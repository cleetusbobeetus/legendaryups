setblock 275 175 331 minecraft:mushroom_stem
fill 275 175 332 275 178 332 minecraft:moss_block
setblock 275 175 336 minecraft:mushroom_stem
fill 275 175 337 275 178 337 minecraft:moss_block
setblock 275 175 341 minecraft:mushroom_stem
fill 275 175 342 275 178 342 minecraft:moss_block
setblock 275 175 346 minecraft:mushroom_stem
fill 275 175 347 275 178 347 minecraft:moss_block
setblock 275 175 351 minecraft:mushroom_stem
fill 275 175 352 275 177 352 minecraft:moss_block
setblock 276 175 325 minecraft:mushroom_stem
fill 276 175 326 276 178 326 minecraft:moss_block
setblock 276 175 330 minecraft:mushroom_stem
fill 276 175 331 276 178 331 minecraft:moss_block
setblock 276 175 335 minecraft:mushroom_stem
fill 276 175 336 276 178 336 minecraft:moss_block
setblock 276 175 340 minecraft:mushroom_stem
fill 276 175 341 276 178 341 minecraft:moss_block
setblock 276 175 345 minecraft:mushroom_stem
fill 276 175 346 276 178 346 minecraft:moss_block
setblock 276 175 350 minecraft:mushroom_stem
fill 276 175 351 276 178 351 minecraft:moss_block
setblock 276 175 355 minecraft:mushroom_stem
setblock 276 175 360 minecraft:mushroom_stem
setblock 276 175 361 minecraft:moss_block
fill 235 176 345 235 214 345 minecraft:green_terracotta
setblock 235 176 346 minecraft:red_mushroom_block
fill 235 176 347 235 228 348 minecraft:green_terracotta
setblock 236 176 323 minecraft:moss_block
setblock 236 176 324 minecraft:mushroom_stem
fill 236 176 325 236 176 328 minecraft:moss_block
setblock 236 176 329 minecraft:mushroom_stem
fill 236 176 330 236 179 330 minecraft:moss_block
setblock 236 176 334 minecraft:mushroom_stem
fill 236 176 335 236 178 335 minecraft:moss_block
setblock 236 176 339 minecraft:mushroom_stem
fill 236 176 340 236 177 340 minecraft:moss_block
setblock 236 176 344 minecraft:mushroom_stem
fill 236 176 345 236 178 345 minecraft:moss_block
setblock 236 176 349 minecraft:mushroom_stem
fill 236 176 350 236 179 350 minecraft:moss_block
setblock 236 176 353 minecraft:moss_block
setblock 236 176 356 minecraft:red_mushroom_block
setblock 236 176 360 minecraft:moss_block
setblock 237 176 323 minecraft:mushroom_stem
fill 237 176 324 237 179 324 minecraft:moss_block
setblock 237 176 328 minecraft:mushroom_stem
fill 237 176 329 237 179 329 minecraft:moss_block
setblock 237 176 333 minecraft:mushroom_stem
setblock 237 176 344 minecraft:moss_block
setblock 237 176 348 minecraft:mushroom_stem
setblock 237 176 349 minecraft:moss_block
setblock 237 176 363 minecraft:mushroom_stem
fill 238 176 323 241 176 323 minecraft:moss_block
setblock 238 176 327 minecraft:mushroom_stem
fill 238 176 328 238 177 328 minecraft:moss_block
fill 238 176 363 241 176 363 minecraft:moss_block
setblock 239 176 346 minecraft:shroomlight
setblock 240 176 325 minecraft:mushroom_stem
setblock 241 176 324 minecraft:mushroom_stem
setblock 241 176 325 minecraft:moss_block
fill 241 176 350 241 180 350 minecraft:dirt
setblock 242 176 323 minecraft:mushroom_stem
fill 242 176 324 245 176 324 minecraft:moss_block
fill 242 176 348 242 180 348 minecraft:dirt
fill 242 176 352 242 180 352 minecraft:dirt
setblock 242 176 363 minecraft:mushroom_stem
fill 243 176 323 246 176 323 minecraft:moss_block
fill 243 176 353 245 180 353 minecraft:dirt
fill 243 176 363 246 176 363 minecraft:moss_block
setblock 246 176 324 minecraft:mushroom_stem
fill 246 176 348 246 180 348 minecraft:dirt
setblock 247 176 323 minecraft:mushroom_stem
fill 247 176 324 250 176 324 minecraft:moss_block
fill 247 176 350 247 180 351 minecraft:dirt
setblock 247 176 363 minecraft:mushroom_stem
fill 248 176 323 248 179 323 minecraft:moss_block
setblock 248 176 362 minecraft:mushroom_stem
fill 248 176 363 251 176 363 minecraft:moss_block
setblock 249 176 325 minecraft:moss_block
fill 249 176 362 252 176 362 minecraft:moss_block
setblock 250 176 325 minecraft:mushroom_stem
setblock 251 176 324 minecraft:mushroom_stem
fill 251 176 325 251 177 325 minecraft:moss_block
setblock 252 176 323 minecraft:mushroom_stem
fill 252 176 324 252 179 324 minecraft:moss_block
setblock 252 176 363 minecraft:mushroom_stem
fill 253 176 323 253 179 323 minecraft:moss_block
setblock 253 176 362 minecraft:mushroom_stem
fill 253 176 363 253 179 363 minecraft:moss_block
setblock 254 176 361 minecraft:mushroom_stem
fill 254 176 362 254 178 362 minecraft:moss_block
setblock 255 176 325 minecraft:mushroom_stem
setblock 256 176 324 minecraft:mushroom_stem
setblock 257 176 323 minecraft:mushroom_stem
setblock 257 176 324 minecraft:moss_block
setblock 257 176 363 minecraft:mushroom_stem
fill 258 176 323 258 177 323 minecraft:moss_block
fill 258 176 363 258 177 363 minecraft:moss_block
fill 268 176 323 268 178 323 minecraft:moss_block
setblock 271 176 324 minecraft:mushroom_stem
fill 271 176 325 271 177 325 minecraft:moss_block
setblock 272 176 323 minecraft:mushroom_stem
fill 272 176 324 272 179 324 minecraft:moss_block
setblock 272 176 363 minecraft:mushroom_stem
fill 273 176 323 273 179 323 minecraft:moss_block
setblock 273 176 343 minecraft:moss_block
setblock 273 176 347 minecraft:mushroom_stem
setblock 273 176 348 minecraft:moss_block
fill 273 176 363 273 177 363 minecraft:moss_block
setblock 274 176 326 minecraft:mushroom_stem
fill 274 176 327 274 179 327 minecraft:moss_block
setblock 274 176 331 minecraft:mushroom_stem
fill 274 176 332 274 179 332 minecraft:moss_block
setblock 274 176 341 minecraft:mushroom_stem
fill 274 176 342 274 177 342 minecraft:moss_block
setblock 274 176 346 minecraft:mushroom_stem
fill 274 176 347 274 178 347 minecraft:moss_block
setblock 275 176 325 minecraft:mushroom_stem
fill 275 176 326 275 179 326 minecraft:moss_block
setblock 275 176 330 minecraft:mushroom_stem
fill 275 176 331 275 179 331 minecraft:moss_block
setblock 275 176 335 minecraft:mushroom_stem
fill 275 176 336 275 179 336 minecraft:moss_block
setblock 275 176 340 minecraft:mushroom_stem
fill 275 176 341 275 178 341 minecraft:moss_block
setblock 275 176 345 minecraft:mushroom_stem
fill 275 176 346 275 179 346 minecraft:moss_block
setblock 275 176 350 minecraft:mushroom_stem
fill 275 176 351 275 179 351 minecraft:moss_block
setblock 276 176 324 minecraft:mushroom_stem
fill 276 176 325 276 179 325 minecraft:moss_block
setblock 276 176 329 minecraft:mushroom_stem
fill 276 176 330 276 179 330 minecraft:moss_block
setblock 276 176 334 minecraft:mushroom_stem
fill 276 176 335 276 179 335 minecraft:moss_block
setblock 276 176 339 minecraft:mushroom_stem
fill 276 176 340 276 179 340 minecraft:moss_block
setblock 276 176 344 minecraft:mushroom_stem
fill 276 176 345 276 179 345 minecraft:moss_block
setblock 276 176 349 minecraft:mushroom_stem
fill 276 176 350 276 179 350 minecraft:moss_block
setblock 276 176 354 minecraft:mushroom_stem
setblock 276 176 355 minecraft:red_mushroom_block
setblock 277 176 349 minecraft:red_mushroom_block
fill 277 176 350 277 225 352 minecraft:green_terracotta
fill 235 177 346 235 224 346 minecraft:green_terracotta
setblock 236 177 323 minecraft:mushroom_stem
fill 236 177 324 236 177 327 minecraft:moss_block
setblock 236 177 328 minecraft:mushroom_stem
fill 236 177 329 236 180 329 minecraft:moss_block
setblock 236 177 333 minecraft:mushroom_stem
fill 236 177 334 236 180 334 minecraft:moss_block
setblock 236 177 338 minecraft:mushroom_stem
setblock 236 177 339 minecraft:moss_block
setblock 236 177 343 minecraft:mushroom_stem
fill 236 177 344 236 178 344 minecraft:moss_block
setblock 236 177 348 minecraft:mushroom_stem
fill 236 177 349 236 180 349 minecraft:moss_block
setblock 236 177 353 minecraft:mushroom_stem
setblock 236 177 363 minecraft:mushroom_stem
fill 237 177 323 240 177 323 minecraft:moss_block
setblock 237 177 327 minecraft:mushroom_stem
fill 237 177 328 237 180 328 minecraft:moss_block
setblock 237 177 332 minecraft:mushroom_stem
fill 237 177 363 240 177 363 minecraft:moss_block
setblock 238 177 326 minecraft:mushroom_stem
fill 238 177 327 238 178 327 minecraft:moss_block
setblock 238 177 332 minecraft:light[level=12]
setblock 238 177 339 minecraft:light[level=12]
setblock 238 177 346 minecraft:light[level=12]
setblock 238 177 353 minecraft:light[level=12]
setblock 238 177 360 minecraft:light[level=12]
setblock 239 177 325 minecraft:mushroom_stem
fill 239 177 346 239 181 346 minecraft:mushroom_stem
setblock 240 177 324 minecraft:mushroom_stem
setblock 241 177 323 minecraft:mushroom_stem
fill 241 177 324 244 177 324 minecraft:moss_block
fill 241 177 349 241 180 349 minecraft:dirt
fill 241 177 351 241 180 352 minecraft:dirt
setblock 241 177 363 minecraft:mushroom_stem
fill 242 177 323 245 177 323 minecraft:moss_block
fill 242 177 353 242 180 353 minecraft:dirt
fill 243 177 347 245 180 347 minecraft:dirt
fill 243 177 363 245 177 363 minecraft:moss_block
setblock 245 177 324 minecraft:mushroom_stem
setblock 245 177 325 minecraft:light[level=12]
setblock 245 177 332 minecraft:light[level=12]
setblock 245 177 339 minecraft:light[level=12]
setblock 245 177 346 minecraft:light[level=12]
setblock 245 177 360 minecraft:light[level=12]
setblock 246 177 323 minecraft:mushroom_stem
fill 246 177 324 249 177 324 minecraft:moss_block
fill 246 177 353 246 180 353 minecraft:dirt
setblock 246 177 363 minecraft:mushroom_stem
fill 247 177 323 247 180 323 minecraft:moss_block
fill 247 177 349 247 180 349 minecraft:dirt
fill 247 177 352 247 180 352 minecraft:dirt
fill 247 177 363 250 177 363 minecraft:moss_block
fill 249 177 362 251 177 362 minecraft:moss_block
setblock 250 177 324 minecraft:mushroom_stem
setblock 251 177 323 minecraft:mushroom_stem
fill 251 177 324 251 180 324 minecraft:moss_block
setblock 251 177 363 minecraft:mushroom_stem
fill 252 177 323 252 180 323 minecraft:moss_block
setblock 252 177 332 minecraft:light[level=12]
fill 252 177 333 255 215 333 minecraft:mushroom_stem
setblock 252 177 346 minecraft:light[level=12]
setblock 252 177 353 minecraft:light[level=12]
setblock 252 177 360 minecraft:light[level=12]
setblock 252 177 362 minecraft:mushroom_stem
fill 252 177 363 252 180 363 minecraft:moss_block
fill 253 177 332 255 215 332 minecraft:mushroom_stem
fill 253 177 334 255 215 334 minecraft:mushroom_stem
fill 253 177 362 253 179 362 minecraft:moss_block
fill 254 177 331 254 215 331 minecraft:mushroom_stem
setblock 255 177 324 minecraft:mushroom_stem
setblock 256 177 323 minecraft:mushroom_stem
setblock 256 177 324 minecraft:moss_block
setblock 256 177 363 minecraft:mushroom_stem
fill 257 177 323 257 178 323 minecraft:moss_block
fill 257 177 363 257 178 363 minecraft:moss_block
fill 259 177 322 259 228 322 minecraft:green_terracotta
setblock 259 177 325 minecraft:light[level=12]
setblock 259 177 332 minecraft:light[level=12]
setblock 259 177 339 minecraft:light[level=12]
setblock 259 177 346 minecraft:light[level=12]
setblock 259 177 353 minecraft:light[level=12]
setblock 259 177 360 minecraft:light[level=12]
setblock 260 177 322 minecraft:red_mushroom_block
setblock 260 177 363 minecraft:red_mushroom_block
setblock 266 177 325 minecraft:light[level=12]
setblock 266 177 332 minecraft:light[level=12]
setblock 266 177 339 minecraft:light[level=12]
setblock 266 177 346 minecraft:light[level=12]
setblock 266 177 353 minecraft:light[level=12]
setblock 266 177 360 minecraft:light[level=12]
fill 269 177 323 269 178 323 minecraft:moss_block
setblock 270 177 324 minecraft:mushroom_stem
setblock 271 177 323 minecraft:mushroom_stem
fill 271 177 324 271 180 324 minecraft:moss_block
fill 272 177 323 272 180 323 minecraft:moss_block
setblock 272 177 363 minecraft:moss_block
setblock 273 177 332 minecraft:light[level=12]
setblock 273 177 339 minecraft:light[level=12]
setblock 273 177 346 minecraft:light[level=12]
setblock 273 177 353 minecraft:light[level=12]
setblock 273 177 360 minecraft:light[level=12]
setblock 274 177 325 minecraft:mushroom_stem
fill 274 177 326 274 180 326 minecraft:moss_block
setblock 274 177 330 minecraft:mushroom_stem
fill 274 177 331 274 180 331 minecraft:moss_block
setblock 274 177 341 minecraft:moss_block
setblock 274 177 345 minecraft:mushroom_stem
fill 274 177 346 274 178 346 minecraft:moss_block
setblock 274 177 350 minecraft:mushroom_stem
setblock 275 177 324 minecraft:mushroom_stem
fill 275 177 325 275 180 325 minecraft:moss_block
setblock 275 177 329 minecraft:mushroom_stem
fill 275 177 330 275 180 330 minecraft:moss_block
setblock 275 177 334 minecraft:mushroom_stem
fill 275 177 335 275 180 335 minecraft:moss_block
setblock 275 177 339 minecraft:mushroom_stem
fill 275 177 340 275 178 340 minecraft:moss_block
setblock 275 177 344 minecraft:mushroom_stem
fill 275 177 345 275 179 345 minecraft:moss_block
setblock 275 177 349 minecraft:mushroom_stem
fill 275 177 350 275 180 350 minecraft:moss_block
setblock 276 177 323 minecraft:mushroom_stem
fill 276 177 324 276 180 324 minecraft:moss_block
setblock 276 177 328 minecraft:mushroom_stem
fill 276 177 329 276 180 329 minecraft:moss_block
setblock 276 177 333 minecraft:mushroom_stem
fill 276 177 334 276 180 334 minecraft:moss_block
setblock 276 177 338 minecraft:mushroom_stem
fill 276 177 339 276 179 339 minecraft:moss_block
setblock 276 177 343 minecraft:mushroom_stem
fill 276 177 344 276 180 344 minecraft:moss_block
setblock 276 177 348 minecraft:mushroom_stem
fill 276 177 349 276 180 349 minecraft:moss_block
setblock 276 177 353 minecraft:mushroom_stem
setblock 276 177 354 minecraft:moss_block
setblock 276 177 363 minecraft:mushroom_stem
fill 277 177 349 277 190 349 minecraft:green_terracotta
fill 236 178 323 236 178 326 minecraft:moss_block
setblock 236 178 327 minecraft:mushroom_stem
fill 236 178 328 236 181 328 minecraft:moss_block
setblock 236 178 332 minecraft:mushroom_stem
fill 236 178 333 236 181 333 minecraft:moss_block
setblock 236 178 343 minecraft:red_mushroom_block
setblock 236 178 347 minecraft:mushroom_stem
fill 236 178 348 236 179 348 minecraft:moss_block
setblock 236 178 352 minecraft:mushroom_stem
setblock 236 178 353 minecraft:moss_block
setblock 236 178 362 minecraft:mushroom_stem
fill 236 178 363 238 178 363 minecraft:moss_block
fill 237 178 323 239 178 323 minecraft:moss_block
setblock 237 178 326 minecraft:mushroom_stem
fill 237 178 327 237 181 327 minecraft:moss_block
setblock 237 178 331 minecraft:mushroom_stem
setblock 237 178 332 minecraft:moss_block
setblock 238 178 325 minecraft:mushroom_stem
setblock 238 178 326 minecraft:moss_block
setblock 238 178 328 minecraft:shroomlight
setblock 238 178 364 minecraft:shroomlight
setblock 239 178 324 minecraft:mushroom_stem
setblock 240 178 323 minecraft:mushroom_stem
fill 240 178 324 241 178 324 minecraft:moss_block
fill 241 178 323 244 178 323 minecraft:moss_block
fill 241 178 348 241 180 348 minecraft:dirt
setblock 241 178 363 minecraft:red_mushroom_block
fill 242 178 347 242 180 347 minecraft:dirt
fill 243 178 354 246 180 354 minecraft:dirt
setblock 245 178 323 minecraft:mushroom_stem
setblock 245 178 363 minecraft:mushroom_stem
fill 246 178 323 246 181 323 minecraft:moss_block
fill 246 178 347 246 180 347 minecraft:dirt
fill 246 178 363 249 178 363 minecraft:moss_block
fill 247 178 324 248 178 324 minecraft:moss_block
fill 247 178 353 247 180 353 minecraft:dirt
fill 248 178 351 248 180 351 minecraft:dirt
setblock 249 178 324 minecraft:mushroom_stem
fill 249 178 362 250 178 362 minecraft:moss_block
setblock 250 178 323 minecraft:mushroom_stem
fill 250 178 324 250 180 324 minecraft:moss_block
setblock 250 178 363 minecraft:mushroom_stem
fill 251 178 323 251 181 323 minecraft:moss_block
setblock 251 178 362 minecraft:mushroom_stem
fill 251 178 363 251 181 363 minecraft:moss_block
fill 252 178 331 252 179 332 minecraft:dirt
fill 252 178 334 252 179 334 minecraft:dirt
fill 252 178 362 252 179 362 minecraft:moss_block
fill 253 178 331 253 179 331 minecraft:dirt
fill 253 178 335 254 179 335 minecraft:dirt
setblock 254 178 324 minecraft:mushroom_stem
setblock 255 178 323 minecraft:mushroom_stem
setblock 255 178 324 minecraft:moss_block
fill 255 178 331 255 179 331 minecraft:dirt
setblock 255 178 363 minecraft:mushroom_stem
setblock 256 178 323 minecraft:moss_block
fill 256 178 332 256 179 334 minecraft:dirt
fill 256 178 363 256 179 363 minecraft:moss_block
fill 260 178 322 260 204 322 minecraft:green_terracotta
setblock 266 178 363 minecraft:red_mushroom_block
setblock 270 178 323 minecraft:mushroom_stem
fill 270 178 324 270 181 324 minecraft:moss_block
fill 271 178 323 271 181 323 minecraft:moss_block
setblock 273 178 325 minecraft:mushroom_stem
setblock 274 178 324 minecraft:mushroom_stem
fill 274 178 325 274 179 325 minecraft:moss_block
setblock 274 178 329 minecraft:mushroom_stem
fill 274 178 330 274 181 330 minecraft:moss_block
setblock 274 178 344 minecraft:mushroom_stem
setblock 274 178 345 minecraft:moss_block
setblock 274 178 349 minecraft:mushroom_stem
setblock 275 178 323 minecraft:mushroom_stem
fill 275 178 324 275 181 324 minecraft:moss_block
setblock 275 178 328 minecraft:mushroom_stem
fill 275 178 329 275 181 329 minecraft:moss_block
setblock 275 178 333 minecraft:mushroom_stem
fill 275 178 334 275 181 334 minecraft:moss_block
setblock 275 178 338 minecraft:mushroom_stem
setblock 275 178 339 minecraft:moss_block
setblock 275 178 343 minecraft:mushroom_stem
fill 275 178 344 275 179 344 minecraft:moss_block
setblock 275 178 348 minecraft:mushroom_stem
fill 275 178 349 275 180 349 minecraft:moss_block
fill 276 178 323 276 181 323 minecraft:moss_block
setblock 276 178 327 minecraft:mushroom_stem
fill 276 178 328 276 181 328 minecraft:moss_block
setblock 276 178 332 minecraft:mushroom_stem
fill 276 178 333 276 181 333 minecraft:moss_block
setblock 276 178 337 minecraft:mushroom_stem
fill 276 178 338 276 180 338 minecraft:moss_block
setblock 276 178 342 minecraft:mushroom_stem
fill 276 178 343 276 180 343 minecraft:moss_block
setblock 276 178 347 minecraft:mushroom_stem
fill 276 178 348 276 181 348 minecraft:moss_block
setblock 276 178 352 minecraft:mushroom_stem
fill 276 178 353 276 179 353 minecraft:moss_block
setblock 276 178 362 minecraft:red_mushroom_block
fill 236 179 323 236 179 325 minecraft:moss_block
setblock 236 179 326 minecraft:mushroom_stem
fill 236 179 327 236 182 327 minecraft:moss_block
setblock 236 179 331 minecraft:mushroom_stem
fill 236 179 332 236 182 332 minecraft:moss_block
setblock 236 179 346 minecraft:mushroom_stem
setblock 236 179 347 minecraft:moss_block
setblock 236 179 351 minecraft:mushroom_stem
fill 236 179 352 236 182 352 minecraft:moss_block
setblock 236 179 355 minecraft:red_mushroom_block
setblock 236 179 363 minecraft:moss_block
fill 237 179 323 238 179 323 minecraft:moss_block
setblock 237 179 325 minecraft:mushroom_stem
fill 237 179 326 237 182 326 minecraft:moss_block
setblock 237 179 330 minecraft:mushroom_stem
fill 237 179 331 237 181 331 minecraft:moss_block
setblock 238 179 324 minecraft:mushroom_stem
fill 238 179 328 238 183 328 minecraft:mushroom_stem
fill 238 179 364 238 230 364 minecraft:green_terracotta
setblock 239 179 323 minecraft:mushroom_stem
setblock 239 179 324 minecraft:moss_block
fill 239 179 326 239 183 326 minecraft:red_mushroom_block
fill 240 179 323 243 179 323 minecraft:moss_block
fill 240 179 349 240 180 352 minecraft:dirt
fill 241 179 347 241 180 347 minecraft:dirt
fill 241 179 353 241 180 353 minecraft:dirt
fill 242 179 354 242 180 354 minecraft:dirt
fill 243 179 346 246 180 346 minecraft:dirt
setblock 244 179 323 minecraft:mushroom_stem
fill 245 179 323 245 182 323 minecraft:moss_block
fill 246 179 363 248 179 363 minecraft:moss_block
setblock 248 179 324 minecraft:mushroom_stem
fill 248 179 352 248 180 352 minecraft:dirt
setblock 249 179 323 minecraft:mushroom_stem
fill 249 179 324 249 180 324 minecraft:moss_block
setblock 249 179 363 minecraft:mushroom_stem
fill 250 179 323 250 182 323 minecraft:moss_block
setblock 250 179 362 minecraft:mushroom_stem
fill 250 179 363 250 182 363 minecraft:moss_block
fill 251 179 331 251 179 334 minecraft:dirt
setblock 251 179 362 minecraft:moss_block
fill 252 179 330 255 179 330 minecraft:dirt
setblock 252 179 335 minecraft:dirt
setblock 253 179 324 minecraft:mushroom_stem
setblock 254 179 323 minecraft:mushroom_stem
setblock 254 179 336 minecraft:dirt
setblock 254 179 363 minecraft:mushroom_stem
setblock 255 179 323 minecraft:moss_block
fill 255 179 335 256 179 335 minecraft:dirt
fill 255 179 363 255 180 363 minecraft:moss_block
setblock 256 179 331 minecraft:dirt
fill 257 179 332 257 179 333 minecraft:dirt
setblock 265 179 323 minecraft:red_mushroom_block
setblock 269 179 323 minecraft:mushroom_stem
fill 270 179 322 270 228 322 minecraft:green_terracotta
fill 270 179 323 270 182 323 minecraft:moss_block
setblock 271 179 322 minecraft:red_mushroom_block
setblock 272 179 325 minecraft:mushroom_stem
setblock 272 179 363 minecraft:red_mushroom_block
setblock 273 179 324 minecraft:mushroom_stem
fill 273 179 325 273 180 325 minecraft:moss_block
setblock 273 179 364 minecraft:shroomlight
setblock 274 179 323 minecraft:mushroom_stem
fill 274 179 324 274 182 324 minecraft:moss_block
setblock 274 179 328 minecraft:mushroom_stem
fill 274 179 329 274 182 329 minecraft:moss_block
setblock 274 179 333 minecraft:mushroom_stem
setblock 275 179 322 minecraft:red_mushroom_block
fill 275 179 323 275 182 323 minecraft:moss_block
setblock 275 179 327 minecraft:mushroom_stem
fill 275 179 328 275 182 328 minecraft:moss_block
setblock 275 179 332 minecraft:mushroom_stem
fill 275 179 333 275 182 333 minecraft:moss_block
setblock 275 179 343 minecraft:moss_block
setblock 275 179 347 minecraft:mushroom_stem
fill 275 179 348 275 180 348 minecraft:moss_block
setblock 276 179 326 minecraft:mushroom_stem
fill 276 179 327 276 182 327 minecraft:moss_block
setblock 276 179 331 minecraft:mushroom_stem
fill 276 179 332 276 182 332 minecraft:moss_block
setblock 276 179 336 minecraft:mushroom_stem
fill 276 179 337 276 182 337 minecraft:moss_block
setblock 276 179 341 minecraft:mushroom_stem
setblock 276 179 342 minecraft:moss_block
setblock 276 179 346 minecraft:mushroom_stem
fill 276 179 347 276 181 347 minecraft:moss_block
setblock 276 179 351 minecraft:mushroom_stem
fill 276 179 352 276 182 352 minecraft:moss_block
setblock 276 179 356 minecraft:red_mushroom_block
fill 236 180 323 236 180 324 minecraft:moss_block
setblock 236 180 325 minecraft:mushroom_stem
fill 236 180 326 236 183 326 minecraft:moss_block
setblock 236 180 330 minecraft:mushroom_stem
fill 236 180 331 236 183 331 minecraft:moss_block
setblock 236 180 336 minecraft:red_mushroom_block
setblock 236 180 350 minecraft:mushroom_stem
fill 236 180 351 236 183 351 minecraft:moss_block
setblock 236 180 361 minecraft:red_mushroom_block
setblock 237 180 323 minecraft:moss_block
setblock 237 180 324 minecraft:mushroom_stem
fill 237 180 325 237 181 325 minecraft:moss_block
setblock 237 180 329 minecraft:mushroom_stem
fill 237 180 330 237 183 330 minecraft:moss_block
setblock 238 180 323 minecraft:mushroom_stem
fill 239 180 323 240 180 323 minecraft:moss_block
setblock 240 180 348 minecraft:dirt
setblock 240 180 353 minecraft:dirt
setblock 241 180 354 minecraft:dirt
setblock 242 180 346 minecraft:dirt
fill 243 180 355 246 180 355 minecraft:dirt
setblock 244 180 323 minecraft:moss_block
fill 246 180 363 247 180 363 minecraft:moss_block
setblock 247 180 354 minecraft:dirt
setblock 248 180 323 minecraft:mushroom_stem
setblock 248 180 350 minecraft:dirt
setblock 248 180 353 minecraft:dirt
setblock 248 180 363 minecraft:mushroom_stem
fill 249 180 323 249 183 323 minecraft:moss_block
fill 249 180 351 249 180 352 minecraft:dirt
fill 249 180 363 249 183 363 minecraft:moss_block
setblock 253 180 323 minecraft:mushroom_stem
setblock 253 180 363 minecraft:mushroom_stem
setblock 254 180 323 minecraft:moss_block
fill 254 180 363 254 181 363 minecraft:moss_block
setblock 259 180 323 minecraft:red_mushroom_block
fill 269 180 323 269 183 323 minecraft:moss_block
fill 270 180 341 270 181 341 minecraft:shroomlight
fill 271 180 322 271 204 322 minecraft:green_terracotta
setblock 272 180 324 minecraft:mushroom_stem
setblock 273 180 323 minecraft:mushroom_stem
fill 273 180 324 273 183 324 minecraft:moss_block
fill 273 180 364 273 228 364 minecraft:green_terracotta
fill 274 180 323 274 183 323 minecraft:moss_block
setblock 274 180 327 minecraft:mushroom_stem
fill 274 180 328 274 183 328 minecraft:moss_block
setblock 274 180 332 minecraft:mushroom_stem
fill 274 180 333 274 183 333 minecraft:moss_block
fill 275 180 322 275 228 322 minecraft:green_terracotta
setblock 275 180 326 minecraft:mushroom_stem
fill 275 180 327 275 183 327 minecraft:moss_block
setblock 275 180 331 minecraft:mushroom_stem
fill 275 180 332 275 183 332 minecraft:moss_block
setblock 275 180 346 minecraft:mushroom_stem
setblock 275 180 347 minecraft:moss_block
setblock 276 180 325 minecraft:mushroom_stem
fill 276 180 326 276 183 326 minecraft:moss_block
setblock 276 180 330 minecraft:mushroom_stem
fill 276 180 331 276 183 331 minecraft:moss_block
setblock 276 180 335 minecraft:mushroom_stem
fill 276 180 336 276 183 336 minecraft:moss_block
setblock 276 180 345 minecraft:mushroom_stem
fill 276 180 346 276 181 346 minecraft:moss_block
setblock 276 180 350 minecraft:mushroom_stem
fill 276 180 351 276 183 351 minecraft:moss_block
setblock 236 181 323 minecraft:moss_block
setblock 236 181 324 minecraft:mushroom_stem
fill 236 181 325 236 184 325 minecraft:moss_block
setblock 236 181 329 minecraft:mushroom_stem
fill 236 181 330 236 184 330 minecraft:moss_block
setblock 236 181 334 minecraft:mushroom_stem
setblock 236 181 342 minecraft:red_mushroom_block
setblock 236 181 350 minecraft:moss_block
setblock 236 181 353 minecraft:moss_block
setblock 237 181 323 minecraft:mushroom_stem
setblock 237 181 328 minecraft:mushroom_stem
fill 237 181 329 237 183 329 minecraft:moss_block
fill 238 181 323 239 181 323 minecraft:moss_block
setblock 238 181 325 minecraft:light[level=15]
setblock 238 181 333 minecraft:light[level=15]
setblock 238 181 341 minecraft:light[level=15]
setblock 238 181 349 minecraft:light[level=15]
setblock 238 181 357 minecraft:light[level=15]
fill 239 181 322 239 225 322 minecraft:green_terracotta
setblock 240 181 322 minecraft:red_mushroom_block
setblock 240 181 363 minecraft:red_mushroom_block
fill 241 181 322 242 228 322 minecraft:green_terracotta
fill 244 181 350 244 184 350 minecraft:mushroom_stem
setblock 246 181 325 minecraft:light[level=15]
setblock 246 181 333 minecraft:light[level=15]
setblock 246 181 341 minecraft:light[level=15]
setblock 246 181 349 minecraft:light[level=15]
setblock 246 181 357 minecraft:light[level=15]
setblock 246 181 363 minecraft:moss_block
setblock 247 181 323 minecraft:mushroom_stem
setblock 247 181 363 minecraft:mushroom_stem
fill 248 181 323 248 184 323 minecraft:moss_block
fill 248 181 363 248 184 363 minecraft:moss_block
setblock 252 181 323 minecraft:mushroom_stem
setblock 252 181 363 minecraft:mushroom_stem
setblock 253 181 323 minecraft:moss_block
fill 253 181 363 253 184 363 minecraft:moss_block
setblock 254 181 325 minecraft:light[level=15]
setblock 254 181 341 minecraft:light[level=15]
setblock 254 181 349 minecraft:light[level=15]
setblock 254 181 357 minecraft:light[level=15]
setblock 259 181 363 minecraft:red_mushroom_block
setblock 262 181 325 minecraft:light[level=15]
setblock 262 181 333 minecraft:light[level=15]
setblock 262 181 341 minecraft:light[level=15]
setblock 262 181 349 minecraft:light[level=15]
setblock 262 181 357 minecraft:light[level=15]
setblock 270 181 325 minecraft:light[level=15]
setblock 270 181 333 minecraft:light[level=15]
setblock 270 181 349 minecraft:light[level=15]
setblock 270 181 357 minecraft:light[level=15]
setblock 271 181 324 minecraft:mushroom_stem
setblock 272 181 323 minecraft:mushroom_stem
fill 272 181 324 272 184 324 minecraft:moss_block
fill 273 181 323 273 184 323 minecraft:moss_block
setblock 274 181 326 minecraft:mushroom_stem
fill 274 181 327 274 184 327 minecraft:moss_block
setblock 274 181 331 minecraft:mushroom_stem
fill 274 181 332 274 184 332 minecraft:moss_block
fill 274 181 334 274 182 334 minecraft:moss_block
setblock 275 181 325 minecraft:mushroom_stem
fill 275 181 326 275 184 326 minecraft:moss_block
setblock 275 181 330 minecraft:mushroom_stem
fill 275 181 331 275 184 331 minecraft:moss_block
setblock 275 181 335 minecraft:mushroom_stem
setblock 276 181 324 minecraft:mushroom_stem
fill 276 181 325 276 184 325 minecraft:moss_block
setblock 276 181 329 minecraft:mushroom_stem
fill 276 181 330 276 184 330 minecraft:moss_block
setblock 276 181 334 minecraft:mushroom_stem
fill 276 181 335 276 184 335 minecraft:moss_block
setblock 276 181 344 minecraft:red_mushroom_block
setblock 276 181 349 minecraft:mushroom_stem
fill 276 181 350 276 183 350 minecraft:moss_block
setblock 235 182 342 minecraft:shroomlight
setblock 236 182 323 minecraft:mushroom_stem
fill 236 182 324 236 185 324 minecraft:moss_block
setblock 236 182 328 minecraft:mushroom_stem
fill 236 182 329 236 183 329 minecraft:moss_block
setblock 236 182 333 minecraft:mushroom_stem
fill 236 182 334 236 185 334 minecraft:moss_block
setblock 236 182 348 minecraft:red_mushroom_block
setblock 236 182 353 minecraft:mushroom_stem
fill 236 182 354 236 185 354 minecraft:moss_block
fill 237 182 323 238 182 323 minecraft:moss_block
setblock 237 182 327 minecraft:mushroom_stem
fill 237 182 328 237 183 328 minecraft:moss_block
fill 237 182 345 241 182 347 minecraft:brown_mushroom_block
fill 238 182 344 240 182 344 minecraft:brown_mushroom_block
fill 238 182 348 240 182 348 minecraft:brown_mushroom_block
fill 240 182 322 240 228 322 minecraft:green_terracotta
setblock 245 182 363 minecraft:moss_block
setblock 246 182 323 minecraft:mushroom_stem
setblock 246 182 363 minecraft:mushroom_stem
fill 247 182 323 247 185 323 minecraft:moss_block
fill 247 182 363 247 185 363 minecraft:moss_block
fill 249 182 362 250 183 362 minecraft:moss_block
setblock 251 182 323 minecraft:mushroom_stem
setblock 251 182 363 minecraft:mushroom_stem
fill 252 182 323 252 183 323 minecraft:moss_block
fill 252 182 363 252 185 363 minecraft:moss_block
setblock 265 182 363 minecraft:red_mushroom_block
setblock 266 182 323 minecraft:red_mushroom_block
fill 268 182 323 268 184 323 minecraft:moss_block
setblock 270 182 324 minecraft:mushroom_stem
fill 270 182 341 270 189 341 minecraft:dirt
setblock 271 182 323 minecraft:mushroom_stem
fill 271 182 324 271 185 324 minecraft:moss_block
fill 272 182 323 272 185 323 minecraft:moss_block
fill 273 182 329 273 182 330 minecraft:moss_block
setblock 273 182 331 minecraft:mushroom_stem
setblock 274 182 326 minecraft:moss_block
setblock 274 182 330 minecraft:mushroom_stem
fill 274 182 331 274 185 331 minecraft:moss_block
fill 275 182 325 275 185 325 minecraft:moss_block
setblock 275 182 329 minecraft:mushroom_stem
fill 275 182 330 275 185 330 minecraft:moss_block
setblock 275 182 334 minecraft:mushroom_stem
fill 275 182 335 275 184 336 minecraft:moss_block
setblock 276 182 323 minecraft:mushroom_stem
fill 276 182 324 276 185 324 minecraft:moss_block
setblock 276 182 328 minecraft:mushroom_stem
fill 276 182 329 276 185 329 minecraft:moss_block
setblock 276 182 333 minecraft:mushroom_stem
fill 276 182 334 276 185 334 minecraft:moss_block
setblock 276 182 338 minecraft:red_mushroom_block
setblock 276 182 348 minecraft:mushroom_stem
setblock 276 182 349 minecraft:moss_block
setblock 276 182 353 minecraft:mushroom_stem
setblock 276 182 357 minecraft:red_mushroom_block
fill 235 183 342 235 201 342 minecraft:green_terracotta
fill 236 183 323 237 184 323 minecraft:moss_block
setblock 236 183 327 minecraft:mushroom_stem
setblock 236 183 328 minecraft:moss_block
setblock 236 183 332 minecraft:mushroom_stem
fill 236 183 333 236 186 333 minecraft:moss_block
fill 236 183 335 236 184 335 minecraft:moss_block
setblock 236 183 352 minecraft:mushroom_stem
fill 236 183 353 236 186 353 minecraft:moss_block
fill 236 183 355 236 183 356 minecraft:moss_block
setblock 237 183 327 minecraft:moss_block
setblock 237 183 331 minecraft:mushroom_stem
setblock 238 183 325 minecraft:light[level=12]
setblock 238 183 332 minecraft:light[level=12]
setblock 238 183 339 minecraft:light[level=12]
setblock 238 183 346 minecraft:light[level=12]
setblock 238 183 353 minecraft:light[level=12]
setblock 238 183 360 minecraft:light[level=12]
setblock 241 183 323 minecraft:red_mushroom_block
setblock 244 183 363 minecraft:moss_block
setblock 245 183 323 minecraft:mushroom_stem
setblock 245 183 325 minecraft:light[level=12]
setblock 245 183 332 minecraft:light[level=12]
setblock 245 183 339 minecraft:light[level=12]
setblock 245 183 346 minecraft:light[level=12]
setblock 245 183 353 minecraft:light[level=12]
setblock 245 183 360 minecraft:light[level=12]
setblock 245 183 363 minecraft:mushroom_stem
fill 246 183 323 246 186 323 minecraft:moss_block
fill 246 183 363 246 186 363 minecraft:moss_block
fill 247 183 362 248 185 362 minecraft:moss_block
setblock 250 183 323 minecraft:mushroom_stem
setblock 250 183 363 minecraft:mushroom_stem
fill 251 183 323 251 185 323 minecraft:moss_block
setblock 251 183 362 minecraft:mushroom_stem
fill 251 183 363 251 186 363 minecraft:moss_block
setblock 252 183 325 minecraft:light[level=12]
setblock 252 183 332 minecraft:light[level=12]
setblock 252 183 346 minecraft:light[level=12]
setblock 252 183 353 minecraft:light[level=12]
setblock 252 183 360 minecraft:light[level=12]
setblock 259 183 325 minecraft:light[level=12]
setblock 259 183 332 minecraft:light[level=12]
setblock 259 183 339 minecraft:light[level=12]
setblock 259 183 346 minecraft:light[level=12]
setblock 259 183 353 minecraft:light[level=12]
setblock 259 183 360 minecraft:light[level=12]
setblock 260 183 323 minecraft:red_mushroom_block
setblock 266 183 325 minecraft:light[level=12]
setblock 266 183 332 minecraft:light[level=12]
setblock 266 183 339 minecraft:light[level=12]
setblock 266 183 346 minecraft:light[level=12]
setblock 266 183 353 minecraft:light[level=12]
setblock 266 183 360 minecraft:light[level=12]
setblock 269 183 324 minecraft:mushroom_stem
setblock 270 183 323 minecraft:mushroom_stem
fill 270 183 324 270 186 324 minecraft:moss_block
fill 270 183 342 270 189 342 minecraft:dirt
fill 271 183 323 271 186 323 minecraft:moss_block
fill 271 183 341 271 189 341 minecraft:dirt
setblock 271 183 363 minecraft:red_mushroom_block
fill 273 183 322 273 228 322 minecraft:green_terracotta
setblock 273 183 325 minecraft:light[level=12]
setblock 273 183 329 minecraft:moss_block
setblock 273 183 330 minecraft:mushroom_stem
fill 273 183 331 273 184 333 minecraft:moss_block
setblock 273 183 339 minecraft:light[level=12]
setblock 273 183 346 minecraft:light[level=12]
setblock 273 183 353 minecraft:light[level=12]
setblock 273 183 360 minecraft:light[level=12]
setblock 274 183 322 minecraft:shroomlight
setblock 274 183 324 minecraft:mushroom_stem
setblock 274 183 329 minecraft:mushroom_stem
fill 274 183 330 274 186 330 minecraft:moss_block
setblock 274 183 334 minecraft:mushroom_stem
fill 274 183 335 274 186 335 minecraft:moss_block
setblock 275 183 323 minecraft:mushroom_stem
setblock 275 183 328 minecraft:mushroom_stem
fill 275 183 329 275 186 329 minecraft:moss_block
setblock 275 183 333 minecraft:mushroom_stem
fill 275 183 334 275 186 334 minecraft:moss_block
fill 276 183 323 276 186 323 minecraft:moss_block
setblock 276 183 327 minecraft:mushroom_stem
fill 276 183 328 276 186 328 minecraft:moss_block
setblock 276 183 332 minecraft:mushroom_stem
fill 276 183 333 276 186 333 minecraft:moss_block
setblock 276 183 337 minecraft:mushroom_stem
fill 276 183 338 276 186 338 minecraft:moss_block
setblock 276 183 352 minecraft:mushroom_stem
fill 276 183 353 276 186 353 minecraft:moss_block
setblock 235 184 330 minecraft:shroomlight
setblock 236 184 326 minecraft:mushroom_stem
fill 236 184 327 240 184 329 minecraft:brown_mushroom_block
setblock 236 184 331 minecraft:mushroom_stem
fill 236 184 332 236 187 332 minecraft:moss_block
setblock 236 184 341 minecraft:red_mushroom_block
setblock 236 184 351 minecraft:mushroom_stem
fill 236 184 352 236 187 352 minecraft:moss_block
setblock 236 184 355 minecraft:moss_block
setblock 236 184 356 minecraft:mushroom_stem
fill 236 184 357 236 185 359 minecraft:moss_block
setblock 236 184 360 minecraft:red_mushroom_block
fill 237 184 326 239 184 326 minecraft:brown_mushroom_block
fill 237 184 330 239 184 330 minecraft:brown_mushroom_block
fill 237 184 331 237 185 331 minecraft:moss_block
fill 243 184 349 243 186 351 minecraft:red_mushroom_block
setblock 243 184 363 minecraft:moss_block
setblock 244 184 323 minecraft:mushroom_stem
fill 244 184 349 245 186 349 minecraft:red_mushroom_block
fill 244 184 351 245 186 352 minecraft:red_mushroom_block
setblock 244 184 363 minecraft:mushroom_stem
fill 245 184 323 245 187 323 minecraft:moss_block
fill 245 184 350 246 186 350 minecraft:red_mushroom_block
setblock 245 184 362 minecraft:mushroom_stem
fill 245 184 363 245 187 363 minecraft:moss_block
fill 246 184 351 246 186 351 minecraft:red_mushroom_block
fill 246 184 362 246 187 362 minecraft:moss_block
setblock 249 184 323 minecraft:mushroom_stem
setblock 249 184 362 minecraft:moss_block
setblock 249 184 363 minecraft:mushroom_stem
fill 250 184 323 250 187 323 minecraft:moss_block
setblock 250 184 362 minecraft:mushroom_stem
fill 250 184 363 250 187 363 minecraft:moss_block
fill 251 184 362 251 187 362 minecraft:moss_block
setblock 254 184 323 minecraft:red_mushroom_block
setblock 258 184 363 minecraft:red_mushroom_block
fill 267 184 323 267 185 323 minecraft:moss_block
setblock 269 184 323 minecraft:mushroom_stem
fill 269 184 324 269 187 324 minecraft:moss_block
fill 269 184 341 269 189 341 minecraft:dirt
fill 270 184 323 270 187 323 minecraft:moss_block
fill 270 184 340 271 189 340 minecraft:dirt
fill 271 184 342 271 189 342 minecraft:dirt
setblock 273 184 324 minecraft:mushroom_stem
setblock 273 184 329 minecraft:mushroom_stem
fill 273 184 330 273 186 330 minecraft:moss_block
fill 274 184 322 274 207 322 minecraft:green_terracotta
setblock 274 184 323 minecraft:mushroom_stem
setblock 274 184 324 minecraft:moss_block
setblock 274 184 328 minecraft:mushroom_stem
fill 274 184 329 274 187 329 minecraft:moss_block
setblock 274 184 333 minecraft:mushroom_stem
fill 274 184 334 274 187 334 minecraft:moss_block
fill 275 184 323 275 187 323 minecraft:moss_block
setblock 275 184 327 minecraft:mushroom_stem
fill 275 184 328 275 187 328 minecraft:moss_block
setblock 275 184 332 minecraft:mushroom_stem
fill 275 184 333 275 187 333 minecraft:moss_block
setblock 275 184 337 minecraft:mushroom_stem
setblock 276 184 326 minecraft:mushroom_stem
fill 276 184 327 276 187 327 minecraft:moss_block
setblock 276 184 331 minecraft:mushroom_stem
fill 276 184 332 276 187 332 minecraft:moss_block
setblock 276 184 336 minecraft:mushroom_stem
fill 276 184 337 276 187 337 minecraft:moss_block
setblock 276 184 345 minecraft:red_mushroom_block
setblock 276 184 351 minecraft:mushroom_stem
fill 276 184 352 276 186 352 minecraft:moss_block
fill 276 184 354 276 184 355 minecraft:moss_block
fill 235 185 330 235 228 330 minecraft:green_terracotta
fill 236 185 323 236 186 323 minecraft:moss_block
setblock 236 185 325 minecraft:mushroom_stem
fill 236 185 326 236 185 329 minecraft:moss_block
setblock 236 185 330 minecraft:mushroom_stem
fill 236 185 331 236 188 331 minecraft:moss_block
setblock 236 185 335 minecraft:mushroom_stem
fill 236 185 336 236 188 336 minecraft:moss_block
setblock 236 185 347 minecraft:red_mushroom_block
fill 236 185 351 236 187 351 minecraft:moss_block
setblock 236 185 355 minecraft:mushroom_stem
fill 236 185 356 236 188 356 minecraft:moss_block
setblock 236 185 360 minecraft:mushroom_stem
fill 236 185 361 236 188 361 minecraft:moss_block
setblock 237 185 329 minecraft:mushroom_stem
setblock 237 185 330 minecraft:moss_block
fill 238 185 332 238 194 332 minecraft:iron_block
fill 239 185 326 239 197 326 minecraft:red_mushroom_block
setblock 239 185 363 minecraft:red_mushroom_block
fill 241 185 363 242 185 363 minecraft:moss_block
fill 242 185 350 242 185 351 minecraft:red_mushroom_block
setblock 243 185 323 minecraft:mushroom_stem
setblock 243 185 352 minecraft:red_mushroom_block
setblock 243 185 363 minecraft:mushroom_stem
fill 244 185 323 244 188 323 minecraft:moss_block
setblock 244 185 348 minecraft:red_mushroom_block
fill 244 185 350 244 186 350 minecraft:red_mushroom_block
setblock 244 185 362 minecraft:mushroom_stem
fill 244 185 363 244 188 363 minecraft:moss_block
fill 245 185 362 245 188 362 minecraft:moss_block
setblock 246 185 349 minecraft:red_mushroom_block
fill 246 185 361 249 185 361 minecraft:moss_block
setblock 248 185 323 minecraft:mushroom_stem
setblock 248 185 363 minecraft:mushroom_stem
fill 249 185 323 249 188 323 minecraft:moss_block
setblock 249 185 362 minecraft:mushroom_stem
fill 249 185 363 249 188 363 minecraft:moss_block
setblock 250 185 361 minecraft:mushroom_stem
fill 250 185 362 250 188 362 minecraft:moss_block
setblock 253 185 363 minecraft:mushroom_stem
setblock 264 185 363 minecraft:red_mushroom_block
fill 266 185 323 266 186 323 minecraft:moss_block
setblock 268 185 323 minecraft:mushroom_stem
fill 268 185 324 268 188 324 minecraft:moss_block
fill 269 185 323 269 188 323 minecraft:moss_block
fill 269 185 340 269 189 340 minecraft:dirt
fill 269 185 342 269 189 342 minecraft:dirt
fill 270 185 343 271 189 343 minecraft:dirt
setblock 272 185 324 minecraft:mushroom_stem
fill 272 185 341 272 189 342 minecraft:dirt
setblock 273 185 323 minecraft:mushroom_stem
fill 273 185 324 273 186 324 minecraft:moss_block
setblock 273 185 329 minecraft:moss_block
fill 273 185 331 273 185 332 minecraft:moss_block
setblock 273 185 333 minecraft:mushroom_stem
fill 273 185 334 273 187 334 minecraft:moss_block
fill 274 185 323 274 188 323 minecraft:moss_block
setblock 274 185 327 minecraft:mushroom_stem
fill 274 185 328 274 186 328 minecraft:moss_block
setblock 274 185 332 minecraft:mushroom_stem
fill 274 185 333 274 188 333 minecraft:moss_block
setblock 274 185 336 minecraft:moss_block
setblock 275 185 326 minecraft:mushroom_stem
fill 275 185 327 275 187 327 minecraft:moss_block
setblock 275 185 331 minecraft:mushroom_stem
fill 275 185 332 275 188 332 minecraft:moss_block
setblock 275 185 335 minecraft:moss_block
setblock 275 185 336 minecraft:mushroom_stem
fill 275 185 337 275 188 337 minecraft:moss_block
setblock 276 185 325 minecraft:mushroom_stem
fill 276 185 326 276 188 326 minecraft:moss_block
setblock 276 185 330 minecraft:mushroom_stem
fill 276 185 331 276 188 331 minecraft:moss_block
setblock 276 185 335 minecraft:mushroom_stem
fill 276 185 336 276 188 336 minecraft:moss_block
setblock 276 185 339 minecraft:red_mushroom_block
setblock 276 185 351 minecraft:moss_block
setblock 276 185 354 minecraft:moss_block
setblock 276 185 355 minecraft:mushroom_stem
fill 276 185 356 276 188 356 minecraft:moss_block
fill 276 185 358 276 186 358 minecraft:red_mushroom_block
setblock 236 186 324 minecraft:mushroom_stem
fill 236 186 325 236 186 328 minecraft:moss_block
setblock 236 186 329 minecraft:mushroom_stem
fill 236 186 330 236 189 330 minecraft:moss_block
setblock 236 186 334 minecraft:mushroom_stem
fill 236 186 335 236 189 335 minecraft:moss_block
setblock 236 186 354 minecraft:mushroom_stem
fill 236 186 355 237 188 355 minecraft:moss_block
fill 236 186 357 236 186 358 minecraft:moss_block
setblock 236 186 359 minecraft:mushroom_stem
fill 236 186 360 236 189 360 minecraft:moss_block
fill 236 186 362 236 186 363 minecraft:moss_block
fill 237 186 356 237 186 357 minecraft:moss_block
setblock 237 186 363 minecraft:mushroom_stem
fill 238 186 363 241 186 363 minecraft:moss_block
setblock 242 186 323 minecraft:mushroom_stem
setblock 242 186 362 minecraft:moss_block
setblock 242 186 363 minecraft:mushroom_stem
fill 243 186 323 243 189 323 minecraft:moss_block
setblock 243 186 362 minecraft:mushroom_stem
fill 243 186 363 243 189 363 minecraft:moss_block
setblock 244 186 361 minecraft:mushroom_stem
fill 244 186 362 244 189 362 minecraft:moss_block
fill 245 186 361 248 186 361 minecraft:moss_block
setblock 247 186 323 minecraft:mushroom_stem
setblock 247 186 362 minecraft:moss_block
setblock 247 186 363 minecraft:mushroom_stem
fill 248 186 323 248 189 323 minecraft:moss_block
setblock 248 186 362 minecraft:mushroom_stem
fill 248 186 363 248 189 363 minecraft:moss_block
setblock 249 186 361 minecraft:mushroom_stem
fill 249 186 362 249 189 362 minecraft:moss_block
fill 250 186 361 250 189 361 minecraft:moss_block
setblock 252 186 362 minecraft:moss_block
setblock 252 186 363 minecraft:mushroom_stem
setblock 253 186 322 minecraft:red_mushroom_block
fill 253 186 363 253 188 363 minecraft:moss_block
setblock 261 186 323 minecraft:red_mushroom_block
fill 265 186 323 265 187 323 minecraft:moss_block
setblock 267 186 323 minecraft:mushroom_stem
fill 267 186 324 267 189 324 minecraft:moss_block
setblock 267 186 363 minecraft:mushroom_stem
fill 268 186 323 268 189 323 minecraft:moss_block
fill 268 186 341 268 189 341 minecraft:dirt
fill 268 186 363 271 186 363 minecraft:moss_block
fill 269 186 343 269 189 343 minecraft:dirt
fill 270 186 339 271 189 339 minecraft:dirt
setblock 271 186 324 minecraft:mushroom_stem
setblock 272 186 323 minecraft:mushroom_stem
fill 272 186 324 272 187 324 minecraft:moss_block
fill 272 186 340 272 189 340 minecraft:dirt
fill 273 186 323 273 189 323 minecraft:moss_block
setblock 273 186 331 minecraft:moss_block
setblock 273 186 332 minecraft:mushroom_stem
fill 273 186 333 273 187 333 minecraft:moss_block
setblock 273 186 335 minecraft:moss_block
setblock 274 186 331 minecraft:mushroom_stem
fill 274 186 332 274 189 332 minecraft:moss_block
setblock 274 186 336 minecraft:mushroom_stem
setblock 275 186 326 minecraft:moss_block
setblock 275 186 330 minecraft:mushroom_stem
fill 275 186 331 275 189 331 minecraft:moss_block
setblock 275 186 335 minecraft:mushroom_stem
fill 275 186 336 275 189 336 minecraft:moss_block
setblock 276 186 324 minecraft:mushroom_stem
fill 276 186 325 276 189 325 minecraft:moss_block
setblock 276 186 329 minecraft:mushroom_stem
fill 276 186 330 276 189 330 minecraft:moss_block
setblock 276 186 334 minecraft:mushroom_stem
fill 276 186 335 276 189 335 minecraft:moss_block
setblock 276 186 339 minecraft:mushroom_stem
setblock 276 186 354 minecraft:mushroom_stem
fill 276 186 355 276 189 355 minecraft:moss_block
fill 276 186 357 276 187 357 minecraft:moss_block
setblock 235 187 323 minecraft:red_mushroom_block
setblock 236 187 323 minecraft:mushroom_stem
fill 236 187 324 236 187 327 minecraft:moss_block
setblock 236 187 328 minecraft:mushroom_stem
fill 236 187 329 236 188 329 minecraft:moss_block
setblock 236 187 333 minecraft:mushroom_stem
fill 236 187 334 236 190 334 minecraft:moss_block
fill 236 187 340 236 188 340 minecraft:red_mushroom_block
setblock 236 187 353 minecraft:mushroom_stem
fill 236 187 354 237 188 354 minecraft:moss_block
setblock 236 187 357 minecraft:moss_block
setblock 236 187 358 minecraft:mushroom_stem
fill 236 187 359 237 189 359 minecraft:moss_block
setblock 236 187 362 minecraft:moss_block
setblock 236 187 363 minecraft:mushroom_stem
setblock 237 187 356 minecraft:moss_block
setblock 237 187 357 minecraft:mushroom_stem
fill 237 187 358 237 190 358 minecraft:moss_block
fill 237 187 363 240 187 363 minecraft:moss_block
setblock 241 187 362 minecraft:moss_block
setblock 241 187 363 minecraft:mushroom_stem
fill 242 187 323 242 190 323 minecraft:moss_block
setblock 242 187 362 minecraft:mushroom_stem
fill 242 187 363 242 190 363 minecraft:moss_block
setblock 243 187 361 minecraft:mushroom_stem
fill 243 187 362 243 190 362 minecraft:moss_block
fill 244 187 361 247 187 361 minecraft:moss_block
fill 245 187 360 248 187 360 minecraft:moss_block
setblock 246 187 323 minecraft:mushroom_stem
setblock 246 187 363 minecraft:mushroom_stem
fill 247 187 323 247 190 323 minecraft:moss_block
setblock 247 187 362 minecraft:mushroom_stem
fill 247 187 363 247 190 363 minecraft:moss_block
setblock 248 187 361 minecraft:mushroom_stem
fill 248 187 362 248 190 362 minecraft:moss_block
setblock 249 187 360 minecraft:mushroom_stem
fill 249 187 361 249 190 361 minecraft:moss_block
setblock 251 187 363 minecraft:mushroom_stem
setblock 252 187 362 minecraft:mushroom_stem
fill 252 187 363 252 190 363 minecraft:moss_block
fill 253 187 322 253 224 322 minecraft:green_terracotta
setblock 255 187 323 minecraft:red_mushroom_block
setblock 257 187 363 minecraft:red_mushroom_block
setblock 266 187 323 minecraft:mushroom_stem
setblock 266 187 363 minecraft:mushroom_stem
fill 267 187 323 267 190 323 minecraft:moss_block
fill 267 187 363 270 187 363 minecraft:moss_block
fill 268 187 340 268 189 340 minecraft:dirt
fill 268 187 342 268 189 342 minecraft:dirt
fill 269 187 339 269 189 339 minecraft:dirt
setblock 270 187 324 minecraft:mushroom_stem
fill 270 187 344 271 189 344 minecraft:dirt
setblock 271 187 323 minecraft:mushroom_stem
fill 271 187 324 271 188 324 minecraft:moss_block
setblock 271 187 363 minecraft:mushroom_stem
fill 272 187 323 272 190 323 minecraft:moss_block
fill 272 187 339 272 189 339 minecraft:dirt
fill 272 187 343 272 189 343 minecraft:dirt
fill 272 187 363 272 190 363 minecraft:moss_block
setblock 273 187 331 minecraft:mushroom_stem
setblock 273 187 332 minecraft:moss_block
fill 273 187 340 273 189 342 minecraft:dirt
setblock 274 187 330 minecraft:mushroom_stem
fill 274 187 331 274 188 331 minecraft:moss_block
setblock 274 187 335 minecraft:mushroom_stem
fill 274 187 336 274 188 336 minecraft:moss_block
setblock 275 187 329 minecraft:mushroom_stem
fill 275 187 330 275 189 330 minecraft:moss_block
setblock 275 187 334 minecraft:mushroom_stem
fill 275 187 335 275 190 335 minecraft:moss_block
setblock 275 187 338 minecraft:moss_block
setblock 276 187 323 minecraft:mushroom_stem
fill 276 187 324 276 188 324 minecraft:moss_block
setblock 276 187 328 minecraft:mushroom_stem
fill 276 187 329 276 190 329 minecraft:moss_block
setblock 276 187 333 minecraft:mushroom_stem
fill 276 187 334 276 190 334 minecraft:moss_block
setblock 276 187 338 minecraft:mushroom_stem
fill 276 187 339 276 190 339 minecraft:moss_block
setblock 276 187 346 minecraft:red_mushroom_block
setblock 276 187 353 minecraft:mushroom_stem
fill 276 187 354 276 188 354 minecraft:moss_block
setblock 276 187 358 minecraft:mushroom_stem
fill 276 187 359 276 190 359 minecraft:moss_block
setblock 276 187 363 minecraft:red_mushroom_block
fill 235 188 323 235 224 323 minecraft:green_terracotta
setblock 236 188 327 minecraft:mushroom_stem
setblock 236 188 328 minecraft:moss_block
setblock 236 188 332 minecraft:mushroom_stem
fill 236 188 333 236 190 333 minecraft:moss_block
setblock 236 188 346 minecraft:red_mushroom_block
setblock 236 188 352 minecraft:mushroom_stem
fill 236 188 353 236 190 353 minecraft:moss_block
setblock 236 188 357 minecraft:mushroom_stem
fill 236 188 358 236 191 358 minecraft:moss_block
setblock 236 188 362 minecraft:mushroom_stem
fill 236 188 363 239 188 363 minecraft:moss_block
setblock 237 188 356 minecraft:mushroom_stem
fill 237 188 357 237 191 357 minecraft:moss_block
setblock 237 188 360 minecraft:moss_block
fill 239 188 362 240 188 362 minecraft:moss_block
setblock 240 188 363 minecraft:mushroom_stem
fill 241 188 323 241 190 323 minecraft:moss_block
setblock 241 188 362 minecraft:mushroom_stem
fill 241 188 363 241 191 363 minecraft:moss_block
setblock 242 188 361 minecraft:mushroom_stem
fill 242 188 362 242 191 362 minecraft:moss_block
fill 243 188 361 246 188 361 minecraft:moss_block
fill 244 188 360 247 188 360 minecraft:moss_block
setblock 245 188 323 minecraft:mushroom_stem
setblock 245 188 363 minecraft:mushroom_stem
fill 246 188 323 246 191 323 minecraft:moss_block
setblock 246 188 362 minecraft:mushroom_stem
fill 246 188 363 246 191 363 minecraft:moss_block
setblock 247 188 361 minecraft:mushroom_stem
fill 247 188 362 247 191 362 minecraft:moss_block
setblock 248 188 360 minecraft:mushroom_stem
fill 248 188 361 248 191 361 minecraft:moss_block
fill 249 188 360 249 189 360 minecraft:moss_block
setblock 250 188 363 minecraft:mushroom_stem
setblock 251 188 362 minecraft:mushroom_stem
fill 251 188 363 251 191 363 minecraft:moss_block
setblock 263 188 363 minecraft:red_mushroom_block
setblock 264 188 323 minecraft:moss_block
setblock 265 188 323 minecraft:mushroom_stem
setblock 265 188 363 minecraft:mushroom_stem
fill 266 188 323 266 189 324 minecraft:moss_block
fill 266 188 363 269 188 363 minecraft:moss_block
fill 268 188 339 268 189 339 minecraft:dirt
fill 268 188 343 268 189 343 minecraft:dirt
setblock 269 188 324 minecraft:mushroom_stem
fill 269 188 344 269 189 344 minecraft:dirt
setblock 270 188 323 minecraft:mushroom_stem
fill 270 188 324 270 189 324 minecraft:moss_block
fill 270 188 338 271 189 338 minecraft:dirt
setblock 270 188 363 minecraft:mushroom_stem
fill 271 188 323 271 191 323 minecraft:moss_block
fill 271 188 363 271 191 363 minecraft:moss_block
fill 272 188 344 272 189 344 minecraft:dirt
fill 273 188 343 273 189 343 minecraft:dirt
setblock 274 188 330 minecraft:moss_block
setblock 274 188 334 minecraft:mushroom_stem
fill 274 188 335 274 189 335 minecraft:moss_block
setblock 275 188 323 minecraft:mushroom_stem
setblock 275 188 328 minecraft:mushroom_stem
fill 275 188 329 275 189 329 minecraft:moss_block
setblock 275 188 333 minecraft:mushroom_stem
fill 275 188 334 275 190 334 minecraft:moss_block
setblock 275 188 338 minecraft:mushroom_stem
setblock 276 188 323 minecraft:moss_block
setblock 276 188 327 minecraft:mushroom_stem
fill 276 188 328 276 190 328 minecraft:moss_block
setblock 276 188 332 minecraft:mushroom_stem
fill 276 188 333 276 191 333 minecraft:moss_block
setblock 276 188 337 minecraft:mushroom_stem
fill 276 188 338 276 191 338 minecraft:moss_block
setblock 276 188 340 minecraft:red_mushroom_block
setblock 276 188 357 minecraft:mushroom_stem
fill 276 188 358 276 191 358 minecraft:moss_block
fill 276 188 360 276 189 360 minecraft:moss_block
setblock 235 189 336 minecraft:shroomlight
setblock 236 189 327 minecraft:red_mushroom_block
setblock 236 189 331 minecraft:mushroom_stem
setblock 236 189 332 minecraft:moss_block
setblock 236 189 336 minecraft:mushroom_stem
setblock 236 189 352 minecraft:moss_block
fill 236 189 354 236 189 355 minecraft:moss_block
setblock 236 189 356 minecraft:mushroom_stem
fill 236 189 357 236 192 357 minecraft:moss_block
setblock 236 189 361 minecraft:mushroom_stem
fill 236 189 362 236 191 363 minecraft:moss_block
setblock 237 189 355 minecraft:mushroom_stem
fill 237 189 356 237 192 356 minecraft:moss_block
setblock 237 189 360 minecraft:mushroom_stem
fill 237 189 361 237 192 361 minecraft:moss_block
fill 237 189 363 238 189 363 minecraft:moss_block
setblock 238 189 325 minecraft:light[level=15]
setblock 238 189 333 minecraft:light[level=15]
setblock 238 189 339 minecraft:light[level=12]
setblock 238 189 341 minecraft:light[level=15]
setblock 238 189 346 minecraft:light[level=12]
setblock 238 189 349 minecraft:light[level=15]
setblock 238 189 353 minecraft:light[level=12]
setblock 238 189 357 minecraft:light[level=15]
setblock 238 189 360 minecraft:light[level=12]
fill 238 189 362 239 189 362 minecraft:moss_block
setblock 239 189 363 minecraft:mushroom_stem
setblock 240 189 362 minecraft:mushroom_stem
fill 240 189 363 240 192 363 minecraft:moss_block
setblock 241 189 361 minecraft:mushroom_stem
fill 241 189 362 241 192 362 minecraft:moss_block
fill 242 189 361 245 189 361 minecraft:moss_block
fill 243 189 360 246 189 360 minecraft:moss_block
setblock 244 189 323 minecraft:mushroom_stem
setblock 244 189 363 minecraft:mushroom_stem
setblock 244 189 364 minecraft:shroomlight
fill 245 189 323 245 192 323 minecraft:moss_block
setblock 245 189 325 minecraft:light[level=12]
setblock 245 189 332 minecraft:light[level=12]
setblock 245 189 339 minecraft:light[level=12]
setblock 245 189 346 minecraft:light[level=12]
setblock 245 189 353 minecraft:light[level=12]
setblock 245 189 362 minecraft:mushroom_stem
fill 245 189 363 245 192 363 minecraft:moss_block
setblock 246 189 325 minecraft:light[level=15]
setblock 246 189 333 minecraft:light[level=15]
setblock 246 189 341 minecraft:light[level=15]
setblock 246 189 349 minecraft:light[level=15]
setblock 246 189 357 minecraft:light[level=15]
setblock 246 189 361 minecraft:mushroom_stem
fill 246 189 362 246 192 362 minecraft:moss_block
setblock 247 189 360 minecraft:mushroom_stem
fill 247 189 361 247 192 361 minecraft:moss_block
fill 248 189 360 248 190 360 minecraft:moss_block
setblock 249 189 363 minecraft:mushroom_stem
setblock 250 189 362 minecraft:mushroom_stem
fill 250 189 363 250 192 363 minecraft:moss_block
fill 251 189 362 251 190 362 minecraft:moss_block
setblock 252 189 325 minecraft:light[level=12]
setblock 252 189 332 minecraft:light[level=12]
setblock 252 189 346 minecraft:light[level=12]
setblock 252 189 353 minecraft:light[level=12]
setblock 252 189 360 minecraft:light[level=12]
setblock 254 189 325 minecraft:light[level=15]
setblock 254 189 341 minecraft:light[level=15]
setblock 254 189 349 minecraft:light[level=15]
setblock 254 189 357 minecraft:light[level=15]
setblock 259 189 325 minecraft:light[level=12]
setblock 259 189 332 minecraft:light[level=12]
setblock 259 189 339 minecraft:light[level=12]
setblock 259 189 346 minecraft:light[level=12]
setblock 259 189 353 minecraft:light[level=12]
setblock 259 189 360 minecraft:light[level=12]
setblock 262 189 325 minecraft:light[level=15]
setblock 262 189 333 minecraft:light[level=15]
setblock 262 189 341 minecraft:light[level=15]
setblock 262 189 349 minecraft:light[level=15]
setblock 262 189 357 minecraft:light[level=15]
setblock 264 189 323 minecraft:mushroom_stem
setblock 264 189 363 minecraft:mushroom_stem
fill 265 189 323 265 192 323 minecraft:moss_block
fill 265 189 363 268 189 363 minecraft:moss_block
setblock 266 189 325 minecraft:light[level=12]
setblock 266 189 332 minecraft:light[level=12]
setblock 266 189 339 minecraft:light[level=12]
setblock 266 189 346 minecraft:light[level=12]
setblock 266 189 353 minecraft:light[level=12]
setblock 266 189 360 minecraft:light[level=12]
fill 267 189 340 267 189 343 minecraft:dirt
fill 267 189 362 268 190 362 minecraft:moss_block
setblock 268 189 324 minecraft:mushroom_stem
setblock 268 189 344 minecraft:dirt
setblock 269 189 323 minecraft:mushroom_stem
fill 269 189 324 269 190 324 minecraft:moss_block
setblock 269 189 338 minecraft:dirt
setblock 269 189 363 minecraft:mushroom_stem
fill 270 189 323 270 192 323 minecraft:moss_block
setblock 270 189 325 minecraft:light[level=15]
setblock 270 189 333 minecraft:light[level=15]
setblock 270 189 349 minecraft:light[level=15]
setblock 270 189 357 minecraft:light[level=15]
fill 270 189 363 270 192 363 minecraft:moss_block
setblock 272 189 338 minecraft:dirt
setblock 273 189 325 minecraft:light[level=12]
setblock 273 189 332 minecraft:light[level=12]
setblock 273 189 339 minecraft:dirt
setblock 273 189 346 minecraft:light[level=12]
setblock 273 189 353 minecraft:light[level=12]
setblock 273 189 360 minecraft:light[level=12]
setblock 274 189 323 minecraft:mushroom_stem
setblock 274 189 333 minecraft:mushroom_stem
setblock 274 189 334 minecraft:moss_block
fill 274 189 340 274 189 342 minecraft:dirt
setblock 275 189 323 minecraft:moss_block
setblock 275 189 332 minecraft:mushroom_stem
fill 275 189 333 275 190 333 minecraft:moss_block
setblock 275 189 337 minecraft:mushroom_stem
setblock 276 189 326 minecraft:mushroom_stem
setblock 276 189 327 minecraft:moss_block
setblock 276 189 331 minecraft:mushroom_stem
fill 276 189 332 276 192 332 minecraft:moss_block
setblock 276 189 336 minecraft:mushroom_stem
fill 276 189 337 276 192 337 minecraft:moss_block
setblock 276 189 356 minecraft:mushroom_stem
fill 276 189 357 276 191 357 minecraft:moss_block
setblock 276 189 361 minecraft:mushroom_stem
fill 235 190 336 235 191 336 minecraft:green_terracotta
fill 235 190 350 235 218 355 minecraft:green_terracotta
setblock 235 190 356 minecraft:red_mushroom_block
fill 235 190 357 235 220 360 minecraft:green_terracotta
setblock 236 190 335 minecraft:mushroom_stem
setblock 236 190 354 minecraft:moss_block
setblock 236 190 355 minecraft:mushroom_stem
fill 236 190 356 236 193 356 minecraft:moss_block
setblock 236 190 359 minecraft:moss_block
setblock 236 190 360 minecraft:mushroom_stem
fill 236 190 361 236 193 361 minecraft:moss_block
setblock 237 190 323 minecraft:red_mushroom_block
setblock 237 190 355 minecraft:moss_block
setblock 237 190 359 minecraft:mushroom_stem
fill 237 190 360 237 193 360 minecraft:moss_block
fill 237 190 362 237 190 363 minecraft:moss_block
setblock 238 190 362 minecraft:moss_block
setblock 238 190 363 minecraft:mushroom_stem
setblock 239 190 362 minecraft:mushroom_stem
fill 239 190 363 239 193 363 minecraft:moss_block
setblock 240 190 361 minecraft:mushroom_stem
fill 240 190 362 240 193 362 minecraft:moss_block
fill 241 190 361 244 190 361 minecraft:moss_block
fill 242 190 360 245 190 360 minecraft:moss_block
setblock 243 190 323 minecraft:mushroom_stem
setblock 243 190 363 minecraft:mushroom_stem
fill 244 190 323 244 193 323 minecraft:moss_block
setblock 244 190 362 minecraft:mushroom_stem
fill 244 190 363 244 193 363 minecraft:moss_block
fill 244 190 364 244 225 364 minecraft:green_terracotta
setblock 245 190 361 minecraft:mushroom_stem
fill 245 190 362 245 193 362 minecraft:moss_block
setblock 246 190 360 minecraft:mushroom_stem
fill 246 190 361 246 193 361 minecraft:moss_block
fill 247 190 360 247 191 360 minecraft:moss_block
setblock 248 190 363 minecraft:mushroom_stem
setblock 249 190 362 minecraft:mushroom_stem
fill 249 190 363 249 193 363 minecraft:moss_block
fill 250 190 362 250 191 362 minecraft:moss_block
setblock 262 190 323 minecraft:red_mushroom_block
setblock 263 190 323 minecraft:mushroom_stem
setblock 263 190 363 minecraft:mushroom_stem
fill 264 190 323 264 193 323 minecraft:moss_block
fill 264 190 363 267 190 363 minecraft:moss_block
fill 266 190 323 266 191 323 minecraft:moss_block
fill 266 190 362 266 192 362 minecraft:moss_block
setblock 267 190 324 minecraft:mushroom_stem
setblock 268 190 323 minecraft:mushroom_stem
setblock 268 190 324 minecraft:moss_block
setblock 268 190 363 minecraft:mushroom_stem
fill 269 190 323 269 193 323 minecraft:moss_block
fill 269 190 363 269 193 363 minecraft:moss_block
fill 270 190 341 270 192 341 minecraft:mushroom_stem
setblock 273 190 323 minecraft:mushroom_stem
setblock 275 190 331 minecraft:mushroom_stem
setblock 275 190 332 minecraft:moss_block
setblock 275 190 336 minecraft:mushroom_stem
setblock 275 190 337 minecraft:moss_block
setblock 275 190 363 minecraft:red_mushroom_block
setblock 276 190 330 minecraft:mushroom_stem
fill 276 190 331 276 191 331 minecraft:moss_block
setblock 276 190 335 minecraft:mushroom_stem
fill 276 190 336 276 193 336 minecraft:moss_block
setblock 276 190 353 minecraft:red_mushroom_block
setblock 276 190 356 minecraft:moss_block
setblock 276 190 360 minecraft:mushroom_stem
fill 276 190 361 276 193 361 minecraft:moss_block
setblock 277 190 354 minecraft:red_mushroom_block
fill 235 191 356 235 228 356 minecraft:green_terracotta
setblock 236 191 339 minecraft:red_mushroom_block
setblock 236 191 354 minecraft:mushroom_stem
fill 236 191 355 236 194 355 minecraft:moss_block
setblock 236 191 359 minecraft:mushroom_stem
fill 236 191 360 236 194 360 minecraft:moss_block
setblock 237 191 358 minecraft:mushroom_stem
fill 237 191 359 237 194 359 minecraft:moss_block
setblock 237 191 362 minecraft:moss_block
setblock 237 191 363 minecraft:mushroom_stem
setblock 238 191 362 minecraft:mushroom_stem
fill 238 191 363 238 194 363 minecraft:moss_block
fill 239 191 362 239 194 362 minecraft:moss_block
fill 240 191 361 243 191 361 minecraft:moss_block
setblock 242 191 323 minecraft:mushroom_stem
fill 242 191 360 244 191 360 minecraft:moss_block
setblock 242 191 363 minecraft:mushroom_stem
fill 243 191 323 243 194 323 minecraft:moss_block
setblock 243 191 362 minecraft:mushroom_stem
fill 243 191 363 243 194 363 minecraft:moss_block
setblock 244 191 361 minecraft:mushroom_stem
fill 244 191 362 244 194 362 minecraft:moss_block
setblock 245 191 360 minecraft:mushroom_stem
fill 245 191 361 245 194 361 minecraft:moss_block
fill 246 191 360 246 192 360 minecraft:moss_block
setblock 247 191 363 minecraft:mushroom_stem
setblock 248 191 362 minecraft:mushroom_stem
fill 248 191 363 248 194 363 minecraft:moss_block
setblock 249 191 361 minecraft:mushroom_stem
fill 249 191 362 249 193 362 minecraft:moss_block
setblock 256 191 323 minecraft:red_mushroom_block
setblock 256 191 363 minecraft:red_mushroom_block
setblock 262 191 363 minecraft:mushroom_stem
fill 263 191 323 263 194 323 minecraft:moss_block
fill 263 191 363 266 191 363 minecraft:moss_block
fill 265 191 362 265 193 362 minecraft:moss_block
setblock 267 191 323 minecraft:mushroom_stem
setblock 267 191 362 minecraft:moss_block
setblock 267 191 363 minecraft:mushroom_stem
fill 268 191 323 268 194 323 minecraft:moss_block
fill 268 191 363 268 194 363 minecraft:moss_block
setblock 272 191 323 minecraft:mushroom_stem
setblock 272 191 363 minecraft:mushroom_stem
setblock 275 191 323 minecraft:red_mushroom_block
setblock 276 191 330 minecraft:moss_block
setblock 276 191 334 minecraft:mushroom_stem
fill 276 191 335 276 192 335 minecraft:moss_block
setblock 276 191 347 minecraft:red_mushroom_block
setblock 276 191 359 minecraft:mushroom_stem
fill 276 191 360 276 194 360 minecraft:moss_block
fill 276 191 362 276 192 362 minecraft:moss_block
setblock 277 191 349 minecraft:red_mushroom_block
fill 277 191 354 277 228 354 minecraft:green_terracotta
setblock 235 192 336 minecraft:red_mushroom_block
setblock 236 192 326 minecraft:red_mushroom_block
setblock 236 192 345 minecraft:red_mushroom_block
setblock 236 192 358 minecraft:mushroom_stem
fill 236 192 359 236 195 359 minecraft:moss_block
setblock 236 192 362 minecraft:moss_block
setblock 236 192 363 minecraft:mushroom_stem
setblock 237 192 357 minecraft:mushroom_stem
fill 237 192 358 237 195 358 minecraft:moss_block
setblock 237 192 362 minecraft:mushroom_stem
fill 237 192 363 237 195 363 minecraft:moss_block
fill 238 192 362 238 195 362 minecraft:moss_block
fill 239 192 361 242 192 361 minecraft:moss_block
setblock 241 192 323 minecraft:mushroom_stem
setblock 241 192 363 minecraft:mushroom_stem
fill 242 192 323 242 195 323 minecraft:moss_block
fill 242 192 360 243 192 360 minecraft:moss_block
setblock 242 192 362 minecraft:mushroom_stem
fill 242 192 363 242 195 363 minecraft:moss_block
setblock 243 192 361 minecraft:mushroom_stem
fill 243 192 362 243 195 362 minecraft:moss_block
setblock 244 192 360 minecraft:mushroom_stem
fill 244 192 361 244 195 361 minecraft:moss_block
fill 245 192 360 245 193 360 minecraft:moss_block
setblock 246 192 323 minecraft:mushroom_stem
setblock 246 192 363 minecraft:mushroom_stem
setblock 247 192 362 minecraft:mushroom_stem
fill 247 192 363 247 195 363 minecraft:moss_block
setblock 248 192 361 minecraft:mushroom_stem
fill 248 192 362 248 195 362 minecraft:moss_block
setblock 250 192 323 minecraft:red_mushroom_block
setblock 251 192 363 minecraft:mushroom_stem
fill 262 192 363 265 192 363 minecraft:moss_block
setblock 266 192 323 minecraft:mushroom_stem
setblock 266 192 363 minecraft:mushroom_stem
fill 267 192 323 267 195 323 minecraft:moss_block
setblock 267 192 362 minecraft:mushroom_stem
fill 267 192 363 267 195 363 minecraft:moss_block
setblock 271 192 323 minecraft:mushroom_stem
setblock 271 192 363 minecraft:mushroom_stem
setblock 272 192 323 minecraft:moss_block
setblock 276 192 333 minecraft:mushroom_stem
setblock 276 192 334 minecraft:moss_block
setblock 276 192 338 minecraft:mushroom_stem
fill 276 192 341 277 192 341 minecraft:red_mushroom_block
setblock 276 192 358 minecraft:mushroom_stem
fill 276 192 359 276 195 359 minecraft:moss_block
setblock 276 192 363 minecraft:mushroom_stem
fill 277 192 349 277 226 349 minecraft:green_terracotta
fill 235 193 336 235 228 336 minecraft:green_terracotta
setblock 236 193 332 minecraft:red_mushroom_block
setblock 236 193 351 minecraft:red_mushroom_block
setblock 236 193 357 minecraft:mushroom_stem
fill 236 193 358 236 196 358 minecraft:moss_block
setblock 236 193 362 minecraft:mushroom_stem
fill 236 193 363 236 196 363 minecraft:moss_block
fill 237 193 357 237 196 357 minecraft:moss_block
setblock 237 193 361 minecraft:mushroom_stem
fill 237 193 362 237 196 362 minecraft:moss_block
fill 238 193 323 238 194 323 minecraft:red_mushroom_block
fill 239 193 361 241 193 361 minecraft:moss_block
setblock 240 193 363 minecraft:mushroom_stem
fill 241 193 323 241 196 323 minecraft:moss_block
setblock 241 193 362 minecraft:mushroom_stem
fill 241 193 363 241 196 363 minecraft:moss_block
setblock 242 193 360 minecraft:moss_block
setblock 242 193 361 minecraft:mushroom_stem
fill 242 193 362 242 196 362 minecraft:moss_block
setblock 243 193 360 minecraft:mushroom_stem
fill 243 193 361 243 196 361 minecraft:moss_block
fill 244 193 360 244 194 360 minecraft:moss_block
setblock 245 193 323 minecraft:mushroom_stem
setblock 245 193 363 minecraft:mushroom_stem
setblock 246 193 362 minecraft:mushroom_stem
fill 246 193 363 246 196 363 minecraft:moss_block
setblock 247 193 361 minecraft:mushroom_stem
fill 247 193 362 247 196 362 minecraft:moss_block
setblock 250 193 363 minecraft:mushroom_stem
setblock 254 193 322 minecraft:shroomlight
fill 255 193 322 255 228 322 minecraft:green_terracotta
fill 261 193 363 264 193 363 minecraft:moss_block
fill 262 193 323 262 195 323 minecraft:moss_block
fill 264 193 362 264 194 362 minecraft:moss_block
setblock 265 193 323 minecraft:mushroom_stem
setblock 265 193 363 minecraft:mushroom_stem
fill 266 193 323 266 196 323 minecraft:moss_block
setblock 266 193 362 minecraft:mushroom_stem
fill 266 193 363 266 196 363 minecraft:moss_block
fill 269 193 340 271 195 342 minecraft:red_mushroom_block
setblock 270 193 323 minecraft:mushroom_stem
fill 270 193 343 271 195 343 minecraft:red_mushroom_block
setblock 270 193 363 minecraft:mushroom_stem
fill 271 193 323 271 196 323 minecraft:moss_block
fill 271 193 363 271 196 363 minecraft:moss_block
fill 272 193 341 272 195 342 minecraft:red_mushroom_block
setblock 276 193 335 minecraft:red_mushroom_block
setblock 276 193 354 minecraft:red_mushroom_block
setblock 276 193 358 minecraft:moss_block
setblock 276 193 362 minecraft:mushroom_stem
fill 276 193 363 276 196 363 minecraft:moss_block
setblock 277 193 325 minecraft:red_mushroom_block
fill 277 193 327 277 207 327 minecraft:green_terracotta
setblock 277 193 328 minecraft:red_mushroom_block
fill 277 193 341 277 214 341 minecraft:green_terracotta
setblock 236 194 338 minecraft:red_mushroom_block
setblock 236 194 356 minecraft:mushroom_stem
fill 236 194 357 236 197 357 minecraft:moss_block
setblock 236 194 361 minecraft:mushroom_stem
fill 236 194 362 236 197 362 minecraft:moss_block
setblock 237 194 360 minecraft:mushroom_stem
fill 237 194 361 237 197 361 minecraft:moss_block
fill 238 194 360 238 197 360 minecraft:moss_block
fill 239 194 361 240 194 361 minecraft:moss_block
setblock 239 194 363 minecraft:mushroom_stem
fill 240 194 323 240 197 323 minecraft:moss_block
setblock 240 194 362 minecraft:mushroom_stem
fill 240 194 363 240 197 363 minecraft:moss_block
setblock 241 194 361 minecraft:mushroom_stem
fill 241 194 362 241 197 362 minecraft:moss_block
setblock 242 194 360 minecraft:mushroom_stem
fill 242 194 361 242 197 361 minecraft:moss_block
fill 243 194 360 243 196 360 minecraft:moss_block
setblock 244 194 323 minecraft:mushroom_stem
setblock 244 194 363 minecraft:mushroom_stem
fill 245 194 323 245 197 323 minecraft:moss_block
setblock 245 194 362 minecraft:mushroom_stem
fill 245 194 363 245 197 363 minecraft:moss_block
setblock 246 194 361 minecraft:mushroom_stem
fill 246 194 362 246 197 362 minecraft:moss_block
setblock 247 194 361 minecraft:moss_block
setblock 249 194 363 minecraft:mushroom_stem
setblock 250 194 363 minecraft:moss_block
fill 254 194 322 254 228 322 minecraft:green_terracotta
setblock 255 194 363 minecraft:red_mushroom_block
setblock 257 194 323 minecraft:red_mushroom_block
fill 260 194 363 263 194 363 minecraft:moss_block
fill 261 194 323 261 196 323 minecraft:moss_block
setblock 264 194 323 minecraft:mushroom_stem
setblock 264 194 363 minecraft:mushroom_stem
fill 265 194 323 265 197 323 minecraft:moss_block
setblock 265 194 362 minecraft:mushroom_stem
fill 265 194 363 265 197 363 minecraft:moss_block
fill 266 194 362 266 197 362 minecraft:moss_block
setblock 268 194 341 minecraft:red_mushroom_block
setblock 269 194 323 minecraft:mushroom_stem
setblock 269 194 343 minecraft:red_mushroom_block
setblock 269 194 363 minecraft:mushroom_stem
fill 270 194 323 270 197 323 minecraft:moss_block
fill 270 194 339 271 194 339 minecraft:red_mushroom_block
fill 270 194 363 270 197 363 minecraft:moss_block
setblock 272 194 340 minecraft:red_mushroom_block
setblock 274 194 363 minecraft:mushroom_stem
fill 275 194 363 275 197 363 minecraft:moss_block
setblock 276 194 323 minecraft:red_mushroom_block
setblock 276 194 329 minecraft:red_mushroom_block
setblock 276 194 348 minecraft:red_mushroom_block
setblock 276 194 361 minecraft:mushroom_stem
fill 276 194 362 276 197 362 minecraft:moss_block
fill 277 194 325 277 228 325 minecraft:green_terracotta
fill 277 194 328 277 224 328 minecraft:green_terracotta
setblock 236 195 344 minecraft:red_mushroom_block
fill 236 195 356 236 198 356 minecraft:moss_block
setblock 236 195 360 minecraft:mushroom_stem
fill 236 195 361 236 198 361 minecraft:moss_block
setblock 237 195 359 minecraft:mushroom_stem
fill 237 195 360 237 198 360 minecraft:moss_block
setblock 238 195 325 minecraft:light[level=12]
setblock 238 195 332 minecraft:light[level=12]
setblock 238 195 339 minecraft:light[level=12]
setblock 238 195 346 minecraft:light[level=12]
setblock 238 195 353 minecraft:light[level=12]
fill 238 195 359 238 198 359 minecraft:moss_block
fill 238 195 361 239 195 361 minecraft:moss_block
setblock 238 195 363 minecraft:mushroom_stem
fill 239 195 323 239 198 323 minecraft:moss_block
setblock 239 195 362 minecraft:mushroom_stem
fill 239 195 363 239 198 363 minecraft:moss_block
setblock 240 195 361 minecraft:mushroom_stem
fill 240 195 362 240 198 362 minecraft:moss_block
fill 241 195 361 241 198 361 minecraft:moss_block
fill 241 195 364 241 226 364 minecraft:green_terracotta
fill 242 195 360 242 198 360 minecraft:moss_block
setblock 242 195 364 minecraft:shroomlight
setblock 243 195 323 minecraft:mushroom_stem
setblock 243 195 363 minecraft:mushroom_stem
fill 244 195 323 244 198 323 minecraft:moss_block
setblock 244 195 362 minecraft:mushroom_stem
fill 244 195 363 244 198 363 minecraft:moss_block
setblock 245 195 325 minecraft:light[level=12]
setblock 245 195 332 minecraft:light[level=12]
setblock 245 195 339 minecraft:light[level=12]
setblock 245 195 346 minecraft:light[level=12]
setblock 245 195 353 minecraft:light[level=12]
setblock 245 195 360 minecraft:light[level=12]
setblock 245 195 361 minecraft:mushroom_stem
fill 245 195 362 245 198 362 minecraft:moss_block
fill 246 195 361 246 196 361 minecraft:moss_block
setblock 248 195 363 minecraft:mushroom_stem
fill 249 195 363 249 198 363 minecraft:moss_block
setblock 251 195 323 minecraft:red_mushroom_block
setblock 252 195 325 minecraft:light[level=12]
setblock 252 195 332 minecraft:light[level=12]
setblock 252 195 346 minecraft:light[level=12]
setblock 252 195 353 minecraft:light[level=12]
setblock 252 195 360 minecraft:light[level=12]
setblock 259 195 325 minecraft:light[level=12]
setblock 259 195 332 minecraft:light[level=12]
setblock 259 195 339 minecraft:light[level=12]
setblock 259 195 346 minecraft:light[level=12]
setblock 259 195 353 minecraft:light[level=12]
setblock 259 195 360 minecraft:light[level=12]
fill 259 195 363 262 195 363 minecraft:moss_block
fill 260 195 323 260 197 323 minecraft:moss_block
fill 262 195 362 263 195 362 minecraft:moss_block
setblock 263 195 323 minecraft:mushroom_stem
setblock 263 195 363 minecraft:mushroom_stem
fill 264 195 323 264 197 324 minecraft:moss_block
setblock 264 195 362 minecraft:mushroom_stem
fill 264 195 363 264 198 363 minecraft:moss_block
fill 265 195 324 266 195 324 minecraft:moss_block
fill 265 195 362 265 198 362 minecraft:moss_block
setblock 266 195 325 minecraft:light[level=12]
setblock 266 195 332 minecraft:light[level=12]
setblock 266 195 339 minecraft:light[level=12]
setblock 266 195 346 minecraft:light[level=12]
setblock 266 195 353 minecraft:light[level=12]
setblock 266 195 360 minecraft:light[level=12]
setblock 268 195 323 minecraft:mushroom_stem
setblock 268 195 363 minecraft:mushroom_stem
fill 269 195 323 269 198 323 minecraft:moss_block
fill 269 195 363 269 198 363 minecraft:moss_block
setblock 272 195 323 minecraft:moss_block
setblock 272 195 363 minecraft:moss_block
setblock 273 195 325 minecraft:light[level=12]
setblock 273 195 332 minecraft:light[level=12]
setblock 273 195 339 minecraft:light[level=12]
setblock 273 195 346 minecraft:light[level=12]
setblock 273 195 353 minecraft:light[level=12]
setblock 273 195 360 minecraft:light[level=12]
setblock 273 195 363 minecraft:mushroom_stem
fill 274 195 363 274 198 363 minecraft:moss_block
fill 275 195 323 276 196 323 minecraft:moss_block
setblock 276 195 342 minecraft:red_mushroom_block
fill 276 195 358 276 196 358 minecraft:moss_block
setblock 276 195 360 minecraft:mushroom_stem
fill 276 195 361 276 198 361 minecraft:moss_block
setblock 236 196 323 minecraft:moss_block
setblock 236 196 325 minecraft:red_mushroom_block
setblock 236 196 350 minecraft:red_mushroom_block
fill 236 196 355 236 199 355 minecraft:moss_block
setblock 236 196 359 minecraft:mushroom_stem
fill 236 196 360 236 199 360 minecraft:moss_block
setblock 237 196 323 minecraft:mushroom_stem
setblock 237 196 358 minecraft:mushroom_stem
fill 237 196 359 237 199 359 minecraft:moss_block
setblock 237 196 363 minecraft:mushroom_stem
fill 238 196 323 238 199 323 minecraft:moss_block
setblock 238 196 361 minecraft:moss_block
setblock 238 196 362 minecraft:mushroom_stem
fill 238 196 363 238 199 363 minecraft:moss_block
setblock 239 196 361 minecraft:mushroom_stem
fill 239 196 362 239 199 362 minecraft:moss_block
fill 240 196 361 240 199 361 minecraft:moss_block
fill 241 196 360 241 199 360 minecraft:moss_block
setblock 242 196 323 minecraft:mushroom_stem
setblock 242 196 363 minecraft:mushroom_stem
fill 242 196 364 242 224 364 minecraft:green_terracotta
fill 243 196 323 243 199 323 minecraft:moss_block
setblock 243 196 362 minecraft:mushroom_stem
fill 243 196 363 243 199 363 minecraft:moss_block
setblock 244 196 361 minecraft:mushroom_stem
fill 244 196 362 244 199 362 minecraft:moss_block
fill 245 196 361 245 199 361 minecraft:moss_block
setblock 247 196 363 minecraft:mushroom_stem
setblock 248 196 362 minecraft:mushroom_stem
fill 248 196 363 248 199 363 minecraft:moss_block
fill 258 196 363 261 196 363 minecraft:moss_block
fill 259 196 323 259 198 323 minecraft:moss_block
fill 261 196 362 262 196 362 minecraft:moss_block
setblock 262 196 323 minecraft:mushroom_stem
fill 262 196 324 263 198 324 minecraft:moss_block
setblock 262 196 363 minecraft:mushroom_stem
fill 263 196 323 263 199 323 minecraft:moss_block
setblock 263 196 362 minecraft:mushroom_stem
fill 263 196 363 263 199 363 minecraft:moss_block
fill 264 196 362 264 199 362 minecraft:moss_block
setblock 265 196 324 minecraft:moss_block
setblock 266 196 324 minecraft:mushroom_stem
setblock 267 196 323 minecraft:mushroom_stem
fill 267 196 324 267 199 324 minecraft:moss_block
setblock 267 196 363 minecraft:mushroom_stem
fill 268 196 323 268 199 323 minecraft:moss_block
fill 268 196 363 268 199 363 minecraft:moss_block
fill 271 196 335 271 204 335 minecraft:dirt
setblock 272 196 323 minecraft:mushroom_stem
setblock 272 196 363 minecraft:mushroom_stem
fill 273 196 323 274 198 323 minecraft:moss_block
fill 273 196 363 273 199 363 minecraft:moss_block
setblock 276 196 324 minecraft:mushroom_stem
setblock 276 196 336 minecraft:red_mushroom_block
setblock 276 196 355 minecraft:red_mushroom_block
setblock 276 196 359 minecraft:mushroom_stem
fill 276 196 360 276 199 360 minecraft:moss_block
fill 235 197 339 235 224 339 minecraft:green_terracotta
setblock 235 197 340 minecraft:shroomlight
fill 235 197 341 235 224 341 minecraft:green_terracotta
setblock 236 197 323 minecraft:mushroom_stem
fill 236 197 324 236 200 324 minecraft:moss_block
setblock 236 197 331 minecraft:red_mushroom_block
fill 236 197 337 236 198 337 minecraft:red_mushroom_block
fill 236 197 340 236 197 342 minecraft:moss_block
setblock 236 197 343 minecraft:mushroom_stem
setblock 236 197 358 minecraft:mushroom_stem
fill 236 197 359 236 200 359 minecraft:moss_block
setblock 236 197 363 minecraft:mushroom_stem
fill 237 197 323 237 200 323 minecraft:moss_block
setblock 237 197 356 minecraft:moss_block
setblock 237 197 357 minecraft:mushroom_stem
fill 237 197 358 238 199 358 minecraft:moss_block
setblock 237 197 362 minecraft:mushroom_stem
fill 237 197 363 237 200 363 minecraft:moss_block
setblock 238 197 325 minecraft:light[level=15]
setblock 238 197 333 minecraft:light[level=15]
setblock 238 197 341 minecraft:light[level=15]
setblock 238 197 349 minecraft:light[level=15]
setblock 238 197 357 minecraft:light[level=15]
setblock 238 197 361 minecraft:mushroom_stem
fill 238 197 362 238 200 362 minecraft:moss_block
fill 239 197 361 239 200 361 minecraft:moss_block
fill 240 197 360 240 200 360 minecraft:moss_block
setblock 241 197 323 minecraft:mushroom_stem
setblock 241 197 363 minecraft:mushroom_stem
fill 242 197 323 242 200 323 minecraft:moss_block
setblock 242 197 362 minecraft:mushroom_stem
fill 242 197 363 242 200 363 minecraft:moss_block
setblock 243 197 361 minecraft:mushroom_stem
fill 243 197 362 243 200 362 minecraft:moss_block
fill 244 197 361 244 200 361 minecraft:moss_block
setblock 246 197 323 minecraft:mushroom_stem
setblock 246 197 325 minecraft:light[level=15]
setblock 246 197 333 minecraft:light[level=15]
setblock 246 197 341 minecraft:light[level=15]
setblock 246 197 349 minecraft:light[level=15]
setblock 246 197 357 minecraft:light[level=15]
setblock 246 197 363 minecraft:mushroom_stem
setblock 247 197 362 minecraft:mushroom_stem
fill 247 197 363 247 200 363 minecraft:moss_block
setblock 254 197 325 minecraft:light[level=15]
setblock 254 197 341 minecraft:light[level=15]
setblock 254 197 349 minecraft:light[level=15]
setblock 254 197 357 minecraft:light[level=15]
setblock 254 197 363 minecraft:red_mushroom_block
fill 257 197 363 260 197 363 minecraft:moss_block
fill 258 197 323 258 199 323 minecraft:moss_block
setblock 260 197 324 minecraft:mushroom_stem
fill 260 197 362 261 197 362 minecraft:moss_block
setblock 261 197 323 minecraft:mushroom_stem
fill 261 197 324 261 200 324 minecraft:moss_block
setblock 261 197 363 minecraft:mushroom_stem
fill 262 197 323 262 200 323 minecraft:moss_block
setblock 262 197 325 minecraft:light[level=15]
setblock 262 197 333 minecraft:light[level=15]
setblock 262 197 341 minecraft:light[level=15]
setblock 262 197 349 minecraft:light[level=15]
setblock 262 197 357 minecraft:light[level=15]
setblock 262 197 362 minecraft:mushroom_stem
fill 262 197 363 262 200 363 minecraft:moss_block
fill 263 197 362 263 200 362 minecraft:moss_block
setblock 265 197 322 minecraft:red_mushroom_block
setblock 265 197 324 minecraft:mushroom_stem
fill 266 197 322 266 228 322 minecraft:green_terracotta
setblock 266 197 323 minecraft:mushroom_stem
fill 266 197 324 266 200 324 minecraft:moss_block
setblock 266 197 363 minecraft:mushroom_stem
fill 267 197 323 267 200 323 minecraft:moss_block
setblock 267 197 362 minecraft:mushroom_stem
fill 267 197 363 267 200 363 minecraft:moss_block
fill 268 197 324 268 198 324 minecraft:moss_block
setblock 270 197 325 minecraft:light[level=15]
setblock 270 197 333 minecraft:light[level=15]
setblock 270 197 341 minecraft:light[level=15]
setblock 270 197 349 minecraft:light[level=15]
setblock 270 197 357 minecraft:light[level=15]
setblock 271 197 323 minecraft:mushroom_stem
setblock 271 197 363 minecraft:mushroom_stem
fill 272 197 323 272 200 323 minecraft:moss_block
fill 272 197 363 272 200 363 minecraft:moss_block
setblock 275 197 323 minecraft:moss_block
fill 275 197 361 275 198 362 minecraft:moss_block
setblock 276 197 323 minecraft:mushroom_stem
fill 276 197 324 276 198 326 minecraft:moss_block
setblock 276 197 330 minecraft:red_mushroom_block
setblock 276 197 349 minecraft:red_mushroom_block
setblock 276 197 358 minecraft:mushroom_stem
fill 276 197 359 276 200 359 minecraft:moss_block
setblock 276 197 363 minecraft:mushroom_stem
setblock 277 197 334 minecraft:shroomlight
fill 235 198 340 235 225 340 minecraft:green_terracotta
fill 236 198 323 236 201 323 minecraft:moss_block
fill 236 198 325 236 199 325 minecraft:moss_block
fill 236 198 339 236 198 341 minecraft:moss_block
setblock 236 198 342 minecraft:mushroom_stem
fill 236 198 343 236 198 346 minecraft:moss_block
setblock 236 198 347 minecraft:mushroom_stem
fill 236 198 354 236 200 354 minecraft:moss_block
setblock 236 198 357 minecraft:mushroom_stem
fill 236 198 358 236 201 358 minecraft:moss_block
setblock 236 198 362 minecraft:mushroom_stem
fill 236 198 363 236 201 363 minecraft:moss_block
setblock 237 198 341 minecraft:mushroom_stem
fill 237 198 342 237 199 344 minecraft:moss_block
setblock 237 198 356 minecraft:mushroom_stem
fill 237 198 357 237 201 357 minecraft:moss_block
setblock 237 198 361 minecraft:mushroom_stem
fill 237 198 362 237 201 362 minecraft:moss_block
setblock 238 198 360 minecraft:mushroom_stem
fill 238 198 361 238 201 361 minecraft:moss_block
setblock 239 198 324 minecraft:mushroom_stem
fill 239 198 360 239 201 360 minecraft:moss_block
setblock 240 198 323 minecraft:mushroom_stem
fill 240 198 324 242 199 324 minecraft:moss_block
setblock 240 198 363 minecraft:mushroom_stem
fill 241 198 323 241 201 323 minecraft:moss_block
setblock 241 198 362 minecraft:mushroom_stem
fill 241 198 363 241 201 363 minecraft:moss_block
setblock 242 198 361 minecraft:mushroom_stem
fill 242 198 362 242 201 362 minecraft:moss_block
fill 243 198 361 243 201 361 minecraft:moss_block
setblock 245 198 323 minecraft:mushroom_stem
setblock 245 198 363 minecraft:mushroom_stem
fill 246 198 323 246 201 323 minecraft:moss_block
setblock 246 198 362 minecraft:mushroom_stem
fill 246 198 363 246 201 363 minecraft:moss_block
fill 247 198 362 247 199 362 minecraft:moss_block
setblock 252 198 323 minecraft:red_mushroom_block
fill 254 198 364 254 228 364 minecraft:green_terracotta
setblock 255 198 364 minecraft:red_mushroom_block
fill 256 198 323 257 200 323 minecraft:moss_block
fill 256 198 363 259 198 363 minecraft:moss_block
setblock 259 198 324 minecraft:mushroom_stem
fill 259 198 362 260 198 362 minecraft:moss_block
setblock 260 198 323 minecraft:mushroom_stem
fill 260 198 324 260 201 324 minecraft:moss_block
setblock 260 198 363 minecraft:mushroom_stem
fill 261 198 323 261 201 323 minecraft:moss_block
setblock 261 198 362 minecraft:mushroom_stem
fill 261 198 363 261 201 363 minecraft:moss_block
setblock 262 198 325 minecraft:moss_block
fill 262 198 362 262 201 362 minecraft:moss_block
setblock 263 198 325 minecraft:mushroom_stem
setblock 264 198 323 minecraft:moss_block
setblock 264 198 324 minecraft:mushroom_stem
fill 264 198 325 264 201 325 minecraft:moss_block
fill 265 198 322 265 231 322 minecraft:green_terracotta
setblock 265 198 323 minecraft:mushroom_stem
fill 265 198 324 265 201 324 minecraft:moss_block
setblock 265 198 363 minecraft:mushroom_stem
fill 266 198 323 266 201 323 minecraft:moss_block
setblock 266 198 362 minecraft:mushroom_stem
fill 266 198 363 266 201 363 minecraft:moss_block
fill 267 198 362 267 201 362 minecraft:moss_block
setblock 269 198 324 minecraft:mushroom_stem
setblock 270 198 323 minecraft:mushroom_stem
fill 270 198 324 270 201 324 minecraft:moss_block
setblock 270 198 363 minecraft:mushroom_stem
fill 271 198 323 271 201 323 minecraft:moss_block
fill 271 198 363 271 201 363 minecraft:moss_block
fill 274 198 362 274 199 362 minecraft:moss_block
setblock 275 198 323 minecraft:mushroom_stem
fill 275 198 324 275 201 324 minecraft:moss_block
fill 275 198 360 275 200 360 minecraft:moss_block
setblock 275 198 363 minecraft:mushroom_stem
fill 276 198 323 276 201 323 minecraft:moss_block
setblock 276 198 327 minecraft:mushroom_stem
fill 276 198 338 276 198 341 minecraft:moss_block
setblock 276 198 342 minecraft:mushroom_stem
fill 276 198 343 276 201 343 minecraft:moss_block
setblock 276 198 357 minecraft:mushroom_stem
fill 276 198 358 276 201 358 minecraft:moss_block
setblock 276 198 362 minecraft:mushroom_stem
fill 276 198 363 276 201 363 minecraft:moss_block
fill 277 198 334 277 228 334 minecraft:green_terracotta
setblock 236 199 326 minecraft:mushroom_stem
fill 236 199 338 236 199 340 minecraft:moss_block
setblock 236 199 341 minecraft:mushroom_stem
fill 236 199 342 236 199 345 minecraft:moss_block
setblock 236 199 346 minecraft:mushroom_stem
fill 236 199 347 236 199 350 minecraft:moss_block
setblock 236 199 351 minecraft:mushroom_stem
fill 236 199 352 236 201 353 minecraft:moss_block
setblock 236 199 356 minecraft:mushroom_stem
fill 236 199 357 236 202 357 minecraft:moss_block
setblock 236 199 361 minecraft:mushroom_stem
fill 236 199 362 236 202 362 minecraft:moss_block
setblock 237 199 324 minecraft:moss_block
setblock 237 199 340 minecraft:mushroom_stem
fill 237 199 341 237 202 341 minecraft:moss_block
setblock 237 199 345 minecraft:mushroom_stem
fill 237 199 346 237 199 349 minecraft:moss_block
setblock 237 199 354 minecraft:moss_block
setblock 237 199 355 minecraft:mushroom_stem
fill 237 199 356 237 202 356 minecraft:moss_block
setblock 237 199 360 minecraft:mushroom_stem
fill 237 199 361 237 202 361 minecraft:moss_block
setblock 238 199 324 minecraft:mushroom_stem
fill 238 199 342 238 199 343 minecraft:moss_block
setblock 238 199 344 minecraft:mushroom_stem
fill 238 199 345 238 202 345 minecraft:moss_block
fill 238 199 357 238 200 357 minecraft:moss_block
setblock 238 199 359 minecraft:mushroom_stem
fill 238 199 360 238 202 360 minecraft:moss_block
setblock 239 199 323 minecraft:mushroom_stem
fill 239 199 324 239 202 324 minecraft:moss_block
setblock 239 199 363 minecraft:mushroom_stem
fill 240 199 323 240 202 323 minecraft:moss_block
setblock 240 199 362 minecraft:mushroom_stem
fill 240 199 363 240 202 363 minecraft:moss_block
setblock 241 199 361 minecraft:mushroom_stem
fill 241 199 362 241 202 362 minecraft:moss_block
setblock 242 199 360 minecraft:mushroom_stem
fill 242 199 361 242 202 361 minecraft:moss_block
setblock 243 199 324 minecraft:mushroom_stem
setblock 244 199 323 minecraft:mushroom_stem
setblock 244 199 363 minecraft:mushroom_stem
fill 245 199 323 245 202 323 minecraft:moss_block
setblock 245 199 362 minecraft:mushroom_stem
fill 245 199 363 245 202 363 minecraft:moss_block
fill 246 199 362 246 201 362 minecraft:moss_block
fill 247 199 323 247 200 323 minecraft:moss_block
setblock 249 199 363 minecraft:mushroom_stem
fill 250 199 363 250 201 363 minecraft:moss_block
setblock 254 199 323 minecraft:mushroom_stem
setblock 254 199 363 minecraft:mushroom_stem
fill 255 199 323 255 202 323 minecraft:moss_block
fill 255 199 363 258 199 363 minecraft:moss_block
setblock 255 199 364 minecraft:shroomlight
setblock 257 199 324 minecraft:moss_block
setblock 258 199 324 minecraft:mushroom_stem
fill 258 199 362 259 199 362 minecraft:moss_block
setblock 259 199 323 minecraft:mushroom_stem
fill 259 199 324 259 202 324 minecraft:moss_block
setblock 259 199 363 minecraft:mushroom_stem
fill 260 199 323 260 202 323 minecraft:moss_block
fill 260 199 325 261 199 325 minecraft:moss_block
setblock 260 199 362 minecraft:mushroom_stem
fill 260 199 363 260 202 363 minecraft:moss_block
fill 261 199 362 261 202 362 minecraft:moss_block
setblock 262 199 324 minecraft:moss_block
setblock 262 199 325 minecraft:mushroom_stem
setblock 263 199 324 minecraft:mushroom_stem
fill 263 199 325 263 202 325 minecraft:moss_block
setblock 264 199 323 minecraft:mushroom_stem
fill 264 199 324 264 202 324 minecraft:moss_block
setblock 264 199 363 minecraft:mushroom_stem
fill 265 199 323 265 202 323 minecraft:moss_block
fill 265 199 325 266 199 325 minecraft:moss_block
setblock 265 199 362 minecraft:mushroom_stem
fill 265 199 363 265 202 363 minecraft:moss_block
fill 266 199 362 266 202 362 minecraft:moss_block
setblock 268 199 324 minecraft:mushroom_stem
fill 268 199 362 268 200 362 minecraft:moss_block
setblock 269 199 323 minecraft:mushroom_stem
fill 269 199 324 269 202 324 minecraft:moss_block
setblock 269 199 363 minecraft:mushroom_stem
fill 270 199 323 270 202 323 minecraft:moss_block
fill 270 199 363 270 202 363 minecraft:moss_block
fill 271 199 324 272 199 324 minecraft:moss_block
setblock 271 199 364 minecraft:shroomlight
fill 272 199 332 272 209 332 minecraft:dirt
fill 272 199 362 273 200 362 minecraft:moss_block
setblock 273 199 323 minecraft:moss_block
setblock 273 199 324 minecraft:mushroom_stem
setblock 274 199 323 minecraft:mushroom_stem
fill 274 199 324 274 202 324 minecraft:moss_block
setblock 274 199 363 minecraft:mushroom_stem
fill 275 199 323 275 202 323 minecraft:moss_block
fill 275 199 325 276 199 325 minecraft:moss_block
setblock 275 199 361 minecraft:moss_block
setblock 275 199 362 minecraft:mushroom_stem
fill 275 199 363 275 202 363 minecraft:moss_block
fill 276 199 324 276 200 324 minecraft:moss_block
setblock 276 199 326 minecraft:mushroom_stem
fill 276 199 327 276 201 328 minecraft:moss_block
setblock 276 199 337 minecraft:red_mushroom_block
fill 276 199 338 276 199 340 minecraft:moss_block
setblock 276 199 341 minecraft:mushroom_stem
fill 276 199 342 276 202 342 minecraft:moss_block
fill 276 199 344 276 199 345 minecraft:moss_block
setblock 276 199 356 minecraft:mushroom_stem
fill 276 199 357 276 202 357 minecraft:moss_block
setblock 276 199 361 minecraft:mushroom_stem
fill 276 199 362 276 202 362 minecraft:moss_block
fill 235 200 324 235 228 325 minecraft:green_terracotta
setblock 235 200 326 minecraft:red_mushroom_block
fill 235 200 327 235 225 329 minecraft:green_terracotta
setblock 235 200 331 minecraft:red_mushroom_block
setblock 236 200 325 minecraft:mushroom_stem
fill 236 200 326 236 202 327 minecraft:moss_block
setblock 236 200 330 minecraft:red_mushroom_block
fill 236 200 337 236 200 339 minecraft:moss_block
setblock 236 200 340 minecraft:mushroom_stem
fill 236 200 341 236 200 344 minecraft:moss_block
setblock 236 200 345 minecraft:mushroom_stem
fill 236 200 346 236 200 349 minecraft:moss_block
setblock 236 200 350 minecraft:mushroom_stem
fill 236 200 351 237 202 351 minecraft:moss_block
setblock 236 200 355 minecraft:mushroom_stem
fill 236 200 356 236 203 356 minecraft:moss_block
setblock 236 200 360 minecraft:mushroom_stem
fill 236 200 361 236 203 361 minecraft:moss_block
setblock 237 200 324 minecraft:mushroom_stem
fill 237 200 325 237 203 325 minecraft:moss_block
setblock 237 200 339 minecraft:mushroom_stem
fill 237 200 340 237 203 340 minecraft:moss_block
fill 237 200 342 237 200 343 minecraft:moss_block
setblock 237 200 344 minecraft:mushroom_stem
fill 237 200 345 237 200 348 minecraft:moss_block
setblock 237 200 349 minecraft:mushroom_stem
fill 237 200 350 237 203 350 minecraft:moss_block
fill 237 200 352 237 200 353 minecraft:moss_block
setblock 237 200 354 minecraft:mushroom_stem
fill 237 200 355 237 203 355 minecraft:moss_block
setblock 237 200 358 minecraft:moss_block
setblock 237 200 359 minecraft:mushroom_stem
fill 237 200 360 237 203 360 minecraft:moss_block
setblock 238 200 323 minecraft:mushroom_stem
fill 238 200 324 238 203 324 minecraft:moss_block
fill 238 200 341 238 200 342 minecraft:moss_block
setblock 238 200 343 minecraft:mushroom_stem
fill 238 200 344 239 202 344 minecraft:moss_block
fill 238 200 346 238 200 347 minecraft:moss_block
setblock 238 200 348 minecraft:mushroom_stem
fill 238 200 349 238 203 349 minecraft:moss_block
fill 238 200 356 238 201 356 minecraft:moss_block
setblock 238 200 358 minecraft:mushroom_stem
fill 238 200 359 238 203 359 minecraft:moss_block
setblock 238 200 363 minecraft:mushroom_stem
fill 239 200 323 239 203 323 minecraft:moss_block
fill 239 200 343 239 203 343 minecraft:moss_block
fill 239 200 345 239 201 345 minecraft:moss_block
setblock 239 200 362 minecraft:mushroom_stem
fill 239 200 363 239 203 363 minecraft:moss_block
fill 240 200 324 241 200 324 minecraft:moss_block
setblock 240 200 361 minecraft:mushroom_stem
fill 240 200 362 240 203 362 minecraft:moss_block
setblock 241 200 360 minecraft:mushroom_stem
fill 241 200 361 241 203 361 minecraft:moss_block
setblock 242 200 324 minecraft:mushroom_stem
setblock 243 200 323 minecraft:mushroom_stem
fill 243 200 324 244 202 324 minecraft:moss_block
setblock 243 200 363 minecraft:mushroom_stem
fill 244 200 323 244 203 323 minecraft:moss_block
setblock 244 200 362 minecraft:mushroom_stem
fill 244 200 363 244 203 363 minecraft:moss_block
fill 245 200 362 245 202 362 minecraft:moss_block
setblock 248 200 323 minecraft:mushroom_stem
setblock 248 200 363 minecraft:mushroom_stem
fill 249 200 363 249 201 363 minecraft:moss_block
setblock 253 200 323 minecraft:mushroom_stem
setblock 253 200 363 minecraft:mushroom_stem
fill 254 200 323 254 203 323 minecraft:moss_block
fill 254 200 363 257 200 363 minecraft:moss_block
fill 255 200 364 255 228 364 minecraft:green_terracotta
setblock 256 200 324 minecraft:moss_block
setblock 257 200 324 minecraft:mushroom_stem
fill 257 200 362 258 200 362 minecraft:moss_block
setblock 258 200 323 minecraft:mushroom_stem
fill 258 200 324 258 202 325 minecraft:moss_block
setblock 258 200 363 minecraft:mushroom_stem
fill 259 200 323 259 203 323 minecraft:moss_block
fill 259 200 325 260 200 325 minecraft:moss_block
setblock 259 200 362 minecraft:mushroom_stem
fill 259 200 363 259 203 363 minecraft:moss_block
fill 260 200 362 260 203 362 minecraft:moss_block
setblock 261 200 325 minecraft:mushroom_stem
setblock 262 200 324 minecraft:mushroom_stem
fill 262 200 325 262 203 325 minecraft:moss_block
setblock 263 200 323 minecraft:mushroom_stem
fill 263 200 324 263 203 324 minecraft:moss_block
setblock 263 200 363 minecraft:mushroom_stem
fill 264 200 323 264 203 323 minecraft:moss_block
setblock 264 200 362 minecraft:mushroom_stem
fill 264 200 363 264 203 363 minecraft:moss_block
setblock 265 200 325 minecraft:moss_block
fill 265 200 362 265 202 362 minecraft:moss_block
setblock 266 200 325 minecraft:mushroom_stem
setblock 267 200 324 minecraft:mushroom_stem
fill 267 200 325 267 203 325 minecraft:moss_block
setblock 268 200 323 minecraft:mushroom_stem
fill 268 200 324 268 203 324 minecraft:moss_block
setblock 268 200 363 minecraft:mushroom_stem
fill 269 200 323 269 203 323 minecraft:moss_block
fill 269 200 363 269 203 363 minecraft:moss_block
fill 270 200 335 270 204 335 minecraft:dirt
setblock 271 200 324 minecraft:moss_block
fill 271 200 334 271 204 334 minecraft:dirt
fill 271 200 336 271 204 336 minecraft:dirt
fill 271 200 362 271 202 362 minecraft:moss_block
fill 271 200 364 271 228 364 minecraft:green_terracotta
setblock 272 200 324 minecraft:mushroom_stem
fill 272 200 335 272 204 335 minecraft:dirt
setblock 273 200 323 minecraft:mushroom_stem
fill 273 200 324 273 203 324 minecraft:moss_block
setblock 273 200 363 minecraft:mushroom_stem
fill 274 200 323 274 203 323 minecraft:moss_block
setblock 274 200 362 minecraft:mushroom_stem
fill 274 200 363 274 203 363 minecraft:moss_block
setblock 275 200 325 minecraft:moss_block
setblock 275 200 326 minecraft:mushroom_stem
fill 275 200 327 275 203 327 minecraft:moss_block
fill 275 200 359 275 201 359 minecraft:moss_block
setblock 275 200 361 minecraft:mushroom_stem
fill 275 200 362 275 203 362 minecraft:moss_block
setblock 276 200 325 minecraft:mushroom_stem
fill 276 200 326 276 203 326 minecraft:moss_block
setblock 276 200 329 minecraft:moss_block
setblock 276 200 330 minecraft:mushroom_stem
setblock 276 200 331 minecraft:red_mushroom_block
fill 276 200 337 276 200 339 minecraft:moss_block
setblock 276 200 340 minecraft:mushroom_stem
fill 276 200 341 276 203 341 minecraft:moss_block
setblock 276 200 344 minecraft:moss_block
setblock 276 200 345 minecraft:mushroom_stem
fill 276 200 346 276 201 348 minecraft:moss_block
setblock 276 200 355 minecraft:mushroom_stem
fill 276 200 356 276 203 356 minecraft:moss_block
setblock 276 200 360 minecraft:mushroom_stem
fill 276 200 361 276 203 361 minecraft:moss_block
setblock 277 200 362 minecraft:red_mushroom_block
fill 277 200 363 277 228 363 minecraft:green_terracotta
fill 235 201 326 235 228 326 minecraft:green_terracotta
fill 235 201 331 235 226 331 minecraft:green_terracotta
setblock 236 201 324 minecraft:mushroom_stem
fill 236 201 325 236 204 325 minecraft:moss_block
setblock 236 201 328 minecraft:moss_block
setblock 236 201 336 minecraft:red_mushroom_block
fill 236 201 337 236 201 338 minecraft:moss_block
setblock 236 201 339 minecraft:mushroom_stem
fill 236 201 340 236 201 343 minecraft:moss_block
setblock 236 201 344 minecraft:mushroom_stem
fill 236 201 345 236 201 348 minecraft:moss_block
setblock 236 201 349 minecraft:mushroom_stem
fill 236 201 350 236 204 350 minecraft:moss_block
setblock 236 201 354 minecraft:mushroom_stem
fill 236 201 355 236 204 355 minecraft:moss_block
setblock 236 201 359 minecraft:mushroom_stem
fill 236 201 360 236 204 360 minecraft:moss_block
setblock 237 201 323 minecraft:mushroom_stem
fill 237 201 324 237 204 324 minecraft:moss_block
fill 237 201 326 237 202 326 minecraft:moss_block
fill 237 201 339 237 204 339 minecraft:moss_block
setblock 237 201 342 minecraft:moss_block
setblock 237 201 343 minecraft:mushroom_stem
fill 237 201 344 237 201 347 minecraft:moss_block
setblock 237 201 348 minecraft:mushroom_stem
fill 237 201 349 237 204 349 minecraft:moss_block
setblock 237 201 352 minecraft:moss_block
setblock 237 201 353 minecraft:mushroom_stem
fill 237 201 354 237 204 354 minecraft:moss_block
setblock 237 201 358 minecraft:mushroom_stem
fill 237 201 359 237 204 359 minecraft:moss_block
setblock 237 201 363 minecraft:mushroom_stem
fill 238 201 323 238 204 323 minecraft:moss_block
setblock 238 201 325 minecraft:light[level=12]
setblock 238 201 332 minecraft:light[level=12]
setblock 238 201 339 minecraft:light[level=12]
fill 238 201 340 238 201 341 minecraft:moss_block
setblock 238 201 342 minecraft:mushroom_stem
fill 238 201 343 238 204 343 minecraft:moss_block
setblock 238 201 346 minecraft:moss_block
setblock 238 201 347 minecraft:mushroom_stem
fill 238 201 348 239 203 348 minecraft:moss_block
fill 238 201 350 238 201 351 minecraft:moss_block
setblock 238 201 352 minecraft:mushroom_stem
fill 238 201 353 238 204 353 minecraft:moss_block
fill 238 201 355 238 202 355 minecraft:moss_block
setblock 238 201 357 minecraft:mushroom_stem
fill 238 201 358 238 203 358 minecraft:moss_block
setblock 238 201 362 minecraft:mushroom_stem
fill 238 201 363 238 204 363 minecraft:moss_block
fill 239 201 342 239 203 342 minecraft:moss_block
setblock 239 201 346 minecraft:mushroom_stem
fill 239 201 347 239 204 347 minecraft:moss_block
setblock 239 201 361 minecraft:mushroom_stem
fill 239 201 362 239 204 362 minecraft:moss_block
setblock 240 201 324 minecraft:moss_block
setblock 240 201 360 minecraft:mushroom_stem
fill 240 201 361 240 204 361 minecraft:moss_block
setblock 241 201 324 minecraft:mushroom_stem
setblock 242 201 323 minecraft:mushroom_stem
fill 242 201 324 242 204 324 minecraft:moss_block
setblock 242 201 363 minecraft:mushroom_stem
fill 243 201 323 243 204 323 minecraft:moss_block
setblock 243 201 362 minecraft:mushroom_stem
fill 243 201 363 243 204 363 minecraft:moss_block
fill 244 201 362 244 203 362 minecraft:moss_block
setblock 245 201 325 minecraft:light[level=12]
setblock 245 201 332 minecraft:light[level=12]
setblock 245 201 339 minecraft:light[level=12]
setblock 245 201 346 minecraft:light[level=12]
setblock 245 201 353 minecraft:light[level=12]
setblock 245 201 360 minecraft:light[level=12]
setblock 247 201 323 minecraft:mushroom_stem
setblock 247 201 363 minecraft:mushroom_stem
fill 248 201 323 251 201 323 minecraft:moss_block
fill 248 201 363 248 202 363 minecraft:moss_block
setblock 252 201 323 minecraft:mushroom_stem
setblock 252 201 325 minecraft:light[level=12]
setblock 252 201 332 minecraft:light[level=12]
setblock 252 201 346 minecraft:light[level=12]
setblock 252 201 353 minecraft:light[level=12]
setblock 252 201 360 minecraft:light[level=12]
setblock 252 201 363 minecraft:mushroom_stem
fill 253 201 323 253 204 323 minecraft:moss_block
fill 253 201 363 256 201 363 minecraft:moss_block
fill 254 201 324 255 201 324 minecraft:moss_block
setblock 256 201 323 minecraft:moss_block
setblock 256 201 324 minecraft:mushroom_stem
setblock 257 201 323 minecraft:mushroom_stem
fill 257 201 324 257 203 325 minecraft:moss_block
setblock 257 201 362 minecraft:moss_block
setblock 257 201 363 minecraft:mushroom_stem
fill 258 201 323 258 204 323 minecraft:moss_block
setblock 258 201 362 minecraft:mushroom_stem
fill 258 201 363 258 204 363 minecraft:moss_block
setblock 259 201 325 minecraft:moss_block
setblock 259 201 332 minecraft:light[level=12]
setblock 259 201 339 minecraft:light[level=12]
setblock 259 201 346 minecraft:light[level=12]
setblock 259 201 353 minecraft:light[level=12]
setblock 259 201 360 minecraft:light[level=12]
fill 259 201 362 259 204 362 minecraft:moss_block
setblock 260 201 325 minecraft:mushroom_stem
fill 260 201 326 263 201 326 minecraft:moss_block
setblock 261 201 324 minecraft:mushroom_stem
fill 261 201 325 261 204 325 minecraft:moss_block
setblock 262 201 323 minecraft:mushroom_stem
fill 262 201 324 262 204 324 minecraft:moss_block
setblock 262 201 363 minecraft:mushroom_stem
fill 263 201 323 263 204 323 minecraft:moss_block
setblock 263 201 362 minecraft:mushroom_stem
fill 263 201 363 263 204 363 minecraft:moss_block
fill 264 201 362 264 203 362 minecraft:moss_block
setblock 265 201 325 minecraft:mushroom_stem
setblock 266 201 324 minecraft:mushroom_stem
fill 266 201 325 266 204 325 minecraft:moss_block
setblock 266 201 332 minecraft:light[level=12]
setblock 266 201 339 minecraft:light[level=12]
setblock 266 201 346 minecraft:light[level=12]
setblock 266 201 353 minecraft:light[level=12]
setblock 266 201 360 minecraft:light[level=12]
setblock 267 201 323 minecraft:mushroom_stem
fill 267 201 324 267 204 324 minecraft:moss_block
setblock 267 201 363 minecraft:mushroom_stem
fill 268 201 323 268 204 323 minecraft:moss_block
fill 268 201 325 268 202 325 minecraft:moss_block
setblock 268 201 362 minecraft:mushroom_stem
fill 268 201 363 268 204 363 minecraft:moss_block
setblock 270 201 362 minecraft:moss_block
setblock 271 201 324 minecraft:mushroom_stem
setblock 272 201 323 minecraft:mushroom_stem
fill 272 201 324 272 204 324 minecraft:moss_block
setblock 272 201 362 minecraft:moss_block
setblock 272 201 363 minecraft:mushroom_stem
fill 273 201 323 273 204 323 minecraft:moss_block
setblock 273 201 325 minecraft:light[level=12]
setblock 273 201 332 minecraft:light[level=12]
setblock 273 201 339 minecraft:light[level=12]
setblock 273 201 346 minecraft:light[level=12]
setblock 273 201 353 minecraft:light[level=12]
setblock 273 201 360 minecraft:light[level=12]
setblock 273 201 362 minecraft:mushroom_stem
fill 273 201 363 273 204 363 minecraft:moss_block
setblock 274 201 325 minecraft:moss_block
fill 274 201 362 274 204 362 minecraft:moss_block
fill 274 201 364 275 228 364 minecraft:green_terracotta
setblock 275 201 325 minecraft:mushroom_stem
fill 275 201 326 275 204 326 minecraft:moss_block
fill 275 201 328 275 202 328 minecraft:moss_block
setblock 275 201 360 minecraft:mushroom_stem
fill 275 201 361 275 204 361 minecraft:moss_block
setblock 276 201 324 minecraft:mushroom_stem
fill 276 201 325 276 204 325 minecraft:moss_block
setblock 276 201 329 minecraft:mushroom_stem
fill 276 201 330 276 203 331 minecraft:moss_block
fill 276 201 337 276 201 338 minecraft:moss_block
setblock 276 201 339 minecraft:mushroom_stem
fill 276 201 340 276 204 340 minecraft:moss_block
setblock 276 201 344 minecraft:mushroom_stem
fill 276 201 345 276 204 345 minecraft:moss_block
setblock 276 201 349 minecraft:mushroom_stem
fill 276 201 350 276 201 353 minecraft:moss_block
setblock 276 201 354 minecraft:mushroom_stem
fill 276 201 355 276 204 355 minecraft:moss_block
setblock 276 201 359 minecraft:mushroom_stem
fill 276 201 360 276 204 360 minecraft:moss_block
setblock 276 201 364 minecraft:red_mushroom_block
fill 277 201 362 277 228 362 minecraft:green_terracotta
fill 277 201 364 277 228 364 minecraft:green_terracotta
setblock 235 202 342 minecraft:shroomlight
setblock 236 202 323 minecraft:mushroom_stem
fill 236 202 324 236 205 324 minecraft:moss_block
setblock 236 202 328 minecraft:mushroom_stem
fill 236 202 329 236 204 330 minecraft:moss_block
setblock 236 202 337 minecraft:moss_block
setblock 236 202 338 minecraft:mushroom_stem
fill 236 202 339 236 202 342 minecraft:moss_block
setblock 236 202 343 minecraft:mushroom_stem
fill 236 202 344 236 202 347 minecraft:moss_block
setblock 236 202 348 minecraft:mushroom_stem
fill 236 202 349 236 205 349 minecraft:moss_block
setblock 236 202 352 minecraft:moss_block
setblock 236 202 353 minecraft:mushroom_stem
fill 236 202 354 236 205 354 minecraft:moss_block
setblock 236 202 358 minecraft:mushroom_stem
fill 236 202 359 236 205 359 minecraft:moss_block
setblock 236 202 363 minecraft:mushroom_stem
fill 237 202 323 237 205 323 minecraft:moss_block
setblock 237 202 327 minecraft:mushroom_stem
setblock 237 202 342 minecraft:mushroom_stem
fill 237 202 343 237 202 346 minecraft:moss_block
setblock 237 202 347 minecraft:mushroom_stem
fill 237 202 348 237 205 348 minecraft:moss_block
setblock 237 202 352 minecraft:mushroom_stem
fill 237 202 353 237 205 353 minecraft:moss_block
setblock 237 202 357 minecraft:mushroom_stem
fill 237 202 358 237 205 358 minecraft:moss_block
setblock 237 202 362 minecraft:mushroom_stem
fill 237 202 363 237 205 363 minecraft:moss_block
setblock 238 202 325 minecraft:moss_block
setblock 238 202 340 minecraft:moss_block
setblock 238 202 341 minecraft:mushroom_stem
fill 238 202 342 238 205 342 minecraft:moss_block
setblock 238 202 346 minecraft:mushroom_stem
fill 238 202 347 238 205 347 minecraft:moss_block
setblock 238 202 350 minecraft:moss_block
setblock 238 202 351 minecraft:mushroom_stem
fill 238 202 352 238 205 352 minecraft:moss_block
fill 238 202 354 238 203 354 minecraft:moss_block
setblock 238 202 356 minecraft:mushroom_stem
fill 238 202 357 238 203 357 minecraft:moss_block
setblock 238 202 361 minecraft:mushroom_stem
fill 238 202 362 238 205 362 minecraft:moss_block
setblock 239 202 325 minecraft:mushroom_stem
setblock 239 202 345 minecraft:mushroom_stem
fill 239 202 346 239 205 346 minecraft:moss_block
setblock 239 202 349 minecraft:moss_block
setblock 239 202 350 minecraft:mushroom_stem
fill 239 202 361 239 204 361 minecraft:moss_block
setblock 240 202 324 minecraft:mushroom_stem
fill 240 202 325 240 203 325 minecraft:moss_block
setblock 241 202 323 minecraft:mushroom_stem
fill 241 202 324 241 205 324 minecraft:moss_block
setblock 241 202 363 minecraft:mushroom_stem
fill 242 202 323 242 205 323 minecraft:moss_block
setblock 242 202 362 minecraft:mushroom_stem
fill 242 202 363 242 205 363 minecraft:moss_block
fill 243 202 362 243 203 362 minecraft:moss_block
setblock 246 202 323 minecraft:mushroom_stem
setblock 246 202 363 minecraft:mushroom_stem
fill 247 202 323 250 202 323 minecraft:moss_block
fill 247 202 363 247 203 363 minecraft:moss_block
setblock 251 202 323 minecraft:mushroom_stem
fill 252 202 323 252 205 323 minecraft:moss_block
fill 252 202 363 255 202 363 minecraft:moss_block
fill 253 202 324 254 202 324 minecraft:moss_block
setblock 255 202 324 minecraft:mushroom_stem
setblock 256 202 323 minecraft:mushroom_stem
fill 256 202 324 256 204 325 minecraft:moss_block
setblock 256 202 362 minecraft:moss_block
setblock 256 202 363 minecraft:mushroom_stem
fill 257 202 323 257 205 323 minecraft:moss_block
setblock 257 202 362 minecraft:mushroom_stem
fill 257 202 363 257 205 363 minecraft:moss_block
setblock 258 202 326 minecraft:mushroom_stem
fill 258 202 362 258 204 362 minecraft:moss_block
setblock 259 202 325 minecraft:mushroom_stem
fill 259 202 326 262 202 326 minecraft:moss_block
setblock 260 202 324 minecraft:mushroom_stem
fill 260 202 325 260 205 325 minecraft:moss_block
setblock 261 202 323 minecraft:mushroom_stem
fill 261 202 324 261 205 324 minecraft:moss_block
setblock 261 202 363 minecraft:mushroom_stem
fill 262 202 323 262 205 323 minecraft:moss_block
setblock 262 202 362 minecraft:mushroom_stem
fill 262 202 363 262 205 363 minecraft:moss_block
setblock 263 202 326 minecraft:mushroom_stem
fill 263 202 362 263 203 362 minecraft:moss_block
setblock 264 202 325 minecraft:mushroom_stem
setblock 264 202 326 minecraft:moss_block
setblock 265 202 324 minecraft:mushroom_stem
fill 265 202 325 265 205 325 minecraft:moss_block
setblock 266 202 323 minecraft:mushroom_stem
fill 266 202 324 266 205 324 minecraft:moss_block
setblock 266 202 363 minecraft:mushroom_stem
fill 267 202 323 267 205 323 minecraft:moss_block
fill 267 202 363 267 205 363 minecraft:moss_block
setblock 270 202 324 minecraft:mushroom_stem
fill 270 202 334 270 204 334 minecraft:dirt
fill 270 202 336 270 204 336 minecraft:dirt
setblock 271 202 323 minecraft:mushroom_stem
fill 271 202 324 271 205 324 minecraft:moss_block
setblock 271 202 363 minecraft:mushroom_stem
fill 272 202 323 272 205 323 minecraft:moss_block
fill 272 202 325 273 202 325 minecraft:moss_block
fill 272 202 334 272 204 334 minecraft:dirt
fill 272 202 336 272 204 336 minecraft:dirt
setblock 272 202 362 minecraft:mushroom_stem
fill 272 202 363 272 205 363 minecraft:moss_block
fill 273 202 362 273 205 362 minecraft:moss_block
setblock 274 202 325 minecraft:mushroom_stem
fill 274 202 326 274 205 326 minecraft:moss_block
setblock 275 202 324 minecraft:mushroom_stem
fill 275 202 325 275 205 325 minecraft:moss_block
setblock 275 202 343 minecraft:moss_block
setblock 275 202 344 minecraft:mushroom_stem
fill 275 202 345 275 203 347 minecraft:moss_block
setblock 275 202 358 minecraft:moss_block
setblock 275 202 359 minecraft:mushroom_stem
fill 275 202 360 275 205 360 minecraft:moss_block
setblock 276 202 323 minecraft:mushroom_stem
fill 276 202 324 276 205 324 minecraft:moss_block
setblock 276 202 327 minecraft:moss_block
setblock 276 202 328 minecraft:mushroom_stem
fill 276 202 329 276 205 329 minecraft:moss_block
setblock 276 202 332 minecraft:moss_block
setblock 276 202 337 minecraft:moss_block
setblock 276 202 338 minecraft:mushroom_stem
fill 276 202 339 276 204 339 minecraft:moss_block
setblock 276 202 343 minecraft:mushroom_stem
fill 276 202 344 276 205 344 minecraft:moss_block
fill 276 202 346 276 202 347 minecraft:moss_block
setblock 276 202 348 minecraft:mushroom_stem
fill 276 202 349 276 202 352 minecraft:moss_block
setblock 276 202 353 minecraft:mushroom_stem
fill 276 202 354 276 205 354 minecraft:moss_block
setblock 276 202 358 minecraft:mushroom_stem
fill 276 202 359 276 205 359 minecraft:moss_block
setblock 276 202 363 minecraft:mushroom_stem
fill 276 202 364 276 228 364 minecraft:green_terracotta
fill 235 203 342 235 228 342 minecraft:green_terracotta
fill 236 203 323 236 206 323 minecraft:moss_block
setblock 236 203 326 minecraft:moss_block
setblock 236 203 327 minecraft:mushroom_stem
fill 236 203 328 237 205 328 minecraft:moss_block
setblock 236 203 337 minecraft:mushroom_stem
fill 236 203 338 236 203 341 minecraft:moss_block
setblock 236 203 342 minecraft:mushroom_stem
fill 236 203 343 236 203 346 minecraft:moss_block
setblock 236 203 347 minecraft:mushroom_stem
fill 236 203 348 236 206 348 minecraft:moss_block
setblock 236 203 351 minecraft:moss_block
setblock 236 203 352 minecraft:mushroom_stem
fill 236 203 353 236 206 353 minecraft:moss_block
setblock 236 203 357 minecraft:mushroom_stem
fill 236 203 358 236 206 358 minecraft:moss_block
setblock 236 203 362 minecraft:mushroom_stem
fill 236 203 363 236 206 363 minecraft:moss_block
setblock 237 203 326 minecraft:mushroom_stem
fill 237 203 327 237 206 327 minecraft:moss_block
setblock 237 203 341 minecraft:mushroom_stem
fill 237 203 342 237 203 345 minecraft:moss_block
setblock 237 203 346 minecraft:mushroom_stem
fill 237 203 347 237 206 347 minecraft:moss_block
setblock 237 203 351 minecraft:mushroom_stem
fill 237 203 352 237 206 352 minecraft:moss_block
setblock 237 203 356 minecraft:mushroom_stem
fill 237 203 357 237 206 357 minecraft:moss_block
setblock 237 203 361 minecraft:mushroom_stem
fill 237 203 362 237 206 362 minecraft:moss_block
setblock 238 203 325 minecraft:mushroom_stem
setblock 238 203 340 minecraft:mushroom_stem
fill 238 203 341 238 204 341 minecraft:moss_block
setblock 238 203 344 minecraft:moss_block
setblock 238 203 345 minecraft:mushroom_stem
fill 238 203 346 238 206 346 minecraft:moss_block
setblock 238 203 350 minecraft:mushroom_stem
fill 238 203 351 239 205 351 minecraft:moss_block
setblock 238 203 355 minecraft:mushroom_stem
fill 238 203 356 238 204 356 minecraft:moss_block
setblock 238 203 360 minecraft:mushroom_stem
fill 238 203 361 238 204 361 minecraft:moss_block
setblock 239 203 324 minecraft:mushroom_stem
fill 239 203 325 239 204 325 minecraft:moss_block
setblock 239 203 344 minecraft:mushroom_stem
fill 239 203 345 239 206 345 minecraft:moss_block
setblock 239 203 349 minecraft:mushroom_stem
fill 239 203 350 239 206 350 minecraft:moss_block
setblock 240 203 323 minecraft:mushroom_stem
fill 240 203 324 240 206 324 minecraft:moss_block
setblock 240 203 363 minecraft:mushroom_stem
fill 241 203 323 241 206 323 minecraft:moss_block
setblock 241 203 362 minecraft:mushroom_stem
fill 241 203 363 241 206 363 minecraft:moss_block
fill 242 203 362 242 204 362 minecraft:moss_block
setblock 243 203 324 minecraft:moss_block
setblock 244 203 324 minecraft:mushroom_stem
setblock 245 203 323 minecraft:mushroom_stem
setblock 245 203 363 minecraft:mushroom_stem
fill 246 203 323 249 203 323 minecraft:moss_block
setblock 246 203 363 minecraft:moss_block
setblock 250 203 323 minecraft:mushroom_stem
fill 251 203 323 251 206 323 minecraft:moss_block
setblock 253 203 324 minecraft:moss_block
fill 253 203 363 254 203 363 minecraft:moss_block
setblock 254 203 324 minecraft:mushroom_stem
setblock 255 203 323 minecraft:mushroom_stem
fill 255 203 324 255 205 325 minecraft:moss_block
setblock 255 203 363 minecraft:mushroom_stem
fill 256 203 323 256 206 323 minecraft:moss_block
fill 256 203 363 256 206 363 minecraft:moss_block
setblock 257 203 326 minecraft:mushroom_stem
setblock 257 203 362 minecraft:moss_block
setblock 258 203 324 minecraft:moss_block
schedule function dropper:buildpart/77_6 1t
