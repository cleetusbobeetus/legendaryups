fill 42 228 616 42 242 616 minecraft:blue_concrete
fill 42 228 621 42 235 621 minecraft:blue_concrete
fill 42 228 630 42 239 630 minecraft:blue_concrete
fill 0 229 617 0 236 617 minecraft:blue_concrete
fill 4 229 625 4 230 625 minecraft:moss_block
fill 7 229 646 7 239 646 minecraft:blue_concrete
fill 21 229 646 21 238 646 minecraft:blue_concrete
setblock 31 229 604 minecraft:diamond_block
setblock 42 229 612 minecraft:glowstone
fill 42 229 615 42 236 615 minecraft:blue_concrete
setblock 0 230 605 minecraft:diamond_block
fill 31 230 604 31 239 604 minecraft:blue_concrete
fill 32 230 617 33 231 617 minecraft:gold_block
fill 42 230 612 42 239 612 minecraft:blue_concrete
setblock 0 231 605 minecraft:glowstone
setblock 3 231 646 minecraft:glowstone
fill 17 231 646 18 231 646 minecraft:glowstone
setblock 20 231 604 minecraft:diamond_block
setblock 42 231 631 minecraft:glowstone
fill 0 232 605 0 239 605 minecraft:blue_concrete
setblock 0 232 616 minecraft:glowstone
setblock 0 232 619 minecraft:diamond_block
fill 3 232 646 3 236 646 minecraft:blue_concrete
fill 17 232 646 18 235 646 minecraft:blue_concrete
fill 20 232 604 20 240 604 minecraft:blue_concrete
setblock 34 232 646 minecraft:diamond_block
fill 42 232 631 42 239 631 minecraft:blue_concrete
fill 0 233 609 0 240 609 minecraft:blue_concrete
setblock 0 233 610 minecraft:white_concrete
fill 0 233 616 0 237 616 minecraft:blue_concrete
fill 0 233 619 0 239 619 minecraft:blue_concrete
fill 34 233 646 34 236 646 minecraft:blue_concrete
setblock 42 233 613 minecraft:glowstone
setblock 42 233 620 minecraft:glowstone
setblock 42 233 623 minecraft:white_concrete
fill 0 234 610 0 239 610 minecraft:blue_concrete
setblock 23 234 646 minecraft:glowstone
setblock 40 234 646 minecraft:white_concrete
setblock 42 234 613 minecraft:diamond_block
fill 42 234 620 42 239 620 minecraft:blue_concrete
fill 42 234 623 42 237 623 minecraft:blue_concrete
setblock 3 235 607 minecraft:light[level=14]
setblock 3 235 615 minecraft:light[level=14]
setblock 3 235 623 minecraft:light[level=14]
setblock 3 235 631 minecraft:light[level=14]
setblock 3 235 639 minecraft:light[level=14]
setblock 11 235 607 minecraft:light[level=14]
setblock 11 235 615 minecraft:light[level=14]
setblock 11 235 623 minecraft:light[level=14]
setblock 11 235 631 minecraft:light[level=14]
setblock 11 235 639 minecraft:light[level=14]
setblock 19 235 607 minecraft:light[level=14]
setblock 19 235 615 minecraft:light[level=14]
setblock 19 235 623 minecraft:light[level=14]
setblock 19 235 631 minecraft:light[level=14]
setblock 19 235 639 minecraft:light[level=14]
setblock 21 235 604 minecraft:diamond_block
setblock 23 235 646 minecraft:blue_concrete
setblock 27 235 607 minecraft:light[level=14]
setblock 27 235 615 minecraft:light[level=14]
setblock 27 235 623 minecraft:light[level=14]
setblock 27 235 631 minecraft:light[level=14]
setblock 27 235 639 minecraft:light[level=14]
setblock 35 235 607 minecraft:light[level=14]
setblock 35 235 615 minecraft:light[level=14]
setblock 35 235 623 minecraft:light[level=14]
setblock 35 235 631 minecraft:light[level=14]
setblock 35 235 639 minecraft:light[level=14]
setblock 39 235 646 minecraft:diamond_block
fill 40 235 646 40 239 646 minecraft:blue_concrete
fill 42 235 613 42 240 613 minecraft:blue_concrete
setblock 0 236 613 minecraft:black_concrete
fill 0 236 614 0 237 614 minecraft:blue_concrete
setblock 0 236 625 minecraft:black_concrete
setblock 1 236 646 minecraft:black_concrete
setblock 8 236 604 minecraft:diamond_block
fill 17 236 646 17 239 646 minecraft:blue_concrete
setblock 18 236 646 minecraft:black_concrete
fill 19 236 646 19 237 646 minecraft:glowstone
fill 20 236 646 20 239 646 minecraft:blue_concrete
fill 21 236 604 21 239 604 minecraft:blue_concrete
fill 23 236 646 24 236 646 minecraft:black_concrete
setblock 25 236 604 minecraft:black_concrete
fill 26 236 646 27 236 646 minecraft:black_concrete
fill 28 236 604 29 236 604 minecraft:black_concrete
setblock 33 236 604 minecraft:blue_concrete
fill 34 236 604 34 237 604 minecraft:black_concrete
setblock 37 236 604 minecraft:diamond_block
fill 39 236 646 39 239 646 minecraft:blue_concrete
setblock 42 236 609 minecraft:black_concrete
setblock 42 236 621 minecraft:black_concrete
setblock 42 236 627 minecraft:black_concrete
setblock 42 236 629 minecraft:black_concrete
setblock 42 236 641 minecraft:black_concrete
fill 0 237 604 0 238 604 minecraft:black_concrete
setblock 0 237 612 minecraft:black_concrete
fill 0 237 613 0 239 613 minecraft:blue_concrete
setblock 0 237 615 minecraft:black_concrete
setblock 0 237 617 minecraft:black_concrete
fill 0 237 625 0 239 625 minecraft:blue_concrete
setblock 0 237 628 minecraft:black_concrete
fill 0 237 630 0 237 631 minecraft:black_concrete
setblock 0 237 635 minecraft:black_concrete
setblock 0 237 644 minecraft:black_concrete
fill 1 237 646 1 239 646 minecraft:blue_concrete
setblock 3 237 646 minecraft:diamond_block
fill 8 237 604 8 239 604 minecraft:blue_concrete
setblock 10 237 604 minecraft:white_concrete
setblock 13 237 646 minecraft:black_concrete
setblock 14 237 604 minecraft:black_concrete
setblock 14 237 646 minecraft:glowstone
fill 18 237 646 18 239 646 minecraft:blue_concrete
fill 19 237 604 19 238 604 minecraft:black_concrete
fill 23 237 646 24 239 646 minecraft:blue_concrete
setblock 25 237 604 minecraft:blue_concrete
fill 26 237 646 27 239 646 minecraft:blue_concrete
fill 28 237 604 29 239 604 minecraft:blue_concrete
setblock 33 237 604 minecraft:diamond_block
fill 33 237 646 34 237 646 minecraft:black_concrete
fill 37 237 604 37 239 604 minecraft:blue_concrete
fill 42 237 604 42 238 604 minecraft:black_concrete
setblock 42 237 609 minecraft:blue_concrete
setblock 42 237 615 minecraft:black_concrete
setblock 42 237 621 minecraft:blue_concrete
setblock 42 237 622 minecraft:black_concrete
fill 42 237 627 42 239 627 minecraft:blue_concrete
fill 42 237 629 42 239 629 minecraft:blue_concrete
fill 42 237 641 42 239 641 minecraft:blue_concrete
setblock 42 237 646 minecraft:black_concrete
setblock 0 238 608 minecraft:black_concrete
fill 0 238 612 0 239 612 minecraft:blue_concrete
setblock 0 238 614 minecraft:black_concrete
setblock 0 238 615 minecraft:white_concrete
setblock 0 238 616 minecraft:black_concrete
fill 0 238 617 0 239 617 minecraft:blue_concrete
setblock 0 238 626 minecraft:black_concrete
fill 0 238 628 0 239 628 minecraft:blue_concrete
fill 0 238 630 0 239 630 minecraft:blue_concrete
setblock 0 238 631 minecraft:white_concrete
fill 0 238 635 0 239 635 minecraft:blue_concrete
fill 0 238 644 0 239 644 minecraft:blue_concrete
setblock 1 238 604 minecraft:black_concrete
fill 2 238 604 2 239 604 minecraft:blue_concrete
setblock 3 238 604 minecraft:black_concrete
fill 3 238 646 3 239 646 minecraft:blue_concrete
fill 10 238 604 10 239 604 minecraft:blue_concrete
fill 13 238 646 14 239 646 minecraft:blue_concrete
fill 14 238 604 14 239 604 minecraft:blue_concrete
fill 17 238 618 19 238 620 minecraft:redstone_block
fill 17 238 626 19 238 628 minecraft:redstone_block
fill 19 238 646 19 239 646 minecraft:blue_concrete
fill 24 238 619 26 238 621 minecraft:redstone_block
setblock 25 238 604 minecraft:black_concrete
setblock 32 238 604 minecraft:black_concrete
fill 33 238 604 34 239 604 minecraft:blue_concrete
fill 33 238 646 33 240 646 minecraft:blue_concrete
setblock 34 238 646 minecraft:black_concrete
setblock 42 238 605 minecraft:black_concrete
setblock 42 238 607 minecraft:black_concrete
fill 42 238 609 42 238 610 minecraft:black_concrete
fill 42 238 615 42 239 615 minecraft:blue_concrete
setblock 42 238 618 minecraft:black_concrete
setblock 42 238 621 minecraft:black_concrete
fill 42 238 622 42 239 622 minecraft:blue_concrete
setblock 42 238 623 minecraft:black_concrete
setblock 42 238 625 minecraft:black_concrete
setblock 42 238 632 minecraft:black_concrete
setblock 42 238 636 minecraft:black_concrete
setblock 42 238 643 minecraft:black_concrete
fill 42 238 646 42 239 646 minecraft:blue_concrete
fill 0 239 604 1 239 604 minecraft:blue_concrete
setblock 0 239 608 minecraft:blue_concrete
fill 0 239 614 0 239 616 minecraft:blue_concrete
setblock 0 239 626 minecraft:blue_concrete
setblock 0 239 631 minecraft:blue_concrete
setblock 0 239 636 minecraft:white_concrete
fill 1 239 605 4 239 606 minecraft:green_terracotta
fill 1 239 607 4 239 610 minecraft:moss_block
fill 1 239 611 4 239 614 minecraft:green_terracotta
fill 1 239 615 4 239 618 minecraft:moss_block
fill 1 239 619 4 239 622 minecraft:green_terracotta
fill 1 239 623 4 239 626 minecraft:moss_block
fill 1 239 627 4 239 630 minecraft:green_terracotta
fill 1 239 631 4 239 634 minecraft:moss_block
fill 1 239 635 4 239 638 minecraft:green_terracotta
fill 1 239 639 4 239 642 minecraft:moss_block
fill 1 239 643 4 239 645 minecraft:green_terracotta
setblock 3 239 604 minecraft:blue_concrete
fill 5 239 605 8 239 606 minecraft:moss_block
fill 5 239 607 8 239 610 minecraft:green_terracotta
fill 5 239 611 8 239 614 minecraft:moss_block
fill 5 239 615 8 239 618 minecraft:green_terracotta
fill 5 239 619 8 239 622 minecraft:moss_block
fill 5 239 623 8 239 626 minecraft:green_terracotta
fill 5 239 627 8 239 630 minecraft:moss_block
fill 5 239 631 8 239 634 minecraft:green_terracotta
fill 5 239 635 8 239 638 minecraft:moss_block
fill 5 239 639 8 239 642 minecraft:green_terracotta
fill 5 239 643 8 239 645 minecraft:moss_block
fill 9 239 605 12 239 606 minecraft:green_terracotta
fill 9 239 607 12 239 610 minecraft:moss_block
fill 9 239 611 12 239 614 minecraft:green_terracotta
fill 9 239 615 12 239 618 minecraft:moss_block
fill 9 239 619 12 239 622 minecraft:green_terracotta
fill 9 239 623 12 239 626 minecraft:moss_block
fill 9 239 627 12 239 630 minecraft:green_terracotta
fill 9 239 631 12 239 634 minecraft:moss_block
fill 9 239 635 12 239 638 minecraft:green_terracotta
fill 9 239 639 12 239 642 minecraft:moss_block
fill 9 239 643 12 239 645 minecraft:green_terracotta
fill 13 239 605 16 239 606 minecraft:moss_block
fill 13 239 607 16 239 610 minecraft:green_terracotta
fill 13 239 611 16 239 614 minecraft:moss_block
fill 13 239 615 16 239 618 minecraft:green_terracotta
fill 13 239 619 16 239 622 minecraft:moss_block
fill 13 239 623 16 239 626 minecraft:green_terracotta
fill 13 239 627 16 239 630 minecraft:moss_block
fill 13 239 631 16 239 634 minecraft:green_terracotta
fill 13 239 635 16 239 638 minecraft:moss_block
fill 13 239 639 16 239 642 minecraft:green_terracotta
fill 13 239 643 16 239 645 minecraft:moss_block
setblock 15 239 646 minecraft:white_concrete
fill 17 239 605 20 239 606 minecraft:green_terracotta
fill 17 239 607 20 239 610 minecraft:moss_block
fill 17 239 611 20 239 614 minecraft:green_terracotta
fill 17 239 615 20 239 617 minecraft:moss_block
fill 17 239 621 19 239 622 minecraft:green_terracotta
fill 17 239 623 19 239 625 minecraft:moss_block
fill 17 239 629 20 239 630 minecraft:green_terracotta
fill 17 239 631 20 239 634 minecraft:moss_block
fill 17 239 635 20 239 638 minecraft:green_terracotta
fill 17 239 639 20 239 642 minecraft:moss_block
fill 17 239 643 20 239 645 minecraft:green_terracotta
setblock 19 239 604 minecraft:blue_concrete
setblock 20 239 618 minecraft:moss_block
fill 20 239 619 20 239 621 minecraft:green_terracotta
fill 20 239 625 20 239 626 minecraft:moss_block
fill 20 239 627 20 239 628 minecraft:green_terracotta
fill 21 239 605 24 239 606 minecraft:moss_block
fill 21 239 607 24 239 610 minecraft:green_terracotta
fill 21 239 611 24 239 614 minecraft:moss_block
fill 21 239 615 24 239 618 minecraft:green_terracotta
fill 21 239 619 23 239 621 minecraft:moss_block
fill 21 239 625 24 239 626 minecraft:green_terracotta
fill 21 239 627 24 239 630 minecraft:moss_block
fill 21 239 631 24 239 634 minecraft:green_terracotta
fill 21 239 635 24 239 638 minecraft:moss_block
fill 21 239 639 24 239 642 minecraft:green_terracotta
fill 21 239 643 24 239 645 minecraft:moss_block
setblock 21 239 646 minecraft:glowstone
fill 23 239 622 24 239 622 minecraft:moss_block
fill 23 239 623 24 239 624 minecraft:green_terracotta
setblock 25 239 604 minecraft:blue_concrete
fill 25 239 605 28 239 606 minecraft:green_terracotta
fill 25 239 607 28 239 610 minecraft:moss_block
fill 25 239 611 28 239 614 minecraft:green_terracotta
fill 25 239 615 28 239 618 minecraft:moss_block
fill 25 239 622 28 239 622 minecraft:green_terracotta
fill 25 239 623 28 239 626 minecraft:moss_block
fill 25 239 627 28 239 630 minecraft:green_terracotta
fill 25 239 631 28 239 634 minecraft:moss_block
fill 25 239 635 28 239 638 minecraft:green_terracotta
fill 25 239 639 28 239 642 minecraft:moss_block
fill 25 239 643 28 239 645 minecraft:green_terracotta
fill 27 239 619 28 239 621 minecraft:green_terracotta
fill 29 239 605 32 239 606 minecraft:moss_block
fill 29 239 607 32 239 610 minecraft:green_terracotta
fill 29 239 611 32 239 614 minecraft:moss_block
fill 29 239 615 32 239 618 minecraft:green_terracotta
fill 29 239 619 32 239 622 minecraft:moss_block
fill 29 239 623 32 239 626 minecraft:green_terracotta
fill 29 239 627 32 239 630 minecraft:moss_block
fill 29 239 631 32 239 634 minecraft:green_terracotta
fill 29 239 635 32 239 638 minecraft:moss_block
fill 29 239 639 32 239 642 minecraft:green_terracotta
fill 29 239 643 32 239 645 minecraft:moss_block
fill 32 239 604 32 240 604 minecraft:blue_concrete
fill 33 239 605 36 239 606 minecraft:green_terracotta
fill 33 239 607 36 239 610 minecraft:moss_block
fill 33 239 611 36 239 614 minecraft:green_terracotta
fill 33 239 615 36 239 618 minecraft:moss_block
fill 33 239 619 36 239 622 minecraft:green_terracotta
fill 33 239 623 36 239 626 minecraft:moss_block
fill 33 239 627 36 239 630 minecraft:green_terracotta
fill 33 239 631 36 239 634 minecraft:moss_block
fill 33 239 635 36 239 638 minecraft:green_terracotta
fill 33 239 639 36 239 642 minecraft:moss_block
fill 33 239 643 36 239 645 minecraft:green_terracotta
setblock 34 239 646 minecraft:blue_concrete
fill 37 239 605 40 239 606 minecraft:moss_block
fill 37 239 607 40 239 610 minecraft:green_terracotta
fill 37 239 611 40 239 614 minecraft:moss_block
fill 37 239 615 40 239 618 minecraft:green_terracotta
fill 37 239 619 40 239 622 minecraft:moss_block
fill 37 239 623 40 239 626 minecraft:green_terracotta
fill 37 239 627 40 239 630 minecraft:moss_block
fill 37 239 631 40 239 634 minecraft:green_terracotta
fill 37 239 635 40 239 638 minecraft:moss_block
fill 37 239 639 40 239 642 minecraft:green_terracotta
fill 37 239 643 40 239 645 minecraft:moss_block
fill 41 239 605 41 239 606 minecraft:green_terracotta
fill 41 239 607 41 239 610 minecraft:moss_block
fill 41 239 611 41 239 614 minecraft:green_terracotta
fill 41 239 615 41 239 618 minecraft:moss_block
fill 41 239 619 41 239 622 minecraft:green_terracotta
fill 41 239 623 41 239 626 minecraft:moss_block
fill 41 239 627 41 239 630 minecraft:green_terracotta
fill 41 239 631 41 239 634 minecraft:moss_block
fill 41 239 635 41 239 638 minecraft:green_terracotta
fill 41 239 639 41 239 642 minecraft:moss_block
fill 41 239 643 41 239 645 minecraft:green_terracotta
fill 42 239 604 42 239 605 minecraft:blue_concrete
setblock 42 239 607 minecraft:blue_concrete
fill 42 239 609 42 239 610 minecraft:blue_concrete
setblock 42 239 618 minecraft:blue_concrete
setblock 42 239 621 minecraft:blue_concrete
setblock 42 239 623 minecraft:blue_concrete
setblock 42 239 625 minecraft:blue_concrete
setblock 42 239 632 minecraft:blue_concrete
setblock 42 239 636 minecraft:blue_concrete
setblock 42 239 643 minecraft:blue_concrete
fill 0 240 604 0 240 608 minecraft:black_concrete
fill 0 240 610 0 240 615 minecraft:black_concrete
setblock 0 240 616 minecraft:blue_concrete
fill 0 240 617 0 240 619 minecraft:black_concrete
fill 0 240 621 0 241 623 minecraft:black_concrete
fill 0 240 625 0 240 639 minecraft:black_concrete
setblock 0 240 640 minecraft:blue_concrete
fill 0 240 641 0 266 642 minecraft:black_concrete
fill 0 240 644 0 243 645 minecraft:black_concrete
fill 1 240 604 19 240 604 minecraft:black_concrete
fill 1 240 605 1 240 645 minecraft:dirt
fill 1 240 646 3 241 646 minecraft:black_concrete
fill 2 240 605 4 240 606 minecraft:green_terracotta
fill 2 240 607 41 240 607 minecraft:dirt
fill 2 240 608 4 240 610 minecraft:moss_block
fill 2 240 611 41 240 611 minecraft:dirt
fill 2 240 612 4 240 614 minecraft:green_terracotta
fill 2 240 615 41 240 615 minecraft:dirt
fill 2 240 616 4 240 618 minecraft:moss_block
fill 2 240 619 15 240 619 minecraft:dirt
fill 2 240 620 4 240 622 minecraft:green_terracotta
fill 2 240 623 18 240 623 minecraft:dirt
fill 2 240 624 4 240 626 minecraft:moss_block
fill 2 240 627 15 240 627 minecraft:dirt
fill 2 240 628 4 240 630 minecraft:green_terracotta
fill 2 240 631 41 240 631 minecraft:dirt
fill 2 240 632 4 240 634 minecraft:moss_block
fill 2 240 635 41 240 635 minecraft:dirt
fill 2 240 636 4 240 638 minecraft:green_terracotta
fill 2 240 639 41 240 639 minecraft:dirt
fill 2 240 640 4 240 642 minecraft:moss_block
fill 2 240 643 41 240 643 minecraft:dirt
fill 2 240 644 4 240 645 minecraft:green_terracotta
fill 5 240 605 5 240 606 minecraft:dirt
fill 5 240 608 5 240 610 minecraft:dirt
fill 5 240 612 5 240 614 minecraft:dirt
fill 5 240 616 5 240 618 minecraft:dirt
fill 5 240 620 5 240 622 minecraft:dirt
fill 5 240 624 5 240 626 minecraft:dirt
fill 5 240 628 5 240 630 minecraft:dirt
fill 5 240 632 5 240 634 minecraft:dirt
fill 5 240 636 5 240 638 minecraft:dirt
fill 5 240 640 5 240 642 minecraft:dirt
fill 5 240 644 5 240 645 minecraft:dirt
fill 5 240 646 13 240 646 minecraft:black_concrete
fill 6 240 605 8 240 606 minecraft:moss_block
fill 6 240 608 8 240 610 minecraft:green_terracotta
fill 6 240 612 8 240 614 minecraft:moss_block
fill 6 240 616 8 240 618 minecraft:green_terracotta
fill 6 240 620 8 240 622 minecraft:moss_block
fill 6 240 624 8 240 626 minecraft:green_terracotta
fill 6 240 628 8 240 630 minecraft:moss_block
fill 6 240 632 8 240 634 minecraft:green_terracotta
fill 6 240 636 8 240 638 minecraft:moss_block
fill 6 240 640 8 240 642 minecraft:green_terracotta
fill 6 240 644 8 240 645 minecraft:moss_block
fill 9 240 605 9 240 606 minecraft:dirt
fill 9 240 608 9 240 610 minecraft:dirt
fill 9 240 612 9 240 614 minecraft:dirt
fill 9 240 616 9 240 618 minecraft:dirt
fill 9 240 620 9 240 622 minecraft:dirt
fill 9 240 624 9 240 626 minecraft:dirt
fill 9 240 628 9 240 630 minecraft:dirt
fill 9 240 632 9 240 634 minecraft:dirt
fill 9 240 636 9 240 638 minecraft:dirt
fill 9 240 640 9 240 642 minecraft:dirt
fill 9 240 644 9 240 645 minecraft:dirt
fill 10 240 605 12 240 606 minecraft:green_terracotta
fill 10 240 608 12 240 610 minecraft:moss_block
fill 10 240 612 12 240 614 minecraft:green_terracotta
fill 10 240 616 12 240 618 minecraft:moss_block
fill 10 240 620 12 240 622 minecraft:green_terracotta
fill 10 240 624 12 240 626 minecraft:moss_block
fill 10 240 628 12 240 630 minecraft:green_terracotta
fill 10 240 632 12 240 634 minecraft:moss_block
fill 10 240 636 12 240 638 minecraft:green_terracotta
fill 10 240 640 12 240 642 minecraft:moss_block
fill 10 240 644 12 240 645 minecraft:green_terracotta
fill 13 240 605 13 240 606 minecraft:dirt
fill 13 240 608 13 240 610 minecraft:dirt
fill 13 240 612 13 240 614 minecraft:dirt
fill 13 240 616 13 240 618 minecraft:dirt
fill 13 240 620 13 240 622 minecraft:dirt
fill 13 240 624 13 240 626 minecraft:dirt
fill 13 240 628 13 240 630 minecraft:dirt
fill 13 240 632 13 240 634 minecraft:dirt
fill 13 240 636 13 240 638 minecraft:dirt
fill 13 240 640 13 240 642 minecraft:dirt
fill 13 240 644 13 240 645 minecraft:dirt
fill 14 240 605 16 240 606 minecraft:moss_block
fill 14 240 608 16 240 610 minecraft:green_terracotta
fill 14 240 612 16 240 614 minecraft:moss_block
fill 14 240 616 15 240 618 minecraft:green_terracotta
fill 14 240 620 15 240 622 minecraft:moss_block
fill 14 240 624 15 240 626 minecraft:green_terracotta
fill 14 240 628 15 240 630 minecraft:moss_block
fill 14 240 632 16 240 634 minecraft:green_terracotta
fill 14 240 636 16 240 638 minecraft:moss_block
fill 14 240 640 16 240 642 minecraft:green_terracotta
fill 14 240 644 16 240 645 minecraft:moss_block
setblock 14 240 646 minecraft:blue_concrete
fill 15 240 646 18 241 646 minecraft:black_concrete
setblock 16 240 616 minecraft:green_terracotta
fill 16 240 617 16 240 621 minecraft:glowstone
setblock 16 240 622 minecraft:moss_block
setblock 16 240 624 minecraft:green_terracotta
fill 16 240 625 16 240 629 minecraft:glowstone
setblock 16 240 630 minecraft:moss_block
fill 17 240 605 17 240 606 minecraft:dirt
fill 17 240 608 17 240 610 minecraft:dirt
fill 17 240 612 17 240 614 minecraft:dirt
setblock 17 240 616 minecraft:dirt
fill 17 240 617 20 240 617 minecraft:glowstone
fill 17 240 618 19 240 620 minecraft:moss_block
fill 17 240 621 23 240 621 minecraft:glowstone
setblock 17 240 622 minecraft:dirt
setblock 17 240 624 minecraft:dirt
fill 17 240 625 23 240 625 minecraft:glowstone
fill 17 240 626 19 240 628 minecraft:moss_block
fill 17 240 629 20 240 629 minecraft:glowstone
setblock 17 240 630 minecraft:dirt
fill 17 240 632 17 240 634 minecraft:dirt
fill 17 240 636 17 240 638 minecraft:dirt
fill 17 240 640 17 240 642 minecraft:dirt
fill 17 240 644 17 240 645 minecraft:dirt
fill 18 240 605 20 240 606 minecraft:green_terracotta
fill 18 240 608 20 240 610 minecraft:moss_block
fill 18 240 612 20 240 614 minecraft:green_terracotta
fill 18 240 616 20 240 616 minecraft:moss_block
setblock 18 240 622 minecraft:green_terracotta
setblock 18 240 624 minecraft:moss_block
fill 18 240 630 20 240 630 minecraft:green_terracotta
fill 18 240 632 20 240 634 minecraft:moss_block
fill 18 240 636 20 240 638 minecraft:green_terracotta
fill 18 240 640 20 240 642 minecraft:moss_block
fill 18 240 644 20 240 645 minecraft:green_terracotta
fill 19 240 622 19 240 624 minecraft:glowstone
setblock 19 240 646 minecraft:white_concrete
fill 20 240 618 20 240 620 minecraft:glowstone
fill 20 240 626 20 240 628 minecraft:glowstone
fill 20 240 646 24 247 646 minecraft:black_concrete
fill 21 240 604 31 242 604 minecraft:black_concrete
fill 21 240 605 21 240 606 minecraft:dirt
fill 21 240 608 21 240 610 minecraft:dirt
fill 21 240 612 21 240 614 minecraft:dirt
fill 21 240 616 21 240 620 minecraft:dirt
fill 21 240 626 21 240 630 minecraft:dirt
fill 21 240 632 21 240 634 minecraft:dirt
fill 21 240 636 21 240 638 minecraft:dirt
fill 21 240 640 21 240 642 minecraft:dirt
fill 21 240 644 21 240 645 minecraft:dirt
fill 22 240 605 24 240 606 minecraft:moss_block
fill 22 240 608 24 240 610 minecraft:green_terracotta
fill 22 240 612 24 240 614 minecraft:moss_block
fill 22 240 616 22 240 618 minecraft:green_terracotta
setblock 22 240 619 minecraft:dirt
setblock 22 240 620 minecraft:moss_block
fill 22 240 626 24 240 626 minecraft:green_terracotta
fill 22 240 627 41 240 627 minecraft:dirt
fill 22 240 628 24 240 630 minecraft:moss_block
fill 22 240 632 24 240 634 minecraft:green_terracotta
fill 22 240 636 24 240 638 minecraft:moss_block
fill 22 240 640 24 240 642 minecraft:green_terracotta
fill 22 240 644 24 240 645 minecraft:moss_block
fill 23 240 616 24 240 617 minecraft:green_terracotta
fill 23 240 618 23 240 620 minecraft:glowstone
fill 23 240 622 23 240 624 minecraft:glowstone
fill 24 240 618 27 240 618 minecraft:glowstone
fill 24 240 619 26 240 621 minecraft:moss_block
fill 24 240 622 27 240 622 minecraft:glowstone
fill 24 240 623 41 240 623 minecraft:dirt
fill 24 240 624 24 240 625 minecraft:green_terracotta
fill 25 240 605 25 240 606 minecraft:dirt
fill 25 240 608 25 240 610 minecraft:dirt
fill 25 240 612 25 240 614 minecraft:dirt
fill 25 240 616 25 240 617 minecraft:dirt
fill 25 240 624 25 240 626 minecraft:dirt
fill 25 240 628 25 240 630 minecraft:dirt
fill 25 240 632 25 240 634 minecraft:dirt
fill 25 240 636 25 240 638 minecraft:dirt
fill 25 240 640 25 240 642 minecraft:dirt
fill 25 240 644 25 240 645 minecraft:dirt
setblock 25 240 646 minecraft:white_concrete
fill 26 240 605 28 240 606 minecraft:green_terracotta
fill 26 240 608 28 240 610 minecraft:moss_block
fill 26 240 612 28 240 614 minecraft:green_terracotta
fill 26 240 616 28 240 617 minecraft:moss_block
fill 26 240 624 28 240 626 minecraft:moss_block
fill 26 240 628 28 240 630 minecraft:green_terracotta
fill 26 240 632 28 240 634 minecraft:moss_block
fill 26 240 636 28 240 638 minecraft:green_terracotta
fill 26 240 640 28 240 642 minecraft:moss_block
fill 26 240 644 28 240 645 minecraft:green_terracotta
fill 26 240 646 32 241 646 minecraft:black_concrete
fill 27 240 619 27 240 621 minecraft:glowstone
setblock 28 240 618 minecraft:moss_block
fill 28 240 619 41 240 619 minecraft:dirt
fill 28 240 620 28 240 622 minecraft:green_terracotta
fill 29 240 605 29 240 606 minecraft:dirt
fill 29 240 608 29 240 610 minecraft:dirt
fill 29 240 612 29 240 614 minecraft:dirt
fill 29 240 616 29 240 618 minecraft:dirt
fill 29 240 620 29 240 622 minecraft:dirt
fill 29 240 624 29 240 626 minecraft:dirt
fill 29 240 628 29 240 630 minecraft:dirt
fill 29 240 632 29 240 634 minecraft:dirt
fill 29 240 636 29 240 638 minecraft:dirt
fill 29 240 640 29 240 642 minecraft:dirt
fill 29 240 644 29 240 645 minecraft:dirt
fill 30 240 605 32 240 606 minecraft:moss_block
fill 30 240 608 32 240 610 minecraft:green_terracotta
fill 30 240 612 32 240 614 minecraft:moss_block
fill 30 240 616 32 240 618 minecraft:green_terracotta
fill 30 240 620 32 240 622 minecraft:moss_block
fill 30 240 624 32 240 626 minecraft:green_terracotta
fill 30 240 628 32 240 630 minecraft:moss_block
fill 30 240 632 32 240 634 minecraft:green_terracotta
fill 30 240 636 32 240 638 minecraft:moss_block
fill 30 240 640 32 240 642 minecraft:green_terracotta
fill 30 240 644 32 240 645 minecraft:moss_block
fill 33 240 604 36 243 604 minecraft:black_concrete
fill 33 240 605 33 240 606 minecraft:dirt
fill 33 240 608 33 240 610 minecraft:dirt
fill 33 240 612 33 240 614 minecraft:dirt
fill 33 240 616 33 240 618 minecraft:dirt
fill 33 240 620 33 240 622 minecraft:dirt
fill 33 240 624 33 240 626 minecraft:dirt
fill 33 240 628 33 240 630 minecraft:dirt
fill 33 240 632 33 240 634 minecraft:dirt
fill 33 240 636 33 240 638 minecraft:dirt
fill 33 240 640 33 240 642 minecraft:dirt
fill 33 240 644 33 240 645 minecraft:dirt
fill 34 240 605 36 240 606 minecraft:green_terracotta
fill 34 240 608 36 240 610 minecraft:moss_block
fill 34 240 612 36 240 614 minecraft:green_terracotta
fill 34 240 616 36 240 618 minecraft:moss_block
fill 34 240 620 36 240 622 minecraft:green_terracotta
fill 34 240 624 36 240 626 minecraft:moss_block
fill 34 240 628 36 240 630 minecraft:green_terracotta
fill 34 240 632 36 240 634 minecraft:moss_block
fill 34 240 636 36 240 638 minecraft:green_terracotta
fill 34 240 640 36 240 642 minecraft:moss_block
fill 34 240 644 36 240 645 minecraft:green_terracotta
fill 34 240 646 37 240 646 minecraft:black_concrete
setblock 37 240 604 minecraft:diamond_block
fill 37 240 605 37 240 606 minecraft:dirt
fill 37 240 608 37 240 610 minecraft:dirt
fill 37 240 612 37 240 614 minecraft:dirt
fill 37 240 616 37 240 618 minecraft:dirt
fill 37 240 620 37 240 622 minecraft:dirt
fill 37 240 624 37 240 626 minecraft:dirt
fill 37 240 628 37 240 630 minecraft:dirt
fill 37 240 632 37 240 634 minecraft:dirt
fill 37 240 636 37 240 638 minecraft:dirt
fill 37 240 640 37 240 642 minecraft:dirt
fill 37 240 644 37 240 645 minecraft:dirt
fill 38 240 604 38 241 604 minecraft:black_concrete
fill 38 240 605 40 240 606 minecraft:moss_block
fill 38 240 608 40 240 610 minecraft:green_terracotta
fill 38 240 612 40 240 614 minecraft:moss_block
fill 38 240 616 40 240 618 minecraft:green_terracotta
fill 38 240 620 40 240 622 minecraft:moss_block
fill 38 240 624 40 240 626 minecraft:green_terracotta
fill 38 240 628 40 240 630 minecraft:moss_block
fill 38 240 632 40 240 634 minecraft:green_terracotta
fill 38 240 636 40 240 638 minecraft:moss_block
fill 38 240 640 40 240 642 minecraft:green_terracotta
fill 38 240 644 40 240 645 minecraft:moss_block
setblock 38 240 646 minecraft:white_concrete
fill 39 240 646 42 272 646 minecraft:black_concrete
fill 40 240 604 41 302 604 minecraft:black_concrete
fill 41 240 605 41 240 606 minecraft:dirt
fill 41 240 608 41 240 610 minecraft:dirt
fill 41 240 612 41 240 614 minecraft:dirt
fill 41 240 616 41 240 618 minecraft:dirt
fill 41 240 620 41 240 622 minecraft:dirt
fill 41 240 624 41 240 626 minecraft:dirt
fill 41 240 628 41 240 630 minecraft:dirt
fill 41 240 632 41 240 634 minecraft:dirt
fill 41 240 636 41 240 638 minecraft:dirt
fill 41 240 640 41 240 642 minecraft:dirt
fill 41 240 644 41 240 645 minecraft:dirt
setblock 42 240 604 minecraft:blue_concrete
fill 42 240 605 42 240 612 minecraft:black_concrete
fill 42 240 614 42 243 615 minecraft:black_concrete
fill 42 240 618 42 240 645 minecraft:black_concrete
fill 0 241 604 0 242 604 minecraft:blue_concrete
fill 0 241 605 0 241 609 minecraft:black_concrete
fill 0 241 610 0 241 611 minecraft:blue_concrete
fill 0 241 612 0 243 612 minecraft:black_concrete
setblock 0 241 613 minecraft:blue_concrete
setblock 0 241 614 minecraft:black_concrete
fill 0 241 615 0 242 615 minecraft:blue_concrete
fill 0 241 616 0 241 618 minecraft:black_concrete
setblock 0 241 619 minecraft:blue_concrete
fill 0 241 620 0 246 620 minecraft:black_concrete
fill 0 241 624 0 242 634 minecraft:black_concrete
setblock 0 241 635 minecraft:blue_concrete
fill 0 241 636 0 241 640 minecraft:black_concrete
setblock 0 241 646 minecraft:black_concrete
fill 1 241 604 16 241 604 minecraft:black_concrete
fill 4 241 646 4 261 646 minecraft:black_concrete
fill 5 241 646 6 241 646 minecraft:blue_concrete
fill 7 241 646 14 241 646 minecraft:black_concrete
setblock 17 241 604 minecraft:white_concrete
fill 18 241 604 20 241 604 minecraft:black_concrete
fill 19 241 646 19 307 646 minecraft:black_concrete
fill 25 241 646 25 262 646 minecraft:black_concrete
fill 32 241 604 32 245 604 minecraft:black_concrete
fill 33 241 646 34 259 646 minecraft:black_concrete
setblock 35 241 646 minecraft:blue_concrete
fill 36 241 646 36 288 646 minecraft:black_concrete
fill 37 241 604 37 287 604 minecraft:black_concrete
fill 37 241 646 37 242 646 minecraft:blue_concrete
fill 38 241 646 38 275 646 minecraft:black_concrete
fill 42 241 604 42 241 607 minecraft:black_concrete
setblock 42 241 608 minecraft:blue_concrete
fill 42 241 609 42 241 613 minecraft:black_concrete
fill 42 241 617 42 241 622 minecraft:black_concrete
setblock 42 241 623 minecraft:blue_concrete
fill 42 241 624 42 241 645 minecraft:black_concrete
fill 0 242 605 0 245 607 minecraft:black_concrete
setblock 0 242 608 minecraft:blue_concrete
fill 0 242 609 0 263 611 minecraft:black_concrete
setblock 0 242 613 minecraft:black_concrete
setblock 0 242 614 minecraft:blue_concrete
fill 0 242 616 0 298 616 minecraft:black_concrete
setblock 0 242 617 minecraft:blue_concrete
fill 0 242 618 0 307 619 minecraft:black_concrete
fill 0 242 621 0 262 621 minecraft:black_concrete
setblock 0 242 622 minecraft:blue_concrete
fill 0 242 623 0 287 623 minecraft:black_concrete
fill 0 242 635 0 252 638 minecraft:black_concrete
setblock 0 242 639 minecraft:blue_concrete
fill 0 242 640 0 268 640 minecraft:black_concrete
setblock 0 242 646 minecraft:blue_concrete
fill 1 242 604 7 242 604 minecraft:black_concrete
fill 1 242 646 1 254 646 minecraft:black_concrete
setblock 2 242 646 minecraft:blue_concrete
fill 3 242 646 3 307 646 minecraft:black_concrete
setblock 5 242 646 minecraft:white_concrete
fill 6 242 646 10 272 646 minecraft:black_concrete
setblock 8 242 604 minecraft:blue_concrete
fill 9 242 604 15 244 604 minecraft:black_concrete
setblock 11 242 646 minecraft:blue_concrete
fill 12 242 646 17 243 646 minecraft:black_concrete
setblock 16 242 604 minecraft:blue_concrete
fill 17 242 604 18 257 604 minecraft:black_concrete
setblock 18 242 646 minecraft:diamond_block
setblock 19 242 604 minecraft:blue_concrete
fill 20 242 604 20 243 604 minecraft:black_concrete
fill 26 242 646 29 243 646 minecraft:black_concrete
setblock 30 242 646 minecraft:blue_concrete
fill 31 242 646 31 295 646 minecraft:black_concrete
setblock 32 242 646 minecraft:blue_concrete
fill 35 242 646 35 257 646 minecraft:black_concrete
setblock 38 242 604 minecraft:blue_concrete
fill 39 242 604 39 307 604 minecraft:black_concrete
setblock 42 242 604 minecraft:blue_concrete
fill 42 242 605 42 256 605 minecraft:black_concrete
setblock 42 242 606 minecraft:blue_concrete
fill 42 242 607 42 253 611 minecraft:black_concrete
setblock 42 242 612 minecraft:blue_concrete
fill 42 242 613 42 245 613 minecraft:black_concrete
fill 42 242 617 42 307 618 minecraft:black_concrete
setblock 42 242 619 minecraft:glowstone
fill 42 242 620 42 243 640 minecraft:black_concrete
setblock 42 242 641 minecraft:blue_concrete
fill 42 242 642 42 244 644 minecraft:black_concrete
setblock 42 242 645 minecraft:blue_concrete
fill 0 243 604 0 307 604 minecraft:black_concrete
fill 0 243 608 0 294 608 minecraft:black_concrete
setblock 0 243 613 minecraft:white_concrete
fill 0 243 614 0 273 615 minecraft:black_concrete
fill 0 243 617 0 261 617 minecraft:black_concrete
fill 0 243 622 0 253 622 minecraft:black_concrete
fill 0 243 624 0 243 629 minecraft:black_concrete
setblock 0 243 630 minecraft:white_concrete
fill 0 243 631 0 244 634 minecraft:black_concrete
fill 0 243 639 0 276 639 minecraft:black_concrete
fill 0 243 643 0 287 643 minecraft:black_concrete
fill 0 243 646 0 307 646 minecraft:black_concrete
setblock 1 243 604 minecraft:diamond_block
fill 2 243 604 8 243 604 minecraft:black_concrete
fill 2 243 646 2 264 646 minecraft:black_concrete
setblock 3 243 607 minecraft:light[level=14]
setblock 3 243 615 minecraft:light[level=14]
setblock 3 243 623 minecraft:light[level=14]
setblock 3 243 631 minecraft:light[level=14]
setblock 3 243 639 minecraft:light[level=14]
fill 5 243 646 5 257 646 minecraft:black_concrete
setblock 11 243 607 minecraft:light[level=14]
setblock 11 243 615 minecraft:light[level=14]
setblock 11 243 623 minecraft:light[level=14]
setblock 11 243 631 minecraft:light[level=14]
setblock 11 243 639 minecraft:light[level=14]
fill 11 243 646 11 268 646 minecraft:black_concrete
fill 16 243 604 16 276 604 minecraft:black_concrete
fill 18 243 646 18 307 646 minecraft:black_concrete
fill 19 243 604 19 307 604 minecraft:black_concrete
setblock 19 243 607 minecraft:light[level=14]
setblock 19 243 615 minecraft:light[level=14]
setblock 19 243 623 minecraft:light[level=14]
setblock 19 243 631 minecraft:light[level=14]
setblock 19 243 639 minecraft:light[level=14]
fill 21 243 604 27 250 604 minecraft:black_concrete
setblock 27 243 607 minecraft:light[level=14]
setblock 27 243 615 minecraft:light[level=14]
setblock 27 243 623 minecraft:light[level=14]
setblock 27 243 631 minecraft:light[level=14]
setblock 27 243 639 minecraft:light[level=14]
setblock 28 243 604 minecraft:diamond_block
fill 29 243 604 31 256 604 minecraft:black_concrete
setblock 30 243 646 minecraft:black_concrete
fill 32 243 646 32 282 646 minecraft:black_concrete
setblock 35 243 607 minecraft:light[level=14]
setblock 35 243 615 minecraft:light[level=14]
setblock 35 243 623 minecraft:light[level=14]
setblock 35 243 631 minecraft:light[level=14]
setblock 35 243 639 minecraft:light[level=14]
fill 37 243 646 37 286 646 minecraft:black_concrete
fill 38 243 604 38 305 604 minecraft:black_concrete
fill 42 243 604 42 307 604 minecraft:black_concrete
fill 42 243 606 42 250 606 minecraft:black_concrete
fill 42 243 612 42 264 612 minecraft:black_concrete
fill 42 243 616 42 268 616 minecraft:black_concrete
fill 42 243 619 42 245 619 minecraft:black_concrete
fill 42 243 641 42 279 641 minecraft:black_concrete
fill 42 243 645 42 307 645 minecraft:black_concrete
fill 0 244 612 0 245 612 minecraft:moss_block
fill 0 244 613 0 258 613 minecraft:black_concrete
fill 0 244 624 0 251 627 minecraft:black_concrete
fill 0 244 628 0 245 628 minecraft:moss_block
fill 0 244 629 0 264 630 minecraft:black_concrete
fill 0 244 644 0 245 644 minecraft:moss_block
fill 0 244 645 0 307 645 minecraft:black_concrete
fill 1 244 604 3 268 604 minecraft:black_concrete
fill 4 244 604 4 245 604 minecraft:moss_block
fill 5 244 604 8 250 604 minecraft:black_concrete
fill 12 244 646 13 291 646 minecraft:black_concrete
fill 14 244 646 14 245 646 minecraft:moss_block
fill 15 244 646 17 262 646 minecraft:black_concrete
fill 20 244 604 20 245 604 minecraft:moss_block
fill 26 244 635 27 251 635 minecraft:dirt
fill 26 244 646 27 267 646 minecraft:black_concrete
fill 28 244 604 28 263 604 minecraft:black_concrete
setblock 28 244 646 minecraft:glowstone
fill 29 244 646 29 261 646 minecraft:black_concrete
fill 30 244 646 30 245 646 minecraft:moss_block
fill 33 244 604 35 257 604 minecraft:black_concrete
fill 36 244 604 36 245 604 minecraft:moss_block
fill 42 244 614 42 245 614 minecraft:moss_block
fill 42 244 615 42 250 615 minecraft:black_concrete
fill 42 244 620 42 246 629 minecraft:black_concrete
fill 42 244 630 42 245 630 minecraft:moss_block
fill 42 244 631 42 257 640 minecraft:black_concrete
fill 0 245 631 0 259 631 minecraft:black_concrete
setblock 0 245 632 minecraft:diamond_block
fill 0 245 633 0 246 634 minecraft:black_concrete
fill 9 245 604 9 300 604 minecraft:black_concrete
setblock 10 245 604 minecraft:glowstone
fill 11 245 604 15 250 604 minecraft:black_concrete
fill 26 245 636 27 251 636 minecraft:dirt
fill 28 245 646 28 251 646 minecraft:black_concrete
setblock 42 245 642 minecraft:glowstone
fill 42 245 643 42 267 644 minecraft:black_concrete
fill 0 246 605 0 260 606 minecraft:black_concrete
setblock 0 246 607 minecraft:glowstone
fill 0 246 612 0 251 612 minecraft:black_concrete
fill 0 246 628 0 251 628 minecraft:black_concrete
fill 0 246 632 0 255 632 minecraft:black_concrete
setblock 0 246 644 minecraft:black_concrete
fill 4 246 604 4 251 604 minecraft:black_concrete
fill 10 246 604 10 307 604 minecraft:black_concrete
fill 14 246 646 14 249 646 minecraft:black_concrete
fill 20 246 604 20 251 604 minecraft:black_concrete
fill 26 246 634 27 251 634 minecraft:dirt
fill 28 246 635 28 251 636 minecraft:dirt
fill 30 246 646 30 251 646 minecraft:black_concrete
setblock 32 246 604 minecraft:glowstone
fill 36 246 604 36 251 604 minecraft:black_concrete
setblock 42 246 613 minecraft:white_concrete
fill 42 246 614 42 251 614 minecraft:black_concrete
setblock 42 246 619 minecraft:diamond_block
fill 42 246 630 42 251 630 minecraft:black_concrete
fill 42 246 642 42 276 642 minecraft:black_concrete
fill 0 247 607 0 259 607 minecraft:black_concrete
setblock 0 247 620 minecraft:glowstone
fill 0 247 633 0 305 633 minecraft:black_concrete
setblock 0 247 634 minecraft:glowstone
setblock 0 247 644 minecraft:diamond_block
fill 8 247 639 8 247 644 minecraft:diamond_block
fill 23 247 607 24 248 607 minecraft:raw_iron_block
fill 25 247 634 25 251 636 minecraft:dirt
fill 26 247 637 27 251 637 minecraft:dirt
fill 28 247 634 28 251 634 minecraft:dirt
fill 32 247 604 32 254 604 minecraft:black_concrete
fill 42 247 613 42 277 613 minecraft:black_concrete
fill 42 247 619 42 250 626 minecraft:black_concrete
setblock 42 247 627 minecraft:diamond_block
fill 42 247 628 42 247 629 minecraft:black_concrete
fill 0 248 620 0 261 620 minecraft:black_concrete
fill 0 248 634 0 275 634 minecraft:black_concrete
fill 0 248 644 0 251 644 minecraft:black_concrete
fill 7 248 641 9 248 645 minecraft:diamond_block
setblock 8 248 640 minecraft:diamond_block
fill 20 248 646 21 305 646 minecraft:black_concrete
setblock 22 248 646 minecraft:white_concrete
fill 23 248 646 24 262 646 minecraft:black_concrete
fill 25 248 637 25 251 637 minecraft:dirt
fill 26 248 633 28 251 633 minecraft:dirt
fill 28 248 637 28 251 637 minecraft:dirt
fill 29 248 634 29 251 636 minecraft:dirt
fill 42 248 627 42 249 628 minecraft:black_concrete
setblock 42 248 629 minecraft:glowstone
fill 7 249 643 9 249 645 minecraft:diamond_block
setblock 8 249 642 minecraft:diamond_block
fill 22 249 646 22 256 646 minecraft:black_concrete
fill 24 249 634 24 251 636 minecraft:dirt
fill 25 249 633 25 251 633 minecraft:dirt
fill 26 249 638 27 251 638 minecraft:dirt
fill 29 249 637 29 251 637 minecraft:dirt
fill 42 249 629 42 298 629 minecraft:black_concrete
setblock 8 250 644 minecraft:diamond_block
setblock 14 250 646 minecraft:glowstone
fill 24 250 633 24 251 633 minecraft:dirt
fill 24 250 637 24 251 637 minecraft:dirt
fill 25 250 638 25 251 638 minecraft:dirt
fill 26 250 632 28 251 632 minecraft:dirt
fill 28 250 638 28 251 638 minecraft:dirt
fill 29 250 633 29 251 633 minecraft:dirt
fill 30 250 634 30 251 636 minecraft:dirt
setblock 42 250 627 minecraft:glowstone
fill 42 250 628 42 307 628 minecraft:black_concrete
setblock 3 251 607 minecraft:light[level=14]
setblock 3 251 615 minecraft:light[level=14]
setblock 3 251 623 minecraft:light[level=14]
setblock 3 251 631 minecraft:light[level=14]
setblock 3 251 639 minecraft:light[level=14]
fill 5 251 604 7 304 604 minecraft:black_concrete
setblock 8 251 604 minecraft:diamond_block
setblock 11 251 604 minecraft:diamond_block
setblock 11 251 607 minecraft:light[level=14]
setblock 11 251 615 minecraft:light[level=14]
setblock 11 251 623 minecraft:light[level=14]
setblock 11 251 631 minecraft:light[level=14]
setblock 11 251 639 minecraft:light[level=14]
fill 12 251 604 15 256 604 minecraft:black_concrete
setblock 14 251 646 minecraft:black_concrete
setblock 19 251 607 minecraft:light[level=14]
setblock 19 251 615 minecraft:light[level=14]
setblock 19 251 631 minecraft:light[level=14]
setblock 19 251 639 minecraft:light[level=14]
fill 21 251 604 23 259 604 minecraft:black_concrete
fill 23 251 634 23 251 636 minecraft:dirt
setblock 24 251 604 minecraft:white_concrete
setblock 24 251 638 minecraft:dirt
fill 25 251 604 27 262 604 minecraft:black_concrete
setblock 25 251 632 minecraft:dirt
fill 26 251 639 27 251 639 minecraft:dirt
setblock 27 251 607 minecraft:light[level=14]
setblock 27 251 615 minecraft:light[level=14]
setblock 27 251 623 minecraft:light[level=14]
setblock 27 251 631 minecraft:light[level=14]
setblock 29 251 632 minecraft:dirt
setblock 29 251 638 minecraft:dirt
setblock 30 251 633 minecraft:dirt
setblock 30 251 637 minecraft:dirt
setblock 35 251 607 minecraft:light[level=14]
setblock 35 251 615 minecraft:light[level=14]
setblock 35 251 623 minecraft:light[level=14]
setblock 35 251 631 minecraft:light[level=14]
setblock 35 251 639 minecraft:light[level=14]
setblock 42 251 606 minecraft:diamond_block
setblock 42 251 615 minecraft:white_concrete
fill 42 251 619 42 255 621 minecraft:black_concrete
setblock 42 251 622 minecraft:white_concrete
fill 42 251 623 42 253 627 minecraft:black_concrete
fill 0 252 612 0 254 612 minecraft:moss_block
setblock 0 252 624 minecraft:diamond_block
fill 0 252 625 0 254 627 minecraft:black_concrete
fill 0 252 628 0 254 628 minecraft:moss_block
fill 0 252 644 0 254 644 minecraft:moss_block
fill 4 252 604 4 254 604 minecraft:moss_block
fill 8 252 604 8 307 604 minecraft:black_concrete
fill 11 252 604 11 270 604 minecraft:black_concrete
fill 14 252 646 14 254 646 minecraft:moss_block
fill 20 252 604 20 254 604 minecraft:moss_block
fill 24 252 604 24 283 604 minecraft:black_concrete
fill 27 252 635 27 254 635 minecraft:stone
setblock 28 252 646 minecraft:white_concrete
fill 30 252 646 30 254 646 minecraft:moss_block
fill 36 252 604 36 254 604 minecraft:moss_block
fill 42 252 606 42 262 606 minecraft:black_concrete
fill 42 252 614 42 254 614 minecraft:moss_block
fill 42 252 615 42 255 615 minecraft:black_concrete
fill 42 252 622 42 267 622 minecraft:black_concrete
fill 42 252 630 42 254 630 minecraft:moss_block
fill 0 253 624 0 282 624 minecraft:black_concrete
fill 0 253 635 0 283 635 minecraft:black_concrete
setblock 0 253 636 minecraft:diamond_block
fill 0 253 637 0 277 638 minecraft:black_concrete
fill 28 253 646 28 272 646 minecraft:black_concrete
setblock 0 254 622 minecraft:glowstone
fill 0 254 636 0 262 636 minecraft:black_concrete
fill 42 254 607 42 272 610 minecraft:black_concrete
setblock 42 254 611 minecraft:white_concrete
setblock 42 254 623 minecraft:white_concrete
fill 42 254 624 42 259 627 minecraft:black_concrete
fill 0 255 612 0 260 612 minecraft:black_concrete
fill 0 255 622 0 264 622 minecraft:black_concrete
fill 0 255 625 0 265 626 minecraft:black_concrete
setblock 0 255 627 minecraft:white_concrete
fill 0 255 628 0 260 628 minecraft:black_concrete
fill 0 255 644 0 260 644 minecraft:black_concrete
setblock 1 255 646 minecraft:diamond_block
fill 4 255 604 4 260 604 minecraft:black_concrete
fill 14 255 646 14 260 646 minecraft:black_concrete
fill 20 255 604 20 258 604 minecraft:black_concrete
fill 25 255 635 28 257 636 minecraft:oak_leaves[persistent=true]
fill 26 255 634 28 257 634 minecraft:oak_leaves[persistent=true]
fill 26 255 637 27 257 637 minecraft:oak_leaves[persistent=true]
fill 30 255 646 30 260 646 minecraft:black_concrete
setblock 32 255 604 minecraft:white_concrete
fill 36 255 604 36 260 604 minecraft:black_concrete
fill 42 255 611 42 307 611 minecraft:black_concrete
fill 42 255 614 42 260 614 minecraft:black_concrete
fill 42 255 623 42 263 623 minecraft:black_concrete
fill 42 255 630 42 260 630 minecraft:black_concrete
fill 0 256 627 0 262 627 minecraft:black_concrete
setblock 0 256 632 minecraft:diamond_block
fill 1 256 646 1 307 646 minecraft:black_concrete
setblock 25 256 634 minecraft:oak_leaves[persistent=true]
fill 26 256 633 27 256 633 minecraft:oak_leaves[persistent=true]
setblock 28 256 637 minecraft:oak_leaves[persistent=true]
setblock 29 256 635 minecraft:oak_leaves[persistent=true]
fill 32 256 604 32 307 604 minecraft:black_concrete
setblock 42 256 615 minecraft:white_concrete
setblock 42 256 619 minecraft:white_concrete
fill 42 256 620 42 291 621 minecraft:black_concrete
fill 0 257 632 0 269 632 minecraft:black_concrete
fill 12 257 604 14 307 604 minecraft:black_concrete
setblock 15 257 604 minecraft:white_concrete
setblock 22 257 646 minecraft:diamond_block
fill 29 257 604 30 257 604 minecraft:black_concrete
setblock 31 257 604 minecraft:glowstone
setblock 42 257 605 minecraft:diamond_block
fill 42 257 615 42 291 615 minecraft:black_concrete
fill 42 257 619 42 260 619 minecraft:black_concrete
setblock 5 258 646 minecraft:diamond_block
fill 15 258 604 15 307 604 minecraft:black_concrete
setblock 17 258 604 minecraft:glowstone
fill 18 258 604 18 307 604 minecraft:black_concrete
fill 22 258 646 22 272 646 minecraft:black_concrete
fill 29 258 604 29 287 604 minecraft:black_concrete
setblock 30 258 604 minecraft:diamond_block
fill 31 258 604 31 307 604 minecraft:black_concrete
fill 33 258 604 34 276 604 minecraft:black_concrete
setblock 35 258 604 minecraft:diamond_block
setblock 35 258 646 minecraft:glowstone
fill 42 258 605 42 276 605 minecraft:black_concrete
fill 42 258 631 42 260 639 minecraft:black_concrete
setblock 42 258 640 minecraft:white_concrete
setblock 0 259 613 minecraft:diamond_block
setblock 3 259 607 minecraft:light[level=14]
setblock 3 259 615 minecraft:light[level=14]
setblock 3 259 623 minecraft:light[level=14]
setblock 3 259 631 minecraft:light[level=14]
setblock 3 259 639 minecraft:light[level=14]
fill 5 259 646 5 307 646 minecraft:black_concrete
setblock 11 259 607 minecraft:light[level=14]
setblock 11 259 615 minecraft:light[level=14]
setblock 11 259 623 minecraft:light[level=14]
setblock 11 259 631 minecraft:light[level=14]
setblock 11 259 639 minecraft:light[level=14]
fill 17 259 604 17 284 604 minecraft:black_concrete
setblock 19 259 607 minecraft:light[level=14]
setblock 19 259 615 minecraft:light[level=14]
setblock 19 259 631 minecraft:light[level=14]
setblock 19 259 639 minecraft:light[level=14]
setblock 20 259 604 minecraft:diamond_block
setblock 27 259 607 minecraft:light[level=14]
setblock 27 259 615 minecraft:light[level=14]
setblock 27 259 623 minecraft:light[level=14]
setblock 27 259 631 minecraft:light[level=14]
setblock 27 259 639 minecraft:light[level=14]
fill 30 259 604 30 307 604 minecraft:black_concrete
fill 35 259 604 35 297 604 minecraft:black_concrete
setblock 35 259 607 minecraft:light[level=14]
setblock 35 259 615 minecraft:light[level=14]
setblock 35 259 623 minecraft:light[level=14]
setblock 35 259 631 minecraft:light[level=14]
setblock 35 259 639 minecraft:light[level=14]
fill 35 259 646 35 307 646 minecraft:black_concrete
fill 42 259 640 42 271 640 minecraft:black_concrete
setblock 0 260 607 minecraft:diamond_block
fill 0 260 613 0 263 613 minecraft:black_concrete
setblock 0 260 631 minecraft:glowstone
setblock 20 260 604 minecraft:black_concrete
setblock 21 260 604 minecraft:diamond_block
fill 22 260 604 23 273 604 minecraft:black_concrete
setblock 33 260 646 minecraft:glowstone
fill 34 260 646 34 265 646 minecraft:black_concrete
setblock 42 260 624 minecraft:glowstone
fill 42 260 625 42 270 627 minecraft:black_concrete
setblock 0 261 605 minecraft:glowstone
fill 0 261 606 0 285 607 minecraft:black_concrete
fill 0 261 612 0 263 612 minecraft:moss_block
fill 0 261 628 0 263 628 minecraft:moss_block
fill 0 261 631 0 271 631 minecraft:black_concrete
fill 0 261 644 0 263 644 minecraft:moss_block
fill 4 261 604 4 263 604 minecraft:moss_block
fill 14 261 646 14 263 646 minecraft:moss_block
fill 20 261 604 20 263 604 minecraft:moss_block
fill 21 261 604 21 292 604 minecraft:black_concrete
fill 30 261 646 30 263 646 minecraft:moss_block
fill 33 261 646 33 307 646 minecraft:black_concrete
fill 36 261 604 36 263 604 minecraft:moss_block
fill 42 261 614 42 263 614 minecraft:moss_block
setblock 42 261 619 minecraft:diamond_block
fill 42 261 624 42 263 624 minecraft:black_concrete
fill 42 261 630 42 263 630 minecraft:moss_block
fill 42 261 631 42 301 632 minecraft:black_concrete
setblock 42 261 633 minecraft:glowstone
fill 42 261 634 42 271 639 minecraft:black_concrete
fill 0 262 605 0 283 605 minecraft:black_concrete
setblock 0 262 617 minecraft:white_concrete
setblock 0 262 620 minecraft:white_concrete
setblock 4 262 646 minecraft:diamond_block
setblock 29 262 646 minecraft:glowstone
fill 42 262 619 42 279 619 minecraft:black_concrete
fill 42 262 633 42 306 633 minecraft:black_concrete
fill 0 263 617 0 307 617 minecraft:black_concrete
fill 0 263 620 0 277 620 minecraft:black_concrete
setblock 0 263 621 minecraft:diamond_block
setblock 0 263 627 minecraft:white_concrete
setblock 0 263 636 minecraft:glowstone
fill 4 263 646 4 271 646 minecraft:black_concrete
fill 15 263 646 16 282 646 minecraft:black_concrete
setblock 17 263 646 minecraft:glowstone
setblock 23 263 646 minecraft:glowstone
fill 24 263 646 24 284 646 minecraft:black_concrete
fill 25 263 604 25 265 604 minecraft:black_concrete
setblock 25 263 646 minecraft:white_concrete
setblock 26 263 604 minecraft:white_concrete
fill 27 263 604 27 307 604 minecraft:black_concrete
fill 29 263 646 29 307 646 minecraft:black_concrete
setblock 42 263 606 minecraft:white_concrete
fill 0 264 609 0 307 609 minecraft:black_concrete
setblock 0 264 610 minecraft:glowstone
fill 0 264 611 0 269 612 minecraft:black_concrete
setblock 0 264 613 minecraft:glowstone
fill 0 264 621 0 285 621 minecraft:black_concrete
fill 0 264 627 0 269 628 minecraft:black_concrete
fill 0 264 636 0 307 636 minecraft:black_concrete
fill 0 264 644 0 269 644 minecraft:black_concrete
fill 4 264 604 4 269 604 minecraft:black_concrete
fill 14 264 646 14 269 646 minecraft:black_concrete
fill 17 264 646 17 279 646 minecraft:black_concrete
fill 20 264 604 20 269 604 minecraft:black_concrete
fill 23 264 646 23 307 646 minecraft:black_concrete
setblock 25 264 646 minecraft:diamond_block
fill 26 264 604 26 291 604 minecraft:black_concrete
setblock 28 264 604 minecraft:glowstone
fill 30 264 646 30 269 646 minecraft:black_concrete
fill 36 264 604 36 269 604 minecraft:black_concrete
fill 42 264 606 42 307 606 minecraft:black_concrete
fill 42 264 614 42 269 614 minecraft:black_concrete
fill 42 264 623 42 264 624 minecraft:glowstone
fill 42 264 630 42 269 630 minecraft:black_concrete
fill 0 265 610 0 307 610 minecraft:black_concrete
fill 0 265 613 0 281 613 minecraft:black_concrete
setblock 0 265 622 minecraft:white_concrete
fill 0 265 629 0 298 629 minecraft:black_concrete
setblock 0 265 630 minecraft:white_concrete
setblock 2 265 646 minecraft:glowstone
fill 25 265 646 25 307 646 minecraft:black_concrete
fill 28 265 604 28 307 604 minecraft:black_concrete
setblock 42 265 612 minecraft:glowstone
fill 42 265 623 42 307 624 minecraft:black_concrete
fill 0 266 622 0 296 622 minecraft:black_concrete
fill 0 266 625 0 278 625 minecraft:black_concrete
setblock 0 266 626 minecraft:diamond_block
fill 0 266 630 0 307 630 minecraft:black_concrete
fill 2 266 646 2 303 646 minecraft:black_concrete
setblock 25 266 604 minecraft:glowstone
fill 27 266 619 28 267 620 minecraft:dirt
fill 29 266 619 29 267 619 minecraft:dirt
setblock 34 266 646 minecraft:white_concrete
fill 42 266 612 42 298 612 minecraft:black_concrete
fill 0 267 626 0 297 626 minecraft:black_concrete
fill 0 267 641 0 307 641 minecraft:black_concrete
setblock 0 267 642 minecraft:white_concrete
setblock 3 267 607 minecraft:light[level=14]
setblock 3 267 615 minecraft:light[level=14]
setblock 3 267 623 minecraft:light[level=14]
setblock 3 267 631 minecraft:light[level=14]
setblock 3 267 639 minecraft:light[level=14]
setblock 11 267 607 minecraft:light[level=14]
setblock 11 267 615 minecraft:light[level=14]
setblock 11 267 623 minecraft:light[level=14]
setblock 11 267 631 minecraft:light[level=14]
setblock 11 267 639 minecraft:light[level=14]
setblock 19 267 607 minecraft:light[level=14]
setblock 19 267 615 minecraft:light[level=14]
setblock 19 267 631 minecraft:light[level=14]
setblock 19 267 639 minecraft:light[level=14]
fill 25 267 604 25 307 604 minecraft:black_concrete
setblock 27 267 607 minecraft:light[level=14]
setblock 27 267 615 minecraft:light[level=14]
setblock 27 267 623 minecraft:light[level=14]
setblock 27 267 631 minecraft:light[level=14]
setblock 27 267 639 minecraft:light[level=14]
fill 34 267 646 34 270 646 minecraft:black_concrete
setblock 35 267 607 minecraft:light[level=14]
setblock 35 267 615 minecraft:light[level=14]
setblock 35 267 623 minecraft:light[level=14]
setblock 35 267 631 minecraft:light[level=14]
setblock 35 267 639 minecraft:light[level=14]
fill 0 268 642 0 307 642 minecraft:black_concrete
setblock 26 268 646 minecraft:white_concrete
fill 27 268 646 27 307 646 minecraft:black_concrete
setblock 42 268 622 minecraft:white_concrete
fill 42 268 643 42 297 643 minecraft:black_concrete
setblock 42 268 644 minecraft:diamond_block
setblock 0 269 640 minecraft:diamond_block
fill 1 269 604 1 288 604 minecraft:black_concrete
setblock 2 269 604 minecraft:white_concrete
fill 3 269 604 3 300 604 minecraft:black_concrete
setblock 11 269 646 minecraft:diamond_block
fill 20 269 637 21 270 638 minecraft:dirt
fill 21 269 636 21 270 636 minecraft:dirt
setblock 26 269 646 minecraft:diamond_block
setblock 42 269 616 minecraft:diamond_block
fill 42 269 622 42 307 622 minecraft:black_concrete
fill 42 269 644 42 277 644 minecraft:black_concrete
fill 0 270 611 0 296 611 minecraft:black_concrete
fill 0 270 612 0 272 612 minecraft:moss_block
fill 0 270 627 0 307 627 minecraft:black_concrete
fill 0 270 628 0 272 628 minecraft:moss_block
setblock 0 270 632 minecraft:diamond_block
fill 0 270 640 0 284 640 minecraft:black_concrete
fill 0 270 644 0 272 644 minecraft:moss_block
fill 2 270 604 2 307 604 minecraft:black_concrete
fill 4 270 604 4 272 604 minecraft:moss_block
fill 11 270 646 11 300 646 minecraft:black_concrete
fill 14 270 646 14 272 646 minecraft:moss_block
fill 20 270 604 20 272 604 minecraft:moss_block
fill 26 270 646 26 307 646 minecraft:black_concrete
fill 30 270 646 30 272 646 minecraft:moss_block
fill 36 270 604 36 272 604 minecraft:moss_block
fill 42 270 614 42 272 614 minecraft:moss_block
fill 42 270 616 42 307 616 minecraft:black_concrete
fill 42 270 630 42 272 630 minecraft:moss_block
fill 0 271 632 0 278 632 minecraft:black_concrete
setblock 11 271 604 minecraft:glowstone
setblock 34 271 646 minecraft:white_concrete
fill 42 271 625 42 307 626 minecraft:black_concrete
setblock 42 271 627 minecraft:glowstone
setblock 0 272 631 minecraft:glowstone
setblock 4 272 646 minecraft:white_concrete
fill 11 272 604 11 307 604 minecraft:black_concrete
fill 26 272 613 27 273 613 minecraft:raw_iron_block
fill 34 272 646 34 277 646 minecraft:black_concrete
fill 42 272 627 42 307 627 minecraft:black_concrete
fill 42 272 634 42 307 635 minecraft:black_concrete
setblock 42 272 636 minecraft:white_concrete
fill 42 272 637 42 298 639 minecraft:black_concrete
setblock 42 272 640 minecraft:white_concrete
fill 0 273 612 0 287 612 minecraft:black_concrete
fill 0 273 628 0 287 628 minecraft:black_concrete
fill 0 273 631 0 301 631 minecraft:black_concrete
fill 0 273 644 0 287 644 minecraft:black_concrete
fill 4 273 604 4 287 604 minecraft:black_concrete
fill 4 273 646 4 307 646 minecraft:black_concrete
fill 6 273 646 8 284 646 minecraft:black_concrete
setblock 9 273 646 minecraft:diamond_block
fill 10 273 646 10 307 646 minecraft:black_concrete
fill 14 273 646 14 274 646 minecraft:black_concrete
fill 20 273 604 20 283 604 minecraft:black_concrete
setblock 22 273 646 minecraft:glowstone
setblock 28 273 646 minecraft:glowstone
fill 30 273 646 30 287 646 minecraft:black_concrete
setblock 36 273 604 minecraft:black_concrete
setblock 39 273 646 minecraft:diamond_block
fill 40 273 646 42 285 646 minecraft:black_concrete
fill 42 273 607 42 274 609 minecraft:black_concrete
setblock 42 273 610 minecraft:diamond_block
fill 42 273 614 42 287 614 minecraft:black_concrete
fill 42 273 630 42 279 630 minecraft:black_concrete
fill 42 273 636 42 307 636 minecraft:black_concrete
fill 42 273 640 42 307 640 minecraft:black_concrete
setblock 0 274 614 minecraft:glowstone
fill 0 274 615 0 298 615 minecraft:black_concrete
fill 9 274 646 9 278 646 minecraft:black_concrete
setblock 22 274 604 minecraft:white_concrete
fill 22 274 646 22 277 646 minecraft:black_concrete
fill 23 274 604 23 275 604 minecraft:black_concrete
fill 28 274 646 28 307 646 minecraft:black_concrete
setblock 36 274 604 minecraft:glowstone
fill 39 274 646 39 307 646 minecraft:black_concrete
fill 42 274 610 42 307 610 minecraft:black_concrete
fill 0 275 614 0 280 614 minecraft:black_concrete
setblock 3 275 607 minecraft:light[level=14]
setblock 3 275 615 minecraft:light[level=14]
setblock 3 275 623 minecraft:light[level=14]
setblock 3 275 631 minecraft:light[level=14]
setblock 3 275 639 minecraft:light[level=14]
setblock 11 275 607 minecraft:light[level=14]
setblock 11 275 615 minecraft:light[level=14]
setblock 11 275 623 minecraft:light[level=14]
setblock 11 275 631 minecraft:light[level=14]
setblock 11 275 639 minecraft:light[level=14]
setblock 14 275 646 minecraft:white_concrete
setblock 19 275 607 minecraft:light[level=14]
setblock 19 275 615 minecraft:light[level=14]
setblock 19 275 631 minecraft:light[level=14]
setblock 19 275 639 minecraft:light[level=14]
fill 22 275 604 22 289 604 minecraft:black_concrete
setblock 27 275 607 minecraft:light[level=14]
setblock 27 275 615 minecraft:light[level=14]
setblock 27 275 623 minecraft:light[level=14]
setblock 27 275 631 minecraft:light[level=14]
setblock 27 275 639 minecraft:light[level=14]
setblock 35 275 607 minecraft:light[level=14]
setblock 35 275 615 minecraft:light[level=14]
setblock 35 275 623 minecraft:light[level=14]
setblock 35 275 631 minecraft:light[level=14]
setblock 35 275 639 minecraft:light[level=14]
setblock 36 275 604 minecraft:black_concrete
fill 42 275 607 42 279 608 minecraft:black_concrete
setblock 42 275 609 minecraft:glowstone
setblock 0 276 634 minecraft:glowstone
fill 14 276 646 14 287 646 minecraft:black_concrete
setblock 23 276 604 minecraft:diamond_block
setblock 36 276 604 minecraft:glowstone
setblock 38 276 646 minecraft:glowstone
fill 42 276 609 42 277 609 minecraft:black_concrete
fill 0 277 634 0 301 634 minecraft:black_concrete
setblock 0 277 639 minecraft:glowstone
setblock 16 277 604 minecraft:diamond_block
fill 23 277 604 23 307 604 minecraft:black_concrete
setblock 33 277 604 minecraft:glowstone
fill 34 277 604 34 307 604 minecraft:black_concrete
fill 36 277 604 36 287 604 minecraft:black_concrete
fill 38 277 646 38 307 646 minecraft:black_concrete
setblock 42 277 605 minecraft:diamond_block
setblock 42 277 642 minecraft:diamond_block
setblock 0 278 620 minecraft:glowstone
fill 0 278 637 0 300 637 minecraft:black_concrete
setblock 0 278 638 minecraft:diamond_block
fill 0 278 639 0 287 639 minecraft:black_concrete
fill 14 278 626 16 278 628 minecraft:redstone_block
fill 15 278 619 17 278 621 minecraft:redstone_block
fill 16 278 604 16 307 604 minecraft:black_concrete
fill 22 278 620 24 278 622 minecraft:redstone_block
setblock 22 278 646 minecraft:white_concrete
fill 33 278 604 33 279 604 minecraft:black_concrete
setblock 34 278 646 minecraft:diamond_block
fill 42 278 605 42 279 605 minecraft:black_concrete
setblock 42 278 609 minecraft:white_concrete
setblock 42 278 613 minecraft:white_concrete
fill 42 278 642 42 307 642 minecraft:black_concrete
setblock 42 278 644 minecraft:diamond_block
fill 0 279 620 0 307 620 minecraft:black_concrete
setblock 0 279 625 minecraft:white_concrete
setblock 0 279 632 minecraft:white_concrete
fill 0 279 638 0 296 638 minecraft:black_concrete
fill 1 279 605 2 280 606 minecraft:light_blue_wool
fill 1 279 607 2 280 612 minecraft:white_wool
fill 1 279 613 2 280 615 minecraft:light_blue_wool
fill 1 279 616 2 280 621 minecraft:white_wool
fill 1 279 622 2 280 624 minecraft:light_blue_wool
fill 1 279 625 2 280 630 minecraft:white_wool
fill 1 279 631 2 280 633 minecraft:light_blue_wool
fill 1 279 634 2 280 639 minecraft:white_wool
fill 1 279 640 2 280 642 minecraft:light_blue_wool
fill 1 279 643 5 280 645 minecraft:white_wool
fill 3 279 605 5 280 609 minecraft:white_wool
fill 3 279 610 5 280 612 minecraft:light_blue_wool
fill 3 279 613 5 280 618 minecraft:white_wool
fill 3 279 619 5 280 621 minecraft:light_blue_wool
fill 3 279 622 5 280 627 minecraft:white_wool
fill 3 279 628 5 280 630 minecraft:light_blue_wool
fill 3 279 631 5 280 636 minecraft:white_wool
fill 3 279 637 5 280 639 minecraft:light_blue_wool
fill 3 279 640 8 280 642 minecraft:white_wool
fill 6 279 605 8 280 606 minecraft:white_wool
fill 6 279 607 8 280 609 minecraft:light_blue_wool
fill 6 279 610 8 280 615 minecraft:white_wool
fill 6 279 616 8 280 618 minecraft:light_blue_wool
fill 6 279 619 8 280 624 minecraft:white_wool
fill 6 279 625 8 280 627 minecraft:light_blue_wool
fill 6 279 628 8 280 633 minecraft:white_wool
fill 6 279 634 8 280 636 minecraft:light_blue_wool
fill 6 279 637 11 280 639 minecraft:white_wool
fill 6 279 643 8 280 645 minecraft:light_blue_wool
fill 9 279 605 11 280 606 minecraft:light_blue_wool
fill 9 279 607 11 280 612 minecraft:white_wool
fill 9 279 613 11 280 615 minecraft:light_blue_wool
fill 9 279 616 11 280 621 minecraft:white_wool
fill 9 279 622 11 280 624 minecraft:light_blue_wool
fill 9 279 625 11 280 630 minecraft:white_wool
fill 9 279 631 11 280 633 minecraft:light_blue_wool
fill 9 279 634 14 280 636 minecraft:white_wool
fill 9 279 640 11 280 642 minecraft:light_blue_wool
fill 9 279 643 14 280 645 minecraft:white_wool
setblock 9 279 646 minecraft:glowstone
fill 12 279 605 14 280 609 minecraft:white_wool
fill 12 279 610 14 280 612 minecraft:light_blue_wool
fill 12 279 613 14 279 618 minecraft:white_wool
fill 12 279 619 14 279 621 minecraft:light_blue_wool
fill 12 279 622 13 279 627 minecraft:white_wool
fill 12 279 628 13 279 630 minecraft:light_blue_wool
fill 12 279 631 17 280 633 minecraft:white_wool
fill 12 279 637 14 280 639 minecraft:light_blue_wool
fill 12 279 640 17 280 642 minecraft:white_wool
fill 14 279 622 14 279 625 minecraft:white_wool
fill 14 279 629 14 279 630 minecraft:light_blue_wool
fill 15 279 605 17 280 606 minecraft:white_wool
fill 15 279 607 17 280 609 minecraft:light_blue_wool
fill 15 279 610 17 280 615 minecraft:white_wool
fill 15 279 616 17 279 618 minecraft:light_blue_wool
fill 15 279 622 17 279 624 minecraft:white_wool
fill 15 279 625 17 279 625 minecraft:light_blue_wool
fill 15 279 629 20 279 630 minecraft:white_wool
fill 15 279 634 17 280 636 minecraft:light_blue_wool
fill 15 279 637 20 280 639 minecraft:white_wool
fill 15 279 643 17 280 645 minecraft:light_blue_wool
fill 17 279 626 17 279 627 minecraft:light_blue_wool
fill 17 279 628 20 279 628 minecraft:white_wool
fill 18 279 605 20 280 606 minecraft:light_blue_wool
fill 18 279 607 20 280 612 minecraft:white_wool
fill 18 279 613 20 280 615 minecraft:light_blue_wool
fill 18 279 616 20 279 621 minecraft:white_wool
fill 18 279 622 20 279 622 minecraft:light_blue_wool
fill 18 279 626 23 279 627 minecraft:white_wool
fill 18 279 631 20 280 633 minecraft:light_blue_wool
fill 18 279 634 23 280 636 minecraft:white_wool
fill 18 279 640 20 280 642 minecraft:light_blue_wool
fill 18 279 643 23 280 645 minecraft:white_wool
fill 21 279 605 23 280 609 minecraft:white_wool
fill 21 279 610 23 280 612 minecraft:light_blue_wool
fill 21 279 613 23 280 618 minecraft:white_wool
fill 21 279 619 21 279 621 minecraft:light_blue_wool
fill 21 279 622 21 279 625 minecraft:white_wool
fill 21 279 628 23 280 630 minecraft:light_blue_wool
fill 21 279 631 26 280 633 minecraft:white_wool
fill 21 279 637 23 280 639 minecraft:light_blue_wool
fill 21 279 640 26 280 642 minecraft:white_wool
fill 22 279 619 23 279 619 minecraft:light_blue_wool
fill 22 279 623 23 279 625 minecraft:white_wool
fill 22 279 646 22 307 646 minecraft:black_concrete
fill 24 279 605 26 280 606 minecraft:white_wool
fill 24 279 607 26 280 609 minecraft:light_blue_wool
fill 24 279 610 26 280 615 minecraft:white_wool
fill 24 279 616 26 280 618 minecraft:light_blue_wool
fill 24 279 619 29 279 619 minecraft:white_wool
fill 24 279 623 26 279 624 minecraft:white_wool
fill 24 279 625 26 280 627 minecraft:light_blue_wool
fill 24 279 628 29 280 630 minecraft:white_wool
fill 24 279 634 26 280 636 minecraft:light_blue_wool
fill 24 279 637 29 280 639 minecraft:white_wool
fill 24 279 643 26 280 645 minecraft:light_blue_wool
fill 25 279 620 26 279 622 minecraft:white_wool
fill 27 279 605 29 280 606 minecraft:light_blue_wool
fill 27 279 607 29 280 612 minecraft:white_wool
fill 27 279 613 29 280 615 minecraft:light_blue_wool
fill 27 279 616 32 280 618 minecraft:white_wool
fill 27 279 620 29 280 621 minecraft:white_wool
fill 27 279 622 29 280 624 minecraft:light_blue_wool
fill 27 279 625 32 280 627 minecraft:white_wool
fill 27 279 631 29 280 633 minecraft:light_blue_wool
fill 27 279 634 32 280 636 minecraft:white_wool
fill 27 279 640 29 280 642 minecraft:light_blue_wool
fill 27 279 643 32 280 645 minecraft:white_wool
fill 30 279 605 32 280 609 minecraft:white_wool
fill 30 279 610 32 280 612 minecraft:light_blue_wool
fill 30 279 613 35 280 615 minecraft:white_wool
fill 30 279 619 32 280 621 minecraft:light_blue_wool
fill 30 279 622 35 280 624 minecraft:white_wool
fill 30 279 628 32 280 630 minecraft:light_blue_wool
fill 30 279 631 35 280 633 minecraft:white_wool
fill 30 279 637 32 280 639 minecraft:light_blue_wool
fill 30 279 640 35 280 642 minecraft:white_wool
fill 33 279 605 35 280 606 minecraft:white_wool
fill 33 279 607 35 280 609 minecraft:light_blue_wool
fill 33 279 610 38 280 612 minecraft:white_wool
fill 33 279 616 35 280 618 minecraft:light_blue_wool
fill 33 279 619 38 280 621 minecraft:white_wool
fill 33 279 625 35 280 627 minecraft:light_blue_wool
fill 33 279 628 38 280 630 minecraft:white_wool
fill 33 279 634 35 280 636 minecraft:light_blue_wool
fill 33 279 637 38 280 639 minecraft:white_wool
fill 33 279 643 35 280 645 minecraft:light_blue_wool
fill 34 279 646 34 307 646 minecraft:black_concrete
fill 36 279 605 38 280 606 minecraft:light_blue_wool
fill 36 279 607 41 280 609 minecraft:white_wool
fill 36 279 613 38 280 615 minecraft:light_blue_wool
fill 36 279 616 41 280 618 minecraft:white_wool
fill 36 279 622 38 280 624 minecraft:light_blue_wool
fill 36 279 625 41 280 627 minecraft:white_wool
fill 36 279 631 38 280 633 minecraft:light_blue_wool
fill 36 279 634 41 280 636 minecraft:white_wool
fill 36 279 640 38 280 642 minecraft:light_blue_wool
fill 36 279 643 41 280 645 minecraft:white_wool
fill 39 279 605 41 280 606 minecraft:white_wool
fill 39 279 610 41 280 612 minecraft:light_blue_wool
fill 39 279 613 41 280 615 minecraft:white_wool
fill 39 279 619 41 280 621 minecraft:light_blue_wool
fill 39 279 622 41 280 624 minecraft:white_wool
fill 39 279 628 41 280 630 minecraft:light_blue_wool
fill 39 279 631 41 280 633 minecraft:white_wool
fill 39 279 637 41 280 639 minecraft:light_blue_wool
fill 39 279 640 41 280 642 minecraft:white_wool
fill 42 279 609 42 296 609 minecraft:black_concrete
fill 42 279 613 42 307 613 minecraft:black_concrete
fill 42 279 644 42 307 644 minecraft:black_concrete
fill 0 280 625 0 307 625 minecraft:black_concrete
fill 0 280 632 0 307 632 minecraft:black_concrete
fill 9 280 646 9 307 646 minecraft:black_concrete
fill 12 280 613 13 280 618 minecraft:white_wool
fill 12 280 619 13 280 621 minecraft:light_blue_wool
fill 12 280 622 12 280 627 minecraft:white_wool
fill 12 280 628 12 280 630 minecraft:light_blue_wool
fill 13 280 622 13 280 624 minecraft:white_wool
fill 13 280 625 13 280 629 minecraft:glowstone
fill 13 280 630 14 280 630 minecraft:light_blue_wool
fill 14 280 613 14 280 617 minecraft:white_wool
fill 14 280 618 14 280 622 minecraft:glowstone
fill 14 280 623 16 280 624 minecraft:white_wool
fill 14 280 625 17 280 625 minecraft:glowstone
fill 14 280 626 16 280 628 minecraft:white_wool
fill 14 280 629 17 280 629 minecraft:glowstone
fill 15 280 616 17 280 617 minecraft:light_blue_wool
fill 15 280 618 18 280 618 minecraft:glowstone
fill 15 280 619 17 280 621 minecraft:white_wool
fill 15 280 622 21 280 622 minecraft:glowstone
fill 15 280 630 20 280 630 minecraft:white_wool
fill 17 280 623 17 280 624 minecraft:glowstone
fill 17 280 626 17 280 628 minecraft:glowstone
setblock 17 280 646 minecraft:glowstone
fill 18 280 616 20 280 617 minecraft:white_wool
fill 18 280 619 18 280 621 minecraft:glowstone
fill 18 280 626 21 280 626 minecraft:glowstone
fill 18 280 627 20 280 629 minecraft:white_wool
fill 19 280 618 20 280 621 minecraft:white_wool
fill 21 280 619 21 280 621 minecraft:glowstone
fill 21 280 623 21 280 625 minecraft:glowstone
fill 21 280 627 23 280 627 minecraft:white_wool
fill 22 280 619 25 280 619 minecraft:glowstone
fill 22 280 620 24 280 622 minecraft:white_wool
fill 22 280 623 25 280 623 minecraft:glowstone
fill 22 280 624 23 280 626 minecraft:white_wool
fill 24 280 624 26 280 624 minecraft:white_wool
fill 25 280 620 25 280 622 minecraft:glowstone
fill 26 280 619 26 280 623 minecraft:white_wool
fill 27 280 619 29 280 619 minecraft:white_wool
setblock 33 280 604 minecraft:glowstone
setblock 42 280 605 minecraft:glowstone
setblock 42 280 607 minecraft:white_concrete
fill 42 280 608 42 307 608 minecraft:black_concrete
setblock 42 280 619 minecraft:white_concrete
setblock 42 280 630 minecraft:diamond_block
setblock 42 280 641 minecraft:white_concrete
setblock 0 281 614 minecraft:glowstone
fill 17 281 646 17 307 646 minecraft:black_concrete
fill 33 281 604 33 285 604 minecraft:black_concrete
fill 42 281 605 42 307 605 minecraft:black_concrete
fill 42 281 607 42 307 607 minecraft:black_concrete
fill 42 281 619 42 303 619 minecraft:black_concrete
fill 42 281 630 42 287 630 minecraft:black_concrete
fill 42 281 641 42 307 641 minecraft:black_concrete
setblock 0 282 613 minecraft:white_concrete
fill 0 282 614 0 289 614 minecraft:black_concrete
fill 0 283 613 0 307 613 minecraft:black_concrete
setblock 0 283 624 minecraft:glowstone
setblock 3 283 607 minecraft:light[level=14]
setblock 3 283 615 minecraft:light[level=14]
setblock 3 283 623 minecraft:light[level=14]
setblock 3 283 631 minecraft:light[level=14]
setblock 3 283 639 minecraft:light[level=14]
setblock 11 283 607 minecraft:light[level=14]
setblock 11 283 615 minecraft:light[level=14]
setblock 11 283 623 minecraft:light[level=14]
setblock 11 283 631 minecraft:light[level=14]
setblock 11 283 639 minecraft:light[level=14]
fill 15 283 646 15 307 646 minecraft:black_concrete
setblock 16 283 646 minecraft:glowstone
setblock 19 283 607 minecraft:light[level=14]
setblock 19 283 615 minecraft:light[level=14]
setblock 19 283 631 minecraft:light[level=14]
setblock 19 283 639 minecraft:light[level=14]
setblock 27 283 607 minecraft:light[level=14]
setblock 27 283 615 minecraft:light[level=14]
setblock 27 283 623 minecraft:light[level=14]
setblock 27 283 631 minecraft:light[level=14]
setblock 27 283 639 minecraft:light[level=14]
setblock 32 283 646 minecraft:glowstone
setblock 35 283 607 minecraft:light[level=14]
setblock 35 283 615 minecraft:light[level=14]
setblock 35 283 623 minecraft:light[level=14]
setblock 35 283 631 minecraft:light[level=14]
setblock 35 283 639 minecraft:light[level=14]
setblock 0 284 605 minecraft:white_concrete
fill 0 284 624 0 287 624 minecraft:black_concrete
setblock 0 284 635 minecraft:glowstone
fill 16 284 646 16 296 646 minecraft:black_concrete
setblock 20 284 604 minecraft:diamond_block
setblock 24 284 604 minecraft:diamond_block
fill 32 284 646 32 307 646 minecraft:black_concrete
fill 0 285 605 0 307 605 minecraft:black_concrete
fill 0 285 635 0 304 635 minecraft:black_concrete
setblock 0 285 640 minecraft:white_concrete
fill 6 285 646 6 307 646 minecraft:black_concrete
setblock 7 285 646 minecraft:glowstone
fill 8 285 646 8 307 646 minecraft:black_concrete
setblock 17 285 604 minecraft:white_concrete
fill 20 285 604 20 287 604 minecraft:black_concrete
fill 24 285 604 24 306 604 minecraft:black_concrete
setblock 24 285 646 minecraft:glowstone
fill 32 285 620 32 286 621 minecraft:gold_block
setblock 0 286 606 minecraft:diamond_block
fill 0 286 607 0 307 607 minecraft:black_concrete
setblock 0 286 621 minecraft:white_concrete
fill 0 286 640 0 291 640 minecraft:black_concrete
fill 7 286 646 7 306 646 minecraft:black_concrete
fill 17 286 604 17 291 604 minecraft:black_concrete
fill 24 286 646 24 307 646 minecraft:black_concrete
setblock 33 286 604 minecraft:glowstone
fill 40 286 646 40 307 646 minecraft:black_concrete
setblock 41 286 646 minecraft:diamond_block
fill 42 286 646 42 307 646 minecraft:black_concrete
setblock 0 287 606 minecraft:black_concrete
fill 0 287 621 0 307 621 minecraft:black_concrete
fill 33 287 604 33 307 604 minecraft:black_concrete
setblock 37 287 646 minecraft:white_concrete
fill 41 287 646 41 296 646 minecraft:black_concrete
setblock 0 288 606 minecraft:glowstone
fill 0 288 612 0 290 612 minecraft:moss_block
setblock 0 288 623 minecraft:diamond_block
setblock 0 288 624 minecraft:white_concrete
fill 0 288 628 0 290 628 minecraft:moss_block
setblock 0 288 639 minecraft:glowstone
setblock 0 288 643 minecraft:white_concrete
fill 0 288 644 0 290 644 minecraft:moss_block
fill 4 288 604 4 290 604 minecraft:moss_block
fill 14 288 646 14 290 646 minecraft:moss_block
fill 20 288 604 20 290 604 minecraft:moss_block
setblock 29 288 604 minecraft:glowstone
fill 30 288 646 30 290 646 minecraft:moss_block
fill 36 288 604 36 290 604 minecraft:moss_block
setblock 37 288 604 minecraft:white_concrete
fill 37 288 646 37 307 646 minecraft:black_concrete
fill 42 288 614 42 290 614 minecraft:moss_block
fill 42 288 630 42 290 630 minecraft:moss_block
fill 0 289 606 0 293 606 minecraft:black_concrete
fill 0 289 623 0 307 624 minecraft:black_concrete
fill 0 289 639 0 296 639 minecraft:black_concrete
fill 0 289 643 0 307 643 minecraft:black_concrete
setblock 1 289 604 minecraft:white_concrete
fill 29 289 604 29 297 604 minecraft:black_concrete
setblock 36 289 646 minecraft:glowstone
fill 37 289 604 37 292 604 minecraft:black_concrete
setblock 0 290 614 minecraft:diamond_block
fill 1 290 604 1 307 604 minecraft:black_concrete
setblock 22 290 604 minecraft:white_concrete
fill 33 290 623 34 291 624 minecraft:stone
fill 36 290 646 36 294 646 minecraft:black_concrete
fill 0 291 612 0 296 612 minecraft:black_concrete
fill 0 291 614 0 307 614 minecraft:black_concrete
fill 0 291 628 0 296 628 minecraft:black_concrete
setblock 0 291 644 minecraft:diamond_block
setblock 3 291 607 minecraft:light[level=14]
setblock 3 291 615 minecraft:light[level=14]
setblock 3 291 623 minecraft:light[level=14]
setblock 3 291 631 minecraft:light[level=14]
setblock 3 291 639 minecraft:light[level=14]
fill 4 291 604 4 296 604 minecraft:black_concrete
setblock 11 291 607 minecraft:light[level=14]
setblock 11 291 615 minecraft:light[level=14]
setblock 11 291 623 minecraft:light[level=14]
setblock 11 291 631 minecraft:light[level=14]
setblock 11 291 639 minecraft:light[level=14]
fill 14 291 646 14 296 646 minecraft:black_concrete
setblock 19 291 607 minecraft:light[level=14]
setblock 19 291 615 minecraft:light[level=14]
setblock 19 291 631 minecraft:light[level=14]
setblock 19 291 639 minecraft:light[level=14]
fill 20 291 604 20 296 604 minecraft:black_concrete
fill 22 291 604 22 299 604 minecraft:black_concrete
setblock 27 291 607 minecraft:light[level=14]
setblock 27 291 615 minecraft:light[level=14]
setblock 27 291 623 minecraft:light[level=14]
setblock 27 291 631 minecraft:light[level=14]
setblock 27 291 639 minecraft:light[level=14]
fill 30 291 646 30 296 646 minecraft:black_concrete
fill 31 291 618 31 292 618 minecraft:raw_iron_block
setblock 35 291 607 minecraft:light[level=14]
setblock 35 291 615 minecraft:light[level=14]
setblock 35 291 623 minecraft:light[level=14]
setblock 35 291 631 minecraft:light[level=14]
setblock 35 291 639 minecraft:light[level=14]
fill 36 291 604 36 296 604 minecraft:black_concrete
fill 42 291 614 42 296 614 minecraft:black_concrete
fill 42 291 630 42 296 630 minecraft:black_concrete
setblock 0 292 640 minecraft:glowstone
fill 0 292 644 0 296 644 minecraft:black_concrete
setblock 12 292 646 minecraft:white_concrete
fill 13 292 646 13 307 646 minecraft:black_concrete
setblock 17 292 604 minecraft:glowstone
setblock 26 292 604 minecraft:white_concrete
setblock 42 292 615 minecraft:glowstone
fill 42 292 620 42 298 620 minecraft:black_concrete
setblock 42 292 621 minecraft:diamond_block
fill 0 293 640 0 299 640 minecraft:black_concrete
fill 12 293 646 12 307 646 minecraft:black_concrete
fill 17 293 604 17 296 604 minecraft:black_concrete
setblock 21 293 604 minecraft:white_concrete
fill 26 293 604 26 307 604 minecraft:black_concrete
setblock 37 293 604 minecraft:diamond_block
fill 42 293 615 42 307 615 minecraft:black_concrete
fill 42 293 621 42 307 621 minecraft:black_concrete
setblock 0 294 606 minecraft:glowstone
fill 21 294 604 21 307 604 minecraft:black_concrete
fill 36 294 615 37 295 616 minecraft:stone
fill 37 294 604 37 301 604 minecraft:black_concrete
fill 0 295 606 0 307 606 minecraft:black_concrete
setblock 0 295 608 minecraft:white_concrete
setblock 36 295 646 minecraft:diamond_block
fill 0 296 608 0 307 608 minecraft:black_concrete
setblock 31 296 646 minecraft:glowstone
fill 36 296 646 36 307 646 minecraft:black_concrete
setblock 0 297 611 minecraft:white_concrete
fill 0 297 612 0 299 612 minecraft:moss_block
setblock 0 297 622 minecraft:glowstone
fill 0 297 628 0 299 628 minecraft:moss_block
setblock 0 297 638 minecraft:glowstone
setblock 0 297 639 minecraft:diamond_block
fill 0 297 644 0 299 644 minecraft:moss_block
fill 4 297 604 4 299 604 minecraft:moss_block
fill 14 297 646 14 299 646 minecraft:moss_block
setblock 16 297 646 minecraft:diamond_block
setblock 17 297 604 minecraft:diamond_block
fill 20 297 604 20 299 604 minecraft:moss_block
fill 30 297 646 30 299 646 minecraft:moss_block
fill 31 297 646 31 307 646 minecraft:black_concrete
fill 36 297 604 36 299 604 minecraft:moss_block
setblock 41 297 646 minecraft:glowstone
setblock 42 297 609 minecraft:white_concrete
fill 42 297 614 42 299 614 minecraft:moss_block
fill 42 297 630 42 299 630 minecraft:moss_block
fill 0 298 611 0 307 611 minecraft:black_concrete
fill 0 298 622 0 300 622 minecraft:black_concrete
setblock 0 298 626 minecraft:diamond_block
fill 0 298 638 0 303 639 minecraft:black_concrete
fill 16 298 646 16 307 646 minecraft:black_concrete
fill 17 298 604 17 307 604 minecraft:black_concrete
setblock 29 298 604 minecraft:diamond_block
setblock 35 298 604 minecraft:diamond_block
fill 41 298 646 41 307 646 minecraft:black_concrete
fill 42 298 609 42 307 609 minecraft:black_concrete
setblock 42 298 643 minecraft:diamond_block
fill 0 299 615 0 299 616 minecraft:white_concrete
fill 0 299 626 0 307 626 minecraft:black_concrete
setblock 0 299 629 minecraft:diamond_block
setblock 3 299 607 minecraft:light[level=14]
setblock 3 299 615 minecraft:light[level=14]
setblock 3 299 623 minecraft:light[level=14]
setblock 3 299 631 minecraft:light[level=14]
setblock 3 299 639 minecraft:light[level=14]
setblock 11 299 607 minecraft:light[level=14]
setblock 11 299 615 minecraft:light[level=14]
setblock 11 299 623 minecraft:light[level=14]
setblock 11 299 631 minecraft:light[level=14]
setblock 11 299 639 minecraft:light[level=14]
setblock 19 299 607 minecraft:light[level=14]
setblock 19 299 615 minecraft:light[level=14]
setblock 19 299 623 minecraft:light[level=14]
setblock 19 299 631 minecraft:light[level=14]
setblock 19 299 639 minecraft:light[level=14]
setblock 27 299 607 minecraft:light[level=14]
setblock 27 299 615 minecraft:light[level=14]
setblock 27 299 623 minecraft:light[level=14]
setblock 27 299 631 minecraft:light[level=14]
setblock 27 299 639 minecraft:light[level=14]
fill 29 299 604 29 305 604 minecraft:black_concrete
fill 35 299 604 35 302 604 minecraft:black_concrete
setblock 35 299 607 minecraft:light[level=14]
setblock 35 299 615 minecraft:light[level=14]
setblock 35 299 623 minecraft:light[level=14]
setblock 35 299 631 minecraft:light[level=14]
setblock 35 299 639 minecraft:light[level=14]
setblock 42 299 612 minecraft:white_concrete
setblock 42 299 620 minecraft:white_concrete
setblock 42 299 629 minecraft:diamond_block
fill 42 299 637 42 307 637 minecraft:black_concrete
setblock 42 299 638 minecraft:white_concrete
fill 42 299 639 42 307 639 minecraft:black_concrete
fill 42 299 643 42 307 643 minecraft:black_concrete
fill 0 300 612 0 307 612 minecraft:black_concrete
fill 0 300 615 0 306 616 minecraft:black_concrete
fill 0 300 628 0 307 629 minecraft:black_concrete
setblock 0 300 640 minecraft:glowstone
fill 0 300 644 0 307 644 minecraft:black_concrete
fill 4 300 604 4 307 604 minecraft:black_concrete
fill 14 300 646 14 307 646 minecraft:black_concrete
fill 20 300 604 20 307 604 minecraft:black_concrete
setblock 22 300 604 minecraft:white_concrete
fill 30 300 646 30 307 646 minecraft:black_concrete
fill 36 300 604 36 307 604 minecraft:black_concrete
fill 42 300 612 42 307 612 minecraft:black_concrete
fill 42 300 614 42 307 614 minecraft:black_concrete
fill 42 300 620 42 307 620 minecraft:black_concrete
fill 42 300 629 42 302 630 minecraft:black_concrete
fill 42 300 638 42 307 638 minecraft:black_concrete
setblock 0 301 622 minecraft:white_concrete
setblock 0 301 637 minecraft:white_concrete
fill 0 301 640 0 307 640 minecraft:black_concrete
setblock 3 301 604 minecraft:glowstone
setblock 9 301 604 minecraft:diamond_block
setblock 11 301 646 minecraft:glowstone
fill 22 301 604 22 307 604 minecraft:black_concrete
fill 0 302 622 0 307 622 minecraft:black_concrete
setblock 0 302 631 minecraft:white_concrete
setblock 0 302 634 minecraft:diamond_block
fill 0 302 637 0 307 637 minecraft:black_concrete
fill 3 302 604 3 307 604 minecraft:black_concrete
fill 9 302 604 9 307 604 minecraft:black_concrete
fill 11 302 646 11 307 646 minecraft:black_concrete
setblock 37 302 604 minecraft:glowstone
fill 42 302 631 42 307 631 minecraft:black_concrete
setblock 42 302 632 minecraft:glowstone
fill 0 303 631 0 307 631 minecraft:black_concrete
fill 0 303 634 0 307 634 minecraft:black_concrete
setblock 35 303 604 minecraft:white_concrete
fill 37 303 604 37 307 604 minecraft:black_concrete
fill 40 303 604 40 307 604 minecraft:black_concrete
setblock 41 303 604 minecraft:diamond_block
setblock 42 303 629 minecraft:glowstone
fill 42 303 630 42 307 630 minecraft:black_concrete
fill 42 303 632 42 307 632 minecraft:black_concrete
setblock 0 304 638 minecraft:glowstone
fill 0 304 639 0 307 639 minecraft:black_concrete
setblock 2 304 646 minecraft:diamond_block
fill 35 304 604 35 307 604 minecraft:black_concrete
fill 41 304 604 41 307 604 minecraft:black_concrete
setblock 42 304 619 minecraft:white_concrete
fill 42 304 629 42 307 629 minecraft:black_concrete
setblock 0 305 635 minecraft:diamond_block
fill 0 305 638 0 307 638 minecraft:black_concrete
fill 2 305 646 2 307 646 minecraft:black_concrete
setblock 5 305 604 minecraft:diamond_block
fill 6 305 604 7 307 604 minecraft:black_concrete
fill 42 305 619 42 307 619 minecraft:black_concrete
setblock 0 306 633 minecraft:white_concrete
fill 0 306 635 0 307 635 minecraft:black_concrete
fill 5 306 604 5 307 604 minecraft:black_concrete
fill 20 306 646 20 307 646 minecraft:black_concrete
setblock 21 306 646 minecraft:diamond_block
setblock 29 306 604 minecraft:diamond_block
setblock 38 306 604 minecraft:glowstone
setblock 0 307 615 minecraft:black_concrete
setblock 0 307 616 minecraft:diamond_block
setblock 0 307 633 minecraft:black_concrete
setblock 7 307 646 minecraft:glowstone
setblock 21 307 646 minecraft:glowstone
setblock 24 307 604 minecraft:white_concrete
setblock 29 307 604 minecraft:black_concrete
setblock 38 307 604 minecraft:black_concrete
setblock 42 307 633 minecraft:diamond_block
