fill 84 293 347 84 294 347 minecraft:stripped_dark_oak_log
fill 84 293 349 84 294 349 minecraft:stripped_dark_oak_log
fill 84 293 359 84 294 359 minecraft:stripped_dark_oak_log
fill 84 293 361 84 294 361 minecraft:stripped_dark_oak_log
fill 84 293 363 84 294 363 minecraft:stripped_dark_oak_log
fill 85 293 338 85 294 338 minecraft:stripped_dark_oak_log
fill 85 293 340 85 294 340 minecraft:stripped_dark_oak_log
fill 85 293 342 85 294 342 minecraft:stripped_dark_oak_log
fill 85 293 344 85 294 344 minecraft:stripped_dark_oak_log
fill 85 293 346 85 294 346 minecraft:stripped_dark_oak_log
fill 85 293 348 85 294 348 minecraft:stripped_dark_oak_log
fill 85 293 350 85 294 350 minecraft:stripped_dark_oak_log
setblock 86 293 323 minecraft:stripped_dark_oak_log
fill 86 293 339 86 294 339 minecraft:stripped_dark_oak_log
fill 86 293 341 86 294 341 minecraft:stripped_dark_oak_log
fill 86 293 343 86 294 343 minecraft:stripped_dark_oak_log
fill 86 293 345 86 294 345 minecraft:stripped_dark_oak_log
fill 86 293 347 86 294 347 minecraft:stripped_dark_oak_log
fill 86 293 349 86 294 349 minecraft:stripped_dark_oak_log
fill 86 293 364 86 308 364 minecraft:dark_oak_planks
fill 87 293 338 87 294 338 minecraft:stripped_dark_oak_log
fill 87 293 340 87 294 340 minecraft:stripped_dark_oak_log
fill 87 293 342 87 294 342 minecraft:stripped_dark_oak_log
fill 87 293 344 87 294 344 minecraft:stripped_dark_oak_log
fill 87 293 346 87 294 346 minecraft:stripped_dark_oak_log
fill 87 293 348 87 294 348 minecraft:stripped_dark_oak_log
fill 87 293 350 87 294 350 minecraft:stripped_dark_oak_log
setblock 88 293 328 minecraft:stripped_dark_oak_log
setblock 88 293 335 minecraft:stripped_dark_oak_log
fill 88 293 339 88 294 339 minecraft:stripped_dark_oak_log
fill 88 293 341 88 294 341 minecraft:stripped_dark_oak_log
fill 88 293 343 88 294 343 minecraft:stripped_dark_oak_log
fill 88 293 345 88 294 345 minecraft:stripped_dark_oak_log
fill 88 293 347 88 294 347 minecraft:stripped_dark_oak_log
fill 88 293 349 88 294 349 minecraft:stripped_dark_oak_log
setblock 88 293 356 minecraft:stripped_dark_oak_log
setblock 50 294 325 minecraft:light[level=12]
setblock 50 294 332 minecraft:light[level=12]
setblock 50 294 339 minecraft:light[level=12]
setblock 50 294 346 minecraft:light[level=12]
setblock 50 294 353 minecraft:light[level=12]
setblock 50 294 360 minecraft:light[level=12]
setblock 57 294 325 minecraft:light[level=12]
setblock 57 294 332 minecraft:light[level=12]
setblock 57 294 339 minecraft:light[level=12]
setblock 57 294 346 minecraft:light[level=12]
setblock 57 294 353 minecraft:light[level=12]
setblock 57 294 360 minecraft:light[level=12]
setblock 64 294 325 minecraft:light[level=12]
fill 64 294 327 64 296 327 minecraft:dark_oak_planks
setblock 64 294 332 minecraft:light[level=12]
setblock 64 294 339 minecraft:light[level=12]
setblock 64 294 346 minecraft:light[level=12]
setblock 64 294 353 minecraft:light[level=12]
fill 65 294 329 65 296 329 minecraft:dark_oak_planks
fill 66 294 330 69 296 330 minecraft:dark_oak_planks
fill 68 294 323 68 296 323 minecraft:dark_oak_planks
fill 70 294 324 70 296 324 minecraft:dark_oak_planks
fill 71 294 325 71 296 328 minecraft:dark_oak_planks
fill 71 294 330 71 294 331 minecraft:stripped_dark_oak_log
setblock 71 294 332 minecraft:light[level=12]
setblock 71 294 339 minecraft:light[level=12]
setblock 71 294 346 minecraft:light[level=12]
setblock 71 294 353 minecraft:light[level=12]
fill 71 294 354 71 294 355 minecraft:stripped_dark_oak_log
setblock 71 294 360 minecraft:light[level=12]
fill 72 294 327 72 294 328 minecraft:red_concrete
fill 72 294 331 72 296 332 minecraft:stripped_dark_oak_log
fill 72 294 353 72 296 354 minecraft:stripped_dark_oak_log
setblock 72 294 357 minecraft:stripped_dark_oak_log
setblock 72 294 358 minecraft:red_concrete
fill 73 294 330 73 294 331 minecraft:stripped_dark_oak_log
fill 73 294 354 73 294 355 minecraft:stripped_dark_oak_log
setblock 78 294 325 minecraft:light[level=12]
setblock 78 294 332 minecraft:light[level=12]
setblock 78 294 339 minecraft:light[level=12]
setblock 78 294 353 minecraft:light[level=12]
setblock 85 294 325 minecraft:light[level=12]
setblock 85 294 332 minecraft:light[level=12]
setblock 85 294 353 minecraft:light[level=12]
setblock 85 294 360 minecraft:light[level=12]
setblock 89 294 342 minecraft:red_concrete
fill 89 294 343 89 308 343 minecraft:dark_oak_planks
setblock 48 295 329 minecraft:stripped_dark_oak_log
setblock 48 295 336 minecraft:stripped_dark_oak_log
setblock 48 295 343 minecraft:stripped_dark_oak_log
setblock 48 295 350 minecraft:stripped_dark_oak_log
setblock 48 295 357 minecraft:stripped_dark_oak_log
setblock 49 295 323 minecraft:stripped_dark_oak_log
setblock 49 295 363 minecraft:stripped_dark_oak_log
setblock 56 295 323 minecraft:stripped_dark_oak_log
setblock 56 295 363 minecraft:stripped_dark_oak_log
setblock 63 295 323 minecraft:stripped_dark_oak_log
fill 64 295 325 64 296 326 minecraft:dark_oak_planks
fill 64 295 328 64 296 328 minecraft:dark_oak_planks
fill 65 295 324 65 296 324 minecraft:dark_oak_planks
fill 66 295 323 67 296 323 minecraft:dark_oak_planks
setblock 69 295 323 minecraft:dark_oak_planks
setblock 70 295 323 minecraft:stripped_dark_oak_log
fill 70 295 330 70 296 330 minecraft:dark_oak_planks
setblock 70 295 363 minecraft:stripped_dark_oak_log
fill 71 295 329 71 296 329 minecraft:dark_oak_planks
fill 71 295 331 71 295 333 minecraft:stripped_dark_oak_log
fill 71 295 352 71 295 354 minecraft:stripped_dark_oak_log
setblock 72 295 329 minecraft:red_concrete
fill 72 295 333 72 296 334 minecraft:stripped_dark_oak_log
fill 72 295 351 72 297 352 minecraft:stripped_dark_oak_log
setblock 72 295 356 minecraft:red_concrete
fill 73 295 331 73 295 333 minecraft:stripped_dark_oak_log
fill 73 295 352 73 295 354 minecraft:stripped_dark_oak_log
setblock 74 295 359 minecraft:shroomlight
setblock 74 295 361 minecraft:shroomlight
setblock 74 295 363 minecraft:shroomlight
setblock 75 295 358 minecraft:shroomlight
setblock 75 295 360 minecraft:shroomlight
setblock 75 295 362 minecraft:shroomlight
setblock 76 295 359 minecraft:shroomlight
setblock 76 295 361 minecraft:shroomlight
setblock 76 295 363 minecraft:shroomlight
setblock 77 295 323 minecraft:stripped_dark_oak_log
setblock 77 295 358 minecraft:shroomlight
setblock 77 295 360 minecraft:shroomlight
setblock 77 295 362 minecraft:shroomlight
setblock 78 295 359 minecraft:shroomlight
setblock 78 295 361 minecraft:shroomlight
setblock 78 295 363 minecraft:shroomlight
setblock 79 295 358 minecraft:shroomlight
setblock 79 295 360 minecraft:shroomlight
setblock 79 295 362 minecraft:shroomlight
setblock 80 295 339 minecraft:shroomlight
setblock 80 295 341 minecraft:shroomlight
setblock 80 295 343 minecraft:shroomlight
setblock 80 295 345 minecraft:shroomlight
setblock 80 295 347 minecraft:shroomlight
setblock 80 295 349 minecraft:shroomlight
setblock 80 295 359 minecraft:shroomlight
setblock 80 295 361 minecraft:shroomlight
setblock 80 295 363 minecraft:shroomlight
setblock 81 295 338 minecraft:shroomlight
setblock 81 295 340 minecraft:shroomlight
setblock 81 295 342 minecraft:shroomlight
setblock 81 295 344 minecraft:shroomlight
setblock 81 295 346 minecraft:shroomlight
setblock 81 295 348 minecraft:shroomlight
setblock 81 295 350 minecraft:shroomlight
setblock 81 295 358 minecraft:shroomlight
setblock 81 295 360 minecraft:shroomlight
setblock 81 295 362 minecraft:shroomlight
setblock 82 295 339 minecraft:shroomlight
setblock 82 295 341 minecraft:shroomlight
setblock 82 295 343 minecraft:shroomlight
setblock 82 295 345 minecraft:shroomlight
setblock 82 295 347 minecraft:shroomlight
setblock 82 295 349 minecraft:shroomlight
setblock 82 295 359 minecraft:shroomlight
setblock 82 295 361 minecraft:shroomlight
setblock 82 295 363 minecraft:shroomlight
setblock 83 295 338 minecraft:shroomlight
setblock 83 295 340 minecraft:shroomlight
setblock 83 295 342 minecraft:shroomlight
setblock 83 295 344 minecraft:shroomlight
setblock 83 295 346 minecraft:shroomlight
setblock 83 295 348 minecraft:shroomlight
setblock 83 295 350 minecraft:shroomlight
setblock 83 295 358 minecraft:shroomlight
setblock 83 295 360 minecraft:shroomlight
setblock 83 295 362 minecraft:shroomlight
setblock 84 295 323 minecraft:stripped_dark_oak_log
setblock 84 295 339 minecraft:shroomlight
setblock 84 295 341 minecraft:shroomlight
setblock 84 295 343 minecraft:shroomlight
setblock 84 295 345 minecraft:shroomlight
setblock 84 295 347 minecraft:shroomlight
setblock 84 295 349 minecraft:shroomlight
setblock 84 295 359 minecraft:shroomlight
setblock 84 295 361 minecraft:shroomlight
setblock 84 295 363 minecraft:shroomlight
setblock 85 295 338 minecraft:shroomlight
setblock 85 295 340 minecraft:shroomlight
setblock 85 295 342 minecraft:shroomlight
setblock 85 295 344 minecraft:shroomlight
setblock 85 295 346 minecraft:shroomlight
setblock 85 295 348 minecraft:shroomlight
setblock 85 295 350 minecraft:shroomlight
setblock 86 295 339 minecraft:shroomlight
setblock 86 295 341 minecraft:shroomlight
setblock 86 295 343 minecraft:shroomlight
setblock 86 295 345 minecraft:shroomlight
setblock 86 295 347 minecraft:shroomlight
setblock 86 295 349 minecraft:shroomlight
setblock 87 295 338 minecraft:shroomlight
setblock 87 295 340 minecraft:shroomlight
setblock 87 295 342 minecraft:shroomlight
setblock 87 295 344 minecraft:shroomlight
setblock 87 295 346 minecraft:shroomlight
setblock 87 295 348 minecraft:shroomlight
setblock 87 295 350 minecraft:shroomlight
setblock 88 295 326 minecraft:stripped_dark_oak_log
setblock 88 295 333 minecraft:stripped_dark_oak_log
setblock 88 295 339 minecraft:shroomlight
setblock 88 295 341 minecraft:shroomlight
setblock 88 295 343 minecraft:shroomlight
setblock 88 295 345 minecraft:shroomlight
setblock 88 295 347 minecraft:shroomlight
setblock 88 295 349 minecraft:shroomlight
setblock 88 295 354 minecraft:stripped_dark_oak_log
setblock 88 295 361 minecraft:stripped_dark_oak_log
fill 89 295 342 89 308 342 minecraft:dark_oak_planks
setblock 48 296 323 minecraft:stripped_dark_oak_log
setblock 48 296 330 minecraft:stripped_dark_oak_log
setblock 48 296 337 minecraft:stripped_dark_oak_log
setblock 48 296 344 minecraft:stripped_dark_oak_log
setblock 48 296 351 minecraft:stripped_dark_oak_log
setblock 48 296 358 minecraft:stripped_dark_oak_log
setblock 50 296 363 minecraft:stripped_dark_oak_log
setblock 55 296 323 minecraft:stripped_dark_oak_log
setblock 57 296 363 minecraft:stripped_dark_oak_log
setblock 62 296 323 minecraft:stripped_dark_oak_log
setblock 63 296 327 minecraft:dark_oak_planks
setblock 64 296 324 minecraft:dark_oak_planks
setblock 64 296 329 minecraft:dark_oak_planks
setblock 65 296 323 minecraft:dark_oak_planks
setblock 65 296 330 minecraft:dark_oak_planks
fill 66 296 331 69 296 331 minecraft:dark_oak_planks
setblock 69 296 323 minecraft:stripped_dark_oak_log
setblock 70 296 323 minecraft:dark_oak_planks
setblock 71 296 324 minecraft:dark_oak_planks
setblock 71 296 330 minecraft:dark_oak_planks
fill 71 296 332 71 296 335 minecraft:stripped_dark_oak_log
fill 71 296 350 71 296 353 minecraft:stripped_dark_oak_log
setblock 71 296 363 minecraft:stripped_dark_oak_log
fill 72 296 325 72 296 328 minecraft:dark_oak_planks
setblock 72 296 330 minecraft:red_concrete
fill 72 296 335 72 298 336 minecraft:stripped_dark_oak_log
fill 72 296 349 72 298 350 minecraft:stripped_dark_oak_log
setblock 72 296 355 minecraft:red_concrete
fill 73 296 332 73 296 335 minecraft:stripped_dark_oak_log
fill 73 296 350 73 296 353 minecraft:stripped_dark_oak_log
fill 74 296 359 74 297 359 minecraft:stripped_dark_oak_log
fill 74 296 361 74 297 361 minecraft:stripped_dark_oak_log
fill 74 296 363 74 297 363 minecraft:stripped_dark_oak_log
fill 75 296 358 75 297 358 minecraft:stripped_dark_oak_log
fill 75 296 360 75 297 360 minecraft:stripped_dark_oak_log
fill 75 296 362 75 297 362 minecraft:stripped_dark_oak_log
setblock 76 296 323 minecraft:stripped_dark_oak_log
fill 76 296 359 76 297 359 minecraft:stripped_dark_oak_log
fill 76 296 361 76 297 361 minecraft:stripped_dark_oak_log
fill 76 296 363 76 300 363 minecraft:stripped_dark_oak_log
fill 77 296 358 77 297 358 minecraft:stripped_dark_oak_log
fill 77 296 360 77 297 360 minecraft:stripped_dark_oak_log
fill 77 296 362 77 297 362 minecraft:stripped_dark_oak_log
fill 78 296 359 78 297 359 minecraft:stripped_dark_oak_log
fill 78 296 361 78 297 361 minecraft:stripped_dark_oak_log
fill 78 296 363 78 297 363 minecraft:stripped_dark_oak_log
fill 79 296 358 79 297 358 minecraft:stripped_dark_oak_log
fill 79 296 360 79 297 360 minecraft:stripped_dark_oak_log
fill 79 296 362 79 297 362 minecraft:stripped_dark_oak_log
fill 80 296 339 80 297 339 minecraft:stripped_dark_oak_log
fill 80 296 341 80 297 341 minecraft:stripped_dark_oak_log
fill 80 296 343 80 297 343 minecraft:stripped_dark_oak_log
fill 80 296 345 80 297 345 minecraft:stripped_dark_oak_log
fill 80 296 347 80 297 347 minecraft:stripped_dark_oak_log
fill 80 296 349 80 297 349 minecraft:stripped_dark_oak_log
fill 80 296 359 80 297 359 minecraft:stripped_dark_oak_log
fill 80 296 361 80 297 361 minecraft:stripped_dark_oak_log
fill 80 296 363 80 298 363 minecraft:stripped_dark_oak_log
fill 81 296 338 81 297 338 minecraft:stripped_dark_oak_log
fill 81 296 340 81 297 340 minecraft:stripped_dark_oak_log
fill 81 296 342 81 297 342 minecraft:stripped_dark_oak_log
fill 81 296 344 81 297 344 minecraft:stripped_dark_oak_log
fill 81 296 346 81 297 346 minecraft:stripped_dark_oak_log
fill 81 296 348 81 297 348 minecraft:stripped_dark_oak_log
fill 81 296 350 81 297 350 minecraft:stripped_dark_oak_log
fill 81 296 358 81 297 358 minecraft:stripped_dark_oak_log
fill 81 296 360 81 297 360 minecraft:stripped_dark_oak_log
fill 81 296 362 81 297 362 minecraft:stripped_dark_oak_log
fill 82 296 339 82 297 339 minecraft:stripped_dark_oak_log
fill 82 296 341 82 297 341 minecraft:stripped_dark_oak_log
fill 82 296 343 82 297 343 minecraft:stripped_dark_oak_log
fill 82 296 345 82 297 345 minecraft:stripped_dark_oak_log
fill 82 296 347 82 297 347 minecraft:stripped_dark_oak_log
fill 82 296 349 82 297 349 minecraft:stripped_dark_oak_log
fill 82 296 359 82 297 359 minecraft:stripped_dark_oak_log
fill 82 296 361 82 297 361 minecraft:stripped_dark_oak_log
fill 82 296 363 82 297 363 minecraft:stripped_dark_oak_log
setblock 83 296 323 minecraft:stripped_dark_oak_log
fill 83 296 338 83 297 338 minecraft:stripped_dark_oak_log
fill 83 296 340 83 297 340 minecraft:stripped_dark_oak_log
fill 83 296 342 83 297 342 minecraft:stripped_dark_oak_log
fill 83 296 344 83 297 344 minecraft:stripped_dark_oak_log
fill 83 296 346 83 297 346 minecraft:stripped_dark_oak_log
fill 83 296 348 83 297 348 minecraft:stripped_dark_oak_log
fill 83 296 350 83 297 350 minecraft:stripped_dark_oak_log
fill 83 296 358 83 297 358 minecraft:stripped_dark_oak_log
fill 83 296 360 83 297 360 minecraft:stripped_dark_oak_log
fill 83 296 362 83 297 362 minecraft:stripped_dark_oak_log
fill 84 296 339 84 297 339 minecraft:stripped_dark_oak_log
fill 84 296 341 84 297 341 minecraft:stripped_dark_oak_log
fill 84 296 343 84 297 343 minecraft:stripped_dark_oak_log
fill 84 296 345 84 297 345 minecraft:stripped_dark_oak_log
fill 84 296 347 84 297 347 minecraft:stripped_dark_oak_log
fill 84 296 349 84 297 349 minecraft:stripped_dark_oak_log
fill 84 296 359 84 297 359 minecraft:stripped_dark_oak_log
fill 84 296 361 84 297 361 minecraft:stripped_dark_oak_log
fill 84 296 363 85 296 363 minecraft:stripped_dark_oak_log
fill 85 296 338 85 297 338 minecraft:stripped_dark_oak_log
fill 85 296 340 85 297 340 minecraft:stripped_dark_oak_log
fill 85 296 342 85 297 342 minecraft:stripped_dark_oak_log
fill 85 296 344 85 297 344 minecraft:stripped_dark_oak_log
fill 85 296 346 85 297 346 minecraft:stripped_dark_oak_log
fill 85 296 348 85 297 348 minecraft:stripped_dark_oak_log
fill 85 296 350 85 297 350 minecraft:stripped_dark_oak_log
fill 86 296 339 86 297 339 minecraft:stripped_dark_oak_log
fill 86 296 341 86 297 341 minecraft:stripped_dark_oak_log
fill 86 296 343 86 297 343 minecraft:stripped_dark_oak_log
fill 86 296 345 86 297 345 minecraft:stripped_dark_oak_log
fill 86 296 347 86 297 347 minecraft:stripped_dark_oak_log
fill 86 296 349 86 297 349 minecraft:stripped_dark_oak_log
fill 87 296 338 87 297 338 minecraft:stripped_dark_oak_log
fill 87 296 340 87 297 340 minecraft:stripped_dark_oak_log
fill 87 296 342 87 297 342 minecraft:stripped_dark_oak_log
fill 87 296 344 87 297 344 minecraft:stripped_dark_oak_log
fill 87 296 346 87 297 346 minecraft:stripped_dark_oak_log
fill 87 296 348 87 297 348 minecraft:stripped_dark_oak_log
fill 87 296 350 87 297 350 minecraft:stripped_dark_oak_log
setblock 88 296 325 minecraft:stripped_dark_oak_log
setblock 88 296 332 minecraft:stripped_dark_oak_log
fill 88 296 339 88 297 339 minecraft:stripped_dark_oak_log
fill 88 296 341 88 297 341 minecraft:stripped_dark_oak_log
fill 88 296 343 88 297 343 minecraft:stripped_dark_oak_log
fill 88 296 345 88 297 345 minecraft:stripped_dark_oak_log
fill 88 296 347 88 297 347 minecraft:stripped_dark_oak_log
fill 88 296 349 88 297 349 minecraft:stripped_dark_oak_log
setblock 88 296 353 minecraft:stripped_dark_oak_log
setblock 88 296 360 minecraft:stripped_dark_oak_log
setblock 48 297 324 minecraft:stripped_dark_oak_log
setblock 48 297 331 minecraft:stripped_dark_oak_log
fill 48 297 333 50 298 333 minecraft:iron_bars
setblock 48 297 338 minecraft:stripped_dark_oak_log
setblock 48 297 345 minecraft:stripped_dark_oak_log
setblock 48 297 352 minecraft:stripped_dark_oak_log
setblock 48 297 359 minecraft:stripped_dark_oak_log
setblock 51 297 363 minecraft:stripped_dark_oak_log
setblock 54 297 323 minecraft:stripped_dark_oak_log
setblock 58 297 363 minecraft:stripped_dark_oak_log
setblock 60 297 364 minecraft:red_concrete
setblock 61 297 323 minecraft:stripped_dark_oak_log
setblock 68 297 323 minecraft:stripped_dark_oak_log
fill 68 297 327 68 299 327 minecraft:stripped_dark_oak_log
fill 71 297 334 71 297 337 minecraft:stripped_dark_oak_log
fill 71 297 348 71 297 351 minecraft:stripped_dark_oak_log
fill 72 297 332 72 297 333 minecraft:red_concrete
fill 72 297 334 73 297 334 minecraft:stripped_dark_oak_log
fill 72 297 337 72 298 340 minecraft:stripped_dark_oak_log
fill 72 297 345 72 298 348 minecraft:stripped_dark_oak_log
setblock 72 297 353 minecraft:red_concrete
setblock 72 297 363 minecraft:stripped_dark_oak_log
fill 73 297 335 73 297 337 minecraft:stripped_dark_oak_log
fill 73 297 348 73 297 351 minecraft:stripped_dark_oak_log
setblock 75 297 323 minecraft:stripped_dark_oak_log
setblock 82 297 323 minecraft:stripped_dark_oak_log
setblock 84 297 363 minecraft:stripped_dark_oak_log
setblock 86 297 334 minecraft:red_concrete
setblock 86 297 363 minecraft:stripped_dark_oak_log
setblock 88 297 324 minecraft:stripped_dark_oak_log
setblock 88 297 331 minecraft:stripped_dark_oak_log
setblock 88 297 352 minecraft:stripped_dark_oak_log
setblock 88 297 359 minecraft:stripped_dark_oak_log
setblock 48 298 325 minecraft:stripped_dark_oak_log
setblock 48 298 332 minecraft:stripped_dark_oak_log
setblock 48 298 339 minecraft:stripped_dark_oak_log
setblock 48 298 346 minecraft:stripped_dark_oak_log
setblock 48 298 353 minecraft:stripped_dark_oak_log
setblock 48 298 360 minecraft:stripped_dark_oak_log
setblock 50 298 325 minecraft:light[level=15]
setblock 50 298 341 minecraft:light[level=15]
setblock 50 298 349 minecraft:light[level=15]
setblock 50 298 357 minecraft:light[level=15]
setblock 52 298 363 minecraft:stripped_dark_oak_log
setblock 53 298 323 minecraft:stripped_dark_oak_log
setblock 58 298 325 minecraft:light[level=15]
setblock 58 298 333 minecraft:light[level=15]
setblock 58 298 341 minecraft:light[level=15]
setblock 58 298 349 minecraft:light[level=15]
setblock 58 298 357 minecraft:light[level=15]
setblock 60 298 323 minecraft:stripped_dark_oak_log
fill 60 298 364 60 308 364 minecraft:dark_oak_planks
setblock 66 298 325 minecraft:light[level=15]
setblock 66 298 333 minecraft:light[level=15]
setblock 66 298 341 minecraft:light[level=15]
setblock 66 298 349 minecraft:light[level=15]
setblock 67 298 323 minecraft:stripped_dark_oak_log
fill 71 298 337 71 298 339 minecraft:stripped_dark_oak_log
fill 71 298 346 71 298 348 minecraft:stripped_dark_oak_log
fill 72 298 333 72 298 334 minecraft:red_concrete
fill 72 298 351 72 298 352 minecraft:red_concrete
fill 73 298 337 73 298 348 minecraft:stripped_dark_oak_log
setblock 73 298 363 minecraft:stripped_dark_oak_log
setblock 74 298 323 minecraft:stripped_dark_oak_log
setblock 74 298 325 minecraft:light[level=15]
setblock 74 298 333 minecraft:light[level=15]
setblock 74 298 341 minecraft:light[level=15]
setblock 74 298 349 minecraft:light[level=15]
setblock 74 298 357 minecraft:light[level=15]
fill 75 298 359 83 298 362 minecraft:red_concrete
setblock 80 298 339 minecraft:shroomlight
setblock 80 298 341 minecraft:shroomlight
setblock 80 298 343 minecraft:shroomlight
setblock 80 298 345 minecraft:shroomlight
setblock 80 298 347 minecraft:shroomlight
setblock 80 298 349 minecraft:shroomlight
setblock 81 298 323 minecraft:stripped_dark_oak_log
setblock 81 298 338 minecraft:shroomlight
setblock 81 298 340 minecraft:shroomlight
setblock 81 298 342 minecraft:shroomlight
setblock 81 298 344 minecraft:shroomlight
setblock 81 298 346 minecraft:shroomlight
setblock 81 298 348 minecraft:shroomlight
setblock 81 298 350 minecraft:shroomlight
setblock 82 298 325 minecraft:light[level=15]
setblock 82 298 333 minecraft:light[level=15]
setblock 82 298 339 minecraft:shroomlight
setblock 82 298 341 minecraft:shroomlight
setblock 82 298 343 minecraft:shroomlight
setblock 82 298 345 minecraft:shroomlight
setblock 82 298 347 minecraft:shroomlight
setblock 82 298 349 minecraft:shroomlight
setblock 82 298 357 minecraft:light[level=15]
setblock 83 298 338 minecraft:shroomlight
setblock 83 298 340 minecraft:shroomlight
setblock 83 298 342 minecraft:shroomlight
setblock 83 298 344 minecraft:shroomlight
setblock 83 298 346 minecraft:shroomlight
setblock 83 298 348 minecraft:shroomlight
setblock 83 298 350 minecraft:shroomlight
setblock 84 298 339 minecraft:shroomlight
setblock 84 298 341 minecraft:shroomlight
setblock 84 298 343 minecraft:shroomlight
setblock 84 298 345 minecraft:shroomlight
setblock 84 298 347 minecraft:shroomlight
setblock 84 298 349 minecraft:shroomlight
setblock 85 298 338 minecraft:shroomlight
setblock 85 298 340 minecraft:shroomlight
setblock 85 298 342 minecraft:shroomlight
setblock 85 298 344 minecraft:shroomlight
setblock 85 298 346 minecraft:shroomlight
setblock 85 298 348 minecraft:shroomlight
setblock 85 298 350 minecraft:shroomlight
fill 86 298 334 86 299 334 minecraft:shroomlight
setblock 86 298 339 minecraft:shroomlight
setblock 86 298 341 minecraft:shroomlight
setblock 86 298 343 minecraft:shroomlight
setblock 86 298 345 minecraft:shroomlight
setblock 86 298 347 minecraft:shroomlight
setblock 86 298 349 minecraft:shroomlight
setblock 87 298 338 minecraft:shroomlight
setblock 87 298 340 minecraft:shroomlight
setblock 87 298 342 minecraft:shroomlight
setblock 87 298 344 minecraft:shroomlight
setblock 87 298 346 minecraft:shroomlight
setblock 87 298 348 minecraft:shroomlight
setblock 87 298 350 minecraft:shroomlight
setblock 87 298 363 minecraft:stripped_dark_oak_log
setblock 88 298 323 minecraft:stripped_dark_oak_log
setblock 88 298 330 minecraft:stripped_dark_oak_log
setblock 88 298 337 minecraft:stripped_dark_oak_log
setblock 88 298 339 minecraft:shroomlight
setblock 88 298 341 minecraft:shroomlight
setblock 88 298 343 minecraft:shroomlight
setblock 88 298 345 minecraft:shroomlight
setblock 88 298 347 minecraft:shroomlight
setblock 88 298 349 minecraft:shroomlight
setblock 88 298 358 minecraft:stripped_dark_oak_log
fill 48 299 326 48 300 326 minecraft:stripped_dark_oak_log
fill 48 299 333 48 300 333 minecraft:stripped_dark_oak_log
fill 48 299 340 48 300 340 minecraft:stripped_dark_oak_log
fill 48 299 347 48 300 347 minecraft:stripped_dark_oak_log
fill 48 299 354 48 300 354 minecraft:stripped_dark_oak_log
fill 48 299 361 48 300 361 minecraft:stripped_dark_oak_log
fill 52 299 323 52 300 323 minecraft:stripped_dark_oak_log
fill 53 299 363 53 300 363 minecraft:stripped_dark_oak_log
fill 59 299 323 59 300 323 minecraft:stripped_dark_oak_log
fill 66 299 323 66 300 323 minecraft:stripped_dark_oak_log
fill 72 299 336 72 299 337 minecraft:red_concrete
fill 72 299 338 72 299 340 minecraft:stripped_dark_oak_log
fill 72 299 345 72 299 347 minecraft:stripped_dark_oak_log
fill 72 299 348 72 299 349 minecraft:red_concrete
fill 73 299 323 73 300 323 minecraft:stripped_dark_oak_log
fill 73 299 341 73 299 344 minecraft:stripped_dark_oak_log
fill 74 299 363 74 300 363 minecraft:stripped_dark_oak_log
fill 76 299 360 82 299 361 minecraft:red_concrete
fill 80 299 323 80 300 323 minecraft:stripped_dark_oak_log
fill 80 299 339 80 300 339 minecraft:stripped_dark_oak_log
fill 80 299 341 80 300 341 minecraft:stripped_dark_oak_log
fill 80 299 343 80 300 343 minecraft:stripped_dark_oak_log
fill 80 299 345 80 300 345 minecraft:stripped_dark_oak_log
fill 80 299 347 80 300 347 minecraft:stripped_dark_oak_log
fill 80 299 349 80 300 349 minecraft:stripped_dark_oak_log
fill 81 299 338 81 300 338 minecraft:stripped_dark_oak_log
fill 81 299 340 81 300 340 minecraft:stripped_dark_oak_log
fill 81 299 342 81 300 342 minecraft:stripped_dark_oak_log
fill 81 299 344 81 300 344 minecraft:stripped_dark_oak_log
fill 81 299 346 81 300 346 minecraft:stripped_dark_oak_log
fill 81 299 348 81 300 348 minecraft:stripped_dark_oak_log
fill 81 299 350 81 300 350 minecraft:stripped_dark_oak_log
fill 81 299 363 81 300 363 minecraft:stripped_dark_oak_log
fill 82 299 339 82 300 339 minecraft:stripped_dark_oak_log
fill 82 299 341 82 300 341 minecraft:stripped_dark_oak_log
fill 82 299 343 82 300 343 minecraft:stripped_dark_oak_log
fill 82 299 345 82 300 345 minecraft:stripped_dark_oak_log
fill 82 299 347 82 300 347 minecraft:stripped_dark_oak_log
fill 82 299 349 82 300 349 minecraft:stripped_dark_oak_log
fill 83 299 338 83 300 338 minecraft:stripped_dark_oak_log
fill 83 299 340 83 300 340 minecraft:stripped_dark_oak_log
fill 83 299 342 83 300 342 minecraft:stripped_dark_oak_log
fill 83 299 344 83 300 344 minecraft:stripped_dark_oak_log
fill 83 299 346 83 300 346 minecraft:stripped_dark_oak_log
fill 83 299 348 83 300 348 minecraft:stripped_dark_oak_log
fill 83 299 350 83 300 350 minecraft:stripped_dark_oak_log
fill 84 299 339 84 300 339 minecraft:stripped_dark_oak_log
fill 84 299 341 84 300 341 minecraft:stripped_dark_oak_log
fill 84 299 343 84 300 343 minecraft:stripped_dark_oak_log
fill 84 299 345 84 300 345 minecraft:stripped_dark_oak_log
fill 84 299 347 84 300 347 minecraft:stripped_dark_oak_log
fill 84 299 349 84 300 349 minecraft:stripped_dark_oak_log
fill 85 299 338 85 300 338 minecraft:stripped_dark_oak_log
fill 85 299 340 85 300 340 minecraft:stripped_dark_oak_log
fill 85 299 342 85 300 342 minecraft:stripped_dark_oak_log
fill 85 299 344 85 300 344 minecraft:stripped_dark_oak_log
fill 85 299 346 85 300 346 minecraft:stripped_dark_oak_log
fill 85 299 348 85 300 348 minecraft:stripped_dark_oak_log
fill 85 299 350 85 300 350 minecraft:stripped_dark_oak_log
fill 86 299 339 86 300 339 minecraft:stripped_dark_oak_log
fill 86 299 341 86 300 341 minecraft:stripped_dark_oak_log
fill 86 299 343 86 300 343 minecraft:stripped_dark_oak_log
fill 86 299 345 86 300 345 minecraft:stripped_dark_oak_log
fill 86 299 347 86 300 347 minecraft:stripped_dark_oak_log
fill 86 299 349 86 300 349 minecraft:stripped_dark_oak_log
fill 87 299 323 87 300 323 minecraft:stripped_dark_oak_log
fill 87 299 338 87 300 338 minecraft:stripped_dark_oak_log
fill 87 299 340 87 300 340 minecraft:stripped_dark_oak_log
fill 87 299 342 87 300 342 minecraft:stripped_dark_oak_log
fill 87 299 344 87 300 344 minecraft:stripped_dark_oak_log
fill 87 299 346 87 300 346 minecraft:stripped_dark_oak_log
fill 87 299 348 87 300 348 minecraft:stripped_dark_oak_log
fill 87 299 350 87 300 350 minecraft:stripped_dark_oak_log
fill 88 299 329 88 300 329 minecraft:stripped_dark_oak_log
fill 88 299 336 88 300 336 minecraft:stripped_dark_oak_log
fill 88 299 339 88 300 339 minecraft:stripped_dark_oak_log
fill 88 299 341 88 300 341 minecraft:stripped_dark_oak_log
fill 88 299 343 88 300 343 minecraft:stripped_dark_oak_log
fill 88 299 345 88 300 345 minecraft:stripped_dark_oak_log
fill 88 299 347 88 300 347 minecraft:stripped_dark_oak_log
fill 88 299 349 88 300 349 minecraft:stripped_dark_oak_log
fill 88 299 357 88 300 357 minecraft:stripped_dark_oak_log
fill 88 299 363 88 300 363 minecraft:stripped_dark_oak_log
fill 48 300 323 48 300 325 minecraft:stripped_dark_oak_log
setblock 48 300 327 minecraft:stripped_dark_oak_log
fill 48 300 329 48 300 332 minecraft:stripped_dark_oak_log
setblock 48 300 334 minecraft:stripped_dark_oak_log
fill 48 300 336 48 300 339 minecraft:stripped_dark_oak_log
setblock 48 300 341 minecraft:stripped_dark_oak_log
fill 48 300 343 48 300 346 minecraft:stripped_dark_oak_log
setblock 48 300 348 minecraft:stripped_dark_oak_log
fill 48 300 350 48 300 353 minecraft:stripped_dark_oak_log
setblock 48 300 355 minecraft:stripped_dark_oak_log
fill 48 300 357 48 300 360 minecraft:stripped_dark_oak_log
setblock 48 300 362 minecraft:stripped_dark_oak_log
setblock 49 300 323 minecraft:stripped_dark_oak_log
fill 49 300 363 52 300 363 minecraft:stripped_dark_oak_log
setblock 50 300 325 minecraft:light[level=12]
setblock 50 300 332 minecraft:light[level=12]
setblock 50 300 339 minecraft:light[level=12]
setblock 50 300 346 minecraft:light[level=12]
setblock 50 300 353 minecraft:light[level=12]
setblock 50 300 360 minecraft:light[level=12]
setblock 51 300 323 minecraft:stripped_dark_oak_log
fill 53 300 323 56 300 323 minecraft:stripped_dark_oak_log
setblock 54 300 363 minecraft:stripped_dark_oak_log
fill 56 300 363 58 300 363 minecraft:stripped_dark_oak_log
setblock 57 300 325 minecraft:light[level=12]
setblock 57 300 332 minecraft:light[level=12]
setblock 57 300 339 minecraft:light[level=12]
setblock 57 300 346 minecraft:light[level=12]
setblock 57 300 353 minecraft:light[level=12]
setblock 57 300 360 minecraft:light[level=12]
setblock 58 300 323 minecraft:stripped_dark_oak_log
fill 60 300 323 63 300 323 minecraft:stripped_dark_oak_log
setblock 64 300 325 minecraft:light[level=12]
setblock 64 300 332 minecraft:light[level=12]
setblock 64 300 339 minecraft:light[level=12]
setblock 64 300 346 minecraft:light[level=12]
setblock 64 300 353 minecraft:light[level=12]
setblock 65 300 323 minecraft:stripped_dark_oak_log
fill 66 300 326 69 300 327 minecraft:cherry_leaves[persistent=true]
fill 67 300 323 70 300 323 minecraft:stripped_dark_oak_log
fill 67 300 325 68 300 325 minecraft:cherry_leaves[persistent=true]
fill 67 300 328 69 300 328 minecraft:cherry_leaves[persistent=true]
fill 70 300 363 73 300 363 minecraft:stripped_dark_oak_log
setblock 71 300 325 minecraft:light[level=12]
setblock 71 300 332 minecraft:light[level=12]
setblock 71 300 339 minecraft:light[level=12]
setblock 71 300 346 minecraft:light[level=12]
setblock 71 300 353 minecraft:light[level=12]
setblock 71 300 360 minecraft:light[level=12]
setblock 72 300 323 minecraft:stripped_dark_oak_log
fill 72 300 338 72 300 340 minecraft:red_concrete
fill 72 300 345 72 300 347 minecraft:red_concrete
fill 74 300 323 77 300 323 minecraft:stripped_dark_oak_log
setblock 75 300 363 minecraft:stripped_dark_oak_log
fill 77 300 360 81 300 361 minecraft:red_concrete
fill 77 300 363 80 300 363 minecraft:stripped_dark_oak_log
setblock 78 300 325 minecraft:light[level=12]
setblock 78 300 332 minecraft:light[level=12]
setblock 78 300 339 minecraft:light[level=12]
setblock 78 300 353 minecraft:light[level=12]
setblock 79 300 323 minecraft:stripped_dark_oak_log
fill 81 300 323 84 300 323 minecraft:stripped_dark_oak_log
setblock 82 300 363 minecraft:stripped_dark_oak_log
fill 84 300 363 87 300 363 minecraft:stripped_dark_oak_log
setblock 85 300 325 minecraft:light[level=12]
setblock 85 300 332 minecraft:light[level=12]
setblock 85 300 353 minecraft:light[level=12]
setblock 85 300 360 minecraft:light[level=12]
setblock 86 300 323 minecraft:stripped_dark_oak_log
setblock 86 300 334 minecraft:red_concrete
fill 88 300 323 88 300 326 minecraft:stripped_dark_oak_log
setblock 88 300 328 minecraft:stripped_dark_oak_log
fill 88 300 330 88 300 333 minecraft:stripped_dark_oak_log
setblock 88 300 335 minecraft:stripped_dark_oak_log
setblock 88 300 337 minecraft:stripped_dark_oak_log
fill 88 300 352 88 300 354 minecraft:stripped_dark_oak_log
setblock 88 300 356 minecraft:stripped_dark_oak_log
fill 88 300 358 88 300 361 minecraft:stripped_dark_oak_log
fill 87 302 322 87 308 322 minecraft:dark_oak_planks
setblock 88 302 322 minecraft:red_concrete
fill 88 303 322 88 308 322 minecraft:dark_oak_planks
setblock 47 305 344 minecraft:red_concrete
setblock 49 305 364 minecraft:red_concrete
fill 50 305 364 50 308 364 minecraft:dark_oak_planks
fill 47 306 344 47 308 344 minecraft:dark_oak_planks
fill 49 306 364 49 308 364 minecraft:dark_oak_planks
setblock 47 308 322 minecraft:dark_oak_planks
setblock 47 308 323 minecraft:red_concrete
