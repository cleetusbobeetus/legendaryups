setblock 377 210 313 minecraft:stripped_oak_log
fill 377 210 314 377 213 314 minecraft:red_terracotta
setblock 378 210 277 minecraft:stripped_oak_log
fill 378 210 278 378 213 278 minecraft:red_terracotta
setblock 378 210 282 minecraft:stripped_oak_log
fill 378 210 283 378 213 283 minecraft:red_terracotta
fill 378 210 293 378 210 295 minecraft:brown_terracotta
fill 378 210 298 378 211 298 minecraft:red_terracotta
setblock 378 210 302 minecraft:stripped_oak_log
fill 378 210 303 378 213 303 minecraft:red_terracotta
setblock 378 210 307 minecraft:stripped_oak_log
fill 378 210 308 378 213 308 minecraft:red_terracotta
fill 378 210 313 378 213 313 minecraft:red_terracotta
setblock 379 210 276 minecraft:stripped_oak_log
fill 379 210 277 379 213 277 minecraft:red_terracotta
setblock 379 210 278 minecraft:light[level=12]
setblock 379 210 285 minecraft:light[level=12]
setblock 379 210 299 minecraft:light[level=12]
setblock 379 210 306 minecraft:light[level=12]
setblock 379 210 313 minecraft:light[level=12]
setblock 379 210 316 minecraft:stripped_oak_log
fill 380 210 276 380 213 276 minecraft:red_terracotta
fill 380 210 291 381 210 291 minecraft:brown_terracotta
fill 380 210 297 382 210 297 minecraft:brown_terracotta
fill 380 210 316 380 213 316 minecraft:red_terracotta
setblock 383 210 292 minecraft:brown_terracotta
setblock 383 210 296 minecraft:brown_terracotta
setblock 386 210 278 minecraft:light[level=12]
setblock 386 210 285 minecraft:light[level=12]
setblock 386 210 292 minecraft:light[level=12]
setblock 386 210 306 minecraft:light[level=12]
setblock 386 210 313 minecraft:light[level=12]
setblock 388 210 316 minecraft:red_terracotta
setblock 389 210 276 minecraft:stripped_oak_log
setblock 389 210 316 minecraft:stripped_oak_log
fill 390 210 276 390 213 276 minecraft:red_terracotta
fill 390 210 316 390 213 316 minecraft:red_terracotta
setblock 392 210 277 minecraft:red_terracotta
setblock 393 210 277 minecraft:stripped_oak_log
setblock 393 210 278 minecraft:light[level=12]
setblock 393 210 285 minecraft:light[level=12]
setblock 393 210 292 minecraft:light[level=12]
setblock 393 210 299 minecraft:light[level=12]
setblock 393 210 306 minecraft:light[level=12]
setblock 393 210 313 minecraft:light[level=12]
setblock 394 210 276 minecraft:stripped_oak_log
fill 394 210 277 394 213 277 minecraft:red_terracotta
setblock 394 210 316 minecraft:stripped_oak_log
fill 395 210 276 395 213 276 minecraft:red_terracotta
fill 395 210 316 395 213 316 minecraft:red_terracotta
setblock 398 210 277 minecraft:stripped_oak_log
setblock 399 210 276 minecraft:stripped_oak_log
setblock 399 210 277 minecraft:red_terracotta
fill 400 210 276 400 213 276 minecraft:red_terracotta
setblock 400 210 278 minecraft:light[level=12]
setblock 400 210 285 minecraft:light[level=12]
setblock 400 210 292 minecraft:light[level=12]
setblock 400 210 299 minecraft:light[level=12]
setblock 400 210 306 minecraft:light[level=12]
setblock 400 210 313 minecraft:light[level=12]
fill 405 210 276 408 210 276 minecraft:red_terracotta
setblock 407 210 278 minecraft:light[level=12]
setblock 407 210 285 minecraft:light[level=12]
setblock 407 210 292 minecraft:light[level=12]
setblock 407 210 299 minecraft:light[level=12]
setblock 407 210 306 minecraft:light[level=12]
setblock 407 210 313 minecraft:light[level=12]
setblock 408 210 277 minecraft:stripped_oak_log
setblock 409 210 276 minecraft:stripped_oak_log
fill 409 210 277 409 213 277 minecraft:red_terracotta
fill 410 210 276 410 213 276 minecraft:red_terracotta
fill 410 210 278 410 211 278 minecraft:red_terracotta
fill 411 210 316 411 212 316 minecraft:red_terracotta
setblock 412 210 277 minecraft:red_terracotta
setblock 412 210 278 minecraft:stripped_oak_log
fill 412 210 279 412 213 279 minecraft:red_terracotta
setblock 413 210 277 minecraft:stripped_oak_log
fill 413 210 278 413 213 278 minecraft:red_terracotta
setblock 414 210 276 minecraft:stripped_oak_log
fill 414 210 277 414 213 277 minecraft:red_terracotta
setblock 414 210 280 minecraft:red_terracotta
setblock 414 210 281 minecraft:stripped_oak_log
fill 414 210 282 414 212 283 minecraft:red_terracotta
setblock 414 210 285 minecraft:light[level=12]
setblock 414 210 292 minecraft:light[level=12]
setblock 414 210 299 minecraft:light[level=12]
setblock 414 210 306 minecraft:light[level=12]
setblock 414 210 313 minecraft:light[level=12]
setblock 414 210 316 minecraft:stripped_oak_log
fill 415 210 276 415 213 276 minecraft:red_terracotta
setblock 415 210 280 minecraft:stripped_oak_log
fill 415 210 281 415 213 281 minecraft:red_terracotta
setblock 415 210 285 minecraft:stripped_oak_log
setblock 415 210 315 minecraft:stripped_oak_log
fill 415 210 316 415 213 316 minecraft:red_terracotta
setblock 416 210 279 minecraft:stripped_oak_log
fill 416 210 280 416 213 280 minecraft:red_terracotta
setblock 416 210 284 minecraft:stripped_oak_log
fill 416 210 285 416 213 285 minecraft:red_terracotta
setblock 416 210 288 minecraft:red_terracotta
setblock 416 210 299 minecraft:stripped_oak_log
fill 416 210 300 416 213 300 minecraft:red_terracotta
setblock 416 210 304 minecraft:stripped_oak_log
fill 416 210 315 416 213 315 minecraft:red_terracotta
setblock 417 210 278 minecraft:stripped_oak_log
fill 417 210 279 417 213 279 minecraft:red_terracotta
setblock 417 210 283 minecraft:stripped_oak_log
fill 417 210 284 417 213 284 minecraft:red_terracotta
setblock 417 210 288 minecraft:stripped_oak_log
fill 417 210 289 417 213 289 minecraft:red_terracotta
setblock 417 210 293 minecraft:stripped_oak_log
fill 417 210 294 417 212 294 minecraft:red_terracotta
setblock 417 210 298 minecraft:stripped_oak_log
fill 417 210 299 417 213 299 minecraft:red_terracotta
setblock 417 210 303 minecraft:stripped_oak_log
fill 417 210 304 417 213 304 minecraft:red_terracotta
setblock 417 210 308 minecraft:stripped_oak_log
fill 417 210 309 417 211 311 minecraft:red_terracotta
setblock 417 210 313 minecraft:stripped_oak_log
fill 417 210 314 417 213 314 minecraft:red_terracotta
setblock 377 211 277 minecraft:stripped_oak_log
fill 377 211 278 377 214 278 minecraft:red_terracotta
setblock 377 211 282 minecraft:stripped_oak_log
fill 377 211 283 377 214 283 minecraft:red_terracotta
setblock 377 211 287 minecraft:stripped_oak_log
setblock 377 211 297 minecraft:stripped_oak_log
fill 377 211 298 377 214 298 minecraft:red_terracotta
setblock 377 211 302 minecraft:stripped_oak_log
fill 377 211 303 377 214 303 minecraft:red_terracotta
setblock 377 211 307 minecraft:stripped_oak_log
fill 377 211 308 377 214 308 minecraft:red_terracotta
setblock 377 211 312 minecraft:stripped_oak_log
fill 377 211 313 377 214 313 minecraft:red_terracotta
setblock 378 211 276 minecraft:stripped_oak_log
fill 378 211 277 378 214 277 minecraft:red_terracotta
setblock 378 211 281 minecraft:stripped_oak_log
fill 378 211 282 378 214 282 minecraft:red_terracotta
setblock 378 211 301 minecraft:stripped_oak_log
fill 378 211 302 378 214 302 minecraft:red_terracotta
setblock 378 211 306 minecraft:stripped_oak_log
fill 378 211 307 378 214 307 minecraft:red_terracotta
fill 378 211 309 378 211 310 minecraft:red_terracotta
setblock 378 211 311 minecraft:stripped_oak_log
fill 378 211 312 378 214 312 minecraft:red_terracotta
setblock 378 211 316 minecraft:stripped_oak_log
fill 379 211 276 379 214 276 minecraft:red_terracotta
fill 379 211 294 379 215 294 minecraft:stripped_oak_log
setblock 379 211 315 minecraft:stripped_oak_log
fill 379 211 316 379 214 316 minecraft:red_terracotta
fill 381 211 296 381 215 296 minecraft:stripped_oak_log
fill 382 211 293 382 215 293 minecraft:stripped_oak_log
setblock 383 211 276 minecraft:stripped_oak_log
setblock 383 211 316 minecraft:stripped_oak_log
setblock 388 211 276 minecraft:stripped_oak_log
setblock 388 211 316 minecraft:stripped_oak_log
fill 389 211 276 389 214 276 minecraft:red_terracotta
fill 389 211 316 389 214 316 minecraft:red_terracotta
setblock 391 211 277 minecraft:red_terracotta
setblock 392 211 277 minecraft:stripped_oak_log
setblock 393 211 276 minecraft:stripped_oak_log
fill 393 211 277 393 214 277 minecraft:red_terracotta
setblock 393 211 316 minecraft:stripped_oak_log
fill 394 211 276 394 214 276 minecraft:red_terracotta
fill 394 211 311 395 212 315 minecraft:stripped_oak_log
fill 394 211 316 394 214 316 minecraft:red_terracotta
fill 395 211 303 395 212 310 minecraft:stripped_oak_log
fill 396 211 299 396 212 308 minecraft:stripped_oak_log
setblock 397 211 277 minecraft:stripped_oak_log
fill 397 211 287 398 212 291 minecraft:stripped_oak_log
fill 397 211 299 397 212 300 minecraft:stripped_oak_log
setblock 398 211 276 minecraft:stripped_oak_log
fill 398 211 277 398 212 277 minecraft:red_terracotta
fill 398 211 279 398 212 286 minecraft:stripped_oak_log
fill 399 211 276 399 213 276 minecraft:red_terracotta
fill 399 211 277 399 212 284 minecraft:stripped_oak_log
fill 404 211 276 407 211 276 minecraft:red_terracotta
setblock 407 211 277 minecraft:stripped_oak_log
setblock 408 211 276 minecraft:stripped_oak_log
fill 408 211 277 408 214 277 minecraft:red_terracotta
fill 409 211 276 409 214 276 minecraft:red_terracotta
fill 409 211 278 409 212 278 minecraft:red_terracotta
setblock 410 211 279 minecraft:stripped_oak_log
setblock 411 211 278 minecraft:stripped_oak_log
fill 411 211 279 411 214 279 minecraft:red_terracotta
setblock 412 211 277 minecraft:stripped_oak_log
fill 412 211 278 412 214 278 minecraft:red_terracotta
setblock 413 211 276 minecraft:stripped_oak_log
fill 413 211 277 413 214 277 minecraft:red_terracotta
setblock 413 211 280 minecraft:red_terracotta
setblock 413 211 316 minecraft:stripped_oak_log
fill 414 211 276 414 214 276 minecraft:red_terracotta
setblock 414 211 280 minecraft:stripped_oak_log
fill 414 211 281 414 214 281 minecraft:red_terracotta
setblock 414 211 284 minecraft:red_terracotta
setblock 414 211 315 minecraft:stripped_oak_log
fill 414 211 316 414 214 316 minecraft:red_terracotta
setblock 415 211 279 minecraft:stripped_oak_log
fill 415 211 280 415 214 280 minecraft:red_terracotta
setblock 415 211 284 minecraft:stripped_oak_log
fill 415 211 285 415 213 286 minecraft:red_terracotta
fill 415 211 315 415 214 315 minecraft:red_terracotta
setblock 416 211 278 minecraft:stripped_oak_log
fill 416 211 279 416 214 279 minecraft:red_terracotta
setblock 416 211 283 minecraft:stripped_oak_log
fill 416 211 284 416 214 284 minecraft:red_terracotta
setblock 416 211 288 minecraft:stripped_oak_log
setblock 416 211 298 minecraft:stripped_oak_log
fill 416 211 299 416 213 299 minecraft:red_terracotta
fill 416 211 301 416 211 302 minecraft:red_terracotta
setblock 416 211 303 minecraft:stripped_oak_log
fill 416 211 304 416 212 306 minecraft:red_terracotta
setblock 417 211 277 minecraft:stripped_oak_log
fill 417 211 278 417 214 278 minecraft:red_terracotta
setblock 417 211 282 minecraft:stripped_oak_log
fill 417 211 283 417 214 283 minecraft:red_terracotta
setblock 417 211 287 minecraft:stripped_oak_log
fill 417 211 288 417 214 288 minecraft:red_terracotta
setblock 417 211 292 minecraft:stripped_oak_log
setblock 417 211 293 minecraft:red_terracotta
setblock 417 211 297 minecraft:stripped_oak_log
fill 417 211 298 417 214 298 minecraft:red_terracotta
setblock 417 211 302 minecraft:stripped_oak_log
fill 417 211 303 417 214 303 minecraft:red_terracotta
fill 417 211 305 417 211 306 minecraft:red_terracotta
setblock 417 211 307 minecraft:stripped_oak_log
fill 417 211 308 417 214 308 minecraft:red_terracotta
setblock 417 211 312 minecraft:stripped_oak_log
fill 417 211 313 417 214 313 minecraft:red_terracotta
fill 376 212 275 376 215 317 minecraft:terracotta
fill 377 212 275 418 215 275 minecraft:terracotta
setblock 377 212 276 minecraft:stripped_oak_log
fill 377 212 277 377 215 277 minecraft:red_terracotta
setblock 377 212 281 minecraft:stripped_oak_log
fill 377 212 282 377 215 282 minecraft:red_terracotta
setblock 377 212 285 minecraft:red_terracotta
setblock 377 212 286 minecraft:stripped_oak_log
fill 377 212 287 377 215 287 minecraft:red_terracotta
setblock 377 212 296 minecraft:stripped_oak_log
fill 377 212 297 377 214 297 minecraft:red_terracotta
setblock 377 212 301 minecraft:stripped_oak_log
fill 377 212 302 377 215 302 minecraft:red_terracotta
setblock 377 212 305 minecraft:red_terracotta
setblock 377 212 306 minecraft:stripped_oak_log
fill 377 212 307 377 215 307 minecraft:red_terracotta
setblock 377 212 311 minecraft:stripped_oak_log
fill 377 212 312 377 215 312 minecraft:red_terracotta
setblock 377 212 316 minecraft:stripped_oak_log
fill 377 212 317 418 215 317 minecraft:terracotta
fill 378 212 276 378 215 276 minecraft:red_terracotta
setblock 378 212 280 minecraft:stripped_oak_log
fill 378 212 281 378 215 281 minecraft:red_terracotta
setblock 378 212 284 minecraft:red_terracotta
setblock 378 212 300 minecraft:stripped_oak_log
fill 378 212 301 378 215 301 minecraft:red_terracotta
setblock 378 212 305 minecraft:stripped_oak_log
fill 378 212 306 378 215 306 minecraft:red_terracotta
setblock 378 212 309 minecraft:red_terracotta
setblock 378 212 310 minecraft:stripped_oak_log
fill 378 212 311 378 215 311 minecraft:red_terracotta
setblock 378 212 315 minecraft:stripped_oak_log
fill 378 212 316 378 215 316 minecraft:red_terracotta
setblock 379 212 303 minecraft:red_terracotta
setblock 379 212 304 minecraft:stripped_oak_log
fill 379 212 305 379 215 305 minecraft:red_terracotta
setblock 379 212 315 minecraft:red_terracotta
setblock 382 212 276 minecraft:stripped_oak_log
setblock 382 212 316 minecraft:stripped_oak_log
setblock 387 212 316 minecraft:stripped_oak_log
fill 388 212 276 388 214 276 minecraft:red_terracotta
fill 388 212 316 388 215 316 minecraft:red_terracotta
setblock 391 212 277 minecraft:stripped_oak_log
setblock 392 212 276 minecraft:stripped_oak_log
fill 392 212 277 392 215 277 minecraft:red_terracotta
setblock 392 212 316 minecraft:stripped_oak_log
fill 393 212 276 393 215 276 minecraft:red_terracotta
fill 393 212 316 393 215 316 minecraft:red_terracotta
setblock 396 212 277 minecraft:stripped_oak_log
setblock 397 212 276 minecraft:stripped_oak_log
fill 397 212 277 397 213 277 minecraft:red_terracotta
fill 398 212 276 398 214 276 minecraft:red_terracotta
fill 404 212 276 406 212 276 minecraft:red_terracotta
setblock 406 212 277 minecraft:stripped_oak_log
setblock 407 212 276 minecraft:stripped_oak_log
fill 407 212 277 407 215 277 minecraft:red_terracotta
fill 407 212 278 407 213 281 minecraft:stripped_oak_log
fill 408 212 276 408 215 276 minecraft:red_terracotta
fill 408 212 278 408 213 278 minecraft:red_terracotta
setblock 410 212 278 minecraft:stripped_oak_log
fill 410 212 279 410 215 279 minecraft:red_terracotta
fill 410 212 316 410 213 316 minecraft:red_terracotta
setblock 411 212 277 minecraft:stripped_oak_log
fill 411 212 278 411 215 278 minecraft:red_terracotta
setblock 412 212 276 minecraft:stripped_oak_log
fill 412 212 277 412 215 277 minecraft:red_terracotta
setblock 412 212 280 minecraft:red_terracotta
setblock 412 212 316 minecraft:stripped_oak_log
fill 413 212 276 413 215 276 minecraft:red_terracotta
setblock 413 212 280 minecraft:stripped_oak_log
fill 413 212 281 413 214 282 minecraft:red_terracotta
fill 413 212 316 413 215 316 minecraft:red_terracotta
setblock 414 212 279 minecraft:stripped_oak_log
fill 414 212 280 414 215 280 minecraft:red_terracotta
setblock 414 212 284 minecraft:stripped_oak_log
fill 414 212 285 414 215 285 minecraft:red_terracotta
fill 414 212 315 414 215 315 minecraft:red_terracotta
setblock 415 212 278 minecraft:stripped_oak_log
fill 415 212 279 415 215 279 minecraft:red_terracotta
setblock 415 212 283 minecraft:stripped_oak_log
fill 415 212 284 415 215 284 minecraft:red_terracotta
setblock 415 212 287 minecraft:red_terracotta
setblock 415 212 302 minecraft:red_terracotta
setblock 415 212 303 minecraft:stripped_oak_log
setblock 416 212 277 minecraft:stripped_oak_log
fill 416 212 278 416 215 278 minecraft:red_terracotta
setblock 416 212 282 minecraft:stripped_oak_log
fill 416 212 283 416 215 283 minecraft:red_terracotta
setblock 416 212 286 minecraft:red_terracotta
setblock 416 212 287 minecraft:stripped_oak_log
fill 416 212 288 416 214 289 minecraft:red_terracotta
setblock 416 212 297 minecraft:stripped_oak_log
setblock 416 212 298 minecraft:red_terracotta
setblock 416 212 301 minecraft:red_terracotta
setblock 416 212 302 minecraft:stripped_oak_log
fill 416 212 303 416 215 303 minecraft:red_terracotta
setblock 416 212 307 minecraft:stripped_oak_log
fill 416 212 308 416 215 308 minecraft:red_terracotta
setblock 417 212 276 minecraft:stripped_oak_log
fill 417 212 277 417 215 277 minecraft:red_terracotta
setblock 417 212 281 minecraft:stripped_oak_log
fill 417 212 282 417 215 282 minecraft:red_terracotta
setblock 417 212 286 minecraft:stripped_oak_log
fill 417 212 287 417 215 287 minecraft:red_terracotta
setblock 417 212 291 minecraft:stripped_oak_log
setblock 417 212 292 minecraft:red_terracotta
setblock 417 212 296 minecraft:stripped_oak_log
fill 417 212 297 417 213 297 minecraft:red_terracotta
setblock 417 212 301 minecraft:stripped_oak_log
fill 417 212 302 417 215 302 minecraft:red_terracotta
setblock 417 212 305 minecraft:red_terracotta
setblock 417 212 306 minecraft:stripped_oak_log
fill 417 212 307 417 215 307 minecraft:red_terracotta
fill 417 212 309 417 212 310 minecraft:red_terracotta
setblock 417 212 311 minecraft:stripped_oak_log
fill 417 212 312 417 215 312 minecraft:red_terracotta
setblock 417 212 316 minecraft:stripped_oak_log
fill 418 212 276 418 215 316 minecraft:terracotta
fill 377 213 276 377 216 276 minecraft:red_terracotta
setblock 377 213 280 minecraft:stripped_oak_log
fill 377 213 281 377 216 281 minecraft:red_terracotta
setblock 377 213 285 minecraft:stripped_oak_log
fill 377 213 286 377 216 286 minecraft:red_terracotta
fill 377 213 288 377 214 288 minecraft:red_terracotta
setblock 377 213 296 minecraft:red_terracotta
setblock 377 213 300 minecraft:stripped_oak_log
fill 377 213 301 377 216 301 minecraft:red_terracotta
setblock 377 213 305 minecraft:stripped_oak_log
fill 377 213 306 377 216 306 minecraft:red_terracotta
setblock 377 213 310 minecraft:stripped_oak_log
fill 377 213 311 377 216 311 minecraft:red_terracotta
setblock 377 213 315 minecraft:stripped_oak_log
fill 377 213 316 377 216 316 minecraft:red_terracotta
setblock 378 213 279 minecraft:stripped_oak_log
fill 378 213 280 378 214 280 minecraft:red_terracotta
setblock 378 213 284 minecraft:stripped_oak_log
setblock 378 213 299 minecraft:stripped_oak_log
fill 378 213 300 378 214 300 minecraft:red_terracotta
setblock 378 213 304 minecraft:stripped_oak_log
fill 378 213 305 378 216 305 minecraft:red_terracotta
setblock 378 213 309 minecraft:stripped_oak_log
fill 378 213 310 378 216 310 minecraft:red_terracotta
setblock 378 213 314 minecraft:stripped_oak_log
setblock 378 213 315 minecraft:red_terracotta
setblock 379 213 303 minecraft:stripped_oak_log
fill 379 213 304 379 215 304 minecraft:red_terracotta
fill 379 213 306 379 214 306 minecraft:red_terracotta
setblock 381 213 276 minecraft:stripped_oak_log
setblock 381 213 316 minecraft:stripped_oak_log
fill 387 213 316 387 214 316 minecraft:red_terracotta
setblock 390 213 277 minecraft:stripped_oak_log
setblock 391 213 276 minecraft:stripped_oak_log
fill 391 213 277 391 214 277 minecraft:red_terracotta
setblock 391 213 316 minecraft:stripped_oak_log
fill 392 213 276 392 216 276 minecraft:red_terracotta
fill 392 213 316 392 216 316 minecraft:red_terracotta
fill 394 213 314 394 213 315 minecraft:orange_terracotta
setblock 395 213 277 minecraft:stripped_oak_log
fill 395 213 306 395 213 313 minecraft:orange_terracotta
setblock 396 213 276 minecraft:stripped_oak_log
fill 396 213 277 396 214 277 minecraft:red_terracotta
fill 396 213 299 396 213 305 minecraft:orange_terracotta
setblock 396 213 316 minecraft:stripped_oak_log
fill 397 213 276 397 214 276 minecraft:red_terracotta
fill 397 213 289 397 213 291 minecraft:orange_terracotta
fill 398 213 281 398 213 289 minecraft:orange_terracotta
fill 399 213 277 399 213 281 minecraft:orange_terracotta
fill 404 213 276 405 213 276 minecraft:red_terracotta
setblock 406 213 276 minecraft:stripped_oak_log
fill 406 213 277 406 216 277 minecraft:red_terracotta
fill 406 213 278 406 213 279 minecraft:stripped_oak_log
fill 407 213 276 407 216 276 minecraft:red_terracotta
fill 407 213 282 408 213 288 minecraft:stripped_oak_log
fill 408 213 280 408 213 281 minecraft:stripped_oak_log
fill 408 213 289 408 214 294 minecraft:stripped_oak_log
setblock 409 213 278 minecraft:stripped_oak_log
fill 409 213 279 409 215 279 minecraft:red_terracotta
fill 409 213 316 409 214 316 minecraft:red_terracotta
setblock 410 213 277 minecraft:stripped_oak_log
fill 410 213 278 410 216 278 minecraft:red_terracotta
setblock 411 213 276 minecraft:stripped_oak_log
fill 411 213 277 411 216 277 minecraft:red_terracotta
setblock 411 213 280 minecraft:red_terracotta
setblock 411 213 316 minecraft:stripped_oak_log
fill 412 213 276 412 216 276 minecraft:red_terracotta
setblock 412 213 280 minecraft:stripped_oak_log
fill 412 213 316 412 216 316 minecraft:red_terracotta
setblock 413 213 279 minecraft:stripped_oak_log
fill 413 213 280 413 214 280 minecraft:red_terracotta
setblock 413 213 283 minecraft:red_terracotta
fill 413 213 315 413 216 315 minecraft:red_terracotta
setblock 414 213 278 minecraft:stripped_oak_log
fill 414 213 279 414 216 279 minecraft:red_terracotta
setblock 414 213 282 minecraft:red_terracotta
setblock 414 213 283 minecraft:stripped_oak_log
fill 414 213 284 414 216 284 minecraft:red_terracotta
setblock 415 213 277 minecraft:stripped_oak_log
fill 415 213 278 415 216 278 minecraft:red_terracotta
setblock 415 213 282 minecraft:stripped_oak_log
fill 415 213 283 415 216 283 minecraft:red_terracotta
setblock 415 213 287 minecraft:stripped_oak_log
setblock 415 213 302 minecraft:stripped_oak_log
fill 415 213 303 415 214 305 minecraft:red_terracotta
setblock 416 213 276 minecraft:stripped_oak_log
fill 416 213 277 416 216 277 minecraft:red_terracotta
setblock 416 213 281 minecraft:stripped_oak_log
fill 416 213 282 416 216 282 minecraft:red_terracotta
setblock 416 213 286 minecraft:stripped_oak_log
fill 416 213 287 416 216 287 minecraft:red_terracotta
setblock 416 213 301 minecraft:stripped_oak_log
fill 416 213 302 416 215 302 minecraft:red_terracotta
fill 416 213 304 416 213 305 minecraft:red_terracotta
setblock 416 213 306 minecraft:stripped_oak_log
fill 416 213 307 416 216 307 minecraft:red_terracotta
fill 416 213 309 416 213 310 minecraft:red_terracotta
fill 416 213 314 416 214 314 minecraft:red_terracotta
setblock 416 213 316 minecraft:stripped_oak_log
fill 417 213 276 417 216 276 minecraft:red_terracotta
setblock 417 213 280 minecraft:stripped_oak_log
fill 417 213 281 417 216 281 minecraft:red_terracotta
setblock 417 213 285 minecraft:stripped_oak_log
fill 417 213 286 417 216 286 minecraft:red_terracotta
setblock 417 213 290 minecraft:stripped_oak_log
setblock 417 213 291 minecraft:red_terracotta
setblock 417 213 296 minecraft:red_terracotta
setblock 417 213 300 minecraft:stripped_oak_log
fill 417 213 301 417 216 301 minecraft:red_terracotta
setblock 417 213 305 minecraft:stripped_oak_log
fill 417 213 306 417 216 306 minecraft:red_terracotta
setblock 417 213 309 minecraft:red_terracotta
setblock 417 213 310 minecraft:stripped_oak_log
fill 417 213 311 417 216 311 minecraft:red_terracotta
setblock 417 213 315 minecraft:stripped_oak_log
fill 417 213 316 417 216 316 minecraft:red_terracotta
setblock 377 214 279 minecraft:stripped_oak_log
fill 377 214 280 377 217 280 minecraft:red_terracotta
setblock 377 214 284 minecraft:stripped_oak_log
fill 377 214 285 377 217 285 minecraft:red_terracotta
setblock 377 214 299 minecraft:stripped_oak_log
fill 377 214 300 377 217 300 minecraft:red_terracotta
setblock 377 214 304 minecraft:stripped_oak_log
fill 377 214 305 377 217 305 minecraft:red_terracotta
setblock 377 214 309 minecraft:stripped_oak_log
fill 377 214 310 377 217 310 minecraft:red_terracotta
setblock 377 214 314 minecraft:stripped_oak_log
fill 377 214 315 377 217 315 minecraft:red_terracotta
setblock 378 214 278 minecraft:stripped_oak_log
setblock 378 214 279 minecraft:red_terracotta
setblock 378 214 283 minecraft:stripped_oak_log
setblock 378 214 303 minecraft:stripped_oak_log
fill 378 214 304 378 217 304 minecraft:red_terracotta
setblock 378 214 308 minecraft:stripped_oak_log
fill 378 214 309 378 217 309 minecraft:red_terracotta
setblock 378 214 313 minecraft:stripped_oak_log
setblock 379 214 303 minecraft:red_terracotta
setblock 379 214 307 minecraft:stripped_oak_log
setblock 380 214 276 minecraft:stripped_oak_log
setblock 380 214 316 minecraft:stripped_oak_log
setblock 390 214 276 minecraft:stripped_oak_log
setblock 390 214 316 minecraft:stripped_oak_log
fill 391 214 276 391 216 276 minecraft:red_terracotta
fill 391 214 316 391 216 316 minecraft:red_terracotta
setblock 394 214 277 minecraft:stripped_oak_log
setblock 395 214 276 minecraft:stripped_oak_log
setblock 395 214 277 minecraft:red_terracotta
setblock 395 214 316 minecraft:stripped_oak_log
fill 396 214 276 396 215 276 minecraft:red_terracotta
setblock 404 214 276 minecraft:red_terracotta
setblock 405 214 276 minecraft:stripped_oak_log
fill 406 214 276 406 217 276 minecraft:red_terracotta
setblock 407 214 278 minecraft:red_terracotta
fill 407 214 279 407 214 282 minecraft:orange_terracotta
fill 407 214 283 407 214 289 minecraft:stripped_oak_log
setblock 408 214 278 minecraft:stripped_oak_log
fill 408 214 285 408 214 288 minecraft:stripped_oak_log
fill 408 214 295 409 214 300 minecraft:stripped_oak_log
setblock 409 214 277 minecraft:stripped_oak_log
fill 409 214 278 409 217 278 minecraft:red_terracotta
fill 409 214 291 409 214 294 minecraft:stripped_oak_log
fill 409 214 301 409 215 306 minecraft:stripped_oak_log
setblock 410 214 276 minecraft:stripped_oak_log
fill 410 214 277 410 217 277 minecraft:red_terracotta
fill 410 214 304 410 215 307 minecraft:stripped_oak_log
setblock 410 214 316 minecraft:stripped_oak_log
fill 411 214 276 411 217 276 minecraft:red_terracotta
setblock 411 214 280 minecraft:stripped_oak_log
fill 411 214 316 411 217 316 minecraft:red_terracotta
setblock 412 214 279 minecraft:stripped_oak_log
fill 412 214 280 412 215 280 minecraft:red_terracotta
fill 412 214 315 412 216 315 minecraft:red_terracotta
setblock 413 214 278 minecraft:stripped_oak_log
fill 413 214 279 413 216 279 minecraft:red_terracotta
setblock 413 214 283 minecraft:stripped_oak_log
setblock 414 214 277 minecraft:stripped_oak_log
fill 414 214 278 414 217 278 minecraft:red_terracotta
setblock 414 214 282 minecraft:stripped_oak_log
fill 414 214 283 414 217 283 minecraft:red_terracotta
setblock 414 214 286 minecraft:red_terracotta
setblock 415 214 276 minecraft:stripped_oak_log
fill 415 214 277 415 217 277 minecraft:red_terracotta
setblock 415 214 281 minecraft:stripped_oak_log
fill 415 214 282 415 217 282 minecraft:red_terracotta
setblock 415 214 285 minecraft:red_terracotta
setblock 415 214 286 minecraft:stripped_oak_log
fill 415 214 287 415 216 287 minecraft:red_terracotta
setblock 415 214 306 minecraft:stripped_oak_log
setblock 415 214 316 minecraft:stripped_oak_log
fill 416 214 276 416 217 276 minecraft:red_terracotta
setblock 416 214 280 minecraft:stripped_oak_log
fill 416 214 281 416 217 281 minecraft:red_terracotta
setblock 416 214 285 minecraft:stripped_oak_log
fill 416 214 286 416 217 286 minecraft:red_terracotta
setblock 416 214 300 minecraft:stripped_oak_log
fill 416 214 301 416 215 301 minecraft:red_terracotta
setblock 416 214 304 minecraft:red_terracotta
setblock 416 214 305 minecraft:stripped_oak_log
fill 416 214 306 416 217 306 minecraft:red_terracotta
setblock 416 214 309 minecraft:red_terracotta
setblock 416 214 310 minecraft:stripped_oak_log
fill 416 214 311 416 217 311 minecraft:red_terracotta
setblock 416 214 315 minecraft:stripped_oak_log
fill 416 214 316 416 217 316 minecraft:red_terracotta
setblock 417 214 279 minecraft:stripped_oak_log
fill 417 214 280 417 217 280 minecraft:red_terracotta
setblock 417 214 284 minecraft:stripped_oak_log
fill 417 214 285 417 217 285 minecraft:red_terracotta
setblock 417 214 289 minecraft:stripped_oak_log
fill 417 214 290 417 215 290 minecraft:red_terracotta
setblock 417 214 299 minecraft:stripped_oak_log
fill 417 214 300 417 215 300 minecraft:red_terracotta
setblock 417 214 304 minecraft:stripped_oak_log
fill 417 214 305 417 217 305 minecraft:red_terracotta
setblock 417 214 309 minecraft:stripped_oak_log
fill 417 214 310 417 217 310 minecraft:red_terracotta
setblock 417 214 314 minecraft:stripped_oak_log
fill 417 214 315 417 217 315 minecraft:red_terracotta
setblock 377 215 278 minecraft:stripped_oak_log
fill 377 215 279 377 216 279 minecraft:red_terracotta
setblock 377 215 283 minecraft:stripped_oak_log
fill 377 215 284 377 217 284 minecraft:red_terracotta
setblock 377 215 298 minecraft:stripped_oak_log
fill 377 215 299 377 216 299 minecraft:red_terracotta
setblock 377 215 303 minecraft:stripped_oak_log
fill 377 215 304 377 218 304 minecraft:red_terracotta
setblock 377 215 308 minecraft:stripped_oak_log
fill 377 215 309 377 218 309 minecraft:red_terracotta
setblock 377 215 313 minecraft:stripped_oak_log
fill 377 215 314 377 218 314 minecraft:red_terracotta
setblock 378 215 282 minecraft:stripped_oak_log
setblock 378 215 302 minecraft:stripped_oak_log
fill 378 215 303 378 217 303 minecraft:red_terracotta
setblock 378 215 307 minecraft:stripped_oak_log
fill 378 215 308 378 218 308 minecraft:red_terracotta
setblock 378 215 312 minecraft:stripped_oak_log
fill 379 215 278 380 215 281 minecraft:orange_terracotta
setblock 379 215 306 minecraft:stripped_oak_log
setblock 379 215 307 minecraft:red_terracotta
setblock 379 215 316 minecraft:stripped_oak_log
fill 380 215 276 382 215 277 minecraft:orange_terracotta
fill 380 215 282 387 215 282 minecraft:orange_terracotta
fill 381 215 278 381 217 278 minecraft:orange_terracotta
fill 381 215 281 381 217 281 minecraft:orange_terracotta
fill 381 215 283 386 215 283 minecraft:orange_terracotta
fill 381 215 298 382 215 303 minecraft:orange_terracotta
fill 382 215 297 389 215 297 minecraft:orange_terracotta
fill 382 215 304 389 215 304 minecraft:orange_terracotta
fill 383 215 276 386 215 276 minecraft:orange_terracotta
setblock 383 215 284 minecraft:orange_terracotta
fill 383 215 296 388 215 296 minecraft:orange_terracotta
fill 383 215 298 383 217 299 minecraft:orange_terracotta
fill 383 215 302 383 217 303 minecraft:orange_terracotta
fill 383 215 305 388 215 305 minecraft:orange_terracotta
fill 384 215 303 384 217 303 minecraft:orange_terracotta
fill 385 215 277 387 215 277 minecraft:orange_terracotta
fill 385 215 295 386 215 295 minecraft:orange_terracotta
fill 386 215 278 387 215 281 minecraft:orange_terracotta
fill 387 215 303 390 215 303 minecraft:orange_terracotta
fill 388 215 298 390 215 298 minecraft:orange_terracotta
fill 388 215 302 390 215 302 minecraft:orange_terracotta
setblock 389 215 276 minecraft:stripped_oak_log
fill 389 215 299 390 215 301 minecraft:orange_terracotta
setblock 389 215 316 minecraft:stripped_oak_log
fill 390 215 276 390 216 276 minecraft:red_terracotta
fill 390 215 316 390 217 316 minecraft:red_terracotta
fill 391 215 300 391 215 301 minecraft:orange_terracotta
setblock 393 215 277 minecraft:stripped_oak_log
setblock 394 215 276 minecraft:stripped_oak_log
setblock 394 215 316 minecraft:stripped_oak_log
setblock 395 215 276 minecraft:red_terracotta
fill 405 215 276 405 217 276 minecraft:red_terracotta
setblock 407 215 278 minecraft:stripped_oak_log
setblock 408 215 277 minecraft:stripped_oak_log
fill 408 215 278 408 217 278 minecraft:red_terracotta
fill 408 215 286 408 215 294 minecraft:orange_terracotta
setblock 409 215 276 minecraft:stripped_oak_log
fill 409 215 277 409 218 277 minecraft:red_terracotta
fill 409 215 297 409 215 300 minecraft:stripped_oak_log
fill 409 215 307 409 215 311 minecraft:stripped_oak_log
setblock 409 215 316 minecraft:stripped_oak_log
fill 410 215 276 410 218 276 minecraft:red_terracotta
setblock 410 215 303 minecraft:stripped_oak_log
fill 410 215 308 410 215 315 minecraft:stripped_oak_log
fill 410 215 316 410 218 316 minecraft:red_terracotta
setblock 411 215 279 minecraft:stripped_oak_log
fill 411 215 313 411 215 315 minecraft:stripped_oak_log
setblock 412 215 278 minecraft:stripped_oak_log
fill 412 215 279 412 216 279 minecraft:red_terracotta
setblock 413 215 277 minecraft:stripped_oak_log
fill 413 215 278 413 217 278 minecraft:red_terracotta
setblock 413 215 281 minecraft:red_terracotta
setblock 413 215 282 minecraft:stripped_oak_log
setblock 413 215 283 minecraft:red_terracotta
setblock 414 215 276 minecraft:stripped_oak_log
fill 414 215 277 414 218 277 minecraft:red_terracotta
setblock 414 215 281 minecraft:stripped_oak_log
fill 414 215 282 414 216 282 minecraft:red_terracotta
setblock 414 215 286 minecraft:stripped_oak_log
setblock 414 215 316 minecraft:stripped_oak_log
fill 415 215 276 415 218 276 minecraft:red_terracotta
setblock 415 215 280 minecraft:stripped_oak_log
fill 415 215 281 415 217 281 minecraft:red_terracotta
setblock 415 215 285 minecraft:stripped_oak_log
fill 415 215 286 415 217 286 minecraft:red_terracotta
setblock 415 215 305 minecraft:stripped_oak_log
setblock 415 215 306 minecraft:red_terracotta
setblock 415 215 315 minecraft:stripped_oak_log
fill 415 215 316 415 218 316 minecraft:red_terracotta
setblock 416 215 279 minecraft:stripped_oak_log
fill 416 215 280 416 218 280 minecraft:red_terracotta
setblock 416 215 284 minecraft:stripped_oak_log
fill 416 215 285 416 218 285 minecraft:red_terracotta
setblock 416 215 288 minecraft:red_terracotta
setblock 416 215 304 minecraft:stripped_oak_log
fill 416 215 305 416 217 305 minecraft:red_terracotta
setblock 416 215 309 minecraft:stripped_oak_log
fill 416 215 310 416 218 310 minecraft:red_terracotta
setblock 416 215 312 minecraft:red_terracotta
setblock 417 215 278 minecraft:stripped_oak_log
fill 417 215 279 417 218 279 minecraft:red_terracotta
setblock 417 215 283 minecraft:stripped_oak_log
fill 417 215 284 417 218 284 minecraft:red_terracotta
setblock 417 215 288 minecraft:stripped_oak_log
fill 417 215 289 417 216 289 minecraft:red_terracotta
setblock 417 215 299 minecraft:red_terracotta
setblock 417 215 303 minecraft:stripped_oak_log
fill 417 215 304 417 218 304 minecraft:red_terracotta
setblock 417 215 308 minecraft:stripped_oak_log
fill 417 215 309 417 218 309 minecraft:red_terracotta
setblock 417 215 313 minecraft:stripped_oak_log
fill 417 215 314 417 218 314 minecraft:red_terracotta
fill 376 216 275 376 219 317 minecraft:brown_terracotta
fill 377 216 275 418 219 275 minecraft:brown_terracotta
setblock 377 216 277 minecraft:stripped_oak_log
setblock 377 216 278 minecraft:red_terracotta
setblock 377 216 282 minecraft:stripped_oak_log
fill 377 216 283 377 217 283 minecraft:red_terracotta
setblock 377 216 287 minecraft:stripped_oak_log
setblock 377 216 302 minecraft:stripped_oak_log
fill 377 216 303 377 218 303 minecraft:red_terracotta
setblock 377 216 307 minecraft:stripped_oak_log
fill 377 216 308 377 218 308 minecraft:red_terracotta
setblock 377 216 312 minecraft:stripped_oak_log
fill 377 216 313 377 218 313 minecraft:red_terracotta
fill 377 216 317 418 219 317 minecraft:brown_terracotta
setblock 378 216 302 minecraft:red_terracotta
setblock 378 216 306 minecraft:stripped_oak_log
fill 378 216 307 378 218 307 minecraft:red_terracotta
setblock 378 216 311 minecraft:stripped_oak_log
setblock 378 216 316 minecraft:stripped_oak_log
setblock 379 216 278 minecraft:light[level=15]
setblock 379 216 285 minecraft:light[level=12]
setblock 379 216 286 minecraft:light[level=15]
setblock 379 216 292 minecraft:light[level=12]
setblock 379 216 294 minecraft:light[level=15]
setblock 379 216 299 minecraft:light[level=12]
setblock 379 216 302 minecraft:light[level=15]
setblock 379 216 306 minecraft:red_terracotta
setblock 379 216 310 minecraft:light[level=15]
setblock 379 216 313 minecraft:light[level=12]
fill 380 216 278 380 216 281 minecraft:orange_terracotta
fill 381 216 277 382 216 277 minecraft:orange_terracotta
fill 381 216 282 386 216 282 minecraft:orange_terracotta
fill 381 216 300 382 216 301 minecraft:orange_terracotta
fill 382 216 276 385 216 276 minecraft:orange_terracotta
fill 382 216 283 384 216 283 minecraft:orange_terracotta
fill 382 216 298 382 216 299 minecraft:orange_terracotta
fill 382 216 302 382 216 303 minecraft:orange_terracotta
fill 383 216 297 388 216 297 minecraft:orange_terracotta
fill 383 216 304 388 216 304 minecraft:orange_terracotta
fill 385 216 277 386 216 277 minecraft:orange_terracotta
fill 385 216 296 387 216 296 minecraft:orange_terracotta
fill 386 216 278 386 216 281 minecraft:orange_terracotta
setblock 386 216 285 minecraft:light[level=12]
setblock 386 216 292 minecraft:light[level=12]
setblock 386 216 306 minecraft:light[level=12]
setblock 386 216 313 minecraft:light[level=12]
setblock 387 216 278 minecraft:light[level=15]
fill 387 216 279 387 216 280 minecraft:orange_terracotta
setblock 387 216 286 minecraft:light[level=15]
setblock 387 216 294 minecraft:light[level=15]
fill 387 216 303 389 216 303 minecraft:orange_terracotta
setblock 387 216 310 minecraft:light[level=15]
fill 388 216 298 389 216 298 minecraft:orange_terracotta
fill 388 216 302 389 216 302 minecraft:orange_terracotta
setblock 388 216 316 minecraft:stripped_oak_log
fill 389 216 299 389 217 301 minecraft:orange_terracotta
setblock 389 216 316 minecraft:red_terracotta
fill 390 216 300 390 216 301 minecraft:orange_terracotta
setblock 393 216 276 minecraft:stripped_oak_log
setblock 393 216 278 minecraft:light[level=12]
setblock 393 216 285 minecraft:light[level=12]
setblock 393 216 292 minecraft:light[level=12]
setblock 393 216 299 minecraft:light[level=12]
setblock 393 216 306 minecraft:light[level=12]
setblock 393 216 313 minecraft:light[level=12]
setblock 394 216 276 minecraft:red_terracotta
setblock 395 216 278 minecraft:light[level=15]
setblock 395 216 286 minecraft:light[level=15]
setblock 395 216 294 minecraft:light[level=15]
setblock 395 216 302 minecraft:light[level=15]
setblock 395 216 310 minecraft:light[level=15]
setblock 400 216 278 minecraft:light[level=12]
setblock 400 216 285 minecraft:light[level=12]
setblock 400 216 292 minecraft:light[level=12]
setblock 400 216 299 minecraft:light[level=12]
setblock 400 216 306 minecraft:light[level=12]
setblock 400 216 313 minecraft:light[level=12]
setblock 403 216 278 minecraft:light[level=15]
setblock 403 216 286 minecraft:light[level=15]
setblock 403 216 294 minecraft:light[level=15]
setblock 403 216 302 minecraft:light[level=15]
setblock 403 216 310 minecraft:light[level=15]
setblock 407 216 277 minecraft:stripped_oak_log
setblock 407 216 278 minecraft:light[level=12]
setblock 407 216 285 minecraft:light[level=12]
setblock 407 216 292 minecraft:light[level=12]
setblock 407 216 299 minecraft:light[level=12]
setblock 407 216 306 minecraft:light[level=12]
setblock 407 216 313 minecraft:light[level=12]
setblock 408 216 276 minecraft:stripped_oak_log
fill 408 216 277 408 218 277 minecraft:red_terracotta
fill 409 216 276 409 218 276 minecraft:red_terracotta
fill 409 216 298 409 216 306 minecraft:orange_terracotta
fill 409 216 316 409 218 316 minecraft:red_terracotta
setblock 410 216 279 minecraft:stripped_oak_log
fill 410 216 307 410 216 309 minecraft:orange_terracotta
fill 410 216 310 410 216 315 minecraft:stripped_oak_log
setblock 411 216 278 minecraft:stripped_oak_log
setblock 411 216 279 minecraft:red_terracotta
setblock 411 216 286 minecraft:light[level=15]
setblock 411 216 294 minecraft:light[level=15]
setblock 411 216 302 minecraft:light[level=15]
setblock 411 216 310 minecraft:light[level=15]
setblock 411 216 315 minecraft:stripped_oak_log
setblock 412 216 277 minecraft:stripped_oak_log
fill 412 216 278 412 218 278 minecraft:red_terracotta
setblock 413 216 276 minecraft:stripped_oak_log
fill 413 216 277 413 218 277 minecraft:red_terracotta
setblock 413 216 316 minecraft:stripped_oak_log
fill 414 216 276 414 218 276 minecraft:red_terracotta
setblock 414 216 280 minecraft:stripped_oak_log
setblock 414 216 281 minecraft:red_terracotta
setblock 414 216 285 minecraft:stripped_oak_log
setblock 414 216 292 minecraft:light[level=12]
setblock 414 216 299 minecraft:light[level=12]
setblock 414 216 306 minecraft:light[level=12]
setblock 414 216 313 minecraft:light[level=12]
setblock 414 216 315 minecraft:stripped_oak_log
fill 414 216 316 414 218 316 minecraft:red_terracotta
setblock 415 216 279 minecraft:stripped_oak_log
fill 415 216 280 415 217 280 minecraft:red_terracotta
setblock 415 216 284 minecraft:stripped_oak_log
fill 415 216 285 415 217 285 minecraft:red_terracotta
setblock 416 216 278 minecraft:stripped_oak_log
fill 416 216 279 416 217 279 minecraft:red_terracotta
setblock 416 216 283 minecraft:stripped_oak_log
fill 416 216 284 416 218 284 minecraft:red_terracotta
setblock 416 216 288 minecraft:stripped_oak_log
setblock 416 216 303 minecraft:stripped_oak_log
setblock 416 216 304 minecraft:red_terracotta
setblock 416 216 308 minecraft:stripped_oak_log
fill 416 216 309 416 218 309 minecraft:red_terracotta
setblock 417 216 277 minecraft:stripped_oak_log
fill 417 216 278 417 218 278 minecraft:red_terracotta
setblock 417 216 282 minecraft:stripped_oak_log
fill 417 216 283 417 218 283 minecraft:red_terracotta
setblock 417 216 287 minecraft:stripped_oak_log
fill 417 216 288 417 218 288 minecraft:red_terracotta
setblock 417 216 302 minecraft:stripped_oak_log
fill 417 216 303 417 217 303 minecraft:red_terracotta
setblock 417 216 307 minecraft:stripped_oak_log
fill 417 216 308 417 218 308 minecraft:red_terracotta
setblock 417 216 312 minecraft:stripped_oak_log
fill 417 216 313 417 218 313 minecraft:red_terracotta
fill 418 216 276 418 219 316 minecraft:brown_terracotta
setblock 377 217 281 minecraft:stripped_oak_log
setblock 377 217 282 minecraft:red_terracotta
setblock 377 217 286 minecraft:stripped_oak_log
setblock 377 217 301 minecraft:stripped_oak_log
fill 377 217 302 377 218 302 minecraft:red_terracotta
setblock 377 217 306 minecraft:stripped_oak_log
fill 377 217 307 377 218 307 minecraft:red_terracotta
setblock 377 217 311 minecraft:stripped_oak_log
fill 377 217 312 377 218 312 minecraft:red_terracotta
setblock 377 217 316 minecraft:stripped_oak_log
setblock 378 217 305 minecraft:stripped_oak_log
fill 378 217 306 378 218 306 minecraft:red_terracotta
setblock 378 217 310 minecraft:stripped_oak_log
fill 378 217 311 378 218 311 minecraft:red_terracotta
setblock 382 217 277 minecraft:orange_terracotta
fill 382 217 282 385 217 282 minecraft:orange_terracotta
fill 382 217 300 382 217 301 minecraft:orange_terracotta
fill 384 217 297 387 217 297 minecraft:orange_terracotta
setblock 385 217 277 minecraft:orange_terracotta
fill 385 217 304 386 217 304 minecraft:orange_terracotta
fill 386 217 278 386 217 280 minecraft:orange_terracotta
fill 387 217 303 388 217 303 minecraft:orange_terracotta
setblock 388 217 298 minecraft:orange_terracotta
setblock 388 217 302 minecraft:orange_terracotta
setblock 407 217 276 minecraft:stripped_oak_log
fill 407 217 277 407 218 277 minecraft:red_terracotta
fill 408 217 276 408 218 276 minecraft:red_terracotta
setblock 410 217 278 minecraft:stripped_oak_log
fill 410 217 310 410 217 315 minecraft:orange_terracotta
setblock 411 217 277 minecraft:stripped_oak_log
fill 411 217 278 411 218 278 minecraft:red_terracotta
setblock 412 217 276 minecraft:stripped_oak_log
fill 412 217 277 412 218 277 minecraft:red_terracotta
setblock 412 217 316 minecraft:stripped_oak_log
fill 413 217 276 413 218 276 minecraft:red_terracotta
fill 413 217 316 413 218 316 minecraft:red_terracotta
setblock 415 217 279 minecraft:red_terracotta
setblock 415 217 283 minecraft:stripped_oak_log
setblock 415 217 284 minecraft:red_terracotta
setblock 416 217 277 minecraft:stripped_oak_log
setblock 416 217 278 minecraft:red_terracotta
setblock 416 217 282 minecraft:stripped_oak_log
fill 416 217 283 416 218 283 minecraft:red_terracotta
setblock 416 217 287 minecraft:stripped_oak_log
setblock 416 217 307 minecraft:stripped_oak_log
fill 416 217 308 416 218 308 minecraft:red_terracotta
setblock 417 217 276 minecraft:stripped_oak_log
fill 417 217 277 417 218 277 minecraft:red_terracotta
setblock 417 217 281 minecraft:stripped_oak_log
fill 417 217 282 417 218 282 minecraft:red_terracotta
setblock 417 217 286 minecraft:stripped_oak_log
fill 417 217 287 417 218 287 minecraft:red_terracotta
setblock 417 217 302 minecraft:red_terracotta
setblock 417 217 306 minecraft:stripped_oak_log
fill 417 217 307 417 218 307 minecraft:red_terracotta
setblock 417 217 311 minecraft:stripped_oak_log
fill 417 217 312 417 218 312 minecraft:red_terracotta
setblock 417 217 316 minecraft:stripped_oak_log
setblock 377 218 301 minecraft:red_terracotta
setblock 377 218 305 minecraft:stripped_oak_log
setblock 377 218 306 minecraft:red_terracotta
setblock 377 218 310 minecraft:stripped_oak_log
setblock 377 218 311 minecraft:red_terracotta
setblock 377 218 315 minecraft:stripped_oak_log
setblock 378 218 304 minecraft:stripped_oak_log
setblock 378 218 305 minecraft:red_terracotta
setblock 378 218 309 minecraft:stripped_oak_log
setblock 378 218 310 minecraft:red_terracotta
setblock 406 218 276 minecraft:stripped_oak_log
setblock 407 218 276 minecraft:red_terracotta
setblock 408 218 316 minecraft:red_terracotta
setblock 409 218 278 minecraft:stripped_oak_log
setblock 410 218 277 minecraft:stripped_oak_log
setblock 410 218 278 minecraft:red_terracotta
setblock 411 218 276 minecraft:stripped_oak_log
setblock 411 218 277 minecraft:red_terracotta
setblock 411 218 316 minecraft:stripped_oak_log
setblock 412 218 276 minecraft:red_terracotta
setblock 412 218 316 minecraft:red_terracotta
setblock 415 218 283 minecraft:red_terracotta
setblock 416 218 276 minecraft:stripped_oak_log
setblock 416 218 281 minecraft:stripped_oak_log
setblock 416 218 282 minecraft:red_terracotta
setblock 416 218 286 minecraft:stripped_oak_log
setblock 416 218 306 minecraft:stripped_oak_log
setblock 416 218 307 minecraft:red_terracotta
setblock 416 218 316 minecraft:stripped_oak_log
setblock 417 218 276 minecraft:red_terracotta
setblock 417 218 280 minecraft:stripped_oak_log
setblock 417 218 281 minecraft:red_terracotta
setblock 417 218 285 minecraft:stripped_oak_log
setblock 417 218 286 minecraft:red_terracotta
setblock 417 218 305 minecraft:stripped_oak_log
setblock 417 218 306 minecraft:red_terracotta
setblock 417 218 310 minecraft:stripped_oak_log
setblock 417 218 311 minecraft:red_terracotta
setblock 417 218 315 minecraft:stripped_oak_log
fill 376 220 275 376 223 317 minecraft:light_gray_terracotta
fill 377 220 275 418 223 275 minecraft:light_gray_terracotta
fill 377 220 317 418 223 317 minecraft:light_gray_terracotta
fill 418 220 276 418 223 316 minecraft:light_gray_terracotta
setblock 379 222 278 minecraft:light[level=12]
setblock 379 222 285 minecraft:light[level=12]
setblock 379 222 292 minecraft:light[level=12]
setblock 379 222 299 minecraft:light[level=12]
setblock 379 222 306 minecraft:light[level=12]
setblock 379 222 313 minecraft:light[level=12]
setblock 386 222 278 minecraft:light[level=12]
setblock 386 222 285 minecraft:light[level=12]
setblock 386 222 292 minecraft:light[level=12]
setblock 386 222 299 minecraft:light[level=12]
setblock 386 222 306 minecraft:light[level=12]
setblock 386 222 313 minecraft:light[level=12]
setblock 393 222 278 minecraft:light[level=12]
setblock 393 222 285 minecraft:light[level=12]
setblock 393 222 292 minecraft:light[level=12]
setblock 393 222 299 minecraft:light[level=12]
setblock 393 222 306 minecraft:light[level=12]
setblock 393 222 313 minecraft:light[level=12]
setblock 400 222 278 minecraft:light[level=12]
setblock 400 222 285 minecraft:light[level=12]
setblock 400 222 292 minecraft:light[level=12]
setblock 400 222 299 minecraft:light[level=12]
setblock 400 222 306 minecraft:light[level=12]
setblock 400 222 313 minecraft:light[level=12]
setblock 407 222 278 minecraft:light[level=12]
setblock 407 222 285 minecraft:light[level=12]
setblock 407 222 292 minecraft:light[level=12]
setblock 407 222 299 minecraft:light[level=12]
setblock 407 222 306 minecraft:light[level=12]
setblock 407 222 313 minecraft:light[level=12]
setblock 414 222 278 minecraft:light[level=12]
setblock 414 222 285 minecraft:light[level=12]
setblock 414 222 292 minecraft:light[level=12]
setblock 414 222 299 minecraft:light[level=12]
setblock 414 222 306 minecraft:light[level=12]
setblock 414 222 313 minecraft:light[level=12]
fill 376 224 275 376 227 317 minecraft:orange_terracotta
fill 377 224 275 418 227 275 minecraft:orange_terracotta
fill 377 224 317 418 227 317 minecraft:orange_terracotta
setblock 379 224 278 minecraft:light[level=15]
setblock 379 224 286 minecraft:light[level=15]
setblock 379 224 294 minecraft:light[level=15]
setblock 379 224 302 minecraft:light[level=15]
setblock 379 224 310 minecraft:light[level=15]
setblock 387 224 278 minecraft:light[level=15]
setblock 387 224 286 minecraft:light[level=15]
setblock 387 224 294 minecraft:light[level=15]
setblock 387 224 302 minecraft:light[level=15]
setblock 387 224 310 minecraft:light[level=15]
fill 388 224 294 393 224 294 minecraft:dark_oak_planks
fill 389 224 290 394 224 293 minecraft:dark_oak_planks
fill 389 224 295 394 224 298 minecraft:dark_oak_planks
fill 390 224 289 404 224 289 minecraft:dark_oak_planks
fill 390 224 299 404 224 299 minecraft:dark_oak_planks
fill 391 224 288 403 224 288 minecraft:dark_oak_planks
fill 391 224 300 403 224 300 minecraft:dark_oak_planks
fill 392 224 287 402 224 287 minecraft:dark_oak_planks
fill 392 224 301 402 224 301 minecraft:dark_oak_planks
fill 393 224 286 401 224 286 minecraft:dark_oak_planks
fill 393 224 302 401 224 302 minecraft:dark_oak_planks
setblock 395 224 278 minecraft:light[level=15]
fill 395 224 290 396 224 291 minecraft:dark_oak_planks
fill 395 224 297 396 224 298 minecraft:dark_oak_planks
setblock 395 224 310 minecraft:light[level=15]
setblock 397 224 285 minecraft:dark_oak_planks
fill 397 224 290 405 224 290 minecraft:dark_oak_planks
fill 397 224 298 405 224 298 minecraft:dark_oak_planks
setblock 397 224 303 minecraft:dark_oak_planks
fill 398 224 291 405 224 291 minecraft:dark_oak_planks
fill 398 224 297 405 224 297 minecraft:dark_oak_planks
fill 400 224 292 405 224 293 minecraft:dark_oak_planks
fill 400 224 295 405 224 296 minecraft:dark_oak_planks
fill 401 224 294 406 224 294 minecraft:dark_oak_planks
setblock 403 224 278 minecraft:light[level=15]
setblock 403 224 286 minecraft:light[level=15]
setblock 403 224 302 minecraft:light[level=15]
setblock 403 224 310 minecraft:light[level=15]
setblock 411 224 278 minecraft:light[level=15]
setblock 411 224 286 minecraft:light[level=15]
setblock 411 224 294 minecraft:light[level=15]
setblock 411 224 302 minecraft:light[level=15]
setblock 411 224 310 minecraft:light[level=15]
fill 418 224 276 418 227 316 minecraft:orange_terracotta
fill 377 225 276 417 225 277 minecraft:smooth_sandstone
fill 377 225 278 417 225 278 minecraft:sandstone
fill 377 225 279 417 225 280 minecraft:smooth_sandstone
fill 377 225 281 417 225 281 minecraft:sandstone
fill 377 225 282 417 225 283 minecraft:smooth_sandstone
fill 377 225 284 417 225 284 minecraft:sandstone
fill 377 225 285 392 225 286 minecraft:smooth_sandstone
fill 377 225 287 391 225 287 minecraft:sandstone
fill 377 225 288 389 225 289 minecraft:smooth_sandstone
fill 377 225 290 388 225 290 minecraft:sandstone
fill 377 225 291 388 225 292 minecraft:smooth_sandstone
fill 377 225 293 388 225 293 minecraft:sandstone
fill 377 225 294 387 225 295 minecraft:smooth_sandstone
fill 377 225 296 388 225 296 minecraft:sandstone
fill 377 225 297 388 225 298 minecraft:smooth_sandstone
fill 377 225 299 389 225 299 minecraft:sandstone
fill 377 225 300 390 225 301 minecraft:smooth_sandstone
fill 377 225 302 392 225 302 minecraft:sandstone
fill 377 225 303 396 225 304 minecraft:smooth_sandstone
fill 377 225 305 417 225 305 minecraft:sandstone
fill 377 225 306 417 225 307 minecraft:smooth_sandstone
fill 377 225 308 417 225 308 minecraft:sandstone
fill 377 225 309 417 225 310 minecraft:smooth_sandstone
fill 377 225 311 417 225 311 minecraft:sandstone
fill 377 225 312 417 225 313 minecraft:smooth_sandstone
fill 377 225 314 417 225 314 minecraft:sandstone
fill 377 225 315 417 225 316 minecraft:smooth_sandstone
setblock 388 225 294 minecraft:iron_block
setblock 388 225 295 minecraft:smooth_sandstone
fill 389 225 290 389 225 292 minecraft:iron_block
fill 389 225 293 389 225 295 minecraft:dark_oak_planks
fill 389 225 296 389 225 298 minecraft:iron_block
setblock 390 225 288 minecraft:smooth_sandstone
setblock 390 225 289 minecraft:iron_block
setblock 390 225 290 minecraft:dark_oak_planks
fill 390 225 291 393 225 291 minecraft:smooth_sandstone
setblock 390 225 292 minecraft:spruce_planks
fill 390 225 293 392 225 293 minecraft:sandstone
fill 390 225 294 392 225 295 minecraft:smooth_sandstone
setblock 390 225 296 minecraft:spruce_planks
fill 390 225 297 393 225 297 minecraft:smooth_sandstone
setblock 390 225 298 minecraft:dark_oak_planks
setblock 390 225 299 minecraft:iron_block
setblock 391 225 288 minecraft:iron_block
setblock 391 225 289 minecraft:smooth_sandstone
fill 391 225 290 392 225 290 minecraft:sandstone
setblock 391 225 292 minecraft:dark_oak_planks
setblock 391 225 296 minecraft:dark_oak_planks
fill 391 225 298 392 225 298 minecraft:smooth_sandstone
setblock 391 225 299 minecraft:sandstone
setblock 391 225 300 minecraft:iron_block
setblock 391 225 301 minecraft:smooth_sandstone
setblock 392 225 287 minecraft:iron_block
fill 392 225 288 394 225 288 minecraft:smooth_sandstone
setblock 392 225 289 minecraft:spruce_planks
fill 392 225 292 393 225 292 minecraft:smooth_sandstone
fill 392 225 296 393 225 296 minecraft:sandstone
setblock 392 225 299 minecraft:spruce_planks
fill 392 225 300 394 225 300 minecraft:smooth_sandstone
setblock 392 225 301 minecraft:iron_block
fill 393 225 285 396 225 285 minecraft:smooth_sandstone
fill 393 225 286 395 225 286 minecraft:iron_block
setblock 393 225 287 minecraft:dark_oak_planks
fill 393 225 289 401 225 289 minecraft:smooth_sandstone
setblock 393 225 290 minecraft:spruce_planks
fill 393 225 293 394 225 293 minecraft:ochre_froglight
setblock 393 225 294 minecraft:smooth_sandstone
fill 393 225 295 394 225 295 minecraft:ochre_froglight
setblock 393 225 298 minecraft:spruce_planks
fill 393 225 299 401 225 299 minecraft:sandstone
setblock 393 225 301 minecraft:dark_oak_planks
fill 393 225 302 395 225 302 minecraft:iron_block
setblock 394 225 287 minecraft:sandstone
fill 394 225 290 395 225 290 minecraft:sandstone
fill 394 225 291 394 225 292 minecraft:ochre_froglight
fill 394 225 296 394 225 297 minecraft:ochre_froglight
fill 394 225 298 395 225 298 minecraft:smooth_sandstone
setblock 394 225 301 minecraft:smooth_sandstone
setblock 395 225 287 minecraft:spruce_planks
setblock 395 225 288 minecraft:dark_oak_planks
fill 395 225 291 396 225 291 minecraft:ochre_froglight
fill 395 225 297 396 225 297 minecraft:ochre_froglight
setblock 395 225 300 minecraft:dark_oak_planks
setblock 395 225 301 minecraft:spruce_planks
fill 396 225 286 398 225 286 minecraft:dark_oak_planks
fill 396 225 287 398 225 287 minecraft:sandstone
fill 396 225 288 398 225 288 minecraft:smooth_sandstone
setblock 396 225 290 minecraft:ochre_froglight
setblock 396 225 298 minecraft:ochre_froglight
fill 396 225 300 398 225 301 minecraft:smooth_sandstone
fill 396 225 302 398 225 302 minecraft:dark_oak_planks
setblock 397 225 285 minecraft:iron_block
setblock 397 225 290 minecraft:smooth_sandstone
setblock 397 225 298 minecraft:smooth_sandstone
setblock 397 225 303 minecraft:iron_block
fill 397 225 304 417 225 304 minecraft:smooth_sandstone
fill 398 225 285 417 225 285 minecraft:smooth_sandstone
fill 398 225 290 398 225 291 minecraft:ochre_froglight
fill 398 225 297 398 225 298 minecraft:ochre_froglight
fill 398 225 303 417 225 303 minecraft:smooth_sandstone
fill 399 225 286 401 225 286 minecraft:iron_block
setblock 399 225 287 minecraft:spruce_planks
setblock 399 225 288 minecraft:dark_oak_planks
fill 399 225 290 400 225 290 minecraft:sandstone
fill 399 225 291 400 225 291 minecraft:ochre_froglight
fill 399 225 297 400 225 297 minecraft:ochre_froglight
fill 399 225 298 400 225 298 minecraft:smooth_sandstone
setblock 399 225 300 minecraft:dark_oak_planks
setblock 399 225 301 minecraft:spruce_planks
fill 399 225 302 401 225 302 minecraft:iron_block
setblock 400 225 287 minecraft:sandstone
fill 400 225 288 402 225 288 minecraft:smooth_sandstone
fill 400 225 292 400 225 293 minecraft:ochre_froglight
fill 400 225 295 400 225 296 minecraft:ochre_froglight
fill 400 225 300 400 225 301 minecraft:smooth_sandstone
setblock 401 225 287 minecraft:dark_oak_planks
setblock 401 225 290 minecraft:spruce_planks
fill 401 225 291 402 225 292 minecraft:smooth_sandstone
setblock 401 225 293 minecraft:ochre_froglight
fill 401 225 294 404 225 294 minecraft:smooth_sandstone
setblock 401 225 295 minecraft:ochre_froglight
fill 401 225 296 402 225 296 minecraft:sandstone
fill 401 225 297 404 225 297 minecraft:smooth_sandstone
setblock 401 225 298 minecraft:spruce_planks
fill 401 225 300 402 225 300 minecraft:smooth_sandstone
setblock 401 225 301 minecraft:dark_oak_planks
fill 402 225 286 417 225 286 minecraft:smooth_sandstone
setblock 402 225 287 minecraft:iron_block
setblock 402 225 289 minecraft:spruce_planks
fill 402 225 290 403 225 290 minecraft:sandstone
fill 402 225 293 404 225 293 minecraft:sandstone
fill 402 225 295 404 225 295 minecraft:smooth_sandstone
fill 402 225 298 403 225 298 minecraft:smooth_sandstone
setblock 402 225 299 minecraft:spruce_planks
setblock 402 225 301 minecraft:iron_block
fill 402 225 302 417 225 302 minecraft:sandstone
fill 403 225 287 417 225 287 minecraft:sandstone
setblock 403 225 288 minecraft:iron_block
setblock 403 225 289 minecraft:smooth_sandstone
fill 403 225 291 404 225 291 minecraft:smooth_sandstone
setblock 403 225 292 minecraft:dark_oak_planks
setblock 403 225 296 minecraft:dark_oak_planks
setblock 403 225 299 minecraft:sandstone
setblock 403 225 300 minecraft:iron_block
fill 403 225 301 417 225 301 minecraft:smooth_sandstone
fill 404 225 288 417 225 288 minecraft:smooth_sandstone
setblock 404 225 289 minecraft:iron_block
setblock 404 225 290 minecraft:dark_oak_planks
setblock 404 225 292 minecraft:spruce_planks
setblock 404 225 296 minecraft:spruce_planks
setblock 404 225 298 minecraft:dark_oak_planks
setblock 404 225 299 minecraft:iron_block
fill 404 225 300 417 225 300 minecraft:smooth_sandstone
fill 405 225 289 417 225 289 minecraft:smooth_sandstone
fill 405 225 290 405 225 292 minecraft:iron_block
fill 405 225 293 405 225 295 minecraft:dark_oak_planks
fill 405 225 296 405 225 298 minecraft:iron_block
fill 405 225 299 417 225 299 minecraft:sandstone
fill 406 225 290 417 225 290 minecraft:sandstone
fill 406 225 291 417 225 292 minecraft:smooth_sandstone
fill 406 225 293 417 225 293 minecraft:sandstone
setblock 406 225 294 minecraft:iron_block
fill 406 225 295 417 225 295 minecraft:smooth_sandstone
fill 406 225 296 417 225 296 minecraft:sandstone
fill 406 225 297 417 225 298 minecraft:smooth_sandstone
fill 407 225 294 417 225 294 minecraft:smooth_sandstone
fill 388 226 285 388 227 285 minecraft:bone_block
fill 388 226 294 388 232 294 minecraft:bone_block
fill 388 226 303 388 227 303 minecraft:bone_block
fill 391 226 285 391 227 285 minecraft:bone_block
fill 391 226 294 391 232 294 minecraft:bone_block
fill 391 226 303 391 227 303 minecraft:bone_block
fill 394 226 285 394 227 285 minecraft:bone_block
fill 394 226 303 394 227 303 minecraft:bone_block
fill 397 226 285 397 227 285 minecraft:bone_block
fill 397 226 303 397 227 303 minecraft:bone_block
fill 400 226 285 400 227 285 minecraft:bone_block
fill 400 226 303 400 227 303 minecraft:bone_block
fill 403 226 285 403 227 285 minecraft:bone_block
fill 403 226 294 403 232 294 minecraft:bone_block
fill 403 226 303 403 227 303 minecraft:bone_block
fill 406 226 285 406 227 285 minecraft:bone_block
fill 406 226 294 406 232 294 minecraft:bone_block
fill 406 226 303 406 227 303 minecraft:bone_block
fill 376 228 275 376 231 317 minecraft:red_terracotta
fill 377 228 275 418 231 275 minecraft:red_terracotta
fill 377 228 317 418 231 317 minecraft:red_terracotta
setblock 379 228 278 minecraft:light[level=12]
setblock 379 228 285 minecraft:light[level=12]
setblock 379 228 292 minecraft:light[level=12]
setblock 379 228 299 minecraft:light[level=12]
setblock 379 228 306 minecraft:light[level=12]
setblock 379 228 313 minecraft:light[level=12]
setblock 386 228 278 minecraft:light[level=12]
setblock 386 228 285 minecraft:light[level=12]
setblock 386 228 292 minecraft:light[level=12]
setblock 386 228 299 minecraft:light[level=12]
setblock 386 228 306 minecraft:light[level=12]
setblock 386 228 313 minecraft:light[level=12]
fill 388 228 286 388 229 286 minecraft:bone_block
fill 388 228 302 388 229 302 minecraft:bone_block
fill 391 228 286 391 229 286 minecraft:bone_block
fill 391 228 302 391 229 302 minecraft:bone_block
setblock 393 228 278 minecraft:light[level=12]
setblock 393 228 285 minecraft:light[level=12]
setblock 393 228 292 minecraft:light[level=12]
setblock 393 228 299 minecraft:light[level=12]
setblock 393 228 306 minecraft:light[level=12]
setblock 393 228 313 minecraft:light[level=12]
fill 394 228 286 394 229 286 minecraft:bone_block
fill 394 228 294 394 232 294 minecraft:bone_block
fill 394 228 302 394 229 302 minecraft:bone_block
fill 397 228 286 397 229 286 minecraft:bone_block
fill 397 228 294 397 232 294 minecraft:bone_block
fill 397 228 302 397 229 302 minecraft:bone_block
setblock 400 228 278 minecraft:light[level=12]
setblock 400 228 285 minecraft:light[level=12]
fill 400 228 286 400 229 286 minecraft:bone_block
setblock 400 228 292 minecraft:light[level=12]
fill 400 228 294 400 232 294 minecraft:bone_block
setblock 400 228 299 minecraft:light[level=12]
fill 400 228 302 400 229 302 minecraft:bone_block
setblock 400 228 306 minecraft:light[level=12]
setblock 400 228 313 minecraft:light[level=12]
fill 403 228 286 403 229 286 minecraft:bone_block
fill 403 228 302 403 229 302 minecraft:bone_block
fill 406 228 286 406 229 286 minecraft:bone_block
fill 406 228 302 406 229 302 minecraft:bone_block
setblock 407 228 278 minecraft:light[level=12]
setblock 407 228 285 minecraft:light[level=12]
setblock 407 228 292 minecraft:light[level=12]
setblock 407 228 299 minecraft:light[level=12]
setblock 407 228 306 minecraft:light[level=12]
setblock 407 228 313 minecraft:light[level=12]
setblock 414 228 278 minecraft:light[level=12]
setblock 414 228 285 minecraft:light[level=12]
setblock 414 228 292 minecraft:light[level=12]
setblock 414 228 299 minecraft:light[level=12]
setblock 414 228 306 minecraft:light[level=12]
setblock 414 228 313 minecraft:light[level=12]
fill 418 228 276 418 231 316 minecraft:red_terracotta
setblock 377 229 288 minecraft:red_terracotta
setblock 377 229 289 minecraft:stripped_oak_log
fill 377 229 290 377 229 293 minecraft:red_terracotta
setblock 377 229 294 minecraft:stripped_oak_log
fill 377 229 295 377 229 298 minecraft:red_terracotta
setblock 377 229 299 minecraft:stripped_oak_log
fill 377 229 300 377 229 303 minecraft:red_terracotta
setblock 377 229 304 minecraft:stripped_oak_log
fill 377 229 305 377 229 308 minecraft:red_terracotta
setblock 377 229 309 minecraft:stripped_oak_log
fill 377 229 310 377 229 313 minecraft:red_terracotta
setblock 377 229 314 minecraft:stripped_oak_log
fill 377 229 315 379 229 316 minecraft:red_terracotta
fill 378 229 290 378 229 292 minecraft:red_terracotta
setblock 378 229 293 minecraft:stripped_oak_log
fill 378 229 294 378 229 297 minecraft:red_terracotta
setblock 378 229 298 minecraft:stripped_oak_log
fill 378 229 299 378 231 300 minecraft:red_terracotta
setblock 378 229 307 minecraft:red_terracotta
setblock 378 229 308 minecraft:stripped_oak_log
fill 378 229 309 378 229 312 minecraft:red_terracotta
setblock 378 229 313 minecraft:stripped_oak_log
fill 378 229 314 381 229 314 minecraft:red_terracotta
setblock 379 229 276 minecraft:red_terracotta
setblock 379 229 291 minecraft:red_terracotta
setblock 379 229 292 minecraft:stripped_oak_log
fill 379 229 293 379 229 296 minecraft:red_terracotta
setblock 379 229 297 minecraft:stripped_oak_log
fill 379 229 298 379 232 298 minecraft:red_terracotta
setblock 379 229 311 minecraft:red_terracotta
setblock 379 229 312 minecraft:stripped_oak_log
fill 379 229 313 379 230 313 minecraft:red_terracotta
setblock 380 229 276 minecraft:stripped_oak_log
fill 380 229 293 380 229 295 minecraft:red_terracotta
setblock 380 229 315 minecraft:red_terracotta
setblock 380 229 316 minecraft:stripped_oak_log
fill 381 229 276 384 229 276 minecraft:red_terracotta
setblock 381 229 315 minecraft:stripped_oak_log
fill 381 229 316 384 229 316 minecraft:red_terracotta
setblock 382 229 314 minecraft:stripped_oak_log
fill 382 229 315 385 229 315 minecraft:red_terracotta
fill 383 229 314 386 229 314 minecraft:red_terracotta
setblock 384 229 277 minecraft:stripped_oak_log
setblock 385 229 276 minecraft:stripped_oak_log
fill 385 229 277 387 230 277 minecraft:red_terracotta
setblock 385 229 316 minecraft:stripped_oak_log
fill 386 229 276 389 229 276 minecraft:red_terracotta
setblock 386 229 315 minecraft:stripped_oak_log
fill 386 229 316 389 229 316 minecraft:red_terracotta
fill 387 229 278 400 229 279 minecraft:stripped_oak_log
setblock 387 229 314 minecraft:stripped_oak_log
fill 387 229 315 389 229 315 minecraft:red_terracotta
fill 388 229 277 397 229 277 minecraft:stripped_oak_log
setblock 390 229 276 minecraft:stripped_oak_log
setblock 390 229 316 minecraft:stripped_oak_log
fill 391 229 276 394 229 276 minecraft:red_terracotta
fill 391 229 316 394 229 316 minecraft:red_terracotta
setblock 395 229 276 minecraft:stripped_oak_log
setblock 395 229 316 minecraft:stripped_oak_log
fill 396 229 276 399 229 276 minecraft:red_terracotta
fill 396 229 316 399 229 316 minecraft:red_terracotta
fill 397 229 280 415 231 282 minecraft:stripped_oak_log
setblock 398 229 277 minecraft:red_terracotta
fill 398 229 315 400 229 315 minecraft:red_terracotta
setblock 399 229 277 minecraft:stripped_oak_log
setblock 400 229 276 minecraft:stripped_oak_log
fill 400 229 277 403 229 277 minecraft:red_terracotta
setblock 400 229 316 minecraft:stripped_oak_log
fill 401 229 276 404 229 276 minecraft:red_terracotta
fill 401 229 278 402 229 278 minecraft:red_terracotta
fill 401 229 279 415 231 279 minecraft:stripped_oak_log
setblock 401 229 314 minecraft:red_terracotta
setblock 401 229 315 minecraft:stripped_oak_log
fill 401 229 316 404 229 316 minecraft:red_terracotta
setblock 402 229 314 minecraft:stripped_oak_log
fill 402 229 315 405 229 315 minecraft:red_terracotta
setblock 403 229 278 minecraft:stripped_oak_log
fill 403 229 283 415 241 284 minecraft:stripped_oak_log
fill 403 229 314 406 229 314 minecraft:red_terracotta
setblock 404 229 277 minecraft:stripped_oak_log
fill 404 229 278 407 229 278 minecraft:red_terracotta
fill 404 229 313 407 229 313 minecraft:red_terracotta
setblock 405 229 276 minecraft:stripped_oak_log
fill 405 229 277 408 229 277 minecraft:red_terracotta
setblock 405 229 316 minecraft:stripped_oak_log
fill 406 229 276 409 229 276 minecraft:red_terracotta
setblock 406 229 315 minecraft:stripped_oak_log
fill 406 229 316 409 229 316 minecraft:red_terracotta
setblock 407 229 314 minecraft:stripped_oak_log
fill 407 229 315 410 229 315 minecraft:red_terracotta
fill 408 229 278 415 241 278 minecraft:stripped_oak_log
setblock 408 229 313 minecraft:stripped_oak_log
fill 408 229 314 411 229 314 minecraft:red_terracotta
setblock 409 229 277 minecraft:stripped_oak_log
fill 409 229 294 416 231 308 minecraft:stripped_oak_log
setblock 410 229 276 minecraft:stripped_oak_log
fill 410 229 277 411 230 277 minecraft:red_terracotta
setblock 410 229 316 minecraft:stripped_oak_log
fill 411 229 276 414 229 276 minecraft:red_terracotta
setblock 411 229 315 minecraft:stripped_oak_log
fill 411 229 316 414 229 316 minecraft:red_terracotta
fill 412 229 277 415 238 277 minecraft:stripped_oak_log
setblock 412 229 314 minecraft:stripped_oak_log
fill 412 229 315 415 229 315 minecraft:red_terracotta
fill 413 229 314 416 229 314 minecraft:red_terracotta
setblock 415 229 276 minecraft:stripped_oak_log
fill 415 229 313 417 229 313 minecraft:red_terracotta
setblock 415 229 316 minecraft:stripped_oak_log
fill 416 229 276 417 231 276 minecraft:red_terracotta
setblock 416 229 309 minecraft:red_terracotta
setblock 416 229 310 minecraft:stripped_oak_log
fill 416 229 311 417 230 312 minecraft:red_terracotta
setblock 416 229 315 minecraft:stripped_oak_log
fill 416 229 316 417 231 316 minecraft:red_terracotta
fill 417 229 277 417 230 277 minecraft:red_terracotta
fill 417 229 291 417 229 293 minecraft:red_terracotta
setblock 417 229 294 minecraft:stripped_oak_log
fill 417 229 295 417 229 298 minecraft:red_terracotta
fill 417 229 299 417 229 305 minecraft:stripped_oak_log
fill 417 229 306 417 229 308 minecraft:red_terracotta
setblock 417 229 309 minecraft:stripped_oak_log
fill 417 229 310 417 232 310 minecraft:red_terracotta
setblock 417 229 314 minecraft:stripped_oak_log
fill 417 229 315 417 232 315 minecraft:red_terracotta
fill 377 230 289 377 230 292 minecraft:red_terracotta
setblock 377 230 293 minecraft:stripped_oak_log
fill 377 230 294 377 230 297 minecraft:red_terracotta
setblock 377 230 298 minecraft:stripped_oak_log
fill 377 230 299 377 230 302 minecraft:red_terracotta
setblock 377 230 303 minecraft:stripped_oak_log
fill 377 230 304 379 230 306 minecraft:terracotta
setblock 377 230 307 minecraft:red_terracotta
setblock 377 230 308 minecraft:stripped_oak_log
fill 377 230 309 377 230 312 minecraft:red_terracotta
setblock 377 230 313 minecraft:stripped_oak_log
fill 377 230 314 378 230 316 minecraft:red_terracotta
setblock 378 230 276 minecraft:red_terracotta
fill 378 230 290 378 230 291 minecraft:red_terracotta
setblock 378 230 292 minecraft:stripped_oak_log
fill 378 230 293 378 230 296 minecraft:red_terracotta
setblock 378 230 297 minecraft:stripped_oak_log
fill 378 230 298 378 233 298 minecraft:red_terracotta
setblock 378 230 301 minecraft:red_terracotta
setblock 378 230 302 minecraft:stripped_oak_log
fill 378 230 308 378 230 311 minecraft:red_terracotta
setblock 378 230 312 minecraft:stripped_oak_log
fill 378 230 313 378 232 313 minecraft:red_terracotta
setblock 379 230 276 minecraft:stripped_oak_log
setblock 379 230 291 minecraft:stripped_oak_log
fill 379 230 292 379 230 295 minecraft:red_terracotta
setblock 379 230 296 minecraft:stripped_oak_log
fill 379 230 297 380 232 297 minecraft:red_terracotta
fill 379 230 299 379 231 299 minecraft:red_terracotta
fill 379 230 314 379 230 315 minecraft:red_terracotta
setblock 379 230 316 minecraft:stripped_oak_log
fill 380 230 276 383 230 276 minecraft:red_terracotta
fill 380 230 293 380 230 294 minecraft:red_terracotta
setblock 380 230 295 minecraft:stripped_oak_log
fill 380 230 296 380 233 296 minecraft:red_terracotta
setblock 380 230 314 minecraft:red_terracotta
setblock 380 230 315 minecraft:stripped_oak_log
fill 380 230 316 383 230 316 minecraft:red_terracotta
setblock 381 230 314 minecraft:stripped_oak_log
fill 381 230 315 384 230 315 minecraft:red_terracotta
setblock 382 230 277 minecraft:red_terracotta
fill 382 230 294 385 237 294 minecraft:bone_block
fill 382 230 314 385 230 314 minecraft:red_terracotta
setblock 383 230 277 minecraft:stripped_oak_log
setblock 384 230 276 minecraft:stripped_oak_log
fill 384 230 277 384 233 277 minecraft:red_terracotta
fill 384 230 293 386 237 293 minecraft:bone_block
fill 384 230 295 385 236 295 minecraft:bone_block
setblock 384 230 316 minecraft:stripped_oak_log
fill 385 230 276 388 230 276 minecraft:red_terracotta
fill 385 230 292 386 236 292 minecraft:bone_block
setblock 385 230 315 minecraft:stripped_oak_log
fill 385 230 316 388 230 316 minecraft:red_terracotta
fill 386 230 315 388 230 315 minecraft:red_terracotta
fill 387 230 278 399 230 279 minecraft:stripped_oak_log
fill 388 230 277 396 230 277 minecraft:stripped_oak_log
fill 388 230 287 388 231 287 minecraft:bone_block
fill 388 230 301 388 231 301 minecraft:bone_block
setblock 389 230 276 minecraft:stripped_oak_log
setblock 389 230 316 minecraft:stripped_oak_log
fill 390 230 276 393 230 276 minecraft:red_terracotta
fill 390 230 316 393 230 316 minecraft:red_terracotta
fill 391 230 287 391 231 287 minecraft:bone_block
fill 391 230 301 391 231 301 minecraft:bone_block
setblock 394 230 276 minecraft:stripped_oak_log
fill 394 230 287 394 231 287 minecraft:bone_block
fill 394 230 301 394 231 301 minecraft:bone_block
setblock 394 230 316 minecraft:stripped_oak_log
fill 395 230 276 398 230 276 minecraft:red_terracotta
fill 395 230 316 398 230 316 minecraft:red_terracotta
setblock 397 230 277 minecraft:red_terracotta
fill 397 230 287 397 231 287 minecraft:bone_block
fill 397 230 301 397 231 301 minecraft:bone_block
setblock 398 230 277 minecraft:stripped_oak_log
fill 398 230 315 399 230 315 minecraft:red_terracotta
setblock 399 230 276 minecraft:stripped_oak_log
fill 399 230 277 402 230 277 minecraft:red_terracotta
setblock 399 230 316 minecraft:stripped_oak_log
fill 400 230 276 403 230 276 minecraft:red_terracotta
fill 400 230 278 401 230 278 minecraft:red_terracotta
fill 400 230 279 400 231 279 minecraft:stripped_oak_log
fill 400 230 287 400 231 287 minecraft:bone_block
fill 400 230 301 400 231 301 minecraft:bone_block
setblock 400 230 314 minecraft:red_terracotta
setblock 400 230 315 minecraft:stripped_oak_log
fill 400 230 316 403 230 316 minecraft:red_terracotta
setblock 401 230 314 minecraft:stripped_oak_log
fill 401 230 315 404 230 315 minecraft:red_terracotta
setblock 402 230 278 minecraft:stripped_oak_log
fill 402 230 314 405 230 314 minecraft:red_terracotta
setblock 403 230 277 minecraft:stripped_oak_log
fill 403 230 278 406 230 278 minecraft:red_terracotta
fill 403 230 287 403 231 287 minecraft:bone_block
fill 403 230 301 403 231 301 minecraft:bone_block
setblock 404 230 276 minecraft:stripped_oak_log
fill 404 230 277 407 230 277 minecraft:red_terracotta
fill 404 230 313 406 230 313 minecraft:red_terracotta
setblock 404 230 316 minecraft:stripped_oak_log
fill 405 230 276 408 230 276 minecraft:red_terracotta
setblock 405 230 315 minecraft:stripped_oak_log
fill 405 230 316 408 230 316 minecraft:red_terracotta
fill 406 230 287 406 231 287 minecraft:bone_block
fill 406 230 301 406 231 301 minecraft:bone_block
setblock 406 230 314 minecraft:stripped_oak_log
fill 406 230 315 409 230 315 minecraft:red_terracotta
setblock 407 230 278 minecraft:stripped_oak_log
setblock 407 230 313 minecraft:stripped_oak_log
fill 407 230 314 410 230 314 minecraft:red_terracotta
setblock 408 230 277 minecraft:stripped_oak_log
setblock 409 230 276 minecraft:stripped_oak_log
fill 409 230 277 409 233 277 minecraft:red_terracotta
setblock 409 230 316 minecraft:stripped_oak_log
fill 410 230 276 413 230 276 minecraft:red_terracotta
setblock 410 230 315 minecraft:stripped_oak_log
fill 410 230 316 413 230 316 minecraft:red_terracotta
setblock 411 230 314 minecraft:stripped_oak_log
fill 411 230 315 414 230 315 minecraft:red_terracotta
fill 412 230 314 415 230 314 minecraft:red_terracotta
setblock 414 230 276 minecraft:stripped_oak_log
setblock 414 230 316 minecraft:stripped_oak_log
fill 415 230 276 415 233 276 minecraft:red_terracotta
setblock 415 230 315 minecraft:stripped_oak_log
fill 415 230 316 415 233 316 minecraft:red_terracotta
setblock 416 230 310 minecraft:red_terracotta
setblock 416 230 313 minecraft:red_terracotta
setblock 416 230 314 minecraft:stripped_oak_log
fill 416 230 315 416 233 315 minecraft:red_terracotta
fill 417 230 291 417 230 292 minecraft:red_terracotta
setblock 417 230 293 minecraft:stripped_oak_log
fill 417 230 294 417 230 297 minecraft:red_terracotta
setblock 417 230 298 minecraft:stripped_oak_log
fill 417 230 299 417 231 300 minecraft:red_terracotta
fill 417 230 301 417 230 305 minecraft:stripped_oak_log
fill 417 230 306 417 230 307 minecraft:red_terracotta
setblock 417 230 308 minecraft:stripped_oak_log
fill 417 230 309 417 233 309 minecraft:red_terracotta
setblock 417 230 313 minecraft:stripped_oak_log
fill 417 230 314 417 233 314 minecraft:red_terracotta
fill 377 231 289 377 231 291 minecraft:red_terracotta
setblock 377 231 292 minecraft:stripped_oak_log
fill 377 231 293 377 231 296 minecraft:red_terracotta
setblock 377 231 297 minecraft:stripped_oak_log
fill 377 231 298 377 231 301 minecraft:red_terracotta
setblock 377 231 302 minecraft:stripped_oak_log
fill 377 231 303 377 231 306 minecraft:red_terracotta
setblock 377 231 307 minecraft:stripped_oak_log
fill 377 231 308 377 231 311 minecraft:red_terracotta
setblock 377 231 312 minecraft:stripped_oak_log
fill 377 231 313 377 231 316 minecraft:red_terracotta
setblock 378 231 276 minecraft:stripped_oak_log
setblock 378 231 290 minecraft:red_terracotta
setblock 378 231 291 minecraft:stripped_oak_log
fill 378 231 292 378 231 295 minecraft:red_terracotta
setblock 378 231 296 minecraft:stripped_oak_log
fill 378 231 297 378 234 297 minecraft:red_terracotta
setblock 378 231 301 minecraft:stripped_oak_log
fill 378 231 302 378 234 302 minecraft:red_terracotta
fill 378 231 305 378 237 305 minecraft:green_concrete
setblock 378 231 310 minecraft:red_terracotta
setblock 378 231 311 minecraft:stripped_oak_log
fill 378 231 312 378 232 312 minecraft:red_terracotta
fill 378 231 314 378 231 315 minecraft:red_terracotta
setblock 378 231 316 minecraft:stripped_oak_log
fill 379 231 276 382 231 276 minecraft:red_terracotta
fill 379 231 291 379 231 294 minecraft:red_terracotta
setblock 379 231 295 minecraft:stripped_oak_log
fill 379 231 296 379 234 296 minecraft:red_terracotta
setblock 379 231 300 minecraft:stripped_oak_log
setblock 379 231 315 minecraft:stripped_oak_log
fill 379 231 316 382 231 316 minecraft:red_terracotta
setblock 380 231 293 minecraft:red_terracotta
setblock 380 231 294 minecraft:stripped_oak_log
fill 380 231 295 380 234 295 minecraft:red_terracotta
fill 380 231 315 383 231 315 minecraft:red_terracotta
fill 381 231 294 381 236 295 minecraft:bone_block
fill 381 231 314 384 231 314 minecraft:red_terracotta
setblock 382 231 277 minecraft:stripped_oak_log
fill 382 231 293 383 236 293 minecraft:bone_block
fill 382 231 295 383 236 295 minecraft:bone_block
setblock 383 231 276 minecraft:stripped_oak_log
fill 383 231 277 383 234 277 minecraft:red_terracotta
fill 383 231 292 384 236 292 minecraft:bone_block
fill 383 231 296 386 236 296 minecraft:bone_block
setblock 383 231 316 minecraft:stripped_oak_log
fill 384 231 276 387 231 276 minecraft:red_terracotta
fill 384 231 291 385 235 291 minecraft:bone_block
fill 384 231 297 385 235 297 minecraft:bone_block
setblock 384 231 315 minecraft:stripped_oak_log
fill 384 231 316 387 231 316 minecraft:red_terracotta
fill 385 231 277 386 231 277 minecraft:red_terracotta
fill 385 231 315 387 231 315 minecraft:red_terracotta
fill 386 231 294 386 236 295 minecraft:bone_block
fill 387 231 277 395 231 279 minecraft:stripped_oak_log
setblock 388 231 276 minecraft:stripped_oak_log
fill 388 231 288 388 233 288 minecraft:bone_block
fill 388 231 300 388 233 300 minecraft:bone_block
setblock 388 231 316 minecraft:stripped_oak_log
fill 389 231 276 392 231 276 minecraft:red_terracotta
fill 389 231 316 391 231 316 minecraft:red_terracotta
fill 391 231 288 391 233 288 minecraft:bone_block
fill 391 231 300 391 233 300 minecraft:bone_block
setblock 393 231 276 minecraft:stripped_oak_log
fill 394 231 276 397 231 276 minecraft:red_terracotta
fill 394 231 288 394 233 288 minecraft:bone_block
fill 394 231 300 394 233 300 minecraft:bone_block
fill 394 231 316 397 231 316 minecraft:red_terracotta
setblock 396 231 277 minecraft:red_terracotta
fill 396 231 278 398 231 279 minecraft:stripped_oak_log
setblock 397 231 277 minecraft:stripped_oak_log
fill 397 231 288 397 233 288 minecraft:bone_block
fill 397 231 300 397 233 300 minecraft:bone_block
setblock 398 231 276 minecraft:stripped_oak_log
fill 398 231 277 401 231 277 minecraft:red_terracotta
setblock 398 231 315 minecraft:red_terracotta
setblock 398 231 316 minecraft:stripped_oak_log
fill 399 231 276 402 231 276 minecraft:red_terracotta
fill 399 231 278 400 231 278 minecraft:red_terracotta
fill 399 231 279 399 237 279 minecraft:stripped_oak_log
setblock 399 231 315 minecraft:stripped_oak_log
fill 399 231 316 402 231 316 minecraft:red_terracotta
fill 400 231 288 400 233 288 minecraft:bone_block
fill 400 231 300 400 233 300 minecraft:bone_block
fill 400 231 315 403 231 315 minecraft:red_terracotta
setblock 401 231 278 minecraft:stripped_oak_log
fill 401 231 314 404 231 314 minecraft:red_terracotta
setblock 402 231 277 minecraft:stripped_oak_log
fill 402 231 278 405 231 278 minecraft:red_terracotta
setblock 403 231 276 minecraft:stripped_oak_log
fill 403 231 277 406 231 277 minecraft:red_terracotta
fill 403 231 288 403 233 288 minecraft:bone_block
fill 403 231 300 403 233 300 minecraft:bone_block
setblock 403 231 316 minecraft:stripped_oak_log
fill 404 231 276 407 231 276 minecraft:red_terracotta
setblock 404 231 315 minecraft:stripped_oak_log
fill 404 231 316 407 231 316 minecraft:red_terracotta
setblock 405 231 314 minecraft:stripped_oak_log
fill 405 231 315 408 231 315 minecraft:red_terracotta
setblock 406 231 278 minecraft:stripped_oak_log
fill 406 231 288 406 233 288 minecraft:bone_block
fill 406 231 300 406 233 300 minecraft:bone_block
fill 406 231 314 409 231 314 minecraft:red_terracotta
setblock 407 231 277 minecraft:stripped_oak_log
setblock 407 231 278 minecraft:red_terracotta
setblock 408 231 276 minecraft:stripped_oak_log
fill 408 231 277 408 234 277 minecraft:red_terracotta
setblock 408 231 316 minecraft:stripped_oak_log
fill 409 231 276 412 231 276 minecraft:red_terracotta
setblock 409 231 315 minecraft:stripped_oak_log
fill 409 231 316 412 231 316 minecraft:red_terracotta
fill 410 231 277 410 232 277 minecraft:red_terracotta
setblock 410 231 314 minecraft:stripped_oak_log
fill 410 231 315 413 231 315 minecraft:red_terracotta
fill 411 231 277 411 241 277 minecraft:stripped_oak_log
setblock 411 231 314 minecraft:red_terracotta
setblock 413 231 276 minecraft:stripped_oak_log
setblock 413 231 316 minecraft:stripped_oak_log
fill 414 231 276 414 234 276 minecraft:red_terracotta
fill 414 231 310 416 232 310 minecraft:iron_bars
setblock 414 231 315 minecraft:stripped_oak_log
fill 414 231 316 414 234 316 minecraft:red_terracotta
fill 415 231 315 415 234 315 minecraft:red_terracotta
fill 416 231 311 416 231 312 minecraft:red_terracotta
setblock 416 231 313 minecraft:stripped_oak_log
fill 416 231 314 416 234 314 minecraft:red_terracotta
setblock 417 231 277 minecraft:stripped_oak_log
setblock 417 231 292 minecraft:stripped_oak_log
fill 417 231 293 417 231 296 minecraft:red_terracotta
setblock 417 231 297 minecraft:stripped_oak_log
setblock 417 231 298 minecraft:red_terracotta
setblock 417 231 301 minecraft:red_terracotta
fill 417 231 302 417 231 305 minecraft:stripped_oak_log
setblock 417 231 306 minecraft:red_terracotta
setblock 417 231 307 minecraft:stripped_oak_log
setblock 417 231 308 minecraft:red_terracotta
setblock 417 231 311 minecraft:red_terracotta
setblock 417 231 312 minecraft:stripped_oak_log
fill 417 231 313 417 234 313 minecraft:red_terracotta
fill 376 232 275 376 235 317 minecraft:yellow_terracotta
fill 377 232 275 418 234 275 minecraft:yellow_terracotta
setblock 377 232 276 minecraft:stripped_oak_log
fill 377 232 289 377 232 290 minecraft:red_terracotta
setblock 377 232 291 minecraft:stripped_oak_log
fill 377 232 292 377 232 295 minecraft:red_terracotta
setblock 377 232 296 minecraft:stripped_oak_log
fill 377 232 297 377 232 300 minecraft:red_terracotta
setblock 377 232 301 minecraft:stripped_oak_log
fill 377 232 302 377 232 305 minecraft:red_terracotta
setblock 377 232 306 minecraft:stripped_oak_log
fill 377 232 307 377 232 310 minecraft:red_terracotta
setblock 377 232 311 minecraft:stripped_oak_log
fill 377 232 312 377 232 315 minecraft:red_terracotta
setblock 377 232 316 minecraft:stripped_oak_log
fill 377 232 317 418 235 317 minecraft:yellow_terracotta
fill 378 232 276 381 232 276 minecraft:red_terracotta
fill 378 232 291 378 232 294 minecraft:red_terracotta
setblock 378 232 295 minecraft:stripped_oak_log
fill 378 232 296 378 235 296 minecraft:red_terracotta
setblock 378 232 299 minecraft:red_terracotta
setblock 378 232 300 minecraft:stripped_oak_log
fill 378 232 301 378 235 301 minecraft:red_terracotta
fill 378 232 303 378 233 303 minecraft:red_terracotta
setblock 378 232 314 minecraft:red_terracotta
setblock 378 232 315 minecraft:stripped_oak_log
fill 378 232 316 381 232 316 minecraft:red_terracotta
setblock 379 232 278 minecraft:light[level=15]
setblock 379 232 286 minecraft:light[level=15]
fill 379 232 292 379 232 293 minecraft:red_terracotta
setblock 379 232 294 minecraft:stripped_oak_log
fill 379 232 295 379 235 295 minecraft:red_terracotta
setblock 379 232 299 minecraft:stripped_oak_log
fill 379 232 300 379 235 300 minecraft:red_terracotta
setblock 379 232 302 minecraft:light[level=15]
setblock 379 232 310 minecraft:light[level=15]
fill 379 232 315 382 232 315 minecraft:red_terracotta
setblock 380 232 293 minecraft:stripped_oak_log
fill 380 232 294 380 233 294 minecraft:red_terracotta
setblock 380 232 298 minecraft:stripped_oak_log
setblock 381 232 277 minecraft:stripped_oak_log
fill 381 232 292 381 235 293 minecraft:bone_block
fill 381 232 296 382 235 296 minecraft:bone_block
setblock 382 232 276 minecraft:stripped_oak_log
fill 382 232 277 382 235 277 minecraft:red_terracotta
fill 382 232 291 382 235 292 minecraft:bone_block
fill 382 232 297 383 235 297 minecraft:bone_block
setblock 382 232 316 minecraft:stripped_oak_log
fill 383 232 276 386 232 276 minecraft:red_terracotta
fill 383 232 291 383 236 291 minecraft:bone_block
setblock 383 232 315 minecraft:stripped_oak_log
fill 383 232 316 386 232 316 minecraft:red_terracotta
fill 384 232 315 386 232 315 minecraft:red_terracotta
setblock 385 232 277 minecraft:red_terracotta
fill 386 232 277 387 232 277 minecraft:stripped_oak_log
fill 386 232 291 386 233 291 minecraft:bone_block
fill 386 232 297 386 235 297 minecraft:bone_block
setblock 387 232 276 minecraft:shroomlight
setblock 387 232 278 minecraft:shroomlight
fill 387 232 279 387 248 279 minecraft:stripped_oak_log
setblock 387 232 286 minecraft:light[level=15]
fill 387 232 293 387 235 296 minecraft:bone_block
setblock 387 232 302 minecraft:light[level=15]
setblock 387 232 310 minecraft:light[level=15]
setblock 387 232 316 minecraft:stripped_oak_log
fill 388 232 276 388 235 276 minecraft:red_terracotta
setblock 388 232 277 minecraft:shroomlight
fill 388 232 278 388 255 278 minecraft:stripped_oak_log
setblock 388 232 279 minecraft:shroomlight
fill 388 232 293 388 235 293 minecraft:bone_block
fill 388 232 295 388 235 295 minecraft:bone_block
fill 388 232 316 389 232 316 minecraft:red_terracotta
setblock 389 232 276 minecraft:shroomlight
fill 389 232 277 389 239 277 minecraft:stripped_oak_log
setblock 389 232 278 minecraft:shroomlight
fill 389 232 279 389 255 279 minecraft:stripped_oak_log
fill 390 232 276 390 233 276 minecraft:red_terracotta
setblock 390 232 277 minecraft:shroomlight
fill 390 232 278 390 242 278 minecraft:stripped_oak_log
setblock 390 232 279 minecraft:shroomlight
setblock 391 232 276 minecraft:shroomlight
fill 391 232 277 391 237 277 minecraft:stripped_oak_log
setblock 391 232 278 minecraft:shroomlight
fill 391 232 279 391 255 279 minecraft:stripped_oak_log
fill 391 232 293 391 235 293 minecraft:bone_block
fill 391 232 295 391 235 295 minecraft:bone_block
setblock 392 232 276 minecraft:stripped_oak_log
setblock 392 232 277 minecraft:shroomlight
fill 392 232 278 392 240 278 minecraft:stripped_oak_log
setblock 392 232 279 minecraft:shroomlight
setblock 393 232 276 minecraft:shroomlight
fill 393 232 277 393 235 277 minecraft:stripped_oak_log
setblock 393 232 278 minecraft:shroomlight
fill 393 232 279 393 240 279 minecraft:stripped_oak_log
fill 394 232 276 394 234 276 minecraft:red_terracotta
setblock 394 232 277 minecraft:shroomlight
fill 394 232 278 394 238 278 minecraft:stripped_oak_log
setblock 394 232 279 minecraft:shroomlight
fill 394 232 293 394 235 293 minecraft:bone_block
fill 394 232 295 394 235 295 minecraft:bone_block
setblock 395 232 276 minecraft:shroomlight
fill 395 232 277 395 233 277 minecraft:stripped_oak_log
setblock 395 232 278 minecraft:shroomlight
fill 395 232 279 395 238 279 minecraft:stripped_oak_log
setblock 395 232 286 minecraft:light[level=15]
setblock 395 232 294 minecraft:light[level=15]
setblock 395 232 302 minecraft:light[level=15]
setblock 395 232 310 minecraft:light[level=15]
fill 395 232 316 396 232 316 minecraft:red_terracotta
setblock 396 232 276 minecraft:red_terracotta
setblock 396 232 277 minecraft:shroomlight
fill 396 232 278 396 236 278 minecraft:stripped_oak_log
setblock 396 232 279 minecraft:shroomlight
setblock 397 232 276 minecraft:shroomlight
fill 397 232 277 397 235 277 minecraft:red_terracotta
setblock 397 232 278 minecraft:shroomlight
fill 397 232 279 397 237 279 minecraft:stripped_oak_log
setblock 397 232 280 minecraft:shroomlight
fill 397 232 281 397 249 281 minecraft:stripped_oak_log
setblock 397 232 282 minecraft:shroomlight
fill 397 232 293 397 235 293 minecraft:bone_block
setblock 397 232 316 minecraft:stripped_oak_log
fill 398 232 276 398 235 276 minecraft:red_terracotta
setblock 398 232 277 minecraft:shroomlight
setblock 398 232 278 minecraft:stripped_oak_log
setblock 398 232 279 minecraft:shroomlight
fill 398 232 280 398 240 280 minecraft:stripped_oak_log
setblock 398 232 281 minecraft:shroomlight
fill 398 232 282 398 249 282 minecraft:stripped_oak_log
setblock 398 232 315 minecraft:stripped_oak_log
fill 398 232 316 401 232 316 minecraft:red_terracotta
setblock 399 232 276 minecraft:shroomlight
fill 399 232 277 399 233 277 minecraft:red_terracotta
setblock 399 232 278 minecraft:shroomlight
setblock 399 232 280 minecraft:shroomlight
fill 399 232 281 399 249 281 minecraft:stripped_oak_log
setblock 399 232 282 minecraft:shroomlight
fill 399 232 315 402 232 315 minecraft:red_terracotta
fill 400 232 276 400 233 276 minecraft:red_terracotta
setblock 400 232 277 minecraft:shroomlight
setblock 400 232 278 minecraft:stripped_oak_log
setblock 400 232 279 minecraft:shroomlight
fill 400 232 280 400 249 280 minecraft:stripped_oak_log
setblock 400 232 281 minecraft:shroomlight
fill 400 232 282 400 249 282 minecraft:stripped_oak_log
fill 400 232 293 400 235 293 minecraft:bone_block
fill 400 232 295 400 235 295 minecraft:bone_block
setblock 401 232 276 minecraft:shroomlight
setblock 401 232 277 minecraft:stripped_oak_log
setblock 401 232 278 minecraft:shroomlight
fill 401 232 279 401 236 279 minecraft:stripped_oak_log
setblock 401 232 280 minecraft:shroomlight
fill 401 232 281 401 249 281 minecraft:stripped_oak_log
setblock 401 232 282 minecraft:shroomlight
fill 401 232 314 403 232 314 minecraft:red_terracotta
setblock 402 232 276 minecraft:stripped_oak_log
setblock 402 232 277 minecraft:shroomlight
fill 402 232 278 402 234 278 minecraft:red_terracotta
setblock 402 232 279 minecraft:shroomlight
fill 402 232 280 402 249 280 minecraft:stripped_oak_log
setblock 402 232 281 minecraft:shroomlight
fill 402 232 282 402 249 282 minecraft:stripped_oak_log
setblock 402 232 316 minecraft:stripped_oak_log
setblock 403 232 276 minecraft:shroomlight
fill 403 232 277 405 232 277 minecraft:red_terracotta
setblock 403 232 278 minecraft:shroomlight
fill 403 232 279 415 241 279 minecraft:stripped_oak_log
setblock 403 232 280 minecraft:shroomlight
fill 403 232 281 415 241 281 minecraft:stripped_oak_log
setblock 403 232 282 minecraft:shroomlight
setblock 403 232 286 minecraft:light[level=15]
fill 403 232 293 403 235 293 minecraft:bone_block
fill 403 232 295 403 235 295 minecraft:bone_block
setblock 403 232 302 minecraft:light[level=15]
setblock 403 232 310 minecraft:light[level=15]
setblock 403 232 315 minecraft:stripped_oak_log
fill 403 232 316 406 232 316 minecraft:red_terracotta
fill 404 232 276 406 232 276 minecraft:red_terracotta
setblock 404 232 278 minecraft:red_terracotta
fill 404 232 280 415 241 280 minecraft:stripped_oak_log
fill 404 232 282 415 241 282 minecraft:stripped_oak_log
setblock 404 232 314 minecraft:stripped_oak_log
fill 404 232 315 407 232 315 minecraft:red_terracotta
setblock 405 232 278 minecraft:stripped_oak_log
fill 405 232 314 408 232 314 minecraft:red_terracotta
setblock 406 232 277 minecraft:stripped_oak_log
fill 406 232 278 406 233 278 minecraft:red_terracotta
fill 406 232 293 406 235 293 minecraft:bone_block
fill 406 232 295 406 235 295 minecraft:bone_block
setblock 407 232 276 minecraft:stripped_oak_log
fill 407 232 277 407 235 277 minecraft:red_terracotta
fill 407 232 278 407 242 278 minecraft:stripped_oak_log
setblock 407 232 316 minecraft:stripped_oak_log
fill 408 232 276 411 232 276 minecraft:red_terracotta
setblock 408 232 315 minecraft:stripped_oak_log
fill 408 232 316 411 232 316 minecraft:red_terracotta
setblock 409 232 294 minecraft:shroomlight
fill 409 232 295 409 248 295 minecraft:stripped_oak_log
setblock 409 232 296 minecraft:shroomlight
fill 409 232 297 409 251 297 minecraft:stripped_oak_log
setblock 409 232 298 minecraft:shroomlight
fill 409 232 299 409 251 299 minecraft:stripped_oak_log
setblock 409 232 300 minecraft:shroomlight
fill 409 232 301 409 251 301 minecraft:stripped_oak_log
setblock 409 232 302 minecraft:shroomlight
fill 409 232 303 409 251 303 minecraft:stripped_oak_log
setblock 409 232 304 minecraft:shroomlight
fill 409 232 305 409 251 305 minecraft:stripped_oak_log
setblock 409 232 306 minecraft:shroomlight
fill 409 232 307 409 251 307 minecraft:stripped_oak_log
setblock 409 232 308 minecraft:shroomlight
fill 409 232 315 412 232 315 minecraft:red_terracotta
fill 410 232 294 410 248 294 minecraft:stripped_oak_log
setblock 410 232 295 minecraft:shroomlight
fill 410 232 296 410 251 296 minecraft:stripped_oak_log
setblock 410 232 297 minecraft:shroomlight
fill 410 232 298 410 251 298 minecraft:stripped_oak_log
setblock 410 232 299 minecraft:shroomlight
fill 410 232 300 410 251 300 minecraft:stripped_oak_log
setblock 410 232 301 minecraft:shroomlight
fill 410 232 302 410 251 302 minecraft:stripped_oak_log
setblock 410 232 303 minecraft:shroomlight
fill 410 232 304 410 251 304 minecraft:stripped_oak_log
setblock 410 232 305 minecraft:shroomlight
fill 410 232 306 410 251 306 minecraft:stripped_oak_log
setblock 410 232 307 minecraft:shroomlight
fill 410 232 308 410 251 308 minecraft:stripped_oak_log
setblock 411 232 286 minecraft:light[level=15]
setblock 411 232 294 minecraft:shroomlight
fill 411 232 295 411 248 295 minecraft:stripped_oak_log
setblock 411 232 296 minecraft:shroomlight
fill 411 232 297 411 251 297 minecraft:stripped_oak_log
setblock 411 232 298 minecraft:shroomlight
fill 411 232 299 411 251 299 minecraft:stripped_oak_log
setblock 411 232 300 minecraft:shroomlight
fill 411 232 301 411 251 301 minecraft:stripped_oak_log
setblock 411 232 302 minecraft:shroomlight
fill 411 232 303 411 251 303 minecraft:stripped_oak_log
setblock 411 232 304 minecraft:shroomlight
fill 411 232 305 411 251 305 minecraft:stripped_oak_log
setblock 411 232 306 minecraft:shroomlight
fill 411 232 307 411 251 307 minecraft:stripped_oak_log
setblock 411 232 308 minecraft:shroomlight
setblock 411 232 310 minecraft:light[level=15]
setblock 412 232 276 minecraft:stripped_oak_log
fill 412 232 294 412 248 294 minecraft:stripped_oak_log
setblock 412 232 295 minecraft:shroomlight
fill 412 232 296 412 251 296 minecraft:stripped_oak_log
setblock 412 232 297 minecraft:shroomlight
fill 412 232 298 412 251 298 minecraft:stripped_oak_log
setblock 412 232 299 minecraft:shroomlight
fill 412 232 300 412 251 300 minecraft:stripped_oak_log
setblock 412 232 301 minecraft:shroomlight
fill 412 232 302 412 251 302 minecraft:stripped_oak_log
setblock 412 232 303 minecraft:shroomlight
fill 412 232 304 412 251 304 minecraft:stripped_oak_log
setblock 412 232 305 minecraft:shroomlight
fill 412 232 306 412 251 306 minecraft:stripped_oak_log
setblock 412 232 307 minecraft:shroomlight
fill 412 232 308 412 251 308 minecraft:stripped_oak_log
setblock 412 232 316 minecraft:stripped_oak_log
fill 413 232 276 413 235 276 minecraft:red_terracotta
setblock 413 232 294 minecraft:shroomlight
fill 413 232 295 413 248 295 minecraft:stripped_oak_log
setblock 413 232 296 minecraft:shroomlight
fill 413 232 297 413 251 297 minecraft:stripped_oak_log
setblock 413 232 298 minecraft:shroomlight
fill 413 232 299 413 251 299 minecraft:stripped_oak_log
setblock 413 232 300 minecraft:shroomlight
fill 413 232 301 413 251 301 minecraft:stripped_oak_log
setblock 413 232 302 minecraft:shroomlight
fill 413 232 303 413 251 303 minecraft:stripped_oak_log
setblock 413 232 304 minecraft:shroomlight
fill 413 232 305 413 251 305 minecraft:stripped_oak_log
setblock 413 232 306 minecraft:shroomlight
fill 413 232 307 413 251 307 minecraft:stripped_oak_log
setblock 413 232 308 minecraft:shroomlight
setblock 413 232 315 minecraft:stripped_oak_log
fill 413 232 316 413 235 316 minecraft:red_terracotta
fill 414 232 294 414 248 294 minecraft:stripped_oak_log
setblock 414 232 295 minecraft:shroomlight
fill 414 232 296 414 251 296 minecraft:stripped_oak_log
setblock 414 232 297 minecraft:shroomlight
fill 414 232 298 414 251 298 minecraft:stripped_oak_log
setblock 414 232 299 minecraft:shroomlight
fill 414 232 300 414 241 300 minecraft:stripped_oak_log
setblock 414 232 301 minecraft:shroomlight
fill 414 232 302 414 240 302 minecraft:stripped_oak_log
setblock 414 232 303 minecraft:shroomlight
fill 414 232 304 414 240 304 minecraft:stripped_oak_log
setblock 414 232 305 minecraft:shroomlight
fill 414 232 306 414 241 306 minecraft:stripped_oak_log
setblock 414 232 307 minecraft:shroomlight
fill 414 232 308 414 243 308 minecraft:stripped_oak_log
fill 414 232 315 414 233 315 minecraft:red_terracotta
setblock 415 232 294 minecraft:shroomlight
fill 415 232 295 415 248 295 minecraft:stripped_oak_log
setblock 415 232 296 minecraft:shroomlight
fill 415 232 297 415 239 297 minecraft:stripped_oak_log
setblock 415 232 298 minecraft:shroomlight
fill 415 232 299 415 238 299 minecraft:stripped_oak_log
setblock 415 232 300 minecraft:shroomlight
fill 415 232 301 415 237 301 minecraft:stripped_oak_log
setblock 415 232 302 minecraft:shroomlight
fill 415 232 303 415 238 303 minecraft:stripped_oak_log
setblock 415 232 304 minecraft:shroomlight
fill 415 232 305 415 240 305 minecraft:stripped_oak_log
setblock 415 232 306 minecraft:shroomlight
fill 415 232 307 415 239 307 minecraft:stripped_oak_log
setblock 415 232 308 minecraft:shroomlight
setblock 416 232 276 minecraft:red_terracotta
fill 416 232 294 416 240 294 minecraft:stripped_oak_log
setblock 416 232 295 minecraft:shroomlight
fill 416 232 296 416 236 296 minecraft:stripped_oak_log
setblock 416 232 297 minecraft:shroomlight
fill 416 232 298 416 234 298 minecraft:stripped_oak_log
setblock 416 232 299 minecraft:shroomlight
fill 416 232 300 416 234 300 minecraft:stripped_oak_log
setblock 416 232 301 minecraft:shroomlight
fill 416 232 302 416 235 302 minecraft:stripped_oak_log
setblock 416 232 303 minecraft:shroomlight
fill 416 232 304 416 236 304 minecraft:stripped_oak_log
setblock 416 232 305 minecraft:shroomlight
fill 416 232 306 416 238 306 minecraft:stripped_oak_log
setblock 416 232 307 minecraft:shroomlight
fill 416 232 308 416 238 308 minecraft:stripped_oak_log
setblock 416 232 312 minecraft:stripped_oak_log
fill 416 232 313 416 233 313 minecraft:red_terracotta
setblock 416 232 316 minecraft:red_terracotta
setblock 417 232 276 minecraft:stripped_oak_log
fill 417 232 277 417 235 277 minecraft:red_terracotta
fill 417 232 292 417 232 293 minecraft:red_terracotta
setblock 417 232 294 minecraft:shroomlight
setblock 417 232 295 minecraft:red_terracotta
setblock 417 232 296 minecraft:shroomlight
fill 417 232 297 417 235 297 minecraft:red_terracotta
setblock 417 232 298 minecraft:shroomlight
fill 417 232 299 417 233 299 minecraft:red_terracotta
setblock 417 232 300 minecraft:shroomlight
setblock 417 232 301 minecraft:stripped_oak_log
setblock 417 232 302 minecraft:shroomlight
fill 417 232 303 417 234 303 minecraft:red_terracotta
setblock 417 232 304 minecraft:shroomlight
fill 417 232 305 417 233 305 minecraft:stripped_oak_log
setblock 417 232 306 minecraft:shroomlight
fill 417 232 307 417 235 307 minecraft:red_terracotta
setblock 417 232 308 minecraft:shroomlight
setblock 417 232 311 minecraft:stripped_oak_log
fill 417 232 312 417 235 312 minecraft:red_terracotta
setblock 417 232 316 minecraft:stripped_oak_log
fill 418 232 276 418 235 316 minecraft:yellow_terracotta
fill 377 233 276 380 233 276 minecraft:red_terracotta
setblock 377 233 290 minecraft:stripped_oak_log
fill 377 233 291 377 233 294 minecraft:red_terracotta
setblock 377 233 295 minecraft:stripped_oak_log
fill 377 233 296 377 233 299 minecraft:red_terracotta
setblock 377 233 300 minecraft:stripped_oak_log
fill 377 233 301 377 233 304 minecraft:red_terracotta
setblock 377 233 305 minecraft:stripped_oak_log
fill 377 233 306 377 233 309 minecraft:red_terracotta
setblock 377 233 310 minecraft:stripped_oak_log
fill 377 233 311 377 233 314 minecraft:red_terracotta
setblock 377 233 315 minecraft:stripped_oak_log
fill 377 233 316 380 233 316 minecraft:red_terracotta
fill 378 233 291 378 233 293 minecraft:red_terracotta
setblock 378 233 294 minecraft:stripped_oak_log
fill 378 233 295 378 236 295 minecraft:red_terracotta
setblock 378 233 299 minecraft:stripped_oak_log
fill 378 233 300 378 236 300 minecraft:red_terracotta
setblock 378 233 314 minecraft:stripped_oak_log
fill 378 233 315 381 233 315 minecraft:red_terracotta
setblock 379 233 292 minecraft:red_terracotta
setblock 379 233 293 minecraft:stripped_oak_log
fill 379 233 294 379 236 294 minecraft:red_terracotta
setblock 379 233 297 minecraft:red_terracotta
setblock 379 233 298 minecraft:stripped_oak_log
fill 379 233 299 379 236 299 minecraft:red_terracotta
fill 379 233 301 379 234 301 minecraft:red_terracotta
setblock 380 233 297 minecraft:stripped_oak_log
fill 380 233 298 380 236 298 minecraft:red_terracotta
setblock 381 233 276 minecraft:stripped_oak_log
fill 381 233 277 381 236 277 minecraft:red_terracotta
fill 381 233 291 381 234 291 minecraft:bone_block
setblock 381 233 316 minecraft:stripped_oak_log
fill 382 233 276 385 233 276 minecraft:red_terracotta
setblock 382 233 315 minecraft:stripped_oak_log
fill 382 233 316 385 233 316 minecraft:red_terracotta
fill 383 233 290 384 234 290 minecraft:bone_block
fill 383 233 315 384 233 315 minecraft:red_terracotta
setblock 384 233 298 minecraft:bone_block
setblock 385 233 277 minecraft:stripped_oak_log
setblock 386 233 276 minecraft:stripped_oak_log
setblock 386 233 277 minecraft:red_terracotta
setblock 386 233 316 minecraft:stripped_oak_log
fill 387 233 276 387 234 276 minecraft:red_terracotta
fill 387 233 277 387 234 278 minecraft:stripped_oak_log
setblock 387 233 297 minecraft:bone_block
fill 387 233 316 388 233 316 minecraft:red_terracotta
fill 388 233 277 388 234 277 minecraft:stripped_oak_log
fill 388 233 279 388 234 279 minecraft:stripped_oak_log
fill 388 233 289 388 234 289 minecraft:bone_block
fill 388 233 299 388 234 299 minecraft:bone_block
fill 389 233 276 389 234 276 minecraft:red_terracotta
fill 389 233 278 389 234 278 minecraft:stripped_oak_log
fill 390 233 277 390 234 277 minecraft:stripped_oak_log
fill 390 233 279 390 234 279 minecraft:stripped_oak_log
setblock 391 233 276 minecraft:stripped_oak_log
fill 391 233 278 391 234 278 minecraft:stripped_oak_log
fill 391 233 289 391 234 289 minecraft:bone_block
fill 391 233 299 391 234 299 minecraft:bone_block
fill 392 233 276 393 234 276 minecraft:red_terracotta
fill 392 233 277 392 234 277 minecraft:stripped_oak_log
fill 392 233 279 392 234 279 minecraft:stripped_oak_log
fill 393 233 278 393 234 278 minecraft:stripped_oak_log
fill 394 233 277 394 234 277 minecraft:stripped_oak_log
fill 394 233 279 394 234 279 minecraft:stripped_oak_log
fill 394 233 289 394 234 289 minecraft:bone_block
fill 394 233 299 394 234 299 minecraft:bone_block
setblock 395 233 276 minecraft:red_terracotta
fill 395 233 278 395 234 278 minecraft:stripped_oak_log
setblock 395 233 316 minecraft:red_terracotta
setblock 396 233 276 minecraft:stripped_oak_log
fill 396 233 277 396 234 277 minecraft:red_terracotta
fill 396 233 279 396 234 279 minecraft:stripped_oak_log
setblock 396 233 280 minecraft:brown_terracotta
setblock 396 233 316 minecraft:stripped_oak_log
fill 397 233 276 397 234 276 minecraft:red_terracotta
fill 397 233 278 397 234 278 minecraft:stripped_oak_log
fill 397 233 280 397 234 280 minecraft:stripped_oak_log
fill 397 233 282 397 234 282 minecraft:stripped_oak_log
fill 397 233 289 397 234 289 minecraft:bone_block
fill 397 233 299 397 234 299 minecraft:bone_block
fill 397 233 316 400 233 316 minecraft:red_terracotta
fill 398 233 277 398 233 278 minecraft:red_terracotta
fill 398 233 279 398 234 279 minecraft:stripped_oak_log
fill 398 233 281 398 234 281 minecraft:stripped_oak_log
fill 398 233 315 401 233 315 minecraft:red_terracotta
fill 399 233 276 399 234 276 minecraft:red_terracotta
setblock 399 233 278 minecraft:stripped_oak_log
fill 399 233 280 399 234 280 minecraft:stripped_oak_log
fill 399 233 282 399 234 282 minecraft:stripped_oak_log
setblock 400 233 277 minecraft:stripped_oak_log
fill 400 233 278 401 234 278 minecraft:red_terracotta
fill 400 233 279 400 234 279 minecraft:stripped_oak_log
fill 400 233 281 400 234 281 minecraft:stripped_oak_log
fill 400 233 289 400 234 289 minecraft:bone_block
fill 400 233 299 400 234 299 minecraft:bone_block
setblock 401 233 276 minecraft:stripped_oak_log
fill 401 233 277 404 233 277 minecraft:red_terracotta
fill 401 233 280 401 234 280 minecraft:stripped_oak_log
fill 401 233 282 401 234 282 minecraft:stripped_oak_log
fill 401 233 314 402 233 314 minecraft:red_terracotta
setblock 401 233 316 minecraft:stripped_oak_log
fill 402 233 276 405 233 276 minecraft:red_terracotta
fill 402 233 279 402 234 279 minecraft:stripped_oak_log
fill 402 233 281 402 234 281 minecraft:stripped_oak_log
setblock 402 233 315 minecraft:stripped_oak_log
fill 402 233 316 405 233 316 minecraft:red_terracotta
setblock 403 233 278 minecraft:red_terracotta
fill 403 233 280 403 234 280 minecraft:stripped_oak_log
fill 403 233 282 403 234 282 minecraft:stripped_oak_log
fill 403 233 289 403 234 289 minecraft:bone_block
fill 403 233 299 403 234 299 minecraft:bone_block
setblock 403 233 314 minecraft:stripped_oak_log
fill 403 233 315 406 233 315 minecraft:red_terracotta
setblock 404 233 278 minecraft:stripped_oak_log
fill 404 233 314 406 233 314 minecraft:red_terracotta
setblock 405 233 277 minecraft:stripped_oak_log
fill 405 233 278 405 236 278 minecraft:red_terracotta
setblock 406 233 276 minecraft:stripped_oak_log
fill 406 233 277 406 236 277 minecraft:red_terracotta
fill 406 233 289 406 234 289 minecraft:bone_block
fill 406 233 299 406 234 299 minecraft:bone_block
setblock 406 233 316 minecraft:stripped_oak_log
fill 407 233 276 410 233 276 minecraft:red_terracotta
setblock 407 233 315 minecraft:stripped_oak_log
fill 407 233 316 410 233 316 minecraft:red_terracotta
fill 408 233 315 411 233 315 minecraft:red_terracotta
fill 409 233 294 409 234 294 minecraft:stripped_oak_log
fill 409 233 296 409 234 296 minecraft:stripped_oak_log
fill 409 233 298 409 234 298 minecraft:stripped_oak_log
fill 409 233 300 409 234 300 minecraft:stripped_oak_log
fill 409 233 302 409 234 302 minecraft:stripped_oak_log
fill 409 233 304 409 234 304 minecraft:stripped_oak_log
fill 409 233 306 409 234 306 minecraft:stripped_oak_log
fill 409 233 308 409 234 308 minecraft:stripped_oak_log
fill 410 233 277 410 241 277 minecraft:stripped_oak_log
fill 410 233 295 410 234 295 minecraft:stripped_oak_log
fill 410 233 297 410 234 297 minecraft:stripped_oak_log
fill 410 233 299 410 234 299 minecraft:stripped_oak_log
fill 410 233 301 410 234 301 minecraft:stripped_oak_log
fill 410 233 303 410 234 303 minecraft:stripped_oak_log
fill 410 233 305 410 234 305 minecraft:stripped_oak_log
fill 410 233 307 410 234 307 minecraft:stripped_oak_log
setblock 411 233 276 minecraft:stripped_oak_log
fill 411 233 294 411 234 294 minecraft:stripped_oak_log
fill 411 233 296 411 234 296 minecraft:stripped_oak_log
fill 411 233 298 411 234 298 minecraft:stripped_oak_log
fill 411 233 300 411 234 300 minecraft:stripped_oak_log
fill 411 233 302 411 234 302 minecraft:stripped_oak_log
fill 411 233 304 411 234 304 minecraft:stripped_oak_log
fill 411 233 306 411 234 306 minecraft:stripped_oak_log
fill 411 233 308 411 234 308 minecraft:stripped_oak_log
setblock 411 233 316 minecraft:stripped_oak_log
fill 412 233 276 412 236 276 minecraft:red_terracotta
fill 412 233 295 412 234 295 minecraft:stripped_oak_log
fill 412 233 297 412 234 297 minecraft:stripped_oak_log
fill 412 233 299 412 234 299 minecraft:stripped_oak_log
fill 412 233 301 412 234 301 minecraft:stripped_oak_log
fill 412 233 303 412 234 303 minecraft:stripped_oak_log
fill 412 233 305 412 234 305 minecraft:stripped_oak_log
fill 412 233 307 412 234 307 minecraft:stripped_oak_log
setblock 412 233 315 minecraft:stripped_oak_log
fill 412 233 316 412 236 316 minecraft:red_terracotta
fill 413 233 294 413 234 294 minecraft:stripped_oak_log
fill 413 233 296 413 234 296 minecraft:stripped_oak_log
fill 413 233 298 413 234 298 minecraft:stripped_oak_log
fill 413 233 300 413 234 300 minecraft:stripped_oak_log
fill 413 233 302 413 234 302 minecraft:stripped_oak_log
fill 413 233 304 413 234 304 minecraft:stripped_oak_log
fill 413 233 306 413 234 306 minecraft:stripped_oak_log
fill 413 233 308 413 234 308 minecraft:stripped_oak_log
setblock 413 233 315 minecraft:red_terracotta
fill 414 233 295 414 234 295 minecraft:stripped_oak_log
fill 414 233 297 414 234 297 minecraft:stripped_oak_log
fill 414 233 299 414 234 299 minecraft:stripped_oak_log
fill 414 233 301 414 234 301 minecraft:stripped_oak_log
fill 414 233 303 414 234 303 minecraft:stripped_oak_log
fill 414 233 305 414 234 305 minecraft:stripped_oak_log
fill 414 233 307 414 234 307 minecraft:stripped_oak_log
fill 415 233 294 415 234 294 minecraft:stripped_oak_log
fill 415 233 296 415 234 296 minecraft:stripped_oak_log
fill 415 233 298 415 234 298 minecraft:stripped_oak_log
fill 415 233 300 415 234 300 minecraft:stripped_oak_log
fill 415 233 302 415 234 302 minecraft:stripped_oak_log
fill 415 233 304 415 234 304 minecraft:stripped_oak_log
fill 415 233 306 415 234 306 minecraft:stripped_oak_log
fill 415 233 308 415 234 308 minecraft:stripped_oak_log
setblock 416 233 276 minecraft:stripped_oak_log
fill 416 233 295 417 233 295 minecraft:stripped_oak_log
fill 416 233 297 416 234 297 minecraft:stripped_oak_log
fill 416 233 299 416 234 299 minecraft:stripped_oak_log
fill 416 233 301 416 234 301 minecraft:stripped_oak_log
fill 416 233 303 416 234 303 minecraft:stripped_oak_log
fill 416 233 305 416 234 305 minecraft:stripped_oak_log
fill 416 233 307 416 234 307 minecraft:stripped_oak_log
setblock 416 233 316 minecraft:stripped_oak_log
fill 417 233 276 417 236 276 minecraft:red_terracotta
fill 417 233 293 417 233 294 minecraft:red_terracotta
fill 417 233 296 417 234 296 minecraft:red_terracotta
fill 417 233 298 417 234 298 minecraft:red_terracotta
setblock 417 233 300 minecraft:stripped_oak_log
fill 417 233 301 417 234 302 minecraft:red_terracotta
setblock 417 233 304 minecraft:red_terracotta
fill 417 233 306 417 234 306 minecraft:red_terracotta
fill 417 233 308 417 234 308 minecraft:red_terracotta
setblock 417 233 310 minecraft:stripped_oak_log
fill 417 233 311 417 236 311 minecraft:red_terracotta
setblock 417 233 315 minecraft:stripped_oak_log
fill 417 233 316 417 236 316 minecraft:red_terracotta
fill 377 234 276 377 235 277 minecraft:red_terracotta
fill 377 234 290 377 234 293 minecraft:red_terracotta
setblock 377 234 294 minecraft:stripped_oak_log
fill 377 234 295 377 234 298 minecraft:red_terracotta
setblock 377 234 299 minecraft:stripped_oak_log
fill 377 234 300 377 234 303 minecraft:red_terracotta
setblock 377 234 304 minecraft:stripped_oak_log
fill 377 234 305 377 236 306 minecraft:red_terracotta
fill 377 234 311 377 234 313 minecraft:red_terracotta
setblock 377 234 314 minecraft:stripped_oak_log
fill 377 234 315 377 236 316 minecraft:red_terracotta
fill 378 234 276 379 234 276 minecraft:red_terracotta
fill 378 234 291 378 234 292 minecraft:red_terracotta
setblock 378 234 293 minecraft:stripped_oak_log
fill 378 234 294 378 237 294 minecraft:red_terracotta
setblock 378 234 298 minecraft:stripped_oak_log
fill 378 234 299 378 237 299 minecraft:red_terracotta
setblock 378 234 303 minecraft:stripped_oak_log
fill 378 234 306 378 236 306 minecraft:green_concrete
fill 378 234 316 379 234 316 minecraft:red_terracotta
setblock 379 234 278 minecraft:light[level=12]
setblock 379 234 285 minecraft:light[level=12]
setblock 379 234 292 minecraft:light[level=12]
fill 379 234 293 379 237 293 minecraft:red_terracotta
setblock 379 234 297 minecraft:stripped_oak_log
fill 379 234 298 379 237 298 minecraft:red_terracotta
setblock 379 234 306 minecraft:light[level=12]
setblock 379 234 313 minecraft:light[level=12]
fill 379 234 315 380 234 315 minecraft:red_terracotta
setblock 380 234 276 minecraft:stripped_oak_log
fill 380 234 277 380 237 277 minecraft:red_terracotta
setblock 380 234 296 minecraft:stripped_oak_log
fill 380 234 297 380 237 297 minecraft:red_terracotta
fill 380 234 299 380 235 299 minecraft:red_terracotta
setblock 380 234 316 minecraft:stripped_oak_log
fill 381 234 276 384 234 276 minecraft:red_terracotta
setblock 381 234 297 minecraft:bone_block
setblock 381 234 315 minecraft:stripped_oak_log
fill 381 234 316 384 234 316 minecraft:red_terracotta
setblock 382 234 315 minecraft:red_terracotta
setblock 384 234 277 minecraft:stripped_oak_log
setblock 385 234 276 minecraft:stripped_oak_log
fill 385 234 277 385 237 277 minecraft:red_terracotta
setblock 385 234 316 minecraft:stripped_oak_log
fill 386 234 276 386 237 276 minecraft:red_terracotta
setblock 386 234 278 minecraft:light[level=12]
setblock 386 234 285 minecraft:light[level=12]
setblock 386 234 299 minecraft:light[level=12]
setblock 386 234 306 minecraft:light[level=12]
setblock 386 234 313 minecraft:light[level=12]
setblock 386 234 316 minecraft:red_terracotta
fill 388 234 290 388 235 290 minecraft:bone_block
fill 388 234 298 388 235 298 minecraft:bone_block
setblock 390 234 276 minecraft:stripped_oak_log
setblock 391 234 276 minecraft:red_terracotta
fill 391 234 290 391 235 290 minecraft:bone_block
fill 391 234 298 391 235 298 minecraft:bone_block
fill 391 234 300 395 239 302 minecraft:stripped_oak_log
fill 392 234 298 392 253 299 minecraft:stripped_oak_log
fill 392 234 303 394 271 303 minecraft:stripped_oak_log
setblock 393 234 285 minecraft:light[level=12]
setblock 393 234 292 minecraft:light[level=12]
fill 393 234 299 393 243 299 minecraft:stripped_oak_log
setblock 393 234 306 minecraft:light[level=12]
setblock 393 234 313 minecraft:light[level=12]
fill 394 234 290 394 235 290 minecraft:bone_block
fill 394 234 298 394 235 298 minecraft:bone_block
setblock 395 234 276 minecraft:stripped_oak_log
fill 395 234 277 395 237 277 minecraft:red_terracotta
setblock 395 234 316 minecraft:stripped_oak_log
fill 396 234 276 396 237 276 minecraft:red_terracotta
setblock 396 234 280 minecraft:stripped_oak_log
fill 396 234 300 396 237 301 minecraft:stripped_oak_log
fill 396 234 316 399 234 316 minecraft:red_terracotta
fill 397 234 290 397 235 290 minecraft:bone_block
fill 397 234 298 397 235 298 minecraft:bone_block
setblock 398 234 277 minecraft:red_terracotta
setblock 398 234 278 minecraft:stripped_oak_log
fill 398 234 315 400 234 315 minecraft:red_terracotta
setblock 399 234 277 minecraft:stripped_oak_log
setblock 399 234 278 minecraft:red_terracotta
setblock 400 234 276 minecraft:stripped_oak_log
fill 400 234 277 403 234 277 minecraft:red_terracotta
setblock 400 234 285 minecraft:light[level=12]
fill 400 234 290 400 235 290 minecraft:bone_block
setblock 400 234 292 minecraft:light[level=12]
fill 400 234 298 400 235 298 minecraft:bone_block
setblock 400 234 306 minecraft:light[level=12]
setblock 400 234 313 minecraft:light[level=12]
setblock 400 234 316 minecraft:stripped_oak_log
fill 401 234 276 404 234 276 minecraft:red_terracotta
setblock 401 234 315 minecraft:stripped_oak_log
fill 401 234 316 404 234 316 minecraft:red_terracotta
fill 402 234 315 405 234 315 minecraft:red_terracotta
setblock 403 234 278 minecraft:stripped_oak_log
fill 403 234 290 403 235 290 minecraft:bone_block
fill 403 234 298 403 235 298 minecraft:bone_block
fill 403 234 314 404 234 314 minecraft:red_terracotta
setblock 404 234 277 minecraft:stripped_oak_log
fill 404 234 278 404 237 278 minecraft:red_terracotta
setblock 405 234 276 minecraft:stripped_oak_log
fill 405 234 277 405 237 277 minecraft:red_terracotta
setblock 405 234 316 minecraft:stripped_oak_log
fill 406 234 276 409 234 276 minecraft:red_terracotta
fill 406 234 278 406 242 278 minecraft:stripped_oak_log
fill 406 234 290 406 235 290 minecraft:bone_block
fill 406 234 298 406 235 298 minecraft:bone_block
setblock 406 234 315 minecraft:stripped_oak_log
fill 406 234 316 409 234 316 minecraft:red_terracotta
setblock 407 234 285 minecraft:light[level=12]
setblock 407 234 292 minecraft:light[level=12]
setblock 407 234 299 minecraft:light[level=12]
setblock 407 234 306 minecraft:light[level=12]
setblock 407 234 313 minecraft:light[level=12]
fill 407 234 315 410 234 315 minecraft:red_terracotta
fill 409 234 277 409 241 277 minecraft:stripped_oak_log
setblock 410 234 276 minecraft:stripped_oak_log
setblock 410 234 316 minecraft:stripped_oak_log
fill 411 234 276 411 237 276 minecraft:red_terracotta
fill 411 234 316 411 237 316 minecraft:red_terracotta
setblock 414 234 285 minecraft:light[level=12]
setblock 414 234 292 minecraft:light[level=12]
setblock 414 234 313 minecraft:light[level=12]
setblock 415 234 276 minecraft:stripped_oak_log
setblock 415 234 316 minecraft:stripped_oak_log
fill 416 234 276 416 237 276 minecraft:red_terracotta
setblock 416 234 295 minecraft:stripped_oak_log
setblock 416 234 315 minecraft:stripped_oak_log
fill 416 234 316 416 237 316 minecraft:red_terracotta
setblock 417 234 278 minecraft:red_terracotta
setblock 417 234 293 minecraft:red_terracotta
setblock 417 234 294 minecraft:stripped_oak_log
fill 417 234 295 417 237 295 minecraft:red_terracotta
setblock 417 234 299 minecraft:stripped_oak_log
setblock 417 234 300 minecraft:red_terracotta
setblock 417 234 304 minecraft:stripped_oak_log
fill 417 234 305 417 237 305 minecraft:red_terracotta
setblock 417 234 309 minecraft:stripped_oak_log
fill 417 234 310 417 237 310 minecraft:red_terracotta
setblock 417 234 314 minecraft:stripped_oak_log
fill 417 234 315 417 237 315 minecraft:red_terracotta
fill 377 235 275 399 235 275 minecraft:yellow_terracotta
setblock 377 235 278 minecraft:stripped_oak_log
fill 377 235 290 377 235 292 minecraft:red_terracotta
setblock 377 235 293 minecraft:stripped_oak_log
fill 377 235 294 377 235 297 minecraft:red_terracotta
setblock 377 235 298 minecraft:stripped_oak_log
fill 377 235 299 377 235 302 minecraft:red_terracotta
setblock 377 235 303 minecraft:stripped_oak_log
fill 377 235 304 378 237 304 minecraft:red_terracotta
setblock 377 235 307 minecraft:red_terracotta
setblock 377 235 313 minecraft:stripped_oak_log
fill 377 235 314 377 238 314 minecraft:red_terracotta
setblock 378 235 276 minecraft:red_terracotta
setblock 378 235 291 minecraft:red_terracotta
setblock 378 235 292 minecraft:stripped_oak_log
fill 378 235 293 378 238 293 minecraft:red_terracotta
setblock 378 235 297 minecraft:stripped_oak_log
fill 378 235 298 378 238 298 minecraft:red_terracotta
setblock 378 235 302 minecraft:stripped_oak_log
fill 378 235 303 378 238 303 minecraft:red_terracotta
setblock 378 235 316 minecraft:red_terracotta
setblock 379 235 276 minecraft:stripped_oak_log
setblock 379 235 296 minecraft:stripped_oak_log
fill 379 235 297 379 238 297 minecraft:red_terracotta
setblock 379 235 301 minecraft:stripped_oak_log
fill 379 235 302 379 238 302 minecraft:red_terracotta
setblock 379 235 316 minecraft:stripped_oak_log
fill 380 235 276 383 235 276 minecraft:red_terracotta
setblock 380 235 295 minecraft:stripped_oak_log
fill 380 235 296 380 238 296 minecraft:red_terracotta
fill 380 235 316 383 235 316 minecraft:red_terracotta
setblock 383 235 277 minecraft:stripped_oak_log
setblock 384 235 276 minecraft:stripped_oak_log
fill 384 235 277 384 238 277 minecraft:red_terracotta
setblock 384 235 316 minecraft:stripped_oak_log
fill 385 235 276 385 238 276 minecraft:red_terracotta
setblock 385 235 316 minecraft:red_terracotta
setblock 387 235 276 minecraft:shroomlight
fill 387 235 277 387 239 277 minecraft:stripped_oak_log
setblock 387 235 278 minecraft:shroomlight
setblock 388 235 277 minecraft:shroomlight
setblock 388 235 279 minecraft:shroomlight
fill 388 235 291 388 235 292 minecraft:bone_block
fill 388 235 294 408 236 294 minecraft:bone_block
fill 388 235 296 388 235 297 minecraft:bone_block
setblock 389 235 276 minecraft:shroomlight
setblock 389 235 278 minecraft:shroomlight
fill 390 235 276 390 238 276 minecraft:red_terracotta
setblock 390 235 277 minecraft:shroomlight
setblock 390 235 279 minecraft:shroomlight
fill 390 235 299 390 236 302 minecraft:brown_terracotta
setblock 391 235 276 minecraft:shroomlight
setblock 391 235 278 minecraft:shroomlight
fill 391 235 291 391 235 292 minecraft:bone_block
fill 391 235 296 391 235 297 minecraft:bone_block
fill 391 235 299 391 271 299 minecraft:stripped_oak_log
fill 391 235 303 391 236 303 minecraft:brown_terracotta
fill 392 235 276 392 236 276 minecraft:red_terracotta
setblock 392 235 277 minecraft:shroomlight
setblock 392 235 279 minecraft:shroomlight
fill 392 235 297 392 236 297 minecraft:brown_terracotta
fill 392 235 304 395 236 304 minecraft:brown_terracotta
setblock 393 235 276 minecraft:shroomlight
setblock 393 235 278 minecraft:shroomlight
setblock 394 235 276 minecraft:stripped_oak_log
setblock 394 235 277 minecraft:shroomlight
setblock 394 235 279 minecraft:shroomlight
fill 394 235 291 394 235 292 minecraft:bone_block
fill 394 235 296 394 235 297 minecraft:bone_block
setblock 395 235 276 minecraft:shroomlight
setblock 395 235 278 minecraft:shroomlight
fill 395 235 303 396 236 303 minecraft:brown_terracotta
fill 395 235 316 398 235 316 minecraft:red_terracotta
setblock 396 235 277 minecraft:shroomlight
setblock 396 235 279 minecraft:shroomlight
setblock 396 235 280 minecraft:orange_terracotta
fill 396 235 302 397 236 302 minecraft:brown_terracotta
setblock 397 235 276 minecraft:shroomlight
setblock 397 235 278 minecraft:shroomlight
setblock 397 235 280 minecraft:shroomlight
setblock 397 235 282 minecraft:shroomlight
fill 397 235 291 397 235 292 minecraft:bone_block
setblock 397 235 295 minecraft:bone_block
setblock 397 235 297 minecraft:bone_block
fill 397 235 300 397 236 301 minecraft:brown_terracotta
setblock 398 235 277 minecraft:shroomlight
fill 398 235 278 398 238 278 minecraft:red_terracotta
setblock 398 235 279 minecraft:shroomlight
setblock 398 235 281 minecraft:shroomlight
fill 398 235 315 399 235 315 minecraft:red_terracotta
setblock 399 235 276 minecraft:shroomlight
fill 399 235 277 399 238 277 minecraft:red_terracotta
setblock 399 235 278 minecraft:shroomlight
setblock 399 235 280 minecraft:shroomlight
setblock 399 235 282 minecraft:shroomlight
setblock 399 235 316 minecraft:stripped_oak_log
fill 400 235 275 402 238 275 minecraft:shroomlight
fill 400 235 276 400 238 276 minecraft:red_terracotta
setblock 400 235 277 minecraft:shroomlight
fill 400 235 278 400 236 278 minecraft:red_terracotta
setblock 400 235 279 minecraft:shroomlight
setblock 400 235 281 minecraft:shroomlight
fill 400 235 291 400 235 292 minecraft:bone_block
fill 400 235 296 400 235 297 minecraft:bone_block
setblock 400 235 315 minecraft:stripped_oak_log
fill 400 235 316 403 235 316 minecraft:red_terracotta
setblock 401 235 276 minecraft:shroomlight
fill 401 235 277 401 236 277 minecraft:red_terracotta
setblock 401 235 278 minecraft:shroomlight
setblock 401 235 280 minecraft:shroomlight
setblock 401 235 282 minecraft:shroomlight
fill 401 235 315 404 235 315 minecraft:red_terracotta
fill 402 235 276 402 236 276 minecraft:red_terracotta
setblock 402 235 277 minecraft:shroomlight
setblock 402 235 278 minecraft:stripped_oak_log
setblock 402 235 279 minecraft:shroomlight
setblock 402 235 281 minecraft:shroomlight
fill 403 235 275 418 235 275 minecraft:yellow_terracotta
setblock 403 235 276 minecraft:shroomlight
setblock 403 235 277 minecraft:stripped_oak_log
setblock 403 235 278 minecraft:shroomlight
setblock 403 235 280 minecraft:shroomlight
setblock 403 235 282 minecraft:shroomlight
fill 403 235 291 403 235 292 minecraft:bone_block
fill 403 235 296 403 235 297 minecraft:bone_block
setblock 404 235 276 minecraft:stripped_oak_log
fill 404 235 277 404 238 277 minecraft:red_terracotta
setblock 404 235 316 minecraft:stripped_oak_log
fill 405 235 276 408 235 276 minecraft:red_terracotta
setblock 405 235 315 minecraft:stripped_oak_log
fill 405 235 316 408 235 316 minecraft:red_terracotta
fill 406 235 291 406 235 292 minecraft:bone_block
fill 406 235 296 406 235 297 minecraft:bone_block
fill 406 235 315 408 235 315 minecraft:red_terracotta
fill 408 235 277 408 242 277 minecraft:stripped_oak_log
setblock 409 235 276 minecraft:stripped_oak_log
setblock 409 235 294 minecraft:shroomlight
setblock 409 235 296 minecraft:shroomlight
setblock 409 235 298 minecraft:shroomlight
setblock 409 235 300 minecraft:shroomlight
setblock 409 235 302 minecraft:shroomlight
setblock 409 235 304 minecraft:shroomlight
setblock 409 235 306 minecraft:shroomlight
setblock 409 235 308 minecraft:shroomlight
setblock 409 235 316 minecraft:stripped_oak_log
fill 410 235 276 410 238 276 minecraft:red_terracotta
setblock 410 235 295 minecraft:shroomlight
setblock 410 235 297 minecraft:shroomlight
setblock 410 235 299 minecraft:shroomlight
setblock 410 235 301 minecraft:shroomlight
schedule function dropper:buildpart/68_7 1t
