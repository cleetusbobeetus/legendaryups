fill 319 269 590 319 270 590 minecraft:light_blue_stained_glass
setblock 323 269 557 minecraft:sea_lantern
fill 324 269 570 324 307 570 minecraft:purple_stained_glass
fill 324 269 589 324 307 589 minecraft:purple_stained_glass
fill 282 270 565 282 272 565 minecraft:magenta_stained_glass
setblock 282 270 580 minecraft:sea_lantern
fill 282 270 581 282 272 581 minecraft:magenta_stained_glass
fill 282 270 597 282 272 597 minecraft:magenta_stained_glass
fill 286 270 557 286 272 557 minecraft:magenta_stained_glass
fill 296 270 599 296 272 599 minecraft:magenta_stained_glass
fill 298 270 586 299 271 587 minecraft:amethyst_block
setblock 300 270 557 minecraft:white_concrete
fill 301 270 593 301 271 593 minecraft:magenta_stained_glass
fill 302 270 557 302 272 557 minecraft:magenta_stained_glass
fill 312 270 599 312 272 599 minecraft:magenta_stained_glass
fill 318 270 557 318 272 557 minecraft:magenta_stained_glass
setblock 318 270 590 minecraft:light_blue_stained_glass
fill 319 270 599 319 307 599 minecraft:purple_stained_glass
setblock 320 270 599 minecraft:white_concrete
setblock 321 270 590 minecraft:light_blue_stained_glass
setblock 321 270 599 minecraft:light_blue_stained_glass
fill 323 270 557 323 291 557 minecraft:purple_stained_glass
fill 324 270 564 324 307 564 minecraft:purple_stained_glass
setblock 324 270 565 minecraft:white_concrete
fill 324 270 567 324 272 567 minecraft:magenta_stained_glass
setblock 324 270 576 minecraft:light_blue_stained_glass
fill 324 270 583 324 272 583 minecraft:magenta_stained_glass
fill 282 271 580 282 306 580 minecraft:purple_stained_glass
setblock 283 271 599 minecraft:white_concrete
fill 300 271 557 300 276 557 minecraft:purple_stained_glass
setblock 304 271 557 minecraft:white_concrete
fill 320 271 599 321 302 599 minecraft:purple_stained_glass
setblock 324 271 561 minecraft:light_blue_stained_glass
fill 324 271 565 324 307 565 minecraft:purple_stained_glass
setblock 324 271 571 minecraft:white_concrete
fill 324 271 576 324 307 576 minecraft:purple_stained_glass
setblock 282 272 574 minecraft:light_blue_stained_glass
fill 283 272 599 283 287 599 minecraft:purple_stained_glass
setblock 289 272 557 minecraft:light_blue_stained_glass
fill 290 272 557 290 274 557 minecraft:purple_stained_glass
setblock 291 272 557 minecraft:light_blue_stained_glass
fill 304 272 557 304 307 557 minecraft:purple_stained_glass
fill 324 272 561 324 274 561 minecraft:purple_stained_glass
fill 324 272 571 324 276 571 minecraft:purple_stained_glass
fill 282 273 565 282 287 565 minecraft:purple_stained_glass
fill 282 273 574 282 281 574 minecraft:purple_stained_glass
setblock 282 273 579 minecraft:white_concrete
fill 282 273 581 282 287 581 minecraft:purple_stained_glass
fill 282 273 597 282 287 597 minecraft:purple_stained_glass
setblock 285 273 560 minecraft:light[level=14]
setblock 285 273 568 minecraft:light[level=14]
setblock 285 273 576 minecraft:light[level=14]
setblock 285 273 584 minecraft:light[level=14]
setblock 285 273 592 minecraft:light[level=14]
setblock 286 273 557 minecraft:purple_stained_glass
fill 289 273 557 289 278 557 minecraft:purple_stained_glass
fill 291 273 557 291 307 557 minecraft:purple_stained_glass
setblock 293 273 560 minecraft:light[level=14]
setblock 293 273 568 minecraft:light[level=14]
setblock 293 273 576 minecraft:light[level=14]
setblock 293 273 584 minecraft:light[level=14]
setblock 293 273 592 minecraft:light[level=14]
setblock 294 273 599 minecraft:sea_lantern
fill 296 273 599 296 281 599 minecraft:purple_stained_glass
setblock 301 273 560 minecraft:light[level=14]
setblock 301 273 568 minecraft:light[level=14]
setblock 301 273 576 minecraft:light[level=14]
setblock 301 273 584 minecraft:light[level=14]
setblock 301 273 592 minecraft:light[level=14]
fill 302 273 557 302 287 557 minecraft:purple_stained_glass
setblock 309 273 560 minecraft:light[level=14]
setblock 309 273 568 minecraft:light[level=14]
setblock 309 273 576 minecraft:light[level=14]
setblock 309 273 584 minecraft:light[level=14]
setblock 309 273 592 minecraft:light[level=14]
setblock 310 273 599 minecraft:sea_lantern
fill 312 273 599 312 287 599 minecraft:purple_stained_glass
setblock 314 273 557 minecraft:sea_lantern
fill 315 273 557 315 307 557 minecraft:purple_stained_glass
setblock 317 273 560 minecraft:light[level=14]
setblock 317 273 568 minecraft:light[level=14]
setblock 317 273 576 minecraft:light[level=14]
setblock 317 273 584 minecraft:light[level=14]
setblock 317 273 592 minecraft:light[level=14]
fill 318 273 557 318 287 557 minecraft:purple_stained_glass
fill 324 273 567 324 287 567 minecraft:purple_stained_glass
fill 324 273 583 324 287 583 minecraft:purple_stained_glass
fill 282 274 579 282 307 579 minecraft:purple_stained_glass
setblock 286 274 557 minecraft:white_concrete
fill 289 274 599 289 307 599 minecraft:purple_stained_glass
setblock 290 274 599 minecraft:light_blue_stained_glass
setblock 292 274 599 minecraft:light_blue_stained_glass
fill 294 274 599 294 282 599 minecraft:purple_stained_glass
fill 310 274 599 310 291 599 minecraft:purple_stained_glass
fill 314 274 557 314 307 557 minecraft:purple_stained_glass
setblock 324 274 598 minecraft:sea_lantern
setblock 282 275 569 minecraft:white_concrete
fill 286 275 557 286 287 557 minecraft:purple_stained_glass
setblock 290 275 557 minecraft:white_concrete
fill 290 275 599 290 283 599 minecraft:purple_stained_glass
fill 292 275 599 292 307 599 minecraft:purple_stained_glass
setblock 322 275 599 minecraft:sea_lantern
fill 323 275 599 324 307 599 minecraft:purple_stained_glass
setblock 324 275 561 minecraft:light_blue_stained_glass
setblock 324 275 584 minecraft:light_blue_stained_glass
fill 324 275 598 324 286 598 minecraft:purple_stained_glass
fill 282 276 569 282 307 569 minecraft:purple_stained_glass
setblock 282 276 588 minecraft:sea_lantern
fill 290 276 557 290 307 557 minecraft:purple_stained_glass
fill 322 276 599 322 307 599 minecraft:purple_stained_glass
fill 324 276 561 324 300 561 minecraft:purple_stained_glass
fill 324 276 584 324 307 584 minecraft:purple_stained_glass
fill 282 277 588 282 307 588 minecraft:purple_stained_glass
setblock 285 277 557 minecraft:light_blue_stained_glass
setblock 285 277 599 minecraft:light_blue_stained_glass
setblock 300 277 557 minecraft:white_concrete
setblock 324 277 571 minecraft:light_blue_stained_glass
fill 285 278 557 285 307 557 minecraft:purple_stained_glass
fill 285 278 599 285 300 599 minecraft:purple_stained_glass
setblock 298 278 599 minecraft:sea_lantern
fill 299 278 599 299 307 599 minecraft:purple_stained_glass
setblock 300 278 557 minecraft:purple_stained_glass
fill 324 278 571 324 294 571 minecraft:purple_stained_glass
fill 324 278 577 324 307 577 minecraft:purple_stained_glass
setblock 324 278 578 minecraft:sea_lantern
setblock 282 279 571 minecraft:white_concrete
setblock 284 279 557 minecraft:light_blue_stained_glass
setblock 289 279 557 minecraft:white_concrete
fill 297 279 569 307 279 574 minecraft:amethyst_block
fill 297 279 582 307 279 587 minecraft:amethyst_block
fill 298 279 566 304 280 568 minecraft:amethyst_block
fill 298 279 575 305 279 576 minecraft:amethyst_block
fill 298 279 580 305 279 581 minecraft:amethyst_block
fill 298 279 588 304 280 590 minecraft:amethyst_block
fill 298 279 599 298 307 599 minecraft:purple_stained_glass
fill 299 279 565 299 280 565 minecraft:amethyst_block
fill 299 279 577 304 279 577 minecraft:amethyst_block
fill 299 279 579 304 279 579 minecraft:amethyst_block
fill 299 279 591 299 280 591 minecraft:amethyst_block
setblock 300 279 557 minecraft:white_concrete
fill 300 279 578 303 279 578 minecraft:amethyst_block
fill 305 279 567 305 280 568 minecraft:amethyst_block
fill 305 279 588 305 280 589 minecraft:amethyst_block
fill 306 279 568 307 280 568 minecraft:amethyst_block
fill 306 279 575 318 279 575 minecraft:amethyst_block
fill 306 279 581 318 279 581 minecraft:amethyst_block
fill 306 279 588 307 280 588 minecraft:amethyst_block
fill 307 279 576 319 279 576 minecraft:amethyst_block
fill 307 279 580 319 279 580 minecraft:amethyst_block
fill 308 279 570 308 279 574 minecraft:amethyst_block
fill 308 279 577 320 279 577 minecraft:amethyst_block
fill 308 279 579 320 279 579 minecraft:amethyst_block
fill 308 279 582 308 279 586 minecraft:amethyst_block
fill 309 279 571 309 279 574 minecraft:amethyst_block
fill 309 279 578 321 279 578 minecraft:amethyst_block
fill 309 279 582 309 279 585 minecraft:amethyst_block
fill 310 279 572 313 279 574 minecraft:amethyst_block
fill 310 279 582 313 279 584 minecraft:amethyst_block
fill 314 279 573 316 280 574 minecraft:amethyst_block
fill 314 279 582 316 280 583 minecraft:amethyst_block
setblock 314 279 599 minecraft:white_concrete
fill 317 279 574 317 280 574 minecraft:amethyst_block
fill 317 279 582 317 280 582 minecraft:amethyst_block
fill 324 279 578 324 307 578 minecraft:purple_stained_glass
setblock 324 279 580 minecraft:white_concrete
fill 282 280 571 296 280 571 minecraft:purple_stained_glass
setblock 282 280 598 minecraft:white_concrete
fill 283 280 558 296 280 570 minecraft:purple_stained_glass
fill 283 280 572 296 280 598 minecraft:purple_stained_glass
fill 284 280 557 284 307 557 minecraft:purple_stained_glass
fill 289 280 557 289 284 557 minecraft:purple_stained_glass
fill 297 280 558 297 280 568 minecraft:purple_stained_glass
fill 297 280 569 299 280 574 minecraft:amethyst_block
fill 297 280 575 297 280 581 minecraft:purple_stained_glass
fill 297 280 582 299 280 587 minecraft:amethyst_block
fill 297 280 588 297 280 598 minecraft:purple_stained_glass
fill 298 280 558 298 280 565 minecraft:purple_stained_glass
fill 298 280 575 299 280 576 minecraft:amethyst_block
fill 298 280 577 298 280 579 minecraft:purple_stained_glass
fill 298 280 580 299 280 581 minecraft:amethyst_block
fill 298 280 591 298 280 598 minecraft:purple_stained_glass
fill 299 280 558 323 280 564 minecraft:purple_stained_glass
fill 299 280 577 300 280 577 minecraft:amethyst_block
setblock 299 280 578 minecraft:purple_stained_glass
fill 299 280 579 300 280 579 minecraft:amethyst_block
fill 299 280 592 323 280 598 minecraft:purple_stained_glass
fill 300 280 557 300 307 557 minecraft:purple_stained_glass
fill 300 280 565 323 280 565 minecraft:purple_stained_glass
fill 300 280 569 300 280 570 minecraft:amethyst_block
fill 300 280 571 302 280 576 minecraft:purple_stained_glass
fill 300 280 578 301 280 578 minecraft:amethyst_block
fill 300 280 580 302 280 585 minecraft:purple_stained_glass
fill 300 280 586 300 280 587 minecraft:amethyst_block
fill 300 280 591 323 280 591 minecraft:purple_stained_glass
fill 301 280 569 302 280 570 minecraft:purple_stained_glass
fill 301 280 577 302 280 577 minecraft:purple_stained_glass
fill 301 280 579 302 280 579 minecraft:purple_stained_glass
fill 301 280 586 302 280 587 minecraft:purple_stained_glass
fill 302 280 578 303 280 578 minecraft:sea_lantern
fill 303 280 569 307 280 569 minecraft:amethyst_block
fill 303 280 570 303 280 575 minecraft:purple_stained_glass
fill 303 280 576 304 280 577 minecraft:sea_lantern
fill 303 280 579 304 280 580 minecraft:sea_lantern
fill 303 280 581 303 280 586 minecraft:purple_stained_glass
fill 303 280 587 307 280 587 minecraft:amethyst_block
fill 304 280 570 305 280 574 minecraft:purple_stained_glass
fill 304 280 575 308 280 575 minecraft:sea_lantern
fill 304 280 581 308 280 581 minecraft:sea_lantern
fill 304 280 582 305 280 586 minecraft:purple_stained_glass
fill 305 280 566 323 280 566 minecraft:purple_stained_glass
setblock 305 280 576 minecraft:sea_lantern
setblock 305 280 580 minecraft:sea_lantern
fill 305 280 590 323 280 590 minecraft:purple_stained_glass
fill 306 280 567 323 280 567 minecraft:purple_stained_glass
fill 306 280 570 308 280 570 minecraft:amethyst_block
fill 306 280 571 306 280 573 minecraft:purple_stained_glass
setblock 306 280 574 minecraft:sea_lantern
setblock 306 280 582 minecraft:sea_lantern
fill 306 280 583 306 280 585 minecraft:purple_stained_glass
fill 306 280 586 308 280 586 minecraft:amethyst_block
fill 306 280 589 323 280 589 minecraft:purple_stained_glass
fill 307 280 571 309 280 571 minecraft:amethyst_block
fill 307 280 572 307 280 574 minecraft:purple_stained_glass
fill 307 280 576 309 280 576 minecraft:sea_lantern
fill 307 280 580 309 280 580 minecraft:sea_lantern
fill 307 280 582 307 280 584 minecraft:purple_stained_glass
fill 307 280 585 309 280 585 minecraft:amethyst_block
fill 308 280 568 323 280 569 minecraft:purple_stained_glass
fill 308 280 572 313 280 572 minecraft:amethyst_block
fill 308 280 573 308 280 574 minecraft:purple_stained_glass
fill 308 280 577 309 280 577 minecraft:sea_lantern
fill 308 280 579 309 280 579 minecraft:sea_lantern
fill 308 280 582 308 280 583 minecraft:purple_stained_glass
fill 308 280 584 313 280 584 minecraft:amethyst_block
fill 308 280 587 323 280 588 minecraft:purple_stained_glass
fill 309 280 570 323 280 570 minecraft:purple_stained_glass
fill 309 280 573 313 280 573 minecraft:amethyst_block
fill 309 280 574 312 280 575 minecraft:purple_stained_glass
fill 309 280 578 310 280 578 minecraft:sea_lantern
fill 309 280 581 312 280 582 minecraft:purple_stained_glass
fill 309 280 583 313 280 583 minecraft:amethyst_block
fill 309 280 586 323 280 586 minecraft:purple_stained_glass
fill 310 280 571 323 280 571 minecraft:purple_stained_glass
fill 310 280 576 315 280 577 minecraft:purple_stained_glass
fill 310 280 579 315 280 580 minecraft:purple_stained_glass
fill 310 280 585 323 280 585 minecraft:purple_stained_glass
fill 311 280 578 316 280 578 minecraft:purple_stained_glass
setblock 313 280 574 minecraft:amethyst_block
setblock 313 280 575 minecraft:purple_stained_glass
setblock 313 280 581 minecraft:purple_stained_glass
setblock 313 280 582 minecraft:amethyst_block
fill 314 280 572 323 280 572 minecraft:purple_stained_glass
fill 314 280 575 318 280 575 minecraft:amethyst_block
fill 314 280 581 318 280 581 minecraft:amethyst_block
fill 314 280 584 323 280 584 minecraft:purple_stained_glass
fill 314 280 599 314 307 599 minecraft:purple_stained_glass
fill 316 280 576 319 280 577 minecraft:amethyst_block
fill 316 280 579 319 280 580 minecraft:amethyst_block
fill 317 280 573 323 280 573 minecraft:purple_stained_glass
fill 317 280 578 321 280 578 minecraft:amethyst_block
fill 317 280 583 323 280 583 minecraft:purple_stained_glass
fill 318 280 574 323 280 574 minecraft:purple_stained_glass
fill 318 280 582 323 280 582 minecraft:purple_stained_glass
fill 319 280 575 323 280 575 minecraft:purple_stained_glass
fill 319 280 581 323 280 581 minecraft:purple_stained_glass
fill 320 280 576 323 280 576 minecraft:purple_stained_glass
setblock 320 280 577 minecraft:amethyst_block
setblock 320 280 579 minecraft:amethyst_block
fill 320 280 580 324 280 580 minecraft:purple_stained_glass
fill 321 280 577 323 280 577 minecraft:purple_stained_glass
fill 321 280 579 323 280 579 minecraft:purple_stained_glass
fill 322 280 578 323 280 578 minecraft:purple_stained_glass
setblock 324 280 594 minecraft:white_concrete
setblock 282 281 561 minecraft:light_blue_stained_glass
fill 282 281 571 282 307 571 minecraft:purple_stained_glass
fill 282 281 598 282 307 598 minecraft:purple_stained_glass
setblock 284 281 599 minecraft:white_concrete
setblock 285 281 560 minecraft:light[level=14]
setblock 285 281 568 minecraft:light[level=14]
setblock 285 281 576 minecraft:light[level=14]
setblock 285 281 584 minecraft:light[level=14]
setblock 285 281 592 minecraft:light[level=14]
setblock 293 281 560 minecraft:light[level=14]
setblock 293 281 568 minecraft:light[level=14]
setblock 293 281 576 minecraft:light[level=14]
setblock 293 281 584 minecraft:light[level=14]
setblock 293 281 592 minecraft:light[level=14]
setblock 297 281 599 minecraft:light_blue_stained_glass
setblock 300 281 599 minecraft:white_concrete
setblock 301 281 560 minecraft:light[level=14]
setblock 301 281 568 minecraft:light[level=14]
setblock 301 281 576 minecraft:light[level=14]
setblock 301 281 584 minecraft:light[level=14]
setblock 301 281 592 minecraft:light[level=14]
setblock 309 281 560 minecraft:light[level=14]
setblock 309 281 568 minecraft:light[level=14]
setblock 309 281 576 minecraft:light[level=14]
setblock 309 281 584 minecraft:light[level=14]
setblock 309 281 592 minecraft:light[level=14]
setblock 317 281 560 minecraft:light[level=14]
setblock 317 281 568 minecraft:light[level=14]
setblock 317 281 576 minecraft:light[level=14]
setblock 317 281 584 minecraft:light[level=14]
setblock 317 281 592 minecraft:light[level=14]
setblock 324 281 559 minecraft:light_blue_stained_glass
fill 324 281 580 324 296 580 minecraft:purple_stained_glass
fill 324 281 594 324 307 594 minecraft:purple_stained_glass
fill 282 282 561 282 284 561 minecraft:purple_stained_glass
setblock 282 282 574 minecraft:white_concrete
fill 284 282 599 284 285 599 minecraft:purple_stained_glass
setblock 296 282 599 minecraft:light_blue_stained_glass
fill 297 282 599 297 307 599 minecraft:purple_stained_glass
fill 300 282 599 300 307 599 minecraft:purple_stained_glass
setblock 303 282 557 minecraft:sea_lantern
fill 324 282 559 324 307 559 minecraft:purple_stained_glass
setblock 324 282 588 minecraft:light_blue_stained_glass
fill 282 283 574 282 305 574 minecraft:purple_stained_glass
setblock 282 283 592 minecraft:light_blue_stained_glass
setblock 294 283 599 minecraft:sea_lantern
fill 296 283 599 296 287 599 minecraft:purple_stained_glass
fill 303 283 557 303 307 557 minecraft:purple_stained_glass
setblock 313 283 599 minecraft:sea_lantern
fill 324 283 588 324 307 588 minecraft:purple_stained_glass
setblock 324 283 597 minecraft:light_blue_stained_glass
fill 282 284 592 282 307 592 minecraft:purple_stained_glass
setblock 290 284 599 minecraft:sea_lantern
fill 294 284 599 294 291 599 minecraft:purple_stained_glass
fill 313 284 599 313 307 599 minecraft:purple_stained_glass
fill 324 284 572 324 307 572 minecraft:purple_stained_glass
setblock 324 284 573 minecraft:sea_lantern
setblock 324 284 597 minecraft:sea_lantern
setblock 282 285 561 minecraft:light_blue_stained_glass
setblock 282 285 562 minecraft:sea_lantern
setblock 282 285 585 minecraft:white_concrete
setblock 282 285 594 minecraft:light_blue_stained_glass
setblock 289 285 557 minecraft:white_concrete
setblock 290 285 599 minecraft:purple_stained_glass
fill 324 285 573 324 307 573 minecraft:purple_stained_glass
fill 324 285 597 324 307 597 minecraft:purple_stained_glass
fill 282 286 561 282 301 562 minecraft:purple_stained_glass
fill 282 286 585 282 297 585 minecraft:purple_stained_glass
fill 282 286 594 282 307 594 minecraft:purple_stained_glass
setblock 284 286 599 minecraft:sea_lantern
fill 289 286 557 289 307 557 minecraft:purple_stained_glass
setblock 290 286 599 minecraft:light_blue_stained_glass
setblock 301 286 557 minecraft:light_blue_stained_glass
setblock 304 286 599 minecraft:light_blue_stained_glass
fill 306 286 563 306 287 563 minecraft:amethyst_block
fill 284 287 599 284 307 599 minecraft:purple_stained_glass
fill 290 287 599 290 307 599 minecraft:purple_stained_glass
fill 301 287 557 301 305 557 minecraft:purple_stained_glass
fill 304 287 599 304 307 599 minecraft:purple_stained_glass
setblock 324 287 598 minecraft:light_blue_stained_glass
fill 282 288 565 282 290 565 minecraft:magenta_stained_glass
fill 282 288 581 282 290 581 minecraft:magenta_stained_glass
fill 282 288 597 282 290 597 minecraft:magenta_stained_glass
setblock 283 288 599 minecraft:sea_lantern
fill 286 288 557 286 290 557 minecraft:magenta_stained_glass
fill 296 288 599 296 290 599 minecraft:magenta_stained_glass
fill 302 288 557 302 290 557 minecraft:magenta_stained_glass
setblock 307 288 557 minecraft:sea_lantern
fill 312 288 599 312 290 599 minecraft:magenta_stained_glass
fill 318 288 557 318 290 557 minecraft:magenta_stained_glass
fill 321 288 573 323 291 575 minecraft:light_blue_stained_glass
fill 324 288 567 324 290 567 minecraft:magenta_stained_glass
fill 324 288 583 324 290 583 minecraft:magenta_stained_glass
setblock 324 288 585 minecraft:sea_lantern
fill 324 288 598 324 307 598 minecraft:purple_stained_glass
setblock 282 289 573 minecraft:light_blue_stained_glass
fill 283 289 599 283 307 599 minecraft:purple_stained_glass
setblock 285 289 560 minecraft:light[level=14]
setblock 285 289 568 minecraft:light[level=14]
setblock 285 289 576 minecraft:light[level=14]
setblock 285 289 584 minecraft:light[level=14]
setblock 285 289 592 minecraft:light[level=14]
setblock 293 289 560 minecraft:light[level=14]
setblock 293 289 568 minecraft:light[level=14]
setblock 293 289 576 minecraft:light[level=14]
setblock 293 289 584 minecraft:light[level=14]
setblock 293 289 592 minecraft:light[level=14]
setblock 301 289 560 minecraft:light[level=14]
setblock 301 289 568 minecraft:light[level=14]
setblock 301 289 576 minecraft:light[level=14]
setblock 301 289 584 minecraft:light[level=14]
setblock 301 289 592 minecraft:light[level=14]
fill 307 289 557 307 307 557 minecraft:purple_stained_glass
setblock 309 289 560 minecraft:light[level=14]
setblock 309 289 568 minecraft:light[level=14]
setblock 309 289 576 minecraft:light[level=14]
setblock 309 289 584 minecraft:light[level=14]
setblock 309 289 592 minecraft:light[level=14]
setblock 317 289 560 minecraft:light[level=14]
setblock 317 289 568 minecraft:light[level=14]
setblock 317 289 576 minecraft:light[level=14]
setblock 317 289 584 minecraft:light[level=14]
setblock 317 289 592 minecraft:light[level=14]
fill 320 289 573 320 291 575 minecraft:light_blue_stained_glass
fill 322 289 572 322 290 572 minecraft:light_blue_stained_glass
fill 322 289 576 322 290 576 minecraft:light_blue_stained_glass
setblock 324 289 582 minecraft:white_concrete
fill 324 289 585 324 307 585 minecraft:purple_stained_glass
fill 282 290 573 282 296 573 minecraft:purple_stained_glass
setblock 282 290 584 minecraft:light_blue_stained_glass
setblock 311 290 557 minecraft:light_blue_stained_glass
fill 319 290 574 319 291 574 minecraft:light_blue_stained_glass
fill 324 290 582 324 307 582 minecraft:purple_stained_glass
setblock 282 291 560 minecraft:white_concrete
fill 282 291 565 282 296 565 minecraft:purple_stained_glass
fill 282 291 581 282 296 581 minecraft:purple_stained_glass
fill 282 291 584 282 307 584 minecraft:purple_stained_glass
fill 282 291 597 282 296 597 minecraft:purple_stained_glass
fill 286 291 557 286 296 557 minecraft:purple_stained_glass
fill 296 291 599 296 296 599 minecraft:purple_stained_glass
setblock 302 291 557 minecraft:sea_lantern
setblock 307 291 599 minecraft:sea_lantern
fill 311 291 557 311 301 557 minecraft:purple_stained_glass
fill 312 291 599 312 296 599 minecraft:purple_stained_glass
fill 318 291 557 318 296 557 minecraft:purple_stained_glass
setblock 318 291 574 minecraft:light_blue_stained_glass
fill 324 291 567 324 296 567 minecraft:purple_stained_glass
fill 324 291 583 324 296 583 minecraft:purple_stained_glass
fill 282 292 560 282 307 560 minecraft:purple_stained_glass
setblock 282 292 566 minecraft:sea_lantern
setblock 282 292 586 minecraft:sea_lantern
setblock 294 292 599 minecraft:light_blue_stained_glass
fill 302 292 557 302 296 557 minecraft:purple_stained_glass
fill 307 292 599 307 307 599 minecraft:purple_stained_glass
setblock 308 292 599 minecraft:light_blue_stained_glass
setblock 310 292 599 minecraft:sea_lantern
setblock 313 292 557 minecraft:white_concrete
setblock 323 292 557 minecraft:sea_lantern
fill 282 293 557 282 307 557 minecraft:purple_stained_glass
fill 282 293 566 282 307 566 minecraft:purple_stained_glass
fill 282 293 586 282 307 586 minecraft:purple_stained_glass
setblock 283 293 557 minecraft:sea_lantern
setblock 287 293 557 minecraft:white_concrete
setblock 288 293 599 minecraft:sea_lantern
fill 294 293 599 294 304 599 minecraft:purple_stained_glass
fill 308 293 599 308 307 599 minecraft:purple_stained_glass
fill 310 293 599 310 300 599 minecraft:purple_stained_glass
fill 313 293 557 313 307 557 minecraft:purple_stained_glass
fill 323 293 557 323 301 557 minecraft:purple_stained_glass
fill 283 294 557 283 307 557 minecraft:purple_stained_glass
fill 287 294 557 287 307 557 minecraft:purple_stained_glass
fill 288 294 599 288 307 599 minecraft:purple_stained_glass
setblock 293 294 599 minecraft:light_blue_stained_glass
fill 305 294 586 306 295 587 minecraft:light_blue_stained_glass
fill 293 295 599 293 300 599 minecraft:purple_stained_glass
setblock 298 295 557 minecraft:sea_lantern
setblock 306 295 557 minecraft:light_blue_stained_glass
setblock 324 295 571 minecraft:white_concrete
setblock 282 296 590 minecraft:light_blue_stained_glass
fill 298 296 557 298 307 557 minecraft:purple_stained_glass
fill 306 296 557 306 303 557 minecraft:purple_stained_glass
setblock 324 296 558 minecraft:light_blue_stained_glass
fill 324 296 571 324 306 571 minecraft:purple_stained_glass
fill 282 297 565 282 299 565 minecraft:magenta_stained_glass
setblock 282 297 573 minecraft:sea_lantern
setblock 282 297 576 minecraft:white_concrete
fill 282 297 581 282 299 581 minecraft:magenta_stained_glass
fill 282 297 590 282 307 590 minecraft:purple_stained_glass
fill 282 297 597 282 299 597 minecraft:magenta_stained_glass
setblock 285 297 560 minecraft:light[level=14]
setblock 285 297 568 minecraft:light[level=14]
setblock 285 297 576 minecraft:light[level=14]
setblock 285 297 584 minecraft:light[level=14]
setblock 285 297 592 minecraft:light[level=14]
fill 286 297 557 286 299 557 minecraft:magenta_stained_glass
setblock 293 297 560 minecraft:light[level=14]
setblock 293 297 568 minecraft:light[level=14]
setblock 293 297 576 minecraft:light[level=14]
setblock 293 297 584 minecraft:light[level=14]
setblock 293 297 592 minecraft:light[level=14]
fill 296 297 599 296 299 599 minecraft:magenta_stained_glass
setblock 301 297 560 minecraft:light[level=14]
setblock 301 297 568 minecraft:light[level=14]
setblock 301 297 576 minecraft:light[level=14]
setblock 301 297 584 minecraft:light[level=14]
setblock 301 297 592 minecraft:light[level=14]
fill 302 297 557 302 299 557 minecraft:magenta_stained_glass
setblock 309 297 560 minecraft:light[level=14]
setblock 309 297 568 minecraft:light[level=14]
setblock 309 297 576 minecraft:light[level=14]
setblock 309 297 584 minecraft:light[level=14]
setblock 309 297 592 minecraft:light[level=14]
fill 312 297 599 312 299 599 minecraft:magenta_stained_glass
setblock 317 297 560 minecraft:light[level=14]
setblock 317 297 568 minecraft:light[level=14]
setblock 317 297 576 minecraft:light[level=14]
setblock 317 297 584 minecraft:light[level=14]
setblock 317 297 592 minecraft:light[level=14]
fill 318 297 557 318 299 557 minecraft:magenta_stained_glass
fill 324 297 558 324 306 558 minecraft:purple_stained_glass
fill 324 297 567 324 299 567 minecraft:magenta_stained_glass
setblock 324 297 580 minecraft:sea_lantern
fill 324 297 583 324 299 583 minecraft:magenta_stained_glass
setblock 324 297 586 minecraft:light_blue_stained_glass
setblock 324 297 593 minecraft:sea_lantern
setblock 282 298 558 minecraft:white_concrete
fill 282 298 573 282 307 573 minecraft:purple_stained_glass
fill 282 298 576 282 307 576 minecraft:purple_stained_glass
setblock 282 298 585 minecraft:light_blue_stained_glass
setblock 282 298 587 minecraft:light_blue_stained_glass
setblock 305 298 557 minecraft:white_concrete
setblock 305 298 599 minecraft:sea_lantern
fill 324 298 580 324 307 580 minecraft:purple_stained_glass
fill 324 298 586 324 301 586 minecraft:purple_stained_glass
fill 324 298 593 324 307 593 minecraft:purple_stained_glass
fill 282 299 558 282 307 558 minecraft:purple_stained_glass
fill 282 299 585 282 307 585 minecraft:purple_stained_glass
fill 282 299 587 282 305 587 minecraft:purple_stained_glass
fill 305 299 557 305 307 557 minecraft:purple_stained_glass
fill 305 299 599 305 307 599 minecraft:purple_stained_glass
setblock 282 300 565 minecraft:light_blue_stained_glass
fill 282 300 581 282 307 581 minecraft:purple_stained_glass
fill 282 300 597 282 303 597 minecraft:purple_stained_glass
fill 286 300 557 286 307 557 minecraft:purple_stained_glass
setblock 296 300 599 minecraft:purple_stained_glass
fill 302 300 557 302 307 557 minecraft:purple_stained_glass
fill 312 300 599 312 307 599 minecraft:purple_stained_glass
fill 318 300 557 318 307 557 minecraft:purple_stained_glass
setblock 324 300 567 minecraft:purple_stained_glass
fill 324 300 583 324 303 583 minecraft:purple_stained_glass
fill 282 301 565 282 307 565 minecraft:purple_stained_glass
setblock 285 301 599 minecraft:light_blue_stained_glass
setblock 293 301 599 minecraft:white_concrete
setblock 296 301 599 minecraft:white_concrete
setblock 310 301 599 minecraft:sea_lantern
setblock 324 301 561 minecraft:sea_lantern
setblock 324 301 567 minecraft:light_blue_stained_glass
setblock 282 302 561 minecraft:sea_lantern
fill 282 302 562 282 307 562 minecraft:purple_stained_glass
setblock 282 302 575 minecraft:light_blue_stained_glass
fill 285 302 599 285 307 599 minecraft:purple_stained_glass
fill 293 302 599 293 307 599 minecraft:purple_stained_glass
fill 296 302 599 296 307 599 minecraft:purple_stained_glass
fill 310 302 599 310 307 599 minecraft:purple_stained_glass
setblock 311 302 557 minecraft:white_concrete
setblock 323 302 557 minecraft:light_blue_stained_glass
fill 324 302 561 324 307 561 minecraft:purple_stained_glass
fill 324 302 567 324 307 567 minecraft:purple_stained_glass
setblock 324 302 586 minecraft:sea_lantern
fill 282 303 561 282 307 561 minecraft:purple_stained_glass
fill 282 303 575 282 307 575 minecraft:purple_stained_glass
fill 311 303 557 311 307 557 minecraft:purple_stained_glass
setblock 320 303 599 minecraft:white_concrete
fill 321 303 599 321 307 599 minecraft:purple_stained_glass
fill 323 303 557 323 307 557 minecraft:purple_stained_glass
fill 324 303 586 324 307 586 minecraft:purple_stained_glass
setblock 324 303 595 minecraft:light_blue_stained_glass
setblock 282 304 597 minecraft:light_blue_stained_glass
setblock 306 304 557 minecraft:white_concrete
setblock 320 304 599 minecraft:purple_stained_glass
setblock 324 304 583 minecraft:white_concrete
fill 324 304 595 324 307 595 minecraft:purple_stained_glass
setblock 282 305 570 minecraft:light_blue_stained_glass
fill 282 305 597 282 307 597 minecraft:purple_stained_glass
setblock 294 305 599 minecraft:sea_lantern
fill 306 305 557 306 307 557 minecraft:purple_stained_glass
setblock 318 305 599 minecraft:white_concrete
setblock 320 305 599 minecraft:sea_lantern
fill 324 305 583 324 307 583 minecraft:purple_stained_glass
fill 282 306 570 282 307 570 minecraft:purple_stained_glass
setblock 282 306 574 minecraft:sea_lantern
setblock 282 306 587 minecraft:light_blue_stained_glass
fill 294 306 599 294 307 599 minecraft:purple_stained_glass
setblock 301 306 557 minecraft:light_blue_stained_glass
fill 318 306 599 318 307 599 minecraft:purple_stained_glass
fill 320 306 599 320 307 599 minecraft:purple_stained_glass
setblock 282 307 574 minecraft:purple_stained_glass
setblock 282 307 580 minecraft:white_concrete
setblock 282 307 587 minecraft:purple_stained_glass
setblock 301 307 557 minecraft:purple_stained_glass
setblock 311 307 599 minecraft:sea_lantern
setblock 324 307 558 minecraft:white_concrete
setblock 324 307 571 minecraft:light_blue_stained_glass
