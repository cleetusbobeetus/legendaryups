fill 49 211 569 49 214 569 minecraft:cobbled_deepslate
setblock 49 211 573 minecraft:calcite
fill 49 211 574 49 214 574 minecraft:cobbled_deepslate
setblock 49 211 578 minecraft:calcite
fill 49 211 579 50 213 579 minecraft:cobbled_deepslate
setblock 49 211 583 minecraft:calcite
fill 49 211 584 49 214 584 minecraft:cobbled_deepslate
setblock 49 211 588 minecraft:calcite
fill 49 211 589 49 214 589 minecraft:cobbled_deepslate
setblock 49 211 593 minecraft:calcite
fill 49 211 594 49 214 594 minecraft:cobbled_deepslate
setblock 49 211 597 minecraft:cobbled_deepslate
setblock 49 211 598 minecraft:calcite
fill 50 211 557 50 307 557 minecraft:deepslate
fill 50 211 558 50 214 558 minecraft:cobbled_deepslate
setblock 50 211 567 minecraft:calcite
fill 50 211 568 50 213 568 minecraft:cobbled_deepslate
setblock 50 211 572 minecraft:calcite
fill 50 211 573 50 214 573 minecraft:cobbled_deepslate
setblock 50 211 576 minecraft:cobbled_deepslate
setblock 50 211 577 minecraft:calcite
fill 50 211 578 50 214 578 minecraft:cobbled_deepslate
fill 50 211 580 50 212 580 minecraft:cobbled_deepslate
setblock 50 211 582 minecraft:calcite
fill 50 211 583 50 213 583 minecraft:cobbled_deepslate
setblock 50 211 587 minecraft:calcite
fill 50 211 588 50 214 588 minecraft:cobbled_deepslate
setblock 50 211 592 minecraft:calcite
fill 50 211 593 50 214 593 minecraft:cobbled_deepslate
setblock 50 211 596 minecraft:cobbled_deepslate
setblock 50 211 597 minecraft:calcite
fill 50 211 598 50 214 598 minecraft:cobbled_deepslate
setblock 51 211 570 minecraft:cobbled_deepslate
setblock 51 211 571 minecraft:calcite
fill 51 211 572 51 214 572 minecraft:cobbled_deepslate
fill 51 211 574 51 211 575 minecraft:cobbled_deepslate
setblock 51 211 586 minecraft:calcite
setblock 51 211 587 minecraft:cobbled_deepslate
setblock 51 211 591 minecraft:calcite
fill 51 211 592 51 213 592 minecraft:cobbled_deepslate
setblock 51 211 596 minecraft:calcite
fill 51 211 597 51 214 597 minecraft:cobbled_deepslate
fill 52 211 596 52 213 596 minecraft:cobbled_deepslate
setblock 54 211 597 minecraft:cobbled_deepslate
setblock 54 211 598 minecraft:calcite
fill 55 211 557 55 307 557 minecraft:deepslate
fill 55 211 598 55 213 598 minecraft:cobbled_deepslate
fill 57 211 599 57 307 599 minecraft:deepslate
fill 59 211 599 59 307 599 minecraft:deepslate
fill 60 211 557 61 307 557 minecraft:deepslate
setblock 62 211 557 minecraft:cobbled_deepslate
fill 62 211 599 64 307 599 minecraft:deepslate
fill 63 211 557 68 307 557 minecraft:deepslate
fill 65 211 558 65 214 558 minecraft:cobbled_deepslate
setblock 65 211 599 minecraft:cobbled_deepslate
fill 66 211 598 68 211 598 minecraft:cobbled_deepslate
fill 66 211 599 69 307 599 minecraft:deepslate
setblock 67 211 559 minecraft:cobbled_deepslate
setblock 68 211 559 minecraft:calcite
fill 68 211 597 69 211 597 minecraft:cobbled_deepslate
setblock 69 211 557 minecraft:cobbled_deepslate
setblock 69 211 558 minecraft:calcite
fill 69 211 559 69 214 559 minecraft:cobbled_deepslate
setblock 69 211 598 minecraft:calcite
fill 70 211 557 70 307 557 minecraft:deepslate
fill 70 211 558 70 214 558 minecraft:cobbled_deepslate
fill 70 211 560 70 212 560 minecraft:cobbled_deepslate
setblock 70 211 596 minecraft:cobbled_deepslate
setblock 70 211 597 minecraft:calcite
fill 70 211 598 70 214 598 minecraft:cobbled_deepslate
setblock 71 211 557 minecraft:cobbled_deepslate
setblock 71 211 596 minecraft:calcite
fill 71 211 597 71 214 597 minecraft:cobbled_deepslate
fill 72 211 557 72 307 557 minecraft:deepslate
setblock 72 211 559 minecraft:cobbled_deepslate
setblock 72 211 560 minecraft:calcite
fill 72 211 596 72 214 596 minecraft:cobbled_deepslate
setblock 73 211 559 minecraft:calcite
setblock 73 211 560 minecraft:cobbled_deepslate
setblock 74 211 558 minecraft:calcite
fill 74 211 559 74 214 559 minecraft:cobbled_deepslate
setblock 74 211 597 minecraft:cobbled_deepslate
setblock 74 211 598 minecraft:calcite
fill 75 211 558 75 214 558 minecraft:cobbled_deepslate
setblock 75 211 596 minecraft:cobbled_deepslate
setblock 75 211 597 minecraft:calcite
fill 75 211 598 75 214 598 minecraft:cobbled_deepslate
fill 76 211 597 76 214 597 minecraft:cobbled_deepslate
setblock 79 211 558 minecraft:calcite
setblock 79 211 598 minecraft:calcite
setblock 80 211 558 minecraft:cobbled_deepslate
setblock 80 211 597 minecraft:calcite
fill 80 211 598 83 211 598 minecraft:cobbled_deepslate
fill 81 211 557 81 307 557 minecraft:deepslate
fill 81 211 597 84 211 597 minecraft:cobbled_deepslate
setblock 82 211 557 minecraft:cobbled_deepslate
setblock 83 211 583 minecraft:light_blue_stained_glass
fill 83 211 599 83 307 599 minecraft:deepslate
fill 84 211 585 84 213 586 minecraft:light_blue_stained_glass
setblock 84 211 598 minecraft:calcite
fill 85 211 558 88 211 558 minecraft:cobbled_deepslate
fill 85 211 587 85 213 587 minecraft:light_blue_stained_glass
setblock 85 211 596 minecraft:cobbled_deepslate
setblock 85 211 597 minecraft:calcite
fill 85 211 598 85 214 598 minecraft:cobbled_deepslate
fill 86 211 588 86 211 590 minecraft:cobbled_deepslate
setblock 86 211 591 minecraft:calcite
fill 86 211 592 86 214 592 minecraft:cobbled_deepslate
setblock 86 211 595 minecraft:cobbled_deepslate
setblock 86 211 596 minecraft:calcite
fill 86 211 597 86 214 597 minecraft:cobbled_deepslate
fill 87 211 567 87 211 569 minecraft:cobbled_deepslate
setblock 87 211 570 minecraft:calcite
fill 87 211 571 87 212 573 minecraft:cobbled_deepslate
setblock 87 211 585 minecraft:calcite
fill 87 211 586 87 214 586 minecraft:cobbled_deepslate
setblock 87 211 590 minecraft:calcite
fill 87 211 591 87 214 591 minecraft:cobbled_deepslate
setblock 87 211 594 minecraft:cobbled_deepslate
setblock 87 211 595 minecraft:calcite
fill 87 211 596 87 214 596 minecraft:cobbled_deepslate
setblock 88 211 559 minecraft:calcite
fill 88 211 560 88 214 560 minecraft:cobbled_deepslate
setblock 88 211 564 minecraft:calcite
fill 88 211 565 88 214 565 minecraft:cobbled_deepslate
setblock 88 211 569 minecraft:calcite
fill 88 211 570 88 214 570 minecraft:cobbled_deepslate
fill 88 211 572 88 211 573 minecraft:cobbled_deepslate
setblock 88 211 574 minecraft:calcite
fill 88 211 575 88 211 578 minecraft:cobbled_deepslate
setblock 88 211 579 minecraft:calcite
fill 88 211 580 88 213 581 minecraft:cobbled_deepslate
setblock 88 211 584 minecraft:calcite
fill 88 211 585 88 214 585 minecraft:cobbled_deepslate
setblock 88 211 589 minecraft:calcite
fill 88 211 590 88 214 590 minecraft:cobbled_deepslate
setblock 88 211 594 minecraft:calcite
fill 88 211 595 88 214 595 minecraft:cobbled_deepslate
fill 89 211 558 89 307 558 minecraft:deepslate
setblock 89 211 559 minecraft:cobbled_deepslate
fill 89 211 560 89 307 561 minecraft:deepslate
setblock 89 211 562 minecraft:cobbled_deepslate
fill 89 211 563 89 278 570 minecraft:deepslate
fill 89 211 571 89 211 572 minecraft:cobbled_deepslate
fill 89 211 573 89 278 573 minecraft:deepslate
setblock 89 211 574 minecraft:cobbled_deepslate
fill 89 211 575 89 278 575 minecraft:deepslate
setblock 89 211 576 minecraft:cobbled_deepslate
fill 89 211 581 89 278 581 minecraft:deepslate
setblock 89 211 582 minecraft:cobbled_deepslate
fill 89 211 583 89 278 583 minecraft:deepslate
fill 89 211 587 89 307 587 minecraft:deepslate
fill 89 211 590 89 307 590 minecraft:deepslate
fill 47 212 572 47 307 572 minecraft:deepslate
setblock 48 212 563 minecraft:calcite
fill 48 212 564 48 214 564 minecraft:cobbled_deepslate
setblock 48 212 568 minecraft:calcite
fill 48 212 569 48 215 569 minecraft:cobbled_deepslate
setblock 48 212 573 minecraft:calcite
fill 48 212 574 48 215 574 minecraft:cobbled_deepslate
setblock 48 212 577 minecraft:cobbled_deepslate
setblock 48 212 578 minecraft:calcite
fill 48 212 579 48 215 579 minecraft:cobbled_deepslate
setblock 48 212 582 minecraft:cobbled_deepslate
setblock 48 212 583 minecraft:calcite
fill 48 212 584 48 215 584 minecraft:cobbled_deepslate
setblock 48 212 588 minecraft:calcite
fill 48 212 589 48 215 589 minecraft:cobbled_deepslate
setblock 48 212 593 minecraft:calcite
fill 48 212 594 48 215 594 minecraft:cobbled_deepslate
setblock 48 212 598 minecraft:calcite
fill 49 212 557 49 307 557 minecraft:deepslate
fill 49 212 558 49 215 558 minecraft:cobbled_deepslate
setblock 49 212 567 minecraft:calcite
fill 49 212 568 49 215 568 minecraft:cobbled_deepslate
setblock 49 212 571 minecraft:cobbled_deepslate
setblock 49 212 572 minecraft:calcite
fill 49 212 573 49 215 573 minecraft:cobbled_deepslate
setblock 49 212 577 minecraft:calcite
fill 49 212 578 49 215 578 minecraft:cobbled_deepslate
setblock 49 212 582 minecraft:calcite
fill 49 212 583 49 215 583 minecraft:cobbled_deepslate
setblock 49 212 587 minecraft:calcite
fill 49 212 588 49 215 588 minecraft:cobbled_deepslate
setblock 49 212 592 minecraft:calcite
fill 49 212 593 49 215 593 minecraft:cobbled_deepslate
setblock 49 212 597 minecraft:calcite
fill 49 212 598 49 215 598 minecraft:cobbled_deepslate
setblock 50 212 560 minecraft:light[level=14]
setblock 50 212 567 minecraft:cobbled_deepslate
setblock 50 212 571 minecraft:calcite
fill 50 212 572 50 215 572 minecraft:cobbled_deepslate
setblock 50 212 576 minecraft:calcite
fill 50 212 577 50 215 577 minecraft:cobbled_deepslate
setblock 50 212 581 minecraft:calcite
fill 50 212 582 50 213 582 minecraft:cobbled_deepslate
setblock 50 212 586 minecraft:calcite
fill 50 212 587 50 214 587 minecraft:cobbled_deepslate
setblock 50 212 591 minecraft:calcite
fill 50 212 592 50 215 592 minecraft:cobbled_deepslate
setblock 50 212 596 minecraft:calcite
fill 50 212 597 50 215 597 minecraft:cobbled_deepslate
setblock 51 212 570 minecraft:calcite
fill 51 212 571 51 214 571 minecraft:cobbled_deepslate
setblock 51 212 574 minecraft:cobbled_deepslate
setblock 51 212 575 minecraft:calcite
fill 51 212 576 51 215 576 minecraft:cobbled_deepslate
setblock 51 212 590 minecraft:calcite
fill 51 212 591 51 213 591 minecraft:cobbled_deepslate
fill 51 212 596 51 214 596 minecraft:cobbled_deepslate
setblock 53 212 598 minecraft:calcite
setblock 54 212 597 minecraft:calcite
fill 54 212 598 54 215 598 minecraft:cobbled_deepslate
setblock 58 212 560 minecraft:light[level=14]
setblock 58 212 568 minecraft:light[level=14]
setblock 58 212 576 minecraft:light[level=14]
setblock 58 212 584 minecraft:light[level=14]
setblock 58 212 592 minecraft:light[level=14]
fill 62 212 557 62 307 557 minecraft:deepslate
fill 65 212 598 67 212 598 minecraft:cobbled_deepslate
fill 65 212 599 65 307 599 minecraft:deepslate
setblock 66 212 560 minecraft:light[level=14]
setblock 66 212 568 minecraft:light[level=14]
setblock 66 212 576 minecraft:light[level=14]
setblock 66 212 584 minecraft:light[level=14]
setblock 66 212 592 minecraft:light[level=14]
setblock 67 212 559 minecraft:calcite
fill 67 212 597 68 212 597 minecraft:cobbled_deepslate
setblock 68 212 558 minecraft:calcite
fill 68 212 559 68 215 559 minecraft:cobbled_deepslate
setblock 68 212 598 minecraft:calcite
fill 69 212 557 69 307 557 minecraft:deepslate
fill 69 212 558 69 215 558 minecraft:cobbled_deepslate
setblock 69 212 596 minecraft:cobbled_deepslate
setblock 69 212 597 minecraft:calcite
fill 69 212 598 69 215 598 minecraft:cobbled_deepslate
setblock 70 212 596 minecraft:calcite
fill 70 212 597 70 215 597 minecraft:cobbled_deepslate
fill 71 212 557 71 278 557 minecraft:deepslate
setblock 71 212 559 minecraft:cobbled_deepslate
setblock 71 212 560 minecraft:calcite
fill 71 212 596 71 215 596 minecraft:cobbled_deepslate
setblock 72 212 559 minecraft:calcite
setblock 72 212 560 minecraft:cobbled_deepslate
setblock 73 212 558 minecraft:calcite
fill 73 212 559 73 215 559 minecraft:cobbled_deepslate
setblock 73 212 598 minecraft:calcite
fill 74 212 558 74 215 558 minecraft:cobbled_deepslate
setblock 74 212 560 minecraft:light[level=14]
setblock 74 212 568 minecraft:light[level=14]
setblock 74 212 576 minecraft:light[level=14]
setblock 74 212 584 minecraft:light[level=14]
setblock 74 212 592 minecraft:light[level=14]
setblock 74 212 597 minecraft:calcite
fill 74 212 598 74 215 598 minecraft:cobbled_deepslate
setblock 75 212 596 minecraft:calcite
fill 75 212 597 75 215 597 minecraft:cobbled_deepslate
setblock 76 212 596 minecraft:cobbled_deepslate
fill 77 212 597 78 212 597 minecraft:cobbled_deepslate
setblock 78 212 558 minecraft:calcite
setblock 78 212 598 minecraft:calcite
fill 79 212 558 79 213 558 minecraft:cobbled_deepslate
setblock 79 212 597 minecraft:calcite
fill 79 212 598 82 212 598 minecraft:cobbled_deepslate
fill 80 212 597 83 212 597 minecraft:cobbled_deepslate
fill 82 212 557 82 307 557 minecraft:deepslate
setblock 82 212 560 minecraft:light[level=14]
setblock 82 212 568 minecraft:light[level=14]
setblock 82 212 576 minecraft:light[level=14]
setblock 82 212 584 minecraft:light[level=14]
setblock 82 212 592 minecraft:light[level=14]
fill 83 212 585 83 214 585 minecraft:light_blue_stained_glass
setblock 83 212 598 minecraft:calcite
fill 84 212 584 85 215 584 minecraft:light_blue_stained_glass
setblock 84 212 596 minecraft:cobbled_deepslate
setblock 84 212 597 minecraft:calcite
fill 84 212 598 84 215 598 minecraft:cobbled_deepslate
fill 85 212 558 87 212 558 minecraft:cobbled_deepslate
fill 85 212 583 85 216 583 minecraft:light_blue_stained_glass
setblock 85 212 596 minecraft:calcite
fill 85 212 597 85 215 597 minecraft:cobbled_deepslate
fill 86 212 588 86 212 589 minecraft:cobbled_deepslate
setblock 86 212 590 minecraft:calcite
fill 86 212 591 86 215 591 minecraft:cobbled_deepslate
setblock 86 212 595 minecraft:calcite
fill 86 212 596 86 215 596 minecraft:cobbled_deepslate
setblock 87 212 568 minecraft:cobbled_deepslate
setblock 87 212 569 minecraft:calcite
fill 87 212 570 87 214 570 minecraft:cobbled_deepslate
setblock 87 212 574 minecraft:calcite
fill 87 212 575 88 214 575 minecraft:cobbled_deepslate
fill 87 212 585 87 215 585 minecraft:cobbled_deepslate
setblock 87 212 589 minecraft:calcite
fill 87 212 590 87 215 590 minecraft:cobbled_deepslate
setblock 87 212 594 minecraft:calcite
fill 87 212 595 87 215 595 minecraft:cobbled_deepslate
setblock 87 212 598 minecraft:cobbled_deepslate
setblock 88 212 558 minecraft:calcite
fill 88 212 559 88 215 559 minecraft:cobbled_deepslate
setblock 88 212 563 minecraft:calcite
fill 88 212 564 88 213 564 minecraft:cobbled_deepslate
setblock 88 212 568 minecraft:calcite
fill 88 212 569 88 215 569 minecraft:cobbled_deepslate
setblock 88 212 572 minecraft:cobbled_deepslate
setblock 88 212 573 minecraft:calcite
fill 88 212 574 88 215 574 minecraft:cobbled_deepslate
fill 88 212 576 88 212 577 minecraft:cobbled_deepslate
setblock 88 212 578 minecraft:calcite
fill 88 212 579 88 215 579 minecraft:cobbled_deepslate
setblock 88 212 583 minecraft:calcite
fill 88 212 584 88 215 584 minecraft:cobbled_deepslate
setblock 88 212 588 minecraft:calcite
fill 88 212 589 88 215 589 minecraft:cobbled_deepslate
setblock 88 212 593 minecraft:calcite
fill 88 212 594 88 215 594 minecraft:cobbled_deepslate
setblock 88 212 598 minecraft:calcite
fill 89 212 559 89 307 559 minecraft:deepslate
fill 89 212 562 89 307 562 minecraft:deepslate
fill 89 212 571 89 278 572 minecraft:deepslate
fill 89 212 574 89 278 574 minecraft:deepslate
fill 89 212 576 89 278 576 minecraft:deepslate
fill 89 212 582 89 278 582 minecraft:deepslate
fill 89 212 598 89 307 598 minecraft:deepslate
fill 48 213 558 48 216 558 minecraft:cobbled_deepslate
setblock 48 213 563 minecraft:cobbled_deepslate
setblock 48 213 567 minecraft:calcite
fill 48 213 568 48 216 568 minecraft:cobbled_deepslate
setblock 48 213 572 minecraft:calcite
fill 48 213 573 48 216 573 minecraft:cobbled_deepslate
setblock 48 213 577 minecraft:calcite
fill 48 213 578 48 216 578 minecraft:cobbled_deepslate
setblock 48 213 582 minecraft:calcite
fill 48 213 583 48 216 583 minecraft:cobbled_deepslate
setblock 48 213 587 minecraft:calcite
fill 48 213 588 48 216 588 minecraft:cobbled_deepslate
setblock 48 213 592 minecraft:calcite
fill 48 213 593 48 216 593 minecraft:cobbled_deepslate
setblock 48 213 596 minecraft:cobbled_deepslate
setblock 48 213 597 minecraft:calcite
fill 48 213 598 48 216 598 minecraft:cobbled_deepslate
setblock 49 213 566 minecraft:calcite
fill 49 213 567 49 215 567 minecraft:cobbled_deepslate
setblock 49 213 571 minecraft:calcite
fill 49 213 572 49 216 572 minecraft:cobbled_deepslate
setblock 49 213 575 minecraft:cobbled_deepslate
setblock 49 213 576 minecraft:calcite
fill 49 213 577 49 216 577 minecraft:cobbled_deepslate
setblock 49 213 581 minecraft:calcite
fill 49 213 582 49 216 582 minecraft:cobbled_deepslate
setblock 49 213 586 minecraft:calcite
fill 49 213 587 49 216 587 minecraft:cobbled_deepslate
setblock 49 213 591 minecraft:calcite
fill 49 213 592 49 216 592 minecraft:cobbled_deepslate
setblock 49 213 596 minecraft:calcite
fill 49 213 597 49 216 597 minecraft:cobbled_deepslate
setblock 50 213 569 minecraft:cobbled_deepslate
setblock 50 213 570 minecraft:calcite
fill 50 213 571 50 216 571 minecraft:cobbled_deepslate
setblock 50 213 575 minecraft:calcite
fill 50 213 576 50 216 576 minecraft:cobbled_deepslate
setblock 50 213 580 minecraft:calcite
fill 50 213 581 50 214 581 minecraft:cobbled_deepslate
setblock 50 213 585 minecraft:calcite
setblock 50 213 586 minecraft:cobbled_deepslate
setblock 50 213 590 minecraft:calcite
fill 50 213 591 50 215 591 minecraft:cobbled_deepslate
setblock 50 213 594 minecraft:cobbled_deepslate
setblock 50 213 595 minecraft:calcite
fill 50 213 596 50 215 596 minecraft:cobbled_deepslate
setblock 51 213 558 minecraft:cobbled_deepslate
setblock 51 213 570 minecraft:cobbled_deepslate
setblock 51 213 574 minecraft:calcite
fill 51 213 575 51 216 575 minecraft:cobbled_deepslate
setblock 51 213 590 minecraft:cobbled_deepslate
setblock 52 213 558 minecraft:calcite
setblock 52 213 598 minecraft:calcite
setblock 53 213 597 minecraft:calcite
fill 53 213 598 53 216 598 minecraft:cobbled_deepslate
fill 64 213 558 64 215 558 minecraft:cobbled_deepslate
fill 64 213 598 66 213 598 minecraft:cobbled_deepslate
setblock 66 213 559 minecraft:calcite
fill 66 213 597 67 213 597 minecraft:cobbled_deepslate
setblock 67 213 558 minecraft:calcite
fill 67 213 559 67 216 559 minecraft:cobbled_deepslate
setblock 67 213 598 minecraft:calcite
fill 68 213 558 68 216 558 minecraft:cobbled_deepslate
setblock 68 213 596 minecraft:cobbled_deepslate
setblock 68 213 597 minecraft:calcite
fill 68 213 598 68 216 598 minecraft:cobbled_deepslate
setblock 69 213 596 minecraft:calcite
fill 69 213 597 69 216 597 minecraft:cobbled_deepslate
setblock 70 213 560 minecraft:calcite
fill 70 213 596 70 216 596 minecraft:cobbled_deepslate
setblock 71 213 559 minecraft:calcite
setblock 71 213 560 minecraft:cobbled_deepslate
setblock 72 213 558 minecraft:calcite
fill 72 213 559 72 216 559 minecraft:cobbled_deepslate
setblock 72 213 598 minecraft:calcite
fill 73 213 558 73 216 558 minecraft:cobbled_deepslate
setblock 73 213 596 minecraft:cobbled_deepslate
setblock 73 213 597 minecraft:calcite
fill 73 213 598 73 216 598 minecraft:cobbled_deepslate
setblock 74 213 596 minecraft:calcite
fill 74 213 597 74 216 597 minecraft:cobbled_deepslate
fill 75 213 596 75 214 596 minecraft:cobbled_deepslate
setblock 77 213 558 minecraft:calcite
setblock 77 213 597 minecraft:cobbled_deepslate
setblock 77 213 598 minecraft:calcite
fill 78 213 558 78 214 558 minecraft:cobbled_deepslate
setblock 78 213 597 minecraft:calcite
fill 78 213 598 81 213 598 minecraft:cobbled_deepslate
fill 79 213 597 82 213 597 minecraft:cobbled_deepslate
fill 82 213 583 84 215 583 minecraft:light_blue_stained_glass
setblock 82 213 598 minecraft:calcite
fill 83 213 584 83 215 584 minecraft:light_blue_stained_glass
setblock 83 213 586 minecraft:light_blue_stained_glass
setblock 83 213 596 minecraft:cobbled_deepslate
setblock 83 213 597 minecraft:calcite
fill 83 213 598 83 216 598 minecraft:cobbled_deepslate
fill 84 213 558 86 213 558 minecraft:cobbled_deepslate
fill 84 213 582 85 215 582 minecraft:light_blue_stained_glass
setblock 84 213 596 minecraft:calcite
fill 84 213 597 84 216 597 minecraft:cobbled_deepslate
fill 85 213 593 85 213 594 minecraft:cobbled_deepslate
fill 85 213 596 85 216 596 minecraft:cobbled_deepslate
setblock 86 213 589 minecraft:calcite
fill 86 213 590 86 216 590 minecraft:cobbled_deepslate
setblock 86 213 594 minecraft:calcite
fill 86 213 595 86 216 595 minecraft:cobbled_deepslate
setblock 87 213 558 minecraft:calcite
setblock 87 213 569 minecraft:cobbled_deepslate
fill 87 213 571 87 213 572 minecraft:cobbled_deepslate
setblock 87 213 573 minecraft:calcite
fill 87 213 574 87 216 574 minecraft:cobbled_deepslate
fill 87 213 576 88 213 576 minecraft:cobbled_deepslate
setblock 87 213 588 minecraft:calcite
fill 87 213 589 87 216 589 minecraft:cobbled_deepslate
setblock 87 213 593 minecraft:calcite
fill 87 213 594 87 216 594 minecraft:cobbled_deepslate
setblock 87 213 598 minecraft:calcite
fill 88 213 558 88 216 558 minecraft:cobbled_deepslate
setblock 88 213 563 minecraft:cobbled_deepslate
setblock 88 213 567 minecraft:calcite
fill 88 213 568 88 216 568 minecraft:cobbled_deepslate
setblock 88 213 572 minecraft:calcite
fill 88 213 573 88 216 573 minecraft:cobbled_deepslate
setblock 88 213 577 minecraft:calcite
fill 88 213 578 88 216 578 minecraft:cobbled_deepslate
setblock 88 213 582 minecraft:calcite
fill 88 213 583 88 216 583 minecraft:cobbled_deepslate
setblock 88 213 587 minecraft:calcite
fill 88 213 588 88 216 588 minecraft:cobbled_deepslate
setblock 88 213 592 minecraft:calcite
fill 88 213 593 88 216 593 minecraft:cobbled_deepslate
setblock 88 213 597 minecraft:calcite
fill 88 213 598 88 216 598 minecraft:cobbled_deepslate
setblock 48 214 566 minecraft:calcite
fill 48 214 567 48 217 567 minecraft:cobbled_deepslate
setblock 48 214 571 minecraft:calcite
fill 48 214 572 48 217 572 minecraft:cobbled_deepslate
setblock 48 214 575 minecraft:cobbled_deepslate
setblock 48 214 576 minecraft:calcite
fill 48 214 577 48 217 577 minecraft:cobbled_deepslate
setblock 48 214 581 minecraft:calcite
fill 48 214 582 48 217 582 minecraft:cobbled_deepslate
setblock 48 214 586 minecraft:calcite
fill 48 214 587 48 217 587 minecraft:cobbled_deepslate
setblock 48 214 591 minecraft:calcite
fill 48 214 592 48 217 592 minecraft:cobbled_deepslate
setblock 48 214 596 minecraft:calcite
fill 48 214 597 48 217 597 minecraft:cobbled_deepslate
setblock 49 214 570 minecraft:calcite
fill 49 214 571 49 217 571 minecraft:cobbled_deepslate
setblock 49 214 575 minecraft:calcite
fill 49 214 576 49 217 576 minecraft:cobbled_deepslate
setblock 49 214 579 minecraft:cobbled_deepslate
setblock 49 214 580 minecraft:calcite
fill 49 214 581 49 217 581 minecraft:cobbled_deepslate
setblock 49 214 585 minecraft:calcite
fill 49 214 586 49 216 586 minecraft:cobbled_deepslate
setblock 49 214 590 minecraft:calcite
fill 49 214 591 49 217 591 minecraft:cobbled_deepslate
setblock 49 214 595 minecraft:calcite
fill 49 214 596 49 217 596 minecraft:cobbled_deepslate
setblock 50 214 569 minecraft:calcite
fill 50 214 570 50 216 570 minecraft:cobbled_deepslate
setblock 50 214 574 minecraft:calcite
fill 50 214 575 50 217 575 minecraft:cobbled_deepslate
setblock 50 214 579 minecraft:calcite
fill 50 214 580 50 217 580 minecraft:cobbled_deepslate
fill 50 214 583 50 226 584 minecraft:calcite
setblock 50 214 589 minecraft:calcite
fill 50 214 590 50 215 590 minecraft:cobbled_deepslate
setblock 50 214 594 minecraft:calcite
fill 50 214 595 50 215 595 minecraft:cobbled_deepslate
setblock 51 214 558 minecraft:calcite
setblock 51 214 573 minecraft:calcite
fill 51 214 574 51 215 574 minecraft:cobbled_deepslate
setblock 51 214 598 minecraft:calcite
setblock 52 214 597 minecraft:calcite
fill 52 214 598 52 217 598 minecraft:cobbled_deepslate
setblock 53 214 597 minecraft:cobbled_deepslate
fill 64 214 598 65 214 598 minecraft:cobbled_deepslate
setblock 66 214 558 minecraft:calcite
fill 66 214 559 66 217 559 minecraft:cobbled_deepslate
setblock 66 214 597 minecraft:cobbled_deepslate
setblock 66 214 598 minecraft:calcite
fill 67 214 558 67 217 558 minecraft:cobbled_deepslate
setblock 67 214 597 minecraft:calcite
fill 67 214 598 67 217 598 minecraft:cobbled_deepslate
setblock 68 214 596 minecraft:calcite
fill 68 214 597 68 217 597 minecraft:cobbled_deepslate
fill 69 214 596 69 217 596 minecraft:cobbled_deepslate
setblock 70 214 559 minecraft:calcite
setblock 71 214 558 minecraft:calcite
fill 71 214 559 71 217 559 minecraft:cobbled_deepslate
setblock 71 214 598 minecraft:calcite
fill 72 214 558 72 217 558 minecraft:cobbled_deepslate
setblock 72 214 597 minecraft:calcite
fill 72 214 598 72 217 598 minecraft:cobbled_deepslate
setblock 73 214 596 minecraft:calcite
fill 73 214 597 73 217 597 minecraft:cobbled_deepslate
fill 74 214 596 74 215 596 minecraft:cobbled_deepslate
setblock 76 214 558 minecraft:calcite
setblock 76 214 598 minecraft:calcite
fill 77 214 558 77 216 558 minecraft:cobbled_deepslate
setblock 77 214 597 minecraft:calcite
fill 77 214 598 80 214 598 minecraft:cobbled_deepslate
fill 78 214 597 81 214 597 minecraft:cobbled_deepslate
fill 80 214 583 81 214 583 minecraft:light_blue_stained_glass
setblock 81 214 598 minecraft:calcite
fill 82 214 582 83 214 582 minecraft:light_blue_stained_glass
setblock 82 214 584 minecraft:light_blue_stained_glass
setblock 82 214 597 minecraft:calcite
fill 82 214 598 82 217 598 minecraft:cobbled_deepslate
setblock 83 214 596 minecraft:calcite
fill 83 214 597 83 217 597 minecraft:cobbled_deepslate
fill 84 214 558 85 214 558 minecraft:cobbled_deepslate
setblock 84 214 585 minecraft:light_blue_stained_glass
fill 84 214 596 84 217 596 minecraft:cobbled_deepslate
setblock 85 214 594 minecraft:calcite
setblock 85 214 595 minecraft:cobbled_deepslate
setblock 86 214 558 minecraft:calcite
fill 86 214 581 87 215 581 minecraft:light_blue_stained_glass
setblock 86 214 589 minecraft:cobbled_deepslate
setblock 86 214 593 minecraft:calcite
fill 86 214 594 86 217 594 minecraft:cobbled_deepslate
setblock 86 214 598 minecraft:calcite
fill 87 214 558 87 217 558 minecraft:cobbled_deepslate
setblock 87 214 571 minecraft:cobbled_deepslate
setblock 87 214 572 minecraft:calcite
fill 87 214 573 87 217 573 minecraft:cobbled_deepslate
setblock 87 214 576 minecraft:cobbled_deepslate
setblock 87 214 577 minecraft:calcite
fill 87 214 578 87 217 578 minecraft:cobbled_deepslate
setblock 87 214 587 minecraft:calcite
fill 87 214 588 87 217 588 minecraft:cobbled_deepslate
setblock 87 214 592 minecraft:calcite
fill 87 214 593 87 217 593 minecraft:cobbled_deepslate
setblock 87 214 597 minecraft:calcite
fill 87 214 598 87 217 598 minecraft:cobbled_deepslate
setblock 88 214 566 minecraft:calcite
fill 88 214 567 88 215 567 minecraft:cobbled_deepslate
setblock 88 214 571 minecraft:calcite
fill 88 214 572 88 217 572 minecraft:cobbled_deepslate
setblock 88 214 576 minecraft:calcite
fill 88 214 577 88 217 577 minecraft:cobbled_deepslate
setblock 88 214 580 minecraft:cobbled_deepslate
setblock 88 214 581 minecraft:calcite
fill 88 214 582 88 217 582 minecraft:cobbled_deepslate
setblock 88 214 586 minecraft:calcite
fill 88 214 587 88 217 587 minecraft:cobbled_deepslate
setblock 88 214 591 minecraft:calcite
fill 88 214 592 88 217 592 minecraft:cobbled_deepslate
setblock 88 214 596 minecraft:calcite
fill 88 214 597 88 217 597 minecraft:cobbled_deepslate
setblock 48 215 565 minecraft:calcite
fill 48 215 566 48 216 566 minecraft:cobbled_deepslate
setblock 48 215 570 minecraft:calcite
fill 48 215 571 48 218 571 minecraft:cobbled_deepslate
setblock 48 215 575 minecraft:calcite
fill 48 215 576 48 218 576 minecraft:cobbled_deepslate
setblock 48 215 580 minecraft:calcite
fill 48 215 581 48 218 581 minecraft:cobbled_deepslate
setblock 48 215 585 minecraft:calcite
fill 48 215 586 48 218 586 minecraft:cobbled_deepslate
setblock 48 215 590 minecraft:calcite
fill 48 215 591 48 218 591 minecraft:cobbled_deepslate
setblock 48 215 595 minecraft:calcite
fill 48 215 596 48 218 596 minecraft:cobbled_deepslate
setblock 49 215 569 minecraft:calcite
fill 49 215 570 49 218 570 minecraft:cobbled_deepslate
setblock 49 215 574 minecraft:calcite
fill 49 215 575 49 218 575 minecraft:cobbled_deepslate
setblock 49 215 579 minecraft:calcite
fill 49 215 580 49 218 580 minecraft:cobbled_deepslate
setblock 49 215 584 minecraft:calcite
fill 49 215 585 49 216 585 minecraft:cobbled_deepslate
setblock 49 215 589 minecraft:calcite
fill 49 215 590 49 217 590 minecraft:cobbled_deepslate
setblock 49 215 594 minecraft:calcite
fill 49 215 595 49 218 595 minecraft:cobbled_deepslate
setblock 50 215 558 minecraft:calcite
setblock 50 215 569 minecraft:cobbled_deepslate
setblock 50 215 573 minecraft:calcite
fill 50 215 574 50 218 574 minecraft:cobbled_deepslate
setblock 50 215 578 minecraft:calcite
fill 50 215 579 50 218 579 minecraft:cobbled_deepslate
setblock 50 215 593 minecraft:calcite
setblock 50 215 594 minecraft:cobbled_deepslate
setblock 50 215 598 minecraft:calcite
setblock 51 215 572 minecraft:calcite
setblock 51 215 573 minecraft:cobbled_deepslate
setblock 51 215 597 minecraft:calcite
fill 51 215 598 51 218 598 minecraft:cobbled_deepslate
setblock 52 215 597 minecraft:cobbled_deepslate
fill 63 215 558 63 216 558 minecraft:cobbled_deepslate
fill 63 215 598 64 215 598 minecraft:cobbled_deepslate
setblock 65 215 558 minecraft:calcite
setblock 65 215 597 minecraft:cobbled_deepslate
setblock 65 215 598 minecraft:calcite
fill 66 215 558 66 218 558 minecraft:cobbled_deepslate
setblock 66 215 597 minecraft:calcite
fill 66 215 598 66 218 598 minecraft:cobbled_deepslate
fill 67 215 597 67 218 597 minecraft:cobbled_deepslate
fill 68 215 596 68 218 596 minecraft:cobbled_deepslate
setblock 69 215 559 minecraft:calcite
setblock 70 215 558 minecraft:calcite
fill 70 215 559 70 218 559 minecraft:cobbled_deepslate
setblock 70 215 598 minecraft:calcite
fill 71 215 558 71 218 558 minecraft:cobbled_deepslate
setblock 71 215 597 minecraft:calcite
fill 71 215 598 71 218 598 minecraft:cobbled_deepslate
setblock 72 215 596 minecraft:calcite
fill 72 215 597 72 218 597 minecraft:cobbled_deepslate
setblock 73 215 596 minecraft:cobbled_deepslate
setblock 75 215 558 minecraft:calcite
setblock 75 215 598 minecraft:calcite
fill 76 215 558 76 218 558 minecraft:cobbled_deepslate
setblock 76 215 597 minecraft:calcite
fill 76 215 598 79 215 598 minecraft:cobbled_deepslate
fill 77 215 597 80 215 597 minecraft:cobbled_deepslate
setblock 80 215 598 minecraft:calcite
setblock 81 215 597 minecraft:calcite
fill 81 215 598 81 218 598 minecraft:cobbled_deepslate
fill 82 215 597 82 218 597 minecraft:cobbled_deepslate
setblock 83 215 582 minecraft:light_blue_stained_glass
fill 83 215 596 83 218 596 minecraft:cobbled_deepslate
setblock 84 215 558 minecraft:cobbled_deepslate
setblock 85 215 558 minecraft:calcite
setblock 85 215 598 minecraft:calcite
fill 86 215 558 86 218 558 minecraft:cobbled_deepslate
setblock 86 215 592 minecraft:calcite
fill 86 215 593 86 218 593 minecraft:cobbled_deepslate
setblock 86 215 597 minecraft:calcite
fill 86 215 598 86 218 598 minecraft:cobbled_deepslate
setblock 87 215 571 minecraft:calcite
fill 87 215 572 87 218 572 minecraft:cobbled_deepslate
setblock 87 215 575 minecraft:cobbled_deepslate
setblock 87 215 576 minecraft:calcite
fill 87 215 577 87 218 577 minecraft:cobbled_deepslate
fill 87 215 579 87 216 579 minecraft:cobbled_deepslate
setblock 87 215 586 minecraft:calcite
fill 87 215 587 87 218 587 minecraft:cobbled_deepslate
setblock 87 215 591 minecraft:calcite
fill 87 215 592 87 218 592 minecraft:cobbled_deepslate
setblock 87 215 596 minecraft:calcite
fill 87 215 597 87 218 597 minecraft:cobbled_deepslate
setblock 88 215 570 minecraft:calcite
fill 88 215 571 88 218 571 minecraft:cobbled_deepslate
setblock 88 215 575 minecraft:calcite
fill 88 215 576 88 218 576 minecraft:cobbled_deepslate
setblock 88 215 580 minecraft:calcite
fill 88 215 581 88 218 581 minecraft:cobbled_deepslate
setblock 88 215 585 minecraft:calcite
fill 88 215 586 88 218 586 minecraft:cobbled_deepslate
setblock 88 215 590 minecraft:calcite
fill 88 215 591 88 218 591 minecraft:cobbled_deepslate
setblock 88 215 595 minecraft:calcite
fill 88 215 596 88 218 596 minecraft:cobbled_deepslate
setblock 48 216 569 minecraft:calcite
fill 48 216 570 48 219 570 minecraft:cobbled_deepslate
setblock 48 216 574 minecraft:calcite
fill 48 216 575 48 219 575 minecraft:cobbled_deepslate
setblock 48 216 579 minecraft:calcite
fill 48 216 580 48 219 580 minecraft:cobbled_deepslate
setblock 48 216 584 minecraft:calcite
fill 48 216 585 48 219 585 minecraft:cobbled_deepslate
setblock 48 216 589 minecraft:calcite
fill 48 216 590 48 219 590 minecraft:cobbled_deepslate
setblock 48 216 594 minecraft:calcite
fill 48 216 595 48 219 595 minecraft:cobbled_deepslate
setblock 49 216 558 minecraft:calcite
setblock 49 216 568 minecraft:calcite
fill 49 216 569 49 217 569 minecraft:cobbled_deepslate
setblock 49 216 573 minecraft:calcite
fill 49 216 574 49 219 574 minecraft:cobbled_deepslate
setblock 49 216 578 minecraft:calcite
fill 49 216 579 49 219 579 minecraft:cobbled_deepslate
setblock 49 216 583 minecraft:calcite
fill 49 216 584 49 217 584 minecraft:cobbled_deepslate
setblock 49 216 588 minecraft:calcite
fill 49 216 589 49 217 589 minecraft:cobbled_deepslate
setblock 49 216 593 minecraft:calcite
fill 49 216 594 49 218 594 minecraft:cobbled_deepslate
setblock 49 216 598 minecraft:calcite
fill 50 216 558 50 219 558 minecraft:cobbled_deepslate
setblock 50 216 572 minecraft:calcite
fill 50 216 573 50 219 573 minecraft:cobbled_deepslate
setblock 50 216 577 minecraft:calcite
fill 50 216 578 50 219 578 minecraft:cobbled_deepslate
setblock 50 216 597 minecraft:calcite
fill 50 216 598 50 219 598 minecraft:cobbled_deepslate
setblock 51 216 597 minecraft:cobbled_deepslate
fill 62 216 558 62 217 558 minecraft:cobbled_deepslate
setblock 63 216 598 minecraft:cobbled_deepslate
setblock 64 216 558 minecraft:calcite
setblock 64 216 598 minecraft:calcite
fill 65 216 558 65 218 559 minecraft:cobbled_deepslate
setblock 65 216 597 minecraft:calcite
fill 65 216 598 65 219 598 minecraft:cobbled_deepslate
fill 66 216 597 66 219 597 minecraft:cobbled_deepslate
setblock 68 216 559 minecraft:calcite
setblock 69 216 558 minecraft:calcite
fill 69 216 559 69 219 559 minecraft:cobbled_deepslate
setblock 69 216 598 minecraft:calcite
fill 70 216 558 70 219 558 minecraft:cobbled_deepslate
setblock 70 216 597 minecraft:calcite
fill 70 216 598 70 219 598 minecraft:cobbled_deepslate
setblock 71 216 596 minecraft:calcite
fill 71 216 597 71 219 597 minecraft:cobbled_deepslate
setblock 72 216 596 minecraft:cobbled_deepslate
setblock 73 216 559 minecraft:calcite
setblock 74 216 558 minecraft:calcite
setblock 74 216 598 minecraft:calcite
fill 75 216 558 75 219 558 minecraft:cobbled_deepslate
setblock 75 216 597 minecraft:calcite
fill 75 216 598 78 216 598 minecraft:cobbled_deepslate
fill 76 216 597 79 216 597 minecraft:cobbled_deepslate
setblock 79 216 598 minecraft:calcite
setblock 80 216 597 minecraft:calcite
fill 80 216 598 80 219 598 minecraft:cobbled_deepslate
fill 81 216 597 81 219 597 minecraft:cobbled_deepslate
setblock 83 216 558 minecraft:cobbled_deepslate
setblock 84 216 558 minecraft:calcite
setblock 84 216 598 minecraft:calcite
fill 85 216 558 85 219 558 minecraft:cobbled_deepslate
setblock 85 216 582 minecraft:light_blue_stained_glass
setblock 85 216 584 minecraft:light_blue_stained_glass
setblock 85 216 597 minecraft:calcite
fill 85 216 598 85 219 598 minecraft:cobbled_deepslate
setblock 86 216 591 minecraft:calcite
fill 86 216 592 86 219 592 minecraft:cobbled_deepslate
setblock 86 216 596 minecraft:calcite
fill 86 216 597 86 219 597 minecraft:cobbled_deepslate
setblock 87 216 571 minecraft:cobbled_deepslate
setblock 87 216 575 minecraft:calcite
fill 87 216 576 87 219 576 minecraft:cobbled_deepslate
setblock 87 216 580 minecraft:calcite
fill 87 216 581 87 219 581 minecraft:cobbled_deepslate
fill 87 216 586 87 219 586 minecraft:cobbled_deepslate
setblock 87 216 590 minecraft:calcite
fill 87 216 591 87 219 591 minecraft:cobbled_deepslate
setblock 87 216 595 minecraft:calcite
fill 87 216 596 87 219 596 minecraft:cobbled_deepslate
setblock 88 216 559 minecraft:calcite
setblock 88 216 569 minecraft:calcite
fill 88 216 570 88 219 570 minecraft:cobbled_deepslate
setblock 88 216 574 minecraft:calcite
fill 88 216 575 88 219 575 minecraft:cobbled_deepslate
setblock 88 216 579 minecraft:calcite
fill 88 216 580 88 219 580 minecraft:cobbled_deepslate
setblock 88 216 584 minecraft:calcite
fill 88 216 585 88 219 585 minecraft:cobbled_deepslate
setblock 88 216 589 minecraft:calcite
fill 88 216 590 88 219 590 minecraft:cobbled_deepslate
setblock 88 216 594 minecraft:calcite
fill 88 216 595 88 219 595 minecraft:cobbled_deepslate
setblock 48 217 558 minecraft:calcite
setblock 48 217 568 minecraft:calcite
fill 48 217 569 48 220 569 minecraft:cobbled_deepslate
setblock 48 217 573 minecraft:calcite
fill 48 217 574 48 220 574 minecraft:cobbled_deepslate
setblock 48 217 578 minecraft:calcite
fill 48 217 579 48 220 579 minecraft:cobbled_deepslate
setblock 48 217 583 minecraft:calcite
fill 48 217 584 48 220 584 minecraft:cobbled_deepslate
setblock 48 217 588 minecraft:calcite
fill 48 217 589 48 220 589 minecraft:cobbled_deepslate
setblock 48 217 593 minecraft:calcite
fill 48 217 594 48 220 594 minecraft:cobbled_deepslate
setblock 48 217 598 minecraft:calcite
fill 49 217 558 49 220 558 minecraft:cobbled_deepslate
setblock 49 217 572 minecraft:calcite
fill 49 217 573 49 220 573 minecraft:cobbled_deepslate
setblock 49 217 577 minecraft:calcite
fill 49 217 578 49 220 578 minecraft:cobbled_deepslate
setblock 49 217 582 minecraft:calcite
fill 49 217 583 49 220 583 minecraft:cobbled_deepslate
setblock 49 217 592 minecraft:calcite
fill 49 217 593 49 218 593 minecraft:cobbled_deepslate
setblock 49 217 597 minecraft:calcite
fill 49 217 598 49 220 598 minecraft:cobbled_deepslate
setblock 50 217 571 minecraft:calcite
fill 50 217 572 50 218 572 minecraft:cobbled_deepslate
setblock 50 217 576 minecraft:calcite
fill 50 217 577 50 220 577 minecraft:cobbled_deepslate
setblock 50 217 597 minecraft:cobbled_deepslate
setblock 62 217 598 minecraft:cobbled_deepslate
setblock 63 217 558 minecraft:calcite
setblock 63 217 598 minecraft:calcite
fill 64 217 558 64 219 559 minecraft:cobbled_deepslate
setblock 64 217 597 minecraft:calcite
fill 64 217 598 64 220 598 minecraft:cobbled_deepslate
fill 65 217 597 65 220 597 minecraft:cobbled_deepslate
setblock 67 217 559 minecraft:calcite
setblock 68 217 558 minecraft:calcite
fill 68 217 559 68 220 559 minecraft:cobbled_deepslate
setblock 68 217 598 minecraft:calcite
fill 69 217 558 69 220 558 minecraft:cobbled_deepslate
setblock 69 217 597 minecraft:calcite
fill 69 217 598 69 220 598 minecraft:cobbled_deepslate
setblock 70 217 596 minecraft:calcite
fill 70 217 597 70 220 597 minecraft:cobbled_deepslate
setblock 71 217 596 minecraft:cobbled_deepslate
setblock 72 217 559 minecraft:calcite
setblock 73 217 558 minecraft:calcite
setblock 73 217 598 minecraft:calcite
fill 74 217 558 74 220 558 minecraft:cobbled_deepslate
setblock 74 217 597 minecraft:calcite
fill 74 217 598 77 217 598 minecraft:cobbled_deepslate
fill 75 217 597 78 217 597 minecraft:cobbled_deepslate
setblock 78 217 598 minecraft:calcite
setblock 79 217 597 minecraft:calcite
fill 79 217 598 79 220 598 minecraft:cobbled_deepslate
fill 80 217 597 80 220 597 minecraft:cobbled_deepslate
setblock 82 217 558 minecraft:cobbled_deepslate
setblock 83 217 558 minecraft:calcite
setblock 83 217 598 minecraft:calcite
fill 84 217 558 84 220 558 minecraft:cobbled_deepslate
setblock 84 217 597 minecraft:calcite
fill 84 217 598 84 220 598 minecraft:cobbled_deepslate
setblock 85 217 596 minecraft:calcite
fill 85 217 597 85 220 597 minecraft:cobbled_deepslate
setblock 86 217 591 minecraft:cobbled_deepslate
setblock 86 217 595 minecraft:calcite
fill 86 217 596 86 220 596 minecraft:cobbled_deepslate
setblock 87 217 574 minecraft:calcite
fill 87 217 575 87 220 575 minecraft:cobbled_deepslate
setblock 87 217 579 minecraft:calcite
fill 87 217 580 87 220 580 minecraft:cobbled_deepslate
fill 87 217 582 87 218 582 minecraft:cobbled_deepslate
setblock 87 217 589 minecraft:calcite
fill 87 217 590 87 220 590 minecraft:cobbled_deepslate
setblock 87 217 594 minecraft:calcite
fill 87 217 595 87 220 595 minecraft:cobbled_deepslate
setblock 88 217 558 minecraft:calcite
fill 88 217 559 88 220 559 minecraft:cobbled_deepslate
setblock 88 217 569 minecraft:cobbled_deepslate
setblock 88 217 573 minecraft:calcite
fill 88 217 574 88 220 574 minecraft:cobbled_deepslate
setblock 88 217 578 minecraft:calcite
fill 88 217 579 88 220 579 minecraft:cobbled_deepslate
setblock 88 217 583 minecraft:calcite
fill 88 217 584 88 220 584 minecraft:cobbled_deepslate
setblock 88 217 588 minecraft:calcite
fill 88 217 589 88 220 589 minecraft:cobbled_deepslate
setblock 88 217 593 minecraft:calcite
fill 88 217 594 88 220 594 minecraft:cobbled_deepslate
setblock 88 217 598 minecraft:calcite
fill 48 218 558 48 220 559 minecraft:cobbled_deepslate
setblock 48 218 567 minecraft:calcite
fill 48 218 568 48 221 568 minecraft:cobbled_deepslate
setblock 48 218 572 minecraft:calcite
fill 48 218 573 48 221 573 minecraft:cobbled_deepslate
setblock 48 218 577 minecraft:calcite
fill 48 218 578 48 221 578 minecraft:cobbled_deepslate
setblock 48 218 582 minecraft:calcite
fill 48 218 583 48 221 583 minecraft:cobbled_deepslate
setblock 48 218 587 minecraft:calcite
fill 48 218 588 48 221 588 minecraft:cobbled_deepslate
setblock 48 218 592 minecraft:calcite
fill 48 218 593 48 221 593 minecraft:cobbled_deepslate
setblock 48 218 597 minecraft:calcite
fill 48 218 598 48 221 598 minecraft:cobbled_deepslate
setblock 49 218 571 minecraft:calcite
fill 49 218 572 49 221 572 minecraft:cobbled_deepslate
setblock 49 218 576 minecraft:calcite
fill 49 218 577 49 221 577 minecraft:cobbled_deepslate
setblock 49 218 581 minecraft:calcite
fill 49 218 582 49 221 582 minecraft:cobbled_deepslate
fill 49 218 584 49 220 584 minecraft:calcite
setblock 49 218 592 minecraft:cobbled_deepslate
setblock 49 218 596 minecraft:calcite
fill 49 218 597 49 219 597 minecraft:cobbled_deepslate
setblock 50 218 575 minecraft:calcite
fill 50 218 576 50 221 576 minecraft:cobbled_deepslate
setblock 50 218 580 minecraft:calcite
setblock 52 218 598 minecraft:calcite
setblock 61 218 558 minecraft:cobbled_deepslate
setblock 62 218 558 minecraft:calcite
setblock 62 218 598 minecraft:calcite
fill 63 218 558 63 220 559 minecraft:cobbled_deepslate
fill 63 218 598 63 221 598 minecraft:cobbled_deepslate
fill 64 218 597 64 221 597 minecraft:cobbled_deepslate
setblock 66 218 559 minecraft:calcite
setblock 67 218 558 minecraft:calcite
fill 67 218 559 67 221 559 minecraft:cobbled_deepslate
setblock 67 218 598 minecraft:calcite
fill 68 218 558 68 221 558 minecraft:cobbled_deepslate
setblock 68 218 597 minecraft:calcite
fill 68 218 598 68 221 598 minecraft:cobbled_deepslate
setblock 69 218 596 minecraft:calcite
fill 69 218 597 69 221 597 minecraft:cobbled_deepslate
setblock 70 218 596 minecraft:cobbled_deepslate
setblock 71 218 559 minecraft:calcite
setblock 72 218 558 minecraft:calcite
fill 72 218 559 72 221 559 minecraft:cobbled_deepslate
setblock 72 218 598 minecraft:calcite
fill 73 218 558 73 221 558 minecraft:cobbled_deepslate
setblock 73 218 597 minecraft:calcite
fill 73 218 598 76 218 598 minecraft:cobbled_deepslate
fill 74 218 597 77 218 597 minecraft:cobbled_deepslate
setblock 77 218 558 minecraft:calcite
setblock 77 218 598 minecraft:calcite
setblock 78 218 597 minecraft:calcite
fill 78 218 598 78 221 598 minecraft:cobbled_deepslate
fill 79 218 597 79 221 597 minecraft:cobbled_deepslate
setblock 81 218 558 minecraft:cobbled_deepslate
setblock 82 218 558 minecraft:calcite
fill 82 218 596 82 219 596 minecraft:cobbled_deepslate
setblock 82 218 598 minecraft:calcite
fill 83 218 558 83 221 558 minecraft:cobbled_deepslate
setblock 83 218 597 minecraft:calcite
fill 83 218 598 83 221 598 minecraft:cobbled_deepslate
setblock 84 218 596 minecraft:calcite
fill 84 218 597 84 221 597 minecraft:cobbled_deepslate
fill 85 218 596 85 221 596 minecraft:cobbled_deepslate
setblock 86 218 594 minecraft:calcite
fill 86 218 595 86 221 595 minecraft:cobbled_deepslate
setblock 87 218 558 minecraft:calcite
setblock 87 218 573 minecraft:calcite
fill 87 218 574 87 221 574 minecraft:cobbled_deepslate
setblock 87 218 578 minecraft:calcite
fill 87 218 579 87 221 579 minecraft:cobbled_deepslate
setblock 87 218 583 minecraft:calcite
fill 87 218 584 87 221 584 minecraft:cobbled_deepslate
setblock 87 218 588 minecraft:calcite
fill 87 218 589 87 221 589 minecraft:cobbled_deepslate
setblock 87 218 593 minecraft:calcite
fill 87 218 594 87 221 594 minecraft:cobbled_deepslate
setblock 87 218 598 minecraft:calcite
fill 88 218 558 88 221 558 minecraft:cobbled_deepslate
setblock 88 218 572 minecraft:calcite
fill 88 218 573 88 221 573 minecraft:cobbled_deepslate
setblock 88 218 577 minecraft:calcite
fill 88 218 578 88 221 578 minecraft:cobbled_deepslate
setblock 88 218 582 minecraft:calcite
fill 88 218 583 88 221 583 minecraft:cobbled_deepslate
setblock 88 218 587 minecraft:calcite
fill 88 218 588 88 221 588 minecraft:cobbled_deepslate
setblock 88 218 592 minecraft:calcite
fill 88 218 593 88 221 593 minecraft:cobbled_deepslate
setblock 88 218 597 minecraft:calcite
fill 88 218 598 88 221 598 minecraft:cobbled_deepslate
setblock 48 219 560 minecraft:cobbled_deepslate
fill 48 219 567 48 222 567 minecraft:cobbled_deepslate
setblock 48 219 571 minecraft:calcite
fill 48 219 572 48 222 572 minecraft:cobbled_deepslate
setblock 48 219 576 minecraft:calcite
fill 48 219 577 48 222 577 minecraft:cobbled_deepslate
setblock 48 219 581 minecraft:calcite
fill 48 219 582 48 222 582 minecraft:cobbled_deepslate
setblock 48 219 586 minecraft:calcite
fill 48 219 587 48 222 587 minecraft:cobbled_deepslate
setblock 48 219 591 minecraft:calcite
fill 48 219 592 48 222 592 minecraft:cobbled_deepslate
setblock 48 219 596 minecraft:calcite
fill 48 219 597 48 222 597 minecraft:cobbled_deepslate
setblock 49 219 570 minecraft:calcite
fill 49 219 571 49 222 571 minecraft:cobbled_deepslate
setblock 49 219 575 minecraft:calcite
fill 49 219 576 49 222 576 minecraft:cobbled_deepslate
setblock 49 219 580 minecraft:calcite
fill 49 219 581 49 222 581 minecraft:cobbled_deepslate
setblock 49 219 595 minecraft:calcite
setblock 49 219 596 minecraft:cobbled_deepslate
setblock 50 219 574 minecraft:calcite
fill 50 219 575 50 222 575 minecraft:cobbled_deepslate
setblock 50 219 579 minecraft:calcite
fill 50 219 580 50 222 580 minecraft:cobbled_deepslate
setblock 51 219 598 minecraft:calcite
fill 59 219 558 60 219 558 minecraft:cobbled_deepslate
setblock 61 219 558 minecraft:calcite
setblock 61 219 598 minecraft:calcite
fill 62 219 558 62 221 559 minecraft:cobbled_deepslate
fill 62 219 598 62 222 598 minecraft:cobbled_deepslate
fill 63 219 597 63 222 597 minecraft:cobbled_deepslate
setblock 65 219 558 minecraft:cobbled_deepslate
setblock 65 219 559 minecraft:calcite
setblock 66 219 558 minecraft:calcite
fill 66 219 559 66 221 560 minecraft:cobbled_deepslate
setblock 66 219 598 minecraft:calcite
fill 67 219 558 67 222 558 minecraft:cobbled_deepslate
fill 67 219 560 68 219 560 minecraft:cobbled_deepslate
setblock 67 219 596 minecraft:cobbled_deepslate
setblock 67 219 597 minecraft:calcite
fill 67 219 598 67 222 598 minecraft:cobbled_deepslate
setblock 68 219 596 minecraft:calcite
fill 68 219 597 68 222 597 minecraft:cobbled_deepslate
fill 69 219 596 69 220 596 minecraft:cobbled_deepslate
setblock 70 219 559 minecraft:calcite
setblock 71 219 558 minecraft:calcite
fill 71 219 559 71 222 559 minecraft:cobbled_deepslate
setblock 71 219 598 minecraft:calcite
fill 72 219 558 72 222 558 minecraft:cobbled_deepslate
setblock 72 219 597 minecraft:calcite
fill 72 219 598 75 219 598 minecraft:cobbled_deepslate
fill 73 219 597 76 219 597 minecraft:cobbled_deepslate
setblock 76 219 558 minecraft:calcite
setblock 76 219 598 minecraft:calcite
fill 77 219 558 80 219 558 minecraft:cobbled_deepslate
setblock 77 219 597 minecraft:calcite
fill 77 219 598 77 222 598 minecraft:cobbled_deepslate
fill 78 219 597 78 222 597 minecraft:cobbled_deepslate
setblock 81 219 558 minecraft:calcite
setblock 81 219 598 minecraft:calcite
fill 82 219 558 82 222 558 minecraft:cobbled_deepslate
setblock 82 219 597 minecraft:calcite
fill 82 219 598 82 222 598 minecraft:cobbled_deepslate
setblock 83 219 596 minecraft:calcite
fill 83 219 597 83 222 597 minecraft:cobbled_deepslate
fill 84 219 596 84 222 596 minecraft:cobbled_deepslate
setblock 86 219 558 minecraft:calcite
setblock 86 219 577 minecraft:cobbled_deepslate
setblock 86 219 578 minecraft:calcite
setblock 86 219 593 minecraft:calcite
fill 86 219 594 86 222 594 minecraft:cobbled_deepslate
setblock 86 219 598 minecraft:calcite
fill 87 219 558 87 222 558 minecraft:cobbled_deepslate
fill 87 219 573 87 222 573 minecraft:cobbled_deepslate
setblock 87 219 577 minecraft:calcite
fill 87 219 578 87 222 578 minecraft:cobbled_deepslate
setblock 87 219 582 minecraft:calcite
fill 87 219 583 87 222 583 minecraft:cobbled_deepslate
fill 87 219 585 87 220 585 minecraft:cobbled_deepslate
setblock 87 219 587 minecraft:calcite
fill 87 219 588 87 222 588 minecraft:cobbled_deepslate
setblock 87 219 592 minecraft:calcite
fill 87 219 593 87 222 593 minecraft:cobbled_deepslate
setblock 87 219 597 minecraft:calcite
fill 87 219 598 87 222 598 minecraft:cobbled_deepslate
setblock 88 219 560 minecraft:cobbled_deepslate
setblock 88 219 571 minecraft:calcite
fill 88 219 572 88 222 572 minecraft:cobbled_deepslate
setblock 88 219 576 minecraft:calcite
fill 88 219 577 88 222 577 minecraft:cobbled_deepslate
setblock 88 219 581 minecraft:calcite
fill 88 219 582 88 222 582 minecraft:cobbled_deepslate
setblock 88 219 586 minecraft:calcite
fill 88 219 587 88 222 587 minecraft:cobbled_deepslate
setblock 88 219 591 minecraft:calcite
fill 88 219 592 88 222 592 minecraft:cobbled_deepslate
setblock 88 219 596 minecraft:calcite
fill 88 219 597 88 222 597 minecraft:cobbled_deepslate
setblock 48 220 560 minecraft:calcite
fill 48 220 561 48 223 561 minecraft:cobbled_deepslate
setblock 48 220 570 minecraft:calcite
fill 48 220 571 48 223 571 minecraft:cobbled_deepslate
setblock 48 220 575 minecraft:calcite
fill 48 220 576 48 223 576 minecraft:cobbled_deepslate
setblock 48 220 580 minecraft:calcite
fill 48 220 581 48 223 581 minecraft:cobbled_deepslate
setblock 48 220 585 minecraft:calcite
fill 48 220 586 48 223 586 minecraft:cobbled_deepslate
setblock 48 220 590 minecraft:calcite
fill 48 220 591 48 222 591 minecraft:cobbled_deepslate
setblock 48 220 595 minecraft:calcite
fill 48 220 596 48 223 596 minecraft:cobbled_deepslate
setblock 49 220 574 minecraft:calcite
fill 49 220 575 49 223 575 minecraft:cobbled_deepslate
setblock 49 220 579 minecraft:calcite
fill 49 220 580 49 223 580 minecraft:cobbled_deepslate
setblock 50 220 558 minecraft:calcite
setblock 50 220 560 minecraft:light[level=14]
setblock 50 220 568 minecraft:light[level=14]
setblock 50 220 573 minecraft:calcite
fill 50 220 574 50 222 574 minecraft:cobbled_deepslate
setblock 50 220 578 minecraft:calcite
fill 50 220 579 50 223 579 minecraft:cobbled_deepslate
setblock 50 220 592 minecraft:light[level=14]
setblock 50 220 598 minecraft:calcite
fill 51 220 558 51 223 558 minecraft:cobbled_deepslate
fill 51 220 598 51 223 598 minecraft:cobbled_deepslate
fill 58 220 558 59 220 558 minecraft:cobbled_deepslate
setblock 58 220 560 minecraft:light[level=14]
setblock 58 220 568 minecraft:light[level=14]
setblock 58 220 576 minecraft:light[level=14]
setblock 58 220 584 minecraft:light[level=14]
setblock 58 220 592 minecraft:light[level=14]
setblock 60 220 558 minecraft:calcite
setblock 60 220 598 minecraft:calcite
fill 61 220 558 61 222 559 minecraft:cobbled_deepslate
fill 61 220 598 61 223 598 minecraft:cobbled_deepslate
setblock 64 220 558 minecraft:cobbled_deepslate
setblock 64 220 559 minecraft:calcite
fill 64 220 560 65 222 560 minecraft:cobbled_deepslate
setblock 65 220 558 minecraft:calcite
fill 65 220 559 65 223 559 minecraft:cobbled_deepslate
setblock 65 220 598 minecraft:calcite
fill 66 220 558 66 223 558 minecraft:cobbled_deepslate
setblock 66 220 568 minecraft:light[level=14]
setblock 66 220 576 minecraft:light[level=14]
setblock 66 220 584 minecraft:light[level=14]
setblock 66 220 592 minecraft:light[level=14]
setblock 66 220 597 minecraft:calcite
fill 66 220 598 66 223 598 minecraft:cobbled_deepslate
setblock 67 220 560 minecraft:cobbled_deepslate
setblock 67 220 596 minecraft:calcite
fill 67 220 597 67 223 597 minecraft:cobbled_deepslate
setblock 68 220 560 minecraft:calcite
fill 68 220 596 68 223 596 minecraft:cobbled_deepslate
setblock 69 220 559 minecraft:calcite
fill 69 220 560 69 223 560 minecraft:cobbled_deepslate
setblock 70 220 558 minecraft:calcite
fill 70 220 559 70 223 559 minecraft:cobbled_deepslate
setblock 70 220 598 minecraft:calcite
fill 71 220 558 71 223 558 minecraft:cobbled_deepslate
setblock 71 220 597 minecraft:calcite
fill 71 220 598 74 220 598 minecraft:cobbled_deepslate
fill 72 220 597 75 220 597 minecraft:cobbled_deepslate
setblock 74 220 560 minecraft:light[level=14]
setblock 74 220 568 minecraft:light[level=14]
setblock 74 220 576 minecraft:light[level=14]
setblock 74 220 584 minecraft:light[level=14]
setblock 74 220 592 minecraft:light[level=14]
setblock 75 220 558 minecraft:calcite
setblock 75 220 598 minecraft:calcite
fill 76 220 558 79 220 558 minecraft:cobbled_deepslate
setblock 76 220 597 minecraft:calcite
fill 76 220 598 76 223 598 minecraft:cobbled_deepslate
fill 77 220 597 77 223 597 minecraft:cobbled_deepslate
setblock 80 220 558 minecraft:calcite
setblock 80 220 598 minecraft:calcite
fill 81 220 558 81 223 558 minecraft:cobbled_deepslate
setblock 81 220 597 minecraft:calcite
fill 81 220 598 81 223 598 minecraft:cobbled_deepslate
setblock 82 220 560 minecraft:light[level=14]
setblock 82 220 568 minecraft:light[level=14]
setblock 82 220 576 minecraft:light[level=14]
setblock 82 220 584 minecraft:light[level=14]
setblock 82 220 592 minecraft:light[level=14]
setblock 82 220 596 minecraft:calcite
fill 82 220 597 82 223 597 minecraft:cobbled_deepslate
fill 83 220 596 83 223 596 minecraft:cobbled_deepslate
setblock 85 220 558 minecraft:calcite
setblock 85 220 598 minecraft:calcite
fill 86 220 558 86 223 558 minecraft:cobbled_deepslate
setblock 86 220 576 minecraft:cobbled_deepslate
setblock 86 220 577 minecraft:calcite
fill 86 220 578 86 220 581 minecraft:cobbled_deepslate
fill 86 220 593 86 223 593 minecraft:cobbled_deepslate
setblock 86 220 597 minecraft:calcite
fill 86 220 598 86 223 598 minecraft:cobbled_deepslate
setblock 87 220 576 minecraft:calcite
fill 87 220 577 87 223 577 minecraft:cobbled_deepslate
setblock 87 220 581 minecraft:calcite
fill 87 220 582 87 223 582 minecraft:cobbled_deepslate
setblock 87 220 586 minecraft:calcite
fill 87 220 587 87 223 587 minecraft:cobbled_deepslate
setblock 87 220 591 minecraft:calcite
fill 87 220 592 87 223 592 minecraft:cobbled_deepslate
setblock 87 220 596 minecraft:calcite
fill 87 220 597 87 223 597 minecraft:cobbled_deepslate
setblock 88 220 560 minecraft:calcite
setblock 88 220 570 minecraft:calcite
fill 88 220 571 88 223 571 minecraft:cobbled_deepslate
setblock 88 220 575 minecraft:calcite
fill 88 220 576 88 223 576 minecraft:cobbled_deepslate
setblock 88 220 580 minecraft:calcite
fill 88 220 581 88 223 581 minecraft:cobbled_deepslate
setblock 88 220 585 minecraft:calcite
fill 88 220 586 88 223 586 minecraft:cobbled_deepslate
setblock 88 220 590 minecraft:calcite
fill 88 220 591 88 223 591 minecraft:cobbled_deepslate
setblock 88 220 595 minecraft:calcite
fill 88 220 596 88 223 596 minecraft:cobbled_deepslate
setblock 48 221 558 minecraft:cobbled_deepslate
setblock 48 221 559 minecraft:calcite
fill 48 221 560 48 224 560 minecraft:cobbled_deepslate
fill 48 221 562 48 221 563 minecraft:cobbled_deepslate
setblock 48 221 564 minecraft:calcite
fill 48 221 566 48 223 566 minecraft:cobbled_deepslate
setblock 48 221 569 minecraft:calcite
fill 48 221 570 48 224 570 minecraft:cobbled_deepslate
setblock 48 221 574 minecraft:calcite
fill 48 221 575 48 224 575 minecraft:cobbled_deepslate
setblock 48 221 579 minecraft:calcite
fill 48 221 580 48 224 580 minecraft:cobbled_deepslate
setblock 48 221 584 minecraft:calcite
fill 48 221 585 48 224 585 minecraft:cobbled_deepslate
setblock 48 221 589 minecraft:calcite
fill 48 221 590 48 223 590 minecraft:cobbled_deepslate
setblock 48 221 594 minecraft:calcite
fill 48 221 595 48 224 595 minecraft:cobbled_deepslate
setblock 49 221 558 minecraft:calcite
setblock 49 221 573 minecraft:calcite
fill 49 221 574 49 224 574 minecraft:cobbled_deepslate
setblock 49 221 578 minecraft:calcite
fill 49 221 579 49 224 579 minecraft:cobbled_deepslate
setblock 49 221 583 minecraft:calcite
fill 49 221 584 49 224 584 minecraft:cobbled_deepslate
setblock 49 221 598 minecraft:calcite
fill 50 221 558 50 224 558 minecraft:cobbled_deepslate
setblock 50 221 577 minecraft:calcite
fill 50 221 578 50 224 578 minecraft:cobbled_deepslate
setblock 50 221 581 minecraft:cobbled_deepslate
fill 50 221 598 50 224 598 minecraft:cobbled_deepslate
fill 52 221 558 53 221 558 minecraft:cobbled_deepslate
fill 55 221 558 58 221 558 minecraft:cobbled_deepslate
setblock 59 221 558 minecraft:calcite
fill 59 221 559 60 223 559 minecraft:cobbled_deepslate
setblock 59 221 598 minecraft:calcite
fill 60 221 558 60 224 558 minecraft:cobbled_deepslate
fill 60 221 598 60 224 598 minecraft:cobbled_deepslate
setblock 62 221 560 minecraft:calcite
fill 62 221 597 62 223 597 minecraft:cobbled_deepslate
setblock 63 221 558 minecraft:cobbled_deepslate
setblock 63 221 559 minecraft:calcite
fill 63 221 560 63 224 560 minecraft:cobbled_deepslate
setblock 64 221 558 minecraft:calcite
fill 64 221 559 64 224 559 minecraft:cobbled_deepslate
fill 64 221 596 65 221 596 minecraft:light_blue_stained_glass
setblock 64 221 598 minecraft:calcite
fill 65 221 558 65 224 558 minecraft:cobbled_deepslate
fill 65 221 595 65 225 595 minecraft:light_blue_stained_glass
setblock 65 221 597 minecraft:calcite
fill 65 221 598 65 224 598 minecraft:cobbled_deepslate
setblock 66 221 596 minecraft:calcite
fill 66 221 597 66 224 597 minecraft:cobbled_deepslate
setblock 67 221 560 minecraft:calcite
fill 67 221 596 67 224 596 minecraft:cobbled_deepslate
setblock 68 221 559 minecraft:calcite
fill 68 221 560 68 224 560 minecraft:cobbled_deepslate
setblock 69 221 558 minecraft:calcite
fill 69 221 559 69 224 559 minecraft:cobbled_deepslate
setblock 69 221 598 minecraft:calcite
fill 70 221 558 70 224 558 minecraft:cobbled_deepslate
setblock 70 221 597 minecraft:calcite
fill 70 221 598 73 221 598 minecraft:cobbled_deepslate
fill 71 221 597 74 221 597 minecraft:cobbled_deepslate
setblock 73 221 559 minecraft:calcite
setblock 74 221 558 minecraft:calcite
setblock 74 221 598 minecraft:calcite
fill 75 221 558 78 221 558 minecraft:cobbled_deepslate
setblock 75 221 597 minecraft:calcite
fill 75 221 598 75 224 598 minecraft:cobbled_deepslate
fill 76 221 597 76 224 597 minecraft:cobbled_deepslate
setblock 79 221 558 minecraft:calcite
setblock 79 221 598 minecraft:calcite
fill 80 221 558 80 224 558 minecraft:cobbled_deepslate
setblock 80 221 597 minecraft:calcite
fill 80 221 598 80 224 598 minecraft:cobbled_deepslate
setblock 81 221 596 minecraft:calcite
fill 81 221 597 81 224 597 minecraft:cobbled_deepslate
setblock 82 221 559 minecraft:cobbled_deepslate
fill 82 221 596 82 224 596 minecraft:cobbled_deepslate
setblock 83 221 559 minecraft:calcite
setblock 84 221 558 minecraft:calcite
fill 84 221 559 87 221 559 minecraft:cobbled_deepslate
setblock 84 221 598 minecraft:calcite
fill 85 221 558 85 224 558 minecraft:cobbled_deepslate
setblock 85 221 597 minecraft:calcite
fill 85 221 598 85 224 598 minecraft:cobbled_deepslate
setblock 86 221 575 minecraft:cobbled_deepslate
setblock 86 221 576 minecraft:calcite
fill 86 221 577 86 221 580 minecraft:cobbled_deepslate
setblock 86 221 581 minecraft:calcite
fill 86 221 582 86 222 584 minecraft:cobbled_deepslate
setblock 86 221 596 minecraft:calcite
fill 86 221 597 86 224 597 minecraft:cobbled_deepslate
setblock 87 221 575 minecraft:calcite
fill 87 221 576 87 224 576 minecraft:cobbled_deepslate
setblock 87 221 580 minecraft:calcite
fill 87 221 581 87 224 581 minecraft:cobbled_deepslate
setblock 87 221 585 minecraft:calcite
fill 87 221 586 87 224 586 minecraft:cobbled_deepslate
setblock 87 221 590 minecraft:calcite
fill 87 221 591 87 224 591 minecraft:cobbled_deepslate
setblock 87 221 595 minecraft:calcite
fill 87 221 596 87 224 596 minecraft:cobbled_deepslate
setblock 88 221 559 minecraft:calcite
fill 88 221 560 88 223 561 minecraft:cobbled_deepslate
fill 88 221 570 88 224 570 minecraft:cobbled_deepslate
setblock 88 221 574 minecraft:calcite
fill 88 221 575 88 224 575 minecraft:cobbled_deepslate
setblock 88 221 579 minecraft:calcite
fill 88 221 580 88 224 580 minecraft:cobbled_deepslate
setblock 88 221 584 minecraft:calcite
fill 88 221 585 88 224 585 minecraft:cobbled_deepslate
setblock 88 221 589 minecraft:calcite
fill 88 221 590 88 224 590 minecraft:cobbled_deepslate
setblock 88 221 594 minecraft:calcite
fill 88 221 595 88 224 595 minecraft:cobbled_deepslate
setblock 48 222 558 minecraft:calcite
fill 48 222 559 49 224 559 minecraft:cobbled_deepslate
setblock 48 222 562 minecraft:cobbled_deepslate
setblock 48 222 563 minecraft:calcite
fill 48 222 564 48 224 565 minecraft:cobbled_deepslate
setblock 48 222 568 minecraft:calcite
fill 48 222 569 48 225 569 minecraft:cobbled_deepslate
setblock 48 222 573 minecraft:calcite
fill 48 222 574 48 225 574 minecraft:cobbled_deepslate
setblock 48 222 578 minecraft:calcite
fill 48 222 579 48 225 579 minecraft:cobbled_deepslate
setblock 48 222 583 minecraft:calcite
fill 48 222 584 48 225 584 minecraft:cobbled_deepslate
setblock 48 222 588 minecraft:calcite
fill 48 222 589 48 225 589 minecraft:cobbled_deepslate
setblock 48 222 593 minecraft:calcite
fill 48 222 594 48 223 594 minecraft:cobbled_deepslate
setblock 48 222 598 minecraft:calcite
fill 49 222 558 49 225 558 minecraft:cobbled_deepslate
setblock 49 222 572 minecraft:calcite
fill 49 222 573 49 225 573 minecraft:cobbled_deepslate
setblock 49 222 577 minecraft:calcite
fill 49 222 578 49 225 578 minecraft:cobbled_deepslate
setblock 49 222 582 minecraft:calcite
fill 49 222 583 49 225 583 minecraft:cobbled_deepslate
fill 49 222 598 49 225 598 minecraft:cobbled_deepslate
setblock 50 222 576 minecraft:calcite
fill 50 222 577 50 225 577 minecraft:cobbled_deepslate
setblock 50 222 581 minecraft:calcite
setblock 52 222 558 minecraft:cobbled_deepslate
setblock 53 222 558 minecraft:calcite
fill 54 222 558 57 222 558 minecraft:cobbled_deepslate
setblock 58 222 558 minecraft:calcite
fill 58 222 559 58 225 559 minecraft:cobbled_deepslate
setblock 58 222 598 minecraft:calcite
fill 59 222 558 59 225 558 minecraft:cobbled_deepslate
fill 59 222 598 59 225 598 minecraft:cobbled_deepslate
setblock 60 222 560 minecraft:cobbled_deepslate
setblock 61 222 560 minecraft:calcite
fill 61 222 597 61 224 597 minecraft:cobbled_deepslate
setblock 62 222 558 minecraft:cobbled_deepslate
setblock 62 222 559 minecraft:calcite
fill 62 222 560 62 225 560 minecraft:cobbled_deepslate
setblock 63 222 558 minecraft:calcite
fill 63 222 559 63 225 559 minecraft:cobbled_deepslate
fill 63 222 596 64 222 596 minecraft:light_blue_stained_glass
setblock 63 222 598 minecraft:calcite
fill 64 222 558 64 225 558 minecraft:cobbled_deepslate
setblock 64 222 561 minecraft:cobbled_deepslate
fill 64 222 594 64 224 595 minecraft:light_blue_stained_glass
setblock 64 222 597 minecraft:calcite
fill 64 222 598 64 225 598 minecraft:cobbled_deepslate
setblock 65 222 561 minecraft:calcite
fill 65 222 594 66 224 594 minecraft:light_blue_stained_glass
setblock 65 222 596 minecraft:calcite
fill 65 222 597 65 225 597 minecraft:cobbled_deepslate
setblock 66 222 559 minecraft:cobbled_deepslate
setblock 66 222 560 minecraft:calcite
fill 66 222 561 66 225 561 minecraft:cobbled_deepslate
fill 66 222 595 66 224 595 minecraft:light_blue_stained_glass
fill 66 222 596 66 225 596 minecraft:cobbled_deepslate
setblock 67 222 559 minecraft:calcite
fill 67 222 560 67 225 560 minecraft:cobbled_deepslate
setblock 68 222 558 minecraft:calcite
fill 68 222 559 68 225 559 minecraft:cobbled_deepslate
setblock 68 222 598 minecraft:calcite
fill 69 222 558 69 225 558 minecraft:cobbled_deepslate
setblock 69 222 597 minecraft:calcite
fill 69 222 598 72 222 598 minecraft:cobbled_deepslate
setblock 70 222 560 minecraft:cobbled_deepslate
fill 70 222 597 73 222 597 minecraft:cobbled_deepslate
setblock 72 222 559 minecraft:calcite
setblock 73 222 558 minecraft:calcite
fill 73 222 559 74 224 559 minecraft:cobbled_deepslate
setblock 73 222 598 minecraft:calcite
fill 74 222 558 77 222 558 minecraft:cobbled_deepslate
setblock 74 222 597 minecraft:calcite
fill 74 222 598 74 225 598 minecraft:cobbled_deepslate
fill 75 222 597 75 225 597 minecraft:cobbled_deepslate
setblock 78 222 558 minecraft:calcite
setblock 78 222 598 minecraft:calcite
fill 79 222 558 79 225 558 minecraft:cobbled_deepslate
setblock 79 222 597 minecraft:calcite
fill 79 222 598 79 225 598 minecraft:cobbled_deepslate
fill 80 222 559 81 222 559 minecraft:cobbled_deepslate
setblock 80 222 596 minecraft:calcite
fill 80 222 597 80 225 597 minecraft:cobbled_deepslate
fill 81 222 596 81 225 596 minecraft:cobbled_deepslate
setblock 82 222 559 minecraft:calcite
setblock 83 222 558 minecraft:calcite
fill 83 222 559 86 222 559 minecraft:cobbled_deepslate
setblock 83 222 598 minecraft:calcite
fill 84 222 558 84 225 558 minecraft:cobbled_deepslate
setblock 84 222 597 minecraft:calcite
fill 84 222 598 84 225 598 minecraft:cobbled_deepslate
fill 85 222 579 85 222 580 minecraft:cobbled_deepslate
setblock 85 222 581 minecraft:calcite
setblock 85 222 596 minecraft:calcite
fill 85 222 597 85 225 597 minecraft:cobbled_deepslate
setblock 86 222 575 minecraft:calcite
fill 86 222 576 86 222 579 minecraft:cobbled_deepslate
setblock 86 222 580 minecraft:calcite
fill 86 222 581 86 225 581 minecraft:cobbled_deepslate
setblock 86 222 585 minecraft:calcite
fill 86 222 586 86 225 586 minecraft:cobbled_deepslate
setblock 86 222 595 minecraft:calcite
fill 86 222 596 86 225 596 minecraft:cobbled_deepslate
setblock 87 222 559 minecraft:calcite
fill 87 222 560 87 225 560 minecraft:cobbled_deepslate
setblock 87 222 574 minecraft:calcite
fill 87 222 575 87 225 575 minecraft:cobbled_deepslate
setblock 87 222 579 minecraft:calcite
fill 87 222 580 87 225 580 minecraft:cobbled_deepslate
setblock 87 222 584 minecraft:calcite
fill 87 222 585 87 225 585 minecraft:cobbled_deepslate
setblock 87 222 589 minecraft:calcite
fill 87 222 590 87 225 590 minecraft:cobbled_deepslate
setblock 87 222 594 minecraft:calcite
fill 87 222 595 87 225 595 minecraft:cobbled_deepslate
setblock 88 222 558 minecraft:calcite
fill 88 222 559 88 225 559 minecraft:cobbled_deepslate
setblock 88 222 562 minecraft:cobbled_deepslate
setblock 88 222 573 minecraft:calcite
fill 88 222 574 88 225 574 minecraft:cobbled_deepslate
setblock 88 222 578 minecraft:calcite
fill 88 222 579 88 225 579 minecraft:cobbled_deepslate
setblock 88 222 583 minecraft:calcite
fill 88 222 584 88 225 584 minecraft:cobbled_deepslate
setblock 88 222 588 minecraft:calcite
fill 88 222 589 88 225 589 minecraft:cobbled_deepslate
setblock 88 222 593 minecraft:calcite
fill 88 222 594 88 225 594 minecraft:cobbled_deepslate
setblock 88 222 598 minecraft:calcite
fill 48 223 558 48 226 558 minecraft:cobbled_deepslate
setblock 48 223 562 minecraft:calcite
fill 48 223 563 48 226 563 minecraft:cobbled_deepslate
setblock 48 223 567 minecraft:calcite
fill 48 223 568 48 226 568 minecraft:cobbled_deepslate
setblock 48 223 572 minecraft:calcite
fill 48 223 573 48 226 573 minecraft:cobbled_deepslate
setblock 48 223 577 minecraft:calcite
fill 48 223 578 48 226 578 minecraft:cobbled_deepslate
setblock 48 223 582 minecraft:calcite
fill 48 223 583 48 226 583 minecraft:cobbled_deepslate
setblock 48 223 587 minecraft:calcite
fill 48 223 588 48 226 588 minecraft:cobbled_deepslate
setblock 48 223 592 minecraft:calcite
setblock 48 223 593 minecraft:cobbled_deepslate
setblock 48 223 597 minecraft:calcite
fill 48 223 598 48 226 598 minecraft:cobbled_deepslate
setblock 49 223 560 minecraft:cobbled_deepslate
setblock 49 223 561 minecraft:calcite
setblock 49 223 571 minecraft:calcite
fill 49 223 572 49 225 572 minecraft:cobbled_deepslate
setblock 49 223 576 minecraft:calcite
fill 49 223 577 49 226 577 minecraft:cobbled_deepslate
setblock 49 223 581 minecraft:calcite
fill 49 223 582 49 226 582 minecraft:cobbled_deepslate
setblock 49 223 585 minecraft:cobbled_deepslate
setblock 50 223 559 minecraft:cobbled_deepslate
setblock 50 223 575 minecraft:calcite
fill 50 223 576 50 224 576 minecraft:cobbled_deepslate
setblock 50 223 580 minecraft:calcite
fill 50 223 581 50 226 581 minecraft:cobbled_deepslate
fill 50 223 582 52 223 582 minecraft:diamond_block
fill 50 223 585 51 224 585 minecraft:diamond_block
setblock 52 223 558 minecraft:calcite
fill 52 223 583 52 223 584 minecraft:diamond_block
fill 53 223 558 56 223 558 minecraft:cobbled_deepslate
setblock 56 223 559 minecraft:calcite
setblock 57 223 558 minecraft:calcite
fill 57 223 559 57 226 559 minecraft:cobbled_deepslate
setblock 57 223 598 minecraft:calcite
fill 58 223 558 58 226 558 minecraft:cobbled_deepslate
fill 58 223 598 58 226 598 minecraft:cobbled_deepslate
setblock 59 223 560 minecraft:cobbled_deepslate
setblock 60 223 560 minecraft:calcite
fill 60 223 597 60 225 597 minecraft:cobbled_deepslate
setblock 61 223 558 minecraft:cobbled_deepslate
setblock 61 223 559 minecraft:calcite
fill 61 223 560 61 226 560 minecraft:cobbled_deepslate
setblock 62 223 558 minecraft:calcite
fill 62 223 559 62 226 559 minecraft:cobbled_deepslate
fill 62 223 561 63 223 561 minecraft:cobbled_deepslate
setblock 62 223 598 minecraft:calcite
fill 63 223 558 63 226 558 minecraft:cobbled_deepslate
fill 63 223 595 63 223 596 minecraft:light_blue_stained_glass
setblock 63 223 597 minecraft:calcite
fill 63 223 598 63 226 598 minecraft:cobbled_deepslate
setblock 64 223 560 minecraft:cobbled_deepslate
setblock 64 223 561 minecraft:calcite
fill 64 223 593 66 224 593 minecraft:light_blue_stained_glass
setblock 64 223 596 minecraft:calcite
fill 64 223 597 64 226 597 minecraft:cobbled_deepslate
setblock 65 223 560 minecraft:calcite
fill 65 223 561 65 226 561 minecraft:cobbled_deepslate
fill 65 223 592 65 225 592 minecraft:light_blue_stained_glass
fill 65 223 596 65 225 596 minecraft:cobbled_deepslate
setblock 66 223 559 minecraft:calcite
fill 66 223 560 66 226 560 minecraft:cobbled_deepslate
setblock 67 223 558 minecraft:calcite
fill 67 223 559 67 226 559 minecraft:cobbled_deepslate
fill 67 223 561 67 224 561 minecraft:cobbled_deepslate
setblock 67 223 595 minecraft:light_blue_stained_glass
setblock 67 223 598 minecraft:calcite
fill 68 223 558 68 226 558 minecraft:cobbled_deepslate
setblock 68 223 597 minecraft:calcite
fill 68 223 598 71 223 598 minecraft:cobbled_deepslate
fill 69 223 597 72 223 597 minecraft:cobbled_deepslate
setblock 70 223 560 minecraft:calcite
setblock 71 223 559 minecraft:calcite
setblock 72 223 558 minecraft:calcite
fill 72 223 559 72 226 559 minecraft:cobbled_deepslate
setblock 72 223 598 minecraft:calcite
fill 73 223 558 76 223 558 minecraft:cobbled_deepslate
setblock 73 223 597 minecraft:calcite
fill 73 223 598 73 226 598 minecraft:cobbled_deepslate
fill 74 223 597 74 226 597 minecraft:cobbled_deepslate
setblock 75 223 559 minecraft:cobbled_deepslate
setblock 76 223 559 minecraft:calcite
setblock 77 223 558 minecraft:calcite
fill 77 223 559 80 223 559 minecraft:cobbled_deepslate
setblock 77 223 598 minecraft:calcite
fill 78 223 558 78 226 558 minecraft:cobbled_deepslate
setblock 78 223 597 minecraft:calcite
fill 78 223 598 78 226 598 minecraft:cobbled_deepslate
fill 79 223 597 79 226 597 minecraft:cobbled_deepslate
fill 80 223 596 80 226 596 minecraft:cobbled_deepslate
setblock 81 223 559 minecraft:calcite
setblock 82 223 558 minecraft:calcite
fill 82 223 559 85 223 559 minecraft:cobbled_deepslate
setblock 82 223 598 minecraft:calcite
fill 83 223 558 83 226 558 minecraft:cobbled_deepslate
setblock 83 223 597 minecraft:calcite
fill 83 223 598 83 226 598 minecraft:cobbled_deepslate
setblock 84 223 596 minecraft:calcite
fill 84 223 597 84 226 597 minecraft:cobbled_deepslate
fill 85 223 578 85 223 579 minecraft:cobbled_deepslate
setblock 85 223 580 minecraft:calcite
fill 85 223 581 85 224 583 minecraft:cobbled_deepslate
fill 85 223 596 85 225 596 minecraft:cobbled_deepslate
setblock 86 223 559 minecraft:calcite
fill 86 223 575 86 223 578 minecraft:cobbled_deepslate
setblock 86 223 579 minecraft:calcite
fill 86 223 580 86 226 580 minecraft:cobbled_deepslate
fill 86 223 582 86 223 583 minecraft:cobbled_deepslate
setblock 86 223 584 minecraft:calcite
fill 86 223 585 86 226 585 minecraft:cobbled_deepslate
fill 86 223 587 86 223 588 minecraft:cobbled_deepslate
setblock 86 223 594 minecraft:calcite
fill 86 223 595 86 224 595 minecraft:cobbled_deepslate
setblock 87 223 558 minecraft:calcite
fill 87 223 559 87 226 559 minecraft:cobbled_deepslate
fill 87 223 561 87 224 561 minecraft:cobbled_deepslate
setblock 87 223 573 minecraft:calcite
fill 87 223 574 87 226 574 minecraft:cobbled_deepslate
setblock 87 223 578 minecraft:calcite
fill 87 223 579 87 226 579 minecraft:cobbled_deepslate
setblock 87 223 583 minecraft:calcite
fill 87 223 584 87 226 584 minecraft:cobbled_deepslate
setblock 87 223 588 minecraft:calcite
fill 87 223 589 87 226 589 minecraft:cobbled_deepslate
setblock 87 223 593 minecraft:calcite
fill 87 223 594 87 225 594 minecraft:cobbled_deepslate
setblock 87 223 598 minecraft:calcite
fill 88 223 558 88 226 558 minecraft:cobbled_deepslate
setblock 88 223 562 minecraft:calcite
fill 88 223 563 88 225 564 minecraft:cobbled_deepslate
setblock 88 223 572 minecraft:calcite
fill 88 223 573 88 226 573 minecraft:cobbled_deepslate
setblock 88 223 577 minecraft:calcite
fill 88 223 578 88 226 578 minecraft:cobbled_deepslate
setblock 88 223 582 minecraft:calcite
fill 88 223 583 88 226 583 minecraft:cobbled_deepslate
setblock 88 223 587 minecraft:calcite
fill 88 223 588 88 226 588 minecraft:cobbled_deepslate
setblock 88 223 592 minecraft:calcite
fill 88 223 593 88 226 593 minecraft:cobbled_deepslate
setblock 88 223 597 minecraft:calcite
fill 88 223 598 88 226 598 minecraft:cobbled_deepslate
setblock 48 224 561 minecraft:calcite
fill 48 224 562 49 226 562 minecraft:cobbled_deepslate
setblock 48 224 566 minecraft:calcite
fill 48 224 567 48 226 567 minecraft:cobbled_deepslate
setblock 48 224 571 minecraft:calcite
fill 48 224 572 48 226 572 minecraft:cobbled_deepslate
setblock 48 224 576 minecraft:calcite
fill 48 224 577 48 226 577 minecraft:cobbled_deepslate
setblock 48 224 581 minecraft:calcite
fill 48 224 582 48 226 582 minecraft:cobbled_deepslate
setblock 48 224 586 minecraft:calcite
fill 48 224 587 48 226 587 minecraft:cobbled_deepslate
setblock 48 224 596 minecraft:calcite
fill 48 224 597 48 225 597 minecraft:cobbled_deepslate
setblock 49 224 560 minecraft:calcite
fill 49 224 561 49 226 561 minecraft:cobbled_deepslate
fill 49 224 563 49 225 563 minecraft:cobbled_deepslate
setblock 49 224 571 minecraft:cobbled_deepslate
setblock 49 224 575 minecraft:calcite
fill 49 224 576 49 226 576 minecraft:cobbled_deepslate
setblock 49 224 580 minecraft:calcite
fill 49 224 581 49 226 581 minecraft:cobbled_deepslate
setblock 49 224 585 minecraft:calcite
setblock 50 224 559 minecraft:calcite
setblock 50 224 579 minecraft:calcite
fill 50 224 580 50 226 580 minecraft:cobbled_deepslate
fill 50 224 582 50 225 582 minecraft:cobbled_deepslate
setblock 51 224 558 minecraft:calcite
fill 51 224 559 54 224 559 minecraft:cobbled_deepslate
fill 51 224 582 51 225 582 minecraft:diamond_block
fill 52 224 558 55 224 558 minecraft:cobbled_deepslate
setblock 52 224 583 minecraft:diamond_block
setblock 55 224 559 minecraft:calcite
setblock 56 224 558 minecraft:calcite
fill 56 224 559 56 226 559 minecraft:cobbled_deepslate
fill 57 224 558 57 226 558 minecraft:cobbled_deepslate
fill 57 224 598 57 226 598 minecraft:cobbled_deepslate
setblock 58 224 560 minecraft:cobbled_deepslate
setblock 59 224 559 minecraft:cobbled_deepslate
setblock 59 224 560 minecraft:calcite
setblock 60 224 559 minecraft:calcite
fill 60 224 560 60 226 561 minecraft:cobbled_deepslate
setblock 61 224 558 minecraft:calcite
fill 61 224 559 61 226 559 minecraft:cobbled_deepslate
fill 61 224 561 62 224 561 minecraft:cobbled_deepslate
setblock 61 224 598 minecraft:calcite
fill 62 224 558 62 226 558 minecraft:cobbled_deepslate
setblock 62 224 597 minecraft:calcite
fill 62 224 598 62 226 598 minecraft:cobbled_deepslate
setblock 63 224 561 minecraft:calcite
fill 63 224 597 63 226 597 minecraft:cobbled_deepslate
setblock 64 224 560 minecraft:calcite
fill 64 224 561 64 226 561 minecraft:cobbled_deepslate
setblock 64 224 592 minecraft:light_blue_stained_glass
fill 64 224 596 64 225 596 minecraft:cobbled_deepslate
setblock 65 224 559 minecraft:calcite
fill 65 224 560 65 226 560 minecraft:cobbled_deepslate
fill 65 224 591 65 225 591 minecraft:light_blue_stained_glass
setblock 66 224 558 minecraft:calcite
fill 66 224 559 66 226 559 minecraft:cobbled_deepslate
setblock 66 224 592 minecraft:light_blue_stained_glass
setblock 66 224 598 minecraft:calcite
fill 67 224 558 67 226 558 minecraft:cobbled_deepslate
setblock 67 224 597 minecraft:calcite
fill 67 224 598 70 224 598 minecraft:cobbled_deepslate
fill 68 224 597 71 224 597 minecraft:cobbled_deepslate
setblock 69 224 560 minecraft:calcite
setblock 70 224 559 minecraft:calcite
fill 70 224 560 71 225 560 minecraft:cobbled_deepslate
setblock 71 224 558 minecraft:calcite
fill 71 224 559 71 226 559 minecraft:cobbled_deepslate
setblock 71 224 598 minecraft:calcite
fill 72 224 558 75 224 558 minecraft:cobbled_deepslate
setblock 72 224 597 minecraft:calcite
fill 72 224 598 72 226 598 minecraft:cobbled_deepslate
fill 73 224 597 73 226 597 minecraft:cobbled_deepslate
setblock 75 224 559 minecraft:calcite
setblock 76 224 558 minecraft:calcite
fill 76 224 559 79 224 559 minecraft:cobbled_deepslate
setblock 76 224 598 minecraft:calcite
fill 77 224 558 77 226 558 minecraft:cobbled_deepslate
setblock 77 224 597 minecraft:calcite
fill 77 224 598 77 226 598 minecraft:cobbled_deepslate
fill 78 224 597 78 226 597 minecraft:cobbled_deepslate
fill 79 224 596 79 225 596 minecraft:cobbled_deepslate
setblock 80 224 559 minecraft:calcite
setblock 81 224 558 minecraft:calcite
fill 81 224 559 84 224 559 minecraft:cobbled_deepslate
setblock 81 224 598 minecraft:calcite
fill 82 224 558 82 226 558 minecraft:cobbled_deepslate
fill 82 224 560 83 224 560 minecraft:cobbled_deepslate
setblock 82 224 597 minecraft:calcite
fill 82 224 598 82 226 598 minecraft:cobbled_deepslate
setblock 83 224 596 minecraft:calcite
fill 83 224 597 83 226 597 minecraft:cobbled_deepslate
setblock 84 224 560 minecraft:calcite
fill 84 224 596 84 226 596 minecraft:cobbled_deepslate
setblock 85 224 559 minecraft:calcite
fill 85 224 560 85 226 560 minecraft:cobbled_deepslate
fill 85 224 577 85 224 578 minecraft:cobbled_deepslate
setblock 85 224 579 minecraft:calcite
fill 85 224 580 85 226 580 minecraft:cobbled_deepslate
setblock 85 224 584 minecraft:calcite
fill 85 224 585 85 226 585 minecraft:cobbled_deepslate
setblock 86 224 558 minecraft:calcite
fill 86 224 559 86 226 559 minecraft:cobbled_deepslate
fill 86 224 575 86 224 577 minecraft:cobbled_deepslate
setblock 86 224 578 minecraft:calcite
fill 86 224 579 86 226 579 minecraft:cobbled_deepslate
setblock 86 224 582 minecraft:cobbled_deepslate
setblock 86 224 583 minecraft:calcite
fill 86 224 584 86 226 584 minecraft:cobbled_deepslate
setblock 86 224 587 minecraft:cobbled_deepslate
setblock 86 224 588 minecraft:calcite
fill 86 224 589 86 226 589 minecraft:cobbled_deepslate
setblock 86 224 594 minecraft:cobbled_deepslate
setblock 86 224 598 minecraft:calcite
fill 87 224 558 87 226 558 minecraft:cobbled_deepslate
setblock 87 224 562 minecraft:calcite
fill 87 224 573 87 225 573 minecraft:cobbled_deepslate
setblock 87 224 577 minecraft:calcite
fill 87 224 578 87 226 578 minecraft:cobbled_deepslate
setblock 87 224 582 minecraft:calcite
fill 87 224 583 87 226 583 minecraft:cobbled_deepslate
setblock 87 224 587 minecraft:calcite
fill 87 224 588 87 226 588 minecraft:cobbled_deepslate
setblock 87 224 592 minecraft:calcite
fill 87 224 593 87 225 593 minecraft:cobbled_deepslate
setblock 87 224 597 minecraft:calcite
fill 87 224 598 87 226 598 minecraft:cobbled_deepslate
setblock 88 224 560 minecraft:cobbled_deepslate
setblock 88 224 561 minecraft:calcite
fill 88 224 562 88 226 562 minecraft:cobbled_deepslate
setblock 88 224 565 minecraft:cobbled_deepslate
setblock 88 224 571 minecraft:calcite
fill 88 224 572 88 226 572 minecraft:cobbled_deepslate
setblock 88 224 576 minecraft:calcite
fill 88 224 577 88 226 577 minecraft:cobbled_deepslate
setblock 88 224 581 minecraft:calcite
fill 88 224 582 88 226 582 minecraft:cobbled_deepslate
setblock 88 224 586 minecraft:calcite
fill 88 224 587 88 226 587 minecraft:cobbled_deepslate
setblock 88 224 591 minecraft:calcite
fill 88 224 592 88 226 592 minecraft:cobbled_deepslate
setblock 88 224 596 minecraft:calcite
fill 88 224 597 88 226 597 minecraft:cobbled_deepslate
setblock 48 225 559 minecraft:cobbled_deepslate
setblock 48 225 560 minecraft:calcite
fill 48 225 561 48 226 561 minecraft:cobbled_deepslate
setblock 48 225 564 minecraft:cobbled_deepslate
setblock 48 225 565 minecraft:calcite
fill 48 225 566 48 226 566 minecraft:cobbled_deepslate
setblock 48 225 570 minecraft:calcite
fill 48 225 571 48 226 571 minecraft:cobbled_deepslate
setblock 48 225 575 minecraft:calcite
fill 48 225 576 48 226 576 minecraft:cobbled_deepslate
setblock 48 225 580 minecraft:calcite
fill 48 225 581 48 226 581 minecraft:cobbled_deepslate
setblock 48 225 585 minecraft:calcite
fill 48 225 586 48 226 586 minecraft:cobbled_deepslate
setblock 48 225 596 minecraft:cobbled_deepslate
setblock 49 225 559 minecraft:calcite
fill 49 225 560 49 226 560 minecraft:cobbled_deepslate
setblock 49 225 564 minecraft:calcite
setblock 49 225 574 minecraft:calcite
fill 49 225 575 49 226 575 minecraft:cobbled_deepslate
setblock 49 225 579 minecraft:calcite
fill 49 225 580 49 226 580 minecraft:cobbled_deepslate
setblock 49 225 584 minecraft:calcite
fill 49 225 585 49 226 585 minecraft:cobbled_deepslate
setblock 50 225 558 minecraft:calcite
fill 50 225 559 53 225 559 minecraft:cobbled_deepslate
setblock 50 225 578 minecraft:calcite
fill 50 225 579 50 226 579 minecraft:cobbled_deepslate
fill 51 225 558 54 225 558 minecraft:cobbled_deepslate
setblock 54 225 559 minecraft:calcite
setblock 55 225 558 minecraft:calcite
fill 55 225 559 55 226 559 minecraft:cobbled_deepslate
fill 56 225 558 56 226 558 minecraft:cobbled_deepslate
fill 56 225 560 57 225 560 minecraft:cobbled_deepslate
fill 56 225 598 56 226 598 minecraft:cobbled_deepslate
setblock 58 225 560 minecraft:calcite
setblock 59 225 559 minecraft:calcite
fill 59 225 560 59 226 561 minecraft:cobbled_deepslate
setblock 60 225 558 minecraft:calcite
fill 60 225 559 60 226 559 minecraft:cobbled_deepslate
setblock 60 225 598 minecraft:calcite
fill 61 225 558 61 226 558 minecraft:cobbled_deepslate
setblock 61 225 561 minecraft:cobbled_deepslate
setblock 61 225 597 minecraft:calcite
fill 61 225 598 61 226 598 minecraft:cobbled_deepslate
setblock 62 225 561 minecraft:calcite
fill 62 225 597 62 226 597 minecraft:cobbled_deepslate
setblock 63 225 560 minecraft:calcite
fill 63 225 561 63 226 561 minecraft:cobbled_deepslate
setblock 64 225 559 minecraft:calcite
fill 64 225 560 64 226 560 minecraft:cobbled_deepslate
setblock 65 225 558 minecraft:calcite
fill 65 225 559 65 226 559 minecraft:cobbled_deepslate
fill 65 225 589 65 225 590 minecraft:light_blue_stained_glass
fill 65 225 593 65 225 594 minecraft:light_blue_stained_glass
setblock 65 225 598 minecraft:calcite
fill 66 225 558 66 226 558 minecraft:cobbled_deepslate
setblock 66 225 597 minecraft:calcite
fill 66 225 598 69 225 598 minecraft:cobbled_deepslate
setblock 67 225 561 minecraft:calcite
fill 67 225 597 70 225 597 minecraft:cobbled_deepslate
setblock 68 225 560 minecraft:calcite
setblock 68 225 561 minecraft:cobbled_deepslate
setblock 69 225 559 minecraft:calcite
fill 69 225 560 69 226 560 minecraft:cobbled_deepslate
setblock 70 225 558 minecraft:calcite
fill 70 225 559 70 226 559 minecraft:cobbled_deepslate
setblock 70 225 598 minecraft:calcite
fill 71 225 558 74 225 558 minecraft:cobbled_deepslate
setblock 71 225 597 minecraft:calcite
fill 71 225 598 71 226 598 minecraft:cobbled_deepslate
fill 72 225 597 72 226 597 minecraft:cobbled_deepslate
setblock 73 225 559 minecraft:cobbled_deepslate
setblock 74 225 559 minecraft:calcite
setblock 75 225 558 minecraft:calcite
fill 75 225 559 78 225 559 minecraft:cobbled_deepslate
setblock 75 225 598 minecraft:calcite
fill 76 225 558 76 226 558 minecraft:cobbled_deepslate
setblock 76 225 597 minecraft:calcite
fill 76 225 598 76 226 598 minecraft:cobbled_deepslate
fill 77 225 597 77 226 597 minecraft:cobbled_deepslate
setblock 79 225 559 minecraft:calcite
setblock 80 225 558 minecraft:calcite
fill 80 225 559 83 225 559 minecraft:cobbled_deepslate
setblock 80 225 598 minecraft:calcite
fill 81 225 558 81 226 558 minecraft:cobbled_deepslate
fill 81 225 560 82 225 560 minecraft:cobbled_deepslate
setblock 81 225 597 minecraft:calcite
fill 81 225 598 81 226 598 minecraft:cobbled_deepslate
setblock 82 225 596 minecraft:calcite
fill 82 225 597 82 226 597 minecraft:cobbled_deepslate
setblock 83 225 560 minecraft:calcite
fill 83 225 596 83 226 596 minecraft:cobbled_deepslate
setblock 84 225 559 minecraft:calcite
fill 84 225 560 84 226 560 minecraft:cobbled_deepslate
fill 84 225 581 85 225 582 minecraft:cobbled_deepslate
setblock 85 225 558 minecraft:calcite
fill 85 225 559 85 226 559 minecraft:cobbled_deepslate
setblock 85 225 577 minecraft:cobbled_deepslate
setblock 85 225 578 minecraft:calcite
fill 85 225 579 85 226 579 minecraft:cobbled_deepslate
setblock 85 225 583 minecraft:calcite
fill 85 225 584 85 226 584 minecraft:cobbled_deepslate
fill 85 225 586 85 226 586 minecraft:cobbled_deepslate
setblock 85 225 598 minecraft:calcite
fill 86 225 558 86 226 558 minecraft:cobbled_deepslate
fill 86 225 575 86 225 576 minecraft:cobbled_deepslate
setblock 86 225 577 minecraft:calcite
fill 86 225 578 86 226 578 minecraft:cobbled_deepslate
setblock 86 225 582 minecraft:calcite
fill 86 225 583 86 226 583 minecraft:cobbled_deepslate
setblock 86 225 587 minecraft:calcite
fill 86 225 588 86 226 588 minecraft:cobbled_deepslate
setblock 86 225 597 minecraft:calcite
fill 86 225 598 86 226 598 minecraft:cobbled_deepslate
setblock 87 225 561 minecraft:calcite
fill 87 225 562 87 226 563 minecraft:cobbled_deepslate
setblock 87 225 576 minecraft:calcite
fill 87 225 577 87 226 577 minecraft:cobbled_deepslate
setblock 87 225 581 minecraft:calcite
fill 87 225 582 87 226 582 minecraft:cobbled_deepslate
setblock 87 225 586 minecraft:calcite
fill 87 225 587 87 226 587 minecraft:cobbled_deepslate
setblock 87 225 591 minecraft:calcite
fill 87 225 592 87 226 592 minecraft:cobbled_deepslate
setblock 87 225 596 minecraft:calcite
fill 87 225 597 87 226 597 minecraft:cobbled_deepslate
setblock 88 225 560 minecraft:calcite
fill 88 225 561 88 226 561 minecraft:cobbled_deepslate
setblock 88 225 565 minecraft:calcite
fill 88 225 566 88 226 566 minecraft:cobbled_deepslate
setblock 88 225 570 minecraft:calcite
fill 88 225 571 88 226 571 minecraft:cobbled_deepslate
setblock 88 225 575 minecraft:calcite
fill 88 225 576 88 226 576 minecraft:cobbled_deepslate
setblock 88 225 580 minecraft:calcite
fill 88 225 581 88 226 581 minecraft:cobbled_deepslate
setblock 88 225 585 minecraft:calcite
fill 88 225 586 88 226 586 minecraft:cobbled_deepslate
setblock 88 225 590 minecraft:calcite
fill 88 225 591 88 226 591 minecraft:cobbled_deepslate
setblock 88 225 595 minecraft:calcite
fill 88 225 596 88 226 596 minecraft:cobbled_deepslate
setblock 48 226 559 minecraft:calcite
setblock 48 226 560 minecraft:cobbled_deepslate
setblock 48 226 564 minecraft:calcite
fill 48 226 565 49 226 565 minecraft:cobbled_deepslate
setblock 48 226 569 minecraft:calcite
setblock 48 226 570 minecraft:cobbled_deepslate
setblock 48 226 574 minecraft:calcite
setblock 48 226 575 minecraft:cobbled_deepslate
setblock 48 226 579 minecraft:calcite
setblock 48 226 580 minecraft:cobbled_deepslate
setblock 48 226 584 minecraft:calcite
setblock 48 226 585 minecraft:cobbled_deepslate
setblock 48 226 589 minecraft:calcite
setblock 49 226 558 minecraft:calcite
fill 49 226 559 52 226 559 minecraft:cobbled_deepslate
setblock 49 226 563 minecraft:calcite
setblock 49 226 564 minecraft:cobbled_deepslate
setblock 49 226 573 minecraft:calcite
setblock 49 226 574 minecraft:cobbled_deepslate
setblock 49 226 578 minecraft:calcite
setblock 49 226 579 minecraft:cobbled_deepslate
setblock 49 226 583 minecraft:calcite
setblock 49 226 584 minecraft:cobbled_deepslate
fill 50 226 558 53 226 558 minecraft:cobbled_deepslate
setblock 53 226 559 minecraft:calcite
setblock 54 226 558 minecraft:calcite
setblock 54 226 559 minecraft:cobbled_deepslate
setblock 55 226 558 minecraft:cobbled_deepslate
setblock 56 226 560 minecraft:cobbled_deepslate
setblock 57 226 560 minecraft:calcite
setblock 58 226 559 minecraft:calcite
fill 58 226 560 58 226 561 minecraft:cobbled_deepslate
setblock 59 226 558 minecraft:calcite
setblock 59 226 559 minecraft:cobbled_deepslate
setblock 59 226 598 minecraft:calcite
setblock 60 226 558 minecraft:cobbled_deepslate
setblock 60 226 597 minecraft:calcite
setblock 60 226 598 minecraft:cobbled_deepslate
setblock 61 226 561 minecraft:calcite
setblock 61 226 597 minecraft:cobbled_deepslate
setblock 62 226 560 minecraft:calcite
fill 62 226 561 62 226 562 minecraft:cobbled_deepslate
setblock 63 226 559 minecraft:calcite
setblock 63 226 560 minecraft:cobbled_deepslate
setblock 63 226 562 minecraft:cobbled_deepslate
setblock 64 226 558 minecraft:calcite
setblock 64 226 559 minecraft:cobbled_deepslate
setblock 64 226 598 minecraft:calcite
setblock 65 226 558 minecraft:cobbled_deepslate
setblock 65 226 597 minecraft:calcite
fill 65 226 598 68 226 598 minecraft:cobbled_deepslate
setblock 66 226 561 minecraft:calcite
fill 66 226 597 69 226 597 minecraft:cobbled_deepslate
setblock 67 226 560 minecraft:calcite
setblock 67 226 561 minecraft:cobbled_deepslate
setblock 68 226 559 minecraft:calcite
setblock 68 226 560 minecraft:cobbled_deepslate
setblock 69 226 558 minecraft:calcite
setblock 69 226 559 minecraft:cobbled_deepslate
setblock 69 226 598 minecraft:calcite
fill 70 226 558 73 226 558 minecraft:cobbled_deepslate
setblock 70 226 560 minecraft:cobbled_deepslate
setblock 70 226 597 minecraft:calcite
setblock 70 226 598 minecraft:cobbled_deepslate
setblock 71 226 597 minecraft:cobbled_deepslate
setblock 73 226 559 minecraft:calcite
setblock 74 226 558 minecraft:calcite
fill 74 226 559 77 226 559 minecraft:cobbled_deepslate
setblock 74 226 598 minecraft:calcite
setblock 75 226 558 minecraft:cobbled_deepslate
setblock 75 226 597 minecraft:calcite
setblock 75 226 598 minecraft:cobbled_deepslate
setblock 76 226 597 minecraft:cobbled_deepslate
setblock 78 226 559 minecraft:calcite
setblock 79 226 558 minecraft:calcite
fill 79 226 559 82 226 559 minecraft:cobbled_deepslate
setblock 79 226 598 minecraft:calcite
setblock 80 226 558 minecraft:cobbled_deepslate
fill 80 226 560 81 226 560 minecraft:cobbled_deepslate
setblock 80 226 597 minecraft:calcite
setblock 80 226 598 minecraft:cobbled_deepslate
setblock 81 226 596 minecraft:calcite
setblock 81 226 597 minecraft:cobbled_deepslate
setblock 82 226 560 minecraft:calcite
setblock 82 226 596 minecraft:cobbled_deepslate
setblock 83 226 559 minecraft:calcite
setblock 83 226 560 minecraft:cobbled_deepslate
setblock 84 226 558 minecraft:calcite
setblock 84 226 559 minecraft:cobbled_deepslate
fill 84 226 581 84 226 582 minecraft:cobbled_deepslate
setblock 84 226 583 minecraft:calcite
setblock 84 226 598 minecraft:calcite
setblock 85 226 558 minecraft:cobbled_deepslate
setblock 85 226 578 minecraft:cobbled_deepslate
setblock 85 226 581 minecraft:cobbled_deepslate
setblock 85 226 582 minecraft:calcite
setblock 85 226 583 minecraft:cobbled_deepslate
setblock 85 226 587 minecraft:calcite
setblock 85 226 597 minecraft:calcite
setblock 85 226 598 minecraft:cobbled_deepslate
setblock 86 226 576 minecraft:calcite
setblock 86 226 577 minecraft:cobbled_deepslate
setblock 86 226 581 minecraft:calcite
setblock 86 226 582 minecraft:cobbled_deepslate
setblock 86 226 586 minecraft:calcite
setblock 86 226 587 minecraft:cobbled_deepslate
setblock 86 226 597 minecraft:cobbled_deepslate
setblock 87 226 560 minecraft:calcite
setblock 87 226 561 minecraft:cobbled_deepslate
setblock 87 226 575 minecraft:calcite
setblock 87 226 576 minecraft:cobbled_deepslate
setblock 87 226 580 minecraft:calcite
setblock 87 226 581 minecraft:cobbled_deepslate
setblock 87 226 585 minecraft:calcite
setblock 87 226 586 minecraft:cobbled_deepslate
setblock 87 226 590 minecraft:calcite
setblock 87 226 591 minecraft:cobbled_deepslate
setblock 87 226 595 minecraft:calcite
setblock 87 226 596 minecraft:cobbled_deepslate
setblock 88 226 559 minecraft:calcite
setblock 88 226 560 minecraft:cobbled_deepslate
setblock 88 226 563 minecraft:cobbled_deepslate
setblock 88 226 564 minecraft:calcite
setblock 88 226 565 minecraft:cobbled_deepslate
setblock 88 226 567 minecraft:cobbled_deepslate
setblock 88 226 574 minecraft:calcite
setblock 88 226 575 minecraft:cobbled_deepslate
setblock 88 226 579 minecraft:calcite
setblock 88 226 580 minecraft:cobbled_deepslate
setblock 88 226 584 minecraft:calcite
setblock 88 226 585 minecraft:cobbled_deepslate
setblock 88 226 589 minecraft:calcite
setblock 88 226 590 minecraft:cobbled_deepslate
setblock 88 226 594 minecraft:calcite
setblock 88 226 595 minecraft:cobbled_deepslate
setblock 50 228 560 minecraft:light[level=14]
setblock 50 228 568 minecraft:light[level=14]
setblock 50 228 576 minecraft:light[level=14]
setblock 50 228 584 minecraft:light[level=14]
setblock 50 228 592 minecraft:light[level=14]
setblock 58 228 560 minecraft:light[level=14]
setblock 58 228 568 minecraft:light[level=14]
setblock 58 228 576 minecraft:light[level=14]
setblock 58 228 584 minecraft:light[level=14]
setblock 58 228 592 minecraft:light[level=14]
setblock 66 228 560 minecraft:light[level=14]
setblock 66 228 568 minecraft:light[level=14]
setblock 66 228 576 minecraft:light[level=14]
setblock 66 228 584 minecraft:light[level=14]
setblock 66 228 592 minecraft:light[level=14]
setblock 74 228 560 minecraft:light[level=14]
setblock 74 228 568 minecraft:light[level=14]
setblock 74 228 576 minecraft:light[level=14]
setblock 74 228 584 minecraft:light[level=14]
setblock 74 228 592 minecraft:light[level=14]
setblock 82 228 560 minecraft:light[level=14]
setblock 82 228 568 minecraft:light[level=14]
setblock 82 228 576 minecraft:light[level=14]
setblock 82 228 584 minecraft:light[level=14]
setblock 82 228 592 minecraft:light[level=14]
fill 65 231 573 67 231 575 minecraft:redstone_block
fill 65 231 581 67 231 583 minecraft:redstone_block
fill 71 231 573 73 231 575 minecraft:redstone_block
fill 72 231 580 74 231 582 minecraft:redstone_block
fill 55 232 578 67 232 578 minecraft:diamond_block
fill 57 232 577 67 232 577 minecraft:diamond_block
fill 57 232 579 67 232 579 minecraft:diamond_block
fill 58 232 576 80 232 576 minecraft:diamond_block
fill 58 232 580 71 232 580 minecraft:diamond_block
fill 61 232 575 64 232 575 minecraft:diamond_block
fill 61 232 581 64 232 581 minecraft:diamond_block
fill 62 232 566 62 233 571 minecraft:diamond_block
fill 62 232 585 62 233 590 minecraft:diamond_block
fill 63 232 567 64 232 574 minecraft:diamond_block
fill 63 232 582 64 232 589 minecraft:diamond_block
fill 65 232 568 66 232 572 minecraft:diamond_block
fill 65 232 584 66 232 588 minecraft:diamond_block
fill 67 232 569 67 232 572 minecraft:diamond_block
fill 67 232 584 67 232 587 minecraft:diamond_block
fill 68 232 570 68 232 575 minecraft:diamond_block
fill 68 232 581 68 232 586 minecraft:diamond_block
fill 69 232 572 70 232 575 minecraft:diamond_block
fill 69 232 581 71 232 584 minecraft:diamond_block
fill 70 232 570 76 232 571 minecraft:diamond_block
fill 70 232 585 76 232 586 minecraft:diamond_block
fill 71 232 569 76 233 569 minecraft:diamond_block
fill 71 232 572 75 232 572 minecraft:diamond_block
fill 71 232 577 81 232 579 minecraft:diamond_block
fill 71 232 587 76 233 587 minecraft:diamond_block
fill 72 232 568 76 233 568 minecraft:diamond_block
fill 72 232 583 75 232 584 minecraft:diamond_block
fill 72 232 588 76 233 588 minecraft:diamond_block
fill 74 232 567 76 233 567 minecraft:diamond_block
fill 74 232 573 75 232 575 minecraft:diamond_block
fill 74 232 589 76 233 589 minecraft:diamond_block
fill 75 232 580 75 232 582 minecraft:diamond_block
fill 76 232 566 76 233 566 minecraft:diamond_block
fill 76 232 575 77 233 575 minecraft:diamond_block
fill 76 232 580 77 233 581 minecraft:diamond_block
fill 76 232 590 76 233 590 minecraft:diamond_block
fill 78 232 580 80 233 580 minecraft:diamond_block
fill 82 232 578 83 233 578 minecraft:diamond_block
fill 48 233 558 54 233 598 minecraft:cobbled_deepslate
fill 55 233 558 56 233 577 minecraft:cobbled_deepslate
fill 55 233 578 59 233 578 minecraft:diamond_block
fill 55 233 579 56 233 598 minecraft:cobbled_deepslate
fill 57 233 558 57 233 576 minecraft:cobbled_deepslate
fill 57 233 577 60 233 577 minecraft:diamond_block
fill 57 233 579 60 233 579 minecraft:diamond_block
fill 57 233 580 57 233 598 minecraft:cobbled_deepslate
fill 58 233 558 60 233 575 minecraft:cobbled_deepslate
fill 58 233 576 62 233 576 minecraft:diamond_block
fill 58 233 580 62 233 580 minecraft:diamond_block
fill 58 233 581 60 233 598 minecraft:cobbled_deepslate
fill 60 233 578 64 233 578 minecraft:light_blue_stained_glass
fill 61 233 558 61 233 574 minecraft:cobbled_deepslate
fill 61 233 575 63 233 575 minecraft:diamond_block
fill 61 233 577 65 233 577 minecraft:light_blue_stained_glass
fill 61 233 579 65 233 579 minecraft:light_blue_stained_glass
fill 61 233 581 63 233 581 minecraft:diamond_block
fill 61 233 582 61 233 598 minecraft:cobbled_deepslate
fill 62 233 558 88 233 565 minecraft:cobbled_deepslate
fill 62 233 572 62 233 574 minecraft:cobbled_deepslate
fill 62 233 582 62 233 584 minecraft:cobbled_deepslate
fill 62 233 591 88 233 598 minecraft:cobbled_deepslate
fill 63 233 566 75 233 566 minecraft:cobbled_deepslate
fill 63 233 567 63 233 574 minecraft:diamond_block
setblock 63 233 576 minecraft:light_blue_stained_glass
setblock 63 233 580 minecraft:light_blue_stained_glass
fill 63 233 582 63 233 589 minecraft:diamond_block
fill 63 233 590 75 233 590 minecraft:cobbled_deepslate
fill 64 233 567 64 233 569 minecraft:diamond_block
fill 64 233 570 65 233 571 minecraft:light_blue_stained_glass
fill 64 233 572 64 233 576 minecraft:sea_lantern
fill 64 233 580 64 233 584 minecraft:sea_lantern
fill 64 233 585 65 233 586 minecraft:light_blue_stained_glass
fill 64 233 587 64 233 589 minecraft:diamond_block
fill 65 233 567 73 233 567 minecraft:cobbled_deepslate
fill 65 233 568 66 233 569 minecraft:diamond_block
fill 65 233 572 68 233 572 minecraft:sea_lantern
fill 65 233 573 67 233 575 minecraft:cobbled_deepslate
fill 65 233 576 74 233 576 minecraft:sea_lantern
fill 65 233 578 67 233 578 minecraft:sea_lantern
fill 65 233 580 71 233 580 minecraft:sea_lantern
fill 65 233 581 67 233 583 minecraft:cobbled_deepslate
fill 65 233 584 68 233 584 minecraft:sea_lantern
fill 65 233 587 66 233 588 minecraft:diamond_block
fill 65 233 589 73 233 589 minecraft:cobbled_deepslate
fill 66 233 570 68 233 570 minecraft:diamond_block
setblock 66 233 571 minecraft:light_blue_stained_glass
fill 66 233 577 67 233 577 minecraft:sea_lantern
fill 66 233 579 67 233 579 minecraft:sea_lantern
setblock 66 233 585 minecraft:light_blue_stained_glass
fill 66 233 586 68 233 586 minecraft:diamond_block
fill 67 233 568 71 233 568 minecraft:cobbled_deepslate
setblock 67 233 569 minecraft:diamond_block
fill 67 233 571 68 233 571 minecraft:diamond_block
fill 67 233 585 68 233 585 minecraft:diamond_block
setblock 67 233 587 minecraft:diamond_block
fill 67 233 588 71 233 588 minecraft:cobbled_deepslate
fill 68 233 569 70 233 569 minecraft:cobbled_deepslate
fill 68 233 573 68 233 575 minecraft:sea_lantern
fill 68 233 581 68 233 583 minecraft:sea_lantern
fill 68 233 587 70 233 587 minecraft:cobbled_deepslate
fill 69 233 570 69 233 571 minecraft:cobbled_deepslate
fill 69 233 572 69 233 573 minecraft:diamond_block
fill 69 233 574 70 233 575 minecraft:sea_lantern
fill 69 233 581 69 233 582 minecraft:sea_lantern
fill 69 233 583 69 233 584 minecraft:diamond_block
fill 69 233 585 69 233 586 minecraft:cobbled_deepslate
fill 70 233 570 71 233 571 minecraft:diamond_block
fill 70 233 572 70 233 573 minecraft:sea_lantern
fill 70 233 581 71 233 581 minecraft:sea_lantern
fill 70 233 582 70 233 584 minecraft:light_blue_stained_glass
fill 70 233 585 71 233 586 minecraft:diamond_block
fill 71 233 572 74 233 572 minecraft:sea_lantern
fill 71 233 573 73 233 575 minecraft:cobbled_deepslate
fill 71 233 577 72 233 579 minecraft:sea_lantern
fill 71 233 582 71 233 583 minecraft:sea_lantern
fill 71 233 584 74 233 584 minecraft:light_blue_stained_glass
setblock 72 233 570 minecraft:diamond_block
fill 72 233 571 74 233 571 minecraft:light_blue_stained_glass
fill 72 233 580 74 233 582 minecraft:cobbled_deepslate
fill 72 233 583 75 233 583 minecraft:sea_lantern
fill 72 233 585 74 233 585 minecraft:light_blue_stained_glass
setblock 72 233 586 minecraft:diamond_block
fill 73 233 570 74 233 570 minecraft:light_blue_stained_glass
fill 73 233 577 77 233 577 minecraft:light_blue_stained_glass
fill 73 233 578 73 233 579 minecraft:sea_lantern
fill 73 233 586 74 233 586 minecraft:light_blue_stained_glass
fill 74 233 573 74 233 575 minecraft:sea_lantern
fill 74 233 578 78 233 578 minecraft:light_blue_stained_glass
fill 74 233 579 75 233 579 minecraft:sea_lantern
fill 75 233 570 75 233 575 minecraft:diamond_block
setblock 75 233 576 minecraft:light_blue_stained_glass
fill 75 233 580 75 233 582 minecraft:sea_lantern
fill 75 233 584 75 233 586 minecraft:diamond_block
fill 76 233 570 76 233 571 minecraft:diamond_block
fill 76 233 572 88 233 574 minecraft:cobbled_deepslate
fill 76 233 576 80 233 576 minecraft:diamond_block
fill 76 233 579 77 233 579 minecraft:light_blue_stained_glass
fill 76 233 582 88 233 584 minecraft:cobbled_deepslate
fill 76 233 585 76 233 586 minecraft:diamond_block
fill 77 233 566 88 233 571 minecraft:cobbled_deepslate
fill 77 233 585 88 233 590 minecraft:cobbled_deepslate
fill 78 233 575 88 233 575 minecraft:cobbled_deepslate
fill 78 233 577 81 233 577 minecraft:diamond_block
fill 78 233 579 81 233 579 minecraft:diamond_block
fill 78 233 581 88 233 581 minecraft:cobbled_deepslate
fill 79 233 578 81 233 578 minecraft:diamond_block
fill 81 233 576 88 233 576 minecraft:cobbled_deepslate
fill 81 233 580 88 233 580 minecraft:cobbled_deepslate
fill 82 233 577 88 233 577 minecraft:cobbled_deepslate
fill 82 233 579 88 233 579 minecraft:cobbled_deepslate
fill 84 233 578 88 233 578 minecraft:cobbled_deepslate
setblock 50 236 560 minecraft:light[level=14]
setblock 50 236 568 minecraft:light[level=14]
setblock 50 236 576 minecraft:light[level=14]
setblock 50 236 584 minecraft:light[level=14]
setblock 50 236 592 minecraft:light[level=14]
setblock 58 236 560 minecraft:light[level=14]
setblock 58 236 568 minecraft:light[level=14]
setblock 58 236 576 minecraft:light[level=14]
setblock 58 236 584 minecraft:light[level=14]
setblock 58 236 592 minecraft:light[level=14]
setblock 66 236 560 minecraft:light[level=14]
setblock 66 236 568 minecraft:light[level=14]
setblock 66 236 576 minecraft:light[level=14]
setblock 66 236 584 minecraft:light[level=14]
setblock 66 236 592 minecraft:light[level=14]
setblock 74 236 560 minecraft:light[level=14]
setblock 74 236 568 minecraft:light[level=14]
setblock 74 236 576 minecraft:light[level=14]
setblock 74 236 584 minecraft:light[level=14]
setblock 74 236 592 minecraft:light[level=14]
setblock 82 236 560 minecraft:light[level=14]
setblock 82 236 568 minecraft:light[level=14]
setblock 82 236 576 minecraft:light[level=14]
setblock 82 236 584 minecraft:light[level=14]
setblock 82 236 592 minecraft:light[level=14]
fill 48 237 561 48 237 562 minecraft:cobbled_deepslate
setblock 48 237 563 minecraft:calcite
fill 48 237 564 48 237 567 minecraft:cobbled_deepslate
setblock 48 237 568 minecraft:calcite
fill 48 237 569 48 237 572 minecraft:cobbled_deepslate
setblock 48 237 573 minecraft:calcite
fill 48 237 574 48 240 574 minecraft:cobbled_deepslate
fill 49 237 563 49 237 566 minecraft:cobbled_deepslate
setblock 49 237 567 minecraft:calcite
fill 49 237 568 49 237 571 minecraft:cobbled_deepslate
setblock 50 237 565 minecraft:cobbled_deepslate
setblock 50 237 566 minecraft:calcite
fill 50 237 567 50 238 569 minecraft:cobbled_deepslate
fill 51 237 558 52 237 558 minecraft:cobbled_deepslate
setblock 53 237 558 minecraft:calcite
fill 53 237 559 56 237 559 minecraft:cobbled_deepslate
setblock 53 237 598 minecraft:calcite
fill 54 237 558 57 237 558 minecraft:cobbled_deepslate
fill 54 237 598 57 237 598 minecraft:cobbled_deepslate
setblock 55 237 560 minecraft:cobbled_deepslate
setblock 56 237 560 minecraft:calcite
fill 56 237 597 58 237 597 minecraft:cobbled_deepslate
setblock 57 237 559 minecraft:calcite
fill 57 237 560 58 238 560 minecraft:cobbled_deepslate
setblock 58 237 558 minecraft:calcite
fill 58 237 559 61 237 559 minecraft:cobbled_deepslate
setblock 58 237 598 minecraft:calcite
fill 59 237 558 62 237 558 minecraft:cobbled_deepslate
setblock 59 237 597 minecraft:calcite
fill 59 237 598 62 237 598 minecraft:cobbled_deepslate
fill 60 237 597 61 239 597 minecraft:cobbled_deepslate
setblock 63 237 558 minecraft:calcite
setblock 63 237 598 minecraft:calcite
fill 64 237 598 64 240 598 minecraft:cobbled_deepslate
fill 70 237 598 72 237 598 minecraft:cobbled_deepslate
setblock 73 237 597 minecraft:cobbled_deepslate
setblock 73 237 598 minecraft:calcite
setblock 74 237 597 minecraft:calcite
fill 74 237 598 77 237 598 minecraft:cobbled_deepslate
fill 75 237 597 78 237 597 minecraft:cobbled_deepslate
setblock 78 237 598 minecraft:calcite
fill 79 237 598 80 239 598 minecraft:cobbled_deepslate
fill 87 237 567 87 237 568 minecraft:cobbled_deepslate
setblock 87 237 569 minecraft:calcite
fill 87 237 570 88 239 570 minecraft:cobbled_deepslate
fill 88 237 564 88 237 567 minecraft:cobbled_deepslate
setblock 88 237 568 minecraft:calcite
fill 88 237 569 88 240 569 minecraft:cobbled_deepslate
fill 88 237 571 88 237 572 minecraft:cobbled_deepslate
setblock 88 237 573 minecraft:calcite
fill 88 237 574 88 239 575 minecraft:cobbled_deepslate
setblock 88 237 583 minecraft:calcite
fill 88 237 584 88 237 587 minecraft:cobbled_deepslate
setblock 88 237 588 minecraft:calcite
fill 88 237 589 88 238 591 minecraft:cobbled_deepslate
setblock 48 238 561 minecraft:cobbled_deepslate
setblock 48 238 562 minecraft:calcite
fill 48 238 563 48 238 566 minecraft:cobbled_deepslate
setblock 48 238 567 minecraft:calcite
fill 48 238 568 48 238 571 minecraft:cobbled_deepslate
setblock 48 238 572 minecraft:calcite
fill 48 238 573 48 241 573 minecraft:cobbled_deepslate
fill 48 238 575 48 239 575 minecraft:cobbled_deepslate
fill 49 238 563 49 238 565 minecraft:cobbled_deepslate
setblock 49 238 566 minecraft:calcite
fill 49 238 567 49 238 570 minecraft:cobbled_deepslate
setblock 49 238 571 minecraft:calcite
fill 49 238 572 49 241 572 minecraft:cobbled_deepslate
fill 50 238 558 51 238 558 minecraft:cobbled_deepslate
setblock 50 238 565 minecraft:calcite
fill 50 238 566 50 241 566 minecraft:cobbled_deepslate
setblock 50 238 570 minecraft:calcite
setblock 52 238 558 minecraft:calcite
fill 52 238 559 55 238 559 minecraft:cobbled_deepslate
setblock 52 238 598 minecraft:calcite
fill 53 238 558 56 238 558 minecraft:cobbled_deepslate
fill 53 238 598 56 238 598 minecraft:cobbled_deepslate
setblock 54 238 560 minecraft:cobbled_deepslate
fill 54 238 597 57 238 597 minecraft:cobbled_deepslate
setblock 55 238 560 minecraft:calcite
setblock 56 238 559 minecraft:calcite
fill 56 238 560 56 241 560 minecraft:cobbled_deepslate
setblock 57 238 558 minecraft:calcite
fill 57 238 559 60 238 559 minecraft:cobbled_deepslate
fill 57 238 596 58 238 596 minecraft:cobbled_deepslate
setblock 57 238 598 minecraft:calcite
fill 58 238 558 61 238 558 minecraft:cobbled_deepslate
setblock 58 238 597 minecraft:calcite
fill 58 238 598 61 238 598 minecraft:cobbled_deepslate
fill 59 238 597 59 241 597 minecraft:cobbled_deepslate
setblock 62 238 558 minecraft:calcite
setblock 62 238 597 minecraft:cobbled_deepslate
setblock 62 238 598 minecraft:calcite
setblock 63 238 558 minecraft:cobbled_deepslate
fill 63 238 598 63 241 598 minecraft:cobbled_deepslate
fill 65 238 598 66 238 598 minecraft:cobbled_deepslate
setblock 67 238 598 minecraft:calcite
fill 68 238 598 71 238 598 minecraft:cobbled_deepslate
fill 71 238 597 72 238 597 minecraft:cobbled_deepslate
setblock 72 238 598 minecraft:calcite
setblock 73 238 597 minecraft:calcite
fill 73 238 598 76 238 598 minecraft:cobbled_deepslate
setblock 74 238 596 minecraft:calcite
fill 74 238 597 77 238 597 minecraft:cobbled_deepslate
fill 75 238 596 77 239 596 minecraft:cobbled_deepslate
setblock 76 238 558 minecraft:cobbled_deepslate
setblock 77 238 598 minecraft:calcite
setblock 78 238 597 minecraft:calcite
fill 78 238 598 78 241 598 minecraft:cobbled_deepslate
fill 79 238 597 79 241 597 minecraft:cobbled_deepslate
fill 87 238 566 87 238 567 minecraft:cobbled_deepslate
setblock 87 238 568 minecraft:calcite
fill 87 238 569 87 241 569 minecraft:cobbled_deepslate
fill 87 238 571 87 238 572 minecraft:cobbled_deepslate
setblock 87 238 573 minecraft:calcite
fill 88 238 563 88 238 566 minecraft:cobbled_deepslate
setblock 88 238 567 minecraft:calcite
fill 88 238 568 88 241 568 minecraft:cobbled_deepslate
setblock 88 238 571 minecraft:cobbled_deepslate
setblock 88 238 572 minecraft:calcite
fill 88 238 573 88 241 573 minecraft:cobbled_deepslate
setblock 88 238 576 minecraft:cobbled_deepslate
setblock 88 238 577 minecraft:calcite
fill 88 238 583 88 238 586 minecraft:cobbled_deepslate
setblock 88 238 587 minecraft:calcite
fill 88 238 588 88 241 588 minecraft:cobbled_deepslate
setblock 88 238 592 minecraft:calcite
setblock 48 239 560 minecraft:cobbled_deepslate
setblock 48 239 561 minecraft:calcite
fill 48 239 562 48 239 565 minecraft:cobbled_deepslate
setblock 48 239 566 minecraft:calcite
fill 48 239 567 48 239 570 minecraft:cobbled_deepslate
setblock 48 239 571 minecraft:calcite
fill 48 239 572 48 242 572 minecraft:cobbled_deepslate
fill 48 239 588 48 239 590 minecraft:cobbled_deepslate
setblock 48 239 591 minecraft:calcite
fill 48 239 592 48 241 593 minecraft:cobbled_deepslate
fill 49 239 558 50 239 558 minecraft:cobbled_deepslate
fill 49 239 562 49 239 564 minecraft:cobbled_deepslate
setblock 49 239 565 minecraft:calcite
fill 49 239 566 49 239 569 minecraft:cobbled_deepslate
setblock 49 239 570 minecraft:calcite
fill 49 239 571 50 241 571 minecraft:cobbled_deepslate
fill 49 239 573 49 240 573 minecraft:cobbled_deepslate
setblock 50 239 564 minecraft:calcite
fill 50 239 565 50 242 565 minecraft:cobbled_deepslate
fill 50 239 567 50 239 568 minecraft:cobbled_deepslate
setblock 50 239 569 minecraft:calcite
fill 50 239 570 50 242 570 minecraft:cobbled_deepslate
fill 50 239 572 50 240 572 minecraft:cobbled_deepslate
setblock 51 239 558 minecraft:calcite
fill 51 239 559 54 239 559 minecraft:cobbled_deepslate
setblock 51 239 567 minecraft:cobbled_deepslate
setblock 51 239 568 minecraft:calcite
fill 51 239 569 51 242 569 minecraft:cobbled_deepslate
setblock 51 239 598 minecraft:calcite
fill 52 239 558 55 239 558 minecraft:cobbled_deepslate
setblock 52 239 597 minecraft:calcite
fill 52 239 598 55 239 598 minecraft:cobbled_deepslate
fill 53 239 597 56 239 597 minecraft:cobbled_deepslate
setblock 54 239 560 minecraft:calcite
setblock 55 239 559 minecraft:calcite
fill 55 239 560 55 241 560 minecraft:cobbled_deepslate
fill 55 239 596 57 239 596 minecraft:cobbled_deepslate
setblock 56 239 558 minecraft:calcite
fill 56 239 559 59 239 559 minecraft:cobbled_deepslate
setblock 56 239 598 minecraft:calcite
fill 57 239 558 60 239 558 minecraft:cobbled_deepslate
fill 57 239 560 57 240 560 minecraft:cobbled_deepslate
setblock 57 239 597 minecraft:calcite
fill 57 239 598 60 239 598 minecraft:cobbled_deepslate
setblock 58 239 596 minecraft:calcite
fill 58 239 597 58 242 597 minecraft:cobbled_deepslate
fill 59 239 596 60 241 596 minecraft:cobbled_deepslate
setblock 60 239 559 minecraft:calcite
setblock 61 239 558 minecraft:calcite
setblock 61 239 598 minecraft:calcite
fill 62 239 558 62 241 558 minecraft:cobbled_deepslate
setblock 62 239 597 minecraft:calcite
fill 62 239 598 62 242 598 minecraft:cobbled_deepslate
fill 63 239 597 63 242 597 minecraft:cobbled_deepslate
setblock 65 239 598 minecraft:cobbled_deepslate
setblock 66 239 598 minecraft:calcite
fill 67 239 598 70 239 598 minecraft:cobbled_deepslate
fill 69 239 597 71 239 597 minecraft:cobbled_deepslate
setblock 71 239 598 minecraft:calcite
setblock 72 239 596 minecraft:cobbled_deepslate
setblock 72 239 597 minecraft:calcite
fill 72 239 598 75 239 598 minecraft:cobbled_deepslate
setblock 73 239 596 minecraft:calcite
fill 73 239 597 76 239 597 minecraft:cobbled_deepslate
fill 74 239 558 75 239 558 minecraft:cobbled_deepslate
fill 74 239 596 74 242 596 minecraft:cobbled_deepslate
setblock 76 239 558 minecraft:calcite
setblock 76 239 598 minecraft:calcite
fill 77 239 558 77 240 558 minecraft:cobbled_deepslate
setblock 77 239 597 minecraft:calcite
fill 77 239 598 77 242 598 minecraft:cobbled_deepslate
fill 78 239 597 78 242 597 minecraft:cobbled_deepslate
setblock 87 239 566 minecraft:cobbled_deepslate
setblock 87 239 567 minecraft:calcite
fill 87 239 568 87 242 568 minecraft:cobbled_deepslate
setblock 87 239 571 minecraft:cobbled_deepslate
setblock 87 239 572 minecraft:calcite
fill 87 239 573 87 241 574 minecraft:cobbled_deepslate
fill 88 239 563 88 239 565 minecraft:cobbled_deepslate
setblock 88 239 566 minecraft:calcite
fill 88 239 567 88 242 567 minecraft:cobbled_deepslate
setblock 88 239 571 minecraft:calcite
fill 88 239 572 88 242 572 minecraft:cobbled_deepslate
setblock 88 239 576 minecraft:calcite
fill 88 239 577 88 241 578 minecraft:cobbled_deepslate
fill 88 239 584 88 239 585 minecraft:cobbled_deepslate
setblock 88 239 586 minecraft:calcite
fill 88 239 587 88 241 587 minecraft:cobbled_deepslate
fill 88 239 589 88 239 590 minecraft:cobbled_deepslate
setblock 88 239 591 minecraft:calcite
fill 88 239 592 88 241 593 minecraft:cobbled_deepslate
fill 48 240 558 48 240 559 minecraft:cobbled_deepslate
setblock 48 240 560 minecraft:calcite
fill 48 240 561 48 240 564 minecraft:cobbled_deepslate
setblock 48 240 565 minecraft:calcite
fill 48 240 566 48 240 569 minecraft:cobbled_deepslate
setblock 48 240 570 minecraft:calcite
fill 48 240 571 48 243 571 minecraft:cobbled_deepslate
setblock 48 240 575 minecraft:calcite
fill 48 240 576 48 243 576 minecraft:cobbled_deepslate
fill 48 240 588 48 240 589 minecraft:cobbled_deepslate
setblock 48 240 590 minecraft:calcite
fill 48 240 591 48 243 591 minecraft:cobbled_deepslate
setblock 48 240 594 minecraft:cobbled_deepslate
setblock 48 240 595 minecraft:calcite
setblock 49 240 558 minecraft:cobbled_deepslate
fill 49 240 562 49 240 563 minecraft:cobbled_deepslate
setblock 49 240 564 minecraft:calcite
fill 49 240 565 49 240 568 minecraft:cobbled_deepslate
setblock 49 240 569 minecraft:calcite
fill 49 240 570 49 243 570 minecraft:cobbled_deepslate
setblock 49 240 574 minecraft:calcite
setblock 50 240 558 minecraft:calcite
fill 50 240 564 50 241 564 minecraft:cobbled_deepslate
setblock 50 240 567 minecraft:cobbled_deepslate
setblock 50 240 568 minecraft:calcite
fill 50 240 569 50 243 569 minecraft:cobbled_deepslate
setblock 50 240 598 minecraft:calcite
fill 51 240 558 53 240 559 minecraft:cobbled_deepslate
setblock 51 240 567 minecraft:calcite
fill 51 240 568 51 241 568 minecraft:cobbled_deepslate
fill 51 240 570 51 241 570 minecraft:cobbled_deepslate
setblock 51 240 597 minecraft:calcite
fill 51 240 598 54 240 598 minecraft:cobbled_deepslate
fill 52 240 597 55 240 597 minecraft:cobbled_deepslate
setblock 53 240 560 minecraft:calcite
fill 53 240 596 56 240 596 minecraft:cobbled_deepslate
setblock 54 240 558 minecraft:cobbled_deepslate
setblock 54 240 559 minecraft:calcite
fill 54 240 560 54 242 560 minecraft:cobbled_deepslate
setblock 55 240 558 minecraft:calcite
fill 55 240 559 58 240 559 minecraft:cobbled_deepslate
setblock 55 240 598 minecraft:calcite
fill 56 240 558 59 240 558 minecraft:cobbled_deepslate
setblock 56 240 597 minecraft:calcite
fill 56 240 598 59 240 598 minecraft:cobbled_deepslate
setblock 57 240 596 minecraft:calcite
fill 57 240 597 57 243 597 minecraft:cobbled_deepslate
fill 58 240 596 58 243 596 minecraft:cobbled_deepslate
setblock 59 240 559 minecraft:calcite
setblock 60 240 558 minecraft:calcite
setblock 60 240 597 minecraft:cobbled_deepslate
setblock 60 240 598 minecraft:calcite
fill 61 240 558 61 242 558 minecraft:cobbled_deepslate
setblock 61 240 596 minecraft:cobbled_deepslate
setblock 61 240 597 minecraft:calcite
fill 61 240 598 61 243 598 minecraft:cobbled_deepslate
fill 62 240 597 62 243 597 minecraft:cobbled_deepslate
fill 64 240 597 65 240 597 minecraft:cobbled_deepslate
setblock 65 240 598 minecraft:calcite
setblock 66 240 597 minecraft:calcite
fill 66 240 598 69 240 598 minecraft:cobbled_deepslate
fill 67 240 597 70 240 597 minecraft:cobbled_deepslate
fill 70 240 596 71 240 596 minecraft:cobbled_deepslate
setblock 70 240 598 minecraft:calcite
setblock 71 240 597 minecraft:calcite
fill 71 240 598 74 240 598 minecraft:cobbled_deepslate
setblock 72 240 596 minecraft:calcite
fill 72 240 597 75 240 597 minecraft:cobbled_deepslate
fill 73 240 558 74 240 558 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_8 1t
