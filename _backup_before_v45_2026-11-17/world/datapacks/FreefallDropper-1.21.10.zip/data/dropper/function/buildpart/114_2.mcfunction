setblock 291 181 504 minecraft:shroomlight
setblock 292 181 495 minecraft:shroomlight
setblock 292 181 497 minecraft:shroomlight
setblock 292 181 499 minecraft:shroomlight
setblock 292 181 501 minecraft:shroomlight
setblock 292 181 503 minecraft:shroomlight
setblock 293 181 496 minecraft:shroomlight
setblock 293 181 498 minecraft:shroomlight
setblock 293 181 500 minecraft:shroomlight
setblock 293 181 502 minecraft:shroomlight
setblock 293 181 504 minecraft:shroomlight
setblock 294 181 495 minecraft:shroomlight
setblock 294 181 497 minecraft:shroomlight
setblock 294 181 499 minecraft:shroomlight
setblock 294 181 501 minecraft:shroomlight
setblock 294 181 503 minecraft:shroomlight
setblock 295 181 496 minecraft:shroomlight
setblock 295 181 498 minecraft:shroomlight
setblock 295 181 500 minecraft:shroomlight
setblock 295 181 502 minecraft:shroomlight
setblock 295 181 504 minecraft:shroomlight
fill 289 182 496 289 183 496 minecraft:polished_blackstone_bricks
fill 289 182 498 289 183 498 minecraft:polished_blackstone_bricks
fill 289 182 500 289 183 500 minecraft:polished_blackstone_bricks
fill 289 182 502 289 183 502 minecraft:polished_blackstone_bricks
fill 289 182 504 289 183 504 minecraft:polished_blackstone_bricks
fill 290 182 495 290 183 495 minecraft:polished_blackstone_bricks
fill 290 182 497 290 183 497 minecraft:polished_blackstone_bricks
fill 290 182 499 290 183 499 minecraft:polished_blackstone_bricks
fill 290 182 501 290 183 501 minecraft:polished_blackstone_bricks
fill 290 182 503 290 183 503 minecraft:polished_blackstone_bricks
fill 291 182 496 291 183 496 minecraft:polished_blackstone_bricks
fill 291 182 498 291 183 498 minecraft:polished_blackstone_bricks
fill 291 182 500 291 183 500 minecraft:polished_blackstone_bricks
fill 291 182 502 291 183 502 minecraft:polished_blackstone_bricks
fill 291 182 504 291 183 504 minecraft:polished_blackstone_bricks
fill 292 182 495 292 183 495 minecraft:polished_blackstone_bricks
fill 292 182 497 292 183 497 minecraft:polished_blackstone_bricks
fill 292 182 499 292 183 499 minecraft:polished_blackstone_bricks
fill 292 182 501 292 183 501 minecraft:polished_blackstone_bricks
fill 292 182 503 292 183 503 minecraft:polished_blackstone_bricks
fill 293 182 496 293 183 496 minecraft:polished_blackstone_bricks
fill 293 182 498 293 183 498 minecraft:polished_blackstone_bricks
fill 293 182 500 293 183 500 minecraft:polished_blackstone_bricks
fill 293 182 502 293 183 502 minecraft:polished_blackstone_bricks
fill 293 182 504 293 183 504 minecraft:polished_blackstone_bricks
fill 294 182 495 294 183 495 minecraft:polished_blackstone_bricks
fill 294 182 497 294 183 497 minecraft:polished_blackstone_bricks
fill 294 182 499 294 183 499 minecraft:polished_blackstone_bricks
fill 294 182 501 294 183 501 minecraft:polished_blackstone_bricks
fill 294 182 503 294 183 503 minecraft:polished_blackstone_bricks
fill 295 182 496 295 183 496 minecraft:polished_blackstone_bricks
fill 295 182 498 295 183 498 minecraft:polished_blackstone_bricks
fill 295 182 500 295 183 500 minecraft:polished_blackstone_bricks
fill 295 182 502 295 183 502 minecraft:polished_blackstone_bricks
fill 295 182 504 295 183 504 minecraft:polished_blackstone_bricks
setblock 285 183 466 minecraft:light[level=14]
setblock 285 183 474 minecraft:light[level=14]
setblock 285 183 482 minecraft:light[level=14]
setblock 285 183 490 minecraft:light[level=14]
setblock 285 183 498 minecraft:light[level=14]
setblock 293 183 466 minecraft:light[level=14]
setblock 293 183 474 minecraft:light[level=14]
setblock 293 183 482 minecraft:light[level=14]
setblock 293 183 490 minecraft:light[level=14]
setblock 301 183 466 minecraft:light[level=14]
setblock 301 183 474 minecraft:light[level=14]
setblock 301 183 482 minecraft:light[level=14]
setblock 301 183 490 minecraft:light[level=14]
setblock 301 183 498 minecraft:light[level=14]
setblock 309 183 466 minecraft:light[level=14]
setblock 309 183 474 minecraft:light[level=14]
setblock 309 183 482 minecraft:light[level=14]
setblock 309 183 490 minecraft:light[level=14]
setblock 309 183 498 minecraft:light[level=14]
setblock 317 183 466 minecraft:light[level=14]
setblock 317 183 474 minecraft:light[level=14]
setblock 317 183 482 minecraft:light[level=14]
setblock 317 183 490 minecraft:light[level=14]
setblock 317 183 498 minecraft:light[level=14]
setblock 289 184 496 minecraft:shroomlight
setblock 289 184 498 minecraft:shroomlight
setblock 289 184 500 minecraft:shroomlight
setblock 289 184 502 minecraft:shroomlight
setblock 289 184 504 minecraft:shroomlight
setblock 290 184 495 minecraft:shroomlight
setblock 290 184 497 minecraft:shroomlight
setblock 290 184 499 minecraft:shroomlight
setblock 290 184 501 minecraft:shroomlight
setblock 290 184 503 minecraft:shroomlight
setblock 291 184 496 minecraft:shroomlight
setblock 291 184 498 minecraft:shroomlight
setblock 291 184 500 minecraft:shroomlight
setblock 291 184 502 minecraft:shroomlight
setblock 291 184 504 minecraft:shroomlight
setblock 292 184 495 minecraft:shroomlight
setblock 292 184 497 minecraft:shroomlight
setblock 292 184 499 minecraft:shroomlight
setblock 292 184 501 minecraft:shroomlight
setblock 292 184 503 minecraft:shroomlight
setblock 293 184 496 minecraft:shroomlight
setblock 293 184 498 minecraft:shroomlight
setblock 293 184 500 minecraft:shroomlight
setblock 293 184 502 minecraft:shroomlight
setblock 293 184 504 minecraft:shroomlight
setblock 294 184 495 minecraft:shroomlight
setblock 294 184 497 minecraft:shroomlight
setblock 294 184 499 minecraft:shroomlight
setblock 294 184 501 minecraft:shroomlight
setblock 294 184 503 minecraft:shroomlight
setblock 295 184 496 minecraft:shroomlight
setblock 295 184 498 minecraft:shroomlight
setblock 295 184 500 minecraft:shroomlight
setblock 295 184 502 minecraft:shroomlight
setblock 295 184 504 minecraft:shroomlight
fill 321 184 489 321 185 495 minecraft:gilded_blackstone
fill 283 185 467 283 185 472 minecraft:nether_bricks
fill 283 185 479 283 185 484 minecraft:nether_bricks
fill 283 185 491 283 185 496 minecraft:nether_bricks
fill 283 185 503 283 185 504 minecraft:nether_bricks
fill 284 185 504 287 185 504 minecraft:nether_bricks
fill 287 185 464 292 185 464 minecraft:nether_bricks
fill 289 185 496 289 187 496 minecraft:polished_blackstone_bricks
fill 289 185 498 289 187 498 minecraft:polished_blackstone_bricks
fill 289 185 500 289 187 500 minecraft:polished_blackstone_bricks
fill 289 185 502 289 187 502 minecraft:polished_blackstone_bricks
fill 289 185 504 289 222 504 minecraft:polished_blackstone_bricks
fill 290 185 495 290 187 495 minecraft:polished_blackstone_bricks
fill 290 185 497 290 187 497 minecraft:polished_blackstone_bricks
fill 290 185 499 290 187 499 minecraft:polished_blackstone_bricks
fill 290 185 501 290 187 501 minecraft:polished_blackstone_bricks
fill 290 185 503 290 187 503 minecraft:polished_blackstone_bricks
fill 291 185 496 291 187 496 minecraft:polished_blackstone_bricks
fill 291 185 498 291 187 498 minecraft:polished_blackstone_bricks
fill 291 185 500 291 187 500 minecraft:polished_blackstone_bricks
fill 291 185 502 291 187 502 minecraft:polished_blackstone_bricks
fill 291 185 504 291 222 504 minecraft:polished_blackstone_bricks
fill 292 185 495 292 187 495 minecraft:polished_blackstone_bricks
fill 292 185 497 292 187 497 minecraft:polished_blackstone_bricks
fill 292 185 499 292 187 499 minecraft:polished_blackstone_bricks
fill 292 185 501 292 187 501 minecraft:polished_blackstone_bricks
fill 292 185 503 292 187 503 minecraft:polished_blackstone_bricks
fill 293 185 496 293 187 496 minecraft:polished_blackstone_bricks
fill 293 185 498 293 187 498 minecraft:polished_blackstone_bricks
fill 293 185 500 293 187 500 minecraft:polished_blackstone_bricks
fill 293 185 502 293 187 502 minecraft:polished_blackstone_bricks
fill 293 185 504 293 187 504 minecraft:polished_blackstone_bricks
fill 294 185 495 294 187 495 minecraft:polished_blackstone_bricks
fill 294 185 497 294 187 497 minecraft:polished_blackstone_bricks
fill 294 185 499 294 187 499 minecraft:polished_blackstone_bricks
fill 294 185 501 294 187 501 minecraft:polished_blackstone_bricks
fill 294 185 503 294 187 503 minecraft:polished_blackstone_bricks
fill 294 185 504 299 185 504 minecraft:nether_bricks
fill 295 185 496 295 187 496 minecraft:polished_blackstone_bricks
fill 295 185 498 295 187 498 minecraft:polished_blackstone_bricks
fill 295 185 500 295 187 500 minecraft:polished_blackstone_bricks
fill 295 185 502 295 187 502 minecraft:polished_blackstone_bricks
fill 299 185 464 304 185 464 minecraft:nether_bricks
fill 300 185 502 300 203 502 minecraft:gilded_blackstone
fill 306 185 504 311 185 504 minecraft:nether_bricks
fill 311 185 464 316 185 464 minecraft:nether_bricks
fill 318 185 504 323 185 504 minecraft:nether_bricks
fill 321 185 480 321 186 486 minecraft:gilded_blackstone
fill 323 185 464 323 185 469 minecraft:nether_bricks
fill 323 185 476 323 185 481 minecraft:nether_bricks
fill 323 185 488 323 185 493 minecraft:nether_bricks
fill 323 185 500 323 185 503 minecraft:nether_bricks
fill 282 186 469 282 191 472 minecraft:shroomlight
fill 282 186 481 282 191 484 minecraft:shroomlight
fill 282 186 493 282 191 496 minecraft:shroomlight
fill 282 186 505 285 191 505 minecraft:shroomlight
fill 289 186 463 292 191 463 minecraft:shroomlight
fill 294 186 504 295 187 504 minecraft:polished_blackstone_bricks
fill 294 186 505 297 191 505 minecraft:shroomlight
fill 301 186 463 304 191 463 minecraft:shroomlight
fill 306 186 505 309 191 505 minecraft:shroomlight
fill 310 186 502 310 197 502 minecraft:red_wool
fill 313 186 463 316 191 463 minecraft:shroomlight
fill 318 186 505 321 191 505 minecraft:shroomlight
fill 324 186 464 324 191 467 minecraft:shroomlight
fill 324 186 476 324 191 479 minecraft:shroomlight
fill 324 186 488 324 191 491 minecraft:shroomlight
fill 324 186 500 324 191 503 minecraft:shroomlight
fill 308 187 502 309 197 502 minecraft:red_wool
fill 311 187 502 312 197 502 minecraft:red_wool
fill 290 188 496 294 188 503 minecraft:gold_block
fill 291 189 497 293 189 502 minecraft:gold_block
fill 292 190 498 292 190 501 minecraft:gold_block
setblock 285 191 466 minecraft:light[level=14]
setblock 285 191 474 minecraft:light[level=14]
setblock 285 191 482 minecraft:light[level=14]
setblock 285 191 490 minecraft:light[level=14]
setblock 285 191 498 minecraft:light[level=14]
fill 291 191 499 293 191 500 minecraft:gold_block
setblock 293 191 466 minecraft:light[level=14]
setblock 293 191 474 minecraft:light[level=14]
setblock 293 191 482 minecraft:light[level=14]
setblock 293 191 490 minecraft:light[level=14]
setblock 293 191 498 minecraft:light[level=14]
setblock 301 191 466 minecraft:light[level=14]
setblock 301 191 474 minecraft:light[level=14]
setblock 301 191 482 minecraft:light[level=14]
setblock 301 191 490 minecraft:light[level=14]
setblock 301 191 498 minecraft:light[level=14]
setblock 309 191 466 minecraft:light[level=14]
setblock 309 191 474 minecraft:light[level=14]
setblock 309 191 482 minecraft:light[level=14]
setblock 309 191 490 minecraft:light[level=14]
setblock 309 191 498 minecraft:light[level=14]
setblock 317 191 466 minecraft:light[level=14]
setblock 317 191 474 minecraft:light[level=14]
setblock 317 191 482 minecraft:light[level=14]
setblock 317 191 490 minecraft:light[level=14]
setblock 317 191 498 minecraft:light[level=14]
fill 282 192 469 282 204 469 minecraft:nether_bricks
fill 282 192 470 282 192 471 minecraft:shroomlight
fill 282 192 472 282 204 472 minecraft:nether_bricks
fill 282 192 481 282 201 481 minecraft:nether_bricks
fill 282 192 482 282 192 483 minecraft:shroomlight
fill 282 192 484 282 205 484 minecraft:nether_bricks
fill 282 192 493 282 200 493 minecraft:nether_bricks
fill 282 192 494 282 192 495 minecraft:shroomlight
fill 282 192 496 282 204 496 minecraft:nether_bricks
fill 282 192 505 282 204 505 minecraft:nether_bricks
fill 283 192 505 284 192 505 minecraft:shroomlight
fill 285 192 505 285 204 505 minecraft:nether_bricks
fill 289 192 463 289 202 463 minecraft:nether_bricks
fill 290 192 463 291 192 463 minecraft:shroomlight
fill 292 192 463 292 201 463 minecraft:nether_bricks
fill 294 192 505 294 205 505 minecraft:nether_bricks
fill 295 192 505 296 192 505 minecraft:shroomlight
fill 297 192 505 297 204 505 minecraft:nether_bricks
fill 301 192 463 301 204 463 minecraft:nether_bricks
fill 302 192 463 303 192 463 minecraft:shroomlight
fill 304 192 463 304 205 463 minecraft:nether_bricks
fill 306 192 505 306 205 505 minecraft:nether_bricks
fill 307 192 505 308 192 505 minecraft:shroomlight
fill 309 192 505 309 204 505 minecraft:nether_bricks
fill 313 192 463 313 201 463 minecraft:nether_bricks
fill 314 192 463 315 192 463 minecraft:shroomlight
fill 316 192 463 316 200 463 minecraft:nether_bricks
fill 318 192 505 318 204 505 minecraft:nether_bricks
fill 319 192 505 320 192 505 minecraft:shroomlight
fill 321 192 505 321 200 505 minecraft:nether_bricks
fill 324 192 464 324 202 464 minecraft:nether_bricks
fill 324 192 465 324 192 466 minecraft:shroomlight
fill 324 192 467 324 204 467 minecraft:nether_bricks
fill 324 192 476 324 204 476 minecraft:nether_bricks
fill 324 192 477 324 192 478 minecraft:shroomlight
fill 324 192 479 324 204 479 minecraft:nether_bricks
fill 324 192 488 324 202 488 minecraft:nether_bricks
fill 324 192 489 324 192 490 minecraft:shroomlight
fill 324 192 491 324 200 491 minecraft:nether_bricks
fill 324 192 500 324 204 500 minecraft:nether_bricks
fill 324 192 501 324 192 502 minecraft:shroomlight
fill 324 192 503 324 204 503 minecraft:nether_bricks
fill 282 193 470 282 202 471 minecraft:nether_bricks
fill 282 193 482 282 202 483 minecraft:nether_bricks
fill 282 193 494 282 204 495 minecraft:nether_bricks
fill 283 193 505 284 202 505 minecraft:nether_bricks
fill 290 193 463 291 204 463 minecraft:nether_bricks
fill 295 193 505 296 204 505 minecraft:nether_bricks
fill 302 193 463 303 204 463 minecraft:nether_bricks
fill 307 193 505 308 204 505 minecraft:nether_bricks
fill 314 193 463 315 204 463 minecraft:nether_bricks
fill 319 193 505 320 200 505 minecraft:nether_bricks
fill 324 193 465 324 201 466 minecraft:nether_bricks
fill 324 193 477 324 201 478 minecraft:nether_bricks
fill 324 193 489 324 200 490 minecraft:nether_bricks
fill 324 193 501 324 204 502 minecraft:nether_bricks
fill 291 198 466 295 199 470 minecraft:nether_bricks
fill 293 198 464 293 198 465 minecraft:nether_bricks
fill 307 198 502 313 199 502 minecraft:gilded_blackstone
setblock 285 199 466 minecraft:light[level=14]
setblock 285 199 474 minecraft:light[level=14]
setblock 285 199 482 minecraft:light[level=14]
setblock 285 199 490 minecraft:light[level=14]
setblock 285 199 498 minecraft:light[level=14]
setblock 293 199 474 minecraft:light[level=14]
setblock 293 199 482 minecraft:light[level=14]
setblock 293 199 490 minecraft:light[level=14]
setblock 293 199 498 minecraft:light[level=14]
setblock 301 199 466 minecraft:light[level=14]
setblock 301 199 474 minecraft:light[level=14]
setblock 301 199 490 minecraft:light[level=14]
setblock 301 199 498 minecraft:light[level=14]
setblock 309 199 466 minecraft:light[level=14]
setblock 309 199 474 minecraft:light[level=14]
setblock 309 199 482 minecraft:light[level=14]
setblock 309 199 490 minecraft:light[level=14]
setblock 309 199 498 minecraft:light[level=14]
setblock 317 199 466 minecraft:light[level=14]
setblock 317 199 474 minecraft:light[level=14]
setblock 317 199 482 minecraft:light[level=14]
setblock 317 199 490 minecraft:light[level=14]
setblock 317 199 498 minecraft:light[level=14]
fill 284 200 473 284 205 475 minecraft:polished_blackstone_bricks
fill 284 200 485 284 205 487 minecraft:polished_blackstone_bricks
fill 284 200 497 284 205 499 minecraft:polished_blackstone_bricks
fill 290 200 503 292 205 503 minecraft:polished_blackstone_bricks
fill 293 200 468 293 205 468 minecraft:bone_block
fill 294 200 465 296 205 465 minecraft:polished_blackstone_bricks
fill 302 200 503 304 205 503 minecraft:polished_blackstone_bricks
fill 306 200 465 308 205 465 minecraft:polished_blackstone_bricks
fill 314 200 503 316 205 503 minecraft:polished_blackstone_bricks
fill 318 200 465 320 205 465 minecraft:polished_blackstone_bricks
fill 322 200 473 322 205 475 minecraft:polished_blackstone_bricks
fill 322 200 485 322 205 487 minecraft:polished_blackstone_bricks
fill 322 200 497 322 205 499 minecraft:polished_blackstone_bricks
fill 282 201 463 282 204 464 minecraft:nether_bricks
setblock 282 201 465 minecraft:red_nether_bricks
fill 282 201 466 282 201 468 minecraft:nether_bricks
fill 282 201 473 282 204 474 minecraft:nether_bricks
fill 282 201 475 282 202 475 minecraft:red_nether_bricks
setblock 282 201 476 minecraft:nether_bricks
setblock 282 201 488 minecraft:red_nether_bricks
setblock 282 201 489 minecraft:nether_bricks
fill 282 201 490 282 201 491 minecraft:red_nether_bricks
fill 282 201 492 282 204 492 minecraft:nether_bricks
setblock 282 201 493 minecraft:red_nether_bricks
fill 282 201 503 282 204 503 minecraft:nether_bricks
setblock 282 201 504 minecraft:red_nether_bricks
fill 288 201 505 288 202 505 minecraft:red_nether_bricks
fill 291 201 467 292 204 469 minecraft:bone_block
fill 292 201 466 294 204 466 minecraft:bone_block
fill 292 201 470 294 204 470 minecraft:bone_block
fill 293 201 467 295 204 467 minecraft:bone_block
fill 293 201 469 295 204 469 minecraft:bone_block
fill 294 201 468 295 204 468 minecraft:bone_block
setblock 316 201 463 minecraft:red_nether_bricks
setblock 319 201 463 minecraft:red_nether_bricks
fill 319 201 505 319 204 505 minecraft:nether_bricks
fill 320 201 505 321 201 505 minecraft:red_nether_bricks
setblock 324 201 489 minecraft:red_nether_bricks
fill 324 201 490 324 204 490 minecraft:nether_bricks
setblock 324 201 491 minecraft:red_nether_bricks
fill 282 202 465 282 204 466 minecraft:nether_bricks
fill 282 202 467 282 203 467 minecraft:red_nether_bricks
fill 282 202 468 282 204 468 minecraft:nether_bricks
setblock 282 202 476 minecraft:red_nether_bricks
setblock 282 202 481 minecraft:red_nether_bricks
fill 282 202 488 282 205 488 minecraft:nether_bricks
setblock 282 202 489 minecraft:red_nether_bricks
fill 282 202 490 282 204 491 minecraft:nether_bricks
fill 282 202 493 282 204 493 minecraft:nether_bricks
fill 282 202 504 282 205 504 minecraft:nether_bricks
fill 287 202 463 287 204 463 minecraft:nether_bricks
fill 287 202 505 287 203 505 minecraft:red_nether_bricks
setblock 288 202 463 minecraft:red_nether_bricks
setblock 292 202 463 minecraft:red_nether_bricks
fill 302 202 505 302 204 505 minecraft:nether_bricks
setblock 303 202 505 minecraft:red_nether_bricks
setblock 304 202 505 minecraft:nether_bricks
setblock 311 202 463 minecraft:nether_bricks
fill 312 202 463 313 202 463 minecraft:red_nether_bricks
fill 316 202 463 316 204 463 minecraft:nether_bricks
setblock 317 202 505 minecraft:red_nether_bricks
fill 319 202 463 319 204 463 minecraft:nether_bricks
fill 320 202 505 321 202 505 minecraft:nether_bricks
fill 323 202 463 323 205 463 minecraft:nether_bricks
setblock 324 202 463 minecraft:red_nether_bricks
setblock 324 202 465 minecraft:red_nether_bricks
fill 324 202 466 324 204 466 minecraft:nether_bricks
fill 324 202 473 324 204 474 minecraft:nether_bricks
setblock 324 202 475 minecraft:red_nether_bricks
fill 324 202 477 324 204 477 minecraft:nether_bricks
setblock 324 202 478 minecraft:red_nether_bricks
fill 324 202 489 324 204 489 minecraft:nether_bricks
fill 324 202 491 324 204 491 minecraft:nether_bricks
setblock 282 203 470 minecraft:red_nether_bricks
fill 282 203 471 282 205 471 minecraft:nether_bricks
fill 282 203 475 282 204 476 minecraft:nether_bricks
fill 282 203 481 282 204 481 minecraft:nether_bricks
setblock 282 203 482 minecraft:red_nether_bricks
fill 282 203 483 282 204 483 minecraft:nether_bricks
fill 282 203 486 282 203 487 minecraft:red_nether_bricks
fill 282 203 489 282 204 489 minecraft:nether_bricks
setblock 283 203 463 minecraft:red_nether_bricks
setblock 283 203 505 minecraft:red_nether_bricks
fill 284 203 505 284 204 505 minecraft:nether_bricks
fill 288 203 463 288 204 463 minecraft:nether_bricks
fill 288 203 505 288 204 505 minecraft:nether_bricks
setblock 289 203 463 minecraft:red_nether_bricks
fill 292 203 463 292 204 463 minecraft:nether_bricks
fill 303 203 505 303 204 505 minecraft:nether_bricks
setblock 304 203 505 minecraft:red_nether_bricks
fill 311 203 463 312 203 463 minecraft:red_nether_bricks
fill 313 203 463 313 204 463 minecraft:nether_bricks
fill 317 203 505 317 204 505 minecraft:nether_bricks
fill 320 203 505 320 205 505 minecraft:nether_bricks
setblock 321 203 505 minecraft:red_nether_bricks
fill 323 203 505 323 204 505 minecraft:nether_bricks
fill 324 203 463 324 204 463 minecraft:nether_bricks
setblock 324 203 464 minecraft:red_nether_bricks
fill 324 203 465 324 204 465 minecraft:nether_bricks
fill 324 203 468 324 204 468 minecraft:nether_bricks
setblock 324 203 469 minecraft:red_nether_bricks
fill 324 203 470 324 204 471 minecraft:nether_bricks
fill 324 203 475 324 205 475 minecraft:nether_bricks
fill 324 203 478 324 204 478 minecraft:nether_bricks
setblock 324 203 488 minecraft:red_nether_bricks
setblock 324 203 505 minecraft:red_nether_bricks
setblock 282 204 467 minecraft:nether_bricks
setblock 282 204 470 minecraft:nether_bricks
setblock 282 204 482 minecraft:nether_bricks
fill 282 204 486 282 204 487 minecraft:nether_bricks
setblock 283 204 463 minecraft:nether_bricks
setblock 283 204 505 minecraft:nether_bricks
setblock 287 204 505 minecraft:nether_bricks
setblock 289 204 463 minecraft:nether_bricks
setblock 304 204 505 minecraft:nether_bricks
fill 311 204 463 312 204 463 minecraft:nether_bricks
setblock 321 204 505 minecraft:nether_bricks
setblock 324 204 464 minecraft:nether_bricks
setblock 324 204 469 minecraft:nether_bricks
fill 324 204 488 324 205 488 minecraft:nether_bricks
setblock 324 204 505 minecraft:nether_bricks
setblock 282 205 463 minecraft:nether_bricks
fill 282 205 464 282 307 464 minecraft:red_nether_bricks
setblock 282 205 465 minecraft:nether_bricks
fill 282 205 466 282 205 470 minecraft:red_nether_bricks
fill 282 205 472 282 205 483 minecraft:red_nether_bricks
fill 282 205 485 282 205 486 minecraft:red_nether_bricks
setblock 282 205 487 minecraft:nether_bricks
fill 282 205 489 282 307 490 minecraft:red_nether_bricks
fill 282 205 491 283 205 491 minecraft:nether_bricks
fill 282 205 492 282 205 503 minecraft:red_nether_bricks
fill 282 205 505 285 205 505 minecraft:red_nether_bricks
fill 283 205 463 296 205 463 minecraft:red_nether_bricks
fill 283 205 467 283 205 472 minecraft:nether_bricks
fill 283 205 479 283 205 484 minecraft:nether_bricks
fill 283 205 492 283 205 496 minecraft:nether_bricks
fill 283 205 503 283 205 504 minecraft:nether_bricks
fill 284 205 504 287 205 504 minecraft:nether_bricks
fill 287 205 464 292 205 464 minecraft:nether_bricks
fill 287 205 505 290 205 505 minecraft:red_nether_bricks
setblock 291 205 505 minecraft:nether_bricks
fill 292 205 505 293 206 505 minecraft:red_nether_bricks
fill 294 205 504 299 205 504 minecraft:nether_bricks
fill 295 205 505 304 205 505 minecraft:red_nether_bricks
setblock 297 205 463 minecraft:nether_bricks
fill 298 205 463 303 205 463 minecraft:red_nether_bricks
fill 299 205 464 304 205 464 minecraft:nether_bricks
fill 305 205 463 316 205 463 minecraft:red_nether_bricks
fill 306 205 504 311 205 504 minecraft:nether_bricks
fill 307 205 505 319 205 505 minecraft:red_nether_bricks
fill 311 205 464 316 205 464 minecraft:nether_bricks
setblock 317 205 463 minecraft:nether_bricks
fill 318 205 463 322 206 463 minecraft:red_nether_bricks
fill 318 205 504 323 205 504 minecraft:nether_bricks
fill 321 205 505 324 205 505 minecraft:red_nether_bricks
fill 323 205 464 323 205 469 minecraft:nether_bricks
fill 323 205 476 323 205 481 minecraft:nether_bricks
fill 323 205 488 323 205 493 minecraft:nether_bricks
fill 323 205 500 323 205 503 minecraft:nether_bricks
fill 324 205 463 324 205 469 minecraft:red_nether_bricks
setblock 324 205 470 minecraft:nether_bricks
fill 324 205 471 324 307 474 minecraft:red_nether_bricks
fill 324 205 476 324 205 481 minecraft:red_nether_bricks
setblock 324 205 482 minecraft:nether_bricks
fill 324 205 483 324 205 487 minecraft:red_nether_bricks
fill 324 205 489 324 205 494 minecraft:red_nether_bricks
setblock 324 205 495 minecraft:nether_bricks
fill 324 205 496 324 205 504 minecraft:red_nether_bricks
fill 282 206 463 284 307 463 minecraft:red_nether_bricks
fill 282 206 465 282 206 468 minecraft:red_nether_bricks
fill 282 206 469 282 211 472 minecraft:shroomlight
fill 282 206 473 282 307 474 minecraft:red_nether_bricks
setblock 282 206 475 minecraft:nether_bricks
fill 282 206 476 282 307 478 minecraft:red_nether_bricks
setblock 282 206 479 minecraft:nether_bricks
fill 282 206 480 282 307 480 minecraft:red_nether_bricks
fill 282 206 481 282 211 484 minecraft:shroomlight
fill 282 206 485 282 307 485 minecraft:red_nether_bricks
setblock 282 206 486 minecraft:nether_bricks
fill 282 206 487 282 307 488 minecraft:red_nether_bricks
fill 282 206 491 282 307 492 minecraft:red_nether_bricks
fill 282 206 493 282 211 496 minecraft:shroomlight
fill 282 206 497 282 206 504 minecraft:red_nether_bricks
fill 282 206 505 285 211 505 minecraft:shroomlight
setblock 285 206 463 minecraft:nether_bricks
fill 286 206 463 288 307 463 minecraft:red_nether_bricks
fill 286 206 505 287 307 505 minecraft:red_nether_bricks
fill 288 206 505 288 207 505 minecraft:nether_bricks
fill 289 206 463 292 211 463 minecraft:shroomlight
fill 289 206 505 289 307 505 minecraft:red_nether_bricks
setblock 290 206 505 minecraft:nether_bricks
fill 291 206 505 291 307 505 minecraft:red_nether_bricks
fill 293 206 463 300 206 463 minecraft:red_nether_bricks
fill 294 206 505 297 211 505 minecraft:shroomlight
setblock 298 206 505 minecraft:nether_bricks
fill 299 206 505 305 206 505 minecraft:red_nether_bricks
fill 301 206 463 304 211 463 minecraft:shroomlight
fill 305 206 463 312 307 463 minecraft:red_nether_bricks
fill 306 206 505 309 211 505 minecraft:shroomlight
fill 310 206 505 311 307 505 minecraft:red_nether_bricks
setblock 312 206 505 minecraft:nether_bricks
fill 313 206 463 316 211 463 minecraft:shroomlight
fill 313 206 505 317 206 505 minecraft:red_nether_bricks
fill 317 206 463 317 307 463 minecraft:red_nether_bricks
fill 318 206 505 321 211 505 minecraft:shroomlight
setblock 322 206 505 minecraft:nether_bricks
fill 323 206 463 324 307 463 minecraft:red_nether_bricks
fill 323 206 505 324 307 505 minecraft:red_nether_bricks
fill 324 206 464 324 211 467 minecraft:shroomlight
fill 324 206 468 324 206 470 minecraft:red_nether_bricks
setblock 324 206 475 minecraft:red_nether_bricks
fill 324 206 476 324 211 479 minecraft:shroomlight
fill 324 206 480 324 307 480 minecraft:red_nether_bricks
setblock 324 206 481 minecraft:nether_bricks
setblock 324 206 482 minecraft:red_nether_bricks
fill 324 206 483 324 206 484 minecraft:nether_bricks
fill 324 206 485 324 307 487 minecraft:red_nether_bricks
fill 324 206 488 324 211 491 minecraft:shroomlight
fill 324 206 492 324 206 499 minecraft:red_nether_bricks
fill 324 206 500 324 211 503 minecraft:shroomlight
fill 324 206 504 324 307 504 minecraft:red_nether_bricks
fill 282 207 465 282 307 466 minecraft:red_nether_bricks
setblock 282 207 467 minecraft:nether_bricks
fill 282 207 468 282 307 468 minecraft:red_nether_bricks
fill 282 207 475 282 307 475 minecraft:red_nether_bricks
fill 282 207 479 282 307 479 minecraft:red_nether_bricks
fill 282 207 486 282 307 486 minecraft:red_nether_bricks
fill 282 207 497 282 307 501 minecraft:red_nether_bricks
setblock 282 207 502 minecraft:nether_bricks
fill 282 207 503 282 307 504 minecraft:red_nether_bricks
fill 285 207 463 285 307 463 minecraft:red_nether_bricks
setblock 285 207 466 minecraft:light[level=14]
setblock 285 207 474 minecraft:light[level=14]
setblock 285 207 482 minecraft:light[level=14]
setblock 285 207 490 minecraft:light[level=14]
setblock 285 207 498 minecraft:light[level=14]
fill 290 207 505 290 307 505 minecraft:red_nether_bricks
setblock 292 207 505 minecraft:nether_bricks
setblock 293 207 463 minecraft:nether_bricks
setblock 293 207 466 minecraft:light[level=14]
setblock 293 207 474 minecraft:light[level=14]
setblock 293 207 482 minecraft:light[level=14]
setblock 293 207 490 minecraft:light[level=14]
setblock 293 207 498 minecraft:light[level=14]
fill 293 207 505 293 307 505 minecraft:red_nether_bricks
fill 294 207 463 300 307 463 minecraft:red_nether_bricks
fill 298 207 505 298 307 505 minecraft:red_nether_bricks
setblock 299 207 505 minecraft:nether_bricks
fill 300 207 505 305 307 505 minecraft:red_nether_bricks
setblock 301 207 466 minecraft:light[level=14]
setblock 301 207 474 minecraft:light[level=14]
setblock 301 207 490 minecraft:light[level=14]
setblock 301 207 498 minecraft:light[level=14]
setblock 309 207 466 minecraft:light[level=14]
setblock 309 207 474 minecraft:light[level=14]
setblock 309 207 482 minecraft:light[level=14]
setblock 309 207 490 minecraft:light[level=14]
setblock 309 207 498 minecraft:light[level=14]
fill 312 207 505 313 307 505 minecraft:red_nether_bricks
setblock 314 207 505 minecraft:nether_bricks
fill 315 207 505 317 307 505 minecraft:red_nether_bricks
setblock 317 207 466 minecraft:light[level=14]
setblock 317 207 474 minecraft:light[level=14]
setblock 317 207 482 minecraft:light[level=14]
setblock 317 207 490 minecraft:light[level=14]
setblock 317 207 498 minecraft:light[level=14]
fill 318 207 463 321 307 463 minecraft:red_nether_bricks
setblock 322 207 463 minecraft:nether_bricks
fill 322 207 505 322 307 505 minecraft:red_nether_bricks
fill 324 207 468 324 307 468 minecraft:red_nether_bricks
setblock 324 207 469 minecraft:nether_bricks
fill 324 207 470 324 307 470 minecraft:red_nether_bricks
setblock 324 207 475 minecraft:nether_bricks
fill 324 207 481 324 307 481 minecraft:red_nether_bricks
setblock 324 207 482 minecraft:nether_bricks
fill 324 207 483 324 307 484 minecraft:red_nether_bricks
fill 324 207 492 324 307 496 minecraft:red_nether_bricks
setblock 324 207 497 minecraft:nether_bricks
fill 324 207 498 324 307 499 minecraft:red_nether_bricks
fill 282 208 467 282 307 467 minecraft:red_nether_bricks
fill 282 208 502 282 307 502 minecraft:red_nether_bricks
fill 288 208 505 288 307 505 minecraft:red_nether_bricks
fill 292 208 505 292 307 505 minecraft:red_nether_bricks
fill 293 208 463 293 307 463 minecraft:red_nether_bricks
fill 299 208 505 299 307 505 minecraft:red_nether_bricks
fill 314 208 505 314 307 505 minecraft:red_nether_bricks
fill 322 208 463 322 307 463 minecraft:red_nether_bricks
fill 324 208 469 324 307 469 minecraft:red_nether_bricks
fill 324 208 475 324 307 475 minecraft:red_nether_bricks
fill 324 208 482 324 307 482 minecraft:red_nether_bricks
fill 324 208 497 324 307 497 minecraft:red_nether_bricks
fill 282 212 469 282 245 469 minecraft:red_nether_bricks
fill 282 212 470 282 212 471 minecraft:shroomlight
fill 282 212 472 282 245 472 minecraft:red_nether_bricks
fill 282 212 481 282 245 481 minecraft:red_nether_bricks
fill 282 212 482 282 212 483 minecraft:shroomlight
fill 282 212 484 282 245 484 minecraft:red_nether_bricks
fill 282 212 493 282 245 493 minecraft:red_nether_bricks
fill 282 212 494 282 212 495 minecraft:shroomlight
fill 282 212 496 282 245 496 minecraft:red_nether_bricks
fill 282 212 505 282 245 505 minecraft:red_nether_bricks
fill 283 212 505 284 212 505 minecraft:shroomlight
fill 285 212 505 285 245 505 minecraft:red_nether_bricks
fill 289 212 463 289 245 463 minecraft:red_nether_bricks
fill 290 212 463 291 212 463 minecraft:shroomlight
fill 292 212 463 292 245 463 minecraft:red_nether_bricks
fill 294 212 505 294 245 505 minecraft:red_nether_bricks
fill 295 212 505 296 212 505 minecraft:shroomlight
fill 297 212 505 297 245 505 minecraft:red_nether_bricks
fill 301 212 463 301 245 463 minecraft:red_nether_bricks
fill 302 212 463 303 212 463 minecraft:shroomlight
fill 304 212 463 304 245 463 minecraft:red_nether_bricks
fill 306 212 505 306 245 505 minecraft:red_nether_bricks
fill 307 212 505 308 212 505 minecraft:shroomlight
fill 309 212 505 309 245 505 minecraft:red_nether_bricks
fill 313 212 463 313 245 463 minecraft:red_nether_bricks
fill 314 212 463 315 212 463 minecraft:shroomlight
fill 316 212 463 316 245 463 minecraft:red_nether_bricks
fill 318 212 505 318 245 505 minecraft:red_nether_bricks
fill 319 212 505 320 212 505 minecraft:shroomlight
fill 321 212 505 321 245 505 minecraft:red_nether_bricks
fill 324 212 464 324 245 464 minecraft:red_nether_bricks
fill 324 212 465 324 212 466 minecraft:shroomlight
fill 324 212 467 324 245 467 minecraft:red_nether_bricks
fill 324 212 476 324 245 476 minecraft:red_nether_bricks
fill 324 212 477 324 212 478 minecraft:shroomlight
fill 324 212 479 324 245 479 minecraft:red_nether_bricks
fill 324 212 488 324 245 488 minecraft:red_nether_bricks
fill 324 212 489 324 212 490 minecraft:shroomlight
fill 324 212 491 324 245 491 minecraft:red_nether_bricks
fill 324 212 500 324 245 500 minecraft:red_nether_bricks
fill 324 212 501 324 212 502 minecraft:shroomlight
fill 324 212 503 324 245 503 minecraft:red_nether_bricks
fill 282 213 470 282 245 471 minecraft:red_nether_bricks
fill 282 213 482 282 245 483 minecraft:red_nether_bricks
fill 282 213 494 282 245 495 minecraft:red_nether_bricks
fill 283 213 505 284 245 505 minecraft:red_nether_bricks
fill 290 213 463 291 245 463 minecraft:red_nether_bricks
fill 295 213 505 296 245 505 minecraft:red_nether_bricks
fill 302 213 463 303 245 463 minecraft:red_nether_bricks
fill 307 213 505 308 245 505 minecraft:red_nether_bricks
fill 314 213 463 315 245 463 minecraft:red_nether_bricks
fill 319 213 505 320 245 505 minecraft:red_nether_bricks
fill 324 213 465 324 245 466 minecraft:red_nether_bricks
fill 324 213 477 324 245 478 minecraft:red_nether_bricks
fill 324 213 489 324 245 490 minecraft:red_nether_bricks
fill 324 213 501 324 245 502 minecraft:red_nether_bricks
setblock 285 215 466 minecraft:light[level=14]
setblock 285 215 474 minecraft:light[level=14]
setblock 285 215 482 minecraft:light[level=14]
setblock 285 215 490 minecraft:light[level=14]
setblock 285 215 498 minecraft:light[level=14]
setblock 293 215 466 minecraft:light[level=14]
setblock 293 215 474 minecraft:light[level=14]
setblock 293 215 482 minecraft:light[level=14]
setblock 293 215 490 minecraft:light[level=14]
setblock 293 215 498 minecraft:light[level=14]
setblock 301 215 466 minecraft:light[level=14]
setblock 301 215 474 minecraft:light[level=14]
setblock 301 215 490 minecraft:light[level=14]
setblock 301 215 498 minecraft:light[level=14]
setblock 309 215 466 minecraft:light[level=14]
setblock 309 215 474 minecraft:light[level=14]
setblock 309 215 482 minecraft:light[level=14]
setblock 309 215 490 minecraft:light[level=14]
setblock 309 215 498 minecraft:light[level=14]
setblock 317 215 466 minecraft:light[level=14]
setblock 317 215 474 minecraft:light[level=14]
setblock 317 215 482 minecraft:light[level=14]
setblock 317 215 490 minecraft:light[level=14]
setblock 317 215 498 minecraft:light[level=14]
fill 284 220 473 284 222 475 minecraft:polished_blackstone_bricks
fill 284 220 485 284 222 487 minecraft:polished_blackstone_bricks
fill 284 220 497 284 222 499 minecraft:polished_blackstone_bricks
fill 290 220 503 292 222 503 minecraft:polished_blackstone_bricks
fill 294 220 465 296 222 465 minecraft:polished_blackstone_bricks
fill 302 220 503 304 222 503 minecraft:polished_blackstone_bricks
fill 306 220 465 308 222 465 minecraft:polished_blackstone_bricks
fill 314 220 503 316 222 503 minecraft:polished_blackstone_bricks
fill 318 220 465 320 222 465 minecraft:polished_blackstone_bricks
fill 322 220 473 322 222 475 minecraft:polished_blackstone_bricks
fill 322 220 485 322 222 487 minecraft:polished_blackstone_bricks
fill 322 220 497 322 222 499 minecraft:polished_blackstone_bricks
setblock 285 223 466 minecraft:light[level=14]
setblock 285 223 474 minecraft:light[level=14]
setblock 285 223 482 minecraft:light[level=14]
setblock 285 223 490 minecraft:light[level=14]
setblock 285 223 498 minecraft:light[level=14]
setblock 293 223 466 minecraft:light[level=14]
setblock 293 223 474 minecraft:light[level=14]
setblock 293 223 482 minecraft:light[level=14]
setblock 293 223 490 minecraft:light[level=14]
setblock 293 223 498 minecraft:light[level=14]
setblock 301 223 466 minecraft:light[level=14]
setblock 301 223 474 minecraft:light[level=14]
setblock 301 223 490 minecraft:light[level=14]
setblock 301 223 498 minecraft:light[level=14]
setblock 309 223 466 minecraft:light[level=14]
setblock 309 223 474 minecraft:light[level=14]
setblock 309 223 482 minecraft:light[level=14]
setblock 309 223 490 minecraft:light[level=14]
setblock 309 223 498 minecraft:light[level=14]
setblock 317 223 466 minecraft:light[level=14]
setblock 317 223 474 minecraft:light[level=14]
setblock 317 223 482 minecraft:light[level=14]
setblock 317 223 490 minecraft:light[level=14]
setblock 317 223 498 minecraft:light[level=14]
fill 283 228 464 284 229 474 minecraft:black_concrete
fill 283 228 475 323 229 475 minecraft:gold_block
fill 283 228 476 284 229 486 minecraft:black_concrete
fill 283 228 487 323 229 487 minecraft:gold_block
fill 283 228 488 284 229 498 minecraft:black_concrete
fill 283 228 499 323 229 499 minecraft:gold_block
fill 283 228 500 284 229 504 minecraft:black_concrete
fill 285 228 464 285 229 474 minecraft:polished_blackstone
fill 285 228 476 285 229 486 minecraft:polished_blackstone
fill 285 228 488 285 229 498 minecraft:polished_blackstone
fill 285 228 500 285 229 504 minecraft:polished_blackstone
fill 286 228 464 287 229 474 minecraft:black_concrete
fill 286 228 476 287 229 486 minecraft:black_concrete
fill 286 228 488 287 229 498 minecraft:black_concrete
fill 286 228 500 287 229 504 minecraft:black_concrete
fill 288 228 464 288 229 474 minecraft:polished_blackstone
fill 288 228 476 288 229 486 minecraft:polished_blackstone
fill 288 228 488 288 229 498 minecraft:polished_blackstone
fill 288 228 500 288 229 504 minecraft:polished_blackstone
fill 289 228 464 290 229 474 minecraft:black_concrete
fill 289 228 476 290 229 486 minecraft:black_concrete
fill 289 228 488 290 229 498 minecraft:black_concrete
fill 289 228 500 290 229 504 minecraft:black_concrete
fill 291 228 464 291 229 474 minecraft:polished_blackstone
fill 291 228 476 291 229 486 minecraft:polished_blackstone
fill 291 228 488 291 229 498 minecraft:polished_blackstone
fill 291 228 500 291 229 504 minecraft:polished_blackstone
fill 292 228 464 293 229 474 minecraft:black_concrete
fill 292 228 476 293 229 486 minecraft:black_concrete
fill 292 228 488 293 229 498 minecraft:black_concrete
fill 292 228 500 293 229 504 minecraft:black_concrete
fill 294 228 464 294 229 474 minecraft:polished_blackstone
fill 294 228 476 294 229 486 minecraft:polished_blackstone
fill 294 228 488 294 229 498 minecraft:polished_blackstone
fill 294 228 500 294 229 504 minecraft:polished_blackstone
fill 295 228 464 296 229 474 minecraft:black_concrete
fill 295 228 476 296 229 486 minecraft:black_concrete
fill 295 228 488 296 229 498 minecraft:black_concrete
fill 295 228 500 296 229 504 minecraft:black_concrete
fill 297 228 464 297 229 474 minecraft:polished_blackstone
fill 297 228 476 297 229 486 minecraft:polished_blackstone
fill 297 228 488 297 229 498 minecraft:polished_blackstone
fill 297 228 500 297 229 504 minecraft:polished_blackstone
fill 298 228 464 299 229 474 minecraft:black_concrete
fill 298 228 476 299 228 486 minecraft:black_concrete
fill 298 228 488 299 229 498 minecraft:black_concrete
fill 298 228 500 299 229 504 minecraft:black_concrete
fill 300 228 464 300 229 474 minecraft:polished_blackstone
fill 300 228 476 300 228 481 minecraft:polished_blackstone
fill 300 228 483 300 228 486 minecraft:polished_blackstone
fill 300 228 488 300 229 498 minecraft:polished_blackstone
fill 300 228 500 300 229 504 minecraft:polished_blackstone
fill 301 228 464 302 229 474 minecraft:black_concrete
fill 301 228 476 301 228 480 minecraft:black_concrete
fill 301 228 484 301 228 486 minecraft:black_concrete
fill 301 228 488 302 229 498 minecraft:black_concrete
fill 301 228 500 302 229 504 minecraft:black_concrete
fill 302 228 476 302 228 479 minecraft:black_concrete
fill 302 228 485 302 228 486 minecraft:black_concrete
fill 303 228 464 303 229 474 minecraft:polished_blackstone
fill 303 228 476 303 228 480 minecraft:polished_blackstone
fill 303 228 484 303 228 486 minecraft:polished_blackstone
fill 303 228 488 303 229 498 minecraft:polished_blackstone
fill 303 228 500 303 229 504 minecraft:polished_blackstone
fill 304 228 464 305 229 474 minecraft:black_concrete
fill 304 228 476 305 228 481 minecraft:black_concrete
fill 304 228 483 305 228 486 minecraft:black_concrete
fill 304 228 488 305 229 498 minecraft:black_concrete
fill 304 228 500 305 229 504 minecraft:black_concrete
setblock 305 228 482 minecraft:black_concrete
fill 306 228 464 306 229 474 minecraft:polished_blackstone
fill 306 228 476 306 229 486 minecraft:polished_blackstone
fill 306 228 488 306 229 498 minecraft:polished_blackstone
fill 306 228 500 306 229 504 minecraft:polished_blackstone
fill 307 228 464 308 229 474 minecraft:black_concrete
fill 307 228 476 308 229 486 minecraft:black_concrete
fill 307 228 488 308 229 498 minecraft:black_concrete
fill 307 228 500 308 229 504 minecraft:black_concrete
fill 309 228 464 309 229 474 minecraft:polished_blackstone
fill 309 228 476 309 229 486 minecraft:polished_blackstone
fill 309 228 488 309 229 498 minecraft:polished_blackstone
fill 309 228 500 309 229 504 minecraft:polished_blackstone
fill 310 228 464 311 229 474 minecraft:black_concrete
fill 310 228 476 311 229 486 minecraft:black_concrete
fill 310 228 488 311 229 498 minecraft:black_concrete
fill 310 228 500 311 229 504 minecraft:black_concrete
fill 312 228 464 312 229 474 minecraft:polished_blackstone
fill 312 228 476 312 229 486 minecraft:polished_blackstone
fill 312 228 488 312 229 498 minecraft:polished_blackstone
fill 312 228 500 312 229 504 minecraft:polished_blackstone
fill 313 228 464 314 229 474 minecraft:black_concrete
fill 313 228 476 314 229 486 minecraft:black_concrete
fill 313 228 488 314 229 498 minecraft:black_concrete
fill 313 228 500 314 229 504 minecraft:black_concrete
fill 315 228 464 315 229 474 minecraft:polished_blackstone
fill 315 228 476 315 229 486 minecraft:polished_blackstone
fill 315 228 488 315 229 498 minecraft:polished_blackstone
fill 315 228 500 315 229 504 minecraft:polished_blackstone
fill 316 228 464 317 229 474 minecraft:black_concrete
fill 316 228 476 317 229 486 minecraft:black_concrete
fill 316 228 488 317 229 498 minecraft:black_concrete
fill 316 228 500 317 229 504 minecraft:black_concrete
fill 318 228 464 318 229 474 minecraft:polished_blackstone
fill 318 228 476 318 229 486 minecraft:polished_blackstone
fill 318 228 488 318 229 498 minecraft:polished_blackstone
fill 318 228 500 318 229 504 minecraft:polished_blackstone
fill 319 228 464 320 229 474 minecraft:black_concrete
fill 319 228 476 320 229 486 minecraft:black_concrete
fill 319 228 488 320 229 498 minecraft:black_concrete
fill 319 228 500 320 229 504 minecraft:black_concrete
fill 321 228 464 321 229 474 minecraft:polished_blackstone
fill 321 228 476 321 229 486 minecraft:polished_blackstone
fill 321 228 488 321 229 498 minecraft:polished_blackstone
fill 321 228 500 321 229 504 minecraft:polished_blackstone
fill 322 228 464 323 229 474 minecraft:black_concrete
fill 322 228 476 323 229 486 minecraft:black_concrete
fill 322 228 488 323 229 498 minecraft:black_concrete
fill 322 228 500 323 229 504 minecraft:black_concrete
fill 298 229 476 298 229 486 minecraft:black_concrete
fill 299 229 476 299 229 480 minecraft:black_concrete
fill 299 229 481 299 229 483 minecraft:shroomlight
fill 299 229 484 299 229 486 minecraft:black_concrete
fill 300 229 476 300 229 479 minecraft:polished_blackstone
fill 300 229 480 300 229 481 minecraft:shroomlight
fill 300 229 483 300 229 484 minecraft:shroomlight
fill 300 229 485 300 229 486 minecraft:polished_blackstone
fill 301 229 476 302 229 478 minecraft:black_concrete
fill 301 229 479 301 229 480 minecraft:shroomlight
fill 301 229 484 301 229 485 minecraft:shroomlight
fill 301 229 486 302 229 486 minecraft:black_concrete
fill 302 229 479 303 229 479 minecraft:shroomlight
fill 302 229 485 303 229 485 minecraft:shroomlight
fill 303 229 476 303 229 478 minecraft:polished_blackstone
fill 303 229 480 304 229 480 minecraft:shroomlight
fill 303 229 484 304 229 484 minecraft:shroomlight
setblock 303 229 486 minecraft:polished_blackstone
fill 304 229 476 305 229 479 minecraft:black_concrete
fill 304 229 481 305 229 481 minecraft:shroomlight
fill 304 229 483 305 229 483 minecraft:shroomlight
fill 304 229 485 305 229 486 minecraft:black_concrete
setblock 305 229 480 minecraft:black_concrete
setblock 305 229 482 minecraft:shroomlight
setblock 305 229 484 minecraft:black_concrete
setblock 285 231 466 minecraft:light[level=14]
setblock 285 231 474 minecraft:light[level=14]
setblock 285 231 482 minecraft:light[level=14]
setblock 285 231 490 minecraft:light[level=14]
setblock 285 231 498 minecraft:light[level=14]
setblock 293 231 466 minecraft:light[level=14]
setblock 293 231 474 minecraft:light[level=14]
setblock 293 231 482 minecraft:light[level=14]
setblock 293 231 490 minecraft:light[level=14]
setblock 293 231 498 minecraft:light[level=14]
setblock 301 231 466 minecraft:light[level=14]
setblock 301 231 474 minecraft:light[level=14]
setblock 301 231 490 minecraft:light[level=14]
setblock 301 231 498 minecraft:light[level=14]
setblock 309 231 466 minecraft:light[level=14]
setblock 309 231 474 minecraft:light[level=14]
setblock 309 231 482 minecraft:light[level=14]
setblock 309 231 490 minecraft:light[level=14]
setblock 309 231 498 minecraft:light[level=14]
setblock 317 231 466 minecraft:light[level=14]
setblock 317 231 474 minecraft:light[level=14]
setblock 317 231 482 minecraft:light[level=14]
setblock 317 231 490 minecraft:light[level=14]
setblock 317 231 498 minecraft:light[level=14]
fill 283 233 464 285 273 464 minecraft:polished_blackstone_bricks
fill 283 233 474 283 273 476 minecraft:polished_blackstone_bricks
fill 283 233 486 283 273 488 minecraft:polished_blackstone_bricks
fill 283 233 490 292 234 502 minecraft:polished_blackstone_bricks
fill 289 233 503 310 234 504 minecraft:polished_blackstone_bricks
fill 293 233 495 301 234 502 minecraft:polished_blackstone_bricks
fill 295 233 464 297 273 464 minecraft:polished_blackstone_bricks
fill 302 233 498 310 234 502 minecraft:polished_blackstone_bricks
fill 307 233 464 309 273 464 minecraft:polished_blackstone_bricks
fill 313 233 504 323 244 504 minecraft:polished_blackstone_bricks
fill 316 233 496 323 244 503 minecraft:polished_blackstone_bricks
fill 319 233 464 321 273 464 minecraft:polished_blackstone_bricks
fill 323 233 472 323 273 474 minecraft:polished_blackstone_bricks
fill 323 233 484 323 273 486 minecraft:polished_blackstone_bricks
setblock 283 235 490 minecraft:shroomlight
fill 283 235 491 283 244 491 minecraft:polished_blackstone_bricks
setblock 283 235 492 minecraft:shroomlight
fill 283 235 493 283 244 493 minecraft:polished_blackstone_bricks
setblock 283 235 494 minecraft:shroomlight
fill 283 235 495 283 244 495 minecraft:polished_blackstone_bricks
setblock 283 235 496 minecraft:shroomlight
fill 283 235 497 283 247 497 minecraft:polished_blackstone_bricks
setblock 283 235 498 minecraft:shroomlight
fill 283 235 499 283 273 499 minecraft:polished_blackstone_bricks
setblock 283 235 500 minecraft:shroomlight
fill 283 235 501 283 247 501 minecraft:polished_blackstone_bricks
setblock 283 235 502 minecraft:shroomlight
fill 284 235 490 284 247 490 minecraft:polished_blackstone_bricks
setblock 284 235 491 minecraft:shroomlight
fill 284 235 492 284 247 492 minecraft:polished_blackstone_bricks
setblock 284 235 493 minecraft:shroomlight
fill 284 235 494 284 247 494 minecraft:polished_blackstone_bricks
setblock 284 235 495 minecraft:shroomlight
fill 284 235 496 284 247 496 minecraft:polished_blackstone_bricks
setblock 284 235 497 minecraft:shroomlight
fill 284 235 498 284 247 498 minecraft:polished_blackstone_bricks
setblock 284 235 499 minecraft:shroomlight
fill 284 235 500 284 247 500 minecraft:polished_blackstone_bricks
setblock 284 235 501 minecraft:shroomlight
fill 284 235 502 284 247 502 minecraft:polished_blackstone_bricks
setblock 285 235 490 minecraft:shroomlight
fill 285 235 491 285 247 491 minecraft:polished_blackstone_bricks
setblock 285 235 492 minecraft:shroomlight
fill 285 235 493 285 247 493 minecraft:polished_blackstone_bricks
setblock 285 235 494 minecraft:shroomlight
fill 285 235 495 285 247 495 minecraft:polished_blackstone_bricks
setblock 285 235 496 minecraft:shroomlight
fill 285 235 497 285 247 497 minecraft:polished_blackstone_bricks
setblock 285 235 498 minecraft:shroomlight
fill 285 235 499 285 247 499 minecraft:polished_blackstone_bricks
setblock 285 235 500 minecraft:shroomlight
fill 285 235 501 285 247 501 minecraft:polished_blackstone_bricks
setblock 285 235 502 minecraft:shroomlight
fill 286 235 490 286 247 490 minecraft:polished_blackstone_bricks
setblock 286 235 491 minecraft:shroomlight
fill 286 235 492 286 247 492 minecraft:polished_blackstone_bricks
setblock 286 235 493 minecraft:shroomlight
fill 286 235 494 286 247 494 minecraft:polished_blackstone_bricks
setblock 286 235 495 minecraft:shroomlight
fill 286 235 496 286 247 496 minecraft:polished_blackstone_bricks
setblock 286 235 497 minecraft:shroomlight
fill 286 235 498 286 247 498 minecraft:polished_blackstone_bricks
setblock 286 235 499 minecraft:shroomlight
fill 286 235 500 286 247 500 minecraft:polished_blackstone_bricks
setblock 286 235 501 minecraft:shroomlight
fill 286 235 502 286 247 502 minecraft:polished_blackstone_bricks
setblock 287 235 490 minecraft:shroomlight
fill 287 235 491 287 247 491 minecraft:polished_blackstone_bricks
setblock 287 235 492 minecraft:shroomlight
fill 287 235 493 287 247 493 minecraft:polished_blackstone_bricks
setblock 287 235 494 minecraft:shroomlight
fill 287 235 495 287 247 495 minecraft:polished_blackstone_bricks
setblock 287 235 496 minecraft:shroomlight
fill 287 235 497 287 247 497 minecraft:polished_blackstone_bricks
setblock 287 235 498 minecraft:shroomlight
fill 287 235 499 287 247 499 minecraft:polished_blackstone_bricks
setblock 287 235 500 minecraft:shroomlight
fill 287 235 501 287 247 501 minecraft:polished_blackstone_bricks
setblock 287 235 502 minecraft:shroomlight
fill 288 235 490 288 247 490 minecraft:polished_blackstone_bricks
setblock 288 235 491 minecraft:shroomlight
fill 288 235 492 288 247 492 minecraft:polished_blackstone_bricks
setblock 288 235 493 minecraft:shroomlight
fill 288 235 494 288 247 494 minecraft:polished_blackstone_bricks
setblock 288 235 495 minecraft:shroomlight
fill 288 235 496 288 247 496 minecraft:polished_blackstone_bricks
setblock 288 235 497 minecraft:shroomlight
fill 288 235 498 288 247 498 minecraft:polished_blackstone_bricks
setblock 288 235 499 minecraft:shroomlight
fill 288 235 500 288 247 500 minecraft:polished_blackstone_bricks
setblock 288 235 501 minecraft:shroomlight
fill 288 235 502 288 247 502 minecraft:polished_blackstone_bricks
setblock 289 235 490 minecraft:shroomlight
fill 289 235 491 289 247 491 minecraft:polished_blackstone_bricks
setblock 289 235 492 minecraft:shroomlight
fill 289 235 493 289 247 493 minecraft:polished_blackstone_bricks
setblock 289 235 494 minecraft:shroomlight
fill 289 235 495 289 247 495 minecraft:polished_blackstone_bricks
setblock 289 235 496 minecraft:shroomlight
fill 289 235 497 289 247 497 minecraft:polished_blackstone_bricks
setblock 289 235 498 minecraft:shroomlight
fill 289 235 499 289 247 499 minecraft:polished_blackstone_bricks
setblock 289 235 500 minecraft:shroomlight
fill 289 235 501 289 247 501 minecraft:polished_blackstone_bricks
setblock 289 235 502 minecraft:shroomlight
fill 289 235 503 289 254 503 minecraft:polished_blackstone_bricks
setblock 289 235 504 minecraft:shroomlight
fill 290 235 490 290 247 490 minecraft:polished_blackstone_bricks
setblock 290 235 491 minecraft:shroomlight
fill 290 235 492 290 247 492 minecraft:polished_blackstone_bricks
setblock 290 235 493 minecraft:shroomlight
fill 290 235 494 290 247 494 minecraft:polished_blackstone_bricks
setblock 290 235 495 minecraft:shroomlight
fill 290 235 496 290 247 496 minecraft:polished_blackstone_bricks
setblock 290 235 497 minecraft:shroomlight
fill 290 235 498 290 247 498 minecraft:polished_blackstone_bricks
setblock 290 235 499 minecraft:shroomlight
fill 290 235 500 290 247 500 minecraft:polished_blackstone_bricks
setblock 290 235 501 minecraft:shroomlight
fill 290 235 502 290 254 502 minecraft:polished_blackstone_bricks
setblock 290 235 503 minecraft:shroomlight
fill 290 235 504 290 273 504 minecraft:polished_blackstone_bricks
setblock 291 235 490 minecraft:shroomlight
fill 291 235 491 291 247 491 minecraft:polished_blackstone_bricks
setblock 291 235 492 minecraft:shroomlight
fill 291 235 493 291 247 493 minecraft:polished_blackstone_bricks
setblock 291 235 494 minecraft:shroomlight
fill 291 235 495 291 247 495 minecraft:polished_blackstone_bricks
setblock 291 235 496 minecraft:shroomlight
fill 291 235 497 291 247 497 minecraft:polished_blackstone_bricks
setblock 291 235 498 minecraft:shroomlight
fill 291 235 499 291 247 499 minecraft:polished_blackstone_bricks
setblock 291 235 500 minecraft:shroomlight
fill 291 235 501 291 247 501 minecraft:polished_blackstone_bricks
setblock 291 235 502 minecraft:shroomlight
fill 291 235 503 291 254 503 minecraft:polished_blackstone_bricks
setblock 291 235 504 minecraft:shroomlight
fill 292 235 490 292 247 490 minecraft:polished_blackstone_bricks
setblock 292 235 491 minecraft:shroomlight
fill 292 235 492 292 247 492 minecraft:polished_blackstone_bricks
setblock 292 235 493 minecraft:shroomlight
fill 292 235 494 292 247 494 minecraft:polished_blackstone_bricks
setblock 292 235 495 minecraft:shroomlight
fill 292 235 496 292 254 496 minecraft:polished_blackstone_bricks
setblock 292 235 497 minecraft:shroomlight
fill 292 235 498 292 254 498 minecraft:polished_blackstone_bricks
setblock 292 235 499 minecraft:shroomlight
fill 292 235 500 292 254 500 minecraft:polished_blackstone_bricks
setblock 292 235 501 minecraft:shroomlight
fill 292 235 502 292 254 502 minecraft:polished_blackstone_bricks
setblock 292 235 503 minecraft:shroomlight
fill 292 235 504 292 254 504 minecraft:polished_blackstone_bricks
fill 293 235 495 293 254 495 minecraft:polished_blackstone_bricks
setblock 293 235 496 minecraft:shroomlight
fill 293 235 497 293 254 497 minecraft:polished_blackstone_bricks
setblock 293 235 498 minecraft:shroomlight
fill 293 235 499 293 254 499 minecraft:polished_blackstone_bricks
setblock 293 235 500 minecraft:shroomlight
fill 293 235 501 293 254 501 minecraft:polished_blackstone_bricks
setblock 293 235 502 minecraft:shroomlight
fill 293 235 503 293 254 503 minecraft:polished_blackstone_bricks
setblock 293 235 504 minecraft:shroomlight
setblock 294 235 495 minecraft:shroomlight
fill 294 235 496 294 254 496 minecraft:polished_blackstone_bricks
setblock 294 235 497 minecraft:shroomlight
fill 294 235 498 294 254 498 minecraft:polished_blackstone_bricks
setblock 294 235 499 minecraft:shroomlight
fill 294 235 500 294 254 500 minecraft:polished_blackstone_bricks
setblock 294 235 501 minecraft:shroomlight
fill 294 235 502 294 254 502 minecraft:polished_blackstone_bricks
setblock 294 235 503 minecraft:shroomlight
fill 294 235 504 294 244 504 minecraft:polished_blackstone_bricks
fill 295 235 495 295 254 495 minecraft:polished_blackstone_bricks
setblock 295 235 496 minecraft:shroomlight
fill 295 235 497 295 254 497 minecraft:polished_blackstone_bricks
setblock 295 235 498 minecraft:shroomlight
fill 295 235 499 295 254 499 minecraft:polished_blackstone_bricks
setblock 295 235 500 minecraft:shroomlight
fill 295 235 501 295 254 501 minecraft:polished_blackstone_bricks
setblock 295 235 502 minecraft:shroomlight
fill 295 235 503 295 254 503 minecraft:polished_blackstone_bricks
setblock 295 235 504 minecraft:shroomlight
setblock 296 235 495 minecraft:shroomlight
fill 296 235 496 296 254 496 minecraft:polished_blackstone_bricks
setblock 296 235 497 minecraft:shroomlight
fill 296 235 498 296 254 498 minecraft:polished_blackstone_bricks
setblock 296 235 499 minecraft:shroomlight
fill 296 235 500 296 254 500 minecraft:polished_blackstone_bricks
setblock 296 235 501 minecraft:shroomlight
fill 296 235 502 296 254 502 minecraft:polished_blackstone_bricks
setblock 296 235 503 minecraft:shroomlight
fill 296 235 504 296 244 504 minecraft:polished_blackstone_bricks
fill 297 235 495 297 254 495 minecraft:polished_blackstone_bricks
setblock 297 235 496 minecraft:shroomlight
fill 297 235 497 297 254 497 minecraft:polished_blackstone_bricks
setblock 297 235 498 minecraft:shroomlight
fill 297 235 499 297 254 499 minecraft:polished_blackstone_bricks
setblock 297 235 500 minecraft:shroomlight
fill 297 235 501 297 254 501 minecraft:polished_blackstone_bricks
setblock 297 235 502 minecraft:shroomlight
fill 297 235 503 297 254 503 minecraft:polished_blackstone_bricks
setblock 297 235 504 minecraft:shroomlight
setblock 298 235 495 minecraft:shroomlight
fill 298 235 496 298 254 496 minecraft:polished_blackstone_bricks
setblock 298 235 497 minecraft:shroomlight
fill 298 235 498 298 254 498 minecraft:polished_blackstone_bricks
setblock 298 235 499 minecraft:shroomlight
fill 298 235 500 298 254 500 minecraft:polished_blackstone_bricks
setblock 298 235 501 minecraft:shroomlight
fill 298 235 502 298 254 502 minecraft:polished_blackstone_bricks
setblock 298 235 503 minecraft:shroomlight
fill 298 235 504 298 244 504 minecraft:polished_blackstone_bricks
fill 299 235 495 299 254 495 minecraft:polished_blackstone_bricks
setblock 299 235 496 minecraft:shroomlight
fill 299 235 497 299 254 497 minecraft:polished_blackstone_bricks
setblock 299 235 498 minecraft:shroomlight
fill 299 235 499 299 254 499 minecraft:polished_blackstone_bricks
setblock 299 235 500 minecraft:shroomlight
fill 299 235 501 299 254 501 minecraft:polished_blackstone_bricks
setblock 299 235 502 minecraft:shroomlight
fill 299 235 503 299 254 503 minecraft:polished_blackstone_bricks
setblock 299 235 504 minecraft:shroomlight
setblock 300 235 495 minecraft:shroomlight
fill 300 235 496 300 254 496 minecraft:polished_blackstone_bricks
setblock 300 235 497 minecraft:shroomlight
fill 300 235 498 300 254 498 minecraft:polished_blackstone_bricks
setblock 300 235 499 minecraft:shroomlight
fill 300 235 500 300 254 500 minecraft:polished_blackstone_bricks
setblock 300 235 501 minecraft:shroomlight
fill 300 235 502 300 254 502 minecraft:polished_blackstone_bricks
setblock 300 235 503 minecraft:shroomlight
fill 300 235 504 300 254 504 minecraft:polished_blackstone_bricks
fill 301 235 495 301 254 495 minecraft:polished_blackstone_bricks
setblock 301 235 496 minecraft:shroomlight
fill 301 235 497 301 254 497 minecraft:polished_blackstone_bricks
setblock 301 235 498 minecraft:shroomlight
fill 301 235 499 301 254 499 minecraft:polished_blackstone_bricks
setblock 301 235 500 minecraft:shroomlight
fill 301 235 501 301 254 501 minecraft:polished_blackstone_bricks
setblock 301 235 502 minecraft:shroomlight
fill 301 235 503 301 254 503 minecraft:polished_blackstone_bricks
setblock 301 235 504 minecraft:shroomlight
fill 302 235 498 302 254 498 minecraft:polished_blackstone_bricks
setblock 302 235 499 minecraft:shroomlight
fill 302 235 500 302 254 500 minecraft:polished_blackstone_bricks
setblock 302 235 501 minecraft:shroomlight
fill 302 235 502 302 254 502 minecraft:polished_blackstone_bricks
setblock 302 235 503 minecraft:shroomlight
fill 302 235 504 302 273 504 minecraft:polished_blackstone_bricks
setblock 303 235 498 minecraft:shroomlight
fill 303 235 499 303 254 499 minecraft:polished_blackstone_bricks
setblock 303 235 500 minecraft:shroomlight
fill 303 235 501 303 254 501 minecraft:polished_blackstone_bricks
setblock 303 235 502 minecraft:shroomlight
fill 303 235 503 303 254 503 minecraft:polished_blackstone_bricks
setblock 303 235 504 minecraft:shroomlight
fill 304 235 498 304 254 498 minecraft:polished_blackstone_bricks
setblock 304 235 499 minecraft:shroomlight
fill 304 235 500 304 254 500 minecraft:polished_blackstone_bricks
setblock 304 235 501 minecraft:shroomlight
fill 304 235 502 304 254 502 minecraft:polished_blackstone_bricks
setblock 304 235 503 minecraft:shroomlight
fill 304 235 504 304 254 504 minecraft:polished_blackstone_bricks
setblock 305 235 498 minecraft:shroomlight
fill 305 235 499 305 254 499 minecraft:polished_blackstone_bricks
setblock 305 235 500 minecraft:shroomlight
fill 305 235 501 305 254 501 minecraft:polished_blackstone_bricks
setblock 305 235 502 minecraft:shroomlight
fill 305 235 503 305 254 503 minecraft:polished_blackstone_bricks
setblock 305 235 504 minecraft:shroomlight
fill 306 235 498 306 254 498 minecraft:polished_blackstone_bricks
setblock 306 235 499 minecraft:shroomlight
fill 306 235 500 306 254 500 minecraft:polished_blackstone_bricks
setblock 306 235 501 minecraft:shroomlight
fill 306 235 502 306 254 502 minecraft:polished_blackstone_bricks
setblock 306 235 503 minecraft:shroomlight
fill 306 235 504 306 244 504 minecraft:polished_blackstone_bricks
setblock 307 235 498 minecraft:shroomlight
fill 307 235 499 307 254 499 minecraft:polished_blackstone_bricks
setblock 307 235 500 minecraft:shroomlight
fill 307 235 501 307 254 501 minecraft:polished_blackstone_bricks
setblock 307 235 502 minecraft:shroomlight
fill 307 235 503 307 254 503 minecraft:polished_blackstone_bricks
setblock 307 235 504 minecraft:shroomlight
fill 308 235 498 308 254 498 minecraft:polished_blackstone_bricks
setblock 308 235 499 minecraft:shroomlight
fill 308 235 500 308 254 500 minecraft:polished_blackstone_bricks
setblock 308 235 501 minecraft:shroomlight
fill 308 235 502 308 254 502 minecraft:polished_blackstone_bricks
setblock 308 235 503 minecraft:shroomlight
fill 308 235 504 308 244 504 minecraft:polished_blackstone_bricks
setblock 309 235 498 minecraft:shroomlight
fill 309 235 499 309 254 499 minecraft:polished_blackstone_bricks
setblock 309 235 500 minecraft:shroomlight
fill 309 235 501 309 254 501 minecraft:polished_blackstone_bricks
setblock 309 235 502 minecraft:shroomlight
fill 309 235 503 309 254 503 minecraft:polished_blackstone_bricks
setblock 309 235 504 minecraft:shroomlight
fill 310 235 498 310 254 498 minecraft:polished_blackstone_bricks
setblock 310 235 499 minecraft:shroomlight
fill 310 235 500 310 254 500 minecraft:polished_blackstone_bricks
setblock 310 235 501 minecraft:shroomlight
fill 310 235 502 310 254 502 minecraft:polished_blackstone_bricks
setblock 310 235 503 minecraft:shroomlight
fill 310 235 504 310 244 504 minecraft:polished_blackstone_bricks
fill 283 236 490 283 237 490 minecraft:polished_blackstone_bricks
fill 283 236 492 283 237 492 minecraft:polished_blackstone_bricks
fill 283 236 494 283 237 494 minecraft:polished_blackstone_bricks
fill 283 236 496 283 237 496 minecraft:polished_blackstone_bricks
fill 283 236 498 283 237 498 minecraft:polished_blackstone_bricks
fill 283 236 500 283 237 500 minecraft:polished_blackstone_bricks
fill 283 236 502 283 237 502 minecraft:polished_blackstone_bricks
fill 284 236 491 284 237 491 minecraft:polished_blackstone_bricks
fill 284 236 493 284 237 493 minecraft:polished_blackstone_bricks
fill 284 236 495 284 237 495 minecraft:polished_blackstone_bricks
fill 284 236 497 284 237 497 minecraft:polished_blackstone_bricks
fill 284 236 499 284 237 499 minecraft:polished_blackstone_bricks
fill 284 236 501 284 237 501 minecraft:polished_blackstone_bricks
fill 285 236 490 285 237 490 minecraft:polished_blackstone_bricks
fill 285 236 492 285 237 492 minecraft:polished_blackstone_bricks
fill 285 236 494 285 237 494 minecraft:polished_blackstone_bricks
fill 285 236 496 285 237 496 minecraft:polished_blackstone_bricks
fill 285 236 498 285 237 498 minecraft:polished_blackstone_bricks
fill 285 236 500 285 237 500 minecraft:polished_blackstone_bricks
fill 285 236 502 285 237 502 minecraft:polished_blackstone_bricks
fill 286 236 491 286 237 491 minecraft:polished_blackstone_bricks
fill 286 236 493 286 237 493 minecraft:polished_blackstone_bricks
fill 286 236 495 286 237 495 minecraft:polished_blackstone_bricks
fill 286 236 497 286 237 497 minecraft:polished_blackstone_bricks
fill 286 236 499 286 237 499 minecraft:polished_blackstone_bricks
fill 286 236 501 286 237 501 minecraft:polished_blackstone_bricks
fill 287 236 490 287 237 490 minecraft:polished_blackstone_bricks
fill 287 236 492 287 237 492 minecraft:polished_blackstone_bricks
fill 287 236 494 287 237 494 minecraft:polished_blackstone_bricks
fill 287 236 496 287 237 496 minecraft:polished_blackstone_bricks
fill 287 236 498 287 237 498 minecraft:polished_blackstone_bricks
fill 287 236 500 287 237 500 minecraft:polished_blackstone_bricks
fill 287 236 502 287 237 502 minecraft:polished_blackstone_bricks
fill 288 236 491 288 237 491 minecraft:polished_blackstone_bricks
fill 288 236 493 288 237 493 minecraft:polished_blackstone_bricks
fill 288 236 495 288 237 495 minecraft:polished_blackstone_bricks
fill 288 236 497 288 237 497 minecraft:polished_blackstone_bricks
fill 288 236 499 288 237 499 minecraft:polished_blackstone_bricks
fill 288 236 501 288 237 501 minecraft:polished_blackstone_bricks
fill 289 236 490 289 237 490 minecraft:polished_blackstone_bricks
fill 289 236 492 289 237 492 minecraft:polished_blackstone_bricks
fill 289 236 494 289 237 494 minecraft:polished_blackstone_bricks
fill 289 236 496 289 237 496 minecraft:polished_blackstone_bricks
fill 289 236 498 289 237 498 minecraft:polished_blackstone_bricks
fill 289 236 500 289 237 500 minecraft:polished_blackstone_bricks
fill 289 236 502 289 237 502 minecraft:polished_blackstone_bricks
fill 289 236 504 289 237 504 minecraft:polished_blackstone_bricks
fill 290 236 491 290 237 491 minecraft:polished_blackstone_bricks
fill 290 236 493 290 237 493 minecraft:polished_blackstone_bricks
fill 290 236 495 290 237 495 minecraft:polished_blackstone_bricks
fill 290 236 497 290 237 497 minecraft:polished_blackstone_bricks
fill 290 236 499 290 237 499 minecraft:polished_blackstone_bricks
fill 290 236 501 290 237 501 minecraft:polished_blackstone_bricks
fill 290 236 503 290 237 503 minecraft:polished_blackstone_bricks
fill 291 236 490 291 237 490 minecraft:polished_blackstone_bricks
fill 291 236 492 291 237 492 minecraft:polished_blackstone_bricks
fill 291 236 494 291 237 494 minecraft:polished_blackstone_bricks
fill 291 236 496 291 237 496 minecraft:polished_blackstone_bricks
fill 291 236 498 291 237 498 minecraft:polished_blackstone_bricks
fill 291 236 500 291 237 500 minecraft:polished_blackstone_bricks
fill 291 236 502 291 237 502 minecraft:polished_blackstone_bricks
fill 291 236 504 291 237 504 minecraft:polished_blackstone_bricks
fill 292 236 491 292 237 491 minecraft:polished_blackstone_bricks
fill 292 236 493 292 237 493 minecraft:polished_blackstone_bricks
fill 292 236 495 292 237 495 minecraft:polished_blackstone_bricks
fill 292 236 497 292 237 497 minecraft:polished_blackstone_bricks
fill 292 236 499 292 237 499 minecraft:polished_blackstone_bricks
fill 292 236 501 292 237 501 minecraft:polished_blackstone_bricks
fill 292 236 503 292 237 503 minecraft:polished_blackstone_bricks
fill 293 236 496 293 237 496 minecraft:polished_blackstone_bricks
fill 293 236 498 293 237 498 minecraft:polished_blackstone_bricks
fill 293 236 500 293 237 500 minecraft:polished_blackstone_bricks
fill 293 236 502 293 237 502 minecraft:polished_blackstone_bricks
fill 293 236 504 293 237 504 minecraft:polished_blackstone_bricks
fill 294 236 495 294 237 495 minecraft:polished_blackstone_bricks
fill 294 236 497 294 237 497 minecraft:polished_blackstone_bricks
fill 294 236 499 294 237 499 minecraft:polished_blackstone_bricks
fill 294 236 501 294 237 501 minecraft:polished_blackstone_bricks
fill 294 236 503 294 237 503 minecraft:polished_blackstone_bricks
fill 295 236 496 295 237 496 minecraft:polished_blackstone_bricks
fill 295 236 498 295 237 498 minecraft:polished_blackstone_bricks
fill 295 236 500 295 237 500 minecraft:polished_blackstone_bricks
fill 295 236 502 295 237 502 minecraft:polished_blackstone_bricks
fill 295 236 504 295 237 504 minecraft:polished_blackstone_bricks
fill 296 236 495 296 237 495 minecraft:polished_blackstone_bricks
fill 296 236 497 296 237 497 minecraft:polished_blackstone_bricks
fill 296 236 499 296 237 499 minecraft:polished_blackstone_bricks
fill 296 236 501 296 237 501 minecraft:polished_blackstone_bricks
fill 296 236 503 296 237 503 minecraft:polished_blackstone_bricks
fill 297 236 496 297 237 496 minecraft:polished_blackstone_bricks
fill 297 236 498 297 237 498 minecraft:polished_blackstone_bricks
fill 297 236 500 297 237 500 minecraft:polished_blackstone_bricks
fill 297 236 502 297 237 502 minecraft:polished_blackstone_bricks
fill 297 236 504 297 237 504 minecraft:polished_blackstone_bricks
fill 298 236 495 298 237 495 minecraft:polished_blackstone_bricks
fill 298 236 497 298 237 497 minecraft:polished_blackstone_bricks
fill 298 236 499 298 237 499 minecraft:polished_blackstone_bricks
fill 298 236 501 298 237 501 minecraft:polished_blackstone_bricks
fill 298 236 503 298 237 503 minecraft:polished_blackstone_bricks
fill 299 236 496 299 237 496 minecraft:polished_blackstone_bricks
fill 299 236 498 299 237 498 minecraft:polished_blackstone_bricks
fill 299 236 500 299 237 500 minecraft:polished_blackstone_bricks
fill 299 236 502 299 237 502 minecraft:polished_blackstone_bricks
fill 299 236 504 299 237 504 minecraft:polished_blackstone_bricks
fill 300 236 495 300 237 495 minecraft:polished_blackstone_bricks
fill 300 236 497 300 237 497 minecraft:polished_blackstone_bricks
fill 300 236 499 300 237 499 minecraft:polished_blackstone_bricks
fill 300 236 501 300 237 501 minecraft:polished_blackstone_bricks
fill 300 236 503 300 237 503 minecraft:polished_blackstone_bricks
fill 301 236 496 301 237 496 minecraft:polished_blackstone_bricks
fill 301 236 498 301 237 498 minecraft:polished_blackstone_bricks
fill 301 236 500 301 237 500 minecraft:polished_blackstone_bricks
fill 301 236 502 301 237 502 minecraft:polished_blackstone_bricks
fill 301 236 504 301 237 504 minecraft:polished_blackstone_bricks
fill 302 236 499 302 237 499 minecraft:polished_blackstone_bricks
fill 302 236 501 302 237 501 minecraft:polished_blackstone_bricks
fill 302 236 503 302 237 503 minecraft:polished_blackstone_bricks
fill 303 236 498 303 237 498 minecraft:polished_blackstone_bricks
fill 303 236 500 303 237 500 minecraft:polished_blackstone_bricks
fill 303 236 502 303 237 502 minecraft:polished_blackstone_bricks
fill 303 236 504 303 237 504 minecraft:polished_blackstone_bricks
fill 304 236 499 304 237 499 minecraft:polished_blackstone_bricks
fill 304 236 501 304 237 501 minecraft:polished_blackstone_bricks
fill 304 236 503 304 237 503 minecraft:polished_blackstone_bricks
fill 305 236 498 305 237 498 minecraft:polished_blackstone_bricks
fill 305 236 500 305 237 500 minecraft:polished_blackstone_bricks
fill 305 236 502 305 237 502 minecraft:polished_blackstone_bricks
fill 305 236 504 305 237 504 minecraft:polished_blackstone_bricks
fill 306 236 499 306 237 499 minecraft:polished_blackstone_bricks
fill 306 236 501 306 237 501 minecraft:polished_blackstone_bricks
fill 306 236 503 306 237 503 minecraft:polished_blackstone_bricks
fill 307 236 498 307 237 498 minecraft:polished_blackstone_bricks
fill 307 236 500 307 237 500 minecraft:polished_blackstone_bricks
fill 307 236 502 307 237 502 minecraft:polished_blackstone_bricks
fill 307 236 504 307 237 504 minecraft:polished_blackstone_bricks
fill 308 236 499 308 237 499 minecraft:polished_blackstone_bricks
fill 308 236 501 308 237 501 minecraft:polished_blackstone_bricks
fill 308 236 503 308 237 503 minecraft:polished_blackstone_bricks
fill 309 236 498 309 237 498 minecraft:polished_blackstone_bricks
fill 309 236 500 309 237 500 minecraft:polished_blackstone_bricks
fill 309 236 502 309 237 502 minecraft:polished_blackstone_bricks
fill 309 236 504 309 237 504 minecraft:polished_blackstone_bricks
fill 310 236 499 310 237 499 minecraft:polished_blackstone_bricks
fill 310 236 501 310 237 501 minecraft:polished_blackstone_bricks
fill 310 236 503 310 237 503 minecraft:polished_blackstone_bricks
setblock 283 238 490 minecraft:shroomlight
setblock 283 238 492 minecraft:shroomlight
setblock 283 238 494 minecraft:shroomlight
setblock 283 238 496 minecraft:shroomlight
setblock 283 238 498 minecraft:shroomlight
setblock 283 238 500 minecraft:shroomlight
setblock 283 238 502 minecraft:shroomlight
setblock 284 238 491 minecraft:shroomlight
setblock 284 238 493 minecraft:shroomlight
setblock 284 238 495 minecraft:shroomlight
setblock 284 238 497 minecraft:shroomlight
setblock 284 238 499 minecraft:shroomlight
setblock 284 238 501 minecraft:shroomlight
setblock 285 238 490 minecraft:shroomlight
setblock 285 238 492 minecraft:shroomlight
setblock 285 238 494 minecraft:shroomlight
setblock 285 238 496 minecraft:shroomlight
setblock 285 238 498 minecraft:shroomlight
setblock 285 238 500 minecraft:shroomlight
setblock 285 238 502 minecraft:shroomlight
setblock 286 238 491 minecraft:shroomlight
setblock 286 238 493 minecraft:shroomlight
setblock 286 238 495 minecraft:shroomlight
setblock 286 238 497 minecraft:shroomlight
setblock 286 238 499 minecraft:shroomlight
setblock 286 238 501 minecraft:shroomlight
setblock 287 238 490 minecraft:shroomlight
setblock 287 238 492 minecraft:shroomlight
setblock 287 238 494 minecraft:shroomlight
setblock 287 238 496 minecraft:shroomlight
setblock 287 238 498 minecraft:shroomlight
setblock 287 238 500 minecraft:shroomlight
setblock 287 238 502 minecraft:shroomlight
setblock 288 238 491 minecraft:shroomlight
setblock 288 238 493 minecraft:shroomlight
setblock 288 238 495 minecraft:shroomlight
setblock 288 238 497 minecraft:shroomlight
setblock 288 238 499 minecraft:shroomlight
setblock 288 238 501 minecraft:shroomlight
setblock 289 238 490 minecraft:shroomlight
setblock 289 238 492 minecraft:shroomlight
setblock 289 238 494 minecraft:shroomlight
setblock 289 238 496 minecraft:shroomlight
setblock 289 238 498 minecraft:shroomlight
setblock 289 238 500 minecraft:shroomlight
setblock 289 238 502 minecraft:shroomlight
setblock 289 238 504 minecraft:shroomlight
setblock 290 238 491 minecraft:shroomlight
setblock 290 238 493 minecraft:shroomlight
setblock 290 238 495 minecraft:shroomlight
setblock 290 238 497 minecraft:shroomlight
setblock 290 238 499 minecraft:shroomlight
setblock 290 238 501 minecraft:shroomlight
setblock 290 238 503 minecraft:shroomlight
setblock 291 238 490 minecraft:shroomlight
setblock 291 238 492 minecraft:shroomlight
setblock 291 238 494 minecraft:shroomlight
setblock 291 238 496 minecraft:shroomlight
setblock 291 238 498 minecraft:shroomlight
setblock 291 238 500 minecraft:shroomlight
setblock 291 238 502 minecraft:shroomlight
setblock 291 238 504 minecraft:shroomlight
setblock 292 238 491 minecraft:shroomlight
setblock 292 238 493 minecraft:shroomlight
setblock 292 238 495 minecraft:shroomlight
setblock 292 238 497 minecraft:shroomlight
setblock 292 238 499 minecraft:shroomlight
setblock 292 238 501 minecraft:shroomlight
setblock 292 238 503 minecraft:shroomlight
setblock 293 238 496 minecraft:shroomlight
setblock 293 238 498 minecraft:shroomlight
setblock 293 238 500 minecraft:shroomlight
setblock 293 238 502 minecraft:shroomlight
setblock 293 238 504 minecraft:shroomlight
setblock 294 238 495 minecraft:shroomlight
setblock 294 238 497 minecraft:shroomlight
setblock 294 238 499 minecraft:shroomlight
setblock 294 238 501 minecraft:shroomlight
setblock 294 238 503 minecraft:shroomlight
setblock 295 238 496 minecraft:shroomlight
setblock 295 238 498 minecraft:shroomlight
setblock 295 238 500 minecraft:shroomlight
setblock 295 238 502 minecraft:shroomlight
setblock 295 238 504 minecraft:shroomlight
setblock 296 238 495 minecraft:shroomlight
setblock 296 238 497 minecraft:shroomlight
setblock 296 238 499 minecraft:shroomlight
setblock 296 238 501 minecraft:shroomlight
setblock 296 238 503 minecraft:shroomlight
setblock 297 238 496 minecraft:shroomlight
setblock 297 238 498 minecraft:shroomlight
setblock 297 238 500 minecraft:shroomlight
setblock 297 238 502 minecraft:shroomlight
setblock 297 238 504 minecraft:shroomlight
setblock 298 238 495 minecraft:shroomlight
setblock 298 238 497 minecraft:shroomlight
setblock 298 238 499 minecraft:shroomlight
setblock 298 238 501 minecraft:shroomlight
setblock 298 238 503 minecraft:shroomlight
setblock 299 238 496 minecraft:shroomlight
setblock 299 238 498 minecraft:shroomlight
setblock 299 238 500 minecraft:shroomlight
setblock 299 238 502 minecraft:shroomlight
setblock 299 238 504 minecraft:shroomlight
setblock 300 238 495 minecraft:shroomlight
setblock 300 238 497 minecraft:shroomlight
setblock 300 238 499 minecraft:shroomlight
setblock 300 238 501 minecraft:shroomlight
setblock 300 238 503 minecraft:shroomlight
setblock 301 238 496 minecraft:shroomlight
setblock 301 238 498 minecraft:shroomlight
setblock 301 238 500 minecraft:shroomlight
setblock 301 238 502 minecraft:shroomlight
setblock 301 238 504 minecraft:shroomlight
setblock 302 238 499 minecraft:shroomlight
setblock 302 238 501 minecraft:shroomlight
setblock 302 238 503 minecraft:shroomlight
setblock 303 238 498 minecraft:shroomlight
setblock 303 238 500 minecraft:shroomlight
setblock 303 238 502 minecraft:shroomlight
setblock 303 238 504 minecraft:shroomlight
setblock 304 238 499 minecraft:shroomlight
setblock 304 238 501 minecraft:shroomlight
setblock 304 238 503 minecraft:shroomlight
setblock 305 238 498 minecraft:shroomlight
setblock 305 238 500 minecraft:shroomlight
setblock 305 238 502 minecraft:shroomlight
setblock 305 238 504 minecraft:shroomlight
setblock 306 238 499 minecraft:shroomlight
setblock 306 238 501 minecraft:shroomlight
setblock 306 238 503 minecraft:shroomlight
setblock 307 238 498 minecraft:shroomlight
setblock 307 238 500 minecraft:shroomlight
setblock 307 238 502 minecraft:shroomlight
setblock 307 238 504 minecraft:shroomlight
setblock 308 238 499 minecraft:shroomlight
setblock 308 238 501 minecraft:shroomlight
setblock 308 238 503 minecraft:shroomlight
setblock 309 238 498 minecraft:shroomlight
setblock 309 238 500 minecraft:shroomlight
setblock 309 238 502 minecraft:shroomlight
setblock 309 238 504 minecraft:shroomlight
setblock 310 238 499 minecraft:shroomlight
setblock 310 238 501 minecraft:shroomlight
setblock 310 238 503 minecraft:shroomlight
fill 283 239 490 283 240 490 minecraft:polished_blackstone_bricks
fill 283 239 492 283 240 492 minecraft:polished_blackstone_bricks
fill 283 239 494 283 240 494 minecraft:polished_blackstone_bricks
fill 283 239 496 283 240 496 minecraft:polished_blackstone_bricks
fill 283 239 498 283 240 498 minecraft:polished_blackstone_bricks
fill 283 239 500 283 240 500 minecraft:polished_blackstone_bricks
fill 283 239 502 283 240 502 minecraft:polished_blackstone_bricks
fill 284 239 491 284 240 491 minecraft:polished_blackstone_bricks
fill 284 239 493 284 240 493 minecraft:polished_blackstone_bricks
fill 284 239 495 284 240 495 minecraft:polished_blackstone_bricks
fill 284 239 497 284 240 497 minecraft:polished_blackstone_bricks
fill 284 239 499 284 240 499 minecraft:polished_blackstone_bricks
fill 284 239 501 284 240 501 minecraft:polished_blackstone_bricks
setblock 285 239 466 minecraft:light[level=14]
setblock 285 239 474 minecraft:light[level=14]
setblock 285 239 482 minecraft:light[level=14]
fill 285 239 490 285 240 490 minecraft:polished_blackstone_bricks
fill 285 239 492 285 240 492 minecraft:polished_blackstone_bricks
fill 285 239 494 285 240 494 minecraft:polished_blackstone_bricks
fill 285 239 496 285 240 496 minecraft:polished_blackstone_bricks
fill 285 239 498 285 240 498 minecraft:polished_blackstone_bricks
fill 285 239 500 285 240 500 minecraft:polished_blackstone_bricks
fill 285 239 502 285 240 502 minecraft:polished_blackstone_bricks
fill 286 239 491 286 240 491 minecraft:polished_blackstone_bricks
fill 286 239 493 286 240 493 minecraft:polished_blackstone_bricks
fill 286 239 495 286 240 495 minecraft:polished_blackstone_bricks
fill 286 239 497 286 240 497 minecraft:polished_blackstone_bricks
fill 286 239 499 286 240 499 minecraft:polished_blackstone_bricks
fill 286 239 501 286 240 501 minecraft:polished_blackstone_bricks
fill 287 239 490 287 240 490 minecraft:polished_blackstone_bricks
fill 287 239 492 287 240 492 minecraft:polished_blackstone_bricks
fill 287 239 494 287 240 494 minecraft:polished_blackstone_bricks
fill 287 239 496 287 240 496 minecraft:polished_blackstone_bricks
fill 287 239 498 287 240 498 minecraft:polished_blackstone_bricks
fill 287 239 500 287 240 500 minecraft:polished_blackstone_bricks
fill 287 239 502 287 240 502 minecraft:polished_blackstone_bricks
fill 288 239 491 288 240 491 minecraft:polished_blackstone_bricks
fill 288 239 493 288 240 493 minecraft:polished_blackstone_bricks
fill 288 239 495 288 240 495 minecraft:polished_blackstone_bricks
fill 288 239 497 288 240 497 minecraft:polished_blackstone_bricks
fill 288 239 499 288 240 499 minecraft:polished_blackstone_bricks
fill 288 239 501 288 240 501 minecraft:polished_blackstone_bricks
fill 289 239 490 289 240 490 minecraft:polished_blackstone_bricks
fill 289 239 492 289 240 492 minecraft:polished_blackstone_bricks
fill 289 239 494 289 240 494 minecraft:polished_blackstone_bricks
fill 289 239 496 289 240 496 minecraft:polished_blackstone_bricks
fill 289 239 498 289 240 498 minecraft:polished_blackstone_bricks
fill 289 239 500 289 240 500 minecraft:polished_blackstone_bricks
fill 289 239 502 289 240 502 minecraft:polished_blackstone_bricks
fill 289 239 504 289 240 504 minecraft:polished_blackstone_bricks
fill 290 239 491 290 240 491 minecraft:polished_blackstone_bricks
fill 290 239 493 290 240 493 minecraft:polished_blackstone_bricks
fill 290 239 495 290 240 495 minecraft:polished_blackstone_bricks
fill 290 239 497 290 240 497 minecraft:polished_blackstone_bricks
fill 290 239 499 290 240 499 minecraft:polished_blackstone_bricks
fill 290 239 501 290 240 501 minecraft:polished_blackstone_bricks
fill 290 239 503 290 240 503 minecraft:polished_blackstone_bricks
fill 291 239 490 291 240 490 minecraft:polished_blackstone_bricks
fill 291 239 492 291 240 492 minecraft:polished_blackstone_bricks
fill 291 239 494 291 240 494 minecraft:polished_blackstone_bricks
fill 291 239 496 291 240 496 minecraft:polished_blackstone_bricks
fill 291 239 498 291 240 498 minecraft:polished_blackstone_bricks
fill 291 239 500 291 240 500 minecraft:polished_blackstone_bricks
fill 291 239 502 291 240 502 minecraft:polished_blackstone_bricks
fill 291 239 504 291 240 504 minecraft:polished_blackstone_bricks
fill 292 239 491 292 240 491 minecraft:polished_blackstone_bricks
fill 292 239 493 292 240 493 minecraft:polished_blackstone_bricks
fill 292 239 495 292 240 495 minecraft:polished_blackstone_bricks
fill 292 239 497 292 240 497 minecraft:polished_blackstone_bricks
fill 292 239 499 292 240 499 minecraft:polished_blackstone_bricks
fill 292 239 501 292 240 501 minecraft:polished_blackstone_bricks
fill 292 239 503 292 240 503 minecraft:polished_blackstone_bricks
setblock 293 239 466 minecraft:light[level=14]
setblock 293 239 474 minecraft:light[level=14]
setblock 293 239 482 minecraft:light[level=14]
setblock 293 239 490 minecraft:light[level=14]
fill 293 239 496 293 240 496 minecraft:polished_blackstone_bricks
fill 293 239 498 293 240 498 minecraft:polished_blackstone_bricks
fill 293 239 500 293 240 500 minecraft:polished_blackstone_bricks
fill 293 239 502 293 240 502 minecraft:polished_blackstone_bricks
fill 293 239 504 293 240 504 minecraft:polished_blackstone_bricks
fill 294 239 495 294 240 495 minecraft:polished_blackstone_bricks
fill 294 239 497 294 240 497 minecraft:polished_blackstone_bricks
fill 294 239 499 294 240 499 minecraft:polished_blackstone_bricks
fill 294 239 501 294 240 501 minecraft:polished_blackstone_bricks
fill 294 239 503 294 240 503 minecraft:polished_blackstone_bricks
fill 295 239 496 295 240 496 minecraft:polished_blackstone_bricks
fill 295 239 498 295 240 498 minecraft:polished_blackstone_bricks
fill 295 239 500 295 240 500 minecraft:polished_blackstone_bricks
fill 295 239 502 295 240 502 minecraft:polished_blackstone_bricks
fill 295 239 504 295 240 504 minecraft:polished_blackstone_bricks
fill 296 239 495 296 240 495 minecraft:polished_blackstone_bricks
fill 296 239 497 296 240 497 minecraft:polished_blackstone_bricks
fill 296 239 499 296 240 499 minecraft:polished_blackstone_bricks
fill 296 239 501 296 240 501 minecraft:polished_blackstone_bricks
fill 296 239 503 296 240 503 minecraft:polished_blackstone_bricks
fill 297 239 496 297 240 496 minecraft:polished_blackstone_bricks
fill 297 239 498 297 240 498 minecraft:polished_blackstone_bricks
fill 297 239 500 297 240 500 minecraft:polished_blackstone_bricks
fill 297 239 502 297 240 502 minecraft:polished_blackstone_bricks
fill 297 239 504 297 240 504 minecraft:polished_blackstone_bricks
fill 298 239 495 298 240 495 minecraft:polished_blackstone_bricks
fill 298 239 497 298 240 497 minecraft:polished_blackstone_bricks
fill 298 239 499 298 240 499 minecraft:polished_blackstone_bricks
fill 298 239 501 298 240 501 minecraft:polished_blackstone_bricks
fill 298 239 503 298 240 503 minecraft:polished_blackstone_bricks
fill 299 239 496 299 240 496 minecraft:polished_blackstone_bricks
fill 299 239 498 299 240 498 minecraft:polished_blackstone_bricks
fill 299 239 500 299 240 500 minecraft:polished_blackstone_bricks
fill 299 239 502 299 240 502 minecraft:polished_blackstone_bricks
fill 299 239 504 299 240 504 minecraft:polished_blackstone_bricks
fill 300 239 495 300 240 495 minecraft:polished_blackstone_bricks
fill 300 239 497 300 240 497 minecraft:polished_blackstone_bricks
fill 300 239 499 300 240 499 minecraft:polished_blackstone_bricks
fill 300 239 501 300 240 501 minecraft:polished_blackstone_bricks
fill 300 239 503 300 240 503 minecraft:polished_blackstone_bricks
setblock 301 239 466 minecraft:light[level=14]
setblock 301 239 474 minecraft:light[level=14]
setblock 301 239 482 minecraft:light[level=14]
setblock 301 239 490 minecraft:light[level=14]
fill 301 239 496 301 240 496 minecraft:polished_blackstone_bricks
fill 301 239 498 301 240 498 minecraft:polished_blackstone_bricks
fill 301 239 500 301 240 500 minecraft:polished_blackstone_bricks
fill 301 239 502 301 240 502 minecraft:polished_blackstone_bricks
fill 301 239 504 301 240 504 minecraft:polished_blackstone_bricks
fill 302 239 499 302 240 499 minecraft:polished_blackstone_bricks
fill 302 239 501 302 240 501 minecraft:polished_blackstone_bricks
fill 302 239 503 302 240 503 minecraft:polished_blackstone_bricks
fill 303 239 498 303 240 498 minecraft:polished_blackstone_bricks
fill 303 239 500 303 240 500 minecraft:polished_blackstone_bricks
fill 303 239 502 303 240 502 minecraft:polished_blackstone_bricks
fill 303 239 504 303 240 504 minecraft:polished_blackstone_bricks
fill 304 239 499 304 240 499 minecraft:polished_blackstone_bricks
fill 304 239 501 304 240 501 minecraft:polished_blackstone_bricks
fill 304 239 503 304 240 503 minecraft:polished_blackstone_bricks
fill 305 239 498 305 240 498 minecraft:polished_blackstone_bricks
fill 305 239 500 305 240 500 minecraft:polished_blackstone_bricks
fill 305 239 502 305 240 502 minecraft:polished_blackstone_bricks
fill 305 239 504 305 240 504 minecraft:polished_blackstone_bricks
fill 306 239 499 306 240 499 minecraft:polished_blackstone_bricks
fill 306 239 501 306 240 501 minecraft:polished_blackstone_bricks
fill 306 239 503 306 240 503 minecraft:polished_blackstone_bricks
fill 307 239 498 307 240 498 minecraft:polished_blackstone_bricks
fill 307 239 500 307 240 500 minecraft:polished_blackstone_bricks
fill 307 239 502 307 240 502 minecraft:polished_blackstone_bricks
fill 307 239 504 307 240 504 minecraft:polished_blackstone_bricks
fill 308 239 499 308 240 499 minecraft:polished_blackstone_bricks
fill 308 239 501 308 240 501 minecraft:polished_blackstone_bricks
fill 308 239 503 308 240 503 minecraft:polished_blackstone_bricks
setblock 309 239 466 minecraft:light[level=14]
setblock 309 239 474 minecraft:light[level=14]
setblock 309 239 482 minecraft:light[level=14]
setblock 309 239 490 minecraft:light[level=14]
fill 309 239 498 309 240 498 minecraft:polished_blackstone_bricks
fill 309 239 500 309 240 500 minecraft:polished_blackstone_bricks
fill 309 239 502 309 240 502 minecraft:polished_blackstone_bricks
fill 309 239 504 309 240 504 minecraft:polished_blackstone_bricks
fill 310 239 499 310 240 499 minecraft:polished_blackstone_bricks
fill 310 239 501 310 240 501 minecraft:polished_blackstone_bricks
fill 310 239 503 310 240 503 minecraft:polished_blackstone_bricks
setblock 317 239 466 minecraft:light[level=14]
setblock 317 239 474 minecraft:light[level=14]
setblock 317 239 482 minecraft:light[level=14]
setblock 317 239 490 minecraft:light[level=14]
fill 284 240 473 284 245 475 minecraft:polished_blackstone_bricks
fill 284 240 485 284 245 487 minecraft:polished_blackstone_bricks
fill 294 240 465 296 245 465 minecraft:polished_blackstone_bricks
fill 306 240 465 308 245 465 minecraft:polished_blackstone_bricks
fill 314 240 503 315 245 503 minecraft:polished_blackstone_bricks
fill 318 240 465 320 245 465 minecraft:polished_blackstone_bricks
fill 322 240 473 322 245 475 minecraft:polished_blackstone_bricks
fill 322 240 485 322 245 487 minecraft:polished_blackstone_bricks
setblock 283 241 490 minecraft:shroomlight
setblock 283 241 492 minecraft:shroomlight
setblock 283 241 494 minecraft:shroomlight
setblock 283 241 496 minecraft:shroomlight
setblock 283 241 498 minecraft:shroomlight
setblock 283 241 500 minecraft:shroomlight
setblock 283 241 502 minecraft:shroomlight
setblock 284 241 491 minecraft:shroomlight
setblock 284 241 493 minecraft:shroomlight
setblock 284 241 495 minecraft:shroomlight
setblock 284 241 497 minecraft:shroomlight
setblock 284 241 499 minecraft:shroomlight
setblock 284 241 501 minecraft:shroomlight
setblock 285 241 490 minecraft:shroomlight
setblock 285 241 492 minecraft:shroomlight
setblock 285 241 494 minecraft:shroomlight
setblock 285 241 496 minecraft:shroomlight
setblock 285 241 498 minecraft:shroomlight
setblock 285 241 500 minecraft:shroomlight
setblock 285 241 502 minecraft:shroomlight
setblock 286 241 491 minecraft:shroomlight
setblock 286 241 493 minecraft:shroomlight
setblock 286 241 495 minecraft:shroomlight
setblock 286 241 497 minecraft:shroomlight
setblock 286 241 499 minecraft:shroomlight
setblock 286 241 501 minecraft:shroomlight
setblock 287 241 490 minecraft:shroomlight
setblock 287 241 492 minecraft:shroomlight
setblock 287 241 494 minecraft:shroomlight
setblock 287 241 496 minecraft:shroomlight
setblock 287 241 498 minecraft:shroomlight
setblock 287 241 500 minecraft:shroomlight
setblock 287 241 502 minecraft:shroomlight
setblock 288 241 491 minecraft:shroomlight
setblock 288 241 493 minecraft:shroomlight
setblock 288 241 495 minecraft:shroomlight
setblock 288 241 497 minecraft:shroomlight
setblock 288 241 499 minecraft:shroomlight
setblock 288 241 501 minecraft:shroomlight
setblock 289 241 490 minecraft:shroomlight
setblock 289 241 492 minecraft:shroomlight
setblock 289 241 494 minecraft:shroomlight
setblock 289 241 496 minecraft:shroomlight
setblock 289 241 498 minecraft:shroomlight
setblock 289 241 500 minecraft:shroomlight
setblock 289 241 502 minecraft:shroomlight
setblock 289 241 504 minecraft:shroomlight
setblock 290 241 491 minecraft:shroomlight
setblock 290 241 493 minecraft:shroomlight
setblock 290 241 495 minecraft:shroomlight
setblock 290 241 497 minecraft:shroomlight
setblock 290 241 499 minecraft:shroomlight
setblock 290 241 501 minecraft:shroomlight
setblock 290 241 503 minecraft:shroomlight
setblock 291 241 490 minecraft:shroomlight
setblock 291 241 492 minecraft:shroomlight
setblock 291 241 494 minecraft:shroomlight
setblock 291 241 496 minecraft:shroomlight
setblock 291 241 498 minecraft:shroomlight
setblock 291 241 500 minecraft:shroomlight
setblock 291 241 502 minecraft:shroomlight
setblock 291 241 504 minecraft:shroomlight
setblock 292 241 491 minecraft:shroomlight
setblock 292 241 493 minecraft:shroomlight
setblock 292 241 495 minecraft:shroomlight
setblock 292 241 497 minecraft:shroomlight
setblock 292 241 499 minecraft:shroomlight
setblock 292 241 501 minecraft:shroomlight
setblock 292 241 503 minecraft:shroomlight
setblock 293 241 496 minecraft:shroomlight
setblock 293 241 498 minecraft:shroomlight
setblock 293 241 500 minecraft:shroomlight
setblock 293 241 502 minecraft:shroomlight
setblock 293 241 504 minecraft:shroomlight
setblock 294 241 495 minecraft:shroomlight
setblock 294 241 497 minecraft:shroomlight
setblock 294 241 499 minecraft:shroomlight
setblock 294 241 501 minecraft:shroomlight
setblock 294 241 503 minecraft:shroomlight
setblock 295 241 496 minecraft:shroomlight
setblock 295 241 498 minecraft:shroomlight
setblock 295 241 500 minecraft:shroomlight
setblock 295 241 502 minecraft:shroomlight
setblock 295 241 504 minecraft:shroomlight
setblock 296 241 495 minecraft:shroomlight
setblock 296 241 497 minecraft:shroomlight
setblock 296 241 499 minecraft:shroomlight
setblock 296 241 501 minecraft:shroomlight
setblock 296 241 503 minecraft:shroomlight
setblock 297 241 496 minecraft:shroomlight
setblock 297 241 498 minecraft:shroomlight
setblock 297 241 500 minecraft:shroomlight
setblock 297 241 502 minecraft:shroomlight
setblock 297 241 504 minecraft:shroomlight
setblock 298 241 495 minecraft:shroomlight
setblock 298 241 497 minecraft:shroomlight
setblock 298 241 499 minecraft:shroomlight
setblock 298 241 501 minecraft:shroomlight
setblock 298 241 503 minecraft:shroomlight
setblock 299 241 496 minecraft:shroomlight
setblock 299 241 498 minecraft:shroomlight
setblock 299 241 500 minecraft:shroomlight
setblock 299 241 502 minecraft:shroomlight
setblock 299 241 504 minecraft:shroomlight
setblock 300 241 495 minecraft:shroomlight
setblock 300 241 497 minecraft:shroomlight
setblock 300 241 499 minecraft:shroomlight
setblock 300 241 501 minecraft:shroomlight
setblock 300 241 503 minecraft:shroomlight
setblock 301 241 496 minecraft:shroomlight
setblock 301 241 498 minecraft:shroomlight
setblock 301 241 500 minecraft:shroomlight
setblock 301 241 502 minecraft:shroomlight
setblock 301 241 504 minecraft:shroomlight
setblock 302 241 499 minecraft:shroomlight
setblock 302 241 501 minecraft:shroomlight
setblock 302 241 503 minecraft:shroomlight
setblock 303 241 498 minecraft:shroomlight
setblock 303 241 500 minecraft:shroomlight
setblock 303 241 502 minecraft:shroomlight
setblock 303 241 504 minecraft:shroomlight
setblock 304 241 499 minecraft:shroomlight
setblock 304 241 501 minecraft:shroomlight
setblock 304 241 503 minecraft:shroomlight
setblock 305 241 498 minecraft:shroomlight
setblock 305 241 500 minecraft:shroomlight
setblock 305 241 502 minecraft:shroomlight
setblock 305 241 504 minecraft:shroomlight
setblock 306 241 499 minecraft:shroomlight
setblock 306 241 501 minecraft:shroomlight
setblock 306 241 503 minecraft:shroomlight
setblock 307 241 498 minecraft:shroomlight
setblock 307 241 500 minecraft:shroomlight
setblock 307 241 502 minecraft:shroomlight
setblock 307 241 504 minecraft:shroomlight
setblock 308 241 499 minecraft:shroomlight
setblock 308 241 501 minecraft:shroomlight
setblock 308 241 503 minecraft:shroomlight
setblock 309 241 498 minecraft:shroomlight
setblock 309 241 500 minecraft:shroomlight
setblock 309 241 502 minecraft:shroomlight
setblock 309 241 504 minecraft:shroomlight
setblock 310 241 499 minecraft:shroomlight
setblock 310 241 501 minecraft:shroomlight
setblock 310 241 503 minecraft:shroomlight
fill 283 242 490 283 243 490 minecraft:polished_blackstone_bricks
fill 283 242 492 283 243 492 minecraft:polished_blackstone_bricks
fill 283 242 494 283 243 494 minecraft:polished_blackstone_bricks
fill 283 242 496 283 243 496 minecraft:polished_blackstone_bricks
fill 283 242 498 283 243 498 minecraft:polished_blackstone_bricks
fill 283 242 500 283 243 500 minecraft:polished_blackstone_bricks
fill 283 242 502 283 243 502 minecraft:polished_blackstone_bricks
fill 284 242 491 284 243 491 minecraft:polished_blackstone_bricks
fill 284 242 493 284 243 493 minecraft:polished_blackstone_bricks
fill 284 242 495 284 243 495 minecraft:polished_blackstone_bricks
fill 284 242 497 284 243 497 minecraft:polished_blackstone_bricks
fill 284 242 499 284 243 499 minecraft:polished_blackstone_bricks
fill 284 242 501 284 243 501 minecraft:polished_blackstone_bricks
fill 285 242 490 285 243 490 minecraft:polished_blackstone_bricks
fill 285 242 492 285 243 492 minecraft:polished_blackstone_bricks
fill 285 242 494 285 243 494 minecraft:polished_blackstone_bricks
fill 285 242 496 285 243 496 minecraft:polished_blackstone_bricks
fill 285 242 498 285 243 498 minecraft:polished_blackstone_bricks
fill 285 242 500 285 243 500 minecraft:polished_blackstone_bricks
fill 285 242 502 285 243 502 minecraft:polished_blackstone_bricks
fill 286 242 491 286 243 491 minecraft:polished_blackstone_bricks
fill 286 242 493 286 243 493 minecraft:polished_blackstone_bricks
fill 286 242 495 286 243 495 minecraft:polished_blackstone_bricks
fill 286 242 497 286 243 497 minecraft:polished_blackstone_bricks
fill 286 242 499 286 243 499 minecraft:polished_blackstone_bricks
fill 286 242 501 286 243 501 minecraft:polished_blackstone_bricks
fill 287 242 490 287 243 490 minecraft:polished_blackstone_bricks
fill 287 242 492 287 243 492 minecraft:polished_blackstone_bricks
fill 287 242 494 287 243 494 minecraft:polished_blackstone_bricks
fill 287 242 496 287 243 496 minecraft:polished_blackstone_bricks
fill 287 242 498 287 243 498 minecraft:polished_blackstone_bricks
fill 287 242 500 287 243 500 minecraft:polished_blackstone_bricks
fill 287 242 502 287 243 502 minecraft:polished_blackstone_bricks
fill 288 242 491 288 243 491 minecraft:polished_blackstone_bricks
fill 288 242 493 288 243 493 minecraft:polished_blackstone_bricks
fill 288 242 495 288 243 495 minecraft:polished_blackstone_bricks
fill 288 242 497 288 243 497 minecraft:polished_blackstone_bricks
fill 288 242 499 288 243 499 minecraft:polished_blackstone_bricks
fill 288 242 501 288 243 501 minecraft:polished_blackstone_bricks
fill 289 242 490 289 243 490 minecraft:polished_blackstone_bricks
fill 289 242 492 289 243 492 minecraft:polished_blackstone_bricks
fill 289 242 494 289 243 494 minecraft:polished_blackstone_bricks
fill 289 242 496 289 243 496 minecraft:polished_blackstone_bricks
fill 289 242 498 289 243 498 minecraft:polished_blackstone_bricks
fill 289 242 500 289 243 500 minecraft:polished_blackstone_bricks
fill 289 242 502 289 243 502 minecraft:polished_blackstone_bricks
fill 289 242 504 289 243 504 minecraft:polished_blackstone_bricks
fill 290 242 491 290 243 491 minecraft:polished_blackstone_bricks
fill 290 242 493 290 243 493 minecraft:polished_blackstone_bricks
fill 290 242 495 290 243 495 minecraft:polished_blackstone_bricks
fill 290 242 497 290 243 497 minecraft:polished_blackstone_bricks
fill 290 242 499 290 243 499 minecraft:polished_blackstone_bricks
fill 290 242 501 290 243 501 minecraft:polished_blackstone_bricks
fill 290 242 503 290 243 503 minecraft:polished_blackstone_bricks
fill 291 242 490 291 243 490 minecraft:polished_blackstone_bricks
fill 291 242 492 291 243 492 minecraft:polished_blackstone_bricks
fill 291 242 494 291 243 494 minecraft:polished_blackstone_bricks
fill 291 242 496 291 243 496 minecraft:polished_blackstone_bricks
fill 291 242 498 291 243 498 minecraft:polished_blackstone_bricks
fill 291 242 500 291 243 500 minecraft:polished_blackstone_bricks
fill 291 242 502 291 243 502 minecraft:polished_blackstone_bricks
fill 291 242 504 291 243 504 minecraft:polished_blackstone_bricks
fill 292 242 491 292 243 491 minecraft:polished_blackstone_bricks
fill 292 242 493 292 243 493 minecraft:polished_blackstone_bricks
fill 292 242 495 292 243 495 minecraft:polished_blackstone_bricks
fill 292 242 497 292 243 497 minecraft:polished_blackstone_bricks
fill 292 242 499 292 243 499 minecraft:polished_blackstone_bricks
fill 292 242 501 292 243 501 minecraft:polished_blackstone_bricks
fill 292 242 503 292 243 503 minecraft:polished_blackstone_bricks
fill 293 242 496 293 243 496 minecraft:polished_blackstone_bricks
fill 293 242 498 293 243 498 minecraft:polished_blackstone_bricks
fill 293 242 500 293 243 500 minecraft:polished_blackstone_bricks
fill 293 242 502 293 243 502 minecraft:polished_blackstone_bricks
fill 293 242 504 293 243 504 minecraft:polished_blackstone_bricks
fill 294 242 495 294 243 495 minecraft:polished_blackstone_bricks
fill 294 242 497 294 243 497 minecraft:polished_blackstone_bricks
fill 294 242 499 294 243 499 minecraft:polished_blackstone_bricks
fill 294 242 501 294 243 501 minecraft:polished_blackstone_bricks
fill 294 242 503 294 243 503 minecraft:polished_blackstone_bricks
fill 295 242 496 295 243 496 minecraft:polished_blackstone_bricks
fill 295 242 498 295 243 498 minecraft:polished_blackstone_bricks
fill 295 242 500 295 243 500 minecraft:polished_blackstone_bricks
fill 295 242 502 295 243 502 minecraft:polished_blackstone_bricks
fill 295 242 504 295 243 504 minecraft:polished_blackstone_bricks
fill 296 242 495 296 243 495 minecraft:polished_blackstone_bricks
fill 296 242 497 296 243 497 minecraft:polished_blackstone_bricks
fill 296 242 499 296 243 499 minecraft:polished_blackstone_bricks
fill 296 242 501 296 243 501 minecraft:polished_blackstone_bricks
fill 296 242 503 296 243 503 minecraft:polished_blackstone_bricks
fill 297 242 496 297 243 496 minecraft:polished_blackstone_bricks
fill 297 242 498 297 243 498 minecraft:polished_blackstone_bricks
fill 297 242 500 297 243 500 minecraft:polished_blackstone_bricks
fill 297 242 502 297 243 502 minecraft:polished_blackstone_bricks
fill 297 242 504 297 243 504 minecraft:polished_blackstone_bricks
fill 298 242 495 298 243 495 minecraft:polished_blackstone_bricks
fill 298 242 497 298 243 497 minecraft:polished_blackstone_bricks
fill 298 242 499 298 243 499 minecraft:polished_blackstone_bricks
fill 298 242 501 298 243 501 minecraft:polished_blackstone_bricks
fill 298 242 503 298 243 503 minecraft:polished_blackstone_bricks
fill 299 242 496 299 243 496 minecraft:polished_blackstone_bricks
fill 299 242 498 299 243 498 minecraft:polished_blackstone_bricks
fill 299 242 500 299 243 500 minecraft:polished_blackstone_bricks
fill 299 242 502 299 243 502 minecraft:polished_blackstone_bricks
fill 299 242 504 299 243 504 minecraft:polished_blackstone_bricks
fill 300 242 495 300 243 495 minecraft:polished_blackstone_bricks
fill 300 242 497 300 243 497 minecraft:polished_blackstone_bricks
fill 300 242 499 300 243 499 minecraft:polished_blackstone_bricks
fill 300 242 501 300 243 501 minecraft:polished_blackstone_bricks
fill 300 242 503 300 243 503 minecraft:polished_blackstone_bricks
fill 301 242 496 301 243 496 minecraft:polished_blackstone_bricks
fill 301 242 498 301 243 498 minecraft:polished_blackstone_bricks
fill 301 242 500 301 243 500 minecraft:polished_blackstone_bricks
fill 301 242 502 301 243 502 minecraft:polished_blackstone_bricks
fill 301 242 504 301 243 504 minecraft:polished_blackstone_bricks
fill 302 242 499 302 243 499 minecraft:polished_blackstone_bricks
fill 302 242 501 302 243 501 minecraft:polished_blackstone_bricks
fill 302 242 503 302 243 503 minecraft:polished_blackstone_bricks
fill 303 242 498 303 243 498 minecraft:polished_blackstone_bricks
fill 303 242 500 303 243 500 minecraft:polished_blackstone_bricks
fill 303 242 502 303 243 502 minecraft:polished_blackstone_bricks
fill 303 242 504 303 243 504 minecraft:polished_blackstone_bricks
fill 304 242 499 304 243 499 minecraft:polished_blackstone_bricks
fill 304 242 501 304 243 501 minecraft:polished_blackstone_bricks
fill 304 242 503 304 243 503 minecraft:polished_blackstone_bricks
fill 305 242 498 305 243 498 minecraft:polished_blackstone_bricks
fill 305 242 500 305 243 500 minecraft:polished_blackstone_bricks
fill 305 242 502 305 243 502 minecraft:polished_blackstone_bricks
fill 305 242 504 305 243 504 minecraft:polished_blackstone_bricks
fill 306 242 499 306 243 499 minecraft:polished_blackstone_bricks
fill 306 242 501 306 243 501 minecraft:polished_blackstone_bricks
fill 306 242 503 306 243 503 minecraft:polished_blackstone_bricks
fill 307 242 498 307 243 498 minecraft:polished_blackstone_bricks
fill 307 242 500 307 243 500 minecraft:polished_blackstone_bricks
fill 307 242 502 307 243 502 minecraft:polished_blackstone_bricks
fill 307 242 504 307 243 504 minecraft:polished_blackstone_bricks
fill 308 242 499 308 243 499 minecraft:polished_blackstone_bricks
fill 308 242 501 308 243 501 minecraft:polished_blackstone_bricks
fill 308 242 503 308 243 503 minecraft:polished_blackstone_bricks
fill 309 242 498 309 243 498 minecraft:polished_blackstone_bricks
fill 309 242 500 309 243 500 minecraft:polished_blackstone_bricks
fill 309 242 502 309 243 502 minecraft:polished_blackstone_bricks
fill 309 242 504 309 243 504 minecraft:polished_blackstone_bricks
fill 310 242 499 310 243 499 minecraft:polished_blackstone_bricks
fill 310 242 501 310 243 501 minecraft:polished_blackstone_bricks
fill 310 242 503 310 243 503 minecraft:polished_blackstone_bricks
setblock 283 244 490 minecraft:shroomlight
setblock 283 244 492 minecraft:shroomlight
setblock 283 244 494 minecraft:shroomlight
setblock 283 244 496 minecraft:shroomlight
setblock 283 244 498 minecraft:shroomlight
setblock 283 244 500 minecraft:shroomlight
setblock 283 244 502 minecraft:shroomlight
setblock 284 244 491 minecraft:shroomlight
setblock 284 244 493 minecraft:shroomlight
setblock 284 244 495 minecraft:shroomlight
setblock 284 244 497 minecraft:shroomlight
setblock 284 244 499 minecraft:shroomlight
setblock 284 244 501 minecraft:shroomlight
setblock 285 244 490 minecraft:shroomlight
setblock 285 244 492 minecraft:shroomlight
setblock 285 244 494 minecraft:shroomlight
setblock 285 244 496 minecraft:shroomlight
setblock 285 244 498 minecraft:shroomlight
setblock 285 244 500 minecraft:shroomlight
setblock 285 244 502 minecraft:shroomlight
setblock 286 244 491 minecraft:shroomlight
setblock 286 244 493 minecraft:shroomlight
setblock 286 244 495 minecraft:shroomlight
setblock 286 244 497 minecraft:shroomlight
setblock 286 244 499 minecraft:shroomlight
setblock 286 244 501 minecraft:shroomlight
setblock 287 244 490 minecraft:shroomlight
setblock 287 244 492 minecraft:shroomlight
setblock 287 244 494 minecraft:shroomlight
setblock 287 244 496 minecraft:shroomlight
setblock 287 244 498 minecraft:shroomlight
setblock 287 244 500 minecraft:shroomlight
setblock 287 244 502 minecraft:shroomlight
setblock 288 244 491 minecraft:shroomlight
setblock 288 244 493 minecraft:shroomlight
setblock 288 244 495 minecraft:shroomlight
setblock 288 244 497 minecraft:shroomlight
setblock 288 244 499 minecraft:shroomlight
setblock 288 244 501 minecraft:shroomlight
setblock 289 244 490 minecraft:shroomlight
setblock 289 244 492 minecraft:shroomlight
setblock 289 244 494 minecraft:shroomlight
setblock 289 244 496 minecraft:shroomlight
setblock 289 244 498 minecraft:shroomlight
setblock 289 244 500 minecraft:shroomlight
setblock 289 244 502 minecraft:shroomlight
setblock 289 244 504 minecraft:shroomlight
setblock 290 244 491 minecraft:shroomlight
setblock 290 244 493 minecraft:shroomlight
setblock 290 244 495 minecraft:shroomlight
setblock 290 244 497 minecraft:shroomlight
setblock 290 244 499 minecraft:shroomlight
setblock 290 244 501 minecraft:shroomlight
setblock 290 244 503 minecraft:shroomlight
setblock 291 244 490 minecraft:shroomlight
setblock 291 244 492 minecraft:shroomlight
setblock 291 244 494 minecraft:shroomlight
setblock 291 244 496 minecraft:shroomlight
setblock 291 244 498 minecraft:shroomlight
setblock 291 244 500 minecraft:shroomlight
setblock 291 244 502 minecraft:shroomlight
setblock 291 244 504 minecraft:shroomlight
setblock 292 244 491 minecraft:shroomlight
setblock 292 244 493 minecraft:shroomlight
setblock 292 244 495 minecraft:shroomlight
setblock 292 244 497 minecraft:shroomlight
setblock 292 244 499 minecraft:shroomlight
setblock 292 244 501 minecraft:shroomlight
setblock 292 244 503 minecraft:shroomlight
setblock 293 244 496 minecraft:shroomlight
setblock 293 244 498 minecraft:shroomlight
setblock 293 244 500 minecraft:shroomlight
setblock 293 244 502 minecraft:shroomlight
setblock 293 244 504 minecraft:shroomlight
setblock 294 244 495 minecraft:shroomlight
setblock 294 244 497 minecraft:shroomlight
setblock 294 244 499 minecraft:shroomlight
setblock 294 244 501 minecraft:shroomlight
setblock 294 244 503 minecraft:shroomlight
setblock 295 244 496 minecraft:shroomlight
setblock 295 244 498 minecraft:shroomlight
setblock 295 244 500 minecraft:shroomlight
setblock 295 244 502 minecraft:shroomlight
setblock 295 244 504 minecraft:shroomlight
setblock 296 244 495 minecraft:shroomlight
setblock 296 244 497 minecraft:shroomlight
setblock 296 244 499 minecraft:shroomlight
setblock 296 244 501 minecraft:shroomlight
setblock 296 244 503 minecraft:shroomlight
setblock 297 244 496 minecraft:shroomlight
setblock 297 244 498 minecraft:shroomlight
setblock 297 244 500 minecraft:shroomlight
setblock 297 244 502 minecraft:shroomlight
setblock 297 244 504 minecraft:shroomlight
setblock 298 244 495 minecraft:shroomlight
setblock 298 244 497 minecraft:shroomlight
setblock 298 244 499 minecraft:shroomlight
setblock 298 244 501 minecraft:shroomlight
setblock 298 244 503 minecraft:shroomlight
setblock 299 244 496 minecraft:shroomlight
setblock 299 244 498 minecraft:shroomlight
setblock 299 244 500 minecraft:shroomlight
setblock 299 244 502 minecraft:shroomlight
setblock 299 244 504 minecraft:shroomlight
setblock 300 244 495 minecraft:shroomlight
setblock 300 244 497 minecraft:shroomlight
setblock 300 244 499 minecraft:shroomlight
setblock 300 244 501 minecraft:shroomlight
setblock 300 244 503 minecraft:shroomlight
setblock 301 244 496 minecraft:shroomlight
setblock 301 244 498 minecraft:shroomlight
setblock 301 244 500 minecraft:shroomlight
setblock 301 244 502 minecraft:shroomlight
setblock 301 244 504 minecraft:shroomlight
setblock 302 244 499 minecraft:shroomlight
setblock 302 244 501 minecraft:shroomlight
setblock 302 244 503 minecraft:shroomlight
setblock 303 244 498 minecraft:shroomlight
setblock 303 244 500 minecraft:shroomlight
setblock 303 244 502 minecraft:shroomlight
setblock 303 244 504 minecraft:shroomlight
setblock 304 244 499 minecraft:shroomlight
setblock 304 244 501 minecraft:shroomlight
setblock 304 244 503 minecraft:shroomlight
setblock 305 244 498 minecraft:shroomlight
setblock 305 244 500 minecraft:shroomlight
setblock 305 244 502 minecraft:shroomlight
setblock 305 244 504 minecraft:shroomlight
setblock 306 244 499 minecraft:shroomlight
setblock 306 244 501 minecraft:shroomlight
setblock 306 244 503 minecraft:shroomlight
setblock 307 244 498 minecraft:shroomlight
setblock 307 244 500 minecraft:shroomlight
setblock 307 244 502 minecraft:shroomlight
setblock 307 244 504 minecraft:shroomlight
setblock 308 244 499 minecraft:shroomlight
setblock 308 244 501 minecraft:shroomlight
setblock 308 244 503 minecraft:shroomlight
setblock 309 244 498 minecraft:shroomlight
setblock 309 244 500 minecraft:shroomlight
setblock 309 244 502 minecraft:shroomlight
setblock 309 244 504 minecraft:shroomlight
setblock 310 244 499 minecraft:shroomlight
setblock 310 244 501 minecraft:shroomlight
setblock 310 244 503 minecraft:shroomlight
fill 283 245 467 283 245 472 minecraft:nether_bricks
fill 283 245 479 283 245 484 minecraft:nether_bricks
fill 283 245 490 283 247 490 minecraft:polished_blackstone_bricks
fill 283 245 491 283 245 496 minecraft:nether_bricks
fill 283 245 498 283 273 498 minecraft:polished_blackstone_bricks
fill 283 245 500 283 273 500 minecraft:polished_blackstone_bricks
fill 283 245 502 283 247 502 minecraft:polished_blackstone_bricks
fill 283 245 503 283 245 504 minecraft:nether_bricks
fill 284 245 491 284 247 491 minecraft:polished_blackstone_bricks
fill 284 245 493 284 247 493 minecraft:polished_blackstone_bricks
fill 284 245 495 284 247 495 minecraft:polished_blackstone_bricks
fill 284 245 497 284 247 497 minecraft:polished_blackstone_bricks
fill 284 245 499 284 247 499 minecraft:polished_blackstone_bricks
fill 284 245 501 284 247 501 minecraft:polished_blackstone_bricks
fill 284 245 504 287 245 504 minecraft:nether_bricks
fill 285 245 490 285 247 490 minecraft:polished_blackstone_bricks
fill 285 245 492 285 247 492 minecraft:polished_blackstone_bricks
fill 285 245 494 285 247 494 minecraft:polished_blackstone_bricks
fill 285 245 496 285 247 496 minecraft:polished_blackstone_bricks
fill 285 245 498 285 247 498 minecraft:polished_blackstone_bricks
fill 285 245 500 285 247 500 minecraft:polished_blackstone_bricks
fill 285 245 502 285 247 502 minecraft:polished_blackstone_bricks
fill 286 245 491 286 247 491 minecraft:polished_blackstone_bricks
fill 286 245 493 286 247 493 minecraft:polished_blackstone_bricks
fill 286 245 495 286 247 495 minecraft:polished_blackstone_bricks
fill 286 245 497 286 247 497 minecraft:polished_blackstone_bricks
fill 286 245 499 286 247 499 minecraft:polished_blackstone_bricks
fill 286 245 501 286 247 501 minecraft:polished_blackstone_bricks
fill 287 245 464 292 245 464 minecraft:nether_bricks
fill 287 245 490 287 247 490 minecraft:polished_blackstone_bricks
fill 287 245 492 287 247 492 minecraft:polished_blackstone_bricks
fill 287 245 494 287 247 494 minecraft:polished_blackstone_bricks
fill 287 245 496 287 247 496 minecraft:polished_blackstone_bricks
fill 287 245 498 287 247 498 minecraft:polished_blackstone_bricks
fill 287 245 500 287 247 500 minecraft:polished_blackstone_bricks
fill 287 245 502 287 247 502 minecraft:polished_blackstone_bricks
fill 288 245 491 288 247 491 minecraft:polished_blackstone_bricks
fill 288 245 493 288 247 493 minecraft:polished_blackstone_bricks
fill 288 245 495 288 247 495 minecraft:polished_blackstone_bricks
fill 288 245 497 288 247 497 minecraft:polished_blackstone_bricks
fill 288 245 499 288 247 499 minecraft:polished_blackstone_bricks
fill 288 245 501 288 247 501 minecraft:polished_blackstone_bricks
fill 289 245 490 289 247 490 minecraft:polished_blackstone_bricks
fill 289 245 492 289 247 492 minecraft:polished_blackstone_bricks
fill 289 245 494 289 247 494 minecraft:polished_blackstone_bricks
fill 289 245 496 289 246 496 minecraft:polished_blackstone_bricks
fill 289 245 498 289 246 498 minecraft:polished_blackstone_bricks
fill 289 245 500 289 246 500 minecraft:polished_blackstone_bricks
fill 289 245 502 289 246 502 minecraft:polished_blackstone_bricks
fill 289 245 504 289 246 504 minecraft:polished_blackstone_bricks
fill 290 245 491 290 247 491 minecraft:polished_blackstone_bricks
fill 290 245 493 290 247 493 minecraft:polished_blackstone_bricks
fill 290 245 495 290 246 495 minecraft:polished_blackstone_bricks
fill 290 245 497 290 246 497 minecraft:polished_blackstone_bricks
fill 290 245 499 290 246 499 minecraft:polished_blackstone_bricks
fill 290 245 501 290 246 501 minecraft:polished_blackstone_bricks
fill 290 245 503 290 246 503 minecraft:polished_blackstone_bricks
fill 291 245 490 291 247 490 minecraft:polished_blackstone_bricks
fill 291 245 492 291 247 492 minecraft:polished_blackstone_bricks
fill 291 245 494 291 247 494 minecraft:polished_blackstone_bricks
fill 291 245 496 291 246 496 minecraft:polished_blackstone_bricks
fill 291 245 498 291 246 498 minecraft:polished_blackstone_bricks
fill 291 245 500 291 246 500 minecraft:polished_blackstone_bricks
fill 291 245 502 291 246 502 minecraft:polished_blackstone_bricks
fill 291 245 504 291 246 504 minecraft:polished_blackstone_bricks
fill 292 245 491 292 247 491 minecraft:polished_blackstone_bricks
fill 292 245 493 292 247 493 minecraft:polished_blackstone_bricks
fill 292 245 495 292 246 495 minecraft:polished_blackstone_bricks
fill 292 245 497 292 246 497 minecraft:polished_blackstone_bricks
fill 292 245 499 292 246 499 minecraft:polished_blackstone_bricks
fill 292 245 501 292 246 501 minecraft:polished_blackstone_bricks
fill 292 245 503 292 246 503 minecraft:polished_blackstone_bricks
fill 293 245 496 293 246 496 minecraft:polished_blackstone_bricks
fill 293 245 498 293 246 498 minecraft:polished_blackstone_bricks
fill 293 245 500 293 246 500 minecraft:polished_blackstone_bricks
fill 293 245 502 293 246 502 minecraft:polished_blackstone_bricks
fill 293 245 504 293 246 504 minecraft:polished_blackstone_bricks
fill 294 245 495 294 246 495 minecraft:polished_blackstone_bricks
fill 294 245 497 294 246 497 minecraft:polished_blackstone_bricks
fill 294 245 499 294 246 499 minecraft:polished_blackstone_bricks
fill 294 245 501 294 246 501 minecraft:polished_blackstone_bricks
fill 294 245 503 294 246 503 minecraft:polished_blackstone_bricks
fill 294 245 504 299 245 504 minecraft:nether_bricks
fill 295 245 496 295 246 496 minecraft:polished_blackstone_bricks
fill 295 245 498 295 246 498 minecraft:polished_blackstone_bricks
fill 295 245 500 295 246 500 minecraft:polished_blackstone_bricks
fill 295 245 502 295 246 502 minecraft:polished_blackstone_bricks
fill 296 245 495 296 246 495 minecraft:polished_blackstone_bricks
fill 296 245 497 296 246 497 minecraft:polished_blackstone_bricks
fill 296 245 499 296 246 499 minecraft:polished_blackstone_bricks
fill 296 245 501 296 246 501 minecraft:polished_blackstone_bricks
fill 296 245 503 296 246 503 minecraft:polished_blackstone_bricks
fill 297 245 496 297 246 496 minecraft:polished_blackstone_bricks
fill 297 245 498 297 246 498 minecraft:polished_blackstone_bricks
fill 297 245 500 297 246 500 minecraft:polished_blackstone_bricks
fill 297 245 502 297 246 502 minecraft:polished_blackstone_bricks
fill 298 245 495 298 246 495 minecraft:polished_blackstone_bricks
fill 298 245 497 298 246 497 minecraft:polished_blackstone_bricks
fill 298 245 499 298 246 499 minecraft:polished_blackstone_bricks
fill 298 245 501 298 246 501 minecraft:polished_blackstone_bricks
fill 298 245 503 298 246 503 minecraft:polished_blackstone_bricks
fill 299 245 464 304 245 464 minecraft:nether_bricks
fill 299 245 496 299 246 496 minecraft:polished_blackstone_bricks
fill 299 245 498 299 246 498 minecraft:polished_blackstone_bricks
fill 299 245 500 299 246 500 minecraft:polished_blackstone_bricks
fill 299 245 502 299 246 502 minecraft:polished_blackstone_bricks
fill 300 245 495 300 246 495 minecraft:polished_blackstone_bricks
fill 300 245 497 300 246 497 minecraft:polished_blackstone_bricks
fill 300 245 499 300 246 499 minecraft:polished_blackstone_bricks
fill 300 245 501 300 246 501 minecraft:polished_blackstone_bricks
fill 300 245 503 300 246 503 minecraft:polished_blackstone_bricks
fill 301 245 496 301 246 496 minecraft:polished_blackstone_bricks
fill 301 245 498 301 246 498 minecraft:polished_blackstone_bricks
fill 301 245 500 301 246 500 minecraft:polished_blackstone_bricks
fill 301 245 502 301 246 502 minecraft:polished_blackstone_bricks
fill 301 245 504 301 246 504 minecraft:polished_blackstone_bricks
fill 302 245 499 302 246 499 minecraft:polished_blackstone_bricks
fill 302 245 501 302 246 501 minecraft:polished_blackstone_bricks
fill 302 245 503 302 246 503 minecraft:polished_blackstone_bricks
fill 303 245 498 303 246 498 minecraft:polished_blackstone_bricks
fill 303 245 500 303 246 500 minecraft:polished_blackstone_bricks
fill 303 245 502 303 246 502 minecraft:polished_blackstone_bricks
fill 303 245 504 303 246 504 minecraft:polished_blackstone_bricks
fill 304 245 499 304 246 499 minecraft:polished_blackstone_bricks
fill 304 245 501 304 246 501 minecraft:polished_blackstone_bricks
fill 304 245 503 304 246 503 minecraft:polished_blackstone_bricks
fill 305 245 498 305 246 498 minecraft:polished_blackstone_bricks
fill 305 245 500 305 246 500 minecraft:polished_blackstone_bricks
fill 305 245 502 305 246 502 minecraft:polished_blackstone_bricks
fill 305 245 504 305 246 504 minecraft:polished_blackstone_bricks
fill 306 245 499 306 246 499 minecraft:polished_blackstone_bricks
fill 306 245 501 306 246 501 minecraft:polished_blackstone_bricks
fill 306 245 503 306 246 503 minecraft:polished_blackstone_bricks
fill 306 245 504 311 245 504 minecraft:nether_bricks
fill 307 245 498 307 246 498 minecraft:polished_blackstone_bricks
fill 307 245 500 307 246 500 minecraft:polished_blackstone_bricks
fill 307 245 502 307 246 502 minecraft:polished_blackstone_bricks
fill 308 245 499 308 246 499 minecraft:polished_blackstone_bricks
fill 308 245 501 308 246 501 minecraft:polished_blackstone_bricks
fill 308 245 503 308 246 503 minecraft:polished_blackstone_bricks
fill 309 245 498 309 246 498 minecraft:polished_blackstone_bricks
fill 309 245 500 309 246 500 minecraft:polished_blackstone_bricks
fill 309 245 502 309 246 502 minecraft:polished_blackstone_bricks
fill 310 245 499 310 246 499 minecraft:polished_blackstone_bricks
fill 310 245 501 310 246 501 minecraft:polished_blackstone_bricks
fill 310 245 503 310 246 503 minecraft:polished_blackstone_bricks
fill 311 245 464 316 245 464 minecraft:nether_bricks
fill 313 245 504 317 245 504 minecraft:polished_blackstone_bricks
fill 316 245 496 322 245 503 minecraft:polished_blackstone_bricks
fill 318 245 504 323 245 504 minecraft:nether_bricks
fill 321 245 488 321 257 488 minecraft:red_wool
fill 323 245 464 323 245 469 minecraft:nether_bricks
fill 323 245 476 323 245 481 minecraft:nether_bricks
fill 323 245 488 323 245 493 minecraft:nether_bricks
fill 323 245 496 323 245 499 minecraft:polished_blackstone_bricks
fill 323 245 500 323 245 503 minecraft:nether_bricks
fill 282 246 469 282 251 472 minecraft:shroomlight
fill 282 246 481 282 251 484 minecraft:shroomlight
fill 282 246 493 282 251 496 minecraft:shroomlight
fill 282 246 505 285 251 505 minecraft:shroomlight
fill 283 246 491 283 247 496 minecraft:polished_blackstone_bricks
fill 289 246 463 292 251 463 minecraft:shroomlight
fill 294 246 504 299 246 504 minecraft:polished_blackstone_bricks
fill 294 246 505 297 251 505 minecraft:shroomlight
fill 301 246 463 304 251 463 minecraft:shroomlight
fill 306 246 504 310 246 504 minecraft:polished_blackstone_bricks
fill 306 246 505 309 251 505 minecraft:shroomlight
fill 313 246 463 316 251 463 minecraft:shroomlight
fill 313 246 504 315 273 504 minecraft:polished_blackstone_bricks
fill 317 246 497 322 246 504 minecraft:gold_block
fill 318 246 505 321 251 505 minecraft:shroomlight
fill 321 246 486 321 257 487 minecraft:red_wool
fill 321 246 489 321 257 490 minecraft:red_wool
fill 323 246 496 323 273 498 minecraft:polished_blackstone_bricks
fill 324 246 464 324 251 467 minecraft:shroomlight
fill 324 246 476 324 251 479 minecraft:shroomlight
fill 324 246 488 324 251 491 minecraft:shroomlight
fill 324 246 500 324 251 503 minecraft:shroomlight
setblock 285 247 466 minecraft:light[level=14]
setblock 285 247 474 minecraft:light[level=14]
setblock 285 247 482 minecraft:light[level=14]
setblock 289 247 496 minecraft:shroomlight
setblock 289 247 498 minecraft:shroomlight
setblock 289 247 500 minecraft:shroomlight
setblock 289 247 502 minecraft:shroomlight
setblock 289 247 504 minecraft:shroomlight
setblock 290 247 495 minecraft:shroomlight
setblock 290 247 497 minecraft:shroomlight
setblock 290 247 499 minecraft:shroomlight
setblock 290 247 501 minecraft:shroomlight
setblock 290 247 503 minecraft:shroomlight
setblock 291 247 496 minecraft:shroomlight
setblock 291 247 498 minecraft:shroomlight
setblock 291 247 500 minecraft:shroomlight
setblock 291 247 502 minecraft:shroomlight
setblock 291 247 504 minecraft:shroomlight
setblock 292 247 495 minecraft:shroomlight
setblock 292 247 497 minecraft:shroomlight
setblock 292 247 499 minecraft:shroomlight
setblock 292 247 501 minecraft:shroomlight
setblock 292 247 503 minecraft:shroomlight
setblock 293 247 466 minecraft:light[level=14]
setblock 293 247 474 minecraft:light[level=14]
setblock 293 247 482 minecraft:light[level=14]
setblock 293 247 490 minecraft:light[level=14]
setblock 293 247 496 minecraft:shroomlight
setblock 293 247 498 minecraft:shroomlight
setblock 293 247 500 minecraft:shroomlight
setblock 293 247 502 minecraft:shroomlight
setblock 293 247 504 minecraft:shroomlight
setblock 294 247 495 minecraft:shroomlight
setblock 294 247 497 minecraft:shroomlight
setblock 294 247 499 minecraft:shroomlight
setblock 294 247 501 minecraft:shroomlight
setblock 294 247 503 minecraft:shroomlight
fill 294 247 504 294 254 504 minecraft:polished_blackstone_bricks
setblock 295 247 496 minecraft:shroomlight
setblock 295 247 498 minecraft:shroomlight
setblock 295 247 500 minecraft:shroomlight
setblock 295 247 502 minecraft:shroomlight
setblock 295 247 504 minecraft:shroomlight
setblock 296 247 495 minecraft:shroomlight
setblock 296 247 497 minecraft:shroomlight
setblock 296 247 499 minecraft:shroomlight
setblock 296 247 501 minecraft:shroomlight
setblock 296 247 503 minecraft:shroomlight
fill 296 247 504 296 254 504 minecraft:polished_blackstone_bricks
setblock 297 247 496 minecraft:shroomlight
setblock 297 247 498 minecraft:shroomlight
setblock 297 247 500 minecraft:shroomlight
setblock 297 247 502 minecraft:shroomlight
setblock 297 247 504 minecraft:shroomlight
setblock 298 247 495 minecraft:shroomlight
setblock 298 247 497 minecraft:shroomlight
setblock 298 247 499 minecraft:shroomlight
setblock 298 247 501 minecraft:shroomlight
setblock 298 247 503 minecraft:shroomlight
fill 298 247 504 298 254 504 minecraft:polished_blackstone_bricks
setblock 299 247 496 minecraft:shroomlight
setblock 299 247 498 minecraft:shroomlight
setblock 299 247 500 minecraft:shroomlight
setblock 299 247 502 minecraft:shroomlight
setblock 299 247 504 minecraft:shroomlight
setblock 300 247 495 minecraft:shroomlight
setblock 300 247 497 minecraft:shroomlight
setblock 300 247 499 minecraft:shroomlight
setblock 300 247 501 minecraft:shroomlight
setblock 300 247 503 minecraft:shroomlight
setblock 301 247 466 minecraft:light[level=14]
setblock 301 247 474 minecraft:light[level=14]
setblock 301 247 482 minecraft:light[level=14]
setblock 301 247 490 minecraft:light[level=14]
setblock 301 247 496 minecraft:shroomlight
setblock 301 247 498 minecraft:shroomlight
setblock 301 247 500 minecraft:shroomlight
setblock 301 247 502 minecraft:shroomlight
setblock 301 247 504 minecraft:shroomlight
setblock 302 247 499 minecraft:shroomlight
setblock 302 247 501 minecraft:shroomlight
setblock 302 247 503 minecraft:shroomlight
setblock 303 247 498 minecraft:shroomlight
setblock 303 247 500 minecraft:shroomlight
setblock 303 247 502 minecraft:shroomlight
setblock 303 247 504 minecraft:shroomlight
setblock 304 247 499 minecraft:shroomlight
setblock 304 247 501 minecraft:shroomlight
setblock 304 247 503 minecraft:shroomlight
setblock 305 247 498 minecraft:shroomlight
setblock 305 247 500 minecraft:shroomlight
setblock 305 247 502 minecraft:shroomlight
setblock 305 247 504 minecraft:shroomlight
setblock 306 247 499 minecraft:shroomlight
setblock 306 247 501 minecraft:shroomlight
setblock 306 247 503 minecraft:shroomlight
fill 306 247 504 306 254 504 minecraft:polished_blackstone_bricks
setblock 307 247 498 minecraft:shroomlight
setblock 307 247 500 minecraft:shroomlight
setblock 307 247 502 minecraft:shroomlight
setblock 307 247 504 minecraft:shroomlight
setblock 308 247 499 minecraft:shroomlight
setblock 308 247 501 minecraft:shroomlight
setblock 308 247 503 minecraft:shroomlight
fill 308 247 504 308 254 504 minecraft:polished_blackstone_bricks
setblock 309 247 466 minecraft:light[level=14]
setblock 309 247 474 minecraft:light[level=14]
setblock 309 247 482 minecraft:light[level=14]
setblock 309 247 490 minecraft:light[level=14]
setblock 309 247 498 minecraft:shroomlight
setblock 309 247 500 minecraft:shroomlight
setblock 309 247 502 minecraft:shroomlight
setblock 309 247 504 minecraft:shroomlight
setblock 310 247 499 minecraft:shroomlight
setblock 310 247 501 minecraft:shroomlight
setblock 310 247 503 minecraft:shroomlight
fill 310 247 504 310 254 504 minecraft:polished_blackstone_bricks
setblock 317 247 466 minecraft:light[level=14]
setblock 317 247 474 minecraft:light[level=14]
setblock 317 247 482 minecraft:light[level=14]
setblock 317 247 490 minecraft:light[level=14]
setblock 317 247 498 minecraft:light[level=14]
fill 318 247 498 321 247 504 minecraft:gold_block
fill 284 248 491 291 248 501 minecraft:gold_block
fill 289 248 502 289 249 502 minecraft:polished_blackstone_bricks
fill 289 248 504 289 249 504 minecraft:polished_blackstone_bricks
fill 290 248 503 290 249 503 minecraft:polished_blackstone_bricks
fill 291 248 502 291 249 502 minecraft:polished_blackstone_bricks
fill 291 248 504 291 249 504 minecraft:polished_blackstone_bricks
fill 292 248 495 292 249 495 minecraft:polished_blackstone_bricks
fill 292 248 497 292 249 497 minecraft:polished_blackstone_bricks
fill 292 248 499 292 249 499 minecraft:polished_blackstone_bricks
fill 292 248 501 292 249 501 minecraft:polished_blackstone_bricks
fill 292 248 503 292 249 503 minecraft:polished_blackstone_bricks
fill 293 248 496 293 249 496 minecraft:polished_blackstone_bricks
fill 293 248 498 293 249 498 minecraft:polished_blackstone_bricks
fill 293 248 500 293 249 500 minecraft:polished_blackstone_bricks
fill 293 248 502 293 249 502 minecraft:polished_blackstone_bricks
fill 293 248 504 293 249 504 minecraft:polished_blackstone_bricks
fill 294 248 495 294 249 495 minecraft:polished_blackstone_bricks
fill 294 248 497 294 249 497 minecraft:polished_blackstone_bricks
fill 294 248 499 294 249 499 minecraft:polished_blackstone_bricks
fill 294 248 501 294 249 501 minecraft:polished_blackstone_bricks
fill 294 248 503 294 249 503 minecraft:polished_blackstone_bricks
fill 295 248 496 295 249 496 minecraft:polished_blackstone_bricks
fill 295 248 498 295 249 498 minecraft:polished_blackstone_bricks
fill 295 248 500 295 249 500 minecraft:polished_blackstone_bricks
fill 295 248 502 295 249 502 minecraft:polished_blackstone_bricks
fill 295 248 504 295 249 504 minecraft:polished_blackstone_bricks
fill 296 248 495 296 249 495 minecraft:polished_blackstone_bricks
fill 296 248 497 296 249 497 minecraft:polished_blackstone_bricks
fill 296 248 499 296 249 499 minecraft:polished_blackstone_bricks
fill 296 248 501 296 249 501 minecraft:polished_blackstone_bricks
fill 296 248 503 296 249 503 minecraft:polished_blackstone_bricks
fill 297 248 496 297 249 496 minecraft:polished_blackstone_bricks
fill 297 248 498 297 249 498 minecraft:polished_blackstone_bricks
fill 297 248 500 297 249 500 minecraft:polished_blackstone_bricks
fill 297 248 502 297 249 502 minecraft:polished_blackstone_bricks
fill 297 248 504 297 249 504 minecraft:polished_blackstone_bricks
fill 298 248 495 298 249 495 minecraft:polished_blackstone_bricks
fill 298 248 497 298 249 497 minecraft:polished_blackstone_bricks
fill 298 248 499 298 249 499 minecraft:polished_blackstone_bricks
fill 298 248 501 298 249 501 minecraft:polished_blackstone_bricks
fill 298 248 503 298 249 503 minecraft:polished_blackstone_bricks
fill 299 248 496 299 249 496 minecraft:polished_blackstone_bricks
fill 299 248 498 299 249 498 minecraft:polished_blackstone_bricks
fill 299 248 500 299 249 500 minecraft:polished_blackstone_bricks
fill 299 248 502 299 249 502 minecraft:polished_blackstone_bricks
fill 299 248 504 299 249 504 minecraft:polished_blackstone_bricks
fill 300 248 495 300 249 495 minecraft:polished_blackstone_bricks
fill 300 248 497 300 249 497 minecraft:polished_blackstone_bricks
fill 300 248 499 300 249 499 minecraft:polished_blackstone_bricks
fill 300 248 501 300 249 501 minecraft:polished_blackstone_bricks
fill 300 248 503 300 249 503 minecraft:polished_blackstone_bricks
fill 301 248 496 301 249 496 minecraft:polished_blackstone_bricks
fill 301 248 498 301 249 498 minecraft:polished_blackstone_bricks
fill 301 248 500 301 249 500 minecraft:polished_blackstone_bricks
fill 301 248 502 301 249 502 minecraft:polished_blackstone_bricks
fill 301 248 504 301 249 504 minecraft:polished_blackstone_bricks
fill 302 248 499 302 249 499 minecraft:polished_blackstone_bricks
fill 302 248 501 302 249 501 minecraft:polished_blackstone_bricks
fill 302 248 503 302 249 503 minecraft:polished_blackstone_bricks
fill 303 248 498 303 249 498 minecraft:polished_blackstone_bricks
fill 303 248 500 303 249 500 minecraft:polished_blackstone_bricks
fill 303 248 502 303 249 502 minecraft:polished_blackstone_bricks
fill 303 248 504 303 249 504 minecraft:polished_blackstone_bricks
fill 304 248 499 304 249 499 minecraft:polished_blackstone_bricks
fill 304 248 501 304 249 501 minecraft:polished_blackstone_bricks
fill 304 248 503 304 249 503 minecraft:polished_blackstone_bricks
fill 305 248 498 305 249 498 minecraft:polished_blackstone_bricks
fill 305 248 500 305 249 500 minecraft:polished_blackstone_bricks
fill 305 248 502 305 249 502 minecraft:polished_blackstone_bricks
fill 305 248 504 305 249 504 minecraft:polished_blackstone_bricks
fill 306 248 499 306 249 499 minecraft:polished_blackstone_bricks
fill 306 248 501 306 249 501 minecraft:polished_blackstone_bricks
fill 306 248 503 306 249 503 minecraft:polished_blackstone_bricks
fill 307 248 498 307 249 498 minecraft:polished_blackstone_bricks
fill 307 248 500 307 249 500 minecraft:polished_blackstone_bricks
fill 307 248 502 307 249 502 minecraft:polished_blackstone_bricks
fill 307 248 504 307 249 504 minecraft:polished_blackstone_bricks
fill 308 248 499 308 249 499 minecraft:polished_blackstone_bricks
fill 308 248 501 308 249 501 minecraft:polished_blackstone_bricks
fill 308 248 503 308 249 503 minecraft:polished_blackstone_bricks
fill 309 248 498 309 249 498 minecraft:polished_blackstone_bricks
fill 309 248 500 309 249 500 minecraft:polished_blackstone_bricks
fill 309 248 502 309 249 502 minecraft:polished_blackstone_bricks
fill 309 248 504 309 249 504 minecraft:polished_blackstone_bricks
fill 310 248 499 310 249 499 minecraft:polished_blackstone_bricks
fill 310 248 501 310 249 501 minecraft:polished_blackstone_bricks
fill 310 248 503 310 249 503 minecraft:polished_blackstone_bricks
fill 319 248 499 320 248 503 minecraft:gold_block
fill 285 249 492 290 249 500 minecraft:gold_block
fill 289 249 501 291 249 501 minecraft:polished_blackstone_bricks
fill 291 249 495 291 249 500 minecraft:polished_blackstone_bricks
fill 319 249 500 320 249 502 minecraft:gold_block
fill 286 250 493 288 250 499 minecraft:gold_block
fill 289 250 493 289 250 495 minecraft:gold_block
setblock 289 250 496 minecraft:shroomlight
setblock 289 250 497 minecraft:gold_block
setblock 289 250 498 minecraft:shroomlight
setblock 289 250 499 minecraft:gold_block
setblock 289 250 500 minecraft:shroomlight
fill 289 250 501 289 254 501 minecraft:polished_blackstone_bricks
setblock 289 250 502 minecraft:shroomlight
setblock 289 250 504 minecraft:shroomlight
setblock 290 250 495 minecraft:shroomlight
fill 290 250 496 290 254 496 minecraft:polished_blackstone_bricks
setblock 290 250 497 minecraft:shroomlight
fill 290 250 498 290 254 498 minecraft:polished_blackstone_bricks
setblock 290 250 499 minecraft:shroomlight
fill 290 250 500 290 254 500 minecraft:polished_blackstone_bricks
setblock 290 250 501 minecraft:shroomlight
setblock 290 250 503 minecraft:shroomlight
fill 291 250 495 291 254 495 minecraft:polished_blackstone_bricks
setblock 291 250 496 minecraft:shroomlight
fill 291 250 497 291 254 497 minecraft:polished_blackstone_bricks
setblock 291 250 498 minecraft:shroomlight
fill 291 250 499 291 254 499 minecraft:polished_blackstone_bricks
setblock 291 250 500 minecraft:shroomlight
fill 291 250 501 291 254 501 minecraft:polished_blackstone_bricks
setblock 291 250 502 minecraft:shroomlight
setblock 291 250 504 minecraft:shroomlight
setblock 292 250 495 minecraft:shroomlight
setblock 292 250 497 minecraft:shroomlight
setblock 292 250 499 minecraft:shroomlight
setblock 292 250 501 minecraft:shroomlight
setblock 292 250 503 minecraft:shroomlight
setblock 293 250 496 minecraft:shroomlight
setblock 293 250 498 minecraft:shroomlight
setblock 293 250 500 minecraft:shroomlight
schedule function dropper:buildpart/114_3 1t
