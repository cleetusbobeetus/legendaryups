fill 134 231 328 134 232 328 minecraft:stone
setblock 134 231 330 minecraft:stripped_spruce_log
fill 134 231 331 134 233 332 minecraft:stone
setblock 134 231 344 minecraft:stone
setblock 134 231 345 minecraft:stripped_spruce_log
fill 134 231 346 134 233 346 minecraft:stone
fill 134 231 348 134 231 349 minecraft:stone
setblock 134 231 350 minecraft:stripped_spruce_log
fill 134 231 351 134 231 354 minecraft:stone
setblock 134 231 355 minecraft:stripped_spruce_log
fill 134 231 356 134 231 359 minecraft:stone
setblock 134 231 360 minecraft:stripped_spruce_log
fill 134 231 361 134 233 361 minecraft:stone
setblock 135 231 324 minecraft:stripped_spruce_log
fill 135 231 325 135 233 325 minecraft:stone
setblock 135 231 329 minecraft:stripped_spruce_log
fill 135 231 330 135 233 330 minecraft:stone
setblock 135 231 334 minecraft:stripped_spruce_log
fill 135 231 335 135 233 335 minecraft:stone
setblock 135 231 344 minecraft:stripped_spruce_log
fill 135 231 345 135 233 345 minecraft:stone
setblock 135 231 349 minecraft:stripped_spruce_log
fill 135 231 350 135 233 350 minecraft:stone
fill 135 231 352 135 231 353 minecraft:stone
setblock 135 231 354 minecraft:stripped_spruce_log
fill 135 231 355 135 233 355 minecraft:stone
setblock 135 231 359 minecraft:stripped_spruce_log
fill 135 231 360 135 233 360 minecraft:stone
fill 136 231 356 136 247 356 minecraft:andesite
fill 94 232 339 94 243 339 minecraft:andesite
setblock 95 232 323 minecraft:stripped_spruce_log
fill 95 232 324 95 233 324 minecraft:stone
setblock 95 232 328 minecraft:stripped_spruce_log
fill 95 232 329 95 233 329 minecraft:stone
fill 95 232 331 95 232 332 minecraft:stone
setblock 95 232 333 minecraft:stripped_spruce_log
fill 95 232 334 95 232 337 minecraft:stone
setblock 95 232 338 minecraft:stripped_spruce_log
fill 95 232 339 95 232 342 minecraft:stone
setblock 95 232 343 minecraft:stripped_spruce_log
fill 95 232 344 95 232 347 minecraft:stone
setblock 95 232 348 minecraft:stripped_spruce_log
fill 95 232 349 95 232 352 minecraft:stone
setblock 95 232 353 minecraft:stripped_spruce_log
fill 95 232 354 95 232 357 minecraft:stone
setblock 95 232 358 minecraft:stripped_spruce_log
fill 95 232 359 95 233 359 minecraft:stone
setblock 95 232 362 minecraft:stone
setblock 95 232 363 minecraft:stripped_spruce_log
fill 96 232 323 96 233 323 minecraft:stone
setblock 96 232 324 minecraft:glowstone
setblock 96 232 327 minecraft:stripped_spruce_log
fill 96 232 328 97 233 328 minecraft:stone
setblock 96 232 332 minecraft:stripped_spruce_log
fill 96 232 333 96 233 333 minecraft:stone
setblock 96 232 342 minecraft:stripped_spruce_log
setblock 96 232 343 minecraft:glowstone
setblock 96 232 347 minecraft:stripped_spruce_log
fill 96 232 348 96 233 348 minecraft:stone
setblock 96 232 352 minecraft:stripped_spruce_log
fill 96 232 353 96 233 353 minecraft:stone
setblock 96 232 357 minecraft:stripped_spruce_log
fill 96 232 358 96 233 358 minecraft:stone
setblock 96 232 362 minecraft:glowstone
fill 96 232 363 96 233 363 minecraft:stone
setblock 97 232 326 minecraft:stripped_spruce_log
setblock 97 232 327 minecraft:stone
setblock 97 232 346 minecraft:stripped_spruce_log
fill 97 232 347 97 235 347 minecraft:stone
setblock 97 232 350 minecraft:stone
setblock 97 232 351 minecraft:stripped_spruce_log
fill 97 232 352 97 235 352 minecraft:stone
setblock 97 232 356 minecraft:stripped_spruce_log
fill 97 232 357 97 235 357 minecraft:stone
fill 97 232 362 97 233 362 minecraft:stone
fill 98 232 346 98 233 346 minecraft:stone
setblock 98 232 350 minecraft:stripped_spruce_log
fill 98 232 351 98 235 351 minecraft:stone
setblock 99 232 324 minecraft:stripped_spruce_log
fill 99 232 354 99 232 362 minecraft:raw_gold_block
setblock 100 232 323 minecraft:stripped_spruce_log
setblock 100 232 363 minecraft:stripped_spruce_log
setblock 101 232 323 minecraft:stone
setblock 109 232 323 minecraft:stone
setblock 110 232 323 minecraft:stripped_spruce_log
fill 110 232 324 110 233 324 minecraft:stone
fill 111 232 323 114 232 323 minecraft:stone
setblock 112 232 325 minecraft:stone
setblock 113 232 325 minecraft:stripped_spruce_log
fill 113 232 326 116 232 326 minecraft:stone
fill 113 232 363 114 232 363 minecraft:stone
setblock 114 232 324 minecraft:stripped_spruce_log
fill 114 232 325 117 232 325 minecraft:stone
setblock 115 232 323 minecraft:stripped_spruce_log
setblock 115 232 324 minecraft:glowstone
setblock 115 232 362 minecraft:glowstone
setblock 115 232 363 minecraft:stripped_spruce_log
fill 116 232 323 118 232 324 minecraft:stone
fill 116 232 363 119 232 363 minecraft:stone
setblock 117 232 326 minecraft:stripped_spruce_log
setblock 118 232 325 minecraft:stripped_spruce_log
fill 118 232 326 118 234 326 minecraft:stone
setblock 119 232 323 minecraft:stone
setblock 119 232 324 minecraft:stripped_spruce_log
fill 119 232 325 119 235 325 minecraft:stone
setblock 120 232 323 minecraft:stripped_spruce_log
fill 120 232 324 123 232 324 minecraft:stone
setblock 120 232 363 minecraft:stripped_spruce_log
fill 121 232 323 124 232 323 minecraft:stone
setblock 121 232 363 minecraft:stone
setblock 123 232 325 minecraft:stripped_spruce_log
setblock 124 232 322 minecraft:diamond_block
setblock 124 232 324 minecraft:stripped_spruce_log
setblock 124 232 325 minecraft:stone
fill 124 232 359 124 232 363 minecraft:stripped_dark_oak_log
setblock 125 232 323 minecraft:stripped_spruce_log
fill 125 232 324 125 233 324 minecraft:stone
fill 125 232 354 125 232 357 minecraft:stripped_dark_oak_log
fill 126 232 323 126 233 323 minecraft:stone
setblock 128 232 325 minecraft:stripped_spruce_log
setblock 129 232 324 minecraft:stripped_spruce_log
fill 129 232 325 129 234 325 minecraft:stone
setblock 130 232 323 minecraft:stripped_spruce_log
fill 130 232 324 130 233 324 minecraft:stone
setblock 130 232 363 minecraft:stripped_spruce_log
fill 131 232 323 131 233 323 minecraft:stone
setblock 131 232 362 minecraft:stripped_spruce_log
fill 131 232 363 131 233 363 minecraft:stone
setblock 131 232 364 minecraft:raw_iron_block
fill 132 232 362 132 233 362 minecraft:stone
setblock 133 232 325 minecraft:stripped_spruce_log
fill 133 232 326 133 235 326 minecraft:stone
setblock 133 232 329 minecraft:stone
setblock 133 232 330 minecraft:stripped_spruce_log
fill 133 232 348 133 232 349 minecraft:stone
setblock 133 232 350 minecraft:stripped_spruce_log
fill 133 232 351 133 232 354 minecraft:stone
setblock 134 232 324 minecraft:glowstone
fill 134 232 325 134 233 325 minecraft:stone
setblock 134 232 329 minecraft:stripped_spruce_log
fill 134 232 330 134 233 330 minecraft:stone
setblock 134 232 333 minecraft:stone
setblock 134 232 343 minecraft:glowstone
setblock 134 232 344 minecraft:stripped_spruce_log
fill 134 232 345 134 233 345 minecraft:stone
setblock 134 232 348 minecraft:stone
setblock 134 232 349 minecraft:stripped_spruce_log
fill 134 232 350 134 232 353 minecraft:stone
setblock 134 232 354 minecraft:stripped_spruce_log
fill 134 232 355 134 232 358 minecraft:stone
setblock 134 232 359 minecraft:stripped_spruce_log
fill 134 232 360 134 233 360 minecraft:stone
setblock 134 232 362 minecraft:glowstone
setblock 135 232 323 minecraft:stripped_spruce_log
fill 135 232 324 135 233 324 minecraft:stone
setblock 135 232 328 minecraft:stripped_spruce_log
fill 135 232 329 135 233 329 minecraft:stone
setblock 135 232 333 minecraft:stripped_spruce_log
fill 135 232 334 135 233 334 minecraft:stone
fill 135 232 336 135 233 336 minecraft:stone
fill 135 232 340 135 233 340 minecraft:stone
setblock 135 232 343 minecraft:stripped_spruce_log
fill 135 232 344 135 233 344 minecraft:stone
setblock 135 232 348 minecraft:stripped_spruce_log
fill 135 232 349 135 233 349 minecraft:stone
setblock 135 232 352 minecraft:stone
setblock 135 232 353 minecraft:stripped_spruce_log
fill 135 232 354 135 233 354 minecraft:stone
setblock 135 232 358 minecraft:stripped_spruce_log
fill 135 232 359 135 233 359 minecraft:stone
setblock 135 232 363 minecraft:stripped_spruce_log
setblock 136 232 351 minecraft:diamond_block
setblock 95 233 323 minecraft:stone
setblock 95 233 327 minecraft:stripped_spruce_log
setblock 95 233 328 minecraft:stone
setblock 95 233 331 minecraft:stone
setblock 95 233 332 minecraft:stripped_spruce_log
fill 95 233 333 95 233 336 minecraft:stone
setblock 95 233 337 minecraft:stripped_spruce_log
fill 95 233 338 95 233 341 minecraft:stone
setblock 95 233 342 minecraft:stripped_spruce_log
fill 95 233 343 95 233 346 minecraft:stone
setblock 95 233 347 minecraft:stripped_spruce_log
fill 95 233 348 95 233 351 minecraft:stone
setblock 95 233 352 minecraft:stripped_spruce_log
fill 95 233 353 95 233 356 minecraft:stone
setblock 95 233 357 minecraft:stripped_spruce_log
setblock 95 233 358 minecraft:stone
setblock 95 233 362 minecraft:stripped_spruce_log
setblock 95 233 363 minecraft:stone
fill 96 233 324 96 234 324 minecraft:spruce_log
setblock 96 233 326 minecraft:stripped_spruce_log
setblock 96 233 327 minecraft:stone
setblock 96 233 331 minecraft:stripped_spruce_log
setblock 96 233 332 minecraft:stone
setblock 96 233 334 minecraft:stone
setblock 96 233 340 minecraft:stone
setblock 96 233 341 minecraft:stripped_spruce_log
setblock 96 233 342 minecraft:stone
fill 96 233 343 96 234 343 minecraft:spruce_log
setblock 96 233 346 minecraft:stripped_spruce_log
setblock 96 233 347 minecraft:stone
setblock 96 233 351 minecraft:stripped_spruce_log
setblock 96 233 352 minecraft:stone
setblock 96 233 355 minecraft:stone
setblock 96 233 356 minecraft:stripped_spruce_log
setblock 96 233 357 minecraft:stone
setblock 96 233 361 minecraft:stripped_spruce_log
fill 96 233 362 96 234 362 minecraft:spruce_log
setblock 97 233 345 minecraft:stripped_spruce_log
fill 97 233 346 97 236 346 minecraft:stone
setblock 97 233 350 minecraft:stripped_spruce_log
fill 97 233 351 97 236 351 minecraft:stone
setblock 97 233 355 minecraft:stripped_spruce_log
fill 97 233 356 97 236 356 minecraft:stone
setblock 98 233 324 minecraft:stripped_spruce_log
setblock 98 233 349 minecraft:stripped_spruce_log
fill 98 233 350 98 235 350 minecraft:stone
setblock 98 233 354 minecraft:stripped_spruce_log
fill 98 233 359 100 233 362 minecraft:raw_gold_block
setblock 99 233 323 minecraft:stripped_spruce_log
fill 99 233 356 99 233 358 minecraft:raw_gold_block
setblock 99 233 363 minecraft:stripped_spruce_log
setblock 100 233 323 minecraft:stone
setblock 100 233 363 minecraft:stone
setblock 109 233 323 minecraft:stripped_spruce_log
fill 110 233 323 113 233 323 minecraft:stone
setblock 111 233 325 minecraft:stone
setblock 112 233 325 minecraft:stripped_spruce_log
setblock 113 233 324 minecraft:stripped_spruce_log
fill 113 233 325 115 233 326 minecraft:stone
setblock 113 233 363 minecraft:stone
setblock 114 233 323 minecraft:stripped_spruce_log
setblock 114 233 324 minecraft:stone
setblock 114 233 363 minecraft:stripped_spruce_log
fill 115 233 323 118 233 323 minecraft:stone
fill 115 233 324 115 234 324 minecraft:spruce_log
fill 115 233 362 115 234 362 minecraft:spruce_log
fill 115 233 363 118 233 363 minecraft:stone
fill 116 233 324 116 233 325 minecraft:stone
setblock 116 233 326 minecraft:stripped_spruce_log
fill 116 233 327 117 233 327 minecraft:stone
setblock 117 233 324 minecraft:stone
setblock 117 233 325 minecraft:stripped_spruce_log
fill 117 233 326 117 235 326 minecraft:stone
setblock 118 233 324 minecraft:stripped_spruce_log
fill 118 233 325 118 236 325 minecraft:stone
setblock 119 233 323 minecraft:stripped_spruce_log
fill 119 233 324 122 233 324 minecraft:stone
setblock 119 233 363 minecraft:stripped_spruce_log
fill 120 233 323 123 233 323 minecraft:stone
setblock 120 233 326 minecraft:stone
setblock 120 233 363 minecraft:stone
setblock 122 233 325 minecraft:stripped_spruce_log
setblock 123 233 324 minecraft:stripped_spruce_log
setblock 123 233 325 minecraft:stone
fill 124 233 322 124 247 322 minecraft:andesite
setblock 124 233 323 minecraft:stripped_spruce_log
setblock 124 233 324 minecraft:stone
setblock 125 233 323 minecraft:stone
setblock 127 233 363 minecraft:stone
setblock 128 233 324 minecraft:stripped_spruce_log
setblock 128 233 325 minecraft:stone
setblock 129 233 323 minecraft:stripped_spruce_log
setblock 129 233 324 minecraft:stone
setblock 129 233 363 minecraft:stripped_spruce_log
setblock 130 233 323 minecraft:stone
setblock 130 233 363 minecraft:stone
setblock 131 233 362 minecraft:stone
fill 131 233 364 131 247 364 minecraft:andesite
setblock 132 233 325 minecraft:stripped_spruce_log
fill 132 233 326 132 233 327 minecraft:stone
setblock 133 233 324 minecraft:stripped_spruce_log
fill 133 233 325 133 236 325 minecraft:stone
setblock 133 233 329 minecraft:stripped_spruce_log
fill 133 233 330 133 235 331 minecraft:stone
fill 133 233 347 133 233 348 minecraft:stone
setblock 133 233 349 minecraft:stripped_spruce_log
fill 133 233 350 133 233 353 minecraft:stone
setblock 133 233 354 minecraft:stripped_spruce_log
fill 133 233 355 134 233 357 minecraft:stone
setblock 134 233 323 minecraft:stripped_spruce_log
fill 134 233 324 134 234 324 minecraft:spruce_log
setblock 134 233 328 minecraft:stripped_spruce_log
setblock 134 233 329 minecraft:stone
setblock 134 233 333 minecraft:stripped_spruce_log
setblock 134 233 334 minecraft:stone
fill 134 233 343 134 234 343 minecraft:spruce_log
setblock 134 233 344 minecraft:stone
setblock 134 233 348 minecraft:stripped_spruce_log
fill 134 233 349 134 233 352 minecraft:stone
setblock 134 233 353 minecraft:stripped_spruce_log
setblock 134 233 354 minecraft:stone
setblock 134 233 358 minecraft:stripped_spruce_log
setblock 134 233 359 minecraft:stone
fill 134 233 362 134 234 362 minecraft:spruce_log
setblock 134 233 363 minecraft:stripped_spruce_log
setblock 135 233 323 minecraft:stone
setblock 135 233 327 minecraft:stripped_spruce_log
setblock 135 233 328 minecraft:stone
setblock 135 233 332 minecraft:stripped_spruce_log
setblock 135 233 333 minecraft:stone
setblock 135 233 337 minecraft:stripped_spruce_log
fill 135 233 338 135 233 339 minecraft:stone
setblock 135 233 342 minecraft:stripped_spruce_log
setblock 135 233 343 minecraft:stone
setblock 135 233 347 minecraft:stripped_spruce_log
setblock 135 233 348 minecraft:stone
setblock 135 233 352 minecraft:stripped_spruce_log
setblock 135 233 353 minecraft:stone
setblock 135 233 357 minecraft:stripped_spruce_log
setblock 135 233 358 minecraft:stone
setblock 135 233 362 minecraft:stripped_spruce_log
setblock 135 233 363 minecraft:stone
setblock 136 233 343 minecraft:diamond_block
fill 136 233 351 136 247 351 minecraft:andesite
setblock 94 234 347 minecraft:raw_iron_block
fill 94 234 352 94 245 352 minecraft:andesite
setblock 94 234 353 minecraft:raw_gold_block
fill 94 234 354 94 247 354 minecraft:andesite
fill 95 234 323 95 234 363 minecraft:spruce_planks
fill 96 234 323 135 234 323 minecraft:spruce_planks
fill 96 234 325 96 234 342 minecraft:spruce_planks
fill 96 234 344 96 234 361 minecraft:spruce_planks
fill 96 234 363 135 234 363 minecraft:spruce_planks
fill 97 234 324 114 234 324 minecraft:spruce_planks
setblock 97 234 344 minecraft:stripped_spruce_log
fill 97 234 345 97 235 345 minecraft:stone
setblock 97 234 349 minecraft:stripped_spruce_log
fill 97 234 350 97 237 350 minecraft:stone
setblock 97 234 353 minecraft:stone
setblock 97 234 354 minecraft:stripped_spruce_log
fill 97 234 355 97 237 355 minecraft:stone
fill 97 234 362 114 234 362 minecraft:spruce_planks
setblock 98 234 348 minecraft:stripped_spruce_log
fill 98 234 349 98 235 349 minecraft:stone
setblock 98 234 353 minecraft:stripped_spruce_log
setblock 98 234 354 minecraft:stone
fill 98 234 361 100 234 361 minecraft:raw_gold_block
fill 99 234 359 99 234 360 minecraft:raw_gold_block
setblock 111 234 325 minecraft:stripped_spruce_log
fill 112 234 325 115 234 325 minecraft:stone
fill 113 234 326 114 234 326 minecraft:stone
setblock 115 234 326 minecraft:stripped_spruce_log
fill 116 234 324 133 234 324 minecraft:spruce_planks
setblock 116 234 325 minecraft:stripped_spruce_log
fill 116 234 326 116 235 326 minecraft:stone
fill 116 234 362 133 234 362 minecraft:spruce_planks
fill 117 234 325 117 236 325 minecraft:stone
setblock 121 234 325 minecraft:stripped_spruce_log
setblock 122 234 325 minecraft:stone
setblock 131 234 325 minecraft:stripped_spruce_log
setblock 132 234 322 minecraft:diamond_block
fill 132 234 325 132 236 325 minecraft:stone
fill 133 234 322 134 239 322 minecraft:andesite
setblock 133 234 328 minecraft:stripped_spruce_log
fill 133 234 329 133 237 329 minecraft:stone
setblock 133 234 332 minecraft:stone
setblock 133 234 347 minecraft:stone
setblock 133 234 348 minecraft:stripped_spruce_log
fill 133 234 349 133 234 352 minecraft:stone
setblock 133 234 353 minecraft:stripped_spruce_log
fill 133 234 354 133 234 357 minecraft:stone
setblock 133 234 358 minecraft:stripped_spruce_log
fill 133 234 359 133 236 360 minecraft:stone
fill 134 234 325 135 234 342 minecraft:spruce_planks
fill 134 234 344 135 234 361 minecraft:spruce_planks
setblock 135 234 324 minecraft:spruce_planks
setblock 135 234 343 minecraft:spruce_planks
setblock 135 234 362 minecraft:spruce_planks
fill 136 234 323 136 247 323 minecraft:andesite
setblock 136 234 324 minecraft:gold_block
fill 136 234 325 136 241 326 minecraft:andesite
fill 136 234 343 136 240 343 minecraft:andesite
fill 94 235 347 94 247 347 minecraft:andesite
fill 94 235 353 94 247 353 minecraft:andesite
fill 95 235 323 95 235 324 minecraft:stone
setblock 95 235 325 minecraft:stripped_spruce_log
fill 95 235 326 95 235 329 minecraft:stone
setblock 95 235 330 minecraft:stripped_spruce_log
fill 95 235 331 95 235 334 minecraft:stone
setblock 95 235 335 minecraft:stripped_spruce_log
fill 95 235 336 95 235 339 minecraft:stone
setblock 95 235 340 minecraft:stripped_spruce_log
fill 95 235 341 95 235 344 minecraft:stone
setblock 95 235 345 minecraft:stripped_spruce_log
fill 95 235 346 95 235 349 minecraft:stone
setblock 95 235 350 minecraft:stripped_spruce_log
fill 95 235 351 95 235 354 minecraft:stone
setblock 95 235 355 minecraft:stripped_spruce_log
fill 95 235 356 95 235 359 minecraft:stone
setblock 95 235 360 minecraft:stripped_spruce_log
fill 95 235 361 95 236 363 minecraft:stone
setblock 96 235 323 minecraft:stone
fill 96 235 325 96 235 328 minecraft:stone
setblock 96 235 329 minecraft:stripped_spruce_log
fill 96 235 330 96 235 333 minecraft:stone
setblock 96 235 334 minecraft:stripped_spruce_log
fill 96 235 335 96 236 336 minecraft:stone
fill 96 235 341 96 235 343 minecraft:stone
setblock 96 235 344 minecraft:stripped_spruce_log
fill 96 235 345 96 235 348 minecraft:stone
setblock 96 235 349 minecraft:stripped_spruce_log
fill 96 235 350 96 235 353 minecraft:stone
setblock 96 235 354 minecraft:stripped_spruce_log
fill 96 235 355 96 235 358 minecraft:stone
setblock 96 235 359 minecraft:stripped_spruce_log
fill 96 235 360 96 235 361 minecraft:stone
setblock 96 235 363 minecraft:stone
setblock 97 235 323 minecraft:stripped_spruce_log
setblock 97 235 325 minecraft:light[level=15]
setblock 97 235 332 minecraft:light[level=12]
setblock 97 235 333 minecraft:light[level=15]
setblock 97 235 339 minecraft:light[level=12]
setblock 97 235 341 minecraft:light[level=15]
setblock 97 235 348 minecraft:stripped_spruce_log
fill 97 235 349 97 237 349 minecraft:stone
setblock 97 235 353 minecraft:stripped_spruce_log
fill 97 235 354 97 238 354 minecraft:stone
setblock 97 235 360 minecraft:light[level=12]
setblock 97 235 363 minecraft:stripped_spruce_log
setblock 98 235 348 minecraft:stone
setblock 98 235 352 minecraft:stripped_spruce_log
setblock 98 235 353 minecraft:stone
setblock 98 235 363 minecraft:stone
setblock 99 235 362 minecraft:raw_gold_block
setblock 104 235 325 minecraft:light[level=12]
setblock 104 235 332 minecraft:light[level=12]
setblock 104 235 339 minecraft:light[level=12]
setblock 104 235 346 minecraft:light[level=12]
setblock 104 235 353 minecraft:light[level=12]
setblock 104 235 360 minecraft:light[level=12]
setblock 105 235 325 minecraft:light[level=15]
setblock 105 235 333 minecraft:light[level=15]
setblock 105 235 341 minecraft:light[level=15]
setblock 105 235 349 minecraft:light[level=15]
setblock 105 235 357 minecraft:light[level=15]
setblock 105 235 364 minecraft:raw_gold_block
fill 109 235 323 111 235 323 minecraft:stone
setblock 110 235 324 minecraft:stone
setblock 111 235 324 minecraft:stripped_spruce_log
fill 111 235 325 114 235 325 minecraft:stone
setblock 111 235 332 minecraft:light[level=12]
setblock 111 235 339 minecraft:light[level=12]
setblock 111 235 346 minecraft:light[level=12]
setblock 111 235 353 minecraft:light[level=12]
setblock 111 235 360 minecraft:light[level=12]
setblock 112 235 323 minecraft:stripped_spruce_log
fill 112 235 324 115 235 324 minecraft:stone
fill 113 235 323 116 235 323 minecraft:stone
setblock 113 235 326 minecraft:stone
setblock 113 235 333 minecraft:light[level=15]
setblock 113 235 341 minecraft:light[level=15]
setblock 113 235 349 minecraft:light[level=15]
setblock 113 235 357 minecraft:light[level=15]
fill 113 235 363 116 235 363 minecraft:stone
setblock 114 235 326 minecraft:stripped_spruce_log
setblock 115 235 325 minecraft:stripped_spruce_log
fill 115 235 326 115 236 326 minecraft:stone
fill 115 235 362 117 236 362 minecraft:raw_gold_block
setblock 116 235 324 minecraft:stripped_spruce_log
fill 116 235 325 116 236 325 minecraft:stone
fill 116 235 361 116 237 361 minecraft:raw_gold_block
setblock 117 235 323 minecraft:stripped_spruce_log
fill 117 235 324 120 235 324 minecraft:stone
setblock 117 235 363 minecraft:stripped_spruce_log
fill 118 235 323 121 235 323 minecraft:stone
setblock 118 235 332 minecraft:light[level=12]
setblock 118 235 339 minecraft:light[level=12]
setblock 118 235 346 minecraft:light[level=12]
setblock 118 235 353 minecraft:light[level=12]
setblock 118 235 360 minecraft:light[level=12]
setblock 120 235 325 minecraft:stripped_spruce_log
setblock 121 235 324 minecraft:stripped_spruce_log
setblock 121 235 325 minecraft:light[level=15]
setblock 121 235 333 minecraft:light[level=15]
setblock 121 235 341 minecraft:light[level=15]
setblock 121 235 349 minecraft:light[level=15]
setblock 121 235 357 minecraft:light[level=15]
setblock 122 235 323 minecraft:stripped_spruce_log
fill 122 235 324 125 235 324 minecraft:stone
fill 123 235 323 126 235 323 minecraft:stone
setblock 125 235 325 minecraft:light[level=12]
setblock 125 235 332 minecraft:light[level=12]
setblock 125 235 339 minecraft:light[level=12]
setblock 125 235 346 minecraft:light[level=12]
setblock 125 235 353 minecraft:light[level=12]
setblock 125 235 360 minecraft:light[level=12]
setblock 126 235 324 minecraft:stripped_spruce_log
setblock 127 235 323 minecraft:stripped_spruce_log
fill 127 235 324 130 235 324 minecraft:stone
setblock 127 235 363 minecraft:stripped_spruce_log
fill 128 235 323 131 235 323 minecraft:stone
fill 128 235 363 131 235 363 minecraft:stone
setblock 129 235 325 minecraft:iron_bars
setblock 129 235 333 minecraft:light[level=15]
setblock 129 235 341 minecraft:light[level=15]
setblock 129 235 349 minecraft:light[level=15]
setblock 129 235 357 minecraft:light[level=15]
setblock 130 235 325 minecraft:stripped_spruce_log
fill 130 235 362 132 235 362 minecraft:stone
setblock 131 235 324 minecraft:stripped_spruce_log
fill 131 235 325 131 236 325 minecraft:stone
fill 132 235 322 132 247 322 minecraft:andesite
setblock 132 235 323 minecraft:stripped_spruce_log
fill 132 235 324 135 235 324 minecraft:stone
setblock 132 235 332 minecraft:light[level=12]
setblock 132 235 339 minecraft:light[level=12]
setblock 132 235 346 minecraft:light[level=12]
setblock 132 235 353 minecraft:light[level=12]
setblock 132 235 360 minecraft:light[level=12]
setblock 132 235 363 minecraft:stripped_spruce_log
fill 133 235 323 135 236 323 minecraft:stone
setblock 133 235 327 minecraft:stripped_spruce_log
fill 133 235 328 135 236 328 minecraft:stone
setblock 133 235 332 minecraft:stripped_spruce_log
fill 133 235 348 133 235 351 minecraft:stone
setblock 133 235 352 minecraft:stripped_spruce_log
fill 133 235 353 133 235 356 minecraft:stone
setblock 133 235 357 minecraft:stripped_spruce_log
fill 133 235 358 135 236 358 minecraft:stone
setblock 133 235 361 minecraft:stone
setblock 133 235 362 minecraft:stripped_spruce_log
fill 133 235 363 135 236 363 minecraft:stone
setblock 134 235 325 minecraft:stone
setblock 134 235 326 minecraft:stripped_spruce_log
fill 134 235 327 135 237 327 minecraft:stone
fill 134 235 329 134 235 330 minecraft:stone
setblock 134 235 331 minecraft:stripped_spruce_log
fill 134 235 332 134 235 335 minecraft:stone
setblock 134 235 345 minecraft:stone
setblock 134 235 346 minecraft:stripped_spruce_log
fill 134 235 347 134 235 350 minecraft:stone
setblock 134 235 351 minecraft:stripped_spruce_log
fill 134 235 352 134 235 355 minecraft:stone
setblock 134 235 356 minecraft:stripped_spruce_log
fill 134 235 357 135 237 357 minecraft:stone
fill 134 235 359 134 235 360 minecraft:stone
setblock 134 235 361 minecraft:stripped_spruce_log
fill 134 235 362 135 237 362 minecraft:stone
setblock 135 235 325 minecraft:stripped_spruce_log
fill 135 235 326 135 238 326 minecraft:stone
setblock 135 235 329 minecraft:stone
setblock 135 235 330 minecraft:stripped_spruce_log
fill 135 235 331 135 235 334 minecraft:stone
setblock 135 235 335 minecraft:stripped_spruce_log
fill 135 235 336 135 235 339 minecraft:stone
fill 135 235 341 135 235 344 minecraft:stone
setblock 135 235 345 minecraft:stripped_spruce_log
fill 135 235 346 135 235 349 minecraft:stone
setblock 135 235 350 minecraft:stripped_spruce_log
fill 135 235 351 135 235 354 minecraft:stone
setblock 135 235 355 minecraft:stripped_spruce_log
fill 135 235 356 135 238 356 minecraft:stone
setblock 135 235 359 minecraft:stone
setblock 135 235 360 minecraft:stripped_spruce_log
fill 135 235 361 135 238 361 minecraft:stone
fill 136 235 324 136 247 324 minecraft:andesite
setblock 94 236 323 minecraft:raw_gold_block
setblock 94 236 357 minecraft:raw_iron_block
setblock 95 236 323 minecraft:stone
setblock 95 236 324 minecraft:stripped_spruce_log
fill 95 236 325 95 236 328 minecraft:stone
setblock 95 236 329 minecraft:stripped_spruce_log
fill 95 236 330 95 236 333 minecraft:stone
setblock 95 236 334 minecraft:stripped_spruce_log
fill 95 236 335 95 236 338 minecraft:stone
setblock 95 236 339 minecraft:stripped_spruce_log
fill 95 236 340 95 236 343 minecraft:stone
setblock 95 236 344 minecraft:stripped_spruce_log
fill 95 236 345 95 236 348 minecraft:stone
setblock 95 236 349 minecraft:stripped_spruce_log
fill 95 236 350 95 236 353 minecraft:stone
setblock 95 236 354 minecraft:stripped_spruce_log
fill 95 236 355 95 236 358 minecraft:stone
setblock 95 236 359 minecraft:stripped_spruce_log
fill 95 236 360 96 236 360 minecraft:stone
setblock 96 236 323 minecraft:stripped_spruce_log
setblock 96 236 327 minecraft:stone
setblock 96 236 328 minecraft:stripped_spruce_log
fill 96 236 329 96 236 332 minecraft:stone
setblock 96 236 333 minecraft:stripped_spruce_log
fill 96 236 334 96 239 334 minecraft:stone
setblock 96 236 343 minecraft:stripped_spruce_log
fill 96 236 344 96 236 347 minecraft:stone
setblock 96 236 348 minecraft:stripped_spruce_log
fill 96 236 349 96 236 352 minecraft:stone
setblock 96 236 353 minecraft:stripped_spruce_log
fill 96 236 354 96 236 357 minecraft:stone
setblock 96 236 358 minecraft:stripped_spruce_log
fill 96 236 359 96 238 359 minecraft:stone
setblock 96 236 363 minecraft:stripped_spruce_log
setblock 97 236 347 minecraft:stripped_spruce_log
fill 97 236 348 97 237 348 minecraft:stone
setblock 97 236 352 minecraft:stripped_spruce_log
fill 97 236 353 97 238 353 minecraft:stone
setblock 97 236 363 minecraft:stone
setblock 98 236 351 minecraft:stripped_spruce_log
setblock 98 236 352 minecraft:stone
fill 105 236 364 105 248 364 minecraft:andesite
fill 109 236 323 110 236 323 minecraft:stone
setblock 110 236 324 minecraft:stripped_spruce_log
setblock 111 236 323 minecraft:stripped_spruce_log
fill 111 236 324 114 236 324 minecraft:stone
fill 112 236 323 115 236 323 minecraft:stone
fill 112 236 325 113 236 325 minecraft:stone
setblock 114 236 325 minecraft:stripped_spruce_log
setblock 114 236 326 minecraft:stone
fill 114 236 363 115 236 363 minecraft:stone
setblock 115 236 324 minecraft:stripped_spruce_log
fill 115 236 325 115 237 325 minecraft:stone
setblock 115 236 361 minecraft:raw_gold_block
setblock 116 236 323 minecraft:stripped_spruce_log
fill 116 236 324 119 236 324 minecraft:stone
fill 116 236 360 116 237 360 minecraft:raw_gold_block
setblock 116 236 363 minecraft:raw_gold_block
fill 117 236 323 120 236 323 minecraft:stone
setblock 117 236 361 minecraft:raw_gold_block
setblock 120 236 324 minecraft:stripped_spruce_log
setblock 121 236 323 minecraft:stripped_spruce_log
fill 122 236 323 125 236 323 minecraft:stone
setblock 126 236 323 minecraft:stripped_spruce_log
fill 127 236 323 130 236 323 minecraft:stone
fill 127 236 363 130 236 363 minecraft:stone
fill 128 236 324 129 236 324 minecraft:stone
setblock 130 236 324 minecraft:stripped_spruce_log
fill 130 236 362 131 236 362 minecraft:stone
setblock 131 236 323 minecraft:stripped_spruce_log
fill 131 236 324 134 236 324 minecraft:stone
setblock 131 236 363 minecraft:stripped_spruce_log
fill 132 236 323 132 239 323 minecraft:stone
setblock 132 236 352 minecraft:stripped_spruce_log
fill 132 236 353 134 236 354 minecraft:stone
setblock 132 236 362 minecraft:stripped_spruce_log
fill 132 236 363 132 239 363 minecraft:stone
setblock 133 236 326 minecraft:stripped_spruce_log
setblock 133 236 327 minecraft:stone
setblock 133 236 330 minecraft:stone
setblock 133 236 331 minecraft:stripped_spruce_log
fill 133 236 332 135 236 332 minecraft:stone
fill 133 236 348 133 236 350 minecraft:stone
setblock 133 236 351 minecraft:stripped_spruce_log
fill 133 236 352 135 237 352 minecraft:stone
setblock 133 236 355 minecraft:stone
setblock 133 236 356 minecraft:stripped_spruce_log
fill 133 236 357 133 239 357 minecraft:stone
setblock 133 236 361 minecraft:stripped_spruce_log
fill 133 236 362 133 239 362 minecraft:stone
setblock 134 236 325 minecraft:stripped_spruce_log
fill 134 236 326 134 237 326 minecraft:stone
setblock 134 236 329 minecraft:stone
setblock 134 236 330 minecraft:stripped_spruce_log
fill 134 236 331 135 238 331 minecraft:stone
fill 134 236 333 134 236 334 minecraft:stone
setblock 134 236 335 minecraft:stripped_spruce_log
fill 134 236 346 134 236 349 minecraft:stone
setblock 134 236 350 minecraft:stripped_spruce_log
fill 134 236 351 135 238 351 minecraft:stone
setblock 134 236 355 minecraft:stripped_spruce_log
fill 134 236 356 134 239 356 minecraft:stone
setblock 134 236 359 minecraft:stone
setblock 134 236 360 minecraft:stripped_spruce_log
fill 134 236 361 134 239 361 minecraft:stone
setblock 135 236 324 minecraft:stripped_spruce_log
fill 135 236 325 135 238 325 minecraft:stone
setblock 135 236 329 minecraft:stripped_spruce_log
fill 135 236 330 135 239 330 minecraft:stone
setblock 135 236 333 minecraft:stone
setblock 135 236 334 minecraft:stripped_spruce_log
fill 135 236 335 135 236 338 minecraft:stone
fill 135 236 342 135 236 343 minecraft:stone
setblock 135 236 344 minecraft:stripped_spruce_log
fill 135 236 345 135 236 348 minecraft:stone
setblock 135 236 349 minecraft:stripped_spruce_log
fill 135 236 350 135 239 350 minecraft:stone
setblock 135 236 353 minecraft:stone
setblock 135 236 354 minecraft:stripped_spruce_log
fill 135 236 355 135 239 355 minecraft:stone
setblock 135 236 359 minecraft:stripped_spruce_log
fill 135 236 360 135 239 360 minecraft:stone
setblock 136 236 340 minecraft:diamond_block
setblock 136 236 342 minecraft:gold_block
fill 94 237 323 94 247 323 minecraft:andesite
fill 94 237 357 94 245 357 minecraft:andesite
fill 95 237 325 95 237 327 minecraft:stone
setblock 95 237 328 minecraft:stripped_spruce_log
fill 95 237 329 95 237 332 minecraft:stone
setblock 95 237 333 minecraft:stripped_spruce_log
fill 95 237 334 95 237 337 minecraft:stone
setblock 95 237 338 minecraft:stripped_spruce_log
fill 95 237 339 95 237 342 minecraft:stone
setblock 95 237 343 minecraft:stripped_spruce_log
fill 95 237 344 95 237 347 minecraft:stone
setblock 95 237 348 minecraft:stripped_spruce_log
fill 95 237 349 95 237 352 minecraft:stone
setblock 95 237 353 minecraft:stripped_spruce_log
fill 95 237 354 95 237 357 minecraft:stone
setblock 95 237 358 minecraft:stripped_spruce_log
fill 95 237 359 95 237 362 minecraft:stone
setblock 95 237 363 minecraft:stripped_spruce_log
fill 96 237 329 96 237 331 minecraft:stone
setblock 96 237 332 minecraft:stripped_spruce_log
fill 96 237 333 96 238 333 minecraft:stone
fill 96 237 335 96 238 335 minecraft:stone
fill 96 237 344 96 237 346 minecraft:stone
setblock 96 237 347 minecraft:stripped_spruce_log
fill 96 237 348 96 237 351 minecraft:stone
setblock 96 237 352 minecraft:stripped_spruce_log
fill 96 237 353 96 237 356 minecraft:stone
setblock 96 237 357 minecraft:stripped_spruce_log
fill 96 237 358 96 240 358 minecraft:stone
setblock 97 237 351 minecraft:stripped_spruce_log
fill 97 237 352 97 238 352 minecraft:stone
setblock 97 237 356 minecraft:stripped_spruce_log
setblock 108 237 364 minecraft:raw_gold_block
setblock 110 237 323 minecraft:stripped_spruce_log
fill 111 237 323 113 237 324 minecraft:stone
setblock 113 237 325 minecraft:stripped_spruce_log
setblock 114 237 323 minecraft:stone
setblock 114 237 324 minecraft:stripped_spruce_log
setblock 114 237 325 minecraft:stone
setblock 114 237 364 minecraft:raw_iron_block
setblock 115 237 323 minecraft:stripped_spruce_log
fill 115 237 324 118 237 324 minecraft:stone
fill 116 237 323 119 237 323 minecraft:stone
fill 116 237 359 116 238 359 minecraft:raw_gold_block
setblock 116 237 362 minecraft:raw_gold_block
setblock 120 237 323 minecraft:stripped_spruce_log
setblock 121 237 323 minecraft:stone
setblock 125 237 323 minecraft:stripped_spruce_log
setblock 126 237 322 minecraft:gold_block
fill 126 237 323 129 237 323 minecraft:stone
fill 127 237 363 129 237 363 minecraft:stone
setblock 129 237 324 minecraft:stripped_spruce_log
setblock 130 237 323 minecraft:stripped_spruce_log
fill 130 237 324 133 237 324 minecraft:stone
setblock 130 237 362 minecraft:stone
setblock 130 237 363 minecraft:stripped_spruce_log
fill 131 237 323 131 240 323 minecraft:stone
setblock 131 237 362 minecraft:stripped_spruce_log
fill 131 237 363 131 240 363 minecraft:stone
fill 132 237 353 132 237 355 minecraft:stone
fill 132 237 362 132 240 362 minecraft:stone
fill 133 237 323 134 237 323 minecraft:stone
fill 133 237 328 134 237 328 minecraft:stone
setblock 133 237 330 minecraft:stripped_spruce_log
setblock 133 237 331 minecraft:stone
setblock 133 237 349 minecraft:stone
setblock 133 237 350 minecraft:stripped_spruce_log
fill 133 237 351 133 240 351 minecraft:stone
fill 133 237 353 133 237 354 minecraft:stone
setblock 133 237 355 minecraft:stripped_spruce_log
fill 133 237 356 133 240 356 minecraft:stone
fill 133 237 358 133 237 359 minecraft:stone
setblock 133 237 360 minecraft:stripped_spruce_log
fill 133 237 363 134 237 363 minecraft:stone
setblock 134 237 324 minecraft:stripped_spruce_log
setblock 134 237 325 minecraft:stone
setblock 134 237 329 minecraft:stripped_spruce_log
fill 134 237 330 134 239 330 minecraft:stone
fill 134 237 332 134 237 333 minecraft:stone
setblock 134 237 334 minecraft:stripped_spruce_log
fill 134 237 347 134 237 348 minecraft:stone
setblock 134 237 349 minecraft:stripped_spruce_log
fill 134 237 350 134 240 350 minecraft:stone
setblock 134 237 353 minecraft:stone
setblock 134 237 354 minecraft:stripped_spruce_log
fill 134 237 355 134 240 355 minecraft:stone
setblock 134 237 358 minecraft:stone
setblock 134 237 359 minecraft:stripped_spruce_log
fill 134 237 360 134 240 360 minecraft:stone
setblock 135 237 323 minecraft:stripped_spruce_log
fill 135 237 324 135 238 324 minecraft:stone
setblock 135 237 328 minecraft:stripped_spruce_log
fill 135 237 329 135 240 329 minecraft:stone
setblock 135 237 332 minecraft:stone
setblock 135 237 333 minecraft:stripped_spruce_log
fill 135 237 334 135 237 337 minecraft:stone
fill 135 237 344 135 237 347 minecraft:stone
setblock 135 237 348 minecraft:stripped_spruce_log
fill 135 237 349 135 240 349 minecraft:stone
setblock 135 237 353 minecraft:stripped_spruce_log
fill 135 237 354 135 240 354 minecraft:stone
setblock 135 237 358 minecraft:stripped_spruce_log
fill 135 237 359 135 240 359 minecraft:stone
setblock 135 237 363 minecraft:stripped_spruce_log
fill 136 237 340 136 247 340 minecraft:andesite
fill 136 237 342 136 243 342 minecraft:andesite
setblock 95 238 327 minecraft:stripped_spruce_log
fill 95 238 328 95 238 331 minecraft:stone
setblock 95 238 332 minecraft:stripped_spruce_log
fill 95 238 333 95 238 336 minecraft:stone
setblock 95 238 337 minecraft:stripped_spruce_log
fill 95 238 338 95 238 341 minecraft:stone
setblock 95 238 342 minecraft:stripped_spruce_log
fill 95 238 343 95 238 346 minecraft:stone
setblock 95 238 347 minecraft:stripped_spruce_log
fill 95 238 348 95 238 351 minecraft:stone
setblock 95 238 352 minecraft:stripped_spruce_log
fill 95 238 353 95 238 356 minecraft:stone
setblock 95 238 357 minecraft:stripped_spruce_log
fill 95 238 358 95 238 361 minecraft:stone
setblock 95 238 362 minecraft:stripped_spruce_log
setblock 96 238 331 minecraft:stripped_spruce_log
setblock 96 238 332 minecraft:stone
setblock 96 238 346 minecraft:stripped_spruce_log
fill 96 238 347 96 238 350 minecraft:stone
setblock 96 238 351 minecraft:stripped_spruce_log
fill 96 238 352 96 238 355 minecraft:stone
setblock 96 238 356 minecraft:stripped_spruce_log
fill 96 238 357 96 241 357 minecraft:stone
setblock 97 238 350 minecraft:stripped_spruce_log
setblock 97 238 351 minecraft:stone
setblock 97 238 355 minecraft:stripped_spruce_log
fill 100 238 329 101 238 329 minecraft:raw_gold_block
fill 108 238 364 108 248 364 minecraft:andesite
fill 110 238 323 113 238 323 minecraft:stone
setblock 110 238 364 minecraft:gold_block
setblock 112 238 324 minecraft:stone
setblock 113 238 324 minecraft:stripped_spruce_log
setblock 114 238 323 minecraft:stripped_spruce_log
fill 114 238 324 116 238 324 minecraft:stone
fill 114 238 364 114 247 364 minecraft:andesite
fill 115 238 323 118 238 323 minecraft:stone
setblock 116 238 358 minecraft:raw_gold_block
fill 126 238 322 126 247 322 minecraft:andesite
fill 127 238 323 128 238 323 minecraft:stone
fill 127 238 363 128 238 363 minecraft:stone
setblock 129 238 323 minecraft:stripped_spruce_log
setblock 129 238 363 minecraft:stripped_spruce_log
fill 130 238 323 130 241 323 minecraft:stone
setblock 130 238 362 minecraft:stripped_spruce_log
fill 130 238 363 130 241 363 minecraft:stone
fill 131 238 324 132 238 324 minecraft:stone
fill 131 238 362 131 241 362 minecraft:stone
fill 132 238 353 132 238 354 minecraft:stone
setblock 132 238 355 minecraft:stripped_spruce_log
fill 132 238 356 132 241 356 minecraft:stone
setblock 133 238 323 minecraft:stone
setblock 133 238 350 minecraft:stone
fill 133 238 352 133 238 353 minecraft:stone
setblock 133 238 354 minecraft:stripped_spruce_log
fill 133 238 355 133 241 355 minecraft:stone
setblock 133 238 358 minecraft:stone
setblock 133 238 359 minecraft:stripped_spruce_log
fill 133 238 360 133 241 360 minecraft:stone
setblock 133 238 363 minecraft:stone
setblock 134 238 323 minecraft:stripped_spruce_log
setblock 134 238 327 minecraft:stone
setblock 134 238 328 minecraft:stripped_spruce_log
setblock 134 238 329 minecraft:stone
setblock 134 238 332 minecraft:stone
setblock 134 238 333 minecraft:stripped_spruce_log
fill 134 238 334 135 238 334 minecraft:stone
setblock 134 238 347 minecraft:stone
setblock 134 238 348 minecraft:stripped_spruce_log
fill 134 238 349 134 240 349 minecraft:stone
setblock 134 238 352 minecraft:stone
setblock 134 238 353 minecraft:stripped_spruce_log
fill 134 238 354 134 241 354 minecraft:stone
setblock 134 238 357 minecraft:stone
setblock 134 238 358 minecraft:stripped_spruce_log
fill 134 238 359 134 241 359 minecraft:stone
setblock 134 238 362 minecraft:stone
setblock 134 238 363 minecraft:stripped_spruce_log
setblock 135 238 323 minecraft:stone
setblock 135 238 327 minecraft:stripped_spruce_log
fill 135 238 328 135 239 328 minecraft:stone
setblock 135 238 332 minecraft:stripped_spruce_log
fill 135 238 333 135 241 333 minecraft:stone
fill 135 238 335 135 238 336 minecraft:stone
setblock 135 238 337 minecraft:stripped_spruce_log
fill 135 238 345 135 238 346 minecraft:stone
setblock 135 238 347 minecraft:stripped_spruce_log
fill 135 238 348 135 241 348 minecraft:stone
setblock 135 238 352 minecraft:stripped_spruce_log
fill 135 238 353 135 241 353 minecraft:stone
setblock 135 238 357 minecraft:stripped_spruce_log
fill 135 238 358 135 241 358 minecraft:stone
setblock 135 238 362 minecraft:stripped_spruce_log
fill 135 238 363 135 241 363 minecraft:stone
setblock 94 239 341 minecraft:gold_block
fill 95 239 328 95 239 330 minecraft:stone
setblock 95 239 331 minecraft:stripped_spruce_log
fill 95 239 332 95 239 335 minecraft:stone
setblock 95 239 336 minecraft:stripped_spruce_log
fill 95 239 337 95 239 340 minecraft:stone
setblock 95 239 341 minecraft:stripped_spruce_log
fill 95 239 342 95 239 345 minecraft:stone
setblock 95 239 346 minecraft:stripped_spruce_log
fill 95 239 347 95 239 350 minecraft:stone
setblock 95 239 351 minecraft:stripped_spruce_log
fill 95 239 352 95 239 355 minecraft:stone
setblock 95 239 356 minecraft:stripped_spruce_log
fill 95 239 357 95 239 360 minecraft:stone
setblock 95 239 361 minecraft:stripped_spruce_log
fill 95 239 364 95 247 364 minecraft:andesite
fill 96 239 329 100 239 329 minecraft:raw_gold_block
fill 96 239 348 96 239 349 minecraft:stone
setblock 96 239 350 minecraft:stripped_spruce_log
fill 96 239 351 96 239 354 minecraft:stone
setblock 96 239 355 minecraft:stripped_spruce_log
fill 96 239 356 96 242 356 minecraft:stone
setblock 96 239 364 minecraft:diamond_block
fill 110 239 323 112 239 323 minecraft:stone
fill 110 239 364 110 247 364 minecraft:andesite
setblock 113 239 323 minecraft:stripped_spruce_log
fill 114 239 323 117 239 323 minecraft:stone
setblock 115 239 364 minecraft:raw_gold_block
setblock 127 239 323 minecraft:stone
setblock 127 239 363 minecraft:stone
setblock 128 239 323 minecraft:stripped_spruce_log
setblock 128 239 363 minecraft:stripped_spruce_log
fill 129 239 323 129 242 323 minecraft:stone
setblock 129 239 362 minecraft:stripped_spruce_log
fill 129 239 363 129 242 363 minecraft:stone
fill 130 239 362 130 242 362 minecraft:stone
setblock 132 239 354 minecraft:stripped_spruce_log
fill 132 239 355 132 242 355 minecraft:stone
setblock 133 239 323 minecraft:stripped_spruce_log
setblock 133 239 352 minecraft:stone
setblock 133 239 353 minecraft:stripped_spruce_log
fill 133 239 354 133 242 354 minecraft:stone
setblock 133 239 358 minecraft:stripped_spruce_log
fill 133 239 359 133 242 359 minecraft:stone
setblock 133 239 363 minecraft:stripped_spruce_log
setblock 134 239 323 minecraft:stone
setblock 134 239 331 minecraft:stone
setblock 134 239 332 minecraft:stripped_spruce_log
setblock 134 239 333 minecraft:stone
setblock 134 239 348 minecraft:stone
setblock 134 239 351 minecraft:stone
setblock 134 239 352 minecraft:stripped_spruce_log
fill 134 239 353 134 242 353 minecraft:stone
setblock 134 239 357 minecraft:stripped_spruce_log
fill 134 239 358 134 242 358 minecraft:stone
setblock 134 239 362 minecraft:stripped_spruce_log
fill 134 239 363 134 242 363 minecraft:stone
setblock 135 239 326 minecraft:stripped_spruce_log
setblock 135 239 327 minecraft:stone
setblock 135 239 331 minecraft:stripped_spruce_log
fill 135 239 332 135 242 332 minecraft:stone
fill 135 239 334 135 239 335 minecraft:stone
setblock 135 239 336 minecraft:stripped_spruce_log
fill 135 239 337 135 242 337 minecraft:stone
setblock 135 239 346 minecraft:stripped_spruce_log
fill 135 239 347 135 240 347 minecraft:stone
setblock 135 239 351 minecraft:stripped_spruce_log
fill 135 239 352 135 242 352 minecraft:stone
setblock 135 239 356 minecraft:stripped_spruce_log
fill 135 239 357 135 242 357 minecraft:stone
setblock 135 239 361 minecraft:stripped_spruce_log
fill 135 239 362 135 242 362 minecraft:stone
fill 94 240 341 94 242 341 minecraft:andesite
setblock 94 240 362 minecraft:gold_block
fill 95 240 328 98 240 329 minecraft:raw_gold_block
setblock 95 240 330 minecraft:stripped_spruce_log
fill 95 240 331 95 240 334 minecraft:stone
setblock 95 240 335 minecraft:stripped_spruce_log
fill 95 240 336 95 240 339 minecraft:stone
setblock 95 240 340 minecraft:stripped_spruce_log
fill 95 240 341 95 240 344 minecraft:stone
setblock 95 240 345 minecraft:stripped_spruce_log
fill 95 240 346 95 240 349 minecraft:stone
setblock 95 240 350 minecraft:stripped_spruce_log
fill 95 240 351 95 240 354 minecraft:stone
setblock 95 240 355 minecraft:stripped_spruce_log
fill 95 240 356 95 240 359 minecraft:stone
setblock 95 240 360 minecraft:stripped_spruce_log
fill 95 240 361 95 243 361 minecraft:stone
fill 96 240 330 98 240 330 minecraft:raw_gold_block
setblock 96 240 349 minecraft:stripped_spruce_log
fill 96 240 350 96 240 353 minecraft:stone
setblock 96 240 354 minecraft:stripped_spruce_log
fill 96 240 355 96 243 355 minecraft:stone
fill 96 240 364 96 243 364 minecraft:andesite
setblock 99 240 329 minecraft:raw_gold_block
fill 110 240 323 111 240 323 minecraft:stone
setblock 112 240 323 minecraft:stripped_spruce_log
fill 113 240 323 115 241 323 minecraft:stone
fill 115 240 364 115 247 364 minecraft:andesite
fill 119 240 322 119 247 322 minecraft:andesite
setblock 120 240 322 minecraft:raw_iron_block
setblock 126 240 363 minecraft:stone
setblock 127 240 363 minecraft:stripped_spruce_log
fill 128 240 323 128 243 323 minecraft:stone
setblock 128 240 362 minecraft:stripped_spruce_log
fill 128 240 363 128 243 363 minecraft:stone
fill 129 240 362 129 243 362 minecraft:stone
fill 130 240 325 130 241 327 minecraft:raw_gold_block
setblock 132 240 323 minecraft:stripped_spruce_log
fill 132 240 326 132 251 326 minecraft:iron_bars
setblock 132 240 357 minecraft:stone
setblock 132 240 363 minecraft:stripped_spruce_log
fill 133 240 322 133 243 322 minecraft:andesite
setblock 133 240 323 minecraft:stone
setblock 133 240 352 minecraft:stripped_spruce_log
fill 133 240 353 133 243 353 minecraft:stone
setblock 133 240 357 minecraft:stripped_spruce_log
fill 133 240 358 133 243 358 minecraft:stone
setblock 133 240 362 minecraft:stripped_spruce_log
fill 133 240 363 133 243 363 minecraft:stone
setblock 134 240 322 minecraft:raw_gold_block
setblock 134 240 351 minecraft:stripped_spruce_log
fill 134 240 352 134 243 352 minecraft:stone
setblock 134 240 356 minecraft:stripped_spruce_log
fill 134 240 357 134 243 357 minecraft:stone
setblock 134 240 361 minecraft:stripped_spruce_log
fill 134 240 362 134 243 362 minecraft:stone
setblock 135 240 330 minecraft:stripped_spruce_log
fill 135 240 331 135 241 331 minecraft:stone
setblock 135 240 334 minecraft:stone
setblock 135 240 335 minecraft:stripped_spruce_log
fill 135 240 336 135 243 336 minecraft:stone
setblock 135 240 350 minecraft:stripped_spruce_log
fill 135 240 351 135 243 351 minecraft:stone
setblock 135 240 355 minecraft:stripped_spruce_log
fill 135 240 356 135 243 356 minecraft:stone
setblock 135 240 360 minecraft:stripped_spruce_log
fill 135 240 361 135 243 361 minecraft:stone
setblock 94 241 358 minecraft:raw_gold_block
fill 94 241 362 94 247 362 minecraft:andesite
fill 95 241 328 96 241 330 minecraft:raw_gold_block
fill 95 241 331 95 241 333 minecraft:stone
setblock 95 241 334 minecraft:stripped_spruce_log
fill 95 241 335 95 241 338 minecraft:stone
setblock 95 241 339 minecraft:stripped_spruce_log
fill 95 241 340 95 241 343 minecraft:stone
setblock 95 241 344 minecraft:stripped_spruce_log
fill 95 241 345 95 241 348 minecraft:stone
setblock 95 241 349 minecraft:stripped_spruce_log
fill 95 241 350 95 241 353 minecraft:stone
setblock 95 241 354 minecraft:stripped_spruce_log
fill 95 241 355 95 241 358 minecraft:stone
setblock 95 241 359 minecraft:stripped_spruce_log
fill 95 241 360 95 244 360 minecraft:stone
fill 96 241 351 96 241 352 minecraft:stone
setblock 96 241 353 minecraft:stripped_spruce_log
fill 96 241 354 96 243 354 minecraft:stone
setblock 97 241 325 minecraft:light[level=12]
setblock 97 241 329 minecraft:raw_gold_block
setblock 97 241 332 minecraft:light[level=12]
setblock 97 241 339 minecraft:light[level=12]
setblock 97 241 346 minecraft:light[level=12]
setblock 97 241 353 minecraft:light[level=12]
setblock 97 241 360 minecraft:light[level=12]
setblock 104 241 325 minecraft:light[level=12]
setblock 104 241 332 minecraft:light[level=12]
setblock 104 241 339 minecraft:light[level=12]
setblock 104 241 346 minecraft:light[level=12]
setblock 104 241 353 minecraft:light[level=12]
setblock 104 241 360 minecraft:light[level=12]
fill 109 241 323 110 241 323 minecraft:stone
setblock 111 241 323 minecraft:stripped_spruce_log
setblock 111 241 325 minecraft:light[level=12]
setblock 111 241 332 minecraft:light[level=12]
setblock 111 241 339 minecraft:light[level=12]
setblock 111 241 346 minecraft:light[level=12]
setblock 111 241 353 minecraft:light[level=12]
setblock 111 241 360 minecraft:light[level=12]
fill 112 241 323 112 244 323 minecraft:stone
setblock 118 241 325 minecraft:light[level=12]
setblock 118 241 332 minecraft:light[level=12]
setblock 118 241 339 minecraft:light[level=12]
setblock 118 241 346 minecraft:light[level=12]
setblock 118 241 353 minecraft:light[level=12]
setblock 118 241 360 minecraft:light[level=12]
fill 120 241 322 120 245 322 minecraft:andesite
setblock 125 241 325 minecraft:light[level=12]
setblock 125 241 332 minecraft:light[level=12]
setblock 125 241 339 minecraft:light[level=12]
setblock 125 241 346 minecraft:light[level=12]
setblock 125 241 353 minecraft:light[level=12]
setblock 125 241 360 minecraft:light[level=12]
setblock 125 241 363 minecraft:stone
setblock 126 241 363 minecraft:stripped_spruce_log
fill 127 241 323 127 244 323 minecraft:stone
setblock 127 241 362 minecraft:stripped_spruce_log
fill 127 241 363 127 244 363 minecraft:stone
fill 128 241 362 128 244 362 minecraft:stone
fill 129 241 324 129 241 326 minecraft:raw_gold_block
fill 130 241 324 131 244 324 minecraft:raw_gold_block
fill 130 241 361 132 241 361 minecraft:stone
setblock 131 241 323 minecraft:stripped_spruce_log
fill 131 241 325 131 241 326 minecraft:raw_gold_block
setblock 131 241 363 minecraft:stripped_spruce_log
setblock 132 241 323 minecraft:stone
setblock 132 241 325 minecraft:light[level=12]
setblock 132 241 332 minecraft:light[level=12]
fill 132 241 336 132 247 336 minecraft:stripped_spruce_log
setblock 132 241 339 minecraft:light[level=12]
setblock 132 241 346 minecraft:light[level=12]
setblock 132 241 353 minecraft:light[level=12]
setblock 132 241 357 minecraft:stripped_spruce_log
setblock 132 241 360 minecraft:light[level=12]
setblock 132 241 362 minecraft:stripped_spruce_log
fill 132 241 363 132 244 363 minecraft:stone
fill 133 241 352 133 242 352 minecraft:stone
setblock 133 241 356 minecraft:stripped_spruce_log
fill 133 241 357 133 244 357 minecraft:stone
fill 133 241 362 133 244 362 minecraft:stone
fill 134 241 322 134 247 322 minecraft:andesite
setblock 134 241 350 minecraft:stripped_spruce_log
fill 134 241 351 134 244 351 minecraft:stone
setblock 134 241 355 minecraft:stripped_spruce_log
fill 134 241 356 134 244 356 minecraft:stone
setblock 134 241 360 minecraft:stripped_spruce_log
fill 134 241 361 134 244 361 minecraft:stone
setblock 135 241 334 minecraft:stripped_spruce_log
fill 135 241 335 135 244 335 minecraft:stone
setblock 135 241 349 minecraft:stripped_spruce_log
fill 135 241 350 135 244 350 minecraft:stone
setblock 135 241 354 minecraft:stripped_spruce_log
fill 135 241 355 135 244 355 minecraft:stone
setblock 135 241 359 minecraft:stripped_spruce_log
fill 135 241 360 135 244 360 minecraft:stone
setblock 136 241 343 minecraft:diamond_block
fill 94 242 358 94 244 358 minecraft:andesite
setblock 95 242 329 minecraft:raw_gold_block
fill 95 242 331 95 242 332 minecraft:stone
setblock 95 242 333 minecraft:stripped_spruce_log
fill 95 242 334 95 242 337 minecraft:stone
setblock 95 242 338 minecraft:stripped_spruce_log
fill 95 242 339 95 242 342 minecraft:stone
setblock 95 242 343 minecraft:stripped_spruce_log
fill 95 242 344 95 242 347 minecraft:stone
setblock 95 242 348 minecraft:stripped_spruce_log
fill 95 242 349 95 242 352 minecraft:stone
setblock 95 242 353 minecraft:stripped_spruce_log
fill 95 242 354 95 242 357 minecraft:stone
setblock 95 242 358 minecraft:stripped_spruce_log
fill 95 242 359 95 245 359 minecraft:stone
setblock 96 242 336 minecraft:stone
setblock 96 242 352 minecraft:stripped_spruce_log
setblock 96 242 353 minecraft:stone
setblock 96 242 357 minecraft:stripped_spruce_log
setblock 109 242 323 minecraft:stone
setblock 110 242 323 minecraft:stripped_spruce_log
setblock 110 242 363 minecraft:stripped_spruce_log
fill 111 242 323 111 245 323 minecraft:stone
fill 111 242 363 113 243 363 minecraft:stone
fill 113 242 323 114 242 323 minecraft:stone
setblock 115 242 323 minecraft:stripped_spruce_log
setblock 124 242 363 minecraft:stone
setblock 125 242 363 minecraft:stripped_spruce_log
fill 126 242 323 126 245 323 minecraft:stone
setblock 126 242 362 minecraft:stripped_spruce_log
fill 126 242 363 126 245 363 minecraft:stone
fill 127 242 362 127 245 362 minecraft:stone
fill 128 242 361 131 242 361 minecraft:stone
fill 129 242 324 129 243 325 minecraft:raw_gold_block
setblock 130 242 323 minecraft:stripped_spruce_log
fill 130 242 325 130 242 326 minecraft:raw_gold_block
setblock 130 242 363 minecraft:stripped_spruce_log
fill 131 242 323 131 245 323 minecraft:stone
fill 131 242 325 131 243 325 minecraft:raw_gold_block
setblock 131 242 362 minecraft:stripped_spruce_log
fill 131 242 363 131 245 363 minecraft:stone
setblock 132 242 323 minecraft:raw_gold_block
setblock 132 242 356 minecraft:stripped_spruce_log
fill 132 242 357 132 244 358 minecraft:stone
setblock 132 242 361 minecraft:stripped_spruce_log
fill 132 242 362 132 245 362 minecraft:stone
setblock 133 242 355 minecraft:stripped_spruce_log
fill 133 242 356 133 245 356 minecraft:stone
setblock 133 242 360 minecraft:stripped_spruce_log
fill 133 242 361 133 245 361 minecraft:stone
setblock 134 242 350 minecraft:stone
setblock 134 242 354 minecraft:stripped_spruce_log
fill 134 242 355 134 245 355 minecraft:stone
setblock 134 242 359 minecraft:stripped_spruce_log
fill 134 242 360 134 245 360 minecraft:stone
setblock 135 242 333 minecraft:stripped_spruce_log
fill 135 242 334 135 245 334 minecraft:stone
setblock 135 242 338 minecraft:stripped_spruce_log
setblock 135 242 348 minecraft:stripped_spruce_log
fill 135 242 349 135 245 349 minecraft:stone
setblock 135 242 353 minecraft:stripped_spruce_log
fill 135 242 354 135 245 354 minecraft:stone
setblock 135 242 358 minecraft:stripped_spruce_log
fill 135 242 359 135 245 359 minecraft:stone
setblock 135 242 363 minecraft:stripped_spruce_log
setblock 136 242 325 minecraft:gold_block
fill 136 242 326 136 244 326 minecraft:andesite
fill 136 242 343 136 247 343 minecraft:andesite
setblock 94 243 341 minecraft:gold_block
setblock 95 243 332 minecraft:stripped_spruce_log
fill 95 243 333 95 243 336 minecraft:stone
setblock 95 243 337 minecraft:stripped_spruce_log
fill 95 243 338 95 243 341 minecraft:stone
setblock 95 243 342 minecraft:stripped_spruce_log
fill 95 243 343 95 243 346 minecraft:stone
setblock 95 243 347 minecraft:stripped_spruce_log
fill 95 243 348 95 243 351 minecraft:stone
setblock 95 243 352 minecraft:stripped_spruce_log
fill 95 243 353 95 243 356 minecraft:stone
setblock 95 243 357 minecraft:stripped_spruce_log
fill 95 243 358 95 246 358 minecraft:stone
setblock 96 243 322 minecraft:gold_block
setblock 96 243 335 minecraft:stone
setblock 96 243 336 minecraft:stripped_spruce_log
fill 96 243 337 96 245 338 minecraft:stone
setblock 96 243 356 minecraft:stripped_spruce_log
setblock 96 243 357 minecraft:stone
setblock 97 243 325 minecraft:light[level=15]
setblock 97 243 333 minecraft:light[level=15]
setblock 97 243 341 minecraft:light[level=15]
setblock 97 243 349 minecraft:light[level=15]
setblock 97 243 357 minecraft:light[level=15]
fill 103 243 323 103 244 325 minecraft:iron_bars
setblock 105 243 325 minecraft:light[level=15]
setblock 105 243 333 minecraft:light[level=15]
setblock 105 243 341 minecraft:light[level=15]
setblock 105 243 349 minecraft:light[level=15]
setblock 105 243 357 minecraft:light[level=15]
fill 107 243 323 108 243 323 minecraft:stone
setblock 108 243 363 minecraft:stone
setblock 109 243 323 minecraft:stripped_spruce_log
setblock 109 243 363 minecraft:stripped_spruce_log
fill 110 243 323 110 246 323 minecraft:stone
fill 110 243 363 110 246 363 minecraft:stone
setblock 113 243 323 minecraft:stone
setblock 113 243 325 minecraft:light[level=15]
setblock 113 243 333 minecraft:light[level=15]
setblock 113 243 341 minecraft:light[level=15]
setblock 113 243 349 minecraft:light[level=15]
setblock 113 243 357 minecraft:light[level=15]
setblock 114 243 323 minecraft:stripped_spruce_log
setblock 114 243 363 minecraft:stripped_spruce_log
fill 115 243 323 115 246 323 minecraft:stone
setblock 121 243 325 minecraft:light[level=15]
setblock 121 243 333 minecraft:light[level=15]
setblock 121 243 341 minecraft:light[level=15]
setblock 121 243 349 minecraft:light[level=15]
setblock 121 243 357 minecraft:light[level=15]
setblock 121 243 364 minecraft:raw_gold_block
fill 122 243 363 123 243 363 minecraft:stone
fill 122 243 364 122 247 364 minecraft:andesite
setblock 124 243 362 minecraft:stone
setblock 124 243 363 minecraft:stripped_spruce_log
fill 125 243 323 125 246 323 minecraft:stone
setblock 125 243 362 minecraft:stripped_spruce_log
fill 125 243 363 125 246 363 minecraft:stone
setblock 126 243 361 minecraft:stripped_spruce_log
fill 126 243 362 126 246 362 minecraft:stone
fill 127 243 361 130 243 361 minecraft:stone
setblock 129 243 323 minecraft:stripped_spruce_log
setblock 129 243 333 minecraft:light[level=15]
setblock 129 243 341 minecraft:light[level=15]
setblock 129 243 349 minecraft:light[level=15]
setblock 129 243 357 minecraft:light[level=15]
fill 129 243 360 131 243 360 minecraft:stone
setblock 129 243 363 minecraft:stripped_spruce_log
fill 130 243 323 130 246 323 minecraft:stone
setblock 130 243 325 minecraft:raw_gold_block
setblock 130 243 362 minecraft:stripped_spruce_log
fill 130 243 363 130 246 363 minecraft:stone
setblock 131 243 361 minecraft:stripped_spruce_log
fill 131 243 362 131 246 362 minecraft:stone
fill 132 243 323 132 244 323 minecraft:stone
fill 132 243 337 134 243 337 minecraft:iron_bars
setblock 132 243 355 minecraft:stripped_spruce_log
fill 132 243 356 132 246 356 minecraft:stone
setblock 132 243 359 minecraft:stone
fill 132 243 361 132 246 361 minecraft:stone
setblock 133 243 354 minecraft:stripped_spruce_log
fill 133 243 355 133 246 355 minecraft:stone
setblock 133 243 359 minecraft:stripped_spruce_log
fill 133 243 360 133 246 360 minecraft:stone
setblock 134 243 353 minecraft:stripped_spruce_log
fill 134 243 354 134 246 354 minecraft:stone
setblock 134 243 358 minecraft:stripped_spruce_log
fill 134 243 359 134 246 359 minecraft:stone
setblock 134 243 363 minecraft:stripped_spruce_log
fill 135 243 333 135 244 333 minecraft:stone
setblock 135 243 337 minecraft:stripped_spruce_log
fill 135 243 338 135 244 340 minecraft:stone
fill 135 243 348 135 246 348 minecraft:stone
setblock 135 243 352 minecraft:stripped_spruce_log
fill 135 243 353 135 246 353 minecraft:stone
setblock 135 243 357 minecraft:stripped_spruce_log
fill 135 243 358 135 246 358 minecraft:stone
setblock 135 243 362 minecraft:stripped_spruce_log
fill 135 243 363 135 246 363 minecraft:stone
fill 136 243 325 136 245 325 minecraft:andesite
setblock 136 243 347 minecraft:raw_gold_block
fill 94 244 326 94 245 326 minecraft:stone
fill 94 244 332 94 247 332 minecraft:andesite
fill 94 244 333 95 244 333 minecraft:stone
setblock 94 244 339 minecraft:raw_gold_block
fill 94 244 340 95 244 340 minecraft:stone
fill 94 244 341 94 247 341 minecraft:andesite
fill 94 244 355 94 244 356 minecraft:stone
setblock 94 244 360 minecraft:stone
setblock 95 244 322 minecraft:stone
fill 95 244 332 95 247 332 minecraft:stone
fill 95 244 334 95 244 335 minecraft:stone
setblock 95 244 336 minecraft:stripped_spruce_log
fill 95 244 337 95 245 339 minecraft:stone
setblock 95 244 341 minecraft:stripped_spruce_log
fill 95 244 342 95 244 345 minecraft:stone
setblock 95 244 346 minecraft:stripped_spruce_log
fill 95 244 347 95 244 350 minecraft:stone
setblock 95 244 351 minecraft:stripped_spruce_log
fill 95 244 352 95 244 355 minecraft:stone
setblock 95 244 356 minecraft:stripped_spruce_log
fill 95 244 357 95 247 357 minecraft:stone
setblock 95 244 361 minecraft:stripped_spruce_log
fill 96 244 322 96 247 322 minecraft:andesite
fill 96 244 324 96 247 324 minecraft:spruce_log
setblock 96 244 335 minecraft:stripped_spruce_log
fill 96 244 336 96 247 336 minecraft:stone
setblock 96 244 339 minecraft:stone
setblock 96 244 340 minecraft:stripped_spruce_log
fill 96 244 343 96 247 343 minecraft:spruce_log
setblock 96 244 356 minecraft:stone
fill 96 244 362 96 247 362 minecraft:spruce_log
setblock 96 244 364 minecraft:stone
fill 97 244 322 98 244 322 minecraft:stone
setblock 99 244 364 minecraft:stone
fill 101 244 364 101 245 364 minecraft:stone
fill 102 244 364 103 247 364 minecraft:andesite
fill 106 244 323 107 244 323 minecraft:stone
fill 106 244 363 107 244 363 minecraft:stone
setblock 108 244 323 minecraft:stripped_spruce_log
setblock 108 244 363 minecraft:stripped_spruce_log
fill 109 244 323 109 246 324 minecraft:stone
setblock 109 244 362 minecraft:stripped_spruce_log
fill 109 244 363 109 247 363 minecraft:stone
fill 110 244 324 111 244 324 minecraft:stone
fill 110 244 362 112 245 362 minecraft:stone
fill 111 244 363 112 244 363 minecraft:stone
setblock 112 244 322 minecraft:stone
setblock 112 244 324 minecraft:stripped_spruce_log
setblock 112 244 364 minecraft:stone
setblock 113 244 323 minecraft:stripped_spruce_log
setblock 113 244 363 minecraft:stripped_spruce_log
fill 114 244 323 114 247 323 minecraft:stone
fill 114 244 363 117 244 363 minecraft:stone
fill 115 244 324 115 247 324 minecraft:spruce_log
fill 115 244 362 115 247 362 minecraft:spruce_log
fill 116 244 323 116 245 323 minecraft:stone
fill 119 244 363 122 244 363 minecraft:stone
setblock 121 244 322 minecraft:stone
fill 121 244 364 121 248 364 minecraft:andesite
setblock 123 244 323 minecraft:stripped_spruce_log
setblock 123 244 362 minecraft:stone
setblock 123 244 363 minecraft:stripped_spruce_log
fill 124 244 323 124 247 323 minecraft:stone
setblock 124 244 362 minecraft:stripped_spruce_log
fill 124 244 363 124 247 363 minecraft:stone
setblock 125 244 322 minecraft:stone
setblock 125 244 361 minecraft:stripped_spruce_log
fill 125 244 362 125 247 362 minecraft:stone
fill 126 244 361 129 244 361 minecraft:stone
fill 127 244 360 130 244 360 minecraft:stone
setblock 128 244 323 minecraft:stripped_spruce_log
setblock 128 244 363 minecraft:stripped_spruce_log
fill 129 244 322 129 244 323 minecraft:stone
setblock 129 244 324 minecraft:raw_gold_block
setblock 129 244 362 minecraft:stripped_spruce_log
fill 129 244 363 129 247 363 minecraft:stone
fill 130 244 322 130 247 322 minecraft:andesite
setblock 130 244 361 minecraft:stripped_spruce_log
fill 130 244 362 130 247 362 minecraft:stone
fill 131 244 336 131 247 336 minecraft:stripped_spruce_log
setblock 131 244 360 minecraft:stripped_spruce_log
fill 131 244 361 131 247 361 minecraft:stone
fill 132 244 335 132 247 335 minecraft:stripped_spruce_log
fill 132 244 337 132 247 337 minecraft:stripped_spruce_log
fill 132 244 355 132 245 355 minecraft:stone
setblock 132 244 359 minecraft:stripped_spruce_log
fill 132 244 360 132 247 360 minecraft:stone
setblock 133 244 322 minecraft:gold_block
fill 133 244 336 133 247 336 minecraft:stripped_spruce_log
fill 133 244 337 134 244 337 minecraft:iron_bars
setblock 133 244 353 minecraft:stripped_spruce_log
fill 133 244 354 133 247 354 minecraft:stone
setblock 133 244 358 minecraft:stripped_spruce_log
fill 133 244 359 133 247 359 minecraft:stone
setblock 133 244 363 minecraft:stripped_spruce_log
fill 134 244 324 134 247 324 minecraft:spruce_log
fill 134 244 343 134 247 343 minecraft:spruce_log
setblock 134 244 352 minecraft:stripped_spruce_log
fill 134 244 353 134 247 353 minecraft:stone
setblock 134 244 357 minecraft:stripped_spruce_log
fill 134 244 358 134 247 358 minecraft:stone
fill 134 244 362 134 247 362 minecraft:spruce_log
fill 134 244 363 134 247 363 minecraft:stone
setblock 135 244 336 minecraft:stripped_spruce_log
fill 135 244 337 135 247 337 minecraft:stone
setblock 135 244 341 minecraft:stripped_spruce_log
fill 135 244 342 136 244 342 minecraft:stone
setblock 135 244 351 minecraft:stripped_spruce_log
fill 135 244 352 135 247 352 minecraft:stone
setblock 135 244 356 minecraft:stripped_spruce_log
fill 135 244 357 135 247 357 minecraft:stone
setblock 135 244 361 minecraft:stripped_spruce_log
fill 135 244 362 136 244 362 minecraft:stone
fill 136 244 328 136 244 329 minecraft:stone
fill 136 244 332 136 244 333 minecraft:stone
setblock 136 244 339 minecraft:raw_iron_block
setblock 136 244 346 minecraft:gold_block
fill 136 244 347 136 247 347 minecraft:andesite
setblock 136 244 359 minecraft:stone
fill 136 244 360 136 247 360 minecraft:andesite
fill 136 244 363 136 245 364 minecraft:andesite
setblock 94 245 325 minecraft:stone
setblock 94 245 330 minecraft:stone
fill 94 245 333 94 247 333 minecraft:andesite
fill 94 245 339 94 247 340 minecraft:andesite
fill 94 245 355 94 245 356 minecraft:andesite
setblock 94 245 358 minecraft:stone
fill 94 245 360 94 247 360 minecraft:andesite
fill 94 245 361 95 245 361 minecraft:stone
fill 95 245 322 95 247 322 minecraft:andesite
fill 95 245 333 95 245 334 minecraft:stone
setblock 95 245 335 minecraft:stripped_spruce_log
fill 95 245 336 95 248 336 minecraft:stone
setblock 95 245 340 minecraft:stripped_spruce_log
fill 95 245 341 95 245 344 minecraft:stone
setblock 95 245 345 minecraft:stripped_spruce_log
fill 95 245 346 95 245 349 minecraft:stone
setblock 95 245 350 minecraft:stripped_spruce_log
fill 95 245 351 95 245 354 minecraft:stone
setblock 95 245 355 minecraft:stripped_spruce_log
fill 95 245 356 95 248 356 minecraft:stone
setblock 95 245 360 minecraft:stripped_spruce_log
fill 95 245 362 95 247 362 minecraft:stone
fill 96 245 335 96 248 335 minecraft:stone
setblock 96 245 339 minecraft:stripped_spruce_log
fill 96 245 340 96 246 342 minecraft:stone
fill 96 245 364 96 247 364 minecraft:andesite
fill 97 245 322 98 247 322 minecraft:andesite
fill 99 245 364 99 248 364 minecraft:andesite
setblock 101 245 322 minecraft:stone
fill 104 245 363 104 245 364 minecraft:stone
fill 105 245 323 106 245 323 minecraft:stone
fill 105 245 363 106 245 363 minecraft:stone
fill 106 245 362 107 245 362 minecraft:stone
setblock 107 245 323 minecraft:stripped_spruce_log
fill 107 245 324 108 247 324 minecraft:stone
setblock 107 245 363 minecraft:stripped_spruce_log
fill 108 245 323 108 248 323 minecraft:stone
setblock 108 245 362 minecraft:stripped_spruce_log
fill 108 245 363 108 248 363 minecraft:stone
fill 109 245 362 109 248 362 minecraft:stone
setblock 110 245 324 minecraft:stone
setblock 111 245 324 minecraft:stripped_spruce_log
setblock 111 245 363 minecraft:stone
fill 112 245 322 112 247 322 minecraft:andesite
setblock 112 245 323 minecraft:stripped_spruce_log
fill 112 245 324 113 247 324 minecraft:stone
setblock 112 245 363 minecraft:stripped_spruce_log
fill 112 245 364 112 247 364 minecraft:andesite
fill 113 245 323 113 248 323 minecraft:stone
setblock 113 245 362 minecraft:stripped_spruce_log
fill 113 245 363 116 245 363 minecraft:stone
fill 114 245 362 114 248 362 minecraft:stone
setblock 117 245 323 minecraft:stripped_spruce_log
setblock 117 245 363 minecraft:stripped_spruce_log
fill 118 245 323 121 245 323 minecraft:stone
fill 118 245 363 121 245 363 minecraft:stone
fill 118 245 364 118 247 364 minecraft:andesite
fill 119 245 364 120 245 364 minecraft:stone
fill 121 245 322 121 247 322 minecraft:andesite
fill 121 245 362 122 245 362 minecraft:stone
setblock 122 245 323 minecraft:stripped_spruce_log
setblock 122 245 363 minecraft:stripped_spruce_log
fill 123 245 323 123 248 323 minecraft:stone
setblock 123 245 361 minecraft:stone
setblock 123 245 362 minecraft:stripped_spruce_log
fill 123 245 363 123 248 363 minecraft:stone
setblock 124 245 361 minecraft:stripped_spruce_log
fill 124 245 362 124 248 362 minecraft:stone
fill 125 245 322 125 247 322 minecraft:andesite
setblock 125 245 360 minecraft:stripped_spruce_log
fill 125 245 361 128 245 361 minecraft:stone
fill 126 245 360 129 245 360 minecraft:stone
setblock 127 245 323 minecraft:stripped_spruce_log
setblock 127 245 363 minecraft:stripped_spruce_log
fill 128 245 322 128 245 323 minecraft:stone
setblock 128 245 362 minecraft:stripped_spruce_log
fill 128 245 363 128 248 363 minecraft:stone
fill 129 245 322 129 247 322 minecraft:andesite
fill 129 245 323 129 247 323 minecraft:stone
fill 129 245 359 129 246 359 minecraft:stone
setblock 129 245 361 minecraft:stripped_spruce_log
fill 129 245 362 129 248 362 minecraft:stone
setblock 130 245 355 minecraft:raw_gold_block
fill 130 245 357 130 245 359 minecraft:raw_gold_block
setblock 130 245 360 minecraft:stripped_spruce_log
fill 130 245 361 130 248 361 minecraft:stone
fill 131 245 360 131 248 360 minecraft:stone
setblock 132 245 323 minecraft:stripped_spruce_log
setblock 132 245 357 minecraft:stone
setblock 132 245 358 minecraft:stripped_spruce_log
fill 132 245 359 132 248 359 minecraft:stone
setblock 132 245 363 minecraft:stripped_spruce_log
fill 133 245 322 133 247 322 minecraft:andesite
setblock 133 245 353 minecraft:stone
setblock 133 245 357 minecraft:stripped_spruce_log
fill 133 245 358 133 248 358 minecraft:stone
setblock 133 245 362 minecraft:stripped_spruce_log
fill 133 245 363 133 248 363 minecraft:stone
fill 134 245 337 134 246 339 minecraft:stone
setblock 134 245 351 minecraft:stripped_spruce_log
fill 134 245 352 134 247 352 minecraft:stone
setblock 134 245 356 minecraft:stripped_spruce_log
fill 134 245 357 134 248 357 minecraft:stone
setblock 134 245 361 minecraft:stripped_spruce_log
setblock 135 245 335 minecraft:stripped_spruce_log
fill 135 245 336 135 248 336 minecraft:stone
fill 135 245 338 135 245 339 minecraft:stone
setblock 135 245 340 minecraft:stripped_spruce_log
fill 135 245 341 135 245 344 minecraft:stone
setblock 135 245 345 minecraft:stripped_spruce_log
setblock 135 245 350 minecraft:stripped_spruce_log
fill 135 245 351 135 248 351 minecraft:stone
setblock 135 245 355 minecraft:stripped_spruce_log
fill 135 245 356 135 248 356 minecraft:stone
setblock 135 245 360 minecraft:stripped_spruce_log
fill 135 245 361 135 247 362 minecraft:stone
fill 136 245 326 136 246 326 minecraft:stone
fill 136 245 328 136 247 329 minecraft:andesite
setblock 136 245 332 minecraft:stone
fill 136 245 333 136 247 333 minecraft:andesite
fill 136 245 339 136 247 339 minecraft:andesite
fill 136 245 342 136 247 342 minecraft:andesite
fill 136 245 346 136 247 346 minecraft:andesite
setblock 136 245 355 minecraft:stone
fill 136 245 359 136 247 359 minecraft:andesite
fill 136 245 362 136 247 362 minecraft:andesite
setblock 94 246 322 minecraft:stone
fill 94 246 325 94 247 326 minecraft:andesite
fill 94 246 330 94 247 330 minecraft:andesite
fill 94 246 342 95 246 342 minecraft:stone
fill 94 246 350 95 246 350 minecraft:stone
fill 94 246 352 95 246 352 minecraft:stone
setblock 94 246 355 minecraft:andesite
setblock 94 246 356 minecraft:stone
setblock 94 246 357 minecraft:raw_iron_block
fill 94 246 358 94 247 358 minecraft:andesite
fill 94 246 361 94 247 361 minecraft:andesite
setblock 95 246 333 minecraft:stone
setblock 95 246 334 minecraft:stripped_spruce_log
fill 95 246 335 95 249 335 minecraft:stone
fill 95 246 337 95 246 338 minecraft:stone
setblock 95 246 339 minecraft:stripped_spruce_log
fill 95 246 340 95 248 341 minecraft:stone
setblock 95 246 343 minecraft:stone
setblock 95 246 344 minecraft:stripped_spruce_log
fill 95 246 345 95 246 348 minecraft:stone
setblock 95 246 349 minecraft:stripped_spruce_log
fill 95 246 351 95 247 351 minecraft:stone
setblock 95 246 353 minecraft:stone
setblock 95 246 354 minecraft:stripped_spruce_log
fill 95 246 355 95 248 355 minecraft:stone
setblock 95 246 359 minecraft:stripped_spruce_log
fill 95 246 360 95 248 361 minecraft:stone
setblock 96 246 337 minecraft:stone
setblock 96 246 338 minecraft:stripped_spruce_log
fill 96 246 339 96 249 339 minecraft:stone
setblock 98 246 364 minecraft:stone
setblock 100 246 322 minecraft:raw_gold_block
fill 101 246 322 101 247 322 minecraft:andesite
fill 101 246 364 101 247 364 minecraft:andesite
fill 102 246 363 105 246 363 minecraft:stone
fill 103 246 323 105 246 323 minecraft:stone
fill 104 246 364 104 247 364 minecraft:andesite
fill 105 246 362 106 246 362 minecraft:stone
setblock 106 246 323 minecraft:stripped_spruce_log
fill 106 246 324 106 249 324 minecraft:stone
setblock 106 246 363 minecraft:stripped_spruce_log
fill 107 246 323 107 249 323 minecraft:stone
setblock 107 246 362 minecraft:stripped_spruce_log
fill 107 246 363 107 249 363 minecraft:stone
setblock 108 246 361 minecraft:stripped_spruce_log
fill 108 246 362 108 249 362 minecraft:stone
fill 109 246 361 110 248 361 minecraft:stone
setblock 110 246 324 minecraft:stripped_spruce_log
fill 110 246 362 111 246 362 minecraft:stone
setblock 111 246 323 minecraft:stripped_spruce_log
fill 111 246 324 111 249 324 minecraft:stone
setblock 111 246 363 minecraft:stripped_spruce_log
setblock 111 246 364 minecraft:stone
fill 112 246 323 112 249 323 minecraft:stone
setblock 112 246 362 minecraft:stripped_spruce_log
fill 112 246 363 115 246 363 minecraft:stone
fill 113 246 362 113 249 362 minecraft:stone
setblock 116 246 323 minecraft:stripped_spruce_log
setblock 116 246 362 minecraft:stone
setblock 116 246 363 minecraft:stripped_spruce_log
setblock 117 246 322 minecraft:diamond_block
fill 117 246 323 120 246 323 minecraft:stone
setblock 117 246 362 minecraft:stripped_spruce_log
fill 117 246 363 120 246 363 minecraft:stone
fill 118 246 362 121 246 362 minecraft:stone
fill 119 246 364 120 247 364 minecraft:andesite
setblock 120 246 322 minecraft:stone
fill 120 246 325 120 251 325 minecraft:stripped_spruce_log
setblock 121 246 323 minecraft:stripped_spruce_log
setblock 121 246 363 minecraft:stripped_spruce_log
fill 122 246 323 122 249 323 minecraft:stone
setblock 122 246 361 minecraft:stone
setblock 122 246 362 minecraft:stripped_spruce_log
fill 122 246 363 122 249 363 minecraft:stone
setblock 123 246 361 minecraft:stripped_spruce_log
fill 123 246 362 123 249 362 minecraft:stone
setblock 124 246 360 minecraft:stripped_spruce_log
fill 124 246 361 127 246 361 minecraft:stone
setblock 125 246 324 minecraft:stripped_spruce_log
fill 125 246 360 128 246 360 minecraft:stone
setblock 126 246 323 minecraft:stripped_spruce_log
fill 126 246 324 129 246 324 minecraft:stone
setblock 126 246 363 minecraft:stripped_spruce_log
setblock 126 246 364 minecraft:stone
fill 127 246 322 127 246 323 minecraft:stone
fill 127 246 359 128 247 359 minecraft:stone
setblock 127 246 362 minecraft:stripped_spruce_log
fill 127 246 363 127 249 363 minecraft:stone
fill 128 246 322 128 247 322 minecraft:andesite
fill 128 246 323 128 248 323 minecraft:stone
setblock 128 246 361 minecraft:stripped_spruce_log
fill 128 246 362 128 249 362 minecraft:stone
setblock 129 246 360 minecraft:stripped_spruce_log
fill 129 246 361 129 249 361 minecraft:stone
fill 130 246 357 130 246 358 minecraft:raw_gold_block
setblock 130 246 359 minecraft:stripped_spruce_log
fill 130 246 360 130 249 360 minecraft:stone
setblock 131 246 323 minecraft:stripped_spruce_log
fill 131 246 335 131 247 335 minecraft:stripped_spruce_log
fill 131 246 337 131 247 337 minecraft:stripped_spruce_log
setblock 131 246 359 minecraft:raw_gold_block
setblock 131 246 363 minecraft:stripped_spruce_log
fill 132 246 323 132 249 323 minecraft:stone
setblock 132 246 357 minecraft:stripped_spruce_log
fill 132 246 358 132 248 358 minecraft:stone
setblock 132 246 362 minecraft:stripped_spruce_log
fill 132 246 363 132 249 363 minecraft:stone
fill 133 246 335 133 247 335 minecraft:stripped_spruce_log
fill 133 246 337 133 247 337 minecraft:stripped_spruce_log
setblock 133 246 356 minecraft:stripped_spruce_log
fill 133 246 357 133 248 357 minecraft:stone
setblock 133 246 361 minecraft:stripped_spruce_log
fill 133 246 362 133 249 362 minecraft:stone
setblock 134 246 340 minecraft:stripped_spruce_log
fill 134 246 341 135 248 341 minecraft:stone
setblock 134 246 355 minecraft:stripped_spruce_log
fill 134 246 356 134 249 356 minecraft:stone
setblock 134 246 360 minecraft:stripped_spruce_log
fill 134 246 361 134 249 361 minecraft:stone
setblock 135 246 334 minecraft:stripped_spruce_log
fill 135 246 335 135 248 335 minecraft:stone
setblock 135 246 338 minecraft:stone
setblock 135 246 339 minecraft:stripped_spruce_log
fill 135 246 340 135 249 340 minecraft:stone
fill 135 246 342 135 246 343 minecraft:stone
setblock 135 246 344 minecraft:stripped_spruce_log
fill 135 246 345 135 247 347 minecraft:stone
setblock 135 246 349 minecraft:stripped_spruce_log
fill 135 246 350 135 249 350 minecraft:stone
setblock 135 246 354 minecraft:stripped_spruce_log
fill 135 246 355 135 249 355 minecraft:stone
setblock 135 246 359 minecraft:stripped_spruce_log
fill 135 246 360 135 249 360 minecraft:stone
setblock 136 246 325 minecraft:diamond_block
fill 136 246 332 136 247 332 minecraft:andesite
setblock 136 246 334 minecraft:stone
setblock 136 246 348 minecraft:stone
fill 136 246 355 136 247 355 minecraft:andesite
setblock 136 246 358 minecraft:stone
setblock 136 246 363 minecraft:diamond_block
setblock 136 246 364 minecraft:stone
setblock 94 247 322 minecraft:andesite
setblock 94 247 342 minecraft:andesite
setblock 94 247 350 minecraft:andesite
setblock 94 247 352 minecraft:andesite
setblock 94 247 355 minecraft:gold_block
fill 94 247 356 94 247 357 minecraft:andesite
setblock 95 247 333 minecraft:stripped_spruce_log
fill 95 247 334 95 249 334 minecraft:stone
setblock 95 247 337 minecraft:stone
setblock 95 247 338 minecraft:stripped_spruce_log
fill 95 247 339 95 249 339 minecraft:stone
setblock 95 247 342 minecraft:stone
setblock 95 247 343 minecraft:stripped_spruce_log
fill 95 247 344 95 247 347 minecraft:stone
setblock 95 247 348 minecraft:stripped_spruce_log
fill 95 247 349 95 247 350 minecraft:stone
setblock 95 247 352 minecraft:stone
setblock 95 247 353 minecraft:stripped_spruce_log
fill 95 247 354 95 248 354 minecraft:stone
setblock 95 247 358 minecraft:stripped_spruce_log
fill 95 247 359 95 249 359 minecraft:stone
setblock 95 247 363 minecraft:stripped_spruce_log
setblock 96 247 337 minecraft:stripped_spruce_log
fill 96 247 338 97 249 338 minecraft:stone
fill 96 247 340 96 247 341 minecraft:stone
setblock 96 247 342 minecraft:stripped_spruce_log
fill 96 247 344 96 249 344 minecraft:stone
setblock 97 247 325 minecraft:light[level=12]
setblock 97 247 332 minecraft:light[level=12]
fill 97 247 339 97 247 340 minecraft:stone
setblock 97 247 346 minecraft:light[level=12]
setblock 97 247 353 minecraft:light[level=12]
setblock 97 247 360 minecraft:light[level=12]
setblock 98 247 364 minecraft:andesite
fill 100 247 322 100 248 322 minecraft:andesite
fill 101 247 363 104 247 363 minecraft:stone
fill 102 247 323 104 247 323 minecraft:stone
fill 103 247 362 105 247 362 minecraft:stone
setblock 104 247 324 minecraft:stripped_spruce_log
setblock 104 247 325 minecraft:light[level=12]
setblock 104 247 332 minecraft:light[level=12]
setblock 104 247 339 minecraft:light[level=12]
setblock 104 247 346 minecraft:light[level=12]
setblock 104 247 353 minecraft:light[level=12]
setblock 104 247 360 minecraft:light[level=12]
setblock 105 247 323 minecraft:stripped_spruce_log
fill 105 247 324 105 249 324 minecraft:stone
setblock 105 247 363 minecraft:stripped_spruce_log
fill 106 247 323 106 249 323 minecraft:stone
setblock 106 247 361 minecraft:stone
setblock 106 247 362 minecraft:stripped_spruce_log
fill 106 247 363 106 249 363 minecraft:stone
setblock 107 247 361 minecraft:stripped_spruce_log
fill 107 247 362 107 249 362 minecraft:stone
setblock 108 247 325 minecraft:stripped_spruce_log
fill 108 247 361 108 250 361 minecraft:stone
setblock 109 247 323 minecraft:stone
setblock 109 247 324 minecraft:stripped_spruce_log
fill 109 247 325 109 250 325 minecraft:stone
setblock 110 247 323 minecraft:stripped_spruce_log
fill 110 247 324 110 249 324 minecraft:stone
setblock 110 247 362 minecraft:stone
setblock 110 247 363 minecraft:stripped_spruce_log
fill 111 247 323 111 249 323 minecraft:stone
setblock 111 247 325 minecraft:light[level=12]
setblock 111 247 332 minecraft:light[level=12]
setblock 111 247 339 minecraft:light[level=12]
setblock 111 247 346 minecraft:light[level=12]
setblock 111 247 353 minecraft:light[level=12]
setblock 111 247 360 minecraft:light[level=12]
setblock 111 247 361 minecraft:stone
setblock 111 247 362 minecraft:stripped_spruce_log
fill 111 247 363 114 247 363 minecraft:stone
setblock 111 247 364 minecraft:andesite
fill 112 247 362 112 249 362 minecraft:stone
setblock 114 247 324 minecraft:stripped_spruce_log
setblock 115 247 323 minecraft:stripped_spruce_log
setblock 115 247 363 minecraft:stripped_spruce_log
fill 116 247 323 119 247 323 minecraft:stone
setblock 116 247 362 minecraft:stripped_spruce_log
fill 116 247 363 119 247 363 minecraft:stone
setblock 117 247 322 minecraft:andesite
fill 117 247 362 120 247 362 minecraft:stone
setblock 118 247 325 minecraft:light[level=12]
setblock 118 247 332 minecraft:light[level=12]
setblock 118 247 339 minecraft:light[level=12]
setblock 118 247 346 minecraft:light[level=12]
setblock 118 247 353 minecraft:light[level=12]
setblock 118 247 360 minecraft:light[level=12]
fill 120 247 322 120 248 322 minecraft:andesite
setblock 120 247 323 minecraft:stripped_spruce_log
fill 120 247 361 121 247 361 minecraft:stone
setblock 120 247 363 minecraft:stripped_spruce_log
fill 121 247 323 121 249 323 minecraft:stone
setblock 121 247 362 minecraft:stripped_spruce_log
fill 121 247 363 121 249 363 minecraft:stone
setblock 122 247 361 minecraft:stripped_spruce_log
fill 122 247 362 122 249 362 minecraft:stone
setblock 123 247 324 minecraft:stone
setblock 123 247 360 minecraft:stripped_spruce_log
fill 123 247 361 126 247 361 minecraft:stone
setblock 124 247 324 minecraft:stripped_spruce_log
fill 124 247 360 127 247 360 minecraft:stone
setblock 125 247 323 minecraft:stripped_spruce_log
fill 125 247 324 128 247 324 minecraft:stone
setblock 125 247 325 minecraft:light[level=12]
setblock 125 247 332 minecraft:light[level=12]
setblock 125 247 339 minecraft:light[level=12]
setblock 125 247 346 minecraft:light[level=12]
setblock 125 247 353 minecraft:light[level=12]
setblock 125 247 363 minecraft:stripped_spruce_log
fill 126 247 323 127 249 323 minecraft:stone
fill 126 247 359 126 249 359 minecraft:stone
setblock 126 247 362 minecraft:stripped_spruce_log
fill 126 247 363 126 249 363 minecraft:stone
setblock 126 247 364 minecraft:andesite
setblock 127 247 322 minecraft:andesite
setblock 127 247 361 minecraft:stripped_spruce_log
fill 127 247 362 127 249 362 minecraft:stone
setblock 128 247 360 minecraft:stripped_spruce_log
fill 128 247 361 128 250 361 minecraft:stone
setblock 129 247 324 minecraft:stripped_spruce_log
setblock 129 247 359 minecraft:stripped_spruce_log
fill 129 247 360 129 250 360 minecraft:stone
setblock 130 247 323 minecraft:stripped_spruce_log
setblock 130 247 359 minecraft:stone
setblock 130 247 363 minecraft:stripped_spruce_log
fill 131 247 323 131 249 323 minecraft:stone
setblock 131 247 362 minecraft:stripped_spruce_log
fill 131 247 363 131 249 363 minecraft:stone
setblock 132 247 325 minecraft:light[level=12]
setblock 132 247 332 minecraft:light[level=12]
setblock 132 247 339 minecraft:light[level=12]
setblock 132 247 346 minecraft:light[level=12]
setblock 132 247 353 minecraft:light[level=12]
setblock 132 247 357 minecraft:stone
setblock 132 247 361 minecraft:stripped_spruce_log
fill 132 247 362 132 249 362 minecraft:stone
fill 133 247 323 133 248 323 minecraft:stone
setblock 133 247 355 minecraft:stripped_spruce_log
fill 133 247 356 133 248 356 minecraft:stone
setblock 133 247 360 minecraft:stripped_spruce_log
fill 133 247 361 133 249 361 minecraft:stone
fill 134 247 337 134 247 338 minecraft:stone
setblock 134 247 339 minecraft:stripped_spruce_log
fill 134 247 340 134 249 340 minecraft:stone
fill 134 247 342 135 247 342 minecraft:stone
setblock 134 247 354 minecraft:stripped_spruce_log
fill 134 247 355 134 249 355 minecraft:stone
setblock 134 247 359 minecraft:stripped_spruce_log
fill 134 247 360 134 249 360 minecraft:stone
setblock 135 247 338 minecraft:stripped_spruce_log
fill 135 247 339 135 249 339 minecraft:stone
setblock 135 247 343 minecraft:stripped_spruce_log
fill 135 247 344 135 249 344 minecraft:stone
setblock 135 247 348 minecraft:stripped_spruce_log
fill 135 247 349 135 249 349 minecraft:stone
setblock 135 247 353 minecraft:stripped_spruce_log
fill 135 247 354 135 249 354 minecraft:stone
setblock 135 247 358 minecraft:stripped_spruce_log
fill 135 247 359 135 249 359 minecraft:stone
setblock 135 247 363 minecraft:stripped_spruce_log
fill 136 247 325 136 247 326 minecraft:andesite
setblock 136 247 334 minecraft:andesite
fill 136 247 348 136 248 348 minecraft:andesite
fill 136 247 358 136 248 358 minecraft:andesite
fill 136 247 363 136 247 364 minecraft:andesite
fill 94 248 322 94 299 323 minecraft:stone
fill 94 248 325 94 248 336 minecraft:stone
setblock 94 248 337 minecraft:diamond_block
fill 94 248 338 94 248 348 minecraft:stone
fill 94 248 350 94 248 355 minecraft:stone
setblock 94 248 356 minecraft:raw_iron_block
setblock 94 248 357 minecraft:andesite
fill 94 248 358 94 257 362 minecraft:stone
fill 94 248 364 96 258 364 minecraft:stone
fill 95 248 322 96 270 322 minecraft:stone
fill 95 248 333 95 249 333 minecraft:stone
setblock 95 248 337 minecraft:stripped_spruce_log
fill 95 248 338 95 249 338 minecraft:stone
setblock 95 248 342 minecraft:stripped_spruce_log
fill 95 248 343 95 248 346 minecraft:stone
setblock 95 248 347 minecraft:stripped_spruce_log
fill 95 248 348 95 249 348 minecraft:stone
setblock 95 248 357 minecraft:stripped_spruce_log
fill 95 248 358 95 249 358 minecraft:stone
setblock 95 248 362 minecraft:stripped_spruce_log
fill 95 248 363 95 249 363 minecraft:stone
setblock 96 248 324 minecraft:glowstone
setblock 96 248 336 minecraft:stripped_spruce_log
fill 96 248 337 96 249 337 minecraft:stone
setblock 96 248 340 minecraft:stone
setblock 96 248 341 minecraft:stripped_spruce_log
fill 96 248 342 96 249 342 minecraft:stone
setblock 96 248 343 minecraft:glowstone
setblock 96 248 362 minecraft:glowstone
fill 97 248 322 97 250 322 minecraft:andesite
setblock 97 248 339 minecraft:stone
setblock 97 248 340 minecraft:stripped_spruce_log
fill 97 248 341 97 251 341 minecraft:stone
fill 98 248 322 99 308 322 minecraft:stone
setblock 98 248 364 minecraft:stone
setblock 99 248 363 minecraft:stripped_spruce_log
fill 100 248 363 103 248 364 minecraft:stone
fill 101 248 322 103 248 323 minecraft:stone
fill 102 248 362 104 248 362 minecraft:stone
setblock 103 248 324 minecraft:stripped_spruce_log
setblock 104 248 322 minecraft:raw_gold_block
setblock 104 248 323 minecraft:stripped_spruce_log
fill 104 248 324 104 249 324 minecraft:stone
setblock 104 248 363 minecraft:stripped_spruce_log
fill 104 248 364 104 308 364 minecraft:stone
fill 105 248 322 105 248 323 minecraft:stone
setblock 105 248 361 minecraft:stone
setblock 105 248 362 minecraft:stripped_spruce_log
fill 105 248 363 105 249 363 minecraft:stone
setblock 106 248 325 minecraft:stone
setblock 106 248 361 minecraft:stripped_spruce_log
fill 106 248 362 106 249 362 minecraft:stone
fill 106 248 364 107 248 364 minecraft:stone
setblock 107 248 322 minecraft:andesite
setblock 107 248 324 minecraft:stone
setblock 107 248 325 minecraft:stripped_spruce_log
fill 107 248 361 107 251 361 minecraft:stone
fill 108 248 322 119 248 322 minecraft:stone
setblock 108 248 324 minecraft:stripped_spruce_log
fill 108 248 325 108 251 325 minecraft:stone
setblock 109 248 323 minecraft:stripped_spruce_log
fill 109 248 324 109 249 324 minecraft:stone
setblock 109 248 363 minecraft:stripped_spruce_log
fill 109 248 364 112 270 364 minecraft:stone
fill 110 248 323 110 249 323 minecraft:stone
fill 110 248 325 110 249 325 minecraft:stone
setblock 110 248 362 minecraft:stripped_spruce_log
fill 110 248 363 113 248 363 minecraft:stone
setblock 111 248 361 minecraft:stripped_spruce_log
fill 111 248 362 111 249 362 minecraft:stone
setblock 112 248 324 minecraft:stone
setblock 113 248 324 minecraft:stripped_spruce_log
setblock 114 248 323 minecraft:stripped_spruce_log
fill 114 248 324 114 249 324 minecraft:stone
setblock 114 248 363 minecraft:stripped_spruce_log
fill 114 248 364 120 249 364 minecraft:stone
fill 115 248 323 118 248 323 minecraft:stone
setblock 115 248 324 minecraft:glowstone
setblock 115 248 362 minecraft:glowstone
fill 115 248 363 118 248 363 minecraft:stone
fill 116 248 362 119 248 362 minecraft:stone
setblock 119 248 323 minecraft:stripped_spruce_log
fill 119 248 361 120 248 361 minecraft:stone
setblock 119 248 363 minecraft:stripped_spruce_log
fill 120 248 323 120 249 323 minecraft:stone
setblock 120 248 362 minecraft:stripped_spruce_log
fill 120 248 363 120 249 363 minecraft:stone
fill 121 248 322 121 250 322 minecraft:stone
fill 121 248 324 122 248 324 minecraft:stone
setblock 121 248 361 minecraft:stripped_spruce_log
fill 121 248 362 121 249 362 minecraft:stone
setblock 122 248 360 minecraft:stripped_spruce_log
fill 122 248 361 125 248 361 minecraft:stone
fill 122 248 364 132 248 364 minecraft:stone
fill 123 248 322 135 248 322 minecraft:stone
setblock 123 248 324 minecraft:stripped_spruce_log
fill 123 248 360 126 248 360 minecraft:stone
setblock 124 248 323 minecraft:stripped_spruce_log
fill 124 248 324 127 248 324 minecraft:stone
setblock 124 248 363 minecraft:stripped_spruce_log
fill 125 248 323 125 249 323 minecraft:stone
setblock 125 248 359 minecraft:stone
setblock 125 248 362 minecraft:stripped_spruce_log
fill 125 248 363 125 249 363 minecraft:stone
fill 126 248 336 126 249 336 minecraft:raw_gold_block
setblock 126 248 361 minecraft:stripped_spruce_log
fill 126 248 362 126 249 362 minecraft:stone
setblock 127 248 359 minecraft:stone
setblock 127 248 360 minecraft:stripped_spruce_log
fill 127 248 361 127 251 361 minecraft:stone
setblock 128 248 324 minecraft:stripped_spruce_log
setblock 128 248 359 minecraft:stripped_spruce_log
fill 128 248 360 128 251 360 minecraft:stone
setblock 129 248 323 minecraft:stripped_spruce_log
fill 129 248 324 129 249 324 minecraft:stone
setblock 129 248 359 minecraft:stone
setblock 129 248 363 minecraft:stripped_spruce_log
fill 130 248 323 130 249 323 minecraft:stone
setblock 130 248 362 minecraft:stripped_spruce_log
fill 130 248 363 130 249 363 minecraft:stone
setblock 131 248 361 minecraft:stripped_spruce_log
fill 131 248 362 131 249 362 minecraft:stone
setblock 132 248 360 minecraft:stripped_spruce_log
fill 132 248 361 132 250 361 minecraft:stone
setblock 133 248 359 minecraft:stripped_spruce_log
fill 133 248 360 133 249 360 minecraft:stone
setblock 133 248 364 minecraft:andesite
setblock 134 248 324 minecraft:glowstone
setblock 134 248 337 minecraft:stone
setblock 134 248 338 minecraft:stripped_spruce_log
fill 134 248 339 134 249 339 minecraft:stone
setblock 134 248 342 minecraft:stone
setblock 134 248 343 minecraft:glowstone
fill 134 248 344 134 249 344 minecraft:stone
setblock 134 248 353 minecraft:stripped_spruce_log
setblock 134 248 354 minecraft:stone
setblock 134 248 358 minecraft:stripped_spruce_log
fill 134 248 359 134 249 359 minecraft:stone
setblock 134 248 362 minecraft:glowstone
setblock 134 248 363 minecraft:stripped_spruce_log
fill 134 248 364 135 264 364 minecraft:stone
setblock 135 248 337 minecraft:stripped_spruce_log
fill 135 248 338 136 248 338 minecraft:stone
setblock 135 248 342 minecraft:stripped_spruce_log
fill 135 248 343 136 249 343 minecraft:stone
fill 135 248 345 136 248 346 minecraft:stone
setblock 135 248 347 minecraft:stripped_spruce_log
fill 135 248 348 135 249 348 minecraft:stone
setblock 135 248 352 minecraft:stripped_spruce_log
fill 135 248 353 136 249 353 minecraft:stone
setblock 135 248 357 minecraft:stripped_spruce_log
fill 135 248 358 135 249 358 minecraft:stone
fill 135 248 361 136 248 361 minecraft:stone
setblock 135 248 362 minecraft:stripped_spruce_log
fill 135 248 363 136 249 363 minecraft:stone
fill 136 248 323 136 248 328 minecraft:stone
setblock 136 248 329 minecraft:andesite
fill 136 248 330 136 251 336 minecraft:stone
fill 136 248 339 136 279 342 minecraft:stone
fill 136 248 344 136 308 344 minecraft:stone
fill 136 248 347 136 308 347 minecraft:stone
fill 136 248 349 136 248 352 minecraft:stone
fill 136 248 354 136 256 357 minecraft:stone
fill 136 248 359 136 251 360 minecraft:stone
fill 136 248 362 136 297 362 minecraft:stone
setblock 136 248 364 minecraft:andesite
fill 94 249 324 94 251 333 minecraft:stone
setblock 94 249 334 minecraft:andesite
fill 94 249 335 94 249 341 minecraft:stone
setblock 94 249 342 minecraft:raw_gold_block
fill 94 249 343 95 249 343 minecraft:stone
setblock 94 249 344 minecraft:andesite
fill 94 249 345 95 249 345 minecraft:stone
setblock 94 249 346 minecraft:raw_iron_block
fill 94 249 347 94 249 348 minecraft:andesite
fill 94 249 349 94 249 353 minecraft:stone
fill 94 249 354 94 249 355 minecraft:andesite
fill 94 249 356 94 263 357 minecraft:stone
fill 94 249 363 94 250 363 minecraft:stone
setblock 95 249 336 minecraft:stripped_spruce_log
setblock 95 249 337 minecraft:stone
setblock 95 249 340 minecraft:stone
setblock 95 249 341 minecraft:stripped_spruce_log
setblock 95 249 342 minecraft:stone
setblock 95 249 344 minecraft:stone
setblock 95 249 346 minecraft:stripped_spruce_log
setblock 95 249 347 minecraft:stone
setblock 95 249 357 minecraft:stone
setblock 95 249 360 minecraft:stone
setblock 95 249 361 minecraft:stripped_spruce_log
setblock 95 249 362 minecraft:stone
fill 96 249 324 96 250 324 minecraft:spruce_log
setblock 96 249 336 minecraft:stone
setblock 96 249 340 minecraft:stripped_spruce_log
setblock 96 249 341 minecraft:stone
fill 96 249 343 96 250 343 minecraft:spruce_log
setblock 96 249 345 minecraft:stripped_spruce_log
fill 96 249 362 96 250 362 minecraft:spruce_log
setblock 97 249 339 minecraft:stripped_spruce_log
fill 97 249 340 97 250 340 minecraft:stone
setblock 97 249 364 minecraft:stone
setblock 98 249 363 minecraft:stripped_spruce_log
setblock 98 249 364 minecraft:gold_block
fill 99 249 363 102 249 364 minecraft:stone
fill 100 249 322 102 249 323 minecraft:stone
setblock 102 249 324 minecraft:stripped_spruce_log
fill 102 249 362 103 249 362 minecraft:stone
fill 103 249 322 103 282 322 minecraft:stone
setblock 103 249 323 minecraft:stripped_spruce_log
setblock 103 249 324 minecraft:stone
setblock 103 249 363 minecraft:stripped_spruce_log
setblock 103 249 364 minecraft:stone
fill 104 249 322 105 249 322 minecraft:andesite
fill 104 249 323 105 249 323 minecraft:stone
setblock 104 249 362 minecraft:stripped_spruce_log
setblock 104 249 363 minecraft:stone
setblock 105 249 325 minecraft:stone
setblock 105 249 361 minecraft:stripped_spruce_log
setblock 105 249 362 minecraft:stone
fill 105 249 364 106 308 364 minecraft:stone
fill 106 249 322 108 249 322 minecraft:stone
setblock 106 249 325 minecraft:stripped_spruce_log
fill 106 249 361 106 251 361 minecraft:stone
setblock 107 249 324 minecraft:stripped_spruce_log
fill 107 249 325 107 252 325 minecraft:stone
setblock 107 249 364 minecraft:andesite
setblock 108 249 323 minecraft:stripped_spruce_log
setblock 108 249 324 minecraft:stone
setblock 108 249 363 minecraft:stripped_spruce_log
fill 108 249 364 108 308 364 minecraft:stone
setblock 109 249 322 minecraft:andesite
setblock 109 249 323 minecraft:stone
setblock 109 249 361 minecraft:stone
setblock 109 249 362 minecraft:stripped_spruce_log
fill 109 249 363 112 249 363 minecraft:stone
fill 110 249 322 120 249 322 minecraft:stone
setblock 110 249 361 minecraft:stripped_spruce_log
setblock 110 249 362 minecraft:stone
setblock 111 249 361 minecraft:stone
setblock 112 249 324 minecraft:stripped_spruce_log
setblock 113 249 323 minecraft:stripped_spruce_log
setblock 113 249 324 minecraft:stone
setblock 113 249 363 minecraft:stripped_spruce_log
fill 113 249 364 113 295 364 minecraft:stone
fill 114 249 323 117 249 323 minecraft:stone
setblock 114 249 362 minecraft:stripped_spruce_log
fill 114 249 363 117 249 363 minecraft:stone
fill 115 249 324 115 250 324 minecraft:spruce_log
fill 115 249 362 115 250 362 minecraft:spruce_log
fill 116 249 362 118 249 362 minecraft:stone
setblock 118 249 323 minecraft:stripped_spruce_log
setblock 118 249 363 minecraft:stripped_spruce_log
setblock 119 249 323 minecraft:stone
fill 119 249 325 119 251 325 minecraft:stripped_spruce_log
setblock 119 249 361 minecraft:stone
setblock 119 249 362 minecraft:stripped_spruce_log
setblock 119 249 363 minecraft:stone
fill 120 249 324 121 249 324 minecraft:stone
fill 120 249 326 120 251 326 minecraft:stripped_spruce_log
setblock 120 249 361 minecraft:stripped_spruce_log
setblock 120 249 362 minecraft:stone
fill 121 249 325 121 251 325 minecraft:stripped_spruce_log
fill 121 249 361 124 249 361 minecraft:stone
fill 121 249 364 121 308 364 minecraft:stone
fill 122 249 322 126 250 322 minecraft:stone
setblock 122 249 324 minecraft:stripped_spruce_log
fill 122 249 360 125 249 360 minecraft:stone
fill 122 249 364 123 249 364 minecraft:andesite
setblock 123 249 323 minecraft:stripped_spruce_log
fill 123 249 324 126 249 324 minecraft:stone
setblock 123 249 363 minecraft:stripped_spruce_log
setblock 124 249 323 minecraft:stone
setblock 124 249 362 minecraft:stripped_spruce_log
fill 124 249 363 124 249 364 minecraft:stone
setblock 125 249 361 minecraft:stripped_spruce_log
setblock 125 249 362 minecraft:stone
fill 125 249 364 133 249 364 minecraft:stone
setblock 126 249 360 minecraft:stripped_spruce_log
fill 126 249 361 126 252 361 minecraft:stone
fill 127 249 322 127 250 322 minecraft:andesite
setblock 127 249 324 minecraft:stripped_spruce_log
setblock 127 249 359 minecraft:stripped_spruce_log
fill 127 249 360 127 252 360 minecraft:stone
fill 128 249 322 136 249 322 minecraft:stone
setblock 128 249 323 minecraft:stripped_spruce_log
setblock 128 249 324 minecraft:stone
setblock 128 249 359 minecraft:stone
setblock 128 249 363 minecraft:stripped_spruce_log
setblock 129 249 323 minecraft:stone
setblock 129 249 362 minecraft:stripped_spruce_log
setblock 129 249 363 minecraft:stone
setblock 130 249 361 minecraft:stripped_spruce_log
setblock 130 249 362 minecraft:stone
setblock 131 249 360 minecraft:stripped_spruce_log
fill 131 249 361 131 251 361 minecraft:stone
setblock 133 249 358 minecraft:stripped_spruce_log
setblock 133 249 359 minecraft:stone
setblock 133 249 363 minecraft:stripped_spruce_log
fill 134 249 324 134 250 324 minecraft:spruce_log
fill 134 249 338 135 249 338 minecraft:stone
setblock 134 249 341 minecraft:stone
setblock 134 249 342 minecraft:stripped_spruce_log
fill 134 249 343 134 250 343 minecraft:spruce_log
fill 134 249 345 136 249 345 minecraft:stone
setblock 134 249 357 minecraft:stripped_spruce_log
setblock 134 249 358 minecraft:stone
fill 134 249 362 134 250 362 minecraft:spruce_log
setblock 134 249 363 minecraft:stone
setblock 135 249 336 minecraft:stripped_spruce_log
fill 135 249 337 136 249 337 minecraft:stone
setblock 135 249 341 minecraft:stripped_spruce_log
setblock 135 249 342 minecraft:stone
setblock 135 249 346 minecraft:stripped_spruce_log
setblock 135 249 347 minecraft:stone
setblock 135 249 351 minecraft:stripped_spruce_log
fill 135 249 352 136 249 352 minecraft:stone
setblock 135 249 356 minecraft:stripped_spruce_log
setblock 135 249 357 minecraft:stone
setblock 135 249 361 minecraft:stripped_spruce_log
setblock 135 249 362 minecraft:stone
setblock 136 249 323 minecraft:andesite
fill 136 249 324 136 260 329 minecraft:stone
setblock 136 249 338 minecraft:gold_block
fill 136 249 346 136 284 346 minecraft:stone
fill 136 249 348 136 276 350 minecraft:stone
setblock 136 249 351 minecraft:gold_block
fill 136 249 358 136 255 358 minecraft:stone
fill 136 249 361 136 306 361 minecraft:stone
fill 136 249 364 136 308 364 minecraft:stone
fill 94 250 334 94 302 335 minecraft:stone
setblock 94 250 336 minecraft:andesite
fill 94 250 337 94 271 341 minecraft:stone
fill 94 250 342 94 250 343 minecraft:andesite
fill 94 250 344 94 257 344 minecraft:stone
setblock 94 250 345 minecraft:andesite
setblock 94 250 346 minecraft:raw_gold_block
fill 94 250 347 94 285 350 minecraft:stone
setblock 94 250 351 minecraft:andesite
fill 94 250 352 94 282 355 minecraft:stone
fill 95 250 323 95 250 363 minecraft:spruce_planks
fill 96 250 323 135 250 323 minecraft:spruce_planks
fill 96 250 325 96 250 342 minecraft:spruce_planks
fill 96 250 344 96 250 361 minecraft:spruce_planks
fill 96 250 363 135 250 363 minecraft:spruce_planks
fill 97 250 324 114 250 324 minecraft:spruce_planks
setblock 97 250 339 minecraft:stone
fill 97 250 362 114 250 362 minecraft:spruce_planks
setblock 97 250 364 minecraft:andesite
fill 98 250 364 101 255 364 minecraft:stone
fill 100 250 322 102 253 322 minecraft:stone
fill 102 250 364 103 250 364 minecraft:andesite
setblock 104 250 322 minecraft:andesite
setblock 104 250 325 minecraft:stone
fill 105 250 322 105 308 322 minecraft:stone
setblock 105 250 325 minecraft:stripped_spruce_log
setblock 105 250 361 minecraft:stone
setblock 106 250 322 minecraft:andesite
fill 106 250 325 106 253 325 minecraft:stone
fill 107 250 322 111 253 322 minecraft:stone
setblock 107 250 364 minecraft:stone
setblock 109 250 361 minecraft:stripped_spruce_log
setblock 110 250 325 minecraft:stripped_spruce_log
setblock 112 250 322 minecraft:andesite
fill 113 250 322 116 276 322 minecraft:stone
fill 114 250 364 118 250 364 minecraft:stone
fill 116 250 324 133 250 324 minecraft:spruce_planks
fill 116 250 362 133 250 362 minecraft:spruce_planks
setblock 117 250 322 minecraft:andesite
fill 118 250 322 120 258 322 minecraft:stone
fill 119 250 326 119 251 326 minecraft:stripped_spruce_log
setblock 119 250 361 minecraft:stripped_spruce_log
setblock 119 250 364 minecraft:diamond_block
fill 120 250 361 123 250 361 minecraft:stone
fill 120 250 364 120 287 364 minecraft:stone
fill 121 250 326 121 251 326 minecraft:stripped_spruce_log
fill 122 250 360 124 250 360 minecraft:stone
fill 122 250 364 123 270 364 minecraft:stone
setblock 124 250 361 minecraft:stripped_spruce_log
setblock 124 250 364 minecraft:andesite
setblock 125 250 360 minecraft:stripped_spruce_log
fill 125 250 361 125 253 361 minecraft:stone
fill 125 250 364 125 262 364 minecraft:stone
fill 126 250 336 126 256 336 minecraft:cobbled_deepslate
fill 126 250 360 126 252 360 minecraft:stone
setblock 126 250 364 minecraft:raw_gold_block
fill 127 250 364 133 261 364 minecraft:stone
fill 128 250 322 129 261 322 minecraft:stone
setblock 129 250 361 minecraft:stripped_spruce_log
setblock 130 250 322 minecraft:andesite
setblock 130 250 360 minecraft:stripped_spruce_log
fill 130 250 361 130 252 361 minecraft:stone
fill 131 250 322 131 259 322 minecraft:stone
setblock 132 250 322 minecraft:andesite
fill 133 250 322 133 288 322 minecraft:stone
setblock 134 250 322 minecraft:andesite
fill 134 250 325 135 250 342 minecraft:spruce_planks
fill 134 250 344 135 250 361 minecraft:spruce_planks
fill 135 250 322 136 284 322 minecraft:stone
setblock 135 250 324 minecraft:spruce_planks
setblock 135 250 343 minecraft:spruce_planks
setblock 135 250 362 minecraft:spruce_planks
fill 136 250 323 136 270 323 minecraft:stone
fill 136 250 337 136 250 338 minecraft:stone
fill 136 250 343 136 308 343 minecraft:stone
fill 136 250 345 136 308 345 minecraft:stone
fill 136 250 351 136 254 351 minecraft:stone
setblock 136 250 352 minecraft:andesite
fill 136 250 353 136 261 353 minecraft:stone
fill 136 250 363 136 305 363 minecraft:stone
fill 94 251 336 95 252 336 minecraft:stone
fill 94 251 342 95 251 343 minecraft:stone
fill 94 251 345 95 251 346 minecraft:stone
fill 94 251 351 94 291 351 minecraft:stone
setblock 94 251 363 minecraft:raw_gold_block
setblock 95 251 335 minecraft:stone
fill 95 251 337 95 251 338 minecraft:stone
setblock 95 251 339 minecraft:stripped_spruce_log
fill 95 251 340 96 252 341 minecraft:stone
setblock 95 251 344 minecraft:stripped_spruce_log
fill 95 251 347 95 252 347 minecraft:stone
setblock 96 251 337 minecraft:stone
setblock 96 251 338 minecraft:stripped_spruce_log
fill 96 251 339 96 253 339 minecraft:stone
setblock 96 251 342 minecraft:stone
setblock 96 251 343 minecraft:stripped_spruce_log
fill 96 251 344 96 253 345 minecraft:stone
setblock 97 251 322 minecraft:raw_iron_block
setblock 97 251 325 minecraft:light[level=15]
setblock 97 251 333 minecraft:light[level=15]
setblock 97 251 349 minecraft:light[level=15]
setblock 97 251 357 minecraft:light[level=15]
fill 97 251 364 97 308 364 minecraft:stone
fill 98 251 323 100 251 323 minecraft:stone
fill 98 251 363 100 251 363 minecraft:stone
setblock 101 251 323 minecraft:stripped_spruce_log
fill 101 251 324 104 251 324 minecraft:stone
setblock 101 251 362 minecraft:stone
setblock 101 251 363 minecraft:stripped_spruce_log
fill 102 251 323 105 251 323 minecraft:stone
setblock 102 251 362 minecraft:stripped_spruce_log
fill 102 251 363 103 253 364 minecraft:stone
setblock 103 251 325 minecraft:stone
fill 103 251 362 106 251 362 minecraft:stone
fill 104 251 322 104 293 322 minecraft:stone
setblock 104 251 325 minecraft:stripped_spruce_log
fill 104 251 363 105 251 363 minecraft:stone
setblock 105 251 324 minecraft:stripped_spruce_log
fill 105 251 325 105 254 325 minecraft:stone
setblock 105 251 333 minecraft:light[level=15]
setblock 105 251 341 minecraft:light[level=15]
setblock 105 251 349 minecraft:light[level=15]
setblock 105 251 357 minecraft:light[level=15]
fill 106 251 322 106 279 322 minecraft:stone
setblock 106 251 323 minecraft:stripped_spruce_log
fill 106 251 324 109 251 324 minecraft:stone
setblock 106 251 363 minecraft:stripped_spruce_log
fill 107 251 323 110 251 323 minecraft:stone
setblock 107 251 362 minecraft:stripped_spruce_log
fill 107 251 363 110 251 363 minecraft:stone
setblock 107 251 364 minecraft:raw_iron_block
fill 108 251 362 111 251 362 minecraft:stone
setblock 109 251 325 minecraft:stripped_spruce_log
setblock 110 251 324 minecraft:stripped_spruce_log
setblock 111 251 323 minecraft:stripped_spruce_log
fill 111 251 324 114 251 324 minecraft:stone
setblock 111 251 363 minecraft:stripped_spruce_log
fill 112 251 322 112 254 323 minecraft:stone
setblock 112 251 362 minecraft:stripped_spruce_log
fill 112 251 363 115 251 363 minecraft:stone
fill 113 251 323 115 251 323 minecraft:stone
setblock 113 251 325 minecraft:light[level=15]
setblock 113 251 333 minecraft:light[level=15]
setblock 113 251 341 minecraft:light[level=15]
setblock 113 251 349 minecraft:light[level=15]
setblock 113 251 357 minecraft:light[level=15]
fill 113 251 362 116 251 362 minecraft:stone
fill 114 251 364 114 300 364 minecraft:stone
setblock 115 251 364 minecraft:raw_gold_block
setblock 116 251 323 minecraft:stripped_spruce_log
setblock 116 251 363 minecraft:stripped_spruce_log
fill 116 251 364 119 254 364 minecraft:stone
fill 117 251 322 117 254 323 minecraft:stone
setblock 117 251 362 minecraft:stripped_spruce_log
fill 117 251 363 120 251 363 minecraft:stone
fill 118 251 323 119 251 324 minecraft:stone
setblock 118 251 325 minecraft:stripped_spruce_log
fill 118 251 362 121 251 362 minecraft:stone
fill 119 251 361 122 251 361 minecraft:stone
setblock 120 251 323 minecraft:stone
setblock 120 251 324 minecraft:stripped_spruce_log
setblock 120 251 327 minecraft:stripped_spruce_log
setblock 121 251 322 minecraft:diamond_block
setblock 121 251 323 minecraft:stripped_spruce_log
fill 121 251 324 124 251 324 minecraft:stone
setblock 121 251 333 minecraft:light[level=15]
setblock 121 251 341 minecraft:light[level=15]
setblock 121 251 349 minecraft:light[level=15]
setblock 121 251 357 minecraft:light[level=15]
setblock 121 251 363 minecraft:stripped_spruce_log
setblock 122 251 322 minecraft:raw_iron_block
fill 122 251 323 125 251 323 minecraft:stone
setblock 122 251 325 minecraft:stripped_spruce_log
fill 122 251 360 123 251 360 minecraft:stone
setblock 122 251 362 minecraft:stripped_spruce_log
fill 122 251 363 125 251 363 minecraft:stone
fill 123 251 322 127 273 322 minecraft:stone
setblock 123 251 361 minecraft:stripped_spruce_log
fill 123 251 362 126 251 362 minecraft:stone
setblock 124 251 360 minecraft:stripped_spruce_log
fill 124 251 361 124 254 361 minecraft:stone
fill 124 251 364 124 308 364 minecraft:stone
setblock 125 251 324 minecraft:stripped_spruce_log
fill 125 251 336 125 256 336 minecraft:cobbled_deepslate
fill 125 251 360 125 252 360 minecraft:stone
setblock 126 251 323 minecraft:stripped_spruce_log
fill 126 251 324 128 252 324 minecraft:stone
setblock 126 251 363 minecraft:stripped_spruce_log
fill 126 251 364 126 308 364 minecraft:stone
fill 127 251 323 130 251 323 minecraft:stone
setblock 127 251 362 minecraft:stripped_spruce_log
fill 127 251 363 130 251 363 minecraft:stone
setblock 128 251 361 minecraft:stripped_spruce_log
fill 128 251 362 131 251 362 minecraft:stone
setblock 129 251 325 minecraft:light[level=15]
setblock 129 251 333 minecraft:light[level=15]
fill 129 251 338 134 252 338 minecraft:stripped_spruce_log
setblock 129 251 341 minecraft:light[level=15]
setblock 129 251 349 minecraft:light[level=15]
setblock 129 251 357 minecraft:light[level=15]
fill 129 251 361 129 252 361 minecraft:stone
fill 130 251 322 130 308 322 minecraft:stone
setblock 131 251 323 minecraft:stripped_spruce_log
setblock 131 251 363 minecraft:stripped_spruce_log
fill 132 251 322 132 251 323 minecraft:stone
fill 132 251 339 135 251 339 minecraft:stripped_spruce_log
setblock 132 251 362 minecraft:stripped_spruce_log
fill 132 251 363 135 251 363 minecraft:stone
setblock 133 251 362 minecraft:stone
fill 134 251 322 134 270 322 minecraft:stone
setblock 134 251 340 minecraft:stripped_spruce_log
fill 134 251 341 134 251 344 minecraft:stone
setblock 134 251 345 minecraft:stripped_spruce_log
fill 134 251 361 135 251 361 minecraft:stone
fill 135 251 337 135 251 338 minecraft:stone
fill 135 251 340 135 251 343 minecraft:stone
setblock 135 251 344 minecraft:stripped_spruce_log
fill 135 251 345 135 251 348 minecraft:stone
setblock 135 251 349 minecraft:stripped_spruce_log
fill 135 251 356 135 251 358 minecraft:stone
setblock 135 251 359 minecraft:stripped_spruce_log
fill 135 251 360 135 252 360 minecraft:stone
fill 135 251 362 135 252 362 minecraft:stone
fill 136 251 337 136 308 337 minecraft:stone
setblock 136 251 338 minecraft:raw_gold_block
fill 136 251 352 136 267 352 minecraft:stone
fill 94 252 324 94 256 330 minecraft:stone
setblock 94 252 331 minecraft:diamond_block
fill 94 252 332 94 261 333 minecraft:stone
fill 94 252 342 94 290 343 minecraft:stone
setblock 94 252 345 minecraft:raw_gold_block
fill 94 252 346 95 253 346 minecraft:stone
setblock 94 252 363 minecraft:gold_block
setblock 95 252 337 minecraft:stone
setblock 95 252 338 minecraft:stripped_spruce_log
fill 95 252 339 95 255 339 minecraft:stone
setblock 95 252 342 minecraft:stone
setblock 95 252 343 minecraft:stripped_spruce_log
fill 95 252 344 95 254 345 minecraft:stone
setblock 96 252 338 minecraft:stone
setblock 96 252 342 minecraft:stripped_spruce_log
fill 96 252 343 96 255 343 minecraft:stone
fill 97 252 322 97 276 322 minecraft:stone
fill 98 252 323 99 252 323 minecraft:stone
setblock 99 252 363 minecraft:stone
setblock 100 252 323 minecraft:stripped_spruce_log
fill 100 252 324 103 252 324 minecraft:stone
setblock 100 252 363 minecraft:stripped_spruce_log
fill 101 252 323 104 252 323 minecraft:stone
fill 101 252 363 101 255 363 minecraft:stone
fill 102 252 362 105 252 362 minecraft:stone
setblock 103 252 325 minecraft:stripped_spruce_log
setblock 104 252 324 minecraft:stripped_spruce_log
fill 104 252 325 104 255 325 minecraft:stone
setblock 104 252 363 minecraft:stone
setblock 105 252 323 minecraft:stripped_spruce_log
fill 105 252 324 108 252 324 minecraft:stone
setblock 105 252 363 minecraft:stripped_spruce_log
fill 106 252 323 109 252 323 minecraft:stone
setblock 106 252 362 minecraft:stripped_spruce_log
fill 106 252 363 109 252 363 minecraft:stone
fill 107 252 362 110 252 362 minecraft:stone
fill 107 252 364 107 308 364 minecraft:stone
setblock 108 252 325 minecraft:stripped_spruce_log
setblock 109 252 324 minecraft:stripped_spruce_log
setblock 109 252 325 minecraft:stone
setblock 110 252 323 minecraft:stripped_spruce_log
fill 110 252 324 113 252 324 minecraft:stone
setblock 110 252 363 minecraft:stripped_spruce_log
fill 111 252 323 111 255 323 minecraft:stone
setblock 111 252 362 minecraft:stripped_spruce_log
fill 111 252 363 114 252 363 minecraft:stone
fill 112 252 362 115 252 362 minecraft:stone
fill 113 252 323 114 252 323 minecraft:stone
setblock 115 252 323 minecraft:stripped_spruce_log
setblock 115 252 363 minecraft:stripped_spruce_log
fill 115 252 364 115 294 364 minecraft:stone
fill 116 252 323 116 255 323 minecraft:stone
setblock 116 252 362 minecraft:stripped_spruce_log
fill 116 252 363 119 252 363 minecraft:stone
fill 117 252 362 120 252 362 minecraft:stone
fill 118 252 323 118 252 324 minecraft:stone
setblock 119 252 323 minecraft:stone
setblock 119 252 324 minecraft:stripped_spruce_log
fill 119 252 338 128 252 339 minecraft:stripped_spruce_log
setblock 120 252 323 minecraft:stripped_spruce_log
fill 120 252 324 123 252 324 minecraft:stone
fill 120 252 361 121 252 361 minecraft:stone
setblock 120 252 363 minecraft:stripped_spruce_log
fill 121 252 322 122 254 323 minecraft:stone
setblock 121 252 362 minecraft:stripped_spruce_log
fill 121 252 363 124 252 363 minecraft:stone
setblock 122 252 361 minecraft:stripped_spruce_log
fill 122 252 362 125 252 362 minecraft:stone
fill 123 252 323 124 252 323 minecraft:stone
setblock 123 252 360 minecraft:stripped_spruce_log
fill 123 252 361 123 255 361 minecraft:stone
setblock 124 252 324 minecraft:stripped_spruce_log
setblock 124 252 360 minecraft:stone
setblock 125 252 323 minecraft:stripped_spruce_log
fill 125 252 324 125 255 324 minecraft:stone
fill 125 252 335 126 256 335 minecraft:cobbled_deepslate
fill 125 252 337 126 256 337 minecraft:cobbled_deepslate
setblock 125 252 363 minecraft:stripped_spruce_log
fill 126 252 323 129 252 323 minecraft:stone
setblock 126 252 362 minecraft:stripped_spruce_log
fill 126 252 363 129 252 363 minecraft:stone
setblock 127 252 361 minecraft:stripped_spruce_log
fill 127 252 362 130 252 362 minecraft:stone
fill 128 252 361 128 253 361 minecraft:stone
fill 129 252 339 134 252 339 minecraft:stripped_spruce_log
setblock 130 252 323 minecraft:stripped_spruce_log
setblock 130 252 363 minecraft:stripped_spruce_log
setblock 131 252 323 minecraft:stone
setblock 131 252 362 minecraft:stripped_spruce_log
fill 131 252 363 134 252 363 minecraft:stone
fill 132 252 322 132 295 322 minecraft:stone
setblock 132 252 362 minecraft:stone
fill 134 252 342 134 252 343 minecraft:stone
setblock 134 252 344 minecraft:stripped_spruce_log
setblock 135 252 338 minecraft:stripped_spruce_log
fill 135 252 339 135 252 342 minecraft:stone
setblock 135 252 343 minecraft:stripped_spruce_log
fill 135 252 344 135 252 347 minecraft:stone
setblock 135 252 348 minecraft:stripped_spruce_log
setblock 135 252 359 minecraft:stone
setblock 135 252 361 minecraft:stone
setblock 135 252 363 minecraft:stripped_spruce_log
setblock 136 252 330 minecraft:raw_gold_block
fill 136 252 331 136 252 336 minecraft:stone
schedule function dropper:buildpart/74_8 1t
