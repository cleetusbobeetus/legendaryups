setblock 226 286 514 minecraft:pearlescent_froglight
fill 226 286 515 226 295 515 minecraft:gray_concrete
setblock 226 286 516 minecraft:pearlescent_froglight
fill 226 286 517 226 295 517 minecraft:gray_concrete
fill 226 286 543 226 296 543 minecraft:gray_concrete
setblock 226 286 544 minecraft:pearlescent_froglight
fill 226 286 545 226 296 545 minecraft:gray_concrete
setblock 226 286 546 minecraft:pearlescent_froglight
fill 226 286 547 226 296 547 minecraft:gray_concrete
setblock 226 286 548 minecraft:pearlescent_froglight
fill 226 286 549 226 300 549 minecraft:gray_concrete
setblock 226 286 550 minecraft:pearlescent_froglight
setblock 227 286 511 minecraft:pearlescent_froglight
fill 227 286 512 227 295 512 minecraft:gray_concrete
setblock 227 286 513 minecraft:pearlescent_froglight
fill 227 286 514 227 295 514 minecraft:gray_concrete
setblock 227 286 515 minecraft:pearlescent_froglight
fill 227 286 516 227 295 516 minecraft:gray_concrete
setblock 227 286 517 minecraft:pearlescent_froglight
setblock 227 286 543 minecraft:pearlescent_froglight
fill 227 286 544 227 296 544 minecraft:gray_concrete
setblock 227 286 545 minecraft:pearlescent_froglight
fill 227 286 546 227 296 546 minecraft:gray_concrete
setblock 227 286 547 minecraft:pearlescent_froglight
fill 227 286 548 227 296 548 minecraft:gray_concrete
setblock 227 286 549 minecraft:pearlescent_froglight
fill 227 286 550 227 300 550 minecraft:gray_concrete
setblock 228 286 510 minecraft:pearlescent_froglight
fill 228 286 511 228 295 511 minecraft:gray_concrete
setblock 228 286 512 minecraft:pearlescent_froglight
fill 228 286 513 228 295 513 minecraft:gray_concrete
setblock 228 286 514 minecraft:pearlescent_froglight
fill 228 286 515 228 295 515 minecraft:gray_concrete
setblock 228 286 516 minecraft:pearlescent_froglight
fill 228 286 517 228 295 517 minecraft:gray_concrete
fill 228 286 543 228 296 543 minecraft:gray_concrete
setblock 228 286 544 minecraft:pearlescent_froglight
fill 228 286 545 228 296 545 minecraft:gray_concrete
setblock 228 286 546 minecraft:pearlescent_froglight
fill 228 286 547 228 296 547 minecraft:gray_concrete
setblock 228 286 548 minecraft:pearlescent_froglight
fill 228 286 549 228 300 549 minecraft:gray_concrete
setblock 228 286 550 minecraft:pearlescent_froglight
fill 229 286 510 230 307 510 minecraft:black_concrete
setblock 229 286 511 minecraft:pearlescent_froglight
fill 229 286 512 229 300 512 minecraft:gray_concrete
setblock 229 286 513 minecraft:pearlescent_froglight
fill 229 286 514 229 295 514 minecraft:gray_concrete
setblock 229 286 515 minecraft:pearlescent_froglight
fill 229 286 516 229 295 516 minecraft:gray_concrete
setblock 229 286 517 minecraft:pearlescent_froglight
setblock 229 286 543 minecraft:pearlescent_froglight
fill 229 286 544 229 300 544 minecraft:gray_concrete
setblock 229 286 545 minecraft:pearlescent_froglight
fill 229 286 546 229 300 546 minecraft:gray_concrete
setblock 229 286 547 minecraft:pearlescent_froglight
fill 229 286 548 229 300 548 minecraft:gray_concrete
setblock 229 286 549 minecraft:pearlescent_froglight
fill 229 286 550 229 300 550 minecraft:gray_concrete
fill 207 287 543 207 288 543 minecraft:gray_concrete
fill 207 287 545 207 288 545 minecraft:gray_concrete
fill 207 287 547 207 288 547 minecraft:gray_concrete
fill 207 287 549 207 288 549 minecraft:gray_concrete
fill 207 287 551 207 288 551 minecraft:gray_concrete
fill 208 287 544 208 288 544 minecraft:gray_concrete
fill 208 287 546 208 288 546 minecraft:gray_concrete
fill 208 287 548 208 288 548 minecraft:gray_concrete
fill 208 287 550 208 288 550 minecraft:gray_concrete
fill 209 287 543 209 288 543 minecraft:gray_concrete
fill 209 287 545 209 288 545 minecraft:gray_concrete
fill 209 287 547 209 288 547 minecraft:gray_concrete
fill 209 287 549 209 288 549 minecraft:gray_concrete
fill 209 287 551 209 288 551 minecraft:gray_concrete
fill 210 287 544 210 288 544 minecraft:gray_concrete
fill 210 287 546 210 288 546 minecraft:gray_concrete
fill 210 287 548 210 288 548 minecraft:gray_concrete
fill 210 287 550 210 288 550 minecraft:gray_concrete
fill 211 287 543 211 288 543 minecraft:gray_concrete
fill 211 287 545 211 288 545 minecraft:gray_concrete
fill 211 287 547 211 288 547 minecraft:gray_concrete
fill 211 287 549 211 288 549 minecraft:gray_concrete
fill 211 287 551 211 288 551 minecraft:gray_concrete
fill 212 287 544 212 288 544 minecraft:gray_concrete
fill 212 287 546 212 288 546 minecraft:gray_concrete
fill 212 287 548 212 288 548 minecraft:gray_concrete
fill 212 287 550 212 288 550 minecraft:gray_concrete
fill 213 287 543 213 288 543 minecraft:gray_concrete
fill 213 287 545 213 288 545 minecraft:gray_concrete
fill 213 287 547 213 288 547 minecraft:gray_concrete
fill 213 287 549 213 288 549 minecraft:gray_concrete
fill 213 287 551 213 288 551 minecraft:gray_concrete
fill 214 287 544 214 288 544 minecraft:gray_concrete
fill 214 287 546 214 288 546 minecraft:gray_concrete
fill 214 287 548 214 288 548 minecraft:gray_concrete
fill 214 287 550 214 288 550 minecraft:gray_concrete
fill 215 287 543 215 288 543 minecraft:gray_concrete
fill 215 287 545 215 288 545 minecraft:gray_concrete
fill 215 287 547 215 288 547 minecraft:gray_concrete
fill 215 287 549 215 288 549 minecraft:gray_concrete
fill 215 287 551 215 288 551 minecraft:gray_concrete
fill 216 287 544 216 288 544 minecraft:gray_concrete
fill 216 287 546 216 288 546 minecraft:gray_concrete
fill 216 287 548 216 288 548 minecraft:gray_concrete
fill 216 287 550 216 288 550 minecraft:gray_concrete
fill 217 287 543 217 288 543 minecraft:gray_concrete
fill 217 287 545 217 288 545 minecraft:gray_concrete
fill 217 287 547 217 288 547 minecraft:gray_concrete
fill 217 287 549 217 288 549 minecraft:gray_concrete
fill 217 287 551 217 288 551 minecraft:gray_concrete
fill 218 287 544 218 288 544 minecraft:gray_concrete
fill 218 287 546 218 288 546 minecraft:gray_concrete
fill 218 287 548 218 288 548 minecraft:gray_concrete
fill 218 287 550 218 288 550 minecraft:gray_concrete
fill 219 287 543 219 288 543 minecraft:gray_concrete
fill 219 287 545 219 288 545 minecraft:gray_concrete
fill 219 287 547 219 288 547 minecraft:gray_concrete
fill 219 287 549 219 288 549 minecraft:gray_concrete
fill 219 287 551 219 288 551 minecraft:gray_concrete
fill 220 287 544 220 288 544 minecraft:gray_concrete
fill 220 287 546 220 288 546 minecraft:gray_concrete
fill 220 287 548 220 288 548 minecraft:gray_concrete
fill 220 287 550 220 288 550 minecraft:gray_concrete
fill 221 287 545 221 288 545 minecraft:gray_concrete
fill 221 287 547 221 288 547 minecraft:gray_concrete
fill 221 287 549 221 288 549 minecraft:gray_concrete
fill 222 287 544 222 288 544 minecraft:gray_concrete
fill 222 287 546 222 288 546 minecraft:gray_concrete
fill 222 287 548 222 288 548 minecraft:gray_concrete
fill 222 287 550 222 288 550 minecraft:gray_concrete
fill 223 287 543 223 288 543 minecraft:gray_concrete
fill 223 287 545 223 288 545 minecraft:gray_concrete
fill 223 287 547 223 288 547 minecraft:gray_concrete
fill 223 287 549 223 288 549 minecraft:gray_concrete
fill 224 287 510 224 288 510 minecraft:black_concrete
fill 224 287 512 224 288 512 minecraft:gray_concrete
fill 224 287 514 224 288 514 minecraft:gray_concrete
fill 224 287 516 224 288 516 minecraft:gray_concrete
fill 224 287 544 224 288 544 minecraft:gray_concrete
fill 224 287 546 224 288 546 minecraft:gray_concrete
fill 224 287 548 224 288 548 minecraft:gray_concrete
fill 224 287 550 224 288 550 minecraft:gray_concrete
fill 225 287 511 225 288 511 minecraft:gray_concrete
fill 225 287 513 225 288 513 minecraft:gray_concrete
fill 225 287 515 225 288 515 minecraft:gray_concrete
fill 225 287 517 225 288 517 minecraft:gray_concrete
fill 225 287 543 225 288 543 minecraft:gray_concrete
fill 225 287 545 225 288 545 minecraft:gray_concrete
fill 225 287 547 225 288 547 minecraft:gray_concrete
fill 225 287 549 225 288 549 minecraft:gray_concrete
fill 226 287 510 226 288 510 minecraft:black_concrete
fill 226 287 512 226 288 512 minecraft:gray_concrete
fill 226 287 514 226 288 514 minecraft:gray_concrete
fill 226 287 516 226 288 516 minecraft:gray_concrete
fill 226 287 544 226 288 544 minecraft:gray_concrete
fill 226 287 546 226 288 546 minecraft:gray_concrete
fill 226 287 548 226 288 548 minecraft:gray_concrete
fill 226 287 550 226 288 550 minecraft:gray_concrete
fill 227 287 511 227 288 511 minecraft:gray_concrete
fill 227 287 513 227 288 513 minecraft:gray_concrete
fill 227 287 515 227 288 515 minecraft:gray_concrete
fill 227 287 517 227 288 517 minecraft:gray_concrete
fill 227 287 543 227 288 543 minecraft:gray_concrete
fill 227 287 545 227 288 545 minecraft:gray_concrete
fill 227 287 547 227 288 547 minecraft:gray_concrete
fill 227 287 549 227 288 549 minecraft:gray_concrete
fill 228 287 510 228 288 510 minecraft:black_concrete
fill 228 287 512 228 288 512 minecraft:gray_concrete
fill 228 287 514 228 288 514 minecraft:gray_concrete
fill 228 287 516 228 288 516 minecraft:gray_concrete
fill 228 287 544 228 288 544 minecraft:gray_concrete
fill 228 287 546 228 288 546 minecraft:gray_concrete
fill 228 287 548 228 288 548 minecraft:gray_concrete
fill 228 287 550 228 288 550 minecraft:gray_concrete
fill 229 287 511 229 288 511 minecraft:gray_concrete
fill 229 287 513 229 288 513 minecraft:gray_concrete
fill 229 287 515 229 288 515 minecraft:gray_concrete
fill 229 287 517 229 288 517 minecraft:gray_concrete
fill 229 287 543 229 288 543 minecraft:gray_concrete
fill 229 287 545 229 288 545 minecraft:gray_concrete
fill 229 287 547 229 288 547 minecraft:gray_concrete
fill 229 287 549 229 288 549 minecraft:gray_concrete
setblock 191 289 513 minecraft:light[level=10]
setblock 191 289 521 minecraft:light[level=10]
setblock 191 289 529 minecraft:light[level=10]
setblock 191 289 537 minecraft:light[level=10]
setblock 191 289 545 minecraft:light[level=10]
setblock 199 289 513 minecraft:light[level=10]
setblock 199 289 521 minecraft:light[level=10]
setblock 199 289 529 minecraft:light[level=10]
setblock 199 289 537 minecraft:light[level=10]
setblock 199 289 545 minecraft:light[level=10]
setblock 207 289 513 minecraft:light[level=10]
setblock 207 289 521 minecraft:light[level=10]
setblock 207 289 537 minecraft:light[level=10]
setblock 207 289 543 minecraft:pearlescent_froglight
setblock 207 289 545 minecraft:pearlescent_froglight
setblock 207 289 547 minecraft:pearlescent_froglight
setblock 207 289 549 minecraft:pearlescent_froglight
setblock 207 289 551 minecraft:pearlescent_froglight
setblock 208 289 544 minecraft:pearlescent_froglight
setblock 208 289 546 minecraft:pearlescent_froglight
setblock 208 289 548 minecraft:pearlescent_froglight
setblock 208 289 550 minecraft:pearlescent_froglight
setblock 209 289 543 minecraft:pearlescent_froglight
setblock 209 289 545 minecraft:pearlescent_froglight
setblock 209 289 547 minecraft:pearlescent_froglight
setblock 209 289 549 minecraft:pearlescent_froglight
setblock 209 289 551 minecraft:pearlescent_froglight
setblock 210 289 544 minecraft:pearlescent_froglight
setblock 210 289 546 minecraft:pearlescent_froglight
setblock 210 289 548 minecraft:pearlescent_froglight
setblock 210 289 550 minecraft:pearlescent_froglight
setblock 211 289 543 minecraft:pearlescent_froglight
setblock 211 289 545 minecraft:pearlescent_froglight
setblock 211 289 547 minecraft:pearlescent_froglight
setblock 211 289 549 minecraft:pearlescent_froglight
setblock 211 289 551 minecraft:pearlescent_froglight
setblock 212 289 544 minecraft:pearlescent_froglight
setblock 212 289 546 minecraft:pearlescent_froglight
setblock 212 289 548 minecraft:pearlescent_froglight
setblock 212 289 550 minecraft:pearlescent_froglight
setblock 213 289 543 minecraft:pearlescent_froglight
setblock 213 289 545 minecraft:pearlescent_froglight
setblock 213 289 547 minecraft:pearlescent_froglight
setblock 213 289 549 minecraft:pearlescent_froglight
setblock 213 289 551 minecraft:pearlescent_froglight
setblock 214 289 544 minecraft:pearlescent_froglight
setblock 214 289 546 minecraft:pearlescent_froglight
setblock 214 289 548 minecraft:pearlescent_froglight
setblock 214 289 550 minecraft:pearlescent_froglight
setblock 215 289 513 minecraft:light[level=10]
setblock 215 289 521 minecraft:light[level=10]
setblock 215 289 529 minecraft:light[level=10]
setblock 215 289 537 minecraft:light[level=10]
setblock 215 289 543 minecraft:pearlescent_froglight
setblock 215 289 545 minecraft:pearlescent_froglight
setblock 215 289 547 minecraft:pearlescent_froglight
setblock 215 289 549 minecraft:pearlescent_froglight
setblock 215 289 551 minecraft:pearlescent_froglight
setblock 216 289 544 minecraft:pearlescent_froglight
setblock 216 289 546 minecraft:pearlescent_froglight
setblock 216 289 548 minecraft:pearlescent_froglight
setblock 216 289 550 minecraft:pearlescent_froglight
setblock 217 289 543 minecraft:pearlescent_froglight
setblock 217 289 545 minecraft:pearlescent_froglight
setblock 217 289 547 minecraft:pearlescent_froglight
setblock 217 289 549 minecraft:pearlescent_froglight
setblock 217 289 551 minecraft:pearlescent_froglight
setblock 218 289 544 minecraft:pearlescent_froglight
setblock 218 289 546 minecraft:pearlescent_froglight
setblock 218 289 548 minecraft:pearlescent_froglight
setblock 218 289 550 minecraft:pearlescent_froglight
setblock 219 289 543 minecraft:pearlescent_froglight
setblock 219 289 545 minecraft:pearlescent_froglight
setblock 219 289 547 minecraft:pearlescent_froglight
setblock 219 289 549 minecraft:pearlescent_froglight
setblock 219 289 551 minecraft:pearlescent_froglight
setblock 220 289 544 minecraft:pearlescent_froglight
setblock 220 289 546 minecraft:pearlescent_froglight
setblock 220 289 548 minecraft:pearlescent_froglight
setblock 220 289 550 minecraft:pearlescent_froglight
setblock 221 289 545 minecraft:pearlescent_froglight
setblock 221 289 547 minecraft:pearlescent_froglight
setblock 221 289 549 minecraft:pearlescent_froglight
setblock 222 289 544 minecraft:pearlescent_froglight
setblock 222 289 546 minecraft:pearlescent_froglight
setblock 222 289 548 minecraft:pearlescent_froglight
setblock 222 289 550 minecraft:pearlescent_froglight
setblock 223 289 513 minecraft:light[level=10]
setblock 223 289 521 minecraft:light[level=10]
setblock 223 289 529 minecraft:light[level=10]
setblock 223 289 537 minecraft:light[level=10]
setblock 223 289 543 minecraft:pearlescent_froglight
setblock 223 289 545 minecraft:pearlescent_froglight
setblock 223 289 547 minecraft:pearlescent_froglight
setblock 223 289 549 minecraft:pearlescent_froglight
setblock 224 289 510 minecraft:pearlescent_froglight
setblock 224 289 512 minecraft:pearlescent_froglight
setblock 224 289 514 minecraft:pearlescent_froglight
setblock 224 289 516 minecraft:pearlescent_froglight
setblock 224 289 544 minecraft:pearlescent_froglight
setblock 224 289 546 minecraft:pearlescent_froglight
setblock 224 289 548 minecraft:pearlescent_froglight
setblock 224 289 550 minecraft:pearlescent_froglight
setblock 225 289 511 minecraft:pearlescent_froglight
setblock 225 289 513 minecraft:pearlescent_froglight
setblock 225 289 515 minecraft:pearlescent_froglight
setblock 225 289 517 minecraft:pearlescent_froglight
setblock 225 289 543 minecraft:pearlescent_froglight
setblock 225 289 545 minecraft:pearlescent_froglight
setblock 225 289 547 minecraft:pearlescent_froglight
setblock 225 289 549 minecraft:pearlescent_froglight
setblock 226 289 510 minecraft:pearlescent_froglight
setblock 226 289 512 minecraft:pearlescent_froglight
setblock 226 289 514 minecraft:pearlescent_froglight
setblock 226 289 516 minecraft:pearlescent_froglight
setblock 226 289 544 minecraft:pearlescent_froglight
setblock 226 289 546 minecraft:pearlescent_froglight
setblock 226 289 548 minecraft:pearlescent_froglight
setblock 226 289 550 minecraft:pearlescent_froglight
setblock 227 289 511 minecraft:pearlescent_froglight
setblock 227 289 513 minecraft:pearlescent_froglight
setblock 227 289 515 minecraft:pearlescent_froglight
setblock 227 289 517 minecraft:pearlescent_froglight
setblock 227 289 543 minecraft:pearlescent_froglight
setblock 227 289 545 minecraft:pearlescent_froglight
setblock 227 289 547 minecraft:pearlescent_froglight
setblock 227 289 549 minecraft:pearlescent_froglight
setblock 228 289 510 minecraft:pearlescent_froglight
setblock 228 289 512 minecraft:pearlescent_froglight
setblock 228 289 514 minecraft:pearlescent_froglight
setblock 228 289 516 minecraft:pearlescent_froglight
setblock 228 289 544 minecraft:pearlescent_froglight
setblock 228 289 546 minecraft:pearlescent_froglight
setblock 228 289 548 minecraft:pearlescent_froglight
setblock 228 289 550 minecraft:pearlescent_froglight
setblock 229 289 511 minecraft:pearlescent_froglight
setblock 229 289 513 minecraft:pearlescent_froglight
setblock 229 289 515 minecraft:pearlescent_froglight
setblock 229 289 517 minecraft:pearlescent_froglight
setblock 229 289 543 minecraft:pearlescent_froglight
setblock 229 289 545 minecraft:pearlescent_froglight
setblock 229 289 547 minecraft:pearlescent_froglight
setblock 229 289 549 minecraft:pearlescent_froglight
fill 188 290 515 188 297 515 minecraft:black_concrete
fill 188 290 523 188 297 523 minecraft:black_concrete
fill 188 290 531 188 297 531 minecraft:black_concrete
fill 188 290 539 188 297 539 minecraft:black_concrete
fill 188 290 547 188 297 547 minecraft:black_concrete
fill 191 290 552 191 297 552 minecraft:black_concrete
fill 195 290 510 195 297 510 minecraft:black_concrete
fill 199 290 552 199 297 552 minecraft:black_concrete
fill 203 290 510 203 297 510 minecraft:black_concrete
fill 207 290 543 207 291 543 minecraft:gray_concrete
fill 207 290 545 207 291 545 minecraft:gray_concrete
fill 207 290 547 207 291 547 minecraft:gray_concrete
fill 207 290 549 207 291 549 minecraft:gray_concrete
fill 207 290 551 207 291 551 minecraft:gray_concrete
fill 207 290 552 207 297 552 minecraft:black_concrete
fill 208 290 544 208 291 544 minecraft:gray_concrete
fill 208 290 546 208 291 546 minecraft:gray_concrete
fill 208 290 548 208 291 548 minecraft:gray_concrete
fill 208 290 550 208 291 550 minecraft:gray_concrete
fill 209 290 543 209 291 543 minecraft:gray_concrete
fill 209 290 545 209 291 545 minecraft:gray_concrete
fill 209 290 547 209 291 547 minecraft:gray_concrete
fill 209 290 549 209 291 549 minecraft:gray_concrete
fill 209 290 551 209 291 551 minecraft:gray_concrete
fill 210 290 544 210 291 544 minecraft:gray_concrete
fill 210 290 546 210 291 546 minecraft:gray_concrete
fill 210 290 548 210 291 548 minecraft:gray_concrete
fill 210 290 550 210 291 550 minecraft:gray_concrete
fill 211 290 510 211 297 510 minecraft:black_concrete
fill 211 290 543 211 291 543 minecraft:gray_concrete
fill 211 290 545 211 291 545 minecraft:gray_concrete
fill 211 290 547 211 291 547 minecraft:gray_concrete
fill 211 290 549 211 291 549 minecraft:gray_concrete
fill 211 290 551 211 291 551 minecraft:gray_concrete
fill 212 290 544 212 291 544 minecraft:gray_concrete
fill 212 290 546 212 291 546 minecraft:gray_concrete
fill 212 290 548 212 291 548 minecraft:gray_concrete
fill 212 290 550 212 291 550 minecraft:gray_concrete
fill 213 290 543 213 291 543 minecraft:gray_concrete
fill 213 290 545 213 291 545 minecraft:gray_concrete
fill 213 290 547 213 291 547 minecraft:gray_concrete
fill 213 290 549 213 291 549 minecraft:gray_concrete
fill 213 290 551 213 291 551 minecraft:gray_concrete
fill 214 290 544 214 291 544 minecraft:gray_concrete
fill 214 290 546 214 291 546 minecraft:gray_concrete
fill 214 290 548 214 291 548 minecraft:gray_concrete
fill 214 290 550 214 291 550 minecraft:gray_concrete
fill 215 290 543 215 291 543 minecraft:gray_concrete
fill 215 290 545 215 291 545 minecraft:gray_concrete
fill 215 290 547 215 291 547 minecraft:gray_concrete
fill 215 290 549 215 291 549 minecraft:gray_concrete
fill 215 290 551 215 291 551 minecraft:gray_concrete
fill 215 290 552 215 297 552 minecraft:black_concrete
fill 216 290 544 216 291 544 minecraft:gray_concrete
fill 216 290 546 216 291 546 minecraft:gray_concrete
fill 216 290 548 216 291 548 minecraft:gray_concrete
fill 216 290 550 216 291 550 minecraft:gray_concrete
fill 217 290 543 217 291 543 minecraft:gray_concrete
fill 217 290 545 217 291 545 minecraft:gray_concrete
fill 217 290 547 217 291 547 minecraft:gray_concrete
fill 217 290 549 217 291 549 minecraft:gray_concrete
fill 217 290 551 217 291 551 minecraft:gray_concrete
fill 218 290 544 218 291 544 minecraft:gray_concrete
fill 218 290 546 218 291 546 minecraft:gray_concrete
fill 218 290 548 218 291 548 minecraft:gray_concrete
fill 218 290 550 218 291 550 minecraft:gray_concrete
fill 219 290 510 219 297 510 minecraft:black_concrete
fill 219 290 543 219 291 543 minecraft:gray_concrete
fill 219 290 545 219 291 545 minecraft:gray_concrete
fill 219 290 547 219 291 547 minecraft:gray_concrete
fill 219 290 549 219 291 549 minecraft:gray_concrete
fill 219 290 551 219 291 551 minecraft:gray_concrete
fill 220 290 544 220 291 544 minecraft:gray_concrete
fill 220 290 546 220 291 546 minecraft:gray_concrete
fill 220 290 548 220 291 548 minecraft:gray_concrete
fill 220 290 550 220 291 550 minecraft:gray_concrete
fill 221 290 545 221 291 545 minecraft:gray_concrete
fill 221 290 547 221 291 547 minecraft:gray_concrete
fill 221 290 549 221 291 549 minecraft:gray_concrete
fill 222 290 544 222 291 544 minecraft:gray_concrete
fill 222 290 546 222 291 546 minecraft:gray_concrete
fill 222 290 548 222 291 548 minecraft:gray_concrete
fill 222 290 550 222 291 550 minecraft:gray_concrete
fill 223 290 543 223 291 543 minecraft:gray_concrete
fill 223 290 545 223 291 545 minecraft:gray_concrete
fill 223 290 547 223 291 547 minecraft:gray_concrete
fill 223 290 549 223 291 549 minecraft:gray_concrete
fill 223 290 552 223 297 552 minecraft:black_concrete
fill 224 290 510 224 291 510 minecraft:black_concrete
fill 224 290 512 224 291 512 minecraft:gray_concrete
fill 224 290 514 224 291 514 minecraft:gray_concrete
fill 224 290 516 224 291 516 minecraft:gray_concrete
fill 224 290 544 224 291 544 minecraft:gray_concrete
fill 224 290 546 224 291 546 minecraft:gray_concrete
fill 224 290 548 224 291 548 minecraft:gray_concrete
fill 224 290 550 224 291 550 minecraft:gray_concrete
fill 225 290 511 225 291 511 minecraft:gray_concrete
fill 225 290 513 225 291 513 minecraft:gray_concrete
fill 225 290 515 225 291 515 minecraft:gray_concrete
fill 225 290 517 225 291 517 minecraft:gray_concrete
fill 225 290 543 225 291 543 minecraft:gray_concrete
fill 225 290 545 225 291 545 minecraft:gray_concrete
fill 225 290 547 225 291 547 minecraft:gray_concrete
fill 225 290 549 225 291 549 minecraft:gray_concrete
fill 226 290 510 228 291 510 minecraft:black_concrete
fill 226 290 512 226 291 512 minecraft:gray_concrete
fill 226 290 514 226 291 514 minecraft:gray_concrete
fill 226 290 516 226 291 516 minecraft:gray_concrete
fill 226 290 544 226 291 544 minecraft:gray_concrete
fill 226 290 546 226 291 546 minecraft:gray_concrete
fill 226 290 548 226 291 548 minecraft:gray_concrete
fill 226 290 550 226 291 550 minecraft:gray_concrete
fill 227 290 511 227 291 511 minecraft:gray_concrete
fill 227 290 513 227 291 513 minecraft:gray_concrete
fill 227 290 515 227 291 515 minecraft:gray_concrete
fill 227 290 517 227 291 517 minecraft:gray_concrete
fill 227 290 543 227 291 543 minecraft:gray_concrete
fill 227 290 545 227 291 545 minecraft:gray_concrete
fill 227 290 547 227 291 547 minecraft:gray_concrete
fill 227 290 549 227 291 549 minecraft:gray_concrete
fill 228 290 512 228 291 512 minecraft:gray_concrete
fill 228 290 514 228 291 514 minecraft:gray_concrete
fill 228 290 516 228 291 516 minecraft:gray_concrete
fill 228 290 544 228 291 544 minecraft:gray_concrete
fill 228 290 546 228 291 546 minecraft:gray_concrete
fill 228 290 548 228 291 548 minecraft:gray_concrete
fill 228 290 550 228 291 550 minecraft:gray_concrete
fill 229 290 511 229 291 511 minecraft:gray_concrete
fill 229 290 513 229 291 513 minecraft:gray_concrete
fill 229 290 515 229 291 515 minecraft:gray_concrete
fill 229 290 517 229 291 517 minecraft:gray_concrete
fill 229 290 543 229 291 543 minecraft:gray_concrete
fill 229 290 545 229 291 545 minecraft:gray_concrete
fill 229 290 547 229 291 547 minecraft:gray_concrete
fill 229 290 549 229 291 549 minecraft:gray_concrete
fill 230 290 515 230 297 515 minecraft:black_concrete
fill 230 290 523 230 297 523 minecraft:black_concrete
fill 230 290 531 230 297 531 minecraft:black_concrete
fill 230 290 539 230 297 539 minecraft:black_concrete
fill 230 290 547 230 297 547 minecraft:black_concrete
setblock 207 292 543 minecraft:pearlescent_froglight
setblock 207 292 545 minecraft:pearlescent_froglight
setblock 207 292 547 minecraft:pearlescent_froglight
setblock 207 292 549 minecraft:pearlescent_froglight
setblock 207 292 551 minecraft:pearlescent_froglight
setblock 208 292 544 minecraft:pearlescent_froglight
setblock 208 292 546 minecraft:pearlescent_froglight
setblock 208 292 548 minecraft:pearlescent_froglight
setblock 208 292 550 minecraft:pearlescent_froglight
setblock 209 292 543 minecraft:pearlescent_froglight
setblock 209 292 545 minecraft:pearlescent_froglight
setblock 209 292 547 minecraft:pearlescent_froglight
setblock 209 292 549 minecraft:pearlescent_froglight
setblock 209 292 551 minecraft:pearlescent_froglight
setblock 210 292 544 minecraft:pearlescent_froglight
setblock 210 292 546 minecraft:pearlescent_froglight
setblock 210 292 548 minecraft:pearlescent_froglight
setblock 210 292 550 minecraft:pearlescent_froglight
setblock 211 292 543 minecraft:pearlescent_froglight
setblock 211 292 545 minecraft:pearlescent_froglight
setblock 211 292 547 minecraft:pearlescent_froglight
setblock 211 292 549 minecraft:pearlescent_froglight
setblock 211 292 551 minecraft:pearlescent_froglight
setblock 212 292 544 minecraft:pearlescent_froglight
setblock 212 292 546 minecraft:pearlescent_froglight
setblock 212 292 548 minecraft:pearlescent_froglight
setblock 212 292 550 minecraft:pearlescent_froglight
setblock 213 292 543 minecraft:pearlescent_froglight
setblock 213 292 545 minecraft:pearlescent_froglight
setblock 213 292 547 minecraft:pearlescent_froglight
setblock 213 292 549 minecraft:pearlescent_froglight
setblock 213 292 551 minecraft:pearlescent_froglight
setblock 214 292 544 minecraft:pearlescent_froglight
setblock 214 292 546 minecraft:pearlescent_froglight
setblock 214 292 548 minecraft:pearlescent_froglight
setblock 214 292 550 minecraft:pearlescent_froglight
setblock 215 292 543 minecraft:pearlescent_froglight
setblock 215 292 545 minecraft:pearlescent_froglight
setblock 215 292 547 minecraft:pearlescent_froglight
setblock 215 292 549 minecraft:pearlescent_froglight
setblock 215 292 551 minecraft:pearlescent_froglight
setblock 216 292 544 minecraft:pearlescent_froglight
setblock 216 292 546 minecraft:pearlescent_froglight
setblock 216 292 548 minecraft:pearlescent_froglight
setblock 216 292 550 minecraft:pearlescent_froglight
setblock 217 292 543 minecraft:pearlescent_froglight
setblock 217 292 545 minecraft:pearlescent_froglight
setblock 217 292 547 minecraft:pearlescent_froglight
setblock 217 292 549 minecraft:pearlescent_froglight
setblock 217 292 551 minecraft:pearlescent_froglight
setblock 218 292 544 minecraft:pearlescent_froglight
setblock 218 292 546 minecraft:pearlescent_froglight
setblock 218 292 548 minecraft:pearlescent_froglight
setblock 218 292 550 minecraft:pearlescent_froglight
setblock 219 292 543 minecraft:pearlescent_froglight
setblock 219 292 545 minecraft:pearlescent_froglight
setblock 219 292 547 minecraft:pearlescent_froglight
setblock 219 292 549 minecraft:pearlescent_froglight
setblock 219 292 551 minecraft:pearlescent_froglight
setblock 220 292 544 minecraft:pearlescent_froglight
setblock 220 292 546 minecraft:pearlescent_froglight
setblock 220 292 548 minecraft:pearlescent_froglight
setblock 220 292 550 minecraft:pearlescent_froglight
setblock 221 292 545 minecraft:pearlescent_froglight
setblock 221 292 547 minecraft:pearlescent_froglight
setblock 221 292 549 minecraft:pearlescent_froglight
setblock 222 292 544 minecraft:pearlescent_froglight
setblock 222 292 546 minecraft:pearlescent_froglight
setblock 222 292 548 minecraft:pearlescent_froglight
setblock 222 292 550 minecraft:pearlescent_froglight
setblock 223 292 543 minecraft:pearlescent_froglight
setblock 223 292 545 minecraft:pearlescent_froglight
setblock 223 292 547 minecraft:pearlescent_froglight
setblock 223 292 549 minecraft:pearlescent_froglight
setblock 224 292 510 minecraft:pearlescent_froglight
setblock 224 292 512 minecraft:pearlescent_froglight
setblock 224 292 514 minecraft:pearlescent_froglight
setblock 224 292 516 minecraft:pearlescent_froglight
setblock 224 292 544 minecraft:pearlescent_froglight
setblock 224 292 546 minecraft:pearlescent_froglight
setblock 224 292 548 minecraft:pearlescent_froglight
setblock 224 292 550 minecraft:pearlescent_froglight
setblock 225 292 511 minecraft:pearlescent_froglight
setblock 225 292 513 minecraft:pearlescent_froglight
setblock 225 292 515 minecraft:pearlescent_froglight
setblock 225 292 517 minecraft:pearlescent_froglight
setblock 225 292 543 minecraft:pearlescent_froglight
setblock 225 292 545 minecraft:pearlescent_froglight
setblock 225 292 547 minecraft:pearlescent_froglight
setblock 225 292 549 minecraft:pearlescent_froglight
setblock 226 292 510 minecraft:pearlescent_froglight
setblock 226 292 512 minecraft:pearlescent_froglight
setblock 226 292 514 minecraft:pearlescent_froglight
setblock 226 292 516 minecraft:pearlescent_froglight
setblock 226 292 544 minecraft:pearlescent_froglight
setblock 226 292 546 minecraft:pearlescent_froglight
setblock 226 292 548 minecraft:pearlescent_froglight
setblock 226 292 550 minecraft:pearlescent_froglight
fill 227 292 510 227 297 510 minecraft:black_concrete
setblock 227 292 511 minecraft:pearlescent_froglight
setblock 227 292 513 minecraft:pearlescent_froglight
setblock 227 292 515 minecraft:pearlescent_froglight
setblock 227 292 517 minecraft:pearlescent_froglight
setblock 227 292 543 minecraft:pearlescent_froglight
setblock 227 292 545 minecraft:pearlescent_froglight
setblock 227 292 547 minecraft:pearlescent_froglight
setblock 227 292 549 minecraft:pearlescent_froglight
setblock 228 292 510 minecraft:pearlescent_froglight
setblock 228 292 512 minecraft:pearlescent_froglight
setblock 228 292 514 minecraft:pearlescent_froglight
setblock 228 292 516 minecraft:pearlescent_froglight
setblock 228 292 544 minecraft:pearlescent_froglight
setblock 228 292 546 minecraft:pearlescent_froglight
setblock 228 292 548 minecraft:pearlescent_froglight
setblock 228 292 550 minecraft:pearlescent_froglight
setblock 229 292 511 minecraft:pearlescent_froglight
setblock 229 292 513 minecraft:pearlescent_froglight
setblock 229 292 515 minecraft:pearlescent_froglight
setblock 229 292 517 minecraft:pearlescent_froglight
setblock 229 292 543 minecraft:pearlescent_froglight
setblock 229 292 545 minecraft:pearlescent_froglight
setblock 229 292 547 minecraft:pearlescent_froglight
setblock 229 292 549 minecraft:pearlescent_froglight
fill 207 293 543 207 294 543 minecraft:gray_concrete
fill 207 293 545 207 294 545 minecraft:gray_concrete
fill 207 293 547 207 294 547 minecraft:gray_concrete
fill 207 293 549 207 294 549 minecraft:gray_concrete
fill 207 293 551 207 294 551 minecraft:gray_concrete
fill 208 293 544 208 294 544 minecraft:gray_concrete
fill 208 293 546 208 294 546 minecraft:gray_concrete
fill 208 293 548 208 294 548 minecraft:gray_concrete
fill 208 293 550 208 294 550 minecraft:gray_concrete
fill 209 293 543 209 294 543 minecraft:gray_concrete
fill 209 293 545 209 294 545 minecraft:gray_concrete
fill 209 293 547 209 294 547 minecraft:gray_concrete
fill 209 293 549 209 294 549 minecraft:gray_concrete
fill 209 293 551 209 294 551 minecraft:gray_concrete
fill 210 293 544 210 294 544 minecraft:gray_concrete
fill 210 293 546 210 294 546 minecraft:gray_concrete
fill 210 293 548 210 294 548 minecraft:gray_concrete
fill 210 293 550 210 294 550 minecraft:gray_concrete
fill 211 293 543 211 294 543 minecraft:gray_concrete
fill 211 293 545 211 294 545 minecraft:gray_concrete
fill 211 293 547 211 294 547 minecraft:gray_concrete
fill 211 293 549 211 294 549 minecraft:gray_concrete
fill 211 293 551 211 294 551 minecraft:gray_concrete
fill 212 293 544 212 294 544 minecraft:gray_concrete
fill 212 293 546 212 294 546 minecraft:gray_concrete
fill 212 293 548 212 294 548 minecraft:gray_concrete
fill 212 293 550 212 294 550 minecraft:gray_concrete
fill 213 293 543 213 294 543 minecraft:gray_concrete
fill 213 293 545 213 294 545 minecraft:gray_concrete
fill 213 293 547 213 294 547 minecraft:gray_concrete
fill 213 293 549 213 294 549 minecraft:gray_concrete
fill 213 293 551 213 294 551 minecraft:gray_concrete
fill 214 293 544 214 294 544 minecraft:gray_concrete
fill 214 293 546 214 294 546 minecraft:gray_concrete
fill 214 293 548 214 294 548 minecraft:gray_concrete
fill 214 293 550 214 294 550 minecraft:gray_concrete
fill 215 293 543 215 294 543 minecraft:gray_concrete
fill 215 293 545 215 294 545 minecraft:gray_concrete
fill 215 293 547 215 294 547 minecraft:gray_concrete
fill 215 293 549 215 294 549 minecraft:gray_concrete
fill 215 293 551 215 294 551 minecraft:gray_concrete
fill 216 293 544 216 294 544 minecraft:gray_concrete
fill 216 293 546 216 294 546 minecraft:gray_concrete
fill 216 293 548 216 294 548 minecraft:gray_concrete
fill 216 293 550 216 294 550 minecraft:gray_concrete
fill 217 293 543 217 294 543 minecraft:gray_concrete
fill 217 293 545 217 294 545 minecraft:gray_concrete
fill 217 293 547 217 294 547 minecraft:gray_concrete
fill 217 293 549 217 294 549 minecraft:gray_concrete
fill 217 293 551 217 294 551 minecraft:gray_concrete
fill 218 293 544 218 294 544 minecraft:gray_concrete
fill 218 293 546 218 294 546 minecraft:gray_concrete
fill 218 293 548 218 294 548 minecraft:gray_concrete
fill 218 293 550 218 294 550 minecraft:gray_concrete
fill 219 293 543 219 294 543 minecraft:gray_concrete
fill 219 293 545 219 294 545 minecraft:gray_concrete
fill 219 293 547 219 294 547 minecraft:gray_concrete
fill 219 293 549 219 294 549 minecraft:gray_concrete
fill 219 293 551 219 294 551 minecraft:gray_concrete
fill 220 293 544 220 294 544 minecraft:gray_concrete
fill 220 293 546 220 294 546 minecraft:gray_concrete
fill 220 293 548 220 294 548 minecraft:gray_concrete
fill 220 293 550 220 294 550 minecraft:gray_concrete
fill 221 293 545 221 294 545 minecraft:gray_concrete
fill 221 293 547 221 294 547 minecraft:gray_concrete
fill 221 293 549 221 294 549 minecraft:gray_concrete
fill 222 293 544 222 294 544 minecraft:gray_concrete
fill 222 293 546 222 294 546 minecraft:gray_concrete
fill 222 293 548 222 294 548 minecraft:gray_concrete
fill 222 293 550 222 294 550 minecraft:gray_concrete
fill 223 293 543 223 294 543 minecraft:gray_concrete
fill 223 293 545 223 294 545 minecraft:gray_concrete
fill 223 293 547 223 294 547 minecraft:gray_concrete
fill 223 293 549 223 294 549 minecraft:gray_concrete
fill 224 293 510 224 307 510 minecraft:black_concrete
fill 224 293 512 224 295 512 minecraft:gray_concrete
fill 224 293 514 224 295 514 minecraft:gray_concrete
fill 224 293 516 224 295 516 minecraft:gray_concrete
fill 224 293 544 224 294 544 minecraft:gray_concrete
fill 224 293 546 224 294 546 minecraft:gray_concrete
fill 224 293 548 224 294 548 minecraft:gray_concrete
fill 224 293 550 224 294 550 minecraft:gray_concrete
fill 225 293 511 225 295 511 minecraft:gray_concrete
fill 225 293 513 225 295 513 minecraft:gray_concrete
fill 225 293 515 225 295 515 minecraft:gray_concrete
fill 225 293 517 225 295 517 minecraft:gray_concrete
fill 225 293 543 225 294 543 minecraft:gray_concrete
fill 225 293 545 225 294 545 minecraft:gray_concrete
fill 225 293 547 225 294 547 minecraft:gray_concrete
fill 225 293 549 225 294 549 minecraft:gray_concrete
fill 226 293 510 226 307 510 minecraft:black_concrete
fill 226 293 512 226 295 512 minecraft:gray_concrete
fill 226 293 514 226 295 514 minecraft:gray_concrete
fill 226 293 516 226 295 516 minecraft:gray_concrete
fill 226 293 544 226 294 544 minecraft:gray_concrete
fill 226 293 546 226 294 546 minecraft:gray_concrete
fill 226 293 548 226 294 548 minecraft:gray_concrete
fill 226 293 550 226 294 550 minecraft:gray_concrete
fill 227 293 511 227 295 511 minecraft:gray_concrete
fill 227 293 513 227 295 513 minecraft:gray_concrete
fill 227 293 515 227 295 515 minecraft:gray_concrete
fill 227 293 517 227 295 517 minecraft:gray_concrete
fill 227 293 543 227 294 543 minecraft:gray_concrete
fill 227 293 545 227 294 545 minecraft:gray_concrete
fill 227 293 547 227 294 547 minecraft:gray_concrete
fill 227 293 549 227 294 549 minecraft:gray_concrete
fill 228 293 510 228 307 510 minecraft:black_concrete
fill 228 293 512 228 295 512 minecraft:gray_concrete
fill 228 293 514 228 295 514 minecraft:gray_concrete
fill 228 293 516 228 295 516 minecraft:gray_concrete
fill 228 293 544 228 294 544 minecraft:gray_concrete
fill 228 293 546 228 294 546 minecraft:gray_concrete
fill 228 293 548 228 294 548 minecraft:gray_concrete
fill 228 293 550 228 294 550 minecraft:gray_concrete
fill 229 293 511 229 295 511 minecraft:gray_concrete
fill 229 293 513 229 300 513 minecraft:gray_concrete
fill 229 293 515 229 295 515 minecraft:gray_concrete
fill 229 293 517 229 295 517 minecraft:gray_concrete
fill 229 293 543 229 294 543 minecraft:gray_concrete
fill 229 293 545 229 294 545 minecraft:gray_concrete
fill 229 293 547 229 294 547 minecraft:gray_concrete
fill 229 293 549 229 294 549 minecraft:gray_concrete
fill 189 294 511 189 295 516 minecraft:gray_concrete
fill 189 294 519 190 294 524 minecraft:gray_concrete
fill 189 294 527 190 294 532 minecraft:gray_concrete
fill 189 294 535 190 294 540 minecraft:gray_concrete
fill 189 294 543 190 294 548 minecraft:gray_concrete
fill 189 294 551 194 295 551 minecraft:gray_concrete
fill 190 294 512 190 294 518 minecraft:gray_concrete
fill 190 294 525 190 294 526 minecraft:gray_concrete
fill 190 294 533 190 294 534 minecraft:gray_concrete
fill 190 294 541 190 294 542 minecraft:gray_concrete
fill 190 294 549 190 294 550 minecraft:gray_concrete
fill 191 294 512 223 294 512 minecraft:gray_concrete
fill 191 294 550 206 294 550 minecraft:gray_concrete
fill 192 294 511 197 295 511 minecraft:gray_concrete
fill 197 294 551 202 295 551 minecraft:gray_concrete
fill 200 294 511 205 295 511 minecraft:gray_concrete
fill 205 294 551 206 295 551 minecraft:gray_concrete
fill 208 294 511 213 295 511 minecraft:gray_concrete
fill 216 294 511 221 295 511 minecraft:gray_concrete
fill 221 294 551 226 295 551 minecraft:gray_concrete
fill 228 294 518 228 294 542 minecraft:gray_concrete
fill 229 294 518 229 295 519 minecraft:gray_concrete
fill 229 294 522 229 295 527 minecraft:gray_concrete
fill 229 294 530 229 295 535 minecraft:gray_concrete
fill 229 294 538 229 295 542 minecraft:gray_concrete
fill 229 294 551 229 295 551 minecraft:gray_concrete
fill 189 295 519 189 295 524 minecraft:gray_concrete
fill 189 295 527 189 295 532 minecraft:gray_concrete
fill 189 295 535 189 295 540 minecraft:gray_concrete
fill 189 295 543 189 295 548 minecraft:gray_concrete
setblock 207 295 543 minecraft:pearlescent_froglight
setblock 207 295 545 minecraft:pearlescent_froglight
setblock 207 295 547 minecraft:pearlescent_froglight
setblock 207 295 549 minecraft:pearlescent_froglight
setblock 207 295 551 minecraft:pearlescent_froglight
setblock 208 295 544 minecraft:pearlescent_froglight
setblock 208 295 546 minecraft:pearlescent_froglight
setblock 208 295 548 minecraft:pearlescent_froglight
setblock 208 295 550 minecraft:pearlescent_froglight
setblock 209 295 543 minecraft:pearlescent_froglight
setblock 209 295 545 minecraft:pearlescent_froglight
setblock 209 295 547 minecraft:pearlescent_froglight
setblock 209 295 549 minecraft:pearlescent_froglight
setblock 209 295 551 minecraft:pearlescent_froglight
setblock 210 295 544 minecraft:pearlescent_froglight
setblock 210 295 546 minecraft:pearlescent_froglight
setblock 210 295 548 minecraft:pearlescent_froglight
setblock 210 295 550 minecraft:pearlescent_froglight
setblock 211 295 543 minecraft:pearlescent_froglight
setblock 211 295 545 minecraft:pearlescent_froglight
setblock 211 295 547 minecraft:pearlescent_froglight
setblock 211 295 549 minecraft:pearlescent_froglight
setblock 211 295 551 minecraft:pearlescent_froglight
setblock 212 295 544 minecraft:pearlescent_froglight
setblock 212 295 546 minecraft:pearlescent_froglight
setblock 212 295 548 minecraft:pearlescent_froglight
setblock 212 295 550 minecraft:pearlescent_froglight
setblock 213 295 543 minecraft:pearlescent_froglight
setblock 213 295 545 minecraft:pearlescent_froglight
setblock 213 295 547 minecraft:pearlescent_froglight
setblock 213 295 549 minecraft:pearlescent_froglight
setblock 213 295 551 minecraft:pearlescent_froglight
setblock 214 295 544 minecraft:pearlescent_froglight
setblock 214 295 546 minecraft:pearlescent_froglight
setblock 214 295 548 minecraft:pearlescent_froglight
setblock 214 295 550 minecraft:pearlescent_froglight
setblock 215 295 543 minecraft:pearlescent_froglight
setblock 215 295 545 minecraft:pearlescent_froglight
setblock 215 295 547 minecraft:pearlescent_froglight
setblock 215 295 549 minecraft:pearlescent_froglight
setblock 215 295 551 minecraft:pearlescent_froglight
setblock 216 295 544 minecraft:pearlescent_froglight
setblock 216 295 546 minecraft:pearlescent_froglight
setblock 216 295 548 minecraft:pearlescent_froglight
setblock 216 295 550 minecraft:pearlescent_froglight
setblock 217 295 543 minecraft:pearlescent_froglight
setblock 217 295 545 minecraft:pearlescent_froglight
setblock 217 295 547 minecraft:pearlescent_froglight
setblock 217 295 549 minecraft:pearlescent_froglight
setblock 217 295 551 minecraft:pearlescent_froglight
setblock 218 295 544 minecraft:pearlescent_froglight
setblock 218 295 546 minecraft:pearlescent_froglight
setblock 218 295 548 minecraft:pearlescent_froglight
setblock 218 295 550 minecraft:pearlescent_froglight
setblock 219 295 543 minecraft:pearlescent_froglight
setblock 219 295 545 minecraft:pearlescent_froglight
setblock 219 295 547 minecraft:pearlescent_froglight
setblock 219 295 549 minecraft:pearlescent_froglight
setblock 219 295 551 minecraft:pearlescent_froglight
setblock 220 295 544 minecraft:pearlescent_froglight
setblock 220 295 546 minecraft:pearlescent_froglight
setblock 220 295 548 minecraft:pearlescent_froglight
setblock 220 295 550 minecraft:pearlescent_froglight
setblock 221 295 545 minecraft:pearlescent_froglight
setblock 221 295 547 minecraft:pearlescent_froglight
setblock 221 295 549 minecraft:pearlescent_froglight
setblock 222 295 544 minecraft:pearlescent_froglight
setblock 222 295 546 minecraft:pearlescent_froglight
setblock 222 295 548 minecraft:pearlescent_froglight
setblock 222 295 550 minecraft:pearlescent_froglight
setblock 223 295 543 minecraft:pearlescent_froglight
setblock 223 295 545 minecraft:pearlescent_froglight
setblock 223 295 547 minecraft:pearlescent_froglight
setblock 223 295 549 minecraft:pearlescent_froglight
setblock 224 295 544 minecraft:pearlescent_froglight
setblock 224 295 546 minecraft:pearlescent_froglight
setblock 224 295 548 minecraft:pearlescent_froglight
setblock 224 295 550 minecraft:pearlescent_froglight
setblock 225 295 543 minecraft:pearlescent_froglight
setblock 225 295 545 minecraft:pearlescent_froglight
setblock 225 295 547 minecraft:pearlescent_froglight
setblock 225 295 549 minecraft:pearlescent_froglight
setblock 226 295 544 minecraft:pearlescent_froglight
setblock 226 295 546 minecraft:pearlescent_froglight
setblock 226 295 548 minecraft:pearlescent_froglight
setblock 226 295 550 minecraft:pearlescent_froglight
setblock 227 295 543 minecraft:pearlescent_froglight
setblock 227 295 545 minecraft:pearlescent_froglight
setblock 227 295 547 minecraft:pearlescent_froglight
setblock 227 295 549 minecraft:pearlescent_froglight
setblock 228 295 544 minecraft:pearlescent_froglight
setblock 228 295 546 minecraft:pearlescent_froglight
setblock 228 295 548 minecraft:pearlescent_froglight
setblock 228 295 550 minecraft:pearlescent_froglight
setblock 229 295 543 minecraft:pearlescent_froglight
setblock 229 295 545 minecraft:pearlescent_froglight
setblock 229 295 547 minecraft:pearlescent_froglight
setblock 229 295 549 minecraft:pearlescent_froglight
fill 207 296 543 207 297 543 minecraft:gray_concrete
fill 207 296 545 207 297 545 minecraft:gray_concrete
fill 207 296 547 207 297 547 minecraft:gray_concrete
fill 207 296 549 207 297 549 minecraft:gray_concrete
fill 207 296 551 207 297 551 minecraft:gray_concrete
fill 208 296 544 208 297 544 minecraft:gray_concrete
fill 208 296 546 208 297 546 minecraft:gray_concrete
fill 208 296 548 208 297 548 minecraft:gray_concrete
fill 208 296 550 208 297 550 minecraft:gray_concrete
fill 209 296 543 209 297 543 minecraft:gray_concrete
fill 209 296 545 209 297 545 minecraft:gray_concrete
fill 209 296 547 209 297 547 minecraft:gray_concrete
fill 209 296 549 209 297 549 minecraft:gray_concrete
fill 209 296 551 209 297 551 minecraft:gray_concrete
fill 210 296 544 210 297 544 minecraft:gray_concrete
fill 210 296 546 210 297 546 minecraft:gray_concrete
fill 210 296 548 210 297 548 minecraft:gray_concrete
fill 210 296 550 210 297 550 minecraft:gray_concrete
fill 211 296 543 211 297 543 minecraft:gray_concrete
fill 211 296 545 211 297 545 minecraft:gray_concrete
fill 211 296 547 211 297 547 minecraft:gray_concrete
fill 211 296 549 211 297 549 minecraft:gray_concrete
fill 211 296 551 211 297 551 minecraft:gray_concrete
fill 212 296 544 212 297 544 minecraft:gray_concrete
fill 212 296 546 212 297 546 minecraft:gray_concrete
fill 212 296 548 212 297 548 minecraft:gray_concrete
fill 212 296 550 212 297 550 minecraft:gray_concrete
fill 213 296 543 213 297 543 minecraft:gray_concrete
fill 213 296 545 213 297 545 minecraft:gray_concrete
fill 213 296 547 213 297 547 minecraft:gray_concrete
fill 213 296 549 213 297 549 minecraft:gray_concrete
fill 213 296 551 213 297 551 minecraft:gray_concrete
fill 214 296 544 214 297 544 minecraft:gray_concrete
fill 214 296 546 214 297 546 minecraft:gray_concrete
fill 214 296 548 214 297 548 minecraft:gray_concrete
fill 214 296 550 214 297 550 minecraft:gray_concrete
fill 215 296 543 215 297 543 minecraft:gray_concrete
fill 215 296 545 215 297 545 minecraft:gray_concrete
fill 215 296 547 215 297 547 minecraft:gray_concrete
fill 215 296 549 215 297 549 minecraft:gray_concrete
fill 215 296 551 215 297 551 minecraft:gray_concrete
fill 216 296 544 216 297 544 minecraft:gray_concrete
fill 216 296 546 216 297 546 minecraft:gray_concrete
fill 216 296 548 216 297 548 minecraft:gray_concrete
fill 216 296 550 216 297 550 minecraft:gray_concrete
fill 217 296 543 217 297 543 minecraft:gray_concrete
fill 217 296 545 217 297 545 minecraft:gray_concrete
fill 217 296 547 217 297 547 minecraft:gray_concrete
fill 217 296 549 217 297 549 minecraft:gray_concrete
fill 217 296 551 217 297 551 minecraft:gray_concrete
fill 218 296 544 218 297 544 minecraft:gray_concrete
fill 218 296 546 218 297 546 minecraft:gray_concrete
fill 218 296 548 218 297 548 minecraft:gray_concrete
fill 218 296 550 218 297 550 minecraft:gray_concrete
fill 219 296 543 219 297 543 minecraft:gray_concrete
fill 219 296 545 219 297 545 minecraft:gray_concrete
fill 219 296 547 219 297 547 minecraft:gray_concrete
fill 219 296 549 219 297 549 minecraft:gray_concrete
fill 219 296 551 219 297 551 minecraft:gray_concrete
fill 220 296 544 220 297 544 minecraft:gray_concrete
fill 220 296 546 220 297 546 minecraft:gray_concrete
fill 220 296 548 220 297 548 minecraft:gray_concrete
fill 220 296 550 220 297 550 minecraft:gray_concrete
fill 221 296 545 221 297 545 minecraft:gray_concrete
fill 221 296 547 221 297 547 minecraft:gray_concrete
fill 221 296 549 221 297 549 minecraft:gray_concrete
fill 222 296 511 223 300 511 minecraft:gray_concrete
fill 222 296 544 222 297 544 minecraft:gray_concrete
fill 222 296 546 222 297 546 minecraft:gray_concrete
fill 222 296 548 222 297 548 minecraft:gray_concrete
fill 222 296 550 222 297 550 minecraft:gray_concrete
setblock 223 296 543 minecraft:gray_concrete
fill 223 296 545 223 297 545 minecraft:gray_concrete
fill 223 296 547 223 297 547 minecraft:gray_concrete
fill 223 296 549 223 297 549 minecraft:gray_concrete
setblock 224 296 544 minecraft:gray_concrete
setblock 224 296 546 minecraft:gray_concrete
setblock 224 296 548 minecraft:gray_concrete
fill 224 296 550 224 297 550 minecraft:gray_concrete
fill 225 296 511 228 296 516 minecraft:white_concrete
setblock 225 296 543 minecraft:gray_concrete
setblock 225 296 545 minecraft:gray_concrete
setblock 225 296 547 minecraft:gray_concrete
fill 225 296 549 225 297 549 minecraft:gray_concrete
setblock 226 296 544 minecraft:gray_concrete
setblock 226 296 546 minecraft:gray_concrete
setblock 226 296 548 minecraft:gray_concrete
fill 226 296 550 226 297 550 minecraft:gray_concrete
setblock 227 296 543 minecraft:gray_concrete
setblock 227 296 545 minecraft:gray_concrete
setblock 227 296 547 minecraft:gray_concrete
fill 227 296 549 227 297 549 minecraft:gray_concrete
setblock 228 296 544 minecraft:gray_concrete
setblock 228 296 546 minecraft:gray_concrete
setblock 228 296 548 minecraft:gray_concrete
fill 228 296 550 228 297 550 minecraft:gray_concrete
setblock 229 296 543 minecraft:gray_concrete
fill 229 296 545 229 297 545 minecraft:gray_concrete
fill 229 296 547 229 297 547 minecraft:gray_concrete
fill 229 296 549 229 297 549 minecraft:gray_concrete
setblock 191 297 513 minecraft:light[level=10]
setblock 191 297 521 minecraft:light[level=10]
setblock 191 297 529 minecraft:light[level=10]
setblock 191 297 537 minecraft:light[level=10]
setblock 191 297 545 minecraft:light[level=10]
setblock 199 297 513 minecraft:light[level=10]
setblock 199 297 521 minecraft:light[level=10]
setblock 199 297 529 minecraft:light[level=10]
setblock 199 297 537 minecraft:light[level=10]
setblock 199 297 545 minecraft:light[level=10]
setblock 207 297 513 minecraft:light[level=10]
setblock 207 297 521 minecraft:light[level=10]
setblock 207 297 537 minecraft:light[level=10]
setblock 215 297 513 minecraft:light[level=10]
setblock 215 297 521 minecraft:light[level=10]
setblock 215 297 529 minecraft:light[level=10]
setblock 215 297 537 minecraft:light[level=10]
setblock 223 297 513 minecraft:light[level=10]
setblock 223 297 521 minecraft:light[level=10]
setblock 223 297 529 minecraft:light[level=10]
setblock 223 297 537 minecraft:light[level=10]
fill 224 297 544 228 297 548 minecraft:white_concrete
fill 226 297 511 227 297 515 minecraft:white_concrete
fill 188 298 515 188 300 515 minecraft:pearlescent_froglight
fill 188 298 523 188 300 523 minecraft:pearlescent_froglight
fill 188 298 531 188 300 531 minecraft:pearlescent_froglight
fill 188 298 539 188 300 539 minecraft:pearlescent_froglight
fill 188 298 547 188 300 547 minecraft:pearlescent_froglight
fill 191 298 552 191 300 552 minecraft:pearlescent_froglight
fill 195 298 510 195 300 510 minecraft:pearlescent_froglight
fill 199 298 552 199 300 552 minecraft:pearlescent_froglight
fill 203 298 510 203 300 510 minecraft:pearlescent_froglight
setblock 207 298 543 minecraft:pearlescent_froglight
setblock 207 298 545 minecraft:pearlescent_froglight
setblock 207 298 547 minecraft:pearlescent_froglight
setblock 207 298 549 minecraft:pearlescent_froglight
fill 207 298 551 207 298 552 minecraft:pearlescent_froglight
setblock 208 298 544 minecraft:pearlescent_froglight
setblock 208 298 546 minecraft:pearlescent_froglight
setblock 208 298 548 minecraft:pearlescent_froglight
setblock 208 298 550 minecraft:pearlescent_froglight
setblock 209 298 543 minecraft:pearlescent_froglight
setblock 209 298 545 minecraft:pearlescent_froglight
setblock 209 298 547 minecraft:pearlescent_froglight
setblock 209 298 549 minecraft:pearlescent_froglight
setblock 209 298 551 minecraft:pearlescent_froglight
setblock 210 298 544 minecraft:pearlescent_froglight
setblock 210 298 546 minecraft:pearlescent_froglight
setblock 210 298 548 minecraft:pearlescent_froglight
setblock 210 298 550 minecraft:pearlescent_froglight
fill 211 298 510 211 300 510 minecraft:pearlescent_froglight
setblock 211 298 543 minecraft:pearlescent_froglight
setblock 211 298 545 minecraft:pearlescent_froglight
setblock 211 298 547 minecraft:pearlescent_froglight
setblock 211 298 549 minecraft:pearlescent_froglight
setblock 211 298 551 minecraft:pearlescent_froglight
setblock 212 298 544 minecraft:pearlescent_froglight
setblock 212 298 546 minecraft:pearlescent_froglight
setblock 212 298 548 minecraft:pearlescent_froglight
setblock 212 298 550 minecraft:pearlescent_froglight
setblock 213 298 543 minecraft:pearlescent_froglight
setblock 213 298 545 minecraft:pearlescent_froglight
setblock 213 298 547 minecraft:pearlescent_froglight
setblock 213 298 549 minecraft:pearlescent_froglight
setblock 213 298 551 minecraft:pearlescent_froglight
setblock 214 298 544 minecraft:pearlescent_froglight
setblock 214 298 546 minecraft:pearlescent_froglight
setblock 214 298 548 minecraft:pearlescent_froglight
setblock 214 298 550 minecraft:pearlescent_froglight
setblock 215 298 543 minecraft:pearlescent_froglight
setblock 215 298 545 minecraft:pearlescent_froglight
setblock 215 298 547 minecraft:pearlescent_froglight
setblock 215 298 549 minecraft:pearlescent_froglight
fill 215 298 551 215 298 552 minecraft:pearlescent_froglight
setblock 216 298 544 minecraft:pearlescent_froglight
setblock 216 298 546 minecraft:pearlescent_froglight
setblock 216 298 548 minecraft:pearlescent_froglight
setblock 216 298 550 minecraft:pearlescent_froglight
setblock 217 298 543 minecraft:pearlescent_froglight
setblock 217 298 545 minecraft:pearlescent_froglight
setblock 217 298 547 minecraft:pearlescent_froglight
setblock 217 298 549 minecraft:pearlescent_froglight
setblock 217 298 551 minecraft:pearlescent_froglight
setblock 218 298 544 minecraft:pearlescent_froglight
setblock 218 298 546 minecraft:pearlescent_froglight
setblock 218 298 548 minecraft:pearlescent_froglight
setblock 218 298 550 minecraft:pearlescent_froglight
fill 219 298 510 219 300 510 minecraft:pearlescent_froglight
setblock 219 298 543 minecraft:pearlescent_froglight
setblock 219 298 545 minecraft:pearlescent_froglight
setblock 219 298 547 minecraft:pearlescent_froglight
setblock 219 298 549 minecraft:pearlescent_froglight
setblock 219 298 551 minecraft:pearlescent_froglight
setblock 220 298 544 minecraft:pearlescent_froglight
setblock 220 298 546 minecraft:pearlescent_froglight
setblock 220 298 548 minecraft:pearlescent_froglight
setblock 220 298 550 minecraft:pearlescent_froglight
setblock 221 298 545 minecraft:pearlescent_froglight
setblock 221 298 547 minecraft:pearlescent_froglight
setblock 221 298 549 minecraft:pearlescent_froglight
setblock 222 298 544 minecraft:pearlescent_froglight
setblock 222 298 546 minecraft:pearlescent_froglight
setblock 222 298 548 minecraft:pearlescent_froglight
setblock 222 298 550 minecraft:pearlescent_froglight
setblock 223 298 545 minecraft:pearlescent_froglight
setblock 223 298 547 minecraft:pearlescent_froglight
setblock 223 298 549 minecraft:pearlescent_froglight
fill 223 298 552 223 300 552 minecraft:pearlescent_froglight
setblock 224 298 544 minecraft:pearlescent_froglight
fill 224 298 545 224 300 545 minecraft:gray_concrete
setblock 224 298 546 minecraft:pearlescent_froglight
fill 224 298 547 224 300 547 minecraft:gray_concrete
setblock 224 298 548 minecraft:pearlescent_froglight
setblock 224 298 550 minecraft:pearlescent_froglight
fill 225 298 544 225 300 544 minecraft:gray_concrete
setblock 225 298 545 minecraft:pearlescent_froglight
setblock 225 298 546 minecraft:white_concrete
setblock 225 298 547 minecraft:pearlescent_froglight
fill 225 298 548 225 300 548 minecraft:gray_concrete
setblock 225 298 549 minecraft:pearlescent_froglight
fill 226 298 512 227 298 514 minecraft:white_concrete
setblock 226 298 544 minecraft:pearlescent_froglight
setblock 226 298 545 minecraft:white_concrete
setblock 226 298 546 minecraft:pearlescent_froglight
setblock 226 298 547 minecraft:white_concrete
setblock 226 298 548 minecraft:pearlescent_froglight
setblock 226 298 550 minecraft:pearlescent_froglight
fill 227 298 510 227 300 510 minecraft:pearlescent_froglight
fill 227 298 544 227 300 544 minecraft:gray_concrete
setblock 227 298 545 minecraft:pearlescent_froglight
setblock 227 298 546 minecraft:white_concrete
setblock 227 298 547 minecraft:pearlescent_froglight
fill 227 298 548 227 300 548 minecraft:gray_concrete
setblock 227 298 549 minecraft:pearlescent_froglight
setblock 228 298 544 minecraft:pearlescent_froglight
fill 228 298 545 228 300 545 minecraft:gray_concrete
setblock 228 298 546 minecraft:pearlescent_froglight
fill 228 298 547 228 300 547 minecraft:gray_concrete
setblock 228 298 548 minecraft:pearlescent_froglight
setblock 228 298 550 minecraft:pearlescent_froglight
setblock 229 298 545 minecraft:pearlescent_froglight
fill 229 298 547 230 298 547 minecraft:pearlescent_froglight
setblock 229 298 549 minecraft:pearlescent_froglight
fill 230 298 515 230 300 515 minecraft:pearlescent_froglight
fill 230 298 523 230 300 523 minecraft:pearlescent_froglight
fill 230 298 531 230 300 531 minecraft:pearlescent_froglight
fill 230 298 539 230 300 539 minecraft:pearlescent_froglight
fill 207 299 543 207 300 543 minecraft:gray_concrete
fill 207 299 545 207 300 545 minecraft:gray_concrete
fill 207 299 547 207 300 547 minecraft:gray_concrete
fill 207 299 549 207 300 549 minecraft:gray_concrete
fill 207 299 551 207 300 551 minecraft:gray_concrete
fill 207 299 552 207 300 552 minecraft:pearlescent_froglight
fill 208 299 544 208 300 544 minecraft:gray_concrete
fill 208 299 546 208 300 546 minecraft:gray_concrete
fill 208 299 548 208 300 548 minecraft:gray_concrete
fill 208 299 550 208 300 550 minecraft:gray_concrete
fill 209 299 543 209 300 543 minecraft:gray_concrete
fill 209 299 545 209 300 545 minecraft:gray_concrete
fill 209 299 547 209 300 547 minecraft:gray_concrete
fill 209 299 549 209 300 549 minecraft:gray_concrete
fill 209 299 551 209 300 551 minecraft:gray_concrete
fill 210 299 544 210 300 544 minecraft:gray_concrete
fill 210 299 546 210 300 546 minecraft:gray_concrete
fill 210 299 548 210 300 548 minecraft:gray_concrete
fill 210 299 550 210 300 550 minecraft:gray_concrete
fill 211 299 543 211 300 543 minecraft:gray_concrete
fill 211 299 545 211 300 545 minecraft:gray_concrete
fill 211 299 547 211 300 547 minecraft:gray_concrete
fill 211 299 549 211 300 549 minecraft:gray_concrete
fill 211 299 551 211 300 551 minecraft:gray_concrete
fill 212 299 544 212 300 544 minecraft:gray_concrete
fill 212 299 546 212 300 546 minecraft:gray_concrete
fill 212 299 548 212 300 548 minecraft:gray_concrete
fill 212 299 550 212 300 550 minecraft:gray_concrete
fill 213 299 543 213 300 543 minecraft:gray_concrete
fill 213 299 545 213 300 545 minecraft:gray_concrete
fill 213 299 547 213 300 547 minecraft:gray_concrete
fill 213 299 549 213 300 549 minecraft:gray_concrete
fill 213 299 551 213 300 551 minecraft:gray_concrete
fill 214 299 544 214 300 544 minecraft:gray_concrete
fill 214 299 546 214 300 546 minecraft:gray_concrete
fill 214 299 548 214 300 548 minecraft:gray_concrete
fill 214 299 550 214 300 550 minecraft:gray_concrete
fill 215 299 543 215 300 543 minecraft:gray_concrete
fill 215 299 545 215 300 545 minecraft:gray_concrete
fill 215 299 547 215 300 547 minecraft:gray_concrete
fill 215 299 549 215 300 549 minecraft:gray_concrete
fill 215 299 551 215 300 551 minecraft:gray_concrete
fill 215 299 552 215 300 552 minecraft:pearlescent_froglight
fill 216 299 544 216 300 544 minecraft:gray_concrete
fill 216 299 546 216 300 546 minecraft:gray_concrete
fill 216 299 548 216 300 548 minecraft:gray_concrete
fill 216 299 550 216 300 550 minecraft:gray_concrete
fill 217 299 543 217 300 543 minecraft:gray_concrete
fill 217 299 545 217 300 545 minecraft:gray_concrete
fill 217 299 547 217 300 547 minecraft:gray_concrete
fill 217 299 549 217 300 549 minecraft:gray_concrete
fill 217 299 551 217 300 551 minecraft:gray_concrete
fill 218 299 544 218 300 544 minecraft:gray_concrete
fill 218 299 546 218 300 546 minecraft:gray_concrete
fill 218 299 548 218 300 548 minecraft:gray_concrete
fill 218 299 550 218 300 550 minecraft:gray_concrete
fill 219 299 543 219 300 543 minecraft:gray_concrete
fill 219 299 545 219 300 545 minecraft:gray_concrete
fill 219 299 547 219 300 547 minecraft:gray_concrete
fill 219 299 549 219 300 549 minecraft:gray_concrete
fill 219 299 551 219 300 551 minecraft:gray_concrete
fill 220 299 544 220 300 544 minecraft:gray_concrete
fill 220 299 546 220 300 546 minecraft:gray_concrete
fill 220 299 548 220 300 548 minecraft:gray_concrete
fill 220 299 550 220 300 550 minecraft:gray_concrete
fill 221 299 545 221 300 545 minecraft:gray_concrete
fill 221 299 547 221 300 547 minecraft:gray_concrete
fill 221 299 549 221 300 549 minecraft:gray_concrete
fill 222 299 544 222 300 544 minecraft:gray_concrete
fill 222 299 546 222 300 546 minecraft:gray_concrete
fill 222 299 548 222 300 548 minecraft:gray_concrete
fill 222 299 550 222 300 550 minecraft:gray_concrete
fill 223 299 545 223 300 545 minecraft:gray_concrete
fill 223 299 547 223 300 547 minecraft:gray_concrete
fill 223 299 549 223 300 549 minecraft:gray_concrete
fill 224 299 544 224 300 544 minecraft:gray_concrete
fill 224 299 546 225 299 546 minecraft:gray_concrete
fill 224 299 548 224 300 548 minecraft:gray_concrete
fill 224 299 550 224 300 550 minecraft:gray_concrete
fill 225 299 513 228 299 513 minecraft:white_concrete
fill 225 299 545 227 299 545 minecraft:gray_concrete
fill 225 299 547 227 299 547 minecraft:gray_concrete
fill 225 299 549 225 300 549 minecraft:gray_concrete
fill 226 299 544 226 300 544 minecraft:gray_concrete
fill 226 299 546 226 300 546 minecraft:white_concrete
fill 226 299 548 226 300 548 minecraft:gray_concrete
fill 226 299 550 226 300 550 minecraft:gray_concrete
fill 227 299 546 228 299 546 minecraft:gray_concrete
fill 227 299 549 227 300 549 minecraft:gray_concrete
fill 228 299 544 228 300 544 minecraft:gray_concrete
fill 228 299 548 228 300 548 minecraft:gray_concrete
fill 228 299 550 228 300 550 minecraft:gray_concrete
fill 229 299 545 229 300 545 minecraft:gray_concrete
fill 229 299 547 229 300 547 minecraft:gray_concrete
fill 229 299 549 229 300 549 minecraft:gray_concrete
fill 230 299 547 230 300 547 minecraft:pearlescent_froglight
setblock 224 300 546 minecraft:gray_concrete
fill 225 300 545 225 300 547 minecraft:white_concrete
fill 226 300 545 227 300 545 minecraft:white_concrete
fill 226 300 547 227 300 547 minecraft:white_concrete
setblock 227 300 546 minecraft:white_concrete
setblock 228 300 546 minecraft:gray_concrete
fill 188 301 515 188 307 515 minecraft:black_concrete
fill 188 301 523 188 307 523 minecraft:black_concrete
fill 188 301 531 188 307 531 minecraft:black_concrete
fill 188 301 539 188 307 539 minecraft:black_concrete
fill 188 301 547 188 307 547 minecraft:black_concrete
fill 191 301 552 191 307 552 minecraft:black_concrete
fill 195 301 510 195 307 510 minecraft:black_concrete
fill 199 301 552 199 307 552 minecraft:black_concrete
fill 203 301 510 203 307 510 minecraft:black_concrete
fill 207 301 552 207 307 552 minecraft:black_concrete
fill 211 301 510 211 307 510 minecraft:black_concrete
fill 215 301 552 215 307 552 minecraft:black_concrete
fill 219 301 510 219 307 510 minecraft:black_concrete
fill 223 301 552 223 307 552 minecraft:black_concrete
fill 227 301 510 227 307 510 minecraft:black_concrete
fill 230 301 515 230 307 515 minecraft:black_concrete
fill 230 301 523 230 307 523 minecraft:black_concrete
fill 230 301 531 230 307 531 minecraft:black_concrete
fill 230 301 539 230 307 539 minecraft:black_concrete
fill 230 301 547 230 307 547 minecraft:black_concrete
