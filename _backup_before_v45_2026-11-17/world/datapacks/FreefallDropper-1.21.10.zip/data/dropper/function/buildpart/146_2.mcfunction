fill 136 265 612 136 307 612 minecraft:obsidian
setblock 94 266 616 minecraft:amethyst_block
setblock 95 266 646 minecraft:amethyst_block
setblock 131 266 604 minecraft:amethyst_block
fill 94 267 616 94 271 616 minecraft:obsidian
setblock 94 267 633 minecraft:amethyst_block
fill 95 267 646 95 307 646 minecraft:obsidian
setblock 103 267 604 minecraft:amethyst_block
fill 104 267 604 104 292 604 minecraft:obsidian
setblock 110 267 646 minecraft:crying_obsidian
setblock 120 267 646 minecraft:white_concrete
fill 131 267 604 131 307 604 minecraft:obsidian
setblock 136 267 607 minecraft:amethyst_block
setblock 136 267 637 minecraft:crying_obsidian
fill 94 268 633 94 289 633 minecraft:obsidian
setblock 94 268 638 minecraft:amethyst_block
setblock 103 268 604 minecraft:obsidian
fill 110 268 646 110 278 646 minecraft:obsidian
fill 120 268 646 120 307 646 minecraft:obsidian
setblock 121 268 646 minecraft:crying_obsidian
fill 136 268 607 136 291 607 minecraft:obsidian
fill 136 268 637 136 306 637 minecraft:obsidian
setblock 136 268 644 minecraft:white_concrete
setblock 94 269 614 minecraft:amethyst_block
fill 94 269 638 94 292 638 minecraft:obsidian
setblock 103 269 604 minecraft:amethyst_block
fill 121 269 646 121 307 646 minecraft:obsidian
setblock 136 269 644 minecraft:obsidian
fill 94 270 612 94 272 612 minecraft:purple_stained_glass
fill 94 270 614 94 272 614 minecraft:obsidian
setblock 94 270 617 minecraft:amethyst_block
fill 94 270 628 94 272 628 minecraft:purple_stained_glass
setblock 94 270 636 minecraft:amethyst_block
setblock 94 270 637 minecraft:obsidian
fill 94 270 644 94 272 644 minecraft:purple_stained_glass
fill 98 270 604 98 272 604 minecraft:purple_stained_glass
fill 103 270 604 103 285 604 minecraft:obsidian
setblock 105 270 604 minecraft:crying_obsidian
setblock 107 270 646 minecraft:amethyst_block
fill 108 270 646 108 272 646 minecraft:purple_stained_glass
fill 114 270 604 114 272 604 minecraft:purple_stained_glass
setblock 117 270 604 minecraft:amethyst_block
fill 124 270 646 124 272 646 minecraft:purple_stained_glass
fill 126 270 633 127 271 633 minecraft:end_stone
fill 130 270 604 130 272 604 minecraft:purple_stained_glass
fill 136 270 614 136 272 614 minecraft:purple_stained_glass
fill 136 270 630 136 272 630 minecraft:purple_stained_glass
setblock 136 270 644 minecraft:crying_obsidian
setblock 94 271 617 minecraft:obsidian
setblock 94 271 622 minecraft:crying_obsidian
fill 94 271 636 94 277 636 minecraft:obsidian
setblock 94 271 637 minecraft:crying_obsidian
setblock 97 271 607 minecraft:light[level=14]
setblock 97 271 615 minecraft:light[level=14]
setblock 97 271 623 minecraft:light[level=14]
setblock 97 271 631 minecraft:light[level=14]
setblock 97 271 639 minecraft:light[level=14]
fill 105 271 604 105 307 604 minecraft:obsidian
setblock 105 271 607 minecraft:light[level=14]
setblock 105 271 615 minecraft:light[level=14]
setblock 105 271 623 minecraft:light[level=14]
setblock 105 271 631 minecraft:light[level=14]
setblock 105 271 639 minecraft:light[level=14]
fill 107 271 646 107 286 646 minecraft:obsidian
setblock 113 271 607 minecraft:light[level=14]
setblock 113 271 615 minecraft:light[level=14]
setblock 113 271 623 minecraft:light[level=14]
setblock 113 271 631 minecraft:light[level=14]
setblock 113 271 639 minecraft:light[level=14]
fill 117 271 604 117 294 604 minecraft:obsidian
setblock 121 271 607 minecraft:light[level=14]
setblock 121 271 615 minecraft:light[level=14]
setblock 121 271 623 minecraft:light[level=14]
setblock 121 271 631 minecraft:light[level=14]
setblock 121 271 639 minecraft:light[level=14]
setblock 129 271 607 minecraft:light[level=14]
setblock 129 271 615 minecraft:light[level=14]
setblock 129 271 623 minecraft:light[level=14]
setblock 129 271 631 minecraft:light[level=14]
setblock 129 271 639 minecraft:light[level=14]
setblock 136 271 618 minecraft:crying_obsidian
fill 136 271 644 136 276 644 minecraft:obsidian
setblock 94 272 616 minecraft:amethyst_block
setblock 94 272 617 minecraft:white_concrete
fill 94 272 622 94 294 622 minecraft:obsidian
fill 94 272 637 94 307 637 minecraft:obsidian
fill 97 272 623 98 273 627 minecraft:obsidian
fill 98 272 619 98 273 622 minecraft:obsidian
fill 98 272 628 98 273 631 minecraft:obsidian
fill 99 272 617 99 273 619 minecraft:obsidian
fill 99 272 631 99 273 633 minecraft:obsidian
fill 100 272 615 100 273 617 minecraft:obsidian
fill 100 272 633 100 273 635 minecraft:obsidian
fill 101 272 614 101 273 615 minecraft:obsidian
fill 101 272 635 101 273 636 minecraft:obsidian
fill 102 272 613 102 273 614 minecraft:obsidian
fill 102 272 636 102 273 637 minecraft:obsidian
fill 103 272 612 103 273 613 minecraft:obsidian
fill 103 272 637 103 273 638 minecraft:obsidian
fill 104 272 611 104 273 612 minecraft:obsidian
fill 104 272 638 104 273 639 minecraft:obsidian
fill 105 272 610 105 273 611 minecraft:obsidian
fill 105 272 639 105 273 640 minecraft:obsidian
fill 106 272 610 107 273 610 minecraft:obsidian
fill 106 272 640 107 273 640 minecraft:obsidian
fill 107 272 609 109 273 609 minecraft:obsidian
fill 107 272 641 109 273 641 minecraft:obsidian
fill 109 272 608 121 273 608 minecraft:obsidian
fill 109 272 642 121 273 642 minecraft:obsidian
fill 113 272 607 117 273 607 minecraft:obsidian
fill 113 272 643 117 273 643 minecraft:obsidian
fill 121 272 609 123 273 609 minecraft:obsidian
fill 121 272 641 123 273 641 minecraft:obsidian
fill 123 272 610 125 273 610 minecraft:obsidian
fill 123 272 640 125 273 640 minecraft:obsidian
setblock 123 272 646 minecraft:amethyst_block
fill 125 272 611 126 273 611 minecraft:obsidian
fill 125 272 639 126 273 639 minecraft:obsidian
fill 126 272 612 127 273 612 minecraft:obsidian
fill 126 272 638 127 273 638 minecraft:obsidian
fill 127 272 613 128 273 613 minecraft:obsidian
fill 127 272 637 128 273 637 minecraft:obsidian
fill 128 272 614 129 273 614 minecraft:obsidian
fill 128 272 636 129 273 636 minecraft:obsidian
fill 129 272 615 130 273 615 minecraft:obsidian
fill 129 272 635 130 273 635 minecraft:obsidian
fill 130 272 616 130 273 617 minecraft:obsidian
fill 130 272 633 130 273 634 minecraft:obsidian
fill 130 272 646 130 307 646 minecraft:obsidian
fill 131 272 617 131 273 619 minecraft:obsidian
fill 131 272 631 131 273 633 minecraft:obsidian
setblock 131 272 646 minecraft:white_concrete
fill 132 272 619 132 273 631 minecraft:obsidian
fill 133 272 623 133 273 627 minecraft:obsidian
fill 136 272 618 136 299 618 minecraft:obsidian
fill 94 273 612 94 287 612 minecraft:obsidian
setblock 94 273 614 minecraft:amethyst_block
fill 94 273 616 94 307 617 minecraft:obsidian
fill 94 273 628 94 287 628 minecraft:obsidian
fill 94 273 644 94 287 644 minecraft:obsidian
fill 98 273 604 98 278 604 minecraft:obsidian
fill 108 273 646 108 287 646 minecraft:obsidian
setblock 109 273 604 minecraft:amethyst_block
fill 110 273 604 110 295 604 minecraft:obsidian
fill 114 273 604 114 287 604 minecraft:obsidian
fill 123 273 646 124 287 646 minecraft:obsidian
fill 130 273 604 130 287 604 minecraft:obsidian
fill 131 273 646 131 290 646 minecraft:obsidian
setblock 136 273 605 minecraft:amethyst_block
fill 136 273 614 136 287 614 minecraft:obsidian
fill 136 273 630 136 287 630 minecraft:obsidian
fill 94 274 614 94 302 614 minecraft:obsidian
fill 109 274 604 109 307 604 minecraft:obsidian
fill 136 274 605 136 287 605 minecraft:obsidian
setblock 136 274 628 minecraft:amethyst_block
setblock 99 275 646 minecraft:amethyst_block
setblock 102 275 646 minecraft:amethyst_block
setblock 127 275 604 minecraft:crying_obsidian
fill 136 275 628 136 307 628 minecraft:obsidian
setblock 136 275 631 minecraft:crying_obsidian
setblock 94 276 608 minecraft:crying_obsidian
setblock 94 276 623 minecraft:crying_obsidian
setblock 96 276 646 minecraft:white_concrete
setblock 97 276 646 minecraft:obsidian
fill 99 276 646 99 307 646 minecraft:obsidian
fill 102 276 646 102 307 646 minecraft:obsidian
fill 127 276 604 127 307 604 minecraft:obsidian
setblock 136 276 608 minecraft:crying_obsidian
fill 136 276 631 136 296 631 minecraft:obsidian
fill 94 277 608 94 307 608 minecraft:obsidian
setblock 94 277 609 minecraft:amethyst_block
fill 94 277 623 94 286 623 minecraft:obsidian
setblock 94 277 641 minecraft:amethyst_block
fill 96 277 646 96 307 646 minecraft:obsidian
setblock 97 277 646 minecraft:amethyst_block
setblock 125 277 646 minecraft:amethyst_block
fill 136 277 608 136 280 608 minecraft:obsidian
setblock 136 277 644 minecraft:white_concrete
fill 94 278 609 94 307 609 minecraft:obsidian
setblock 94 278 636 minecraft:crying_obsidian
fill 94 278 641 94 283 641 minecraft:obsidian
fill 97 278 646 97 307 646 minecraft:obsidian
fill 111 278 623 113 278 625 minecraft:redstone_block
fill 112 278 630 114 278 632 minecraft:redstone_block
fill 118 278 622 120 278 624 minecraft:redstone_block
fill 119 278 629 121 278 631 minecraft:redstone_block
fill 125 278 646 125 300 646 minecraft:obsidian
setblock 136 278 635 minecraft:crying_obsidian
fill 136 278 644 136 299 644 minecraft:obsidian
setblock 94 279 625 minecraft:white_concrete
setblock 94 279 632 minecraft:crying_obsidian
fill 94 279 636 94 298 636 minecraft:obsidian
setblock 97 279 607 minecraft:light[level=14]
setblock 97 279 615 minecraft:light[level=14]
setblock 97 279 623 minecraft:light[level=14]
setblock 97 279 631 minecraft:light[level=14]
setblock 97 279 639 minecraft:light[level=14]
setblock 98 279 604 minecraft:white_concrete
fill 104 279 615 105 279 639 minecraft:obsidian
setblock 105 279 607 minecraft:light[level=14]
fill 106 279 615 128 279 616 minecraft:obsidian
fill 106 279 617 110 279 637 minecraft:purple_stained_glass
fill 106 279 638 128 279 639 minecraft:obsidian
setblock 110 279 646 minecraft:crying_obsidian
fill 111 279 617 117 279 622 minecraft:purple_stained_glass
fill 111 279 626 111 279 637 minecraft:purple_stained_glass
fill 112 279 626 114 279 629 minecraft:purple_stained_glass
fill 112 279 633 126 279 637 minecraft:purple_stained_glass
setblock 113 279 607 minecraft:light[level=14]
setblock 113 279 623 minecraft:light[level=14]
setblock 113 279 631 minecraft:light[level=14]
fill 114 279 623 117 279 625 minecraft:purple_stained_glass
fill 115 279 629 118 279 632 minecraft:purple_stained_glass
fill 118 279 617 126 279 621 minecraft:purple_stained_glass
fill 118 279 625 126 279 628 minecraft:purple_stained_glass
fill 119 279 632 126 279 632 minecraft:purple_stained_glass
setblock 121 279 607 minecraft:light[level=14]
fill 121 279 622 126 279 624 minecraft:purple_stained_glass
setblock 121 279 631 minecraft:light[level=14]
fill 122 279 629 126 279 631 minecraft:purple_stained_glass
fill 127 279 617 128 279 637 minecraft:obsidian
setblock 129 279 607 minecraft:light[level=14]
setblock 129 279 615 minecraft:light[level=14]
setblock 129 279 623 minecraft:light[level=14]
setblock 129 279 631 minecraft:light[level=14]
setblock 129 279 639 minecraft:light[level=14]
fill 136 279 635 136 305 635 minecraft:obsidian
fill 94 280 625 94 297 625 minecraft:obsidian
fill 94 280 632 94 307 632 minecraft:obsidian
setblock 94 280 635 minecraft:crying_obsidian
setblock 94 280 639 minecraft:white_concrete
fill 95 280 605 103 280 645 minecraft:netherrack
fill 98 280 604 98 287 604 minecraft:obsidian
fill 104 280 605 135 280 614 minecraft:netherrack
fill 104 280 615 104 280 617 minecraft:obsidian
setblock 104 280 618 minecraft:crying_obsidian
fill 104 280 619 104 280 621 minecraft:obsidian
setblock 104 280 622 minecraft:crying_obsidian
fill 104 280 623 104 280 625 minecraft:obsidian
setblock 104 280 626 minecraft:crying_obsidian
fill 104 280 627 104 280 629 minecraft:obsidian
setblock 104 280 630 minecraft:crying_obsidian
fill 104 280 631 104 280 633 minecraft:obsidian
setblock 104 280 634 minecraft:crying_obsidian
fill 104 280 635 104 280 637 minecraft:obsidian
setblock 104 280 638 minecraft:crying_obsidian
fill 104 280 639 106 280 639 minecraft:obsidian
fill 104 280 640 135 280 645 minecraft:netherrack
setblock 104 280 646 minecraft:amethyst_block
fill 105 280 615 105 284 616 minecraft:obsidian
setblock 105 280 617 minecraft:crying_obsidian
fill 105 280 618 105 280 620 minecraft:obsidian
setblock 105 280 621 minecraft:crying_obsidian
fill 105 280 622 105 280 624 minecraft:obsidian
setblock 105 280 625 minecraft:crying_obsidian
fill 105 280 626 105 280 628 minecraft:obsidian
setblock 105 280 629 minecraft:crying_obsidian
fill 105 280 630 105 280 632 minecraft:obsidian
setblock 105 280 633 minecraft:crying_obsidian
fill 105 280 634 105 280 636 minecraft:obsidian
setblock 105 280 637 minecraft:crying_obsidian
fill 105 280 638 107 280 638 minecraft:obsidian
setblock 106 280 615 minecraft:obsidian
setblock 106 280 616 minecraft:crying_obsidian
fill 106 280 617 109 280 637 minecraft:purple_stained_glass
setblock 107 280 615 minecraft:crying_obsidian
fill 107 280 616 109 280 616 minecraft:obsidian
setblock 107 280 639 minecraft:crying_obsidian
fill 108 280 615 110 280 615 minecraft:obsidian
setblock 108 280 638 minecraft:crying_obsidian
fill 108 280 639 110 280 639 minecraft:obsidian
fill 109 280 638 111 280 638 minecraft:obsidian
setblock 110 280 616 minecraft:crying_obsidian
fill 110 280 617 116 280 621 minecraft:purple_stained_glass
fill 110 280 622 110 280 626 minecraft:crying_obsidian
fill 110 280 627 110 280 637 minecraft:purple_stained_glass
fill 110 280 646 110 307 646 minecraft:obsidian
setblock 111 280 615 minecraft:crying_obsidian
fill 111 280 616 113 280 616 minecraft:obsidian
fill 111 280 622 114 280 622 minecraft:crying_obsidian
fill 111 280 623 113 280 625 minecraft:netherrack
fill 111 280 626 114 280 626 minecraft:crying_obsidian
fill 111 280 627 113 280 628 minecraft:purple_stained_glass
fill 111 280 629 111 280 633 minecraft:crying_obsidian
fill 111 280 634 126 280 637 minecraft:purple_stained_glass
setblock 111 280 639 minecraft:crying_obsidian
fill 112 280 615 114 280 615 minecraft:obsidian
fill 112 280 629 118 280 629 minecraft:crying_obsidian
fill 112 280 630 114 280 632 minecraft:netherrack
fill 112 280 633 115 280 633 minecraft:crying_obsidian
setblock 112 280 638 minecraft:crying_obsidian
fill 112 280 639 114 280 639 minecraft:obsidian
fill 113 280 638 115 280 638 minecraft:obsidian
setblock 114 280 616 minecraft:crying_obsidian
fill 114 280 623 114 280 625 minecraft:crying_obsidian
fill 114 280 627 114 280 628 minecraft:crying_obsidian
setblock 115 280 615 minecraft:crying_obsidian
fill 115 280 616 117 280 616 minecraft:obsidian
fill 115 280 622 116 280 624 minecraft:purple_stained_glass
fill 115 280 625 121 280 625 minecraft:crying_obsidian
fill 115 280 630 115 280 632 minecraft:crying_obsidian
setblock 115 280 639 minecraft:crying_obsidian
fill 116 280 615 118 280 615 minecraft:obsidian
fill 116 280 630 117 280 633 minecraft:purple_stained_glass
setblock 116 280 638 minecraft:crying_obsidian
fill 116 280 639 118 280 639 minecraft:obsidian
fill 117 280 617 126 280 620 minecraft:purple_stained_glass
fill 117 280 621 117 280 624 minecraft:crying_obsidian
fill 117 280 638 119 280 638 minecraft:obsidian
setblock 118 280 616 minecraft:crying_obsidian
fill 118 280 621 121 280 621 minecraft:crying_obsidian
fill 118 280 622 120 280 624 minecraft:netherrack
fill 118 280 626 118 280 628 minecraft:crying_obsidian
fill 118 280 630 118 280 632 minecraft:crying_obsidian
fill 118 280 633 126 280 633 minecraft:purple_stained_glass
setblock 119 280 615 minecraft:crying_obsidian
fill 119 280 616 121 280 616 minecraft:obsidian
fill 119 280 626 126 280 627 minecraft:purple_stained_glass
fill 119 280 628 122 280 628 minecraft:crying_obsidian
fill 119 280 629 121 280 631 minecraft:netherrack
fill 119 280 632 122 280 632 minecraft:crying_obsidian
setblock 119 280 639 minecraft:crying_obsidian
fill 120 280 615 122 280 615 minecraft:obsidian
setblock 120 280 638 minecraft:crying_obsidian
fill 120 280 639 122 280 639 minecraft:obsidian
fill 121 280 622 121 280 624 minecraft:crying_obsidian
fill 121 280 638 123 280 638 minecraft:obsidian
setblock 122 280 616 minecraft:crying_obsidian
fill 122 280 621 126 280 625 minecraft:purple_stained_glass
fill 122 280 629 122 280 631 minecraft:crying_obsidian
setblock 123 280 615 minecraft:crying_obsidian
fill 123 280 616 125 280 616 minecraft:obsidian
fill 123 280 628 126 280 632 minecraft:purple_stained_glass
setblock 123 280 639 minecraft:crying_obsidian
fill 124 280 615 126 280 615 minecraft:obsidian
setblock 124 280 638 minecraft:crying_obsidian
fill 124 280 639 126 280 639 minecraft:obsidian
fill 125 280 638 127 280 638 minecraft:obsidian
setblock 126 280 616 minecraft:crying_obsidian
setblock 127 280 615 minecraft:crying_obsidian
fill 127 280 616 127 280 618 minecraft:obsidian
setblock 127 280 619 minecraft:crying_obsidian
fill 127 280 620 127 280 622 minecraft:obsidian
setblock 127 280 623 minecraft:crying_obsidian
fill 127 280 624 127 280 626 minecraft:obsidian
setblock 127 280 627 minecraft:crying_obsidian
fill 127 280 628 127 280 630 minecraft:obsidian
setblock 127 280 631 minecraft:crying_obsidian
fill 127 280 632 127 280 634 minecraft:obsidian
setblock 127 280 635 minecraft:crying_obsidian
fill 127 280 636 128 280 637 minecraft:obsidian
setblock 127 280 639 minecraft:crying_obsidian
fill 128 280 615 128 280 617 minecraft:obsidian
setblock 128 280 618 minecraft:crying_obsidian
fill 128 280 619 128 280 621 minecraft:obsidian
setblock 128 280 622 minecraft:crying_obsidian
fill 128 280 623 128 280 625 minecraft:obsidian
setblock 128 280 626 minecraft:crying_obsidian
fill 128 280 627 128 280 629 minecraft:obsidian
setblock 128 280 630 minecraft:crying_obsidian
fill 128 280 631 128 280 633 minecraft:obsidian
setblock 128 280 634 minecraft:crying_obsidian
setblock 128 280 635 minecraft:obsidian
setblock 128 280 638 minecraft:crying_obsidian
setblock 128 280 639 minecraft:obsidian
fill 129 280 615 135 280 639 minecraft:netherrack
fill 94 281 635 94 282 635 minecraft:obsidian
fill 94 281 639 94 307 639 minecraft:obsidian
fill 104 281 616 104 284 616 minecraft:obsidian
fill 104 281 638 106 284 638 minecraft:obsidian
fill 104 281 646 104 301 646 minecraft:obsidian
fill 105 281 617 105 284 617 minecraft:obsidian
fill 105 281 637 105 284 637 minecraft:obsidian
fill 105 281 639 105 284 639 minecraft:obsidian
fill 106 281 616 106 284 616 minecraft:obsidian
setblock 111 281 604 minecraft:amethyst_block
fill 126 281 616 128 284 616 minecraft:obsidian
fill 126 281 638 128 284 638 minecraft:obsidian
fill 127 281 615 127 284 615 minecraft:obsidian
fill 127 281 617 127 284 617 minecraft:obsidian
fill 127 281 637 127 284 637 minecraft:obsidian
fill 127 281 639 127 284 639 minecraft:obsidian
setblock 133 281 604 minecraft:white_concrete
setblock 136 281 608 minecraft:crying_obsidian
fill 111 282 604 111 307 604 minecraft:obsidian
setblock 125 282 604 minecraft:amethyst_block
fill 133 282 604 133 307 604 minecraft:obsidian
fill 136 282 608 136 293 608 minecraft:obsidian
setblock 136 282 623 minecraft:crying_obsidian
setblock 94 283 635 minecraft:crying_obsidian
setblock 96 283 604 minecraft:crying_obsidian
fill 125 283 604 125 307 604 minecraft:obsidian
fill 136 283 623 136 307 623 minecraft:obsidian
fill 94 284 635 94 307 635 minecraft:obsidian
setblock 94 284 641 minecraft:white_concrete
fill 96 284 604 96 302 604 minecraft:obsidian
setblock 136 284 633 minecraft:white_concrete
setblock 136 284 639 minecraft:amethyst_block
fill 94 285 641 94 307 641 minecraft:obsidian
fill 106 285 624 108 286 624 minecraft:netherrack
fill 107 285 623 107 286 623 minecraft:netherrack
fill 107 285 625 107 286 625 minecraft:netherrack
setblock 126 285 646 minecraft:amethyst_block
fill 136 285 633 136 307 633 minecraft:obsidian
fill 136 285 639 136 307 639 minecraft:obsidian
setblock 136 285 645 minecraft:crying_obsidian
setblock 103 286 604 minecraft:crying_obsidian
setblock 113 286 646 minecraft:amethyst_block
setblock 115 286 604 minecraft:crying_obsidian
setblock 121 286 604 minecraft:amethyst_block
setblock 124 286 604 minecraft:crying_obsidian
fill 126 286 646 126 288 646 minecraft:obsidian
setblock 136 286 617 minecraft:amethyst_block
fill 136 286 645 136 292 645 minecraft:obsidian
setblock 94 287 623 minecraft:amethyst_block
setblock 97 287 607 minecraft:light[level=14]
setblock 97 287 615 minecraft:light[level=14]
setblock 97 287 623 minecraft:light[level=14]
setblock 97 287 631 minecraft:light[level=14]
setblock 97 287 639 minecraft:light[level=14]
fill 103 287 604 103 304 604 minecraft:obsidian
setblock 105 287 607 minecraft:light[level=14]
setblock 105 287 615 minecraft:light[level=14]
setblock 105 287 623 minecraft:light[level=14]
setblock 105 287 631 minecraft:light[level=14]
setblock 105 287 639 minecraft:light[level=14]
setblock 107 287 646 minecraft:amethyst_block
setblock 113 287 607 minecraft:light[level=14]
setblock 113 287 615 minecraft:light[level=14]
setblock 113 287 623 minecraft:light[level=14]
setblock 113 287 631 minecraft:light[level=14]
setblock 113 287 639 minecraft:light[level=14]
fill 113 287 646 113 307 646 minecraft:obsidian
fill 115 287 604 115 307 604 minecraft:obsidian
fill 121 287 604 121 307 604 minecraft:obsidian
setblock 121 287 607 minecraft:light[level=14]
setblock 121 287 615 minecraft:light[level=14]
setblock 121 287 623 minecraft:light[level=14]
setblock 121 287 631 minecraft:light[level=14]
setblock 121 287 639 minecraft:light[level=14]
fill 124 287 604 124 303 604 minecraft:obsidian
setblock 129 287 607 minecraft:light[level=14]
setblock 129 287 615 minecraft:light[level=14]
setblock 129 287 623 minecraft:light[level=14]
setblock 129 287 631 minecraft:light[level=14]
setblock 129 287 639 minecraft:light[level=14]
fill 136 287 617 136 307 617 minecraft:obsidian
fill 94 288 612 94 290 612 minecraft:purple_stained_glass
fill 94 288 623 94 307 623 minecraft:obsidian
fill 94 288 628 94 290 628 minecraft:purple_stained_glass
fill 94 288 644 94 290 644 minecraft:purple_stained_glass
fill 98 288 604 98 290 604 minecraft:purple_stained_glass
fill 107 288 646 107 307 646 minecraft:obsidian
fill 108 288 646 108 290 646 minecraft:purple_stained_glass
fill 114 288 604 114 290 604 minecraft:purple_stained_glass
fill 123 288 646 123 304 646 minecraft:obsidian
fill 124 288 646 124 290 646 minecraft:purple_stained_glass
fill 130 288 604 130 290 604 minecraft:purple_stained_glass
setblock 136 288 605 minecraft:crying_obsidian
fill 136 288 614 136 290 614 minecraft:purple_stained_glass
fill 136 288 630 136 290 630 minecraft:purple_stained_glass
setblock 94 289 615 minecraft:crying_obsidian
setblock 94 289 626 minecraft:white_concrete
fill 95 289 630 96 292 632 minecraft:amethyst_block
setblock 126 289 646 minecraft:amethyst_block
fill 136 289 605 136 291 605 minecraft:obsidian
setblock 136 289 638 minecraft:crying_obsidian
fill 94 290 615 94 307 615 minecraft:obsidian
fill 94 290 626 94 307 626 minecraft:obsidian
setblock 94 290 633 minecraft:white_concrete
fill 95 290 629 95 291 629 minecraft:amethyst_block
fill 95 290 633 95 291 633 minecraft:amethyst_block
fill 97 290 630 97 292 632 minecraft:amethyst_block
fill 126 290 646 126 307 646 minecraft:obsidian
fill 136 290 638 136 307 638 minecraft:obsidian
fill 94 291 612 94 296 612 minecraft:obsidian
fill 94 291 628 94 296 628 minecraft:obsidian
fill 94 291 633 94 307 633 minecraft:obsidian
fill 94 291 644 94 296 644 minecraft:obsidian
setblock 94 291 645 minecraft:crying_obsidian
fill 94 291 646 94 307 646 minecraft:obsidian
fill 98 291 604 98 296 604 minecraft:obsidian
fill 98 291 631 98 293 631 minecraft:amethyst_block
setblock 102 291 604 minecraft:amethyst_block
fill 108 291 646 108 296 646 minecraft:obsidian
fill 114 291 604 114 296 604 minecraft:obsidian
fill 124 291 646 124 296 646 minecraft:obsidian
fill 130 291 604 130 296 604 minecraft:obsidian
setblock 131 291 646 minecraft:white_concrete
fill 136 291 614 136 296 614 minecraft:obsidian
fill 136 291 630 136 296 630 minecraft:obsidian
fill 94 292 645 94 299 645 minecraft:obsidian
setblock 98 292 630 minecraft:amethyst_block
setblock 98 292 632 minecraft:amethyst_block
fill 99 292 631 99 293 631 minecraft:amethyst_block
fill 102 292 604 102 307 604 minecraft:obsidian
fill 120 292 635 121 293 636 minecraft:netherrack
fill 131 292 646 131 307 646 minecraft:obsidian
setblock 136 292 605 minecraft:amethyst_block
setblock 136 292 607 minecraft:crying_obsidian
setblock 94 293 607 minecraft:white_concrete
setblock 94 293 638 minecraft:white_concrete
fill 96 293 631 97 293 631 minecraft:amethyst_block
setblock 100 293 631 minecraft:amethyst_block
setblock 104 293 604 minecraft:amethyst_block
setblock 132 293 646 minecraft:white_concrete
fill 136 293 605 136 307 605 minecraft:obsidian
fill 136 293 607 136 307 607 minecraft:obsidian
setblock 136 293 610 minecraft:crying_obsidian
setblock 136 293 645 minecraft:crying_obsidian
fill 94 294 607 94 307 607 minecraft:obsidian
fill 94 294 638 94 307 638 minecraft:obsidian
fill 104 294 604 104 307 604 minecraft:obsidian
fill 132 294 646 132 307 646 minecraft:obsidian
setblock 136 294 608 minecraft:amethyst_block
fill 136 294 610 136 307 610 minecraft:obsidian
setblock 136 294 616 minecraft:crying_obsidian
fill 136 294 645 136 307 645 minecraft:obsidian
setblock 94 295 622 minecraft:crying_obsidian
setblock 97 295 607 minecraft:light[level=14]
setblock 97 295 615 minecraft:light[level=14]
setblock 97 295 623 minecraft:light[level=14]
setblock 97 295 631 minecraft:light[level=14]
setblock 97 295 639 minecraft:light[level=14]
setblock 105 295 607 minecraft:light[level=14]
setblock 105 295 615 minecraft:light[level=14]
setblock 105 295 623 minecraft:light[level=14]
setblock 105 295 631 minecraft:light[level=14]
setblock 105 295 639 minecraft:light[level=14]
setblock 113 295 607 minecraft:light[level=14]
setblock 113 295 615 minecraft:light[level=14]
setblock 113 295 623 minecraft:light[level=14]
setblock 113 295 631 minecraft:light[level=14]
setblock 113 295 639 minecraft:light[level=14]
setblock 117 295 604 minecraft:crying_obsidian
setblock 121 295 607 minecraft:light[level=14]
setblock 121 295 615 minecraft:light[level=14]
setblock 121 295 623 minecraft:light[level=14]
setblock 121 295 631 minecraft:light[level=14]
setblock 121 295 639 minecraft:light[level=14]
setblock 129 295 607 minecraft:light[level=14]
setblock 129 295 615 minecraft:light[level=14]
setblock 129 295 623 minecraft:light[level=14]
setblock 129 295 631 minecraft:light[level=14]
setblock 129 295 639 minecraft:light[level=14]
fill 136 295 608 136 307 608 minecraft:obsidian
fill 136 295 616 136 307 616 minecraft:obsidian
fill 94 296 622 94 307 622 minecraft:obsidian
setblock 110 296 604 minecraft:amethyst_block
fill 117 296 604 117 307 604 minecraft:obsidian
setblock 94 297 610 minecraft:amethyst_block
fill 94 297 612 94 299 612 minecraft:purple_stained_glass
fill 94 297 628 94 299 628 minecraft:purple_stained_glass
fill 94 297 644 94 299 644 minecraft:purple_stained_glass
fill 98 297 604 98 299 604 minecraft:purple_stained_glass
fill 108 297 646 108 299 646 minecraft:purple_stained_glass
fill 110 297 604 110 307 604 minecraft:obsidian
fill 114 297 604 114 299 604 minecraft:purple_stained_glass
fill 124 297 646 124 299 646 minecraft:purple_stained_glass
fill 130 297 604 130 299 604 minecraft:purple_stained_glass
fill 136 297 614 136 299 614 minecraft:purple_stained_glass
fill 136 297 630 136 299 630 minecraft:purple_stained_glass
setblock 136 297 631 minecraft:amethyst_block
fill 94 298 610 94 307 610 minecraft:obsidian
setblock 94 298 625 minecraft:amethyst_block
setblock 94 298 634 minecraft:white_concrete
fill 136 298 631 136 301 631 minecraft:obsidian
fill 94 299 625 94 307 625 minecraft:obsidian
fill 94 299 634 94 307 634 minecraft:obsidian
setblock 94 299 636 minecraft:crying_obsidian
fill 94 300 612 94 307 612 minecraft:obsidian
fill 94 300 628 94 307 628 minecraft:obsidian
fill 94 300 636 94 307 636 minecraft:obsidian
fill 94 300 644 94 307 644 minecraft:obsidian
setblock 94 300 645 minecraft:white_concrete
fill 98 300 604 98 307 604 minecraft:obsidian
setblock 101 300 646 minecraft:crying_obsidian
fill 108 300 646 108 305 646 minecraft:obsidian
fill 114 300 604 114 307 604 minecraft:obsidian
fill 124 300 646 124 307 646 minecraft:obsidian
fill 130 300 604 130 307 604 minecraft:obsidian
fill 136 300 614 136 307 614 minecraft:obsidian
setblock 136 300 618 minecraft:amethyst_block
fill 136 300 630 136 307 630 minecraft:obsidian
setblock 136 300 644 minecraft:crying_obsidian
fill 94 301 645 94 307 645 minecraft:obsidian
fill 101 301 646 101 305 646 minecraft:obsidian
setblock 122 301 604 minecraft:white_concrete
setblock 125 301 646 minecraft:crying_obsidian
fill 136 301 618 136 307 618 minecraft:obsidian
fill 136 301 644 136 307 644 minecraft:obsidian
setblock 104 302 646 minecraft:crying_obsidian
fill 122 302 604 122 307 604 minecraft:obsidian
fill 125 302 646 125 307 646 minecraft:obsidian
setblock 129 302 646 minecraft:crying_obsidian
setblock 136 302 626 minecraft:amethyst_block
setblock 136 302 631 minecraft:amethyst_block
setblock 94 303 614 minecraft:crying_obsidian
setblock 94 303 619 minecraft:crying_obsidian
setblock 96 303 604 minecraft:amethyst_block
setblock 97 303 607 minecraft:light[level=14]
setblock 97 303 615 minecraft:light[level=14]
setblock 97 303 623 minecraft:light[level=14]
setblock 97 303 631 minecraft:light[level=14]
setblock 97 303 639 minecraft:light[level=14]
fill 104 303 646 104 307 646 minecraft:obsidian
setblock 105 303 607 minecraft:light[level=14]
setblock 105 303 615 minecraft:light[level=14]
setblock 105 303 623 minecraft:light[level=14]
setblock 105 303 631 minecraft:light[level=14]
setblock 105 303 639 minecraft:light[level=14]
setblock 113 303 607 minecraft:light[level=14]
setblock 113 303 615 minecraft:light[level=14]
setblock 113 303 623 minecraft:light[level=14]
setblock 113 303 631 minecraft:light[level=14]
setblock 113 303 639 minecraft:light[level=14]
setblock 121 303 607 minecraft:light[level=14]
setblock 121 303 615 minecraft:light[level=14]
setblock 121 303 623 minecraft:light[level=14]
setblock 121 303 631 minecraft:light[level=14]
setblock 121 303 639 minecraft:light[level=14]
setblock 129 303 607 minecraft:light[level=14]
setblock 129 303 615 minecraft:light[level=14]
setblock 129 303 623 minecraft:light[level=14]
setblock 129 303 631 minecraft:light[level=14]
setblock 129 303 639 minecraft:light[level=14]
fill 129 303 646 129 307 646 minecraft:obsidian
fill 136 303 626 136 307 626 minecraft:obsidian
fill 136 303 631 136 307 631 minecraft:obsidian
fill 94 304 614 94 307 614 minecraft:obsidian
fill 94 304 619 94 307 619 minecraft:obsidian
fill 96 304 604 96 307 604 minecraft:obsidian
setblock 119 304 646 minecraft:white_concrete
setblock 124 304 604 minecraft:white_concrete
setblock 128 304 604 minecraft:white_concrete
setblock 97 305 604 minecraft:amethyst_block
setblock 98 305 646 minecraft:amethyst_block
fill 103 305 604 103 306 604 minecraft:white_concrete
fill 119 305 646 119 307 646 minecraft:obsidian
setblock 123 305 646 minecraft:white_concrete
fill 124 305 604 124 307 604 minecraft:obsidian
fill 128 305 604 128 307 604 minecraft:obsidian
fill 97 306 604 97 307 604 minecraft:obsidian
fill 98 306 646 98 307 646 minecraft:obsidian
setblock 101 306 646 minecraft:white_concrete
setblock 108 306 646 minecraft:white_concrete
fill 123 306 646 123 307 646 minecraft:obsidian
setblock 136 306 635 minecraft:white_concrete
setblock 94 307 630 minecraft:white_concrete
setblock 101 307 646 minecraft:obsidian
setblock 103 307 604 minecraft:obsidian
setblock 108 307 646 minecraft:obsidian
setblock 136 307 635 minecraft:obsidian
setblock 136 307 637 minecraft:amethyst_block
