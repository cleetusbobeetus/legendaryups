setblock 417 163 341 minecraft:gray_concrete
setblock 417 163 342 minecraft:polished_deepslate
fill 417 163 343 417 164 345 minecraft:gray_concrete
setblock 417 163 347 minecraft:polished_deepslate
fill 417 163 348 417 166 348 minecraft:gray_concrete
setblock 417 163 352 minecraft:polished_deepslate
fill 417 163 353 417 166 353 minecraft:gray_concrete
setblock 417 163 357 minecraft:polished_deepslate
fill 417 163 358 417 166 358 minecraft:gray_concrete
setblock 417 163 362 minecraft:polished_deepslate
fill 417 163 363 417 166 363 minecraft:gray_concrete
fill 377 164 327 377 167 327 minecraft:gray_concrete
setblock 377 164 330 minecraft:gray_concrete
setblock 377 164 331 minecraft:polished_deepslate
fill 377 164 332 377 167 332 minecraft:gray_concrete
setblock 377 164 336 minecraft:polished_deepslate
fill 377 164 337 377 167 337 minecraft:gray_concrete
setblock 377 164 340 minecraft:gray_concrete
setblock 377 164 341 minecraft:polished_deepslate
fill 377 164 342 377 164 345 minecraft:gray_concrete
setblock 377 164 346 minecraft:polished_deepslate
fill 377 164 347 377 167 347 minecraft:gray_concrete
setblock 377 164 351 minecraft:polished_deepslate
fill 377 164 352 377 167 352 minecraft:gray_concrete
setblock 377 164 356 minecraft:polished_deepslate
fill 377 164 357 377 167 357 minecraft:gray_concrete
setblock 377 164 360 minecraft:gray_concrete
setblock 377 164 361 minecraft:polished_deepslate
fill 377 164 362 380 164 362 minecraft:gray_concrete
setblock 378 164 330 minecraft:polished_deepslate
fill 378 164 331 378 167 331 minecraft:gray_concrete
setblock 378 164 334 minecraft:gray_concrete
setblock 378 164 335 minecraft:polished_deepslate
fill 378 164 336 378 167 336 minecraft:gray_concrete
setblock 378 164 340 minecraft:polished_deepslate
fill 378 164 341 378 167 341 minecraft:gray_concrete
setblock 378 164 345 minecraft:polished_deepslate
fill 378 164 346 378 167 346 minecraft:gray_concrete
setblock 378 164 350 minecraft:polished_deepslate
fill 378 164 351 378 167 351 minecraft:gray_concrete
setblock 378 164 355 minecraft:polished_deepslate
fill 378 164 356 378 167 356 minecraft:gray_concrete
setblock 378 164 360 minecraft:polished_deepslate
fill 378 164 361 378 167 361 minecraft:gray_concrete
setblock 379 164 325 minecraft:light[level=12]
setblock 379 164 334 minecraft:polished_deepslate
fill 379 164 335 379 167 335 minecraft:gray_concrete
setblock 379 164 339 minecraft:polished_deepslate
fill 379 164 340 379 167 340 minecraft:gray_concrete
setblock 379 164 343 minecraft:gray_concrete
setblock 379 164 344 minecraft:polished_deepslate
setblock 379 164 346 minecraft:light[level=12]
setblock 379 164 349 minecraft:polished_deepslate
fill 379 164 350 379 166 350 minecraft:gray_concrete
setblock 379 164 354 minecraft:polished_deepslate
fill 379 164 355 379 167 355 minecraft:gray_concrete
setblock 379 164 359 minecraft:polished_deepslate
fill 379 164 360 379 167 360 minecraft:gray_concrete
setblock 380 164 333 minecraft:polished_deepslate
fill 380 164 334 380 167 334 minecraft:gray_concrete
setblock 380 164 338 minecraft:polished_deepslate
fill 380 164 339 380 167 339 minecraft:gray_concrete
setblock 380 164 363 minecraft:polished_deepslate
fill 381 164 363 382 166 363 minecraft:gray_concrete
fill 382 164 364 382 181 364 minecraft:gray_wool
setblock 386 164 325 minecraft:light[level=12]
setblock 386 164 332 minecraft:light[level=12]
setblock 386 164 339 minecraft:light[level=12]
setblock 386 164 346 minecraft:light[level=12]
setblock 386 164 353 minecraft:light[level=12]
setblock 386 164 360 minecraft:light[level=12]
fill 393 164 323 394 164 323 minecraft:gray_concrete
setblock 393 164 325 minecraft:light[level=12]
setblock 393 164 332 minecraft:light[level=12]
setblock 393 164 339 minecraft:light[level=12]
setblock 393 164 346 minecraft:light[level=12]
setblock 393 164 353 minecraft:light[level=12]
fill 393 164 354 393 165 354 minecraft:white_wool
setblock 393 164 360 minecraft:light[level=12]
fill 393 164 364 393 181 364 minecraft:gray_wool
setblock 394 164 363 minecraft:gray_concrete
setblock 395 164 323 minecraft:polished_deepslate
fill 395 164 324 396 166 324 minecraft:gray_concrete
setblock 395 164 363 minecraft:polished_deepslate
fill 396 164 323 396 167 323 minecraft:gray_concrete
setblock 396 164 362 minecraft:polished_deepslate
fill 396 164 363 396 167 363 minecraft:gray_concrete
fill 397 164 362 400 164 362 minecraft:gray_concrete
fill 398 164 361 401 164 361 minecraft:gray_concrete
setblock 399 164 324 minecraft:polished_deepslate
setblock 400 164 323 minecraft:polished_deepslate
fill 400 164 324 400 167 324 minecraft:gray_concrete
setblock 400 164 325 minecraft:light[level=12]
setblock 400 164 332 minecraft:light[level=12]
setblock 400 164 339 minecraft:light[level=12]
setblock 400 164 346 minecraft:light[level=12]
setblock 400 164 353 minecraft:light[level=12]
setblock 400 164 360 minecraft:light[level=12]
setblock 400 164 363 minecraft:polished_deepslate
fill 401 164 323 401 167 323 minecraft:gray_concrete
setblock 401 164 362 minecraft:polished_deepslate
fill 401 164 363 401 167 363 minecraft:gray_concrete
setblock 402 164 361 minecraft:polished_deepslate
fill 402 164 362 402 167 362 minecraft:gray_concrete
fill 403 164 361 403 167 361 minecraft:gray_concrete
setblock 405 164 323 minecraft:polished_deepslate
setblock 405 164 363 minecraft:polished_deepslate
fill 406 164 323 406 167 323 minecraft:gray_concrete
setblock 406 164 362 minecraft:polished_deepslate
fill 406 164 363 409 164 363 minecraft:gray_concrete
setblock 407 164 325 minecraft:light[level=12]
setblock 407 164 332 minecraft:light[level=12]
setblock 407 164 339 minecraft:light[level=12]
setblock 407 164 346 minecraft:light[level=12]
setblock 407 164 353 minecraft:light[level=12]
setblock 407 164 360 minecraft:light[level=12]
fill 407 164 362 407 167 362 minecraft:gray_concrete
fill 408 164 364 408 185 364 minecraft:gray_wool
setblock 410 164 363 minecraft:polished_deepslate
setblock 411 164 362 minecraft:polished_deepslate
fill 411 164 363 411 167 363 minecraft:gray_concrete
fill 412 164 362 413 166 362 minecraft:gray_concrete
setblock 414 164 325 minecraft:light[level=12]
setblock 414 164 332 minecraft:light[level=12]
setblock 414 164 339 minecraft:light[level=12]
setblock 414 164 346 minecraft:light[level=12]
setblock 414 164 353 minecraft:light[level=12]
setblock 414 164 360 minecraft:light[level=12]
fill 414 164 361 416 164 361 minecraft:gray_concrete
setblock 414 164 363 minecraft:gray_concrete
setblock 415 164 352 minecraft:gray_concrete
setblock 415 164 353 minecraft:polished_deepslate
fill 415 164 354 415 167 354 minecraft:gray_concrete
fill 415 164 356 415 164 357 minecraft:gray_concrete
setblock 415 164 358 minecraft:polished_deepslate
fill 415 164 359 415 167 359 minecraft:gray_concrete
setblock 415 164 363 minecraft:polished_deepslate
fill 415 164 364 415 171 364 minecraft:gray_wool
setblock 416 164 332 minecraft:polished_deepslate
fill 416 164 333 416 167 333 minecraft:gray_concrete
setblock 416 164 336 minecraft:gray_concrete
setblock 416 164 337 minecraft:polished_deepslate
fill 416 164 338 416 165 340 minecraft:gray_concrete
fill 416 164 348 416 167 348 minecraft:gray_concrete
setblock 416 164 352 minecraft:polished_deepslate
fill 416 164 353 416 167 353 minecraft:gray_concrete
setblock 416 164 357 minecraft:polished_deepslate
fill 416 164 358 416 167 358 minecraft:gray_concrete
fill 416 164 360 416 165 360 minecraft:gray_concrete
setblock 416 164 362 minecraft:polished_deepslate
fill 416 164 363 416 167 363 minecraft:gray_concrete
fill 417 164 323 417 166 323 minecraft:gray_concrete
setblock 417 164 331 minecraft:polished_deepslate
fill 417 164 332 417 167 332 minecraft:gray_concrete
setblock 417 164 335 minecraft:gray_concrete
setblock 417 164 336 minecraft:polished_deepslate
fill 417 164 337 417 167 337 minecraft:gray_concrete
setblock 417 164 341 minecraft:polished_deepslate
fill 417 164 342 417 167 342 minecraft:gray_concrete
setblock 417 164 346 minecraft:polished_deepslate
fill 417 164 347 417 167 347 minecraft:gray_concrete
setblock 417 164 351 minecraft:polished_deepslate
fill 417 164 352 417 167 352 minecraft:gray_concrete
setblock 417 164 356 minecraft:polished_deepslate
fill 417 164 357 417 167 357 minecraft:gray_concrete
setblock 417 164 361 minecraft:polished_deepslate
fill 417 164 362 417 167 362 minecraft:gray_concrete
setblock 418 164 339 minecraft:light_blue_stained_glass
setblock 418 164 353 minecraft:light_blue_stained_glass
fill 377 165 323 378 165 323 minecraft:gray_concrete
fill 377 165 326 377 168 326 minecraft:gray_concrete
setblock 377 165 330 minecraft:polished_deepslate
fill 377 165 331 377 168 331 minecraft:gray_concrete
setblock 377 165 335 minecraft:polished_deepslate
fill 377 165 336 377 168 336 minecraft:gray_concrete
setblock 377 165 340 minecraft:polished_deepslate
fill 377 165 341 377 165 344 minecraft:gray_concrete
setblock 377 165 345 minecraft:polished_deepslate
fill 377 165 346 377 168 346 minecraft:gray_concrete
setblock 377 165 350 minecraft:polished_deepslate
fill 377 165 351 377 168 351 minecraft:gray_concrete
setblock 377 165 355 minecraft:polished_deepslate
fill 377 165 356 377 168 356 minecraft:gray_concrete
setblock 377 165 360 minecraft:polished_deepslate
fill 377 165 361 377 167 362 minecraft:gray_concrete
setblock 378 165 329 minecraft:polished_deepslate
fill 378 165 330 378 168 330 minecraft:gray_concrete
setblock 378 165 334 minecraft:polished_deepslate
fill 378 165 335 378 168 335 minecraft:gray_concrete
setblock 378 165 338 minecraft:gray_concrete
setblock 378 165 339 minecraft:polished_deepslate
fill 378 165 340 378 168 340 minecraft:gray_concrete
setblock 378 165 343 minecraft:gray_concrete
setblock 378 165 344 minecraft:polished_deepslate
fill 378 165 345 379 167 345 minecraft:gray_concrete
setblock 378 165 349 minecraft:polished_deepslate
fill 378 165 350 378 168 350 minecraft:gray_concrete
setblock 378 165 354 minecraft:polished_deepslate
fill 378 165 355 378 168 355 minecraft:gray_concrete
setblock 378 165 358 minecraft:gray_concrete
setblock 378 165 359 minecraft:polished_deepslate
fill 378 165 360 378 168 360 minecraft:gray_concrete
fill 378 165 362 378 165 363 minecraft:gray_concrete
setblock 379 165 323 minecraft:polished_deepslate
setblock 379 165 333 minecraft:polished_deepslate
fill 379 165 334 379 168 334 minecraft:gray_concrete
setblock 379 165 338 minecraft:polished_deepslate
fill 379 165 339 379 168 339 minecraft:gray_concrete
setblock 379 165 343 minecraft:polished_deepslate
fill 379 165 344 379 168 344 minecraft:gray_concrete
fill 379 165 346 379 165 347 minecraft:gray_concrete
setblock 379 165 348 minecraft:polished_deepslate
setblock 379 165 349 minecraft:gray_concrete
setblock 379 165 353 minecraft:polished_deepslate
fill 379 165 354 379 167 354 minecraft:gray_concrete
setblock 379 165 358 minecraft:polished_deepslate
fill 379 165 359 379 168 359 minecraft:gray_concrete
setblock 379 165 362 minecraft:gray_concrete
setblock 379 165 363 minecraft:polished_deepslate
fill 380 165 323 380 168 323 minecraft:gray_concrete
setblock 380 165 333 minecraft:gray_concrete
setblock 380 165 337 minecraft:polished_deepslate
fill 380 165 338 380 168 338 minecraft:gray_concrete
fill 380 165 340 380 165 341 minecraft:gray_concrete
setblock 380 165 362 minecraft:polished_deepslate
fill 380 165 363 380 168 363 minecraft:gray_concrete
fill 381 165 362 381 168 362 minecraft:gray_concrete
fill 392 165 323 393 165 323 minecraft:gray_concrete
setblock 393 165 363 minecraft:gray_concrete
setblock 394 165 323 minecraft:polished_deepslate
fill 394 165 324 394 168 324 minecraft:gray_concrete
setblock 394 165 362 minecraft:gray_concrete
setblock 394 165 363 minecraft:polished_deepslate
setblock 394 165 364 minecraft:light_blue_stained_glass
fill 395 165 323 395 168 323 minecraft:gray_concrete
setblock 395 165 362 minecraft:polished_deepslate
fill 395 165 363 395 168 363 minecraft:gray_concrete
fill 395 165 364 395 181 364 minecraft:gray_wool
setblock 396 165 361 minecraft:polished_deepslate
fill 396 165 362 399 165 362 minecraft:gray_concrete
setblock 397 165 325 minecraft:polished_deepslate
fill 397 165 361 400 165 361 minecraft:gray_concrete
setblock 398 165 324 minecraft:polished_deepslate
fill 398 165 325 399 167 325 minecraft:gray_concrete
setblock 398 165 364 minecraft:light_blue_stained_glass
setblock 399 165 323 minecraft:polished_deepslate
fill 399 165 324 399 168 324 minecraft:gray_concrete
setblock 399 165 363 minecraft:polished_deepslate
fill 400 165 323 400 168 323 minecraft:gray_concrete
setblock 400 165 362 minecraft:polished_deepslate
fill 400 165 363 400 168 363 minecraft:gray_concrete
setblock 401 165 361 minecraft:polished_deepslate
fill 401 165 362 401 168 362 minecraft:gray_concrete
fill 402 165 361 402 168 361 minecraft:gray_concrete
setblock 403 165 324 minecraft:polished_deepslate
fill 403 165 362 404 165 362 minecraft:gray_concrete
setblock 404 165 323 minecraft:polished_deepslate
fill 404 165 361 404 166 361 minecraft:gray_concrete
setblock 404 165 363 minecraft:polished_deepslate
fill 405 165 323 405 168 323 minecraft:gray_concrete
setblock 405 165 362 minecraft:polished_deepslate
fill 405 165 363 408 165 363 minecraft:gray_concrete
fill 406 165 362 406 168 362 minecraft:gray_concrete
fill 408 165 362 409 165 362 minecraft:gray_concrete
setblock 409 165 363 minecraft:polished_deepslate
setblock 410 165 362 minecraft:polished_deepslate
fill 410 165 363 410 168 363 minecraft:gray_concrete
fill 411 165 362 411 168 362 minecraft:gray_concrete
fill 412 165 361 415 165 361 minecraft:gray_concrete
fill 414 165 355 414 165 357 minecraft:gray_concrete
setblock 414 165 358 minecraft:polished_deepslate
fill 414 165 359 414 168 359 minecraft:gray_concrete
setblock 414 165 362 minecraft:gray_concrete
setblock 414 165 363 minecraft:polished_deepslate
fill 415 165 323 416 167 323 minecraft:gray_concrete
setblock 415 165 351 minecraft:gray_concrete
setblock 415 165 352 minecraft:polished_deepslate
fill 415 165 353 415 168 353 minecraft:gray_concrete
setblock 415 165 356 minecraft:gray_concrete
setblock 415 165 357 minecraft:polished_deepslate
fill 415 165 358 415 168 358 minecraft:gray_concrete
setblock 415 165 362 minecraft:polished_deepslate
fill 415 165 363 415 168 363 minecraft:gray_concrete
fill 416 165 332 416 167 332 minecraft:gray_concrete
setblock 416 165 336 minecraft:polished_deepslate
fill 416 165 337 416 168 337 minecraft:gray_concrete
setblock 416 165 341 minecraft:polished_deepslate
fill 416 165 342 416 165 345 minecraft:gray_concrete
setblock 416 165 346 minecraft:polished_deepslate
fill 416 165 347 416 168 347 minecraft:gray_concrete
setblock 416 165 351 minecraft:polished_deepslate
fill 416 165 352 416 168 352 minecraft:gray_concrete
setblock 416 165 356 minecraft:polished_deepslate
fill 416 165 357 416 168 357 minecraft:gray_concrete
setblock 416 165 361 minecraft:polished_deepslate
fill 416 165 362 416 168 362 minecraft:gray_concrete
setblock 417 165 324 minecraft:gray_concrete
fill 417 165 327 417 167 327 minecraft:gray_concrete
setblock 417 165 330 minecraft:polished_deepslate
fill 417 165 331 417 168 331 minecraft:gray_concrete
setblock 417 165 335 minecraft:polished_deepslate
fill 417 165 336 417 168 336 minecraft:gray_concrete
setblock 417 165 339 minecraft:gray_concrete
setblock 417 165 340 minecraft:polished_deepslate
fill 417 165 341 417 168 341 minecraft:gray_concrete
fill 417 165 343 417 165 344 minecraft:gray_concrete
setblock 417 165 345 minecraft:polished_deepslate
fill 417 165 346 417 168 346 minecraft:gray_concrete
setblock 417 165 350 minecraft:polished_deepslate
fill 417 165 351 417 168 351 minecraft:gray_concrete
setblock 417 165 355 minecraft:polished_deepslate
fill 417 165 356 417 168 356 minecraft:gray_concrete
setblock 417 165 360 minecraft:polished_deepslate
fill 417 165 361 417 168 361 minecraft:gray_concrete
setblock 418 165 325 minecraft:light_blue_stained_glass
fill 418 165 339 418 168 339 minecraft:gray_wool
fill 418 165 353 418 180 353 minecraft:gray_wool
setblock 377 166 323 minecraft:gray_concrete
setblock 377 166 324 minecraft:polished_deepslate
fill 377 166 325 377 169 325 minecraft:gray_concrete
setblock 377 166 329 minecraft:polished_deepslate
fill 377 166 330 377 169 330 minecraft:gray_concrete
setblock 377 166 334 minecraft:polished_deepslate
fill 377 166 335 377 169 335 minecraft:gray_concrete
setblock 377 166 339 minecraft:polished_deepslate
fill 377 166 340 377 166 343 minecraft:gray_concrete
setblock 377 166 344 minecraft:polished_deepslate
fill 377 166 345 377 169 345 minecraft:gray_concrete
setblock 377 166 349 minecraft:polished_deepslate
fill 377 166 350 377 169 350 minecraft:gray_concrete
setblock 377 166 354 minecraft:polished_deepslate
fill 377 166 355 377 169 355 minecraft:gray_concrete
setblock 377 166 359 minecraft:polished_deepslate
fill 377 166 360 377 169 360 minecraft:gray_concrete
setblock 378 166 323 minecraft:polished_deepslate
fill 378 166 329 378 167 329 minecraft:gray_concrete
setblock 378 166 333 minecraft:polished_deepslate
fill 378 166 334 378 169 334 minecraft:gray_concrete
setblock 378 166 338 minecraft:polished_deepslate
fill 378 166 339 378 169 339 minecraft:gray_concrete
setblock 378 166 342 minecraft:gray_concrete
setblock 378 166 343 minecraft:polished_deepslate
fill 378 166 344 378 169 344 minecraft:gray_concrete
setblock 378 166 348 minecraft:polished_deepslate
fill 378 166 349 378 169 349 minecraft:gray_concrete
setblock 378 166 353 minecraft:polished_deepslate
fill 378 166 354 378 169 354 minecraft:gray_concrete
setblock 378 166 358 minecraft:polished_deepslate
fill 378 166 359 378 169 359 minecraft:gray_concrete
setblock 378 166 362 minecraft:gray_concrete
setblock 378 166 363 minecraft:polished_deepslate
fill 379 166 323 379 169 323 minecraft:gray_concrete
setblock 379 166 325 minecraft:light[level=13]
setblock 379 166 332 minecraft:polished_deepslate
fill 379 166 333 379 169 333 minecraft:gray_concrete
setblock 379 166 336 minecraft:gray_concrete
setblock 379 166 337 minecraft:polished_deepslate
fill 379 166 338 379 169 338 minecraft:gray_concrete
setblock 379 166 342 minecraft:polished_deepslate
fill 379 166 343 379 169 343 minecraft:gray_concrete
setblock 379 166 346 minecraft:gray_concrete
setblock 379 166 349 minecraft:light[level=13]
setblock 379 166 352 minecraft:polished_deepslate
fill 379 166 353 379 167 353 minecraft:gray_concrete
setblock 379 166 357 minecraft:polished_deepslate
fill 379 166 358 379 168 358 minecraft:gray_concrete
setblock 379 166 361 minecraft:gray_concrete
setblock 379 166 362 minecraft:polished_deepslate
fill 379 166 363 379 169 363 minecraft:gray_concrete
setblock 380 166 336 minecraft:polished_deepslate
fill 380 166 337 380 169 337 minecraft:gray_concrete
setblock 380 166 340 minecraft:gray_concrete
setblock 380 166 341 minecraft:polished_deepslate
fill 380 166 362 380 169 362 minecraft:gray_concrete
fill 381 166 323 381 167 323 minecraft:gray_concrete
setblock 383 166 363 minecraft:polished_deepslate
setblock 387 166 325 minecraft:light[level=13]
setblock 387 166 333 minecraft:light[level=13]
setblock 387 166 341 minecraft:light[level=13]
setblock 387 166 349 minecraft:light[level=13]
setblock 387 166 357 minecraft:light[level=13]
fill 391 166 323 392 166 323 minecraft:gray_concrete
fill 391 166 363 392 166 363 minecraft:gray_concrete
setblock 393 166 323 minecraft:polished_deepslate
fill 393 166 324 393 169 324 minecraft:gray_concrete
setblock 393 166 362 minecraft:gray_concrete
setblock 393 166 363 minecraft:polished_deepslate
fill 394 166 323 394 169 323 minecraft:gray_concrete
setblock 394 166 362 minecraft:polished_deepslate
fill 394 166 363 394 169 363 minecraft:gray_concrete
fill 394 166 364 394 184 364 minecraft:gray_wool
setblock 395 166 325 minecraft:light[level=13]
setblock 395 166 333 minecraft:light[level=13]
setblock 395 166 341 minecraft:light[level=13]
setblock 395 166 349 minecraft:light[level=13]
setblock 395 166 357 minecraft:light[level=13]
setblock 395 166 361 minecraft:polished_deepslate
fill 395 166 362 398 166 362 minecraft:gray_concrete
setblock 396 166 325 minecraft:polished_deepslate
fill 396 166 361 399 166 361 minecraft:gray_concrete
setblock 397 166 323 minecraft:gray_concrete
setblock 397 166 324 minecraft:polished_deepslate
fill 397 166 325 397 169 325 minecraft:gray_concrete
setblock 398 166 323 minecraft:polished_deepslate
fill 398 166 324 398 169 324 minecraft:gray_concrete
fill 398 166 360 400 166 360 minecraft:gray_concrete
setblock 398 166 363 minecraft:polished_deepslate
fill 398 166 364 398 184 364 minecraft:gray_wool
fill 399 166 323 399 169 323 minecraft:gray_concrete
setblock 399 166 362 minecraft:polished_deepslate
fill 399 166 363 399 169 363 minecraft:gray_concrete
setblock 400 166 361 minecraft:polished_deepslate
fill 400 166 362 400 169 362 minecraft:gray_concrete
setblock 401 166 360 minecraft:polished_deepslate
fill 401 166 361 401 169 361 minecraft:gray_concrete
setblock 402 166 324 minecraft:polished_deepslate
setblock 403 166 323 minecraft:polished_deepslate
setblock 403 166 324 minecraft:gray_concrete
setblock 403 166 325 minecraft:light[level=13]
setblock 403 166 333 minecraft:light[level=13]
setblock 403 166 341 minecraft:light[level=13]
setblock 403 166 349 minecraft:light[level=13]
setblock 403 166 357 minecraft:light[level=13]
setblock 403 166 362 minecraft:gray_concrete
setblock 403 166 363 minecraft:polished_deepslate
fill 404 166 323 404 169 323 minecraft:gray_concrete
setblock 404 166 362 minecraft:polished_deepslate
fill 404 166 363 407 166 363 minecraft:gray_concrete
setblock 405 166 361 minecraft:polished_deepslate
fill 405 166 362 405 169 362 minecraft:gray_concrete
setblock 408 166 362 minecraft:gray_concrete
setblock 408 166 363 minecraft:polished_deepslate
setblock 409 166 362 minecraft:polished_deepslate
fill 409 166 363 409 169 363 minecraft:gray_concrete
setblock 410 166 361 minecraft:polished_deepslate
fill 410 166 362 410 169 362 minecraft:gray_concrete
setblock 411 166 325 minecraft:light[level=13]
setblock 411 166 333 minecraft:light[level=13]
setblock 411 166 341 minecraft:light[level=13]
setblock 411 166 349 minecraft:light[level=13]
setblock 411 166 357 minecraft:light[level=13]
fill 411 166 361 414 166 361 minecraft:gray_concrete
setblock 412 166 363 minecraft:gray_concrete
setblock 413 166 323 minecraft:polished_deepslate
fill 413 166 360 414 167 360 minecraft:gray_concrete
setblock 413 166 363 minecraft:polished_deepslate
fill 414 166 323 414 169 323 minecraft:gray_concrete
fill 414 166 355 414 166 356 minecraft:gray_concrete
setblock 414 166 357 minecraft:polished_deepslate
fill 414 166 358 414 169 358 minecraft:gray_concrete
setblock 414 166 362 minecraft:polished_deepslate
fill 414 166 363 414 169 363 minecraft:gray_concrete
fill 415 166 337 415 168 338 minecraft:gray_concrete
setblock 415 166 351 minecraft:polished_deepslate
fill 415 166 352 415 169 352 minecraft:gray_concrete
setblock 415 166 356 minecraft:polished_deepslate
fill 415 166 357 415 169 357 minecraft:gray_concrete
setblock 415 166 361 minecraft:polished_deepslate
fill 415 166 362 415 169 362 minecraft:gray_concrete
setblock 416 166 334 minecraft:gray_concrete
setblock 416 166 335 minecraft:polished_deepslate
fill 416 166 336 416 169 336 minecraft:gray_concrete
fill 416 166 338 416 166 339 minecraft:gray_concrete
setblock 416 166 340 minecraft:polished_deepslate
fill 416 166 341 416 166 344 minecraft:gray_concrete
setblock 416 166 345 minecraft:polished_deepslate
fill 416 166 346 416 169 346 minecraft:gray_concrete
setblock 416 166 350 minecraft:polished_deepslate
fill 416 166 351 416 169 351 minecraft:gray_concrete
setblock 416 166 355 minecraft:polished_deepslate
fill 416 166 356 416 169 356 minecraft:gray_concrete
setblock 416 166 360 minecraft:polished_deepslate
fill 416 166 361 416 169 361 minecraft:gray_concrete
setblock 417 166 324 minecraft:polished_deepslate
fill 417 166 325 417 168 326 minecraft:gray_concrete
setblock 417 166 329 minecraft:polished_deepslate
fill 417 166 330 417 169 330 minecraft:gray_concrete
setblock 417 166 334 minecraft:polished_deepslate
fill 417 166 335 417 169 335 minecraft:gray_concrete
setblock 417 166 339 minecraft:polished_deepslate
fill 417 166 340 417 169 340 minecraft:gray_concrete
setblock 417 166 343 minecraft:gray_concrete
setblock 417 166 344 minecraft:polished_deepslate
fill 417 166 345 417 169 345 minecraft:gray_concrete
setblock 417 166 349 minecraft:polished_deepslate
fill 417 166 350 417 169 350 minecraft:gray_concrete
setblock 417 166 354 minecraft:polished_deepslate
fill 417 166 355 417 169 355 minecraft:gray_concrete
setblock 417 166 359 minecraft:polished_deepslate
fill 417 166 360 417 169 360 minecraft:gray_concrete
fill 418 166 325 418 184 325 minecraft:gray_wool
setblock 376 167 340 minecraft:light_blue_stained_glass
setblock 377 167 323 minecraft:polished_deepslate
fill 377 167 324 377 170 324 minecraft:gray_concrete
setblock 377 167 328 minecraft:polished_deepslate
fill 377 167 329 377 170 329 minecraft:gray_concrete
setblock 377 167 333 minecraft:polished_deepslate
fill 377 167 334 377 170 334 minecraft:gray_concrete
setblock 377 167 338 minecraft:polished_deepslate
fill 377 167 339 377 167 342 minecraft:gray_concrete
setblock 377 167 343 minecraft:polished_deepslate
fill 377 167 344 377 170 344 minecraft:gray_concrete
setblock 377 167 348 minecraft:polished_deepslate
fill 377 167 349 377 170 349 minecraft:gray_concrete
setblock 377 167 353 minecraft:polished_deepslate
fill 377 167 354 377 170 354 minecraft:gray_concrete
setblock 377 167 358 minecraft:polished_deepslate
fill 377 167 359 377 170 359 minecraft:gray_concrete
setblock 377 167 363 minecraft:polished_deepslate
fill 378 167 323 378 170 323 minecraft:gray_concrete
setblock 378 167 332 minecraft:polished_deepslate
fill 378 167 333 378 170 333 minecraft:gray_concrete
setblock 378 167 337 minecraft:polished_deepslate
fill 378 167 338 378 170 338 minecraft:gray_concrete
setblock 378 167 342 minecraft:polished_deepslate
fill 378 167 343 378 170 343 minecraft:gray_concrete
setblock 378 167 347 minecraft:polished_deepslate
fill 378 167 348 378 170 348 minecraft:gray_concrete
setblock 378 167 352 minecraft:polished_deepslate
fill 378 167 353 378 169 353 minecraft:gray_concrete
setblock 378 167 357 minecraft:polished_deepslate
fill 378 167 358 378 170 358 minecraft:gray_concrete
setblock 378 167 362 minecraft:polished_deepslate
fill 378 167 363 378 170 363 minecraft:gray_concrete
fill 379 167 332 379 168 332 minecraft:gray_concrete
setblock 379 167 336 minecraft:polished_deepslate
fill 379 167 337 379 170 337 minecraft:gray_concrete
setblock 379 167 341 minecraft:polished_deepslate
fill 379 167 342 380 168 342 minecraft:gray_concrete
setblock 379 167 346 minecraft:polished_deepslate
setblock 379 167 356 minecraft:polished_deepslate
fill 379 167 357 379 168 357 minecraft:gray_concrete
setblock 379 167 361 minecraft:polished_deepslate
fill 379 167 362 379 170 362 minecraft:gray_concrete
setblock 380 167 335 minecraft:polished_deepslate
fill 380 167 336 380 169 336 minecraft:gray_concrete
setblock 380 167 340 minecraft:polished_deepslate
fill 380 167 341 380 169 341 minecraft:gray_concrete
setblock 381 167 363 minecraft:gray_concrete
setblock 382 167 363 minecraft:polished_deepslate
fill 383 167 363 383 168 363 minecraft:gray_concrete
fill 390 167 323 391 167 323 minecraft:gray_concrete
fill 390 167 363 391 167 363 minecraft:gray_concrete
setblock 392 167 323 minecraft:polished_deepslate
fill 392 167 324 392 170 324 minecraft:gray_concrete
setblock 392 167 362 minecraft:gray_concrete
setblock 392 167 363 minecraft:polished_deepslate
fill 393 167 323 393 170 323 minecraft:gray_concrete
setblock 393 167 362 minecraft:polished_deepslate
fill 393 167 363 393 170 363 minecraft:gray_concrete
setblock 394 167 361 minecraft:polished_deepslate
fill 394 167 362 397 167 362 minecraft:gray_concrete
setblock 395 167 324 minecraft:gray_concrete
setblock 395 167 325 minecraft:polished_deepslate
fill 395 167 361 398 167 361 minecraft:gray_concrete
setblock 396 167 324 minecraft:polished_deepslate
fill 396 167 325 396 170 325 minecraft:gray_concrete
setblock 397 167 323 minecraft:polished_deepslate
fill 397 167 324 397 170 324 minecraft:gray_concrete
fill 397 167 360 399 167 360 minecraft:gray_concrete
setblock 397 167 363 minecraft:polished_deepslate
fill 398 167 323 398 170 323 minecraft:gray_concrete
setblock 398 167 362 minecraft:polished_deepslate
fill 398 167 363 398 170 363 minecraft:gray_concrete
setblock 399 167 361 minecraft:polished_deepslate
fill 399 167 362 399 170 362 minecraft:gray_concrete
setblock 400 167 360 minecraft:polished_deepslate
fill 400 167 361 400 170 361 minecraft:gray_concrete
setblock 401 167 324 minecraft:polished_deepslate
fill 401 167 360 401 168 360 minecraft:gray_concrete
setblock 402 167 323 minecraft:polished_deepslate
fill 402 167 324 402 168 324 minecraft:gray_concrete
setblock 402 167 363 minecraft:polished_deepslate
fill 403 167 323 403 170 323 minecraft:gray_concrete
setblock 403 167 362 minecraft:polished_deepslate
fill 403 167 363 406 167 363 minecraft:gray_concrete
setblock 404 167 361 minecraft:polished_deepslate
fill 404 167 362 404 170 362 minecraft:gray_concrete
fill 405 167 361 408 167 361 minecraft:gray_concrete
setblock 407 167 363 minecraft:polished_deepslate
setblock 408 167 362 minecraft:polished_deepslate
fill 408 167 363 408 170 363 minecraft:gray_concrete
setblock 409 167 361 minecraft:polished_deepslate
fill 409 167 362 409 170 362 minecraft:gray_concrete
fill 410 167 361 413 167 361 minecraft:gray_concrete
setblock 412 167 323 minecraft:polished_deepslate
fill 412 167 360 412 169 360 minecraft:gray_concrete
setblock 412 167 362 minecraft:gray_concrete
setblock 412 167 363 minecraft:polished_deepslate
fill 413 167 323 413 170 323 minecraft:gray_concrete
setblock 413 167 362 minecraft:polished_deepslate
fill 413 167 363 413 170 363 minecraft:gray_concrete
setblock 414 167 355 minecraft:gray_concrete
setblock 414 167 356 minecraft:polished_deepslate
fill 414 167 357 414 170 357 minecraft:gray_concrete
setblock 414 167 361 minecraft:polished_deepslate
fill 414 167 362 414 170 362 minecraft:gray_concrete
fill 415 167 336 415 168 336 minecraft:gray_concrete
setblock 415 167 339 minecraft:gray_concrete
setblock 415 167 340 minecraft:polished_deepslate
fill 415 167 341 416 169 341 minecraft:gray_concrete
fill 415 167 351 415 168 351 minecraft:gray_concrete
setblock 415 167 355 minecraft:polished_deepslate
fill 415 167 356 415 170 356 minecraft:gray_concrete
setblock 415 167 360 minecraft:polished_deepslate
fill 415 167 361 415 170 361 minecraft:gray_concrete
setblock 416 167 334 minecraft:polished_deepslate
fill 416 167 335 416 170 335 minecraft:gray_concrete
setblock 416 167 338 minecraft:gray_concrete
setblock 416 167 339 minecraft:polished_deepslate
fill 416 167 340 416 170 340 minecraft:gray_concrete
fill 416 167 342 416 167 343 minecraft:gray_concrete
setblock 416 167 344 minecraft:polished_deepslate
fill 416 167 345 416 170 345 minecraft:gray_concrete
setblock 416 167 349 minecraft:polished_deepslate
fill 416 167 350 416 170 350 minecraft:gray_concrete
setblock 416 167 354 minecraft:polished_deepslate
fill 416 167 355 416 170 355 minecraft:gray_concrete
setblock 416 167 359 minecraft:polished_deepslate
fill 416 167 360 416 170 360 minecraft:gray_concrete
setblock 417 167 323 minecraft:polished_deepslate
fill 417 167 324 417 170 324 minecraft:gray_concrete
setblock 417 167 328 minecraft:polished_deepslate
fill 417 167 329 417 168 329 minecraft:gray_concrete
setblock 417 167 333 minecraft:polished_deepslate
fill 417 167 334 417 170 334 minecraft:gray_concrete
setblock 417 167 338 minecraft:polished_deepslate
fill 417 167 339 417 170 339 minecraft:gray_concrete
setblock 417 167 343 minecraft:polished_deepslate
fill 417 167 344 417 170 344 minecraft:gray_concrete
setblock 417 167 348 minecraft:polished_deepslate
fill 417 167 349 417 170 349 minecraft:gray_concrete
setblock 417 167 353 minecraft:polished_deepslate
fill 417 167 354 417 170 354 minecraft:gray_concrete
setblock 417 167 358 minecraft:polished_deepslate
fill 417 167 359 417 170 359 minecraft:gray_concrete
setblock 417 167 363 minecraft:polished_deepslate
setblock 418 167 330 minecraft:light_blue_stained_glass
setblock 376 168 333 minecraft:light_blue_stained_glass
fill 376 168 340 376 182 340 minecraft:gray_wool
fill 377 168 323 377 171 323 minecraft:gray_concrete
setblock 377 168 327 minecraft:polished_deepslate
fill 377 168 328 377 171 328 minecraft:gray_concrete
setblock 377 168 332 minecraft:polished_deepslate
fill 377 168 333 377 171 333 minecraft:gray_concrete
setblock 377 168 337 minecraft:polished_deepslate
fill 377 168 338 377 168 341 minecraft:gray_concrete
setblock 377 168 342 minecraft:polished_deepslate
fill 377 168 343 377 171 343 minecraft:gray_concrete
setblock 377 168 347 minecraft:polished_deepslate
fill 377 168 348 377 171 348 minecraft:gray_concrete
setblock 377 168 352 minecraft:polished_deepslate
fill 377 168 353 377 171 353 minecraft:gray_concrete
setblock 377 168 357 minecraft:polished_deepslate
fill 377 168 358 377 171 358 minecraft:gray_concrete
setblock 377 168 361 minecraft:gray_concrete
setblock 377 168 362 minecraft:polished_deepslate
fill 377 168 363 377 171 363 minecraft:gray_concrete
setblock 378 168 331 minecraft:polished_deepslate
fill 378 168 332 378 170 332 minecraft:gray_concrete
setblock 378 168 336 minecraft:polished_deepslate
fill 378 168 337 378 171 337 minecraft:gray_concrete
setblock 378 168 341 minecraft:polished_deepslate
fill 378 168 342 378 171 342 minecraft:gray_concrete
setblock 378 168 345 minecraft:gray_concrete
setblock 378 168 346 minecraft:polished_deepslate
fill 378 168 347 378 171 347 minecraft:gray_concrete
setblock 378 168 351 minecraft:polished_deepslate
fill 378 168 352 378 169 352 minecraft:gray_concrete
setblock 378 168 356 minecraft:polished_deepslate
fill 378 168 357 378 170 357 minecraft:gray_concrete
setblock 378 168 361 minecraft:polished_deepslate
fill 378 168 362 378 171 362 minecraft:gray_concrete
setblock 379 168 335 minecraft:polished_deepslate
fill 379 168 336 379 171 336 minecraft:gray_concrete
setblock 379 168 340 minecraft:polished_deepslate
fill 379 168 341 379 171 341 minecraft:gray_concrete
setblock 379 168 345 minecraft:polished_deepslate
setblock 379 168 346 minecraft:gray_concrete
setblock 379 168 356 minecraft:gray_concrete
setblock 379 168 360 minecraft:polished_deepslate
setblock 380 168 335 minecraft:gray_concrete
setblock 380 168 339 minecraft:polished_deepslate
fill 380 168 340 380 170 340 minecraft:gray_concrete
setblock 381 168 323 minecraft:polished_deepslate
setblock 381 168 363 minecraft:polished_deepslate
setblock 382 168 323 minecraft:gray_concrete
fill 382 168 363 382 170 363 minecraft:gray_concrete
fill 389 168 323 390 168 323 minecraft:gray_concrete
fill 389 168 363 390 168 363 minecraft:gray_concrete
setblock 390 168 364 minecraft:light_blue_stained_glass
setblock 391 168 323 minecraft:polished_deepslate
setblock 391 168 362 minecraft:gray_concrete
setblock 391 168 363 minecraft:polished_deepslate
fill 392 168 323 392 171 323 minecraft:gray_concrete
setblock 392 168 362 minecraft:polished_deepslate
fill 392 168 363 392 171 363 minecraft:gray_concrete
setblock 393 168 361 minecraft:polished_deepslate
fill 393 168 362 396 168 362 minecraft:gray_concrete
fill 394 168 361 397 168 361 minecraft:gray_concrete
setblock 395 168 324 minecraft:polished_deepslate
fill 395 168 325 395 171 325 minecraft:gray_concrete
setblock 396 168 323 minecraft:polished_deepslate
fill 396 168 324 396 171 324 minecraft:gray_concrete
fill 396 168 360 398 168 360 minecraft:gray_concrete
setblock 396 168 363 minecraft:polished_deepslate
fill 397 168 323 397 171 323 minecraft:gray_concrete
setblock 397 168 362 minecraft:polished_deepslate
fill 397 168 363 397 171 363 minecraft:gray_concrete
setblock 398 168 325 minecraft:gray_concrete
setblock 398 168 361 minecraft:polished_deepslate
fill 398 168 362 398 171 362 minecraft:gray_concrete
setblock 399 168 325 minecraft:polished_deepslate
setblock 399 168 360 minecraft:polished_deepslate
fill 399 168 361 399 171 361 minecraft:gray_concrete
setblock 400 168 324 minecraft:polished_deepslate
setblock 400 168 360 minecraft:gray_concrete
setblock 401 168 323 minecraft:polished_deepslate
fill 401 168 324 401 170 324 minecraft:gray_concrete
setblock 401 168 363 minecraft:polished_deepslate
fill 402 168 323 402 171 323 minecraft:gray_concrete
setblock 402 168 362 minecraft:polished_deepslate
fill 402 168 363 405 168 363 minecraft:gray_concrete
setblock 403 168 361 minecraft:polished_deepslate
fill 403 168 362 403 171 362 minecraft:gray_concrete
fill 404 168 361 407 168 361 minecraft:gray_concrete
setblock 406 168 323 minecraft:polished_deepslate
setblock 406 168 363 minecraft:polished_deepslate
setblock 407 168 362 minecraft:polished_deepslate
fill 407 168 363 407 171 363 minecraft:gray_concrete
setblock 408 168 361 minecraft:polished_deepslate
fill 408 168 362 408 171 362 minecraft:gray_concrete
fill 409 168 361 412 168 361 minecraft:gray_concrete
setblock 411 168 323 minecraft:polished_deepslate
setblock 411 168 363 minecraft:polished_deepslate
fill 412 168 323 412 171 323 minecraft:gray_concrete
setblock 412 168 362 minecraft:polished_deepslate
fill 412 168 363 412 171 363 minecraft:gray_concrete
setblock 413 168 360 minecraft:gray_concrete
setblock 413 168 361 minecraft:polished_deepslate
fill 413 168 362 413 171 362 minecraft:gray_concrete
fill 414 168 322 415 184 322 minecraft:gray_wool
setblock 414 168 355 minecraft:polished_deepslate
fill 414 168 356 414 169 356 minecraft:gray_concrete
setblock 414 168 360 minecraft:polished_deepslate
fill 414 168 361 414 171 361 minecraft:gray_concrete
setblock 415 168 323 minecraft:gray_concrete
setblock 415 168 339 minecraft:polished_deepslate
fill 415 168 340 415 171 340 minecraft:gray_concrete
fill 415 168 342 415 168 343 minecraft:gray_concrete
setblock 415 168 354 minecraft:polished_deepslate
fill 415 168 355 415 171 355 minecraft:gray_concrete
setblock 415 168 359 minecraft:polished_deepslate
fill 415 168 360 415 171 360 minecraft:gray_concrete
setblock 416 168 322 minecraft:light_blue_stained_glass
setblock 416 168 323 minecraft:polished_deepslate
setblock 416 168 333 minecraft:polished_deepslate
fill 416 168 334 416 170 334 minecraft:gray_concrete
setblock 416 168 338 minecraft:polished_deepslate
fill 416 168 339 416 171 339 minecraft:gray_concrete
setblock 416 168 342 minecraft:gray_concrete
setblock 416 168 343 minecraft:polished_deepslate
fill 416 168 344 416 171 344 minecraft:gray_concrete
setblock 416 168 348 minecraft:polished_deepslate
fill 416 168 349 416 171 349 minecraft:gray_concrete
setblock 416 168 353 minecraft:polished_deepslate
fill 416 168 354 416 171 354 minecraft:gray_concrete
setblock 416 168 358 minecraft:polished_deepslate
fill 416 168 359 416 171 359 minecraft:gray_concrete
setblock 416 168 363 minecraft:polished_deepslate
fill 417 168 323 417 171 323 minecraft:gray_concrete
setblock 417 168 328 minecraft:gray_concrete
setblock 417 168 332 minecraft:polished_deepslate
fill 417 168 333 417 171 333 minecraft:gray_concrete
setblock 417 168 337 minecraft:polished_deepslate
fill 417 168 338 417 171 338 minecraft:gray_concrete
setblock 417 168 342 minecraft:polished_deepslate
fill 417 168 343 417 171 343 minecraft:gray_concrete
setblock 417 168 347 minecraft:polished_deepslate
fill 417 168 348 417 171 348 minecraft:gray_concrete
setblock 417 168 352 minecraft:polished_deepslate
fill 417 168 353 417 171 353 minecraft:gray_concrete
setblock 417 168 357 minecraft:polished_deepslate
fill 417 168 358 417 171 358 minecraft:gray_concrete
setblock 417 168 362 minecraft:polished_deepslate
fill 417 168 363 417 171 363 minecraft:gray_concrete
fill 418 168 330 418 184 330 minecraft:gray_wool
fill 376 169 333 376 181 333 minecraft:gray_wool
setblock 377 169 326 minecraft:polished_deepslate
fill 377 169 327 377 171 327 minecraft:gray_concrete
setblock 377 169 331 minecraft:polished_deepslate
fill 377 169 332 377 172 332 minecraft:gray_concrete
setblock 377 169 336 minecraft:polished_deepslate
fill 377 169 337 377 169 340 minecraft:gray_concrete
setblock 377 169 341 minecraft:polished_deepslate
fill 377 169 342 377 172 342 minecraft:gray_concrete
setblock 377 169 346 minecraft:polished_deepslate
fill 377 169 347 377 172 347 minecraft:gray_concrete
setblock 377 169 351 minecraft:polished_deepslate
fill 377 169 352 377 172 352 minecraft:gray_concrete
setblock 377 169 356 minecraft:polished_deepslate
fill 377 169 357 377 172 357 minecraft:gray_concrete
setblock 377 169 361 minecraft:polished_deepslate
fill 377 169 362 377 172 362 minecraft:gray_concrete
setblock 378 169 331 minecraft:gray_concrete
setblock 378 169 335 minecraft:polished_deepslate
fill 378 169 336 378 172 336 minecraft:gray_concrete
setblock 378 169 340 minecraft:polished_deepslate
fill 378 169 341 378 172 341 minecraft:gray_concrete
setblock 378 169 345 minecraft:polished_deepslate
fill 378 169 346 378 172 346 minecraft:gray_concrete
setblock 378 169 350 minecraft:polished_deepslate
setblock 378 169 351 minecraft:gray_concrete
setblock 378 169 355 minecraft:polished_deepslate
fill 378 169 356 378 170 356 minecraft:gray_concrete
setblock 378 169 360 minecraft:polished_deepslate
fill 378 169 361 378 171 361 minecraft:gray_concrete
setblock 379 169 334 minecraft:polished_deepslate
fill 379 169 335 379 170 335 minecraft:gray_concrete
setblock 379 169 339 minecraft:polished_deepslate
fill 379 169 340 379 172 340 minecraft:gray_concrete
fill 379 169 342 379 170 342 minecraft:gray_concrete
setblock 379 169 344 minecraft:polished_deepslate
setblock 379 169 345 minecraft:gray_concrete
setblock 380 169 323 minecraft:polished_deepslate
setblock 380 169 338 minecraft:polished_deepslate
fill 380 169 339 380 170 339 minecraft:gray_concrete
setblock 380 169 363 minecraft:polished_deepslate
fill 381 169 323 381 170 323 minecraft:gray_concrete
fill 381 169 363 381 171 363 minecraft:gray_concrete
fill 388 169 323 389 169 323 minecraft:gray_concrete
fill 388 169 363 389 169 363 minecraft:gray_concrete
setblock 390 169 323 minecraft:polished_deepslate
setblock 390 169 363 minecraft:polished_deepslate
fill 390 169 364 390 181 364 minecraft:gray_wool
fill 391 169 323 391 171 324 minecraft:gray_concrete
setblock 391 169 362 minecraft:polished_deepslate
fill 391 169 363 391 172 363 minecraft:gray_concrete
fill 392 169 362 395 169 362 minecraft:gray_concrete
fill 393 169 361 396 169 361 minecraft:gray_concrete
setblock 394 169 324 minecraft:polished_deepslate
fill 394 169 325 394 172 325 minecraft:gray_concrete
setblock 395 169 323 minecraft:polished_deepslate
fill 395 169 324 395 172 324 minecraft:gray_concrete
setblock 395 169 363 minecraft:polished_deepslate
fill 396 169 323 396 172 323 minecraft:gray_concrete
fill 396 169 360 397 169 360 minecraft:gray_concrete
setblock 396 169 362 minecraft:polished_deepslate
fill 396 169 363 396 172 363 minecraft:gray_concrete
setblock 397 169 361 minecraft:polished_deepslate
fill 397 169 362 397 172 362 minecraft:gray_concrete
setblock 398 169 325 minecraft:polished_deepslate
setblock 398 169 360 minecraft:polished_deepslate
fill 398 169 361 398 172 361 minecraft:gray_concrete
setblock 399 169 324 minecraft:polished_deepslate
setblock 399 169 360 minecraft:gray_concrete
setblock 400 169 323 minecraft:polished_deepslate
fill 400 169 324 400 172 324 minecraft:gray_concrete
setblock 400 169 363 minecraft:polished_deepslate
fill 401 169 323 401 172 323 minecraft:gray_concrete
setblock 401 169 362 minecraft:polished_deepslate
fill 401 169 363 404 169 363 minecraft:gray_concrete
setblock 402 169 361 minecraft:polished_deepslate
fill 402 169 362 402 172 362 minecraft:gray_concrete
fill 403 169 361 405 169 361 minecraft:gray_concrete
fill 404 169 334 405 170 336 minecraft:white_wool
setblock 405 169 323 minecraft:polished_deepslate
setblock 405 169 363 minecraft:polished_deepslate
setblock 406 169 323 minecraft:gray_concrete
setblock 406 169 362 minecraft:polished_deepslate
fill 406 169 363 406 172 363 minecraft:gray_concrete
fill 407 169 362 407 172 362 minecraft:gray_concrete
fill 408 169 361 411 169 361 minecraft:gray_concrete
setblock 410 169 323 minecraft:polished_deepslate
setblock 410 169 363 minecraft:polished_deepslate
fill 411 169 323 411 172 323 minecraft:gray_concrete
setblock 411 169 362 minecraft:polished_deepslate
fill 411 169 363 411 172 363 minecraft:gray_concrete
setblock 412 169 361 minecraft:polished_deepslate
fill 412 169 362 412 172 362 minecraft:gray_concrete
setblock 413 169 360 minecraft:polished_deepslate
fill 413 169 361 413 172 361 minecraft:gray_concrete
setblock 414 169 359 minecraft:polished_deepslate
fill 414 169 360 414 171 360 minecraft:gray_concrete
setblock 415 169 323 minecraft:polished_deepslate
setblock 415 169 337 minecraft:gray_concrete
setblock 415 169 338 minecraft:polished_deepslate
fill 415 169 339 415 172 339 minecraft:gray_concrete
setblock 415 169 342 minecraft:gray_concrete
setblock 415 169 343 minecraft:polished_deepslate
fill 415 169 344 415 171 345 minecraft:gray_concrete
setblock 415 169 353 minecraft:polished_deepslate
fill 415 169 354 415 170 354 minecraft:gray_concrete
setblock 415 169 358 minecraft:polished_deepslate
fill 415 169 359 415 172 359 minecraft:gray_concrete
setblock 415 169 363 minecraft:polished_deepslate
fill 416 169 322 416 180 322 minecraft:gray_wool
fill 416 169 323 416 172 323 minecraft:gray_concrete
setblock 416 169 333 minecraft:gray_concrete
setblock 416 169 337 minecraft:polished_deepslate
fill 416 169 338 416 172 338 minecraft:gray_concrete
setblock 416 169 342 minecraft:polished_deepslate
fill 416 169 343 416 172 343 minecraft:gray_concrete
setblock 416 169 347 minecraft:polished_deepslate
fill 416 169 348 416 172 348 minecraft:gray_concrete
setblock 416 169 352 minecraft:polished_deepslate
fill 416 169 353 416 172 353 minecraft:gray_concrete
setblock 416 169 357 minecraft:polished_deepslate
fill 416 169 358 416 172 358 minecraft:gray_concrete
setblock 416 169 362 minecraft:polished_deepslate
fill 416 169 363 416 172 363 minecraft:gray_concrete
setblock 417 169 325 minecraft:gray_concrete
setblock 417 169 331 minecraft:polished_deepslate
fill 417 169 332 417 170 332 minecraft:gray_concrete
setblock 417 169 336 minecraft:polished_deepslate
fill 417 169 337 417 172 337 minecraft:gray_concrete
setblock 417 169 341 minecraft:polished_deepslate
fill 417 169 342 417 172 342 minecraft:gray_concrete
setblock 417 169 346 minecraft:polished_deepslate
fill 417 169 347 417 172 347 minecraft:gray_concrete
setblock 417 169 351 minecraft:polished_deepslate
fill 417 169 352 417 172 352 minecraft:gray_concrete
setblock 417 169 356 minecraft:polished_deepslate
fill 417 169 357 417 172 357 minecraft:gray_concrete
setblock 417 169 361 minecraft:polished_deepslate
fill 417 169 362 417 172 362 minecraft:gray_concrete
setblock 418 169 339 minecraft:light_blue_stained_glass
fill 418 169 348 418 176 349 minecraft:gray_wool
setblock 418 169 350 minecraft:light_blue_stained_glass
fill 376 170 324 376 184 325 minecraft:gray_wool
setblock 376 170 326 minecraft:light_blue_stained_glass
fill 376 170 327 376 173 330 minecraft:gray_wool
setblock 377 170 325 minecraft:polished_deepslate
fill 377 170 326 377 173 326 minecraft:gray_concrete
setblock 377 170 330 minecraft:polished_deepslate
fill 377 170 331 377 173 331 minecraft:gray_concrete
setblock 377 170 335 minecraft:polished_deepslate
fill 377 170 336 377 170 339 minecraft:gray_concrete
setblock 377 170 340 minecraft:polished_deepslate
fill 377 170 341 377 173 341 minecraft:gray_concrete
setblock 377 170 345 minecraft:polished_deepslate
fill 377 170 346 377 173 346 minecraft:gray_concrete
setblock 377 170 350 minecraft:polished_deepslate
fill 377 170 351 377 172 351 minecraft:gray_concrete
setblock 377 170 355 minecraft:polished_deepslate
fill 377 170 356 377 172 356 minecraft:gray_concrete
setblock 377 170 360 minecraft:polished_deepslate
fill 377 170 361 377 173 361 minecraft:gray_concrete
setblock 378 170 334 minecraft:polished_deepslate
fill 378 170 335 378 172 335 minecraft:gray_concrete
setblock 378 170 339 minecraft:polished_deepslate
fill 378 170 340 378 173 340 minecraft:gray_concrete
setblock 378 170 344 minecraft:polished_deepslate
fill 378 170 345 378 173 345 minecraft:gray_concrete
setblock 378 170 355 minecraft:gray_concrete
setblock 378 170 359 minecraft:polished_deepslate
fill 378 170 360 378 171 360 minecraft:gray_concrete
setblock 379 170 323 minecraft:polished_deepslate
setblock 379 170 325 minecraft:light[level=12]
setblock 379 170 332 minecraft:light[level=12]
setblock 379 170 338 minecraft:polished_deepslate
fill 379 170 339 379 172 339 minecraft:gray_concrete
setblock 379 170 343 minecraft:polished_deepslate
fill 379 170 344 379 171 344 minecraft:gray_concrete
setblock 379 170 346 minecraft:light[level=12]
setblock 379 170 353 minecraft:light[level=12]
setblock 379 170 360 minecraft:light[level=12]
setblock 379 170 363 minecraft:polished_deepslate
fill 380 170 323 380 173 323 minecraft:gray_concrete
fill 380 170 363 380 172 363 minecraft:gray_concrete
fill 382 170 322 382 184 322 minecraft:gray_wool
fill 383 170 322 384 170 322 minecraft:light_blue_stained_glass
fill 385 170 322 390 180 322 minecraft:gray_wool
setblock 386 170 325 minecraft:light[level=12]
setblock 386 170 332 minecraft:light[level=12]
setblock 386 170 339 minecraft:light[level=12]
setblock 386 170 346 minecraft:light[level=12]
setblock 386 170 353 minecraft:light[level=12]
setblock 386 170 360 minecraft:light[level=12]
fill 387 170 323 388 170 323 minecraft:gray_concrete
fill 387 170 349 387 171 351 minecraft:gray_wool
fill 388 170 350 388 171 350 minecraft:gray_wool
setblock 388 170 363 minecraft:gray_concrete
setblock 389 170 323 minecraft:polished_deepslate
setblock 389 170 363 minecraft:polished_deepslate
fill 390 170 323 390 173 323 minecraft:gray_concrete
setblock 390 170 362 minecraft:polished_deepslate
fill 390 170 363 390 173 363 minecraft:gray_concrete
fill 391 170 362 394 170 362 minecraft:gray_concrete
setblock 393 170 324 minecraft:polished_deepslate
setblock 393 170 325 minecraft:light[level=12]
setblock 393 170 332 minecraft:light[level=12]
setblock 393 170 339 minecraft:light[level=12]
setblock 393 170 346 minecraft:light[level=12]
setblock 393 170 353 minecraft:light[level=12]
setblock 393 170 360 minecraft:light[level=12]
fill 393 170 361 395 170 361 minecraft:gray_concrete
setblock 394 170 323 minecraft:polished_deepslate
fill 394 170 324 394 173 324 minecraft:gray_concrete
setblock 394 170 363 minecraft:polished_deepslate
fill 395 170 323 395 173 323 minecraft:gray_concrete
setblock 395 170 362 minecraft:polished_deepslate
fill 395 170 363 395 173 363 minecraft:gray_concrete
setblock 396 170 361 minecraft:polished_deepslate
fill 396 170 362 396 173 362 minecraft:gray_concrete
setblock 397 170 325 minecraft:polished_deepslate
fill 397 170 361 397 173 361 minecraft:gray_concrete
setblock 397 170 364 minecraft:light_blue_stained_glass
setblock 398 170 324 minecraft:polished_deepslate
setblock 399 170 323 minecraft:polished_deepslate
fill 399 170 324 399 173 324 minecraft:gray_concrete
setblock 399 170 363 minecraft:polished_deepslate
fill 400 170 323 400 173 323 minecraft:gray_concrete
setblock 400 170 325 minecraft:light[level=12]
setblock 400 170 332 minecraft:light[level=12]
setblock 400 170 339 minecraft:light[level=12]
setblock 400 170 346 minecraft:light[level=12]
setblock 400 170 353 minecraft:light[level=12]
setblock 400 170 360 minecraft:light[level=12]
setblock 400 170 362 minecraft:polished_deepslate
fill 400 170 363 403 170 363 minecraft:gray_concrete
setblock 401 170 361 minecraft:polished_deepslate
fill 401 170 362 401 173 362 minecraft:gray_concrete
fill 402 170 361 403 170 361 minecraft:gray_concrete
setblock 404 170 323 minecraft:polished_deepslate
setblock 404 170 363 minecraft:polished_deepslate
setblock 405 170 323 minecraft:gray_concrete
setblock 405 170 362 minecraft:polished_deepslate
fill 405 170 363 405 173 363 minecraft:gray_concrete
fill 406 170 362 406 173 362 minecraft:gray_concrete
setblock 407 170 325 minecraft:light[level=12]
setblock 407 170 332 minecraft:light[level=12]
setblock 407 170 339 minecraft:light[level=12]
setblock 407 170 346 minecraft:light[level=12]
setblock 407 170 353 minecraft:light[level=12]
setblock 407 170 360 minecraft:light[level=12]
fill 409 170 361 410 170 361 minecraft:gray_concrete
setblock 409 170 363 minecraft:polished_deepslate
fill 410 170 323 410 173 323 minecraft:gray_concrete
setblock 410 170 362 minecraft:polished_deepslate
fill 410 170 363 410 173 363 minecraft:gray_concrete
setblock 411 170 361 minecraft:polished_deepslate
fill 411 170 362 411 173 362 minecraft:gray_concrete
setblock 412 170 360 minecraft:polished_deepslate
fill 412 170 361 412 173 361 minecraft:gray_concrete
setblock 413 170 360 minecraft:gray_concrete
setblock 414 170 323 minecraft:polished_deepslate
setblock 414 170 325 minecraft:light[level=12]
setblock 414 170 332 minecraft:light[level=12]
setblock 414 170 339 minecraft:light[level=12]
setblock 414 170 346 minecraft:light[level=12]
setblock 414 170 353 minecraft:light[level=12]
setblock 414 170 358 minecraft:polished_deepslate
setblock 414 170 359 minecraft:gray_concrete
setblock 414 170 363 minecraft:polished_deepslate
fill 415 170 323 415 173 323 minecraft:gray_concrete
setblock 415 170 337 minecraft:polished_deepslate
fill 415 170 338 415 171 338 minecraft:gray_concrete
setblock 415 170 341 minecraft:gray_concrete
setblock 415 170 342 minecraft:polished_deepslate
fill 415 170 343 415 173 343 minecraft:gray_concrete
setblock 415 170 346 minecraft:gray_concrete
setblock 415 170 353 minecraft:gray_concrete
setblock 415 170 357 minecraft:polished_deepslate
fill 415 170 358 415 172 358 minecraft:gray_concrete
setblock 415 170 362 minecraft:polished_deepslate
fill 415 170 363 415 173 363 minecraft:gray_concrete
setblock 416 170 336 minecraft:polished_deepslate
fill 416 170 337 416 173 337 minecraft:gray_concrete
setblock 416 170 341 minecraft:polished_deepslate
fill 416 170 342 416 173 342 minecraft:gray_concrete
setblock 416 170 346 minecraft:polished_deepslate
fill 416 170 347 416 173 347 minecraft:gray_concrete
setblock 416 170 351 minecraft:polished_deepslate
fill 416 170 352 416 173 352 minecraft:gray_concrete
setblock 416 170 356 minecraft:polished_deepslate
fill 416 170 357 416 173 357 minecraft:gray_concrete
setblock 416 170 361 minecraft:polished_deepslate
fill 416 170 362 416 173 362 minecraft:gray_concrete
setblock 417 170 325 minecraft:polished_deepslate
setblock 417 170 335 minecraft:polished_deepslate
fill 417 170 336 417 173 336 minecraft:gray_concrete
setblock 417 170 340 minecraft:polished_deepslate
fill 417 170 341 417 173 341 minecraft:gray_concrete
setblock 417 170 345 minecraft:polished_deepslate
fill 417 170 346 417 173 346 minecraft:gray_concrete
setblock 417 170 350 minecraft:polished_deepslate
fill 417 170 351 417 173 351 minecraft:gray_concrete
setblock 417 170 355 minecraft:polished_deepslate
fill 417 170 356 417 173 356 minecraft:gray_concrete
setblock 417 170 360 minecraft:polished_deepslate
fill 417 170 361 417 173 361 minecraft:gray_concrete
fill 418 170 339 418 184 339 minecraft:gray_wool
fill 418 170 350 418 182 350 minecraft:gray_wool
fill 376 171 326 376 184 326 minecraft:gray_wool
setblock 377 171 324 minecraft:polished_deepslate
fill 377 171 325 377 174 325 minecraft:gray_concrete
setblock 377 171 329 minecraft:polished_deepslate
fill 377 171 330 377 172 330 minecraft:gray_concrete
setblock 377 171 334 minecraft:polished_deepslate
fill 377 171 335 377 171 338 minecraft:gray_concrete
setblock 377 171 339 minecraft:polished_deepslate
fill 377 171 340 377 174 340 minecraft:gray_concrete
setblock 377 171 344 minecraft:polished_deepslate
fill 377 171 345 377 174 345 minecraft:gray_concrete
setblock 377 171 349 minecraft:polished_deepslate
fill 377 171 350 377 174 350 minecraft:gray_concrete
setblock 377 171 354 minecraft:polished_deepslate
fill 377 171 355 377 172 355 minecraft:gray_concrete
setblock 377 171 359 minecraft:polished_deepslate
fill 377 171 360 377 173 360 minecraft:gray_concrete
setblock 378 171 323 minecraft:polished_deepslate
setblock 378 171 333 minecraft:polished_deepslate
fill 378 171 334 378 172 334 minecraft:gray_concrete
setblock 378 171 338 minecraft:polished_deepslate
fill 378 171 339 378 174 339 minecraft:gray_concrete
setblock 378 171 343 minecraft:polished_deepslate
fill 378 171 344 378 174 344 minecraft:gray_concrete
setblock 378 171 359 minecraft:gray_concrete
setblock 378 171 363 minecraft:polished_deepslate
fill 379 171 323 379 174 323 minecraft:gray_concrete
setblock 379 171 337 minecraft:polished_deepslate
fill 379 171 338 379 172 338 minecraft:gray_concrete
setblock 379 171 342 minecraft:polished_deepslate
fill 379 171 343 379 172 343 minecraft:gray_concrete
fill 379 171 363 379 173 363 minecraft:gray_concrete
fill 383 171 322 384 181 322 minecraft:gray_wool
setblock 387 171 323 minecraft:gray_concrete
setblock 388 171 323 minecraft:polished_deepslate
setblock 388 171 363 minecraft:polished_deepslate
fill 389 171 323 389 174 323 minecraft:gray_concrete
fill 389 171 363 389 174 363 minecraft:gray_concrete
fill 390 171 324 390 172 324 minecraft:gray_concrete
fill 390 171 362 393 171 362 minecraft:gray_concrete
setblock 392 171 324 minecraft:polished_deepslate
setblock 393 171 323 minecraft:polished_deepslate
fill 393 171 324 393 173 325 minecraft:gray_concrete
fill 393 171 361 394 171 361 minecraft:gray_concrete
setblock 393 171 363 minecraft:polished_deepslate
fill 394 171 323 394 174 323 minecraft:gray_concrete
setblock 394 171 362 minecraft:polished_deepslate
fill 394 171 363 394 174 363 minecraft:gray_concrete
setblock 395 171 361 minecraft:polished_deepslate
fill 395 171 362 395 174 362 minecraft:gray_concrete
fill 396 171 322 396 184 322 minecraft:gray_wool
setblock 396 171 325 minecraft:polished_deepslate
fill 396 171 361 396 174 361 minecraft:gray_concrete
setblock 397 171 322 minecraft:light_blue_stained_glass
setblock 397 171 324 minecraft:polished_deepslate
fill 397 171 364 397 180 364 minecraft:gray_wool
setblock 398 171 323 minecraft:polished_deepslate
fill 398 171 324 398 174 324 minecraft:gray_concrete
setblock 398 171 363 minecraft:polished_deepslate
fill 399 171 323 399 174 323 minecraft:gray_concrete
setblock 399 171 362 minecraft:polished_deepslate
fill 399 171 363 402 171 363 minecraft:gray_concrete
setblock 400 171 361 minecraft:polished_deepslate
fill 400 171 362 400 174 362 minecraft:gray_concrete
setblock 401 171 361 minecraft:gray_concrete
setblock 403 171 323 minecraft:polished_deepslate
setblock 403 171 363 minecraft:polished_deepslate
fill 404 171 323 404 172 323 minecraft:gray_concrete
setblock 404 171 362 minecraft:polished_deepslate
fill 404 171 363 404 174 363 minecraft:gray_concrete
fill 405 171 362 405 174 362 minecraft:gray_concrete
setblock 408 171 363 minecraft:polished_deepslate
fill 409 171 323 409 174 323 minecraft:gray_concrete
setblock 409 171 361 minecraft:gray_concrete
setblock 409 171 362 minecraft:polished_deepslate
fill 409 171 363 409 174 363 minecraft:gray_concrete
setblock 410 171 361 minecraft:polished_deepslate
fill 410 171 362 410 174 362 minecraft:gray_concrete
fill 411 171 361 411 174 361 minecraft:gray_concrete
setblock 413 171 323 minecraft:polished_deepslate
setblock 413 171 363 minecraft:polished_deepslate
fill 414 171 323 414 174 323 minecraft:gray_concrete
setblock 414 171 362 minecraft:polished_deepslate
fill 414 171 363 414 174 363 minecraft:gray_concrete
setblock 415 171 341 minecraft:polished_deepslate
fill 415 171 342 415 174 342 minecraft:gray_concrete
setblock 415 171 346 minecraft:polished_deepslate
setblock 415 171 356 minecraft:polished_deepslate
fill 415 171 357 415 172 357 minecraft:gray_concrete
setblock 415 171 361 minecraft:polished_deepslate
fill 415 171 362 415 174 362 minecraft:gray_concrete
setblock 416 171 335 minecraft:polished_deepslate
fill 416 171 336 416 172 336 minecraft:gray_concrete
setblock 416 171 340 minecraft:polished_deepslate
fill 416 171 341 416 174 341 minecraft:gray_concrete
setblock 416 171 345 minecraft:polished_deepslate
fill 416 171 346 416 174 346 minecraft:gray_concrete
setblock 416 171 350 minecraft:polished_deepslate
fill 416 171 351 416 174 351 minecraft:gray_concrete
setblock 416 171 355 minecraft:polished_deepslate
fill 416 171 356 416 173 356 minecraft:gray_concrete
setblock 416 171 360 minecraft:polished_deepslate
fill 416 171 361 416 174 361 minecraft:gray_concrete
setblock 417 171 324 minecraft:polished_deepslate
setblock 417 171 334 minecraft:polished_deepslate
fill 417 171 335 417 173 335 minecraft:gray_concrete
setblock 417 171 339 minecraft:polished_deepslate
fill 417 171 340 417 174 340 minecraft:gray_concrete
setblock 417 171 344 minecraft:polished_deepslate
fill 417 171 345 417 174 345 minecraft:gray_concrete
setblock 417 171 349 minecraft:polished_deepslate
fill 417 171 350 417 174 350 minecraft:gray_concrete
setblock 417 171 354 minecraft:polished_deepslate
fill 417 171 355 417 174 355 minecraft:gray_concrete
setblock 417 171 359 minecraft:polished_deepslate
fill 417 171 360 417 174 360 minecraft:gray_concrete
setblock 377 172 323 minecraft:polished_deepslate
fill 377 172 324 377 175 324 minecraft:gray_concrete
setblock 377 172 333 minecraft:polished_deepslate
fill 377 172 334 377 172 337 minecraft:gray_concrete
setblock 377 172 338 minecraft:polished_deepslate
fill 377 172 339 377 175 339 minecraft:gray_concrete
setblock 377 172 343 minecraft:polished_deepslate
fill 377 172 344 377 175 344 minecraft:gray_concrete
setblock 377 172 348 minecraft:polished_deepslate
fill 377 172 349 377 175 349 minecraft:gray_concrete
setblock 377 172 358 minecraft:polished_deepslate
fill 377 172 359 377 173 359 minecraft:gray_concrete
setblock 377 172 363 minecraft:polished_deepslate
fill 378 172 323 378 175 323 minecraft:gray_concrete
setblock 378 172 337 minecraft:polished_deepslate
fill 378 172 338 378 175 338 minecraft:gray_concrete
setblock 378 172 342 minecraft:polished_deepslate
fill 378 172 343 378 175 343 minecraft:gray_concrete
setblock 378 172 347 minecraft:polished_deepslate
fill 378 172 363 378 174 363 minecraft:gray_concrete
setblock 379 172 341 minecraft:polished_deepslate
fill 379 172 342 379 173 342 minecraft:gray_concrete
setblock 386 172 323 minecraft:gray_concrete
setblock 387 172 323 minecraft:polished_deepslate
fill 388 172 323 388 175 323 minecraft:gray_concrete
fill 388 172 363 388 175 363 minecraft:gray_concrete
fill 389 172 324 389 173 324 minecraft:gray_concrete
fill 390 172 362 392 172 362 minecraft:gray_concrete
setblock 391 172 323 minecraft:gray_concrete
setblock 391 172 324 minecraft:polished_deepslate
setblock 392 172 323 minecraft:polished_deepslate
fill 392 172 324 392 175 324 minecraft:gray_concrete
setblock 392 172 363 minecraft:polished_deepslate
fill 393 172 323 393 175 323 minecraft:gray_concrete
setblock 393 172 361 minecraft:gray_concrete
setblock 393 172 362 minecraft:polished_deepslate
fill 393 172 363 393 175 363 minecraft:gray_concrete
setblock 394 172 361 minecraft:polished_deepslate
fill 394 172 362 394 175 362 minecraft:gray_concrete
setblock 395 172 325 minecraft:polished_deepslate
fill 395 172 361 395 175 361 minecraft:gray_concrete
setblock 396 172 324 minecraft:polished_deepslate
fill 396 172 325 396 175 325 minecraft:gray_concrete
fill 397 172 322 397 184 322 minecraft:gray_wool
setblock 397 172 323 minecraft:polished_deepslate
fill 397 172 324 397 175 324 minecraft:gray_concrete
setblock 397 172 363 minecraft:polished_deepslate
fill 398 172 323 398 175 323 minecraft:gray_concrete
setblock 398 172 362 minecraft:polished_deepslate
fill 398 172 363 401 172 363 minecraft:gray_concrete
setblock 399 172 361 minecraft:polished_deepslate
fill 399 172 362 399 175 362 minecraft:gray_concrete
setblock 402 172 323 minecraft:polished_deepslate
setblock 402 172 363 minecraft:polished_deepslate
fill 403 172 323 403 175 323 minecraft:gray_concrete
setblock 403 172 362 minecraft:polished_deepslate
fill 403 172 363 403 175 363 minecraft:gray_concrete
fill 404 172 362 404 173 362 minecraft:gray_concrete
setblock 407 172 363 minecraft:polished_deepslate
setblock 408 172 362 minecraft:polished_deepslate
fill 408 172 363 408 175 363 minecraft:gray_concrete
fill 409 172 362 409 175 362 minecraft:gray_concrete
fill 410 172 361 410 173 361 minecraft:gray_concrete
setblock 412 172 323 minecraft:polished_deepslate
setblock 412 172 363 minecraft:polished_deepslate
fill 413 172 323 413 175 323 minecraft:gray_concrete
setblock 413 172 362 minecraft:polished_deepslate
fill 413 172 363 413 175 363 minecraft:gray_concrete
setblock 414 172 361 minecraft:polished_deepslate
fill 414 172 362 414 175 362 minecraft:gray_concrete
setblock 415 172 340 minecraft:polished_deepslate
fill 415 172 341 415 175 341 minecraft:gray_concrete
setblock 415 172 344 minecraft:gray_concrete
setblock 415 172 345 minecraft:polished_deepslate
fill 415 172 346 415 174 347 minecraft:gray_concrete
setblock 415 172 360 minecraft:polished_deepslate
fill 415 172 361 415 173 361 minecraft:gray_concrete
setblock 415 172 364 minecraft:light_blue_stained_glass
setblock 416 172 339 minecraft:polished_deepslate
fill 416 172 340 416 175 340 minecraft:gray_concrete
setblock 416 172 344 minecraft:polished_deepslate
fill 416 172 345 416 175 345 minecraft:gray_concrete
setblock 416 172 349 minecraft:polished_deepslate
fill 416 172 350 416 175 350 minecraft:gray_concrete
setblock 416 172 354 minecraft:polished_deepslate
fill 416 172 355 416 173 355 minecraft:gray_concrete
setblock 416 172 359 minecraft:polished_deepslate
fill 416 172 360 416 175 360 minecraft:gray_concrete
setblock 417 172 323 minecraft:polished_deepslate
fill 417 172 324 417 175 324 minecraft:gray_concrete
setblock 417 172 334 minecraft:gray_concrete
setblock 417 172 338 minecraft:polished_deepslate
fill 417 172 339 417 175 339 minecraft:gray_concrete
setblock 417 172 343 minecraft:polished_deepslate
fill 417 172 344 417 175 344 minecraft:gray_concrete
setblock 417 172 348 minecraft:polished_deepslate
fill 417 172 349 417 175 349 minecraft:gray_concrete
setblock 417 172 353 minecraft:polished_deepslate
fill 417 172 354 417 175 354 minecraft:gray_concrete
setblock 417 172 358 minecraft:polished_deepslate
fill 417 172 359 417 175 359 minecraft:gray_concrete
setblock 417 172 363 minecraft:polished_deepslate
fill 376 173 341 376 184 341 minecraft:gray_wool
fill 376 173 342 376 173 343 minecraft:light_blue_stained_glass
fill 377 173 323 377 176 323 minecraft:gray_concrete
setblock 377 173 332 minecraft:polished_deepslate
fill 377 173 333 377 173 336 minecraft:gray_concrete
setblock 377 173 337 minecraft:polished_deepslate
fill 377 173 338 377 176 338 minecraft:gray_concrete
setblock 377 173 342 minecraft:polished_deepslate
fill 377 173 343 377 176 343 minecraft:gray_concrete
setblock 377 173 347 minecraft:polished_deepslate
fill 377 173 348 377 176 348 minecraft:gray_concrete
setblock 377 173 358 minecraft:gray_concrete
setblock 377 173 362 minecraft:polished_deepslate
fill 377 173 363 377 176 363 minecraft:gray_concrete
setblock 378 173 336 minecraft:polished_deepslate
fill 378 173 337 378 174 337 minecraft:gray_concrete
setblock 378 173 341 minecraft:polished_deepslate
fill 378 173 342 378 176 342 minecraft:gray_concrete
setblock 378 173 346 minecraft:polished_deepslate
setblock 379 173 340 minecraft:polished_deepslate
setblock 379 173 341 minecraft:gray_concrete
setblock 385 173 323 minecraft:gray_concrete
setblock 386 173 323 minecraft:polished_deepslate
fill 387 173 323 387 176 323 minecraft:gray_concrete
fill 387 173 363 387 176 363 minecraft:gray_concrete
setblock 390 173 324 minecraft:polished_deepslate
fill 390 173 362 391 173 362 minecraft:gray_concrete
setblock 391 173 323 minecraft:polished_deepslate
fill 391 173 324 391 176 324 minecraft:gray_concrete
setblock 391 173 363 minecraft:polished_deepslate
fill 392 173 323 392 176 323 minecraft:gray_concrete
fill 392 173 325 392 174 325 minecraft:gray_concrete
setblock 392 173 362 minecraft:polished_deepslate
fill 392 173 363 392 176 363 minecraft:gray_concrete
setblock 393 173 361 minecraft:polished_deepslate
fill 393 173 362 393 176 362 minecraft:gray_concrete
setblock 394 173 325 minecraft:polished_deepslate
fill 394 173 361 394 176 361 minecraft:gray_concrete
setblock 395 173 324 minecraft:polished_deepslate
fill 395 173 325 395 176 325 minecraft:gray_concrete
setblock 396 173 323 minecraft:polished_deepslate
fill 396 173 324 396 176 324 minecraft:gray_concrete
setblock 396 173 363 minecraft:polished_deepslate
fill 397 173 323 397 176 323 minecraft:gray_concrete
setblock 397 173 362 minecraft:polished_deepslate
fill 397 173 363 400 173 363 minecraft:gray_concrete
setblock 398 173 361 minecraft:polished_deepslate
fill 398 173 362 398 176 362 minecraft:gray_concrete
setblock 401 173 323 minecraft:polished_deepslate
setblock 401 173 363 minecraft:polished_deepslate
fill 402 173 323 402 176 323 minecraft:gray_concrete
setblock 402 173 362 minecraft:polished_deepslate
fill 402 173 363 402 176 363 minecraft:gray_concrete
fill 403 173 362 403 174 362 minecraft:gray_concrete
setblock 406 173 363 minecraft:polished_deepslate
setblock 407 173 362 minecraft:polished_deepslate
fill 407 173 363 407 176 363 minecraft:gray_concrete
fill 408 173 323 408 175 323 minecraft:gray_concrete
fill 408 173 362 408 176 362 minecraft:gray_concrete
setblock 411 173 323 minecraft:polished_deepslate
setblock 411 173 363 minecraft:polished_deepslate
fill 412 173 323 412 176 323 minecraft:gray_concrete
setblock 412 173 362 minecraft:polished_deepslate
fill 412 173 363 412 176 363 minecraft:gray_concrete
setblock 413 173 361 minecraft:polished_deepslate
fill 413 173 362 413 176 362 minecraft:gray_concrete
fill 414 173 361 414 174 361 minecraft:gray_concrete
setblock 415 173 339 minecraft:polished_deepslate
fill 415 173 340 415 176 340 minecraft:gray_concrete
setblock 415 173 344 minecraft:polished_deepslate
fill 415 173 345 415 176 345 minecraft:gray_concrete
setblock 415 173 359 minecraft:polished_deepslate
setblock 415 173 360 minecraft:gray_concrete
fill 415 173 364 415 180 364 minecraft:gray_wool
setblock 416 173 323 minecraft:polished_deepslate
setblock 416 173 338 minecraft:polished_deepslate
fill 416 173 339 416 176 339 minecraft:gray_concrete
setblock 416 173 343 minecraft:polished_deepslate
fill 416 173 344 416 176 344 minecraft:gray_concrete
setblock 416 173 348 minecraft:polished_deepslate
fill 416 173 349 416 176 349 minecraft:gray_concrete
setblock 416 173 354 minecraft:gray_concrete
setblock 416 173 358 minecraft:polished_deepslate
fill 416 173 359 416 174 359 minecraft:gray_concrete
setblock 416 173 363 minecraft:polished_deepslate
fill 417 173 323 417 176 323 minecraft:gray_concrete
setblock 417 173 337 minecraft:polished_deepslate
fill 417 173 338 417 176 338 minecraft:gray_concrete
setblock 417 173 342 minecraft:polished_deepslate
fill 417 173 343 417 176 343 minecraft:gray_concrete
setblock 417 173 347 minecraft:polished_deepslate
fill 417 173 348 417 176 348 minecraft:gray_concrete
setblock 417 173 352 minecraft:polished_deepslate
fill 417 173 353 417 176 353 minecraft:gray_concrete
setblock 417 173 357 minecraft:polished_deepslate
fill 417 173 358 417 176 358 minecraft:gray_concrete
setblock 417 173 362 minecraft:polished_deepslate
fill 417 173 363 417 176 363 minecraft:gray_concrete
fill 376 174 327 376 175 329 minecraft:gray_wool
setblock 376 174 330 minecraft:light_blue_stained_glass
fill 376 174 342 376 184 343 minecraft:gray_wool
setblock 377 174 326 minecraft:polished_deepslate
fill 377 174 327 377 177 327 minecraft:gray_concrete
fill 377 174 332 377 174 335 minecraft:gray_concrete
setblock 377 174 336 minecraft:polished_deepslate
fill 377 174 337 377 177 337 minecraft:gray_concrete
setblock 377 174 341 minecraft:polished_deepslate
fill 377 174 342 377 177 342 minecraft:gray_concrete
setblock 377 174 346 minecraft:polished_deepslate
fill 377 174 347 377 177 347 minecraft:gray_concrete
setblock 377 174 361 minecraft:polished_deepslate
fill 377 174 362 377 175 362 minecraft:gray_concrete
setblock 378 174 340 minecraft:polished_deepslate
fill 378 174 341 378 177 341 minecraft:gray_concrete
setblock 378 174 345 minecraft:polished_deepslate
fill 378 174 346 378 177 346 minecraft:gray_concrete
setblock 379 174 325 minecraft:light[level=13]
setblock 379 174 333 minecraft:light[level=13]
setblock 379 174 341 minecraft:light[level=13]
setblock 379 174 349 minecraft:light[level=13]
setblock 379 174 357 minecraft:light[level=13]
setblock 380 174 323 minecraft:polished_deepslate
fill 381 174 323 381 177 323 minecraft:gray_concrete
fill 381 174 338 381 179 338 minecraft:polished_deepslate
fill 383 174 323 384 174 323 minecraft:gray_concrete
setblock 385 174 323 minecraft:polished_deepslate
fill 386 174 323 386 177 323 minecraft:gray_concrete
setblock 387 174 325 minecraft:light[level=13]
setblock 387 174 333 minecraft:light[level=13]
setblock 387 174 341 minecraft:light[level=13]
setblock 387 174 349 minecraft:light[level=13]
setblock 387 174 357 minecraft:light[level=13]
setblock 388 174 324 minecraft:gray_concrete
setblock 389 174 324 minecraft:polished_deepslate
setblock 390 174 323 minecraft:polished_deepslate
fill 390 174 324 390 177 324 minecraft:gray_concrete
setblock 390 174 362 minecraft:gray_concrete
setblock 390 174 363 minecraft:polished_deepslate
fill 391 174 323 391 177 323 minecraft:gray_concrete
fill 391 174 325 391 175 325 minecraft:gray_concrete
setblock 391 174 362 minecraft:polished_deepslate
fill 391 174 363 391 177 363 minecraft:gray_concrete
fill 392 174 362 392 177 362 minecraft:gray_concrete
setblock 393 174 324 minecraft:gray_concrete
setblock 393 174 325 minecraft:polished_deepslate
fill 393 174 361 393 177 361 minecraft:gray_concrete
setblock 394 174 324 minecraft:polished_deepslate
fill 394 174 325 394 177 325 minecraft:gray_concrete
setblock 395 174 323 minecraft:polished_deepslate
fill 395 174 324 395 177 324 minecraft:gray_concrete
setblock 395 174 333 minecraft:light[level=13]
setblock 395 174 341 minecraft:light[level=13]
setblock 395 174 349 minecraft:light[level=13]
setblock 395 174 357 minecraft:light[level=13]
setblock 395 174 363 minecraft:polished_deepslate
fill 396 174 323 396 177 323 minecraft:gray_concrete
setblock 396 174 362 minecraft:polished_deepslate
fill 396 174 363 399 174 363 minecraft:gray_concrete
setblock 397 174 361 minecraft:polished_deepslate
fill 397 174 362 397 177 362 minecraft:gray_concrete
setblock 399 174 324 minecraft:polished_deepslate
setblock 400 174 323 minecraft:polished_deepslate
setblock 400 174 363 minecraft:polished_deepslate
fill 401 174 323 401 177 323 minecraft:gray_concrete
setblock 401 174 362 minecraft:polished_deepslate
fill 401 174 363 401 177 363 minecraft:gray_concrete
setblock 402 174 362 minecraft:gray_concrete
setblock 403 174 325 minecraft:light[level=13]
setblock 403 174 333 minecraft:light[level=13]
setblock 403 174 341 minecraft:light[level=13]
setblock 403 174 349 minecraft:light[level=13]
setblock 403 174 357 minecraft:light[level=13]
setblock 404 174 323 minecraft:gray_concrete
setblock 405 174 363 minecraft:polished_deepslate
setblock 406 174 362 minecraft:polished_deepslate
fill 406 174 363 406 177 363 minecraft:gray_concrete
fill 407 174 323 407 176 323 minecraft:gray_concrete
fill 407 174 362 407 177 362 minecraft:gray_concrete
setblock 410 174 323 minecraft:polished_deepslate
setblock 410 174 363 minecraft:polished_deepslate
fill 411 174 323 411 177 323 minecraft:gray_concrete
setblock 411 174 325 minecraft:light[level=13]
setblock 411 174 333 minecraft:light[level=13]
setblock 411 174 341 minecraft:light[level=13]
setblock 411 174 349 minecraft:light[level=13]
setblock 411 174 357 minecraft:light[level=13]
setblock 411 174 362 minecraft:polished_deepslate
fill 411 174 363 411 177 363 minecraft:gray_concrete
setblock 412 174 361 minecraft:polished_deepslate
fill 412 174 362 412 177 362 minecraft:gray_concrete
fill 413 174 361 413 175 361 minecraft:gray_concrete
setblock 415 174 323 minecraft:polished_deepslate
setblock 415 174 343 minecraft:polished_deepslate
fill 415 174 344 415 177 344 minecraft:gray_concrete
setblock 415 174 348 minecraft:polished_deepslate
setblock 415 174 363 minecraft:polished_deepslate
fill 416 174 323 416 177 323 minecraft:gray_concrete
setblock 416 174 337 minecraft:polished_deepslate
fill 416 174 338 416 177 338 minecraft:gray_concrete
setblock 416 174 342 minecraft:polished_deepslate
fill 416 174 343 416 177 343 minecraft:gray_concrete
setblock 416 174 347 minecraft:polished_deepslate
fill 416 174 348 416 177 348 minecraft:gray_concrete
setblock 416 174 358 minecraft:gray_concrete
setblock 416 174 362 minecraft:polished_deepslate
fill 416 174 363 416 177 363 minecraft:gray_concrete
setblock 417 174 336 minecraft:polished_deepslate
fill 417 174 337 417 177 337 minecraft:gray_concrete
setblock 417 174 341 minecraft:polished_deepslate
fill 417 174 342 417 177 342 minecraft:gray_concrete
setblock 417 174 346 minecraft:polished_deepslate
fill 417 174 347 417 177 347 minecraft:gray_concrete
setblock 417 174 351 minecraft:polished_deepslate
fill 417 174 352 417 177 352 minecraft:gray_concrete
setblock 417 174 356 minecraft:polished_deepslate
fill 417 174 357 417 175 357 minecraft:gray_concrete
setblock 417 174 361 minecraft:polished_deepslate
fill 417 174 362 417 177 362 minecraft:gray_concrete
fill 376 175 330 376 184 330 minecraft:gray_wool
setblock 376 175 337 minecraft:light_blue_stained_glass
setblock 377 175 325 minecraft:polished_deepslate
fill 377 175 326 377 178 326 minecraft:gray_concrete
fill 377 175 328 377 175 329 minecraft:gray_concrete
fill 377 175 333 377 175 334 minecraft:gray_concrete
setblock 377 175 335 minecraft:polished_deepslate
fill 377 175 336 377 178 336 minecraft:gray_concrete
setblock 377 175 340 minecraft:polished_deepslate
fill 377 175 341 377 178 341 minecraft:gray_concrete
setblock 377 175 345 minecraft:polished_deepslate
fill 377 175 346 377 178 346 minecraft:gray_concrete
setblock 378 175 339 minecraft:polished_deepslate
fill 378 175 340 378 178 340 minecraft:gray_concrete
setblock 378 175 344 minecraft:polished_deepslate
fill 378 175 345 378 178 345 minecraft:gray_concrete
setblock 379 175 323 minecraft:polished_deepslate
fill 380 175 323 380 178 323 minecraft:gray_concrete
fill 382 175 323 383 175 323 minecraft:gray_concrete
setblock 384 175 323 minecraft:polished_deepslate
fill 385 175 323 385 178 323 minecraft:gray_concrete
fill 386 175 324 387 175 324 minecraft:gray_concrete
fill 386 175 363 386 177 363 minecraft:gray_concrete
setblock 388 175 324 minecraft:polished_deepslate
setblock 389 175 323 minecraft:polished_deepslate
fill 389 175 324 389 177 325 minecraft:gray_concrete
setblock 389 175 362 minecraft:gray_concrete
setblock 389 175 363 minecraft:polished_deepslate
fill 390 175 323 390 178 323 minecraft:gray_concrete
fill 390 175 325 390 176 325 minecraft:gray_concrete
setblock 390 175 362 minecraft:polished_deepslate
fill 390 175 363 390 178 363 minecraft:gray_concrete
fill 391 175 362 391 178 362 minecraft:gray_concrete
fill 392 175 322 392 184 322 minecraft:gray_wool
setblock 392 175 325 minecraft:polished_deepslate
setblock 393 175 322 minecraft:light_blue_stained_glass
setblock 393 175 324 minecraft:polished_deepslate
fill 393 175 325 393 178 325 minecraft:gray_concrete
fill 394 175 322 395 184 322 minecraft:gray_wool
setblock 394 175 323 minecraft:polished_deepslate
fill 394 175 324 394 178 324 minecraft:gray_concrete
setblock 394 175 363 minecraft:polished_deepslate
fill 395 175 323 395 178 323 minecraft:gray_concrete
setblock 395 175 362 minecraft:polished_deepslate
fill 395 175 363 398 175 363 minecraft:gray_concrete
fill 396 175 362 396 178 362 minecraft:gray_concrete
setblock 398 175 324 minecraft:polished_deepslate
setblock 399 175 323 minecraft:polished_deepslate
fill 399 175 324 399 178 324 minecraft:gray_concrete
fill 399 175 357 399 176 357 minecraft:gray_wool
setblock 399 175 363 minecraft:polished_deepslate
fill 400 175 323 400 178 323 minecraft:gray_concrete
setblock 400 175 362 minecraft:polished_deepslate
fill 400 175 363 400 178 363 minecraft:gray_concrete
fill 401 175 362 401 176 362 minecraft:gray_concrete
setblock 403 175 364 minecraft:light_blue_stained_glass
setblock 404 175 323 minecraft:polished_deepslate
setblock 404 175 363 minecraft:polished_deepslate
fill 404 175 364 405 180 364 minecraft:gray_wool
fill 405 175 323 406 177 323 minecraft:gray_concrete
setblock 405 175 362 minecraft:polished_deepslate
fill 405 175 363 405 178 363 minecraft:gray_concrete
fill 406 175 362 406 178 362 minecraft:gray_concrete
setblock 409 175 323 minecraft:polished_deepslate
setblock 409 175 363 minecraft:polished_deepslate
fill 410 175 323 410 178 323 minecraft:gray_concrete
setblock 410 175 362 minecraft:polished_deepslate
fill 410 175 363 410 178 363 minecraft:gray_concrete
setblock 411 175 361 minecraft:polished_deepslate
fill 411 175 362 411 178 362 minecraft:gray_concrete
fill 412 175 361 412 176 361 minecraft:gray_concrete
setblock 414 175 323 minecraft:polished_deepslate
setblock 414 175 363 minecraft:polished_deepslate
fill 415 175 323 415 178 323 minecraft:gray_concrete
setblock 415 175 342 minecraft:polished_deepslate
fill 415 175 343 415 178 343 minecraft:gray_concrete
setblock 415 175 346 minecraft:gray_concrete
setblock 415 175 347 minecraft:polished_deepslate
fill 415 175 348 415 178 348 minecraft:gray_concrete
setblock 415 175 362 minecraft:polished_deepslate
fill 415 175 363 415 178 363 minecraft:gray_concrete
setblock 416 175 341 minecraft:polished_deepslate
fill 416 175 342 416 178 342 minecraft:gray_concrete
setblock 416 175 346 minecraft:polished_deepslate
fill 416 175 347 416 178 347 minecraft:gray_concrete
setblock 416 175 351 minecraft:polished_deepslate
setblock 416 175 361 minecraft:polished_deepslate
fill 416 175 362 416 176 362 minecraft:gray_concrete
fill 417 175 336 417 178 336 minecraft:gray_concrete
setblock 417 175 340 minecraft:polished_deepslate
fill 417 175 341 417 178 341 minecraft:gray_concrete
setblock 417 175 345 minecraft:polished_deepslate
fill 417 175 346 417 178 346 minecraft:gray_concrete
setblock 417 175 350 minecraft:polished_deepslate
fill 417 175 351 417 178 351 minecraft:gray_concrete
setblock 417 175 355 minecraft:polished_deepslate
setblock 417 175 356 minecraft:gray_concrete
setblock 417 175 360 minecraft:polished_deepslate
fill 417 175 361 417 177 361 minecraft:gray_concrete
setblock 376 176 327 minecraft:light_blue_stained_glass
fill 376 176 328 376 184 329 minecraft:gray_wool
fill 376 176 337 376 184 337 minecraft:gray_wool
setblock 377 176 324 minecraft:polished_deepslate
fill 377 176 325 377 179 325 minecraft:gray_concrete
setblock 377 176 328 minecraft:gray_concrete
setblock 377 176 329 minecraft:polished_deepslate
fill 377 176 330 377 176 333 minecraft:gray_concrete
setblock 377 176 334 minecraft:polished_deepslate
fill 377 176 335 377 179 335 minecraft:gray_concrete
setblock 377 176 339 minecraft:polished_deepslate
fill 377 176 340 377 179 340 minecraft:gray_concrete
setblock 377 176 344 minecraft:polished_deepslate
fill 377 176 345 377 179 345 minecraft:gray_concrete
setblock 377 176 349 minecraft:polished_deepslate
fill 377 176 350 377 179 350 minecraft:gray_concrete
setblock 378 176 323 minecraft:polished_deepslate
setblock 378 176 338 minecraft:polished_deepslate
fill 378 176 339 378 177 339 minecraft:gray_concrete
setblock 378 176 343 minecraft:polished_deepslate
fill 378 176 344 378 179 344 minecraft:gray_concrete
fill 379 176 323 379 179 323 minecraft:gray_concrete
setblock 379 176 325 minecraft:light[level=12]
setblock 379 176 332 minecraft:light[level=12]
setblock 379 176 339 minecraft:light[level=12]
setblock 379 176 346 minecraft:light[level=12]
setblock 379 176 353 minecraft:light[level=12]
setblock 379 176 360 minecraft:light[level=12]
setblock 379 176 364 minecraft:light_blue_stained_glass
setblock 382 176 323 minecraft:gray_concrete
setblock 383 176 323 minecraft:polished_deepslate
fill 384 176 323 384 179 323 minecraft:gray_concrete
fill 385 176 324 386 176 324 minecraft:gray_concrete
setblock 386 176 325 minecraft:light[level=12]
setblock 386 176 332 minecraft:light[level=12]
setblock 386 176 339 minecraft:light[level=12]
setblock 386 176 346 minecraft:light[level=12]
setblock 386 176 353 minecraft:light[level=12]
setblock 386 176 360 minecraft:light[level=12]
setblock 387 176 324 minecraft:polished_deepslate
setblock 388 176 323 minecraft:polished_deepslate
fill 388 176 324 388 178 325 minecraft:gray_concrete
setblock 388 176 363 minecraft:polished_deepslate
fill 389 176 323 389 179 323 minecraft:gray_concrete
setblock 389 176 362 minecraft:polished_deepslate
fill 389 176 363 389 179 363 minecraft:gray_concrete
fill 390 176 362 390 179 362 minecraft:gray_concrete
setblock 391 176 325 minecraft:polished_deepslate
setblock 392 176 324 minecraft:polished_deepslate
fill 392 176 325 392 179 325 minecraft:gray_concrete
fill 393 176 322 393 184 322 minecraft:gray_wool
setblock 393 176 323 minecraft:polished_deepslate
fill 393 176 324 393 179 324 minecraft:gray_concrete
setblock 393 176 332 minecraft:light[level=12]
setblock 393 176 339 minecraft:light[level=12]
setblock 393 176 346 minecraft:light[level=12]
setblock 393 176 353 minecraft:light[level=12]
setblock 393 176 360 minecraft:light[level=12]
setblock 393 176 363 minecraft:polished_deepslate
fill 394 176 323 394 179 323 minecraft:gray_concrete
setblock 394 176 362 minecraft:polished_deepslate
fill 394 176 363 397 176 363 minecraft:gray_concrete
fill 395 176 362 395 179 362 minecraft:gray_concrete
setblock 396 176 325 minecraft:polished_deepslate
setblock 397 176 324 minecraft:polished_deepslate
setblock 398 176 323 minecraft:polished_deepslate
fill 398 176 324 398 179 324 minecraft:gray_concrete
setblock 398 176 363 minecraft:polished_deepslate
fill 399 176 323 399 179 323 minecraft:gray_concrete
setblock 399 176 362 minecraft:polished_deepslate
fill 399 176 363 399 179 363 minecraft:gray_concrete
setblock 400 176 325 minecraft:light[level=12]
setblock 400 176 332 minecraft:light[level=12]
setblock 400 176 339 minecraft:light[level=12]
setblock 400 176 346 minecraft:light[level=12]
setblock 400 176 353 minecraft:light[level=12]
setblock 400 176 360 minecraft:light[level=12]
fill 400 176 362 400 178 362 minecraft:gray_concrete
setblock 403 176 323 minecraft:polished_deepslate
setblock 403 176 363 minecraft:polished_deepslate
fill 403 176 364 403 184 364 minecraft:gray_wool
fill 404 176 323 404 179 323 minecraft:gray_concrete
fill 404 176 363 404 179 363 minecraft:gray_concrete
fill 405 176 362 405 179 362 minecraft:gray_concrete
setblock 407 176 325 minecraft:light[level=12]
setblock 407 176 332 minecraft:light[level=12]
setblock 407 176 339 minecraft:light[level=12]
setblock 407 176 346 minecraft:light[level=12]
setblock 407 176 353 minecraft:light[level=12]
setblock 407 176 360 minecraft:light[level=12]
setblock 408 176 323 minecraft:polished_deepslate
setblock 408 176 363 minecraft:polished_deepslate
fill 409 176 323 409 179 323 minecraft:gray_concrete
setblock 409 176 362 minecraft:polished_deepslate
fill 409 176 363 409 179 363 minecraft:gray_concrete
fill 410 176 324 411 176 324 minecraft:gray_concrete
fill 410 176 362 410 179 362 minecraft:gray_concrete
fill 411 176 361 411 177 361 minecraft:gray_concrete
setblock 412 176 324 minecraft:polished_deepslate
setblock 413 176 323 minecraft:polished_deepslate
fill 413 176 324 414 178 324 minecraft:gray_concrete
setblock 413 176 363 minecraft:polished_deepslate
fill 414 176 323 414 179 323 minecraft:gray_concrete
setblock 414 176 325 minecraft:light[level=12]
setblock 414 176 332 minecraft:light[level=12]
setblock 414 176 339 minecraft:light[level=12]
fill 414 176 343 414 176 346 minecraft:gray_concrete
setblock 414 176 353 minecraft:light[level=12]
setblock 414 176 360 minecraft:light[level=12]
setblock 414 176 362 minecraft:polished_deepslate
fill 414 176 363 414 179 363 minecraft:gray_concrete
setblock 415 176 341 minecraft:polished_deepslate
fill 415 176 342 415 179 342 minecraft:gray_concrete
setblock 415 176 346 minecraft:polished_deepslate
fill 415 176 347 415 179 347 minecraft:gray_concrete
fill 415 176 349 415 177 349 minecraft:gray_concrete
fill 415 176 362 415 178 362 minecraft:gray_concrete
setblock 416 176 340 minecraft:polished_deepslate
fill 416 176 341 416 179 341 minecraft:gray_concrete
setblock 416 176 345 minecraft:polished_deepslate
fill 416 176 346 416 179 346 minecraft:gray_concrete
setblock 416 176 350 minecraft:polished_deepslate
fill 416 176 351 416 179 351 minecraft:gray_concrete
setblock 417 176 324 minecraft:polished_deepslate
fill 417 176 325 417 179 325 minecraft:gray_concrete
setblock 417 176 339 minecraft:polished_deepslate
fill 417 176 340 417 179 340 minecraft:gray_concrete
setblock 417 176 344 minecraft:polished_deepslate
fill 417 176 345 417 179 345 minecraft:gray_concrete
setblock 417 176 349 minecraft:polished_deepslate
fill 417 176 350 417 179 350 minecraft:gray_concrete
setblock 417 176 354 minecraft:polished_deepslate
setblock 417 176 359 minecraft:polished_deepslate
fill 417 176 360 417 177 360 minecraft:gray_concrete
fill 376 177 327 376 184 327 minecraft:gray_wool
setblock 377 177 323 minecraft:polished_deepslate
fill 377 177 324 378 179 324 minecraft:gray_concrete
setblock 377 177 328 minecraft:polished_deepslate
fill 377 177 329 377 177 332 minecraft:gray_concrete
setblock 377 177 333 minecraft:polished_deepslate
fill 377 177 334 377 180 334 minecraft:gray_concrete
setblock 377 177 338 minecraft:polished_deepslate
fill 377 177 339 377 180 339 minecraft:gray_concrete
setblock 377 177 343 minecraft:polished_deepslate
fill 377 177 344 377 180 344 minecraft:gray_concrete
setblock 377 177 348 minecraft:polished_deepslate
fill 377 177 349 377 180 349 minecraft:gray_concrete
fill 378 177 323 378 180 323 minecraft:gray_concrete
setblock 378 177 342 minecraft:polished_deepslate
fill 378 177 343 378 180 343 minecraft:gray_concrete
setblock 378 177 347 minecraft:polished_deepslate
fill 379 177 364 379 182 364 minecraft:gray_wool
setblock 382 177 323 minecraft:polished_deepslate
fill 383 177 323 383 179 324 minecraft:gray_concrete
fill 384 177 324 385 177 324 minecraft:gray_concrete
fill 385 177 363 385 178 363 minecraft:gray_concrete
setblock 386 177 324 minecraft:polished_deepslate
fill 386 177 325 387 179 325 minecraft:gray_concrete
setblock 387 177 323 minecraft:polished_deepslate
fill 387 177 324 387 180 324 minecraft:gray_concrete
setblock 387 177 363 minecraft:polished_deepslate
fill 388 177 323 388 180 323 minecraft:gray_concrete
setblock 388 177 362 minecraft:polished_deepslate
fill 388 177 363 388 180 363 minecraft:gray_concrete
fill 389 177 362 389 180 362 minecraft:gray_concrete
setblock 390 177 325 minecraft:polished_deepslate
fill 390 177 326 393 177 326 minecraft:gray_concrete
setblock 391 177 324 minecraft:polished_deepslate
fill 391 177 325 391 180 325 minecraft:gray_concrete
setblock 392 177 323 minecraft:polished_deepslate
fill 392 177 324 392 180 324 minecraft:gray_concrete
fill 392 177 361 392 178 361 minecraft:gray_concrete
setblock 392 177 363 minecraft:polished_deepslate
fill 393 177 323 393 180 323 minecraft:gray_concrete
setblock 393 177 362 minecraft:polished_deepslate
fill 393 177 363 396 177 363 minecraft:gray_concrete
setblock 394 177 361 minecraft:polished_deepslate
fill 394 177 362 394 180 362 minecraft:gray_concrete
setblock 395 177 325 minecraft:polished_deepslate
setblock 396 177 324 minecraft:polished_deepslate
fill 396 177 325 396 180 325 minecraft:gray_concrete
setblock 397 177 323 minecraft:polished_deepslate
fill 397 177 324 397 180 324 minecraft:gray_concrete
setblock 397 177 363 minecraft:polished_deepslate
fill 398 177 323 398 180 323 minecraft:gray_concrete
setblock 398 177 362 minecraft:polished_deepslate
fill 398 177 363 398 180 363 minecraft:gray_concrete
fill 399 177 362 399 179 362 minecraft:gray_concrete
setblock 402 177 323 minecraft:polished_deepslate
setblock 402 177 363 minecraft:polished_deepslate
fill 403 177 323 403 180 323 minecraft:gray_concrete
fill 403 177 363 403 180 363 minecraft:gray_concrete
setblock 407 177 323 minecraft:polished_deepslate
setblock 407 177 363 minecraft:polished_deepslate
fill 408 177 323 408 179 324 minecraft:gray_concrete
setblock 408 177 362 minecraft:polished_deepslate
fill 408 177 363 408 180 363 minecraft:gray_concrete
fill 409 177 324 410 177 324 minecraft:gray_concrete
fill 409 177 362 409 180 362 minecraft:gray_concrete
setblock 411 177 324 minecraft:polished_deepslate
setblock 412 177 323 minecraft:polished_deepslate
fill 412 177 324 412 180 324 minecraft:gray_concrete
setblock 412 177 363 minecraft:polished_deepslate
fill 413 177 323 413 180 323 minecraft:gray_concrete
setblock 413 177 362 minecraft:polished_deepslate
fill 413 177 363 413 180 363 minecraft:gray_concrete
fill 414 177 343 414 177 345 minecraft:gray_concrete
setblock 414 177 346 minecraft:polished_deepslate
fill 414 177 347 414 179 348 minecraft:gray_concrete
fill 414 177 362 414 179 362 minecraft:gray_concrete
setblock 415 177 324 minecraft:gray_concrete
setblock 415 177 340 minecraft:polished_deepslate
fill 415 177 341 415 180 341 minecraft:gray_concrete
setblock 415 177 345 minecraft:polished_deepslate
fill 415 177 346 415 180 346 minecraft:gray_concrete
setblock 415 177 350 minecraft:polished_deepslate
setblock 416 177 339 minecraft:polished_deepslate
fill 416 177 340 416 180 340 minecraft:gray_concrete
setblock 416 177 344 minecraft:polished_deepslate
fill 416 177 345 416 180 345 minecraft:gray_concrete
setblock 416 177 349 minecraft:polished_deepslate
fill 416 177 350 416 180 350 minecraft:gray_concrete
fill 416 177 352 416 178 352 minecraft:gray_concrete
setblock 417 177 323 minecraft:polished_deepslate
fill 417 177 324 417 180 324 minecraft:gray_concrete
fill 417 177 326 417 177 327 minecraft:gray_concrete
setblock 417 177 338 minecraft:polished_deepslate
fill 417 177 339 417 180 339 minecraft:gray_concrete
setblock 417 177 343 minecraft:polished_deepslate
fill 417 177 344 417 180 344 minecraft:gray_concrete
setblock 417 177 348 minecraft:polished_deepslate
fill 417 177 349 417 180 349 minecraft:gray_concrete
setblock 417 177 353 minecraft:polished_deepslate
fill 417 177 354 417 180 354 minecraft:gray_concrete
setblock 417 177 363 minecraft:polished_deepslate
fill 418 177 348 418 181 348 minecraft:gray_wool
setblock 418 177 349 minecraft:light_blue_stained_glass
setblock 376 178 349 minecraft:light_blue_stained_glass
fill 376 178 350 376 181 350 minecraft:gray_wool
fill 377 178 323 377 181 323 minecraft:gray_concrete
setblock 377 178 327 minecraft:polished_deepslate
fill 377 178 328 377 178 331 minecraft:gray_concrete
setblock 377 178 332 minecraft:polished_deepslate
fill 377 178 333 377 181 333 minecraft:gray_concrete
setblock 377 178 337 minecraft:polished_deepslate
fill 377 178 338 377 181 338 minecraft:gray_concrete
setblock 377 178 342 minecraft:polished_deepslate
fill 377 178 343 377 181 343 minecraft:gray_concrete
setblock 377 178 347 minecraft:polished_deepslate
fill 377 178 348 377 181 348 minecraft:gray_concrete
setblock 378 178 325 minecraft:gray_concrete
setblock 378 178 326 minecraft:polished_deepslate
fill 378 178 327 378 181 327 minecraft:gray_concrete
setblock 378 178 341 minecraft:polished_deepslate
fill 378 178 342 378 180 342 minecraft:gray_concrete
setblock 378 178 346 minecraft:polished_deepslate
fill 378 178 347 378 181 347 minecraft:gray_concrete
setblock 379 178 324 minecraft:gray_concrete
setblock 380 178 324 minecraft:polished_deepslate
fill 380 178 338 380 179 338 minecraft:polished_deepslate
setblock 381 178 323 minecraft:polished_deepslate
fill 381 178 324 382 180 324 minecraft:gray_concrete
fill 381 178 337 381 179 337 minecraft:polished_deepslate
fill 381 178 339 381 179 339 minecraft:polished_deepslate
fill 382 178 323 382 181 323 minecraft:gray_concrete
fill 382 178 338 382 179 338 minecraft:polished_deepslate
setblock 384 178 324 minecraft:gray_concrete
fill 384 178 363 384 179 363 minecraft:gray_concrete
setblock 385 178 324 minecraft:polished_deepslate
fill 385 178 325 385 181 325 minecraft:gray_concrete
setblock 386 178 323 minecraft:polished_deepslate
fill 386 178 324 386 181 324 minecraft:gray_concrete
setblock 386 178 363 minecraft:polished_deepslate
fill 387 178 323 387 181 323 minecraft:gray_concrete
setblock 387 178 362 minecraft:polished_deepslate
fill 387 178 363 387 181 363 minecraft:gray_concrete
setblock 388 178 326 minecraft:polished_deepslate
fill 388 178 362 388 181 362 minecraft:gray_concrete
setblock 389 178 324 minecraft:gray_concrete
setblock 389 178 325 minecraft:polished_deepslate
fill 389 178 326 392 178 326 minecraft:gray_concrete
setblock 390 178 324 minecraft:polished_deepslate
fill 390 178 325 390 181 325 minecraft:gray_concrete
setblock 391 178 323 minecraft:polished_deepslate
fill 391 178 324 391 181 324 minecraft:gray_concrete
setblock 391 178 363 minecraft:polished_deepslate
fill 392 178 323 392 181 323 minecraft:gray_concrete
setblock 392 178 362 minecraft:polished_deepslate
fill 392 178 363 395 178 363 minecraft:gray_concrete
setblock 393 178 326 minecraft:polished_deepslate
setblock 393 178 361 minecraft:polished_deepslate
fill 393 178 362 393 181 362 minecraft:gray_concrete
setblock 394 178 325 minecraft:polished_deepslate
fill 394 178 326 394 181 326 minecraft:gray_concrete
setblock 395 178 324 minecraft:polished_deepslate
fill 395 178 325 395 181 325 minecraft:gray_concrete
setblock 396 178 323 minecraft:polished_deepslate
fill 396 178 324 396 181 324 minecraft:gray_concrete
setblock 396 178 363 minecraft:polished_deepslate
fill 397 178 323 397 181 323 minecraft:gray_concrete
fill 397 178 325 397 179 325 minecraft:gray_concrete
setblock 397 178 362 minecraft:polished_deepslate
fill 397 178 363 397 181 363 minecraft:gray_concrete
fill 398 178 362 398 180 362 minecraft:gray_concrete
setblock 400 178 324 minecraft:polished_deepslate
setblock 401 178 323 minecraft:polished_deepslate
setblock 401 178 363 minecraft:polished_deepslate
fill 402 178 323 402 181 323 minecraft:gray_concrete
fill 402 178 363 402 181 363 minecraft:gray_concrete
fill 404 178 362 404 180 362 minecraft:gray_concrete
setblock 405 178 323 minecraft:gray_concrete
setblock 406 178 323 minecraft:polished_deepslate
fill 406 178 324 407 180 324 minecraft:gray_concrete
setblock 406 178 363 minecraft:polished_deepslate
fill 407 178 323 407 181 323 minecraft:gray_concrete
setblock 407 178 362 minecraft:polished_deepslate
fill 407 178 363 407 181 363 minecraft:gray_concrete
fill 408 178 362 408 181 362 minecraft:gray_concrete
setblock 409 178 324 minecraft:gray_concrete
setblock 410 178 324 minecraft:polished_deepslate
setblock 411 178 323 minecraft:polished_deepslate
fill 411 178 324 411 181 324 minecraft:gray_concrete
setblock 411 178 363 minecraft:polished_deepslate
fill 412 178 323 412 181 323 minecraft:gray_concrete
setblock 412 178 362 minecraft:polished_deepslate
fill 412 178 363 412 181 363 minecraft:gray_concrete
fill 413 178 362 413 180 362 minecraft:gray_concrete
fill 414 178 343 414 178 344 minecraft:gray_concrete
setblock 414 178 345 minecraft:polished_deepslate
fill 414 178 346 414 181 346 minecraft:gray_concrete
setblock 414 178 349 minecraft:gray_concrete
setblock 415 178 324 minecraft:polished_deepslate
setblock 415 178 340 minecraft:gray_concrete
setblock 415 178 344 minecraft:polished_deepslate
fill 415 178 345 415 181 345 minecraft:gray_concrete
setblock 415 178 349 minecraft:polished_deepslate
fill 415 178 350 415 180 351 minecraft:gray_concrete
setblock 416 178 323 minecraft:polished_deepslate
fill 416 178 339 416 180 339 minecraft:gray_concrete
setblock 416 178 343 minecraft:polished_deepslate
fill 416 178 344 416 181 344 minecraft:gray_concrete
setblock 416 178 348 minecraft:polished_deepslate
fill 416 178 349 416 181 349 minecraft:gray_concrete
setblock 416 178 363 minecraft:polished_deepslate
fill 417 178 323 417 181 323 minecraft:gray_concrete
setblock 417 178 326 minecraft:gray_concrete
setblock 417 178 327 minecraft:polished_deepslate
fill 417 178 328 417 181 328 minecraft:gray_concrete
setblock 417 178 337 minecraft:polished_deepslate
fill 417 178 338 417 181 338 minecraft:gray_concrete
setblock 417 178 342 minecraft:polished_deepslate
fill 417 178 343 417 181 343 minecraft:gray_concrete
setblock 417 178 347 minecraft:polished_deepslate
fill 417 178 348 417 181 348 minecraft:gray_concrete
setblock 417 178 352 minecraft:polished_deepslate
fill 417 178 353 417 181 353 minecraft:gray_concrete
setblock 417 178 362 minecraft:polished_deepslate
fill 417 178 363 417 179 363 minecraft:gray_concrete
fill 418 178 349 418 184 349 minecraft:gray_wool
setblock 376 179 331 minecraft:light_blue_stained_glass
fill 376 179 349 376 180 349 minecraft:gray_wool
setblock 377 179 326 minecraft:polished_deepslate
fill 377 179 327 377 179 330 minecraft:gray_concrete
setblock 377 179 331 minecraft:polished_deepslate
fill 377 179 332 377 182 332 minecraft:gray_concrete
setblock 377 179 336 minecraft:polished_deepslate
fill 377 179 337 377 182 337 minecraft:gray_concrete
setblock 377 179 341 minecraft:polished_deepslate
fill 377 179 342 377 182 342 minecraft:gray_concrete
setblock 377 179 346 minecraft:polished_deepslate
fill 377 179 347 377 182 347 minecraft:gray_concrete
setblock 377 179 351 minecraft:polished_deepslate
setblock 378 179 325 minecraft:polished_deepslate
fill 378 179 326 378 182 326 minecraft:gray_concrete
fill 378 179 328 378 179 329 minecraft:gray_concrete
setblock 378 179 341 minecraft:gray_concrete
setblock 378 179 345 minecraft:polished_deepslate
fill 378 179 346 378 181 346 minecraft:gray_concrete
setblock 379 179 324 minecraft:polished_deepslate
setblock 380 179 323 minecraft:polished_deepslate
fill 380 179 324 380 182 324 minecraft:gray_concrete
fill 381 179 323 381 182 323 minecraft:gray_concrete
setblock 383 179 325 minecraft:polished_deepslate
setblock 384 179 324 minecraft:polished_deepslate
fill 384 179 325 384 182 325 minecraft:gray_concrete
setblock 385 179 323 minecraft:polished_deepslate
fill 385 179 324 385 182 324 minecraft:gray_concrete
setblock 385 179 363 minecraft:polished_deepslate
fill 386 179 323 386 182 323 minecraft:gray_concrete
setblock 386 179 326 minecraft:gray_concrete
fill 386 179 363 386 182 363 minecraft:gray_concrete
setblock 387 179 326 minecraft:polished_deepslate
fill 387 179 362 387 182 362 minecraft:gray_concrete
setblock 388 179 324 minecraft:gray_concrete
setblock 388 179 325 minecraft:polished_deepslate
fill 388 179 326 391 179 326 minecraft:gray_concrete
setblock 389 179 324 minecraft:polished_deepslate
fill 389 179 325 389 182 325 minecraft:gray_concrete
setblock 390 179 323 minecraft:polished_deepslate
fill 390 179 324 390 182 324 minecraft:gray_concrete
setblock 390 179 363 minecraft:polished_deepslate
fill 391 179 323 391 182 323 minecraft:gray_concrete
setblock 391 179 361 minecraft:gray_concrete
setblock 391 179 362 minecraft:polished_deepslate
fill 391 179 363 394 179 363 minecraft:gray_concrete
setblock 392 179 326 minecraft:polished_deepslate
setblock 392 179 361 minecraft:polished_deepslate
fill 392 179 362 392 182 362 minecraft:gray_concrete
setblock 393 179 325 minecraft:polished_deepslate
fill 393 179 326 393 182 326 minecraft:gray_concrete
setblock 393 179 361 minecraft:gray_concrete
setblock 394 179 324 minecraft:polished_deepslate
fill 394 179 325 394 182 325 minecraft:gray_concrete
setblock 395 179 323 minecraft:polished_deepslate
fill 395 179 324 395 182 324 minecraft:gray_concrete
setblock 395 179 363 minecraft:polished_deepslate
fill 396 179 323 396 182 323 minecraft:gray_concrete
setblock 396 179 362 minecraft:polished_deepslate
fill 396 179 363 396 182 363 minecraft:gray_concrete
fill 397 179 362 397 181 362 minecraft:gray_concrete
setblock 399 179 324 minecraft:polished_deepslate
setblock 400 179 323 minecraft:polished_deepslate
fill 400 179 324 400 180 324 minecraft:gray_concrete
setblock 400 179 363 minecraft:polished_deepslate
fill 401 179 323 401 182 323 minecraft:gray_concrete
fill 401 179 363 401 182 363 minecraft:gray_concrete
setblock 403 179 322 minecraft:light_blue_stained_glass
setblock 405 179 323 minecraft:polished_deepslate
fill 405 179 324 405 182 324 minecraft:gray_concrete
setblock 405 179 363 minecraft:polished_deepslate
fill 406 179 323 406 182 323 minecraft:gray_concrete
setblock 406 179 362 minecraft:polished_deepslate
fill 406 179 363 406 182 363 minecraft:gray_concrete
fill 407 179 362 407 182 362 minecraft:gray_concrete
setblock 409 179 324 minecraft:polished_deepslate
setblock 410 179 323 minecraft:polished_deepslate
fill 410 179 324 410 182 324 minecraft:gray_concrete
setblock 410 179 363 minecraft:polished_deepslate
fill 411 179 323 411 182 323 minecraft:gray_concrete
setblock 411 179 362 minecraft:polished_deepslate
fill 411 179 363 411 182 363 minecraft:gray_concrete
fill 412 179 362 412 181 362 minecraft:gray_concrete
setblock 413 179 324 minecraft:gray_concrete
setblock 414 179 324 minecraft:polished_deepslate
setblock 414 179 343 minecraft:gray_concrete
setblock 414 179 344 minecraft:polished_deepslate
fill 414 179 345 414 182 345 minecraft:gray_concrete
setblock 414 179 349 minecraft:polished_deepslate
fill 414 179 350 414 182 350 minecraft:gray_concrete
setblock 415 179 323 minecraft:polished_deepslate
fill 415 179 324 416 180 324 minecraft:gray_concrete
setblock 415 179 343 minecraft:polished_deepslate
fill 415 179 344 415 182 344 minecraft:gray_concrete
setblock 415 179 348 minecraft:polished_deepslate
fill 415 179 349 415 182 349 minecraft:gray_concrete
setblock 415 179 363 minecraft:polished_deepslate
fill 416 179 323 416 182 323 minecraft:gray_concrete
fill 416 179 325 416 179 326 minecraft:gray_concrete
setblock 416 179 342 minecraft:polished_deepslate
fill 416 179 343 416 182 343 minecraft:gray_concrete
setblock 416 179 347 minecraft:polished_deepslate
fill 416 179 348 416 182 348 minecraft:gray_concrete
setblock 416 179 352 minecraft:polished_deepslate
fill 416 179 353 416 182 353 minecraft:gray_concrete
fill 416 179 363 416 180 363 minecraft:gray_concrete
setblock 417 179 326 minecraft:polished_deepslate
fill 417 179 327 417 182 327 minecraft:gray_concrete
fill 417 179 329 417 179 330 minecraft:gray_concrete
setblock 417 179 336 minecraft:polished_deepslate
fill 417 179 337 417 182 337 minecraft:gray_concrete
setblock 417 179 341 minecraft:polished_deepslate
fill 417 179 342 417 182 342 minecraft:gray_concrete
setblock 417 179 346 minecraft:polished_deepslate
fill 417 179 347 417 182 347 minecraft:gray_concrete
setblock 417 179 351 minecraft:polished_deepslate
fill 417 179 352 417 182 352 minecraft:gray_concrete
setblock 418 179 354 minecraft:light_blue_stained_glass
fill 418 179 355 418 180 356 minecraft:gray_wool
setblock 376 180 331 minecraft:gray_wool
setblock 377 180 324 minecraft:gray_concrete
setblock 377 180 325 minecraft:polished_deepslate
fill 377 180 326 377 180 329 minecraft:gray_concrete
setblock 377 180 330 minecraft:polished_deepslate
fill 377 180 331 377 183 331 minecraft:gray_concrete
setblock 377 180 335 minecraft:polished_deepslate
fill 377 180 336 377 183 336 minecraft:gray_concrete
setblock 377 180 340 minecraft:polished_deepslate
fill 377 180 341 377 182 341 minecraft:gray_concrete
setblock 377 180 345 minecraft:polished_deepslate
fill 377 180 346 377 183 346 minecraft:gray_concrete
setblock 377 180 350 minecraft:polished_deepslate
fill 377 180 351 377 183 351 minecraft:gray_concrete
setblock 378 180 324 minecraft:polished_deepslate
fill 378 180 325 378 183 325 minecraft:gray_concrete
setblock 378 180 328 minecraft:gray_concrete
setblock 378 180 329 minecraft:polished_deepslate
fill 378 180 330 378 183 330 minecraft:gray_concrete
setblock 378 180 344 minecraft:polished_deepslate
fill 378 180 345 378 181 345 minecraft:gray_concrete
setblock 379 180 323 minecraft:polished_deepslate
fill 379 180 324 379 183 324 minecraft:gray_concrete
fill 380 180 323 380 183 323 minecraft:gray_concrete
setblock 382 180 325 minecraft:polished_deepslate
setblock 383 180 323 minecraft:gray_concrete
setblock 383 180 324 minecraft:polished_deepslate
fill 383 180 325 383 183 325 minecraft:gray_concrete
setblock 383 180 363 minecraft:gray_concrete
setblock 384 180 323 minecraft:polished_deepslate
fill 384 180 324 384 183 324 minecraft:gray_concrete
setblock 384 180 363 minecraft:polished_deepslate
fill 385 180 323 385 183 323 minecraft:gray_concrete
setblock 385 180 326 minecraft:gray_concrete
fill 385 180 363 385 183 363 minecraft:gray_concrete
setblock 386 180 325 minecraft:gray_concrete
setblock 386 180 326 minecraft:polished_deepslate
fill 386 180 362 386 183 362 minecraft:gray_concrete
setblock 387 180 325 minecraft:polished_deepslate
fill 387 180 326 390 180 326 minecraft:gray_concrete
setblock 388 180 324 minecraft:polished_deepslate
fill 388 180 325 388 183 325 minecraft:gray_concrete
setblock 389 180 323 minecraft:polished_deepslate
fill 389 180 324 389 183 324 minecraft:gray_concrete
setblock 389 180 363 minecraft:polished_deepslate
fill 390 180 323 390 183 323 minecraft:gray_concrete
setblock 390 180 362 minecraft:polished_deepslate
fill 390 180 363 393 180 363 minecraft:gray_concrete
setblock 391 180 326 minecraft:polished_deepslate
setblock 391 180 361 minecraft:polished_deepslate
fill 391 180 362 391 183 362 minecraft:gray_concrete
setblock 392 180 325 minecraft:polished_deepslate
fill 392 180 326 392 183 326 minecraft:gray_concrete
setblock 392 180 361 minecraft:gray_concrete
setblock 393 180 324 minecraft:polished_deepslate
fill 393 180 325 393 183 325 minecraft:gray_concrete
setblock 394 180 323 minecraft:polished_deepslate
fill 394 180 324 394 183 324 minecraft:gray_concrete
setblock 394 180 363 minecraft:polished_deepslate
fill 395 180 323 395 183 323 minecraft:gray_concrete
setblock 395 180 362 minecraft:polished_deepslate
fill 395 180 363 395 183 363 minecraft:gray_concrete
fill 396 180 362 396 181 362 minecraft:gray_concrete
setblock 398 180 324 minecraft:polished_deepslate
setblock 399 180 323 minecraft:polished_deepslate
fill 399 180 324 399 181 324 minecraft:gray_concrete
setblock 399 180 363 minecraft:polished_deepslate
fill 400 180 323 400 183 323 minecraft:gray_concrete
fill 400 180 363 400 183 363 minecraft:gray_concrete
setblock 402 180 364 minecraft:light_blue_stained_glass
fill 403 180 322 403 184 322 minecraft:gray_wool
setblock 403 180 324 minecraft:polished_deepslate
setblock 404 180 323 minecraft:polished_deepslate
fill 404 180 324 404 183 324 minecraft:gray_concrete
setblock 404 180 363 minecraft:polished_deepslate
fill 405 180 323 405 183 323 minecraft:gray_concrete
setblock 405 180 362 minecraft:polished_deepslate
fill 405 180 363 405 183 363 minecraft:gray_concrete
fill 406 180 362 406 183 362 minecraft:gray_concrete
setblock 408 180 323 minecraft:gray_concrete
setblock 408 180 324 minecraft:polished_deepslate
setblock 409 180 323 minecraft:polished_deepslate
fill 409 180 324 409 182 325 minecraft:gray_concrete
setblock 409 180 363 minecraft:polished_deepslate
fill 410 180 323 410 183 323 minecraft:gray_concrete
fill 410 180 325 411 180 325 minecraft:gray_concrete
setblock 410 180 362 minecraft:polished_deepslate
fill 410 180 363 410 183 363 minecraft:gray_concrete
fill 411 180 362 411 182 362 minecraft:gray_concrete
setblock 412 180 325 minecraft:polished_deepslate
setblock 413 180 324 minecraft:polished_deepslate
fill 413 180 346 413 180 347 minecraft:gray_concrete
setblock 414 180 323 minecraft:polished_deepslate
fill 414 180 324 414 182 324 minecraft:gray_concrete
setblock 414 180 343 minecraft:polished_deepslate
fill 414 180 344 414 181 344 minecraft:gray_concrete
setblock 414 180 347 minecraft:gray_concrete
setblock 414 180 348 minecraft:polished_deepslate
fill 414 180 349 414 183 349 minecraft:gray_concrete
setblock 414 180 363 minecraft:polished_deepslate
fill 415 180 323 415 183 323 minecraft:gray_concrete
setblock 415 180 342 minecraft:polished_deepslate
fill 415 180 343 415 182 343 minecraft:gray_concrete
setblock 415 180 347 minecraft:polished_deepslate
fill 415 180 348 415 183 348 minecraft:gray_concrete
setblock 415 180 352 minecraft:polished_deepslate
fill 415 180 363 415 181 363 minecraft:gray_concrete
setblock 416 180 325 minecraft:gray_concrete
setblock 416 180 326 minecraft:polished_deepslate
fill 416 180 327 416 182 327 minecraft:gray_concrete
setblock 416 180 341 minecraft:polished_deepslate
fill 416 180 342 416 183 342 minecraft:gray_concrete
setblock 416 180 346 minecraft:polished_deepslate
fill 416 180 347 416 183 347 minecraft:gray_concrete
setblock 416 180 351 minecraft:polished_deepslate
fill 416 180 352 416 183 352 minecraft:gray_concrete
setblock 417 180 325 minecraft:polished_deepslate
fill 417 180 326 417 183 326 minecraft:gray_concrete
setblock 417 180 329 minecraft:gray_concrete
setblock 417 180 330 minecraft:polished_deepslate
fill 417 180 331 417 181 333 minecraft:gray_concrete
fill 417 180 336 417 182 336 minecraft:gray_concrete
setblock 417 180 340 minecraft:polished_deepslate
fill 417 180 341 417 183 341 minecraft:gray_concrete
setblock 417 180 345 minecraft:polished_deepslate
fill 417 180 346 417 183 346 minecraft:gray_concrete
setblock 417 180 350 minecraft:polished_deepslate
fill 417 180 351 417 183 351 minecraft:gray_concrete
fill 418 180 354 418 184 354 minecraft:gray_wool
setblock 376 181 331 minecraft:black_concrete
setblock 376 181 338 minecraft:light_blue_stained_glass
fill 376 181 345 376 182 345 minecraft:black_concrete
fill 376 181 349 376 182 349 minecraft:black_concrete
fill 376 181 353 376 181 354 minecraft:black_concrete
fill 376 181 355 376 184 355 minecraft:gray_wool
setblock 376 181 362 minecraft:light_blue_stained_glass
setblock 377 181 324 minecraft:polished_deepslate
fill 377 181 325 377 181 328 minecraft:gray_concrete
setblock 377 181 329 minecraft:polished_deepslate
fill 377 181 330 377 184 330 minecraft:gray_concrete
setblock 377 181 334 minecraft:polished_deepslate
fill 377 181 335 377 184 335 minecraft:gray_concrete
setblock 377 181 339 minecraft:polished_deepslate
fill 377 181 340 377 182 340 minecraft:gray_concrete
setblock 377 181 344 minecraft:polished_deepslate
fill 377 181 345 377 184 345 minecraft:gray_concrete
setblock 377 181 349 minecraft:polished_deepslate
fill 377 181 350 377 184 350 minecraft:gray_concrete
fill 377 181 364 377 182 364 minecraft:black_concrete
setblock 378 181 323 minecraft:polished_deepslate
fill 378 181 324 378 183 324 minecraft:gray_concrete
setblock 378 181 328 minecraft:polished_deepslate
fill 378 181 329 378 184 329 minecraft:gray_concrete
fill 378 181 331 378 182 331 minecraft:gray_concrete
setblock 378 181 344 minecraft:gray_concrete
fill 378 181 364 378 184 364 minecraft:gray_wool
fill 379 181 323 379 184 323 minecraft:gray_concrete
setblock 380 181 364 minecraft:black_concrete
setblock 381 181 324 minecraft:gray_concrete
setblock 381 181 325 minecraft:polished_deepslate
setblock 382 181 324 minecraft:polished_deepslate
fill 382 181 325 382 184 325 minecraft:gray_concrete
setblock 383 181 323 minecraft:polished_deepslate
fill 383 181 324 383 184 324 minecraft:gray_concrete
setblock 383 181 363 minecraft:polished_deepslate
fill 384 181 323 384 184 323 minecraft:gray_concrete
setblock 384 181 326 minecraft:gray_concrete
fill 384 181 363 384 184 363 minecraft:gray_concrete
fill 385 181 322 387 181 322 minecraft:gray_wool
setblock 385 181 326 minecraft:polished_deepslate
setblock 386 181 325 minecraft:polished_deepslate
fill 386 181 326 389 181 326 minecraft:gray_concrete
setblock 387 181 324 minecraft:polished_deepslate
fill 387 181 325 387 184 325 minecraft:gray_concrete
fill 388 181 322 389 181 322 minecraft:black_concrete
setblock 388 181 323 minecraft:polished_deepslate
fill 388 181 324 388 184 324 minecraft:gray_concrete
setblock 388 181 327 minecraft:gray_concrete
setblock 388 181 363 minecraft:polished_deepslate
fill 389 181 323 389 184 323 minecraft:gray_concrete
setblock 389 181 327 minecraft:polished_deepslate
setblock 389 181 362 minecraft:polished_deepslate
fill 389 181 363 392 181 363 minecraft:gray_concrete
fill 390 181 322 390 185 322 minecraft:gray_wool
setblock 390 181 326 minecraft:polished_deepslate
fill 390 181 327 390 182 327 minecraft:gray_concrete
fill 390 181 362 390 184 362 minecraft:gray_concrete
fill 391 181 322 391 182 322 minecraft:black_concrete
setblock 391 181 325 minecraft:polished_deepslate
fill 391 181 326 391 184 326 minecraft:gray_concrete
setblock 392 181 324 minecraft:polished_deepslate
fill 392 181 325 392 184 325 minecraft:gray_concrete
setblock 393 181 323 minecraft:polished_deepslate
fill 393 181 324 393 184 324 minecraft:gray_concrete
setblock 393 181 363 minecraft:polished_deepslate
fill 394 181 323 394 184 323 minecraft:gray_concrete
setblock 394 181 362 minecraft:polished_deepslate
fill 394 181 363 394 184 363 minecraft:gray_concrete
fill 395 181 362 395 182 362 minecraft:gray_concrete
setblock 396 181 325 minecraft:polished_deepslate
setblock 397 181 324 minecraft:polished_deepslate
setblock 397 181 364 minecraft:black_concrete
setblock 398 181 323 minecraft:polished_deepslate
fill 398 181 324 398 182 324 minecraft:gray_concrete
setblock 398 181 363 minecraft:polished_deepslate
fill 399 181 323 399 183 323 minecraft:gray_concrete
fill 399 181 363 399 183 363 minecraft:gray_concrete
fill 402 181 364 402 184 364 minecraft:gray_wool
setblock 403 181 323 minecraft:polished_deepslate
setblock 403 181 324 minecraft:gray_concrete
setblock 403 181 363 minecraft:polished_deepslate
fill 404 181 323 404 184 323 minecraft:gray_concrete
setblock 404 181 362 minecraft:polished_deepslate
fill 404 181 363 404 184 363 minecraft:gray_concrete
fill 404 181 364 404 184 364 minecraft:gray_wool
fill 405 181 362 405 183 362 minecraft:gray_concrete
setblock 405 181 364 minecraft:black_concrete
setblock 406 181 324 minecraft:gray_concrete
setblock 407 181 324 minecraft:polished_deepslate
setblock 408 181 323 minecraft:polished_deepslate
fill 408 181 324 408 182 325 minecraft:gray_concrete
fill 408 181 353 410 182 353 minecraft:white_wool
setblock 408 181 363 minecraft:polished_deepslate
fill 409 181 323 409 184 323 minecraft:gray_concrete
fill 409 181 352 409 182 352 minecraft:white_wool
fill 409 181 354 409 182 354 minecraft:white_wool
setblock 409 181 362 minecraft:polished_deepslate
fill 409 181 363 409 184 363 minecraft:gray_concrete
setblock 410 181 325 minecraft:gray_concrete
fill 410 181 362 410 183 362 minecraft:gray_concrete
setblock 411 181 325 minecraft:polished_deepslate
setblock 412 181 324 minecraft:polished_deepslate
setblock 412 181 325 minecraft:gray_concrete
setblock 413 181 323 minecraft:polished_deepslate
fill 413 181 324 413 182 324 minecraft:gray_concrete
setblock 413 181 363 minecraft:polished_deepslate
fill 414 181 323 414 183 323 minecraft:gray_concrete
setblock 414 181 347 minecraft:polished_deepslate
fill 414 181 348 414 183 348 minecraft:gray_concrete
fill 414 181 363 414 182 363 minecraft:gray_concrete
setblock 415 181 324 minecraft:gray_concrete
setblock 415 181 342 minecraft:gray_concrete
setblock 415 181 346 minecraft:polished_deepslate
fill 415 181 347 415 184 347 minecraft:gray_concrete
setblock 415 181 350 minecraft:gray_concrete
setblock 415 181 351 minecraft:polished_deepslate
setblock 415 181 352 minecraft:gray_concrete
setblock 415 181 364 minecraft:black_concrete
setblock 416 181 322 minecraft:black_concrete
setblock 416 181 325 minecraft:polished_deepslate
fill 416 181 326 416 182 326 minecraft:gray_concrete
fill 416 181 328 416 181 329 minecraft:gray_concrete
setblock 416 181 340 minecraft:polished_deepslate
fill 416 181 341 416 182 341 minecraft:gray_concrete
setblock 416 181 345 minecraft:polished_deepslate
fill 416 181 346 416 184 346 minecraft:gray_concrete
setblock 416 181 350 minecraft:polished_deepslate
fill 416 181 351 416 184 351 minecraft:gray_concrete
setblock 417 181 324 minecraft:polished_deepslate
fill 417 181 325 417 184 325 minecraft:gray_concrete
setblock 417 181 329 minecraft:polished_deepslate
fill 417 181 330 417 184 330 minecraft:gray_concrete
setblock 417 181 334 minecraft:polished_deepslate
fill 417 181 335 417 184 335 minecraft:gray_concrete
setblock 417 181 339 minecraft:polished_deepslate
fill 417 181 340 417 183 340 minecraft:gray_concrete
setblock 417 181 344 minecraft:polished_deepslate
fill 417 181 345 417 184 345 minecraft:gray_concrete
setblock 417 181 349 minecraft:polished_deepslate
fill 417 181 350 417 184 350 minecraft:gray_concrete
setblock 417 181 354 minecraft:polished_deepslate
setblock 418 181 324 minecraft:black_concrete
setblock 418 181 353 minecraft:black_concrete
fill 418 181 355 418 184 355 minecraft:gray_wool
setblock 418 181 356 minecraft:black_concrete
fill 376 182 331 376 184 331 minecraft:gray_wool
setblock 376 182 332 minecraft:light_blue_stained_glass
setblock 376 182 333 minecraft:black_concrete
setblock 376 182 338 minecraft:gray_wool
setblock 376 182 350 minecraft:black_concrete
fill 376 182 353 376 184 354 minecraft:gray_wool
setblock 376 182 356 minecraft:light_blue_stained_glass
fill 376 182 357 376 184 359 minecraft:gray_wool
setblock 376 182 362 minecraft:gray_wool
setblock 377 182 323 minecraft:polished_deepslate
fill 377 182 324 377 182 327 minecraft:gray_concrete
setblock 377 182 328 minecraft:polished_deepslate
fill 377 182 329 377 184 329 minecraft:gray_concrete
setblock 377 182 333 minecraft:polished_deepslate
fill 377 182 334 377 184 334 minecraft:gray_concrete
setblock 377 182 338 minecraft:polished_deepslate
setblock 377 182 339 minecraft:gray_concrete
setblock 377 182 343 minecraft:polished_deepslate
fill 377 182 344 377 183 344 minecraft:gray_concrete
setblock 377 182 348 minecraft:polished_deepslate
fill 377 182 349 377 184 349 minecraft:gray_concrete
fill 378 182 323 378 184 323 minecraft:gray_concrete
setblock 378 182 327 minecraft:polished_deepslate
fill 378 182 328 378 184 328 minecraft:gray_concrete
setblock 378 182 332 minecraft:polished_deepslate
fill 379 182 325 380 184 326 minecraft:light_blue_stained_glass
setblock 379 182 332 minecraft:light[level=12]
setblock 379 182 333 minecraft:light[level=13]
setblock 379 182 339 minecraft:light[level=12]
setblock 379 182 341 minecraft:light[level=13]
setblock 379 182 346 minecraft:light[level=12]
setblock 379 182 349 minecraft:light[level=13]
setblock 379 182 353 minecraft:light[level=12]
setblock 379 182 357 minecraft:light[level=13]
setblock 379 182 360 minecraft:light[level=12]
fill 380 182 322 381 182 322 minecraft:black_concrete
fill 380 182 364 380 184 364 minecraft:gray_wool
setblock 381 182 324 minecraft:polished_deepslate
fill 381 182 325 381 183 325 minecraft:gray_concrete
fill 381 182 364 382 182 364 minecraft:black_concrete
setblock 382 182 323 minecraft:polished_deepslate
fill 382 182 324 382 184 324 minecraft:gray_concrete
setblock 383 182 322 minecraft:black_concrete
fill 383 182 323 383 184 323 minecraft:gray_concrete
fill 383 182 363 383 184 363 minecraft:gray_concrete
fill 384 182 322 385 184 322 minecraft:gray_wool
setblock 384 182 326 minecraft:polished_deepslate
setblock 385 182 325 minecraft:polished_deepslate
fill 385 182 326 388 182 326 minecraft:gray_concrete
setblock 386 182 322 minecraft:black_concrete
setblock 386 182 324 minecraft:polished_deepslate
fill 386 182 325 386 184 325 minecraft:gray_concrete
setblock 386 182 332 minecraft:light[level=12]
setblock 386 182 339 minecraft:light[level=12]
setblock 386 182 346 minecraft:light[level=12]
setblock 386 182 353 minecraft:light[level=12]
setblock 386 182 360 minecraft:light[level=12]
fill 387 182 322 388 184 322 minecraft:gray_wool
setblock 387 182 323 minecraft:polished_deepslate
fill 387 182 324 387 184 324 minecraft:gray_concrete
setblock 387 182 327 minecraft:gray_concrete
setblock 387 182 333 minecraft:light[level=13]
setblock 387 182 341 minecraft:light[level=13]
setblock 387 182 349 minecraft:light[level=13]
setblock 387 182 357 minecraft:light[level=13]
setblock 387 182 363 minecraft:polished_deepslate
fill 388 182 323 388 184 323 minecraft:gray_concrete
setblock 388 182 327 minecraft:polished_deepslate
setblock 388 182 362 minecraft:polished_deepslate
fill 388 182 363 391 182 363 minecraft:gray_concrete
setblock 389 182 322 minecraft:black_concrete
setblock 389 182 326 minecraft:polished_deepslate
fill 389 182 327 389 183 327 minecraft:gray_concrete
fill 389 182 362 389 184 362 minecraft:gray_concrete
setblock 390 182 325 minecraft:polished_deepslate
fill 390 182 326 390 184 326 minecraft:gray_concrete
setblock 390 182 364 minecraft:light_blue_stained_glass
setblock 391 182 324 minecraft:polished_deepslate
fill 391 182 325 391 184 325 minecraft:gray_concrete
setblock 392 182 323 minecraft:polished_deepslate
fill 392 182 324 392 184 324 minecraft:gray_concrete
setblock 392 182 363 minecraft:polished_deepslate
fill 393 182 323 393 184 323 minecraft:gray_concrete
setblock 393 182 332 minecraft:light[level=12]
setblock 393 182 339 minecraft:light[level=12]
setblock 393 182 346 minecraft:light[level=12]
setblock 393 182 353 minecraft:light[level=12]
setblock 393 182 360 minecraft:light[level=12]
setblock 393 182 362 minecraft:polished_deepslate
fill 393 182 363 393 184 363 minecraft:gray_concrete
setblock 393 182 364 minecraft:black_concrete
fill 394 182 362 394 183 362 minecraft:gray_concrete
setblock 395 182 325 minecraft:polished_deepslate
setblock 395 182 333 minecraft:light[level=13]
setblock 395 182 341 minecraft:light[level=13]
setblock 395 182 349 minecraft:light[level=13]
setblock 395 182 357 minecraft:light[level=13]
setblock 395 182 364 minecraft:black_concrete
setblock 396 182 324 minecraft:polished_deepslate
setblock 397 182 323 minecraft:polished_deepslate
setblock 397 182 324 minecraft:gray_concrete
setblock 397 182 363 minecraft:polished_deepslate
fill 397 182 364 397 184 364 minecraft:gray_wool
setblock 398 182 322 minecraft:black_concrete
fill 398 182 323 398 184 323 minecraft:gray_concrete
fill 398 182 363 398 183 363 minecraft:gray_concrete
setblock 400 182 325 minecraft:light[level=12]
setblock 400 182 332 minecraft:light[level=12]
setblock 400 182 339 minecraft:light[level=12]
setblock 400 182 346 minecraft:light[level=12]
setblock 400 182 353 minecraft:light[level=12]
setblock 400 182 360 minecraft:light[level=12]
setblock 402 182 323 minecraft:polished_deepslate
setblock 402 182 363 minecraft:polished_deepslate
fill 403 182 323 403 184 323 minecraft:gray_concrete
setblock 403 182 325 minecraft:light[level=13]
setblock 403 182 333 minecraft:light[level=13]
setblock 403 182 341 minecraft:light[level=13]
schedule function dropper:buildpart/80_5 1t
