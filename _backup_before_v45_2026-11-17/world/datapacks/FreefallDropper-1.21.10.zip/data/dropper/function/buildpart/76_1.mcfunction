setblock 188 144 344 minecraft:white_concrete
fill 192 144 364 192 225 364 minecraft:black_concrete
setblock 199 144 364 minecraft:ochre_froglight
fill 209 144 355 209 148 355 minecraft:gray_concrete
fill 209 144 358 209 148 358 minecraft:gray_concrete
setblock 211 144 322 minecraft:ochre_froglight
fill 211 144 355 211 148 355 minecraft:gray_concrete
fill 212 144 356 212 148 357 minecraft:gray_concrete
fill 215 144 328 215 149 328 minecraft:lime_stained_glass
setblock 226 144 322 minecraft:ochre_froglight
fill 227 144 364 227 274 364 minecraft:black_concrete
fill 229 144 322 229 187 322 minecraft:black_concrete
setblock 188 145 340 minecraft:ochre_froglight
fill 188 145 344 188 167 344 minecraft:black_concrete
setblock 188 145 361 minecraft:white_concrete
setblock 191 145 323 minecraft:verdant_froglight
setblock 191 145 325 minecraft:verdant_froglight
setblock 191 145 327 minecraft:verdant_froglight
setblock 191 145 332 minecraft:light[level=12]
setblock 191 145 333 minecraft:light[level=15]
setblock 191 145 339 minecraft:light[level=12]
setblock 191 145 341 minecraft:light[level=15]
setblock 191 145 346 minecraft:light[level=12]
setblock 191 145 349 minecraft:light[level=15]
setblock 191 145 353 minecraft:light[level=12]
setblock 191 145 357 minecraft:light[level=15]
setblock 191 145 360 minecraft:light[level=12]
setblock 192 145 324 minecraft:verdant_froglight
setblock 192 145 326 minecraft:verdant_froglight
setblock 193 145 323 minecraft:verdant_froglight
setblock 193 145 325 minecraft:verdant_froglight
setblock 193 145 327 minecraft:verdant_froglight
setblock 194 145 324 minecraft:verdant_froglight
setblock 194 145 326 minecraft:verdant_froglight
setblock 195 145 323 minecraft:verdant_froglight
setblock 195 145 325 minecraft:verdant_froglight
setblock 195 145 327 minecraft:verdant_froglight
setblock 196 145 324 minecraft:verdant_froglight
setblock 196 145 326 minecraft:verdant_froglight
setblock 197 145 323 minecraft:verdant_froglight
setblock 197 145 325 minecraft:verdant_froglight
setblock 197 145 327 minecraft:verdant_froglight
setblock 198 145 324 minecraft:verdant_froglight
setblock 198 145 326 minecraft:verdant_froglight
setblock 198 145 332 minecraft:light[level=12]
setblock 198 145 339 minecraft:light[level=12]
setblock 198 145 346 minecraft:light[level=12]
setblock 198 145 353 minecraft:light[level=12]
setblock 198 145 360 minecraft:light[level=12]
setblock 199 145 323 minecraft:verdant_froglight
setblock 199 145 325 minecraft:verdant_froglight
setblock 199 145 327 minecraft:verdant_froglight
setblock 199 145 333 minecraft:light[level=15]
setblock 199 145 341 minecraft:light[level=15]
setblock 199 145 349 minecraft:light[level=15]
setblock 199 145 357 minecraft:light[level=15]
fill 199 145 364 199 203 364 minecraft:black_concrete
setblock 200 145 324 minecraft:verdant_froglight
setblock 200 145 326 minecraft:verdant_froglight
setblock 201 145 323 minecraft:verdant_froglight
setblock 201 145 325 minecraft:verdant_froglight
setblock 201 145 327 minecraft:verdant_froglight
setblock 202 145 324 minecraft:verdant_froglight
setblock 202 145 326 minecraft:verdant_froglight
setblock 203 145 323 minecraft:verdant_froglight
setblock 203 145 325 minecraft:verdant_froglight
setblock 203 145 327 minecraft:verdant_froglight
setblock 205 145 325 minecraft:light[level=12]
setblock 205 145 332 minecraft:light[level=12]
setblock 205 145 339 minecraft:light[level=12]
setblock 205 145 346 minecraft:light[level=12]
setblock 205 145 353 minecraft:light[level=12]
setblock 205 145 360 minecraft:light[level=12]
setblock 207 145 325 minecraft:light[level=15]
setblock 207 145 333 minecraft:light[level=15]
setblock 207 145 341 minecraft:light[level=15]
setblock 207 145 349 minecraft:light[level=15]
setblock 207 145 357 minecraft:light[level=15]
fill 208 145 356 208 148 357 minecraft:gray_concrete
fill 210 145 359 211 148 359 minecraft:gray_concrete
fill 211 145 322 211 173 322 minecraft:black_concrete
setblock 212 145 325 minecraft:light[level=12]
setblock 212 145 332 minecraft:light[level=12]
setblock 212 145 339 minecraft:light[level=12]
setblock 212 145 346 minecraft:light[level=12]
setblock 212 145 353 minecraft:light[level=12]
fill 212 145 355 212 148 355 minecraft:gray_concrete
fill 212 145 358 212 148 358 minecraft:gray_concrete
setblock 212 145 360 minecraft:light[level=12]
setblock 215 145 325 minecraft:light[level=15]
setblock 215 145 333 minecraft:light[level=15]
setblock 215 145 341 minecraft:light[level=15]
setblock 215 145 349 minecraft:light[level=15]
setblock 215 145 357 minecraft:light[level=15]
setblock 219 145 325 minecraft:light[level=12]
setblock 219 145 332 minecraft:light[level=12]
setblock 219 145 339 minecraft:light[level=12]
setblock 219 145 346 minecraft:light[level=12]
setblock 219 145 353 minecraft:light[level=12]
setblock 219 145 360 minecraft:light[level=12]
setblock 223 145 325 minecraft:verdant_froglight
setblock 223 145 327 minecraft:verdant_froglight
setblock 223 145 329 minecraft:verdant_froglight
setblock 223 145 331 minecraft:verdant_froglight
setblock 223 145 333 minecraft:verdant_froglight
setblock 223 145 341 minecraft:light[level=15]
setblock 223 145 349 minecraft:light[level=15]
setblock 223 145 357 minecraft:light[level=15]
setblock 224 145 326 minecraft:verdant_froglight
setblock 224 145 328 minecraft:verdant_froglight
setblock 224 145 330 minecraft:verdant_froglight
setblock 224 145 332 minecraft:verdant_froglight
setblock 224 145 338 minecraft:verdant_froglight
setblock 224 145 340 minecraft:verdant_froglight
setblock 224 145 342 minecraft:verdant_froglight
setblock 224 145 344 minecraft:verdant_froglight
setblock 224 145 346 minecraft:verdant_froglight
setblock 224 145 348 minecraft:verdant_froglight
setblock 224 145 350 minecraft:verdant_froglight
setblock 225 145 325 minecraft:verdant_froglight
setblock 225 145 327 minecraft:verdant_froglight
setblock 225 145 329 minecraft:verdant_froglight
setblock 225 145 331 minecraft:verdant_froglight
setblock 225 145 333 minecraft:verdant_froglight
setblock 225 145 339 minecraft:verdant_froglight
setblock 225 145 341 minecraft:verdant_froglight
setblock 225 145 343 minecraft:verdant_froglight
setblock 225 145 345 minecraft:verdant_froglight
setblock 225 145 347 minecraft:verdant_froglight
setblock 225 145 349 minecraft:verdant_froglight
fill 226 145 322 226 154 322 minecraft:black_concrete
setblock 226 145 326 minecraft:verdant_froglight
setblock 226 145 328 minecraft:verdant_froglight
setblock 226 145 330 minecraft:verdant_froglight
setblock 226 145 332 minecraft:verdant_froglight
setblock 226 145 338 minecraft:verdant_froglight
setblock 226 145 340 minecraft:verdant_froglight
setblock 226 145 342 minecraft:verdant_froglight
setblock 226 145 344 minecraft:verdant_froglight
setblock 226 145 346 minecraft:verdant_froglight
setblock 226 145 348 minecraft:verdant_froglight
setblock 226 145 350 minecraft:verdant_froglight
setblock 226 145 353 minecraft:light[level=12]
setblock 226 145 360 minecraft:light[level=12]
setblock 227 145 325 minecraft:verdant_froglight
setblock 227 145 327 minecraft:verdant_froglight
setblock 227 145 329 minecraft:verdant_froglight
setblock 227 145 331 minecraft:verdant_froglight
setblock 227 145 333 minecraft:verdant_froglight
setblock 227 145 339 minecraft:verdant_froglight
setblock 227 145 341 minecraft:verdant_froglight
setblock 227 145 343 minecraft:verdant_froglight
setblock 227 145 345 minecraft:verdant_froglight
setblock 227 145 347 minecraft:verdant_froglight
setblock 227 145 349 minecraft:verdant_froglight
setblock 228 145 326 minecraft:verdant_froglight
setblock 228 145 328 minecraft:verdant_froglight
setblock 228 145 330 minecraft:verdant_froglight
setblock 228 145 332 minecraft:verdant_froglight
setblock 228 145 338 minecraft:verdant_froglight
setblock 228 145 340 minecraft:verdant_froglight
setblock 228 145 342 minecraft:verdant_froglight
setblock 228 145 344 minecraft:verdant_froglight
setblock 228 145 346 minecraft:verdant_froglight
setblock 228 145 348 minecraft:verdant_froglight
setblock 228 145 350 minecraft:verdant_froglight
setblock 229 145 325 minecraft:verdant_froglight
setblock 229 145 327 minecraft:verdant_froglight
setblock 229 145 329 minecraft:verdant_froglight
setblock 229 145 331 minecraft:verdant_froglight
setblock 229 145 333 minecraft:verdant_froglight
setblock 229 145 339 minecraft:verdant_froglight
setblock 229 145 341 minecraft:verdant_froglight
setblock 229 145 343 minecraft:verdant_froglight
setblock 229 145 345 minecraft:verdant_froglight
setblock 229 145 347 minecraft:verdant_froglight
setblock 229 145 349 minecraft:verdant_froglight
setblock 230 145 334 minecraft:sea_lantern
setblock 188 146 340 minecraft:black_concrete
fill 188 146 361 188 164 361 minecraft:black_concrete
setblock 188 146 362 minecraft:sea_lantern
fill 188 146 363 188 166 364 minecraft:black_concrete
fill 191 146 323 191 147 323 minecraft:light_gray_concrete
fill 191 146 325 191 147 325 minecraft:light_gray_concrete
fill 191 146 327 191 147 327 minecraft:light_gray_concrete
fill 192 146 324 192 147 324 minecraft:light_gray_concrete
fill 192 146 326 192 147 326 minecraft:light_gray_concrete
fill 193 146 323 193 147 323 minecraft:light_gray_concrete
fill 193 146 325 193 147 325 minecraft:light_gray_concrete
fill 193 146 327 193 147 327 minecraft:light_gray_concrete
fill 194 146 324 194 147 324 minecraft:light_gray_concrete
fill 194 146 326 194 147 326 minecraft:light_gray_concrete
fill 195 146 323 195 147 323 minecraft:light_gray_concrete
fill 195 146 325 195 147 325 minecraft:light_gray_concrete
fill 195 146 327 195 147 327 minecraft:light_gray_concrete
fill 196 146 324 196 147 324 minecraft:light_gray_concrete
fill 196 146 326 196 147 326 minecraft:light_gray_concrete
fill 197 146 323 197 147 323 minecraft:light_gray_concrete
fill 197 146 325 197 147 325 minecraft:light_gray_concrete
fill 197 146 327 197 147 327 minecraft:light_gray_concrete
fill 198 146 324 198 147 324 minecraft:light_gray_concrete
fill 198 146 326 198 147 326 minecraft:light_gray_concrete
fill 199 146 323 199 147 323 minecraft:light_gray_concrete
fill 199 146 325 199 147 325 minecraft:light_gray_concrete
fill 199 146 327 199 147 327 minecraft:light_gray_concrete
fill 200 146 324 200 147 324 minecraft:light_gray_concrete
fill 200 146 326 200 147 326 minecraft:light_gray_concrete
fill 201 146 323 201 147 323 minecraft:light_gray_concrete
fill 201 146 325 201 147 325 minecraft:light_gray_concrete
fill 201 146 327 201 147 327 minecraft:light_gray_concrete
fill 202 146 324 202 147 324 minecraft:light_gray_concrete
fill 202 146 326 202 147 326 minecraft:light_gray_concrete
fill 203 146 323 203 147 323 minecraft:light_gray_concrete
fill 203 146 325 203 147 325 minecraft:light_gray_concrete
fill 203 146 327 203 147 327 minecraft:light_gray_concrete
setblock 206 146 364 minecraft:pearlescent_froglight
fill 208 146 355 208 148 355 minecraft:gray_concrete
fill 208 146 358 208 148 358 minecraft:gray_concrete
fill 209 146 354 212 148 354 minecraft:gray_concrete
fill 209 146 359 209 148 359 minecraft:gray_concrete
fill 212 146 359 212 148 359 minecraft:gray_concrete
fill 213 146 355 213 148 358 minecraft:gray_concrete
setblock 216 146 364 minecraft:white_concrete
fill 223 146 325 223 147 325 minecraft:light_gray_concrete
fill 223 146 327 223 147 327 minecraft:light_gray_concrete
fill 223 146 329 223 147 329 minecraft:light_gray_concrete
fill 223 146 331 223 147 331 minecraft:light_gray_concrete
fill 223 146 333 223 147 333 minecraft:light_gray_concrete
fill 224 146 326 224 147 326 minecraft:light_gray_concrete
fill 224 146 328 224 147 328 minecraft:light_gray_concrete
fill 224 146 330 224 147 330 minecraft:light_gray_concrete
fill 224 146 332 224 147 332 minecraft:light_gray_concrete
fill 224 146 338 224 147 338 minecraft:light_gray_concrete
fill 224 146 340 224 147 340 minecraft:light_gray_concrete
fill 224 146 342 224 147 342 minecraft:light_gray_concrete
fill 224 146 344 224 147 344 minecraft:light_gray_concrete
fill 224 146 346 224 147 346 minecraft:light_gray_concrete
fill 224 146 348 224 147 348 minecraft:light_gray_concrete
fill 224 146 350 224 147 350 minecraft:light_gray_concrete
fill 225 146 325 225 147 325 minecraft:light_gray_concrete
fill 225 146 327 225 147 327 minecraft:light_gray_concrete
fill 225 146 329 225 147 329 minecraft:light_gray_concrete
fill 225 146 331 225 147 331 minecraft:light_gray_concrete
fill 225 146 333 225 147 333 minecraft:light_gray_concrete
fill 225 146 339 225 147 339 minecraft:light_gray_concrete
fill 225 146 341 225 147 341 minecraft:light_gray_concrete
fill 225 146 343 225 147 343 minecraft:light_gray_concrete
fill 225 146 345 225 147 345 minecraft:light_gray_concrete
fill 225 146 347 225 147 347 minecraft:light_gray_concrete
fill 225 146 349 225 147 349 minecraft:light_gray_concrete
fill 226 146 326 226 147 326 minecraft:light_gray_concrete
fill 226 146 328 226 147 328 minecraft:light_gray_concrete
fill 226 146 330 226 147 330 minecraft:light_gray_concrete
fill 226 146 332 226 147 332 minecraft:light_gray_concrete
fill 226 146 338 226 147 338 minecraft:light_gray_concrete
fill 226 146 340 226 147 340 minecraft:light_gray_concrete
fill 226 146 342 226 147 342 minecraft:light_gray_concrete
fill 226 146 344 226 147 344 minecraft:light_gray_concrete
fill 226 146 346 226 147 346 minecraft:light_gray_concrete
fill 226 146 348 226 147 348 minecraft:light_gray_concrete
fill 226 146 350 226 147 350 minecraft:light_gray_concrete
fill 227 146 325 227 147 325 minecraft:light_gray_concrete
fill 227 146 327 227 147 327 minecraft:light_gray_concrete
fill 227 146 329 227 147 329 minecraft:light_gray_concrete
fill 227 146 331 227 147 331 minecraft:light_gray_concrete
fill 227 146 333 227 147 333 minecraft:light_gray_concrete
fill 227 146 339 227 147 339 minecraft:light_gray_concrete
fill 227 146 341 227 147 341 minecraft:light_gray_concrete
fill 227 146 343 227 147 343 minecraft:light_gray_concrete
fill 227 146 345 227 147 345 minecraft:light_gray_concrete
fill 227 146 347 227 147 347 minecraft:light_gray_concrete
fill 227 146 349 227 147 349 minecraft:light_gray_concrete
fill 228 146 326 228 147 326 minecraft:light_gray_concrete
fill 228 146 328 228 147 328 minecraft:light_gray_concrete
fill 228 146 330 228 147 330 minecraft:light_gray_concrete
fill 228 146 332 228 147 332 minecraft:light_gray_concrete
fill 228 146 338 228 147 338 minecraft:light_gray_concrete
fill 228 146 340 228 147 340 minecraft:light_gray_concrete
fill 228 146 342 228 147 342 minecraft:light_gray_concrete
fill 228 146 344 228 147 344 minecraft:light_gray_concrete
fill 228 146 346 228 147 346 minecraft:light_gray_concrete
fill 228 146 348 228 147 348 minecraft:light_gray_concrete
fill 228 146 350 228 147 350 minecraft:light_gray_concrete
fill 229 146 325 229 147 325 minecraft:light_gray_concrete
fill 229 146 327 229 147 327 minecraft:light_gray_concrete
fill 229 146 329 229 147 329 minecraft:light_gray_concrete
fill 229 146 331 229 147 331 minecraft:light_gray_concrete
fill 229 146 333 229 147 333 minecraft:light_gray_concrete
fill 229 146 339 229 147 339 minecraft:light_gray_concrete
fill 229 146 341 229 147 341 minecraft:light_gray_concrete
fill 229 146 343 229 147 343 minecraft:light_gray_concrete
fill 229 146 345 229 147 345 minecraft:light_gray_concrete
fill 229 146 347 229 147 347 minecraft:light_gray_concrete
fill 229 146 349 229 147 349 minecraft:light_gray_concrete
fill 230 146 334 230 155 334 minecraft:black_concrete
setblock 188 147 324 minecraft:white_concrete
fill 188 147 340 188 148 340 minecraft:sea_lantern
fill 188 147 362 188 189 362 minecraft:black_concrete
setblock 193 147 364 minecraft:pearlescent_froglight
setblock 201 147 364 minecraft:white_concrete
fill 206 147 364 206 166 364 minecraft:black_concrete
fill 207 147 356 207 148 357 minecraft:gray_concrete
fill 208 147 354 208 148 354 minecraft:gray_concrete
fill 208 147 359 208 148 359 minecraft:gray_concrete
fill 210 147 360 210 148 360 minecraft:gray_concrete
fill 216 147 364 216 177 364 minecraft:black_concrete
setblock 230 147 325 minecraft:white_concrete
setblock 230 147 350 minecraft:white_concrete
setblock 230 147 357 minecraft:white_concrete
fill 188 148 324 188 215 324 minecraft:black_concrete
setblock 191 148 323 minecraft:verdant_froglight
setblock 191 148 325 minecraft:verdant_froglight
setblock 191 148 327 minecraft:verdant_froglight
setblock 192 148 324 minecraft:verdant_froglight
setblock 192 148 326 minecraft:verdant_froglight
setblock 193 148 323 minecraft:verdant_froglight
setblock 193 148 325 minecraft:verdant_froglight
setblock 193 148 327 minecraft:verdant_froglight
fill 193 148 364 193 164 364 minecraft:black_concrete
setblock 194 148 324 minecraft:verdant_froglight
setblock 194 148 326 minecraft:verdant_froglight
setblock 195 148 323 minecraft:verdant_froglight
setblock 195 148 325 minecraft:verdant_froglight
setblock 195 148 327 minecraft:verdant_froglight
setblock 196 148 324 minecraft:verdant_froglight
setblock 196 148 326 minecraft:verdant_froglight
setblock 197 148 323 minecraft:verdant_froglight
setblock 197 148 325 minecraft:verdant_froglight
setblock 197 148 327 minecraft:verdant_froglight
setblock 198 148 324 minecraft:verdant_froglight
setblock 198 148 326 minecraft:verdant_froglight
setblock 199 148 323 minecraft:verdant_froglight
setblock 199 148 325 minecraft:verdant_froglight
setblock 199 148 327 minecraft:verdant_froglight
setblock 200 148 324 minecraft:verdant_froglight
setblock 200 148 326 minecraft:verdant_froglight
setblock 201 148 323 minecraft:verdant_froglight
setblock 201 148 325 minecraft:verdant_froglight
setblock 201 148 327 minecraft:verdant_froglight
fill 201 148 364 201 207 364 minecraft:black_concrete
setblock 202 148 324 minecraft:verdant_froglight
setblock 202 148 326 minecraft:verdant_froglight
setblock 203 148 323 minecraft:verdant_froglight
setblock 203 148 325 minecraft:verdant_froglight
setblock 203 148 327 minecraft:verdant_froglight
setblock 207 148 355 minecraft:gray_concrete
setblock 207 148 358 minecraft:gray_concrete
fill 209 148 353 212 148 353 minecraft:gray_concrete
setblock 209 148 360 minecraft:gray_concrete
fill 211 148 360 212 148 360 minecraft:gray_concrete
setblock 212 148 364 minecraft:ochre_froglight
setblock 213 148 354 minecraft:gray_concrete
setblock 213 148 359 minecraft:gray_concrete
fill 214 148 355 214 148 358 minecraft:gray_concrete
setblock 219 148 364 minecraft:white_concrete
setblock 222 148 322 minecraft:sea_lantern
setblock 223 148 325 minecraft:verdant_froglight
setblock 223 148 327 minecraft:verdant_froglight
setblock 223 148 329 minecraft:verdant_froglight
setblock 223 148 331 minecraft:verdant_froglight
setblock 223 148 333 minecraft:verdant_froglight
setblock 224 148 326 minecraft:verdant_froglight
setblock 224 148 328 minecraft:verdant_froglight
setblock 224 148 330 minecraft:verdant_froglight
setblock 224 148 332 minecraft:verdant_froglight
setblock 224 148 338 minecraft:verdant_froglight
setblock 224 148 340 minecraft:verdant_froglight
setblock 224 148 342 minecraft:verdant_froglight
setblock 224 148 344 minecraft:verdant_froglight
setblock 224 148 346 minecraft:verdant_froglight
setblock 224 148 348 minecraft:verdant_froglight
setblock 224 148 350 minecraft:verdant_froglight
setblock 225 148 325 minecraft:verdant_froglight
setblock 225 148 327 minecraft:verdant_froglight
setblock 225 148 329 minecraft:verdant_froglight
setblock 225 148 331 minecraft:verdant_froglight
setblock 225 148 333 minecraft:verdant_froglight
setblock 225 148 339 minecraft:verdant_froglight
setblock 225 148 341 minecraft:verdant_froglight
setblock 225 148 343 minecraft:verdant_froglight
setblock 225 148 345 minecraft:verdant_froglight
setblock 225 148 347 minecraft:verdant_froglight
setblock 225 148 349 minecraft:verdant_froglight
setblock 226 148 326 minecraft:verdant_froglight
setblock 226 148 328 minecraft:verdant_froglight
setblock 226 148 330 minecraft:verdant_froglight
setblock 226 148 332 minecraft:verdant_froglight
setblock 226 148 338 minecraft:verdant_froglight
setblock 226 148 340 minecraft:verdant_froglight
setblock 226 148 342 minecraft:verdant_froglight
setblock 226 148 344 minecraft:verdant_froglight
setblock 226 148 346 minecraft:verdant_froglight
setblock 226 148 348 minecraft:verdant_froglight
setblock 226 148 350 minecraft:verdant_froglight
setblock 227 148 325 minecraft:verdant_froglight
setblock 227 148 327 minecraft:verdant_froglight
setblock 227 148 329 minecraft:verdant_froglight
setblock 227 148 331 minecraft:verdant_froglight
setblock 227 148 333 minecraft:verdant_froglight
setblock 227 148 339 minecraft:verdant_froglight
setblock 227 148 341 minecraft:verdant_froglight
setblock 227 148 343 minecraft:verdant_froglight
setblock 227 148 345 minecraft:verdant_froglight
setblock 227 148 347 minecraft:verdant_froglight
setblock 227 148 349 minecraft:verdant_froglight
setblock 228 148 326 minecraft:verdant_froglight
setblock 228 148 328 minecraft:verdant_froglight
setblock 228 148 330 minecraft:verdant_froglight
setblock 228 148 332 minecraft:verdant_froglight
setblock 228 148 338 minecraft:verdant_froglight
setblock 228 148 340 minecraft:verdant_froglight
setblock 228 148 342 minecraft:verdant_froglight
setblock 228 148 344 minecraft:verdant_froglight
setblock 228 148 346 minecraft:verdant_froglight
setblock 228 148 348 minecraft:verdant_froglight
setblock 228 148 350 minecraft:verdant_froglight
setblock 229 148 325 minecraft:verdant_froglight
setblock 229 148 327 minecraft:verdant_froglight
setblock 229 148 329 minecraft:verdant_froglight
setblock 229 148 331 minecraft:verdant_froglight
setblock 229 148 333 minecraft:verdant_froglight
setblock 229 148 339 minecraft:verdant_froglight
setblock 229 148 341 minecraft:verdant_froglight
setblock 229 148 343 minecraft:verdant_froglight
setblock 229 148 345 minecraft:verdant_froglight
setblock 229 148 347 minecraft:verdant_froglight
setblock 229 148 349 minecraft:verdant_froglight
fill 230 148 325 230 150 325 minecraft:black_concrete
setblock 230 148 348 minecraft:white_concrete
fill 230 148 350 230 226 350 minecraft:black_concrete
fill 230 148 357 230 216 357 minecraft:black_concrete
setblock 188 149 331 minecraft:pearlescent_froglight
setblock 188 149 340 minecraft:pearlescent_froglight
fill 191 149 323 191 151 323 minecraft:light_gray_concrete
fill 191 149 325 191 151 325 minecraft:light_gray_concrete
fill 191 149 327 191 151 327 minecraft:light_gray_concrete
fill 192 149 324 192 151 324 minecraft:light_gray_concrete
fill 192 149 326 192 151 326 minecraft:light_gray_concrete
fill 193 149 323 193 151 323 minecraft:light_gray_concrete
fill 193 149 325 193 151 325 minecraft:light_gray_concrete
fill 193 149 327 193 151 327 minecraft:light_gray_concrete
fill 194 149 324 194 151 324 minecraft:light_gray_concrete
fill 194 149 326 194 151 326 minecraft:light_gray_concrete
fill 195 149 323 195 151 323 minecraft:light_gray_concrete
fill 195 149 325 195 151 325 minecraft:light_gray_concrete
fill 195 149 327 195 151 327 minecraft:light_gray_concrete
fill 196 149 324 196 151 324 minecraft:light_gray_concrete
fill 196 149 326 196 151 326 minecraft:light_gray_concrete
fill 197 149 323 197 151 323 minecraft:light_gray_concrete
fill 197 149 325 197 151 325 minecraft:light_gray_concrete
fill 197 149 327 197 151 327 minecraft:light_gray_concrete
fill 198 149 324 198 151 324 minecraft:light_gray_concrete
fill 198 149 326 198 151 326 minecraft:light_gray_concrete
fill 199 149 323 199 151 323 minecraft:light_gray_concrete
fill 199 149 325 199 151 325 minecraft:light_gray_concrete
fill 199 149 327 199 151 327 minecraft:light_gray_concrete
fill 200 149 324 200 151 324 minecraft:light_gray_concrete
fill 200 149 326 200 151 326 minecraft:light_gray_concrete
fill 201 149 323 201 151 323 minecraft:light_gray_concrete
fill 201 149 325 201 151 325 minecraft:light_gray_concrete
fill 201 149 327 201 151 327 minecraft:light_gray_concrete
fill 202 149 324 202 151 324 minecraft:light_gray_concrete
fill 202 149 326 202 151 326 minecraft:light_gray_concrete
fill 203 149 323 203 151 323 minecraft:light_gray_concrete
fill 203 149 325 203 151 325 minecraft:light_gray_concrete
fill 203 149 327 203 151 327 minecraft:light_gray_concrete
fill 212 149 364 212 182 364 minecraft:black_concrete
setblock 213 149 322 minecraft:ochre_froglight
fill 215 149 332 216 156 333 minecraft:lime_stained_glass
fill 219 149 364 219 195 364 minecraft:black_concrete
fill 222 149 322 222 182 322 minecraft:black_concrete
fill 223 149 325 223 151 325 minecraft:light_gray_concrete
fill 223 149 327 223 151 327 minecraft:light_gray_concrete
fill 223 149 329 223 151 329 minecraft:light_gray_concrete
fill 223 149 331 223 151 331 minecraft:light_gray_concrete
fill 223 149 333 223 151 333 minecraft:light_gray_concrete
fill 223 149 334 223 150 334 minecraft:gray_concrete
fill 224 149 326 224 151 326 minecraft:light_gray_concrete
fill 224 149 328 224 151 328 minecraft:light_gray_concrete
fill 224 149 330 224 151 330 minecraft:light_gray_concrete
fill 224 149 332 224 151 332 minecraft:light_gray_concrete
fill 224 149 338 224 151 338 minecraft:light_gray_concrete
fill 224 149 340 224 151 340 minecraft:light_gray_concrete
fill 224 149 342 224 151 342 minecraft:light_gray_concrete
fill 224 149 344 224 151 344 minecraft:light_gray_concrete
fill 224 149 346 224 151 346 minecraft:light_gray_concrete
fill 224 149 348 224 151 348 minecraft:light_gray_concrete
fill 224 149 350 224 151 350 minecraft:light_gray_concrete
fill 225 149 325 225 151 325 minecraft:light_gray_concrete
fill 225 149 327 225 151 327 minecraft:light_gray_concrete
fill 225 149 329 225 151 329 minecraft:light_gray_concrete
fill 225 149 331 225 151 331 minecraft:light_gray_concrete
fill 225 149 333 225 151 333 minecraft:light_gray_concrete
fill 225 149 339 225 151 339 minecraft:light_gray_concrete
fill 225 149 341 225 151 341 minecraft:light_gray_concrete
fill 225 149 343 225 151 343 minecraft:light_gray_concrete
fill 225 149 345 225 151 345 minecraft:light_gray_concrete
fill 225 149 347 225 151 347 minecraft:light_gray_concrete
fill 225 149 349 225 151 349 minecraft:light_gray_concrete
fill 226 149 326 226 151 326 minecraft:light_gray_concrete
fill 226 149 328 226 151 328 minecraft:light_gray_concrete
fill 226 149 330 226 151 330 minecraft:light_gray_concrete
fill 226 149 332 226 151 332 minecraft:light_gray_concrete
fill 226 149 338 226 151 338 minecraft:light_gray_concrete
fill 226 149 340 226 151 340 minecraft:light_gray_concrete
fill 226 149 342 226 151 342 minecraft:light_gray_concrete
fill 226 149 344 226 151 344 minecraft:light_gray_concrete
fill 226 149 346 226 151 346 minecraft:light_gray_concrete
fill 226 149 348 226 151 348 minecraft:light_gray_concrete
fill 226 149 350 226 151 350 minecraft:light_gray_concrete
fill 227 149 325 227 151 325 minecraft:light_gray_concrete
fill 227 149 327 227 151 327 minecraft:light_gray_concrete
fill 227 149 329 227 151 329 minecraft:light_gray_concrete
fill 227 149 331 227 151 331 minecraft:light_gray_concrete
fill 227 149 333 227 151 333 minecraft:light_gray_concrete
fill 227 149 339 227 151 339 minecraft:light_gray_concrete
fill 227 149 341 227 151 341 minecraft:light_gray_concrete
fill 227 149 343 227 151 343 minecraft:light_gray_concrete
fill 227 149 345 227 151 345 minecraft:light_gray_concrete
fill 227 149 347 227 151 347 minecraft:light_gray_concrete
fill 227 149 349 227 151 349 minecraft:light_gray_concrete
fill 228 149 326 228 151 326 minecraft:light_gray_concrete
fill 228 149 328 228 151 328 minecraft:light_gray_concrete
fill 228 149 330 228 151 330 minecraft:light_gray_concrete
fill 228 149 332 228 151 332 minecraft:light_gray_concrete
fill 228 149 338 228 151 338 minecraft:light_gray_concrete
fill 228 149 340 228 151 340 minecraft:light_gray_concrete
fill 228 149 342 228 151 342 minecraft:light_gray_concrete
fill 228 149 344 228 151 344 minecraft:light_gray_concrete
fill 228 149 346 228 151 346 minecraft:light_gray_concrete
fill 228 149 348 228 151 348 minecraft:light_gray_concrete
fill 228 149 350 228 151 350 minecraft:light_gray_concrete
fill 229 149 325 229 151 325 minecraft:light_gray_concrete
fill 229 149 327 229 151 327 minecraft:light_gray_concrete
fill 229 149 329 229 151 329 minecraft:light_gray_concrete
fill 229 149 331 229 151 331 minecraft:light_gray_concrete
fill 229 149 333 229 151 333 minecraft:light_gray_concrete
fill 229 149 339 229 151 339 minecraft:light_gray_concrete
fill 229 149 341 229 151 341 minecraft:light_gray_concrete
fill 229 149 343 229 151 343 minecraft:light_gray_concrete
fill 229 149 345 229 151 345 minecraft:light_gray_concrete
fill 229 149 347 229 151 347 minecraft:light_gray_concrete
fill 229 149 349 229 151 349 minecraft:light_gray_concrete
setblock 230 149 331 minecraft:sea_lantern
setblock 230 149 332 minecraft:ochre_froglight
fill 230 149 348 230 180 348 minecraft:black_concrete
setblock 230 149 363 minecraft:pearlescent_froglight
setblock 188 150 328 minecraft:white_concrete
fill 188 150 331 188 178 331 minecraft:black_concrete
fill 188 150 340 188 308 340 minecraft:black_concrete
fill 191 150 341 192 151 345 minecraft:light_gray_concrete
fill 192 150 337 192 151 340 minecraft:light_gray_concrete
fill 192 150 346 192 151 349 minecraft:light_gray_concrete
fill 193 150 335 193 151 337 minecraft:light_gray_concrete
fill 193 150 349 193 151 351 minecraft:light_gray_concrete
fill 194 150 333 194 151 335 minecraft:light_gray_concrete
fill 194 150 351 194 151 353 minecraft:light_gray_concrete
fill 195 150 332 195 151 333 minecraft:light_gray_concrete
fill 195 150 353 195 151 354 minecraft:light_gray_concrete
fill 196 150 331 196 151 332 minecraft:light_gray_concrete
fill 196 150 354 196 151 355 minecraft:light_gray_concrete
fill 197 150 330 197 151 331 minecraft:light_gray_concrete
fill 197 150 355 197 151 356 minecraft:light_gray_concrete
fill 198 150 329 198 151 330 minecraft:light_gray_concrete
fill 198 150 356 198 151 357 minecraft:light_gray_concrete
fill 199 150 328 199 151 329 minecraft:light_gray_concrete
fill 199 150 357 199 151 358 minecraft:light_gray_concrete
fill 200 150 328 201 151 328 minecraft:light_gray_concrete
fill 200 150 358 201 151 358 minecraft:light_gray_concrete
fill 201 150 359 203 151 359 minecraft:light_gray_concrete
fill 203 150 360 215 151 360 minecraft:light_gray_concrete
fill 204 150 326 215 151 326 minecraft:light_gray_concrete
fill 207 150 325 211 151 325 minecraft:light_gray_concrete
fill 207 150 361 211 151 361 minecraft:light_gray_concrete
fill 213 150 322 213 175 322 minecraft:black_concrete
fill 215 150 327 217 150 327 minecraft:light_gray_concrete
fill 215 150 359 217 151 359 minecraft:light_gray_concrete
fill 217 150 328 219 151 328 minecraft:light_gray_concrete
fill 217 150 358 219 151 358 minecraft:light_gray_concrete
fill 219 150 329 220 151 329 minecraft:light_gray_concrete
fill 219 150 357 220 151 357 minecraft:light_gray_concrete
fill 220 150 330 221 151 330 minecraft:light_gray_concrete
fill 220 150 356 221 151 356 minecraft:light_gray_concrete
fill 221 150 331 222 151 331 minecraft:light_gray_concrete
fill 221 150 355 222 151 355 minecraft:light_gray_concrete
fill 222 150 332 222 151 332 minecraft:light_gray_concrete
fill 222 150 354 223 151 354 minecraft:light_gray_concrete
setblock 222 150 364 minecraft:white_concrete
fill 223 150 353 224 151 353 minecraft:light_gray_concrete
fill 224 150 334 224 151 335 minecraft:light_gray_concrete
fill 224 150 351 224 151 352 minecraft:light_gray_concrete
fill 225 150 335 225 151 337 minecraft:light_gray_concrete
fill 225 150 351 225 151 351 minecraft:light_gray_concrete
fill 226 150 337 226 151 337 minecraft:light_gray_concrete
fill 230 150 331 230 157 332 minecraft:black_concrete
fill 230 150 363 230 189 363 minecraft:black_concrete
fill 188 151 328 188 164 328 minecraft:black_concrete
setblock 188 151 341 minecraft:white_concrete
setblock 191 151 332 minecraft:light[level=12]
setblock 191 151 339 minecraft:light[level=12]
setblock 191 151 346 minecraft:light[level=12]
setblock 191 151 353 minecraft:light[level=12]
setblock 191 151 360 minecraft:light[level=12]
setblock 198 151 332 minecraft:light[level=12]
setblock 198 151 339 minecraft:light[level=12]
setblock 198 151 346 minecraft:light[level=12]
setblock 198 151 353 minecraft:light[level=12]
setblock 198 151 360 minecraft:light[level=12]
setblock 205 151 325 minecraft:light[level=12]
setblock 205 151 332 minecraft:light[level=12]
setblock 205 151 339 minecraft:light[level=12]
setblock 205 151 346 minecraft:light[level=12]
setblock 205 151 353 minecraft:light[level=12]
setblock 212 151 325 minecraft:light[level=12]
setblock 212 151 332 minecraft:light[level=12]
setblock 212 151 339 minecraft:light[level=12]
setblock 212 151 346 minecraft:light[level=12]
setblock 212 151 353 minecraft:light[level=12]
fill 213 151 327 215 151 331 minecraft:white_concrete
fill 216 151 327 217 151 327 minecraft:light_gray_concrete
setblock 219 151 325 minecraft:light[level=12]
setblock 219 151 332 minecraft:light[level=12]
setblock 219 151 339 minecraft:light[level=12]
setblock 219 151 346 minecraft:light[level=12]
setblock 219 151 353 minecraft:light[level=12]
setblock 219 151 360 minecraft:light[level=12]
fill 222 151 364 222 198 364 minecraft:black_concrete
setblock 226 151 353 minecraft:light[level=12]
setblock 226 151 360 minecraft:light[level=12]
setblock 230 151 325 minecraft:white_concrete
fill 230 151 341 230 154 341 minecraft:black_concrete
setblock 230 151 342 minecraft:ochre_froglight
fill 188 152 341 188 229 341 minecraft:black_concrete
fill 213 152 327 213 152 331 minecraft:white_concrete
fill 214 152 327 215 152 327 minecraft:white_concrete
fill 214 152 328 214 152 329 minecraft:black_concrete
fill 214 152 330 215 152 331 minecraft:white_concrete
setblock 214 152 364 minecraft:pearlescent_froglight
fill 215 152 328 215 152 329 minecraft:white_concrete
fill 230 152 325 230 217 325 minecraft:black_concrete
fill 230 152 342 230 190 342 minecraft:black_concrete
setblock 230 152 361 minecraft:sea_lantern
setblock 191 153 325 minecraft:light[level=15]
setblock 191 153 333 minecraft:light[level=15]
setblock 191 153 341 minecraft:light[level=15]
setblock 191 153 349 minecraft:light[level=15]
setblock 191 153 357 minecraft:light[level=15]
setblock 199 153 325 minecraft:light[level=15]
setblock 199 153 333 minecraft:light[level=15]
setblock 199 153 341 minecraft:light[level=15]
setblock 199 153 349 minecraft:light[level=15]
setblock 199 153 357 minecraft:light[level=15]
setblock 204 153 364 minecraft:ochre_froglight
setblock 207 153 325 minecraft:light[level=15]
setblock 207 153 333 minecraft:light[level=15]
setblock 207 153 341 minecraft:light[level=15]
setblock 207 153 349 minecraft:light[level=15]
setblock 207 153 357 minecraft:light[level=15]
fill 214 153 364 214 161 364 minecraft:black_concrete
setblock 215 153 325 minecraft:light[level=15]
setblock 215 153 341 minecraft:light[level=15]
setblock 215 153 349 minecraft:light[level=15]
setblock 215 153 357 minecraft:light[level=15]
setblock 223 153 325 minecraft:light[level=15]
setblock 223 153 333 minecraft:light[level=15]
setblock 223 153 341 minecraft:light[level=15]
setblock 223 153 349 minecraft:light[level=15]
setblock 223 153 357 minecraft:light[level=15]
setblock 230 153 347 minecraft:white_concrete
setblock 230 153 352 minecraft:sea_lantern
fill 230 153 361 230 164 361 minecraft:black_concrete
fill 204 154 364 204 250 364 minecraft:black_concrete
setblock 230 154 333 minecraft:pearlescent_froglight
setblock 230 154 336 minecraft:pearlescent_froglight
fill 230 154 347 230 207 347 minecraft:black_concrete
fill 230 154 352 230 183 352 minecraft:black_concrete
setblock 194 155 322 minecraft:pearlescent_froglight
setblock 195 155 364 minecraft:ochre_froglight
setblock 196 155 364 minecraft:sea_lantern
setblock 220 155 322 minecraft:pearlescent_froglight
setblock 226 155 322 minecraft:pearlescent_froglight
fill 230 155 333 230 216 333 minecraft:black_concrete
fill 230 155 336 230 174 336 minecraft:black_concrete
setblock 230 155 341 minecraft:white_concrete
setblock 188 156 329 minecraft:white_concrete
setblock 188 156 348 minecraft:white_concrete
fill 194 156 322 194 308 322 minecraft:black_concrete
fill 195 156 364 196 161 364 minecraft:black_concrete
fill 220 156 322 220 166 322 minecraft:black_concrete
setblock 221 156 364 minecraft:pearlescent_froglight
fill 226 156 322 226 190 322 minecraft:black_concrete
setblock 230 156 334 minecraft:white_concrete
fill 230 156 341 230 198 341 minecraft:black_concrete
setblock 230 156 346 minecraft:white_concrete
fill 188 157 329 188 241 329 minecraft:black_concrete
fill 188 157 348 188 160 348 minecraft:black_concrete
fill 189 157 323 196 158 363 minecraft:hay_block
fill 197 157 323 197 158 342 minecraft:hay_block
fill 197 157 343 197 158 349 minecraft:green_concrete
fill 197 157 350 197 158 363 minecraft:hay_block
setblock 198 157 322 minecraft:pearlescent_froglight
fill 198 157 323 198 158 339 minecraft:hay_block
fill 198 157 340 198 158 343 minecraft:green_concrete
fill 198 157 344 200 158 348 minecraft:hay_block
fill 198 157 349 198 158 352 minecraft:green_concrete
fill 198 157 353 198 158 363 minecraft:hay_block
fill 199 157 323 199 158 338 minecraft:hay_block
fill 199 157 339 199 158 340 minecraft:green_concrete
fill 199 157 341 200 158 343 minecraft:hay_block
fill 199 157 349 200 158 351 minecraft:hay_block
fill 199 157 352 199 158 353 minecraft:green_concrete
fill 199 157 354 199 158 363 minecraft:hay_block
fill 200 157 323 200 158 337 minecraft:hay_block
fill 200 157 338 200 158 339 minecraft:green_concrete
fill 200 157 340 202 158 340 minecraft:hay_block
fill 200 157 352 202 158 352 minecraft:hay_block
fill 200 157 353 200 158 354 minecraft:green_concrete
fill 200 157 355 200 158 363 minecraft:hay_block
fill 201 157 323 201 158 336 minecraft:hay_block
fill 201 157 337 202 158 337 minecraft:green_concrete
fill 201 157 338 204 158 339 minecraft:hay_block
fill 201 157 341 201 158 342 minecraft:hay_block
fill 201 157 343 201 158 349 minecraft:green_concrete
fill 201 157 350 201 158 351 minecraft:hay_block
fill 201 157 353 204 158 354 minecraft:hay_block
fill 201 157 355 202 158 355 minecraft:green_concrete
fill 201 157 356 201 158 363 minecraft:hay_block
fill 202 157 323 202 158 335 minecraft:hay_block
fill 202 157 336 203 158 336 minecraft:green_concrete
fill 202 157 341 202 158 341 minecraft:hay_block
fill 202 157 342 202 158 343 minecraft:green_concrete
fill 202 157 344 204 158 348 minecraft:hay_block
fill 202 157 349 202 158 350 minecraft:green_concrete
fill 202 157 351 202 158 351 minecraft:hay_block
fill 202 157 356 203 158 356 minecraft:green_concrete
fill 202 157 357 202 158 363 minecraft:hay_block
fill 203 157 323 205 158 334 minecraft:hay_block
fill 203 157 335 206 158 335 minecraft:green_concrete
fill 203 157 337 208 158 337 minecraft:hay_block
fill 203 157 340 203 158 341 minecraft:green_concrete
fill 203 157 342 205 158 343 minecraft:hay_block
fill 203 157 349 205 158 350 minecraft:hay_block
fill 203 157 351 203 158 352 minecraft:green_concrete
fill 203 157 355 208 158 355 minecraft:hay_block
fill 203 157 357 206 158 357 minecraft:green_concrete
fill 203 157 358 205 158 363 minecraft:hay_block
fill 204 157 336 208 158 336 minecraft:hay_block
fill 204 157 340 204 158 340 minecraft:green_concrete
fill 204 157 341 214 158 341 minecraft:hay_block
fill 204 157 351 214 158 351 minecraft:hay_block
fill 204 157 352 204 158 352 minecraft:green_concrete
fill 204 157 356 208 158 356 minecraft:hay_block
fill 205 157 338 205 158 338 minecraft:hay_block
fill 205 157 339 206 158 339 minecraft:green_concrete
fill 205 157 340 213 158 340 minecraft:hay_block
fill 205 157 344 205 158 348 minecraft:green_concrete
fill 205 157 352 213 158 352 minecraft:hay_block
fill 205 157 353 206 158 353 minecraft:green_concrete
fill 205 157 354 205 158 354 minecraft:hay_block
fill 206 157 323 208 158 333 minecraft:hay_block
fill 206 157 334 212 158 334 minecraft:green_concrete
fill 206 157 338 212 158 338 minecraft:green_concrete
fill 206 157 342 206 158 342 minecraft:hay_block
fill 206 157 343 206 157 344 minecraft:green_concrete
fill 206 157 345 206 157 347 minecraft:hay_block
fill 206 157 348 206 157 349 minecraft:green_concrete
fill 206 157 350 206 158 350 minecraft:hay_block
fill 206 157 354 212 158 354 minecraft:green_concrete
fill 206 157 358 212 158 358 minecraft:green_concrete
fill 206 157 359 208 158 363 minecraft:hay_block
fill 207 157 335 208 158 335 minecraft:hay_block
fill 207 157 339 211 158 339 minecraft:hay_block
fill 207 157 342 207 157 343 minecraft:green_concrete
setblock 207 157 344 minecraft:hay_block
setblock 207 157 348 minecraft:hay_block
fill 207 157 349 207 157 350 minecraft:green_concrete
fill 207 157 353 211 158 353 minecraft:hay_block
fill 207 157 357 208 158 357 minecraft:hay_block
fill 208 157 342 211 158 342 minecraft:green_concrete
fill 208 157 343 210 157 343 minecraft:hay_block
fill 208 157 349 210 157 349 minecraft:hay_block
fill 208 157 350 211 158 350 minecraft:green_concrete
fill 209 157 323 209 158 333 minecraft:green_concrete
fill 209 157 335 209 158 337 minecraft:green_concrete
fill 209 157 355 209 158 357 minecraft:green_concrete
fill 209 157 359 209 158 363 minecraft:green_concrete
fill 210 157 323 229 158 333 minecraft:hay_block
fill 210 157 335 211 158 337 minecraft:hay_block
fill 210 157 355 211 158 357 minecraft:hay_block
fill 210 157 359 229 158 363 minecraft:hay_block
fill 211 157 343 212 157 343 minecraft:green_concrete
setblock 211 157 344 minecraft:hay_block
setblock 211 157 348 minecraft:hay_block
fill 211 157 349 212 157 349 minecraft:green_concrete
fill 212 157 335 215 158 335 minecraft:green_concrete
fill 212 157 336 214 158 337 minecraft:hay_block
fill 212 157 339 213 158 339 minecraft:green_concrete
fill 212 157 342 215 158 342 minecraft:hay_block
fill 212 157 344 213 157 344 minecraft:green_concrete
fill 212 157 345 212 157 347 minecraft:hay_block
fill 212 157 348 213 157 348 minecraft:green_concrete
fill 212 157 350 215 158 350 minecraft:hay_block
fill 212 157 353 213 158 353 minecraft:green_concrete
fill 212 157 355 214 158 356 minecraft:hay_block
fill 212 157 357 215 158 357 minecraft:green_concrete
fill 213 157 334 229 158 334 minecraft:hay_block
fill 213 157 338 217 158 338 minecraft:hay_block
fill 213 157 343 215 158 343 minecraft:hay_block
fill 213 157 345 213 158 347 minecraft:green_concrete
fill 213 157 349 215 158 349 minecraft:hay_block
fill 213 157 354 217 158 354 minecraft:hay_block
fill 213 157 358 229 158 358 minecraft:hay_block
fill 214 157 339 217 158 339 minecraft:hay_block
fill 214 157 340 215 158 340 minecraft:green_concrete
fill 214 157 344 216 158 348 minecraft:hay_block
fill 214 157 352 215 158 352 minecraft:green_concrete
fill 214 157 353 217 158 353 minecraft:hay_block
fill 215 157 336 216 158 336 minecraft:green_concrete
fill 215 157 337 215 158 337 minecraft:hay_block
fill 215 157 341 215 158 341 minecraft:green_concrete
fill 215 157 351 215 158 351 minecraft:green_concrete
fill 215 157 355 215 158 355 minecraft:hay_block
fill 215 157 356 216 158 356 minecraft:green_concrete
fill 216 157 335 229 158 335 minecraft:hay_block
fill 216 157 337 217 158 337 minecraft:green_concrete
fill 216 157 340 218 158 341 minecraft:hay_block
fill 216 157 342 216 158 343 minecraft:green_concrete
fill 216 157 349 216 158 350 minecraft:green_concrete
fill 216 157 351 218 158 352 minecraft:hay_block
fill 216 157 355 217 158 355 minecraft:green_concrete
fill 216 157 357 229 158 357 minecraft:hay_block
fill 217 157 336 229 158 336 minecraft:hay_block
fill 217 157 342 219 158 342 minecraft:hay_block
fill 217 157 343 217 158 349 minecraft:green_concrete
fill 217 157 350 219 158 350 minecraft:hay_block
fill 217 157 356 229 158 356 minecraft:hay_block
fill 218 157 337 229 158 337 minecraft:hay_block
fill 218 157 338 218 158 339 minecraft:green_concrete
fill 218 157 343 219 158 349 minecraft:hay_block
fill 218 157 353 218 158 354 minecraft:green_concrete
fill 218 157 355 229 158 355 minecraft:hay_block
fill 219 157 338 229 158 338 minecraft:hay_block
fill 219 157 339 219 158 340 minecraft:green_concrete
fill 219 157 341 219 158 341 minecraft:hay_block
fill 219 157 351 219 158 351 minecraft:hay_block
fill 219 157 352 219 158 353 minecraft:green_concrete
fill 219 157 354 229 158 354 minecraft:hay_block
fill 220 157 339 229 158 339 minecraft:hay_block
fill 220 157 340 220 158 343 minecraft:green_concrete
fill 220 157 344 220 158 348 minecraft:hay_block
fill 220 157 349 220 158 352 minecraft:green_concrete
fill 220 157 353 229 158 353 minecraft:hay_block
fill 221 157 340 229 158 342 minecraft:hay_block
fill 221 157 343 221 158 349 minecraft:green_concrete
fill 221 157 350 229 158 352 minecraft:hay_block
fill 221 157 364 221 166 364 minecraft:black_concrete
fill 222 157 343 229 158 349 minecraft:hay_block
setblock 230 157 329 minecraft:pearlescent_froglight
fill 230 157 334 230 200 334 minecraft:black_concrete
fill 230 157 346 230 308 346 minecraft:black_concrete
fill 198 158 322 198 183 322 minecraft:black_concrete
setblock 206 158 343 minecraft:green_concrete
fill 206 158 344 206 158 348 minecraft:verdant_froglight
setblock 206 158 349 minecraft:green_concrete
setblock 207 158 342 minecraft:green_concrete
fill 207 158 343 207 158 344 minecraft:verdant_froglight
fill 207 158 348 207 158 349 minecraft:verdant_froglight
setblock 207 158 350 minecraft:green_concrete
fill 208 158 343 211 158 343 minecraft:verdant_froglight
fill 208 158 349 211 158 349 minecraft:verdant_froglight
fill 211 158 344 212 158 344 minecraft:verdant_froglight
fill 211 158 348 212 158 348 minecraft:verdant_froglight
setblock 212 158 343 minecraft:green_concrete
fill 212 158 345 212 158 347 minecraft:verdant_froglight
setblock 212 158 349 minecraft:green_concrete
setblock 213 158 344 minecraft:green_concrete
setblock 213 158 348 minecraft:green_concrete
fill 230 158 329 230 212 329 minecraft:black_concrete
setblock 230 158 331 minecraft:ochre_froglight
fill 230 158 332 230 182 332 minecraft:black_concrete
setblock 188 159 330 minecraft:white_concrete
fill 230 159 331 230 210 331 minecraft:black_concrete
setblock 188 160 323 minecraft:sea_lantern
fill 188 160 330 188 221 330 minecraft:black_concrete
setblock 188 160 332 minecraft:sea_lantern
fill 210 160 356 211 167 357 minecraft:lime_stained_glass
fill 188 161 323 188 198 323 minecraft:black_concrete
setblock 188 161 326 minecraft:white_concrete
fill 188 161 332 188 200 332 minecraft:black_concrete
setblock 188 161 338 minecraft:sea_lantern
setblock 188 161 348 minecraft:pearlescent_froglight
setblock 191 161 325 minecraft:light[level=15]
setblock 191 161 333 minecraft:light[level=15]
setblock 191 161 341 minecraft:light[level=15]
setblock 191 161 349 minecraft:light[level=15]
setblock 191 161 357 minecraft:light[level=15]
setblock 199 161 325 minecraft:light[level=15]
setblock 199 161 333 minecraft:light[level=15]
setblock 199 161 341 minecraft:light[level=15]
setblock 199 161 349 minecraft:light[level=15]
setblock 199 161 357 minecraft:light[level=15]
setblock 207 161 325 minecraft:light[level=15]
setblock 207 161 333 minecraft:light[level=15]
setblock 207 161 341 minecraft:light[level=15]
setblock 207 161 349 minecraft:light[level=15]
setblock 207 161 357 minecraft:light[level=15]
fill 209 161 356 209 166 356 minecraft:lime_stained_glass
setblock 215 161 325 minecraft:light[level=15]
setblock 215 161 333 minecraft:light[level=15]
setblock 215 161 341 minecraft:light[level=15]
setblock 215 161 349 minecraft:light[level=15]
setblock 215 161 357 minecraft:light[level=15]
setblock 223 161 325 minecraft:light[level=15]
setblock 223 161 333 minecraft:light[level=15]
setblock 223 161 341 minecraft:light[level=15]
setblock 223 161 349 minecraft:light[level=15]
setblock 223 161 357 minecraft:light[level=15]
fill 188 162 326 188 236 326 minecraft:black_concrete
fill 188 162 338 188 182 338 minecraft:black_concrete
fill 188 162 348 188 235 348 minecraft:black_concrete
fill 192 162 344 195 168 344 minecraft:gray_concrete
fill 193 162 343 194 168 343 minecraft:gray_concrete
fill 193 162 345 195 168 345 minecraft:gray_concrete
setblock 195 162 364 minecraft:pearlescent_froglight
fill 196 162 364 196 252 364 minecraft:black_concrete
setblock 202 162 364 minecraft:white_concrete
setblock 208 162 364 minecraft:ochre_froglight
setblock 214 162 364 minecraft:ochre_froglight
setblock 229 162 364 minecraft:white_concrete
fill 230 162 364 230 308 364 minecraft:black_concrete
setblock 189 163 364 minecraft:ochre_froglight
setblock 191 163 325 minecraft:light[level=12]
setblock 191 163 332 minecraft:light[level=12]
setblock 191 163 339 minecraft:light[level=12]
setblock 191 163 346 minecraft:light[level=12]
setblock 191 163 353 minecraft:light[level=12]
setblock 191 163 360 minecraft:light[level=12]
fill 192 163 343 192 168 343 minecraft:gray_concrete
fill 192 163 345 192 168 345 minecraft:gray_concrete
fill 193 163 346 194 168 346 minecraft:gray_concrete
fill 195 163 343 195 168 343 minecraft:gray_concrete
fill 195 163 364 195 207 364 minecraft:black_concrete
setblock 198 163 325 minecraft:light[level=12]
setblock 198 163 332 minecraft:light[level=12]
setblock 198 163 339 minecraft:light[level=12]
setblock 198 163 346 minecraft:light[level=12]
setblock 198 163 353 minecraft:light[level=12]
setblock 198 163 360 minecraft:light[level=12]
fill 202 163 364 202 207 364 minecraft:black_concrete
setblock 205 163 325 minecraft:light[level=12]
setblock 205 163 332 minecraft:light[level=12]
setblock 205 163 339 minecraft:light[level=12]
setblock 205 163 346 minecraft:light[level=12]
setblock 205 163 353 minecraft:light[level=12]
setblock 205 163 360 minecraft:light[level=12]
fill 208 163 364 208 170 364 minecraft:black_concrete
setblock 212 163 325 minecraft:light[level=12]
setblock 212 163 332 minecraft:light[level=12]
setblock 212 163 339 minecraft:light[level=12]
setblock 212 163 346 minecraft:light[level=12]
setblock 212 163 353 minecraft:light[level=12]
setblock 212 163 360 minecraft:light[level=12]
fill 214 163 364 214 176 364 minecraft:black_concrete
setblock 219 163 325 minecraft:light[level=12]
setblock 219 163 332 minecraft:light[level=12]
setblock 219 163 339 minecraft:light[level=12]
setblock 219 163 346 minecraft:light[level=12]
setblock 219 163 353 minecraft:light[level=12]
setblock 219 163 360 minecraft:light[level=12]
setblock 226 163 325 minecraft:light[level=12]
setblock 226 163 332 minecraft:light[level=12]
setblock 226 163 339 minecraft:light[level=12]
setblock 226 163 346 minecraft:light[level=12]
setblock 226 163 353 minecraft:light[level=12]
setblock 226 163 360 minecraft:light[level=12]
fill 229 163 364 229 169 364 minecraft:black_concrete
setblock 230 163 339 minecraft:sea_lantern
setblock 230 163 358 minecraft:ochre_froglight
fill 189 164 364 189 173 364 minecraft:black_concrete
fill 192 164 346 192 168 346 minecraft:gray_concrete
fill 193 164 342 195 168 342 minecraft:gray_concrete
fill 195 164 346 195 168 346 minecraft:gray_concrete
fill 196 164 343 196 168 345 minecraft:gray_concrete
setblock 209 164 322 minecraft:white_concrete
setblock 230 164 339 minecraft:black_concrete
fill 230 164 358 230 239 358 minecraft:black_concrete
setblock 188 165 328 minecraft:pearlescent_froglight
setblock 188 165 361 minecraft:white_concrete
fill 191 165 343 191 168 345 minecraft:gray_concrete
fill 192 165 342 192 168 342 minecraft:gray_concrete
fill 193 165 347 195 168 347 minecraft:gray_concrete
setblock 193 165 364 minecraft:white_concrete
fill 196 165 346 196 168 346 minecraft:gray_concrete
setblock 199 165 322 minecraft:pearlescent_froglight
fill 200 165 337 200 166 337 minecraft:gray_concrete
fill 209 165 322 209 170 322 minecraft:black_concrete
setblock 225 165 364 minecraft:sea_lantern
setblock 230 165 339 minecraft:white_concrete
setblock 230 165 361 minecraft:white_concrete
setblock 230 165 362 minecraft:pearlescent_froglight
fill 188 166 328 188 233 328 minecraft:black_concrete
fill 188 166 361 188 173 361 minecraft:black_concrete
fill 191 166 342 191 168 342 minecraft:gray_concrete
fill 191 166 346 191 168 346 minecraft:gray_concrete
fill 192 166 341 195 168 341 minecraft:gray_concrete
fill 192 166 347 192 168 347 minecraft:gray_concrete
fill 193 166 364 193 220 364 minecraft:black_concrete
fill 196 166 342 196 168 342 minecraft:gray_concrete
fill 196 166 347 196 168 347 minecraft:gray_concrete
fill 197 166 343 197 168 345 minecraft:gray_concrete
setblock 198 166 364 minecraft:sea_lantern
fill 199 166 322 199 179 322 minecraft:black_concrete
setblock 207 166 322 minecraft:pearlescent_froglight
setblock 212 166 322 minecraft:ochre_froglight
setblock 214 166 322 minecraft:pearlescent_froglight
fill 223 166 340 223 167 340 minecraft:lime_stained_glass
fill 225 166 364 225 205 364 minecraft:black_concrete
fill 230 166 339 230 170 339 minecraft:black_concrete
fill 230 166 361 230 181 362 minecraft:black_concrete
setblock 188 167 363 minecraft:pearlescent_froglight
fill 188 167 364 188 308 364 minecraft:black_concrete
fill 190 167 343 190 168 346 minecraft:gray_concrete
fill 191 167 347 191 168 347 minecraft:gray_concrete
fill 193 167 348 195 168 348 minecraft:gray_concrete
fill 196 167 341 196 168 341 minecraft:gray_concrete
fill 197 167 342 197 168 342 minecraft:gray_concrete
fill 197 167 346 197 168 346 minecraft:gray_concrete
fill 198 167 364 198 244 364 minecraft:black_concrete
setblock 206 167 364 minecraft:sea_lantern
fill 207 167 322 207 252 322 minecraft:black_concrete
fill 212 167 322 212 177 322 minecraft:black_concrete
fill 214 167 322 214 185 322 minecraft:black_concrete
setblock 220 167 322 minecraft:ochre_froglight
setblock 221 167 364 minecraft:sea_lantern
setblock 224 167 364 minecraft:white_concrete
setblock 230 167 337 minecraft:white_concrete
setblock 230 167 344 minecraft:white_concrete
setblock 188 168 344 minecraft:pearlescent_froglight
fill 188 168 363 188 201 363 minecraft:black_concrete
setblock 190 168 342 minecraft:gray_concrete
setblock 191 168 341 minecraft:gray_concrete
fill 192 168 340 195 168 340 minecraft:gray_concrete
setblock 192 168 348 minecraft:gray_concrete
setblock 196 168 348 minecraft:gray_concrete
setblock 197 168 347 minecraft:gray_concrete
fill 198 168 343 198 168 345 minecraft:gray_concrete
fill 206 168 364 206 183 364 minecraft:black_concrete
fill 209 168 354 211 168 358 minecraft:white_concrete
setblock 215 168 364 minecraft:sea_lantern
fill 220 168 322 220 209 322 minecraft:black_concrete
setblock 220 168 364 minecraft:white_concrete
fill 221 168 364 221 211 364 minecraft:black_concrete
fill 223 168 340 223 178 340 minecraft:gray_concrete
fill 224 168 364 224 228 364 minecraft:black_concrete
fill 230 168 337 230 180 337 minecraft:black_concrete
setblock 230 168 343 minecraft:ochre_froglight
fill 230 168 344 230 195 344 minecraft:black_concrete
setblock 188 169 339 minecraft:ochre_froglight
fill 188 169 344 188 215 344 minecraft:black_concrete
setblock 191 169 325 minecraft:light[level=15]
setblock 191 169 332 minecraft:light[level=12]
setblock 191 169 333 minecraft:light[level=15]
setblock 191 169 339 minecraft:light[level=12]
setblock 191 169 341 minecraft:light[level=15]
setblock 191 169 346 minecraft:light[level=12]
setblock 191 169 349 minecraft:light[level=15]
setblock 191 169 353 minecraft:light[level=12]
setblock 191 169 357 minecraft:light[level=15]
setblock 191 169 360 minecraft:light[level=12]
fill 194 169 344 194 171 344 minecraft:iron_block
setblock 194 169 364 minecraft:pearlescent_froglight
setblock 198 169 325 minecraft:light[level=12]
setblock 198 169 332 minecraft:light[level=12]
setblock 198 169 339 minecraft:light[level=12]
setblock 198 169 346 minecraft:light[level=12]
setblock 198 169 353 minecraft:light[level=12]
setblock 198 169 360 minecraft:light[level=12]
setblock 199 169 325 minecraft:light[level=15]
setblock 199 169 333 minecraft:light[level=15]
setblock 199 169 341 minecraft:light[level=15]
setblock 199 169 349 minecraft:light[level=15]
setblock 199 169 357 minecraft:light[level=15]
setblock 205 169 325 minecraft:light[level=12]
setblock 205 169 332 minecraft:light[level=12]
setblock 205 169 339 minecraft:light[level=12]
setblock 205 169 346 minecraft:light[level=12]
setblock 205 169 353 minecraft:light[level=12]
setblock 205 169 360 minecraft:light[level=12]
setblock 207 169 325 minecraft:light[level=15]
setblock 207 169 333 minecraft:light[level=15]
setblock 207 169 341 minecraft:light[level=15]
setblock 207 169 349 minecraft:light[level=15]
setblock 207 169 357 minecraft:light[level=15]
fill 209 169 354 209 169 358 minecraft:white_concrete
fill 210 169 354 211 169 354 minecraft:white_concrete
fill 210 169 355 210 169 356 minecraft:black_concrete
fill 210 169 357 211 169 358 minecraft:white_concrete
fill 211 169 355 211 169 356 minecraft:white_concrete
setblock 212 169 325 minecraft:light[level=12]
setblock 212 169 332 minecraft:light[level=12]
setblock 212 169 339 minecraft:light[level=12]
setblock 212 169 346 minecraft:light[level=12]
setblock 212 169 353 minecraft:light[level=12]
setblock 212 169 360 minecraft:light[level=12]
setblock 215 169 325 minecraft:light[level=15]
setblock 215 169 333 minecraft:light[level=15]
setblock 215 169 341 minecraft:light[level=15]
setblock 215 169 349 minecraft:light[level=15]
setblock 215 169 357 minecraft:light[level=15]
fill 215 169 364 215 185 364 minecraft:black_concrete
setblock 219 169 325 minecraft:light[level=12]
setblock 219 169 332 minecraft:light[level=12]
setblock 219 169 339 minecraft:light[level=12]
setblock 219 169 346 minecraft:light[level=12]
setblock 219 169 353 minecraft:light[level=12]
setblock 219 169 360 minecraft:light[level=12]
fill 220 169 364 220 183 364 minecraft:black_concrete
fill 222 169 340 222 178 340 minecraft:gray_concrete
setblock 223 169 322 minecraft:pearlescent_froglight
setblock 223 169 325 minecraft:light[level=15]
setblock 223 169 333 minecraft:light[level=15]
setblock 223 169 341 minecraft:light[level=15]
setblock 223 169 349 minecraft:light[level=15]
setblock 223 169 357 minecraft:light[level=15]
setblock 226 169 325 minecraft:light[level=12]
setblock 226 169 332 minecraft:light[level=12]
setblock 226 169 339 minecraft:light[level=12]
setblock 226 169 346 minecraft:light[level=12]
setblock 226 169 353 minecraft:light[level=12]
setblock 226 169 360 minecraft:light[level=12]
setblock 227 169 322 minecraft:sea_lantern
fill 230 169 343 230 276 343 minecraft:black_concrete
fill 188 170 339 188 215 339 minecraft:black_concrete
setblock 191 170 364 minecraft:sea_lantern
fill 194 170 364 194 187 364 minecraft:black_concrete
fill 222 170 339 223 178 339 minecraft:gray_concrete
fill 222 170 341 223 178 341 minecraft:gray_concrete
fill 223 170 322 223 182 322 minecraft:black_concrete
fill 227 170 322 227 246 322 minecraft:black_concrete
fill 228 170 364 229 170 364 minecraft:white_concrete
setblock 230 170 324 minecraft:sea_lantern
setblock 188 171 327 minecraft:ochre_froglight
setblock 188 171 337 minecraft:white_concrete
fill 191 171 364 191 199 364 minecraft:black_concrete
setblock 208 171 322 minecraft:ochre_froglight
setblock 208 171 364 minecraft:ochre_froglight
setblock 209 171 322 minecraft:white_concrete
fill 221 171 340 221 178 340 minecraft:gray_concrete
fill 224 171 339 224 178 341 minecraft:gray_concrete
fill 228 171 364 229 173 364 minecraft:black_concrete
fill 230 171 324 230 308 324 minecraft:black_concrete
setblock 230 171 339 minecraft:white_concrete
fill 188 172 327 188 202 327 minecraft:black_concrete
fill 188 172 337 188 190 337 minecraft:black_concrete
setblock 188 172 358 minecraft:ochre_froglight
setblock 196 172 322 minecraft:pearlescent_froglight
fill 208 172 322 209 174 322 minecraft:black_concrete
fill 208 172 364 208 308 364 minecraft:black_concrete
fill 217 172 335 218 173 335 minecraft:end_stone
fill 221 172 339 221 178 339 minecraft:gray_concrete
fill 221 172 341 221 178 341 minecraft:gray_concrete
fill 222 172 338 223 178 338 minecraft:gray_concrete
fill 222 172 342 223 178 342 minecraft:gray_concrete
fill 230 172 339 230 176 339 minecraft:black_concrete
fill 188 173 358 188 175 358 minecraft:black_concrete
setblock 194 173 344 minecraft:verdant_froglight
fill 196 173 322 196 235 322 minecraft:black_concrete
fill 201 173 358 202 174 358 minecraft:end_stone
fill 220 173 340 220 178 340 minecraft:gray_concrete
fill 221 173 338 221 178 338 minecraft:gray_concrete
fill 221 173 342 221 178 342 minecraft:gray_concrete
fill 224 173 338 224 178 338 minecraft:gray_concrete
fill 224 173 342 224 178 342 minecraft:gray_concrete
fill 225 173 339 225 178 341 minecraft:gray_concrete
setblock 230 173 328 minecraft:white_concrete
setblock 188 174 343 minecraft:pearlescent_froglight
setblock 188 174 361 minecraft:sea_lantern
setblock 189 174 364 minecraft:white_concrete
fill 211 174 322 211 175 322 minecraft:sea_lantern
setblock 217 174 364 minecraft:white_concrete
fill 220 174 339 220 178 339 minecraft:gray_concrete
fill 220 174 341 220 178 341 minecraft:gray_concrete
fill 222 174 337 223 178 337 minecraft:gray_concrete
fill 222 174 343 224 178 343 minecraft:gray_concrete
fill 225 174 338 225 178 338 minecraft:gray_concrete
fill 225 174 342 225 178 342 minecraft:gray_concrete
setblock 228 174 364 minecraft:sea_lantern
setblock 229 174 364 minecraft:pearlescent_froglight
fill 230 174 328 230 241 328 minecraft:black_concrete
fill 188 175 343 188 231 343 minecraft:black_concrete
setblock 188 175 350 minecraft:sea_lantern
fill 188 175 361 188 308 361 minecraft:black_concrete
fill 189 175 364 189 194 364 minecraft:black_concrete
setblock 190 175 364 minecraft:pearlescent_froglight
setblock 191 175 325 minecraft:light[level=12]
setblock 191 175 332 minecraft:light[level=12]
setblock 191 175 339 minecraft:light[level=12]
setblock 191 175 346 minecraft:light[level=12]
setblock 191 175 353 minecraft:light[level=12]
setblock 191 175 360 minecraft:light[level=12]
setblock 198 175 325 minecraft:light[level=12]
setblock 198 175 332 minecraft:light[level=12]
setblock 198 175 339 minecraft:light[level=12]
setblock 198 175 346 minecraft:light[level=12]
setblock 198 175 353 minecraft:light[level=12]
setblock 198 175 360 minecraft:light[level=12]
setblock 205 175 325 minecraft:light[level=12]
setblock 205 175 332 minecraft:light[level=12]
setblock 205 175 339 minecraft:light[level=12]
setblock 205 175 346 minecraft:light[level=12]
setblock 205 175 353 minecraft:light[level=12]
setblock 205 175 360 minecraft:light[level=12]
setblock 208 175 322 minecraft:white_concrete
fill 209 175 322 209 181 322 minecraft:black_concrete
setblock 212 175 325 minecraft:light[level=12]
setblock 212 175 332 minecraft:light[level=12]
setblock 212 175 339 minecraft:light[level=12]
setblock 212 175 346 minecraft:light[level=12]
setblock 212 175 353 minecraft:light[level=12]
setblock 212 175 360 minecraft:light[level=12]
fill 217 175 364 217 208 364 minecraft:black_concrete
setblock 219 175 325 minecraft:light[level=12]
setblock 219 175 332 minecraft:light[level=12]
fill 219 175 335 220 176 336 minecraft:end_stone
setblock 219 175 339 minecraft:light[level=12]
fill 219 175 340 219 178 340 minecraft:gray_concrete
setblock 219 175 346 minecraft:light[level=12]
setblock 219 175 353 minecraft:light[level=12]
setblock 219 175 360 minecraft:light[level=12]
fill 220 175 334 220 176 334 minecraft:end_stone
fill 220 175 338 220 178 338 minecraft:gray_concrete
fill 220 175 342 220 178 342 minecraft:gray_concrete
fill 221 175 337 221 178 337 minecraft:gray_concrete
fill 221 175 343 221 178 343 minecraft:gray_concrete
fill 224 175 337 224 178 337 minecraft:gray_concrete
setblock 226 175 325 minecraft:light[level=12]
setblock 226 175 332 minecraft:light[level=12]
fill 226 175 339 226 178 341 minecraft:gray_concrete
setblock 226 175 346 minecraft:light[level=12]
setblock 226 175 353 minecraft:light[level=12]
setblock 226 175 360 minecraft:light[level=12]
fill 228 175 364 229 210 364 minecraft:black_concrete
setblock 230 175 336 minecraft:white_concrete
fill 188 176 350 188 232 350 minecraft:black_concrete
setblock 188 176 358 minecraft:ochre_froglight
setblock 188 176 360 minecraft:white_concrete
fill 190 176 364 190 243 364 minecraft:black_concrete
setblock 208 176 322 minecraft:black_concrete
fill 211 176 322 211 227 322 minecraft:black_concrete
setblock 213 176 322 minecraft:ochre_froglight
fill 219 176 339 219 178 339 minecraft:gray_concrete
fill 219 176 341 219 178 342 minecraft:gray_concrete
fill 220 176 337 220 178 337 minecraft:gray_concrete
fill 220 176 343 220 178 343 minecraft:gray_concrete
fill 222 176 336 223 178 336 minecraft:gray_concrete
fill 222 176 344 224 178 344 minecraft:gray_concrete
fill 225 176 337 225 178 337 minecraft:gray_concrete
fill 225 176 343 225 178 343 minecraft:gray_concrete
fill 226 176 338 226 178 338 minecraft:gray_concrete
fill 226 176 342 226 178 342 minecraft:gray_concrete
fill 230 176 336 230 215 336 minecraft:black_concrete
setblock 230 176 356 minecraft:ochre_froglight
fill 188 177 358 188 212 358 minecraft:black_concrete
fill 188 177 360 188 242 360 minecraft:black_concrete
setblock 191 177 325 minecraft:light[level=15]
setblock 191 177 333 minecraft:light[level=15]
setblock 191 177 341 minecraft:light[level=15]
setblock 191 177 349 minecraft:light[level=15]
setblock 191 177 357 minecraft:light[level=15]
setblock 199 177 325 minecraft:light[level=15]
setblock 199 177 333 minecraft:light[level=15]
setblock 199 177 341 minecraft:light[level=15]
setblock 199 177 349 minecraft:light[level=15]
setblock 199 177 357 minecraft:light[level=15]
setblock 204 177 322 minecraft:sea_lantern
setblock 207 177 325 minecraft:light[level=15]
setblock 207 177 333 minecraft:light[level=15]
setblock 207 177 341 minecraft:light[level=15]
setblock 207 177 349 minecraft:light[level=15]
setblock 207 177 357 minecraft:light[level=15]
setblock 208 177 322 minecraft:pearlescent_froglight
fill 213 177 322 213 202 322 minecraft:black_concrete
setblock 214 177 364 minecraft:sea_lantern
setblock 215 177 325 minecraft:light[level=15]
setblock 215 177 333 minecraft:light[level=15]
setblock 215 177 341 minecraft:light[level=15]
setblock 215 177 349 minecraft:light[level=15]
setblock 215 177 357 minecraft:light[level=15]
fill 219 177 338 219 178 338 minecraft:gray_concrete
fill 221 177 336 221 178 336 minecraft:gray_concrete
fill 221 177 344 221 178 344 minecraft:gray_concrete
setblock 223 177 325 minecraft:light[level=15]
setblock 223 177 333 minecraft:light[level=15]
setblock 223 177 349 minecraft:light[level=15]
setblock 223 177 357 minecraft:light[level=15]
fill 224 177 336 225 178 336 minecraft:gray_concrete
fill 225 177 344 225 178 344 minecraft:gray_concrete
fill 226 177 337 226 178 337 minecraft:gray_concrete
fill 226 177 343 226 178 343 minecraft:gray_concrete
fill 227 177 339 227 178 341 minecraft:gray_concrete
setblock 230 177 339 minecraft:pearlescent_froglight
fill 230 177 356 230 211 356 minecraft:black_concrete
fill 204 178 322 204 188 322 minecraft:black_concrete
fill 208 178 322 208 233 322 minecraft:black_concrete
setblock 209 178 364 minecraft:pearlescent_froglight
setblock 212 178 322 minecraft:white_concrete
fill 214 178 364 214 237 364 minecraft:black_concrete
setblock 216 178 364 minecraft:white_concrete
fill 218 178 338 218 178 342 minecraft:gray_concrete
setblock 219 178 337 minecraft:gray_concrete
setblock 219 178 343 minecraft:gray_concrete
setblock 220 178 336 minecraft:gray_concrete
setblock 220 178 344 minecraft:gray_concrete
fill 222 178 335 224 178 335 minecraft:gray_concrete
fill 222 178 345 224 178 345 minecraft:gray_concrete
setblock 226 178 336 minecraft:gray_concrete
setblock 226 178 344 minecraft:gray_concrete
setblock 227 178 338 minecraft:gray_concrete
setblock 227 178 342 minecraft:gray_concrete
fill 230 178 339 230 200 339 minecraft:black_concrete
setblock 188 179 331 minecraft:pearlescent_froglight
setblock 188 179 342 minecraft:sea_lantern
setblock 188 179 357 minecraft:white_concrete
fill 209 179 364 209 202 364 minecraft:black_concrete
fill 212 179 322 212 198 322 minecraft:black_concrete
fill 216 179 364 216 299 364 minecraft:black_concrete
fill 222 179 339 223 179 341 minecraft:lime_stained_glass
setblock 224 179 340 minecraft:lime_stained_glass
fill 188 180 331 188 194 331 minecraft:black_concrete
fill 188 180 342 188 212 342 minecraft:black_concrete
fill 188 180 357 188 254 357 minecraft:black_concrete
setblock 199 180 322 minecraft:sea_lantern
setblock 203 180 322 minecraft:ochre_froglight
setblock 210 180 322 minecraft:sea_lantern
setblock 218 180 322 minecraft:sea_lantern
fill 222 180 340 223 181 340 minecraft:lime_stained_glass
setblock 223 180 341 minecraft:lime_stained_glass
setblock 191 181 325 minecraft:light[level=12]
setblock 191 181 332 minecraft:light[level=12]
setblock 191 181 339 minecraft:light[level=12]
setblock 191 181 346 minecraft:light[level=12]
setblock 191 181 353 minecraft:light[level=12]
setblock 191 181 360 minecraft:light[level=12]
setblock 198 181 325 minecraft:light[level=12]
setblock 198 181 332 minecraft:light[level=12]
setblock 198 181 339 minecraft:light[level=12]
setblock 198 181 346 minecraft:light[level=12]
setblock 198 181 353 minecraft:light[level=12]
setblock 198 181 360 minecraft:light[level=12]
fill 199 181 322 199 186 322 minecraft:black_concrete
fill 203 181 322 203 248 322 minecraft:black_concrete
setblock 205 181 325 minecraft:light[level=12]
setblock 205 181 332 minecraft:light[level=12]
setblock 205 181 339 minecraft:light[level=12]
setblock 205 181 346 minecraft:light[level=12]
setblock 205 181 353 minecraft:light[level=12]
setblock 205 181 360 minecraft:light[level=12]
fill 210 181 322 210 243 322 minecraft:black_concrete
setblock 212 181 325 minecraft:light[level=12]
setblock 212 181 332 minecraft:light[level=12]
setblock 212 181 339 minecraft:light[level=12]
setblock 212 181 346 minecraft:light[level=12]
setblock 212 181 353 minecraft:light[level=12]
setblock 212 181 360 minecraft:light[level=12]
fill 218 181 322 218 193 322 minecraft:black_concrete
setblock 219 181 325 minecraft:light[level=12]
setblock 219 181 332 minecraft:light[level=12]
setblock 219 181 339 minecraft:light[level=12]
setblock 219 181 346 minecraft:light[level=12]
setblock 219 181 353 minecraft:light[level=12]
setblock 219 181 360 minecraft:light[level=12]
setblock 226 181 325 minecraft:light[level=12]
setblock 226 181 332 minecraft:light[level=12]
setblock 226 181 339 minecraft:light[level=12]
setblock 226 181 346 minecraft:light[level=12]
setblock 226 181 353 minecraft:light[level=12]
setblock 226 181 360 minecraft:light[level=12]
setblock 230 181 337 minecraft:ochre_froglight
setblock 230 181 340 minecraft:white_concrete
setblock 230 181 348 minecraft:white_concrete
setblock 188 182 351 minecraft:sea_lantern
fill 204 182 358 204 183 359 minecraft:end_stone
fill 205 182 359 205 183 359 minecraft:end_stone
setblock 209 182 322 minecraft:sea_lantern
fill 223 182 340 223 183 340 minecraft:lime_stained_glass
fill 230 182 337 230 200 337 minecraft:black_concrete
fill 230 182 340 230 236 340 minecraft:black_concrete
fill 230 182 348 230 279 348 minecraft:black_concrete
setblock 230 182 361 minecraft:white_concrete
fill 230 182 362 230 188 362 minecraft:black_concrete
setblock 188 183 338 minecraft:sea_lantern
fill 188 183 351 188 249 351 minecraft:black_concrete
fill 209 183 322 209 207 322 minecraft:black_concrete
setblock 212 183 364 minecraft:sea_lantern
setblock 222 183 322 minecraft:sea_lantern
setblock 223 183 322 minecraft:pearlescent_froglight
setblock 230 183 332 minecraft:white_concrete
fill 230 183 361 230 201 361 minecraft:black_concrete
fill 188 184 338 188 265 338 minecraft:black_concrete
setblock 198 184 322 minecraft:pearlescent_froglight
fill 201 184 356 202 185 357 minecraft:gray_concrete
setblock 203 184 364 minecraft:pearlescent_froglight
setblock 206 184 364 minecraft:sea_lantern
fill 212 184 364 212 214 364 minecraft:black_concrete
setblock 220 184 364 minecraft:ochre_froglight
fill 222 184 322 223 213 322 minecraft:black_concrete
setblock 230 184 327 minecraft:white_concrete
fill 230 184 332 230 308 332 minecraft:black_concrete
setblock 230 184 352 minecraft:ochre_froglight
setblock 191 185 325 minecraft:light[level=15]
setblock 191 185 333 minecraft:light[level=15]
setblock 191 185 341 minecraft:light[level=15]
setblock 191 185 349 minecraft:light[level=15]
setblock 191 185 357 minecraft:light[level=15]
fill 198 185 322 198 221 322 minecraft:black_concrete
setblock 199 185 325 minecraft:light[level=15]
setblock 199 185 333 minecraft:light[level=15]
setblock 199 185 341 minecraft:light[level=15]
setblock 199 185 349 minecraft:light[level=15]
setblock 199 185 357 minecraft:light[level=15]
fill 203 185 364 203 261 364 minecraft:black_concrete
fill 206 185 364 206 192 364 minecraft:black_concrete
setblock 207 185 325 minecraft:light[level=15]
setblock 207 185 333 minecraft:light[level=15]
setblock 207 185 341 minecraft:light[level=15]
setblock 207 185 349 minecraft:light[level=15]
setblock 207 185 357 minecraft:light[level=15]
setblock 215 185 325 minecraft:light[level=15]
setblock 215 185 333 minecraft:light[level=15]
setblock 215 185 341 minecraft:light[level=15]
setblock 215 185 349 minecraft:light[level=15]
setblock 215 185 357 minecraft:light[level=15]
fill 220 185 364 220 222 364 minecraft:black_concrete
setblock 223 185 325 minecraft:light[level=15]
setblock 223 185 333 minecraft:light[level=15]
setblock 223 185 341 minecraft:light[level=15]
setblock 223 185 349 minecraft:light[level=15]
setblock 223 185 357 minecraft:light[level=15]
setblock 226 185 364 minecraft:ochre_froglight
fill 230 185 327 230 277 327 minecraft:black_concrete
setblock 230 185 352 minecraft:black_concrete
setblock 195 186 322 minecraft:white_concrete
fill 204 186 350 205 187 350 minecraft:end_stone
fill 214 186 322 214 187 322 minecraft:pearlescent_froglight
setblock 215 186 364 minecraft:white_concrete
fill 222 186 341 223 187 342 minecraft:gray_concrete
fill 223 186 338 223 187 339 minecraft:end_stone
fill 226 186 364 226 198 364 minecraft:black_concrete
setblock 230 186 352 minecraft:ochre_froglight
setblock 191 187 325 minecraft:light[level=12]
setblock 191 187 332 minecraft:light[level=12]
setblock 191 187 339 minecraft:light[level=12]
fill 191 187 341 192 188 345 minecraft:light_gray_concrete
setblock 191 187 346 minecraft:light[level=12]
setblock 191 187 353 minecraft:light[level=12]
setblock 191 187 360 minecraft:light[level=12]
fill 192 187 337 192 188 340 minecraft:light_gray_concrete
fill 192 187 346 192 188 349 minecraft:light_gray_concrete
fill 193 187 335 193 188 337 minecraft:light_gray_concrete
fill 193 187 349 193 188 351 minecraft:light_gray_concrete
fill 194 187 333 194 188 335 minecraft:light_gray_concrete
fill 194 187 351 194 188 353 minecraft:light_gray_concrete
setblock 195 187 322 minecraft:black_concrete
fill 195 187 332 195 188 333 minecraft:light_gray_concrete
fill 195 187 353 195 188 354 minecraft:light_gray_concrete
fill 196 187 331 196 188 332 minecraft:light_gray_concrete
fill 196 187 354 196 188 355 minecraft:light_gray_concrete
fill 197 187 330 197 188 331 minecraft:light_gray_concrete
fill 197 187 355 197 188 356 minecraft:light_gray_concrete
setblock 198 187 325 minecraft:light[level=12]
fill 198 187 329 198 188 330 minecraft:light_gray_concrete
setblock 198 187 332 minecraft:light[level=12]
setblock 198 187 339 minecraft:light[level=12]
setblock 198 187 346 minecraft:light[level=12]
setblock 198 187 353 minecraft:light[level=12]
fill 198 187 356 198 188 357 minecraft:light_gray_concrete
setblock 198 187 360 minecraft:light[level=12]
setblock 199 187 322 minecraft:sea_lantern
fill 199 187 328 199 188 329 minecraft:light_gray_concrete
fill 199 187 357 199 188 358 minecraft:light_gray_concrete
fill 200 187 328 201 188 328 minecraft:light_gray_concrete
fill 200 187 358 201 188 358 minecraft:light_gray_concrete
fill 201 187 327 203 188 327 minecraft:light_gray_concrete
fill 201 187 359 203 188 359 minecraft:light_gray_concrete
fill 203 187 326 215 188 326 minecraft:light_gray_concrete
fill 203 187 360 215 188 360 minecraft:light_gray_concrete
setblock 205 187 325 minecraft:light[level=12]
setblock 205 187 332 minecraft:light[level=12]
setblock 205 187 339 minecraft:light[level=12]
setblock 205 187 346 minecraft:light[level=12]
setblock 205 187 353 minecraft:light[level=12]
fill 207 187 325 211 188 325 minecraft:light_gray_concrete
fill 207 187 361 211 188 361 minecraft:light_gray_concrete
setblock 212 187 325 minecraft:light[level=12]
setblock 212 187 332 minecraft:light[level=12]
setblock 212 187 339 minecraft:light[level=12]
setblock 212 187 346 minecraft:light[level=12]
setblock 212 187 353 minecraft:light[level=12]
fill 215 187 327 217 188 327 minecraft:light_gray_concrete
fill 215 187 359 217 188 359 minecraft:light_gray_concrete
fill 215 187 364 215 231 364 minecraft:black_concrete
fill 217 187 328 219 188 328 minecraft:light_gray_concrete
fill 217 187 358 219 188 358 minecraft:light_gray_concrete
setblock 219 187 325 minecraft:light[level=12]
fill 219 187 329 220 188 329 minecraft:light_gray_concrete
setblock 219 187 332 minecraft:light[level=12]
setblock 219 187 339 minecraft:light[level=12]
setblock 219 187 346 minecraft:light[level=12]
setblock 219 187 353 minecraft:light[level=12]
fill 219 187 357 220 188 357 minecraft:light_gray_concrete
setblock 219 187 360 minecraft:light[level=12]
fill 220 187 330 221 188 330 minecraft:light_gray_concrete
fill 220 187 356 221 188 356 minecraft:light_gray_concrete
fill 221 187 331 222 188 331 minecraft:light_gray_concrete
fill 221 187 355 222 188 355 minecraft:light_gray_concrete
fill 222 187 332 223 188 332 minecraft:light_gray_concrete
fill 222 187 354 223 188 354 minecraft:light_gray_concrete
fill 223 187 333 224 188 333 minecraft:light_gray_concrete
fill 223 187 353 224 188 353 minecraft:light_gray_concrete
fill 224 187 334 224 188 335 minecraft:light_gray_concrete
fill 224 187 351 224 188 352 minecraft:light_gray_concrete
fill 225 187 335 225 188 337 minecraft:light_gray_concrete
fill 225 187 349 225 188 351 minecraft:light_gray_concrete
setblock 226 187 325 minecraft:light[level=12]
setblock 226 187 332 minecraft:light[level=12]
fill 226 187 337 226 188 349 minecraft:light_gray_concrete
setblock 226 187 353 minecraft:light[level=12]
setblock 226 187 360 minecraft:light[level=12]
fill 227 187 341 227 188 345 minecraft:light_gray_concrete
fill 230 187 352 230 189 352 minecraft:black_concrete
setblock 194 188 364 minecraft:white_concrete
setblock 195 188 322 minecraft:pearlescent_froglight
fill 199 188 322 199 208 322 minecraft:black_concrete
fill 214 188 322 214 222 322 minecraft:black_concrete
setblock 229 188 322 minecraft:ochre_froglight
setblock 230 188 338 minecraft:sea_lantern
setblock 230 188 349 minecraft:sea_lantern
fill 191 189 339 191 189 347 minecraft:verdant_froglight
fill 192 189 336 192 189 338 minecraft:verdant_froglight
fill 192 189 348 192 189 350 minecraft:verdant_froglight
fill 193 189 334 193 189 335 minecraft:verdant_froglight
fill 193 189 351 193 189 352 minecraft:verdant_froglight
setblock 194 189 333 minecraft:verdant_froglight
setblock 194 189 353 minecraft:verdant_froglight
fill 194 189 364 194 196 364 minecraft:black_concrete
fill 195 189 322 195 223 322 minecraft:black_concrete
fill 195 189 331 195 189 332 minecraft:verdant_froglight
fill 195 189 354 195 189 355 minecraft:verdant_froglight
setblock 196 189 331 minecraft:verdant_froglight
fill 196 189 355 196 189 356 minecraft:verdant_froglight
fill 197 189 356 197 189 357 minecraft:verdant_froglight
setblock 198 189 357 minecraft:verdant_froglight
setblock 199 189 358 minecraft:verdant_froglight
fill 200 189 359 201 189 359 minecraft:verdant_froglight
fill 202 189 360 204 189 360 minecraft:verdant_froglight
setblock 204 189 322 minecraft:ochre_froglight
fill 205 189 361 213 189 361 minecraft:verdant_froglight
setblock 211 189 364 minecraft:white_concrete
fill 212 189 325 213 189 325 minecraft:verdant_froglight
fill 214 189 326 216 189 326 minecraft:verdant_froglight
fill 214 189 360 216 189 360 minecraft:verdant_froglight
fill 217 189 327 218 189 327 minecraft:verdant_froglight
fill 217 189 359 218 189 359 minecraft:verdant_froglight
setblock 219 189 328 minecraft:verdant_froglight
setblock 219 189 358 minecraft:verdant_froglight
fill 220 189 329 221 189 329 minecraft:verdant_froglight
fill 220 189 357 221 189 357 minecraft:verdant_froglight
fill 221 189 330 222 189 330 minecraft:verdant_froglight
fill 221 189 356 222 189 356 minecraft:verdant_froglight
fill 222 189 331 223 189 331 minecraft:verdant_froglight
fill 222 189 355 223 189 355 minecraft:verdant_froglight
setblock 223 189 332 minecraft:verdant_froglight
setblock 223 189 354 minecraft:verdant_froglight
setblock 224 189 333 minecraft:verdant_froglight
setblock 224 189 353 minecraft:verdant_froglight
fill 225 189 334 225 189 335 minecraft:verdant_froglight
fill 225 189 351 225 189 352 minecraft:verdant_froglight
fill 226 189 336 226 189 338 minecraft:verdant_froglight
fill 226 189 348 226 189 350 minecraft:verdant_froglight
fill 227 189 339 227 189 347 minecraft:verdant_froglight
setblock 229 189 322 minecraft:black_concrete
fill 230 189 338 230 215 338 minecraft:black_concrete
fill 230 189 349 230 198 349 minecraft:black_concrete
setblock 230 189 362 minecraft:ochre_froglight
setblock 188 190 346 minecraft:sea_lantern
setblock 188 190 362 minecraft:white_concrete
fill 204 190 322 204 308 322 minecraft:black_concrete
fill 211 190 364 211 215 364 minecraft:black_concrete
setblock 229 190 322 minecraft:ochre_froglight
fill 230 190 351 230 190 352 minecraft:ochre_froglight
setblock 230 190 353 minecraft:sea_lantern
fill 230 190 362 230 194 362 minecraft:black_concrete
setblock 230 190 363 minecraft:pearlescent_froglight
setblock 188 191 337 minecraft:sea_lantern
setblock 188 191 345 minecraft:ochre_froglight
fill 188 191 346 188 195 346 minecraft:black_concrete
fill 188 191 362 188 208 362 minecraft:black_concrete
setblock 226 191 322 minecraft:ochre_froglight
fill 229 191 322 229 226 322 minecraft:black_concrete
setblock 230 191 342 minecraft:ochre_froglight
fill 230 191 351 230 231 353 minecraft:black_concrete
fill 230 191 363 230 242 363 minecraft:black_concrete
fill 188 192 337 188 214 337 minecraft:black_concrete
fill 188 192 345 188 214 345 minecraft:black_concrete
fill 222 192 354 222 193 354 minecraft:gray_concrete
fill 226 192 322 226 206 322 minecraft:black_concrete
fill 230 192 342 230 282 342 minecraft:black_concrete
setblock 191 193 325 minecraft:light[level=15]
setblock 191 193 332 minecraft:light[level=12]
setblock 191 193 333 minecraft:light[level=15]
setblock 191 193 339 minecraft:light[level=12]
setblock 191 193 341 minecraft:light[level=15]
setblock 191 193 346 minecraft:light[level=12]
setblock 191 193 349 minecraft:light[level=15]
setblock 191 193 353 minecraft:light[level=12]
setblock 191 193 357 minecraft:light[level=15]
setblock 191 193 360 minecraft:light[level=12]
setblock 198 193 325 minecraft:light[level=12]
setblock 198 193 332 minecraft:light[level=12]
setblock 198 193 339 minecraft:light[level=12]
setblock 198 193 346 minecraft:light[level=12]
setblock 198 193 353 minecraft:light[level=12]
setblock 198 193 360 minecraft:light[level=12]
setblock 199 193 325 minecraft:light[level=15]
setblock 199 193 333 minecraft:light[level=15]
setblock 199 193 341 minecraft:light[level=15]
setblock 199 193 349 minecraft:light[level=15]
setblock 199 193 357 minecraft:light[level=15]
setblock 205 193 325 minecraft:light[level=12]
setblock 205 193 332 minecraft:light[level=12]
setblock 205 193 339 minecraft:light[level=12]
setblock 205 193 346 minecraft:light[level=12]
setblock 205 193 353 minecraft:light[level=12]
setblock 205 193 360 minecraft:light[level=12]
setblock 206 193 364 minecraft:ochre_froglight
setblock 207 193 325 minecraft:light[level=15]
setblock 207 193 333 minecraft:light[level=15]
setblock 207 193 341 minecraft:light[level=15]
setblock 207 193 349 minecraft:light[level=15]
setblock 207 193 357 minecraft:light[level=15]
setblock 212 193 325 minecraft:light[level=12]
setblock 212 193 332 minecraft:light[level=12]
setblock 212 193 339 minecraft:light[level=12]
setblock 212 193 346 minecraft:light[level=12]
setblock 212 193 353 minecraft:light[level=12]
setblock 212 193 360 minecraft:light[level=12]
setblock 215 193 325 minecraft:light[level=15]
setblock 215 193 333 minecraft:light[level=15]
setblock 215 193 341 minecraft:light[level=15]
setblock 215 193 349 minecraft:light[level=15]
setblock 215 193 357 minecraft:light[level=15]
setblock 219 193 325 minecraft:light[level=12]
setblock 219 193 332 minecraft:light[level=12]
setblock 219 193 339 minecraft:light[level=12]
setblock 219 193 346 minecraft:light[level=12]
setblock 219 193 353 minecraft:light[level=12]
setblock 219 193 360 minecraft:light[level=12]
setblock 223 193 325 minecraft:light[level=15]
setblock 223 193 333 minecraft:light[level=15]
setblock 223 193 341 minecraft:light[level=15]
setblock 223 193 349 minecraft:light[level=15]
setblock 223 193 357 minecraft:light[level=15]
setblock 226 193 325 minecraft:light[level=12]
setblock 226 193 332 minecraft:light[level=12]
setblock 226 193 339 minecraft:light[level=12]
setblock 226 193 346 minecraft:light[level=12]
setblock 226 193 353 minecraft:light[level=12]
setblock 226 193 360 minecraft:light[level=12]
setblock 205 194 322 minecraft:white_concrete
fill 206 194 364 206 257 364 minecraft:black_concrete
setblock 210 194 364 minecraft:white_concrete
setblock 215 194 322 minecraft:pearlescent_froglight
setblock 218 194 322 minecraft:sea_lantern
setblock 188 195 331 minecraft:white_concrete
setblock 189 195 364 minecraft:white_concrete
fill 205 195 322 205 308 322 minecraft:black_concrete
fill 210 195 364 210 308 364 minecraft:black_concrete
fill 215 195 322 215 238 322 minecraft:black_concrete
fill 218 195 322 218 225 322 minecraft:black_concrete
fill 223 195 351 223 196 351 minecraft:end_stone
setblock 230 195 362 minecraft:white_concrete
fill 188 196 331 188 204 331 minecraft:black_concrete
setblock 188 196 335 minecraft:ochre_froglight
setblock 188 196 346 minecraft:sea_lantern
setblock 188 196 353 minecraft:ochre_froglight
fill 189 196 364 189 210 364 minecraft:black_concrete
setblock 219 196 364 minecraft:ochre_froglight
setblock 230 196 344 minecraft:sea_lantern
fill 230 196 362 230 249 362 minecraft:black_concrete
setblock 188 197 335 minecraft:white_concrete
fill 188 197 346 188 209 346 minecraft:black_concrete
fill 188 197 353 188 209 353 minecraft:black_concrete
setblock 188 197 359 minecraft:sea_lantern
setblock 192 197 322 minecraft:ochre_froglight
setblock 194 197 364 minecraft:pearlescent_froglight
fill 200 197 345 201 198 346 minecraft:end_stone
setblock 205 197 364 minecraft:sea_lantern
fill 219 197 364 219 200 364 minecraft:black_concrete
fill 230 197 344 230 222 344 minecraft:black_concrete
fill 188 198 335 188 210 335 minecraft:black_concrete
fill 188 198 359 188 199 359 minecraft:black_concrete
fill 192 198 322 192 267 322 minecraft:black_concrete
fill 194 198 364 194 238 364 minecraft:black_concrete
fill 205 198 364 205 230 364 minecraft:black_concrete
setblock 188 199 323 minecraft:ochre_froglight
setblock 188 199 347 minecraft:ochre_froglight
setblock 191 199 325 minecraft:light[level=12]
setblock 191 199 332 minecraft:light[level=12]
setblock 191 199 339 minecraft:light[level=12]
setblock 191 199 346 minecraft:light[level=12]
setblock 191 199 353 minecraft:light[level=12]
setblock 191 199 360 minecraft:light[level=12]
setblock 198 199 325 minecraft:light[level=12]
setblock 198 199 332 minecraft:light[level=12]
setblock 198 199 339 minecraft:light[level=12]
setblock 198 199 346 minecraft:light[level=12]
setblock 198 199 353 minecraft:light[level=12]
setblock 198 199 360 minecraft:light[level=12]
setblock 205 199 325 minecraft:light[level=12]
setblock 205 199 332 minecraft:light[level=12]
setblock 205 199 339 minecraft:light[level=12]
setblock 205 199 346 minecraft:light[level=12]
setblock 205 199 353 minecraft:light[level=12]
setblock 205 199 360 minecraft:light[level=12]
setblock 212 199 322 minecraft:white_concrete
setblock 212 199 325 minecraft:light[level=12]
setblock 212 199 332 minecraft:light[level=12]
setblock 212 199 339 minecraft:light[level=12]
setblock 212 199 346 minecraft:light[level=12]
setblock 212 199 353 minecraft:light[level=12]
setblock 212 199 360 minecraft:light[level=12]
setblock 219 199 325 minecraft:light[level=12]
setblock 219 199 332 minecraft:light[level=12]
setblock 219 199 339 minecraft:light[level=12]
setblock 219 199 346 minecraft:light[level=12]
setblock 219 199 353 minecraft:light[level=12]
setblock 219 199 360 minecraft:light[level=12]
setblock 222 199 364 minecraft:sea_lantern
setblock 226 199 325 minecraft:light[level=12]
setblock 226 199 332 minecraft:light[level=12]
setblock 226 199 339 minecraft:light[level=12]
setblock 226 199 346 minecraft:light[level=12]
setblock 226 199 353 minecraft:light[level=12]
setblock 226 199 360 minecraft:light[level=12]
setblock 226 199 364 minecraft:white_concrete
setblock 230 199 341 minecraft:sea_lantern
setblock 230 199 349 minecraft:pearlescent_froglight
fill 188 200 323 188 224 323 minecraft:black_concrete
fill 188 200 347 188 204 347 minecraft:black_concrete
setblock 188 200 359 minecraft:ochre_froglight
setblock 191 200 364 minecraft:white_concrete
fill 212 200 322 212 267 322 minecraft:black_concrete
fill 222 200 364 222 204 364 minecraft:black_concrete
fill 226 200 364 226 287 364 minecraft:black_concrete
fill 230 200 341 230 308 341 minecraft:black_concrete
fill 230 200 349 230 260 349 minecraft:black_concrete
setblock 188 201 332 minecraft:white_concrete
fill 188 201 359 188 241 359 minecraft:black_concrete
setblock 191 201 325 minecraft:light[level=15]
setblock 191 201 333 minecraft:light[level=15]
setblock 191 201 341 minecraft:light[level=15]
setblock 191 201 349 minecraft:light[level=15]
setblock 191 201 357 minecraft:light[level=15]
fill 191 201 364 191 221 364 minecraft:black_concrete
setblock 199 201 325 minecraft:light[level=15]
setblock 199 201 333 minecraft:light[level=15]
setblock 199 201 341 minecraft:light[level=15]
setblock 199 201 349 minecraft:light[level=15]
setblock 199 201 357 minecraft:light[level=15]
fill 202 201 330 204 202 330 minecraft:gray_concrete
fill 203 201 329 204 202 329 minecraft:gray_concrete
setblock 207 201 325 minecraft:light[level=15]
setblock 207 201 333 minecraft:light[level=15]
setblock 207 201 341 minecraft:light[level=15]
setblock 207 201 349 minecraft:light[level=15]
setblock 207 201 357 minecraft:light[level=15]
setblock 215 201 325 minecraft:light[level=15]
setblock 215 201 333 minecraft:light[level=15]
setblock 215 201 341 minecraft:light[level=15]
setblock 215 201 349 minecraft:light[level=15]
setblock 215 201 357 minecraft:light[level=15]
setblock 219 201 364 minecraft:sea_lantern
setblock 223 201 325 minecraft:light[level=15]
setblock 223 201 333 minecraft:light[level=15]
setblock 223 201 341 minecraft:light[level=15]
setblock 223 201 349 minecraft:light[level=15]
setblock 223 201 357 minecraft:light[level=15]
setblock 230 201 334 minecraft:sea_lantern
setblock 230 201 337 minecraft:pearlescent_froglight
setblock 230 201 339 minecraft:white_concrete
fill 188 202 332 188 227 332 minecraft:black_concrete
setblock 188 202 363 minecraft:white_concrete
fill 219 202 364 219 237 364 minecraft:black_concrete
fill 230 202 334 230 215 334 minecraft:black_concrete
fill 230 202 337 230 220 337 minecraft:black_concrete
fill 230 202 339 230 254 339 minecraft:black_concrete
setblock 230 202 361 minecraft:pearlescent_froglight
setblock 188 203 327 minecraft:white_concrete
setblock 188 203 349 minecraft:white_concrete
setblock 188 203 354 minecraft:white_concrete
fill 188 203 363 188 303 363 minecraft:black_concrete
setblock 209 203 364 minecraft:sea_lantern
setblock 213 203 322 minecraft:ochre_froglight
fill 230 203 361 230 233 361 minecraft:black_concrete
fill 188 204 327 188 214 327 minecraft:black_concrete
fill 188 204 349 188 212 349 minecraft:black_concrete
fill 188 204 354 188 247 354 minecraft:black_concrete
fill 196 204 340 196 205 340 minecraft:lime_stained_glass
setblock 199 204 364 minecraft:pearlescent_froglight
fill 209 204 364 209 229 364 minecraft:black_concrete
fill 213 204 322 213 248 322 minecraft:black_concrete
setblock 230 204 330 minecraft:sea_lantern
setblock 188 205 331 minecraft:white_concrete
setblock 188 205 347 minecraft:white_concrete
setblock 191 205 325 minecraft:light[level=12]
setblock 191 205 332 minecraft:light[level=12]
setblock 191 205 339 minecraft:light[level=12]
setblock 191 205 346 minecraft:light[level=12]
setblock 191 205 353 minecraft:light[level=12]
setblock 191 205 360 minecraft:light[level=12]
setblock 198 205 325 minecraft:light[level=12]
setblock 198 205 332 minecraft:light[level=12]
setblock 198 205 339 minecraft:light[level=12]
setblock 198 205 346 minecraft:light[level=12]
setblock 198 205 353 minecraft:light[level=12]
setblock 198 205 360 minecraft:light[level=12]
fill 199 205 364 199 253 364 minecraft:black_concrete
setblock 205 205 325 minecraft:light[level=12]
setblock 205 205 332 minecraft:light[level=12]
setblock 205 205 339 minecraft:light[level=12]
setblock 205 205 346 minecraft:light[level=12]
setblock 205 205 353 minecraft:light[level=12]
setblock 205 205 360 minecraft:light[level=12]
setblock 207 205 364 minecraft:pearlescent_froglight
setblock 212 205 325 minecraft:light[level=12]
setblock 212 205 332 minecraft:light[level=12]
setblock 212 205 339 minecraft:light[level=12]
setblock 212 205 346 minecraft:light[level=12]
setblock 212 205 353 minecraft:light[level=12]
setblock 212 205 360 minecraft:light[level=12]
setblock 219 205 325 minecraft:light[level=12]
setblock 219 205 332 minecraft:light[level=12]
setblock 219 205 339 minecraft:light[level=12]
setblock 219 205 346 minecraft:light[level=12]
setblock 219 205 353 minecraft:light[level=12]
setblock 219 205 360 minecraft:light[level=12]
setblock 222 205 364 minecraft:white_concrete
setblock 226 205 325 minecraft:light[level=12]
setblock 226 205 332 minecraft:light[level=12]
setblock 226 205 339 minecraft:light[level=12]
setblock 226 205 346 minecraft:light[level=12]
setblock 226 205 353 minecraft:light[level=12]
setblock 226 205 360 minecraft:light[level=12]
setblock 230 205 326 minecraft:white_concrete
fill 230 205 330 230 222 330 minecraft:black_concrete
setblock 230 205 335 minecraft:ochre_froglight
fill 188 206 331 188 212 331 minecraft:black_concrete
fill 188 206 347 188 244 347 minecraft:black_concrete
fill 196 206 340 196 214 340 minecraft:gray_concrete
setblock 197 206 364 minecraft:pearlescent_froglight
fill 207 206 364 207 308 364 minecraft:black_concrete
fill 217 206 330 217 207 330 minecraft:end_stone
fill 222 206 364 222 208 364 minecraft:black_concrete
setblock 225 206 364 minecraft:sea_lantern
fill 230 206 326 230 240 326 minecraft:black_concrete
fill 230 206 335 230 268 335 minecraft:black_concrete
fill 194 207 323 196 208 323 minecraft:light_gray_concrete
fill 194 207 362 196 208 363 minecraft:light_gray_concrete
setblock 197 207 364 minecraft:black_concrete
fill 225 207 364 225 276 364 minecraft:black_concrete
setblock 226 207 322 minecraft:sea_lantern
fill 194 208 324 196 209 324 minecraft:light_gray_concrete
fill 194 208 361 196 209 361 minecraft:light_gray_concrete
fill 195 208 325 195 210 325 minecraft:light_gray_concrete
fill 195 208 340 195 214 340 minecraft:gray_concrete
fill 195 208 360 195 210 360 minecraft:light_gray_concrete
setblock 195 208 364 minecraft:white_concrete
fill 196 208 339 196 214 339 minecraft:gray_concrete
fill 197 208 340 197 214 340 minecraft:gray_concrete
setblock 197 208 364 minecraft:sea_lantern
setblock 201 208 364 minecraft:white_concrete
setblock 202 208 364 minecraft:ochre_froglight
setblock 209 208 322 minecraft:pearlescent_froglight
fill 226 208 322 226 211 322 minecraft:black_concrete
setblock 230 208 347 minecraft:white_concrete
setblock 188 209 362 minecraft:white_concrete
setblock 191 209 325 minecraft:light[level=15]
setblock 191 209 333 minecraft:light[level=15]
setblock 191 209 341 minecraft:light[level=15]
setblock 191 209 349 minecraft:light[level=15]
setblock 191 209 357 minecraft:light[level=15]
fill 194 209 325 194 210 325 minecraft:light_gray_concrete
fill 194 209 360 194 210 360 minecraft:light_gray_concrete
fill 195 209 323 195 210 323 minecraft:lime_concrete
fill 195 209 326 195 211 326 minecraft:light_gray_concrete
fill 195 209 339 195 214 339 minecraft:gray_concrete
fill 195 209 341 197 214 341 minecraft:gray_concrete
fill 195 209 359 195 211 359 minecraft:light_gray_concrete
fill 195 209 362 195 209 363 minecraft:lime_concrete
fill 195 209 364 195 218 364 minecraft:black_concrete
fill 196 209 325 196 210 325 minecraft:light_gray_concrete
fill 196 209 360 196 210 360 minecraft:light_gray_concrete
fill 197 209 339 197 214 339 minecraft:gray_concrete
fill 197 209 364 197 225 364 minecraft:black_concrete
setblock 199 209 322 minecraft:ochre_froglight
setblock 199 209 325 minecraft:light[level=15]
setblock 199 209 333 minecraft:light[level=15]
setblock 199 209 341 minecraft:light[level=15]
setblock 199 209 349 minecraft:light[level=15]
setblock 199 209 357 minecraft:light[level=15]
fill 201 209 364 202 213 364 minecraft:black_concrete
setblock 207 209 325 minecraft:light[level=15]
setblock 207 209 333 minecraft:light[level=15]
setblock 207 209 341 minecraft:light[level=15]
setblock 207 209 349 minecraft:light[level=15]
setblock 207 209 357 minecraft:light[level=15]
fill 209 209 322 209 222 322 minecraft:black_concrete
setblock 215 209 325 minecraft:light[level=15]
setblock 215 209 333 minecraft:light[level=15]
setblock 215 209 341 minecraft:light[level=15]
setblock 215 209 349 minecraft:light[level=15]
setblock 215 209 357 minecraft:light[level=15]
setblock 217 209 364 minecraft:sea_lantern
setblock 222 209 364 minecraft:pearlescent_froglight
setblock 223 209 325 minecraft:light[level=15]
setblock 223 209 333 minecraft:light[level=15]
setblock 223 209 341 minecraft:light[level=15]
setblock 223 209 349 minecraft:light[level=15]
setblock 223 209 357 minecraft:light[level=15]
fill 230 209 347 230 226 347 minecraft:black_concrete
setblock 188 210 346 minecraft:ochre_froglight
setblock 188 210 353 minecraft:sea_lantern
fill 188 210 362 188 222 362 minecraft:black_concrete
fill 194 210 326 194 211 327 minecraft:light_gray_concrete
fill 194 210 340 194 214 340 minecraft:gray_concrete
fill 194 210 358 194 211 359 minecraft:light_gray_concrete
setblock 195 210 324 minecraft:lime_concrete
fill 195 210 327 196 211 327 minecraft:light_gray_concrete
fill 195 210 358 196 211 358 minecraft:light_gray_concrete
fill 195 210 361 195 210 362 minecraft:lime_concrete
fill 196 210 326 196 211 326 minecraft:light_gray_concrete
fill 196 210 338 196 214 338 minecraft:gray_concrete
fill 196 210 359 196 211 359 minecraft:light_gray_concrete
fill 199 210 322 199 211 322 minecraft:black_concrete
setblock 201 210 322 minecraft:white_concrete
fill 217 210 364 217 218 364 minecraft:black_concrete
setblock 220 210 322 minecraft:white_concrete
fill 222 210 364 222 282 364 minecraft:black_concrete
setblock 188 211 335 minecraft:white_concrete
fill 188 211 346 188 213 346 minecraft:black_concrete
fill 188 211 353 188 222 353 minecraft:black_concrete
setblock 189 211 364 minecraft:sea_lantern
setblock 191 211 325 minecraft:light[level=12]
setblock 191 211 332 minecraft:light[level=12]
setblock 191 211 339 minecraft:light[level=12]
setblock 191 211 346 minecraft:light[level=12]
setblock 191 211 353 minecraft:light[level=12]
setblock 191 211 360 minecraft:light[level=12]
fill 194 211 328 196 212 328 minecraft:light_gray_concrete
fill 194 211 339 194 214 339 minecraft:gray_concrete
fill 194 211 341 194 214 341 minecraft:gray_concrete
fill 194 211 357 196 212 357 minecraft:light_gray_concrete
setblock 195 211 325 minecraft:lime_concrete
fill 195 211 329 195 213 329 minecraft:light_gray_concrete
fill 195 211 338 195 214 338 minecraft:gray_concrete
fill 195 211 342 197 214 342 minecraft:gray_concrete
fill 195 211 356 195 213 356 minecraft:light_gray_concrete
setblock 195 211 360 minecraft:lime_concrete
fill 197 211 338 197 214 338 minecraft:gray_concrete
setblock 198 211 325 minecraft:light[level=12]
setblock 198 211 332 minecraft:light[level=12]
fill 198 211 339 198 214 341 minecraft:gray_concrete
setblock 198 211 346 minecraft:light[level=12]
setblock 198 211 353 minecraft:light[level=12]
setblock 198 211 360 minecraft:light[level=12]
fill 199 211 332 200 212 333 minecraft:gray_concrete
fill 201 211 322 201 254 322 minecraft:black_concrete
setblock 205 211 325 minecraft:light[level=12]
setblock 205 211 332 minecraft:light[level=12]
setblock 205 211 339 minecraft:light[level=12]
setblock 205 211 346 minecraft:light[level=12]
setblock 205 211 353 minecraft:light[level=12]
setblock 205 211 360 minecraft:light[level=12]
setblock 212 211 325 minecraft:light[level=12]
setblock 212 211 332 minecraft:light[level=12]
setblock 212 211 339 minecraft:light[level=12]
setblock 212 211 346 minecraft:light[level=12]
setblock 212 211 353 minecraft:light[level=12]
setblock 212 211 360 minecraft:light[level=12]
setblock 219 211 325 minecraft:light[level=12]
setblock 219 211 332 minecraft:light[level=12]
setblock 219 211 339 minecraft:light[level=12]
setblock 219 211 346 minecraft:light[level=12]
setblock 219 211 353 minecraft:light[level=12]
setblock 219 211 360 minecraft:light[level=12]
fill 220 211 322 220 246 322 minecraft:black_concrete
setblock 226 211 325 minecraft:light[level=12]
setblock 226 211 332 minecraft:light[level=12]
setblock 226 211 339 minecraft:light[level=12]
setblock 226 211 346 minecraft:light[level=12]
setblock 226 211 353 minecraft:light[level=12]
setblock 226 211 360 minecraft:light[level=12]
setblock 228 211 364 minecraft:pearlescent_froglight
fill 229 211 364 229 283 364 minecraft:black_concrete
setblock 230 211 331 minecraft:ochre_froglight
fill 188 212 335 188 240 335 minecraft:black_concrete
setblock 188 212 355 minecraft:sea_lantern
fill 189 212 364 189 218 364 minecraft:black_concrete
fill 193 212 336 193 213 337 minecraft:end_stone
fill 193 212 340 193 214 340 minecraft:gray_concrete
fill 194 212 329 194 213 329 minecraft:light_gray_concrete
fill 194 212 338 194 214 338 minecraft:gray_concrete
fill 194 212 342 194 214 342 minecraft:gray_concrete
fill 194 212 356 194 213 356 minecraft:light_gray_concrete
fill 195 212 326 195 212 327 minecraft:lime_concrete
fill 195 212 330 195 213 330 minecraft:light_gray_concrete
fill 195 212 355 195 213 355 minecraft:light_gray_concrete
fill 195 212 358 195 212 359 minecraft:lime_concrete
fill 196 212 329 196 213 329 minecraft:light_gray_concrete
fill 196 212 337 196 214 337 minecraft:gray_concrete
fill 196 212 356 196 213 356 minecraft:light_gray_concrete
fill 198 212 338 198 214 338 minecraft:gray_concrete
fill 198 212 342 198 214 342 minecraft:gray_concrete
setblock 199 212 322 minecraft:pearlescent_froglight
setblock 221 212 322 minecraft:pearlescent_froglight
setblock 221 212 364 minecraft:pearlescent_froglight
setblock 223 212 364 minecraft:ochre_froglight
setblock 226 212 322 minecraft:ochre_froglight
fill 228 212 364 228 228 364 minecraft:black_concrete
fill 230 212 331 230 216 331 minecraft:black_concrete
setblock 230 212 356 minecraft:white_concrete
setblock 188 213 331 minecraft:ochre_froglight
fill 188 213 342 188 214 342 minecraft:pearlescent_froglight
setblock 188 213 349 minecraft:white_concrete
fill 188 213 355 188 261 355 minecraft:black_concrete
setblock 188 213 358 minecraft:pearlescent_froglight
fill 193 213 339 193 214 339 minecraft:gray_concrete
fill 193 213 341 193 214 341 minecraft:gray_concrete
fill 194 213 330 194 213 331 minecraft:light_gray_concrete
fill 194 213 354 194 213 355 minecraft:light_gray_concrete
fill 195 213 327 195 213 328 minecraft:lime_concrete
fill 195 213 331 195 214 332 minecraft:light_gray_concrete
fill 195 213 337 195 214 337 minecraft:gray_concrete
fill 195 213 343 197 214 343 minecraft:gray_concrete
fill 195 213 353 195 214 354 minecraft:light_gray_concrete
fill 195 213 357 195 213 358 minecraft:lime_concrete
fill 196 213 330 196 213 331 minecraft:light_gray_concrete
fill 196 213 354 196 213 355 minecraft:light_gray_concrete
fill 197 213 337 197 214 337 minecraft:gray_concrete
fill 199 213 322 199 308 322 minecraft:black_concrete
fill 199 213 339 199 214 341 minecraft:gray_concrete
fill 221 213 322 221 299 322 minecraft:black_concrete
fill 221 213 364 221 236 364 minecraft:black_concrete
fill 223 213 364 223 214 364 minecraft:black_concrete
fill 226 213 322 226 308 322 minecraft:black_concrete
setblock 230 213 329 minecraft:pearlescent_froglight
fill 230 213 356 230 233 356 minecraft:black_concrete
fill 188 214 331 188 308 331 minecraft:black_concrete
setblock 188 214 346 minecraft:sea_lantern
fill 188 214 349 188 226 349 minecraft:black_concrete
fill 188 214 358 188 282 358 minecraft:black_concrete
setblock 193 214 338 minecraft:gray_concrete
setblock 193 214 342 minecraft:gray_concrete
fill 194 214 331 194 214 333 minecraft:light_gray_concrete
setblock 194 214 337 minecraft:gray_concrete
setblock 194 214 343 minecraft:gray_concrete
fill 194 214 352 194 214 354 minecraft:light_gray_concrete
fill 195 214 328 195 214 330 minecraft:lime_concrete
fill 195 214 333 195 215 334 minecraft:light_gray_concrete
fill 195 214 351 195 215 352 minecraft:light_gray_concrete
fill 195 214 355 195 214 357 minecraft:lime_concrete
fill 196 214 331 196 214 333 minecraft:light_gray_concrete
setblock 196 214 336 minecraft:gray_concrete
fill 196 214 352 196 214 354 minecraft:light_gray_concrete
setblock 198 214 337 minecraft:gray_concrete
setblock 198 214 343 minecraft:gray_concrete
setblock 199 214 338 minecraft:gray_concrete
setblock 199 214 342 minecraft:gray_concrete
setblock 201 214 364 minecraft:white_concrete
fill 202 214 364 202 252 364 minecraft:black_concrete
setblock 222 214 322 minecraft:ochre_froglight
fill 223 214 322 223 216 322 minecraft:black_concrete
setblock 230 214 323 minecraft:sea_lantern
fill 230 214 329 230 271 329 minecraft:black_concrete
setblock 188 215 327 minecraft:white_concrete
setblock 188 215 337 minecraft:pearlescent_froglight
setblock 188 215 342 minecraft:black_concrete
setblock 188 215 345 minecraft:ochre_froglight
fill 188 215 346 188 234 346 minecraft:black_concrete
fill 194 215 332 194 215 335 minecraft:light_gray_concrete
fill 194 215 350 194 215 353 minecraft:light_gray_concrete
fill 195 215 330 195 215 331 minecraft:lime_concrete
fill 195 215 332 196 215 332 minecraft:light_gray_concrete
fill 195 215 335 195 216 336 minecraft:light_gray_concrete
fill 195 215 339 196 215 340 minecraft:lime_stained_glass
fill 195 215 349 195 216 350 minecraft:light_gray_concrete
fill 195 215 353 196 215 353 minecraft:light_gray_concrete
fill 195 215 354 195 215 355 minecraft:lime_concrete
fill 196 215 333 196 215 335 minecraft:light_gray_concrete
setblock 196 215 341 minecraft:lime_stained_glass
fill 196 215 350 196 215 352 minecraft:light_gray_concrete
setblock 197 215 340 minecraft:lime_stained_glass
fill 201 215 364 201 244 364 minecraft:black_concrete
setblock 212 215 364 minecraft:pearlescent_froglight
fill 222 215 322 222 250 322 minecraft:black_concrete
setblock 223 215 364 minecraft:ochre_froglight
fill 230 215 323 230 236 323 minecraft:black_concrete
setblock 188 216 324 minecraft:ochre_froglight
fill 188 216 327 188 240 327 minecraft:black_concrete
fill 188 216 337 188 308 337 minecraft:black_concrete
setblock 188 216 339 minecraft:pearlescent_froglight
setblock 188 216 342 minecraft:white_concrete
setblock 188 216 344 minecraft:pearlescent_froglight
fill 188 216 345 188 308 345 minecraft:black_concrete
fill 194 216 334 194 216 338 minecraft:light_gray_concrete
fill 194 216 347 194 216 351 minecraft:light_gray_concrete
fill 195 216 332 195 216 333 minecraft:lime_concrete
fill 195 216 334 196 216 334 minecraft:light_gray_concrete
fill 195 216 337 195 217 339 minecraft:light_gray_concrete
fill 195 216 340 196 216 340 minecraft:lime_stained_glass
fill 195 216 341 195 217 348 minecraft:light_gray_concrete
fill 195 216 351 196 216 351 minecraft:light_gray_concrete
fill 195 216 352 195 216 353 minecraft:lime_concrete
fill 196 216 335 196 216 338 minecraft:light_gray_concrete
setblock 196 216 339 minecraft:lime_stained_glass
fill 196 216 347 196 216 350 minecraft:light_gray_concrete
setblock 211 216 364 minecraft:white_concrete
fill 212 216 364 212 229 364 minecraft:black_concrete
fill 223 216 364 223 237 364 minecraft:black_concrete
setblock 230 216 334 minecraft:ochre_froglight
setblock 230 216 336 minecraft:pearlescent_froglight
setblock 230 216 338 minecraft:white_concrete
fill 188 217 324 188 253 324 minecraft:black_concrete
setblock 188 217 339 minecraft:sea_lantern
fill 188 217 342 188 308 342 minecraft:black_concrete
fill 188 217 344 188 255 344 minecraft:black_concrete
setblock 191 217 325 minecraft:light[level=15]
setblock 191 217 332 minecraft:light[level=12]
setblock 191 217 333 minecraft:light[level=15]
setblock 191 217 339 minecraft:light[level=12]
setblock 191 217 341 minecraft:light[level=15]
setblock 191 217 346 minecraft:light[level=12]
setblock 191 217 349 minecraft:light[level=15]
setblock 191 217 353 minecraft:light[level=12]
setblock 191 217 357 minecraft:light[level=15]
setblock 191 217 360 minecraft:light[level=12]
fill 194 217 337 194 217 348 minecraft:light_gray_concrete
fill 195 217 333 195 217 336 minecraft:lime_concrete
fill 195 217 340 195 218 340 minecraft:light_gray_concrete
fill 195 217 349 195 217 352 minecraft:lime_concrete
fill 196 217 337 196 217 339 minecraft:light_gray_concrete
fill 196 217 340 196 218 340 minecraft:lime_stained_glass
fill 196 217 341 196 217 348 minecraft:light_gray_concrete
setblock 198 217 325 minecraft:light[level=12]
setblock 198 217 332 minecraft:light[level=12]
setblock 198 217 339 minecraft:light[level=12]
setblock 198 217 346 minecraft:light[level=12]
setblock 198 217 353 minecraft:light[level=12]
setblock 198 217 360 minecraft:light[level=12]
setblock 199 217 325 minecraft:light[level=15]
setblock 199 217 333 minecraft:light[level=15]
setblock 199 217 341 minecraft:light[level=15]
setblock 199 217 349 minecraft:light[level=15]
setblock 199 217 357 minecraft:light[level=15]
setblock 205 217 325 minecraft:light[level=12]
setblock 205 217 332 minecraft:light[level=12]
setblock 205 217 339 minecraft:light[level=12]
setblock 205 217 346 minecraft:light[level=12]
setblock 205 217 353 minecraft:light[level=12]
setblock 205 217 360 minecraft:light[level=12]
setblock 207 217 325 minecraft:light[level=15]
setblock 207 217 333 minecraft:light[level=15]
setblock 207 217 341 minecraft:light[level=15]
setblock 207 217 349 minecraft:light[level=15]
setblock 207 217 357 minecraft:light[level=15]
fill 211 217 364 211 232 364 minecraft:black_concrete
setblock 212 217 325 minecraft:light[level=12]
setblock 212 217 332 minecraft:light[level=12]
setblock 212 217 339 minecraft:light[level=12]
setblock 212 217 346 minecraft:light[level=12]
setblock 212 217 353 minecraft:light[level=12]
setblock 212 217 360 minecraft:light[level=12]
setblock 215 217 325 minecraft:light[level=15]
setblock 215 217 333 minecraft:light[level=15]
setblock 215 217 341 minecraft:light[level=15]
setblock 215 217 349 minecraft:light[level=15]
setblock 215 217 357 minecraft:light[level=15]
setblock 219 217 325 minecraft:light[level=12]
setblock 219 217 332 minecraft:light[level=12]
setblock 219 217 339 minecraft:light[level=12]
setblock 219 217 346 minecraft:light[level=12]
setblock 219 217 353 minecraft:light[level=12]
setblock 219 217 360 minecraft:light[level=12]
setblock 223 217 322 minecraft:sea_lantern
setblock 223 217 325 minecraft:light[level=15]
setblock 223 217 333 minecraft:light[level=15]
setblock 223 217 341 minecraft:light[level=15]
setblock 223 217 349 minecraft:light[level=15]
setblock 223 217 357 minecraft:light[level=15]
setblock 226 217 325 minecraft:light[level=12]
setblock 226 217 332 minecraft:light[level=12]
setblock 226 217 339 minecraft:light[level=12]
setblock 226 217 346 minecraft:light[level=12]
setblock 226 217 353 minecraft:light[level=12]
setblock 226 217 360 minecraft:light[level=12]
setblock 230 217 331 minecraft:white_concrete
setblock 230 217 333 minecraft:sea_lantern
setblock 230 217 334 minecraft:black_concrete
setblock 230 217 336 minecraft:black_concrete
fill 230 217 338 230 220 338 minecraft:black_concrete
setblock 230 217 354 minecraft:ochre_froglight
setblock 230 217 357 minecraft:sea_lantern
fill 188 218 339 188 308 339 minecraft:black_concrete
fill 190 218 322 190 220 322 minecraft:black_concrete
setblock 191 218 322 minecraft:pearlescent_froglight
setblock 193 218 322 minecraft:ochre_froglight
fill 194 218 340 194 218 345 minecraft:light_gray_concrete
fill 195 218 336 195 218 339 minecraft:lime_concrete
fill 195 218 341 196 218 345 minecraft:light_gray_concrete
fill 195 218 346 195 218 349 minecraft:lime_concrete
fill 223 218 322 223 297 322 minecraft:black_concrete
setblock 230 218 325 minecraft:sea_lantern
fill 230 218 331 230 252 331 minecraft:black_concrete
fill 230 218 333 230 278 333 minecraft:black_concrete
setblock 230 218 334 minecraft:white_concrete
setblock 230 218 336 minecraft:pearlescent_froglight
fill 230 218 354 230 308 354 minecraft:black_concrete
fill 230 218 357 230 233 357 minecraft:black_concrete
setblock 188 219 334 minecraft:white_concrete
setblock 189 219 364 minecraft:sea_lantern
fill 191 219 322 191 270 322 minecraft:black_concrete
fill 193 219 322 193 237 322 minecraft:black_concrete
setblock 195 219 364 minecraft:white_concrete
setblock 217 219 364 minecraft:pearlescent_froglight
fill 230 219 325 230 236 325 minecraft:black_concrete
fill 230 219 334 230 220 334 minecraft:black_concrete
fill 230 219 336 230 227 336 minecraft:black_concrete
fill 188 220 334 188 234 334 minecraft:black_concrete
fill 189 220 364 189 244 364 minecraft:black_concrete
fill 195 220 364 195 266 364 minecraft:black_concrete
fill 217 220 364 217 245 364 minecraft:black_concrete
setblock 190 221 322 minecraft:sea_lantern
setblock 193 221 364 minecraft:pearlescent_froglight
setblock 200 221 322 minecraft:pearlescent_froglight
setblock 230 221 334 minecraft:ochre_froglight
setblock 230 221 337 minecraft:sea_lantern
setblock 230 221 338 minecraft:ochre_froglight
setblock 188 222 330 minecraft:ochre_froglight
fill 190 222 322 190 259 322 minecraft:black_concrete
setblock 191 222 364 minecraft:white_concrete
fill 193 222 364 193 279 364 minecraft:black_concrete
setblock 198 222 322 minecraft:white_concrete
fill 200 222 322 200 259 322 minecraft:black_concrete
setblock 225 222 322 minecraft:pearlescent_froglight
fill 230 222 334 230 225 334 minecraft:black_concrete
fill 230 222 337 230 244 337 minecraft:black_concrete
setblock 230 222 338 minecraft:sea_lantern
setblock 230 222 355 minecraft:pearlescent_froglight
fill 188 223 330 188 242 330 minecraft:black_concrete
setblock 188 223 353 minecraft:pearlescent_froglight
setblock 188 223 362 minecraft:ochre_froglight
setblock 191 223 325 minecraft:light[level=12]
setblock 191 223 332 minecraft:light[level=12]
setblock 191 223 339 minecraft:light[level=12]
setblock 191 223 346 minecraft:light[level=12]
setblock 191 223 353 minecraft:light[level=12]
setblock 191 223 360 minecraft:light[level=12]
fill 191 223 364 191 231 364 minecraft:black_concrete
fill 198 223 322 198 283 322 minecraft:black_concrete
setblock 198 223 325 minecraft:light[level=12]
setblock 198 223 332 minecraft:light[level=12]
setblock 198 223 339 minecraft:light[level=12]
setblock 198 223 346 minecraft:light[level=12]
setblock 198 223 353 minecraft:light[level=12]
setblock 198 223 360 minecraft:light[level=12]
setblock 205 223 325 minecraft:light[level=12]
setblock 205 223 332 minecraft:light[level=12]
setblock 205 223 339 minecraft:light[level=12]
setblock 205 223 346 minecraft:light[level=12]
setblock 205 223 353 minecraft:light[level=12]
setblock 205 223 360 minecraft:light[level=12]
setblock 209 223 322 minecraft:ochre_froglight
setblock 212 223 325 minecraft:light[level=12]
setblock 212 223 332 minecraft:light[level=12]
setblock 212 223 339 minecraft:light[level=12]
setblock 212 223 346 minecraft:light[level=12]
setblock 212 223 353 minecraft:light[level=12]
setblock 212 223 360 minecraft:light[level=12]
setblock 214 223 322 minecraft:sea_lantern
setblock 219 223 325 minecraft:light[level=12]
setblock 219 223 332 minecraft:light[level=12]
setblock 219 223 339 minecraft:light[level=12]
setblock 219 223 346 minecraft:light[level=12]
setblock 219 223 353 minecraft:light[level=12]
setblock 219 223 360 minecraft:light[level=12]
setblock 220 223 364 minecraft:pearlescent_froglight
fill 225 223 322 225 308 322 minecraft:black_concrete
setblock 226 223 325 minecraft:light[level=12]
setblock 226 223 332 minecraft:light[level=12]
setblock 226 223 339 minecraft:light[level=12]
setblock 226 223 346 minecraft:light[level=12]
setblock 226 223 353 minecraft:light[level=12]
setblock 226 223 360 minecraft:light[level=12]
setblock 230 223 330 minecraft:white_concrete
fill 230 223 338 230 308 338 minecraft:black_concrete
setblock 230 223 344 minecraft:ochre_froglight
fill 230 223 355 230 281 355 minecraft:black_concrete
setblock 188 224 353 minecraft:black_concrete
fill 188 224 362 188 251 362 minecraft:black_concrete
setblock 195 224 322 minecraft:white_concrete
fill 201 224 338 201 226 346 minecraft:iron_block
fill 202 224 337 202 226 339 minecraft:iron_block
fill 202 224 340 202 225 340 minecraft:purple_stained_glass
fill 202 224 341 202 225 341 minecraft:magenta_stained_glass
fill 202 224 342 202 225 343 minecraft:purple_stained_glass
fill 202 224 344 202 225 344 minecraft:magenta_stained_glass
fill 202 224 345 202 226 347 minecraft:iron_block
fill 203 224 336 203 226 337 minecraft:iron_block
fill 203 224 338 203 225 339 minecraft:purple_stained_glass
fill 203 224 340 203 225 340 minecraft:magenta_stained_glass
fill 203 224 341 203 225 342 minecraft:purple_stained_glass
fill 203 224 343 203 225 343 minecraft:magenta_stained_glass
fill 203 224 344 203 225 345 minecraft:purple_stained_glass
fill 203 224 346 203 225 346 minecraft:magenta_stained_glass
fill 203 224 347 203 226 348 minecraft:iron_block
fill 204 224 335 204 226 336 minecraft:iron_block
fill 204 224 337 204 225 338 minecraft:purple_stained_glass
fill 204 224 339 204 225 339 minecraft:magenta_stained_glass
fill 204 224 340 204 225 341 minecraft:purple_stained_glass
fill 204 224 342 204 225 342 minecraft:magenta_stained_glass
fill 204 224 343 204 225 344 minecraft:purple_stained_glass
fill 204 224 345 204 225 345 minecraft:magenta_stained_glass
fill 204 224 346 204 225 347 minecraft:purple_stained_glass
fill 204 224 348 204 226 349 minecraft:iron_block
fill 205 224 334 206 226 335 minecraft:iron_block
fill 205 224 336 205 225 337 minecraft:purple_stained_glass
fill 205 224 338 205 225 338 minecraft:magenta_stained_glass
fill 205 224 339 205 225 340 minecraft:purple_stained_glass
fill 205 224 341 205 225 341 minecraft:magenta_stained_glass
fill 205 224 342 205 225 343 minecraft:purple_stained_glass
fill 205 224 344 205 225 344 minecraft:magenta_stained_glass
fill 205 224 345 205 225 346 minecraft:purple_stained_glass
fill 205 224 347 205 225 347 minecraft:magenta_stained_glass
fill 205 224 348 206 225 348 minecraft:purple_stained_glass
fill 205 224 349 206 226 350 minecraft:iron_block
fill 206 224 336 206 225 336 minecraft:purple_stained_glass
fill 206 224 337 206 225 337 minecraft:magenta_stained_glass
fill 206 224 338 206 225 339 minecraft:purple_stained_glass
setblock 206 224 340 minecraft:magenta_stained_glass
fill 206 224 341 206 224 342 minecraft:purple_stained_glass
setblock 206 224 343 minecraft:magenta_stained_glass
fill 206 224 344 206 224 345 minecraft:purple_stained_glass
fill 206 224 346 206 225 346 minecraft:magenta_stained_glass
fill 206 224 347 207 225 347 minecraft:purple_stained_glass
fill 207 224 334 213 226 334 minecraft:iron_block
fill 207 224 335 207 225 335 minecraft:purple_stained_glass
fill 207 224 336 207 225 336 minecraft:magenta_stained_glass
fill 207 224 337 207 225 338 minecraft:purple_stained_glass
setblock 207 224 339 minecraft:magenta_stained_glass
setblock 207 224 340 minecraft:purple_stained_glass
setblock 207 224 344 minecraft:purple_stained_glass
setblock 207 224 345 minecraft:magenta_stained_glass
fill 207 224 346 208 225 346 minecraft:purple_stained_glass
fill 207 224 348 207 225 348 minecraft:magenta_stained_glass
fill 207 224 349 208 225 349 minecraft:purple_stained_glass
fill 207 224 350 213 226 350 minecraft:iron_block
fill 208 224 335 208 225 335 minecraft:magenta_stained_glass
fill 208 224 336 208 225 337 minecraft:purple_stained_glass
fill 208 224 338 208 225 338 minecraft:magenta_stained_glass
fill 208 224 339 209 224 339 minecraft:purple_stained_glass
fill 208 224 345 209 224 345 minecraft:purple_stained_glass
fill 208 224 347 208 225 347 minecraft:magenta_stained_glass
fill 208 224 348 209 225 348 minecraft:purple_stained_glass
fill 209 224 322 209 232 322 minecraft:black_concrete
fill 209 224 335 209 225 336 minecraft:purple_stained_glass
fill 209 224 337 209 225 337 minecraft:magenta_stained_glass
fill 209 224 338 210 225 338 minecraft:purple_stained_glass
fill 209 224 346 209 225 346 minecraft:magenta_stained_glass
fill 209 224 347 210 225 347 minecraft:purple_stained_glass
fill 209 224 349 209 225 349 minecraft:magenta_stained_glass
fill 210 224 335 210 225 335 minecraft:purple_stained_glass
fill 210 224 336 210 225 336 minecraft:magenta_stained_glass
fill 210 224 337 211 225 337 minecraft:purple_stained_glass
setblock 210 224 339 minecraft:magenta_stained_glass
setblock 210 224 345 minecraft:magenta_stained_glass
fill 210 224 346 211 225 346 minecraft:purple_stained_glass
fill 210 224 348 210 225 348 minecraft:magenta_stained_glass
fill 210 224 349 211 225 349 minecraft:purple_stained_glass
fill 211 224 335 211 225 335 minecraft:magenta_stained_glass
fill 211 224 336 212 225 336 minecraft:purple_stained_glass
fill 211 224 338 211 225 338 minecraft:magenta_stained_glass
fill 211 224 339 211 224 340 minecraft:purple_stained_glass
setblock 211 224 344 minecraft:magenta_stained_glass
fill 211 224 345 212 224 345 minecraft:purple_stained_glass
fill 211 224 347 211 225 347 minecraft:magenta_stained_glass
fill 211 224 348 212 225 348 minecraft:purple_stained_glass
fill 212 224 335 214 226 335 minecraft:iron_block
fill 212 224 337 212 225 337 minecraft:magenta_stained_glass
fill 212 224 338 212 225 339 minecraft:purple_stained_glass
setblock 212 224 340 minecraft:magenta_stained_glass
fill 212 224 341 212 224 342 minecraft:purple_stained_glass
setblock 212 224 343 minecraft:magenta_stained_glass
fill 212 224 344 213 224 344 minecraft:purple_stained_glass
fill 212 224 346 212 225 346 minecraft:magenta_stained_glass
fill 212 224 347 213 225 347 minecraft:purple_stained_glass
fill 212 224 349 214 226 349 minecraft:iron_block
fill 213 224 336 213 225 336 minecraft:magenta_stained_glass
fill 213 224 337 213 225 338 minecraft:purple_stained_glass
fill 213 224 339 213 225 339 minecraft:magenta_stained_glass
fill 213 224 340 213 225 341 minecraft:purple_stained_glass
fill 213 224 342 213 225 342 minecraft:magenta_stained_glass
fill 213 224 343 214 225 343 minecraft:purple_stained_glass
fill 213 224 345 213 225 345 minecraft:magenta_stained_glass
fill 213 224 346 214 225 346 minecraft:purple_stained_glass
fill 213 224 348 213 225 348 minecraft:magenta_stained_glass
fill 214 224 322 214 264 322 minecraft:black_concrete
fill 214 224 336 215 226 336 minecraft:iron_block
fill 214 224 337 214 225 337 minecraft:purple_stained_glass
fill 214 224 338 214 225 338 minecraft:magenta_stained_glass
fill 214 224 339 214 225 340 minecraft:purple_stained_glass
fill 214 224 341 214 225 341 minecraft:magenta_stained_glass
fill 214 224 342 215 225 342 minecraft:purple_stained_glass
fill 214 224 344 214 225 344 minecraft:magenta_stained_glass
fill 214 224 345 215 225 345 minecraft:purple_stained_glass
fill 214 224 347 214 225 347 minecraft:magenta_stained_glass
fill 214 224 348 215 226 348 minecraft:iron_block
fill 215 224 337 216 226 337 minecraft:iron_block
fill 215 224 338 215 225 339 minecraft:purple_stained_glass
fill 215 224 340 215 225 340 minecraft:magenta_stained_glass
fill 215 224 341 216 225 341 minecraft:purple_stained_glass
fill 215 224 343 215 225 343 minecraft:magenta_stained_glass
fill 215 224 344 216 225 344 minecraft:purple_stained_glass
fill 215 224 346 215 225 346 minecraft:magenta_stained_glass
fill 215 224 347 216 226 347 minecraft:iron_block
fill 216 224 338 217 226 339 minecraft:iron_block
fill 216 224 340 216 225 340 minecraft:purple_stained_glass
fill 216 224 342 216 225 342 minecraft:magenta_stained_glass
fill 216 224 343 216 225 343 minecraft:purple_stained_glass
fill 216 224 345 217 226 346 minecraft:iron_block
fill 217 224 340 217 226 344 minecraft:iron_block
fill 220 224 364 220 308 364 minecraft:black_concrete
fill 230 224 330 230 308 330 minecraft:black_concrete
fill 230 224 344 230 308 344 minecraft:black_concrete
setblock 188 225 323 minecraft:pearlescent_froglight
setblock 188 225 336 minecraft:sea_lantern
setblock 188 225 353 minecraft:white_concrete
fill 189 225 323 199 225 363 minecraft:black_stained_glass
fill 195 225 322 195 287 322 minecraft:black_concrete
fill 200 225 323 200 225 339 minecraft:black_stained_glass
fill 200 225 340 200 225 344 minecraft:iron_block
fill 200 225 345 200 225 363 minecraft:black_stained_glass
fill 201 225 323 201 225 337 minecraft:black_stained_glass
fill 201 225 347 201 225 363 minecraft:black_stained_glass
fill 202 225 323 202 225 335 minecraft:black_stained_glass
setblock 202 225 336 minecraft:iron_block
setblock 202 225 348 minecraft:iron_block
fill 202 225 349 202 225 363 minecraft:black_stained_glass
fill 203 225 323 204 225 334 minecraft:black_stained_glass
setblock 203 225 335 minecraft:iron_block
setblock 203 225 349 minecraft:iron_block
fill 203 225 350 204 225 363 minecraft:black_stained_glass
fill 205 225 323 206 225 333 minecraft:black_stained_glass
fill 205 225 351 206 225 363 minecraft:black_stained_glass
fill 206 225 340 206 225 344 minecraft:verdant_froglight
setblock 206 225 345 minecraft:purple_stained_glass
fill 207 225 323 229 225 332 minecraft:black_stained_glass
fill 207 225 333 211 225 333 minecraft:iron_block
fill 207 225 339 207 225 340 minecraft:verdant_froglight
fill 207 225 344 207 225 345 minecraft:verdant_froglight
fill 207 225 351 211 225 351 minecraft:iron_block
fill 207 225 352 229 225 363 minecraft:black_stained_glass
fill 208 225 339 211 225 339 minecraft:verdant_froglight
fill 208 225 345 211 225 345 minecraft:verdant_froglight
fill 211 225 340 212 225 340 minecraft:verdant_froglight
fill 211 225 344 212 225 344 minecraft:verdant_froglight
fill 212 225 333 229 225 333 minecraft:black_stained_glass
fill 212 225 341 212 225 343 minecraft:verdant_froglight
setblock 212 225 345 minecraft:purple_stained_glass
fill 212 225 351 229 225 351 minecraft:black_stained_glass
setblock 213 225 344 minecraft:purple_stained_glass
fill 214 225 334 229 225 334 minecraft:black_stained_glass
fill 214 225 350 229 225 350 minecraft:black_stained_glass
setblock 215 225 335 minecraft:iron_block
setblock 215 225 349 minecraft:iron_block
fill 216 225 335 229 225 335 minecraft:black_stained_glass
setblock 216 225 336 minecraft:iron_block
setblock 216 225 348 minecraft:iron_block
fill 216 225 349 229 225 349 minecraft:black_stained_glass
fill 217 225 336 229 225 337 minecraft:black_stained_glass
fill 217 225 347 229 225 348 minecraft:black_stained_glass
fill 218 225 338 229 225 339 minecraft:black_stained_glass
fill 218 225 340 218 225 344 minecraft:iron_block
fill 218 225 345 229 225 346 minecraft:black_stained_glass
fill 219 225 340 229 225 344 minecraft:black_stained_glass
fill 188 226 323 188 266 323 minecraft:black_concrete
fill 188 226 336 188 235 336 minecraft:black_concrete
fill 188 226 353 188 299 353 minecraft:black_concrete
setblock 192 226 364 minecraft:pearlescent_froglight
setblock 197 226 364 minecraft:pearlescent_froglight
fill 202 226 340 202 226 344 minecraft:iron_block
schedule function dropper:buildpart/76_2 1t
