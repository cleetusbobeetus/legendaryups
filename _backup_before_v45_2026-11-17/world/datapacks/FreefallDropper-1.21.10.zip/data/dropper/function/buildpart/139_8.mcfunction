setblock 333 270 592 minecraft:oak_log
setblock 333 270 597 minecraft:oak_log
fill 333 270 598 333 273 598 minecraft:green_terracotta
fill 334 270 590 335 270 591 minecraft:oak_leaves[persistent=true]
fill 334 270 597 335 272 597 minecraft:green_terracotta
fill 335 270 564 335 270 567 minecraft:oak_leaves[persistent=true]
fill 335 270 588 335 270 589 minecraft:oak_leaves[persistent=true]
fill 335 270 592 339 270 592 minecraft:oak_leaves[persistent=true]
setblock 336 270 558 minecraft:oak_leaves[persistent=true]
setblock 336 270 565 minecraft:oak_leaves[persistent=true]
fill 336 270 588 338 270 588 minecraft:oak_leaves[persistent=true]
fill 336 270 593 338 270 593 minecraft:oak_leaves[persistent=true]
setblock 337 270 598 minecraft:oak_log
fill 338 270 589 339 270 589 minecraft:oak_leaves[persistent=true]
fill 339 270 590 339 271 591 minecraft:oak_leaves[persistent=true]
setblock 345 270 598 minecraft:oak_leaves[persistent=true]
fill 348 270 581 348 270 585 minecraft:oak_leaves[persistent=true]
fill 349 270 581 349 271 582 minecraft:oak_leaves[persistent=true]
fill 349 270 585 353 270 586 minecraft:oak_leaves[persistent=true]
fill 350 270 569 350 271 570 minecraft:oak_leaves[persistent=true]
fill 352 270 587 357 270 587 minecraft:oak_leaves[persistent=true]
fill 353 270 558 353 273 558 minecraft:green_terracotta
fill 353 270 583 353 271 584 minecraft:oak_leaves[persistent=true]
fill 353 270 588 355 270 588 minecraft:oak_leaves[persistent=true]
fill 354 270 583 355 273 585 minecraft:oak_log
fill 355 270 580 356 270 581 minecraft:oak_leaves[persistent=true]
fill 355 270 586 357 271 586 minecraft:oak_leaves[persistent=true]
fill 355 270 591 356 270 592 minecraft:oak_leaves[persistent=true]
setblock 356 270 559 minecraft:oak_log
fill 356 270 582 358 270 582 minecraft:oak_leaves[persistent=true]
fill 356 270 589 357 270 590 minecraft:oak_leaves[persistent=true]
fill 356 270 593 357 270 594 minecraft:oak_leaves[persistent=true]
setblock 356 270 598 minecraft:green_terracotta
setblock 357 270 558 minecraft:oak_log
fill 357 270 559 357 273 559 minecraft:green_terracotta
setblock 357 270 581 minecraft:oak_leaves[persistent=true]
fill 357 270 583 358 270 585 minecraft:oak_leaves[persistent=true]
setblock 357 270 598 minecraft:oak_log
fill 358 270 558 358 273 558 minecraft:green_terracotta
fill 358 270 589 360 270 589 minecraft:oak_leaves[persistent=true]
fill 358 270 594 359 270 595 minecraft:oak_leaves[persistent=true]
fill 360 270 590 361 270 590 minecraft:oak_leaves[persistent=true]
fill 360 270 593 361 270 594 minecraft:oak_leaves[persistent=true]
fill 361 270 591 361 271 592 minecraft:oak_leaves[persistent=true]
setblock 364 270 598 minecraft:oak_leaves[persistent=true]
setblock 370 270 565 minecraft:oak_log
fill 370 270 566 370 273 566 minecraft:green_terracotta
setblock 370 270 570 minecraft:oak_log
fill 370 270 586 370 273 586 minecraft:green_terracotta
setblock 370 270 589 minecraft:green_terracotta
setblock 370 270 590 minecraft:oak_log
fill 370 270 591 370 273 591 minecraft:green_terracotta
setblock 370 270 594 minecraft:green_terracotta
setblock 370 270 595 minecraft:oak_log
fill 370 270 596 370 271 598 minecraft:green_terracotta
fill 330 271 565 330 271 568 minecraft:green_terracotta
setblock 330 271 569 minecraft:oak_log
fill 330 271 570 330 271 573 minecraft:green_terracotta
setblock 330 271 574 minecraft:oak_log
setblock 330 271 575 minecraft:oak_leaves[persistent=true]
fill 330 271 582 330 272 582 minecraft:green_terracotta
setblock 330 271 584 minecraft:oak_log
fill 330 271 585 330 273 585 minecraft:green_terracotta
setblock 330 271 589 minecraft:oak_log
fill 330 271 590 330 273 590 minecraft:green_terracotta
setblock 330 271 593 minecraft:green_terracotta
setblock 330 271 594 minecraft:oak_log
fill 330 271 595 330 273 595 minecraft:green_terracotta
setblock 330 271 598 minecraft:green_terracotta
fill 331 271 564 331 272 565 minecraft:oak_leaves[persistent=true]
fill 331 271 569 331 273 570 minecraft:green_terracotta
fill 331 271 584 331 273 584 minecraft:green_terracotta
setblock 331 271 588 minecraft:oak_log
fill 331 271 589 331 273 589 minecraft:green_terracotta
setblock 331 271 593 minecraft:oak_log
fill 331 271 594 331 273 594 minecraft:green_terracotta
setblock 331 271 597 minecraft:green_terracotta
setblock 331 271 598 minecraft:oak_log
fill 332 271 563 334 271 563 minecraft:oak_leaves[persistent=true]
fill 332 271 567 334 272 567 minecraft:oak_leaves[persistent=true]
fill 332 271 585 332 272 585 minecraft:green_terracotta
setblock 332 271 587 minecraft:oak_log
fill 332 271 588 332 273 588 minecraft:green_terracotta
setblock 332 271 592 minecraft:oak_log
fill 332 271 593 333 273 593 minecraft:green_terracotta
fill 332 271 595 332 272 595 minecraft:green_terracotta
setblock 332 271 597 minecraft:oak_log
fill 332 271 598 332 273 598 minecraft:green_terracotta
fill 333 271 587 333 273 587 minecraft:green_terracotta
setblock 333 271 590 minecraft:green_terracotta
setblock 333 271 591 minecraft:oak_log
fill 333 271 592 333 273 592 minecraft:green_terracotta
setblock 333 271 596 minecraft:oak_log
fill 333 271 597 333 273 597 minecraft:green_terracotta
fill 334 271 596 334 273 596 minecraft:green_terracotta
fill 335 271 564 335 271 566 minecraft:oak_leaves[persistent=true]
fill 335 271 589 335 271 592 minecraft:oak_leaves[persistent=true]
fill 336 271 588 337 271 588 minecraft:oak_leaves[persistent=true]
fill 336 271 592 338 271 592 minecraft:oak_leaves[persistent=true]
setblock 336 271 597 minecraft:green_terracotta
setblock 336 271 598 minecraft:oak_log
fill 337 271 598 338 273 598 minecraft:green_terracotta
fill 338 271 589 338 272 589 minecraft:oak_leaves[persistent=true]
fill 348 271 582 348 271 584 minecraft:oak_leaves[persistent=true]
setblock 349 271 558 minecraft:oak_leaves[persistent=true]
fill 349 271 585 352 272 585 minecraft:oak_leaves[persistent=true]
fill 350 271 586 353 271 586 minecraft:oak_leaves[persistent=true]
setblock 351 271 598 minecraft:oak_leaves[persistent=true]
fill 352 271 558 352 273 558 minecraft:green_terracotta
fill 353 271 585 353 273 585 minecraft:oak_log
fill 353 271 587 355 271 587 minecraft:oak_leaves[persistent=true]
setblock 354 271 559 minecraft:green_terracotta
fill 354 271 598 355 271 598 minecraft:green_terracotta
setblock 355 271 559 minecraft:oak_log
fill 355 271 581 356 271 581 minecraft:oak_leaves[persistent=true]
setblock 356 271 558 minecraft:oak_log
fill 356 271 559 356 273 559 minecraft:green_terracotta
fill 356 271 582 357 271 582 minecraft:oak_leaves[persistent=true]
fill 356 271 590 356 271 593 minecraft:oak_leaves[persistent=true]
setblock 356 271 598 minecraft:oak_log
fill 357 271 558 357 273 558 minecraft:green_terracotta
fill 357 271 583 357 271 585 minecraft:oak_leaves[persistent=true]
fill 357 271 589 357 271 590 minecraft:oak_leaves[persistent=true]
fill 357 271 593 357 271 594 minecraft:oak_leaves[persistent=true]
fill 357 271 598 360 271 598 minecraft:green_terracotta
fill 358 271 589 359 271 589 minecraft:oak_leaves[persistent=true]
fill 358 271 594 360 271 594 minecraft:oak_leaves[persistent=true]
fill 360 271 590 360 272 590 minecraft:oak_leaves[persistent=true]
fill 360 271 593 361 271 593 minecraft:oak_leaves[persistent=true]
setblock 361 271 558 minecraft:oak_log
fill 368 271 598 369 272 598 minecraft:green_terracotta
setblock 369 271 589 minecraft:green_terracotta
setblock 369 271 590 minecraft:oak_log
fill 369 271 591 369 271 594 minecraft:green_terracotta
setblock 369 271 595 minecraft:oak_log
setblock 370 271 558 minecraft:green_terracotta
fill 370 271 561 370 273 561 minecraft:green_terracotta
setblock 370 271 564 minecraft:oak_log
fill 370 271 565 370 273 565 minecraft:green_terracotta
setblock 370 271 569 minecraft:oak_log
fill 370 271 570 370 272 572 minecraft:green_terracotta
setblock 370 271 581 minecraft:oak_leaves[persistent=true]
fill 370 271 585 370 273 585 minecraft:green_terracotta
setblock 370 271 589 minecraft:oak_log
fill 370 271 590 370 273 590 minecraft:green_terracotta
setblock 370 271 594 minecraft:oak_log
fill 370 271 595 370 273 595 minecraft:green_terracotta
fill 330 272 565 330 272 567 minecraft:green_terracotta
setblock 330 272 568 minecraft:oak_log
fill 330 272 569 330 272 572 minecraft:green_terracotta
setblock 330 272 573 minecraft:oak_log
fill 330 272 574 330 272 577 minecraft:green_terracotta
setblock 330 272 578 minecraft:oak_log
fill 330 272 579 330 273 581 minecraft:green_terracotta
setblock 330 272 583 minecraft:oak_log
fill 330 272 584 330 273 584 minecraft:green_terracotta
setblock 330 272 588 minecraft:oak_log
fill 330 272 589 330 273 589 minecraft:green_terracotta
setblock 330 272 593 minecraft:oak_log
fill 330 272 594 330 273 594 minecraft:green_terracotta
setblock 330 272 598 minecraft:oak_log
setblock 331 272 566 minecraft:oak_leaves[persistent=true]
setblock 331 272 567 minecraft:oak_log
fill 331 272 568 331 273 568 minecraft:green_terracotta
setblock 331 272 571 minecraft:green_terracotta
setblock 331 272 572 minecraft:oak_log
fill 331 272 573 331 273 574 minecraft:green_terracotta
fill 331 272 583 331 273 583 minecraft:green_terracotta
setblock 331 272 586 minecraft:green_terracotta
setblock 331 272 587 minecraft:oak_log
fill 331 272 588 331 273 588 minecraft:green_terracotta
setblock 331 272 592 minecraft:oak_log
fill 331 272 593 331 273 593 minecraft:green_terracotta
setblock 331 272 597 minecraft:oak_log
fill 331 272 598 331 273 598 minecraft:green_terracotta
setblock 332 272 560 minecraft:light[level=14]
setblock 332 272 568 minecraft:light[level=14]
setblock 332 272 576 minecraft:light[level=14]
setblock 332 272 584 minecraft:light[level=14]
setblock 332 272 586 minecraft:oak_log
fill 332 272 587 332 273 587 minecraft:green_terracotta
setblock 332 272 591 minecraft:oak_log
fill 332 272 592 332 273 592 minecraft:green_terracotta
setblock 332 272 596 minecraft:oak_log
fill 332 272 597 332 273 597 minecraft:green_terracotta
setblock 333 272 563 minecraft:oak_leaves[persistent=true]
setblock 333 272 590 minecraft:oak_log
fill 333 272 591 333 273 591 minecraft:green_terracotta
setblock 333 272 594 minecraft:green_terracotta
fill 333 272 596 333 273 596 minecraft:green_terracotta
setblock 335 272 565 minecraft:oak_leaves[persistent=true]
fill 335 272 590 335 272 591 minecraft:oak_leaves[persistent=true]
fill 335 272 596 335 273 596 minecraft:green_terracotta
setblock 335 272 598 minecraft:oak_log
fill 336 272 592 337 272 592 minecraft:oak_leaves[persistent=true]
setblock 336 272 597 minecraft:oak_log
fill 336 272 598 336 273 598 minecraft:green_terracotta
fill 337 272 597 337 273 597 minecraft:green_terracotta
setblock 340 272 560 minecraft:light[level=14]
setblock 340 272 568 minecraft:light[level=14]
setblock 340 272 576 minecraft:light[level=14]
setblock 340 272 584 minecraft:light[level=14]
setblock 340 272 592 minecraft:light[level=14]
setblock 343 272 558 minecraft:oak_leaves[persistent=true]
setblock 348 272 560 minecraft:light[level=14]
setblock 348 272 568 minecraft:light[level=14]
setblock 348 272 576 minecraft:light[level=14]
setblock 348 272 584 minecraft:light[level=14]
setblock 348 272 592 minecraft:light[level=14]
setblock 349 272 582 minecraft:oak_leaves[persistent=true]
fill 351 272 558 351 273 558 minecraft:green_terracotta
fill 352 272 598 354 272 598 minecraft:green_terracotta
setblock 353 272 559 minecraft:green_terracotta
fill 353 272 583 353 273 584 minecraft:oak_log
setblock 353 272 586 minecraft:oak_leaves[persistent=true]
setblock 354 272 559 minecraft:oak_log
setblock 355 272 558 minecraft:oak_log
fill 355 272 559 355 273 559 minecraft:green_terracotta
setblock 355 272 581 minecraft:oak_leaves[persistent=true]
fill 355 272 586 356 272 586 minecraft:oak_leaves[persistent=true]
setblock 355 272 597 minecraft:green_terracotta
setblock 355 272 598 minecraft:oak_log
fill 356 272 558 356 273 558 minecraft:green_terracotta
setblock 356 272 560 minecraft:light[level=14]
setblock 356 272 568 minecraft:light[level=14]
setblock 356 272 576 minecraft:light[level=14]
setblock 356 272 582 minecraft:oak_leaves[persistent=true]
setblock 356 272 592 minecraft:oak_leaves[persistent=true]
setblock 356 272 597 minecraft:oak_log
fill 356 272 598 359 272 598 minecraft:green_terracotta
fill 357 272 583 357 272 584 minecraft:oak_leaves[persistent=true]
setblock 357 272 590 minecraft:oak_leaves[persistent=true]
setblock 357 272 593 minecraft:oak_leaves[persistent=true]
fill 357 272 597 357 273 597 minecraft:green_terracotta
setblock 358 272 594 minecraft:oak_leaves[persistent=true]
setblock 360 272 558 minecraft:oak_log
setblock 360 272 593 minecraft:oak_leaves[persistent=true]
setblock 360 272 598 minecraft:oak_log
fill 361 272 558 362 273 558 minecraft:green_terracotta
fill 361 272 598 362 273 598 minecraft:green_terracotta
setblock 364 272 560 minecraft:light[level=14]
setblock 364 272 568 minecraft:light[level=14]
setblock 364 272 576 minecraft:light[level=14]
setblock 364 272 584 minecraft:light[level=14]
setblock 364 272 592 minecraft:light[level=14]
setblock 365 272 598 minecraft:oak_log
fill 366 272 598 367 273 598 minecraft:green_terracotta
setblock 368 272 558 minecraft:oak_leaves[persistent=true]
fill 368 272 597 370 272 597 minecraft:green_terracotta
setblock 369 272 558 minecraft:green_terracotta
setblock 369 272 588 minecraft:green_terracotta
setblock 369 272 589 minecraft:oak_log
fill 369 272 590 369 272 593 minecraft:green_terracotta
setblock 369 272 594 minecraft:oak_log
fill 369 272 595 369 273 596 minecraft:green_terracotta
setblock 370 272 558 minecraft:oak_log
fill 370 272 559 370 273 560 minecraft:green_terracotta
setblock 370 272 563 minecraft:oak_log
fill 370 272 564 370 273 564 minecraft:green_terracotta
setblock 370 272 568 minecraft:oak_log
fill 370 272 569 370 273 569 minecraft:green_terracotta
setblock 370 272 573 minecraft:oak_log
fill 370 272 574 370 273 574 minecraft:green_terracotta
setblock 370 272 575 minecraft:oak_leaves[persistent=true]
setblock 370 272 588 minecraft:oak_log
fill 370 272 589 370 273 589 minecraft:green_terracotta
setblock 370 272 593 minecraft:oak_log
fill 370 272 594 370 273 594 minecraft:green_terracotta
fill 370 272 596 370 273 596 minecraft:green_terracotta
setblock 370 272 598 minecraft:oak_log
setblock 330 273 562 minecraft:oak_leaves[persistent=true]
fill 330 273 564 330 273 566 minecraft:green_terracotta
setblock 330 273 567 minecraft:oak_log
fill 330 273 568 330 273 571 minecraft:green_terracotta
setblock 330 273 572 minecraft:oak_log
fill 330 273 573 330 273 576 minecraft:green_terracotta
setblock 330 273 577 minecraft:oak_log
fill 330 273 578 331 273 578 minecraft:green_terracotta
setblock 330 273 582 minecraft:oak_log
setblock 330 273 583 minecraft:green_terracotta
setblock 330 273 587 minecraft:oak_log
setblock 330 273 588 minecraft:green_terracotta
setblock 330 273 592 minecraft:oak_log
setblock 330 273 593 minecraft:green_terracotta
setblock 330 273 596 minecraft:green_terracotta
setblock 330 273 597 minecraft:oak_log
setblock 330 273 598 minecraft:green_terracotta
setblock 331 273 567 minecraft:green_terracotta
setblock 331 273 571 minecraft:oak_log
fill 331 273 572 332 273 572 minecraft:green_terracotta
setblock 331 273 575 minecraft:green_terracotta
setblock 331 273 576 minecraft:oak_log
setblock 331 273 577 minecraft:green_terracotta
fill 331 273 579 331 273 580 minecraft:green_terracotta
setblock 331 273 581 minecraft:oak_log
setblock 331 273 582 minecraft:green_terracotta
setblock 331 273 586 minecraft:oak_log
setblock 331 273 587 minecraft:green_terracotta
setblock 331 273 591 minecraft:oak_log
setblock 331 273 592 minecraft:green_terracotta
setblock 331 273 596 minecraft:oak_log
setblock 331 273 597 minecraft:green_terracotta
fill 332 273 558 333 273 558 minecraft:green_terracotta
setblock 332 273 569 minecraft:green_terracotta
setblock 332 273 570 minecraft:oak_log
setblock 332 273 571 minecraft:green_terracotta
fill 332 273 573 332 273 574 minecraft:green_terracotta
setblock 332 273 575 minecraft:oak_log
setblock 332 273 584 minecraft:green_terracotta
setblock 332 273 585 minecraft:oak_log
setblock 332 273 586 minecraft:green_terracotta
setblock 332 273 590 minecraft:oak_log
setblock 332 273 591 minecraft:green_terracotta
setblock 332 273 595 minecraft:oak_log
setblock 332 273 596 minecraft:green_terracotta
setblock 333 273 589 minecraft:oak_log
setblock 333 273 590 minecraft:green_terracotta
setblock 333 273 594 minecraft:oak_log
fill 333 273 595 334 273 595 minecraft:green_terracotta
setblock 334 273 558 minecraft:oak_log
setblock 334 273 597 minecraft:green_terracotta
setblock 334 273 598 minecraft:oak_log
setblock 335 273 597 minecraft:oak_log
setblock 335 273 598 minecraft:green_terracotta
setblock 336 273 596 minecraft:oak_log
setblock 336 273 597 minecraft:green_terracotta
setblock 337 273 558 minecraft:oak_leaves[persistent=true]
setblock 339 273 598 minecraft:oak_log
setblock 350 273 558 minecraft:green_terracotta
fill 350 273 598 353 273 598 minecraft:green_terracotta
setblock 352 273 559 minecraft:green_terracotta
fill 352 273 597 354 273 597 minecraft:green_terracotta
setblock 353 273 559 minecraft:oak_log
setblock 354 273 558 minecraft:oak_log
setblock 354 273 559 minecraft:green_terracotta
setblock 354 273 598 minecraft:oak_log
setblock 355 273 558 minecraft:green_terracotta
setblock 355 273 597 minecraft:oak_log
fill 355 273 598 358 273 598 minecraft:green_terracotta
setblock 356 273 597 minecraft:green_terracotta
setblock 358 273 559 minecraft:oak_log
fill 358 273 597 359 273 597 minecraft:green_terracotta
setblock 359 273 558 minecraft:oak_log
setblock 359 273 598 minecraft:oak_log
setblock 360 273 558 minecraft:green_terracotta
setblock 360 273 598 minecraft:green_terracotta
setblock 363 273 558 minecraft:green_terracotta
setblock 363 273 598 minecraft:green_terracotta
setblock 364 273 598 minecraft:oak_log
setblock 365 273 598 minecraft:green_terracotta
fill 366 273 597 369 273 597 minecraft:green_terracotta
fill 367 273 558 368 273 558 minecraft:green_terracotta
fill 368 273 591 368 273 593 minecraft:green_terracotta
setblock 368 273 594 minecraft:oak_log
setblock 368 273 595 minecraft:green_terracotta
setblock 368 273 598 minecraft:green_terracotta
setblock 369 273 558 minecraft:oak_log
setblock 369 273 568 minecraft:oak_log
fill 369 273 569 369 273 571 minecraft:green_terracotta
setblock 369 273 587 minecraft:green_terracotta
setblock 369 273 588 minecraft:oak_log
fill 369 273 589 369 273 592 minecraft:green_terracotta
setblock 369 273 593 minecraft:oak_log
setblock 369 273 594 minecraft:green_terracotta
setblock 369 273 598 minecraft:oak_log
setblock 370 273 558 minecraft:green_terracotta
setblock 370 273 562 minecraft:oak_log
setblock 370 273 563 minecraft:green_terracotta
setblock 370 273 567 minecraft:oak_log
setblock 370 273 568 minecraft:green_terracotta
fill 370 273 570 370 273 571 minecraft:green_terracotta
setblock 370 273 572 minecraft:oak_log
setblock 370 273 573 minecraft:green_terracotta
fill 370 273 575 370 273 576 minecraft:green_terracotta
setblock 370 273 584 minecraft:green_terracotta
setblock 370 273 587 minecraft:oak_log
setblock 370 273 588 minecraft:green_terracotta
setblock 370 273 592 minecraft:oak_log
setblock 370 273 593 minecraft:green_terracotta
setblock 370 273 597 minecraft:oak_log
setblock 370 273 598 minecraft:green_terracotta
fill 336 279 580 349 279 580 minecraft:jungle_leaves[persistent=true]
fill 337 279 575 350 279 579 minecraft:jungle_leaves[persistent=true]
fill 337 279 581 350 279 585 minecraft:jungle_leaves[persistent=true]
fill 338 279 573 366 279 574 minecraft:jungle_leaves[persistent=true]
fill 338 279 586 366 279 587 minecraft:jungle_leaves[persistent=true]
fill 339 279 571 365 279 572 minecraft:jungle_leaves[persistent=true]
fill 339 279 588 365 279 589 minecraft:jungle_leaves[persistent=true]
fill 340 279 570 364 279 570 minecraft:jungle_leaves[persistent=true]
fill 340 279 590 364 279 590 minecraft:jungle_leaves[persistent=true]
fill 341 279 569 363 279 569 minecraft:jungle_leaves[persistent=true]
fill 341 279 591 363 279 591 minecraft:jungle_leaves[persistent=true]
fill 342 279 568 362 279 568 minecraft:jungle_leaves[persistent=true]
fill 342 279 592 362 279 592 minecraft:jungle_leaves[persistent=true]
fill 343 279 567 361 279 567 minecraft:jungle_leaves[persistent=true]
fill 343 279 593 361 279 593 minecraft:jungle_leaves[persistent=true]
fill 345 279 566 359 279 566 minecraft:jungle_leaves[persistent=true]
fill 345 279 594 359 279 594 minecraft:jungle_leaves[persistent=true]
fill 347 279 565 357 279 565 minecraft:jungle_leaves[persistent=true]
fill 347 279 595 357 279 595 minecraft:jungle_leaves[persistent=true]
fill 351 279 575 351 279 578 minecraft:jungle_leaves[persistent=true]
fill 351 279 582 351 279 585 minecraft:jungle_leaves[persistent=true]
setblock 352 279 564 minecraft:jungle_leaves[persistent=true]
fill 352 279 575 367 279 577 minecraft:jungle_leaves[persistent=true]
fill 352 279 583 367 279 585 minecraft:jungle_leaves[persistent=true]
setblock 352 279 596 minecraft:jungle_leaves[persistent=true]
fill 353 279 578 367 279 578 minecraft:jungle_leaves[persistent=true]
fill 353 279 582 367 279 582 minecraft:jungle_leaves[persistent=true]
fill 354 279 579 367 279 579 minecraft:jungle_leaves[persistent=true]
fill 354 279 581 367 279 581 minecraft:jungle_leaves[persistent=true]
fill 355 279 580 368 279 580 minecraft:jungle_leaves[persistent=true]
fill 330 280 558 343 280 598 minecraft:oak_leaves[persistent=true]
fill 344 280 558 344 280 575 minecraft:oak_leaves[persistent=true]
fill 344 280 576 344 280 584 minecraft:azalea_leaves[persistent=true]
fill 344 280 585 344 280 598 minecraft:oak_leaves[persistent=true]
fill 345 280 558 345 280 574 minecraft:oak_leaves[persistent=true]
fill 345 280 575 345 280 579 minecraft:azalea_leaves[persistent=true]
fill 345 280 580 348 280 580 minecraft:oak_leaves[persistent=true]
fill 345 280 581 345 280 585 minecraft:azalea_leaves[persistent=true]
fill 345 280 586 345 280 598 minecraft:oak_leaves[persistent=true]
fill 346 280 558 346 280 573 minecraft:oak_leaves[persistent=true]
fill 346 280 574 346 280 576 minecraft:azalea_leaves[persistent=true]
fill 346 280 577 348 280 579 minecraft:oak_leaves[persistent=true]
fill 346 280 581 348 280 583 minecraft:oak_leaves[persistent=true]
fill 346 280 584 346 280 586 minecraft:azalea_leaves[persistent=true]
fill 346 280 587 346 280 598 minecraft:oak_leaves[persistent=true]
fill 347 280 558 347 280 572 minecraft:oak_leaves[persistent=true]
fill 347 280 573 347 280 575 minecraft:azalea_leaves[persistent=true]
fill 347 280 576 357 280 576 minecraft:oak_leaves[persistent=true]
fill 347 280 584 357 280 584 minecraft:oak_leaves[persistent=true]
fill 347 280 585 347 280 587 minecraft:azalea_leaves[persistent=true]
fill 347 280 588 347 280 598 minecraft:oak_leaves[persistent=true]
fill 348 280 558 370 280 571 minecraft:oak_leaves[persistent=true]
fill 348 280 572 348 280 574 minecraft:azalea_leaves[persistent=true]
fill 348 280 575 356 280 575 minecraft:oak_leaves[persistent=true]
fill 348 280 585 356 280 585 minecraft:oak_leaves[persistent=true]
fill 348 280 586 348 280 588 minecraft:azalea_leaves[persistent=true]
fill 348 280 589 370 280 598 minecraft:oak_leaves[persistent=true]
fill 349 280 572 351 280 573 minecraft:azalea_leaves[persistent=true]
fill 349 280 574 355 280 574 minecraft:oak_leaves[persistent=true]
fill 349 280 577 349 280 578 minecraft:oak_leaves[persistent=true]
fill 349 280 579 349 280 581 minecraft:ochre_froglight
fill 349 280 582 349 280 583 minecraft:oak_leaves[persistent=true]
fill 349 280 586 355 280 586 minecraft:oak_leaves[persistent=true]
fill 349 280 587 351 280 588 minecraft:azalea_leaves[persistent=true]
setblock 350 280 577 minecraft:oak_leaves[persistent=true]
fill 350 280 578 350 280 579 minecraft:ochre_froglight
fill 350 280 581 350 280 582 minecraft:ochre_froglight
setblock 350 280 583 minecraft:oak_leaves[persistent=true]
fill 351 280 577 351 280 578 minecraft:ochre_froglight
fill 351 280 582 351 280 583 minecraft:ochre_froglight
fill 352 280 572 356 280 572 minecraft:azalea_leaves[persistent=true]
setblock 352 280 573 minecraft:oak_leaves[persistent=true]
fill 352 280 577 353 280 577 minecraft:ochre_froglight
fill 352 280 583 353 280 583 minecraft:ochre_froglight
setblock 352 280 587 minecraft:oak_leaves[persistent=true]
fill 352 280 588 356 280 588 minecraft:azalea_leaves[persistent=true]
fill 353 280 573 357 280 573 minecraft:azalea_leaves[persistent=true]
fill 353 280 578 354 280 578 minecraft:ochre_froglight
fill 353 280 582 354 280 582 minecraft:ochre_froglight
fill 353 280 587 357 280 587 minecraft:azalea_leaves[persistent=true]
fill 354 280 577 358 280 577 minecraft:oak_leaves[persistent=true]
fill 354 280 579 355 280 579 minecraft:ochre_froglight
fill 354 280 581 355 280 581 minecraft:ochre_froglight
fill 354 280 583 358 280 583 minecraft:oak_leaves[persistent=true]
fill 355 280 578 358 280 578 minecraft:oak_leaves[persistent=true]
setblock 355 280 580 minecraft:ochre_froglight
fill 355 280 582 358 280 582 minecraft:oak_leaves[persistent=true]
fill 356 280 574 358 280 574 minecraft:azalea_leaves[persistent=true]
fill 356 280 579 358 280 581 minecraft:oak_leaves[persistent=true]
fill 356 280 586 358 280 586 minecraft:azalea_leaves[persistent=true]
fill 357 280 572 370 280 572 minecraft:oak_leaves[persistent=true]
fill 357 280 575 359 280 575 minecraft:azalea_leaves[persistent=true]
fill 357 280 585 359 280 585 minecraft:azalea_leaves[persistent=true]
fill 357 280 588 370 280 588 minecraft:oak_leaves[persistent=true]
fill 358 280 573 370 280 573 minecraft:oak_leaves[persistent=true]
fill 358 280 576 360 280 576 minecraft:azalea_leaves[persistent=true]
fill 358 280 584 360 280 584 minecraft:azalea_leaves[persistent=true]
fill 358 280 587 370 280 587 minecraft:oak_leaves[persistent=true]
fill 359 280 574 370 280 574 minecraft:oak_leaves[persistent=true]
fill 359 280 577 360 280 579 minecraft:azalea_leaves[persistent=true]
setblock 359 280 580 minecraft:oak_leaves[persistent=true]
fill 359 280 581 360 280 583 minecraft:azalea_leaves[persistent=true]
fill 359 280 586 370 280 586 minecraft:oak_leaves[persistent=true]
fill 360 280 575 370 280 575 minecraft:oak_leaves[persistent=true]
setblock 360 280 580 minecraft:azalea_leaves[persistent=true]
fill 360 280 585 370 280 585 minecraft:oak_leaves[persistent=true]
fill 361 280 576 370 280 584 minecraft:oak_leaves[persistent=true]
fill 330 284 558 330 284 560 minecraft:green_terracotta
setblock 330 284 561 minecraft:oak_log
fill 330 284 562 330 287 562 minecraft:green_terracotta
setblock 330 284 565 minecraft:oak_leaves[persistent=true]
setblock 330 284 570 minecraft:green_terracotta
setblock 330 284 571 minecraft:oak_log
fill 330 284 572 330 284 575 minecraft:green_terracotta
setblock 330 284 576 minecraft:oak_log
fill 330 284 577 330 284 580 minecraft:green_terracotta
setblock 330 284 581 minecraft:oak_log
fill 330 284 582 330 284 585 minecraft:green_terracotta
setblock 330 284 586 minecraft:oak_log
fill 330 284 587 330 284 590 minecraft:green_terracotta
setblock 330 284 591 minecraft:oak_log
fill 330 284 592 330 284 595 minecraft:green_terracotta
setblock 330 284 596 minecraft:oak_log
fill 330 284 597 330 286 598 minecraft:green_terracotta
fill 331 284 558 332 284 558 minecraft:green_terracotta
fill 331 284 573 331 284 574 minecraft:green_terracotta
setblock 331 284 575 minecraft:oak_log
fill 331 284 576 331 284 579 minecraft:green_terracotta
setblock 331 284 580 minecraft:oak_log
fill 331 284 581 331 284 584 minecraft:green_terracotta
setblock 331 284 585 minecraft:oak_log
fill 331 284 598 332 284 598 minecraft:green_terracotta
fill 332 284 576 332 284 578 minecraft:green_terracotta
setblock 332 284 579 minecraft:oak_log
fill 332 284 580 332 285 582 minecraft:green_terracotta
setblock 333 284 558 minecraft:oak_log
setblock 333 284 598 minecraft:oak_log
setblock 334 284 558 minecraft:oak_leaves[persistent=true]
fill 334 284 584 341 285 587 minecraft:dark_oak_log
fill 335 284 583 341 285 583 minecraft:dark_oak_log
fill 335 284 588 340 285 588 minecraft:dark_oak_log
fill 336 284 582 340 285 582 minecraft:dark_oak_log
fill 337 284 589 339 285 589 minecraft:dark_oak_log
fill 338 284 591 339 284 592 minecraft:glowstone
fill 340 284 558 342 284 558 minecraft:green_terracotta
setblock 341 284 598 minecraft:oak_leaves[persistent=true]
setblock 343 284 558 minecraft:oak_log
fill 343 284 559 346 284 559 minecraft:green_terracotta
setblock 343 284 598 minecraft:oak_log
fill 344 284 558 347 284 558 minecraft:green_terracotta
fill 344 284 598 347 284 598 minecraft:green_terracotta
setblock 345 284 560 minecraft:green_terracotta
setblock 346 284 560 minecraft:oak_log
fill 346 284 597 348 284 597 minecraft:green_terracotta
setblock 347 284 559 minecraft:oak_log
fill 347 284 560 350 284 560 minecraft:green_terracotta
setblock 348 284 558 minecraft:oak_log
fill 348 284 559 351 284 559 minecraft:green_terracotta
setblock 348 284 598 minecraft:oak_log
fill 349 284 558 352 284 558 minecraft:green_terracotta
setblock 349 284 597 minecraft:oak_log
fill 349 284 598 352 284 598 minecraft:green_terracotta
fill 350 284 597 353 284 597 minecraft:green_terracotta
setblock 351 284 560 minecraft:oak_log
setblock 352 284 559 minecraft:oak_log
fill 352 284 560 352 287 560 minecraft:green_terracotta
setblock 353 284 558 minecraft:oak_log
fill 353 284 559 356 284 559 minecraft:green_terracotta
setblock 353 284 598 minecraft:oak_log
fill 354 284 558 357 284 558 minecraft:green_terracotta
fill 354 284 598 357 284 598 minecraft:green_terracotta
setblock 358 284 558 minecraft:oak_log
fill 358 284 584 360 300 587 minecraft:oak_log
setblock 358 284 598 minecraft:oak_log
fill 359 284 558 362 284 558 minecraft:green_terracotta
fill 359 284 598 362 284 598 minecraft:green_terracotta
fill 361 284 585 361 300 586 minecraft:oak_log
fill 361 284 597 363 284 597 minecraft:green_terracotta
setblock 362 284 559 minecraft:oak_log
setblock 363 284 558 minecraft:oak_log
fill 363 284 559 366 284 559 minecraft:green_terracotta
setblock 363 284 598 minecraft:oak_log
fill 364 284 558 367 284 558 minecraft:green_terracotta
setblock 364 284 596 minecraft:green_terracotta
setblock 364 284 597 minecraft:oak_log
fill 364 284 598 367 284 598 minecraft:green_terracotta
setblock 365 284 596 minecraft:oak_log
fill 365 284 597 368 284 597 minecraft:green_terracotta
fill 366 284 596 369 284 596 minecraft:green_terracotta
setblock 367 284 559 minecraft:oak_log
setblock 368 284 558 minecraft:oak_log
fill 368 284 559 370 285 559 minecraft:green_terracotta
setblock 368 284 578 minecraft:oak_log
fill 368 284 579 368 284 582 minecraft:green_terracotta
fill 368 284 594 370 284 595 minecraft:green_terracotta
setblock 368 284 598 minecraft:oak_log
fill 369 284 558 370 286 558 minecraft:green_terracotta
fill 369 284 560 370 284 560 minecraft:green_terracotta
fill 369 284 575 369 284 576 minecraft:green_terracotta
setblock 369 284 577 minecraft:oak_log
fill 369 284 578 369 284 581 minecraft:green_terracotta
setblock 369 284 582 minecraft:oak_log
fill 369 284 583 369 284 586 minecraft:green_terracotta
setblock 369 284 587 minecraft:oak_log
fill 369 284 588 369 284 591 minecraft:green_terracotta
setblock 369 284 592 minecraft:oak_log
fill 369 284 593 370 286 593 minecraft:green_terracotta
setblock 369 284 597 minecraft:oak_log
fill 369 284 598 370 286 598 minecraft:green_terracotta
setblock 370 284 561 minecraft:oak_log
fill 370 284 562 370 287 562 minecraft:green_terracotta
setblock 370 284 566 minecraft:oak_leaves[persistent=true]
fill 370 284 572 370 284 575 minecraft:green_terracotta
setblock 370 284 576 minecraft:oak_log
fill 370 284 577 370 284 580 minecraft:green_terracotta
setblock 370 284 581 minecraft:oak_log
fill 370 284 582 370 284 585 minecraft:green_terracotta
setblock 370 284 586 minecraft:oak_log
fill 370 284 587 370 284 590 minecraft:green_terracotta
setblock 370 284 591 minecraft:oak_log
fill 370 284 592 370 287 592 minecraft:green_terracotta
setblock 370 284 596 minecraft:oak_log
fill 370 284 597 370 287 597 minecraft:green_terracotta
fill 330 285 558 330 285 559 minecraft:green_terracotta
setblock 330 285 560 minecraft:oak_log
fill 330 285 561 330 288 561 minecraft:green_terracotta
fill 330 285 563 330 286 563 minecraft:green_terracotta
setblock 330 285 570 minecraft:oak_log
fill 330 285 571 330 285 574 minecraft:green_terracotta
setblock 330 285 575 minecraft:oak_log
fill 330 285 576 330 285 579 minecraft:green_terracotta
setblock 330 285 580 minecraft:oak_log
fill 330 285 581 330 285 584 minecraft:green_terracotta
setblock 330 285 585 minecraft:oak_log
fill 330 285 586 330 285 589 minecraft:green_terracotta
setblock 330 285 590 minecraft:oak_log
fill 330 285 591 330 285 594 minecraft:green_terracotta
setblock 330 285 595 minecraft:oak_log
fill 330 285 596 330 288 596 minecraft:green_terracotta
setblock 331 285 558 minecraft:green_terracotta
setblock 331 285 573 minecraft:green_terracotta
setblock 331 285 574 minecraft:oak_log
fill 331 285 575 331 285 578 minecraft:green_terracotta
setblock 331 285 579 minecraft:oak_log
fill 331 285 580 331 285 583 minecraft:green_terracotta
setblock 331 285 584 minecraft:oak_log
fill 331 285 585 331 287 586 minecraft:green_terracotta
setblock 331 285 598 minecraft:green_terracotta
setblock 332 285 558 minecraft:oak_log
fill 332 285 576 332 285 577 minecraft:green_terracotta
setblock 332 285 578 minecraft:oak_log
fill 332 285 579 332 288 579 minecraft:green_terracotta
setblock 332 285 598 minecraft:oak_log
fill 333 285 558 333 288 558 minecraft:green_terracotta
setblock 333 285 598 minecraft:green_terracotta
setblock 334 285 583 minecraft:dark_oak_log
setblock 334 285 588 minecraft:dark_oak_log
setblock 335 285 582 minecraft:dark_oak_log
fill 336 285 581 339 285 581 minecraft:dark_oak_log
setblock 336 285 589 minecraft:dark_oak_log
fill 339 285 558 341 285 558 minecraft:green_terracotta
setblock 340 285 589 minecraft:dark_oak_log
setblock 341 285 588 minecraft:dark_oak_log
setblock 342 285 558 minecraft:oak_log
fill 342 285 559 345 285 559 minecraft:green_terracotta
fill 342 285 584 342 285 586 minecraft:dark_oak_log
setblock 342 285 598 minecraft:oak_log
fill 343 285 558 346 285 558 minecraft:green_terracotta
fill 343 285 598 346 285 598 minecraft:green_terracotta
setblock 344 285 560 minecraft:green_terracotta
setblock 345 285 560 minecraft:oak_log
setblock 346 285 559 minecraft:oak_log
fill 346 285 560 349 285 560 minecraft:green_terracotta
fill 346 285 597 347 285 597 minecraft:green_terracotta
setblock 347 285 558 minecraft:oak_log
fill 347 285 559 350 285 559 minecraft:green_terracotta
setblock 347 285 598 minecraft:oak_log
fill 348 285 558 351 285 558 minecraft:green_terracotta
setblock 348 285 561 minecraft:green_terracotta
setblock 348 285 597 minecraft:oak_log
fill 348 285 598 351 285 598 minecraft:green_terracotta
fill 349 285 597 352 285 597 minecraft:green_terracotta
setblock 350 285 560 minecraft:oak_log
setblock 351 285 559 minecraft:oak_log
fill 351 285 560 351 288 560 minecraft:green_terracotta
setblock 352 285 558 minecraft:oak_log
fill 352 285 559 355 285 559 minecraft:green_terracotta
setblock 352 285 598 minecraft:oak_log
fill 353 285 558 356 285 558 minecraft:green_terracotta
fill 353 285 560 353 286 560 minecraft:green_terracotta
setblock 353 285 597 minecraft:oak_log
fill 353 285 598 356 285 598 minecraft:green_terracotta
setblock 356 285 559 minecraft:oak_log
setblock 357 285 558 minecraft:oak_log
fill 357 285 559 360 285 559 minecraft:green_terracotta
fill 357 285 584 357 286 587 minecraft:dark_oak_log
setblock 357 285 598 minecraft:oak_log
fill 358 285 558 361 285 558 minecraft:green_terracotta
fill 358 285 583 360 286 583 minecraft:dark_oak_log
fill 358 285 598 361 285 598 minecraft:green_terracotta
fill 359 285 588 360 286 588 minecraft:dark_oak_log
fill 360 285 597 362 285 597 minecraft:green_terracotta
setblock 361 285 559 minecraft:oak_log
fill 361 285 584 361 286 584 minecraft:dark_oak_log
fill 361 285 587 361 286 587 minecraft:dark_oak_log
setblock 362 285 558 minecraft:oak_log
fill 362 285 559 365 285 559 minecraft:green_terracotta
setblock 362 285 598 minecraft:oak_log
fill 363 285 558 366 285 558 minecraft:green_terracotta
setblock 363 285 597 minecraft:oak_log
fill 363 285 598 366 285 598 minecraft:green_terracotta
setblock 364 285 596 minecraft:oak_log
fill 364 285 597 367 285 597 minecraft:green_terracotta
fill 365 285 596 368 285 596 minecraft:green_terracotta
setblock 366 285 559 minecraft:oak_log
setblock 367 285 558 minecraft:oak_log
fill 367 285 559 367 288 559 minecraft:green_terracotta
setblock 367 285 598 minecraft:oak_log
fill 368 285 558 368 288 558 minecraft:green_terracotta
setblock 368 285 577 minecraft:oak_log
fill 368 285 578 368 285 581 minecraft:green_terracotta
setblock 368 285 582 minecraft:oak_log
fill 368 285 583 370 285 584 minecraft:green_terracotta
fill 368 285 594 369 285 595 minecraft:green_terracotta
setblock 368 285 597 minecraft:oak_log
fill 368 285 598 368 288 598 minecraft:green_terracotta
setblock 369 285 560 minecraft:green_terracotta
setblock 369 285 561 minecraft:oak_log
setblock 369 285 575 minecraft:green_terracotta
setblock 369 285 576 minecraft:oak_log
fill 369 285 577 369 285 580 minecraft:green_terracotta
setblock 369 285 581 minecraft:oak_log
fill 369 285 582 370 287 582 minecraft:green_terracotta
setblock 369 285 585 minecraft:green_terracotta
setblock 369 285 586 minecraft:oak_log
fill 369 285 587 369 285 590 minecraft:green_terracotta
setblock 369 285 591 minecraft:oak_log
fill 369 285 592 369 288 592 minecraft:green_terracotta
setblock 369 285 596 minecraft:oak_log
fill 369 285 597 369 288 597 minecraft:green_terracotta
setblock 370 285 560 minecraft:oak_log
fill 370 285 561 370 288 561 minecraft:green_terracotta
fill 370 285 563 370 286 563 minecraft:green_terracotta
fill 370 285 573 370 285 574 minecraft:green_terracotta
setblock 370 285 575 minecraft:oak_log
fill 370 285 576 370 285 579 minecraft:green_terracotta
setblock 370 285 580 minecraft:oak_log
fill 370 285 581 370 288 581 minecraft:green_terracotta
setblock 370 285 585 minecraft:oak_log
fill 370 285 586 370 285 589 minecraft:green_terracotta
setblock 370 285 590 minecraft:oak_log
fill 370 285 591 370 288 591 minecraft:green_terracotta
setblock 370 285 594 minecraft:green_terracotta
setblock 370 285 595 minecraft:oak_log
fill 370 285 596 370 288 596 minecraft:green_terracotta
setblock 330 286 558 minecraft:green_terracotta
setblock 330 286 559 minecraft:oak_log
fill 330 286 560 330 289 560 minecraft:green_terracotta
setblock 330 286 564 minecraft:oak_log
fill 330 286 565 330 288 566 minecraft:green_terracotta
setblock 330 286 569 minecraft:oak_log
fill 330 286 570 330 286 573 minecraft:green_terracotta
setblock 330 286 574 minecraft:oak_log
fill 330 286 575 330 286 578 minecraft:green_terracotta
setblock 330 286 579 minecraft:oak_log
fill 330 286 580 330 286 583 minecraft:green_terracotta
setblock 330 286 584 minecraft:oak_log
fill 330 286 585 330 286 588 minecraft:green_terracotta
setblock 330 286 589 minecraft:oak_log
fill 330 286 590 330 286 593 minecraft:green_terracotta
setblock 330 286 594 minecraft:oak_log
fill 330 286 595 330 288 595 minecraft:green_terracotta
setblock 331 286 558 minecraft:oak_log
setblock 331 286 573 minecraft:oak_log
fill 331 286 574 331 286 577 minecraft:green_terracotta
setblock 331 286 578 minecraft:oak_log
fill 331 286 579 331 286 582 minecraft:green_terracotta
setblock 331 286 583 minecraft:oak_log
fill 331 286 584 331 289 584 minecraft:green_terracotta
setblock 331 286 598 minecraft:oak_log
fill 332 286 558 332 289 558 minecraft:green_terracotta
setblock 332 286 576 minecraft:green_terracotta
setblock 332 286 577 minecraft:oak_log
fill 332 286 578 332 289 578 minecraft:green_terracotta
fill 332 286 580 332 286 581 minecraft:green_terracotta
setblock 332 286 582 minecraft:oak_log
fill 332 286 583 332 289 583 minecraft:green_terracotta
fill 332 286 598 332 287 598 minecraft:green_terracotta
fill 334 286 558 335 286 558 minecraft:green_terracotta
setblock 334 286 598 minecraft:oak_leaves[persistent=true]
fill 337 286 558 340 286 558 minecraft:green_terracotta
fill 338 286 585 338 288 585 minecraft:oak_log
setblock 340 286 559 minecraft:oak_log
setblock 341 286 558 minecraft:oak_log
fill 341 286 559 344 286 559 minecraft:green_terracotta
setblock 341 286 598 minecraft:oak_log
fill 342 286 558 345 286 558 minecraft:green_terracotta
fill 342 286 560 343 286 560 minecraft:green_terracotta
fill 342 286 598 345 286 598 minecraft:green_terracotta
setblock 344 286 560 minecraft:oak_log
setblock 345 286 559 minecraft:oak_log
fill 345 286 560 347 286 561 minecraft:green_terracotta
fill 345 286 597 346 286 597 minecraft:green_terracotta
setblock 346 286 558 minecraft:oak_log
fill 346 286 559 349 286 559 minecraft:green_terracotta
setblock 346 286 598 minecraft:oak_log
fill 347 286 558 350 286 558 minecraft:green_terracotta
setblock 347 286 597 minecraft:oak_log
fill 347 286 598 350 286 598 minecraft:green_terracotta
setblock 348 286 560 minecraft:green_terracotta
setblock 348 286 561 minecraft:oak_log
fill 348 286 597 351 286 597 minecraft:green_terracotta
setblock 349 286 560 minecraft:oak_log
fill 349 286 561 350 288 561 minecraft:green_terracotta
setblock 350 286 559 minecraft:oak_log
fill 350 286 560 350 289 560 minecraft:green_terracotta
setblock 351 286 558 minecraft:oak_log
fill 351 286 559 354 286 559 minecraft:green_terracotta
setblock 351 286 598 minecraft:oak_log
fill 352 286 558 355 286 558 minecraft:green_terracotta
setblock 352 286 597 minecraft:oak_log
fill 352 286 598 355 286 598 minecraft:green_terracotta
setblock 355 286 559 minecraft:oak_log
setblock 356 286 558 minecraft:oak_log
fill 356 286 559 359 286 559 minecraft:green_terracotta
fill 356 286 584 356 286 587 minecraft:dark_oak_log
setblock 356 286 598 minecraft:oak_log
fill 357 286 558 360 286 558 minecraft:green_terracotta
setblock 357 286 583 minecraft:dark_oak_log
fill 357 286 588 358 286 588 minecraft:dark_oak_log
fill 357 286 598 360 286 598 minecraft:green_terracotta
fill 358 286 582 360 286 582 minecraft:dark_oak_log
setblock 359 286 589 minecraft:dark_oak_log
fill 359 286 597 361 286 597 minecraft:green_terracotta
setblock 360 286 559 minecraft:oak_log
setblock 361 286 558 minecraft:oak_log
fill 361 286 559 364 286 559 minecraft:green_terracotta
setblock 361 286 583 minecraft:dark_oak_log
setblock 361 286 588 minecraft:dark_oak_log
setblock 361 286 598 minecraft:oak_log
fill 362 286 558 365 286 558 minecraft:green_terracotta
fill 362 286 584 362 286 587 minecraft:dark_oak_log
setblock 362 286 597 minecraft:oak_log
fill 362 286 598 365 286 598 minecraft:green_terracotta
setblock 363 286 596 minecraft:oak_log
fill 363 286 597 366 286 597 minecraft:green_terracotta
setblock 364 286 560 minecraft:oak_log
fill 364 286 596 367 286 596 minecraft:green_terracotta
setblock 365 286 559 minecraft:oak_log
fill 365 286 560 367 287 560 minecraft:green_terracotta
setblock 366 286 558 minecraft:oak_log
fill 366 286 559 366 289 559 minecraft:green_terracotta
setblock 366 286 598 minecraft:oak_log
fill 367 286 558 367 289 558 minecraft:green_terracotta
setblock 367 286 597 minecraft:oak_log
fill 367 286 598 367 289 598 minecraft:green_terracotta
fill 368 286 559 369 286 559 minecraft:green_terracotta
fill 368 286 577 368 286 580 minecraft:green_terracotta
setblock 368 286 581 minecraft:oak_log
fill 368 286 582 368 286 585 minecraft:green_terracotta
setblock 368 286 586 minecraft:oak_log
fill 368 286 587 370 287 587 minecraft:green_terracotta
fill 368 286 594 368 286 595 minecraft:green_terracotta
setblock 368 286 596 minecraft:oak_log
fill 368 286 597 368 289 597 minecraft:green_terracotta
setblock 369 286 560 minecraft:oak_log
fill 369 286 561 369 288 562 minecraft:green_terracotta
setblock 369 286 575 minecraft:oak_log
fill 369 286 576 369 286 579 minecraft:green_terracotta
setblock 369 286 580 minecraft:oak_log
fill 369 286 581 369 289 581 minecraft:green_terracotta
fill 369 286 583 369 286 584 minecraft:green_terracotta
setblock 369 286 585 minecraft:oak_log
fill 369 286 586 370 288 586 minecraft:green_terracotta
fill 369 286 588 369 286 589 minecraft:green_terracotta
setblock 369 286 590 minecraft:oak_log
fill 369 286 591 369 289 591 minecraft:green_terracotta
setblock 369 286 594 minecraft:green_terracotta
setblock 369 286 595 minecraft:oak_log
fill 369 286 596 369 289 596 minecraft:green_terracotta
setblock 370 286 559 minecraft:oak_log
fill 370 286 560 370 289 560 minecraft:green_terracotta
setblock 370 286 564 minecraft:oak_log
setblock 370 286 573 minecraft:green_terracotta
setblock 370 286 574 minecraft:oak_log
fill 370 286 575 370 286 578 minecraft:green_terracotta
setblock 370 286 579 minecraft:oak_log
fill 370 286 580 370 289 580 minecraft:green_terracotta
setblock 370 286 583 minecraft:green_terracotta
setblock 370 286 584 minecraft:oak_log
fill 370 286 585 370 289 585 minecraft:green_terracotta
setblock 370 286 588 minecraft:green_terracotta
setblock 370 286 589 minecraft:oak_log
fill 370 286 590 370 289 590 minecraft:green_terracotta
setblock 370 286 594 minecraft:oak_log
fill 370 286 595 370 289 595 minecraft:green_terracotta
setblock 330 287 558 minecraft:oak_log
fill 330 287 559 331 288 559 minecraft:green_terracotta
setblock 330 287 563 minecraft:oak_log
fill 330 287 564 330 290 564 minecraft:green_terracotta
setblock 330 287 567 minecraft:green_terracotta
setblock 330 287 568 minecraft:oak_log
fill 330 287 569 330 287 572 minecraft:green_terracotta
setblock 330 287 573 minecraft:oak_log
fill 330 287 574 330 287 577 minecraft:green_terracotta
setblock 330 287 578 minecraft:oak_log
fill 330 287 579 330 287 582 minecraft:green_terracotta
setblock 330 287 583 minecraft:oak_log
fill 330 287 584 330 287 587 minecraft:green_terracotta
setblock 330 287 588 minecraft:oak_log
fill 330 287 589 330 287 592 minecraft:green_terracotta
setblock 330 287 593 minecraft:oak_log
setblock 330 287 594 minecraft:green_terracotta
setblock 330 287 597 minecraft:green_terracotta
setblock 330 287 598 minecraft:oak_log
fill 331 287 558 331 290 558 minecraft:green_terracotta
fill 331 287 560 331 288 560 minecraft:green_terracotta
fill 331 287 573 331 287 576 minecraft:green_terracotta
setblock 331 287 577 minecraft:oak_log
fill 331 287 578 331 287 581 minecraft:green_terracotta
setblock 331 287 582 minecraft:oak_log
fill 331 287 583 331 290 583 minecraft:green_terracotta
setblock 331 287 587 minecraft:oak_log
fill 331 287 598 331 288 598 minecraft:green_terracotta
fill 332 287 577 332 288 577 minecraft:green_terracotta
setblock 332 287 580 minecraft:green_terracotta
setblock 332 287 581 minecraft:oak_log
fill 332 287 582 332 290 582 minecraft:green_terracotta
setblock 334 287 558 minecraft:green_terracotta
setblock 335 287 558 minecraft:oak_log
fill 336 287 558 339 287 558 minecraft:green_terracotta
setblock 339 287 559 minecraft:oak_log
setblock 340 287 558 minecraft:oak_log
fill 340 287 559 343 287 559 minecraft:green_terracotta
setblock 340 287 598 minecraft:oak_leaves[persistent=true]
fill 341 287 558 344 287 558 minecraft:green_terracotta
fill 341 287 560 342 287 560 minecraft:green_terracotta
fill 341 287 598 344 287 598 minecraft:green_terracotta
setblock 343 287 560 minecraft:oak_log
fill 343 287 561 346 287 561 minecraft:green_terracotta
setblock 344 287 559 minecraft:oak_log
fill 344 287 560 347 287 560 minecraft:green_terracotta
fill 344 287 597 345 287 597 minecraft:green_terracotta
setblock 345 287 558 minecraft:oak_log
fill 345 287 559 348 287 559 minecraft:green_terracotta
setblock 345 287 598 minecraft:oak_log
fill 346 287 558 349 287 558 minecraft:green_terracotta
setblock 346 287 597 minecraft:oak_log
fill 346 287 598 349 287 598 minecraft:green_terracotta
setblock 347 287 561 minecraft:oak_log
fill 347 287 597 350 287 597 minecraft:green_terracotta
setblock 348 287 560 minecraft:oak_log
fill 348 287 561 348 290 561 minecraft:green_terracotta
setblock 349 287 559 minecraft:oak_log
fill 349 287 560 349 290 560 minecraft:green_terracotta
setblock 350 287 558 minecraft:oak_log
fill 350 287 559 353 287 559 minecraft:green_terracotta
setblock 350 287 598 minecraft:oak_log
fill 351 287 558 354 287 558 minecraft:green_terracotta
setblock 351 287 597 minecraft:oak_log
fill 351 287 598 354 287 598 minecraft:green_terracotta
setblock 352 287 597 minecraft:green_terracotta
setblock 353 287 560 minecraft:oak_log
setblock 354 287 559 minecraft:oak_log
fill 354 287 560 354 289 560 minecraft:green_terracotta
setblock 355 287 558 minecraft:oak_log
fill 355 287 559 358 287 559 minecraft:green_terracotta
setblock 355 287 598 minecraft:oak_log
fill 356 287 558 359 287 558 minecraft:green_terracotta
fill 356 287 598 359 287 598 minecraft:green_terracotta
setblock 359 287 559 minecraft:oak_log
fill 359 287 597 360 287 597 minecraft:green_terracotta
setblock 360 287 558 minecraft:oak_log
fill 360 287 559 363 287 559 minecraft:green_terracotta
setblock 360 287 598 minecraft:oak_log
fill 361 287 558 364 287 558 minecraft:green_terracotta
setblock 361 287 597 minecraft:oak_log
fill 361 287 598 364 287 598 minecraft:green_terracotta
setblock 362 287 560 minecraft:green_terracotta
fill 362 287 597 365 287 597 minecraft:green_terracotta
setblock 363 287 560 minecraft:oak_log
fill 363 287 596 366 287 596 minecraft:green_terracotta
setblock 364 287 559 minecraft:oak_log
fill 364 287 560 364 290 560 minecraft:green_terracotta
setblock 365 287 558 minecraft:oak_log
fill 365 287 559 365 290 559 minecraft:green_terracotta
setblock 365 287 598 minecraft:oak_log
fill 366 287 558 366 290 558 minecraft:green_terracotta
setblock 366 287 597 minecraft:oak_log
fill 366 287 598 366 290 598 minecraft:green_terracotta
setblock 367 287 580 minecraft:green_terracotta
setblock 367 287 581 minecraft:oak_log
fill 367 287 582 368 287 584 minecraft:green_terracotta
setblock 367 287 596 minecraft:oak_log
fill 367 287 597 367 290 597 minecraft:green_terracotta
setblock 368 287 559 minecraft:green_terracotta
setblock 368 287 560 minecraft:oak_log
fill 368 287 577 368 287 579 minecraft:green_terracotta
setblock 368 287 580 minecraft:oak_log
fill 368 287 581 368 290 581 minecraft:green_terracotta
setblock 368 287 585 minecraft:oak_log
fill 368 287 586 368 290 586 minecraft:green_terracotta
fill 368 287 588 368 287 589 minecraft:green_terracotta
setblock 368 287 594 minecraft:green_terracotta
setblock 368 287 595 minecraft:oak_log
fill 368 287 596 368 288 596 minecraft:green_terracotta
setblock 369 287 558 minecraft:green_terracotta
setblock 369 287 559 minecraft:oak_log
fill 369 287 560 369 290 560 minecraft:green_terracotta
fill 369 287 575 369 287 578 minecraft:green_terracotta
setblock 369 287 579 minecraft:oak_log
fill 369 287 580 369 290 580 minecraft:green_terracotta
setblock 369 287 583 minecraft:green_terracotta
setblock 369 287 584 minecraft:oak_log
fill 369 287 585 369 290 585 minecraft:green_terracotta
setblock 369 287 588 minecraft:green_terracotta
setblock 369 287 589 minecraft:oak_log
fill 369 287 590 369 290 590 minecraft:green_terracotta
setblock 369 287 593 minecraft:green_terracotta
setblock 369 287 594 minecraft:oak_log
fill 369 287 595 369 290 595 minecraft:green_terracotta
setblock 369 287 598 minecraft:green_terracotta
setblock 370 287 558 minecraft:oak_log
fill 370 287 559 370 290 559 minecraft:green_terracotta
setblock 370 287 563 minecraft:oak_log
fill 370 287 564 370 289 565 minecraft:green_terracotta
setblock 370 287 567 minecraft:oak_leaves[persistent=true]
setblock 370 287 573 minecraft:oak_log
fill 370 287 574 370 287 577 minecraft:green_terracotta
setblock 370 287 578 minecraft:oak_log
fill 370 287 579 370 290 579 minecraft:green_terracotta
setblock 370 287 583 minecraft:oak_log
fill 370 287 584 370 290 584 minecraft:green_terracotta
setblock 370 287 588 minecraft:oak_log
fill 370 287 589 370 290 589 minecraft:green_terracotta
setblock 370 287 593 minecraft:oak_log
fill 370 287 594 370 290 594 minecraft:green_terracotta
setblock 370 287 598 minecraft:oak_log
fill 330 288 558 330 291 558 minecraft:green_terracotta
setblock 330 288 562 minecraft:oak_log
fill 330 288 563 330 291 563 minecraft:green_terracotta
setblock 330 288 567 minecraft:oak_log
fill 330 288 568 330 288 571 minecraft:green_terracotta
setblock 330 288 572 minecraft:oak_log
fill 330 288 573 330 288 576 minecraft:green_terracotta
setblock 330 288 577 minecraft:oak_log
fill 330 288 578 330 288 581 minecraft:green_terracotta
setblock 330 288 582 minecraft:oak_log
fill 330 288 583 330 288 586 minecraft:green_terracotta
setblock 330 288 587 minecraft:oak_log
fill 330 288 588 330 288 591 minecraft:green_terracotta
setblock 330 288 592 minecraft:oak_log
setblock 330 288 597 minecraft:oak_log
fill 330 288 598 330 289 598 minecraft:green_terracotta
setblock 331 288 561 minecraft:oak_log
fill 331 288 562 331 291 562 minecraft:green_terracotta
fill 331 288 574 331 288 575 minecraft:green_terracotta
setblock 331 288 576 minecraft:oak_log
fill 331 288 577 331 288 580 minecraft:green_terracotta
setblock 331 288 581 minecraft:oak_log
fill 331 288 582 331 291 582 minecraft:green_terracotta
setblock 331 288 585 minecraft:green_terracotta
setblock 331 288 586 minecraft:oak_log
fill 331 288 587 331 291 587 minecraft:green_terracotta
setblock 332 288 560 minecraft:light[level=14]
setblock 332 288 568 minecraft:light[level=14]
setblock 332 288 576 minecraft:light[level=14]
setblock 332 288 580 minecraft:oak_log
fill 332 288 581 332 290 581 minecraft:green_terracotta
setblock 332 288 584 minecraft:green_terracotta
setblock 332 288 592 minecraft:light[level=14]
setblock 334 288 558 minecraft:oak_log
fill 335 288 558 338 288 558 minecraft:green_terracotta
setblock 338 288 559 minecraft:oak_log
setblock 339 288 558 minecraft:oak_log
fill 339 288 559 342 288 559 minecraft:green_terracotta
fill 340 288 558 343 288 558 minecraft:green_terracotta
fill 340 288 560 341 288 560 minecraft:green_terracotta
setblock 340 288 568 minecraft:light[level=14]
setblock 340 288 576 minecraft:light[level=14]
setblock 340 288 584 minecraft:light[level=14]
setblock 340 288 592 minecraft:light[level=14]
fill 340 288 598 343 288 598 minecraft:green_terracotta
setblock 342 288 560 minecraft:oak_log
fill 342 288 561 345 288 561 minecraft:green_terracotta
setblock 343 288 559 minecraft:oak_log
fill 343 288 560 346 288 560 minecraft:green_terracotta
setblock 344 288 558 minecraft:oak_log
fill 344 288 559 347 288 559 minecraft:green_terracotta
setblock 344 288 597 minecraft:green_terracotta
setblock 344 288 598 minecraft:oak_log
fill 345 288 558 348 288 558 minecraft:green_terracotta
setblock 345 288 597 minecraft:oak_log
fill 345 288 598 348 288 598 minecraft:green_terracotta
setblock 346 288 561 minecraft:oak_log
fill 346 288 562 346 291 562 minecraft:green_terracotta
fill 346 288 597 349 288 597 minecraft:green_terracotta
setblock 347 288 560 minecraft:oak_log
fill 347 288 561 347 291 561 minecraft:green_terracotta
setblock 348 288 559 minecraft:oak_log
fill 348 288 560 348 291 560 minecraft:green_terracotta
setblock 348 288 568 minecraft:light[level=14]
setblock 348 288 576 minecraft:light[level=14]
setblock 348 288 584 minecraft:light[level=14]
setblock 348 288 592 minecraft:light[level=14]
setblock 349 288 558 minecraft:oak_log
fill 349 288 559 352 288 559 minecraft:green_terracotta
setblock 349 288 598 minecraft:oak_log
fill 350 288 558 353 288 558 minecraft:green_terracotta
setblock 350 288 597 minecraft:oak_log
fill 350 288 598 353 288 598 minecraft:green_terracotta
setblock 351 288 597 minecraft:green_terracotta
setblock 352 288 560 minecraft:oak_log
setblock 353 288 559 minecraft:oak_log
fill 353 288 560 353 290 560 minecraft:green_terracotta
setblock 354 288 558 minecraft:oak_log
fill 354 288 559 357 288 559 minecraft:green_terracotta
setblock 354 288 598 minecraft:oak_log
fill 355 288 558 358 288 558 minecraft:green_terracotta
fill 355 288 598 358 288 598 minecraft:green_terracotta
setblock 356 288 560 minecraft:light[level=14]
setblock 356 288 568 minecraft:light[level=14]
setblock 356 288 576 minecraft:light[level=14]
setblock 356 288 584 minecraft:light[level=14]
setblock 356 288 592 minecraft:light[level=14]
setblock 358 288 559 minecraft:oak_log
fill 358 288 597 359 288 597 minecraft:green_terracotta
setblock 359 288 558 minecraft:oak_log
fill 359 288 559 362 288 559 minecraft:green_terracotta
setblock 359 288 598 minecraft:oak_log
fill 360 288 558 363 288 558 minecraft:green_terracotta
fill 360 288 560 361 288 560 minecraft:green_terracotta
setblock 360 288 597 minecraft:oak_log
fill 360 288 598 363 288 598 minecraft:green_terracotta
fill 361 288 597 364 288 597 minecraft:green_terracotta
setblock 362 288 560 minecraft:oak_log
fill 362 288 596 365 288 596 minecraft:green_terracotta
setblock 363 288 559 minecraft:oak_log
fill 363 288 560 363 291 560 minecraft:green_terracotta
setblock 364 288 558 minecraft:oak_log
fill 364 288 559 364 291 559 minecraft:green_terracotta
setblock 364 288 568 minecraft:light[level=14]
setblock 364 288 576 minecraft:light[level=14]
setblock 364 288 584 minecraft:light[level=14]
setblock 364 288 592 minecraft:light[level=14]
setblock 364 288 598 minecraft:oak_log
fill 365 288 558 365 291 558 minecraft:green_terracotta
fill 365 288 560 366 288 560 minecraft:green_terracotta
setblock 365 288 597 minecraft:oak_log
fill 365 288 598 365 291 598 minecraft:green_terracotta
setblock 366 288 596 minecraft:oak_log
fill 366 288 597 366 291 597 minecraft:green_terracotta
setblock 367 288 560 minecraft:oak_log
setblock 367 288 579 minecraft:green_terracotta
setblock 367 288 580 minecraft:oak_log
fill 367 288 581 367 288 584 minecraft:green_terracotta
setblock 367 288 585 minecraft:oak_log
fill 367 288 586 367 291 586 minecraft:green_terracotta
fill 367 288 596 367 289 596 minecraft:green_terracotta
setblock 368 288 559 minecraft:oak_log
fill 368 288 560 368 289 561 minecraft:green_terracotta
fill 368 288 577 368 288 578 minecraft:green_terracotta
setblock 368 288 579 minecraft:oak_log
fill 368 288 580 368 291 580 minecraft:green_terracotta
fill 368 288 582 368 288 583 minecraft:green_terracotta
setblock 368 288 584 minecraft:oak_log
fill 368 288 585 368 291 585 minecraft:green_terracotta
fill 368 288 587 368 288 588 minecraft:green_terracotta
setblock 368 288 589 minecraft:oak_log
fill 368 288 590 368 291 590 minecraft:green_terracotta
setblock 368 288 595 minecraft:green_terracotta
setblock 369 288 558 minecraft:oak_log
fill 369 288 559 369 291 559 minecraft:green_terracotta
setblock 369 288 563 minecraft:oak_log
fill 369 288 575 369 288 577 minecraft:green_terracotta
setblock 369 288 578 minecraft:oak_log
fill 369 288 579 369 291 579 minecraft:green_terracotta
setblock 369 288 582 minecraft:green_terracotta
setblock 369 288 583 minecraft:oak_log
fill 369 288 584 369 291 584 minecraft:green_terracotta
setblock 369 288 587 minecraft:green_terracotta
setblock 369 288 588 minecraft:oak_log
fill 369 288 589 369 291 589 minecraft:green_terracotta
setblock 369 288 593 minecraft:oak_log
fill 369 288 594 369 290 594 minecraft:green_terracotta
setblock 369 288 598 minecraft:oak_log
fill 370 288 558 370 291 558 minecraft:green_terracotta
setblock 370 288 562 minecraft:oak_log
fill 370 288 563 370 291 563 minecraft:green_terracotta
fill 370 288 573 370 288 576 minecraft:green_terracotta
setblock 370 288 577 minecraft:oak_log
fill 370 288 578 370 291 578 minecraft:green_terracotta
setblock 370 288 582 minecraft:oak_log
fill 370 288 583 370 291 583 minecraft:green_terracotta
setblock 370 288 587 minecraft:oak_log
fill 370 288 588 370 291 588 minecraft:green_terracotta
setblock 370 288 592 minecraft:oak_log
fill 370 288 593 370 291 593 minecraft:green_terracotta
setblock 370 288 597 minecraft:oak_log
fill 370 288 598 370 291 598 minecraft:green_terracotta
fill 330 289 559 330 290 559 minecraft:green_terracotta
setblock 330 289 561 minecraft:oak_log
fill 330 289 562 330 292 562 minecraft:green_terracotta
setblock 330 289 565 minecraft:green_terracotta
setblock 330 289 566 minecraft:oak_log
fill 330 289 567 330 289 570 minecraft:green_terracotta
setblock 330 289 571 minecraft:oak_log
fill 330 289 572 330 289 575 minecraft:green_terracotta
setblock 330 289 576 minecraft:oak_log
fill 330 289 577 330 289 580 minecraft:green_terracotta
setblock 330 289 581 minecraft:oak_log
fill 330 289 582 330 289 585 minecraft:green_terracotta
setblock 330 289 586 minecraft:oak_log
fill 330 289 587 330 289 590 minecraft:green_terracotta
setblock 330 289 591 minecraft:oak_log
setblock 330 289 597 minecraft:green_terracotta
setblock 331 289 560 minecraft:oak_log
fill 331 289 561 331 291 561 minecraft:green_terracotta
fill 331 289 563 331 289 564 minecraft:green_terracotta
setblock 331 289 574 minecraft:green_terracotta
setblock 331 289 575 minecraft:oak_log
fill 331 289 576 331 289 579 minecraft:green_terracotta
setblock 331 289 580 minecraft:oak_log
fill 331 289 581 331 292 581 minecraft:green_terracotta
setblock 331 289 585 minecraft:oak_log
fill 331 289 586 331 292 586 minecraft:green_terracotta
setblock 332 289 579 minecraft:oak_log
fill 332 289 580 332 290 580 minecraft:green_terracotta
setblock 332 289 584 minecraft:oak_log
setblock 333 289 558 minecraft:oak_log
setblock 333 289 598 minecraft:oak_leaves[persistent=true]
fill 334 289 558 337 289 558 minecraft:green_terracotta
fill 336 289 585 339 291 586 minecraft:oak_leaves[persistent=true]
setblock 337 289 559 minecraft:oak_log
fill 337 289 584 339 291 584 minecraft:oak_leaves[persistent=true]
fill 337 289 587 338 291 587 minecraft:oak_leaves[persistent=true]
setblock 338 289 558 minecraft:oak_log
fill 338 289 559 341 289 559 minecraft:green_terracotta
fill 339 289 558 342 289 558 minecraft:green_terracotta
fill 339 289 560 340 289 560 minecraft:green_terracotta
fill 340 289 598 342 289 598 minecraft:green_terracotta
setblock 341 289 560 minecraft:oak_log
fill 341 289 561 344 289 561 minecraft:green_terracotta
setblock 342 289 559 minecraft:oak_log
fill 342 289 560 345 289 560 minecraft:green_terracotta
setblock 343 289 558 minecraft:oak_log
fill 343 289 559 346 289 559 minecraft:green_terracotta
setblock 343 289 598 minecraft:oak_log
fill 344 289 558 347 289 558 minecraft:green_terracotta
setblock 344 289 562 minecraft:oak_log
setblock 344 289 597 minecraft:oak_log
fill 344 289 598 347 289 598 minecraft:green_terracotta
setblock 345 289 561 minecraft:oak_log
fill 345 289 562 345 292 562 minecraft:green_terracotta
fill 345 289 597 348 289 597 minecraft:green_terracotta
setblock 346 289 560 minecraft:oak_log
fill 346 289 561 346 292 561 minecraft:green_terracotta
setblock 347 289 559 minecraft:oak_log
fill 347 289 560 347 292 560 minecraft:green_terracotta
fill 347 289 562 347 290 562 minecraft:green_terracotta
setblock 348 289 558 minecraft:oak_log
fill 348 289 559 351 289 559 minecraft:green_terracotta
setblock 348 289 598 minecraft:oak_log
fill 349 289 558 352 289 558 minecraft:green_terracotta
setblock 349 289 561 minecraft:green_terracotta
setblock 349 289 597 minecraft:oak_log
fill 349 289 598 352 289 598 minecraft:green_terracotta
setblock 350 289 561 minecraft:oak_log
setblock 350 289 597 minecraft:green_terracotta
setblock 351 289 560 minecraft:oak_log
setblock 352 289 559 minecraft:oak_log
fill 352 289 560 352 291 560 minecraft:green_terracotta
setblock 353 289 558 minecraft:oak_log
fill 353 289 559 356 289 559 minecraft:green_terracotta
setblock 353 289 598 minecraft:oak_log
fill 354 289 558 357 289 558 minecraft:green_terracotta
fill 354 289 598 357 289 598 minecraft:green_terracotta
setblock 357 289 559 minecraft:oak_log
setblock 358 289 558 minecraft:oak_log
fill 358 289 559 361 289 559 minecraft:green_terracotta
setblock 358 289 597 minecraft:green_terracotta
setblock 358 289 598 minecraft:oak_log
fill 359 289 558 362 289 558 minecraft:green_terracotta
fill 359 289 560 360 289 560 minecraft:green_terracotta
setblock 359 289 597 minecraft:oak_log
fill 359 289 598 362 289 598 minecraft:green_terracotta
fill 360 289 597 363 289 597 minecraft:green_terracotta
setblock 361 289 560 minecraft:oak_log
setblock 362 289 559 minecraft:oak_log
fill 362 289 560 362 292 560 minecraft:green_terracotta
fill 362 289 596 364 289 596 minecraft:green_terracotta
setblock 363 289 558 minecraft:oak_log
fill 363 289 559 363 292 559 minecraft:green_terracotta
setblock 363 289 598 minecraft:oak_log
fill 364 289 558 364 292 558 minecraft:green_terracotta
setblock 364 289 597 minecraft:oak_log
fill 364 289 598 364 292 598 minecraft:green_terracotta
setblock 365 289 560 minecraft:green_terracotta
setblock 365 289 596 minecraft:oak_log
fill 365 289 597 365 292 597 minecraft:green_terracotta
setblock 366 289 560 minecraft:oak_log
fill 366 289 596 366 290 596 minecraft:green_terracotta
setblock 367 289 559 minecraft:oak_log
fill 367 289 560 367 290 560 minecraft:green_terracotta
fill 367 289 580 367 289 583 minecraft:green_terracotta
setblock 367 289 584 minecraft:oak_log
fill 367 289 585 367 292 585 minecraft:green_terracotta
fill 367 289 587 368 289 587 minecraft:green_terracotta
setblock 368 289 558 minecraft:oak_log
fill 368 289 559 368 291 559 minecraft:green_terracotta
setblock 368 289 577 minecraft:green_terracotta
setblock 368 289 578 minecraft:oak_log
fill 368 289 579 368 291 579 minecraft:green_terracotta
setblock 368 289 582 minecraft:green_terracotta
setblock 368 289 583 minecraft:oak_log
fill 368 289 584 368 292 584 minecraft:green_terracotta
setblock 368 289 588 minecraft:oak_log
fill 368 289 589 368 292 589 minecraft:green_terracotta
setblock 368 289 591 minecraft:green_terracotta
setblock 368 289 598 minecraft:oak_log
fill 369 289 558 369 292 558 minecraft:green_terracotta
setblock 369 289 561 minecraft:green_terracotta
setblock 369 289 562 minecraft:oak_log
fill 369 289 563 369 290 564 minecraft:green_terracotta
fill 369 289 575 369 289 576 minecraft:green_terracotta
setblock 369 289 577 minecraft:oak_log
fill 369 289 578 369 292 578 minecraft:green_terracotta
setblock 369 289 582 minecraft:oak_log
fill 369 289 583 369 292 583 minecraft:green_terracotta
setblock 369 289 586 minecraft:green_terracotta
setblock 369 289 587 minecraft:oak_log
fill 369 289 588 369 292 588 minecraft:green_terracotta
setblock 369 289 592 minecraft:oak_log
fill 369 289 593 369 290 593 minecraft:green_terracotta
setblock 369 289 597 minecraft:oak_log
fill 369 289 598 369 292 598 minecraft:green_terracotta
setblock 370 289 561 minecraft:oak_log
fill 370 289 562 370 292 562 minecraft:green_terracotta
setblock 370 289 566 minecraft:oak_log
fill 370 289 573 370 289 575 minecraft:green_terracotta
setblock 370 289 576 minecraft:oak_log
fill 370 289 577 370 292 577 minecraft:green_terracotta
setblock 370 289 581 minecraft:oak_log
fill 370 289 582 370 292 582 minecraft:green_terracotta
setblock 370 289 586 minecraft:oak_log
fill 370 289 587 370 292 587 minecraft:green_terracotta
setblock 370 289 591 minecraft:oak_log
fill 370 289 592 370 292 592 minecraft:green_terracotta
setblock 370 289 596 minecraft:oak_log
fill 370 289 597 370 291 597 minecraft:green_terracotta
setblock 330 290 560 minecraft:oak_log
fill 330 290 561 330 293 561 minecraft:green_terracotta
setblock 330 290 565 minecraft:oak_log
fill 330 290 566 330 290 569 minecraft:green_terracotta
setblock 330 290 570 minecraft:oak_log
fill 330 290 571 330 290 574 minecraft:green_terracotta
setblock 330 290 575 minecraft:oak_log
fill 330 290 576 330 290 579 minecraft:green_terracotta
setblock 330 290 580 minecraft:oak_log
fill 330 290 581 330 290 584 minecraft:green_terracotta
setblock 330 290 585 minecraft:oak_log
fill 330 290 586 330 290 589 minecraft:green_terracotta
setblock 330 290 590 minecraft:oak_log
setblock 330 290 591 minecraft:green_terracotta
setblock 331 290 560 minecraft:green_terracotta
setblock 331 290 563 minecraft:green_terracotta
setblock 331 290 564 minecraft:oak_log
fill 331 290 565 331 292 565 minecraft:green_terracotta
fill 331 290 575 331 290 578 minecraft:green_terracotta
setblock 331 290 579 minecraft:oak_log
fill 331 290 580 331 292 580 minecraft:green_terracotta
setblock 331 290 584 minecraft:oak_log
fill 331 290 585 331 293 585 minecraft:green_terracotta
setblock 332 290 558 minecraft:oak_log
setblock 332 290 583 minecraft:oak_log
fill 333 290 558 336 290 558 minecraft:green_terracotta
setblock 336 290 584 minecraft:oak_leaves[persistent=true]
setblock 337 290 558 minecraft:oak_log
fill 337 290 559 340 290 559 minecraft:green_terracotta
fill 337 290 583 338 290 583 minecraft:oak_leaves[persistent=true]
fill 338 290 558 341 290 558 minecraft:green_terracotta
setblock 339 290 560 minecraft:green_terracotta
setblock 339 290 587 minecraft:oak_leaves[persistent=true]
setblock 339 290 598 minecraft:oak_leaves[persistent=true]
setblock 340 290 560 minecraft:oak_log
fill 340 290 561 343 290 561 minecraft:green_terracotta
setblock 340 290 585 minecraft:oak_leaves[persistent=true]
fill 340 290 598 341 290 598 minecraft:green_terracotta
setblock 341 290 559 minecraft:oak_log
fill 341 290 560 344 290 560 minecraft:green_terracotta
setblock 342 290 558 minecraft:oak_log
fill 342 290 559 345 290 559 minecraft:green_terracotta
setblock 342 290 598 minecraft:oak_log
fill 343 290 558 346 290 558 minecraft:green_terracotta
setblock 343 290 562 minecraft:oak_log
fill 343 290 598 346 290 598 minecraft:green_terracotta
setblock 344 290 561 minecraft:oak_log
fill 344 290 562 344 292 562 minecraft:green_terracotta
fill 344 290 597 347 290 597 minecraft:green_terracotta
setblock 345 290 560 minecraft:oak_log
fill 345 290 561 345 293 561 minecraft:green_terracotta
setblock 346 290 559 minecraft:oak_log
fill 346 290 560 346 293 560 minecraft:green_terracotta
setblock 347 290 558 minecraft:oak_log
fill 347 290 559 350 290 559 minecraft:green_terracotta
setblock 347 290 598 minecraft:oak_log
fill 348 290 558 351 290 558 minecraft:green_terracotta
setblock 348 290 597 minecraft:oak_log
fill 348 290 598 351 290 598 minecraft:green_terracotta
setblock 349 290 561 minecraft:oak_log
setblock 349 290 597 minecraft:green_terracotta
setblock 350 290 560 minecraft:oak_log
setblock 350 290 561 minecraft:green_terracotta
setblock 351 290 559 minecraft:oak_log
fill 351 290 560 351 291 560 minecraft:green_terracotta
setblock 352 290 558 minecraft:oak_log
fill 352 290 559 355 290 559 minecraft:green_terracotta
setblock 352 290 598 minecraft:oak_log
fill 353 290 558 356 290 558 minecraft:green_terracotta
fill 353 290 598 356 290 598 minecraft:green_terracotta
setblock 356 290 559 minecraft:oak_log
setblock 357 290 558 minecraft:oak_log
fill 357 290 559 360 290 559 minecraft:green_terracotta
setblock 357 290 598 minecraft:oak_log
fill 358 290 558 361 290 558 minecraft:green_terracotta
setblock 358 290 597 minecraft:oak_log
fill 358 290 598 361 290 598 minecraft:green_terracotta
setblock 359 290 560 minecraft:green_terracotta
fill 359 290 597 362 290 597 minecraft:green_terracotta
setblock 360 290 560 minecraft:oak_log
setblock 361 290 559 minecraft:oak_log
fill 361 290 560 361 292 560 minecraft:green_terracotta
setblock 362 290 558 minecraft:oak_log
fill 362 290 559 362 293 559 minecraft:green_terracotta
fill 362 290 596 363 290 596 minecraft:green_terracotta
setblock 362 290 598 minecraft:oak_log
fill 363 290 558 363 293 558 minecraft:green_terracotta
setblock 363 290 597 minecraft:oak_log
fill 363 290 598 363 293 598 minecraft:green_terracotta
setblock 364 290 596 minecraft:oak_log
fill 364 290 597 364 293 597 minecraft:green_terracotta
setblock 365 290 560 minecraft:oak_log
fill 365 290 596 365 291 596 minecraft:green_terracotta
setblock 366 290 559 minecraft:oak_log
fill 366 290 560 366 291 560 minecraft:green_terracotta
setblock 367 290 558 minecraft:oak_log
fill 367 290 559 367 292 559 minecraft:green_terracotta
fill 367 290 580 367 290 582 minecraft:green_terracotta
setblock 367 290 583 minecraft:oak_log
fill 367 290 584 367 293 584 minecraft:green_terracotta
setblock 367 290 587 minecraft:green_terracotta
setblock 367 290 588 minecraft:oak_log
setblock 367 290 598 minecraft:oak_log
fill 368 290 558 368 292 558 minecraft:green_terracotta
setblock 368 290 578 minecraft:green_terracotta
setblock 368 290 582 minecraft:oak_log
fill 368 290 583 368 293 583 minecraft:green_terracotta
setblock 368 290 587 minecraft:oak_log
fill 368 290 588 368 293 588 minecraft:green_terracotta
setblock 368 290 597 minecraft:oak_log
fill 368 290 598 368 292 598 minecraft:green_terracotta
setblock 369 290 561 minecraft:oak_log
fill 369 290 562 369 291 562 minecraft:green_terracotta
setblock 369 290 576 minecraft:oak_log
fill 369 290 577 369 291 577 minecraft:green_terracotta
setblock 369 290 581 minecraft:oak_log
fill 369 290 582 369 293 582 minecraft:green_terracotta
setblock 369 290 586 minecraft:oak_log
fill 369 290 587 369 293 587 minecraft:green_terracotta
setblock 369 290 591 minecraft:oak_log
fill 369 290 592 369 291 592 minecraft:green_terracotta
setblock 369 290 596 minecraft:oak_log
setblock 369 290 597 minecraft:green_terracotta
setblock 370 290 560 minecraft:oak_log
fill 370 290 561 370 292 561 minecraft:green_terracotta
setblock 370 290 564 minecraft:green_terracotta
setblock 370 290 565 minecraft:oak_log
fill 370 290 566 370 291 567 minecraft:green_terracotta
setblock 370 290 574 minecraft:green_terracotta
setblock 370 290 575 minecraft:oak_log
fill 370 290 576 370 292 576 minecraft:green_terracotta
setblock 370 290 580 minecraft:oak_log
fill 370 290 581 370 293 581 minecraft:green_terracotta
setblock 370 290 585 minecraft:oak_log
fill 370 290 586 370 293 586 minecraft:green_terracotta
setblock 370 290 590 minecraft:oak_log
fill 370 290 591 370 293 591 minecraft:green_terracotta
setblock 370 290 595 minecraft:oak_log
fill 370 290 596 370 291 596 minecraft:green_terracotta
setblock 330 291 559 minecraft:oak_log
fill 330 291 560 330 293 560 minecraft:green_terracotta
setblock 330 291 564 minecraft:oak_log
fill 330 291 565 330 291 568 minecraft:green_terracotta
setblock 330 291 569 minecraft:oak_log
fill 330 291 570 330 291 573 minecraft:green_terracotta
setblock 330 291 574 minecraft:oak_log
fill 330 291 575 330 291 578 minecraft:green_terracotta
setblock 330 291 579 minecraft:oak_log
fill 330 291 580 330 291 583 minecraft:green_terracotta
setblock 330 291 584 minecraft:oak_log
fill 330 291 585 330 291 588 minecraft:green_terracotta
setblock 330 291 589 minecraft:oak_log
fill 330 291 590 330 292 590 minecraft:green_terracotta
setblock 331 291 558 minecraft:oak_log
setblock 331 291 563 minecraft:oak_log
fill 331 291 564 331 292 564 minecraft:green_terracotta
setblock 331 291 577 minecraft:green_terracotta
setblock 331 291 578 minecraft:oak_log
fill 331 291 579 331 292 579 minecraft:green_terracotta
setblock 331 291 583 minecraft:oak_log
fill 331 291 584 331 293 584 minecraft:green_terracotta
fill 334 291 558 335 291 558 minecraft:green_terracotta
setblock 336 291 558 minecraft:oak_log
fill 337 291 558 339 291 559 minecraft:green_terracotta
setblock 338 291 560 minecraft:green_terracotta
setblock 339 291 560 minecraft:oak_log
setblock 340 291 558 minecraft:green_terracotta
setblock 340 291 559 minecraft:oak_log
fill 340 291 560 342 291 561 minecraft:green_terracotta
setblock 340 291 598 minecraft:green_terracotta
setblock 341 291 558 minecraft:oak_log
fill 341 291 559 344 291 559 minecraft:green_terracotta
setblock 341 291 598 minecraft:oak_log
fill 342 291 558 345 291 558 minecraft:green_terracotta
setblock 342 291 562 minecraft:oak_log
fill 342 291 598 345 291 598 minecraft:green_terracotta
setblock 343 291 560 minecraft:green_terracotta
setblock 343 291 561 minecraft:oak_log
fill 343 291 562 343 292 562 minecraft:green_terracotta
setblock 344 291 560 minecraft:oak_log
fill 344 291 561 344 294 561 minecraft:green_terracotta
fill 344 291 597 346 291 597 minecraft:green_terracotta
setblock 345 291 559 minecraft:oak_log
fill 345 291 560 345 294 560 minecraft:green_terracotta
setblock 346 291 558 minecraft:oak_log
fill 346 291 559 349 291 559 minecraft:green_terracotta
setblock 346 291 598 minecraft:oak_log
fill 347 291 558 350 291 558 minecraft:green_terracotta
setblock 347 291 597 minecraft:oak_log
fill 347 291 598 350 291 598 minecraft:green_terracotta
setblock 348 291 561 minecraft:oak_log
setblock 349 291 560 minecraft:oak_log
setblock 349 291 561 minecraft:green_terracotta
setblock 350 291 559 minecraft:oak_log
fill 350 291 560 350 292 560 minecraft:green_terracotta
setblock 351 291 558 minecraft:oak_log
fill 351 291 559 354 291 559 minecraft:green_terracotta
setblock 351 291 598 minecraft:oak_log
fill 352 291 558 355 291 558 minecraft:green_terracotta
fill 352 291 598 355 291 598 minecraft:green_terracotta
setblock 355 291 559 minecraft:oak_log
setblock 356 291 558 minecraft:oak_log
fill 356 291 559 359 291 559 minecraft:green_terracotta
setblock 356 291 598 minecraft:oak_log
fill 357 291 558 360 291 558 minecraft:green_terracotta
fill 357 291 598 360 291 598 minecraft:green_terracotta
setblock 359 291 560 minecraft:oak_log
fill 359 291 597 361 291 597 minecraft:green_terracotta
setblock 360 291 559 minecraft:oak_log
setblock 360 291 560 minecraft:green_terracotta
setblock 361 291 558 minecraft:oak_log
fill 361 291 559 361 294 559 minecraft:green_terracotta
setblock 361 291 598 minecraft:oak_log
fill 362 291 558 362 294 558 minecraft:green_terracotta
setblock 362 291 597 minecraft:oak_log
fill 362 291 598 362 294 598 minecraft:green_terracotta
setblock 363 291 596 minecraft:oak_log
fill 363 291 597 363 294 597 minecraft:green_terracotta
setblock 364 291 560 minecraft:oak_log
setblock 364 291 596 minecraft:green_terracotta
setblock 365 291 559 minecraft:oak_log
setblock 365 291 560 minecraft:green_terracotta
setblock 366 291 558 minecraft:oak_log
fill 366 291 559 366 292 559 minecraft:green_terracotta
setblock 366 291 598 minecraft:oak_log
fill 367 291 558 367 293 558 minecraft:green_terracotta
setblock 367 291 581 minecraft:green_terracotta
setblock 367 291 582 minecraft:oak_log
fill 367 291 583 367 292 583 minecraft:green_terracotta
setblock 367 291 587 minecraft:oak_log
fill 367 291 588 367 292 588 minecraft:green_terracotta
setblock 367 291 597 minecraft:oak_log
fill 367 291 598 367 293 598 minecraft:green_terracotta
setblock 368 291 581 minecraft:oak_log
fill 368 291 582 368 293 582 minecraft:green_terracotta
setblock 368 291 586 minecraft:oak_log
fill 368 291 587 368 294 587 minecraft:green_terracotta
setblock 368 291 597 minecraft:green_terracotta
setblock 369 291 560 minecraft:oak_log
setblock 369 291 561 minecraft:green_terracotta
setblock 369 291 563 minecraft:green_terracotta
setblock 369 291 580 minecraft:oak_log
fill 369 291 581 369 294 581 minecraft:green_terracotta
setblock 369 291 585 minecraft:oak_log
fill 369 291 586 369 294 586 minecraft:green_terracotta
setblock 369 291 590 minecraft:oak_log
fill 369 291 591 369 292 591 minecraft:green_terracotta
setblock 370 291 559 minecraft:oak_log
fill 370 291 560 370 292 560 minecraft:green_terracotta
setblock 370 291 564 minecraft:oak_log
fill 370 291 565 370 293 565 minecraft:green_terracotta
setblock 370 291 568 minecraft:oak_leaves[persistent=true]
setblock 370 291 575 minecraft:green_terracotta
setblock 370 291 579 minecraft:oak_log
fill 370 291 580 370 294 580 minecraft:green_terracotta
setblock 370 291 584 minecraft:oak_log
fill 370 291 585 370 294 585 minecraft:green_terracotta
setblock 370 291 589 minecraft:oak_log
fill 370 291 590 370 294 590 minecraft:green_terracotta
setblock 370 291 594 minecraft:oak_log
setblock 370 291 595 minecraft:green_terracotta
setblock 330 292 559 minecraft:green_terracotta
setblock 330 292 563 minecraft:oak_log
fill 330 292 564 330 292 567 minecraft:green_terracotta
setblock 330 292 568 minecraft:oak_log
fill 330 292 569 330 292 572 minecraft:green_terracotta
setblock 330 292 573 minecraft:oak_log
fill 330 292 574 330 292 577 minecraft:green_terracotta
setblock 330 292 578 minecraft:oak_log
fill 330 292 579 330 292 582 minecraft:green_terracotta
setblock 330 292 583 minecraft:oak_log
fill 330 292 584 330 292 587 minecraft:green_terracotta
setblock 330 292 588 minecraft:oak_log
fill 330 292 589 330 293 589 minecraft:green_terracotta
setblock 330 292 594 minecraft:oak_leaves[persistent=true]
setblock 331 292 563 minecraft:green_terracotta
setblock 331 292 582 minecraft:oak_log
fill 331 292 583 331 293 583 minecraft:green_terracotta
setblock 335 292 558 minecraft:oak_log
fill 336 292 558 339 292 558 minecraft:green_terracotta
fill 337 292 559 338 292 559 minecraft:green_terracotta
setblock 338 292 560 minecraft:oak_log
setblock 339 292 559 minecraft:oak_log
fill 339 292 560 342 292 560 minecraft:green_terracotta
setblock 340 292 558 minecraft:oak_log
fill 340 292 559 343 292 559 minecraft:green_terracotta
fill 340 292 561 341 292 561 minecraft:green_terracotta
setblock 340 292 598 minecraft:oak_log
fill 341 292 558 344 292 558 minecraft:green_terracotta
fill 341 292 598 344 292 598 minecraft:green_terracotta
setblock 342 292 561 minecraft:oak_log
setblock 343 292 560 minecraft:oak_log
fill 343 292 561 343 294 561 minecraft:green_terracotta
setblock 344 292 559 minecraft:oak_log
fill 344 292 560 344 295 560 minecraft:green_terracotta
setblock 345 292 558 minecraft:oak_log
fill 345 292 559 348 292 559 minecraft:green_terracotta
setblock 345 292 598 minecraft:oak_log
fill 346 292 558 349 292 558 minecraft:green_terracotta
fill 346 292 598 349 292 598 minecraft:green_terracotta
setblock 347 292 561 minecraft:oak_log
setblock 348 292 560 minecraft:oak_log
setblock 348 292 561 minecraft:green_terracotta
setblock 349 292 559 minecraft:oak_log
fill 349 292 560 349 293 560 minecraft:green_terracotta
setblock 350 292 558 minecraft:oak_log
fill 350 292 559 353 292 559 minecraft:green_terracotta
setblock 350 292 598 minecraft:oak_log
fill 351 292 558 354 292 558 minecraft:green_terracotta
fill 351 292 598 354 292 598 minecraft:green_terracotta
setblock 354 292 559 minecraft:oak_log
setblock 355 292 558 minecraft:oak_log
fill 355 292 559 358 292 559 minecraft:green_terracotta
setblock 355 292 598 minecraft:oak_log
fill 356 292 558 359 292 558 minecraft:green_terracotta
fill 356 292 598 359 292 598 minecraft:green_terracotta
setblock 359 292 559 minecraft:oak_log
fill 359 292 597 360 292 597 minecraft:green_terracotta
setblock 360 292 558 minecraft:oak_log
fill 360 292 559 360 294 559 minecraft:green_terracotta
setblock 360 292 598 minecraft:oak_log
fill 361 292 558 361 295 558 minecraft:green_terracotta
setblock 361 292 597 minecraft:oak_log
fill 361 292 598 361 295 598 minecraft:green_terracotta
fill 362 292 597 362 295 597 minecraft:green_terracotta
setblock 363 292 560 minecraft:oak_log
setblock 364 292 559 minecraft:oak_log
setblock 364 292 560 minecraft:green_terracotta
setblock 365 292 558 minecraft:oak_log
fill 365 292 559 365 293 559 minecraft:green_terracotta
setblock 365 292 598 minecraft:oak_log
fill 366 292 558 366 294 558 minecraft:green_terracotta
setblock 366 292 597 minecraft:oak_log
fill 366 292 598 366 294 598 minecraft:green_terracotta
setblock 367 292 582 minecraft:green_terracotta
setblock 367 292 586 minecraft:oak_log
fill 367 292 587 367 293 587 minecraft:green_terracotta
setblock 367 292 597 minecraft:green_terracotta
setblock 368 292 580 minecraft:oak_log
fill 368 292 581 368 293 581 minecraft:green_terracotta
setblock 368 292 585 minecraft:oak_log
fill 368 292 586 368 295 586 minecraft:green_terracotta
setblock 368 292 590 minecraft:oak_log
setblock 369 292 579 minecraft:oak_log
fill 369 292 580 369 293 580 minecraft:green_terracotta
setblock 369 292 584 minecraft:oak_log
fill 369 292 585 369 295 585 minecraft:green_terracotta
setblock 369 292 589 minecraft:oak_log
fill 369 292 590 369 294 590 minecraft:green_terracotta
setblock 370 292 559 minecraft:green_terracotta
setblock 370 292 563 minecraft:oak_log
fill 370 292 564 370 293 564 minecraft:green_terracotta
fill 370 292 566 370 293 566 minecraft:green_terracotta
setblock 370 292 578 minecraft:oak_log
fill 370 292 579 370 294 579 minecraft:green_terracotta
setblock 370 292 583 minecraft:oak_log
fill 370 292 584 370 295 584 minecraft:green_terracotta
setblock 370 292 588 minecraft:oak_log
fill 370 292 589 370 295 589 minecraft:green_terracotta
setblock 370 292 593 minecraft:oak_log
setblock 370 292 598 minecraft:oak_leaves[persistent=true]
setblock 330 293 562 minecraft:oak_log
fill 330 293 563 330 293 566 minecraft:green_terracotta
setblock 330 293 567 minecraft:oak_log
fill 330 293 568 330 293 571 minecraft:green_terracotta
fill 330 293 575 330 293 576 minecraft:green_terracotta
setblock 330 293 577 minecraft:oak_log
fill 330 293 578 330 293 581 minecraft:green_terracotta
setblock 330 293 582 minecraft:oak_log
fill 330 293 583 330 293 586 minecraft:green_terracotta
setblock 330 293 587 minecraft:oak_log
fill 330 293 588 330 295 588 minecraft:green_terracotta
setblock 331 293 581 minecraft:oak_log
setblock 331 293 582 minecraft:green_terracotta
setblock 332 293 598 minecraft:oak_leaves[persistent=true]
fill 336 293 558 338 293 558 minecraft:green_terracotta
setblock 337 293 559 minecraft:green_terracotta
setblock 338 293 559 minecraft:oak_log
setblock 339 293 558 minecraft:oak_log
fill 339 293 559 341 293 560 minecraft:green_terracotta
fill 340 293 558 343 293 558 minecraft:green_terracotta
setblock 340 293 561 minecraft:green_terracotta
setblock 341 293 561 minecraft:oak_log
fill 341 293 598 343 293 598 minecraft:green_terracotta
setblock 342 293 559 minecraft:green_terracotta
setblock 342 293 560 minecraft:oak_log
fill 342 293 561 342 294 561 minecraft:green_terracotta
setblock 343 293 559 minecraft:oak_log
fill 343 293 560 343 296 560 minecraft:green_terracotta
setblock 344 293 558 minecraft:oak_log
fill 344 293 559 347 293 559 minecraft:green_terracotta
setblock 344 293 598 minecraft:oak_log
fill 345 293 558 348 293 558 minecraft:green_terracotta
fill 345 293 598 348 293 598 minecraft:green_terracotta
setblock 346 293 561 minecraft:oak_log
setblock 347 293 560 minecraft:oak_log
fill 347 293 569 348 294 570 minecraft:oak_leaves[persistent=true]
setblock 348 293 559 minecraft:oak_log
setblock 348 293 560 minecraft:green_terracotta
setblock 349 293 558 minecraft:oak_log
fill 349 293 559 351 293 559 minecraft:green_terracotta
setblock 349 293 598 minecraft:oak_log
fill 350 293 558 353 293 558 minecraft:green_terracotta
setblock 354 293 558 minecraft:oak_log
fill 355 293 558 358 293 558 minecraft:green_terracotta
fill 356 293 598 358 293 598 minecraft:green_terracotta
setblock 358 293 559 minecraft:oak_log
setblock 359 293 558 minecraft:oak_log
setblock 359 293 559 minecraft:green_terracotta
setblock 359 293 598 minecraft:oak_log
fill 360 293 558 360 296 558 minecraft:green_terracotta
setblock 360 293 597 minecraft:oak_log
fill 360 293 598 360 296 598 minecraft:green_terracotta
fill 361 293 597 361 295 597 minecraft:green_terracotta
setblock 363 293 559 minecraft:oak_log
setblock 364 293 558 minecraft:oak_log
setblock 364 293 559 minecraft:green_terracotta
setblock 364 293 598 minecraft:oak_log
fill 365 293 558 365 294 558 minecraft:green_terracotta
setblock 365 293 597 minecraft:oak_log
fill 365 293 598 365 295 598 minecraft:green_terracotta
setblock 367 293 585 minecraft:oak_log
setblock 367 293 586 minecraft:green_terracotta
setblock 368 293 558 minecraft:oak_leaves[persistent=true]
setblock 368 293 584 minecraft:oak_log
fill 368 293 585 368 295 585 minecraft:green_terracotta
setblock 368 293 589 minecraft:oak_log
setblock 369 293 579 minecraft:green_terracotta
setblock 369 293 583 minecraft:oak_log
fill 369 293 584 369 296 584 minecraft:green_terracotta
setblock 369 293 588 minecraft:oak_log
fill 369 293 589 369 296 589 minecraft:green_terracotta
setblock 370 293 562 minecraft:oak_log
setblock 370 293 563 minecraft:green_terracotta
setblock 370 293 575 minecraft:oak_leaves[persistent=true]
setblock 370 293 577 minecraft:oak_log
setblock 370 293 578 minecraft:green_terracotta
setblock 370 293 582 minecraft:oak_log
fill 370 293 583 370 296 583 minecraft:green_terracotta
setblock 370 293 587 minecraft:oak_log
fill 370 293 588 370 296 588 minecraft:green_terracotta
setblock 370 293 592 minecraft:oak_log
setblock 330 294 561 minecraft:oak_log
fill 330 294 562 330 294 565 minecraft:green_terracotta
setblock 330 294 566 minecraft:oak_log
fill 330 294 567 330 294 570 minecraft:green_terracotta
fill 330 294 578 330 294 580 minecraft:green_terracotta
setblock 330 294 581 minecraft:oak_log
fill 330 294 582 330 294 585 minecraft:green_terracotta
setblock 330 294 586 minecraft:oak_log
fill 330 294 587 330 296 587 minecraft:green_terracotta
setblock 337 294 558 minecraft:green_terracotta
setblock 338 294 558 minecraft:oak_log
fill 338 294 559 341 294 559 minecraft:green_terracotta
setblock 338 294 598 minecraft:oak_leaves[persistent=true]
fill 339 294 558 342 294 558 minecraft:green_terracotta
fill 339 294 560 340 294 560 minecraft:green_terracotta
setblock 341 294 560 minecraft:oak_log
setblock 341 294 561 minecraft:green_terracotta
fill 341 294 598 342 294 598 minecraft:green_terracotta
setblock 342 294 559 minecraft:oak_log
fill 342 294 560 342 296 560 minecraft:green_terracotta
setblock 343 294 558 minecraft:oak_log
fill 343 294 559 346 294 559 minecraft:green_terracotta
setblock 343 294 598 minecraft:oak_log
fill 344 294 558 347 294 558 minecraft:green_terracotta
fill 344 294 598 347 294 598 minecraft:green_terracotta
setblock 345 294 561 minecraft:oak_log
setblock 346 294 560 minecraft:oak_log
setblock 347 294 559 minecraft:oak_log
setblock 347 294 560 minecraft:green_terracotta
setblock 348 294 558 minecraft:oak_log
fill 348 294 559 349 294 559 minecraft:green_terracotta
fill 349 294 558 352 294 558 minecraft:green_terracotta
setblock 353 294 558 minecraft:oak_log
fill 354 294 558 357 294 558 minecraft:green_terracotta
fill 356 294 598 357 294 598 minecraft:green_terracotta
setblock 358 294 558 minecraft:oak_log
setblock 358 294 598 minecraft:oak_log
fill 359 294 558 359 296 558 minecraft:green_terracotta
fill 359 294 598 359 297 598 minecraft:green_terracotta
setblock 360 294 597 minecraft:green_terracotta
setblock 362 294 559 minecraft:oak_log
setblock 363 294 558 minecraft:oak_log
setblock 363 294 559 minecraft:green_terracotta
setblock 363 294 598 minecraft:oak_log
fill 364 294 558 364 295 558 minecraft:green_terracotta
setblock 364 294 597 minecraft:oak_log
fill 364 294 598 364 296 598 minecraft:green_terracotta
setblock 368 294 583 minecraft:oak_log
setblock 368 294 584 minecraft:green_terracotta
setblock 368 294 588 minecraft:oak_log
setblock 369 294 582 minecraft:oak_log
fill 369 294 583 369 295 583 minecraft:green_terracotta
setblock 369 294 587 minecraft:oak_log
fill 369 294 588 369 297 588 minecraft:green_terracotta
setblock 370 294 569 minecraft:oak_leaves[persistent=true]
setblock 370 294 581 minecraft:oak_log
fill 370 294 582 370 297 582 minecraft:green_terracotta
setblock 370 294 586 minecraft:oak_log
fill 370 294 587 370 297 587 minecraft:green_terracotta
setblock 370 294 591 minecraft:oak_log
setblock 370 294 594 minecraft:oak_leaves[persistent=true]
fill 330 295 562 330 295 564 minecraft:green_terracotta
setblock 330 295 565 minecraft:oak_log
fill 330 295 566 330 295 569 minecraft:green_terracotta
setblock 330 295 570 minecraft:oak_log
fill 330 295 581 330 295 584 minecraft:green_terracotta
setblock 330 295 585 minecraft:oak_log
fill 330 295 586 330 296 586 minecraft:green_terracotta
setblock 330 295 593 minecraft:oak_leaves[persistent=true]
setblock 331 295 558 minecraft:oak_leaves[persistent=true]
setblock 337 295 558 minecraft:oak_log
fill 338 295 558 340 295 559 minecraft:green_terracotta
setblock 340 295 560 minecraft:oak_log
setblock 341 295 558 minecraft:green_terracotta
setblock 341 295 559 minecraft:oak_log
fill 341 295 560 341 297 560 minecraft:green_terracotta
setblock 342 295 558 minecraft:oak_log
fill 342 295 559 345 295 559 minecraft:green_terracotta
setblock 342 295 598 minecraft:oak_log
fill 343 295 558 346 295 558 minecraft:green_terracotta
fill 343 295 598 345 295 598 minecraft:green_terracotta
setblock 345 295 560 minecraft:oak_log
setblock 346 295 559 minecraft:oak_log
setblock 347 295 558 minecraft:oak_log
setblock 347 295 559 minecraft:green_terracotta
fill 348 295 558 349 295 558 minecraft:green_terracotta
setblock 350 295 558 minecraft:oak_leaves[persistent=true]
fill 350 295 598 350 296 598 minecraft:oak_leaves[persistent=true]
setblock 357 295 558 minecraft:oak_log
setblock 357 295 598 minecraft:oak_log
fill 358 295 558 358 296 558 minecraft:green_terracotta
fill 358 295 598 358 298 598 minecraft:green_terracotta
setblock 362 295 558 minecraft:oak_log
setblock 362 295 598 minecraft:oak_log
setblock 363 295 558 minecraft:green_terracotta
fill 363 295 598 363 298 598 minecraft:green_terracotta
setblock 368 295 587 minecraft:oak_log
setblock 369 295 582 minecraft:green_terracotta
setblock 369 295 586 minecraft:oak_log
fill 369 295 587 369 298 587 minecraft:green_terracotta
setblock 369 295 598 minecraft:oak_leaves[persistent=true]
setblock 370 295 563 minecraft:oak_leaves[persistent=true]
setblock 370 295 580 minecraft:oak_log
fill 370 295 581 370 296 581 minecraft:green_terracotta
setblock 370 295 585 minecraft:oak_log
fill 370 295 586 370 298 586 minecraft:green_terracotta
setblock 370 295 590 minecraft:oak_log
fill 370 295 591 370 298 591 minecraft:green_terracotta
setblock 330 296 563 minecraft:green_terracotta
setblock 330 296 564 minecraft:oak_log
fill 330 296 565 330 296 568 minecraft:green_terracotta
setblock 330 296 569 minecraft:oak_log
fill 330 296 570 330 299 570 minecraft:green_terracotta
setblock 330 296 574 minecraft:oak_leaves[persistent=true]
fill 330 296 580 330 297 580 minecraft:oak_leaves[persistent=true]
setblock 330 296 584 minecraft:oak_log
setblock 330 296 585 minecraft:green_terracotta
setblock 331 296 598 minecraft:oak_leaves[persistent=true]
setblock 332 296 560 minecraft:light[level=14]
setblock 332 296 568 minecraft:light[level=14]
setblock 332 296 576 minecraft:light[level=14]
setblock 332 296 584 minecraft:light[level=14]
setblock 332 296 592 minecraft:light[level=14]
fill 337 296 558 340 296 558 minecraft:green_terracotta
fill 338 296 559 339 296 559 minecraft:green_terracotta
setblock 340 296 559 minecraft:oak_log
setblock 340 296 560 minecraft:green_terracotta
setblock 340 296 568 minecraft:light[level=14]
setblock 340 296 576 minecraft:light[level=14]
setblock 340 296 584 minecraft:light[level=14]
setblock 340 296 592 minecraft:light[level=14]
setblock 341 296 558 minecraft:oak_log
fill 341 296 559 344 296 559 minecraft:green_terracotta
fill 342 296 558 345 296 558 minecraft:green_terracotta
fill 342 296 598 343 298 598 minecraft:green_terracotta
setblock 345 296 559 minecraft:oak_log
setblock 346 296 558 minecraft:oak_log
setblock 346 296 559 minecraft:green_terracotta
fill 347 296 558 348 296 558 minecraft:green_terracotta
setblock 348 296 560 minecraft:light[level=14]
setblock 348 296 568 minecraft:light[level=14]
setblock 348 296 576 minecraft:light[level=14]
setblock 348 296 584 minecraft:light[level=14]
setblock 348 296 592 minecraft:light[level=14]
setblock 356 296 560 minecraft:light[level=14]
setblock 356 296 568 minecraft:light[level=14]
setblock 356 296 576 minecraft:light[level=14]
setblock 356 296 584 minecraft:light[level=14]
setblock 356 296 592 minecraft:light[level=14]
setblock 356 296 598 minecraft:oak_leaves[persistent=true]
fill 357 296 598 357 299 598 minecraft:green_terracotta
setblock 361 296 558 minecraft:oak_log
setblock 361 296 598 minecraft:oak_log
setblock 362 296 558 minecraft:green_terracotta
fill 362 296 598 362 299 598 minecraft:green_terracotta
setblock 364 296 560 minecraft:light[level=14]
setblock 364 296 568 minecraft:light[level=14]
setblock 364 296 576 minecraft:light[level=14]
setblock 364 296 584 minecraft:light[level=14]
setblock 364 296 592 minecraft:light[level=14]
setblock 369 296 558 minecraft:oak_leaves[persistent=true]
setblock 369 296 585 minecraft:oak_log
fill 369 296 586 369 297 586 minecraft:green_terracotta
setblock 370 296 576 minecraft:oak_leaves[persistent=true]
setblock 370 296 584 minecraft:oak_log
fill 370 296 585 370 299 585 minecraft:green_terracotta
setblock 370 296 589 minecraft:oak_log
fill 370 296 590 370 299 590 minecraft:green_terracotta
setblock 330 297 561 minecraft:oak_leaves[persistent=true]
fill 330 297 564 330 297 567 minecraft:green_terracotta
setblock 330 297 568 minecraft:oak_log
fill 330 297 569 330 300 569 minecraft:green_terracotta
fill 330 297 571 330 298 571 minecraft:green_terracotta
setblock 330 297 586 minecraft:oak_leaves[persistent=true]
fill 337 297 558 339 297 558 minecraft:green_terracotta
setblock 337 297 598 minecraft:oak_leaves[persistent=true]
setblock 338 297 559 minecraft:green_terracotta
setblock 339 297 559 minecraft:oak_log
setblock 340 297 558 minecraft:oak_log
fill 340 297 559 343 297 559 minecraft:green_terracotta
fill 341 297 558 344 297 558 minecraft:green_terracotta
setblock 344 297 559 minecraft:oak_log
setblock 345 297 558 minecraft:oak_log
fill 346 297 558 347 297 558 minecraft:green_terracotta
fill 356 297 584 357 297 587 minecraft:oak_leaves[persistent=true]
fill 356 297 598 356 300 598 minecraft:green_terracotta
fill 357 297 583 362 297 583 minecraft:oak_leaves[persistent=true]
fill 357 297 588 361 297 588 minecraft:oak_leaves[persistent=true]
fill 358 297 582 360 297 582 minecraft:oak_leaves[persistent=true]
fill 358 297 589 360 297 589 minecraft:oak_leaves[persistent=true]
setblock 360 297 598 minecraft:oak_log
fill 361 297 584 362 298 584 minecraft:oak_leaves[persistent=true]
fill 361 297 587 362 297 587 minecraft:oak_leaves[persistent=true]
fill 361 297 598 361 300 598 minecraft:green_terracotta
fill 362 297 585 362 298 586 minecraft:oak_leaves[persistent=true]
setblock 363 297 558 minecraft:oak_leaves[persistent=true]
fill 365 297 577 365 298 578 minecraft:glowstone
setblock 369 297 585 minecraft:green_terracotta
setblock 370 297 570 minecraft:oak_leaves[persistent=true]
setblock 370 297 583 minecraft:oak_log
fill 370 297 584 370 300 584 minecraft:green_terracotta
setblock 370 297 588 minecraft:oak_log
fill 370 297 589 370 300 589 minecraft:green_terracotta
setblock 370 297 595 minecraft:oak_leaves[persistent=true]
fill 330 298 564 330 298 566 minecraft:green_terracotta
setblock 330 298 567 minecraft:oak_log
fill 330 298 568 331 300 568 minecraft:green_terracotta
setblock 330 298 572 minecraft:oak_log
setblock 330 298 592 minecraft:oak_leaves[persistent=true]
fill 331 298 567 331 300 567 minecraft:green_terracotta
setblock 332 298 558 minecraft:oak_leaves[persistent=true]
fill 337 298 558 338 298 558 minecraft:green_terracotta
setblock 338 298 559 minecraft:oak_log
setblock 339 298 558 minecraft:oak_log
fill 339 298 559 342 298 559 minecraft:green_terracotta
fill 340 298 558 343 298 558 minecraft:green_terracotta
fill 340 298 598 341 300 598 minecraft:green_terracotta
setblock 343 298 559 minecraft:oak_log
setblock 344 298 558 minecraft:oak_log
fill 345 298 558 346 298 558 minecraft:green_terracotta
fill 356 298 585 357 298 586 minecraft:oak_leaves[persistent=true]
setblock 357 298 558 minecraft:oak_leaves[persistent=true]
fill 357 298 583 357 298 584 minecraft:oak_leaves[persistent=true]
setblock 357 298 587 minecraft:oak_leaves[persistent=true]
fill 358 298 583 361 298 583 minecraft:oak_leaves[persistent=true]
fill 358 298 588 361 298 588 minecraft:oak_leaves[persistent=true]
setblock 359 298 597 minecraft:green_terracotta
setblock 359 298 598 minecraft:oak_log
setblock 360 298 597 minecraft:oak_log
fill 360 298 598 360 300 598 minecraft:green_terracotta
fill 361 298 587 361 299 587 minecraft:oak_leaves[persistent=true]
setblock 368 298 598 minecraft:oak_leaves[persistent=true]
setblock 369 298 588 minecraft:oak_log
setblock 370 298 564 minecraft:oak_leaves[persistent=true]
setblock 370 298 583 minecraft:green_terracotta
setblock 370 298 587 minecraft:oak_log
fill 370 298 588 370 300 588 minecraft:green_terracotta
fill 330 299 564 330 299 565 minecraft:green_terracotta
setblock 330 299 566 minecraft:oak_log
fill 330 299 567 330 300 567 minecraft:green_terracotta
setblock 330 299 571 minecraft:oak_log
fill 330 299 572 330 300 573 minecraft:green_terracotta
setblock 330 299 598 minecraft:oak_leaves[persistent=true]
fill 331 299 566 331 300 566 minecraft:green_terracotta
setblock 331 299 569 minecraft:green_terracotta
setblock 331 299 570 minecraft:oak_log
fill 336 299 558 337 299 558 minecraft:green_terracotta
setblock 338 299 558 minecraft:oak_log
fill 338 299 559 341 299 559 minecraft:green_terracotta
fill 339 299 558 342 299 558 minecraft:green_terracotta
fill 339 299 598 339 300 598 minecraft:green_terracotta
setblock 342 299 559 minecraft:oak_log
setblock 342 299 598 minecraft:green_terracotta
setblock 343 299 558 minecraft:oak_log
fill 343 299 559 343 300 559 minecraft:green_terracotta
setblock 343 299 598 minecraft:oak_log
fill 344 299 558 345 300 558 minecraft:green_terracotta
fill 344 299 598 344 300 598 minecraft:green_terracotta
setblock 349 299 598 minecraft:oak_leaves[persistent=true]
setblock 351 299 558 minecraft:oak_leaves[persistent=true]
fill 354 299 598 355 300 598 minecraft:green_terracotta
fill 357 299 584 357 299 586 minecraft:oak_leaves[persistent=true]
fill 357 299 597 358 299 597 minecraft:green_terracotta
setblock 358 299 598 minecraft:oak_log
fill 359 299 583 360 299 583 minecraft:oak_leaves[persistent=true]
setblock 359 299 588 minecraft:oak_leaves[persistent=true]
setblock 359 299 597 minecraft:oak_log
fill 359 299 598 359 300 598 minecraft:green_terracotta
fill 360 299 597 361 300 597 minecraft:green_terracotta
setblock 361 299 584 minecraft:oak_leaves[persistent=true]
setblock 363 299 598 minecraft:oak_log
setblock 370 299 558 minecraft:oak_leaves[persistent=true]
fill 370 299 567 370 299 570 minecraft:green_terracotta
setblock 370 299 571 minecraft:oak_log
setblock 370 299 583 minecraft:oak_leaves[persistent=true]
setblock 370 299 586 minecraft:oak_log
fill 370 299 587 370 300 587 minecraft:green_terracotta
setblock 370 299 591 minecraft:oak_log
setblock 330 300 560 minecraft:oak_leaves[persistent=true]
fill 330 300 563 330 300 564 minecraft:green_terracotta
setblock 330 300 565 minecraft:oak_log
setblock 330 300 566 minecraft:green_terracotta
setblock 330 300 570 minecraft:oak_log
fill 330 300 571 331 300 571 minecraft:green_terracotta
setblock 330 300 574 minecraft:green_terracotta
setblock 330 300 579 minecraft:oak_leaves[persistent=true]
setblock 331 300 565 minecraft:green_terracotta
setblock 331 300 569 minecraft:oak_log
setblock 331 300 570 minecraft:green_terracotta
setblock 331 300 572 minecraft:green_terracotta
fill 335 300 558 336 300 558 minecraft:green_terracotta
setblock 336 300 598 minecraft:oak_leaves[persistent=true]
setblock 337 300 558 minecraft:oak_log
fill 337 300 559 340 300 559 minecraft:green_terracotta
setblock 337 300 598 minecraft:oak_log
fill 338 300 558 341 300 558 minecraft:green_terracotta
setblock 338 300 598 minecraft:green_terracotta
setblock 341 300 559 minecraft:oak_log
setblock 342 300 558 minecraft:oak_log
setblock 342 300 559 minecraft:green_terracotta
setblock 342 300 598 minecraft:oak_log
setblock 343 300 558 minecraft:green_terracotta
setblock 343 300 598 minecraft:green_terracotta
setblock 345 300 598 minecraft:green_terracotta
setblock 352 300 598 minecraft:oak_log
setblock 353 300 598 minecraft:green_terracotta
fill 355 300 597 357 300 597 minecraft:green_terracotta
fill 357 300 596 358 300 596 minecraft:green_terracotta
setblock 357 300 598 minecraft:oak_log
setblock 358 300 558 minecraft:green_terracotta
setblock 358 300 597 minecraft:oak_log
setblock 358 300 598 minecraft:green_terracotta
setblock 359 300 596 minecraft:oak_log
setblock 359 300 597 minecraft:green_terracotta
setblock 360 300 596 minecraft:green_terracotta
setblock 362 300 597 minecraft:green_terracotta
setblock 362 300 598 minecraft:oak_log
setblock 363 300 598 minecraft:green_terracotta
setblock 364 300 558 minecraft:oak_leaves[persistent=true]
fill 370 300 566 370 300 569 minecraft:green_terracotta
setblock 370 300 570 minecraft:oak_log
fill 370 300 571 370 300 574 minecraft:green_terracotta
setblock 370 300 577 minecraft:oak_leaves[persistent=true]
setblock 370 300 585 minecraft:oak_log
setblock 370 300 586 minecraft:green_terracotta
setblock 370 300 590 minecraft:oak_log
fill 370 300 591 370 300 592 minecraft:green_terracotta
setblock 370 300 596 minecraft:oak_leaves[persistent=true]
