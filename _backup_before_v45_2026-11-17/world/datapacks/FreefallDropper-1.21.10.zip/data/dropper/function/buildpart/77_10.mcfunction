setblock 275 298 352 minecraft:moss_block
fill 275 298 353 275 298 358 minecraft:mushroom_stem
fill 275 298 363 276 298 363 minecraft:mushroom_stem
setblock 276 298 328 minecraft:mushroom_stem
setblock 276 298 329 minecraft:red_mushroom_block
fill 276 298 330 276 298 336 minecraft:mushroom_stem
setblock 276 298 338 minecraft:mushroom_stem
setblock 276 298 342 minecraft:mushroom_stem
setblock 276 298 343 minecraft:moss_block
setblock 276 298 347 minecraft:mushroom_stem
fill 276 298 348 276 300 348 minecraft:moss_block
setblock 276 298 352 minecraft:mushroom_stem
fill 276 298 353 276 300 353 minecraft:moss_block
setblock 276 298 354 minecraft:red_mushroom_block
fill 276 298 355 276 298 358 minecraft:mushroom_stem
fill 277 298 355 277 308 355 minecraft:moss_block
setblock 236 299 326 minecraft:mushroom_stem
fill 236 299 327 236 300 327 minecraft:moss_block
setblock 236 299 331 minecraft:mushroom_stem
fill 236 299 332 236 300 333 minecraft:moss_block
setblock 236 299 338 minecraft:red_mushroom_block
fill 236 299 342 236 299 344 minecraft:red_mushroom_block
setblock 236 299 346 minecraft:mushroom_stem
fill 236 299 347 236 300 347 minecraft:moss_block
setblock 236 299 351 minecraft:mushroom_stem
setblock 236 299 363 minecraft:red_mushroom_block
setblock 237 299 346 minecraft:red_mushroom_block
fill 238 299 341 240 299 341 minecraft:red_mushroom_block
setblock 239 299 322 minecraft:shroomlight
fill 239 299 346 240 299 346 minecraft:red_mushroom_block
fill 240 299 322 240 308 322 minecraft:moss_block
fill 240 299 327 240 299 340 minecraft:red_mushroom_block
setblock 240 299 342 minecraft:red_mushroom_block
fill 240 299 347 240 299 359 minecraft:red_mushroom_block
fill 241 299 323 243 299 323 minecraft:moss_block
fill 241 299 327 272 299 327 minecraft:red_mushroom_block
fill 241 299 359 272 299 359 minecraft:red_mushroom_block
setblock 242 299 324 minecraft:moss_block
setblock 243 299 324 minecraft:mushroom_stem
fill 243 299 325 243 300 325 minecraft:moss_block
setblock 244 299 323 minecraft:mushroom_stem
fill 244 299 324 244 300 324 minecraft:moss_block
fill 245 299 323 245 300 323 minecraft:moss_block
setblock 245 299 326 minecraft:moss_block
fill 245 299 363 248 299 363 minecraft:moss_block
setblock 246 299 326 minecraft:mushroom_stem
setblock 247 299 325 minecraft:mushroom_stem
fill 247 299 326 247 300 326 minecraft:moss_block
fill 247 299 349 247 299 351 minecraft:red_mushroom_block
setblock 248 299 324 minecraft:mushroom_stem
fill 248 299 325 248 300 325 minecraft:moss_block
fill 248 299 352 250 299 352 minecraft:red_mushroom_block
setblock 249 299 323 minecraft:mushroom_stem
fill 249 299 324 249 300 324 minecraft:moss_block
fill 249 299 347 250 299 347 minecraft:red_mushroom_block
setblock 249 299 363 minecraft:mushroom_stem
fill 250 299 323 253 299 323 minecraft:moss_block
fill 250 299 363 252 300 363 minecraft:moss_block
setblock 252 299 325 minecraft:mushroom_stem
fill 252 299 349 252 299 350 minecraft:red_mushroom_block
setblock 253 299 324 minecraft:mushroom_stem
fill 253 299 364 254 308 364 minecraft:moss_block
setblock 254 299 323 minecraft:mushroom_stem
setblock 254 299 324 minecraft:moss_block
fill 255 299 323 258 299 323 minecraft:moss_block
setblock 255 299 363 minecraft:red_mushroom_block
setblock 255 299 364 minecraft:shroomlight
setblock 259 299 323 minecraft:mushroom_stem
fill 260 299 323 260 300 323 minecraft:moss_block
setblock 264 299 323 minecraft:mushroom_stem
fill 264 299 324 264 300 324 minecraft:moss_block
setblock 264 299 363 minecraft:mushroom_stem
fill 265 299 323 265 300 323 minecraft:moss_block
setblock 265 299 362 minecraft:mushroom_stem
fill 265 299 363 265 300 363 minecraft:moss_block
fill 266 299 362 266 300 362 minecraft:moss_block
setblock 268 299 324 minecraft:mushroom_stem
setblock 269 299 323 minecraft:mushroom_stem
setblock 269 299 363 minecraft:mushroom_stem
setblock 270 299 322 minecraft:shroomlight
fill 270 299 323 270 300 323 minecraft:moss_block
fill 270 299 363 270 300 363 minecraft:moss_block
setblock 271 299 339 minecraft:red_mushroom_block
setblock 271 299 341 minecraft:red_mushroom_block
fill 272 299 328 272 299 336 minecraft:red_mushroom_block
fill 272 299 344 272 299 358 minecraft:red_mushroom_block
setblock 274 299 342 minecraft:red_mushroom_block
setblock 275 299 339 minecraft:red_mushroom_block
setblock 275 299 347 minecraft:mushroom_stem
fill 275 299 348 275 300 348 minecraft:moss_block
setblock 275 299 352 minecraft:mushroom_stem
setblock 276 299 323 minecraft:red_mushroom_block
setblock 276 299 346 minecraft:mushroom_stem
fill 276 299 347 276 300 347 minecraft:moss_block
setblock 276 299 351 minecraft:mushroom_stem
fill 276 299 352 276 300 352 minecraft:moss_block
fill 276 299 354 276 300 354 minecraft:moss_block
setblock 235 300 330 minecraft:shroomlight
fill 235 300 349 235 308 350 minecraft:moss_block
setblock 235 300 351 minecraft:red_mushroom_block
setblock 236 300 325 minecraft:red_mushroom_block
setblock 236 300 326 minecraft:moss_block
setblock 236 300 329 minecraft:moss_block
setblock 236 300 330 minecraft:mushroom_stem
fill 236 300 331 237 300 331 minecraft:moss_block
setblock 236 300 334 minecraft:moss_block
setblock 236 300 335 minecraft:mushroom_stem
setblock 236 300 344 minecraft:red_mushroom_block
setblock 236 300 345 minecraft:mushroom_stem
setblock 236 300 346 minecraft:moss_block
setblock 236 300 350 minecraft:mushroom_stem
setblock 236 300 351 minecraft:moss_block
setblock 237 300 329 minecraft:mushroom_stem
setblock 237 300 330 minecraft:moss_block
fill 239 300 322 239 301 322 minecraft:moss_block
fill 240 300 323 242 300 323 minecraft:moss_block
setblock 241 300 324 minecraft:moss_block
setblock 242 300 324 minecraft:mushroom_stem
setblock 242 300 363 minecraft:red_mushroom_block
setblock 243 300 323 minecraft:mushroom_stem
setblock 243 300 324 minecraft:moss_block
setblock 244 300 323 minecraft:moss_block
setblock 244 300 326 minecraft:moss_block
setblock 245 300 326 minecraft:mushroom_stem
fill 245 300 363 247 300 363 minecraft:moss_block
setblock 246 300 325 minecraft:mushroom_stem
setblock 246 300 326 minecraft:moss_block
setblock 247 300 324 minecraft:mushroom_stem
setblock 247 300 325 minecraft:moss_block
setblock 248 300 323 minecraft:mushroom_stem
setblock 248 300 324 minecraft:moss_block
setblock 248 300 363 minecraft:mushroom_stem
fill 249 300 323 252 300 323 minecraft:moss_block
setblock 249 300 363 minecraft:moss_block
setblock 251 300 325 minecraft:mushroom_stem
setblock 252 300 324 minecraft:mushroom_stem
setblock 253 300 323 minecraft:mushroom_stem
setblock 253 300 324 minecraft:moss_block
fill 254 300 323 257 300 323 minecraft:moss_block
fill 255 300 364 255 308 364 minecraft:moss_block
setblock 258 300 323 minecraft:mushroom_stem
setblock 259 300 323 minecraft:moss_block
setblock 260 300 363 minecraft:moss_block
setblock 263 300 323 minecraft:mushroom_stem
setblock 263 300 363 minecraft:mushroom_stem
setblock 264 300 323 minecraft:moss_block
setblock 264 300 362 minecraft:mushroom_stem
setblock 264 300 363 minecraft:moss_block
setblock 265 300 362 minecraft:moss_block
setblock 267 300 324 minecraft:mushroom_stem
setblock 268 300 323 minecraft:mushroom_stem
setblock 268 300 363 minecraft:mushroom_stem
setblock 269 300 323 minecraft:moss_block
setblock 269 300 363 minecraft:moss_block
fill 270 300 322 270 308 322 minecraft:moss_block
setblock 275 300 346 minecraft:mushroom_stem
setblock 275 300 347 minecraft:moss_block
setblock 275 300 351 minecraft:mushroom_stem
fill 275 300 352 275 300 353 minecraft:moss_block
setblock 276 300 342 minecraft:red_mushroom_block
setblock 276 300 345 minecraft:mushroom_stem
setblock 276 300 346 minecraft:moss_block
setblock 276 300 350 minecraft:mushroom_stem
setblock 276 300 351 minecraft:moss_block
setblock 276 300 361 minecraft:red_mushroom_block
setblock 277 300 335 minecraft:shroomlight
fill 235 301 330 235 308 330 minecraft:moss_block
fill 235 301 346 235 304 346 minecraft:moss_block
setblock 235 301 347 minecraft:red_mushroom_block
fill 235 301 351 235 308 351 minecraft:moss_block
setblock 238 301 325 minecraft:light[level=15]
setblock 238 301 333 minecraft:light[level=15]
setblock 238 301 341 minecraft:light[level=15]
setblock 238 301 349 minecraft:light[level=15]
setblock 238 301 357 minecraft:light[level=15]
setblock 246 301 325 minecraft:light[level=15]
setblock 246 301 333 minecraft:light[level=15]
setblock 246 301 341 minecraft:light[level=15]
setblock 246 301 349 minecraft:light[level=15]
setblock 246 301 357 minecraft:light[level=15]
setblock 254 301 325 minecraft:light[level=15]
setblock 254 301 333 minecraft:light[level=15]
setblock 254 301 341 minecraft:light[level=15]
setblock 254 301 349 minecraft:light[level=15]
setblock 254 301 357 minecraft:light[level=15]
setblock 262 301 325 minecraft:light[level=15]
setblock 262 301 333 minecraft:light[level=15]
setblock 262 301 341 minecraft:light[level=15]
setblock 262 301 349 minecraft:light[level=15]
setblock 262 301 357 minecraft:light[level=15]
setblock 270 301 325 minecraft:light[level=15]
setblock 270 301 333 minecraft:light[level=15]
setblock 270 301 341 minecraft:light[level=15]
setblock 270 301 349 minecraft:light[level=15]
setblock 270 301 357 minecraft:light[level=15]
fill 277 301 335 277 308 335 minecraft:moss_block
setblock 277 301 345 minecraft:red_mushroom_block
fill 235 302 347 235 308 347 minecraft:moss_block
setblock 239 302 322 minecraft:red_mushroom_block
fill 253 302 359 257 302 361 minecraft:red_mushroom_block
fill 254 302 358 256 302 358 minecraft:red_mushroom_block
fill 254 302 362 256 302 362 minecraft:red_mushroom_block
setblock 272 302 322 minecraft:shroomlight
fill 277 302 345 277 308 345 minecraft:moss_block
setblock 277 302 352 minecraft:red_mushroom_block
setblock 238 303 325 minecraft:light[level=12]
setblock 238 303 332 minecraft:light[level=12]
setblock 238 303 339 minecraft:light[level=12]
setblock 238 303 346 minecraft:light[level=12]
setblock 238 303 353 minecraft:light[level=12]
setblock 238 303 360 minecraft:light[level=12]
fill 239 303 322 239 308 322 minecraft:moss_block
setblock 245 303 325 minecraft:light[level=12]
setblock 245 303 332 minecraft:light[level=12]
setblock 245 303 339 minecraft:light[level=12]
setblock 245 303 346 minecraft:light[level=12]
setblock 245 303 353 minecraft:light[level=12]
setblock 245 303 360 minecraft:light[level=12]
setblock 252 303 325 minecraft:light[level=12]
setblock 252 303 332 minecraft:light[level=12]
setblock 252 303 339 minecraft:light[level=12]
setblock 252 303 346 minecraft:light[level=12]
setblock 252 303 353 minecraft:light[level=12]
setblock 252 303 360 minecraft:light[level=12]
setblock 259 303 325 minecraft:light[level=12]
setblock 259 303 332 minecraft:light[level=12]
setblock 259 303 339 minecraft:light[level=12]
setblock 259 303 346 minecraft:light[level=12]
setblock 259 303 353 minecraft:light[level=12]
setblock 259 303 360 minecraft:light[level=12]
setblock 266 303 325 minecraft:light[level=12]
setblock 266 303 332 minecraft:light[level=12]
setblock 266 303 339 minecraft:light[level=12]
setblock 266 303 346 minecraft:light[level=12]
setblock 266 303 353 minecraft:light[level=12]
setblock 266 303 360 minecraft:light[level=12]
fill 272 303 322 272 308 322 minecraft:moss_block
setblock 273 303 325 minecraft:light[level=12]
setblock 273 303 332 minecraft:light[level=12]
setblock 273 303 339 minecraft:light[level=12]
setblock 273 303 346 minecraft:light[level=12]
setblock 273 303 353 minecraft:light[level=12]
setblock 273 303 360 minecraft:light[level=12]
fill 277 303 352 277 308 352 minecraft:moss_block
setblock 273 304 322 minecraft:red_mushroom_block
fill 274 304 322 275 308 322 minecraft:moss_block
setblock 235 305 331 minecraft:shroomlight
fill 235 305 332 235 308 333 minecraft:moss_block
setblock 235 305 346 minecraft:red_mushroom_block
setblock 235 305 358 minecraft:red_mushroom_block
fill 273 305 322 273 308 322 minecraft:moss_block
fill 235 306 331 235 308 331 minecraft:moss_block
fill 235 306 346 235 307 346 minecraft:moss_block
fill 235 306 358 235 308 358 minecraft:moss_block
setblock 238 306 322 minecraft:shroomlight
fill 238 307 322 238 308 322 minecraft:moss_block
setblock 235 308 346 minecraft:red_mushroom_block
