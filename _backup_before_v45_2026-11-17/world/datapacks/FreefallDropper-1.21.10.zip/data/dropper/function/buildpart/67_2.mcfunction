fill 349 206 282 351 208 285 minecraft:oak_leaves[persistent=true]
fill 352 206 283 352 208 284 minecraft:oak_leaves[persistent=true]
fill 360 206 293 360 207 295 minecraft:moss_block
fill 361 206 292 362 207 292 minecraft:moss_block
fill 361 206 294 362 206 295 minecraft:packed_mud
fill 361 206 296 363 207 296 minecraft:moss_block
fill 362 206 293 363 207 293 minecraft:moss_block
setblock 363 206 294 minecraft:packed_mud
fill 363 206 305 364 207 305 minecraft:white_concrete
fill 364 206 304 364 207 304 minecraft:white_concrete
fill 364 206 306 364 207 306 minecraft:white_concrete
fill 371 206 316 371 221 316 minecraft:light_blue_terracotta
fill 346 207 310 350 207 312 minecraft:white_wool
fill 347 207 309 350 208 309 minecraft:white_wool
fill 347 207 313 349 208 313 minecraft:white_wool
fill 348 207 283 348 207 284 minecraft:oak_leaves[persistent=true]
fill 348 207 308 348 208 308 minecraft:white_wool
setblock 352 207 282 minecraft:oak_leaves[persistent=true]
fill 352 207 292 352 212 292 minecraft:packed_mud
fill 353 207 291 353 212 291 minecraft:packed_mud
fill 355 207 275 355 221 275 minecraft:light_blue_terracotta
fill 355 207 293 355 212 293 minecraft:packed_mud
setblock 360 207 296 minecraft:moss_block
fill 361 207 293 361 207 295 minecraft:moss_block
fill 362 207 294 364 207 295 minecraft:moss_block
setblock 371 207 278 minecraft:white_wool
setblock 332 208 278 minecraft:light[level=15]
setblock 332 208 286 minecraft:light[level=15]
setblock 332 208 294 minecraft:light[level=15]
setblock 332 208 302 minecraft:light[level=15]
setblock 332 208 310 minecraft:light[level=15]
setblock 340 208 278 minecraft:light[level=15]
setblock 340 208 286 minecraft:light[level=15]
setblock 340 208 294 minecraft:light[level=15]
setblock 340 208 302 minecraft:light[level=15]
setblock 340 208 310 minecraft:light[level=15]
fill 346 208 311 349 208 312 minecraft:white_wool
fill 347 208 310 350 208 310 minecraft:white_wool
setblock 348 208 278 minecraft:light[level=15]
setblock 348 208 286 minecraft:light[level=15]
setblock 348 208 294 minecraft:light[level=15]
setblock 348 208 302 minecraft:light[level=15]
fill 349 208 292 351 212 292 minecraft:packed_mud
setblock 349 208 308 minecraft:white_wool
fill 350 208 290 352 212 291 minecraft:packed_mud
fill 350 208 293 353 212 293 minecraft:packed_mud
setblock 350 208 311 minecraft:white_wool
fill 351 208 289 357 212 289 minecraft:packed_mud
fill 351 208 294 357 212 294 minecraft:packed_mud
fill 352 208 288 356 212 288 minecraft:packed_mud
fill 352 208 295 357 212 295 minecraft:packed_mud
fill 353 208 290 357 212 290 minecraft:packed_mud
fill 354 208 296 356 212 296 minecraft:packed_mud
setblock 356 208 278 minecraft:light[level=15]
setblock 356 208 286 minecraft:light[level=15]
fill 356 208 291 357 212 293 minecraft:packed_mud
setblock 356 208 302 minecraft:light[level=15]
setblock 356 208 310 minecraft:light[level=15]
setblock 364 208 278 minecraft:light[level=15]
setblock 364 208 286 minecraft:light[level=15]
setblock 364 208 294 minecraft:light[level=15]
setblock 364 208 302 minecraft:light[level=15]
setblock 364 208 310 minecraft:light[level=15]
fill 371 208 278 371 217 278 minecraft:light_blue_terracotta
setblock 371 208 286 minecraft:white_wool
fill 348 209 292 348 210 292 minecraft:packed_mud
fill 349 209 293 349 212 294 minecraft:packed_mud
setblock 349 209 311 minecraft:white_wool
fill 350 209 288 350 211 289 minecraft:packed_mud
fill 350 209 294 350 212 295 minecraft:packed_mud
fill 351 209 287 351 212 288 minecraft:packed_mud
fill 351 209 295 351 214 296 minecraft:packed_mud
fill 352 209 287 356 212 287 minecraft:packed_mud
fill 352 209 296 353 214 296 minecraft:packed_mud
fill 353 209 297 356 211 297 minecraft:packed_mud
fill 355 209 291 355 212 291 minecraft:packed_mud
setblock 356 209 317 minecraft:white_wool
fill 357 209 288 357 212 288 minecraft:packed_mud
fill 357 209 296 357 212 296 minecraft:packed_mud
fill 358 209 289 358 212 295 minecraft:packed_mud
fill 371 209 286 371 221 286 minecraft:light_blue_terracotta
setblock 329 210 300 minecraft:white_wool
setblock 332 210 278 minecraft:light[level=12]
setblock 332 210 285 minecraft:light[level=12]
setblock 332 210 292 minecraft:light[level=12]
setblock 332 210 299 minecraft:light[level=12]
setblock 332 210 306 minecraft:light[level=12]
setblock 332 210 313 minecraft:light[level=12]
setblock 339 210 278 minecraft:light[level=12]
setblock 339 210 285 minecraft:light[level=12]
setblock 339 210 292 minecraft:light[level=12]
setblock 339 210 299 minecraft:light[level=12]
setblock 339 210 306 minecraft:light[level=12]
setblock 339 210 313 minecraft:light[level=12]
setblock 346 210 278 minecraft:light[level=12]
setblock 346 210 285 minecraft:light[level=12]
setblock 346 210 292 minecraft:light[level=12]
setblock 346 210 299 minecraft:light[level=12]
setblock 346 210 306 minecraft:light[level=12]
setblock 346 210 313 minecraft:light[level=12]
fill 348 210 293 348 211 293 minecraft:packed_mud
fill 349 210 290 349 210 291 minecraft:packed_mud
fill 349 210 295 349 212 295 minecraft:packed_mud
fill 350 210 296 350 212 296 minecraft:packed_mud
fill 351 210 297 352 212 297 minecraft:packed_mud
fill 352 210 286 355 211 286 minecraft:packed_mud
setblock 353 210 278 minecraft:light[level=12]
setblock 353 210 285 minecraft:light[level=12]
setblock 353 210 299 minecraft:light[level=12]
setblock 353 210 306 minecraft:light[level=12]
setblock 353 210 313 minecraft:light[level=12]
fill 356 210 317 356 221 317 minecraft:light_blue_terracotta
fill 357 210 287 357 211 287 minecraft:packed_mud
fill 357 210 297 357 211 297 minecraft:packed_mud
fill 358 210 288 358 211 288 minecraft:packed_mud
fill 358 210 296 358 211 296 minecraft:packed_mud
fill 359 210 290 359 211 295 minecraft:packed_mud
setblock 360 210 278 minecraft:light[level=12]
setblock 360 210 285 minecraft:light[level=12]
setblock 360 210 292 minecraft:light[level=12]
setblock 360 210 299 minecraft:light[level=12]
setblock 360 210 306 minecraft:light[level=12]
setblock 360 210 313 minecraft:light[level=12]
setblock 367 210 278 minecraft:light[level=12]
setblock 367 210 285 minecraft:light[level=12]
setblock 367 210 292 minecraft:light[level=12]
setblock 367 210 299 minecraft:light[level=12]
setblock 367 210 306 minecraft:light[level=12]
setblock 367 210 313 minecraft:light[level=12]
fill 329 211 300 329 219 300 minecraft:light_blue_terracotta
setblock 349 211 291 minecraft:packed_mud
setblock 350 212 289 minecraft:packed_mud
fill 353 212 286 354 212 286 minecraft:packed_mud
fill 353 212 297 355 212 297 minecraft:packed_mud
fill 359 212 291 359 212 294 minecraft:packed_mud
setblock 329 213 283 minecraft:white_wool
setblock 329 213 289 minecraft:white_wool
fill 329 213 290 329 221 290 minecraft:light_blue_terracotta
fill 350 213 294 351 214 294 minecraft:packed_mud
fill 351 213 290 351 214 291 minecraft:packed_mud
fill 351 213 293 351 214 293 minecraft:packed_mud
fill 352 213 288 353 214 289 minecraft:packed_mud
fill 352 213 295 353 214 295 minecraft:packed_mud
fill 354 213 288 355 214 288 minecraft:packed_mud
fill 354 213 296 354 214 296 minecraft:packed_mud
fill 355 213 289 356 214 289 minecraft:packed_mud
fill 355 213 295 356 214 295 minecraft:packed_mud
fill 357 213 290 357 214 291 minecraft:packed_mud
fill 357 213 293 357 214 294 minecraft:packed_mud
fill 358 213 291 358 214 293 minecraft:packed_mud
setblock 371 213 314 minecraft:white_wool
fill 329 214 283 329 221 283 minecraft:light_blue_terracotta
fill 329 214 289 329 218 289 minecraft:light_blue_terracotta
fill 331 214 275 331 221 275 minecraft:light_blue_terracotta
setblock 332 214 275 minecraft:white_wool
fill 333 214 275 333 221 275 minecraft:light_blue_terracotta
fill 346 214 290 349 214 294 minecraft:packed_mud
fill 347 214 288 351 214 289 minecraft:packed_mud
fill 347 214 295 350 214 296 minecraft:packed_mud
fill 348 214 286 360 214 287 minecraft:packed_mud
fill 348 214 297 360 214 298 minecraft:packed_mud
fill 350 214 285 358 214 285 minecraft:packed_mud
fill 350 214 290 350 214 293 minecraft:packed_mud
fill 350 214 299 358 214 299 minecraft:packed_mud
fill 352 214 284 356 214 284 minecraft:packed_mud
fill 352 214 300 356 214 300 minecraft:packed_mud
fill 355 214 296 361 214 296 minecraft:packed_mud
fill 356 214 288 361 214 288 minecraft:packed_mud
fill 357 214 289 361 214 289 minecraft:packed_mud
fill 357 214 295 361 214 295 minecraft:packed_mud
fill 358 214 290 362 214 290 minecraft:packed_mud
fill 358 214 294 362 214 294 minecraft:packed_mud
fill 359 214 291 362 214 293 minecraft:packed_mud
fill 371 214 279 371 217 280 minecraft:light_blue_terracotta
setblock 371 214 281 minecraft:white_wool
fill 371 214 314 371 218 314 minecraft:light_blue_terracotta
fill 330 215 276 370 215 277 minecraft:white_stained_glass
fill 330 215 278 370 215 278 minecraft:white_wool
fill 330 215 279 370 215 280 minecraft:white_stained_glass
fill 330 215 281 370 215 281 minecraft:white_wool
fill 330 215 282 370 215 283 minecraft:white_stained_glass
fill 330 215 284 351 215 284 minecraft:white_wool
fill 330 215 285 347 215 286 minecraft:white_stained_glass
fill 330 215 287 347 215 287 minecraft:white_wool
fill 330 215 288 346 215 289 minecraft:white_stained_glass
fill 330 215 290 345 215 290 minecraft:white_wool
fill 330 215 291 345 215 292 minecraft:white_stained_glass
fill 330 215 293 345 215 293 minecraft:white_wool
fill 330 215 294 345 215 295 minecraft:white_stained_glass
fill 330 215 296 346 215 296 minecraft:white_wool
fill 330 215 297 347 215 298 minecraft:white_stained_glass
fill 330 215 299 349 215 299 minecraft:white_wool
fill 330 215 300 351 215 301 minecraft:white_stained_glass
fill 330 215 302 370 215 302 minecraft:white_wool
fill 330 215 303 370 215 304 minecraft:white_stained_glass
fill 330 215 305 370 215 305 minecraft:white_wool
fill 330 215 306 370 215 307 minecraft:white_stained_glass
fill 330 215 308 370 215 308 minecraft:white_wool
fill 330 215 309 370 215 310 minecraft:white_stained_glass
fill 330 215 311 370 215 311 minecraft:white_wool
fill 330 215 312 370 215 313 minecraft:white_stained_glass
fill 330 215 314 370 215 314 minecraft:white_wool
fill 330 215 315 370 215 316 minecraft:white_stained_glass
setblock 330 215 317 minecraft:white_wool
fill 331 215 317 331 218 317 minecraft:light_blue_terracotta
fill 332 215 275 332 219 275 minecraft:light_blue_terracotta
fill 346 215 290 349 215 294 minecraft:moss_block
setblock 346 215 295 minecraft:white_stained_glass
fill 347 215 288 350 215 289 minecraft:moss_block
fill 347 215 295 350 215 296 minecraft:moss_block
fill 348 215 285 349 215 285 minecraft:white_stained_glass
fill 348 215 286 360 215 287 minecraft:moss_block
fill 348 215 297 360 215 298 minecraft:moss_block
fill 350 215 285 358 215 285 minecraft:moss_block
setblock 350 215 290 minecraft:moss_block
fill 350 215 291 350 215 293 minecraft:ochre_froglight
setblock 350 215 294 minecraft:moss_block
fill 350 215 299 358 215 299 minecraft:moss_block
fill 351 215 288 352 215 288 minecraft:moss_block
setblock 351 215 289 minecraft:ochre_froglight
fill 351 215 290 351 215 291 minecraft:sea_lantern
fill 351 215 293 351 215 294 minecraft:sea_lantern
setblock 351 215 295 minecraft:ochre_froglight
fill 351 215 296 352 215 296 minecraft:moss_block
fill 352 215 284 356 215 284 minecraft:moss_block
fill 352 215 289 353 215 289 minecraft:sea_lantern
fill 352 215 295 353 215 295 minecraft:sea_lantern
fill 352 215 300 356 215 300 minecraft:moss_block
fill 352 215 301 370 215 301 minecraft:white_stained_glass
fill 353 215 288 355 215 288 minecraft:ochre_froglight
fill 353 215 296 355 215 296 minecraft:ochre_froglight
fill 355 215 289 356 215 289 minecraft:sea_lantern
fill 355 215 295 356 215 295 minecraft:sea_lantern
fill 356 215 288 361 215 288 minecraft:moss_block
fill 356 215 296 361 215 296 minecraft:moss_block
fill 357 215 284 370 215 284 minecraft:white_wool
setblock 357 215 289 minecraft:ochre_froglight
fill 357 215 290 357 215 291 minecraft:sea_lantern
fill 357 215 293 357 215 294 minecraft:sea_lantern
setblock 357 215 295 minecraft:ochre_froglight
fill 357 215 300 370 215 300 minecraft:white_stained_glass
fill 358 215 289 361 215 290 minecraft:moss_block
fill 358 215 291 358 215 293 minecraft:ochre_froglight
fill 358 215 294 361 215 295 minecraft:moss_block
fill 359 215 285 370 215 285 minecraft:white_stained_glass
fill 359 215 291 362 215 293 minecraft:moss_block
fill 359 215 299 370 215 299 minecraft:white_wool
fill 361 215 286 370 215 286 minecraft:white_stained_glass
fill 361 215 287 370 215 287 minecraft:white_wool
fill 361 215 297 370 215 298 minecraft:white_stained_glass
fill 362 215 288 370 215 289 minecraft:white_stained_glass
setblock 362 215 290 minecraft:moss_block
setblock 362 215 294 minecraft:moss_block
fill 362 215 295 370 215 295 minecraft:white_stained_glass
fill 362 215 296 370 215 296 minecraft:white_wool
fill 363 215 290 370 215 290 minecraft:white_wool
fill 363 215 291 370 215 292 minecraft:white_stained_glass
fill 363 215 293 370 215 293 minecraft:white_wool
fill 363 215 294 370 215 294 minecraft:white_stained_glass
fill 371 215 281 371 221 281 minecraft:light_blue_terracotta
setblock 329 216 282 minecraft:white_wool
setblock 329 216 293 minecraft:white_wool
setblock 330 216 275 minecraft:white_wool
fill 330 216 317 330 221 317 minecraft:light_blue_terracotta
setblock 332 216 278 minecraft:light[level=15]
setblock 332 216 285 minecraft:light[level=12]
setblock 332 216 286 minecraft:light[level=15]
setblock 332 216 292 minecraft:light[level=12]
setblock 332 216 294 minecraft:light[level=15]
setblock 332 216 299 minecraft:light[level=12]
setblock 332 216 302 minecraft:light[level=15]
setblock 332 216 306 minecraft:light[level=12]
setblock 332 216 310 minecraft:light[level=15]
setblock 332 216 313 minecraft:light[level=12]
setblock 338 216 275 minecraft:white_wool
setblock 339 216 278 minecraft:light[level=12]
setblock 339 216 285 minecraft:light[level=12]
setblock 339 216 292 minecraft:light[level=12]
setblock 339 216 299 minecraft:light[level=12]
setblock 339 216 306 minecraft:light[level=12]
setblock 339 216 313 minecraft:light[level=12]
setblock 340 216 278 minecraft:light[level=15]
setblock 340 216 286 minecraft:light[level=15]
setblock 340 216 294 minecraft:light[level=15]
setblock 340 216 302 minecraft:light[level=15]
setblock 340 216 310 minecraft:light[level=15]
setblock 346 216 278 minecraft:light[level=12]
setblock 346 216 285 minecraft:light[level=12]
setblock 346 216 292 minecraft:light[level=12]
setblock 346 216 299 minecraft:light[level=12]
setblock 346 216 306 minecraft:light[level=12]
setblock 346 216 313 minecraft:light[level=12]
fill 347 216 285 349 217 300 minecraft:gray_concrete
setblock 348 216 278 minecraft:light[level=15]
setblock 348 216 302 minecraft:light[level=15]
setblock 348 216 310 minecraft:light[level=15]
fill 350 216 285 362 217 287 minecraft:gray_concrete
fill 350 216 298 362 217 300 minecraft:gray_concrete
setblock 353 216 278 minecraft:light[level=12]
setblock 353 216 306 minecraft:light[level=12]
setblock 353 216 313 minecraft:light[level=12]
setblock 356 216 278 minecraft:light[level=15]
setblock 356 216 302 minecraft:light[level=15]
setblock 356 216 310 minecraft:light[level=15]
setblock 360 216 278 minecraft:light[level=12]
fill 360 216 288 362 217 297 minecraft:gray_concrete
setblock 360 216 306 minecraft:light[level=12]
setblock 360 216 313 minecraft:light[level=12]
setblock 364 216 278 minecraft:light[level=15]
setblock 364 216 286 minecraft:light[level=15]
setblock 364 216 294 minecraft:light[level=15]
setblock 364 216 302 minecraft:light[level=15]
setblock 364 216 310 minecraft:light[level=15]
setblock 367 216 278 minecraft:light[level=12]
setblock 367 216 285 minecraft:light[level=12]
setblock 367 216 292 minecraft:light[level=12]
setblock 367 216 299 minecraft:light[level=12]
setblock 367 216 306 minecraft:light[level=12]
setblock 367 216 313 minecraft:light[level=12]
setblock 371 216 301 minecraft:white_wool
fill 371 216 302 371 219 303 minecraft:light_blue_terracotta
setblock 371 216 308 minecraft:white_wool
fill 371 216 309 371 221 310 minecraft:light_blue_terracotta
setblock 329 217 278 minecraft:white_wool
fill 329 217 279 329 221 279 minecraft:light_blue_terracotta
fill 329 217 282 329 222 282 minecraft:light_blue_terracotta
fill 329 217 293 329 221 293 minecraft:light_blue_terracotta
fill 330 217 275 330 221 275 minecraft:light_blue_terracotta
fill 338 217 275 338 222 275 minecraft:light_blue_terracotta
setblock 355 217 317 minecraft:white_wool
setblock 364 217 275 minecraft:white_wool
setblock 371 217 287 minecraft:white_wool
fill 371 217 301 371 221 301 minecraft:light_blue_terracotta
fill 371 217 308 371 219 308 minecraft:light_blue_terracotta
setblock 329 218 275 minecraft:light_blue_concrete
setblock 329 218 278 minecraft:light_blue_concrete
fill 329 218 305 329 219 305 minecraft:light_blue_concrete
setblock 329 218 312 minecraft:light_blue_concrete
fill 329 218 313 329 221 313 minecraft:light_blue_terracotta
setblock 332 218 317 minecraft:light_blue_concrete
setblock 335 218 275 minecraft:light_blue_concrete
fill 336 218 275 336 221 275 minecraft:light_blue_terracotta
setblock 336 218 317 minecraft:light_blue_concrete
setblock 337 218 275 minecraft:light_blue_concrete
setblock 345 218 275 minecraft:light_blue_concrete
fill 347 218 285 347 230 285 minecraft:gray_concrete
setblock 347 218 286 minecraft:light_blue_stained_glass
fill 347 218 287 362 231 287 minecraft:gray_concrete
setblock 347 218 288 minecraft:light_blue_stained_glass
fill 347 218 289 349 231 289 minecraft:gray_concrete
setblock 347 218 290 minecraft:sea_lantern
fill 347 218 291 349 231 291 minecraft:gray_concrete
setblock 347 218 292 minecraft:light_blue_stained_glass
fill 347 218 293 349 231 293 minecraft:gray_concrete
setblock 347 218 294 minecraft:black_stained_glass
fill 347 218 295 349 231 295 minecraft:gray_concrete
setblock 347 218 296 minecraft:sea_lantern
fill 347 218 297 349 231 297 minecraft:gray_concrete
setblock 347 218 298 minecraft:black_stained_glass
fill 347 218 299 347 231 300 minecraft:gray_concrete
fill 347 218 317 348 218 317 minecraft:light_blue_concrete
setblock 348 218 285 minecraft:black_stained_glass
fill 348 218 286 361 231 286 minecraft:gray_concrete
fill 348 218 288 349 231 288 minecraft:gray_concrete
fill 348 218 290 349 231 290 minecraft:gray_concrete
fill 348 218 292 349 231 292 minecraft:gray_concrete
fill 348 218 294 349 231 294 minecraft:gray_concrete
fill 348 218 296 349 231 296 minecraft:gray_concrete
fill 348 218 298 361 231 299 minecraft:gray_concrete
setblock 348 218 300 minecraft:black_stained_glass
fill 349 218 285 349 230 285 minecraft:gray_concrete
fill 349 218 300 349 231 300 minecraft:gray_concrete
fill 349 218 317 349 221 317 minecraft:light_blue_terracotta
setblock 350 218 285 minecraft:light_blue_stained_glass
setblock 350 218 300 minecraft:light_blue_stained_glass
fill 351 218 285 351 230 285 minecraft:gray_concrete
fill 351 218 300 351 231 300 minecraft:gray_concrete
setblock 352 218 285 minecraft:black_stained_glass
setblock 352 218 300 minecraft:black_stained_glass
fill 353 218 285 353 230 285 minecraft:gray_concrete
fill 353 218 300 353 231 300 minecraft:gray_concrete
setblock 354 218 285 minecraft:black_stained_glass
setblock 354 218 300 minecraft:sea_lantern
fill 355 218 285 355 230 285 minecraft:gray_concrete
fill 355 218 300 355 231 300 minecraft:gray_concrete
fill 355 218 317 355 221 317 minecraft:light_blue_terracotta
setblock 356 218 285 minecraft:light_blue_stained_glass
setblock 356 218 300 minecraft:black_stained_glass
setblock 357 218 275 minecraft:light_blue_concrete
fill 357 218 285 357 230 285 minecraft:gray_concrete
fill 357 218 300 357 231 300 minecraft:gray_concrete
fill 358 218 275 359 218 275 minecraft:light_blue_terracotta
setblock 358 218 285 minecraft:sea_lantern
setblock 358 218 300 minecraft:sea_lantern
fill 358 218 304 361 218 306 minecraft:white_wool
fill 359 218 285 359 230 285 minecraft:gray_concrete
fill 359 218 300 359 231 300 minecraft:gray_concrete
fill 359 218 303 361 218 303 minecraft:white_wool
fill 359 218 307 362 219 307 minecraft:white_wool
setblock 360 218 285 minecraft:black_stained_glass
fill 360 218 288 361 231 297 minecraft:gray_concrete
setblock 360 218 300 minecraft:black_stained_glass
fill 361 218 285 362 230 285 minecraft:gray_concrete
fill 361 218 300 362 231 300 minecraft:gray_concrete
fill 361 218 308 362 218 308 minecraft:white_wool
setblock 362 218 286 minecraft:light_blue_stained_glass
setblock 362 218 288 minecraft:black_stained_glass
fill 362 218 289 362 231 289 minecraft:gray_concrete
setblock 362 218 290 minecraft:black_stained_glass
fill 362 218 291 362 231 291 minecraft:gray_concrete
setblock 362 218 292 minecraft:light_blue_stained_glass
fill 362 218 293 362 231 293 minecraft:gray_concrete
setblock 362 218 294 minecraft:black_stained_glass
fill 362 218 295 362 231 295 minecraft:gray_concrete
setblock 362 218 296 minecraft:light_blue_stained_glass
fill 362 218 297 362 231 297 minecraft:gray_concrete
setblock 362 218 298 minecraft:black_stained_glass
fill 362 218 299 362 231 299 minecraft:gray_concrete
fill 362 218 305 362 219 306 minecraft:white_wool
fill 364 218 275 364 221 275 minecraft:light_blue_terracotta
setblock 364 218 317 minecraft:light_blue_concrete
setblock 370 218 317 minecraft:light_blue_concrete
fill 371 218 278 371 219 278 minecraft:light_blue_concrete
fill 371 218 279 371 221 279 minecraft:light_blue_terracotta
setblock 371 218 280 minecraft:light_blue_concrete
setblock 371 218 282 minecraft:light_blue_concrete
fill 371 218 287 371 221 287 minecraft:light_blue_terracotta
setblock 371 218 295 minecraft:light_blue_concrete
setblock 371 218 296 minecraft:light_blue_terracotta
setblock 371 218 300 minecraft:light_blue_concrete
setblock 371 218 307 minecraft:light_blue_concrete
fill 329 219 275 329 221 275 minecraft:light_blue_terracotta
setblock 329 219 278 minecraft:light_blue_terracotta
setblock 329 219 281 minecraft:light_blue_concrete
setblock 329 219 289 minecraft:light_blue_concrete
fill 329 219 291 329 221 291 minecraft:light_blue_terracotta
setblock 329 219 292 minecraft:light_blue_concrete
fill 329 219 309 329 219 310 minecraft:light_blue_concrete
fill 329 219 312 329 221 312 minecraft:light_blue_terracotta
setblock 329 219 315 minecraft:light_blue_concrete
fill 329 219 316 329 221 317 minecraft:light_blue_terracotta
setblock 331 219 317 minecraft:light_blue_concrete
fill 332 219 317 332 221 317 minecraft:light_blue_terracotta
setblock 334 219 317 minecraft:light_blue_concrete
fill 335 219 275 335 221 275 minecraft:light_blue_terracotta
fill 335 219 317 336 221 317 minecraft:light_blue_terracotta
fill 337 219 275 337 221 275 minecraft:light_blue_terracotta
setblock 337 219 317 minecraft:white_wool
setblock 338 219 317 minecraft:light_blue_concrete
setblock 341 219 317 minecraft:light_blue_concrete
fill 343 219 282 344 220 283 minecraft:white_wool
setblock 344 219 275 minecraft:light_blue_concrete
fill 345 219 275 345 221 275 minecraft:light_blue_terracotta
fill 347 219 286 347 220 286 minecraft:gray_concrete
fill 347 219 288 347 220 288 minecraft:gray_concrete
fill 347 219 290 347 220 290 minecraft:gray_concrete
fill 347 219 292 347 220 292 minecraft:gray_concrete
fill 347 219 294 347 220 294 minecraft:gray_concrete
fill 347 219 296 347 220 296 minecraft:gray_concrete
fill 347 219 298 347 220 298 minecraft:gray_concrete
fill 347 219 317 348 221 317 minecraft:light_blue_terracotta
fill 348 219 285 348 220 285 minecraft:gray_concrete
fill 348 219 300 348 220 300 minecraft:gray_concrete
fill 350 219 285 350 220 285 minecraft:gray_concrete
fill 350 219 300 350 220 300 minecraft:gray_concrete
fill 352 219 278 354 219 279 minecraft:white_concrete
fill 352 219 285 352 220 285 minecraft:gray_concrete
fill 352 219 300 352 220 300 minecraft:gray_concrete
setblock 352 219 317 minecraft:light_blue_concrete
fill 354 219 285 354 220 285 minecraft:gray_concrete
fill 354 219 300 354 220 300 minecraft:gray_concrete
fill 356 219 285 356 220 285 minecraft:gray_concrete
fill 356 219 300 356 220 300 minecraft:gray_concrete
fill 357 219 275 357 221 275 minecraft:light_blue_terracotta
fill 358 219 275 358 220 275 minecraft:light_blue_concrete
fill 358 219 285 358 220 285 minecraft:gray_concrete
fill 358 219 300 358 220 300 minecraft:gray_concrete
fill 358 219 305 361 219 306 minecraft:white_wool
setblock 358 219 317 minecraft:white_wool
setblock 359 219 275 minecraft:light_blue_terracotta
fill 359 219 304 362 219 304 minecraft:white_wool
setblock 360 219 275 minecraft:light_blue_concrete
fill 360 219 285 360 220 285 minecraft:gray_concrete
fill 360 219 300 360 220 300 minecraft:gray_concrete
fill 360 219 303 361 219 303 minecraft:white_wool
fill 361 219 275 361 221 275 minecraft:light_blue_terracotta
fill 362 219 275 363 219 275 minecraft:light_blue_concrete
fill 362 219 286 362 220 286 minecraft:gray_concrete
fill 362 219 288 362 220 288 minecraft:gray_concrete
fill 362 219 290 362 220 290 minecraft:gray_concrete
fill 362 219 292 362 220 292 minecraft:gray_concrete
fill 362 219 294 362 220 294 minecraft:gray_concrete
fill 362 219 296 362 220 296 minecraft:gray_concrete
fill 362 219 298 362 220 298 minecraft:gray_concrete
setblock 362 219 317 minecraft:light_blue_concrete
fill 364 219 317 364 221 317 minecraft:light_blue_terracotta
fill 368 219 275 369 221 275 minecraft:light_blue_terracotta
setblock 370 219 275 minecraft:light_blue_concrete
fill 370 219 317 370 221 317 minecraft:light_blue_terracotta
fill 371 219 276 371 220 276 minecraft:light_blue_concrete
fill 371 219 280 371 221 280 minecraft:light_blue_terracotta
fill 371 219 282 371 221 282 minecraft:light_blue_terracotta
setblock 371 219 295 minecraft:light_blue_terracotta
setblock 371 219 296 minecraft:light_blue_concrete
fill 371 219 300 371 221 300 minecraft:light_blue_terracotta
fill 371 219 307 371 221 307 minecraft:light_blue_terracotta
fill 371 219 313 371 219 314 minecraft:light_blue_concrete
setblock 329 220 276 minecraft:light_blue_concrete
setblock 329 220 278 minecraft:light_blue_concrete
fill 329 220 281 329 221 281 minecraft:light_blue_terracotta
fill 329 220 287 329 221 287 minecraft:light_blue_terracotta
setblock 329 220 288 minecraft:light_blue_concrete
fill 329 220 289 329 221 289 minecraft:light_blue_terracotta
fill 329 220 292 329 221 292 minecraft:light_blue_terracotta
setblock 329 220 300 minecraft:light_blue_concrete
fill 329 220 301 329 221 302 minecraft:light_blue_terracotta
setblock 329 220 303 minecraft:light_blue_concrete
fill 329 220 304 329 221 305 minecraft:light_blue_terracotta
fill 329 220 309 329 221 310 minecraft:light_blue_terracotta
fill 329 220 315 329 221 315 minecraft:light_blue_terracotta
fill 331 220 317 331 221 317 minecraft:light_blue_terracotta
setblock 332 220 275 minecraft:light_blue_concrete
fill 334 220 317 334 223 317 minecraft:light_blue_terracotta
fill 337 220 317 338 221 317 minecraft:light_blue_terracotta
setblock 339 220 275 minecraft:light_blue_concrete
fill 341 220 317 341 221 317 minecraft:light_blue_terracotta
setblock 342 220 317 minecraft:light_blue_concrete
fill 344 220 275 344 221 275 minecraft:light_blue_terracotta
fill 352 220 317 352 221 317 minecraft:light_blue_terracotta
fill 358 220 317 358 221 317 minecraft:light_blue_terracotta
setblock 359 220 275 minecraft:light_blue_concrete
fill 360 220 275 360 222 275 minecraft:light_blue_terracotta
setblock 360 220 306 minecraft:white_wool
fill 362 220 275 363 221 275 minecraft:light_blue_terracotta
fill 362 220 317 362 221 317 minecraft:light_blue_terracotta
fill 370 220 275 370 221 275 minecraft:light_blue_terracotta
fill 371 220 278 371 221 278 minecraft:light_blue_terracotta
setblock 371 220 295 minecraft:light_blue_concrete
fill 371 220 296 371 221 296 minecraft:light_blue_terracotta
fill 371 220 302 371 221 302 minecraft:light_blue_terracotta
setblock 371 220 303 minecraft:light_blue_concrete
setblock 371 220 308 minecraft:light_blue_concrete
fill 371 220 313 371 222 314 minecraft:light_blue_terracotta
setblock 329 221 276 minecraft:light_blue_terracotta
fill 329 221 278 329 222 278 minecraft:light_blue_terracotta
setblock 329 221 284 minecraft:white_wool
setblock 329 221 288 minecraft:light_blue_terracotta
setblock 329 221 300 minecraft:light_blue_terracotta
fill 329 221 303 329 222 303 minecraft:light_blue_terracotta
setblock 332 221 275 minecraft:light_blue_terracotta
setblock 339 221 275 minecraft:light_blue_terracotta
setblock 342 221 317 minecraft:light_blue_terracotta
setblock 347 221 286 minecraft:black_stained_glass
setblock 347 221 288 minecraft:sea_lantern
setblock 347 221 290 minecraft:black_stained_glass
setblock 347 221 292 minecraft:sea_lantern
setblock 347 221 294 minecraft:black_stained_glass
setblock 347 221 296 minecraft:black_stained_glass
setblock 347 221 298 minecraft:light_blue_stained_glass
setblock 348 221 285 minecraft:light_blue_stained_glass
setblock 348 221 300 minecraft:black_stained_glass
setblock 350 221 285 minecraft:sea_lantern
setblock 350 221 300 minecraft:black_stained_glass
setblock 352 221 285 minecraft:light_blue_stained_glass
setblock 352 221 300 minecraft:light_blue_stained_glass
setblock 354 221 285 minecraft:sea_lantern
setblock 354 221 300 minecraft:black_stained_glass
setblock 356 221 285 minecraft:black_stained_glass
setblock 356 221 300 minecraft:black_stained_glass
fill 358 221 275 359 221 275 minecraft:light_blue_terracotta
setblock 358 221 285 minecraft:sea_lantern
setblock 358 221 300 minecraft:black_stained_glass
setblock 360 221 285 minecraft:light_blue_stained_glass
setblock 360 221 300 minecraft:black_stained_glass
setblock 362 221 286 minecraft:light_blue_stained_glass
setblock 362 221 288 minecraft:sea_lantern
setblock 362 221 290 minecraft:light_blue_stained_glass
setblock 362 221 292 minecraft:black_stained_glass
setblock 362 221 294 minecraft:black_stained_glass
setblock 362 221 296 minecraft:black_stained_glass
setblock 362 221 298 minecraft:black_stained_glass
setblock 371 221 276 minecraft:light_blue_terracotta
setblock 371 221 295 minecraft:light_blue_terracotta
setblock 371 221 303 minecraft:light_blue_terracotta
setblock 371 221 308 minecraft:light_blue_terracotta
fill 329 222 275 329 223 277 minecraft:light_blue_concrete
fill 329 222 279 329 222 281 minecraft:light_blue_concrete
fill 329 222 283 329 222 293 minecraft:light_blue_concrete
fill 329 222 295 329 277 296 minecraft:light_blue_concrete
fill 329 222 298 329 224 302 minecraft:light_blue_concrete
fill 329 222 304 329 222 310 minecraft:light_blue_concrete
fill 329 222 312 329 230 317 minecraft:light_blue_concrete
fill 330 222 275 330 256 275 minecraft:light_blue_concrete
fill 330 222 317 332 222 317 minecraft:light_blue_concrete
setblock 331 222 275 minecraft:white_wool
fill 332 222 275 337 222 275 minecraft:light_blue_concrete
setblock 332 222 278 minecraft:light[level=12]
setblock 332 222 285 minecraft:light[level=12]
setblock 332 222 292 minecraft:light[level=12]
setblock 332 222 299 minecraft:light[level=12]
setblock 332 222 306 minecraft:light[level=12]
setblock 332 222 313 minecraft:light[level=12]
fill 335 222 317 347 223 317 minecraft:light_blue_concrete
fill 339 222 275 359 222 275 minecraft:light_blue_concrete
setblock 339 222 278 minecraft:light[level=12]
setblock 339 222 285 minecraft:light[level=12]
setblock 339 222 292 minecraft:light[level=12]
setblock 339 222 299 minecraft:light[level=12]
setblock 339 222 306 minecraft:light[level=12]
setblock 339 222 313 minecraft:light[level=12]
setblock 346 222 278 minecraft:light[level=12]
setblock 346 222 285 minecraft:light[level=12]
setblock 346 222 292 minecraft:light[level=12]
setblock 346 222 299 minecraft:light[level=12]
setblock 346 222 306 minecraft:light[level=12]
setblock 346 222 313 minecraft:light[level=12]
fill 347 222 286 347 223 286 minecraft:gray_concrete
fill 347 222 288 347 223 288 minecraft:gray_concrete
fill 347 222 290 347 223 290 minecraft:gray_concrete
fill 347 222 292 347 223 292 minecraft:gray_concrete
fill 347 222 294 347 223 294 minecraft:gray_concrete
fill 347 222 296 347 223 296 minecraft:gray_concrete
fill 347 222 298 347 223 298 minecraft:gray_concrete
fill 348 222 285 348 223 285 minecraft:gray_concrete
fill 348 222 300 348 223 300 minecraft:gray_concrete
setblock 348 222 317 minecraft:light_blue_terracotta
fill 349 222 317 368 222 317 minecraft:light_blue_concrete
fill 350 222 285 350 223 285 minecraft:gray_concrete
fill 350 222 300 350 223 300 minecraft:gray_concrete
fill 352 222 285 352 223 285 minecraft:gray_concrete
fill 352 222 300 352 223 300 minecraft:gray_concrete
setblock 353 222 278 minecraft:light[level=12]
setblock 353 222 306 minecraft:light[level=12]
setblock 353 222 313 minecraft:light[level=12]
fill 354 222 285 354 223 285 minecraft:gray_concrete
fill 354 222 300 354 223 300 minecraft:gray_concrete
fill 356 222 285 356 223 285 minecraft:gray_concrete
fill 356 222 300 356 223 300 minecraft:gray_concrete
fill 358 222 285 358 223 285 minecraft:gray_concrete
fill 358 222 300 358 223 300 minecraft:gray_concrete
setblock 360 222 278 minecraft:light[level=12]
fill 360 222 285 360 223 285 minecraft:gray_concrete
fill 360 222 300 360 223 300 minecraft:gray_concrete
setblock 360 222 306 minecraft:light[level=12]
setblock 360 222 313 minecraft:light[level=12]
fill 361 222 275 362 297 275 minecraft:light_blue_concrete
fill 362 222 286 362 223 286 minecraft:gray_concrete
fill 362 222 288 362 223 288 minecraft:gray_concrete
fill 362 222 290 362 223 290 minecraft:gray_concrete
fill 362 222 292 362 223 292 minecraft:gray_concrete
fill 362 222 294 362 223 294 minecraft:gray_concrete
fill 362 222 296 362 223 296 minecraft:gray_concrete
fill 362 222 298 362 223 298 minecraft:gray_concrete
setblock 363 222 275 minecraft:light_blue_terracotta
fill 364 222 275 366 254 275 minecraft:light_blue_concrete
setblock 367 222 278 minecraft:light[level=12]
setblock 367 222 285 minecraft:light[level=12]
setblock 367 222 292 minecraft:light[level=12]
setblock 367 222 299 minecraft:light[level=12]
setblock 367 222 306 minecraft:light[level=12]
setblock 367 222 313 minecraft:light[level=12]
fill 368 222 275 371 222 275 minecraft:light_blue_concrete
fill 370 222 317 370 308 317 minecraft:light_blue_concrete
fill 371 222 276 371 222 284 minecraft:light_blue_concrete
fill 371 222 286 371 222 312 minecraft:light_blue_concrete
fill 371 222 316 371 273 316 minecraft:light_blue_concrete
fill 329 223 278 329 255 278 minecraft:light_blue_concrete
fill 329 223 279 329 224 279 minecraft:light_blue_terracotta
fill 329 223 280 329 223 291 minecraft:light_blue_concrete
setblock 329 223 292 minecraft:light_blue_terracotta
fill 329 223 293 329 265 294 minecraft:light_blue_concrete
fill 329 223 297 329 239 297 minecraft:light_blue_concrete
fill 329 223 303 329 223 309 minecraft:light_blue_concrete
setblock 329 223 310 minecraft:light_blue_terracotta
fill 329 223 311 329 292 311 minecraft:light_blue_concrete
fill 330 223 317 331 223 317 minecraft:light_blue_concrete
fill 331 223 275 336 226 275 minecraft:light_blue_concrete
setblock 332 223 317 minecraft:light_blue_terracotta
setblock 337 223 275 minecraft:light_blue_terracotta
fill 338 223 275 339 275 275 minecraft:light_blue_concrete
setblock 340 223 275 minecraft:light_blue_terracotta
fill 341 223 275 345 223 275 minecraft:light_blue_concrete
setblock 346 223 275 minecraft:light_blue_terracotta
fill 347 223 275 348 294 275 minecraft:light_blue_concrete
fill 348 223 317 351 223 317 minecraft:light_blue_concrete
fill 349 223 275 349 224 275 minecraft:light_blue_terracotta
fill 350 223 275 352 230 275 minecraft:light_blue_concrete
setblock 352 223 317 minecraft:light_blue_terracotta
fill 353 223 275 354 223 275 minecraft:light_blue_terracotta
fill 353 223 317 356 244 317 minecraft:light_blue_concrete
fill 355 223 275 357 231 275 minecraft:light_blue_concrete
setblock 357 223 317 minecraft:light_blue_terracotta
setblock 358 223 275 minecraft:light_blue_terracotta
fill 358 223 317 360 223 317 minecraft:light_blue_concrete
fill 359 223 275 360 251 275 minecraft:light_blue_concrete
setblock 361 223 317 minecraft:light_blue_terracotta
fill 362 223 317 365 223 317 minecraft:light_blue_concrete
fill 363 223 275 363 291 275 minecraft:light_blue_concrete
fill 363 223 286 363 227 288 minecraft:dirt
setblock 366 223 317 minecraft:white_wool
fill 367 223 317 368 234 317 minecraft:light_blue_concrete
fill 368 223 275 369 240 275 minecraft:light_blue_concrete
setblock 370 223 275 minecraft:light_blue_terracotta
fill 371 223 275 371 244 281 minecraft:light_blue_concrete
setblock 371 223 282 minecraft:light_blue_terracotta
fill 371 223 283 371 223 291 minecraft:light_blue_concrete
setblock 371 223 292 minecraft:light_blue_terracotta
fill 371 223 293 371 223 296 minecraft:light_blue_concrete
setblock 371 223 297 minecraft:light_blue_terracotta
fill 371 223 298 371 243 302 minecraft:light_blue_concrete
fill 371 223 303 371 223 304 minecraft:light_blue_terracotta
fill 371 223 305 371 223 315 minecraft:light_blue_concrete
fill 371 223 317 371 308 317 minecraft:light_blue_concrete
setblock 329 224 275 minecraft:light_blue_terracotta
fill 329 224 276 329 308 277 minecraft:light_blue_concrete
fill 329 224 280 329 230 280 minecraft:light_blue_concrete
setblock 329 224 281 minecraft:light_blue_terracotta
fill 329 224 282 329 226 283 minecraft:light_blue_concrete
setblock 329 224 284 minecraft:white_wool
fill 329 224 285 329 272 292 minecraft:light_blue_concrete
fill 329 224 303 329 308 303 minecraft:light_blue_concrete
setblock 329 224 304 minecraft:light_blue_terracotta
fill 329 224 305 329 232 310 minecraft:light_blue_concrete
setblock 330 224 317 minecraft:light_blue_terracotta
fill 331 224 317 345 227 317 minecraft:light_blue_concrete
setblock 332 224 278 minecraft:light[level=15]
setblock 332 224 286 minecraft:light[level=15]
setblock 332 224 294 minecraft:light[level=15]
setblock 332 224 302 minecraft:light[level=15]
setblock 332 224 310 minecraft:light[level=15]
fill 337 224 275 337 260 275 minecraft:light_blue_concrete
fill 340 224 275 344 234 275 minecraft:light_blue_concrete
setblock 340 224 278 minecraft:light[level=15]
setblock 340 224 286 minecraft:light[level=15]
setblock 340 224 294 minecraft:light[level=15]
setblock 340 224 302 minecraft:light[level=15]
setblock 340 224 310 minecraft:light[level=15]
setblock 345 224 275 minecraft:light_blue_terracotta
fill 346 224 275 346 263 275 minecraft:light_blue_concrete
setblock 346 224 317 minecraft:light_blue_terracotta
setblock 347 224 286 minecraft:light_blue_stained_glass
setblock 347 224 288 minecraft:black_stained_glass
setblock 347 224 290 minecraft:light_blue_stained_glass
setblock 347 224 292 minecraft:black_stained_glass
setblock 347 224 294 minecraft:light_blue_stained_glass
setblock 347 224 296 minecraft:sea_lantern
setblock 347 224 298 minecraft:sea_lantern
fill 347 224 317 348 303 317 minecraft:light_blue_concrete
setblock 348 224 278 minecraft:light[level=15]
setblock 348 224 285 minecraft:light_blue_stained_glass
setblock 348 224 300 minecraft:light_blue_stained_glass
setblock 348 224 302 minecraft:light[level=15]
setblock 348 224 310 minecraft:light[level=15]
setblock 349 224 317 minecraft:white_wool
setblock 350 224 285 minecraft:black_stained_glass
setblock 350 224 300 minecraft:black_stained_glass
fill 350 224 317 352 229 317 minecraft:light_blue_concrete
setblock 352 224 285 minecraft:black_stained_glass
setblock 352 224 300 minecraft:sea_lantern
fill 353 224 275 354 239 275 minecraft:light_blue_concrete
setblock 354 224 285 minecraft:black_stained_glass
setblock 354 224 300 minecraft:sea_lantern
setblock 356 224 278 minecraft:light[level=15]
setblock 356 224 285 minecraft:black_stained_glass
setblock 356 224 300 minecraft:black_stained_glass
setblock 356 224 302 minecraft:light[level=15]
setblock 356 224 310 minecraft:light[level=15]
fill 357 224 317 357 291 317 minecraft:light_blue_concrete
fill 358 224 275 358 308 275 minecraft:light_blue_concrete
setblock 358 224 285 minecraft:light_blue_stained_glass
setblock 358 224 300 minecraft:black_stained_glass
setblock 358 224 317 minecraft:light_blue_terracotta
fill 359 224 317 361 237 317 minecraft:light_blue_concrete
fill 360 224 284 361 227 284 minecraft:dirt
setblock 360 224 285 minecraft:sea_lantern
setblock 360 224 300 minecraft:sea_lantern
setblock 362 224 286 minecraft:light_blue_stained_glass
setblock 362 224 288 minecraft:light_blue_stained_glass
setblock 362 224 290 minecraft:light_blue_stained_glass
setblock 362 224 292 minecraft:light_blue_stained_glass
setblock 362 224 294 minecraft:black_stained_glass
setblock 362 224 296 minecraft:black_stained_glass
setblock 362 224 298 minecraft:black_stained_glass
setblock 362 224 317 minecraft:light_blue_terracotta
fill 363 224 289 363 227 289 minecraft:dirt
fill 363 224 317 363 308 317 minecraft:light_blue_concrete
setblock 364 224 278 minecraft:light[level=15]
setblock 364 224 286 minecraft:light[level=15]
setblock 364 224 294 minecraft:light[level=15]
setblock 364 224 302 minecraft:light[level=15]
setblock 364 224 310 minecraft:light[level=15]
fill 364 224 317 365 224 317 minecraft:light_blue_terracotta
fill 366 224 317 366 308 317 minecraft:light_blue_concrete
fill 367 224 275 367 259 275 minecraft:light_blue_concrete
fill 370 224 275 370 281 275 minecraft:light_blue_concrete
setblock 371 224 282 minecraft:white_wool
fill 371 224 283 371 308 284 minecraft:light_blue_concrete
setblock 371 224 285 minecraft:light_blue_terracotta
fill 371 224 286 371 225 294 minecraft:light_blue_concrete
setblock 371 224 295 minecraft:light_blue_terracotta
fill 371 224 296 371 262 297 minecraft:light_blue_concrete
fill 371 224 303 371 231 307 minecraft:light_blue_concrete
setblock 371 224 308 minecraft:white_wool
setblock 371 224 309 minecraft:light_blue_terracotta
fill 371 224 310 371 227 315 minecraft:light_blue_concrete
fill 329 225 275 329 308 275 minecraft:light_blue_concrete
fill 329 225 279 329 230 279 minecraft:light_blue_concrete
fill 329 225 281 329 308 281 minecraft:light_blue_concrete
fill 329 225 284 329 262 284 minecraft:light_blue_concrete
setblock 329 225 298 minecraft:white_wool
fill 329 225 299 329 253 302 minecraft:light_blue_concrete
fill 329 225 304 329 308 304 minecraft:light_blue_concrete
fill 330 225 317 330 252 317 minecraft:light_blue_concrete
fill 345 225 275 345 264 275 minecraft:light_blue_concrete
fill 346 225 317 346 308 317 minecraft:light_blue_concrete
fill 347 225 286 347 226 286 minecraft:gray_concrete
fill 347 225 288 347 226 288 minecraft:gray_concrete
fill 347 225 290 347 226 290 minecraft:gray_concrete
fill 347 225 292 347 226 292 minecraft:gray_concrete
fill 347 225 294 347 226 294 minecraft:gray_concrete
fill 347 225 296 347 226 296 minecraft:gray_concrete
fill 347 225 298 347 226 298 minecraft:gray_concrete
fill 348 225 285 348 226 285 minecraft:gray_concrete
fill 348 225 300 348 226 300 minecraft:gray_concrete
fill 349 225 275 349 308 275 minecraft:light_blue_concrete
fill 349 225 317 349 308 317 minecraft:light_blue_concrete
fill 350 225 285 350 226 285 minecraft:gray_concrete
fill 350 225 300 350 226 300 minecraft:gray_concrete
fill 352 225 281 352 226 281 minecraft:ochre_froglight
fill 352 225 285 352 226 285 minecraft:gray_concrete
fill 352 225 300 352 226 300 minecraft:gray_concrete
fill 354 225 285 354 226 285 minecraft:gray_concrete
fill 354 225 300 354 226 300 minecraft:gray_concrete
fill 356 225 285 356 226 285 minecraft:gray_concrete
fill 356 225 300 356 226 300 minecraft:gray_concrete
fill 358 225 284 359 227 284 minecraft:dirt
fill 358 225 285 358 226 285 minecraft:gray_concrete
fill 358 225 300 358 226 300 minecraft:gray_concrete
fill 358 225 317 358 291 317 minecraft:light_blue_concrete
fill 360 225 285 360 226 285 minecraft:gray_concrete
fill 360 225 300 360 226 300 minecraft:gray_concrete
fill 362 225 284 362 227 284 minecraft:dirt
fill 362 225 286 362 226 286 minecraft:gray_concrete
fill 362 225 288 362 226 288 minecraft:gray_concrete
fill 362 225 290 362 226 290 minecraft:gray_concrete
fill 362 225 292 362 226 292 minecraft:gray_concrete
fill 362 225 294 362 226 294 minecraft:gray_concrete
fill 362 225 296 362 226 296 minecraft:gray_concrete
fill 362 225 298 362 226 298 minecraft:gray_concrete
fill 362 225 317 362 308 317 minecraft:light_blue_concrete
fill 363 225 285 363 227 285 minecraft:dirt
fill 363 225 290 363 227 290 minecraft:dirt
fill 364 225 286 364 227 289 minecraft:dirt
fill 364 225 317 365 270 317 minecraft:light_blue_concrete
fill 369 225 317 369 308 317 minecraft:light_blue_concrete
fill 371 225 282 371 261 282 minecraft:light_blue_concrete
fill 371 225 285 371 308 285 minecraft:light_blue_concrete
fill 371 225 295 371 308 295 minecraft:light_blue_concrete
fill 371 225 308 371 294 309 minecraft:light_blue_concrete
fill 329 226 298 329 308 298 minecraft:light_blue_concrete
fill 356 226 284 356 227 284 minecraft:ochre_froglight
fill 359 226 283 361 227 283 minecraft:dirt
fill 363 226 284 363 227 284 minecraft:dirt
fill 363 226 291 363 227 291 minecraft:dirt
fill 364 226 285 364 227 285 minecraft:dirt
fill 364 226 290 364 227 290 minecraft:dirt
fill 371 226 286 371 227 288 minecraft:light_blue_concrete
setblock 371 226 289 minecraft:white_wool
fill 371 226 290 371 232 294 minecraft:light_blue_concrete
fill 329 227 282 329 308 282 minecraft:light_blue_concrete
setblock 329 227 283 minecraft:white_wool
fill 331 227 275 333 241 275 minecraft:light_blue_concrete
setblock 334 227 275 minecraft:white_wool
fill 335 227 275 336 252 275 minecraft:light_blue_concrete
setblock 347 227 286 minecraft:black_stained_glass
setblock 347 227 288 minecraft:black_stained_glass
setblock 347 227 290 minecraft:black_stained_glass
setblock 347 227 292 minecraft:sea_lantern
setblock 347 227 294 minecraft:black_stained_glass
setblock 347 227 296 minecraft:light_blue_stained_glass
setblock 347 227 298 minecraft:black_stained_glass
setblock 348 227 285 minecraft:sea_lantern
setblock 348 227 300 minecraft:black_stained_glass
setblock 350 227 285 minecraft:light_blue_stained_glass
setblock 350 227 300 minecraft:black_stained_glass
fill 352 227 281 352 233 281 minecraft:dirt
setblock 352 227 285 minecraft:sea_lantern
setblock 352 227 300 minecraft:black_stained_glass
setblock 354 227 285 minecraft:sea_lantern
setblock 354 227 300 minecraft:black_stained_glass
setblock 356 227 285 minecraft:black_stained_glass
setblock 356 227 300 minecraft:black_stained_glass
setblock 357 227 284 minecraft:dirt
setblock 358 227 283 minecraft:dirt
setblock 358 227 285 minecraft:light_blue_stained_glass
setblock 358 227 300 minecraft:black_stained_glass
setblock 360 227 285 minecraft:light_blue_stained_glass
setblock 360 227 300 minecraft:black_stained_glass
setblock 362 227 283 minecraft:dirt
setblock 362 227 286 minecraft:black_stained_glass
setblock 362 227 288 minecraft:sea_lantern
setblock 362 227 290 minecraft:sea_lantern
setblock 362 227 292 minecraft:black_stained_glass
setblock 362 227 294 minecraft:sea_lantern
setblock 362 227 296 minecraft:sea_lantern
setblock 362 227 298 minecraft:black_stained_glass
setblock 364 227 284 minecraft:dirt
fill 365 227 286 365 227 289 minecraft:dirt
fill 371 227 289 371 236 289 minecraft:light_blue_concrete
fill 329 228 283 329 308 283 minecraft:light_blue_concrete
fill 331 228 317 343 228 317 minecraft:light_blue_concrete
setblock 332 228 278 minecraft:light[level=12]
setblock 332 228 285 minecraft:light[level=12]
setblock 332 228 292 minecraft:light[level=12]
setblock 332 228 299 minecraft:light[level=12]
setblock 332 228 306 minecraft:light[level=12]
setblock 332 228 313 minecraft:light[level=12]
fill 334 228 275 334 260 275 minecraft:light_blue_concrete
setblock 339 228 278 minecraft:light[level=12]
setblock 339 228 285 minecraft:light[level=12]
setblock 339 228 292 minecraft:light[level=12]
setblock 339 228 299 minecraft:light[level=12]
setblock 339 228 306 minecraft:light[level=12]
setblock 339 228 313 minecraft:light[level=12]
setblock 344 228 317 minecraft:white_wool
fill 345 228 317 345 243 317 minecraft:light_blue_concrete
setblock 346 228 278 minecraft:light[level=12]
setblock 346 228 285 minecraft:light[level=12]
setblock 346 228 292 minecraft:light[level=12]
setblock 346 228 299 minecraft:light[level=12]
setblock 346 228 306 minecraft:light[level=12]
setblock 346 228 313 minecraft:light[level=12]
fill 347 228 286 347 231 286 minecraft:gray_concrete
fill 347 228 288 347 231 288 minecraft:gray_concrete
fill 347 228 290 347 231 290 minecraft:gray_concrete
fill 347 228 292 347 231 292 minecraft:gray_concrete
fill 347 228 294 347 231 294 minecraft:gray_concrete
fill 347 228 296 347 231 296 minecraft:gray_concrete
fill 347 228 298 347 231 298 minecraft:gray_concrete
fill 348 228 285 348 230 285 minecraft:gray_concrete
fill 348 228 300 348 231 300 minecraft:gray_concrete
fill 350 228 285 350 230 285 minecraft:gray_concrete
fill 350 228 300 350 231 300 minecraft:gray_concrete
fill 352 228 282 352 233 282 minecraft:dirt
fill 352 228 285 352 230 285 minecraft:gray_concrete
fill 352 228 300 352 231 300 minecraft:gray_concrete
setblock 353 228 278 minecraft:light[level=12]
setblock 353 228 306 minecraft:light[level=12]
setblock 353 228 313 minecraft:light[level=12]
fill 354 228 285 354 230 285 minecraft:gray_concrete
fill 354 228 300 354 231 300 minecraft:gray_concrete
fill 356 228 284 356 236 284 minecraft:dirt
fill 356 228 285 356 230 285 minecraft:gray_concrete
fill 356 228 300 356 231 300 minecraft:gray_concrete
fill 358 228 285 358 230 285 minecraft:gray_concrete
fill 358 228 300 358 231 300 minecraft:gray_concrete
setblock 360 228 278 minecraft:light[level=12]
fill 360 228 285 360 230 285 minecraft:gray_concrete
fill 360 228 300 360 231 300 minecraft:gray_concrete
setblock 360 228 306 minecraft:light[level=12]
setblock 360 228 313 minecraft:light[level=12]
fill 362 228 286 362 231 286 minecraft:gray_concrete
fill 362 228 288 362 231 288 minecraft:gray_concrete
fill 362 228 290 362 231 290 minecraft:gray_concrete
fill 362 228 292 362 231 292 minecraft:gray_concrete
fill 362 228 294 362 231 294 minecraft:gray_concrete
fill 362 228 296 362 231 296 minecraft:gray_concrete
fill 362 228 298 362 231 298 minecraft:gray_concrete
setblock 367 228 278 minecraft:light[level=12]
setblock 367 228 285 minecraft:light[level=12]
setblock 367 228 292 minecraft:light[level=12]
setblock 367 228 299 minecraft:light[level=12]
setblock 367 228 306 minecraft:light[level=12]
setblock 367 228 313 minecraft:light[level=12]
fill 371 228 286 371 236 287 minecraft:light_blue_concrete
setblock 371 228 288 minecraft:white_wool
fill 371 228 310 371 308 310 minecraft:light_blue_concrete
setblock 371 228 311 minecraft:white_wool
fill 371 228 312 371 294 315 minecraft:light_blue_concrete
fill 331 229 317 334 267 317 minecraft:light_blue_concrete
setblock 335 229 317 minecraft:white_wool
fill 336 229 317 344 247 317 minecraft:light_blue_concrete
fill 351 229 281 351 233 282 minecraft:dirt
fill 353 229 281 353 233 282 minecraft:dirt
fill 371 229 288 371 262 288 minecraft:light_blue_concrete
fill 371 229 311 371 255 311 minecraft:light_blue_concrete
fill 335 230 317 335 248 317 minecraft:light_blue_concrete
fill 350 230 317 350 308 317 minecraft:light_blue_concrete
fill 351 230 280 353 233 280 minecraft:dirt
setblock 351 230 317 minecraft:white_wool
fill 352 230 283 352 233 283 minecraft:dirt
fill 352 230 317 352 240 317 minecraft:light_blue_concrete
fill 355 230 284 355 236 284 minecraft:dirt
fill 356 230 283 356 236 283 minecraft:dirt
fill 329 231 279 329 231 280 minecraft:white_wool
fill 329 231 312 329 290 314 minecraft:light_blue_concrete
setblock 329 231 315 minecraft:white_wool
fill 329 231 316 329 257 317 minecraft:light_blue_concrete
fill 343 231 305 343 232 305 minecraft:ochre_froglight
fill 347 231 285 362 231 285 minecraft:yellow_concrete
fill 350 231 275 350 238 275 minecraft:light_blue_concrete
fill 350 231 281 350 233 282 minecraft:dirt
setblock 351 231 275 minecraft:white_wool
fill 351 231 283 351 233 283 minecraft:dirt
fill 351 231 317 351 282 317 minecraft:light_blue_concrete
fill 352 231 275 352 289 275 minecraft:light_blue_concrete
fill 353 231 283 353 236 283 minecraft:dirt
fill 354 231 281 354 233 282 minecraft:dirt
fill 355 231 283 355 236 283 minecraft:dirt
fill 357 231 283 357 236 284 minecraft:dirt
fill 329 232 279 329 294 280 minecraft:light_blue_concrete
fill 329 232 315 329 308 315 minecraft:light_blue_concrete
setblock 332 232 278 minecraft:light[level=15]
setblock 332 232 286 minecraft:light[level=15]
setblock 332 232 294 minecraft:light[level=15]
setblock 332 232 302 minecraft:light[level=15]
setblock 332 232 310 minecraft:light[level=15]
setblock 340 232 278 minecraft:light[level=15]
setblock 340 232 286 minecraft:light[level=15]
setblock 340 232 294 minecraft:light[level=15]
setblock 340 232 302 minecraft:light[level=15]
setblock 340 232 310 minecraft:light[level=15]
setblock 348 232 278 minecraft:light[level=15]
setblock 348 232 286 minecraft:light[level=15]
setblock 348 232 294 minecraft:light[level=15]
setblock 348 232 302 minecraft:light[level=15]
setblock 348 232 310 minecraft:light[level=15]
fill 350 232 280 350 233 280 minecraft:dirt
fill 350 232 283 350 233 283 minecraft:dirt
fill 351 232 275 351 308 275 minecraft:light_blue_concrete
fill 351 232 279 353 233 279 minecraft:dirt
fill 352 232 284 352 233 284 minecraft:dirt
fill 354 232 280 354 233 280 minecraft:dirt
fill 354 232 283 354 236 284 minecraft:dirt
fill 355 232 275 355 308 275 minecraft:light_blue_concrete
fill 355 232 285 357 236 285 minecraft:dirt
setblock 356 232 275 minecraft:white_wool
setblock 356 232 278 minecraft:light[level=15]
fill 356 232 282 356 236 282 minecraft:dirt
setblock 356 232 286 minecraft:light[level=15]
setblock 356 232 302 minecraft:light[level=15]
setblock 356 232 310 minecraft:light[level=15]
fill 357 232 275 357 308 275 minecraft:light_blue_concrete
fill 358 232 287 362 232 287 minecraft:oak_leaves[persistent=true]
fill 359 232 286 362 232 286 minecraft:oak_leaves[persistent=true]
fill 360 232 288 362 232 289 minecraft:oak_leaves[persistent=true]
setblock 364 232 278 minecraft:light[level=15]
setblock 364 232 286 minecraft:light[level=15]
setblock 364 232 294 minecraft:light[level=15]
setblock 364 232 302 minecraft:light[level=15]
setblock 364 232 310 minecraft:light[level=15]
fill 371 232 303 371 255 303 minecraft:light_blue_concrete
setblock 371 232 304 minecraft:white_wool
fill 371 232 305 371 308 307 minecraft:light_blue_concrete
fill 329 233 305 329 238 306 minecraft:light_blue_concrete
setblock 329 233 307 minecraft:white_wool
fill 329 233 308 329 308 310 minecraft:light_blue_concrete
fill 343 233 305 343 241 305 minecraft:dirt
fill 349 233 281 349 233 282 minecraft:dirt
setblock 350 233 279 minecraft:dirt
setblock 351 233 284 minecraft:dirt
fill 353 233 284 353 236 284 minecraft:dirt
setblock 354 233 279 minecraft:dirt
fill 354 233 285 354 236 285 minecraft:dirt
fill 355 233 281 355 233 282 minecraft:dirt
fill 355 233 286 357 236 286 minecraft:dirt
fill 356 233 275 356 308 275 minecraft:light_blue_concrete
fill 357 233 282 357 236 282 minecraft:dirt
fill 358 233 283 358 236 285 minecraft:dirt
fill 359 233 286 361 233 288 minecraft:oak_leaves[persistent=true]
fill 360 233 289 361 233 289 minecraft:oak_leaves[persistent=true]
fill 362 233 287 362 233 288 minecraft:oak_leaves[persistent=true]
fill 371 233 290 371 239 292 minecraft:light_blue_concrete
setblock 371 233 293 minecraft:white_wool
fill 371 233 294 371 274 294 minecraft:light_blue_concrete
fill 371 233 304 371 308 304 minecraft:light_blue_concrete
fill 329 234 307 329 270 307 minecraft:light_blue_concrete
setblock 332 234 278 minecraft:light[level=12]
setblock 332 234 285 minecraft:light[level=12]
setblock 332 234 292 minecraft:light[level=12]
setblock 332 234 299 minecraft:light[level=12]
setblock 332 234 306 minecraft:light[level=12]
setblock 332 234 313 minecraft:light[level=12]
setblock 339 234 278 minecraft:light[level=12]
setblock 339 234 285 minecraft:light[level=12]
setblock 339 234 292 minecraft:light[level=12]
setblock 339 234 299 minecraft:light[level=12]
setblock 339 234 306 minecraft:light[level=12]
setblock 339 234 313 minecraft:light[level=12]
fill 341 234 297 341 235 297 minecraft:white_wool
fill 343 234 304 343 241 304 minecraft:dirt
setblock 346 234 278 minecraft:light[level=12]
setblock 346 234 285 minecraft:light[level=12]
setblock 346 234 292 minecraft:light[level=12]
setblock 346 234 299 minecraft:light[level=12]
setblock 346 234 306 minecraft:light[level=12]
setblock 346 234 313 minecraft:light[level=12]
fill 352 234 281 352 236 281 minecraft:iron_block
setblock 353 234 278 minecraft:light[level=12]
setblock 353 234 285 minecraft:light[level=12]
setblock 353 234 299 minecraft:light[level=12]
setblock 353 234 306 minecraft:light[level=12]
setblock 353 234 313 minecraft:light[level=12]
fill 354 234 282 355 236 282 minecraft:dirt
fill 354 234 286 354 236 286 minecraft:dirt
fill 356 234 281 356 236 281 minecraft:dirt
fill 358 234 282 358 236 282 minecraft:dirt
setblock 360 234 278 minecraft:light[level=12]
setblock 360 234 285 minecraft:light[level=12]
setblock 360 234 292 minecraft:light[level=12]
setblock 360 234 299 minecraft:light[level=12]
setblock 360 234 306 minecraft:light[level=12]
setblock 360 234 313 minecraft:light[level=12]
setblock 367 234 278 minecraft:light[level=12]
setblock 367 234 285 minecraft:light[level=12]
setblock 367 234 292 minecraft:light[level=12]
setblock 367 234 299 minecraft:light[level=12]
setblock 367 234 306 minecraft:light[level=12]
setblock 367 234 313 minecraft:light[level=12]
fill 371 234 293 371 308 293 minecraft:light_blue_concrete
fill 340 235 275 340 308 275 minecraft:light_blue_concrete
setblock 341 235 275 minecraft:white_wool
fill 342 235 275 344 256 275 minecraft:light_blue_concrete
fill 342 235 304 342 241 305 minecraft:dirt
fill 343 235 306 343 241 306 minecraft:dirt
fill 344 235 304 344 241 305 minecraft:dirt
fill 344 235 307 344 236 308 minecraft:white_wool
fill 353 235 282 353 236 282 minecraft:dirt
fill 353 235 285 353 236 285 minecraft:dirt
fill 354 235 281 355 236 281 minecraft:dirt
fill 355 235 287 357 236 287 minecraft:dirt
fill 357 235 281 357 236 281 minecraft:dirt
fill 358 235 286 358 236 286 minecraft:dirt
fill 359 235 283 359 236 285 minecraft:dirt
setblock 367 235 317 minecraft:white_wool
fill 368 235 317 368 247 317 minecraft:light_blue_concrete
fill 330 236 281 330 237 283 minecraft:white_concrete
fill 341 236 275 341 302 275 minecraft:light_blue_concrete
fill 342 236 306 342 241 306 minecraft:dirt
fill 343 236 303 343 241 303 minecraft:dirt
fill 344 236 306 344 241 306 minecraft:dirt
fill 352 236 283 352 236 284 minecraft:dirt
setblock 353 236 286 minecraft:dirt
setblock 354 236 287 minecraft:dirt
setblock 356 236 280 minecraft:dirt
setblock 358 236 281 minecraft:dirt
setblock 358 236 287 minecraft:dirt
setblock 359 236 282 minecraft:dirt
setblock 359 236 286 minecraft:dirt
fill 367 236 317 367 279 317 minecraft:light_blue_concrete
fill 369 236 281 370 237 283 minecraft:white_concrete
fill 331 237 281 331 238 283 minecraft:white_concrete
fill 332 237 282 332 239 282 minecraft:white_concrete
fill 341 237 304 341 241 305 minecraft:dirt
fill 342 237 303 342 241 303 minecraft:dirt
fill 343 237 307 343 241 307 minecraft:dirt
fill 344 237 303 344 241 303 minecraft:dirt
fill 345 237 304 345 241 305 minecraft:dirt
fill 356 237 284 356 240 284 minecraft:white_concrete
fill 367 237 282 368 239 282 minecraft:white_concrete
fill 368 237 281 368 238 281 minecraft:white_concrete
fill 368 237 283 368 238 283 minecraft:white_concrete
fill 371 237 286 371 308 286 minecraft:light_blue_concrete
setblock 371 237 287 minecraft:white_wool
setblock 371 237 289 minecraft:white_wool
setblock 330 238 282 minecraft:white_concrete
fill 332 238 281 332 239 281 minecraft:white_concrete
fill 332 238 283 332 239 283 minecraft:white_concrete
fill 333 238 282 333 240 282 minecraft:white_concrete
fill 341 238 303 341 241 303 minecraft:dirt
fill 341 238 306 341 241 306 minecraft:dirt
fill 342 238 307 342 241 307 minecraft:dirt
fill 344 238 288 344 239 288 minecraft:white_concrete
fill 344 238 307 344 241 307 minecraft:dirt
fill 345 238 303 345 241 303 minecraft:dirt
fill 345 238 306 345 241 306 minecraft:dirt
setblock 352 238 281 minecraft:ochre_froglight
fill 359 238 299 359 239 300 minecraft:white_wool
fill 359 238 317 360 247 317 minecraft:light_blue_concrete
setblock 361 238 317 minecraft:white_wool
fill 366 238 282 366 240 282 minecraft:white_concrete
fill 367 238 281 367 239 281 minecraft:white_concrete
fill 367 238 283 367 239 283 minecraft:white_concrete
setblock 369 238 282 minecraft:white_concrete
setblock 370 238 282 minecraft:yellow_concrete
fill 371 238 287 371 257 287 minecraft:light_blue_concrete
fill 371 238 289 371 248 289 minecraft:light_blue_concrete
fill 329 239 305 329 243 305 minecraft:light_blue_concrete
setblock 329 239 306 minecraft:white_wool
setblock 330 239 282 minecraft:yellow_concrete
setblock 331 239 282 minecraft:white_concrete
fill 333 239 281 334 240 281 minecraft:white_concrete
fill 333 239 283 334 240 283 minecraft:white_concrete
fill 334 239 282 334 241 282 minecraft:white_concrete
fill 340 239 304 340 241 305 minecraft:dirt
fill 341 239 307 341 241 307 minecraft:dirt
fill 342 239 302 344 241 302 minecraft:dirt
fill 345 239 307 345 241 307 minecraft:dirt
fill 346 239 304 346 241 306 minecraft:dirt
setblock 350 239 275 minecraft:white_wool
fill 361 239 317 361 243 317 minecraft:light_blue_concrete
fill 365 239 281 365 240 283 minecraft:white_concrete
fill 366 239 281 366 240 281 minecraft:white_concrete
fill 366 239 283 366 240 283 minecraft:white_concrete
setblock 369 239 282 minecraft:yellow_concrete
setblock 329 240 297 minecraft:white_wool
fill 329 240 306 329 308 306 minecraft:light_blue_concrete
setblock 332 240 278 minecraft:light[level=15]
setblock 332 240 282 minecraft:yellow_concrete
setblock 332 240 285 minecraft:light[level=12]
setblock 332 240 286 minecraft:light[level=15]
setblock 332 240 292 minecraft:light[level=12]
setblock 332 240 294 minecraft:light[level=15]
setblock 332 240 299 minecraft:light[level=12]
setblock 332 240 302 minecraft:light[level=15]
setblock 332 240 306 minecraft:light[level=12]
setblock 332 240 310 minecraft:light[level=15]
setblock 332 240 313 minecraft:light[level=12]
fill 335 240 281 335 241 283 minecraft:white_concrete
fill 336 240 282 336 242 282 minecraft:white_concrete
setblock 339 240 278 minecraft:light[level=12]
setblock 339 240 285 minecraft:light[level=12]
setblock 339 240 292 minecraft:light[level=12]
setblock 339 240 299 minecraft:light[level=12]
setblock 339 240 306 minecraft:light[level=12]
setblock 339 240 313 minecraft:light[level=12]
setblock 340 240 278 minecraft:light[level=15]
setblock 340 240 286 minecraft:light[level=15]
setblock 340 240 294 minecraft:light[level=15]
setblock 340 240 302 minecraft:light[level=15]
fill 340 240 303 340 241 303 minecraft:dirt
fill 340 240 306 340 241 306 minecraft:dirt
setblock 340 240 310 minecraft:light[level=15]
fill 341 240 302 341 241 302 minecraft:dirt
fill 342 240 308 344 241 308 minecraft:dirt
fill 345 240 302 345 241 302 minecraft:dirt
setblock 346 240 278 minecraft:light[level=12]
setblock 346 240 285 minecraft:light[level=12]
setblock 346 240 292 minecraft:light[level=12]
setblock 346 240 299 minecraft:light[level=12]
fill 346 240 303 346 241 303 minecraft:dirt
setblock 346 240 313 minecraft:light[level=12]
setblock 348 240 278 minecraft:light[level=15]
setblock 348 240 286 minecraft:light[level=15]
setblock 348 240 294 minecraft:light[level=15]
setblock 348 240 302 minecraft:light[level=15]
setblock 348 240 310 minecraft:light[level=15]
fill 350 240 275 350 308 275 minecraft:light_blue_concrete
setblock 353 240 275 minecraft:white_wool
setblock 353 240 278 minecraft:light[level=12]
setblock 353 240 285 minecraft:light[level=12]
setblock 353 240 299 minecraft:light[level=12]
setblock 353 240 306 minecraft:light[level=12]
setblock 353 240 313 minecraft:light[level=12]
fill 354 240 275 354 308 275 minecraft:light_blue_concrete
fill 354 240 284 355 242 284 minecraft:oak_leaves[persistent=true]
fill 355 240 283 357 242 283 minecraft:oak_leaves[persistent=true]
fill 355 240 285 357 242 285 minecraft:oak_leaves[persistent=true]
setblock 356 240 278 minecraft:light[level=15]
fill 356 240 282 356 242 282 minecraft:oak_leaves[persistent=true]
setblock 356 240 286 minecraft:light[level=15]
setblock 356 240 294 minecraft:light[level=15]
setblock 356 240 302 minecraft:light[level=15]
setblock 356 240 310 minecraft:light[level=15]
fill 357 240 284 357 242 284 minecraft:oak_leaves[persistent=true]
setblock 360 240 278 minecraft:light[level=12]
setblock 360 240 285 minecraft:light[level=12]
setblock 360 240 292 minecraft:light[level=12]
setblock 360 240 299 minecraft:light[level=12]
setblock 360 240 306 minecraft:light[level=12]
setblock 360 240 313 minecraft:light[level=12]
fill 363 240 282 364 242 282 minecraft:white_concrete
setblock 364 240 278 minecraft:light[level=15]
fill 364 240 281 364 241 281 minecraft:white_concrete
fill 364 240 283 364 241 283 minecraft:white_concrete
setblock 364 240 286 minecraft:light[level=15]
setblock 364 240 294 minecraft:light[level=15]
setblock 364 240 302 minecraft:light[level=15]
setblock 364 240 310 minecraft:light[level=15]
setblock 367 240 278 minecraft:light[level=12]
setblock 367 240 282 minecraft:yellow_concrete
setblock 367 240 285 minecraft:light[level=12]
setblock 367 240 292 minecraft:light[level=12]
setblock 367 240 299 minecraft:light[level=12]
setblock 367 240 306 minecraft:light[level=12]
setblock 367 240 313 minecraft:light[level=12]
setblock 371 240 290 minecraft:white_wool
fill 371 240 291 371 277 292 minecraft:light_blue_concrete
fill 329 241 297 329 308 297 minecraft:light_blue_concrete
setblock 333 241 282 minecraft:yellow_concrete
fill 336 241 281 336 242 281 minecraft:white_concrete
fill 336 241 283 336 242 283 minecraft:white_concrete
fill 337 241 282 337 243 282 minecraft:white_concrete
fill 339 241 304 339 241 305 minecraft:dirt
setblock 340 241 302 minecraft:dirt
setblock 340 241 307 minecraft:dirt
setblock 341 241 308 minecraft:dirt
fill 342 241 301 344 241 301 minecraft:dirt
setblock 345 241 308 minecraft:dirt
setblock 346 241 302 minecraft:dirt
setblock 346 241 307 minecraft:dirt
fill 347 241 304 347 241 306 minecraft:dirt
setblock 352 241 317 minecraft:white_wool
fill 353 241 275 353 308 275 minecraft:light_blue_concrete
setblock 354 241 283 minecraft:oak_leaves[persistent=true]
setblock 354 241 285 minecraft:oak_leaves[persistent=true]
setblock 355 241 282 minecraft:oak_leaves[persistent=true]
fill 355 241 286 357 241 286 minecraft:oak_leaves[persistent=true]
fill 356 241 284 356 242 284 minecraft:oak_leaves[persistent=true]
setblock 357 241 282 minecraft:oak_leaves[persistent=true]
fill 358 241 283 358 241 284 minecraft:oak_leaves[persistent=true]
fill 362 241 282 362 243 282 minecraft:white_concrete
fill 363 241 281 363 242 281 minecraft:white_concrete
fill 363 241 283 363 242 283 minecraft:white_concrete
fill 364 241 286 364 243 286 minecraft:white_wool
setblock 365 241 282 minecraft:white_concrete
setblock 366 241 282 minecraft:yellow_concrete
setblock 368 241 275 minecraft:white_wool
fill 369 241 275 369 308 275 minecraft:light_blue_concrete
fill 371 241 290 371 280 290 minecraft:light_blue_concrete
fill 331 242 275 331 308 275 minecraft:light_blue_concrete
setblock 332 242 275 minecraft:white_wool
fill 333 242 275 333 296 275 minecraft:light_blue_concrete
setblock 334 242 282 minecraft:yellow_concrete
setblock 335 242 282 minecraft:white_concrete
fill 337 242 281 338 242 281 minecraft:white_concrete
fill 337 242 283 338 242 283 minecraft:white_concrete
fill 338 242 282 339 243 282 minecraft:white_concrete
fill 343 242 305 343 245 305 minecraft:white_concrete
fill 352 242 317 352 308 317 minecraft:light_blue_concrete
fill 360 242 282 361 243 282 minecraft:white_concrete
fill 361 242 281 362 242 281 minecraft:white_concrete
fill 361 242 283 362 242 283 minecraft:white_concrete
fill 361 242 285 363 243 287 minecraft:white_wool
fill 362 242 284 365 242 284 minecraft:white_wool
fill 362 242 288 365 242 288 minecraft:white_wool
fill 364 242 285 365 243 285 minecraft:white_wool
fill 364 242 287 365 243 287 minecraft:white_wool
setblock 365 242 282 minecraft:yellow_concrete
fill 365 242 286 365 243 286 minecraft:white_wool
fill 368 242 275 368 308 275 minecraft:light_blue_concrete
fill 332 243 275 332 308 275 minecraft:light_blue_concrete
setblock 336 243 282 minecraft:yellow_concrete
fill 338 243 281 340 243 281 minecraft:white_concrete
fill 338 243 283 340 243 283 minecraft:white_concrete
fill 340 243 282 340 245 282 minecraft:white_concrete
fill 341 243 282 343 243 286 minecraft:white_wool
fill 344 243 282 344 244 285 minecraft:white_wool
fill 345 243 283 345 243 285 minecraft:white_wool
fill 358 243 282 359 245 282 minecraft:white_concrete
fill 359 243 281 361 243 281 minecraft:white_concrete
fill 359 243 283 361 243 283 minecraft:white_concrete
fill 360 243 305 360 244 305 minecraft:ochre_froglight
fill 362 243 284 364 243 284 minecraft:white_wool
fill 362 243 288 364 243 288 minecraft:white_wool
setblock 363 243 282 minecraft:yellow_concrete
setblock 363 243 283 minecraft:white_wool
setblock 329 244 305 minecraft:white_wool
fill 337 244 282 338 244 282 minecraft:yellow_concrete
setblock 339 244 282 minecraft:white_concrete
fill 340 244 281 342 244 281 minecraft:white_concrete
setblock 340 244 283 minecraft:white_concrete
fill 340 244 284 343 244 284 minecraft:white_wool
fill 341 244 282 341 245 282 minecraft:white_concrete
fill 341 244 283 343 244 283 minecraft:white_wool
fill 341 244 285 343 244 285 minecraft:white_wool
fill 342 244 282 343 244 282 minecraft:white_wool
setblock 343 244 281 minecraft:white_wool
fill 343 244 286 344 244 286 minecraft:white_wool
setblock 345 244 285 minecraft:white_wool
setblock 345 244 317 minecraft:white_wool
fill 354 244 310 356 245 310 minecraft:white_concrete
fill 355 244 309 356 245 309 minecraft:white_concrete
fill 356 244 282 357 246 282 minecraft:white_concrete
fill 357 244 281 359 244 281 minecraft:white_concrete
fill 357 244 283 359 244 283 minecraft:white_concrete
setblock 360 244 282 minecraft:white_concrete
fill 361 244 282 362 244 282 minecraft:yellow_concrete
setblock 361 244 317 minecraft:white_wool
setblock 371 244 298 minecraft:white_wool
fill 371 244 299 371 253 302 minecraft:light_blue_concrete
fill 329 245 305 329 308 305 minecraft:light_blue_concrete
setblock 339 245 282 minecraft:yellow_concrete
fill 341 245 281 345 245 281 minecraft:white_concrete
fill 341 245 283 345 245 283 minecraft:white_concrete
fill 342 245 282 348 246 282 minecraft:white_concrete
fill 342 245 304 342 247 306 minecraft:oak_leaves[persistent=true]
fill 343 245 303 343 247 304 minecraft:oak_leaves[persistent=true]
fill 343 245 306 344 247 306 minecraft:oak_leaves[persistent=true]
fill 344 245 304 344 247 305 minecraft:oak_leaves[persistent=true]
fill 345 245 305 345 247 305 minecraft:oak_leaves[persistent=true]
fill 345 245 317 345 260 317 minecraft:light_blue_concrete
fill 351 245 282 355 246 282 minecraft:white_concrete
fill 353 245 317 354 308 317 minecraft:light_blue_concrete
fill 354 245 281 358 245 281 minecraft:white_concrete
fill 354 245 283 358 245 283 minecraft:white_concrete
setblock 355 245 317 minecraft:white_wool
fill 356 245 317 356 255 317 minecraft:light_blue_concrete
setblock 360 245 282 minecraft:yellow_concrete
fill 360 245 305 360 255 305 minecraft:dirt
fill 361 245 317 361 308 317 minecraft:light_blue_concrete
fill 371 245 275 371 271 277 minecraft:light_blue_concrete
setblock 371 245 278 minecraft:white_wool
fill 371 245 279 371 308 281 minecraft:light_blue_concrete
fill 371 245 298 371 308 298 minecraft:light_blue_concrete
setblock 332 246 278 minecraft:light[level=12]
setblock 332 246 285 minecraft:light[level=12]
setblock 332 246 292 minecraft:light[level=12]
setblock 332 246 299 minecraft:light[level=12]
setblock 332 246 306 minecraft:light[level=12]
setblock 332 246 313 minecraft:light[level=12]
setblock 339 246 278 minecraft:light[level=12]
setblock 339 246 285 minecraft:light[level=12]
setblock 339 246 292 minecraft:light[level=12]
setblock 339 246 299 minecraft:light[level=12]
setblock 339 246 306 minecraft:light[level=12]
setblock 339 246 313 minecraft:light[level=12]
setblock 341 246 282 minecraft:yellow_concrete
fill 341 246 304 341 246 306 minecraft:oak_leaves[persistent=true]
setblock 342 246 303 minecraft:oak_leaves[persistent=true]
fill 343 246 305 343 247 305 minecraft:oak_leaves[persistent=true]
setblock 343 246 307 minecraft:oak_leaves[persistent=true]
fill 344 246 281 355 246 281 minecraft:white_concrete
fill 344 246 283 355 246 283 minecraft:white_concrete
setblock 344 246 303 minecraft:oak_leaves[persistent=true]
setblock 345 246 304 minecraft:oak_leaves[persistent=true]
setblock 345 246 306 minecraft:oak_leaves[persistent=true]
setblock 346 246 278 minecraft:light[level=12]
setblock 346 246 285 minecraft:light[level=12]
setblock 346 246 292 minecraft:light[level=12]
setblock 346 246 299 minecraft:light[level=12]
setblock 346 246 306 minecraft:light[level=12]
setblock 346 246 313 minecraft:light[level=12]
fill 349 246 282 350 247 282 minecraft:white_concrete
setblock 353 246 278 minecraft:light[level=12]
setblock 353 246 285 minecraft:light[level=12]
setblock 353 246 299 minecraft:light[level=12]
setblock 353 246 306 minecraft:light[level=12]
setblock 353 246 313 minecraft:light[level=12]
fill 355 246 317 355 308 317 minecraft:light_blue_concrete
setblock 358 246 282 minecraft:yellow_concrete
setblock 360 246 278 minecraft:light[level=12]
setblock 360 246 285 minecraft:light[level=12]
setblock 360 246 292 minecraft:light[level=12]
setblock 360 246 299 minecraft:light[level=12]
setblock 360 246 306 minecraft:light[level=12]
setblock 360 246 313 minecraft:light[level=12]
setblock 367 246 278 minecraft:light[level=12]
setblock 367 246 285 minecraft:light[level=12]
setblock 367 246 292 minecraft:light[level=12]
setblock 367 246 299 minecraft:light[level=12]
setblock 367 246 306 minecraft:light[level=12]
setblock 367 246 313 minecraft:light[level=12]
fill 371 246 278 371 308 278 minecraft:light_blue_concrete
fill 343 247 282 345 247 282 minecraft:yellow_concrete
fill 346 247 282 348 247 282 minecraft:white_concrete
fill 349 247 281 350 247 281 minecraft:white_concrete
fill 349 247 283 350 247 283 minecraft:white_concrete
fill 351 247 282 353 247 282 minecraft:white_concrete
fill 354 247 282 356 247 282 minecraft:yellow_concrete
fill 359 247 305 359 255 305 minecraft:dirt
fill 360 247 304 360 255 304 minecraft:dirt
fill 360 247 306 360 255 306 minecraft:dirt
fill 361 247 305 361 255 305 minecraft:dirt
setblock 332 248 278 minecraft:light[level=15]
setblock 332 248 286 minecraft:light[level=15]
setblock 332 248 294 minecraft:light[level=15]
setblock 332 248 302 minecraft:light[level=15]
setblock 332 248 310 minecraft:light[level=15]
fill 336 248 317 341 280 317 minecraft:light_blue_concrete
setblock 340 248 278 minecraft:light[level=15]
setblock 340 248 286 minecraft:light[level=15]
setblock 340 248 294 minecraft:light[level=15]
setblock 340 248 302 minecraft:light[level=15]
setblock 340 248 310 minecraft:light[level=15]
setblock 342 248 317 minecraft:white_wool
fill 343 248 317 344 270 317 minecraft:light_blue_concrete
fill 346 248 282 353 248 282 minecraft:yellow_concrete
setblock 348 248 278 minecraft:light[level=15]
setblock 348 248 286 minecraft:light[level=15]
setblock 348 248 294 minecraft:light[level=15]
setblock 348 248 302 minecraft:light[level=15]
setblock 348 248 310 minecraft:light[level=15]
setblock 356 248 278 minecraft:light[level=15]
setblock 356 248 286 minecraft:light[level=15]
setblock 356 248 294 minecraft:light[level=15]
setblock 356 248 302 minecraft:light[level=15]
setblock 356 248 310 minecraft:light[level=15]
fill 359 248 304 359 255 304 minecraft:dirt
fill 359 248 306 359 255 306 minecraft:dirt
fill 359 248 317 359 308 317 minecraft:light_blue_concrete
setblock 360 248 317 minecraft:white_wool
fill 361 248 304 361 255 304 minecraft:dirt
fill 361 248 306 361 255 306 minecraft:dirt
setblock 364 248 278 minecraft:light[level=15]
setblock 364 248 286 minecraft:light[level=15]
setblock 364 248 294 minecraft:light[level=15]
setblock 364 248 302 minecraft:light[level=15]
setblock 364 248 310 minecraft:light[level=15]
setblock 368 248 317 minecraft:white_wool
setblock 335 249 317 minecraft:white_wool
fill 342 249 317 342 308 317 minecraft:light_blue_concrete
fill 358 249 304 358 255 306 minecraft:dirt
fill 360 249 303 360 255 303 minecraft:dirt
fill 360 249 307 360 255 307 minecraft:dirt
fill 360 249 317 360 278 317 minecraft:light_blue_concrete
fill 368 249 317 368 291 317 minecraft:light_blue_concrete
setblock 371 249 289 minecraft:white_wool
fill 335 250 317 335 308 317 minecraft:light_blue_concrete
fill 359 250 303 359 255 303 minecraft:dirt
fill 359 250 307 359 255 307 minecraft:dirt
fill 361 250 303 361 255 303 minecraft:dirt
fill 361 250 307 361 255 307 minecraft:dirt
fill 362 250 304 362 255 306 minecraft:dirt
fill 371 250 289 371 308 289 minecraft:light_blue_concrete
fill 357 251 304 357 255 306 minecraft:dirt
fill 358 251 303 358 255 303 minecraft:dirt
fill 358 251 307 358 255 307 minecraft:dirt
fill 359 251 308 360 255 308 minecraft:dirt
fill 360 251 302 360 255 302 minecraft:dirt
fill 362 251 303 362 255 303 minecraft:dirt
fill 362 251 307 362 255 307 minecraft:dirt
setblock 332 252 278 minecraft:light[level=12]
setblock 332 252 285 minecraft:light[level=12]
setblock 332 252 292 minecraft:light[level=12]
setblock 332 252 299 minecraft:light[level=12]
setblock 332 252 306 minecraft:light[level=12]
setblock 332 252 313 minecraft:light[level=12]
setblock 339 252 278 minecraft:light[level=12]
setblock 339 252 285 minecraft:light[level=12]
setblock 339 252 292 minecraft:light[level=12]
setblock 339 252 299 minecraft:light[level=12]
setblock 339 252 306 minecraft:light[level=12]
setblock 339 252 313 minecraft:light[level=12]
setblock 346 252 278 minecraft:light[level=12]
setblock 346 252 285 minecraft:light[level=12]
setblock 346 252 292 minecraft:light[level=12]
setblock 346 252 299 minecraft:light[level=12]
setblock 346 252 306 minecraft:light[level=12]
setblock 346 252 313 minecraft:light[level=12]
setblock 353 252 278 minecraft:light[level=12]
setblock 353 252 285 minecraft:light[level=12]
setblock 353 252 292 minecraft:light[level=12]
setblock 353 252 299 minecraft:light[level=12]
setblock 353 252 306 minecraft:light[level=12]
setblock 353 252 313 minecraft:light[level=12]
fill 357 252 303 357 255 303 minecraft:dirt
fill 357 252 307 357 255 307 minecraft:dirt
fill 358 252 302 359 255 302 minecraft:dirt
fill 358 252 308 358 255 308 minecraft:dirt
fill 359 252 275 359 261 275 minecraft:light_blue_concrete
setblock 360 252 275 minecraft:white_wool
setblock 360 252 278 minecraft:light[level=12]
setblock 360 252 285 minecraft:light[level=12]
setblock 360 252 292 minecraft:light[level=12]
setblock 360 252 299 minecraft:light[level=12]
setblock 360 252 313 minecraft:light[level=12]
fill 361 252 302 361 255 302 minecraft:dirt
fill 361 252 308 361 255 308 minecraft:dirt
fill 363 252 304 363 255 306 minecraft:dirt
setblock 367 252 278 minecraft:light[level=12]
setblock 367 252 285 minecraft:light[level=12]
setblock 367 252 292 minecraft:light[level=12]
setblock 367 252 299 minecraft:light[level=12]
setblock 367 252 306 minecraft:light[level=12]
setblock 367 252 313 minecraft:light[level=12]
setblock 330 253 317 minecraft:white_wool
setblock 335 253 275 minecraft:white_wool
fill 336 253 275 336 308 275 minecraft:light_blue_concrete
fill 356 253 304 356 255 306 minecraft:dirt
fill 359 253 309 360 255 309 minecraft:dirt
fill 360 253 275 360 308 275 minecraft:light_blue_concrete
fill 360 253 301 360 255 301 minecraft:dirt
fill 362 253 302 362 255 302 minecraft:dirt
fill 362 253 308 362 255 308 minecraft:dirt
fill 363 253 303 363 255 303 minecraft:dirt
fill 363 253 307 363 255 307 minecraft:dirt
fill 329 254 299 329 285 300 minecraft:light_blue_concrete
setblock 329 254 301 minecraft:white_wool
fill 329 254 302 329 285 302 minecraft:light_blue_concrete
fill 330 254 317 330 267 317 minecraft:light_blue_concrete
fill 335 254 275 335 308 275 minecraft:light_blue_concrete
fill 356 254 303 356 255 303 minecraft:dirt
fill 356 254 307 356 255 307 minecraft:dirt
fill 357 254 302 357 255 302 minecraft:dirt
fill 357 254 308 357 255 308 minecraft:dirt
fill 358 254 301 359 255 301 minecraft:dirt
fill 358 254 309 358 255 309 minecraft:dirt
fill 361 254 301 362 255 301 minecraft:dirt
fill 361 254 309 362 255 309 minecraft:dirt
fill 363 254 302 363 255 302 minecraft:dirt
fill 363 254 308 363 255 308 minecraft:dirt
fill 364 254 304 364 255 306 minecraft:dirt
fill 371 254 299 371 283 299 minecraft:light_blue_concrete
setblock 371 254 300 minecraft:white_wool
fill 371 254 301 371 289 302 minecraft:light_blue_concrete
fill 329 255 301 329 308 301 minecraft:light_blue_concrete
fill 355 255 304 355 255 306 minecraft:dirt
setblock 356 255 302 minecraft:dirt
setblock 356 255 308 minecraft:dirt
setblock 357 255 301 minecraft:dirt
setblock 357 255 309 minecraft:dirt
fill 359 255 310 360 255 310 minecraft:dirt
setblock 360 255 300 minecraft:dirt
setblock 363 255 309 minecraft:dirt
setblock 364 255 275 minecraft:white_wool
setblock 364 255 303 minecraft:dirt
setblock 364 255 307 minecraft:dirt
fill 365 255 275 366 304 275 minecraft:light_blue_concrete
fill 371 255 300 371 303 300 minecraft:light_blue_concrete
setblock 329 256 278 minecraft:white_wool
setblock 332 256 278 minecraft:light[level=15]
setblock 332 256 286 minecraft:light[level=15]
setblock 332 256 294 minecraft:light[level=15]
setblock 332 256 302 minecraft:light[level=15]
setblock 332 256 310 minecraft:light[level=15]
setblock 340 256 278 minecraft:light[level=15]
setblock 340 256 286 minecraft:light[level=15]
setblock 340 256 294 minecraft:light[level=15]
setblock 340 256 302 minecraft:light[level=15]
setblock 340 256 310 minecraft:light[level=15]
setblock 348 256 278 minecraft:light[level=15]
setblock 348 256 286 minecraft:light[level=15]
setblock 348 256 294 minecraft:light[level=15]
setblock 348 256 302 minecraft:light[level=15]
setblock 348 256 310 minecraft:light[level=15]
setblock 356 256 278 minecraft:light[level=15]
setblock 356 256 286 minecraft:light[level=15]
setblock 356 256 294 minecraft:light[level=15]
setblock 356 256 302 minecraft:light[level=15]
setblock 356 256 310 minecraft:light[level=15]
setblock 356 256 317 minecraft:white_wool
fill 360 256 305 360 259 305 minecraft:iron_block
fill 363 256 303 365 259 303 minecraft:packed_mud
fill 364 256 275 364 308 275 minecraft:light_blue_concrete
setblock 364 256 278 minecraft:light[level=15]
setblock 364 256 286 minecraft:light[level=15]
setblock 364 256 294 minecraft:light[level=15]
fill 364 256 301 365 258 302 minecraft:packed_mud
fill 364 256 304 364 259 304 minecraft:packed_mud
setblock 364 256 310 minecraft:light[level=15]
setblock 371 256 303 minecraft:white_wool
setblock 371 256 311 minecraft:white_wool
fill 329 257 278 329 308 278 minecraft:light_blue_concrete
setblock 330 257 275 minecraft:white_wool
fill 342 257 275 343 306 275 minecraft:light_blue_concrete
setblock 344 257 275 minecraft:white_wool
fill 356 257 317 356 278 317 minecraft:light_blue_concrete
fill 363 257 302 363 259 302 minecraft:packed_mud
fill 363 257 304 363 258 304 minecraft:packed_mud
fill 365 257 304 365 259 304 minecraft:packed_mud
fill 366 257 302 366 258 303 minecraft:packed_mud
fill 371 257 303 371 299 303 minecraft:light_blue_concrete
fill 371 257 311 371 308 311 minecraft:light_blue_concrete
setblock 329 258 316 minecraft:white_wool
fill 329 258 317 329 308 317 minecraft:light_blue_concrete
fill 330 258 275 330 308 275 minecraft:light_blue_concrete
setblock 332 258 278 minecraft:light[level=12]
setblock 332 258 285 minecraft:light[level=12]
setblock 332 258 292 minecraft:light[level=12]
setblock 332 258 299 minecraft:light[level=12]
setblock 332 258 306 minecraft:light[level=12]
setblock 332 258 313 minecraft:light[level=12]
setblock 339 258 278 minecraft:light[level=12]
setblock 339 258 285 minecraft:light[level=12]
setblock 339 258 292 minecraft:light[level=12]
setblock 339 258 299 minecraft:light[level=12]
setblock 339 258 306 minecraft:light[level=12]
setblock 339 258 313 minecraft:light[level=12]
fill 344 258 275 344 297 275 minecraft:light_blue_concrete
setblock 346 258 278 minecraft:light[level=12]
setblock 346 258 285 minecraft:light[level=12]
setblock 346 258 292 minecraft:light[level=12]
setblock 346 258 299 minecraft:light[level=12]
setblock 346 258 306 minecraft:light[level=12]
setblock 346 258 313 minecraft:light[level=12]
setblock 353 258 278 minecraft:light[level=12]
setblock 353 258 285 minecraft:light[level=12]
setblock 353 258 292 minecraft:light[level=12]
setblock 353 258 299 minecraft:light[level=12]
setblock 353 258 306 minecraft:light[level=12]
setblock 353 258 313 minecraft:light[level=12]
setblock 360 258 278 minecraft:light[level=12]
setblock 360 258 285 minecraft:light[level=12]
setblock 360 258 292 minecraft:light[level=12]
setblock 360 258 299 minecraft:light[level=12]
setblock 360 258 306 minecraft:light[level=12]
setblock 360 258 313 minecraft:light[level=12]
setblock 366 258 304 minecraft:packed_mud
setblock 367 258 278 minecraft:light[level=12]
setblock 367 258 285 minecraft:light[level=12]
setblock 367 258 292 minecraft:light[level=12]
setblock 367 258 299 minecraft:light[level=12]
setblock 367 258 306 minecraft:light[level=12]
setblock 367 258 313 minecraft:light[level=12]
setblock 371 258 287 minecraft:white_wool
fill 329 259 316 329 265 316 minecraft:light_blue_concrete
fill 335 259 301 340 260 301 minecraft:white_wool
fill 336 259 300 340 259 300 minecraft:white_wool
fill 336 259 302 339 259 303 minecraft:white_wool
fill 337 259 299 339 259 299 minecraft:white_wool
fill 363 259 301 366 259 301 minecraft:moss_block
fill 363 259 304 363 260 304 minecraft:moss_block
fill 364 259 302 365 259 302 minecraft:packed_mud
fill 364 259 305 365 260 305 minecraft:moss_block
fill 366 259 302 366 260 302 minecraft:moss_block
setblock 366 259 303 minecraft:packed_mud
fill 366 259 304 366 260 304 minecraft:moss_block
fill 371 259 287 371 308 287 minecraft:light_blue_concrete
fill 335 260 300 339 260 300 minecraft:white_wool
fill 336 260 302 340 260 302 minecraft:white_wool
fill 337 260 299 338 260 299 minecraft:white_wool
fill 337 260 303 340 260 303 minecraft:white_wool
setblock 360 260 305 minecraft:ochre_froglight
fill 362 260 302 365 260 302 minecraft:moss_block
fill 363 260 301 365 260 301 minecraft:moss_block
fill 363 260 303 366 260 303 minecraft:moss_block
fill 364 260 304 365 260 304 minecraft:moss_block
setblock 367 260 275 minecraft:white_wool
setblock 334 261 275 minecraft:white_wool
setblock 337 261 275 minecraft:white_wool
setblock 345 261 317 minecraft:white_wool
fill 354 261 284 354 262 285 minecraft:white_concrete
fill 367 261 275 367 270 275 minecraft:light_blue_concrete
fill 334 262 275 334 280 275 minecraft:light_blue_concrete
fill 337 262 275 337 281 275 minecraft:light_blue_concrete
fill 345 262 317 345 308 317 minecraft:light_blue_concrete
setblock 359 262 275 minecraft:white_wool
setblock 371 262 282 minecraft:white_wool
setblock 329 263 284 minecraft:white_wool
fill 359 263 275 359 308 275 minecraft:light_blue_concrete
fill 371 263 282 371 308 282 minecraft:light_blue_concrete
fill 371 263 288 371 264 288 minecraft:white_wool
setblock 371 263 296 minecraft:white_wool
fill 371 263 297 371 308 297 minecraft:light_blue_concrete
fill 329 264 284 329 280 284 minecraft:light_blue_concrete
setblock 332 264 278 minecraft:light[level=15]
setblock 332 264 285 minecraft:light[level=12]
setblock 332 264 286 minecraft:light[level=15]
setblock 332 264 292 minecraft:light[level=12]
setblock 332 264 294 minecraft:light[level=15]
setblock 332 264 299 minecraft:light[level=12]
setblock 332 264 302 minecraft:light[level=15]
setblock 332 264 306 minecraft:light[level=12]
setblock 332 264 310 minecraft:light[level=15]
setblock 332 264 313 minecraft:light[level=12]
setblock 339 264 278 minecraft:light[level=12]
setblock 339 264 285 minecraft:light[level=12]
setblock 339 264 292 minecraft:light[level=12]
setblock 339 264 299 minecraft:light[level=12]
setblock 339 264 306 minecraft:light[level=12]
setblock 339 264 313 minecraft:light[level=12]
setblock 340 264 278 minecraft:light[level=15]
setblock 340 264 286 minecraft:light[level=15]
setblock 340 264 294 minecraft:light[level=15]
setblock 340 264 302 minecraft:light[level=15]
setblock 340 264 310 minecraft:light[level=15]
setblock 346 264 275 minecraft:white_wool
setblock 346 264 278 minecraft:light[level=12]
setblock 346 264 285 minecraft:light[level=12]
setblock 346 264 292 minecraft:light[level=12]
setblock 346 264 299 minecraft:light[level=12]
setblock 346 264 306 minecraft:light[level=12]
setblock 346 264 313 minecraft:light[level=12]
setblock 348 264 278 minecraft:light[level=15]
setblock 348 264 286 minecraft:light[level=15]
setblock 348 264 294 minecraft:light[level=15]
setblock 348 264 302 minecraft:light[level=15]
setblock 348 264 310 minecraft:light[level=15]
setblock 353 264 278 minecraft:light[level=12]
setblock 353 264 285 minecraft:light[level=12]
setblock 353 264 292 minecraft:light[level=12]
setblock 353 264 299 minecraft:light[level=12]
setblock 353 264 306 minecraft:light[level=12]
setblock 353 264 313 minecraft:light[level=12]
setblock 356 264 278 minecraft:light[level=15]
setblock 356 264 286 minecraft:light[level=15]
setblock 356 264 294 minecraft:light[level=15]
setblock 356 264 302 minecraft:light[level=15]
setblock 356 264 310 minecraft:light[level=15]
setblock 360 264 278 minecraft:light[level=12]
setblock 360 264 285 minecraft:light[level=12]
setblock 360 264 292 minecraft:light[level=12]
setblock 360 264 299 minecraft:light[level=12]
setblock 360 264 306 minecraft:light[level=12]
setblock 360 264 313 minecraft:light[level=12]
fill 363 264 293 363 268 293 minecraft:packed_mud
setblock 364 264 278 minecraft:light[level=15]
setblock 364 264 286 minecraft:light[level=15]
setblock 364 264 294 minecraft:light[level=15]
setblock 364 264 302 minecraft:light[level=15]
setblock 364 264 310 minecraft:light[level=15]
setblock 367 264 278 minecraft:light[level=12]
setblock 367 264 285 minecraft:light[level=12]
setblock 367 264 292 minecraft:light[level=12]
setblock 367 264 299 minecraft:light[level=12]
setblock 367 264 306 minecraft:light[level=12]
setblock 367 264 313 minecraft:light[level=12]
fill 371 264 296 371 308 296 minecraft:light_blue_concrete
setblock 345 265 275 minecraft:white_wool
fill 346 265 275 346 308 275 minecraft:light_blue_concrete
fill 361 265 293 362 266 293 minecraft:packed_mud
fill 362 265 292 362 267 292 minecraft:packed_mud
fill 362 265 294 364 268 294 minecraft:packed_mud
fill 364 265 293 364 267 293 minecraft:packed_mud
fill 371 265 288 371 308 288 minecraft:light_blue_concrete
fill 329 266 293 329 308 293 minecraft:light_blue_concrete
setblock 329 266 294 minecraft:white_wool
setblock 329 266 316 minecraft:white_wool
fill 332 266 294 332 267 295 minecraft:white_concrete
fill 345 266 275 345 308 275 minecraft:light_blue_concrete
setblock 361 266 292 minecraft:packed_mud
fill 362 266 295 363 267 295 minecraft:packed_mud
fill 363 266 292 364 268 292 minecraft:packed_mud
fill 365 266 293 365 266 294 minecraft:packed_mud
fill 329 267 294 329 299 294 minecraft:light_blue_concrete
fill 329 267 316 329 308 316 minecraft:light_blue_concrete
fill 334 267 303 335 268 304 minecraft:white_concrete
fill 336 267 304 336 268 304 minecraft:white_concrete
setblock 361 267 294 minecraft:packed_mud
fill 362 267 293 362 268 293 minecraft:packed_mud
setblock 365 267 293 minecraft:packed_mud
fill 330 268 317 331 268 317 minecraft:white_wool
fill 332 268 317 334 286 317 minecraft:light_blue_concrete
fill 340 268 286 342 269 286 minecraft:white_wool
fill 341 268 287 342 269 287 minecraft:white_wool
fill 361 268 292 361 268 294 minecraft:moss_block
fill 362 268 292 362 269 292 minecraft:moss_block
fill 362 268 295 364 269 295 minecraft:moss_block
fill 364 268 293 365 269 293 minecraft:moss_block
fill 365 268 294 365 269 294 minecraft:moss_block
fill 330 269 317 331 308 317 minecraft:light_blue_concrete
fill 361 269 293 361 269 295 minecraft:moss_block
fill 362 269 293 363 269 294 minecraft:moss_block
fill 363 269 291 363 269 292 minecraft:moss_block
setblock 364 269 292 minecraft:moss_block
setblock 364 269 294 minecraft:moss_block
setblock 332 270 278 minecraft:light[level=12]
setblock 332 270 285 minecraft:light[level=12]
setblock 332 270 292 minecraft:light[level=12]
setblock 332 270 299 minecraft:light[level=12]
setblock 332 270 306 minecraft:light[level=12]
setblock 332 270 313 minecraft:light[level=12]
setblock 339 270 278 minecraft:light[level=12]
setblock 339 270 285 minecraft:light[level=12]
setblock 339 270 292 minecraft:light[level=12]
setblock 339 270 299 minecraft:light[level=12]
setblock 339 270 306 minecraft:light[level=12]
setblock 339 270 313 minecraft:light[level=12]
setblock 346 270 278 minecraft:light[level=12]
setblock 346 270 285 minecraft:light[level=12]
setblock 346 270 292 minecraft:light[level=12]
setblock 346 270 299 minecraft:light[level=12]
setblock 346 270 306 minecraft:light[level=12]
setblock 346 270 313 minecraft:light[level=12]
setblock 353 270 278 minecraft:light[level=12]
setblock 353 270 285 minecraft:light[level=12]
setblock 353 270 292 minecraft:light[level=12]
setblock 353 270 299 minecraft:light[level=12]
setblock 353 270 306 minecraft:light[level=12]
setblock 353 270 313 minecraft:light[level=12]
setblock 360 270 278 minecraft:light[level=12]
setblock 360 270 285 minecraft:light[level=12]
setblock 360 270 292 minecraft:light[level=12]
setblock 360 270 299 minecraft:light[level=12]
setblock 360 270 306 minecraft:light[level=12]
setblock 360 270 313 minecraft:light[level=12]
setblock 367 270 278 minecraft:light[level=12]
setblock 367 270 285 minecraft:light[level=12]
setblock 367 270 292 minecraft:light[level=12]
setblock 367 270 299 minecraft:light[level=12]
setblock 367 270 306 minecraft:light[level=12]
setblock 367 270 313 minecraft:light[level=12]
setblock 329 271 307 minecraft:white_wool
setblock 343 271 317 minecraft:white_wool
fill 344 271 317 344 308 317 minecraft:light_blue_concrete
setblock 364 271 317 minecraft:white_wool
fill 365 271 317 365 308 317 minecraft:light_blue_concrete
setblock 367 271 275 minecraft:white_wool
fill 329 272 307 329 308 307 minecraft:light_blue_concrete
setblock 332 272 278 minecraft:light[level=15]
setblock 332 272 286 minecraft:light[level=15]
setblock 332 272 294 minecraft:light[level=15]
setblock 332 272 302 minecraft:light[level=15]
setblock 332 272 310 minecraft:light[level=15]
setblock 340 272 278 minecraft:light[level=15]
setblock 340 272 286 minecraft:light[level=15]
setblock 340 272 294 minecraft:light[level=15]
setblock 340 272 302 minecraft:light[level=15]
setblock 340 272 310 minecraft:light[level=15]
fill 343 272 317 343 296 317 minecraft:light_blue_concrete
setblock 348 272 278 minecraft:light[level=15]
setblock 348 272 286 minecraft:light[level=15]
setblock 348 272 294 minecraft:light[level=15]
setblock 348 272 302 minecraft:light[level=15]
setblock 348 272 310 minecraft:light[level=15]
setblock 356 272 278 minecraft:light[level=15]
setblock 356 272 286 minecraft:light[level=15]
setblock 356 272 294 minecraft:light[level=15]
setblock 356 272 302 minecraft:light[level=15]
setblock 356 272 310 minecraft:light[level=15]
setblock 364 272 278 minecraft:light[level=15]
setblock 364 272 286 minecraft:light[level=15]
setblock 364 272 294 minecraft:light[level=15]
setblock 364 272 302 minecraft:light[level=15]
setblock 364 272 310 minecraft:light[level=15]
fill 364 272 317 364 308 317 minecraft:light_blue_concrete
fill 367 272 275 367 308 275 minecraft:light_blue_concrete
fill 371 272 275 371 308 275 minecraft:light_blue_concrete
setblock 371 272 276 minecraft:white_wool
fill 371 272 277 371 308 277 minecraft:light_blue_concrete
fill 329 273 285 329 308 286 minecraft:light_blue_concrete
setblock 329 273 287 minecraft:white_wool
fill 329 273 288 329 295 292 minecraft:light_blue_concrete
fill 371 273 276 371 300 276 minecraft:light_blue_concrete
fill 329 274 287 329 279 287 minecraft:light_blue_concrete
setblock 371 274 316 minecraft:white_wool
fill 351 275 281 353 276 282 minecraft:packed_mud
fill 352 275 283 353 276 283 minecraft:packed_mud
fill 353 275 284 353 276 284 minecraft:packed_mud
setblock 371 275 294 minecraft:white_wool
fill 371 275 316 371 308 316 minecraft:light_blue_concrete
setblock 332 276 278 minecraft:light[level=12]
setblock 332 276 285 minecraft:light[level=12]
setblock 332 276 292 minecraft:light[level=12]
setblock 332 276 299 minecraft:light[level=12]
setblock 332 276 306 minecraft:light[level=12]
setblock 332 276 313 minecraft:light[level=12]
fill 338 276 275 338 297 275 minecraft:light_blue_concrete
setblock 339 276 275 minecraft:white_wool
setblock 339 276 278 minecraft:light[level=12]
setblock 339 276 285 minecraft:light[level=12]
setblock 339 276 292 minecraft:light[level=12]
setblock 339 276 299 minecraft:light[level=12]
setblock 339 276 306 minecraft:light[level=12]
setblock 339 276 313 minecraft:light[level=12]
setblock 346 276 278 minecraft:light[level=12]
setblock 346 276 285 minecraft:light[level=12]
setblock 346 276 292 minecraft:light[level=12]
setblock 346 276 299 minecraft:light[level=12]
setblock 346 276 306 minecraft:light[level=12]
setblock 346 276 313 minecraft:light[level=12]
setblock 350 276 282 minecraft:packed_mud
setblock 351 276 283 minecraft:packed_mud
setblock 352 276 280 minecraft:packed_mud
setblock 352 276 284 minecraft:packed_mud
setblock 353 276 278 minecraft:light[level=12]
setblock 353 276 285 minecraft:light[level=12]
setblock 353 276 292 minecraft:light[level=12]
setblock 353 276 299 minecraft:light[level=12]
setblock 353 276 306 minecraft:light[level=12]
setblock 353 276 313 minecraft:light[level=12]
fill 354 276 282 354 276 283 minecraft:packed_mud
setblock 360 276 278 minecraft:light[level=12]
setblock 360 276 285 minecraft:light[level=12]
setblock 360 276 292 minecraft:light[level=12]
setblock 360 276 299 minecraft:light[level=12]
setblock 360 276 306 minecraft:light[level=12]
setblock 360 276 313 minecraft:light[level=12]
setblock 367 276 278 minecraft:light[level=12]
setblock 367 276 285 minecraft:light[level=12]
setblock 367 276 292 minecraft:light[level=12]
setblock 367 276 299 minecraft:light[level=12]
setblock 367 276 306 minecraft:light[level=12]
setblock 367 276 313 minecraft:light[level=12]
fill 371 276 294 371 278 294 minecraft:light_blue_concrete
fill 330 277 276 330 279 283 minecraft:white_wool
fill 330 277 284 333 279 286 minecraft:light_gray_wool
fill 330 277 287 330 279 294 minecraft:white_wool
fill 330 277 295 333 279 296 minecraft:light_gray_wool
fill 330 277 297 330 279 304 minecraft:white_wool
fill 330 277 305 333 279 307 minecraft:light_gray_wool
fill 330 277 308 330 279 315 minecraft:white_wool
fill 330 277 316 333 279 316 minecraft:light_gray_wool
fill 331 277 276 332 279 276 minecraft:light_gray_wool
fill 331 277 277 335 279 283 minecraft:white_wool
fill 331 277 287 335 279 293 minecraft:white_wool
fill 331 277 294 333 279 294 minecraft:light_gray_wool
fill 331 277 297 332 279 297 minecraft:light_gray_wool
fill 331 277 298 335 279 304 minecraft:white_wool
fill 331 277 308 335 279 314 minecraft:white_wool
fill 331 277 315 333 279 315 minecraft:light_gray_wool
fill 333 277 276 342 279 276 minecraft:white_wool
fill 333 277 297 343 279 297 minecraft:white_wool
fill 334 277 284 342 279 286 minecraft:white_wool
fill 334 277 294 342 279 296 minecraft:white_wool
fill 334 277 305 342 279 307 minecraft:white_wool
fill 334 277 315 342 279 316 minecraft:white_wool
fill 336 277 277 337 279 278 minecraft:white_wool
fill 336 277 279 339 279 280 minecraft:light_gray_wool
fill 336 277 281 336 279 283 minecraft:white_wool
fill 336 277 287 336 279 289 minecraft:white_wool
fill 336 277 290 339 279 291 minecraft:light_gray_wool
fill 336 277 292 346 278 293 minecraft:white_wool
fill 336 277 298 337 279 299 minecraft:white_wool
fill 336 277 300 339 279 301 minecraft:light_gray_wool
fill 336 277 302 336 279 304 minecraft:white_wool
fill 336 277 308 336 279 310 minecraft:white_wool
fill 336 277 311 340 279 311 minecraft:light_gray_wool
fill 336 277 312 336 279 314 minecraft:white_wool
fill 337 277 281 339 279 281 minecraft:light_gray_wool
fill 337 277 282 370 279 283 minecraft:white_wool
fill 337 277 287 370 279 288 minecraft:white_wool
fill 337 277 289 339 279 289 minecraft:light_gray_wool
fill 337 277 302 339 279 302 minecraft:light_gray_wool
fill 337 277 303 370 279 304 minecraft:white_wool
fill 337 277 308 370 279 309 minecraft:white_wool
fill 337 277 310 339 279 310 minecraft:light_gray_wool
fill 337 277 312 339 279 312 minecraft:light_gray_wool
fill 337 277 313 370 279 314 minecraft:white_wool
fill 338 277 277 370 279 277 minecraft:white_wool
fill 338 277 278 338 279 278 minecraft:light_gray_wool
fill 338 277 298 370 279 298 minecraft:white_wool
fill 338 277 299 338 279 299 minecraft:light_gray_wool
fill 339 277 275 339 278 275 minecraft:light_blue_concrete
fill 339 277 278 362 279 278 minecraft:white_wool
fill 339 277 299 349 279 299 minecraft:white_wool
fill 340 277 279 348 279 279 minecraft:white_wool
fill 340 277 280 340 279 280 minecraft:light_gray_wool
fill 340 277 281 348 279 281 minecraft:white_wool
fill 340 277 289 348 279 289 minecraft:white_wool
fill 340 277 290 340 279 290 minecraft:light_gray_wool
fill 340 277 291 347 278 291 minecraft:white_wool
fill 340 277 300 348 279 302 minecraft:white_wool
fill 340 277 310 348 279 310 minecraft:white_wool
fill 340 277 312 348 279 312 minecraft:white_wool
fill 341 277 280 348 279 280 minecraft:white_wool
fill 341 277 290 348 278 290 minecraft:white_wool
fill 341 277 311 348 279 311 minecraft:white_wool
fill 343 277 276 345 279 276 minecraft:light_gray_wool
fill 343 277 284 346 279 286 minecraft:light_gray_wool
fill 343 277 294 345 279 296 minecraft:light_gray_wool
fill 343 277 305 345 279 307 minecraft:light_gray_wool
fill 343 277 315 345 279 316 minecraft:light_gray_wool
fill 344 277 297 345 279 297 minecraft:light_gray_wool
fill 346 277 276 355 279 276 minecraft:white_wool
fill 346 277 294 347 278 294 minecraft:white_wool
fill 346 277 295 346 279 296 minecraft:light_gray_wool
fill 346 277 297 355 278 297 minecraft:white_wool
fill 346 277 305 346 279 306 minecraft:light_gray_wool
fill 346 277 307 354 279 307 minecraft:white_wool
fill 346 277 315 355 279 315 minecraft:white_wool
fill 346 277 316 346 279 316 minecraft:light_gray_wool
fill 347 277 284 354 279 286 minecraft:white_wool
fill 347 277 292 347 278 292 minecraft:white_wool
fill 347 277 295 347 278 296 minecraft:white_wool
fill 347 277 305 354 279 306 minecraft:white_wool
fill 347 277 316 354 279 316 minecraft:white_wool
fill 348 277 296 349 278 296 minecraft:white_wool
fill 349 277 279 352 279 281 minecraft:light_gray_wool
fill 349 277 289 349 278 290 minecraft:light_gray_wool
fill 349 277 300 352 279 302 minecraft:light_gray_wool
fill 349 277 310 352 279 312 minecraft:light_gray_wool
fill 350 277 289 352 278 289 minecraft:light_gray_wool
fill 350 277 299 351 279 299 minecraft:light_gray_wool
fill 351 277 290 352 278 290 minecraft:light_gray_wool
fill 351 277 296 354 278 296 minecraft:white_wool
fill 352 277 299 362 279 299 minecraft:white_wool
fill 353 277 279 360 279 281 minecraft:white_wool
fill 353 277 289 360 278 292 minecraft:white_wool
fill 353 277 294 354 278 295 minecraft:white_wool
fill 353 277 300 360 279 302 minecraft:white_wool
fill 353 277 310 360 279 312 minecraft:white_wool
fill 354 277 293 370 278 293 minecraft:white_wool
fill 355 277 284 358 279 286 minecraft:light_gray_wool
fill 355 277 294 355 279 294 minecraft:white_wool
fill 355 277 295 358 279 296 minecraft:light_gray_wool
fill 355 277 305 358 279 307 minecraft:light_gray_wool
fill 355 277 316 358 279 316 minecraft:light_gray_wool
fill 356 277 276 358 279 276 minecraft:light_gray_wool
fill 356 277 294 358 279 294 minecraft:light_gray_wool
fill 356 277 297 357 279 297 minecraft:light_gray_wool
fill 356 277 315 358 279 315 minecraft:light_gray_wool
fill 358 277 297 368 279 297 minecraft:white_wool
fill 359 277 276 368 279 276 minecraft:white_wool
fill 359 277 284 367 279 286 minecraft:white_wool
fill 359 277 294 367 279 296 minecraft:white_wool
fill 359 277 305 367 279 307 minecraft:white_wool
fill 359 277 315 367 279 316 minecraft:white_wool
fill 361 277 279 361 279 279 minecraft:white_wool
fill 361 277 280 365 279 280 minecraft:light_gray_wool
fill 361 277 281 361 279 281 minecraft:white_wool
fill 361 277 289 361 279 289 minecraft:white_wool
fill 361 277 290 365 279 290 minecraft:light_gray_wool
fill 361 277 291 361 279 292 minecraft:white_wool
fill 361 277 300 361 279 300 minecraft:white_wool
fill 361 277 301 365 279 301 minecraft:light_gray_wool
fill 361 277 302 361 279 302 minecraft:white_wool
fill 361 277 310 361 279 310 minecraft:white_wool
fill 361 277 311 365 279 311 minecraft:light_gray_wool
fill 361 277 312 361 279 312 minecraft:white_wool
fill 362 277 279 365 279 279 minecraft:light_gray_wool
fill 362 277 281 364 279 281 minecraft:light_gray_wool
fill 362 277 289 364 279 289 minecraft:light_gray_wool
fill 362 277 291 365 279 291 minecraft:light_gray_wool
fill 362 277 292 370 279 292 minecraft:white_wool
fill 362 277 300 365 279 300 minecraft:light_gray_wool
fill 362 277 302 364 279 302 minecraft:light_gray_wool
fill 362 277 310 364 279 310 minecraft:light_gray_wool
fill 362 277 312 364 279 312 minecraft:light_gray_wool
fill 363 277 278 363 279 278 minecraft:light_gray_wool
fill 363 277 299 363 279 299 minecraft:light_gray_wool
fill 364 277 278 370 279 278 minecraft:white_wool
fill 364 277 299 370 279 299 minecraft:white_wool
fill 365 277 281 370 279 281 minecraft:white_wool
fill 365 277 289 370 279 289 minecraft:white_wool
fill 365 277 302 370 279 302 minecraft:white_wool
fill 365 277 310 370 279 310 minecraft:white_wool
fill 365 277 312 370 279 312 minecraft:white_wool
fill 366 277 279 370 279 280 minecraft:white_wool
fill 366 277 290 370 279 291 minecraft:white_wool
fill 366 277 300 370 279 301 minecraft:white_wool
fill 366 277 311 370 279 311 minecraft:white_wool
fill 368 277 284 370 279 286 minecraft:light_gray_wool
fill 368 277 294 370 279 296 minecraft:light_gray_wool
fill 368 277 305 370 279 307 minecraft:light_gray_wool
fill 368 277 315 370 279 316 minecraft:light_gray_wool
fill 369 277 276 370 279 276 minecraft:light_gray_wool
fill 369 277 297 370 279 297 minecraft:light_gray_wool
setblock 329 278 295 minecraft:white_wool
fill 329 278 296 329 308 296 minecraft:light_blue_concrete
fill 371 278 291 371 308 291 minecraft:light_blue_concrete
setblock 371 278 292 minecraft:white_wool
fill 329 279 295 329 308 295 minecraft:light_blue_concrete
fill 336 279 292 345 279 293 minecraft:white_wool
setblock 339 279 275 minecraft:white_wool
fill 340 279 291 346 279 291 minecraft:white_wool
fill 341 279 290 346 279 290 minecraft:white_wool
fill 346 279 292 346 279 294 minecraft:ochre_froglight
fill 346 279 297 348 279 297 minecraft:white_wool
fill 347 279 290 347 279 292 minecraft:ochre_froglight
fill 347 279 294 347 279 296 minecraft:ochre_froglight
fill 348 279 290 349 279 290 minecraft:ochre_froglight
fill 348 279 296 349 279 296 minecraft:ochre_froglight
fill 349 279 289 351 279 289 minecraft:ochre_froglight
fill 349 279 297 351 279 297 minecraft:ochre_froglight
fill 351 279 290 353 279 290 minecraft:ochre_froglight
fill 351 279 296 353 279 296 minecraft:ochre_froglight
setblock 352 279 289 minecraft:light_gray_wool
fill 352 279 297 355 279 297 minecraft:white_wool
fill 353 279 289 360 279 289 minecraft:white_wool
fill 353 279 291 353 279 292 minecraft:ochre_froglight
fill 353 279 294 353 279 295 minecraft:ochre_froglight
fill 354 279 290 360 279 291 minecraft:white_wool
fill 354 279 292 354 279 294 minecraft:ochre_froglight
fill 354 279 295 354 279 296 minecraft:white_wool
fill 355 279 292 360 279 293 minecraft:white_wool
setblock 356 279 317 minecraft:white_wool
setblock 360 279 317 minecraft:white_wool
fill 361 279 293 370 279 293 minecraft:white_wool
fill 371 279 292 371 304 292 minecraft:light_blue_concrete
setblock 371 279 294 minecraft:white_wool
setblock 329 280 287 minecraft:white_wool
setblock 332 280 278 minecraft:light[level=15]
setblock 332 280 286 minecraft:light[level=15]
setblock 332 280 294 minecraft:light[level=15]
setblock 332 280 302 minecraft:light[level=15]
setblock 332 280 310 minecraft:light[level=15]
fill 339 280 275 339 296 275 minecraft:light_blue_concrete
setblock 340 280 278 minecraft:light[level=15]
setblock 340 280 286 minecraft:light[level=15]
setblock 340 280 294 minecraft:light[level=15]
setblock 340 280 302 minecraft:light[level=15]
setblock 340 280 310 minecraft:light[level=15]
setblock 348 280 278 minecraft:light[level=15]
setblock 348 280 286 minecraft:light[level=15]
setblock 348 280 302 minecraft:light[level=15]
setblock 348 280 310 minecraft:light[level=15]
setblock 356 280 278 minecraft:light[level=15]
setblock 356 280 286 minecraft:light[level=15]
setblock 356 280 294 minecraft:light[level=15]
setblock 356 280 302 minecraft:light[level=15]
setblock 356 280 310 minecraft:light[level=15]
fill 356 280 317 356 308 317 minecraft:light_blue_concrete
fill 360 280 317 360 308 317 minecraft:light_blue_concrete
setblock 364 280 278 minecraft:light[level=15]
setblock 364 280 286 minecraft:light[level=15]
setblock 364 280 294 minecraft:light[level=15]
setblock 364 280 302 minecraft:light[level=15]
setblock 364 280 310 minecraft:light[level=15]
setblock 367 280 317 minecraft:white_wool
fill 371 280 294 371 295 294 minecraft:light_blue_concrete
setblock 329 281 284 minecraft:white_wool
fill 329 281 287 329 308 287 minecraft:light_blue_concrete
setblock 334 281 275 minecraft:white_wool
fill 336 281 317 337 308 317 minecraft:light_blue_concrete
setblock 338 281 317 minecraft:white_wool
fill 339 281 317 341 295 317 minecraft:light_blue_concrete
fill 342 281 306 344 283 307 minecraft:packed_mud
fill 343 281 305 344 283 305 minecraft:packed_mud
fill 367 281 317 367 302 317 minecraft:light_blue_concrete
setblock 371 281 290 minecraft:white_wool
fill 329 282 284 329 308 284 minecraft:light_blue_concrete
setblock 332 282 278 minecraft:light[level=12]
setblock 332 282 285 minecraft:light[level=12]
setblock 332 282 292 minecraft:light[level=12]
setblock 332 282 299 minecraft:light[level=12]
setblock 332 282 306 minecraft:light[level=12]
setblock 332 282 313 minecraft:light[level=12]
fill 334 282 275 334 308 275 minecraft:light_blue_concrete
setblock 337 282 275 minecraft:white_wool
fill 338 282 317 338 283 317 minecraft:light_blue_concrete
setblock 339 282 278 minecraft:light[level=12]
setblock 339 282 285 minecraft:light[level=12]
setblock 339 282 292 minecraft:light[level=12]
setblock 339 282 299 minecraft:light[level=12]
setblock 339 282 306 minecraft:light[level=12]
setblock 339 282 313 minecraft:light[level=12]
setblock 341 282 307 minecraft:packed_mud
fill 342 282 305 342 283 305 minecraft:packed_mud
fill 342 282 308 344 283 308 minecraft:packed_mud
fill 345 282 305 345 282 307 minecraft:packed_mud
setblock 346 282 278 minecraft:light[level=12]
setblock 346 282 285 minecraft:light[level=12]
setblock 346 282 292 minecraft:light[level=12]
setblock 346 282 299 minecraft:light[level=12]
setblock 346 282 306 minecraft:light[level=12]
setblock 346 282 313 minecraft:light[level=12]
setblock 353 282 278 minecraft:light[level=12]
setblock 353 282 285 minecraft:light[level=12]
setblock 353 282 292 minecraft:light[level=12]
setblock 353 282 299 minecraft:light[level=12]
setblock 353 282 306 minecraft:light[level=12]
setblock 353 282 313 minecraft:light[level=12]
setblock 360 282 278 minecraft:light[level=12]
setblock 360 282 285 minecraft:light[level=12]
setblock 360 282 292 minecraft:light[level=12]
setblock 360 282 299 minecraft:light[level=12]
setblock 360 282 306 minecraft:light[level=12]
setblock 360 282 313 minecraft:light[level=12]
setblock 367 282 278 minecraft:light[level=12]
setblock 367 282 285 minecraft:light[level=12]
setblock 367 282 292 minecraft:light[level=12]
setblock 367 282 299 minecraft:light[level=12]
setblock 367 282 306 minecraft:light[level=12]
setblock 367 282 313 minecraft:light[level=12]
setblock 370 282 275 minecraft:white_wool
fill 371 282 290 371 288 290 minecraft:light_blue_concrete
fill 337 283 275 337 308 275 minecraft:light_blue_concrete
fill 345 283 306 345 283 307 minecraft:packed_mud
fill 349 283 307 350 289 309 minecraft:dirt
setblock 351 283 317 minecraft:white_wool
fill 370 283 275 370 306 275 minecraft:light_blue_concrete
setblock 338 284 317 minecraft:white_wool
fill 341 284 307 342 285 307 minecraft:moss_block
fill 342 284 305 342 285 305 minecraft:moss_block
fill 342 284 306 344 284 306 minecraft:packed_mud
fill 342 284 308 342 285 308 minecraft:moss_block
fill 343 284 304 344 284 304 minecraft:moss_block
setblock 343 284 305 minecraft:packed_mud
fill 343 284 307 344 284 308 minecraft:packed_mud
fill 344 284 305 345 285 305 minecraft:moss_block
fill 345 284 306 345 285 306 minecraft:moss_block
setblock 345 284 307 minecraft:packed_mud
setblock 345 284 308 minecraft:moss_block
fill 348 284 307 348 289 309 minecraft:dirt
fill 348 284 310 348 285 310 minecraft:white_wool
fill 349 284 306 350 289 306 minecraft:dirt
fill 351 284 307 351 289 309 minecraft:dirt
fill 351 284 317 351 308 317 minecraft:light_blue_concrete
setblock 371 284 299 minecraft:white_wool
fill 338 285 317 338 308 317 minecraft:light_blue_concrete
fill 341 285 306 344 285 306 minecraft:moss_block
fill 343 285 304 343 285 305 minecraft:moss_block
fill 343 285 307 344 285 308 minecraft:moss_block
setblock 345 285 307 minecraft:moss_block
fill 348 285 306 348 289 306 minecraft:dirt
fill 349 285 310 350 289 310 minecraft:dirt
fill 351 285 306 351 289 306 minecraft:dirt
fill 371 285 299 371 308 299 minecraft:light_blue_concrete
setblock 329 286 299 minecraft:white_wool
fill 329 286 300 329 303 300 minecraft:light_blue_concrete
setblock 329 286 302 minecraft:white_wool
fill 347 286 285 348 287 286 minecraft:white_concrete
fill 347 286 307 347 289 309 minecraft:dirt
fill 348 286 310 348 289 310 minecraft:dirt
fill 349 286 305 349 289 305 minecraft:dirt
fill 351 286 310 351 289 310 minecraft:dirt
fill 352 286 307 352 289 309 minecraft:dirt
fill 329 287 299 329 308 299 minecraft:light_blue_concrete
fill 329 287 302 329 308 302 minecraft:light_blue_concrete
fill 332 287 317 333 308 317 minecraft:light_blue_concrete
setblock 334 287 317 minecraft:white_wool
fill 347 287 306 347 289 306 minecraft:dirt
fill 347 287 310 347 289 310 minecraft:dirt
fill 348 287 305 348 289 305 minecraft:dirt
fill 349 287 311 350 289 311 minecraft:dirt
fill 350 287 305 351 289 305 minecraft:dirt
fill 352 287 306 352 289 306 minecraft:dirt
fill 352 287 310 352 289 310 minecraft:dirt
setblock 332 288 278 minecraft:light[level=15]
setblock 332 288 285 minecraft:light[level=12]
setblock 332 288 286 minecraft:light[level=15]
setblock 332 288 292 minecraft:light[level=12]
setblock 332 288 294 minecraft:light[level=15]
setblock 332 288 299 minecraft:light[level=12]
setblock 332 288 302 minecraft:light[level=15]
setblock 332 288 306 minecraft:light[level=12]
setblock 332 288 310 minecraft:light[level=15]
setblock 332 288 313 minecraft:light[level=12]
fill 334 288 317 334 308 317 minecraft:light_blue_concrete
setblock 339 288 278 minecraft:light[level=12]
setblock 339 288 285 minecraft:light[level=12]
setblock 339 288 292 minecraft:light[level=12]
setblock 339 288 299 minecraft:light[level=12]
setblock 339 288 306 minecraft:light[level=12]
setblock 339 288 313 minecraft:light[level=12]
setblock 340 288 278 minecraft:light[level=15]
setblock 340 288 286 minecraft:light[level=15]
setblock 340 288 294 minecraft:light[level=15]
setblock 340 288 302 minecraft:light[level=15]
setblock 340 288 310 minecraft:light[level=15]
setblock 346 288 278 minecraft:light[level=12]
setblock 346 288 285 minecraft:light[level=12]
setblock 346 288 292 minecraft:light[level=12]
setblock 346 288 299 minecraft:light[level=12]
setblock 346 288 306 minecraft:light[level=12]
fill 346 288 307 346 289 309 minecraft:dirt
setblock 346 288 313 minecraft:light[level=12]
fill 347 288 305 347 289 305 minecraft:dirt
setblock 348 288 278 minecraft:light[level=15]
setblock 348 288 286 minecraft:light[level=15]
setblock 348 288 294 minecraft:light[level=15]
setblock 348 288 302 minecraft:light[level=15]
fill 348 288 311 348 289 311 minecraft:dirt
fill 351 288 311 351 289 311 minecraft:dirt
fill 352 288 305 352 289 305 minecraft:dirt
setblock 353 288 278 minecraft:light[level=12]
setblock 353 288 285 minecraft:light[level=12]
setblock 353 288 292 minecraft:light[level=12]
setblock 353 288 299 minecraft:light[level=12]
setblock 353 288 306 minecraft:light[level=12]
fill 353 288 307 353 289 309 minecraft:dirt
setblock 353 288 313 minecraft:light[level=12]
setblock 356 288 278 minecraft:light[level=15]
setblock 356 288 286 minecraft:light[level=15]
setblock 356 288 294 minecraft:light[level=15]
setblock 356 288 302 minecraft:light[level=15]
setblock 356 288 310 minecraft:light[level=15]
setblock 360 288 278 minecraft:light[level=12]
setblock 360 288 285 minecraft:light[level=12]
setblock 360 288 292 minecraft:light[level=12]
setblock 360 288 299 minecraft:light[level=12]
setblock 360 288 306 minecraft:light[level=12]
setblock 360 288 313 minecraft:light[level=12]
setblock 364 288 278 minecraft:light[level=15]
setblock 364 288 286 minecraft:light[level=15]
setblock 364 288 294 minecraft:light[level=15]
setblock 364 288 302 minecraft:light[level=15]
setblock 364 288 310 minecraft:light[level=15]
setblock 367 288 278 minecraft:light[level=12]
setblock 367 288 285 minecraft:light[level=12]
setblock 367 288 292 minecraft:light[level=12]
setblock 367 288 299 minecraft:light[level=12]
setblock 367 288 306 minecraft:light[level=12]
setblock 367 288 313 minecraft:light[level=12]
setblock 346 289 306 minecraft:dirt
setblock 346 289 310 minecraft:dirt
setblock 347 289 311 minecraft:dirt
fill 348 289 304 351 289 304 minecraft:dirt
fill 349 289 312 350 289 312 minecraft:dirt
setblock 352 289 311 minecraft:dirt
setblock 353 289 306 minecraft:dirt
setblock 353 289 310 minecraft:dirt
setblock 371 289 290 minecraft:white_wool
fill 349 290 308 350 292 308 minecraft:white_concrete
setblock 352 290 275 minecraft:white_wool
fill 371 290 290 371 308 290 minecraft:light_blue_concrete
fill 371 290 301 371 308 301 minecraft:light_blue_concrete
setblock 371 290 302 minecraft:white_wool
fill 329 291 312 329 308 313 minecraft:light_blue_concrete
setblock 329 291 314 minecraft:white_wool
fill 352 291 275 352 308 275 minecraft:light_blue_concrete
fill 371 291 302 371 298 302 minecraft:light_blue_concrete
setblock 329 292 314 minecraft:light_blue_concrete
fill 357 292 317 358 292 317 minecraft:white_wool
setblock 363 292 275 minecraft:white_wool
setblock 368 292 317 minecraft:white_wool
setblock 329 293 311 minecraft:white_wool
setblock 329 293 314 minecraft:white_wool
fill 348 293 307 351 295 309 minecraft:oak_leaves[persistent=true]
fill 349 293 306 350 295 306 minecraft:oak_leaves[persistent=true]
fill 357 293 317 358 308 317 minecraft:light_blue_concrete
fill 363 293 275 363 308 275 minecraft:light_blue_concrete
fill 368 293 317 368 308 317 minecraft:light_blue_concrete
fill 329 294 311 329 308 311 minecraft:light_blue_concrete
fill 329 294 314 329 308 314 minecraft:light_blue_concrete
setblock 332 294 278 minecraft:light[level=12]
setblock 332 294 285 minecraft:light[level=12]
setblock 332 294 292 minecraft:light[level=12]
setblock 332 294 299 minecraft:light[level=12]
setblock 332 294 306 minecraft:light[level=12]
setblock 332 294 313 minecraft:light[level=12]
setblock 339 294 278 minecraft:light[level=12]
setblock 339 294 285 minecraft:light[level=12]
setblock 339 294 292 minecraft:light[level=12]
setblock 339 294 299 minecraft:light[level=12]
setblock 339 294 306 minecraft:light[level=12]
setblock 339 294 313 minecraft:light[level=12]
setblock 346 294 278 minecraft:light[level=12]
setblock 346 294 285 minecraft:light[level=12]
setblock 346 294 292 minecraft:light[level=12]
setblock 346 294 299 minecraft:light[level=12]
setblock 346 294 306 minecraft:light[level=12]
setblock 346 294 313 minecraft:light[level=12]
setblock 348 294 306 minecraft:oak_leaves[persistent=true]
fill 349 294 310 350 294 310 minecraft:oak_leaves[persistent=true]
setblock 353 294 278 minecraft:light[level=12]
setblock 353 294 285 minecraft:light[level=12]
setblock 353 294 292 minecraft:light[level=12]
setblock 353 294 299 minecraft:light[level=12]
setblock 353 294 306 minecraft:light[level=12]
setblock 353 294 313 minecraft:light[level=12]
setblock 360 294 278 minecraft:light[level=12]
setblock 360 294 285 minecraft:light[level=12]
setblock 360 294 292 minecraft:light[level=12]
setblock 360 294 299 minecraft:light[level=12]
setblock 360 294 306 minecraft:light[level=12]
setblock 360 294 313 minecraft:light[level=12]
setblock 367 294 278 minecraft:light[level=12]
setblock 367 294 285 minecraft:light[level=12]
setblock 367 294 292 minecraft:light[level=12]
setblock 367 294 299 minecraft:light[level=12]
setblock 367 294 306 minecraft:light[level=12]
setblock 367 294 313 minecraft:light[level=12]
fill 329 295 279 329 308 279 minecraft:light_blue_concrete
setblock 329 295 280 minecraft:white_wool
setblock 347 295 275 minecraft:white_wool
fill 348 295 275 348 308 275 minecraft:light_blue_concrete
setblock 371 295 308 minecraft:white_wool
fill 371 295 309 371 308 309 minecraft:light_blue_concrete
setblock 371 295 312 minecraft:white_wool
fill 371 295 313 371 299 315 minecraft:light_blue_concrete
fill 329 296 280 329 308 280 minecraft:light_blue_concrete
fill 329 296 288 329 308 290 minecraft:light_blue_concrete
setblock 329 296 291 minecraft:white_wool
fill 329 296 292 329 308 292 minecraft:light_blue_concrete
setblock 332 296 278 minecraft:light[level=15]
setblock 332 296 286 minecraft:light[level=15]
setblock 332 296 294 minecraft:light[level=15]
setblock 332 296 302 minecraft:light[level=15]
setblock 332 296 310 minecraft:light[level=15]
fill 335 296 292 335 297 293 minecraft:white_concrete
fill 339 296 317 340 299 317 minecraft:light_blue_concrete
setblock 340 296 278 minecraft:light[level=15]
setblock 340 296 286 minecraft:light[level=15]
setblock 340 296 294 minecraft:light[level=15]
setblock 340 296 302 minecraft:light[level=15]
setblock 340 296 310 minecraft:light[level=15]
setblock 341 296 317 minecraft:white_wool
fill 347 296 275 347 308 275 minecraft:light_blue_concrete
setblock 348 296 278 minecraft:light[level=15]
setblock 348 296 286 minecraft:light[level=15]
setblock 348 296 294 minecraft:light[level=15]
setblock 348 296 302 minecraft:light[level=15]
setblock 348 296 310 minecraft:light[level=15]
setblock 356 296 278 minecraft:light[level=15]
setblock 356 296 286 minecraft:light[level=15]
setblock 356 296 294 minecraft:light[level=15]
setblock 356 296 302 minecraft:light[level=15]
setblock 356 296 310 minecraft:light[level=15]
setblock 364 296 278 minecraft:light[level=15]
setblock 364 296 286 minecraft:light[level=15]
setblock 364 296 294 minecraft:light[level=15]
setblock 364 296 302 minecraft:light[level=15]
setblock 364 296 310 minecraft:light[level=15]
setblock 371 296 294 minecraft:white_wool
fill 371 296 308 371 308 308 minecraft:light_blue_concrete
fill 371 296 312 371 308 312 minecraft:light_blue_concrete
fill 329 297 291 329 308 291 minecraft:light_blue_concrete
setblock 333 297 275 minecraft:white_wool
setblock 339 297 275 minecraft:white_wool
fill 341 297 317 341 308 317 minecraft:light_blue_concrete
setblock 343 297 317 minecraft:white_wool
fill 371 297 294 371 308 294 minecraft:light_blue_concrete
fill 333 298 275 333 308 275 minecraft:light_blue_concrete
setblock 338 298 275 minecraft:white_wool
fill 339 298 275 339 308 275 minecraft:light_blue_concrete
fill 343 298 317 343 308 317 minecraft:light_blue_concrete
setblock 344 298 275 minecraft:white_wool
fill 344 298 287 346 299 287 minecraft:white_wool
fill 345 298 286 345 299 286 minecraft:white_wool
fill 345 298 288 345 299 288 minecraft:white_wool
fill 361 298 275 361 308 275 minecraft:light_blue_concrete
setblock 362 298 275 minecraft:white_wool
fill 338 299 275 338 308 275 minecraft:light_blue_concrete
fill 344 299 275 344 308 275 minecraft:light_blue_concrete
fill 362 299 275 362 308 275 minecraft:light_blue_concrete
setblock 371 299 302 minecraft:white_wool
setblock 329 300 294 minecraft:white_wool
setblock 332 300 278 minecraft:light[level=12]
setblock 332 300 285 minecraft:light[level=12]
setblock 332 300 292 minecraft:light[level=12]
setblock 332 300 299 minecraft:light[level=12]
setblock 332 300 306 minecraft:light[level=12]
setblock 332 300 313 minecraft:light[level=12]
setblock 339 300 278 minecraft:light[level=12]
setblock 339 300 285 minecraft:light[level=12]
setblock 339 300 292 minecraft:light[level=12]
setblock 339 300 299 minecraft:light[level=12]
schedule function dropper:buildpart/67_3 1t
