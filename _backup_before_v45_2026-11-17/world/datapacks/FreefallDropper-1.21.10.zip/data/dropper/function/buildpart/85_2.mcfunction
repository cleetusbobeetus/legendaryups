setblock 71 279 394 minecraft:black_concrete
setblock 71 279 395 minecraft:white_concrete
fill 71 279 396 72 279 397 minecraft:gray_concrete
fill 72 279 381 88 279 381 minecraft:purple_concrete
fill 72 279 382 73 279 382 minecraft:red_concrete
fill 72 279 386 74 279 386 minecraft:gray_concrete
fill 72 279 389 77 279 389 minecraft:black_concrete
fill 72 279 390 72 279 394 minecraft:white_concrete
fill 72 279 395 77 279 395 minecraft:black_concrete
fill 72 279 398 74 279 398 minecraft:gray_concrete
fill 72 279 402 73 279 402 minecraft:red_concrete
fill 72 279 403 88 279 403 minecraft:purple_concrete
fill 73 279 385 75 279 385 minecraft:gray_concrete
setblock 73 279 387 minecraft:gray_concrete
fill 73 279 388 77 279 388 minecraft:black_concrete
fill 73 279 390 77 279 394 minecraft:black_concrete
fill 73 279 396 77 279 396 minecraft:black_concrete
setblock 73 279 397 minecraft:gray_concrete
fill 73 279 399 75 279 399 minecraft:gray_concrete
fill 74 279 382 88 279 382 minecraft:purple_concrete
setblock 74 279 383 minecraft:red_concrete
setblock 74 279 384 minecraft:gray_concrete
fill 74 279 387 76 279 387 minecraft:black_concrete
fill 74 279 397 76 279 397 minecraft:black_concrete
setblock 74 279 400 minecraft:gray_concrete
setblock 74 279 401 minecraft:red_concrete
fill 74 279 402 88 279 402 minecraft:purple_concrete
fill 75 279 383 88 279 383 minecraft:purple_concrete
setblock 75 279 384 minecraft:red_concrete
fill 75 279 386 76 279 386 minecraft:black_concrete
fill 75 279 398 76 279 398 minecraft:black_concrete
setblock 75 279 400 minecraft:red_concrete
fill 75 279 401 88 279 401 minecraft:purple_concrete
fill 76 279 384 88 279 384 minecraft:purple_concrete
setblock 76 279 385 minecraft:red_concrete
setblock 76 279 399 minecraft:red_concrete
fill 76 279 400 88 279 400 minecraft:purple_concrete
fill 77 279 385 88 279 385 minecraft:purple_concrete
fill 77 279 386 77 279 387 minecraft:red_concrete
fill 77 279 397 77 279 398 minecraft:red_concrete
fill 77 279 399 88 279 399 minecraft:purple_concrete
fill 78 279 386 88 279 387 minecraft:purple_concrete
fill 78 279 388 78 279 396 minecraft:red_concrete
fill 78 279 397 88 279 398 minecraft:purple_concrete
fill 79 279 388 88 279 391 minecraft:purple_concrete
setblock 79 279 392 minecraft:red_concrete
fill 79 279 393 88 279 396 minecraft:purple_concrete
fill 80 279 392 88 279 392 minecraft:purple_concrete
setblock 50 281 372 minecraft:light[level=14]
setblock 50 281 380 minecraft:light[level=14]
setblock 50 281 388 minecraft:light[level=14]
setblock 50 281 396 minecraft:light[level=14]
setblock 50 281 404 minecraft:light[level=14]
setblock 58 281 372 minecraft:light[level=14]
setblock 58 281 380 minecraft:light[level=14]
setblock 58 281 388 minecraft:light[level=14]
setblock 58 281 396 minecraft:light[level=14]
setblock 58 281 404 minecraft:light[level=14]
setblock 66 281 372 minecraft:light[level=14]
setblock 66 281 380 minecraft:light[level=14]
setblock 66 281 388 minecraft:light[level=14]
setblock 66 281 396 minecraft:light[level=14]
setblock 66 281 404 minecraft:light[level=14]
setblock 74 281 372 minecraft:light[level=14]
setblock 74 281 380 minecraft:light[level=14]
setblock 74 281 388 minecraft:light[level=14]
setblock 74 281 396 minecraft:light[level=14]
setblock 74 281 404 minecraft:light[level=14]
setblock 82 281 372 minecraft:light[level=14]
setblock 82 281 380 minecraft:light[level=14]
setblock 82 281 388 minecraft:light[level=14]
setblock 82 281 396 minecraft:light[level=14]
setblock 82 281 404 minecraft:light[level=14]
fill 48 283 370 57 285 373 minecraft:magenta_concrete
fill 48 283 376 48 285 385 minecraft:magenta_concrete
fill 48 283 392 48 300 393 minecraft:magenta_concrete
fill 48 283 400 48 300 401 minecraft:magenta_concrete
fill 48 283 408 48 300 409 minecraft:magenta_concrete
fill 49 283 378 51 285 384 minecraft:magenta_concrete
fill 54 283 410 55 300 410 minecraft:magenta_concrete
fill 58 283 370 58 300 370 minecraft:magenta_concrete
fill 62 283 410 63 300 410 minecraft:magenta_concrete
fill 65 283 370 66 300 370 minecraft:magenta_concrete
fill 68 283 370 76 285 373 minecraft:magenta_concrete
fill 70 283 410 71 300 410 minecraft:magenta_concrete
fill 78 283 410 79 300 410 minecraft:magenta_concrete
fill 81 283 370 88 300 380 minecraft:magenta_concrete
fill 86 283 410 87 300 410 minecraft:magenta_concrete
fill 88 283 387 88 300 388 minecraft:magenta_concrete
fill 88 283 395 88 300 396 minecraft:magenta_concrete
fill 88 283 403 88 300 404 minecraft:magenta_concrete
fill 47 284 374 47 289 374 minecraft:sea_lantern
fill 47 284 382 47 289 382 minecraft:sea_lantern
fill 47 284 390 47 289 390 minecraft:sea_lantern
fill 47 284 398 47 289 398 minecraft:sea_lantern
fill 47 284 406 47 289 406 minecraft:sea_lantern
fill 50 284 411 50 289 411 minecraft:sea_lantern
fill 54 284 369 54 289 369 minecraft:sea_lantern
fill 58 284 411 58 289 411 minecraft:sea_lantern
fill 62 284 369 62 289 369 minecraft:sea_lantern
fill 66 284 411 66 289 411 minecraft:sea_lantern
fill 70 284 369 70 289 369 minecraft:sea_lantern
fill 74 284 411 74 289 411 minecraft:sea_lantern
fill 78 284 369 78 289 369 minecraft:sea_lantern
fill 82 284 411 82 289 411 minecraft:sea_lantern
fill 86 284 369 86 289 369 minecraft:sea_lantern
fill 89 284 374 89 289 374 minecraft:sea_lantern
fill 89 284 382 89 289 382 minecraft:sea_lantern
fill 89 284 390 89 289 390 minecraft:sea_lantern
fill 89 284 398 89 289 398 minecraft:sea_lantern
fill 89 284 406 89 289 406 minecraft:sea_lantern
fill 47 286 370 47 307 370 minecraft:black_concrete
setblock 47 286 371 minecraft:sea_lantern
setblock 47 286 373 minecraft:sea_lantern
setblock 48 286 370 minecraft:sea_lantern
fill 48 286 371 48 300 371 minecraft:magenta_concrete
setblock 48 286 372 minecraft:sea_lantern
fill 48 286 373 48 300 373 minecraft:magenta_concrete
fill 48 286 376 48 300 377 minecraft:magenta_concrete
setblock 48 286 378 minecraft:sea_lantern
fill 48 286 379 48 300 379 minecraft:magenta_concrete
setblock 48 286 380 minecraft:sea_lantern
fill 48 286 381 48 300 381 minecraft:magenta_concrete
setblock 48 286 382 minecraft:sea_lantern
fill 48 286 383 48 300 383 minecraft:magenta_concrete
setblock 48 286 384 minecraft:sea_lantern
fill 48 286 385 48 300 385 minecraft:magenta_concrete
fill 49 286 370 49 300 370 minecraft:magenta_concrete
setblock 49 286 371 minecraft:sea_lantern
fill 49 286 372 49 300 372 minecraft:magenta_concrete
setblock 49 286 373 minecraft:sea_lantern
fill 49 286 378 49 300 378 minecraft:magenta_concrete
setblock 49 286 379 minecraft:sea_lantern
fill 49 286 380 49 300 380 minecraft:magenta_concrete
setblock 49 286 381 minecraft:sea_lantern
fill 49 286 382 49 300 382 minecraft:magenta_concrete
setblock 49 286 383 minecraft:sea_lantern
fill 49 286 384 49 300 384 minecraft:magenta_concrete
setblock 50 286 370 minecraft:sea_lantern
fill 50 286 371 50 300 371 minecraft:magenta_concrete
setblock 50 286 372 minecraft:sea_lantern
fill 50 286 373 50 300 373 minecraft:magenta_concrete
setblock 50 286 378 minecraft:sea_lantern
fill 50 286 379 50 300 379 minecraft:magenta_concrete
setblock 50 286 380 minecraft:sea_lantern
fill 50 286 381 50 300 381 minecraft:magenta_concrete
setblock 50 286 382 minecraft:sea_lantern
fill 50 286 383 50 300 383 minecraft:magenta_concrete
setblock 50 286 384 minecraft:sea_lantern
fill 51 286 370 51 300 370 minecraft:magenta_concrete
setblock 51 286 371 minecraft:sea_lantern
fill 51 286 372 51 300 372 minecraft:magenta_concrete
setblock 51 286 373 minecraft:sea_lantern
fill 51 286 378 51 300 378 minecraft:magenta_concrete
setblock 51 286 379 minecraft:sea_lantern
fill 51 286 380 51 300 380 minecraft:magenta_concrete
setblock 51 286 381 minecraft:sea_lantern
fill 51 286 382 51 300 382 minecraft:magenta_concrete
setblock 51 286 383 minecraft:sea_lantern
fill 51 286 384 51 300 384 minecraft:magenta_concrete
setblock 52 286 370 minecraft:sea_lantern
fill 52 286 371 52 300 371 minecraft:magenta_concrete
setblock 52 286 372 minecraft:sea_lantern
fill 52 286 373 52 300 373 minecraft:magenta_concrete
fill 53 286 370 53 300 370 minecraft:magenta_concrete
setblock 53 286 371 minecraft:sea_lantern
fill 53 286 372 53 300 372 minecraft:magenta_concrete
setblock 53 286 373 minecraft:sea_lantern
setblock 54 286 370 minecraft:sea_lantern
fill 54 286 371 54 300 371 minecraft:magenta_concrete
setblock 54 286 372 minecraft:sea_lantern
fill 54 286 373 54 300 373 minecraft:magenta_concrete
fill 55 286 370 55 300 370 minecraft:magenta_concrete
setblock 55 286 371 minecraft:sea_lantern
fill 55 286 372 55 300 372 minecraft:magenta_concrete
setblock 55 286 373 minecraft:sea_lantern
setblock 56 286 370 minecraft:sea_lantern
fill 56 286 371 56 300 371 minecraft:magenta_concrete
setblock 56 286 372 minecraft:sea_lantern
fill 56 286 373 56 300 373 minecraft:magenta_concrete
fill 57 286 370 57 300 370 minecraft:magenta_concrete
setblock 57 286 371 minecraft:sea_lantern
fill 57 286 372 57 300 372 minecraft:magenta_concrete
setblock 57 286 373 minecraft:sea_lantern
setblock 68 286 370 minecraft:sea_lantern
fill 68 286 371 68 300 371 minecraft:magenta_concrete
setblock 68 286 372 minecraft:sea_lantern
fill 68 286 373 68 300 373 minecraft:magenta_concrete
fill 69 286 370 69 300 370 minecraft:magenta_concrete
setblock 69 286 371 minecraft:sea_lantern
fill 69 286 372 69 300 372 minecraft:magenta_concrete
setblock 69 286 373 minecraft:sea_lantern
setblock 70 286 370 minecraft:sea_lantern
fill 70 286 371 70 300 371 minecraft:magenta_concrete
setblock 70 286 372 minecraft:sea_lantern
fill 70 286 373 70 300 373 minecraft:magenta_concrete
fill 71 286 370 71 300 370 minecraft:magenta_concrete
setblock 71 286 371 minecraft:sea_lantern
fill 71 286 372 71 300 372 minecraft:magenta_concrete
setblock 71 286 373 minecraft:sea_lantern
setblock 72 286 370 minecraft:sea_lantern
fill 72 286 371 72 300 371 minecraft:magenta_concrete
setblock 72 286 372 minecraft:sea_lantern
fill 72 286 373 72 300 373 minecraft:magenta_concrete
fill 73 286 370 73 300 370 minecraft:magenta_concrete
setblock 73 286 371 minecraft:sea_lantern
fill 73 286 372 73 300 372 minecraft:magenta_concrete
setblock 73 286 373 minecraft:sea_lantern
setblock 74 286 370 minecraft:sea_lantern
fill 74 286 371 74 300 371 minecraft:magenta_concrete
setblock 74 286 372 minecraft:sea_lantern
fill 74 286 373 74 300 373 minecraft:magenta_concrete
fill 74 286 384 74 287 384 minecraft:cyan_concrete
fill 75 286 370 75 300 370 minecraft:magenta_concrete
setblock 75 286 371 minecraft:sea_lantern
fill 75 286 372 75 300 372 minecraft:magenta_concrete
setblock 75 286 373 minecraft:sea_lantern
setblock 76 286 370 minecraft:sea_lantern
fill 76 286 371 76 300 371 minecraft:magenta_concrete
setblock 76 286 372 minecraft:sea_lantern
fill 76 286 373 76 300 373 minecraft:magenta_concrete
fill 47 287 371 47 288 371 minecraft:black_concrete
fill 47 287 373 47 288 373 minecraft:black_concrete
fill 48 287 370 48 288 370 minecraft:magenta_concrete
fill 48 287 372 48 288 372 minecraft:magenta_concrete
fill 48 287 378 48 288 378 minecraft:magenta_concrete
fill 48 287 380 48 288 380 minecraft:magenta_concrete
fill 48 287 382 48 288 382 minecraft:magenta_concrete
fill 48 287 384 48 288 384 minecraft:magenta_concrete
fill 49 287 371 49 288 371 minecraft:magenta_concrete
fill 49 287 373 49 288 373 minecraft:magenta_concrete
fill 49 287 379 49 288 379 minecraft:magenta_concrete
fill 49 287 381 49 288 381 minecraft:magenta_concrete
fill 49 287 383 49 288 383 minecraft:magenta_concrete
fill 50 287 370 50 288 370 minecraft:magenta_concrete
fill 50 287 372 50 288 372 minecraft:magenta_concrete
fill 50 287 378 50 288 378 minecraft:magenta_concrete
fill 50 287 380 50 288 380 minecraft:magenta_concrete
fill 50 287 382 50 288 382 minecraft:magenta_concrete
fill 50 287 384 50 288 384 minecraft:magenta_concrete
fill 51 287 371 51 288 371 minecraft:magenta_concrete
fill 51 287 373 51 288 373 minecraft:magenta_concrete
fill 51 287 379 51 288 379 minecraft:magenta_concrete
fill 51 287 381 51 288 381 minecraft:magenta_concrete
fill 51 287 383 51 288 383 minecraft:magenta_concrete
fill 52 287 370 52 288 370 minecraft:magenta_concrete
fill 52 287 372 52 288 372 minecraft:magenta_concrete
fill 53 287 371 53 288 371 minecraft:magenta_concrete
fill 53 287 373 53 288 373 minecraft:magenta_concrete
fill 54 287 370 54 288 370 minecraft:magenta_concrete
fill 54 287 372 54 288 372 minecraft:magenta_concrete
fill 55 287 371 55 288 371 minecraft:magenta_concrete
fill 55 287 373 55 288 373 minecraft:magenta_concrete
fill 56 287 370 56 288 370 minecraft:magenta_concrete
fill 56 287 372 56 288 372 minecraft:magenta_concrete
fill 57 287 371 57 288 371 minecraft:magenta_concrete
fill 57 287 373 57 288 373 minecraft:magenta_concrete
fill 68 287 370 68 288 370 minecraft:magenta_concrete
fill 68 287 372 68 288 372 minecraft:magenta_concrete
fill 69 287 371 69 288 371 minecraft:magenta_concrete
fill 69 287 373 69 288 373 minecraft:magenta_concrete
fill 70 287 370 70 288 370 minecraft:magenta_concrete
fill 70 287 372 70 288 372 minecraft:magenta_concrete
fill 71 287 371 71 288 371 minecraft:magenta_concrete
fill 71 287 373 71 288 373 minecraft:magenta_concrete
fill 72 287 370 72 288 370 minecraft:magenta_concrete
fill 72 287 372 72 288 372 minecraft:magenta_concrete
fill 73 287 371 73 288 371 minecraft:magenta_concrete
fill 73 287 373 73 288 373 minecraft:magenta_concrete
fill 74 287 370 74 288 370 minecraft:magenta_concrete
fill 74 287 372 74 288 372 minecraft:magenta_concrete
fill 75 287 371 75 288 371 minecraft:magenta_concrete
fill 75 287 373 75 288 373 minecraft:magenta_concrete
fill 76 287 370 76 288 370 minecraft:magenta_concrete
fill 76 287 372 76 288 372 minecraft:magenta_concrete
fill 83 288 393 87 289 397 minecraft:pink_concrete
setblock 47 289 371 minecraft:sea_lantern
setblock 47 289 373 minecraft:sea_lantern
setblock 48 289 370 minecraft:sea_lantern
setblock 48 289 372 minecraft:sea_lantern
setblock 48 289 378 minecraft:sea_lantern
setblock 48 289 380 minecraft:sea_lantern
setblock 48 289 382 minecraft:sea_lantern
setblock 48 289 384 minecraft:sea_lantern
setblock 49 289 371 minecraft:sea_lantern
setblock 49 289 373 minecraft:sea_lantern
setblock 49 289 379 minecraft:sea_lantern
setblock 49 289 381 minecraft:sea_lantern
setblock 49 289 383 minecraft:sea_lantern
setblock 50 289 370 minecraft:sea_lantern
setblock 50 289 372 minecraft:sea_lantern
setblock 50 289 378 minecraft:sea_lantern
setblock 50 289 380 minecraft:sea_lantern
setblock 50 289 382 minecraft:sea_lantern
setblock 50 289 384 minecraft:sea_lantern
setblock 50 289 388 minecraft:light[level=14]
setblock 50 289 396 minecraft:light[level=14]
setblock 50 289 404 minecraft:light[level=14]
setblock 51 289 371 minecraft:sea_lantern
setblock 51 289 373 minecraft:sea_lantern
setblock 51 289 379 minecraft:sea_lantern
setblock 51 289 381 minecraft:sea_lantern
setblock 51 289 383 minecraft:sea_lantern
setblock 52 289 370 minecraft:sea_lantern
setblock 52 289 372 minecraft:sea_lantern
setblock 53 289 371 minecraft:sea_lantern
setblock 53 289 373 minecraft:sea_lantern
setblock 54 289 370 minecraft:sea_lantern
setblock 54 289 372 minecraft:sea_lantern
setblock 55 289 371 minecraft:sea_lantern
setblock 55 289 373 minecraft:sea_lantern
setblock 56 289 370 minecraft:sea_lantern
setblock 56 289 372 minecraft:sea_lantern
setblock 57 289 371 minecraft:sea_lantern
setblock 57 289 373 minecraft:sea_lantern
setblock 58 289 372 minecraft:light[level=14]
setblock 58 289 380 minecraft:light[level=14]
setblock 58 289 388 minecraft:light[level=14]
setblock 58 289 396 minecraft:light[level=14]
setblock 58 289 404 minecraft:light[level=14]
setblock 66 289 372 minecraft:light[level=14]
setblock 66 289 380 minecraft:light[level=14]
setblock 66 289 388 minecraft:light[level=14]
setblock 66 289 396 minecraft:light[level=14]
setblock 66 289 404 minecraft:light[level=14]
setblock 68 289 370 minecraft:sea_lantern
setblock 68 289 372 minecraft:sea_lantern
setblock 69 289 371 minecraft:sea_lantern
setblock 69 289 373 minecraft:sea_lantern
setblock 70 289 370 minecraft:sea_lantern
setblock 70 289 372 minecraft:sea_lantern
setblock 71 289 371 minecraft:sea_lantern
setblock 71 289 373 minecraft:sea_lantern
setblock 72 289 370 minecraft:sea_lantern
setblock 72 289 372 minecraft:sea_lantern
setblock 73 289 371 minecraft:sea_lantern
setblock 73 289 373 minecraft:sea_lantern
setblock 74 289 370 minecraft:sea_lantern
setblock 74 289 372 minecraft:sea_lantern
setblock 74 289 380 minecraft:light[level=14]
setblock 74 289 388 minecraft:light[level=14]
setblock 74 289 396 minecraft:light[level=14]
setblock 74 289 404 minecraft:light[level=14]
setblock 75 289 371 minecraft:sea_lantern
setblock 75 289 373 minecraft:sea_lantern
setblock 76 289 370 minecraft:sea_lantern
setblock 76 289 372 minecraft:sea_lantern
setblock 82 289 388 minecraft:light[level=14]
setblock 82 289 396 minecraft:light[level=14]
setblock 82 289 404 minecraft:light[level=14]
fill 47 290 371 47 291 371 minecraft:black_concrete
fill 47 290 373 47 291 374 minecraft:black_concrete
fill 47 290 382 47 297 382 minecraft:black_concrete
fill 47 290 390 47 297 390 minecraft:black_concrete
fill 47 290 398 47 297 398 minecraft:black_concrete
fill 47 290 406 47 297 406 minecraft:black_concrete
fill 48 290 370 48 291 370 minecraft:magenta_concrete
fill 48 290 372 48 291 372 minecraft:magenta_concrete
fill 48 290 378 48 291 378 minecraft:magenta_concrete
fill 48 290 380 48 291 380 minecraft:magenta_concrete
fill 48 290 382 48 291 382 minecraft:magenta_concrete
fill 48 290 384 48 291 384 minecraft:magenta_concrete
fill 49 290 371 49 291 371 minecraft:magenta_concrete
fill 49 290 373 49 291 373 minecraft:magenta_concrete
fill 49 290 379 49 291 379 minecraft:magenta_concrete
fill 49 290 381 49 291 381 minecraft:magenta_concrete
fill 49 290 383 49 291 383 minecraft:magenta_concrete
fill 50 290 370 50 291 370 minecraft:magenta_concrete
fill 50 290 372 50 291 372 minecraft:magenta_concrete
fill 50 290 378 50 291 378 minecraft:magenta_concrete
fill 50 290 380 50 291 380 minecraft:magenta_concrete
fill 50 290 382 50 291 382 minecraft:magenta_concrete
fill 50 290 384 50 291 384 minecraft:magenta_concrete
fill 50 290 411 50 297 411 minecraft:black_concrete
fill 51 290 371 51 291 371 minecraft:magenta_concrete
fill 51 290 373 51 291 373 minecraft:magenta_concrete
fill 51 290 379 51 291 379 minecraft:magenta_concrete
fill 51 290 381 51 291 381 minecraft:magenta_concrete
fill 51 290 383 51 291 383 minecraft:magenta_concrete
fill 52 290 370 52 291 370 minecraft:magenta_concrete
fill 52 290 372 52 291 372 minecraft:magenta_concrete
fill 53 290 371 53 291 371 minecraft:magenta_concrete
fill 53 290 373 53 291 373 minecraft:magenta_concrete
fill 54 290 369 54 297 369 minecraft:black_concrete
fill 54 290 370 54 291 370 minecraft:magenta_concrete
fill 54 290 372 54 291 372 minecraft:magenta_concrete
fill 55 290 371 55 291 371 minecraft:magenta_concrete
fill 55 290 373 55 291 373 minecraft:magenta_concrete
fill 56 290 370 56 291 370 minecraft:magenta_concrete
fill 56 290 372 56 291 372 minecraft:magenta_concrete
fill 57 290 371 57 291 371 minecraft:magenta_concrete
fill 57 290 373 57 291 373 minecraft:magenta_concrete
fill 58 290 411 58 297 411 minecraft:black_concrete
fill 62 290 369 62 297 369 minecraft:black_concrete
fill 66 290 411 66 297 411 minecraft:black_concrete
fill 68 290 370 68 291 370 minecraft:magenta_concrete
fill 68 290 372 68 291 372 minecraft:magenta_concrete
fill 69 290 371 69 291 371 minecraft:magenta_concrete
fill 69 290 373 69 291 373 minecraft:magenta_concrete
fill 70 290 369 70 297 369 minecraft:black_concrete
fill 70 290 370 70 291 370 minecraft:magenta_concrete
fill 70 290 372 70 291 372 minecraft:magenta_concrete
fill 71 290 371 71 291 371 minecraft:magenta_concrete
fill 71 290 373 71 291 373 minecraft:magenta_concrete
fill 72 290 370 72 291 370 minecraft:magenta_concrete
fill 72 290 372 72 291 372 minecraft:magenta_concrete
fill 73 290 371 73 291 371 minecraft:magenta_concrete
fill 73 290 373 73 291 373 minecraft:magenta_concrete
fill 74 290 370 74 291 370 minecraft:magenta_concrete
fill 74 290 372 74 291 372 minecraft:magenta_concrete
fill 74 290 411 74 297 411 minecraft:black_concrete
fill 75 290 371 75 291 371 minecraft:magenta_concrete
fill 75 290 373 75 291 373 minecraft:magenta_concrete
fill 76 290 370 76 291 370 minecraft:magenta_concrete
fill 76 290 372 76 291 372 minecraft:magenta_concrete
fill 78 290 369 78 297 369 minecraft:black_concrete
fill 82 290 411 82 297 411 minecraft:black_concrete
fill 83 290 394 87 291 396 minecraft:pink_concrete
fill 84 290 393 86 291 393 minecraft:pink_concrete
fill 84 290 397 86 291 397 minecraft:pink_concrete
fill 86 290 369 86 297 369 minecraft:black_concrete
fill 89 290 374 89 297 374 minecraft:black_concrete
fill 89 290 382 89 297 382 minecraft:black_concrete
fill 89 290 390 89 297 390 minecraft:black_concrete
fill 89 290 398 89 297 398 minecraft:black_concrete
fill 89 290 406 89 297 406 minecraft:black_concrete
setblock 47 292 371 minecraft:sea_lantern
setblock 47 292 373 minecraft:sea_lantern
fill 47 292 374 47 297 374 minecraft:black_concrete
setblock 48 292 370 minecraft:sea_lantern
setblock 48 292 372 minecraft:sea_lantern
setblock 48 292 378 minecraft:sea_lantern
setblock 48 292 380 minecraft:sea_lantern
setblock 48 292 382 minecraft:sea_lantern
setblock 48 292 384 minecraft:sea_lantern
setblock 49 292 371 minecraft:sea_lantern
setblock 49 292 373 minecraft:sea_lantern
setblock 49 292 379 minecraft:sea_lantern
setblock 49 292 381 minecraft:sea_lantern
setblock 49 292 383 minecraft:sea_lantern
setblock 50 292 370 minecraft:sea_lantern
setblock 50 292 372 minecraft:sea_lantern
setblock 50 292 378 minecraft:sea_lantern
setblock 50 292 380 minecraft:sea_lantern
setblock 50 292 382 minecraft:sea_lantern
setblock 50 292 384 minecraft:sea_lantern
setblock 51 292 371 minecraft:sea_lantern
setblock 51 292 373 minecraft:sea_lantern
setblock 51 292 379 minecraft:sea_lantern
setblock 51 292 381 minecraft:sea_lantern
setblock 51 292 383 minecraft:sea_lantern
setblock 52 292 370 minecraft:sea_lantern
setblock 52 292 372 minecraft:sea_lantern
setblock 53 292 371 minecraft:sea_lantern
setblock 53 292 373 minecraft:sea_lantern
setblock 54 292 370 minecraft:sea_lantern
setblock 54 292 372 minecraft:sea_lantern
setblock 55 292 371 minecraft:sea_lantern
setblock 55 292 373 minecraft:sea_lantern
setblock 56 292 370 minecraft:sea_lantern
setblock 56 292 372 minecraft:sea_lantern
setblock 57 292 371 minecraft:sea_lantern
setblock 57 292 373 minecraft:sea_lantern
setblock 68 292 370 minecraft:sea_lantern
setblock 68 292 372 minecraft:sea_lantern
setblock 69 292 371 minecraft:sea_lantern
setblock 69 292 373 minecraft:sea_lantern
setblock 70 292 370 minecraft:sea_lantern
setblock 70 292 372 minecraft:sea_lantern
setblock 71 292 371 minecraft:sea_lantern
setblock 71 292 373 minecraft:sea_lantern
setblock 72 292 370 minecraft:sea_lantern
setblock 72 292 372 minecraft:sea_lantern
setblock 73 292 371 minecraft:sea_lantern
setblock 73 292 373 minecraft:sea_lantern
setblock 74 292 370 minecraft:sea_lantern
setblock 74 292 372 minecraft:sea_lantern
setblock 75 292 371 minecraft:sea_lantern
setblock 75 292 373 minecraft:sea_lantern
setblock 76 292 370 minecraft:sea_lantern
setblock 76 292 372 minecraft:sea_lantern
fill 83 292 395 87 292 395 minecraft:pink_concrete
fill 84 292 394 86 292 394 minecraft:pink_concrete
fill 84 292 396 86 292 396 minecraft:pink_concrete
setblock 85 292 393 minecraft:pink_concrete
setblock 85 292 397 minecraft:pink_concrete
fill 47 293 371 47 294 371 minecraft:black_concrete
fill 47 293 373 47 294 373 minecraft:black_concrete
fill 48 293 370 48 294 370 minecraft:magenta_concrete
fill 48 293 372 48 294 372 minecraft:magenta_concrete
fill 48 293 378 48 294 378 minecraft:magenta_concrete
fill 48 293 380 48 294 380 minecraft:magenta_concrete
fill 48 293 382 48 294 382 minecraft:magenta_concrete
fill 48 293 384 48 294 384 minecraft:magenta_concrete
fill 49 293 371 49 294 371 minecraft:magenta_concrete
fill 49 293 373 49 294 373 minecraft:magenta_concrete
fill 49 293 379 49 294 379 minecraft:magenta_concrete
fill 49 293 381 49 294 381 minecraft:magenta_concrete
fill 49 293 383 49 294 383 minecraft:magenta_concrete
fill 50 293 370 50 294 370 minecraft:magenta_concrete
fill 50 293 372 50 294 372 minecraft:magenta_concrete
fill 50 293 378 50 294 378 minecraft:magenta_concrete
fill 50 293 380 50 294 380 minecraft:magenta_concrete
fill 50 293 382 50 294 382 minecraft:magenta_concrete
fill 50 293 384 50 294 384 minecraft:magenta_concrete
fill 51 293 371 51 294 371 minecraft:magenta_concrete
fill 51 293 373 51 294 373 minecraft:magenta_concrete
fill 51 293 379 51 294 379 minecraft:magenta_concrete
fill 51 293 381 51 294 381 minecraft:magenta_concrete
fill 51 293 383 51 294 383 minecraft:magenta_concrete
fill 52 293 370 52 294 370 minecraft:magenta_concrete
fill 52 293 372 52 294 372 minecraft:magenta_concrete
fill 53 293 371 53 294 371 minecraft:magenta_concrete
fill 53 293 373 53 294 373 minecraft:magenta_concrete
fill 54 293 370 54 294 370 minecraft:magenta_concrete
fill 54 293 372 54 294 372 minecraft:magenta_concrete
fill 55 293 371 55 294 371 minecraft:magenta_concrete
fill 55 293 373 55 294 373 minecraft:magenta_concrete
fill 56 293 370 56 294 370 minecraft:magenta_concrete
fill 56 293 372 56 294 372 minecraft:magenta_concrete
fill 57 293 371 57 294 371 minecraft:magenta_concrete
fill 57 293 373 57 294 373 minecraft:magenta_concrete
fill 68 293 370 68 294 370 minecraft:magenta_concrete
fill 68 293 372 68 294 372 minecraft:magenta_concrete
fill 69 293 371 69 294 371 minecraft:magenta_concrete
fill 69 293 373 69 294 373 minecraft:magenta_concrete
fill 70 293 370 70 294 370 minecraft:magenta_concrete
fill 70 293 372 70 294 372 minecraft:magenta_concrete
fill 71 293 371 71 294 371 minecraft:magenta_concrete
fill 71 293 373 71 294 373 minecraft:magenta_concrete
fill 72 293 370 72 294 370 minecraft:magenta_concrete
fill 72 293 372 72 294 372 minecraft:magenta_concrete
fill 73 293 371 73 294 371 minecraft:magenta_concrete
fill 73 293 373 73 294 373 minecraft:magenta_concrete
fill 74 293 370 74 294 370 minecraft:magenta_concrete
fill 74 293 372 74 294 372 minecraft:magenta_concrete
fill 75 293 371 75 294 371 minecraft:magenta_concrete
fill 75 293 373 75 294 373 minecraft:magenta_concrete
fill 76 293 370 76 294 370 minecraft:magenta_concrete
fill 76 293 372 76 294 372 minecraft:magenta_concrete
setblock 85 293 395 minecraft:pink_concrete
fill 48 294 374 49 294 375 minecraft:magenta_concrete
fill 48 294 386 49 294 391 minecraft:magenta_concrete
fill 48 294 394 49 294 399 minecraft:magenta_concrete
fill 48 294 402 49 294 407 minecraft:magenta_concrete
fill 48 294 410 53 295 410 minecraft:magenta_concrete
fill 49 294 376 49 294 377 minecraft:magenta_concrete
setblock 49 294 385 minecraft:magenta_concrete
fill 49 294 392 49 294 393 minecraft:magenta_concrete
fill 49 294 400 49 294 401 minecraft:magenta_concrete
fill 49 294 408 49 294 409 minecraft:magenta_concrete
fill 50 294 409 88 294 409 minecraft:magenta_concrete
fill 56 294 410 61 295 410 minecraft:magenta_concrete
fill 58 294 371 67 294 371 minecraft:magenta_concrete
fill 59 294 370 64 295 370 minecraft:magenta_concrete
fill 64 294 410 69 295 410 minecraft:magenta_concrete
fill 67 294 370 67 295 370 minecraft:magenta_concrete
fill 72 294 410 77 295 410 minecraft:magenta_concrete
fill 77 294 370 80 294 371 minecraft:magenta_concrete
fill 80 294 410 85 295 410 minecraft:magenta_concrete
fill 87 294 381 87 294 408 minecraft:magenta_concrete
fill 88 294 381 88 295 386 minecraft:magenta_concrete
fill 88 294 389 88 295 394 minecraft:magenta_concrete
fill 88 294 397 88 295 402 minecraft:magenta_concrete
fill 88 294 405 88 295 408 minecraft:magenta_concrete
fill 88 294 410 88 295 410 minecraft:magenta_concrete
setblock 47 295 371 minecraft:sea_lantern
setblock 47 295 373 minecraft:sea_lantern
setblock 48 295 370 minecraft:sea_lantern
setblock 48 295 372 minecraft:sea_lantern
fill 48 295 374 48 295 375 minecraft:magenta_concrete
setblock 48 295 378 minecraft:sea_lantern
setblock 48 295 380 minecraft:sea_lantern
setblock 48 295 382 minecraft:sea_lantern
setblock 48 295 384 minecraft:sea_lantern
fill 48 295 386 48 295 391 minecraft:magenta_concrete
fill 48 295 394 48 295 399 minecraft:magenta_concrete
fill 48 295 402 48 295 407 minecraft:magenta_concrete
setblock 49 295 371 minecraft:sea_lantern
setblock 49 295 373 minecraft:sea_lantern
setblock 49 295 379 minecraft:sea_lantern
setblock 49 295 381 minecraft:sea_lantern
setblock 49 295 383 minecraft:sea_lantern
setblock 50 295 370 minecraft:sea_lantern
setblock 50 295 372 minecraft:sea_lantern
setblock 50 295 378 minecraft:sea_lantern
setblock 50 295 380 minecraft:sea_lantern
setblock 50 295 382 minecraft:sea_lantern
setblock 50 295 384 minecraft:sea_lantern
setblock 51 295 371 minecraft:sea_lantern
setblock 51 295 373 minecraft:sea_lantern
setblock 51 295 379 minecraft:sea_lantern
setblock 51 295 381 minecraft:sea_lantern
setblock 51 295 383 minecraft:sea_lantern
setblock 52 295 370 minecraft:sea_lantern
setblock 52 295 372 minecraft:sea_lantern
setblock 53 295 371 minecraft:sea_lantern
setblock 53 295 373 minecraft:sea_lantern
setblock 54 295 370 minecraft:sea_lantern
setblock 54 295 372 minecraft:sea_lantern
setblock 55 295 371 minecraft:sea_lantern
setblock 55 295 373 minecraft:sea_lantern
setblock 56 295 370 minecraft:sea_lantern
setblock 56 295 372 minecraft:sea_lantern
setblock 57 295 371 minecraft:sea_lantern
setblock 57 295 373 minecraft:sea_lantern
setblock 68 295 370 minecraft:sea_lantern
setblock 68 295 372 minecraft:sea_lantern
setblock 69 295 371 minecraft:sea_lantern
setblock 69 295 373 minecraft:sea_lantern
setblock 70 295 370 minecraft:sea_lantern
setblock 70 295 372 minecraft:sea_lantern
setblock 71 295 371 minecraft:sea_lantern
setblock 71 295 373 minecraft:sea_lantern
setblock 72 295 370 minecraft:sea_lantern
setblock 72 295 372 minecraft:sea_lantern
setblock 73 295 371 minecraft:sea_lantern
setblock 73 295 373 minecraft:sea_lantern
setblock 74 295 370 minecraft:sea_lantern
setblock 74 295 372 minecraft:sea_lantern
setblock 75 295 371 minecraft:sea_lantern
setblock 75 295 373 minecraft:sea_lantern
setblock 76 295 370 minecraft:sea_lantern
setblock 76 295 372 minecraft:sea_lantern
fill 77 295 370 80 295 370 minecraft:magenta_concrete
setblock 88 295 409 minecraft:magenta_concrete
fill 47 296 371 47 297 371 minecraft:black_concrete
fill 47 296 373 47 297 373 minecraft:black_concrete
fill 48 296 370 48 297 370 minecraft:magenta_concrete
fill 48 296 372 48 297 372 minecraft:magenta_concrete
fill 48 296 378 48 297 378 minecraft:magenta_concrete
fill 48 296 380 48 297 380 minecraft:magenta_concrete
fill 48 296 382 48 297 382 minecraft:magenta_concrete
fill 48 296 384 48 297 384 minecraft:magenta_concrete
fill 49 296 371 49 297 371 minecraft:magenta_concrete
fill 49 296 373 49 297 373 minecraft:magenta_concrete
fill 49 296 379 49 297 379 minecraft:magenta_concrete
fill 49 296 381 49 297 381 minecraft:magenta_concrete
fill 49 296 383 49 297 383 minecraft:magenta_concrete
fill 50 296 370 50 297 370 minecraft:magenta_concrete
fill 50 296 372 50 297 372 minecraft:magenta_concrete
fill 50 296 378 50 297 378 minecraft:magenta_concrete
fill 50 296 380 50 297 380 minecraft:magenta_concrete
fill 50 296 382 50 297 382 minecraft:magenta_concrete
fill 50 296 384 50 297 384 minecraft:magenta_concrete
fill 51 296 371 51 297 371 minecraft:magenta_concrete
fill 51 296 373 51 297 373 minecraft:magenta_concrete
fill 51 296 379 51 297 379 minecraft:magenta_concrete
fill 51 296 381 51 297 381 minecraft:magenta_concrete
fill 51 296 383 51 297 383 minecraft:magenta_concrete
fill 52 296 370 52 297 370 minecraft:magenta_concrete
fill 52 296 372 52 297 372 minecraft:magenta_concrete
fill 53 296 371 53 297 371 minecraft:magenta_concrete
fill 53 296 373 53 297 373 minecraft:magenta_concrete
fill 54 296 370 54 297 370 minecraft:magenta_concrete
fill 54 296 372 54 297 372 minecraft:magenta_concrete
fill 55 296 371 55 297 371 minecraft:magenta_concrete
fill 55 296 373 55 297 373 minecraft:magenta_concrete
fill 56 296 370 56 297 370 minecraft:magenta_concrete
fill 56 296 372 56 297 372 minecraft:magenta_concrete
fill 57 296 371 57 297 371 minecraft:magenta_concrete
fill 57 296 373 57 297 373 minecraft:magenta_concrete
fill 68 296 370 68 297 370 minecraft:magenta_concrete
fill 68 296 372 68 297 372 minecraft:magenta_concrete
fill 69 296 371 69 297 371 minecraft:magenta_concrete
fill 69 296 373 69 297 373 minecraft:magenta_concrete
fill 70 296 370 70 297 370 minecraft:magenta_concrete
fill 70 296 372 70 297 372 minecraft:magenta_concrete
fill 71 296 371 71 297 371 minecraft:magenta_concrete
fill 71 296 373 71 297 373 minecraft:magenta_concrete
fill 72 296 370 72 297 370 minecraft:magenta_concrete
fill 72 296 372 72 297 372 minecraft:magenta_concrete
fill 73 296 371 73 297 371 minecraft:magenta_concrete
fill 73 296 373 73 297 373 minecraft:magenta_concrete
fill 74 296 370 74 297 370 minecraft:magenta_concrete
fill 74 296 372 74 297 372 minecraft:magenta_concrete
fill 75 296 371 75 297 371 minecraft:magenta_concrete
fill 75 296 373 75 297 373 minecraft:magenta_concrete
fill 76 296 370 76 297 370 minecraft:magenta_concrete
fill 76 296 372 76 297 372 minecraft:magenta_concrete
setblock 50 297 388 minecraft:light[level=14]
setblock 50 297 396 minecraft:light[level=14]
setblock 50 297 404 minecraft:light[level=14]
setblock 58 297 372 minecraft:light[level=14]
setblock 58 297 380 minecraft:light[level=14]
setblock 58 297 388 minecraft:light[level=14]
setblock 58 297 396 minecraft:light[level=14]
setblock 58 297 404 minecraft:light[level=14]
setblock 66 297 372 minecraft:light[level=14]
setblock 66 297 380 minecraft:light[level=14]
setblock 66 297 388 minecraft:light[level=14]
setblock 66 297 396 minecraft:light[level=14]
setblock 66 297 404 minecraft:light[level=14]
setblock 74 297 380 minecraft:light[level=14]
setblock 74 297 388 minecraft:light[level=14]
setblock 74 297 396 minecraft:light[level=14]
setblock 74 297 404 minecraft:light[level=14]
setblock 82 297 388 minecraft:light[level=14]
setblock 82 297 396 minecraft:light[level=14]
setblock 82 297 404 minecraft:light[level=14]
setblock 47 298 371 minecraft:sea_lantern
fill 47 298 373 47 298 374 minecraft:sea_lantern
fill 47 298 382 48 298 382 minecraft:sea_lantern
fill 47 298 390 47 300 390 minecraft:sea_lantern
fill 47 298 398 47 300 398 minecraft:sea_lantern
fill 47 298 406 47 300 406 minecraft:sea_lantern
setblock 48 298 370 minecraft:sea_lantern
setblock 48 298 372 minecraft:sea_lantern
setblock 48 298 378 minecraft:sea_lantern
setblock 48 298 380 minecraft:sea_lantern
setblock 48 298 384 minecraft:sea_lantern
setblock 49 298 371 minecraft:sea_lantern
setblock 49 298 373 minecraft:sea_lantern
setblock 49 298 379 minecraft:sea_lantern
setblock 49 298 381 minecraft:sea_lantern
setblock 49 298 383 minecraft:sea_lantern
setblock 50 298 370 minecraft:sea_lantern
setblock 50 298 372 minecraft:sea_lantern
setblock 50 298 378 minecraft:sea_lantern
setblock 50 298 380 minecraft:sea_lantern
setblock 50 298 382 minecraft:sea_lantern
setblock 50 298 384 minecraft:sea_lantern
fill 50 298 386 51 299 394 minecraft:magenta_concrete
fill 50 298 411 50 300 411 minecraft:sea_lantern
setblock 51 298 371 minecraft:sea_lantern
setblock 51 298 373 minecraft:sea_lantern
setblock 51 298 379 minecraft:sea_lantern
setblock 51 298 381 minecraft:sea_lantern
setblock 51 298 383 minecraft:sea_lantern
fill 51 298 385 52 299 385 minecraft:magenta_concrete
fill 51 298 395 52 299 397 minecraft:magenta_concrete
setblock 52 298 370 minecraft:sea_lantern
setblock 52 298 372 minecraft:sea_lantern
fill 52 298 381 52 299 384 minecraft:magenta_concrete
fill 52 298 398 53 299 399 minecraft:magenta_concrete
setblock 53 298 371 minecraft:sea_lantern
setblock 53 298 373 minecraft:sea_lantern
fill 53 298 380 53 299 383 minecraft:magenta_concrete
fill 53 298 397 53 299 397 minecraft:magenta_concrete
fill 53 298 400 54 299 400 minecraft:magenta_concrete
fill 54 298 369 54 298 370 minecraft:sea_lantern
setblock 54 298 372 minecraft:sea_lantern
fill 54 298 378 54 299 381 minecraft:magenta_concrete
fill 54 298 399 54 299 399 minecraft:magenta_concrete
fill 54 298 401 55 299 402 minecraft:magenta_concrete
setblock 55 298 371 minecraft:sea_lantern
setblock 55 298 373 minecraft:sea_lantern
fill 55 298 377 55 299 379 minecraft:magenta_concrete
fill 55 298 403 57 299 403 minecraft:magenta_concrete
setblock 56 298 370 minecraft:sea_lantern
setblock 56 298 372 minecraft:sea_lantern
fill 56 298 376 56 299 378 minecraft:magenta_concrete
fill 56 298 402 56 299 402 minecraft:magenta_concrete
fill 56 298 404 59 299 404 minecraft:magenta_concrete
setblock 57 298 371 minecraft:sea_lantern
setblock 57 298 373 minecraft:sea_lantern
fill 57 298 376 57 299 377 minecraft:magenta_concrete
fill 58 298 375 59 299 376 minecraft:magenta_concrete
fill 58 298 405 61 299 405 minecraft:magenta_concrete
fill 58 298 411 58 300 411 minecraft:sea_lantern
fill 59 298 374 63 299 374 minecraft:magenta_concrete
fill 59 298 406 63 299 406 minecraft:magenta_concrete
fill 60 298 375 61 299 375 minecraft:magenta_concrete
fill 61 298 373 67 299 373 minecraft:magenta_concrete
fill 61 298 407 75 299 407 minecraft:magenta_concrete
fill 62 298 369 62 300 369 minecraft:sea_lantern
fill 64 298 372 67 299 372 minecraft:magenta_concrete
fill 64 298 408 72 299 408 minecraft:magenta_concrete
fill 66 298 411 66 300 411 minecraft:sea_lantern
setblock 68 298 370 minecraft:sea_lantern
setblock 68 298 372 minecraft:sea_lantern
setblock 69 298 371 minecraft:sea_lantern
setblock 69 298 373 minecraft:sea_lantern
fill 70 298 369 70 298 370 minecraft:sea_lantern
setblock 70 298 372 minecraft:sea_lantern
setblock 71 298 371 minecraft:sea_lantern
setblock 71 298 373 minecraft:sea_lantern
setblock 72 298 370 minecraft:sea_lantern
setblock 72 298 372 minecraft:sea_lantern
setblock 73 298 371 minecraft:sea_lantern
setblock 73 298 373 minecraft:sea_lantern
fill 73 298 374 77 299 374 minecraft:magenta_concrete
fill 73 298 406 77 299 406 minecraft:magenta_concrete
setblock 74 298 370 minecraft:sea_lantern
setblock 74 298 372 minecraft:sea_lantern
fill 74 298 411 74 300 411 minecraft:sea_lantern
setblock 75 298 371 minecraft:sea_lantern
setblock 75 298 373 minecraft:sea_lantern
fill 75 298 375 78 299 375 minecraft:magenta_concrete
fill 75 298 405 78 299 405 minecraft:magenta_concrete
setblock 76 298 370 minecraft:sea_lantern
setblock 76 298 372 minecraft:sea_lantern
fill 77 298 376 80 299 376 minecraft:magenta_concrete
fill 77 298 404 80 299 404 minecraft:magenta_concrete
fill 78 298 369 78 300 369 minecraft:sea_lantern
fill 79 298 377 80 299 377 minecraft:magenta_concrete
fill 79 298 403 81 299 403 minecraft:magenta_concrete
fill 80 298 378 80 299 378 minecraft:magenta_concrete
fill 80 298 402 82 299 402 minecraft:magenta_concrete
fill 81 298 401 82 299 401 minecraft:magenta_concrete
fill 82 298 381 84 299 381 minecraft:magenta_concrete
fill 82 298 399 83 299 400 minecraft:magenta_concrete
fill 82 298 411 82 300 411 minecraft:sea_lantern
fill 83 298 382 84 299 383 minecraft:magenta_concrete
fill 83 298 397 84 299 398 minecraft:magenta_concrete
fill 84 298 384 85 299 385 minecraft:magenta_concrete
fill 84 298 395 85 299 396 minecraft:magenta_concrete
fill 84 298 399 84 299 399 minecraft:magenta_concrete
fill 85 298 383 85 299 383 minecraft:magenta_concrete
fill 85 298 386 86 299 394 minecraft:magenta_concrete
fill 85 298 397 85 299 397 minecraft:magenta_concrete
fill 86 298 369 86 300 369 minecraft:sea_lantern
fill 89 298 374 89 300 374 minecraft:sea_lantern
fill 89 298 382 89 300 382 minecraft:sea_lantern
fill 89 298 390 89 300 390 minecraft:sea_lantern
fill 89 298 398 89 300 398 minecraft:sea_lantern
fill 89 298 406 89 300 406 minecraft:sea_lantern
fill 47 299 371 47 307 371 minecraft:black_concrete
fill 47 299 373 47 307 373 minecraft:black_concrete
fill 47 299 374 47 300 374 minecraft:sea_lantern
fill 47 299 382 47 300 382 minecraft:sea_lantern
fill 48 299 370 48 300 370 minecraft:magenta_concrete
fill 48 299 372 48 300 372 minecraft:magenta_concrete
fill 48 299 378 48 300 378 minecraft:magenta_concrete
fill 48 299 380 48 300 380 minecraft:magenta_concrete
fill 48 299 382 48 300 382 minecraft:magenta_concrete
fill 48 299 384 48 300 384 minecraft:magenta_concrete
fill 49 299 371 49 300 371 minecraft:magenta_concrete
fill 49 299 373 49 300 373 minecraft:magenta_concrete
fill 49 299 379 49 300 379 minecraft:magenta_concrete
fill 49 299 381 49 300 381 minecraft:magenta_concrete
fill 49 299 383 49 300 383 minecraft:magenta_concrete
fill 50 299 370 50 300 370 minecraft:magenta_concrete
fill 50 299 372 50 300 372 minecraft:magenta_concrete
fill 50 299 378 50 300 378 minecraft:magenta_concrete
fill 50 299 380 50 300 380 minecraft:magenta_concrete
fill 50 299 382 50 300 382 minecraft:magenta_concrete
fill 50 299 384 50 300 384 minecraft:magenta_concrete
fill 51 299 371 51 300 371 minecraft:magenta_concrete
fill 51 299 373 51 300 373 minecraft:magenta_concrete
fill 51 299 379 51 300 379 minecraft:magenta_concrete
fill 51 299 381 51 300 381 minecraft:magenta_concrete
fill 51 299 383 51 300 383 minecraft:magenta_concrete
fill 52 299 370 52 300 370 minecraft:magenta_concrete
fill 52 299 372 52 300 372 minecraft:magenta_concrete
fill 53 299 371 53 300 371 minecraft:magenta_concrete
fill 53 299 373 53 300 373 minecraft:magenta_concrete
fill 54 299 369 54 300 369 minecraft:sea_lantern
fill 54 299 370 54 300 370 minecraft:magenta_concrete
fill 54 299 372 54 300 372 minecraft:magenta_concrete
fill 55 299 371 55 300 371 minecraft:magenta_concrete
fill 55 299 373 55 300 373 minecraft:magenta_concrete
fill 56 299 370 56 300 370 minecraft:magenta_concrete
fill 56 299 372 56 300 372 minecraft:magenta_concrete
fill 57 299 371 57 300 371 minecraft:magenta_concrete
fill 57 299 373 57 300 373 minecraft:magenta_concrete
fill 68 299 370 68 300 370 minecraft:magenta_concrete
fill 68 299 372 68 300 372 minecraft:magenta_concrete
fill 69 299 371 69 300 371 minecraft:magenta_concrete
fill 69 299 373 69 300 373 minecraft:magenta_concrete
fill 70 299 369 70 300 369 minecraft:sea_lantern
fill 70 299 370 70 300 370 minecraft:magenta_concrete
fill 70 299 372 70 300 372 minecraft:magenta_concrete
fill 71 299 371 71 300 371 minecraft:magenta_concrete
fill 71 299 373 71 300 373 minecraft:magenta_concrete
fill 72 299 370 72 300 370 minecraft:magenta_concrete
fill 72 299 372 72 300 372 minecraft:magenta_concrete
fill 73 299 371 73 300 371 minecraft:magenta_concrete
fill 73 299 373 73 300 373 minecraft:magenta_concrete
fill 74 299 370 74 300 370 minecraft:magenta_concrete
fill 74 299 372 74 300 372 minecraft:magenta_concrete
fill 75 299 371 75 300 371 minecraft:magenta_concrete
fill 75 299 373 75 300 373 minecraft:magenta_concrete
fill 76 299 370 76 300 370 minecraft:magenta_concrete
fill 76 299 372 76 300 372 minecraft:magenta_concrete
fill 56 300 376 56 300 377 minecraft:sea_lantern
fill 47 301 374 47 307 374 minecraft:black_concrete
fill 47 301 382 47 307 382 minecraft:black_concrete
fill 47 301 390 47 307 390 minecraft:black_concrete
fill 47 301 398 47 307 398 minecraft:black_concrete
fill 47 301 406 47 307 406 minecraft:black_concrete
fill 50 301 411 50 307 411 minecraft:black_concrete
fill 54 301 369 54 307 369 minecraft:black_concrete
fill 58 301 411 58 307 411 minecraft:black_concrete
fill 62 301 369 62 307 369 minecraft:black_concrete
fill 66 301 411 66 307 411 minecraft:black_concrete
fill 70 301 369 70 307 369 minecraft:black_concrete
fill 74 301 411 74 307 411 minecraft:black_concrete
fill 78 301 369 78 307 369 minecraft:black_concrete
fill 82 301 411 82 307 411 minecraft:black_concrete
fill 86 301 369 86 307 369 minecraft:black_concrete
fill 89 301 374 89 307 374 minecraft:black_concrete
fill 89 301 382 89 307 382 minecraft:black_concrete
fill 89 301 390 89 307 390 minecraft:black_concrete
fill 89 301 398 89 307 398 minecraft:black_concrete
fill 89 301 406 89 307 406 minecraft:black_concrete
