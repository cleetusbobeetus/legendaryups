fill 406 205 519 406 207 521 minecraft:smooth_quartz
fill 407 205 522 407 207 522 minecraft:smooth_quartz
fill 408 205 517 408 207 517 minecraft:smooth_quartz
fill 409 205 523 409 207 523 minecraft:smooth_quartz
fill 410 205 517 410 207 517 minecraft:smooth_quartz
fill 411 205 522 411 207 522 minecraft:smooth_quartz
fill 412 205 519 412 207 521 minecraft:smooth_quartz
fill 417 205 552 417 208 552 minecraft:light_blue_concrete
fill 418 205 515 418 208 515 minecraft:light_blue_concrete
setblock 418 205 516 minecraft:white_concrete
fill 418 205 517 418 208 517 minecraft:light_blue_concrete
fill 418 205 520 418 208 520 minecraft:light_blue_concrete
setblock 418 205 521 minecraft:white_concrete
fill 418 205 522 418 206 523 minecraft:light_blue_concrete
fill 418 205 524 418 206 524 minecraft:white_concrete
fill 418 205 525 418 205 527 minecraft:light_blue_concrete
fill 418 205 536 418 206 536 minecraft:white_concrete
fill 418 205 537 418 208 541 minecraft:light_blue_concrete
setblock 418 205 542 minecraft:white_concrete
setblock 418 205 547 minecraft:white_concrete
fill 418 205 549 418 208 550 minecraft:light_blue_concrete
fill 418 205 551 418 205 552 minecraft:white_concrete
setblock 376 206 510 minecraft:light_blue_concrete
fill 376 206 518 376 208 518 minecraft:light_blue_concrete
setblock 376 206 522 minecraft:white_concrete
fill 376 206 523 376 208 524 minecraft:light_blue_concrete
setblock 376 206 525 minecraft:white_concrete
fill 376 206 526 376 208 527 minecraft:light_blue_concrete
setblock 376 206 528 minecraft:white_concrete
setblock 376 206 529 minecraft:light_blue_concrete
setblock 376 206 530 minecraft:white_concrete
fill 376 206 531 376 208 531 minecraft:light_blue_concrete
fill 376 206 535 376 208 535 minecraft:light_blue_concrete
setblock 376 206 538 minecraft:white_concrete
fill 376 206 539 376 208 546 minecraft:light_blue_concrete
setblock 376 206 549 minecraft:white_concrete
fill 376 206 552 376 208 552 minecraft:light_blue_concrete
fill 377 206 510 377 207 510 minecraft:white_concrete
fill 382 206 510 383 206 510 minecraft:light_blue_concrete
setblock 384 206 510 minecraft:white_concrete
fill 385 206 510 388 206 510 minecraft:light_blue_concrete
setblock 389 206 510 minecraft:white_concrete
fill 390 206 510 390 208 510 minecraft:light_blue_concrete
setblock 390 206 552 minecraft:white_concrete
setblock 391 206 510 minecraft:white_concrete
fill 391 206 552 391 208 552 minecraft:light_blue_concrete
fill 395 206 510 395 208 510 minecraft:light_blue_concrete
setblock 396 206 510 minecraft:white_concrete
fill 397 206 510 399 206 510 minecraft:light_blue_concrete
fill 401 206 510 401 208 510 minecraft:light_blue_concrete
fill 406 206 510 407 206 510 minecraft:white_concrete
fill 406 206 518 406 207 518 minecraft:smooth_quartz
fill 406 206 522 406 207 522 minecraft:smooth_quartz
fill 407 206 517 407 207 517 minecraft:smooth_quartz
fill 407 206 523 408 207 523 minecraft:smooth_quartz
setblock 408 206 510 minecraft:light_blue_concrete
fill 408 206 552 409 206 552 minecraft:light_blue_concrete
setblock 409 206 510 minecraft:white_concrete
fill 410 206 523 411 207 523 minecraft:smooth_quartz
setblock 410 206 552 minecraft:white_concrete
fill 411 206 517 411 207 517 minecraft:smooth_quartz
fill 411 206 552 416 208 552 minecraft:light_blue_concrete
fill 412 206 518 412 207 518 minecraft:smooth_quartz
fill 412 206 522 412 207 522 minecraft:smooth_quartz
fill 418 206 516 418 208 516 minecraft:light_blue_concrete
fill 418 206 521 418 208 521 minecraft:light_blue_concrete
fill 418 206 525 418 208 526 minecraft:light_blue_concrete
fill 418 206 527 418 206 528 minecraft:white_concrete
fill 418 206 529 418 208 531 minecraft:light_blue_concrete
setblock 418 206 532 minecraft:white_concrete
fill 418 206 542 418 208 542 minecraft:light_blue_concrete
fill 418 206 547 418 208 547 minecraft:light_blue_concrete
fill 418 206 551 418 208 552 minecraft:light_blue_concrete
setblock 376 207 510 minecraft:white_concrete
fill 376 207 512 376 208 514 minecraft:light_blue_concrete
setblock 376 207 515 minecraft:white_concrete
fill 376 207 522 376 208 522 minecraft:light_blue_concrete
fill 376 207 525 376 208 525 minecraft:light_blue_concrete
fill 376 207 528 376 208 528 minecraft:light_blue_concrete
setblock 376 207 529 minecraft:white_concrete
fill 376 207 530 376 208 530 minecraft:light_blue_concrete
setblock 376 207 537 minecraft:white_concrete
fill 376 207 538 376 208 538 minecraft:light_blue_concrete
fill 376 207 547 376 209 547 minecraft:light_blue_concrete
fill 376 207 549 376 208 549 minecraft:light_blue_concrete
setblock 378 207 510 minecraft:white_concrete
setblock 382 207 510 minecraft:white_concrete
fill 383 207 510 384 208 510 minecraft:light_blue_concrete
setblock 385 207 510 minecraft:white_concrete
fill 386 207 510 389 208 510 minecraft:light_blue_concrete
fill 390 207 552 390 208 552 minecraft:light_blue_concrete
fill 391 207 510 391 208 510 minecraft:light_blue_concrete
fill 396 207 510 398 208 510 minecraft:light_blue_concrete
setblock 397 207 552 minecraft:white_concrete
fill 398 207 552 399 208 552 minecraft:light_blue_concrete
setblock 399 207 510 minecraft:white_concrete
fill 405 207 519 405 207 521 minecraft:smooth_quartz
fill 406 207 510 406 208 510 minecraft:light_blue_concrete
setblock 406 207 517 minecraft:smooth_quartz
fill 406 207 552 406 208 552 minecraft:light_blue_concrete
fill 407 207 510 408 207 510 minecraft:white_concrete
setblock 407 207 552 minecraft:white_concrete
fill 408 207 516 410 207 516 minecraft:smooth_quartz
fill 408 207 552 408 208 552 minecraft:light_blue_concrete
fill 409 207 510 409 208 510 minecraft:light_blue_concrete
setblock 409 207 524 minecraft:smooth_quartz
setblock 409 207 552 minecraft:white_concrete
fill 410 207 552 410 208 552 minecraft:light_blue_concrete
setblock 412 207 517 minecraft:smooth_quartz
fill 413 207 519 413 207 521 minecraft:smooth_quartz
setblock 418 207 522 minecraft:white_concrete
fill 418 207 523 418 208 524 minecraft:light_blue_concrete
fill 418 207 527 418 208 528 minecraft:light_blue_concrete
fill 418 207 532 418 208 532 minecraft:light_blue_concrete
fill 418 207 536 418 208 536 minecraft:light_blue_concrete
setblock 418 207 548 minecraft:white_concrete
fill 376 208 510 378 208 510 minecraft:light_blue_concrete
setblock 376 208 515 minecraft:light_blue_concrete
setblock 376 208 529 minecraft:light_blue_concrete
setblock 376 208 537 minecraft:light_blue_concrete
setblock 382 208 510 minecraft:light_blue_concrete
setblock 385 208 510 minecraft:light_blue_concrete
fill 397 208 552 397 209 552 minecraft:light_blue_concrete
setblock 399 208 510 minecraft:light_blue_concrete
fill 407 208 510 408 208 510 minecraft:light_blue_concrete
setblock 407 208 552 minecraft:light_blue_concrete
fill 409 208 520 409 211 520 minecraft:quartz_pillar
setblock 409 208 552 minecraft:light_blue_concrete
setblock 418 208 522 minecraft:light_blue_concrete
setblock 418 208 548 minecraft:light_blue_concrete
setblock 376 209 510 minecraft:light_blue_concrete
fill 376 209 511 376 209 543 minecraft:white_concrete
setblock 376 209 544 minecraft:light_blue_concrete
fill 376 209 545 376 210 546 minecraft:white_concrete
fill 376 209 548 376 209 552 minecraft:white_concrete
fill 377 209 510 386 209 510 minecraft:white_concrete
fill 377 209 552 396 209 552 minecraft:white_concrete
fill 387 209 510 387 210 510 minecraft:light_blue_concrete
fill 388 209 510 418 209 510 minecraft:white_concrete
fill 398 209 552 418 209 552 minecraft:white_concrete
fill 418 209 511 418 308 511 minecraft:white_concrete
setblock 418 209 512 minecraft:light_blue_concrete
fill 418 209 513 418 308 513 minecraft:white_concrete
setblock 418 209 514 minecraft:light_blue_concrete
fill 418 209 515 418 209 525 minecraft:white_concrete
fill 418 209 526 418 209 527 minecraft:light_blue_concrete
fill 418 209 528 418 209 532 minecraft:white_concrete
fill 418 209 534 418 308 536 minecraft:white_concrete
setblock 418 209 537 minecraft:light_blue_concrete
fill 418 209 538 418 209 551 minecraft:white_concrete
fill 376 210 510 379 308 510 minecraft:white_concrete
fill 376 210 511 376 211 511 minecraft:light_blue_concrete
fill 376 210 512 376 210 524 minecraft:white_concrete
setblock 376 210 525 minecraft:light_blue_concrete
fill 376 210 526 376 210 534 minecraft:white_concrete
setblock 376 210 535 minecraft:light_blue_concrete
fill 376 210 536 376 210 544 minecraft:white_concrete
fill 376 210 547 376 308 548 minecraft:white_concrete
setblock 376 210 549 minecraft:light_blue_concrete
fill 376 210 550 376 308 550 minecraft:white_concrete
setblock 376 210 551 minecraft:light_blue_concrete
fill 376 210 552 377 308 552 minecraft:white_concrete
setblock 378 210 552 minecraft:light_blue_concrete
setblock 379 210 513 minecraft:light[level=14]
setblock 379 210 521 minecraft:light[level=14]
setblock 379 210 529 minecraft:light[level=14]
setblock 379 210 537 minecraft:light[level=14]
setblock 379 210 545 minecraft:light[level=14]
fill 379 210 552 388 210 552 minecraft:white_concrete
setblock 380 210 510 minecraft:light_blue_concrete
fill 381 210 510 386 210 510 minecraft:white_concrete
setblock 387 210 513 minecraft:light[level=14]
setblock 387 210 521 minecraft:light[level=14]
setblock 387 210 529 minecraft:light[level=14]
setblock 387 210 537 minecraft:light[level=14]
setblock 387 210 545 minecraft:light[level=14]
fill 388 210 510 412 210 510 minecraft:white_concrete
fill 389 210 552 389 211 552 minecraft:light_blue_concrete
fill 390 210 552 393 308 552 minecraft:white_concrete
setblock 394 210 552 minecraft:light_blue_concrete
setblock 395 210 513 minecraft:light[level=14]
setblock 395 210 521 minecraft:light[level=14]
setblock 395 210 529 minecraft:light[level=14]
setblock 395 210 537 minecraft:light[level=14]
setblock 395 210 545 minecraft:light[level=14]
setblock 395 210 552 minecraft:white_concrete
setblock 396 210 552 minecraft:light_blue_concrete
fill 397 210 552 398 308 552 minecraft:white_concrete
setblock 399 210 552 minecraft:light_blue_concrete
fill 400 210 552 409 308 552 minecraft:white_concrete
setblock 403 210 513 minecraft:light[level=14]
setblock 403 210 521 minecraft:light[level=14]
setblock 403 210 529 minecraft:light[level=14]
setblock 403 210 537 minecraft:light[level=14]
setblock 403 210 545 minecraft:light[level=14]
setblock 410 210 552 minecraft:light_blue_concrete
setblock 411 210 513 minecraft:light[level=14]
setblock 411 210 521 minecraft:light[level=14]
setblock 411 210 529 minecraft:light[level=14]
setblock 411 210 537 minecraft:light[level=14]
setblock 411 210 545 minecraft:light[level=14]
fill 411 210 552 414 308 552 minecraft:white_concrete
setblock 413 210 510 minecraft:light_blue_concrete
fill 414 210 510 418 308 510 minecraft:white_concrete
fill 415 210 552 416 210 552 minecraft:light_blue_concrete
fill 417 210 552 418 308 552 minecraft:white_concrete
fill 418 210 512 418 308 512 minecraft:white_concrete
fill 418 210 514 418 210 523 minecraft:white_concrete
setblock 418 210 524 minecraft:light_blue_concrete
fill 418 210 525 418 210 528 minecraft:white_concrete
setblock 418 210 529 minecraft:light_blue_concrete
fill 418 210 530 418 210 533 minecraft:white_concrete
fill 418 210 537 418 308 537 minecraft:white_concrete
setblock 418 210 538 minecraft:light_blue_concrete
fill 418 210 539 418 308 540 minecraft:white_concrete
setblock 418 210 541 minecraft:light_blue_concrete
fill 418 210 542 418 308 542 minecraft:white_concrete
setblock 418 210 543 minecraft:light_blue_concrete
fill 418 210 544 418 210 545 minecraft:white_concrete
setblock 418 210 546 minecraft:light_blue_concrete
fill 418 210 547 418 308 551 minecraft:white_concrete
fill 376 211 512 376 308 513 minecraft:white_concrete
setblock 376 211 514 minecraft:light_blue_concrete
fill 376 211 515 376 308 527 minecraft:white_concrete
setblock 376 211 528 minecraft:light_blue_concrete
fill 376 211 529 376 308 532 minecraft:white_concrete
fill 376 211 533 376 211 534 minecraft:light_blue_concrete
fill 376 211 535 376 308 543 minecraft:white_concrete
setblock 376 211 544 minecraft:light_blue_concrete
fill 376 211 545 376 308 545 minecraft:white_concrete
setblock 376 211 546 minecraft:light_blue_concrete
fill 376 211 549 376 308 549 minecraft:white_concrete
fill 376 211 551 376 308 551 minecraft:white_concrete
fill 378 211 552 381 308 552 minecraft:white_concrete
fill 380 211 510 380 308 510 minecraft:white_concrete
setblock 381 211 510 minecraft:light_blue_concrete
fill 382 211 510 385 308 510 minecraft:white_concrete
setblock 382 211 552 minecraft:light_blue_concrete
fill 383 211 552 384 308 552 minecraft:white_concrete
fill 385 211 552 386 211 552 minecraft:light_blue_concrete
setblock 386 211 510 minecraft:light_blue_concrete
fill 387 211 510 394 308 510 minecraft:white_concrete
fill 387 211 552 388 308 552 minecraft:white_concrete
fill 394 211 552 394 308 552 minecraft:white_concrete
fill 395 211 510 396 211 510 minecraft:light_blue_concrete
setblock 395 211 552 minecraft:light_blue_concrete
fill 396 211 552 396 308 552 minecraft:white_concrete
fill 397 211 510 404 308 510 minecraft:white_concrete
fill 399 211 552 399 308 552 minecraft:white_concrete
setblock 405 211 510 minecraft:light_blue_concrete
fill 406 211 510 413 308 510 minecraft:white_concrete
fill 408 211 519 408 213 521 minecraft:flowering_azalea_leaves[persistent=true]
fill 409 211 518 409 213 519 minecraft:flowering_azalea_leaves[persistent=true]
fill 409 211 521 410 213 521 minecraft:flowering_azalea_leaves[persistent=true]
fill 410 211 519 410 213 520 minecraft:flowering_azalea_leaves[persistent=true]
fill 410 211 552 410 308 552 minecraft:white_concrete
fill 414 211 529 414 212 529 minecraft:white_wool
setblock 415 211 552 minecraft:light_blue_concrete
fill 416 211 552 416 308 552 minecraft:white_concrete
fill 418 211 514 418 308 520 minecraft:white_concrete
setblock 418 211 521 minecraft:light_blue_concrete
fill 418 211 522 418 308 522 minecraft:white_concrete
setblock 418 211 523 minecraft:light_blue_concrete
fill 418 211 524 418 308 525 minecraft:white_concrete
fill 418 211 526 418 211 527 minecraft:light_blue_concrete
fill 418 211 528 418 308 529 minecraft:white_concrete
setblock 418 211 530 minecraft:light_blue_concrete
fill 418 211 531 418 308 532 minecraft:white_concrete
setblock 418 211 533 minecraft:light_blue_concrete
fill 418 211 538 418 308 538 minecraft:white_concrete
fill 418 211 541 418 308 541 minecraft:white_concrete
fill 418 211 543 418 308 544 minecraft:white_concrete
setblock 418 211 545 minecraft:light_blue_concrete
fill 418 211 546 418 308 546 minecraft:white_concrete
fill 376 212 511 376 308 511 minecraft:white_concrete
fill 376 212 514 376 308 514 minecraft:white_concrete
fill 376 212 528 376 308 528 minecraft:white_concrete
fill 376 212 533 376 308 534 minecraft:white_concrete
fill 376 212 544 376 308 544 minecraft:white_concrete
fill 376 212 546 376 308 546 minecraft:white_concrete
fill 381 212 510 381 308 510 minecraft:white_concrete
fill 382 212 552 382 308 552 minecraft:white_concrete
fill 385 212 552 386 308 552 minecraft:white_concrete
fill 386 212 510 386 308 510 minecraft:white_concrete
fill 389 212 552 389 308 552 minecraft:white_concrete
fill 395 212 510 396 308 510 minecraft:white_concrete
fill 395 212 552 395 308 552 minecraft:white_concrete
fill 405 212 510 405 308 510 minecraft:white_concrete
fill 407 212 519 407 212 521 minecraft:flowering_azalea_leaves[persistent=true]
setblock 408 212 518 minecraft:flowering_azalea_leaves[persistent=true]
fill 408 212 522 410 212 522 minecraft:flowering_azalea_leaves[persistent=true]
fill 409 212 520 409 213 520 minecraft:flowering_azalea_leaves[persistent=true]
setblock 410 212 518 minecraft:flowering_azalea_leaves[persistent=true]
fill 411 212 519 411 212 521 minecraft:flowering_azalea_leaves[persistent=true]
fill 415 212 552 415 308 552 minecraft:white_concrete
fill 418 212 521 418 308 521 minecraft:white_concrete
fill 418 212 523 418 308 523 minecraft:white_concrete
fill 418 212 526 418 308 527 minecraft:white_concrete
fill 418 212 530 418 308 530 minecraft:white_concrete
fill 418 212 533 418 308 533 minecraft:white_concrete
fill 418 212 545 418 308 545 minecraft:white_concrete
fill 414 214 532 414 215 532 minecraft:white_wool
fill 406 217 519 406 218 520 minecraft:white_wool
fill 410 217 535 414 218 539 minecraft:smooth_quartz
fill 415 217 537 416 217 537 minecraft:smooth_quartz
setblock 379 218 513 minecraft:light[level=14]
setblock 379 218 521 minecraft:light[level=14]
setblock 379 218 529 minecraft:light[level=14]
setblock 379 218 537 minecraft:light[level=14]
setblock 379 218 545 minecraft:light[level=14]
setblock 387 218 513 minecraft:light[level=14]
setblock 387 218 521 minecraft:light[level=14]
setblock 387 218 529 minecraft:light[level=14]
setblock 387 218 537 minecraft:light[level=14]
setblock 387 218 545 minecraft:light[level=14]
setblock 395 218 513 minecraft:light[level=14]
setblock 395 218 521 minecraft:light[level=14]
setblock 395 218 529 minecraft:light[level=14]
setblock 395 218 537 minecraft:light[level=14]
setblock 395 218 545 minecraft:light[level=14]
setblock 403 218 513 minecraft:light[level=14]
setblock 403 218 521 minecraft:light[level=14]
setblock 403 218 529 minecraft:light[level=14]
setblock 403 218 537 minecraft:light[level=14]
setblock 403 218 545 minecraft:light[level=14]
setblock 411 218 513 minecraft:light[level=14]
setblock 411 218 521 minecraft:light[level=14]
setblock 411 218 529 minecraft:light[level=14]
setblock 411 218 545 minecraft:light[level=14]
fill 412 219 537 412 222 537 minecraft:quartz_pillar
fill 382 220 521 382 221 521 minecraft:white_wool
fill 405 220 540 406 221 540 minecraft:white_wool
fill 410 223 537 414 226 537 minecraft:gold_block
fill 411 223 536 413 226 536 minecraft:gold_block
fill 411 223 538 413 226 538 minecraft:gold_block
fill 412 223 535 412 226 535 minecraft:gold_block
fill 412 223 539 412 226 539 minecraft:gold_block
fill 389 224 542 389 225 542 minecraft:white_wool
fill 410 224 536 410 225 536 minecraft:gold_block
fill 410 224 538 410 225 538 minecraft:gold_block
fill 411 224 535 411 225 535 minecraft:gold_block
fill 411 224 539 411 225 539 minecraft:gold_block
fill 413 224 535 413 225 535 minecraft:gold_block
fill 413 224 539 413 225 539 minecraft:gold_block
fill 414 224 536 414 225 536 minecraft:gold_block
fill 414 224 538 414 225 538 minecraft:gold_block
setblock 379 226 513 minecraft:light[level=14]
setblock 379 226 521 minecraft:light[level=14]
setblock 379 226 529 minecraft:light[level=14]
setblock 379 226 537 minecraft:light[level=14]
setblock 379 226 545 minecraft:light[level=14]
setblock 387 226 513 minecraft:light[level=14]
setblock 387 226 521 minecraft:light[level=14]
setblock 387 226 529 minecraft:light[level=14]
setblock 387 226 537 minecraft:light[level=14]
setblock 387 226 545 minecraft:light[level=14]
setblock 395 226 513 minecraft:light[level=14]
setblock 395 226 521 minecraft:light[level=14]
setblock 395 226 529 minecraft:light[level=14]
setblock 395 226 537 minecraft:light[level=14]
setblock 395 226 545 minecraft:light[level=14]
setblock 403 226 513 minecraft:light[level=14]
setblock 403 226 521 minecraft:light[level=14]
setblock 403 226 529 minecraft:light[level=14]
setblock 403 226 537 minecraft:light[level=14]
setblock 403 226 545 minecraft:light[level=14]
setblock 411 226 513 minecraft:light[level=14]
setblock 411 226 521 minecraft:light[level=14]
setblock 411 226 529 minecraft:light[level=14]
setblock 411 226 545 minecraft:light[level=14]
fill 388 232 527 388 234 529 minecraft:gold_block
fill 388 232 530 392 232 530 minecraft:white_wool
fill 388 232 531 388 234 533 minecraft:gold_block
fill 389 232 525 389 234 526 minecraft:gold_block
fill 389 232 527 393 232 529 minecraft:white_wool
fill 389 232 531 393 232 533 minecraft:white_wool
fill 389 232 534 389 234 535 minecraft:gold_block
fill 390 232 524 390 234 525 minecraft:gold_block
fill 390 232 526 400 233 526 minecraft:white_wool
fill 390 232 534 400 233 534 minecraft:white_wool
fill 390 232 535 390 234 536 minecraft:gold_block
fill 391 232 524 391 234 524 minecraft:gold_block
fill 391 232 525 399 233 525 minecraft:white_wool
fill 391 232 535 399 233 535 minecraft:white_wool
fill 391 232 536 391 234 536 minecraft:gold_block
fill 392 232 523 394 234 523 minecraft:gold_block
fill 392 232 524 398 233 524 minecraft:white_wool
fill 392 232 536 398 233 536 minecraft:white_wool
fill 392 232 537 394 234 537 minecraft:gold_block
fill 394 232 527 394 232 528 minecraft:white_wool
fill 394 232 532 394 232 533 minecraft:white_wool
fill 395 232 523 395 233 523 minecraft:white_wool
fill 395 232 527 401 232 527 minecraft:white_wool
fill 395 232 533 401 232 533 minecraft:white_wool
fill 395 232 537 395 233 537 minecraft:white_wool
fill 396 232 523 398 234 523 minecraft:gold_block
fill 396 232 528 401 232 528 minecraft:white_wool
fill 396 232 532 401 232 532 minecraft:white_wool
fill 396 232 537 398 234 537 minecraft:gold_block
fill 397 232 529 401 232 529 minecraft:white_wool
fill 397 232 531 401 232 531 minecraft:white_wool
fill 398 232 530 402 232 530 minecraft:white_wool
fill 399 232 524 400 234 524 minecraft:gold_block
fill 399 232 536 400 234 536 minecraft:gold_block
fill 400 232 525 401 234 525 minecraft:gold_block
fill 400 232 535 401 234 535 minecraft:gold_block
fill 401 232 526 401 234 526 minecraft:gold_block
fill 401 232 534 401 234 534 minecraft:gold_block
fill 402 232 527 402 234 529 minecraft:gold_block
fill 402 232 531 402 234 533 minecraft:gold_block
fill 377 233 511 386 233 551 minecraft:white_wool
fill 387 233 511 387 233 527 minecraft:white_wool
fill 387 233 528 387 233 532 minecraft:gold_block
fill 387 233 533 387 233 551 minecraft:white_wool
fill 388 233 511 388 233 525 minecraft:white_wool
setblock 388 233 526 minecraft:gold_block
fill 388 233 530 391 233 530 minecraft:white_wool
setblock 388 233 534 minecraft:gold_block
fill 388 233 535 388 233 551 minecraft:white_wool
fill 389 233 511 389 233 524 minecraft:white_wool
fill 389 233 527 391 233 529 minecraft:white_wool
fill 389 233 531 391 233 533 minecraft:white_wool
fill 389 233 536 389 233 551 minecraft:white_wool
fill 390 233 511 390 233 523 minecraft:white_wool
fill 390 233 537 390 233 551 minecraft:white_wool
fill 391 233 511 392 233 522 minecraft:white_wool
setblock 391 233 523 minecraft:gold_block
setblock 391 233 537 minecraft:gold_block
fill 391 233 538 392 233 551 minecraft:white_wool
fill 392 233 527 392 233 528 minecraft:white_wool
fill 392 233 529 392 233 531 minecraft:pearlescent_froglight
fill 392 233 532 392 233 533 minecraft:white_wool
fill 393 233 511 417 233 521 minecraft:white_wool
fill 393 233 522 397 233 522 minecraft:gold_block
setblock 393 233 527 minecraft:white_wool
fill 393 233 528 393 233 529 minecraft:pearlescent_froglight
fill 393 233 531 393 233 532 minecraft:pearlescent_froglight
setblock 393 233 533 minecraft:white_wool
fill 393 233 538 397 233 538 minecraft:gold_block
fill 393 233 539 417 233 551 minecraft:white_wool
fill 394 233 527 394 233 528 minecraft:pearlescent_froglight
fill 394 233 532 394 233 533 minecraft:pearlescent_froglight
fill 395 233 527 396 233 527 minecraft:pearlescent_froglight
fill 395 233 533 396 233 533 minecraft:pearlescent_froglight
fill 396 233 528 397 233 528 minecraft:pearlescent_froglight
fill 396 233 532 397 233 532 minecraft:pearlescent_froglight
fill 397 233 527 401 233 527 minecraft:white_wool
fill 397 233 529 398 233 529 minecraft:pearlescent_froglight
fill 397 233 531 398 233 531 minecraft:pearlescent_froglight
fill 397 233 533 401 233 533 minecraft:white_wool
fill 398 233 522 417 233 522 minecraft:white_wool
fill 398 233 528 401 233 528 minecraft:white_wool
setblock 398 233 530 minecraft:pearlescent_froglight
fill 398 233 532 401 233 532 minecraft:white_wool
fill 398 233 538 417 233 538 minecraft:white_wool
setblock 399 233 523 minecraft:gold_block
fill 399 233 529 401 233 531 minecraft:white_wool
setblock 399 233 537 minecraft:gold_block
fill 400 233 523 417 233 523 minecraft:white_wool
fill 400 233 537 417 233 537 minecraft:white_wool
fill 401 233 524 417 233 524 minecraft:white_wool
fill 401 233 536 417 233 536 minecraft:white_wool
fill 402 233 525 417 233 525 minecraft:white_wool
setblock 402 233 526 minecraft:gold_block
setblock 402 233 530 minecraft:white_wool
setblock 402 233 534 minecraft:gold_block
fill 402 233 535 417 233 535 minecraft:white_wool
fill 403 233 526 417 233 527 minecraft:white_wool
fill 403 233 528 403 233 532 minecraft:gold_block
fill 403 233 533 417 233 534 minecraft:white_wool
fill 404 233 528 417 233 532 minecraft:white_wool
setblock 379 234 513 minecraft:light[level=14]
setblock 379 234 521 minecraft:light[level=14]
setblock 379 234 529 minecraft:light[level=14]
setblock 379 234 537 minecraft:light[level=14]
setblock 379 234 545 minecraft:light[level=14]
setblock 387 234 513 minecraft:light[level=14]
setblock 387 234 521 minecraft:light[level=14]
setblock 387 234 529 minecraft:light[level=14]
setblock 387 234 537 minecraft:light[level=14]
setblock 387 234 545 minecraft:light[level=14]
setblock 388 234 530 minecraft:gold_block
fill 389 234 527 389 234 529 minecraft:gold_block
fill 389 234 531 389 234 533 minecraft:gold_block
setblock 390 234 526 minecraft:gold_block
setblock 390 234 534 minecraft:gold_block
setblock 391 234 525 minecraft:gold_block
setblock 391 234 535 minecraft:gold_block
fill 392 234 524 394 234 524 minecraft:gold_block
fill 392 234 536 394 234 536 minecraft:gold_block
setblock 395 234 513 minecraft:light[level=14]
setblock 395 234 521 minecraft:light[level=14]
setblock 395 234 523 minecraft:gold_block
setblock 395 234 537 minecraft:gold_block
setblock 395 234 545 minecraft:light[level=14]
fill 396 234 524 398 234 524 minecraft:gold_block
fill 396 234 536 398 234 536 minecraft:gold_block
setblock 399 234 525 minecraft:gold_block
setblock 399 234 535 minecraft:gold_block
setblock 400 234 526 minecraft:gold_block
setblock 400 234 534 minecraft:gold_block
fill 401 234 527 401 234 529 minecraft:gold_block
fill 401 234 531 401 234 533 minecraft:gold_block
setblock 402 234 530 minecraft:gold_block
setblock 403 234 513 minecraft:light[level=14]
setblock 403 234 521 minecraft:light[level=14]
setblock 403 234 529 minecraft:light[level=14]
setblock 403 234 537 minecraft:light[level=14]
setblock 403 234 545 minecraft:light[level=14]
setblock 411 234 513 minecraft:light[level=14]
setblock 411 234 521 minecraft:light[level=14]
setblock 411 234 529 minecraft:light[level=14]
setblock 411 234 537 minecraft:light[level=14]
setblock 411 234 545 minecraft:light[level=14]
fill 382 237 531 383 237 532 minecraft:white_wool
fill 394 237 518 395 238 518 minecraft:white_wool
fill 397 237 544 403 240 546 minecraft:smooth_quartz
fill 398 237 543 402 240 543 minecraft:smooth_quartz
fill 398 237 547 402 240 547 minecraft:smooth_quartz
fill 399 237 548 401 240 548 minecraft:smooth_quartz
fill 400 237 542 400 240 542 minecraft:smooth_quartz
fill 406 237 536 406 237 537 minecraft:white_wool
fill 411 237 514 411 237 515 minecraft:smooth_quartz
setblock 412 237 513 minecraft:smooth_quartz
fill 412 237 514 415 273 515 minecraft:quartz_pillar
fill 412 237 516 415 237 516 minecraft:smooth_quartz
fill 413 237 512 414 237 512 minecraft:smooth_quartz
fill 413 237 513 414 273 513 minecraft:quartz_pillar
setblock 415 237 513 minecraft:smooth_quartz
setblock 416 237 514 minecraft:smooth_quartz
fill 397 238 543 397 240 543 minecraft:smooth_quartz
fill 397 238 547 397 240 547 minecraft:smooth_quartz
fill 398 238 548 398 240 548 minecraft:smooth_quartz
fill 399 238 542 399 240 542 minecraft:smooth_quartz
fill 400 238 549 400 240 549 minecraft:smooth_quartz
fill 401 238 542 402 240 542 minecraft:smooth_quartz
fill 402 238 548 402 240 548 minecraft:smooth_quartz
fill 403 238 543 403 240 543 minecraft:smooth_quartz
fill 403 238 547 403 240 547 minecraft:smooth_quartz
fill 387 239 513 391 240 517 minecraft:smooth_quartz
fill 389 239 511 389 239 512 minecraft:smooth_quartz
fill 396 239 544 396 240 546 minecraft:smooth_quartz
fill 397 239 548 397 240 548 minecraft:smooth_quartz
fill 398 239 542 398 240 542 minecraft:smooth_quartz
fill 399 239 549 399 240 549 minecraft:smooth_quartz
fill 400 239 541 400 240 541 minecraft:smooth_quartz
fill 401 239 549 402 240 549 minecraft:smooth_quartz
fill 403 239 548 403 240 548 minecraft:smooth_quartz
fill 404 239 544 404 240 547 minecraft:smooth_quartz
setblock 396 240 543 minecraft:smooth_quartz
setblock 396 240 547 minecraft:smooth_quartz
setblock 397 240 542 minecraft:smooth_quartz
fill 398 240 541 399 240 541 minecraft:smooth_quartz
setblock 398 240 549 minecraft:smooth_quartz
setblock 400 240 550 minecraft:smooth_quartz
fill 401 240 541 402 240 541 minecraft:smooth_quartz
setblock 403 240 542 minecraft:smooth_quartz
setblock 403 240 549 minecraft:smooth_quartz
setblock 404 240 543 minecraft:smooth_quartz
fill 389 241 515 389 244 515 minecraft:quartz_pillar
fill 400 241 545 400 244 545 minecraft:quartz_pillar
setblock 379 242 513 minecraft:light[level=14]
setblock 379 242 521 minecraft:light[level=14]
setblock 379 242 529 minecraft:light[level=14]
setblock 379 242 537 minecraft:light[level=14]
setblock 379 242 545 minecraft:light[level=14]
setblock 387 242 513 minecraft:light[level=14]
setblock 387 242 521 minecraft:light[level=14]
setblock 387 242 529 minecraft:light[level=14]
setblock 387 242 537 minecraft:light[level=14]
setblock 387 242 545 minecraft:light[level=14]
setblock 395 242 513 minecraft:light[level=14]
setblock 395 242 521 minecraft:light[level=14]
setblock 395 242 529 minecraft:light[level=14]
setblock 395 242 537 minecraft:light[level=14]
setblock 395 242 545 minecraft:light[level=14]
setblock 403 242 513 minecraft:light[level=14]
setblock 403 242 521 minecraft:light[level=14]
setblock 403 242 529 minecraft:light[level=14]
setblock 403 242 537 minecraft:light[level=14]
fill 403 242 538 403 243 538 minecraft:white_wool
setblock 403 242 545 minecraft:light[level=14]
setblock 411 242 513 minecraft:light[level=14]
setblock 411 242 521 minecraft:light[level=14]
setblock 411 242 529 minecraft:light[level=14]
setblock 411 242 537 minecraft:light[level=14]
setblock 411 242 545 minecraft:light[level=14]
fill 399 244 544 399 246 546 minecraft:flowering_azalea_leaves[persistent=true]
fill 400 244 544 401 246 544 minecraft:flowering_azalea_leaves[persistent=true]
fill 400 244 546 400 246 547 minecraft:flowering_azalea_leaves[persistent=true]
fill 401 244 545 401 246 546 minecraft:flowering_azalea_leaves[persistent=true]
fill 402 244 545 402 246 545 minecraft:flowering_azalea_leaves[persistent=true]
fill 387 245 515 391 248 515 minecraft:gold_block
fill 388 245 514 390 248 514 minecraft:gold_block
fill 388 245 516 390 248 516 minecraft:gold_block
fill 389 245 513 389 248 513 minecraft:gold_block
fill 389 245 517 389 248 517 minecraft:gold_block
fill 398 245 545 398 245 546 minecraft:flowering_azalea_leaves[persistent=true]
setblock 399 245 547 minecraft:flowering_azalea_leaves[persistent=true]
fill 400 245 543 401 245 543 minecraft:flowering_azalea_leaves[persistent=true]
fill 400 245 545 400 246 545 minecraft:flowering_azalea_leaves[persistent=true]
setblock 401 245 547 minecraft:flowering_azalea_leaves[persistent=true]
setblock 402 245 544 minecraft:flowering_azalea_leaves[persistent=true]
setblock 402 245 546 minecraft:flowering_azalea_leaves[persistent=true]
fill 411 245 514 411 245 515 minecraft:smooth_quartz
setblock 412 245 513 minecraft:smooth_quartz
fill 412 245 516 415 245 516 minecraft:smooth_quartz
fill 413 245 512 414 245 512 minecraft:smooth_quartz
setblock 415 245 513 minecraft:smooth_quartz
setblock 416 245 514 minecraft:smooth_quartz
fill 387 246 514 387 247 514 minecraft:gold_block
fill 387 246 516 387 247 516 minecraft:gold_block
fill 388 246 513 388 247 513 minecraft:gold_block
fill 388 246 517 388 247 517 minecraft:gold_block
fill 390 246 513 390 247 513 minecraft:gold_block
fill 390 246 517 390 247 517 minecraft:gold_block
fill 391 246 514 391 247 514 minecraft:gold_block
fill 391 246 516 391 247 516 minecraft:gold_block
fill 399 247 541 400 248 542 minecraft:white_wool
fill 410 248 515 411 249 519 minecraft:smooth_quartz
fill 412 248 516 414 249 519 minecraft:smooth_quartz
fill 415 248 517 416 248 517 minecraft:smooth_quartz
setblock 389 249 515 minecraft:gold_block
setblock 379 250 513 minecraft:light[level=14]
setblock 379 250 521 minecraft:light[level=14]
setblock 379 250 529 minecraft:light[level=14]
setblock 379 250 537 minecraft:light[level=14]
setblock 379 250 545 minecraft:light[level=14]
setblock 387 250 513 minecraft:light[level=14]
setblock 387 250 521 minecraft:light[level=14]
setblock 387 250 529 minecraft:light[level=14]
setblock 387 250 537 minecraft:light[level=14]
setblock 387 250 545 minecraft:light[level=14]
setblock 395 250 513 minecraft:light[level=14]
setblock 395 250 521 minecraft:light[level=14]
setblock 395 250 529 minecraft:light[level=14]
setblock 395 250 537 minecraft:light[level=14]
setblock 395 250 545 minecraft:light[level=14]
setblock 403 250 513 minecraft:light[level=14]
setblock 403 250 521 minecraft:light[level=14]
setblock 403 250 529 minecraft:light[level=14]
setblock 403 250 537 minecraft:light[level=14]
setblock 403 250 545 minecraft:light[level=14]
setblock 411 250 513 minecraft:light[level=14]
setblock 411 250 521 minecraft:light[level=14]
setblock 411 250 529 minecraft:light[level=14]
setblock 411 250 537 minecraft:light[level=14]
setblock 411 250 545 minecraft:light[level=14]
fill 412 250 517 412 253 517 minecraft:quartz_pillar
fill 395 251 522 396 252 523 minecraft:white_wool
fill 404 251 536 405 252 536 minecraft:white_wool
fill 405 251 535 405 252 535 minecraft:white_wool
fill 405 251 537 405 252 537 minecraft:white_wool
fill 411 253 514 411 253 515 minecraft:smooth_quartz
setblock 412 253 513 minecraft:smooth_quartz
fill 412 253 516 415 253 516 minecraft:smooth_quartz
fill 413 253 512 414 253 512 minecraft:smooth_quartz
setblock 415 253 513 minecraft:smooth_quartz
setblock 416 253 514 minecraft:smooth_quartz
fill 410 254 517 414 257 517 minecraft:gold_block
fill 411 254 516 413 257 516 minecraft:gold_block
fill 411 254 518 413 257 518 minecraft:gold_block
fill 412 254 519 412 257 519 minecraft:gold_block
fill 377 255 532 383 255 532 minecraft:smooth_quartz
fill 379 255 530 383 256 531 minecraft:smooth_quartz
fill 379 255 533 383 256 534 minecraft:smooth_quartz
fill 410 255 516 410 256 516 minecraft:gold_block
fill 410 255 518 410 256 518 minecraft:gold_block
fill 411 255 515 411 256 515 minecraft:gold_block
fill 411 255 519 411 256 519 minecraft:gold_block
fill 413 255 519 413 256 519 minecraft:gold_block
fill 414 255 516 414 256 516 minecraft:gold_block
fill 414 255 518 414 256 518 minecraft:gold_block
fill 379 256 532 383 256 532 minecraft:smooth_quartz
fill 381 257 532 381 260 532 minecraft:quartz_pillar
fill 384 257 532 385 258 533 minecraft:white_wool
setblock 379 258 513 minecraft:light[level=14]
setblock 379 258 521 minecraft:light[level=14]
setblock 379 258 529 minecraft:light[level=14]
setblock 379 258 537 minecraft:light[level=14]
setblock 379 258 545 minecraft:light[level=14]
setblock 387 258 513 minecraft:light[level=14]
setblock 387 258 521 minecraft:light[level=14]
setblock 387 258 529 minecraft:light[level=14]
setblock 387 258 537 minecraft:light[level=14]
setblock 387 258 545 minecraft:light[level=14]
fill 391 258 522 391 259 523 minecraft:white_wool
setblock 395 258 513 minecraft:light[level=14]
setblock 395 258 521 minecraft:light[level=14]
setblock 395 258 529 minecraft:light[level=14]
setblock 395 258 537 minecraft:light[level=14]
setblock 395 258 545 minecraft:light[level=14]
setblock 403 258 513 minecraft:light[level=14]
setblock 403 258 521 minecraft:light[level=14]
setblock 403 258 529 minecraft:light[level=14]
setblock 403 258 537 minecraft:light[level=14]
setblock 403 258 545 minecraft:light[level=14]
setblock 411 258 513 minecraft:light[level=14]
setblock 411 258 521 minecraft:light[level=14]
setblock 411 258 529 minecraft:light[level=14]
setblock 411 258 537 minecraft:light[level=14]
setblock 411 258 545 minecraft:light[level=14]
setblock 412 258 517 minecraft:gold_block
fill 400 259 541 400 260 542 minecraft:white_wool
fill 379 261 532 383 264 532 minecraft:gold_block
fill 380 261 531 382 264 531 minecraft:gold_block
fill 380 261 533 382 264 533 minecraft:gold_block
fill 381 261 530 381 264 530 minecraft:gold_block
fill 381 261 534 381 264 534 minecraft:gold_block
fill 411 261 514 411 261 515 minecraft:smooth_quartz
setblock 412 261 513 minecraft:smooth_quartz
fill 412 261 516 415 261 516 minecraft:smooth_quartz
fill 413 261 512 414 261 512 minecraft:smooth_quartz
setblock 415 261 513 minecraft:smooth_quartz
setblock 416 261 514 minecraft:smooth_quartz
fill 379 262 531 379 263 531 minecraft:gold_block
fill 379 262 533 379 263 533 minecraft:gold_block
fill 380 262 530 380 263 530 minecraft:gold_block
fill 380 262 534 380 263 534 minecraft:gold_block
fill 382 262 530 382 263 530 minecraft:gold_block
fill 382 262 534 382 263 534 minecraft:gold_block
fill 383 262 531 383 263 531 minecraft:gold_block
fill 383 262 533 383 263 533 minecraft:gold_block
fill 391 263 521 391 264 521 minecraft:white_stained_glass
setblock 381 265 532 minecraft:gold_block
fill 391 265 521 391 272 521 minecraft:smooth_quartz
fill 411 265 529 412 266 529 minecraft:white_wool
setblock 379 266 513 minecraft:light[level=14]
setblock 379 266 521 minecraft:light[level=14]
setblock 379 266 529 minecraft:light[level=14]
setblock 379 266 537 minecraft:light[level=14]
setblock 379 266 545 minecraft:light[level=14]
setblock 387 266 513 minecraft:light[level=14]
setblock 387 266 521 minecraft:light[level=14]
setblock 387 266 529 minecraft:light[level=14]
setblock 387 266 537 minecraft:light[level=14]
setblock 387 266 545 minecraft:light[level=14]
setblock 395 266 513 minecraft:light[level=14]
setblock 395 266 521 minecraft:light[level=14]
setblock 395 266 529 minecraft:light[level=14]
setblock 395 266 537 minecraft:light[level=14]
setblock 395 266 545 minecraft:light[level=14]
setblock 403 266 513 minecraft:light[level=14]
setblock 403 266 521 minecraft:light[level=14]
setblock 403 266 529 minecraft:light[level=14]
setblock 403 266 537 minecraft:light[level=14]
setblock 403 266 545 minecraft:light[level=14]
setblock 411 266 513 minecraft:light[level=14]
setblock 411 266 521 minecraft:light[level=14]
setblock 411 266 537 minecraft:light[level=14]
setblock 411 266 545 minecraft:light[level=14]
fill 390 267 520 390 272 521 minecraft:smooth_quartz
fill 391 267 520 391 272 520 minecraft:smooth_quartz
fill 391 268 522 391 272 522 minecraft:smooth_quartz
fill 392 268 520 392 272 521 minecraft:smooth_quartz
fill 389 269 520 389 272 521 minecraft:smooth_quartz
fill 390 269 519 391 272 519 minecraft:smooth_quartz
fill 390 269 522 390 272 522 minecraft:smooth_quartz
fill 392 269 522 392 272 522 minecraft:smooth_quartz
fill 411 269 514 411 269 515 minecraft:smooth_quartz
setblock 412 269 513 minecraft:smooth_quartz
fill 412 269 516 415 269 516 minecraft:smooth_quartz
fill 413 269 512 414 269 512 minecraft:smooth_quartz
setblock 415 269 513 minecraft:smooth_quartz
setblock 416 269 514 minecraft:smooth_quartz
fill 380 270 524 381 271 525 minecraft:white_wool
fill 389 270 522 389 272 522 minecraft:smooth_quartz
fill 391 270 523 391 272 523 minecraft:smooth_quartz
fill 392 270 519 392 272 519 minecraft:smooth_quartz
fill 393 270 520 393 272 521 minecraft:smooth_quartz
fill 388 271 521 388 272 521 minecraft:smooth_quartz
fill 389 271 519 389 272 519 minecraft:smooth_quartz
fill 390 271 518 391 272 518 minecraft:smooth_quartz
fill 390 271 523 390 272 523 minecraft:smooth_quartz
fill 392 271 523 392 272 523 minecraft:smooth_quartz
fill 393 271 519 393 272 519 minecraft:smooth_quartz
fill 393 271 522 393 272 522 minecraft:smooth_quartz
fill 401 271 538 402 272 539 minecraft:white_wool
fill 387 272 517 388 273 518 minecraft:white_wool
fill 388 272 519 388 272 520 minecraft:smooth_quartz
setblock 388 272 522 minecraft:smooth_quartz
setblock 389 272 518 minecraft:smooth_quartz
setblock 389 272 523 minecraft:smooth_quartz
setblock 391 272 524 minecraft:smooth_quartz
setblock 392 272 518 minecraft:smooth_quartz
setblock 393 272 523 minecraft:smooth_quartz
fill 394 272 520 394 272 521 minecraft:smooth_quartz
fill 412 272 513 412 273 513 minecraft:gold_block
fill 412 272 516 414 273 516 minecraft:gold_block
fill 413 272 512 414 273 512 minecraft:gold_block
fill 415 272 513 415 273 513 minecraft:gold_block
setblock 391 273 521 minecraft:quartz_pillar
setblock 379 274 513 minecraft:light[level=14]
setblock 379 274 521 minecraft:light[level=14]
setblock 379 274 529 minecraft:light[level=14]
setblock 379 274 537 minecraft:light[level=14]
setblock 379 274 545 minecraft:light[level=14]
setblock 387 274 513 minecraft:light[level=14]
setblock 387 274 521 minecraft:light[level=14]
setblock 387 274 529 minecraft:light[level=14]
setblock 387 274 537 minecraft:light[level=14]
setblock 387 274 545 minecraft:light[level=14]
setblock 395 274 513 minecraft:light[level=14]
setblock 395 274 521 minecraft:light[level=14]
setblock 395 274 529 minecraft:light[level=14]
setblock 395 274 537 minecraft:light[level=14]
setblock 395 274 545 minecraft:light[level=14]
setblock 403 274 513 minecraft:light[level=14]
setblock 403 274 521 minecraft:light[level=14]
setblock 403 274 529 minecraft:light[level=14]
setblock 403 274 537 minecraft:light[level=14]
setblock 403 274 545 minecraft:light[level=14]
setblock 411 274 513 minecraft:light[level=14]
setblock 411 274 521 minecraft:light[level=14]
setblock 411 274 529 minecraft:light[level=14]
setblock 411 274 537 minecraft:light[level=14]
setblock 411 274 545 minecraft:light[level=14]
fill 377 279 511 377 280 514 minecraft:white_concrete
fill 377 279 515 377 280 529 minecraft:white_wool
fill 377 279 530 377 280 535 minecraft:white_concrete
fill 377 279 536 377 280 550 minecraft:white_wool
fill 377 279 551 379 280 551 minecraft:white_concrete
fill 378 279 511 378 280 512 minecraft:white_concrete
fill 378 279 513 378 280 527 minecraft:white_wool
fill 378 279 528 378 280 533 minecraft:white_concrete
fill 378 279 534 378 280 548 minecraft:white_wool
fill 378 279 549 380 280 550 minecraft:white_concrete
fill 379 279 511 379 280 525 minecraft:white_wool
fill 379 279 526 379 280 531 minecraft:white_concrete
fill 379 279 532 379 280 546 minecraft:white_wool
fill 379 279 547 381 280 548 minecraft:white_concrete
fill 380 279 511 380 280 523 minecraft:white_wool
fill 380 279 524 380 280 529 minecraft:white_concrete
fill 380 279 530 380 280 544 minecraft:white_wool
fill 380 279 545 382 280 546 minecraft:white_concrete
fill 380 279 551 387 280 551 minecraft:white_wool
fill 381 279 511 381 280 521 minecraft:white_wool
fill 381 279 522 381 280 527 minecraft:white_concrete
fill 381 279 528 381 280 542 minecraft:white_wool
fill 381 279 543 383 280 544 minecraft:white_concrete
fill 381 279 549 387 280 550 minecraft:white_wool
fill 382 279 511 382 280 519 minecraft:white_wool
fill 382 279 520 382 280 525 minecraft:white_concrete
fill 382 279 526 382 280 540 minecraft:white_wool
fill 382 279 541 384 280 542 minecraft:white_concrete
fill 382 279 547 388 280 548 minecraft:white_wool
fill 383 279 511 383 280 517 minecraft:white_wool
fill 383 279 518 383 280 523 minecraft:white_concrete
fill 383 279 524 383 280 538 minecraft:white_wool
fill 383 279 539 385 280 540 minecraft:white_concrete
fill 383 279 545 389 280 546 minecraft:white_wool
fill 384 279 511 384 280 515 minecraft:white_wool
fill 384 279 516 384 280 521 minecraft:white_concrete
fill 384 279 522 384 280 536 minecraft:white_wool
fill 384 279 537 386 280 538 minecraft:white_concrete
fill 384 279 543 390 280 544 minecraft:white_wool
fill 385 279 511 385 280 513 minecraft:white_wool
fill 385 279 514 385 280 519 minecraft:white_concrete
fill 385 279 520 385 280 534 minecraft:white_wool
fill 385 279 535 387 280 536 minecraft:white_concrete
fill 385 279 541 391 280 542 minecraft:white_wool
fill 386 279 511 386 280 511 minecraft:white_wool
fill 386 279 512 386 280 517 minecraft:white_concrete
fill 386 279 518 386 280 532 minecraft:white_wool
fill 386 279 533 388 280 534 minecraft:white_concrete
fill 386 279 539 392 280 540 minecraft:white_wool
fill 387 279 511 387 280 515 minecraft:white_concrete
fill 387 279 516 387 280 530 minecraft:white_wool
fill 387 279 531 389 280 532 minecraft:white_concrete
fill 387 279 537 393 280 538 minecraft:white_wool
fill 388 279 511 388 280 513 minecraft:white_concrete
fill 388 279 514 388 280 528 minecraft:white_wool
fill 388 279 529 390 280 530 minecraft:white_concrete
fill 388 279 535 394 279 536 minecraft:white_wool
fill 388 279 549 388 280 549 minecraft:white_wool
fill 388 279 550 390 280 551 minecraft:white_concrete
fill 389 279 511 389 280 511 minecraft:white_concrete
fill 389 279 512 389 280 526 minecraft:white_wool
fill 389 279 527 391 280 528 minecraft:white_concrete
fill 389 279 533 392 279 534 minecraft:white_wool
fill 389 279 547 389 280 547 minecraft:white_wool
fill 389 279 548 391 280 549 minecraft:white_concrete
fill 390 279 511 390 280 524 minecraft:white_wool
fill 390 279 525 392 280 526 minecraft:white_concrete
fill 390 279 531 393 279 532 minecraft:white_wool
fill 390 279 545 390 280 545 minecraft:white_wool
fill 390 279 546 392 280 547 minecraft:white_concrete
fill 391 279 511 391 280 522 minecraft:white_wool
fill 391 279 523 393 280 524 minecraft:white_concrete
fill 391 279 529 397 279 530 minecraft:white_wool
fill 391 279 543 391 280 543 minecraft:white_wool
fill 391 279 544 393 280 545 minecraft:white_concrete
fill 391 279 550 397 280 551 minecraft:white_wool
fill 392 279 511 392 280 520 minecraft:white_wool
fill 392 279 521 394 280 522 minecraft:white_concrete
fill 392 279 527 398 280 528 minecraft:white_wool
fill 392 279 541 392 280 541 minecraft:white_wool
fill 392 279 542 394 280 543 minecraft:white_concrete
fill 392 279 548 398 280 549 minecraft:white_wool
fill 393 279 511 393 280 518 minecraft:white_wool
fill 393 279 519 395 280 520 minecraft:white_concrete
fill 393 279 525 399 280 526 minecraft:white_wool
setblock 393 279 534 minecraft:white_wool
fill 393 279 539 393 280 539 minecraft:white_wool
fill 393 279 540 395 280 541 minecraft:white_concrete
fill 393 279 546 399 280 547 minecraft:white_wool
fill 394 279 511 394 280 516 minecraft:white_wool
fill 394 279 517 396 280 518 minecraft:white_concrete
fill 394 279 523 400 280 524 minecraft:white_wool
setblock 394 279 531 minecraft:white_wool
fill 394 279 537 394 280 537 minecraft:white_wool
fill 394 279 538 396 280 539 minecraft:white_concrete
fill 394 279 544 400 280 545 minecraft:white_wool
fill 395 279 511 395 280 514 minecraft:white_wool
fill 395 279 515 397 280 516 minecraft:white_concrete
fill 395 279 521 401 280 522 minecraft:white_wool
fill 395 279 536 397 279 537 minecraft:white_concrete
fill 395 279 542 401 280 543 minecraft:white_wool
fill 396 279 511 396 280 512 minecraft:white_wool
fill 396 279 513 398 280 514 minecraft:white_concrete
fill 396 279 519 402 280 520 minecraft:white_wool
fill 396 279 531 397 279 531 minecraft:white_wool
fill 396 279 535 398 279 535 minecraft:white_concrete
fill 396 279 540 402 280 541 minecraft:white_wool
fill 397 279 511 399 280 512 minecraft:white_concrete
fill 397 279 517 403 280 518 minecraft:white_wool
fill 397 279 532 399 279 532 minecraft:white_concrete
fill 397 279 534 398 279 534 minecraft:white_concrete
fill 397 279 538 403 280 539 minecraft:white_wool
fill 398 279 515 404 280 516 minecraft:white_wool
fill 398 279 529 398 280 529 minecraft:white_wool
fill 398 279 530 400 280 531 minecraft:white_concrete
fill 398 279 533 399 279 533 minecraft:white_concrete
fill 398 279 536 404 280 537 minecraft:white_wool
fill 398 279 550 398 280 550 minecraft:white_wool
fill 398 279 551 400 280 551 minecraft:white_concrete
fill 399 279 513 405 280 514 minecraft:white_wool
fill 399 279 527 399 280 527 minecraft:white_wool
fill 399 279 528 401 280 529 minecraft:white_concrete
fill 399 279 534 405 280 535 minecraft:white_wool
fill 399 279 548 399 280 548 minecraft:white_wool
fill 399 279 549 401 280 550 minecraft:white_concrete
fill 400 279 511 406 280 512 minecraft:white_wool
fill 400 279 525 400 280 525 minecraft:white_wool
fill 400 279 526 402 280 527 minecraft:white_concrete
fill 400 279 532 406 280 533 minecraft:white_wool
fill 400 279 546 400 280 546 minecraft:white_wool
fill 400 279 547 402 280 548 minecraft:white_concrete
fill 401 279 523 401 280 523 minecraft:white_wool
fill 401 279 524 403 280 525 minecraft:white_concrete
fill 401 279 530 407 280 531 minecraft:white_wool
fill 401 279 544 401 280 544 minecraft:white_wool
fill 401 279 545 403 280 546 minecraft:white_concrete
fill 401 279 551 408 280 551 minecraft:white_wool
fill 402 279 521 402 280 521 minecraft:white_wool
fill 402 279 522 404 280 523 minecraft:white_concrete
fill 402 279 528 408 280 529 minecraft:white_wool
fill 402 279 542 402 280 542 minecraft:white_wool
fill 402 279 543 404 280 544 minecraft:white_concrete
fill 402 279 549 408 280 550 minecraft:white_wool
fill 403 279 519 403 280 519 minecraft:white_wool
fill 403 279 520 405 280 521 minecraft:white_concrete
fill 403 279 526 409 280 527 minecraft:white_wool
fill 403 279 540 403 280 540 minecraft:white_wool
fill 403 279 541 405 280 542 minecraft:white_concrete
fill 403 279 547 409 280 548 minecraft:white_wool
fill 404 279 517 404 280 517 minecraft:white_wool
fill 404 279 518 406 280 519 minecraft:white_concrete
fill 404 279 524 410 280 525 minecraft:white_wool
fill 404 279 538 404 280 538 minecraft:white_wool
fill 404 279 539 406 280 540 minecraft:white_concrete
fill 404 279 545 410 280 546 minecraft:white_wool
fill 405 279 515 405 280 515 minecraft:white_wool
fill 405 279 516 407 280 517 minecraft:white_concrete
fill 405 279 522 411 280 523 minecraft:white_wool
fill 405 279 536 405 280 536 minecraft:white_wool
fill 405 279 537 407 280 538 minecraft:white_concrete
fill 405 279 543 411 280 544 minecraft:white_wool
fill 406 279 513 406 280 513 minecraft:white_wool
fill 406 279 514 408 280 515 minecraft:white_concrete
fill 406 279 520 412 280 521 minecraft:white_wool
fill 406 279 534 406 280 534 minecraft:white_wool
fill 406 279 535 408 280 536 minecraft:white_concrete
fill 406 279 541 412 280 542 minecraft:white_wool
fill 407 279 511 407 280 511 minecraft:white_wool
fill 407 279 512 409 280 513 minecraft:white_concrete
fill 407 279 518 413 280 519 minecraft:white_wool
fill 407 279 532 407 280 532 minecraft:white_wool
fill 407 279 533 409 280 534 minecraft:white_concrete
fill 407 279 539 413 280 540 minecraft:white_wool
fill 408 279 511 410 280 511 minecraft:white_concrete
fill 408 279 516 414 280 517 minecraft:white_wool
fill 408 279 530 408 280 530 minecraft:white_wool
fill 408 279 531 410 280 532 minecraft:white_concrete
fill 408 279 537 414 280 538 minecraft:white_wool
fill 409 279 514 415 280 515 minecraft:white_wool
fill 409 279 528 409 280 528 minecraft:white_wool
fill 409 279 529 411 280 530 minecraft:white_concrete
fill 409 279 535 415 280 536 minecraft:white_wool
fill 409 279 549 409 280 549 minecraft:white_wool
fill 409 279 550 411 280 551 minecraft:white_concrete
fill 410 279 512 416 280 513 minecraft:white_wool
fill 410 279 526 410 280 526 minecraft:white_wool
fill 410 279 527 412 280 528 minecraft:white_concrete
fill 410 279 533 416 280 534 minecraft:white_wool
fill 410 279 547 410 280 547 minecraft:white_wool
fill 410 279 548 412 280 549 minecraft:white_concrete
fill 411 279 511 417 280 511 minecraft:white_wool
fill 411 279 524 411 280 524 minecraft:white_wool
fill 411 279 525 413 280 526 minecraft:white_concrete
fill 411 279 531 417 280 532 minecraft:white_wool
fill 411 279 545 411 280 545 minecraft:white_wool
fill 411 279 546 413 280 547 minecraft:white_concrete
fill 412 279 522 412 280 522 minecraft:white_wool
fill 412 279 523 414 280 524 minecraft:white_concrete
fill 412 279 529 417 280 530 minecraft:white_wool
fill 412 279 543 412 280 543 minecraft:white_wool
fill 412 279 544 414 280 545 minecraft:white_concrete
fill 412 279 550 417 280 551 minecraft:white_wool
fill 413 279 520 413 280 520 minecraft:white_wool
fill 413 279 521 415 280 522 minecraft:white_concrete
fill 413 279 527 417 280 528 minecraft:white_wool
fill 413 279 541 413 280 541 minecraft:white_wool
fill 413 279 542 415 280 543 minecraft:white_concrete
fill 413 279 548 417 280 549 minecraft:white_wool
fill 414 279 518 414 280 518 minecraft:white_wool
fill 414 279 519 416 280 520 minecraft:white_concrete
fill 414 279 525 417 280 526 minecraft:white_wool
fill 414 279 539 414 280 539 minecraft:white_wool
fill 414 279 540 416 280 541 minecraft:white_concrete
fill 414 279 546 417 280 547 minecraft:white_wool
fill 415 279 516 415 280 516 minecraft:white_wool
fill 415 279 517 417 280 518 minecraft:white_concrete
fill 415 279 523 417 280 524 minecraft:white_wool
fill 415 279 537 415 280 537 minecraft:white_wool
fill 415 279 538 417 280 539 minecraft:white_concrete
fill 415 279 544 417 280 545 minecraft:white_wool
fill 416 279 514 416 280 514 minecraft:white_wool
fill 416 279 515 417 280 516 minecraft:white_concrete
fill 416 279 521 417 280 522 minecraft:white_wool
fill 416 279 535 416 280 535 minecraft:white_wool
fill 416 279 536 417 280 537 minecraft:white_concrete
fill 416 279 542 417 280 543 minecraft:white_wool
fill 417 279 512 417 280 512 minecraft:white_wool
fill 417 279 513 417 280 514 minecraft:white_concrete
fill 417 279 519 417 280 520 minecraft:white_wool
fill 417 279 533 417 280 533 minecraft:white_wool
fill 417 279 534 417 280 535 minecraft:white_concrete
fill 417 279 540 417 280 541 minecraft:white_wool
fill 388 280 535 392 280 536 minecraft:white_wool
fill 389 280 533 391 280 534 minecraft:white_wool
fill 390 280 531 391 280 532 minecraft:white_wool
fill 391 280 529 393 280 530 minecraft:white_wool
setblock 392 280 531 minecraft:white_wool
fill 392 280 532 392 280 534 minecraft:pearlescent_froglight
fill 393 280 531 393 280 532 minecraft:pearlescent_froglight
fill 393 280 534 393 280 535 minecraft:pearlescent_froglight
setblock 393 280 536 minecraft:white_wool
fill 394 280 529 397 280 529 minecraft:white_wool
fill 394 280 530 394 280 531 minecraft:pearlescent_froglight
fill 394 280 535 394 280 536 minecraft:pearlescent_froglight
fill 395 280 530 396 280 530 minecraft:pearlescent_froglight
fill 395 280 536 396 280 536 minecraft:pearlescent_froglight
fill 395 280 537 397 280 537 minecraft:white_concrete
fill 396 280 531 397 280 531 minecraft:pearlescent_froglight
fill 396 280 535 397 280 535 minecraft:pearlescent_froglight
setblock 397 280 530 minecraft:white_wool
fill 397 280 532 398 280 532 minecraft:pearlescent_froglight
fill 397 280 534 398 280 534 minecraft:pearlescent_froglight
setblock 397 280 536 minecraft:white_concrete
setblock 398 280 533 minecraft:pearlescent_froglight
setblock 398 280 535 minecraft:white_concrete
fill 399 280 532 399 280 533 minecraft:white_concrete
setblock 379 282 513 minecraft:light[level=14]
setblock 379 282 521 minecraft:light[level=14]
setblock 379 282 529 minecraft:light[level=14]
setblock 379 282 537 minecraft:light[level=14]
setblock 379 282 545 minecraft:light[level=14]
setblock 387 282 513 minecraft:light[level=14]
setblock 387 282 521 minecraft:light[level=14]
setblock 387 282 529 minecraft:light[level=14]
setblock 387 282 537 minecraft:light[level=14]
setblock 387 282 545 minecraft:light[level=14]
setblock 395 282 513 minecraft:light[level=14]
setblock 395 282 521 minecraft:light[level=14]
setblock 395 282 529 minecraft:light[level=14]
setblock 395 282 537 minecraft:light[level=14]
setblock 395 282 545 minecraft:light[level=14]
setblock 403 282 513 minecraft:light[level=14]
setblock 403 282 521 minecraft:light[level=14]
setblock 403 282 529 minecraft:light[level=14]
setblock 403 282 537 minecraft:light[level=14]
setblock 403 282 545 minecraft:light[level=14]
setblock 411 282 513 minecraft:light[level=14]
setblock 411 282 521 minecraft:light[level=14]
setblock 411 282 529 minecraft:light[level=14]
setblock 411 282 537 minecraft:light[level=14]
setblock 411 282 545 minecraft:light[level=14]
fill 380 284 513 380 284 515 minecraft:smooth_quartz
fill 381 284 512 383 284 512 minecraft:smooth_quartz
fill 381 284 513 383 300 515 minecraft:quartz_pillar
fill 381 284 516 383 284 516 minecraft:smooth_quartz
fill 384 284 513 384 284 515 minecraft:smooth_quartz
fill 394 284 540 399 287 543 minecraft:smooth_quartz
fill 395 284 539 398 287 539 minecraft:smooth_quartz
fill 395 284 544 398 287 544 minecraft:smooth_quartz
setblock 411 284 513 minecraft:smooth_quartz
fill 411 284 514 414 300 514 minecraft:quartz_pillar
setblock 411 284 515 minecraft:smooth_quartz
fill 412 284 512 414 284 512 minecraft:smooth_quartz
fill 412 284 513 414 300 513 minecraft:quartz_pillar
fill 412 284 515 414 300 515 minecraft:quartz_pillar
fill 412 284 516 414 284 516 minecraft:smooth_quartz
fill 415 284 513 415 284 515 minecraft:smooth_quartz
fill 393 285 541 393 287 542 minecraft:smooth_quartz
fill 394 285 539 394 287 539 minecraft:smooth_quartz
fill 394 285 544 394 287 544 minecraft:smooth_quartz
fill 396 285 538 397 287 538 minecraft:smooth_quartz
fill 396 285 545 397 287 545 minecraft:smooth_quartz
fill 399 285 539 399 287 539 minecraft:smooth_quartz
fill 399 285 544 399 287 544 minecraft:smooth_quartz
fill 400 285 541 400 287 542 minecraft:smooth_quartz
fill 393 286 540 393 287 540 minecraft:smooth_quartz
fill 393 286 543 393 287 543 minecraft:smooth_quartz
fill 395 286 538 395 287 538 minecraft:smooth_quartz
fill 395 286 545 395 287 545 minecraft:smooth_quartz
fill 398 286 538 398 287 538 minecraft:smooth_quartz
fill 398 286 545 398 287 545 minecraft:smooth_quartz
fill 400 286 540 400 287 540 minecraft:smooth_quartz
fill 400 286 543 400 287 543 minecraft:smooth_quartz
fill 392 287 540 392 287 543 minecraft:smooth_quartz
setblock 393 287 539 minecraft:smooth_quartz
setblock 393 287 544 minecraft:smooth_quartz
setblock 394 287 538 minecraft:smooth_quartz
setblock 394 287 545 minecraft:smooth_quartz
fill 396 287 537 397 287 537 minecraft:smooth_quartz
fill 396 287 546 397 287 546 minecraft:smooth_quartz
setblock 399 287 538 minecraft:smooth_quartz
setblock 399 287 545 minecraft:smooth_quartz
setblock 400 287 539 minecraft:smooth_quartz
setblock 400 287 544 minecraft:smooth_quartz
fill 413 287 529 413 289 529 minecraft:white_stained_glass
setblock 396 288 539 minecraft:white_wool
setblock 379 290 513 minecraft:light[level=14]
setblock 379 290 521 minecraft:light[level=14]
setblock 379 290 529 minecraft:light[level=14]
setblock 379 290 537 minecraft:light[level=14]
setblock 379 290 545 minecraft:light[level=14]
setblock 387 290 513 minecraft:light[level=14]
setblock 387 290 521 minecraft:light[level=14]
setblock 387 290 529 minecraft:light[level=14]
setblock 387 290 537 minecraft:light[level=14]
setblock 387 290 545 minecraft:light[level=14]
setblock 395 290 513 minecraft:light[level=14]
setblock 395 290 521 minecraft:light[level=14]
setblock 395 290 529 minecraft:light[level=14]
setblock 395 290 537 minecraft:light[level=14]
setblock 395 290 545 minecraft:light[level=14]
setblock 403 290 513 minecraft:light[level=14]
setblock 403 290 521 minecraft:light[level=14]
setblock 403 290 529 minecraft:light[level=14]
setblock 403 290 537 minecraft:light[level=14]
setblock 403 290 545 minecraft:light[level=14]
setblock 411 290 513 minecraft:light[level=14]
setblock 411 290 521 minecraft:light[level=14]
setblock 411 290 529 minecraft:light[level=14]
setblock 411 290 537 minecraft:light[level=14]
setblock 411 290 545 minecraft:light[level=14]
fill 412 290 529 413 298 529 minecraft:smooth_quartz
fill 395 291 541 398 293 542 minecraft:flowering_azalea_leaves[persistent=true]
fill 396 291 540 397 293 540 minecraft:flowering_azalea_leaves[persistent=true]
fill 396 291 543 397 293 543 minecraft:flowering_azalea_leaves[persistent=true]
fill 412 291 528 413 298 528 minecraft:smooth_quartz
fill 380 292 513 380 292 515 minecraft:smooth_quartz
fill 381 292 512 383 292 512 minecraft:smooth_quartz
fill 381 292 516 383 292 516 minecraft:smooth_quartz
fill 384 292 513 384 292 515 minecraft:smooth_quartz
setblock 395 292 540 minecraft:flowering_azalea_leaves[persistent=true]
setblock 395 292 543 minecraft:flowering_azalea_leaves[persistent=true]
setblock 398 292 540 minecraft:flowering_azalea_leaves[persistent=true]
setblock 398 292 543 minecraft:flowering_azalea_leaves[persistent=true]
setblock 411 292 513 minecraft:smooth_quartz
setblock 411 292 515 minecraft:smooth_quartz
fill 411 292 528 411 298 529 minecraft:smooth_quartz
fill 412 292 512 414 292 512 minecraft:smooth_quartz
fill 412 292 516 414 292 516 minecraft:smooth_quartz
fill 412 292 530 413 298 530 minecraft:smooth_quartz
fill 414 292 528 414 298 529 minecraft:smooth_quartz
fill 415 292 513 415 292 515 minecraft:smooth_quartz
fill 411 293 530 411 298 530 minecraft:smooth_quartz
fill 412 293 527 413 298 527 minecraft:smooth_quartz
fill 414 293 530 414 298 530 minecraft:smooth_quartz
fill 410 294 528 410 298 529 minecraft:smooth_quartz
fill 411 294 527 411 298 527 minecraft:smooth_quartz
fill 412 294 531 413 298 531 minecraft:smooth_quartz
fill 414 294 527 414 298 527 minecraft:smooth_quartz
fill 415 294 528 415 298 529 minecraft:smooth_quartz
fill 410 295 527 410 298 527 minecraft:smooth_quartz
fill 410 295 530 410 298 530 minecraft:smooth_quartz
fill 411 295 526 414 298 526 minecraft:smooth_quartz
fill 411 295 531 411 298 531 minecraft:smooth_quartz
fill 414 295 531 414 298 531 minecraft:smooth_quartz
fill 415 295 527 415 298 527 minecraft:smooth_quartz
fill 415 295 530 415 298 530 minecraft:smooth_quartz
fill 409 296 528 409 298 529 minecraft:smooth_quartz
fill 410 296 531 410 298 531 minecraft:smooth_quartz
fill 412 296 532 413 298 532 minecraft:smooth_quartz
fill 415 296 531 415 298 531 minecraft:smooth_quartz
fill 416 296 528 416 298 529 minecraft:smooth_quartz
fill 409 297 527 409 298 527 minecraft:smooth_quartz
fill 409 297 530 409 298 530 minecraft:smooth_quartz
fill 410 297 526 410 298 526 minecraft:smooth_quartz
fill 411 297 525 414 298 525 minecraft:smooth_quartz
fill 411 297 532 411 298 532 minecraft:smooth_quartz
fill 414 297 532 414 298 532 minecraft:smooth_quartz
fill 415 297 526 415 298 526 minecraft:smooth_quartz
fill 416 297 527 416 298 527 minecraft:smooth_quartz
fill 416 297 530 416 298 530 minecraft:smooth_quartz
setblock 379 298 513 minecraft:light[level=14]
setblock 379 298 521 minecraft:light[level=14]
setblock 379 298 529 minecraft:light[level=14]
setblock 379 298 537 minecraft:light[level=14]
setblock 379 298 545 minecraft:light[level=14]
setblock 387 298 513 minecraft:light[level=14]
setblock 387 298 521 minecraft:light[level=14]
setblock 387 298 529 minecraft:light[level=14]
setblock 387 298 537 minecraft:light[level=14]
setblock 387 298 545 minecraft:light[level=14]
setblock 395 298 513 minecraft:light[level=14]
setblock 395 298 521 minecraft:light[level=14]
setblock 395 298 529 minecraft:light[level=14]
setblock 395 298 537 minecraft:light[level=14]
setblock 395 298 545 minecraft:light[level=14]
setblock 403 298 513 minecraft:light[level=14]
setblock 403 298 521 minecraft:light[level=14]
setblock 403 298 529 minecraft:light[level=14]
setblock 403 298 537 minecraft:light[level=14]
setblock 403 298 545 minecraft:light[level=14]
setblock 408 298 529 minecraft:smooth_quartz
setblock 409 298 526 minecraft:smooth_quartz
setblock 409 298 531 minecraft:smooth_quartz
setblock 410 298 525 minecraft:smooth_quartz
setblock 410 298 532 minecraft:smooth_quartz
setblock 411 298 513 minecraft:light[level=14]
setblock 411 298 521 minecraft:light[level=14]
setblock 411 298 537 minecraft:light[level=14]
setblock 411 298 545 minecraft:light[level=14]
fill 412 298 533 413 298 533 minecraft:smooth_quartz
setblock 415 298 525 minecraft:smooth_quartz
setblock 415 298 532 minecraft:smooth_quartz
setblock 416 298 526 minecraft:smooth_quartz
setblock 416 298 531 minecraft:smooth_quartz
fill 417 298 528 417 298 529 minecraft:smooth_quartz
fill 380 299 513 380 300 515 minecraft:gold_block
fill 381 299 512 383 300 512 minecraft:gold_block
fill 381 299 516 383 300 516 minecraft:gold_block
fill 384 299 513 384 300 515 minecraft:gold_block
fill 411 299 513 411 300 513 minecraft:gold_block
fill 411 299 515 411 300 515 minecraft:gold_block
fill 412 299 512 413 300 512 minecraft:gold_block
fill 412 299 516 414 300 516 minecraft:gold_block
fill 415 299 514 415 300 514 minecraft:gold_block
