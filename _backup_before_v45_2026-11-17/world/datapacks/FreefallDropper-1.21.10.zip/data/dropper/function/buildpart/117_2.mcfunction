fill 424 87 490 424 90 490 minecraft:blackstone
setblock 424 87 494 minecraft:polished_blackstone_bricks
fill 424 87 495 424 90 495 minecraft:blackstone
setblock 424 87 499 minecraft:polished_blackstone_bricks
fill 424 87 500 424 90 500 minecraft:blackstone
setblock 424 87 504 minecraft:polished_blackstone_bricks
setblock 425 87 493 minecraft:polished_blackstone_bricks
fill 425 87 494 425 90 494 minecraft:blackstone
setblock 425 87 498 minecraft:polished_blackstone_bricks
fill 425 87 499 425 90 499 minecraft:blackstone
setblock 425 87 502 minecraft:blackstone
fill 425 87 504 425 90 504 minecraft:blackstone
setblock 426 87 497 minecraft:polished_blackstone_bricks
fill 426 87 498 426 88 498 minecraft:blackstone
setblock 438 87 464 minecraft:blackstone
setblock 438 87 504 minecraft:blackstone
setblock 439 87 464 minecraft:polished_blackstone_bricks
setblock 439 87 504 minecraft:polished_blackstone_bricks
fill 440 87 464 440 90 464 minecraft:blackstone
fill 440 87 504 442 88 504 minecraft:blackstone
setblock 444 87 464 minecraft:polished_blackstone_bricks
setblock 453 87 464 minecraft:blackstone
setblock 453 87 504 minecraft:blackstone
setblock 454 87 464 minecraft:polished_blackstone_bricks
setblock 454 87 504 minecraft:polished_blackstone_bricks
fill 455 87 464 455 90 464 minecraft:blackstone
setblock 455 87 503 minecraft:polished_blackstone_bricks
fill 455 87 504 455 90 504 minecraft:blackstone
fill 456 87 465 457 87 465 minecraft:blackstone
fill 456 87 503 456 90 503 minecraft:blackstone
fill 457 87 502 460 87 502 minecraft:blackstone
setblock 458 87 465 minecraft:polished_blackstone_bricks
fill 458 87 486 460 91 486 minecraft:polished_blackstone_bricks
setblock 459 87 464 minecraft:polished_blackstone_bricks
fill 459 87 465 459 90 465 minecraft:blackstone
fill 459 87 501 461 87 501 minecraft:blackstone
setblock 459 87 504 minecraft:polished_blackstone_bricks
fill 460 87 464 460 90 464 minecraft:blackstone
setblock 460 87 503 minecraft:polished_blackstone_bricks
fill 460 87 504 460 90 504 minecraft:blackstone
setblock 461 87 496 minecraft:blackstone
setblock 461 87 497 minecraft:polished_blackstone_bricks
fill 461 87 498 461 90 498 minecraft:blackstone
fill 461 87 500 461 88 500 minecraft:blackstone
setblock 461 87 502 minecraft:polished_blackstone_bricks
fill 461 87 503 461 90 503 minecraft:blackstone
setblock 462 87 496 minecraft:polished_blackstone_bricks
fill 462 87 497 462 90 497 minecraft:blackstone
setblock 462 87 501 minecraft:polished_blackstone_bricks
fill 462 87 502 462 90 502 minecraft:blackstone
setblock 463 87 471 minecraft:blackstone
setblock 463 87 475 minecraft:polished_blackstone_bricks
fill 463 87 476 463 90 476 minecraft:blackstone
fill 463 87 478 463 88 478 minecraft:blackstone
setblock 463 87 491 minecraft:blackstone
setblock 463 87 495 minecraft:polished_blackstone_bricks
fill 463 87 496 463 90 496 minecraft:blackstone
setblock 463 87 500 minecraft:polished_blackstone_bricks
fill 463 87 501 463 90 501 minecraft:blackstone
setblock 464 87 464 minecraft:polished_blackstone_bricks
setblock 464 87 465 minecraft:blackstone
setblock 464 87 469 minecraft:polished_blackstone_bricks
fill 464 87 470 464 88 470 minecraft:blackstone
setblock 464 87 474 minecraft:polished_blackstone_bricks
fill 464 87 475 464 90 475 minecraft:blackstone
setblock 464 87 479 minecraft:polished_blackstone_bricks
fill 464 87 480 464 90 480 minecraft:blackstone
setblock 464 87 489 minecraft:polished_blackstone_bricks
fill 464 87 490 464 90 490 minecraft:blackstone
setblock 464 87 494 minecraft:polished_blackstone_bricks
fill 464 87 495 464 90 495 minecraft:blackstone
setblock 464 87 499 minecraft:polished_blackstone_bricks
fill 464 87 500 464 90 500 minecraft:blackstone
setblock 464 87 504 minecraft:polished_blackstone_bricks
setblock 424 88 473 minecraft:polished_blackstone_bricks
fill 424 88 474 424 91 474 minecraft:blackstone
setblock 424 88 478 minecraft:polished_blackstone_bricks
fill 424 88 479 424 88 482 minecraft:blackstone
setblock 424 88 483 minecraft:polished_blackstone_bricks
fill 424 88 484 424 91 484 minecraft:blackstone
setblock 424 88 488 minecraft:polished_blackstone_bricks
fill 424 88 489 424 91 489 minecraft:blackstone
setblock 424 88 493 minecraft:polished_blackstone_bricks
fill 424 88 494 424 91 494 minecraft:blackstone
setblock 424 88 498 minecraft:polished_blackstone_bricks
fill 424 88 499 424 91 499 minecraft:blackstone
setblock 424 88 503 minecraft:polished_blackstone_bricks
fill 424 88 504 424 91 504 minecraft:blackstone
setblock 425 88 476 minecraft:blackstone
setblock 425 88 477 minecraft:polished_blackstone_bricks
fill 425 88 478 425 89 480 minecraft:blackstone
setblock 425 88 492 minecraft:polished_blackstone_bricks
fill 425 88 493 425 90 493 minecraft:blackstone
setblock 425 88 497 minecraft:polished_blackstone_bricks
fill 425 88 498 425 91 498 minecraft:blackstone
setblock 425 88 502 minecraft:polished_blackstone_bricks
setblock 426 88 466 minecraft:light[level=11]
setblock 426 88 474 minecraft:light[level=11]
setblock 426 88 482 minecraft:light[level=11]
setblock 426 88 490 minecraft:light[level=11]
setblock 426 88 496 minecraft:polished_blackstone_bricks
setblock 426 88 497 minecraft:blackstone
setblock 434 88 466 minecraft:light[level=11]
setblock 434 88 474 minecraft:light[level=11]
setblock 434 88 482 minecraft:light[level=11]
setblock 434 88 490 minecraft:light[level=11]
setblock 434 88 498 minecraft:light[level=11]
fill 435 88 504 437 88 504 minecraft:blackstone
setblock 437 88 464 minecraft:blackstone
setblock 438 88 464 minecraft:polished_blackstone_bricks
setblock 438 88 504 minecraft:polished_blackstone_bricks
fill 439 88 464 439 91 464 minecraft:blackstone
setblock 439 88 503 minecraft:polished_blackstone_bricks
fill 439 88 504 439 91 504 minecraft:blackstone
fill 440 88 503 440 91 503 minecraft:blackstone
setblock 442 88 466 minecraft:light[level=11]
setblock 442 88 474 minecraft:light[level=11]
setblock 442 88 482 minecraft:light[level=11]
setblock 442 88 490 minecraft:light[level=11]
setblock 442 88 498 minecraft:light[level=11]
setblock 443 88 464 minecraft:polished_blackstone_bricks
setblock 443 88 504 minecraft:polished_blackstone_bricks
fill 444 88 464 445 90 464 minecraft:blackstone
fill 444 88 504 444 91 504 minecraft:blackstone
setblock 450 88 466 minecraft:light[level=11]
setblock 450 88 474 minecraft:light[level=11]
setblock 450 88 482 minecraft:light[level=11]
setblock 450 88 490 minecraft:light[level=11]
setblock 450 88 498 minecraft:light[level=11]
fill 451 88 464 452 88 464 minecraft:blackstone
fill 451 88 504 452 88 504 minecraft:blackstone
setblock 453 88 464 minecraft:polished_blackstone_bricks
setblock 453 88 504 minecraft:polished_blackstone_bricks
fill 454 88 464 454 91 464 minecraft:blackstone
setblock 454 88 503 minecraft:polished_blackstone_bricks
fill 454 88 504 454 91 504 minecraft:blackstone
fill 455 88 465 456 88 465 minecraft:blackstone
setblock 455 88 502 minecraft:polished_blackstone_bricks
fill 455 88 503 455 91 503 minecraft:blackstone
fill 456 88 502 459 88 502 minecraft:blackstone
setblock 457 88 465 minecraft:polished_blackstone_bricks
fill 457 88 501 460 88 501 minecraft:blackstone
setblock 458 88 464 minecraft:polished_blackstone_bricks
fill 458 88 465 458 91 465 minecraft:blackstone
setblock 458 88 466 minecraft:light[level=11]
setblock 458 88 474 minecraft:light[level=11]
setblock 458 88 482 minecraft:light[level=11]
setblock 458 88 490 minecraft:light[level=11]
setblock 458 88 498 minecraft:light[level=11]
setblock 458 88 503 minecraft:blackstone
setblock 458 88 504 minecraft:polished_blackstone_bricks
fill 459 88 464 459 91 464 minecraft:blackstone
fill 459 88 472 459 89 472 minecraft:polished_blackstone_bricks
fill 459 88 474 459 89 474 minecraft:polished_blackstone_bricks
setblock 459 88 503 minecraft:polished_blackstone_bricks
fill 459 88 504 459 91 504 minecraft:blackstone
setblock 460 88 502 minecraft:polished_blackstone_bricks
fill 460 88 503 460 91 503 minecraft:blackstone
setblock 461 88 496 minecraft:polished_blackstone_bricks
fill 461 88 497 461 91 497 minecraft:blackstone
setblock 461 88 501 minecraft:polished_blackstone_bricks
fill 461 88 502 461 91 502 minecraft:blackstone
setblock 462 88 495 minecraft:polished_blackstone_bricks
fill 462 88 496 462 91 496 minecraft:blackstone
setblock 462 88 500 minecraft:polished_blackstone_bricks
fill 462 88 501 462 91 501 minecraft:blackstone
setblock 463 88 464 minecraft:polished_blackstone_bricks
setblock 463 88 474 minecraft:polished_blackstone_bricks
fill 463 88 475 463 89 475 minecraft:blackstone
setblock 463 88 479 minecraft:polished_blackstone_bricks
setblock 463 88 494 minecraft:polished_blackstone_bricks
fill 463 88 495 463 91 495 minecraft:blackstone
setblock 463 88 499 minecraft:polished_blackstone_bricks
fill 463 88 500 463 91 500 minecraft:blackstone
setblock 463 88 504 minecraft:polished_blackstone_bricks
fill 464 88 464 464 91 464 minecraft:blackstone
setblock 464 88 473 minecraft:polished_blackstone_bricks
fill 464 88 474 464 90 474 minecraft:blackstone
setblock 464 88 478 minecraft:polished_blackstone_bricks
fill 464 88 479 464 91 479 minecraft:blackstone
fill 464 88 481 464 88 482 minecraft:blackstone
fill 464 88 489 464 89 489 minecraft:blackstone
setblock 464 88 493 minecraft:polished_blackstone_bricks
fill 464 88 494 464 91 494 minecraft:blackstone
setblock 464 88 498 minecraft:polished_blackstone_bricks
fill 464 88 499 464 91 499 minecraft:blackstone
setblock 464 88 503 minecraft:polished_blackstone_bricks
fill 464 88 504 464 91 504 minecraft:blackstone
fill 424 89 473 424 90 473 minecraft:blackstone
setblock 424 89 477 minecraft:polished_blackstone_bricks
fill 424 89 478 424 89 481 minecraft:blackstone
setblock 424 89 482 minecraft:polished_blackstone_bricks
fill 424 89 483 424 92 483 minecraft:blackstone
setblock 424 89 487 minecraft:polished_blackstone_bricks
fill 424 89 488 424 92 488 minecraft:blackstone
setblock 424 89 492 minecraft:polished_blackstone_bricks
fill 424 89 493 424 92 493 minecraft:blackstone
setblock 424 89 497 minecraft:polished_blackstone_bricks
fill 424 89 498 424 92 498 minecraft:blackstone
setblock 424 89 502 minecraft:polished_blackstone_bricks
fill 424 89 503 424 92 503 minecraft:blackstone
setblock 425 89 476 minecraft:polished_blackstone_bricks
fill 425 89 477 425 91 477 minecraft:blackstone
setblock 425 89 481 minecraft:polished_blackstone_bricks
fill 425 89 482 425 92 482 minecraft:blackstone
setblock 425 89 492 minecraft:blackstone
setblock 425 89 496 minecraft:polished_blackstone_bricks
fill 425 89 497 425 92 497 minecraft:blackstone
setblock 425 89 501 minecraft:polished_blackstone_bricks
fill 425 89 502 425 92 502 minecraft:blackstone
setblock 426 89 504 minecraft:blackstone
fill 434 89 504 436 89 504 minecraft:blackstone
fill 435 89 464 436 89 464 minecraft:blackstone
fill 436 89 503 437 89 503 minecraft:blackstone
setblock 437 89 464 minecraft:polished_blackstone_bricks
setblock 437 89 504 minecraft:polished_blackstone_bricks
fill 438 89 464 438 92 464 minecraft:blackstone
setblock 438 89 503 minecraft:polished_blackstone_bricks
fill 438 89 504 438 92 504 minecraft:blackstone
fill 439 89 465 440 89 465 minecraft:blackstone
fill 439 89 503 439 92 503 minecraft:blackstone
fill 440 89 504 441 89 504 minecraft:blackstone
setblock 441 89 465 minecraft:polished_blackstone_bricks
fill 441 89 503 442 89 503 minecraft:blackstone
setblock 442 89 464 minecraft:polished_blackstone_bricks
setblock 442 89 504 minecraft:polished_blackstone_bricks
fill 443 89 464 443 92 464 minecraft:blackstone
fill 443 89 504 443 92 504 minecraft:blackstone
fill 445 89 504 445 90 504 minecraft:blackstone
setblock 446 89 464 minecraft:blackstone
setblock 447 89 464 minecraft:polished_blackstone_bricks
fill 448 89 464 451 89 464 minecraft:blackstone
fill 449 89 504 451 89 504 minecraft:blackstone
setblock 452 89 464 minecraft:polished_blackstone_bricks
setblock 452 89 503 minecraft:blackstone
setblock 452 89 504 minecraft:polished_blackstone_bricks
fill 453 89 464 453 92 464 minecraft:blackstone
setblock 453 89 503 minecraft:polished_blackstone_bricks
fill 453 89 504 453 92 504 minecraft:blackstone
fill 454 89 465 455 89 465 minecraft:blackstone
setblock 454 89 502 minecraft:polished_blackstone_bricks
fill 454 89 503 454 92 503 minecraft:blackstone
fill 455 89 502 458 89 502 minecraft:blackstone
setblock 456 89 465 minecraft:polished_blackstone_bricks
fill 456 89 501 459 89 501 minecraft:blackstone
setblock 457 89 464 minecraft:polished_blackstone_bricks
fill 457 89 465 457 92 465 minecraft:blackstone
setblock 457 89 504 minecraft:polished_blackstone_bricks
fill 458 89 464 458 92 464 minecraft:blackstone
setblock 458 89 503 minecraft:polished_blackstone_bricks
fill 458 89 504 458 92 504 minecraft:blackstone
setblock 459 89 502 minecraft:polished_blackstone_bricks
fill 459 89 503 459 92 503 minecraft:blackstone
setblock 460 89 500 minecraft:blackstone
setblock 460 89 501 minecraft:polished_blackstone_bricks
fill 460 89 502 460 92 502 minecraft:blackstone
setblock 461 89 465 minecraft:polished_blackstone_bricks
fill 461 89 496 461 90 496 minecraft:blackstone
setblock 461 89 500 minecraft:polished_blackstone_bricks
fill 461 89 501 461 92 501 minecraft:blackstone
setblock 462 89 464 minecraft:polished_blackstone_bricks
setblock 462 89 494 minecraft:polished_blackstone_bricks
fill 462 89 495 462 91 495 minecraft:blackstone
setblock 462 89 499 minecraft:polished_blackstone_bricks
fill 462 89 500 462 92 500 minecraft:blackstone
setblock 462 89 504 minecraft:polished_blackstone_bricks
fill 463 89 464 463 92 464 minecraft:blackstone
setblock 463 89 474 minecraft:blackstone
setblock 463 89 478 minecraft:polished_blackstone_bricks
fill 463 89 479 463 91 480 minecraft:blackstone
setblock 463 89 493 minecraft:polished_blackstone_bricks
fill 463 89 494 463 92 494 minecraft:blackstone
setblock 463 89 498 minecraft:polished_blackstone_bricks
fill 463 89 499 463 92 499 minecraft:blackstone
setblock 463 89 503 minecraft:polished_blackstone_bricks
fill 463 89 504 463 92 504 minecraft:blackstone
setblock 464 89 472 minecraft:polished_blackstone_bricks
fill 464 89 473 464 90 473 minecraft:blackstone
setblock 464 89 477 minecraft:polished_blackstone_bricks
fill 464 89 478 464 92 478 minecraft:blackstone
setblock 464 89 481 minecraft:blackstone
setblock 464 89 482 minecraft:polished_blackstone_bricks
fill 464 89 483 464 92 483 minecraft:blackstone
setblock 464 89 492 minecraft:polished_blackstone_bricks
fill 464 89 493 464 92 493 minecraft:blackstone
setblock 464 89 497 minecraft:polished_blackstone_bricks
fill 464 89 498 464 92 498 minecraft:blackstone
setblock 464 89 502 minecraft:polished_blackstone_bricks
fill 464 89 503 464 92 503 minecraft:blackstone
setblock 424 90 476 minecraft:polished_blackstone_bricks
fill 424 90 477 424 90 480 minecraft:blackstone
setblock 424 90 481 minecraft:polished_blackstone_bricks
fill 424 90 482 424 93 482 minecraft:blackstone
setblock 424 90 486 minecraft:polished_blackstone_bricks
fill 424 90 487 424 93 487 minecraft:blackstone
setblock 424 90 491 minecraft:polished_blackstone_bricks
fill 424 90 492 424 92 492 minecraft:blackstone
setblock 424 90 496 minecraft:polished_blackstone_bricks
fill 424 90 497 424 93 497 minecraft:blackstone
setblock 424 90 501 minecraft:polished_blackstone_bricks
fill 424 90 502 424 93 502 minecraft:blackstone
setblock 425 90 476 minecraft:blackstone
fill 425 90 478 425 90 479 minecraft:blackstone
setblock 425 90 480 minecraft:polished_blackstone_bricks
fill 425 90 481 425 93 481 minecraft:blackstone
fill 425 90 483 425 91 483 minecraft:blackstone
setblock 425 90 495 minecraft:polished_blackstone_bricks
fill 425 90 496 425 91 496 minecraft:blackstone
setblock 425 90 500 minecraft:polished_blackstone_bricks
fill 425 90 501 425 92 501 minecraft:blackstone
setblock 426 90 504 minecraft:polished_blackstone_bricks
fill 432 90 504 435 90 504 minecraft:blackstone
fill 434 90 464 435 90 464 minecraft:blackstone
fill 434 90 503 436 90 503 minecraft:blackstone
setblock 436 90 464 minecraft:polished_blackstone_bricks
setblock 436 90 504 minecraft:polished_blackstone_bricks
fill 437 90 464 437 92 465 minecraft:blackstone
setblock 437 90 503 minecraft:polished_blackstone_bricks
fill 437 90 504 437 93 504 minecraft:blackstone
fill 438 90 465 439 90 465 minecraft:blackstone
fill 438 90 503 438 93 503 minecraft:blackstone
setblock 440 90 465 minecraft:polished_blackstone_bricks
setblock 440 90 504 minecraft:blackstone
setblock 441 90 464 minecraft:polished_blackstone_bricks
fill 441 90 465 442 91 465 minecraft:blackstone
setblock 441 90 503 minecraft:blackstone
setblock 441 90 504 minecraft:polished_blackstone_bricks
fill 442 90 464 442 93 464 minecraft:blackstone
setblock 442 90 503 minecraft:polished_blackstone_bricks
fill 442 90 504 442 93 504 minecraft:blackstone
setblock 446 90 464 minecraft:polished_blackstone_bricks
setblock 446 90 504 minecraft:polished_blackstone_bricks
fill 447 90 464 450 90 464 minecraft:blackstone
fill 447 90 504 450 90 504 minecraft:blackstone
setblock 451 90 464 minecraft:polished_blackstone_bricks
setblock 451 90 503 minecraft:blackstone
setblock 451 90 504 minecraft:polished_blackstone_bricks
fill 452 90 464 452 93 464 minecraft:blackstone
setblock 452 90 503 minecraft:polished_blackstone_bricks
fill 452 90 504 452 93 504 minecraft:blackstone
fill 453 90 465 454 90 465 minecraft:blackstone
setblock 453 90 502 minecraft:polished_blackstone_bricks
fill 453 90 503 453 93 503 minecraft:blackstone
fill 454 90 502 457 90 502 minecraft:blackstone
setblock 455 90 465 minecraft:polished_blackstone_bricks
fill 455 90 501 458 90 501 minecraft:blackstone
setblock 456 90 464 minecraft:polished_blackstone_bricks
fill 456 90 465 456 93 465 minecraft:blackstone
setblock 456 90 504 minecraft:polished_blackstone_bricks
fill 457 90 464 457 93 464 minecraft:blackstone
setblock 457 90 503 minecraft:polished_blackstone_bricks
fill 457 90 504 457 93 504 minecraft:blackstone
fill 458 90 500 459 90 500 minecraft:blackstone
setblock 458 90 502 minecraft:polished_blackstone_bricks
fill 458 90 503 458 93 503 minecraft:blackstone
fill 459 90 485 459 91 485 minecraft:polished_blackstone_bricks
fill 459 90 487 459 91 487 minecraft:polished_blackstone_bricks
setblock 459 90 501 minecraft:polished_blackstone_bricks
fill 459 90 502 459 93 502 minecraft:blackstone
setblock 460 90 465 minecraft:polished_blackstone_bricks
setblock 460 90 499 minecraft:blackstone
setblock 460 90 500 minecraft:polished_blackstone_bricks
fill 460 90 501 460 93 501 minecraft:blackstone
setblock 461 90 464 minecraft:polished_blackstone_bricks
fill 461 90 465 461 91 465 minecraft:blackstone
setblock 461 90 499 minecraft:polished_blackstone_bricks
fill 461 90 500 461 93 500 minecraft:blackstone
setblock 461 90 504 minecraft:polished_blackstone_bricks
fill 462 90 464 462 93 464 minecraft:blackstone
setblock 462 90 494 minecraft:blackstone
setblock 462 90 498 minecraft:polished_blackstone_bricks
fill 462 90 499 462 93 499 minecraft:blackstone
setblock 462 90 503 minecraft:polished_blackstone_bricks
fill 462 90 504 462 93 504 minecraft:blackstone
setblock 463 90 477 minecraft:polished_blackstone_bricks
fill 463 90 478 463 91 478 minecraft:blackstone
setblock 463 90 492 minecraft:polished_blackstone_bricks
fill 463 90 493 463 91 493 minecraft:blackstone
setblock 463 90 497 minecraft:polished_blackstone_bricks
fill 463 90 498 463 93 498 minecraft:blackstone
setblock 463 90 502 minecraft:polished_blackstone_bricks
fill 463 90 503 463 93 503 minecraft:blackstone
setblock 464 90 476 minecraft:polished_blackstone_bricks
fill 464 90 477 464 92 477 minecraft:blackstone
setblock 464 90 481 minecraft:polished_blackstone_bricks
fill 464 90 482 464 93 482 minecraft:blackstone
fill 464 90 484 464 91 484 minecraft:blackstone
setblock 464 90 491 minecraft:polished_blackstone_bricks
fill 464 90 492 464 92 492 minecraft:blackstone
setblock 464 90 496 minecraft:polished_blackstone_bricks
fill 464 90 497 464 93 497 minecraft:blackstone
setblock 464 90 501 minecraft:polished_blackstone_bricks
fill 464 90 502 464 93 502 minecraft:blackstone
setblock 424 91 475 minecraft:polished_blackstone_bricks
fill 424 91 476 424 91 479 minecraft:blackstone
setblock 424 91 480 minecraft:polished_blackstone_bricks
fill 424 91 481 424 94 481 minecraft:blackstone
setblock 424 91 485 minecraft:polished_blackstone_bricks
fill 424 91 486 424 94 486 minecraft:blackstone
setblock 424 91 490 minecraft:polished_blackstone_bricks
fill 424 91 491 424 92 491 minecraft:blackstone
setblock 424 91 495 minecraft:polished_blackstone_bricks
fill 424 91 496 424 93 496 minecraft:blackstone
setblock 424 91 500 minecraft:polished_blackstone_bricks
fill 424 91 501 424 94 501 minecraft:blackstone
setblock 425 91 478 minecraft:blackstone
setblock 425 91 479 minecraft:polished_blackstone_bricks
fill 425 91 480 425 94 480 minecraft:blackstone
setblock 425 91 484 minecraft:polished_blackstone_bricks
setblock 425 91 494 minecraft:polished_blackstone_bricks
setblock 425 91 495 minecraft:blackstone
setblock 425 91 499 minecraft:polished_blackstone_bricks
fill 425 91 500 425 92 500 minecraft:blackstone
setblock 425 91 504 minecraft:polished_blackstone_bricks
fill 426 91 504 426 92 504 minecraft:blackstone
setblock 430 91 504 minecraft:polished_blackstone_bricks
fill 431 91 504 434 91 504 minecraft:blackstone
fill 433 91 464 434 91 464 minecraft:blackstone
fill 433 91 503 435 91 503 minecraft:blackstone
setblock 435 91 464 minecraft:polished_blackstone_bricks
setblock 435 91 504 minecraft:polished_blackstone_bricks
fill 436 91 464 436 93 465 minecraft:blackstone
setblock 436 91 503 minecraft:polished_blackstone_bricks
fill 436 91 504 436 94 504 minecraft:blackstone
setblock 437 91 502 minecraft:polished_blackstone_bricks
fill 437 91 503 437 94 503 minecraft:blackstone
setblock 438 91 465 minecraft:blackstone
setblock 438 91 502 minecraft:blackstone
setblock 439 91 465 minecraft:polished_blackstone_bricks
setblock 440 91 464 minecraft:polished_blackstone_bricks
fill 440 91 465 440 94 465 minecraft:blackstone
setblock 440 91 504 minecraft:polished_blackstone_bricks
fill 441 91 464 441 94 464 minecraft:blackstone
setblock 441 91 503 minecraft:polished_blackstone_bricks
fill 441 91 504 441 94 504 minecraft:blackstone
fill 442 91 503 442 92 503 minecraft:blackstone
setblock 444 91 464 minecraft:blackstone
fill 444 91 466 448 92 470 minecraft:blackstone
setblock 445 91 464 minecraft:polished_blackstone_bricks
setblock 445 91 504 minecraft:polished_blackstone_bricks
fill 446 91 464 446 91 465 minecraft:blackstone
fill 446 91 504 449 91 504 minecraft:blackstone
fill 447 91 464 449 91 464 minecraft:blackstone
setblock 450 91 464 minecraft:polished_blackstone_bricks
setblock 450 91 503 minecraft:blackstone
setblock 450 91 504 minecraft:polished_blackstone_bricks
fill 451 91 464 451 94 464 minecraft:blackstone
setblock 451 91 503 minecraft:polished_blackstone_bricks
fill 451 91 504 451 94 504 minecraft:blackstone
fill 452 91 465 453 91 465 minecraft:blackstone
setblock 452 91 502 minecraft:polished_blackstone_bricks
fill 452 91 503 452 94 503 minecraft:blackstone
fill 453 91 502 456 91 502 minecraft:blackstone
setblock 454 91 465 minecraft:polished_blackstone_bricks
fill 454 91 501 457 91 501 minecraft:blackstone
setblock 455 91 464 minecraft:polished_blackstone_bricks
fill 455 91 465 455 94 465 minecraft:blackstone
setblock 455 91 504 minecraft:polished_blackstone_bricks
fill 456 91 464 456 94 464 minecraft:blackstone
setblock 456 91 503 minecraft:polished_blackstone_bricks
fill 456 91 504 456 94 504 minecraft:blackstone
fill 457 91 500 458 91 500 minecraft:blackstone
setblock 457 91 502 minecraft:polished_blackstone_bricks
fill 457 91 503 457 94 503 minecraft:blackstone
setblock 458 91 501 minecraft:polished_blackstone_bricks
fill 458 91 502 458 94 502 minecraft:blackstone
setblock 459 91 465 minecraft:polished_blackstone_bricks
setblock 459 91 500 minecraft:polished_blackstone_bricks
fill 459 91 501 459 94 501 minecraft:blackstone
setblock 460 91 464 minecraft:polished_blackstone_bricks
fill 460 91 465 460 93 465 minecraft:blackstone
setblock 460 91 500 minecraft:blackstone
setblock 460 91 504 minecraft:polished_blackstone_bricks
fill 461 91 464 461 94 464 minecraft:blackstone
setblock 461 91 498 minecraft:polished_blackstone_bricks
fill 461 91 499 461 92 499 minecraft:blackstone
setblock 461 91 503 minecraft:polished_blackstone_bricks
fill 461 91 504 461 94 504 minecraft:blackstone
setblock 462 91 497 minecraft:polished_blackstone_bricks
fill 462 91 498 462 93 498 minecraft:blackstone
setblock 462 91 502 minecraft:polished_blackstone_bricks
fill 462 91 503 462 94 503 minecraft:blackstone
setblock 463 91 496 minecraft:polished_blackstone_bricks
fill 463 91 497 463 94 497 minecraft:blackstone
setblock 463 91 501 minecraft:polished_blackstone_bricks
fill 463 91 502 463 94 502 minecraft:blackstone
setblock 464 91 475 minecraft:polished_blackstone_bricks
setblock 464 91 476 minecraft:blackstone
setblock 464 91 480 minecraft:polished_blackstone_bricks
fill 464 91 481 464 94 481 minecraft:blackstone
setblock 464 91 485 minecraft:polished_blackstone_bricks
setblock 464 91 491 minecraft:blackstone
setblock 464 91 495 minecraft:polished_blackstone_bricks
fill 464 91 496 464 94 496 minecraft:blackstone
setblock 464 91 500 minecraft:polished_blackstone_bricks
fill 464 91 501 464 94 501 minecraft:blackstone
fill 424 92 475 424 92 478 minecraft:blackstone
setblock 424 92 479 minecraft:polished_blackstone_bricks
fill 424 92 480 424 95 480 minecraft:blackstone
setblock 424 92 484 minecraft:polished_blackstone_bricks
fill 424 92 485 424 95 485 minecraft:blackstone
setblock 424 92 489 minecraft:polished_blackstone_bricks
setblock 424 92 490 minecraft:blackstone
setblock 424 92 494 minecraft:polished_blackstone_bricks
fill 424 92 495 424 93 495 minecraft:blackstone
setblock 424 92 499 minecraft:polished_blackstone_bricks
fill 424 92 500 424 95 500 minecraft:blackstone
setblock 424 92 504 minecraft:polished_blackstone_bricks
setblock 425 92 478 minecraft:polished_blackstone_bricks
fill 425 92 479 425 93 479 minecraft:blackstone
setblock 425 92 483 minecraft:polished_blackstone_bricks
fill 425 92 484 425 95 484 minecraft:blackstone
setblock 425 92 498 minecraft:polished_blackstone_bricks
setblock 425 92 499 minecraft:blackstone
fill 425 92 504 425 93 504 minecraft:blackstone
setblock 429 92 504 minecraft:polished_blackstone_bricks
fill 430 92 504 433 92 504 minecraft:blackstone
setblock 433 92 464 minecraft:blackstone
fill 433 92 503 434 92 503 minecraft:blackstone
setblock 434 92 464 minecraft:polished_blackstone_bricks
setblock 434 92 504 minecraft:polished_blackstone_bricks
fill 435 92 464 435 95 464 minecraft:blackstone
setblock 435 92 503 minecraft:polished_blackstone_bricks
fill 435 92 504 435 95 504 minecraft:blackstone
setblock 436 92 502 minecraft:polished_blackstone_bricks
fill 436 92 503 436 95 503 minecraft:blackstone
setblock 437 92 502 minecraft:blackstone
setblock 438 92 465 minecraft:polished_blackstone_bricks
setblock 439 92 464 minecraft:polished_blackstone_bricks
fill 439 92 465 439 95 465 minecraft:blackstone
setblock 439 92 504 minecraft:polished_blackstone_bricks
fill 440 92 464 440 95 464 minecraft:blackstone
setblock 440 92 503 minecraft:polished_blackstone_bricks
fill 440 92 504 440 95 504 minecraft:blackstone
fill 441 92 465 441 93 465 minecraft:blackstone
fill 441 92 503 441 93 503 minecraft:blackstone
setblock 444 92 464 minecraft:polished_blackstone_bricks
setblock 444 92 504 minecraft:polished_blackstone_bricks
fill 445 92 464 448 92 464 minecraft:blackstone
fill 445 92 504 448 92 504 minecraft:blackstone
setblock 449 92 464 minecraft:polished_blackstone_bricks
setblock 449 92 503 minecraft:blackstone
setblock 449 92 504 minecraft:polished_blackstone_bricks
fill 450 92 464 450 95 464 minecraft:blackstone
setblock 450 92 503 minecraft:polished_blackstone_bricks
fill 450 92 504 450 95 504 minecraft:blackstone
fill 451 92 465 452 92 465 minecraft:blackstone
setblock 451 92 502 minecraft:polished_blackstone_bricks
fill 451 92 503 451 95 503 minecraft:blackstone
fill 452 92 502 455 92 502 minecraft:blackstone
setblock 453 92 465 minecraft:polished_blackstone_bricks
setblock 454 92 464 minecraft:polished_blackstone_bricks
fill 454 92 465 454 95 465 minecraft:blackstone
fill 454 92 501 456 92 501 minecraft:blackstone
setblock 454 92 504 minecraft:polished_blackstone_bricks
fill 455 92 464 455 95 464 minecraft:blackstone
setblock 455 92 503 minecraft:polished_blackstone_bricks
fill 455 92 504 455 95 504 minecraft:blackstone
fill 456 92 493 456 93 493 minecraft:light_blue_stained_glass
setblock 456 92 502 minecraft:polished_blackstone_bricks
fill 456 92 503 456 95 503 minecraft:blackstone
fill 457 92 471 461 93 475 minecraft:blackstone
setblock 457 92 501 minecraft:polished_blackstone_bricks
fill 457 92 502 457 95 502 minecraft:blackstone
setblock 458 92 465 minecraft:polished_blackstone_bricks
setblock 458 92 500 minecraft:polished_blackstone_bricks
fill 458 92 501 458 95 501 minecraft:blackstone
setblock 459 92 464 minecraft:polished_blackstone_bricks
fill 459 92 465 459 94 465 minecraft:blackstone
setblock 459 92 504 minecraft:polished_blackstone_bricks
fill 460 92 464 460 95 464 minecraft:blackstone
setblock 460 92 503 minecraft:polished_blackstone_bricks
fill 460 92 504 460 95 504 minecraft:blackstone
setblock 461 92 498 minecraft:blackstone
setblock 461 92 502 minecraft:polished_blackstone_bricks
fill 461 92 503 461 95 503 minecraft:blackstone
fill 462 92 473 463 92 473 minecraft:blackstone
setblock 462 92 496 minecraft:polished_blackstone_bricks
setblock 462 92 497 minecraft:blackstone
setblock 462 92 501 minecraft:polished_blackstone_bricks
fill 462 92 502 462 94 502 minecraft:blackstone
setblock 463 92 495 minecraft:polished_blackstone_bricks
fill 463 92 496 463 93 496 minecraft:blackstone
setblock 463 92 500 minecraft:polished_blackstone_bricks
fill 463 92 501 463 95 501 minecraft:blackstone
setblock 464 92 479 minecraft:polished_blackstone_bricks
fill 464 92 480 464 94 480 minecraft:blackstone
setblock 464 92 484 minecraft:polished_blackstone_bricks
fill 464 92 485 464 94 485 minecraft:blackstone
setblock 464 92 494 minecraft:polished_blackstone_bricks
fill 464 92 495 464 94 495 minecraft:blackstone
setblock 464 92 499 minecraft:polished_blackstone_bricks
fill 464 92 500 464 95 500 minecraft:blackstone
setblock 464 92 504 minecraft:polished_blackstone_bricks
fill 424 93 476 424 93 477 minecraft:blackstone
setblock 424 93 478 minecraft:polished_blackstone_bricks
fill 424 93 479 424 96 479 minecraft:blackstone
setblock 424 93 483 minecraft:polished_blackstone_bricks
fill 424 93 484 424 96 484 minecraft:blackstone
setblock 424 93 488 minecraft:polished_blackstone_bricks
setblock 424 93 489 minecraft:blackstone
setblock 424 93 493 minecraft:polished_blackstone_bricks
setblock 424 93 494 minecraft:blackstone
setblock 424 93 498 minecraft:polished_blackstone_bricks
fill 424 93 499 424 94 499 minecraft:blackstone
setblock 424 93 503 minecraft:polished_blackstone_bricks
fill 424 93 504 424 94 504 minecraft:blackstone
setblock 425 93 482 minecraft:polished_blackstone_bricks
fill 425 93 483 425 96 483 minecraft:blackstone
fill 429 93 504 432 93 504 minecraft:blackstone
setblock 432 93 464 minecraft:blackstone
fill 432 93 503 433 93 503 minecraft:blackstone
setblock 433 93 464 minecraft:polished_blackstone_bricks
setblock 433 93 504 minecraft:polished_blackstone_bricks
fill 434 93 464 434 96 464 minecraft:blackstone
setblock 434 93 503 minecraft:polished_blackstone_bricks
fill 434 93 504 434 96 504 minecraft:blackstone
fill 435 93 465 435 94 465 minecraft:blackstone
fill 435 93 503 435 96 503 minecraft:blackstone
setblock 437 93 464 minecraft:blackstone
setblock 437 93 465 minecraft:polished_blackstone_bricks
setblock 438 93 464 minecraft:polished_blackstone_bricks
fill 438 93 465 438 96 465 minecraft:blackstone
setblock 438 93 504 minecraft:polished_blackstone_bricks
fill 439 93 464 439 96 464 minecraft:blackstone
setblock 439 93 503 minecraft:polished_blackstone_bricks
fill 439 93 504 439 96 504 minecraft:blackstone
fill 440 93 503 440 94 503 minecraft:blackstone
setblock 443 93 464 minecraft:polished_blackstone_bricks
setblock 443 93 504 minecraft:polished_blackstone_bricks
fill 444 93 464 447 93 464 minecraft:blackstone
fill 444 93 504 447 93 504 minecraft:blackstone
fill 445 93 468 447 97 468 minecraft:polished_blackstone_bricks
setblock 448 93 464 minecraft:polished_blackstone_bricks
setblock 448 93 504 minecraft:polished_blackstone_bricks
fill 449 93 464 449 96 464 minecraft:blackstone
setblock 449 93 503 minecraft:polished_blackstone_bricks
fill 449 93 504 449 96 504 minecraft:blackstone
fill 450 93 503 450 96 503 minecraft:blackstone
setblock 451 93 465 minecraft:blackstone
fill 451 93 502 454 93 502 minecraft:blackstone
setblock 452 93 465 minecraft:polished_blackstone_bricks
setblock 453 93 464 minecraft:polished_blackstone_bricks
fill 453 93 465 453 96 465 minecraft:blackstone
setblock 453 93 504 minecraft:polished_blackstone_bricks
fill 454 93 464 454 96 464 minecraft:blackstone
fill 454 93 501 455 93 501 minecraft:blackstone
setblock 454 93 503 minecraft:polished_blackstone_bricks
fill 454 93 504 454 96 504 minecraft:blackstone
setblock 455 93 502 minecraft:polished_blackstone_bricks
fill 455 93 503 455 96 503 minecraft:blackstone
setblock 456 93 501 minecraft:polished_blackstone_bricks
fill 456 93 502 456 96 502 minecraft:blackstone
setblock 457 93 465 minecraft:polished_blackstone_bricks
fill 457 93 501 457 95 501 minecraft:blackstone
setblock 458 93 464 minecraft:polished_blackstone_bricks
fill 458 93 465 458 96 465 minecraft:blackstone
setblock 458 93 504 minecraft:polished_blackstone_bricks
fill 459 93 464 459 96 464 minecraft:blackstone
setblock 459 93 503 minecraft:polished_blackstone_bricks
fill 459 93 504 459 96 504 minecraft:blackstone
setblock 460 93 502 minecraft:polished_blackstone_bricks
fill 460 93 503 460 96 503 minecraft:blackstone
setblock 461 93 501 minecraft:polished_blackstone_bricks
fill 461 93 502 461 95 502 minecraft:blackstone
setblock 462 93 500 minecraft:polished_blackstone_bricks
fill 462 93 501 462 94 501 minecraft:blackstone
setblock 463 93 464 minecraft:polished_blackstone_bricks
setblock 463 93 499 minecraft:polished_blackstone_bricks
fill 463 93 500 463 95 500 minecraft:blackstone
setblock 463 93 504 minecraft:polished_blackstone_bricks
setblock 464 93 478 minecraft:polished_blackstone_bricks
setblock 464 93 479 minecraft:blackstone
setblock 464 93 483 minecraft:polished_blackstone_bricks
fill 464 93 484 464 96 484 minecraft:blackstone
setblock 464 93 493 minecraft:polished_blackstone_bricks
setblock 464 93 494 minecraft:blackstone
setblock 464 93 498 minecraft:polished_blackstone_bricks
fill 464 93 499 464 96 499 minecraft:blackstone
setblock 464 93 503 minecraft:polished_blackstone_bricks
fill 464 93 504 464 96 504 minecraft:blackstone
setblock 424 94 477 minecraft:polished_blackstone_bricks
fill 424 94 478 424 95 478 minecraft:blackstone
setblock 424 94 482 minecraft:polished_blackstone_bricks
fill 424 94 483 424 97 483 minecraft:blackstone
setblock 424 94 487 minecraft:polished_blackstone_bricks
fill 424 94 488 424 97 488 minecraft:blackstone
setblock 424 94 497 minecraft:polished_blackstone_bricks
setblock 424 94 498 minecraft:blackstone
setblock 424 94 502 minecraft:polished_blackstone_bricks
fill 424 94 503 424 95 503 minecraft:blackstone
setblock 425 94 481 minecraft:polished_blackstone_bricks
fill 425 94 482 425 97 482 minecraft:blackstone
fill 429 94 504 431 94 504 minecraft:blackstone
setblock 431 94 464 minecraft:blackstone
setblock 432 94 464 minecraft:polished_blackstone_bricks
setblock 432 94 503 minecraft:blackstone
setblock 432 94 504 minecraft:polished_blackstone_bricks
fill 433 94 464 433 97 464 minecraft:blackstone
setblock 433 94 503 minecraft:polished_blackstone_bricks
fill 433 94 504 433 97 504 minecraft:blackstone
fill 434 94 465 434 95 465 minecraft:blackstone
fill 434 94 503 434 97 503 minecraft:blackstone
setblock 436 94 464 minecraft:blackstone
setblock 436 94 465 minecraft:polished_blackstone_bricks
setblock 437 94 464 minecraft:polished_blackstone_bricks
fill 437 94 465 437 97 465 minecraft:blackstone
setblock 437 94 504 minecraft:polished_blackstone_bricks
fill 438 94 464 438 97 464 minecraft:blackstone
setblock 438 94 503 minecraft:polished_blackstone_bricks
fill 438 94 504 438 97 504 minecraft:blackstone
fill 439 94 503 439 95 503 minecraft:blackstone
setblock 442 94 464 minecraft:polished_blackstone_bricks
setblock 442 94 504 minecraft:polished_blackstone_bricks
fill 443 94 464 446 94 464 minecraft:blackstone
fill 443 94 504 446 94 504 minecraft:blackstone
setblock 447 94 464 minecraft:polished_blackstone_bricks
setblock 447 94 504 minecraft:polished_blackstone_bricks
fill 448 94 464 448 97 464 minecraft:blackstone
setblock 448 94 503 minecraft:polished_blackstone_bricks
fill 448 94 504 448 97 504 minecraft:blackstone
fill 449 94 503 449 97 503 minecraft:blackstone
setblock 450 94 465 minecraft:blackstone
setblock 451 94 465 minecraft:polished_blackstone_bricks
fill 451 94 502 453 94 502 minecraft:blackstone
setblock 452 94 464 minecraft:polished_blackstone_bricks
fill 452 94 465 452 97 465 minecraft:blackstone
setblock 452 94 504 minecraft:polished_blackstone_bricks
fill 453 94 464 453 97 464 minecraft:blackstone
setblock 453 94 503 minecraft:polished_blackstone_bricks
fill 453 94 504 453 97 504 minecraft:blackstone
setblock 454 94 501 minecraft:blackstone
setblock 454 94 502 minecraft:polished_blackstone_bricks
fill 454 94 503 454 97 503 minecraft:blackstone
setblock 455 94 501 minecraft:polished_blackstone_bricks
fill 455 94 502 455 97 502 minecraft:blackstone
setblock 456 94 465 minecraft:polished_blackstone_bricks
fill 456 94 501 456 95 501 minecraft:blackstone
setblock 457 94 464 minecraft:polished_blackstone_bricks
fill 457 94 465 457 97 465 minecraft:blackstone
setblock 457 94 504 minecraft:polished_blackstone_bricks
fill 458 94 464 458 97 464 minecraft:blackstone
fill 458 94 473 460 98 473 minecraft:polished_blackstone_bricks
setblock 458 94 503 minecraft:polished_blackstone_bricks
fill 458 94 504 458 97 504 minecraft:blackstone
setblock 459 94 502 minecraft:polished_blackstone_bricks
fill 459 94 503 459 97 503 minecraft:blackstone
setblock 460 94 501 minecraft:polished_blackstone_bricks
fill 460 94 502 460 96 502 minecraft:blackstone
setblock 462 94 464 minecraft:polished_blackstone_bricks
setblock 462 94 500 minecraft:blackstone
setblock 462 94 504 minecraft:polished_blackstone_bricks
setblock 463 94 498 minecraft:polished_blackstone_bricks
fill 463 94 499 463 95 499 minecraft:blackstone
setblock 463 94 503 minecraft:polished_blackstone_bricks
fill 463 94 504 463 97 504 minecraft:blackstone
setblock 464 94 482 minecraft:polished_blackstone_bricks
fill 464 94 483 464 97 483 minecraft:blackstone
setblock 464 94 497 minecraft:polished_blackstone_bricks
fill 464 94 498 464 96 498 minecraft:blackstone
setblock 464 94 502 minecraft:polished_blackstone_bricks
fill 464 94 503 464 97 503 minecraft:blackstone
setblock 424 95 481 minecraft:polished_blackstone_bricks
fill 424 95 482 424 98 482 minecraft:blackstone
setblock 424 95 486 minecraft:polished_blackstone_bricks
fill 424 95 487 424 98 487 minecraft:blackstone
setblock 424 95 501 minecraft:polished_blackstone_bricks
setblock 424 95 502 minecraft:blackstone
setblock 425 95 481 minecraft:blackstone
fill 429 95 504 430 95 504 minecraft:blackstone
setblock 431 95 464 minecraft:polished_blackstone_bricks
setblock 431 95 504 minecraft:polished_blackstone_bricks
fill 432 95 464 432 98 464 minecraft:blackstone
fill 432 95 504 432 98 504 minecraft:blackstone
fill 433 95 503 433 97 503 minecraft:blackstone
setblock 435 95 465 minecraft:polished_blackstone_bricks
setblock 436 95 464 minecraft:polished_blackstone_bricks
fill 436 95 465 436 98 465 minecraft:blackstone
setblock 436 95 504 minecraft:polished_blackstone_bricks
fill 437 95 464 437 98 464 minecraft:blackstone
setblock 437 95 503 minecraft:polished_blackstone_bricks
fill 437 95 504 437 98 504 minecraft:blackstone
setblock 438 95 503 minecraft:blackstone
setblock 440 95 465 minecraft:polished_blackstone_bricks
setblock 441 95 464 minecraft:polished_blackstone_bricks
setblock 441 95 504 minecraft:polished_blackstone_bricks
fill 442 95 464 445 95 464 minecraft:blackstone
fill 442 95 504 445 95 504 minecraft:blackstone
setblock 446 95 464 minecraft:polished_blackstone_bricks
setblock 446 95 504 minecraft:polished_blackstone_bricks
fill 447 95 464 447 98 464 minecraft:blackstone
fill 447 95 504 447 98 504 minecraft:blackstone
fill 448 95 503 448 98 503 minecraft:blackstone
setblock 449 95 465 minecraft:blackstone
setblock 450 95 465 minecraft:polished_blackstone_bricks
setblock 451 95 464 minecraft:polished_blackstone_bricks
fill 451 95 465 451 98 465 minecraft:blackstone
fill 451 95 502 452 95 502 minecraft:blackstone
setblock 451 95 504 minecraft:polished_blackstone_bricks
fill 452 95 464 452 98 464 minecraft:blackstone
setblock 452 95 503 minecraft:polished_blackstone_bricks
fill 452 95 504 452 98 504 minecraft:blackstone
setblock 453 95 502 minecraft:polished_blackstone_bricks
fill 453 95 503 453 98 503 minecraft:blackstone
setblock 454 95 501 minecraft:polished_blackstone_bricks
fill 454 95 502 454 98 502 minecraft:blackstone
setblock 455 95 465 minecraft:polished_blackstone_bricks
setblock 455 95 501 minecraft:blackstone
setblock 456 95 464 minecraft:polished_blackstone_bricks
fill 456 95 465 456 98 465 minecraft:blackstone
setblock 456 95 504 minecraft:polished_blackstone_bricks
fill 457 95 464 457 98 464 minecraft:blackstone
setblock 457 95 503 minecraft:polished_blackstone_bricks
fill 457 95 504 457 98 504 minecraft:blackstone
setblock 458 95 502 minecraft:polished_blackstone_bricks
fill 458 95 503 458 98 503 minecraft:blackstone
fill 459 95 502 459 97 502 minecraft:blackstone
setblock 461 95 464 minecraft:polished_blackstone_bricks
setblock 461 95 504 minecraft:polished_blackstone_bricks
setblock 462 95 503 minecraft:polished_blackstone_bricks
fill 462 95 504 462 98 504 minecraft:blackstone
setblock 463 95 502 minecraft:polished_blackstone_bricks
fill 463 95 503 463 96 503 minecraft:blackstone
setblock 464 95 482 minecraft:blackstone
setblock 464 95 497 minecraft:blackstone
setblock 464 95 501 minecraft:polished_blackstone_bricks
fill 464 95 502 464 98 502 minecraft:blackstone
setblock 424 96 480 minecraft:polished_blackstone_bricks
fill 424 96 481 424 99 481 minecraft:blackstone
setblock 424 96 485 minecraft:polished_blackstone_bricks
fill 424 96 486 424 99 486 minecraft:blackstone
setblock 425 96 484 minecraft:polished_blackstone_bricks
setblock 426 96 466 minecraft:light[level=11]
setblock 426 96 474 minecraft:light[level=11]
setblock 426 96 482 minecraft:light[level=11]
setblock 426 96 490 minecraft:light[level=11]
setblock 426 96 498 minecraft:light[level=11]
setblock 429 96 504 minecraft:blackstone
setblock 430 96 464 minecraft:polished_blackstone_bricks
setblock 430 96 504 minecraft:polished_blackstone_bricks
fill 431 96 464 431 99 464 minecraft:blackstone
fill 431 96 504 431 99 504 minecraft:blackstone
setblock 433 96 465 minecraft:blackstone
setblock 434 96 465 minecraft:polished_blackstone_bricks
setblock 434 96 466 minecraft:light[level=11]
setblock 434 96 474 minecraft:light[level=11]
setblock 434 96 482 minecraft:light[level=11]
setblock 434 96 490 minecraft:light[level=11]
setblock 434 96 498 minecraft:light[level=11]
setblock 435 96 464 minecraft:polished_blackstone_bricks
fill 435 96 465 435 99 465 minecraft:blackstone
setblock 435 96 504 minecraft:polished_blackstone_bricks
fill 436 96 464 436 99 464 minecraft:blackstone
setblock 436 96 503 minecraft:polished_blackstone_bricks
fill 436 96 504 436 99 504 minecraft:blackstone
setblock 437 96 503 minecraft:blackstone
setblock 439 96 465 minecraft:polished_blackstone_bricks
setblock 440 96 464 minecraft:polished_blackstone_bricks
fill 440 96 465 440 99 465 minecraft:blackstone
setblock 440 96 504 minecraft:polished_blackstone_bricks
fill 441 96 464 444 96 464 minecraft:blackstone
fill 441 96 504 444 96 504 minecraft:blackstone
setblock 442 96 466 minecraft:light[level=11]
setblock 442 96 474 minecraft:light[level=11]
setblock 442 96 482 minecraft:light[level=11]
setblock 442 96 490 minecraft:light[level=11]
setblock 442 96 498 minecraft:light[level=11]
setblock 445 96 464 minecraft:polished_blackstone_bricks
setblock 445 96 504 minecraft:polished_blackstone_bricks
fill 446 96 464 446 99 464 minecraft:blackstone
fill 446 96 467 446 97 467 minecraft:polished_blackstone_bricks
fill 446 96 469 446 97 469 minecraft:polished_blackstone_bricks
fill 446 96 504 446 99 504 minecraft:blackstone
setblock 449 96 465 minecraft:polished_blackstone_bricks
setblock 450 96 464 minecraft:polished_blackstone_bricks
fill 450 96 465 450 99 465 minecraft:blackstone
setblock 450 96 466 minecraft:light[level=11]
setblock 450 96 474 minecraft:light[level=11]
setblock 450 96 482 minecraft:light[level=11]
setblock 450 96 490 minecraft:light[level=11]
setblock 450 96 498 minecraft:light[level=11]
setblock 450 96 504 minecraft:polished_blackstone_bricks
fill 451 96 464 451 99 464 minecraft:blackstone
setblock 451 96 502 minecraft:blackstone
setblock 451 96 503 minecraft:polished_blackstone_bricks
fill 451 96 504 451 99 504 minecraft:blackstone
setblock 452 96 502 minecraft:polished_blackstone_bricks
fill 452 96 503 452 99 503 minecraft:blackstone
fill 453 96 502 453 99 502 minecraft:blackstone
setblock 454 96 465 minecraft:polished_blackstone_bricks
setblock 455 96 464 minecraft:polished_blackstone_bricks
fill 455 96 465 455 99 465 minecraft:blackstone
setblock 455 96 504 minecraft:polished_blackstone_bricks
fill 456 96 464 456 99 464 minecraft:blackstone
setblock 456 96 503 minecraft:polished_blackstone_bricks
fill 456 96 504 456 99 504 minecraft:blackstone
setblock 457 96 502 minecraft:polished_blackstone_bricks
fill 457 96 503 457 99 503 minecraft:blackstone
setblock 458 96 466 minecraft:light[level=11]
setblock 458 96 474 minecraft:light[level=11]
setblock 458 96 482 minecraft:light[level=11]
setblock 458 96 490 minecraft:light[level=11]
setblock 458 96 498 minecraft:light[level=11]
fill 458 96 502 458 98 502 minecraft:blackstone
setblock 460 96 464 minecraft:polished_blackstone_bricks
setblock 460 96 504 minecraft:polished_blackstone_bricks
fill 461 96 464 461 97 464 minecraft:blackstone
setblock 461 96 503 minecraft:polished_blackstone_bricks
fill 461 96 504 461 99 504 minecraft:blackstone
fill 462 96 503 462 97 503 minecraft:blackstone
setblock 463 96 502 minecraft:blackstone
setblock 464 96 485 minecraft:polished_blackstone_bricks
setblock 464 96 500 minecraft:polished_blackstone_bricks
fill 464 96 501 464 98 501 minecraft:blackstone
setblock 424 97 479 minecraft:polished_blackstone_bricks
fill 424 97 480 424 100 480 minecraft:blackstone
setblock 424 97 484 minecraft:polished_blackstone_bricks
fill 424 97 485 425 99 485 minecraft:blackstone
setblock 425 97 483 minecraft:polished_blackstone_bricks
fill 425 97 484 425 100 484 minecraft:blackstone
setblock 429 97 464 minecraft:polished_blackstone_bricks
setblock 429 97 504 minecraft:polished_blackstone_bricks
fill 430 97 464 430 100 464 minecraft:blackstone
fill 430 97 504 430 100 504 minecraft:blackstone
setblock 432 97 465 minecraft:blackstone
setblock 433 97 465 minecraft:polished_blackstone_bricks
setblock 434 97 464 minecraft:polished_blackstone_bricks
fill 434 97 465 434 100 465 minecraft:blackstone
setblock 434 97 504 minecraft:polished_blackstone_bricks
fill 435 97 464 435 100 464 minecraft:blackstone
setblock 435 97 503 minecraft:polished_blackstone_bricks
fill 435 97 504 435 100 504 minecraft:blackstone
setblock 436 97 503 minecraft:blackstone
setblock 438 97 465 minecraft:polished_blackstone_bricks
setblock 439 97 464 minecraft:polished_blackstone_bricks
fill 439 97 465 439 100 465 minecraft:blackstone
setblock 439 97 504 minecraft:polished_blackstone_bricks
fill 440 97 464 443 97 464 minecraft:blackstone
fill 440 97 504 443 97 504 minecraft:blackstone
setblock 444 97 464 minecraft:polished_blackstone_bricks
setblock 444 97 504 minecraft:polished_blackstone_bricks
fill 445 97 464 445 100 464 minecraft:blackstone
fill 445 97 504 445 100 504 minecraft:blackstone
setblock 448 97 465 minecraft:polished_blackstone_bricks
setblock 449 97 464 minecraft:polished_blackstone_bricks
fill 449 97 465 449 100 465 minecraft:blackstone
setblock 449 97 504 minecraft:polished_blackstone_bricks
fill 450 97 464 450 100 464 minecraft:blackstone
setblock 450 97 503 minecraft:polished_blackstone_bricks
fill 450 97 504 450 100 504 minecraft:blackstone
setblock 451 97 502 minecraft:polished_blackstone_bricks
fill 451 97 503 451 100 503 minecraft:blackstone
fill 452 97 502 452 100 502 minecraft:blackstone
setblock 453 97 465 minecraft:polished_blackstone_bricks
setblock 454 97 464 minecraft:polished_blackstone_bricks
fill 454 97 465 454 100 465 minecraft:blackstone
setblock 454 97 504 minecraft:polished_blackstone_bricks
fill 455 97 464 455 100 464 minecraft:blackstone
setblock 455 97 503 minecraft:polished_blackstone_bricks
fill 455 97 504 455 100 504 minecraft:blackstone
setblock 456 97 502 minecraft:polished_blackstone_bricks
fill 456 97 503 456 100 503 minecraft:blackstone
fill 457 97 502 457 99 502 minecraft:blackstone
setblock 458 97 465 minecraft:polished_blackstone_bricks
setblock 459 97 464 minecraft:polished_blackstone_bricks
fill 459 97 472 459 98 472 minecraft:polished_blackstone_bricks
fill 459 97 474 459 98 474 minecraft:polished_blackstone_bricks
setblock 459 97 504 minecraft:polished_blackstone_bricks
fill 460 97 464 460 100 464 minecraft:blackstone
setblock 460 97 503 minecraft:polished_blackstone_bricks
fill 460 97 504 460 100 504 minecraft:blackstone
fill 461 97 503 461 98 503 minecraft:blackstone
setblock 464 97 484 minecraft:polished_blackstone_bricks
fill 464 97 485 464 99 486 minecraft:blackstone
setblock 464 97 500 minecraft:blackstone
setblock 464 97 504 minecraft:polished_blackstone_bricks
setblock 424 98 483 minecraft:polished_blackstone_bricks
fill 424 98 484 424 101 484 minecraft:blackstone
setblock 424 98 488 minecraft:polished_blackstone_bricks
fill 424 98 489 424 101 489 minecraft:blackstone
setblock 425 98 482 minecraft:polished_blackstone_bricks
fill 425 98 483 425 101 483 minecraft:blackstone
setblock 425 98 486 minecraft:blackstone
setblock 428 98 464 minecraft:polished_blackstone_bricks
fill 429 98 464 429 101 464 minecraft:blackstone
fill 429 98 504 429 101 504 minecraft:blackstone
setblock 431 98 465 minecraft:blackstone
setblock 432 98 465 minecraft:polished_blackstone_bricks
setblock 433 98 464 minecraft:polished_blackstone_bricks
fill 433 98 465 433 101 465 minecraft:blackstone
setblock 433 98 504 minecraft:polished_blackstone_bricks
fill 434 98 464 434 101 464 minecraft:blackstone
fill 434 98 504 434 101 504 minecraft:blackstone
setblock 437 98 465 minecraft:polished_blackstone_bricks
setblock 438 98 464 minecraft:polished_blackstone_bricks
fill 438 98 465 438 101 465 minecraft:blackstone
setblock 438 98 504 minecraft:polished_blackstone_bricks
fill 439 98 464 442 98 464 minecraft:blackstone
fill 439 98 504 442 98 504 minecraft:blackstone
setblock 443 98 464 minecraft:polished_blackstone_bricks
setblock 443 98 504 minecraft:polished_blackstone_bricks
fill 444 98 464 444 101 464 minecraft:blackstone
fill 444 98 504 444 101 504 minecraft:blackstone
setblock 446 98 465 minecraft:blackstone
setblock 447 98 465 minecraft:polished_blackstone_bricks
setblock 448 98 464 minecraft:polished_blackstone_bricks
fill 448 98 465 448 101 465 minecraft:blackstone
setblock 448 98 504 minecraft:polished_blackstone_bricks
fill 449 98 464 449 101 464 minecraft:blackstone
setblock 449 98 503 minecraft:polished_blackstone_bricks
fill 449 98 504 449 101 504 minecraft:blackstone
fill 450 98 503 450 101 503 minecraft:blackstone
fill 451 98 502 451 101 502 minecraft:blackstone
setblock 452 98 465 minecraft:polished_blackstone_bricks
setblock 453 98 464 minecraft:polished_blackstone_bricks
fill 453 98 465 453 100 466 minecraft:blackstone
setblock 453 98 504 minecraft:polished_blackstone_bricks
fill 454 98 464 454 101 464 minecraft:blackstone
setblock 454 98 503 minecraft:polished_blackstone_bricks
fill 454 98 504 454 101 504 minecraft:blackstone
setblock 455 98 502 minecraft:polished_blackstone_bricks
fill 455 98 503 455 101 503 minecraft:blackstone
fill 456 98 502 456 101 502 minecraft:blackstone
setblock 457 98 465 minecraft:polished_blackstone_bricks
setblock 458 98 464 minecraft:polished_blackstone_bricks
setblock 458 98 504 minecraft:polished_blackstone_bricks
fill 459 98 464 459 101 464 minecraft:blackstone
setblock 459 98 503 minecraft:polished_blackstone_bricks
fill 459 98 504 459 101 504 minecraft:blackstone
fill 460 98 503 460 99 503 minecraft:blackstone
setblock 463 98 504 minecraft:polished_blackstone_bricks
setblock 464 98 483 minecraft:polished_blackstone_bricks
fill 464 98 484 464 101 484 minecraft:blackstone
setblock 464 98 487 minecraft:blackstone
setblock 464 98 503 minecraft:polished_blackstone_bricks
fill 464 98 504 464 101 504 minecraft:blackstone
setblock 424 99 482 minecraft:polished_blackstone_bricks
fill 424 99 483 424 102 483 minecraft:blackstone
setblock 424 99 487 minecraft:polished_blackstone_bricks
fill 424 99 488 424 102 488 minecraft:blackstone
fill 425 99 482 425 102 482 minecraft:blackstone
setblock 425 99 486 minecraft:polished_blackstone_bricks
fill 425 99 487 430 100 487 minecraft:blackstone
fill 426 99 484 430 99 486 minecraft:blackstone
fill 426 99 488 430 100 488 minecraft:blackstone
setblock 427 99 464 minecraft:polished_blackstone_bricks
fill 428 99 464 428 102 464 minecraft:blackstone
fill 428 99 504 428 102 504 minecraft:blackstone
setblock 430 99 465 minecraft:blackstone
setblock 431 99 465 minecraft:polished_blackstone_bricks
setblock 432 99 464 minecraft:polished_blackstone_bricks
fill 432 99 465 432 102 465 minecraft:blackstone
setblock 432 99 504 minecraft:polished_blackstone_bricks
fill 433 99 464 433 102 464 minecraft:blackstone
fill 433 99 466 434 99 466 minecraft:blackstone
fill 433 99 504 433 102 504 minecraft:blackstone
setblock 435 99 466 minecraft:polished_blackstone_bricks
setblock 436 99 465 minecraft:polished_blackstone_bricks
fill 436 99 466 436 102 466 minecraft:blackstone
fill 436 99 500 437 100 501 minecraft:cyan_stained_glass
setblock 437 99 464 minecraft:polished_blackstone_bricks
fill 437 99 465 437 102 465 minecraft:blackstone
setblock 437 99 504 minecraft:polished_blackstone_bricks
fill 438 99 464 441 99 464 minecraft:blackstone
fill 438 99 500 438 100 500 minecraft:cyan_stained_glass
fill 438 99 504 441 99 504 minecraft:blackstone
setblock 441 99 465 minecraft:polished_blackstone_bricks
setblock 442 99 464 minecraft:polished_blackstone_bricks
fill 442 99 465 442 102 465 minecraft:blackstone
setblock 442 99 504 minecraft:polished_blackstone_bricks
fill 443 99 464 443 102 464 minecraft:blackstone
fill 443 99 504 443 102 504 minecraft:blackstone
fill 444 99 465 445 99 465 minecraft:blackstone
setblock 446 99 465 minecraft:polished_blackstone_bricks
setblock 447 99 464 minecraft:polished_blackstone_bricks
fill 447 99 465 447 102 465 minecraft:blackstone
setblock 447 99 503 minecraft:blackstone
setblock 447 99 504 minecraft:polished_blackstone_bricks
fill 448 99 464 448 102 464 minecraft:blackstone
setblock 448 99 503 minecraft:polished_blackstone_bricks
fill 448 99 504 448 102 504 minecraft:blackstone
fill 449 99 503 449 102 503 minecraft:blackstone
setblock 450 99 466 minecraft:polished_blackstone_bricks
setblock 451 99 465 minecraft:polished_blackstone_bricks
fill 451 99 466 452 101 466 minecraft:blackstone
setblock 452 99 464 minecraft:polished_blackstone_bricks
fill 452 99 465 452 102 465 minecraft:blackstone
setblock 452 99 504 minecraft:polished_blackstone_bricks
fill 453 99 464 453 102 464 minecraft:blackstone
setblock 453 99 503 minecraft:polished_blackstone_bricks
fill 453 99 504 453 102 504 minecraft:blackstone
setblock 454 99 466 minecraft:blackstone
setblock 454 99 502 minecraft:polished_blackstone_bricks
fill 454 99 503 454 102 503 minecraft:blackstone
fill 455 99 502 455 102 502 minecraft:blackstone
setblock 456 99 465 minecraft:polished_blackstone_bricks
setblock 457 99 464 minecraft:polished_blackstone_bricks
fill 457 99 465 457 102 465 minecraft:blackstone
setblock 457 99 504 minecraft:polished_blackstone_bricks
fill 458 99 464 458 102 464 minecraft:blackstone
setblock 458 99 503 minecraft:polished_blackstone_bricks
fill 458 99 504 458 102 504 minecraft:blackstone
fill 459 99 503 459 101 503 minecraft:blackstone
setblock 462 99 504 minecraft:polished_blackstone_bricks
fill 463 99 504 463 102 504 minecraft:blackstone
fill 464 99 483 464 102 483 minecraft:blackstone
setblock 464 99 487 minecraft:polished_blackstone_bricks
fill 464 99 488 464 101 489 minecraft:blackstone
setblock 464 99 502 minecraft:polished_blackstone_bricks
fill 464 99 503 464 102 503 minecraft:blackstone
setblock 424 100 481 minecraft:polished_blackstone_bricks
fill 424 100 482 424 103 482 minecraft:blackstone
setblock 424 100 485 minecraft:blackstone
setblock 424 100 486 minecraft:polished_blackstone_bricks
fill 424 100 487 424 103 487 minecraft:blackstone
setblock 424 100 490 minecraft:blackstone
fill 425 100 481 425 103 481 minecraft:blackstone
setblock 425 100 485 minecraft:polished_blackstone_bricks
fill 425 100 486 430 100 486 minecraft:blackstone
fill 425 100 488 425 101 488 minecraft:blackstone
setblock 426 100 464 minecraft:polished_blackstone_bricks
setblock 426 100 484 minecraft:polished_blackstone_bricks
fill 426 100 485 430 100 485 minecraft:blackstone
fill 427 100 464 427 103 464 minecraft:blackstone
fill 427 100 484 430 100 484 minecraft:blackstone
setblock 429 100 465 minecraft:blackstone
setblock 430 100 465 minecraft:polished_blackstone_bricks
setblock 431 100 464 minecraft:polished_blackstone_bricks
fill 431 100 465 431 102 466 minecraft:blackstone
setblock 431 100 504 minecraft:polished_blackstone_bricks
fill 432 100 464 432 103 464 minecraft:blackstone
fill 432 100 466 433 100 466 minecraft:blackstone
fill 432 100 504 432 103 504 minecraft:blackstone
setblock 434 100 466 minecraft:polished_blackstone_bricks
setblock 435 100 465 minecraft:polished_blackstone_bricks
fill 435 100 466 435 103 466 minecraft:blackstone
setblock 436 100 464 minecraft:polished_blackstone_bricks
fill 436 100 465 436 103 465 minecraft:blackstone
setblock 436 100 504 minecraft:polished_blackstone_bricks
fill 437 100 464 440 100 464 minecraft:blackstone
fill 437 100 466 437 101 466 minecraft:blackstone
fill 437 100 504 440 100 504 minecraft:blackstone
setblock 440 100 465 minecraft:polished_blackstone_bricks
setblock 441 100 464 minecraft:polished_blackstone_bricks
fill 441 100 465 441 103 465 minecraft:blackstone
setblock 441 100 504 minecraft:polished_blackstone_bricks
fill 442 100 464 442 103 464 minecraft:blackstone
fill 442 100 504 442 103 504 minecraft:blackstone
fill 443 100 465 444 100 465 minecraft:blackstone
setblock 445 100 465 minecraft:polished_blackstone_bricks
setblock 446 100 464 minecraft:polished_blackstone_bricks
fill 446 100 465 446 103 465 minecraft:blackstone
setblock 446 100 504 minecraft:polished_blackstone_bricks
fill 447 100 464 447 103 464 minecraft:blackstone
setblock 447 100 503 minecraft:polished_blackstone_bricks
fill 447 100 504 447 103 504 minecraft:blackstone
setblock 448 100 466 minecraft:blackstone
fill 448 100 503 448 103 503 minecraft:blackstone
setblock 449 100 466 minecraft:polished_blackstone_bricks
setblock 450 100 465 minecraft:polished_blackstone_bricks
fill 450 100 466 450 103 466 minecraft:blackstone
fill 450 100 502 450 102 502 minecraft:blackstone
setblock 451 100 464 minecraft:polished_blackstone_bricks
fill 451 100 465 451 103 465 minecraft:blackstone
setblock 451 100 504 minecraft:polished_blackstone_bricks
fill 452 100 464 452 103 464 minecraft:blackstone
setblock 452 100 503 minecraft:polished_blackstone_bricks
fill 452 100 504 452 103 504 minecraft:blackstone
setblock 453 100 502 minecraft:polished_blackstone_bricks
fill 453 100 503 453 103 503 minecraft:blackstone
setblock 454 100 466 minecraft:polished_blackstone_bricks
fill 454 100 502 454 103 502 minecraft:blackstone
setblock 455 100 465 minecraft:polished_blackstone_bricks
setblock 456 100 464 minecraft:polished_blackstone_bricks
fill 456 100 465 456 103 465 minecraft:blackstone
setblock 456 100 504 minecraft:polished_blackstone_bricks
fill 457 100 464 457 103 464 minecraft:blackstone
setblock 457 100 503 minecraft:polished_blackstone_bricks
fill 457 100 504 457 103 504 minecraft:blackstone
fill 458 100 503 458 103 503 minecraft:blackstone
setblock 461 100 504 minecraft:polished_blackstone_bricks
fill 462 100 504 462 103 504 minecraft:blackstone
fill 464 100 482 464 103 482 minecraft:blackstone
setblock 464 100 485 minecraft:blackstone
setblock 464 100 486 minecraft:polished_blackstone_bricks
fill 464 100 487 464 103 487 minecraft:blackstone
setblock 464 100 490 minecraft:blackstone
setblock 464 100 491 minecraft:polished_blackstone_bricks
setblock 424 101 479 minecraft:blackstone
setblock 424 101 480 minecraft:polished_blackstone_bricks
fill 424 101 481 424 104 481 minecraft:blackstone
setblock 424 101 485 minecraft:polished_blackstone_bricks
fill 424 101 486 426 102 486 minecraft:blackstone
setblock 424 101 490 minecraft:polished_blackstone_bricks
fill 424 101 491 424 103 492 minecraft:blackstone
setblock 425 101 464 minecraft:polished_blackstone_bricks
setblock 425 101 484 minecraft:polished_blackstone_bricks
fill 425 101 485 426 103 485 minecraft:blackstone
fill 425 101 487 426 101 487 minecraft:blackstone
setblock 425 101 489 minecraft:polished_blackstone_bricks
fill 425 101 490 425 104 490 minecraft:blackstone
fill 426 101 464 426 104 464 minecraft:blackstone
setblock 426 101 483 minecraft:polished_blackstone_bricks
fill 426 101 484 426 104 484 minecraft:blackstone
fill 427 101 465 428 101 465 minecraft:blackstone
fill 427 101 486 429 102 486 minecraft:polished_blackstone_bricks
fill 427 101 504 427 103 504 minecraft:blackstone
setblock 429 101 465 minecraft:polished_blackstone_bricks
fill 429 101 466 430 103 466 minecraft:blackstone
setblock 430 101 464 minecraft:polished_blackstone_bricks
fill 430 101 465 430 104 465 minecraft:blackstone
setblock 430 101 504 minecraft:polished_blackstone_bricks
fill 431 101 464 431 104 464 minecraft:blackstone
fill 431 101 504 431 104 504 minecraft:blackstone
setblock 432 101 466 minecraft:blackstone
setblock 433 101 466 minecraft:polished_blackstone_bricks
setblock 434 101 465 minecraft:polished_blackstone_bricks
fill 434 101 466 434 104 466 minecraft:blackstone
setblock 435 101 464 minecraft:polished_blackstone_bricks
fill 435 101 465 435 104 465 minecraft:blackstone
setblock 435 101 504 minecraft:polished_blackstone_bricks
fill 436 101 464 439 101 464 minecraft:blackstone
fill 436 101 504 439 101 504 minecraft:blackstone
setblock 438 101 466 minecraft:polished_blackstone_bricks
setblock 439 101 465 minecraft:polished_blackstone_bricks
setblock 440 101 464 minecraft:polished_blackstone_bricks
fill 440 101 465 440 104 465 minecraft:blackstone
setblock 440 101 504 minecraft:polished_blackstone_bricks
fill 441 101 464 441 104 464 minecraft:blackstone
fill 441 101 504 441 104 504 minecraft:blackstone
setblock 443 101 465 minecraft:blackstone
setblock 444 101 465 minecraft:polished_blackstone_bricks
setblock 445 101 464 minecraft:polished_blackstone_bricks
fill 445 101 465 445 104 465 minecraft:blackstone
setblock 445 101 504 minecraft:polished_blackstone_bricks
fill 446 101 464 446 104 464 minecraft:blackstone
fill 446 101 466 447 101 466 minecraft:blackstone
setblock 446 101 503 minecraft:polished_blackstone_bricks
fill 446 101 504 446 104 504 minecraft:blackstone
fill 447 101 503 447 104 503 minecraft:blackstone
setblock 448 101 466 minecraft:polished_blackstone_bricks
setblock 449 101 465 minecraft:polished_blackstone_bricks
fill 449 101 466 449 104 466 minecraft:blackstone
setblock 450 101 464 minecraft:polished_blackstone_bricks
fill 450 101 465 450 104 465 minecraft:blackstone
setblock 450 101 504 minecraft:polished_blackstone_bricks
fill 451 101 464 451 104 464 minecraft:blackstone
setblock 451 101 503 minecraft:polished_blackstone_bricks
fill 451 101 504 451 104 504 minecraft:blackstone
setblock 452 101 502 minecraft:polished_blackstone_bricks
fill 452 101 503 452 104 503 minecraft:blackstone
setblock 453 101 465 minecraft:blackstone
setblock 453 101 466 minecraft:polished_blackstone_bricks
fill 453 101 502 453 104 502 minecraft:blackstone
setblock 454 101 465 minecraft:polished_blackstone_bricks
fill 454 101 466 455 103 466 minecraft:blackstone
setblock 455 101 464 minecraft:polished_blackstone_bricks
fill 455 101 465 455 104 465 minecraft:blackstone
setblock 455 101 504 minecraft:polished_blackstone_bricks
fill 456 101 464 456 104 464 minecraft:blackstone
setblock 456 101 503 minecraft:polished_blackstone_bricks
fill 456 101 504 456 104 504 minecraft:blackstone
fill 457 101 503 457 104 503 minecraft:blackstone
setblock 460 101 464 minecraft:polished_blackstone_bricks
setblock 460 101 504 minecraft:polished_blackstone_bricks
fill 461 101 464 461 104 464 minecraft:blackstone
fill 461 101 504 461 104 504 minecraft:blackstone
setblock 463 101 485 minecraft:blackstone
setblock 463 101 486 minecraft:polished_blackstone_bricks
fill 463 101 487 463 102 489 minecraft:blackstone
setblock 464 101 485 minecraft:polished_blackstone_bricks
fill 464 101 486 464 104 486 minecraft:blackstone
setblock 464 101 490 minecraft:polished_blackstone_bricks
fill 464 101 491 464 102 493 minecraft:blackstone
setblock 424 102 464 minecraft:polished_blackstone_bricks
fill 424 102 465 424 102 468 minecraft:blackstone
setblock 424 102 469 minecraft:polished_blackstone_bricks
setblock 424 102 478 minecraft:blackstone
setblock 424 102 479 minecraft:polished_blackstone_bricks
fill 424 102 480 425 104 480 minecraft:blackstone
setblock 424 102 484 minecraft:polished_blackstone_bricks
fill 424 102 485 424 105 485 minecraft:blackstone
setblock 424 102 489 minecraft:polished_blackstone_bricks
fill 424 102 490 424 105 490 minecraft:blackstone
setblock 424 102 493 minecraft:blackstone
fill 425 102 464 425 105 464 minecraft:blackstone
setblock 425 102 483 minecraft:polished_blackstone_bricks
fill 425 102 484 425 105 484 minecraft:blackstone
setblock 425 102 487 minecraft:blackstone
setblock 425 102 488 minecraft:polished_blackstone_bricks
fill 425 102 489 426 104 489 minecraft:blackstone
fill 425 102 491 425 103 491 minecraft:blackstone
fill 426 102 465 427 102 465 minecraft:blackstone
setblock 426 102 482 minecraft:polished_blackstone_bricks
fill 426 102 483 426 105 483 minecraft:blackstone
setblock 426 102 487 minecraft:polished_blackstone_bricks
fill 426 102 488 426 105 488 minecraft:blackstone
fill 426 102 504 426 104 504 minecraft:blackstone
setblock 428 102 465 minecraft:polished_blackstone_bricks
fill 428 102 466 428 105 466 minecraft:blackstone
setblock 429 102 464 minecraft:polished_blackstone_bricks
fill 429 102 465 429 105 465 minecraft:blackstone
setblock 429 102 504 minecraft:polished_blackstone_bricks
fill 430 102 464 430 105 464 minecraft:blackstone
fill 430 102 504 430 105 504 minecraft:blackstone
setblock 431 102 467 minecraft:polished_blackstone_bricks
setblock 432 102 466 minecraft:polished_blackstone_bricks
fill 432 102 467 434 103 467 minecraft:blackstone
setblock 433 102 465 minecraft:polished_blackstone_bricks
fill 433 102 466 433 105 466 minecraft:blackstone
setblock 434 102 464 minecraft:polished_blackstone_bricks
fill 434 102 465 434 105 465 minecraft:blackstone
setblock 434 102 504 minecraft:polished_blackstone_bricks
fill 435 102 464 438 102 464 minecraft:blackstone
fill 435 102 504 438 102 504 minecraft:blackstone
setblock 437 102 466 minecraft:polished_blackstone_bricks
setblock 438 102 465 minecraft:polished_blackstone_bricks
fill 438 102 466 439 104 466 minecraft:blackstone
setblock 439 102 464 minecraft:polished_blackstone_bricks
fill 439 102 465 439 105 465 minecraft:blackstone
setblock 439 102 504 minecraft:polished_blackstone_bricks
fill 440 102 464 440 105 464 minecraft:blackstone
fill 440 102 504 440 105 504 minecraft:blackstone
setblock 443 102 465 minecraft:polished_blackstone_bricks
setblock 444 102 464 minecraft:polished_blackstone_bricks
fill 444 102 465 444 104 466 minecraft:blackstone
setblock 444 102 504 minecraft:polished_blackstone_bricks
fill 445 102 464 445 105 464 minecraft:blackstone
fill 445 102 466 446 102 466 minecraft:blackstone
fill 445 102 504 445 105 504 minecraft:blackstone
fill 446 102 503 446 105 503 minecraft:blackstone
setblock 447 102 466 minecraft:polished_blackstone_bricks
setblock 448 102 465 minecraft:polished_blackstone_bricks
fill 448 102 466 448 105 466 minecraft:blackstone
setblock 449 102 464 minecraft:polished_blackstone_bricks
fill 449 102 465 449 105 465 minecraft:blackstone
fill 449 102 502 449 103 502 minecraft:blackstone
setblock 449 102 504 minecraft:polished_blackstone_bricks
fill 450 102 464 450 105 464 minecraft:blackstone
setblock 450 102 503 minecraft:polished_blackstone_bricks
fill 450 102 504 450 105 504 minecraft:blackstone
setblock 451 102 466 minecraft:blackstone
setblock 451 102 502 minecraft:polished_blackstone_bricks
fill 451 102 503 451 105 503 minecraft:blackstone
setblock 452 102 466 minecraft:polished_blackstone_bricks
fill 452 102 502 452 105 502 minecraft:blackstone
setblock 453 102 465 minecraft:polished_blackstone_bricks
fill 453 102 466 453 105 466 minecraft:blackstone
setblock 454 102 464 minecraft:polished_blackstone_bricks
fill 454 102 465 454 105 465 minecraft:blackstone
setblock 454 102 504 minecraft:polished_blackstone_bricks
fill 455 102 464 455 105 464 minecraft:blackstone
setblock 455 102 503 minecraft:polished_blackstone_bricks
fill 455 102 504 455 105 504 minecraft:blackstone
fill 456 102 503 456 105 503 minecraft:blackstone
setblock 459 102 464 minecraft:polished_blackstone_bricks
setblock 459 102 504 minecraft:polished_blackstone_bricks
fill 460 102 464 460 104 464 minecraft:blackstone
fill 460 102 504 460 105 504 minecraft:blackstone
setblock 463 102 484 minecraft:blackstone
setblock 463 102 485 minecraft:polished_blackstone_bricks
fill 463 102 486 463 105 486 minecraft:blackstone
setblock 463 102 490 minecraft:polished_blackstone_bricks
fill 463 102 491 463 105 491 minecraft:blackstone
setblock 464 102 464 minecraft:polished_blackstone_bricks
fill 464 102 465 464 105 465 minecraft:blackstone
fill 464 102 481 464 104 481 minecraft:blackstone
setblock 464 102 484 minecraft:polished_blackstone_bricks
fill 464 102 485 464 105 485 minecraft:blackstone
setblock 464 102 488 minecraft:blackstone
setblock 464 102 489 minecraft:polished_blackstone_bricks
fill 464 102 490 464 105 490 minecraft:blackstone
setblock 464 102 494 minecraft:polished_blackstone_bricks
fill 464 102 495 464 105 495 minecraft:blackstone
setblock 464 102 504 minecraft:polished_blackstone_bricks
fill 424 103 464 424 103 467 minecraft:blackstone
setblock 424 103 468 minecraft:polished_blackstone_bricks
fill 424 103 469 424 103 472 minecraft:blackstone
setblock 424 103 473 minecraft:polished_blackstone_bricks
fill 424 103 474 424 106 474 minecraft:blackstone
fill 424 103 476 424 103 477 minecraft:blackstone
setblock 424 103 478 minecraft:polished_blackstone_bricks
fill 424 103 479 424 106 479 minecraft:blackstone
setblock 424 103 483 minecraft:polished_blackstone_bricks
fill 424 103 484 424 106 484 minecraft:blackstone
fill 424 103 486 425 103 486 minecraft:blackstone
setblock 424 103 488 minecraft:polished_blackstone_bricks
fill 424 103 489 424 106 489 minecraft:blackstone
setblock 424 103 493 minecraft:polished_blackstone_bricks
fill 424 103 494 424 106 494 minecraft:blackstone
fill 425 103 465 425 103 466 minecraft:blackstone
setblock 425 103 467 minecraft:polished_blackstone_bricks
fill 425 103 468 425 104 470 minecraft:blackstone
setblock 425 103 482 minecraft:polished_blackstone_bricks
fill 425 103 483 425 106 483 minecraft:blackstone
setblock 425 103 487 minecraft:polished_blackstone_bricks
fill 425 103 488 425 106 488 minecraft:blackstone
setblock 425 103 492 minecraft:polished_blackstone_bricks
setblock 426 103 465 minecraft:blackstone
fill 426 103 482 426 106 482 minecraft:blackstone
setblock 426 103 486 minecraft:polished_blackstone_bricks
fill 426 103 487 427 105 487 minecraft:blackstone
setblock 426 103 490 minecraft:blackstone
setblock 427 103 465 minecraft:polished_blackstone_bricks
fill 427 103 466 427 106 466 minecraft:blackstone
setblock 427 103 484 minecraft:blackstone
setblock 427 103 485 minecraft:polished_blackstone_bricks
fill 427 103 486 427 106 486 minecraft:blackstone
fill 427 103 488 427 104 488 minecraft:blackstone
setblock 428 103 464 minecraft:polished_blackstone_bricks
fill 428 103 465 428 106 465 minecraft:blackstone
fill 428 103 486 429 105 486 minecraft:polished_blackstone_bricks
setblock 428 103 504 minecraft:polished_blackstone_bricks
fill 429 103 464 429 106 464 minecraft:blackstone
setblock 429 103 467 minecraft:blackstone
fill 429 103 504 429 106 504 minecraft:blackstone
setblock 430 103 467 minecraft:polished_blackstone_bricks
setblock 431 103 465 minecraft:blackstone
setblock 431 103 466 minecraft:polished_blackstone_bricks
fill 431 103 467 431 106 467 minecraft:blackstone
setblock 432 103 465 minecraft:polished_blackstone_bricks
fill 432 103 466 432 106 466 minecraft:blackstone
setblock 433 103 464 minecraft:polished_blackstone_bricks
fill 433 103 465 433 106 465 minecraft:blackstone
setblock 433 103 504 minecraft:polished_blackstone_bricks
fill 434 103 464 437 103 464 minecraft:blackstone
fill 434 103 504 437 103 504 minecraft:blackstone
setblock 435 103 467 minecraft:polished_blackstone_bricks
setblock 436 103 466 minecraft:polished_blackstone_bricks
setblock 437 103 465 minecraft:polished_blackstone_bricks
fill 437 103 466 437 106 466 minecraft:blackstone
setblock 438 103 464 minecraft:polished_blackstone_bricks
fill 438 103 465 438 106 465 minecraft:blackstone
setblock 438 103 504 minecraft:polished_blackstone_bricks
fill 439 103 464 439 106 464 minecraft:blackstone
fill 439 103 504 439 104 504 minecraft:blackstone
setblock 440 103 466 minecraft:blackstone
setblock 441 103 466 minecraft:polished_blackstone_bricks
setblock 442 103 465 minecraft:polished_blackstone_bricks
fill 442 103 466 443 105 466 minecraft:blackstone
setblock 443 103 464 minecraft:polished_blackstone_bricks
fill 443 103 465 443 106 465 minecraft:blackstone
setblock 443 103 504 minecraft:polished_blackstone_bricks
fill 444 103 464 444 106 464 minecraft:blackstone
fill 444 103 504 444 106 504 minecraft:blackstone
setblock 445 103 466 minecraft:blackstone
fill 445 103 503 445 106 503 minecraft:blackstone
setblock 446 103 466 minecraft:polished_blackstone_bricks
setblock 447 103 465 minecraft:polished_blackstone_bricks
fill 447 103 466 447 106 466 minecraft:blackstone
setblock 448 103 464 minecraft:polished_blackstone_bricks
fill 448 103 465 448 106 465 minecraft:blackstone
fill 448 103 467 449 103 467 minecraft:blackstone
fill 448 103 502 448 104 502 minecraft:blackstone
setblock 448 103 504 minecraft:polished_blackstone_bricks
fill 449 103 464 449 106 464 minecraft:blackstone
setblock 449 103 503 minecraft:polished_blackstone_bricks
fill 449 103 504 449 106 504 minecraft:blackstone
setblock 450 103 467 minecraft:polished_blackstone_bricks
setblock 450 103 502 minecraft:polished_blackstone_bricks
fill 450 103 503 450 106 503 minecraft:blackstone
setblock 451 103 466 minecraft:polished_blackstone_bricks
fill 451 103 467 452 104 467 minecraft:blackstone
fill 451 103 502 451 106 502 minecraft:blackstone
setblock 452 103 465 minecraft:polished_blackstone_bricks
fill 452 103 466 452 106 466 minecraft:blackstone
setblock 453 103 464 minecraft:polished_blackstone_bricks
fill 453 103 465 453 106 465 minecraft:blackstone
setblock 453 103 504 minecraft:polished_blackstone_bricks
fill 454 103 464 454 106 464 minecraft:blackstone
setblock 454 103 503 minecraft:polished_blackstone_bricks
fill 454 103 504 454 106 504 minecraft:blackstone
fill 455 103 503 455 106 503 minecraft:blackstone
setblock 457 103 465 minecraft:polished_blackstone_bricks
setblock 458 103 464 minecraft:polished_blackstone_bricks
setblock 458 103 504 minecraft:polished_blackstone_bricks
fill 459 103 464 459 105 464 minecraft:blackstone
fill 459 103 504 459 105 504 minecraft:blackstone
setblock 462 103 464 minecraft:blackstone
setblock 463 103 464 minecraft:polished_blackstone_bricks
setblock 463 103 484 minecraft:polished_blackstone_bricks
fill 463 103 485 463 106 485 minecraft:blackstone
fill 463 103 487 463 103 488 minecraft:blackstone
setblock 463 103 489 minecraft:polished_blackstone_bricks
fill 463 103 490 463 106 490 minecraft:blackstone
fill 463 103 492 463 103 493 minecraft:blackstone
setblock 463 103 504 minecraft:polished_blackstone_bricks
fill 464 103 464 464 106 464 minecraft:blackstone
fill 464 103 466 464 103 467 minecraft:blackstone
setblock 464 103 468 minecraft:polished_blackstone_bricks
setblock 464 103 483 minecraft:polished_blackstone_bricks
fill 464 103 484 464 106 484 minecraft:blackstone
setblock 464 103 488 minecraft:polished_blackstone_bricks
fill 464 103 489 464 106 489 minecraft:blackstone
fill 464 103 491 464 103 492 minecraft:blackstone
setblock 464 103 493 minecraft:polished_blackstone_bricks
fill 464 103 494 464 106 494 minecraft:blackstone
fill 464 103 496 464 103 497 minecraft:blackstone
setblock 464 103 502 minecraft:blackstone
setblock 464 103 503 minecraft:polished_blackstone_bricks
fill 464 103 504 464 105 504 minecraft:blackstone
fill 424 104 464 424 104 466 minecraft:blackstone
setblock 424 104 467 minecraft:polished_blackstone_bricks
fill 424 104 468 424 104 471 minecraft:blackstone
setblock 424 104 472 minecraft:polished_blackstone_bricks
fill 424 104 473 425 106 473 minecraft:blackstone
fill 424 104 475 424 104 476 minecraft:blackstone
setblock 424 104 477 minecraft:polished_blackstone_bricks
fill 424 104 478 425 106 478 minecraft:blackstone
setblock 424 104 482 minecraft:polished_blackstone_bricks
fill 424 104 483 424 107 483 minecraft:blackstone
setblock 424 104 486 minecraft:blackstone
setblock 424 104 487 minecraft:polished_blackstone_bricks
fill 424 104 488 424 107 488 minecraft:blackstone
setblock 424 104 491 minecraft:blackstone
setblock 424 104 492 minecraft:polished_blackstone_bricks
fill 424 104 493 425 106 493 minecraft:blackstone
fill 424 104 495 424 105 495 minecraft:blackstone
setblock 425 104 465 minecraft:blackstone
setblock 425 104 466 minecraft:polished_blackstone_bricks
fill 425 104 467 426 106 467 minecraft:blackstone
setblock 425 104 471 minecraft:polished_blackstone_bricks
fill 425 104 472 425 107 472 minecraft:blackstone
fill 425 104 474 425 105 474 minecraft:blackstone
fill 425 104 479 425 105 479 minecraft:blackstone
setblock 425 104 481 minecraft:polished_blackstone_bricks
fill 425 104 482 425 107 482 minecraft:blackstone
setblock 425 104 485 minecraft:blackstone
setblock 425 104 486 minecraft:polished_blackstone_bricks
fill 425 104 487 425 107 487 minecraft:blackstone
setblock 425 104 491 minecraft:polished_blackstone_bricks
fill 425 104 492 425 107 492 minecraft:blackstone
setblock 426 104 465 minecraft:polished_blackstone_bricks
fill 426 104 466 426 107 466 minecraft:blackstone
fill 426 104 468 426 104 469 minecraft:blackstone
setblock 426 104 470 minecraft:polished_blackstone_bricks
fill 426 104 471 426 107 471 minecraft:blackstone
setblock 426 104 474 minecraft:light[level=11]
fill 426 104 481 426 105 481 minecraft:blackstone
setblock 426 104 485 minecraft:polished_blackstone_bricks
fill 426 104 486 426 107 486 minecraft:blackstone
setblock 426 104 490 minecraft:polished_blackstone_bricks
fill 426 104 491 426 107 491 minecraft:blackstone
setblock 426 104 498 minecraft:light[level=11]
setblock 427 104 464 minecraft:polished_blackstone_bricks
fill 427 104 465 427 107 465 minecraft:blackstone
setblock 427 104 484 minecraft:polished_blackstone_bricks
fill 427 104 485 427 105 485 minecraft:blackstone
setblock 427 104 489 minecraft:polished_blackstone_bricks
setblock 427 104 504 minecraft:polished_blackstone_bricks
fill 428 104 464 428 107 464 minecraft:blackstone
setblock 428 104 467 minecraft:blackstone
fill 428 104 485 428 105 485 minecraft:polished_blackstone_bricks
fill 428 104 487 428 105 487 minecraft:polished_blackstone_bricks
fill 428 104 504 428 107 504 minecraft:blackstone
setblock 429 104 466 minecraft:blackstone
setblock 429 104 467 minecraft:polished_blackstone_bricks
setblock 430 104 466 minecraft:polished_blackstone_bricks
fill 430 104 467 430 107 467 minecraft:blackstone
setblock 431 104 465 minecraft:polished_blackstone_bricks
fill 431 104 466 431 107 466 minecraft:blackstone
setblock 432 104 464 minecraft:polished_blackstone_bricks
fill 432 104 465 432 107 465 minecraft:blackstone
fill 432 104 467 433 104 467 minecraft:blackstone
setblock 432 104 504 minecraft:polished_blackstone_bricks
fill 433 104 464 436 104 464 minecraft:blackstone
fill 433 104 504 436 104 504 minecraft:blackstone
setblock 434 104 467 minecraft:polished_blackstone_bricks
setblock 434 104 474 minecraft:light[level=11]
setblock 434 104 482 minecraft:light[level=11]
setblock 434 104 490 minecraft:light[level=11]
setblock 434 104 498 minecraft:light[level=11]
setblock 435 104 466 minecraft:polished_blackstone_bricks
fill 435 104 467 435 105 467 minecraft:blackstone
setblock 436 104 465 minecraft:polished_blackstone_bricks
fill 436 104 466 436 107 466 minecraft:blackstone
setblock 437 104 464 minecraft:polished_blackstone_bricks
fill 437 104 465 437 107 465 minecraft:blackstone
setblock 437 104 504 minecraft:polished_blackstone_bricks
fill 438 104 464 438 107 464 minecraft:blackstone
setblock 438 104 504 minecraft:blackstone
setblock 440 104 466 minecraft:polished_blackstone_bricks
setblock 441 104 465 minecraft:polished_blackstone_bricks
fill 441 104 466 441 106 466 minecraft:blackstone
setblock 442 104 464 minecraft:polished_blackstone_bricks
fill 442 104 465 442 107 465 minecraft:blackstone
setblock 442 104 474 minecraft:light[level=11]
setblock 442 104 482 minecraft:light[level=11]
setblock 442 104 490 minecraft:light[level=11]
setblock 442 104 498 minecraft:light[level=11]
setblock 442 104 504 minecraft:polished_blackstone_bricks
fill 443 104 464 443 107 464 minecraft:blackstone
fill 443 104 504 443 107 504 minecraft:blackstone
setblock 445 104 466 minecraft:polished_blackstone_bricks
setblock 446 104 465 minecraft:polished_blackstone_bricks
fill 446 104 466 446 106 467 minecraft:blackstone
setblock 447 104 464 minecraft:polished_blackstone_bricks
fill 447 104 465 447 107 465 minecraft:blackstone
fill 447 104 467 448 104 467 minecraft:blackstone
setblock 447 104 504 minecraft:polished_blackstone_bricks
fill 448 104 464 448 107 464 minecraft:blackstone
setblock 448 104 503 minecraft:polished_blackstone_bricks
fill 448 104 504 448 107 504 minecraft:blackstone
setblock 449 104 467 minecraft:polished_blackstone_bricks
setblock 449 104 502 minecraft:polished_blackstone_bricks
fill 449 104 503 449 107 503 minecraft:blackstone
setblock 450 104 466 minecraft:polished_blackstone_bricks
fill 450 104 467 450 106 467 minecraft:blackstone
setblock 450 104 474 minecraft:light[level=11]
setblock 450 104 482 minecraft:light[level=11]
setblock 450 104 490 minecraft:light[level=11]
setblock 450 104 498 minecraft:light[level=11]
fill 450 104 502 450 107 502 minecraft:blackstone
setblock 451 104 465 minecraft:polished_blackstone_bricks
fill 451 104 466 451 107 466 minecraft:blackstone
setblock 452 104 464 minecraft:polished_blackstone_bricks
fill 452 104 465 452 107 465 minecraft:blackstone
setblock 452 104 504 minecraft:polished_blackstone_bricks
fill 453 104 464 453 107 464 minecraft:blackstone
fill 453 104 478 454 105 479 minecraft:light_blue_stained_glass
setblock 453 104 503 minecraft:polished_blackstone_bricks
fill 453 104 504 453 107 504 minecraft:blackstone
setblock 454 104 466 minecraft:blackstone
setblock 454 104 502 minecraft:polished_blackstone_bricks
fill 454 104 503 454 106 503 minecraft:blackstone
setblock 455 104 466 minecraft:polished_blackstone_bricks
setblock 456 104 465 minecraft:polished_blackstone_bricks
setblock 457 104 464 minecraft:polished_blackstone_bricks
setblock 457 104 465 minecraft:blackstone
setblock 457 104 504 minecraft:polished_blackstone_bricks
fill 458 104 464 458 105 464 minecraft:blackstone
setblock 458 104 466 minecraft:light[level=11]
setblock 458 104 474 minecraft:light[level=11]
setblock 458 104 482 minecraft:light[level=11]
setblock 458 104 490 minecraft:light[level=11]
setblock 458 104 498 minecraft:light[level=11]
fill 458 104 504 458 106 504 minecraft:blackstone
setblock 462 104 464 minecraft:polished_blackstone_bricks
fill 462 104 487 462 104 488 minecraft:blackstone
setblock 462 104 489 minecraft:polished_blackstone_bricks
fill 462 104 490 462 107 490 minecraft:blackstone
setblock 462 104 504 minecraft:polished_blackstone_bricks
fill 463 104 464 463 106 464 minecraft:blackstone
fill 463 104 484 463 107 484 minecraft:blackstone
setblock 463 104 487 minecraft:blackstone
setblock 463 104 488 minecraft:polished_blackstone_bricks
fill 463 104 489 463 107 489 minecraft:blackstone
setblock 463 104 492 minecraft:blackstone
setblock 463 104 493 minecraft:polished_blackstone_bricks
fill 463 104 494 463 107 494 minecraft:blackstone
fill 463 104 504 463 105 504 minecraft:blackstone
setblock 464 104 466 minecraft:blackstone
setblock 464 104 467 minecraft:polished_blackstone_bricks
fill 464 104 468 464 105 470 minecraft:blackstone
fill 464 104 480 464 105 480 minecraft:blackstone
setblock 464 104 482 minecraft:polished_blackstone_bricks
fill 464 104 483 464 107 483 minecraft:blackstone
setblock 464 104 487 minecraft:polished_blackstone_bricks
fill 464 104 488 464 107 488 minecraft:blackstone
setblock 464 104 491 minecraft:blackstone
setblock 464 104 492 minecraft:polished_blackstone_bricks
fill 464 104 493 464 107 493 minecraft:blackstone
setblock 464 104 496 minecraft:blackstone
setblock 464 104 497 minecraft:polished_blackstone_bricks
fill 464 104 498 464 107 498 minecraft:blackstone
fill 464 104 503 464 105 503 minecraft:blackstone
fill 424 105 464 424 105 465 minecraft:blackstone
setblock 424 105 466 minecraft:polished_blackstone_bricks
fill 424 105 467 424 105 470 minecraft:blackstone
setblock 424 105 471 minecraft:polished_blackstone_bricks
fill 424 105 472 424 108 472 minecraft:blackstone
setblock 424 105 475 minecraft:blackstone
setblock 424 105 476 minecraft:polished_blackstone_bricks
fill 424 105 477 425 107 477 minecraft:blackstone
setblock 424 105 480 minecraft:blackstone
setblock 424 105 481 minecraft:polished_blackstone_bricks
fill 424 105 482 424 108 482 minecraft:blackstone
setblock 424 105 486 minecraft:polished_blackstone_bricks
fill 424 105 487 424 108 487 minecraft:blackstone
setblock 424 105 491 minecraft:polished_blackstone_bricks
fill 424 105 492 424 108 492 minecraft:blackstone
setblock 425 105 465 minecraft:polished_blackstone_bricks
fill 425 105 466 425 108 466 minecraft:blackstone
fill 425 105 468 425 105 469 minecraft:blackstone
setblock 425 105 470 minecraft:polished_blackstone_bricks
fill 425 105 471 425 108 471 minecraft:blackstone
setblock 425 105 475 minecraft:polished_blackstone_bricks
fill 425 105 476 425 108 476 minecraft:blackstone
setblock 425 105 480 minecraft:polished_blackstone_bricks
fill 425 105 481 425 108 481 minecraft:blackstone
setblock 425 105 485 minecraft:polished_blackstone_bricks
fill 425 105 486 425 108 486 minecraft:blackstone
setblock 425 105 489 minecraft:blackstone
setblock 425 105 490 minecraft:polished_blackstone_bricks
fill 425 105 491 425 108 491 minecraft:blackstone
setblock 425 105 494 minecraft:blackstone
setblock 426 105 464 minecraft:polished_blackstone_bricks
fill 426 105 465 426 108 465 minecraft:blackstone
setblock 426 105 468 minecraft:blackstone
setblock 426 105 469 minecraft:polished_blackstone_bricks
fill 426 105 470 427 107 470 minecraft:blackstone
fill 426 105 472 426 105 473 minecraft:blackstone
setblock 426 105 484 minecraft:polished_blackstone_bricks
fill 426 105 485 426 108 485 minecraft:blackstone
setblock 426 105 489 minecraft:polished_blackstone_bricks
fill 426 105 490 426 108 490 minecraft:blackstone
fill 426 105 492 426 106 492 minecraft:blackstone
setblock 426 105 504 minecraft:polished_blackstone_bricks
fill 427 105 464 427 108 464 minecraft:blackstone
setblock 427 105 467 minecraft:blackstone
setblock 427 105 468 minecraft:polished_blackstone_bricks
fill 427 105 469 427 108 469 minecraft:blackstone
setblock 427 105 488 minecraft:polished_blackstone_bricks
fill 427 105 489 427 106 489 minecraft:blackstone
fill 427 105 504 427 107 504 minecraft:blackstone
setblock 428 105 467 minecraft:polished_blackstone_bricks
setblock 429 105 466 minecraft:polished_blackstone_bricks
fill 429 105 467 429 108 467 minecraft:blackstone
setblock 430 105 465 minecraft:polished_blackstone_bricks
fill 430 105 466 430 108 466 minecraft:blackstone
setblock 431 105 464 minecraft:polished_blackstone_bricks
fill 431 105 465 431 108 465 minecraft:blackstone
setblock 431 105 504 minecraft:polished_blackstone_bricks
fill 432 105 464 435 105 464 minecraft:blackstone
setblock 432 105 467 minecraft:blackstone
fill 432 105 504 435 105 504 minecraft:blackstone
setblock 433 105 467 minecraft:polished_blackstone_bricks
setblock 434 105 466 minecraft:polished_blackstone_bricks
fill 434 105 467 434 106 467 minecraft:blackstone
setblock 435 105 465 minecraft:polished_blackstone_bricks
fill 435 105 466 435 107 466 minecraft:blackstone
setblock 436 105 464 minecraft:polished_blackstone_bricks
fill 436 105 465 436 108 465 minecraft:blackstone
setblock 436 105 504 minecraft:polished_blackstone_bricks
fill 437 105 464 437 108 464 minecraft:blackstone
setblock 437 105 504 minecraft:blackstone
setblock 438 105 466 minecraft:blackstone
setblock 439 105 466 minecraft:polished_blackstone_bricks
setblock 440 105 465 minecraft:polished_blackstone_bricks
fill 440 105 466 440 106 466 minecraft:blackstone
setblock 441 105 464 minecraft:polished_blackstone_bricks
fill 441 105 465 441 108 465 minecraft:blackstone
setblock 441 105 504 minecraft:polished_blackstone_bricks
fill 442 105 464 442 108 464 minecraft:blackstone
fill 442 105 504 442 108 504 minecraft:blackstone
setblock 444 105 465 minecraft:blackstone
setblock 444 105 466 minecraft:polished_blackstone_bricks
setblock 445 105 465 minecraft:polished_blackstone_bricks
fill 445 105 466 445 106 467 minecraft:blackstone
setblock 446 105 464 minecraft:polished_blackstone_bricks
fill 446 105 465 446 108 465 minecraft:blackstone
setblock 446 105 504 minecraft:polished_blackstone_bricks
fill 447 105 464 447 108 464 minecraft:blackstone
setblock 447 105 467 minecraft:blackstone
setblock 447 105 503 minecraft:polished_blackstone_bricks
fill 447 105 504 447 108 504 minecraft:blackstone
setblock 448 105 467 minecraft:polished_blackstone_bricks
setblock 448 105 502 minecraft:polished_blackstone_bricks
fill 448 105 503 448 108 503 minecraft:blackstone
setblock 449 105 466 minecraft:polished_blackstone_bricks
fill 449 105 467 449 107 467 minecraft:blackstone
fill 449 105 502 449 107 502 minecraft:blackstone
setblock 450 105 465 minecraft:polished_blackstone_bricks
fill 450 105 466 450 108 466 minecraft:blackstone
setblock 451 105 464 minecraft:polished_blackstone_bricks
fill 451 105 465 451 108 465 minecraft:blackstone
setblock 451 105 467 minecraft:blackstone
setblock 451 105 504 minecraft:polished_blackstone_bricks
fill 452 105 464 452 108 464 minecraft:blackstone
setblock 452 105 503 minecraft:polished_blackstone_bricks
fill 452 105 504 452 108 504 minecraft:blackstone
setblock 453 105 502 minecraft:polished_blackstone_bricks
fill 453 105 503 453 107 503 minecraft:blackstone
setblock 454 105 466 minecraft:polished_blackstone_bricks
setblock 455 105 465 minecraft:polished_blackstone_bricks
setblock 456 105 464 minecraft:polished_blackstone_bricks
setblock 456 105 465 minecraft:blackstone
setblock 456 105 504 minecraft:polished_blackstone_bricks
fill 457 105 464 457 106 464 minecraft:blackstone
fill 457 105 504 457 106 504 minecraft:blackstone
setblock 462 105 487 minecraft:blackstone
setblock 462 105 488 minecraft:polished_blackstone_bricks
fill 462 105 489 462 108 489 minecraft:blackstone
fill 462 105 491 462 106 491 minecraft:blackstone
setblock 463 105 487 minecraft:polished_blackstone_bricks
fill 463 105 488 463 108 488 minecraft:blackstone
setblock 463 105 492 minecraft:polished_blackstone_bricks
fill 463 105 493 463 108 493 minecraft:blackstone
fill 463 105 495 463 106 495 minecraft:blackstone
setblock 464 105 466 minecraft:polished_blackstone_bricks
fill 464 105 467 464 108 467 minecraft:blackstone
setblock 464 105 471 minecraft:polished_blackstone_bricks
fill 464 105 472 464 108 472 minecraft:blackstone
setblock 464 105 481 minecraft:polished_blackstone_bricks
fill 464 105 482 464 108 482 minecraft:blackstone
setblock 464 105 486 minecraft:polished_blackstone_bricks
fill 464 105 487 464 108 487 minecraft:blackstone
setblock 464 105 491 minecraft:polished_blackstone_bricks
fill 464 105 492 464 108 492 minecraft:blackstone
setblock 464 105 496 minecraft:polished_blackstone_bricks
fill 464 105 497 464 108 497 minecraft:blackstone
fill 464 105 499 464 106 499 minecraft:blackstone
setblock 424 106 464 minecraft:blackstone
setblock 424 106 465 minecraft:polished_blackstone_bricks
fill 424 106 466 424 106 469 minecraft:blackstone
setblock 424 106 470 minecraft:polished_blackstone_bricks
fill 424 106 471 424 109 471 minecraft:blackstone
setblock 424 106 475 minecraft:polished_blackstone_bricks
fill 424 106 476 424 109 476 minecraft:blackstone
setblock 424 106 480 minecraft:polished_blackstone_bricks
fill 424 106 481 424 109 481 minecraft:blackstone
setblock 424 106 485 minecraft:polished_blackstone_bricks
fill 424 106 486 424 109 486 minecraft:blackstone
setblock 424 106 490 minecraft:polished_blackstone_bricks
fill 424 106 491 424 109 491 minecraft:blackstone
setblock 424 106 495 minecraft:polished_blackstone_bricks
fill 424 106 496 424 109 496 minecraft:blackstone
setblock 425 106 464 minecraft:polished_blackstone_bricks
fill 425 106 465 425 109 465 minecraft:blackstone
setblock 425 106 468 minecraft:blackstone
setblock 425 106 469 minecraft:polished_blackstone_bricks
fill 425 106 470 425 109 470 minecraft:blackstone
setblock 425 106 474 minecraft:polished_blackstone_bricks
fill 425 106 475 426 108 475 minecraft:blackstone
setblock 425 106 479 minecraft:polished_blackstone_bricks
fill 425 106 480 425 109 480 minecraft:blackstone
setblock 425 106 484 minecraft:polished_blackstone_bricks
fill 425 106 485 425 109 485 minecraft:blackstone
setblock 425 106 489 minecraft:polished_blackstone_bricks
fill 425 106 490 425 109 490 minecraft:blackstone
setblock 425 106 494 minecraft:polished_blackstone_bricks
fill 426 106 464 426 109 464 minecraft:blackstone
setblock 426 106 468 minecraft:polished_blackstone_bricks
fill 426 106 469 426 109 469 minecraft:blackstone
setblock 426 106 472 minecraft:blackstone
setblock 426 106 473 minecraft:polished_blackstone_bricks
fill 426 106 474 426 109 474 minecraft:blackstone
setblock 426 106 483 minecraft:polished_blackstone_bricks
fill 426 106 484 426 107 484 minecraft:blackstone
setblock 426 106 487 minecraft:blackstone
setblock 426 106 488 minecraft:polished_blackstone_bricks
fill 426 106 489 426 109 489 minecraft:blackstone
setblock 426 106 504 minecraft:blackstone
setblock 427 106 467 minecraft:polished_blackstone_bricks
fill 427 106 468 427 109 468 minecraft:blackstone
setblock 427 106 471 minecraft:blackstone
setblock 427 106 472 minecraft:polished_blackstone_bricks
setblock 427 106 487 minecraft:polished_blackstone_bricks
setblock 427 106 488 minecraft:blackstone
setblock 427 106 490 minecraft:blackstone
setblock 428 106 466 minecraft:polished_blackstone_bricks
fill 428 106 467 428 108 467 minecraft:blackstone
setblock 429 106 465 minecraft:polished_blackstone_bricks
fill 429 106 466 429 109 466 minecraft:blackstone
setblock 430 106 464 minecraft:polished_blackstone_bricks
fill 430 106 465 430 109 465 minecraft:blackstone
setblock 430 106 504 minecraft:polished_blackstone_bricks
fill 431 106 464 434 106 464 minecraft:blackstone
fill 431 106 504 434 106 504 minecraft:blackstone
setblock 432 106 467 minecraft:polished_blackstone_bricks
setblock 433 106 466 minecraft:polished_blackstone_bricks
fill 433 106 467 433 107 467 minecraft:blackstone
setblock 434 106 465 minecraft:polished_blackstone_bricks
fill 434 106 466 434 108 466 minecraft:blackstone
setblock 435 106 464 minecraft:polished_blackstone_bricks
fill 435 106 465 435 108 465 minecraft:blackstone
setblock 435 106 504 minecraft:polished_blackstone_bricks
fill 436 106 464 436 109 464 minecraft:blackstone
setblock 438 106 466 minecraft:polished_blackstone_bricks
setblock 439 106 465 minecraft:polished_blackstone_bricks
setblock 439 106 466 minecraft:blackstone
setblock 440 106 464 minecraft:polished_blackstone_bricks
fill 440 106 465 440 108 465 minecraft:blackstone
fill 441 106 464 441 109 464 minecraft:blackstone
fill 441 106 504 441 107 504 minecraft:blackstone
setblock 442 106 466 minecraft:blackstone
setblock 443 106 466 minecraft:polished_blackstone_bricks
setblock 444 106 465 minecraft:polished_blackstone_bricks
fill 444 106 466 444 109 466 minecraft:blackstone
setblock 445 106 464 minecraft:polished_blackstone_bricks
fill 445 106 465 445 109 465 minecraft:blackstone
setblock 445 106 504 minecraft:polished_blackstone_bricks
fill 446 106 464 446 109 464 minecraft:blackstone
setblock 446 106 503 minecraft:polished_blackstone_bricks
fill 446 106 504 446 109 504 minecraft:blackstone
setblock 447 106 467 minecraft:polished_blackstone_bricks
fill 447 106 503 447 109 503 minecraft:blackstone
setblock 448 106 466 minecraft:polished_blackstone_bricks
fill 448 106 467 448 107 467 minecraft:blackstone
setblock 448 106 502 minecraft:blackstone
setblock 449 106 465 minecraft:polished_blackstone_bricks
fill 449 106 466 449 108 466 minecraft:blackstone
setblock 450 106 464 minecraft:polished_blackstone_bricks
fill 450 106 465 450 109 465 minecraft:blackstone
setblock 450 106 504 minecraft:polished_blackstone_bricks
fill 451 106 464 451 109 464 minecraft:blackstone
setblock 451 106 503 minecraft:polished_blackstone_bricks
fill 451 106 504 451 109 504 minecraft:blackstone
fill 452 106 503 452 108 503 minecraft:blackstone
setblock 453 106 466 minecraft:polished_blackstone_bricks
setblock 454 106 465 minecraft:polished_blackstone_bricks
setblock 455 106 464 minecraft:polished_blackstone_bricks
setblock 455 106 465 minecraft:blackstone
setblock 455 106 504 minecraft:polished_blackstone_bricks
fill 456 106 464 456 107 464 minecraft:blackstone
fill 456 106 504 456 107 504 minecraft:blackstone
setblock 462 106 487 minecraft:polished_blackstone_bricks
fill 462 106 488 462 108 488 minecraft:blackstone
setblock 462 106 492 minecraft:polished_blackstone_bricks
setblock 463 106 486 minecraft:polished_blackstone_bricks
fill 463 106 487 463 109 487 minecraft:blackstone
setblock 463 106 491 minecraft:polished_blackstone_bricks
fill 463 106 492 463 109 492 minecraft:blackstone
setblock 464 106 465 minecraft:polished_blackstone_bricks
fill 464 106 466 464 109 466 minecraft:blackstone
fill 464 106 468 464 106 469 minecraft:blackstone
setblock 464 106 470 minecraft:polished_blackstone_bricks
fill 464 106 471 464 109 471 minecraft:blackstone
fill 464 106 473 464 106 474 minecraft:blackstone
setblock 464 106 475 minecraft:polished_blackstone_bricks
setblock 464 106 479 minecraft:blackstone
setblock 464 106 480 minecraft:polished_blackstone_bricks
fill 464 106 481 464 109 481 minecraft:blackstone
setblock 464 106 485 minecraft:polished_blackstone_bricks
fill 464 106 486 464 109 486 minecraft:blackstone
setblock 464 106 490 minecraft:polished_blackstone_bricks
fill 464 106 491 464 109 491 minecraft:blackstone
setblock 464 106 495 minecraft:polished_blackstone_bricks
fill 464 106 496 464 109 496 minecraft:blackstone
setblock 424 107 464 minecraft:polished_blackstone_bricks
fill 424 107 465 424 107 468 minecraft:blackstone
setblock 424 107 469 minecraft:polished_blackstone_bricks
fill 424 107 470 424 110 470 minecraft:blackstone
setblock 424 107 473 minecraft:blackstone
setblock 424 107 474 minecraft:polished_blackstone_bricks
fill 424 107 475 424 110 475 minecraft:blackstone
setblock 424 107 478 minecraft:blackstone
setblock 424 107 479 minecraft:polished_blackstone_bricks
fill 424 107 480 424 110 480 minecraft:blackstone
setblock 424 107 484 minecraft:polished_blackstone_bricks
fill 424 107 485 424 110 485 minecraft:blackstone
setblock 424 107 489 minecraft:polished_blackstone_bricks
fill 424 107 490 424 110 490 minecraft:blackstone
setblock 424 107 493 minecraft:blackstone
setblock 424 107 494 minecraft:polished_blackstone_bricks
fill 424 107 495 425 109 495 minecraft:blackstone
fill 425 107 464 425 110 464 minecraft:blackstone
setblock 425 107 467 minecraft:blackstone
setblock 425 107 468 minecraft:polished_blackstone_bricks
fill 425 107 469 425 110 469 minecraft:blackstone
setblock 425 107 473 minecraft:polished_blackstone_bricks
fill 425 107 474 425 110 474 minecraft:blackstone
setblock 425 107 478 minecraft:polished_blackstone_bricks
fill 425 107 479 425 110 479 minecraft:blackstone
setblock 425 107 483 minecraft:polished_blackstone_bricks
fill 425 107 484 425 110 484 minecraft:blackstone
setblock 425 107 488 minecraft:polished_blackstone_bricks
fill 425 107 489 425 110 489 minecraft:blackstone
setblock 425 107 493 minecraft:polished_blackstone_bricks
fill 425 107 494 425 110 494 minecraft:blackstone
setblock 426 107 467 minecraft:polished_blackstone_bricks
fill 426 107 468 426 110 468 minecraft:blackstone
setblock 426 107 472 minecraft:polished_blackstone_bricks
fill 426 107 473 427 109 473 minecraft:blackstone
setblock 426 107 476 minecraft:blackstone
setblock 426 107 483 minecraft:blackstone
setblock 426 107 487 minecraft:polished_blackstone_bricks
fill 426 107 488 426 109 488 minecraft:blackstone
setblock 426 107 492 minecraft:polished_blackstone_bricks
setblock 426 107 493 minecraft:blackstone
setblock 427 107 466 minecraft:polished_blackstone_bricks
fill 427 107 467 427 108 467 minecraft:blackstone
setblock 427 107 471 minecraft:polished_blackstone_bricks
fill 427 107 472 427 110 472 minecraft:blackstone
setblock 428 107 465 minecraft:polished_blackstone_bricks
fill 428 107 466 428 110 466 minecraft:blackstone
setblock 429 107 464 minecraft:polished_blackstone_bricks
fill 429 107 465 429 110 465 minecraft:blackstone
setblock 429 107 504 minecraft:polished_blackstone_bricks
fill 430 107 464 433 107 464 minecraft:blackstone
fill 430 107 504 433 107 504 minecraft:blackstone
setblock 431 107 467 minecraft:polished_blackstone_bricks
setblock 432 107 466 minecraft:polished_blackstone_bricks
setblock 432 107 467 minecraft:blackstone
setblock 433 107 465 minecraft:polished_blackstone_bricks
fill 433 107 466 433 108 466 minecraft:blackstone
setblock 434 107 464 minecraft:polished_blackstone_bricks
fill 434 107 465 434 109 465 minecraft:blackstone
fill 434 107 497 438 108 501 minecraft:blackstone
fill 435 107 464 435 110 464 minecraft:blackstone
fill 436 107 502 436 107 503 minecraft:blackstone
setblock 438 107 465 minecraft:polished_blackstone_bricks
setblock 439 107 464 minecraft:polished_blackstone_bricks
fill 439 107 465 439 108 465 minecraft:blackstone
fill 440 107 464 440 110 464 minecraft:blackstone
setblock 442 107 466 minecraft:polished_blackstone_bricks
setblock 443 107 465 minecraft:polished_blackstone_bricks
fill 443 107 466 443 108 466 minecraft:blackstone
setblock 444 107 464 minecraft:polished_blackstone_bricks
fill 444 107 465 444 110 465 minecraft:blackstone
setblock 444 107 504 minecraft:polished_blackstone_bricks
fill 445 107 464 445 110 464 minecraft:blackstone
fill 445 107 466 446 107 466 minecraft:blackstone
setblock 445 107 503 minecraft:polished_blackstone_bricks
fill 445 107 504 445 110 504 minecraft:blackstone
setblock 446 107 467 minecraft:polished_blackstone_bricks
fill 446 107 503 446 110 503 minecraft:blackstone
setblock 447 107 466 minecraft:polished_blackstone_bricks
setblock 447 107 467 minecraft:blackstone
setblock 448 107 465 minecraft:polished_blackstone_bricks
fill 448 107 466 448 109 466 minecraft:blackstone
setblock 449 107 464 minecraft:polished_blackstone_bricks
fill 449 107 465 449 110 465 minecraft:blackstone
setblock 449 107 504 minecraft:polished_blackstone_bricks
fill 450 107 464 450 110 464 minecraft:blackstone
setblock 450 107 503 minecraft:polished_blackstone_bricks
fill 450 107 504 450 110 504 minecraft:blackstone
fill 451 107 503 451 109 503 minecraft:blackstone
setblock 452 107 466 minecraft:polished_blackstone_bricks
setblock 453 107 465 minecraft:polished_blackstone_bricks
setblock 454 107 464 minecraft:polished_blackstone_bricks
setblock 454 107 465 minecraft:blackstone
setblock 454 107 504 minecraft:polished_blackstone_bricks
setblock 455 107 464 minecraft:blackstone
setblock 455 107 504 minecraft:blackstone
setblock 462 107 491 minecraft:polished_blackstone_bricks
fill 462 107 492 462 109 493 minecraft:blackstone
setblock 463 107 485 minecraft:polished_blackstone_bricks
fill 463 107 486 463 110 486 minecraft:blackstone
setblock 463 107 490 minecraft:polished_blackstone_bricks
fill 463 107 491 463 110 491 minecraft:blackstone
setblock 463 107 495 minecraft:polished_blackstone_bricks
fill 463 107 496 463 110 496 minecraft:blackstone
setblock 464 107 464 minecraft:polished_blackstone_bricks
fill 464 107 465 464 108 465 minecraft:blackstone
setblock 464 107 468 minecraft:blackstone
setblock 464 107 469 minecraft:polished_blackstone_bricks
fill 464 107 470 464 110 470 minecraft:blackstone
setblock 464 107 473 minecraft:blackstone
setblock 464 107 474 minecraft:polished_blackstone_bricks
fill 464 107 475 464 107 478 minecraft:blackstone
setblock 464 107 479 minecraft:polished_blackstone_bricks
fill 464 107 480 464 110 480 minecraft:blackstone
setblock 464 107 484 minecraft:polished_blackstone_bricks
fill 464 107 485 464 110 485 minecraft:blackstone
setblock 464 107 489 minecraft:polished_blackstone_bricks
fill 464 107 490 464 110 490 minecraft:blackstone
setblock 464 107 494 minecraft:polished_blackstone_bricks
fill 464 107 495 464 110 495 minecraft:blackstone
setblock 464 107 499 minecraft:polished_blackstone_bricks
fill 424 108 464 424 108 467 minecraft:blackstone
setblock 424 108 468 minecraft:polished_blackstone_bricks
fill 424 108 469 424 111 469 minecraft:blackstone
setblock 424 108 473 minecraft:polished_blackstone_bricks
fill 424 108 474 424 111 474 minecraft:blackstone
setblock 424 108 477 minecraft:blackstone
setblock 424 108 478 minecraft:polished_blackstone_bricks
fill 424 108 479 424 111 479 minecraft:blackstone
setblock 424 108 483 minecraft:polished_blackstone_bricks
fill 424 108 484 424 111 484 minecraft:blackstone
setblock 424 108 488 minecraft:polished_blackstone_bricks
fill 424 108 489 424 111 489 minecraft:blackstone
setblock 424 108 493 minecraft:polished_blackstone_bricks
fill 424 108 494 424 111 494 minecraft:blackstone
setblock 424 108 497 minecraft:blackstone
setblock 425 108 467 minecraft:polished_blackstone_bricks
fill 425 108 468 425 111 468 minecraft:blackstone
setblock 425 108 472 minecraft:polished_blackstone_bricks
fill 425 108 473 425 111 473 minecraft:blackstone
setblock 425 108 477 minecraft:polished_blackstone_bricks
fill 425 108 478 425 111 478 minecraft:blackstone
setblock 425 108 482 minecraft:polished_blackstone_bricks
fill 425 108 483 425 109 483 minecraft:blackstone
setblock 425 108 487 minecraft:polished_blackstone_bricks
fill 425 108 488 425 111 488 minecraft:blackstone
setblock 425 108 492 minecraft:polished_blackstone_bricks
fill 425 108 493 425 111 493 minecraft:blackstone
setblock 426 108 466 minecraft:polished_blackstone_bricks
fill 426 108 467 426 111 467 minecraft:blackstone
setblock 426 108 470 minecraft:blackstone
setblock 426 108 471 minecraft:polished_blackstone_bricks
fill 426 108 472 426 111 472 minecraft:blackstone
setblock 426 108 476 minecraft:polished_blackstone_bricks
setblock 426 108 486 minecraft:polished_blackstone_bricks
setblock 426 108 487 minecraft:blackstone
setblock 426 108 491 minecraft:polished_blackstone_bricks
fill 426 108 492 426 109 492 minecraft:blackstone
setblock 427 108 465 minecraft:polished_blackstone_bricks
fill 427 108 466 427 110 466 minecraft:blackstone
setblock 427 108 470 minecraft:polished_blackstone_bricks
fill 427 108 471 427 111 471 minecraft:blackstone
setblock 428 108 464 minecraft:polished_blackstone_bricks
fill 428 108 465 428 111 465 minecraft:blackstone
setblock 428 108 504 minecraft:polished_blackstone_bricks
fill 429 108 464 432 108 464 minecraft:blackstone
fill 429 108 504 430 108 504 minecraft:blackstone
setblock 430 108 467 minecraft:polished_blackstone_bricks
setblock 431 108 466 minecraft:polished_blackstone_bricks
setblock 431 108 467 minecraft:blackstone
setblock 432 108 465 minecraft:polished_blackstone_bricks
fill 432 108 466 432 109 466 minecraft:blackstone
setblock 433 108 464 minecraft:polished_blackstone_bricks
fill 433 108 465 433 109 465 minecraft:blackstone
fill 434 108 464 434 110 464 minecraft:blackstone
setblock 437 108 465 minecraft:polished_blackstone_bricks
setblock 438 108 464 minecraft:polished_blackstone_bricks
setblock 438 108 465 minecraft:blackstone
fill 439 108 464 439 110 464 minecraft:blackstone
setblock 442 108 465 minecraft:polished_blackstone_bricks
setblock 443 108 464 minecraft:polished_blackstone_bricks
fill 443 108 465 443 110 465 minecraft:blackstone
setblock 443 108 504 minecraft:polished_blackstone_bricks
fill 444 108 464 444 111 464 minecraft:blackstone
fill 444 108 504 444 111 504 minecraft:blackstone
setblock 445 108 466 minecraft:blackstone
fill 445 108 503 445 111 503 minecraft:blackstone
setblock 446 108 466 minecraft:polished_blackstone_bricks
setblock 447 108 465 minecraft:polished_blackstone_bricks
fill 447 108 466 447 109 466 minecraft:blackstone
setblock 448 108 464 minecraft:polished_blackstone_bricks
fill 448 108 465 448 110 465 minecraft:blackstone
setblock 448 108 504 minecraft:polished_blackstone_bricks
fill 449 108 464 449 111 464 minecraft:blackstone
setblock 449 108 503 minecraft:polished_blackstone_bricks
fill 449 108 504 449 111 504 minecraft:blackstone
fill 450 108 503 450 109 503 minecraft:blackstone
setblock 452 108 465 minecraft:polished_blackstone_bricks
setblock 453 108 464 minecraft:polished_blackstone_bricks
setblock 453 108 504 minecraft:polished_blackstone_bricks
setblock 454 108 464 minecraft:blackstone
setblock 454 108 504 minecraft:blackstone
setblock 462 108 490 minecraft:polished_blackstone_bricks
fill 462 108 491 462 111 491 minecraft:blackstone
setblock 463 108 484 minecraft:polished_blackstone_bricks
fill 463 108 485 463 109 485 minecraft:blackstone
setblock 463 108 489 minecraft:polished_blackstone_bricks
fill 463 108 490 463 111 490 minecraft:blackstone
setblock 463 108 494 minecraft:polished_blackstone_bricks
fill 463 108 495 463 111 495 minecraft:blackstone
setblock 464 108 468 minecraft:polished_blackstone_bricks
fill 464 108 469 464 111 469 minecraft:blackstone
setblock 464 108 473 minecraft:polished_blackstone_bricks
fill 464 108 474 464 108 477 minecraft:blackstone
setblock 464 108 478 minecraft:polished_blackstone_bricks
fill 464 108 479 464 111 479 minecraft:blackstone
setblock 464 108 483 minecraft:polished_blackstone_bricks
fill 464 108 484 464 111 484 minecraft:blackstone
setblock 464 108 488 minecraft:polished_blackstone_bricks
fill 464 108 489 464 111 489 minecraft:blackstone
setblock 464 108 493 minecraft:polished_blackstone_bricks
fill 464 108 494 464 111 494 minecraft:blackstone
setblock 464 108 498 minecraft:polished_blackstone_bricks
fill 464 108 499 464 111 499 minecraft:blackstone
fill 424 109 464 424 109 466 minecraft:blackstone
setblock 424 109 467 minecraft:polished_blackstone_bricks
fill 424 109 468 424 112 468 minecraft:blackstone
setblock 424 109 472 minecraft:polished_blackstone_bricks
fill 424 109 473 424 112 473 minecraft:blackstone
setblock 424 109 477 minecraft:polished_blackstone_bricks
fill 424 109 478 424 112 478 minecraft:blackstone
setblock 424 109 482 minecraft:polished_blackstone_bricks
fill 424 109 483 424 112 483 minecraft:blackstone
setblock 424 109 487 minecraft:polished_blackstone_bricks
fill 424 109 488 424 112 488 minecraft:blackstone
setblock 424 109 492 minecraft:polished_blackstone_bricks
fill 424 109 493 424 112 493 minecraft:blackstone
setblock 424 109 497 minecraft:polished_blackstone_bricks
setblock 425 109 466 minecraft:polished_blackstone_bricks
fill 425 109 467 425 112 467 minecraft:blackstone
setblock 425 109 471 minecraft:polished_blackstone_bricks
fill 425 109 472 425 112 472 minecraft:blackstone
setblock 425 109 475 minecraft:blackstone
setblock 425 109 476 minecraft:polished_blackstone_bricks
fill 425 109 477 426 111 477 minecraft:blackstone
setblock 425 109 481 minecraft:polished_blackstone_bricks
setblock 425 109 482 minecraft:blackstone
setblock 425 109 486 minecraft:polished_blackstone_bricks
fill 425 109 487 425 111 487 minecraft:blackstone
setblock 425 109 491 minecraft:polished_blackstone_bricks
fill 425 109 492 425 112 492 minecraft:blackstone
setblock 426 109 465 minecraft:polished_blackstone_bricks
setblock 426 109 466 minecraft:blackstone
setblock 426 109 470 minecraft:polished_blackstone_bricks
fill 426 109 471 426 112 471 minecraft:blackstone
setblock 426 109 475 minecraft:polished_blackstone_bricks
fill 426 109 476 426 112 476 minecraft:blackstone
setblock 426 109 490 minecraft:polished_blackstone_bricks
setblock 426 109 491 minecraft:blackstone
setblock 427 109 464 minecraft:polished_blackstone_bricks
fill 427 109 465 427 112 465 minecraft:blackstone
setblock 427 109 469 minecraft:polished_blackstone_bricks
fill 427 109 470 427 111 470 minecraft:blackstone
setblock 427 109 474 minecraft:polished_blackstone_bricks
fill 428 109 464 431 109 464 minecraft:blackstone
setblock 430 109 466 minecraft:polished_blackstone_bricks
setblock 431 109 465 minecraft:polished_blackstone_bricks
setblock 431 109 466 minecraft:blackstone
setblock 432 109 464 minecraft:polished_blackstone_bricks
fill 432 109 465 432 110 465 minecraft:blackstone
fill 433 109 464 433 110 464 minecraft:blackstone
fill 435 109 499 437 113 499 minecraft:polished_blackstone_bricks
setblock 437 109 464 minecraft:polished_blackstone_bricks
setblock 438 109 464 minecraft:blackstone
setblock 441 109 465 minecraft:polished_blackstone_bricks
setblock 442 109 464 minecraft:polished_blackstone_bricks
fill 442 109 465 442 110 465 minecraft:blackstone
setblock 442 109 504 minecraft:polished_blackstone_bricks
fill 443 109 464 443 112 464 minecraft:blackstone
fill 443 109 504 443 112 504 minecraft:blackstone
setblock 445 109 466 minecraft:polished_blackstone_bricks
setblock 446 109 465 minecraft:polished_blackstone_bricks
setblock 446 109 466 minecraft:blackstone
setblock 447 109 464 minecraft:polished_blackstone_bricks
fill 447 109 465 447 111 465 minecraft:blackstone
setblock 447 109 504 minecraft:polished_blackstone_bricks
fill 448 109 464 448 112 464 minecraft:blackstone
setblock 448 109 503 minecraft:polished_blackstone_bricks
fill 448 109 504 448 112 504 minecraft:blackstone
fill 449 109 503 449 110 503 minecraft:blackstone
setblock 451 109 465 minecraft:polished_blackstone_bricks
setblock 452 109 464 minecraft:polished_blackstone_bricks
setblock 452 109 504 minecraft:polished_blackstone_bricks
setblock 453 109 504 minecraft:blackstone
setblock 462 109 489 minecraft:polished_blackstone_bricks
fill 462 109 490 462 110 490 minecraft:blackstone
setblock 463 109 488 minecraft:polished_blackstone_bricks
fill 463 109 489 463 112 489 minecraft:blackstone
setblock 463 109 493 minecraft:polished_blackstone_bricks
fill 463 109 494 463 112 494 minecraft:blackstone
setblock 464 109 467 minecraft:polished_blackstone_bricks
fill 464 109 468 464 112 468 minecraft:blackstone
setblock 464 109 472 minecraft:polished_blackstone_bricks
fill 464 109 473 464 109 476 minecraft:blackstone
setblock 464 109 477 minecraft:polished_blackstone_bricks
fill 464 109 478 464 112 478 minecraft:blackstone
setblock 464 109 482 minecraft:polished_blackstone_bricks
fill 464 109 483 464 112 483 minecraft:blackstone
setblock 464 109 487 minecraft:polished_blackstone_bricks
fill 464 109 488 464 112 488 minecraft:blackstone
setblock 464 109 492 minecraft:polished_blackstone_bricks
fill 464 109 493 464 112 493 minecraft:blackstone
setblock 464 109 497 minecraft:polished_blackstone_bricks
fill 464 109 498 464 112 498 minecraft:blackstone
fill 424 110 464 424 110 465 minecraft:blackstone
setblock 424 110 466 minecraft:polished_blackstone_bricks
fill 424 110 467 424 113 467 minecraft:blackstone
setblock 424 110 471 minecraft:polished_blackstone_bricks
fill 424 110 472 424 113 472 minecraft:blackstone
setblock 424 110 476 minecraft:polished_blackstone_bricks
fill 424 110 477 424 113 477 minecraft:blackstone
setblock 424 110 481 minecraft:polished_blackstone_bricks
fill 424 110 482 424 113 482 minecraft:blackstone
setblock 424 110 486 minecraft:polished_blackstone_bricks
fill 424 110 487 424 113 487 minecraft:blackstone
setblock 424 110 491 minecraft:polished_blackstone_bricks
fill 424 110 492 424 113 492 minecraft:blackstone
setblock 424 110 495 minecraft:blackstone
setblock 424 110 496 minecraft:polished_blackstone_bricks
fill 424 110 497 424 113 497 minecraft:blackstone
setblock 425 110 465 minecraft:polished_blackstone_bricks
fill 425 110 466 425 113 466 minecraft:blackstone
setblock 425 110 470 minecraft:polished_blackstone_bricks
fill 425 110 471 425 113 471 minecraft:blackstone
setblock 425 110 475 minecraft:polished_blackstone_bricks
fill 425 110 476 425 113 476 minecraft:blackstone
setblock 425 110 480 minecraft:polished_blackstone_bricks
setblock 425 110 481 minecraft:blackstone
setblock 425 110 485 minecraft:polished_blackstone_bricks
setblock 425 110 486 minecraft:blackstone
setblock 425 110 490 minecraft:polished_blackstone_bricks
fill 425 110 491 425 113 491 minecraft:blackstone
setblock 425 110 495 minecraft:polished_blackstone_bricks
setblock 426 110 464 minecraft:polished_blackstone_bricks
fill 426 110 465 426 112 465 minecraft:blackstone
setblock 426 110 469 minecraft:polished_blackstone_bricks
fill 426 110 470 426 113 470 minecraft:blackstone
setblock 426 110 473 minecraft:blackstone
setblock 426 110 474 minecraft:polished_blackstone_bricks
fill 426 110 475 426 113 475 minecraft:blackstone
fill 427 110 464 430 110 464 minecraft:blackstone
setblock 427 110 469 minecraft:blackstone
setblock 427 110 473 minecraft:polished_blackstone_bricks
fill 427 110 474 427 113 474 minecraft:blackstone
setblock 429 110 466 minecraft:polished_blackstone_bricks
setblock 430 110 465 minecraft:polished_blackstone_bricks
setblock 431 110 464 minecraft:polished_blackstone_bricks
setblock 431 110 465 minecraft:blackstone
fill 432 110 464 432 111 464 minecraft:blackstone
setblock 441 110 464 minecraft:polished_blackstone_bricks
fill 442 110 464 442 113 464 minecraft:blackstone
fill 442 110 504 442 113 504 minecraft:blackstone
setblock 445 110 465 minecraft:polished_blackstone_bricks
setblock 446 110 464 minecraft:polished_blackstone_bricks
fill 446 110 465 446 111 465 minecraft:blackstone
setblock 446 110 504 minecraft:polished_blackstone_bricks
fill 447 110 464 447 113 464 minecraft:blackstone
setblock 447 110 503 minecraft:polished_blackstone_bricks
fill 447 110 504 447 113 504 minecraft:blackstone
fill 448 110 503 448 113 503 minecraft:blackstone
setblock 451 110 464 minecraft:polished_blackstone_bricks
setblock 451 110 504 minecraft:polished_blackstone_bricks
setblock 452 110 504 minecraft:blackstone
setblock 462 110 492 minecraft:blackstone
setblock 462 110 493 minecraft:polished_blackstone_bricks
setblock 463 110 472 minecraft:polished_blackstone_bricks
setblock 463 110 487 minecraft:polished_blackstone_bricks
fill 463 110 488 463 113 488 minecraft:blackstone
setblock 463 110 492 minecraft:polished_blackstone_bricks
fill 463 110 493 463 113 493 minecraft:blackstone
setblock 463 110 497 minecraft:polished_blackstone_bricks
setblock 464 110 466 minecraft:polished_blackstone_bricks
fill 464 110 467 464 113 467 minecraft:blackstone
setblock 464 110 471 minecraft:polished_blackstone_bricks
fill 464 110 472 464 110 475 minecraft:blackstone
setblock 464 110 476 minecraft:polished_blackstone_bricks
fill 464 110 477 464 113 477 minecraft:blackstone
setblock 464 110 481 minecraft:polished_blackstone_bricks
fill 464 110 482 464 113 482 minecraft:blackstone
setblock 464 110 486 minecraft:polished_blackstone_bricks
fill 464 110 487 464 113 487 minecraft:blackstone
setblock 464 110 491 minecraft:polished_blackstone_bricks
fill 464 110 492 464 113 492 minecraft:blackstone
setblock 464 110 496 minecraft:polished_blackstone_bricks
fill 464 110 497 464 113 497 minecraft:blackstone
setblock 424 111 464 minecraft:blackstone
setblock 424 111 465 minecraft:polished_blackstone_bricks
fill 424 111 466 424 113 466 minecraft:blackstone
setblock 424 111 470 minecraft:polished_blackstone_bricks
fill 424 111 471 424 113 471 minecraft:blackstone
setblock 424 111 475 minecraft:polished_blackstone_bricks
fill 424 111 476 424 113 476 minecraft:blackstone
setblock 424 111 480 minecraft:polished_blackstone_bricks
fill 424 111 481 424 113 481 minecraft:blackstone
setblock 424 111 485 minecraft:polished_blackstone_bricks
fill 424 111 486 424 113 486 minecraft:blackstone
setblock 424 111 490 minecraft:polished_blackstone_bricks
fill 424 111 491 424 113 491 minecraft:blackstone
setblock 424 111 495 minecraft:polished_blackstone_bricks
fill 424 111 496 424 113 496 minecraft:blackstone
fill 424 111 498 424 112 498 minecraft:blackstone
setblock 425 111 464 minecraft:polished_blackstone_bricks
setblock 425 111 469 minecraft:polished_blackstone_bricks
fill 425 111 470 425 113 470 minecraft:blackstone
setblock 425 111 474 minecraft:polished_blackstone_bricks
fill 425 111 475 425 113 475 minecraft:blackstone
setblock 425 111 479 minecraft:polished_blackstone_bricks
fill 425 111 480 425 113 480 minecraft:blackstone
setblock 425 111 489 minecraft:polished_blackstone_bricks
fill 425 111 490 425 113 490 minecraft:blackstone
setblock 425 111 494 minecraft:polished_blackstone_bricks
fill 425 111 495 425 113 495 minecraft:blackstone
fill 426 111 464 429 111 464 minecraft:blackstone
setblock 426 111 468 minecraft:polished_blackstone_bricks
fill 426 111 469 426 113 469 minecraft:blackstone
setblock 426 111 473 minecraft:polished_blackstone_bricks
fill 426 111 474 426 113 474 minecraft:blackstone
setblock 427 111 472 minecraft:polished_blackstone_bricks
fill 427 111 473 427 113 473 minecraft:blackstone
setblock 429 111 465 minecraft:polished_blackstone_bricks
setblock 430 111 464 minecraft:polished_blackstone_bricks
setblock 430 111 465 minecraft:blackstone
fill 431 111 464 431 112 464 minecraft:blackstone
setblock 440 111 464 minecraft:polished_blackstone_bricks
fill 441 111 464 441 113 464 minecraft:blackstone
setblock 444 111 465 minecraft:polished_blackstone_bricks
setblock 445 111 464 minecraft:polished_blackstone_bricks
setblock 445 111 465 minecraft:blackstone
setblock 445 111 504 minecraft:polished_blackstone_bricks
fill 446 111 464 446 113 464 minecraft:blackstone
setblock 446 111 503 minecraft:polished_blackstone_bricks
fill 446 111 504 446 113 504 minecraft:blackstone
fill 447 111 503 447 113 503 minecraft:blackstone
setblock 450 111 464 minecraft:polished_blackstone_bricks
setblock 450 111 504 minecraft:polished_blackstone_bricks
setblock 451 111 504 minecraft:blackstone
setblock 462 111 492 minecraft:polished_blackstone_bricks
fill 462 111 493 462 113 493 minecraft:blackstone
setblock 463 111 471 minecraft:polished_blackstone_bricks
fill 463 111 472 463 111 475 minecraft:blackstone
setblock 463 111 486 minecraft:polished_blackstone_bricks
fill 463 111 487 463 113 487 minecraft:blackstone
setblock 463 111 491 minecraft:polished_blackstone_bricks
fill 463 111 492 463 113 492 minecraft:blackstone
setblock 463 111 496 minecraft:polished_blackstone_bricks
fill 463 111 497 463 113 497 minecraft:blackstone
setblock 464 111 470 minecraft:polished_blackstone_bricks
fill 464 111 471 464 111 474 minecraft:blackstone
setblock 464 111 475 minecraft:polished_blackstone_bricks
fill 464 111 476 464 113 476 minecraft:blackstone
setblock 464 111 480 minecraft:polished_blackstone_bricks
fill 464 111 481 464 113 481 minecraft:blackstone
setblock 464 111 485 minecraft:polished_blackstone_bricks
fill 464 111 486 464 113 486 minecraft:blackstone
setblock 464 111 490 minecraft:polished_blackstone_bricks
fill 464 111 491 464 113 491 minecraft:blackstone
setblock 464 111 495 minecraft:polished_blackstone_bricks
fill 464 111 496 464 113 496 minecraft:blackstone
setblock 424 112 464 minecraft:polished_blackstone_bricks
fill 424 112 465 424 113 465 minecraft:blackstone
setblock 424 112 469 minecraft:polished_blackstone_bricks
fill 424 112 470 424 113 470 minecraft:blackstone
setblock 424 112 474 minecraft:polished_blackstone_bricks
fill 424 112 475 424 113 475 minecraft:blackstone
setblock 424 112 479 minecraft:polished_blackstone_bricks
fill 424 112 480 424 113 480 minecraft:blackstone
setblock 424 112 484 minecraft:polished_blackstone_bricks
fill 424 112 485 424 113 485 minecraft:blackstone
setblock 424 112 489 minecraft:polished_blackstone_bricks
fill 424 112 490 424 113 490 minecraft:blackstone
setblock 424 112 494 minecraft:polished_blackstone_bricks
fill 424 112 495 424 113 495 minecraft:blackstone
fill 425 112 464 428 112 464 minecraft:blackstone
setblock 425 112 468 minecraft:polished_blackstone_bricks
fill 425 112 469 425 113 469 minecraft:blackstone
setblock 425 112 473 minecraft:polished_blackstone_bricks
fill 425 112 474 425 113 474 minecraft:blackstone
setblock 425 112 477 minecraft:blackstone
setblock 425 112 478 minecraft:polished_blackstone_bricks
fill 425 112 479 425 113 479 minecraft:blackstone
fill 425 112 481 425 113 481 minecraft:blackstone
setblock 425 112 489 minecraft:blackstone
setblock 425 112 493 minecraft:polished_blackstone_bricks
fill 425 112 494 425 113 494 minecraft:blackstone
fill 425 112 496 425 113 496 minecraft:blackstone
setblock 426 112 466 minecraft:light[level=11]
fill 426 112 468 426 113 468 minecraft:blackstone
setblock 426 112 472 minecraft:polished_blackstone_bricks
fill 426 112 473 426 113 473 minecraft:blackstone
setblock 426 112 477 minecraft:polished_blackstone_bricks
setblock 426 112 482 minecraft:light[level=11]
setblock 426 112 490 minecraft:light[level=11]
setblock 426 112 498 minecraft:light[level=11]
setblock 427 112 471 minecraft:polished_blackstone_bricks
fill 427 112 472 427 113 472 minecraft:blackstone
setblock 428 112 465 minecraft:polished_blackstone_bricks
setblock 429 112 464 minecraft:polished_blackstone_bricks
fill 430 112 464 430 113 464 minecraft:blackstone
setblock 434 112 466 minecraft:light[level=11]
setblock 434 112 474 minecraft:light[level=11]
setblock 434 112 482 minecraft:light[level=11]
setblock 434 112 490 minecraft:light[level=11]
setblock 434 112 498 minecraft:light[level=11]
fill 436 112 498 436 113 498 minecraft:polished_blackstone_bricks
fill 436 112 500 436 113 500 minecraft:polished_blackstone_bricks
setblock 442 112 466 minecraft:light[level=11]
setblock 442 112 474 minecraft:light[level=11]
setblock 442 112 482 minecraft:light[level=11]
setblock 442 112 490 minecraft:light[level=11]
setblock 442 112 498 minecraft:light[level=11]
setblock 444 112 464 minecraft:polished_blackstone_bricks
setblock 444 112 504 minecraft:polished_blackstone_bricks
fill 445 112 464 445 113 464 minecraft:blackstone
setblock 445 112 503 minecraft:polished_blackstone_bricks
fill 445 112 504 445 113 504 minecraft:blackstone
fill 446 112 503 446 113 503 minecraft:blackstone
setblock 449 112 504 minecraft:polished_blackstone_bricks
setblock 450 112 466 minecraft:light[level=11]
setblock 450 112 474 minecraft:light[level=11]
setblock 450 112 482 minecraft:light[level=11]
setblock 450 112 490 minecraft:light[level=11]
setblock 450 112 498 minecraft:light[level=11]
fill 450 112 504 450 113 504 minecraft:blackstone
setblock 458 112 466 minecraft:light[level=11]
setblock 458 112 474 minecraft:light[level=11]
setblock 458 112 482 minecraft:light[level=11]
setblock 458 112 490 minecraft:light[level=11]
setblock 458 112 498 minecraft:light[level=11]
setblock 462 112 491 minecraft:polished_blackstone_bricks
fill 462 112 492 462 113 492 minecraft:blackstone
fill 462 112 494 462 113 494 minecraft:blackstone
fill 463 112 471 463 112 474 minecraft:blackstone
setblock 463 112 475 minecraft:polished_blackstone_bricks
fill 463 112 476 463 113 477 minecraft:blackstone
fill 463 112 486 463 113 486 minecraft:blackstone
setblock 463 112 490 minecraft:polished_blackstone_bricks
fill 463 112 491 463 113 491 minecraft:blackstone
setblock 463 112 495 minecraft:polished_blackstone_bricks
fill 463 112 496 463 113 496 minecraft:blackstone
setblock 464 112 469 minecraft:polished_blackstone_bricks
fill 464 112 470 464 112 473 minecraft:blackstone
setblock 464 112 474 minecraft:polished_blackstone_bricks
fill 464 112 475 464 113 475 minecraft:blackstone
setblock 464 112 479 minecraft:polished_blackstone_bricks
fill 464 112 480 464 113 480 minecraft:blackstone
setblock 464 112 484 minecraft:polished_blackstone_bricks
fill 464 112 485 464 113 485 minecraft:blackstone
setblock 464 112 489 minecraft:polished_blackstone_bricks
fill 464 112 490 464 113 490 minecraft:blackstone
setblock 464 112 494 minecraft:polished_blackstone_bricks
fill 464 112 495 464 113 495 minecraft:blackstone
setblock 464 112 499 minecraft:polished_blackstone_bricks
fill 464 112 500 464 113 500 minecraft:blackstone
fill 424 113 464 427 113 464 minecraft:blackstone
setblock 424 113 468 minecraft:polished_blackstone_bricks
setblock 424 113 469 minecraft:blackstone
setblock 424 113 473 minecraft:polished_blackstone_bricks
setblock 424 113 474 minecraft:blackstone
setblock 424 113 478 minecraft:polished_blackstone_bricks
setblock 424 113 479 minecraft:blackstone
setblock 424 113 483 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/117_3 1t
