fill 493 204 457 495 204 457 minecraft:red_nether_bricks
setblock 494 204 416 minecraft:orange_concrete
fill 494 204 458 494 209 458 minecraft:netherrack
fill 495 204 416 496 209 416 minecraft:netherrack
fill 495 204 417 497 204 417 minecraft:red_nether_bricks
fill 497 204 416 498 205 416 minecraft:orange_concrete
fill 497 204 457 499 204 457 minecraft:red_nether_bricks
fill 499 204 417 501 204 417 minecraft:red_nether_bricks
fill 500 204 458 501 205 458 minecraft:orange_concrete
fill 501 204 457 503 204 457 minecraft:red_nether_bricks
fill 502 204 458 503 209 458 minecraft:netherrack
fill 503 204 416 504 209 416 minecraft:netherrack
fill 503 204 417 505 204 417 minecraft:red_nether_bricks
fill 505 204 416 506 204 416 minecraft:orange_concrete
fill 505 204 457 507 204 457 minecraft:red_nether_bricks
fill 507 204 416 507 209 416 minecraft:netherrack
fill 507 204 417 509 204 417 minecraft:red_nether_bricks
fill 509 204 457 511 204 457 minecraft:red_nether_bricks
fill 511 204 417 511 204 419 minecraft:red_nether_bricks
fill 511 204 421 511 204 423 minecraft:red_nether_bricks
fill 511 204 425 511 204 427 minecraft:red_nether_bricks
fill 511 204 429 511 204 431 minecraft:red_nether_bricks
fill 511 204 433 511 204 435 minecraft:red_nether_bricks
fill 511 204 437 511 204 439 minecraft:red_nether_bricks
fill 511 204 441 511 204 443 minecraft:red_nether_bricks
fill 511 204 445 511 204 447 minecraft:red_nether_bricks
fill 511 204 449 511 204 451 minecraft:red_nether_bricks
fill 511 204 453 511 204 455 minecraft:red_nether_bricks
fill 511 204 458 511 209 458 minecraft:netherrack
fill 512 204 419 512 209 420 minecraft:netherrack
fill 512 204 421 512 205 422 minecraft:orange_concrete
fill 512 204 428 512 209 428 minecraft:netherrack
fill 512 204 429 512 204 430 minecraft:orange_concrete
fill 512 204 431 512 205 432 minecraft:netherrack
fill 512 204 433 512 205 433 minecraft:orange_concrete
fill 512 204 439 512 209 440 minecraft:netherrack
fill 512 204 441 512 205 442 minecraft:orange_concrete
setblock 512 204 450 minecraft:orange_concrete
fill 512 204 451 512 209 452 minecraft:netherrack
fill 512 204 453 512 205 454 minecraft:orange_concrete
fill 512 204 458 512 205 458 minecraft:orange_concrete
setblock 470 205 416 minecraft:orange_concrete
fill 470 205 417 470 208 417 minecraft:netherrack
fill 470 205 428 470 208 428 minecraft:netherrack
setblock 470 205 433 minecraft:orange_concrete
setblock 470 205 444 minecraft:orange_concrete
fill 470 205 448 470 208 449 minecraft:netherrack
fill 473 205 416 474 208 416 minecraft:netherrack
setblock 477 205 458 minecraft:orange_concrete
setblock 478 205 416 minecraft:orange_concrete
setblock 480 205 458 minecraft:orange_concrete
fill 481 205 458 481 208 458 minecraft:netherrack
fill 482 205 423 482 210 425 minecraft:red_nether_bricks
fill 483 205 422 483 208 422 minecraft:red_nether_bricks
fill 483 205 441 484 206 442 minecraft:shroomlight
fill 484 205 426 485 208 426 minecraft:red_nether_bricks
setblock 488 205 458 minecraft:orange_concrete
setblock 489 205 416 minecraft:orange_concrete
fill 492 205 458 492 208 458 minecraft:netherrack
fill 494 205 416 494 208 416 minecraft:netherrack
fill 505 205 416 505 208 416 minecraft:netherrack
setblock 506 205 416 minecraft:orange_concrete
fill 508 205 458 509 205 458 minecraft:orange_concrete
fill 509 205 416 510 205 416 minecraft:orange_concrete
fill 512 205 429 512 207 430 minecraft:netherrack
setblock 512 205 434 minecraft:orange_concrete
setblock 512 205 445 minecraft:orange_concrete
fill 512 205 450 512 207 450 minecraft:netherrack
fill 470 206 416 470 211 416 minecraft:netherrack
fill 470 206 422 470 207 423 minecraft:orange_concrete
fill 470 206 424 470 211 425 minecraft:netherrack
fill 470 206 433 470 211 433 minecraft:netherrack
fill 470 206 434 470 206 435 minecraft:orange_concrete
fill 470 206 436 470 211 437 minecraft:netherrack
fill 470 206 442 470 207 443 minecraft:orange_concrete
fill 470 206 444 470 211 445 minecraft:netherrack
setblock 470 206 446 minecraft:orange_concrete
fill 470 206 454 470 207 455 minecraft:orange_concrete
fill 470 206 456 470 211 457 minecraft:netherrack
fill 475 206 458 475 207 458 minecraft:orange_concrete
setblock 476 206 416 minecraft:orange_concrete
fill 477 206 416 478 211 416 minecraft:netherrack
fill 477 206 458 477 211 458 minecraft:netherrack
fill 478 206 458 479 206 458 minecraft:orange_concrete
fill 479 206 416 480 207 416 minecraft:orange_concrete
fill 480 206 458 480 211 458 minecraft:netherrack
fill 481 206 424 481 211 425 minecraft:red_nether_bricks
fill 482 206 422 482 207 422 minecraft:red_nether_bricks
fill 482 206 426 483 211 426 minecraft:red_nether_bricks
fill 485 206 416 486 211 416 minecraft:netherrack
fill 486 206 425 486 207 425 minecraft:red_nether_bricks
fill 486 206 458 487 207 458 minecraft:orange_concrete
fill 487 206 416 488 206 416 minecraft:orange_concrete
fill 488 206 458 489 211 458 minecraft:netherrack
fill 489 206 416 489 211 416 minecraft:netherrack
fill 497 206 416 498 211 416 minecraft:netherrack
fill 498 206 458 499 206 458 minecraft:orange_concrete
fill 499 206 416 500 207 416 minecraft:orange_concrete
fill 500 206 458 501 211 458 minecraft:netherrack
fill 506 206 416 506 211 416 minecraft:netherrack
fill 507 206 458 507 207 458 minecraft:orange_concrete
setblock 508 206 416 minecraft:orange_concrete
fill 508 206 458 509 211 458 minecraft:netherrack
fill 509 206 416 510 211 416 minecraft:netherrack
setblock 510 206 458 minecraft:orange_concrete
fill 511 206 416 511 207 416 minecraft:orange_concrete
fill 512 206 421 512 211 422 minecraft:netherrack
fill 512 206 423 512 207 424 minecraft:orange_concrete
fill 512 206 431 512 209 431 minecraft:netherrack
setblock 512 206 432 minecraft:orange_concrete
fill 512 206 433 512 211 434 minecraft:netherrack
fill 512 206 435 512 207 436 minecraft:orange_concrete
fill 512 206 441 512 208 442 minecraft:netherrack
fill 512 206 443 512 206 444 minecraft:orange_concrete
fill 512 206 445 512 211 445 minecraft:netherrack
fill 512 206 447 512 207 447 minecraft:orange_concrete
setblock 512 206 448 minecraft:netherrack
fill 512 206 453 512 211 454 minecraft:netherrack
fill 512 206 455 512 207 456 minecraft:orange_concrete
fill 512 206 458 512 211 458 minecraft:netherrack
fill 470 207 430 470 207 431 minecraft:orange_concrete
setblock 470 207 434 minecraft:orange_concrete
fill 470 207 435 470 210 435 minecraft:netherrack
fill 470 207 446 470 210 446 minecraft:netherrack
setblock 470 207 451 minecraft:orange_concrete
setblock 471 207 416 minecraft:orange_concrete
setblock 474 207 458 minecraft:orange_concrete
fill 476 207 416 476 210 416 minecraft:netherrack
fill 478 207 458 479 210 458 minecraft:netherrack
fill 481 207 423 481 209 423 minecraft:red_nether_bricks
fill 481 207 426 481 213 426 minecraft:red_nether_bricks
fill 482 207 427 483 211 427 minecraft:red_nether_bricks
setblock 486 207 423 minecraft:red_nether_bricks
fill 487 207 416 487 210 416 minecraft:netherrack
setblock 488 207 416 minecraft:orange_concrete
fill 491 207 416 492 207 416 minecraft:orange_concrete
setblock 495 207 458 minecraft:orange_concrete
setblock 498 207 458 minecraft:orange_concrete
fill 499 207 458 499 210 458 minecraft:netherrack
setblock 506 207 458 minecraft:orange_concrete
fill 508 207 416 508 210 416 minecraft:netherrack
fill 510 207 458 510 210 458 minecraft:netherrack
setblock 512 207 416 minecraft:orange_concrete
setblock 512 207 427 minecraft:orange_concrete
fill 512 207 432 512 209 432 minecraft:netherrack
fill 512 207 443 512 210 443 minecraft:netherrack
setblock 512 207 444 minecraft:orange_concrete
setblock 512 207 448 minecraft:orange_concrete
fill 470 208 420 470 208 421 minecraft:orange_concrete
fill 470 208 422 470 213 423 minecraft:netherrack
fill 470 208 429 470 209 429 minecraft:orange_concrete
fill 470 208 430 470 213 431 minecraft:netherrack
setblock 470 208 432 minecraft:orange_concrete
fill 470 208 434 470 213 434 minecraft:netherrack
fill 470 208 440 470 209 441 minecraft:orange_concrete
fill 470 208 442 470 213 443 minecraft:netherrack
fill 470 208 451 470 213 451 minecraft:netherrack
fill 470 208 452 470 208 453 minecraft:orange_concrete
fill 470 208 454 470 213 455 minecraft:netherrack
fill 471 208 416 471 213 416 minecraft:netherrack
fill 472 208 458 473 209 458 minecraft:orange_concrete
setblock 473 208 419 minecraft:light[level=14]
setblock 473 208 427 minecraft:light[level=14]
setblock 473 208 435 minecraft:light[level=14]
setblock 473 208 443 minecraft:light[level=14]
setblock 473 208 451 minecraft:light[level=14]
fill 474 208 458 475 213 458 minecraft:netherrack
setblock 476 208 458 minecraft:orange_concrete
fill 479 208 416 480 213 416 minecraft:netherrack
fill 480 208 424 480 211 427 minecraft:red_nether_bricks
fill 481 208 416 482 209 416 minecraft:orange_concrete
setblock 481 208 419 minecraft:light[level=14]
fill 481 208 427 481 214 427 minecraft:red_nether_bricks
setblock 481 208 435 minecraft:light[level=14]
setblock 481 208 443 minecraft:light[level=14]
setblock 481 208 451 minecraft:light[level=14]
fill 484 208 458 485 209 458 minecraft:orange_concrete
fill 486 208 458 487 213 458 minecraft:netherrack
fill 488 208 416 488 213 416 minecraft:netherrack
setblock 489 208 419 minecraft:light[level=14]
setblock 489 208 427 minecraft:light[level=14]
setblock 489 208 435 minecraft:light[level=14]
setblock 489 208 443 minecraft:light[level=14]
setblock 489 208 451 minecraft:light[level=14]
setblock 490 208 416 minecraft:orange_concrete
fill 491 208 416 492 213 416 minecraft:netherrack
fill 493 208 416 493 209 416 minecraft:orange_concrete
fill 493 208 458 493 209 458 minecraft:orange_concrete
fill 495 208 458 495 213 458 minecraft:netherrack
fill 496 208 458 497 208 458 minecraft:orange_concrete
setblock 497 208 419 minecraft:light[level=14]
setblock 497 208 427 minecraft:light[level=14]
setblock 497 208 435 minecraft:light[level=14]
setblock 497 208 443 minecraft:light[level=14]
setblock 497 208 451 minecraft:light[level=14]
fill 498 208 458 498 213 458 minecraft:netherrack
fill 499 208 416 500 213 416 minecraft:netherrack
fill 501 208 416 502 208 416 minecraft:orange_concrete
fill 504 208 458 505 209 458 minecraft:orange_concrete
setblock 505 208 419 minecraft:light[level=14]
setblock 505 208 435 minecraft:light[level=14]
setblock 505 208 443 minecraft:light[level=14]
setblock 505 208 451 minecraft:light[level=14]
fill 506 208 458 507 213 458 minecraft:netherrack
fill 511 208 416 512 213 416 minecraft:netherrack
fill 512 208 417 512 209 418 minecraft:orange_concrete
fill 512 208 423 512 210 424 minecraft:netherrack
fill 512 208 425 512 208 426 minecraft:orange_concrete
fill 512 208 427 512 213 427 minecraft:netherrack
fill 512 208 429 512 209 429 minecraft:orange_concrete
setblock 512 208 430 minecraft:netherrack
fill 512 208 435 512 213 436 minecraft:netherrack
fill 512 208 437 512 209 438 minecraft:orange_concrete
fill 512 208 444 512 210 444 minecraft:netherrack
setblock 512 208 446 minecraft:orange_concrete
fill 512 208 447 512 213 448 minecraft:netherrack
fill 512 208 449 512 209 450 minecraft:orange_concrete
fill 512 208 455 512 213 456 minecraft:netherrack
setblock 512 208 457 minecraft:orange_concrete
setblock 470 209 417 minecraft:orange_concrete
setblock 470 209 420 minecraft:orange_concrete
fill 470 209 421 470 212 421 minecraft:netherrack
setblock 470 209 428 minecraft:orange_concrete
fill 470 209 432 470 212 432 minecraft:netherrack
fill 470 209 448 470 209 449 minecraft:orange_concrete
setblock 470 209 452 minecraft:orange_concrete
fill 470 209 453 470 212 453 minecraft:netherrack
fill 473 209 416 474 209 416 minecraft:orange_concrete
fill 476 209 458 476 212 458 minecraft:netherrack
fill 479 209 425 479 213 427 minecraft:red_nether_bricks
fill 480 209 428 482 212 428 minecraft:red_nether_bricks
setblock 481 209 458 minecraft:orange_concrete
fill 484 209 423 484 209 424 minecraft:red_nether_bricks
fill 484 209 426 484 210 426 minecraft:red_nether_bricks
fill 490 209 416 490 212 416 minecraft:netherrack
setblock 492 209 458 minecraft:orange_concrete
setblock 494 209 416 minecraft:orange_concrete
fill 494 209 417 494 209 421 minecraft:magma_block
fill 496 209 458 497 212 458 minecraft:netherrack
fill 501 209 416 501 212 416 minecraft:netherrack
setblock 502 209 416 minecraft:orange_concrete
setblock 505 209 416 minecraft:orange_concrete
fill 512 209 425 512 212 425 minecraft:netherrack
setblock 512 209 426 minecraft:orange_concrete
setblock 512 209 430 minecraft:orange_concrete
setblock 512 209 441 minecraft:orange_concrete
fill 512 209 442 512 211 442 minecraft:netherrack
fill 512 209 446 512 212 446 minecraft:netherrack
fill 512 209 457 512 212 457 minecraft:netherrack
fill 470 210 417 470 231 417 minecraft:netherrack
fill 470 210 418 470 210 419 minecraft:orange_concrete
fill 470 210 420 470 227 420 minecraft:netherrack
fill 470 210 426 470 211 427 minecraft:orange_concrete
fill 470 210 428 470 228 429 minecraft:netherrack
fill 470 210 438 470 210 439 minecraft:orange_concrete
fill 470 210 440 470 227 441 minecraft:netherrack
fill 470 210 447 470 211 447 minecraft:orange_concrete
fill 470 210 448 470 231 449 minecraft:netherrack
setblock 470 210 450 minecraft:orange_concrete
fill 470 210 452 470 227 452 minecraft:netherrack
fill 470 210 458 471 211 458 minecraft:orange_concrete
fill 471 210 417 473 210 417 minecraft:red_nether_bricks
fill 471 210 419 471 210 421 minecraft:red_nether_bricks
fill 471 210 423 471 210 425 minecraft:red_nether_bricks
fill 471 210 427 471 210 429 minecraft:red_nether_bricks
fill 471 210 431 471 210 433 minecraft:red_nether_bricks
fill 471 210 435 471 210 437 minecraft:red_nether_bricks
fill 471 210 439 471 210 441 minecraft:red_nether_bricks
fill 471 210 443 471 210 445 minecraft:red_nether_bricks
fill 471 210 447 471 210 449 minecraft:red_nether_bricks
fill 471 210 451 471 210 453 minecraft:red_nether_bricks
fill 471 210 455 471 210 457 minecraft:red_nether_bricks
setblock 472 210 416 minecraft:orange_concrete
fill 472 210 458 473 228 458 minecraft:netherrack
fill 473 210 416 474 231 416 minecraft:netherrack
fill 473 210 457 475 210 457 minecraft:red_nether_bricks
fill 475 210 416 475 211 416 minecraft:orange_concrete
fill 475 210 417 477 210 417 minecraft:red_nether_bricks
fill 477 210 457 479 210 457 minecraft:red_nether_bricks
fill 478 210 427 478 215 427 minecraft:red_nether_bricks
fill 479 210 417 481 210 417 minecraft:red_nether_bricks
fill 479 210 428 479 215 428 minecraft:red_nether_bricks
fill 481 210 416 482 227 416 minecraft:netherrack
fill 481 210 457 483 210 457 minecraft:red_nether_bricks
fill 481 210 458 481 231 458 minecraft:netherrack
fill 482 210 458 483 210 458 minecraft:orange_concrete
fill 483 210 416 484 210 416 minecraft:orange_concrete
fill 483 210 417 485 210 417 minecraft:red_nether_bricks
fill 483 210 424 483 210 425 minecraft:red_nether_bricks
setblock 484 210 424 minecraft:red_nether_bricks
fill 484 210 458 485 227 458 minecraft:netherrack
fill 485 210 457 487 210 457 minecraft:red_nether_bricks
fill 487 210 417 489 210 417 minecraft:red_nether_bricks
fill 489 210 457 491 210 457 minecraft:red_nether_bricks
fill 490 210 458 491 211 458 minecraft:orange_concrete
fill 491 210 417 493 210 417 minecraft:red_nether_bricks
fill 492 210 458 493 228 458 minecraft:netherrack
fill 493 210 416 494 228 416 minecraft:netherrack
fill 493 210 418 495 210 419 minecraft:magma_block
fill 493 210 457 495 210 457 minecraft:red_nether_bricks
fill 494 210 417 494 212 417 minecraft:magma_block
setblock 494 210 420 minecraft:magma_block
setblock 494 210 458 minecraft:orange_concrete
fill 495 210 416 496 211 416 minecraft:orange_concrete
fill 495 210 417 497 210 417 minecraft:red_nether_bricks
fill 497 210 457 499 210 457 minecraft:red_nether_bricks
fill 499 210 417 501 210 417 minecraft:red_nether_bricks
fill 501 210 457 503 210 457 minecraft:red_nether_bricks
fill 502 210 416 502 227 416 minecraft:netherrack
fill 502 210 458 503 211 458 minecraft:orange_concrete
fill 503 210 416 504 210 416 minecraft:orange_concrete
fill 503 210 417 505 210 417 minecraft:red_nether_bricks
fill 504 210 458 505 227 458 minecraft:netherrack
fill 505 210 416 505 231 416 minecraft:netherrack
fill 505 210 457 507 210 457 minecraft:red_nether_bricks
fill 507 210 416 507 211 416 minecraft:orange_concrete
fill 507 210 417 509 210 417 minecraft:red_nether_bricks
fill 509 210 457 511 210 457 minecraft:red_nether_bricks
fill 511 210 417 511 210 419 minecraft:red_nether_bricks
fill 511 210 421 511 210 423 minecraft:red_nether_bricks
fill 511 210 425 511 210 427 minecraft:red_nether_bricks
fill 511 210 429 511 210 431 minecraft:red_nether_bricks
fill 511 210 433 511 210 435 minecraft:red_nether_bricks
fill 511 210 437 511 210 439 minecraft:red_nether_bricks
fill 511 210 441 511 210 443 minecraft:red_nether_bricks
fill 511 210 445 511 210 447 minecraft:red_nether_bricks
fill 511 210 449 511 210 451 minecraft:red_nether_bricks
fill 511 210 453 511 210 455 minecraft:red_nether_bricks
fill 511 210 458 511 211 458 minecraft:orange_concrete
fill 512 210 417 512 227 418 minecraft:netherrack
fill 512 210 419 512 211 420 minecraft:orange_concrete
fill 512 210 426 512 212 426 minecraft:netherrack
setblock 512 210 428 minecraft:orange_concrete
fill 512 210 429 512 228 430 minecraft:netherrack
fill 512 210 431 512 211 432 minecraft:orange_concrete
fill 512 210 437 512 227 438 minecraft:netherrack
fill 512 210 439 512 210 440 minecraft:orange_concrete
fill 512 210 441 512 211 441 minecraft:netherrack
fill 512 210 449 512 228 450 minecraft:netherrack
fill 512 210 451 512 211 452 minecraft:orange_concrete
fill 470 211 418 470 214 419 minecraft:netherrack
setblock 470 211 435 minecraft:orange_concrete
setblock 470 211 438 minecraft:orange_concrete
fill 470 211 439 470 214 439 minecraft:netherrack
setblock 470 211 446 minecraft:orange_concrete
fill 470 211 450 470 214 450 minecraft:netherrack
fill 472 211 416 472 214 416 minecraft:netherrack
setblock 476 211 416 minecraft:orange_concrete
fill 478 211 426 478 214 426 minecraft:red_nether_bricks
fill 478 211 428 478 215 429 minecraft:red_nether_bricks
fill 478 211 458 479 211 458 minecraft:orange_concrete
fill 479 211 429 481 215 429 minecraft:red_nether_bricks
fill 482 211 424 482 211 425 minecraft:red_nether_bricks
setblock 482 211 458 minecraft:orange_concrete
fill 483 211 416 483 214 416 minecraft:netherrack
fill 483 211 424 484 212 424 minecraft:magma_block
setblock 483 211 425 minecraft:red_nether_bricks
fill 483 211 458 483 214 458 minecraft:netherrack
setblock 484 211 416 minecraft:orange_concrete
setblock 487 211 416 minecraft:orange_concrete
fill 493 211 417 493 211 418 minecraft:magma_block
fill 494 211 418 494 211 419 minecraft:magma_block
fill 494 211 458 494 214 458 minecraft:netherrack
fill 495 211 417 495 211 418 minecraft:magma_block
setblock 499 211 458 minecraft:orange_concrete
fill 503 211 416 504 214 416 minecraft:netherrack
fill 503 211 450 503 212 450 minecraft:magma_block
setblock 508 211 416 minecraft:orange_concrete
setblock 510 211 458 minecraft:orange_concrete
setblock 512 211 423 minecraft:orange_concrete
fill 512 211 424 512 213 424 minecraft:netherrack
fill 512 211 428 512 214 428 minecraft:netherrack
fill 512 211 439 512 214 439 minecraft:netherrack
setblock 512 211 440 minecraft:orange_concrete
fill 512 211 443 512 211 444 minecraft:orange_concrete
setblock 470 212 416 minecraft:orange_concrete
fill 470 212 424 470 213 425 minecraft:orange_concrete
fill 470 212 426 470 225 427 minecraft:netherrack
fill 470 212 433 470 213 433 minecraft:orange_concrete
fill 470 212 435 470 225 435 minecraft:netherrack
fill 470 212 436 470 212 437 minecraft:orange_concrete
fill 470 212 438 470 229 438 minecraft:netherrack
fill 470 212 444 470 213 445 minecraft:orange_concrete
fill 470 212 446 470 225 447 minecraft:netherrack
fill 470 212 456 470 212 457 minecraft:orange_concrete
fill 470 212 458 471 225 458 minecraft:netherrack
fill 475 212 416 476 225 416 minecraft:netherrack
fill 477 212 416 478 213 416 minecraft:orange_concrete
fill 477 212 427 477 214 429 minecraft:red_nether_bricks
fill 477 212 458 477 213 458 minecraft:orange_concrete
fill 478 212 430 480 215 430 minecraft:red_nether_bricks
fill 478 212 458 479 225 458 minecraft:netherrack
fill 480 212 425 480 213 427 minecraft:red_nether_bricks
setblock 480 212 458 minecraft:orange_concrete
fill 481 212 425 482 212 425 minecraft:red_nether_bricks
fill 482 212 426 482 213 427 minecraft:red_nether_bricks
fill 482 212 458 482 229 458 minecraft:netherrack
fill 484 212 416 484 229 416 minecraft:netherrack
fill 485 212 416 486 212 416 minecraft:orange_concrete
fill 487 212 416 487 225 416 minecraft:netherrack
fill 488 212 443 488 212 445 minecraft:orange_concrete
fill 488 212 458 489 213 458 minecraft:orange_concrete
fill 489 212 416 489 213 416 minecraft:orange_concrete
fill 489 212 442 489 212 443 minecraft:orange_concrete
fill 489 212 446 491 213 446 minecraft:orange_concrete
setblock 490 212 442 minecraft:orange_concrete
fill 490 212 458 491 225 458 minecraft:netherrack
fill 492 212 444 492 212 445 minecraft:orange_concrete
fill 495 212 416 496 225 416 minecraft:netherrack
fill 497 212 416 498 213 416 minecraft:orange_concrete
fill 499 212 458 499 225 458 minecraft:netherrack
fill 500 212 424 502 212 425 minecraft:orange_concrete
fill 500 212 458 501 212 458 minecraft:orange_concrete
fill 501 212 422 502 212 423 minecraft:orange_concrete
fill 501 212 426 502 212 427 minecraft:orange_concrete
fill 502 212 421 508 212 421 minecraft:orange_concrete
fill 502 212 428 508 212 428 minecraft:orange_concrete
fill 502 212 454 504 213 455 minecraft:magma_block
fill 502 212 458 503 229 458 minecraft:netherrack
fill 503 212 422 508 212 422 minecraft:orange_concrete
fill 503 212 427 503 214 427 minecraft:orange_concrete
fill 503 212 429 507 212 429 minecraft:orange_concrete
fill 503 212 451 503 212 453 minecraft:magma_block
fill 503 212 456 503 215 456 minecraft:magma_block
fill 504 212 420 506 212 420 minecraft:orange_concrete
setblock 506 212 416 minecraft:orange_concrete
fill 506 212 427 509 212 427 minecraft:orange_concrete
fill 507 212 416 508 225 416 minecraft:netherrack
fill 507 212 423 509 212 423 minecraft:orange_concrete
fill 507 212 426 509 212 426 minecraft:orange_concrete
fill 508 212 424 509 212 425 minecraft:orange_concrete
fill 508 212 458 509 213 458 minecraft:orange_concrete
fill 509 212 416 510 213 416 minecraft:orange_concrete
fill 510 212 458 511 225 458 minecraft:netherrack
fill 512 212 419 512 229 420 minecraft:netherrack
fill 512 212 421 512 212 422 minecraft:orange_concrete
fill 512 212 423 512 225 423 minecraft:netherrack
fill 512 212 431 512 225 432 minecraft:netherrack
fill 512 212 433 512 213 434 minecraft:orange_concrete
fill 512 212 440 512 229 440 minecraft:netherrack
fill 512 212 441 512 212 442 minecraft:orange_concrete
fill 512 212 443 512 213 444 minecraft:netherrack
fill 512 212 445 512 213 445 minecraft:orange_concrete
fill 512 212 451 512 225 452 minecraft:netherrack
fill 512 212 453 512 213 454 minecraft:orange_concrete
setblock 512 212 458 minecraft:orange_concrete
fill 470 213 416 470 231 416 minecraft:netherrack
setblock 470 213 421 minecraft:orange_concrete
setblock 470 213 432 minecraft:orange_concrete
fill 470 213 436 470 231 437 minecraft:netherrack
setblock 470 213 453 minecraft:orange_concrete
setblock 470 213 456 minecraft:orange_concrete
fill 470 213 457 470 231 457 minecraft:netherrack
setblock 476 213 458 minecraft:orange_concrete
fill 477 213 430 477 215 430 minecraft:red_nether_bricks
fill 478 213 431 479 215 431 minecraft:red_nether_bricks
fill 480 213 428 481 215 428 minecraft:red_nether_bricks
fill 480 213 458 480 231 458 minecraft:netherrack
setblock 481 213 425 minecraft:red_nether_bricks
fill 485 213 416 486 231 416 minecraft:netherrack
fill 488 213 444 488 213 445 minecraft:orange_concrete
fill 489 213 443 489 214 443 minecraft:orange_concrete
setblock 490 213 416 minecraft:orange_concrete
setblock 492 213 444 minecraft:orange_concrete
fill 496 213 458 497 213 458 minecraft:orange_concrete
setblock 500 213 458 minecraft:orange_concrete
setblock 501 213 416 minecraft:orange_concrete
fill 501 213 423 502 213 426 minecraft:orange_concrete
fill 501 213 458 501 231 458 minecraft:netherrack
fill 502 213 422 507 213 422 minecraft:orange_concrete
setblock 502 213 427 minecraft:orange_concrete
fill 502 213 453 504 213 453 minecraft:magma_block
fill 502 213 456 502 214 457 minecraft:magma_block
fill 503 213 421 506 213 421 minecraft:orange_concrete
fill 503 213 428 507 213 428 minecraft:orange_concrete
setblock 503 213 452 minecraft:magma_block
fill 503 213 457 504 214 457 minecraft:magma_block
fill 504 213 456 504 214 456 minecraft:magma_block
fill 506 213 416 506 231 416 minecraft:netherrack
fill 506 213 427 508 213 427 minecraft:orange_concrete
fill 507 213 423 508 213 423 minecraft:orange_concrete
fill 507 213 426 508 213 426 minecraft:orange_concrete
fill 508 213 424 508 214 425 minecraft:orange_concrete
fill 512 213 421 512 231 421 minecraft:netherrack
setblock 512 213 422 minecraft:orange_concrete
fill 512 213 425 512 213 426 minecraft:orange_concrete
fill 512 213 441 512 231 442 minecraft:netherrack
setblock 512 213 446 minecraft:orange_concrete
setblock 512 213 457 minecraft:orange_concrete
fill 512 213 458 512 231 458 minecraft:netherrack
fill 470 214 421 470 227 421 minecraft:netherrack
fill 470 214 422 470 214 423 minecraft:orange_concrete
fill 470 214 424 470 231 425 minecraft:netherrack
fill 470 214 430 470 215 431 minecraft:orange_concrete
fill 470 214 432 470 227 433 minecraft:netherrack
setblock 470 214 434 minecraft:orange_concrete
fill 470 214 442 470 215 443 minecraft:orange_concrete
fill 470 214 444 470 227 445 minecraft:netherrack
fill 470 214 451 470 215 451 minecraft:orange_concrete
fill 470 214 453 470 227 453 minecraft:netherrack
fill 470 214 454 470 214 455 minecraft:orange_concrete
fill 470 214 456 470 231 456 minecraft:netherrack
fill 471 214 416 471 215 416 minecraft:orange_concrete
fill 474 214 458 475 215 458 minecraft:orange_concrete
fill 476 214 429 476 215 430 minecraft:red_nether_bricks
fill 476 214 458 477 227 458 minecraft:netherrack
fill 477 214 416 478 227 416 minecraft:netherrack
fill 477 214 431 477 215 431 minecraft:red_nether_bricks
fill 478 214 432 478 215 432 minecraft:red_nether_bricks
fill 478 214 445 480 215 445 minecraft:netherrack
fill 479 214 416 480 215 416 minecraft:orange_concrete
fill 479 214 426 480 214 427 minecraft:red_nether_bricks
fill 479 214 446 480 215 446 minecraft:netherrack
fill 480 214 431 480 215 431 minecraft:red_nether_bricks
fill 486 214 458 487 214 458 minecraft:orange_concrete
setblock 488 214 416 minecraft:orange_concrete
fill 488 214 458 489 227 458 minecraft:netherrack
fill 489 214 416 490 227 416 minecraft:netherrack
setblock 490 214 446 minecraft:orange_concrete
fill 491 214 416 492 215 416 minecraft:orange_concrete
fill 495 214 458 495 215 458 minecraft:orange_concrete
fill 496 214 458 497 227 458 minecraft:netherrack
fill 497 214 416 498 231 416 minecraft:netherrack
setblock 498 214 458 minecraft:orange_concrete
fill 499 214 416 500 214 416 minecraft:orange_concrete
fill 500 214 458 500 231 458 minecraft:netherrack
fill 501 214 416 501 227 416 minecraft:netherrack
fill 502 214 423 502 214 426 minecraft:orange_concrete
fill 502 214 455 504 214 455 minecraft:magma_block
fill 503 214 422 506 214 422 minecraft:orange_concrete
setblock 503 214 454 minecraft:magma_block
fill 506 214 427 507 214 427 minecraft:orange_concrete
fill 506 214 458 507 215 458 minecraft:orange_concrete
setblock 507 214 423 minecraft:orange_concrete
setblock 507 214 426 minecraft:orange_concrete
fill 508 214 458 509 227 458 minecraft:netherrack
fill 509 214 416 510 227 416 minecraft:netherrack
fill 511 214 416 512 215 416 minecraft:orange_concrete
fill 512 214 422 512 231 422 minecraft:netherrack
setblock 512 214 424 minecraft:orange_concrete
fill 512 214 425 512 227 426 minecraft:netherrack
fill 512 214 427 512 215 427 minecraft:orange_concrete
fill 512 214 433 512 227 434 minecraft:netherrack
fill 512 214 435 512 215 436 minecraft:orange_concrete
fill 512 214 443 512 225 443 minecraft:netherrack
setblock 512 214 444 minecraft:orange_concrete
fill 512 214 445 512 227 446 minecraft:netherrack
fill 512 214 447 512 215 448 minecraft:orange_concrete
fill 512 214 453 512 231 454 minecraft:netherrack
fill 512 214 455 512 214 456 minecraft:orange_concrete
fill 512 214 457 512 227 457 minecraft:netherrack
fill 470 215 418 470 215 419 minecraft:orange_concrete
setblock 470 215 422 minecraft:orange_concrete
fill 470 215 423 470 225 423 minecraft:netherrack
fill 470 215 434 470 225 434 minecraft:netherrack
setblock 470 215 439 minecraft:orange_concrete
setblock 470 215 450 minecraft:orange_concrete
fill 470 215 454 470 225 455 minecraft:netherrack
setblock 472 215 416 minecraft:orange_concrete
fill 476 215 431 476 215 432 minecraft:red_nether_bricks
fill 477 215 428 477 215 429 minecraft:red_nether_bricks
setblock 477 215 432 minecraft:red_nether_bricks
fill 479 215 427 480 215 427 minecraft:red_nether_bricks
setblock 479 215 432 minecraft:red_nether_bricks
setblock 483 215 416 minecraft:orange_concrete
setblock 483 215 458 minecraft:orange_concrete
setblock 486 215 458 minecraft:orange_concrete
fill 487 215 458 487 225 458 minecraft:netherrack
fill 488 215 416 488 225 416 minecraft:netherrack
setblock 494 215 458 minecraft:orange_concrete
fill 498 215 458 498 225 458 minecraft:netherrack
fill 499 215 416 499 225 416 minecraft:netherrack
setblock 500 215 416 minecraft:orange_concrete
fill 503 215 416 504 215 416 minecraft:orange_concrete
fill 512 215 424 512 225 424 minecraft:netherrack
setblock 512 215 428 minecraft:orange_concrete
setblock 512 215 439 minecraft:orange_concrete
fill 512 215 444 512 225 444 minecraft:netherrack
fill 512 215 455 512 225 455 minecraft:netherrack
setblock 512 215 456 minecraft:orange_concrete
fill 470 216 418 470 229 419 minecraft:netherrack
fill 470 216 422 470 226 422 minecraft:netherrack
fill 470 216 430 470 229 431 minecraft:netherrack
fill 470 216 439 470 229 439 minecraft:netherrack
fill 470 216 442 470 226 443 minecraft:netherrack
fill 470 216 450 470 229 451 minecraft:netherrack
fill 471 216 416 472 229 416 minecraft:netherrack
setblock 473 216 419 minecraft:light[level=14]
setblock 473 216 427 minecraft:light[level=14]
setblock 473 216 435 minecraft:light[level=14]
setblock 473 216 443 minecraft:light[level=14]
setblock 473 216 451 minecraft:light[level=14]
fill 474 216 458 475 226 458 minecraft:netherrack
fill 479 216 416 480 226 416 minecraft:netherrack
setblock 481 216 419 minecraft:light[level=14]
setblock 481 216 427 minecraft:light[level=14]
setblock 481 216 435 minecraft:light[level=14]
setblock 481 216 443 minecraft:light[level=14]
setblock 481 216 451 minecraft:light[level=14]
fill 483 216 416 483 229 416 minecraft:netherrack
fill 483 216 458 483 229 458 minecraft:netherrack
fill 486 216 458 486 226 458 minecraft:netherrack
setblock 489 216 419 minecraft:light[level=14]
setblock 489 216 427 minecraft:light[level=14]
setblock 489 216 435 minecraft:light[level=14]
setblock 489 216 443 minecraft:light[level=14]
setblock 489 216 451 minecraft:light[level=14]
fill 491 216 416 492 229 416 minecraft:netherrack
fill 494 216 458 495 229 458 minecraft:netherrack
setblock 497 216 419 minecraft:light[level=14]
setblock 497 216 427 minecraft:light[level=14]
setblock 497 216 435 minecraft:light[level=14]
setblock 497 216 443 minecraft:light[level=14]
setblock 497 216 451 minecraft:light[level=14]
fill 500 216 416 500 226 416 minecraft:netherrack
fill 503 216 416 504 229 416 minecraft:netherrack
setblock 505 216 419 minecraft:light[level=14]
setblock 505 216 427 minecraft:light[level=14]
setblock 505 216 435 minecraft:light[level=14]
setblock 505 216 443 minecraft:light[level=14]
setblock 505 216 451 minecraft:light[level=14]
fill 506 216 458 507 226 458 minecraft:netherrack
fill 511 216 416 512 226 416 minecraft:netherrack
fill 512 216 427 512 229 428 minecraft:netherrack
fill 512 216 435 512 225 436 minecraft:netherrack
fill 512 216 439 512 229 439 minecraft:netherrack
fill 512 216 447 512 226 448 minecraft:netherrack
fill 512 216 456 512 225 456 minecraft:netherrack
fill 471 221 417 476 222 420 minecraft:red_terracotta
fill 471 221 421 471 222 421 minecraft:nether_wart_block
fill 471 221 422 471 222 424 minecraft:red_terracotta
fill 471 221 425 471 222 426 minecraft:nether_wart_block
fill 471 221 427 476 222 435 minecraft:red_terracotta
fill 471 221 436 471 222 437 minecraft:nether_wart_block
fill 471 221 438 471 222 440 minecraft:red_terracotta
fill 471 221 441 471 222 442 minecraft:nether_wart_block
fill 471 221 443 476 222 451 minecraft:red_terracotta
fill 471 221 452 471 222 453 minecraft:nether_wart_block
fill 471 221 454 471 222 456 minecraft:red_terracotta
fill 471 221 457 472 222 457 minecraft:nether_wart_block
fill 472 221 421 474 222 421 minecraft:red_terracotta
fill 472 221 422 475 222 425 minecraft:nether_wart_block
fill 472 221 426 475 222 426 minecraft:red_terracotta
fill 472 221 436 475 222 436 minecraft:red_terracotta
fill 472 221 437 472 222 441 minecraft:nether_wart_block
fill 472 221 442 475 222 442 minecraft:red_terracotta
fill 472 221 452 475 222 452 minecraft:red_terracotta
fill 472 221 453 475 222 456 minecraft:nether_wart_block
fill 473 221 437 474 222 437 minecraft:red_terracotta
fill 473 221 438 475 222 440 minecraft:nether_wart_block
fill 473 221 441 474 222 441 minecraft:red_terracotta
fill 473 221 457 474 222 457 minecraft:red_terracotta
fill 475 221 421 476 222 421 minecraft:nether_wart_block
fill 475 221 437 476 222 437 minecraft:nether_wart_block
fill 475 221 441 476 222 441 minecraft:nether_wart_block
fill 475 221 457 476 222 457 minecraft:nether_wart_block
fill 476 221 422 486 222 425 minecraft:red_terracotta
fill 476 221 426 476 222 426 minecraft:nether_wart_block
fill 476 221 436 477 222 436 minecraft:nether_wart_block
fill 476 221 438 487 222 440 minecraft:red_terracotta
fill 476 221 442 477 222 442 minecraft:nether_wart_block
fill 476 221 452 476 222 453 minecraft:nether_wart_block
fill 476 221 454 486 222 456 minecraft:red_terracotta
fill 477 221 417 477 222 419 minecraft:red_terracotta
fill 477 221 420 477 222 420 minecraft:nether_wart_block
fill 477 221 421 486 222 421 minecraft:red_terracotta
fill 477 221 426 485 222 426 minecraft:red_terracotta
fill 477 221 427 477 222 427 minecraft:nether_wart_block
fill 477 221 428 477 222 434 minecraft:red_terracotta
fill 477 221 435 478 222 435 minecraft:nether_wart_block
fill 477 221 437 486 222 437 minecraft:red_terracotta
fill 477 221 441 486 222 441 minecraft:red_terracotta
fill 477 221 443 477 222 443 minecraft:nether_wart_block
fill 477 221 444 477 222 450 minecraft:red_terracotta
fill 477 221 451 477 222 451 minecraft:nether_wart_block
fill 477 221 452 485 222 453 minecraft:red_terracotta
fill 477 221 457 486 222 457 minecraft:red_terracotta
fill 478 221 417 478 222 418 minecraft:red_terracotta
fill 478 221 419 478 222 419 minecraft:nether_wart_block
fill 478 221 420 485 222 420 minecraft:red_terracotta
fill 478 221 427 484 222 427 minecraft:red_terracotta
fill 478 221 428 478 222 428 minecraft:nether_wart_block
fill 478 221 429 478 222 433 minecraft:red_terracotta
fill 478 221 434 479 222 434 minecraft:nether_wart_block
fill 478 221 436 485 222 436 minecraft:red_terracotta
fill 478 221 442 484 222 443 minecraft:red_terracotta
fill 478 221 444 479 222 444 minecraft:nether_wart_block
fill 478 221 445 478 222 449 minecraft:red_terracotta
fill 478 221 450 478 222 450 minecraft:nether_wart_block
fill 478 221 451 484 222 451 minecraft:red_terracotta
fill 479 221 417 479 222 418 minecraft:nether_wart_block
fill 479 221 419 484 222 419 minecraft:red_terracotta
fill 479 221 428 483 222 428 minecraft:red_terracotta
fill 479 221 429 480 222 429 minecraft:nether_wart_block
fill 479 221 430 479 222 432 minecraft:red_terracotta
fill 479 221 433 483 222 433 minecraft:nether_wart_block
fill 479 221 435 484 222 435 minecraft:red_terracotta
fill 479 221 445 480 222 445 minecraft:nether_wart_block
fill 479 221 446 479 222 448 minecraft:red_terracotta
fill 479 221 449 480 222 449 minecraft:nether_wart_block
fill 479 221 450 483 222 450 minecraft:red_terracotta
fill 480 221 417 483 222 417 minecraft:nether_wart_block
fill 480 221 418 482 222 418 minecraft:red_terracotta
fill 480 221 430 483 222 432 minecraft:nether_wart_block
fill 480 221 434 483 222 434 minecraft:red_terracotta
fill 480 221 444 483 222 444 minecraft:red_terracotta
fill 480 221 446 483 222 448 minecraft:nether_wart_block
fill 481 221 429 482 222 429 minecraft:red_terracotta
fill 481 221 445 481 222 445 minecraft:red_terracotta
fill 481 221 449 482 222 449 minecraft:red_terracotta
fill 482 221 445 483 222 445 minecraft:nether_wart_block
fill 483 221 418 484 222 418 minecraft:nether_wart_block
fill 483 221 429 484 222 429 minecraft:nether_wart_block
fill 483 221 449 484 222 449 minecraft:nether_wart_block
fill 484 221 417 494 222 417 minecraft:red_terracotta
fill 484 221 428 485 222 428 minecraft:nether_wart_block
fill 484 221 430 494 222 433 minecraft:red_terracotta
fill 484 221 434 484 222 434 minecraft:nether_wart_block
fill 484 221 444 484 222 444 minecraft:nether_wart_block
fill 484 221 445 494 222 448 minecraft:red_terracotta
fill 484 221 450 485 222 450 minecraft:nether_wart_block
fill 485 221 418 493 222 418 minecraft:red_terracotta
fill 485 221 419 485 222 419 minecraft:nether_wart_block
fill 485 221 427 486 222 427 minecraft:nether_wart_block
fill 485 221 429 494 222 429 minecraft:red_terracotta
fill 485 221 434 493 222 434 minecraft:red_terracotta
fill 485 221 435 485 222 435 minecraft:nether_wart_block
fill 485 221 442 485 222 442 minecraft:red_terracotta
fill 485 221 443 485 222 443 minecraft:nether_wart_block
fill 485 221 444 493 221 444 minecraft:red_terracotta
fill 485 221 449 494 222 449 minecraft:red_terracotta
fill 485 221 451 486 222 451 minecraft:nether_wart_block
fill 486 221 419 492 222 419 minecraft:red_terracotta
fill 486 221 420 486 222 420 minecraft:nether_wart_block
fill 486 221 426 487 222 426 minecraft:nether_wart_block
fill 486 221 428 493 222 428 minecraft:red_terracotta
fill 486 221 435 492 222 435 minecraft:red_terracotta
fill 486 221 436 486 222 436 minecraft:nether_wart_block
fill 486 221 442 486 222 442 minecraft:nether_wart_block
fill 486 221 443 492 221 443 minecraft:red_terracotta
fill 486 221 450 493 222 450 minecraft:red_terracotta
fill 486 221 452 487 222 452 minecraft:nether_wart_block
fill 486 221 453 486 222 453 minecraft:red_terracotta
fill 487 221 420 491 222 420 minecraft:red_terracotta
fill 487 221 421 487 222 422 minecraft:nether_wart_block
fill 487 221 423 487 222 424 minecraft:red_terracotta
fill 487 221 425 491 222 425 minecraft:nether_wart_block
fill 487 221 427 492 222 427 minecraft:red_terracotta
fill 487 221 436 491 222 436 minecraft:red_terracotta
fill 487 221 437 488 222 437 minecraft:nether_wart_block
fill 487 221 441 488 222 441 minecraft:nether_wart_block
fill 487 221 442 491 221 442 minecraft:red_terracotta
fill 487 221 451 492 222 451 minecraft:red_terracotta
fill 487 221 453 491 222 453 minecraft:nether_wart_block
fill 487 221 454 487 222 455 minecraft:red_terracotta
fill 487 221 456 487 222 457 minecraft:nether_wart_block
fill 488 221 421 490 222 421 minecraft:red_terracotta
fill 488 221 422 490 222 424 minecraft:nether_wart_block
fill 488 221 426 490 222 426 minecraft:red_terracotta
fill 488 221 438 490 221 440 minecraft:nether_wart_block
fill 488 221 452 491 222 452 minecraft:red_terracotta
fill 488 221 454 490 222 456 minecraft:nether_wart_block
fill 488 221 457 490 222 457 minecraft:red_terracotta
fill 489 221 437 490 222 437 minecraft:red_terracotta
fill 489 221 441 489 222 441 minecraft:red_terracotta
setblock 490 221 441 minecraft:nether_wart_block
fill 491 221 421 491 222 422 minecraft:nether_wart_block
fill 491 221 423 502 222 423 minecraft:red_terracotta
fill 491 221 424 491 222 424 minecraft:nether_wart_block
fill 491 221 426 492 222 426 minecraft:nether_wart_block
fill 491 221 437 491 222 438 minecraft:nether_wart_block
fill 491 221 439 492 221 439 minecraft:red_terracotta
setblock 491 221 440 minecraft:nether_wart_block
fill 491 221 454 491 222 454 minecraft:nether_wart_block
fill 491 221 455 503 222 455 minecraft:red_terracotta
fill 491 221 456 491 222 457 minecraft:nether_wart_block
fill 492 221 420 492 222 421 minecraft:nether_wart_block
fill 492 221 422 502 222 422 minecraft:red_terracotta
fill 492 221 424 502 222 425 minecraft:red_terracotta
fill 492 221 436 492 222 436 minecraft:nether_wart_block
fill 492 221 437 502 221 438 minecraft:red_terracotta
fill 492 221 452 492 222 452 minecraft:nether_wart_block
fill 492 221 453 502 222 454 minecraft:red_terracotta
fill 492 221 456 502 222 456 minecraft:red_terracotta
fill 492 221 457 492 222 457 minecraft:nether_wart_block
fill 493 221 419 493 222 420 minecraft:nether_wart_block
fill 493 221 421 501 222 421 minecraft:red_terracotta
fill 493 221 426 501 222 426 minecraft:red_terracotta
fill 493 221 427 493 222 427 minecraft:nether_wart_block
fill 493 221 435 493 222 435 minecraft:nether_wart_block
fill 493 221 436 501 222 436 minecraft:red_terracotta
fill 493 221 451 493 222 451 minecraft:nether_wart_block
fill 493 221 452 501 222 452 minecraft:red_terracotta
fill 493 221 457 501 222 457 minecraft:red_terracotta
fill 494 221 418 494 222 419 minecraft:nether_wart_block
fill 494 221 420 500 222 420 minecraft:red_terracotta
fill 494 221 427 500 222 427 minecraft:red_terracotta
fill 494 221 428 494 222 428 minecraft:nether_wart_block
fill 494 221 434 494 222 434 minecraft:nether_wart_block
fill 494 221 435 500 222 435 minecraft:red_terracotta
fill 494 221 439 503 221 439 minecraft:red_terracotta
fill 494 221 443 500 221 443 minecraft:red_terracotta
setblock 494 221 444 minecraft:nether_wart_block
fill 494 221 450 494 222 450 minecraft:nether_wart_block
fill 494 221 451 500 222 451 minecraft:red_terracotta
fill 495 221 417 495 222 418 minecraft:nether_wart_block
fill 495 221 419 499 222 419 minecraft:red_terracotta
fill 495 221 428 499 222 428 minecraft:red_terracotta
fill 495 221 429 495 222 430 minecraft:nether_wart_block
fill 495 221 431 495 222 432 minecraft:red_terracotta
fill 495 221 433 499 222 433 minecraft:nether_wart_block
fill 495 221 434 499 222 434 minecraft:red_terracotta
fill 495 221 440 502 221 440 minecraft:red_terracotta
fill 495 221 442 501 221 442 minecraft:red_terracotta
fill 495 221 444 499 222 444 minecraft:red_terracotta
fill 495 221 445 496 222 446 minecraft:nether_wart_block
fill 495 221 447 495 222 447 minecraft:red_terracotta
fill 495 221 448 495 222 449 minecraft:nether_wart_block
fill 495 221 450 499 222 450 minecraft:red_terracotta
fill 496 221 417 499 222 417 minecraft:nether_wart_block
fill 496 221 418 498 222 418 minecraft:red_terracotta
fill 496 221 429 498 222 429 minecraft:red_terracotta
fill 496 221 430 498 222 432 minecraft:nether_wart_block
fill 496 221 441 502 221 441 minecraft:red_terracotta
fill 496 221 447 498 222 448 minecraft:nether_wart_block
fill 496 221 449 497 222 449 minecraft:red_terracotta
fill 497 221 445 497 222 445 minecraft:red_terracotta
fill 497 221 446 499 222 446 minecraft:nether_wart_block
fill 498 221 445 499 222 445 minecraft:nether_wart_block
fill 498 221 449 499 222 449 minecraft:nether_wart_block
fill 499 221 418 500 222 418 minecraft:nether_wart_block
fill 499 221 429 499 222 430 minecraft:nether_wart_block
fill 499 221 431 510 222 432 minecraft:red_terracotta
fill 499 221 447 510 222 447 minecraft:red_terracotta
fill 499 221 448 499 222 448 minecraft:nether_wart_block
fill 500 221 417 510 222 417 minecraft:red_terracotta
fill 500 221 419 501 222 419 minecraft:nether_wart_block
fill 500 221 428 500 222 428 minecraft:nether_wart_block
fill 500 221 429 509 222 430 minecraft:red_terracotta
fill 500 221 433 510 222 433 minecraft:red_terracotta
fill 500 221 434 500 222 434 minecraft:nether_wart_block
fill 500 221 444 500 222 444 minecraft:nether_wart_block
fill 500 221 445 509 222 446 minecraft:red_terracotta
fill 500 221 448 509 222 449 minecraft:red_terracotta
fill 500 221 450 500 222 450 minecraft:nether_wart_block
fill 501 221 418 509 222 418 minecraft:red_terracotta
fill 501 221 420 502 222 420 minecraft:nether_wart_block
fill 501 221 427 501 222 427 minecraft:nether_wart_block
fill 501 221 428 508 222 428 minecraft:red_terracotta
fill 501 221 434 509 222 434 minecraft:red_terracotta
fill 501 221 435 501 222 435 minecraft:nether_wart_block
fill 501 221 443 501 222 443 minecraft:nether_wart_block
fill 501 221 444 509 222 444 minecraft:red_terracotta
fill 501 221 450 508 222 450 minecraft:red_terracotta
fill 501 221 451 501 222 451 minecraft:nether_wart_block
fill 502 221 419 508 222 419 minecraft:red_terracotta
fill 502 221 421 503 222 421 minecraft:nether_wart_block
fill 502 221 426 502 222 426 minecraft:nether_wart_block
fill 502 221 427 507 222 427 minecraft:red_terracotta
fill 502 221 435 508 222 435 minecraft:red_terracotta
fill 502 221 436 502 222 436 minecraft:nether_wart_block
fill 502 221 442 502 222 442 minecraft:nether_wart_block
fill 502 221 443 508 222 443 minecraft:red_terracotta
fill 502 221 451 507 222 451 minecraft:red_terracotta
fill 502 221 452 502 222 452 minecraft:nether_wart_block
fill 502 221 457 503 222 457 minecraft:nether_wart_block
fill 503 221 420 507 222 420 minecraft:red_terracotta
fill 503 221 422 506 222 425 minecraft:nether_wart_block
fill 503 221 426 506 222 426 minecraft:red_terracotta
fill 503 221 436 507 222 436 minecraft:red_terracotta
fill 503 221 437 503 222 438 minecraft:nether_wart_block
fill 503 221 440 504 222 441 minecraft:nether_wart_block
fill 503 221 442 507 222 442 minecraft:red_terracotta
fill 503 221 452 506 222 452 minecraft:red_terracotta
fill 503 221 453 506 222 454 minecraft:nether_wart_block
fill 503 221 456 507 222 456 minecraft:nether_wart_block
fill 504 221 421 506 222 421 minecraft:red_terracotta
fill 504 221 437 505 222 437 minecraft:red_terracotta
fill 504 221 438 506 222 439 minecraft:nether_wart_block
fill 504 221 455 506 222 455 minecraft:nether_wart_block
fill 504 221 457 506 222 457 minecraft:red_terracotta
fill 505 221 440 506 222 440 minecraft:nether_wart_block
fill 505 221 441 505 222 441 minecraft:red_terracotta
fill 506 221 437 507 222 437 minecraft:nether_wart_block
fill 506 221 441 507 222 441 minecraft:nether_wart_block
fill 507 221 421 507 222 422 minecraft:nether_wart_block
fill 507 221 423 511 222 424 minecraft:red_terracotta
fill 507 221 425 507 222 426 minecraft:nether_wart_block
fill 507 221 438 511 222 440 minecraft:red_terracotta
fill 507 221 452 507 222 453 minecraft:nether_wart_block
fill 507 221 454 511 222 455 minecraft:red_terracotta
fill 507 221 457 507 222 457 minecraft:nether_wart_block
fill 508 221 420 508 222 420 minecraft:nether_wart_block
fill 508 221 421 511 222 422 minecraft:red_terracotta
fill 508 221 425 511 222 425 minecraft:red_terracotta
fill 508 221 426 508 222 427 minecraft:nether_wart_block
fill 508 221 436 508 222 436 minecraft:nether_wart_block
fill 508 221 437 511 222 437 minecraft:red_terracotta
fill 508 221 441 511 222 441 minecraft:red_terracotta
fill 508 221 442 508 222 442 minecraft:nether_wart_block
fill 508 221 451 508 222 452 minecraft:nether_wart_block
fill 508 221 453 511 222 453 minecraft:red_terracotta
fill 508 221 456 511 222 457 minecraft:red_terracotta
fill 509 221 419 509 222 419 minecraft:nether_wart_block
fill 509 221 420 511 222 420 minecraft:red_terracotta
fill 509 221 426 511 222 426 minecraft:red_terracotta
fill 509 221 427 509 222 428 minecraft:nether_wart_block
fill 509 221 435 509 222 435 minecraft:nether_wart_block
fill 509 221 436 511 222 436 minecraft:red_terracotta
fill 509 221 442 511 222 442 minecraft:red_terracotta
fill 509 221 443 509 222 443 minecraft:nether_wart_block
fill 509 221 450 509 222 451 minecraft:nether_wart_block
fill 509 221 452 511 222 452 minecraft:red_terracotta
fill 510 221 418 511 222 418 minecraft:nether_wart_block
fill 510 221 419 511 222 419 minecraft:red_terracotta
fill 510 221 427 511 222 427 minecraft:red_terracotta
fill 510 221 428 510 222 429 minecraft:nether_wart_block
fill 510 221 430 510 222 430 minecraft:red_terracotta
fill 510 221 434 510 222 434 minecraft:nether_wart_block
fill 510 221 435 511 222 435 minecraft:red_terracotta
fill 510 221 443 511 222 443 minecraft:red_terracotta
fill 510 221 444 510 222 445 minecraft:nether_wart_block
fill 510 221 446 510 222 446 minecraft:red_terracotta
fill 510 221 448 510 222 448 minecraft:red_terracotta
fill 510 221 449 510 222 450 minecraft:nether_wart_block
fill 510 221 451 511 222 451 minecraft:red_terracotta
fill 511 221 417 511 222 417 minecraft:nether_wart_block
fill 511 221 428 511 222 428 minecraft:red_terracotta
fill 511 221 429 511 222 433 minecraft:nether_wart_block
fill 511 221 434 511 222 434 minecraft:red_terracotta
fill 511 221 444 511 222 444 minecraft:red_terracotta
fill 511 221 445 511 222 449 minecraft:nether_wart_block
fill 511 221 450 511 222 450 minecraft:red_terracotta
fill 485 222 444 491 222 444 minecraft:red_terracotta
fill 486 222 443 490 222 443 minecraft:red_terracotta
fill 487 222 442 489 222 442 minecraft:red_terracotta
fill 488 222 438 489 222 440 minecraft:nether_wart_block
fill 490 222 438 490 222 439 minecraft:nether_wart_block
fill 490 222 440 490 222 442 minecraft:shroomlight
fill 491 222 439 491 222 440 minecraft:shroomlight
fill 491 222 442 491 222 443 minecraft:shroomlight
fill 492 222 437 502 222 437 minecraft:red_terracotta
fill 492 222 438 492 222 439 minecraft:shroomlight
fill 492 222 443 492 222 444 minecraft:shroomlight
fill 493 222 438 494 222 438 minecraft:shroomlight
fill 493 222 444 494 222 444 minecraft:shroomlight
fill 494 222 439 495 222 439 minecraft:shroomlight
fill 494 222 443 495 222 443 minecraft:shroomlight
fill 495 222 438 502 222 438 minecraft:red_terracotta
fill 495 222 440 496 222 440 minecraft:shroomlight
fill 495 222 442 496 222 442 minecraft:shroomlight
fill 496 222 439 503 222 439 minecraft:red_terracotta
setblock 496 222 441 minecraft:shroomlight
fill 496 222 443 500 222 443 minecraft:red_terracotta
fill 497 222 440 501 222 442 minecraft:red_terracotta
fill 502 222 440 502 222 441 minecraft:red_terracotta
setblock 473 224 419 minecraft:light[level=14]
setblock 473 224 427 minecraft:light[level=14]
setblock 473 224 435 minecraft:light[level=14]
setblock 473 224 443 minecraft:light[level=14]
setblock 473 224 451 minecraft:light[level=14]
setblock 481 224 419 minecraft:light[level=14]
setblock 481 224 427 minecraft:light[level=14]
setblock 481 224 435 minecraft:light[level=14]
setblock 481 224 443 minecraft:light[level=14]
setblock 481 224 451 minecraft:light[level=14]
setblock 489 224 419 minecraft:light[level=14]
setblock 489 224 427 minecraft:light[level=14]
setblock 489 224 435 minecraft:light[level=14]
setblock 489 224 443 minecraft:light[level=14]
setblock 489 224 451 minecraft:light[level=14]
setblock 497 224 419 minecraft:light[level=14]
setblock 497 224 427 minecraft:light[level=14]
setblock 497 224 435 minecraft:light[level=14]
setblock 497 224 443 minecraft:light[level=14]
setblock 497 224 451 minecraft:light[level=14]
setblock 505 224 419 minecraft:light[level=14]
setblock 505 224 427 minecraft:light[level=14]
setblock 505 224 435 minecraft:light[level=14]
setblock 505 224 443 minecraft:light[level=14]
setblock 505 224 451 minecraft:light[level=14]
fill 470 226 423 470 227 423 minecraft:orange_concrete
setblock 470 226 426 minecraft:orange_concrete
fill 470 226 427 470 229 427 minecraft:netherrack
fill 470 226 434 470 227 435 minecraft:orange_concrete
fill 470 226 446 470 226 447 minecraft:orange_concrete
fill 470 226 454 470 227 455 minecraft:orange_concrete
setblock 470 226 458 minecraft:orange_concrete
fill 471 226 458 471 229 458 minecraft:netherrack
fill 474 226 438 478 226 440 minecraft:red_nether_bricks
fill 475 226 416 476 226 416 minecraft:orange_concrete
fill 475 226 436 477 226 437 minecraft:red_nether_bricks
fill 475 226 441 478 230 441 minecraft:red_nether_bricks
fill 476 226 442 478 232 442 minecraft:red_nether_bricks
setblock 478 226 437 minecraft:red_nether_bricks
fill 478 226 458 479 227 458 minecraft:orange_concrete
fill 487 226 416 488 227 416 minecraft:orange_concrete
fill 487 226 458 487 227 458 minecraft:orange_concrete
fill 490 226 458 491 226 458 minecraft:orange_concrete
fill 495 226 416 495 229 416 minecraft:netherrack
setblock 496 226 416 minecraft:orange_concrete
fill 498 226 458 499 227 458 minecraft:orange_concrete
fill 499 226 416 499 227 416 minecraft:orange_concrete
fill 507 226 416 508 226 416 minecraft:orange_concrete
fill 510 226 458 511 226 458 minecraft:orange_concrete
fill 512 226 423 512 227 424 minecraft:orange_concrete
fill 512 226 431 512 226 432 minecraft:orange_concrete
fill 512 226 435 512 227 435 minecraft:orange_concrete
setblock 512 226 436 minecraft:netherrack
fill 512 226 443 512 227 444 minecraft:orange_concrete
fill 512 226 451 512 229 451 minecraft:netherrack
setblock 512 226 452 minecraft:orange_concrete
fill 512 226 455 512 227 456 minecraft:orange_concrete
setblock 470 227 422 minecraft:orange_concrete
fill 470 227 426 470 230 426 minecraft:netherrack
fill 470 227 442 470 227 443 minecraft:orange_concrete
setblock 470 227 446 minecraft:orange_concrete
fill 470 227 447 470 230 447 minecraft:netherrack
fill 470 227 458 470 230 458 minecraft:netherrack
fill 474 227 439 478 227 440 minecraft:red_nether_bricks
fill 474 227 458 474 229 458 minecraft:netherrack
fill 475 227 416 475 230 416 minecraft:netherrack
fill 475 227 438 478 227 438 minecraft:red_nether_bricks
fill 475 227 442 475 231 442 minecraft:red_nether_bricks
setblock 475 227 458 minecraft:orange_concrete
setblock 476 227 416 minecraft:orange_concrete
fill 476 227 437 477 227 437 minecraft:red_nether_bricks
fill 476 227 443 478 232 443 minecraft:red_nether_bricks
fill 479 227 416 480 227 416 minecraft:orange_concrete
fill 479 227 440 479 228 441 minecraft:red_nether_bricks
setblock 486 227 458 minecraft:orange_concrete
fill 490 227 458 491 229 458 minecraft:netherrack
fill 496 227 416 496 230 416 minecraft:netherrack
setblock 500 227 416 minecraft:orange_concrete
fill 506 227 458 507 227 458 minecraft:orange_concrete
fill 507 227 416 507 230 416 minecraft:netherrack
setblock 508 227 416 minecraft:orange_concrete
setblock 510 227 458 minecraft:orange_concrete
setblock 511 227 416 minecraft:orange_concrete
fill 511 227 458 511 230 458 minecraft:netherrack
fill 512 227 416 512 229 416 minecraft:netherrack
fill 512 227 431 512 230 432 minecraft:netherrack
setblock 512 227 436 minecraft:orange_concrete
setblock 512 227 447 minecraft:orange_concrete
fill 512 227 448 512 229 448 minecraft:netherrack
fill 512 227 452 512 230 452 minecraft:netherrack
fill 470 228 420 470 229 421 minecraft:orange_concrete
fill 470 228 422 470 233 423 minecraft:netherrack
fill 470 228 432 470 228 433 minecraft:orange_concrete
fill 470 228 434 470 233 435 minecraft:netherrack
setblock 470 228 440 minecraft:netherrack
fill 470 228 441 470 229 441 minecraft:orange_concrete
fill 470 228 442 470 233 443 minecraft:netherrack
setblock 470 228 444 minecraft:orange_concrete
fill 470 228 445 470 231 446 minecraft:netherrack
fill 470 228 452 470 229 453 minecraft:orange_concrete
fill 470 228 454 470 233 455 minecraft:netherrack
fill 471 228 417 473 228 417 minecraft:red_nether_bricks
fill 471 228 419 471 228 421 minecraft:red_nether_bricks
fill 471 228 423 471 228 425 minecraft:red_nether_bricks
fill 471 228 427 471 228 429 minecraft:red_nether_bricks
fill 471 228 431 471 228 433 minecraft:red_nether_bricks
fill 471 228 435 471 228 437 minecraft:red_nether_bricks
fill 471 228 439 471 228 441 minecraft:red_nether_bricks
fill 471 228 443 471 228 445 minecraft:red_nether_bricks
fill 471 228 447 471 228 449 minecraft:red_nether_bricks
fill 471 228 451 471 228 453 minecraft:red_nether_bricks
fill 471 228 455 471 228 457 minecraft:red_nether_bricks
fill 473 228 457 475 228 457 minecraft:red_nether_bricks
fill 475 228 417 477 228 417 minecraft:red_nether_bricks
fill 475 228 439 478 228 440 minecraft:red_nether_bricks
fill 475 228 443 475 231 443 minecraft:red_nether_bricks
fill 475 228 458 475 233 458 minecraft:netherrack
fill 476 228 416 477 231 416 minecraft:netherrack
fill 476 228 438 477 228 438 minecraft:red_nether_bricks
fill 476 228 444 478 233 444 minecraft:red_nether_bricks
fill 476 228 458 477 228 458 minecraft:orange_concrete
fill 477 228 457 479 228 457 minecraft:red_nether_bricks
setblock 478 228 416 minecraft:orange_concrete
fill 478 228 458 479 233 458 minecraft:netherrack
fill 479 228 416 480 233 416 minecraft:netherrack
fill 479 228 417 481 228 417 minecraft:red_nether_bricks
fill 479 228 442 479 232 443 minecraft:red_nether_bricks
fill 481 228 416 481 229 416 minecraft:orange_concrete
fill 481 228 457 483 228 457 minecraft:red_nether_bricks
setblock 482 228 416 minecraft:netherrack
fill 483 228 417 485 228 417 minecraft:red_nether_bricks
fill 484 228 458 485 229 458 minecraft:orange_concrete
fill 485 228 457 487 228 457 minecraft:red_nether_bricks
fill 486 228 458 487 233 458 minecraft:netherrack
fill 487 228 416 488 233 416 minecraft:netherrack
fill 487 228 417 489 228 417 minecraft:red_nether_bricks
setblock 488 228 458 minecraft:orange_concrete
fill 489 228 416 490 228 416 minecraft:orange_concrete
fill 489 228 457 491 228 457 minecraft:red_nether_bricks
fill 489 228 458 489 231 458 minecraft:netherrack
fill 491 228 417 493 228 417 minecraft:red_nether_bricks
fill 493 228 457 495 228 457 minecraft:red_nether_bricks
fill 495 228 417 497 228 417 minecraft:red_nether_bricks
fill 496 228 458 497 229 458 minecraft:orange_concrete
fill 497 228 457 499 228 457 minecraft:red_nether_bricks
fill 498 228 458 499 233 458 minecraft:netherrack
fill 499 228 416 500 233 416 minecraft:netherrack
fill 499 228 417 501 228 417 minecraft:red_nether_bricks
fill 501 228 416 502 229 416 minecraft:orange_concrete
fill 501 228 457 503 228 457 minecraft:red_nether_bricks
fill 503 228 417 505 228 417 minecraft:red_nether_bricks
setblock 504 228 458 minecraft:netherrack
fill 505 228 457 507 228 457 minecraft:red_nether_bricks
fill 505 228 458 505 229 458 minecraft:orange_concrete
fill 506 228 458 507 229 458 minecraft:netherrack
fill 507 228 417 509 228 417 minecraft:red_nether_bricks
fill 508 228 416 508 233 416 minecraft:netherrack
fill 508 228 458 509 228 458 minecraft:orange_concrete
fill 509 228 416 510 228 416 minecraft:orange_concrete
fill 509 228 457 511 228 457 minecraft:red_nether_bricks
fill 510 228 458 510 233 458 minecraft:netherrack
fill 511 228 416 511 233 416 minecraft:netherrack
fill 511 228 417 511 228 419 minecraft:red_nether_bricks
fill 511 228 421 511 228 423 minecraft:red_nether_bricks
fill 511 228 425 511 228 427 minecraft:red_nether_bricks
fill 511 228 429 511 228 431 minecraft:red_nether_bricks
fill 511 228 433 511 228 435 minecraft:red_nether_bricks
fill 511 228 437 511 228 439 minecraft:red_nether_bricks
fill 511 228 441 511 228 443 minecraft:red_nether_bricks
fill 511 228 445 511 228 447 minecraft:red_nether_bricks
fill 511 228 449 511 228 451 minecraft:red_nether_bricks
fill 511 228 453 511 228 455 minecraft:red_nether_bricks
fill 512 228 417 512 229 417 minecraft:orange_concrete
setblock 512 228 418 minecraft:netherrack
fill 512 228 423 512 233 424 minecraft:netherrack
fill 512 228 425 512 229 426 minecraft:orange_concrete
fill 512 228 433 512 231 433 minecraft:netherrack
setblock 512 228 434 minecraft:orange_concrete
fill 512 228 435 512 233 436 minecraft:netherrack
fill 512 228 437 512 229 438 minecraft:orange_concrete
fill 512 228 443 512 233 444 minecraft:netherrack
fill 512 228 445 512 228 446 minecraft:orange_concrete
fill 512 228 447 512 233 447 minecraft:netherrack
fill 512 228 455 512 233 456 minecraft:netherrack
fill 512 228 457 512 229 457 minecraft:orange_concrete
fill 470 229 428 470 231 428 minecraft:netherrack
setblock 470 229 429 minecraft:orange_concrete
setblock 470 229 432 minecraft:orange_concrete
fill 470 229 433 470 232 433 minecraft:netherrack
setblock 470 229 440 minecraft:orange_concrete
fill 470 229 444 470 232 444 minecraft:netherrack
fill 472 229 458 473 229 458 minecraft:orange_concrete
fill 475 229 439 475 230 439 minecraft:magma_block
fill 475 229 440 478 229 440 minecraft:red_nether_bricks
fill 476 229 439 478 229 439 minecraft:red_nether_bricks
setblock 476 229 458 minecraft:orange_concrete
fill 477 229 445 478 235 445 minecraft:red_nether_bricks
fill 477 229 458 477 232 458 minecraft:netherrack
fill 478 229 416 478 232 416 minecraft:netherrack
fill 479 229 441 479 230 441 minecraft:red_nether_bricks
fill 479 229 444 479 235 444 minecraft:red_nether_bricks
setblock 482 229 416 minecraft:orange_concrete
fill 488 229 458 488 231 458 minecraft:netherrack
fill 489 229 416 489 232 416 minecraft:netherrack
setblock 490 229 416 minecraft:orange_concrete
fill 492 229 458 492 231 458 minecraft:netherrack
setblock 493 229 416 minecraft:orange_concrete
setblock 493 229 458 minecraft:orange_concrete
fill 494 229 416 494 231 416 minecraft:netherrack
setblock 504 229 458 minecraft:orange_concrete
fill 508 229 458 509 231 458 minecraft:netherrack
fill 509 229 416 510 232 416 minecraft:netherrack
setblock 512 229 418 minecraft:orange_concrete
setblock 512 229 429 minecraft:orange_concrete
fill 512 229 430 512 231 430 minecraft:netherrack
fill 512 229 434 512 232 434 minecraft:netherrack
fill 512 229 445 512 232 445 minecraft:netherrack
setblock 512 229 446 minecraft:orange_concrete
fill 512 229 449 512 229 450 minecraft:orange_concrete
fill 470 230 418 470 231 419 minecraft:orange_concrete
fill 470 230 420 470 235 421 minecraft:netherrack
fill 470 230 427 470 231 427 minecraft:orange_concrete
fill 470 230 429 470 235 429 minecraft:netherrack
fill 470 230 430 470 230 431 minecraft:orange_concrete
fill 470 230 432 470 235 432 minecraft:netherrack
fill 470 230 438 470 231 439 minecraft:orange_concrete
fill 470 230 440 470 235 441 minecraft:netherrack
fill 470 230 450 470 230 451 minecraft:orange_concrete
fill 470 230 452 470 235 453 minecraft:netherrack
fill 471 230 416 472 230 416 minecraft:orange_concrete
fill 471 230 458 471 231 458 minecraft:orange_concrete
fill 472 230 458 473 235 458 minecraft:netherrack
setblock 474 230 458 minecraft:orange_concrete
setblock 475 230 444 minecraft:red_nether_bricks
fill 476 230 440 478 230 440 minecraft:red_nether_bricks
fill 476 230 445 476 233 445 minecraft:red_nether_bricks
fill 476 230 458 476 235 458 minecraft:netherrack
fill 478 230 446 478 237 446 minecraft:red_nether_bricks
fill 479 230 445 479 236 445 minecraft:red_nether_bricks
fill 480 230 443 480 233 444 minecraft:red_nether_bricks
fill 481 230 416 482 235 416 minecraft:netherrack
fill 482 230 458 483 231 458 minecraft:orange_concrete
fill 483 230 416 484 231 416 minecraft:orange_concrete
fill 484 230 458 485 235 458 minecraft:netherrack
fill 490 230 416 490 235 416 minecraft:netherrack
setblock 490 230 458 minecraft:netherrack
fill 491 230 416 492 230 416 minecraft:orange_concrete
fill 491 230 458 491 231 458 minecraft:orange_concrete
fill 493 230 416 493 235 416 minecraft:netherrack
fill 493 230 458 493 235 458 minecraft:netherrack
fill 494 230 458 495 230 458 minecraft:orange_concrete
fill 495 230 416 495 231 416 minecraft:orange_concrete
fill 496 230 458 497 232 458 minecraft:netherrack
fill 501 230 416 502 235 416 minecraft:netherrack
fill 502 230 458 503 231 458 minecraft:orange_concrete
fill 503 230 416 504 231 416 minecraft:orange_concrete
fill 504 230 458 505 235 458 minecraft:netherrack
setblock 506 230 458 minecraft:orange_concrete
fill 507 230 458 507 233 458 minecraft:netherrack
setblock 512 230 416 minecraft:orange_concrete
fill 512 230 417 512 235 418 minecraft:netherrack
fill 512 230 419 512 231 420 minecraft:orange_concrete
fill 512 230 425 512 235 426 minecraft:netherrack
fill 512 230 427 512 230 428 minecraft:orange_concrete
fill 512 230 429 512 235 429 minecraft:netherrack
fill 512 230 437 512 235 438 minecraft:netherrack
fill 512 230 439 512 231 440 minecraft:orange_concrete
fill 512 230 446 512 235 446 minecraft:netherrack
setblock 512 230 448 minecraft:orange_concrete
fill 512 230 449 512 235 450 minecraft:netherrack
fill 512 230 451 512 231 451 minecraft:orange_concrete
fill 512 230 457 512 235 457 minecraft:netherrack
setblock 470 231 426 minecraft:orange_concrete
fill 470 231 430 470 234 431 minecraft:netherrack
setblock 470 231 447 minecraft:orange_concrete
setblock 470 231 450 minecraft:orange_concrete
fill 470 231 451 470 234 451 minecraft:netherrack
setblock 470 231 458 minecraft:orange_concrete
fill 471 231 416 471 234 416 minecraft:netherrack
setblock 472 231 416 minecraft:orange_concrete
fill 474 231 458 474 234 458 minecraft:netherrack
setblock 475 231 416 minecraft:orange_concrete
fill 476 231 441 478 231 441 minecraft:red_nether_bricks
fill 477 231 446 477 235 446 minecraft:red_nether_bricks
fill 479 231 446 480 237 446 minecraft:red_nether_bricks
fill 480 231 445 480 237 445 minecraft:red_nether_bricks
setblock 490 231 458 minecraft:orange_concrete
fill 491 231 416 492 234 416 minecraft:netherrack
setblock 494 231 458 minecraft:orange_concrete
fill 495 231 458 495 234 458 minecraft:netherrack
setblock 496 231 416 minecraft:orange_concrete
fill 506 231 458 506 233 458 minecraft:netherrack
setblock 507 231 416 minecraft:orange_concrete
setblock 511 231 458 minecraft:orange_concrete
fill 512 231 416 512 234 416 minecraft:netherrack
fill 512 231 427 512 234 427 minecraft:netherrack
setblock 512 231 428 minecraft:orange_concrete
fill 512 231 431 512 231 432 minecraft:orange_concrete
fill 512 231 448 512 234 448 minecraft:netherrack
setblock 512 231 452 minecraft:orange_concrete
fill 470 232 416 470 232 417 minecraft:orange_concrete
fill 470 232 418 470 237 419 minecraft:netherrack
fill 470 232 424 470 233 425 minecraft:orange_concrete
fill 470 232 426 470 237 427 minecraft:netherrack
setblock 470 232 428 minecraft:orange_concrete
fill 470 232 436 470 233 437 minecraft:orange_concrete
fill 470 232 438 470 237 439 minecraft:netherrack
fill 470 232 445 470 233 445 minecraft:orange_concrete
fill 470 232 446 470 233 447 minecraft:netherrack
fill 470 232 448 470 232 449 minecraft:orange_concrete
fill 470 232 450 470 237 450 minecraft:netherrack
fill 470 232 456 470 233 457 minecraft:orange_concrete
fill 470 232 458 471 237 458 minecraft:netherrack
fill 472 232 416 472 237 416 minecraft:netherrack
fill 473 232 416 474 232 416 minecraft:orange_concrete
setblock 473 232 419 minecraft:light[level=14]
setblock 473 232 427 minecraft:light[level=14]
setblock 473 232 435 minecraft:light[level=14]
setblock 473 232 443 minecraft:light[level=14]
setblock 473 232 451 minecraft:light[level=14]
fill 475 232 416 476 233 416 minecraft:netherrack
fill 477 232 416 477 233 416 minecraft:orange_concrete
fill 478 232 447 480 237 447 minecraft:red_nether_bricks
fill 480 232 458 481 232 458 minecraft:orange_concrete
setblock 481 232 419 minecraft:light[level=14]
setblock 481 232 427 minecraft:light[level=14]
setblock 481 232 435 minecraft:light[level=14]
setblock 481 232 443 minecraft:light[level=14]
fill 481 232 445 481 237 445 minecraft:red_nether_bricks
setblock 481 232 451 minecraft:light[level=14]
fill 482 232 458 483 237 458 minecraft:netherrack
fill 483 232 416 484 237 416 minecraft:netherrack
fill 485 232 416 486 233 416 minecraft:orange_concrete
fill 488 232 458 489 233 458 minecraft:orange_concrete
setblock 489 232 419 minecraft:light[level=14]
setblock 489 232 427 minecraft:light[level=14]
setblock 489 232 435 minecraft:light[level=14]
setblock 489 232 443 minecraft:light[level=14]
setblock 489 232 451 minecraft:light[level=14]
fill 490 232 458 491 237 458 minecraft:netherrack
setblock 492 232 458 minecraft:orange_concrete
setblock 494 232 416 minecraft:orange_concrete
fill 494 232 458 494 234 458 minecraft:netherrack
fill 495 232 416 496 237 416 minecraft:netherrack
fill 497 232 416 498 233 416 minecraft:orange_concrete
setblock 497 232 419 minecraft:light[level=14]
setblock 497 232 427 minecraft:light[level=14]
setblock 497 232 435 minecraft:light[level=14]
setblock 497 232 443 minecraft:light[level=14]
setblock 497 232 451 minecraft:light[level=14]
fill 500 232 458 501 233 458 minecraft:orange_concrete
fill 502 232 458 503 237 458 minecraft:netherrack
fill 503 232 416 504 237 416 minecraft:netherrack
fill 505 232 416 506 232 416 minecraft:orange_concrete
setblock 505 232 419 minecraft:light[level=14]
setblock 505 232 427 minecraft:light[level=14]
setblock 505 232 435 minecraft:light[level=14]
setblock 505 232 443 minecraft:light[level=14]
setblock 505 232 451 minecraft:light[level=14]
fill 507 232 416 507 237 416 minecraft:netherrack
setblock 508 232 458 minecraft:netherrack
fill 509 232 458 509 233 458 minecraft:orange_concrete
fill 511 232 458 511 237 458 minecraft:netherrack
fill 512 232 419 512 237 420 minecraft:netherrack
fill 512 232 421 512 233 422 minecraft:orange_concrete
fill 512 232 428 512 237 428 minecraft:netherrack
setblock 512 232 430 minecraft:orange_concrete
fill 512 232 431 512 237 432 minecraft:netherrack
fill 512 232 433 512 233 433 minecraft:orange_concrete
fill 512 232 439 512 237 440 minecraft:netherrack
fill 512 232 441 512 232 442 minecraft:orange_concrete
fill 512 232 451 512 237 452 minecraft:netherrack
fill 512 232 453 512 233 454 minecraft:orange_concrete
fill 512 232 458 512 233 458 minecraft:orange_concrete
setblock 470 233 416 minecraft:orange_concrete
fill 470 233 417 470 236 417 minecraft:netherrack
fill 470 233 428 470 236 428 minecraft:netherrack
setblock 470 233 433 minecraft:orange_concrete
setblock 470 233 444 minecraft:orange_concrete
fill 470 233 448 470 236 449 minecraft:netherrack
fill 473 233 416 474 236 416 minecraft:netherrack
fill 476 233 442 476 234 442 minecraft:magma_block
fill 477 233 442 478 233 443 minecraft:red_nether_bricks
fill 477 233 447 477 235 447 minecraft:red_nether_bricks
setblock 477 233 458 minecraft:orange_concrete
setblock 478 233 416 minecraft:orange_concrete
fill 478 233 448 480 237 448 minecraft:red_nether_bricks
fill 479 233 443 479 234 443 minecraft:red_nether_bricks
setblock 480 233 458 minecraft:orange_concrete
fill 481 233 446 481 238 447 minecraft:red_nether_bricks
fill 481 233 458 481 236 458 minecraft:netherrack
setblock 489 233 416 minecraft:orange_concrete
fill 492 233 458 492 236 458 minecraft:netherrack
fill 494 233 416 494 236 416 minecraft:netherrack
fill 496 233 458 496 235 458 minecraft:netherrack
setblock 497 233 458 minecraft:orange_concrete
fill 505 233 416 505 236 416 minecraft:netherrack
setblock 506 233 416 minecraft:orange_concrete
setblock 508 233 458 minecraft:orange_concrete
fill 509 233 416 510 233 416 minecraft:orange_concrete
fill 512 233 430 512 236 430 minecraft:netherrack
setblock 512 233 434 minecraft:orange_concrete
fill 512 233 441 512 236 441 minecraft:netherrack
setblock 512 233 442 minecraft:orange_concrete
setblock 512 233 445 minecraft:orange_concrete
fill 470 234 416 470 239 416 minecraft:netherrack
fill 470 234 422 470 235 423 minecraft:orange_concrete
fill 470 234 424 470 239 425 minecraft:netherrack
fill 470 234 433 470 239 433 minecraft:netherrack
fill 470 234 434 470 234 435 minecraft:orange_concrete
fill 470 234 436 470 239 437 minecraft:netherrack
fill 470 234 442 470 235 443 minecraft:orange_concrete
fill 470 234 444 470 239 445 minecraft:netherrack
setblock 470 234 446 minecraft:orange_concrete
fill 470 234 447 470 237 447 minecraft:netherrack
fill 470 234 454 470 235 455 minecraft:orange_concrete
fill 470 234 456 470 239 457 minecraft:netherrack
fill 471 234 417 473 234 417 minecraft:red_nether_bricks
fill 471 234 419 471 234 421 minecraft:red_nether_bricks
fill 471 234 423 471 234 425 minecraft:red_nether_bricks
fill 471 234 427 471 234 429 minecraft:red_nether_bricks
fill 471 234 431 471 234 433 minecraft:red_nether_bricks
fill 471 234 435 471 234 437 minecraft:red_nether_bricks
fill 471 234 439 471 234 441 minecraft:red_nether_bricks
fill 471 234 443 471 234 445 minecraft:red_nether_bricks
fill 471 234 447 471 234 449 minecraft:red_nether_bricks
fill 471 234 451 471 234 453 minecraft:red_nether_bricks
fill 471 234 455 471 234 457 minecraft:red_nether_bricks
fill 473 234 457 475 234 457 minecraft:red_nether_bricks
fill 475 234 416 475 237 416 minecraft:netherrack
fill 475 234 417 477 234 417 minecraft:red_nether_bricks
fill 475 234 458 475 235 458 minecraft:orange_concrete
setblock 476 234 416 minecraft:orange_concrete
fill 477 234 416 478 239 416 minecraft:netherrack
fill 477 234 442 477 235 442 minecraft:magma_block
fill 477 234 444 478 234 444 minecraft:red_nether_bricks
fill 477 234 457 479 234 457 minecraft:red_nether_bricks
fill 477 234 458 477 239 458 minecraft:netherrack
setblock 478 234 443 minecraft:red_nether_bricks
fill 478 234 458 479 234 458 minecraft:orange_concrete
fill 479 234 416 480 235 416 minecraft:orange_concrete
fill 479 234 417 481 234 417 minecraft:red_nether_bricks
fill 480 234 444 480 235 444 minecraft:red_nether_bricks
fill 480 234 449 480 240 449 minecraft:red_nether_bricks
fill 480 234 458 480 239 458 minecraft:netherrack
fill 481 234 448 481 240 448 minecraft:red_nether_bricks
fill 481 234 457 483 234 457 minecraft:red_nether_bricks
fill 482 234 447 482 240 447 minecraft:red_nether_bricks
fill 483 234 417 485 234 417 minecraft:red_nether_bricks
fill 485 234 416 486 239 416 minecraft:netherrack
fill 485 234 457 487 234 457 minecraft:red_nether_bricks
fill 486 234 458 487 235 458 minecraft:orange_concrete
fill 487 234 416 488 234 416 minecraft:orange_concrete
fill 487 234 417 489 234 417 minecraft:red_nether_bricks
fill 488 234 458 489 239 458 minecraft:netherrack
fill 489 234 416 489 239 416 minecraft:netherrack
fill 489 234 457 491 234 457 minecraft:red_nether_bricks
fill 491 234 417 493 234 417 minecraft:red_nether_bricks
fill 493 234 457 495 234 457 minecraft:red_nether_bricks
fill 495 234 417 497 234 417 minecraft:red_nether_bricks
fill 497 234 416 498 239 416 minecraft:netherrack
fill 497 234 457 499 234 457 minecraft:red_nether_bricks
fill 497 234 458 497 235 458 minecraft:netherrack
fill 498 234 458 499 234 458 minecraft:orange_concrete
fill 499 234 416 500 235 416 minecraft:orange_concrete
fill 499 234 417 501 234 417 minecraft:red_nether_bricks
fill 500 234 458 501 239 458 minecraft:netherrack
fill 501 234 457 503 234 457 minecraft:red_nether_bricks
fill 503 234 417 505 234 417 minecraft:red_nether_bricks
fill 505 234 457 507 234 457 minecraft:red_nether_bricks
fill 506 234 416 506 239 416 minecraft:netherrack
fill 506 234 458 507 235 458 minecraft:orange_concrete
fill 507 234 417 509 234 417 minecraft:red_nether_bricks
setblock 508 234 416 minecraft:orange_concrete
fill 508 234 458 509 239 458 minecraft:netherrack
fill 509 234 416 510 239 416 minecraft:netherrack
fill 509 234 457 511 234 457 minecraft:red_nether_bricks
setblock 510 234 458 minecraft:orange_concrete
fill 511 234 416 511 235 416 minecraft:orange_concrete
fill 511 234 417 511 234 419 minecraft:red_nether_bricks
fill 511 234 421 511 234 423 minecraft:red_nether_bricks
fill 511 234 425 511 234 427 minecraft:red_nether_bricks
fill 511 234 429 511 234 431 minecraft:red_nether_bricks
fill 511 234 433 511 234 435 minecraft:red_nether_bricks
fill 511 234 437 511 234 439 minecraft:red_nether_bricks
fill 511 234 441 511 234 443 minecraft:red_nether_bricks
fill 511 234 445 511 234 447 minecraft:red_nether_bricks
fill 511 234 449 511 234 451 minecraft:red_nether_bricks
fill 511 234 453 511 234 455 minecraft:red_nether_bricks
fill 512 234 421 512 239 422 minecraft:netherrack
fill 512 234 423 512 234 424 minecraft:orange_concrete
fill 512 234 433 512 239 434 minecraft:netherrack
fill 512 234 435 512 235 436 minecraft:orange_concrete
fill 512 234 442 512 239 442 minecraft:netherrack
fill 512 234 443 512 234 444 minecraft:orange_concrete
fill 512 234 445 512 239 445 minecraft:netherrack
fill 512 234 447 512 235 447 minecraft:orange_concrete
fill 512 234 453 512 239 454 minecraft:netherrack
fill 512 234 455 512 235 456 minecraft:orange_concrete
fill 512 234 458 512 236 458 minecraft:netherrack
fill 470 235 430 470 235 431 minecraft:orange_concrete
setblock 470 235 434 minecraft:orange_concrete
fill 470 235 435 470 238 435 minecraft:netherrack
fill 470 235 446 470 238 446 minecraft:netherrack
setblock 470 235 451 minecraft:orange_concrete
setblock 471 235 416 minecraft:orange_concrete
setblock 474 235 458 minecraft:orange_concrete
fill 476 235 416 476 238 416 minecraft:netherrack
setblock 478 235 444 minecraft:red_nether_bricks
fill 478 235 458 479 237 458 minecraft:netherrack
fill 479 235 449 479 238 449 minecraft:red_nether_bricks
fill 481 235 449 482 241 449 minecraft:red_nether_bricks
fill 482 235 446 482 238 446 minecraft:red_nether_bricks
fill 482 235 448 482 241 448 minecraft:red_nether_bricks
fill 487 235 416 487 238 416 minecraft:netherrack
setblock 488 235 416 minecraft:orange_concrete
fill 491 235 416 492 235 416 minecraft:orange_concrete
fill 494 235 458 495 235 458 minecraft:orange_concrete
setblock 498 235 458 minecraft:orange_concrete
fill 499 235 458 499 238 458 minecraft:netherrack
fill 508 235 416 508 238 416 minecraft:netherrack
fill 510 235 458 510 238 458 minecraft:netherrack
setblock 512 235 416 minecraft:orange_concrete
fill 512 235 423 512 238 423 minecraft:netherrack
setblock 512 235 424 minecraft:orange_concrete
setblock 512 235 427 minecraft:orange_concrete
fill 512 235 443 512 238 444 minecraft:netherrack
setblock 512 235 448 minecraft:orange_concrete
fill 470 236 420 470 236 421 minecraft:orange_concrete
fill 470 236 422 470 241 423 minecraft:netherrack
fill 470 236 429 470 237 429 minecraft:orange_concrete
fill 470 236 430 470 241 431 minecraft:netherrack
setblock 470 236 432 minecraft:orange_concrete
fill 470 236 434 470 241 434 minecraft:netherrack
fill 470 236 440 470 237 441 minecraft:orange_concrete
fill 470 236 442 470 241 443 minecraft:netherrack
fill 470 236 451 470 241 451 minecraft:netherrack
fill 470 236 452 470 236 453 minecraft:orange_concrete
fill 470 236 454 470 241 455 minecraft:netherrack
fill 471 236 416 471 241 416 minecraft:netherrack
fill 472 236 458 473 237 458 minecraft:orange_concrete
fill 474 236 458 475 241 458 minecraft:netherrack
setblock 476 236 458 minecraft:orange_concrete
setblock 478 236 445 minecraft:red_nether_bricks
fill 479 236 416 480 241 416 minecraft:netherrack
fill 480 236 450 482 239 450 minecraft:red_nether_bricks
fill 481 236 416 482 237 416 minecraft:orange_concrete
fill 483 236 447 483 240 449 minecraft:red_nether_bricks
fill 484 236 458 485 237 458 minecraft:orange_concrete
fill 486 236 458 487 241 458 minecraft:netherrack
fill 488 236 416 488 241 416 minecraft:netherrack
setblock 490 236 416 minecraft:orange_concrete
fill 491 236 416 492 241 416 minecraft:netherrack
fill 493 236 416 493 237 416 minecraft:orange_concrete
fill 493 236 458 493 237 458 minecraft:orange_concrete
fill 494 236 458 495 237 458 minecraft:netherrack
fill 496 236 458 497 236 458 minecraft:orange_concrete
fill 498 236 458 498 241 458 minecraft:netherrack
fill 499 236 416 500 241 416 minecraft:netherrack
fill 501 236 416 502 236 416 minecraft:orange_concrete
fill 504 236 458 505 237 458 minecraft:orange_concrete
fill 506 236 458 507 241 458 minecraft:netherrack
fill 511 236 416 512 241 416 minecraft:netherrack
fill 512 236 417 512 237 418 minecraft:orange_concrete
fill 512 236 424 512 241 424 minecraft:netherrack
fill 512 236 425 512 236 426 minecraft:orange_concrete
fill 512 236 427 512 241 427 minecraft:netherrack
fill 512 236 429 512 237 429 minecraft:orange_concrete
fill 512 236 435 512 241 436 minecraft:netherrack
fill 512 236 437 512 237 438 minecraft:orange_concrete
setblock 512 236 446 minecraft:orange_concrete
fill 512 236 447 512 241 448 minecraft:netherrack
fill 512 236 449 512 237 450 minecraft:orange_concrete
fill 512 236 455 512 241 456 minecraft:netherrack
setblock 512 236 457 minecraft:orange_concrete
setblock 470 237 417 minecraft:orange_concrete
setblock 470 237 420 minecraft:orange_concrete
fill 470 237 421 470 240 421 minecraft:netherrack
setblock 470 237 428 minecraft:orange_concrete
fill 470 237 432 470 240 432 minecraft:netherrack
fill 470 237 448 470 237 449 minecraft:orange_concrete
setblock 470 237 452 minecraft:orange_concrete
fill 470 237 453 470 240 453 minecraft:netherrack
fill 473 237 416 474 237 416 minecraft:orange_concrete
fill 476 237 458 476 239 458 minecraft:netherrack
setblock 481 237 458 minecraft:orange_concrete
fill 483 237 450 483 243 450 minecraft:red_nether_bricks
fill 484 237 448 484 242 449 minecraft:red_nether_bricks
fill 490 237 416 490 240 416 minecraft:netherrack
setblock 492 237 458 minecraft:orange_concrete
setblock 494 237 416 minecraft:orange_concrete
fill 496 237 458 497 239 458 minecraft:netherrack
fill 501 237 416 501 240 416 minecraft:netherrack
setblock 502 237 416 minecraft:orange_concrete
setblock 505 237 416 minecraft:orange_concrete
fill 512 237 425 512 240 426 minecraft:netherrack
setblock 512 237 430 minecraft:orange_concrete
setblock 512 237 441 minecraft:orange_concrete
fill 512 237 446 512 240 446 minecraft:netherrack
fill 512 237 457 512 240 457 minecraft:netherrack
setblock 512 237 458 minecraft:orange_concrete
fill 470 238 417 470 243 417 minecraft:netherrack
fill 470 238 418 470 238 419 minecraft:orange_concrete
fill 470 238 420 470 243 420 minecraft:netherrack
fill 470 238 426 470 239 427 minecraft:orange_concrete
fill 470 238 428 470 243 429 minecraft:netherrack
fill 470 238 438 470 238 439 minecraft:orange_concrete
fill 470 238 440 470 243 441 minecraft:netherrack
fill 470 238 447 470 239 447 minecraft:orange_concrete
fill 470 238 448 470 243 449 minecraft:netherrack
setblock 470 238 450 minecraft:orange_concrete
fill 470 238 452 470 243 452 minecraft:netherrack
fill 470 238 458 471 239 458 minecraft:orange_concrete
setblock 472 238 416 minecraft:orange_concrete
fill 472 238 458 473 243 458 minecraft:netherrack
fill 473 238 416 474 243 416 minecraft:netherrack
fill 475 238 416 475 239 416 minecraft:orange_concrete
setblock 478 238 458 minecraft:netherrack
fill 479 238 447 480 238 448 minecraft:red_nether_bricks
fill 479 238 458 479 239 458 minecraft:orange_concrete
setblock 480 238 446 minecraft:red_nether_bricks
fill 481 238 416 482 243 416 minecraft:netherrack
fill 481 238 451 484 240 451 minecraft:red_nether_bricks
fill 481 238 458 481 243 458 minecraft:netherrack
fill 482 238 458 483 238 458 minecraft:orange_concrete
fill 483 238 416 484 238 416 minecraft:orange_concrete
fill 484 238 450 484 244 450 minecraft:red_nether_bricks
fill 484 238 458 485 240 458 minecraft:netherrack
fill 490 238 458 491 239 458 minecraft:orange_concrete
fill 492 238 458 493 243 458 minecraft:netherrack
fill 493 238 416 494 243 416 minecraft:netherrack
setblock 494 238 458 minecraft:orange_concrete
fill 495 238 416 496 239 416 minecraft:orange_concrete
fill 495 238 458 495 241 458 minecraft:netherrack
fill 502 238 416 502 243 416 minecraft:netherrack
fill 502 238 458 503 239 458 minecraft:orange_concrete
fill 503 238 416 504 238 416 minecraft:orange_concrete
fill 504 238 458 505 243 458 minecraft:netherrack
fill 505 238 416 505 243 416 minecraft:netherrack
fill 507 238 416 507 239 416 minecraft:orange_concrete
fill 511 238 458 511 239 458 minecraft:orange_concrete
fill 512 238 417 512 243 418 minecraft:netherrack
fill 512 238 419 512 239 420 minecraft:orange_concrete
setblock 512 238 428 minecraft:orange_concrete
fill 512 238 429 512 243 430 minecraft:netherrack
fill 512 238 431 512 239 432 minecraft:orange_concrete
fill 512 238 437 512 243 438 minecraft:netherrack
fill 512 238 439 512 238 440 minecraft:orange_concrete
fill 512 238 441 512 243 441 minecraft:netherrack
fill 512 238 449 512 243 450 minecraft:netherrack
fill 512 238 451 512 239 452 minecraft:orange_concrete
fill 512 238 458 512 243 458 minecraft:netherrack
fill 470 239 418 470 242 419 minecraft:netherrack
setblock 470 239 435 minecraft:orange_concrete
setblock 470 239 438 minecraft:orange_concrete
fill 470 239 439 470 242 439 minecraft:netherrack
setblock 470 239 446 minecraft:orange_concrete
fill 470 239 450 470 242 450 minecraft:netherrack
fill 472 239 416 472 242 416 minecraft:netherrack
setblock 476 239 416 minecraft:orange_concrete
setblock 478 239 458 minecraft:orange_concrete
fill 479 239 434 479 240 434 minecraft:netherrack
fill 480 239 447 480 239 448 minecraft:red_nether_bricks
fill 481 239 447 481 240 447 minecraft:red_nether_bricks
setblock 482 239 458 minecraft:orange_concrete
fill 483 239 416 483 242 416 minecraft:netherrack
fill 483 239 452 483 243 452 minecraft:red_nether_bricks
fill 483 239 458 483 242 458 minecraft:netherrack
setblock 484 239 416 minecraft:orange_concrete
fill 485 239 449 485 244 451 minecraft:red_nether_bricks
setblock 487 239 416 minecraft:orange_concrete
fill 494 239 458 494 241 458 minecraft:netherrack
fill 495 239 420 496 240 421 minecraft:netherrack
fill 496 239 419 496 240 419 minecraft:netherrack
setblock 499 239 458 minecraft:orange_concrete
fill 503 239 416 504 242 416 minecraft:netherrack
setblock 508 239 416 minecraft:orange_concrete
setblock 510 239 458 minecraft:orange_concrete
setblock 512 239 423 minecraft:orange_concrete
fill 512 239 428 512 242 428 minecraft:netherrack
fill 512 239 439 512 242 439 minecraft:netherrack
setblock 512 239 440 minecraft:orange_concrete
fill 512 239 443 512 239 444 minecraft:orange_concrete
setblock 470 240 416 minecraft:orange_concrete
fill 470 240 424 470 241 425 minecraft:orange_concrete
fill 470 240 426 470 245 427 minecraft:netherrack
fill 470 240 433 470 241 433 minecraft:orange_concrete
fill 470 240 435 470 245 435 minecraft:netherrack
fill 470 240 436 470 240 437 minecraft:orange_concrete
fill 470 240 438 470 245 438 minecraft:netherrack
fill 470 240 444 470 241 445 minecraft:orange_concrete
fill 470 240 446 470 245 447 minecraft:netherrack
fill 470 240 456 470 240 457 minecraft:orange_concrete
fill 470 240 458 471 245 458 minecraft:netherrack
fill 471 240 417 473 240 417 minecraft:red_nether_bricks
fill 471 240 419 471 240 421 minecraft:red_nether_bricks
fill 471 240 423 471 240 425 minecraft:red_nether_bricks
fill 471 240 427 471 240 429 minecraft:red_nether_bricks
fill 471 240 431 471 240 433 minecraft:red_nether_bricks
fill 471 240 435 471 240 437 minecraft:red_nether_bricks
fill 471 240 439 471 240 441 minecraft:red_nether_bricks
fill 471 240 443 471 240 445 minecraft:red_nether_bricks
fill 471 240 447 471 240 449 minecraft:red_nether_bricks
fill 471 240 451 471 240 453 minecraft:red_nether_bricks
fill 471 240 455 471 240 457 minecraft:red_nether_bricks
setblock 473 240 419 minecraft:light[level=14]
setblock 473 240 427 minecraft:light[level=14]
setblock 473 240 435 minecraft:light[level=14]
setblock 473 240 443 minecraft:light[level=14]
setblock 473 240 451 minecraft:light[level=14]
fill 473 240 457 475 240 457 minecraft:red_nether_bricks
fill 475 240 416 476 245 416 minecraft:netherrack
fill 475 240 417 477 240 417 minecraft:red_nether_bricks
fill 476 240 458 477 241 458 minecraft:orange_concrete
fill 477 240 416 478 241 416 minecraft:orange_concrete
fill 477 240 457 479 240 457 minecraft:red_nether_bricks
fill 478 240 458 479 245 458 minecraft:netherrack
fill 479 240 417 481 240 417 minecraft:red_nether_bricks
setblock 480 240 458 minecraft:orange_concrete
setblock 481 240 419 minecraft:light[level=14]
setblock 481 240 427 minecraft:light[level=14]
setblock 481 240 435 minecraft:light[level=14]
setblock 481 240 443 minecraft:light[level=14]
fill 481 240 450 482 241 450 minecraft:red_nether_bricks
fill 481 240 457 483 240 457 minecraft:red_nether_bricks
fill 482 240 452 482 241 452 minecraft:red_nether_bricks
fill 482 240 458 482 242 458 minecraft:netherrack
fill 483 240 417 485 240 417 minecraft:red_nether_bricks
fill 484 240 416 484 245 416 minecraft:netherrack
fill 484 240 452 485 244 452 minecraft:red_nether_bricks
fill 485 240 416 486 240 416 minecraft:orange_concrete
fill 485 240 448 485 242 448 minecraft:red_nether_bricks
fill 485 240 457 487 240 457 minecraft:red_nether_bricks
fill 486 240 449 486 245 451 minecraft:red_nether_bricks
fill 487 240 416 487 245 416 minecraft:netherrack
fill 487 240 417 489 240 417 minecraft:red_nether_bricks
fill 488 240 458 489 241 458 minecraft:orange_concrete
fill 489 240 416 489 241 416 minecraft:orange_concrete
setblock 489 240 419 minecraft:light[level=14]
setblock 489 240 427 minecraft:light[level=14]
setblock 489 240 435 minecraft:light[level=14]
setblock 489 240 443 minecraft:light[level=14]
setblock 489 240 451 minecraft:light[level=14]
fill 489 240 457 491 240 457 minecraft:red_nether_bricks
fill 490 240 458 491 245 458 minecraft:netherrack
fill 491 240 417 493 240 417 minecraft:red_nether_bricks
fill 493 240 457 495 240 457 minecraft:red_nether_bricks
fill 495 240 416 496 245 416 minecraft:netherrack
fill 495 240 417 497 240 417 minecraft:red_nether_bricks
setblock 496 240 458 minecraft:netherrack
fill 497 240 416 498 241 416 minecraft:orange_concrete
setblock 497 240 419 minecraft:light[level=14]
setblock 497 240 427 minecraft:light[level=14]
setblock 497 240 435 minecraft:light[level=14]
setblock 497 240 443 minecraft:light[level=14]
setblock 497 240 451 minecraft:light[level=14]
fill 497 240 457 499 240 457 minecraft:red_nether_bricks
fill 497 240 458 497 241 458 minecraft:orange_concrete
fill 499 240 417 501 240 417 minecraft:red_nether_bricks
fill 499 240 458 499 245 458 minecraft:netherrack
fill 500 240 458 501 240 458 minecraft:orange_concrete
fill 501 240 457 503 240 457 minecraft:red_nether_bricks
fill 502 240 458 503 242 458 minecraft:netherrack
fill 503 240 417 505 240 417 minecraft:red_nether_bricks
setblock 505 240 419 minecraft:light[level=14]
setblock 505 240 427 minecraft:light[level=14]
setblock 505 240 435 minecraft:light[level=14]
setblock 505 240 443 minecraft:light[level=14]
setblock 505 240 451 minecraft:light[level=14]
fill 505 240 457 507 240 457 minecraft:red_nether_bricks
setblock 506 240 416 minecraft:orange_concrete
fill 507 240 416 508 245 416 minecraft:netherrack
fill 507 240 417 509 240 417 minecraft:red_nether_bricks
fill 508 240 458 509 241 458 minecraft:orange_concrete
fill 509 240 416 510 241 416 minecraft:orange_concrete
fill 509 240 457 511 240 457 minecraft:red_nether_bricks
fill 510 240 458 511 245 458 minecraft:netherrack
fill 511 240 417 511 240 419 minecraft:red_nether_bricks
fill 511 240 421 511 240 423 minecraft:red_nether_bricks
fill 511 240 425 511 240 427 minecraft:red_nether_bricks
fill 511 240 429 511 240 431 minecraft:red_nether_bricks
fill 511 240 433 511 240 435 minecraft:red_nether_bricks
fill 511 240 437 511 240 439 minecraft:red_nether_bricks
fill 511 240 441 511 240 443 minecraft:red_nether_bricks
fill 511 240 445 511 240 447 minecraft:red_nether_bricks
fill 511 240 449 511 240 451 minecraft:red_nether_bricks
fill 511 240 453 511 240 455 minecraft:red_nether_bricks
fill 512 240 419 512 245 420 minecraft:netherrack
fill 512 240 421 512 240 422 minecraft:orange_concrete
fill 512 240 423 512 245 423 minecraft:netherrack
fill 512 240 431 512 245 432 minecraft:netherrack
fill 512 240 433 512 241 434 minecraft:orange_concrete
fill 512 240 440 512 245 440 minecraft:netherrack
setblock 512 240 442 minecraft:orange_concrete
fill 512 240 443 512 245 444 minecraft:netherrack
fill 512 240 445 512 241 445 minecraft:orange_concrete
fill 512 240 451 512 245 452 minecraft:netherrack
fill 512 240 453 512 240 454 minecraft:orange_concrete
fill 470 241 416 470 244 416 minecraft:netherrack
setblock 470 241 421 minecraft:orange_concrete
setblock 470 241 432 minecraft:orange_concrete
fill 470 241 436 470 244 437 minecraft:netherrack
setblock 470 241 453 minecraft:orange_concrete
setblock 470 241 456 minecraft:orange_concrete
fill 470 241 457 470 244 457 minecraft:netherrack
fill 480 241 458 480 244 458 minecraft:netherrack
fill 482 241 451 484 242 451 minecraft:red_nether_bricks
fill 483 241 448 483 242 449 minecraft:red_nether_bricks
fill 484 241 458 484 243 458 minecraft:netherrack
fill 485 241 416 486 244 416 minecraft:netherrack
setblock 485 241 458 minecraft:orange_concrete
fill 486 241 452 486 247 452 minecraft:red_nether_bricks
fill 487 241 450 487 247 451 minecraft:red_nether_bricks
setblock 490 241 416 minecraft:orange_concrete
setblock 496 241 458 minecraft:orange_concrete
setblock 500 241 458 minecraft:orange_concrete
setblock 501 241 416 minecraft:orange_concrete
fill 501 241 458 501 244 458 minecraft:netherrack
fill 505 241 430 506 242 431 minecraft:netherrack
fill 506 241 416 506 244 416 minecraft:netherrack
fill 507 241 430 507 242 430 minecraft:netherrack
fill 512 241 421 512 244 421 minecraft:netherrack
setblock 512 241 422 minecraft:orange_concrete
fill 512 241 425 512 241 426 minecraft:orange_concrete
fill 512 241 442 512 244 442 minecraft:netherrack
setblock 512 241 446 minecraft:orange_concrete
fill 512 241 453 512 244 453 minecraft:netherrack
setblock 512 241 454 minecraft:orange_concrete
setblock 512 241 457 minecraft:orange_concrete
fill 470 242 421 470 247 421 minecraft:netherrack
fill 470 242 422 470 242 423 minecraft:orange_concrete
fill 470 242 424 470 247 425 minecraft:netherrack
fill 470 242 430 470 243 431 minecraft:orange_concrete
fill 470 242 432 470 247 433 minecraft:netherrack
setblock 470 242 434 minecraft:orange_concrete
fill 470 242 442 470 243 443 minecraft:orange_concrete
fill 470 242 444 470 247 445 minecraft:netherrack
fill 470 242 451 470 243 451 minecraft:orange_concrete
fill 470 242 453 470 247 453 minecraft:netherrack
fill 470 242 454 470 242 455 minecraft:orange_concrete
fill 470 242 456 470 247 456 minecraft:netherrack
fill 471 242 416 471 243 416 minecraft:orange_concrete
fill 474 242 458 475 243 458 minecraft:orange_concrete
fill 476 242 458 477 247 458 minecraft:netherrack
fill 477 242 416 478 247 416 minecraft:netherrack
fill 479 242 416 480 243 416 minecraft:orange_concrete
fill 482 242 449 482 242 450 minecraft:red_nether_bricks
fill 485 242 453 486 244 453 minecraft:red_nether_bricks
fill 485 242 458 485 243 458 minecraft:netherrack
fill 486 242 458 487 242 458 minecraft:orange_concrete
fill 487 242 449 487 245 449 minecraft:red_nether_bricks
fill 487 242 452 487 248 452 minecraft:red_nether_bricks
setblock 488 242 416 minecraft:orange_concrete
fill 488 242 451 488 249 451 minecraft:red_nether_bricks
fill 488 242 458 489 247 458 minecraft:netherrack
fill 489 242 416 490 247 416 minecraft:netherrack
fill 491 242 416 492 243 416 minecraft:orange_concrete
fill 494 242 458 495 243 458 minecraft:orange_concrete
fill 496 242 458 497 247 458 minecraft:netherrack
fill 497 242 416 498 247 416 minecraft:netherrack
setblock 498 242 458 minecraft:orange_concrete
fill 499 242 416 500 242 416 minecraft:orange_concrete
fill 500 242 458 500 244 458 minecraft:netherrack
fill 501 242 416 501 247 416 minecraft:netherrack
fill 506 242 458 507 243 458 minecraft:orange_concrete
fill 508 242 458 509 247 458 minecraft:netherrack
fill 509 242 416 510 247 416 minecraft:netherrack
fill 511 242 416 512 243 416 minecraft:orange_concrete
fill 512 242 422 512 247 422 minecraft:netherrack
setblock 512 242 424 minecraft:orange_concrete
fill 512 242 425 512 247 426 minecraft:netherrack
fill 512 242 427 512 243 427 minecraft:orange_concrete
fill 512 242 433 512 247 434 minecraft:netherrack
fill 512 242 435 512 242 436 minecraft:orange_concrete
fill 512 242 445 512 247 446 minecraft:netherrack
fill 512 242 447 512 243 448 minecraft:orange_concrete
fill 512 242 454 512 247 454 minecraft:netherrack
fill 512 242 455 512 242 456 minecraft:orange_concrete
fill 512 242 457 512 247 457 minecraft:netherrack
fill 470 243 418 470 243 419 minecraft:orange_concrete
setblock 470 243 422 minecraft:orange_concrete
fill 470 243 423 470 246 423 minecraft:netherrack
fill 470 243 434 470 246 434 minecraft:netherrack
setblock 470 243 439 minecraft:orange_concrete
setblock 470 243 450 minecraft:orange_concrete
fill 470 243 454 470 245 455 minecraft:netherrack
setblock 472 243 416 minecraft:orange_concrete
fill 482 243 458 483 243 458 minecraft:orange_concrete
setblock 483 243 416 minecraft:orange_concrete
fill 483 243 449 484 243 449 minecraft:red_nether_bricks
fill 483 243 451 484 243 451 minecraft:red_nether_bricks
setblock 486 243 458 minecraft:orange_concrete
fill 487 243 453 488 248 453 minecraft:red_nether_bricks
fill 487 243 458 487 246 458 minecraft:netherrack
fill 488 243 416 488 246 416 minecraft:netherrack
fill 488 243 450 488 248 450 minecraft:red_nether_bricks
fill 488 243 452 488 249 452 minecraft:red_nether_bricks
fill 489 243 451 489 250 451 minecraft:red_nether_bricks
fill 498 243 458 498 246 458 minecraft:netherrack
fill 499 243 416 499 246 416 minecraft:netherrack
setblock 500 243 416 minecraft:orange_concrete
fill 502 243 458 502 245 458 minecraft:netherrack
fill 503 243 416 504 243 416 minecraft:orange_concrete
setblock 503 243 458 minecraft:orange_concrete
fill 512 243 424 512 246 424 minecraft:netherrack
setblock 512 243 428 minecraft:orange_concrete
fill 512 243 435 512 246 435 minecraft:netherrack
setblock 512 243 436 minecraft:orange_concrete
setblock 512 243 439 minecraft:orange_concrete
fill 512 243 455 512 246 456 minecraft:netherrack
fill 470 244 417 470 245 417 minecraft:orange_concrete
fill 470 244 418 470 249 419 minecraft:netherrack
setblock 470 244 420 minecraft:orange_concrete
fill 470 244 422 470 249 422 minecraft:netherrack
fill 470 244 428 470 245 429 minecraft:orange_concrete
fill 470 244 430 470 249 431 minecraft:netherrack
fill 470 244 439 470 249 439 minecraft:netherrack
fill 470 244 440 470 244 441 minecraft:orange_concrete
fill 470 244 442 470 249 443 minecraft:netherrack
fill 470 244 448 470 245 449 minecraft:orange_concrete
fill 470 244 450 470 249 451 minecraft:netherrack
setblock 470 244 452 minecraft:orange_concrete
fill 471 244 416 472 249 416 minecraft:netherrack
fill 472 244 458 473 245 458 minecraft:orange_concrete
fill 473 244 416 474 245 416 minecraft:orange_concrete
fill 474 244 458 475 249 458 minecraft:netherrack
fill 479 244 416 480 249 416 minecraft:netherrack
fill 481 244 416 482 244 416 minecraft:orange_concrete
fill 481 244 458 481 245 458 minecraft:orange_concrete
fill 482 244 458 483 245 458 minecraft:netherrack
fill 483 244 416 483 249 416 minecraft:netherrack
fill 483 244 450 483 246 450 minecraft:magma_block
setblock 484 244 449 minecraft:red_nether_bricks
fill 484 244 451 484 245 451 minecraft:red_nether_bricks
fill 484 244 458 485 244 458 minecraft:orange_concrete
fill 486 244 458 486 249 458 minecraft:netherrack
fill 488 244 449 488 245 449 minecraft:red_nether_bricks
fill 489 244 450 489 249 450 minecraft:red_nether_bricks
fill 489 244 452 489 250 453 minecraft:red_nether_bricks
fill 491 244 416 492 249 416 minecraft:netherrack
fill 492 244 458 493 245 458 minecraft:orange_concrete
fill 493 244 416 494 245 416 minecraft:orange_concrete
fill 494 244 458 495 249 458 minecraft:netherrack
fill 500 244 416 500 249 416 minecraft:netherrack
setblock 502 244 416 minecraft:orange_concrete
fill 503 244 416 504 249 416 minecraft:netherrack
fill 503 244 458 503 249 458 minecraft:netherrack
fill 504 244 458 505 244 458 minecraft:orange_concrete
fill 505 244 416 505 245 416 minecraft:orange_concrete
fill 506 244 458 507 249 458 minecraft:netherrack
fill 511 244 416 512 249 416 minecraft:netherrack
fill 512 244 417 512 244 418 minecraft:orange_concrete
fill 512 244 427 512 249 428 minecraft:netherrack
fill 512 244 429 512 245 430 minecraft:orange_concrete
fill 512 244 436 512 249 436 minecraft:netherrack
fill 512 244 437 512 244 438 minecraft:orange_concrete
fill 512 244 439 512 249 439 minecraft:netherrack
fill 512 244 441 512 245 441 minecraft:orange_concrete
fill 512 244 447 512 249 448 minecraft:netherrack
fill 512 244 449 512 245 450 minecraft:orange_concrete
fill 512 244 458 512 245 458 minecraft:orange_concrete
setblock 470 245 416 minecraft:orange_concrete
fill 470 245 420 470 248 420 minecraft:netherrack
fill 470 245 436 470 245 437 minecraft:orange_concrete
setblock 470 245 440 minecraft:orange_concrete
fill 470 245 441 470 248 441 minecraft:netherrack
fill 470 245 452 470 247 452 minecraft:netherrack
setblock 470 245 457 minecraft:orange_concrete
fill 471 245 452 473 245 454 minecraft:magma_block
fill 474 245 453 475 246 453 minecraft:magma_block
setblock 480 245 458 minecraft:orange_concrete
fill 481 245 416 481 248 416 minecraft:netherrack
setblock 482 245 416 minecraft:orange_concrete
fill 484 245 450 484 246 450 minecraft:magma_block
fill 484 245 458 485 247 458 minecraft:netherrack
fill 485 245 416 486 245 416 minecraft:orange_concrete
fill 485 245 450 485 245 452 minecraft:red_nether_bricks
fill 486 245 453 486 246 453 minecraft:red_nether_bricks
fill 487 245 454 488 246 454 minecraft:red_nether_bricks
fill 490 245 451 490 251 453 minecraft:red_nether_bricks
fill 500 245 458 501 245 458 minecraft:orange_concrete
fill 502 245 416 502 248 416 minecraft:netherrack
setblock 504 245 458 minecraft:orange_concrete
fill 505 245 458 505 248 458 minecraft:netherrack
setblock 506 245 416 minecraft:orange_concrete
fill 512 245 417 512 248 417 minecraft:netherrack
setblock 512 245 418 minecraft:orange_concrete
setblock 512 245 421 minecraft:orange_concrete
fill 512 245 437 512 248 438 minecraft:netherrack
setblock 512 245 442 minecraft:orange_concrete
setblock 512 245 453 minecraft:orange_concrete
fill 470 246 416 470 251 417 minecraft:netherrack
fill 470 246 426 470 246 427 minecraft:orange_concrete
fill 470 246 428 470 251 429 minecraft:netherrack
fill 470 246 435 470 247 435 minecraft:orange_concrete
fill 470 246 436 470 251 437 minecraft:netherrack
setblock 470 246 438 minecraft:orange_concrete
fill 470 246 440 470 251 440 minecraft:netherrack
fill 470 246 446 470 247 447 minecraft:orange_concrete
fill 470 246 448 470 251 449 minecraft:netherrack
setblock 470 246 454 minecraft:netherrack
fill 470 246 455 470 247 455 minecraft:orange_concrete
fill 470 246 457 470 251 457 minecraft:netherrack
fill 470 246 458 471 246 458 minecraft:orange_concrete
fill 471 246 417 473 246 417 minecraft:red_nether_bricks
fill 471 246 419 471 246 421 minecraft:red_nether_bricks
fill 471 246 423 471 246 425 minecraft:red_nether_bricks
fill 471 246 427 471 246 429 minecraft:red_nether_bricks
fill 471 246 431 471 246 433 minecraft:red_nether_bricks
fill 471 246 435 471 246 437 minecraft:red_nether_bricks
fill 471 246 439 471 246 441 minecraft:red_nether_bricks
fill 471 246 443 471 246 445 minecraft:red_nether_bricks
fill 471 246 447 471 246 449 minecraft:red_nether_bricks
fill 471 246 451 471 246 453 minecraft:red_nether_bricks
fill 471 246 454 474 246 454 minecraft:magma_block
fill 471 246 455 471 246 457 minecraft:red_nether_bricks
fill 472 246 452 473 246 453 minecraft:magma_block
fill 472 246 458 473 248 458 minecraft:netherrack
fill 473 246 416 474 251 416 minecraft:netherrack
fill 473 246 457 475 246 457 minecraft:red_nether_bricks
setblock 474 246 452 minecraft:magma_block
fill 475 246 416 476 247 416 minecraft:orange_concrete
fill 475 246 417 477 246 417 minecraft:red_nether_bricks
fill 476 246 453 478 246 453 minecraft:magma_block
fill 477 246 457 479 246 457 minecraft:red_nether_bricks
fill 478 246 458 479 247 458 minecraft:orange_concrete
fill 479 246 417 481 246 417 minecraft:red_nether_bricks
fill 480 246 458 481 251 458 minecraft:netherrack
fill 481 246 457 483 246 457 minecraft:red_nether_bricks
fill 482 246 416 482 251 416 minecraft:netherrack
setblock 482 246 458 minecraft:orange_concrete
fill 483 246 417 485 246 417 minecraft:red_nether_bricks
fill 483 246 458 483 249 458 minecraft:netherrack
setblock 484 246 416 minecraft:orange_concrete
fill 484 246 443 484 247 443 minecraft:shroomlight
fill 485 246 416 486 251 416 minecraft:netherrack
fill 485 246 451 485 246 452 minecraft:red_nether_bricks
fill 485 246 457 487 246 457 minecraft:red_nether_bricks
fill 486 246 450 486 246 451 minecraft:red_nether_bricks
fill 487 246 416 487 247 416 minecraft:orange_concrete
fill 487 246 417 489 246 417 minecraft:red_nether_bricks
fill 489 246 454 489 248 454 minecraft:red_nether_bricks
fill 489 246 457 491 246 457 minecraft:red_nether_bricks
fill 490 246 450 490 250 450 minecraft:red_nether_bricks
fill 490 246 458 491 247 458 minecraft:orange_concrete
fill 491 246 417 493 246 417 minecraft:red_nether_bricks
fill 491 246 451 491 252 453 minecraft:red_nether_bricks
fill 492 246 458 493 251 458 minecraft:netherrack
fill 493 246 416 494 251 416 minecraft:netherrack
fill 493 246 457 495 246 457 minecraft:red_nether_bricks
fill 495 246 416 496 246 416 minecraft:orange_concrete
fill 495 246 417 497 246 417 minecraft:red_nether_bricks
fill 497 246 457 499 246 457 minecraft:red_nether_bricks
fill 499 246 417 501 246 417 minecraft:red_nether_bricks
fill 499 246 458 499 247 458 minecraft:orange_concrete
fill 500 246 458 501 251 458 minecraft:netherrack
fill 501 246 457 503 246 457 minecraft:red_nether_bricks
setblock 502 246 458 minecraft:orange_concrete
fill 503 246 417 505 246 417 minecraft:red_nether_bricks
fill 504 246 458 504 251 458 minecraft:netherrack
fill 505 246 416 506 251 416 minecraft:netherrack
fill 505 246 457 507 246 457 minecraft:red_nether_bricks
fill 507 246 416 508 247 416 minecraft:orange_concrete
fill 507 246 417 509 246 417 minecraft:red_nether_bricks
fill 509 246 457 511 246 457 minecraft:red_nether_bricks
fill 510 246 458 511 247 458 minecraft:orange_concrete
fill 511 246 417 511 246 419 minecraft:red_nether_bricks
fill 511 246 421 511 246 423 minecraft:red_nether_bricks
fill 511 246 425 511 246 427 minecraft:red_nether_bricks
fill 511 246 429 511 246 431 minecraft:red_nether_bricks
fill 511 246 433 511 246 435 minecraft:red_nether_bricks
fill 511 246 437 511 246 439 minecraft:red_nether_bricks
fill 511 246 441 511 246 443 minecraft:red_nether_bricks
fill 511 246 445 511 246 447 minecraft:red_nether_bricks
fill 511 246 449 511 246 451 minecraft:red_nether_bricks
fill 511 246 453 511 246 455 minecraft:red_nether_bricks
fill 512 246 418 512 251 418 minecraft:netherrack
fill 512 246 419 512 246 420 minecraft:orange_concrete
fill 512 246 421 512 251 421 minecraft:netherrack
fill 512 246 423 512 247 423 minecraft:orange_concrete
fill 512 246 429 512 251 430 minecraft:netherrack
fill 512 246 431 512 247 432 minecraft:orange_concrete
setblock 512 246 440 minecraft:orange_concrete
fill 512 246 441 512 251 442 minecraft:netherrack
fill 512 246 443 512 247 444 minecraft:orange_concrete
fill 512 246 449 512 251 450 minecraft:netherrack
fill 512 246 451 512 246 452 minecraft:orange_concrete
fill 512 246 453 512 251 453 minecraft:netherrack
fill 512 246 458 512 251 458 minecraft:netherrack
setblock 470 247 423 minecraft:orange_concrete
setblock 470 247 426 minecraft:orange_concrete
fill 470 247 427 470 250 427 minecraft:netherrack
setblock 470 247 434 minecraft:orange_concrete
fill 470 247 438 470 250 438 minecraft:netherrack
setblock 470 247 454 minecraft:orange_concrete
setblock 470 247 458 minecraft:orange_concrete
fill 471 247 458 471 250 458 minecraft:netherrack
fill 482 247 458 482 249 458 minecraft:netherrack
fill 484 247 416 484 250 416 minecraft:netherrack
setblock 486 247 451 minecraft:red_nether_bricks
setblock 487 247 458 minecraft:orange_concrete
setblock 488 247 416 minecraft:orange_concrete
setblock 488 247 454 minecraft:red_nether_bricks
fill 490 247 454 490 249 454 minecraft:red_nether_bricks
fill 491 247 450 491 251 450 minecraft:red_nether_bricks
fill 492 247 451 492 253 453 minecraft:red_nether_bricks
fill 495 247 416 495 250 416 minecraft:netherrack
setblock 496 247 416 minecraft:orange_concrete
setblock 498 247 458 minecraft:orange_concrete
setblock 499 247 416 minecraft:orange_concrete
fill 502 247 458 502 250 458 minecraft:netherrack
fill 512 247 419 512 250 420 minecraft:netherrack
setblock 512 247 424 minecraft:orange_concrete
setblock 512 247 435 minecraft:orange_concrete
fill 512 247 440 512 250 440 minecraft:netherrack
fill 512 247 451 512 250 451 minecraft:netherrack
setblock 512 247 452 minecraft:orange_concrete
fill 512 247 455 512 247 456 minecraft:orange_concrete
fill 470 248 421 470 249 421 minecraft:orange_concrete
fill 470 248 423 470 253 423 minecraft:netherrack
fill 470 248 424 470 248 425 minecraft:orange_concrete
fill 470 248 426 470 253 426 minecraft:netherrack
fill 470 248 432 470 249 433 minecraft:orange_concrete
fill 470 248 434 470 253 435 minecraft:netherrack
fill 470 248 444 470 248 445 minecraft:orange_concrete
fill 470 248 446 470 253 447 minecraft:netherrack
fill 470 248 452 470 249 453 minecraft:orange_concrete
fill 470 248 454 470 253 455 minecraft:netherrack
setblock 470 248 456 minecraft:orange_concrete
fill 470 248 458 470 250 458 minecraft:netherrack
setblock 473 248 419 minecraft:light[level=14]
setblock 473 248 427 minecraft:light[level=14]
setblock 473 248 435 minecraft:light[level=14]
setblock 473 248 443 minecraft:light[level=14]
setblock 473 248 451 minecraft:light[level=14]
fill 475 248 416 476 253 416 minecraft:netherrack
fill 476 248 458 477 249 458 minecraft:orange_concrete
fill 477 248 416 478 248 416 minecraft:orange_concrete
fill 478 248 458 479 253 458 minecraft:netherrack
setblock 481 248 419 minecraft:light[level=14]
setblock 481 248 427 minecraft:light[level=14]
setblock 481 248 435 minecraft:light[level=14]
setblock 481 248 443 minecraft:light[level=14]
setblock 481 248 451 minecraft:light[level=14]
setblock 484 248 458 minecraft:netherrack
fill 485 248 458 485 249 458 minecraft:orange_concrete
fill 487 248 416 488 253 416 minecraft:netherrack
setblock 487 248 451 minecraft:red_nether_bricks
fill 487 248 458 487 253 458 minecraft:netherrack
fill 488 248 458 489 248 458 minecraft:orange_concrete
fill 489 248 416 490 249 416 minecraft:orange_concrete
setblock 489 248 419 minecraft:light[level=14]
setblock 489 248 427 minecraft:light[level=14]
setblock 489 248 435 minecraft:light[level=14]
setblock 489 248 443 minecraft:light[level=14]
fill 490 248 458 491 250 458 minecraft:netherrack
fill 491 248 454 491 251 454 minecraft:red_nether_bricks
fill 492 248 450 492 252 450 minecraft:red_nether_bricks
fill 493 248 451 493 254 453 minecraft:red_nether_bricks
fill 496 248 416 496 253 416 minecraft:netherrack
fill 496 248 458 497 249 458 minecraft:orange_concrete
fill 497 248 416 498 248 416 minecraft:orange_concrete
setblock 497 248 419 minecraft:light[level=14]
setblock 497 248 427 minecraft:light[level=14]
setblock 497 248 435 minecraft:light[level=14]
setblock 497 248 443 minecraft:light[level=14]
setblock 497 248 451 minecraft:light[level=14]
fill 498 248 458 499 253 458 minecraft:netherrack
fill 499 248 416 499 253 416 minecraft:netherrack
fill 501 248 416 501 249 416 minecraft:orange_concrete
setblock 505 248 419 minecraft:light[level=14]
setblock 505 248 427 minecraft:light[level=14]
setblock 505 248 435 minecraft:light[level=14]
setblock 505 248 443 minecraft:light[level=14]
setblock 505 248 451 minecraft:light[level=14]
fill 507 248 416 508 253 416 minecraft:netherrack
fill 508 248 458 509 248 458 minecraft:orange_concrete
fill 509 248 416 510 249 416 minecraft:orange_concrete
fill 510 248 458 511 253 458 minecraft:netherrack
setblock 512 248 422 minecraft:orange_concrete
fill 512 248 423 512 253 424 minecraft:netherrack
fill 512 248 425 512 249 426 minecraft:orange_concrete
fill 512 248 431 512 253 432 minecraft:netherrack
fill 512 248 433 512 248 434 minecraft:orange_concrete
fill 512 248 435 512 253 435 minecraft:netherrack
fill 512 248 443 512 253 444 minecraft:netherrack
fill 512 248 445 512 249 446 minecraft:orange_concrete
fill 512 248 452 512 253 452 minecraft:netherrack
setblock 512 248 454 minecraft:orange_concrete
fill 512 248 455 512 253 456 minecraft:netherrack
fill 512 248 457 512 249 457 minecraft:orange_concrete
setblock 470 249 420 minecraft:orange_concrete
fill 470 249 424 470 252 425 minecraft:netherrack
setblock 470 249 441 minecraft:orange_concrete
setblock 470 249 444 minecraft:orange_concrete
fill 470 249 445 470 252 445 minecraft:netherrack
fill 470 249 456 470 252 456 minecraft:netherrack
fill 472 249 458 472 251 458 minecraft:netherrack
setblock 473 249 458 minecraft:orange_concrete
fill 477 249 416 477 252 416 minecraft:netherrack
setblock 478 249 416 minecraft:orange_concrete
setblock 481 249 416 minecraft:orange_concrete
setblock 484 249 458 minecraft:orange_concrete
setblock 488 249 453 minecraft:red_nether_bricks
setblock 488 249 458 minecraft:orange_concrete
fill 489 249 458 489 252 458 minecraft:netherrack
fill 492 249 454 492 252 454 minecraft:red_nether_bricks
fill 493 249 450 493 254 450 minecraft:red_nether_bricks
fill 494 249 451 494 255 453 minecraft:red_nether_bricks
fill 497 249 416 498 252 416 minecraft:netherrack
setblock 502 249 416 minecraft:orange_concrete
setblock 505 249 458 minecraft:orange_concrete
setblock 508 249 458 minecraft:orange_concrete
fill 509 249 458 509 252 458 minecraft:netherrack
setblock 512 249 417 minecraft:orange_concrete
fill 512 249 422 512 252 422 minecraft:netherrack
fill 512 249 433 512 252 433 minecraft:netherrack
setblock 512 249 434 minecraft:orange_concrete
fill 512 249 437 512 249 438 minecraft:orange_concrete
fill 512 249 454 512 252 454 minecraft:netherrack
fill 470 250 418 470 251 419 minecraft:orange_concrete
fill 470 250 420 470 255 421 minecraft:netherrack
setblock 470 250 422 minecraft:orange_concrete
fill 470 250 430 470 251 431 minecraft:orange_concrete
fill 470 250 432 470 255 433 minecraft:netherrack
fill 470 250 439 470 251 439 minecraft:orange_concrete
fill 470 250 441 470 255 441 minecraft:netherrack
fill 470 250 442 470 250 443 minecraft:orange_concrete
fill 470 250 444 470 255 444 minecraft:netherrack
fill 470 250 450 470 251 451 minecraft:orange_concrete
fill 470 250 452 470 255 453 minecraft:netherrack
fill 471 250 416 472 251 416 minecraft:orange_concrete
fill 473 250 458 473 251 458 minecraft:netherrack
fill 474 250 458 475 250 458 minecraft:orange_concrete
fill 476 250 458 477 255 458 minecraft:netherrack
fill 478 250 416 478 255 416 minecraft:netherrack
fill 479 250 416 480 250 416 minecraft:orange_concrete
fill 481 250 416 481 255 416 minecraft:netherrack
fill 482 250 458 483 251 458 minecraft:orange_concrete
fill 483 250 416 483 251 416 minecraft:orange_concrete
fill 484 250 458 485 255 458 minecraft:netherrack
setblock 486 250 458 minecraft:orange_concrete
fill 488 250 458 488 252 458 minecraft:netherrack
fill 489 250 416 490 255 416 minecraft:netherrack
fill 491 250 416 492 251 416 minecraft:orange_concrete
fill 493 250 454 493 253 454 minecraft:red_nether_bricks
fill 494 250 450 494 256 450 minecraft:red_nether_bricks
fill 494 250 458 495 251 458 minecraft:orange_concrete
fill 495 250 451 495 256 452 minecraft:red_nether_bricks
fill 496 250 458 497 255 458 minecraft:netherrack
setblock 500 250 416 minecraft:orange_concrete
fill 501 250 416 502 255 416 minecraft:netherrack
fill 503 250 416 504 251 416 minecraft:orange_concrete
fill 503 250 458 503 251 458 minecraft:orange_concrete
fill 505 250 458 505 255 458 minecraft:netherrack
fill 506 250 458 507 250 458 minecraft:orange_concrete
fill 508 250 458 508 255 458 minecraft:netherrack
fill 509 250 416 510 255 416 minecraft:netherrack
fill 511 250 416 512 250 416 minecraft:orange_concrete
fill 512 250 417 512 255 417 minecraft:netherrack
fill 512 250 425 512 255 426 minecraft:netherrack
fill 512 250 427 512 251 428 minecraft:orange_concrete
fill 512 250 434 512 255 434 minecraft:netherrack
setblock 512 250 436 minecraft:orange_concrete
fill 512 250 437 512 255 438 minecraft:netherrack
fill 512 250 439 512 251 439 minecraft:orange_concrete
fill 512 250 445 512 255 446 minecraft:netherrack
fill 512 250 447 512 250 448 minecraft:orange_concrete
fill 512 250 457 512 255 457 minecraft:netherrack
fill 470 251 422 470 254 422 minecraft:netherrack
setblock 470 251 427 minecraft:orange_concrete
setblock 470 251 438 minecraft:orange_concrete
fill 470 251 442 470 253 443 minecraft:netherrack
fill 470 251 458 471 251 458 minecraft:orange_concrete
setblock 474 251 458 minecraft:orange_concrete
fill 475 251 458 475 254 458 minecraft:netherrack
fill 479 251 416 480 254 416 minecraft:netherrack
setblock 484 251 416 minecraft:orange_concrete
fill 486 251 458 486 254 458 minecraft:netherrack
fill 490 251 458 490 253 458 minecraft:netherrack
setblock 491 251 458 minecraft:orange_concrete
fill 494 251 454 494 253 454 minecraft:red_nether_bricks
setblock 495 251 416 minecraft:orange_concrete
fill 495 251 450 495 257 450 minecraft:red_nether_bricks
fill 495 251 453 495 255 453 minecraft:red_nether_bricks
fill 496 251 451 496 257 452 minecraft:red_nether_bricks
fill 500 251 416 500 254 416 minecraft:netherrack
setblock 502 251 458 minecraft:orange_concrete
fill 506 251 458 507 254 458 minecraft:netherrack
fill 511 251 416 511 254 416 minecraft:netherrack
setblock 512 251 416 minecraft:orange_concrete
fill 512 251 419 512 251 420 minecraft:orange_concrete
fill 512 251 436 512 254 436 minecraft:netherrack
setblock 512 251 440 minecraft:orange_concrete
fill 512 251 447 512 254 447 minecraft:netherrack
setblock 512 251 448 minecraft:orange_concrete
setblock 512 251 451 minecraft:orange_concrete
fill 470 252 416 470 253 417 minecraft:orange_concrete
fill 470 252 418 470 257 419 minecraft:netherrack
fill 470 252 427 470 257 427 minecraft:netherrack
fill 470 252 428 470 252 429 minecraft:orange_concrete
fill 470 252 430 470 257 431 minecraft:netherrack
fill 470 252 436 470 253 437 minecraft:orange_concrete
fill 470 252 438 470 257 439 minecraft:netherrack
setblock 470 252 440 minecraft:orange_concrete
fill 470 252 448 470 253 449 minecraft:orange_concrete
fill 470 252 450 470 257 451 minecraft:netherrack
fill 470 252 457 470 253 457 minecraft:orange_concrete
fill 470 252 458 471 253 458 minecraft:netherrack
fill 471 252 416 472 257 416 minecraft:netherrack
fill 471 252 417 473 252 417 minecraft:red_nether_bricks
fill 471 252 419 471 252 421 minecraft:red_nether_bricks
fill 471 252 423 471 252 425 minecraft:red_nether_bricks
fill 471 252 427 471 252 429 minecraft:red_nether_bricks
fill 471 252 431 471 252 433 minecraft:red_nether_bricks
fill 471 252 435 471 252 437 minecraft:red_nether_bricks
fill 471 252 439 471 252 441 minecraft:red_nether_bricks
fill 471 252 443 471 252 445 minecraft:red_nether_bricks
fill 471 252 447 471 252 449 minecraft:red_nether_bricks
fill 471 252 451 471 252 453 minecraft:red_nether_bricks
fill 471 252 455 471 252 457 minecraft:red_nether_bricks
fill 472 252 458 473 252 458 minecraft:orange_concrete
fill 473 252 416 474 253 416 minecraft:orange_concrete
fill 473 252 457 475 252 457 minecraft:red_nether_bricks
fill 474 252 458 474 257 458 minecraft:netherrack
fill 475 252 417 477 252 417 minecraft:red_nether_bricks
fill 477 252 457 479 252 457 minecraft:red_nether_bricks
fill 479 252 417 481 252 417 minecraft:red_nether_bricks
fill 480 252 458 481 253 458 minecraft:orange_concrete
fill 481 252 457 483 252 457 minecraft:red_nether_bricks
setblock 482 252 416 minecraft:orange_concrete
fill 482 252 458 483 257 458 minecraft:netherrack
fill 483 252 416 484 257 416 minecraft:netherrack
fill 483 252 417 485 252 417 minecraft:red_nether_bricks
fill 485 252 416 486 253 416 minecraft:orange_concrete
fill 485 252 457 487 252 457 minecraft:red_nether_bricks
fill 487 252 417 489 252 417 minecraft:red_nether_bricks
fill 489 252 457 491 252 457 minecraft:red_nether_bricks
fill 491 252 416 492 257 416 minecraft:netherrack
fill 491 252 417 493 252 417 minecraft:red_nether_bricks
fill 491 252 458 491 257 458 minecraft:netherrack
fill 492 252 458 493 252 458 minecraft:orange_concrete
fill 493 252 416 494 252 416 minecraft:orange_concrete
fill 493 252 457 495 252 457 minecraft:red_nether_bricks
fill 494 252 458 495 257 458 minecraft:netherrack
fill 495 252 416 495 257 416 minecraft:netherrack
fill 495 252 417 497 252 417 minecraft:red_nether_bricks
fill 496 252 450 496 258 450 minecraft:red_nether_bricks
fill 496 252 453 496 256 453 minecraft:red_nether_bricks
fill 497 252 451 497 259 451 minecraft:red_nether_bricks
fill 497 252 457 499 252 457 minecraft:red_nether_bricks
fill 499 252 417 501 252 417 minecraft:red_nether_bricks
fill 500 252 458 501 253 458 minecraft:orange_concrete
fill 501 252 457 503 252 457 minecraft:red_nether_bricks
fill 502 252 458 503 257 458 minecraft:netherrack
fill 503 252 416 504 257 416 minecraft:netherrack
fill 503 252 417 505 252 417 minecraft:red_nether_bricks
setblock 504 252 458 minecraft:orange_concrete
fill 505 252 416 506 253 416 minecraft:orange_concrete
fill 505 252 457 507 252 457 minecraft:red_nether_bricks
fill 507 252 417 509 252 417 minecraft:red_nether_bricks
fill 509 252 457 511 252 457 minecraft:red_nether_bricks
fill 511 252 417 511 252 419 minecraft:red_nether_bricks
fill 511 252 421 511 252 423 minecraft:red_nether_bricks
fill 511 252 425 511 252 427 minecraft:red_nether_bricks
fill 511 252 429 511 252 431 minecraft:red_nether_bricks
fill 511 252 433 511 252 435 minecraft:red_nether_bricks
fill 511 252 437 511 252 439 minecraft:red_nether_bricks
fill 511 252 441 511 252 443 minecraft:red_nether_bricks
fill 511 252 445 511 252 447 minecraft:red_nether_bricks
fill 511 252 449 511 252 451 minecraft:red_nether_bricks
fill 511 252 453 511 252 455 minecraft:red_nether_bricks
fill 512 252 416 512 257 416 minecraft:netherrack
setblock 512 252 418 minecraft:orange_concrete
fill 512 252 419 512 257 420 minecraft:netherrack
fill 512 252 421 512 253 421 minecraft:orange_concrete
fill 512 252 427 512 257 428 minecraft:netherrack
fill 512 252 429 512 252 430 minecraft:orange_concrete
fill 512 252 439 512 257 440 minecraft:netherrack
fill 512 252 441 512 253 442 minecraft:orange_concrete
fill 512 252 448 512 257 448 minecraft:netherrack
fill 512 252 449 512 252 450 minecraft:orange_concrete
fill 512 252 451 512 257 451 minecraft:netherrack
fill 512 252 453 512 253 453 minecraft:orange_concrete
fill 512 252 458 512 253 458 minecraft:orange_concrete
fill 470 253 424 470 253 425 minecraft:orange_concrete
setblock 470 253 428 minecraft:orange_concrete
fill 470 253 429 470 256 429 minecraft:netherrack
fill 470 253 440 470 255 440 minecraft:netherrack
setblock 470 253 445 minecraft:orange_concrete
setblock 470 253 456 minecraft:orange_concrete
fill 472 253 458 473 255 458 minecraft:netherrack
setblock 477 253 416 minecraft:orange_concrete
fill 482 253 416 482 256 416 minecraft:netherrack
fill 488 253 458 489 253 458 minecraft:orange_concrete
setblock 492 253 458 minecraft:orange_concrete
fill 493 253 416 493 256 416 minecraft:netherrack
fill 493 253 458 493 256 458 minecraft:netherrack
setblock 494 253 416 minecraft:orange_concrete
fill 494 253 449 496 254 449 minecraft:red_nether_bricks
fill 497 253 416 498 253 416 minecraft:orange_concrete
fill 497 253 450 497 259 450 minecraft:red_nether_bricks
fill 497 253 452 497 258 452 minecraft:red_nether_bricks
fill 504 253 458 504 256 458 minecraft:netherrack
setblock 509 253 458 minecraft:orange_concrete
fill 512 253 418 512 256 418 minecraft:netherrack
setblock 512 253 422 minecraft:orange_concrete
fill 512 253 429 512 256 429 minecraft:netherrack
setblock 512 253 430 minecraft:orange_concrete
setblock 512 253 433 minecraft:orange_concrete
fill 512 253 449 512 256 450 minecraft:netherrack
setblock 512 253 454 minecraft:orange_concrete
fill 470 254 416 470 259 417 minecraft:netherrack
fill 470 254 423 470 255 423 minecraft:orange_concrete
fill 470 254 424 470 259 425 minecraft:netherrack
setblock 470 254 426 minecraft:orange_concrete
fill 470 254 428 470 259 428 minecraft:netherrack
fill 470 254 434 470 255 435 minecraft:orange_concrete
fill 470 254 436 470 259 437 minecraft:netherrack
setblock 470 254 442 minecraft:netherrack
fill 470 254 443 470 255 443 minecraft:orange_concrete
fill 470 254 445 470 259 445 minecraft:netherrack
fill 470 254 446 470 254 447 minecraft:orange_concrete
fill 470 254 448 470 256 449 minecraft:netherrack
fill 470 254 454 470 255 455 minecraft:orange_concrete
fill 470 254 456 470 259 457 minecraft:netherrack
setblock 470 254 458 minecraft:orange_concrete
fill 471 254 458 471 257 458 minecraft:netherrack
fill 473 254 416 474 259 416 minecraft:netherrack
fill 473 254 431 473 255 431 minecraft:magma_block
fill 475 254 416 476 254 416 minecraft:orange_concrete
fill 477 254 416 477 259 416 minecraft:netherrack
fill 478 254 458 479 255 458 minecraft:orange_concrete
fill 480 254 458 481 259 458 minecraft:netherrack
fill 485 254 416 486 259 416 minecraft:netherrack
fill 487 254 416 488 255 416 minecraft:orange_concrete
fill 487 254 458 487 255 458 minecraft:orange_concrete
fill 488 254 458 489 259 458 minecraft:netherrack
setblock 490 254 458 minecraft:orange_concrete
fill 492 254 458 492 259 458 minecraft:netherrack
fill 494 254 416 494 259 416 minecraft:netherrack
setblock 496 254 416 minecraft:orange_concrete
fill 497 254 416 498 259 416 minecraft:netherrack
fill 497 254 449 498 259 449 minecraft:red_nether_bricks
fill 497 254 453 497 256 453 minecraft:red_nether_bricks
fill 498 254 450 498 259 452 minecraft:red_nether_bricks
fill 498 254 458 499 255 458 minecraft:orange_concrete
fill 499 254 416 499 255 416 minecraft:orange_concrete
fill 500 254 458 501 259 458 minecraft:netherrack
fill 505 254 416 506 259 416 minecraft:netherrack
fill 507 254 416 508 254 416 minecraft:orange_concrete
fill 509 254 458 509 259 458 minecraft:netherrack
fill 510 254 458 511 254 458 minecraft:orange_concrete
fill 512 254 421 512 259 422 minecraft:netherrack
fill 512 254 423 512 255 424 minecraft:orange_concrete
fill 512 254 430 512 259 430 minecraft:netherrack
fill 512 254 431 512 254 432 minecraft:orange_concrete
fill 512 254 433 512 259 433 minecraft:netherrack
fill 512 254 435 512 255 435 minecraft:orange_concrete
fill 512 254 441 512 259 442 minecraft:netherrack
fill 512 254 443 512 255 444 minecraft:orange_concrete
setblock 512 254 452 minecraft:orange_concrete
fill 512 254 453 512 259 454 minecraft:netherrack
fill 512 254 455 512 255 456 minecraft:orange_concrete
fill 512 254 458 512 259 458 minecraft:netherrack
setblock 470 255 422 minecraft:orange_concrete
fill 470 255 426 470 258 426 minecraft:netherrack
setblock 470 255 442 minecraft:orange_concrete
setblock 470 255 446 minecraft:orange_concrete
fill 470 255 447 470 258 447 minecraft:netherrack
fill 470 255 458 470 257 458 minecraft:netherrack
fill 475 255 416 475 258 416 minecraft:netherrack
setblock 475 255 458 minecraft:orange_concrete
setblock 476 255 416 minecraft:orange_concrete
fill 479 255 416 480 255 416 minecraft:orange_concrete
setblock 486 255 458 minecraft:orange_concrete
fill 490 255 458 490 258 458 minecraft:netherrack
fill 493 255 451 493 255 452 minecraft:red_nether_bricks
fill 495 255 449 496 256 449 minecraft:red_nether_bricks
fill 496 255 416 496 258 416 minecraft:netherrack
fill 499 255 449 499 259 452 minecraft:red_nether_bricks
setblock 500 255 416 minecraft:orange_concrete
fill 506 255 458 507 255 458 minecraft:orange_concrete
fill 507 255 416 507 258 416 minecraft:netherrack
setblock 508 255 416 minecraft:orange_concrete
setblock 510 255 458 minecraft:orange_concrete
setblock 511 255 416 minecraft:orange_concrete
fill 511 255 458 511 258 458 minecraft:netherrack
fill 512 255 431 512 258 432 minecraft:netherrack
setblock 512 255 436 minecraft:orange_concrete
setblock 512 255 447 minecraft:orange_concrete
fill 512 255 452 512 258 452 minecraft:netherrack
fill 470 256 420 470 257 421 minecraft:orange_concrete
fill 470 256 422 470 261 423 minecraft:netherrack
fill 470 256 432 470 256 433 minecraft:orange_concrete
fill 470 256 434 470 261 435 minecraft:netherrack
fill 470 256 440 470 257 441 minecraft:orange_concrete
fill 470 256 442 470 261 443 minecraft:netherrack
setblock 470 256 444 minecraft:orange_concrete
fill 470 256 446 470 258 446 minecraft:netherrack
fill 470 256 452 470 257 453 minecraft:orange_concrete
fill 470 256 454 470 261 455 minecraft:netherrack
setblock 472 256 458 minecraft:netherrack
setblock 473 256 419 minecraft:light[level=14]
setblock 473 256 427 minecraft:light[level=14]
setblock 473 256 435 minecraft:light[level=14]
setblock 473 256 443 minecraft:light[level=14]
setblock 473 256 451 minecraft:light[level=14]
fill 473 256 458 473 257 458 minecraft:orange_concrete
fill 475 256 458 475 261 458 minecraft:netherrack
fill 476 256 416 476 261 416 minecraft:netherrack
fill 476 256 458 477 256 458 minecraft:orange_concrete
setblock 478 256 416 minecraft:orange_concrete
fill 478 256 434 478 257 434 minecraft:magma_block
fill 478 256 458 479 258 458 minecraft:netherrack
fill 479 256 416 480 261 416 minecraft:netherrack
fill 481 256 416 481 257 416 minecraft:orange_concrete
setblock 481 256 419 minecraft:light[level=14]
setblock 481 256 427 minecraft:light[level=14]
setblock 481 256 435 minecraft:light[level=14]
setblock 481 256 443 minecraft:light[level=14]
setblock 481 256 451 minecraft:light[level=14]
fill 484 256 458 485 257 458 minecraft:orange_concrete
fill 486 256 458 487 261 458 minecraft:netherrack
fill 487 256 416 488 261 416 minecraft:netherrack
fill 489 256 416 490 256 416 minecraft:orange_concrete
setblock 489 256 419 minecraft:light[level=14]
setblock 489 256 427 minecraft:light[level=14]
setblock 489 256 435 minecraft:light[level=14]
setblock 489 256 443 minecraft:light[level=14]
setblock 489 256 451 minecraft:light[level=14]
fill 493 256 452 493 258 452 minecraft:magma_block
fill 494 256 451 494 256 452 minecraft:red_nether_bricks
fill 496 256 458 497 256 458 minecraft:orange_concrete
setblock 497 256 419 minecraft:light[level=14]
setblock 497 256 427 minecraft:light[level=14]
setblock 497 256 435 minecraft:light[level=14]
setblock 497 256 443 minecraft:light[level=14]
fill 497 256 448 499 258 448 minecraft:red_nether_bricks
fill 498 256 458 499 261 458 minecraft:netherrack
fill 499 256 416 500 261 416 minecraft:netherrack
fill 500 256 449 500 260 451 minecraft:red_nether_bricks
fill 501 256 416 502 257 416 minecraft:orange_concrete
setblock 505 256 419 minecraft:light[level=14]
schedule function dropper:buildpart/106_6 1t
