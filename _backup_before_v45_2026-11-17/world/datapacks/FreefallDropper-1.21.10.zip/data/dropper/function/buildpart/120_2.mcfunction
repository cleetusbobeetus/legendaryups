setblock 0 258 544 minecraft:black_concrete
setblock 0 258 545 minecraft:white_concrete
fill 8 258 529 15 258 529 minecraft:black_wool
fill 8 258 533 15 258 533 minecraft:black_wool
fill 9 258 527 15 259 528 minecraft:black_wool
fill 9 258 534 15 259 535 minecraft:black_wool
fill 10 258 525 32 259 525 minecraft:black_wool
fill 10 258 537 32 259 537 minecraft:black_wool
fill 11 258 523 31 258 523 minecraft:black_wool
fill 11 258 539 31 258 539 minecraft:black_wool
fill 12 258 522 30 259 522 minecraft:black_wool
fill 12 258 540 30 259 540 minecraft:black_wool
fill 13 258 521 29 258 521 minecraft:black_wool
fill 13 258 541 29 258 541 minecraft:black_wool
fill 14 258 520 28 258 520 minecraft:black_wool
fill 14 258 542 28 258 542 minecraft:black_wool
setblock 14 258 552 minecraft:white_concrete
fill 16 258 519 26 258 519 minecraft:black_wool
fill 16 258 543 26 258 543 minecraft:black_wool
fill 19 258 518 23 258 518 minecraft:black_wool
fill 19 258 527 19 272 529 minecraft:black_wool
fill 19 258 544 23 258 544 minecraft:black_wool
fill 19 258 552 19 284 552 minecraft:black_concrete
fill 20 258 527 33 259 528 minecraft:black_wool
fill 22 258 535 33 259 535 minecraft:black_wool
fill 22 258 552 24 291 552 minecraft:black_concrete
setblock 23 258 510 minecraft:sea_lantern
fill 23 258 530 33 258 534 minecraft:black_wool
setblock 25 258 552 minecraft:white_concrete
fill 26 258 552 26 307 552 minecraft:black_concrete
fill 34 258 530 34 258 533 minecraft:black_wool
setblock 34 258 552 minecraft:sea_lantern
fill 41 258 510 41 269 510 minecraft:black_concrete
fill 42 258 546 42 281 546 minecraft:black_concrete
fill 42 258 551 42 270 551 minecraft:black_concrete
setblock 0 259 544 minecraft:sea_lantern
fill 0 259 545 0 307 545 minecraft:black_concrete
setblock 3 259 513 minecraft:light[level=11]
setblock 3 259 521 minecraft:light[level=11]
setblock 3 259 529 minecraft:light[level=11]
setblock 3 259 537 minecraft:light[level=11]
setblock 3 259 545 minecraft:light[level=11]
fill 9 259 529 15 260 533 minecraft:black_wool
fill 10 259 526 32 260 526 minecraft:black_wool
fill 10 259 536 32 260 536 minecraft:black_wool
setblock 11 259 513 minecraft:light[level=11]
setblock 11 259 521 minecraft:light[level=11]
fill 11 259 524 31 260 524 minecraft:black_wool
fill 11 259 538 31 260 538 minecraft:black_wool
setblock 11 259 545 minecraft:light[level=11]
fill 12 259 523 30 260 523 minecraft:black_wool
fill 12 259 539 30 260 539 minecraft:black_wool
fill 14 259 521 28 260 521 minecraft:black_wool
fill 14 259 541 28 260 541 minecraft:black_wool
fill 14 259 552 14 260 552 minecraft:black_concrete
fill 15 259 520 27 259 520 minecraft:black_wool
fill 15 259 542 27 259 542 minecraft:black_wool
setblock 17 259 510 minecraft:white_concrete
fill 17 259 519 25 259 519 minecraft:black_wool
fill 17 259 543 25 259 543 minecraft:black_wool
setblock 19 259 513 minecraft:light[level=11]
setblock 19 259 545 minecraft:light[level=11]
fill 20 259 529 33 260 529 minecraft:black_wool
setblock 21 259 510 minecraft:light_blue_stained_glass
fill 23 259 510 23 307 510 minecraft:black_concrete
fill 23 259 530 33 260 531 minecraft:black_wool
fill 23 259 533 33 259 534 minecraft:black_wool
fill 24 259 532 33 260 532 minecraft:black_wool
fill 25 259 552 25 261 552 minecraft:black_concrete
setblock 27 259 513 minecraft:light[level=11]
setblock 27 259 545 minecraft:light[level=11]
fill 34 259 552 34 287 552 minecraft:black_concrete
setblock 35 259 513 minecraft:light[level=11]
setblock 35 259 521 minecraft:light[level=11]
setblock 35 259 529 minecraft:light[level=11]
setblock 35 259 537 minecraft:light[level=11]
setblock 35 259 545 minecraft:light[level=11]
fill 0 260 510 0 307 510 minecraft:black_concrete
setblock 0 260 511 minecraft:white_concrete
fill 0 260 544 0 307 544 minecraft:black_concrete
fill 10 260 527 15 261 528 minecraft:black_wool
fill 10 260 534 15 261 535 minecraft:black_wool
fill 11 260 525 31 261 525 minecraft:black_wool
fill 11 260 537 31 261 537 minecraft:black_wool
fill 13 260 522 29 260 522 minecraft:black_wool
fill 13 260 540 29 260 540 minecraft:black_wool
fill 16 260 520 26 260 520 minecraft:black_wool
fill 16 260 542 26 260 542 minecraft:black_wool
fill 17 260 510 17 307 510 minecraft:black_concrete
setblock 17 260 552 minecraft:sea_lantern
fill 18 260 552 18 307 552 minecraft:black_concrete
fill 19 260 519 23 260 519 minecraft:black_wool
fill 19 260 543 23 260 543 minecraft:black_wool
fill 20 260 527 32 261 528 minecraft:black_wool
fill 21 260 510 21 289 510 minecraft:black_concrete
fill 22 260 535 32 261 535 minecraft:black_wool
fill 23 260 534 32 261 534 minecraft:black_wool
fill 24 260 533 33 260 533 minecraft:black_wool
fill 0 261 511 0 307 511 minecraft:black_concrete
setblock 0 261 513 minecraft:light_blue_stained_glass
fill 0 261 518 0 263 518 minecraft:cyan_concrete
fill 0 261 534 0 263 534 minecraft:cyan_concrete
setblock 0 261 535 minecraft:sea_lantern
fill 0 261 550 0 263 550 minecraft:cyan_concrete
setblock 1 261 510 minecraft:white_concrete
fill 4 261 510 4 263 510 minecraft:cyan_concrete
fill 10 261 529 15 262 533 minecraft:black_wool
fill 11 261 526 31 262 526 minecraft:black_wool
fill 11 261 536 31 262 536 minecraft:black_wool
fill 12 261 524 30 261 524 minecraft:black_wool
fill 12 261 538 30 261 538 minecraft:black_wool
fill 13 261 523 29 262 523 minecraft:black_wool
fill 13 261 539 29 262 539 minecraft:black_wool
fill 14 261 522 28 261 522 minecraft:black_wool
fill 14 261 540 28 261 540 minecraft:black_wool
fill 14 261 552 14 263 552 minecraft:cyan_concrete
fill 15 261 521 27 261 521 minecraft:black_wool
fill 15 261 541 27 261 541 minecraft:black_wool
fill 17 261 520 25 261 520 minecraft:black_wool
fill 17 261 542 25 261 542 minecraft:black_wool
fill 17 261 552 17 299 552 minecraft:black_concrete
fill 20 261 510 20 263 510 minecraft:cyan_concrete
fill 20 261 529 32 262 529 minecraft:black_wool
fill 22 261 530 32 262 530 minecraft:black_wool
fill 23 261 531 32 262 531 minecraft:black_wool
fill 24 261 532 32 262 533 minecraft:black_wool
fill 30 261 552 30 263 552 minecraft:cyan_concrete
fill 36 261 510 36 263 510 minecraft:cyan_concrete
fill 42 261 520 42 263 520 minecraft:cyan_concrete
fill 42 261 536 42 263 536 minecraft:cyan_concrete
setblock 42 261 538 minecraft:white_concrete
fill 42 261 539 42 269 539 minecraft:black_concrete
fill 0 262 513 0 307 513 minecraft:black_concrete
setblock 0 262 520 minecraft:light_blue_stained_glass
fill 0 262 535 0 307 535 minecraft:black_concrete
setblock 0 262 539 minecraft:white_concrete
setblock 1 262 510 minecraft:sea_lantern
fill 11 262 527 15 263 528 minecraft:black_wool
fill 11 262 534 15 263 535 minecraft:black_wool
fill 12 262 525 30 263 525 minecraft:black_wool
fill 12 262 537 30 263 537 minecraft:black_wool
fill 13 262 524 29 263 524 minecraft:black_wool
fill 13 262 538 29 263 538 minecraft:black_wool
fill 15 262 522 27 263 522 minecraft:black_wool
fill 15 262 540 27 263 540 minecraft:black_wool
fill 16 262 521 26 262 521 minecraft:black_wool
fill 16 262 541 26 262 541 minecraft:black_wool
fill 19 262 520 23 262 520 minecraft:black_wool
fill 19 262 542 23 262 542 minecraft:black_wool
fill 20 262 527 31 263 528 minecraft:black_wool
setblock 21 262 552 minecraft:light_blue_stained_glass
fill 23 262 534 31 263 535 minecraft:black_wool
setblock 25 262 552 minecraft:sea_lantern
fill 28 262 514 28 263 515 minecraft:cyan_stained_glass
setblock 31 262 510 minecraft:sea_lantern
setblock 33 262 510 minecraft:sea_lantern
setblock 40 262 510 minecraft:light_blue_stained_glass
setblock 41 262 552 minecraft:sea_lantern
fill 42 262 538 42 270 538 minecraft:black_concrete
fill 0 263 520 0 266 520 minecraft:black_concrete
fill 0 263 526 0 307 526 minecraft:black_concrete
setblock 0 263 527 minecraft:white_concrete
fill 0 263 528 0 307 529 minecraft:black_concrete
fill 0 263 539 0 286 539 minecraft:black_concrete
fill 1 263 510 1 307 510 minecraft:black_concrete
fill 11 263 529 15 264 533 minecraft:black_wool
fill 12 263 526 30 264 526 minecraft:black_wool
fill 12 263 536 30 263 536 minecraft:black_wool
fill 14 263 523 28 263 523 minecraft:black_wool
fill 14 263 539 28 263 539 minecraft:black_wool
fill 17 263 521 25 263 521 minecraft:black_wool
fill 17 263 541 25 263 541 minecraft:black_wool
fill 20 263 529 31 264 529 minecraft:black_wool
fill 21 263 552 21 307 552 minecraft:black_concrete
fill 22 263 530 31 265 530 minecraft:black_wool
fill 23 263 531 31 265 531 minecraft:black_wool
fill 24 263 532 31 264 533 minecraft:black_wool
fill 25 263 552 25 270 552 minecraft:black_concrete
fill 31 263 510 31 307 510 minecraft:black_concrete
fill 33 263 510 33 270 510 minecraft:black_concrete
setblock 36 263 552 minecraft:sea_lantern
setblock 40 263 510 minecraft:white_concrete
fill 41 263 552 41 307 552 minecraft:black_concrete
fill 0 264 518 0 269 518 minecraft:black_concrete
fill 0 264 527 0 283 527 minecraft:black_concrete
fill 0 264 534 0 269 534 minecraft:black_concrete
setblock 0 264 540 minecraft:sea_lantern
fill 0 264 550 0 269 550 minecraft:black_concrete
fill 4 264 510 4 268 510 minecraft:black_concrete
fill 11 264 528 15 264 528 minecraft:black_wool
fill 11 264 534 15 264 534 minecraft:black_wool
fill 12 264 527 15 265 527 minecraft:black_wool
fill 12 264 535 15 264 536 minecraft:black_wool
fill 13 264 525 29 265 525 minecraft:black_wool
fill 13 264 537 29 265 537 minecraft:black_wool
fill 14 264 524 28 265 524 minecraft:black_wool
fill 14 264 538 28 265 538 minecraft:black_wool
fill 14 264 552 14 269 552 minecraft:black_concrete
fill 15 264 523 27 265 523 minecraft:black_wool
fill 15 264 539 27 265 539 minecraft:black_wool
fill 16 264 522 26 264 522 minecraft:black_wool
fill 16 264 536 19 265 536 minecraft:black_wool
fill 16 264 540 26 264 540 minecraft:black_wool
fill 18 264 510 18 272 510 minecraft:black_concrete
fill 18 264 521 24 264 521 minecraft:black_wool
fill 18 264 541 24 264 541 minecraft:black_wool
setblock 19 264 510 minecraft:light_blue_stained_glass
fill 20 264 510 20 269 510 minecraft:black_concrete
fill 20 264 527 30 265 528 minecraft:black_wool
fill 21 264 536 30 264 536 minecraft:black_wool
fill 23 264 534 30 265 535 minecraft:black_wool
fill 30 264 552 30 269 552 minecraft:black_concrete
setblock 31 264 528 minecraft:black_wool
setblock 31 264 534 minecraft:black_wool
fill 36 264 510 36 266 510 minecraft:black_concrete
fill 36 264 552 36 290 552 minecraft:black_concrete
fill 40 264 510 40 305 510 minecraft:black_concrete
fill 42 264 520 42 269 520 minecraft:black_concrete
fill 42 264 536 42 269 536 minecraft:black_concrete
setblock 0 265 521 minecraft:white_concrete
fill 0 265 540 0 303 540 minecraft:black_concrete
setblock 5 265 510 minecraft:light_blue_stained_glass
fill 11 265 530 15 265 532 minecraft:black_wool
fill 12 265 528 15 266 529 minecraft:black_wool
fill 12 265 533 15 265 535 minecraft:black_wool
fill 13 265 526 29 266 526 minecraft:black_wool
fill 13 265 536 15 266 536 minecraft:black_wool
fill 17 265 522 25 265 522 minecraft:black_wool
fill 17 265 540 25 265 540 minecraft:black_wool
fill 19 265 510 19 287 510 minecraft:black_concrete
fill 20 265 521 22 265 521 minecraft:black_wool
fill 20 265 529 30 266 529 minecraft:black_wool
fill 20 265 541 22 265 541 minecraft:black_wool
fill 21 265 536 29 266 536 minecraft:black_wool
fill 24 265 532 30 266 533 minecraft:black_wool
setblock 31 265 532 minecraft:black_wool
setblock 42 265 547 minecraft:light_blue_stained_glass
fill 0 266 521 0 299 521 minecraft:black_concrete
setblock 0 266 530 minecraft:light_blue_stained_glass
setblock 0 266 548 minecraft:sea_lantern
fill 5 266 510 5 307 510 minecraft:black_concrete
fill 11 266 524 11 267 524 minecraft:light_blue_stained_glass
fill 12 266 530 15 266 534 minecraft:black_wool
fill 13 266 527 15 267 527 minecraft:black_wool
fill 13 266 535 15 267 535 minecraft:black_wool
fill 14 266 525 28 266 525 minecraft:black_wool
fill 14 266 537 28 266 537 minecraft:black_wool
fill 15 266 524 27 266 524 minecraft:black_wool
fill 15 266 538 27 266 538 minecraft:black_wool
fill 16 266 523 26 266 523 minecraft:black_wool
fill 16 266 536 18 271 536 minecraft:black_wool
fill 16 266 539 26 266 539 minecraft:black_wool
fill 18 266 522 24 266 522 minecraft:black_wool
fill 18 266 540 24 266 540 minecraft:black_wool
fill 20 266 527 29 267 528 minecraft:black_wool
fill 22 266 530 30 267 530 minecraft:black_wool
fill 23 266 531 30 267 531 minecraft:black_wool
fill 23 266 534 29 267 535 minecraft:black_wool
fill 30 266 527 31 267 527 minecraft:light_blue_stained_glass
setblock 30 266 528 minecraft:black_wool
setblock 30 266 534 minecraft:black_wool
fill 42 266 547 42 267 547 minecraft:black_concrete
setblock 0 267 520 minecraft:light_blue_stained_glass
fill 0 267 530 0 307 530 minecraft:black_concrete
fill 0 267 548 0 272 548 minecraft:black_concrete
setblock 3 267 513 minecraft:light[level=11]
setblock 3 267 521 minecraft:light[level=11]
setblock 3 267 529 minecraft:light[level=11]
setblock 3 267 537 minecraft:light[level=11]
setblock 3 267 545 minecraft:light[level=11]
setblock 10 267 552 minecraft:sea_lantern
setblock 11 267 513 minecraft:light[level=11]
setblock 11 267 521 minecraft:light[level=11]
setblock 11 267 529 minecraft:light[level=11]
setblock 11 267 537 minecraft:light[level=11]
setblock 11 267 545 minecraft:light[level=11]
fill 12 267 530 15 267 532 minecraft:black_wool
fill 13 267 528 15 268 529 minecraft:black_wool
fill 13 267 533 15 268 534 minecraft:black_wool
fill 14 267 526 28 268 526 minecraft:black_wool
fill 14 267 536 15 268 536 minecraft:black_wool
fill 15 267 525 27 268 525 minecraft:black_wool
fill 15 267 537 27 268 537 minecraft:black_wool
fill 16 267 524 26 268 524 minecraft:black_wool
fill 16 267 538 26 268 538 minecraft:black_wool
fill 17 267 523 25 267 523 minecraft:black_wool
fill 17 267 539 25 267 539 minecraft:black_wool
setblock 19 267 513 minecraft:light[level=11]
setblock 19 267 521 minecraft:light[level=11]
setblock 19 267 545 minecraft:light[level=11]
fill 20 267 522 22 267 522 minecraft:black_wool
fill 20 267 529 29 269 529 minecraft:black_wool
fill 20 267 540 22 267 540 minecraft:black_wool
fill 21 267 536 28 268 536 minecraft:black_wool
setblock 22 267 510 minecraft:sea_lantern
fill 24 267 532 29 269 533 minecraft:black_wool
setblock 27 267 513 minecraft:light[level=11]
setblock 27 267 521 minecraft:light[level=11]
setblock 27 267 545 minecraft:light[level=11]
setblock 30 267 532 minecraft:black_wool
setblock 35 267 513 minecraft:light[level=11]
setblock 35 267 521 minecraft:light[level=11]
setblock 35 267 529 minecraft:light[level=11]
setblock 35 267 537 minecraft:light[level=11]
setblock 35 267 545 minecraft:light[level=11]
setblock 36 267 510 minecraft:white_concrete
setblock 42 267 511 minecraft:sea_lantern
setblock 42 267 521 minecraft:sea_lantern
setblock 42 267 524 minecraft:white_concrete
setblock 42 267 540 minecraft:white_concrete
fill 0 268 520 0 272 520 minecraft:black_concrete
fill 10 268 552 10 307 552 minecraft:black_concrete
fill 13 268 530 15 269 532 minecraft:black_wool
fill 14 268 527 15 269 527 minecraft:black_wool
fill 14 268 535 15 269 535 minecraft:black_wool
fill 18 268 523 24 268 523 minecraft:black_wool
fill 18 268 539 24 268 539 minecraft:black_wool
fill 20 268 527 28 269 528 minecraft:black_wool
fill 22 268 510 22 307 510 minecraft:black_concrete
fill 22 268 530 29 269 530 minecraft:black_wool
fill 23 268 531 29 269 531 minecraft:black_wool
fill 23 268 535 28 269 535 minecraft:black_wool
fill 24 268 534 29 268 534 minecraft:black_wool
setblock 29 268 528 minecraft:black_wool
fill 36 268 510 36 269 510 minecraft:black_concrete
fill 42 268 511 42 270 511 minecraft:black_concrete
setblock 42 268 513 minecraft:white_concrete
fill 42 268 521 42 297 521 minecraft:black_concrete
fill 42 268 524 42 307 524 minecraft:black_concrete
fill 42 268 540 42 307 540 minecraft:black_concrete
setblock 42 268 547 minecraft:white_concrete
setblock 0 269 538 minecraft:light_blue_stained_glass
setblock 4 269 510 minecraft:light_blue_stained_glass
fill 13 269 529 15 269 529 minecraft:black_wool
fill 13 269 533 15 269 533 minecraft:black_wool
fill 14 269 528 15 270 528 minecraft:black_wool
fill 14 269 534 15 270 534 minecraft:black_wool
fill 15 269 526 27 269 526 minecraft:black_wool
setblock 15 269 536 minecraft:black_wool
fill 16 269 525 26 269 525 minecraft:black_wool
fill 16 269 537 26 269 537 minecraft:black_wool
fill 17 269 524 25 269 524 minecraft:black_wool
fill 17 269 538 25 269 538 minecraft:black_wool
fill 19 269 523 23 269 523 minecraft:black_wool
fill 19 269 539 23 269 539 minecraft:black_wool
fill 22 269 536 27 269 536 minecraft:black_wool
fill 24 269 534 28 270 534 minecraft:black_wool
setblock 40 269 552 minecraft:white_concrete
fill 42 269 513 42 271 513 minecraft:black_concrete
fill 42 269 547 42 272 547 minecraft:black_concrete
fill 0 270 518 0 272 518 minecraft:cyan_concrete
fill 0 270 534 0 272 534 minecraft:cyan_concrete
fill 0 270 536 0 307 536 minecraft:black_concrete
setblock 0 270 537 minecraft:white_concrete
fill 0 270 538 0 298 538 minecraft:black_concrete
fill 0 270 550 0 272 550 minecraft:cyan_concrete
setblock 3 270 552 minecraft:light_blue_stained_glass
fill 4 270 510 4 272 510 minecraft:cyan_concrete
fill 4 270 552 4 278 552 minecraft:black_concrete
fill 5 270 532 5 271 533 minecraft:light_blue_stained_glass
fill 14 270 529 15 271 533 minecraft:black_wool
fill 14 270 552 14 272 552 minecraft:cyan_concrete
fill 15 270 527 15 271 527 minecraft:black_wool
fill 15 270 535 15 271 535 minecraft:black_wool
fill 16 270 526 26 271 526 minecraft:black_wool
fill 17 270 525 25 271 525 minecraft:black_wool
fill 17 270 531 17 272 531 minecraft:black_wool
fill 17 270 537 25 271 537 minecraft:black_wool
fill 18 270 524 24 270 524 minecraft:black_wool
fill 18 270 530 18 272 530 minecraft:black_wool
fill 18 270 538 24 270 538 minecraft:black_wool
fill 20 270 510 20 272 510 minecraft:cyan_concrete
fill 20 270 527 27 271 529 minecraft:black_wool
fill 22 270 530 28 271 530 minecraft:black_wool
fill 22 270 536 26 271 536 minecraft:black_wool
fill 23 270 531 28 271 531 minecraft:black_wool
fill 23 270 535 27 271 535 minecraft:black_wool
fill 24 270 510 24 293 510 minecraft:black_concrete
fill 24 270 532 28 271 533 minecraft:black_wool
setblock 25 270 510 minecraft:light_blue_stained_glass
fill 28 270 528 28 270 529 minecraft:black_wool
fill 30 270 552 30 272 552 minecraft:cyan_concrete
fill 36 270 510 36 272 510 minecraft:cyan_concrete
fill 40 270 552 40 290 552 minecraft:black_concrete
setblock 41 270 510 minecraft:light_blue_stained_glass
fill 42 270 520 42 272 520 minecraft:cyan_concrete
fill 42 270 536 42 272 536 minecraft:cyan_concrete
setblock 42 270 539 minecraft:sea_lantern
fill 0 271 537 0 307 537 minecraft:black_concrete
setblock 0 271 547 minecraft:light_blue_stained_glass
fill 3 271 552 3 307 552 minecraft:black_concrete
fill 15 271 528 15 272 528 minecraft:black_wool
fill 15 271 534 15 272 534 minecraft:black_wool
fill 19 271 524 23 271 524 minecraft:black_wool
fill 19 271 538 23 271 538 minecraft:black_wool
fill 24 271 534 27 272 534 minecraft:black_wool
fill 25 271 510 25 307 510 minecraft:black_concrete
setblock 25 271 552 minecraft:white_concrete
setblock 28 271 529 minecraft:black_wool
setblock 33 271 510 minecraft:light_blue_stained_glass
fill 41 271 510 41 288 510 minecraft:black_concrete
setblock 42 271 511 minecraft:white_concrete
setblock 42 271 517 minecraft:sea_lantern
setblock 42 271 522 minecraft:white_concrete
setblock 42 271 538 minecraft:white_concrete
fill 42 271 539 42 294 539 minecraft:black_concrete
setblock 42 271 551 minecraft:white_concrete
fill 0 272 547 0 301 547 minecraft:black_concrete
setblock 2 272 510 minecraft:light_blue_stained_glass
setblock 6 272 552 minecraft:sea_lantern
fill 15 272 529 15 272 533 minecraft:black_wool
fill 17 272 526 25 272 526 minecraft:black_wool
fill 17 272 536 18 272 536 minecraft:black_wool
fill 18 272 525 24 272 525 minecraft:black_wool
fill 18 272 537 24 272 537 minecraft:black_wool
fill 20 272 527 26 272 529 minecraft:black_wool
fill 22 272 530 27 272 530 minecraft:black_wool
fill 22 272 536 25 272 536 minecraft:black_wool
fill 23 272 531 27 272 531 minecraft:black_wool
fill 23 272 535 26 272 535 minecraft:black_wool
fill 23 272 546 25 272 548 minecraft:light_blue_stained_glass
fill 24 272 532 27 272 533 minecraft:black_wool
fill 25 272 552 25 307 552 minecraft:black_concrete
fill 27 272 528 27 272 529 minecraft:black_wool
fill 33 272 510 33 288 510 minecraft:black_concrete
setblock 33 272 552 minecraft:sea_lantern
fill 36 272 526 38 272 528 minecraft:light_blue_stained_glass
fill 42 272 511 42 274 511 minecraft:black_concrete
setblock 42 272 513 minecraft:sea_lantern
fill 42 272 517 42 307 517 minecraft:black_concrete
fill 42 272 522 42 285 522 minecraft:black_concrete
setblock 42 272 526 minecraft:light_blue_stained_glass
setblock 42 272 528 minecraft:white_concrete
fill 42 272 538 42 285 538 minecraft:black_concrete
fill 42 272 551 42 304 551 minecraft:black_concrete
fill 0 273 518 0 287 518 minecraft:black_concrete
setblock 0 273 520 minecraft:light_blue_stained_glass
fill 0 273 534 0 287 534 minecraft:black_concrete
setblock 0 273 546 minecraft:sea_lantern
setblock 0 273 548 minecraft:light_blue_stained_glass
fill 0 273 550 0 279 550 minecraft:black_concrete
fill 2 273 510 2 298 510 minecraft:black_concrete
fill 4 273 510 4 287 510 minecraft:black_concrete
fill 6 273 552 6 307 552 minecraft:black_concrete
fill 14 273 552 14 287 552 minecraft:black_concrete
setblock 18 273 510 minecraft:light_blue_stained_glass
fill 20 273 510 20 287 510 minecraft:black_concrete
setblock 27 273 552 minecraft:white_concrete
setblock 30 273 552 minecraft:black_concrete
fill 33 273 552 33 307 552 minecraft:black_concrete
fill 36 273 510 36 287 510 minecraft:black_concrete
setblock 37 273 510 minecraft:sea_lantern
fill 42 273 513 42 307 513 minecraft:black_concrete
fill 42 273 520 42 287 520 minecraft:black_concrete
fill 42 273 526 42 307 526 minecraft:black_concrete
fill 42 273 528 42 307 528 minecraft:black_concrete
fill 42 273 536 42 287 536 minecraft:black_concrete
setblock 42 273 547 minecraft:white_concrete
fill 0 274 520 0 292 520 minecraft:black_concrete
fill 0 274 546 0 307 546 minecraft:black_concrete
fill 0 274 548 0 307 548 minecraft:black_concrete
fill 18 274 510 18 307 510 minecraft:black_concrete
setblock 26 274 510 minecraft:white_concrete
fill 27 274 552 27 307 552 minecraft:black_concrete
setblock 30 274 552 minecraft:white_concrete
fill 37 274 510 37 286 510 minecraft:black_concrete
setblock 38 274 552 minecraft:white_concrete
setblock 42 274 543 minecraft:sea_lantern
fill 42 274 547 42 301 547 minecraft:black_concrete
fill 0 275 531 0 277 531 minecraft:black_concrete
setblock 0 275 532 minecraft:white_concrete
fill 0 275 533 0 307 533 minecraft:black_concrete
setblock 3 275 513 minecraft:light[level=11]
setblock 3 275 521 minecraft:light[level=11]
setblock 3 275 529 minecraft:light[level=11]
setblock 3 275 537 minecraft:light[level=11]
setblock 3 275 545 minecraft:light[level=11]
setblock 11 275 513 minecraft:light[level=11]
setblock 11 275 521 minecraft:light[level=11]
setblock 11 275 529 minecraft:light[level=11]
setblock 11 275 537 minecraft:light[level=11]
setblock 11 275 545 minecraft:light[level=11]
setblock 19 275 513 minecraft:light[level=11]
setblock 19 275 521 minecraft:light[level=11]
setblock 19 275 529 minecraft:light[level=11]
setblock 19 275 537 minecraft:light[level=11]
setblock 19 275 545 minecraft:light[level=11]
fill 26 275 510 26 307 510 minecraft:black_concrete
setblock 27 275 513 minecraft:light[level=11]
setblock 27 275 521 minecraft:light[level=11]
setblock 27 275 529 minecraft:light[level=11]
setblock 27 275 537 minecraft:light[level=11]
setblock 27 275 545 minecraft:light[level=11]
fill 30 275 552 30 287 552 minecraft:black_concrete
setblock 35 275 513 minecraft:light[level=11]
setblock 35 275 521 minecraft:light[level=11]
setblock 35 275 529 minecraft:light[level=11]
setblock 35 275 537 minecraft:light[level=11]
setblock 35 275 545 minecraft:light[level=11]
fill 38 275 552 38 307 552 minecraft:black_concrete
setblock 42 275 511 minecraft:white_concrete
setblock 42 275 515 minecraft:white_concrete
fill 42 275 543 42 307 543 minecraft:black_concrete
fill 0 276 532 0 307 532 minecraft:black_concrete
setblock 14 276 510 minecraft:light_blue_stained_glass
setblock 37 276 552 minecraft:white_concrete
fill 42 276 511 42 300 511 minecraft:black_concrete
fill 42 276 515 42 307 515 minecraft:black_concrete
fill 14 277 510 14 298 510 minecraft:black_concrete
setblock 28 277 510 minecraft:sea_lantern
fill 37 277 552 37 307 552 minecraft:black_concrete
setblock 0 278 531 minecraft:light_blue_stained_glass
fill 1 278 520 17 278 542 minecraft:black_concrete
fill 2 278 518 40 278 519 minecraft:black_concrete
fill 2 278 543 40 278 544 minecraft:black_concrete
fill 3 278 517 39 278 517 minecraft:black_concrete
fill 3 278 545 39 278 545 minecraft:black_concrete
fill 4 278 516 38 278 516 minecraft:black_concrete
fill 4 278 546 38 278 546 minecraft:black_concrete
fill 5 278 515 37 278 515 minecraft:black_concrete
fill 5 278 547 37 278 547 minecraft:black_concrete
fill 6 278 514 36 278 514 minecraft:black_concrete
fill 6 278 548 36 278 548 minecraft:black_concrete
fill 7 278 513 35 278 513 minecraft:black_concrete
fill 7 278 549 35 278 549 minecraft:black_concrete
fill 8 278 512 34 278 512 minecraft:black_concrete
fill 8 278 550 34 278 550 minecraft:black_concrete
fill 10 278 511 32 278 511 minecraft:black_concrete
fill 10 278 551 32 278 551 minecraft:black_concrete
fill 18 278 520 18 278 532 minecraft:black_concrete
fill 18 278 534 18 278 542 minecraft:black_concrete
fill 19 278 520 19 278 531 minecraft:black_concrete
fill 19 278 535 19 278 542 minecraft:black_concrete
fill 20 278 520 41 278 530 minecraft:black_concrete
fill 20 278 536 41 278 542 minecraft:black_concrete
fill 21 278 531 41 278 531 minecraft:black_concrete
fill 21 278 535 41 278 535 minecraft:black_concrete
fill 22 278 532 41 278 532 minecraft:black_concrete
fill 22 278 534 41 278 534 minecraft:black_concrete
fill 23 278 533 41 278 533 minecraft:black_concrete
fill 28 278 510 28 302 510 minecraft:black_concrete
fill 0 279 531 1 283 531 minecraft:black_concrete
fill 1 279 521 1 279 530 minecraft:black_concrete
fill 1 279 532 1 279 541 minecraft:black_concrete
fill 2 279 519 2 279 520 minecraft:black_concrete
fill 2 279 521 17 279 541 minecraft:black_wool
fill 2 279 542 2 279 543 minecraft:black_concrete
setblock 3 279 518 minecraft:black_concrete
fill 3 279 519 39 279 520 minecraft:black_wool
fill 3 279 542 39 279 543 minecraft:black_wool
setblock 3 279 544 minecraft:black_concrete
fill 4 279 517 4 280 517 minecraft:black_concrete
fill 4 279 518 38 279 518 minecraft:black_wool
fill 4 279 544 38 279 544 minecraft:black_wool
fill 4 279 545 4 280 545 minecraft:black_concrete
fill 4 279 552 4 280 552 minecraft:sea_lantern
fill 5 279 515 5 279 516 minecraft:black_concrete
fill 5 279 517 37 280 517 minecraft:black_wool
fill 5 279 545 37 280 545 minecraft:black_wool
fill 5 279 546 5 279 547 minecraft:black_concrete
fill 6 279 515 6 280 515 minecraft:black_concrete
fill 6 279 516 36 280 516 minecraft:black_wool
fill 6 279 546 36 280 546 minecraft:black_wool
fill 6 279 547 6 280 547 minecraft:black_concrete
fill 7 279 514 7 280 514 minecraft:black_concrete
fill 7 279 515 35 280 515 minecraft:black_wool
fill 7 279 547 35 280 547 minecraft:black_wool
fill 7 279 548 7 280 548 minecraft:black_concrete
setblock 8 279 513 minecraft:black_concrete
fill 8 279 514 34 279 514 minecraft:black_wool
fill 8 279 548 34 279 548 minecraft:black_wool
setblock 8 279 549 minecraft:black_concrete
fill 9 279 512 10 279 512 minecraft:black_concrete
fill 9 279 513 33 279 513 minecraft:black_wool
fill 9 279 549 33 279 549 minecraft:black_wool
fill 9 279 550 10 279 550 minecraft:black_concrete
fill 11 279 511 31 279 511 minecraft:black_concrete
fill 11 279 512 31 279 512 minecraft:black_wool
fill 11 279 550 31 279 550 minecraft:black_wool
fill 11 279 551 31 279 551 minecraft:black_concrete
fill 18 279 521 18 279 531 minecraft:black_wool
setblock 18 279 532 minecraft:gray_wool
setblock 18 279 534 minecraft:gray_wool
fill 18 279 535 18 279 541 minecraft:black_wool
fill 19 279 521 40 279 530 minecraft:black_wool
setblock 19 279 531 minecraft:gray_wool
setblock 19 279 535 minecraft:gray_wool
fill 19 279 536 40 279 541 minecraft:black_wool
fill 21 279 531 22 279 531 minecraft:gray_wool
setblock 21 279 535 minecraft:gray_wool
setblock 22 279 532 minecraft:gray_wool
setblock 22 279 534 minecraft:gray_wool
fill 22 279 535 40 279 535 minecraft:black_wool
fill 23 279 531 40 279 534 minecraft:black_wool
fill 32 279 512 33 279 512 minecraft:black_concrete
fill 32 279 550 33 279 550 minecraft:black_concrete
setblock 34 279 513 minecraft:black_concrete
setblock 34 279 549 minecraft:black_concrete
setblock 35 279 510 minecraft:light_blue_stained_glass
fill 35 279 514 35 280 514 minecraft:black_concrete
fill 35 279 548 35 280 548 minecraft:black_concrete
fill 36 279 515 37 279 515 minecraft:black_concrete
fill 36 279 547 37 279 547 minecraft:black_concrete
fill 37 279 516 37 280 516 minecraft:black_concrete
fill 37 279 546 37 280 546 minecraft:black_concrete
fill 38 279 517 38 280 517 minecraft:black_concrete
fill 38 279 545 38 280 545 minecraft:black_concrete
setblock 39 279 518 minecraft:black_concrete
setblock 39 279 544 minecraft:black_concrete
fill 40 279 519 40 279 520 minecraft:black_concrete
fill 40 279 542 40 279 543 minecraft:black_concrete
fill 41 279 521 41 279 541 minecraft:black_concrete
setblock 0 280 550 minecraft:sea_lantern
fill 1 280 511 1 280 521 minecraft:black_wool
fill 1 280 522 1 280 530 minecraft:black_concrete
fill 1 280 532 1 280 540 minecraft:black_concrete
fill 1 280 541 1 280 551 minecraft:black_wool
fill 2 280 511 2 280 519 minecraft:black_wool
fill 2 280 520 2 280 521 minecraft:black_concrete
fill 2 280 522 16 280 540 minecraft:black_wool
fill 2 280 541 2 280 542 minecraft:black_concrete
fill 2 280 543 2 280 551 minecraft:black_wool
setblock 3 280 510 minecraft:sea_lantern
fill 3 280 511 3 280 518 minecraft:black_wool
setblock 3 280 519 minecraft:black_concrete
fill 3 280 520 39 280 521 minecraft:black_wool
fill 3 280 541 39 280 542 minecraft:black_wool
setblock 3 280 543 minecraft:black_concrete
fill 3 280 544 3 280 551 minecraft:black_wool
fill 4 280 511 4 280 516 minecraft:black_wool
fill 4 280 518 4 281 518 minecraft:black_concrete
fill 4 280 519 38 280 519 minecraft:black_wool
fill 4 280 543 38 280 543 minecraft:black_wool
fill 4 280 544 4 281 544 minecraft:black_concrete
fill 4 280 546 4 280 551 minecraft:black_wool
fill 5 280 511 5 280 515 minecraft:black_wool
setblock 5 280 516 minecraft:black_concrete
fill 5 280 518 37 281 518 minecraft:black_wool
fill 5 280 544 37 281 544 minecraft:black_wool
setblock 5 280 546 minecraft:black_concrete
fill 5 280 547 5 280 551 minecraft:black_wool
fill 6 280 511 6 280 514 minecraft:black_wool
fill 6 280 548 6 280 551 minecraft:black_wool
fill 7 280 511 8 280 513 minecraft:black_wool
fill 7 280 549 8 280 551 minecraft:black_wool
fill 8 280 514 8 281 514 minecraft:black_concrete
fill 8 280 548 8 281 548 minecraft:black_concrete
fill 9 280 511 9 280 512 minecraft:black_wool
setblock 9 280 513 minecraft:black_concrete
fill 9 280 514 33 280 514 minecraft:black_wool
fill 9 280 548 33 280 548 minecraft:black_wool
setblock 9 280 549 minecraft:black_concrete
fill 9 280 550 9 280 551 minecraft:black_wool
setblock 10 280 510 minecraft:white_concrete
fill 10 280 511 11 280 511 minecraft:black_wool
fill 10 280 512 11 280 512 minecraft:black_concrete
fill 10 280 513 32 280 513 minecraft:black_wool
fill 10 280 549 32 280 549 minecraft:black_wool
fill 10 280 550 11 280 550 minecraft:black_concrete
fill 10 280 551 11 280 551 minecraft:black_wool
fill 12 280 511 30 280 511 minecraft:black_concrete
fill 12 280 512 30 280 512 minecraft:black_wool
fill 12 280 550 30 280 550 minecraft:black_wool
fill 12 280 551 30 280 551 minecraft:black_concrete
fill 17 280 522 17 280 530 minecraft:black_wool
setblock 17 280 531 minecraft:gray_wool
fill 17 280 532 17 280 534 minecraft:sea_lantern
fill 17 280 535 17 280 540 minecraft:black_wool
fill 18 280 522 19 280 529 minecraft:black_wool
setblock 18 280 530 minecraft:gray_wool
fill 18 280 531 18 280 532 minecraft:sea_lantern
fill 18 280 534 18 280 535 minecraft:sea_lantern
fill 18 280 536 18 280 540 minecraft:black_wool
fill 19 280 530 19 280 531 minecraft:sea_lantern
fill 19 280 535 19 280 536 minecraft:sea_lantern
fill 19 280 537 40 280 540 minecraft:black_wool
fill 20 280 522 40 280 528 minecraft:black_wool
fill 20 280 529 21 280 529 minecraft:gray_wool
fill 20 280 530 21 280 530 minecraft:sea_lantern
fill 20 280 536 21 280 536 minecraft:sea_lantern
fill 21 280 531 22 280 531 minecraft:sea_lantern
fill 21 280 535 22 280 535 minecraft:sea_lantern
fill 22 280 529 40 280 529 minecraft:black_wool
setblock 22 280 530 minecraft:gray_wool
fill 22 280 532 23 280 532 minecraft:sea_lantern
fill 22 280 534 23 280 534 minecraft:sea_lantern
setblock 22 280 536 minecraft:gray_wool
fill 23 280 530 40 280 530 minecraft:black_wool
setblock 23 280 531 minecraft:gray_wool
setblock 23 280 533 minecraft:sea_lantern
setblock 23 280 535 minecraft:gray_wool
fill 23 280 536 40 280 536 minecraft:black_wool
fill 24 280 531 40 280 535 minecraft:black_wool
fill 31 280 511 41 280 511 minecraft:black_wool
fill 31 280 512 32 280 512 minecraft:black_concrete
fill 31 280 550 32 280 550 minecraft:black_concrete
fill 31 280 551 41 280 551 minecraft:black_wool
fill 33 280 512 41 280 512 minecraft:black_wool
setblock 33 280 513 minecraft:black_concrete
setblock 33 280 549 minecraft:black_concrete
fill 33 280 550 41 280 550 minecraft:black_wool
fill 34 280 513 41 280 513 minecraft:black_wool
fill 34 280 514 34 281 514 minecraft:black_concrete
fill 34 280 548 34 281 548 minecraft:black_concrete
fill 34 280 549 41 280 549 minecraft:black_wool
fill 35 280 510 35 297 510 minecraft:black_concrete
fill 36 280 514 41 280 514 minecraft:black_wool
setblock 36 280 515 minecraft:black_concrete
setblock 36 280 547 minecraft:black_concrete
fill 36 280 548 41 280 548 minecraft:black_wool
fill 37 280 515 41 280 515 minecraft:black_wool
fill 37 280 547 41 280 547 minecraft:black_wool
fill 38 280 516 41 280 516 minecraft:black_wool
fill 38 280 518 38 281 518 minecraft:black_concrete
fill 38 280 544 38 281 544 minecraft:black_concrete
fill 38 280 546 41 280 546 minecraft:black_wool
fill 39 280 517 41 280 518 minecraft:black_wool
setblock 39 280 519 minecraft:black_concrete
setblock 39 280 543 minecraft:black_concrete
fill 39 280 544 41 280 545 minecraft:black_wool
fill 40 280 519 41 280 519 minecraft:black_wool
fill 40 280 520 40 280 521 minecraft:black_concrete
fill 40 280 541 40 280 542 minecraft:black_concrete
fill 40 280 543 41 280 543 minecraft:black_wool
fill 41 280 520 41 280 521 minecraft:black_wool
fill 41 280 522 41 280 540 minecraft:black_concrete
fill 41 280 541 41 280 542 minecraft:black_wool
fill 0 281 514 0 307 515 minecraft:black_concrete
setblock 0 281 516 minecraft:sea_lantern
fill 0 281 550 0 287 550 minecraft:black_concrete
fill 1 281 523 1 281 530 minecraft:black_concrete
fill 1 281 532 1 281 539 minecraft:black_concrete
fill 2 281 521 2 281 522 minecraft:black_concrete
fill 2 281 523 15 281 539 minecraft:black_wool
fill 2 281 540 2 281 541 minecraft:black_concrete
fill 3 281 510 3 307 510 minecraft:black_concrete
setblock 3 281 520 minecraft:black_concrete
fill 3 281 521 39 281 522 minecraft:black_wool
fill 3 281 540 39 281 541 minecraft:black_wool
setblock 3 281 542 minecraft:black_concrete
fill 4 281 519 4 282 519 minecraft:black_concrete
fill 4 281 520 38 281 520 minecraft:black_wool
fill 4 281 542 38 281 542 minecraft:black_wool
fill 4 281 543 4 282 543 minecraft:black_concrete
fill 4 281 552 4 307 552 minecraft:black_concrete
setblock 5 281 517 minecraft:black_concrete
fill 5 281 519 37 282 519 minecraft:black_wool
fill 5 281 543 37 282 543 minecraft:black_wool
setblock 5 281 545 minecraft:black_concrete
setblock 6 281 516 minecraft:black_concrete
fill 6 281 517 36 281 517 minecraft:black_wool
fill 6 281 545 36 281 545 minecraft:black_wool
setblock 6 281 546 minecraft:black_concrete
setblock 7 281 515 minecraft:black_concrete
fill 7 281 516 35 281 516 minecraft:black_wool
fill 7 281 546 35 281 546 minecraft:black_wool
setblock 7 281 547 minecraft:black_concrete
fill 8 281 515 34 281 515 minecraft:black_wool
fill 8 281 547 34 281 547 minecraft:black_wool
fill 9 281 514 9 282 514 minecraft:black_concrete
fill 9 281 548 9 282 548 minecraft:black_concrete
fill 10 281 510 10 282 510 minecraft:black_concrete
setblock 10 281 513 minecraft:black_concrete
fill 10 281 514 32 281 514 minecraft:black_wool
fill 10 281 548 32 281 548 minecraft:black_wool
setblock 10 281 549 minecraft:black_concrete
fill 11 281 512 12 281 512 minecraft:black_concrete
fill 11 281 513 31 281 513 minecraft:black_wool
fill 11 281 549 31 281 549 minecraft:black_wool
fill 11 281 550 12 281 550 minecraft:black_concrete
fill 13 281 511 29 281 511 minecraft:black_concrete
fill 13 281 512 29 281 512 minecraft:black_wool
fill 13 281 550 29 281 550 minecraft:black_wool
fill 13 281 551 29 281 551 minecraft:black_concrete
fill 16 281 523 16 281 530 minecraft:black_wool
fill 16 281 531 16 281 534 minecraft:gray_wool
fill 16 281 535 16 281 539 minecraft:black_wool
fill 17 281 523 18 281 528 minecraft:black_wool
fill 17 281 529 17 281 530 minecraft:gray_wool
fill 17 281 535 17 281 536 minecraft:gray_wool
fill 17 281 537 18 281 539 minecraft:black_wool
fill 18 281 529 19 281 529 minecraft:gray_wool
setblock 18 281 536 minecraft:gray_wool
fill 19 281 523 40 281 527 minecraft:black_wool
fill 19 281 528 22 281 528 minecraft:gray_wool
fill 19 281 537 22 281 537 minecraft:gray_wool
fill 19 281 538 40 281 539 minecraft:black_wool
fill 22 281 529 23 281 529 minecraft:gray_wool
fill 23 281 528 40 281 528 minecraft:black_wool
fill 23 281 530 24 281 530 minecraft:gray_wool
setblock 23 281 536 minecraft:gray_wool
fill 23 281 537 40 281 537 minecraft:black_wool
fill 24 281 529 40 281 529 minecraft:black_wool
fill 24 281 531 24 281 535 minecraft:gray_wool
fill 24 281 536 40 281 536 minecraft:black_wool
fill 25 281 530 40 281 531 minecraft:black_wool
fill 25 281 532 25 281 533 minecraft:gray_wool
fill 25 281 534 40 281 535 minecraft:black_wool
fill 26 281 532 40 281 533 minecraft:black_wool
fill 30 281 512 31 281 512 minecraft:black_concrete
fill 30 281 550 31 281 550 minecraft:black_concrete
setblock 32 281 513 minecraft:black_concrete
setblock 32 281 549 minecraft:black_concrete
fill 33 281 514 33 282 514 minecraft:black_concrete
fill 33 281 548 33 282 548 minecraft:black_concrete
setblock 35 281 515 minecraft:black_concrete
setblock 35 281 547 minecraft:black_concrete
setblock 36 281 516 minecraft:black_concrete
setblock 36 281 546 minecraft:black_concrete
setblock 37 281 517 minecraft:black_concrete
setblock 37 281 545 minecraft:black_concrete
fill 38 281 519 38 282 519 minecraft:black_concrete
fill 38 281 543 38 282 543 minecraft:black_concrete
setblock 39 281 520 minecraft:black_concrete
setblock 39 281 542 minecraft:black_concrete
fill 40 281 521 40 281 522 minecraft:black_concrete
fill 40 281 540 40 281 541 minecraft:black_concrete
fill 41 281 523 41 281 539 minecraft:black_concrete
setblock 42 281 523 minecraft:sea_lantern
fill 0 282 516 0 302 516 minecraft:black_concrete
fill 1 282 525 1 282 530 minecraft:black_concrete
fill 1 282 532 1 282 537 minecraft:black_concrete
fill 2 282 523 2 282 524 minecraft:black_concrete
fill 2 282 525 14 282 537 minecraft:black_wool
fill 2 282 538 2 282 539 minecraft:black_concrete
fill 3 282 521 3 282 522 minecraft:black_concrete
fill 3 282 523 39 282 524 minecraft:black_wool
fill 3 282 538 18 282 539 minecraft:black_wool
fill 3 282 540 3 282 541 minecraft:black_concrete
fill 4 282 520 4 283 520 minecraft:black_concrete
fill 4 282 521 38 282 522 minecraft:black_wool
fill 4 282 540 38 282 541 minecraft:black_wool
fill 4 282 542 4 283 542 minecraft:black_concrete
setblock 5 282 518 minecraft:black_concrete
fill 5 282 520 37 283 520 minecraft:black_wool
fill 5 282 542 37 283 542 minecraft:black_wool
setblock 5 282 544 minecraft:black_concrete
setblock 6 282 517 minecraft:black_concrete
fill 6 282 518 36 282 518 minecraft:black_wool
fill 6 282 544 36 282 544 minecraft:black_wool
setblock 6 282 545 minecraft:black_concrete
setblock 7 282 516 minecraft:black_concrete
fill 7 282 517 35 282 517 minecraft:black_wool
fill 7 282 545 35 282 545 minecraft:black_wool
setblock 7 282 546 minecraft:black_concrete
setblock 8 282 515 minecraft:black_concrete
fill 8 282 516 34 282 516 minecraft:black_wool
fill 8 282 546 34 282 546 minecraft:black_wool
setblock 8 282 547 minecraft:black_concrete
fill 9 282 515 33 282 515 minecraft:black_wool
fill 9 282 547 33 282 547 minecraft:black_wool
fill 10 282 514 10 283 514 minecraft:black_concrete
fill 10 282 548 10 283 548 minecraft:black_concrete
fill 11 282 513 12 282 513 minecraft:black_concrete
fill 11 282 514 31 282 514 minecraft:black_wool
fill 11 282 548 31 282 548 minecraft:black_wool
fill 11 282 549 12 282 549 minecraft:black_concrete
fill 13 282 512 14 282 512 minecraft:black_concrete
fill 13 282 513 29 282 513 minecraft:black_wool
fill 13 282 549 29 282 549 minecraft:black_wool
fill 13 282 550 14 282 550 minecraft:black_concrete
fill 15 282 511 27 282 511 minecraft:black_concrete
fill 15 282 512 27 282 512 minecraft:black_wool
fill 15 282 525 15 282 529 minecraft:black_wool
fill 15 282 530 15 282 534 minecraft:gray_wool
fill 15 282 535 15 282 537 minecraft:black_wool
fill 15 282 550 27 282 550 minecraft:black_wool
fill 15 282 551 27 282 551 minecraft:black_concrete
fill 16 282 525 16 282 528 minecraft:black_wool
fill 16 282 529 16 282 530 minecraft:gray_wool
fill 16 282 535 16 282 536 minecraft:gray_wool
setblock 16 282 537 minecraft:black_wool
fill 17 282 525 17 282 527 minecraft:black_wool
fill 17 282 528 18 282 528 minecraft:gray_wool
fill 17 282 537 18 282 537 minecraft:gray_wool
fill 18 282 525 40 282 526 minecraft:black_wool
fill 18 282 527 23 282 527 minecraft:gray_wool
fill 19 282 538 22 282 538 minecraft:gray_wool
fill 19 282 539 39 282 539 minecraft:black_wool
fill 23 282 528 24 282 528 minecraft:gray_wool
fill 23 282 537 24 282 537 minecraft:gray_wool
fill 23 282 538 39 282 538 minecraft:black_wool
fill 24 282 527 40 282 527 minecraft:black_wool
fill 24 282 529 25 282 529 minecraft:gray_wool
fill 24 282 536 25 282 536 minecraft:gray_wool
fill 25 282 528 40 282 528 minecraft:black_wool
fill 25 282 530 25 282 531 minecraft:gray_wool
fill 25 282 534 25 282 535 minecraft:gray_wool
fill 25 282 537 40 282 537 minecraft:black_wool
fill 26 282 529 40 282 530 minecraft:black_wool
fill 26 282 531 26 282 534 minecraft:gray_wool
fill 26 282 535 40 282 536 minecraft:black_wool
fill 27 282 531 40 282 534 minecraft:black_wool
fill 28 282 512 29 282 512 minecraft:black_concrete
fill 28 282 550 29 282 550 minecraft:black_concrete
fill 30 282 513 31 282 513 minecraft:black_concrete
fill 30 282 549 31 282 549 minecraft:black_concrete
fill 32 282 514 32 283 514 minecraft:black_concrete
fill 32 282 548 32 283 548 minecraft:black_concrete
setblock 34 282 515 minecraft:black_concrete
setblock 34 282 547 minecraft:black_concrete
setblock 35 282 516 minecraft:black_concrete
setblock 35 282 546 minecraft:black_concrete
setblock 36 282 517 minecraft:black_concrete
setblock 36 282 545 minecraft:black_concrete
setblock 37 282 518 minecraft:black_concrete
setblock 37 282 544 minecraft:black_concrete
fill 38 282 520 38 283 520 minecraft:black_concrete
fill 38 282 542 38 283 542 minecraft:black_concrete
fill 39 282 521 39 282 522 minecraft:black_concrete
fill 39 282 540 39 282 541 minecraft:black_concrete
fill 40 282 523 40 282 524 minecraft:black_concrete
fill 40 282 538 40 282 539 minecraft:black_concrete
fill 41 282 525 41 282 537 minecraft:black_concrete
fill 42 282 523 42 293 523 minecraft:black_concrete
setblock 42 282 546 minecraft:white_concrete
fill 1 283 528 1 283 530 minecraft:black_concrete
fill 1 283 532 1 283 534 minecraft:black_concrete
fill 2 283 524 2 283 527 minecraft:black_concrete
fill 2 283 528 13 283 534 minecraft:black_wool
fill 2 283 535 2 283 538 minecraft:black_concrete
setblock 3 283 513 minecraft:light[level=11]
setblock 3 283 521 minecraft:light[level=11]
fill 3 283 522 3 283 523 minecraft:black_concrete
fill 3 283 524 15 283 527 minecraft:black_wool
fill 3 283 535 14 283 538 minecraft:black_wool
fill 3 283 539 3 283 540 minecraft:black_concrete
setblock 3 283 545 minecraft:light[level=11]
setblock 4 283 521 minecraft:black_concrete
fill 4 283 522 38 283 523 minecraft:black_wool
fill 4 283 539 18 283 540 minecraft:black_wool
setblock 4 283 541 minecraft:black_concrete
setblock 5 283 519 minecraft:black_concrete
fill 5 283 521 37 283 521 minecraft:black_wool
fill 5 283 541 37 283 541 minecraft:black_wool
setblock 5 283 543 minecraft:black_concrete
setblock 6 283 518 minecraft:black_concrete
fill 6 283 519 36 283 519 minecraft:black_wool
fill 6 283 543 36 283 543 minecraft:black_wool
setblock 6 283 544 minecraft:black_concrete
setblock 7 283 517 minecraft:black_concrete
fill 7 283 518 35 283 518 minecraft:black_wool
fill 7 283 544 35 283 544 minecraft:black_wool
setblock 7 283 545 minecraft:black_concrete
setblock 8 283 516 minecraft:black_concrete
fill 8 283 517 34 283 517 minecraft:black_wool
fill 8 283 545 34 283 545 minecraft:black_wool
setblock 8 283 546 minecraft:black_concrete
setblock 9 283 515 minecraft:black_concrete
fill 9 283 516 33 283 516 minecraft:black_wool
fill 9 283 546 33 283 546 minecraft:black_wool
setblock 9 283 547 minecraft:black_concrete
setblock 10 283 510 minecraft:white_concrete
fill 10 283 515 32 283 515 minecraft:black_wool
fill 10 283 547 32 283 547 minecraft:black_wool
setblock 11 283 513 minecraft:light[level=11]
setblock 11 283 514 minecraft:black_concrete
setblock 11 283 548 minecraft:black_concrete
fill 12 283 513 13 283 513 minecraft:black_concrete
fill 12 283 514 30 283 514 minecraft:black_wool
fill 12 283 548 30 283 548 minecraft:black_wool
fill 12 283 549 13 283 549 minecraft:black_concrete
fill 14 283 512 17 283 512 minecraft:black_concrete
fill 14 283 513 28 283 513 minecraft:black_wool
fill 14 283 528 14 283 529 minecraft:black_wool
fill 14 283 530 14 283 534 minecraft:gray_wool
fill 14 283 549 28 283 549 minecraft:black_wool
fill 14 283 550 17 283 550 minecraft:black_concrete
fill 15 283 528 15 283 529 minecraft:gray_wool
fill 15 283 535 15 283 536 minecraft:gray_wool
fill 15 283 537 15 283 538 minecraft:black_wool
setblock 16 283 510 minecraft:white_concrete
fill 16 283 524 16 283 526 minecraft:black_wool
fill 16 283 527 16 283 528 minecraft:gray_wool
setblock 16 283 537 minecraft:gray_wool
setblock 16 283 538 minecraft:black_wool
fill 17 283 524 19 283 525 minecraft:black_wool
fill 17 283 526 17 283 527 minecraft:gray_wool
fill 17 283 538 18 283 538 minecraft:gray_wool
fill 18 283 511 24 283 511 minecraft:black_concrete
fill 18 283 512 24 283 512 minecraft:black_wool
fill 18 283 526 24 283 526 minecraft:gray_wool
fill 18 283 550 24 283 550 minecraft:black_wool
fill 18 283 551 24 283 551 minecraft:black_concrete
setblock 19 283 529 minecraft:light[level=11]
setblock 19 283 537 minecraft:light[level=11]
fill 19 283 539 22 283 539 minecraft:gray_wool
fill 19 283 540 38 283 540 minecraft:black_wool
fill 20 283 524 39 283 524 minecraft:black_wool
fill 20 283 525 21 283 525 minecraft:gray_wool
fill 22 283 525 39 283 525 minecraft:black_wool
fill 23 283 538 24 283 538 minecraft:gray_wool
fill 23 283 539 38 283 539 minecraft:black_wool
fill 24 283 527 25 283 527 minecraft:gray_wool
fill 25 283 512 28 283 512 minecraft:black_concrete
fill 25 283 526 39 283 526 minecraft:black_wool
fill 25 283 528 26 283 528 minecraft:gray_wool
setblock 25 283 537 minecraft:gray_wool
fill 25 283 538 39 283 538 minecraft:black_wool
fill 25 283 550 28 283 550 minecraft:black_concrete
fill 26 283 527 39 283 527 minecraft:black_wool
fill 26 283 529 26 283 530 minecraft:gray_wool
fill 26 283 535 26 283 536 minecraft:gray_wool
fill 26 283 537 39 283 537 minecraft:black_wool
fill 27 283 528 40 283 529 minecraft:black_wool
fill 27 283 530 27 283 534 minecraft:gray_wool
fill 27 283 535 39 283 536 minecraft:black_wool
fill 28 283 530 40 283 534 minecraft:black_wool
fill 29 283 513 30 283 513 minecraft:black_concrete
fill 29 283 549 30 283 549 minecraft:black_concrete
setblock 31 283 514 minecraft:black_concrete
setblock 31 283 548 minecraft:black_concrete
setblock 31 283 552 minecraft:white_concrete
setblock 33 283 515 minecraft:black_concrete
setblock 33 283 547 minecraft:black_concrete
setblock 34 283 516 minecraft:black_concrete
setblock 34 283 546 minecraft:black_concrete
setblock 35 283 513 minecraft:light[level=11]
setblock 35 283 517 minecraft:black_concrete
setblock 35 283 545 minecraft:black_concrete
setblock 36 283 518 minecraft:black_concrete
setblock 36 283 544 minecraft:black_concrete
setblock 37 283 519 minecraft:black_concrete
setblock 37 283 543 minecraft:black_concrete
setblock 38 283 521 minecraft:black_concrete
setblock 38 283 541 minecraft:black_concrete
fill 39 283 522 39 283 523 minecraft:black_concrete
fill 39 283 539 39 283 540 minecraft:black_concrete
fill 40 283 524 40 283 527 minecraft:black_concrete
fill 40 283 535 40 283 538 minecraft:black_concrete
fill 41 283 528 41 283 534 minecraft:black_concrete
fill 42 283 546 42 307 546 minecraft:black_concrete
setblock 0 284 527 minecraft:white_concrete
fill 0 284 531 0 286 531 minecraft:black_concrete
fill 2 284 527 2 284 535 minecraft:black_concrete
fill 2 284 545 2 297 545 minecraft:iron_block
fill 3 284 524 3 284 526 minecraft:black_concrete
fill 3 284 527 12 284 535 minecraft:black_wool
fill 3 284 536 3 284 538 minecraft:black_concrete
fill 4 284 522 4 284 523 minecraft:black_concrete
fill 4 284 524 14 284 526 minecraft:black_wool
fill 4 284 536 13 284 538 minecraft:black_wool
fill 4 284 539 4 284 540 minecraft:black_concrete
fill 5 284 520 5 284 521 minecraft:black_concrete
fill 5 284 522 37 284 523 minecraft:black_wool
fill 5 284 539 16 284 540 minecraft:black_wool
fill 5 284 541 5 284 542 minecraft:black_concrete
setblock 6 284 519 minecraft:black_concrete
fill 6 284 520 36 284 521 minecraft:black_wool
fill 6 284 541 36 284 542 minecraft:black_wool
setblock 6 284 543 minecraft:black_concrete
setblock 7 284 518 minecraft:black_concrete
fill 7 284 519 35 284 519 minecraft:black_wool
fill 7 284 543 35 284 543 minecraft:black_wool
setblock 7 284 544 minecraft:black_concrete
setblock 8 284 517 minecraft:black_concrete
fill 8 284 518 34 284 518 minecraft:black_wool
fill 8 284 544 34 284 544 minecraft:black_wool
setblock 8 284 545 minecraft:black_concrete
setblock 9 284 516 minecraft:black_concrete
fill 9 284 517 33 284 517 minecraft:black_wool
fill 9 284 545 33 284 545 minecraft:black_wool
setblock 9 284 546 minecraft:black_concrete
fill 10 284 510 10 306 510 minecraft:black_concrete
fill 10 284 515 11 284 515 minecraft:black_concrete
fill 10 284 516 32 284 516 minecraft:black_wool
fill 10 284 546 32 284 546 minecraft:black_wool
fill 10 284 547 11 284 547 minecraft:black_concrete
fill 12 284 514 13 284 514 minecraft:black_concrete
fill 12 284 515 30 284 515 minecraft:black_wool
fill 12 284 547 30 284 547 minecraft:black_wool
fill 12 284 548 13 284 548 minecraft:black_concrete
fill 13 284 527 13 284 528 minecraft:black_wool
fill 13 284 529 13 284 534 minecraft:gray_wool
setblock 13 284 535 minecraft:black_wool
fill 14 284 513 16 284 513 minecraft:black_concrete
fill 14 284 514 28 284 514 minecraft:black_wool
fill 14 284 527 14 284 529 minecraft:gray_wool
fill 14 284 535 14 284 536 minecraft:gray_wool
fill 14 284 537 14 284 538 minecraft:black_wool
fill 14 284 548 28 284 548 minecraft:black_wool
fill 14 284 549 16 284 549 minecraft:black_concrete
setblock 15 284 510 minecraft:sea_lantern
fill 15 284 524 16 284 525 minecraft:black_wool
fill 15 284 526 15 284 527 minecraft:gray_wool
setblock 15 284 537 minecraft:gray_wool
setblock 15 284 538 minecraft:black_wool
fill 16 284 510 16 307 510 minecraft:black_concrete
setblock 16 284 526 minecraft:gray_wool
setblock 16 284 538 minecraft:gray_wool
fill 17 284 512 25 284 512 minecraft:black_concrete
fill 17 284 513 25 284 513 minecraft:black_wool
fill 17 284 524 18 284 524 minecraft:black_wool
fill 17 284 525 19 284 525 minecraft:gray_wool
fill 17 284 539 19 284 539 minecraft:gray_wool
fill 17 284 540 19 284 540 minecraft:black_wool
fill 17 284 549 25 284 549 minecraft:black_wool
fill 17 284 550 25 284 550 minecraft:black_concrete
fill 19 284 524 23 284 524 minecraft:gray_wool
fill 20 284 540 21 285 540 minecraft:gray_wool
fill 22 284 525 25 284 525 minecraft:gray_wool
fill 22 284 539 24 284 539 minecraft:gray_wool
fill 22 284 540 37 284 540 minecraft:black_wool
fill 24 284 524 38 284 524 minecraft:black_wool
fill 25 284 526 26 284 526 minecraft:gray_wool
setblock 25 284 538 minecraft:gray_wool
fill 25 284 539 37 284 539 minecraft:black_wool
fill 26 284 513 28 284 513 minecraft:black_concrete
fill 26 284 525 38 284 525 minecraft:black_wool
fill 26 284 527 27 284 527 minecraft:gray_wool
setblock 26 284 537 minecraft:gray_wool
fill 26 284 538 38 284 538 minecraft:black_wool
fill 26 284 549 28 284 549 minecraft:black_concrete
fill 27 284 526 38 284 526 minecraft:black_wool
fill 27 284 528 27 284 529 minecraft:gray_wool
fill 27 284 535 27 284 536 minecraft:gray_wool
fill 27 284 537 38 284 537 minecraft:black_wool
fill 28 284 527 39 284 528 minecraft:black_wool
fill 28 284 529 28 284 535 minecraft:gray_wool
fill 28 284 536 38 284 536 minecraft:black_wool
fill 29 284 514 30 284 514 minecraft:black_concrete
fill 29 284 529 39 284 535 minecraft:black_wool
fill 29 284 548 30 284 548 minecraft:black_concrete
fill 31 284 515 32 284 515 minecraft:black_concrete
fill 31 284 547 32 284 547 minecraft:black_concrete
fill 31 284 552 31 307 552 minecraft:black_concrete
setblock 33 284 516 minecraft:black_concrete
setblock 33 284 546 minecraft:black_concrete
setblock 34 284 517 minecraft:black_concrete
setblock 34 284 545 minecraft:black_concrete
setblock 35 284 518 minecraft:black_concrete
setblock 35 284 544 minecraft:black_concrete
setblock 36 284 519 minecraft:black_concrete
setblock 36 284 543 minecraft:black_concrete
fill 37 284 520 37 284 521 minecraft:black_concrete
fill 37 284 541 37 284 542 minecraft:black_concrete
fill 38 284 522 38 284 523 minecraft:black_concrete
fill 38 284 539 38 284 540 minecraft:black_concrete
fill 39 284 524 39 284 526 minecraft:black_concrete
fill 39 284 536 39 284 538 minecraft:black_concrete
fill 40 284 527 40 284 535 minecraft:black_concrete
fill 0 285 527 0 307 527 minecraft:black_concrete
setblock 0 285 543 minecraft:white_concrete
fill 3 285 526 3 285 536 minecraft:black_concrete
fill 4 285 523 4 285 525 minecraft:black_concrete
fill 4 285 526 11 285 536 minecraft:black_wool
fill 4 285 537 4 285 539 minecraft:black_concrete
setblock 5 285 522 minecraft:black_concrete
fill 5 285 523 14 285 525 minecraft:black_wool
fill 5 285 537 13 285 539 minecraft:black_wool
setblock 5 285 540 minecraft:black_concrete
fill 6 285 520 6 285 521 minecraft:black_concrete
fill 6 285 522 36 285 522 minecraft:black_wool
fill 6 285 540 16 285 540 minecraft:black_wool
fill 6 285 541 6 285 542 minecraft:black_concrete
setblock 7 285 519 minecraft:black_concrete
fill 7 285 520 35 285 521 minecraft:black_wool
fill 7 285 541 35 285 542 minecraft:black_wool
setblock 7 285 543 minecraft:black_concrete
setblock 8 285 518 minecraft:black_concrete
fill 8 285 519 34 285 519 minecraft:black_wool
fill 8 285 543 34 285 543 minecraft:black_wool
setblock 8 285 544 minecraft:black_concrete
setblock 9 285 517 minecraft:black_concrete
fill 9 285 518 33 285 518 minecraft:black_wool
fill 9 285 544 33 285 544 minecraft:black_wool
setblock 9 285 545 minecraft:black_concrete
fill 10 285 516 11 285 516 minecraft:black_concrete
fill 10 285 517 32 285 517 minecraft:black_wool
fill 10 285 545 32 285 545 minecraft:black_wool
fill 10 285 546 11 285 546 minecraft:black_concrete
setblock 12 285 515 minecraft:black_concrete
fill 12 285 516 30 285 516 minecraft:black_wool
fill 12 285 526 12 285 528 minecraft:black_wool
fill 12 285 529 12 285 534 minecraft:gray_wool
fill 12 285 535 12 285 536 minecraft:black_wool
fill 12 285 546 30 285 546 minecraft:black_wool
setblock 12 285 547 minecraft:black_concrete
fill 13 285 514 15 285 514 minecraft:black_concrete
fill 13 285 515 29 285 515 minecraft:black_wool
setblock 13 285 526 minecraft:black_wool
fill 13 285 527 13 285 528 minecraft:gray_wool
fill 13 285 535 13 285 536 minecraft:gray_wool
fill 13 285 547 29 285 547 minecraft:black_wool
fill 13 285 548 15 285 548 minecraft:black_concrete
setblock 14 285 526 minecraft:gray_wool
setblock 14 285 537 minecraft:gray_wool
fill 14 285 538 14 285 539 minecraft:black_wool
fill 15 285 510 15 307 510 minecraft:black_concrete
fill 15 285 523 15 285 524 minecraft:black_wool
fill 15 285 525 16 285 525 minecraft:gray_wool
setblock 15 285 538 minecraft:gray_wool
setblock 15 285 539 minecraft:black_wool
fill 16 285 513 26 285 513 minecraft:black_concrete
fill 16 285 514 26 285 514 minecraft:black_wool
fill 16 285 523 17 285 523 minecraft:black_wool
fill 16 285 524 18 285 524 minecraft:gray_wool
setblock 16 285 539 minecraft:gray_wool
fill 16 285 548 26 285 548 minecraft:black_wool
fill 16 285 549 26 285 549 minecraft:black_concrete
fill 17 285 540 19 285 540 minecraft:gray_wool
fill 18 285 523 24 285 523 minecraft:gray_wool
setblock 19 285 552 minecraft:light_blue_stained_glass
fill 22 285 540 24 285 540 minecraft:gray_wool
fill 24 285 524 26 285 524 minecraft:gray_wool
fill 25 285 523 37 285 523 minecraft:black_wool
fill 25 285 539 26 285 539 minecraft:gray_wool
fill 25 285 540 36 285 540 minecraft:black_wool
fill 26 285 525 27 285 525 minecraft:gray_wool
fill 26 285 538 27 285 538 minecraft:gray_wool
fill 27 285 514 29 285 514 minecraft:black_concrete
fill 27 285 524 37 285 524 minecraft:black_wool
fill 27 285 526 28 285 526 minecraft:gray_wool
fill 27 285 537 28 285 537 minecraft:gray_wool
fill 27 285 539 37 285 539 minecraft:black_wool
fill 27 285 548 29 285 548 minecraft:black_concrete
fill 28 285 525 37 285 525 minecraft:black_wool
fill 28 285 527 28 285 528 minecraft:gray_wool
setblock 28 285 536 minecraft:gray_wool
fill 28 285 538 37 285 538 minecraft:black_wool
fill 29 285 526 38 285 527 minecraft:black_wool
fill 29 285 528 29 285 535 minecraft:gray_wool
fill 29 285 536 37 285 537 minecraft:black_wool
setblock 30 285 515 minecraft:black_concrete
fill 30 285 528 38 285 535 minecraft:black_wool
setblock 30 285 547 minecraft:black_concrete
fill 31 285 516 32 285 516 minecraft:black_concrete
fill 31 285 546 32 285 546 minecraft:black_concrete
setblock 33 285 517 minecraft:black_concrete
setblock 33 285 545 minecraft:black_concrete
setblock 34 285 518 minecraft:black_concrete
setblock 34 285 544 minecraft:black_concrete
setblock 35 285 519 minecraft:black_concrete
setblock 35 285 543 minecraft:black_concrete
fill 35 285 544 35 294 544 minecraft:iron_block
fill 36 285 520 36 285 521 minecraft:black_concrete
fill 36 285 541 36 285 542 minecraft:black_concrete
setblock 37 285 522 minecraft:black_concrete
setblock 37 285 540 minecraft:black_concrete
fill 38 285 523 38 285 525 minecraft:black_concrete
setblock 38 285 536 minecraft:black_wool
fill 38 285 537 38 285 539 minecraft:black_concrete
fill 39 285 526 39 285 536 minecraft:black_concrete
fill 0 286 543 0 307 543 minecraft:black_concrete
setblock 0 286 549 minecraft:light_blue_stained_glass
fill 4 286 526 4 286 536 minecraft:black_concrete
fill 5 286 523 5 286 525 minecraft:black_concrete
fill 5 286 526 10 286 536 minecraft:black_wool
fill 5 286 537 5 286 539 minecraft:black_concrete
fill 6 286 522 6 286 523 minecraft:black_concrete
fill 6 286 524 12 286 525 minecraft:black_wool
fill 6 286 537 12 286 538 minecraft:black_wool
fill 6 286 539 6 286 540 minecraft:black_concrete
fill 7 286 520 7 286 521 minecraft:black_concrete
fill 7 286 522 14 286 523 minecraft:black_wool
fill 7 286 539 13 286 540 minecraft:black_wool
fill 7 286 541 7 286 542 minecraft:black_concrete
fill 8 286 519 8 286 520 minecraft:black_concrete
fill 8 286 521 20 286 521 minecraft:black_wool
fill 8 286 541 16 286 541 minecraft:black_wool
fill 8 286 542 8 286 543 minecraft:black_concrete
fill 9 286 518 9 286 519 minecraft:black_concrete
fill 9 286 520 33 286 520 minecraft:black_wool
fill 9 286 542 33 286 542 minecraft:black_wool
fill 9 286 543 9 286 544 minecraft:black_concrete
fill 10 286 517 10 286 518 minecraft:black_concrete
fill 10 286 519 32 286 519 minecraft:black_wool
fill 10 286 543 32 286 543 minecraft:black_wool
fill 10 286 544 10 286 545 minecraft:black_concrete
setblock 11 286 517 minecraft:black_concrete
fill 11 286 518 31 286 518 minecraft:black_wool
fill 11 286 526 11 286 528 minecraft:black_wool
fill 11 286 529 11 286 534 minecraft:gray_wool
fill 11 286 535 11 286 536 minecraft:black_wool
fill 11 286 544 31 286 544 minecraft:black_wool
setblock 11 286 545 minecraft:black_concrete
fill 12 286 516 13 286 516 minecraft:black_concrete
fill 12 286 517 30 286 517 minecraft:black_wool
fill 12 286 526 12 286 528 minecraft:gray_wool
fill 12 286 535 12 286 536 minecraft:gray_wool
fill 12 286 545 30 286 545 minecraft:black_wool
fill 12 286 546 13 286 546 minecraft:black_concrete
fill 13 286 515 15 286 515 minecraft:black_concrete
setblock 13 286 524 minecraft:black_wool
fill 13 286 525 13 286 526 minecraft:gray_wool
fill 13 286 537 13 286 538 minecraft:gray_wool
fill 13 286 547 15 286 547 minecraft:black_concrete
fill 14 286 516 28 286 516 minecraft:black_wool
fill 14 286 524 14 286 525 minecraft:gray_wool
fill 14 286 538 14 286 539 minecraft:gray_wool
fill 14 286 540 15 286 540 minecraft:black_wool
fill 14 286 546 28 286 546 minecraft:black_wool
fill 15 286 522 16 286 522 minecraft:black_wool
fill 15 286 523 15 286 524 minecraft:gray_wool
setblock 15 286 539 minecraft:gray_wool
fill 16 286 514 26 286 514 minecraft:black_concrete
fill 16 286 515 26 286 515 minecraft:black_wool
fill 16 286 523 17 286 523 minecraft:gray_wool
setblock 16 286 540 minecraft:gray_wool
fill 16 286 547 26 286 547 minecraft:black_wool
fill 16 286 548 26 286 548 minecraft:black_concrete
fill 17 286 522 25 286 522 minecraft:gray_wool
fill 17 286 541 24 286 541 minecraft:gray_wool
fill 19 286 552 19 307 552 minecraft:black_concrete
setblock 21 286 521 minecraft:gray_wool
fill 22 286 521 34 286 521 minecraft:black_wool
fill 25 286 523 26 286 523 minecraft:gray_wool
fill 25 286 540 26 286 540 minecraft:gray_wool
fill 25 286 541 34 286 541 minecraft:black_wool
fill 26 286 522 35 286 522 minecraft:black_wool
fill 27 286 515 29 286 515 minecraft:black_concrete
fill 27 286 523 35 286 523 minecraft:black_wool
fill 27 286 524 28 286 524 minecraft:gray_wool
setblock 27 286 539 minecraft:gray_wool
fill 27 286 540 35 286 540 minecraft:black_wool
fill 27 286 547 29 286 547 minecraft:black_concrete
fill 28 286 525 29 286 525 minecraft:gray_wool
setblock 28 286 538 minecraft:gray_wool
fill 28 286 539 35 286 539 minecraft:black_wool
fill 29 286 516 30 286 516 minecraft:black_concrete
fill 29 286 524 36 286 524 minecraft:black_wool
fill 29 286 526 29 286 527 minecraft:gray_wool
fill 29 286 536 29 286 537 minecraft:gray_wool
fill 29 286 538 36 286 538 minecraft:black_wool
fill 29 286 546 30 286 546 minecraft:black_concrete
fill 30 286 525 36 286 526 minecraft:black_wool
fill 30 286 527 30 286 536 minecraft:gray_wool
fill 30 286 537 36 286 537 minecraft:black_wool
fill 31 286 517 32 286 517 minecraft:black_concrete
fill 31 286 527 37 286 529 minecraft:black_wool
fill 31 286 530 31 286 533 minecraft:gray_wool
fill 31 286 534 37 286 536 minecraft:black_wool
fill 31 286 545 32 286 545 minecraft:black_concrete
fill 32 286 518 33 286 518 minecraft:black_concrete
fill 32 286 530 37 286 533 minecraft:black_wool
fill 32 286 544 33 286 544 minecraft:black_concrete
fill 33 286 519 34 286 519 minecraft:black_concrete
fill 33 286 543 34 286 543 minecraft:black_concrete
fill 34 286 520 35 286 520 minecraft:black_concrete
fill 34 286 542 35 286 542 minecraft:black_concrete
setblock 35 286 521 minecraft:black_concrete
setblock 35 286 541 minecraft:black_concrete
fill 36 286 522 36 286 523 minecraft:black_concrete
fill 36 286 539 36 286 540 minecraft:black_concrete
fill 37 286 523 37 286 525 minecraft:black_concrete
setblock 37 286 526 minecraft:black_wool
fill 37 286 537 37 286 539 minecraft:black_concrete
fill 38 286 526 38 286 536 minecraft:black_concrete
setblock 42 286 522 minecraft:light_blue_stained_glass
setblock 42 286 538 minecraft:white_concrete
setblock 42 286 550 minecraft:white_concrete
setblock 0 287 531 minecraft:sea_lantern
setblock 0 287 539 minecraft:sea_lantern
fill 0 287 549 0 307 549 minecraft:black_concrete
fill 5 287 526 5 287 536 minecraft:black_concrete
fill 6 287 524 6 287 528 minecraft:black_concrete
fill 6 287 529 9 287 533 minecraft:black_wool
fill 6 287 534 6 287 538 minecraft:black_concrete
fill 7 287 522 7 287 525 minecraft:black_concrete
fill 7 287 526 9 287 528 minecraft:black_wool
fill 7 287 534 9 287 536 minecraft:black_wool
fill 7 287 537 7 287 540 minecraft:black_concrete
fill 8 287 521 8 287 523 minecraft:black_concrete
fill 8 287 524 11 287 525 minecraft:black_wool
fill 8 287 537 11 287 538 minecraft:black_wool
fill 8 287 539 8 287 541 minecraft:black_concrete
fill 9 287 520 9 287 521 minecraft:black_concrete
fill 9 287 522 12 287 523 minecraft:black_wool
fill 9 287 539 12 287 540 minecraft:black_wool
fill 9 287 541 9 287 542 minecraft:black_concrete
fill 10 287 519 10 287 520 minecraft:black_concrete
fill 10 287 521 15 287 521 minecraft:black_wool
fill 10 287 526 10 287 527 minecraft:black_wool
fill 10 287 528 10 287 534 minecraft:gray_wool
fill 10 287 535 10 287 536 minecraft:black_wool
fill 10 287 541 15 287 541 minecraft:black_wool
fill 10 287 542 10 287 543 minecraft:black_concrete
fill 11 287 518 11 287 519 minecraft:black_concrete
fill 11 287 520 18 287 520 minecraft:black_wool
fill 11 287 526 11 287 528 minecraft:gray_wool
fill 11 287 535 11 287 536 minecraft:gray_wool
fill 11 287 542 17 287 542 minecraft:black_wool
fill 11 287 543 11 287 544 minecraft:black_concrete
fill 12 287 517 13 287 518 minecraft:black_concrete
fill 12 287 519 30 287 519 minecraft:black_wool
fill 12 287 524 12 287 525 minecraft:gray_wool
fill 12 287 537 12 287 538 minecraft:gray_wool
fill 12 287 543 30 287 543 minecraft:black_wool
fill 12 287 544 13 287 545 minecraft:black_concrete
fill 13 287 522 14 287 522 minecraft:black_wool
fill 13 287 523 13 287 524 minecraft:gray_wool
setblock 13 287 539 minecraft:gray_wool
setblock 13 287 540 minecraft:black_wool
fill 14 287 516 15 287 517 minecraft:black_concrete
fill 14 287 518 28 287 518 minecraft:black_wool
setblock 14 287 523 minecraft:gray_wool
fill 14 287 540 15 287 540 minecraft:gray_wool
fill 14 287 544 28 287 544 minecraft:black_wool
fill 14 287 545 15 287 546 minecraft:black_concrete
fill 15 287 522 16 287 522 minecraft:gray_wool
fill 16 287 515 18 287 516 minecraft:black_concrete
fill 16 287 517 26 287 517 minecraft:black_wool
fill 16 287 521 20 287 521 minecraft:gray_wool
fill 16 287 541 17 287 541 minecraft:gray_wool
fill 16 287 545 26 287 545 minecraft:black_wool
fill 16 287 546 18 287 547 minecraft:black_concrete
fill 18 287 542 24 287 542 minecraft:gray_wool
fill 19 287 515 26 287 515 minecraft:black_concrete
fill 19 287 516 23 287 516 minecraft:black_wool
fill 19 287 520 23 287 520 minecraft:gray_wool
fill 19 287 546 23 287 546 minecraft:black_wool
fill 19 287 547 26 287 547 minecraft:black_concrete
fill 22 287 521 26 287 521 minecraft:gray_wool
fill 24 287 516 28 287 516 minecraft:black_concrete
fill 24 287 520 31 287 520 minecraft:black_wool
fill 24 287 546 28 287 546 minecraft:black_concrete
fill 25 287 541 26 287 541 minecraft:gray_wool
fill 25 287 542 31 287 542 minecraft:black_wool
fill 26 287 522 27 287 522 minecraft:gray_wool
fill 27 287 517 30 287 517 minecraft:black_concrete
fill 27 287 521 32 287 521 minecraft:black_wool
fill 27 287 523 29 287 523 minecraft:gray_wool
fill 27 287 540 28 287 540 minecraft:gray_wool
fill 27 287 541 32 287 541 minecraft:black_wool
fill 27 287 545 30 287 545 minecraft:black_concrete
fill 28 287 522 33 287 522 minecraft:black_wool
fill 28 287 539 29 287 539 minecraft:gray_wool
fill 29 287 518 31 287 518 minecraft:black_concrete
setblock 29 287 524 minecraft:gray_wool
fill 29 287 538 30 287 538 minecraft:gray_wool
fill 29 287 540 33 287 540 minecraft:black_wool
fill 29 287 544 31 287 544 minecraft:black_concrete
fill 30 287 523 33 287 524 minecraft:black_wool
fill 30 287 525 30 287 526 minecraft:gray_wool
setblock 30 287 537 minecraft:gray_wool
fill 30 287 539 33 287 539 minecraft:black_wool
fill 31 287 519 32 287 519 minecraft:black_concrete
fill 31 287 525 34 287 525 minecraft:black_wool
fill 31 287 526 31 287 529 minecraft:gray_wool
fill 31 287 534 31 287 536 minecraft:gray_wool
fill 31 287 537 34 287 538 minecraft:black_wool
fill 31 287 543 32 287 543 minecraft:black_concrete
fill 32 287 520 33 287 520 minecraft:black_concrete
fill 32 287 526 35 287 528 minecraft:black_wool
fill 32 287 529 32 287 534 minecraft:gray_wool
fill 32 287 535 35 287 536 minecraft:black_wool
fill 32 287 542 33 287 542 minecraft:black_concrete
fill 33 287 521 34 287 521 minecraft:black_concrete
fill 33 287 529 35 287 534 minecraft:black_wool
fill 33 287 541 34 287 541 minecraft:black_concrete
fill 34 287 522 35 287 523 minecraft:black_concrete
setblock 34 287 524 minecraft:black_wool
fill 34 287 539 35 287 540 minecraft:black_concrete
fill 35 287 524 36 287 525 minecraft:black_concrete
fill 35 287 537 36 287 538 minecraft:black_concrete
fill 36 287 526 37 287 528 minecraft:black_concrete
fill 36 287 529 36 287 533 minecraft:black_wool
fill 36 287 534 37 287 536 minecraft:black_concrete
setblock 37 287 510 minecraft:sea_lantern
fill 37 287 529 37 287 533 minecraft:black_concrete
fill 42 287 522 42 307 522 minecraft:black_concrete
fill 42 287 538 42 304 538 minecraft:black_concrete
fill 42 287 550 42 307 550 minecraft:black_concrete
fill 0 288 518 0 290 518 minecraft:cyan_concrete
fill 0 288 531 0 307 531 minecraft:black_concrete
fill 0 288 534 0 290 534 minecraft:cyan_concrete
fill 0 288 539 0 307 539 minecraft:black_concrete
setblock 0 288 541 minecraft:sea_lantern
fill 0 288 550 0 290 550 minecraft:cyan_concrete
fill 4 288 510 4 290 510 minecraft:cyan_concrete
fill 6 288 529 8 288 533 minecraft:black_concrete
fill 7 288 526 8 288 528 minecraft:black_concrete
fill 7 288 534 8 288 536 minecraft:black_concrete
fill 8 288 524 10 288 525 minecraft:black_concrete
fill 8 288 537 10 288 538 minecraft:black_concrete
fill 9 288 522 11 288 523 minecraft:black_concrete
fill 9 288 526 9 288 527 minecraft:black_concrete
fill 9 288 528 9 288 534 minecraft:gray_wool
fill 9 288 535 9 288 536 minecraft:black_concrete
fill 9 288 539 11 288 540 minecraft:black_concrete
fill 10 288 521 14 288 521 minecraft:black_concrete
fill 10 288 526 10 288 527 minecraft:gray_wool
fill 10 288 535 10 288 536 minecraft:gray_wool
fill 10 288 541 13 288 541 minecraft:black_concrete
fill 11 288 520 15 288 520 minecraft:black_concrete
fill 11 288 524 11 288 525 minecraft:gray_wool
fill 11 288 537 11 288 538 minecraft:gray_wool
fill 11 288 542 15 288 542 minecraft:black_concrete
fill 12 288 519 18 288 519 minecraft:black_concrete
setblock 12 288 522 minecraft:black_concrete
setblock 12 288 523 minecraft:gray_wool
setblock 12 288 539 minecraft:gray_wool
setblock 12 288 540 minecraft:black_concrete
fill 12 288 543 17 288 543 minecraft:black_concrete
fill 13 288 522 14 288 522 minecraft:gray_wool
setblock 13 288 540 minecraft:gray_wool
fill 14 288 518 28 288 518 minecraft:black_concrete
fill 14 288 541 15 288 541 minecraft:gray_wool
fill 14 288 544 28 288 544 minecraft:black_concrete
fill 14 288 552 14 290 552 minecraft:cyan_concrete
setblock 15 288 521 minecraft:gray_wool
fill 16 288 517 26 288 517 minecraft:black_concrete
fill 16 288 520 18 288 520 minecraft:gray_wool
fill 16 288 542 17 288 542 minecraft:gray_wool
fill 16 288 545 26 288 545 minecraft:black_concrete
fill 18 288 543 24 288 543 minecraft:gray_wool
setblock 19 288 510 minecraft:light_blue_stained_glass
fill 19 288 516 23 288 516 minecraft:black_concrete
fill 19 288 519 23 288 519 minecraft:gray_wool
fill 19 288 546 23 288 546 minecraft:black_concrete
fill 20 288 510 20 290 510 minecraft:cyan_concrete
fill 24 288 519 30 288 519 minecraft:black_concrete
fill 24 288 520 26 288 520 minecraft:gray_wool
fill 25 288 542 26 288 542 minecraft:gray_wool
fill 25 288 543 30 288 543 minecraft:black_concrete
fill 27 288 520 31 288 520 minecraft:black_concrete
setblock 27 288 521 minecraft:gray_wool
fill 27 288 541 28 288 541 minecraft:gray_wool
fill 27 288 542 31 288 542 minecraft:black_concrete
fill 28 288 521 32 288 521 minecraft:black_concrete
fill 28 288 522 29 288 522 minecraft:gray_wool
setblock 29 288 540 minecraft:gray_wool
fill 29 288 541 32 288 541 minecraft:black_concrete
setblock 30 288 510 minecraft:white_concrete
fill 30 288 522 33 288 522 minecraft:black_concrete
fill 30 288 523 30 288 524 minecraft:gray_wool
setblock 30 288 539 minecraft:gray_wool
fill 30 288 540 33 288 540 minecraft:black_concrete
fill 30 288 552 30 290 552 minecraft:cyan_concrete
fill 31 288 523 33 288 524 minecraft:black_concrete
setblock 31 288 525 minecraft:gray_wool
fill 31 288 537 31 288 538 minecraft:gray_wool
fill 31 288 539 33 288 539 minecraft:black_concrete
fill 32 288 525 34 288 525 minecraft:black_concrete
fill 32 288 526 32 288 528 minecraft:gray_wool
fill 32 288 535 32 288 536 minecraft:gray_wool
fill 32 288 537 34 288 538 minecraft:black_concrete
fill 33 288 526 35 288 528 minecraft:black_concrete
fill 33 288 529 33 288 534 minecraft:gray_wool
fill 33 288 535 35 288 536 minecraft:black_concrete
setblock 34 288 524 minecraft:black_concrete
fill 34 288 529 35 288 534 minecraft:black_concrete
setblock 34 288 552 minecraft:light_blue_stained_glass
fill 36 288 510 36 290 510 minecraft:cyan_concrete
fill 36 288 529 36 288 533 minecraft:black_concrete
fill 37 288 510 37 307 510 minecraft:black_concrete
fill 42 288 520 42 290 520 minecraft:cyan_concrete
fill 42 288 536 42 290 536 minecraft:cyan_concrete
fill 0 289 541 0 305 541 minecraft:black_concrete
fill 3 289 543 5 292 545 minecraft:light_blue_stained_glass
fill 19 289 510 19 307 510 minecraft:black_concrete
fill 30 289 510 30 302 510 minecraft:black_concrete
setblock 33 289 510 minecraft:sea_lantern
fill 34 289 552 34 307 552 minecraft:black_concrete
setblock 41 289 510 minecraft:sea_lantern
setblock 0 290 542 minecraft:sea_lantern
setblock 21 290 510 minecraft:light_blue_stained_glass
setblock 29 290 510 minecraft:white_concrete
fill 33 290 510 33 307 510 minecraft:black_concrete
fill 41 290 510 41 297 510 minecraft:black_concrete
fill 0 291 518 0 296 518 minecraft:black_concrete
fill 0 291 534 0 296 534 minecraft:black_concrete
fill 0 291 542 0 307 542 minecraft:black_concrete
fill 0 291 550 0 296 550 minecraft:black_concrete
setblock 3 291 513 minecraft:light[level=11]
setblock 3 291 521 minecraft:light[level=11]
setblock 3 291 529 minecraft:light[level=11]
setblock 3 291 537 minecraft:light[level=11]
fill 4 291 510 4 296 510 minecraft:black_concrete
setblock 11 291 513 minecraft:light[level=11]
setblock 11 291 521 minecraft:light[level=11]
setblock 11 291 529 minecraft:light[level=11]
setblock 11 291 537 minecraft:light[level=11]
setblock 11 291 545 minecraft:light[level=11]
fill 14 291 552 14 296 552 minecraft:black_concrete
setblock 19 291 513 minecraft:light[level=11]
setblock 19 291 521 minecraft:light[level=11]
setblock 19 291 529 minecraft:light[level=11]
setblock 19 291 537 minecraft:light[level=11]
setblock 19 291 545 minecraft:light[level=11]
fill 20 291 510 21 296 510 minecraft:black_concrete
setblock 27 291 513 minecraft:light[level=11]
setblock 27 291 521 minecraft:light[level=11]
setblock 27 291 529 minecraft:light[level=11]
setblock 27 291 537 minecraft:light[level=11]
setblock 27 291 545 minecraft:light[level=11]
fill 29 291 510 29 307 510 minecraft:black_concrete
fill 30 291 552 30 296 552 minecraft:black_concrete
setblock 35 291 513 minecraft:light[level=11]
setblock 35 291 521 minecraft:light[level=11]
setblock 35 291 529 minecraft:light[level=11]
setblock 35 291 537 minecraft:light[level=11]
setblock 35 291 545 minecraft:light[level=11]
fill 36 291 510 36 296 510 minecraft:black_concrete
setblock 36 291 552 minecraft:sea_lantern
setblock 40 291 552 minecraft:light_blue_stained_glass
fill 42 291 520 42 296 520 minecraft:black_concrete
fill 42 291 536 42 296 536 minecraft:black_concrete
fill 22 292 552 23 302 552 minecraft:black_concrete
setblock 24 292 552 minecraft:light_blue_stained_glass
fill 36 292 552 36 301 552 minecraft:black_concrete
setblock 40 292 552 minecraft:white_concrete
setblock 0 293 520 minecraft:white_concrete
fill 24 293 552 24 307 552 minecraft:black_concrete
fill 40 293 552 40 307 552 minecraft:black_concrete
fill 0 294 520 0 307 520 minecraft:black_concrete
setblock 24 294 510 minecraft:sea_lantern
fill 26 294 545 27 295 546 minecraft:cyan_stained_glass
setblock 42 294 523 minecraft:sea_lantern
setblock 42 294 545 minecraft:sea_lantern
fill 8 295 552 8 307 552 minecraft:black_concrete
setblock 9 295 552 minecraft:light_blue_stained_glass
fill 24 295 510 24 307 510 minecraft:black_concrete
fill 42 295 523 42 307 523 minecraft:black_concrete
setblock 42 295 539 minecraft:sea_lantern
fill 42 295 545 42 307 545 minecraft:black_concrete
setblock 2 296 552 minecraft:light_blue_stained_glass
fill 9 296 552 9 307 552 minecraft:black_concrete
setblock 32 296 552 minecraft:light_blue_stained_glass
setblock 42 296 539 minecraft:black_concrete
fill 0 297 518 0 299 518 minecraft:cyan_concrete
fill 0 297 534 0 299 534 minecraft:cyan_concrete
fill 0 297 550 0 299 550 minecraft:cyan_concrete
fill 2 297 552 2 307 552 minecraft:black_concrete
fill 4 297 510 4 299 510 minecraft:cyan_concrete
fill 14 297 552 14 299 552 minecraft:cyan_concrete
fill 20 297 510 20 299 510 minecraft:cyan_concrete
fill 21 297 510 21 307 510 minecraft:black_concrete
fill 27 297 516 28 298 517 minecraft:cyan_stained_glass
fill 28 297 518 28 298 518 minecraft:cyan_stained_glass
fill 30 297 552 30 299 552 minecraft:cyan_concrete
fill 32 297 552 32 298 552 minecraft:black_concrete
fill 36 297 510 36 299 510 minecraft:cyan_concrete
fill 42 297 520 42 299 520 minecraft:cyan_concrete
fill 42 297 536 42 299 536 minecraft:cyan_concrete
setblock 42 297 539 minecraft:light_blue_stained_glass
setblock 0 298 551 minecraft:white_concrete
setblock 35 298 510 minecraft:white_concrete
setblock 41 298 510 minecraft:white_concrete
setblock 42 298 521 minecraft:white_concrete
fill 42 298 539 42 299 539 minecraft:black_concrete
setblock 0 299 538 minecraft:white_concrete
fill 0 299 551 0 307 551 minecraft:black_concrete
setblock 2 299 510 minecraft:white_concrete
setblock 3 299 513 minecraft:light[level=11]
setblock 3 299 521 minecraft:light[level=11]
setblock 3 299 529 minecraft:light[level=11]
setblock 3 299 537 minecraft:light[level=11]
setblock 3 299 545 minecraft:light[level=11]
setblock 11 299 513 minecraft:light[level=11]
setblock 11 299 521 minecraft:light[level=11]
setblock 11 299 529 minecraft:light[level=11]
setblock 11 299 537 minecraft:light[level=11]
setblock 11 299 545 minecraft:light[level=11]
setblock 14 299 510 minecraft:white_concrete
setblock 19 299 513 minecraft:light[level=11]
setblock 19 299 521 minecraft:light[level=11]
setblock 19 299 529 minecraft:light[level=11]
setblock 19 299 537 minecraft:light[level=11]
setblock 19 299 545 minecraft:light[level=11]
setblock 27 299 513 minecraft:light[level=11]
setblock 27 299 521 minecraft:light[level=11]
setblock 27 299 529 minecraft:light[level=11]
setblock 27 299 537 minecraft:light[level=11]
setblock 27 299 545 minecraft:light[level=11]
setblock 32 299 552 minecraft:white_concrete
fill 35 299 510 35 307 510 minecraft:black_concrete
setblock 35 299 513 minecraft:light[level=11]
setblock 35 299 521 minecraft:light[level=11]
setblock 35 299 529 minecraft:light[level=11]
setblock 35 299 537 minecraft:light[level=11]
setblock 35 299 545 minecraft:light[level=11]
fill 41 299 510 41 307 510 minecraft:black_concrete
fill 42 299 521 42 307 521 minecraft:black_concrete
fill 0 300 518 0 307 518 minecraft:black_concrete
setblock 0 300 521 minecraft:white_concrete
fill 0 300 534 0 307 534 minecraft:black_concrete
fill 0 300 538 0 307 538 minecraft:black_concrete
fill 0 300 550 0 307 550 minecraft:black_concrete
fill 2 300 510 2 307 510 minecraft:black_concrete
setblock 4 300 510 minecraft:white_concrete
fill 14 300 510 14 304 510 minecraft:black_concrete
fill 14 300 552 14 307 552 minecraft:black_concrete
setblock 15 300 552 minecraft:light_blue_stained_glass
setblock 17 300 552 minecraft:white_concrete
fill 20 300 510 20 305 510 minecraft:black_concrete
fill 30 300 552 30 307 552 minecraft:black_concrete
fill 32 300 552 32 307 552 minecraft:black_concrete
fill 36 300 510 36 307 510 minecraft:black_concrete
fill 42 300 520 42 307 520 minecraft:black_concrete
setblock 42 300 534 minecraft:sea_lantern
fill 42 300 536 42 307 536 minecraft:black_concrete
setblock 42 300 539 minecraft:sea_lantern
setblock 42 300 542 minecraft:sea_lantern
fill 0 301 521 0 307 521 minecraft:black_concrete
fill 4 301 510 4 307 510 minecraft:black_concrete
fill 15 301 552 15 307 552 minecraft:black_concrete
fill 17 301 552 17 307 552 minecraft:black_concrete
setblock 42 301 511 minecraft:light_blue_stained_glass
fill 42 301 534 42 302 534 minecraft:black_concrete
setblock 42 301 539 minecraft:black_concrete
fill 42 301 542 42 307 542 minecraft:black_concrete
setblock 0 302 547 minecraft:light_blue_stained_glass
setblock 36 302 552 minecraft:light_blue_stained_glass
fill 42 302 511 42 307 511 minecraft:black_concrete
setblock 42 302 539 minecraft:sea_lantern
setblock 42 302 547 minecraft:white_concrete
setblock 0 303 516 minecraft:sea_lantern
fill 0 303 547 0 307 547 minecraft:black_concrete
setblock 11 303 510 minecraft:white_concrete
setblock 20 303 552 minecraft:light_blue_stained_glass
setblock 22 303 552 minecraft:sea_lantern
fill 23 303 552 23 307 552 minecraft:black_concrete
setblock 28 303 510 minecraft:light_blue_stained_glass
setblock 30 303 510 minecraft:sea_lantern
setblock 36 303 552 minecraft:black_concrete
setblock 42 303 534 minecraft:light_blue_stained_glass
fill 42 303 539 42 307 539 minecraft:black_concrete
fill 42 303 547 42 307 547 minecraft:black_concrete
fill 0 304 516 0 307 516 minecraft:black_concrete
setblock 0 304 540 minecraft:light_blue_stained_glass
fill 11 304 510 11 307 510 minecraft:black_concrete
fill 20 304 552 20 307 552 minecraft:black_concrete
fill 22 304 552 22 307 552 minecraft:black_concrete
fill 28 304 510 28 307 510 minecraft:black_concrete
fill 30 304 510 30 307 510 minecraft:black_concrete
setblock 36 304 552 minecraft:white_concrete
fill 42 304 534 42 307 534 minecraft:black_concrete
fill 0 305 540 0 307 540 minecraft:black_concrete
setblock 14 305 510 minecraft:sea_lantern
fill 36 305 552 36 307 552 minecraft:black_concrete
setblock 42 305 514 minecraft:sea_lantern
setblock 42 305 527 minecraft:light_blue_stained_glass
setblock 42 305 538 minecraft:light_blue_stained_glass
setblock 42 305 551 minecraft:light_blue_stained_glass
setblock 0 306 541 minecraft:white_concrete
fill 14 306 510 14 307 510 minecraft:black_concrete
setblock 20 306 510 minecraft:sea_lantern
setblock 40 306 510 minecraft:sea_lantern
fill 42 306 514 42 307 514 minecraft:black_concrete
fill 42 306 527 42 307 527 minecraft:black_concrete
fill 42 306 538 42 307 538 minecraft:black_concrete
setblock 42 306 544 minecraft:sea_lantern
fill 42 306 551 42 307 551 minecraft:black_concrete
setblock 0 307 541 minecraft:black_concrete
setblock 10 307 510 minecraft:sea_lantern
setblock 20 307 510 minecraft:black_concrete
setblock 32 307 510 minecraft:white_concrete
setblock 40 307 510 minecraft:black_concrete
setblock 42 307 544 minecraft:black_concrete
