fill 136 50 276 136 51 276 minecraft:white_concrete
fill 136 50 277 136 51 278 minecraft:red_concrete
fill 136 50 279 136 51 279 minecraft:white_concrete
fill 136 50 281 136 51 282 minecraft:red_concrete
fill 136 50 283 136 51 284 minecraft:white_concrete
fill 136 50 285 136 51 286 minecraft:red_concrete
fill 136 50 287 136 51 287 minecraft:white_concrete
fill 136 50 289 136 51 290 minecraft:red_concrete
fill 136 50 291 136 51 292 minecraft:white_concrete
fill 136 50 293 136 51 294 minecraft:red_concrete
fill 136 50 295 136 51 295 minecraft:white_concrete
fill 136 50 297 136 51 298 minecraft:red_concrete
fill 136 50 299 136 51 300 minecraft:white_concrete
fill 136 50 301 136 51 302 minecraft:red_concrete
fill 136 50 303 136 51 303 minecraft:white_concrete
fill 136 50 305 136 51 306 minecraft:red_concrete
fill 136 50 307 136 51 308 minecraft:white_concrete
fill 136 50 309 136 51 310 minecraft:red_concrete
fill 136 50 311 136 51 311 minecraft:white_concrete
fill 136 50 313 136 51 314 minecraft:red_concrete
fill 136 50 315 136 51 316 minecraft:white_concrete
fill 136 50 317 136 51 317 minecraft:red_concrete
setblock 97 51 278 minecraft:light[level=12]
setblock 97 51 285 minecraft:light[level=12]
setblock 97 51 292 minecraft:light[level=12]
setblock 97 51 299 minecraft:light[level=12]
setblock 97 51 306 minecraft:light[level=12]
setblock 97 51 313 minecraft:light[level=12]
fill 103 51 310 111 51 310 minecraft:yellow_concrete
setblock 104 51 278 minecraft:light[level=12]
setblock 104 51 285 minecraft:light[level=12]
setblock 104 51 292 minecraft:light[level=12]
setblock 104 51 299 minecraft:light[level=12]
setblock 104 51 306 minecraft:light[level=12]
setblock 104 51 313 minecraft:light[level=12]
fill 106 51 316 108 54 316 minecraft:shroomlight
setblock 111 51 278 minecraft:light[level=12]
setblock 111 51 285 minecraft:light[level=12]
setblock 111 51 292 minecraft:light[level=12]
setblock 111 51 299 minecraft:light[level=12]
setblock 111 51 306 minecraft:light[level=12]
setblock 111 51 313 minecraft:light[level=12]
setblock 118 51 278 minecraft:light[level=12]
setblock 118 51 285 minecraft:light[level=12]
setblock 118 51 299 minecraft:light[level=12]
setblock 118 51 306 minecraft:light[level=12]
setblock 118 51 313 minecraft:light[level=12]
setblock 125 51 278 minecraft:light[level=12]
setblock 125 51 285 minecraft:light[level=12]
setblock 125 51 292 minecraft:light[level=12]
setblock 125 51 299 minecraft:light[level=12]
setblock 125 51 306 minecraft:light[level=12]
setblock 125 51 313 minecraft:light[level=12]
setblock 132 51 278 minecraft:light[level=12]
setblock 132 51 285 minecraft:light[level=12]
setblock 132 51 292 minecraft:light[level=12]
setblock 132 51 299 minecraft:light[level=12]
setblock 132 51 306 minecraft:light[level=12]
setblock 132 51 313 minecraft:light[level=12]
fill 94 52 275 94 53 276 minecraft:red_concrete
fill 94 52 277 94 53 278 minecraft:white_concrete
fill 94 52 279 94 53 280 minecraft:red_concrete
fill 94 52 281 94 53 282 minecraft:white_concrete
fill 94 52 283 94 53 284 minecraft:red_concrete
fill 94 52 285 94 53 286 minecraft:white_concrete
fill 94 52 287 94 53 288 minecraft:red_concrete
fill 94 52 289 94 53 290 minecraft:white_concrete
fill 94 52 291 94 53 292 minecraft:red_concrete
fill 94 52 293 94 53 294 minecraft:white_concrete
fill 94 52 295 94 53 296 minecraft:red_concrete
fill 94 52 297 94 53 298 minecraft:white_concrete
fill 94 52 299 94 53 300 minecraft:red_concrete
fill 94 52 301 94 53 302 minecraft:white_concrete
fill 94 52 303 94 53 304 minecraft:red_concrete
fill 94 52 305 94 53 306 minecraft:white_concrete
fill 94 52 307 94 53 308 minecraft:red_concrete
fill 94 52 309 94 53 310 minecraft:white_concrete
fill 94 52 311 94 53 312 minecraft:red_concrete
fill 94 52 313 94 53 314 minecraft:white_concrete
fill 94 52 315 94 53 316 minecraft:red_concrete
fill 95 52 275 95 53 275 minecraft:red_concrete
fill 95 52 317 95 53 317 minecraft:red_concrete
fill 96 52 275 97 53 275 minecraft:white_concrete
fill 96 52 317 97 53 317 minecraft:white_concrete
fill 98 52 275 99 53 275 minecraft:red_concrete
fill 98 52 317 99 53 317 minecraft:red_concrete
fill 100 52 275 101 53 275 minecraft:white_concrete
fill 100 52 317 101 53 317 minecraft:white_concrete
fill 102 52 275 103 53 275 minecraft:red_concrete
fill 102 52 317 103 53 317 minecraft:red_concrete
setblock 103 52 310 minecraft:red_terracotta
fill 104 52 275 105 53 275 minecraft:white_concrete
fill 104 52 317 105 53 317 minecraft:white_concrete
fill 106 52 275 107 53 275 minecraft:red_concrete
fill 106 52 317 107 53 317 minecraft:red_concrete
setblock 107 52 310 minecraft:red_terracotta
fill 108 52 275 109 53 275 minecraft:white_concrete
fill 108 52 317 109 53 317 minecraft:white_concrete
fill 110 52 275 111 53 275 minecraft:red_concrete
fill 110 52 317 111 53 317 minecraft:red_concrete
setblock 111 52 310 minecraft:red_terracotta
fill 112 52 275 113 53 275 minecraft:white_concrete
fill 112 52 317 113 53 317 minecraft:white_concrete
fill 114 52 275 115 53 275 minecraft:red_concrete
fill 114 52 317 115 53 317 minecraft:red_concrete
fill 116 52 275 117 53 275 minecraft:white_concrete
fill 116 52 317 117 53 317 minecraft:white_concrete
fill 118 52 275 119 53 275 minecraft:red_concrete
fill 118 52 317 119 53 317 minecraft:red_concrete
fill 120 52 275 121 53 275 minecraft:white_concrete
fill 120 52 317 121 53 317 minecraft:white_concrete
fill 122 52 275 123 53 275 minecraft:red_concrete
fill 122 52 317 123 53 317 minecraft:red_concrete
fill 124 52 275 125 53 275 minecraft:white_concrete
fill 124 52 317 125 53 317 minecraft:white_concrete
fill 126 52 275 127 53 275 minecraft:red_concrete
fill 126 52 317 127 53 317 minecraft:red_concrete
fill 128 52 275 129 53 275 minecraft:white_concrete
fill 128 52 317 129 53 317 minecraft:white_concrete
fill 130 52 275 131 53 275 minecraft:red_concrete
setblock 130 52 306 minecraft:red_terracotta
setblock 130 52 308 minecraft:red_terracotta
fill 130 52 317 131 53 317 minecraft:red_concrete
fill 131 52 285 131 52 287 minecraft:red_terracotta
fill 132 52 275 133 53 275 minecraft:white_concrete
fill 132 52 285 133 52 285 minecraft:red_terracotta
fill 132 52 287 133 52 287 minecraft:red_terracotta
setblock 132 52 306 minecraft:red_terracotta
setblock 132 52 308 minecraft:red_terracotta
fill 132 52 317 133 53 317 minecraft:white_concrete
setblock 133 52 286 minecraft:red_terracotta
fill 134 52 275 135 53 275 minecraft:red_concrete
fill 134 52 317 135 53 317 minecraft:red_concrete
fill 136 52 276 136 53 276 minecraft:red_concrete
fill 136 52 277 136 53 278 minecraft:white_concrete
fill 136 52 279 136 53 280 minecraft:red_concrete
fill 136 52 281 136 53 282 minecraft:white_concrete
fill 136 52 283 136 53 284 minecraft:red_concrete
fill 136 52 285 136 53 286 minecraft:white_concrete
fill 136 52 287 136 53 288 minecraft:red_concrete
fill 136 52 289 136 53 290 minecraft:white_concrete
fill 136 52 291 136 53 292 minecraft:red_concrete
fill 136 52 293 136 53 294 minecraft:white_concrete
fill 136 52 295 136 53 296 minecraft:red_concrete
fill 136 52 297 136 53 298 minecraft:white_concrete
fill 136 52 299 136 53 300 minecraft:red_concrete
fill 136 52 301 136 53 302 minecraft:white_concrete
fill 136 52 303 136 53 304 minecraft:red_concrete
fill 136 52 305 136 53 306 minecraft:white_concrete
fill 136 52 307 136 53 308 minecraft:red_concrete
fill 136 52 309 136 53 310 minecraft:white_concrete
fill 136 52 311 136 53 312 minecraft:red_concrete
fill 136 52 313 136 53 314 minecraft:white_concrete
fill 136 52 315 136 53 316 minecraft:red_concrete
fill 136 52 317 136 53 317 minecraft:white_concrete
setblock 97 53 278 minecraft:light[level=15]
setblock 97 53 286 minecraft:light[level=15]
setblock 97 53 294 minecraft:light[level=15]
setblock 97 53 302 minecraft:light[level=15]
setblock 97 53 310 minecraft:light[level=15]
fill 100 53 287 100 54 288 minecraft:yellow_wool
setblock 105 53 278 minecraft:light[level=15]
setblock 105 53 286 minecraft:light[level=15]
setblock 105 53 294 minecraft:light[level=15]
setblock 105 53 302 minecraft:light[level=15]
setblock 105 53 310 minecraft:light[level=15]
setblock 113 53 278 minecraft:light[level=15]
setblock 113 53 286 minecraft:light[level=15]
setblock 113 53 294 minecraft:light[level=15]
setblock 113 53 302 minecraft:light[level=15]
setblock 113 53 310 minecraft:light[level=15]
setblock 121 53 278 minecraft:light[level=15]
setblock 121 53 286 minecraft:light[level=15]
setblock 121 53 294 minecraft:light[level=15]
setblock 121 53 302 minecraft:light[level=15]
setblock 121 53 310 minecraft:light[level=15]
setblock 129 53 278 minecraft:light[level=15]
setblock 129 53 286 minecraft:light[level=15]
setblock 129 53 294 minecraft:light[level=15]
setblock 129 53 302 minecraft:light[level=15]
setblock 129 53 310 minecraft:light[level=15]
fill 94 54 275 94 55 276 minecraft:white_concrete
fill 94 54 277 94 55 278 minecraft:red_concrete
fill 94 54 279 94 55 280 minecraft:white_concrete
fill 94 54 281 94 55 282 minecraft:red_concrete
fill 94 54 283 94 55 284 minecraft:white_concrete
fill 94 54 285 94 55 286 minecraft:red_concrete
fill 94 54 287 94 55 288 minecraft:white_concrete
fill 94 54 289 94 55 290 minecraft:red_concrete
fill 94 54 291 94 55 292 minecraft:white_concrete
fill 94 54 293 94 55 294 minecraft:red_concrete
fill 94 54 295 94 55 296 minecraft:white_concrete
fill 94 54 297 94 55 298 minecraft:red_concrete
fill 94 54 299 94 55 300 minecraft:white_concrete
fill 94 54 301 94 55 302 minecraft:red_concrete
fill 94 54 303 94 55 304 minecraft:white_concrete
fill 94 54 305 94 55 306 minecraft:red_concrete
fill 94 54 307 94 55 308 minecraft:white_concrete
fill 94 54 309 94 55 310 minecraft:red_concrete
fill 94 54 311 94 55 312 minecraft:white_concrete
fill 94 54 313 94 55 314 minecraft:red_concrete
fill 94 54 315 94 55 316 minecraft:white_concrete
fill 95 54 275 95 55 275 minecraft:white_concrete
fill 95 54 317 95 55 317 minecraft:white_concrete
fill 96 54 275 97 55 275 minecraft:red_concrete
fill 96 54 317 97 55 317 minecraft:red_concrete
fill 98 54 275 99 55 275 minecraft:white_concrete
fill 98 54 317 99 55 317 minecraft:white_concrete
fill 100 54 275 101 55 275 minecraft:red_concrete
fill 100 54 317 101 55 317 minecraft:red_concrete
fill 102 54 275 103 55 275 minecraft:white_concrete
fill 102 54 317 103 55 317 minecraft:white_concrete
fill 104 54 275 105 55 275 minecraft:red_concrete
fill 104 54 317 105 55 317 minecraft:red_concrete
fill 106 54 275 107 55 275 minecraft:white_concrete
fill 106 54 317 107 55 317 minecraft:white_concrete
fill 108 54 275 109 55 275 minecraft:red_concrete
fill 108 54 317 109 55 317 minecraft:red_concrete
fill 110 54 275 111 55 275 minecraft:white_concrete
fill 110 54 317 111 55 317 minecraft:white_concrete
fill 112 54 275 113 55 275 minecraft:red_concrete
fill 112 54 317 113 55 317 minecraft:red_concrete
fill 114 54 275 115 55 275 minecraft:white_concrete
fill 114 54 317 115 55 317 minecraft:white_concrete
fill 116 54 275 117 55 275 minecraft:red_concrete
fill 116 54 317 117 55 317 minecraft:red_concrete
fill 118 54 275 119 55 275 minecraft:white_concrete
fill 118 54 317 119 55 317 minecraft:white_concrete
fill 120 54 275 121 55 275 minecraft:red_concrete
fill 120 54 317 121 55 317 minecraft:red_concrete
fill 122 54 275 123 55 275 minecraft:white_concrete
fill 122 54 317 123 55 317 minecraft:white_concrete
fill 124 54 275 125 55 275 minecraft:red_concrete
fill 124 54 317 125 55 317 minecraft:red_concrete
fill 126 54 275 127 55 275 minecraft:white_concrete
fill 126 54 317 127 55 317 minecraft:white_concrete
fill 128 54 275 129 55 275 minecraft:red_concrete
fill 128 54 317 129 55 317 minecraft:red_concrete
fill 130 54 275 131 55 275 minecraft:white_concrete
fill 130 54 317 131 55 317 minecraft:white_concrete
fill 132 54 275 133 55 275 minecraft:red_concrete
fill 132 54 317 133 55 317 minecraft:red_concrete
fill 134 54 275 135 55 275 minecraft:white_concrete
fill 134 54 317 135 55 317 minecraft:white_concrete
fill 136 54 276 136 55 276 minecraft:white_concrete
fill 136 54 277 136 55 278 minecraft:red_concrete
fill 136 54 279 136 55 280 minecraft:white_concrete
fill 136 54 281 136 55 282 minecraft:red_concrete
fill 136 54 283 136 55 284 minecraft:white_concrete
fill 136 54 285 136 55 286 minecraft:red_concrete
fill 136 54 287 136 55 288 minecraft:white_concrete
fill 136 54 289 136 55 290 minecraft:red_concrete
fill 136 54 291 136 55 292 minecraft:white_concrete
fill 136 54 293 136 55 294 minecraft:red_concrete
fill 136 54 295 136 55 296 minecraft:white_concrete
fill 136 54 297 136 55 298 minecraft:red_concrete
fill 136 54 299 136 55 300 minecraft:white_concrete
fill 136 54 301 136 55 302 minecraft:red_concrete
fill 136 54 303 136 55 304 minecraft:white_concrete
fill 136 54 305 136 55 306 minecraft:red_concrete
fill 136 54 307 136 55 308 minecraft:white_concrete
fill 136 54 309 136 55 310 minecraft:red_concrete
fill 136 54 311 136 55 312 minecraft:white_concrete
fill 136 54 313 136 55 314 minecraft:red_concrete
fill 136 54 315 136 55 316 minecraft:white_concrete
fill 136 54 317 136 55 317 minecraft:red_concrete
fill 128 55 301 129 56 302 minecraft:red_concrete
fill 94 56 275 94 57 276 minecraft:red_concrete
fill 94 56 277 94 57 278 minecraft:white_concrete
fill 94 56 279 94 57 280 minecraft:red_concrete
fill 94 56 281 94 57 282 minecraft:white_concrete
fill 94 56 283 94 57 284 minecraft:red_concrete
fill 94 56 285 94 57 286 minecraft:white_concrete
fill 94 56 287 94 57 288 minecraft:red_concrete
fill 94 56 289 94 57 290 minecraft:white_concrete
fill 94 56 291 94 57 292 minecraft:red_concrete
fill 94 56 293 94 57 294 minecraft:white_concrete
fill 94 56 295 94 57 296 minecraft:red_concrete
fill 94 56 297 94 57 298 minecraft:white_concrete
fill 94 56 299 94 57 300 minecraft:red_concrete
fill 94 56 301 94 57 302 minecraft:white_concrete
fill 94 56 303 94 57 304 minecraft:red_concrete
fill 94 56 305 94 57 306 minecraft:white_concrete
fill 94 56 307 94 57 308 minecraft:red_concrete
fill 94 56 309 94 57 310 minecraft:white_concrete
fill 94 56 311 94 57 312 minecraft:red_concrete
fill 94 56 313 94 57 314 minecraft:white_concrete
fill 94 56 315 94 57 316 minecraft:red_concrete
fill 95 56 275 95 57 275 minecraft:red_concrete
fill 95 56 276 95 57 281 minecraft:red_terracotta
fill 95 56 284 96 56 289 minecraft:red_terracotta
fill 95 56 292 96 56 297 minecraft:red_terracotta
fill 95 56 300 96 56 305 minecraft:red_terracotta
fill 95 56 308 96 56 313 minecraft:red_terracotta
fill 95 56 316 100 57 316 minecraft:red_terracotta
fill 95 56 317 95 57 317 minecraft:red_concrete
fill 96 56 275 97 57 275 minecraft:white_concrete
fill 96 56 277 96 56 283 minecraft:red_terracotta
fill 96 56 290 96 56 291 minecraft:red_terracotta
fill 96 56 298 96 56 299 minecraft:red_terracotta
fill 96 56 306 96 56 307 minecraft:red_terracotta
fill 96 56 314 96 56 315 minecraft:red_terracotta
fill 96 56 317 97 57 317 minecraft:white_concrete
fill 97 56 277 134 56 277 minecraft:red_terracotta
fill 97 56 315 135 56 315 minecraft:red_terracotta
fill 98 56 275 99 57 275 minecraft:red_concrete
fill 98 56 276 103 57 276 minecraft:red_terracotta
fill 98 56 317 99 57 317 minecraft:red_concrete
fill 100 56 275 101 57 275 minecraft:white_concrete
fill 100 56 317 101 57 317 minecraft:white_concrete
fill 102 56 275 103 57 275 minecraft:red_concrete
fill 102 56 317 103 57 317 minecraft:red_concrete
fill 103 56 316 108 57 316 minecraft:red_terracotta
fill 104 56 275 105 57 275 minecraft:white_concrete
fill 104 56 317 105 57 317 minecraft:white_concrete
fill 106 56 275 107 57 275 minecraft:red_concrete
fill 106 56 276 111 57 276 minecraft:red_terracotta
fill 106 56 317 107 57 317 minecraft:red_concrete
fill 108 56 275 109 57 275 minecraft:white_concrete
fill 108 56 317 109 57 317 minecraft:white_concrete
fill 110 56 275 111 57 275 minecraft:red_concrete
fill 110 56 317 111 57 317 minecraft:red_concrete
fill 111 56 316 116 57 316 minecraft:red_terracotta
fill 112 56 275 113 57 275 minecraft:white_concrete
fill 112 56 317 113 57 317 minecraft:white_concrete
fill 114 56 275 115 57 275 minecraft:red_concrete
fill 114 56 276 119 57 276 minecraft:red_terracotta
fill 114 56 317 115 57 317 minecraft:red_concrete
fill 116 56 275 117 57 275 minecraft:white_concrete
fill 116 56 317 117 57 317 minecraft:white_concrete
fill 118 56 275 119 57 275 minecraft:red_concrete
fill 118 56 317 119 57 317 minecraft:red_concrete
fill 119 56 316 124 57 316 minecraft:red_terracotta
fill 120 56 275 121 57 275 minecraft:white_concrete
fill 120 56 317 121 57 317 minecraft:white_concrete
fill 122 56 275 123 57 275 minecraft:red_concrete
fill 122 56 276 127 57 276 minecraft:red_terracotta
fill 122 56 317 123 57 317 minecraft:red_concrete
fill 124 56 275 125 57 275 minecraft:white_concrete
fill 124 56 317 125 57 317 minecraft:white_concrete
fill 126 56 275 127 57 275 minecraft:red_concrete
fill 126 56 317 127 57 317 minecraft:red_concrete
fill 127 56 309 127 57 309 minecraft:brown_terracotta
fill 127 56 316 132 57 316 minecraft:red_terracotta
fill 128 56 275 129 57 275 minecraft:white_concrete
fill 128 56 317 129 57 317 minecraft:white_concrete
fill 130 56 275 131 57 275 minecraft:red_concrete
fill 130 56 276 135 57 276 minecraft:red_terracotta
fill 130 56 317 131 57 317 minecraft:red_concrete
fill 132 56 275 133 57 275 minecraft:white_concrete
fill 132 56 317 133 57 317 minecraft:white_concrete
fill 134 56 275 135 57 275 minecraft:red_concrete
fill 134 56 278 134 56 314 minecraft:red_terracotta
fill 134 56 317 135 57 317 minecraft:red_concrete
fill 135 56 279 135 57 284 minecraft:red_terracotta
fill 135 56 287 135 57 292 minecraft:red_terracotta
fill 135 56 295 135 57 300 minecraft:red_terracotta
fill 135 56 303 135 57 308 minecraft:red_terracotta
fill 135 56 311 135 57 314 minecraft:red_terracotta
fill 135 56 316 135 57 316 minecraft:red_terracotta
fill 136 56 276 136 57 276 minecraft:red_concrete
fill 136 56 277 136 57 278 minecraft:white_concrete
fill 136 56 279 136 57 280 minecraft:red_concrete
fill 136 56 281 136 57 282 minecraft:white_concrete
fill 136 56 283 136 57 284 minecraft:red_concrete
fill 136 56 285 136 57 286 minecraft:white_concrete
fill 136 56 287 136 57 288 minecraft:red_concrete
fill 136 56 289 136 57 290 minecraft:white_concrete
fill 136 56 291 136 57 292 minecraft:red_concrete
fill 136 56 293 136 57 294 minecraft:white_concrete
fill 136 56 295 136 57 296 minecraft:red_concrete
fill 136 56 297 136 57 298 minecraft:white_concrete
fill 136 56 299 136 57 300 minecraft:red_concrete
fill 136 56 301 136 57 302 minecraft:white_concrete
fill 136 56 303 136 57 304 minecraft:red_concrete
fill 136 56 305 136 57 306 minecraft:white_concrete
fill 136 56 307 136 57 308 minecraft:red_concrete
fill 136 56 309 136 57 310 minecraft:white_concrete
fill 136 56 311 136 57 312 minecraft:red_concrete
fill 136 56 313 136 57 314 minecraft:white_concrete
fill 136 56 315 136 57 316 minecraft:red_concrete
fill 136 56 317 136 57 317 minecraft:white_concrete
fill 95 57 284 95 57 289 minecraft:red_terracotta
fill 95 57 292 95 57 297 minecraft:red_terracotta
fill 95 57 300 95 57 305 minecraft:red_terracotta
fill 95 57 308 95 57 313 minecraft:red_terracotta
setblock 97 57 278 minecraft:light[level=12]
setblock 97 57 285 minecraft:light[level=12]
setblock 97 57 292 minecraft:light[level=12]
setblock 97 57 299 minecraft:light[level=12]
setblock 97 57 306 minecraft:light[level=12]
setblock 97 57 313 minecraft:light[level=12]
setblock 104 57 278 minecraft:light[level=12]
setblock 104 57 285 minecraft:light[level=12]
setblock 104 57 292 minecraft:light[level=12]
setblock 104 57 299 minecraft:light[level=12]
setblock 104 57 306 minecraft:light[level=12]
setblock 104 57 313 minecraft:light[level=12]
setblock 111 57 278 minecraft:light[level=12]
setblock 111 57 285 minecraft:light[level=12]
setblock 111 57 292 minecraft:light[level=12]
setblock 111 57 299 minecraft:light[level=12]
setblock 111 57 306 minecraft:light[level=12]
setblock 111 57 313 minecraft:light[level=12]
setblock 118 57 278 minecraft:light[level=12]
setblock 118 57 285 minecraft:light[level=12]
setblock 118 57 299 minecraft:light[level=12]
setblock 118 57 306 minecraft:light[level=12]
setblock 118 57 313 minecraft:light[level=12]
setblock 125 57 278 minecraft:light[level=12]
setblock 125 57 285 minecraft:light[level=12]
setblock 125 57 292 minecraft:light[level=12]
setblock 125 57 299 minecraft:light[level=12]
setblock 125 57 306 minecraft:light[level=12]
setblock 125 57 313 minecraft:light[level=12]
fill 128 57 311 128 57 313 minecraft:brown_terracotta
setblock 129 57 310 minecraft:brown_terracotta
fill 129 57 314 131 57 314 minecraft:brown_terracotta
setblock 130 57 306 minecraft:red_terracotta
setblock 130 57 308 minecraft:red_terracotta
fill 131 57 285 131 57 287 minecraft:red_terracotta
setblock 131 57 310 minecraft:brown_terracotta
setblock 132 57 278 minecraft:light[level=12]
fill 132 57 285 133 57 285 minecraft:red_terracotta
fill 132 57 287 133 57 287 minecraft:red_terracotta
setblock 132 57 292 minecraft:light[level=12]
setblock 132 57 299 minecraft:light[level=12]
setblock 132 57 306 minecraft:red_terracotta
setblock 132 57 308 minecraft:red_terracotta
fill 132 57 311 132 57 313 minecraft:brown_terracotta
setblock 133 57 286 minecraft:red_terracotta
setblock 135 57 315 minecraft:red_terracotta
fill 94 58 275 94 59 276 minecraft:white_concrete
fill 94 58 277 94 59 278 minecraft:red_concrete
fill 94 58 279 94 59 280 minecraft:white_concrete
fill 94 58 281 94 59 282 minecraft:red_concrete
fill 94 58 283 94 59 284 minecraft:white_concrete
fill 94 58 285 94 59 286 minecraft:red_concrete
fill 94 58 287 94 59 288 minecraft:white_concrete
fill 94 58 289 94 59 290 minecraft:red_concrete
fill 94 58 291 94 59 292 minecraft:white_concrete
fill 94 58 293 94 59 294 minecraft:red_concrete
fill 94 58 295 94 59 296 minecraft:white_concrete
fill 94 58 297 94 59 298 minecraft:red_concrete
fill 94 58 299 94 59 300 minecraft:white_concrete
fill 94 58 301 94 59 302 minecraft:red_concrete
fill 94 58 303 94 59 304 minecraft:white_concrete
fill 94 58 305 94 59 306 minecraft:red_concrete
fill 94 58 307 94 59 308 minecraft:white_concrete
fill 94 58 309 94 59 310 minecraft:red_concrete
fill 94 58 311 94 59 312 minecraft:white_concrete
fill 94 58 313 94 59 314 minecraft:red_concrete
fill 94 58 315 94 59 316 minecraft:white_concrete
fill 95 58 275 95 59 275 minecraft:white_concrete
fill 95 58 317 95 59 317 minecraft:white_concrete
fill 96 58 275 97 59 275 minecraft:red_concrete
fill 96 58 317 97 59 317 minecraft:red_concrete
fill 98 58 275 99 59 275 minecraft:white_concrete
fill 98 58 317 99 59 317 minecraft:white_concrete
fill 100 58 275 101 59 275 minecraft:red_concrete
fill 100 58 317 101 59 317 minecraft:red_concrete
fill 102 58 275 103 59 275 minecraft:white_concrete
fill 102 58 317 103 59 317 minecraft:white_concrete
fill 104 58 275 105 59 275 minecraft:red_concrete
fill 104 58 317 105 59 317 minecraft:red_concrete
fill 106 58 275 107 59 275 minecraft:white_concrete
fill 106 58 317 107 59 317 minecraft:white_concrete
fill 108 58 275 109 59 275 minecraft:red_concrete
fill 108 58 317 109 59 317 minecraft:red_concrete
fill 110 58 275 111 59 275 minecraft:white_concrete
fill 110 58 317 111 59 317 minecraft:white_concrete
fill 112 58 275 113 59 275 minecraft:red_concrete
fill 112 58 317 113 59 317 minecraft:red_concrete
fill 114 58 275 115 59 275 minecraft:white_concrete
fill 114 58 317 115 59 317 minecraft:white_concrete
fill 116 58 275 117 59 275 minecraft:red_concrete
fill 116 58 317 117 59 317 minecraft:red_concrete
fill 118 58 275 119 59 275 minecraft:white_concrete
fill 118 58 317 119 59 317 minecraft:white_concrete
fill 120 58 275 121 59 275 minecraft:red_concrete
fill 120 58 317 121 59 317 minecraft:red_concrete
fill 122 58 275 123 59 275 minecraft:white_concrete
fill 122 58 317 123 59 317 minecraft:white_concrete
fill 124 58 275 125 59 275 minecraft:red_concrete
fill 124 58 317 125 59 317 minecraft:red_concrete
fill 126 58 275 127 59 275 minecraft:white_concrete
fill 126 58 317 127 59 317 minecraft:white_concrete
fill 128 58 275 129 59 275 minecraft:red_concrete
fill 128 58 317 129 59 317 minecraft:red_concrete
fill 130 58 275 131 59 275 minecraft:white_concrete
fill 130 58 317 131 59 317 minecraft:white_concrete
fill 132 58 275 133 59 275 minecraft:red_concrete
fill 132 58 317 133 59 317 minecraft:red_concrete
fill 134 58 275 135 59 275 minecraft:white_concrete
fill 134 58 317 135 59 317 minecraft:white_concrete
fill 136 58 276 136 59 276 minecraft:white_concrete
fill 136 58 277 136 59 278 minecraft:red_concrete
fill 136 58 279 136 59 280 minecraft:white_concrete
fill 136 58 281 136 59 282 minecraft:red_concrete
fill 136 58 283 136 59 284 minecraft:white_concrete
fill 136 58 285 136 59 286 minecraft:red_concrete
fill 136 58 287 136 59 288 minecraft:white_concrete
fill 136 58 289 136 59 290 minecraft:red_concrete
fill 136 58 291 136 59 292 minecraft:white_concrete
fill 136 58 293 136 59 294 minecraft:red_concrete
fill 136 58 295 136 59 296 minecraft:white_concrete
fill 136 58 297 136 59 298 minecraft:red_concrete
fill 136 58 299 136 59 300 minecraft:white_concrete
fill 136 58 301 136 59 302 minecraft:red_concrete
fill 136 58 303 136 59 304 minecraft:white_concrete
fill 136 58 305 136 59 306 minecraft:red_concrete
fill 136 58 307 136 59 308 minecraft:white_concrete
fill 136 58 309 136 59 310 minecraft:red_concrete
fill 136 58 311 136 59 312 minecraft:white_concrete
fill 136 58 313 136 59 314 minecraft:red_concrete
fill 136 58 315 136 59 316 minecraft:white_concrete
fill 136 58 317 136 59 317 minecraft:red_concrete
fill 128 59 289 132 60 293 minecraft:brown_terracotta
fill 133 59 291 134 59 291 minecraft:brown_terracotta
fill 94 60 275 94 61 276 minecraft:red_concrete
fill 94 60 277 94 61 278 minecraft:white_concrete
fill 94 60 279 94 61 279 minecraft:red_concrete
fill 94 60 280 94 65 280 minecraft:shroomlight
fill 94 60 281 94 61 282 minecraft:white_concrete
fill 94 60 283 94 61 284 minecraft:red_concrete
fill 94 60 285 94 61 286 minecraft:white_concrete
fill 94 60 287 94 61 287 minecraft:red_concrete
fill 94 60 288 94 65 288 minecraft:shroomlight
fill 94 60 289 94 61 290 minecraft:white_concrete
fill 94 60 291 94 61 292 minecraft:red_concrete
fill 94 60 293 94 61 294 minecraft:white_concrete
fill 94 60 295 94 61 295 minecraft:red_concrete
fill 94 60 296 94 65 296 minecraft:shroomlight
fill 94 60 297 94 61 298 minecraft:white_concrete
fill 94 60 299 94 61 300 minecraft:red_concrete
fill 94 60 301 94 61 302 minecraft:white_concrete
fill 94 60 303 94 61 303 minecraft:red_concrete
fill 94 60 304 94 65 304 minecraft:shroomlight
fill 94 60 305 94 61 306 minecraft:white_concrete
fill 94 60 307 94 61 308 minecraft:red_concrete
fill 94 60 309 94 61 310 minecraft:white_concrete
fill 94 60 311 94 61 311 minecraft:red_concrete
fill 94 60 312 94 65 312 minecraft:shroomlight
fill 94 60 313 94 61 314 minecraft:white_concrete
fill 94 60 315 94 61 316 minecraft:red_concrete
fill 95 60 275 95 61 275 minecraft:red_concrete
fill 95 60 317 95 61 317 minecraft:red_concrete
fill 96 60 275 97 61 275 minecraft:white_concrete
fill 96 60 317 96 61 317 minecraft:white_concrete
fill 97 60 317 97 65 317 minecraft:shroomlight
fill 98 60 275 99 61 275 minecraft:red_concrete
fill 98 60 317 99 61 317 minecraft:red_concrete
fill 100 60 275 100 61 275 minecraft:white_concrete
fill 100 60 317 101 61 317 minecraft:white_concrete
fill 101 60 275 101 65 275 minecraft:shroomlight
fill 102 60 275 103 61 275 minecraft:red_concrete
fill 102 60 317 103 61 317 minecraft:red_concrete
fill 104 60 275 105 61 275 minecraft:white_concrete
fill 104 60 317 104 61 317 minecraft:white_concrete
fill 105 60 317 105 65 317 minecraft:shroomlight
fill 106 60 275 107 61 275 minecraft:red_concrete
fill 106 60 317 107 61 317 minecraft:red_concrete
fill 108 60 275 108 61 275 minecraft:white_concrete
fill 108 60 317 109 61 317 minecraft:white_concrete
fill 109 60 275 109 65 275 minecraft:shroomlight
fill 110 60 275 111 61 275 minecraft:red_concrete
fill 110 60 317 111 61 317 minecraft:red_concrete
fill 112 60 275 113 61 275 minecraft:white_concrete
fill 112 60 317 112 61 317 minecraft:white_concrete
fill 113 60 317 113 65 317 minecraft:shroomlight
fill 114 60 275 115 61 275 minecraft:red_concrete
fill 114 60 317 115 61 317 minecraft:red_concrete
fill 116 60 275 116 61 275 minecraft:white_concrete
fill 116 60 317 117 61 317 minecraft:white_concrete
fill 117 60 275 117 65 275 minecraft:shroomlight
fill 118 60 275 119 61 275 minecraft:red_concrete
fill 118 60 317 119 61 317 minecraft:red_concrete
fill 120 60 275 121 61 275 minecraft:white_concrete
fill 120 60 317 120 61 317 minecraft:white_concrete
fill 121 60 317 121 65 317 minecraft:shroomlight
fill 122 60 275 123 61 275 minecraft:red_concrete
fill 122 60 317 123 61 317 minecraft:red_concrete
fill 124 60 275 124 61 275 minecraft:white_concrete
fill 124 60 317 125 61 317 minecraft:white_concrete
fill 125 60 275 125 65 275 minecraft:shroomlight
fill 126 60 275 127 61 275 minecraft:red_concrete
fill 126 60 317 127 61 317 minecraft:red_concrete
fill 128 60 275 129 61 275 minecraft:white_concrete
fill 128 60 317 128 61 317 minecraft:white_concrete
fill 129 60 317 129 65 317 minecraft:shroomlight
fill 130 60 275 131 61 275 minecraft:red_concrete
fill 130 60 317 131 61 317 minecraft:red_concrete
fill 132 60 275 132 61 275 minecraft:white_concrete
fill 132 60 317 133 61 317 minecraft:white_concrete
fill 133 60 275 133 65 275 minecraft:shroomlight
fill 134 60 275 135 61 275 minecraft:red_concrete
fill 134 60 317 135 61 317 minecraft:red_concrete
fill 136 60 276 136 61 276 minecraft:red_concrete
fill 136 60 277 136 61 278 minecraft:white_concrete
fill 136 60 279 136 61 279 minecraft:red_concrete
fill 136 60 280 136 65 280 minecraft:shroomlight
fill 136 60 281 136 61 282 minecraft:white_concrete
fill 136 60 283 136 61 284 minecraft:red_concrete
fill 136 60 285 136 61 286 minecraft:white_concrete
fill 136 60 287 136 61 287 minecraft:red_concrete
fill 136 60 288 136 65 288 minecraft:shroomlight
fill 136 60 289 136 61 290 minecraft:white_concrete
fill 136 60 291 136 61 292 minecraft:red_concrete
fill 136 60 293 136 61 294 minecraft:white_concrete
fill 136 60 295 136 61 295 minecraft:red_concrete
fill 136 60 296 136 65 296 minecraft:shroomlight
fill 136 60 297 136 61 298 minecraft:white_concrete
fill 136 60 299 136 61 300 minecraft:red_concrete
fill 136 60 301 136 61 302 minecraft:white_concrete
fill 136 60 303 136 61 303 minecraft:red_concrete
fill 136 60 304 136 65 304 minecraft:shroomlight
fill 136 60 305 136 61 306 minecraft:white_concrete
fill 136 60 307 136 61 308 minecraft:red_concrete
fill 136 60 309 136 61 310 minecraft:white_concrete
fill 136 60 311 136 61 311 minecraft:red_concrete
fill 136 60 312 136 65 312 minecraft:shroomlight
fill 136 60 313 136 61 314 minecraft:white_concrete
fill 136 60 315 136 61 316 minecraft:red_concrete
fill 136 60 317 136 61 317 minecraft:white_concrete
setblock 97 61 278 minecraft:light[level=15]
setblock 97 61 286 minecraft:light[level=15]
setblock 97 61 294 minecraft:light[level=15]
setblock 97 61 302 minecraft:light[level=15]
setblock 97 61 310 minecraft:light[level=15]
setblock 105 61 278 minecraft:light[level=15]
setblock 105 61 286 minecraft:light[level=15]
setblock 105 61 294 minecraft:light[level=15]
setblock 105 61 302 minecraft:light[level=15]
setblock 105 61 310 minecraft:light[level=15]
setblock 113 61 278 minecraft:light[level=15]
setblock 113 61 286 minecraft:light[level=15]
setblock 113 61 294 minecraft:light[level=15]
setblock 113 61 302 minecraft:light[level=15]
setblock 113 61 310 minecraft:light[level=15]
setblock 121 61 278 minecraft:light[level=15]
setblock 121 61 286 minecraft:light[level=15]
setblock 121 61 294 minecraft:light[level=15]
setblock 121 61 302 minecraft:light[level=15]
setblock 121 61 310 minecraft:light[level=15]
setblock 129 61 278 minecraft:light[level=15]
setblock 129 61 286 minecraft:light[level=15]
setblock 129 61 294 minecraft:light[level=15]
setblock 129 61 302 minecraft:light[level=15]
setblock 129 61 310 minecraft:light[level=15]
fill 130 61 291 130 64 291 minecraft:red_terracotta
fill 94 62 275 94 63 276 minecraft:white_concrete
fill 94 62 277 94 63 278 minecraft:red_concrete
fill 94 62 279 94 63 279 minecraft:white_concrete
fill 94 62 281 94 63 282 minecraft:red_concrete
fill 94 62 283 94 63 284 minecraft:white_concrete
fill 94 62 285 94 63 286 minecraft:red_concrete
fill 94 62 287 94 63 287 minecraft:white_concrete
fill 94 62 289 94 63 290 minecraft:red_concrete
fill 94 62 291 94 63 292 minecraft:white_concrete
fill 94 62 293 94 63 294 minecraft:red_concrete
fill 94 62 295 94 63 295 minecraft:white_concrete
fill 94 62 297 94 63 298 minecraft:red_concrete
fill 94 62 299 94 63 300 minecraft:white_concrete
fill 94 62 301 94 63 302 minecraft:red_concrete
fill 94 62 303 94 63 303 minecraft:white_concrete
fill 94 62 305 94 63 306 minecraft:red_concrete
fill 94 62 307 94 63 308 minecraft:white_concrete
fill 94 62 309 94 63 310 minecraft:red_concrete
fill 94 62 311 94 63 311 minecraft:white_concrete
fill 94 62 313 94 63 314 minecraft:red_concrete
fill 94 62 315 94 63 316 minecraft:white_concrete
fill 95 62 275 95 63 275 minecraft:white_concrete
fill 95 62 317 95 63 317 minecraft:white_concrete
fill 96 62 275 97 63 275 minecraft:red_concrete
fill 96 62 317 96 63 317 minecraft:red_concrete
fill 98 62 275 99 63 275 minecraft:white_concrete
fill 98 62 317 99 63 317 minecraft:white_concrete
fill 100 62 275 100 63 275 minecraft:red_concrete
fill 100 62 317 101 63 317 minecraft:red_concrete
fill 102 62 275 103 63 275 minecraft:white_concrete
fill 102 62 317 103 63 317 minecraft:white_concrete
fill 104 62 275 105 63 275 minecraft:red_concrete
fill 104 62 317 104 63 317 minecraft:red_concrete
fill 106 62 275 107 63 275 minecraft:white_concrete
fill 106 62 317 107 63 317 minecraft:white_concrete
fill 108 62 275 108 63 275 minecraft:red_concrete
fill 108 62 317 109 63 317 minecraft:red_concrete
fill 110 62 275 111 63 275 minecraft:white_concrete
fill 110 62 317 111 63 317 minecraft:white_concrete
fill 112 62 275 113 63 275 minecraft:red_concrete
fill 112 62 317 112 63 317 minecraft:red_concrete
fill 114 62 275 115 63 275 minecraft:white_concrete
fill 114 62 317 115 63 317 minecraft:white_concrete
fill 116 62 275 116 63 275 minecraft:red_concrete
fill 116 62 317 117 63 317 minecraft:red_concrete
fill 118 62 275 119 63 275 minecraft:white_concrete
fill 118 62 317 119 63 317 minecraft:white_concrete
fill 120 62 275 121 63 275 minecraft:red_concrete
fill 120 62 317 120 63 317 minecraft:red_concrete
fill 122 62 275 123 63 275 minecraft:white_concrete
fill 122 62 317 123 63 317 minecraft:white_concrete
fill 124 62 275 124 63 275 minecraft:red_concrete
fill 124 62 317 125 63 317 minecraft:red_concrete
fill 126 62 275 127 63 275 minecraft:white_concrete
fill 126 62 317 127 63 317 minecraft:white_concrete
fill 128 62 275 129 63 275 minecraft:red_concrete
fill 128 62 317 128 63 317 minecraft:red_concrete
fill 130 62 275 131 63 275 minecraft:white_concrete
setblock 130 62 306 minecraft:red_terracotta
setblock 130 62 308 minecraft:red_terracotta
fill 130 62 317 131 63 317 minecraft:white_concrete
fill 131 62 285 131 62 287 minecraft:red_terracotta
fill 132 62 275 132 63 275 minecraft:red_concrete
fill 132 62 285 133 62 285 minecraft:red_terracotta
fill 132 62 287 133 62 287 minecraft:red_terracotta
setblock 132 62 306 minecraft:red_terracotta
setblock 132 62 308 minecraft:red_terracotta
fill 132 62 317 133 63 317 minecraft:red_concrete
setblock 133 62 286 minecraft:red_terracotta
fill 134 62 275 135 63 275 minecraft:white_concrete
fill 134 62 317 135 63 317 minecraft:white_concrete
fill 136 62 276 136 63 276 minecraft:white_concrete
fill 136 62 277 136 63 278 minecraft:red_concrete
fill 136 62 279 136 63 279 minecraft:white_concrete
fill 136 62 281 136 63 282 minecraft:red_concrete
fill 136 62 283 136 63 284 minecraft:white_concrete
fill 136 62 285 136 63 286 minecraft:red_concrete
fill 136 62 287 136 63 287 minecraft:white_concrete
fill 136 62 289 136 63 290 minecraft:red_concrete
fill 136 62 291 136 63 292 minecraft:white_concrete
fill 136 62 293 136 63 294 minecraft:red_concrete
fill 136 62 295 136 63 295 minecraft:white_concrete
fill 136 62 297 136 63 298 minecraft:red_concrete
fill 136 62 299 136 63 300 minecraft:white_concrete
fill 136 62 301 136 63 302 minecraft:red_concrete
fill 136 62 303 136 63 303 minecraft:white_concrete
fill 136 62 305 136 63 306 minecraft:red_concrete
fill 136 62 307 136 63 308 minecraft:white_concrete
fill 136 62 309 136 63 310 minecraft:red_concrete
fill 136 62 311 136 63 311 minecraft:white_concrete
fill 136 62 313 136 63 314 minecraft:red_concrete
fill 136 62 315 136 63 316 minecraft:white_concrete
fill 136 62 317 136 63 317 minecraft:red_concrete
setblock 97 63 278 minecraft:light[level=12]
setblock 97 63 285 minecraft:light[level=12]
setblock 97 63 292 minecraft:light[level=12]
setblock 97 63 299 minecraft:light[level=12]
setblock 97 63 306 minecraft:light[level=12]
setblock 97 63 313 minecraft:light[level=12]
setblock 104 63 278 minecraft:light[level=12]
setblock 104 63 285 minecraft:light[level=12]
setblock 104 63 292 minecraft:light[level=12]
setblock 104 63 299 minecraft:light[level=12]
setblock 104 63 306 minecraft:light[level=12]
setblock 104 63 313 minecraft:light[level=12]
setblock 111 63 278 minecraft:light[level=12]
setblock 111 63 285 minecraft:light[level=12]
setblock 111 63 292 minecraft:light[level=12]
setblock 111 63 299 minecraft:light[level=12]
setblock 111 63 306 minecraft:light[level=12]
setblock 111 63 313 minecraft:light[level=12]
setblock 118 63 278 minecraft:light[level=12]
setblock 118 63 285 minecraft:light[level=12]
setblock 118 63 299 minecraft:light[level=12]
setblock 118 63 306 minecraft:light[level=12]
setblock 118 63 313 minecraft:light[level=12]
setblock 125 63 278 minecraft:light[level=12]
setblock 125 63 285 minecraft:light[level=12]
setblock 125 63 292 minecraft:light[level=12]
setblock 125 63 299 minecraft:light[level=12]
setblock 125 63 306 minecraft:light[level=12]
setblock 125 63 313 minecraft:light[level=12]
setblock 132 63 278 minecraft:light[level=12]
setblock 132 63 285 minecraft:light[level=12]
setblock 132 63 292 minecraft:light[level=12]
setblock 132 63 299 minecraft:light[level=12]
setblock 132 63 306 minecraft:light[level=12]
setblock 132 63 313 minecraft:light[level=12]
fill 94 64 275 94 65 276 minecraft:red_concrete
fill 94 64 277 94 65 278 minecraft:white_concrete
fill 94 64 279 94 65 279 minecraft:red_concrete
fill 94 64 281 94 65 282 minecraft:white_concrete
fill 94 64 283 94 65 284 minecraft:red_concrete
fill 94 64 285 94 65 286 minecraft:white_concrete
fill 94 64 287 94 65 287 minecraft:red_concrete
fill 94 64 289 94 65 290 minecraft:white_concrete
fill 94 64 291 94 65 292 minecraft:red_concrete
fill 94 64 293 94 65 294 minecraft:white_concrete
fill 94 64 295 94 65 295 minecraft:red_concrete
fill 94 64 297 94 65 298 minecraft:white_concrete
fill 94 64 299 94 65 300 minecraft:red_concrete
fill 94 64 301 94 65 302 minecraft:white_concrete
fill 94 64 303 94 65 303 minecraft:red_concrete
fill 94 64 305 94 65 306 minecraft:white_concrete
fill 94 64 307 94 65 308 minecraft:red_concrete
fill 94 64 309 94 65 310 minecraft:white_concrete
fill 94 64 311 94 65 311 minecraft:red_concrete
fill 94 64 313 94 65 314 minecraft:white_concrete
fill 94 64 315 94 65 316 minecraft:red_concrete
fill 95 64 275 95 65 275 minecraft:red_concrete
fill 95 64 317 95 65 317 minecraft:red_concrete
fill 96 64 275 97 65 275 minecraft:white_concrete
fill 96 64 317 96 65 317 minecraft:white_concrete
fill 98 64 275 99 65 275 minecraft:red_concrete
fill 98 64 317 99 65 317 minecraft:red_concrete
fill 100 64 275 100 65 275 minecraft:white_concrete
fill 100 64 317 101 65 317 minecraft:white_concrete
fill 102 64 275 103 65 275 minecraft:red_concrete
fill 102 64 317 103 65 317 minecraft:red_concrete
fill 104 64 275 105 65 275 minecraft:white_concrete
fill 104 64 317 104 65 317 minecraft:white_concrete
fill 106 64 275 107 65 275 minecraft:red_concrete
fill 106 64 317 107 65 317 minecraft:red_concrete
fill 108 64 275 108 65 275 minecraft:white_concrete
fill 108 64 317 109 65 317 minecraft:white_concrete
fill 110 64 275 111 65 275 minecraft:red_concrete
fill 110 64 317 111 65 317 minecraft:red_concrete
fill 112 64 275 113 65 275 minecraft:white_concrete
fill 112 64 317 112 65 317 minecraft:white_concrete
fill 114 64 275 115 65 275 minecraft:red_concrete
fill 114 64 317 115 65 317 minecraft:red_concrete
fill 116 64 275 116 65 275 minecraft:white_concrete
fill 116 64 317 117 65 317 minecraft:white_concrete
fill 118 64 275 119 65 275 minecraft:red_concrete
fill 118 64 317 119 65 317 minecraft:red_concrete
fill 120 64 275 121 65 275 minecraft:white_concrete
fill 120 64 317 120 65 317 minecraft:white_concrete
fill 122 64 275 123 65 275 minecraft:red_concrete
fill 122 64 317 123 65 317 minecraft:red_concrete
fill 124 64 275 124 65 275 minecraft:white_concrete
fill 124 64 317 125 65 317 minecraft:white_concrete
fill 126 64 275 127 65 275 minecraft:red_concrete
fill 126 64 317 127 65 317 minecraft:red_concrete
fill 128 64 275 129 65 275 minecraft:white_concrete
setblock 128 64 306 minecraft:iron_block
fill 128 64 317 128 65 317 minecraft:white_concrete
setblock 129 64 305 minecraft:iron_block
fill 129 64 306 131 64 306 minecraft:black_concrete
setblock 129 64 307 minecraft:iron_block
fill 130 64 275 131 65 275 minecraft:red_concrete
setblock 130 64 304 minecraft:iron_block
setblock 130 64 305 minecraft:black_concrete
setblock 130 64 307 minecraft:black_concrete
setblock 130 64 308 minecraft:iron_block
fill 130 64 317 131 65 317 minecraft:red_concrete
setblock 131 64 305 minecraft:iron_block
fill 132 64 275 132 65 275 minecraft:white_concrete
setblock 132 64 306 minecraft:iron_block
fill 132 64 317 133 65 317 minecraft:white_concrete
fill 134 64 275 135 65 275 minecraft:red_concrete
fill 134 64 317 135 65 317 minecraft:red_concrete
fill 136 64 276 136 65 276 minecraft:red_concrete
fill 136 64 277 136 65 278 minecraft:white_concrete
fill 136 64 279 136 65 279 minecraft:red_concrete
fill 136 64 281 136 65 282 minecraft:white_concrete
fill 136 64 283 136 65 284 minecraft:red_concrete
fill 136 64 285 136 65 286 minecraft:white_concrete
fill 136 64 287 136 65 287 minecraft:red_concrete
fill 136 64 289 136 65 290 minecraft:white_concrete
fill 136 64 291 136 65 292 minecraft:red_concrete
fill 136 64 293 136 65 294 minecraft:white_concrete
fill 136 64 295 136 65 295 minecraft:red_concrete
fill 136 64 297 136 65 298 minecraft:white_concrete
fill 136 64 299 136 65 300 minecraft:red_concrete
fill 136 64 301 136 65 302 minecraft:white_concrete
fill 136 64 303 136 65 303 minecraft:red_concrete
fill 136 64 305 136 65 306 minecraft:white_concrete
fill 136 64 307 136 65 308 minecraft:red_concrete
fill 136 64 309 136 65 310 minecraft:white_concrete
fill 136 64 311 136 65 311 minecraft:red_concrete
fill 136 64 313 136 65 314 minecraft:white_concrete
fill 136 64 315 136 65 316 minecraft:red_concrete
fill 136 64 317 136 65 317 minecraft:white_concrete
fill 128 65 291 132 68 291 minecraft:yellow_concrete
fill 128 65 311 128 65 313 minecraft:brown_terracotta
fill 129 65 290 131 68 290 minecraft:yellow_concrete
fill 129 65 292 131 68 292 minecraft:yellow_concrete
setblock 129 65 310 minecraft:brown_terracotta
fill 129 65 314 131 65 314 minecraft:brown_terracotta
fill 130 65 289 130 68 289 minecraft:yellow_concrete
fill 130 65 293 130 68 293 minecraft:yellow_concrete
fill 130 65 307 130 76 307 minecraft:iron_block
fill 131 65 306 131 76 306 minecraft:iron_block
setblock 131 65 310 minecraft:brown_terracotta
fill 132 65 311 132 65 313 minecraft:brown_terracotta
fill 94 66 275 94 67 276 minecraft:white_concrete
fill 94 66 277 94 67 278 minecraft:red_concrete
fill 94 66 279 94 67 280 minecraft:white_concrete
fill 94 66 281 94 67 282 minecraft:red_concrete
fill 94 66 283 94 67 284 minecraft:white_concrete
fill 94 66 285 94 67 286 minecraft:red_concrete
fill 94 66 287 94 67 288 minecraft:white_concrete
fill 94 66 289 94 67 290 minecraft:red_concrete
fill 94 66 291 94 67 292 minecraft:white_concrete
fill 94 66 293 94 67 294 minecraft:red_concrete
fill 94 66 295 94 67 296 minecraft:white_concrete
fill 94 66 297 94 67 298 minecraft:red_concrete
fill 94 66 299 94 67 300 minecraft:white_concrete
fill 94 66 301 94 67 302 minecraft:red_concrete
fill 94 66 303 94 67 304 minecraft:white_concrete
fill 94 66 305 94 67 306 minecraft:red_concrete
fill 94 66 307 94 67 308 minecraft:white_concrete
fill 94 66 309 94 67 310 minecraft:red_concrete
fill 94 66 311 94 67 312 minecraft:white_concrete
fill 94 66 313 94 67 314 minecraft:red_concrete
fill 94 66 315 94 67 316 minecraft:white_concrete
fill 95 66 275 95 67 275 minecraft:white_concrete
fill 95 66 317 95 67 317 minecraft:white_concrete
fill 96 66 275 97 67 275 minecraft:red_concrete
fill 96 66 317 97 67 317 minecraft:red_concrete
fill 98 66 275 99 67 275 minecraft:white_concrete
fill 98 66 317 99 67 317 minecraft:white_concrete
fill 100 66 275 101 67 275 minecraft:red_concrete
fill 100 66 317 101 67 317 minecraft:red_concrete
fill 102 66 275 103 67 275 minecraft:white_concrete
fill 102 66 317 103 67 317 minecraft:white_concrete
fill 104 66 275 105 67 275 minecraft:red_concrete
fill 104 66 317 105 67 317 minecraft:red_concrete
fill 106 66 275 107 67 275 minecraft:white_concrete
fill 106 66 317 107 67 317 minecraft:white_concrete
fill 108 66 275 109 67 275 minecraft:red_concrete
fill 108 66 317 109 67 317 minecraft:red_concrete
fill 110 66 275 111 67 275 minecraft:white_concrete
fill 110 66 317 111 67 317 minecraft:white_concrete
fill 112 66 275 113 67 275 minecraft:red_concrete
fill 112 66 317 113 67 317 minecraft:red_concrete
fill 114 66 275 115 67 275 minecraft:white_concrete
fill 114 66 317 115 67 317 minecraft:white_concrete
fill 116 66 275 117 67 275 minecraft:red_concrete
fill 116 66 317 117 67 317 minecraft:red_concrete
fill 118 66 275 119 67 275 minecraft:white_concrete
fill 118 66 317 119 67 317 minecraft:white_concrete
fill 120 66 275 121 67 275 minecraft:red_concrete
fill 120 66 317 121 67 317 minecraft:red_concrete
fill 122 66 275 123 67 275 minecraft:white_concrete
fill 122 66 317 123 67 317 minecraft:white_concrete
fill 124 66 275 125 67 275 minecraft:red_concrete
fill 124 66 317 125 67 317 minecraft:red_concrete
fill 126 66 275 127 67 275 minecraft:white_concrete
fill 126 66 317 127 67 317 minecraft:white_concrete
fill 128 66 275 129 67 275 minecraft:red_concrete
fill 128 66 290 128 67 290 minecraft:yellow_concrete
fill 128 66 292 128 67 292 minecraft:yellow_concrete
fill 128 66 317 129 67 317 minecraft:red_concrete
fill 129 66 289 129 67 289 minecraft:yellow_concrete
fill 129 66 293 129 67 293 minecraft:yellow_concrete
fill 130 66 275 131 67 275 minecraft:white_concrete
fill 130 66 317 131 67 317 minecraft:white_concrete
fill 131 66 289 131 67 289 minecraft:yellow_concrete
fill 131 66 293 131 67 293 minecraft:yellow_concrete
fill 132 66 275 133 67 275 minecraft:red_concrete
fill 132 66 290 132 67 290 minecraft:yellow_concrete
fill 132 66 292 132 67 292 minecraft:yellow_concrete
fill 132 66 317 133 67 317 minecraft:red_concrete
fill 134 66 275 135 67 275 minecraft:white_concrete
fill 134 66 317 135 67 317 minecraft:white_concrete
fill 136 66 276 136 67 276 minecraft:white_concrete
fill 136 66 277 136 67 278 minecraft:red_concrete
fill 136 66 279 136 67 280 minecraft:white_concrete
fill 136 66 281 136 67 282 minecraft:red_concrete
fill 136 66 283 136 67 284 minecraft:white_concrete
fill 136 66 285 136 67 286 minecraft:red_concrete
fill 136 66 287 136 67 288 minecraft:white_concrete
fill 136 66 289 136 67 290 minecraft:red_concrete
fill 136 66 291 136 67 292 minecraft:white_concrete
fill 136 66 293 136 67 294 minecraft:red_concrete
fill 136 66 295 136 67 296 minecraft:white_concrete
fill 136 66 297 136 67 298 minecraft:red_concrete
fill 136 66 299 136 67 300 minecraft:white_concrete
fill 136 66 301 136 67 302 minecraft:red_concrete
fill 136 66 303 136 67 304 minecraft:white_concrete
fill 136 66 305 136 67 306 minecraft:red_concrete
fill 136 66 307 136 67 308 minecraft:white_concrete
fill 136 66 309 136 67 310 minecraft:red_concrete
fill 136 66 311 136 67 312 minecraft:white_concrete
fill 136 66 313 136 67 314 minecraft:red_concrete
fill 136 66 315 136 67 316 minecraft:white_concrete
fill 136 66 317 136 67 317 minecraft:red_concrete
setblock 130 67 306 minecraft:red_terracotta
setblock 130 67 308 minecraft:red_terracotta
fill 131 67 285 131 67 287 minecraft:red_terracotta
fill 132 67 285 133 67 285 minecraft:red_terracotta
fill 132 67 287 133 67 287 minecraft:red_terracotta
setblock 132 67 306 minecraft:red_terracotta
setblock 132 67 308 minecraft:red_terracotta
setblock 133 67 286 minecraft:red_terracotta
fill 94 68 275 94 69 276 minecraft:red_concrete
fill 94 68 277 94 69 278 minecraft:white_concrete
fill 94 68 279 94 69 280 minecraft:red_concrete
fill 94 68 281 94 69 282 minecraft:white_concrete
fill 94 68 283 94 69 284 minecraft:red_concrete
fill 94 68 285 94 69 286 minecraft:white_concrete
fill 94 68 287 94 69 288 minecraft:red_concrete
fill 94 68 289 94 69 290 minecraft:white_concrete
fill 94 68 291 94 69 292 minecraft:red_concrete
fill 94 68 293 94 69 294 minecraft:white_concrete
fill 94 68 295 94 69 296 minecraft:red_concrete
fill 94 68 297 94 69 298 minecraft:white_concrete
fill 94 68 299 94 69 300 minecraft:red_concrete
fill 94 68 301 94 69 302 minecraft:white_concrete
fill 94 68 303 94 69 304 minecraft:red_concrete
fill 94 68 305 94 69 306 minecraft:white_concrete
fill 94 68 307 94 69 308 minecraft:red_concrete
fill 94 68 309 94 69 310 minecraft:white_concrete
fill 94 68 311 94 69 312 minecraft:red_concrete
fill 94 68 313 94 69 314 minecraft:white_concrete
fill 94 68 315 94 69 316 minecraft:red_concrete
fill 95 68 275 95 69 275 minecraft:red_concrete
fill 95 68 317 95 69 317 minecraft:red_concrete
fill 96 68 275 97 69 275 minecraft:white_concrete
fill 96 68 317 97 69 317 minecraft:white_concrete
fill 98 68 275 99 69 275 minecraft:red_concrete
fill 98 68 317 99 69 317 minecraft:red_concrete
fill 100 68 275 101 69 275 minecraft:white_concrete
fill 100 68 317 101 69 317 minecraft:white_concrete
fill 102 68 275 103 69 275 minecraft:red_concrete
fill 102 68 317 103 69 317 minecraft:red_concrete
fill 104 68 275 105 69 275 minecraft:white_concrete
fill 104 68 317 105 69 317 minecraft:white_concrete
fill 106 68 275 107 69 275 minecraft:red_concrete
fill 106 68 317 107 69 317 minecraft:red_concrete
fill 108 68 275 109 69 275 minecraft:white_concrete
fill 108 68 317 109 69 317 minecraft:white_concrete
fill 110 68 275 111 69 275 minecraft:red_concrete
fill 110 68 317 111 69 317 minecraft:red_concrete
fill 112 68 275 113 69 275 minecraft:white_concrete
fill 112 68 317 113 69 317 minecraft:white_concrete
fill 114 68 275 115 69 275 minecraft:red_concrete
fill 114 68 317 115 69 317 minecraft:red_concrete
fill 116 68 275 117 69 275 minecraft:white_concrete
fill 116 68 317 117 69 317 minecraft:white_concrete
fill 118 68 275 119 69 275 minecraft:red_concrete
fill 118 68 317 119 69 317 minecraft:red_concrete
fill 120 68 275 121 69 275 minecraft:white_concrete
fill 120 68 317 121 69 317 minecraft:white_concrete
fill 122 68 275 123 69 275 minecraft:red_concrete
fill 122 68 317 123 69 317 minecraft:red_concrete
fill 124 68 275 125 69 275 minecraft:white_concrete
fill 124 68 317 125 69 317 minecraft:white_concrete
fill 126 68 275 127 69 275 minecraft:red_concrete
fill 126 68 317 127 69 317 minecraft:red_concrete
fill 128 68 275 129 69 275 minecraft:white_concrete
fill 128 68 317 129 69 317 minecraft:white_concrete
fill 130 68 275 131 69 275 minecraft:red_concrete
fill 130 68 317 131 69 317 minecraft:red_concrete
fill 132 68 275 133 69 275 minecraft:white_concrete
fill 132 68 317 133 69 317 minecraft:white_concrete
fill 134 68 275 135 69 275 minecraft:red_concrete
fill 134 68 317 135 69 317 minecraft:red_concrete
fill 136 68 276 136 69 276 minecraft:red_concrete
fill 136 68 277 136 69 278 minecraft:white_concrete
fill 136 68 279 136 69 280 minecraft:red_concrete
fill 136 68 281 136 69 282 minecraft:white_concrete
fill 136 68 283 136 69 284 minecraft:red_concrete
fill 136 68 285 136 69 286 minecraft:white_concrete
fill 136 68 287 136 69 288 minecraft:red_concrete
fill 136 68 289 136 69 290 minecraft:white_concrete
fill 136 68 291 136 69 292 minecraft:red_concrete
fill 136 68 293 136 69 294 minecraft:white_concrete
fill 136 68 295 136 69 296 minecraft:red_concrete
fill 136 68 297 136 69 298 minecraft:white_concrete
fill 136 68 299 136 69 300 minecraft:red_concrete
fill 136 68 301 136 69 302 minecraft:white_concrete
fill 136 68 303 136 69 304 minecraft:red_concrete
fill 136 68 305 136 69 306 minecraft:white_concrete
fill 136 68 307 136 69 308 minecraft:red_concrete
fill 136 68 309 136 69 310 minecraft:white_concrete
fill 136 68 311 136 69 312 minecraft:red_concrete
fill 136 68 313 136 69 314 minecraft:white_concrete
fill 136 68 315 136 69 316 minecraft:red_concrete
fill 136 68 317 136 69 317 minecraft:white_concrete
setblock 97 69 278 minecraft:light[level=15]
setblock 97 69 285 minecraft:light[level=12]
setblock 97 69 286 minecraft:light[level=15]
setblock 97 69 292 minecraft:light[level=12]
setblock 97 69 294 minecraft:light[level=15]
setblock 97 69 299 minecraft:light[level=12]
setblock 97 69 302 minecraft:light[level=15]
setblock 97 69 306 minecraft:light[level=12]
setblock 97 69 310 minecraft:light[level=15]
setblock 97 69 313 minecraft:light[level=12]
setblock 104 69 278 minecraft:light[level=12]
setblock 104 69 285 minecraft:light[level=12]
setblock 104 69 292 minecraft:light[level=12]
setblock 104 69 299 minecraft:light[level=12]
setblock 104 69 306 minecraft:light[level=12]
setblock 104 69 313 minecraft:light[level=12]
setblock 105 69 278 minecraft:light[level=15]
setblock 105 69 286 minecraft:light[level=15]
setblock 105 69 294 minecraft:light[level=15]
setblock 105 69 302 minecraft:light[level=15]
setblock 105 69 310 minecraft:light[level=15]
setblock 111 69 278 minecraft:light[level=12]
setblock 111 69 285 minecraft:light[level=12]
setblock 111 69 292 minecraft:light[level=12]
setblock 111 69 299 minecraft:light[level=12]
setblock 111 69 306 minecraft:light[level=12]
setblock 111 69 313 minecraft:light[level=12]
setblock 113 69 278 minecraft:light[level=15]
setblock 113 69 286 minecraft:light[level=15]
setblock 113 69 294 minecraft:light[level=15]
setblock 113 69 302 minecraft:light[level=15]
setblock 113 69 310 minecraft:light[level=15]
setblock 118 69 278 minecraft:light[level=12]
setblock 118 69 285 minecraft:light[level=12]
setblock 118 69 299 minecraft:light[level=12]
setblock 118 69 306 minecraft:light[level=12]
setblock 118 69 313 minecraft:light[level=12]
setblock 121 69 278 minecraft:light[level=15]
setblock 121 69 286 minecraft:light[level=15]
setblock 121 69 294 minecraft:light[level=15]
setblock 121 69 302 minecraft:light[level=15]
setblock 121 69 310 minecraft:light[level=15]
setblock 125 69 278 minecraft:light[level=12]
setblock 125 69 285 minecraft:light[level=12]
setblock 125 69 292 minecraft:light[level=12]
setblock 125 69 299 minecraft:light[level=12]
setblock 125 69 306 minecraft:light[level=12]
setblock 125 69 313 minecraft:light[level=12]
setblock 129 69 278 minecraft:light[level=15]
setblock 129 69 286 minecraft:light[level=15]
setblock 129 69 294 minecraft:light[level=15]
setblock 129 69 302 minecraft:light[level=15]
setblock 129 69 310 minecraft:light[level=15]
setblock 130 69 291 minecraft:yellow_concrete
setblock 132 69 278 minecraft:light[level=12]
setblock 132 69 285 minecraft:light[level=12]
setblock 132 69 292 minecraft:light[level=12]
setblock 132 69 299 minecraft:light[level=12]
setblock 132 69 306 minecraft:light[level=12]
setblock 132 69 313 minecraft:light[level=12]
fill 94 70 275 94 71 276 minecraft:white_concrete
fill 94 70 277 94 71 278 minecraft:red_concrete
fill 94 70 279 94 71 280 minecraft:white_concrete
fill 94 70 281 94 71 282 minecraft:red_concrete
fill 94 70 283 94 71 284 minecraft:white_concrete
fill 94 70 285 94 71 286 minecraft:red_concrete
fill 94 70 287 94 71 288 minecraft:white_concrete
fill 94 70 289 94 71 290 minecraft:red_concrete
fill 94 70 291 94 71 292 minecraft:white_concrete
fill 94 70 293 94 71 294 minecraft:red_concrete
fill 94 70 295 94 71 296 minecraft:white_concrete
fill 94 70 297 94 71 298 minecraft:red_concrete
fill 94 70 299 94 71 300 minecraft:white_concrete
fill 94 70 301 94 71 302 minecraft:red_concrete
fill 94 70 303 94 71 304 minecraft:white_concrete
fill 94 70 305 94 71 306 minecraft:red_concrete
fill 94 70 307 94 71 308 minecraft:white_concrete
fill 94 70 309 94 71 310 minecraft:red_concrete
fill 94 70 311 94 71 312 minecraft:white_concrete
fill 94 70 313 94 71 314 minecraft:red_concrete
fill 94 70 315 94 71 316 minecraft:white_concrete
fill 95 70 275 95 71 275 minecraft:white_concrete
fill 95 70 276 95 71 281 minecraft:red_terracotta
fill 95 70 284 96 70 289 minecraft:red_terracotta
fill 95 70 292 96 70 297 minecraft:red_terracotta
fill 95 70 300 96 70 305 minecraft:red_terracotta
fill 95 70 308 96 70 313 minecraft:red_terracotta
fill 95 70 316 100 71 316 minecraft:red_terracotta
fill 95 70 317 95 71 317 minecraft:white_concrete
fill 96 70 275 97 71 275 minecraft:red_concrete
fill 96 70 277 96 70 283 minecraft:red_terracotta
fill 96 70 290 96 70 291 minecraft:red_terracotta
fill 96 70 298 96 70 299 minecraft:red_terracotta
fill 96 70 306 96 70 307 minecraft:red_terracotta
fill 96 70 314 96 70 315 minecraft:red_terracotta
fill 96 70 317 97 71 317 minecraft:red_concrete
fill 97 70 277 134 70 277 minecraft:red_terracotta
fill 97 70 315 135 70 315 minecraft:red_terracotta
fill 98 70 275 99 71 275 minecraft:white_concrete
fill 98 70 276 103 71 276 minecraft:red_terracotta
fill 98 70 317 99 71 317 minecraft:white_concrete
fill 99 70 281 99 71 281 minecraft:brown_terracotta
fill 100 70 275 101 71 275 minecraft:red_concrete
fill 100 70 295 100 71 295 minecraft:brown_terracotta
fill 100 70 306 100 71 306 minecraft:brown_terracotta
fill 100 70 317 101 71 317 minecraft:red_concrete
fill 102 70 275 103 71 275 minecraft:white_concrete
fill 102 70 317 103 71 317 minecraft:white_concrete
fill 103 70 316 108 71 316 minecraft:red_terracotta
fill 104 70 275 105 71 275 minecraft:red_concrete
fill 104 70 317 105 71 317 minecraft:red_concrete
fill 106 70 275 107 71 275 minecraft:white_concrete
fill 106 70 276 111 71 276 minecraft:red_terracotta
fill 106 70 317 107 71 317 minecraft:white_concrete
fill 108 70 275 109 71 275 minecraft:red_concrete
fill 108 70 317 109 71 317 minecraft:red_concrete
fill 110 70 275 111 71 275 minecraft:white_concrete
fill 110 70 317 111 71 317 minecraft:white_concrete
fill 111 70 316 116 71 316 minecraft:red_terracotta
fill 112 70 275 113 71 275 minecraft:red_concrete
fill 112 70 317 113 71 317 minecraft:red_concrete
fill 114 70 275 115 71 275 minecraft:white_concrete
fill 114 70 276 119 71 276 minecraft:red_terracotta
fill 114 70 317 115 71 317 minecraft:white_concrete
fill 116 70 275 117 71 275 minecraft:red_concrete
fill 116 70 317 117 71 317 minecraft:red_concrete
fill 117 70 310 117 71 310 minecraft:brown_terracotta
fill 118 70 275 119 71 275 minecraft:white_concrete
fill 118 70 317 119 71 317 minecraft:white_concrete
fill 119 70 316 124 71 316 minecraft:red_terracotta
fill 120 70 275 121 71 275 minecraft:red_concrete
fill 120 70 317 121 71 317 minecraft:red_concrete
fill 122 70 275 123 71 275 minecraft:white_concrete
fill 122 70 276 127 71 276 minecraft:red_terracotta
fill 122 70 317 123 71 317 minecraft:white_concrete
fill 124 70 275 125 71 275 minecraft:red_concrete
fill 124 70 317 125 71 317 minecraft:red_concrete
fill 126 70 275 127 71 275 minecraft:white_concrete
fill 126 70 317 127 71 317 minecraft:white_concrete
fill 127 70 316 132 71 316 minecraft:red_terracotta
fill 128 70 275 129 71 275 minecraft:red_concrete
fill 128 70 317 129 71 317 minecraft:red_concrete
fill 130 70 275 131 71 275 minecraft:white_concrete
fill 130 70 276 135 71 276 minecraft:red_terracotta
fill 130 70 317 131 71 317 minecraft:white_concrete
fill 132 70 275 133 71 275 minecraft:red_concrete
fill 132 70 317 133 71 317 minecraft:red_concrete
fill 134 70 275 135 71 275 minecraft:white_concrete
fill 134 70 278 134 70 314 minecraft:red_terracotta
fill 134 70 317 135 71 317 minecraft:white_concrete
fill 135 70 279 135 71 284 minecraft:red_terracotta
fill 135 70 287 135 71 292 minecraft:red_terracotta
fill 135 70 295 135 71 300 minecraft:red_terracotta
fill 135 70 303 135 71 308 minecraft:red_terracotta
fill 135 70 311 135 71 314 minecraft:red_terracotta
fill 135 70 316 135 71 316 minecraft:red_terracotta
fill 136 70 276 136 71 276 minecraft:white_concrete
fill 136 70 277 136 71 278 minecraft:red_concrete
fill 136 70 279 136 71 280 minecraft:white_concrete
fill 136 70 281 136 71 282 minecraft:red_concrete
fill 136 70 283 136 71 284 minecraft:white_concrete
fill 136 70 285 136 71 286 minecraft:red_concrete
fill 136 70 287 136 71 288 minecraft:white_concrete
fill 136 70 289 136 71 290 minecraft:red_concrete
fill 136 70 291 136 71 292 minecraft:white_concrete
fill 136 70 293 136 71 294 minecraft:red_concrete
fill 136 70 295 136 71 296 minecraft:white_concrete
fill 136 70 297 136 71 298 minecraft:red_concrete
fill 136 70 299 136 71 300 minecraft:white_concrete
fill 136 70 301 136 71 302 minecraft:red_concrete
fill 136 70 303 136 71 304 minecraft:white_concrete
fill 136 70 305 136 71 306 minecraft:red_concrete
fill 136 70 307 136 71 308 minecraft:white_concrete
fill 136 70 309 136 71 310 minecraft:red_concrete
fill 136 70 311 136 71 312 minecraft:white_concrete
fill 136 70 313 136 71 314 minecraft:red_concrete
fill 136 70 315 136 71 316 minecraft:white_concrete
fill 136 70 317 136 71 317 minecraft:red_concrete
fill 95 71 284 95 71 289 minecraft:red_terracotta
fill 95 71 292 95 71 297 minecraft:red_terracotta
fill 95 71 300 95 71 305 minecraft:red_terracotta
fill 95 71 308 95 71 313 minecraft:red_terracotta
fill 99 71 280 99 72 280 minecraft:brown_terracotta
fill 99 71 295 99 72 295 minecraft:brown_terracotta
fill 99 71 306 99 72 306 minecraft:brown_terracotta
fill 117 71 311 117 72 311 minecraft:brown_terracotta
setblock 135 71 315 minecraft:red_terracotta
fill 94 72 275 94 73 276 minecraft:red_concrete
fill 94 72 277 94 73 278 minecraft:white_concrete
fill 94 72 279 94 73 280 minecraft:red_concrete
fill 94 72 281 94 73 282 minecraft:white_concrete
fill 94 72 283 94 73 284 minecraft:red_concrete
fill 94 72 285 94 73 286 minecraft:white_concrete
fill 94 72 287 94 73 288 minecraft:red_concrete
fill 94 72 289 94 73 290 minecraft:white_concrete
fill 94 72 291 94 73 292 minecraft:red_concrete
fill 94 72 293 94 73 294 minecraft:white_concrete
fill 94 72 295 94 73 296 minecraft:red_concrete
fill 94 72 297 94 73 298 minecraft:white_concrete
fill 94 72 299 94 73 300 minecraft:red_concrete
fill 94 72 301 94 73 302 minecraft:white_concrete
fill 94 72 303 94 73 304 minecraft:red_concrete
fill 94 72 305 94 73 306 minecraft:white_concrete
fill 94 72 307 94 73 308 minecraft:red_concrete
fill 94 72 309 94 73 310 minecraft:white_concrete
fill 94 72 311 94 73 312 minecraft:red_concrete
fill 94 72 313 94 73 314 minecraft:white_concrete
fill 94 72 315 94 73 316 minecraft:red_concrete
fill 95 72 275 95 73 275 minecraft:red_concrete
fill 95 72 317 95 73 317 minecraft:red_concrete
fill 96 72 275 97 73 275 minecraft:white_concrete
fill 96 72 317 97 73 317 minecraft:white_concrete
fill 98 72 275 99 73 275 minecraft:red_concrete
fill 98 72 295 98 73 295 minecraft:brown_terracotta
fill 98 72 306 98 73 306 minecraft:brown_terracotta
fill 98 72 317 99 73 317 minecraft:red_concrete
fill 99 72 279 99 73 279 minecraft:brown_terracotta
fill 100 72 275 101 73 275 minecraft:white_concrete
fill 100 72 317 101 73 317 minecraft:white_concrete
fill 102 72 275 103 73 275 minecraft:red_concrete
fill 102 72 317 103 73 317 minecraft:red_concrete
fill 104 72 275 105 73 275 minecraft:white_concrete
fill 104 72 317 105 73 317 minecraft:white_concrete
fill 106 72 275 107 73 275 minecraft:red_concrete
fill 106 72 317 107 73 317 minecraft:red_concrete
fill 108 72 275 109 73 275 minecraft:white_concrete
fill 108 72 317 109 73 317 minecraft:white_concrete
fill 110 72 275 111 73 275 minecraft:red_concrete
fill 110 72 317 111 73 317 minecraft:red_concrete
fill 112 72 275 113 73 275 minecraft:white_concrete
fill 112 72 317 113 73 317 minecraft:white_concrete
fill 114 72 275 115 73 275 minecraft:red_concrete
fill 114 72 317 115 73 317 minecraft:red_concrete
fill 116 72 275 117 73 275 minecraft:white_concrete
fill 116 72 317 117 73 317 minecraft:white_concrete
fill 117 72 312 117 73 312 minecraft:brown_terracotta
fill 118 72 275 119 73 275 minecraft:red_concrete
fill 118 72 317 119 73 317 minecraft:red_concrete
fill 120 72 275 121 73 275 minecraft:white_concrete
fill 120 72 317 121 73 317 minecraft:white_concrete
fill 122 72 275 123 73 275 minecraft:red_concrete
fill 122 72 317 123 73 317 minecraft:red_concrete
fill 124 72 275 125 73 275 minecraft:white_concrete
fill 124 72 317 125 73 317 minecraft:white_concrete
fill 126 72 275 127 73 275 minecraft:red_concrete
fill 126 72 317 127 73 317 minecraft:red_concrete
fill 128 72 275 129 73 275 minecraft:white_concrete
fill 128 72 317 129 73 317 minecraft:white_concrete
fill 130 72 275 131 73 275 minecraft:red_concrete
setblock 130 72 306 minecraft:red_terracotta
setblock 130 72 308 minecraft:red_terracotta
fill 130 72 317 131 73 317 minecraft:red_concrete
fill 131 72 285 131 72 287 minecraft:red_terracotta
fill 132 72 275 133 73 275 minecraft:white_concrete
fill 132 72 285 133 72 285 minecraft:red_terracotta
fill 132 72 287 133 72 287 minecraft:red_terracotta
setblock 132 72 306 minecraft:red_terracotta
setblock 132 72 308 minecraft:red_terracotta
fill 132 72 317 133 73 317 minecraft:white_concrete
setblock 133 72 286 minecraft:red_terracotta
fill 134 72 275 135 73 275 minecraft:red_concrete
fill 134 72 317 135 73 317 minecraft:red_concrete
fill 136 72 276 136 73 276 minecraft:red_concrete
fill 136 72 277 136 73 278 minecraft:white_concrete
fill 136 72 279 136 73 280 minecraft:red_concrete
fill 136 72 281 136 73 282 minecraft:white_concrete
fill 136 72 283 136 73 284 minecraft:red_concrete
fill 136 72 285 136 73 286 minecraft:white_concrete
fill 136 72 287 136 73 288 minecraft:red_concrete
fill 136 72 289 136 73 290 minecraft:white_concrete
fill 136 72 291 136 73 292 minecraft:red_concrete
fill 136 72 293 136 73 294 minecraft:white_concrete
fill 136 72 295 136 73 296 minecraft:red_concrete
fill 136 72 297 136 73 298 minecraft:white_concrete
fill 136 72 299 136 73 300 minecraft:red_concrete
fill 136 72 301 136 73 302 minecraft:white_concrete
fill 136 72 303 136 73 304 minecraft:red_concrete
fill 136 72 305 136 73 306 minecraft:white_concrete
fill 136 72 307 136 73 308 minecraft:red_concrete
fill 136 72 309 136 73 310 minecraft:white_concrete
fill 136 72 311 136 73 312 minecraft:red_concrete
fill 136 72 313 136 73 314 minecraft:white_concrete
fill 136 72 315 136 73 316 minecraft:red_concrete
fill 136 72 317 136 73 317 minecraft:white_concrete
fill 97 73 295 97 74 295 minecraft:brown_terracotta
fill 97 73 306 97 74 306 minecraft:brown_terracotta
fill 99 73 278 99 74 278 minecraft:brown_terracotta
fill 107 73 276 109 74 276 minecraft:red_terracotta
fill 107 73 315 108 74 316 minecraft:red_terracotta
fill 109 73 315 109 74 315 minecraft:red_terracotta
fill 117 73 313 117 74 313 minecraft:brown_terracotta
fill 128 73 311 128 73 313 minecraft:brown_terracotta
setblock 129 73 310 minecraft:brown_terracotta
fill 129 73 314 131 73 314 minecraft:brown_terracotta
setblock 131 73 310 minecraft:brown_terracotta
fill 132 73 311 132 73 313 minecraft:brown_terracotta
fill 94 74 275 94 75 276 minecraft:white_concrete
fill 94 74 277 94 75 278 minecraft:red_concrete
fill 94 74 279 94 75 279 minecraft:white_concrete
fill 94 74 280 94 79 280 minecraft:shroomlight
fill 94 74 281 94 75 282 minecraft:red_concrete
fill 94 74 283 94 75 284 minecraft:white_concrete
fill 94 74 285 94 75 286 minecraft:red_concrete
fill 94 74 287 94 75 287 minecraft:white_concrete
fill 94 74 288 94 79 288 minecraft:shroomlight
fill 94 74 289 94 75 290 minecraft:red_concrete
fill 94 74 291 94 75 292 minecraft:white_concrete
fill 94 74 293 94 75 294 minecraft:red_concrete
fill 94 74 295 94 75 295 minecraft:white_concrete
fill 94 74 296 94 79 296 minecraft:shroomlight
fill 94 74 297 94 75 298 minecraft:red_concrete
fill 94 74 299 94 75 300 minecraft:white_concrete
fill 94 74 301 94 75 302 minecraft:red_concrete
fill 94 74 303 94 75 303 minecraft:white_concrete
fill 94 74 304 94 79 304 minecraft:shroomlight
fill 94 74 305 94 75 306 minecraft:red_concrete
fill 94 74 307 94 75 308 minecraft:white_concrete
fill 94 74 309 94 75 310 minecraft:red_concrete
fill 94 74 311 94 75 311 minecraft:white_concrete
fill 94 74 312 94 79 312 minecraft:shroomlight
fill 94 74 313 94 75 314 minecraft:red_concrete
fill 94 74 315 94 75 316 minecraft:white_concrete
fill 95 74 275 95 75 275 minecraft:white_concrete
fill 95 74 317 95 75 317 minecraft:white_concrete
fill 96 74 275 97 75 275 minecraft:red_concrete
fill 96 74 295 96 75 295 minecraft:brown_terracotta
fill 96 74 306 96 75 306 minecraft:brown_terracotta
fill 96 74 317 96 75 317 minecraft:red_concrete
fill 97 74 317 97 79 317 minecraft:shroomlight
fill 98 74 275 99 75 275 minecraft:white_concrete
fill 98 74 317 99 75 317 minecraft:white_concrete
fill 99 74 277 99 75 277 minecraft:brown_terracotta
fill 100 74 275 100 75 275 minecraft:red_concrete
fill 100 74 317 101 75 317 minecraft:red_concrete
fill 101 74 275 101 79 275 minecraft:shroomlight
fill 102 74 275 103 75 275 minecraft:white_concrete
fill 102 74 317 103 75 317 minecraft:white_concrete
fill 104 74 275 105 75 275 minecraft:red_concrete
fill 104 74 317 104 75 317 minecraft:red_concrete
fill 105 74 317 105 79 317 minecraft:shroomlight
fill 106 74 275 107 75 275 minecraft:white_concrete
fill 106 74 317 107 75 317 minecraft:white_concrete
fill 107 74 277 109 75 277 minecraft:red_terracotta
fill 107 74 314 109 75 314 minecraft:red_terracotta
fill 108 74 275 108 75 275 minecraft:red_concrete
fill 108 74 278 108 77 278 minecraft:red_terracotta
fill 108 74 313 108 77 313 minecraft:red_terracotta
fill 108 74 317 109 75 317 minecraft:red_concrete
fill 109 74 275 109 79 275 minecraft:shroomlight
fill 110 74 275 111 75 275 minecraft:white_concrete
fill 110 74 317 111 75 317 minecraft:white_concrete
fill 112 74 275 113 75 275 minecraft:red_concrete
fill 112 74 317 112 75 317 minecraft:red_concrete
fill 113 74 317 113 79 317 minecraft:shroomlight
fill 114 74 275 115 75 275 minecraft:white_concrete
fill 114 74 317 115 75 317 minecraft:white_concrete
fill 116 74 275 116 75 275 minecraft:red_concrete
fill 116 74 317 117 75 317 minecraft:red_concrete
fill 117 74 275 117 79 275 minecraft:shroomlight
fill 117 74 314 117 75 314 minecraft:brown_terracotta
fill 118 74 275 119 75 275 minecraft:white_concrete
fill 118 74 317 119 75 317 minecraft:white_concrete
fill 120 74 275 121 75 275 minecraft:red_concrete
fill 120 74 317 120 75 317 minecraft:red_concrete
fill 121 74 317 121 79 317 minecraft:shroomlight
fill 122 74 275 123 75 275 minecraft:white_concrete
fill 122 74 317 123 75 317 minecraft:white_concrete
fill 124 74 275 124 75 275 minecraft:red_concrete
fill 124 74 317 125 75 317 minecraft:red_concrete
fill 125 74 275 125 79 275 minecraft:shroomlight
fill 126 74 275 127 75 275 minecraft:white_concrete
fill 126 74 317 127 75 317 minecraft:white_concrete
fill 128 74 275 129 75 275 minecraft:red_concrete
fill 128 74 317 128 75 317 minecraft:red_concrete
fill 129 74 317 129 79 317 minecraft:shroomlight
fill 130 74 275 131 75 275 minecraft:white_concrete
fill 130 74 317 131 75 317 minecraft:white_concrete
fill 132 74 275 132 75 275 minecraft:red_concrete
fill 132 74 317 133 75 317 minecraft:red_concrete
fill 133 74 275 133 79 275 minecraft:shroomlight
fill 133 74 286 134 75 286 minecraft:iron_block
fill 134 74 275 135 75 275 minecraft:white_concrete
fill 134 74 317 135 75 317 minecraft:white_concrete
fill 136 74 276 136 75 276 minecraft:white_concrete
fill 136 74 277 136 75 278 minecraft:red_concrete
fill 136 74 279 136 75 279 minecraft:white_concrete
fill 136 74 280 136 79 280 minecraft:shroomlight
fill 136 74 281 136 75 282 minecraft:red_concrete
fill 136 74 283 136 75 284 minecraft:white_concrete
fill 136 74 285 136 75 286 minecraft:red_concrete
fill 136 74 287 136 75 287 minecraft:white_concrete
fill 136 74 288 136 79 288 minecraft:shroomlight
fill 136 74 289 136 75 290 minecraft:red_concrete
fill 136 74 291 136 75 292 minecraft:white_concrete
fill 136 74 293 136 75 294 minecraft:red_concrete
fill 136 74 295 136 75 295 minecraft:white_concrete
fill 136 74 296 136 79 296 minecraft:shroomlight
fill 136 74 297 136 75 298 minecraft:red_concrete
fill 136 74 299 136 75 300 minecraft:white_concrete
fill 136 74 301 136 75 302 minecraft:red_concrete
fill 136 74 303 136 75 303 minecraft:white_concrete
fill 136 74 304 136 79 304 minecraft:shroomlight
fill 136 74 305 136 75 306 minecraft:red_concrete
fill 136 74 307 136 75 308 minecraft:white_concrete
fill 136 74 309 136 75 310 minecraft:red_concrete
fill 136 74 311 136 75 311 minecraft:white_concrete
fill 136 74 312 136 79 312 minecraft:shroomlight
fill 136 74 313 136 75 314 minecraft:red_concrete
fill 136 74 315 136 75 316 minecraft:white_concrete
fill 136 74 317 136 75 317 minecraft:red_concrete
fill 95 75 295 95 76 295 minecraft:brown_terracotta
setblock 97 75 278 minecraft:light[level=12]
setblock 97 75 285 minecraft:light[level=12]
setblock 97 75 292 minecraft:light[level=12]
setblock 97 75 299 minecraft:light[level=12]
setblock 97 75 306 minecraft:light[level=12]
setblock 97 75 313 minecraft:light[level=12]
fill 99 75 276 99 76 276 minecraft:brown_terracotta
setblock 104 75 278 minecraft:light[level=12]
setblock 104 75 285 minecraft:light[level=12]
setblock 104 75 292 minecraft:light[level=12]
setblock 104 75 299 minecraft:light[level=12]
setblock 104 75 306 minecraft:light[level=12]
setblock 104 75 313 minecraft:light[level=12]
fill 107 75 278 107 77 278 minecraft:red_terracotta
fill 107 75 313 107 76 313 minecraft:red_terracotta
setblock 108 75 276 minecraft:red_terracotta
fill 108 75 279 108 77 279 minecraft:red_terracotta
fill 108 75 312 108 77 312 minecraft:red_terracotta
setblock 108 75 315 minecraft:red_terracotta
setblock 108 75 316 minecraft:yellow_concrete
fill 109 75 278 109 76 278 minecraft:red_terracotta
fill 109 75 313 109 77 313 minecraft:red_terracotta
setblock 111 75 278 minecraft:light[level=12]
setblock 111 75 285 minecraft:light[level=12]
setblock 111 75 292 minecraft:light[level=12]
setblock 111 75 299 minecraft:light[level=12]
setblock 111 75 306 minecraft:light[level=12]
setblock 111 75 313 minecraft:light[level=12]
fill 117 75 315 117 76 315 minecraft:brown_terracotta
setblock 118 75 278 minecraft:light[level=12]
setblock 118 75 285 minecraft:light[level=12]
setblock 118 75 299 minecraft:light[level=12]
setblock 118 75 306 minecraft:light[level=12]
setblock 118 75 313 minecraft:light[level=12]
setblock 125 75 278 minecraft:light[level=12]
setblock 125 75 285 minecraft:light[level=12]
setblock 125 75 292 minecraft:light[level=12]
setblock 125 75 299 minecraft:light[level=12]
setblock 125 75 306 minecraft:light[level=12]
setblock 125 75 313 minecraft:light[level=12]
setblock 131 75 286 minecraft:shroomlight
setblock 132 75 278 minecraft:light[level=12]
setblock 132 75 285 minecraft:light[level=12]
setblock 132 75 292 minecraft:light[level=12]
setblock 132 75 299 minecraft:light[level=12]
setblock 132 75 306 minecraft:light[level=12]
setblock 132 75 313 minecraft:light[level=12]
fill 94 76 275 94 77 276 minecraft:red_concrete
fill 94 76 277 94 77 278 minecraft:white_concrete
fill 94 76 279 94 77 279 minecraft:red_concrete
fill 94 76 281 94 77 282 minecraft:white_concrete
fill 94 76 283 94 77 284 minecraft:red_concrete
fill 94 76 285 94 77 286 minecraft:white_concrete
fill 94 76 287 94 77 287 minecraft:red_concrete
fill 94 76 289 94 77 290 minecraft:white_concrete
fill 94 76 291 94 77 292 minecraft:red_concrete
fill 94 76 293 94 77 294 minecraft:white_concrete
fill 94 76 295 94 77 295 minecraft:red_concrete
fill 94 76 297 94 77 298 minecraft:white_concrete
fill 94 76 299 94 77 300 minecraft:red_concrete
fill 94 76 301 94 77 302 minecraft:white_concrete
fill 94 76 303 94 77 303 minecraft:red_concrete
fill 94 76 305 94 77 306 minecraft:white_concrete
fill 94 76 307 94 77 308 minecraft:red_concrete
fill 94 76 309 94 77 310 minecraft:white_concrete
fill 94 76 311 94 77 311 minecraft:red_concrete
fill 94 76 313 94 77 314 minecraft:white_concrete
fill 94 76 315 94 77 316 minecraft:red_concrete
fill 95 76 275 95 77 275 minecraft:red_concrete
fill 95 76 317 95 77 317 minecraft:red_concrete
fill 96 76 275 97 77 275 minecraft:white_concrete
fill 96 76 317 96 77 317 minecraft:white_concrete
fill 98 76 275 99 77 275 minecraft:red_concrete
fill 98 76 317 99 77 317 minecraft:red_concrete
fill 100 76 275 100 77 275 minecraft:white_concrete
setblock 100 76 281 minecraft:shroomlight
setblock 100 76 287 minecraft:shroomlight
setblock 100 76 293 minecraft:shroomlight
setblock 100 76 299 minecraft:shroomlight
setblock 100 76 305 minecraft:shroomlight
setblock 100 76 311 minecraft:shroomlight
fill 100 76 317 101 77 317 minecraft:white_concrete
fill 102 76 275 103 77 275 minecraft:red_concrete
fill 102 76 317 103 77 317 minecraft:red_concrete
fill 104 76 275 105 77 275 minecraft:white_concrete
fill 104 76 317 104 77 317 minecraft:white_concrete
fill 106 76 275 107 77 275 minecraft:red_concrete
setblock 106 76 281 minecraft:shroomlight
setblock 106 76 311 minecraft:shroomlight
fill 106 76 317 107 77 317 minecraft:red_concrete
fill 107 76 279 107 77 280 minecraft:red_terracotta
fill 107 76 311 107 77 312 minecraft:red_terracotta
fill 108 76 275 108 77 275 minecraft:white_concrete
setblock 108 76 276 minecraft:yellow_concrete
fill 108 76 277 108 77 277 minecraft:red_terracotta
fill 108 76 280 109 77 280 minecraft:red_terracotta
fill 108 76 311 109 77 311 minecraft:red_terracotta
fill 108 76 314 108 77 314 minecraft:red_terracotta
setblock 108 76 315 minecraft:yellow_concrete
fill 108 76 317 109 77 317 minecraft:white_concrete
fill 109 76 279 109 77 279 minecraft:red_terracotta
fill 109 76 312 109 77 312 minecraft:red_terracotta
fill 110 76 275 111 77 275 minecraft:red_concrete
fill 110 76 317 111 77 317 minecraft:red_concrete
fill 112 76 275 113 77 275 minecraft:white_concrete
setblock 112 76 281 minecraft:shroomlight
setblock 112 76 311 minecraft:shroomlight
fill 112 76 317 112 77 317 minecraft:white_concrete
fill 114 76 275 115 77 275 minecraft:red_concrete
fill 114 76 317 115 77 317 minecraft:red_concrete
fill 116 76 275 116 77 275 minecraft:white_concrete
fill 116 76 317 117 77 317 minecraft:white_concrete
fill 118 76 275 119 77 275 minecraft:red_concrete
setblock 118 76 281 minecraft:shroomlight
setblock 118 76 311 minecraft:shroomlight
fill 118 76 317 119 77 317 minecraft:red_concrete
fill 120 76 275 121 77 275 minecraft:white_concrete
fill 120 76 317 120 77 317 minecraft:white_concrete
fill 122 76 275 123 77 275 minecraft:red_concrete
fill 122 76 317 123 77 317 minecraft:red_concrete
fill 124 76 275 124 77 275 minecraft:white_concrete
setblock 124 76 281 minecraft:shroomlight
setblock 124 76 311 minecraft:shroomlight
fill 124 76 317 125 77 317 minecraft:white_concrete
fill 126 76 275 127 77 275 minecraft:red_concrete
fill 126 76 317 127 77 317 minecraft:red_concrete
fill 128 76 275 129 77 275 minecraft:white_concrete
fill 128 76 317 128 77 317 minecraft:white_concrete
fill 129 76 284 129 77 284 minecraft:yellow_wool
fill 129 76 311 129 77 313 minecraft:red_terracotta
fill 130 76 275 131 77 275 minecraft:red_concrete
setblock 130 76 281 minecraft:shroomlight
setblock 130 76 287 minecraft:shroomlight
setblock 130 76 293 minecraft:shroomlight
setblock 130 76 299 minecraft:shroomlight
setblock 130 76 305 minecraft:shroomlight
setblock 130 76 311 minecraft:shroomlight
fill 130 76 312 131 102 313 minecraft:red_terracotta
fill 130 76 317 131 77 317 minecraft:red_concrete
fill 131 76 311 131 102 311 minecraft:red_terracotta
fill 132 76 275 132 77 275 minecraft:white_concrete
fill 132 76 317 133 77 317 minecraft:white_concrete
fill 134 76 275 135 77 275 minecraft:red_concrete
fill 134 76 317 135 77 317 minecraft:red_concrete
fill 136 76 276 136 77 276 minecraft:red_concrete
fill 136 76 277 136 77 278 minecraft:white_concrete
fill 136 76 279 136 77 279 minecraft:red_concrete
fill 136 76 281 136 77 282 minecraft:white_concrete
fill 136 76 283 136 77 284 minecraft:red_concrete
fill 136 76 285 136 77 286 minecraft:white_concrete
fill 136 76 287 136 77 287 minecraft:red_concrete
fill 136 76 289 136 77 290 minecraft:white_concrete
fill 136 76 291 136 77 292 minecraft:red_concrete
fill 136 76 293 136 77 294 minecraft:white_concrete
fill 136 76 295 136 77 295 minecraft:red_concrete
fill 136 76 297 136 77 298 minecraft:white_concrete
fill 136 76 299 136 77 300 minecraft:red_concrete
fill 136 76 301 136 77 302 minecraft:white_concrete
fill 136 76 303 136 77 303 minecraft:red_concrete
fill 136 76 305 136 77 306 minecraft:white_concrete
fill 136 76 307 136 77 308 minecraft:red_concrete
fill 136 76 309 136 77 310 minecraft:white_concrete
fill 136 76 311 136 77 311 minecraft:red_concrete
fill 136 76 313 136 77 314 minecraft:white_concrete
fill 136 76 315 136 77 316 minecraft:red_concrete
fill 136 76 317 136 77 317 minecraft:white_concrete
setblock 95 77 276 minecraft:red_terracotta
fill 95 77 278 95 77 279 minecraft:red_terracotta
fill 95 77 281 96 77 281 minecraft:red_terracotta
fill 95 77 284 95 77 285 minecraft:red_terracotta
fill 95 77 287 95 77 288 minecraft:red_terracotta
fill 95 77 293 95 77 294 minecraft:red_terracotta
fill 95 77 296 95 77 297 minecraft:red_terracotta
setblock 95 77 300 minecraft:red_terracotta
fill 95 77 302 95 77 303 minecraft:red_terracotta
fill 95 77 305 96 77 305 minecraft:red_terracotta
fill 95 77 308 95 77 309 minecraft:red_terracotta
fill 95 77 311 95 77 312 minecraft:red_terracotta
fill 96 77 277 96 77 278 minecraft:red_terracotta
fill 96 77 280 97 77 280 minecraft:red_terracotta
fill 96 77 283 96 77 284 minecraft:red_terracotta
fill 96 77 286 96 77 287 minecraft:red_terracotta
fill 96 77 289 96 77 290 minecraft:red_terracotta
fill 96 77 292 96 77 293 minecraft:red_terracotta
fill 96 77 295 96 77 296 minecraft:red_terracotta
fill 96 77 298 96 77 299 minecraft:red_terracotta
fill 96 77 301 96 77 302 minecraft:red_terracotta
fill 96 77 304 97 77 304 minecraft:red_terracotta
fill 96 77 307 96 77 308 minecraft:red_terracotta
fill 96 77 310 96 77 311 minecraft:red_terracotta
fill 96 77 313 96 77 314 minecraft:red_terracotta
fill 96 77 316 97 77 316 minecraft:red_terracotta
setblock 97 77 277 minecraft:red_terracotta
setblock 97 77 278 minecraft:light[level=15]
fill 97 77 279 98 77 279 minecraft:red_terracotta
fill 97 77 282 97 77 283 minecraft:red_terracotta
fill 97 77 285 97 77 286 minecraft:red_terracotta
fill 97 77 288 97 77 289 minecraft:red_terracotta
fill 97 77 291 97 77 292 minecraft:red_terracotta
fill 97 77 294 97 77 295 minecraft:red_terracotta
fill 97 77 297 97 77 298 minecraft:red_terracotta
fill 97 77 300 97 77 301 minecraft:red_terracotta
setblock 97 77 302 minecraft:light[level=15]
fill 97 77 303 98 77 303 minecraft:red_terracotta
fill 97 77 306 97 77 307 minecraft:red_terracotta
fill 97 77 309 97 77 310 minecraft:red_terracotta
fill 97 77 312 97 77 313 minecraft:red_terracotta
fill 97 77 315 98 77 315 minecraft:red_terracotta
setblock 98 77 276 minecraft:red_terracotta
fill 98 77 278 99 77 278 minecraft:red_terracotta
fill 98 77 281 98 77 282 minecraft:red_terracotta
fill 98 77 284 98 77 285 minecraft:red_terracotta
fill 98 77 287 98 77 288 minecraft:red_terracotta
fill 98 77 290 98 77 291 minecraft:red_terracotta
fill 98 77 293 98 77 294 minecraft:red_terracotta
fill 98 77 296 98 77 297 minecraft:red_terracotta
fill 98 77 299 98 77 300 minecraft:red_terracotta
fill 98 77 302 99 77 302 minecraft:red_terracotta
fill 98 77 305 98 77 306 minecraft:red_terracotta
fill 98 77 308 98 77 309 minecraft:red_terracotta
fill 98 77 311 98 77 312 minecraft:red_terracotta
fill 98 77 314 99 77 314 minecraft:red_terracotta
fill 99 77 277 100 77 277 minecraft:red_terracotta
fill 99 77 280 99 77 281 minecraft:red_terracotta
fill 99 77 283 99 77 284 minecraft:red_terracotta
fill 99 77 286 99 77 287 minecraft:red_terracotta
fill 99 77 289 99 77 290 minecraft:red_terracotta
fill 99 77 292 99 77 293 minecraft:red_terracotta
fill 99 77 295 99 77 296 minecraft:red_terracotta
fill 99 77 298 99 77 299 minecraft:red_terracotta
fill 99 77 301 100 77 301 minecraft:red_terracotta
fill 99 77 304 99 77 305 minecraft:red_terracotta
fill 99 77 307 99 77 308 minecraft:red_terracotta
fill 99 77 310 99 77 311 minecraft:red_terracotta
fill 99 77 313 100 77 313 minecraft:red_terracotta
fill 99 77 316 100 77 316 minecraft:red_terracotta
fill 100 77 276 101 77 276 minecraft:red_terracotta
fill 100 77 279 100 77 280 minecraft:red_terracotta
fill 100 77 282 100 77 283 minecraft:red_terracotta
fill 100 77 285 100 77 286 minecraft:red_terracotta
fill 100 77 288 100 77 289 minecraft:red_terracotta
fill 100 77 291 100 77 292 minecraft:red_terracotta
fill 100 77 294 100 77 295 minecraft:red_terracotta
fill 100 77 297 100 77 298 minecraft:red_terracotta
setblock 100 77 300 minecraft:red_terracotta
fill 100 77 303 100 77 304 minecraft:red_terracotta
fill 100 77 306 100 77 307 minecraft:red_terracotta
fill 100 77 309 100 77 310 minecraft:red_terracotta
fill 100 77 312 101 77 312 minecraft:red_terracotta
fill 100 77 315 101 77 315 minecraft:red_terracotta
fill 101 77 278 101 77 279 minecraft:red_terracotta
fill 101 77 281 102 77 281 minecraft:red_terracotta
fill 101 77 311 102 77 311 minecraft:red_terracotta
fill 101 77 314 102 77 314 minecraft:red_terracotta
fill 102 77 277 102 77 278 minecraft:red_terracotta
fill 102 77 280 103 77 280 minecraft:red_terracotta
fill 102 77 313 103 77 313 minecraft:red_terracotta
fill 103 77 276 103 77 277 minecraft:red_terracotta
fill 103 77 279 104 77 279 minecraft:red_terracotta
fill 103 77 312 104 77 312 minecraft:red_terracotta
fill 103 77 315 103 77 316 minecraft:red_terracotta
fill 104 77 278 105 77 278 minecraft:red_terracotta
fill 104 77 281 105 77 281 minecraft:red_terracotta
fill 104 77 311 105 77 311 minecraft:red_terracotta
fill 104 77 314 104 77 315 minecraft:red_terracotta
fill 105 77 277 106 77 277 minecraft:red_terracotta
fill 105 77 280 106 77 280 minecraft:red_terracotta
setblock 105 77 286 minecraft:light[level=15]
setblock 105 77 294 minecraft:light[level=15]
setblock 105 77 302 minecraft:light[level=15]
setblock 105 77 310 minecraft:light[level=15]
fill 105 77 313 105 77 314 minecraft:red_terracotta
fill 105 77 316 106 77 316 minecraft:red_terracotta
fill 106 77 276 107 77 276 minecraft:red_terracotta
setblock 106 77 279 minecraft:red_terracotta
fill 106 77 312 106 77 313 minecraft:red_terracotta
fill 106 77 315 107 77 315 minecraft:red_terracotta
fill 107 77 281 111 77 281 minecraft:red_terracotta
fill 107 77 310 109 78 310 minecraft:red_terracotta
setblock 107 77 314 minecraft:red_terracotta
fill 108 77 282 108 79 282 minecraft:red_terracotta
fill 108 77 309 108 79 309 minecraft:red_terracotta
setblock 108 77 316 minecraft:red_terracotta
fill 109 77 276 109 77 277 minecraft:red_terracotta
fill 109 77 315 110 77 315 minecraft:red_terracotta
setblock 110 77 276 minecraft:red_terracotta
fill 110 77 278 110 77 279 minecraft:red_terracotta
fill 110 77 311 110 77 312 minecraft:red_terracotta
fill 110 77 314 111 77 314 minecraft:red_terracotta
fill 111 77 277 111 77 278 minecraft:red_terracotta
fill 111 77 280 112 77 280 minecraft:red_terracotta
setblock 111 77 311 minecraft:red_terracotta
fill 111 77 313 112 77 313 minecraft:red_terracotta
fill 111 77 316 112 77 316 minecraft:red_terracotta
setblock 112 77 277 minecraft:red_terracotta
fill 112 77 279 113 77 279 minecraft:red_terracotta
fill 112 77 312 113 77 312 minecraft:red_terracotta
fill 112 77 315 113 77 315 minecraft:red_terracotta
fill 113 77 278 114 77 278 minecraft:red_terracotta
fill 113 77 281 114 77 281 minecraft:red_terracotta
setblock 113 77 286 minecraft:light[level=15]
setblock 113 77 294 minecraft:light[level=15]
setblock 113 77 302 minecraft:light[level=15]
setblock 113 77 310 minecraft:light[level=15]
fill 113 77 311 114 77 311 minecraft:red_terracotta
fill 113 77 314 114 77 314 minecraft:red_terracotta
fill 114 77 277 115 77 277 minecraft:red_terracotta
fill 114 77 280 115 77 280 minecraft:red_terracotta
fill 114 77 313 115 77 313 minecraft:red_terracotta
fill 114 77 316 115 77 316 minecraft:red_terracotta
fill 115 77 276 116 77 276 minecraft:red_terracotta
fill 115 77 279 116 77 279 minecraft:red_terracotta
fill 115 77 312 116 77 312 minecraft:red_terracotta
fill 115 77 315 116 77 315 minecraft:red_terracotta
fill 116 77 278 117 77 278 minecraft:red_terracotta
fill 116 77 281 117 77 281 minecraft:red_terracotta
fill 116 77 311 117 77 311 minecraft:red_terracotta
fill 116 77 314 117 77 314 minecraft:red_terracotta
fill 117 77 277 118 77 277 minecraft:red_terracotta
fill 117 77 280 118 77 280 minecraft:red_terracotta
fill 117 77 313 118 77 313 minecraft:red_terracotta
fill 118 77 276 119 77 276 minecraft:red_terracotta
fill 118 77 279 119 77 279 minecraft:red_terracotta
fill 118 77 312 119 77 312 minecraft:red_terracotta
fill 118 77 315 119 77 315 minecraft:red_terracotta
fill 119 77 278 120 77 278 minecraft:red_terracotta
fill 119 77 281 120 77 281 minecraft:red_terracotta
fill 119 77 311 120 77 311 minecraft:red_terracotta
fill 119 77 314 120 77 314 minecraft:red_terracotta
fill 120 77 277 121 77 277 minecraft:red_terracotta
fill 120 77 280 121 77 280 minecraft:red_terracotta
fill 120 77 313 121 77 313 minecraft:red_terracotta
fill 120 77 316 121 77 316 minecraft:red_terracotta
setblock 121 77 278 minecraft:light[level=15]
fill 121 77 279 122 77 279 minecraft:red_terracotta
setblock 121 77 286 minecraft:light[level=15]
setblock 121 77 294 minecraft:light[level=15]
setblock 121 77 302 minecraft:light[level=15]
setblock 121 77 310 minecraft:light[level=15]
fill 121 77 312 122 77 312 minecraft:red_terracotta
fill 121 77 315 122 77 315 minecraft:red_terracotta
setblock 122 77 276 minecraft:red_terracotta
fill 122 77 278 123 77 278 minecraft:red_terracotta
fill 122 77 281 123 77 281 minecraft:red_terracotta
fill 122 77 311 123 77 311 minecraft:red_terracotta
fill 122 77 314 123 77 314 minecraft:red_terracotta
fill 123 77 277 124 77 277 minecraft:red_terracotta
fill 123 77 280 124 77 280 minecraft:red_terracotta
fill 123 77 313 124 77 313 minecraft:red_terracotta
fill 123 77 316 124 77 316 minecraft:red_terracotta
fill 124 77 276 125 77 276 minecraft:red_terracotta
fill 124 77 279 125 77 279 minecraft:red_terracotta
fill 124 77 312 125 77 312 minecraft:red_terracotta
fill 124 77 315 125 77 315 minecraft:red_terracotta
fill 125 77 278 126 77 278 minecraft:red_terracotta
fill 125 77 281 126 77 281 minecraft:red_terracotta
fill 125 77 311 126 77 311 minecraft:red_terracotta
fill 125 77 314 126 77 314 minecraft:red_terracotta
fill 126 77 277 127 77 277 minecraft:red_terracotta
fill 126 77 280 127 77 280 minecraft:red_terracotta
fill 126 77 313 127 77 313 minecraft:red_terracotta
setblock 127 77 276 minecraft:red_terracotta
fill 127 77 279 128 77 279 minecraft:red_terracotta
fill 127 77 312 128 77 312 minecraft:red_terracotta
fill 127 77 315 127 77 316 minecraft:red_terracotta
fill 128 77 278 129 77 278 minecraft:red_terracotta
fill 128 77 281 129 77 281 minecraft:red_terracotta
setblock 128 77 311 minecraft:red_terracotta
fill 128 77 314 128 77 315 minecraft:red_terracotta
fill 129 77 277 130 77 277 minecraft:red_terracotta
fill 129 77 280 130 77 280 minecraft:red_terracotta
setblock 129 77 286 minecraft:light[level=15]
setblock 129 77 294 minecraft:light[level=15]
setblock 129 77 302 minecraft:light[level=15]
setblock 129 77 310 minecraft:light[level=15]
setblock 129 77 314 minecraft:red_terracotta
fill 129 77 316 130 77 316 minecraft:red_terracotta
fill 130 77 276 131 77 276 minecraft:red_terracotta
fill 130 77 279 131 77 279 minecraft:red_terracotta
fill 130 77 282 130 77 283 minecraft:red_terracotta
fill 130 77 285 133 77 286 minecraft:red_terracotta
fill 130 77 288 130 77 289 minecraft:red_terracotta
fill 130 77 291 130 77 292 minecraft:red_terracotta
fill 130 77 294 130 77 295 minecraft:red_terracotta
fill 130 77 297 130 77 298 minecraft:red_terracotta
fill 130 77 300 130 77 301 minecraft:red_terracotta
fill 130 77 303 130 77 304 minecraft:red_terracotta
fill 130 77 306 130 77 309 minecraft:red_terracotta
setblock 130 77 311 minecraft:red_terracotta
fill 130 77 315 131 77 315 minecraft:red_terracotta
fill 131 77 278 132 77 278 minecraft:red_terracotta
fill 131 77 281 131 77 282 minecraft:red_terracotta
fill 131 77 284 132 77 284 minecraft:red_terracotta
fill 131 77 287 131 77 288 minecraft:red_terracotta
fill 131 77 290 131 77 291 minecraft:red_terracotta
fill 131 77 293 131 77 294 minecraft:red_terracotta
fill 131 77 296 131 77 297 minecraft:red_terracotta
fill 131 77 299 131 77 300 minecraft:red_terracotta
fill 131 77 302 131 77 303 minecraft:red_terracotta
fill 131 77 305 132 77 306 minecraft:red_terracotta
fill 131 77 308 131 77 309 minecraft:red_terracotta
fill 131 77 314 132 77 314 minecraft:red_terracotta
fill 132 77 277 133 77 277 minecraft:red_terracotta
fill 132 77 280 132 77 281 minecraft:red_terracotta
fill 132 77 283 133 77 283 minecraft:red_terracotta
fill 132 77 287 135 77 287 minecraft:red_terracotta
fill 132 77 289 132 77 290 minecraft:red_terracotta
fill 132 77 292 132 77 293 minecraft:red_terracotta
fill 132 77 295 132 77 296 minecraft:red_terracotta
fill 132 77 298 132 77 299 minecraft:red_terracotta
fill 132 77 301 132 77 302 minecraft:red_terracotta
fill 132 77 304 133 77 304 minecraft:red_terracotta
fill 132 77 307 132 77 308 minecraft:red_terracotta
fill 132 77 310 132 77 311 minecraft:red_terracotta
fill 132 77 313 133 77 313 minecraft:red_terracotta
setblock 132 77 316 minecraft:red_terracotta
fill 133 77 276 134 77 276 minecraft:red_terracotta
fill 133 77 279 133 77 280 minecraft:red_terracotta
fill 133 77 282 134 77 282 minecraft:red_terracotta
fill 133 77 288 133 77 289 minecraft:red_terracotta
fill 133 77 291 133 77 292 minecraft:red_terracotta
fill 133 77 294 133 77 295 minecraft:red_terracotta
fill 133 77 297 133 77 298 minecraft:red_terracotta
fill 133 77 300 133 77 301 minecraft:red_terracotta
fill 133 77 303 134 77 303 minecraft:red_terracotta
fill 133 77 306 133 77 307 minecraft:red_terracotta
fill 133 77 309 133 77 310 minecraft:red_terracotta
fill 133 77 312 134 77 312 minecraft:red_terracotta
fill 133 77 315 134 77 315 minecraft:red_terracotta
fill 134 77 278 134 77 279 minecraft:red_terracotta
fill 134 77 281 135 77 281 minecraft:red_terracotta
fill 134 77 284 134 77 285 minecraft:red_terracotta
setblock 134 77 288 minecraft:red_terracotta
fill 134 77 290 134 77 291 minecraft:red_terracotta
fill 134 77 293 134 77 294 minecraft:red_terracotta
fill 134 77 296 134 77 297 minecraft:red_terracotta
fill 134 77 299 134 77 300 minecraft:red_terracotta
setblock 134 77 302 minecraft:red_terracotta
fill 134 77 305 134 77 306 minecraft:red_terracotta
fill 134 77 308 134 77 309 minecraft:red_terracotta
fill 134 77 311 135 77 311 minecraft:red_terracotta
fill 134 77 314 135 77 314 minecraft:red_terracotta
setblock 135 77 280 minecraft:red_terracotta
fill 135 77 283 135 77 284 minecraft:red_terracotta
fill 135 77 289 135 77 290 minecraft:red_terracotta
setblock 135 77 292 minecraft:red_terracotta
fill 135 77 295 135 77 296 minecraft:red_terracotta
fill 135 77 298 135 77 299 minecraft:red_terracotta
fill 135 77 304 135 77 305 minecraft:red_terracotta
fill 135 77 307 135 77 308 minecraft:red_terracotta
setblock 135 77 313 minecraft:red_terracotta
setblock 135 77 316 minecraft:red_terracotta
fill 94 78 275 94 79 276 minecraft:white_concrete
fill 94 78 277 94 79 278 minecraft:red_concrete
fill 94 78 279 94 79 279 minecraft:white_concrete
fill 94 78 281 94 79 282 minecraft:red_concrete
fill 94 78 283 94 79 284 minecraft:white_concrete
fill 94 78 285 94 79 286 minecraft:red_concrete
fill 94 78 287 94 79 287 minecraft:white_concrete
fill 94 78 289 94 79 290 minecraft:red_concrete
fill 94 78 291 94 79 292 minecraft:white_concrete
fill 94 78 293 94 79 294 minecraft:red_concrete
fill 94 78 295 94 79 295 minecraft:white_concrete
fill 94 78 297 94 79 298 minecraft:red_concrete
fill 94 78 299 94 79 300 minecraft:white_concrete
fill 94 78 301 94 79 302 minecraft:red_concrete
fill 94 78 303 94 79 303 minecraft:white_concrete
fill 94 78 305 94 79 306 minecraft:red_concrete
fill 94 78 307 94 79 308 minecraft:white_concrete
fill 94 78 309 94 79 310 minecraft:red_concrete
fill 94 78 311 94 79 311 minecraft:white_concrete
fill 94 78 313 94 79 314 minecraft:red_concrete
fill 94 78 315 94 79 316 minecraft:white_concrete
fill 95 78 275 95 79 275 minecraft:white_concrete
fill 95 78 317 95 79 317 minecraft:white_concrete
fill 96 78 275 97 79 275 minecraft:red_concrete
fill 96 78 317 96 79 317 minecraft:red_concrete
fill 98 78 275 99 79 275 minecraft:white_concrete
fill 98 78 317 99 79 317 minecraft:white_concrete
fill 100 78 275 100 79 275 minecraft:red_concrete
fill 100 78 281 100 78 311 minecraft:yellow_concrete
fill 100 78 317 101 79 317 minecraft:red_concrete
fill 101 78 281 130 78 281 minecraft:yellow_concrete
fill 101 78 311 130 78 311 minecraft:yellow_concrete
fill 102 78 275 103 79 275 minecraft:white_concrete
fill 102 78 317 103 79 317 minecraft:white_concrete
fill 104 78 275 105 79 275 minecraft:red_concrete
fill 104 78 317 104 79 317 minecraft:red_concrete
fill 106 78 275 107 79 275 minecraft:white_concrete
fill 106 78 317 107 79 317 minecraft:white_concrete
fill 107 78 282 107 79 282 minecraft:red_terracotta
fill 107 78 309 107 79 309 minecraft:red_terracotta
fill 108 78 275 108 79 275 minecraft:red_concrete
setblock 108 78 279 minecraft:yellow_concrete
setblock 108 78 280 minecraft:red_terracotta
fill 108 78 283 108 80 283 minecraft:red_terracotta
fill 108 78 308 108 80 308 minecraft:red_terracotta
setblock 108 78 312 minecraft:yellow_concrete
fill 108 78 317 109 79 317 minecraft:red_concrete
fill 109 78 282 109 79 282 minecraft:red_terracotta
fill 109 78 309 109 79 309 minecraft:red_terracotta
fill 110 78 275 111 79 275 minecraft:white_concrete
fill 110 78 317 111 79 317 minecraft:white_concrete
fill 112 78 275 113 79 275 minecraft:red_concrete
fill 112 78 317 112 79 317 minecraft:red_concrete
fill 114 78 275 115 79 275 minecraft:white_concrete
fill 114 78 317 115 79 317 minecraft:white_concrete
fill 116 78 275 116 79 275 minecraft:red_concrete
fill 116 78 317 117 79 317 minecraft:red_concrete
fill 118 78 275 119 79 275 minecraft:white_concrete
fill 118 78 317 119 79 317 minecraft:white_concrete
fill 120 78 275 121 79 275 minecraft:red_concrete
fill 120 78 317 120 79 317 minecraft:red_concrete
fill 122 78 275 123 79 275 minecraft:white_concrete
fill 122 78 317 123 79 317 minecraft:white_concrete
fill 124 78 275 124 79 275 minecraft:red_concrete
fill 124 78 317 125 79 317 minecraft:red_concrete
fill 126 78 275 127 79 275 minecraft:white_concrete
fill 126 78 317 127 79 317 minecraft:white_concrete
fill 128 78 275 129 79 275 minecraft:red_concrete
fill 128 78 317 128 79 317 minecraft:red_concrete
fill 129 78 312 129 102 313 minecraft:red_terracotta
fill 130 78 275 131 79 275 minecraft:white_concrete
fill 130 78 282 130 78 310 minecraft:yellow_concrete
fill 130 78 317 131 79 317 minecraft:white_concrete
fill 131 78 306 131 102 306 minecraft:iron_block
fill 131 78 308 131 102 308 minecraft:iron_block
fill 132 78 275 132 79 275 minecraft:red_concrete
fill 132 78 286 132 102 286 minecraft:iron_block
fill 132 78 307 132 102 307 minecraft:iron_block
fill 132 78 317 133 79 317 minecraft:red_concrete
fill 134 78 275 135 79 275 minecraft:white_concrete
fill 134 78 317 135 79 317 minecraft:white_concrete
fill 136 78 276 136 79 276 minecraft:white_concrete
fill 136 78 277 136 79 278 minecraft:red_concrete
fill 136 78 279 136 79 279 minecraft:white_concrete
fill 136 78 281 136 79 282 minecraft:red_concrete
fill 136 78 283 136 79 284 minecraft:white_concrete
fill 136 78 285 136 79 286 minecraft:red_concrete
fill 136 78 287 136 79 287 minecraft:white_concrete
fill 136 78 289 136 79 290 minecraft:red_concrete
fill 136 78 291 136 79 292 minecraft:white_concrete
fill 136 78 293 136 79 294 minecraft:red_concrete
fill 136 78 295 136 79 295 minecraft:white_concrete
fill 136 78 297 136 79 298 minecraft:red_concrete
fill 136 78 299 136 79 300 minecraft:white_concrete
fill 136 78 301 136 79 302 minecraft:red_concrete
fill 136 78 303 136 79 303 minecraft:white_concrete
fill 136 78 305 136 79 306 minecraft:red_concrete
fill 136 78 307 136 79 308 minecraft:white_concrete
fill 136 78 309 136 79 310 minecraft:red_concrete
fill 136 78 311 136 79 311 minecraft:white_concrete
fill 136 78 313 136 79 314 minecraft:red_concrete
fill 136 78 315 136 79 316 minecraft:white_concrete
fill 136 78 317 136 79 317 minecraft:red_concrete
fill 106 79 302 106 80 303 minecraft:green_concrete
fill 107 79 283 107 79 284 minecraft:red_terracotta
fill 107 79 307 107 79 308 minecraft:red_terracotta
setblock 108 79 280 minecraft:yellow_concrete
setblock 108 79 281 minecraft:red_terracotta
fill 108 79 284 108 81 285 minecraft:red_terracotta
fill 108 79 306 108 81 307 minecraft:red_terracotta
setblock 108 79 310 minecraft:red_terracotta
setblock 108 79 311 minecraft:yellow_concrete
fill 109 79 283 109 79 284 minecraft:red_terracotta
fill 109 79 307 109 79 308 minecraft:red_terracotta
fill 129 79 311 130 102 311 minecraft:red_terracotta
fill 130 79 300 130 80 300 minecraft:red_concrete
fill 130 79 307 130 102 307 minecraft:iron_block
fill 130 79 310 130 102 310 minecraft:red_terracotta
fill 94 80 275 94 81 276 minecraft:red_concrete
fill 94 80 277 94 81 278 minecraft:white_concrete
fill 94 80 279 94 81 280 minecraft:red_concrete
fill 94 80 281 94 81 282 minecraft:white_concrete
fill 94 80 283 94 81 284 minecraft:red_concrete
fill 94 80 285 94 81 286 minecraft:white_concrete
fill 94 80 287 94 81 288 minecraft:red_concrete
fill 94 80 289 94 81 290 minecraft:white_concrete
fill 94 80 291 94 81 292 minecraft:red_concrete
fill 94 80 293 94 81 294 minecraft:white_concrete
fill 94 80 295 94 81 296 minecraft:red_concrete
fill 94 80 297 94 81 298 minecraft:white_concrete
fill 94 80 299 94 81 300 minecraft:red_concrete
fill 94 80 301 94 81 302 minecraft:white_concrete
fill 94 80 303 94 81 304 minecraft:red_concrete
fill 94 80 305 94 81 306 minecraft:white_concrete
fill 94 80 307 94 81 308 minecraft:red_concrete
fill 94 80 309 94 81 310 minecraft:white_concrete
fill 94 80 311 94 81 312 minecraft:red_concrete
fill 94 80 313 94 81 314 minecraft:white_concrete
fill 94 80 315 94 81 316 minecraft:red_concrete
fill 95 80 275 95 81 275 minecraft:red_concrete
fill 95 80 317 95 81 317 minecraft:red_concrete
fill 96 80 275 97 81 275 minecraft:white_concrete
fill 96 80 317 97 81 317 minecraft:white_concrete
fill 98 80 275 99 81 275 minecraft:red_concrete
fill 98 80 317 99 81 317 minecraft:red_concrete
fill 100 80 275 101 81 275 minecraft:white_concrete
fill 100 80 317 101 81 317 minecraft:white_concrete
fill 102 80 275 103 81 275 minecraft:red_concrete
fill 102 80 317 103 81 317 minecraft:red_concrete
fill 104 80 275 105 81 275 minecraft:white_concrete
fill 104 80 317 105 81 317 minecraft:white_concrete
fill 106 80 275 107 81 275 minecraft:red_concrete
fill 106 80 317 107 81 317 minecraft:red_concrete
fill 107 80 284 107 80 286 minecraft:red_terracotta
fill 107 80 305 107 80 307 minecraft:red_terracotta
fill 108 80 275 109 81 275 minecraft:white_concrete
setblock 108 80 282 minecraft:yellow_concrete
fill 108 80 286 108 82 287 minecraft:red_terracotta
fill 108 80 304 108 82 305 minecraft:red_terracotta
setblock 108 80 309 minecraft:yellow_concrete
fill 108 80 317 109 81 317 minecraft:white_concrete
fill 109 80 284 109 80 286 minecraft:red_terracotta
fill 109 80 305 109 80 307 minecraft:red_terracotta
fill 110 80 275 111 81 275 minecraft:red_concrete
fill 110 80 317 111 81 317 minecraft:red_concrete
fill 112 80 275 113 81 275 minecraft:white_concrete
fill 112 80 317 113 81 317 minecraft:white_concrete
fill 114 80 275 115 81 275 minecraft:red_concrete
fill 114 80 317 115 81 317 minecraft:red_concrete
fill 116 80 275 117 81 275 minecraft:white_concrete
fill 116 80 317 117 81 317 minecraft:white_concrete
fill 118 80 275 119 81 275 minecraft:red_concrete
fill 118 80 317 119 81 317 minecraft:red_concrete
fill 120 80 275 121 81 275 minecraft:white_concrete
fill 120 80 317 121 81 317 minecraft:white_concrete
fill 122 80 275 123 81 275 minecraft:red_concrete
fill 122 80 317 123 81 317 minecraft:red_concrete
fill 124 80 275 125 81 275 minecraft:white_concrete
fill 124 80 317 125 81 317 minecraft:white_concrete
fill 126 80 275 127 81 275 minecraft:red_concrete
fill 126 80 317 127 81 317 minecraft:red_concrete
fill 128 80 275 129 81 275 minecraft:white_concrete
fill 128 80 317 129 81 317 minecraft:white_concrete
fill 130 80 275 131 81 275 minecraft:red_concrete
fill 130 80 317 131 81 317 minecraft:red_concrete
fill 132 80 275 133 81 275 minecraft:white_concrete
fill 132 80 317 133 81 317 minecraft:white_concrete
fill 134 80 275 135 81 275 minecraft:red_concrete
fill 134 80 317 135 81 317 minecraft:red_concrete
fill 136 80 276 136 81 276 minecraft:red_concrete
fill 136 80 277 136 81 278 minecraft:white_concrete
fill 136 80 279 136 81 280 minecraft:red_concrete
fill 136 80 281 136 81 282 minecraft:white_concrete
fill 136 80 283 136 81 284 minecraft:red_concrete
fill 136 80 285 136 81 286 minecraft:white_concrete
fill 136 80 287 136 81 288 minecraft:red_concrete
fill 136 80 289 136 81 290 minecraft:white_concrete
fill 136 80 291 136 81 292 minecraft:red_concrete
fill 136 80 293 136 81 294 minecraft:white_concrete
fill 136 80 295 136 81 296 minecraft:red_concrete
fill 136 80 297 136 81 298 minecraft:white_concrete
fill 136 80 299 136 81 300 minecraft:red_concrete
fill 136 80 301 136 81 302 minecraft:white_concrete
fill 136 80 303 136 81 304 minecraft:red_concrete
fill 136 80 305 136 81 306 minecraft:white_concrete
fill 136 80 307 136 81 308 minecraft:red_concrete
fill 136 80 309 136 81 310 minecraft:white_concrete
fill 136 80 311 136 81 312 minecraft:red_concrete
fill 136 80 313 136 81 314 minecraft:white_concrete
fill 136 80 315 136 81 316 minecraft:red_concrete
fill 136 80 317 136 81 317 minecraft:white_concrete
setblock 97 81 278 minecraft:light[level=12]
setblock 97 81 285 minecraft:light[level=12]
setblock 97 81 292 minecraft:light[level=12]
setblock 97 81 299 minecraft:light[level=12]
setblock 97 81 306 minecraft:light[level=12]
setblock 97 81 313 minecraft:light[level=12]
setblock 104 81 278 minecraft:light[level=12]
setblock 104 81 285 minecraft:light[level=12]
setblock 104 81 292 minecraft:light[level=12]
setblock 104 81 299 minecraft:light[level=12]
setblock 104 81 306 minecraft:light[level=12]
setblock 104 81 313 minecraft:light[level=12]
fill 107 81 285 107 81 288 minecraft:red_terracotta
fill 107 81 303 107 81 306 minecraft:red_terracotta
setblock 108 81 283 minecraft:yellow_concrete
fill 108 81 288 108 83 289 minecraft:red_terracotta
fill 108 81 302 108 83 303 minecraft:red_terracotta
setblock 108 81 308 minecraft:yellow_concrete
fill 109 81 285 109 81 288 minecraft:red_terracotta
fill 109 81 303 109 81 306 minecraft:red_terracotta
setblock 111 81 278 minecraft:light[level=12]
setblock 111 81 285 minecraft:light[level=12]
setblock 111 81 292 minecraft:light[level=12]
setblock 111 81 299 minecraft:light[level=12]
setblock 111 81 306 minecraft:light[level=12]
setblock 111 81 313 minecraft:light[level=12]
setblock 118 81 278 minecraft:light[level=12]
setblock 118 81 285 minecraft:light[level=12]
setblock 118 81 292 minecraft:light[level=12]
setblock 118 81 299 minecraft:light[level=12]
setblock 118 81 306 minecraft:light[level=12]
setblock 118 81 313 minecraft:light[level=12]
setblock 125 81 278 minecraft:light[level=12]
setblock 125 81 285 minecraft:light[level=12]
setblock 125 81 292 minecraft:light[level=12]
setblock 125 81 299 minecraft:light[level=12]
setblock 125 81 306 minecraft:light[level=12]
setblock 125 81 313 minecraft:light[level=12]
fill 128 81 311 128 81 313 minecraft:brown_terracotta
setblock 129 81 310 minecraft:brown_terracotta
fill 129 81 314 131 81 314 minecraft:brown_terracotta
setblock 131 81 310 minecraft:brown_terracotta
setblock 132 81 278 minecraft:light[level=12]
setblock 132 81 285 minecraft:light[level=12]
setblock 132 81 292 minecraft:light[level=12]
setblock 132 81 299 minecraft:light[level=12]
setblock 132 81 306 minecraft:light[level=12]
fill 132 81 311 132 81 313 minecraft:brown_terracotta
fill 94 82 275 94 83 276 minecraft:white_concrete
fill 94 82 277 94 83 278 minecraft:red_concrete
fill 94 82 279 94 83 280 minecraft:white_concrete
fill 94 82 281 94 83 282 minecraft:red_concrete
fill 94 82 283 94 83 284 minecraft:white_concrete
fill 94 82 285 94 83 286 minecraft:red_concrete
fill 94 82 287 94 83 288 minecraft:white_concrete
fill 94 82 289 94 83 290 minecraft:red_concrete
fill 94 82 291 94 83 292 minecraft:white_concrete
fill 94 82 293 94 83 294 minecraft:red_concrete
fill 94 82 295 94 83 296 minecraft:white_concrete
fill 94 82 297 94 83 298 minecraft:red_concrete
fill 94 82 299 94 83 300 minecraft:white_concrete
fill 94 82 301 94 83 302 minecraft:red_concrete
fill 94 82 303 94 83 304 minecraft:white_concrete
fill 94 82 305 94 83 306 minecraft:red_concrete
fill 94 82 307 94 83 308 minecraft:white_concrete
fill 94 82 309 94 83 310 minecraft:red_concrete
fill 94 82 311 94 83 312 minecraft:white_concrete
fill 94 82 313 94 83 314 minecraft:red_concrete
fill 94 82 315 94 83 316 minecraft:white_concrete
fill 95 82 275 95 83 275 minecraft:white_concrete
fill 95 82 317 95 83 317 minecraft:white_concrete
fill 96 82 275 97 83 275 minecraft:red_concrete
fill 96 82 317 97 83 317 minecraft:red_concrete
fill 98 82 275 99 83 275 minecraft:white_concrete
fill 98 82 317 99 83 317 minecraft:white_concrete
fill 100 82 275 101 83 275 minecraft:red_concrete
fill 100 82 317 101 83 317 minecraft:red_concrete
fill 102 82 275 103 83 275 minecraft:white_concrete
fill 102 82 317 103 83 317 minecraft:white_concrete
fill 104 82 275 105 83 275 minecraft:red_concrete
fill 104 82 317 105 83 317 minecraft:red_concrete
fill 106 82 275 107 83 275 minecraft:white_concrete
fill 106 82 317 107 83 317 minecraft:white_concrete
fill 107 82 287 107 82 290 minecraft:red_terracotta
fill 107 82 301 107 82 304 minecraft:red_terracotta
fill 108 82 275 109 83 275 minecraft:red_concrete
setblock 108 82 285 minecraft:yellow_concrete
fill 108 82 290 108 83 293 minecraft:red_terracotta
fill 108 82 298 108 83 301 minecraft:red_terracotta
setblock 108 82 306 minecraft:yellow_concrete
fill 108 82 317 109 83 317 minecraft:red_concrete
fill 109 82 287 109 82 290 minecraft:red_terracotta
fill 109 82 301 109 82 304 minecraft:red_terracotta
fill 110 82 275 111 83 275 minecraft:white_concrete
fill 110 82 317 111 83 317 minecraft:white_concrete
fill 112 82 275 113 83 275 minecraft:red_concrete
fill 112 82 317 113 83 317 minecraft:red_concrete
fill 114 82 275 115 83 275 minecraft:white_concrete
fill 114 82 317 115 83 317 minecraft:white_concrete
fill 116 82 275 117 83 275 minecraft:red_concrete
fill 116 82 317 117 83 317 minecraft:red_concrete
fill 118 82 275 119 83 275 minecraft:white_concrete
fill 118 82 317 119 83 317 minecraft:white_concrete
fill 120 82 275 121 83 275 minecraft:red_concrete
fill 120 82 317 121 83 317 minecraft:red_concrete
fill 122 82 275 123 83 275 minecraft:white_concrete
fill 122 82 317 123 83 317 minecraft:white_concrete
fill 124 82 275 125 83 275 minecraft:red_concrete
fill 124 82 317 125 83 317 minecraft:red_concrete
fill 126 82 275 127 83 275 minecraft:white_concrete
fill 126 82 317 127 83 317 minecraft:white_concrete
fill 128 82 275 129 83 275 minecraft:red_concrete
fill 128 82 317 129 83 317 minecraft:red_concrete
fill 130 82 275 131 83 275 minecraft:white_concrete
setblock 130 82 306 minecraft:red_terracotta
setblock 130 82 308 minecraft:red_terracotta
fill 130 82 317 131 83 317 minecraft:white_concrete
fill 131 82 285 131 82 287 minecraft:red_terracotta
fill 132 82 275 133 83 275 minecraft:red_concrete
fill 132 82 285 133 82 285 minecraft:red_terracotta
fill 132 82 287 133 82 287 minecraft:red_terracotta
setblock 132 82 306 minecraft:red_terracotta
setblock 132 82 308 minecraft:red_terracotta
fill 132 82 317 133 83 317 minecraft:red_concrete
setblock 133 82 286 minecraft:red_terracotta
fill 134 82 275 135 83 275 minecraft:white_concrete
fill 134 82 317 135 83 317 minecraft:white_concrete
fill 136 82 276 136 83 276 minecraft:white_concrete
fill 136 82 277 136 83 278 minecraft:red_concrete
fill 136 82 279 136 83 280 minecraft:white_concrete
fill 136 82 281 136 83 282 minecraft:red_concrete
fill 136 82 283 136 83 284 minecraft:white_concrete
fill 136 82 285 136 83 286 minecraft:red_concrete
fill 136 82 287 136 83 288 minecraft:white_concrete
fill 136 82 289 136 83 290 minecraft:red_concrete
fill 136 82 291 136 83 292 minecraft:white_concrete
fill 136 82 293 136 83 294 minecraft:red_concrete
fill 136 82 295 136 83 296 minecraft:white_concrete
fill 136 82 297 136 83 298 minecraft:red_concrete
fill 136 82 299 136 83 300 minecraft:white_concrete
fill 136 82 301 136 83 302 minecraft:red_concrete
fill 136 82 303 136 83 304 minecraft:white_concrete
fill 136 82 305 136 83 306 minecraft:red_concrete
fill 136 82 307 136 83 308 minecraft:white_concrete
fill 136 82 309 136 83 310 minecraft:red_concrete
fill 136 82 311 136 83 312 minecraft:white_concrete
fill 136 82 313 136 83 314 minecraft:red_concrete
fill 136 82 315 136 83 316 minecraft:white_concrete
fill 136 82 317 136 83 317 minecraft:red_concrete
fill 107 83 290 107 83 301 minecraft:red_terracotta
fill 108 83 286 108 83 287 minecraft:yellow_concrete
fill 108 83 294 109 84 297 minecraft:red_terracotta
fill 108 83 304 108 83 305 minecraft:yellow_concrete
fill 109 83 290 109 83 293 minecraft:red_terracotta
fill 109 83 298 109 83 301 minecraft:red_terracotta
fill 133 83 307 134 83 307 minecraft:iron_block
fill 94 84 275 94 85 276 minecraft:red_concrete
fill 94 84 277 94 85 278 minecraft:white_concrete
fill 94 84 279 94 85 280 minecraft:red_concrete
fill 94 84 281 94 85 282 minecraft:white_concrete
fill 94 84 283 94 85 284 minecraft:red_concrete
fill 94 84 285 94 85 286 minecraft:white_concrete
fill 94 84 287 94 85 288 minecraft:red_concrete
fill 94 84 289 94 85 290 minecraft:white_concrete
fill 94 84 291 94 85 292 minecraft:red_concrete
fill 94 84 293 94 85 294 minecraft:white_concrete
fill 94 84 295 94 85 296 minecraft:red_concrete
fill 94 84 297 94 85 298 minecraft:white_concrete
fill 94 84 299 94 85 300 minecraft:red_concrete
fill 94 84 301 94 85 302 minecraft:white_concrete
fill 94 84 303 94 85 304 minecraft:red_concrete
fill 94 84 305 94 85 306 minecraft:white_concrete
fill 94 84 307 94 85 308 minecraft:red_concrete
fill 94 84 309 94 85 310 minecraft:white_concrete
fill 94 84 311 94 85 312 minecraft:red_concrete
fill 94 84 313 94 85 314 minecraft:white_concrete
fill 94 84 315 94 85 316 minecraft:red_concrete
fill 95 84 275 95 85 275 minecraft:red_concrete
fill 95 84 276 95 85 281 minecraft:red_terracotta
fill 95 84 284 96 84 289 minecraft:red_terracotta
fill 95 84 292 96 84 297 minecraft:red_terracotta
fill 95 84 300 96 84 305 minecraft:red_terracotta
fill 95 84 308 96 84 313 minecraft:red_terracotta
fill 95 84 316 100 85 316 minecraft:red_terracotta
fill 95 84 317 95 85 317 minecraft:red_concrete
fill 96 84 275 97 85 275 minecraft:white_concrete
fill 96 84 277 96 84 283 minecraft:red_terracotta
fill 96 84 290 96 84 291 minecraft:red_terracotta
fill 96 84 298 96 84 299 minecraft:red_terracotta
fill 96 84 306 96 84 307 minecraft:red_terracotta
fill 96 84 314 96 84 315 minecraft:red_terracotta
fill 96 84 317 97 85 317 minecraft:white_concrete
fill 97 84 277 134 84 277 minecraft:red_terracotta
fill 97 84 315 135 84 315 minecraft:red_terracotta
fill 98 84 275 99 85 275 minecraft:red_concrete
fill 98 84 276 103 85 276 minecraft:red_terracotta
fill 98 84 317 99 85 317 minecraft:red_concrete
fill 100 84 275 101 85 275 minecraft:white_concrete
fill 100 84 317 101 85 317 minecraft:white_concrete
fill 102 84 275 103 85 275 minecraft:red_concrete
fill 102 84 317 103 85 317 minecraft:red_concrete
fill 103 84 316 108 85 316 minecraft:red_terracotta
fill 104 84 275 105 85 275 minecraft:white_concrete
fill 104 84 317 105 85 317 minecraft:white_concrete
fill 106 84 275 107 85 275 minecraft:red_concrete
fill 106 84 276 111 85 276 minecraft:red_terracotta
fill 106 84 317 107 85 317 minecraft:red_concrete
fill 107 84 293 107 84 298 minecraft:red_terracotta
fill 108 84 275 109 85 275 minecraft:white_concrete
fill 108 84 289 108 84 290 minecraft:yellow_concrete
fill 108 84 291 108 84 293 minecraft:red_terracotta
fill 108 84 298 108 84 300 minecraft:red_terracotta
fill 108 84 301 108 84 302 minecraft:yellow_concrete
fill 108 84 317 109 85 317 minecraft:white_concrete
setblock 109 84 293 minecraft:red_terracotta
setblock 109 84 298 minecraft:red_terracotta
fill 110 84 275 111 85 275 minecraft:red_concrete
fill 110 84 317 111 85 317 minecraft:red_concrete
fill 111 84 316 116 85 316 minecraft:red_terracotta
fill 112 84 275 113 85 275 minecraft:white_concrete
fill 112 84 317 113 85 317 minecraft:white_concrete
fill 114 84 275 115 85 275 minecraft:red_concrete
fill 114 84 276 119 85 276 minecraft:red_terracotta
fill 114 84 317 115 85 317 minecraft:red_concrete
fill 116 84 275 117 85 275 minecraft:white_concrete
fill 116 84 317 117 85 317 minecraft:white_concrete
fill 118 84 275 119 85 275 minecraft:red_concrete
fill 118 84 317 119 85 317 minecraft:red_concrete
fill 119 84 316 124 85 316 minecraft:red_terracotta
fill 120 84 275 121 85 275 minecraft:white_concrete
fill 120 84 317 121 85 317 minecraft:white_concrete
fill 122 84 275 123 85 275 minecraft:red_concrete
fill 122 84 276 127 85 276 minecraft:red_terracotta
fill 122 84 317 123 85 317 minecraft:red_concrete
fill 124 84 275 125 85 275 minecraft:white_concrete
fill 124 84 317 125 85 317 minecraft:white_concrete
fill 126 84 275 127 85 275 minecraft:red_concrete
fill 126 84 317 127 85 317 minecraft:red_concrete
fill 127 84 316 132 85 316 minecraft:red_terracotta
fill 128 84 275 129 85 275 minecraft:white_concrete
fill 128 84 317 129 85 317 minecraft:white_concrete
setblock 129 84 307 minecraft:shroomlight
fill 130 84 275 131 85 275 minecraft:red_concrete
fill 130 84 276 135 85 276 minecraft:red_terracotta
fill 130 84 317 131 85 317 minecraft:red_concrete
fill 132 84 275 133 85 275 minecraft:white_concrete
fill 132 84 317 133 85 317 minecraft:white_concrete
setblock 133 84 307 minecraft:iron_block
fill 134 84 275 135 85 275 minecraft:red_concrete
fill 134 84 278 134 84 314 minecraft:red_terracotta
fill 134 84 317 135 85 317 minecraft:red_concrete
fill 135 84 279 135 85 284 minecraft:red_terracotta
fill 135 84 287 135 85 292 minecraft:red_terracotta
fill 135 84 295 135 85 300 minecraft:red_terracotta
fill 135 84 303 135 85 308 minecraft:red_terracotta
fill 135 84 311 135 85 314 minecraft:red_terracotta
fill 135 84 316 135 85 316 minecraft:red_terracotta
fill 136 84 276 136 85 276 minecraft:red_concrete
fill 136 84 277 136 85 278 minecraft:white_concrete
fill 136 84 279 136 85 280 minecraft:red_concrete
fill 136 84 281 136 85 282 minecraft:white_concrete
fill 136 84 283 136 85 284 minecraft:red_concrete
fill 136 84 285 136 85 286 minecraft:white_concrete
fill 136 84 287 136 85 288 minecraft:red_concrete
fill 136 84 289 136 85 290 minecraft:white_concrete
fill 136 84 291 136 85 292 minecraft:red_concrete
fill 136 84 293 136 85 294 minecraft:white_concrete
fill 136 84 295 136 85 296 minecraft:red_concrete
fill 136 84 297 136 85 298 minecraft:white_concrete
fill 136 84 299 136 85 300 minecraft:red_concrete
fill 136 84 301 136 85 302 minecraft:white_concrete
fill 136 84 303 136 85 304 minecraft:red_concrete
fill 136 84 305 136 85 306 minecraft:white_concrete
fill 136 84 307 136 85 308 minecraft:red_concrete
fill 136 84 309 136 85 310 minecraft:white_concrete
fill 136 84 311 136 85 312 minecraft:red_concrete
fill 136 84 313 136 85 314 minecraft:white_concrete
fill 136 84 315 136 85 316 minecraft:red_concrete
fill 136 84 317 136 85 317 minecraft:white_concrete
fill 95 85 284 95 85 289 minecraft:red_terracotta
fill 95 85 292 95 85 297 minecraft:red_terracotta
fill 95 85 300 95 85 305 minecraft:red_terracotta
fill 95 85 308 95 85 313 minecraft:red_terracotta
setblock 97 85 278 minecraft:light[level=15]
setblock 97 85 286 minecraft:light[level=15]
setblock 97 85 294 minecraft:light[level=15]
setblock 97 85 302 minecraft:light[level=15]
setblock 97 85 310 minecraft:light[level=15]
setblock 105 85 278 minecraft:light[level=15]
setblock 105 85 286 minecraft:light[level=15]
setblock 105 85 294 minecraft:light[level=15]
setblock 105 85 302 minecraft:light[level=15]
setblock 105 85 310 minecraft:light[level=15]
fill 108 85 291 108 85 300 minecraft:yellow_concrete
setblock 113 85 278 minecraft:light[level=15]
setblock 113 85 286 minecraft:light[level=15]
setblock 113 85 294 minecraft:light[level=15]
setblock 113 85 302 minecraft:light[level=15]
setblock 113 85 310 minecraft:light[level=15]
setblock 121 85 278 minecraft:light[level=15]
setblock 121 85 286 minecraft:light[level=15]
setblock 121 85 294 minecraft:light[level=15]
setblock 121 85 302 minecraft:light[level=15]
setblock 121 85 310 minecraft:light[level=15]
setblock 129 85 278 minecraft:light[level=15]
setblock 129 85 286 minecraft:light[level=15]
setblock 129 85 294 minecraft:light[level=15]
setblock 129 85 302 minecraft:light[level=15]
setblock 129 85 310 minecraft:light[level=15]
setblock 135 85 315 minecraft:red_terracotta
fill 94 86 275 94 87 276 minecraft:white_concrete
fill 94 86 277 94 87 278 minecraft:red_concrete
fill 94 86 279 94 87 280 minecraft:white_concrete
fill 94 86 281 94 87 282 minecraft:red_concrete
fill 94 86 283 94 87 284 minecraft:white_concrete
fill 94 86 285 94 87 286 minecraft:red_concrete
fill 94 86 287 94 87 288 minecraft:white_concrete
fill 94 86 289 94 87 290 minecraft:red_concrete
fill 94 86 291 94 87 292 minecraft:white_concrete
fill 94 86 293 94 87 294 minecraft:red_concrete
fill 94 86 295 94 87 296 minecraft:white_concrete
fill 94 86 297 94 87 298 minecraft:red_concrete
fill 94 86 299 94 87 300 minecraft:white_concrete
fill 94 86 301 94 87 302 minecraft:red_concrete
fill 94 86 303 94 87 304 minecraft:white_concrete
fill 94 86 305 94 87 306 minecraft:red_concrete
fill 94 86 307 94 87 308 minecraft:white_concrete
fill 94 86 309 94 87 310 minecraft:red_concrete
fill 94 86 311 94 87 312 minecraft:white_concrete
fill 94 86 313 94 87 314 minecraft:red_concrete
fill 94 86 315 94 87 316 minecraft:white_concrete
fill 95 86 275 95 87 275 minecraft:white_concrete
fill 95 86 317 95 87 317 minecraft:white_concrete
fill 96 86 275 97 87 275 minecraft:red_concrete
fill 96 86 317 97 87 317 minecraft:red_concrete
fill 98 86 275 99 87 275 minecraft:white_concrete
fill 98 86 317 99 87 317 minecraft:white_concrete
fill 100 86 275 101 87 275 minecraft:red_concrete
fill 100 86 317 101 87 317 minecraft:red_concrete
fill 102 86 275 103 87 275 minecraft:white_concrete
fill 102 86 317 103 87 317 minecraft:white_concrete
fill 104 86 275 105 87 275 minecraft:red_concrete
fill 104 86 317 105 87 317 minecraft:red_concrete
fill 106 86 275 107 87 275 minecraft:white_concrete
fill 106 86 317 107 87 317 minecraft:white_concrete
fill 108 86 275 109 87 275 minecraft:red_concrete
fill 108 86 317 109 87 317 minecraft:red_concrete
fill 110 86 275 111 87 275 minecraft:white_concrete
fill 110 86 317 111 87 317 minecraft:white_concrete
fill 112 86 275 113 87 275 minecraft:red_concrete
fill 112 86 317 113 87 317 minecraft:red_concrete
fill 114 86 275 115 87 275 minecraft:white_concrete
fill 114 86 317 115 87 317 minecraft:white_concrete
fill 116 86 275 117 87 275 minecraft:red_concrete
fill 116 86 317 117 87 317 minecraft:red_concrete
schedule function dropper:buildpart/62_2 1t
