fill 436 210 562 438 211 562 minecraft:white_concrete
fill 436 210 594 438 211 594 minecraft:white_concrete
fill 438 210 561 450 211 561 minecraft:white_concrete
fill 438 210 595 450 211 595 minecraft:white_concrete
fill 440 210 598 445 211 598 minecraft:white_concrete
fill 442 210 560 446 211 560 minecraft:white_concrete
fill 442 210 596 446 211 596 minecraft:white_concrete
fill 443 210 558 448 211 558 minecraft:white_concrete
fill 448 210 598 453 211 598 minecraft:white_concrete
fill 450 210 562 452 211 562 minecraft:white_concrete
fill 450 210 594 452 211 594 minecraft:white_concrete
fill 451 210 558 456 211 558 minecraft:white_concrete
fill 452 210 563 454 211 563 minecraft:white_concrete
fill 452 210 593 454 211 593 minecraft:white_concrete
fill 454 210 564 455 211 564 minecraft:white_concrete
fill 454 210 592 455 211 592 minecraft:white_concrete
fill 455 210 565 456 211 565 minecraft:white_concrete
fill 455 210 591 456 211 591 minecraft:white_concrete
fill 456 210 566 457 211 566 minecraft:white_concrete
fill 456 210 590 457 211 590 minecraft:white_concrete
fill 456 210 598 461 211 598 minecraft:white_concrete
fill 457 210 567 458 211 567 minecraft:white_concrete
fill 457 210 589 458 211 589 minecraft:white_concrete
fill 458 210 568 459 211 568 minecraft:white_concrete
fill 458 210 588 459 211 588 minecraft:white_concrete
fill 459 210 558 464 211 558 minecraft:white_concrete
fill 459 210 569 459 211 570 minecraft:white_concrete
fill 459 210 586 459 211 587 minecraft:white_concrete
fill 460 210 570 460 211 572 minecraft:white_concrete
fill 460 210 584 460 211 586 minecraft:white_concrete
fill 461 210 572 461 211 584 minecraft:white_concrete
fill 462 210 576 463 210 580 minecraft:white_concrete
fill 463 210 560 463 210 575 minecraft:white_concrete
fill 463 210 581 463 210 596 minecraft:white_concrete
fill 464 210 561 464 211 566 minecraft:white_concrete
fill 464 210 569 464 211 574 minecraft:white_concrete
fill 464 210 577 464 211 582 minecraft:white_concrete
fill 464 210 585 464 211 590 minecraft:white_concrete
fill 464 210 593 464 211 596 minecraft:white_concrete
fill 464 210 598 464 211 598 minecraft:white_concrete
fill 424 211 566 424 211 571 minecraft:white_concrete
fill 424 211 574 424 211 579 minecraft:white_concrete
fill 424 211 582 424 211 587 minecraft:white_concrete
fill 424 211 590 424 211 595 minecraft:white_concrete
fill 462 211 576 462 211 580 minecraft:white_concrete
setblock 464 211 597 minecraft:white_concrete
setblock 426 212 560 minecraft:light[level=14]
setblock 426 212 568 minecraft:light[level=14]
setblock 426 212 576 minecraft:light[level=14]
setblock 426 212 584 minecraft:light[level=14]
setblock 426 212 592 minecraft:light[level=14]
setblock 434 212 560 minecraft:light[level=14]
setblock 434 212 568 minecraft:light[level=14]
setblock 434 212 576 minecraft:light[level=14]
setblock 434 212 584 minecraft:light[level=14]
setblock 434 212 592 minecraft:light[level=14]
fill 435 212 594 436 212 594 minecraft:sea_lantern
fill 437 212 595 439 212 595 minecraft:sea_lantern
fill 440 212 596 448 212 596 minecraft:sea_lantern
setblock 442 212 560 minecraft:light[level=14]
setblock 442 212 568 minecraft:light[level=14]
setblock 442 212 576 minecraft:light[level=14]
setblock 442 212 584 minecraft:light[level=14]
setblock 442 212 592 minecraft:light[level=14]
fill 449 212 595 451 212 595 minecraft:sea_lantern
setblock 450 212 560 minecraft:light[level=14]
setblock 450 212 568 minecraft:light[level=14]
setblock 450 212 576 minecraft:light[level=14]
setblock 450 212 584 minecraft:light[level=14]
setblock 450 212 592 minecraft:light[level=14]
fill 452 212 594 453 212 594 minecraft:sea_lantern
setblock 454 212 593 minecraft:sea_lantern
fill 455 212 592 456 212 592 minecraft:sea_lantern
fill 456 212 591 457 212 591 minecraft:sea_lantern
fill 457 212 590 458 212 590 minecraft:sea_lantern
setblock 458 212 560 minecraft:light[level=14]
setblock 458 212 568 minecraft:light[level=14]
setblock 458 212 576 minecraft:light[level=14]
setblock 458 212 584 minecraft:light[level=14]
setblock 458 212 589 minecraft:sea_lantern
setblock 458 212 592 minecraft:light[level=14]
setblock 459 212 588 minecraft:sea_lantern
fill 430 213 588 430 214 588 minecraft:purple_concrete
fill 423 214 562 423 219 562 minecraft:sea_lantern
fill 423 214 570 423 219 570 minecraft:sea_lantern
fill 423 214 578 423 219 578 minecraft:sea_lantern
fill 423 214 586 423 219 586 minecraft:sea_lantern
fill 423 214 594 423 219 594 minecraft:sea_lantern
fill 426 214 599 426 219 599 minecraft:sea_lantern
fill 430 214 557 430 219 557 minecraft:sea_lantern
fill 434 214 599 434 219 599 minecraft:sea_lantern
fill 438 214 557 438 219 557 minecraft:sea_lantern
fill 442 214 599 442 219 599 minecraft:sea_lantern
fill 446 214 557 446 219 557 minecraft:sea_lantern
fill 450 214 589 451 215 590 minecraft:purple_concrete
fill 450 214 599 450 219 599 minecraft:sea_lantern
fill 454 214 557 454 219 557 minecraft:sea_lantern
fill 458 214 599 458 219 599 minecraft:sea_lantern
fill 462 214 557 462 219 557 minecraft:sea_lantern
fill 465 214 562 465 219 562 minecraft:sea_lantern
fill 465 214 570 465 219 570 minecraft:sea_lantern
fill 465 214 578 465 219 578 minecraft:sea_lantern
fill 465 214 586 465 219 586 minecraft:sea_lantern
fill 465 214 594 465 219 594 minecraft:sea_lantern
fill 448 219 594 449 220 595 minecraft:red_concrete
fill 449 219 593 449 220 593 minecraft:red_concrete
fill 423 220 562 423 227 562 minecraft:yellow_concrete
fill 423 220 570 423 227 570 minecraft:yellow_concrete
fill 423 220 578 423 227 578 minecraft:yellow_concrete
fill 423 220 586 423 227 586 minecraft:yellow_concrete
fill 423 220 594 423 227 594 minecraft:yellow_concrete
setblock 426 220 560 minecraft:light[level=14]
setblock 426 220 568 minecraft:light[level=14]
setblock 426 220 576 minecraft:light[level=14]
setblock 426 220 584 minecraft:light[level=14]
setblock 426 220 592 minecraft:light[level=14]
fill 426 220 599 426 227 599 minecraft:yellow_concrete
fill 430 220 557 430 227 557 minecraft:yellow_concrete
setblock 434 220 560 minecraft:light[level=14]
setblock 434 220 568 minecraft:light[level=14]
setblock 434 220 576 minecraft:light[level=14]
setblock 434 220 584 minecraft:light[level=14]
setblock 434 220 592 minecraft:light[level=14]
fill 434 220 599 434 227 599 minecraft:yellow_concrete
fill 438 220 557 438 227 557 minecraft:yellow_concrete
setblock 442 220 560 minecraft:light[level=14]
setblock 442 220 568 minecraft:light[level=14]
setblock 442 220 576 minecraft:light[level=14]
setblock 442 220 584 minecraft:light[level=14]
setblock 442 220 592 minecraft:light[level=14]
fill 442 220 599 442 227 599 minecraft:yellow_concrete
fill 446 220 557 446 226 557 minecraft:yellow_concrete
setblock 450 220 560 minecraft:light[level=14]
setblock 450 220 568 minecraft:light[level=14]
setblock 450 220 576 minecraft:light[level=14]
setblock 450 220 584 minecraft:light[level=14]
setblock 450 220 592 minecraft:light[level=14]
fill 450 220 599 450 227 599 minecraft:yellow_concrete
fill 454 220 557 454 227 557 minecraft:yellow_concrete
setblock 458 220 560 minecraft:light[level=14]
setblock 458 220 568 minecraft:light[level=14]
setblock 458 220 576 minecraft:light[level=14]
setblock 458 220 584 minecraft:light[level=14]
setblock 458 220 592 minecraft:light[level=14]
fill 458 220 599 458 227 599 minecraft:yellow_concrete
fill 462 220 557 462 225 557 minecraft:yellow_concrete
fill 465 220 562 465 227 562 minecraft:yellow_concrete
fill 465 220 570 465 227 570 minecraft:yellow_concrete
fill 465 220 578 465 227 578 minecraft:yellow_concrete
fill 465 220 586 465 227 586 minecraft:yellow_concrete
fill 465 220 594 465 227 594 minecraft:yellow_concrete
fill 426 221 574 427 222 582 minecraft:white_concrete
fill 427 221 571 428 222 573 minecraft:white_concrete
fill 427 221 583 428 222 585 minecraft:white_concrete
fill 428 221 569 429 222 570 minecraft:white_concrete
fill 428 221 586 429 222 587 minecraft:white_concrete
fill 429 221 568 430 222 568 minecraft:white_concrete
fill 429 221 571 429 222 571 minecraft:white_concrete
fill 429 221 585 429 222 585 minecraft:white_concrete
fill 429 221 588 430 222 588 minecraft:white_concrete
fill 430 221 566 431 222 567 minecraft:white_concrete
fill 430 221 569 430 222 569 minecraft:white_concrete
fill 430 221 587 430 222 587 minecraft:white_concrete
fill 430 221 589 431 222 590 minecraft:white_concrete
fill 431 221 565 433 222 565 minecraft:white_concrete
fill 431 221 591 433 222 591 minecraft:white_concrete
fill 432 221 564 435 222 564 minecraft:white_concrete
fill 432 221 566 432 222 566 minecraft:white_concrete
fill 432 221 590 432 222 590 minecraft:white_concrete
fill 432 221 592 435 222 592 minecraft:white_concrete
fill 434 221 563 437 222 563 minecraft:white_concrete
fill 434 221 593 437 222 593 minecraft:white_concrete
fill 435 221 562 439 222 562 minecraft:white_concrete
fill 435 221 594 439 222 594 minecraft:white_concrete
fill 437 221 561 451 222 561 minecraft:white_concrete
fill 437 221 595 451 222 595 minecraft:white_concrete
fill 440 221 560 448 222 560 minecraft:white_concrete
fill 440 221 596 448 222 596 minecraft:white_concrete
fill 449 221 562 453 222 562 minecraft:white_concrete
fill 449 221 594 453 222 594 minecraft:white_concrete
fill 451 221 563 454 222 563 minecraft:white_concrete
fill 451 221 593 454 222 593 minecraft:white_concrete
fill 453 221 564 456 222 564 minecraft:white_concrete
fill 453 221 592 456 222 592 minecraft:white_concrete
fill 455 221 565 457 222 565 minecraft:white_concrete
fill 455 221 591 457 222 591 minecraft:white_concrete
fill 456 221 566 458 222 566 minecraft:white_concrete
fill 456 221 590 458 222 590 minecraft:white_concrete
fill 457 221 567 458 222 567 minecraft:white_concrete
fill 457 221 589 458 222 589 minecraft:white_concrete
fill 458 221 568 459 222 569 minecraft:white_concrete
fill 458 221 587 459 222 588 minecraft:white_concrete
fill 459 221 570 460 222 571 minecraft:white_concrete
fill 459 221 585 460 222 586 minecraft:white_concrete
fill 460 221 569 460 222 569 minecraft:white_concrete
fill 460 221 572 461 222 573 minecraft:white_concrete
fill 460 221 583 461 222 584 minecraft:white_concrete
fill 460 221 587 460 222 587 minecraft:white_concrete
fill 461 221 571 461 222 571 minecraft:white_concrete
fill 461 221 574 462 222 582 minecraft:white_concrete
fill 461 221 585 461 222 585 minecraft:white_concrete
fill 426 223 574 426 223 582 minecraft:sea_lantern
fill 427 223 571 427 223 573 minecraft:sea_lantern
fill 427 223 583 427 223 585 minecraft:sea_lantern
fill 428 223 569 428 223 570 minecraft:sea_lantern
fill 428 223 586 428 223 587 minecraft:sea_lantern
setblock 429 223 568 minecraft:sea_lantern
setblock 429 223 588 minecraft:sea_lantern
fill 430 223 566 430 223 567 minecraft:sea_lantern
fill 430 223 589 430 223 590 minecraft:sea_lantern
fill 431 223 565 431 223 566 minecraft:sea_lantern
fill 431 223 590 431 223 591 minecraft:sea_lantern
fill 432 223 564 432 223 565 minecraft:sea_lantern
fill 432 223 591 432 223 592 minecraft:sea_lantern
setblock 433 223 564 minecraft:sea_lantern
setblock 433 223 592 minecraft:sea_lantern
setblock 434 223 563 minecraft:sea_lantern
setblock 434 223 593 minecraft:sea_lantern
fill 435 223 562 436 223 562 minecraft:sea_lantern
fill 435 223 594 436 223 594 minecraft:sea_lantern
fill 437 223 595 439 223 595 minecraft:sea_lantern
fill 440 223 596 447 223 596 minecraft:sea_lantern
fill 424 224 558 424 225 563 minecraft:white_concrete
fill 424 224 566 425 224 571 minecraft:white_concrete
fill 424 224 574 425 224 579 minecraft:white_concrete
fill 424 224 582 425 224 587 minecraft:white_concrete
fill 424 224 590 425 224 595 minecraft:white_concrete
fill 424 224 598 429 225 598 minecraft:white_concrete
fill 425 224 559 425 224 565 minecraft:white_concrete
fill 425 224 572 425 224 573 minecraft:white_concrete
fill 425 224 580 425 224 581 minecraft:white_concrete
fill 425 224 588 425 224 589 minecraft:white_concrete
fill 425 224 596 425 224 597 minecraft:white_concrete
fill 426 224 559 463 224 559 minecraft:white_concrete
fill 426 224 597 464 224 597 minecraft:white_concrete
fill 427 224 558 432 225 558 minecraft:white_concrete
fill 432 224 598 437 225 598 minecraft:white_concrete
fill 435 224 558 440 225 558 minecraft:white_concrete
fill 440 224 598 445 225 598 minecraft:white_concrete
fill 443 224 558 448 225 558 minecraft:white_concrete
fill 448 224 598 453 225 598 minecraft:white_concrete
fill 451 224 558 456 225 558 minecraft:white_concrete
fill 456 224 598 461 225 598 minecraft:white_concrete
fill 459 224 558 464 225 558 minecraft:white_concrete
fill 463 224 560 463 224 596 minecraft:white_concrete
fill 464 224 561 464 225 566 minecraft:white_concrete
fill 464 224 569 464 225 574 minecraft:white_concrete
fill 464 224 577 464 225 582 minecraft:white_concrete
fill 464 224 585 464 225 590 minecraft:white_concrete
fill 464 224 593 464 225 596 minecraft:white_concrete
fill 464 224 598 464 225 598 minecraft:white_concrete
fill 424 225 566 424 225 571 minecraft:white_concrete
fill 424 225 574 424 225 579 minecraft:white_concrete
fill 424 225 582 424 225 587 minecraft:white_concrete
fill 424 225 590 424 225 595 minecraft:white_concrete
setblock 464 225 597 minecraft:white_concrete
setblock 423 226 572 minecraft:orange_concrete
fill 423 226 573 423 226 574 minecraft:yellow_concrete
fill 423 226 592 423 227 592 minecraft:orange_concrete
fill 423 226 593 423 229 593 minecraft:yellow_concrete
fill 423 226 595 423 229 595 minecraft:yellow_concrete
fill 423 226 596 423 227 596 minecraft:orange_concrete
setblock 433 226 599 minecraft:orange_concrete
setblock 435 226 599 minecraft:orange_concrete
fill 436 226 599 436 229 599 minecraft:yellow_concrete
setblock 437 226 599 minecraft:orange_concrete
fill 438 226 599 439 229 599 minecraft:yellow_concrete
fill 448 226 557 449 229 557 minecraft:yellow_concrete
fill 450 226 557 451 226 557 minecraft:orange_concrete
fill 451 226 570 452 227 571 minecraft:purple_concrete
setblock 451 226 599 minecraft:orange_concrete
fill 452 226 557 452 229 557 minecraft:yellow_concrete
fill 452 226 599 453 229 599 minecraft:yellow_concrete
setblock 454 226 599 minecraft:orange_concrete
fill 455 226 557 455 229 557 minecraft:yellow_concrete
fill 455 226 599 457 226 599 minecraft:yellow_concrete
setblock 456 226 557 minecraft:orange_concrete
fill 457 226 557 461 226 557 minecraft:yellow_concrete
setblock 462 226 557 minecraft:orange_concrete
fill 465 226 558 465 229 558 minecraft:yellow_concrete
setblock 465 226 559 minecraft:orange_concrete
fill 465 226 563 465 226 564 minecraft:orange_concrete
fill 465 226 565 465 229 565 minecraft:yellow_concrete
setblock 465 226 566 minecraft:orange_concrete
setblock 465 226 571 minecraft:orange_concrete
fill 465 226 572 465 229 572 minecraft:yellow_concrete
fill 465 226 587 465 229 587 minecraft:yellow_concrete
setblock 465 226 588 minecraft:orange_concrete
setblock 423 227 567 minecraft:orange_concrete
fill 423 227 568 423 227 569 minecraft:yellow_concrete
fill 423 227 572 423 229 573 minecraft:yellow_concrete
setblock 423 227 574 minecraft:orange_concrete
fill 423 227 575 423 227 576 minecraft:yellow_concrete
setblock 423 227 577 minecraft:orange_concrete
fill 423 227 579 423 229 580 minecraft:yellow_concrete
setblock 423 227 581 minecraft:orange_concrete
fill 423 227 582 423 229 584 minecraft:yellow_concrete
setblock 423 227 585 minecraft:orange_concrete
fill 427 227 599 428 229 599 minecraft:yellow_concrete
setblock 429 227 599 minecraft:orange_concrete
fill 433 227 599 433 229 599 minecraft:yellow_concrete
fill 435 227 599 435 229 599 minecraft:yellow_concrete
fill 437 227 599 437 229 599 minecraft:yellow_concrete
setblock 446 227 557 minecraft:orange_concrete
fill 450 227 557 451 229 557 minecraft:yellow_concrete
setblock 451 227 599 minecraft:yellow_concrete
fill 454 227 599 454 229 599 minecraft:yellow_concrete
fill 455 227 599 456 227 599 minecraft:orange_concrete
fill 456 227 557 459 227 557 minecraft:yellow_concrete
fill 457 227 599 457 229 599 minecraft:yellow_concrete
setblock 459 227 599 minecraft:orange_concrete
fill 460 227 557 461 227 557 minecraft:orange_concrete
setblock 462 227 557 minecraft:yellow_concrete
fill 462 227 599 462 229 599 minecraft:yellow_concrete
setblock 463 227 557 minecraft:orange_concrete
setblock 463 227 599 minecraft:orange_concrete
fill 464 227 599 465 229 599 minecraft:yellow_concrete
fill 465 227 559 465 229 559 minecraft:yellow_concrete
fill 465 227 563 465 229 564 minecraft:yellow_concrete
fill 465 227 566 465 229 566 minecraft:yellow_concrete
fill 465 227 571 465 229 571 minecraft:yellow_concrete
fill 465 227 588 465 229 588 minecraft:yellow_concrete
fill 423 228 562 423 233 562 minecraft:sea_lantern
setblock 423 228 566 minecraft:orange_concrete
fill 423 228 567 423 229 568 minecraft:yellow_concrete
setblock 423 228 569 minecraft:orange_concrete
fill 423 228 570 423 233 570 minecraft:sea_lantern
setblock 423 228 571 minecraft:orange_concrete
fill 423 228 574 423 230 574 minecraft:yellow_concrete
setblock 423 228 575 minecraft:orange_concrete
fill 423 228 576 423 229 577 minecraft:yellow_concrete
fill 423 228 578 423 233 578 minecraft:sea_lantern
fill 423 228 581 423 229 581 minecraft:yellow_concrete
fill 423 228 585 423 229 585 minecraft:yellow_concrete
fill 423 228 586 423 233 586 minecraft:sea_lantern
setblock 423 228 589 minecraft:orange_concrete
fill 423 228 592 423 229 592 minecraft:yellow_concrete
fill 423 228 594 423 233 594 minecraft:sea_lantern
fill 423 228 596 423 229 596 minecraft:yellow_concrete
setblock 425 228 557 minecraft:orange_concrete
fill 426 228 557 428 229 557 minecraft:yellow_concrete
setblock 426 228 560 minecraft:light[level=14]
setblock 426 228 568 minecraft:light[level=14]
setblock 426 228 576 minecraft:light[level=14]
setblock 426 228 584 minecraft:light[level=14]
setblock 426 228 592 minecraft:light[level=14]
fill 426 228 599 426 233 599 minecraft:sea_lantern
setblock 429 228 557 minecraft:orange_concrete
fill 429 228 599 429 229 599 minecraft:yellow_concrete
fill 430 228 557 430 233 557 minecraft:sea_lantern
setblock 431 228 599 minecraft:orange_concrete
fill 432 228 599 432 229 599 minecraft:yellow_concrete
setblock 434 228 560 minecraft:light[level=14]
setblock 434 228 568 minecraft:light[level=14]
setblock 434 228 576 minecraft:light[level=14]
setblock 434 228 584 minecraft:light[level=14]
setblock 434 228 592 minecraft:light[level=14]
fill 434 228 599 434 233 599 minecraft:sea_lantern
fill 438 228 557 438 233 557 minecraft:sea_lantern
setblock 442 228 560 minecraft:light[level=14]
setblock 442 228 568 minecraft:light[level=14]
setblock 442 228 576 minecraft:light[level=14]
setblock 442 228 584 minecraft:light[level=14]
setblock 442 228 592 minecraft:light[level=14]
fill 442 228 599 442 233 599 minecraft:sea_lantern
fill 443 228 599 446 229 599 minecraft:yellow_concrete
fill 446 228 557 446 233 557 minecraft:sea_lantern
fill 447 228 599 449 228 599 minecraft:orange_concrete
setblock 450 228 560 minecraft:light[level=14]
setblock 450 228 568 minecraft:light[level=14]
setblock 450 228 576 minecraft:light[level=14]
setblock 450 228 584 minecraft:light[level=14]
setblock 450 228 592 minecraft:light[level=14]
fill 450 228 599 450 233 599 minecraft:sea_lantern
setblock 451 228 599 minecraft:orange_concrete
fill 454 228 557 454 233 557 minecraft:sea_lantern
fill 455 228 599 456 229 599 minecraft:yellow_concrete
fill 456 228 557 458 229 557 minecraft:yellow_concrete
setblock 458 228 560 minecraft:light[level=14]
setblock 458 228 568 minecraft:light[level=14]
setblock 458 228 576 minecraft:light[level=14]
setblock 458 228 584 minecraft:light[level=14]
setblock 458 228 592 minecraft:light[level=14]
fill 458 228 599 458 233 599 minecraft:sea_lantern
fill 459 228 557 460 228 557 minecraft:orange_concrete
fill 459 228 599 459 230 599 minecraft:yellow_concrete
fill 461 228 557 461 229 557 minecraft:yellow_concrete
fill 462 228 557 462 233 557 minecraft:sea_lantern
fill 463 228 557 463 230 557 minecraft:yellow_concrete
fill 463 228 599 463 230 599 minecraft:yellow_concrete
fill 465 228 562 465 233 562 minecraft:sea_lantern
fill 465 228 570 465 233 570 minecraft:sea_lantern
fill 465 228 574 465 229 576 minecraft:yellow_concrete
setblock 465 228 577 minecraft:orange_concrete
fill 465 228 578 465 233 578 minecraft:sea_lantern
setblock 465 228 579 minecraft:orange_concrete
fill 465 228 580 465 229 580 minecraft:yellow_concrete
fill 465 228 586 465 233 586 minecraft:sea_lantern
setblock 465 228 590 minecraft:orange_concrete
fill 465 228 591 465 229 592 minecraft:yellow_concrete
fill 465 228 594 465 233 594 minecraft:sea_lantern
setblock 465 228 595 minecraft:orange_concrete
setblock 465 228 598 minecraft:orange_concrete
setblock 423 229 566 minecraft:yellow_concrete
setblock 423 229 569 minecraft:yellow_concrete
setblock 423 229 571 minecraft:yellow_concrete
setblock 423 229 575 minecraft:yellow_concrete
setblock 423 229 589 minecraft:yellow_concrete
setblock 425 229 557 minecraft:yellow_concrete
setblock 429 229 557 minecraft:yellow_concrete
setblock 431 229 599 minecraft:yellow_concrete
fill 440 229 585 441 230 586 minecraft:blue_concrete
fill 441 229 587 441 230 587 minecraft:blue_concrete
fill 447 229 599 449 229 599 minecraft:yellow_concrete
setblock 451 229 599 minecraft:yellow_concrete
fill 459 229 557 460 229 557 minecraft:yellow_concrete
setblock 465 229 577 minecraft:yellow_concrete
setblock 465 229 579 minecraft:yellow_concrete
fill 465 229 590 465 230 590 minecraft:yellow_concrete
setblock 465 229 595 minecraft:yellow_concrete
setblock 465 229 598 minecraft:yellow_concrete
fill 423 230 557 423 264 561 minecraft:orange_concrete
setblock 423 230 563 minecraft:yellow_concrete
fill 423 230 564 423 264 566 minecraft:orange_concrete
setblock 423 230 567 minecraft:yellow_concrete
fill 423 230 568 423 231 569 minecraft:orange_concrete
fill 423 230 571 423 264 573 minecraft:orange_concrete
fill 423 230 575 423 230 577 minecraft:orange_concrete
fill 423 230 579 423 266 581 minecraft:orange_concrete
setblock 423 230 582 minecraft:yellow_concrete
fill 423 230 583 423 231 585 minecraft:orange_concrete
fill 423 230 587 423 230 590 minecraft:orange_concrete
fill 423 230 592 423 268 593 minecraft:orange_concrete
fill 423 230 595 423 231 599 minecraft:orange_concrete
fill 424 230 557 429 230 557 minecraft:orange_concrete
fill 424 230 599 425 268 599 minecraft:orange_concrete
fill 427 230 599 433 230 599 minecraft:orange_concrete
fill 431 230 557 432 230 557 minecraft:orange_concrete
setblock 433 230 557 minecraft:yellow_concrete
fill 434 230 557 437 230 557 minecraft:orange_concrete
fill 435 230 599 441 231 599 minecraft:orange_concrete
fill 439 230 557 440 265 557 minecraft:orange_concrete
setblock 441 230 557 minecraft:yellow_concrete
fill 442 230 557 444 268 557 minecraft:orange_concrete
fill 443 230 599 445 264 599 minecraft:orange_concrete
setblock 445 230 557 minecraft:yellow_concrete
setblock 446 230 599 minecraft:yellow_concrete
fill 447 230 557 453 230 557 minecraft:orange_concrete
fill 447 230 599 449 231 599 minecraft:orange_concrete
fill 451 230 599 451 268 599 minecraft:orange_concrete
setblock 452 230 599 minecraft:yellow_concrete
fill 453 230 599 457 230 599 minecraft:orange_concrete
fill 455 230 557 456 265 557 minecraft:orange_concrete
setblock 457 230 557 minecraft:yellow_concrete
fill 458 230 557 461 231 557 minecraft:orange_concrete
fill 460 230 599 462 265 599 minecraft:orange_concrete
fill 464 230 557 465 231 557 minecraft:orange_concrete
fill 464 230 599 465 230 599 minecraft:orange_concrete
fill 465 230 558 465 265 560 minecraft:orange_concrete
fill 465 230 563 465 266 569 minecraft:orange_concrete
fill 465 230 571 465 230 577 minecraft:orange_concrete
fill 465 230 579 465 268 582 minecraft:orange_concrete
fill 465 230 584 465 268 585 minecraft:orange_concrete
fill 465 230 587 465 230 589 minecraft:orange_concrete
fill 465 230 591 465 264 591 minecraft:orange_concrete
setblock 465 230 592 minecraft:yellow_concrete
fill 465 230 593 465 268 593 minecraft:orange_concrete
fill 465 230 595 465 231 598 minecraft:orange_concrete
fill 423 231 563 423 265 563 minecraft:orange_concrete
fill 423 231 567 423 264 567 minecraft:orange_concrete
fill 423 231 574 423 266 574 minecraft:orange_concrete
fill 423 231 575 423 231 576 minecraft:yellow_concrete
fill 423 231 577 423 268 577 minecraft:orange_concrete
fill 423 231 582 423 265 582 minecraft:orange_concrete
fill 423 231 587 423 265 589 minecraft:orange_concrete
setblock 423 231 590 minecraft:yellow_concrete
fill 423 231 591 423 264 591 minecraft:orange_concrete
fill 424 231 557 426 231 557 minecraft:yellow_concrete
fill 427 231 557 429 264 557 minecraft:orange_concrete
fill 427 231 599 427 232 599 minecraft:yellow_concrete
fill 428 231 599 433 264 599 minecraft:orange_concrete
setblock 431 231 557 minecraft:yellow_concrete
fill 432 231 557 435 231 557 minecraft:orange_concrete
setblock 436 231 557 minecraft:yellow_concrete
fill 437 231 557 437 269 557 minecraft:orange_concrete
fill 441 231 557 441 264 557 minecraft:orange_concrete
fill 445 231 557 445 266 557 minecraft:orange_concrete
fill 446 231 599 446 268 599 minecraft:orange_concrete
fill 447 231 557 449 268 557 minecraft:orange_concrete
setblock 450 231 557 minecraft:yellow_concrete
fill 451 231 557 453 264 557 minecraft:orange_concrete
fill 452 231 599 452 266 599 minecraft:orange_concrete
setblock 453 231 599 minecraft:yellow_concrete
fill 454 231 599 457 265 599 minecraft:orange_concrete
fill 457 231 557 457 268 557 minecraft:orange_concrete
fill 459 231 599 459 264 599 minecraft:orange_concrete
fill 463 231 557 463 268 557 minecraft:orange_concrete
setblock 463 231 599 minecraft:orange_concrete
setblock 464 231 599 minecraft:yellow_concrete
fill 465 231 561 465 268 561 minecraft:orange_concrete
fill 465 231 571 465 268 571 minecraft:orange_concrete
setblock 465 231 572 minecraft:yellow_concrete
fill 465 231 573 465 231 577 minecraft:orange_concrete
fill 465 231 583 465 264 583 minecraft:orange_concrete
fill 465 231 587 465 268 588 minecraft:orange_concrete
setblock 465 231 589 minecraft:yellow_concrete
fill 465 231 590 465 268 590 minecraft:orange_concrete
fill 465 231 592 465 268 592 minecraft:orange_concrete
fill 465 231 599 465 266 599 minecraft:orange_concrete
fill 423 232 568 423 268 568 minecraft:orange_concrete
setblock 423 232 569 minecraft:yellow_concrete
setblock 423 232 575 minecraft:yellow_concrete
fill 423 232 576 423 268 576 minecraft:orange_concrete
setblock 423 232 583 minecraft:yellow_concrete
fill 423 232 584 423 268 585 minecraft:orange_concrete
fill 423 232 590 423 264 590 minecraft:orange_concrete
fill 423 232 595 423 265 598 minecraft:orange_concrete
setblock 423 232 599 minecraft:yellow_concrete
fill 424 232 557 426 265 557 minecraft:orange_concrete
fill 431 232 557 434 268 557 minecraft:orange_concrete
setblock 435 232 557 minecraft:yellow_concrete
fill 435 232 599 435 264 599 minecraft:orange_concrete
fill 436 232 557 436 268 557 minecraft:orange_concrete
setblock 436 232 599 minecraft:yellow_concrete
fill 437 232 599 438 268 599 minecraft:orange_concrete
fill 438 232 563 440 233 563 minecraft:purple_concrete
fill 439 232 564 439 233 564 minecraft:purple_concrete
setblock 439 232 599 minecraft:yellow_concrete
fill 440 232 599 441 268 599 minecraft:orange_concrete
fill 447 232 599 448 268 599 minecraft:orange_concrete
setblock 449 232 599 minecraft:yellow_concrete
fill 450 232 557 450 268 557 minecraft:orange_concrete
fill 453 232 599 453 266 599 minecraft:orange_concrete
fill 458 232 557 459 268 557 minecraft:orange_concrete
setblock 460 232 557 minecraft:yellow_concrete
fill 461 232 557 461 264 557 minecraft:orange_concrete
setblock 463 232 599 minecraft:yellow_concrete
fill 464 232 557 464 265 557 minecraft:orange_concrete
fill 464 232 599 464 268 599 minecraft:orange_concrete
setblock 465 232 557 minecraft:yellow_concrete
fill 465 232 572 465 268 574 minecraft:orange_concrete
setblock 465 232 575 minecraft:yellow_concrete
fill 465 232 576 465 268 577 minecraft:orange_concrete
fill 465 232 589 465 268 589 minecraft:orange_concrete
fill 465 232 595 465 269 595 minecraft:orange_concrete
setblock 465 232 596 minecraft:yellow_concrete
fill 465 232 597 465 265 598 minecraft:orange_concrete
fill 423 233 569 423 268 569 minecraft:orange_concrete
fill 423 233 575 423 269 575 minecraft:orange_concrete
fill 423 233 583 423 268 583 minecraft:orange_concrete
fill 423 233 599 423 264 599 minecraft:orange_concrete
fill 427 233 599 427 268 599 minecraft:orange_concrete
fill 435 233 557 435 268 557 minecraft:orange_concrete
fill 436 233 599 436 268 599 minecraft:orange_concrete
fill 439 233 599 439 268 599 minecraft:orange_concrete
fill 449 233 599 449 268 599 minecraft:orange_concrete
fill 460 233 557 460 268 557 minecraft:orange_concrete
fill 463 233 599 463 265 599 minecraft:orange_concrete
fill 465 233 557 465 268 557 minecraft:orange_concrete
fill 465 233 575 465 264 575 minecraft:orange_concrete
fill 465 233 596 465 268 596 minecraft:orange_concrete
fill 423 234 562 423 243 562 minecraft:orange_concrete
fill 423 234 570 423 243 570 minecraft:orange_concrete
fill 423 234 578 423 243 578 minecraft:orange_concrete
fill 423 234 586 423 243 586 minecraft:orange_concrete
fill 423 234 594 423 243 594 minecraft:orange_concrete
fill 426 234 599 426 243 599 minecraft:orange_concrete
fill 430 234 557 430 243 557 minecraft:orange_concrete
fill 434 234 599 434 243 599 minecraft:orange_concrete
fill 438 234 557 438 243 557 minecraft:orange_concrete
fill 442 234 599 442 243 599 minecraft:orange_concrete
fill 446 234 557 446 243 557 minecraft:orange_concrete
fill 450 234 599 450 243 599 minecraft:orange_concrete
fill 454 234 557 454 243 557 minecraft:orange_concrete
fill 458 234 599 458 243 599 minecraft:orange_concrete
fill 462 234 557 462 243 557 minecraft:orange_concrete
fill 465 234 562 465 243 562 minecraft:orange_concrete
fill 465 234 570 465 243 570 minecraft:orange_concrete
fill 465 234 578 465 243 578 minecraft:orange_concrete
fill 465 234 586 465 243 586 minecraft:orange_concrete
fill 465 234 594 465 243 594 minecraft:orange_concrete
setblock 426 236 560 minecraft:light[level=14]
setblock 426 236 568 minecraft:light[level=14]
setblock 426 236 576 minecraft:light[level=14]
setblock 426 236 584 minecraft:light[level=14]
setblock 426 236 592 minecraft:light[level=14]
setblock 434 236 560 minecraft:light[level=14]
setblock 434 236 568 minecraft:light[level=14]
setblock 434 236 576 minecraft:light[level=14]
setblock 434 236 584 minecraft:light[level=14]
setblock 434 236 592 minecraft:light[level=14]
setblock 442 236 560 minecraft:light[level=14]
setblock 442 236 568 minecraft:light[level=14]
setblock 442 236 576 minecraft:light[level=14]
setblock 442 236 584 minecraft:light[level=14]
setblock 442 236 592 minecraft:light[level=14]
setblock 450 236 560 minecraft:light[level=14]
setblock 450 236 568 minecraft:light[level=14]
setblock 450 236 576 minecraft:light[level=14]
setblock 450 236 584 minecraft:light[level=14]
setblock 450 236 592 minecraft:light[level=14]
setblock 458 236 560 minecraft:light[level=14]
setblock 458 236 568 minecraft:light[level=14]
setblock 458 236 576 minecraft:light[level=14]
setblock 458 236 584 minecraft:light[level=14]
setblock 458 236 592 minecraft:light[level=14]
fill 437 238 576 439 238 578 minecraft:redstone_block
fill 437 238 582 439 238 584 minecraft:redstone_block
fill 445 238 576 447 238 578 minecraft:redstone_block
fill 445 238 582 447 238 584 minecraft:redstone_block
fill 426 239 580 431 240 580 minecraft:yellow_concrete
fill 427 239 575 427 240 577 minecraft:purple_concrete
fill 427 239 578 432 240 579 minecraft:yellow_concrete
fill 427 239 581 427 240 585 minecraft:yellow_concrete
fill 428 239 573 428 240 576 minecraft:purple_concrete
fill 428 239 577 436 239 577 minecraft:yellow_concrete
fill 428 239 581 428 240 584 minecraft:yellow_concrete
fill 428 239 585 430 240 587 minecraft:purple_concrete
fill 429 239 571 429 240 572 minecraft:yellow_concrete
fill 429 239 573 430 240 575 minecraft:purple_concrete
fill 429 239 576 436 239 576 minecraft:yellow_concrete
fill 429 239 581 429 240 582 minecraft:yellow_concrete
fill 429 239 583 431 240 584 minecraft:purple_concrete
fill 429 239 588 430 240 589 minecraft:purple_concrete
fill 430 239 570 441 240 571 minecraft:yellow_concrete
fill 430 239 572 436 240 572 minecraft:purple_concrete
fill 430 239 581 430 240 581 minecraft:yellow_concrete
fill 430 239 582 433 240 582 minecraft:purple_concrete
fill 430 239 590 430 240 590 minecraft:purple_concrete
fill 431 239 569 440 240 569 minecraft:yellow_concrete
fill 431 239 573 438 240 574 minecraft:purple_concrete
fill 431 239 575 437 239 575 minecraft:yellow_concrete
fill 431 239 581 434 240 581 minecraft:purple_concrete
fill 431 239 585 431 240 585 minecraft:purple_concrete
fill 431 239 586 435 240 591 minecraft:yellow_concrete
fill 432 239 568 438 240 568 minecraft:yellow_concrete
fill 432 239 580 435 240 580 minecraft:purple_concrete
fill 432 239 583 432 240 583 minecraft:purple_concrete
fill 432 239 584 435 240 585 minecraft:yellow_concrete
fill 432 239 592 435 240 592 minecraft:yellow_concrete
fill 433 239 567 436 240 567 minecraft:yellow_concrete
fill 433 239 578 435 240 578 minecraft:yellow_concrete
fill 433 239 579 438 239 579 minecraft:purple_concrete
fill 433 239 583 436 239 583 minecraft:yellow_concrete
fill 433 239 593 436 240 593 minecraft:yellow_concrete
fill 434 239 582 436 239 582 minecraft:yellow_concrete
fill 435 239 566 441 240 566 minecraft:purple_concrete
fill 435 239 581 438 239 581 minecraft:yellow_concrete
fill 435 239 594 436 240 594 minecraft:yellow_concrete
setblock 436 239 578 minecraft:purple_concrete
fill 436 239 580 438 240 580 minecraft:yellow_concrete
setblock 436 239 584 minecraft:yellow_concrete
fill 436 239 585 437 239 592 minecraft:purple_concrete
fill 437 239 565 440 240 565 minecraft:purple_concrete
fill 437 239 567 442 240 567 minecraft:purple_concrete
fill 437 239 572 442 240 572 minecraft:yellow_concrete
fill 437 239 593 440 240 594 minecraft:purple_concrete
fill 437 239 595 437 240 595 minecraft:yellow_concrete
fill 438 239 575 440 239 575 minecraft:purple_concrete
setblock 438 239 585 minecraft:purple_concrete
fill 438 239 586 441 240 588 minecraft:yellow_concrete
fill 438 239 589 438 240 592 minecraft:purple_concrete
fill 438 239 595 442 240 595 minecraft:purple_concrete
fill 439 239 568 443 240 568 minecraft:purple_concrete
fill 439 239 573 443 240 573 minecraft:yellow_concrete
fill 439 239 574 439 240 574 minecraft:purple_concrete
fill 439 239 579 440 239 581 minecraft:white_concrete
fill 439 239 585 440 239 585 minecraft:yellow_concrete
fill 439 239 589 442 240 591 minecraft:yellow_concrete
fill 439 239 592 439 240 592 minecraft:purple_concrete
fill 440 239 574 443 240 574 minecraft:yellow_concrete
fill 440 239 576 441 239 576 minecraft:purple_concrete
setblock 440 239 577 minecraft:yellow_concrete
fill 440 239 578 444 239 578 minecraft:white_concrete
fill 440 239 582 444 239 582 minecraft:white_concrete
fill 440 239 583 440 239 584 minecraft:yellow_concrete
fill 440 239 592 447 240 592 minecraft:yellow_concrete
fill 441 239 565 447 240 565 minecraft:yellow_concrete
fill 441 239 569 444 240 569 minecraft:purple_concrete
fill 441 239 575 443 240 575 minecraft:yellow_concrete
fill 441 239 577 443 240 577 minecraft:white_concrete
fill 441 239 583 443 240 583 minecraft:white_concrete
fill 441 239 584 442 240 585 minecraft:purple_concrete
fill 441 239 593 451 240 593 minecraft:yellow_concrete
fill 441 239 594 441 240 594 minecraft:purple_concrete
fill 442 239 564 442 240 564 minecraft:yellow_concrete
fill 442 239 566 448 240 566 minecraft:yellow_concrete
fill 442 239 570 444 240 570 minecraft:purple_concrete
fill 442 239 571 442 240 571 minecraft:yellow_concrete
fill 442 239 576 443 240 576 minecraft:yellow_concrete
fill 442 239 586 443 240 587 minecraft:purple_concrete
fill 442 239 588 442 240 588 minecraft:yellow_concrete
fill 442 239 594 449 240 594 minecraft:yellow_concrete
fill 442 239 596 442 240 596 minecraft:purple_concrete
fill 443 239 567 448 240 567 minecraft:yellow_concrete
fill 443 239 571 445 240 572 minecraft:purple_concrete
fill 443 239 584 444 239 585 minecraft:yellow_concrete
fill 443 239 588 445 240 589 minecraft:purple_concrete
fill 443 239 590 443 240 591 minecraft:yellow_concrete
fill 443 239 595 447 240 595 minecraft:yellow_concrete
fill 444 239 568 449 240 568 minecraft:yellow_concrete
fill 444 239 573 444 239 577 minecraft:purple_concrete
fill 444 239 579 445 239 581 minecraft:white_concrete
setblock 444 239 583 minecraft:purple_concrete
fill 444 239 586 456 240 586 minecraft:yellow_concrete
fill 444 239 587 444 240 587 minecraft:purple_concrete
fill 444 239 590 454 240 590 minecraft:purple_concrete
fill 444 239 591 445 240 591 minecraft:yellow_concrete
fill 445 239 569 449 240 570 minecraft:yellow_concrete
fill 445 239 573 445 239 575 minecraft:purple_concrete
fill 445 239 585 457 239 585 minecraft:yellow_concrete
fill 445 239 587 456 240 587 minecraft:yellow_concrete
fill 446 239 571 448 239 575 minecraft:yellow_concrete
fill 446 239 579 447 239 580 minecraft:purple_concrete
fill 446 239 581 452 239 581 minecraft:yellow_concrete
fill 446 239 588 455 240 588 minecraft:yellow_concrete
fill 446 239 589 447 240 589 minecraft:purple_concrete
fill 446 239 591 453 240 591 minecraft:purple_concrete
setblock 448 239 576 minecraft:yellow_concrete
fill 448 239 577 448 239 579 minecraft:purple_concrete
fill 448 239 580 454 240 580 minecraft:yellow_concrete
fill 448 239 582 451 239 582 minecraft:yellow_concrete
fill 448 239 583 453 239 584 minecraft:purple_concrete
fill 448 239 589 454 240 589 minecraft:yellow_concrete
fill 448 239 592 452 240 592 minecraft:purple_concrete
fill 449 239 566 449 240 567 minecraft:purple_concrete
fill 449 239 571 449 240 574 minecraft:yellow_concrete
fill 449 239 575 449 240 578 minecraft:purple_concrete
fill 449 239 579 455 240 579 minecraft:yellow_concrete
fill 450 239 567 450 240 577 minecraft:purple_concrete
fill 450 239 578 455 240 578 minecraft:yellow_concrete
fill 451 239 567 451 240 576 minecraft:purple_concrete
fill 451 239 577 456 240 577 minecraft:yellow_concrete
fill 452 239 568 452 240 574 minecraft:purple_concrete
fill 452 239 575 456 240 576 minecraft:yellow_concrete
fill 452 239 582 456 240 582 minecraft:purple_concrete
fill 453 239 569 453 240 574 minecraft:yellow_concrete
fill 453 239 581 457 240 581 minecraft:purple_concrete
fill 454 239 570 454 240 574 minecraft:yellow_concrete
fill 454 239 583 455 240 583 minecraft:purple_concrete
fill 454 239 584 457 240 584 minecraft:yellow_concrete
fill 455 239 571 455 240 574 minecraft:yellow_concrete
fill 455 239 580 458 240 580 minecraft:purple_concrete
fill 455 239 589 455 240 589 minecraft:purple_concrete
fill 456 239 573 456 240 574 minecraft:yellow_concrete
fill 456 239 578 457 240 579 minecraft:purple_concrete
fill 456 239 583 457 240 583 minecraft:yellow_concrete
fill 457 239 575 457 240 575 minecraft:yellow_concrete
fill 457 239 576 457 240 577 minecraft:purple_concrete
fill 457 239 582 457 240 582 minecraft:yellow_concrete
fill 424 240 558 425 240 598 minecraft:white_concrete
fill 426 240 558 426 240 579 minecraft:white_concrete
fill 426 240 581 426 240 598 minecraft:white_concrete
fill 427 240 558 427 240 574 minecraft:white_concrete
fill 427 240 586 427 240 598 minecraft:white_concrete
fill 428 240 558 428 240 572 minecraft:white_concrete
fill 428 240 577 435 240 577 minecraft:yellow_concrete
fill 428 240 588 428 240 598 minecraft:white_concrete
fill 429 240 558 429 240 570 minecraft:white_concrete
fill 429 240 576 435 240 576 minecraft:yellow_concrete
fill 429 240 590 429 240 598 minecraft:white_concrete
fill 430 240 558 430 240 569 minecraft:white_concrete
fill 430 240 591 430 240 598 minecraft:white_concrete
fill 431 240 558 431 240 568 minecraft:white_concrete
fill 431 240 575 435 240 575 minecraft:yellow_concrete
fill 431 240 592 431 240 598 minecraft:white_concrete
fill 432 240 558 432 240 567 minecraft:white_concrete
fill 432 240 593 432 240 598 minecraft:white_concrete
fill 433 240 558 434 240 566 minecraft:white_concrete
fill 433 240 579 435 240 579 minecraft:purple_concrete
fill 433 240 583 435 240 583 minecraft:yellow_concrete
fill 433 240 594 434 240 598 minecraft:white_concrete
fill 434 240 582 435 240 582 minecraft:yellow_concrete
fill 435 240 558 436 240 565 minecraft:white_concrete
setblock 435 240 581 minecraft:yellow_concrete
fill 435 240 595 436 240 598 minecraft:white_concrete
fill 436 240 575 436 240 579 minecraft:sea_lantern
fill 436 240 581 436 240 585 minecraft:sea_lantern
fill 436 240 586 437 240 592 minecraft:purple_concrete
fill 437 240 558 441 240 564 minecraft:white_concrete
fill 437 240 575 440 240 575 minecraft:sea_lantern
fill 437 240 576 439 240 578 minecraft:white_concrete
fill 437 240 579 440 240 579 minecraft:sea_lantern
fill 437 240 581 440 240 581 minecraft:sea_lantern
fill 437 240 582 439 240 584 minecraft:white_concrete
fill 437 240 585 440 240 585 minecraft:sea_lantern
fill 437 240 596 441 240 598 minecraft:white_concrete
setblock 439 240 580 minecraft:white_concrete
fill 440 240 576 440 240 578 minecraft:sea_lantern
setblock 440 240 580 minecraft:sea_lantern
fill 440 240 582 440 240 584 minecraft:sea_lantern
setblock 441 240 576 minecraft:purple_concrete
fill 441 240 578 444 240 578 minecraft:sea_lantern
fill 441 240 582 444 240 582 minecraft:sea_lantern
fill 442 240 558 464 240 563 minecraft:white_concrete
fill 442 240 597 464 240 598 minecraft:white_concrete
fill 443 240 564 464 240 564 minecraft:white_concrete
fill 443 240 584 443 240 585 minecraft:yellow_concrete
fill 443 240 596 464 240 596 minecraft:white_concrete
fill 444 240 573 445 240 574 minecraft:purple_concrete
fill 444 240 575 444 240 577 minecraft:sea_lantern
fill 444 240 579 444 240 581 minecraft:sea_lantern
fill 444 240 583 444 240 585 minecraft:sea_lantern
fill 445 240 575 448 240 575 minecraft:sea_lantern
fill 445 240 576 447 240 578 minecraft:white_concrete
fill 445 240 579 448 240 579 minecraft:sea_lantern
setblock 445 240 580 minecraft:white_concrete
fill 445 240 581 448 240 581 minecraft:sea_lantern
fill 445 240 582 447 240 584 minecraft:white_concrete
fill 445 240 585 448 240 585 minecraft:sea_lantern
fill 446 240 571 448 240 574 minecraft:yellow_concrete
fill 446 240 580 447 240 580 minecraft:purple_concrete
fill 448 240 565 464 240 565 minecraft:white_concrete
fill 448 240 576 448 240 578 minecraft:sea_lantern
fill 448 240 582 448 240 584 minecraft:sea_lantern
fill 448 240 595 464 240 595 minecraft:white_concrete
fill 449 240 581 451 240 582 minecraft:yellow_concrete
fill 449 240 583 453 240 584 minecraft:purple_concrete
fill 449 240 585 457 240 585 minecraft:yellow_concrete
fill 450 240 566 464 240 566 minecraft:white_concrete
fill 450 240 594 464 240 594 minecraft:white_concrete
fill 452 240 567 464 240 567 minecraft:white_concrete
setblock 452 240 581 minecraft:yellow_concrete
fill 452 240 593 464 240 593 minecraft:white_concrete
fill 453 240 568 464 240 568 minecraft:white_concrete
fill 453 240 592 464 240 592 minecraft:white_concrete
fill 454 240 569 464 240 569 minecraft:white_concrete
fill 454 240 591 464 240 591 minecraft:white_concrete
fill 455 240 570 464 240 570 minecraft:white_concrete
fill 455 240 590 464 240 590 minecraft:white_concrete
fill 456 240 571 464 240 572 minecraft:white_concrete
fill 456 240 588 464 240 589 minecraft:white_concrete
fill 457 240 573 464 240 574 minecraft:white_concrete
fill 457 240 586 464 240 587 minecraft:white_concrete
fill 458 240 575 464 240 579 minecraft:white_concrete
fill 458 240 581 464 240 585 minecraft:white_concrete
fill 459 240 580 464 240 580 minecraft:white_concrete
fill 423 244 562 423 247 562 minecraft:sea_lantern
fill 423 244 570 423 247 570 minecraft:sea_lantern
fill 423 244 578 423 247 578 minecraft:sea_lantern
fill 423 244 586 423 247 586 minecraft:sea_lantern
fill 423 244 594 423 247 594 minecraft:sea_lantern
fill 424 244 564 424 273 565 minecraft:white_concrete
fill 424 244 572 424 273 573 minecraft:white_concrete
fill 424 244 580 424 273 581 minecraft:white_concrete
fill 424 244 588 424 273 589 minecraft:white_concrete
fill 424 244 596 424 273 597 minecraft:white_concrete
fill 425 244 558 426 273 558 minecraft:white_concrete
setblock 426 244 560 minecraft:light[level=14]
setblock 426 244 568 minecraft:light[level=14]
setblock 426 244 576 minecraft:light[level=14]
setblock 426 244 584 minecraft:light[level=14]
setblock 426 244 592 minecraft:light[level=14]
fill 426 244 599 426 247 599 minecraft:sea_lantern
fill 430 244 557 430 247 557 minecraft:sea_lantern
fill 430 244 598 431 273 598 minecraft:white_concrete
fill 433 244 558 434 273 558 minecraft:white_concrete
setblock 434 244 560 minecraft:light[level=14]
setblock 434 244 568 minecraft:light[level=14]
setblock 434 244 576 minecraft:light[level=14]
setblock 434 244 584 minecraft:light[level=14]
setblock 434 244 592 minecraft:light[level=14]
fill 434 244 599 434 247 599 minecraft:sea_lantern
fill 438 244 557 438 247 557 minecraft:sea_lantern
fill 438 244 598 439 273 598 minecraft:white_concrete
fill 441 244 558 442 273 558 minecraft:white_concrete
setblock 442 244 560 minecraft:light[level=14]
setblock 442 244 568 minecraft:light[level=14]
setblock 442 244 576 minecraft:light[level=14]
setblock 442 244 584 minecraft:light[level=14]
setblock 442 244 592 minecraft:light[level=14]
fill 442 244 599 442 247 599 minecraft:sea_lantern
fill 446 244 557 446 247 557 minecraft:sea_lantern
fill 446 244 598 447 273 598 minecraft:white_concrete
fill 449 244 558 450 273 558 minecraft:white_concrete
setblock 450 244 560 minecraft:light[level=14]
fill 450 244 564 451 245 565 minecraft:red_concrete
setblock 450 244 568 minecraft:light[level=14]
setblock 450 244 576 minecraft:light[level=14]
setblock 450 244 584 minecraft:light[level=14]
setblock 450 244 592 minecraft:light[level=14]
fill 450 244 599 450 247 599 minecraft:sea_lantern
fill 454 244 557 454 247 557 minecraft:sea_lantern
fill 454 244 598 455 273 598 minecraft:white_concrete
fill 457 244 558 458 273 558 minecraft:white_concrete
setblock 458 244 560 minecraft:light[level=14]
setblock 458 244 568 minecraft:light[level=14]
setblock 458 244 576 minecraft:light[level=14]
setblock 458 244 584 minecraft:light[level=14]
setblock 458 244 592 minecraft:light[level=14]
fill 458 244 599 458 247 599 minecraft:sea_lantern
fill 462 244 557 462 247 557 minecraft:sea_lantern
fill 462 244 598 463 273 598 minecraft:white_concrete
fill 464 244 559 464 273 560 minecraft:white_concrete
fill 464 244 567 464 273 568 minecraft:white_concrete
fill 464 244 575 464 273 576 minecraft:white_concrete
fill 464 244 583 464 273 584 minecraft:white_concrete
fill 464 244 591 464 273 592 minecraft:white_concrete
fill 465 244 562 465 247 562 minecraft:sea_lantern
fill 465 244 570 465 247 570 minecraft:sea_lantern
fill 465 244 578 465 247 578 minecraft:sea_lantern
fill 465 244 586 465 247 586 minecraft:sea_lantern
fill 465 244 594 465 247 594 minecraft:sea_lantern
fill 423 248 562 423 255 562 minecraft:orange_concrete
fill 423 248 570 423 255 570 minecraft:orange_concrete
fill 423 248 578 423 255 578 minecraft:orange_concrete
fill 423 248 586 423 255 586 minecraft:orange_concrete
fill 423 248 594 423 255 594 minecraft:orange_concrete
fill 426 248 599 426 255 599 minecraft:orange_concrete
fill 430 248 557 430 255 557 minecraft:orange_concrete
fill 434 248 599 434 255 599 minecraft:orange_concrete
fill 438 248 557 438 255 557 minecraft:orange_concrete
fill 442 248 599 442 255 599 minecraft:orange_concrete
fill 446 248 557 446 255 557 minecraft:orange_concrete
fill 450 248 599 450 255 599 minecraft:orange_concrete
fill 452 248 587 453 249 588 minecraft:orange_concrete
fill 454 248 557 454 255 557 minecraft:orange_concrete
fill 455 248 574 456 249 574 minecraft:red_concrete
fill 458 248 599 458 255 599 minecraft:orange_concrete
fill 462 248 557 462 255 557 minecraft:orange_concrete
fill 465 248 562 465 255 562 minecraft:orange_concrete
fill 465 248 570 465 255 570 minecraft:orange_concrete
fill 465 248 578 465 255 578 minecraft:orange_concrete
fill 465 248 586 465 255 586 minecraft:orange_concrete
fill 465 248 594 465 255 594 minecraft:orange_concrete
fill 452 249 585 452 250 586 minecraft:light_blue_concrete
fill 457 251 595 457 251 597 minecraft:iron_block
fill 424 252 558 424 253 563 minecraft:white_concrete
fill 424 252 566 425 252 571 minecraft:white_concrete
fill 424 252 574 425 252 579 minecraft:white_concrete
fill 424 252 582 425 252 587 minecraft:white_concrete
fill 424 252 590 425 252 595 minecraft:white_concrete
fill 424 252 598 429 253 598 minecraft:white_concrete
fill 425 252 559 425 252 565 minecraft:white_concrete
fill 425 252 572 425 252 573 minecraft:white_concrete
fill 425 252 580 425 252 581 minecraft:white_concrete
fill 425 252 588 425 252 589 minecraft:white_concrete
fill 425 252 596 425 252 597 minecraft:white_concrete
fill 426 252 559 463 252 559 minecraft:white_concrete
setblock 426 252 560 minecraft:light[level=14]
setblock 426 252 568 minecraft:light[level=14]
setblock 426 252 576 minecraft:light[level=14]
setblock 426 252 584 minecraft:light[level=14]
setblock 426 252 592 minecraft:light[level=14]
fill 426 252 597 464 252 597 minecraft:white_concrete
fill 427 252 558 432 253 558 minecraft:white_concrete
fill 432 252 598 437 253 598 minecraft:white_concrete
setblock 434 252 560 minecraft:light[level=14]
setblock 434 252 568 minecraft:light[level=14]
setblock 434 252 576 minecraft:light[level=14]
setblock 434 252 584 minecraft:light[level=14]
setblock 434 252 592 minecraft:light[level=14]
fill 435 252 558 440 253 558 minecraft:white_concrete
fill 440 252 598 445 253 598 minecraft:white_concrete
setblock 442 252 560 minecraft:light[level=14]
setblock 442 252 568 minecraft:light[level=14]
setblock 442 252 576 minecraft:light[level=14]
setblock 442 252 584 minecraft:light[level=14]
setblock 442 252 592 minecraft:light[level=14]
fill 443 252 558 448 253 558 minecraft:white_concrete
fill 448 252 598 453 253 598 minecraft:white_concrete
setblock 450 252 560 minecraft:light[level=14]
setblock 450 252 568 minecraft:light[level=14]
setblock 450 252 576 minecraft:light[level=14]
setblock 450 252 584 minecraft:light[level=14]
setblock 450 252 592 minecraft:light[level=14]
fill 451 252 558 456 253 558 minecraft:white_concrete
fill 456 252 598 461 253 598 minecraft:white_concrete
fill 457 252 595 457 252 596 minecraft:iron_block
setblock 458 252 560 minecraft:light[level=14]
setblock 458 252 568 minecraft:light[level=14]
setblock 458 252 576 minecraft:light[level=14]
setblock 458 252 584 minecraft:light[level=14]
setblock 458 252 592 minecraft:light[level=14]
fill 459 252 558 464 253 558 minecraft:white_concrete
fill 463 252 560 463 252 596 minecraft:white_concrete
fill 464 252 561 464 253 566 minecraft:white_concrete
fill 464 252 569 464 253 574 minecraft:white_concrete
fill 464 252 577 464 253 582 minecraft:white_concrete
fill 464 252 585 464 253 590 minecraft:white_concrete
fill 464 252 593 464 253 596 minecraft:white_concrete
fill 464 252 598 464 253 598 minecraft:white_concrete
fill 424 253 566 424 253 571 minecraft:white_concrete
fill 424 253 574 424 253 579 minecraft:white_concrete
fill 424 253 582 424 253 587 minecraft:white_concrete
fill 424 253 590 424 253 595 minecraft:white_concrete
setblock 464 253 597 minecraft:white_concrete
fill 425 254 572 426 255 572 minecraft:iron_block
fill 461 254 586 461 255 586 minecraft:yellow_concrete
fill 426 255 574 427 256 582 minecraft:white_concrete
fill 427 255 571 428 256 573 minecraft:white_concrete
fill 427 255 583 428 256 585 minecraft:white_concrete
fill 428 255 569 429 256 570 minecraft:white_concrete
fill 428 255 586 429 256 587 minecraft:white_concrete
fill 429 255 568 430 256 568 minecraft:white_concrete
fill 429 255 571 429 256 571 minecraft:white_concrete
fill 429 255 585 429 256 585 minecraft:white_concrete
fill 429 255 588 430 256 588 minecraft:white_concrete
fill 430 255 566 431 256 567 minecraft:white_concrete
fill 430 255 569 430 256 569 minecraft:white_concrete
fill 430 255 587 430 256 587 minecraft:white_concrete
fill 430 255 589 431 256 590 minecraft:white_concrete
fill 431 255 565 433 256 565 minecraft:white_concrete
fill 431 255 591 433 256 591 minecraft:white_concrete
fill 432 255 564 435 256 564 minecraft:white_concrete
fill 432 255 566 432 256 566 minecraft:white_concrete
fill 432 255 590 432 256 590 minecraft:white_concrete
fill 432 255 592 435 256 592 minecraft:white_concrete
fill 434 255 563 437 256 563 minecraft:white_concrete
fill 434 255 593 437 256 593 minecraft:white_concrete
fill 435 255 562 439 256 562 minecraft:white_concrete
fill 435 255 594 439 256 594 minecraft:white_concrete
fill 437 255 561 451 256 561 minecraft:white_concrete
fill 437 255 595 451 256 595 minecraft:white_concrete
fill 440 255 560 448 256 560 minecraft:white_concrete
fill 440 255 596 448 256 596 minecraft:white_concrete
fill 449 255 562 453 256 562 minecraft:white_concrete
fill 449 255 594 453 256 594 minecraft:white_concrete
fill 451 255 563 454 256 563 minecraft:white_concrete
fill 451 255 593 454 256 593 minecraft:white_concrete
fill 453 255 564 456 256 564 minecraft:white_concrete
fill 453 255 592 456 256 592 minecraft:white_concrete
fill 455 255 565 457 256 565 minecraft:white_concrete
fill 455 255 591 457 256 591 minecraft:white_concrete
fill 456 255 566 458 256 566 minecraft:white_concrete
fill 456 255 590 458 256 590 minecraft:white_concrete
fill 457 255 567 458 256 567 minecraft:white_concrete
fill 457 255 589 458 256 589 minecraft:white_concrete
fill 458 255 568 459 256 569 minecraft:white_concrete
fill 458 255 587 459 256 588 minecraft:white_concrete
fill 459 255 570 460 256 571 minecraft:white_concrete
fill 459 255 585 460 256 586 minecraft:white_concrete
fill 460 255 569 460 256 569 minecraft:white_concrete
fill 460 255 572 461 256 573 minecraft:white_concrete
fill 460 255 583 461 256 584 minecraft:white_concrete
fill 460 255 587 460 256 587 minecraft:white_concrete
fill 461 255 571 461 256 571 minecraft:white_concrete
fill 461 255 574 462 256 582 minecraft:white_concrete
fill 461 255 585 461 256 585 minecraft:white_concrete
fill 423 256 562 423 261 562 minecraft:sea_lantern
fill 423 256 570 423 261 570 minecraft:sea_lantern
fill 423 256 578 423 261 578 minecraft:sea_lantern
fill 423 256 586 423 261 586 minecraft:sea_lantern
fill 423 256 594 423 261 594 minecraft:sea_lantern
fill 426 256 599 426 261 599 minecraft:sea_lantern
fill 430 256 557 430 261 557 minecraft:sea_lantern
fill 434 256 599 434 261 599 minecraft:sea_lantern
fill 438 256 557 438 261 557 minecraft:sea_lantern
fill 442 256 599 442 261 599 minecraft:sea_lantern
fill 446 256 557 446 261 557 minecraft:sea_lantern
fill 450 256 599 450 261 599 minecraft:sea_lantern
fill 454 256 557 454 261 557 minecraft:sea_lantern
fill 458 256 599 458 261 599 minecraft:sea_lantern
fill 462 256 557 462 261 557 minecraft:sea_lantern
fill 465 256 562 465 261 562 minecraft:sea_lantern
fill 465 256 570 465 261 570 minecraft:sea_lantern
fill 465 256 578 465 261 578 minecraft:sea_lantern
fill 465 256 586 465 261 586 minecraft:sea_lantern
fill 465 256 594 465 261 594 minecraft:sea_lantern
fill 428 257 586 428 257 587 minecraft:sea_lantern
setblock 429 257 588 minecraft:sea_lantern
fill 430 257 589 430 257 590 minecraft:sea_lantern
fill 431 257 590 431 257 591 minecraft:sea_lantern
fill 432 257 591 432 257 592 minecraft:sea_lantern
setblock 433 257 592 minecraft:sea_lantern
setblock 434 257 593 minecraft:sea_lantern
fill 435 257 594 436 257 594 minecraft:sea_lantern
fill 437 257 595 439 257 595 minecraft:sea_lantern
fill 440 257 596 448 257 596 minecraft:sea_lantern
fill 449 257 595 451 257 595 minecraft:sea_lantern
fill 452 257 594 453 257 594 minecraft:sea_lantern
setblock 454 257 593 minecraft:sea_lantern
fill 455 257 592 456 257 592 minecraft:sea_lantern
fill 456 257 591 457 257 591 minecraft:sea_lantern
fill 457 257 565 457 257 566 minecraft:sea_lantern
fill 457 257 590 458 257 590 minecraft:sea_lantern
fill 458 257 566 458 257 567 minecraft:sea_lantern
setblock 458 257 589 minecraft:sea_lantern
setblock 459 257 568 minecraft:sea_lantern
setblock 459 257 588 minecraft:sea_lantern
fill 460 257 569 460 257 570 minecraft:sea_lantern
fill 460 257 586 460 257 587 minecraft:sea_lantern
fill 461 257 571 461 257 573 minecraft:sea_lantern
fill 461 257 583 461 257 585 minecraft:sea_lantern
fill 462 257 574 462 257 582 minecraft:sea_lantern
setblock 426 260 560 minecraft:light[level=14]
setblock 426 260 568 minecraft:light[level=14]
setblock 426 260 576 minecraft:light[level=14]
setblock 426 260 584 minecraft:light[level=14]
setblock 426 260 592 minecraft:light[level=14]
fill 430 260 582 431 261 583 minecraft:red_concrete
setblock 434 260 560 minecraft:light[level=14]
setblock 434 260 568 minecraft:light[level=14]
setblock 434 260 576 minecraft:light[level=14]
setblock 434 260 584 minecraft:light[level=14]
setblock 434 260 592 minecraft:light[level=14]
setblock 442 260 560 minecraft:light[level=14]
setblock 442 260 568 minecraft:light[level=14]
setblock 442 260 576 minecraft:light[level=14]
setblock 442 260 584 minecraft:light[level=14]
setblock 442 260 592 minecraft:light[level=14]
setblock 450 260 560 minecraft:light[level=14]
setblock 450 260 568 minecraft:light[level=14]
setblock 450 260 576 minecraft:light[level=14]
setblock 450 260 584 minecraft:light[level=14]
setblock 450 260 592 minecraft:light[level=14]
fill 457 260 580 458 261 581 minecraft:lime_concrete
setblock 458 260 560 minecraft:light[level=14]
setblock 458 260 568 minecraft:light[level=14]
setblock 458 260 576 minecraft:light[level=14]
fill 458 260 579 458 261 579 minecraft:lime_concrete
setblock 458 260 584 minecraft:light[level=14]
setblock 458 260 592 minecraft:light[level=14]
fill 423 262 562 423 264 562 minecraft:orange_concrete
fill 423 262 570 423 268 570 minecraft:orange_concrete
fill 423 262 578 423 268 578 minecraft:orange_concrete
fill 423 262 586 423 268 586 minecraft:orange_concrete
fill 423 262 594 423 268 594 minecraft:orange_concrete
fill 426 262 599 426 268 599 minecraft:orange_concrete
fill 430 262 557 430 264 557 minecraft:orange_concrete
fill 432 262 579 432 263 580 minecraft:orange_concrete
fill 434 262 599 434 268 599 minecraft:orange_concrete
fill 438 262 557 438 269 557 minecraft:orange_concrete
fill 442 262 599 442 264 599 minecraft:orange_concrete
fill 446 262 557 446 269 557 minecraft:orange_concrete
fill 450 262 599 450 264 599 minecraft:orange_concrete
fill 454 262 557 454 264 557 minecraft:orange_concrete
fill 458 262 599 458 264 599 minecraft:orange_concrete
fill 462 262 557 462 268 557 minecraft:orange_concrete
fill 465 262 562 465 268 562 minecraft:orange_concrete
fill 465 262 570 465 268 570 minecraft:orange_concrete
fill 465 262 578 465 266 578 minecraft:orange_concrete
fill 465 262 586 465 268 586 minecraft:orange_concrete
fill 465 262 594 465 268 594 minecraft:orange_concrete
fill 423 265 557 423 265 560 minecraft:orange_concrete
fill 423 265 561 423 265 562 minecraft:red_concrete
fill 423 265 564 423 268 564 minecraft:orange_concrete
setblock 423 265 565 minecraft:red_concrete
fill 423 265 566 423 268 566 minecraft:orange_concrete
setblock 423 265 567 minecraft:red_concrete
fill 423 265 571 423 265 572 minecraft:red_concrete
fill 423 265 573 423 268 573 minecraft:orange_concrete
fill 423 265 590 423 265 591 minecraft:red_concrete
setblock 423 265 599 minecraft:red_concrete
setblock 427 265 557 minecraft:red_concrete
fill 428 265 557 429 268 557 minecraft:orange_concrete
fill 428 265 599 428 268 599 minecraft:orange_concrete
setblock 429 265 599 minecraft:red_concrete
setblock 430 265 557 minecraft:red_concrete
fill 430 265 599 431 266 599 minecraft:orange_concrete
setblock 432 265 599 minecraft:red_concrete
fill 433 265 599 433 269 599 minecraft:orange_concrete
setblock 435 265 599 minecraft:red_concrete
setblock 441 265 557 minecraft:red_concrete
fill 442 265 599 442 266 599 minecraft:red_concrete
setblock 443 265 599 minecraft:orange_concrete
setblock 444 265 599 minecraft:red_concrete
setblock 445 265 599 minecraft:orange_concrete
setblock 450 265 599 minecraft:red_concrete
fill 451 265 557 451 268 557 minecraft:orange_concrete
setblock 452 265 557 minecraft:red_concrete
fill 453 265 557 453 268 557 minecraft:orange_concrete
setblock 454 265 557 minecraft:red_concrete
fill 458 265 599 459 265 599 minecraft:red_concrete
setblock 461 265 557 minecraft:red_concrete
fill 465 265 575 465 266 575 minecraft:red_concrete
setblock 465 265 583 minecraft:red_concrete
setblock 465 265 591 minecraft:red_concrete
setblock 423 266 557 minecraft:red_concrete
fill 423 266 558 423 268 558 minecraft:orange_concrete
fill 423 266 559 423 267 559 minecraft:red_concrete
fill 423 266 560 423 268 562 minecraft:orange_concrete
fill 423 266 563 423 267 563 minecraft:red_concrete
fill 423 266 565 423 268 565 minecraft:orange_concrete
fill 423 266 567 423 269 567 minecraft:orange_concrete
fill 423 266 571 423 268 572 minecraft:orange_concrete
setblock 423 266 582 minecraft:red_concrete
setblock 423 266 587 minecraft:orange_concrete
setblock 423 266 588 minecraft:red_concrete
fill 423 266 589 423 266 591 minecraft:orange_concrete
fill 423 266 595 423 266 596 minecraft:orange_concrete
setblock 423 266 597 minecraft:red_concrete
fill 423 266 598 423 268 599 minecraft:orange_concrete
fill 424 266 557 425 268 557 minecraft:orange_concrete
fill 424 266 558 424 267 563 minecraft:white_concrete
fill 424 266 566 425 266 571 minecraft:white_concrete
fill 424 266 574 425 266 579 minecraft:white_concrete
fill 424 266 582 425 266 587 minecraft:white_concrete
fill 424 266 590 425 266 595 minecraft:white_concrete
fill 424 266 598 429 267 598 minecraft:white_concrete
fill 425 266 559 425 266 565 minecraft:white_concrete
fill 425 266 572 425 266 573 minecraft:white_concrete
fill 425 266 580 425 266 581 minecraft:white_concrete
fill 425 266 588 425 266 589 minecraft:white_concrete
fill 425 266 596 425 266 597 minecraft:white_concrete
setblock 426 266 557 minecraft:red_concrete
fill 426 266 559 463 266 559 minecraft:white_concrete
fill 426 266 597 464 266 597 minecraft:white_concrete
fill 427 266 557 427 268 557 minecraft:orange_concrete
fill 427 266 558 432 267 558 minecraft:white_concrete
fill 429 266 599 429 268 599 minecraft:orange_concrete
fill 430 266 557 430 268 557 minecraft:orange_concrete
fill 432 266 598 437 267 598 minecraft:white_concrete
fill 432 266 599 432 268 599 minecraft:orange_concrete
fill 435 266 558 440 267 558 minecraft:white_concrete
setblock 435 266 599 minecraft:orange_concrete
setblock 439 266 557 minecraft:red_concrete
fill 440 266 557 441 268 557 minecraft:orange_concrete
fill 440 266 598 445 267 598 minecraft:white_concrete
fill 443 266 558 448 267 558 minecraft:white_concrete
setblock 443 266 599 minecraft:red_concrete
fill 444 266 599 444 268 599 minecraft:orange_concrete
setblock 445 266 599 minecraft:red_concrete
fill 448 266 598 453 267 598 minecraft:white_concrete
fill 450 266 599 450 268 599 minecraft:orange_concrete
fill 451 266 558 456 267 558 minecraft:white_concrete
fill 452 266 557 452 268 557 minecraft:orange_concrete
setblock 454 266 557 minecraft:orange_concrete
setblock 454 266 599 minecraft:red_concrete
setblock 455 266 557 minecraft:red_concrete
fill 455 266 599 459 266 599 minecraft:orange_concrete
fill 456 266 557 456 268 557 minecraft:orange_concrete
fill 456 266 598 461 267 598 minecraft:white_concrete
fill 459 266 558 464 267 558 minecraft:white_concrete
setblock 460 266 599 minecraft:red_concrete
fill 461 266 557 461 268 557 minecraft:orange_concrete
fill 461 266 577 461 266 578 minecraft:purple_concrete
fill 461 266 599 462 266 599 minecraft:orange_concrete
fill 463 266 560 463 266 596 minecraft:white_concrete
setblock 463 266 599 minecraft:red_concrete
setblock 464 266 557 minecraft:red_concrete
fill 464 266 561 464 267 566 minecraft:white_concrete
fill 464 266 569 464 267 574 minecraft:white_concrete
fill 464 266 577 464 267 582 minecraft:white_concrete
fill 464 266 585 464 267 590 minecraft:white_concrete
fill 464 266 593 464 267 596 minecraft:white_concrete
fill 464 266 598 464 267 598 minecraft:white_concrete
setblock 465 266 558 minecraft:red_concrete
fill 465 266 559 465 268 559 minecraft:orange_concrete
setblock 465 266 560 minecraft:red_concrete
fill 465 266 583 465 268 583 minecraft:orange_concrete
fill 465 266 591 465 268 591 minecraft:orange_concrete
setblock 465 266 597 minecraft:orange_concrete
setblock 465 266 598 minecraft:red_concrete
fill 423 267 557 423 269 557 minecraft:orange_concrete
setblock 423 267 574 minecraft:red_concrete
fill 423 267 579 423 268 579 minecraft:orange_concrete
setblock 423 267 580 minecraft:red_concrete
fill 423 267 581 423 268 582 minecraft:orange_concrete
setblock 423 267 587 minecraft:red_concrete
fill 423 267 588 423 268 590 minecraft:orange_concrete
setblock 423 267 591 minecraft:red_concrete
fill 423 267 595 423 268 595 minecraft:orange_concrete
setblock 423 267 596 minecraft:red_concrete
fill 423 267 597 423 268 597 minecraft:orange_concrete
fill 424 267 566 424 267 571 minecraft:white_concrete
fill 424 267 574 424 267 579 minecraft:white_concrete
fill 424 267 582 424 267 587 minecraft:white_concrete
fill 424 267 590 424 267 595 minecraft:white_concrete
fill 426 267 557 426 268 557 minecraft:orange_concrete
fill 426 267 574 427 268 582 minecraft:white_concrete
fill 427 267 571 428 268 573 minecraft:white_concrete
fill 427 267 583 428 268 585 minecraft:white_concrete
fill 428 267 569 429 268 570 minecraft:white_concrete
fill 428 267 586 429 268 587 minecraft:white_concrete
fill 429 267 568 430 268 568 minecraft:white_concrete
fill 429 267 571 429 268 571 minecraft:white_concrete
fill 429 267 585 429 268 585 minecraft:white_concrete
fill 429 267 588 430 268 588 minecraft:white_concrete
fill 430 267 566 431 268 567 minecraft:white_concrete
fill 430 267 569 430 268 569 minecraft:white_concrete
fill 430 267 587 430 268 587 minecraft:white_concrete
fill 430 267 589 431 268 590 minecraft:white_concrete
fill 430 267 599 430 268 599 minecraft:orange_concrete
fill 431 267 565 433 268 565 minecraft:white_concrete
fill 431 267 591 433 268 591 minecraft:white_concrete
setblock 431 267 599 minecraft:red_concrete
fill 432 267 564 435 268 564 minecraft:white_concrete
fill 432 267 566 432 268 566 minecraft:white_concrete
fill 432 267 590 432 268 590 minecraft:white_concrete
fill 432 267 592 435 268 592 minecraft:white_concrete
fill 434 267 563 437 268 563 minecraft:white_concrete
fill 434 267 593 437 268 593 minecraft:white_concrete
fill 435 267 562 439 268 562 minecraft:white_concrete
fill 435 267 594 439 268 594 minecraft:white_concrete
setblock 435 267 599 minecraft:red_concrete
fill 437 267 561 451 268 561 minecraft:white_concrete
fill 437 267 595 451 268 595 minecraft:white_concrete
fill 439 267 557 439 268 557 minecraft:orange_concrete
fill 440 267 560 448 268 560 minecraft:white_concrete
fill 440 267 596 448 268 596 minecraft:white_concrete
fill 442 267 599 443 268 599 minecraft:orange_concrete
setblock 445 267 557 minecraft:red_concrete
fill 445 267 599 445 268 599 minecraft:orange_concrete
fill 449 267 562 453 268 562 minecraft:white_concrete
fill 449 267 594 453 268 594 minecraft:white_concrete
fill 451 267 563 454 268 563 minecraft:white_concrete
fill 451 267 593 454 268 593 minecraft:white_concrete
fill 452 267 599 453 267 599 minecraft:red_concrete
fill 453 267 564 456 268 564 minecraft:white_concrete
fill 453 267 592 456 268 592 minecraft:white_concrete
setblock 454 267 557 minecraft:red_concrete
fill 454 267 599 455 268 599 minecraft:orange_concrete
fill 455 267 557 455 268 557 minecraft:orange_concrete
fill 455 267 565 457 268 565 minecraft:white_concrete
fill 455 267 591 457 268 591 minecraft:white_concrete
fill 456 267 566 458 268 566 minecraft:white_concrete
fill 456 267 590 458 268 590 minecraft:white_concrete
setblock 456 267 599 minecraft:red_concrete
fill 457 267 567 458 268 567 minecraft:white_concrete
fill 457 267 589 458 268 589 minecraft:white_concrete
fill 457 267 599 458 268 599 minecraft:orange_concrete
fill 458 267 568 459 268 569 minecraft:white_concrete
fill 458 267 587 459 268 588 minecraft:white_concrete
fill 459 267 570 460 268 571 minecraft:white_concrete
fill 459 267 585 460 268 586 minecraft:white_concrete
setblock 459 267 599 minecraft:red_concrete
fill 460 267 569 460 268 569 minecraft:white_concrete
fill 460 267 572 461 268 573 minecraft:white_concrete
fill 460 267 583 461 268 584 minecraft:white_concrete
fill 460 267 587 460 268 587 minecraft:white_concrete
fill 460 267 599 461 268 599 minecraft:orange_concrete
fill 461 267 571 461 268 571 minecraft:white_concrete
fill 461 267 574 462 268 582 minecraft:white_concrete
fill 461 267 585 461 268 585 minecraft:white_concrete
setblock 462 267 599 minecraft:red_concrete
fill 463 267 599 463 268 599 minecraft:orange_concrete
fill 464 267 557 464 268 557 minecraft:orange_concrete
setblock 464 267 597 minecraft:white_concrete
fill 465 267 558 465 268 558 minecraft:orange_concrete
fill 465 267 560 465 268 560 minecraft:orange_concrete
fill 465 267 563 465 268 568 minecraft:orange_concrete
setblock 465 267 569 minecraft:red_concrete
fill 465 267 575 465 268 575 minecraft:orange_concrete
setblock 465 267 578 minecraft:red_concrete
setblock 465 267 597 minecraft:red_concrete
fill 465 267 598 465 268 598 minecraft:orange_concrete
setblock 465 267 599 minecraft:red_concrete
setblock 423 268 559 minecraft:orange_concrete
setblock 423 268 563 minecraft:orange_concrete
setblock 423 268 574 minecraft:orange_concrete
setblock 423 268 580 minecraft:orange_concrete
setblock 423 268 587 minecraft:orange_concrete
fill 423 268 591 423 269 591 minecraft:orange_concrete
setblock 423 268 596 minecraft:orange_concrete
setblock 426 268 560 minecraft:light[level=14]
setblock 426 268 568 minecraft:light[level=14]
setblock 426 268 584 minecraft:light[level=14]
setblock 426 268 592 minecraft:light[level=14]
fill 428 268 579 428 269 580 minecraft:yellow_concrete
setblock 431 268 599 minecraft:orange_concrete
setblock 434 268 560 minecraft:light[level=14]
setblock 434 268 568 minecraft:light[level=14]
setblock 434 268 576 minecraft:light[level=14]
setblock 434 268 584 minecraft:light[level=14]
setblock 435 268 599 minecraft:orange_concrete
fill 440 268 558 440 269 559 minecraft:iron_block
setblock 442 268 568 minecraft:light[level=14]
setblock 442 268 576 minecraft:light[level=14]
setblock 442 268 584 minecraft:light[level=14]
setblock 442 268 592 minecraft:light[level=14]
setblock 445 268 557 minecraft:orange_concrete
setblock 450 268 560 minecraft:light[level=14]
setblock 450 268 568 minecraft:light[level=14]
setblock 450 268 576 minecraft:light[level=14]
setblock 450 268 584 minecraft:light[level=14]
setblock 450 268 592 minecraft:light[level=14]
fill 452 268 599 453 268 599 minecraft:orange_concrete
setblock 454 268 557 minecraft:orange_concrete
setblock 456 268 599 minecraft:orange_concrete
setblock 458 268 560 minecraft:light[level=14]
setblock 458 268 576 minecraft:light[level=14]
setblock 458 268 584 minecraft:light[level=14]
setblock 458 268 592 minecraft:light[level=14]
fill 459 268 599 459 269 599 minecraft:orange_concrete
setblock 462 268 599 minecraft:orange_concrete
setblock 465 268 569 minecraft:orange_concrete
setblock 465 268 578 minecraft:orange_concrete
setblock 465 268 597 minecraft:orange_concrete
fill 465 268 599 465 270 599 minecraft:orange_concrete
fill 423 269 558 423 269 566 minecraft:red_concrete
fill 423 269 568 423 269 574 minecraft:red_concrete
fill 423 269 576 423 269 590 minecraft:red_concrete
fill 423 269 592 423 269 599 minecraft:red_concrete
fill 424 269 557 424 307 557 minecraft:red_concrete
fill 424 269 599 432 269 599 minecraft:red_concrete
setblock 425 269 557 minecraft:orange_concrete
fill 426 269 557 436 269 557 minecraft:red_concrete
fill 426 269 574 426 269 582 minecraft:sea_lantern
fill 427 269 571 427 269 573 minecraft:sea_lantern
fill 427 269 579 427 269 580 minecraft:yellow_concrete
fill 427 269 583 427 269 585 minecraft:sea_lantern
fill 428 269 569 428 269 570 minecraft:sea_lantern
fill 428 269 586 428 269 587 minecraft:sea_lantern
setblock 429 269 568 minecraft:sea_lantern
setblock 429 269 588 minecraft:sea_lantern
fill 430 269 566 430 269 567 minecraft:sea_lantern
fill 430 269 589 430 269 590 minecraft:sea_lantern
fill 431 269 565 431 269 566 minecraft:sea_lantern
fill 431 269 590 431 269 591 minecraft:sea_lantern
fill 432 269 564 432 269 565 minecraft:sea_lantern
fill 432 269 591 432 269 592 minecraft:sea_lantern
setblock 433 269 564 minecraft:sea_lantern
setblock 433 269 592 minecraft:sea_lantern
setblock 434 269 563 minecraft:sea_lantern
setblock 434 269 593 minecraft:sea_lantern
fill 434 269 599 447 269 599 minecraft:red_concrete
fill 435 269 562 436 269 562 minecraft:sea_lantern
fill 435 269 594 436 269 594 minecraft:sea_lantern
fill 437 269 561 438 269 561 minecraft:sea_lantern
fill 437 269 595 439 269 595 minecraft:sea_lantern
fill 439 269 557 439 270 557 minecraft:red_concrete
setblock 440 269 557 minecraft:orange_concrete
setblock 440 269 560 minecraft:iron_block
fill 440 269 596 448 269 596 minecraft:sea_lantern
fill 441 269 557 445 307 557 minecraft:red_concrete
fill 447 269 557 465 269 557 minecraft:red_concrete
setblock 448 269 599 minecraft:orange_concrete
fill 449 269 595 451 269 595 minecraft:sea_lantern
fill 449 269 599 458 269 599 minecraft:red_concrete
fill 452 269 594 453 269 594 minecraft:sea_lantern
setblock 454 269 593 minecraft:sea_lantern
fill 455 269 592 456 269 592 minecraft:sea_lantern
fill 456 269 591 457 269 591 minecraft:sea_lantern
fill 457 269 590 458 269 590 minecraft:sea_lantern
setblock 458 269 589 minecraft:sea_lantern
setblock 459 269 588 minecraft:sea_lantern
fill 460 269 586 460 269 587 minecraft:sea_lantern
fill 460 269 599 464 307 599 minecraft:red_concrete
fill 461 269 583 461 269 585 minecraft:sea_lantern
fill 462 269 579 462 269 582 minecraft:sea_lantern
fill 465 269 558 465 269 571 minecraft:red_concrete
setblock 465 269 572 minecraft:orange_concrete
fill 465 269 573 465 269 594 minecraft:red_concrete
fill 465 269 596 465 307 598 minecraft:red_concrete
fill 423 270 557 423 307 557 minecraft:red_concrete
setblock 423 270 558 minecraft:orange_concrete
fill 423 270 559 423 307 561 minecraft:red_concrete
fill 423 270 562 423 273 562 minecraft:sea_lantern
fill 423 270 563 423 307 569 minecraft:red_concrete
fill 423 270 570 423 273 570 minecraft:sea_lantern
fill 423 270 571 423 307 576 minecraft:red_concrete
setblock 423 270 577 minecraft:orange_concrete
fill 423 270 578 423 273 578 minecraft:sea_lantern
fill 423 270 579 423 270 585 minecraft:red_concrete
fill 423 270 586 423 273 586 minecraft:sea_lantern
fill 423 270 587 423 270 593 minecraft:red_concrete
fill 423 270 594 423 273 594 minecraft:sea_lantern
fill 423 270 595 423 307 597 minecraft:red_concrete
setblock 423 270 598 minecraft:orange_concrete
fill 423 270 599 425 307 599 minecraft:red_concrete
fill 425 270 557 426 307 557 minecraft:red_concrete
fill 426 270 599 426 273 599 minecraft:sea_lantern
setblock 427 270 557 minecraft:orange_concrete
setblock 427 270 599 minecraft:orange_concrete
fill 428 270 557 429 307 557 minecraft:red_concrete
fill 428 270 599 433 307 599 minecraft:red_concrete
fill 430 270 557 430 273 557 minecraft:sea_lantern
fill 431 270 557 437 270 557 minecraft:red_concrete
fill 434 270 599 434 273 599 minecraft:sea_lantern
fill 435 270 599 441 307 599 minecraft:red_concrete
fill 438 270 557 438 273 557 minecraft:sea_lantern
fill 440 270 557 440 307 557 minecraft:red_concrete
fill 442 270 599 442 273 599 minecraft:sea_lantern
fill 443 270 599 444 270 599 minecraft:red_concrete
setblock 445 270 599 minecraft:orange_concrete
fill 446 270 557 446 273 557 minecraft:sea_lantern
fill 446 270 599 449 307 599 minecraft:red_concrete
fill 447 270 557 452 270 557 minecraft:red_concrete
fill 450 270 599 450 273 599 minecraft:sea_lantern
fill 451 270 599 454 307 599 minecraft:red_concrete
setblock 453 270 557 minecraft:orange_concrete
fill 454 270 557 454 273 557 minecraft:sea_lantern
setblock 455 270 557 minecraft:orange_concrete
setblock 455 270 599 minecraft:orange_concrete
fill 456 270 557 461 307 557 minecraft:red_concrete
fill 456 270 599 457 270 599 minecraft:red_concrete
fill 458 270 599 458 273 599 minecraft:sea_lantern
fill 459 270 599 459 307 599 minecraft:red_concrete
fill 462 270 557 462 273 557 minecraft:sea_lantern
fill 463 270 557 465 270 557 minecraft:red_concrete
fill 465 270 558 465 307 561 minecraft:red_concrete
fill 465 270 562 465 273 562 minecraft:sea_lantern
setblock 465 270 563 minecraft:red_concrete
setblock 465 270 564 minecraft:orange_concrete
fill 465 270 565 465 307 565 minecraft:red_concrete
setblock 465 270 566 minecraft:orange_concrete
fill 465 270 567 465 307 569 minecraft:red_concrete
fill 465 270 570 465 273 570 minecraft:sea_lantern
fill 465 270 571 465 270 577 minecraft:red_concrete
fill 465 270 578 465 273 578 minecraft:sea_lantern
fill 465 270 579 465 307 584 minecraft:red_concrete
fill 465 270 585 465 271 585 minecraft:orange_concrete
fill 465 270 586 465 273 586 minecraft:sea_lantern
fill 465 270 587 465 307 589 minecraft:red_concrete
setblock 465 270 590 minecraft:orange_concrete
fill 465 270 591 465 307 593 minecraft:red_concrete
fill 465 270 594 465 273 594 minecraft:sea_lantern
setblock 465 270 595 minecraft:red_concrete
fill 423 271 558 423 307 558 minecraft:red_concrete
fill 423 271 577 423 307 577 minecraft:red_concrete
fill 423 271 579 423 307 580 minecraft:red_concrete
setblock 423 271 581 minecraft:orange_concrete
fill 423 271 582 423 307 585 minecraft:red_concrete
fill 423 271 587 423 307 587 minecraft:red_concrete
fill 423 271 588 423 271 589 minecraft:orange_concrete
fill 423 271 590 423 307 593 minecraft:red_concrete
fill 423 271 598 423 307 598 minecraft:red_concrete
fill 427 271 557 427 307 557 minecraft:red_concrete
fill 427 271 599 427 307 599 minecraft:red_concrete
fill 431 271 557 433 307 557 minecraft:red_concrete
fill 434 271 557 435 271 557 minecraft:orange_concrete
fill 436 271 557 437 307 557 minecraft:red_concrete
setblock 439 271 557 minecraft:orange_concrete
fill 443 271 599 443 307 599 minecraft:red_concrete
setblock 444 271 599 minecraft:orange_concrete
fill 445 271 599 445 307 599 minecraft:red_concrete
fill 447 271 557 449 307 557 minecraft:red_concrete
setblock 450 271 557 minecraft:orange_concrete
fill 451 271 557 453 307 557 minecraft:red_concrete
fill 455 271 557 455 307 557 minecraft:red_concrete
fill 455 271 599 456 307 599 minecraft:red_concrete
setblock 457 271 599 minecraft:orange_concrete
fill 463 271 557 464 307 557 minecraft:red_concrete
setblock 465 271 557 minecraft:orange_concrete
setblock 465 271 563 minecraft:orange_concrete
fill 465 271 564 465 307 564 minecraft:red_concrete
fill 465 271 566 465 307 566 minecraft:red_concrete
setblock 465 271 571 minecraft:orange_concrete
fill 465 271 572 465 307 575 minecraft:red_concrete
setblock 465 271 576 minecraft:orange_concrete
fill 465 271 577 465 307 577 minecraft:red_concrete
fill 465 271 590 465 307 590 minecraft:red_concrete
setblock 465 271 595 minecraft:orange_concrete
fill 465 271 599 465 307 599 minecraft:red_concrete
fill 423 272 581 423 307 581 minecraft:red_concrete
fill 423 272 588 423 307 589 minecraft:red_concrete
fill 434 272 557 435 307 557 minecraft:red_concrete
fill 439 272 557 439 307 557 minecraft:red_concrete
fill 444 272 599 444 307 599 minecraft:red_concrete
fill 450 272 557 450 307 557 minecraft:red_concrete
fill 457 272 599 457 307 599 minecraft:red_concrete
fill 465 272 557 465 307 557 minecraft:red_concrete
fill 465 272 563 465 307 563 minecraft:red_concrete
fill 465 272 571 465 307 571 minecraft:red_concrete
fill 465 272 576 465 307 576 minecraft:red_concrete
fill 465 272 585 465 307 585 minecraft:red_concrete
fill 465 272 595 465 307 595 minecraft:red_concrete
fill 423 274 562 423 283 562 minecraft:red_concrete
fill 423 274 570 423 283 570 minecraft:red_concrete
fill 423 274 578 423 283 578 minecraft:red_concrete
fill 423 274 586 423 283 586 minecraft:red_concrete
fill 423 274 594 423 283 594 minecraft:red_concrete
fill 426 274 599 426 283 599 minecraft:red_concrete
fill 430 274 557 430 283 557 minecraft:red_concrete
fill 434 274 599 434 283 599 minecraft:red_concrete
fill 438 274 557 438 283 557 minecraft:red_concrete
fill 442 274 599 442 283 599 minecraft:red_concrete
fill 446 274 557 446 283 557 minecraft:red_concrete
fill 450 274 599 450 283 599 minecraft:red_concrete
fill 454 274 557 454 283 557 minecraft:red_concrete
fill 458 274 599 458 283 599 minecraft:red_concrete
fill 462 274 557 462 283 557 minecraft:red_concrete
fill 465 274 562 465 283 562 minecraft:red_concrete
fill 465 274 570 465 283 570 minecraft:red_concrete
fill 465 274 578 465 283 578 minecraft:red_concrete
fill 465 274 586 465 283 586 minecraft:red_concrete
fill 465 274 594 465 283 594 minecraft:red_concrete
setblock 426 276 560 minecraft:light[level=14]
setblock 426 276 568 minecraft:light[level=14]
setblock 426 276 576 minecraft:light[level=14]
setblock 426 276 584 minecraft:light[level=14]
setblock 426 276 592 minecraft:light[level=14]
setblock 434 276 560 minecraft:light[level=14]
setblock 434 276 568 minecraft:light[level=14]
setblock 434 276 576 minecraft:light[level=14]
setblock 434 276 584 minecraft:light[level=14]
setblock 434 276 592 minecraft:light[level=14]
setblock 442 276 560 minecraft:light[level=14]
setblock 442 276 568 minecraft:light[level=14]
setblock 442 276 576 minecraft:light[level=14]
setblock 442 276 584 minecraft:light[level=14]
setblock 442 276 592 minecraft:light[level=14]
setblock 450 276 560 minecraft:light[level=14]
setblock 450 276 568 minecraft:light[level=14]
setblock 450 276 576 minecraft:light[level=14]
setblock 450 276 584 minecraft:light[level=14]
setblock 450 276 592 minecraft:light[level=14]
setblock 458 276 560 minecraft:light[level=14]
setblock 458 276 568 minecraft:light[level=14]
setblock 458 276 576 minecraft:light[level=14]
setblock 458 276 584 minecraft:light[level=14]
setblock 458 276 592 minecraft:light[level=14]
fill 437 278 573 439 278 575 minecraft:redstone_block
fill 440 278 582 442 278 584 minecraft:redstone_block
fill 444 278 574 446 278 576 minecraft:redstone_block
fill 424 279 558 428 280 559 minecraft:red_concrete
fill 424 279 560 428 279 565 minecraft:blue_concrete
fill 424 279 566 428 279 571 minecraft:red_concrete
fill 424 279 572 428 279 577 minecraft:blue_concrete
fill 424 279 578 428 279 583 minecraft:red_concrete
fill 424 279 584 428 279 589 minecraft:blue_concrete
fill 424 279 590 428 279 595 minecraft:red_concrete
fill 424 279 596 428 279 598 minecraft:blue_concrete
fill 429 279 558 434 279 559 minecraft:blue_concrete
fill 429 279 560 434 279 565 minecraft:red_concrete
fill 429 279 566 434 279 571 minecraft:blue_concrete
fill 429 279 572 434 279 577 minecraft:red_concrete
fill 429 279 578 434 279 583 minecraft:blue_concrete
fill 429 279 584 434 279 589 minecraft:red_concrete
fill 429 279 590 434 279 595 minecraft:blue_concrete
fill 429 279 596 434 279 598 minecraft:red_concrete
fill 435 279 558 440 279 559 minecraft:red_concrete
fill 435 279 560 440 279 565 minecraft:blue_concrete
fill 435 279 566 440 279 571 minecraft:red_concrete
fill 435 279 572 436 279 577 minecraft:blue_concrete
fill 435 279 578 439 279 583 minecraft:red_concrete
fill 435 279 584 439 279 589 minecraft:blue_concrete
fill 435 279 590 440 279 595 minecraft:red_concrete
fill 435 279 596 440 279 598 minecraft:blue_concrete
fill 437 279 572 440 279 572 minecraft:blue_concrete
fill 437 279 576 439 279 577 minecraft:blue_concrete
fill 440 279 573 440 279 576 minecraft:blue_concrete
fill 440 279 580 440 279 581 minecraft:red_concrete
fill 440 279 585 440 279 589 minecraft:blue_concrete
fill 441 279 558 446 279 559 minecraft:blue_concrete
fill 441 279 560 446 279 565 minecraft:red_concrete
fill 441 279 566 446 279 571 minecraft:blue_concrete
fill 441 279 572 443 279 576 minecraft:red_concrete
fill 441 279 580 446 279 581 minecraft:blue_concrete
fill 441 279 585 446 279 589 minecraft:red_concrete
fill 441 279 590 446 279 595 minecraft:blue_concrete
fill 441 279 596 446 279 598 minecraft:red_concrete
fill 443 279 577 446 279 577 minecraft:red_concrete
fill 443 279 578 446 279 579 minecraft:blue_concrete
fill 443 279 582 446 279 583 minecraft:blue_concrete
fill 443 279 584 446 279 584 minecraft:red_concrete
fill 444 279 572 446 279 573 minecraft:red_concrete
fill 447 279 558 452 279 559 minecraft:red_concrete
fill 447 279 560 452 279 565 minecraft:blue_concrete
fill 447 279 566 452 279 571 minecraft:red_concrete
fill 447 279 572 452 279 577 minecraft:blue_concrete
fill 447 279 578 452 279 583 minecraft:red_concrete
fill 447 279 584 452 279 589 minecraft:blue_concrete
fill 447 279 590 452 279 595 minecraft:red_concrete
fill 447 279 596 452 279 598 minecraft:blue_concrete
fill 453 279 558 458 279 559 minecraft:blue_concrete
fill 453 279 560 458 279 565 minecraft:red_concrete
fill 453 279 566 458 279 571 minecraft:blue_concrete
fill 453 279 572 458 279 577 minecraft:red_concrete
fill 453 279 578 458 279 583 minecraft:blue_concrete
fill 453 279 584 458 279 589 minecraft:red_concrete
fill 453 279 590 458 279 595 minecraft:blue_concrete
fill 453 279 596 458 279 598 minecraft:red_concrete
fill 459 279 558 464 279 559 minecraft:red_concrete
fill 459 279 560 464 279 565 minecraft:blue_concrete
fill 459 279 566 464 279 571 minecraft:red_concrete
fill 459 279 572 464 279 577 minecraft:blue_concrete
fill 459 279 578 464 279 583 minecraft:red_concrete
fill 459 279 584 464 279 589 minecraft:blue_concrete
fill 459 279 590 464 279 595 minecraft:red_concrete
fill 459 279 596 464 279 598 minecraft:blue_concrete
fill 424 280 560 464 280 560 minecraft:yellow_concrete
fill 424 280 561 428 280 565 minecraft:blue_concrete
fill 424 280 566 464 280 566 minecraft:yellow_concrete
fill 424 280 567 428 280 571 minecraft:red_concrete
fill 424 280 572 435 280 572 minecraft:yellow_concrete
fill 424 280 573 428 280 577 minecraft:blue_concrete
fill 424 280 578 438 280 578 minecraft:yellow_concrete
fill 424 280 579 428 280 583 minecraft:red_concrete
fill 424 280 584 438 280 584 minecraft:yellow_concrete
fill 424 280 585 428 280 589 minecraft:blue_concrete
fill 424 280 590 464 280 590 minecraft:yellow_concrete
fill 424 280 591 428 280 595 minecraft:red_concrete
fill 424 280 596 464 280 596 minecraft:yellow_concrete
fill 424 280 597 428 280 598 minecraft:blue_concrete
fill 429 280 558 429 280 559 minecraft:yellow_concrete
fill 429 280 561 429 280 565 minecraft:yellow_concrete
fill 429 280 567 429 280 571 minecraft:yellow_concrete
fill 429 280 573 429 280 577 minecraft:yellow_concrete
fill 429 280 579 429 280 583 minecraft:yellow_concrete
fill 429 280 585 429 280 589 minecraft:yellow_concrete
fill 429 280 591 429 280 595 minecraft:yellow_concrete
fill 429 280 597 429 280 598 minecraft:yellow_concrete
fill 430 280 558 434 280 559 minecraft:blue_concrete
fill 430 280 561 434 280 565 minecraft:red_concrete
fill 430 280 567 434 280 571 minecraft:blue_concrete
fill 430 280 573 434 280 577 minecraft:red_concrete
fill 430 280 579 434 280 583 minecraft:blue_concrete
fill 430 280 585 434 280 589 minecraft:red_concrete
fill 430 280 591 434 280 595 minecraft:blue_concrete
fill 430 280 597 434 280 598 minecraft:red_concrete
fill 435 280 558 435 280 559 minecraft:yellow_concrete
fill 435 280 561 435 280 565 minecraft:yellow_concrete
fill 435 280 567 435 280 571 minecraft:yellow_concrete
fill 435 280 573 435 280 577 minecraft:yellow_concrete
fill 435 280 579 435 280 583 minecraft:yellow_concrete
fill 435 280 585 435 280 589 minecraft:yellow_concrete
fill 435 280 591 435 280 595 minecraft:yellow_concrete
fill 435 280 597 435 280 598 minecraft:yellow_concrete
fill 436 280 558 440 280 559 minecraft:red_concrete
fill 436 280 561 440 280 565 minecraft:blue_concrete
fill 436 280 567 440 280 571 minecraft:red_concrete
fill 436 280 572 436 280 576 minecraft:sea_lantern
fill 436 280 577 438 280 577 minecraft:blue_concrete
fill 436 280 579 438 280 583 minecraft:red_concrete
fill 436 280 585 438 280 589 minecraft:blue_concrete
fill 436 280 591 440 280 595 minecraft:red_concrete
fill 436 280 597 440 280 598 minecraft:blue_concrete
fill 437 280 572 440 280 572 minecraft:sea_lantern
fill 437 280 573 439 280 575 minecraft:white_concrete
fill 437 280 576 443 280 576 minecraft:sea_lantern
fill 439 280 577 439 280 585 minecraft:sea_lantern
fill 439 280 586 440 280 589 minecraft:blue_concrete
fill 440 280 573 440 280 575 minecraft:sea_lantern
fill 440 280 580 443 280 581 minecraft:sea_lantern
fill 440 280 582 442 280 584 minecraft:white_concrete
fill 440 280 585 443 280 585 minecraft:sea_lantern
fill 441 280 558 441 280 559 minecraft:yellow_concrete
fill 441 280 561 441 280 565 minecraft:yellow_concrete
fill 441 280 567 441 280 575 minecraft:yellow_concrete
fill 441 280 586 441 280 589 minecraft:yellow_concrete
fill 441 280 591 441 280 595 minecraft:yellow_concrete
fill 441 280 597 441 280 598 minecraft:yellow_concrete
fill 442 280 558 446 280 559 minecraft:blue_concrete
fill 442 280 561 446 280 565 minecraft:red_concrete
fill 442 280 567 446 280 571 minecraft:blue_concrete
fill 442 280 572 464 280 572 minecraft:yellow_concrete
fill 442 280 573 442 280 575 minecraft:red_concrete
fill 442 280 586 446 280 589 minecraft:red_concrete
fill 442 280 591 446 280 595 minecraft:blue_concrete
fill 442 280 597 446 280 598 minecraft:red_concrete
fill 443 280 573 443 280 575 minecraft:sea_lantern
fill 443 280 577 443 280 579 minecraft:sea_lantern
fill 443 280 582 443 280 584 minecraft:sea_lantern
fill 444 280 573 447 280 573 minecraft:sea_lantern
fill 444 280 574 446 280 576 minecraft:white_concrete
fill 444 280 577 447 280 577 minecraft:sea_lantern
fill 444 280 578 464 280 578 minecraft:yellow_concrete
fill 444 280 579 446 280 583 minecraft:blue_concrete
fill 444 280 584 464 280 584 minecraft:yellow_concrete
fill 444 280 585 446 280 585 minecraft:red_concrete
fill 447 280 558 447 280 559 minecraft:yellow_concrete
fill 447 280 561 447 280 565 minecraft:yellow_concrete
fill 447 280 567 447 280 571 minecraft:yellow_concrete
fill 447 280 574 447 280 576 minecraft:sea_lantern
fill 447 280 579 447 280 583 minecraft:yellow_concrete
fill 447 280 585 447 280 589 minecraft:yellow_concrete
fill 447 280 591 447 280 595 minecraft:yellow_concrete
fill 447 280 597 447 280 598 minecraft:yellow_concrete
fill 448 280 558 452 280 559 minecraft:red_concrete
fill 448 280 561 452 280 565 minecraft:blue_concrete
fill 448 280 567 452 280 571 minecraft:red_concrete
fill 448 280 573 452 280 577 minecraft:blue_concrete
fill 448 280 579 452 280 583 minecraft:red_concrete
fill 448 280 585 452 280 589 minecraft:blue_concrete
fill 448 280 591 452 280 595 minecraft:red_concrete
fill 448 280 597 452 280 598 minecraft:blue_concrete
fill 453 280 558 453 280 559 minecraft:yellow_concrete
fill 453 280 561 453 280 565 minecraft:yellow_concrete
fill 453 280 567 453 280 571 minecraft:yellow_concrete
fill 453 280 573 453 280 577 minecraft:yellow_concrete
fill 453 280 579 453 280 583 minecraft:yellow_concrete
fill 453 280 585 453 280 589 minecraft:yellow_concrete
fill 453 280 591 453 280 595 minecraft:yellow_concrete
fill 453 280 597 453 280 598 minecraft:yellow_concrete
fill 454 280 558 458 280 559 minecraft:blue_concrete
fill 454 280 561 458 280 565 minecraft:red_concrete
fill 454 280 567 458 280 571 minecraft:blue_concrete
fill 454 280 573 458 280 577 minecraft:red_concrete
fill 454 280 579 458 280 583 minecraft:blue_concrete
fill 454 280 585 458 280 589 minecraft:red_concrete
fill 454 280 591 458 280 595 minecraft:blue_concrete
fill 454 280 597 458 280 598 minecraft:red_concrete
fill 459 280 558 459 280 559 minecraft:yellow_concrete
fill 459 280 561 459 280 565 minecraft:yellow_concrete
fill 459 280 567 459 280 571 minecraft:yellow_concrete
fill 459 280 573 459 280 577 minecraft:yellow_concrete
fill 459 280 579 459 280 583 minecraft:yellow_concrete
fill 459 280 585 459 280 589 minecraft:yellow_concrete
fill 459 280 591 459 280 595 minecraft:yellow_concrete
fill 459 280 597 459 280 598 minecraft:yellow_concrete
fill 460 280 558 464 280 559 minecraft:red_concrete
fill 460 280 561 464 280 565 minecraft:blue_concrete
fill 460 280 567 464 280 571 minecraft:red_concrete
fill 460 280 573 464 280 577 minecraft:blue_concrete
fill 460 280 579 464 280 583 minecraft:red_concrete
fill 460 280 585 464 280 589 minecraft:blue_concrete
fill 460 280 591 464 280 595 minecraft:red_concrete
fill 460 280 597 464 280 598 minecraft:blue_concrete
fill 423 284 562 423 289 562 minecraft:sea_lantern
fill 423 284 570 423 289 570 minecraft:sea_lantern
fill 423 284 578 423 289 578 minecraft:sea_lantern
fill 423 284 586 423 289 586 minecraft:sea_lantern
fill 423 284 594 423 289 594 minecraft:sea_lantern
fill 424 284 564 424 300 565 minecraft:white_concrete
fill 424 284 572 424 300 573 minecraft:white_concrete
fill 424 284 580 424 300 581 minecraft:white_concrete
fill 424 284 588 424 300 589 minecraft:white_concrete
fill 424 284 596 424 300 597 minecraft:white_concrete
fill 425 284 558 426 300 558 minecraft:white_concrete
setblock 426 284 560 minecraft:light[level=14]
setblock 426 284 568 minecraft:light[level=14]
setblock 426 284 576 minecraft:light[level=14]
setblock 426 284 584 minecraft:light[level=14]
setblock 426 284 592 minecraft:light[level=14]
fill 426 284 599 426 289 599 minecraft:sea_lantern
fill 430 284 557 430 289 557 minecraft:sea_lantern
fill 430 284 598 431 300 598 minecraft:white_concrete
fill 433 284 558 434 300 558 minecraft:white_concrete
setblock 434 284 560 minecraft:light[level=14]
setblock 434 284 568 minecraft:light[level=14]
setblock 434 284 576 minecraft:light[level=14]
setblock 434 284 584 minecraft:light[level=14]
setblock 434 284 592 minecraft:light[level=14]
fill 434 284 599 434 289 599 minecraft:sea_lantern
fill 438 284 557 438 289 557 minecraft:sea_lantern
fill 438 284 598 439 300 598 minecraft:white_concrete
fill 439 284 558 439 285 560 minecraft:iron_block
fill 441 284 558 442 300 558 minecraft:white_concrete
setblock 442 284 560 minecraft:light[level=14]
setblock 442 284 568 minecraft:light[level=14]
setblock 442 284 576 minecraft:light[level=14]
setblock 442 284 584 minecraft:light[level=14]
setblock 442 284 592 minecraft:light[level=14]
fill 442 284 599 442 289 599 minecraft:sea_lantern
fill 445 284 569 446 285 569 minecraft:red_concrete
fill 446 284 557 446 289 557 minecraft:sea_lantern
fill 446 284 598 447 300 598 minecraft:white_concrete
fill 449 284 558 450 300 558 minecraft:white_concrete
setblock 450 284 560 minecraft:light[level=14]
setblock 450 284 568 minecraft:light[level=14]
setblock 450 284 576 minecraft:light[level=14]
setblock 450 284 584 minecraft:light[level=14]
setblock 450 284 592 minecraft:light[level=14]
fill 450 284 599 450 289 599 minecraft:sea_lantern
fill 454 284 557 454 289 557 minecraft:sea_lantern
fill 454 284 598 455 300 598 minecraft:white_concrete
fill 457 284 558 458 300 558 minecraft:white_concrete
setblock 458 284 560 minecraft:light[level=14]
setblock 458 284 568 minecraft:light[level=14]
setblock 458 284 576 minecraft:light[level=14]
setblock 458 284 584 minecraft:light[level=14]
setblock 458 284 592 minecraft:light[level=14]
fill 458 284 599 458 289 599 minecraft:sea_lantern
fill 462 284 557 462 289 557 minecraft:sea_lantern
fill 462 284 598 463 300 598 minecraft:white_concrete
fill 464 284 559 464 300 560 minecraft:white_concrete
fill 464 284 567 464 300 568 minecraft:white_concrete
fill 464 284 575 464 300 576 minecraft:white_concrete
fill 464 284 583 464 300 584 minecraft:white_concrete
fill 464 284 591 464 300 592 minecraft:white_concrete
fill 465 284 562 465 289 562 minecraft:sea_lantern
fill 465 284 570 465 289 570 minecraft:sea_lantern
fill 465 284 578 465 289 578 minecraft:sea_lantern
fill 465 284 586 465 289 586 minecraft:sea_lantern
fill 465 284 594 465 289 594 minecraft:sea_lantern
fill 459 285 571 461 286 571 minecraft:lime_concrete
fill 460 285 572 461 286 572 minecraft:lime_concrete
fill 437 288 570 437 289 571 minecraft:orange_concrete
fill 423 290 562 423 297 562 minecraft:red_concrete
fill 423 290 570 423 297 570 minecraft:red_concrete
fill 423 290 578 423 297 578 minecraft:red_concrete
fill 423 290 586 423 297 586 minecraft:red_concrete
fill 423 290 594 423 297 594 minecraft:red_concrete
fill 426 290 599 426 297 599 minecraft:red_concrete
fill 430 290 557 430 297 557 minecraft:red_concrete
fill 434 290 599 434 297 599 minecraft:red_concrete
fill 438 290 557 438 297 557 minecraft:red_concrete
fill 442 290 599 442 297 599 minecraft:red_concrete
fill 446 290 557 446 297 557 minecraft:red_concrete
fill 450 290 599 450 297 599 minecraft:red_concrete
fill 454 290 557 454 297 557 minecraft:red_concrete
fill 458 290 599 458 297 599 minecraft:red_concrete
fill 462 290 557 462 297 557 minecraft:red_concrete
fill 465 290 562 465 297 562 minecraft:red_concrete
fill 465 290 570 465 297 570 minecraft:red_concrete
fill 465 290 578 465 297 578 minecraft:red_concrete
fill 465 290 586 465 297 586 minecraft:red_concrete
fill 465 290 594 465 297 594 minecraft:red_concrete
setblock 426 292 560 minecraft:light[level=14]
setblock 426 292 568 minecraft:light[level=14]
setblock 426 292 576 minecraft:light[level=14]
setblock 426 292 584 minecraft:light[level=14]
setblock 426 292 592 minecraft:light[level=14]
setblock 434 292 560 minecraft:light[level=14]
setblock 434 292 568 minecraft:light[level=14]
setblock 434 292 576 minecraft:light[level=14]
setblock 434 292 584 minecraft:light[level=14]
setblock 434 292 592 minecraft:light[level=14]
setblock 442 292 560 minecraft:light[level=14]
setblock 442 292 568 minecraft:light[level=14]
setblock 442 292 576 minecraft:light[level=14]
setblock 442 292 584 minecraft:light[level=14]
setblock 442 292 592 minecraft:light[level=14]
setblock 450 292 560 minecraft:light[level=14]
setblock 450 292 568 minecraft:light[level=14]
setblock 450 292 576 minecraft:light[level=14]
setblock 450 292 584 minecraft:light[level=14]
setblock 450 292 592 minecraft:light[level=14]
setblock 458 292 560 minecraft:light[level=14]
setblock 458 292 568 minecraft:light[level=14]
setblock 458 292 576 minecraft:light[level=14]
setblock 458 292 584 minecraft:light[level=14]
setblock 458 292 592 minecraft:light[level=14]
fill 426 293 574 427 294 582 minecraft:white_concrete
fill 427 293 571 428 294 573 minecraft:white_concrete
fill 427 293 583 428 294 585 minecraft:white_concrete
fill 428 293 569 429 294 570 minecraft:white_concrete
fill 428 293 586 429 294 587 minecraft:white_concrete
fill 429 293 568 430 294 568 minecraft:white_concrete
fill 429 293 571 429 294 571 minecraft:white_concrete
fill 429 293 585 429 294 585 minecraft:white_concrete
fill 429 293 588 430 294 588 minecraft:white_concrete
fill 430 293 566 431 294 567 minecraft:white_concrete
fill 430 293 569 430 294 569 minecraft:white_concrete
fill 430 293 587 430 294 587 minecraft:white_concrete
fill 430 293 589 431 294 590 minecraft:white_concrete
fill 431 293 565 433 294 565 minecraft:white_concrete
fill 431 293 591 433 294 591 minecraft:white_concrete
fill 432 293 564 435 294 564 minecraft:white_concrete
fill 432 293 566 432 294 566 minecraft:white_concrete
fill 432 293 590 432 294 590 minecraft:white_concrete
fill 432 293 592 435 294 592 minecraft:white_concrete
fill 434 293 563 437 294 563 minecraft:white_concrete
fill 434 293 593 437 294 593 minecraft:white_concrete
fill 435 293 562 439 294 562 minecraft:white_concrete
fill 435 293 594 439 294 594 minecraft:white_concrete
fill 437 293 561 451 294 561 minecraft:white_concrete
fill 437 293 595 451 294 595 minecraft:white_concrete
fill 440 293 560 448 294 560 minecraft:white_concrete
fill 440 293 596 448 294 596 minecraft:white_concrete
fill 449 293 562 453 294 562 minecraft:white_concrete
fill 449 293 594 453 294 594 minecraft:white_concrete
fill 451 293 563 454 294 563 minecraft:white_concrete
fill 451 293 593 454 294 593 minecraft:white_concrete
fill 453 293 564 456 294 564 minecraft:white_concrete
fill 453 293 592 456 294 592 minecraft:white_concrete
fill 455 293 565 457 294 565 minecraft:white_concrete
fill 455 293 591 457 294 591 minecraft:white_concrete
fill 456 293 566 458 294 566 minecraft:white_concrete
fill 456 293 590 458 294 590 minecraft:white_concrete
fill 457 293 567 458 294 567 minecraft:white_concrete
fill 457 293 589 458 294 589 minecraft:white_concrete
fill 458 293 568 459 294 569 minecraft:white_concrete
fill 458 293 587 459 294 588 minecraft:white_concrete
fill 459 293 570 460 294 571 minecraft:white_concrete
fill 459 293 585 460 294 586 minecraft:white_concrete
fill 460 293 569 460 294 569 minecraft:white_concrete
fill 460 293 572 461 294 573 minecraft:white_concrete
fill 460 293 583 461 294 584 minecraft:white_concrete
fill 460 293 587 460 294 587 minecraft:white_concrete
fill 461 293 571 461 294 571 minecraft:white_concrete
fill 461 293 574 462 294 582 minecraft:white_concrete
fill 461 293 585 461 294 585 minecraft:white_concrete
fill 424 294 558 424 295 563 minecraft:white_concrete
fill 424 294 566 425 294 571 minecraft:white_concrete
fill 424 294 574 425 294 579 minecraft:white_concrete
fill 424 294 582 425 294 587 minecraft:white_concrete
fill 424 294 590 425 294 595 minecraft:white_concrete
fill 424 294 598 429 295 598 minecraft:white_concrete
fill 425 294 559 425 294 565 minecraft:white_concrete
fill 425 294 572 425 294 573 minecraft:white_concrete
fill 425 294 580 425 294 581 minecraft:white_concrete
fill 425 294 588 425 294 589 minecraft:white_concrete
fill 425 294 596 425 294 597 minecraft:white_concrete
fill 426 294 559 463 294 559 minecraft:white_concrete
fill 426 294 597 464 294 597 minecraft:white_concrete
fill 427 294 558 432 295 558 minecraft:white_concrete
fill 432 294 598 437 295 598 minecraft:white_concrete
fill 435 294 558 440 295 558 minecraft:white_concrete
fill 440 294 598 445 295 598 minecraft:white_concrete
fill 443 294 558 448 295 558 minecraft:white_concrete
fill 448 294 598 453 295 598 minecraft:white_concrete
fill 451 294 558 456 295 558 minecraft:white_concrete
fill 456 294 598 461 295 598 minecraft:white_concrete
fill 459 294 558 464 295 558 minecraft:white_concrete
fill 463 294 560 463 294 596 minecraft:white_concrete
fill 464 294 561 464 295 566 minecraft:white_concrete
fill 464 294 569 464 295 574 minecraft:white_concrete
fill 464 294 577 464 295 582 minecraft:white_concrete
fill 464 294 585 464 295 590 minecraft:white_concrete
fill 464 294 593 464 295 596 minecraft:white_concrete
fill 464 294 598 464 295 598 minecraft:white_concrete
fill 424 295 566 424 295 571 minecraft:white_concrete
fill 424 295 574 424 295 579 minecraft:white_concrete
fill 424 295 582 424 295 587 minecraft:white_concrete
fill 424 295 590 424 295 595 minecraft:white_concrete
fill 438 295 595 439 295 595 minecraft:sea_lantern
fill 440 295 596 443 295 596 minecraft:sea_lantern
setblock 464 295 597 minecraft:white_concrete
fill 439 296 585 441 297 585 minecraft:blue_concrete
fill 440 296 584 440 297 584 minecraft:blue_concrete
fill 440 296 586 440 297 586 minecraft:blue_concrete
fill 423 298 562 423 300 562 minecraft:sea_lantern
fill 423 298 570 423 300 570 minecraft:sea_lantern
fill 423 298 578 423 300 578 minecraft:sea_lantern
fill 423 298 586 423 300 586 minecraft:sea_lantern
fill 423 298 594 423 300 594 minecraft:sea_lantern
fill 426 298 599 426 300 599 minecraft:sea_lantern
fill 430 298 557 430 300 557 minecraft:sea_lantern
fill 434 298 599 434 300 599 minecraft:sea_lantern
fill 438 298 557 438 300 557 minecraft:sea_lantern
fill 442 298 599 442 300 599 minecraft:sea_lantern
fill 446 298 557 446 300 557 minecraft:sea_lantern
fill 450 298 599 450 300 599 minecraft:sea_lantern
fill 454 298 557 454 300 557 minecraft:sea_lantern
fill 458 298 599 458 300 599 minecraft:sea_lantern
fill 462 298 557 462 300 557 minecraft:sea_lantern
fill 465 298 562 465 300 562 minecraft:sea_lantern
fill 465 298 570 465 300 570 minecraft:sea_lantern
fill 465 298 578 465 300 578 minecraft:sea_lantern
fill 465 298 586 465 300 586 minecraft:sea_lantern
fill 465 298 594 465 300 594 minecraft:sea_lantern
fill 453 299 570 455 300 570 minecraft:yellow_concrete
fill 454 299 569 454 300 569 minecraft:yellow_concrete
fill 454 299 571 454 300 571 minecraft:yellow_concrete
setblock 426 300 560 minecraft:light[level=14]
setblock 426 300 568 minecraft:light[level=14]
setblock 426 300 576 minecraft:light[level=14]
setblock 426 300 584 minecraft:light[level=14]
setblock 426 300 592 minecraft:light[level=14]
setblock 434 300 560 minecraft:light[level=14]
setblock 434 300 568 minecraft:light[level=14]
setblock 434 300 576 minecraft:light[level=14]
setblock 434 300 584 minecraft:light[level=14]
setblock 434 300 592 minecraft:light[level=14]
setblock 442 300 560 minecraft:light[level=14]
setblock 442 300 568 minecraft:light[level=14]
setblock 442 300 576 minecraft:light[level=14]
setblock 442 300 584 minecraft:light[level=14]
setblock 442 300 592 minecraft:light[level=14]
setblock 450 300 560 minecraft:light[level=14]
setblock 450 300 568 minecraft:light[level=14]
setblock 450 300 576 minecraft:light[level=14]
setblock 450 300 584 minecraft:light[level=14]
setblock 450 300 592 minecraft:light[level=14]
setblock 458 300 560 minecraft:light[level=14]
setblock 458 300 568 minecraft:light[level=14]
setblock 458 300 576 minecraft:light[level=14]
setblock 458 300 584 minecraft:light[level=14]
setblock 458 300 592 minecraft:light[level=14]
fill 423 301 562 423 307 562 minecraft:red_concrete
fill 423 301 570 423 307 570 minecraft:red_concrete
fill 423 301 578 423 307 578 minecraft:red_concrete
fill 423 301 586 423 307 586 minecraft:red_concrete
fill 423 301 594 423 307 594 minecraft:red_concrete
fill 426 301 599 426 307 599 minecraft:red_concrete
fill 430 301 557 430 307 557 minecraft:red_concrete
fill 434 301 599 434 307 599 minecraft:red_concrete
fill 438 301 557 438 307 557 minecraft:red_concrete
fill 442 301 599 442 307 599 minecraft:red_concrete
fill 446 301 557 446 307 557 minecraft:red_concrete
fill 450 301 599 450 307 599 minecraft:red_concrete
fill 454 301 557 454 307 557 minecraft:red_concrete
fill 458 301 599 458 307 599 minecraft:red_concrete
fill 462 301 557 462 307 557 minecraft:red_concrete
fill 465 301 562 465 307 562 minecraft:red_concrete
fill 465 301 570 465 307 570 minecraft:red_concrete
fill 465 301 578 465 307 578 minecraft:red_concrete
fill 465 301 586 465 307 586 minecraft:red_concrete
fill 465 301 594 465 307 594 minecraft:red_concrete
