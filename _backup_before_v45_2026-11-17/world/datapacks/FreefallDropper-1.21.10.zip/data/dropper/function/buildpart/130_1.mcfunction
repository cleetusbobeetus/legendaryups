setblock 473 211 537 minecraft:light[level=14]
setblock 473 211 545 minecraft:light[level=14]
setblock 481 211 513 minecraft:light[level=14]
setblock 481 211 521 minecraft:light[level=14]
setblock 481 211 529 minecraft:light[level=14]
setblock 481 211 537 minecraft:light[level=14]
setblock 481 211 545 minecraft:light[level=14]
fill 483 211 531 484 214 531 minecraft:white_concrete
setblock 489 211 513 minecraft:light[level=14]
setblock 489 211 521 minecraft:light[level=14]
setblock 489 211 529 minecraft:light[level=14]
setblock 489 211 537 minecraft:light[level=14]
setblock 489 211 545 minecraft:light[level=14]
setblock 497 211 513 minecraft:light[level=14]
setblock 497 211 521 minecraft:light[level=14]
setblock 497 211 529 minecraft:light[level=14]
setblock 497 211 537 minecraft:light[level=14]
setblock 497 211 545 minecraft:light[level=14]
fill 500 211 531 510 212 531 minecraft:white_concrete
setblock 505 211 513 minecraft:light[level=14]
setblock 505 211 521 minecraft:light[level=14]
setblock 505 211 529 minecraft:light[level=14]
setblock 505 211 537 minecraft:light[level=14]
setblock 505 211 545 minecraft:light[level=14]
fill 470 212 516 470 218 516 minecraft:light_blue_concrete
fill 470 212 517 470 212 518 minecraft:pearlescent_froglight
fill 470 212 519 470 219 519 minecraft:light_blue_concrete
fill 470 212 528 470 216 528 minecraft:light_blue_concrete
fill 470 212 529 470 212 530 minecraft:pearlescent_froglight
fill 470 212 531 470 218 531 minecraft:light_blue_concrete
fill 470 212 540 470 214 540 minecraft:light_blue_concrete
fill 470 212 541 470 212 542 minecraft:pearlescent_froglight
fill 470 212 543 470 218 543 minecraft:light_blue_concrete
fill 470 212 552 470 215 552 minecraft:light_blue_concrete
setblock 471 212 531 minecraft:white_concrete
fill 471 212 552 472 212 552 minecraft:pearlescent_froglight
fill 473 212 552 473 218 552 minecraft:light_blue_concrete
fill 477 212 510 477 214 510 minecraft:light_blue_concrete
fill 478 212 510 479 212 510 minecraft:pearlescent_froglight
fill 480 212 510 480 218 510 minecraft:light_blue_concrete
fill 482 212 530 484 215 530 minecraft:white_concrete
fill 482 212 552 482 218 552 minecraft:light_blue_concrete
fill 483 212 552 484 212 552 minecraft:pearlescent_froglight
fill 485 212 552 485 218 552 minecraft:light_blue_concrete
fill 489 212 510 489 218 510 minecraft:light_blue_concrete
fill 490 212 510 491 212 510 minecraft:pearlescent_froglight
fill 492 212 510 492 218 510 minecraft:light_blue_concrete
fill 494 212 552 494 218 552 minecraft:light_blue_concrete
fill 495 212 552 496 212 552 minecraft:pearlescent_froglight
fill 497 212 552 497 218 552 minecraft:light_blue_concrete
fill 499 212 530 500 216 530 minecraft:white_concrete
fill 501 212 510 501 219 510 minecraft:light_blue_concrete
fill 502 212 510 503 212 510 minecraft:pearlescent_froglight
fill 504 212 510 504 218 510 minecraft:light_blue_concrete
fill 505 212 513 505 212 516 minecraft:smooth_quartz
fill 506 212 512 507 212 512 minecraft:smooth_quartz
setblock 506 212 516 minecraft:smooth_quartz
fill 506 212 552 506 218 552 minecraft:light_blue_concrete
fill 507 212 552 508 212 552 minecraft:pearlescent_froglight
fill 508 212 513 509 212 513 minecraft:smooth_quartz
setblock 508 212 516 minecraft:smooth_quartz
fill 509 212 514 509 212 515 minecraft:smooth_quartz
fill 509 212 552 509 218 552 minecraft:light_blue_concrete
fill 512 212 511 512 218 511 minecraft:light_blue_concrete
fill 512 212 512 512 212 513 minecraft:pearlescent_froglight
fill 512 212 514 512 214 514 minecraft:light_blue_concrete
fill 512 212 523 512 220 523 minecraft:light_blue_concrete
fill 512 212 524 512 212 525 minecraft:pearlescent_froglight
fill 512 212 526 512 218 526 minecraft:light_blue_concrete
fill 512 212 535 512 218 535 minecraft:light_blue_concrete
fill 512 212 536 512 212 537 minecraft:pearlescent_froglight
fill 512 212 538 512 218 538 minecraft:light_blue_concrete
fill 512 212 547 512 218 547 minecraft:light_blue_concrete
fill 512 212 548 512 212 549 minecraft:pearlescent_froglight
fill 512 212 550 512 218 550 minecraft:light_blue_concrete
fill 470 213 517 470 218 518 minecraft:light_blue_concrete
fill 470 213 529 470 216 530 minecraft:light_blue_concrete
fill 470 213 541 470 218 542 minecraft:light_blue_concrete
fill 471 213 552 472 218 552 minecraft:light_blue_concrete
fill 478 213 510 479 216 510 minecraft:light_blue_concrete
fill 479 213 530 481 214 530 minecraft:white_concrete
setblock 481 213 531 minecraft:white_concrete
fill 483 213 552 484 214 552 minecraft:light_blue_concrete
fill 490 213 510 491 218 510 minecraft:light_blue_concrete
fill 495 213 552 496 215 552 minecraft:light_blue_concrete
fill 500 213 531 501 213 531 minecraft:white_concrete
fill 501 213 530 503 214 530 minecraft:white_concrete
fill 502 213 510 503 215 510 minecraft:light_blue_concrete
fill 507 213 552 508 218 552 minecraft:light_blue_concrete
fill 512 213 512 512 218 513 minecraft:light_blue_concrete
fill 512 213 524 512 216 525 minecraft:light_blue_concrete
fill 512 213 536 512 214 537 minecraft:light_blue_concrete
fill 512 213 548 512 218 549 minecraft:light_blue_concrete
fill 475 214 529 480 214 529 minecraft:white_concrete
fill 477 214 530 478 214 530 minecraft:white_concrete
fill 482 214 529 482 217 529 minecraft:white_concrete
fill 500 214 529 500 217 529 minecraft:white_concrete
fill 502 214 529 507 214 529 minecraft:white_concrete
fill 504 214 530 505 214 530 minecraft:white_concrete
setblock 470 215 511 minecraft:white_concrete
fill 470 215 512 470 218 512 minecraft:light_blue_concrete
setblock 470 215 513 minecraft:white_concrete
fill 470 215 514 470 218 514 minecraft:light_blue_concrete
setblock 470 215 536 minecraft:white_concrete
fill 470 215 537 470 218 537 minecraft:light_blue_concrete
setblock 470 215 540 minecraft:white_concrete
setblock 470 215 551 minecraft:white_concrete
fill 472 215 528 475 215 528 minecraft:white_concrete
fill 473 215 529 478 215 529 minecraft:white_concrete
setblock 477 215 510 minecraft:white_concrete
fill 480 215 528 480 216 529 minecraft:white_concrete
setblock 481 215 510 minecraft:white_concrete
fill 481 215 529 481 215 530 minecraft:white_concrete
fill 482 215 510 484 215 510 minecraft:light_blue_concrete
fill 483 215 529 483 216 529 minecraft:white_concrete
setblock 483 215 552 minecraft:white_concrete
setblock 484 215 531 minecraft:white_concrete
fill 484 215 552 484 218 552 minecraft:light_blue_concrete
setblock 485 215 510 minecraft:white_concrete
setblock 486 215 552 minecraft:white_concrete
fill 487 215 552 488 218 552 minecraft:light_blue_concrete
fill 497 215 531 498 215 531 minecraft:white_concrete
fill 498 215 552 500 218 552 minecraft:light_blue_concrete
fill 499 215 529 499 216 529 minecraft:white_concrete
fill 501 215 529 501 215 530 minecraft:white_concrete
setblock 501 215 552 minecraft:white_concrete
fill 502 215 528 502 216 529 minecraft:white_concrete
fill 502 215 552 502 218 552 minecraft:light_blue_concrete
fill 504 215 529 509 215 529 minecraft:white_concrete
setblock 504 215 552 minecraft:white_concrete
fill 505 215 510 506 218 510 minecraft:light_blue_concrete
fill 505 215 552 505 218 552 minecraft:light_blue_concrete
setblock 507 215 510 minecraft:white_concrete
fill 507 215 528 510 215 528 minecraft:white_concrete
fill 508 215 510 508 219 510 minecraft:light_blue_concrete
setblock 511 215 552 minecraft:white_concrete
setblock 512 215 514 minecraft:white_concrete
fill 512 215 536 512 218 536 minecraft:light_blue_concrete
setblock 512 215 537 minecraft:white_concrete
fill 512 215 543 512 218 543 minecraft:light_blue_concrete
setblock 512 215 544 minecraft:white_concrete
fill 512 215 545 512 218 546 minecraft:light_blue_concrete
setblock 512 215 551 minecraft:white_concrete
fill 470 216 511 470 218 511 minecraft:light_blue_concrete
fill 470 216 513 470 218 513 minecraft:light_blue_concrete
setblock 470 216 520 minecraft:white_concrete
fill 470 216 536 470 218 536 minecraft:light_blue_concrete
fill 470 216 538 470 217 538 minecraft:white_concrete
fill 470 216 540 470 218 540 minecraft:light_blue_concrete
fill 470 216 544 470 218 545 minecraft:light_blue_concrete
setblock 470 216 546 minecraft:white_concrete
fill 470 216 547 470 218 547 minecraft:light_blue_concrete
fill 470 216 551 470 218 551 minecraft:light_blue_concrete
setblock 470 216 552 minecraft:white_concrete
fill 471 216 528 474 216 528 minecraft:white_concrete
fill 472 216 529 474 216 529 minecraft:white_concrete
fill 477 216 510 477 218 510 minecraft:light_blue_concrete
fill 478 216 528 479 217 528 minecraft:white_concrete
setblock 479 216 529 minecraft:white_concrete
fill 479 216 552 479 218 552 minecraft:light_blue_concrete
setblock 480 216 552 minecraft:white_concrete
fill 481 216 510 482 216 510 minecraft:light_blue_concrete
fill 481 216 528 481 217 529 minecraft:white_concrete
setblock 481 216 552 minecraft:light_blue_concrete
fill 482 216 528 482 217 528 minecraft:white_concrete
fill 482 216 530 483 216 530 minecraft:white_concrete
fill 483 216 510 484 216 510 minecraft:white_concrete
fill 483 216 552 483 218 552 minecraft:light_blue_concrete
fill 485 216 510 485 218 510 minecraft:light_blue_concrete
fill 486 216 552 486 219 552 minecraft:light_blue_concrete
setblock 495 216 552 minecraft:white_concrete
fill 496 216 552 496 218 552 minecraft:light_blue_concrete
fill 500 216 528 501 217 528 minecraft:white_concrete
fill 501 216 529 501 217 529 minecraft:white_concrete
fill 501 216 549 507 217 549 minecraft:gold_block
fill 501 216 552 501 218 552 minecraft:light_blue_concrete
setblock 502 216 510 minecraft:white_concrete
fill 503 216 510 503 219 510 minecraft:light_blue_concrete
fill 503 216 528 503 216 529 minecraft:white_concrete
fill 504 216 528 504 217 528 minecraft:white_concrete
fill 504 216 552 504 218 552 minecraft:light_blue_concrete
setblock 507 216 510 minecraft:light_blue_concrete
fill 508 216 528 510 216 529 minecraft:white_concrete
setblock 511 216 528 minecraft:white_concrete
fill 511 216 552 511 218 552 minecraft:light_blue_concrete
fill 512 216 514 512 218 514 minecraft:light_blue_concrete
setblock 512 216 517 minecraft:white_concrete
fill 512 216 518 512 218 519 minecraft:light_blue_concrete
setblock 512 216 520 minecraft:white_concrete
fill 512 216 521 512 218 522 minecraft:light_blue_concrete
fill 512 216 537 512 219 537 minecraft:light_blue_concrete
setblock 512 216 542 minecraft:white_concrete
fill 512 216 544 512 218 544 minecraft:light_blue_concrete
setblock 512 216 551 minecraft:light_blue_concrete
fill 470 217 520 470 218 520 minecraft:light_blue_concrete
setblock 470 217 524 minecraft:white_concrete
fill 470 217 525 470 218 525 minecraft:light_blue_concrete
fill 470 217 528 470 217 529 minecraft:white_concrete
fill 470 217 530 470 218 530 minecraft:light_blue_concrete
fill 470 217 546 470 218 546 minecraft:light_blue_concrete
fill 470 217 552 470 218 552 minecraft:light_blue_concrete
fill 476 217 527 478 218 527 minecraft:white_concrete
setblock 477 217 528 minecraft:white_concrete
setblock 478 217 510 minecraft:white_concrete
fill 479 217 510 479 219 510 minecraft:light_blue_concrete
fill 480 217 527 480 218 528 minecraft:white_concrete
fill 480 217 552 480 218 552 minecraft:light_blue_concrete
fill 481 217 510 482 217 510 minecraft:white_concrete
setblock 481 217 552 minecraft:white_concrete
fill 483 217 510 484 218 510 minecraft:light_blue_concrete
fill 489 217 552 490 218 552 minecraft:light_blue_concrete
setblock 491 217 552 minecraft:white_concrete
fill 492 217 552 492 218 552 minecraft:light_blue_concrete
setblock 493 217 510 minecraft:white_concrete
fill 494 217 510 496 218 510 minecraft:light_blue_concrete
fill 495 217 552 495 218 552 minecraft:light_blue_concrete
fill 502 217 510 502 218 510 minecraft:light_blue_concrete
fill 502 217 527 502 218 528 minecraft:white_concrete
fill 503 217 528 503 218 528 minecraft:white_concrete
fill 504 217 527 506 218 527 minecraft:white_concrete
setblock 505 217 528 minecraft:white_concrete
setblock 507 217 510 minecraft:white_concrete
fill 512 217 517 512 218 517 minecraft:light_blue_concrete
fill 512 217 520 512 219 520 minecraft:light_blue_concrete
setblock 512 217 524 minecraft:white_concrete
fill 512 217 525 512 218 525 minecraft:light_blue_concrete
fill 512 217 528 512 218 528 minecraft:light_blue_concrete
setblock 512 217 529 minecraft:white_concrete
fill 512 217 530 512 218 530 minecraft:light_blue_concrete
fill 512 217 532 512 218 532 minecraft:light_blue_concrete
setblock 512 217 533 minecraft:white_concrete
fill 512 217 542 512 218 542 minecraft:light_blue_concrete
setblock 512 217 551 minecraft:white_concrete
setblock 470 218 524 minecraft:light_blue_concrete
fill 470 218 528 470 218 529 minecraft:light_blue_concrete
setblock 470 218 538 minecraft:light_blue_concrete
fill 474 218 526 475 219 527 minecraft:white_concrete
setblock 476 218 526 minecraft:white_concrete
setblock 478 218 510 minecraft:light_blue_concrete
fill 479 218 527 479 218 528 minecraft:white_concrete
fill 481 218 510 482 218 510 minecraft:light_blue_concrete
setblock 481 218 528 minecraft:white_concrete
setblock 481 218 552 minecraft:light_blue_concrete
setblock 491 218 552 minecraft:light_blue_concrete
setblock 493 218 510 minecraft:light_blue_concrete
setblock 501 218 528 minecraft:white_concrete
fill 503 218 527 503 219 527 minecraft:white_concrete
fill 506 218 526 508 218 526 minecraft:white_concrete
setblock 507 218 510 minecraft:light_blue_concrete
fill 507 218 527 508 219 527 minecraft:white_concrete
setblock 512 218 524 minecraft:light_blue_concrete
setblock 512 218 529 minecraft:light_blue_concrete
setblock 512 218 533 minecraft:light_blue_concrete
setblock 512 218 551 minecraft:light_blue_concrete
fill 470 219 510 470 220 510 minecraft:light_blue_concrete
fill 470 219 511 470 219 514 minecraft:white_concrete
fill 470 219 516 470 225 518 minecraft:white_concrete
fill 470 219 520 470 219 531 minecraft:white_concrete
setblock 470 219 532 minecraft:light_blue_concrete
fill 470 219 533 470 219 540 minecraft:white_concrete
setblock 470 219 541 minecraft:light_blue_concrete
fill 470 219 542 470 225 543 minecraft:white_concrete
setblock 470 219 544 minecraft:light_blue_concrete
fill 470 219 545 470 307 547 minecraft:white_concrete
fill 470 219 549 470 220 552 minecraft:white_concrete
fill 471 219 510 473 219 510 minecraft:white_concrete
fill 471 219 552 485 219 552 minecraft:white_concrete
fill 472 219 525 473 220 526 minecraft:white_concrete
setblock 473 219 513 minecraft:light[level=14]
setblock 473 219 521 minecraft:light[level=14]
setblock 473 219 529 minecraft:light[level=14]
setblock 473 219 537 minecraft:light[level=14]
setblock 473 219 545 minecraft:light[level=14]
setblock 474 219 510 minecraft:light_blue_concrete
fill 475 219 510 478 219 510 minecraft:white_concrete
fill 477 219 526 479 219 526 minecraft:white_concrete
fill 478 219 527 479 219 527 minecraft:white_concrete
fill 480 219 510 493 219 510 minecraft:white_concrete
setblock 481 219 513 minecraft:light[level=14]
setblock 481 219 521 minecraft:light[level=14]
setblock 481 219 529 minecraft:light[level=14]
setblock 481 219 537 minecraft:light[level=14]
setblock 481 219 545 minecraft:light[level=14]
fill 487 219 552 489 219 552 minecraft:white_concrete
setblock 489 219 513 minecraft:light[level=14]
setblock 489 219 521 minecraft:light[level=14]
setblock 489 219 529 minecraft:light[level=14]
setblock 489 219 537 minecraft:light[level=14]
setblock 489 219 545 minecraft:light[level=14]
setblock 490 219 552 minecraft:light_blue_concrete
fill 491 219 552 507 219 552 minecraft:white_concrete
setblock 494 219 510 minecraft:light_blue_concrete
fill 495 219 510 500 307 510 minecraft:white_concrete
setblock 497 219 513 minecraft:light[level=14]
setblock 497 219 521 minecraft:light[level=14]
setblock 497 219 529 minecraft:light[level=14]
setblock 497 219 537 minecraft:light[level=14]
setblock 497 219 545 minecraft:light[level=14]
fill 502 219 510 502 225 510 minecraft:white_concrete
fill 503 219 526 505 219 526 minecraft:white_concrete
fill 504 219 510 507 219 510 minecraft:white_concrete
setblock 504 219 527 minecraft:white_concrete
setblock 505 219 513 minecraft:light[level=14]
setblock 505 219 521 minecraft:light[level=14]
setblock 505 219 529 minecraft:light[level=14]
setblock 505 219 537 minecraft:light[level=14]
setblock 505 219 545 minecraft:light[level=14]
fill 507 219 526 510 219 526 minecraft:white_concrete
setblock 508 219 552 minecraft:light_blue_concrete
fill 509 219 510 512 220 510 minecraft:white_concrete
fill 509 219 525 510 220 525 minecraft:white_concrete
fill 509 219 552 512 225 552 minecraft:white_concrete
fill 512 219 511 512 220 512 minecraft:white_concrete
setblock 512 219 513 minecraft:light_blue_concrete
fill 512 219 514 512 220 519 minecraft:white_concrete
fill 512 219 521 512 307 522 minecraft:white_concrete
fill 512 219 524 512 219 530 minecraft:white_concrete
fill 512 219 532 512 220 536 minecraft:white_concrete
fill 512 219 538 512 225 539 minecraft:white_concrete
fill 512 219 541 512 219 551 minecraft:white_concrete
fill 470 220 511 470 307 511 minecraft:white_concrete
fill 470 220 512 470 220 513 minecraft:light_blue_concrete
fill 470 220 514 470 307 515 minecraft:white_concrete
fill 470 220 519 470 225 522 minecraft:white_concrete
setblock 470 220 523 minecraft:light_blue_concrete
fill 470 220 524 470 220 536 minecraft:white_concrete
setblock 470 220 537 minecraft:light_blue_concrete
fill 470 220 538 470 220 539 minecraft:white_concrete
setblock 470 220 540 minecraft:light_blue_concrete
fill 470 220 541 470 225 541 minecraft:white_concrete
fill 470 220 544 470 307 544 minecraft:white_concrete
fill 470 220 548 470 307 548 minecraft:white_concrete
setblock 471 220 510 minecraft:light_blue_concrete
setblock 471 220 525 minecraft:white_concrete
fill 471 220 552 475 225 552 minecraft:white_concrete
fill 472 220 510 477 220 510 minecraft:white_concrete
fill 472 220 520 472 225 522 minecraft:quartz_block
fill 472 220 532 472 225 534 minecraft:quartz_block
fill 472 220 544 472 225 546 minecraft:quartz_block
fill 476 220 525 477 220 526 minecraft:white_concrete
setblock 476 220 552 minecraft:light_blue_concrete
fill 477 220 552 482 220 552 minecraft:white_concrete
fill 478 220 510 478 221 510 minecraft:light_blue_concrete
setblock 478 220 526 minecraft:white_concrete
fill 478 220 550 480 225 550 minecraft:quartz_block
fill 479 220 510 488 220 510 minecraft:white_concrete
fill 482 220 512 484 225 512 minecraft:quartz_block
setblock 483 220 552 minecraft:light_blue_concrete
fill 484 220 552 488 220 552 minecraft:white_concrete
setblock 489 220 510 minecraft:light_blue_concrete
setblock 489 220 552 minecraft:light_blue_concrete
fill 490 220 510 494 225 510 minecraft:white_concrete
fill 490 220 550 492 225 550 minecraft:quartz_block
fill 490 220 552 492 220 552 minecraft:white_concrete
setblock 493 220 552 minecraft:light_blue_concrete
fill 494 220 512 496 225 512 minecraft:quartz_block
fill 494 220 552 496 225 552 minecraft:white_concrete
setblock 497 220 552 minecraft:light_blue_concrete
fill 498 220 552 498 307 552 minecraft:white_concrete
fill 499 220 552 499 221 552 minecraft:light_blue_concrete
fill 500 220 552 508 225 552 minecraft:white_concrete
fill 501 220 510 501 225 510 minecraft:white_concrete
fill 502 220 550 504 225 550 minecraft:quartz_block
fill 503 220 510 504 220 510 minecraft:white_concrete
fill 504 220 526 506 220 526 minecraft:white_concrete
setblock 505 220 510 minecraft:light_blue_concrete
fill 505 220 513 505 220 516 minecraft:smooth_quartz
fill 505 220 525 506 220 525 minecraft:white_concrete
fill 506 220 510 508 220 510 minecraft:white_concrete
fill 506 220 512 508 225 512 minecraft:quartz_block
setblock 506 220 516 minecraft:smooth_quartz
fill 508 220 513 509 220 513 minecraft:smooth_quartz
setblock 508 220 516 minecraft:smooth_quartz
fill 509 220 514 509 220 515 minecraft:smooth_quartz
fill 509 220 526 510 220 526 minecraft:white_concrete
fill 510 220 520 510 225 522 minecraft:quartz_block
fill 510 220 532 510 225 534 minecraft:quartz_block
fill 510 220 544 510 225 546 minecraft:quartz_block
fill 511 220 525 512 220 525 minecraft:white_concrete
fill 512 220 513 512 225 513 minecraft:white_concrete
fill 512 220 520 512 307 520 minecraft:white_concrete
fill 512 220 524 512 225 524 minecraft:white_concrete
fill 512 220 526 512 221 526 minecraft:light_blue_concrete
fill 512 220 527 512 307 531 minecraft:white_concrete
fill 512 220 537 512 225 537 minecraft:white_concrete
fill 512 220 540 512 307 541 minecraft:white_concrete
setblock 512 220 542 minecraft:light_blue_concrete
fill 512 220 543 512 307 546 minecraft:white_concrete
setblock 512 220 547 minecraft:light_blue_concrete
fill 512 220 548 512 225 551 minecraft:white_concrete
fill 470 221 510 471 307 510 minecraft:white_concrete
fill 470 221 512 470 307 513 minecraft:white_concrete
fill 470 221 523 470 225 534 minecraft:white_concrete
setblock 470 221 535 minecraft:light_blue_concrete
fill 470 221 536 470 307 537 minecraft:white_concrete
fill 470 221 538 470 221 539 minecraft:light_blue_concrete
fill 470 221 540 470 225 540 minecraft:white_concrete
fill 470 221 549 470 221 550 minecraft:light_blue_concrete
fill 470 221 551 470 307 551 minecraft:white_concrete
setblock 470 221 552 minecraft:light_blue_concrete
setblock 472 221 510 minecraft:light_blue_concrete
fill 473 221 510 477 225 510 minecraft:white_concrete
fill 474 221 524 476 221 524 minecraft:white_concrete
fill 475 221 525 476 221 525 minecraft:white_concrete
fill 476 221 526 476 223 536 minecraft:gold_block
fill 476 221 552 476 307 552 minecraft:white_concrete
fill 477 221 524 477 223 530 minecraft:gold_block
fill 477 221 532 477 223 538 minecraft:gold_block
setblock 477 221 552 minecraft:light_blue_concrete
fill 478 221 522 478 223 525 minecraft:gold_block
fill 478 221 537 478 223 540 minecraft:gold_block
fill 478 221 552 483 225 552 minecraft:white_concrete
fill 479 221 510 480 225 510 minecraft:white_concrete
fill 479 221 521 479 223 523 minecraft:gold_block
fill 479 221 539 479 223 541 minecraft:gold_block
fill 480 221 520 480 223 522 minecraft:gold_block
fill 480 221 540 480 223 542 minecraft:gold_block
setblock 481 221 510 minecraft:light_blue_concrete
fill 481 221 519 481 223 521 minecraft:gold_block
fill 481 221 541 481 223 543 minecraft:gold_block
fill 482 221 510 489 225 510 minecraft:white_concrete
fill 482 221 518 482 223 520 minecraft:gold_block
fill 482 221 542 482 223 544 minecraft:gold_block
fill 483 221 518 483 223 519 minecraft:gold_block
fill 483 221 543 483 223 544 minecraft:gold_block
fill 484 221 517 485 223 518 minecraft:gold_block
fill 484 221 544 485 223 545 minecraft:gold_block
setblock 484 221 552 minecraft:light_blue_concrete
fill 485 221 552 490 225 552 minecraft:white_concrete
fill 486 221 516 490 223 517 minecraft:gold_block
fill 486 221 545 490 223 546 minecraft:gold_block
fill 491 221 516 496 223 516 minecraft:gold_block
fill 491 221 546 496 223 546 minecraft:gold_block
setblock 491 221 552 minecraft:light_blue_concrete
fill 492 221 517 498 223 517 minecraft:gold_block
fill 492 221 545 498 223 545 minecraft:gold_block
fill 492 221 552 493 307 552 minecraft:white_concrete
fill 497 221 518 500 223 518 minecraft:gold_block
fill 497 221 544 500 223 544 minecraft:gold_block
fill 497 221 552 497 225 552 minecraft:white_concrete
fill 499 221 519 501 223 519 minecraft:gold_block
fill 499 221 543 501 223 543 minecraft:gold_block
fill 500 221 520 502 223 520 minecraft:gold_block
fill 500 221 542 502 223 542 minecraft:gold_block
fill 501 221 521 503 223 521 minecraft:gold_block
fill 501 221 541 503 223 541 minecraft:gold_block
fill 502 221 522 504 223 522 minecraft:gold_block
fill 502 221 540 504 223 540 minecraft:gold_block
fill 503 221 510 503 225 510 minecraft:white_concrete
fill 503 221 523 504 223 523 minecraft:gold_block
fill 503 221 539 504 223 539 minecraft:gold_block
setblock 504 221 510 minecraft:light_blue_concrete
fill 504 221 524 505 223 525 minecraft:gold_block
fill 504 221 537 505 223 538 minecraft:gold_block
fill 505 221 510 505 307 510 minecraft:white_concrete
fill 505 221 526 506 223 530 minecraft:gold_block
fill 505 221 532 506 223 536 minecraft:gold_block
setblock 506 221 510 minecraft:light_blue_concrete
fill 506 221 524 507 221 525 minecraft:white_concrete
fill 506 221 531 506 223 531 minecraft:gold_block
fill 507 221 510 511 307 510 minecraft:white_concrete
fill 508 221 524 508 223 524 minecraft:white_concrete
fill 512 221 510 512 221 511 minecraft:light_blue_concrete
fill 512 221 512 512 225 512 minecraft:white_concrete
setblock 512 221 514 minecraft:light_blue_concrete
fill 512 221 515 512 307 516 minecraft:white_concrete
setblock 512 221 517 minecraft:light_blue_concrete
fill 512 221 518 512 307 519 minecraft:white_concrete
fill 512 221 523 512 225 523 minecraft:white_concrete
setblock 512 221 525 minecraft:light_blue_concrete
setblock 512 221 532 minecraft:light_blue_concrete
fill 512 221 533 512 225 536 minecraft:white_concrete
fill 512 221 542 512 307 542 minecraft:white_concrete
fill 512 221 547 512 225 547 minecraft:white_concrete
fill 470 222 535 470 307 535 minecraft:white_concrete
fill 470 222 538 470 307 539 minecraft:white_concrete
fill 470 222 549 470 307 550 minecraft:white_concrete
fill 470 222 552 470 225 552 minecraft:white_concrete
fill 472 222 510 472 307 510 minecraft:white_concrete
fill 473 222 523 474 223 524 minecraft:white_concrete
fill 475 222 524 475 222 525 minecraft:white_concrete
fill 475 222 528 475 222 534 minecraft:gold_block
setblock 476 222 525 minecraft:gold_block
setblock 476 222 537 minecraft:gold_block
setblock 477 222 523 minecraft:gold_block
setblock 477 222 531 minecraft:gold_block
setblock 477 222 539 minecraft:gold_block
fill 477 222 552 477 307 552 minecraft:white_concrete
fill 478 222 510 478 225 510 minecraft:white_concrete
fill 478 222 526 478 222 527 minecraft:gold_block
fill 478 222 535 478 222 536 minecraft:gold_block
setblock 479 222 520 minecraft:gold_block
setblock 479 222 524 minecraft:gold_block
setblock 479 222 538 minecraft:gold_block
setblock 479 222 542 minecraft:gold_block
setblock 480 222 519 minecraft:gold_block
setblock 480 222 523 minecraft:gold_block
setblock 480 222 539 minecraft:gold_block
setblock 480 222 543 minecraft:gold_block
fill 481 222 510 481 307 510 minecraft:white_concrete
setblock 483 222 517 minecraft:gold_block
setblock 483 222 520 minecraft:gold_block
setblock 483 222 542 minecraft:gold_block
setblock 483 222 545 minecraft:gold_block
setblock 484 222 519 minecraft:gold_block
setblock 484 222 543 minecraft:gold_block
fill 484 222 552 484 225 552 minecraft:white_concrete
setblock 485 222 516 minecraft:gold_block
setblock 485 222 546 minecraft:gold_block
fill 486 222 518 487 222 518 minecraft:gold_block
fill 486 222 544 487 222 544 minecraft:gold_block
fill 488 222 515 494 222 515 minecraft:gold_block
fill 488 222 547 494 222 547 minecraft:gold_block
setblock 491 222 517 minecraft:gold_block
setblock 491 222 545 minecraft:gold_block
fill 491 222 552 491 307 552 minecraft:white_concrete
fill 495 222 518 496 222 518 minecraft:gold_block
fill 495 222 544 496 222 544 minecraft:gold_block
setblock 497 222 516 minecraft:gold_block
setblock 497 222 546 minecraft:gold_block
setblock 498 222 519 minecraft:gold_block
setblock 498 222 543 minecraft:gold_block
setblock 499 222 517 minecraft:gold_block
setblock 499 222 520 minecraft:gold_block
setblock 499 222 542 minecraft:gold_block
setblock 499 222 545 minecraft:gold_block
fill 499 222 552 499 307 552 minecraft:white_concrete
setblock 502 222 519 minecraft:gold_block
setblock 502 222 523 minecraft:gold_block
setblock 502 222 539 minecraft:gold_block
setblock 502 222 543 minecraft:gold_block
setblock 503 222 520 minecraft:gold_block
setblock 503 222 524 minecraft:gold_block
setblock 503 222 538 minecraft:gold_block
setblock 503 222 542 minecraft:gold_block
fill 504 222 510 504 225 510 minecraft:white_concrete
fill 504 222 526 504 222 527 minecraft:gold_block
fill 504 222 535 504 222 536 minecraft:gold_block
setblock 505 222 523 minecraft:gold_block
setblock 505 222 531 minecraft:gold_block
setblock 505 222 539 minecraft:gold_block
fill 506 222 510 506 307 510 minecraft:white_concrete
setblock 506 222 525 minecraft:gold_block
setblock 506 222 537 minecraft:gold_block
fill 507 222 524 507 222 525 minecraft:white_concrete
fill 507 222 528 507 222 534 minecraft:gold_block
fill 508 222 523 509 223 523 minecraft:white_concrete
fill 509 222 524 509 223 524 minecraft:white_concrete
fill 512 222 510 512 225 511 minecraft:white_concrete
fill 512 222 514 512 225 514 minecraft:white_concrete
fill 512 222 517 512 307 517 minecraft:white_concrete
fill 512 222 525 512 225 526 minecraft:white_concrete
fill 512 222 532 512 307 532 minecraft:white_concrete
fill 472 223 523 472 224 523 minecraft:white_concrete
setblock 473 223 522 minecraft:white_concrete
setblock 509 223 522 minecraft:white_concrete
fill 510 223 523 510 224 523 minecraft:white_concrete
setblock 473 224 523 minecraft:white_concrete
setblock 509 224 523 minecraft:white_concrete
setblock 511 224 522 minecraft:white_concrete
fill 471 225 514 471 225 519 minecraft:smooth_quartz
fill 471 225 526 471 225 531 minecraft:smooth_quartz
fill 471 225 538 471 225 543 minecraft:smooth_quartz
fill 471 225 550 471 225 551 minecraft:smooth_quartz
fill 472 225 551 475 225 551 minecraft:smooth_quartz
fill 475 225 511 480 225 511 minecraft:smooth_quartz
fill 482 225 551 487 225 551 minecraft:smooth_quartz
fill 487 225 511 492 225 511 minecraft:smooth_quartz
fill 494 225 551 499 225 551 minecraft:smooth_quartz
fill 499 225 511 504 225 511 minecraft:smooth_quartz
fill 506 225 551 511 225 551 minecraft:smooth_quartz
fill 511 225 511 511 225 516 minecraft:smooth_quartz
fill 511 225 523 511 225 528 minecraft:smooth_quartz
fill 511 225 535 511 225 540 minecraft:smooth_quartz
fill 511 225 547 511 225 550 minecraft:smooth_quartz
fill 470 226 516 470 231 519 minecraft:pearlescent_froglight
fill 470 226 520 470 307 527 minecraft:white_concrete
fill 470 226 528 470 231 531 minecraft:pearlescent_froglight
fill 470 226 532 470 307 534 minecraft:white_concrete
fill 470 226 540 470 231 543 minecraft:pearlescent_froglight
fill 470 226 552 473 231 552 minecraft:pearlescent_froglight
fill 473 226 510 476 307 510 minecraft:white_concrete
fill 474 226 552 475 307 552 minecraft:white_concrete
fill 477 226 510 480 231 510 minecraft:pearlescent_froglight
fill 478 226 552 481 307 552 minecraft:white_concrete
fill 482 226 510 488 307 510 minecraft:white_concrete
fill 482 226 552 485 231 552 minecraft:pearlescent_froglight
fill 486 226 552 490 307 552 minecraft:white_concrete
fill 489 226 510 492 231 510 minecraft:pearlescent_froglight
fill 493 226 510 494 307 510 minecraft:white_concrete
fill 494 226 552 497 231 552 minecraft:pearlescent_froglight
fill 500 226 552 505 307 552 minecraft:white_concrete
fill 501 226 510 504 231 510 minecraft:pearlescent_froglight
fill 506 226 552 509 231 552 minecraft:pearlescent_froglight
fill 510 226 552 512 307 552 minecraft:white_concrete
fill 512 226 510 512 307 510 minecraft:white_concrete
fill 512 226 511 512 231 514 minecraft:pearlescent_froglight
fill 512 226 523 512 231 526 minecraft:pearlescent_froglight
fill 512 226 533 512 307 534 minecraft:white_concrete
fill 512 226 535 512 231 538 minecraft:pearlescent_froglight
fill 512 226 539 512 307 539 minecraft:white_concrete
fill 512 226 547 512 231 550 minecraft:pearlescent_froglight
fill 512 226 551 512 307 551 minecraft:white_concrete
setblock 473 227 513 minecraft:light[level=14]
setblock 473 227 521 minecraft:light[level=14]
setblock 473 227 529 minecraft:light[level=14]
setblock 473 227 537 minecraft:light[level=14]
setblock 473 227 545 minecraft:light[level=14]
setblock 481 227 513 minecraft:light[level=14]
setblock 481 227 521 minecraft:light[level=14]
setblock 481 227 529 minecraft:light[level=14]
setblock 481 227 537 minecraft:light[level=14]
setblock 481 227 545 minecraft:light[level=14]
setblock 489 227 513 minecraft:light[level=14]
setblock 489 227 521 minecraft:light[level=14]
setblock 489 227 529 minecraft:light[level=14]
setblock 489 227 537 minecraft:light[level=14]
setblock 489 227 545 minecraft:light[level=14]
setblock 497 227 513 minecraft:light[level=14]
setblock 497 227 521 minecraft:light[level=14]
setblock 497 227 529 minecraft:light[level=14]
setblock 497 227 537 minecraft:light[level=14]
setblock 497 227 545 minecraft:light[level=14]
fill 499 227 530 499 228 530 minecraft:gold_block
setblock 505 227 513 minecraft:light[level=14]
setblock 505 227 521 minecraft:light[level=14]
setblock 505 227 529 minecraft:light[level=14]
setblock 505 227 537 minecraft:light[level=14]
setblock 505 227 545 minecraft:light[level=14]
fill 505 228 513 505 228 516 minecraft:smooth_quartz
fill 506 228 512 507 228 512 minecraft:smooth_quartz
setblock 506 228 516 minecraft:smooth_quartz
fill 508 228 513 509 228 513 minecraft:smooth_quartz
setblock 508 228 516 minecraft:smooth_quartz
fill 509 228 514 509 228 515 minecraft:smooth_quartz
fill 505 230 513 505 231 515 minecraft:gold_block
fill 506 230 516 506 231 516 minecraft:gold_block
fill 507 230 512 507 231 512 minecraft:gold_block
fill 508 230 513 508 231 513 minecraft:gold_block
fill 508 230 516 508 231 516 minecraft:gold_block
fill 509 230 514 509 231 515 minecraft:gold_block
fill 470 232 516 470 245 519 minecraft:white_concrete
fill 470 232 528 470 245 531 minecraft:white_concrete
fill 470 232 540 470 245 543 minecraft:white_concrete
fill 470 232 552 473 245 552 minecraft:white_concrete
fill 477 232 510 480 245 510 minecraft:white_concrete
fill 482 232 552 485 245 552 minecraft:white_concrete
fill 489 232 510 492 245 510 minecraft:white_concrete
fill 494 232 552 497 245 552 minecraft:white_concrete
fill 501 232 510 504 245 510 minecraft:white_concrete
fill 506 232 552 509 245 552 minecraft:white_concrete
fill 512 232 511 512 245 514 minecraft:white_concrete
fill 512 232 523 512 245 526 minecraft:white_concrete
fill 512 232 535 512 245 538 minecraft:white_concrete
fill 512 232 547 512 245 550 minecraft:white_concrete
setblock 473 235 513 minecraft:light[level=14]
setblock 473 235 521 minecraft:light[level=14]
setblock 473 235 529 minecraft:light[level=14]
setblock 473 235 537 minecraft:light[level=14]
setblock 473 235 545 minecraft:light[level=14]
setblock 481 235 513 minecraft:light[level=14]
setblock 481 235 521 minecraft:light[level=14]
setblock 481 235 529 minecraft:light[level=14]
setblock 481 235 537 minecraft:light[level=14]
setblock 481 235 545 minecraft:light[level=14]
setblock 489 235 513 minecraft:light[level=14]
setblock 489 235 521 minecraft:light[level=14]
setblock 489 235 529 minecraft:light[level=14]
setblock 489 235 537 minecraft:light[level=14]
setblock 489 235 545 minecraft:light[level=14]
setblock 497 235 513 minecraft:light[level=14]
setblock 497 235 521 minecraft:light[level=14]
setblock 497 235 529 minecraft:light[level=14]
setblock 497 235 537 minecraft:light[level=14]
setblock 497 235 545 minecraft:light[level=14]
setblock 505 235 513 minecraft:light[level=14]
setblock 505 235 521 minecraft:light[level=14]
setblock 505 235 529 minecraft:light[level=14]
setblock 505 235 537 minecraft:light[level=14]
setblock 505 235 545 minecraft:light[level=14]
fill 471 237 511 511 238 513 minecraft:white_wool
fill 471 237 514 511 238 514 minecraft:light_gray_wool
fill 471 237 515 511 238 517 minecraft:white_wool
fill 471 237 518 511 238 518 minecraft:light_gray_wool
fill 471 237 519 511 238 521 minecraft:white_wool
fill 471 237 522 511 238 522 minecraft:light_gray_wool
fill 471 237 523 511 237 525 minecraft:white_wool
fill 471 237 526 494 237 526 minecraft:light_gray_wool
fill 471 237 527 492 237 529 minecraft:white_wool
fill 471 237 530 494 237 530 minecraft:light_gray_wool
fill 471 237 531 511 237 533 minecraft:white_wool
fill 471 237 534 511 238 534 minecraft:light_gray_wool
fill 471 237 535 511 238 537 minecraft:white_wool
fill 471 237 538 511 238 538 minecraft:light_gray_wool
fill 471 237 539 511 238 541 minecraft:white_wool
fill 471 237 542 511 238 542 minecraft:light_gray_wool
fill 471 237 543 511 238 545 minecraft:white_wool
fill 471 237 546 511 238 546 minecraft:light_gray_wool
fill 471 237 547 511 238 549 minecraft:white_wool
fill 471 237 550 511 238 550 minecraft:light_gray_wool
fill 471 237 551 511 238 551 minecraft:white_wool
setblock 493 237 527 minecraft:white_wool
setblock 493 237 529 minecraft:white_wool
fill 496 237 526 511 237 526 minecraft:light_gray_wool
fill 496 237 530 511 237 530 minecraft:light_gray_wool
fill 497 237 527 511 237 527 minecraft:white_wool
fill 497 237 529 511 237 529 minecraft:white_wool
fill 498 237 528 511 237 528 minecraft:white_wool
fill 471 238 523 493 238 525 minecraft:white_wool
fill 471 238 526 492 238 526 minecraft:light_gray_wool
fill 471 238 527 491 238 529 minecraft:white_wool
fill 471 238 530 492 238 530 minecraft:light_gray_wool
fill 471 238 531 493 238 533 minecraft:white_wool
fill 492 238 527 492 238 529 minecraft:pearlescent_froglight
fill 493 238 526 493 238 527 minecraft:pearlescent_froglight
fill 493 238 529 493 238 530 minecraft:pearlescent_froglight
fill 494 238 523 511 238 524 minecraft:white_wool
fill 494 238 525 494 238 526 minecraft:pearlescent_froglight
fill 494 238 530 494 238 531 minecraft:pearlescent_froglight
fill 494 238 532 511 238 533 minecraft:white_wool
fill 495 238 525 496 238 525 minecraft:pearlescent_froglight
fill 495 238 531 496 238 531 minecraft:pearlescent_froglight
fill 496 238 526 497 238 526 minecraft:pearlescent_froglight
fill 496 238 530 497 238 530 minecraft:pearlescent_froglight
fill 497 238 525 511 238 525 minecraft:white_wool
fill 497 238 527 498 238 527 minecraft:pearlescent_froglight
fill 497 238 529 498 238 529 minecraft:pearlescent_froglight
fill 497 238 531 511 238 531 minecraft:white_wool
fill 498 238 526 511 238 526 minecraft:light_gray_wool
setblock 498 238 528 minecraft:pearlescent_froglight
fill 498 238 530 511 238 530 minecraft:light_gray_wool
fill 499 238 527 511 238 529 minecraft:white_wool
fill 492 239 527 492 239 529 minecraft:lime_stained_glass
setblock 493 239 526 minecraft:lime_stained_glass
setblock 493 239 530 minecraft:lime_stained_glass
fill 494 239 525 496 239 525 minecraft:lime_stained_glass
fill 494 239 531 496 239 531 minecraft:lime_stained_glass
setblock 497 239 526 minecraft:lime_stained_glass
setblock 497 239 530 minecraft:lime_stained_glass
fill 498 239 527 498 239 529 minecraft:lime_stained_glass
fill 484 240 526 492 240 530 minecraft:light_gray_concrete
fill 485 240 523 505 240 525 minecraft:light_gray_concrete
fill 485 240 531 505 240 533 minecraft:light_gray_concrete
fill 486 240 522 504 243 522 minecraft:light_gray_concrete
fill 486 240 534 504 243 534 minecraft:light_gray_concrete
fill 487 240 521 503 243 521 minecraft:light_gray_concrete
fill 487 240 535 503 243 535 minecraft:light_gray_concrete
fill 488 240 520 502 243 520 minecraft:light_gray_concrete
fill 488 240 536 502 243 536 minecraft:light_gray_concrete
fill 489 240 519 501 243 519 minecraft:light_gray_concrete
fill 489 240 537 501 243 537 minecraft:light_gray_concrete
fill 490 240 518 500 243 518 minecraft:light_gray_concrete
fill 490 240 538 500 243 538 minecraft:light_gray_concrete
fill 493 240 517 497 243 517 minecraft:light_gray_concrete
setblock 493 240 526 minecraft:light_gray_concrete
setblock 493 240 530 minecraft:light_gray_concrete
fill 493 240 539 497 243 539 minecraft:light_gray_concrete
fill 497 240 526 506 240 526 minecraft:light_gray_concrete
fill 497 240 530 506 240 530 minecraft:light_gray_concrete
fill 498 240 527 506 240 529 minecraft:light_gray_concrete
fill 482 241 524 482 242 532 minecraft:sea_lantern
fill 483 241 522 483 242 525 minecraft:sea_lantern
fill 483 241 526 491 241 530 minecraft:light_gray_concrete
fill 483 241 531 483 242 534 minecraft:sea_lantern
fill 484 241 520 484 242 522 minecraft:sea_lantern
fill 484 241 523 494 241 525 minecraft:light_gray_concrete
fill 484 241 531 494 241 533 minecraft:light_gray_concrete
fill 484 241 534 484 242 536 minecraft:sea_lantern
fill 485 241 519 485 242 520 minecraft:sea_lantern
fill 485 241 521 485 242 522 minecraft:light_gray_concrete
fill 485 241 534 485 242 535 minecraft:light_gray_concrete
fill 485 241 536 485 242 537 minecraft:sea_lantern
fill 486 241 518 486 242 519 minecraft:sea_lantern
fill 486 241 520 486 242 521 minecraft:light_gray_concrete
fill 486 241 535 486 242 536 minecraft:light_gray_concrete
fill 486 241 537 486 242 538 minecraft:sea_lantern
fill 487 241 517 487 242 518 minecraft:sea_lantern
fill 487 241 519 487 242 520 minecraft:light_gray_concrete
fill 487 241 536 487 242 537 minecraft:light_gray_concrete
fill 487 241 538 487 242 539 minecraft:sea_lantern
fill 488 241 517 489 242 517 minecraft:sea_lantern
fill 488 241 518 488 242 519 minecraft:light_gray_concrete
fill 488 241 537 488 242 538 minecraft:light_gray_concrete
fill 488 241 539 489 242 539 minecraft:sea_lantern
fill 489 241 516 492 242 516 minecraft:sea_lantern
fill 489 241 518 489 242 518 minecraft:light_gray_concrete
fill 489 241 538 489 242 538 minecraft:light_gray_concrete
fill 489 241 540 492 242 540 minecraft:sea_lantern
fill 490 241 517 492 242 517 minecraft:light_gray_concrete
fill 490 241 539 492 242 539 minecraft:light_gray_concrete
fill 491 241 515 499 242 515 minecraft:sea_lantern
fill 491 241 541 499 242 541 minecraft:sea_lantern
fill 492 241 526 492 241 527 minecraft:light_gray_concrete
setblock 492 241 528 minecraft:light_blue_stained_glass
fill 492 241 529 492 241 530 minecraft:light_gray_concrete
fill 493 241 516 497 242 516 minecraft:light_gray_concrete
fill 493 241 540 497 242 540 minecraft:light_gray_concrete
fill 495 241 523 506 241 524 minecraft:light_gray_concrete
setblock 495 241 525 minecraft:light_blue_stained_glass
setblock 495 241 531 minecraft:light_blue_stained_glass
fill 495 241 532 506 241 533 minecraft:light_gray_concrete
fill 496 241 525 506 241 525 minecraft:light_gray_concrete
fill 496 241 531 506 241 531 minecraft:light_gray_concrete
fill 498 241 516 501 242 516 minecraft:sea_lantern
fill 498 241 517 500 242 517 minecraft:light_gray_concrete
fill 498 241 526 507 241 527 minecraft:light_gray_concrete
setblock 498 241 528 minecraft:light_blue_stained_glass
fill 498 241 529 507 241 530 minecraft:light_gray_concrete
fill 498 241 539 500 242 539 minecraft:light_gray_concrete
fill 498 241 540 501 242 540 minecraft:sea_lantern
fill 499 241 528 507 241 528 minecraft:light_gray_concrete
fill 501 241 517 503 242 517 minecraft:sea_lantern
fill 501 241 518 502 242 518 minecraft:light_gray_concrete
fill 501 241 538 502 242 538 minecraft:light_gray_concrete
fill 501 241 539 503 242 539 minecraft:sea_lantern
fill 502 241 519 503 242 519 minecraft:light_gray_concrete
fill 502 241 537 503 242 537 minecraft:light_gray_concrete
fill 503 241 518 504 242 518 minecraft:sea_lantern
fill 503 241 520 504 242 520 minecraft:light_gray_concrete
fill 503 241 536 504 242 536 minecraft:light_gray_concrete
fill 503 241 538 504 242 538 minecraft:sea_lantern
fill 504 241 519 505 242 519 minecraft:sea_lantern
fill 504 241 521 505 242 521 minecraft:light_gray_concrete
fill 504 241 535 505 242 535 minecraft:light_gray_concrete
fill 504 241 537 505 242 537 minecraft:sea_lantern
fill 505 241 520 506 242 520 minecraft:sea_lantern
fill 505 241 522 505 242 522 minecraft:light_gray_concrete
fill 505 241 534 505 242 534 minecraft:light_gray_concrete
fill 505 241 536 506 242 536 minecraft:sea_lantern
fill 506 241 521 506 242 522 minecraft:sea_lantern
fill 506 241 534 506 242 535 minecraft:sea_lantern
fill 507 241 522 507 242 525 minecraft:sea_lantern
fill 507 241 531 507 242 534 minecraft:sea_lantern
fill 508 241 524 508 242 532 minecraft:sea_lantern
fill 471 242 511 473 273 511 minecraft:quartz_block
fill 471 242 521 471 273 523 minecraft:quartz_block
fill 471 242 533 471 273 535 minecraft:quartz_block
fill 471 242 545 471 273 547 minecraft:quartz_block
fill 472 242 520 472 245 522 minecraft:quartz_block
fill 472 242 532 472 245 534 minecraft:quartz_block
fill 472 242 544 472 245 546 minecraft:quartz_block
fill 475 242 512 479 244 512 minecraft:white_wool
fill 477 242 551 479 273 551 minecraft:quartz_block
fill 478 242 550 480 245 550 minecraft:quartz_block
fill 482 242 512 484 245 512 minecraft:quartz_block
fill 483 242 511 485 273 511 minecraft:quartz_block
fill 483 242 526 490 242 530 minecraft:light_gray_concrete
fill 484 242 523 491 242 525 minecraft:light_gray_concrete
fill 484 242 531 491 242 533 minecraft:light_gray_concrete
fill 489 242 551 491 273 551 minecraft:quartz_block
fill 490 242 550 492 245 550 minecraft:quartz_block
fill 491 242 526 491 246 530 minecraft:light_blue_stained_glass
fill 492 242 523 492 242 524 minecraft:light_gray_concrete
fill 492 242 525 492 242 527 minecraft:light_blue_stained_glass
fill 492 242 529 492 242 531 minecraft:light_blue_stained_glass
fill 492 242 532 492 242 533 minecraft:light_gray_concrete
fill 493 242 523 506 242 523 minecraft:light_gray_concrete
fill 493 242 524 494 242 525 minecraft:light_blue_stained_glass
fill 493 242 531 494 242 532 minecraft:light_blue_stained_glass
fill 493 242 533 506 242 533 minecraft:light_gray_concrete
fill 494 242 512 496 245 512 minecraft:quartz_block
fill 495 242 511 497 273 511 minecraft:quartz_block
fill 495 242 524 497 246 524 minecraft:light_blue_stained_glass
fill 495 242 532 497 246 532 minecraft:light_blue_stained_glass
fill 496 242 525 498 242 525 minecraft:light_blue_stained_glass
fill 496 242 531 498 242 531 minecraft:light_blue_stained_glass
fill 498 242 524 506 242 524 minecraft:light_gray_concrete
fill 498 242 526 499 242 527 minecraft:light_blue_stained_glass
fill 498 242 529 499 242 530 minecraft:light_blue_stained_glass
fill 498 242 532 506 242 532 minecraft:light_gray_concrete
fill 499 242 525 506 242 525 minecraft:light_gray_concrete
fill 499 242 528 499 246 528 minecraft:light_blue_stained_glass
fill 499 242 531 506 242 531 minecraft:light_gray_concrete
fill 500 242 526 507 242 530 minecraft:light_gray_concrete
fill 501 242 551 503 273 551 minecraft:quartz_block
fill 502 242 550 504 245 550 minecraft:quartz_block
fill 506 242 512 508 245 512 minecraft:quartz_block
fill 507 242 511 509 273 511 minecraft:quartz_block
fill 510 242 520 510 245 522 minecraft:quartz_block
fill 510 242 532 510 245 534 minecraft:quartz_block
fill 510 242 544 510 245 546 minecraft:quartz_block
fill 511 242 519 511 273 521 minecraft:quartz_block
fill 511 242 531 511 273 533 minecraft:quartz_block
fill 511 242 543 511 273 545 minecraft:quartz_block
setblock 473 243 513 minecraft:light[level=14]
setblock 473 243 521 minecraft:light[level=14]
setblock 473 243 529 minecraft:light[level=14]
setblock 473 243 537 minecraft:light[level=14]
setblock 473 243 545 minecraft:light[level=14]
setblock 481 243 513 minecraft:light[level=14]
setblock 481 243 521 minecraft:light[level=14]
setblock 481 243 529 minecraft:light[level=14]
setblock 481 243 537 minecraft:light[level=14]
setblock 481 243 545 minecraft:light[level=14]
fill 484 243 526 489 243 530 minecraft:light_gray_concrete
fill 485 243 523 490 243 525 minecraft:light_gray_concrete
fill 485 243 531 490 243 533 minecraft:light_gray_concrete
setblock 489 243 513 minecraft:light[level=14]
setblock 489 243 545 minecraft:light[level=14]
fill 490 243 526 490 245 530 minecraft:light_blue_stained_glass
fill 491 243 523 492 243 523 minecraft:light_gray_concrete
fill 491 243 524 493 244 525 minecraft:light_blue_stained_glass
fill 491 243 531 493 244 532 minecraft:light_blue_stained_glass
fill 491 243 533 492 243 533 minecraft:light_gray_concrete
fill 492 243 526 492 244 526 minecraft:light_blue_stained_glass
fill 492 243 530 492 244 530 minecraft:light_blue_stained_glass
fill 493 243 523 497 245 523 minecraft:light_blue_stained_glass
fill 493 243 533 497 245 533 minecraft:light_blue_stained_glass
fill 494 243 524 494 246 524 minecraft:light_blue_stained_glass
fill 494 243 532 494 246 532 minecraft:light_blue_stained_glass
setblock 497 243 513 minecraft:light[level=14]
fill 497 243 525 499 244 525 minecraft:light_blue_stained_glass
fill 497 243 531 499 244 531 minecraft:light_blue_stained_glass
setblock 497 243 545 minecraft:light[level=14]
fill 498 243 523 505 243 523 minecraft:light_gray_concrete
fill 498 243 524 499 245 524 minecraft:light_blue_stained_glass
fill 498 243 526 500 244 526 minecraft:light_blue_stained_glass
fill 498 243 530 500 244 530 minecraft:light_blue_stained_glass
fill 498 243 532 499 245 532 minecraft:light_blue_stained_glass
fill 498 243 533 505 243 533 minecraft:light_gray_concrete
fill 499 243 527 500 245 527 minecraft:light_blue_stained_glass
fill 499 243 529 500 245 529 minecraft:light_blue_stained_glass
fill 500 243 524 505 243 525 minecraft:light_gray_concrete
fill 500 243 528 500 245 528 minecraft:light_blue_stained_glass
fill 500 243 531 505 243 532 minecraft:light_gray_concrete
fill 501 243 526 506 243 530 minecraft:light_gray_concrete
setblock 505 243 513 minecraft:light[level=14]
setblock 505 243 521 minecraft:light[level=14]
setblock 505 243 537 minecraft:light[level=14]
setblock 505 243 545 minecraft:light[level=14]
setblock 489 244 528 minecraft:light_blue_stained_glass
setblock 490 244 525 minecraft:light_blue_stained_glass
setblock 490 244 531 minecraft:light_blue_stained_glass
setblock 492 244 523 minecraft:light_blue_stained_glass
setblock 492 244 533 minecraft:light_blue_stained_glass
setblock 495 244 522 minecraft:light_blue_stained_glass
setblock 495 244 534 minecraft:light_blue_stained_glass
setblock 498 244 523 minecraft:light_blue_stained_glass
setblock 498 244 533 minecraft:light_blue_stained_glass
setblock 500 244 525 minecraft:light_blue_stained_glass
setblock 500 244 531 minecraft:light_blue_stained_glass
setblock 501 244 528 minecraft:light_blue_stained_glass
fill 471 245 514 471 245 519 minecraft:smooth_quartz
fill 471 245 526 471 245 531 minecraft:smooth_quartz
fill 471 245 538 471 245 543 minecraft:smooth_quartz
fill 471 245 550 471 245 551 minecraft:smooth_quartz
fill 472 245 551 475 245 551 minecraft:smooth_quartz
fill 474 245 512 480 246 512 minecraft:gold_block
fill 475 245 511 480 245 511 minecraft:smooth_quartz
fill 482 245 551 487 245 551 minecraft:smooth_quartz
fill 487 245 511 492 245 511 minecraft:smooth_quartz
fill 491 245 524 492 245 525 minecraft:light_blue_stained_glass
fill 491 245 531 492 245 532 minecraft:light_blue_stained_glass
fill 493 245 524 493 246 524 minecraft:light_blue_stained_glass
fill 493 245 532 493 246 532 minecraft:light_blue_stained_glass
fill 494 245 551 499 245 551 minecraft:smooth_quartz
fill 498 245 525 499 245 525 minecraft:light_blue_stained_glass
fill 498 245 531 499 245 531 minecraft:light_blue_stained_glass
fill 499 245 511 504 245 511 minecraft:smooth_quartz
fill 499 245 526 500 245 526 minecraft:light_blue_stained_glass
fill 499 245 530 500 245 530 minecraft:light_blue_stained_glass
fill 506 245 551 511 245 551 minecraft:smooth_quartz
fill 511 245 511 511 245 516 minecraft:smooth_quartz
fill 511 245 523 511 245 528 minecraft:smooth_quartz
fill 511 245 535 511 245 540 minecraft:smooth_quartz
fill 511 245 547 511 245 550 minecraft:smooth_quartz
fill 470 246 516 470 251 519 minecraft:pearlescent_froglight
fill 470 246 528 470 251 531 minecraft:pearlescent_froglight
fill 470 246 540 470 251 543 minecraft:pearlescent_froglight
fill 470 246 552 473 251 552 minecraft:pearlescent_froglight
fill 477 246 510 480 251 510 minecraft:pearlescent_froglight
fill 482 246 552 485 251 552 minecraft:pearlescent_froglight
fill 489 246 510 492 251 510 minecraft:pearlescent_froglight
setblock 492 246 525 minecraft:light_blue_stained_glass
setblock 492 246 531 minecraft:light_blue_stained_glass
fill 494 246 552 497 251 552 minecraft:pearlescent_froglight
setblock 498 246 525 minecraft:light_blue_stained_glass
setblock 498 246 531 minecraft:light_blue_stained_glass
fill 499 246 526 499 246 527 minecraft:light_blue_stained_glass
fill 499 246 529 499 246 530 minecraft:light_blue_stained_glass
fill 501 246 510 504 251 510 minecraft:pearlescent_froglight
fill 506 246 552 509 251 552 minecraft:pearlescent_froglight
fill 512 246 511 512 251 514 minecraft:pearlescent_froglight
fill 512 246 523 512 251 526 minecraft:pearlescent_froglight
fill 512 246 535 512 251 538 minecraft:pearlescent_froglight
fill 512 246 547 512 251 550 minecraft:pearlescent_froglight
fill 502 250 532 502 251 532 minecraft:gold_block
setblock 473 251 513 minecraft:light[level=14]
setblock 473 251 521 minecraft:light[level=14]
setblock 473 251 529 minecraft:light[level=14]
setblock 473 251 537 minecraft:light[level=14]
setblock 473 251 545 minecraft:light[level=14]
setblock 481 251 513 minecraft:light[level=14]
setblock 481 251 521 minecraft:light[level=14]
setblock 481 251 529 minecraft:light[level=14]
setblock 481 251 537 minecraft:light[level=14]
setblock 481 251 545 minecraft:light[level=14]
setblock 489 251 513 minecraft:light[level=14]
setblock 489 251 521 minecraft:light[level=14]
setblock 489 251 529 minecraft:light[level=14]
setblock 489 251 537 minecraft:light[level=14]
setblock 489 251 545 minecraft:light[level=14]
setblock 497 251 513 minecraft:light[level=14]
setblock 497 251 521 minecraft:light[level=14]
setblock 497 251 529 minecraft:light[level=14]
setblock 497 251 537 minecraft:light[level=14]
setblock 497 251 545 minecraft:light[level=14]
setblock 505 251 513 minecraft:light[level=14]
setblock 505 251 521 minecraft:light[level=14]
setblock 505 251 529 minecraft:light[level=14]
setblock 505 251 537 minecraft:light[level=14]
setblock 505 251 545 minecraft:light[level=14]
fill 470 252 516 470 265 516 minecraft:white_concrete
fill 470 252 517 470 252 518 minecraft:pearlescent_froglight
fill 470 252 519 470 265 519 minecraft:white_concrete
fill 470 252 528 470 265 528 minecraft:white_concrete
fill 470 252 529 470 252 530 minecraft:pearlescent_froglight
fill 470 252 531 470 265 531 minecraft:white_concrete
fill 470 252 540 470 265 540 minecraft:white_concrete
fill 470 252 541 470 252 542 minecraft:pearlescent_froglight
fill 470 252 543 470 265 543 minecraft:white_concrete
fill 470 252 552 470 265 552 minecraft:white_concrete
fill 471 252 552 472 252 552 minecraft:pearlescent_froglight
fill 473 252 552 473 265 552 minecraft:white_concrete
fill 477 252 510 477 265 510 minecraft:white_concrete
fill 478 252 510 479 252 510 minecraft:pearlescent_froglight
fill 480 252 510 480 265 510 minecraft:white_concrete
fill 482 252 552 482 265 552 minecraft:white_concrete
fill 483 252 552 484 252 552 minecraft:pearlescent_froglight
fill 485 252 552 485 265 552 minecraft:white_concrete
fill 489 252 510 489 265 510 minecraft:white_concrete
fill 490 252 510 491 252 510 minecraft:pearlescent_froglight
fill 492 252 510 492 265 510 minecraft:white_concrete
fill 494 252 552 494 265 552 minecraft:white_concrete
fill 495 252 552 496 252 552 minecraft:pearlescent_froglight
fill 497 252 552 497 265 552 minecraft:white_concrete
fill 501 252 510 501 265 510 minecraft:white_concrete
fill 502 252 510 503 252 510 minecraft:pearlescent_froglight
fill 504 252 510 504 265 510 minecraft:white_concrete
fill 506 252 552 506 265 552 minecraft:white_concrete
fill 507 252 552 508 252 552 minecraft:pearlescent_froglight
fill 509 252 552 509 265 552 minecraft:white_concrete
fill 512 252 511 512 265 511 minecraft:white_concrete
fill 512 252 512 512 252 513 minecraft:pearlescent_froglight
fill 512 252 514 512 265 514 minecraft:white_concrete
fill 512 252 523 512 265 523 minecraft:white_concrete
fill 512 252 524 512 252 525 minecraft:pearlescent_froglight
fill 512 252 526 512 265 526 minecraft:white_concrete
fill 512 252 535 512 265 535 minecraft:white_concrete
fill 512 252 536 512 252 537 minecraft:pearlescent_froglight
fill 512 252 538 512 265 538 minecraft:white_concrete
fill 512 252 547 512 265 547 minecraft:white_concrete
fill 512 252 548 512 252 549 minecraft:pearlescent_froglight
fill 512 252 550 512 265 550 minecraft:white_concrete
fill 470 253 517 470 265 518 minecraft:white_concrete
fill 470 253 529 470 265 530 minecraft:white_concrete
fill 470 253 541 470 265 542 minecraft:white_concrete
fill 471 253 552 472 265 552 minecraft:white_concrete
fill 478 253 510 479 265 510 minecraft:white_concrete
fill 483 253 552 484 265 552 minecraft:white_concrete
fill 490 253 510 491 265 510 minecraft:white_concrete
fill 495 253 552 496 265 552 minecraft:white_concrete
fill 502 253 510 503 265 510 minecraft:white_concrete
fill 507 253 552 508 265 552 minecraft:white_concrete
fill 512 253 512 512 265 513 minecraft:white_concrete
fill 512 253 524 512 265 525 minecraft:white_concrete
fill 512 253 536 512 265 537 minecraft:white_concrete
fill 512 253 548 512 265 549 minecraft:white_concrete
fill 475 255 531 477 256 531 minecraft:gold_block
fill 476 255 530 476 256 530 minecraft:gold_block
fill 476 255 532 476 256 532 minecraft:gold_block
setblock 473 259 513 minecraft:light[level=14]
setblock 473 259 521 minecraft:light[level=14]
setblock 473 259 529 minecraft:light[level=14]
setblock 473 259 537 minecraft:light[level=14]
setblock 473 259 545 minecraft:light[level=14]
setblock 481 259 513 minecraft:light[level=14]
setblock 481 259 521 minecraft:light[level=14]
setblock 481 259 529 minecraft:light[level=14]
setblock 481 259 537 minecraft:light[level=14]
setblock 481 259 545 minecraft:light[level=14]
setblock 489 259 513 minecraft:light[level=14]
setblock 489 259 521 minecraft:light[level=14]
setblock 489 259 529 minecraft:light[level=14]
setblock 489 259 537 minecraft:light[level=14]
setblock 489 259 545 minecraft:light[level=14]
setblock 497 259 513 minecraft:light[level=14]
setblock 497 259 521 minecraft:light[level=14]
setblock 497 259 529 minecraft:light[level=14]
setblock 497 259 537 minecraft:light[level=14]
setblock 497 259 545 minecraft:light[level=14]
setblock 505 259 513 minecraft:light[level=14]
setblock 505 259 521 minecraft:light[level=14]
setblock 505 259 529 minecraft:light[level=14]
setblock 505 259 537 minecraft:light[level=14]
setblock 505 259 545 minecraft:light[level=14]
fill 472 260 520 472 265 522 minecraft:quartz_block
fill 472 260 532 472 265 534 minecraft:quartz_block
fill 472 260 544 472 265 546 minecraft:quartz_block
fill 478 260 550 480 265 550 minecraft:quartz_block
fill 482 260 512 484 265 512 minecraft:quartz_block
fill 482 260 529 483 261 529 minecraft:white_wool
fill 483 260 528 483 261 528 minecraft:white_wool
fill 483 260 530 483 261 530 minecraft:white_wool
fill 490 260 550 492 265 550 minecraft:quartz_block
fill 494 260 512 496 265 512 minecraft:quartz_block
fill 502 260 550 504 265 550 minecraft:quartz_block
fill 506 260 512 508 265 512 minecraft:quartz_block
fill 510 260 520 510 265 522 minecraft:quartz_block
fill 510 260 532 510 265 534 minecraft:quartz_block
fill 510 260 544 510 265 546 minecraft:quartz_block
fill 483 263 536 484 264 536 minecraft:gold_block
fill 471 265 514 471 265 519 minecraft:smooth_quartz
fill 471 265 526 471 265 531 minecraft:smooth_quartz
fill 471 265 538 471 265 543 minecraft:smooth_quartz
fill 471 265 550 471 265 551 minecraft:smooth_quartz
fill 472 265 551 475 265 551 minecraft:smooth_quartz
fill 475 265 511 480 265 511 minecraft:smooth_quartz
fill 482 265 551 487 265 551 minecraft:smooth_quartz
fill 487 265 511 492 265 511 minecraft:smooth_quartz
fill 494 265 551 499 265 551 minecraft:smooth_quartz
fill 499 265 511 504 265 511 minecraft:smooth_quartz
fill 506 265 551 511 265 551 minecraft:smooth_quartz
fill 511 265 511 511 265 516 minecraft:smooth_quartz
fill 511 265 523 511 265 528 minecraft:smooth_quartz
fill 511 265 535 511 265 540 minecraft:smooth_quartz
fill 511 265 547 511 265 550 minecraft:smooth_quartz
fill 470 266 516 470 271 519 minecraft:pearlescent_froglight
fill 470 266 528 470 271 531 minecraft:pearlescent_froglight
fill 470 266 540 470 271 543 minecraft:pearlescent_froglight
fill 470 266 552 473 271 552 minecraft:pearlescent_froglight
fill 477 266 510 480 271 510 minecraft:pearlescent_froglight
fill 482 266 552 485 271 552 minecraft:pearlescent_froglight
fill 489 266 510 492 271 510 minecraft:pearlescent_froglight
fill 494 266 552 497 271 552 minecraft:pearlescent_froglight
fill 501 266 510 504 271 510 minecraft:pearlescent_froglight
fill 506 266 552 509 271 552 minecraft:pearlescent_froglight
fill 512 266 511 512 271 514 minecraft:pearlescent_froglight
fill 512 266 523 512 271 526 minecraft:pearlescent_froglight
fill 512 266 535 512 271 538 minecraft:pearlescent_froglight
fill 512 266 547 512 271 550 minecraft:pearlescent_froglight
setblock 473 267 513 minecraft:light[level=14]
setblock 473 267 521 minecraft:light[level=14]
setblock 473 267 529 minecraft:light[level=14]
setblock 473 267 537 minecraft:light[level=14]
setblock 473 267 545 minecraft:light[level=14]
setblock 481 267 513 minecraft:light[level=14]
setblock 481 267 521 minecraft:light[level=14]
setblock 481 267 529 minecraft:light[level=14]
setblock 481 267 537 minecraft:light[level=14]
setblock 481 267 545 minecraft:light[level=14]
setblock 489 267 513 minecraft:light[level=14]
setblock 489 267 521 minecraft:light[level=14]
setblock 489 267 529 minecraft:light[level=14]
setblock 489 267 537 minecraft:light[level=14]
setblock 489 267 545 minecraft:light[level=14]
setblock 497 267 513 minecraft:light[level=14]
setblock 497 267 521 minecraft:light[level=14]
setblock 497 267 529 minecraft:light[level=14]
setblock 497 267 537 minecraft:light[level=14]
setblock 497 267 545 minecraft:light[level=14]
setblock 505 267 513 minecraft:light[level=14]
setblock 505 267 521 minecraft:light[level=14]
setblock 505 267 529 minecraft:light[level=14]
setblock 505 267 537 minecraft:light[level=14]
setblock 505 267 545 minecraft:light[level=14]
fill 470 272 516 470 285 516 minecraft:white_concrete
fill 470 272 517 470 272 518 minecraft:pearlescent_froglight
fill 470 272 519 470 285 519 minecraft:white_concrete
fill 470 272 528 470 285 528 minecraft:white_concrete
fill 470 272 529 470 272 530 minecraft:pearlescent_froglight
fill 470 272 531 470 285 531 minecraft:white_concrete
fill 470 272 540 470 285 540 minecraft:white_concrete
fill 470 272 541 470 272 542 minecraft:pearlescent_froglight
fill 470 272 543 470 285 543 minecraft:white_concrete
fill 470 272 552 470 285 552 minecraft:white_concrete
fill 471 272 552 472 272 552 minecraft:pearlescent_froglight
fill 473 272 552 473 285 552 minecraft:white_concrete
fill 477 272 510 477 285 510 minecraft:white_concrete
fill 478 272 510 479 272 510 minecraft:pearlescent_froglight
fill 480 272 510 480 285 510 minecraft:white_concrete
fill 482 272 552 482 285 552 minecraft:white_concrete
fill 483 272 552 484 272 552 minecraft:pearlescent_froglight
fill 485 272 552 485 285 552 minecraft:white_concrete
fill 489 272 510 489 285 510 minecraft:white_concrete
fill 490 272 510 491 272 510 minecraft:pearlescent_froglight
fill 492 272 510 492 285 510 minecraft:white_concrete
fill 494 272 552 494 285 552 minecraft:white_concrete
fill 495 272 552 496 272 552 minecraft:pearlescent_froglight
fill 497 272 552 497 285 552 minecraft:white_concrete
fill 501 272 510 501 285 510 minecraft:white_concrete
fill 502 272 510 503 272 510 minecraft:pearlescent_froglight
fill 504 272 510 504 285 510 minecraft:white_concrete
fill 506 272 552 506 285 552 minecraft:white_concrete
fill 507 272 552 508 272 552 minecraft:pearlescent_froglight
fill 509 272 552 509 285 552 minecraft:white_concrete
fill 512 272 511 512 285 511 minecraft:white_concrete
fill 512 272 512 512 272 513 minecraft:pearlescent_froglight
fill 512 272 514 512 285 514 minecraft:white_concrete
fill 512 272 523 512 285 523 minecraft:white_concrete
fill 512 272 524 512 272 525 minecraft:pearlescent_froglight
fill 512 272 526 512 285 526 minecraft:white_concrete
fill 512 272 535 512 285 535 minecraft:white_concrete
fill 512 272 536 512 272 537 minecraft:pearlescent_froglight
fill 512 272 538 512 285 538 minecraft:white_concrete
fill 512 272 547 512 285 547 minecraft:white_concrete
fill 512 272 548 512 272 549 minecraft:pearlescent_froglight
fill 512 272 550 512 285 550 minecraft:white_concrete
fill 470 273 517 470 285 518 minecraft:white_concrete
fill 470 273 529 470 285 530 minecraft:white_concrete
fill 470 273 541 470 285 542 minecraft:white_concrete
fill 471 273 552 472 285 552 minecraft:white_concrete
fill 478 273 510 479 285 510 minecraft:white_concrete
fill 483 273 552 484 285 552 minecraft:white_concrete
fill 490 273 510 491 285 510 minecraft:white_concrete
fill 495 273 552 496 285 552 minecraft:white_concrete
fill 502 273 510 503 285 510 minecraft:white_concrete
fill 507 273 552 508 285 552 minecraft:white_concrete
fill 512 273 512 512 285 513 minecraft:white_concrete
fill 512 273 524 512 285 525 minecraft:white_concrete
fill 512 273 536 512 285 537 minecraft:white_concrete
fill 512 273 548 512 285 549 minecraft:white_concrete
setblock 473 275 513 minecraft:light[level=14]
setblock 473 275 521 minecraft:light[level=14]
setblock 473 275 529 minecraft:light[level=14]
setblock 473 275 537 minecraft:light[level=14]
setblock 473 275 545 minecraft:light[level=14]
setblock 481 275 513 minecraft:light[level=14]
setblock 481 275 521 minecraft:light[level=14]
setblock 481 275 529 minecraft:light[level=14]
setblock 481 275 537 minecraft:light[level=14]
setblock 481 275 545 minecraft:light[level=14]
setblock 489 275 513 minecraft:light[level=14]
setblock 489 275 521 minecraft:light[level=14]
setblock 489 275 529 minecraft:light[level=14]
setblock 489 275 537 minecraft:light[level=14]
setblock 489 275 545 minecraft:light[level=14]
setblock 497 275 513 minecraft:light[level=14]
setblock 497 275 521 minecraft:light[level=14]
setblock 497 275 529 minecraft:light[level=14]
setblock 497 275 537 minecraft:light[level=14]
setblock 497 275 545 minecraft:light[level=14]
setblock 505 275 513 minecraft:light[level=14]
setblock 505 275 521 minecraft:light[level=14]
setblock 505 275 529 minecraft:light[level=14]
setblock 505 275 537 minecraft:light[level=14]
setblock 505 275 545 minecraft:light[level=14]
fill 481 279 525 481 281 531 minecraft:gold_block
fill 482 279 523 482 281 527 minecraft:gold_block
fill 482 279 528 489 279 528 minecraft:white_stained_glass
fill 482 279 529 482 281 533 minecraft:gold_block
fill 483 279 521 483 281 523 minecraft:gold_block
fill 483 279 524 490 279 527 minecraft:white_stained_glass
fill 483 279 529 490 279 532 minecraft:white_stained_glass
fill 483 279 533 483 281 535 minecraft:gold_block
fill 484 279 520 484 281 521 minecraft:gold_block
fill 484 279 522 500 280 523 minecraft:white_stained_glass
fill 484 279 533 500 280 534 minecraft:white_stained_glass
fill 484 279 535 484 281 536 minecraft:gold_block
fill 485 279 519 485 281 520 minecraft:gold_block
fill 485 279 521 499 280 521 minecraft:white_stained_glass
fill 485 279 535 499 280 535 minecraft:white_stained_glass
fill 485 279 536 485 281 537 minecraft:gold_block
fill 486 279 519 487 281 519 minecraft:gold_block
fill 486 279 520 498 280 520 minecraft:white_stained_glass
fill 486 279 536 498 280 536 minecraft:white_stained_glass
fill 486 279 537 487 281 537 minecraft:gold_block
fill 487 279 518 491 281 518 minecraft:gold_block
fill 487 279 538 491 281 538 minecraft:gold_block
fill 488 279 519 496 280 519 minecraft:white_stained_glass
fill 488 279 537 496 280 537 minecraft:white_stained_glass
fill 489 279 517 495 281 517 minecraft:gold_block
fill 489 279 539 495 281 539 minecraft:gold_block
fill 491 279 524 491 279 526 minecraft:white_stained_glass
fill 491 279 530 491 279 532 minecraft:white_stained_glass
fill 492 279 518 492 280 518 minecraft:white_stained_glass
fill 492 279 524 501 279 525 minecraft:white_stained_glass
fill 492 279 531 501 279 532 minecraft:white_stained_glass
fill 492 279 538 492 280 538 minecraft:white_stained_glass
fill 493 279 518 497 281 518 minecraft:gold_block
fill 493 279 526 501 279 526 minecraft:white_stained_glass
fill 493 279 530 501 279 530 minecraft:white_stained_glass
fill 493 279 538 497 281 538 minecraft:gold_block
fill 494 279 527 501 279 527 minecraft:white_stained_glass
fill 494 279 529 501 279 529 minecraft:white_stained_glass
fill 495 279 528 502 279 528 minecraft:white_stained_glass
fill 497 279 519 499 281 519 minecraft:gold_block
fill 497 279 537 499 281 537 minecraft:gold_block
fill 499 279 520 500 281 520 minecraft:gold_block
fill 499 279 536 500 281 536 minecraft:gold_block
fill 500 279 521 501 281 521 minecraft:gold_block
fill 500 279 535 501 281 535 minecraft:gold_block
fill 501 279 522 501 281 523 minecraft:gold_block
fill 501 279 533 501 281 534 minecraft:gold_block
fill 502 279 523 502 281 527 minecraft:gold_block
fill 502 279 529 502 281 533 minecraft:gold_block
fill 503 279 525 503 281 531 minecraft:gold_block
fill 471 280 511 480 280 551 minecraft:quartz_block
fill 481 280 511 481 280 523 minecraft:quartz_block
setblock 481 280 524 minecraft:gold_block
setblock 481 280 532 minecraft:gold_block
fill 481 280 533 481 280 551 minecraft:quartz_block
fill 482 280 511 482 280 521 minecraft:quartz_block
setblock 482 280 522 minecraft:gold_block
fill 482 280 528 488 280 528 minecraft:white_stained_glass
setblock 482 280 534 minecraft:gold_block
fill 482 280 535 482 280 551 minecraft:quartz_block
fill 483 280 511 483 280 520 minecraft:quartz_block
fill 483 280 524 488 280 527 minecraft:white_stained_glass
fill 483 280 529 488 280 532 minecraft:white_stained_glass
fill 483 280 536 483 280 551 minecraft:quartz_block
fill 484 280 511 484 280 519 minecraft:quartz_block
fill 484 280 537 484 280 551 minecraft:quartz_block
fill 485 280 511 485 280 518 minecraft:quartz_block
fill 485 280 538 485 280 551 minecraft:quartz_block
fill 486 280 511 487 280 517 minecraft:quartz_block
setblock 486 280 518 minecraft:gold_block
setblock 486 280 538 minecraft:gold_block
fill 486 280 539 487 280 551 minecraft:quartz_block
fill 488 280 511 511 280 516 minecraft:quartz_block
setblock 488 280 517 minecraft:gold_block
setblock 488 280 539 minecraft:gold_block
fill 488 280 540 511 280 551 minecraft:quartz_block
fill 489 280 524 489 280 526 minecraft:white_stained_glass
fill 489 280 527 489 280 529 minecraft:pearlescent_froglight
fill 489 280 530 489 280 532 minecraft:white_stained_glass
fill 490 280 524 490 280 525 minecraft:white_stained_glass
fill 490 280 526 490 280 527 minecraft:pearlescent_froglight
fill 490 280 529 490 280 530 minecraft:pearlescent_froglight
fill 490 280 531 490 280 532 minecraft:white_stained_glass
fill 491 280 524 501 280 524 minecraft:white_stained_glass
fill 491 280 525 491 280 526 minecraft:pearlescent_froglight
fill 491 280 530 491 280 531 minecraft:pearlescent_froglight
fill 491 280 532 501 280 532 minecraft:white_stained_glass
fill 492 280 525 493 280 525 minecraft:pearlescent_froglight
fill 492 280 531 493 280 531 minecraft:pearlescent_froglight
fill 493 280 526 494 280 526 minecraft:pearlescent_froglight
fill 493 280 530 494 280 530 minecraft:pearlescent_froglight
fill 494 280 525 501 280 525 minecraft:white_stained_glass
fill 494 280 527 495 280 527 minecraft:pearlescent_froglight
fill 494 280 529 495 280 529 minecraft:pearlescent_froglight
fill 494 280 531 501 280 531 minecraft:white_stained_glass
fill 495 280 526 501 280 526 minecraft:white_stained_glass
setblock 495 280 528 minecraft:pearlescent_froglight
fill 495 280 530 501 280 530 minecraft:white_stained_glass
setblock 496 280 517 minecraft:gold_block
fill 496 280 527 501 280 529 minecraft:white_stained_glass
setblock 496 280 539 minecraft:gold_block
fill 497 280 517 511 280 517 minecraft:quartz_block
fill 497 280 539 511 280 539 minecraft:quartz_block
setblock 498 280 518 minecraft:gold_block
setblock 498 280 538 minecraft:gold_block
fill 499 280 518 511 280 518 minecraft:quartz_block
fill 499 280 538 511 280 538 minecraft:quartz_block
fill 500 280 519 511 280 519 minecraft:quartz_block
fill 500 280 537 511 280 537 minecraft:quartz_block
fill 501 280 520 511 280 520 minecraft:quartz_block
fill 501 280 536 511 280 536 minecraft:quartz_block
fill 502 280 521 511 280 521 minecraft:quartz_block
setblock 502 280 522 minecraft:gold_block
setblock 502 280 528 minecraft:white_stained_glass
setblock 502 280 534 minecraft:gold_block
fill 502 280 535 511 280 535 minecraft:quartz_block
fill 503 280 522 511 280 523 minecraft:quartz_block
setblock 503 280 524 minecraft:gold_block
setblock 503 280 532 minecraft:gold_block
fill 503 280 533 511 280 534 minecraft:quartz_block
fill 504 280 524 511 280 532 minecraft:quartz_block
fill 482 281 528 483 281 528 minecraft:gold_block
fill 483 281 524 483 281 527 minecraft:gold_block
fill 483 281 529 483 281 532 minecraft:gold_block
fill 484 281 522 484 281 525 minecraft:gold_block
fill 484 281 531 484 281 534 minecraft:gold_block
fill 485 281 521 485 281 523 minecraft:gold_block
fill 485 281 533 485 281 535 minecraft:gold_block
fill 486 281 520 487 281 521 minecraft:gold_block
fill 486 281 535 487 281 536 minecraft:gold_block
fill 488 281 519 489 281 520 minecraft:gold_block
fill 488 281 536 489 281 537 minecraft:gold_block
fill 490 281 519 496 281 519 minecraft:gold_block
fill 490 281 537 496 281 537 minecraft:gold_block
setblock 492 281 518 minecraft:gold_block
setblock 492 281 538 minecraft:gold_block
fill 495 281 520 498 281 520 minecraft:gold_block
fill 495 281 536 498 281 536 minecraft:gold_block
fill 497 281 521 499 281 521 minecraft:gold_block
fill 497 281 535 499 281 535 minecraft:gold_block
fill 499 281 522 500 281 523 minecraft:gold_block
fill 499 281 533 500 281 534 minecraft:gold_block
fill 500 281 524 501 281 525 minecraft:gold_block
fill 500 281 531 501 281 532 minecraft:gold_block
fill 501 281 526 501 281 530 minecraft:gold_block
setblock 502 281 528 minecraft:gold_block
setblock 473 283 513 minecraft:light[level=14]
setblock 473 283 521 minecraft:light[level=14]
setblock 473 283 529 minecraft:light[level=14]
setblock 473 283 537 minecraft:light[level=14]
setblock 473 283 545 minecraft:light[level=14]
setblock 481 283 513 minecraft:light[level=14]
setblock 481 283 521 minecraft:light[level=14]
setblock 481 283 529 minecraft:light[level=14]
setblock 481 283 537 minecraft:light[level=14]
setblock 481 283 545 minecraft:light[level=14]
setblock 489 283 513 minecraft:light[level=14]
setblock 489 283 521 minecraft:light[level=14]
setblock 489 283 529 minecraft:light[level=14]
setblock 489 283 537 minecraft:light[level=14]
setblock 489 283 545 minecraft:light[level=14]
setblock 497 283 513 minecraft:light[level=14]
setblock 497 283 521 minecraft:light[level=14]
setblock 497 283 529 minecraft:light[level=14]
setblock 497 283 537 minecraft:light[level=14]
setblock 497 283 545 minecraft:light[level=14]
setblock 505 283 513 minecraft:light[level=14]
setblock 505 283 521 minecraft:light[level=14]
setblock 505 283 529 minecraft:light[level=14]
setblock 505 283 537 minecraft:light[level=14]
setblock 505 283 545 minecraft:light[level=14]
fill 471 284 511 473 300 511 minecraft:quartz_block
fill 471 284 521 471 300 523 minecraft:quartz_block
fill 471 284 533 471 300 535 minecraft:quartz_block
fill 471 284 545 471 300 547 minecraft:quartz_block
fill 472 284 520 472 285 522 minecraft:quartz_block
fill 472 284 532 472 285 534 minecraft:quartz_block
fill 472 284 544 472 285 546 minecraft:quartz_block
fill 473 284 546 473 284 548 minecraft:smooth_quartz
fill 474 284 545 477 284 545 minecraft:smooth_quartz
fill 474 284 546 476 300 548 minecraft:quartz_block
fill 474 284 549 476 284 549 minecraft:smooth_quartz
setblock 477 284 546 minecraft:smooth_quartz
fill 477 284 547 477 300 547 minecraft:quartz_block
setblock 477 284 548 minecraft:smooth_quartz
fill 477 284 551 479 300 551 minecraft:quartz_block
fill 478 284 550 480 285 550 minecraft:quartz_block
fill 482 284 512 484 285 512 minecraft:quartz_block
fill 483 284 511 485 300 511 minecraft:quartz_block
fill 489 284 551 491 300 551 minecraft:quartz_block
fill 490 284 550 492 285 550 minecraft:quartz_block
fill 494 284 512 496 285 512 minecraft:quartz_block
fill 495 284 511 497 300 511 minecraft:quartz_block
fill 501 284 551 503 300 551 minecraft:quartz_block
fill 502 284 550 504 285 550 minecraft:quartz_block
fill 506 284 512 508 285 512 minecraft:quartz_block
fill 507 284 511 509 300 511 minecraft:quartz_block
fill 510 284 520 510 285 522 minecraft:quartz_block
fill 510 284 532 510 285 534 minecraft:quartz_block
fill 510 284 544 510 285 546 minecraft:quartz_block
fill 511 284 519 511 300 521 minecraft:quartz_block
fill 511 284 531 511 300 533 minecraft:quartz_block
fill 511 284 543 511 300 545 minecraft:quartz_block
fill 471 285 514 471 285 519 minecraft:smooth_quartz
fill 471 285 526 471 285 531 minecraft:smooth_quartz
fill 471 285 538 471 285 543 minecraft:smooth_quartz
fill 471 285 550 471 285 551 minecraft:smooth_quartz
fill 472 285 551 475 285 551 minecraft:smooth_quartz
fill 475 285 511 480 285 511 minecraft:smooth_quartz
fill 482 285 551 487 285 551 minecraft:smooth_quartz
fill 487 285 511 492 285 511 minecraft:smooth_quartz
fill 494 285 551 499 285 551 minecraft:smooth_quartz
fill 499 285 511 504 285 511 minecraft:smooth_quartz
fill 506 285 551 511 285 551 minecraft:smooth_quartz
fill 511 285 511 511 285 516 minecraft:smooth_quartz
fill 511 285 523 511 285 528 minecraft:smooth_quartz
fill 511 285 535 511 285 540 minecraft:smooth_quartz
fill 511 285 547 511 285 550 minecraft:smooth_quartz
fill 470 286 516 470 291 519 minecraft:pearlescent_froglight
fill 470 286 528 470 291 531 minecraft:pearlescent_froglight
fill 470 286 540 470 291 543 minecraft:pearlescent_froglight
fill 470 286 552 473 291 552 minecraft:pearlescent_froglight
fill 477 286 510 480 291 510 minecraft:pearlescent_froglight
fill 482 286 552 485 291 552 minecraft:pearlescent_froglight
fill 489 286 510 492 291 510 minecraft:pearlescent_froglight
fill 494 286 552 497 291 552 minecraft:pearlescent_froglight
fill 501 286 510 504 291 510 minecraft:pearlescent_froglight
fill 506 286 552 509 291 552 minecraft:pearlescent_froglight
fill 512 286 511 512 291 514 minecraft:pearlescent_froglight
fill 512 286 523 512 291 526 minecraft:pearlescent_froglight
fill 512 286 535 512 291 538 minecraft:pearlescent_froglight
fill 512 286 547 512 291 550 minecraft:pearlescent_froglight
fill 505 289 518 505 290 519 minecraft:white_wool
setblock 473 291 513 minecraft:light[level=14]
setblock 473 291 521 minecraft:light[level=14]
setblock 473 291 529 minecraft:light[level=14]
setblock 473 291 537 minecraft:light[level=14]
setblock 473 291 545 minecraft:light[level=14]
setblock 481 291 513 minecraft:light[level=14]
setblock 481 291 521 minecraft:light[level=14]
setblock 481 291 529 minecraft:light[level=14]
setblock 481 291 537 minecraft:light[level=14]
setblock 481 291 545 minecraft:light[level=14]
setblock 489 291 513 minecraft:light[level=14]
setblock 489 291 521 minecraft:light[level=14]
setblock 489 291 529 minecraft:light[level=14]
setblock 489 291 537 minecraft:light[level=14]
setblock 489 291 545 minecraft:light[level=14]
setblock 497 291 513 minecraft:light[level=14]
setblock 497 291 521 minecraft:light[level=14]
setblock 497 291 529 minecraft:light[level=14]
setblock 497 291 537 minecraft:light[level=14]
setblock 497 291 545 minecraft:light[level=14]
setblock 505 291 513 minecraft:light[level=14]
setblock 505 291 521 minecraft:light[level=14]
setblock 505 291 529 minecraft:light[level=14]
setblock 505 291 537 minecraft:light[level=14]
setblock 505 291 545 minecraft:light[level=14]
fill 470 292 516 470 307 516 minecraft:white_concrete
fill 470 292 517 470 292 518 minecraft:pearlescent_froglight
fill 470 292 519 470 307 519 minecraft:white_concrete
fill 470 292 528 470 307 528 minecraft:white_concrete
fill 470 292 529 470 292 530 minecraft:pearlescent_froglight
fill 470 292 531 470 307 531 minecraft:white_concrete
fill 470 292 540 470 307 540 minecraft:white_concrete
fill 470 292 541 470 292 542 minecraft:pearlescent_froglight
fill 470 292 543 470 307 543 minecraft:white_concrete
fill 470 292 552 470 307 552 minecraft:white_concrete
fill 471 292 552 472 292 552 minecraft:pearlescent_froglight
fill 473 292 546 473 292 548 minecraft:smooth_quartz
fill 473 292 552 473 307 552 minecraft:white_concrete
fill 474 292 545 477 292 545 minecraft:smooth_quartz
fill 474 292 549 476 292 549 minecraft:smooth_quartz
fill 477 292 510 477 307 510 minecraft:white_concrete
setblock 477 292 546 minecraft:smooth_quartz
setblock 477 292 548 minecraft:smooth_quartz
fill 478 292 510 479 292 510 minecraft:pearlescent_froglight
fill 480 292 510 480 307 510 minecraft:white_concrete
fill 482 292 552 482 307 552 minecraft:white_concrete
fill 483 292 552 484 292 552 minecraft:pearlescent_froglight
fill 485 292 552 485 307 552 minecraft:white_concrete
fill 489 292 510 489 307 510 minecraft:white_concrete
fill 490 292 510 491 292 510 minecraft:pearlescent_froglight
fill 492 292 510 492 307 510 minecraft:white_concrete
fill 494 292 552 494 307 552 minecraft:white_concrete
fill 495 292 552 496 292 552 minecraft:pearlescent_froglight
fill 497 292 552 497 307 552 minecraft:white_concrete
fill 501 292 510 501 307 510 minecraft:white_concrete
fill 502 292 510 503 292 510 minecraft:pearlescent_froglight
fill 504 292 510 504 307 510 minecraft:white_concrete
fill 506 292 552 506 307 552 minecraft:white_concrete
fill 507 292 552 508 292 552 minecraft:pearlescent_froglight
fill 509 292 552 509 307 552 minecraft:white_concrete
fill 512 292 511 512 307 511 minecraft:white_concrete
fill 512 292 512 512 292 513 minecraft:pearlescent_froglight
fill 512 292 514 512 307 514 minecraft:white_concrete
fill 512 292 523 512 307 523 minecraft:white_concrete
fill 512 292 524 512 292 525 minecraft:pearlescent_froglight
fill 512 292 526 512 307 526 minecraft:white_concrete
fill 512 292 535 512 307 535 minecraft:white_concrete
fill 512 292 536 512 292 537 minecraft:pearlescent_froglight
fill 512 292 538 512 307 538 minecraft:white_concrete
fill 512 292 547 512 307 547 minecraft:white_concrete
fill 512 292 548 512 292 549 minecraft:pearlescent_froglight
fill 512 292 550 512 307 550 minecraft:white_concrete
fill 470 293 517 470 307 518 minecraft:white_concrete
fill 470 293 529 470 307 530 minecraft:white_concrete
fill 470 293 541 470 307 542 minecraft:white_concrete
fill 471 293 552 472 307 552 minecraft:white_concrete
fill 478 293 510 479 307 510 minecraft:white_concrete
fill 483 293 552 484 307 552 minecraft:white_concrete
fill 490 293 510 491 307 510 minecraft:white_concrete
fill 495 293 552 496 307 552 minecraft:white_concrete
fill 502 293 510 503 307 510 minecraft:white_concrete
fill 507 293 552 508 307 552 minecraft:white_concrete
fill 512 293 512 512 307 513 minecraft:white_concrete
fill 512 293 524 512 307 525 minecraft:white_concrete
fill 512 293 536 512 307 537 minecraft:white_concrete
fill 512 293 548 512 307 549 minecraft:white_concrete
setblock 473 299 513 minecraft:light[level=14]
setblock 473 299 521 minecraft:light[level=14]
setblock 473 299 529 minecraft:light[level=14]
setblock 473 299 537 minecraft:light[level=14]
setblock 473 299 545 minecraft:light[level=14]
fill 473 299 547 473 300 547 minecraft:gold_block
fill 474 299 545 476 300 545 minecraft:gold_block
fill 475 299 549 476 300 549 minecraft:gold_block
fill 477 299 546 477 300 546 minecraft:gold_block
fill 477 299 548 477 300 548 minecraft:gold_block
setblock 481 299 513 minecraft:light[level=14]
setblock 481 299 521 minecraft:light[level=14]
setblock 481 299 529 minecraft:light[level=14]
setblock 481 299 537 minecraft:light[level=14]
setblock 481 299 545 minecraft:light[level=14]
setblock 489 299 513 minecraft:light[level=14]
setblock 489 299 521 minecraft:light[level=14]
setblock 489 299 529 minecraft:light[level=14]
setblock 489 299 537 minecraft:light[level=14]
setblock 489 299 545 minecraft:light[level=14]
setblock 497 299 513 minecraft:light[level=14]
setblock 497 299 521 minecraft:light[level=14]
setblock 497 299 529 minecraft:light[level=14]
setblock 497 299 537 minecraft:light[level=14]
setblock 497 299 545 minecraft:light[level=14]
setblock 505 299 513 minecraft:light[level=14]
setblock 505 299 521 minecraft:light[level=14]
setblock 505 299 529 minecraft:light[level=14]
setblock 505 299 537 minecraft:light[level=14]
setblock 505 299 545 minecraft:light[level=14]
fill 472 300 520 472 300 522 minecraft:quartz_block
fill 472 300 532 472 300 534 minecraft:quartz_block
fill 472 300 544 472 300 546 minecraft:quartz_block
fill 478 300 550 480 300 550 minecraft:quartz_block
fill 482 300 512 484 300 512 minecraft:quartz_block
fill 490 300 550 492 300 550 minecraft:quartz_block
fill 494 300 512 496 300 512 minecraft:quartz_block
fill 502 300 550 504 300 550 minecraft:quartz_block
fill 506 300 512 508 300 512 minecraft:quartz_block
fill 510 300 520 510 300 522 minecraft:quartz_block
fill 510 300 532 510 300 534 minecraft:quartz_block
fill 510 300 544 510 300 546 minecraft:quartz_block
