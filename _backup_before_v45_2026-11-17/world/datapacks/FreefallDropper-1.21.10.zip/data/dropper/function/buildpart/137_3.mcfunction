fill 235 159 575 235 162 575 minecraft:orange_terracotta
setblock 235 159 580 minecraft:yellow_concrete
setblock 235 159 591 minecraft:yellow_concrete
fill 235 159 595 235 162 596 minecraft:orange_terracotta
setblock 237 159 557 minecraft:yellow_concrete
setblock 238 159 560 minecraft:light[level=14]
setblock 238 159 568 minecraft:light[level=14]
setblock 238 159 576 minecraft:light[level=14]
setblock 238 159 584 minecraft:light[level=14]
setblock 238 159 592 minecraft:light[level=14]
setblock 246 159 560 minecraft:light[level=14]
setblock 246 159 568 minecraft:light[level=14]
setblock 246 159 576 minecraft:light[level=14]
setblock 246 159 584 minecraft:light[level=14]
setblock 246 159 592 minecraft:light[level=14]
setblock 248 159 599 minecraft:yellow_concrete
setblock 251 159 599 minecraft:yellow_concrete
fill 252 159 599 252 162 599 minecraft:orange_terracotta
fill 253 159 557 253 162 557 minecraft:orange_terracotta
setblock 254 159 560 minecraft:light[level=14]
setblock 254 159 568 minecraft:light[level=14]
setblock 254 159 576 minecraft:light[level=14]
setblock 254 159 584 minecraft:light[level=14]
setblock 254 159 592 minecraft:light[level=14]
setblock 257 159 557 minecraft:yellow_concrete
setblock 259 159 599 minecraft:yellow_concrete
setblock 262 159 560 minecraft:light[level=14]
setblock 262 159 568 minecraft:light[level=14]
setblock 262 159 576 minecraft:light[level=14]
setblock 262 159 584 minecraft:light[level=14]
setblock 262 159 592 minecraft:light[level=14]
fill 263 159 599 263 162 599 minecraft:orange_terracotta
fill 264 159 557 264 162 557 minecraft:orange_terracotta
setblock 265 159 557 minecraft:yellow_concrete
setblock 268 159 557 minecraft:yellow_concrete
setblock 270 159 560 minecraft:light[level=14]
setblock 270 159 568 minecraft:light[level=14]
setblock 270 159 576 minecraft:light[level=14]
setblock 270 159 584 minecraft:light[level=14]
setblock 270 159 592 minecraft:light[level=14]
fill 277 159 564 277 162 565 minecraft:orange_terracotta
setblock 277 159 569 minecraft:yellow_concrete
setblock 277 159 580 minecraft:yellow_concrete
fill 277 159 585 277 162 585 minecraft:orange_terracotta
fill 277 159 596 277 162 596 minecraft:orange_terracotta
setblock 277 159 597 minecraft:yellow_concrete
fill 235 160 558 235 161 558 minecraft:yellow_concrete
fill 235 160 559 235 161 560 minecraft:orange_terracotta
fill 235 160 561 235 160 562 minecraft:yellow_concrete
fill 235 160 563 235 177 563 minecraft:orange_terracotta
fill 235 160 569 235 161 570 minecraft:yellow_concrete
fill 235 160 571 235 173 572 minecraft:orange_terracotta
fill 235 160 580 235 173 580 minecraft:orange_terracotta
fill 235 160 581 235 160 582 minecraft:yellow_concrete
fill 235 160 583 235 177 584 minecraft:orange_terracotta
fill 235 160 589 235 161 590 minecraft:yellow_concrete
fill 235 160 591 235 173 592 minecraft:orange_terracotta
setblock 235 160 593 minecraft:yellow_concrete
fill 236 160 557 237 173 557 minecraft:orange_terracotta
fill 237 160 599 238 161 599 minecraft:yellow_concrete
fill 238 160 557 239 161 557 minecraft:yellow_concrete
fill 239 160 599 240 173 599 minecraft:orange_terracotta
fill 242 160 574 242 161 576 minecraft:shroomlight
fill 243 160 575 243 161 575 minecraft:shroomlight
fill 244 160 557 245 173 557 minecraft:orange_terracotta
fill 246 160 557 247 160 557 minecraft:yellow_concrete
fill 246 160 599 246 161 599 minecraft:yellow_concrete
fill 248 160 599 248 173 599 minecraft:orange_terracotta
fill 249 160 599 250 160 599 minecraft:yellow_concrete
fill 251 160 599 251 177 599 minecraft:orange_terracotta
fill 256 160 557 257 173 557 minecraft:orange_terracotta
fill 257 160 599 258 161 599 minecraft:yellow_concrete
fill 258 160 557 259 161 557 minecraft:yellow_concrete
fill 259 160 599 260 173 599 minecraft:orange_terracotta
fill 265 160 557 265 177 557 minecraft:orange_terracotta
fill 266 160 557 267 160 557 minecraft:yellow_concrete
fill 268 160 557 268 173 557 minecraft:orange_terracotta
fill 269 160 599 270 160 599 minecraft:yellow_concrete
fill 270 160 557 270 161 557 minecraft:yellow_concrete
fill 271 160 599 272 173 599 minecraft:orange_terracotta
fill 276 160 557 277 173 557 minecraft:orange_terracotta
fill 277 160 558 277 161 559 minecraft:yellow_concrete
setblock 277 160 567 minecraft:yellow_concrete
fill 277 160 568 277 173 569 minecraft:orange_terracotta
fill 277 160 570 277 161 571 minecraft:yellow_concrete
fill 277 160 576 277 177 577 minecraft:orange_terracotta
fill 277 160 578 277 160 579 minecraft:yellow_concrete
fill 277 160 580 277 173 580 minecraft:orange_terracotta
fill 277 160 588 277 173 589 minecraft:orange_terracotta
fill 277 160 590 277 161 591 minecraft:yellow_concrete
fill 277 160 597 277 177 597 minecraft:orange_terracotta
setblock 235 161 557 minecraft:yellow_concrete
fill 235 161 561 235 179 562 minecraft:orange_terracotta
fill 235 161 577 235 161 578 minecraft:yellow_concrete
setblock 235 161 581 minecraft:yellow_concrete
fill 235 161 582 235 179 582 minecraft:orange_terracotta
fill 235 161 593 235 179 593 minecraft:orange_terracotta
setblock 235 161 598 minecraft:yellow_concrete
setblock 245 161 599 minecraft:yellow_concrete
fill 246 161 557 246 179 557 minecraft:orange_terracotta
setblock 247 161 557 minecraft:yellow_concrete
fill 249 161 599 250 179 599 minecraft:orange_terracotta
setblock 250 161 557 minecraft:yellow_concrete
fill 256 161 560 256 162 561 minecraft:shroomlight
fill 266 161 557 267 179 557 minecraft:orange_terracotta
setblock 266 161 599 minecraft:yellow_concrete
setblock 269 161 599 minecraft:yellow_concrete
fill 270 161 580 271 162 581 minecraft:yellow_concrete
fill 270 161 599 270 179 599 minecraft:orange_terracotta
setblock 271 161 557 minecraft:yellow_concrete
fill 271 161 579 271 162 579 minecraft:yellow_concrete
setblock 277 161 562 minecraft:yellow_concrete
fill 277 161 567 277 179 567 minecraft:orange_terracotta
fill 277 161 578 277 179 578 minecraft:orange_terracotta
setblock 277 161 579 minecraft:yellow_concrete
fill 277 161 582 277 161 583 minecraft:yellow_concrete
setblock 277 161 599 minecraft:yellow_concrete
fill 235 162 557 235 175 558 minecraft:orange_terracotta
setblock 235 162 559 minecraft:yellow_concrete
fill 235 162 560 235 173 560 minecraft:orange_terracotta
fill 235 162 567 235 162 568 minecraft:yellow_concrete
fill 235 162 569 235 175 570 minecraft:orange_terracotta
fill 235 162 576 235 163 576 minecraft:yellow_concrete
fill 235 162 577 235 175 578 minecraft:orange_terracotta
setblock 235 162 579 minecraft:yellow_concrete
fill 235 162 581 235 179 581 minecraft:orange_terracotta
fill 235 162 587 235 163 588 minecraft:yellow_concrete
fill 235 162 589 235 175 590 minecraft:orange_terracotta
fill 235 162 598 235 175 598 minecraft:orange_terracotta
fill 235 162 599 236 162 599 minecraft:yellow_concrete
fill 236 162 558 238 162 558 minecraft:orange_concrete
fill 236 162 560 236 162 562 minecraft:orange_concrete
fill 236 162 564 236 162 566 minecraft:orange_concrete
fill 236 162 568 236 162 570 minecraft:orange_concrete
fill 236 162 572 236 162 574 minecraft:orange_concrete
fill 236 162 576 236 162 578 minecraft:orange_concrete
fill 236 162 580 236 162 582 minecraft:orange_concrete
fill 236 162 584 236 162 586 minecraft:orange_concrete
fill 236 162 588 236 162 590 minecraft:orange_concrete
fill 236 162 592 236 162 594 minecraft:orange_concrete
fill 236 162 596 236 162 598 minecraft:orange_concrete
fill 237 162 599 238 179 599 minecraft:orange_terracotta
fill 238 162 557 239 175 557 minecraft:orange_terracotta
fill 238 162 598 240 162 598 minecraft:orange_concrete
fill 240 162 557 241 163 557 minecraft:yellow_concrete
fill 240 162 558 242 162 558 minecraft:orange_concrete
fill 242 162 598 244 162 598 minecraft:orange_concrete
fill 243 162 599 244 163 599 minecraft:yellow_concrete
fill 244 162 558 246 162 558 minecraft:orange_concrete
fill 245 162 599 246 175 599 minecraft:orange_terracotta
fill 246 162 598 248 162 598 minecraft:orange_concrete
fill 247 162 557 247 179 557 minecraft:orange_terracotta
setblock 247 162 599 minecraft:yellow_concrete
fill 248 162 557 249 162 557 minecraft:yellow_concrete
fill 248 162 558 250 162 558 minecraft:orange_concrete
fill 250 162 557 250 175 557 minecraft:orange_terracotta
fill 250 162 598 252 162 598 minecraft:orange_concrete
fill 252 162 557 252 163 557 minecraft:yellow_concrete
fill 252 162 558 254 162 558 minecraft:orange_concrete
fill 254 162 598 256 162 598 minecraft:orange_concrete
fill 255 162 599 256 163 599 minecraft:yellow_concrete
fill 256 162 558 258 162 558 minecraft:orange_concrete
fill 257 162 599 258 175 599 minecraft:orange_terracotta
fill 258 162 557 259 175 557 minecraft:orange_terracotta
fill 258 162 598 260 162 598 minecraft:orange_concrete
fill 260 162 557 261 163 557 minecraft:yellow_concrete
fill 260 162 558 262 162 558 minecraft:orange_concrete
fill 262 162 598 264 162 598 minecraft:orange_concrete
fill 264 162 558 266 162 558 minecraft:orange_concrete
fill 264 162 599 264 163 599 minecraft:yellow_concrete
fill 266 162 598 268 162 598 minecraft:orange_concrete
fill 266 162 599 266 175 599 minecraft:orange_terracotta
fill 267 162 599 268 162 599 minecraft:yellow_concrete
fill 268 162 558 270 162 558 minecraft:orange_concrete
setblock 269 162 557 minecraft:yellow_concrete
fill 269 162 599 269 179 599 minecraft:orange_terracotta
fill 270 162 557 271 175 557 minecraft:orange_terracotta
fill 270 162 598 272 162 598 minecraft:orange_concrete
fill 272 162 557 273 163 557 minecraft:yellow_concrete
fill 272 162 558 274 162 558 minecraft:orange_concrete
fill 274 162 598 276 162 598 minecraft:orange_concrete
fill 275 162 599 276 163 599 minecraft:yellow_concrete
fill 276 162 558 276 162 560 minecraft:orange_concrete
fill 276 162 562 276 162 564 minecraft:orange_concrete
fill 276 162 566 276 162 568 minecraft:orange_concrete
fill 276 162 570 276 162 572 minecraft:orange_concrete
fill 276 162 574 276 162 576 minecraft:orange_concrete
fill 276 162 578 276 162 580 minecraft:orange_concrete
fill 276 162 582 276 162 584 minecraft:orange_concrete
fill 276 162 586 276 162 588 minecraft:orange_concrete
fill 276 162 590 276 162 592 minecraft:orange_concrete
fill 276 162 594 276 162 596 minecraft:orange_concrete
fill 277 162 558 277 179 559 minecraft:orange_terracotta
fill 277 162 560 277 162 561 minecraft:yellow_concrete
fill 277 162 562 277 175 562 minecraft:orange_terracotta
fill 277 162 570 277 175 571 minecraft:orange_terracotta
fill 277 162 572 277 163 573 minecraft:yellow_concrete
fill 277 162 579 277 179 579 minecraft:orange_terracotta
setblock 277 162 581 minecraft:yellow_concrete
fill 277 162 582 277 175 583 minecraft:orange_terracotta
fill 277 162 584 277 163 584 minecraft:yellow_concrete
fill 277 162 590 277 175 591 minecraft:orange_terracotta
fill 277 162 592 277 162 593 minecraft:yellow_concrete
fill 277 162 599 277 175 599 minecraft:orange_terracotta
fill 235 163 559 235 173 559 minecraft:orange_terracotta
setblock 235 163 564 minecraft:yellow_concrete
setblock 235 163 567 minecraft:yellow_concrete
fill 235 163 568 235 173 568 minecraft:orange_terracotta
setblock 235 163 575 minecraft:yellow_concrete
fill 235 163 579 235 173 579 minecraft:orange_terracotta
fill 235 163 595 235 163 596 minecraft:yellow_concrete
setblock 235 163 599 minecraft:yellow_concrete
fill 236 163 599 236 173 599 minecraft:orange_terracotta
fill 247 163 599 247 173 599 minecraft:orange_terracotta
fill 248 163 557 249 173 557 minecraft:orange_terracotta
setblock 252 163 599 minecraft:yellow_concrete
setblock 253 163 557 minecraft:yellow_concrete
setblock 263 163 599 minecraft:yellow_concrete
setblock 264 163 557 minecraft:yellow_concrete
fill 267 163 599 268 173 599 minecraft:orange_terracotta
fill 269 163 557 269 173 557 minecraft:orange_terracotta
fill 277 163 560 277 173 560 minecraft:orange_terracotta
setblock 277 163 561 minecraft:yellow_concrete
fill 277 163 564 277 163 565 minecraft:yellow_concrete
fill 277 163 581 277 173 581 minecraft:orange_terracotta
setblock 277 163 585 minecraft:yellow_concrete
fill 277 163 592 277 173 592 minecraft:orange_terracotta
setblock 277 163 593 minecraft:yellow_concrete
setblock 277 163 596 minecraft:yellow_concrete
fill 235 164 564 235 177 564 minecraft:orange_terracotta
fill 235 164 567 235 174 567 minecraft:orange_terracotta
fill 235 164 575 235 177 576 minecraft:orange_terracotta
fill 235 164 587 235 174 588 minecraft:orange_terracotta
fill 235 164 595 235 177 596 minecraft:orange_terracotta
fill 235 164 599 235 174 599 minecraft:orange_terracotta
fill 240 164 557 241 174 557 minecraft:orange_terracotta
fill 243 164 599 244 177 599 minecraft:orange_terracotta
fill 252 164 557 253 177 557 minecraft:orange_terracotta
fill 252 164 599 252 177 599 minecraft:orange_terracotta
setblock 253 164 578 minecraft:yellow_concrete
fill 254 164 577 256 164 577 minecraft:yellow_concrete
fill 255 164 580 256 164 580 minecraft:yellow_concrete
fill 255 164 599 256 174 599 minecraft:orange_terracotta
fill 256 164 578 257 164 579 minecraft:yellow_concrete
fill 260 164 557 261 173 557 minecraft:orange_terracotta
fill 263 164 599 264 177 599 minecraft:orange_terracotta
fill 264 164 557 264 177 557 minecraft:orange_terracotta
fill 272 164 557 273 177 557 minecraft:orange_terracotta
fill 275 164 599 276 174 599 minecraft:orange_terracotta
fill 277 164 561 277 174 561 minecraft:orange_terracotta
fill 277 164 564 277 177 565 minecraft:orange_terracotta
fill 277 164 572 277 174 573 minecraft:orange_terracotta
fill 277 164 584 277 177 585 minecraft:orange_terracotta
fill 277 164 593 277 174 593 minecraft:orange_terracotta
fill 277 164 596 277 177 596 minecraft:orange_terracotta
fill 252 165 576 252 165 581 minecraft:yellow_concrete
fill 253 165 576 253 165 577 minecraft:yellow_concrete
fill 253 165 578 253 167 578 minecraft:shroomlight
fill 253 165 580 253 165 581 minecraft:yellow_concrete
fill 254 165 575 256 165 576 minecraft:yellow_concrete
fill 254 165 577 256 174 577 minecraft:shroomlight
fill 254 165 581 256 165 582 minecraft:yellow_concrete
fill 255 165 578 257 167 578 minecraft:shroomlight
fill 255 165 580 256 167 580 minecraft:shroomlight
fill 256 165 579 257 174 579 minecraft:shroomlight
fill 257 165 576 258 165 577 minecraft:yellow_concrete
fill 257 165 580 258 165 581 minecraft:yellow_concrete
fill 258 165 578 258 165 579 minecraft:yellow_concrete
fill 251 166 576 251 166 581 minecraft:yellow_concrete
fill 252 166 575 253 166 575 minecraft:yellow_concrete
fill 252 166 576 252 167 581 minecraft:shroomlight
fill 252 166 582 253 166 582 minecraft:yellow_concrete
fill 253 166 576 253 173 577 minecraft:shroomlight
fill 253 166 580 253 166 581 minecraft:shroomlight
fill 254 166 574 256 167 574 minecraft:yellow_concrete
fill 254 166 575 256 173 576 minecraft:shroomlight
fill 254 166 581 256 173 582 minecraft:shroomlight
fill 254 166 583 256 167 583 minecraft:yellow_concrete
fill 257 166 575 258 166 575 minecraft:yellow_concrete
fill 257 166 576 258 173 577 minecraft:shroomlight
fill 257 166 580 258 167 581 minecraft:shroomlight
fill 257 166 582 258 166 582 minecraft:yellow_concrete
fill 258 166 578 258 167 579 minecraft:shroomlight
fill 259 166 576 259 166 581 minecraft:yellow_concrete
setblock 238 167 560 minecraft:light[level=14]
setblock 238 167 568 minecraft:light[level=14]
setblock 238 167 576 minecraft:light[level=14]
setblock 238 167 584 minecraft:light[level=14]
setblock 238 167 592 minecraft:light[level=14]
setblock 246 167 560 minecraft:light[level=14]
setblock 246 167 568 minecraft:light[level=14]
setblock 246 167 576 minecraft:light[level=14]
setblock 246 167 584 minecraft:light[level=14]
setblock 246 167 592 minecraft:light[level=14]
fill 250 167 577 250 167 580 minecraft:yellow_concrete
fill 251 167 575 251 167 576 minecraft:yellow_concrete
fill 251 167 577 251 172 580 minecraft:shroomlight
fill 251 167 581 251 167 582 minecraft:yellow_concrete
fill 252 167 574 253 167 574 minecraft:yellow_concrete
fill 252 167 575 253 167 575 minecraft:shroomlight
fill 252 167 582 253 172 582 minecraft:shroomlight
fill 252 167 583 253 167 583 minecraft:yellow_concrete
fill 253 167 581 253 173 581 minecraft:shroomlight
setblock 254 167 560 minecraft:light[level=14]
setblock 254 167 568 minecraft:light[level=14]
setblock 254 167 584 minecraft:light[level=14]
setblock 254 167 592 minecraft:light[level=14]
fill 257 167 574 258 168 574 minecraft:yellow_concrete
fill 257 167 575 258 172 575 minecraft:shroomlight
fill 257 167 582 258 172 582 minecraft:shroomlight
fill 257 167 583 258 168 583 minecraft:yellow_concrete
fill 259 167 575 259 167 576 minecraft:yellow_concrete
fill 259 167 577 259 167 580 minecraft:shroomlight
fill 259 167 581 259 167 582 minecraft:yellow_concrete
fill 260 167 577 260 167 580 minecraft:yellow_concrete
setblock 262 167 560 minecraft:light[level=14]
setblock 262 167 568 minecraft:light[level=14]
setblock 262 167 576 minecraft:light[level=14]
setblock 262 167 584 minecraft:light[level=14]
setblock 262 167 592 minecraft:light[level=14]
setblock 270 167 560 minecraft:light[level=14]
setblock 270 167 568 minecraft:light[level=14]
setblock 270 167 576 minecraft:light[level=14]
setblock 270 167 584 minecraft:light[level=14]
setblock 270 167 592 minecraft:light[level=14]
fill 248 168 579 250 168 581 minecraft:redstone_block
fill 250 168 574 252 168 576 minecraft:redstone_block
fill 250 168 577 250 169 578 minecraft:yellow_concrete
fill 251 168 581 252 171 581 minecraft:shroomlight
fill 251 168 582 251 169 582 minecraft:yellow_concrete
fill 252 168 577 252 173 580 minecraft:shroomlight
fill 252 168 583 252 169 583 minecraft:yellow_concrete
setblock 253 168 574 minecraft:yellow_concrete
fill 253 168 575 253 172 575 minecraft:shroomlight
fill 253 168 583 255 168 585 minecraft:redstone_block
fill 254 168 573 256 171 573 minecraft:yellow_concrete
fill 254 168 574 256 171 574 minecraft:shroomlight
fill 256 168 578 257 174 578 minecraft:shroomlight
fill 256 168 580 257 173 580 minecraft:shroomlight
fill 256 168 583 256 171 583 minecraft:shroomlight
fill 256 168 584 256 169 584 minecraft:yellow_concrete
fill 257 168 581 259 171 581 minecraft:shroomlight
fill 258 168 578 260 168 580 minecraft:redstone_block
fill 259 168 575 259 172 575 minecraft:yellow_concrete
fill 259 168 576 259 171 577 minecraft:shroomlight
fill 259 168 582 259 172 582 minecraft:yellow_concrete
fill 260 168 576 260 169 577 minecraft:yellow_concrete
fill 260 168 581 260 169 581 minecraft:yellow_concrete
setblock 253 169 573 minecraft:yellow_concrete
fill 253 169 574 253 170 574 minecraft:shroomlight
fill 257 169 573 257 170 573 minecraft:yellow_concrete
fill 257 169 574 257 170 574 minecraft:shroomlight
fill 257 169 583 257 170 583 minecraft:shroomlight
fill 257 169 584 257 170 584 minecraft:yellow_concrete
fill 258 169 574 258 172 574 minecraft:yellow_concrete
fill 258 169 583 258 172 583 minecraft:yellow_concrete
fill 236 170 558 246 170 598 minecraft:red_nether_bricks
fill 247 170 558 248 170 577 minecraft:red_nether_bricks
fill 247 170 578 247 170 582 minecraft:shroomlight
fill 247 170 583 251 170 598 minecraft:red_nether_bricks
fill 248 170 578 250 170 578 minecraft:shroomlight
fill 248 170 579 250 170 581 minecraft:red_nether_bricks
fill 248 170 582 251 170 582 minecraft:shroomlight
fill 249 170 558 276 170 572 minecraft:red_nether_bricks
fill 249 170 573 249 170 577 minecraft:shroomlight
fill 250 170 573 253 170 573 minecraft:shroomlight
fill 250 170 574 252 170 576 minecraft:red_nether_bricks
setblock 250 170 577 minecraft:shroomlight
fill 252 170 583 252 170 586 minecraft:shroomlight
fill 252 170 587 276 170 598 minecraft:red_nether_bricks
fill 253 170 583 255 170 585 minecraft:red_nether_bricks
fill 253 170 586 256 170 586 minecraft:shroomlight
fill 256 170 584 256 170 585 minecraft:shroomlight
fill 257 170 585 276 170 586 minecraft:red_nether_bricks
fill 258 170 573 276 170 573 minecraft:red_nether_bricks
fill 258 170 578 260 170 580 minecraft:red_nether_bricks
fill 258 170 584 276 170 584 minecraft:red_nether_bricks
fill 259 170 574 276 170 574 minecraft:red_nether_bricks
fill 259 170 583 276 170 583 minecraft:red_nether_bricks
fill 260 170 575 276 170 575 minecraft:red_nether_bricks
fill 260 170 576 260 171 576 minecraft:yellow_concrete
fill 260 170 577 261 170 577 minecraft:shroomlight
fill 260 170 581 261 170 581 minecraft:shroomlight
fill 260 170 582 276 170 582 minecraft:red_nether_bricks
fill 261 170 576 276 170 576 minecraft:red_nether_bricks
fill 261 170 578 261 170 580 minecraft:shroomlight
fill 262 170 577 276 170 581 minecraft:red_nether_bricks
fill 250 171 576 250 171 581 minecraft:yellow_concrete
fill 251 171 575 251 172 575 minecraft:yellow_concrete
fill 251 171 576 252 171 576 minecraft:shroomlight
fill 251 171 582 251 172 582 minecraft:yellow_concrete
fill 252 171 574 253 172 574 minecraft:yellow_concrete
fill 252 171 575 252 172 575 minecraft:shroomlight
fill 252 171 583 253 172 583 minecraft:yellow_concrete
fill 254 171 583 255 171 583 minecraft:shroomlight
fill 254 171 584 256 171 584 minecraft:yellow_concrete
fill 257 171 574 257 172 574 minecraft:yellow_concrete
fill 257 171 583 257 172 583 minecraft:yellow_concrete
fill 258 171 578 259 172 580 minecraft:shroomlight
fill 260 171 577 260 171 581 minecraft:yellow_concrete
fill 250 172 577 250 172 580 minecraft:yellow_concrete
fill 251 172 576 251 173 576 minecraft:yellow_concrete
fill 251 172 581 251 173 581 minecraft:yellow_concrete
fill 252 172 576 252 173 576 minecraft:shroomlight
fill 252 172 581 252 173 581 minecraft:shroomlight
fill 254 172 574 256 173 574 minecraft:yellow_concrete
fill 254 172 583 256 173 583 minecraft:yellow_concrete
fill 257 172 581 258 173 581 minecraft:shroomlight
fill 259 172 576 259 173 576 minecraft:yellow_concrete
setblock 259 172 577 minecraft:shroomlight
fill 259 172 581 259 173 581 minecraft:yellow_concrete
fill 260 172 577 260 172 580 minecraft:yellow_concrete
fill 251 173 577 251 173 580 minecraft:yellow_concrete
fill 252 173 575 253 173 575 minecraft:yellow_concrete
fill 252 173 582 253 173 582 minecraft:yellow_concrete
fill 253 173 578 253 174 578 minecraft:shroomlight
fill 255 173 578 255 174 578 minecraft:shroomlight
fill 255 173 580 255 174 580 minecraft:shroomlight
fill 257 173 575 258 173 575 minecraft:yellow_concrete
fill 257 173 582 258 173 582 minecraft:yellow_concrete
fill 258 173 578 258 173 580 minecraft:shroomlight
fill 259 173 577 259 173 580 minecraft:yellow_concrete
fill 235 174 559 235 175 560 minecraft:yellow_concrete
fill 235 174 568 235 175 568 minecraft:yellow_concrete
fill 235 174 571 235 174 572 minecraft:yellow_concrete
fill 235 174 579 235 175 580 minecraft:yellow_concrete
fill 235 174 591 235 174 592 minecraft:yellow_concrete
fill 236 174 557 237 175 557 minecraft:yellow_concrete
fill 236 174 558 238 174 558 minecraft:orange_concrete
fill 236 174 560 236 174 562 minecraft:orange_concrete
fill 236 174 564 236 174 566 minecraft:orange_concrete
fill 236 174 568 236 174 570 minecraft:orange_concrete
fill 236 174 572 236 174 574 minecraft:orange_concrete
fill 236 174 576 236 174 578 minecraft:orange_concrete
fill 236 174 580 236 174 582 minecraft:orange_concrete
fill 236 174 584 236 174 586 minecraft:orange_concrete
fill 236 174 588 236 174 590 minecraft:orange_concrete
fill 236 174 592 236 174 594 minecraft:orange_concrete
fill 236 174 596 236 174 598 minecraft:orange_concrete
fill 236 174 599 236 175 599 minecraft:yellow_concrete
fill 238 174 598 240 174 598 minecraft:orange_concrete
setblock 239 174 599 minecraft:yellow_concrete
fill 240 174 558 242 174 558 minecraft:orange_concrete
fill 240 174 599 240 177 599 minecraft:orange_terracotta
fill 242 174 598 244 174 598 minecraft:orange_concrete
fill 243 174 576 243 177 582 minecraft:iron_block
fill 244 174 557 244 177 557 minecraft:orange_terracotta
fill 244 174 558 246 174 558 minecraft:orange_concrete
fill 244 174 574 244 177 575 minecraft:iron_block
fill 244 174 583 244 177 584 minecraft:iron_block
setblock 245 174 557 minecraft:yellow_concrete
fill 245 174 572 245 177 573 minecraft:iron_block
fill 245 174 585 245 177 586 minecraft:iron_block
fill 246 174 571 246 174 572 minecraft:iron_block
fill 246 174 586 246 174 587 minecraft:iron_block
fill 246 174 598 248 174 598 minecraft:orange_concrete
fill 247 174 570 247 177 571 minecraft:iron_block
fill 247 174 587 247 177 588 minecraft:iron_block
fill 247 174 599 248 175 599 minecraft:yellow_concrete
fill 248 174 557 249 175 557 minecraft:yellow_concrete
fill 248 174 558 250 174 558 minecraft:orange_concrete
fill 248 174 570 248 177 570 minecraft:iron_block
fill 248 174 588 248 177 588 minecraft:iron_block
fill 249 174 569 250 177 569 minecraft:iron_block
fill 249 174 589 250 177 589 minecraft:iron_block
fill 250 174 598 252 174 598 minecraft:orange_concrete
fill 251 174 568 257 177 568 minecraft:iron_block
fill 251 174 590 257 177 590 minecraft:iron_block
fill 252 174 558 254 174 558 minecraft:orange_concrete
fill 252 174 576 252 174 581 minecraft:yellow_concrete
fill 253 174 576 253 174 577 minecraft:yellow_concrete
fill 253 174 581 258 174 581 minecraft:yellow_concrete
fill 254 174 575 256 174 576 minecraft:yellow_concrete
fill 254 174 582 256 174 582 minecraft:yellow_concrete
fill 254 174 598 256 174 598 minecraft:orange_concrete
fill 256 174 557 257 174 557 minecraft:yellow_concrete
fill 256 174 558 258 174 558 minecraft:orange_concrete
setblock 256 174 580 minecraft:shroomlight
fill 257 174 576 258 174 577 minecraft:yellow_concrete
fill 257 174 580 258 174 580 minecraft:yellow_concrete
fill 258 174 569 259 177 569 minecraft:iron_block
fill 258 174 578 258 174 579 minecraft:yellow_concrete
fill 258 174 589 259 177 589 minecraft:iron_block
fill 258 174 598 260 174 598 minecraft:orange_concrete
fill 259 174 599 260 174 599 minecraft:yellow_concrete
fill 260 174 557 260 175 557 minecraft:yellow_concrete
fill 260 174 558 262 174 558 minecraft:orange_concrete
fill 260 174 570 261 177 570 minecraft:iron_block
fill 260 174 588 261 177 588 minecraft:iron_block
setblock 261 174 557 minecraft:orange_terracotta
fill 261 174 571 262 174 571 minecraft:iron_block
fill 261 174 587 262 174 587 minecraft:iron_block
fill 262 174 572 263 177 572 minecraft:iron_block
fill 262 174 586 263 177 586 minecraft:iron_block
fill 262 174 598 264 174 598 minecraft:orange_concrete
fill 263 174 573 263 177 573 minecraft:iron_block
fill 263 174 585 263 177 585 minecraft:iron_block
fill 264 174 558 266 174 558 minecraft:orange_concrete
fill 264 174 574 264 177 575 minecraft:iron_block
fill 264 174 583 264 177 584 minecraft:iron_block
fill 265 174 576 265 177 582 minecraft:iron_block
fill 266 174 598 268 174 598 minecraft:orange_concrete
fill 267 174 599 268 175 599 minecraft:yellow_concrete
fill 268 174 557 269 175 557 minecraft:yellow_concrete
fill 268 174 558 270 174 558 minecraft:orange_concrete
fill 270 174 598 272 174 598 minecraft:orange_concrete
setblock 271 174 599 minecraft:yellow_concrete
fill 272 174 558 274 174 558 minecraft:orange_concrete
fill 272 174 599 272 177 599 minecraft:orange_terracotta
fill 274 174 598 276 174 598 minecraft:orange_concrete
fill 276 174 557 276 177 557 minecraft:orange_terracotta
fill 276 174 558 276 174 560 minecraft:orange_concrete
fill 276 174 562 276 174 564 minecraft:orange_concrete
fill 276 174 566 276 174 568 minecraft:orange_concrete
fill 276 174 570 276 174 572 minecraft:orange_concrete
fill 276 174 574 276 174 576 minecraft:orange_concrete
fill 276 174 578 276 174 580 minecraft:orange_concrete
fill 276 174 582 276 174 584 minecraft:orange_concrete
fill 276 174 586 276 174 588 minecraft:orange_concrete
fill 276 174 590 276 174 592 minecraft:orange_concrete
fill 276 174 594 276 174 596 minecraft:orange_concrete
setblock 277 174 557 minecraft:yellow_concrete
fill 277 174 560 277 175 560 minecraft:yellow_concrete
fill 277 174 568 277 174 569 minecraft:yellow_concrete
fill 277 174 580 277 175 581 minecraft:yellow_concrete
fill 277 174 588 277 174 589 minecraft:yellow_concrete
fill 277 174 592 277 175 592 minecraft:yellow_concrete
setblock 235 175 567 minecraft:yellow_concrete
fill 235 175 571 235 178 572 minecraft:orange_terracotta
fill 235 175 587 235 177 587 minecraft:orange_terracotta
setblock 235 175 588 minecraft:yellow_concrete
setblock 235 175 591 minecraft:yellow_concrete
fill 235 175 592 235 178 592 minecraft:orange_terracotta
setblock 235 175 599 minecraft:yellow_concrete
setblock 238 175 560 minecraft:light[level=14]
setblock 238 175 568 minecraft:light[level=14]
setblock 238 175 576 minecraft:light[level=14]
setblock 238 175 584 minecraft:light[level=14]
setblock 238 175 592 minecraft:light[level=14]
fill 239 175 599 239 178 599 minecraft:orange_terracotta
setblock 240 175 557 minecraft:yellow_concrete
fill 241 175 557 241 177 557 minecraft:orange_terracotta
fill 242 175 576 242 175 582 minecraft:iron_block
fill 243 175 574 243 176 575 minecraft:iron_block
fill 243 175 583 243 176 584 minecraft:iron_block
fill 244 175 572 244 176 573 minecraft:iron_block
fill 244 175 576 244 176 582 minecraft:iron_block
fill 244 175 585 244 176 586 minecraft:iron_block
fill 245 175 557 245 177 557 minecraft:orange_terracotta
fill 245 175 571 245 176 571 minecraft:iron_block
fill 245 175 574 245 176 576 minecraft:iron_block
fill 245 175 582 245 176 584 minecraft:iron_block
fill 245 175 587 245 176 587 minecraft:iron_block
setblock 246 175 560 minecraft:light[level=14]
setblock 246 175 568 minecraft:light[level=14]
fill 246 175 570 246 176 570 minecraft:iron_block
fill 246 175 571 246 176 571 minecraft:light_gray_concrete
fill 246 175 572 246 176 573 minecraft:iron_block
setblock 246 175 576 minecraft:light[level=14]
setblock 246 175 584 minecraft:light[level=14]
fill 246 175 585 246 176 586 minecraft:iron_block
fill 246 175 587 246 176 587 minecraft:light_gray_concrete
fill 246 175 588 246 176 588 minecraft:iron_block
setblock 246 175 592 minecraft:light[level=14]
fill 247 175 569 248 176 569 minecraft:iron_block
fill 247 175 572 247 176 572 minecraft:light_gray_concrete
fill 247 175 586 247 176 586 minecraft:light_gray_concrete
fill 247 175 589 248 176 589 minecraft:iron_block
fill 248 175 571 248 176 571 minecraft:iron_block
fill 248 175 573 248 176 573 minecraft:light_gray_concrete
fill 248 175 585 248 176 585 minecraft:light_gray_concrete
fill 248 175 587 248 176 587 minecraft:iron_block
fill 249 175 568 250 176 568 minecraft:iron_block
fill 249 175 570 251 176 570 minecraft:iron_block
fill 249 175 574 249 176 574 minecraft:light_gray_concrete
fill 249 175 584 249 176 584 minecraft:light_gray_concrete
fill 249 175 588 251 176 588 minecraft:iron_block
fill 249 175 590 250 176 590 minecraft:iron_block
fill 250 175 575 250 176 575 minecraft:light_gray_concrete
fill 250 175 578 251 176 580 minecraft:white_concrete
fill 250 175 583 250 176 583 minecraft:light_gray_concrete
fill 251 175 567 257 176 567 minecraft:iron_block
fill 251 175 569 257 176 569 minecraft:iron_block
fill 251 175 576 251 176 576 minecraft:light_gray_concrete
fill 251 175 577 251 176 577 minecraft:white_concrete
fill 251 175 581 251 176 581 minecraft:white_concrete
fill 251 175 582 251 176 582 minecraft:light_gray_concrete
fill 251 175 589 257 176 589 minecraft:iron_block
fill 251 175 591 257 176 591 minecraft:iron_block
fill 252 175 576 256 176 576 minecraft:white_concrete
fill 252 175 582 256 176 582 minecraft:white_concrete
fill 253 175 575 255 176 575 minecraft:white_concrete
fill 253 175 578 256 175 578 minecraft:yellow_concrete
fill 253 175 583 255 176 583 minecraft:white_concrete
setblock 254 175 560 minecraft:light[level=14]
fill 254 175 577 256 175 577 minecraft:yellow_concrete
setblock 254 175 584 minecraft:light[level=14]
setblock 254 175 592 minecraft:light[level=14]
fill 255 175 579 256 175 580 minecraft:yellow_concrete
fill 255 175 599 256 175 599 minecraft:yellow_concrete
fill 256 175 557 256 178 557 minecraft:orange_terracotta
setblock 257 175 557 minecraft:yellow_concrete
fill 257 175 570 259 176 570 minecraft:iron_block
fill 257 175 576 257 176 576 minecraft:light_gray_concrete
fill 257 175 577 257 176 581 minecraft:white_concrete
fill 257 175 582 257 176 582 minecraft:light_gray_concrete
fill 257 175 588 259 176 588 minecraft:iron_block
fill 258 175 568 259 176 568 minecraft:iron_block
fill 258 175 575 258 176 575 minecraft:light_gray_concrete
fill 258 175 578 258 176 580 minecraft:white_concrete
fill 258 175 583 258 176 583 minecraft:light_gray_concrete
fill 258 175 590 259 176 590 minecraft:iron_block
fill 259 175 574 259 176 574 minecraft:light_gray_concrete
fill 259 175 584 259 176 584 minecraft:light_gray_concrete
setblock 259 175 599 minecraft:yellow_concrete
fill 260 175 569 261 176 569 minecraft:iron_block
fill 260 175 571 261 176 571 minecraft:iron_block
fill 260 175 573 260 176 573 minecraft:light_gray_concrete
fill 260 175 585 260 176 585 minecraft:light_gray_concrete
fill 260 175 587 261 176 587 minecraft:iron_block
fill 260 175 589 261 176 589 minecraft:iron_block
fill 260 175 599 260 178 599 minecraft:orange_terracotta
setblock 261 175 557 minecraft:yellow_concrete
fill 261 175 572 261 176 572 minecraft:light_gray_concrete
fill 261 175 586 261 176 586 minecraft:light_gray_concrete
setblock 262 175 560 minecraft:light[level=14]
setblock 262 175 568 minecraft:light[level=14]
fill 262 175 570 262 176 570 minecraft:iron_block
fill 262 175 571 262 176 571 minecraft:light_gray_concrete
fill 262 175 573 262 176 573 minecraft:iron_block
setblock 262 175 576 minecraft:light[level=14]
setblock 262 175 584 minecraft:light[level=14]
fill 262 175 585 262 176 585 minecraft:iron_block
fill 262 175 587 262 176 587 minecraft:light_gray_concrete
fill 262 175 588 262 176 588 minecraft:iron_block
setblock 262 175 592 minecraft:light[level=14]
fill 263 175 571 263 176 571 minecraft:iron_block
fill 263 175 574 263 176 576 minecraft:iron_block
fill 263 175 582 263 176 584 minecraft:iron_block
fill 263 175 587 263 176 587 minecraft:iron_block
fill 264 175 572 264 176 573 minecraft:iron_block
fill 264 175 576 264 176 582 minecraft:iron_block
fill 264 175 585 264 176 586 minecraft:iron_block
fill 265 175 574 265 176 575 minecraft:iron_block
fill 265 175 583 265 176 584 minecraft:iron_block
fill 266 175 576 266 175 582 minecraft:iron_block
setblock 270 175 560 minecraft:light[level=14]
setblock 270 175 568 minecraft:light[level=14]
setblock 270 175 576 minecraft:light[level=14]
setblock 270 175 584 minecraft:light[level=14]
setblock 270 175 592 minecraft:light[level=14]
fill 271 175 599 271 178 599 minecraft:orange_terracotta
fill 275 175 599 275 177 599 minecraft:orange_terracotta
setblock 276 175 599 minecraft:yellow_concrete
fill 277 175 557 277 178 557 minecraft:orange_terracotta
setblock 277 175 561 minecraft:yellow_concrete
fill 277 175 568 277 178 568 minecraft:orange_terracotta
setblock 277 175 569 minecraft:yellow_concrete
setblock 277 175 572 minecraft:yellow_concrete
fill 277 175 573 277 177 573 minecraft:orange_terracotta
fill 277 175 588 277 178 589 minecraft:orange_terracotta
setblock 277 175 593 minecraft:yellow_concrete
fill 235 176 557 235 176 558 minecraft:yellow_concrete
fill 235 176 559 235 181 560 minecraft:orange_terracotta
fill 235 176 565 235 177 566 minecraft:yellow_concrete
fill 235 176 567 235 181 568 minecraft:orange_terracotta
setblock 235 176 569 minecraft:yellow_concrete
fill 235 176 570 235 179 570 minecraft:orange_terracotta
fill 235 176 577 235 177 578 minecraft:yellow_concrete
fill 235 176 579 235 181 580 minecraft:orange_terracotta
setblock 235 176 585 minecraft:orange_terracotta
fill 235 176 586 235 177 586 minecraft:yellow_concrete
fill 235 176 588 235 181 588 minecraft:orange_terracotta
fill 235 176 589 235 176 590 minecraft:yellow_concrete
fill 235 176 591 235 181 591 minecraft:orange_terracotta
fill 235 176 597 235 177 598 minecraft:yellow_concrete
fill 235 176 599 236 181 599 minecraft:orange_terracotta
fill 236 176 557 237 178 557 minecraft:orange_terracotta
fill 238 176 557 239 176 557 minecraft:yellow_concrete
fill 238 176 576 242 176 582 minecraft:blue_stained_glass
fill 240 176 557 240 181 557 minecraft:orange_terracotta
fill 242 176 557 242 177 557 minecraft:yellow_concrete
setblock 243 176 557 minecraft:orange_terracotta
fill 245 176 599 246 176 599 minecraft:yellow_concrete
fill 247 176 599 248 181 599 minecraft:orange_terracotta
fill 248 176 557 249 181 557 minecraft:orange_terracotta
fill 250 176 557 251 177 557 minecraft:yellow_concrete
setblock 253 176 599 minecraft:orange_terracotta
fill 254 176 599 254 177 599 minecraft:yellow_concrete
fill 255 176 599 256 181 599 minecraft:orange_terracotta
fill 257 176 557 258 178 557 minecraft:orange_terracotta
setblock 257 176 599 minecraft:yellow_concrete
fill 258 176 599 259 179 599 minecraft:orange_terracotta
setblock 259 176 557 minecraft:yellow_concrete
fill 260 176 557 261 181 557 minecraft:orange_terracotta
fill 262 176 557 263 177 557 minecraft:yellow_concrete
fill 265 176 599 266 177 599 minecraft:yellow_concrete
fill 266 176 576 270 176 582 minecraft:blue_stained_glass
fill 267 176 599 268 181 599 minecraft:orange_terracotta
fill 268 176 557 269 181 557 minecraft:orange_terracotta
fill 270 176 557 271 176 557 minecraft:yellow_concrete
fill 276 176 599 276 181 599 minecraft:orange_terracotta
fill 277 176 560 277 181 561 minecraft:orange_terracotta
fill 277 176 562 277 177 563 minecraft:yellow_concrete
fill 277 176 569 277 181 569 minecraft:orange_terracotta
fill 277 176 570 277 176 571 minecraft:yellow_concrete
fill 277 176 572 277 181 572 minecraft:orange_terracotta
fill 277 176 574 277 177 574 minecraft:yellow_concrete
setblock 277 176 575 minecraft:orange_terracotta
fill 277 176 580 277 181 581 minecraft:orange_terracotta
fill 277 176 582 277 177 583 minecraft:yellow_concrete
fill 277 176 590 277 179 590 minecraft:orange_terracotta
setblock 277 176 591 minecraft:yellow_concrete
fill 277 176 592 277 181 593 minecraft:orange_terracotta
fill 277 176 594 277 177 595 minecraft:yellow_concrete
fill 277 176 599 277 177 599 minecraft:yellow_concrete
setblock 235 177 557 minecraft:yellow_concrete
fill 235 177 558 235 180 558 minecraft:orange_terracotta
fill 235 177 569 235 180 569 minecraft:orange_terracotta
fill 235 177 573 235 179 573 minecraft:orange_terracotta
setblock 235 177 574 minecraft:yellow_concrete
setblock 235 177 585 minecraft:yellow_concrete
fill 235 177 589 235 180 590 minecraft:orange_terracotta
fill 238 177 557 238 180 557 minecraft:orange_terracotta
setblock 239 177 557 minecraft:yellow_concrete
fill 241 177 599 241 179 599 minecraft:orange_terracotta
setblock 242 177 599 minecraft:yellow_concrete
setblock 243 177 557 minecraft:yellow_concrete
setblock 245 177 599 minecraft:yellow_concrete
fill 246 177 571 246 177 572 minecraft:iron_block
fill 246 177 586 246 177 587 minecraft:iron_block
fill 246 177 599 246 180 599 minecraft:orange_terracotta
setblock 253 177 599 minecraft:yellow_concrete
setblock 254 177 557 minecraft:yellow_concrete
fill 255 177 557 255 179 557 minecraft:orange_terracotta
fill 257 177 599 257 180 599 minecraft:orange_terracotta
fill 259 177 557 259 180 557 minecraft:orange_terracotta
fill 261 177 571 262 177 571 minecraft:iron_block
fill 261 177 587 262 177 587 minecraft:iron_block
fill 270 177 557 270 180 557 minecraft:orange_terracotta
setblock 271 177 557 minecraft:yellow_concrete
fill 273 177 599 274 177 599 minecraft:yellow_concrete
setblock 274 177 557 minecraft:yellow_concrete
fill 275 177 557 275 179 557 minecraft:orange_terracotta
fill 277 177 570 277 180 571 minecraft:orange_terracotta
setblock 277 177 575 minecraft:yellow_concrete
setblock 277 177 586 minecraft:yellow_concrete
fill 277 177 587 277 179 587 minecraft:orange_terracotta
fill 277 177 591 277 180 591 minecraft:orange_terracotta
fill 235 178 557 235 183 557 minecraft:orange_terracotta
fill 235 178 563 235 179 564 minecraft:yellow_concrete
fill 235 178 565 235 183 566 minecraft:orange_terracotta
fill 235 178 574 235 183 574 minecraft:orange_terracotta
fill 235 178 575 235 178 576 minecraft:yellow_concrete
fill 235 178 577 235 183 578 minecraft:orange_terracotta
fill 235 178 583 235 179 584 minecraft:yellow_concrete
fill 235 178 585 235 183 586 minecraft:orange_terracotta
setblock 235 178 587 minecraft:yellow_concrete
fill 235 178 595 235 179 596 minecraft:yellow_concrete
fill 235 178 597 235 183 598 minecraft:orange_terracotta
fill 239 178 557 239 180 557 minecraft:orange_terracotta
fill 240 178 599 240 179 599 minecraft:yellow_concrete
setblock 241 178 557 minecraft:yellow_concrete
fill 242 178 557 243 183 557 minecraft:orange_terracotta
fill 242 178 599 242 183 599 minecraft:orange_terracotta
fill 243 178 599 244 178 599 minecraft:yellow_concrete
fill 244 178 557 245 179 557 minecraft:yellow_concrete
fill 245 178 599 245 183 599 minecraft:orange_terracotta
fill 250 178 557 251 183 557 minecraft:orange_terracotta
fill 251 178 599 252 179 599 minecraft:yellow_concrete
fill 252 178 557 253 178 557 minecraft:yellow_concrete
fill 253 178 599 254 183 599 minecraft:orange_terracotta
fill 254 178 557 254 179 557 minecraft:orange_terracotta
fill 256 178 569 257 179 569 minecraft:red_concrete
fill 262 178 557 263 183 557 minecraft:orange_terracotta
fill 263 178 599 264 178 599 minecraft:yellow_concrete
fill 264 178 557 265 179 557 minecraft:yellow_concrete
fill 265 178 599 266 183 599 minecraft:orange_terracotta
fill 271 178 557 271 183 557 minecraft:orange_terracotta
fill 272 178 557 273 178 557 minecraft:yellow_concrete
fill 272 178 599 272 179 599 minecraft:yellow_concrete
fill 273 178 599 274 183 599 minecraft:orange_terracotta
fill 274 178 557 274 183 557 minecraft:orange_terracotta
setblock 275 178 599 minecraft:yellow_concrete
fill 276 178 557 276 179 557 minecraft:yellow_concrete
fill 277 178 562 277 183 563 minecraft:orange_terracotta
fill 277 178 564 277 179 565 minecraft:yellow_concrete
setblock 277 178 573 minecraft:yellow_concrete
fill 277 178 574 277 183 575 minecraft:orange_terracotta
fill 277 178 576 277 179 577 minecraft:yellow_concrete
fill 277 178 582 277 183 583 minecraft:orange_terracotta
fill 277 178 584 277 178 585 minecraft:yellow_concrete
fill 277 178 586 277 183 586 minecraft:orange_terracotta
fill 277 178 594 277 183 595 minecraft:orange_terracotta
fill 277 178 596 277 179 597 minecraft:yellow_concrete
fill 277 178 599 277 183 599 minecraft:orange_terracotta
fill 235 179 571 235 179 572 minecraft:yellow_concrete
setblock 235 179 575 minecraft:yellow_concrete
fill 235 179 576 235 182 576 minecraft:orange_terracotta
fill 235 179 587 235 182 587 minecraft:orange_terracotta
setblock 235 179 592 minecraft:yellow_concrete
setblock 236 179 557 minecraft:yellow_concrete
fill 237 179 557 237 181 557 minecraft:orange_terracotta
setblock 239 179 599 minecraft:yellow_concrete
fill 241 179 557 241 182 557 minecraft:orange_terracotta
fill 243 179 599 244 182 599 minecraft:orange_terracotta
fill 252 179 557 252 182 557 minecraft:orange_terracotta
setblock 253 179 557 minecraft:yellow_concrete
fill 256 179 557 257 179 557 minecraft:yellow_concrete
setblock 258 179 557 minecraft:orange_terracotta
setblock 260 179 599 minecraft:yellow_concrete
setblock 263 179 599 minecraft:yellow_concrete
fill 264 179 599 264 182 599 minecraft:orange_terracotta
setblock 271 179 599 minecraft:yellow_concrete
fill 272 179 557 273 181 557 minecraft:orange_terracotta
fill 275 179 599 275 182 599 minecraft:orange_terracotta
setblock 277 179 557 minecraft:yellow_concrete
setblock 277 179 568 minecraft:yellow_concrete
fill 277 179 573 277 182 573 minecraft:orange_terracotta
fill 277 179 584 277 182 584 minecraft:orange_terracotta
setblock 277 179 585 minecraft:yellow_concrete
fill 277 179 588 277 179 589 minecraft:yellow_concrete
fill 235 180 561 235 180 562 minecraft:yellow_concrete
fill 235 180 563 235 185 564 minecraft:orange_terracotta
fill 235 180 570 235 181 570 minecraft:yellow_concrete
fill 235 180 571 235 185 572 minecraft:orange_terracotta
setblock 235 180 573 minecraft:yellow_concrete
fill 235 180 575 235 185 575 minecraft:orange_terracotta
fill 235 180 581 235 181 582 minecraft:yellow_concrete
fill 235 180 583 235 185 584 minecraft:orange_terracotta
fill 235 180 592 235 185 592 minecraft:orange_terracotta
fill 235 180 593 235 180 594 minecraft:yellow_concrete
fill 235 180 595 235 185 596 minecraft:orange_terracotta
fill 236 180 557 236 185 557 minecraft:orange_terracotta
fill 236 180 558 238 180 558 minecraft:orange_concrete
fill 236 180 560 236 180 562 minecraft:orange_concrete
fill 236 180 563 238 183 563 minecraft:magma_block
fill 236 180 564 236 180 566 minecraft:orange_concrete
fill 236 180 568 236 180 570 minecraft:orange_concrete
fill 236 180 572 236 180 574 minecraft:orange_concrete
fill 236 180 576 236 180 578 minecraft:orange_concrete
fill 236 180 580 236 180 582 minecraft:orange_concrete
fill 236 180 584 236 180 586 minecraft:orange_concrete
fill 236 180 588 236 180 590 minecraft:orange_concrete
fill 236 180 592 236 180 594 minecraft:orange_concrete
fill 236 180 596 236 180 598 minecraft:orange_concrete
fill 237 180 564 238 183 565 minecraft:magma_block
fill 237 180 599 238 181 599 minecraft:yellow_concrete
fill 238 180 598 240 180 598 minecraft:orange_concrete
fill 239 180 564 239 183 564 minecraft:magma_block
fill 239 180 599 240 185 599 minecraft:orange_terracotta
fill 240 180 558 242 180 558 minecraft:orange_concrete
setblock 241 180 599 minecraft:yellow_concrete
fill 242 180 598 244 180 598 minecraft:orange_concrete
fill 244 180 557 245 185 557 minecraft:orange_terracotta
fill 244 180 558 246 180 558 minecraft:orange_concrete
fill 246 180 557 247 181 557 minecraft:yellow_concrete
fill 246 180 598 248 180 598 minecraft:orange_concrete
fill 248 180 558 250 180 558 minecraft:orange_concrete
fill 249 180 599 250 181 599 minecraft:yellow_concrete
fill 250 180 598 252 180 598 minecraft:orange_concrete
fill 251 180 599 252 185 599 minecraft:orange_terracotta
fill 252 180 558 254 180 558 minecraft:orange_concrete
fill 253 180 557 253 185 557 minecraft:orange_terracotta
fill 254 180 557 255 180 557 minecraft:yellow_concrete
fill 254 180 598 256 180 598 minecraft:orange_concrete
fill 256 180 557 257 181 557 minecraft:orange_terracotta
fill 256 180 558 258 180 558 minecraft:orange_concrete
fill 258 180 557 258 181 557 minecraft:yellow_concrete
fill 258 180 598 260 180 598 minecraft:orange_concrete
fill 258 180 599 258 181 599 minecraft:yellow_concrete
fill 259 180 599 260 181 599 minecraft:orange_terracotta
fill 260 180 558 262 180 558 minecraft:orange_concrete
fill 261 180 599 262 180 599 minecraft:yellow_concrete
fill 262 180 598 264 180 598 minecraft:orange_concrete
fill 263 180 599 263 185 599 minecraft:orange_terracotta
fill 264 180 557 265 185 557 minecraft:orange_terracotta
fill 264 180 558 266 180 558 minecraft:orange_concrete
fill 266 180 557 267 181 557 minecraft:yellow_concrete
fill 266 180 598 268 180 598 minecraft:orange_concrete
fill 268 180 558 270 180 558 minecraft:orange_concrete
fill 269 180 599 270 181 599 minecraft:yellow_concrete
fill 270 180 598 272 180 598 minecraft:orange_concrete
fill 271 180 599 272 185 599 minecraft:orange_terracotta
fill 272 180 558 274 180 558 minecraft:orange_concrete
fill 274 180 598 276 180 598 minecraft:orange_concrete
setblock 275 180 557 minecraft:yellow_concrete
fill 276 180 557 277 185 557 minecraft:orange_terracotta
fill 276 180 558 276 180 560 minecraft:orange_concrete
fill 276 180 562 276 180 564 minecraft:orange_concrete
fill 276 180 566 276 180 568 minecraft:orange_concrete
fill 276 180 570 276 180 572 minecraft:orange_concrete
fill 276 180 574 276 180 576 minecraft:orange_concrete
fill 276 180 578 276 180 580 minecraft:orange_concrete
fill 276 180 582 276 180 584 minecraft:orange_concrete
fill 276 180 586 276 180 588 minecraft:orange_concrete
fill 276 180 590 276 180 592 minecraft:orange_concrete
fill 276 180 594 276 180 596 minecraft:orange_concrete
fill 277 180 558 277 181 559 minecraft:yellow_concrete
fill 277 180 564 277 185 565 minecraft:orange_terracotta
fill 277 180 566 277 180 567 minecraft:yellow_concrete
fill 277 180 568 277 185 568 minecraft:orange_terracotta
fill 277 180 576 277 185 577 minecraft:orange_terracotta
fill 277 180 578 277 181 579 minecraft:yellow_concrete
fill 277 180 585 277 185 585 minecraft:orange_terracotta
setblock 277 180 587 minecraft:yellow_concrete
fill 277 180 588 277 185 589 minecraft:orange_terracotta
fill 277 180 590 277 181 590 minecraft:yellow_concrete
fill 277 180 596 277 185 597 minecraft:orange_terracotta
setblock 277 180 598 minecraft:yellow_concrete
setblock 235 181 558 minecraft:yellow_concrete
setblock 235 181 561 minecraft:yellow_concrete
fill 235 181 562 235 184 562 minecraft:orange_terracotta
setblock 235 181 569 minecraft:yellow_concrete
fill 235 181 573 235 184 573 minecraft:orange_terracotta
fill 235 181 589 235 181 590 minecraft:yellow_concrete
setblock 235 181 593 minecraft:yellow_concrete
fill 235 181 594 235 184 594 minecraft:orange_terracotta
fill 236 181 562 237 182 562 minecraft:magma_block
fill 236 181 564 236 182 566 minecraft:magma_block
fill 237 181 566 237 182 566 minecraft:magma_block
fill 238 181 557 239 181 557 minecraft:yellow_concrete
fill 239 181 563 240 182 563 minecraft:magma_block
fill 239 181 565 240 182 565 minecraft:magma_block
fill 240 181 564 242 182 564 minecraft:magma_block
fill 241 181 599 241 184 599 minecraft:orange_terracotta
setblock 246 181 599 minecraft:yellow_concrete
fill 254 181 557 255 183 557 minecraft:orange_terracotta
setblock 257 181 599 minecraft:yellow_concrete
setblock 259 181 557 minecraft:yellow_concrete
fill 261 181 599 262 184 599 minecraft:orange_terracotta
setblock 270 181 557 minecraft:yellow_concrete
fill 275 181 557 275 183 557 minecraft:orange_terracotta
fill 277 181 566 277 184 566 minecraft:orange_terracotta
setblock 277 181 567 minecraft:yellow_concrete
fill 277 181 570 277 181 571 minecraft:yellow_concrete
fill 277 181 587 277 184 587 minecraft:orange_terracotta
setblock 277 181 591 minecraft:yellow_concrete
fill 277 181 598 277 184 598 minecraft:orange_terracotta
fill 235 182 558 235 187 558 minecraft:orange_terracotta
fill 235 182 559 235 182 560 minecraft:yellow_concrete
fill 235 182 561 235 187 561 minecraft:orange_terracotta
fill 235 182 567 235 183 568 minecraft:yellow_concrete
fill 235 182 569 235 187 570 minecraft:orange_terracotta
fill 235 182 579 235 182 580 minecraft:yellow_concrete
fill 235 182 581 235 187 582 minecraft:orange_terracotta
fill 235 182 588 235 183 588 minecraft:yellow_concrete
fill 235 182 589 235 187 590 minecraft:orange_terracotta
setblock 235 182 591 minecraft:yellow_concrete
fill 235 182 593 235 187 593 minecraft:orange_terracotta
fill 235 182 599 236 183 599 minecraft:yellow_concrete
setblock 237 182 557 minecraft:yellow_concrete
fill 237 182 599 238 187 599 minecraft:orange_terracotta
fill 238 182 557 239 187 557 minecraft:orange_terracotta
fill 240 182 557 240 183 557 minecraft:yellow_concrete
fill 245 182 577 246 183 578 minecraft:yellow_concrete
fill 246 182 557 247 187 557 minecraft:orange_terracotta
fill 246 182 599 246 187 599 minecraft:orange_terracotta
fill 247 182 599 248 182 599 minecraft:yellow_concrete
fill 248 182 557 249 183 557 minecraft:yellow_concrete
fill 249 182 599 250 187 599 minecraft:orange_terracotta
fill 255 182 599 256 183 599 minecraft:yellow_concrete
fill 256 182 557 256 185 557 minecraft:orange_terracotta
setblock 257 182 557 minecraft:yellow_concrete
fill 257 182 599 258 187 599 minecraft:orange_terracotta
fill 258 182 557 259 187 557 minecraft:orange_terracotta
setblock 259 182 599 minecraft:yellow_concrete
fill 260 182 557 261 183 557 minecraft:yellow_concrete
fill 260 182 599 260 185 599 minecraft:orange_terracotta
fill 266 182 557 267 184 557 minecraft:orange_terracotta
fill 267 182 599 268 183 599 minecraft:yellow_concrete
fill 268 182 557 269 182 557 minecraft:yellow_concrete
fill 269 182 599 270 187 599 minecraft:orange_terracotta
fill 270 182 557 270 187 557 minecraft:orange_terracotta
fill 272 182 557 272 183 557 minecraft:yellow_concrete
setblock 273 182 557 minecraft:orange_terracotta
fill 276 182 599 276 183 599 minecraft:yellow_concrete
fill 277 182 558 277 187 559 minecraft:orange_terracotta
fill 277 182 560 277 183 561 minecraft:yellow_concrete
fill 277 182 567 277 187 567 minecraft:orange_terracotta
setblock 277 182 569 minecraft:yellow_concrete
fill 277 182 570 277 187 571 minecraft:orange_terracotta
fill 277 182 572 277 183 572 minecraft:yellow_concrete
fill 277 182 578 277 187 579 minecraft:orange_terracotta
fill 277 182 580 277 182 581 minecraft:yellow_concrete
fill 277 182 590 277 187 591 minecraft:orange_terracotta
fill 277 182 592 277 183 593 minecraft:yellow_concrete
fill 235 183 559 235 186 560 minecraft:orange_terracotta
setblock 235 183 576 minecraft:yellow_concrete
setblock 235 183 579 minecraft:yellow_concrete
fill 235 183 580 235 186 580 minecraft:orange_terracotta
setblock 235 183 587 minecraft:yellow_concrete
fill 235 183 591 235 186 591 minecraft:orange_terracotta
fill 236 183 564 236 183 565 minecraft:magma_block
fill 237 183 557 237 186 557 minecraft:orange_terracotta
setblock 238 183 560 minecraft:light[level=14]
setblock 238 183 568 minecraft:light[level=14]
setblock 238 183 576 minecraft:light[level=14]
setblock 238 183 584 minecraft:light[level=14]
setblock 238 183 592 minecraft:light[level=14]
setblock 241 183 557 minecraft:yellow_concrete
fill 243 183 599 244 183 599 minecraft:yellow_concrete
setblock 246 183 560 minecraft:light[level=14]
setblock 246 183 568 minecraft:light[level=14]
setblock 246 183 576 minecraft:light[level=14]
setblock 246 183 584 minecraft:light[level=14]
setblock 246 183 592 minecraft:light[level=14]
setblock 247 183 599 minecraft:yellow_concrete
fill 248 183 599 248 186 599 minecraft:orange_terracotta
setblock 252 183 557 minecraft:yellow_concrete
setblock 254 183 560 minecraft:light[level=14]
setblock 254 183 568 minecraft:light[level=14]
setblock 254 183 576 minecraft:light[level=14]
setblock 254 183 584 minecraft:light[level=14]
setblock 254 183 592 minecraft:light[level=14]
fill 257 183 557 257 185 557 minecraft:orange_terracotta
fill 259 183 599 259 186 599 minecraft:orange_terracotta
setblock 262 183 560 minecraft:light[level=14]
setblock 262 183 568 minecraft:light[level=14]
setblock 262 183 576 minecraft:light[level=14]
setblock 262 183 584 minecraft:light[level=14]
setblock 262 183 592 minecraft:light[level=14]
setblock 264 183 599 minecraft:yellow_concrete
fill 268 183 557 268 186 557 minecraft:orange_terracotta
setblock 269 183 557 minecraft:yellow_concrete
setblock 270 183 560 minecraft:light[level=14]
setblock 270 183 568 minecraft:light[level=14]
setblock 270 183 576 minecraft:light[level=14]
setblock 270 183 584 minecraft:light[level=14]
setblock 270 183 592 minecraft:light[level=14]
setblock 273 183 557 minecraft:yellow_concrete
setblock 275 183 599 minecraft:yellow_concrete
fill 277 183 569 277 186 569 minecraft:orange_terracotta
setblock 277 183 573 minecraft:yellow_concrete
fill 277 183 580 277 186 580 minecraft:orange_terracotta
setblock 277 183 581 minecraft:yellow_concrete
setblock 277 183 584 minecraft:yellow_concrete
setblock 235 184 557 minecraft:yellow_concrete
fill 235 184 565 235 185 566 minecraft:yellow_concrete
fill 235 184 567 235 189 568 minecraft:orange_terracotta
fill 235 184 574 235 185 574 minecraft:yellow_concrete
fill 235 184 576 235 189 576 minecraft:orange_terracotta
fill 235 184 577 235 184 578 minecraft:yellow_concrete
fill 235 184 579 235 189 579 minecraft:orange_terracotta
fill 235 184 585 235 185 586 minecraft:yellow_concrete
fill 235 184 587 235 189 588 minecraft:orange_terracotta
fill 235 184 597 235 184 598 minecraft:yellow_concrete
fill 235 184 599 236 189 599 minecraft:orange_terracotta
fill 240 184 557 241 189 557 minecraft:orange_terracotta
fill 242 184 557 243 185 557 minecraft:yellow_concrete
fill 242 184 599 242 185 599 minecraft:yellow_concrete
fill 243 184 599 244 189 599 minecraft:orange_terracotta
setblock 245 184 599 minecraft:yellow_concrete
fill 247 184 599 247 189 599 minecraft:orange_terracotta
fill 248 184 557 249 186 557 minecraft:orange_terracotta
fill 250 184 557 251 184 557 minecraft:yellow_concrete
fill 252 184 557 252 189 557 minecraft:orange_terracotta
fill 253 184 599 254 185 599 minecraft:yellow_concrete
fill 254 184 557 254 185 557 minecraft:yellow_concrete
setblock 255 184 557 minecraft:orange_terracotta
fill 255 184 599 256 189 599 minecraft:orange_terracotta
fill 260 184 557 261 189 557 minecraft:orange_terracotta
fill 262 184 557 263 185 557 minecraft:yellow_concrete
fill 264 184 599 264 189 599 minecraft:orange_terracotta
fill 265 184 599 266 184 599 minecraft:yellow_concrete
fill 267 184 599 268 189 599 minecraft:orange_terracotta
fill 269 184 557 269 186 557 minecraft:orange_terracotta
setblock 271 184 557 minecraft:yellow_concrete
fill 272 184 557 273 189 557 minecraft:orange_terracotta
fill 273 184 599 274 185 599 minecraft:yellow_concrete
fill 274 184 557 275 185 557 minecraft:yellow_concrete
fill 275 184 599 276 189 599 minecraft:orange_terracotta
fill 277 184 560 277 189 561 minecraft:orange_terracotta
fill 277 184 562 277 184 563 minecraft:yellow_concrete
fill 277 184 572 277 189 573 minecraft:orange_terracotta
fill 277 184 574 277 185 575 minecraft:yellow_concrete
fill 277 184 581 277 189 581 minecraft:orange_terracotta
fill 277 184 582 277 184 583 minecraft:yellow_concrete
fill 277 184 584 277 189 584 minecraft:orange_terracotta
fill 277 184 586 277 185 586 minecraft:yellow_concrete
fill 277 184 592 277 189 593 minecraft:orange_terracotta
fill 277 184 594 277 185 595 minecraft:yellow_concrete
setblock 277 184 599 minecraft:yellow_concrete
fill 235 185 557 235 188 557 minecraft:orange_terracotta
setblock 235 185 562 minecraft:yellow_concrete
setblock 235 185 573 minecraft:yellow_concrete
fill 235 185 577 235 188 578 minecraft:orange_terracotta
setblock 235 185 594 minecraft:yellow_concrete
setblock 235 185 597 minecraft:yellow_concrete
fill 235 185 598 235 188 598 minecraft:orange_terracotta
setblock 241 185 599 minecraft:yellow_concrete
fill 245 185 599 245 188 599 minecraft:orange_terracotta
fill 250 185 557 250 188 557 minecraft:orange_terracotta
setblock 251 185 557 minecraft:yellow_concrete
setblock 255 185 557 minecraft:yellow_concrete
fill 261 185 599 262 185 599 minecraft:yellow_concrete
setblock 265 185 599 minecraft:yellow_concrete
setblock 266 185 557 minecraft:yellow_concrete
fill 266 185 599 266 188 599 minecraft:orange_terracotta
fill 267 185 557 267 187 557 minecraft:orange_terracotta
fill 271 185 557 271 188 557 minecraft:orange_terracotta
fill 277 185 562 277 188 562 minecraft:orange_terracotta
setblock 277 185 563 minecraft:yellow_concrete
setblock 277 185 566 minecraft:yellow_concrete
fill 277 185 582 277 188 583 minecraft:orange_terracotta
setblock 277 185 587 minecraft:yellow_concrete
setblock 277 185 598 minecraft:yellow_concrete
fill 277 185 599 277 188 599 minecraft:orange_terracotta
fill 235 186 562 235 191 562 minecraft:orange_terracotta
fill 235 186 563 235 186 564 minecraft:yellow_concrete
fill 235 186 565 235 191 566 minecraft:orange_terracotta
fill 235 186 571 235 187 572 minecraft:yellow_concrete
fill 235 186 573 235 191 574 minecraft:orange_terracotta
setblock 235 186 575 minecraft:yellow_concrete
fill 235 186 583 235 187 584 minecraft:yellow_concrete
fill 235 186 585 235 191 586 minecraft:orange_terracotta
fill 235 186 592 235 187 592 minecraft:yellow_concrete
fill 235 186 594 235 191 594 minecraft:orange_terracotta
fill 235 186 595 235 186 596 minecraft:yellow_concrete
fill 235 186 597 235 191 597 minecraft:orange_terracotta
fill 236 186 557 236 187 557 minecraft:yellow_concrete
fill 236 186 558 238 186 558 minecraft:orange_concrete
fill 236 186 560 236 186 562 minecraft:orange_concrete
fill 236 186 564 236 186 566 minecraft:orange_concrete
fill 236 186 568 236 186 570 minecraft:orange_concrete
fill 236 186 572 236 186 574 minecraft:orange_concrete
fill 236 186 576 236 186 578 minecraft:orange_concrete
fill 236 186 580 236 186 582 minecraft:orange_concrete
fill 236 186 584 236 186 586 minecraft:orange_concrete
fill 236 186 588 236 186 590 minecraft:orange_concrete
fill 236 186 592 236 186 594 minecraft:orange_concrete
fill 236 186 596 236 186 598 minecraft:orange_concrete
fill 238 186 598 240 186 598 minecraft:orange_concrete
fill 239 186 599 240 187 599 minecraft:yellow_concrete
fill 240 186 558 242 186 558 minecraft:orange_concrete
fill 241 186 599 242 191 599 minecraft:orange_terracotta
fill 242 186 557 243 191 557 minecraft:orange_terracotta
fill 242 186 598 244 186 598 minecraft:orange_concrete
fill 244 186 557 245 187 557 minecraft:yellow_concrete
fill 244 186 558 246 186 558 minecraft:orange_concrete
fill 246 186 598 248 186 598 minecraft:orange_concrete
fill 248 186 558 250 186 558 minecraft:orange_concrete
fill 250 186 598 252 186 598 minecraft:orange_concrete
fill 251 186 557 251 188 557 minecraft:orange_terracotta
fill 251 186 599 252 186 599 minecraft:yellow_concrete
fill 252 186 558 254 186 558 minecraft:orange_concrete
setblock 253 186 557 minecraft:yellow_concrete
fill 253 186 599 254 191 599 minecraft:orange_terracotta
fill 254 186 557 255 191 557 minecraft:orange_terracotta
fill 254 186 598 256 186 598 minecraft:orange_concrete
fill 256 186 557 257 187 557 minecraft:yellow_concrete
fill 256 186 558 258 186 558 minecraft:orange_concrete
fill 258 186 598 260 186 598 minecraft:orange_concrete
fill 260 186 558 262 186 558 minecraft:orange_concrete
fill 260 186 599 260 187 599 minecraft:yellow_concrete
fill 261 186 599 262 191 599 minecraft:orange_terracotta
fill 262 186 557 263 191 557 minecraft:orange_terracotta
fill 262 186 567 262 187 569 minecraft:red_concrete
fill 262 186 598 264 186 598 minecraft:orange_concrete
fill 263 186 568 263 187 568 minecraft:red_concrete
setblock 263 186 599 minecraft:yellow_concrete
fill 264 186 557 265 186 557 minecraft:yellow_concrete
fill 264 186 558 266 186 558 minecraft:orange_concrete
fill 265 186 599 265 191 599 minecraft:orange_terracotta
fill 266 186 557 266 187 557 minecraft:orange_terracotta
fill 266 186 598 268 186 598 minecraft:orange_concrete
fill 268 186 558 270 186 558 minecraft:orange_concrete
fill 270 186 598 272 186 598 minecraft:orange_concrete
fill 271 186 599 272 187 599 minecraft:yellow_concrete
fill 272 186 558 274 186 558 minecraft:orange_concrete
fill 273 186 599 274 191 599 minecraft:orange_terracotta
fill 274 186 557 275 191 557 minecraft:orange_terracotta
fill 274 186 598 276 186 598 minecraft:orange_concrete
fill 276 186 557 277 187 557 minecraft:yellow_concrete
fill 276 186 558 276 186 560 minecraft:orange_concrete
fill 276 186 562 276 186 564 minecraft:orange_concrete
fill 276 186 566 276 186 568 minecraft:orange_concrete
fill 276 186 570 276 186 572 minecraft:orange_concrete
fill 276 186 574 276 186 576 minecraft:orange_concrete
fill 276 186 578 276 186 580 minecraft:orange_concrete
fill 276 186 582 276 186 584 minecraft:orange_concrete
fill 276 186 586 276 186 588 minecraft:orange_concrete
fill 276 186 590 276 186 592 minecraft:orange_concrete
fill 276 186 594 276 186 596 minecraft:orange_concrete
fill 277 186 563 277 191 563 minecraft:orange_terracotta
fill 277 186 564 277 186 565 minecraft:yellow_concrete
fill 277 186 566 277 191 566 minecraft:orange_terracotta
fill 277 186 568 277 187 568 minecraft:yellow_concrete
fill 277 186 574 277 191 575 minecraft:orange_terracotta
fill 277 186 576 277 187 577 minecraft:yellow_concrete
setblock 277 186 585 minecraft:yellow_concrete
fill 277 186 586 277 191 587 minecraft:orange_terracotta
fill 277 186 588 277 187 589 minecraft:yellow_concrete
fill 277 186 594 277 191 595 minecraft:orange_terracotta
fill 277 186 596 277 186 597 minecraft:yellow_concrete
fill 277 186 598 277 191 598 minecraft:orange_terracotta
fill 235 187 559 235 187 560 minecraft:yellow_concrete
setblock 235 187 563 minecraft:yellow_concrete
fill 235 187 564 235 190 564 minecraft:orange_terracotta
fill 235 187 575 235 190 575 minecraft:orange_terracotta
setblock 235 187 580 minecraft:yellow_concrete
setblock 235 187 591 minecraft:yellow_concrete
fill 235 187 595 235 190 596 minecraft:orange_terracotta
setblock 237 187 557 minecraft:yellow_concrete
setblock 248 187 557 minecraft:yellow_concrete
setblock 248 187 599 minecraft:yellow_concrete
fill 249 187 557 249 189 557 minecraft:orange_terracotta
setblock 251 187 599 minecraft:yellow_concrete
fill 252 187 599 252 190 599 minecraft:orange_terracotta
fill 253 187 557 253 190 557 minecraft:orange_terracotta
setblock 259 187 599 minecraft:yellow_concrete
fill 263 187 599 263 190 599 minecraft:orange_terracotta
fill 264 187 557 264 190 557 minecraft:orange_terracotta
setblock 265 187 557 minecraft:yellow_concrete
fill 268 187 557 269 187 557 minecraft:yellow_concrete
fill 277 187 564 277 189 565 minecraft:orange_terracotta
setblock 277 187 569 minecraft:yellow_concrete
setblock 277 187 580 minecraft:yellow_concrete
fill 277 187 585 277 190 585 minecraft:orange_terracotta
fill 277 187 596 277 190 596 minecraft:orange_terracotta
setblock 277 187 597 minecraft:yellow_concrete
fill 235 188 558 235 189 558 minecraft:yellow_concrete
fill 235 188 559 235 193 560 minecraft:orange_terracotta
setblock 235 188 561 minecraft:yellow_concrete
fill 235 188 563 235 193 563 minecraft:orange_terracotta
fill 235 188 569 235 189 570 minecraft:yellow_concrete
fill 235 188 571 235 193 572 minecraft:orange_terracotta
fill 235 188 580 235 193 580 minecraft:orange_terracotta
fill 235 188 581 235 188 582 minecraft:yellow_concrete
fill 235 188 583 235 193 584 minecraft:orange_terracotta
fill 235 188 589 235 189 590 minecraft:yellow_concrete
fill 235 188 591 235 193 592 minecraft:orange_terracotta
setblock 235 188 593 minecraft:yellow_concrete
fill 236 188 557 237 193 557 minecraft:orange_terracotta
fill 237 188 599 238 189 599 minecraft:yellow_concrete
fill 238 188 557 239 189 557 minecraft:yellow_concrete
fill 239 188 599 240 193 599 minecraft:orange_terracotta
fill 244 188 557 245 193 557 minecraft:orange_terracotta
fill 246 188 557 247 188 557 minecraft:yellow_concrete
fill 246 188 599 246 189 599 minecraft:yellow_concrete
fill 248 188 557 248 193 557 minecraft:orange_terracotta
fill 248 188 599 248 193 599 minecraft:orange_terracotta
fill 249 188 599 250 188 599 minecraft:yellow_concrete
fill 251 188 599 251 193 599 minecraft:orange_terracotta
fill 256 188 557 257 193 557 minecraft:orange_terracotta
fill 257 188 599 258 189 599 minecraft:yellow_concrete
fill 258 188 557 259 189 557 minecraft:yellow_concrete
fill 259 188 599 260 193 599 minecraft:orange_terracotta
fill 265 188 557 265 193 557 minecraft:orange_terracotta
fill 266 188 557 267 188 557 minecraft:yellow_concrete
fill 268 188 557 269 189 557 minecraft:orange_terracotta
fill 269 188 599 270 188 599 minecraft:yellow_concrete
fill 270 188 557 270 189 557 minecraft:yellow_concrete
fill 271 188 599 272 193 599 minecraft:orange_terracotta
fill 276 188 557 277 193 557 minecraft:orange_terracotta
fill 277 188 558 277 189 559 minecraft:yellow_concrete
setblock 277 188 567 minecraft:yellow_concrete
fill 277 188 568 277 193 569 minecraft:orange_terracotta
fill 277 188 570 277 189 571 minecraft:yellow_concrete
fill 277 188 576 277 193 577 minecraft:orange_terracotta
fill 277 188 578 277 188 579 minecraft:yellow_concrete
fill 277 188 580 277 193 580 minecraft:orange_terracotta
fill 277 188 588 277 193 589 minecraft:orange_terracotta
fill 277 188 590 277 189 591 minecraft:yellow_concrete
fill 277 188 597 277 193 597 minecraft:orange_terracotta
setblock 235 189 557 minecraft:yellow_concrete
fill 235 189 561 235 192 561 minecraft:orange_terracotta
fill 235 189 577 235 189 578 minecraft:yellow_concrete
setblock 235 189 581 minecraft:yellow_concrete
fill 235 189 582 235 192 582 minecraft:orange_terracotta
fill 235 189 593 235 192 593 minecraft:orange_terracotta
setblock 235 189 598 minecraft:yellow_concrete
setblock 245 189 599 minecraft:yellow_concrete
fill 246 189 557 246 192 557 minecraft:orange_terracotta
setblock 247 189 557 minecraft:yellow_concrete
fill 249 189 599 250 192 599 minecraft:orange_terracotta
fill 250 189 557 251 189 557 minecraft:yellow_concrete
fill 266 189 557 267 191 557 minecraft:orange_terracotta
setblock 266 189 599 minecraft:yellow_concrete
setblock 269 189 599 minecraft:yellow_concrete
fill 270 189 599 270 192 599 minecraft:orange_terracotta
setblock 271 189 557 minecraft:yellow_concrete
setblock 277 189 562 minecraft:yellow_concrete
fill 277 189 567 277 191 567 minecraft:orange_terracotta
fill 277 189 578 277 192 578 minecraft:orange_terracotta
setblock 277 189 579 minecraft:yellow_concrete
fill 277 189 582 277 189 583 minecraft:yellow_concrete
setblock 277 189 599 minecraft:yellow_concrete
fill 235 190 557 235 195 558 minecraft:orange_terracotta
fill 235 190 567 235 190 568 minecraft:yellow_concrete
fill 235 190 569 235 195 570 minecraft:orange_terracotta
fill 235 190 576 235 191 576 minecraft:yellow_concrete
fill 235 190 577 235 195 578 minecraft:orange_terracotta
setblock 235 190 579 minecraft:yellow_concrete
fill 235 190 581 235 195 581 minecraft:orange_terracotta
fill 235 190 587 235 191 588 minecraft:yellow_concrete
fill 235 190 589 235 195 590 minecraft:orange_terracotta
fill 235 190 598 235 195 598 minecraft:orange_terracotta
fill 235 190 599 236 190 599 minecraft:yellow_concrete
fill 237 190 599 238 195 599 minecraft:orange_terracotta
fill 238 190 557 239 195 557 minecraft:orange_terracotta
fill 240 190 557 241 191 557 minecraft:yellow_concrete
fill 243 190 599 244 191 599 minecraft:yellow_concrete
fill 245 190 599 246 195 599 minecraft:orange_terracotta
fill 247 190 557 247 195 557 minecraft:orange_terracotta
setblock 247 190 599 minecraft:yellow_concrete
setblock 249 190 557 minecraft:yellow_concrete
fill 250 190 557 251 195 557 minecraft:orange_terracotta
fill 252 190 557 252 191 557 minecraft:yellow_concrete
fill 252 190 590 253 191 591 minecraft:orange_concrete
fill 255 190 599 256 191 599 minecraft:yellow_concrete
fill 257 190 599 258 195 599 minecraft:orange_terracotta
fill 258 190 557 259 195 557 minecraft:orange_terracotta
fill 260 190 557 261 191 557 minecraft:yellow_concrete
fill 264 190 599 264 191 599 minecraft:yellow_concrete
fill 266 190 599 266 195 599 minecraft:orange_terracotta
fill 267 190 599 268 190 599 minecraft:yellow_concrete
fill 268 190 557 268 193 557 minecraft:orange_terracotta
setblock 269 190 557 minecraft:yellow_concrete
fill 269 190 599 269 195 599 minecraft:orange_terracotta
fill 270 190 557 271 195 557 minecraft:orange_terracotta
fill 272 190 557 273 191 557 minecraft:yellow_concrete
fill 275 190 599 276 191 599 minecraft:yellow_concrete
fill 277 190 558 277 192 559 minecraft:orange_terracotta
fill 277 190 560 277 190 561 minecraft:yellow_concrete
fill 277 190 562 277 195 562 minecraft:orange_terracotta
fill 277 190 564 277 191 564 minecraft:yellow_concrete
setblock 277 190 565 minecraft:orange_terracotta
fill 277 190 570 277 195 571 minecraft:orange_terracotta
fill 277 190 572 277 191 573 minecraft:yellow_concrete
fill 277 190 579 277 195 579 minecraft:orange_terracotta
setblock 277 190 581 minecraft:yellow_concrete
fill 277 190 582 277 195 583 minecraft:orange_terracotta
fill 277 190 584 277 191 584 minecraft:yellow_concrete
fill 277 190 590 277 195 591 minecraft:orange_terracotta
fill 277 190 592 277 190 593 minecraft:yellow_concrete
fill 277 190 599 277 195 599 minecraft:orange_terracotta
setblock 235 191 564 minecraft:yellow_concrete
setblock 235 191 567 minecraft:yellow_concrete
fill 235 191 568 235 194 568 minecraft:orange_terracotta
setblock 235 191 575 minecraft:yellow_concrete
fill 235 191 579 235 194 579 minecraft:orange_terracotta
fill 235 191 595 235 191 596 minecraft:yellow_concrete
setblock 235 191 599 minecraft:yellow_concrete
fill 236 191 599 236 194 599 minecraft:orange_terracotta
setblock 238 191 560 minecraft:light[level=14]
setblock 238 191 568 minecraft:light[level=14]
setblock 238 191 576 minecraft:light[level=14]
setblock 238 191 584 minecraft:light[level=14]
setblock 238 191 592 minecraft:light[level=14]
setblock 246 191 560 minecraft:light[level=14]
setblock 246 191 568 minecraft:light[level=14]
setblock 246 191 576 minecraft:light[level=14]
setblock 246 191 584 minecraft:light[level=14]
setblock 246 191 592 minecraft:light[level=14]
fill 247 191 599 247 194 599 minecraft:orange_terracotta
fill 249 191 557 249 194 557 minecraft:orange_terracotta
setblock 252 191 599 minecraft:yellow_concrete
setblock 253 191 557 minecraft:yellow_concrete
setblock 254 191 560 minecraft:light[level=14]
setblock 254 191 568 minecraft:light[level=14]
setblock 254 191 576 minecraft:light[level=14]
setblock 254 191 584 minecraft:light[level=14]
setblock 254 191 592 minecraft:light[level=14]
setblock 262 191 560 minecraft:light[level=14]
setblock 262 191 568 minecraft:light[level=14]
setblock 262 191 576 minecraft:light[level=14]
setblock 262 191 584 minecraft:light[level=14]
setblock 262 191 592 minecraft:light[level=14]
setblock 263 191 599 minecraft:yellow_concrete
setblock 264 191 557 minecraft:yellow_concrete
fill 267 191 599 268 194 599 minecraft:orange_terracotta
fill 269 191 557 269 193 557 minecraft:orange_terracotta
setblock 270 191 560 minecraft:light[level=14]
setblock 270 191 568 minecraft:light[level=14]
setblock 270 191 576 minecraft:light[level=14]
setblock 270 191 584 minecraft:light[level=14]
setblock 270 191 592 minecraft:light[level=14]
fill 277 191 560 277 194 560 minecraft:orange_terracotta
setblock 277 191 561 minecraft:yellow_concrete
setblock 277 191 565 minecraft:yellow_concrete
fill 277 191 581 277 194 581 minecraft:orange_terracotta
setblock 277 191 585 minecraft:yellow_concrete
fill 277 191 592 277 194 592 minecraft:orange_terracotta
setblock 277 191 593 minecraft:yellow_concrete
setblock 277 191 596 minecraft:yellow_concrete
fill 235 192 562 235 193 562 minecraft:yellow_concrete
fill 235 192 564 235 197 564 minecraft:orange_terracotta
fill 235 192 565 235 192 566 minecraft:yellow_concrete
fill 235 192 567 235 197 567 minecraft:orange_terracotta
fill 235 192 573 235 193 574 minecraft:yellow_concrete
fill 235 192 575 235 197 576 minecraft:orange_terracotta
fill 235 192 585 235 192 586 minecraft:yellow_concrete
fill 235 192 587 235 197 588 minecraft:orange_terracotta
fill 235 192 594 235 193 594 minecraft:yellow_concrete
fill 235 192 595 235 197 596 minecraft:orange_terracotta
setblock 235 192 597 minecraft:yellow_concrete
fill 235 192 599 235 197 599 minecraft:orange_terracotta
fill 236 192 558 238 192 558 minecraft:orange_concrete
fill 236 192 560 236 192 562 minecraft:orange_concrete
fill 236 192 564 236 192 566 minecraft:orange_concrete
fill 236 192 568 236 192 570 minecraft:orange_concrete
fill 236 192 572 236 192 574 minecraft:orange_concrete
fill 236 192 576 236 192 578 minecraft:orange_concrete
fill 236 192 580 236 192 582 minecraft:orange_concrete
fill 236 192 584 236 192 586 minecraft:orange_concrete
fill 236 192 588 236 192 590 minecraft:orange_concrete
fill 236 192 592 236 192 594 minecraft:orange_concrete
fill 236 192 596 236 192 598 minecraft:orange_concrete
fill 238 192 598 240 192 598 minecraft:orange_concrete
fill 240 192 557 241 197 557 minecraft:orange_terracotta
fill 240 192 558 242 192 558 minecraft:orange_concrete
fill 241 192 599 242 193 599 minecraft:yellow_concrete
fill 242 192 557 243 192 557 minecraft:yellow_concrete
fill 242 192 598 244 192 598 minecraft:orange_concrete
fill 243 192 599 244 197 599 minecraft:orange_terracotta
fill 244 192 558 246 192 558 minecraft:orange_concrete
fill 246 192 598 248 192 598 minecraft:orange_concrete
fill 248 192 558 250 192 558 minecraft:orange_concrete
fill 250 192 598 252 192 598 minecraft:orange_concrete
fill 252 192 557 253 197 557 minecraft:orange_terracotta
fill 252 192 558 254 192 558 minecraft:orange_concrete
fill 252 192 599 252 197 599 minecraft:orange_terracotta
fill 253 192 599 254 192 599 minecraft:yellow_concrete
fill 254 192 557 255 193 557 minecraft:yellow_concrete
fill 254 192 598 256 192 598 minecraft:orange_concrete
fill 255 192 599 256 197 599 minecraft:orange_terracotta
fill 256 192 558 258 192 558 minecraft:orange_concrete
fill 258 192 598 260 192 598 minecraft:orange_concrete
fill 260 192 557 261 194 557 minecraft:orange_terracotta
fill 260 192 558 262 192 558 minecraft:orange_concrete
fill 261 192 599 262 193 599 minecraft:yellow_concrete
fill 262 192 557 263 192 557 minecraft:yellow_concrete
fill 262 192 598 264 192 598 minecraft:orange_concrete
fill 263 192 599 264 197 599 minecraft:orange_terracotta
fill 264 192 557 264 197 557 minecraft:orange_terracotta
fill 264 192 558 266 192 558 minecraft:orange_concrete
setblock 265 192 599 minecraft:yellow_concrete
fill 266 192 557 266 193 557 minecraft:yellow_concrete
fill 266 192 598 268 192 598 minecraft:orange_concrete
setblock 267 192 557 minecraft:orange_terracotta
fill 268 192 558 270 192 558 minecraft:orange_concrete
fill 270 192 598 272 192 598 minecraft:orange_concrete
fill 272 192 557 273 197 557 minecraft:orange_terracotta
fill 272 192 558 274 192 558 minecraft:orange_concrete
fill 273 192 599 274 193 599 minecraft:yellow_concrete
fill 274 192 557 275 193 557 minecraft:yellow_concrete
fill 274 192 598 276 192 598 minecraft:orange_concrete
fill 275 192 599 276 197 599 minecraft:orange_terracotta
fill 276 192 558 276 192 560 minecraft:orange_concrete
fill 276 192 562 276 192 564 minecraft:orange_concrete
fill 276 192 566 276 192 568 minecraft:orange_concrete
fill 276 192 570 276 192 572 minecraft:orange_concrete
fill 276 192 574 276 192 576 minecraft:orange_concrete
fill 276 192 578 276 192 580 minecraft:orange_concrete
fill 276 192 582 276 192 584 minecraft:orange_concrete
fill 276 192 586 276 192 588 minecraft:orange_concrete
fill 276 192 590 276 192 592 minecraft:orange_concrete
fill 276 192 594 276 192 596 minecraft:orange_concrete
fill 277 192 561 277 194 561 minecraft:orange_terracotta
setblock 277 192 563 minecraft:yellow_concrete
fill 277 192 564 277 197 565 minecraft:orange_terracotta
fill 277 192 566 277 193 567 minecraft:yellow_concrete
fill 277 192 572 277 197 573 minecraft:orange_terracotta
fill 277 192 574 277 192 575 minecraft:yellow_concrete
fill 277 192 584 277 197 585 minecraft:orange_terracotta
fill 277 192 586 277 193 587 minecraft:yellow_concrete
fill 277 192 593 277 197 593 minecraft:orange_terracotta
fill 277 192 594 277 192 595 minecraft:yellow_concrete
fill 277 192 596 277 197 596 minecraft:orange_terracotta
fill 277 192 598 277 193 598 minecraft:yellow_concrete
setblock 235 193 561 minecraft:yellow_concrete
fill 235 193 565 235 196 566 minecraft:orange_terracotta
setblock 235 193 582 minecraft:yellow_concrete
setblock 235 193 585 minecraft:yellow_concrete
fill 235 193 586 235 196 586 minecraft:orange_terracotta
setblock 235 193 593 minecraft:yellow_concrete
fill 235 193 597 235 196 597 minecraft:orange_terracotta
fill 242 193 557 242 196 557 minecraft:orange_terracotta
setblock 243 193 557 minecraft:yellow_concrete
setblock 246 193 557 minecraft:yellow_concrete
fill 249 193 599 250 193 599 minecraft:yellow_concrete
setblock 253 193 599 minecraft:yellow_concrete
fill 254 193 599 254 196 599 minecraft:orange_terracotta
fill 262 193 557 262 196 557 minecraft:orange_terracotta
setblock 263 193 557 minecraft:yellow_concrete
fill 265 193 599 265 196 599 minecraft:orange_terracotta
setblock 267 193 557 minecraft:yellow_concrete
setblock 270 193 599 minecraft:yellow_concrete
setblock 277 193 558 minecraft:yellow_concrete
fill 277 193 559 277 195 559 minecraft:orange_terracotta
fill 277 193 563 277 196 563 minecraft:orange_terracotta
fill 277 193 574 277 196 574 minecraft:orange_terracotta
setblock 277 193 575 minecraft:yellow_concrete
setblock 277 193 578 minecraft:yellow_concrete
fill 277 193 594 277 196 595 minecraft:orange_terracotta
fill 235 194 559 235 195 560 minecraft:yellow_concrete
fill 235 194 561 235 199 562 minecraft:orange_terracotta
setblock 235 194 563 minecraft:yellow_concrete
fill 235 194 571 235 195 572 minecraft:yellow_concrete
fill 235 194 573 235 199 574 minecraft:orange_terracotta
fill 235 194 580 235 195 580 minecraft:yellow_concrete
fill 235 194 582 235 199 582 minecraft:orange_terracotta
fill 235 194 583 235 194 584 minecraft:yellow_concrete
fill 235 194 585 235 199 585 minecraft:orange_terracotta
fill 235 194 591 235 195 592 minecraft:yellow_concrete
fill 235 194 593 235 199 594 minecraft:orange_terracotta
fill 236 194 557 237 195 557 minecraft:yellow_concrete
fill 239 194 599 240 194 599 minecraft:yellow_concrete
fill 241 194 599 242 199 599 minecraft:orange_terracotta
fill 243 194 557 243 199 557 minecraft:orange_terracotta
fill 244 194 557 245 194 557 minecraft:yellow_concrete
fill 246 194 557 246 199 557 minecraft:orange_terracotta
fill 248 194 557 248 195 557 minecraft:yellow_concrete
fill 248 194 599 248 195 599 minecraft:yellow_concrete
fill 249 194 599 250 199 599 minecraft:orange_terracotta
setblock 251 194 599 minecraft:yellow_concrete
fill 253 194 599 253 199 599 minecraft:orange_terracotta
fill 254 194 557 255 199 557 minecraft:orange_terracotta
fill 256 194 557 257 195 557 minecraft:yellow_concrete
fill 259 194 599 260 195 599 minecraft:yellow_concrete
fill 261 194 599 262 199 599 minecraft:orange_terracotta
fill 263 194 557 263 196 557 minecraft:orange_terracotta
setblock 265 194 557 minecraft:yellow_concrete
fill 266 194 557 267 199 557 minecraft:orange_terracotta
fill 268 194 557 269 195 557 minecraft:yellow_concrete
fill 270 194 599 270 199 599 minecraft:orange_terracotta
fill 271 194 599 272 194 599 minecraft:yellow_concrete
fill 273 194 599 274 199 599 minecraft:orange_terracotta
fill 274 194 557 275 199 557 minecraft:orange_terracotta
fill 276 194 557 277 194 557 minecraft:yellow_concrete
fill 277 194 558 277 195 558 minecraft:orange_terracotta
fill 277 194 566 277 199 567 minecraft:orange_terracotta
fill 277 194 568 277 195 569 minecraft:yellow_concrete
fill 277 194 575 277 199 575 minecraft:orange_terracotta
fill 277 194 576 277 194 577 minecraft:yellow_concrete
fill 277 194 578 277 199 578 minecraft:orange_terracotta
fill 277 194 580 277 195 580 minecraft:yellow_concrete
fill 277 194 586 277 199 587 minecraft:orange_terracotta
fill 277 194 588 277 195 589 minecraft:yellow_concrete
setblock 277 194 597 minecraft:yellow_concrete
fill 277 194 598 277 199 598 minecraft:orange_terracotta
fill 235 195 563 235 198 563 minecraft:orange_terracotta
setblock 235 195 568 minecraft:yellow_concrete
setblock 235 195 579 minecraft:yellow_concrete
fill 235 195 583 235 198 584 minecraft:orange_terracotta
setblock 236 195 599 minecraft:yellow_concrete
setblock 239 195 599 minecraft:yellow_concrete
fill 240 195 599 240 198 599 minecraft:orange_terracotta
fill 244 195 557 245 198 557 minecraft:orange_terracotta
setblock 247 195 599 minecraft:yellow_concrete
setblock 249 195 557 minecraft:yellow_concrete
fill 251 195 599 251 198 599 minecraft:orange_terracotta
setblock 260 195 557 minecraft:yellow_concrete
fill 261 195 557 261 197 557 minecraft:orange_terracotta
fill 265 195 557 265 198 557 minecraft:orange_terracotta
fill 267 195 599 268 195 599 minecraft:yellow_concrete
setblock 271 195 599 minecraft:yellow_concrete
fill 272 195 599 272 198 599 minecraft:orange_terracotta
fill 276 195 557 276 198 557 minecraft:orange_terracotta
setblock 277 195 557 minecraft:yellow_concrete
fill 277 195 560 277 195 561 minecraft:yellow_concrete
fill 277 195 576 277 197 577 minecraft:orange_terracotta
setblock 277 195 581 minecraft:yellow_concrete
setblock 277 195 592 minecraft:yellow_concrete
fill 277 195 597 277 198 597 minecraft:orange_terracotta
fill 235 196 557 235 197 558 minecraft:yellow_concrete
fill 235 196 559 235 201 560 minecraft:orange_terracotta
fill 235 196 568 235 201 568 minecraft:orange_terracotta
fill 235 196 569 235 196 570 minecraft:yellow_concrete
fill 235 196 571 235 201 572 minecraft:orange_terracotta
fill 235 196 577 235 197 578 minecraft:yellow_concrete
fill 235 196 579 235 201 580 minecraft:orange_terracotta
setblock 235 196 581 minecraft:yellow_concrete
fill 235 196 589 235 197 590 minecraft:yellow_concrete
fill 235 196 591 235 201 592 minecraft:orange_terracotta
fill 235 196 598 235 197 598 minecraft:yellow_concrete
fill 236 196 557 237 201 557 minecraft:orange_terracotta
fill 236 196 599 236 201 599 minecraft:orange_terracotta
fill 237 196 599 238 196 599 minecraft:yellow_concrete
fill 238 196 557 239 197 557 minecraft:yellow_concrete
fill 239 196 599 239 201 599 minecraft:orange_terracotta
fill 245 196 599 246 197 599 minecraft:yellow_concrete
setblock 247 196 557 minecraft:yellow_concrete
fill 247 196 599 248 201 599 minecraft:orange_terracotta
fill 248 196 557 249 201 557 minecraft:orange_terracotta
fill 250 196 557 251 197 557 minecraft:yellow_concrete
fill 256 196 557 257 201 557 minecraft:orange_terracotta
fill 257 196 599 258 196 599 minecraft:yellow_concrete
fill 258 196 557 259 196 557 minecraft:yellow_concrete
fill 259 196 599 260 201 599 minecraft:orange_terracotta
fill 260 196 557 260 201 557 minecraft:orange_terracotta
fill 266 196 599 266 197 599 minecraft:yellow_concrete
fill 267 196 599 268 201 599 minecraft:orange_terracotta
fill 268 196 557 269 201 557 minecraft:orange_terracotta
setblock 269 196 599 minecraft:yellow_concrete
fill 270 196 557 271 197 557 minecraft:yellow_concrete
fill 271 196 599 271 201 599 minecraft:orange_terracotta
fill 277 196 557 277 201 557 minecraft:orange_terracotta
fill 277 196 558 277 196 559 minecraft:yellow_concrete
fill 277 196 560 277 197 561 minecraft:orange_terracotta
fill 277 196 562 277 197 562 minecraft:yellow_concrete
fill 277 196 568 277 201 569 minecraft:orange_terracotta
fill 277 196 570 277 197 571 minecraft:yellow_concrete
setblock 277 196 579 minecraft:yellow_concrete
fill 277 196 580 277 201 581 minecraft:orange_terracotta
fill 277 196 582 277 197 583 minecraft:yellow_concrete
fill 277 196 588 277 201 589 minecraft:orange_terracotta
fill 277 196 590 277 196 591 minecraft:yellow_concrete
fill 277 196 592 277 201 592 minecraft:orange_terracotta
fill 277 196 599 277 197 599 minecraft:yellow_concrete
fill 235 197 565 235 197 566 minecraft:yellow_concrete
setblock 235 197 569 minecraft:yellow_concrete
fill 235 197 570 235 200 570 minecraft:orange_terracotta
fill 235 197 581 235 200 581 minecraft:orange_terracotta
setblock 235 197 586 minecraft:yellow_concrete
setblock 235 197 597 minecraft:yellow_concrete
fill 237 197 599 238 200 599 minecraft:orange_terracotta
setblock 242 197 557 minecraft:yellow_concrete
fill 247 197 557 247 200 557 minecraft:orange_terracotta
setblock 254 197 599 minecraft:yellow_concrete
setblock 257 197 599 minecraft:yellow_concrete
fill 258 197 557 258 200 557 minecraft:orange_terracotta
fill 258 197 599 258 200 599 minecraft:orange_terracotta
setblock 259 197 557 minecraft:yellow_concrete
fill 262 197 557 263 197 557 minecraft:yellow_concrete
setblock 265 197 599 minecraft:yellow_concrete
fill 269 197 599 269 200 599 minecraft:orange_terracotta
fill 277 197 558 277 199 559 minecraft:orange_terracotta
setblock 277 197 563 minecraft:yellow_concrete
setblock 277 197 574 minecraft:yellow_concrete
fill 277 197 579 277 199 579 minecraft:orange_terracotta
fill 277 197 590 277 200 590 minecraft:orange_terracotta
setblock 277 197 591 minecraft:yellow_concrete
fill 277 197 594 277 197 595 minecraft:yellow_concrete
fill 235 198 557 235 203 558 minecraft:orange_terracotta
fill 235 198 564 235 199 564 minecraft:yellow_concrete
fill 235 198 565 235 203 566 minecraft:orange_terracotta
setblock 235 198 567 minecraft:yellow_concrete
fill 235 198 569 235 203 569 minecraft:orange_terracotta
fill 235 198 575 235 199 576 minecraft:yellow_concrete
fill 235 198 577 235 203 578 minecraft:orange_terracotta
fill 235 198 586 235 203 586 minecraft:orange_terracotta
fill 235 198 587 235 198 588 minecraft:yellow_concrete
fill 235 198 589 235 203 590 minecraft:orange_terracotta
fill 235 198 595 235 199 596 minecraft:yellow_concrete
fill 235 198 597 235 203 598 minecraft:orange_terracotta
setblock 235 198 599 minecraft:yellow_concrete
fill 236 198 558 238 198 558 minecraft:orange_concrete
fill 236 198 560 236 198 562 minecraft:orange_concrete
fill 236 198 564 236 198 566 minecraft:orange_concrete
fill 236 198 568 236 198 570 minecraft:orange_concrete
fill 236 198 572 236 198 574 minecraft:orange_concrete
fill 236 198 576 236 198 578 minecraft:orange_concrete
fill 236 198 580 236 198 582 minecraft:orange_concrete
fill 236 198 584 236 198 586 minecraft:orange_concrete
fill 236 198 588 236 198 590 minecraft:orange_concrete
fill 236 198 592 236 198 594 minecraft:orange_concrete
fill 236 198 596 236 198 598 minecraft:orange_concrete
fill 238 198 557 239 203 557 minecraft:orange_terracotta
fill 238 198 598 240 198 598 minecraft:orange_concrete
fill 240 198 557 241 198 557 minecraft:yellow_concrete
fill 240 198 558 242 198 558 minecraft:orange_concrete
fill 242 198 557 242 203 557 minecraft:orange_terracotta
fill 242 198 598 244 198 598 minecraft:orange_concrete
fill 243 198 599 244 199 599 minecraft:yellow_concrete
fill 244 198 558 246 198 558 minecraft:orange_concrete
fill 245 198 599 246 202 599 minecraft:orange_terracotta
fill 246 198 598 248 198 598 minecraft:orange_concrete
fill 248 198 558 250 198 558 minecraft:orange_concrete
fill 250 198 557 251 203 557 minecraft:orange_terracotta
fill 250 198 598 252 198 598 minecraft:orange_concrete
fill 252 198 557 253 199 557 minecraft:yellow_concrete
fill 252 198 558 254 198 558 minecraft:orange_concrete
fill 252 198 599 252 199 599 minecraft:yellow_concrete
fill 254 198 598 256 198 598 minecraft:orange_concrete
fill 254 198 599 254 203 599 minecraft:orange_terracotta
fill 255 198 565 255 199 565 minecraft:yellow_concrete
fill 255 198 599 256 198 599 minecraft:yellow_concrete
fill 256 198 558 258 198 558 minecraft:orange_concrete
fill 257 198 599 257 203 599 minecraft:orange_terracotta
fill 258 198 598 260 198 598 minecraft:orange_concrete
fill 259 198 557 259 203 557 minecraft:orange_terracotta
fill 260 198 558 262 198 558 minecraft:orange_concrete
setblock 261 198 557 minecraft:yellow_concrete
fill 262 198 557 263 203 557 minecraft:orange_terracotta
fill 262 198 598 264 198 598 minecraft:orange_concrete
fill 263 198 599 264 199 599 minecraft:yellow_concrete
fill 264 198 557 264 199 557 minecraft:yellow_concrete
fill 264 198 558 266 198 558 minecraft:orange_concrete
fill 265 198 599 266 203 599 minecraft:orange_terracotta
fill 266 198 598 268 198 598 minecraft:orange_concrete
fill 268 198 558 270 198 558 minecraft:orange_concrete
fill 270 198 557 271 203 557 minecraft:orange_terracotta
fill 270 198 598 272 198 598 minecraft:orange_concrete
fill 272 198 557 273 199 557 minecraft:yellow_concrete
fill 272 198 558 274 198 558 minecraft:orange_concrete
fill 274 198 598 276 198 598 minecraft:orange_concrete
fill 275 198 599 276 198 599 minecraft:yellow_concrete
fill 276 198 558 276 198 560 minecraft:orange_concrete
fill 276 198 562 276 198 564 minecraft:orange_concrete
fill 276 198 566 276 198 568 minecraft:orange_concrete
fill 276 198 570 276 198 572 minecraft:orange_concrete
fill 276 198 574 276 198 576 minecraft:orange_concrete
fill 276 198 578 276 198 580 minecraft:orange_concrete
fill 276 198 582 276 198 584 minecraft:orange_concrete
fill 276 198 586 276 198 588 minecraft:orange_concrete
fill 276 198 590 276 198 592 minecraft:orange_concrete
fill 276 198 594 276 198 596 minecraft:orange_concrete
fill 277 198 560 277 201 560 minecraft:orange_terracotta
setblock 277 198 561 minecraft:yellow_concrete
fill 277 198 562 277 203 563 minecraft:orange_terracotta
fill 277 198 564 277 199 565 minecraft:yellow_concrete
fill 277 198 570 277 200 571 minecraft:orange_terracotta
fill 277 198 572 277 198 573 minecraft:yellow_concrete
fill 277 198 574 277 203 574 minecraft:orange_terracotta
fill 277 198 576 277 199 576 minecraft:yellow_concrete
setblock 277 198 577 minecraft:orange_terracotta
fill 277 198 582 277 203 583 minecraft:orange_terracotta
fill 277 198 584 277 199 585 minecraft:yellow_concrete
fill 277 198 591 277 203 591 minecraft:orange_terracotta
setblock 277 198 593 minecraft:yellow_concrete
fill 277 198 594 277 202 595 minecraft:orange_terracotta
fill 277 198 596 277 199 596 minecraft:yellow_concrete
fill 277 198 599 277 203 599 minecraft:orange_terracotta
setblock 235 199 563 minecraft:yellow_concrete
fill 235 199 567 235 202 567 minecraft:orange_terracotta
fill 235 199 583 235 199 584 minecraft:yellow_concrete
setblock 235 199 587 minecraft:yellow_concrete
fill 235 199 588 235 202 588 minecraft:orange_terracotta
fill 235 199 599 235 202 599 minecraft:orange_terracotta
setblock 238 199 560 minecraft:light[level=14]
setblock 238 199 568 minecraft:light[level=14]
setblock 238 199 576 minecraft:light[level=14]
setblock 238 199 584 minecraft:light[level=14]
setblock 238 199 592 minecraft:light[level=14]
fill 240 199 557 240 202 557 minecraft:orange_terracotta
setblock 240 199 599 minecraft:yellow_concrete
setblock 241 199 557 minecraft:yellow_concrete
fill 244 199 557 245 199 557 minecraft:yellow_concrete
setblock 246 199 560 minecraft:light[level=14]
setblock 246 199 568 minecraft:light[level=14]
setblock 246 199 576 minecraft:light[level=14]
setblock 246 199 584 minecraft:light[level=14]
setblock 246 199 592 minecraft:light[level=14]
setblock 251 199 599 minecraft:yellow_concrete
setblock 254 199 560 minecraft:light[level=14]
setblock 254 199 568 minecraft:light[level=14]
setblock 254 199 576 minecraft:light[level=14]
setblock 254 199 584 minecraft:light[level=14]
setblock 254 199 592 minecraft:light[level=14]
fill 255 199 599 256 202 599 minecraft:orange_terracotta
fill 261 199 557 261 202 557 minecraft:orange_terracotta
setblock 262 199 560 minecraft:light[level=14]
setblock 262 199 568 minecraft:light[level=14]
setblock 262 199 576 minecraft:light[level=14]
setblock 262 199 584 minecraft:light[level=14]
setblock 262 199 592 minecraft:light[level=14]
setblock 265 199 557 minecraft:yellow_concrete
setblock 270 199 560 minecraft:light[level=14]
setblock 270 199 568 minecraft:light[level=14]
setblock 270 199 576 minecraft:light[level=14]
setblock 270 199 584 minecraft:light[level=14]
setblock 270 199 592 minecraft:light[level=14]
setblock 272 199 599 minecraft:yellow_concrete
setblock 275 199 599 minecraft:yellow_concrete
setblock 276 199 557 minecraft:yellow_concrete
fill 276 199 599 276 202 599 minecraft:orange_terracotta
fill 277 199 561 277 201 561 minecraft:orange_terracotta
fill 277 199 572 277 202 572 minecraft:orange_terracotta
setblock 277 199 573 minecraft:yellow_concrete
setblock 277 199 577 minecraft:yellow_concrete
fill 277 199 593 277 202 593 minecraft:orange_terracotta
setblock 277 199 597 minecraft:yellow_concrete
fill 235 200 561 235 201 562 minecraft:yellow_concrete
fill 235 200 563 235 205 564 minecraft:orange_terracotta
fill 235 200 573 235 200 574 minecraft:yellow_concrete
fill 235 200 575 235 203 576 minecraft:orange_terracotta
fill 235 200 582 235 201 582 minecraft:yellow_concrete
fill 235 200 583 235 202 584 minecraft:orange_terracotta
setblock 235 200 585 minecraft:yellow_concrete
fill 235 200 587 235 205 587 minecraft:orange_terracotta
fill 235 200 593 235 201 594 minecraft:yellow_concrete
fill 235 200 595 235 203 596 minecraft:orange_terracotta
fill 240 200 599 240 202 599 minecraft:orange_terracotta
fill 241 200 557 241 202 557 minecraft:orange_terracotta
fill 241 200 599 242 200 599 minecraft:yellow_concrete
setblock 243 200 557 minecraft:yellow_concrete
fill 243 200 599 244 203 599 minecraft:orange_terracotta
fill 244 200 557 245 205 557 minecraft:orange_terracotta
fill 246 200 557 246 201 557 minecraft:yellow_concrete
fill 249 200 599 250 201 599 minecraft:yellow_concrete
fill 251 200 599 252 205 599 minecraft:orange_terracotta
fill 252 200 557 253 204 557 minecraft:orange_terracotta
setblock 253 200 599 minecraft:yellow_concrete
fill 254 200 557 255 200 557 minecraft:yellow_concrete
fill 261 200 599 262 201 599 minecraft:yellow_concrete
fill 263 200 599 264 202 599 minecraft:orange_terracotta
fill 264 200 557 265 202 557 minecraft:orange_terracotta
fill 266 200 557 267 201 557 minecraft:yellow_concrete
fill 270 200 599 270 201 599 minecraft:yellow_concrete
fill 272 200 557 273 202 557 minecraft:orange_terracotta
fill 272 200 599 272 205 599 minecraft:orange_terracotta
fill 273 200 599 274 200 599 minecraft:yellow_concrete
fill 274 200 557 275 200 557 minecraft:yellow_concrete
fill 275 200 599 275 205 599 minecraft:orange_terracotta
fill 276 200 557 276 205 557 minecraft:orange_terracotta
fill 277 200 558 277 201 558 minecraft:yellow_concrete
setblock 277 200 559 minecraft:orange_terracotta
fill 277 200 564 277 202 565 minecraft:orange_terracotta
fill 277 200 566 277 201 567 minecraft:yellow_concrete
fill 277 200 573 277 202 573 minecraft:orange_terracotta
setblock 277 200 575 minecraft:yellow_concrete
fill 277 200 576 277 205 577 minecraft:orange_terracotta
fill 277 200 578 277 201 579 minecraft:yellow_concrete
fill 277 200 584 277 203 585 minecraft:orange_terracotta
fill 277 200 586 277 200 587 minecraft:yellow_concrete
fill 277 200 596 277 202 597 minecraft:orange_terracotta
fill 277 200 598 277 201 598 minecraft:yellow_concrete
setblock 235 201 570 minecraft:yellow_concrete
setblock 235 201 573 minecraft:yellow_concrete
fill 235 201 574 235 203 574 minecraft:orange_terracotta
setblock 235 201 581 minecraft:yellow_concrete
fill 235 201 585 235 204 585 minecraft:orange_terracotta
fill 237 201 599 238 201 599 minecraft:yellow_concrete
setblock 241 201 599 minecraft:yellow_concrete
fill 242 201 599 242 204 599 minecraft:orange_terracotta
fill 243 201 557 243 204 557 minecraft:orange_terracotta
setblock 247 201 557 minecraft:yellow_concrete
fill 253 201 599 253 204 599 minecraft:orange_terracotta
fill 254 201 557 254 204 557 minecraft:orange_terracotta
setblock 255 201 557 minecraft:yellow_concrete
setblock 258 201 557 minecraft:yellow_concrete
setblock 258 201 599 minecraft:yellow_concrete
fill 259 201 589 260 202 591 minecraft:orange_concrete
setblock 269 201 599 minecraft:yellow_concrete
fill 273 201 599 274 203 599 minecraft:orange_terracotta
fill 274 201 557 274 202 557 minecraft:orange_terracotta
setblock 275 201 557 minecraft:yellow_concrete
setblock 277 201 559 minecraft:yellow_concrete
setblock 277 201 570 minecraft:yellow_concrete
fill 277 201 571 277 203 571 minecraft:orange_terracotta
fill 277 201 575 277 202 575 minecraft:orange_terracotta
fill 277 201 586 277 204 586 minecraft:orange_terracotta
setblock 277 201 587 minecraft:yellow_concrete
setblock 277 201 590 minecraft:yellow_concrete
fill 235 202 559 235 203 560 minecraft:yellow_concrete
fill 235 202 561 235 203 562 minecraft:orange_terracotta
fill 235 202 568 235 203 568 minecraft:yellow_concrete
fill 235 202 570 235 206 570 minecraft:orange_terracotta
fill 235 202 571 235 202 572 minecraft:yellow_concrete
fill 235 202 573 235 206 573 minecraft:orange_terracotta
fill 235 202 579 235 203 580 minecraft:yellow_concrete
fill 235 202 581 235 204 582 minecraft:orange_terracotta
fill 235 202 591 235 202 592 minecraft:yellow_concrete
fill 235 202 593 235 202 594 minecraft:orange_terracotta
fill 236 202 557 237 202 557 minecraft:yellow_concrete
fill 236 202 599 236 203 599 minecraft:yellow_concrete
fill 237 202 599 238 202 599 minecraft:orange_terracotta
setblock 239 202 599 minecraft:yellow_concrete
fill 241 202 599 241 206 599 minecraft:orange_terracotta
fill 246 202 557 247 204 557 minecraft:orange_terracotta
fill 247 202 599 248 203 599 minecraft:yellow_concrete
fill 248 202 557 249 203 557 minecraft:yellow_concrete
fill 249 202 599 250 206 599 minecraft:orange_terracotta
fill 255 202 557 255 206 557 minecraft:orange_terracotta
fill 256 202 557 257 202 557 minecraft:yellow_concrete
fill 258 202 557 258 203 557 minecraft:orange_terracotta
setblock 258 202 599 minecraft:orange_terracotta
fill 259 202 599 260 202 599 minecraft:yellow_concrete
fill 260 202 557 260 203 557 minecraft:yellow_concrete
fill 261 202 599 262 206 599 minecraft:orange_terracotta
fill 266 202 557 267 206 557 minecraft:orange_terracotta
fill 267 202 599 268 203 599 minecraft:yellow_concrete
fill 268 202 557 269 203 557 minecraft:yellow_concrete
fill 269 202 599 270 206 599 minecraft:orange_terracotta
setblock 271 202 599 minecraft:yellow_concrete
setblock 275 202 557 minecraft:orange_terracotta
setblock 277 202 557 minecraft:yellow_concrete
fill 277 202 558 277 206 559 minecraft:orange_terracotta
fill 277 202 560 277 203 561 minecraft:yellow_concrete
fill 277 202 566 277 206 567 minecraft:orange_terracotta
fill 277 202 568 277 202 569 minecraft:yellow_concrete
setblock 277 202 570 minecraft:orange_terracotta
fill 277 202 578 277 203 579 minecraft:orange_terracotta
fill 277 202 580 277 203 581 minecraft:yellow_concrete
fill 277 202 587 277 207 587 minecraft:orange_terracotta
fill 277 202 588 277 202 589 minecraft:yellow_concrete
fill 277 202 590 277 206 590 minecraft:orange_terracotta
fill 277 202 592 277 203 592 minecraft:yellow_concrete
fill 277 202 598 277 206 598 minecraft:orange_terracotta
setblock 235 203 567 minecraft:yellow_concrete
fill 235 203 571 235 204 572 minecraft:orange_terracotta
setblock 235 203 583 minecraft:red_concrete
fill 235 203 584 235 205 584 minecraft:orange_terracotta
setblock 235 203 588 minecraft:yellow_concrete
setblock 235 203 591 minecraft:yellow_concrete
fill 235 203 592 235 203 593 minecraft:red_concrete
fill 235 203 594 235 206 594 minecraft:orange_terracotta
setblock 235 203 599 minecraft:yellow_concrete
fill 236 203 557 236 206 557 minecraft:orange_terracotta
setblock 237 203 557 minecraft:yellow_concrete
fill 237 203 599 237 206 599 minecraft:orange_terracotta
setblock 238 203 599 minecraft:red_concrete
fill 239 203 599 239 206 599 minecraft:orange_terracotta
setblock 240 203 557 minecraft:yellow_concrete
setblock 240 203 599 minecraft:red_concrete
setblock 241 203 557 minecraft:red_concrete
setblock 245 203 599 minecraft:orange_terracotta
setblock 246 203 599 minecraft:red_concrete
fill 249 203 589 249 204 590 minecraft:yellow_concrete
fill 255 203 599 256 203 599 minecraft:yellow_concrete
fill 256 203 557 257 206 557 minecraft:orange_terracotta
fill 258 203 599 258 204 599 minecraft:red_concrete
setblock 259 203 599 minecraft:yellow_concrete
fill 260 203 599 260 206 599 minecraft:orange_terracotta
setblock 261 203 557 minecraft:yellow_concrete
setblock 263 203 599 minecraft:red_concrete
fill 264 203 557 264 204 557 minecraft:red_concrete
fill 264 203 599 264 205 599 minecraft:orange_terracotta
fill 265 203 557 265 205 557 minecraft:orange_terracotta
fill 271 203 599 271 206 599 minecraft:orange_terracotta
setblock 272 203 557 minecraft:yellow_concrete
fill 273 203 557 273 205 557 minecraft:orange_terracotta
fill 274 203 557 275 203 557 minecraft:red_concrete
setblock 276 203 599 minecraft:yellow_concrete
fill 277 203 557 277 206 557 minecraft:orange_terracotta
setblock 277 203 564 minecraft:red_concrete
fill 277 203 565 277 205 565 minecraft:orange_terracotta
setblock 277 203 568 minecraft:orange_terracotta
setblock 277 203 569 minecraft:yellow_concrete
setblock 277 203 570 minecraft:red_concrete
fill 277 203 572 277 203 573 minecraft:yellow_concrete
setblock 277 203 575 minecraft:red_concrete
fill 277 203 588 277 203 589 minecraft:orange_terracotta
setblock 277 203 593 minecraft:yellow_concrete
setblock 277 203 594 minecraft:red_concrete
setblock 277 203 595 minecraft:orange_terracotta
setblock 277 203 596 minecraft:red_concrete
setblock 277 203 597 minecraft:orange_terracotta
fill 235 204 557 235 204 558 minecraft:yellow_concrete
fill 235 204 559 235 206 560 minecraft:orange_terracotta
setblock 235 204 561 minecraft:red_concrete
fill 235 204 562 235 206 562 minecraft:orange_terracotta
fill 235 204 565 235 205 566 minecraft:yellow_concrete
fill 235 204 567 235 206 568 minecraft:orange_terracotta
setblock 235 204 569 minecraft:yellow_concrete
fill 235 204 574 235 204 575 minecraft:red_concrete
fill 235 204 576 235 205 576 minecraft:orange_terracotta
fill 235 204 577 235 205 578 minecraft:yellow_concrete
setblock 235 204 579 minecraft:red_concrete
fill 235 204 580 235 207 580 minecraft:orange_terracotta
fill 235 204 583 235 205 583 minecraft:orange_terracotta
fill 235 204 586 235 205 586 minecraft:yellow_concrete
fill 235 204 588 235 206 588 minecraft:orange_terracotta
fill 235 204 589 235 204 590 minecraft:yellow_concrete
fill 235 204 591 235 206 593 minecraft:orange_terracotta
fill 235 204 595 235 204 596 minecraft:red_concrete
fill 235 204 597 235 205 598 minecraft:yellow_concrete
fill 235 204 599 236 204 599 minecraft:orange_terracotta
fill 236 204 558 238 204 558 minecraft:orange_concrete
fill 236 204 560 236 204 562 minecraft:orange_concrete
fill 236 204 564 236 204 566 minecraft:orange_concrete
fill 236 204 568 236 204 570 minecraft:orange_concrete
fill 236 204 572 236 204 574 minecraft:orange_concrete
fill 236 204 576 236 204 578 minecraft:orange_concrete
fill 236 204 580 236 204 582 minecraft:orange_concrete
fill 236 204 584 236 204 586 minecraft:orange_concrete
fill 236 204 588 236 204 590 minecraft:orange_concrete
fill 236 204 592 236 204 594 minecraft:orange_concrete
fill 236 204 596 236 204 598 minecraft:orange_concrete
setblock 237 204 557 minecraft:red_concrete
fill 238 204 557 239 204 557 minecraft:yellow_concrete
fill 238 204 598 240 204 598 minecraft:orange_concrete
fill 238 204 599 238 206 599 minecraft:orange_terracotta
fill 240 204 557 241 205 557 minecraft:orange_terracotta
fill 240 204 558 242 204 558 minecraft:orange_concrete
fill 240 204 599 240 205 599 minecraft:orange_terracotta
fill 242 204 557 242 205 557 minecraft:yellow_concrete
fill 242 204 598 244 204 598 minecraft:orange_concrete
setblock 243 204 599 minecraft:red_concrete
fill 244 204 558 246 204 558 minecraft:orange_concrete
fill 244 204 599 244 205 599 minecraft:orange_terracotta
fill 245 204 599 246 204 599 minecraft:yellow_concrete
fill 246 204 598 248 204 598 minecraft:orange_concrete
fill 247 204 599 248 206 599 minecraft:orange_terracotta
fill 248 204 557 249 204 557 minecraft:orange_terracotta
fill 248 204 558 250 204 558 minecraft:orange_concrete
fill 250 204 557 251 205 557 minecraft:yellow_concrete
fill 250 204 598 252 204 598 minecraft:orange_concrete
fill 252 204 558 254 204 558 minecraft:orange_concrete
fill 254 204 598 256 204 598 minecraft:orange_concrete
fill 254 204 599 254 205 599 minecraft:yellow_concrete
fill 255 204 599 256 206 599 minecraft:orange_terracotta
fill 256 204 558 258 204 558 minecraft:orange_concrete
setblock 257 204 599 minecraft:yellow_concrete
setblock 258 204 557 minecraft:red_concrete
fill 258 204 598 260 204 598 minecraft:orange_concrete
setblock 259 204 557 minecraft:yellow_concrete
fill 259 204 599 259 206 599 minecraft:orange_terracotta
fill 260 204 557 261 206 557 minecraft:orange_terracotta
fill 260 204 558 262 204 558 minecraft:orange_concrete
fill 262 204 557 263 205 557 minecraft:yellow_concrete
fill 262 204 598 264 204 598 minecraft:orange_concrete
fill 263 204 599 263 205 599 minecraft:orange_terracotta
fill 264 204 558 266 204 558 minecraft:orange_concrete
fill 265 204 599 266 205 599 minecraft:yellow_concrete
fill 266 204 598 268 204 598 minecraft:orange_concrete
fill 267 204 599 267 206 599 minecraft:orange_terracotta
fill 268 204 557 269 206 557 minecraft:orange_terracotta
fill 268 204 558 270 204 558 minecraft:orange_concrete
setblock 268 204 599 minecraft:red_concrete
fill 270 204 557 271 204 557 minecraft:yellow_concrete
fill 270 204 598 272 204 598 minecraft:orange_concrete
fill 272 204 557 272 206 557 minecraft:orange_terracotta
fill 272 204 558 274 204 558 minecraft:orange_concrete
setblock 273 204 599 minecraft:red_concrete
fill 274 204 557 275 204 557 minecraft:orange_terracotta
fill 274 204 598 276 204 598 minecraft:orange_concrete
setblock 274 204 599 minecraft:orange_terracotta
fill 276 204 558 276 204 560 minecraft:orange_concrete
fill 276 204 562 276 204 564 minecraft:orange_concrete
fill 276 204 566 276 204 568 minecraft:orange_concrete
fill 276 204 570 276 204 572 minecraft:orange_concrete
fill 276 204 574 276 204 576 minecraft:orange_concrete
fill 276 204 578 276 204 580 minecraft:orange_concrete
fill 276 204 582 276 204 584 minecraft:orange_concrete
fill 276 204 586 276 204 588 minecraft:orange_concrete
fill 276 204 590 276 204 592 minecraft:orange_concrete
fill 276 204 594 276 204 596 minecraft:orange_concrete
setblock 276 204 599 minecraft:orange_terracotta
fill 277 204 560 277 204 561 minecraft:orange_terracotta
fill 277 204 562 277 205 563 minecraft:yellow_concrete
fill 277 204 564 277 205 564 minecraft:orange_terracotta
setblock 277 204 568 minecraft:red_concrete
fill 277 204 569 277 206 569 minecraft:orange_terracotta
fill 277 204 570 277 204 571 minecraft:yellow_concrete
fill 277 204 572 277 204 573 minecraft:orange_terracotta
fill 277 204 574 277 205 574 minecraft:yellow_concrete
setblock 277 204 575 minecraft:orange_terracotta
setblock 277 204 578 minecraft:red_concrete
fill 277 204 579 277 206 579 minecraft:orange_terracotta
setblock 277 204 580 minecraft:red_concrete
fill 277 204 581 277 206 581 minecraft:orange_terracotta
fill 277 204 582 277 205 583 minecraft:yellow_concrete
setblock 277 204 584 minecraft:red_concrete
fill 277 204 585 277 205 585 minecraft:orange_terracotta
setblock 277 204 588 minecraft:red_concrete
fill 277 204 589 277 206 589 minecraft:orange_terracotta
setblock 277 204 591 minecraft:yellow_concrete
fill 277 204 592 277 206 593 minecraft:orange_terracotta
fill 277 204 594 277 205 595 minecraft:yellow_concrete
fill 277 204 596 277 205 596 minecraft:orange_terracotta
setblock 277 204 597 minecraft:red_concrete
fill 277 204 599 277 205 599 minecraft:yellow_concrete
setblock 235 205 557 minecraft:yellow_concrete
fill 235 205 558 235 206 558 minecraft:orange_terracotta
fill 235 205 561 235 206 561 minecraft:orange_terracotta
fill 235 205 569 235 206 569 minecraft:orange_terracotta
setblock 235 205 571 minecraft:red_concrete
fill 235 205 572 235 206 572 minecraft:orange_terracotta
setblock 235 205 574 minecraft:yellow_concrete
setblock 235 205 575 minecraft:orange_terracotta
fill 235 205 579 235 206 579 minecraft:orange_terracotta
fill 235 205 581 235 206 581 minecraft:orange_terracotta
setblock 235 205 582 minecraft:red_concrete
setblock 235 205 585 minecraft:yellow_concrete
fill 235 205 589 235 206 590 minecraft:orange_terracotta
fill 235 205 595 235 205 596 minecraft:orange_terracotta
setblock 235 205 599 minecraft:red_concrete
fill 236 205 599 236 206 599 minecraft:orange_terracotta
fill 237 205 557 239 206 557 minecraft:orange_terracotta
setblock 242 205 599 minecraft:yellow_concrete
setblock 243 205 557 minecraft:yellow_concrete
setblock 243 205 599 minecraft:orange_terracotta
setblock 245 205 599 minecraft:yellow_concrete
setblock 246 205 557 minecraft:red_concrete
fill 246 205 599 246 206 599 minecraft:orange_terracotta
fill 247 205 557 247 206 557 minecraft:orange_terracotta
setblock 248 205 557 minecraft:red_concrete
fill 249 205 557 249 206 557 minecraft:orange_terracotta
fill 251 205 587 251 206 588 minecraft:shroomlight
setblock 252 205 557 minecraft:orange_terracotta
fill 252 205 587 252 206 587 minecraft:shroomlight
setblock 253 205 557 minecraft:red_concrete
setblock 253 205 599 minecraft:yellow_concrete
setblock 254 205 557 minecraft:yellow_concrete
setblock 257 205 599 minecraft:red_concrete
fill 258 205 557 259 206 557 minecraft:orange_terracotta
fill 258 205 599 258 206 599 minecraft:orange_terracotta
setblock 264 205 557 minecraft:orange_terracotta
fill 268 205 599 268 206 599 minecraft:orange_terracotta
fill 270 205 557 270 206 557 minecraft:orange_terracotta
setblock 271 205 557 minecraft:yellow_concrete
fill 273 205 599 274 205 599 minecraft:yellow_concrete
fill 274 205 557 275 205 557 minecraft:yellow_concrete
setblock 276 205 599 minecraft:red_concrete
fill 277 205 560 277 207 560 minecraft:orange_terracotta
setblock 277 205 561 minecraft:red_concrete
fill 277 205 568 277 206 568 minecraft:orange_terracotta
fill 277 205 570 277 206 571 minecraft:orange_terracotta
setblock 277 205 572 minecraft:red_concrete
setblock 277 205 573 minecraft:orange_terracotta
setblock 277 205 575 minecraft:yellow_concrete
fill 277 205 578 277 206 578 minecraft:orange_terracotta
fill 277 205 580 277 206 580 minecraft:orange_terracotta
setblock 277 205 584 minecraft:orange_terracotta
setblock 277 205 586 minecraft:yellow_concrete
setblock 277 205 588 minecraft:orange_terracotta
fill 277 205 591 277 206 591 minecraft:orange_terracotta
setblock 277 205 597 minecraft:orange_terracotta
setblock 235 206 557 minecraft:orange_terracotta
fill 235 206 563 235 207 564 minecraft:yellow_concrete
fill 235 206 565 235 206 566 minecraft:orange_terracotta
setblock 235 206 571 minecraft:orange_terracotta
setblock 235 206 574 minecraft:orange_terracotta
fill 235 206 575 235 206 576 minecraft:yellow_concrete
fill 235 206 577 235 206 578 minecraft:orange_terracotta
setblock 235 206 582 minecraft:orange_terracotta
fill 235 206 583 235 207 584 minecraft:yellow_concrete
fill 235 206 585 235 206 586 minecraft:orange_terracotta
setblock 235 206 587 minecraft:yellow_concrete
fill 235 206 595 235 207 596 minecraft:yellow_concrete
fill 235 206 597 235 206 599 minecraft:orange_terracotta
setblock 240 206 557 minecraft:orange_terracotta
fill 240 206 599 240 207 599 minecraft:yellow_concrete
setblock 241 206 557 minecraft:yellow_concrete
fill 242 206 557 243 206 557 minecraft:orange_terracotta
setblock 242 206 599 minecraft:orange_terracotta
fill 243 206 599 244 206 599 minecraft:yellow_concrete
fill 244 206 557 245 207 557 minecraft:yellow_concrete
setblock 245 206 599 minecraft:orange_terracotta
setblock 246 206 557 minecraft:orange_terracotta
setblock 248 206 557 minecraft:orange_terracotta
fill 250 206 557 251 206 557 minecraft:orange_terracotta
fill 251 206 599 252 207 599 minecraft:yellow_concrete
fill 252 206 557 253 206 557 minecraft:yellow_concrete
fill 253 206 599 254 206 599 minecraft:orange_terracotta
setblock 254 206 557 minecraft:orange_terracotta
fill 255 206 569 255 207 570 minecraft:orange_concrete
setblock 257 206 599 minecraft:orange_terracotta
fill 262 206 557 263 206 557 minecraft:orange_terracotta
fill 263 206 599 264 206 599 minecraft:yellow_concrete
fill 264 206 557 265 207 557 minecraft:yellow_concrete
fill 265 206 599 266 206 599 minecraft:orange_terracotta
setblock 271 206 557 minecraft:orange_terracotta
fill 272 206 599 272 207 599 minecraft:yellow_concrete
setblock 273 206 557 minecraft:yellow_concrete
fill 273 206 599 274 206 599 minecraft:orange_terracotta
fill 274 206 557 275 206 557 minecraft:orange_terracotta
setblock 275 206 599 minecraft:yellow_concrete
fill 276 206 557 276 207 557 minecraft:yellow_concrete
fill 276 206 599 277 206 599 minecraft:orange_terracotta
fill 277 206 561 277 206 563 minecraft:orange_terracotta
fill 277 206 564 277 207 565 minecraft:yellow_concrete
setblock 277 206 572 minecraft:orange_terracotta
setblock 277 206 573 minecraft:yellow_concrete
fill 277 206 574 277 206 575 minecraft:orange_terracotta
fill 277 206 576 277 207 577 minecraft:yellow_concrete
fill 277 206 582 277 206 583 minecraft:orange_terracotta
fill 277 206 584 277 206 585 minecraft:yellow_concrete
setblock 277 206 586 minecraft:orange_terracotta
fill 277 206 588 277 207 588 minecraft:yellow_concrete
fill 277 206 594 277 206 595 minecraft:orange_terracotta
fill 277 206 596 277 207 597 minecraft:yellow_concrete
fill 235 207 557 235 207 562 minecraft:red_concrete
fill 235 207 565 235 207 570 minecraft:red_concrete
fill 235 207 571 235 207 572 minecraft:yellow_concrete
fill 235 207 573 235 207 574 minecraft:red_concrete
setblock 235 207 575 minecraft:yellow_concrete
fill 235 207 576 235 207 577 minecraft:red_concrete
setblock 235 207 578 minecraft:orange_terracotta
fill 235 207 579 235 209 579 minecraft:red_concrete
fill 235 207 581 235 207 582 minecraft:red_concrete
fill 235 207 585 235 211 585 minecraft:red_concrete
setblock 235 207 586 minecraft:orange_terracotta
fill 235 207 587 235 207 589 minecraft:red_concrete
setblock 235 207 590 minecraft:orange_terracotta
setblock 235 207 591 minecraft:red_concrete
setblock 235 207 592 minecraft:yellow_concrete
fill 235 207 593 235 207 594 minecraft:red_concrete
fill 235 207 597 235 208 598 minecraft:red_concrete
setblock 235 207 599 minecraft:orange_terracotta
setblock 236 207 557 minecraft:yellow_concrete
fill 236 207 599 238 207 599 minecraft:red_concrete
fill 237 207 557 237 208 557 minecraft:orange_terracotta
fill 238 207 557 240 208 557 minecraft:red_concrete
setblock 238 207 560 minecraft:light[level=14]
setblock 238 207 568 minecraft:light[level=14]
setblock 238 207 576 minecraft:light[level=14]
setblock 238 207 584 minecraft:light[level=14]
setblock 238 207 592 minecraft:light[level=14]
setblock 239 207 599 minecraft:yellow_concrete
fill 241 207 557 242 207 557 minecraft:orange_terracotta
fill 241 207 599 250 207 599 minecraft:red_concrete
fill 243 207 557 243 211 557 minecraft:red_concrete
fill 246 207 557 252 207 557 minecraft:red_concrete
setblock 246 207 560 minecraft:light[level=14]
setblock 246 207 568 minecraft:light[level=14]
setblock 246 207 576 minecraft:light[level=14]
setblock 246 207 584 minecraft:light[level=14]
setblock 246 207 592 minecraft:light[level=14]
setblock 253 207 557 minecraft:yellow_concrete
fill 253 207 599 254 211 599 minecraft:red_concrete
fill 254 207 557 255 207 557 minecraft:red_concrete
setblock 254 207 560 minecraft:light[level=14]
setblock 254 207 568 minecraft:light[level=14]
setblock 254 207 576 minecraft:light[level=14]
setblock 254 207 584 minecraft:light[level=14]
setblock 254 207 592 minecraft:light[level=14]
setblock 255 207 599 minecraft:orange_terracotta
fill 256 207 557 257 207 557 minecraft:yellow_concrete
fill 256 207 599 259 207 599 minecraft:red_concrete
fill 258 207 557 263 207 557 minecraft:red_concrete
setblock 260 207 599 minecraft:yellow_concrete
fill 261 207 599 262 207 599 minecraft:red_concrete
setblock 262 207 560 minecraft:light[level=14]
setblock 262 207 568 minecraft:light[level=14]
setblock 262 207 576 minecraft:light[level=14]
setblock 262 207 584 minecraft:light[level=14]
setblock 262 207 592 minecraft:light[level=14]
setblock 263 207 599 minecraft:yellow_concrete
fill 264 207 599 269 207 599 minecraft:red_concrete
fill 266 207 557 275 207 557 minecraft:red_concrete
setblock 270 207 560 minecraft:light[level=14]
setblock 270 207 568 minecraft:light[level=14]
setblock 270 207 576 minecraft:light[level=14]
setblock 270 207 584 minecraft:light[level=14]
setblock 270 207 592 minecraft:light[level=14]
setblock 270 207 599 minecraft:orange_terracotta
setblock 271 207 599 minecraft:yellow_concrete
fill 273 207 599 277 207 599 minecraft:red_concrete
setblock 277 207 557 minecraft:yellow_concrete
fill 277 207 558 277 207 559 minecraft:red_concrete
setblock 277 207 561 minecraft:orange_terracotta
fill 277 207 562 277 207 563 minecraft:red_concrete
fill 277 207 566 277 207 567 minecraft:red_concrete
setblock 277 207 568 minecraft:yellow_concrete
fill 277 207 569 277 207 575 minecraft:red_concrete
fill 277 207 578 277 207 584 minecraft:red_concrete
setblock 277 207 585 minecraft:yellow_concrete
fill 277 207 586 277 208 586 minecraft:red_concrete
setblock 277 207 589 minecraft:yellow_concrete
fill 277 207 590 277 207 595 minecraft:red_concrete
setblock 277 207 598 minecraft:red_concrete
fill 235 208 557 235 208 560 minecraft:red_concrete
fill 235 208 561 235 208 562 minecraft:yellow_concrete
fill 235 208 563 235 208 564 minecraft:orange_terracotta
fill 235 208 565 235 208 569 minecraft:red_concrete
fill 235 208 570 235 209 570 minecraft:yellow_concrete
fill 235 208 571 235 208 572 minecraft:red_concrete
setblock 235 208 573 minecraft:yellow_concrete
fill 235 208 574 235 210 576 minecraft:red_concrete
fill 235 208 577 235 209 577 minecraft:orange_terracotta
fill 235 208 578 235 211 578 minecraft:red_concrete
fill 235 208 580 235 209 580 minecraft:red_concrete
fill 235 208 581 235 209 582 minecraft:yellow_concrete
fill 235 208 583 235 213 584 minecraft:red_concrete
setblock 235 208 586 minecraft:red_concrete
fill 235 208 587 235 208 588 minecraft:orange_terracotta
fill 235 208 589 235 208 590 minecraft:red_concrete
setblock 235 208 591 minecraft:orange_terracotta
fill 235 208 592 235 213 592 minecraft:red_concrete
fill 235 208 593 235 208 594 minecraft:yellow_concrete
fill 235 208 595 235 213 596 minecraft:red_concrete
fill 235 208 599 236 209 599 minecraft:red_concrete
fill 236 208 557 236 213 557 minecraft:red_concrete
fill 237 208 599 238 209 599 minecraft:yellow_concrete
fill 239 208 599 240 213 599 minecraft:red_concrete
fill 241 208 557 242 210 557 minecraft:red_concrete
setblock 241 208 599 minecraft:yellow_concrete
fill 242 208 599 243 210 599 minecraft:red_concrete
fill 244 208 557 245 213 557 minecraft:red_concrete
fill 244 208 599 244 209 599 minecraft:orange_terracotta
fill 245 208 599 245 211 599 minecraft:red_concrete
fill 246 208 557 247 209 557 minecraft:yellow_concrete
setblock 246 208 599 minecraft:orange_terracotta
fill 247 208 599 248 209 599 minecraft:red_concrete
fill 248 208 557 254 208 557 minecraft:red_concrete
fill 249 208 599 250 209 599 minecraft:yellow_concrete
fill 251 208 599 252 213 599 minecraft:red_concrete
setblock 255 208 557 minecraft:yellow_concrete
fill 255 208 599 256 209 599 minecraft:red_concrete
fill 256 208 557 257 213 557 minecraft:red_concrete
setblock 257 208 599 minecraft:orange_terracotta
fill 258 208 557 258 209 557 minecraft:yellow_concrete
fill 258 208 599 258 209 599 minecraft:yellow_concrete
fill 259 208 557 263 208 557 minecraft:red_concrete
fill 259 208 599 260 209 599 minecraft:red_concrete
fill 261 208 599 262 208 599 minecraft:yellow_concrete
fill 263 208 599 268 209 599 minecraft:red_concrete
setblock 264 208 557 minecraft:orange_terracotta
fill 265 208 557 265 213 557 minecraft:red_concrete
fill 266 208 557 267 208 557 minecraft:yellow_concrete
fill 268 208 557 270 208 557 minecraft:red_concrete
fill 269 208 599 270 209 599 minecraft:yellow_concrete
setblock 271 208 557 minecraft:orange_terracotta
fill 271 208 599 274 208 599 minecraft:red_concrete
fill 272 208 557 277 208 557 minecraft:red_concrete
setblock 275 208 599 minecraft:orange_terracotta
fill 276 208 599 277 209 599 minecraft:red_concrete
fill 277 208 558 277 209 559 minecraft:yellow_concrete
fill 277 208 560 277 209 561 minecraft:red_concrete
fill 277 208 562 277 209 562 minecraft:orange_terracotta
fill 277 208 563 277 210 565 minecraft:red_concrete
fill 277 208 566 277 208 567 minecraft:yellow_concrete
fill 277 208 568 277 209 569 minecraft:red_concrete
fill 277 208 570 277 209 570 minecraft:yellow_concrete
fill 277 208 571 277 208 577 minecraft:red_concrete
fill 277 208 578 277 209 579 minecraft:yellow_concrete
fill 277 208 580 277 208 584 minecraft:red_concrete
setblock 277 208 585 minecraft:orange_terracotta
setblock 277 208 587 minecraft:yellow_concrete
fill 277 208 588 277 213 589 minecraft:red_concrete
fill 277 208 590 277 209 591 minecraft:yellow_concrete
setblock 277 208 592 minecraft:orange_terracotta
fill 277 208 593 277 208 597 minecraft:red_concrete
setblock 277 208 598 minecraft:yellow_concrete
fill 235 209 557 235 211 557 minecraft:red_concrete
setblock 235 209 558 minecraft:yellow_concrete
setblock 235 209 559 minecraft:red_concrete
setblock 235 209 560 minecraft:orange_terracotta
setblock 235 209 561 minecraft:yellow_concrete
setblock 235 209 562 minecraft:orange_terracotta
fill 235 209 563 235 209 568 minecraft:red_concrete
setblock 235 209 569 minecraft:yellow_concrete
setblock 235 209 571 minecraft:orange_terracotta
fill 235 209 572 235 213 572 minecraft:red_concrete
setblock 235 209 573 minecraft:orange_terracotta
setblock 235 209 586 minecraft:orange_terracotta
fill 235 209 587 235 209 588 minecraft:red_concrete
fill 235 209 589 235 209 590 minecraft:yellow_concrete
setblock 235 209 591 minecraft:red_concrete
setblock 235 209 593 minecraft:yellow_concrete
fill 235 209 594 235 212 594 minecraft:red_concrete
fill 235 209 597 235 211 597 minecraft:red_concrete
setblock 235 209 598 minecraft:orange_terracotta
setblock 237 209 557 minecraft:red_concrete
fill 238 209 557 239 209 557 minecraft:yellow_concrete
setblock 240 209 557 minecraft:red_concrete
fill 241 209 599 241 212 599 minecraft:red_concrete
setblock 246 209 599 minecraft:yellow_concrete
setblock 248 209 557 minecraft:orange_terracotta
fill 249 209 557 255 209 557 minecraft:red_concrete
setblock 257 209 599 minecraft:yellow_concrete
setblock 259 209 557 minecraft:yellow_concrete
fill 260 209 557 264 209 557 minecraft:red_concrete
fill 261 209 599 262 212 599 minecraft:red_concrete
fill 266 209 557 266 212 557 minecraft:red_concrete
setblock 267 209 557 minecraft:yellow_concrete
setblock 268 209 557 minecraft:orange_terracotta
setblock 269 209 557 minecraft:red_concrete
setblock 270 209 557 minecraft:yellow_concrete
fill 271 209 557 271 211 557 minecraft:red_concrete
fill 271 209 599 272 209 599 minecraft:orange_terracotta
setblock 272 209 557 minecraft:orange_terracotta
fill 273 209 557 277 210 557 minecraft:red_concrete
fill 273 209 599 273 211 599 minecraft:red_concrete
setblock 274 209 599 minecraft:orange_terracotta
fill 275 209 599 275 210 599 minecraft:red_concrete
setblock 277 209 566 minecraft:orange_terracotta
setblock 277 209 567 minecraft:yellow_concrete
setblock 277 209 571 minecraft:yellow_concrete
fill 277 209 572 277 209 577 minecraft:red_concrete
setblock 277 209 580 minecraft:orange_terracotta
setblock 277 209 581 minecraft:red_concrete
setblock 277 209 582 minecraft:yellow_concrete
fill 277 209 583 277 210 585 minecraft:red_concrete
setblock 277 209 586 minecraft:orange_terracotta
fill 277 209 587 277 212 587 minecraft:red_concrete
fill 277 209 592 277 209 595 minecraft:red_concrete
setblock 277 209 596 minecraft:orange_terracotta
fill 277 209 597 277 212 598 minecraft:red_concrete
fill 235 210 558 235 215 558 minecraft:red_concrete
fill 235 210 559 235 210 560 minecraft:yellow_concrete
fill 235 210 561 235 211 566 minecraft:red_concrete
fill 235 210 567 235 211 568 minecraft:yellow_concrete
fill 235 210 569 235 213 571 minecraft:red_concrete
fill 235 210 573 235 212 573 minecraft:red_concrete
fill 235 210 577 235 211 577 minecraft:red_concrete
fill 235 210 579 235 210 580 minecraft:yellow_concrete
fill 235 210 581 235 215 582 minecraft:red_concrete
fill 235 210 586 235 210 587 minecraft:red_concrete
fill 235 210 588 235 211 588 minecraft:yellow_concrete
fill 235 210 589 235 215 590 minecraft:red_concrete
setblock 235 210 591 minecraft:yellow_concrete
fill 235 210 593 235 215 593 minecraft:red_concrete
fill 235 210 598 235 211 598 minecraft:red_concrete
fill 235 210 599 236 211 599 minecraft:yellow_concrete
fill 236 210 558 238 210 558 minecraft:orange_concrete
fill 236 210 560 236 210 562 minecraft:orange_concrete
fill 236 210 564 236 210 566 minecraft:orange_concrete
fill 236 210 568 236 210 570 minecraft:orange_concrete
fill 236 210 572 236 210 574 minecraft:orange_concrete
fill 236 210 576 236 210 578 minecraft:orange_concrete
fill 236 210 580 236 210 582 minecraft:orange_concrete
fill 236 210 584 236 210 586 minecraft:orange_concrete
fill 236 210 588 236 210 590 minecraft:orange_concrete
fill 236 210 592 236 210 594 minecraft:orange_concrete
fill 236 210 596 236 210 598 minecraft:orange_concrete
setblock 237 210 557 minecraft:yellow_concrete
fill 237 210 599 238 215 599 minecraft:red_concrete
fill 238 210 557 239 215 557 minecraft:red_concrete
fill 238 210 598 240 210 598 minecraft:orange_concrete
fill 240 210 557 240 211 557 minecraft:yellow_concrete
fill 240 210 558 242 210 558 minecraft:orange_concrete
fill 242 210 598 244 210 598 minecraft:orange_concrete
fill 244 210 558 246 210 558 minecraft:orange_concrete
setblock 244 210 599 minecraft:red_concrete
fill 246 210 557 247 215 557 minecraft:red_concrete
fill 246 210 598 248 210 598 minecraft:orange_concrete
fill 246 210 599 246 215 599 minecraft:red_concrete
fill 247 210 599 248 210 599 minecraft:yellow_concrete
fill 248 210 557 249 210 557 minecraft:yellow_concrete
fill 248 210 558 250 210 558 minecraft:orange_concrete
fill 249 210 599 250 215 599 minecraft:red_concrete
fill 250 210 557 255 210 557 minecraft:red_concrete
fill 250 210 598 252 210 598 minecraft:orange_concrete
fill 252 210 558 254 210 558 minecraft:orange_concrete
fill 254 210 598 256 210 598 minecraft:orange_concrete
fill 255 210 599 256 211 599 minecraft:yellow_concrete
fill 256 210 558 258 210 558 minecraft:orange_concrete
fill 257 210 599 258 215 599 minecraft:red_concrete
fill 258 210 557 259 215 557 minecraft:red_concrete
fill 258 210 598 260 210 598 minecraft:orange_concrete
setblock 259 210 599 minecraft:yellow_concrete
fill 260 210 557 261 211 557 minecraft:yellow_concrete
fill 260 210 558 262 210 558 minecraft:orange_concrete
fill 260 210 599 260 213 599 minecraft:red_concrete
fill 262 210 557 264 211 557 minecraft:red_concrete
fill 262 210 598 264 210 598 minecraft:orange_concrete
fill 263 210 599 266 210 599 minecraft:red_concrete
fill 264 210 558 266 210 558 minecraft:orange_concrete
fill 266 210 598 268 210 598 minecraft:orange_concrete
fill 267 210 557 267 215 557 minecraft:red_concrete
fill 267 210 599 268 211 599 minecraft:yellow_concrete
fill 268 210 557 269 210 557 minecraft:yellow_concrete
fill 268 210 558 270 210 558 minecraft:orange_concrete
fill 269 210 599 272 213 599 minecraft:red_concrete
fill 270 210 557 270 215 557 minecraft:red_concrete
fill 270 210 598 272 210 598 minecraft:orange_concrete
fill 272 210 557 272 211 557 minecraft:yellow_concrete
fill 272 210 558 274 210 558 minecraft:orange_concrete
fill 274 210 598 276 210 598 minecraft:orange_concrete
fill 274 210 599 274 211 599 minecraft:red_concrete
fill 276 210 558 276 210 560 minecraft:orange_concrete
fill 276 210 562 276 210 564 minecraft:orange_concrete
fill 276 210 566 276 210 568 minecraft:orange_concrete
fill 276 210 570 276 210 572 minecraft:orange_concrete
fill 276 210 574 276 210 576 minecraft:orange_concrete
fill 276 210 578 276 210 580 minecraft:orange_concrete
fill 276 210 582 276 210 584 minecraft:orange_concrete
fill 276 210 586 276 210 588 minecraft:orange_concrete
fill 276 210 590 276 210 592 minecraft:orange_concrete
fill 276 210 594 276 210 596 minecraft:orange_concrete
fill 276 210 599 276 211 599 minecraft:yellow_concrete
fill 277 210 558 277 215 559 minecraft:red_concrete
fill 277 210 560 277 211 561 minecraft:yellow_concrete
fill 277 210 562 277 211 562 minecraft:red_concrete
fill 277 210 566 277 212 568 minecraft:red_concrete
setblock 277 210 569 minecraft:yellow_concrete
fill 277 210 570 277 215 571 minecraft:red_concrete
fill 277 210 572 277 211 573 minecraft:yellow_concrete
fill 277 210 574 277 211 579 minecraft:red_concrete
fill 277 210 580 277 210 581 minecraft:yellow_concrete
fill 277 210 582 277 211 582 minecraft:red_concrete
fill 277 210 586 277 211 586 minecraft:red_concrete
fill 277 210 590 277 215 591 minecraft:red_concrete
fill 277 210 592 277 211 593 minecraft:yellow_concrete
fill 277 210 594 277 211 596 minecraft:red_concrete
fill 277 210 599 277 211 599 minecraft:red_concrete
fill 235 211 559 235 214 560 minecraft:red_concrete
fill 235 211 574 235 211 575 minecraft:red_concrete
setblock 235 211 576 minecraft:yellow_concrete
setblock 235 211 579 minecraft:yellow_concrete
fill 235 211 580 235 214 580 minecraft:red_concrete
setblock 235 211 586 minecraft:red_concrete
setblock 235 211 587 minecraft:yellow_concrete
fill 235 211 591 235 214 591 minecraft:red_concrete
fill 237 211 557 237 214 557 minecraft:red_concrete
setblock 241 211 557 minecraft:yellow_concrete
setblock 242 211 557 minecraft:red_concrete
setblock 242 211 599 minecraft:red_concrete
fill 243 211 599 244 211 599 minecraft:yellow_concrete
setblock 247 211 599 minecraft:yellow_concrete
fill 248 211 557 248 214 557 minecraft:red_concrete
fill 248 211 599 248 214 599 minecraft:red_concrete
setblock 249 211 557 minecraft:yellow_concrete
fill 250 211 557 251 211 557 minecraft:red_concrete
setblock 252 211 557 minecraft:yellow_concrete
fill 253 211 557 255 211 557 minecraft:red_concrete
fill 259 211 599 259 214 599 minecraft:red_concrete
fill 263 211 599 263 213 599 minecraft:red_concrete
setblock 264 211 599 minecraft:yellow_concrete
fill 265 211 599 266 211 599 minecraft:red_concrete
fill 268 211 557 269 214 557 minecraft:red_concrete
setblock 273 211 557 minecraft:yellow_concrete
fill 274 211 557 277 211 557 minecraft:red_concrete
setblock 275 211 599 minecraft:yellow_concrete
setblock 277 211 563 minecraft:red_concrete
schedule function dropper:buildpart/137_4 1t
