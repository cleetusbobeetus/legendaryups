fill 269 182 237 276 182 237 minecraft:sea_lantern
setblock 269 182 261 minecraft:black_stained_glass
setblock 269 182 269 minecraft:light_blue_stained_glass
setblock 271 182 243 minecraft:cyan_stained_glass
setblock 271 182 245 minecraft:ochre_froglight
setblock 271 182 247 minecraft:cyan_stained_glass
setblock 271 182 249 minecraft:light_blue_stained_glass
setblock 271 182 251 minecraft:cyan_stained_glass
setblock 271 182 253 minecraft:black_stained_glass
setblock 271 182 261 minecraft:magenta_stained_glass
setblock 271 182 269 minecraft:black_stained_glass
fill 272 182 233 272 188 233 minecraft:iron_bars
setblock 272 182 242 minecraft:ochre_froglight
setblock 272 182 255 minecraft:black_stained_glass
setblock 273 182 261 minecraft:black_stained_glass
setblock 273 182 269 minecraft:black_stained_glass
setblock 274 182 242 minecraft:magenta_stained_glass
setblock 274 182 255 minecraft:cyan_stained_glass
setblock 275 182 261 minecraft:black_stained_glass
setblock 275 182 269 minecraft:ochre_froglight
fill 276 182 230 276 182 236 minecraft:sea_lantern
setblock 276 182 243 minecraft:sea_lantern
setblock 276 182 245 minecraft:magenta_stained_glass
setblock 276 182 247 minecraft:cyan_stained_glass
setblock 276 182 249 minecraft:black_stained_glass
setblock 276 182 251 minecraft:black_stained_glass
setblock 276 182 253 minecraft:light_blue_stained_glass
setblock 276 182 262 minecraft:black_stained_glass
setblock 276 182 264 minecraft:sea_lantern
setblock 276 182 266 minecraft:black_stained_glass
setblock 276 182 268 minecraft:pearlescent_froglight
setblock 277 182 229 minecraft:cyan_concrete
fill 235 183 230 235 242 230 minecraft:black_concrete
fill 236 183 230 236 184 230 minecraft:gray_concrete
fill 236 183 232 236 184 232 minecraft:gray_concrete
fill 236 183 234 236 184 234 minecraft:gray_concrete
fill 236 183 236 236 184 236 minecraft:gray_concrete
fill 236 183 243 236 184 243 minecraft:black_concrete
fill 236 183 245 236 184 245 minecraft:black_concrete
fill 236 183 247 236 184 247 minecraft:black_concrete
fill 236 183 249 236 184 249 minecraft:black_concrete
fill 236 183 251 236 184 251 minecraft:black_concrete
fill 236 183 253 236 184 253 minecraft:black_concrete
fill 237 183 228 237 192 228 minecraft:black_concrete
fill 237 183 229 237 184 229 minecraft:gray_concrete
fill 237 183 237 237 184 237 minecraft:gray_concrete
fill 237 183 242 237 184 242 minecraft:black_concrete
fill 237 183 255 237 184 255 minecraft:black_concrete
setblock 238 183 228 minecraft:verdant_froglight
fill 239 183 229 239 184 229 minecraft:gray_concrete
fill 239 183 237 239 184 237 minecraft:gray_concrete
fill 239 183 242 239 184 242 minecraft:black_concrete
fill 239 183 255 239 184 255 minecraft:black_concrete
fill 239 183 270 239 274 270 minecraft:black_concrete
fill 241 183 229 241 184 229 minecraft:gray_concrete
fill 241 183 237 241 184 237 minecraft:gray_concrete
fill 241 183 243 241 184 243 minecraft:black_concrete
fill 241 183 245 241 184 245 minecraft:black_concrete
fill 241 183 247 241 184 247 minecraft:black_concrete
fill 241 183 249 241 184 249 minecraft:black_concrete
fill 241 183 251 241 184 251 minecraft:black_concrete
fill 241 183 253 241 184 253 minecraft:black_concrete
fill 243 183 229 243 184 229 minecraft:gray_concrete
fill 243 183 237 243 184 237 minecraft:gray_concrete
fill 244 183 230 244 184 230 minecraft:gray_concrete
fill 244 183 232 244 184 232 minecraft:gray_concrete
fill 244 183 234 244 184 234 minecraft:gray_concrete
fill 244 183 236 244 184 236 minecraft:gray_concrete
setblock 245 183 228 minecraft:magenta_concrete
fill 249 183 265 249 184 265 minecraft:gray_concrete
fill 249 183 267 249 184 267 minecraft:gray_concrete
fill 250 183 264 250 184 264 minecraft:gray_concrete
fill 250 183 269 250 184 269 minecraft:gray_concrete
fill 252 183 264 252 184 264 minecraft:gray_concrete
fill 252 183 269 252 184 269 minecraft:gray_concrete
setblock 252 183 270 minecraft:blue_concrete
fill 254 183 228 254 186 228 minecraft:black_concrete
fill 254 183 264 254 184 264 minecraft:gray_concrete
fill 254 183 269 254 184 269 minecraft:gray_concrete
fill 256 183 264 256 184 264 minecraft:gray_concrete
fill 256 183 269 256 184 269 minecraft:gray_concrete
fill 258 183 264 258 184 264 minecraft:gray_concrete
fill 258 183 269 258 184 269 minecraft:gray_concrete
fill 259 183 228 259 195 228 minecraft:black_concrete
fill 260 183 264 260 184 264 minecraft:gray_concrete
fill 260 183 269 260 184 269 minecraft:gray_concrete
fill 262 183 265 262 184 265 minecraft:gray_concrete
fill 262 183 267 262 184 267 minecraft:gray_concrete
fill 268 183 262 268 184 262 minecraft:gray_concrete
fill 268 183 264 268 185 264 minecraft:gray_concrete
fill 268 183 266 268 185 266 minecraft:gray_concrete
fill 268 183 268 268 185 268 minecraft:gray_concrete
fill 269 183 261 269 184 261 minecraft:gray_concrete
fill 269 183 269 269 185 269 minecraft:gray_concrete
fill 271 183 243 271 184 243 minecraft:gray_concrete
fill 271 183 245 271 184 245 minecraft:gray_concrete
fill 271 183 247 271 184 247 minecraft:gray_concrete
fill 271 183 249 271 184 249 minecraft:gray_concrete
fill 271 183 251 271 184 251 minecraft:gray_concrete
fill 271 183 253 271 184 253 minecraft:gray_concrete
fill 271 183 261 271 185 261 minecraft:gray_concrete
fill 271 183 269 271 185 269 minecraft:gray_concrete
fill 272 183 242 272 184 242 minecraft:gray_concrete
fill 272 183 255 272 184 255 minecraft:gray_concrete
fill 273 183 261 273 185 261 minecraft:gray_concrete
fill 273 183 269 273 185 269 minecraft:gray_concrete
fill 274 183 242 274 184 242 minecraft:gray_concrete
fill 274 183 255 274 184 255 minecraft:gray_concrete
fill 275 183 261 275 185 261 minecraft:gray_concrete
fill 275 183 269 275 185 269 minecraft:gray_concrete
fill 276 183 243 276 184 243 minecraft:gray_concrete
fill 276 183 245 276 184 245 minecraft:gray_concrete
fill 276 183 247 276 184 247 minecraft:gray_concrete
fill 276 183 249 276 184 249 minecraft:gray_concrete
fill 276 183 251 276 184 251 minecraft:gray_concrete
fill 276 183 253 276 184 253 minecraft:gray_concrete
fill 276 183 262 276 185 262 minecraft:gray_concrete
fill 276 183 264 276 185 264 minecraft:gray_concrete
fill 276 183 266 276 185 266 minecraft:gray_concrete
fill 276 183 268 276 185 268 minecraft:gray_concrete
fill 277 183 229 277 251 229 minecraft:black_concrete
setblock 277 183 255 minecraft:purple_concrete
setblock 235 184 238 minecraft:pearlescent_froglight
fill 235 184 239 235 275 239 minecraft:black_concrete
fill 238 184 228 238 216 228 minecraft:black_concrete
setblock 241 184 270 minecraft:purple_concrete
fill 245 184 228 245 202 228 minecraft:black_concrete
setblock 245 184 270 minecraft:cyan_concrete
setblock 247 184 270 minecraft:sea_lantern
fill 252 184 270 252 293 270 minecraft:black_concrete
fill 277 184 255 277 222 255 minecraft:black_concrete
fill 235 185 238 235 285 238 minecraft:black_concrete
setblock 236 185 230 minecraft:black_stained_glass
setblock 236 185 232 minecraft:black_stained_glass
setblock 236 185 234 minecraft:black_stained_glass
setblock 236 185 236 minecraft:black_stained_glass
setblock 236 185 243 minecraft:black_stained_glass
setblock 236 185 245 minecraft:sea_lantern
setblock 236 185 247 minecraft:black_stained_glass
setblock 236 185 249 minecraft:ochre_froglight
setblock 236 185 251 minecraft:black_stained_glass
setblock 236 185 253 minecraft:sea_lantern
setblock 237 185 229 minecraft:black_stained_glass
setblock 237 185 237 minecraft:sea_lantern
setblock 237 185 242 minecraft:black_stained_glass
setblock 237 185 255 minecraft:black_stained_glass
setblock 238 185 239 minecraft:light[level=15]
setblock 238 185 263 minecraft:light[level=15]
setblock 239 185 229 minecraft:cyan_stained_glass
setblock 239 185 237 minecraft:cyan_stained_glass
setblock 239 185 242 minecraft:pearlescent_froglight
setblock 239 185 255 minecraft:pearlescent_froglight
setblock 241 185 229 minecraft:cyan_stained_glass
setblock 241 185 237 minecraft:magenta_stained_glass
setblock 241 185 243 minecraft:black_stained_glass
setblock 241 185 245 minecraft:black_stained_glass
setblock 241 185 247 minecraft:sea_lantern
setblock 241 185 249 minecraft:black_stained_glass
setblock 241 185 251 minecraft:black_stained_glass
setblock 241 185 253 minecraft:black_stained_glass
fill 241 185 270 241 228 270 minecraft:black_concrete
setblock 243 185 229 minecraft:black_stained_glass
setblock 243 185 237 minecraft:pearlescent_froglight
setblock 244 185 230 minecraft:sea_lantern
setblock 244 185 232 minecraft:magenta_stained_glass
setblock 244 185 234 minecraft:ochre_froglight
setblock 244 185 236 minecraft:ochre_froglight
fill 245 185 270 245 188 270 minecraft:black_concrete
setblock 246 185 231 minecraft:light[level=15]
setblock 246 185 239 minecraft:light[level=15]
setblock 246 185 247 minecraft:light[level=15]
setblock 246 185 255 minecraft:light[level=15]
setblock 246 185 263 minecraft:light[level=15]
fill 247 185 270 247 199 270 minecraft:black_concrete
setblock 249 185 265 minecraft:sea_lantern
setblock 249 185 267 minecraft:magenta_stained_glass
setblock 250 185 264 minecraft:black_stained_glass
setblock 250 185 269 minecraft:pearlescent_froglight
setblock 252 185 264 minecraft:black_stained_glass
setblock 252 185 269 minecraft:sea_lantern
setblock 254 185 231 minecraft:light[level=15]
setblock 254 185 239 minecraft:light[level=15]
setblock 254 185 247 minecraft:light[level=15]
setblock 254 185 255 minecraft:light[level=15]
setblock 254 185 263 minecraft:light[level=15]
setblock 254 185 264 minecraft:magenta_stained_glass
setblock 254 185 269 minecraft:magenta_stained_glass
setblock 256 185 264 minecraft:black_stained_glass
setblock 256 185 269 minecraft:pearlescent_froglight
setblock 257 185 228 minecraft:pearlescent_froglight
setblock 258 185 264 minecraft:black_stained_glass
setblock 258 185 269 minecraft:cyan_stained_glass
setblock 260 185 264 minecraft:black_stained_glass
setblock 260 185 269 minecraft:black_stained_glass
setblock 262 185 231 minecraft:light[level=15]
setblock 262 185 239 minecraft:light[level=15]
setblock 262 185 247 minecraft:light[level=15]
fill 262 185 255 270 185 263 minecraft:magenta_stained_glass
setblock 262 185 265 minecraft:light_blue_stained_glass
setblock 262 185 267 minecraft:pearlescent_froglight
setblock 270 185 231 minecraft:light[level=15]
setblock 270 185 239 minecraft:light[level=15]
setblock 270 185 247 minecraft:light[level=15]
setblock 271 185 243 minecraft:pearlescent_froglight
setblock 271 185 245 minecraft:pearlescent_froglight
setblock 271 185 247 minecraft:cyan_stained_glass
setblock 271 185 249 minecraft:black_stained_glass
setblock 271 185 251 minecraft:black_stained_glass
setblock 271 185 253 minecraft:pearlescent_froglight
setblock 272 185 242 minecraft:cyan_stained_glass
setblock 272 185 255 minecraft:light_blue_stained_glass
setblock 274 185 242 minecraft:ochre_froglight
setblock 274 185 255 minecraft:sea_lantern
setblock 276 185 243 minecraft:ochre_froglight
setblock 276 185 245 minecraft:light_blue_stained_glass
setblock 276 185 247 minecraft:sea_lantern
setblock 276 185 249 minecraft:black_stained_glass
setblock 276 185 251 minecraft:sea_lantern
setblock 276 185 253 minecraft:ochre_froglight
setblock 277 185 238 minecraft:cyan_concrete
setblock 277 185 248 minecraft:cyan_concrete
fill 236 186 230 236 187 230 minecraft:gray_concrete
fill 236 186 232 236 187 232 minecraft:gray_concrete
fill 236 186 234 236 187 234 minecraft:gray_concrete
fill 236 186 236 236 187 236 minecraft:gray_concrete
fill 236 186 243 236 187 243 minecraft:black_concrete
fill 236 186 245 236 187 245 minecraft:black_concrete
fill 236 186 247 236 187 247 minecraft:black_concrete
fill 236 186 249 236 187 249 minecraft:black_concrete
fill 236 186 251 236 187 251 minecraft:black_concrete
fill 236 186 253 236 187 253 minecraft:black_concrete
fill 237 186 229 237 187 229 minecraft:gray_concrete
fill 237 186 237 237 187 237 minecraft:gray_concrete
fill 237 186 242 237 187 242 minecraft:black_concrete
fill 237 186 255 237 187 255 minecraft:black_concrete
fill 239 186 229 239 187 229 minecraft:gray_concrete
fill 239 186 237 239 187 237 minecraft:gray_concrete
fill 239 186 242 239 187 242 minecraft:black_concrete
fill 239 186 255 239 187 255 minecraft:black_concrete
fill 241 186 229 241 187 229 minecraft:gray_concrete
fill 241 186 237 241 187 237 minecraft:gray_concrete
fill 241 186 243 241 187 243 minecraft:black_concrete
fill 241 186 245 241 187 245 minecraft:black_concrete
fill 241 186 247 241 187 247 minecraft:black_concrete
fill 241 186 249 241 187 249 minecraft:black_concrete
fill 241 186 251 241 187 251 minecraft:black_concrete
fill 241 186 253 241 187 253 minecraft:black_concrete
fill 243 186 229 243 187 229 minecraft:gray_concrete
setblock 243 186 237 minecraft:gray_concrete
fill 244 186 230 244 187 230 minecraft:gray_concrete
fill 244 186 232 244 187 232 minecraft:gray_concrete
fill 244 186 234 244 187 234 minecraft:gray_concrete
setblock 244 186 236 minecraft:gray_concrete
setblock 245 186 237 minecraft:sea_lantern
fill 249 186 265 249 187 265 minecraft:gray_concrete
fill 249 186 267 249 187 267 minecraft:gray_concrete
fill 250 186 264 250 187 264 minecraft:gray_concrete
fill 250 186 269 250 187 269 minecraft:gray_concrete
fill 252 186 264 252 187 264 minecraft:gray_concrete
fill 252 186 269 252 187 269 minecraft:gray_concrete
fill 254 186 264 254 187 264 minecraft:gray_concrete
fill 254 186 269 254 187 269 minecraft:gray_concrete
fill 256 186 264 256 187 264 minecraft:gray_concrete
fill 256 186 269 256 187 269 minecraft:gray_concrete
fill 257 186 228 257 252 228 minecraft:black_concrete
fill 258 186 264 258 187 264 minecraft:gray_concrete
fill 258 186 269 258 187 269 minecraft:gray_concrete
fill 260 186 264 260 187 264 minecraft:gray_concrete
fill 260 186 269 260 187 269 minecraft:gray_concrete
fill 262 186 265 262 187 265 minecraft:gray_concrete
fill 262 186 267 262 187 267 minecraft:gray_concrete
fill 263 186 256 263 187 262 minecraft:magenta_stained_glass
fill 264 186 256 269 187 256 minecraft:magenta_stained_glass
fill 264 186 262 269 187 262 minecraft:magenta_stained_glass
setblock 264 186 270 minecraft:ochre_froglight
setblock 268 186 261 minecraft:black_concrete
fill 268 186 263 276 186 269 minecraft:black_concrete
fill 269 186 257 269 187 261 minecraft:magenta_stained_glass
fill 270 186 261 276 186 262 minecraft:black_concrete
setblock 271 186 243 minecraft:gray_concrete
setblock 271 186 245 minecraft:gray_concrete
setblock 271 186 247 minecraft:gray_concrete
setblock 271 186 249 minecraft:gray_concrete
setblock 271 186 251 minecraft:gray_concrete
setblock 271 186 253 minecraft:gray_concrete
setblock 272 186 242 minecraft:gray_concrete
setblock 272 186 255 minecraft:gray_concrete
setblock 274 186 242 minecraft:gray_concrete
setblock 274 186 255 minecraft:gray_concrete
setblock 276 186 243 minecraft:gray_concrete
setblock 276 186 245 minecraft:gray_concrete
setblock 276 186 247 minecraft:gray_concrete
setblock 276 186 249 minecraft:gray_concrete
setblock 276 186 251 minecraft:gray_concrete
setblock 276 186 253 minecraft:gray_concrete
fill 277 186 238 277 213 238 minecraft:black_concrete
fill 277 186 248 277 187 248 minecraft:black_concrete
setblock 235 187 260 minecraft:verdant_froglight
setblock 238 187 238 minecraft:light[level=12]
setblock 238 187 259 minecraft:light[level=12]
setblock 238 187 266 minecraft:light[level=12]
fill 243 187 237 247 187 237 minecraft:red_concrete
fill 244 187 236 246 187 236 minecraft:red_concrete
fill 244 187 238 246 187 238 minecraft:red_concrete
setblock 245 187 231 minecraft:light[level=12]
setblock 245 187 245 minecraft:light[level=12]
setblock 245 187 252 minecraft:light[level=12]
setblock 245 187 259 minecraft:light[level=12]
setblock 245 187 266 minecraft:light[level=12]
setblock 252 187 231 minecraft:light[level=12]
setblock 252 187 238 minecraft:light[level=12]
setblock 252 187 245 minecraft:light[level=12]
setblock 252 187 252 minecraft:light[level=12]
setblock 252 187 259 minecraft:light[level=12]
setblock 254 187 228 minecraft:ochre_froglight
setblock 259 187 231 minecraft:light[level=12]
setblock 259 187 238 minecraft:light[level=12]
setblock 259 187 245 minecraft:light[level=12]
setblock 259 187 252 minecraft:light[level=12]
setblock 259 187 259 minecraft:light[level=12]
fill 264 187 270 264 200 270 minecraft:black_concrete
setblock 266 187 231 minecraft:light[level=12]
setblock 266 187 238 minecraft:light[level=12]
setblock 266 187 245 minecraft:light[level=12]
setblock 266 187 252 minecraft:light[level=12]
setblock 266 187 259 minecraft:light[level=12]
setblock 266 187 266 minecraft:light[level=12]
setblock 268 187 261 minecraft:pearlescent_froglight
fill 268 187 263 268 187 269 minecraft:pearlescent_froglight
fill 269 187 269 276 187 269 minecraft:pearlescent_froglight
setblock 269 187 270 minecraft:sea_lantern
fill 270 187 261 276 187 261 minecraft:pearlescent_froglight
fill 271 187 242 276 187 255 minecraft:black_concrete
setblock 271 187 270 minecraft:blue_concrete
fill 272 187 265 272 193 265 minecraft:iron_bars
setblock 273 187 231 minecraft:light[level=12]
setblock 273 187 238 minecraft:light[level=12]
setblock 273 187 259 minecraft:light[level=12]
setblock 273 187 266 minecraft:light[level=12]
fill 276 187 262 276 187 268 minecraft:pearlescent_froglight
setblock 235 188 249 minecraft:ochre_froglight
setblock 235 188 255 minecraft:magenta_concrete
fill 235 188 260 235 215 260 minecraft:black_concrete
setblock 236 188 230 minecraft:magenta_stained_glass
setblock 236 188 232 minecraft:pearlescent_froglight
setblock 236 188 234 minecraft:ochre_froglight
setblock 236 188 236 minecraft:pearlescent_froglight
setblock 236 188 243 minecraft:cyan_stained_glass
setblock 236 188 245 minecraft:sea_lantern
setblock 236 188 247 minecraft:pearlescent_froglight
setblock 236 188 249 minecraft:black_stained_glass
setblock 236 188 251 minecraft:light_blue_stained_glass
setblock 236 188 253 minecraft:ochre_froglight
setblock 237 188 229 minecraft:black_stained_glass
setblock 237 188 237 minecraft:black_stained_glass
setblock 237 188 242 minecraft:sea_lantern
setblock 237 188 255 minecraft:ochre_froglight
setblock 239 188 229 minecraft:black_stained_glass
setblock 239 188 237 minecraft:sea_lantern
setblock 239 188 242 minecraft:black_stained_glass
setblock 239 188 255 minecraft:light_blue_stained_glass
setblock 241 188 229 minecraft:cyan_stained_glass
setblock 241 188 237 minecraft:cyan_stained_glass
setblock 241 188 243 minecraft:black_stained_glass
setblock 241 188 245 minecraft:ochre_froglight
setblock 241 188 247 minecraft:black_stained_glass
setblock 241 188 249 minecraft:black_stained_glass
setblock 241 188 251 minecraft:pearlescent_froglight
setblock 241 188 253 minecraft:ochre_froglight
setblock 243 188 229 minecraft:black_stained_glass
setblock 243 188 237 minecraft:cyan_stained_glass
setblock 244 188 230 minecraft:pearlescent_froglight
setblock 244 188 232 minecraft:black_stained_glass
setblock 244 188 234 minecraft:light_blue_stained_glass
setblock 244 188 236 minecraft:black_stained_glass
fill 244 188 237 246 188 237 minecraft:light_blue_stained_glass
setblock 249 188 265 minecraft:light_blue_stained_glass
setblock 249 188 267 minecraft:light_blue_stained_glass
setblock 250 188 264 minecraft:pearlescent_froglight
setblock 250 188 269 minecraft:black_stained_glass
setblock 252 188 264 minecraft:black_stained_glass
setblock 252 188 269 minecraft:cyan_stained_glass
fill 254 188 228 254 194 228 minecraft:black_concrete
setblock 254 188 264 minecraft:pearlescent_froglight
setblock 254 188 269 minecraft:sea_lantern
setblock 256 188 264 minecraft:sea_lantern
setblock 256 188 269 minecraft:ochre_froglight
setblock 258 188 264 minecraft:black_stained_glass
setblock 258 188 269 minecraft:pearlescent_froglight
setblock 260 188 264 minecraft:black_stained_glass
setblock 260 188 269 minecraft:black_stained_glass
setblock 262 188 265 minecraft:black_stained_glass
setblock 262 188 267 minecraft:magenta_stained_glass
setblock 264 188 228 minecraft:ochre_froglight
fill 264 188 257 264 189 261 minecraft:magenta_stained_glass
fill 265 188 257 268 189 257 minecraft:magenta_stained_glass
fill 265 188 261 268 189 261 minecraft:magenta_stained_glass
fill 268 188 258 268 189 260 minecraft:magenta_stained_glass
fill 269 188 270 269 211 270 minecraft:black_concrete
fill 271 188 242 271 188 255 minecraft:sea_lantern
fill 271 188 270 271 236 270 minecraft:black_concrete
fill 272 188 242 276 188 242 minecraft:sea_lantern
fill 272 188 255 276 188 255 minecraft:sea_lantern
fill 273 188 248 273 196 248 minecraft:iron_bars
fill 276 188 243 276 188 254 minecraft:sea_lantern
setblock 277 188 248 minecraft:magenta_concrete
setblock 235 189 229 minecraft:verdant_froglight
fill 235 189 249 236 190 249 minecraft:black_concrete
fill 235 189 255 235 201 255 minecraft:black_concrete
fill 236 189 230 236 190 230 minecraft:gray_concrete
fill 236 189 232 236 190 232 minecraft:gray_concrete
fill 236 189 234 236 190 234 minecraft:gray_concrete
fill 236 189 236 236 190 236 minecraft:gray_concrete
fill 236 189 243 236 190 243 minecraft:black_concrete
fill 236 189 245 236 190 245 minecraft:black_concrete
fill 236 189 247 236 190 247 minecraft:black_concrete
fill 236 189 251 236 190 251 minecraft:black_concrete
fill 236 189 253 236 190 253 minecraft:black_concrete
fill 237 189 229 237 190 229 minecraft:gray_concrete
fill 237 189 237 237 190 237 minecraft:gray_concrete
fill 237 189 242 237 190 242 minecraft:black_concrete
fill 237 189 255 237 190 255 minecraft:black_concrete
fill 238 189 236 240 201 236 minecraft:gray_concrete
fill 239 189 229 239 190 229 minecraft:gray_concrete
fill 239 189 235 240 201 235 minecraft:gray_concrete
fill 239 189 237 239 190 237 minecraft:gray_concrete
fill 239 189 242 240 190 242 minecraft:black_concrete
fill 239 189 255 239 190 255 minecraft:black_concrete
fill 240 189 234 240 201 234 minecraft:gray_concrete
fill 241 189 229 241 190 229 minecraft:gray_concrete
fill 241 189 234 249 189 242 minecraft:magenta_stained_glass
fill 241 189 243 241 190 243 minecraft:black_concrete
fill 241 189 245 241 190 245 minecraft:black_concrete
fill 241 189 247 241 190 247 minecraft:black_concrete
fill 241 189 249 241 190 249 minecraft:black_concrete
fill 241 189 251 241 190 251 minecraft:black_concrete
fill 241 189 253 241 190 253 minecraft:black_concrete
setblock 243 189 228 minecraft:blue_concrete
fill 243 189 229 243 190 229 minecraft:gray_concrete
fill 244 189 230 244 190 230 minecraft:gray_concrete
fill 244 189 232 244 190 232 minecraft:gray_concrete
setblock 245 189 270 minecraft:verdant_froglight
fill 249 189 265 249 190 265 minecraft:gray_concrete
fill 249 189 267 249 190 267 minecraft:gray_concrete
fill 250 189 264 250 190 264 minecraft:gray_concrete
fill 250 189 269 250 190 269 minecraft:gray_concrete
fill 252 189 264 252 190 264 minecraft:gray_concrete
fill 252 189 269 252 190 269 minecraft:gray_concrete
fill 254 189 264 254 190 264 minecraft:gray_concrete
fill 254 189 269 254 190 269 minecraft:gray_concrete
setblock 255 189 270 minecraft:ochre_froglight
fill 256 189 264 256 190 264 minecraft:gray_concrete
fill 256 189 269 256 190 269 minecraft:gray_concrete
fill 258 189 264 258 190 264 minecraft:gray_concrete
fill 258 189 269 258 190 269 minecraft:gray_concrete
setblock 260 189 228 minecraft:sea_lantern
fill 260 189 264 260 190 264 minecraft:gray_concrete
fill 260 189 269 260 190 269 minecraft:gray_concrete
fill 262 189 265 262 190 265 minecraft:gray_concrete
fill 262 189 267 262 190 267 minecraft:gray_concrete
fill 264 189 228 264 200 228 minecraft:black_concrete
fill 277 189 248 277 244 248 minecraft:black_concrete
fill 235 190 229 235 207 229 minecraft:black_concrete
setblock 240 190 270 minecraft:sea_lantern
fill 241 190 234 241 190 237 minecraft:gray_concrete
fill 241 190 242 241 277 242 minecraft:black_concrete
fill 242 190 234 244 190 234 minecraft:gray_concrete
fill 242 190 235 242 191 241 minecraft:magenta_stained_glass
fill 243 190 228 243 204 228 minecraft:black_concrete
fill 243 190 235 248 191 235 minecraft:magenta_stained_glass
fill 243 190 236 244 190 237 minecraft:gray_concrete
fill 243 190 241 248 191 241 minecraft:magenta_stained_glass
fill 245 190 270 245 201 270 minecraft:black_concrete
fill 248 190 236 248 191 240 minecraft:magenta_stained_glass
fill 255 190 270 255 204 270 minecraft:black_concrete
fill 260 190 228 260 288 228 minecraft:black_concrete
fill 265 190 258 265 191 260 minecraft:magenta_stained_glass
fill 266 190 258 267 191 258 minecraft:magenta_stained_glass
fill 266 190 260 267 191 260 minecraft:magenta_stained_glass
fill 267 190 259 267 191 259 minecraft:magenta_stained_glass
setblock 275 190 228 minecraft:ochre_froglight
setblock 277 190 261 minecraft:magenta_concrete
fill 235 191 249 235 282 249 minecraft:black_concrete
setblock 235 191 250 minecraft:purple_concrete
setblock 236 191 230 minecraft:ochre_froglight
setblock 236 191 232 minecraft:sea_lantern
setblock 236 191 234 minecraft:cyan_stained_glass
setblock 236 191 236 minecraft:black_stained_glass
setblock 236 191 243 minecraft:magenta_stained_glass
setblock 236 191 245 minecraft:black_stained_glass
setblock 236 191 247 minecraft:black_stained_glass
setblock 236 191 249 minecraft:magenta_stained_glass
setblock 236 191 251 minecraft:black_stained_glass
setblock 236 191 253 minecraft:cyan_stained_glass
setblock 237 191 229 minecraft:cyan_stained_glass
setblock 237 191 237 minecraft:light_blue_stained_glass
setblock 237 191 242 minecraft:black_stained_glass
setblock 237 191 255 minecraft:cyan_stained_glass
setblock 239 191 229 minecraft:light_blue_stained_glass
setblock 239 191 237 minecraft:cyan_stained_glass
setblock 239 191 242 minecraft:light_blue_stained_glass
setblock 239 191 255 minecraft:cyan_stained_glass
fill 240 191 242 240 202 242 minecraft:black_concrete
fill 240 191 270 240 196 270 minecraft:black_concrete
setblock 241 191 229 minecraft:light_blue_stained_glass
fill 241 191 234 241 202 236 minecraft:gray_concrete
setblock 241 191 237 minecraft:magenta_stained_glass
setblock 241 191 243 minecraft:cyan_stained_glass
setblock 241 191 245 minecraft:magenta_stained_glass
setblock 241 191 247 minecraft:magenta_stained_glass
setblock 241 191 249 minecraft:pearlescent_froglight
setblock 241 191 251 minecraft:black_stained_glass
setblock 241 191 253 minecraft:light_blue_stained_glass
fill 242 191 234 243 211 234 minecraft:gray_concrete
setblock 243 191 229 minecraft:cyan_stained_glass
setblock 243 191 236 minecraft:gray_concrete
setblock 243 191 237 minecraft:ochre_froglight
setblock 244 191 230 minecraft:sea_lantern
setblock 244 191 232 minecraft:black_stained_glass
setblock 244 191 234 minecraft:black_stained_glass
setblock 244 191 236 minecraft:black_stained_glass
fill 244 191 237 244 193 237 minecraft:gray_concrete
setblock 249 191 265 minecraft:magenta_stained_glass
setblock 249 191 267 minecraft:black_stained_glass
setblock 250 191 264 minecraft:black_stained_glass
setblock 250 191 269 minecraft:ochre_froglight
setblock 252 191 264 minecraft:black_stained_glass
setblock 252 191 269 minecraft:light_blue_stained_glass
setblock 254 191 264 minecraft:pearlescent_froglight
setblock 254 191 269 minecraft:light_blue_stained_glass
setblock 256 191 264 minecraft:ochre_froglight
setblock 256 191 269 minecraft:light_blue_stained_glass
setblock 258 191 264 minecraft:magenta_stained_glass
setblock 258 191 269 minecraft:black_stained_glass
setblock 260 191 264 minecraft:sea_lantern
setblock 260 191 269 minecraft:cyan_stained_glass
setblock 262 191 265 minecraft:black_stained_glass
setblock 262 191 267 minecraft:black_stained_glass
fill 275 191 228 275 308 228 minecraft:black_concrete
fill 277 191 261 277 193 261 minecraft:black_concrete
fill 235 192 250 235 194 250 minecraft:black_concrete
fill 236 192 230 236 193 230 minecraft:gray_concrete
fill 236 192 232 236 193 232 minecraft:gray_concrete
fill 236 192 234 236 193 234 minecraft:gray_concrete
fill 236 192 236 236 193 236 minecraft:gray_concrete
fill 236 192 243 236 193 243 minecraft:black_concrete
fill 236 192 245 236 193 245 minecraft:black_concrete
fill 236 192 247 236 193 247 minecraft:black_concrete
fill 236 192 249 236 193 249 minecraft:black_concrete
fill 236 192 251 236 193 251 minecraft:black_concrete
fill 236 192 253 236 193 253 minecraft:black_concrete
fill 237 192 229 237 193 229 minecraft:gray_concrete
fill 237 192 237 237 193 237 minecraft:gray_concrete
fill 237 192 242 237 193 242 minecraft:black_concrete
fill 237 192 255 237 193 255 minecraft:black_concrete
setblock 238 192 239 minecraft:light[level=15]
setblock 238 192 263 minecraft:light[level=15]
fill 239 192 229 239 193 229 minecraft:gray_concrete
fill 239 192 237 239 193 237 minecraft:gray_concrete
fill 239 192 242 239 193 242 minecraft:black_concrete
fill 239 192 255 239 193 255 minecraft:black_concrete
fill 241 192 229 241 193 229 minecraft:gray_concrete
fill 241 192 237 242 193 237 minecraft:gray_concrete
fill 241 192 243 241 193 243 minecraft:black_concrete
fill 241 192 245 241 193 245 minecraft:black_concrete
fill 241 192 247 241 193 247 minecraft:black_concrete
fill 241 192 249 241 193 249 minecraft:black_concrete
fill 241 192 251 241 193 251 minecraft:black_concrete
fill 241 192 253 241 193 253 minecraft:black_concrete
fill 242 192 235 242 211 236 minecraft:gray_concrete
fill 243 192 229 243 193 229 minecraft:gray_concrete
fill 243 192 235 244 211 235 minecraft:gray_concrete
fill 243 192 236 243 193 240 minecraft:magenta_stained_glass
fill 244 192 230 244 193 230 minecraft:gray_concrete
fill 244 192 232 244 193 232 minecraft:gray_concrete
fill 244 192 234 244 193 234 minecraft:gray_concrete
fill 244 192 236 247 193 236 minecraft:magenta_stained_glass
fill 244 192 240 247 193 240 minecraft:magenta_stained_glass
setblock 246 192 231 minecraft:light[level=15]
setblock 246 192 239 minecraft:light[level=15]
setblock 246 192 247 minecraft:light[level=15]
setblock 246 192 255 minecraft:light[level=15]
setblock 246 192 263 minecraft:light[level=15]
fill 247 192 237 247 193 239 minecraft:magenta_stained_glass
fill 249 192 265 249 193 265 minecraft:gray_concrete
fill 249 192 267 249 193 267 minecraft:gray_concrete
fill 250 192 264 250 193 264 minecraft:gray_concrete
fill 250 192 269 250 193 269 minecraft:gray_concrete
setblock 251 192 228 minecraft:purple_concrete
fill 252 192 264 252 193 264 minecraft:gray_concrete
fill 252 192 269 252 193 269 minecraft:gray_concrete
setblock 254 192 231 minecraft:light[level=15]
setblock 254 192 239 minecraft:light[level=15]
setblock 254 192 247 minecraft:light[level=15]
setblock 254 192 255 minecraft:light[level=15]
setblock 254 192 263 minecraft:light[level=15]
fill 254 192 264 254 193 264 minecraft:gray_concrete
fill 254 192 269 254 193 269 minecraft:gray_concrete
fill 256 192 264 256 193 264 minecraft:gray_concrete
fill 256 192 269 256 193 269 minecraft:gray_concrete
setblock 258 192 228 minecraft:verdant_froglight
fill 258 192 264 258 193 264 minecraft:gray_concrete
fill 258 192 269 258 193 269 minecraft:gray_concrete
setblock 258 192 270 minecraft:magenta_concrete
fill 260 192 264 260 193 264 minecraft:gray_concrete
fill 260 192 269 260 193 269 minecraft:gray_concrete
setblock 262 192 231 minecraft:light[level=15]
setblock 262 192 239 minecraft:light[level=15]
setblock 262 192 247 minecraft:light[level=15]
setblock 262 192 255 minecraft:light[level=15]
setblock 262 192 263 minecraft:light[level=15]
fill 262 192 265 262 193 265 minecraft:gray_concrete
fill 262 192 267 262 193 267 minecraft:gray_concrete
fill 266 192 259 266 193 259 minecraft:magenta_stained_glass
setblock 270 192 231 minecraft:light[level=15]
setblock 270 192 239 minecraft:light[level=15]
setblock 270 192 247 minecraft:light[level=15]
setblock 270 192 255 minecraft:light[level=15]
setblock 270 192 263 minecraft:light[level=15]
setblock 277 192 252 minecraft:ochre_froglight
setblock 235 193 264 minecraft:verdant_froglight
setblock 237 193 228 minecraft:pearlescent_froglight
setblock 238 193 238 minecraft:light[level=12]
setblock 238 193 259 minecraft:light[level=12]
setblock 238 193 266 minecraft:light[level=12]
setblock 245 193 231 minecraft:light[level=12]
setblock 245 193 238 minecraft:light[level=12]
setblock 245 193 245 minecraft:light[level=12]
setblock 245 193 252 minecraft:light[level=12]
setblock 245 193 259 minecraft:light[level=12]
setblock 245 193 266 minecraft:light[level=12]
fill 251 193 228 251 200 228 minecraft:black_concrete
setblock 252 193 231 minecraft:light[level=12]
setblock 252 193 238 minecraft:light[level=12]
setblock 252 193 245 minecraft:light[level=12]
setblock 252 193 252 minecraft:light[level=12]
setblock 252 193 259 minecraft:light[level=12]
fill 258 193 228 258 232 228 minecraft:black_concrete
fill 258 193 270 258 284 270 minecraft:black_concrete
setblock 259 193 231 minecraft:light[level=12]
setblock 259 193 238 minecraft:light[level=12]
setblock 259 193 245 minecraft:light[level=12]
setblock 259 193 252 minecraft:light[level=12]
setblock 259 193 259 minecraft:light[level=12]
setblock 266 193 231 minecraft:light[level=12]
setblock 266 193 238 minecraft:light[level=12]
setblock 266 193 245 minecraft:light[level=12]
setblock 266 193 252 minecraft:light[level=12]
setblock 266 193 266 minecraft:light[level=12]
setblock 272 193 233 minecraft:redstone_block
setblock 273 193 231 minecraft:light[level=12]
setblock 273 193 238 minecraft:light[level=12]
setblock 273 193 245 minecraft:light[level=12]
setblock 273 193 252 minecraft:light[level=12]
setblock 273 193 259 minecraft:light[level=12]
setblock 273 193 266 minecraft:light[level=12]
fill 277 193 252 277 205 252 minecraft:black_concrete
fill 235 194 264 235 228 264 minecraft:black_concrete
setblock 236 194 230 minecraft:magenta_stained_glass
setblock 236 194 232 minecraft:pearlescent_froglight
setblock 236 194 234 minecraft:ochre_froglight
setblock 236 194 236 minecraft:black_stained_glass
setblock 236 194 243 minecraft:black_stained_glass
setblock 236 194 245 minecraft:sea_lantern
setblock 236 194 247 minecraft:black_stained_glass
setblock 236 194 249 minecraft:cyan_stained_glass
setblock 236 194 251 minecraft:sea_lantern
setblock 236 194 253 minecraft:light_blue_stained_glass
fill 237 194 228 237 246 228 minecraft:black_concrete
setblock 237 194 229 minecraft:ochre_froglight
setblock 237 194 237 minecraft:pearlescent_froglight
setblock 237 194 242 minecraft:sea_lantern
setblock 237 194 255 minecraft:magenta_stained_glass
setblock 237 194 270 minecraft:cyan_concrete
setblock 239 194 229 minecraft:black_stained_glass
setblock 239 194 237 minecraft:ochre_froglight
setblock 239 194 242 minecraft:cyan_stained_glass
setblock 239 194 255 minecraft:black_stained_glass
setblock 241 194 229 minecraft:pearlescent_froglight
setblock 241 194 237 minecraft:black_stained_glass
setblock 241 194 243 minecraft:sea_lantern
setblock 241 194 245 minecraft:black_stained_glass
setblock 241 194 247 minecraft:ochre_froglight
setblock 241 194 249 minecraft:black_stained_glass
setblock 241 194 251 minecraft:sea_lantern
setblock 241 194 253 minecraft:black_stained_glass
fill 242 194 237 242 211 237 minecraft:gray_concrete
setblock 243 194 229 minecraft:black_stained_glass
fill 243 194 236 243 211 236 minecraft:gray_concrete
setblock 243 194 237 minecraft:pearlescent_froglight
setblock 243 194 240 minecraft:sea_lantern
setblock 244 194 230 minecraft:ochre_froglight
setblock 244 194 232 minecraft:black_stained_glass
setblock 244 194 234 minecraft:black_stained_glass
setblock 244 194 236 minecraft:light_blue_stained_glass
fill 244 194 237 244 195 239 minecraft:magenta_stained_glass
fill 245 194 237 246 195 237 minecraft:magenta_stained_glass
fill 245 194 239 246 195 239 minecraft:magenta_stained_glass
setblock 246 194 228 minecraft:pearlescent_froglight
fill 246 194 238 246 195 238 minecraft:magenta_stained_glass
setblock 249 194 265 minecraft:magenta_stained_glass
setblock 249 194 267 minecraft:ochre_froglight
setblock 250 194 264 minecraft:black_stained_glass
setblock 250 194 269 minecraft:black_stained_glass
setblock 252 194 264 minecraft:black_stained_glass
setblock 252 194 269 minecraft:black_stained_glass
setblock 254 194 264 minecraft:black_stained_glass
setblock 254 194 269 minecraft:black_stained_glass
setblock 256 194 264 minecraft:black_stained_glass
setblock 256 194 269 minecraft:black_stained_glass
setblock 258 194 264 minecraft:black_stained_glass
setblock 258 194 269 minecraft:black_stained_glass
setblock 260 194 264 minecraft:cyan_stained_glass
setblock 260 194 269 minecraft:ochre_froglight
setblock 262 194 265 minecraft:ochre_froglight
setblock 262 194 267 minecraft:pearlescent_froglight
setblock 277 194 261 minecraft:verdant_froglight
setblock 235 195 250 minecraft:pearlescent_froglight
setblock 235 195 258 minecraft:verdant_froglight
setblock 235 195 259 minecraft:blue_concrete
fill 236 195 230 236 196 230 minecraft:gray_concrete
fill 236 195 232 236 196 232 minecraft:gray_concrete
fill 236 195 234 236 196 234 minecraft:gray_concrete
fill 236 195 236 236 196 236 minecraft:gray_concrete
fill 236 195 243 236 196 243 minecraft:black_concrete
fill 236 195 245 236 196 245 minecraft:black_concrete
fill 236 195 247 236 196 247 minecraft:black_concrete
fill 236 195 249 236 196 249 minecraft:black_concrete
fill 236 195 251 236 196 251 minecraft:black_concrete
fill 236 195 253 236 196 253 minecraft:black_concrete
fill 237 195 229 237 196 229 minecraft:gray_concrete
fill 237 195 237 237 196 237 minecraft:gray_concrete
fill 237 195 242 237 196 242 minecraft:black_concrete
fill 237 195 255 237 196 255 minecraft:black_concrete
fill 237 195 270 237 308 270 minecraft:black_concrete
fill 239 195 229 239 196 229 minecraft:gray_concrete
fill 239 195 237 239 196 237 minecraft:gray_concrete
fill 239 195 242 239 196 242 minecraft:black_concrete
fill 239 195 255 239 196 255 minecraft:black_concrete
fill 241 195 229 241 196 229 minecraft:gray_concrete
fill 241 195 237 241 196 237 minecraft:gray_concrete
fill 241 195 243 241 196 243 minecraft:black_concrete
fill 241 195 245 241 196 245 minecraft:black_concrete
fill 241 195 247 241 196 247 minecraft:black_concrete
fill 241 195 249 241 196 249 minecraft:black_concrete
fill 241 195 251 241 196 251 minecraft:black_concrete
fill 241 195 253 241 196 253 minecraft:black_concrete
fill 242 195 239 243 195 241 minecraft:white_concrete
fill 243 195 229 243 196 229 minecraft:gray_concrete
fill 243 195 237 243 196 237 minecraft:gray_concrete
setblock 243 195 238 minecraft:white_concrete
setblock 243 195 242 minecraft:white_concrete
fill 244 195 230 244 196 230 minecraft:gray_concrete
fill 244 195 232 244 196 232 minecraft:gray_concrete
fill 244 195 234 244 196 234 minecraft:gray_concrete
fill 244 195 236 244 196 236 minecraft:gray_concrete
fill 244 195 240 244 195 241 minecraft:white_concrete
fill 246 195 228 246 216 228 minecraft:black_concrete
fill 249 195 265 249 196 265 minecraft:gray_concrete
fill 249 195 267 249 196 267 minecraft:gray_concrete
fill 250 195 264 250 196 264 minecraft:gray_concrete
fill 250 195 269 250 196 269 minecraft:gray_concrete
fill 252 195 264 252 196 264 minecraft:gray_concrete
fill 252 195 269 252 196 269 minecraft:gray_concrete
setblock 254 195 228 minecraft:sea_lantern
fill 254 195 264 254 196 264 minecraft:gray_concrete
fill 254 195 269 254 196 269 minecraft:gray_concrete
fill 256 195 264 256 196 264 minecraft:gray_concrete
fill 256 195 269 256 196 269 minecraft:gray_concrete
fill 258 195 264 258 196 264 minecraft:gray_concrete
fill 258 195 269 258 196 269 minecraft:gray_concrete
fill 260 195 264 260 196 264 minecraft:gray_concrete
fill 260 195 269 260 196 269 minecraft:gray_concrete
fill 262 195 265 262 196 265 minecraft:gray_concrete
fill 262 195 267 262 196 267 minecraft:gray_concrete
setblock 273 195 270 minecraft:blue_concrete
fill 277 195 261 277 249 261 minecraft:black_concrete
fill 235 196 250 235 220 250 minecraft:black_concrete
fill 235 196 258 235 204 259 minecraft:black_concrete
fill 243 196 239 243 196 241 minecraft:light_blue_stained_glass
fill 244 196 237 244 211 237 minecraft:gray_concrete
setblock 244 196 270 minecraft:verdant_froglight
fill 245 196 238 245 197 238 minecraft:magenta_stained_glass
setblock 250 196 270 minecraft:sea_lantern
fill 254 196 228 254 239 228 minecraft:black_concrete
setblock 259 196 228 minecraft:blue_concrete
fill 273 196 270 273 308 270 minecraft:black_concrete
setblock 235 197 243 minecraft:purple_concrete
setblock 236 197 230 minecraft:black_stained_glass
setblock 236 197 232 minecraft:black_stained_glass
setblock 236 197 234 minecraft:sea_lantern
setblock 236 197 236 minecraft:black_stained_glass
setblock 236 197 243 minecraft:black_stained_glass
setblock 236 197 245 minecraft:black_stained_glass
setblock 236 197 247 minecraft:black_stained_glass
setblock 236 197 249 minecraft:black_stained_glass
setblock 236 197 251 minecraft:pearlescent_froglight
setblock 236 197 253 minecraft:black_stained_glass
setblock 237 197 229 minecraft:black_stained_glass
setblock 237 197 237 minecraft:sea_lantern
setblock 237 197 242 minecraft:ochre_froglight
setblock 237 197 255 minecraft:pearlescent_froglight
setblock 239 197 229 minecraft:black_stained_glass
setblock 239 197 237 minecraft:sea_lantern
setblock 239 197 242 minecraft:sea_lantern
setblock 239 197 255 minecraft:ochre_froglight
setblock 240 197 270 minecraft:pearlescent_froglight
setblock 241 197 229 minecraft:ochre_froglight
setblock 241 197 237 minecraft:pearlescent_froglight
setblock 241 197 243 minecraft:pearlescent_froglight
setblock 241 197 245 minecraft:magenta_stained_glass
setblock 241 197 247 minecraft:sea_lantern
setblock 241 197 249 minecraft:black_stained_glass
setblock 241 197 251 minecraft:black_stained_glass
setblock 241 197 253 minecraft:cyan_stained_glass
setblock 243 197 229 minecraft:black_stained_glass
setblock 243 197 237 minecraft:magenta_stained_glass
setblock 244 197 230 minecraft:black_stained_glass
setblock 244 197 232 minecraft:black_stained_glass
setblock 244 197 234 minecraft:black_stained_glass
setblock 244 197 236 minecraft:black_stained_glass
fill 244 197 270 244 288 270 minecraft:black_concrete
setblock 249 197 265 minecraft:sea_lantern
setblock 249 197 267 minecraft:pearlescent_froglight
setblock 250 197 264 minecraft:sea_lantern
setblock 250 197 269 minecraft:black_stained_glass
fill 250 197 270 250 211 270 minecraft:black_concrete
setblock 252 197 264 minecraft:black_stained_glass
setblock 252 197 269 minecraft:pearlescent_froglight
setblock 254 197 264 minecraft:black_stained_glass
setblock 254 197 269 minecraft:black_stained_glass
setblock 256 197 264 minecraft:sea_lantern
setblock 256 197 269 minecraft:ochre_froglight
setblock 258 197 264 minecraft:sea_lantern
setblock 258 197 269 minecraft:magenta_stained_glass
setblock 259 197 228 minecraft:sea_lantern
setblock 260 197 264 minecraft:black_stained_glass
setblock 260 197 269 minecraft:pearlescent_froglight
setblock 261 197 228 minecraft:magenta_concrete
setblock 262 197 265 minecraft:black_stained_glass
setblock 262 197 267 minecraft:black_stained_glass
fill 235 198 243 236 199 243 minecraft:black_concrete
fill 236 198 230 236 199 230 minecraft:gray_concrete
fill 236 198 232 236 199 232 minecraft:gray_concrete
fill 236 198 234 236 199 234 minecraft:gray_concrete
fill 236 198 236 236 199 236 minecraft:gray_concrete
fill 236 198 245 236 199 245 minecraft:black_concrete
fill 236 198 247 236 199 247 minecraft:black_concrete
fill 236 198 249 236 199 249 minecraft:black_concrete
fill 236 198 251 236 199 251 minecraft:black_concrete
fill 236 198 253 236 199 253 minecraft:black_concrete
fill 237 198 229 237 199 229 minecraft:gray_concrete
fill 237 198 237 237 199 237 minecraft:gray_concrete
fill 237 198 242 237 199 242 minecraft:black_concrete
fill 237 198 255 237 199 255 minecraft:black_concrete
fill 239 198 229 239 199 229 minecraft:gray_concrete
fill 239 198 237 239 199 237 minecraft:gray_concrete
fill 239 198 242 239 199 242 minecraft:black_concrete
fill 239 198 255 239 199 255 minecraft:black_concrete
fill 240 198 270 240 304 270 minecraft:black_concrete
fill 241 198 229 241 199 229 minecraft:gray_concrete
fill 241 198 237 241 199 237 minecraft:gray_concrete
fill 241 198 243 241 199 243 minecraft:black_concrete
fill 241 198 245 241 199 245 minecraft:black_concrete
fill 241 198 247 241 199 247 minecraft:black_concrete
fill 241 198 249 241 199 249 minecraft:black_concrete
fill 241 198 251 241 199 251 minecraft:black_concrete
fill 241 198 253 241 199 253 minecraft:black_concrete
fill 243 198 229 243 199 229 minecraft:gray_concrete
fill 243 198 237 243 199 237 minecraft:gray_concrete
fill 244 198 230 244 199 230 minecraft:gray_concrete
fill 244 198 232 244 199 232 minecraft:gray_concrete
fill 244 198 234 244 199 234 minecraft:gray_concrete
fill 244 198 236 244 199 236 minecraft:gray_concrete
fill 249 198 265 249 199 265 minecraft:gray_concrete
fill 249 198 267 249 199 267 minecraft:gray_concrete
fill 250 198 264 250 199 264 minecraft:gray_concrete
fill 250 198 269 250 199 269 minecraft:gray_concrete
fill 252 198 264 252 199 264 minecraft:gray_concrete
fill 252 198 269 252 199 269 minecraft:gray_concrete
fill 254 198 264 254 199 264 minecraft:gray_concrete
fill 254 198 269 254 199 269 minecraft:gray_concrete
setblock 254 198 270 minecraft:blue_concrete
fill 256 198 264 256 199 264 minecraft:gray_concrete
fill 256 198 269 256 199 269 minecraft:gray_concrete
fill 258 198 264 258 199 264 minecraft:gray_concrete
fill 258 198 269 258 199 269 minecraft:gray_concrete
fill 259 198 228 259 278 228 minecraft:black_concrete
fill 260 198 264 260 199 264 minecraft:gray_concrete
fill 260 198 269 260 199 269 minecraft:gray_concrete
fill 261 198 228 261 237 228 minecraft:black_concrete
fill 262 198 265 262 199 265 minecraft:gray_concrete
fill 262 198 267 262 199 267 minecraft:gray_concrete
setblock 272 198 265 minecraft:redstone_block
setblock 238 199 238 minecraft:light[level=12]
setblock 238 199 239 minecraft:light[level=15]
setblock 238 199 259 minecraft:light[level=12]
setblock 238 199 263 minecraft:light[level=15]
setblock 238 199 266 minecraft:light[level=12]
setblock 245 199 231 minecraft:light[level=12]
setblock 245 199 238 minecraft:light[level=12]
setblock 245 199 245 minecraft:light[level=12]
setblock 245 199 252 minecraft:light[level=12]
setblock 245 199 259 minecraft:light[level=12]
setblock 245 199 266 minecraft:light[level=12]
setblock 246 199 231 minecraft:light[level=15]
setblock 246 199 239 minecraft:light[level=15]
setblock 246 199 247 minecraft:light[level=15]
setblock 246 199 255 minecraft:light[level=15]
setblock 246 199 263 minecraft:light[level=15]
setblock 252 199 231 minecraft:light[level=12]
setblock 252 199 238 minecraft:light[level=12]
setblock 252 199 245 minecraft:light[level=12]
setblock 252 199 252 minecraft:light[level=12]
setblock 252 199 259 minecraft:light[level=12]
setblock 254 199 231 minecraft:light[level=15]
setblock 254 199 239 minecraft:light[level=15]
setblock 254 199 247 minecraft:light[level=15]
setblock 254 199 255 minecraft:light[level=15]
setblock 254 199 263 minecraft:light[level=15]
fill 254 199 270 254 218 270 minecraft:black_concrete
setblock 259 199 231 minecraft:light[level=12]
setblock 259 199 238 minecraft:light[level=12]
setblock 259 199 245 minecraft:light[level=12]
setblock 259 199 252 minecraft:light[level=12]
setblock 259 199 259 minecraft:light[level=12]
setblock 262 199 231 minecraft:light[level=15]
setblock 262 199 239 minecraft:light[level=15]
setblock 262 199 247 minecraft:light[level=15]
setblock 262 199 255 minecraft:light[level=15]
setblock 262 199 263 minecraft:light[level=15]
setblock 266 199 231 minecraft:light[level=12]
setblock 266 199 238 minecraft:light[level=12]
setblock 266 199 245 minecraft:light[level=12]
setblock 266 199 252 minecraft:light[level=12]
setblock 266 199 259 minecraft:light[level=12]
setblock 266 199 266 minecraft:light[level=12]
setblock 270 199 231 minecraft:light[level=15]
setblock 270 199 239 minecraft:light[level=15]
setblock 270 199 247 minecraft:light[level=15]
setblock 270 199 255 minecraft:light[level=15]
setblock 270 199 263 minecraft:light[level=15]
setblock 273 199 231 minecraft:light[level=12]
setblock 273 199 238 minecraft:light[level=12]
setblock 273 199 245 minecraft:light[level=12]
setblock 273 199 248 minecraft:redstone_block
setblock 273 199 252 minecraft:light[level=12]
setblock 273 199 259 minecraft:light[level=12]
setblock 273 199 266 minecraft:light[level=12]
fill 235 200 243 235 241 243 minecraft:black_concrete
setblock 236 200 230 minecraft:cyan_stained_glass
setblock 236 200 232 minecraft:black_stained_glass
setblock 236 200 234 minecraft:black_stained_glass
setblock 236 200 236 minecraft:pearlescent_froglight
setblock 236 200 243 minecraft:cyan_stained_glass
setblock 236 200 245 minecraft:black_stained_glass
setblock 236 200 247 minecraft:black_stained_glass
setblock 236 200 249 minecraft:ochre_froglight
setblock 236 200 251 minecraft:black_stained_glass
setblock 236 200 253 minecraft:black_stained_glass
setblock 237 200 229 minecraft:ochre_froglight
setblock 237 200 237 minecraft:cyan_stained_glass
setblock 237 200 242 minecraft:black_stained_glass
setblock 237 200 255 minecraft:cyan_stained_glass
setblock 239 200 229 minecraft:pearlescent_froglight
setblock 239 200 237 minecraft:black_stained_glass
setblock 239 200 242 minecraft:cyan_stained_glass
setblock 239 200 255 minecraft:magenta_stained_glass
setblock 241 200 229 minecraft:magenta_stained_glass
setblock 241 200 237 minecraft:light_blue_stained_glass
setblock 241 200 243 minecraft:black_stained_glass
setblock 241 200 245 minecraft:black_stained_glass
setblock 241 200 247 minecraft:black_stained_glass
setblock 241 200 249 minecraft:sea_lantern
setblock 241 200 251 minecraft:pearlescent_froglight
setblock 241 200 253 minecraft:black_stained_glass
setblock 243 200 229 minecraft:black_stained_glass
setblock 243 200 237 minecraft:light_blue_stained_glass
setblock 244 200 230 minecraft:black_stained_glass
setblock 244 200 232 minecraft:ochre_froglight
setblock 244 200 234 minecraft:light_blue_stained_glass
setblock 244 200 236 minecraft:pearlescent_froglight
setblock 247 200 270 minecraft:pearlescent_froglight
setblock 249 200 265 minecraft:black_stained_glass
setblock 249 200 267 minecraft:sea_lantern
setblock 250 200 264 minecraft:magenta_stained_glass
setblock 250 200 269 minecraft:black_stained_glass
setblock 252 200 264 minecraft:sea_lantern
setblock 252 200 269 minecraft:magenta_stained_glass
setblock 254 200 264 minecraft:ochre_froglight
setblock 254 200 269 minecraft:sea_lantern
setblock 256 200 264 minecraft:ochre_froglight
setblock 256 200 269 minecraft:black_stained_glass
setblock 258 200 264 minecraft:pearlescent_froglight
setblock 258 200 269 minecraft:black_stained_glass
setblock 260 200 264 minecraft:black_stained_glass
setblock 260 200 269 minecraft:ochre_froglight
setblock 262 200 265 minecraft:magenta_stained_glass
setblock 262 200 267 minecraft:ochre_froglight
setblock 277 200 240 minecraft:cyan_concrete
fill 236 201 230 236 202 230 minecraft:gray_concrete
fill 236 201 232 236 202 232 minecraft:gray_concrete
fill 236 201 234 236 202 234 minecraft:gray_concrete
fill 236 201 236 236 202 236 minecraft:gray_concrete
fill 236 201 243 236 202 243 minecraft:black_concrete
fill 236 201 245 236 202 245 minecraft:black_concrete
fill 236 201 247 236 202 247 minecraft:black_concrete
fill 236 201 249 236 202 249 minecraft:black_concrete
fill 236 201 251 236 202 251 minecraft:black_concrete
fill 236 201 253 236 202 253 minecraft:black_concrete
fill 237 201 229 237 202 229 minecraft:gray_concrete
fill 237 201 237 237 202 237 minecraft:gray_concrete
fill 237 201 242 237 202 242 minecraft:black_concrete
fill 237 201 255 237 202 255 minecraft:black_concrete
fill 239 201 229 239 202 229 minecraft:gray_concrete
fill 239 201 237 239 202 237 minecraft:gray_concrete
setblock 239 201 242 minecraft:black_concrete
fill 239 201 255 239 202 255 minecraft:black_concrete
fill 241 201 229 241 202 229 minecraft:gray_concrete
fill 241 201 237 241 202 237 minecraft:gray_concrete
fill 241 201 243 241 202 243 minecraft:black_concrete
fill 241 201 245 241 202 245 minecraft:black_concrete
fill 241 201 247 241 202 247 minecraft:black_concrete
fill 241 201 249 241 202 249 minecraft:black_concrete
fill 241 201 251 241 202 251 minecraft:black_concrete
fill 241 201 253 241 202 253 minecraft:black_concrete
fill 243 201 229 243 202 229 minecraft:gray_concrete
fill 243 201 237 243 202 237 minecraft:gray_concrete
fill 244 201 230 244 202 230 minecraft:gray_concrete
fill 244 201 232 244 202 232 minecraft:gray_concrete
fill 244 201 234 244 202 234 minecraft:gray_concrete
fill 244 201 236 244 202 236 minecraft:gray_concrete
fill 247 201 270 247 308 270 minecraft:black_concrete
fill 249 201 265 249 202 265 minecraft:gray_concrete
fill 249 201 267 249 202 267 minecraft:gray_concrete
fill 250 201 264 250 202 264 minecraft:gray_concrete
fill 250 201 269 250 202 269 minecraft:gray_concrete
setblock 251 201 228 minecraft:purple_concrete
fill 252 201 264 252 202 264 minecraft:gray_concrete
fill 252 201 269 252 202 269 minecraft:gray_concrete
fill 254 201 264 254 202 264 minecraft:gray_concrete
fill 254 201 269 254 202 269 minecraft:gray_concrete
fill 256 201 264 256 202 264 minecraft:gray_concrete
fill 256 201 269 256 202 269 minecraft:gray_concrete
fill 258 201 264 258 202 264 minecraft:gray_concrete
fill 258 201 269 258 202 269 minecraft:gray_concrete
fill 260 201 264 260 202 264 minecraft:gray_concrete
fill 260 201 269 260 202 269 minecraft:gray_concrete
fill 262 201 265 262 202 265 minecraft:gray_concrete
fill 262 201 267 262 202 267 minecraft:gray_concrete
setblock 264 201 228 minecraft:pearlescent_froglight
setblock 264 201 270 minecraft:cyan_concrete
fill 277 201 240 277 205 240 minecraft:black_concrete
setblock 235 202 255 minecraft:cyan_concrete
fill 236 202 244 238 202 244 minecraft:black_concrete
fill 237 202 243 238 202 243 minecraft:black_concrete
fill 237 202 245 238 202 245 minecraft:black_concrete
fill 238 202 236 239 202 236 minecraft:gray_concrete
setblock 238 202 246 minecraft:black_concrete
setblock 239 202 233 minecraft:gray_concrete
setblock 239 202 235 minecraft:gray_concrete
fill 239 202 240 239 203 246 minecraft:sea_lantern
fill 240 202 233 240 203 236 minecraft:sea_lantern
fill 240 202 243 240 202 246 minecraft:black_concrete
fill 241 202 233 244 202 233 minecraft:gray_concrete
fill 241 202 244 241 277 244 minecraft:black_concrete
fill 241 202 246 241 277 246 minecraft:black_concrete
setblock 245 202 270 minecraft:ochre_froglight
fill 251 202 228 251 221 228 minecraft:black_concrete
fill 264 202 228 264 250 228 minecraft:black_concrete
fill 264 202 270 264 233 270 minecraft:black_concrete
fill 235 203 255 235 213 255 minecraft:black_concrete
setblock 236 203 230 minecraft:black_stained_glass
setblock 236 203 232 minecraft:magenta_stained_glass
setblock 236 203 234 minecraft:black_stained_glass
setblock 236 203 236 minecraft:cyan_stained_glass
setblock 236 203 243 minecraft:light_blue_stained_glass
fill 236 203 244 237 277 244 minecraft:black_concrete
setblock 236 203 245 minecraft:light_blue_stained_glass
setblock 236 203 247 minecraft:light_blue_stained_glass
setblock 236 203 249 minecraft:black_stained_glass
setblock 236 203 251 minecraft:black_stained_glass
setblock 236 203 253 minecraft:sea_lantern
setblock 237 203 229 minecraft:pearlescent_froglight
setblock 237 203 237 minecraft:black_stained_glass
setblock 237 203 242 minecraft:pearlescent_froglight
fill 237 203 243 237 277 243 minecraft:black_concrete
fill 237 203 245 237 277 245 minecraft:black_concrete
fill 237 203 247 237 277 247 minecraft:black_concrete
setblock 237 203 255 minecraft:sea_lantern
fill 238 203 236 238 211 236 minecraft:gray_concrete
fill 238 203 242 238 204 249 minecraft:light_blue_stained_glass
fill 238 203 250 239 277 252 minecraft:black_concrete
setblock 239 203 229 minecraft:ochre_froglight
fill 239 203 233 239 204 239 minecraft:light_blue_stained_glass
fill 239 203 247 239 204 249 minecraft:light_blue_stained_glass
setblock 239 203 255 minecraft:black_stained_glass
fill 240 203 232 240 204 232 minecraft:light_blue_stained_glass
fill 240 203 237 240 204 245 minecraft:light_blue_stained_glass
fill 240 203 246 240 277 246 minecraft:black_concrete
setblock 241 203 229 minecraft:black_stained_glass
fill 241 203 232 243 211 232 minecraft:gray_concrete
fill 241 203 233 241 204 235 minecraft:light_blue_stained_glass
fill 241 203 236 241 211 236 minecraft:gray_concrete
setblock 241 203 237 minecraft:ochre_froglight
setblock 241 203 243 minecraft:sea_lantern
setblock 241 203 245 minecraft:black_stained_glass
setblock 241 203 247 minecraft:black_stained_glass
setblock 241 203 249 minecraft:black_stained_glass
setblock 241 203 251 minecraft:sea_lantern
setblock 241 203 253 minecraft:sea_lantern
fill 242 203 233 244 211 233 minecraft:gray_concrete
setblock 243 203 229 minecraft:sea_lantern
setblock 243 203 237 minecraft:light_blue_stained_glass
setblock 244 203 230 minecraft:black_stained_glass
setblock 244 203 232 minecraft:magenta_stained_glass
setblock 244 203 234 minecraft:sea_lantern
setblock 244 203 236 minecraft:ochre_froglight
setblock 245 203 228 minecraft:sea_lantern
fill 245 203 270 245 220 270 minecraft:black_concrete
setblock 249 203 265 minecraft:cyan_stained_glass
setblock 249 203 267 minecraft:black_stained_glass
setblock 250 203 264 minecraft:cyan_stained_glass
setblock 250 203 269 minecraft:ochre_froglight
setblock 252 203 264 minecraft:black_stained_glass
setblock 252 203 269 minecraft:black_stained_glass
setblock 254 203 264 minecraft:black_stained_glass
setblock 254 203 269 minecraft:black_stained_glass
setblock 256 203 264 minecraft:cyan_stained_glass
setblock 256 203 269 minecraft:black_stained_glass
setblock 257 203 270 minecraft:cyan_concrete
setblock 258 203 264 minecraft:black_stained_glass
setblock 258 203 269 minecraft:pearlescent_froglight
setblock 259 203 270 minecraft:cyan_concrete
setblock 260 203 264 minecraft:light_blue_stained_glass
setblock 260 203 269 minecraft:magenta_stained_glass
setblock 262 203 265 minecraft:cyan_stained_glass
setblock 262 203 267 minecraft:sea_lantern
setblock 277 203 269 minecraft:ochre_froglight
setblock 235 204 247 minecraft:sea_lantern
fill 236 204 230 236 205 230 minecraft:gray_concrete
fill 236 204 232 236 205 232 minecraft:gray_concrete
fill 236 204 234 236 205 234 minecraft:gray_concrete
fill 236 204 236 236 205 236 minecraft:gray_concrete
fill 236 204 243 236 205 243 minecraft:black_concrete
fill 236 204 245 236 205 245 minecraft:black_concrete
fill 236 204 247 236 205 247 minecraft:black_concrete
fill 236 204 249 236 205 249 minecraft:black_concrete
fill 236 204 251 236 205 251 minecraft:black_concrete
fill 236 204 253 236 205 253 minecraft:black_concrete
fill 237 204 229 237 205 229 minecraft:gray_concrete
fill 237 204 237 237 205 237 minecraft:gray_concrete
fill 237 204 242 237 205 242 minecraft:black_concrete
fill 237 204 255 237 205 255 minecraft:black_concrete
fill 239 204 229 239 205 229 minecraft:gray_concrete
fill 239 204 240 239 204 246 minecraft:light_blue_stained_glass
fill 239 204 255 239 205 255 minecraft:black_concrete
fill 240 204 233 240 204 236 minecraft:light_blue_stained_glass
fill 241 204 229 241 205 229 minecraft:gray_concrete
fill 241 204 237 241 205 237 minecraft:gray_concrete
fill 241 204 243 241 205 243 minecraft:black_concrete
fill 241 204 245 241 205 245 minecraft:black_concrete
fill 241 204 247 241 205 247 minecraft:black_concrete
fill 241 204 249 241 205 249 minecraft:black_concrete
fill 241 204 251 241 205 251 minecraft:black_concrete
fill 241 204 253 241 205 253 minecraft:black_concrete
fill 243 204 229 243 205 229 minecraft:gray_concrete
fill 243 204 237 243 205 237 minecraft:gray_concrete
fill 244 204 230 244 205 230 minecraft:gray_concrete
fill 244 204 232 244 205 232 minecraft:gray_concrete
fill 244 204 234 244 205 234 minecraft:gray_concrete
fill 244 204 236 244 205 236 minecraft:gray_concrete
fill 245 204 228 245 243 228 minecraft:black_concrete
fill 249 204 265 249 205 265 minecraft:gray_concrete
fill 249 204 267 249 205 267 minecraft:gray_concrete
fill 250 204 264 250 205 264 minecraft:gray_concrete
fill 250 204 269 250 205 269 minecraft:gray_concrete
fill 252 204 264 252 205 264 minecraft:gray_concrete
fill 252 204 269 252 205 269 minecraft:gray_concrete
fill 254 204 264 254 205 264 minecraft:gray_concrete
fill 254 204 269 254 205 269 minecraft:gray_concrete
fill 256 204 264 256 205 264 minecraft:gray_concrete
fill 256 204 269 256 205 269 minecraft:gray_concrete
fill 257 204 270 257 251 270 minecraft:black_concrete
fill 258 204 264 258 205 264 minecraft:gray_concrete
fill 258 204 269 258 205 269 minecraft:gray_concrete
fill 259 204 270 259 251 270 minecraft:black_concrete
fill 260 204 264 260 205 264 minecraft:gray_concrete
fill 260 204 269 260 205 269 minecraft:gray_concrete
fill 262 204 265 262 205 265 minecraft:gray_concrete
fill 262 204 267 262 205 267 minecraft:gray_concrete
fill 277 204 269 277 308 269 minecraft:black_concrete
fill 235 205 247 235 308 247 minecraft:black_concrete
fill 235 205 258 235 216 258 minecraft:black_concrete
setblock 235 205 259 minecraft:magenta_concrete
setblock 238 205 238 minecraft:light[level=12]
fill 238 205 242 239 205 249 minecraft:black_concrete
setblock 238 205 259 minecraft:light[level=12]
setblock 238 205 266 minecraft:light[level=12]
fill 239 205 233 240 205 237 minecraft:gray_concrete
fill 240 205 232 240 211 232 minecraft:gray_concrete
fill 240 205 242 240 277 245 minecraft:black_concrete
fill 241 205 233 241 211 235 minecraft:gray_concrete
setblock 243 205 228 minecraft:sea_lantern
setblock 245 205 231 minecraft:light[level=12]
setblock 245 205 238 minecraft:light[level=12]
setblock 245 205 245 minecraft:light[level=12]
setblock 245 205 252 minecraft:light[level=12]
setblock 245 205 259 minecraft:light[level=12]
setblock 245 205 266 minecraft:light[level=12]
fill 249 205 262 250 206 263 minecraft:gray_concrete
fill 250 205 255 250 206 261 minecraft:gray_concrete
fill 251 205 250 251 206 255 minecraft:gray_concrete
setblock 252 205 231 minecraft:light[level=12]
setblock 252 205 238 minecraft:light[level=12]
setblock 252 205 245 minecraft:light[level=12]
setblock 252 205 252 minecraft:light[level=12]
setblock 252 205 259 minecraft:light[level=12]
setblock 255 205 270 minecraft:purple_concrete
setblock 259 205 231 minecraft:light[level=12]
setblock 259 205 238 minecraft:light[level=12]
setblock 259 205 245 minecraft:light[level=12]
setblock 259 205 252 minecraft:light[level=12]
setblock 259 205 259 minecraft:light[level=12]
setblock 266 205 231 minecraft:light[level=12]
setblock 266 205 238 minecraft:light[level=12]
setblock 266 205 245 minecraft:light[level=12]
setblock 266 205 252 minecraft:light[level=12]
setblock 266 205 259 minecraft:light[level=12]
setblock 266 205 266 minecraft:light[level=12]
setblock 273 205 231 minecraft:light[level=12]
setblock 273 205 238 minecraft:light[level=12]
setblock 273 205 245 minecraft:light[level=12]
setblock 273 205 252 minecraft:light[level=12]
setblock 273 205 259 minecraft:light[level=12]
setblock 273 205 266 minecraft:light[level=12]
setblock 277 205 244 minecraft:ochre_froglight
fill 235 206 259 235 250 259 minecraft:black_concrete
setblock 236 206 230 minecraft:sea_lantern
setblock 236 206 232 minecraft:magenta_stained_glass
setblock 236 206 234 minecraft:black_stained_glass
setblock 236 206 236 minecraft:magenta_stained_glass
setblock 236 206 243 minecraft:light_blue_stained_glass
setblock 236 206 245 minecraft:light_blue_stained_glass
setblock 236 206 247 minecraft:black_stained_glass
setblock 236 206 249 minecraft:light_blue_stained_glass
setblock 236 206 251 minecraft:ochre_froglight
setblock 236 206 253 minecraft:sea_lantern
setblock 237 206 229 minecraft:light_blue_stained_glass
setblock 237 206 237 minecraft:black_stained_glass
setblock 237 206 242 minecraft:ochre_froglight
setblock 237 206 255 minecraft:sea_lantern
setblock 238 206 239 minecraft:light[level=15]
fill 238 206 242 238 277 249 minecraft:black_concrete
setblock 238 206 263 minecraft:light[level=15]
setblock 239 206 229 minecraft:sea_lantern
fill 239 206 233 240 211 236 minecraft:gray_concrete
setblock 239 206 237 minecraft:ochre_froglight
setblock 239 206 242 minecraft:light_blue_stained_glass
fill 239 206 243 239 277 249 minecraft:black_concrete
setblock 239 206 255 minecraft:ochre_froglight
fill 240 206 237 240 211 237 minecraft:gray_concrete
setblock 241 206 229 minecraft:black_stained_glass
setblock 241 206 237 minecraft:black_stained_glass
setblock 241 206 243 minecraft:black_stained_glass
setblock 241 206 245 minecraft:magenta_stained_glass
setblock 241 206 247 minecraft:cyan_stained_glass
setblock 241 206 249 minecraft:black_stained_glass
setblock 241 206 251 minecraft:black_stained_glass
setblock 241 206 253 minecraft:ochre_froglight
fill 243 206 228 243 246 228 minecraft:black_concrete
setblock 243 206 229 minecraft:ochre_froglight
setblock 243 206 237 minecraft:black_stained_glass
setblock 244 206 230 minecraft:pearlescent_froglight
setblock 244 206 232 minecraft:pearlescent_froglight
setblock 244 206 234 minecraft:black_stained_glass
setblock 244 206 236 minecraft:pearlescent_froglight
setblock 246 206 231 minecraft:light[level=15]
setblock 246 206 239 minecraft:light[level=15]
setblock 246 206 247 minecraft:light[level=15]
setblock 246 206 255 minecraft:light[level=15]
setblock 246 206 263 minecraft:light[level=15]
fill 249 206 260 249 206 261 minecraft:gray_concrete
setblock 249 206 265 minecraft:cyan_stained_glass
setblock 249 206 267 minecraft:black_stained_glass
fill 250 206 252 250 206 254 minecraft:gray_concrete
setblock 250 206 264 minecraft:black_stained_glass
setblock 250 206 269 minecraft:black_stained_glass
fill 251 206 244 252 206 249 minecraft:gray_concrete
fill 251 206 256 251 206 259 minecraft:gray_concrete
fill 252 206 236 253 206 243 minecraft:gray_concrete
fill 252 206 250 252 206 251 minecraft:gray_concrete
setblock 252 206 264 minecraft:light_blue_stained_glass
setblock 252 206 269 minecraft:magenta_stained_glass
fill 253 206 229 253 207 235 minecraft:gray_concrete
fill 254 206 229 254 206 234 minecraft:gray_concrete
setblock 254 206 239 minecraft:light[level=15]
setblock 254 206 247 minecraft:light[level=15]
setblock 254 206 255 minecraft:light[level=15]
setblock 254 206 263 minecraft:light[level=15]
setblock 254 206 264 minecraft:cyan_stained_glass
setblock 254 206 269 minecraft:sea_lantern
fill 255 206 270 255 253 270 minecraft:black_concrete
setblock 256 206 264 minecraft:black_stained_glass
setblock 256 206 269 minecraft:pearlescent_froglight
setblock 258 206 264 minecraft:black_stained_glass
setblock 258 206 269 minecraft:black_stained_glass
setblock 260 206 264 minecraft:black_stained_glass
setblock 260 206 269 minecraft:pearlescent_froglight
setblock 262 206 231 minecraft:light[level=15]
setblock 262 206 239 minecraft:light[level=15]
setblock 262 206 247 minecraft:light[level=15]
setblock 262 206 255 minecraft:light[level=15]
setblock 262 206 263 minecraft:light[level=15]
setblock 262 206 265 minecraft:pearlescent_froglight
setblock 262 206 267 minecraft:magenta_stained_glass
setblock 266 206 228 minecraft:cyan_concrete
setblock 270 206 231 minecraft:light[level=15]
setblock 270 206 239 minecraft:light[level=15]
setblock 270 206 247 minecraft:light[level=15]
setblock 270 206 255 minecraft:light[level=15]
setblock 270 206 263 minecraft:light[level=15]
setblock 277 206 230 minecraft:ochre_froglight
setblock 277 206 240 minecraft:verdant_froglight
fill 277 206 244 277 264 244 minecraft:black_concrete
setblock 277 206 252 minecraft:magenta_concrete
fill 236 207 230 236 208 230 minecraft:gray_concrete
fill 236 207 232 236 208 232 minecraft:gray_concrete
fill 236 207 234 236 208 234 minecraft:gray_concrete
fill 236 207 236 236 208 236 minecraft:gray_concrete
fill 236 207 243 236 208 243 minecraft:black_concrete
fill 236 207 245 236 208 245 minecraft:black_concrete
fill 236 207 247 236 208 247 minecraft:black_concrete
fill 236 207 249 236 208 249 minecraft:black_concrete
fill 236 207 251 236 208 251 minecraft:black_concrete
fill 236 207 253 236 208 253 minecraft:black_concrete
fill 236 207 265 238 208 265 minecraft:iron_block
fill 237 207 229 237 208 229 minecraft:gray_concrete
fill 237 207 237 237 208 237 minecraft:gray_concrete
fill 237 207 242 237 208 242 minecraft:black_concrete
fill 237 207 255 237 208 255 minecraft:black_concrete
fill 239 207 229 239 208 229 minecraft:gray_concrete
fill 239 207 237 239 208 237 minecraft:gray_concrete
fill 239 207 242 239 208 242 minecraft:black_concrete
fill 239 207 255 239 208 255 minecraft:black_concrete
fill 241 207 229 241 208 229 minecraft:gray_concrete
fill 241 207 237 241 208 237 minecraft:gray_concrete
fill 241 207 243 241 208 243 minecraft:black_concrete
fill 241 207 245 241 208 245 minecraft:black_concrete
fill 241 207 247 241 208 247 minecraft:black_concrete
fill 241 207 249 241 208 249 minecraft:black_concrete
fill 241 207 251 241 208 251 minecraft:black_concrete
fill 241 207 253 241 208 253 minecraft:black_concrete
fill 243 207 229 243 208 229 minecraft:gray_concrete
fill 243 207 237 243 208 237 minecraft:gray_concrete
fill 244 207 230 244 208 230 minecraft:gray_concrete
fill 244 207 232 244 208 232 minecraft:gray_concrete
fill 244 207 234 244 208 234 minecraft:gray_concrete
fill 244 207 236 244 208 236 minecraft:gray_concrete
fill 249 207 263 250 207 263 minecraft:magenta_concrete
fill 249 207 265 249 208 265 minecraft:gray_concrete
fill 249 207 267 249 208 267 minecraft:gray_concrete
fill 250 207 256 250 207 262 minecraft:magenta_concrete
fill 250 207 264 250 208 264 minecraft:gray_concrete
fill 250 207 269 250 208 269 minecraft:gray_concrete
fill 251 207 249 251 207 255 minecraft:magenta_concrete
fill 252 207 238 252 207 246 minecraft:gray_concrete
fill 252 207 264 252 208 264 minecraft:gray_concrete
fill 252 207 269 252 208 269 minecraft:gray_concrete
fill 253 207 236 253 207 240 minecraft:gray_concrete
fill 254 207 229 254 207 233 minecraft:gray_concrete
fill 254 207 264 254 208 264 minecraft:gray_concrete
fill 254 207 269 254 208 269 minecraft:gray_concrete
fill 256 207 264 256 208 264 minecraft:gray_concrete
fill 256 207 269 256 208 269 minecraft:gray_concrete
fill 258 207 264 258 208 264 minecraft:gray_concrete
fill 258 207 269 258 208 269 minecraft:gray_concrete
fill 260 207 264 260 208 264 minecraft:gray_concrete
fill 260 207 269 260 208 269 minecraft:gray_concrete
fill 262 207 265 262 208 265 minecraft:gray_concrete
fill 262 207 267 262 208 267 minecraft:gray_concrete
fill 266 207 228 266 220 228 minecraft:black_concrete
fill 277 207 230 277 227 230 minecraft:black_concrete
fill 277 207 240 277 215 240 minecraft:black_concrete
setblock 277 207 243 minecraft:sea_lantern
fill 277 207 252 277 308 252 minecraft:black_concrete
setblock 235 208 229 minecraft:pearlescent_froglight
fill 252 208 241 252 208 244 minecraft:magenta_concrete
fill 253 208 232 253 208 238 minecraft:magenta_concrete
fill 254 208 229 254 208 231 minecraft:magenta_concrete
fill 277 208 243 277 246 243 minecraft:black_concrete
fill 235 209 229 235 242 229 minecraft:black_concrete
setblock 236 209 230 minecraft:black_stained_glass
setblock 236 209 232 minecraft:sea_lantern
setblock 236 209 234 minecraft:black_stained_glass
setblock 236 209 236 minecraft:light_blue_stained_glass
setblock 236 209 243 minecraft:black_stained_glass
setblock 236 209 245 minecraft:black_stained_glass
setblock 236 209 247 minecraft:black_stained_glass
setblock 236 209 249 minecraft:sea_lantern
setblock 236 209 251 minecraft:black_stained_glass
setblock 236 209 253 minecraft:black_stained_glass
setblock 237 209 229 minecraft:light_blue_stained_glass
setblock 237 209 237 minecraft:sea_lantern
setblock 237 209 242 minecraft:ochre_froglight
setblock 237 209 255 minecraft:black_stained_glass
setblock 239 209 229 minecraft:light_blue_stained_glass
setblock 239 209 237 minecraft:black_stained_glass
setblock 239 209 242 minecraft:sea_lantern
setblock 239 209 255 minecraft:magenta_stained_glass
setblock 241 209 229 minecraft:black_stained_glass
setblock 241 209 237 minecraft:ochre_froglight
setblock 241 209 243 minecraft:black_stained_glass
setblock 241 209 245 minecraft:black_stained_glass
setblock 241 209 247 minecraft:sea_lantern
setblock 241 209 249 minecraft:black_stained_glass
setblock 241 209 251 minecraft:pearlescent_froglight
setblock 241 209 253 minecraft:black_stained_glass
setblock 243 209 229 minecraft:pearlescent_froglight
setblock 243 209 237 minecraft:magenta_stained_glass
setblock 244 209 230 minecraft:magenta_stained_glass
setblock 244 209 232 minecraft:pearlescent_froglight
setblock 244 209 234 minecraft:ochre_froglight
setblock 244 209 236 minecraft:pearlescent_froglight
setblock 249 209 265 minecraft:cyan_stained_glass
setblock 249 209 267 minecraft:light_blue_stained_glass
setblock 250 209 264 minecraft:magenta_stained_glass
setblock 250 209 269 minecraft:black_stained_glass
setblock 252 209 264 minecraft:cyan_stained_glass
setblock 252 209 269 minecraft:light_blue_stained_glass
setblock 254 209 264 minecraft:sea_lantern
setblock 254 209 269 minecraft:ochre_froglight
setblock 256 209 264 minecraft:magenta_stained_glass
setblock 256 209 269 minecraft:cyan_stained_glass
setblock 258 209 264 minecraft:pearlescent_froglight
setblock 258 209 269 minecraft:ochre_froglight
setblock 260 209 264 minecraft:black_stained_glass
setblock 260 209 269 minecraft:light_blue_stained_glass
setblock 262 209 265 minecraft:black_stained_glass
setblock 262 209 267 minecraft:black_stained_glass
setblock 235 210 266 minecraft:blue_concrete
fill 236 210 230 236 211 230 minecraft:gray_concrete
fill 236 210 232 236 211 232 minecraft:gray_concrete
fill 236 210 234 236 211 234 minecraft:gray_concrete
fill 236 210 236 236 211 236 minecraft:gray_concrete
fill 236 210 243 236 211 243 minecraft:black_concrete
fill 236 210 245 236 211 245 minecraft:black_concrete
fill 236 210 247 236 211 247 minecraft:black_concrete
fill 236 210 249 236 211 249 minecraft:black_concrete
fill 236 210 251 236 211 251 minecraft:black_concrete
fill 236 210 253 236 211 253 minecraft:black_concrete
fill 237 210 229 237 211 229 minecraft:gray_concrete
fill 237 210 237 237 211 237 minecraft:gray_concrete
fill 237 210 242 237 211 242 minecraft:black_concrete
fill 237 210 255 237 211 255 minecraft:black_concrete
fill 239 210 229 239 211 229 minecraft:gray_concrete
fill 239 210 237 239 211 237 minecraft:gray_concrete
fill 239 210 242 239 211 242 minecraft:black_concrete
fill 239 210 255 239 211 255 minecraft:black_concrete
fill 241 210 229 241 211 229 minecraft:gray_concrete
fill 241 210 237 241 211 237 minecraft:gray_concrete
fill 241 210 243 241 211 243 minecraft:black_concrete
fill 241 210 245 241 211 245 minecraft:black_concrete
fill 241 210 247 241 211 247 minecraft:black_concrete
fill 241 210 249 241 211 249 minecraft:black_concrete
fill 241 210 251 241 211 251 minecraft:black_concrete
fill 241 210 253 241 211 253 minecraft:black_concrete
fill 243 210 229 243 211 229 minecraft:gray_concrete
fill 243 210 237 243 211 237 minecraft:gray_concrete
fill 244 210 230 244 211 230 minecraft:gray_concrete
fill 244 210 232 244 211 232 minecraft:gray_concrete
fill 244 210 234 244 211 234 minecraft:gray_concrete
fill 244 210 236 244 211 236 minecraft:gray_concrete
fill 249 210 265 249 211 265 minecraft:gray_concrete
fill 249 210 267 249 211 267 minecraft:gray_concrete
fill 250 210 264 250 211 264 minecraft:gray_concrete
fill 250 210 269 250 211 269 minecraft:gray_concrete
fill 252 210 264 252 211 264 minecraft:gray_concrete
fill 252 210 269 252 211 269 minecraft:gray_concrete
fill 254 210 264 254 211 264 minecraft:gray_concrete
fill 254 210 269 254 211 269 minecraft:gray_concrete
fill 256 210 264 256 211 264 minecraft:gray_concrete
fill 256 210 269 256 211 269 minecraft:gray_concrete
fill 258 210 264 258 211 264 minecraft:gray_concrete
fill 258 210 269 258 211 269 minecraft:gray_concrete
fill 260 210 264 260 211 264 minecraft:gray_concrete
fill 260 210 269 260 211 269 minecraft:gray_concrete
setblock 261 210 270 minecraft:blue_concrete
fill 262 210 265 262 211 265 minecraft:gray_concrete
fill 262 210 267 262 211 267 minecraft:gray_concrete
setblock 277 210 267 minecraft:magenta_concrete
setblock 235 211 233 minecraft:blue_concrete
fill 235 211 234 235 262 234 minecraft:black_concrete
fill 235 211 266 235 228 266 minecraft:black_concrete
setblock 238 211 238 minecraft:light[level=12]
setblock 238 211 259 minecraft:light[level=12]
setblock 238 211 266 minecraft:light[level=12]
setblock 245 211 231 minecraft:light[level=12]
setblock 245 211 238 minecraft:light[level=12]
setblock 245 211 245 minecraft:light[level=12]
setblock 245 211 252 minecraft:light[level=12]
setblock 245 211 259 minecraft:light[level=12]
setblock 245 211 266 minecraft:light[level=12]
setblock 252 211 231 minecraft:light[level=12]
setblock 252 211 238 minecraft:light[level=12]
setblock 252 211 245 minecraft:light[level=12]
setblock 252 211 252 minecraft:light[level=12]
setblock 252 211 259 minecraft:light[level=12]
setblock 259 211 231 minecraft:light[level=12]
setblock 259 211 238 minecraft:light[level=12]
setblock 259 211 245 minecraft:light[level=12]
setblock 259 211 252 minecraft:light[level=12]
setblock 259 211 259 minecraft:light[level=12]
fill 261 211 270 261 217 270 minecraft:black_concrete
setblock 266 211 231 minecraft:light[level=12]
setblock 266 211 238 minecraft:light[level=12]
setblock 266 211 245 minecraft:light[level=12]
setblock 266 211 252 minecraft:light[level=12]
setblock 266 211 259 minecraft:light[level=12]
setblock 266 211 266 minecraft:light[level=12]
setblock 273 211 231 minecraft:light[level=12]
setblock 273 211 238 minecraft:light[level=12]
setblock 273 211 245 minecraft:light[level=12]
setblock 273 211 252 minecraft:light[level=12]
setblock 273 211 259 minecraft:light[level=12]
setblock 273 211 266 minecraft:light[level=12]
fill 277 211 267 277 231 267 minecraft:black_concrete
fill 235 212 233 244 212 233 minecraft:black_concrete
setblock 235 212 246 minecraft:sea_lantern
fill 236 212 229 244 212 232 minecraft:black_concrete
fill 236 212 234 244 212 237 minecraft:black_concrete
setblock 236 212 243 minecraft:black_stained_glass
setblock 236 212 245 minecraft:black_stained_glass
setblock 236 212 247 minecraft:sea_lantern
setblock 236 212 249 minecraft:ochre_froglight
setblock 236 212 251 minecraft:cyan_stained_glass
setblock 236 212 253 minecraft:pearlescent_froglight
setblock 237 212 242 minecraft:black_stained_glass
setblock 237 212 255 minecraft:ochre_froglight
setblock 239 212 242 minecraft:black_stained_glass
setblock 239 212 255 minecraft:magenta_stained_glass
setblock 241 212 243 minecraft:black_stained_glass
setblock 241 212 245 minecraft:black_stained_glass
setblock 241 212 247 minecraft:black_stained_glass
setblock 241 212 249 minecraft:cyan_stained_glass
setblock 241 212 251 minecraft:magenta_stained_glass
setblock 241 212 253 minecraft:light_blue_stained_glass
setblock 249 212 265 minecraft:light_blue_stained_glass
setblock 249 212 267 minecraft:pearlescent_froglight
setblock 250 212 264 minecraft:ochre_froglight
setblock 250 212 269 minecraft:black_stained_glass
setblock 250 212 270 minecraft:verdant_froglight
setblock 252 212 264 minecraft:light_blue_stained_glass
setblock 252 212 269 minecraft:black_stained_glass
setblock 254 212 264 minecraft:black_stained_glass
setblock 254 212 269 minecraft:cyan_stained_glass
setblock 256 212 264 minecraft:black_stained_glass
setblock 256 212 269 minecraft:cyan_stained_glass
setblock 258 212 264 minecraft:magenta_stained_glass
setblock 258 212 269 minecraft:pearlescent_froglight
setblock 260 212 264 minecraft:pearlescent_froglight
setblock 260 212 269 minecraft:black_stained_glass
setblock 262 212 265 minecraft:light_blue_stained_glass
setblock 262 212 267 minecraft:sea_lantern
setblock 269 212 270 minecraft:magenta_concrete
fill 235 213 233 235 234 233 minecraft:black_concrete
fill 235 213 246 235 225 246 minecraft:black_concrete
setblock 235 213 248 minecraft:cyan_concrete
fill 236 213 229 236 213 237 minecraft:pearlescent_froglight
fill 236 213 243 236 214 243 minecraft:black_concrete
fill 236 213 245 236 214 245 minecraft:black_concrete
fill 236 213 247 236 214 247 minecraft:black_concrete
fill 236 213 249 236 214 249 minecraft:black_concrete
fill 236 213 251 236 214 251 minecraft:black_concrete
fill 236 213 253 236 214 253 minecraft:black_concrete
setblock 236 213 270 minecraft:cyan_concrete
fill 237 213 229 244 213 229 minecraft:pearlescent_froglight
fill 237 213 237 244 213 237 minecraft:pearlescent_froglight
fill 237 213 242 237 214 242 minecraft:black_concrete
fill 237 213 255 237 214 255 minecraft:black_concrete
fill 238 213 231 242 214 235 minecraft:gray_concrete
setblock 238 213 239 minecraft:light[level=15]
setblock 238 213 263 minecraft:light[level=15]
fill 239 213 242 239 214 242 minecraft:black_concrete
fill 239 213 255 239 214 255 minecraft:black_concrete
fill 241 213 243 241 214 243 minecraft:black_concrete
fill 241 213 245 241 214 245 minecraft:black_concrete
fill 241 213 247 241 214 247 minecraft:black_concrete
fill 241 213 249 241 214 249 minecraft:black_concrete
fill 241 213 251 241 214 251 minecraft:black_concrete
fill 241 213 253 241 214 253 minecraft:black_concrete
fill 244 213 230 244 213 236 minecraft:pearlescent_froglight
setblock 246 213 231 minecraft:light[level=15]
setblock 246 213 239 minecraft:light[level=15]
setblock 246 213 247 minecraft:light[level=15]
setblock 246 213 255 minecraft:light[level=15]
setblock 246 213 263 minecraft:light[level=15]
fill 249 213 265 249 214 265 minecraft:gray_concrete
fill 249 213 267 249 214 267 minecraft:gray_concrete
fill 250 213 264 250 214 264 minecraft:gray_concrete
fill 250 213 269 250 214 269 minecraft:gray_concrete
fill 250 213 270 250 242 270 minecraft:black_concrete
fill 252 213 264 252 214 264 minecraft:gray_concrete
fill 252 213 269 252 214 269 minecraft:gray_concrete
setblock 254 213 231 minecraft:light[level=15]
setblock 254 213 239 minecraft:light[level=15]
setblock 254 213 247 minecraft:light[level=15]
setblock 254 213 255 minecraft:light[level=15]
setblock 254 213 263 minecraft:light[level=15]
fill 254 213 264 254 214 264 minecraft:gray_concrete
fill 254 213 269 254 214 269 minecraft:gray_concrete
fill 256 213 264 256 214 264 minecraft:gray_concrete
fill 256 213 269 256 214 269 minecraft:gray_concrete
fill 258 213 264 258 214 264 minecraft:gray_concrete
fill 258 213 269 258 214 269 minecraft:gray_concrete
fill 260 213 264 260 214 264 minecraft:gray_concrete
fill 260 213 269 260 214 269 minecraft:gray_concrete
setblock 262 213 231 minecraft:light[level=15]
setblock 262 213 239 minecraft:light[level=15]
setblock 262 213 247 minecraft:light[level=15]
setblock 262 213 255 minecraft:light[level=15]
setblock 262 213 263 minecraft:light[level=15]
fill 262 213 265 262 214 265 minecraft:gray_concrete
fill 262 213 267 262 214 267 minecraft:gray_concrete
fill 269 213 270 269 219 270 minecraft:black_concrete
setblock 270 213 231 minecraft:light[level=15]
setblock 270 213 239 minecraft:light[level=15]
setblock 270 213 247 minecraft:light[level=15]
setblock 270 213 255 minecraft:light[level=15]
setblock 270 213 263 minecraft:light[level=15]
setblock 277 213 265 minecraft:purple_concrete
fill 235 214 248 235 266 248 minecraft:black_concrete
setblock 235 214 255 minecraft:blue_concrete
fill 236 214 270 236 308 270 minecraft:black_concrete
fill 273 214 245 275 215 245 minecraft:iron_block
setblock 277 214 238 minecraft:purple_concrete
fill 277 214 265 277 215 265 minecraft:black_concrete
fill 235 215 255 235 223 255 minecraft:black_concrete
setblock 236 215 243 minecraft:light_blue_stained_glass
setblock 236 215 245 minecraft:black_stained_glass
setblock 236 215 247 minecraft:light_blue_stained_glass
setblock 236 215 249 minecraft:black_stained_glass
setblock 236 215 251 minecraft:black_stained_glass
setblock 236 215 253 minecraft:magenta_stained_glass
setblock 237 215 242 minecraft:black_stained_glass
setblock 237 215 255 minecraft:light_blue_stained_glass
fill 238 215 231 238 220 231 minecraft:gray_concrete
setblock 238 215 232 minecraft:magenta_stained_glass
fill 238 215 233 242 220 233 minecraft:gray_concrete
setblock 238 215 234 minecraft:magenta_stained_glass
fill 238 215 235 238 220 235 minecraft:gray_concrete
setblock 239 215 231 minecraft:black_stained_glass
fill 239 215 232 241 220 232 minecraft:gray_concrete
fill 239 215 234 241 220 234 minecraft:gray_concrete
setblock 239 215 235 minecraft:black_stained_glass
setblock 239 215 242 minecraft:light_blue_stained_glass
setblock 239 215 255 minecraft:cyan_stained_glass
fill 240 215 231 240 220 231 minecraft:gray_concrete
fill 240 215 235 240 220 235 minecraft:gray_concrete
setblock 241 215 231 minecraft:black_stained_glass
setblock 241 215 235 minecraft:ochre_froglight
setblock 241 215 243 minecraft:light_blue_stained_glass
setblock 241 215 245 minecraft:black_stained_glass
setblock 241 215 247 minecraft:black_stained_glass
setblock 241 215 249 minecraft:cyan_stained_glass
setblock 241 215 251 minecraft:magenta_stained_glass
setblock 241 215 253 minecraft:sea_lantern
fill 242 215 231 242 220 231 minecraft:gray_concrete
setblock 242 215 232 minecraft:black_stained_glass
setblock 242 215 234 minecraft:sea_lantern
fill 242 215 235 242 220 235 minecraft:gray_concrete
setblock 249 215 265 minecraft:black_stained_glass
setblock 249 215 267 minecraft:cyan_stained_glass
setblock 250 215 264 minecraft:black_stained_glass
setblock 250 215 269 minecraft:black_stained_glass
setblock 252 215 264 minecraft:black_stained_glass
setblock 252 215 269 minecraft:cyan_stained_glass
setblock 254 215 264 minecraft:black_stained_glass
setblock 254 215 269 minecraft:black_stained_glass
setblock 256 215 264 minecraft:cyan_stained_glass
setblock 256 215 269 minecraft:black_stained_glass
setblock 258 215 264 minecraft:light_blue_stained_glass
setblock 258 215 269 minecraft:black_stained_glass
setblock 260 215 264 minecraft:cyan_stained_glass
setblock 260 215 269 minecraft:black_stained_glass
setblock 262 215 265 minecraft:cyan_stained_glass
setblock 262 215 267 minecraft:sea_lantern
setblock 274 215 235 minecraft:cyan_wool
fill 277 215 238 277 222 238 minecraft:black_concrete
setblock 235 216 260 minecraft:sea_lantern
fill 236 216 243 236 217 243 minecraft:black_concrete
fill 236 216 245 236 217 245 minecraft:black_concrete
fill 236 216 247 236 217 247 minecraft:black_concrete
fill 236 216 249 236 217 249 minecraft:black_concrete
fill 236 216 251 236 217 251 minecraft:black_concrete
fill 236 216 253 236 217 253 minecraft:black_concrete
fill 237 216 242 237 217 242 minecraft:black_concrete
fill 237 216 255 237 217 255 minecraft:black_concrete
fill 238 216 232 238 217 232 minecraft:gray_concrete
fill 238 216 234 238 217 234 minecraft:gray_concrete
fill 239 216 231 239 217 231 minecraft:gray_concrete
fill 239 216 235 239 217 235 minecraft:gray_concrete
fill 239 216 242 239 217 242 minecraft:black_concrete
fill 239 216 255 239 217 255 minecraft:black_concrete
fill 241 216 231 241 217 231 minecraft:gray_concrete
fill 241 216 235 241 217 235 minecraft:gray_concrete
fill 241 216 243 241 217 243 minecraft:black_concrete
fill 241 216 245 241 217 245 minecraft:black_concrete
fill 241 216 247 241 217 247 minecraft:black_concrete
fill 241 216 249 241 217 249 minecraft:black_concrete
fill 241 216 251 241 217 251 minecraft:black_concrete
fill 241 216 253 241 217 253 minecraft:black_concrete
fill 242 216 232 242 217 232 minecraft:gray_concrete
fill 242 216 234 242 217 234 minecraft:gray_concrete
fill 249 216 265 249 217 265 minecraft:gray_concrete
fill 249 216 267 249 217 267 minecraft:gray_concrete
fill 250 216 264 250 217 264 minecraft:gray_concrete
fill 250 216 269 250 217 269 minecraft:gray_concrete
fill 252 216 264 252 217 264 minecraft:gray_concrete
fill 252 216 269 252 217 269 minecraft:gray_concrete
fill 254 216 264 254 217 264 minecraft:gray_concrete
fill 254 216 269 254 217 269 minecraft:gray_concrete
fill 256 216 264 256 217 264 minecraft:gray_concrete
fill 256 216 269 256 217 269 minecraft:gray_concrete
fill 258 216 264 258 217 264 minecraft:gray_concrete
fill 258 216 269 258 217 269 minecraft:gray_concrete
fill 260 216 264 260 217 264 minecraft:gray_concrete
fill 260 216 269 260 217 269 minecraft:gray_concrete
setblock 260 216 270 minecraft:blue_concrete
fill 262 216 265 262 217 265 minecraft:gray_concrete
fill 262 216 267 262 217 267 minecraft:gray_concrete
setblock 277 216 240 minecraft:verdant_froglight
setblock 277 216 265 minecraft:ochre_froglight
setblock 235 217 254 minecraft:verdant_froglight
setblock 235 217 258 minecraft:verdant_froglight
fill 235 217 260 235 308 260 minecraft:black_concrete
setblock 238 217 228 minecraft:pearlescent_froglight
setblock 238 217 238 minecraft:light[level=12]
setblock 238 217 259 minecraft:light[level=12]
setblock 238 217 266 minecraft:light[level=12]
setblock 245 217 231 minecraft:light[level=12]
setblock 245 217 238 minecraft:light[level=12]
setblock 245 217 245 minecraft:light[level=12]
setblock 245 217 252 minecraft:light[level=12]
setblock 245 217 259 minecraft:light[level=12]
setblock 245 217 266 minecraft:light[level=12]
setblock 246 217 228 minecraft:purple_concrete
setblock 252 217 231 minecraft:light[level=12]
setblock 252 217 238 minecraft:light[level=12]
setblock 252 217 245 minecraft:light[level=12]
setblock 252 217 252 minecraft:light[level=12]
setblock 252 217 259 minecraft:light[level=12]
setblock 259 217 231 minecraft:light[level=12]
setblock 259 217 238 minecraft:light[level=12]
setblock 259 217 245 minecraft:light[level=12]
setblock 259 217 252 minecraft:light[level=12]
setblock 259 217 259 minecraft:light[level=12]
fill 260 217 270 260 222 270 minecraft:black_concrete
setblock 266 217 231 minecraft:light[level=12]
setblock 266 217 238 minecraft:light[level=12]
setblock 266 217 245 minecraft:light[level=12]
setblock 266 217 252 minecraft:light[level=12]
setblock 266 217 259 minecraft:light[level=12]
setblock 266 217 266 minecraft:light[level=12]
setblock 273 217 231 minecraft:light[level=12]
setblock 273 217 238 minecraft:light[level=12]
setblock 273 217 245 minecraft:light[level=12]
setblock 273 217 252 minecraft:light[level=12]
setblock 273 217 259 minecraft:light[level=12]
setblock 273 217 266 minecraft:light[level=12]
fill 277 217 240 277 221 240 minecraft:black_concrete
fill 277 217 265 277 254 265 minecraft:black_concrete
fill 235 218 254 235 280 254 minecraft:black_concrete
fill 235 218 258 235 264 258 minecraft:black_concrete
setblock 236 218 243 minecraft:pearlescent_froglight
setblock 236 218 245 minecraft:pearlescent_froglight
setblock 236 218 247 minecraft:ochre_froglight
setblock 236 218 249 minecraft:black_stained_glass
setblock 236 218 251 minecraft:sea_lantern
setblock 236 218 253 minecraft:cyan_stained_glass
setblock 237 218 242 minecraft:ochre_froglight
setblock 237 218 255 minecraft:black_stained_glass
fill 238 218 228 238 279 228 minecraft:black_concrete
setblock 238 218 232 minecraft:black_stained_glass
setblock 238 218 234 minecraft:cyan_stained_glass
setblock 239 218 231 minecraft:black_stained_glass
setblock 239 218 235 minecraft:pearlescent_froglight
setblock 239 218 242 minecraft:pearlescent_froglight
setblock 239 218 255 minecraft:pearlescent_froglight
setblock 241 218 231 minecraft:sea_lantern
setblock 241 218 235 minecraft:black_stained_glass
setblock 241 218 243 minecraft:cyan_stained_glass
setblock 241 218 245 minecraft:cyan_stained_glass
setblock 241 218 247 minecraft:black_stained_glass
setblock 241 218 249 minecraft:black_stained_glass
setblock 241 218 251 minecraft:magenta_stained_glass
setblock 241 218 253 minecraft:sea_lantern
setblock 242 218 232 minecraft:black_stained_glass
setblock 242 218 234 minecraft:black_stained_glass
fill 246 218 228 246 228 228 minecraft:black_concrete
setblock 249 218 265 minecraft:magenta_stained_glass
setblock 249 218 267 minecraft:light_blue_stained_glass
setblock 250 218 264 minecraft:cyan_stained_glass
setblock 250 218 269 minecraft:light_blue_stained_glass
setblock 252 218 264 minecraft:cyan_stained_glass
setblock 252 218 269 minecraft:black_stained_glass
setblock 254 218 264 minecraft:black_stained_glass
setblock 254 218 269 minecraft:pearlescent_froglight
setblock 256 218 264 minecraft:cyan_stained_glass
setblock 256 218 269 minecraft:cyan_stained_glass
setblock 258 218 264 minecraft:pearlescent_froglight
setblock 258 218 269 minecraft:magenta_stained_glass
setblock 260 218 264 minecraft:sea_lantern
setblock 260 218 269 minecraft:cyan_stained_glass
setblock 261 218 270 minecraft:pearlescent_froglight
setblock 262 218 265 minecraft:light_blue_stained_glass
setblock 262 218 267 minecraft:light_blue_stained_glass
setblock 277 218 260 minecraft:ochre_froglight
fill 236 219 243 236 220 243 minecraft:black_concrete
fill 236 219 245 236 220 245 minecraft:black_concrete
fill 236 219 247 236 220 247 minecraft:black_concrete
fill 236 219 249 236 220 249 minecraft:black_concrete
fill 236 219 251 236 220 251 minecraft:black_concrete
fill 236 219 253 236 220 253 minecraft:black_concrete
fill 237 219 242 237 220 242 minecraft:black_concrete
fill 237 219 255 237 220 255 minecraft:black_concrete
fill 238 219 232 238 220 232 minecraft:gray_concrete
fill 238 219 234 238 220 234 minecraft:gray_concrete
fill 239 219 231 239 220 231 minecraft:gray_concrete
fill 239 219 235 239 220 235 minecraft:gray_concrete
fill 239 219 242 239 220 242 minecraft:black_concrete
fill 239 219 255 239 220 255 minecraft:black_concrete
fill 241 219 231 241 220 231 minecraft:gray_concrete
fill 241 219 235 241 220 235 minecraft:gray_concrete
fill 241 219 243 241 220 243 minecraft:black_concrete
fill 241 219 245 241 220 245 minecraft:black_concrete
fill 241 219 247 241 220 247 minecraft:black_concrete
fill 241 219 249 241 220 249 minecraft:black_concrete
fill 241 219 251 241 220 251 minecraft:black_concrete
fill 241 219 253 241 220 253 minecraft:black_concrete
fill 242 219 232 242 220 232 minecraft:gray_concrete
fill 242 219 234 242 220 234 minecraft:gray_concrete
fill 249 219 265 249 220 265 minecraft:gray_concrete
fill 249 219 267 249 220 267 minecraft:gray_concrete
fill 250 219 264 250 220 264 minecraft:gray_concrete
fill 250 219 269 250 220 269 minecraft:gray_concrete
fill 252 219 264 252 220 264 minecraft:gray_concrete
fill 252 219 269 252 220 269 minecraft:gray_concrete
fill 254 219 264 254 220 264 minecraft:gray_concrete
fill 254 219 269 254 220 269 minecraft:gray_concrete
setblock 254 219 270 minecraft:purple_concrete
fill 256 219 264 256 220 264 minecraft:gray_concrete
fill 256 219 269 256 220 269 minecraft:gray_concrete
fill 258 219 264 258 220 264 minecraft:gray_concrete
fill 258 219 269 258 220 269 minecraft:gray_concrete
fill 260 219 264 260 220 264 minecraft:gray_concrete
fill 260 219 269 260 220 269 minecraft:gray_concrete
fill 261 219 270 261 220 270 minecraft:black_concrete
fill 262 219 265 262 220 265 minecraft:gray_concrete
fill 262 219 267 262 220 267 minecraft:gray_concrete
setblock 265 219 228 minecraft:verdant_froglight
fill 277 219 260 277 220 260 minecraft:black_concrete
setblock 238 220 239 minecraft:light[level=15]
setblock 238 220 263 minecraft:light[level=15]
setblock 246 220 231 minecraft:light[level=15]
setblock 246 220 239 minecraft:light[level=15]
setblock 246 220 247 minecraft:light[level=15]
setblock 246 220 255 minecraft:light[level=15]
setblock 246 220 263 minecraft:light[level=15]
setblock 254 220 231 minecraft:light[level=15]
setblock 254 220 239 minecraft:light[level=15]
setblock 254 220 247 minecraft:light[level=15]
setblock 254 220 263 minecraft:light[level=15]
fill 254 220 270 254 299 270 minecraft:black_concrete
setblock 262 220 231 minecraft:light[level=15]
setblock 262 220 239 minecraft:light[level=15]
setblock 262 220 247 minecraft:light[level=15]
setblock 262 220 255 minecraft:light[level=15]
setblock 262 220 263 minecraft:light[level=15]
fill 265 220 228 265 308 228 minecraft:black_concrete
setblock 269 220 270 minecraft:sea_lantern
setblock 270 220 231 minecraft:light[level=15]
setblock 270 220 239 minecraft:light[level=15]
setblock 270 220 247 minecraft:light[level=15]
setblock 270 220 255 minecraft:light[level=15]
setblock 270 220 263 minecraft:light[level=15]
setblock 275 220 270 minecraft:cyan_concrete
setblock 235 221 237 minecraft:pearlescent_froglight
setblock 235 221 250 minecraft:magenta_concrete
setblock 236 221 243 minecraft:cyan_stained_glass
setblock 236 221 245 minecraft:black_stained_glass
setblock 236 221 247 minecraft:pearlescent_froglight
setblock 236 221 249 minecraft:black_stained_glass
setblock 236 221 251 minecraft:light_blue_stained_glass
setblock 236 221 253 minecraft:black_stained_glass
setblock 237 221 242 minecraft:black_stained_glass
setblock 237 221 255 minecraft:black_stained_glass
setblock 239 221 242 minecraft:cyan_stained_glass
setblock 239 221 255 minecraft:black_stained_glass
setblock 241 221 243 minecraft:ochre_froglight
setblock 241 221 245 minecraft:pearlescent_froglight
setblock 241 221 247 minecraft:black_stained_glass
setblock 241 221 249 minecraft:black_stained_glass
setblock 241 221 251 minecraft:black_stained_glass
setblock 241 221 253 minecraft:sea_lantern
fill 242 221 248 243 221 250 minecraft:light_gray_concrete
fill 243 221 244 243 222 247 minecraft:light_gray_concrete
fill 243 221 251 243 222 254 minecraft:light_gray_concrete
fill 244 221 242 244 221 245 minecraft:light_gray_concrete
fill 244 221 254 244 221 256 minecraft:light_gray_concrete
fill 245 221 241 245 222 242 minecraft:light_gray_concrete
fill 245 221 245 245 221 246 minecraft:light_gray_concrete
fill 245 221 256 245 222 257 minecraft:light_gray_concrete
setblock 245 221 270 minecraft:magenta_concrete
fill 246 221 240 246 222 240 minecraft:light_gray_concrete
fill 246 221 246 248 221 246 minecraft:light_gray_concrete
fill 246 221 258 247 221 258 minecraft:light_gray_concrete
fill 247 221 239 247 222 239 minecraft:light_gray_concrete
fill 247 221 257 248 221 257 minecraft:light_gray_concrete
fill 247 221 259 247 222 259 minecraft:light_gray_concrete
fill 248 221 238 249 222 238 minecraft:light_gray_concrete
fill 248 221 247 249 221 247 minecraft:light_gray_concrete
fill 248 221 256 249 221 256 minecraft:light_gray_concrete
fill 248 221 260 249 222 260 minecraft:light_gray_concrete
fill 249 221 237 251 221 237 minecraft:light_gray_concrete
fill 249 221 248 253 221 251 minecraft:gray_concrete
fill 249 221 255 250 221 255 minecraft:light_gray_concrete
fill 249 221 261 251 221 261 minecraft:light_gray_concrete
setblock 249 221 265 minecraft:black_stained_glass
setblock 249 221 267 minecraft:magenta_stained_glass
fill 250 221 245 262 221 247 minecraft:gray_concrete
fill 250 221 252 252 221 253 minecraft:gray_concrete
fill 250 221 254 251 221 254 minecraft:light_gray_concrete
setblock 250 221 264 minecraft:ochre_froglight
setblock 250 221 269 minecraft:black_stained_glass
fill 251 221 236 261 221 236 minecraft:light_gray_concrete
fill 251 221 244 260 221 244 minecraft:gray_concrete
fill 251 221 262 261 221 262 minecraft:light_gray_concrete
setblock 252 221 228 minecraft:blue_concrete
fill 252 221 243 260 221 243 minecraft:gray_concrete
fill 252 221 254 252 221 255 minecraft:gray_concrete
setblock 252 221 264 minecraft:ochre_froglight
setblock 252 221 269 minecraft:ochre_froglight
fill 253 221 237 253 221 238 minecraft:light_gray_concrete
setblock 253 221 255 minecraft:gray_concrete
fill 254 221 238 254 221 242 minecraft:light_gray_concrete
fill 254 221 248 254 221 250 minecraft:gray_concrete
setblock 254 221 256 minecraft:gray_concrete
setblock 254 221 264 minecraft:light_blue_stained_glass
setblock 254 221 269 minecraft:light_blue_stained_glass
fill 255 221 235 257 222 235 minecraft:light_gray_concrete
fill 255 221 242 255 223 242 minecraft:light_gray_concrete
fill 255 221 248 263 221 249 minecraft:gray_concrete
fill 255 221 263 257 222 263 minecraft:light_gray_concrete
fill 256 221 242 258 221 242 minecraft:gray_concrete
setblock 256 221 264 minecraft:black_stained_glass
setblock 256 221 269 minecraft:ochre_froglight
fill 258 221 250 263 221 250 minecraft:gray_concrete
fill 258 221 256 258 221 260 minecraft:light_gray_concrete
setblock 258 221 264 minecraft:ochre_froglight
setblock 258 221 269 minecraft:black_stained_glass
fill 259 221 251 262 221 251 minecraft:gray_concrete
fill 259 221 255 260 221 255 minecraft:gray_concrete
fill 259 221 260 259 221 261 minecraft:light_gray_concrete
fill 260 221 252 261 221 254 minecraft:gray_concrete
setblock 260 221 264 minecraft:cyan_stained_glass
setblock 260 221 269 minecraft:black_stained_glass
fill 261 221 237 263 221 237 minecraft:light_gray_concrete
fill 261 221 244 262 221 244 minecraft:light_gray_concrete
fill 261 221 261 263 221 261 minecraft:light_gray_concrete
setblock 261 221 270 minecraft:sea_lantern
fill 262 221 243 263 221 243 minecraft:light_gray_concrete
fill 262 221 252 262 221 253 minecraft:gray_concrete
setblock 262 221 265 minecraft:black_stained_glass
setblock 262 221 267 minecraft:cyan_stained_glass
fill 263 221 238 264 222 238 minecraft:light_gray_concrete
fill 263 221 242 264 221 242 minecraft:light_gray_concrete
setblock 263 221 247 minecraft:gray_concrete
fill 263 221 251 264 221 251 minecraft:light_gray_concrete
fill 263 221 260 264 222 260 minecraft:light_gray_concrete
fill 264 221 241 265 221 241 minecraft:light_gray_concrete
fill 264 221 252 267 221 252 minecraft:light_gray_concrete
fill 265 221 239 265 221 240 minecraft:light_gray_concrete
fill 265 221 259 265 222 259 minecraft:light_gray_concrete
setblock 266 221 228 minecraft:magenta_concrete
fill 266 221 240 266 223 240 minecraft:light_gray_concrete
fill 266 221 258 266 222 258 minecraft:light_gray_concrete
fill 267 221 241 267 222 242 minecraft:light_gray_concrete
fill 267 221 253 269 221 253 minecraft:light_gray_concrete
fill 267 221 256 267 222 257 minecraft:light_gray_concrete
fill 268 221 242 268 221 244 minecraft:light_gray_concrete
fill 268 221 254 268 221 256 minecraft:light_gray_concrete
fill 269 221 244 269 221 252 minecraft:light_gray_concrete
fill 269 221 254 269 222 254 minecraft:light_gray_concrete
setblock 269 221 270 minecraft:pearlescent_froglight
fill 270 221 248 270 222 250 minecraft:light_gray_concrete
setblock 274 221 228 minecraft:pearlescent_froglight
fill 275 221 270 275 308 270 minecraft:black_concrete
setblock 277 221 260 minecraft:cyan_concrete
fill 235 222 237 235 245 237 minecraft:black_concrete
fill 235 222 250 235 245 250 minecraft:black_concrete
fill 236 222 243 236 223 243 minecraft:black_concrete
fill 236 222 245 236 223 245 minecraft:black_concrete
fill 236 222 247 236 223 247 minecraft:black_concrete
fill 236 222 249 236 223 249 minecraft:black_concrete
fill 236 222 251 236 223 251 minecraft:black_concrete
fill 236 222 253 236 223 253 minecraft:black_concrete
fill 237 222 242 237 223 242 minecraft:black_concrete
fill 237 222 255 237 223 255 minecraft:black_concrete
fill 239 222 242 239 223 242 minecraft:black_concrete
fill 239 222 255 239 223 255 minecraft:black_concrete
fill 241 222 243 241 223 243 minecraft:black_concrete
fill 241 222 245 241 223 245 minecraft:black_concrete
fill 241 222 247 241 223 247 minecraft:black_concrete
fill 241 222 249 241 223 249 minecraft:black_concrete
fill 241 222 251 241 223 251 minecraft:black_concrete
fill 241 222 253 241 223 253 minecraft:black_concrete
fill 242 222 245 242 222 253 minecraft:light_gray_concrete
fill 243 222 243 244 222 243 minecraft:light_gray_concrete
setblock 243 222 248 minecraft:light_gray_concrete
fill 243 222 249 248 222 249 minecraft:gray_stained_glass
setblock 243 222 250 minecraft:light_gray_concrete
fill 243 222 255 244 222 255 minecraft:light_gray_concrete
fill 244 222 241 244 222 242 minecraft:light_gray_concrete
fill 244 222 244 247 222 245 minecraft:black_stained_glass
fill 244 222 246 244 222 248 minecraft:gray_stained_glass
fill 244 222 250 244 222 252 minecraft:black_stained_glass
fill 244 222 253 247 222 254 minecraft:gray_stained_glass
fill 244 222 256 244 222 257 minecraft:light_gray_concrete
setblock 245 222 240 minecraft:light_gray_concrete
setblock 245 222 243 minecraft:black_stained_glass
fill 245 222 246 249 222 246 minecraft:black_stained_glass
fill 245 222 247 248 222 248 minecraft:gray_stained_glass
fill 245 222 250 248 222 251 minecraft:black_stained_glass
fill 245 222 252 249 222 252 minecraft:gray_stained_glass
setblock 245 222 255 minecraft:gray_stained_glass
fill 245 222 258 246 222 258 minecraft:light_gray_concrete
fill 245 222 270 245 308 270 minecraft:black_concrete
setblock 246 222 239 minecraft:light_gray_concrete
fill 246 222 241 247 222 243 minecraft:gray_stained_glass
fill 246 222 255 248 222 257 minecraft:black_stained_glass
setblock 246 222 259 minecraft:light_gray_concrete
setblock 247 222 238 minecraft:light_gray_concrete
fill 247 222 240 250 222 240 minecraft:black_stained_glass
setblock 247 222 258 minecraft:black_stained_glass
setblock 247 222 260 minecraft:light_gray_concrete
fill 248 222 237 250 222 237 minecraft:light_gray_concrete
fill 248 222 239 250 222 239 minecraft:black_stained_glass
fill 248 222 241 251 222 241 minecraft:black_stained_glass
fill 248 222 242 248 222 244 minecraft:gray_stained_glass
fill 248 222 245 249 222 245 minecraft:black_stained_glass
fill 248 222 253 249 222 253 minecraft:gray_stained_glass
fill 248 222 254 250 222 254 minecraft:black_stained_glass
fill 248 222 258 250 222 259 minecraft:gray_stained_glass
fill 248 222 261 250 222 261 minecraft:light_gray_concrete
fill 249 222 242 251 222 242 minecraft:black_stained_glass
fill 249 222 243 249 222 244 minecraft:gray_stained_glass
fill 249 222 247 249 222 248 minecraft:light_gray_concrete
fill 249 222 249 249 222 251 minecraft:sea_lantern
fill 249 222 255 249 222 256 minecraft:black_stained_glass
fill 249 222 257 251 222 257 minecraft:gray_stained_glass
fill 249 222 265 249 223 265 minecraft:gray_concrete
fill 249 222 267 249 223 267 minecraft:gray_concrete
fill 250 222 236 255 222 236 minecraft:light_gray_concrete
fill 250 222 238 253 222 238 minecraft:gray_stained_glass
fill 250 222 243 251 222 243 minecraft:black_stained_glass
setblock 250 222 244 minecraft:gray_stained_glass
fill 250 222 245 251 222 245 minecraft:sea_lantern
fill 250 222 246 250 222 247 minecraft:light_gray_concrete
fill 250 222 248 251 222 251 minecraft:black_stained_glass
setblock 250 222 252 minecraft:sea_lantern
fill 250 222 253 251 222 253 minecraft:light_gray_concrete
setblock 250 222 255 minecraft:black_stained_glass
fill 250 222 256 251 222 256 minecraft:gray_stained_glass
fill 250 222 260 253 222 260 minecraft:black_stained_glass
fill 250 222 262 255 222 262 minecraft:light_gray_concrete
fill 250 222 264 250 223 264 minecraft:gray_concrete
fill 250 222 269 250 223 269 minecraft:gray_concrete
setblock 251 222 228 minecraft:purple_concrete
fill 251 222 237 252 222 237 minecraft:gray_stained_glass
fill 251 222 239 253 222 240 minecraft:gray_stained_glass
fill 251 222 244 252 222 244 minecraft:sea_lantern
fill 251 222 246 261 222 247 minecraft:black_stained_glass
setblock 251 222 252 minecraft:black_stained_glass
setblock 251 222 254 minecraft:light_gray_concrete
setblock 251 222 255 minecraft:gray_stained_glass
fill 251 222 258 253 222 259 minecraft:black_stained_glass
fill 251 222 261 252 222 261 minecraft:black_stained_glass
fill 252 222 228 252 271 228 minecraft:black_concrete
fill 252 222 235 254 222 235 minecraft:light_gray_concrete
fill 252 222 241 253 222 242 minecraft:gray_stained_glass
fill 252 222 243 253 222 243 minecraft:sea_lantern
fill 252 222 245 260 222 245 minecraft:black_stained_glass
fill 252 222 248 252 222 250 minecraft:black_stained_glass
fill 252 222 251 253 222 251 minecraft:pearlescent_froglight
fill 252 222 252 252 222 254 minecraft:sea_lantern
fill 252 222 255 253 222 255 minecraft:pearlescent_froglight
fill 252 222 256 252 222 257 minecraft:black_stained_glass
fill 252 222 263 254 222 263 minecraft:light_gray_concrete
fill 252 222 264 252 223 264 minecraft:gray_concrete
fill 252 222 269 252 223 269 minecraft:gray_concrete
fill 253 222 237 255 222 237 minecraft:black_stained_glass
fill 253 222 244 259 222 244 minecraft:black_stained_glass
fill 253 222 248 253 222 249 minecraft:black_stained_glass
setblock 253 222 250 minecraft:sea_lantern
setblock 253 222 256 minecraft:sea_lantern
setblock 253 222 257 minecraft:black_stained_glass
fill 253 222 261 256 222 261 minecraft:gray_stained_glass
fill 254 222 238 255 222 241 minecraft:black_stained_glass
fill 254 222 242 254 222 243 minecraft:light_gray_concrete
fill 254 222 248 262 222 248 minecraft:black_stained_glass
fill 254 222 249 254 222 250 minecraft:pearlescent_froglight
fill 254 222 256 254 222 257 minecraft:pearlescent_froglight
fill 254 222 258 256 222 260 minecraft:gray_stained_glass
fill 254 222 264 254 223 264 minecraft:gray_concrete
fill 254 222 269 254 223 269 minecraft:gray_concrete
setblock 255 222 243 minecraft:light_gray_concrete
fill 255 222 249 257 222 249 minecraft:sea_lantern
fill 255 222 257 257 222 257 minecraft:sea_lantern
fill 256 222 236 256 222 241 minecraft:gray_stained_glass
fill 256 222 242 258 222 242 minecraft:sea_lantern
fill 256 222 243 258 222 243 minecraft:black_stained_glass
setblock 256 222 262 minecraft:gray_stained_glass
fill 256 222 264 256 223 264 minecraft:gray_concrete
fill 256 222 269 256 223 269 minecraft:gray_concrete
fill 257 222 236 262 222 236 minecraft:light_gray_concrete
fill 257 222 237 258 222 241 minecraft:gray_stained_glass
fill 257 222 258 258 222 261 minecraft:black_stained_glass
fill 257 222 262 262 222 262 minecraft:light_gray_concrete
fill 258 222 235 260 222 235 minecraft:light_gray_concrete
fill 258 222 249 258 222 250 minecraft:pearlescent_froglight
fill 258 222 256 258 222 257 minecraft:pearlescent_froglight
fill 258 222 263 260 222 263 minecraft:light_gray_concrete
fill 258 222 264 258 223 264 minecraft:gray_concrete
fill 258 222 269 258 223 269 minecraft:gray_concrete
setblock 259 222 237 minecraft:gray_stained_glass
fill 259 222 238 260 222 242 minecraft:black_stained_glass
fill 259 222 243 260 222 243 minecraft:sea_lantern
fill 259 222 249 262 222 249 minecraft:black_stained_glass
setblock 259 222 250 minecraft:sea_lantern
fill 259 222 251 260 222 251 minecraft:pearlescent_froglight
fill 259 222 255 260 222 255 minecraft:pearlescent_froglight
setblock 259 222 256 minecraft:sea_lantern
fill 259 222 257 260 222 260 minecraft:gray_stained_glass
setblock 259 222 261 minecraft:black_stained_glass
fill 260 222 237 261 222 237 minecraft:black_stained_glass
fill 260 222 244 261 222 244 minecraft:light_gray_concrete
fill 260 222 250 262 222 250 minecraft:black_stained_glass
fill 260 222 252 260 222 254 minecraft:sea_lantern
setblock 260 222 256 minecraft:gray_stained_glass
fill 260 222 261 261 222 261 minecraft:gray_stained_glass
fill 260 222 264 260 223 264 minecraft:gray_concrete
fill 260 222 269 260 223 269 minecraft:gray_concrete
fill 261 222 238 261 222 240 minecraft:black_stained_glass
fill 261 222 241 261 222 243 minecraft:gray_stained_glass
fill 261 222 245 262 222 245 minecraft:light_gray_concrete
fill 261 222 251 261 222 252 minecraft:black_stained_glass
fill 261 222 253 261 222 254 minecraft:sea_lantern
fill 261 222 255 262 222 257 minecraft:black_stained_glass
fill 261 222 258 261 222 260 minecraft:gray_stained_glass
fill 261 222 270 261 231 270 minecraft:black_concrete
fill 262 222 237 264 222 237 minecraft:light_gray_concrete
setblock 262 222 238 minecraft:black_stained_glass
fill 262 222 239 262 222 242 minecraft:gray_stained_glass
fill 262 222 243 264 222 244 minecraft:black_stained_glass
setblock 262 222 246 minecraft:sea_lantern
setblock 262 222 247 minecraft:black_stained_glass
fill 262 222 251 262 222 252 minecraft:light_gray_concrete
setblock 262 222 253 minecraft:sea_lantern
fill 262 222 254 264 222 254 minecraft:gray_stained_glass
fill 262 222 258 264 222 259 minecraft:black_stained_glass
setblock 262 222 260 minecraft:gray_stained_glass
fill 262 222 261 264 222 261 minecraft:light_gray_concrete
fill 262 222 265 262 223 265 minecraft:gray_concrete
fill 262 222 267 262 223 267 minecraft:gray_concrete
fill 263 222 239 263 222 241 minecraft:gray_stained_glass
fill 263 222 242 266 222 242 minecraft:black_stained_glass
fill 263 222 245 267 222 246 minecraft:gray_stained_glass
fill 263 222 247 263 222 249 minecraft:sea_lantern
fill 263 222 250 263 222 251 minecraft:light_gray_concrete
fill 263 222 252 267 222 253 minecraft:black_stained_glass
fill 263 222 255 266 222 255 minecraft:gray_stained_glass
fill 263 222 256 263 222 257 minecraft:black_stained_glass
fill 264 222 239 264 222 240 minecraft:gray_stained_glass
fill 264 222 241 266 222 241 minecraft:black_stained_glass
fill 264 222 247 268 222 248 minecraft:black_stained_glass
fill 264 222 249 268 222 251 minecraft:gray_stained_glass
fill 264 222 256 266 222 256 minecraft:gray_stained_glass
setblock 264 222 257 minecraft:black_stained_glass
fill 265 222 238 265 222 239 minecraft:light_gray_concrete
setblock 265 222 240 minecraft:black_stained_glass
fill 265 222 243 266 222 243 minecraft:black_stained_glass
fill 265 222 244 268 222 244 minecraft:gray_stained_glass
fill 265 222 254 268 222 254 minecraft:black_stained_glass
fill 265 222 257 266 222 257 minecraft:gray_stained_glass
setblock 265 222 258 minecraft:black_stained_glass
setblock 265 222 260 minecraft:light_gray_concrete
fill 266 222 228 266 308 228 minecraft:black_concrete
setblock 266 222 239 minecraft:light_gray_concrete
setblock 266 222 259 minecraft:light_gray_concrete
setblock 267 222 240 minecraft:light_gray_concrete
setblock 267 222 243 minecraft:gray_stained_glass
setblock 267 222 255 minecraft:black_stained_glass
setblock 267 222 258 minecraft:light_gray_concrete
fill 268 222 241 268 222 243 minecraft:light_gray_concrete
setblock 268 222 245 minecraft:gray_stained_glass
setblock 268 222 246 minecraft:black_stained_glass
setblock 268 222 252 minecraft:gray_stained_glass
setblock 268 222 253 minecraft:black_stained_glass
fill 268 222 255 268 222 257 minecraft:light_gray_concrete
fill 269 222 243 269 222 248 minecraft:light_gray_concrete
setblock 269 222 249 minecraft:gray_stained_glass
fill 269 222 250 269 222 253 minecraft:light_gray_concrete
setblock 269 222 255 minecraft:light_gray_concrete
fill 269 222 270 269 239 270 minecraft:black_concrete
fill 270 222 245 270 222 247 minecraft:light_gray_concrete
fill 270 222 251 270 222 253 minecraft:light_gray_concrete
fill 274 222 228 274 226 228 minecraft:black_concrete
setblock 277 222 237 minecraft:magenta_concrete
setblock 277 222 240 minecraft:blue_concrete
fill 277 222 260 277 239 260 minecraft:black_concrete
setblock 238 223 231 minecraft:light[level=12]
setblock 238 223 238 minecraft:light[level=12]
setblock 238 223 259 minecraft:light[level=12]
setblock 238 223 266 minecraft:light[level=12]
fill 242 223 248 243 223 250 minecraft:cyan_concrete
fill 243 223 244 244 223 244 minecraft:cyan_concrete
fill 243 223 245 245 223 245 minecraft:light_gray_concrete
fill 243 223 246 243 223 247 minecraft:cyan_concrete
fill 243 223 251 243 223 254 minecraft:cyan_concrete
fill 244 223 242 244 223 243 minecraft:cyan_concrete
fill 244 223 254 244 223 256 minecraft:cyan_concrete
setblock 245 223 231 minecraft:light[level=12]
setblock 245 223 238 minecraft:light[level=12]
fill 245 223 241 245 223 242 minecraft:cyan_concrete
fill 245 223 246 248 223 246 minecraft:light_gray_concrete
setblock 245 223 252 minecraft:light[level=12]
fill 245 223 256 245 223 257 minecraft:cyan_concrete
setblock 245 223 259 minecraft:light[level=12]
setblock 245 223 266 minecraft:light[level=12]
setblock 246 223 240 minecraft:cyan_concrete
fill 246 223 258 247 223 258 minecraft:light_gray_concrete
setblock 246 223 270 minecraft:purple_concrete
setblock 247 223 239 minecraft:cyan_concrete
fill 247 223 257 248 223 257 minecraft:light_gray_concrete
setblock 247 223 259 minecraft:cyan_concrete
fill 248 223 238 249 223 238 minecraft:cyan_concrete
setblock 248 223 247 minecraft:light_gray_concrete
setblock 248 223 256 minecraft:light_gray_concrete
setblock 248 223 260 minecraft:cyan_concrete
fill 248 223 261 248 224 261 minecraft:white_concrete
fill 249 223 237 251 223 237 minecraft:cyan_concrete
fill 249 223 246 250 224 261 minecraft:gray_concrete
fill 249 223 262 262 223 262 minecraft:white_concrete
fill 251 223 228 251 250 228 minecraft:black_concrete
fill 251 223 236 252 223 236 minecraft:cyan_concrete
fill 251 223 246 264 224 247 minecraft:gray_concrete
fill 251 223 259 264 224 261 minecraft:gray_concrete
setblock 252 223 231 minecraft:light[level=12]
setblock 252 223 238 minecraft:light[level=12]
setblock 252 223 245 minecraft:light[level=12]
fill 252 223 263 259 223 263 minecraft:white_concrete
fill 253 223 236 253 223 238 minecraft:light_gray_concrete
fill 254 223 236 261 223 236 minecraft:cyan_concrete
fill 254 223 238 254 223 242 minecraft:light_gray_concrete
fill 255 223 235 257 223 235 minecraft:cyan_concrete
setblock 259 223 231 minecraft:light[level=12]
setblock 259 223 238 minecraft:light[level=12]
setblock 259 223 245 minecraft:light[level=12]
setblock 260 223 270 minecraft:pearlescent_froglight
fill 261 223 237 263 223 237 minecraft:cyan_concrete
fill 261 223 244 262 223 244 minecraft:light_gray_concrete
fill 261 223 263 261 224 263 minecraft:white_concrete
fill 262 223 243 263 223 243 minecraft:light_gray_concrete
fill 262 223 248 264 224 258 minecraft:gray_concrete
fill 263 223 238 264 223 238 minecraft:cyan_concrete
fill 263 223 242 264 223 242 minecraft:light_gray_concrete
fill 264 223 241 265 223 241 minecraft:light_gray_concrete
setblock 265 223 239 minecraft:cyan_concrete
setblock 265 223 240 minecraft:light_gray_concrete
fill 265 223 252 267 223 252 minecraft:light_gray_concrete
setblock 265 223 259 minecraft:cyan_concrete
setblock 266 223 231 minecraft:light[level=12]
setblock 266 223 238 minecraft:light[level=12]
setblock 266 223 245 minecraft:light[level=12]
setblock 266 223 258 minecraft:cyan_concrete
setblock 266 223 259 minecraft:light[level=12]
setblock 266 223 266 minecraft:light[level=12]
fill 267 223 241 267 223 242 minecraft:cyan_concrete
fill 267 223 253 269 223 253 minecraft:light_gray_concrete
fill 267 223 256 267 223 257 minecraft:cyan_concrete
fill 268 223 242 268 223 244 minecraft:cyan_concrete
fill 268 223 254 268 223 256 minecraft:cyan_concrete
fill 269 223 244 269 223 252 minecraft:cyan_concrete
setblock 269 223 254 minecraft:cyan_concrete
fill 270 223 248 270 223 250 minecraft:cyan_concrete
setblock 273 223 231 minecraft:light[level=12]
setblock 273 223 238 minecraft:light[level=12]
setblock 273 223 245 minecraft:light[level=12]
setblock 273 223 252 minecraft:light[level=12]
setblock 273 223 259 minecraft:light[level=12]
setblock 273 223 266 minecraft:light[level=12]
fill 277 223 237 277 293 237 minecraft:black_concrete
setblock 277 223 238 minecraft:pearlescent_froglight
fill 277 223 240 277 280 240 minecraft:black_concrete
setblock 277 223 255 minecraft:pearlescent_froglight
fill 235 224 253 236 224 253 minecraft:ochre_froglight
setblock 235 224 255 minecraft:blue_concrete
setblock 236 224 243 minecraft:ochre_froglight
setblock 236 224 245 minecraft:light_blue_stained_glass
setblock 236 224 247 minecraft:cyan_stained_glass
setblock 236 224 249 minecraft:black_stained_glass
setblock 236 224 251 minecraft:black_stained_glass
setblock 237 224 242 minecraft:black_stained_glass
setblock 237 224 255 minecraft:magenta_stained_glass
setblock 239 224 242 minecraft:magenta_stained_glass
setblock 239 224 255 minecraft:black_stained_glass
setblock 240 224 233 minecraft:redstone_block
setblock 241 224 243 minecraft:black_stained_glass
setblock 241 224 245 minecraft:sea_lantern
setblock 241 224 247 minecraft:black_stained_glass
setblock 241 224 249 minecraft:black_stained_glass
setblock 241 224 251 minecraft:black_stained_glass
setblock 241 224 253 minecraft:ochre_froglight
fill 246 224 270 246 293 270 minecraft:black_concrete
setblock 248 224 260 minecraft:white_concrete
fill 249 224 262 251 224 262 minecraft:white_concrete
setblock 249 224 265 minecraft:light_blue_stained_glass
setblock 249 224 267 minecraft:black_stained_glass
setblock 250 224 264 minecraft:magenta_stained_glass
setblock 250 224 269 minecraft:black_stained_glass
fill 251 224 263 254 224 263 minecraft:white_concrete
fill 252 224 262 253 224 262 minecraft:light_blue_stained_glass
setblock 252 224 264 minecraft:black_stained_glass
setblock 252 224 269 minecraft:black_stained_glass
fill 254 224 262 254 225 262 minecraft:white_concrete
setblock 254 224 264 minecraft:black_stained_glass
setblock 254 224 269 minecraft:cyan_stained_glass
fill 255 224 262 255 225 263 minecraft:light_blue_stained_glass
setblock 255 224 264 minecraft:white_concrete
setblock 256 224 262 minecraft:light_blue_stained_glass
fill 256 224 263 257 224 263 minecraft:white_concrete
setblock 256 224 264 minecraft:black_stained_glass
setblock 256 224 269 minecraft:magenta_stained_glass
fill 257 224 262 257 225 262 minecraft:white_concrete
fill 258 224 262 258 225 263 minecraft:light_blue_stained_glass
setblock 258 224 264 minecraft:white_concrete
setblock 258 224 269 minecraft:black_stained_glass
fill 259 224 262 261 224 262 minecraft:light_blue_stained_glass
fill 259 224 263 260 224 263 minecraft:white_concrete
setblock 260 224 264 minecraft:magenta_stained_glass
setblock 260 224 269 minecraft:black_stained_glass
fill 260 224 270 260 227 270 minecraft:black_concrete
fill 262 224 262 262 225 262 minecraft:white_concrete
setblock 262 224 265 minecraft:ochre_froglight
setblock 262 224 267 minecraft:ochre_froglight
fill 277 224 238 277 308 238 minecraft:black_concrete
fill 277 224 255 277 260 255 minecraft:black_concrete
fill 235 225 253 236 226 253 minecraft:black_concrete
fill 235 225 255 235 266 255 minecraft:black_concrete
fill 236 225 243 236 226 243 minecraft:black_concrete
fill 236 225 245 236 226 245 minecraft:black_concrete
fill 236 225 247 236 226 247 minecraft:black_concrete
fill 236 225 249 236 226 249 minecraft:black_concrete
fill 236 225 251 236 226 251 minecraft:black_concrete
fill 237 225 242 237 226 242 minecraft:black_concrete
fill 237 225 255 237 226 255 minecraft:black_concrete
fill 239 225 242 239 226 242 minecraft:black_concrete
fill 239 225 255 239 226 255 minecraft:black_concrete
fill 241 225 243 241 226 243 minecraft:black_concrete
fill 241 225 245 241 226 245 minecraft:black_concrete
fill 241 225 247 241 226 247 minecraft:black_concrete
fill 241 225 249 241 226 249 minecraft:black_concrete
fill 241 225 251 241 226 251 minecraft:black_concrete
fill 241 225 253 241 226 253 minecraft:black_concrete
fill 249 225 246 249 237 246 minecraft:gray_concrete
setblock 249 225 247 minecraft:black_stained_glass
fill 249 225 248 250 238 248 minecraft:gray_concrete
setblock 249 225 249 minecraft:light_blue_stained_glass
fill 249 225 250 250 238 250 minecraft:gray_concrete
setblock 249 225 251 minecraft:black_stained_glass
fill 249 225 252 250 238 252 minecraft:gray_concrete
setblock 249 225 253 minecraft:sea_lantern
fill 249 225 254 250 238 254 minecraft:gray_concrete
setblock 249 225 255 minecraft:black_stained_glass
fill 249 225 256 250 238 256 minecraft:gray_concrete
setblock 249 225 257 minecraft:black_stained_glass
fill 249 225 258 250 238 258 minecraft:gray_concrete
setblock 249 225 259 minecraft:sea_lantern
fill 249 225 260 249 238 261 minecraft:gray_concrete
fill 249 225 265 249 226 265 minecraft:gray_concrete
fill 249 225 267 249 229 267 minecraft:gray_concrete
setblock 250 225 246 minecraft:light_blue_stained_glass
fill 250 225 247 263 238 247 minecraft:gray_concrete
fill 250 225 249 250 238 249 minecraft:gray_concrete
fill 250 225 251 250 238 251 minecraft:gray_concrete
fill 250 225 253 250 238 253 minecraft:gray_concrete
fill 250 225 255 250 238 255 minecraft:gray_concrete
fill 250 225 257 250 238 257 minecraft:gray_concrete
fill 250 225 259 263 238 260 minecraft:gray_concrete
setblock 250 225 261 minecraft:sea_lantern
fill 250 225 264 250 226 264 minecraft:gray_concrete
fill 250 225 269 250 226 269 minecraft:gray_concrete
fill 251 225 246 251 237 246 minecraft:gray_concrete
fill 251 225 261 251 240 261 minecraft:gray_concrete
setblock 251 225 262 minecraft:white_concrete
setblock 252 225 246 minecraft:sea_lantern
setblock 252 225 261 minecraft:black_stained_glass
setblock 252 225 262 minecraft:light_blue_stained_glass
setblock 252 225 263 minecraft:white_concrete
fill 252 225 264 252 229 264 minecraft:gray_concrete
fill 252 225 269 252 226 269 minecraft:gray_concrete
fill 253 225 246 253 237 246 minecraft:gray_concrete
fill 253 225 261 253 240 261 minecraft:gray_concrete
setblock 253 225 262 minecraft:white_concrete
setblock 254 225 246 minecraft:sea_lantern
setblock 254 225 261 minecraft:light_blue_stained_glass
setblock 254 225 263 minecraft:white_concrete
fill 254 225 264 256 226 264 minecraft:gray_concrete
fill 254 225 269 254 226 269 minecraft:gray_concrete
fill 255 225 246 255 237 246 minecraft:gray_concrete
fill 255 225 261 255 238 261 minecraft:gray_concrete
setblock 256 225 246 minecraft:light_blue_stained_glass
setblock 256 225 261 minecraft:black_stained_glass
fill 256 225 262 256 225 263 minecraft:white_concrete
fill 256 225 269 256 226 269 minecraft:gray_concrete
fill 257 225 246 257 237 246 minecraft:gray_concrete
fill 257 225 261 257 238 261 minecraft:gray_concrete
setblock 258 225 246 minecraft:black_stained_glass
setblock 258 225 261 minecraft:sea_lantern
fill 258 225 264 258 226 264 minecraft:gray_concrete
fill 258 225 269 258 226 269 minecraft:gray_concrete
fill 259 225 246 259 237 246 minecraft:gray_concrete
fill 259 225 261 259 238 261 minecraft:gray_concrete
fill 259 225 262 259 225 263 minecraft:white_concrete
setblock 260 225 246 minecraft:black_stained_glass
setblock 260 225 261 minecraft:black_stained_glass
setblock 260 225 262 minecraft:white_concrete
fill 260 225 264 260 226 264 minecraft:gray_concrete
fill 260 225 269 260 226 269 minecraft:gray_concrete
fill 261 225 246 261 237 246 minecraft:gray_concrete
fill 261 225 261 261 238 261 minecraft:gray_concrete
setblock 261 225 262 minecraft:light_blue_stained_glass
setblock 262 225 246 minecraft:sea_lantern
fill 262 225 248 263 238 258 minecraft:gray_concrete
setblock 262 225 261 minecraft:sea_lantern
fill 262 225 265 262 226 265 minecraft:gray_concrete
fill 262 225 267 262 226 267 minecraft:gray_concrete
fill 263 225 246 264 237 246 minecraft:gray_concrete
fill 263 225 261 264 238 261 minecraft:gray_concrete
setblock 264 225 247 minecraft:sea_lantern
fill 264 225 248 264 238 248 minecraft:gray_concrete
setblock 264 225 249 minecraft:black_stained_glass
fill 264 225 250 264 238 250 minecraft:gray_concrete
setblock 264 225 251 minecraft:sea_lantern
fill 264 225 252 264 238 252 minecraft:gray_concrete
setblock 264 225 253 minecraft:sea_lantern
fill 264 225 254 264 238 254 minecraft:gray_concrete
setblock 264 225 255 minecraft:black_stained_glass
fill 264 225 256 264 238 256 minecraft:gray_concrete
setblock 264 225 257 minecraft:black_stained_glass
fill 264 225 258 264 238 258 minecraft:gray_concrete
setblock 264 225 259 minecraft:sea_lantern
fill 264 225 260 264 238 260 minecraft:gray_concrete
setblock 235 226 246 minecraft:magenta_concrete
setblock 235 226 261 minecraft:ochre_froglight
fill 236 226 262 248 228 269 minecraft:gray_concrete
fill 239 226 261 248 228 261 minecraft:gray_concrete
setblock 243 226 270 minecraft:blue_concrete
fill 249 226 247 249 227 247 minecraft:gray_concrete
fill 249 226 249 249 227 249 minecraft:gray_concrete
fill 249 226 251 249 227 251 minecraft:gray_concrete
fill 249 226 253 249 227 253 minecraft:gray_concrete
fill 249 226 255 249 227 255 minecraft:gray_concrete
fill 249 226 257 249 227 257 minecraft:gray_concrete
fill 249 226 259 249 227 259 minecraft:gray_concrete
fill 249 226 262 253 228 263 minecraft:gray_concrete
fill 250 226 246 250 227 246 minecraft:gray_concrete
fill 250 226 261 250 227 261 minecraft:gray_concrete
fill 252 226 246 252 227 246 minecraft:gray_concrete
fill 252 226 261 252 227 261 minecraft:gray_concrete
fill 254 226 246 254 227 246 minecraft:gray_concrete
fill 254 226 261 254 227 261 minecraft:gray_concrete
fill 256 226 246 256 227 246 minecraft:gray_concrete
fill 256 226 261 256 227 261 minecraft:gray_concrete
fill 258 226 246 258 227 246 minecraft:gray_concrete
fill 258 226 261 258 227 261 minecraft:gray_concrete
fill 260 226 246 260 227 246 minecraft:gray_concrete
fill 260 226 261 260 227 261 minecraft:gray_concrete
fill 262 226 246 262 227 246 minecraft:gray_concrete
fill 262 226 261 262 227 261 minecraft:gray_concrete
fill 264 226 247 264 227 247 minecraft:gray_concrete
fill 264 226 249 264 227 249 minecraft:gray_concrete
fill 264 226 251 264 227 251 minecraft:gray_concrete
fill 264 226 253 264 227 253 minecraft:gray_concrete
fill 264 226 255 264 227 255 minecraft:gray_concrete
fill 264 226 257 264 227 257 minecraft:gray_concrete
fill 264 226 259 264 227 259 minecraft:gray_concrete
fill 267 226 229 273 228 233 minecraft:gray_concrete
fill 268 226 241 276 228 249 minecraft:gray_concrete
schedule function dropper:buildpart/53_6 1t
