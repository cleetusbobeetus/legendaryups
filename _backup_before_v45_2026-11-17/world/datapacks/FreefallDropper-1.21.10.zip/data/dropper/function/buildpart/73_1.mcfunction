setblock 88 90 349 minecraft:stripped_dark_oak_log
fill 88 90 351 88 90 354 minecraft:stripped_dark_oak_log
setblock 88 90 356 minecraft:stripped_dark_oak_log
fill 88 90 358 88 90 361 minecraft:stripped_dark_oak_log
fill 48 91 364 48 127 364 minecraft:dark_oak_planks
fill 65 91 322 65 126 322 minecraft:dark_oak_planks
fill 67 91 322 75 93 322 minecraft:dark_oak_planks
setblock 76 91 322 minecraft:red_concrete
fill 77 91 322 81 125 322 minecraft:dark_oak_planks
setblock 48 92 329 minecraft:stripped_dark_oak_log
setblock 48 92 336 minecraft:stripped_dark_oak_log
setblock 48 92 343 minecraft:stripped_dark_oak_log
setblock 48 92 350 minecraft:stripped_dark_oak_log
setblock 48 92 357 minecraft:stripped_dark_oak_log
setblock 49 92 323 minecraft:stripped_dark_oak_log
setblock 49 92 363 minecraft:stripped_dark_oak_log
setblock 56 92 323 minecraft:stripped_dark_oak_log
setblock 56 92 363 minecraft:stripped_dark_oak_log
setblock 63 92 323 minecraft:stripped_dark_oak_log
setblock 63 92 363 minecraft:stripped_dark_oak_log
setblock 70 92 323 minecraft:stripped_dark_oak_log
setblock 70 92 363 minecraft:stripped_dark_oak_log
fill 76 92 322 76 129 322 minecraft:dark_oak_planks
setblock 77 92 323 minecraft:stripped_dark_oak_log
setblock 77 92 363 minecraft:stripped_dark_oak_log
setblock 84 92 323 minecraft:stripped_dark_oak_log
setblock 84 92 363 minecraft:stripped_dark_oak_log
setblock 88 92 326 minecraft:stripped_dark_oak_log
setblock 88 92 333 minecraft:stripped_dark_oak_log
setblock 88 92 340 minecraft:stripped_dark_oak_log
setblock 88 92 347 minecraft:stripped_dark_oak_log
setblock 88 92 354 minecraft:stripped_dark_oak_log
setblock 88 92 361 minecraft:stripped_dark_oak_log
setblock 48 93 323 minecraft:stripped_dark_oak_log
setblock 48 93 330 minecraft:stripped_dark_oak_log
setblock 48 93 337 minecraft:stripped_dark_oak_log
fill 48 93 339 50 94 339 minecraft:iron_bars
setblock 48 93 344 minecraft:stripped_dark_oak_log
setblock 48 93 351 minecraft:stripped_dark_oak_log
setblock 48 93 358 minecraft:stripped_dark_oak_log
setblock 50 93 329 minecraft:red_concrete
setblock 50 93 363 minecraft:stripped_dark_oak_log
setblock 55 93 323 minecraft:stripped_dark_oak_log
setblock 57 93 363 minecraft:stripped_dark_oak_log
setblock 62 93 323 minecraft:stripped_dark_oak_log
setblock 64 93 363 minecraft:stripped_dark_oak_log
setblock 69 93 323 minecraft:stripped_dark_oak_log
setblock 71 93 363 minecraft:stripped_dark_oak_log
setblock 76 93 323 minecraft:stripped_dark_oak_log
setblock 78 93 363 minecraft:stripped_dark_oak_log
setblock 83 93 323 minecraft:stripped_dark_oak_log
setblock 85 93 363 minecraft:stripped_dark_oak_log
setblock 88 93 325 minecraft:stripped_dark_oak_log
setblock 88 93 332 minecraft:stripped_dark_oak_log
setblock 88 93 339 minecraft:stripped_dark_oak_log
setblock 88 93 346 minecraft:stripped_dark_oak_log
setblock 88 93 353 minecraft:stripped_dark_oak_log
setblock 88 93 360 minecraft:stripped_dark_oak_log
fill 47 94 324 47 129 325 minecraft:dark_oak_planks
setblock 47 94 326 minecraft:red_concrete
fill 47 94 327 47 129 327 minecraft:dark_oak_planks
setblock 47 94 338 minecraft:red_concrete
fill 47 94 339 47 129 339 minecraft:dark_oak_planks
setblock 48 94 324 minecraft:stripped_dark_oak_log
setblock 48 94 331 minecraft:stripped_dark_oak_log
setblock 48 94 338 minecraft:stripped_dark_oak_log
setblock 48 94 345 minecraft:stripped_dark_oak_log
setblock 48 94 352 minecraft:stripped_dark_oak_log
setblock 48 94 359 minecraft:stripped_dark_oak_log
fill 50 94 329 50 95 329 minecraft:shroomlight
setblock 51 94 363 minecraft:stripped_dark_oak_log
setblock 54 94 323 minecraft:stripped_dark_oak_log
setblock 58 94 363 minecraft:stripped_dark_oak_log
fill 60 94 322 60 120 322 minecraft:dark_oak_planks
setblock 61 94 322 minecraft:red_concrete
setblock 61 94 323 minecraft:stripped_dark_oak_log
fill 62 94 322 64 110 322 minecraft:dark_oak_planks
setblock 65 94 363 minecraft:stripped_dark_oak_log
fill 67 94 322 73 109 322 minecraft:dark_oak_planks
setblock 68 94 323 minecraft:stripped_dark_oak_log
setblock 72 94 363 minecraft:stripped_dark_oak_log
setblock 74 94 322 minecraft:red_concrete
fill 75 94 322 75 129 322 minecraft:dark_oak_planks
setblock 75 94 323 minecraft:stripped_dark_oak_log
setblock 79 94 363 minecraft:stripped_dark_oak_log
setblock 82 94 323 minecraft:stripped_dark_oak_log
setblock 86 94 363 minecraft:stripped_dark_oak_log
setblock 88 94 324 minecraft:stripped_dark_oak_log
setblock 88 94 331 minecraft:stripped_dark_oak_log
setblock 88 94 338 minecraft:stripped_dark_oak_log
setblock 88 94 345 minecraft:stripped_dark_oak_log
setblock 88 94 352 minecraft:stripped_dark_oak_log
setblock 88 94 359 minecraft:stripped_dark_oak_log
fill 47 95 326 47 131 326 minecraft:dark_oak_planks
fill 47 95 338 47 126 338 minecraft:dark_oak_planks
setblock 48 95 325 minecraft:stripped_dark_oak_log
setblock 48 95 332 minecraft:stripped_dark_oak_log
setblock 48 95 339 minecraft:stripped_dark_oak_log
setblock 48 95 346 minecraft:stripped_dark_oak_log
setblock 48 95 353 minecraft:stripped_dark_oak_log
setblock 48 95 360 minecraft:stripped_dark_oak_log
fill 49 95 322 57 97 322 minecraft:dark_oak_planks
fill 51 95 335 51 100 335 minecraft:red_concrete
setblock 52 95 363 minecraft:stripped_dark_oak_log
setblock 53 95 323 minecraft:stripped_dark_oak_log
setblock 58 95 322 minecraft:red_concrete
setblock 59 95 363 minecraft:stripped_dark_oak_log
setblock 60 95 323 minecraft:stripped_dark_oak_log
fill 61 95 322 61 129 322 minecraft:dark_oak_planks
setblock 66 95 363 minecraft:stripped_dark_oak_log
setblock 67 95 323 minecraft:stripped_dark_oak_log
setblock 73 95 363 minecraft:stripped_dark_oak_log
fill 74 95 322 74 114 322 minecraft:dark_oak_planks
setblock 74 95 323 minecraft:stripped_dark_oak_log
setblock 80 95 363 minecraft:stripped_dark_oak_log
setblock 81 95 323 minecraft:stripped_dark_oak_log
setblock 87 95 363 minecraft:stripped_dark_oak_log
setblock 88 95 323 minecraft:stripped_dark_oak_log
setblock 88 95 330 minecraft:stripped_dark_oak_log
setblock 88 95 337 minecraft:stripped_dark_oak_log
setblock 88 95 344 minecraft:stripped_dark_oak_log
setblock 88 95 351 minecraft:stripped_dark_oak_log
setblock 88 95 358 minecraft:stripped_dark_oak_log
setblock 48 96 326 minecraft:stripped_dark_oak_log
setblock 48 96 333 minecraft:stripped_dark_oak_log
setblock 48 96 340 minecraft:stripped_dark_oak_log
setblock 48 96 347 minecraft:stripped_dark_oak_log
setblock 48 96 354 minecraft:stripped_dark_oak_log
setblock 48 96 361 minecraft:stripped_dark_oak_log
setblock 50 96 325 minecraft:light[level=12]
setblock 50 96 329 minecraft:red_concrete
setblock 50 96 332 minecraft:light[level=12]
fill 50 96 335 50 100 335 minecraft:red_concrete
setblock 50 96 339 minecraft:light[level=12]
setblock 50 96 346 minecraft:light[level=12]
setblock 50 96 353 minecraft:light[level=12]
setblock 50 96 360 minecraft:light[level=12]
setblock 52 96 323 minecraft:stripped_dark_oak_log
fill 52 96 344 52 99 344 minecraft:iron_bars
setblock 53 96 363 minecraft:stripped_dark_oak_log
setblock 57 96 325 minecraft:light[level=12]
setblock 57 96 332 minecraft:light[level=12]
setblock 57 96 339 minecraft:light[level=12]
setblock 57 96 346 minecraft:light[level=12]
setblock 57 96 353 minecraft:light[level=12]
setblock 57 96 360 minecraft:light[level=12]
fill 58 96 322 58 129 322 minecraft:dark_oak_planks
setblock 59 96 323 minecraft:stripped_dark_oak_log
setblock 60 96 363 minecraft:stripped_dark_oak_log
setblock 64 96 325 minecraft:light[level=12]
setblock 64 96 332 minecraft:light[level=12]
setblock 64 96 339 minecraft:light[level=12]
setblock 64 96 346 minecraft:light[level=12]
setblock 64 96 353 minecraft:light[level=12]
setblock 64 96 360 minecraft:light[level=12]
setblock 66 96 323 minecraft:stripped_dark_oak_log
setblock 67 96 363 minecraft:stripped_dark_oak_log
setblock 71 96 325 minecraft:light[level=12]
setblock 71 96 332 minecraft:light[level=12]
setblock 71 96 339 minecraft:light[level=12]
setblock 71 96 346 minecraft:light[level=12]
setblock 71 96 353 minecraft:light[level=12]
setblock 71 96 360 minecraft:light[level=12]
setblock 73 96 323 minecraft:stripped_dark_oak_log
setblock 74 96 363 minecraft:stripped_dark_oak_log
setblock 78 96 325 minecraft:light[level=12]
setblock 78 96 332 minecraft:light[level=12]
setblock 78 96 339 minecraft:light[level=12]
setblock 78 96 346 minecraft:light[level=12]
setblock 78 96 353 minecraft:light[level=12]
setblock 78 96 360 minecraft:light[level=12]
setblock 80 96 323 minecraft:stripped_dark_oak_log
setblock 81 96 363 minecraft:stripped_dark_oak_log
setblock 85 96 325 minecraft:light[level=12]
setblock 85 96 332 minecraft:light[level=12]
setblock 85 96 339 minecraft:light[level=12]
setblock 85 96 346 minecraft:light[level=12]
setblock 85 96 353 minecraft:light[level=12]
setblock 85 96 360 minecraft:light[level=12]
setblock 87 96 323 minecraft:stripped_dark_oak_log
setblock 88 96 329 minecraft:stripped_dark_oak_log
setblock 88 96 336 minecraft:stripped_dark_oak_log
setblock 88 96 343 minecraft:stripped_dark_oak_log
setblock 88 96 350 minecraft:stripped_dark_oak_log
setblock 88 96 357 minecraft:stripped_dark_oak_log
setblock 88 96 363 minecraft:stripped_dark_oak_log
setblock 89 96 323 minecraft:red_concrete
fill 89 96 324 89 97 344 minecraft:dark_oak_planks
setblock 48 97 327 minecraft:stripped_dark_oak_log
setblock 48 97 334 minecraft:stripped_dark_oak_log
setblock 48 97 341 minecraft:stripped_dark_oak_log
setblock 48 97 348 minecraft:stripped_dark_oak_log
setblock 48 97 355 minecraft:stripped_dark_oak_log
setblock 48 97 362 minecraft:stripped_dark_oak_log
fill 49 97 364 50 129 364 minecraft:dark_oak_planks
fill 50 97 334 51 100 334 minecraft:red_concrete
fill 50 97 336 51 100 336 minecraft:red_concrete
setblock 51 97 323 minecraft:stripped_dark_oak_log
setblock 51 97 364 minecraft:red_concrete
fill 52 97 335 52 100 335 minecraft:red_concrete
fill 52 97 364 53 118 364 minecraft:dark_oak_planks
setblock 54 97 363 minecraft:stripped_dark_oak_log
setblock 58 97 323 minecraft:stripped_dark_oak_log
setblock 61 97 363 minecraft:stripped_dark_oak_log
setblock 65 97 323 minecraft:stripped_dark_oak_log
setblock 68 97 363 minecraft:stripped_dark_oak_log
setblock 72 97 323 minecraft:stripped_dark_oak_log
setblock 75 97 363 minecraft:stripped_dark_oak_log
setblock 79 97 323 minecraft:stripped_dark_oak_log
setblock 82 97 363 minecraft:stripped_dark_oak_log
setblock 86 97 323 minecraft:stripped_dark_oak_log
setblock 88 97 328 minecraft:stripped_dark_oak_log
setblock 88 97 335 minecraft:stripped_dark_oak_log
setblock 88 97 342 minecraft:stripped_dark_oak_log
setblock 88 97 349 minecraft:stripped_dark_oak_log
setblock 88 97 356 minecraft:stripped_dark_oak_log
fill 89 97 323 89 129 323 minecraft:dark_oak_planks
fill 49 98 322 52 108 322 minecraft:dark_oak_planks
fill 49 98 335 49 100 335 minecraft:red_concrete
setblock 50 98 325 minecraft:light[level=15]
setblock 50 98 333 minecraft:light[level=15]
setblock 50 98 341 minecraft:light[level=15]
setblock 50 98 349 minecraft:light[level=15]
setblock 50 98 357 minecraft:light[level=15]
fill 51 98 364 51 129 364 minecraft:dark_oak_planks
fill 52 98 334 52 100 334 minecraft:red_concrete
fill 52 98 336 52 100 336 minecraft:red_concrete
setblock 53 98 322 minecraft:red_concrete
fill 54 98 322 57 125 322 minecraft:dark_oak_planks
setblock 58 98 325 minecraft:light[level=15]
setblock 58 98 333 minecraft:light[level=15]
setblock 58 98 341 minecraft:light[level=15]
setblock 58 98 349 minecraft:light[level=15]
setblock 58 98 357 minecraft:light[level=15]
setblock 66 98 325 minecraft:light[level=15]
setblock 66 98 333 minecraft:light[level=15]
setblock 66 98 341 minecraft:light[level=15]
setblock 66 98 349 minecraft:light[level=15]
setblock 66 98 357 minecraft:light[level=15]
fill 73 98 324 79 99 324 minecraft:iron_bars
setblock 74 98 325 minecraft:light[level=15]
setblock 74 98 333 minecraft:light[level=15]
setblock 74 98 341 minecraft:light[level=15]
setblock 74 98 349 minecraft:light[level=15]
setblock 74 98 357 minecraft:light[level=15]
setblock 82 98 325 minecraft:light[level=15]
setblock 82 98 333 minecraft:light[level=15]
setblock 82 98 341 minecraft:light[level=15]
setblock 82 98 349 minecraft:light[level=15]
setblock 82 98 357 minecraft:light[level=15]
setblock 89 98 324 minecraft:red_concrete
fill 89 98 325 89 102 344 minecraft:dark_oak_planks
fill 89 98 346 89 125 349 minecraft:dark_oak_planks
setblock 89 98 350 minecraft:red_concrete
fill 48 99 329 48 100 329 minecraft:stripped_dark_oak_log
fill 48 99 336 48 122 336 minecraft:stripped_dark_oak_log
fill 48 99 343 48 101 343 minecraft:stripped_dark_oak_log
fill 48 99 350 48 100 350 minecraft:stripped_dark_oak_log
fill 48 99 357 48 100 357 minecraft:stripped_dark_oak_log
fill 49 99 323 49 100 323 minecraft:stripped_dark_oak_log
fill 49 99 334 49 100 334 minecraft:red_concrete
fill 49 99 336 49 100 336 minecraft:red_concrete
fill 49 99 363 49 100 363 minecraft:stripped_dark_oak_log
fill 50 99 333 51 100 333 minecraft:red_concrete
fill 50 99 337 51 100 337 minecraft:red_concrete
fill 53 99 322 53 129 322 minecraft:dark_oak_planks
fill 53 99 335 53 100 335 minecraft:red_concrete
fill 56 99 323 56 100 323 minecraft:stripped_dark_oak_log
fill 56 99 363 56 100 363 minecraft:stripped_dark_oak_log
fill 63 99 323 63 100 323 minecraft:stripped_dark_oak_log
fill 63 99 363 63 100 363 minecraft:stripped_dark_oak_log
fill 70 99 323 70 100 323 minecraft:stripped_dark_oak_log
fill 70 99 363 70 100 363 minecraft:stripped_dark_oak_log
fill 70 99 364 71 129 364 minecraft:dark_oak_planks
setblock 72 99 364 minecraft:red_concrete
fill 77 99 323 77 100 323 minecraft:stripped_dark_oak_log
fill 77 99 363 77 100 363 minecraft:stripped_dark_oak_log
setblock 82 99 322 minecraft:red_concrete
fill 84 99 323 84 100 323 minecraft:stripped_dark_oak_log
fill 84 99 363 84 100 363 minecraft:stripped_dark_oak_log
fill 88 99 326 88 100 326 minecraft:stripped_dark_oak_log
fill 88 99 333 88 100 333 minecraft:stripped_dark_oak_log
fill 88 99 340 88 100 340 minecraft:stripped_dark_oak_log
fill 88 99 347 88 100 347 minecraft:stripped_dark_oak_log
fill 88 99 354 88 100 354 minecraft:stripped_dark_oak_log
fill 88 99 361 88 100 361 minecraft:stripped_dark_oak_log
fill 89 99 324 89 100 324 minecraft:dark_oak_planks
fill 89 99 350 89 125 350 minecraft:dark_oak_planks
fill 47 100 347 47 129 347 minecraft:dark_oak_planks
setblock 47 100 348 minecraft:red_concrete
fill 47 100 349 47 129 349 minecraft:dark_oak_planks
fill 48 100 323 48 100 327 minecraft:stripped_dark_oak_log
fill 48 100 330 48 102 334 minecraft:stripped_dark_oak_log
fill 48 100 337 48 101 341 minecraft:stripped_dark_oak_log
fill 48 100 344 48 101 348 minecraft:stripped_dark_oak_log
fill 48 100 351 48 100 355 minecraft:stripped_dark_oak_log
fill 48 100 358 48 100 362 minecraft:stripped_dark_oak_log
setblock 49 100 333 minecraft:red_concrete
setblock 49 100 337 minecraft:red_concrete
fill 49 100 339 52 100 349 minecraft:dark_oak_planks
fill 50 100 363 54 100 363 minecraft:stripped_dark_oak_log
fill 51 100 323 55 100 323 minecraft:stripped_dark_oak_log
setblock 52 100 333 minecraft:red_concrete
setblock 52 100 337 minecraft:red_concrete
setblock 53 100 334 minecraft:red_concrete
setblock 53 100 336 minecraft:red_concrete
fill 57 100 363 61 100 363 minecraft:stripped_dark_oak_log
fill 58 100 323 62 100 323 minecraft:stripped_dark_oak_log
fill 63 100 325 63 105 325 minecraft:red_concrete
fill 64 100 363 68 100 363 minecraft:stripped_dark_oak_log
fill 65 100 323 69 100 323 minecraft:stripped_dark_oak_log
fill 71 100 363 75 100 363 minecraft:stripped_dark_oak_log
fill 72 100 323 76 100 323 minecraft:stripped_dark_oak_log
fill 72 100 364 72 129 364 minecraft:dark_oak_planks
fill 78 100 363 82 100 363 minecraft:stripped_dark_oak_log
fill 79 100 323 83 100 323 minecraft:stripped_dark_oak_log
fill 82 100 322 82 129 322 minecraft:dark_oak_planks
fill 85 100 363 88 100 363 minecraft:stripped_dark_oak_log
fill 86 100 323 88 100 323 minecraft:stripped_dark_oak_log
fill 88 100 324 88 100 325 minecraft:stripped_dark_oak_log
fill 88 100 328 88 100 332 minecraft:stripped_dark_oak_log
fill 88 100 335 88 100 339 minecraft:stripped_dark_oak_log
fill 88 100 342 88 100 346 minecraft:stripped_dark_oak_log
fill 88 100 349 88 100 353 minecraft:stripped_dark_oak_log
fill 88 100 356 88 100 360 minecraft:stripped_dark_oak_log
fill 47 101 348 47 130 348 minecraft:dark_oak_planks
setblock 48 101 324 minecraft:stripped_dark_oak_log
setblock 48 101 352 minecraft:stripped_dark_oak_log
setblock 48 101 359 minecraft:stripped_dark_oak_log
fill 49 101 330 52 101 349 minecraft:stripped_dark_oak_log
setblock 51 101 363 minecraft:stripped_dark_oak_log
fill 53 101 330 54 102 340 minecraft:stripped_dark_oak_log
setblock 54 101 323 minecraft:stripped_dark_oak_log
setblock 58 101 363 minecraft:stripped_dark_oak_log
setblock 61 101 323 minecraft:stripped_dark_oak_log
setblock 65 101 363 minecraft:stripped_dark_oak_log
setblock 68 101 323 minecraft:stripped_dark_oak_log
setblock 72 101 363 minecraft:stripped_dark_oak_log
setblock 75 101 323 minecraft:stripped_dark_oak_log
setblock 79 101 363 minecraft:stripped_dark_oak_log
setblock 82 101 323 minecraft:stripped_dark_oak_log
fill 86 101 351 86 114 351 minecraft:red_wool
setblock 86 101 363 minecraft:stripped_dark_oak_log
setblock 88 101 324 minecraft:stripped_dark_oak_log
setblock 88 101 331 minecraft:stripped_dark_oak_log
setblock 88 101 338 minecraft:stripped_dark_oak_log
setblock 88 101 345 minecraft:stripped_dark_oak_log
setblock 88 101 352 minecraft:stripped_dark_oak_log
setblock 88 101 359 minecraft:stripped_dark_oak_log
setblock 89 101 324 minecraft:red_concrete
fill 47 102 341 47 114 342 minecraft:dark_oak_planks
fill 47 102 343 47 105 345 minecraft:shroomlight
setblock 48 102 325 minecraft:stripped_dark_oak_log
fill 48 102 337 52 102 340 minecraft:stripped_dark_oak_log
setblock 48 102 346 minecraft:stripped_dark_oak_log
setblock 48 102 353 minecraft:stripped_dark_oak_log
setblock 48 102 360 minecraft:stripped_dark_oak_log
fill 49 102 330 52 102 336 minecraft:stripped_dark_oak_log
setblock 50 102 325 minecraft:light[level=12]
setblock 50 102 346 minecraft:light[level=12]
setblock 50 102 353 minecraft:light[level=12]
setblock 50 102 360 minecraft:light[level=12]
fill 52 102 341 52 102 349 minecraft:red_concrete
setblock 52 102 363 minecraft:stripped_dark_oak_log
setblock 53 102 323 minecraft:stripped_dark_oak_log
setblock 57 102 325 minecraft:light[level=12]
setblock 57 102 332 minecraft:light[level=12]
setblock 57 102 339 minecraft:light[level=12]
setblock 57 102 346 minecraft:light[level=12]
setblock 57 102 353 minecraft:light[level=12]
setblock 57 102 360 minecraft:light[level=12]
setblock 59 102 363 minecraft:stripped_dark_oak_log
setblock 60 102 323 minecraft:stripped_dark_oak_log
fill 62 102 325 62 105 325 minecraft:red_concrete
fill 63 102 326 63 105 326 minecraft:red_concrete
fill 64 102 325 64 105 325 minecraft:red_concrete
setblock 64 102 332 minecraft:light[level=12]
setblock 64 102 339 minecraft:light[level=12]
setblock 64 102 346 minecraft:light[level=12]
setblock 64 102 353 minecraft:light[level=12]
setblock 64 102 360 minecraft:light[level=12]
setblock 66 102 363 minecraft:stripped_dark_oak_log
setblock 67 102 323 minecraft:stripped_dark_oak_log
setblock 71 102 325 minecraft:light[level=12]
setblock 71 102 332 minecraft:light[level=12]
setblock 71 102 339 minecraft:light[level=12]
setblock 71 102 346 minecraft:light[level=12]
setblock 71 102 353 minecraft:light[level=12]
setblock 71 102 360 minecraft:light[level=12]
setblock 73 102 363 minecraft:stripped_dark_oak_log
setblock 74 102 323 minecraft:stripped_dark_oak_log
setblock 78 102 325 minecraft:light[level=12]
setblock 78 102 332 minecraft:light[level=12]
setblock 78 102 339 minecraft:light[level=12]
setblock 78 102 346 minecraft:light[level=12]
setblock 78 102 353 minecraft:light[level=12]
setblock 78 102 360 minecraft:light[level=12]
setblock 80 102 363 minecraft:stripped_dark_oak_log
setblock 81 102 323 minecraft:stripped_dark_oak_log
setblock 85 102 325 minecraft:light[level=12]
setblock 85 102 332 minecraft:light[level=12]
setblock 85 102 339 minecraft:light[level=12]
setblock 85 102 346 minecraft:light[level=12]
setblock 85 102 353 minecraft:light[level=12]
setblock 85 102 360 minecraft:light[level=12]
fill 86 102 349 86 114 350 minecraft:red_wool
fill 86 102 352 86 114 353 minecraft:red_wool
setblock 87 102 363 minecraft:stripped_dark_oak_log
setblock 88 102 323 minecraft:stripped_dark_oak_log
setblock 88 102 330 minecraft:stripped_dark_oak_log
setblock 88 102 337 minecraft:stripped_dark_oak_log
setblock 88 102 344 minecraft:stripped_dark_oak_log
setblock 88 102 351 minecraft:stripped_dark_oak_log
setblock 88 102 358 minecraft:stripped_dark_oak_log
fill 89 102 324 89 129 324 minecraft:dark_oak_planks
fill 47 103 355 47 127 357 minecraft:dark_oak_planks
setblock 47 103 358 minecraft:red_concrete
fill 47 103 359 47 126 361 minecraft:dark_oak_planks
setblock 48 103 326 minecraft:stripped_dark_oak_log
fill 48 103 330 48 122 330 minecraft:stripped_dark_oak_log
setblock 48 103 331 minecraft:shroomlight
fill 48 103 332 48 122 332 minecraft:stripped_dark_oak_log
setblock 48 103 333 minecraft:shroomlight
fill 48 103 334 48 122 334 minecraft:stripped_dark_oak_log
setblock 48 103 335 minecraft:shroomlight
setblock 48 103 337 minecraft:shroomlight
fill 48 103 338 48 122 338 minecraft:stripped_dark_oak_log
setblock 48 103 339 minecraft:shroomlight
fill 48 103 340 48 122 340 minecraft:stripped_dark_oak_log
setblock 48 103 347 minecraft:stripped_dark_oak_log
setblock 48 103 354 minecraft:stripped_dark_oak_log
setblock 48 103 361 minecraft:stripped_dark_oak_log
setblock 49 103 330 minecraft:shroomlight
fill 49 103 331 49 122 331 minecraft:stripped_dark_oak_log
setblock 49 103 332 minecraft:shroomlight
fill 49 103 333 49 122 333 minecraft:stripped_dark_oak_log
setblock 49 103 334 minecraft:shroomlight
fill 49 103 335 49 122 335 minecraft:stripped_dark_oak_log
setblock 49 103 336 minecraft:shroomlight
fill 49 103 337 49 122 337 minecraft:stripped_dark_oak_log
setblock 49 103 338 minecraft:shroomlight
fill 49 103 339 49 122 339 minecraft:stripped_dark_oak_log
setblock 49 103 340 minecraft:shroomlight
fill 50 103 330 50 122 330 minecraft:stripped_dark_oak_log
setblock 50 103 331 minecraft:shroomlight
fill 50 103 332 50 122 332 minecraft:stripped_dark_oak_log
setblock 50 103 333 minecraft:shroomlight
fill 50 103 334 50 122 334 minecraft:stripped_dark_oak_log
setblock 50 103 335 minecraft:shroomlight
fill 50 103 336 50 122 336 minecraft:stripped_dark_oak_log
setblock 50 103 337 minecraft:shroomlight
fill 50 103 338 50 122 338 minecraft:stripped_dark_oak_log
setblock 50 103 339 minecraft:shroomlight
fill 50 103 340 50 122 340 minecraft:stripped_dark_oak_log
setblock 51 103 330 minecraft:shroomlight
fill 51 103 331 51 122 331 minecraft:stripped_dark_oak_log
setblock 51 103 332 minecraft:shroomlight
fill 51 103 333 51 122 333 minecraft:stripped_dark_oak_log
setblock 51 103 334 minecraft:shroomlight
fill 51 103 335 51 122 335 minecraft:stripped_dark_oak_log
setblock 51 103 336 minecraft:shroomlight
fill 51 103 337 51 122 337 minecraft:stripped_dark_oak_log
setblock 51 103 338 minecraft:shroomlight
fill 51 103 339 51 122 339 minecraft:stripped_dark_oak_log
setblock 51 103 340 minecraft:shroomlight
setblock 52 103 323 minecraft:stripped_dark_oak_log
fill 52 103 330 52 122 330 minecraft:stripped_dark_oak_log
setblock 52 103 331 minecraft:shroomlight
fill 52 103 332 52 122 332 minecraft:stripped_dark_oak_log
setblock 52 103 333 minecraft:shroomlight
fill 52 103 334 52 122 334 minecraft:stripped_dark_oak_log
setblock 52 103 335 minecraft:shroomlight
fill 52 103 336 52 122 336 minecraft:stripped_dark_oak_log
setblock 52 103 337 minecraft:shroomlight
fill 52 103 338 52 122 338 minecraft:stripped_dark_oak_log
setblock 52 103 339 minecraft:shroomlight
fill 52 103 340 52 122 340 minecraft:stripped_dark_oak_log
setblock 52 103 344 minecraft:stripped_dark_oak_log
setblock 52 103 349 minecraft:stripped_dark_oak_log
setblock 53 103 330 minecraft:shroomlight
fill 53 103 331 53 122 331 minecraft:stripped_dark_oak_log
setblock 53 103 332 minecraft:shroomlight
fill 53 103 333 53 122 333 minecraft:stripped_dark_oak_log
setblock 53 103 334 minecraft:shroomlight
fill 53 103 335 53 122 335 minecraft:stripped_dark_oak_log
setblock 53 103 336 minecraft:shroomlight
fill 53 103 337 53 122 337 minecraft:stripped_dark_oak_log
setblock 53 103 338 minecraft:shroomlight
fill 53 103 339 53 122 339 minecraft:stripped_dark_oak_log
setblock 53 103 340 minecraft:shroomlight
setblock 53 103 363 minecraft:stripped_dark_oak_log
fill 54 103 330 54 122 330 minecraft:stripped_dark_oak_log
setblock 54 103 331 minecraft:shroomlight
fill 54 103 332 54 122 332 minecraft:stripped_dark_oak_log
setblock 54 103 333 minecraft:shroomlight
fill 54 103 334 54 122 334 minecraft:stripped_dark_oak_log
setblock 54 103 335 minecraft:shroomlight
fill 54 103 336 54 122 336 minecraft:stripped_dark_oak_log
setblock 54 103 337 minecraft:shroomlight
fill 54 103 338 54 122 338 minecraft:stripped_dark_oak_log
setblock 54 103 339 minecraft:shroomlight
fill 54 103 340 54 122 340 minecraft:stripped_dark_oak_log
setblock 59 103 323 minecraft:stripped_dark_oak_log
setblock 60 103 363 minecraft:stripped_dark_oak_log
fill 61 103 323 61 104 325 minecraft:iron_bars
fill 62 103 326 62 105 326 minecraft:red_concrete
fill 63 103 324 63 105 324 minecraft:red_concrete
fill 64 103 326 64 105 326 minecraft:red_concrete
setblock 66 103 323 minecraft:stripped_dark_oak_log
setblock 67 103 363 minecraft:stripped_dark_oak_log
setblock 73 103 323 minecraft:stripped_dark_oak_log
setblock 74 103 363 minecraft:stripped_dark_oak_log
setblock 80 103 323 minecraft:stripped_dark_oak_log
setblock 81 103 363 minecraft:stripped_dark_oak_log
setblock 87 103 323 minecraft:stripped_dark_oak_log
setblock 88 103 329 minecraft:stripped_dark_oak_log
setblock 88 103 336 minecraft:stripped_dark_oak_log
setblock 88 103 343 minecraft:stripped_dark_oak_log
setblock 88 103 350 minecraft:stripped_dark_oak_log
setblock 88 103 357 minecraft:stripped_dark_oak_log
setblock 88 103 363 minecraft:stripped_dark_oak_log
fill 89 103 325 89 114 334 minecraft:dark_oak_planks
setblock 89 103 335 minecraft:red_concrete
fill 89 103 336 89 125 344 minecraft:dark_oak_planks
fill 47 104 358 47 129 358 minecraft:dark_oak_planks
setblock 48 104 327 minecraft:stripped_dark_oak_log
fill 48 104 331 48 105 331 minecraft:stripped_dark_oak_log
fill 48 104 333 48 105 333 minecraft:stripped_dark_oak_log
fill 48 104 335 48 105 335 minecraft:stripped_dark_oak_log
fill 48 104 337 48 105 337 minecraft:stripped_dark_oak_log
fill 48 104 339 48 105 339 minecraft:stripped_dark_oak_log
setblock 48 104 341 minecraft:stripped_dark_oak_log
setblock 48 104 348 minecraft:stripped_dark_oak_log
setblock 48 104 355 minecraft:stripped_dark_oak_log
setblock 48 104 362 minecraft:stripped_dark_oak_log
fill 49 104 330 49 105 330 minecraft:stripped_dark_oak_log
fill 49 104 332 49 105 332 minecraft:stripped_dark_oak_log
fill 49 104 334 49 105 334 minecraft:stripped_dark_oak_log
fill 49 104 336 49 105 336 minecraft:stripped_dark_oak_log
fill 49 104 338 49 105 338 minecraft:stripped_dark_oak_log
fill 49 104 340 49 105 340 minecraft:stripped_dark_oak_log
fill 50 104 331 50 105 331 minecraft:stripped_dark_oak_log
fill 50 104 333 50 105 333 minecraft:stripped_dark_oak_log
fill 50 104 335 50 105 335 minecraft:stripped_dark_oak_log
fill 50 104 337 50 105 337 minecraft:stripped_dark_oak_log
fill 50 104 339 50 105 339 minecraft:stripped_dark_oak_log
setblock 51 104 323 minecraft:stripped_dark_oak_log
fill 51 104 330 51 105 330 minecraft:stripped_dark_oak_log
fill 51 104 332 51 105 332 minecraft:stripped_dark_oak_log
fill 51 104 334 51 105 334 minecraft:stripped_dark_oak_log
fill 51 104 336 51 105 336 minecraft:stripped_dark_oak_log
fill 51 104 338 51 105 338 minecraft:stripped_dark_oak_log
fill 51 104 340 51 105 340 minecraft:stripped_dark_oak_log
fill 52 104 331 52 105 331 minecraft:stripped_dark_oak_log
fill 52 104 333 52 105 333 minecraft:stripped_dark_oak_log
fill 52 104 335 52 105 335 minecraft:stripped_dark_oak_log
fill 52 104 337 52 105 337 minecraft:stripped_dark_oak_log
fill 52 104 339 52 105 339 minecraft:stripped_dark_oak_log
fill 53 104 330 53 105 330 minecraft:stripped_dark_oak_log
fill 53 104 332 53 105 332 minecraft:stripped_dark_oak_log
fill 53 104 334 53 105 334 minecraft:stripped_dark_oak_log
fill 53 104 336 53 105 336 minecraft:stripped_dark_oak_log
fill 53 104 338 53 105 338 minecraft:stripped_dark_oak_log
fill 53 104 340 53 105 340 minecraft:stripped_dark_oak_log
fill 54 104 331 54 105 331 minecraft:stripped_dark_oak_log
fill 54 104 333 54 105 333 minecraft:stripped_dark_oak_log
fill 54 104 335 54 105 335 minecraft:stripped_dark_oak_log
fill 54 104 337 54 105 337 minecraft:stripped_dark_oak_log
fill 54 104 339 54 105 339 minecraft:stripped_dark_oak_log
setblock 54 104 363 minecraft:stripped_dark_oak_log
setblock 58 104 323 minecraft:stripped_dark_oak_log
setblock 61 104 363 minecraft:stripped_dark_oak_log
fill 62 104 324 62 105 324 minecraft:red_concrete
fill 63 104 327 63 105 327 minecraft:red_concrete
fill 64 104 324 64 105 324 minecraft:red_concrete
setblock 65 104 323 minecraft:stripped_dark_oak_log
setblock 68 104 363 minecraft:stripped_dark_oak_log
setblock 72 104 323 minecraft:stripped_dark_oak_log
setblock 75 104 363 minecraft:stripped_dark_oak_log
setblock 79 104 323 minecraft:stripped_dark_oak_log
setblock 82 104 363 minecraft:stripped_dark_oak_log
setblock 86 104 323 minecraft:stripped_dark_oak_log
setblock 88 104 328 minecraft:stripped_dark_oak_log
setblock 88 104 335 minecraft:stripped_dark_oak_log
setblock 88 104 342 minecraft:stripped_dark_oak_log
setblock 88 104 349 minecraft:stripped_dark_oak_log
setblock 88 104 356 minecraft:stripped_dark_oak_log
fill 89 104 335 89 129 335 minecraft:dark_oak_planks
fill 61 105 325 61 105 326 minecraft:red_concrete
setblock 62 105 327 minecraft:red_concrete
setblock 63 105 323 minecraft:red_concrete
setblock 64 105 327 minecraft:red_concrete
fill 65 105 325 65 105 326 minecraft:red_concrete
fill 47 106 343 47 125 345 minecraft:dark_oak_planks
setblock 48 106 329 minecraft:stripped_dark_oak_log
setblock 48 106 331 minecraft:shroomlight
setblock 48 106 333 minecraft:shroomlight
setblock 48 106 335 minecraft:shroomlight
setblock 48 106 337 minecraft:shroomlight
setblock 48 106 339 minecraft:shroomlight
setblock 48 106 343 minecraft:stripped_dark_oak_log
setblock 48 106 350 minecraft:stripped_dark_oak_log
setblock 48 106 357 minecraft:stripped_dark_oak_log
setblock 49 106 323 minecraft:stripped_dark_oak_log
setblock 49 106 330 minecraft:shroomlight
setblock 49 106 332 minecraft:shroomlight
setblock 49 106 334 minecraft:shroomlight
setblock 49 106 336 minecraft:shroomlight
setblock 49 106 338 minecraft:shroomlight
setblock 49 106 340 minecraft:shroomlight
setblock 49 106 363 minecraft:stripped_dark_oak_log
setblock 50 106 325 minecraft:light[level=15]
setblock 50 106 331 minecraft:shroomlight
setblock 50 106 333 minecraft:shroomlight
setblock 50 106 335 minecraft:shroomlight
setblock 50 106 337 minecraft:shroomlight
setblock 50 106 339 minecraft:shroomlight
setblock 50 106 341 minecraft:light[level=15]
setblock 50 106 349 minecraft:light[level=15]
setblock 50 106 357 minecraft:light[level=15]
setblock 51 106 330 minecraft:shroomlight
setblock 51 106 332 minecraft:shroomlight
setblock 51 106 334 minecraft:shroomlight
setblock 51 106 336 minecraft:shroomlight
setblock 51 106 338 minecraft:shroomlight
setblock 51 106 340 minecraft:shroomlight
setblock 52 106 331 minecraft:shroomlight
setblock 52 106 333 minecraft:shroomlight
setblock 52 106 335 minecraft:shroomlight
setblock 52 106 337 minecraft:shroomlight
setblock 52 106 339 minecraft:shroomlight
setblock 53 106 330 minecraft:shroomlight
setblock 53 106 332 minecraft:shroomlight
setblock 53 106 334 minecraft:shroomlight
setblock 53 106 336 minecraft:shroomlight
setblock 53 106 338 minecraft:shroomlight
setblock 53 106 340 minecraft:shroomlight
setblock 54 106 331 minecraft:shroomlight
setblock 54 106 333 minecraft:shroomlight
setblock 54 106 335 minecraft:shroomlight
setblock 54 106 337 minecraft:shroomlight
setblock 54 106 339 minecraft:shroomlight
setblock 56 106 323 minecraft:stripped_dark_oak_log
setblock 56 106 363 minecraft:stripped_dark_oak_log
setblock 58 106 325 minecraft:light[level=15]
setblock 58 106 333 minecraft:light[level=15]
setblock 58 106 341 minecraft:light[level=15]
setblock 58 106 349 minecraft:light[level=15]
setblock 58 106 357 minecraft:light[level=15]
fill 59 106 323 63 108 328 minecraft:stripped_dark_oak_log
setblock 63 106 363 minecraft:stripped_dark_oak_log
fill 64 106 324 67 108 328 minecraft:stripped_dark_oak_log
fill 65 106 323 67 108 323 minecraft:stripped_dark_oak_log
setblock 66 106 333 minecraft:light[level=15]
setblock 66 106 341 minecraft:light[level=15]
setblock 66 106 349 minecraft:light[level=15]
setblock 66 106 357 minecraft:light[level=15]
setblock 70 106 323 minecraft:stripped_dark_oak_log
setblock 70 106 363 minecraft:stripped_dark_oak_log
setblock 74 106 325 minecraft:light[level=15]
setblock 74 106 333 minecraft:light[level=15]
setblock 74 106 341 minecraft:light[level=15]
setblock 74 106 349 minecraft:light[level=15]
setblock 74 106 357 minecraft:light[level=15]
setblock 77 106 323 minecraft:stripped_dark_oak_log
setblock 77 106 363 minecraft:stripped_dark_oak_log
setblock 82 106 325 minecraft:light[level=15]
setblock 82 106 333 minecraft:light[level=15]
setblock 82 106 341 minecraft:light[level=15]
setblock 82 106 349 minecraft:light[level=15]
setblock 82 106 357 minecraft:light[level=15]
setblock 84 106 323 minecraft:stripped_dark_oak_log
setblock 84 106 363 minecraft:stripped_dark_oak_log
setblock 88 106 326 minecraft:stripped_dark_oak_log
setblock 88 106 333 minecraft:stripped_dark_oak_log
setblock 88 106 340 minecraft:stripped_dark_oak_log
setblock 88 106 347 minecraft:stripped_dark_oak_log
setblock 88 106 354 minecraft:stripped_dark_oak_log
setblock 88 106 361 minecraft:stripped_dark_oak_log
setblock 48 107 323 minecraft:stripped_dark_oak_log
fill 48 107 331 48 108 331 minecraft:stripped_dark_oak_log
fill 48 107 333 48 108 333 minecraft:stripped_dark_oak_log
fill 48 107 335 48 108 335 minecraft:stripped_dark_oak_log
fill 48 107 337 48 108 337 minecraft:stripped_dark_oak_log
fill 48 107 339 48 108 339 minecraft:stripped_dark_oak_log
setblock 48 107 344 minecraft:stripped_dark_oak_log
setblock 48 107 351 minecraft:stripped_dark_oak_log
setblock 48 107 358 minecraft:stripped_dark_oak_log
fill 49 107 330 49 108 330 minecraft:stripped_dark_oak_log
fill 49 107 332 49 108 332 minecraft:stripped_dark_oak_log
fill 49 107 334 49 108 334 minecraft:stripped_dark_oak_log
fill 49 107 336 49 108 336 minecraft:stripped_dark_oak_log
fill 49 107 338 49 108 338 minecraft:stripped_dark_oak_log
fill 49 107 340 49 108 340 minecraft:stripped_dark_oak_log
fill 50 107 331 50 108 331 minecraft:stripped_dark_oak_log
fill 50 107 333 50 108 333 minecraft:stripped_dark_oak_log
fill 50 107 335 50 108 335 minecraft:stripped_dark_oak_log
fill 50 107 337 50 108 337 minecraft:stripped_dark_oak_log
fill 50 107 339 50 108 339 minecraft:stripped_dark_oak_log
setblock 50 107 363 minecraft:stripped_dark_oak_log
fill 51 107 330 51 108 330 minecraft:stripped_dark_oak_log
fill 51 107 332 51 108 332 minecraft:stripped_dark_oak_log
fill 51 107 334 51 108 334 minecraft:stripped_dark_oak_log
fill 51 107 336 51 108 336 minecraft:stripped_dark_oak_log
fill 51 107 338 51 108 338 minecraft:stripped_dark_oak_log
fill 51 107 340 51 108 340 minecraft:stripped_dark_oak_log
fill 52 107 331 52 108 331 minecraft:stripped_dark_oak_log
fill 52 107 333 52 108 333 minecraft:stripped_dark_oak_log
fill 52 107 335 52 108 335 minecraft:stripped_dark_oak_log
fill 52 107 337 52 108 337 minecraft:stripped_dark_oak_log
fill 52 107 339 52 108 339 minecraft:stripped_dark_oak_log
fill 53 107 330 53 108 330 minecraft:stripped_dark_oak_log
fill 53 107 332 53 108 332 minecraft:stripped_dark_oak_log
fill 53 107 334 53 108 334 minecraft:stripped_dark_oak_log
fill 53 107 336 53 108 336 minecraft:stripped_dark_oak_log
fill 53 107 338 53 108 338 minecraft:stripped_dark_oak_log
fill 53 107 340 53 108 340 minecraft:stripped_dark_oak_log
fill 54 107 331 54 108 331 minecraft:stripped_dark_oak_log
fill 54 107 333 54 108 333 minecraft:stripped_dark_oak_log
fill 54 107 335 54 108 335 minecraft:stripped_dark_oak_log
fill 54 107 337 54 108 337 minecraft:stripped_dark_oak_log
fill 54 107 339 54 108 339 minecraft:stripped_dark_oak_log
setblock 55 107 323 minecraft:stripped_dark_oak_log
setblock 57 107 363 minecraft:stripped_dark_oak_log
setblock 64 107 363 minecraft:stripped_dark_oak_log
setblock 69 107 323 minecraft:stripped_dark_oak_log
setblock 71 107 363 minecraft:stripped_dark_oak_log
setblock 76 107 323 minecraft:stripped_dark_oak_log
setblock 78 107 363 minecraft:stripped_dark_oak_log
setblock 83 107 323 minecraft:stripped_dark_oak_log
setblock 85 107 363 minecraft:stripped_dark_oak_log
setblock 88 107 325 minecraft:stripped_dark_oak_log
setblock 88 107 332 minecraft:stripped_dark_oak_log
setblock 88 107 339 minecraft:stripped_dark_oak_log
setblock 88 107 346 minecraft:stripped_dark_oak_log
setblock 88 107 353 minecraft:stripped_dark_oak_log
setblock 88 107 360 minecraft:stripped_dark_oak_log
setblock 48 108 324 minecraft:stripped_dark_oak_log
setblock 48 108 345 minecraft:stripped_dark_oak_log
setblock 48 108 352 minecraft:stripped_dark_oak_log
setblock 48 108 359 minecraft:stripped_dark_oak_log
setblock 50 108 325 minecraft:light[level=12]
setblock 50 108 346 minecraft:light[level=12]
setblock 50 108 353 minecraft:light[level=12]
setblock 50 108 360 minecraft:light[level=12]
setblock 51 108 363 minecraft:stripped_dark_oak_log
setblock 54 108 323 minecraft:stripped_dark_oak_log
setblock 57 108 325 minecraft:light[level=12]
setblock 57 108 332 minecraft:light[level=12]
setblock 57 108 339 minecraft:light[level=12]
setblock 57 108 346 minecraft:light[level=12]
setblock 57 108 353 minecraft:light[level=12]
setblock 57 108 360 minecraft:light[level=12]
setblock 58 108 363 minecraft:stripped_dark_oak_log
setblock 64 108 332 minecraft:light[level=12]
setblock 64 108 339 minecraft:light[level=12]
setblock 64 108 346 minecraft:light[level=12]
setblock 64 108 353 minecraft:light[level=12]
setblock 64 108 360 minecraft:light[level=12]
setblock 65 108 363 minecraft:stripped_dark_oak_log
setblock 68 108 323 minecraft:stripped_dark_oak_log
setblock 71 108 325 minecraft:light[level=12]
setblock 71 108 332 minecraft:light[level=12]
setblock 71 108 339 minecraft:light[level=12]
setblock 71 108 346 minecraft:light[level=12]
setblock 71 108 353 minecraft:light[level=12]
setblock 71 108 360 minecraft:light[level=12]
setblock 72 108 363 minecraft:stripped_dark_oak_log
setblock 74 108 364 minecraft:red_concrete
setblock 75 108 323 minecraft:stripped_dark_oak_log
fill 75 108 364 77 121 364 minecraft:dark_oak_planks
setblock 78 108 325 minecraft:light[level=12]
setblock 78 108 332 minecraft:light[level=12]
setblock 78 108 339 minecraft:light[level=12]
setblock 78 108 346 minecraft:light[level=12]
setblock 78 108 353 minecraft:light[level=12]
setblock 78 108 360 minecraft:light[level=12]
setblock 79 108 363 minecraft:stripped_dark_oak_log
setblock 82 108 323 minecraft:stripped_dark_oak_log
setblock 85 108 325 minecraft:light[level=12]
setblock 85 108 332 minecraft:light[level=12]
setblock 85 108 339 minecraft:light[level=12]
setblock 85 108 346 minecraft:light[level=12]
setblock 85 108 353 minecraft:light[level=12]
setblock 85 108 360 minecraft:light[level=12]
setblock 86 108 363 minecraft:stripped_dark_oak_log
setblock 88 108 324 minecraft:stripped_dark_oak_log
setblock 88 108 331 minecraft:stripped_dark_oak_log
setblock 88 108 338 minecraft:stripped_dark_oak_log
setblock 88 108 345 minecraft:stripped_dark_oak_log
setblock 88 108 352 minecraft:stripped_dark_oak_log
setblock 88 108 359 minecraft:stripped_dark_oak_log
fill 48 109 325 48 110 325 minecraft:stripped_dark_oak_log
setblock 48 109 331 minecraft:shroomlight
setblock 48 109 333 minecraft:shroomlight
setblock 48 109 335 minecraft:shroomlight
setblock 48 109 337 minecraft:shroomlight
setblock 48 109 339 minecraft:shroomlight
fill 48 109 346 48 110 346 minecraft:stripped_dark_oak_log
fill 48 109 353 48 110 353 minecraft:stripped_dark_oak_log
fill 48 109 360 48 110 360 minecraft:stripped_dark_oak_log
setblock 49 109 322 minecraft:red_concrete
setblock 49 109 330 minecraft:shroomlight
setblock 49 109 332 minecraft:shroomlight
setblock 49 109 334 minecraft:shroomlight
setblock 49 109 336 minecraft:shroomlight
setblock 49 109 338 minecraft:shroomlight
setblock 49 109 340 minecraft:shroomlight
fill 50 109 322 51 129 322 minecraft:dark_oak_planks
setblock 50 109 331 minecraft:shroomlight
setblock 50 109 333 minecraft:shroomlight
setblock 50 109 335 minecraft:shroomlight
setblock 50 109 337 minecraft:shroomlight
setblock 50 109 339 minecraft:shroomlight
setblock 51 109 330 minecraft:shroomlight
setblock 51 109 332 minecraft:shroomlight
setblock 51 109 334 minecraft:shroomlight
setblock 51 109 336 minecraft:shroomlight
setblock 51 109 338 minecraft:shroomlight
setblock 51 109 340 minecraft:shroomlight
setblock 52 109 322 minecraft:red_concrete
setblock 52 109 331 minecraft:shroomlight
setblock 52 109 333 minecraft:shroomlight
setblock 52 109 335 minecraft:shroomlight
setblock 52 109 337 minecraft:shroomlight
setblock 52 109 339 minecraft:shroomlight
fill 52 109 363 52 110 363 minecraft:stripped_dark_oak_log
fill 53 109 323 53 110 323 minecraft:stripped_dark_oak_log
setblock 53 109 330 minecraft:shroomlight
setblock 53 109 332 minecraft:shroomlight
setblock 53 109 334 minecraft:shroomlight
setblock 53 109 336 minecraft:shroomlight
setblock 53 109 338 minecraft:shroomlight
setblock 53 109 340 minecraft:shroomlight
setblock 54 109 331 minecraft:shroomlight
setblock 54 109 333 minecraft:shroomlight
setblock 54 109 335 minecraft:shroomlight
setblock 54 109 337 minecraft:shroomlight
setblock 54 109 339 minecraft:shroomlight
fill 59 109 323 59 122 323 minecraft:stripped_dark_oak_log
setblock 59 109 324 minecraft:shroomlight
fill 59 109 325 59 122 325 minecraft:stripped_dark_oak_log
setblock 59 109 326 minecraft:shroomlight
fill 59 109 327 59 122 327 minecraft:stripped_dark_oak_log
setblock 59 109 328 minecraft:shroomlight
fill 59 109 363 59 110 363 minecraft:stripped_dark_oak_log
setblock 60 109 323 minecraft:shroomlight
fill 60 109 324 60 122 324 minecraft:stripped_dark_oak_log
setblock 60 109 325 minecraft:shroomlight
fill 60 109 326 60 122 326 minecraft:stripped_dark_oak_log
setblock 60 109 327 minecraft:shroomlight
fill 60 109 328 60 122 328 minecraft:stripped_dark_oak_log
fill 61 109 323 61 122 323 minecraft:stripped_dark_oak_log
setblock 61 109 324 minecraft:shroomlight
fill 61 109 325 61 122 325 minecraft:stripped_dark_oak_log
setblock 61 109 326 minecraft:shroomlight
fill 61 109 327 61 122 327 minecraft:stripped_dark_oak_log
setblock 61 109 328 minecraft:shroomlight
setblock 62 109 323 minecraft:shroomlight
fill 62 109 324 62 122 324 minecraft:stripped_dark_oak_log
setblock 62 109 325 minecraft:shroomlight
fill 62 109 326 62 122 326 minecraft:stripped_dark_oak_log
setblock 62 109 327 minecraft:shroomlight
fill 62 109 328 62 122 328 minecraft:stripped_dark_oak_log
fill 63 109 323 63 122 323 minecraft:stripped_dark_oak_log
setblock 63 109 324 minecraft:shroomlight
fill 63 109 325 63 122 325 minecraft:stripped_dark_oak_log
setblock 63 109 326 minecraft:shroomlight
fill 63 109 327 63 122 327 minecraft:stripped_dark_oak_log
setblock 63 109 328 minecraft:shroomlight
setblock 64 109 323 minecraft:shroomlight
fill 64 109 324 64 122 324 minecraft:stripped_dark_oak_log
setblock 64 109 325 minecraft:shroomlight
fill 64 109 326 64 122 326 minecraft:stripped_dark_oak_log
setblock 64 109 327 minecraft:shroomlight
fill 64 109 328 64 122 328 minecraft:stripped_dark_oak_log
fill 65 109 323 65 122 323 minecraft:stripped_dark_oak_log
setblock 65 109 324 minecraft:shroomlight
fill 65 109 325 65 122 325 minecraft:stripped_dark_oak_log
setblock 65 109 326 minecraft:shroomlight
fill 65 109 327 65 122 327 minecraft:stripped_dark_oak_log
setblock 65 109 328 minecraft:shroomlight
setblock 66 109 323 minecraft:shroomlight
fill 66 109 324 66 122 324 minecraft:stripped_dark_oak_log
setblock 66 109 325 minecraft:shroomlight
fill 66 109 326 66 122 326 minecraft:stripped_dark_oak_log
setblock 66 109 327 minecraft:shroomlight
fill 66 109 328 66 122 328 minecraft:stripped_dark_oak_log
fill 66 109 363 66 110 363 minecraft:stripped_dark_oak_log
fill 67 109 323 67 122 323 minecraft:stripped_dark_oak_log
setblock 67 109 324 minecraft:shroomlight
fill 67 109 325 67 122 325 minecraft:stripped_dark_oak_log
setblock 67 109 326 minecraft:shroomlight
fill 67 109 327 67 122 327 minecraft:stripped_dark_oak_log
setblock 67 109 328 minecraft:shroomlight
fill 73 109 363 73 110 363 minecraft:stripped_dark_oak_log
fill 74 109 323 74 110 323 minecraft:stripped_dark_oak_log
fill 74 109 364 74 129 364 minecraft:dark_oak_planks
fill 80 109 363 80 110 363 minecraft:stripped_dark_oak_log
fill 81 109 323 81 110 323 minecraft:stripped_dark_oak_log
fill 87 109 363 87 110 363 minecraft:stripped_dark_oak_log
fill 88 109 323 88 110 323 minecraft:stripped_dark_oak_log
fill 88 109 330 88 110 330 minecraft:stripped_dark_oak_log
fill 88 109 337 88 110 337 minecraft:stripped_dark_oak_log
fill 88 109 344 88 110 344 minecraft:stripped_dark_oak_log
fill 88 109 351 88 110 351 minecraft:stripped_dark_oak_log
fill 88 109 358 88 110 358 minecraft:stripped_dark_oak_log
fill 48 110 323 48 110 324 minecraft:stripped_dark_oak_log
fill 48 110 326 48 110 327 minecraft:stripped_dark_oak_log
setblock 48 110 329 minecraft:stripped_dark_oak_log
fill 48 110 331 48 111 331 minecraft:stripped_dark_oak_log
fill 48 110 333 48 111 333 minecraft:stripped_dark_oak_log
fill 48 110 335 48 111 335 minecraft:stripped_dark_oak_log
fill 48 110 337 48 111 337 minecraft:stripped_dark_oak_log
fill 48 110 339 48 111 339 minecraft:stripped_dark_oak_log
fill 48 110 341 48 111 341 minecraft:stripped_dark_oak_log
fill 48 110 343 48 110 345 minecraft:stripped_dark_oak_log
fill 48 110 347 48 110 348 minecraft:stripped_dark_oak_log
fill 48 110 350 48 110 352 minecraft:stripped_dark_oak_log
fill 48 110 354 48 110 355 minecraft:stripped_dark_oak_log
fill 48 110 357 48 110 359 minecraft:stripped_dark_oak_log
fill 48 110 361 48 110 362 minecraft:stripped_dark_oak_log
fill 49 110 322 49 125 322 minecraft:dark_oak_planks
setblock 49 110 323 minecraft:stripped_dark_oak_log
fill 49 110 330 49 111 330 minecraft:stripped_dark_oak_log
fill 49 110 332 49 111 332 minecraft:stripped_dark_oak_log
fill 49 110 334 49 111 334 minecraft:stripped_dark_oak_log
fill 49 110 336 49 111 336 minecraft:stripped_dark_oak_log
fill 49 110 338 49 111 338 minecraft:stripped_dark_oak_log
fill 49 110 340 49 111 340 minecraft:stripped_dark_oak_log
fill 49 110 363 51 110 363 minecraft:stripped_dark_oak_log
fill 50 110 331 50 111 331 minecraft:stripped_dark_oak_log
fill 50 110 333 50 111 333 minecraft:stripped_dark_oak_log
fill 50 110 335 50 111 335 minecraft:stripped_dark_oak_log
fill 50 110 337 50 111 337 minecraft:stripped_dark_oak_log
fill 50 110 339 50 111 339 minecraft:stripped_dark_oak_log
fill 51 110 323 52 110 323 minecraft:stripped_dark_oak_log
fill 51 110 330 51 111 330 minecraft:stripped_dark_oak_log
fill 51 110 332 51 111 332 minecraft:stripped_dark_oak_log
fill 51 110 334 51 111 334 minecraft:stripped_dark_oak_log
fill 51 110 336 51 111 336 minecraft:stripped_dark_oak_log
fill 51 110 338 51 111 338 minecraft:stripped_dark_oak_log
fill 51 110 340 51 111 340 minecraft:stripped_dark_oak_log
fill 52 110 322 52 131 322 minecraft:dark_oak_planks
fill 52 110 331 52 111 331 minecraft:stripped_dark_oak_log
fill 52 110 333 52 111 333 minecraft:stripped_dark_oak_log
fill 52 110 335 52 111 335 minecraft:stripped_dark_oak_log
fill 52 110 337 52 111 337 minecraft:stripped_dark_oak_log
fill 52 110 339 52 111 339 minecraft:stripped_dark_oak_log
fill 53 110 330 53 111 330 minecraft:stripped_dark_oak_log
fill 53 110 332 53 111 332 minecraft:stripped_dark_oak_log
fill 53 110 334 53 111 334 minecraft:stripped_dark_oak_log
fill 53 110 336 53 111 336 minecraft:stripped_dark_oak_log
fill 53 110 338 53 111 338 minecraft:stripped_dark_oak_log
fill 53 110 340 53 111 340 minecraft:stripped_dark_oak_log
fill 53 110 363 54 110 363 minecraft:stripped_dark_oak_log
fill 54 110 323 56 110 323 minecraft:stripped_dark_oak_log
fill 54 110 331 54 111 331 minecraft:stripped_dark_oak_log
fill 54 110 333 54 111 333 minecraft:stripped_dark_oak_log
fill 54 110 335 54 111 335 minecraft:stripped_dark_oak_log
fill 54 110 337 54 111 337 minecraft:stripped_dark_oak_log
fill 54 110 339 54 111 339 minecraft:stripped_dark_oak_log
fill 56 110 363 58 110 363 minecraft:stripped_dark_oak_log
fill 58 110 323 58 111 323 minecraft:stripped_dark_oak_log
fill 59 110 324 59 111 324 minecraft:stripped_dark_oak_log
fill 59 110 326 59 111 326 minecraft:stripped_dark_oak_log
fill 59 110 328 59 111 328 minecraft:stripped_dark_oak_log
fill 60 110 323 60 111 323 minecraft:stripped_dark_oak_log
fill 60 110 325 60 111 325 minecraft:stripped_dark_oak_log
fill 60 110 327 60 111 327 minecraft:stripped_dark_oak_log
fill 60 110 363 61 110 363 minecraft:stripped_dark_oak_log
fill 61 110 324 61 111 324 minecraft:stripped_dark_oak_log
fill 61 110 326 61 111 326 minecraft:stripped_dark_oak_log
fill 61 110 328 61 111 328 minecraft:stripped_dark_oak_log
fill 62 110 323 62 111 323 minecraft:stripped_dark_oak_log
fill 62 110 325 62 111 325 minecraft:stripped_dark_oak_log
fill 62 110 327 62 111 327 minecraft:stripped_dark_oak_log
fill 63 110 324 63 111 324 minecraft:stripped_dark_oak_log
fill 63 110 326 63 111 326 minecraft:stripped_dark_oak_log
fill 63 110 328 63 111 328 minecraft:stripped_dark_oak_log
fill 63 110 363 65 110 363 minecraft:stripped_dark_oak_log
fill 64 110 323 64 111 323 minecraft:stripped_dark_oak_log
fill 64 110 325 64 111 325 minecraft:stripped_dark_oak_log
fill 64 110 327 64 111 327 minecraft:stripped_dark_oak_log
fill 65 110 324 65 111 324 minecraft:stripped_dark_oak_log
fill 65 110 326 65 111 326 minecraft:stripped_dark_oak_log
fill 65 110 328 65 111 328 minecraft:stripped_dark_oak_log
fill 66 110 323 66 111 323 minecraft:stripped_dark_oak_log
fill 66 110 325 66 111 325 minecraft:stripped_dark_oak_log
fill 66 110 327 66 111 327 minecraft:stripped_dark_oak_log
fill 67 110 322 69 126 322 minecraft:dark_oak_planks
fill 67 110 324 67 111 324 minecraft:stripped_dark_oak_log
fill 67 110 326 67 111 326 minecraft:stripped_dark_oak_log
fill 67 110 328 67 111 328 minecraft:stripped_dark_oak_log
fill 67 110 363 68 110 363 minecraft:stripped_dark_oak_log
fill 68 110 323 70 110 323 minecraft:stripped_dark_oak_log
setblock 70 110 322 minecraft:red_concrete
fill 70 110 363 72 110 363 minecraft:stripped_dark_oak_log
fill 71 110 322 73 129 322 minecraft:dark_oak_planks
fill 72 110 323 73 110 323 minecraft:stripped_dark_oak_log
fill 74 110 363 75 110 363 minecraft:stripped_dark_oak_log
fill 75 110 323 77 110 323 minecraft:stripped_dark_oak_log
fill 77 110 363 79 110 363 minecraft:stripped_dark_oak_log
fill 79 110 323 80 110 323 minecraft:stripped_dark_oak_log
fill 81 110 363 82 110 363 minecraft:stripped_dark_oak_log
fill 82 110 323 84 110 323 minecraft:stripped_dark_oak_log
fill 84 110 363 86 110 363 minecraft:stripped_dark_oak_log
fill 86 110 323 87 110 323 minecraft:stripped_dark_oak_log
fill 88 110 324 88 110 326 minecraft:stripped_dark_oak_log
fill 88 110 328 88 110 329 minecraft:stripped_dark_oak_log
fill 88 110 331 88 110 333 minecraft:stripped_dark_oak_log
fill 88 110 335 88 110 336 minecraft:stripped_dark_oak_log
fill 88 110 338 88 110 340 minecraft:stripped_dark_oak_log
fill 88 110 342 88 110 343 minecraft:stripped_dark_oak_log
fill 88 110 345 88 110 347 minecraft:stripped_dark_oak_log
fill 88 110 349 88 110 350 minecraft:stripped_dark_oak_log
fill 88 110 352 88 110 354 minecraft:stripped_dark_oak_log
fill 88 110 356 88 110 357 minecraft:stripped_dark_oak_log
fill 88 110 359 88 110 361 minecraft:stripped_dark_oak_log
setblock 88 110 363 minecraft:stripped_dark_oak_log
setblock 48 111 327 minecraft:stripped_dark_oak_log
setblock 48 111 348 minecraft:stripped_dark_oak_log
setblock 48 111 355 minecraft:stripped_dark_oak_log
setblock 48 111 362 minecraft:stripped_dark_oak_log
setblock 51 111 323 minecraft:stripped_dark_oak_log
setblock 54 111 363 minecraft:stripped_dark_oak_log
setblock 61 111 363 minecraft:stripped_dark_oak_log
setblock 62 111 322 minecraft:red_concrete
fill 63 111 322 64 125 322 minecraft:dark_oak_planks
setblock 68 111 363 minecraft:stripped_dark_oak_log
fill 70 111 322 70 129 322 minecraft:dark_oak_planks
setblock 72 111 323 minecraft:stripped_dark_oak_log
setblock 75 111 363 minecraft:stripped_dark_oak_log
setblock 79 111 323 minecraft:stripped_dark_oak_log
setblock 82 111 363 minecraft:stripped_dark_oak_log
setblock 86 111 323 minecraft:stripped_dark_oak_log
setblock 88 111 328 minecraft:stripped_dark_oak_log
setblock 88 111 335 minecraft:stripped_dark_oak_log
setblock 88 111 342 minecraft:stripped_dark_oak_log
setblock 88 111 349 minecraft:stripped_dark_oak_log
setblock 88 111 356 minecraft:stripped_dark_oak_log
setblock 48 112 331 minecraft:shroomlight
setblock 48 112 333 minecraft:shroomlight
setblock 48 112 335 minecraft:shroomlight
setblock 48 112 337 minecraft:shroomlight
setblock 48 112 339 minecraft:shroomlight
setblock 49 112 330 minecraft:shroomlight
setblock 49 112 332 minecraft:shroomlight
setblock 49 112 334 minecraft:shroomlight
setblock 49 112 336 minecraft:shroomlight
setblock 49 112 338 minecraft:shroomlight
setblock 49 112 340 minecraft:shroomlight
setblock 50 112 331 minecraft:shroomlight
setblock 50 112 333 minecraft:shroomlight
setblock 50 112 335 minecraft:shroomlight
setblock 50 112 337 minecraft:shroomlight
setblock 50 112 339 minecraft:shroomlight
setblock 51 112 330 minecraft:shroomlight
setblock 51 112 332 minecraft:shroomlight
setblock 51 112 334 minecraft:shroomlight
setblock 51 112 336 minecraft:shroomlight
setblock 51 112 338 minecraft:shroomlight
setblock 51 112 340 minecraft:shroomlight
setblock 52 112 331 minecraft:shroomlight
setblock 52 112 333 minecraft:shroomlight
setblock 52 112 335 minecraft:shroomlight
setblock 52 112 337 minecraft:shroomlight
setblock 52 112 339 minecraft:shroomlight
setblock 53 112 330 minecraft:shroomlight
setblock 53 112 332 minecraft:shroomlight
setblock 53 112 334 minecraft:shroomlight
setblock 53 112 336 minecraft:shroomlight
setblock 53 112 338 minecraft:shroomlight
setblock 53 112 340 minecraft:shroomlight
setblock 54 112 331 minecraft:shroomlight
setblock 54 112 333 minecraft:shroomlight
setblock 54 112 335 minecraft:shroomlight
setblock 54 112 337 minecraft:shroomlight
setblock 54 112 339 minecraft:shroomlight
setblock 59 112 324 minecraft:shroomlight
setblock 59 112 326 minecraft:shroomlight
setblock 59 112 328 minecraft:shroomlight
setblock 60 112 323 minecraft:shroomlight
setblock 60 112 325 minecraft:shroomlight
setblock 60 112 327 minecraft:shroomlight
setblock 61 112 324 minecraft:shroomlight
setblock 61 112 326 minecraft:shroomlight
setblock 61 112 328 minecraft:shroomlight
fill 62 112 322 62 129 322 minecraft:dark_oak_planks
setblock 62 112 323 minecraft:shroomlight
setblock 62 112 325 minecraft:shroomlight
setblock 62 112 327 minecraft:shroomlight
setblock 63 112 324 minecraft:shroomlight
setblock 63 112 326 minecraft:shroomlight
setblock 63 112 328 minecraft:shroomlight
setblock 64 112 323 minecraft:shroomlight
setblock 64 112 325 minecraft:shroomlight
setblock 64 112 327 minecraft:shroomlight
setblock 65 112 324 minecraft:shroomlight
setblock 65 112 326 minecraft:shroomlight
setblock 65 112 328 minecraft:shroomlight
setblock 66 112 323 minecraft:shroomlight
setblock 66 112 325 minecraft:shroomlight
setblock 66 112 327 minecraft:shroomlight
setblock 67 112 324 minecraft:shroomlight
setblock 67 112 326 minecraft:shroomlight
setblock 67 112 328 minecraft:shroomlight
setblock 48 113 329 minecraft:stripped_dark_oak_log
fill 48 113 331 48 114 331 minecraft:stripped_dark_oak_log
fill 48 113 333 48 114 333 minecraft:stripped_dark_oak_log
fill 48 113 335 48 114 335 minecraft:stripped_dark_oak_log
fill 48 113 337 48 114 337 minecraft:stripped_dark_oak_log
fill 48 113 339 48 114 339 minecraft:stripped_dark_oak_log
setblock 48 113 343 minecraft:stripped_dark_oak_log
setblock 48 113 350 minecraft:stripped_dark_oak_log
setblock 48 113 357 minecraft:stripped_dark_oak_log
setblock 49 113 323 minecraft:stripped_dark_oak_log
fill 49 113 330 49 114 330 minecraft:stripped_dark_oak_log
fill 49 113 332 49 114 332 minecraft:stripped_dark_oak_log
fill 49 113 334 49 114 334 minecraft:stripped_dark_oak_log
fill 49 113 336 49 114 336 minecraft:stripped_dark_oak_log
fill 49 113 338 49 114 338 minecraft:stripped_dark_oak_log
fill 49 113 340 49 114 340 minecraft:stripped_dark_oak_log
setblock 49 113 363 minecraft:stripped_dark_oak_log
fill 50 113 331 50 114 331 minecraft:stripped_dark_oak_log
fill 50 113 333 50 114 333 minecraft:stripped_dark_oak_log
fill 50 113 335 50 114 335 minecraft:stripped_dark_oak_log
fill 50 113 337 50 114 337 minecraft:stripped_dark_oak_log
fill 50 113 339 50 114 339 minecraft:stripped_dark_oak_log
fill 51 113 330 51 114 330 minecraft:stripped_dark_oak_log
fill 51 113 332 51 114 332 minecraft:stripped_dark_oak_log
fill 51 113 334 51 114 334 minecraft:stripped_dark_oak_log
fill 51 113 336 51 114 336 minecraft:stripped_dark_oak_log
fill 51 113 338 51 114 338 minecraft:stripped_dark_oak_log
fill 51 113 340 51 114 340 minecraft:stripped_dark_oak_log
fill 52 113 331 52 114 331 minecraft:stripped_dark_oak_log
fill 52 113 333 52 114 333 minecraft:stripped_dark_oak_log
fill 52 113 335 52 114 335 minecraft:stripped_dark_oak_log
fill 52 113 337 52 114 337 minecraft:stripped_dark_oak_log
fill 52 113 339 52 114 339 minecraft:stripped_dark_oak_log
fill 53 113 330 53 114 330 minecraft:stripped_dark_oak_log
fill 53 113 332 53 114 332 minecraft:stripped_dark_oak_log
fill 53 113 334 53 114 334 minecraft:stripped_dark_oak_log
fill 53 113 336 53 114 336 minecraft:stripped_dark_oak_log
fill 53 113 338 53 114 338 minecraft:stripped_dark_oak_log
fill 53 113 340 53 114 340 minecraft:stripped_dark_oak_log
fill 54 113 331 54 114 331 minecraft:stripped_dark_oak_log
fill 54 113 333 54 114 333 minecraft:stripped_dark_oak_log
fill 54 113 335 54 114 335 minecraft:stripped_dark_oak_log
fill 54 113 337 54 114 337 minecraft:stripped_dark_oak_log
fill 54 113 339 54 114 339 minecraft:stripped_dark_oak_log
setblock 56 113 323 minecraft:stripped_dark_oak_log
setblock 56 113 363 minecraft:stripped_dark_oak_log
fill 59 113 324 59 114 324 minecraft:stripped_dark_oak_log
fill 59 113 326 59 114 326 minecraft:stripped_dark_oak_log
fill 59 113 328 59 114 328 minecraft:stripped_dark_oak_log
fill 60 113 323 60 114 323 minecraft:stripped_dark_oak_log
fill 60 113 325 60 114 325 minecraft:stripped_dark_oak_log
fill 60 113 327 60 114 327 minecraft:stripped_dark_oak_log
fill 61 113 324 61 114 324 minecraft:stripped_dark_oak_log
fill 61 113 326 61 114 326 minecraft:stripped_dark_oak_log
fill 61 113 328 61 114 328 minecraft:stripped_dark_oak_log
fill 62 113 323 62 114 323 minecraft:stripped_dark_oak_log
fill 62 113 325 62 114 325 minecraft:stripped_dark_oak_log
fill 62 113 327 62 114 327 minecraft:stripped_dark_oak_log
fill 63 113 324 63 114 324 minecraft:stripped_dark_oak_log
fill 63 113 326 63 114 326 minecraft:stripped_dark_oak_log
fill 63 113 328 63 114 328 minecraft:stripped_dark_oak_log
setblock 63 113 363 minecraft:stripped_dark_oak_log
fill 64 113 323 64 114 323 minecraft:stripped_dark_oak_log
fill 64 113 325 64 114 325 minecraft:stripped_dark_oak_log
fill 64 113 327 64 114 327 minecraft:stripped_dark_oak_log
fill 65 113 324 65 114 324 minecraft:stripped_dark_oak_log
fill 65 113 326 65 114 326 minecraft:stripped_dark_oak_log
fill 65 113 328 65 114 328 minecraft:stripped_dark_oak_log
fill 66 113 323 66 114 323 minecraft:stripped_dark_oak_log
fill 66 113 325 66 114 325 minecraft:stripped_dark_oak_log
fill 66 113 327 66 114 327 minecraft:stripped_dark_oak_log
fill 67 113 324 67 114 324 minecraft:stripped_dark_oak_log
fill 67 113 326 67 114 326 minecraft:stripped_dark_oak_log
fill 67 113 328 67 114 328 minecraft:stripped_dark_oak_log
setblock 70 113 323 minecraft:stripped_dark_oak_log
setblock 70 113 363 minecraft:stripped_dark_oak_log
setblock 77 113 323 minecraft:stripped_dark_oak_log
setblock 77 113 363 minecraft:stripped_dark_oak_log
setblock 84 113 323 minecraft:stripped_dark_oak_log
setblock 84 113 363 minecraft:stripped_dark_oak_log
setblock 88 113 326 minecraft:stripped_dark_oak_log
setblock 88 113 333 minecraft:stripped_dark_oak_log
setblock 88 113 340 minecraft:stripped_dark_oak_log
setblock 88 113 347 minecraft:stripped_dark_oak_log
setblock 88 113 354 minecraft:stripped_dark_oak_log
setblock 88 113 361 minecraft:stripped_dark_oak_log
setblock 48 114 323 minecraft:stripped_dark_oak_log
setblock 48 114 344 minecraft:stripped_dark_oak_log
setblock 48 114 351 minecraft:stripped_dark_oak_log
setblock 48 114 358 minecraft:stripped_dark_oak_log
setblock 50 114 325 minecraft:light[level=15]
setblock 50 114 341 minecraft:light[level=15]
setblock 50 114 346 minecraft:light[level=12]
setblock 50 114 349 minecraft:light[level=15]
setblock 50 114 353 minecraft:light[level=12]
setblock 50 114 357 minecraft:light[level=15]
setblock 50 114 360 minecraft:light[level=12]
setblock 50 114 363 minecraft:stripped_dark_oak_log
setblock 55 114 323 minecraft:stripped_dark_oak_log
setblock 57 114 325 minecraft:light[level=12]
setblock 57 114 332 minecraft:light[level=12]
setblock 57 114 339 minecraft:light[level=12]
setblock 57 114 346 minecraft:light[level=12]
setblock 57 114 353 minecraft:light[level=12]
setblock 57 114 360 minecraft:light[level=12]
setblock 57 114 363 minecraft:stripped_dark_oak_log
setblock 58 114 325 minecraft:light[level=15]
setblock 58 114 333 minecraft:light[level=15]
setblock 58 114 341 minecraft:light[level=15]
setblock 58 114 349 minecraft:light[level=15]
setblock 58 114 357 minecraft:light[level=15]
setblock 64 114 332 minecraft:light[level=12]
setblock 64 114 339 minecraft:light[level=12]
setblock 64 114 346 minecraft:light[level=12]
setblock 64 114 353 minecraft:light[level=12]
setblock 64 114 360 minecraft:light[level=12]
setblock 64 114 363 minecraft:stripped_dark_oak_log
setblock 66 114 333 minecraft:light[level=15]
setblock 66 114 341 minecraft:light[level=15]
setblock 66 114 349 minecraft:light[level=15]
setblock 66 114 357 minecraft:light[level=15]
setblock 69 114 323 minecraft:stripped_dark_oak_log
setblock 71 114 325 minecraft:light[level=12]
setblock 71 114 332 minecraft:light[level=12]
setblock 71 114 339 minecraft:light[level=12]
setblock 71 114 346 minecraft:light[level=12]
setblock 71 114 353 minecraft:light[level=12]
setblock 71 114 360 minecraft:light[level=12]
setblock 71 114 363 minecraft:stripped_dark_oak_log
setblock 74 114 325 minecraft:light[level=15]
setblock 74 114 333 minecraft:light[level=15]
setblock 74 114 341 minecraft:light[level=15]
setblock 74 114 349 minecraft:light[level=15]
setblock 74 114 357 minecraft:light[level=15]
setblock 76 114 323 minecraft:stripped_dark_oak_log
setblock 78 114 325 minecraft:light[level=12]
setblock 78 114 332 minecraft:light[level=12]
setblock 78 114 339 minecraft:light[level=12]
setblock 78 114 346 minecraft:light[level=12]
setblock 78 114 353 minecraft:light[level=12]
setblock 78 114 360 minecraft:light[level=12]
setblock 78 114 363 minecraft:stripped_dark_oak_log
setblock 82 114 325 minecraft:light[level=15]
setblock 82 114 333 minecraft:light[level=15]
setblock 82 114 341 minecraft:light[level=15]
setblock 82 114 349 minecraft:light[level=15]
setblock 82 114 357 minecraft:light[level=15]
setblock 83 114 323 minecraft:stripped_dark_oak_log
setblock 85 114 325 minecraft:light[level=12]
setblock 85 114 332 minecraft:light[level=12]
setblock 85 114 339 minecraft:light[level=12]
setblock 85 114 346 minecraft:light[level=12]
setblock 85 114 353 minecraft:light[level=12]
setblock 85 114 360 minecraft:light[level=12]
setblock 85 114 363 minecraft:stripped_dark_oak_log
setblock 88 114 325 minecraft:stripped_dark_oak_log
setblock 88 114 332 minecraft:stripped_dark_oak_log
setblock 88 114 339 minecraft:stripped_dark_oak_log
setblock 88 114 346 minecraft:stripped_dark_oak_log
setblock 88 114 353 minecraft:stripped_dark_oak_log
setblock 88 114 360 minecraft:stripped_dark_oak_log
fill 47 115 341 47 129 341 minecraft:dark_oak_planks
setblock 47 115 342 minecraft:red_concrete
setblock 48 115 324 minecraft:stripped_dark_oak_log
setblock 48 115 331 minecraft:shroomlight
setblock 48 115 333 minecraft:shroomlight
setblock 48 115 335 minecraft:shroomlight
setblock 48 115 337 minecraft:shroomlight
setblock 48 115 339 minecraft:shroomlight
setblock 48 115 345 minecraft:stripped_dark_oak_log
setblock 48 115 352 minecraft:stripped_dark_oak_log
setblock 48 115 359 minecraft:stripped_dark_oak_log
setblock 49 115 330 minecraft:shroomlight
setblock 49 115 332 minecraft:shroomlight
setblock 49 115 334 minecraft:shroomlight
setblock 49 115 336 minecraft:shroomlight
setblock 49 115 338 minecraft:shroomlight
setblock 49 115 340 minecraft:shroomlight
setblock 50 115 331 minecraft:shroomlight
setblock 50 115 333 minecraft:shroomlight
setblock 50 115 335 minecraft:shroomlight
setblock 50 115 337 minecraft:shroomlight
setblock 50 115 339 minecraft:shroomlight
setblock 51 115 330 minecraft:shroomlight
setblock 51 115 332 minecraft:shroomlight
setblock 51 115 334 minecraft:shroomlight
setblock 51 115 336 minecraft:shroomlight
setblock 51 115 338 minecraft:shroomlight
setblock 51 115 340 minecraft:shroomlight
setblock 51 115 363 minecraft:stripped_dark_oak_log
setblock 52 115 331 minecraft:shroomlight
setblock 52 115 333 minecraft:shroomlight
setblock 52 115 335 minecraft:shroomlight
setblock 52 115 337 minecraft:shroomlight
setblock 52 115 339 minecraft:shroomlight
setblock 53 115 330 minecraft:shroomlight
setblock 53 115 332 minecraft:shroomlight
setblock 53 115 334 minecraft:shroomlight
setblock 53 115 336 minecraft:shroomlight
setblock 53 115 338 minecraft:shroomlight
setblock 53 115 340 minecraft:shroomlight
setblock 54 115 323 minecraft:stripped_dark_oak_log
setblock 54 115 331 minecraft:shroomlight
setblock 54 115 333 minecraft:shroomlight
setblock 54 115 335 minecraft:shroomlight
setblock 54 115 337 minecraft:shroomlight
setblock 54 115 339 minecraft:shroomlight
setblock 55 115 364 minecraft:red_concrete
fill 56 115 364 61 125 364 minecraft:dark_oak_planks
setblock 58 115 363 minecraft:stripped_dark_oak_log
setblock 59 115 324 minecraft:shroomlight
setblock 59 115 326 minecraft:shroomlight
setblock 59 115 328 minecraft:shroomlight
setblock 60 115 323 minecraft:shroomlight
setblock 60 115 325 minecraft:shroomlight
setblock 60 115 327 minecraft:shroomlight
setblock 61 115 324 minecraft:shroomlight
setblock 61 115 326 minecraft:shroomlight
setblock 61 115 328 minecraft:shroomlight
setblock 62 115 323 minecraft:shroomlight
setblock 62 115 325 minecraft:shroomlight
setblock 62 115 327 minecraft:shroomlight
setblock 63 115 324 minecraft:shroomlight
setblock 63 115 326 minecraft:shroomlight
setblock 63 115 328 minecraft:shroomlight
setblock 64 115 323 minecraft:shroomlight
setblock 64 115 325 minecraft:shroomlight
setblock 64 115 327 minecraft:shroomlight
setblock 65 115 324 minecraft:shroomlight
setblock 65 115 326 minecraft:shroomlight
setblock 65 115 328 minecraft:shroomlight
setblock 65 115 363 minecraft:stripped_dark_oak_log
setblock 66 115 323 minecraft:shroomlight
setblock 66 115 325 minecraft:shroomlight
setblock 66 115 327 minecraft:shroomlight
setblock 67 115 324 minecraft:shroomlight
setblock 67 115 326 minecraft:shroomlight
setblock 67 115 328 minecraft:shroomlight
setblock 68 115 323 minecraft:stripped_dark_oak_log
setblock 72 115 363 minecraft:stripped_dark_oak_log
setblock 74 115 322 minecraft:red_concrete
setblock 75 115 323 minecraft:stripped_dark_oak_log
setblock 79 115 363 minecraft:stripped_dark_oak_log
setblock 82 115 323 minecraft:stripped_dark_oak_log
fill 86 115 348 86 116 354 minecraft:iron_bars
setblock 86 115 363 minecraft:stripped_dark_oak_log
setblock 88 115 324 minecraft:stripped_dark_oak_log
setblock 88 115 331 minecraft:stripped_dark_oak_log
setblock 88 115 338 minecraft:stripped_dark_oak_log
setblock 88 115 345 minecraft:stripped_dark_oak_log
setblock 88 115 352 minecraft:stripped_dark_oak_log
setblock 88 115 359 minecraft:stripped_dark_oak_log
fill 89 115 325 89 129 327 minecraft:dark_oak_planks
setblock 89 115 328 minecraft:red_concrete
fill 89 115 329 89 127 334 minecraft:dark_oak_planks
fill 47 116 342 47 129 342 minecraft:dark_oak_planks
setblock 47 116 363 minecraft:red_concrete
fill 47 116 364 47 130 364 minecraft:dark_oak_planks
setblock 48 116 325 minecraft:stripped_dark_oak_log
fill 48 116 331 48 117 331 minecraft:stripped_dark_oak_log
fill 48 116 333 48 117 333 minecraft:stripped_dark_oak_log
fill 48 116 335 48 117 335 minecraft:stripped_dark_oak_log
fill 48 116 337 48 117 337 minecraft:stripped_dark_oak_log
fill 48 116 339 48 117 339 minecraft:stripped_dark_oak_log
setblock 48 116 346 minecraft:stripped_dark_oak_log
setblock 48 116 353 minecraft:stripped_dark_oak_log
setblock 48 116 360 minecraft:stripped_dark_oak_log
fill 49 116 330 49 117 330 minecraft:stripped_dark_oak_log
fill 49 116 332 49 117 332 minecraft:stripped_dark_oak_log
fill 49 116 334 49 117 334 minecraft:stripped_dark_oak_log
fill 49 116 336 49 117 336 minecraft:stripped_dark_oak_log
fill 49 116 338 49 117 338 minecraft:stripped_dark_oak_log
fill 49 116 340 49 117 340 minecraft:stripped_dark_oak_log
fill 50 116 331 50 117 331 minecraft:stripped_dark_oak_log
fill 50 116 333 50 117 333 minecraft:stripped_dark_oak_log
fill 50 116 335 50 117 335 minecraft:stripped_dark_oak_log
fill 50 116 337 50 117 337 minecraft:stripped_dark_oak_log
fill 50 116 339 50 117 339 minecraft:stripped_dark_oak_log
fill 51 116 330 51 117 330 minecraft:stripped_dark_oak_log
fill 51 116 332 51 117 332 minecraft:stripped_dark_oak_log
fill 51 116 334 51 117 334 minecraft:stripped_dark_oak_log
fill 51 116 336 51 117 336 minecraft:stripped_dark_oak_log
fill 51 116 338 51 117 338 minecraft:stripped_dark_oak_log
fill 51 116 340 51 117 340 minecraft:stripped_dark_oak_log
fill 52 116 331 52 117 331 minecraft:stripped_dark_oak_log
fill 52 116 333 52 117 333 minecraft:stripped_dark_oak_log
fill 52 116 335 52 117 335 minecraft:stripped_dark_oak_log
fill 52 116 337 52 117 337 minecraft:stripped_dark_oak_log
fill 52 116 339 52 117 339 minecraft:stripped_dark_oak_log
setblock 52 116 363 minecraft:stripped_dark_oak_log
setblock 53 116 323 minecraft:stripped_dark_oak_log
fill 53 116 330 53 117 330 minecraft:stripped_dark_oak_log
fill 53 116 332 53 117 332 minecraft:stripped_dark_oak_log
fill 53 116 334 53 117 334 minecraft:stripped_dark_oak_log
fill 53 116 336 53 117 336 minecraft:stripped_dark_oak_log
fill 53 116 338 53 117 338 minecraft:stripped_dark_oak_log
fill 53 116 340 53 117 340 minecraft:stripped_dark_oak_log
fill 54 116 331 54 117 331 minecraft:stripped_dark_oak_log
fill 54 116 333 54 117 333 minecraft:stripped_dark_oak_log
fill 54 116 335 54 117 335 minecraft:stripped_dark_oak_log
fill 54 116 337 54 117 337 minecraft:stripped_dark_oak_log
fill 54 116 339 54 117 339 minecraft:stripped_dark_oak_log
setblock 55 116 364 minecraft:dark_oak_planks
fill 59 116 324 59 117 324 minecraft:stripped_dark_oak_log
fill 59 116 326 59 117 326 minecraft:stripped_dark_oak_log
fill 59 116 328 59 117 328 minecraft:stripped_dark_oak_log
setblock 59 116 363 minecraft:stripped_dark_oak_log
fill 60 116 323 60 117 323 minecraft:stripped_dark_oak_log
fill 60 116 325 60 117 325 minecraft:stripped_dark_oak_log
fill 60 116 327 60 117 327 minecraft:stripped_dark_oak_log
fill 61 116 324 61 117 324 minecraft:stripped_dark_oak_log
fill 61 116 326 61 117 326 minecraft:stripped_dark_oak_log
fill 61 116 328 61 117 328 minecraft:stripped_dark_oak_log
fill 62 116 323 62 117 323 minecraft:stripped_dark_oak_log
fill 62 116 325 62 117 325 minecraft:stripped_dark_oak_log
fill 62 116 327 62 117 327 minecraft:stripped_dark_oak_log
fill 63 116 324 63 117 324 minecraft:stripped_dark_oak_log
fill 63 116 326 63 117 326 minecraft:stripped_dark_oak_log
fill 63 116 328 63 117 328 minecraft:stripped_dark_oak_log
fill 64 116 323 64 117 323 minecraft:stripped_dark_oak_log
fill 64 116 325 64 117 325 minecraft:stripped_dark_oak_log
fill 64 116 327 64 117 327 minecraft:stripped_dark_oak_log
fill 65 116 324 65 117 324 minecraft:stripped_dark_oak_log
fill 65 116 326 65 117 326 minecraft:stripped_dark_oak_log
fill 65 116 328 65 117 328 minecraft:stripped_dark_oak_log
fill 66 116 323 66 117 323 minecraft:stripped_dark_oak_log
fill 66 116 325 66 117 325 minecraft:stripped_dark_oak_log
fill 66 116 327 66 117 327 minecraft:stripped_dark_oak_log
setblock 66 116 363 minecraft:stripped_dark_oak_log
fill 67 116 324 67 117 324 minecraft:stripped_dark_oak_log
fill 67 116 326 67 117 326 minecraft:stripped_dark_oak_log
fill 67 116 328 67 117 328 minecraft:stripped_dark_oak_log
setblock 73 116 363 minecraft:stripped_dark_oak_log
fill 74 116 322 74 125 322 minecraft:dark_oak_planks
setblock 74 116 323 minecraft:stripped_dark_oak_log
setblock 80 116 363 minecraft:stripped_dark_oak_log
setblock 81 116 323 minecraft:stripped_dark_oak_log
setblock 87 116 363 minecraft:stripped_dark_oak_log
setblock 88 116 323 minecraft:stripped_dark_oak_log
setblock 88 116 330 minecraft:stripped_dark_oak_log
setblock 88 116 337 minecraft:stripped_dark_oak_log
setblock 88 116 344 minecraft:stripped_dark_oak_log
setblock 88 116 351 minecraft:stripped_dark_oak_log
setblock 88 116 358 minecraft:stripped_dark_oak_log
fill 89 116 328 89 130 328 minecraft:dark_oak_planks
fill 47 117 363 47 129 363 minecraft:dark_oak_planks
setblock 48 117 326 minecraft:stripped_dark_oak_log
setblock 48 117 347 minecraft:stripped_dark_oak_log
setblock 48 117 354 minecraft:stripped_dark_oak_log
setblock 48 117 361 minecraft:stripped_dark_oak_log
setblock 52 117 323 minecraft:stripped_dark_oak_log
setblock 53 117 363 minecraft:stripped_dark_oak_log
setblock 55 117 364 minecraft:red_concrete
setblock 60 117 363 minecraft:stripped_dark_oak_log
setblock 67 117 363 minecraft:stripped_dark_oak_log
setblock 73 117 323 minecraft:stripped_dark_oak_log
setblock 74 117 363 minecraft:stripped_dark_oak_log
setblock 80 117 323 minecraft:stripped_dark_oak_log
setblock 81 117 363 minecraft:stripped_dark_oak_log
setblock 87 117 323 minecraft:stripped_dark_oak_log
setblock 88 117 329 minecraft:stripped_dark_oak_log
setblock 88 117 336 minecraft:stripped_dark_oak_log
setblock 88 117 343 minecraft:stripped_dark_oak_log
setblock 88 117 350 minecraft:stripped_dark_oak_log
setblock 88 117 357 minecraft:stripped_dark_oak_log
setblock 88 117 363 minecraft:stripped_dark_oak_log
fill 48 118 324 50 119 324 minecraft:iron_bars
setblock 48 118 327 minecraft:stripped_dark_oak_log
setblock 48 118 331 minecraft:shroomlight
setblock 48 118 333 minecraft:shroomlight
setblock 48 118 335 minecraft:shroomlight
setblock 48 118 337 minecraft:shroomlight
setblock 48 118 339 minecraft:shroomlight
setblock 48 118 341 minecraft:stripped_dark_oak_log
setblock 48 118 348 minecraft:stripped_dark_oak_log
setblock 48 118 355 minecraft:stripped_dark_oak_log
setblock 48 118 362 minecraft:stripped_dark_oak_log
setblock 49 118 330 minecraft:shroomlight
setblock 49 118 332 minecraft:shroomlight
setblock 49 118 334 minecraft:shroomlight
setblock 49 118 336 minecraft:shroomlight
setblock 49 118 338 minecraft:shroomlight
setblock 49 118 340 minecraft:shroomlight
setblock 50 118 331 minecraft:shroomlight
setblock 50 118 333 minecraft:shroomlight
setblock 50 118 335 minecraft:shroomlight
setblock 50 118 337 minecraft:shroomlight
setblock 50 118 339 minecraft:shroomlight
setblock 51 118 323 minecraft:stripped_dark_oak_log
setblock 51 118 330 minecraft:shroomlight
setblock 51 118 332 minecraft:shroomlight
setblock 51 118 334 minecraft:shroomlight
setblock 51 118 336 minecraft:shroomlight
setblock 51 118 338 minecraft:shroomlight
setblock 51 118 340 minecraft:shroomlight
setblock 52 118 331 minecraft:shroomlight
setblock 52 118 333 minecraft:shroomlight
setblock 52 118 335 minecraft:shroomlight
setblock 52 118 337 minecraft:shroomlight
setblock 52 118 339 minecraft:shroomlight
setblock 53 118 330 minecraft:shroomlight
setblock 53 118 332 minecraft:shroomlight
setblock 53 118 334 minecraft:shroomlight
setblock 53 118 336 minecraft:shroomlight
setblock 53 118 338 minecraft:shroomlight
setblock 53 118 340 minecraft:shroomlight
setblock 54 118 331 minecraft:shroomlight
setblock 54 118 333 minecraft:shroomlight
setblock 54 118 335 minecraft:shroomlight
setblock 54 118 337 minecraft:shroomlight
setblock 54 118 339 minecraft:shroomlight
setblock 54 118 363 minecraft:stripped_dark_oak_log
fill 55 118 364 55 129 364 minecraft:dark_oak_planks
setblock 58 118 323 minecraft:stripped_dark_oak_log
setblock 59 118 324 minecraft:shroomlight
setblock 59 118 326 minecraft:shroomlight
setblock 59 118 328 minecraft:shroomlight
setblock 60 118 323 minecraft:shroomlight
setblock 60 118 325 minecraft:shroomlight
setblock 60 118 327 minecraft:shroomlight
setblock 61 118 324 minecraft:shroomlight
setblock 61 118 326 minecraft:shroomlight
setblock 61 118 328 minecraft:shroomlight
setblock 61 118 363 minecraft:stripped_dark_oak_log
setblock 62 118 323 minecraft:shroomlight
setblock 62 118 325 minecraft:shroomlight
setblock 62 118 327 minecraft:shroomlight
setblock 63 118 324 minecraft:shroomlight
setblock 63 118 326 minecraft:shroomlight
setblock 63 118 328 minecraft:shroomlight
setblock 64 118 323 minecraft:shroomlight
setblock 64 118 325 minecraft:shroomlight
setblock 64 118 327 minecraft:shroomlight
setblock 65 118 324 minecraft:shroomlight
setblock 65 118 326 minecraft:shroomlight
setblock 65 118 328 minecraft:shroomlight
setblock 66 118 323 minecraft:shroomlight
setblock 66 118 325 minecraft:shroomlight
setblock 66 118 327 minecraft:shroomlight
setblock 67 118 324 minecraft:shroomlight
setblock 67 118 326 minecraft:shroomlight
setblock 67 118 328 minecraft:shroomlight
setblock 68 118 363 minecraft:stripped_dark_oak_log
setblock 72 118 323 minecraft:stripped_dark_oak_log
setblock 75 118 363 minecraft:stripped_dark_oak_log
setblock 79 118 323 minecraft:stripped_dark_oak_log
setblock 82 118 363 minecraft:stripped_dark_oak_log
setblock 86 118 323 minecraft:stripped_dark_oak_log
setblock 88 118 328 minecraft:stripped_dark_oak_log
setblock 88 118 335 minecraft:stripped_dark_oak_log
setblock 88 118 342 minecraft:stripped_dark_oak_log
setblock 88 118 349 minecraft:stripped_dark_oak_log
setblock 88 118 356 minecraft:stripped_dark_oak_log
setblock 47 119 335 minecraft:red_concrete
fill 48 119 331 48 120 331 minecraft:stripped_dark_oak_log
fill 48 119 333 48 120 333 minecraft:stripped_dark_oak_log
fill 48 119 335 48 120 335 minecraft:stripped_dark_oak_log
fill 48 119 337 48 120 337 minecraft:stripped_dark_oak_log
fill 48 119 339 48 120 339 minecraft:stripped_dark_oak_log
fill 49 119 330 49 120 330 minecraft:stripped_dark_oak_log
fill 49 119 332 49 120 332 minecraft:stripped_dark_oak_log
fill 49 119 334 49 120 334 minecraft:stripped_dark_oak_log
fill 49 119 336 49 120 336 minecraft:stripped_dark_oak_log
fill 49 119 338 49 120 338 minecraft:stripped_dark_oak_log
fill 49 119 340 49 120 340 minecraft:stripped_dark_oak_log
fill 50 119 331 50 120 331 minecraft:stripped_dark_oak_log
fill 50 119 333 50 120 333 minecraft:stripped_dark_oak_log
fill 50 119 335 50 120 335 minecraft:stripped_dark_oak_log
fill 50 119 337 50 120 337 minecraft:stripped_dark_oak_log
fill 50 119 339 50 120 339 minecraft:stripped_dark_oak_log
fill 51 119 330 51 120 330 minecraft:stripped_dark_oak_log
fill 51 119 332 51 120 332 minecraft:stripped_dark_oak_log
fill 51 119 334 51 120 334 minecraft:stripped_dark_oak_log
fill 51 119 336 51 120 336 minecraft:stripped_dark_oak_log
fill 51 119 338 51 120 338 minecraft:stripped_dark_oak_log
fill 51 119 340 51 120 340 minecraft:stripped_dark_oak_log
fill 52 119 331 52 120 331 minecraft:stripped_dark_oak_log
fill 52 119 333 52 120 333 minecraft:stripped_dark_oak_log
fill 52 119 335 52 120 335 minecraft:stripped_dark_oak_log
fill 52 119 337 52 120 337 minecraft:stripped_dark_oak_log
fill 52 119 339 52 120 339 minecraft:stripped_dark_oak_log
setblock 52 119 364 minecraft:red_concrete
fill 53 119 330 53 120 330 minecraft:stripped_dark_oak_log
fill 53 119 332 53 120 332 minecraft:stripped_dark_oak_log
fill 53 119 334 53 120 334 minecraft:stripped_dark_oak_log
fill 53 119 336 53 120 336 minecraft:stripped_dark_oak_log
fill 53 119 338 53 120 338 minecraft:stripped_dark_oak_log
fill 53 119 340 53 120 340 minecraft:stripped_dark_oak_log
fill 53 119 364 53 130 364 minecraft:dark_oak_planks
fill 54 119 331 54 120 331 minecraft:stripped_dark_oak_log
fill 54 119 333 54 120 333 minecraft:stripped_dark_oak_log
fill 54 119 335 54 120 335 minecraft:stripped_dark_oak_log
fill 54 119 337 54 120 337 minecraft:stripped_dark_oak_log
fill 54 119 339 54 120 339 minecraft:stripped_dark_oak_log
fill 59 119 324 59 120 324 minecraft:stripped_dark_oak_log
fill 59 119 326 59 120 326 minecraft:stripped_dark_oak_log
fill 59 119 328 59 120 328 minecraft:stripped_dark_oak_log
fill 60 119 323 60 120 323 minecraft:stripped_dark_oak_log
fill 60 119 325 60 120 325 minecraft:stripped_dark_oak_log
fill 60 119 327 60 120 327 minecraft:stripped_dark_oak_log
fill 61 119 324 61 120 324 minecraft:stripped_dark_oak_log
fill 61 119 326 61 120 326 minecraft:stripped_dark_oak_log
fill 61 119 328 61 120 328 minecraft:stripped_dark_oak_log
fill 62 119 323 62 120 323 minecraft:stripped_dark_oak_log
fill 62 119 325 62 120 325 minecraft:stripped_dark_oak_log
fill 62 119 327 62 120 327 minecraft:stripped_dark_oak_log
fill 63 119 324 63 120 324 minecraft:stripped_dark_oak_log
fill 63 119 326 63 120 326 minecraft:stripped_dark_oak_log
fill 63 119 328 63 120 328 minecraft:stripped_dark_oak_log
fill 64 119 323 64 120 323 minecraft:stripped_dark_oak_log
fill 64 119 325 64 120 325 minecraft:stripped_dark_oak_log
fill 64 119 327 64 120 327 minecraft:stripped_dark_oak_log
fill 65 119 324 65 120 324 minecraft:stripped_dark_oak_log
fill 65 119 326 65 120 326 minecraft:stripped_dark_oak_log
fill 65 119 328 65 120 328 minecraft:stripped_dark_oak_log
fill 66 119 323 66 120 323 minecraft:stripped_dark_oak_log
fill 66 119 325 66 120 325 minecraft:stripped_dark_oak_log
fill 66 119 327 66 120 327 minecraft:stripped_dark_oak_log
fill 67 119 324 67 120 324 minecraft:stripped_dark_oak_log
fill 67 119 326 67 120 326 minecraft:stripped_dark_oak_log
fill 67 119 328 67 120 328 minecraft:stripped_dark_oak_log
fill 47 120 335 47 130 335 minecraft:dark_oak_planks
fill 48 120 323 48 120 327 minecraft:stripped_dark_oak_log
setblock 48 120 329 minecraft:stripped_dark_oak_log
setblock 48 120 341 minecraft:stripped_dark_oak_log
fill 48 120 343 48 120 348 minecraft:stripped_dark_oak_log
fill 48 120 350 48 120 355 minecraft:stripped_dark_oak_log
fill 48 120 357 48 120 362 minecraft:stripped_dark_oak_log
setblock 49 120 323 minecraft:stripped_dark_oak_log
fill 49 120 363 54 120 363 minecraft:stripped_dark_oak_log
setblock 50 120 325 minecraft:light[level=12]
setblock 50 120 346 minecraft:light[level=12]
setblock 50 120 353 minecraft:light[level=12]
setblock 50 120 360 minecraft:light[level=12]
fill 51 120 323 56 120 323 minecraft:stripped_dark_oak_log
fill 52 120 364 52 129 364 minecraft:dark_oak_planks
fill 56 120 363 61 120 363 minecraft:stripped_dark_oak_log
setblock 57 120 325 minecraft:light[level=12]
setblock 57 120 332 minecraft:light[level=12]
setblock 57 120 339 minecraft:light[level=12]
setblock 57 120 346 minecraft:light[level=12]
setblock 57 120 353 minecraft:light[level=12]
setblock 57 120 360 minecraft:light[level=12]
setblock 58 120 323 minecraft:stripped_dark_oak_log
fill 63 120 363 68 120 363 minecraft:stripped_dark_oak_log
setblock 64 120 332 minecraft:light[level=12]
setblock 64 120 339 minecraft:light[level=12]
setblock 64 120 346 minecraft:light[level=12]
setblock 64 120 353 minecraft:light[level=12]
setblock 64 120 360 minecraft:light[level=12]
fill 68 120 323 70 120 323 minecraft:stripped_dark_oak_log
fill 70 120 363 75 120 363 minecraft:stripped_dark_oak_log
setblock 71 120 325 minecraft:light[level=12]
setblock 71 120 332 minecraft:light[level=12]
setblock 71 120 339 minecraft:light[level=12]
setblock 71 120 346 minecraft:light[level=12]
setblock 71 120 353 minecraft:light[level=12]
setblock 71 120 360 minecraft:light[level=12]
fill 72 120 323 77 120 323 minecraft:stripped_dark_oak_log
fill 77 120 363 82 120 363 minecraft:stripped_dark_oak_log
setblock 78 120 325 minecraft:light[level=12]
setblock 78 120 332 minecraft:light[level=12]
setblock 78 120 339 minecraft:light[level=12]
setblock 78 120 346 minecraft:light[level=12]
setblock 78 120 353 minecraft:light[level=12]
setblock 78 120 360 minecraft:light[level=12]
fill 79 120 323 84 120 323 minecraft:stripped_dark_oak_log
fill 84 120 363 88 120 363 minecraft:stripped_dark_oak_log
setblock 85 120 325 minecraft:light[level=12]
setblock 85 120 332 minecraft:light[level=12]
setblock 85 120 339 minecraft:light[level=12]
setblock 85 120 346 minecraft:light[level=12]
setblock 85 120 353 minecraft:light[level=12]
setblock 85 120 360 minecraft:light[level=12]
fill 86 120 323 88 120 323 minecraft:stripped_dark_oak_log
setblock 87 120 358 minecraft:red_concrete
fill 88 120 324 88 120 326 minecraft:stripped_dark_oak_log
fill 88 120 328 88 120 333 minecraft:stripped_dark_oak_log
fill 88 120 335 88 120 340 minecraft:stripped_dark_oak_log
fill 88 120 342 88 120 347 minecraft:stripped_dark_oak_log
fill 88 120 349 88 120 354 minecraft:stripped_dark_oak_log
fill 88 120 356 88 120 361 minecraft:stripped_dark_oak_log
setblock 48 121 323 minecraft:stripped_dark_oak_log
setblock 48 121 331 minecraft:shroomlight
setblock 48 121 333 minecraft:shroomlight
setblock 48 121 335 minecraft:shroomlight
setblock 48 121 337 minecraft:shroomlight
setblock 48 121 339 minecraft:shroomlight
setblock 48 121 344 minecraft:stripped_dark_oak_log
setblock 48 121 351 minecraft:stripped_dark_oak_log
setblock 48 121 358 minecraft:stripped_dark_oak_log
setblock 49 121 330 minecraft:shroomlight
setblock 49 121 332 minecraft:shroomlight
setblock 49 121 334 minecraft:shroomlight
setblock 49 121 336 minecraft:shroomlight
setblock 49 121 338 minecraft:shroomlight
setblock 49 121 340 minecraft:shroomlight
setblock 50 121 331 minecraft:shroomlight
setblock 50 121 333 minecraft:shroomlight
setblock 50 121 335 minecraft:shroomlight
setblock 50 121 337 minecraft:shroomlight
setblock 50 121 339 minecraft:shroomlight
setblock 50 121 363 minecraft:stripped_dark_oak_log
setblock 51 121 330 minecraft:shroomlight
setblock 51 121 332 minecraft:shroomlight
setblock 51 121 334 minecraft:shroomlight
setblock 51 121 336 minecraft:shroomlight
setblock 51 121 338 minecraft:shroomlight
setblock 51 121 340 minecraft:shroomlight
setblock 52 121 331 minecraft:shroomlight
setblock 52 121 333 minecraft:shroomlight
setblock 52 121 335 minecraft:shroomlight
setblock 52 121 337 minecraft:shroomlight
setblock 52 121 339 minecraft:shroomlight
setblock 53 121 330 minecraft:shroomlight
setblock 53 121 332 minecraft:shroomlight
setblock 53 121 334 minecraft:shroomlight
setblock 53 121 336 minecraft:shroomlight
setblock 53 121 338 minecraft:shroomlight
setblock 53 121 340 minecraft:shroomlight
setblock 54 121 331 minecraft:shroomlight
setblock 54 121 333 minecraft:shroomlight
setblock 54 121 335 minecraft:shroomlight
setblock 54 121 337 minecraft:shroomlight
setblock 54 121 339 minecraft:shroomlight
setblock 55 121 323 minecraft:stripped_dark_oak_log
setblock 57 121 363 minecraft:stripped_dark_oak_log
setblock 59 121 324 minecraft:shroomlight
setblock 59 121 326 minecraft:shroomlight
setblock 59 121 328 minecraft:shroomlight
setblock 60 121 322 minecraft:red_concrete
setblock 60 121 323 minecraft:shroomlight
setblock 60 121 325 minecraft:shroomlight
setblock 60 121 327 minecraft:shroomlight
setblock 61 121 324 minecraft:shroomlight
setblock 61 121 326 minecraft:shroomlight
setblock 61 121 328 minecraft:shroomlight
setblock 62 121 323 minecraft:shroomlight
setblock 62 121 325 minecraft:shroomlight
setblock 62 121 327 minecraft:shroomlight
setblock 63 121 324 minecraft:shroomlight
setblock 63 121 326 minecraft:shroomlight
setblock 63 121 328 minecraft:shroomlight
setblock 64 121 323 minecraft:shroomlight
setblock 64 121 325 minecraft:shroomlight
setblock 64 121 327 minecraft:shroomlight
setblock 64 121 363 minecraft:stripped_dark_oak_log
setblock 65 121 324 minecraft:shroomlight
setblock 65 121 326 minecraft:shroomlight
setblock 65 121 328 minecraft:shroomlight
setblock 66 121 323 minecraft:shroomlight
setblock 66 121 325 minecraft:shroomlight
setblock 66 121 327 minecraft:shroomlight
setblock 67 121 324 minecraft:shroomlight
setblock 67 121 326 minecraft:shroomlight
setblock 67 121 328 minecraft:shroomlight
setblock 69 121 323 minecraft:stripped_dark_oak_log
setblock 71 121 363 minecraft:stripped_dark_oak_log
setblock 76 121 323 minecraft:stripped_dark_oak_log
setblock 78 121 363 minecraft:stripped_dark_oak_log
setblock 83 121 323 minecraft:stripped_dark_oak_log
setblock 85 121 363 minecraft:stripped_dark_oak_log
fill 87 121 358 87 122 358 minecraft:shroomlight
setblock 88 121 325 minecraft:stripped_dark_oak_log
setblock 88 121 332 minecraft:stripped_dark_oak_log
setblock 88 121 339 minecraft:stripped_dark_oak_log
setblock 88 121 346 minecraft:stripped_dark_oak_log
setblock 88 121 353 minecraft:stripped_dark_oak_log
setblock 88 121 360 minecraft:stripped_dark_oak_log
setblock 48 122 324 minecraft:stripped_dark_oak_log
setblock 48 122 331 minecraft:stripped_dark_oak_log
setblock 48 122 333 minecraft:stripped_dark_oak_log
setblock 48 122 335 minecraft:stripped_dark_oak_log
setblock 48 122 337 minecraft:stripped_dark_oak_log
setblock 48 122 339 minecraft:stripped_dark_oak_log
setblock 48 122 345 minecraft:stripped_dark_oak_log
setblock 48 122 352 minecraft:stripped_dark_oak_log
setblock 48 122 359 minecraft:stripped_dark_oak_log
setblock 49 122 330 minecraft:stripped_dark_oak_log
setblock 49 122 332 minecraft:stripped_dark_oak_log
setblock 49 122 334 minecraft:stripped_dark_oak_log
setblock 49 122 336 minecraft:stripped_dark_oak_log
setblock 49 122 338 minecraft:stripped_dark_oak_log
setblock 49 122 340 minecraft:stripped_dark_oak_log
setblock 50 122 325 minecraft:light[level=15]
setblock 50 122 331 minecraft:stripped_dark_oak_log
setblock 50 122 333 minecraft:stripped_dark_oak_log
setblock 50 122 335 minecraft:stripped_dark_oak_log
setblock 50 122 337 minecraft:stripped_dark_oak_log
setblock 50 122 339 minecraft:stripped_dark_oak_log
setblock 50 122 341 minecraft:light[level=15]
setblock 50 122 349 minecraft:light[level=15]
setblock 50 122 357 minecraft:light[level=15]
setblock 51 122 330 minecraft:stripped_dark_oak_log
setblock 51 122 332 minecraft:stripped_dark_oak_log
setblock 51 122 334 minecraft:stripped_dark_oak_log
setblock 51 122 336 minecraft:stripped_dark_oak_log
setblock 51 122 338 minecraft:stripped_dark_oak_log
setblock 51 122 340 minecraft:stripped_dark_oak_log
setblock 51 122 363 minecraft:stripped_dark_oak_log
setblock 52 122 331 minecraft:stripped_dark_oak_log
setblock 52 122 333 minecraft:stripped_dark_oak_log
setblock 52 122 335 minecraft:stripped_dark_oak_log
setblock 52 122 337 minecraft:stripped_dark_oak_log
setblock 52 122 339 minecraft:stripped_dark_oak_log
setblock 53 122 330 minecraft:stripped_dark_oak_log
setblock 53 122 332 minecraft:stripped_dark_oak_log
setblock 53 122 334 minecraft:stripped_dark_oak_log
setblock 53 122 336 minecraft:stripped_dark_oak_log
setblock 53 122 338 minecraft:stripped_dark_oak_log
setblock 53 122 340 minecraft:stripped_dark_oak_log
setblock 54 122 323 minecraft:stripped_dark_oak_log
setblock 54 122 331 minecraft:stripped_dark_oak_log
setblock 54 122 333 minecraft:stripped_dark_oak_log
setblock 54 122 335 minecraft:stripped_dark_oak_log
setblock 54 122 337 minecraft:stripped_dark_oak_log
setblock 54 122 339 minecraft:stripped_dark_oak_log
setblock 58 122 325 minecraft:light[level=15]
setblock 58 122 333 minecraft:light[level=15]
setblock 58 122 341 minecraft:light[level=15]
setblock 58 122 349 minecraft:light[level=15]
setblock 58 122 357 minecraft:light[level=15]
setblock 58 122 363 minecraft:stripped_dark_oak_log
setblock 59 122 324 minecraft:stripped_dark_oak_log
setblock 59 122 326 minecraft:stripped_dark_oak_log
setblock 59 122 328 minecraft:stripped_dark_oak_log
fill 60 122 322 60 129 322 minecraft:dark_oak_planks
setblock 60 122 323 minecraft:stripped_dark_oak_log
setblock 60 122 325 minecraft:stripped_dark_oak_log
setblock 60 122 327 minecraft:stripped_dark_oak_log
setblock 61 122 324 minecraft:stripped_dark_oak_log
setblock 61 122 326 minecraft:stripped_dark_oak_log
setblock 61 122 328 minecraft:stripped_dark_oak_log
setblock 62 122 323 minecraft:stripped_dark_oak_log
setblock 62 122 325 minecraft:stripped_dark_oak_log
setblock 62 122 327 minecraft:stripped_dark_oak_log
setblock 63 122 324 minecraft:stripped_dark_oak_log
setblock 63 122 326 minecraft:stripped_dark_oak_log
setblock 63 122 328 minecraft:stripped_dark_oak_log
setblock 64 122 323 minecraft:stripped_dark_oak_log
setblock 64 122 325 minecraft:stripped_dark_oak_log
setblock 64 122 327 minecraft:stripped_dark_oak_log
setblock 65 122 324 minecraft:stripped_dark_oak_log
setblock 65 122 326 minecraft:stripped_dark_oak_log
setblock 65 122 328 minecraft:stripped_dark_oak_log
setblock 65 122 363 minecraft:stripped_dark_oak_log
setblock 66 122 323 minecraft:stripped_dark_oak_log
setblock 66 122 325 minecraft:stripped_dark_oak_log
setblock 66 122 327 minecraft:stripped_dark_oak_log
setblock 66 122 333 minecraft:light[level=15]
setblock 66 122 341 minecraft:light[level=15]
setblock 66 122 349 minecraft:light[level=15]
setblock 66 122 357 minecraft:light[level=15]
setblock 67 122 324 minecraft:stripped_dark_oak_log
setblock 67 122 326 minecraft:stripped_dark_oak_log
setblock 67 122 328 minecraft:stripped_dark_oak_log
setblock 68 122 323 minecraft:stripped_dark_oak_log
setblock 72 122 363 minecraft:stripped_dark_oak_log
setblock 74 122 325 minecraft:light[level=15]
setblock 74 122 333 minecraft:light[level=15]
setblock 74 122 349 minecraft:light[level=15]
setblock 74 122 357 minecraft:light[level=15]
setblock 75 122 323 minecraft:stripped_dark_oak_log
setblock 75 122 364 minecraft:red_concrete
fill 76 122 364 77 129 364 minecraft:dark_oak_planks
setblock 79 122 363 minecraft:stripped_dark_oak_log
setblock 82 122 323 minecraft:stripped_dark_oak_log
setblock 82 122 325 minecraft:light[level=15]
setblock 82 122 333 minecraft:light[level=15]
setblock 82 122 341 minecraft:light[level=15]
setblock 82 122 349 minecraft:light[level=15]
setblock 82 122 357 minecraft:light[level=15]
setblock 86 122 363 minecraft:stripped_dark_oak_log
setblock 88 122 324 minecraft:stripped_dark_oak_log
setblock 88 122 331 minecraft:stripped_dark_oak_log
setblock 88 122 338 minecraft:stripped_dark_oak_log
setblock 88 122 345 minecraft:stripped_dark_oak_log
setblock 88 122 352 minecraft:stripped_dark_oak_log
setblock 88 122 359 minecraft:stripped_dark_oak_log
fill 75 123 364 75 126 364 minecraft:dark_oak_planks
setblock 78 123 364 minecraft:red_concrete
setblock 87 123 358 minecraft:red_concrete
fill 78 124 364 78 125 364 minecraft:dark_oak_planks
fill 47 126 322 47 128 322 minecraft:spruce_planks
setblock 47 126 329 minecraft:spruce_planks
fill 47 126 330 47 129 331 minecraft:dark_oak_planks
fill 47 126 343 47 129 344 minecraft:dark_oak_planks
setblock 47 126 345 minecraft:spruce_planks
setblock 47 126 350 minecraft:spruce_planks
fill 47 126 351 47 129 351 minecraft:dark_oak_planks
setblock 47 126 352 minecraft:spruce_planks
fill 47 126 353 47 129 353 minecraft:dark_oak_planks
setblock 49 126 322 minecraft:spruce_planks
setblock 50 126 325 minecraft:light[level=12]
setblock 50 126 332 minecraft:light[level=12]
setblock 50 126 339 minecraft:light[level=12]
setblock 50 126 346 minecraft:light[level=12]
setblock 50 126 353 minecraft:light[level=12]
setblock 50 126 360 minecraft:light[level=12]
setblock 54 126 322 minecraft:spruce_planks
fill 55 126 322 57 129 322 minecraft:dark_oak_planks
fill 56 126 364 57 129 364 minecraft:dark_oak_planks
setblock 57 126 325 minecraft:light[level=12]
setblock 57 126 332 minecraft:light[level=12]
setblock 57 126 339 minecraft:light[level=12]
setblock 57 126 346 minecraft:light[level=12]
setblock 57 126 353 minecraft:light[level=12]
setblock 57 126 360 minecraft:light[level=12]
setblock 58 126 364 minecraft:spruce_planks
fill 59 126 364 61 129 364 minecraft:dark_oak_planks
setblock 63 126 322 minecraft:spruce_planks
fill 64 126 322 64 129 322 minecraft:dark_oak_planks
setblock 64 126 325 minecraft:light[level=12]
setblock 64 126 332 minecraft:light[level=12]
setblock 64 126 339 minecraft:light[level=12]
setblock 64 126 346 minecraft:light[level=12]
setblock 64 126 353 minecraft:light[level=12]
setblock 64 126 360 minecraft:light[level=12]
fill 64 126 364 64 129 364 minecraft:dark_oak_planks
setblock 65 126 364 minecraft:spruce_planks
fill 66 126 364 68 127 364 minecraft:dark_oak_planks
setblock 71 126 325 minecraft:light[level=12]
setblock 71 126 332 minecraft:light[level=12]
setblock 71 126 339 minecraft:light[level=12]
setblock 71 126 346 minecraft:light[level=12]
setblock 71 126 353 minecraft:light[level=12]
setblock 71 126 360 minecraft:light[level=12]
setblock 74 126 322 minecraft:spruce_planks
fill 77 126 322 77 129 322 minecraft:dark_oak_planks
setblock 78 126 322 minecraft:spruce_planks
setblock 78 126 325 minecraft:light[level=12]
setblock 78 126 332 minecraft:light[level=12]
setblock 78 126 339 minecraft:light[level=12]
setblock 78 126 346 minecraft:light[level=12]
setblock 78 126 353 minecraft:light[level=12]
setblock 78 126 360 minecraft:light[level=12]
setblock 78 126 364 minecraft:spruce_planks
fill 79 126 322 81 129 322 minecraft:dark_oak_planks
fill 83 126 322 88 126 322 minecraft:dark_oak_planks
setblock 85 126 325 minecraft:light[level=12]
setblock 85 126 332 minecraft:light[level=12]
setblock 85 126 339 minecraft:light[level=12]
setblock 85 126 346 minecraft:light[level=12]
setblock 85 126 353 minecraft:light[level=12]
setblock 85 126 360 minecraft:light[level=12]
setblock 86 126 364 minecraft:red_concrete
fill 87 126 364 87 129 364 minecraft:dark_oak_planks
setblock 88 126 364 minecraft:red_concrete
setblock 89 126 322 minecraft:spruce_planks
fill 89 126 336 89 127 339 minecraft:dark_oak_planks
setblock 89 126 340 minecraft:spruce_planks
fill 89 126 341 89 129 344 minecraft:dark_oak_planks
setblock 89 126 346 minecraft:spruce_planks
fill 89 126 347 89 127 348 minecraft:dark_oak_planks
setblock 89 126 349 minecraft:spruce_planks
setblock 89 126 350 minecraft:red_concrete
setblock 89 126 364 minecraft:dark_oak_planks
fill 47 127 329 47 129 329 minecraft:dark_oak_planks
setblock 47 127 332 minecraft:spruce_planks
setblock 47 127 338 minecraft:spruce_planks
fill 47 127 345 47 129 345 minecraft:dark_oak_planks
fill 47 127 350 47 129 350 minecraft:dark_oak_planks
fill 47 127 352 47 129 352 minecraft:dark_oak_planks
fill 47 127 359 47 129 360 minecraft:dark_oak_planks
setblock 47 127 361 minecraft:spruce_planks
fill 49 127 322 49 129 322 minecraft:dark_oak_planks
fill 54 127 322 54 129 322 minecraft:dark_oak_planks
fill 58 127 364 58 129 364 minecraft:dark_oak_planks
fill 63 127 322 63 129 322 minecraft:dark_oak_planks
fill 65 127 322 65 128 322 minecraft:spruce_planks
fill 65 127 364 65 130 364 minecraft:dark_oak_planks
fill 67 127 322 68 129 322 minecraft:dark_oak_planks
setblock 69 127 322 minecraft:spruce_planks
fill 74 127 322 74 129 322 minecraft:dark_oak_planks
setblock 75 127 364 minecraft:red_concrete
fill 78 127 322 78 129 322 minecraft:dark_oak_planks
fill 78 127 364 78 129 364 minecraft:dark_oak_planks
setblock 83 127 322 minecraft:spruce_planks
fill 84 127 322 89 127 322 minecraft:dark_oak_planks
fill 86 127 364 86 129 364 minecraft:dark_oak_planks
fill 88 127 364 88 129 364 minecraft:dark_oak_planks
fill 89 127 340 89 130 340 minecraft:dark_oak_planks
fill 89 127 346 89 129 346 minecraft:dark_oak_planks
fill 89 127 349 89 127 350 minecraft:dark_oak_planks
fill 89 127 356 89 127 358 minecraft:dark_oak_planks
setblock 89 127 359 minecraft:spruce_planks
fill 89 127 360 89 127 363 minecraft:dark_oak_planks
setblock 89 127 364 minecraft:spruce_planks
fill 47 128 332 47 129 332 minecraft:dark_oak_planks
fill 47 128 338 47 129 338 minecraft:dark_oak_planks
fill 47 128 355 47 129 356 minecraft:dark_oak_planks
setblock 47 128 357 minecraft:spruce_planks
fill 47 128 361 47 129 361 minecraft:dark_oak_planks
setblock 48 128 364 minecraft:spruce_planks
fill 64 128 341 72 128 341 minecraft:smooth_sandstone
fill 65 128 337 72 128 340 minecraft:smooth_sandstone
fill 65 128 342 72 128 345 minecraft:smooth_sandstone
setblock 66 128 322 minecraft:spruce_planks
fill 66 128 335 84 128 336 minecraft:smooth_sandstone
fill 66 128 346 84 128 347 minecraft:smooth_sandstone
setblock 66 128 364 minecraft:spruce_planks
fill 67 128 334 83 128 334 minecraft:smooth_sandstone
fill 67 128 348 83 128 348 minecraft:smooth_sandstone
fill 67 128 364 68 129 364 minecraft:dark_oak_planks
fill 68 128 333 82 128 333 minecraft:smooth_sandstone
fill 68 128 349 82 128 349 minecraft:smooth_sandstone
fill 69 128 322 69 129 322 minecraft:dark_oak_planks
fill 69 128 332 81 128 332 minecraft:smooth_sandstone
fill 69 128 350 81 128 350 minecraft:smooth_sandstone
setblock 69 128 364 minecraft:spruce_planks
fill 71 128 331 79 128 331 minecraft:smooth_sandstone
fill 71 128 351 79 128 351 minecraft:smooth_sandstone
fill 73 128 337 73 128 339 minecraft:smooth_sandstone
fill 73 128 343 73 128 345 minecraft:smooth_sandstone
setblock 73 128 364 minecraft:spruce_planks
fill 74 128 337 85 128 338 minecraft:smooth_sandstone
fill 74 128 344 85 128 345 minecraft:smooth_sandstone
fill 75 128 330 75 129 330 minecraft:smooth_sandstone
fill 75 128 352 75 129 352 minecraft:smooth_sandstone
fill 75 128 364 75 129 364 minecraft:dark_oak_planks
fill 77 128 339 85 128 339 minecraft:smooth_sandstone
fill 77 128 343 85 128 343 minecraft:smooth_sandstone
fill 78 128 340 85 128 342 minecraft:smooth_sandstone
fill 79 128 364 79 129 364 minecraft:dark_oak_planks
setblock 80 128 364 minecraft:spruce_planks
fill 81 128 364 83 129 364 minecraft:dark_oak_planks
fill 83 128 322 88 129 322 minecraft:dark_oak_planks
fill 86 128 341 86 129 341 minecraft:smooth_sandstone
setblock 89 128 322 minecraft:spruce_planks
fill 89 128 329 89 129 331 minecraft:dark_oak_planks
setblock 89 128 332 minecraft:spruce_planks
fill 89 128 333 89 129 334 minecraft:dark_oak_planks
fill 89 128 336 89 129 336 minecraft:dark_oak_planks
setblock 89 128 337 minecraft:spruce_planks
fill 89 128 338 89 129 339 minecraft:dark_oak_planks
setblock 89 128 347 minecraft:spruce_planks
fill 89 128 348 89 129 348 minecraft:dark_oak_planks
setblock 89 128 349 minecraft:spruce_planks
fill 89 128 350 89 129 350 minecraft:dark_oak_planks
setblock 89 128 352 minecraft:spruce_planks
fill 89 128 356 89 129 356 minecraft:dark_oak_planks
setblock 89 128 357 minecraft:spruce_planks
fill 89 128 358 89 129 362 minecraft:dark_oak_planks
setblock 89 128 363 minecraft:red_concrete
fill 89 128 364 89 129 364 minecraft:dark_oak_planks
setblock 47 129 322 minecraft:dark_oak_planks
setblock 47 129 357 minecraft:dark_oak_planks
fill 48 129 323 48 129 324 minecraft:moss_block
setblock 48 129 325 minecraft:mossy_cobblestone
fill 48 129 326 48 129 328 minecraft:moss_block
setblock 48 129 329 minecraft:mossy_cobblestone
fill 48 129 330 48 129 332 minecraft:moss_block
setblock 48 129 333 minecraft:mossy_cobblestone
fill 48 129 334 48 129 336 minecraft:moss_block
setblock 48 129 337 minecraft:mossy_cobblestone
fill 48 129 338 48 129 340 minecraft:moss_block
setblock 48 129 341 minecraft:mossy_cobblestone
fill 48 129 342 48 129 344 minecraft:moss_block
setblock 48 129 345 minecraft:mossy_cobblestone
fill 48 129 346 48 129 348 minecraft:moss_block
setblock 48 129 349 minecraft:mossy_cobblestone
fill 48 129 350 48 129 352 minecraft:moss_block
setblock 48 129 353 minecraft:mossy_cobblestone
fill 48 129 354 48 129 356 minecraft:moss_block
setblock 48 129 357 minecraft:mossy_cobblestone
fill 48 129 358 48 129 360 minecraft:moss_block
setblock 48 129 361 minecraft:mossy_cobblestone
fill 48 129 362 49 129 363 minecraft:moss_block
setblock 48 129 364 minecraft:dark_oak_planks
setblock 49 129 323 minecraft:moss_block
setblock 49 129 324 minecraft:mossy_cobblestone
fill 49 129 325 49 129 327 minecraft:moss_block
setblock 49 129 328 minecraft:mossy_cobblestone
fill 49 129 329 49 129 331 minecraft:moss_block
setblock 49 129 332 minecraft:mossy_cobblestone
fill 49 129 333 49 129 335 minecraft:moss_block
setblock 49 129 336 minecraft:mossy_cobblestone
fill 49 129 337 49 129 339 minecraft:moss_block
setblock 49 129 340 minecraft:mossy_cobblestone
fill 49 129 341 49 129 343 minecraft:moss_block
setblock 49 129 344 minecraft:mossy_cobblestone
fill 49 129 345 49 129 347 minecraft:moss_block
setblock 49 129 348 minecraft:mossy_cobblestone
fill 49 129 349 49 129 351 minecraft:moss_block
setblock 49 129 352 minecraft:mossy_cobblestone
fill 49 129 353 49 129 355 minecraft:moss_block
setblock 49 129 356 minecraft:mossy_cobblestone
fill 49 129 357 49 129 359 minecraft:moss_block
setblock 49 129 360 minecraft:mossy_cobblestone
fill 49 129 361 51 129 361 minecraft:moss_block
setblock 50 129 323 minecraft:mossy_cobblestone
fill 50 129 324 50 129 326 minecraft:moss_block
setblock 50 129 327 minecraft:mossy_cobblestone
fill 50 129 328 50 129 330 minecraft:moss_block
setblock 50 129 331 minecraft:mossy_cobblestone
fill 50 129 332 50 129 334 minecraft:moss_block
setblock 50 129 335 minecraft:mossy_cobblestone
fill 50 129 336 50 129 338 minecraft:moss_block
setblock 50 129 339 minecraft:mossy_cobblestone
fill 50 129 340 50 129 342 minecraft:moss_block
setblock 50 129 343 minecraft:mossy_cobblestone
fill 50 129 344 50 129 346 minecraft:moss_block
setblock 50 129 347 minecraft:mossy_cobblestone
fill 50 129 348 50 129 350 minecraft:moss_block
setblock 50 129 351 minecraft:mossy_cobblestone
fill 50 129 352 50 129 354 minecraft:moss_block
setblock 50 129 355 minecraft:mossy_cobblestone
fill 50 129 356 50 129 358 minecraft:moss_block
setblock 50 129 359 minecraft:mossy_cobblestone
fill 50 129 360 52 129 360 minecraft:moss_block
setblock 50 129 362 minecraft:moss_block
setblock 50 129 363 minecraft:mossy_cobblestone
fill 51 129 323 51 129 325 minecraft:moss_block
setblock 51 129 326 minecraft:mossy_cobblestone
fill 51 129 327 51 129 329 minecraft:moss_block
setblock 51 129 330 minecraft:mossy_cobblestone
fill 51 129 331 51 129 333 minecraft:moss_block
setblock 51 129 334 minecraft:mossy_cobblestone
fill 51 129 335 51 129 337 minecraft:moss_block
setblock 51 129 338 minecraft:mossy_cobblestone
fill 51 129 339 51 129 341 minecraft:moss_block
setblock 51 129 342 minecraft:mossy_cobblestone
fill 51 129 343 51 129 345 minecraft:moss_block
setblock 51 129 346 minecraft:mossy_cobblestone
fill 51 129 347 51 129 349 minecraft:moss_block
setblock 51 129 350 minecraft:mossy_cobblestone
fill 51 129 351 51 129 353 minecraft:moss_block
setblock 51 129 354 minecraft:mossy_cobblestone
fill 51 129 355 51 129 357 minecraft:moss_block
setblock 51 129 358 minecraft:mossy_cobblestone
fill 51 129 359 53 129 359 minecraft:moss_block
setblock 51 129 362 minecraft:mossy_cobblestone
fill 51 129 363 53 129 363 minecraft:moss_block
fill 52 129 323 52 129 324 minecraft:moss_block
setblock 52 129 325 minecraft:mossy_cobblestone
fill 52 129 326 52 129 328 minecraft:moss_block
setblock 52 129 329 minecraft:mossy_cobblestone
fill 52 129 330 52 129 332 minecraft:moss_block
setblock 52 129 333 minecraft:mossy_cobblestone
fill 52 129 334 52 129 336 minecraft:moss_block
setblock 52 129 337 minecraft:mossy_cobblestone
fill 52 129 338 52 129 340 minecraft:moss_block
setblock 52 129 341 minecraft:mossy_cobblestone
fill 52 129 342 52 129 344 minecraft:moss_block
setblock 52 129 345 minecraft:mossy_cobblestone
fill 52 129 346 52 129 348 minecraft:moss_block
setblock 52 129 349 minecraft:mossy_cobblestone
fill 52 129 350 52 129 352 minecraft:moss_block
setblock 52 129 353 minecraft:mossy_cobblestone
fill 52 129 354 52 129 356 minecraft:moss_block
setblock 52 129 357 minecraft:mossy_cobblestone
fill 52 129 358 54 129 358 minecraft:moss_block
setblock 52 129 361 minecraft:mossy_cobblestone
fill 52 129 362 54 129 362 minecraft:moss_block
setblock 53 129 323 minecraft:moss_block
setblock 53 129 324 minecraft:mossy_cobblestone
fill 53 129 325 53 129 327 minecraft:moss_block
setblock 53 129 328 minecraft:mossy_cobblestone
fill 53 129 329 53 129 331 minecraft:moss_block
setblock 53 129 332 minecraft:mossy_cobblestone
fill 53 129 333 53 129 335 minecraft:moss_block
setblock 53 129 336 minecraft:mossy_cobblestone
fill 53 129 337 53 129 339 minecraft:moss_block
setblock 53 129 340 minecraft:mossy_cobblestone
fill 53 129 341 53 129 343 minecraft:moss_block
setblock 53 129 344 minecraft:mossy_cobblestone
fill 53 129 345 53 129 347 minecraft:moss_block
setblock 53 129 348 minecraft:mossy_cobblestone
fill 53 129 349 53 129 351 minecraft:moss_block
setblock 53 129 352 minecraft:mossy_cobblestone
fill 53 129 353 53 129 355 minecraft:moss_block
setblock 53 129 356 minecraft:mossy_cobblestone
fill 53 129 357 55 129 357 minecraft:moss_block
setblock 53 129 360 minecraft:mossy_cobblestone
fill 53 129 361 55 129 361 minecraft:moss_block
setblock 54 129 323 minecraft:mossy_cobblestone
fill 54 129 324 54 129 326 minecraft:moss_block
setblock 54 129 327 minecraft:mossy_cobblestone
fill 54 129 328 54 129 330 minecraft:moss_block
setblock 54 129 331 minecraft:mossy_cobblestone
fill 54 129 332 54 129 334 minecraft:moss_block
setblock 54 129 335 minecraft:mossy_cobblestone
fill 54 129 336 54 129 338 minecraft:moss_block
setblock 54 129 339 minecraft:mossy_cobblestone
fill 54 129 340 54 129 342 minecraft:moss_block
setblock 54 129 343 minecraft:mossy_cobblestone
fill 54 129 344 54 129 346 minecraft:moss_block
setblock 54 129 347 minecraft:mossy_cobblestone
fill 54 129 348 54 129 350 minecraft:moss_block
setblock 54 129 351 minecraft:mossy_cobblestone
fill 54 129 352 54 129 354 minecraft:moss_block
setblock 54 129 355 minecraft:mossy_cobblestone
fill 54 129 356 56 129 356 minecraft:moss_block
setblock 54 129 359 minecraft:mossy_cobblestone
fill 54 129 360 56 129 360 minecraft:moss_block
setblock 54 129 363 minecraft:mossy_cobblestone
fill 55 129 323 55 129 325 minecraft:moss_block
setblock 55 129 326 minecraft:mossy_cobblestone
fill 55 129 327 55 129 329 minecraft:moss_block
setblock 55 129 330 minecraft:mossy_cobblestone
fill 55 129 331 55 129 333 minecraft:moss_block
setblock 55 129 334 minecraft:mossy_cobblestone
fill 55 129 335 55 129 337 minecraft:moss_block
setblock 55 129 338 minecraft:mossy_cobblestone
fill 55 129 339 55 129 341 minecraft:moss_block
setblock 55 129 342 minecraft:mossy_cobblestone
fill 55 129 343 55 129 345 minecraft:moss_block
setblock 55 129 346 minecraft:mossy_cobblestone
fill 55 129 347 55 129 349 minecraft:moss_block
setblock 55 129 350 minecraft:mossy_cobblestone
fill 55 129 351 55 129 353 minecraft:moss_block
setblock 55 129 354 minecraft:mossy_cobblestone
fill 55 129 355 57 129 355 minecraft:moss_block
setblock 55 129 358 minecraft:mossy_cobblestone
fill 55 129 359 57 129 359 minecraft:moss_block
setblock 55 129 362 minecraft:mossy_cobblestone
fill 55 129 363 57 129 363 minecraft:moss_block
fill 56 129 323 56 129 324 minecraft:moss_block
setblock 56 129 325 minecraft:mossy_cobblestone
fill 56 129 326 56 129 328 minecraft:moss_block
setblock 56 129 329 minecraft:mossy_cobblestone
fill 56 129 330 56 129 332 minecraft:moss_block
setblock 56 129 333 minecraft:mossy_cobblestone
fill 56 129 334 56 129 336 minecraft:moss_block
setblock 56 129 337 minecraft:mossy_cobblestone
fill 56 129 338 56 129 340 minecraft:moss_block
setblock 56 129 341 minecraft:mossy_cobblestone
fill 56 129 342 56 129 344 minecraft:moss_block
setblock 56 129 345 minecraft:mossy_cobblestone
fill 56 129 346 56 129 348 minecraft:moss_block
setblock 56 129 349 minecraft:mossy_cobblestone
fill 56 129 350 56 129 352 minecraft:moss_block
setblock 56 129 353 minecraft:mossy_cobblestone
fill 56 129 354 58 129 354 minecraft:moss_block
setblock 56 129 357 minecraft:mossy_cobblestone
fill 56 129 358 58 129 358 minecraft:moss_block
setblock 56 129 361 minecraft:mossy_cobblestone
fill 56 129 362 58 129 362 minecraft:moss_block
setblock 57 129 323 minecraft:moss_block
setblock 57 129 324 minecraft:mossy_cobblestone
fill 57 129 325 57 129 327 minecraft:moss_block
setblock 57 129 328 minecraft:mossy_cobblestone
fill 57 129 329 57 129 331 minecraft:moss_block
setblock 57 129 332 minecraft:mossy_cobblestone
fill 57 129 333 57 129 335 minecraft:moss_block
setblock 57 129 336 minecraft:mossy_cobblestone
fill 57 129 337 57 129 339 minecraft:moss_block
setblock 57 129 340 minecraft:mossy_cobblestone
fill 57 129 341 57 129 343 minecraft:moss_block
setblock 57 129 344 minecraft:mossy_cobblestone
fill 57 129 345 57 129 347 minecraft:moss_block
setblock 57 129 348 minecraft:mossy_cobblestone
fill 57 129 349 57 129 351 minecraft:moss_block
setblock 57 129 352 minecraft:mossy_cobblestone
fill 57 129 353 59 129 353 minecraft:moss_block
setblock 57 129 356 minecraft:mossy_cobblestone
fill 57 129 357 59 129 357 minecraft:moss_block
setblock 57 129 360 minecraft:mossy_cobblestone
fill 57 129 361 59 129 361 minecraft:moss_block
setblock 58 129 323 minecraft:mossy_cobblestone
fill 58 129 324 58 129 326 minecraft:moss_block
setblock 58 129 327 minecraft:mossy_cobblestone
fill 58 129 328 58 129 330 minecraft:moss_block
setblock 58 129 331 minecraft:mossy_cobblestone
fill 58 129 332 58 129 334 minecraft:moss_block
setblock 58 129 335 minecraft:mossy_cobblestone
fill 58 129 336 58 129 338 minecraft:moss_block
setblock 58 129 339 minecraft:mossy_cobblestone
fill 58 129 340 58 129 342 minecraft:moss_block
setblock 58 129 343 minecraft:mossy_cobblestone
fill 58 129 344 58 129 346 minecraft:moss_block
setblock 58 129 347 minecraft:mossy_cobblestone
fill 58 129 348 58 129 350 minecraft:moss_block
setblock 58 129 351 minecraft:mossy_cobblestone
fill 58 129 352 60 129 352 minecraft:moss_block
setblock 58 129 355 minecraft:mossy_cobblestone
fill 58 129 356 60 129 356 minecraft:moss_block
setblock 58 129 359 minecraft:mossy_cobblestone
fill 58 129 360 60 129 360 minecraft:moss_block
setblock 58 129 363 minecraft:mossy_cobblestone
fill 59 129 323 59 129 325 minecraft:moss_block
setblock 59 129 326 minecraft:mossy_cobblestone
fill 59 129 327 59 129 329 minecraft:moss_block
setblock 59 129 330 minecraft:mossy_cobblestone
fill 59 129 331 59 129 333 minecraft:moss_block
setblock 59 129 334 minecraft:mossy_cobblestone
fill 59 129 335 59 129 337 minecraft:moss_block
setblock 59 129 338 minecraft:mossy_cobblestone
fill 59 129 339 59 129 341 minecraft:moss_block
setblock 59 129 342 minecraft:mossy_cobblestone
fill 59 129 343 59 129 345 minecraft:moss_block
setblock 59 129 346 minecraft:mossy_cobblestone
fill 59 129 347 59 129 349 minecraft:moss_block
setblock 59 129 350 minecraft:mossy_cobblestone
fill 59 129 351 61 129 351 minecraft:moss_block
setblock 59 129 354 minecraft:mossy_cobblestone
fill 59 129 355 61 129 355 minecraft:moss_block
setblock 59 129 358 minecraft:mossy_cobblestone
fill 59 129 359 61 129 359 minecraft:moss_block
setblock 59 129 362 minecraft:mossy_cobblestone
fill 59 129 363 61 129 363 minecraft:moss_block
fill 60 129 323 60 129 324 minecraft:moss_block
setblock 60 129 325 minecraft:mossy_cobblestone
fill 60 129 326 60 129 328 minecraft:moss_block
setblock 60 129 329 minecraft:mossy_cobblestone
fill 60 129 330 60 129 332 minecraft:moss_block
setblock 60 129 333 minecraft:mossy_cobblestone
fill 60 129 334 60 129 336 minecraft:moss_block
setblock 60 129 337 minecraft:mossy_cobblestone
fill 60 129 338 60 129 340 minecraft:moss_block
setblock 60 129 341 minecraft:mossy_cobblestone
fill 60 129 342 60 129 344 minecraft:moss_block
setblock 60 129 345 minecraft:mossy_cobblestone
fill 60 129 346 60 129 348 minecraft:moss_block
setblock 60 129 349 minecraft:mossy_cobblestone
fill 60 129 350 62 129 350 minecraft:moss_block
setblock 60 129 353 minecraft:mossy_cobblestone
fill 60 129 354 62 129 354 minecraft:moss_block
setblock 60 129 357 minecraft:mossy_cobblestone
fill 60 129 358 62 129 358 minecraft:moss_block
setblock 60 129 361 minecraft:mossy_cobblestone
fill 60 129 362 62 129 362 minecraft:moss_block
setblock 61 129 323 minecraft:moss_block
setblock 61 129 324 minecraft:mossy_cobblestone
fill 61 129 325 61 129 327 minecraft:moss_block
setblock 61 129 328 minecraft:mossy_cobblestone
fill 61 129 329 61 129 331 minecraft:moss_block
setblock 61 129 332 minecraft:mossy_cobblestone
fill 61 129 333 61 129 335 minecraft:moss_block
setblock 61 129 336 minecraft:mossy_cobblestone
fill 61 129 337 61 129 339 minecraft:moss_block
setblock 61 129 340 minecraft:mossy_cobblestone
fill 61 129 341 61 129 343 minecraft:moss_block
setblock 61 129 344 minecraft:mossy_cobblestone
fill 61 129 345 61 129 347 minecraft:moss_block
setblock 61 129 348 minecraft:mossy_cobblestone
fill 61 129 349 63 129 349 minecraft:moss_block
setblock 61 129 352 minecraft:mossy_cobblestone
fill 61 129 353 63 129 353 minecraft:moss_block
setblock 61 129 356 minecraft:mossy_cobblestone
fill 61 129 357 63 129 357 minecraft:moss_block
setblock 61 129 360 minecraft:mossy_cobblestone
fill 61 129 361 63 129 361 minecraft:moss_block
setblock 62 129 323 minecraft:mossy_cobblestone
fill 62 129 324 62 129 326 minecraft:moss_block
setblock 62 129 327 minecraft:mossy_cobblestone
fill 62 129 328 62 129 330 minecraft:moss_block
setblock 62 129 331 minecraft:mossy_cobblestone
fill 62 129 332 62 129 334 minecraft:moss_block
setblock 62 129 335 minecraft:mossy_cobblestone
fill 62 129 336 62 129 338 minecraft:moss_block
setblock 62 129 339 minecraft:mossy_cobblestone
fill 62 129 340 62 129 342 minecraft:moss_block
setblock 62 129 343 minecraft:mossy_cobblestone
fill 62 129 344 62 129 346 minecraft:moss_block
setblock 62 129 347 minecraft:mossy_cobblestone
fill 62 129 348 64 129 348 minecraft:moss_block
setblock 62 129 351 minecraft:mossy_cobblestone
fill 62 129 352 64 129 352 minecraft:moss_block
setblock 62 129 355 minecraft:mossy_cobblestone
fill 62 129 356 64 129 356 minecraft:moss_block
setblock 62 129 359 minecraft:mossy_cobblestone
fill 62 129 360 64 129 360 minecraft:moss_block
setblock 62 129 363 minecraft:mossy_cobblestone
fill 63 129 323 63 129 325 minecraft:moss_block
setblock 63 129 326 minecraft:mossy_cobblestone
fill 63 129 327 63 129 329 minecraft:moss_block
setblock 63 129 330 minecraft:mossy_cobblestone
fill 63 129 331 63 129 333 minecraft:moss_block
setblock 63 129 334 minecraft:mossy_cobblestone
fill 63 129 335 63 129 337 minecraft:moss_block
setblock 63 129 338 minecraft:mossy_cobblestone
fill 63 129 339 63 129 341 minecraft:moss_block
setblock 63 129 342 minecraft:mossy_cobblestone
fill 63 129 343 63 129 345 minecraft:moss_block
setblock 63 129 346 minecraft:mossy_cobblestone
fill 63 129 347 65 129 347 minecraft:moss_block
setblock 63 129 350 minecraft:mossy_cobblestone
fill 63 129 351 65 129 351 minecraft:moss_block
setblock 63 129 354 minecraft:mossy_cobblestone
fill 63 129 355 65 129 355 minecraft:moss_block
setblock 63 129 358 minecraft:mossy_cobblestone
fill 63 129 359 65 129 359 minecraft:moss_block
setblock 63 129 362 minecraft:mossy_cobblestone
fill 63 129 363 65 129 363 minecraft:moss_block
fill 64 129 323 64 129 324 minecraft:moss_block
setblock 64 129 325 minecraft:mossy_cobblestone
fill 64 129 326 64 129 328 minecraft:moss_block
setblock 64 129 329 minecraft:mossy_cobblestone
fill 64 129 330 64 129 332 minecraft:moss_block
setblock 64 129 333 minecraft:mossy_cobblestone
fill 64 129 334 64 129 336 minecraft:moss_block
setblock 64 129 337 minecraft:mossy_cobblestone
fill 64 129 338 64 129 340 minecraft:moss_block
setblock 64 129 341 minecraft:smooth_sandstone
fill 64 129 342 64 129 344 minecraft:moss_block
setblock 64 129 345 minecraft:mossy_cobblestone
fill 64 129 346 65 129 346 minecraft:moss_block
setblock 64 129 349 minecraft:mossy_cobblestone
fill 64 129 350 66 129 350 minecraft:moss_block
setblock 64 129 353 minecraft:mossy_cobblestone
fill 64 129 354 66 129 354 minecraft:moss_block
setblock 64 129 357 minecraft:mossy_cobblestone
fill 64 129 358 66 129 358 minecraft:moss_block
setblock 64 129 361 minecraft:mossy_cobblestone
fill 64 129 362 66 129 362 minecraft:moss_block
fill 65 129 322 66 129 322 minecraft:dark_oak_planks
setblock 65 129 323 minecraft:moss_block
setblock 65 129 324 minecraft:mossy_cobblestone
fill 65 129 325 65 129 327 minecraft:moss_block
setblock 65 129 328 minecraft:mossy_cobblestone
fill 65 129 329 65 129 331 minecraft:moss_block
setblock 65 129 332 minecraft:mossy_cobblestone
fill 65 129 333 65 129 335 minecraft:moss_block
setblock 65 129 336 minecraft:mossy_cobblestone
fill 65 129 337 65 129 338 minecraft:smooth_sandstone
fill 65 129 339 65 129 343 minecraft:white_concrete
fill 65 129 344 65 129 345 minecraft:smooth_sandstone
setblock 65 129 348 minecraft:mossy_cobblestone
fill 65 129 349 67 129 349 minecraft:moss_block
setblock 65 129 352 minecraft:mossy_cobblestone
fill 65 129 353 67 129 353 minecraft:moss_block
setblock 65 129 356 minecraft:mossy_cobblestone
fill 65 129 357 67 129 357 minecraft:moss_block
setblock 65 129 360 minecraft:mossy_cobblestone
fill 65 129 361 67 129 361 minecraft:moss_block
setblock 66 129 323 minecraft:mossy_cobblestone
fill 66 129 324 66 129 326 minecraft:moss_block
setblock 66 129 327 minecraft:mossy_cobblestone
fill 66 129 328 66 129 330 minecraft:moss_block
setblock 66 129 331 minecraft:mossy_cobblestone
fill 66 129 332 66 129 334 minecraft:moss_block
fill 66 129 335 66 129 336 minecraft:smooth_sandstone
setblock 66 129 337 minecraft:white_concrete
fill 66 129 338 66 129 344 minecraft:smooth_sandstone
setblock 66 129 345 minecraft:white_concrete
fill 66 129 346 66 129 347 minecraft:smooth_sandstone
setblock 66 129 348 minecraft:moss_block
setblock 66 129 351 minecraft:mossy_cobblestone
fill 66 129 352 68 129 352 minecraft:moss_block
setblock 66 129 355 minecraft:mossy_cobblestone
fill 66 129 356 68 129 356 minecraft:moss_block
setblock 66 129 359 minecraft:mossy_cobblestone
fill 66 129 360 68 129 360 minecraft:moss_block
setblock 66 129 363 minecraft:mossy_cobblestone
setblock 66 129 364 minecraft:dark_oak_planks
fill 67 129 323 67 129 325 minecraft:moss_block
setblock 67 129 326 minecraft:mossy_cobblestone
fill 67 129 327 67 129 329 minecraft:moss_block
setblock 67 129 330 minecraft:mossy_cobblestone
fill 67 129 331 67 129 333 minecraft:moss_block
setblock 67 129 334 minecraft:smooth_sandstone
setblock 67 129 335 minecraft:white_concrete
fill 67 129 336 67 129 339 minecraft:smooth_sandstone
fill 67 129 340 67 129 342 minecraft:white_concrete
fill 67 129 343 67 129 346 minecraft:smooth_sandstone
setblock 67 129 347 minecraft:white_concrete
setblock 67 129 348 minecraft:smooth_sandstone
setblock 67 129 350 minecraft:mossy_cobblestone
fill 67 129 351 69 129 351 minecraft:moss_block
setblock 67 129 354 minecraft:mossy_cobblestone
fill 67 129 355 69 129 355 minecraft:moss_block
setblock 67 129 358 minecraft:mossy_cobblestone
fill 67 129 359 69 129 359 minecraft:moss_block
setblock 67 129 362 minecraft:mossy_cobblestone
fill 67 129 363 69 129 363 minecraft:moss_block
fill 68 129 323 68 129 324 minecraft:moss_block
setblock 68 129 325 minecraft:mossy_cobblestone
fill 68 129 326 68 129 328 minecraft:moss_block
setblock 68 129 329 minecraft:mossy_cobblestone
fill 68 129 330 68 129 332 minecraft:moss_block
setblock 68 129 333 minecraft:smooth_sandstone
setblock 68 129 334 minecraft:white_concrete
fill 68 129 335 68 129 336 minecraft:smooth_sandstone
setblock 68 129 337 minecraft:white_concrete
fill 68 129 338 68 129 341 minecraft:smooth_sandstone
fill 68 129 342 69 129 344 minecraft:stone
setblock 68 129 345 minecraft:white_concrete
fill 68 129 346 68 129 347 minecraft:smooth_sandstone
setblock 68 129 348 minecraft:white_concrete
setblock 68 129 349 minecraft:smooth_sandstone
setblock 68 129 350 minecraft:moss_block
setblock 68 129 353 minecraft:mossy_cobblestone
fill 68 129 354 70 129 354 minecraft:moss_block
setblock 68 129 357 minecraft:mossy_cobblestone
fill 68 129 358 70 129 358 minecraft:moss_block
setblock 68 129 361 minecraft:mossy_cobblestone
fill 68 129 362 70 129 362 minecraft:moss_block
setblock 69 129 323 minecraft:moss_block
setblock 69 129 324 minecraft:mossy_cobblestone
fill 69 129 325 69 129 327 minecraft:moss_block
setblock 69 129 328 minecraft:mossy_cobblestone
fill 69 129 329 69 129 331 minecraft:moss_block
schedule function dropper:buildpart/73_2 1t
