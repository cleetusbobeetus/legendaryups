fill 385 144 558 387 144 558 minecraft:obsidian
fill 387 144 557 387 145 557 minecraft:purple_concrete
fill 387 144 598 389 144 598 minecraft:obsidian
fill 389 144 558 391 144 558 minecraft:obsidian
fill 390 144 599 391 145 599 minecraft:purple_concrete
fill 391 144 563 391 150 564 minecraft:purple_concrete
fill 391 144 598 393 144 598 minecraft:obsidian
fill 392 144 561 392 147 562 minecraft:purple_concrete
fill 392 144 564 392 150 565 minecraft:purple_concrete
fill 392 144 599 393 149 599 minecraft:purple_terracotta
fill 393 144 557 394 149 557 minecraft:purple_terracotta
fill 393 144 558 395 144 558 minecraft:obsidian
fill 393 144 565 395 146 565 minecraft:purple_concrete
setblock 394 144 599 minecraft:purple_concrete
fill 395 144 557 396 145 557 minecraft:purple_concrete
setblock 395 144 560 minecraft:black_concrete
fill 395 144 561 395 146 561 minecraft:purple_concrete
fill 395 144 598 397 144 598 minecraft:obsidian
fill 396 144 562 396 146 562 minecraft:purple_concrete
fill 396 144 564 396 146 564 minecraft:purple_concrete
fill 397 144 558 399 144 558 minecraft:obsidian
fill 397 144 561 397 145 562 minecraft:black_concrete
setblock 397 144 565 minecraft:black_concrete
setblock 398 144 561 minecraft:black_concrete
fill 399 144 598 401 144 598 minecraft:obsidian
fill 401 144 558 403 144 558 minecraft:obsidian
fill 402 144 599 403 145 599 minecraft:purple_concrete
fill 403 144 598 405 144 598 minecraft:obsidian
setblock 404 144 557 minecraft:purple_concrete
fill 404 144 599 405 149 599 minecraft:purple_terracotta
fill 405 144 557 406 149 557 minecraft:purple_terracotta
fill 405 144 558 407 144 558 minecraft:obsidian
fill 407 144 557 408 145 557 minecraft:purple_concrete
fill 407 144 598 409 144 598 minecraft:obsidian
fill 409 144 558 411 144 558 minecraft:obsidian
fill 411 144 598 413 144 598 minecraft:obsidian
fill 411 144 599 411 145 599 minecraft:purple_concrete
fill 413 144 557 414 149 557 minecraft:purple_terracotta
fill 413 144 558 415 144 558 minecraft:obsidian
fill 413 144 599 413 149 599 minecraft:purple_terracotta
fill 414 144 599 415 144 599 minecraft:purple_concrete
fill 415 144 557 416 144 557 minecraft:purple_concrete
fill 415 144 598 417 144 598 minecraft:obsidian
fill 416 144 599 416 149 599 minecraft:purple_terracotta
fill 417 144 557 417 149 557 minecraft:purple_terracotta
fill 417 144 558 417 144 560 minecraft:obsidian
fill 417 144 562 417 144 564 minecraft:obsidian
fill 417 144 566 417 144 568 minecraft:obsidian
fill 417 144 570 417 144 572 minecraft:obsidian
fill 417 144 574 417 144 576 minecraft:obsidian
fill 417 144 578 417 144 580 minecraft:obsidian
fill 417 144 582 417 144 584 minecraft:obsidian
fill 417 144 586 417 144 588 minecraft:obsidian
fill 417 144 590 417 144 592 minecraft:obsidian
fill 417 144 594 417 144 596 minecraft:obsidian
fill 418 144 564 418 149 565 minecraft:purple_terracotta
fill 418 144 566 418 145 567 minecraft:purple_concrete
fill 418 144 573 418 149 573 minecraft:purple_terracotta
setblock 418 144 575 minecraft:purple_concrete
fill 418 144 576 418 149 577 minecraft:purple_terracotta
fill 418 144 578 418 145 578 minecraft:purple_concrete
fill 418 144 584 418 149 585 minecraft:purple_terracotta
fill 418 144 586 418 144 587 minecraft:purple_concrete
fill 418 144 596 418 149 597 minecraft:purple_terracotta
fill 418 144 598 418 145 598 minecraft:purple_concrete
fill 376 145 565 376 147 565 minecraft:purple_terracotta
setblock 376 145 570 minecraft:purple_concrete
setblock 376 145 581 minecraft:purple_concrete
fill 376 145 585 376 147 586 minecraft:purple_terracotta
fill 378 145 599 379 145 599 minecraft:purple_concrete
fill 379 145 583 379 145 584 minecraft:obsidian
setblock 380 145 581 minecraft:obsidian
setblock 380 145 586 minecraft:obsidian
setblock 382 145 599 minecraft:purple_concrete
fill 383 145 557 384 148 557 minecraft:purple_terracotta
fill 383 145 599 383 148 599 minecraft:purple_terracotta
setblock 384 145 581 minecraft:obsidian
setblock 384 145 586 minecraft:obsidian
fill 385 145 582 385 145 585 minecraft:obsidian
setblock 388 145 557 minecraft:purple_concrete
fill 390 145 563 390 151 565 minecraft:purple_concrete
fill 391 145 562 391 149 562 minecraft:purple_concrete
fill 391 145 565 391 151 565 minecraft:purple_concrete
setblock 394 145 560 minecraft:purple_concrete
fill 394 145 599 394 148 599 minecraft:purple_terracotta
setblock 396 145 561 minecraft:purple_concrete
fill 398 145 562 398 145 563 minecraft:black_concrete
setblock 399 145 557 minecraft:purple_concrete
setblock 399 145 599 minecraft:purple_concrete
fill 404 145 557 404 148 557 minecraft:purple_terracotta
setblock 410 145 599 minecraft:purple_concrete
fill 414 145 599 415 148 599 minecraft:purple_terracotta
fill 415 145 557 415 148 557 minecraft:purple_terracotta
setblock 416 145 557 minecraft:purple_concrete
fill 418 145 558 418 145 559 minecraft:purple_concrete
fill 418 145 575 418 148 575 minecraft:purple_terracotta
setblock 418 145 579 minecraft:purple_concrete
fill 418 145 586 418 148 586 minecraft:purple_terracotta
setblock 418 145 587 minecraft:purple_concrete
setblock 418 145 590 minecraft:purple_concrete
fill 376 146 559 376 147 560 minecraft:purple_concrete
fill 376 146 561 376 151 562 minecraft:purple_terracotta
setblock 376 146 567 minecraft:purple_terracotta
fill 376 146 568 376 147 568 minecraft:purple_concrete
fill 376 146 570 376 151 570 minecraft:purple_terracotta
fill 376 146 571 376 146 572 minecraft:purple_concrete
fill 376 146 573 376 148 574 minecraft:purple_terracotta
fill 376 146 579 376 147 580 minecraft:purple_concrete
fill 376 146 581 376 151 582 minecraft:purple_terracotta
setblock 376 146 583 minecraft:purple_concrete
fill 376 146 584 376 149 584 minecraft:purple_terracotta
fill 376 146 591 376 146 592 minecraft:purple_concrete
fill 376 146 593 376 151 594 minecraft:purple_terracotta
fill 377 146 557 378 147 557 minecraft:purple_concrete
fill 377 146 599 377 147 599 minecraft:purple_concrete
fill 378 146 599 379 151 599 minecraft:purple_terracotta
setblock 380 146 599 minecraft:purple_concrete
fill 381 146 583 383 146 584 minecraft:amethyst_block
fill 382 146 599 382 151 599 minecraft:purple_terracotta
setblock 386 146 557 minecraft:purple_concrete
fill 387 146 557 388 151 557 minecraft:purple_terracotta
fill 388 146 599 389 147 599 minecraft:purple_concrete
fill 389 146 557 390 147 557 minecraft:purple_concrete
fill 389 146 563 389 151 565 minecraft:purple_concrete
fill 390 146 562 390 149 562 minecraft:purple_concrete
fill 390 146 566 393 147 566 minecraft:purple_concrete
fill 390 146 599 391 151 599 minecraft:purple_terracotta
fill 391 146 561 391 147 561 minecraft:purple_concrete
fill 395 146 557 396 151 557 minecraft:purple_terracotta
setblock 396 146 561 minecraft:black_concrete
fill 397 146 557 398 146 557 minecraft:purple_concrete
fill 399 146 557 399 151 557 minecraft:purple_terracotta
fill 399 146 599 399 151 599 minecraft:purple_terracotta
fill 400 146 599 401 146 599 minecraft:purple_concrete
fill 402 146 599 403 151 599 minecraft:purple_terracotta
fill 407 146 557 408 151 557 minecraft:purple_terracotta
fill 408 146 599 409 147 599 minecraft:purple_concrete
fill 409 146 557 410 147 557 minecraft:purple_concrete
fill 410 146 599 411 151 599 minecraft:purple_terracotta
setblock 412 146 599 minecraft:purple_concrete
fill 416 146 557 416 151 557 minecraft:purple_terracotta
setblock 418 146 557 minecraft:purple_concrete
fill 418 146 558 418 151 559 minecraft:purple_terracotta
fill 418 146 560 418 147 560 minecraft:purple_concrete
fill 418 146 566 418 151 567 minecraft:purple_terracotta
fill 418 146 568 418 146 569 minecraft:purple_concrete
fill 418 146 578 418 151 579 minecraft:purple_terracotta
fill 418 146 580 418 147 581 minecraft:purple_concrete
fill 418 146 587 418 151 587 minecraft:purple_terracotta
fill 418 146 588 418 146 589 minecraft:purple_concrete
fill 418 146 590 418 151 590 minecraft:purple_terracotta
fill 418 146 592 418 147 592 minecraft:purple_concrete
fill 418 146 598 418 151 598 minecraft:purple_terracotta
setblock 376 147 567 minecraft:purple_concrete
setblock 376 147 571 minecraft:purple_concrete
fill 376 147 572 376 150 572 minecraft:purple_terracotta
fill 376 147 583 376 149 583 minecraft:purple_terracotta
setblock 376 147 588 minecraft:purple_concrete
setblock 376 147 591 minecraft:purple_concrete
fill 376 147 592 376 150 592 minecraft:purple_terracotta
setblock 376 147 599 minecraft:purple_concrete
fill 380 147 599 380 150 599 minecraft:purple_terracotta
setblock 381 147 557 minecraft:purple_concrete
fill 382 147 583 382 149 584 minecraft:amethyst_block
setblock 383 147 583 minecraft:amethyst_block
fill 386 147 557 386 150 557 minecraft:purple_terracotta
fill 388 147 563 388 150 566 minecraft:purple_concrete
fill 389 147 562 389 149 562 minecraft:purple_concrete
fill 389 147 566 389 153 566 minecraft:purple_concrete
fill 392 147 563 395 147 563 minecraft:purple_concrete
fill 393 147 565 394 147 565 minecraft:purple_concrete
fill 396 147 599 397 147 599 minecraft:purple_concrete
fill 397 147 557 397 150 557 minecraft:purple_terracotta
setblock 398 147 557 minecraft:purple_concrete
setblock 400 147 599 minecraft:purple_concrete
fill 401 147 557 402 147 557 minecraft:purple_concrete
fill 401 147 599 401 150 599 minecraft:purple_terracotta
fill 412 147 599 412 150 599 minecraft:purple_terracotta
setblock 417 147 599 minecraft:purple_concrete
fill 418 147 557 418 150 557 minecraft:purple_terracotta
setblock 418 147 561 minecraft:purple_concrete
fill 418 147 568 418 150 568 minecraft:purple_terracotta
setblock 418 147 569 minecraft:purple_concrete
setblock 418 147 572 minecraft:purple_concrete
fill 418 147 588 418 150 589 minecraft:purple_terracotta
setblock 418 147 593 minecraft:purple_concrete
fill 376 148 557 376 148 558 minecraft:purple_concrete
fill 376 148 559 376 153 560 minecraft:purple_terracotta
fill 376 148 565 376 149 566 minecraft:purple_concrete
fill 376 148 567 376 153 568 minecraft:purple_terracotta
setblock 376 148 569 minecraft:purple_concrete
fill 376 148 571 376 150 571 minecraft:purple_terracotta
fill 376 148 577 376 149 578 minecraft:purple_concrete
fill 376 148 579 376 153 580 minecraft:purple_terracotta
setblock 376 148 585 minecraft:purple_terracotta
fill 376 148 586 376 149 586 minecraft:purple_concrete
fill 376 148 588 376 153 588 minecraft:purple_terracotta
fill 376 148 589 376 148 590 minecraft:purple_concrete
fill 376 148 591 376 153 591 minecraft:purple_terracotta
fill 376 148 597 376 149 598 minecraft:purple_concrete
fill 376 148 599 377 153 599 minecraft:purple_terracotta
fill 377 148 557 378 153 557 minecraft:purple_terracotta
fill 379 148 557 380 148 557 minecraft:purple_concrete
setblock 379 148 560 minecraft:light[level=12]
setblock 379 148 568 minecraft:light[level=12]
setblock 379 148 576 minecraft:light[level=12]
setblock 379 148 584 minecraft:light[level=12]
setblock 379 148 592 minecraft:light[level=12]
fill 381 148 557 381 153 557 minecraft:purple_terracotta
fill 386 148 599 387 148 599 minecraft:purple_concrete
setblock 387 148 560 minecraft:light[level=12]
fill 387 148 564 387 149 567 minecraft:purple_concrete
setblock 387 148 568 minecraft:light[level=12]
setblock 387 148 576 minecraft:light[level=12]
setblock 387 148 584 minecraft:light[level=12]
setblock 387 148 592 minecraft:light[level=12]
fill 388 148 567 390 150 567 minecraft:purple_concrete
fill 388 148 599 389 153 599 minecraft:purple_terracotta
fill 389 148 557 390 153 557 minecraft:purple_terracotta
fill 390 148 566 392 149 566 minecraft:purple_concrete
fill 391 148 557 392 149 557 minecraft:purple_concrete
fill 392 148 562 394 148 563 minecraft:purple_concrete
fill 393 148 564 393 148 565 minecraft:purple_concrete
setblock 394 148 564 minecraft:purple_concrete
setblock 395 148 560 minecraft:light[level=12]
setblock 395 148 568 minecraft:light[level=12]
setblock 395 148 576 minecraft:light[level=12]
setblock 395 148 584 minecraft:light[level=12]
setblock 395 148 592 minecraft:light[level=12]
fill 395 148 599 395 149 599 minecraft:purple_concrete
fill 396 148 599 397 153 599 minecraft:purple_terracotta
fill 398 148 557 398 153 557 minecraft:purple_terracotta
setblock 398 148 599 minecraft:purple_concrete
setblock 400 148 557 minecraft:purple_concrete
fill 400 148 599 400 153 599 minecraft:purple_terracotta
fill 401 148 557 402 153 557 minecraft:purple_terracotta
fill 403 148 557 403 149 557 minecraft:purple_concrete
setblock 403 148 560 minecraft:light[level=12]
setblock 403 148 568 minecraft:light[level=12]
setblock 403 148 576 minecraft:light[level=12]
setblock 403 148 584 minecraft:light[level=12]
setblock 403 148 592 minecraft:light[level=12]
fill 406 148 599 407 149 599 minecraft:purple_concrete
fill 408 148 599 409 153 599 minecraft:purple_terracotta
fill 409 148 557 410 153 557 minecraft:purple_terracotta
fill 411 148 557 412 148 557 minecraft:purple_concrete
setblock 411 148 560 minecraft:light[level=12]
setblock 411 148 568 minecraft:light[level=12]
setblock 411 148 576 minecraft:light[level=12]
setblock 411 148 584 minecraft:light[level=12]
setblock 411 148 592 minecraft:light[level=12]
fill 417 148 599 417 153 599 minecraft:purple_terracotta
fill 418 148 560 418 153 561 minecraft:purple_terracotta
fill 418 148 562 418 149 563 minecraft:purple_concrete
fill 418 148 569 418 153 569 minecraft:purple_terracotta
fill 418 148 570 418 148 571 minecraft:purple_concrete
fill 418 148 572 418 153 572 minecraft:purple_terracotta
fill 418 148 574 418 149 574 minecraft:purple_concrete
fill 418 148 580 418 153 581 minecraft:purple_terracotta
fill 418 148 582 418 149 583 minecraft:purple_concrete
setblock 418 148 591 minecraft:purple_concrete
fill 418 148 592 418 153 593 minecraft:purple_terracotta
fill 418 148 594 418 149 595 minecraft:purple_concrete
fill 418 148 599 418 149 599 minecraft:purple_concrete
setblock 376 149 557 minecraft:purple_concrete
fill 376 149 558 376 152 558 minecraft:purple_terracotta
fill 376 149 569 376 152 569 minecraft:purple_terracotta
fill 376 149 573 376 151 573 minecraft:purple_terracotta
setblock 376 149 574 minecraft:purple_concrete
setblock 376 149 585 minecraft:purple_concrete
fill 376 149 589 376 152 590 minecraft:purple_terracotta
fill 379 149 557 379 152 557 minecraft:purple_terracotta
setblock 380 149 557 minecraft:purple_concrete
fill 383 149 557 384 149 557 minecraft:purple_concrete
setblock 383 149 599 minecraft:purple_concrete
fill 386 149 564 386 149 567 minecraft:purple_concrete
setblock 386 149 599 minecraft:purple_concrete
fill 387 149 563 387 150 563 minecraft:purple_concrete
fill 387 149 568 388 149 568 minecraft:purple_concrete
fill 387 149 599 387 152 599 minecraft:purple_terracotta
fill 392 149 562 392 149 563 minecraft:purple_concrete
fill 393 149 563 393 149 564 minecraft:purple_concrete
fill 394 149 562 394 151 563 minecraft:amethyst_block
setblock 394 149 599 minecraft:purple_concrete
fill 398 149 599 398 152 599 minecraft:purple_terracotta
fill 400 149 557 400 152 557 minecraft:purple_terracotta
setblock 404 149 557 minecraft:purple_concrete
fill 411 149 557 411 152 557 minecraft:purple_terracotta
setblock 412 149 557 minecraft:purple_concrete
fill 414 149 599 415 149 599 minecraft:purple_concrete
setblock 415 149 557 minecraft:purple_concrete
fill 418 149 570 418 152 571 minecraft:purple_terracotta
setblock 418 149 575 minecraft:purple_concrete
setblock 418 149 586 minecraft:purple_concrete
fill 418 149 591 418 152 591 minecraft:purple_terracotta
fill 376 150 557 376 155 557 minecraft:purple_terracotta
fill 376 150 563 376 151 564 minecraft:purple_concrete
fill 376 150 565 376 155 566 minecraft:purple_terracotta
fill 376 150 574 376 151 574 minecraft:purple_terracotta
fill 376 150 575 376 150 576 minecraft:purple_concrete
fill 376 150 577 376 155 578 minecraft:purple_terracotta
fill 376 150 583 376 151 584 minecraft:purple_concrete
fill 376 150 585 376 155 586 minecraft:purple_terracotta
setblock 376 150 587 minecraft:purple_concrete
fill 376 150 595 376 151 596 minecraft:purple_concrete
fill 376 150 597 376 155 598 minecraft:purple_terracotta
fill 377 150 558 379 150 558 minecraft:obsidian
fill 377 150 560 377 150 562 minecraft:obsidian
fill 377 150 564 377 150 566 minecraft:obsidian
fill 377 150 568 377 150 570 minecraft:obsidian
fill 377 150 572 377 150 574 minecraft:obsidian
fill 377 150 576 377 150 578 minecraft:obsidian
fill 377 150 580 377 150 582 minecraft:obsidian
fill 377 150 584 377 150 586 minecraft:obsidian
fill 377 150 588 377 150 590 minecraft:obsidian
fill 377 150 592 377 150 594 minecraft:obsidian
fill 377 150 596 377 150 598 minecraft:obsidian
fill 379 150 598 381 150 598 minecraft:obsidian
fill 380 150 557 380 155 557 minecraft:purple_terracotta
fill 381 150 558 383 150 558 minecraft:obsidian
fill 381 150 599 381 151 599 minecraft:purple_concrete
setblock 382 150 557 minecraft:purple_concrete
fill 383 150 557 384 155 557 minecraft:purple_terracotta
fill 383 150 598 385 150 598 minecraft:obsidian
fill 383 150 599 383 155 599 minecraft:purple_terracotta
fill 384 150 599 385 150 599 minecraft:purple_concrete
fill 385 150 557 385 151 557 minecraft:purple_concrete
fill 385 150 558 387 150 558 minecraft:obsidian
fill 385 150 565 387 150 565 minecraft:purple_concrete
fill 385 150 566 387 154 568 minecraft:black_concrete
fill 386 150 564 387 152 564 minecraft:purple_concrete
fill 386 150 569 386 156 569 minecraft:black_concrete
fill 386 150 599 386 155 599 minecraft:purple_terracotta
setblock 387 150 569 minecraft:purple_concrete
fill 387 150 598 389 150 598 minecraft:obsidian
fill 388 150 568 389 150 568 minecraft:purple_concrete
fill 389 150 558 391 150 558 minecraft:obsidian
fill 390 150 566 391 150 566 minecraft:purple_concrete
fill 391 150 557 392 155 557 minecraft:purple_terracotta
fill 391 150 598 393 150 598 minecraft:obsidian
fill 392 150 599 393 151 599 minecraft:purple_concrete
fill 393 150 557 394 150 557 minecraft:purple_concrete
fill 393 150 558 395 150 558 minecraft:obsidian
fill 394 150 599 395 155 599 minecraft:purple_terracotta
fill 395 150 598 397 150 598 minecraft:obsidian
fill 397 150 558 399 150 558 minecraft:obsidian
fill 399 150 598 401 150 598 minecraft:obsidian
fill 401 150 558 403 150 558 minecraft:obsidian
fill 403 150 557 404 155 557 minecraft:purple_terracotta
fill 403 150 598 405 150 598 minecraft:obsidian
fill 404 150 599 405 150 599 minecraft:purple_concrete
fill 405 150 557 406 151 557 minecraft:purple_concrete
fill 405 150 558 407 150 558 minecraft:obsidian
fill 406 150 599 407 155 599 minecraft:purple_terracotta
fill 407 150 598 409 150 598 minecraft:obsidian
fill 409 150 558 411 150 558 minecraft:obsidian
fill 411 150 598 413 150 598 minecraft:obsidian
fill 412 150 557 412 155 557 minecraft:purple_terracotta
fill 413 150 557 414 150 557 minecraft:purple_concrete
fill 413 150 558 415 150 558 minecraft:obsidian
fill 413 150 599 413 151 599 minecraft:purple_concrete
fill 414 150 599 415 155 599 minecraft:purple_terracotta
fill 415 150 557 415 155 557 minecraft:purple_terracotta
fill 415 150 598 417 150 598 minecraft:obsidian
setblock 416 150 599 minecraft:purple_concrete
fill 417 150 557 417 151 557 minecraft:purple_concrete
fill 417 150 558 417 150 560 minecraft:obsidian
fill 417 150 562 417 150 564 minecraft:obsidian
fill 417 150 566 417 150 568 minecraft:obsidian
fill 417 150 570 417 150 572 minecraft:obsidian
fill 417 150 574 417 150 576 minecraft:obsidian
fill 417 150 578 417 150 580 minecraft:obsidian
fill 417 150 582 417 150 584 minecraft:obsidian
fill 417 150 586 417 150 588 minecraft:obsidian
fill 417 150 590 417 150 592 minecraft:obsidian
fill 417 150 594 417 150 596 minecraft:obsidian
fill 418 150 562 418 155 563 minecraft:purple_terracotta
fill 418 150 564 418 151 565 minecraft:purple_concrete
setblock 418 150 573 minecraft:purple_concrete
fill 418 150 574 418 155 575 minecraft:purple_terracotta
fill 418 150 576 418 151 577 minecraft:purple_concrete
fill 418 150 582 418 155 583 minecraft:purple_terracotta
fill 418 150 584 418 150 585 minecraft:purple_concrete
fill 418 150 586 418 155 586 minecraft:purple_terracotta
fill 418 150 594 418 155 595 minecraft:purple_terracotta
fill 418 150 596 418 151 597 minecraft:purple_concrete
fill 418 150 599 418 155 599 minecraft:purple_terracotta
fill 376 151 571 376 151 572 minecraft:purple_concrete
setblock 376 151 575 minecraft:purple_concrete
fill 376 151 576 376 154 576 minecraft:purple_terracotta
fill 376 151 587 376 154 587 minecraft:purple_terracotta
setblock 376 151 592 minecraft:purple_concrete
setblock 380 151 599 minecraft:purple_concrete
fill 382 151 557 382 154 557 minecraft:purple_terracotta
fill 384 151 566 384 153 569 minecraft:black_concrete
fill 384 151 599 385 154 599 minecraft:purple_terracotta
fill 385 151 565 387 153 565 minecraft:black_concrete
fill 385 151 569 385 153 570 minecraft:black_concrete
setblock 386 151 557 minecraft:purple_concrete
fill 387 151 569 387 155 569 minecraft:black_concrete
fill 388 151 563 388 151 565 minecraft:purple_concrete
fill 388 151 566 388 153 568 minecraft:black_concrete
setblock 388 151 569 minecraft:purple_concrete
fill 389 151 567 389 152 568 minecraft:purple_concrete
fill 390 151 566 390 151 567 minecraft:purple_concrete
fill 393 151 557 393 154 557 minecraft:purple_terracotta
setblock 394 151 557 minecraft:purple_concrete
setblock 397 151 557 minecraft:purple_concrete
setblock 401 151 599 minecraft:purple_concrete
setblock 404 151 599 minecraft:purple_concrete
fill 405 151 599 405 154 599 minecraft:purple_terracotta
setblock 412 151 599 minecraft:purple_concrete
fill 413 151 557 414 154 557 minecraft:purple_terracotta
fill 416 151 599 416 154 599 minecraft:purple_terracotta
setblock 418 151 557 minecraft:purple_concrete
setblock 418 151 568 minecraft:purple_concrete
fill 418 151 573 418 154 573 minecraft:purple_terracotta
fill 418 151 584 418 154 584 minecraft:purple_terracotta
setblock 418 151 585 minecraft:purple_concrete
fill 418 151 588 418 151 589 minecraft:purple_concrete
fill 376 152 561 376 153 562 minecraft:purple_concrete
fill 376 152 563 376 157 564 minecraft:purple_terracotta
fill 376 152 570 376 153 570 minecraft:purple_concrete
fill 376 152 571 376 153 572 minecraft:purple_terracotta
fill 376 152 573 376 152 574 minecraft:purple_concrete
fill 376 152 575 376 157 575 minecraft:purple_terracotta
fill 376 152 581 376 153 582 minecraft:purple_concrete
fill 376 152 583 376 157 584 minecraft:purple_terracotta
fill 376 152 592 376 157 592 minecraft:purple_terracotta
fill 376 152 593 376 152 594 minecraft:purple_concrete
fill 376 152 595 376 157 596 minecraft:purple_terracotta
fill 378 152 599 379 153 599 minecraft:purple_concrete
fill 380 152 599 381 157 599 minecraft:purple_terracotta
setblock 382 152 599 minecraft:purple_concrete
fill 383 152 567 383 153 570 minecraft:black_concrete
fill 384 152 570 384 153 571 minecraft:black_concrete
fill 385 152 557 386 157 557 minecraft:purple_terracotta
fill 385 152 571 385 153 571 minecraft:black_concrete
fill 386 152 570 387 154 570 minecraft:black_concrete
fill 387 152 557 388 153 557 minecraft:purple_concrete
fill 388 152 564 389 152 565 minecraft:purple_concrete
setblock 388 152 569 minecraft:black_concrete
setblock 390 152 566 minecraft:purple_concrete
fill 390 152 599 391 153 599 minecraft:purple_concrete
fill 392 152 599 393 157 599 minecraft:purple_terracotta
fill 394 152 557 394 157 557 minecraft:purple_terracotta
fill 395 152 557 396 152 557 minecraft:purple_concrete
fill 397 152 557 397 157 557 minecraft:purple_terracotta
fill 399 152 557 399 153 557 minecraft:purple_concrete
fill 399 152 599 399 153 599 minecraft:purple_concrete
fill 401 152 599 401 157 599 minecraft:purple_terracotta
fill 402 152 599 403 152 599 minecraft:purple_concrete
fill 404 152 599 404 157 599 minecraft:purple_terracotta
fill 405 152 557 406 157 557 minecraft:purple_terracotta
fill 407 152 557 408 153 557 minecraft:purple_concrete
fill 410 152 599 411 153 599 minecraft:purple_concrete
fill 412 152 599 413 157 599 minecraft:purple_terracotta
setblock 416 152 557 minecraft:purple_concrete
fill 417 152 557 418 157 557 minecraft:purple_terracotta
fill 418 152 558 418 153 559 minecraft:purple_concrete
fill 418 152 564 418 157 565 minecraft:purple_terracotta
fill 418 152 566 418 152 567 minecraft:purple_concrete
fill 418 152 568 418 157 568 minecraft:purple_terracotta
fill 418 152 576 418 157 577 minecraft:purple_terracotta
fill 418 152 578 418 153 579 minecraft:purple_concrete
fill 418 152 585 418 157 585 minecraft:purple_terracotta
setblock 418 152 587 minecraft:purple_concrete
fill 418 152 588 418 157 589 minecraft:purple_terracotta
fill 418 152 590 418 153 590 minecraft:purple_concrete
fill 418 152 596 418 157 597 minecraft:purple_terracotta
setblock 418 152 598 minecraft:purple_concrete
setblock 376 153 558 minecraft:purple_concrete
setblock 376 153 569 minecraft:purple_concrete
fill 376 153 573 376 155 574 minecraft:purple_terracotta
fill 376 153 589 376 153 590 minecraft:purple_concrete
setblock 376 153 593 minecraft:purple_concrete
fill 376 153 594 376 156 594 minecraft:purple_terracotta
setblock 379 153 557 minecraft:purple_concrete
fill 382 153 569 382 153 571 minecraft:black_concrete
fill 382 153 599 382 156 599 minecraft:purple_terracotta
fill 383 153 571 383 159 571 minecraft:purple_concrete
fill 383 153 572 384 153 572 minecraft:black_concrete
fill 386 153 571 386 156 571 minecraft:black_concrete
setblock 387 153 599 minecraft:purple_concrete
setblock 388 153 565 minecraft:purple_concrete
fill 395 153 557 396 156 557 minecraft:purple_terracotta
setblock 398 153 599 minecraft:purple_concrete
setblock 400 153 557 minecraft:purple_concrete
fill 402 153 599 403 156 599 minecraft:purple_terracotta
setblock 411 153 557 minecraft:purple_concrete
fill 416 153 557 416 156 557 minecraft:purple_terracotta
fill 418 153 566 418 156 566 minecraft:purple_terracotta
setblock 418 153 567 minecraft:purple_concrete
fill 418 153 570 418 153 571 minecraft:purple_concrete
fill 418 153 587 418 156 587 minecraft:purple_terracotta
setblock 418 153 591 minecraft:purple_concrete
fill 418 153 598 418 156 598 minecraft:purple_terracotta
fill 376 154 558 376 159 558 minecraft:purple_terracotta
fill 376 154 559 376 154 560 minecraft:purple_concrete
fill 376 154 561 376 156 562 minecraft:purple_terracotta
fill 376 154 567 376 155 568 minecraft:purple_concrete
fill 376 154 569 376 159 570 minecraft:purple_terracotta
setblock 376 154 571 minecraft:purple_concrete
fill 376 154 572 376 157 572 minecraft:purple_terracotta
fill 376 154 579 376 154 580 minecraft:purple_concrete
fill 376 154 581 376 159 582 minecraft:purple_terracotta
fill 376 154 588 376 155 588 minecraft:purple_concrete
fill 376 154 589 376 159 590 minecraft:purple_terracotta
setblock 376 154 591 minecraft:purple_concrete
fill 376 154 593 376 159 593 minecraft:purple_terracotta
fill 376 154 599 377 155 599 minecraft:purple_concrete
fill 377 154 557 378 154 557 minecraft:purple_concrete
fill 378 154 599 379 159 599 minecraft:purple_terracotta
fill 379 154 557 379 159 557 minecraft:purple_terracotta
fill 381 154 557 381 155 557 minecraft:purple_concrete
fill 381 154 571 382 158 571 minecraft:purple_concrete
fill 382 154 568 382 154 569 minecraft:black_concrete
fill 382 154 570 385 157 570 minecraft:purple_concrete
fill 382 154 572 385 158 572 minecraft:purple_concrete
fill 383 154 567 384 155 568 minecraft:black_concrete
fill 383 154 569 384 157 569 minecraft:purple_concrete
fill 383 154 573 384 160 573 minecraft:purple_concrete
setblock 384 154 566 minecraft:black_concrete
fill 384 154 571 385 158 571 minecraft:purple_concrete
setblock 385 154 569 minecraft:black_concrete
fill 387 154 557 388 159 557 minecraft:purple_terracotta
fill 387 154 599 387 159 599 minecraft:purple_terracotta
fill 388 154 599 389 154 599 minecraft:purple_concrete
fill 389 154 557 390 155 557 minecraft:purple_concrete
fill 390 154 599 391 159 599 minecraft:purple_terracotta
fill 396 154 599 397 155 599 minecraft:purple_concrete
setblock 398 154 557 minecraft:purple_concrete
fill 398 154 599 399 159 599 minecraft:purple_terracotta
fill 399 154 557 400 159 557 minecraft:purple_terracotta
setblock 400 154 599 minecraft:purple_concrete
fill 401 154 557 402 155 557 minecraft:purple_concrete
fill 407 154 557 408 159 557 minecraft:purple_terracotta
fill 408 154 599 409 155 599 minecraft:purple_concrete
fill 409 154 557 410 154 557 minecraft:purple_concrete
fill 410 154 599 411 159 599 minecraft:purple_terracotta
fill 411 154 557 411 159 557 minecraft:purple_terracotta
fill 417 154 599 417 155 599 minecraft:purple_concrete
fill 418 154 558 418 159 559 minecraft:purple_terracotta
fill 418 154 560 418 155 561 minecraft:purple_concrete
fill 418 154 567 418 159 567 minecraft:purple_terracotta
setblock 418 154 569 minecraft:purple_concrete
fill 418 154 570 418 159 571 minecraft:purple_terracotta
fill 418 154 572 418 155 572 minecraft:purple_concrete
fill 418 154 578 418 159 579 minecraft:purple_terracotta
fill 418 154 580 418 154 581 minecraft:purple_concrete
fill 418 154 590 418 159 591 minecraft:purple_terracotta
fill 418 154 592 418 155 593 minecraft:purple_concrete
setblock 376 155 559 minecraft:purple_concrete
fill 376 155 560 376 158 560 minecraft:purple_terracotta
fill 376 155 571 376 157 571 minecraft:purple_terracotta
setblock 376 155 576 minecraft:purple_concrete
setblock 376 155 579 minecraft:purple_concrete
fill 376 155 580 376 158 580 minecraft:purple_terracotta
setblock 376 155 587 minecraft:purple_concrete
fill 376 155 591 376 158 591 minecraft:purple_terracotta
fill 377 155 557 378 157 557 minecraft:purple_terracotta
fill 381 155 570 381 157 570 minecraft:purple_concrete
fill 381 155 572 381 159 573 minecraft:purple_concrete
setblock 382 155 557 minecraft:purple_concrete
setblock 382 155 568 minecraft:black_concrete
fill 382 155 569 382 157 569 minecraft:purple_concrete
fill 382 155 573 382 161 574 minecraft:purple_concrete
fill 383 155 574 384 160 574 minecraft:purple_concrete
fill 384 155 599 385 155 599 minecraft:purple_concrete
fill 385 155 567 386 155 568 minecraft:black_concrete
fill 385 155 569 385 156 569 minecraft:purple_concrete
fill 385 155 573 385 158 573 minecraft:purple_concrete
fill 386 155 570 386 156 570 minecraft:black_concrete
setblock 387 155 568 minecraft:black_concrete
setblock 388 155 599 minecraft:purple_concrete
fill 389 155 599 389 158 599 minecraft:purple_terracotta
setblock 393 155 557 minecraft:purple_concrete
fill 398 155 557 398 158 557 minecraft:purple_terracotta
fill 400 155 599 400 158 599 minecraft:purple_terracotta
setblock 405 155 599 minecraft:purple_concrete
fill 409 155 557 409 158 557 minecraft:purple_terracotta
setblock 410 155 557 minecraft:purple_concrete
fill 413 155 557 414 155 557 minecraft:purple_concrete
setblock 416 155 599 minecraft:purple_concrete
fill 418 155 569 418 158 569 minecraft:purple_terracotta
setblock 418 155 573 minecraft:purple_concrete
fill 418 155 580 418 158 580 minecraft:purple_terracotta
setblock 418 155 581 minecraft:purple_concrete
setblock 418 155 584 minecraft:purple_concrete
setblock 376 156 557 minecraft:purple_concrete
fill 376 156 559 376 158 559 minecraft:purple_terracotta
fill 376 156 565 376 157 566 minecraft:purple_concrete
fill 376 156 567 376 161 568 minecraft:purple_terracotta
setblock 376 156 573 minecraft:purple_terracotta
fill 376 156 574 376 157 574 minecraft:purple_concrete
fill 376 156 576 376 161 576 minecraft:purple_terracotta
fill 376 156 577 376 156 578 minecraft:purple_concrete
fill 376 156 579 376 161 579 minecraft:purple_terracotta
fill 376 156 585 376 157 586 minecraft:purple_concrete
fill 376 156 587 376 161 588 minecraft:purple_terracotta
fill 376 156 597 376 156 598 minecraft:purple_concrete
fill 376 156 599 377 161 599 minecraft:purple_terracotta
fill 377 156 558 379 156 558 minecraft:obsidian
fill 377 156 560 377 156 562 minecraft:obsidian
fill 377 156 564 377 156 566 minecraft:obsidian
fill 377 156 568 377 156 570 minecraft:obsidian
fill 377 156 572 377 156 574 minecraft:obsidian
fill 377 156 576 377 156 578 minecraft:obsidian
fill 377 156 580 377 156 582 minecraft:obsidian
fill 377 156 584 377 156 586 minecraft:obsidian
fill 377 156 588 377 156 590 minecraft:obsidian
fill 377 156 592 377 156 594 minecraft:obsidian
fill 377 156 596 377 156 598 minecraft:obsidian
setblock 379 156 560 minecraft:light[level=12]
setblock 379 156 568 minecraft:light[level=12]
setblock 379 156 576 minecraft:light[level=12]
setblock 379 156 584 minecraft:light[level=12]
setblock 379 156 592 minecraft:light[level=12]
fill 379 156 598 381 156 598 minecraft:obsidian
setblock 380 156 557 minecraft:purple_concrete
fill 381 156 557 382 161 557 minecraft:purple_terracotta
fill 381 156 558 383 156 558 minecraft:obsidian
fill 381 156 574 381 161 575 minecraft:purple_concrete
fill 382 156 575 383 162 575 minecraft:purple_concrete
fill 383 156 557 384 157 557 minecraft:purple_concrete
fill 383 156 568 386 156 568 minecraft:black_concrete
fill 383 156 598 385 156 598 minecraft:obsidian
fill 383 156 599 383 157 599 minecraft:purple_concrete
fill 384 156 599 385 161 599 minecraft:purple_terracotta
fill 385 156 558 387 156 558 minecraft:obsidian
setblock 386 156 599 minecraft:purple_concrete
setblock 387 156 560 minecraft:light[level=12]
setblock 387 156 568 minecraft:light[level=12]
setblock 387 156 576 minecraft:light[level=12]
setblock 387 156 584 minecraft:light[level=12]
setblock 387 156 592 minecraft:light[level=12]
fill 387 156 598 389 156 598 minecraft:obsidian
fill 388 156 599 388 161 599 minecraft:purple_terracotta
fill 389 156 557 390 161 557 minecraft:purple_terracotta
fill 389 156 558 391 156 558 minecraft:obsidian
fill 391 156 557 392 156 557 minecraft:purple_concrete
fill 391 156 598 393 156 598 minecraft:obsidian
fill 393 156 557 393 161 557 minecraft:purple_terracotta
fill 393 156 558 395 156 558 minecraft:obsidian
fill 394 156 599 395 157 599 minecraft:purple_concrete
setblock 395 156 560 minecraft:light[level=12]
setblock 395 156 568 minecraft:light[level=12]
setblock 395 156 576 minecraft:light[level=12]
setblock 395 156 584 minecraft:light[level=12]
setblock 395 156 592 minecraft:light[level=12]
fill 395 156 598 397 156 598 minecraft:obsidian
fill 396 156 599 397 161 599 minecraft:purple_terracotta
fill 397 156 558 399 156 558 minecraft:obsidian
fill 399 156 598 401 156 598 minecraft:obsidian
fill 401 156 557 402 161 557 minecraft:purple_terracotta
fill 401 156 558 403 156 558 minecraft:obsidian
fill 403 156 557 404 157 557 minecraft:purple_concrete
setblock 403 156 560 minecraft:light[level=12]
setblock 403 156 568 minecraft:light[level=12]
setblock 403 156 576 minecraft:light[level=12]
setblock 403 156 584 minecraft:light[level=12]
setblock 403 156 592 minecraft:light[level=12]
fill 403 156 598 405 156 598 minecraft:obsidian
fill 405 156 558 407 156 558 minecraft:obsidian
fill 405 156 599 405 161 599 minecraft:purple_terracotta
fill 406 156 599 407 156 599 minecraft:purple_concrete
fill 407 156 598 409 156 598 minecraft:obsidian
fill 408 156 599 409 161 599 minecraft:purple_terracotta
fill 409 156 558 411 156 558 minecraft:obsidian
fill 410 156 557 410 161 557 minecraft:purple_terracotta
setblock 411 156 560 minecraft:light[level=12]
setblock 411 156 568 minecraft:light[level=12]
setblock 411 156 576 minecraft:light[level=12]
setblock 411 156 584 minecraft:light[level=12]
setblock 411 156 592 minecraft:light[level=12]
fill 411 156 598 413 156 598 minecraft:obsidian
setblock 412 156 557 minecraft:purple_concrete
fill 413 156 557 414 161 557 minecraft:purple_terracotta
fill 413 156 558 415 156 558 minecraft:obsidian
fill 414 156 599 415 157 599 minecraft:purple_concrete
fill 415 156 557 415 157 557 minecraft:purple_concrete
fill 415 156 598 417 156 598 minecraft:obsidian
fill 416 156 599 417 161 599 minecraft:purple_terracotta
fill 417 156 558 417 156 560 minecraft:obsidian
fill 417 156 562 417 156 564 minecraft:obsidian
fill 417 156 566 417 156 568 minecraft:obsidian
fill 417 156 570 417 156 572 minecraft:obsidian
fill 417 156 574 417 156 576 minecraft:obsidian
fill 417 156 578 417 156 580 minecraft:obsidian
fill 417 156 582 417 156 584 minecraft:obsidian
fill 417 156 586 417 156 588 minecraft:obsidian
fill 417 156 590 417 156 592 minecraft:obsidian
fill 417 156 594 417 156 596 minecraft:obsidian
fill 418 156 560 418 161 561 minecraft:purple_terracotta
fill 418 156 562 418 156 563 minecraft:purple_concrete
fill 418 156 572 418 161 573 minecraft:purple_terracotta
fill 418 156 574 418 157 575 minecraft:purple_concrete
fill 418 156 581 418 161 581 minecraft:purple_terracotta
fill 418 156 582 418 156 583 minecraft:purple_concrete
fill 418 156 584 418 161 584 minecraft:purple_terracotta
fill 418 156 586 418 157 586 minecraft:purple_concrete
fill 418 156 592 418 161 593 minecraft:purple_terracotta
fill 418 156 594 418 157 595 minecraft:purple_concrete
setblock 418 156 599 minecraft:purple_concrete
fill 376 157 557 376 160 557 minecraft:purple_terracotta
fill 376 157 561 376 159 561 minecraft:purple_terracotta
setblock 376 157 562 minecraft:purple_concrete
setblock 376 157 573 minecraft:purple_concrete
fill 376 157 577 376 160 578 minecraft:purple_terracotta
setblock 376 157 594 minecraft:purple_concrete
setblock 376 157 597 minecraft:purple_concrete
fill 376 157 598 376 160 598 minecraft:purple_terracotta
fill 380 157 557 380 159 557 minecraft:purple_terracotta
fill 380 157 572 380 158 575 minecraft:purple_concrete
fill 381 157 576 383 162 576 minecraft:purple_concrete
setblock 382 157 599 minecraft:purple_concrete
fill 384 157 575 384 161 575 minecraft:purple_concrete
setblock 385 157 569 minecraft:black_concrete
fill 385 157 574 385 158 574 minecraft:purple_concrete
fill 386 157 599 386 160 599 minecraft:purple_terracotta
fill 391 157 557 391 160 557 minecraft:purple_terracotta
setblock 392 157 557 minecraft:purple_concrete
fill 395 157 557 396 157 557 minecraft:purple_concrete
fill 402 157 599 403 157 599 minecraft:purple_concrete
setblock 406 157 599 minecraft:purple_concrete
fill 407 157 599 407 160 599 minecraft:purple_terracotta
fill 412 157 557 412 160 557 minecraft:purple_terracotta
setblock 416 157 557 minecraft:purple_concrete
fill 418 157 562 418 160 562 minecraft:purple_terracotta
setblock 418 157 563 minecraft:purple_concrete
setblock 418 157 566 minecraft:purple_concrete
fill 418 157 582 418 160 583 minecraft:purple_terracotta
setblock 418 157 587 minecraft:purple_concrete
setblock 418 157 598 minecraft:purple_concrete
fill 418 157 599 418 160 599 minecraft:purple_terracotta
fill 376 158 562 376 159 562 minecraft:purple_terracotta
fill 376 158 563 376 158 564 minecraft:purple_concrete
fill 376 158 565 376 163 566 minecraft:purple_terracotta
fill 376 158 571 376 159 572 minecraft:purple_concrete
fill 376 158 573 376 163 574 minecraft:purple_terracotta
setblock 376 158 575 minecraft:purple_concrete
fill 376 158 583 376 159 584 minecraft:purple_concrete
fill 376 158 585 376 163 586 minecraft:purple_terracotta
fill 376 158 592 376 159 592 minecraft:purple_concrete
fill 376 158 594 376 163 594 minecraft:purple_terracotta
fill 376 158 595 376 158 596 minecraft:purple_concrete
fill 376 158 597 376 163 597 minecraft:purple_terracotta
fill 377 158 557 377 159 557 minecraft:purple_concrete
setblock 378 158 557 minecraft:purple_terracotta
fill 380 158 576 380 162 577 minecraft:purple_concrete
fill 380 158 599 381 159 599 minecraft:purple_concrete
fill 381 158 577 382 160 578 minecraft:purple_concrete
fill 382 158 570 384 158 570 minecraft:purple_concrete
fill 382 158 599 383 163 599 minecraft:purple_terracotta
fill 383 158 557 384 163 557 minecraft:purple_terracotta
fill 383 158 577 383 163 577 minecraft:purple_concrete
fill 384 158 576 384 161 576 minecraft:purple_concrete
fill 385 158 557 386 159 557 minecraft:purple_concrete
fill 392 158 557 392 163 557 minecraft:purple_terracotta
fill 392 158 599 393 158 599 minecraft:purple_concrete
setblock 394 158 557 minecraft:purple_concrete
fill 394 158 599 395 163 599 minecraft:purple_terracotta
fill 395 158 557 396 163 557 minecraft:purple_terracotta
fill 397 158 557 397 159 557 minecraft:purple_concrete
fill 401 158 599 401 159 599 minecraft:purple_concrete
fill 402 158 599 403 163 599 minecraft:purple_terracotta
fill 403 158 557 404 163 557 minecraft:purple_terracotta
setblock 404 158 599 minecraft:purple_concrete
fill 405 158 557 406 158 557 minecraft:purple_concrete
fill 406 158 599 406 163 599 minecraft:purple_terracotta
fill 412 158 599 413 159 599 minecraft:purple_concrete
fill 414 158 599 415 163 599 minecraft:purple_terracotta
fill 415 158 557 416 163 557 minecraft:purple_terracotta
fill 417 158 557 418 159 557 minecraft:purple_concrete
fill 418 158 563 418 163 563 minecraft:purple_terracotta
fill 418 158 564 418 158 565 minecraft:purple_concrete
fill 418 158 566 418 163 566 minecraft:purple_terracotta
fill 418 158 568 418 159 568 minecraft:purple_concrete
fill 418 158 574 418 163 575 minecraft:purple_terracotta
fill 418 158 576 418 159 577 minecraft:purple_concrete
setblock 418 158 585 minecraft:purple_concrete
fill 418 158 586 418 163 587 minecraft:purple_terracotta
fill 418 158 588 418 159 589 minecraft:purple_concrete
fill 418 158 594 418 163 595 minecraft:purple_terracotta
fill 418 158 596 418 158 597 minecraft:purple_concrete
fill 418 158 598 418 163 598 minecraft:purple_terracotta
fill 376 159 559 376 159 560 minecraft:purple_concrete
setblock 376 159 563 minecraft:purple_concrete
fill 376 159 564 376 162 564 minecraft:purple_terracotta
fill 376 159 575 376 162 575 minecraft:purple_terracotta
setblock 376 159 580 minecraft:purple_concrete
setblock 376 159 591 minecraft:purple_concrete
fill 376 159 595 376 162 596 minecraft:purple_terracotta
setblock 378 159 557 minecraft:purple_concrete
fill 379 159 575 380 159 575 minecraft:purple_concrete
fill 380 159 573 380 159 574 minecraft:purple_concrete
fill 380 159 578 380 161 578 minecraft:purple_concrete
fill 381 159 579 382 160 579 minecraft:purple_concrete
fill 381 159 580 383 159 580 minecraft:amethyst_block
fill 382 159 571 382 159 572 minecraft:purple_concrete
fill 383 159 572 384 159 572 minecraft:purple_concrete
fill 383 159 578 383 161 578 minecraft:purple_concrete
setblock 383 159 579 minecraft:amethyst_block
fill 384 159 565 385 160 566 minecraft:amethyst_block
fill 384 159 571 384 162 571 minecraft:amethyst_block
fill 384 159 577 384 162 577 minecraft:purple_concrete
fill 388 159 592 388 160 593 minecraft:obsidian
setblock 389 159 599 minecraft:purple_concrete
setblock 392 159 599 minecraft:purple_concrete
fill 393 159 599 393 162 599 minecraft:purple_terracotta
fill 394 159 557 394 162 557 minecraft:purple_terracotta
setblock 398 159 557 minecraft:purple_concrete
setblock 400 159 599 minecraft:purple_concrete
fill 404 159 599 404 162 599 minecraft:purple_terracotta
fill 405 159 557 405 162 557 minecraft:purple_terracotta
setblock 406 159 557 minecraft:purple_concrete
setblock 409 159 557 minecraft:purple_concrete
fill 418 159 564 418 162 565 minecraft:purple_terracotta
setblock 418 159 569 minecraft:purple_concrete
setblock 418 159 580 minecraft:purple_concrete
fill 418 159 585 418 162 585 minecraft:purple_terracotta
fill 418 159 596 418 162 596 minecraft:purple_terracotta
setblock 418 159 597 minecraft:purple_concrete
fill 376 160 558 376 161 558 minecraft:purple_concrete
fill 376 160 559 376 161 560 minecraft:purple_terracotta
fill 376 160 561 376 160 562 minecraft:purple_concrete
fill 376 160 563 376 165 563 minecraft:purple_terracotta
fill 376 160 569 376 161 570 minecraft:purple_concrete
fill 376 160 571 376 165 572 minecraft:purple_terracotta
fill 376 160 580 376 165 580 minecraft:purple_terracotta
fill 376 160 581 376 160 582 minecraft:purple_concrete
fill 376 160 583 376 165 584 minecraft:purple_terracotta
fill 376 160 589 376 161 590 minecraft:purple_concrete
fill 376 160 591 376 165 592 minecraft:purple_terracotta
setblock 376 160 593 minecraft:purple_concrete
fill 377 160 557 378 165 557 minecraft:purple_terracotta
fill 378 160 599 379 161 599 minecraft:purple_concrete
fill 379 160 557 380 161 557 minecraft:purple_concrete
fill 379 160 576 379 160 577 minecraft:purple_concrete
fill 380 160 574 380 161 575 minecraft:purple_concrete
setblock 380 160 579 minecraft:purple_concrete
fill 380 160 599 381 165 599 minecraft:purple_terracotta
setblock 381 160 573 minecraft:purple_concrete
fill 381 160 580 383 160 580 minecraft:purple_concrete
fill 382 160 572 383 160 572 minecraft:purple_concrete
fill 383 160 571 383 162 571 minecraft:amethyst_block
setblock 383 160 579 minecraft:purple_concrete
fill 384 160 578 384 163 578 minecraft:purple_concrete
fill 385 160 557 386 165 557 minecraft:purple_terracotta
fill 387 160 557 388 160 557 minecraft:purple_concrete
fill 387 160 599 387 161 599 minecraft:purple_concrete
fill 389 160 599 389 165 599 minecraft:purple_terracotta
fill 390 160 599 391 160 599 minecraft:purple_concrete
fill 392 160 599 392 165 599 minecraft:purple_terracotta
fill 397 160 557 398 165 557 minecraft:purple_terracotta
fill 398 160 599 399 161 599 minecraft:purple_concrete
fill 399 160 557 400 161 557 minecraft:purple_concrete
fill 400 160 599 401 165 599 minecraft:purple_terracotta
fill 406 160 557 406 165 557 minecraft:purple_terracotta
fill 407 160 557 408 160 557 minecraft:purple_concrete
fill 409 160 557 409 165 557 minecraft:purple_terracotta
fill 410 160 599 411 160 599 minecraft:purple_concrete
fill 411 160 557 411 161 557 minecraft:purple_concrete
fill 412 160 599 413 165 599 minecraft:purple_terracotta
fill 417 160 557 418 165 557 minecraft:purple_terracotta
fill 418 160 558 418 161 559 minecraft:purple_concrete
setblock 418 160 567 minecraft:purple_concrete
fill 418 160 568 418 165 569 minecraft:purple_terracotta
fill 418 160 570 418 161 571 minecraft:purple_concrete
fill 418 160 576 418 165 577 minecraft:purple_terracotta
fill 418 160 578 418 160 579 minecraft:purple_concrete
fill 418 160 580 418 165 580 minecraft:purple_terracotta
fill 418 160 588 418 165 589 minecraft:purple_terracotta
fill 418 160 590 418 161 591 minecraft:purple_concrete
fill 418 160 597 418 165 597 minecraft:purple_terracotta
setblock 376 161 557 minecraft:purple_concrete
fill 376 161 561 376 163 562 minecraft:purple_terracotta
fill 376 161 577 376 161 578 minecraft:purple_concrete
setblock 376 161 581 minecraft:purple_concrete
fill 376 161 582 376 164 582 minecraft:purple_terracotta
fill 376 161 593 376 164 593 minecraft:purple_terracotta
setblock 376 161 598 minecraft:purple_concrete
fill 379 161 577 379 161 578 minecraft:purple_concrete
fill 380 161 579 383 164 581 minecraft:black_concrete
fill 381 161 577 382 164 577 minecraft:purple_concrete
fill 381 161 578 382 164 578 minecraft:black_concrete
fill 382 161 582 382 165 582 minecraft:black_concrete
setblock 383 161 574 minecraft:purple_concrete
setblock 384 161 579 minecraft:purple_concrete
setblock 386 161 599 minecraft:purple_concrete
fill 387 161 557 387 164 557 minecraft:purple_terracotta
setblock 388 161 557 minecraft:purple_concrete
fill 390 161 599 391 164 599 minecraft:purple_terracotta
setblock 391 161 557 minecraft:purple_concrete
fill 407 161 557 408 164 557 minecraft:purple_terracotta
setblock 407 161 599 minecraft:purple_concrete
setblock 410 161 599 minecraft:purple_concrete
fill 411 161 599 411 164 599 minecraft:purple_terracotta
setblock 412 161 557 minecraft:purple_concrete
setblock 418 161 562 minecraft:purple_concrete
fill 418 161 567 418 164 567 minecraft:purple_terracotta
fill 418 161 578 418 164 578 minecraft:purple_terracotta
setblock 418 161 579 minecraft:purple_concrete
fill 418 161 582 418 161 583 minecraft:purple_concrete
setblock 418 161 599 minecraft:purple_concrete
fill 376 162 557 376 167 558 minecraft:purple_terracotta
setblock 376 162 559 minecraft:purple_concrete
fill 376 162 560 376 165 560 minecraft:purple_terracotta
fill 376 162 567 376 162 568 minecraft:purple_concrete
fill 376 162 569 376 167 570 minecraft:purple_terracotta
fill 376 162 576 376 163 576 minecraft:purple_concrete
fill 376 162 577 376 167 578 minecraft:purple_terracotta
setblock 376 162 579 minecraft:purple_concrete
fill 376 162 581 376 167 581 minecraft:purple_terracotta
fill 376 162 587 376 163 588 minecraft:purple_concrete
fill 376 162 589 376 167 590 minecraft:purple_terracotta
fill 376 162 598 376 167 598 minecraft:purple_terracotta
fill 376 162 599 377 162 599 minecraft:purple_concrete
fill 377 162 558 379 162 558 minecraft:obsidian
fill 377 162 560 377 162 562 minecraft:obsidian
fill 377 162 564 377 162 566 minecraft:obsidian
fill 377 162 568 377 162 570 minecraft:obsidian
fill 377 162 572 377 162 574 minecraft:obsidian
fill 377 162 576 377 162 578 minecraft:obsidian
fill 377 162 580 377 162 582 minecraft:obsidian
fill 377 162 584 377 162 586 minecraft:obsidian
fill 377 162 588 377 162 590 minecraft:obsidian
fill 377 162 592 377 162 594 minecraft:obsidian
fill 377 162 596 377 162 598 minecraft:obsidian
fill 378 162 599 379 167 599 minecraft:purple_terracotta
fill 379 162 557 380 167 557 minecraft:purple_terracotta
fill 379 162 578 379 162 579 minecraft:purple_concrete
fill 379 162 580 379 163 580 minecraft:black_concrete
fill 379 162 598 381 162 598 minecraft:obsidian
fill 380 162 578 380 164 578 minecraft:black_concrete
fill 380 162 582 381 166 582 minecraft:black_concrete
fill 381 162 557 382 163 557 minecraft:purple_concrete
fill 381 162 558 383 162 558 minecraft:obsidian
setblock 381 162 575 minecraft:purple_concrete
fill 382 162 583 383 164 583 minecraft:black_concrete
fill 383 162 578 383 164 578 minecraft:black_concrete
fill 383 162 582 383 165 582 minecraft:black_concrete
fill 383 162 598 385 162 598 minecraft:obsidian
fill 384 162 579 384 164 581 minecraft:black_concrete
fill 384 162 599 385 163 599 minecraft:purple_concrete
fill 385 162 558 387 162 558 minecraft:obsidian
fill 386 162 599 387 167 599 minecraft:purple_terracotta
fill 387 162 598 389 162 598 minecraft:obsidian
fill 388 162 557 388 167 557 minecraft:purple_terracotta
setblock 388 162 599 minecraft:purple_concrete
fill 389 162 557 390 162 557 minecraft:purple_concrete
fill 389 162 558 391 162 558 minecraft:obsidian
fill 391 162 557 391 167 557 minecraft:purple_terracotta
fill 391 162 598 393 162 598 minecraft:obsidian
fill 393 162 557 393 163 557 minecraft:purple_concrete
fill 393 162 558 395 162 558 minecraft:obsidian
fill 395 162 598 397 162 598 minecraft:obsidian
fill 396 162 599 397 163 599 minecraft:purple_concrete
fill 397 162 558 399 162 558 minecraft:obsidian
fill 398 162 599 399 167 599 minecraft:purple_terracotta
fill 399 162 557 400 167 557 minecraft:purple_terracotta
fill 399 162 598 401 162 598 minecraft:obsidian
fill 401 162 557 402 163 557 minecraft:purple_concrete
fill 401 162 558 403 162 558 minecraft:obsidian
fill 403 162 598 405 162 598 minecraft:obsidian
fill 405 162 558 407 162 558 minecraft:obsidian
fill 405 162 599 405 163 599 minecraft:purple_concrete
fill 407 162 598 409 162 598 minecraft:obsidian
fill 407 162 599 407 167 599 minecraft:purple_terracotta
fill 408 162 599 409 162 599 minecraft:purple_concrete
fill 409 162 558 411 162 558 minecraft:obsidian
setblock 410 162 557 minecraft:purple_concrete
fill 410 162 599 410 167 599 minecraft:purple_terracotta
fill 411 162 557 412 167 557 minecraft:purple_terracotta
fill 411 162 598 413 162 598 minecraft:obsidian
fill 413 162 557 414 163 557 minecraft:purple_concrete
fill 413 162 558 415 162 558 minecraft:obsidian
fill 415 162 598 417 162 598 minecraft:obsidian
fill 416 162 599 417 163 599 minecraft:purple_concrete
fill 417 162 558 417 162 560 minecraft:obsidian
fill 417 162 562 417 162 564 minecraft:obsidian
fill 417 162 566 417 162 568 minecraft:obsidian
fill 417 162 570 417 162 572 minecraft:obsidian
fill 417 162 574 417 162 576 minecraft:obsidian
fill 417 162 578 417 162 580 minecraft:obsidian
fill 417 162 582 417 162 584 minecraft:obsidian
fill 417 162 586 417 162 588 minecraft:obsidian
fill 417 162 590 417 162 592 minecraft:obsidian
fill 417 162 594 417 162 596 minecraft:obsidian
fill 418 162 558 418 167 559 minecraft:purple_terracotta
fill 418 162 560 418 162 561 minecraft:purple_concrete
fill 418 162 562 418 167 562 minecraft:purple_terracotta
fill 418 162 570 418 167 571 minecraft:purple_terracotta
fill 418 162 572 418 163 573 minecraft:purple_concrete
fill 418 162 579 418 167 579 minecraft:purple_terracotta
setblock 418 162 581 minecraft:purple_concrete
fill 418 162 582 418 167 583 minecraft:purple_terracotta
fill 418 162 584 418 163 584 minecraft:purple_concrete
fill 418 162 590 418 167 591 minecraft:purple_terracotta
fill 418 162 592 418 162 593 minecraft:purple_concrete
fill 418 162 599 418 167 599 minecraft:purple_terracotta
fill 376 163 559 376 165 559 minecraft:purple_terracotta
setblock 376 163 564 minecraft:purple_concrete
setblock 376 163 567 minecraft:purple_concrete
fill 376 163 568 376 166 568 minecraft:purple_terracotta
setblock 376 163 575 minecraft:purple_concrete
fill 376 163 579 376 166 579 minecraft:purple_terracotta
fill 376 163 595 376 163 596 minecraft:purple_concrete
setblock 376 163 599 minecraft:purple_concrete
fill 377 163 599 377 166 599 minecraft:purple_terracotta
setblock 379 163 579 minecraft:black_concrete
setblock 380 163 577 minecraft:purple_concrete
fill 381 163 576 382 163 576 minecraft:purple_concrete
fill 381 163 583 381 164 584 minecraft:black_concrete
fill 382 163 584 383 163 584 minecraft:black_concrete
fill 384 163 582 384 164 583 minecraft:black_concrete
fill 388 163 599 388 166 599 minecraft:purple_terracotta
fill 389 163 557 390 165 557 minecraft:purple_terracotta
setblock 393 163 599 minecraft:purple_concrete
setblock 394 163 557 minecraft:purple_concrete
setblock 404 163 599 minecraft:purple_concrete
setblock 405 163 557 minecraft:purple_concrete
fill 407 163 582 407 164 582 minecraft:amethyst_block
fill 408 163 599 409 166 599 minecraft:purple_terracotta
fill 410 163 557 410 166 557 minecraft:purple_terracotta
fill 418 163 560 418 166 560 minecraft:purple_terracotta
setblock 418 163 561 minecraft:purple_concrete
fill 418 163 564 418 163 565 minecraft:purple_concrete
fill 418 163 581 418 166 581 minecraft:purple_terracotta
setblock 418 163 585 minecraft:purple_concrete
fill 418 163 592 418 166 592 minecraft:purple_terracotta
setblock 418 163 593 minecraft:purple_concrete
setblock 418 163 596 minecraft:purple_concrete
setblock 376 164 561 minecraft:purple_terracotta
fill 376 164 562 376 165 562 minecraft:purple_concrete
fill 376 164 564 376 169 564 minecraft:purple_terracotta
fill 376 164 565 376 164 566 minecraft:purple_concrete
fill 376 164 567 376 169 567 minecraft:purple_terracotta
fill 376 164 573 376 165 574 minecraft:purple_concrete
fill 376 164 575 376 169 576 minecraft:purple_terracotta
fill 376 164 585 376 164 586 minecraft:purple_concrete
fill 376 164 587 376 169 588 minecraft:purple_terracotta
fill 376 164 594 376 165 594 minecraft:purple_concrete
fill 376 164 595 376 169 596 minecraft:purple_terracotta
setblock 376 164 597 minecraft:purple_concrete
fill 376 164 599 376 169 599 minecraft:purple_terracotta
setblock 379 164 560 minecraft:light[level=12]
setblock 379 164 568 minecraft:light[level=12]
setblock 379 164 576 minecraft:light[level=12]
setblock 379 164 584 minecraft:light[level=12]
setblock 379 164 592 minecraft:light[level=12]
fill 380 164 583 380 166 583 minecraft:black_concrete
fill 381 164 557 382 169 557 minecraft:purple_terracotta
fill 382 164 584 383 169 585 minecraft:purple_concrete
fill 382 164 599 383 165 599 minecraft:purple_concrete
fill 383 164 557 384 165 557 minecraft:purple_concrete
fill 384 164 584 384 169 584 minecraft:purple_concrete
setblock 384 164 585 minecraft:black_concrete
fill 384 164 599 385 169 599 minecraft:purple_terracotta
setblock 387 164 560 minecraft:light[level=12]
setblock 387 164 568 minecraft:light[level=12]
setblock 387 164 576 minecraft:light[level=12]
setblock 387 164 584 minecraft:light[level=12]
setblock 387 164 592 minecraft:light[level=12]
setblock 392 164 557 minecraft:purple_concrete
fill 393 164 557 394 169 557 minecraft:purple_terracotta
fill 393 164 599 393 169 599 minecraft:purple_terracotta
fill 394 164 599 395 164 599 minecraft:purple_concrete
fill 395 164 557 396 165 557 minecraft:purple_concrete
setblock 395 164 560 minecraft:light[level=12]
setblock 395 164 568 minecraft:light[level=12]
setblock 395 164 576 minecraft:light[level=12]
setblock 395 164 584 minecraft:light[level=12]
setblock 395 164 592 minecraft:light[level=12]
fill 396 164 599 397 169 599 minecraft:purple_terracotta
fill 401 164 557 402 169 557 minecraft:purple_terracotta
fill 402 164 599 403 165 599 minecraft:purple_concrete
fill 403 164 557 404 164 557 minecraft:purple_concrete
setblock 403 164 560 minecraft:light[level=12]
setblock 403 164 568 minecraft:light[level=12]
setblock 403 164 576 minecraft:light[level=12]
setblock 403 164 584 minecraft:light[level=12]
setblock 403 164 592 minecraft:light[level=12]
fill 404 164 599 405 169 599 minecraft:purple_terracotta
fill 405 164 557 405 169 557 minecraft:purple_terracotta
setblock 406 164 599 minecraft:purple_concrete
setblock 411 164 560 minecraft:light[level=12]
setblock 411 164 568 minecraft:light[level=12]
setblock 411 164 576 minecraft:light[level=12]
setblock 411 164 584 minecraft:light[level=12]
setblock 411 164 592 minecraft:light[level=12]
fill 413 164 557 414 169 557 minecraft:purple_terracotta
fill 414 164 599 415 165 599 minecraft:purple_concrete
fill 415 164 557 416 165 557 minecraft:purple_concrete
fill 416 164 599 417 169 599 minecraft:purple_terracotta
fill 418 164 561 418 169 561 minecraft:purple_terracotta
setblock 418 164 563 minecraft:purple_concrete
fill 418 164 564 418 169 565 minecraft:purple_terracotta
fill 418 164 566 418 165 566 minecraft:purple_concrete
fill 418 164 572 418 169 573 minecraft:purple_terracotta
fill 418 164 574 418 164 575 minecraft:purple_concrete
fill 418 164 584 418 169 585 minecraft:purple_terracotta
fill 418 164 586 418 165 587 minecraft:purple_concrete
fill 418 164 593 418 169 593 minecraft:purple_terracotta
fill 418 164 594 418 164 595 minecraft:purple_concrete
fill 418 164 596 418 169 596 minecraft:purple_terracotta
fill 418 164 598 418 165 598 minecraft:purple_concrete
setblock 376 165 561 minecraft:purple_concrete
fill 376 165 565 376 168 566 minecraft:purple_terracotta
setblock 376 165 582 minecraft:purple_concrete
setblock 376 165 585 minecraft:purple_concrete
fill 376 165 586 376 168 586 minecraft:purple_terracotta
setblock 376 165 593 minecraft:purple_concrete
fill 376 165 597 376 168 597 minecraft:purple_terracotta
fill 380 165 580 384 165 581 minecraft:black_concrete
fill 380 165 584 380 166 584 minecraft:black_concrete
fill 381 165 579 383 165 579 minecraft:black_concrete
fill 381 165 583 381 168 585 minecraft:purple_concrete
fill 382 165 583 384 168 583 minecraft:purple_concrete
fill 382 165 586 384 170 586 minecraft:purple_concrete
fill 384 165 582 385 165 582 minecraft:black_concrete
fill 384 165 585 385 170 585 minecraft:purple_concrete
setblock 385 165 583 minecraft:black_concrete
fill 385 165 584 385 169 584 minecraft:purple_concrete
setblock 387 165 557 minecraft:purple_concrete
fill 390 165 599 391 165 599 minecraft:purple_concrete
fill 392 165 557 392 167 557 minecraft:purple_terracotta
setblock 394 165 599 minecraft:purple_concrete
fill 395 165 599 395 168 599 minecraft:purple_terracotta
fill 403 165 557 403 168 557 minecraft:purple_terracotta
setblock 404 165 557 minecraft:purple_concrete
fill 406 165 585 407 166 585 minecraft:obsidian
fill 406 165 599 406 168 599 minecraft:purple_terracotta
fill 407 165 557 408 165 557 minecraft:purple_concrete
setblock 411 165 599 minecraft:purple_concrete
fill 418 165 563 418 168 563 minecraft:purple_terracotta
setblock 418 165 567 minecraft:purple_concrete
fill 418 165 574 418 168 574 minecraft:purple_terracotta
setblock 418 165 575 minecraft:purple_concrete
setblock 418 165 578 minecraft:purple_concrete
fill 418 165 594 418 168 595 minecraft:purple_terracotta
fill 376 166 559 376 167 560 minecraft:purple_concrete
fill 376 166 561 376 171 562 minecraft:purple_terracotta
setblock 376 166 563 minecraft:purple_concrete
fill 376 166 571 376 167 572 minecraft:purple_concrete
fill 376 166 573 376 171 574 minecraft:purple_terracotta
fill 376 166 580 376 167 580 minecraft:purple_concrete
fill 376 166 582 376 171 582 minecraft:purple_terracotta
fill 376 166 583 376 166 584 minecraft:purple_concrete
fill 376 166 585 376 171 585 minecraft:purple_terracotta
fill 376 166 591 376 167 592 minecraft:purple_concrete
fill 376 166 593 376 171 594 minecraft:purple_terracotta
fill 377 166 557 378 167 557 minecraft:purple_concrete
fill 380 166 581 384 166 581 minecraft:black_concrete
fill 380 166 599 381 166 599 minecraft:purple_concrete
fill 381 166 580 383 166 580 minecraft:black_concrete
fill 381 166 586 381 168 586 minecraft:purple_concrete
fill 382 166 582 384 167 582 minecraft:purple_concrete
fill 382 166 587 385 170 587 minecraft:purple_concrete
fill 382 166 599 383 171 599 minecraft:purple_terracotta
fill 383 166 557 384 168 557 minecraft:purple_terracotta
fill 385 166 557 386 166 557 minecraft:purple_concrete
setblock 385 166 582 minecraft:black_concrete
fill 385 166 583 385 167 583 minecraft:purple_concrete
fill 385 166 586 385 171 586 minecraft:purple_concrete
fill 387 166 557 387 171 557 minecraft:purple_terracotta
fill 389 166 557 389 167 557 minecraft:purple_concrete
fill 389 166 599 389 167 599 minecraft:purple_concrete
setblock 390 166 557 minecraft:purple_terracotta
fill 390 166 599 391 171 599 minecraft:purple_terracotta
setblock 392 166 599 minecraft:purple_concrete
fill 394 166 599 394 171 599 minecraft:purple_terracotta
fill 395 166 557 396 171 557 minecraft:purple_terracotta
fill 397 166 557 398 167 557 minecraft:purple_concrete
fill 400 166 599 401 167 599 minecraft:purple_concrete
fill 402 166 599 403 171 599 minecraft:purple_terracotta
fill 404 166 557 404 171 557 minecraft:purple_terracotta
setblock 406 166 557 minecraft:purple_concrete
fill 407 166 557 408 171 557 minecraft:purple_terracotta
fill 409 166 557 409 167 557 minecraft:purple_concrete
fill 411 166 599 411 171 599 minecraft:purple_terracotta
fill 412 166 599 413 166 599 minecraft:purple_concrete
fill 414 166 599 415 171 599 minecraft:purple_terracotta
fill 415 166 557 416 171 557 minecraft:purple_terracotta
fill 417 166 557 418 166 557 minecraft:purple_concrete
fill 418 166 566 418 171 567 minecraft:purple_terracotta
fill 418 166 568 418 167 569 minecraft:purple_concrete
fill 418 166 575 418 171 575 minecraft:purple_terracotta
fill 418 166 576 418 166 577 minecraft:purple_concrete
fill 418 166 578 418 171 578 minecraft:purple_terracotta
fill 418 166 580 418 167 580 minecraft:purple_concrete
fill 418 166 586 418 171 587 minecraft:purple_terracotta
fill 418 166 588 418 167 589 minecraft:purple_concrete
setblock 418 166 597 minecraft:purple_concrete
fill 418 166 598 418 171 598 minecraft:purple_terracotta
fill 376 167 563 376 170 563 minecraft:purple_terracotta
setblock 376 167 568 minecraft:purple_concrete
setblock 376 167 579 minecraft:purple_concrete
fill 376 167 583 376 170 584 minecraft:purple_terracotta
setblock 377 167 599 minecraft:purple_concrete
setblock 380 167 599 minecraft:purple_concrete
setblock 381 167 582 minecraft:black_concrete
fill 381 167 599 381 170 599 minecraft:purple_terracotta
fill 382 167 581 383 167 581 minecraft:black_concrete
fill 383 167 588 386 171 588 minecraft:purple_concrete
fill 385 167 557 385 170 557 minecraft:purple_terracotta
fill 385 167 589 385 173 589 minecraft:purple_concrete
setblock 386 167 557 minecraft:purple_concrete
fill 386 167 585 386 170 587 minecraft:purple_concrete
setblock 388 167 599 minecraft:purple_concrete
setblock 390 167 557 minecraft:purple_concrete
fill 392 167 599 392 170 599 minecraft:purple_terracotta
fill 406 167 557 406 170 557 minecraft:purple_terracotta
fill 408 167 599 409 167 599 minecraft:purple_concrete
setblock 410 167 557 minecraft:purple_concrete
setblock 412 167 599 minecraft:purple_concrete
fill 413 167 599 413 170 599 minecraft:purple_terracotta
fill 417 167 557 417 170 557 minecraft:purple_terracotta
setblock 418 167 557 minecraft:purple_concrete
setblock 418 167 560 minecraft:purple_concrete
fill 418 167 576 418 170 577 minecraft:purple_terracotta
setblock 418 167 581 minecraft:purple_concrete
setblock 418 167 592 minecraft:purple_concrete
fill 418 167 597 418 170 597 minecraft:purple_terracotta
fill 376 168 557 376 169 558 minecraft:purple_concrete
fill 376 168 559 376 173 560 minecraft:purple_terracotta
fill 376 168 568 376 173 568 minecraft:purple_terracotta
fill 376 168 569 376 168 570 minecraft:purple_concrete
fill 376 168 571 376 173 572 minecraft:purple_terracotta
fill 376 168 577 376 169 578 minecraft:purple_concrete
fill 376 168 579 376 173 580 minecraft:purple_terracotta
setblock 376 168 581 minecraft:purple_concrete
fill 376 168 589 376 169 590 minecraft:purple_concrete
fill 376 168 591 376 173 592 minecraft:purple_terracotta
fill 376 168 598 376 169 598 minecraft:purple_concrete
fill 377 168 557 378 173 557 minecraft:purple_terracotta
fill 377 168 558 379 168 558 minecraft:obsidian
fill 377 168 560 377 168 562 minecraft:obsidian
fill 377 168 564 377 168 566 minecraft:obsidian
fill 377 168 568 377 168 570 minecraft:obsidian
fill 377 168 572 377 168 574 minecraft:obsidian
fill 377 168 576 377 168 578 minecraft:obsidian
fill 377 168 580 377 168 582 minecraft:obsidian
fill 377 168 584 377 168 586 minecraft:obsidian
fill 377 168 588 377 168 590 minecraft:obsidian
fill 377 168 592 377 168 594 minecraft:obsidian
fill 377 168 596 377 168 598 minecraft:obsidian
fill 377 168 599 377 173 599 minecraft:purple_terracotta
fill 378 168 599 379 168 599 minecraft:purple_concrete
fill 379 168 557 380 169 557 minecraft:purple_concrete
fill 379 168 598 381 168 598 minecraft:obsidian
fill 380 168 599 380 173 599 minecraft:purple_terracotta
fill 381 168 558 383 168 558 minecraft:obsidian
fill 382 168 582 383 168 582 minecraft:black_concrete
fill 382 168 588 382 169 588 minecraft:purple_concrete
fill 383 168 589 384 171 589 minecraft:purple_concrete
fill 383 168 598 385 168 598 minecraft:obsidian
fill 385 168 558 387 168 558 minecraft:obsidian
fill 385 168 590 386 173 590 minecraft:purple_concrete
fill 386 168 557 386 170 557 minecraft:purple_terracotta
fill 386 168 589 387 174 589 minecraft:purple_concrete
fill 386 168 599 387 169 599 minecraft:purple_concrete
fill 387 168 571 388 169 572 minecraft:amethyst_block
fill 387 168 586 387 170 588 minecraft:purple_concrete
fill 387 168 598 389 168 598 minecraft:obsidian
setblock 388 168 557 minecraft:purple_concrete
fill 388 168 599 389 173 599 minecraft:purple_terracotta
fill 389 168 557 390 173 557 minecraft:purple_terracotta
fill 389 168 558 391 168 558 minecraft:obsidian
fill 391 168 557 392 169 557 minecraft:purple_concrete
fill 391 168 598 393 168 598 minecraft:obsidian
fill 393 168 558 395 168 558 minecraft:obsidian
fill 395 168 598 397 168 598 minecraft:obsidian
fill 397 168 557 398 173 557 minecraft:purple_terracotta
fill 397 168 558 399 168 558 minecraft:obsidian
fill 398 168 599 399 168 599 minecraft:purple_concrete
fill 399 168 557 400 168 557 minecraft:purple_concrete
fill 399 168 598 401 168 598 minecraft:obsidian
fill 400 168 599 401 173 599 minecraft:purple_terracotta
fill 401 168 558 403 168 558 minecraft:obsidian
fill 403 168 598 405 168 598 minecraft:obsidian
fill 405 168 558 407 168 558 minecraft:obsidian
fill 407 168 598 409 168 598 minecraft:obsidian
fill 407 168 599 407 169 599 minecraft:purple_concrete
fill 408 168 599 409 173 599 minecraft:purple_terracotta
fill 409 168 557 410 173 557 minecraft:purple_terracotta
fill 409 168 558 411 168 558 minecraft:obsidian
setblock 410 168 599 minecraft:purple_concrete
fill 411 168 557 412 169 557 minecraft:purple_concrete
fill 411 168 598 413 168 598 minecraft:obsidian
fill 412 168 599 412 173 599 minecraft:purple_terracotta
fill 413 168 558 415 168 558 minecraft:obsidian
fill 415 168 598 417 168 598 minecraft:obsidian
fill 417 168 558 417 168 560 minecraft:obsidian
fill 417 168 562 417 168 564 minecraft:obsidian
fill 417 168 566 417 168 568 minecraft:obsidian
fill 417 168 570 417 168 572 minecraft:obsidian
fill 417 168 574 417 168 576 minecraft:obsidian
fill 417 168 578 417 168 580 minecraft:obsidian
fill 417 168 582 417 168 584 minecraft:obsidian
fill 417 168 586 417 168 588 minecraft:obsidian
fill 417 168 590 417 168 592 minecraft:obsidian
fill 417 168 594 417 168 596 minecraft:obsidian
fill 418 168 557 418 173 557 minecraft:purple_terracotta
fill 418 168 558 418 168 559 minecraft:purple_concrete
fill 418 168 560 418 173 560 minecraft:purple_terracotta
fill 418 168 562 418 169 562 minecraft:purple_concrete
fill 418 168 568 418 173 569 minecraft:purple_terracotta
fill 418 168 570 418 169 571 minecraft:purple_concrete
setblock 418 168 579 minecraft:purple_concrete
fill 418 168 580 418 173 581 minecraft:purple_terracotta
fill 418 168 582 418 169 583 minecraft:purple_concrete
fill 418 168 588 418 173 589 minecraft:purple_terracotta
fill 418 168 590 418 168 591 minecraft:purple_concrete
fill 418 168 592 418 173 592 minecraft:purple_terracotta
fill 418 168 599 418 169 599 minecraft:purple_concrete
fill 376 169 565 376 169 566 minecraft:purple_concrete
setblock 376 169 569 minecraft:purple_concrete
fill 376 169 570 376 172 570 minecraft:purple_terracotta
fill 376 169 581 376 172 581 minecraft:purple_terracotta
setblock 376 169 586 minecraft:purple_concrete
setblock 376 169 597 minecraft:purple_concrete
fill 378 169 599 379 172 599 minecraft:purple_terracotta
setblock 383 169 557 minecraft:purple_concrete
setblock 383 169 583 minecraft:purple_concrete
fill 384 169 557 384 171 557 minecraft:purple_terracotta
fill 384 169 590 384 172 590 minecraft:purple_concrete
fill 387 169 590 388 171 590 minecraft:purple_concrete
fill 388 169 557 388 172 557 minecraft:purple_terracotta
fill 388 169 588 388 172 589 minecraft:purple_concrete
setblock 395 169 599 minecraft:purple_concrete
setblock 398 169 599 minecraft:purple_concrete
fill 399 169 557 399 172 557 minecraft:purple_terracotta
fill 399 169 599 399 172 599 minecraft:purple_terracotta
setblock 400 169 557 minecraft:purple_concrete
setblock 403 169 557 minecraft:purple_concrete
setblock 406 169 599 minecraft:purple_concrete
fill 410 169 599 410 172 599 minecraft:purple_terracotta
fill 418 169 558 418 172 559 minecraft:purple_terracotta
setblock 418 169 563 minecraft:purple_concrete
setblock 418 169 574 minecraft:purple_concrete
fill 418 169 579 418 172 579 minecraft:purple_terracotta
fill 418 169 590 418 172 590 minecraft:purple_terracotta
setblock 418 169 591 minecraft:purple_concrete
fill 418 169 594 418 169 595 minecraft:purple_concrete
fill 376 170 557 376 175 558 minecraft:purple_terracotta
fill 376 170 564 376 171 564 minecraft:purple_concrete
fill 376 170 565 376 175 566 minecraft:purple_terracotta
setblock 376 170 567 minecraft:purple_concrete
fill 376 170 569 376 175 569 minecraft:purple_terracotta
fill 376 170 575 376 171 576 minecraft:purple_concrete
fill 376 170 577 376 175 578 minecraft:purple_terracotta
fill 376 170 586 376 175 586 minecraft:purple_terracotta
fill 376 170 587 376 170 588 minecraft:purple_concrete
fill 376 170 589 376 175 590 minecraft:purple_terracotta
fill 376 170 595 376 171 596 minecraft:purple_concrete
fill 376 170 597 376 175 598 minecraft:purple_terracotta
setblock 376 170 599 minecraft:purple_concrete
fill 379 170 557 380 175 557 minecraft:purple_terracotta
fill 381 170 557 382 170 557 minecraft:purple_concrete
fill 383 170 557 383 171 557 minecraft:purple_terracotta
fill 383 170 584 383 173 584 minecraft:amethyst_block
setblock 383 170 585 minecraft:purple_concrete
fill 384 170 599 385 171 599 minecraft:purple_concrete
fill 385 170 591 388 171 591 minecraft:purple_concrete
fill 386 170 599 387 175 599 minecraft:purple_terracotta
fill 388 170 587 388 172 587 minecraft:purple_concrete
fill 389 170 589 389 171 590 minecraft:purple_concrete
fill 391 170 557 392 175 557 minecraft:purple_terracotta
fill 393 170 557 394 171 557 minecraft:purple_concrete
fill 393 170 599 393 171 599 minecraft:purple_concrete
fill 395 170 599 395 175 599 minecraft:purple_terracotta
fill 396 170 599 397 170 599 minecraft:purple_concrete
fill 398 170 599 398 175 599 minecraft:purple_terracotta
fill 400 170 557 400 175 557 minecraft:purple_terracotta
fill 401 170 557 402 170 557 minecraft:purple_concrete
fill 403 170 557 403 175 557 minecraft:purple_terracotta
fill 404 170 599 405 171 599 minecraft:purple_concrete
fill 405 170 557 405 171 557 minecraft:purple_concrete
fill 406 170 599 407 175 599 minecraft:purple_terracotta
fill 411 170 557 412 175 557 minecraft:purple_terracotta
fill 413 170 557 414 171 557 minecraft:purple_concrete
fill 416 170 599 417 170 599 minecraft:purple_concrete
setblock 418 170 561 minecraft:purple_concrete
fill 418 170 562 418 175 563 minecraft:purple_terracotta
fill 418 170 564 418 171 565 minecraft:purple_concrete
fill 418 170 570 418 175 571 minecraft:purple_terracotta
fill 418 170 572 418 170 573 minecraft:purple_concrete
fill 418 170 574 418 175 574 minecraft:purple_terracotta
fill 418 170 582 418 175 583 minecraft:purple_terracotta
fill 418 170 584 418 171 585 minecraft:purple_concrete
fill 418 170 591 418 175 591 minecraft:purple_terracotta
setblock 418 170 593 minecraft:purple_concrete
fill 418 170 594 418 175 595 minecraft:purple_terracotta
fill 418 170 596 418 171 596 minecraft:purple_concrete
fill 418 170 599 418 175 599 minecraft:purple_terracotta
setblock 376 171 563 minecraft:purple_concrete
fill 376 171 567 376 174 567 minecraft:purple_terracotta
fill 376 171 583 376 171 584 minecraft:purple_concrete
setblock 376 171 587 minecraft:purple_concrete
fill 376 171 588 376 174 588 minecraft:purple_terracotta
fill 376 171 599 376 174 599 minecraft:purple_terracotta
fill 381 171 557 381 174 557 minecraft:purple_terracotta
setblock 381 171 599 minecraft:purple_concrete
setblock 382 171 557 minecraft:purple_concrete
fill 383 171 585 383 173 585 minecraft:amethyst_block
fill 383 171 586 384 171 587 minecraft:purple_concrete
fill 385 171 557 386 171 557 minecraft:purple_concrete
fill 385 171 587 387 172 587 minecraft:purple_concrete
setblock 386 171 586 minecraft:purple_concrete
fill 386 171 592 389 171 592 minecraft:purple_concrete
fill 387 171 588 387 174 588 minecraft:purple_concrete
fill 389 171 588 389 173 588 minecraft:purple_concrete
fill 389 171 591 389 176 591 minecraft:black_concrete
fill 390 171 590 390 171 591 minecraft:purple_concrete
setblock 392 171 599 minecraft:purple_concrete
fill 396 171 599 397 174 599 minecraft:purple_terracotta
fill 401 171 557 402 173 557 minecraft:purple_terracotta
setblock 406 171 557 minecraft:purple_concrete
setblock 413 171 599 minecraft:purple_concrete
setblock 416 171 599 minecraft:purple_concrete
setblock 417 171 557 minecraft:purple_concrete
fill 417 171 599 417 174 599 minecraft:purple_terracotta
fill 418 171 561 418 174 561 minecraft:purple_terracotta
fill 418 171 572 418 174 572 minecraft:purple_terracotta
setblock 418 171 573 minecraft:purple_concrete
fill 418 171 576 418 171 577 minecraft:purple_concrete
fill 418 171 593 418 174 593 minecraft:purple_terracotta
setblock 418 171 597 minecraft:purple_concrete
fill 376 172 561 376 173 562 minecraft:purple_concrete
fill 376 172 563 376 186 564 minecraft:purple_terracotta
fill 376 172 573 376 172 574 minecraft:purple_concrete
fill 376 172 575 376 189 576 minecraft:purple_terracotta
fill 376 172 582 376 173 582 minecraft:purple_concrete
fill 376 172 583 376 186 584 minecraft:purple_terracotta
setblock 376 172 585 minecraft:purple_concrete
fill 376 172 587 376 189 587 minecraft:purple_terracotta
fill 376 172 593 376 173 594 minecraft:purple_concrete
fill 376 172 595 376 190 596 minecraft:purple_terracotta
setblock 379 172 560 minecraft:light[level=12]
setblock 379 172 568 minecraft:light[level=12]
setblock 379 172 576 minecraft:light[level=12]
setblock 379 172 584 minecraft:light[level=12]
setblock 379 172 592 minecraft:light[level=12]
fill 381 172 599 381 186 599 minecraft:purple_terracotta
fill 382 172 557 382 189 557 minecraft:purple_terracotta
fill 382 172 599 383 172 599 minecraft:purple_concrete
fill 383 172 557 384 172 557 minecraft:purple_concrete
fill 384 172 587 384 172 589 minecraft:purple_concrete
fill 384 172 599 385 189 599 minecraft:purple_terracotta
fill 385 172 557 386 173 557 minecraft:purple_terracotta
fill 385 172 588 386 173 588 minecraft:purple_concrete
fill 385 172 591 386 173 591 minecraft:purple_concrete
fill 386 172 592 386 173 592 minecraft:purple_concrete
fill 387 172 557 387 173 557 minecraft:purple_concrete
setblock 387 172 560 minecraft:light[level=12]
setblock 387 172 568 minecraft:light[level=12]
setblock 387 172 576 minecraft:light[level=12]
setblock 387 172 584 minecraft:light[level=12]
setblock 387 172 590 minecraft:purple_concrete
fill 387 172 591 388 175 592 minecraft:black_concrete
fill 388 172 590 390 176 590 minecraft:black_concrete
fill 388 172 593 390 176 593 minecraft:black_concrete
fill 389 172 589 390 172 589 minecraft:purple_concrete
fill 389 172 592 391 175 592 minecraft:black_concrete
fill 390 172 591 391 176 591 minecraft:black_concrete
fill 390 172 599 391 173 599 minecraft:purple_concrete
fill 392 172 599 393 186 599 minecraft:purple_terracotta
fill 393 172 557 394 189 557 minecraft:purple_terracotta
setblock 394 172 599 minecraft:purple_concrete
fill 395 172 557 396 173 557 minecraft:purple_concrete
setblock 395 172 560 minecraft:light[level=12]
setblock 395 172 568 minecraft:light[level=12]
setblock 395 172 576 minecraft:light[level=12]
setblock 395 172 584 minecraft:light[level=12]
setblock 395 172 592 minecraft:light[level=12]
fill 402 172 599 403 173 599 minecraft:purple_concrete
setblock 403 172 560 minecraft:light[level=12]
setblock 403 172 568 minecraft:light[level=12]
setblock 403 172 576 minecraft:light[level=12]
setblock 403 172 584 minecraft:light[level=12]
setblock 403 172 592 minecraft:light[level=12]
setblock 404 172 557 minecraft:purple_concrete
fill 404 172 599 405 189 599 minecraft:purple_terracotta
fill 405 172 557 406 186 557 minecraft:purple_terracotta
fill 407 172 557 408 173 557 minecraft:purple_concrete
setblock 411 172 560 minecraft:light[level=12]
setblock 411 172 568 minecraft:light[level=12]
setblock 411 172 576 minecraft:light[level=12]
setblock 411 172 584 minecraft:light[level=12]
setblock 411 172 592 minecraft:light[level=12]
fill 411 172 599 411 173 599 minecraft:purple_concrete
fill 413 172 557 414 189 557 minecraft:purple_terracotta
fill 413 172 599 413 186 599 minecraft:purple_terracotta
fill 414 172 599 415 172 599 minecraft:purple_concrete
fill 415 172 557 416 172 557 minecraft:purple_concrete
fill 416 172 599 416 189 599 minecraft:purple_terracotta
fill 417 172 557 417 186 557 minecraft:purple_terracotta
fill 418 172 564 418 189 565 minecraft:purple_terracotta
fill 418 172 566 418 173 567 minecraft:purple_concrete
fill 418 172 573 418 189 573 minecraft:purple_terracotta
setblock 418 172 575 minecraft:purple_concrete
fill 418 172 576 418 186 577 minecraft:purple_terracotta
fill 418 172 578 418 173 578 minecraft:purple_concrete
fill 418 172 584 418 189 585 minecraft:purple_terracotta
fill 418 172 586 418 172 587 minecraft:purple_concrete
fill 418 172 596 418 186 597 minecraft:purple_terracotta
fill 418 172 598 418 173 598 minecraft:purple_concrete
setblock 376 173 570 minecraft:purple_concrete
setblock 376 173 573 minecraft:purple_concrete
fill 376 173 574 376 191 574 minecraft:purple_terracotta
setblock 376 173 581 minecraft:purple_concrete
fill 376 173 585 376 191 585 minecraft:purple_terracotta
fill 378 173 599 379 173 599 minecraft:purple_concrete
setblock 382 173 599 minecraft:purple_concrete
fill 383 173 557 384 175 557 minecraft:purple_terracotta
fill 383 173 599 383 191 599 minecraft:purple_terracotta
fill 387 173 590 387 175 590 minecraft:black_concrete
fill 387 173 593 387 174 593 minecraft:black_concrete
setblock 388 173 557 minecraft:purple_concrete
fill 388 173 588 388 174 588 minecraft:purple_concrete
fill 388 173 589 390 175 589 minecraft:black_concrete
fill 390 173 594 390 176 594 minecraft:black_concrete
fill 391 173 590 391 176 590 minecraft:black_concrete
fill 391 173 593 392 174 593 minecraft:black_concrete
fill 392 173 591 392 175 592 minecraft:black_concrete
fill 394 173 599 394 191 599 minecraft:purple_terracotta
setblock 399 173 557 minecraft:purple_concrete
setblock 399 173 599 minecraft:purple_concrete
fill 404 173 557 404 175 557 minecraft:purple_terracotta
setblock 410 173 599 minecraft:purple_concrete
fill 414 173 599 415 191 599 minecraft:purple_terracotta
fill 415 173 557 415 191 557 minecraft:purple_terracotta
setblock 416 173 557 minecraft:purple_concrete
fill 418 173 558 418 173 559 minecraft:purple_concrete
fill 418 173 575 418 191 575 minecraft:purple_terracotta
setblock 418 173 579 minecraft:purple_concrete
fill 418 173 586 418 191 586 minecraft:purple_terracotta
setblock 418 173 587 minecraft:purple_concrete
setblock 418 173 590 minecraft:purple_concrete
fill 376 174 559 376 175 560 minecraft:purple_concrete
fill 376 174 561 376 187 562 minecraft:purple_terracotta
fill 376 174 568 376 175 568 minecraft:purple_concrete
fill 376 174 570 376 187 570 minecraft:purple_terracotta
fill 376 174 571 376 174 572 minecraft:purple_concrete
fill 376 174 573 376 191 573 minecraft:purple_terracotta
fill 376 174 579 376 175 580 minecraft:purple_concrete
fill 376 174 581 376 187 582 minecraft:purple_terracotta
fill 376 174 591 376 174 592 minecraft:purple_concrete
fill 376 174 593 376 187 594 minecraft:purple_terracotta
fill 377 174 557 378 175 557 minecraft:purple_concrete
fill 377 174 558 379 174 558 minecraft:obsidian
fill 377 174 560 377 174 562 minecraft:obsidian
fill 377 174 564 377 174 566 minecraft:obsidian
fill 377 174 568 377 174 570 minecraft:obsidian
fill 377 174 572 377 174 574 minecraft:obsidian
fill 377 174 576 377 174 578 minecraft:obsidian
fill 377 174 580 377 174 582 minecraft:obsidian
fill 377 174 584 377 174 586 minecraft:obsidian
fill 377 174 588 377 174 590 minecraft:obsidian
fill 377 174 592 377 174 594 minecraft:obsidian
fill 377 174 596 377 174 598 minecraft:obsidian
fill 377 174 599 377 175 599 minecraft:purple_concrete
fill 378 174 599 379 187 599 minecraft:purple_terracotta
fill 379 174 598 381 174 598 minecraft:obsidian
setblock 380 174 599 minecraft:purple_concrete
fill 381 174 558 383 174 558 minecraft:obsidian
fill 382 174 599 382 191 599 minecraft:purple_terracotta
fill 383 174 598 385 174 598 minecraft:obsidian
fill 385 174 557 385 186 557 minecraft:purple_terracotta
fill 385 174 558 387 174 558 minecraft:obsidian
setblock 386 174 557 minecraft:purple_concrete
fill 386 174 590 386 174 591 minecraft:purple_concrete
fill 387 174 557 388 187 557 minecraft:purple_terracotta
fill 387 174 598 389 174 598 minecraft:obsidian
fill 388 174 599 389 175 599 minecraft:purple_concrete
fill 389 174 557 390 175 557 minecraft:purple_concrete
fill 389 174 558 391 174 558 minecraft:obsidian
fill 389 174 594 389 176 594 minecraft:black_concrete
fill 390 174 599 391 187 599 minecraft:purple_terracotta
fill 391 174 594 392 174 594 minecraft:black_concrete
fill 391 174 598 393 174 598 minecraft:obsidian
fill 392 174 590 392 176 590 minecraft:black_concrete
fill 393 174 558 395 174 558 minecraft:obsidian
fill 393 174 591 393 174 593 minecraft:black_concrete
fill 395 174 557 396 191 557 minecraft:purple_terracotta
fill 395 174 567 396 175 567 minecraft:amethyst_block
fill 395 174 598 397 174 598 minecraft:obsidian
fill 397 174 557 398 174 557 minecraft:purple_concrete
fill 397 174 558 399 174 558 minecraft:obsidian
fill 399 174 557 399 187 557 minecraft:purple_terracotta
fill 399 174 598 401 174 598 minecraft:obsidian
fill 399 174 599 399 187 599 minecraft:purple_terracotta
fill 400 174 599 401 174 599 minecraft:purple_concrete
fill 401 174 557 401 175 557 minecraft:purple_concrete
fill 401 174 558 403 174 558 minecraft:obsidian
setblock 402 174 557 minecraft:purple_terracotta
fill 402 174 599 403 191 599 minecraft:purple_terracotta
fill 403 174 598 405 174 598 minecraft:obsidian
fill 405 174 558 407 174 558 minecraft:obsidian
fill 407 174 557 408 187 557 minecraft:purple_terracotta
fill 407 174 598 409 174 598 minecraft:obsidian
fill 408 174 599 409 175 599 minecraft:purple_concrete
fill 409 174 557 410 175 557 minecraft:purple_concrete
fill 409 174 558 411 174 558 minecraft:obsidian
fill 410 174 599 411 187 599 minecraft:purple_terracotta
fill 411 174 598 413 174 598 minecraft:obsidian
setblock 412 174 599 minecraft:purple_concrete
fill 413 174 558 415 174 558 minecraft:obsidian
fill 415 174 598 417 174 598 minecraft:obsidian
fill 416 174 557 416 191 557 minecraft:purple_terracotta
fill 417 174 558 417 174 560 minecraft:obsidian
fill 417 174 562 417 174 564 minecraft:obsidian
fill 417 174 566 417 174 568 minecraft:obsidian
fill 417 174 570 417 174 572 minecraft:obsidian
fill 417 174 574 417 174 576 minecraft:obsidian
fill 417 174 578 417 174 580 minecraft:obsidian
fill 417 174 582 417 174 584 minecraft:obsidian
fill 417 174 586 417 174 588 minecraft:obsidian
fill 417 174 590 417 174 592 minecraft:obsidian
fill 417 174 594 417 174 596 minecraft:obsidian
setblock 418 174 557 minecraft:purple_concrete
fill 418 174 558 418 187 559 minecraft:purple_terracotta
fill 418 174 560 418 175 560 minecraft:purple_concrete
fill 418 174 566 418 187 567 minecraft:purple_terracotta
fill 418 174 568 418 174 569 minecraft:purple_concrete
fill 418 174 578 418 187 579 minecraft:purple_terracotta
fill 418 174 580 418 175 581 minecraft:purple_concrete
fill 418 174 587 418 191 587 minecraft:purple_terracotta
fill 418 174 588 418 174 589 minecraft:purple_concrete
fill 418 174 590 418 187 590 minecraft:purple_terracotta
fill 418 174 592 418 175 592 minecraft:purple_concrete
fill 418 174 598 418 191 598 minecraft:purple_terracotta
setblock 376 175 567 minecraft:purple_concrete
fill 376 175 571 376 186 572 minecraft:purple_terracotta
setblock 376 175 588 minecraft:purple_concrete
setblock 376 175 591 minecraft:purple_concrete
fill 376 175 592 376 186 592 minecraft:purple_terracotta
setblock 376 175 599 minecraft:purple_concrete
fill 380 175 599 380 186 599 minecraft:purple_terracotta
setblock 381 175 557 minecraft:purple_concrete
fill 386 175 557 386 186 557 minecraft:purple_terracotta
fill 391 175 593 391 175 594 minecraft:black_concrete
fill 392 175 593 394 176 594 minecraft:purple_concrete
setblock 392 175 595 minecraft:black_concrete
setblock 393 175 591 minecraft:black_concrete
fill 393 175 592 394 176 592 minecraft:purple_concrete
fill 396 175 599 397 175 599 minecraft:purple_concrete
fill 397 175 557 397 186 557 minecraft:purple_terracotta
setblock 398 175 557 minecraft:purple_concrete
setblock 400 175 599 minecraft:purple_concrete
fill 401 175 599 401 186 599 minecraft:purple_terracotta
setblock 402 175 557 minecraft:purple_concrete
fill 412 175 599 412 186 599 minecraft:purple_terracotta
setblock 417 175 599 minecraft:purple_concrete
fill 418 175 557 418 186 557 minecraft:purple_terracotta
setblock 418 175 561 minecraft:purple_concrete
fill 418 175 568 418 186 568 minecraft:purple_terracotta
setblock 418 175 569 minecraft:purple_concrete
setblock 418 175 572 minecraft:purple_concrete
fill 418 175 588 418 186 589 minecraft:purple_terracotta
setblock 418 175 593 minecraft:purple_concrete
fill 376 176 557 376 176 558 minecraft:purple_concrete
fill 376 176 559 376 186 560 minecraft:purple_terracotta
fill 376 176 565 376 176 566 minecraft:purple_concrete
fill 376 176 567 376 189 568 minecraft:purple_terracotta
setblock 376 176 569 minecraft:purple_concrete
fill 376 176 577 376 176 578 minecraft:purple_concrete
fill 376 176 579 376 186 580 minecraft:purple_terracotta
setblock 376 176 586 minecraft:purple_concrete
fill 376 176 588 376 189 588 minecraft:purple_terracotta
fill 376 176 589 376 176 590 minecraft:purple_concrete
fill 376 176 591 376 186 591 minecraft:purple_terracotta
fill 376 176 597 376 176 598 minecraft:purple_concrete
fill 376 176 599 377 189 599 minecraft:purple_terracotta
fill 377 176 557 378 186 557 minecraft:purple_terracotta
fill 379 176 557 380 176 557 minecraft:purple_concrete
fill 381 176 557 381 189 557 minecraft:purple_terracotta
setblock 383 176 557 minecraft:purple_concrete
fill 384 176 557 384 191 557 minecraft:purple_terracotta
fill 386 176 599 387 176 599 minecraft:purple_concrete
fill 388 176 591 388 176 592 minecraft:black_concrete
fill 388 176 599 389 186 599 minecraft:purple_terracotta
fill 389 176 557 390 186 557 minecraft:purple_terracotta
fill 389 176 592 390 176 592 minecraft:black_concrete
fill 391 176 557 392 176 557 minecraft:purple_concrete
fill 391 176 592 391 176 594 minecraft:purple_concrete
setblock 391 176 595 minecraft:black_concrete
fill 392 176 591 392 176 592 minecraft:purple_concrete
fill 392 176 595 394 176 595 minecraft:purple_concrete
setblock 393 176 590 minecraft:black_concrete
fill 393 176 591 394 176 591 minecraft:purple_concrete
fill 395 176 592 395 176 594 minecraft:purple_concrete
setblock 395 176 599 minecraft:purple_concrete
setblock 396 176 593 minecraft:purple_concrete
fill 396 176 599 397 189 599 minecraft:purple_terracotta
fill 398 176 557 398 186 557 minecraft:purple_terracotta
setblock 398 176 599 minecraft:purple_concrete
setblock 400 176 557 minecraft:purple_concrete
fill 400 176 599 400 186 599 minecraft:purple_terracotta
fill 401 176 557 402 189 557 minecraft:purple_terracotta
fill 403 176 557 404 176 557 minecraft:purple_concrete
fill 406 176 599 407 176 599 minecraft:purple_concrete
fill 408 176 599 409 189 599 minecraft:purple_terracotta
fill 409 176 557 410 186 557 minecraft:purple_terracotta
fill 411 176 557 412 176 557 minecraft:purple_concrete
fill 417 176 599 417 189 599 minecraft:purple_terracotta
fill 418 176 560 418 189 561 minecraft:purple_terracotta
fill 418 176 562 418 176 563 minecraft:purple_concrete
fill 418 176 569 418 186 569 minecraft:purple_terracotta
fill 418 176 570 418 176 571 minecraft:purple_concrete
fill 418 176 572 418 189 572 minecraft:purple_terracotta
setblock 418 176 574 minecraft:purple_concrete
fill 418 176 580 418 186 581 minecraft:purple_terracotta
fill 418 176 582 418 176 583 minecraft:purple_concrete
setblock 418 176 591 minecraft:purple_concrete
fill 418 176 592 418 189 593 minecraft:purple_terracotta
fill 418 176 594 418 176 595 minecraft:purple_concrete
setblock 418 176 599 minecraft:purple_concrete
fill 376 177 557 376 187 558 minecraft:purple_terracotta
fill 376 177 565 376 191 566 minecraft:purple_terracotta
fill 376 177 569 376 187 569 minecraft:purple_terracotta
fill 376 177 577 376 188 578 minecraft:purple_terracotta
fill 376 177 586 376 191 586 minecraft:purple_terracotta
fill 376 177 589 376 187 590 minecraft:purple_terracotta
fill 376 177 597 376 188 598 minecraft:purple_terracotta
fill 379 177 557 380 187 557 minecraft:purple_terracotta
fill 383 177 557 383 191 557 minecraft:purple_terracotta
fill 386 177 599 387 187 599 minecraft:purple_terracotta
fill 391 177 557 392 188 557 minecraft:purple_terracotta
fill 395 177 599 395 191 599 minecraft:purple_terracotta
fill 398 177 599 398 187 599 minecraft:purple_terracotta
fill 400 177 557 400 187 557 minecraft:purple_terracotta
fill 403 177 557 404 191 557 minecraft:purple_terracotta
fill 406 177 599 407 188 599 minecraft:purple_terracotta
fill 411 177 557 412 187 557 minecraft:purple_terracotta
fill 418 177 562 418 188 563 minecraft:purple_terracotta
fill 418 177 570 418 187 571 minecraft:purple_terracotta
fill 418 177 574 418 191 574 minecraft:purple_terracotta
fill 418 177 582 418 188 583 minecraft:purple_terracotta
fill 418 177 591 418 187 591 minecraft:purple_terracotta
fill 418 177 594 418 191 595 minecraft:purple_terracotta
fill 418 177 599 418 188 599 minecraft:purple_terracotta
setblock 379 180 560 minecraft:light[level=12]
setblock 379 180 568 minecraft:light[level=12]
setblock 379 180 576 minecraft:light[level=12]
setblock 379 180 584 minecraft:light[level=12]
setblock 379 180 592 minecraft:light[level=12]
setblock 387 180 560 minecraft:light[level=12]
setblock 387 180 568 minecraft:light[level=12]
setblock 387 180 576 minecraft:light[level=12]
setblock 387 180 584 minecraft:light[level=12]
setblock 387 180 592 minecraft:light[level=12]
setblock 395 180 560 minecraft:light[level=12]
setblock 395 180 568 minecraft:light[level=12]
setblock 395 180 576 minecraft:light[level=12]
setblock 395 180 584 minecraft:light[level=12]
setblock 395 180 592 minecraft:light[level=12]
setblock 403 180 560 minecraft:light[level=12]
setblock 403 180 568 minecraft:light[level=12]
setblock 403 180 576 minecraft:light[level=12]
setblock 403 180 584 minecraft:light[level=12]
setblock 403 180 592 minecraft:light[level=12]
setblock 411 180 560 minecraft:light[level=12]
setblock 411 180 568 minecraft:light[level=12]
setblock 411 180 576 minecraft:light[level=12]
setblock 411 180 584 minecraft:light[level=12]
setblock 411 180 592 minecraft:light[level=12]
fill 377 182 558 377 183 568 minecraft:purple_terracotta
fill 377 182 569 377 183 570 minecraft:black_concrete
fill 377 182 571 377 183 584 minecraft:purple_terracotta
fill 377 182 585 377 183 586 minecraft:black_concrete
fill 377 182 587 378 183 598 minecraft:purple_terracotta
fill 378 182 558 378 183 567 minecraft:purple_terracotta
fill 378 182 568 378 183 568 minecraft:black_concrete
fill 378 182 569 378 183 582 minecraft:purple_terracotta
fill 378 182 583 378 183 584 minecraft:black_concrete
fill 378 182 585 385 183 586 minecraft:purple_terracotta
fill 379 182 558 379 183 565 minecraft:purple_terracotta
fill 379 182 566 379 183 566 minecraft:black_concrete
fill 379 182 567 379 183 581 minecraft:purple_terracotta
fill 379 182 582 379 183 582 minecraft:black_concrete
fill 379 182 583 386 183 584 minecraft:purple_terracotta
fill 379 182 587 379 183 596 minecraft:purple_terracotta
fill 379 182 597 379 183 598 minecraft:black_concrete
fill 380 182 558 380 183 563 minecraft:purple_terracotta
fill 380 182 564 380 183 565 minecraft:black_concrete
fill 380 182 566 380 183 579 minecraft:purple_terracotta
fill 380 182 580 380 183 580 minecraft:black_concrete
fill 380 182 581 387 183 582 minecraft:purple_terracotta
fill 380 182 587 380 183 594 minecraft:purple_terracotta
fill 380 182 595 380 183 596 minecraft:black_concrete
fill 380 182 597 387 183 598 minecraft:purple_terracotta
fill 381 182 558 381 183 561 minecraft:purple_terracotta
fill 381 182 562 381 183 563 minecraft:black_concrete
fill 381 182 564 381 183 577 minecraft:purple_terracotta
fill 381 182 578 381 183 579 minecraft:black_concrete
fill 381 182 580 388 183 580 minecraft:purple_terracotta
fill 381 182 587 381 183 593 minecraft:purple_terracotta
fill 381 182 594 381 183 594 minecraft:black_concrete
fill 381 182 595 388 183 596 minecraft:purple_terracotta
fill 382 182 558 382 183 560 minecraft:purple_terracotta
fill 382 182 561 382 183 561 minecraft:black_concrete
fill 382 182 562 382 183 575 minecraft:purple_terracotta
fill 382 182 576 382 183 577 minecraft:black_concrete
fill 382 182 578 389 183 579 minecraft:purple_terracotta
fill 382 182 587 382 183 591 minecraft:purple_terracotta
fill 382 182 592 382 183 593 minecraft:black_concrete
fill 382 182 594 389 183 594 minecraft:purple_terracotta
fill 383 182 558 383 183 558 minecraft:purple_terracotta
fill 383 182 559 383 183 559 minecraft:black_concrete
fill 383 182 560 383 183 574 minecraft:purple_terracotta
fill 383 182 575 383 183 575 minecraft:black_concrete
fill 383 182 576 390 183 577 minecraft:purple_terracotta
fill 383 182 587 383 183 589 minecraft:purple_terracotta
fill 383 182 590 383 183 591 minecraft:black_concrete
fill 383 182 592 390 183 593 minecraft:purple_terracotta
fill 384 182 558 384 183 558 minecraft:black_concrete
fill 384 182 559 384 183 572 minecraft:purple_terracotta
fill 384 182 573 384 183 573 minecraft:black_concrete
fill 384 182 574 391 183 575 minecraft:purple_terracotta
fill 384 182 587 384 183 587 minecraft:purple_terracotta
fill 384 182 588 384 183 589 minecraft:black_concrete
fill 384 182 590 391 183 591 minecraft:purple_terracotta
fill 385 182 558 385 183 570 minecraft:purple_terracotta
fill 385 182 571 385 183 572 minecraft:black_concrete
fill 385 182 573 392 183 573 minecraft:purple_terracotta
fill 385 182 587 385 183 587 minecraft:black_concrete
fill 385 182 588 392 183 589 minecraft:purple_terracotta
fill 386 182 558 386 183 568 minecraft:purple_terracotta
fill 386 182 569 386 183 570 minecraft:black_concrete
fill 386 182 571 393 183 572 minecraft:purple_terracotta
fill 386 182 585 386 183 586 minecraft:black_concrete
fill 386 182 587 393 183 587 minecraft:purple_terracotta
fill 387 182 558 387 183 567 minecraft:purple_terracotta
fill 387 182 568 387 183 568 minecraft:black_concrete
fill 387 182 569 394 183 570 minecraft:purple_terracotta
fill 387 182 583 387 183 584 minecraft:black_concrete
fill 387 182 585 394 183 586 minecraft:purple_terracotta
fill 388 182 558 388 183 565 minecraft:purple_terracotta
fill 388 182 566 388 183 566 minecraft:black_concrete
fill 388 182 567 395 183 568 minecraft:purple_terracotta
fill 388 182 581 388 183 582 minecraft:black_concrete
fill 388 182 583 395 183 584 minecraft:purple_terracotta
fill 388 182 597 388 183 598 minecraft:black_concrete
fill 389 182 558 389 183 563 minecraft:purple_terracotta
fill 389 182 564 389 183 565 minecraft:black_concrete
fill 389 182 566 396 183 566 minecraft:purple_terracotta
fill 389 182 580 389 183 580 minecraft:black_concrete
fill 389 182 581 396 182 582 minecraft:purple_terracotta
fill 389 182 595 389 183 596 minecraft:black_concrete
fill 389 182 597 396 183 598 minecraft:purple_terracotta
fill 390 182 558 390 183 561 minecraft:purple_terracotta
fill 390 182 562 390 183 563 minecraft:black_concrete
fill 390 182 564 397 183 565 minecraft:purple_terracotta
fill 390 182 578 390 183 579 minecraft:black_concrete
fill 390 182 580 397 182 580 minecraft:purple_terracotta
fill 390 182 594 390 183 594 minecraft:black_concrete
fill 390 182 595 397 183 596 minecraft:purple_terracotta
fill 391 182 558 391 183 560 minecraft:purple_terracotta
fill 391 182 561 391 183 561 minecraft:black_concrete
fill 391 182 562 398 183 563 minecraft:purple_terracotta
fill 391 182 576 391 183 577 minecraft:black_concrete
fill 391 182 578 398 182 579 minecraft:purple_terracotta
fill 391 182 592 391 183 592 minecraft:black_concrete
fill 391 182 593 398 183 594 minecraft:purple_terracotta
fill 392 182 558 392 183 558 minecraft:purple_terracotta
fill 392 182 559 392 183 559 minecraft:black_concrete
fill 392 182 560 399 183 561 minecraft:purple_terracotta
fill 392 182 574 392 183 575 minecraft:black_concrete
fill 392 182 576 396 182 577 minecraft:purple_terracotta
fill 392 182 590 392 183 591 minecraft:black_concrete
fill 392 182 592 399 183 592 minecraft:purple_terracotta
fill 393 182 558 393 183 558 minecraft:black_concrete
fill 393 182 559 400 183 559 minecraft:purple_terracotta
fill 393 182 573 393 183 573 minecraft:black_concrete
fill 393 182 574 397 182 575 minecraft:purple_terracotta
fill 393 182 588 393 183 589 minecraft:black_concrete
fill 393 182 590 400 183 591 minecraft:purple_terracotta
fill 394 182 558 401 183 558 minecraft:purple_terracotta
fill 394 182 571 394 182 572 minecraft:black_concrete
fill 394 182 573 401 182 573 minecraft:purple_terracotta
fill 394 182 587 394 183 587 minecraft:black_concrete
fill 394 182 588 401 183 589 minecraft:purple_terracotta
fill 395 182 569 395 183 570 minecraft:black_concrete
fill 395 182 571 402 182 572 minecraft:purple_terracotta
fill 395 182 585 395 183 585 minecraft:black_concrete
fill 395 182 586 402 183 587 minecraft:purple_terracotta
fill 396 182 567 396 183 568 minecraft:black_concrete
fill 396 182 569 403 182 570 minecraft:purple_terracotta
fill 396 182 583 396 183 584 minecraft:black_concrete
fill 396 182 585 403 183 585 minecraft:purple_terracotta
fill 397 182 566 397 183 566 minecraft:black_concrete
fill 397 182 567 404 183 568 minecraft:purple_terracotta
setblock 397 182 577 minecraft:purple_terracotta
fill 397 182 581 397 182 582 minecraft:black_concrete
fill 397 182 583 404 183 584 minecraft:purple_terracotta
fill 397 182 597 397 183 598 minecraft:black_concrete
fill 398 182 564 398 183 565 minecraft:black_concrete
fill 398 182 566 405 183 566 minecraft:purple_terracotta
setblock 398 182 574 minecraft:purple_terracotta
setblock 398 182 580 minecraft:black_concrete
fill 398 182 581 405 182 582 minecraft:purple_terracotta
fill 398 182 595 398 183 596 minecraft:black_concrete
fill 398 182 597 405 183 598 minecraft:purple_terracotta
fill 399 182 562 399 183 563 minecraft:black_concrete
fill 399 182 564 406 183 565 minecraft:purple_terracotta
fill 399 182 579 406 182 580 minecraft:purple_terracotta
fill 399 182 593 417 183 593 minecraft:purple_terracotta
fill 399 182 594 399 183 594 minecraft:black_concrete
fill 399 182 595 406 183 596 minecraft:purple_terracotta
fill 400 182 560 400 183 561 minecraft:black_concrete
fill 400 182 562 407 183 563 minecraft:purple_terracotta
setblock 400 182 574 minecraft:purple_terracotta
fill 400 182 578 407 182 578 minecraft:purple_terracotta
fill 400 182 592 400 183 592 minecraft:black_concrete
fill 400 182 594 407 183 594 minecraft:purple_terracotta
fill 401 182 559 401 183 559 minecraft:black_concrete
fill 401 182 560 408 183 561 minecraft:purple_terracotta
fill 401 182 574 401 182 575 minecraft:black_concrete
fill 401 182 577 408 182 577 minecraft:purple_terracotta
fill 401 182 590 401 183 591 minecraft:black_concrete
fill 401 182 592 408 183 592 minecraft:purple_terracotta
fill 402 182 558 402 183 558 minecraft:black_concrete
fill 402 182 559 409 183 559 minecraft:purple_terracotta
setblock 402 182 573 minecraft:black_concrete
fill 402 182 574 408 182 576 minecraft:purple_terracotta
fill 402 182 588 402 183 589 minecraft:black_concrete
fill 402 182 590 409 183 591 minecraft:purple_terracotta
fill 403 182 558 417 183 558 minecraft:purple_terracotta
setblock 403 182 571 minecraft:black_concrete
fill 403 182 572 410 182 573 minecraft:purple_terracotta
fill 403 182 586 417 183 586 minecraft:purple_terracotta
fill 403 182 587 403 183 587 minecraft:black_concrete
fill 403 182 588 410 183 589 minecraft:purple_terracotta
fill 404 182 569 404 183 570 minecraft:black_concrete
fill 404 182 571 411 183 571 minecraft:purple_terracotta
fill 404 182 585 404 183 585 minecraft:black_concrete
fill 404 182 587 411 183 587 minecraft:purple_terracotta
fill 405 182 567 405 183 568 minecraft:black_concrete
fill 405 182 569 412 183 570 minecraft:purple_terracotta
fill 405 182 583 405 183 584 minecraft:black_concrete
fill 405 182 585 412 183 585 minecraft:purple_terracotta
fill 406 182 566 406 183 566 minecraft:black_concrete
fill 406 182 567 413 183 568 minecraft:purple_terracotta
fill 406 182 581 406 183 582 minecraft:black_concrete
fill 406 182 583 413 183 584 minecraft:purple_terracotta
fill 406 182 597 406 183 598 minecraft:black_concrete
fill 407 182 564 407 183 564 minecraft:black_concrete
fill 407 182 565 414 183 566 minecraft:purple_terracotta
fill 407 182 579 417 183 579 minecraft:purple_terracotta
fill 407 182 580 407 183 580 minecraft:black_concrete
fill 407 182 581 414 183 582 minecraft:purple_terracotta
fill 407 182 595 407 183 596 minecraft:black_concrete
fill 407 182 597 414 183 598 minecraft:purple_terracotta
fill 408 182 562 408 183 563 minecraft:black_concrete
fill 408 182 564 415 183 564 minecraft:purple_terracotta
fill 408 182 578 408 183 578 minecraft:black_concrete
fill 408 182 580 415 183 580 minecraft:purple_terracotta
fill 408 182 594 408 183 594 minecraft:black_concrete
fill 408 182 595 415 183 596 minecraft:purple_terracotta
fill 409 182 560 409 183 561 minecraft:black_concrete
fill 409 182 562 416 183 563 minecraft:purple_terracotta
fill 409 182 574 409 183 575 minecraft:purple_terracotta
fill 409 182 576 409 183 577 minecraft:black_concrete
fill 409 182 578 416 183 578 minecraft:purple_terracotta
fill 409 182 592 409 183 592 minecraft:black_concrete
fill 409 182 594 416 183 594 minecraft:purple_terracotta
fill 410 182 559 410 183 559 minecraft:black_concrete
fill 410 182 560 417 183 561 minecraft:purple_terracotta
fill 410 182 574 410 183 575 minecraft:black_concrete
fill 410 182 576 417 183 577 minecraft:purple_terracotta
fill 410 182 590 410 183 591 minecraft:black_concrete
fill 410 182 592 417 183 592 minecraft:purple_terracotta
fill 411 182 559 417 183 559 minecraft:purple_terracotta
fill 411 182 572 417 183 572 minecraft:purple_terracotta
fill 411 182 573 411 183 573 minecraft:black_concrete
fill 411 182 574 417 183 575 minecraft:purple_terracotta
fill 411 182 588 411 183 589 minecraft:black_concrete
fill 411 182 590 417 183 591 minecraft:purple_terracotta
fill 412 182 571 412 183 571 minecraft:black_concrete
fill 412 182 573 417 183 573 minecraft:purple_terracotta
fill 412 182 587 412 183 587 minecraft:black_concrete
fill 412 182 588 417 183 589 minecraft:purple_terracotta
fill 413 182 569 413 183 570 minecraft:black_concrete
fill 413 182 571 417 183 571 minecraft:purple_terracotta
fill 413 182 585 413 183 585 minecraft:black_concrete
fill 413 182 587 417 183 587 minecraft:purple_terracotta
fill 414 182 567 414 183 568 minecraft:black_concrete
fill 414 182 569 417 183 570 minecraft:purple_terracotta
fill 414 182 583 414 183 584 minecraft:black_concrete
fill 414 182 585 417 183 585 minecraft:purple_terracotta
fill 415 182 565 417 183 565 minecraft:purple_terracotta
fill 415 182 566 415 183 566 minecraft:black_concrete
fill 415 182 567 417 183 568 minecraft:purple_terracotta
fill 415 182 581 415 183 582 minecraft:black_concrete
fill 415 182 583 417 183 584 minecraft:purple_terracotta
fill 415 182 597 415 183 598 minecraft:black_concrete
fill 416 182 564 416 183 564 minecraft:black_concrete
fill 416 182 566 417 183 566 minecraft:purple_terracotta
fill 416 182 580 416 183 580 minecraft:black_concrete
fill 416 182 581 417 183 582 minecraft:purple_terracotta
fill 416 182 595 416 183 596 minecraft:black_concrete
fill 416 182 597 417 183 598 minecraft:purple_terracotta
fill 417 182 562 417 183 563 minecraft:black_concrete
fill 417 182 564 417 183 564 minecraft:purple_terracotta
fill 417 182 578 417 183 578 minecraft:black_concrete
fill 417 182 580 417 183 580 minecraft:purple_terracotta
fill 417 182 594 417 183 594 minecraft:black_concrete
fill 417 182 595 417 183 596 minecraft:purple_terracotta
fill 389 183 581 394 183 582 minecraft:purple_terracotta
fill 390 183 580 393 183 580 minecraft:purple_terracotta
fill 391 183 578 392 183 579 minecraft:purple_terracotta
fill 392 183 576 392 183 577 minecraft:purple_terracotta
fill 393 183 574 396 183 578 minecraft:mossy_stone_bricks
setblock 393 183 579 minecraft:purple_terracotta
setblock 394 183 571 minecraft:black_concrete
fill 394 183 572 404 183 573 minecraft:mossy_stone_bricks
fill 394 183 579 404 183 580 minecraft:mossy_stone_bricks
fill 395 183 571 403 183 571 minecraft:mossy_stone_bricks
fill 395 183 581 403 183 581 minecraft:mossy_stone_bricks
fill 395 183 582 396 183 582 minecraft:purple_terracotta
fill 396 183 569 396 183 570 minecraft:purple_terracotta
fill 397 183 569 403 183 569 minecraft:purple_terracotta
fill 397 183 570 401 183 570 minecraft:mossy_stone_bricks
fill 397 183 574 397 183 575 minecraft:mossy_stone_bricks
fill 397 183 577 397 183 578 minecraft:mossy_stone_bricks
fill 397 183 582 401 183 582 minecraft:mossy_stone_bricks
setblock 398 183 574 minecraft:mossy_stone_bricks
setblock 398 183 578 minecraft:mossy_stone_bricks
fill 400 183 574 405 183 574 minecraft:mossy_stone_bricks
fill 400 183 578 405 183 578 minecraft:mossy_stone_bricks
fill 401 183 575 405 183 575 minecraft:mossy_stone_bricks
fill 401 183 577 405 183 577 minecraft:mossy_stone_bricks
fill 402 183 570 403 183 570 minecraft:purple_terracotta
fill 402 183 576 405 183 576 minecraft:mossy_stone_bricks
fill 402 183 582 405 183 582 minecraft:purple_terracotta
fill 404 183 581 405 183 581 minecraft:purple_terracotta
fill 405 183 572 410 183 573 minecraft:purple_terracotta
fill 405 183 579 406 183 580 minecraft:purple_terracotta
fill 406 183 574 407 183 578 minecraft:purple_terracotta
fill 408 183 574 408 183 577 minecraft:purple_terracotta
fill 391 184 574 392 193 578 minecraft:stone_bricks
fill 392 184 569 394 196 572 minecraft:cobblestone
fill 392 184 573 393 193 573 minecraft:stone_bricks
fill 392 184 579 393 194 579 minecraft:stone_bricks
fill 392 184 580 394 196 583 minecraft:cobblestone
fill 395 184 569 395 196 571 minecraft:cobblestone
fill 395 184 581 395 196 583 minecraft:cobblestone
fill 396 184 569 396 193 570 minecraft:stone_bricks
fill 396 184 582 396 193 583 minecraft:stone_bricks
fill 397 184 568 401 193 569 minecraft:stone_bricks
fill 397 184 583 401 193 584 minecraft:stone_bricks
fill 402 184 569 402 193 570 minecraft:stone_bricks
fill 402 184 582 402 194 583 minecraft:stone_bricks
fill 403 184 569 406 196 571 minecraft:cobblestone
fill 403 184 581 406 196 583 minecraft:cobblestone
fill 404 184 572 406 196 572 minecraft:cobblestone
fill 404 184 580 406 196 580 minecraft:cobblestone
fill 405 184 573 406 194 573 minecraft:stone_bricks
fill 405 184 579 406 193 579 minecraft:stone_bricks
fill 406 184 574 407 193 578 minecraft:stone_bricks
fill 376 187 559 376 187 560 minecraft:purple_concrete
setblock 376 187 563 minecraft:purple_concrete
fill 376 187 564 376 190 564 minecraft:purple_terracotta
fill 376 187 571 376 187 572 minecraft:purple_concrete
fill 376 187 579 376 189 579 minecraft:purple_terracotta
setblock 376 187 580 minecraft:purple_concrete
fill 376 187 583 376 187 584 minecraft:purple_concrete
fill 376 187 591 376 187 592 minecraft:purple_concrete
fill 377 187 557 378 187 557 minecraft:purple_concrete
fill 380 187 599 381 187 599 minecraft:purple_concrete
fill 385 187 557 386 187 557 minecraft:purple_concrete
fill 388 187 599 388 189 599 minecraft:purple_terracotta
setblock 389 187 557 minecraft:purple_concrete
setblock 389 187 599 minecraft:purple_concrete
fill 390 187 557 390 189 557 minecraft:purple_terracotta
setblock 392 187 599 minecraft:purple_concrete
fill 393 187 599 393 190 599 minecraft:purple_terracotta
fill 397 187 557 398 187 557 minecraft:purple_concrete
fill 400 187 599 401 187 599 minecraft:purple_concrete
fill 401 187 592 404 187 592 minecraft:black_concrete
fill 402 187 590 403 187 591 minecraft:black_concrete
fill 402 187 593 407 187 593 minecraft:black_concrete
fill 403 187 594 405 187 594 minecraft:black_concrete
setblock 404 187 589 minecraft:black_concrete
fill 404 187 590 408 189 591 minecraft:purple_concrete
fill 405 187 557 405 190 557 minecraft:purple_terracotta
fill 405 187 589 409 190 589 minecraft:purple_concrete
fill 405 187 592 408 189 592 minecraft:purple_concrete
setblock 406 187 557 minecraft:purple_concrete
fill 406 187 588 408 191 588 minecraft:purple_concrete
fill 409 187 557 410 187 557 minecraft:purple_concrete
fill 409 187 590 409 192 590 minecraft:purple_concrete
fill 412 187 599 413 187 599 minecraft:purple_concrete
fill 417 187 557 418 187 557 minecraft:purple_concrete
fill 418 187 568 418 187 569 minecraft:purple_concrete
fill 418 187 576 418 187 577 minecraft:purple_concrete
setblock 418 187 580 minecraft:purple_concrete
fill 418 187 581 418 189 581 minecraft:purple_terracotta
fill 418 187 588 418 187 589 minecraft:purple_concrete
fill 418 187 596 418 190 596 minecraft:purple_terracotta
setblock 418 187 597 minecraft:purple_concrete
fill 376 188 557 378 188 557 minecraft:purple_terracotta
fill 376 188 558 376 189 558 minecraft:purple_concrete
fill 376 188 559 376 193 560 minecraft:purple_terracotta
setblock 376 188 561 minecraft:purple_concrete
fill 376 188 562 376 191 563 minecraft:purple_terracotta
fill 376 188 569 376 189 570 minecraft:purple_concrete
fill 376 188 571 376 193 572 minecraft:purple_terracotta
fill 376 188 580 376 193 580 minecraft:purple_terracotta
fill 376 188 581 376 188 582 minecraft:purple_concrete
fill 376 188 583 376 193 584 minecraft:purple_terracotta
fill 376 188 589 376 189 590 minecraft:purple_concrete
fill 376 188 591 376 193 592 minecraft:purple_terracotta
setblock 376 188 593 minecraft:purple_concrete
fill 376 188 594 376 191 594 minecraft:purple_terracotta
fill 378 188 599 379 189 599 minecraft:purple_concrete
fill 379 188 557 380 189 557 minecraft:purple_concrete
setblock 379 188 560 minecraft:light[level=12]
setblock 379 188 568 minecraft:light[level=12]
setblock 379 188 576 minecraft:light[level=12]
setblock 379 188 584 minecraft:light[level=12]
setblock 379 188 592 minecraft:light[level=12]
fill 380 188 599 381 193 599 minecraft:purple_terracotta
fill 385 188 557 386 193 557 minecraft:purple_terracotta
setblock 386 188 599 minecraft:purple_terracotta
fill 387 188 557 388 188 557 minecraft:purple_concrete
setblock 387 188 560 minecraft:light[level=12]
setblock 387 188 568 minecraft:light[level=12]
setblock 387 188 576 minecraft:light[level=12]
setblock 387 188 584 minecraft:light[level=12]
setblock 387 188 592 minecraft:light[level=12]
fill 387 188 599 387 189 599 minecraft:purple_concrete
fill 389 188 557 389 193 557 minecraft:purple_terracotta
fill 389 188 599 389 193 599 minecraft:purple_terracotta
fill 390 188 599 391 188 599 minecraft:purple_concrete
fill 392 188 599 392 193 599 minecraft:purple_terracotta
setblock 395 188 560 minecraft:light[level=12]
setblock 395 188 568 minecraft:light[level=12]
setblock 395 188 576 minecraft:light[level=12]
setblock 395 188 584 minecraft:light[level=12]
setblock 395 188 592 minecraft:light[level=12]
fill 397 188 557 398 193 557 minecraft:purple_terracotta
fill 398 188 599 399 189 599 minecraft:purple_concrete
fill 399 188 557 400 189 557 minecraft:purple_concrete
fill 400 188 599 401 193 599 minecraft:purple_terracotta
setblock 403 188 560 minecraft:light[level=12]
setblock 403 188 568 minecraft:light[level=12]
setblock 403 188 576 minecraft:light[level=12]
setblock 403 188 584 minecraft:light[level=12]
fill 403 188 590 403 188 593 minecraft:black_concrete
setblock 404 188 589 minecraft:purple_concrete
fill 404 188 592 404 188 593 minecraft:black_concrete
fill 405 188 588 405 189 588 minecraft:purple_concrete
setblock 405 188 593 minecraft:black_concrete
fill 406 188 557 406 193 557 minecraft:purple_terracotta
fill 406 188 593 407 188 593 minecraft:purple_concrete
fill 407 188 557 408 188 557 minecraft:purple_concrete
fill 407 188 587 409 192 587 minecraft:purple_concrete
fill 409 188 557 410 189 557 minecraft:purple_terracotta
fill 409 188 588 410 194 588 minecraft:purple_concrete
fill 409 188 591 409 191 591 minecraft:purple_concrete
fill 410 188 589 410 193 589 minecraft:purple_concrete
fill 410 188 599 411 188 599 minecraft:purple_concrete
fill 411 188 557 411 189 557 minecraft:purple_concrete
setblock 411 188 560 minecraft:light[level=12]
setblock 411 188 568 minecraft:light[level=12]
setblock 411 188 576 minecraft:light[level=12]
setblock 411 188 584 minecraft:light[level=12]
setblock 411 188 592 minecraft:light[level=12]
setblock 412 188 557 minecraft:purple_terracotta
fill 412 188 599 413 193 599 minecraft:purple_terracotta
fill 417 188 557 418 193 557 minecraft:purple_terracotta
fill 418 188 558 418 189 559 minecraft:purple_concrete
fill 418 188 566 418 191 566 minecraft:purple_terracotta
setblock 418 188 567 minecraft:purple_concrete
fill 418 188 568 418 193 569 minecraft:purple_terracotta
fill 418 188 570 418 189 571 minecraft:purple_concrete
fill 418 188 576 418 193 577 minecraft:purple_terracotta
fill 418 188 578 418 188 579 minecraft:purple_concrete
fill 418 188 580 418 193 580 minecraft:purple_terracotta
fill 418 188 588 418 193 589 minecraft:purple_terracotta
fill 418 188 590 418 189 591 minecraft:purple_concrete
fill 418 188 597 418 193 597 minecraft:purple_terracotta
setblock 376 189 557 minecraft:purple_concrete
fill 376 189 561 376 192 561 minecraft:purple_terracotta
fill 376 189 577 376 189 578 minecraft:purple_concrete
setblock 376 189 581 minecraft:purple_concrete
fill 376 189 582 376 192 582 minecraft:purple_terracotta
fill 376 189 593 376 192 593 minecraft:purple_terracotta
fill 376 189 597 376 191 597 minecraft:purple_terracotta
setblock 376 189 598 minecraft:purple_concrete
fill 377 189 557 378 193 557 minecraft:purple_terracotta
setblock 386 189 599 minecraft:purple_concrete
fill 387 189 557 387 192 557 minecraft:purple_terracotta
setblock 388 189 557 minecraft:purple_concrete
fill 390 189 599 391 192 599 minecraft:purple_terracotta
fill 391 189 557 392 189 557 minecraft:purple_concrete
fill 393 189 562 393 190 562 minecraft:amethyst_block
setblock 404 189 592 minecraft:black_concrete
fill 406 189 587 406 191 587 minecraft:purple_concrete
setblock 406 189 593 minecraft:black_concrete
fill 406 189 599 406 191 599 minecraft:purple_terracotta
fill 407 189 557 408 191 557 minecraft:purple_terracotta
setblock 407 189 599 minecraft:purple_concrete
fill 408 189 586 410 194 586 minecraft:purple_concrete
fill 410 189 587 410 195 587 minecraft:purple_concrete
fill 410 189 590 410 192 590 minecraft:purple_concrete
setblock 410 189 599 minecraft:purple_concrete
fill 411 189 599 411 192 599 minecraft:purple_terracotta
setblock 412 189 557 minecraft:purple_concrete
setblock 418 189 562 minecraft:purple_concrete
fill 418 189 563 418 191 563 minecraft:purple_terracotta
fill 418 189 567 418 191 567 minecraft:purple_terracotta
fill 418 189 578 418 192 578 minecraft:purple_terracotta
setblock 418 189 579 minecraft:purple_concrete
fill 418 189 582 418 189 583 minecraft:purple_concrete
setblock 418 189 599 minecraft:purple_concrete
fill 376 190 557 376 195 558 minecraft:purple_terracotta
fill 376 190 567 376 190 568 minecraft:purple_concrete
fill 376 190 569 376 195 570 minecraft:purple_terracotta
setblock 376 190 575 minecraft:purple_terracotta
fill 376 190 576 376 191 576 minecraft:purple_concrete
fill 376 190 577 376 195 578 minecraft:purple_terracotta
setblock 376 190 579 minecraft:purple_concrete
fill 376 190 581 376 195 581 minecraft:purple_terracotta
fill 376 190 587 376 191 588 minecraft:purple_concrete
fill 376 190 589 376 195 590 minecraft:purple_terracotta
fill 376 190 598 376 195 598 minecraft:purple_terracotta
fill 376 190 599 377 190 599 minecraft:purple_concrete
fill 378 190 599 379 195 599 minecraft:purple_terracotta
fill 379 190 557 380 195 557 minecraft:purple_terracotta
fill 381 190 557 382 191 557 minecraft:purple_concrete
fill 384 190 599 385 191 599 minecraft:purple_concrete
fill 386 190 599 387 195 599 minecraft:purple_terracotta
fill 388 190 557 388 195 557 minecraft:purple_terracotta
setblock 388 190 599 minecraft:purple_concrete
setblock 390 190 557 minecraft:purple_concrete
fill 391 190 557 392 195 557 minecraft:purple_terracotta
fill 393 190 557 393 191 557 minecraft:purple_concrete
setblock 394 190 557 minecraft:purple_terracotta
fill 396 190 599 397 191 599 minecraft:purple_concrete
fill 398 190 599 399 195 599 minecraft:purple_terracotta
fill 399 190 557 400 195 557 minecraft:purple_terracotta
fill 401 190 557 402 191 557 minecraft:purple_concrete
setblock 404 190 599 minecraft:purple_terracotta
fill 405 190 590 408 190 591 minecraft:purple_concrete
fill 405 190 599 405 191 599 minecraft:purple_concrete
fill 406 190 592 408 190 592 minecraft:purple_concrete
fill 407 190 586 407 192 586 minecraft:purple_concrete
fill 407 190 599 407 195 599 minecraft:purple_terracotta
fill 408 190 599 409 190 599 minecraft:purple_concrete
fill 409 190 557 409 193 557 minecraft:purple_terracotta
fill 409 190 585 410 194 585 minecraft:purple_concrete
setblock 410 190 557 minecraft:purple_concrete
fill 410 190 599 410 195 599 minecraft:purple_terracotta
fill 411 190 557 412 195 557 minecraft:purple_terracotta
fill 411 190 586 411 193 589 minecraft:purple_concrete
fill 413 190 557 414 191 557 minecraft:purple_concrete
fill 416 190 599 417 191 599 minecraft:purple_concrete
fill 418 190 558 418 192 559 minecraft:purple_terracotta
fill 418 190 560 418 190 561 minecraft:purple_concrete
fill 418 190 562 418 195 562 minecraft:purple_terracotta
fill 418 190 564 418 191 564 minecraft:purple_concrete
setblock 418 190 565 minecraft:purple_terracotta
fill 418 190 570 418 195 571 minecraft:purple_terracotta
fill 418 190 572 418 191 573 minecraft:purple_concrete
fill 418 190 579 418 195 579 minecraft:purple_terracotta
setblock 418 190 581 minecraft:purple_concrete
fill 418 190 582 418 195 583 minecraft:purple_terracotta
fill 418 190 584 418 191 584 minecraft:purple_concrete
setblock 418 190 585 minecraft:purple_terracotta
fill 418 190 590 418 195 591 minecraft:purple_terracotta
fill 418 190 592 418 190 593 minecraft:purple_concrete
fill 418 190 599 418 195 599 minecraft:purple_terracotta
setblock 376 191 564 minecraft:purple_concrete
setblock 376 191 567 minecraft:purple_concrete
fill 376 191 568 376 194 568 minecraft:purple_terracotta
setblock 376 191 575 minecraft:purple_concrete
fill 376 191 579 376 194 579 minecraft:purple_terracotta
fill 376 191 595 376 191 596 minecraft:purple_concrete
setblock 376 191 599 minecraft:purple_concrete
fill 377 191 599 377 194 599 minecraft:purple_terracotta
fill 388 191 599 388 194 599 minecraft:purple_terracotta
fill 390 191 557 390 194 557 minecraft:purple_terracotta
setblock 393 191 599 minecraft:purple_concrete
setblock 394 191 557 minecraft:purple_concrete
setblock 404 191 599 minecraft:purple_concrete
setblock 405 191 557 minecraft:purple_concrete
fill 406 191 589 408 191 591 minecraft:purple_concrete
fill 408 191 585 408 194 585 minecraft:purple_concrete
fill 408 191 599 409 194 599 minecraft:purple_terracotta
fill 409 191 584 411 192 584 minecraft:purple_concrete
fill 409 191 589 409 193 589 minecraft:purple_concrete
fill 410 191 557 410 193 557 minecraft:purple_terracotta
fill 411 191 585 412 193 585 minecraft:purple_concrete
fill 412 191 586 412 193 588 minecraft:purple_concrete
fill 418 191 560 418 194 560 minecraft:purple_terracotta
setblock 418 191 561 minecraft:purple_concrete
setblock 418 191 565 minecraft:purple_concrete
fill 418 191 581 418 194 581 minecraft:purple_terracotta
setblock 418 191 585 minecraft:purple_concrete
fill 418 191 592 418 194 592 minecraft:purple_terracotta
setblock 418 191 593 minecraft:purple_concrete
setblock 418 191 596 minecraft:purple_concrete
fill 376 192 562 376 193 562 minecraft:purple_concrete
fill 376 192 563 376 193 564 minecraft:purple_terracotta
fill 376 192 565 376 192 566 minecraft:purple_concrete
fill 376 192 567 376 197 567 minecraft:purple_terracotta
fill 376 192 573 376 193 574 minecraft:purple_concrete
fill 376 192 575 376 197 576 minecraft:purple_terracotta
fill 376 192 585 376 192 586 minecraft:purple_concrete
fill 376 192 587 376 197 588 minecraft:purple_terracotta
fill 376 192 594 376 193 594 minecraft:purple_concrete
fill 376 192 595 376 197 596 minecraft:purple_terracotta
setblock 376 192 597 minecraft:purple_concrete
fill 376 192 599 376 197 599 minecraft:purple_terracotta
fill 377 192 558 379 192 558 minecraft:obsidian
fill 377 192 560 377 192 562 minecraft:obsidian
fill 377 192 564 377 192 566 minecraft:obsidian
fill 377 192 568 377 192 570 minecraft:obsidian
fill 377 192 572 377 192 574 minecraft:obsidian
fill 377 192 576 377 192 578 minecraft:obsidian
fill 377 192 580 377 192 582 minecraft:obsidian
fill 377 192 584 377 192 586 minecraft:obsidian
fill 377 192 588 377 192 590 minecraft:obsidian
fill 377 192 592 377 192 594 minecraft:obsidian
fill 377 192 596 377 192 598 minecraft:obsidian
fill 379 192 598 381 192 598 minecraft:obsidian
fill 381 192 557 382 197 557 minecraft:purple_terracotta
fill 381 192 558 383 192 558 minecraft:obsidian
fill 382 192 599 383 193 599 minecraft:purple_concrete
fill 383 192 557 384 192 557 minecraft:purple_concrete
fill 383 192 598 385 192 598 minecraft:obsidian
fill 384 192 599 385 197 599 minecraft:purple_terracotta
fill 385 192 558 387 192 558 minecraft:obsidian
fill 387 192 598 389 192 598 minecraft:obsidian
fill 389 192 558 391 192 558 minecraft:obsidian
fill 391 192 598 393 192 598 minecraft:obsidian
fill 393 192 557 394 197 557 minecraft:purple_terracotta
fill 393 192 558 395 192 558 minecraft:obsidian
fill 393 192 599 393 197 599 minecraft:purple_terracotta
fill 394 192 599 395 192 599 minecraft:purple_concrete
fill 395 192 557 396 193 557 minecraft:purple_concrete
fill 395 192 598 397 192 598 minecraft:obsidian
fill 396 192 599 397 197 599 minecraft:purple_terracotta
fill 397 192 558 399 192 558 minecraft:obsidian
fill 399 192 598 401 192 598 minecraft:obsidian
fill 400 192 592 400 193 592 minecraft:amethyst_block
fill 401 192 557 402 194 557 minecraft:purple_terracotta
fill 401 192 558 403 192 558 minecraft:obsidian
fill 402 192 599 403 193 599 minecraft:purple_concrete
fill 403 192 557 404 192 557 minecraft:purple_concrete
fill 403 192 598 405 192 598 minecraft:obsidian
fill 404 192 599 405 197 599 minecraft:purple_terracotta
fill 405 192 557 405 197 557 minecraft:purple_terracotta
fill 405 192 558 407 192 558 minecraft:obsidian
fill 406 192 590 406 194 591 minecraft:amethyst_block
setblock 406 192 599 minecraft:purple_concrete
fill 407 192 557 407 193 557 minecraft:purple_concrete
fill 407 192 588 408 192 590 minecraft:purple_concrete
fill 407 192 598 409 192 598 minecraft:obsidian
setblock 408 192 557 minecraft:purple_terracotta
fill 409 192 558 411 192 558 minecraft:obsidian
fill 410 192 583 412 192 583 minecraft:purple_concrete
fill 411 192 598 413 192 598 minecraft:obsidian
setblock 412 192 584 minecraft:purple_concrete
fill 413 192 557 414 197 557 minecraft:purple_terracotta
fill 413 192 558 415 192 558 minecraft:obsidian
fill 413 192 585 413 194 585 minecraft:purple_concrete
fill 414 192 599 415 193 599 minecraft:purple_concrete
fill 415 192 557 416 193 557 minecraft:purple_concrete
fill 415 192 598 417 192 598 minecraft:obsidian
fill 416 192 599 417 197 599 minecraft:purple_terracotta
fill 417 192 558 417 192 560 minecraft:obsidian
fill 417 192 562 417 192 564 minecraft:obsidian
fill 417 192 566 417 192 568 minecraft:obsidian
fill 417 192 570 417 192 572 minecraft:obsidian
fill 417 192 574 417 192 576 minecraft:obsidian
fill 417 192 578 417 192 580 minecraft:obsidian
fill 417 192 582 417 192 584 minecraft:obsidian
fill 417 192 586 417 192 588 minecraft:obsidian
fill 417 192 590 417 192 592 minecraft:obsidian
fill 417 192 594 417 192 596 minecraft:obsidian
fill 418 192 561 418 194 561 minecraft:purple_terracotta
setblock 418 192 563 minecraft:purple_concrete
fill 418 192 564 418 197 565 minecraft:purple_terracotta
fill 418 192 566 418 193 567 minecraft:purple_concrete
fill 418 192 572 418 197 573 minecraft:purple_terracotta
fill 418 192 574 418 192 575 minecraft:purple_concrete
fill 418 192 584 418 197 585 minecraft:purple_terracotta
fill 418 192 586 418 193 587 minecraft:purple_concrete
fill 418 192 593 418 197 593 minecraft:purple_terracotta
fill 418 192 594 418 192 595 minecraft:purple_concrete
fill 418 192 596 418 197 596 minecraft:purple_terracotta
fill 418 192 598 418 193 598 minecraft:purple_concrete
setblock 376 193 561 minecraft:purple_concrete
fill 376 193 565 376 196 566 minecraft:purple_terracotta
setblock 376 193 582 minecraft:purple_concrete
setblock 376 193 585 minecraft:purple_concrete
fill 376 193 586 376 196 586 minecraft:purple_terracotta
setblock 376 193 593 minecraft:purple_concrete
fill 376 193 597 376 196 597 minecraft:purple_terracotta
fill 383 193 557 383 196 557 minecraft:purple_terracotta
setblock 384 193 557 minecraft:purple_concrete
setblock 387 193 557 minecraft:purple_concrete
fill 390 193 599 391 193 599 minecraft:purple_concrete
setblock 394 193 599 minecraft:purple_concrete
fill 395 193 599 395 196 599 minecraft:purple_terracotta
fill 403 193 557 403 196 557 minecraft:purple_terracotta
setblock 404 193 557 minecraft:purple_concrete
fill 406 193 599 406 196 599 minecraft:purple_terracotta
fill 407 193 590 407 194 590 minecraft:amethyst_block
setblock 408 193 557 minecraft:purple_concrete
fill 408 193 587 408 193 589 minecraft:purple_concrete
fill 409 193 583 410 193 584 minecraft:purple_concrete
fill 409 193 587 409 194 587 minecraft:purple_concrete
setblock 410 193 582 minecraft:purple_concrete
fill 411 193 582 412 197 584 minecraft:black_concrete
setblock 411 193 599 minecraft:purple_concrete
fill 413 193 582 413 198 583 minecraft:black_concrete
setblock 413 193 584 minecraft:purple_concrete
fill 413 193 586 413 194 586 minecraft:purple_concrete
setblock 418 193 558 minecraft:purple_concrete
fill 418 193 559 418 195 559 minecraft:purple_terracotta
fill 418 193 563 418 196 563 minecraft:purple_terracotta
fill 418 193 574 418 196 574 minecraft:purple_terracotta
setblock 418 193 575 minecraft:purple_concrete
setblock 418 193 578 minecraft:purple_concrete
fill 418 193 594 418 196 595 minecraft:purple_terracotta
fill 376 194 559 376 195 560 minecraft:purple_concrete
fill 376 194 561 376 199 562 minecraft:purple_terracotta
setblock 376 194 563 minecraft:purple_concrete
fill 376 194 564 376 197 564 minecraft:purple_terracotta
fill 376 194 571 376 195 572 minecraft:purple_concrete
fill 376 194 573 376 199 574 minecraft:purple_terracotta
fill 376 194 580 376 195 580 minecraft:purple_concrete
fill 376 194 582 376 199 582 minecraft:purple_terracotta
fill 376 194 583 376 194 584 minecraft:purple_concrete
fill 376 194 585 376 199 585 minecraft:purple_terracotta
fill 376 194 591 376 195 592 minecraft:purple_concrete
fill 376 194 593 376 199 594 minecraft:purple_terracotta
fill 377 194 557 378 195 557 minecraft:purple_concrete
fill 380 194 599 381 194 599 minecraft:purple_concrete
fill 382 194 599 383 199 599 minecraft:purple_terracotta
fill 384 194 557 384 199 557 minecraft:purple_terracotta
fill 385 194 557 386 194 557 minecraft:purple_concrete
fill 387 194 557 387 199 557 minecraft:purple_terracotta
fill 389 194 557 389 195 557 minecraft:purple_concrete
fill 389 194 599 389 195 599 minecraft:purple_concrete
fill 390 194 599 391 199 599 minecraft:purple_terracotta
fill 391 194 574 392 194 574 minecraft:stone_bricks
fill 391 194 576 391 194 577 minecraft:stone_bricks
fill 392 194 575 392 194 576 minecraft:stone_bricks
setblock 392 194 599 minecraft:purple_concrete
fill 394 194 599 394 199 599 minecraft:purple_terracotta
fill 395 194 557 396 199 557 minecraft:purple_terracotta
fill 396 194 569 397 194 569 minecraft:stone_bricks
setblock 396 194 582 minecraft:stone_bricks
fill 397 194 557 398 195 557 minecraft:purple_concrete
setblock 397 194 568 minecraft:stone_bricks
fill 398 194 583 399 194 584 minecraft:stone_bricks
fill 400 194 568 401 194 569 minecraft:stone_bricks
fill 400 194 592 400 203 592 minecraft:obsidian
fill 400 194 599 401 195 599 minecraft:purple_concrete
fill 402 194 599 403 199 599 minecraft:purple_terracotta
fill 404 194 557 404 196 557 minecraft:purple_terracotta
setblock 406 194 557 minecraft:purple_concrete
setblock 406 194 574 minecraft:stone_bricks
fill 406 194 576 407 194 577 minecraft:stone_bricks
fill 407 194 557 408 199 557 minecraft:purple_terracotta
setblock 407 194 578 minecraft:stone_bricks
setblock 408 194 587 minecraft:purple_concrete
fill 409 194 557 410 195 557 minecraft:purple_concrete
fill 409 194 583 409 194 584 minecraft:purple_concrete
fill 410 194 582 410 197 584 minecraft:black_concrete
fill 411 194 581 413 198 581 minecraft:black_concrete
fill 411 194 585 412 196 585 minecraft:black_concrete
fill 411 194 586 411 194 588 minecraft:purple_concrete
fill 411 194 599 411 199 599 minecraft:purple_terracotta
fill 412 194 580 412 196 580 minecraft:black_concrete
fill 412 194 586 412 194 587 minecraft:purple_concrete
fill 412 194 599 413 194 599 minecraft:purple_concrete
fill 413 194 584 413 197 584 minecraft:black_concrete
fill 414 194 582 414 197 583 minecraft:black_concrete
setblock 414 194 584 minecraft:purple_concrete
fill 414 194 599 415 199 599 minecraft:purple_terracotta
fill 415 194 557 416 199 557 minecraft:purple_terracotta
fill 417 194 557 418 194 557 minecraft:purple_concrete
fill 418 194 558 418 195 558 minecraft:purple_terracotta
fill 418 194 566 418 199 567 minecraft:purple_terracotta
fill 418 194 568 418 195 569 minecraft:purple_concrete
fill 418 194 575 418 199 575 minecraft:purple_terracotta
fill 418 194 576 418 194 577 minecraft:purple_concrete
fill 418 194 578 418 199 578 minecraft:purple_terracotta
fill 418 194 580 418 195 580 minecraft:purple_concrete
fill 418 194 586 418 199 587 minecraft:purple_terracotta
fill 418 194 588 418 195 589 minecraft:purple_concrete
setblock 418 194 597 minecraft:purple_concrete
schedule function dropper:buildpart/140_3 1t
