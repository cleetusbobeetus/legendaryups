fill 530 247 330 530 247 331 minecraft:dark_oak_planks
setblock 530 247 334 minecraft:dark_oak_planks
setblock 532 247 323 minecraft:stripped_dark_oak_log
setblock 534 247 363 minecraft:stripped_dark_oak_log
setblock 539 247 323 minecraft:stripped_dark_oak_log
setblock 541 247 363 minecraft:stripped_dark_oak_log
setblock 546 247 323 minecraft:stripped_dark_oak_log
setblock 548 247 363 minecraft:stripped_dark_oak_log
setblock 553 247 323 minecraft:stripped_dark_oak_log
setblock 555 247 363 minecraft:stripped_dark_oak_log
setblock 558 247 325 minecraft:stripped_dark_oak_log
setblock 558 247 332 minecraft:stripped_dark_oak_log
setblock 558 247 339 minecraft:stripped_dark_oak_log
setblock 558 247 346 minecraft:stripped_dark_oak_log
setblock 558 247 353 minecraft:stripped_dark_oak_log
setblock 558 247 360 minecraft:stripped_dark_oak_log
setblock 518 248 324 minecraft:stripped_dark_oak_log
setblock 518 248 331 minecraft:stripped_dark_oak_log
setblock 518 248 338 minecraft:stripped_dark_oak_log
setblock 518 248 345 minecraft:stripped_dark_oak_log
setblock 518 248 352 minecraft:stripped_dark_oak_log
setblock 518 248 359 minecraft:stripped_dark_oak_log
setblock 521 248 363 minecraft:stripped_dark_oak_log
setblock 524 248 323 minecraft:stripped_dark_oak_log
fill 525 248 332 525 250 332 minecraft:stripped_dark_oak_log
setblock 528 248 363 minecraft:stripped_dark_oak_log
setblock 531 248 323 minecraft:stripped_dark_oak_log
setblock 535 248 363 minecraft:stripped_dark_oak_log
setblock 538 248 323 minecraft:stripped_dark_oak_log
setblock 542 248 363 minecraft:stripped_dark_oak_log
setblock 545 248 323 minecraft:stripped_dark_oak_log
setblock 549 248 363 minecraft:stripped_dark_oak_log
setblock 552 248 323 minecraft:stripped_dark_oak_log
setblock 556 248 363 minecraft:stripped_dark_oak_log
setblock 558 248 324 minecraft:stripped_dark_oak_log
setblock 558 248 331 minecraft:stripped_dark_oak_log
setblock 558 248 338 minecraft:stripped_dark_oak_log
setblock 558 248 345 minecraft:stripped_dark_oak_log
setblock 558 248 352 minecraft:stripped_dark_oak_log
setblock 558 248 359 minecraft:stripped_dark_oak_log
fill 518 249 325 518 250 325 minecraft:stripped_dark_oak_log
fill 518 249 332 518 250 332 minecraft:stripped_dark_oak_log
fill 518 249 339 518 250 339 minecraft:stripped_dark_oak_log
fill 518 249 346 518 250 346 minecraft:stripped_dark_oak_log
fill 518 249 353 518 250 353 minecraft:stripped_dark_oak_log
fill 518 249 360 518 250 360 minecraft:stripped_dark_oak_log
fill 522 249 363 522 250 363 minecraft:stripped_dark_oak_log
fill 523 249 323 523 250 323 minecraft:stripped_dark_oak_log
fill 529 249 363 529 250 363 minecraft:stripped_dark_oak_log
fill 530 249 323 530 250 323 minecraft:stripped_dark_oak_log
fill 536 249 363 536 250 363 minecraft:stripped_dark_oak_log
fill 537 249 323 537 250 323 minecraft:stripped_dark_oak_log
fill 543 249 363 543 250 363 minecraft:stripped_dark_oak_log
fill 544 249 323 544 250 323 minecraft:stripped_dark_oak_log
fill 550 249 363 550 250 363 minecraft:stripped_dark_oak_log
fill 551 249 323 551 250 323 minecraft:stripped_dark_oak_log
fill 557 249 363 557 250 363 minecraft:stripped_dark_oak_log
fill 558 249 323 558 250 323 minecraft:stripped_dark_oak_log
fill 558 249 330 558 250 330 minecraft:stripped_dark_oak_log
fill 558 249 337 558 250 337 minecraft:stripped_dark_oak_log
fill 558 249 344 558 250 344 minecraft:stripped_dark_oak_log
fill 558 249 351 558 250 351 minecraft:stripped_dark_oak_log
fill 558 249 358 558 250 358 minecraft:stripped_dark_oak_log
fill 518 250 323 518 250 324 minecraft:stripped_dark_oak_log
fill 518 250 326 518 250 327 minecraft:stripped_dark_oak_log
fill 518 250 329 518 250 331 minecraft:stripped_dark_oak_log
fill 518 250 333 518 250 334 minecraft:stripped_dark_oak_log
fill 518 250 336 518 250 338 minecraft:stripped_dark_oak_log
fill 518 250 340 518 250 341 minecraft:stripped_dark_oak_log
fill 518 250 343 518 250 345 minecraft:stripped_dark_oak_log
fill 518 250 347 518 250 348 minecraft:stripped_dark_oak_log
fill 518 250 350 518 250 352 minecraft:stripped_dark_oak_log
fill 518 250 354 518 250 355 minecraft:stripped_dark_oak_log
fill 518 250 357 518 250 359 minecraft:stripped_dark_oak_log
fill 518 250 361 518 250 362 minecraft:stripped_dark_oak_log
setblock 519 250 323 minecraft:stripped_dark_oak_log
fill 519 250 363 521 250 363 minecraft:stripped_dark_oak_log
fill 521 250 323 522 250 323 minecraft:stripped_dark_oak_log
fill 523 250 363 524 250 363 minecraft:stripped_dark_oak_log
fill 524 250 323 526 250 323 minecraft:stripped_dark_oak_log
fill 526 250 363 528 250 363 minecraft:stripped_dark_oak_log
fill 528 250 323 529 250 323 minecraft:stripped_dark_oak_log
fill 530 250 363 531 250 363 minecraft:stripped_dark_oak_log
fill 531 250 323 533 250 323 minecraft:stripped_dark_oak_log
fill 533 250 363 535 250 363 minecraft:stripped_dark_oak_log
fill 535 250 323 536 250 323 minecraft:stripped_dark_oak_log
fill 537 250 363 538 250 363 minecraft:stripped_dark_oak_log
fill 538 250 323 540 250 323 minecraft:stripped_dark_oak_log
fill 540 250 363 542 250 363 minecraft:stripped_dark_oak_log
fill 542 250 323 543 250 323 minecraft:stripped_dark_oak_log
fill 544 250 363 545 250 363 minecraft:stripped_dark_oak_log
fill 545 250 323 547 250 323 minecraft:stripped_dark_oak_log
fill 547 250 363 549 250 363 minecraft:stripped_dark_oak_log
fill 549 250 323 550 250 323 minecraft:stripped_dark_oak_log
fill 551 250 363 552 250 363 minecraft:stripped_dark_oak_log
fill 552 250 323 554 250 323 minecraft:stripped_dark_oak_log
fill 554 250 363 556 250 363 minecraft:stripped_dark_oak_log
fill 556 250 323 557 250 323 minecraft:stripped_dark_oak_log
fill 558 250 324 558 250 326 minecraft:stripped_dark_oak_log
fill 558 250 328 558 250 329 minecraft:stripped_dark_oak_log
fill 558 250 331 558 250 333 minecraft:stripped_dark_oak_log
fill 558 250 335 558 250 336 minecraft:stripped_dark_oak_log
fill 558 250 338 558 250 340 minecraft:stripped_dark_oak_log
fill 558 250 342 558 250 343 minecraft:stripped_dark_oak_log
fill 558 250 345 558 250 347 minecraft:stripped_dark_oak_log
fill 558 250 349 558 250 350 minecraft:stripped_dark_oak_log
fill 558 250 352 558 250 354 minecraft:stripped_dark_oak_log
fill 558 250 356 558 250 357 minecraft:stripped_dark_oak_log
fill 558 250 359 558 250 361 minecraft:stripped_dark_oak_log
setblock 558 250 363 minecraft:stripped_dark_oak_log
setblock 518 251 327 minecraft:stripped_dark_oak_log
setblock 518 251 334 minecraft:stripped_dark_oak_log
setblock 518 251 341 minecraft:stripped_dark_oak_log
setblock 518 251 348 minecraft:stripped_dark_oak_log
setblock 518 251 355 minecraft:stripped_dark_oak_log
setblock 518 251 362 minecraft:stripped_dark_oak_log
setblock 521 251 323 minecraft:stripped_dark_oak_log
fill 524 251 331 526 253 333 minecraft:cherry_leaves[persistent=true]
setblock 524 251 363 minecraft:stripped_dark_oak_log
fill 525 251 334 526 253 334 minecraft:cherry_leaves[persistent=true]
fill 527 251 332 527 253 333 minecraft:cherry_leaves[persistent=true]
setblock 528 251 323 minecraft:stripped_dark_oak_log
setblock 531 251 363 minecraft:stripped_dark_oak_log
setblock 535 251 323 minecraft:stripped_dark_oak_log
setblock 538 251 363 minecraft:stripped_dark_oak_log
setblock 542 251 323 minecraft:stripped_dark_oak_log
setblock 545 251 363 minecraft:stripped_dark_oak_log
setblock 549 251 323 minecraft:stripped_dark_oak_log
fill 550 251 340 550 252 340 minecraft:cherry_leaves[persistent=true]
setblock 552 251 363 minecraft:stripped_dark_oak_log
setblock 556 251 323 minecraft:stripped_dark_oak_log
setblock 558 251 328 minecraft:stripped_dark_oak_log
setblock 558 251 335 minecraft:stripped_dark_oak_log
setblock 558 251 342 minecraft:stripped_dark_oak_log
setblock 558 251 349 minecraft:stripped_dark_oak_log
setblock 558 251 356 minecraft:stripped_dark_oak_log
setblock 520 252 325 minecraft:light[level=14]
setblock 520 252 333 minecraft:light[level=14]
setblock 520 252 341 minecraft:light[level=14]
setblock 520 252 349 minecraft:light[level=14]
setblock 520 252 357 minecraft:light[level=14]
fill 523 252 332 523 252 333 minecraft:cherry_leaves[persistent=true]
setblock 524 252 334 minecraft:cherry_leaves[persistent=true]
setblock 527 252 331 minecraft:cherry_leaves[persistent=true]
setblock 527 252 334 minecraft:cherry_leaves[persistent=true]
setblock 528 252 325 minecraft:light[level=14]
setblock 528 252 333 minecraft:light[level=14]
setblock 528 252 341 minecraft:light[level=14]
setblock 528 252 349 minecraft:light[level=14]
setblock 528 252 357 minecraft:light[level=14]
setblock 536 252 325 minecraft:light[level=14]
setblock 536 252 333 minecraft:light[level=14]
setblock 536 252 349 minecraft:light[level=14]
setblock 536 252 357 minecraft:light[level=14]
setblock 544 252 325 minecraft:light[level=14]
setblock 544 252 333 minecraft:light[level=14]
setblock 544 252 341 minecraft:light[level=14]
setblock 544 252 349 minecraft:light[level=14]
setblock 544 252 357 minecraft:light[level=14]
setblock 552 252 325 minecraft:light[level=14]
setblock 552 252 333 minecraft:light[level=14]
setblock 552 252 341 minecraft:light[level=14]
setblock 552 252 349 minecraft:light[level=14]
setblock 552 252 357 minecraft:light[level=14]
setblock 518 253 329 minecraft:stripped_dark_oak_log
setblock 518 253 336 minecraft:stripped_dark_oak_log
setblock 518 253 343 minecraft:stripped_dark_oak_log
setblock 518 253 350 minecraft:stripped_dark_oak_log
setblock 518 253 357 minecraft:stripped_dark_oak_log
setblock 519 253 323 minecraft:stripped_dark_oak_log
setblock 519 253 363 minecraft:stripped_dark_oak_log
setblock 526 253 323 minecraft:stripped_dark_oak_log
setblock 526 253 363 minecraft:stripped_dark_oak_log
setblock 533 253 323 minecraft:stripped_dark_oak_log
setblock 533 253 363 minecraft:stripped_dark_oak_log
setblock 540 253 323 minecraft:stripped_dark_oak_log
setblock 540 253 363 minecraft:stripped_dark_oak_log
setblock 547 253 323 minecraft:stripped_dark_oak_log
setblock 547 253 363 minecraft:stripped_dark_oak_log
setblock 554 253 323 minecraft:stripped_dark_oak_log
setblock 554 253 363 minecraft:stripped_dark_oak_log
setblock 558 253 326 minecraft:stripped_dark_oak_log
setblock 558 253 333 minecraft:stripped_dark_oak_log
setblock 558 253 340 minecraft:stripped_dark_oak_log
setblock 558 253 347 minecraft:stripped_dark_oak_log
setblock 558 253 354 minecraft:stripped_dark_oak_log
setblock 558 253 361 minecraft:stripped_dark_oak_log
setblock 518 254 323 minecraft:stripped_dark_oak_log
setblock 518 254 330 minecraft:stripped_dark_oak_log
setblock 518 254 337 minecraft:stripped_dark_oak_log
setblock 518 254 344 minecraft:stripped_dark_oak_log
setblock 518 254 351 minecraft:stripped_dark_oak_log
setblock 518 254 358 minecraft:stripped_dark_oak_log
setblock 520 254 363 minecraft:stripped_dark_oak_log
setblock 525 254 323 minecraft:stripped_dark_oak_log
setblock 527 254 363 minecraft:stripped_dark_oak_log
setblock 532 254 323 minecraft:stripped_dark_oak_log
setblock 534 254 363 minecraft:stripped_dark_oak_log
setblock 539 254 323 minecraft:stripped_dark_oak_log
setblock 541 254 363 minecraft:stripped_dark_oak_log
setblock 546 254 323 minecraft:stripped_dark_oak_log
setblock 548 254 363 minecraft:stripped_dark_oak_log
setblock 553 254 323 minecraft:stripped_dark_oak_log
setblock 555 254 363 minecraft:stripped_dark_oak_log
setblock 558 254 325 minecraft:stripped_dark_oak_log
setblock 558 254 332 minecraft:stripped_dark_oak_log
setblock 558 254 339 minecraft:stripped_dark_oak_log
setblock 558 254 346 minecraft:stripped_dark_oak_log
setblock 558 254 353 minecraft:stripped_dark_oak_log
setblock 558 254 360 minecraft:stripped_dark_oak_log
setblock 518 255 324 minecraft:stripped_dark_oak_log
setblock 518 255 331 minecraft:stripped_dark_oak_log
setblock 518 255 338 minecraft:stripped_dark_oak_log
setblock 518 255 345 minecraft:stripped_dark_oak_log
setblock 518 255 352 minecraft:stripped_dark_oak_log
setblock 518 255 359 minecraft:stripped_dark_oak_log
setblock 521 255 363 minecraft:stripped_dark_oak_log
setblock 524 255 323 minecraft:stripped_dark_oak_log
setblock 528 255 363 minecraft:stripped_dark_oak_log
setblock 531 255 323 minecraft:stripped_dark_oak_log
setblock 535 255 363 minecraft:stripped_dark_oak_log
setblock 538 255 323 minecraft:stripped_dark_oak_log
setblock 542 255 363 minecraft:stripped_dark_oak_log
setblock 545 255 323 minecraft:stripped_dark_oak_log
setblock 549 255 363 minecraft:stripped_dark_oak_log
setblock 552 255 323 minecraft:stripped_dark_oak_log
setblock 556 255 363 minecraft:stripped_dark_oak_log
setblock 558 255 324 minecraft:stripped_dark_oak_log
setblock 558 255 331 minecraft:stripped_dark_oak_log
setblock 558 255 338 minecraft:stripped_dark_oak_log
setblock 558 255 345 minecraft:stripped_dark_oak_log
setblock 558 255 352 minecraft:stripped_dark_oak_log
setblock 558 255 359 minecraft:stripped_dark_oak_log
setblock 518 256 325 minecraft:stripped_dark_oak_log
setblock 518 256 332 minecraft:stripped_dark_oak_log
setblock 518 256 339 minecraft:stripped_dark_oak_log
setblock 518 256 346 minecraft:stripped_dark_oak_log
setblock 518 256 353 minecraft:stripped_dark_oak_log
setblock 518 256 360 minecraft:stripped_dark_oak_log
setblock 522 256 363 minecraft:stripped_dark_oak_log
setblock 523 256 323 minecraft:stripped_dark_oak_log
setblock 529 256 363 minecraft:stripped_dark_oak_log
setblock 530 256 323 minecraft:stripped_dark_oak_log
setblock 536 256 363 minecraft:stripped_dark_oak_log
setblock 537 256 323 minecraft:stripped_dark_oak_log
setblock 543 256 363 minecraft:stripped_dark_oak_log
setblock 544 256 323 minecraft:stripped_dark_oak_log
setblock 550 256 363 minecraft:stripped_dark_oak_log
setblock 551 256 323 minecraft:stripped_dark_oak_log
setblock 557 256 363 minecraft:stripped_dark_oak_log
setblock 558 256 323 minecraft:stripped_dark_oak_log
setblock 558 256 330 minecraft:stripped_dark_oak_log
setblock 558 256 337 minecraft:stripped_dark_oak_log
setblock 558 256 344 minecraft:stripped_dark_oak_log
setblock 558 256 351 minecraft:stripped_dark_oak_log
setblock 558 256 358 minecraft:stripped_dark_oak_log
setblock 518 257 326 minecraft:stripped_dark_oak_log
setblock 518 257 333 minecraft:stripped_dark_oak_log
setblock 518 257 340 minecraft:stripped_dark_oak_log
setblock 518 257 347 minecraft:stripped_dark_oak_log
setblock 518 257 354 minecraft:stripped_dark_oak_log
setblock 518 257 361 minecraft:stripped_dark_oak_log
setblock 522 257 323 minecraft:stripped_dark_oak_log
setblock 523 257 363 minecraft:stripped_dark_oak_log
setblock 529 257 323 minecraft:stripped_dark_oak_log
setblock 530 257 363 minecraft:stripped_dark_oak_log
setblock 536 257 323 minecraft:stripped_dark_oak_log
setblock 537 257 363 minecraft:stripped_dark_oak_log
setblock 543 257 323 minecraft:stripped_dark_oak_log
setblock 544 257 363 minecraft:stripped_dark_oak_log
setblock 550 257 323 minecraft:stripped_dark_oak_log
setblock 551 257 363 minecraft:stripped_dark_oak_log
setblock 557 257 323 minecraft:stripped_dark_oak_log
setblock 558 257 329 minecraft:stripped_dark_oak_log
setblock 558 257 336 minecraft:stripped_dark_oak_log
setblock 558 257 343 minecraft:stripped_dark_oak_log
setblock 558 257 350 minecraft:stripped_dark_oak_log
setblock 558 257 357 minecraft:stripped_dark_oak_log
setblock 558 257 363 minecraft:stripped_dark_oak_log
setblock 518 258 327 minecraft:stripped_dark_oak_log
setblock 518 258 334 minecraft:stripped_dark_oak_log
setblock 518 258 341 minecraft:stripped_dark_oak_log
setblock 518 258 348 minecraft:stripped_dark_oak_log
setblock 518 258 355 minecraft:stripped_dark_oak_log
setblock 518 258 362 minecraft:stripped_dark_oak_log
setblock 521 258 323 minecraft:stripped_dark_oak_log
setblock 524 258 363 minecraft:stripped_dark_oak_log
setblock 528 258 323 minecraft:stripped_dark_oak_log
fill 530 258 323 530 259 325 minecraft:iron_bars
setblock 531 258 363 minecraft:stripped_dark_oak_log
setblock 535 258 323 minecraft:stripped_dark_oak_log
setblock 538 258 363 minecraft:stripped_dark_oak_log
setblock 542 258 323 minecraft:stripped_dark_oak_log
setblock 545 258 363 minecraft:stripped_dark_oak_log
setblock 549 258 323 minecraft:stripped_dark_oak_log
setblock 552 258 363 minecraft:stripped_dark_oak_log
setblock 556 258 323 minecraft:stripped_dark_oak_log
setblock 558 258 328 minecraft:stripped_dark_oak_log
setblock 558 258 335 minecraft:stripped_dark_oak_log
setblock 558 258 342 minecraft:stripped_dark_oak_log
setblock 558 258 349 minecraft:stripped_dark_oak_log
setblock 558 258 356 minecraft:stripped_dark_oak_log
fill 525 259 343 526 260 343 minecraft:cherry_leaves[persistent=true]
fill 518 260 323 518 260 327 minecraft:stripped_dark_oak_log
fill 518 260 329 518 260 334 minecraft:stripped_dark_oak_log
fill 518 260 336 518 260 341 minecraft:stripped_dark_oak_log
fill 518 260 343 518 260 348 minecraft:stripped_dark_oak_log
fill 518 260 350 518 260 355 minecraft:stripped_dark_oak_log
fill 518 260 357 518 260 362 minecraft:stripped_dark_oak_log
setblock 519 260 323 minecraft:stripped_dark_oak_log
fill 519 260 363 524 260 363 minecraft:stripped_dark_oak_log
setblock 520 260 325 minecraft:light[level=14]
setblock 520 260 333 minecraft:light[level=14]
setblock 520 260 341 minecraft:light[level=14]
setblock 520 260 349 minecraft:light[level=14]
setblock 520 260 357 minecraft:light[level=14]
fill 521 260 323 526 260 323 minecraft:stripped_dark_oak_log
fill 526 260 363 531 260 363 minecraft:stripped_dark_oak_log
fill 528 260 323 533 260 323 minecraft:stripped_dark_oak_log
setblock 528 260 325 minecraft:light[level=14]
setblock 528 260 333 minecraft:light[level=14]
setblock 528 260 341 minecraft:light[level=14]
setblock 528 260 349 minecraft:light[level=14]
setblock 528 260 357 minecraft:light[level=14]
fill 533 260 363 538 260 363 minecraft:stripped_dark_oak_log
fill 535 260 323 540 260 323 minecraft:stripped_dark_oak_log
setblock 536 260 325 minecraft:light[level=14]
setblock 536 260 333 minecraft:light[level=14]
setblock 536 260 349 minecraft:light[level=14]
setblock 536 260 357 minecraft:light[level=14]
fill 540 260 363 545 260 363 minecraft:stripped_dark_oak_log
fill 542 260 323 547 260 323 minecraft:stripped_dark_oak_log
setblock 544 260 325 minecraft:light[level=14]
setblock 544 260 333 minecraft:light[level=14]
setblock 544 260 341 minecraft:light[level=14]
setblock 544 260 349 minecraft:light[level=14]
setblock 544 260 357 minecraft:light[level=14]
fill 547 260 363 552 260 363 minecraft:stripped_dark_oak_log
fill 549 260 323 554 260 323 minecraft:stripped_dark_oak_log
setblock 552 260 325 minecraft:light[level=14]
setblock 552 260 333 minecraft:light[level=14]
setblock 552 260 341 minecraft:light[level=14]
setblock 552 260 349 minecraft:light[level=14]
setblock 552 260 357 minecraft:light[level=14]
fill 554 260 363 558 260 363 minecraft:stripped_dark_oak_log
fill 556 260 323 558 260 323 minecraft:stripped_dark_oak_log
fill 558 260 324 558 260 326 minecraft:stripped_dark_oak_log
fill 558 260 328 558 260 333 minecraft:stripped_dark_oak_log
fill 558 260 335 558 260 340 minecraft:stripped_dark_oak_log
fill 558 260 342 558 260 347 minecraft:stripped_dark_oak_log
fill 558 260 349 558 260 354 minecraft:stripped_dark_oak_log
fill 558 260 356 558 260 361 minecraft:stripped_dark_oak_log
setblock 518 261 323 minecraft:stripped_dark_oak_log
setblock 518 261 330 minecraft:stripped_dark_oak_log
setblock 518 261 337 minecraft:stripped_dark_oak_log
setblock 518 261 344 minecraft:stripped_dark_oak_log
setblock 518 261 351 minecraft:stripped_dark_oak_log
setblock 518 261 358 minecraft:stripped_dark_oak_log
setblock 520 261 363 minecraft:stripped_dark_oak_log
setblock 525 261 323 minecraft:stripped_dark_oak_log
setblock 527 261 363 minecraft:stripped_dark_oak_log
setblock 532 261 323 minecraft:stripped_dark_oak_log
setblock 534 261 363 minecraft:stripped_dark_oak_log
setblock 539 261 323 minecraft:stripped_dark_oak_log
setblock 541 261 363 minecraft:stripped_dark_oak_log
setblock 546 261 323 minecraft:stripped_dark_oak_log
setblock 548 261 363 minecraft:stripped_dark_oak_log
setblock 553 261 323 minecraft:stripped_dark_oak_log
setblock 555 261 363 minecraft:stripped_dark_oak_log
setblock 558 261 325 minecraft:stripped_dark_oak_log
setblock 558 261 332 minecraft:stripped_dark_oak_log
setblock 558 261 339 minecraft:stripped_dark_oak_log
setblock 558 261 346 minecraft:stripped_dark_oak_log
setblock 558 261 353 minecraft:stripped_dark_oak_log
setblock 558 261 360 minecraft:stripped_dark_oak_log
setblock 518 262 324 minecraft:stripped_dark_oak_log
setblock 518 262 331 minecraft:stripped_dark_oak_log
setblock 518 262 338 minecraft:stripped_dark_oak_log
setblock 518 262 345 minecraft:stripped_dark_oak_log
setblock 518 262 352 minecraft:stripped_dark_oak_log
setblock 518 262 359 minecraft:stripped_dark_oak_log
setblock 521 262 363 minecraft:stripped_dark_oak_log
setblock 524 262 323 minecraft:stripped_dark_oak_log
setblock 528 262 363 minecraft:stripped_dark_oak_log
setblock 531 262 323 minecraft:stripped_dark_oak_log
setblock 535 262 363 minecraft:stripped_dark_oak_log
setblock 538 262 323 minecraft:stripped_dark_oak_log
setblock 542 262 363 minecraft:stripped_dark_oak_log
setblock 545 262 323 minecraft:stripped_dark_oak_log
setblock 549 262 363 minecraft:stripped_dark_oak_log
setblock 552 262 323 minecraft:stripped_dark_oak_log
setblock 556 262 363 minecraft:stripped_dark_oak_log
setblock 558 262 324 minecraft:stripped_dark_oak_log
setblock 558 262 331 minecraft:stripped_dark_oak_log
setblock 558 262 338 minecraft:stripped_dark_oak_log
setblock 558 262 345 minecraft:stripped_dark_oak_log
setblock 558 262 352 minecraft:stripped_dark_oak_log
setblock 558 262 359 minecraft:stripped_dark_oak_log
setblock 518 263 325 minecraft:stripped_dark_oak_log
setblock 518 263 332 minecraft:stripped_dark_oak_log
setblock 518 263 339 minecraft:stripped_dark_oak_log
setblock 518 263 346 minecraft:stripped_dark_oak_log
setblock 518 263 353 minecraft:stripped_dark_oak_log
setblock 518 263 360 minecraft:stripped_dark_oak_log
setblock 522 263 363 minecraft:stripped_dark_oak_log
setblock 523 263 323 minecraft:stripped_dark_oak_log
setblock 529 263 363 minecraft:stripped_dark_oak_log
setblock 530 263 323 minecraft:stripped_dark_oak_log
setblock 536 263 363 minecraft:stripped_dark_oak_log
setblock 537 263 323 minecraft:stripped_dark_oak_log
setblock 543 263 363 minecraft:stripped_dark_oak_log
setblock 544 263 323 minecraft:stripped_dark_oak_log
setblock 550 263 363 minecraft:stripped_dark_oak_log
setblock 551 263 323 minecraft:stripped_dark_oak_log
setblock 557 263 363 minecraft:stripped_dark_oak_log
setblock 558 263 323 minecraft:stripped_dark_oak_log
setblock 558 263 330 minecraft:stripped_dark_oak_log
setblock 558 263 337 minecraft:stripped_dark_oak_log
setblock 558 263 344 minecraft:stripped_dark_oak_log
setblock 558 263 351 minecraft:stripped_dark_oak_log
setblock 558 263 358 minecraft:stripped_dark_oak_log
setblock 518 264 326 minecraft:stripped_dark_oak_log
setblock 518 264 333 minecraft:stripped_dark_oak_log
setblock 518 264 340 minecraft:stripped_dark_oak_log
setblock 518 264 347 minecraft:stripped_dark_oak_log
setblock 518 264 354 minecraft:stripped_dark_oak_log
setblock 518 264 361 minecraft:stripped_dark_oak_log
setblock 522 264 323 minecraft:stripped_dark_oak_log
setblock 523 264 363 minecraft:stripped_dark_oak_log
setblock 529 264 323 minecraft:stripped_dark_oak_log
setblock 530 264 363 minecraft:stripped_dark_oak_log
setblock 536 264 323 minecraft:stripped_dark_oak_log
setblock 537 264 363 minecraft:stripped_dark_oak_log
setblock 543 264 323 minecraft:stripped_dark_oak_log
setblock 544 264 363 minecraft:stripped_dark_oak_log
setblock 550 264 323 minecraft:stripped_dark_oak_log
setblock 551 264 363 minecraft:stripped_dark_oak_log
setblock 557 264 323 minecraft:stripped_dark_oak_log
setblock 558 264 329 minecraft:stripped_dark_oak_log
setblock 558 264 336 minecraft:stripped_dark_oak_log
setblock 558 264 343 minecraft:stripped_dark_oak_log
setblock 558 264 350 minecraft:stripped_dark_oak_log
setblock 558 264 357 minecraft:stripped_dark_oak_log
setblock 558 264 363 minecraft:stripped_dark_oak_log
setblock 518 265 327 minecraft:stripped_dark_oak_log
setblock 518 265 334 minecraft:stripped_dark_oak_log
setblock 518 265 341 minecraft:stripped_dark_oak_log
setblock 518 265 348 minecraft:stripped_dark_oak_log
setblock 518 265 355 minecraft:stripped_dark_oak_log
setblock 518 265 362 minecraft:stripped_dark_oak_log
setblock 521 265 323 minecraft:stripped_dark_oak_log
setblock 524 265 363 minecraft:stripped_dark_oak_log
setblock 528 265 323 minecraft:stripped_dark_oak_log
setblock 531 265 363 minecraft:stripped_dark_oak_log
setblock 535 265 323 minecraft:stripped_dark_oak_log
setblock 538 265 363 minecraft:stripped_dark_oak_log
setblock 542 265 323 minecraft:stripped_dark_oak_log
setblock 545 265 363 minecraft:stripped_dark_oak_log
setblock 549 265 323 minecraft:stripped_dark_oak_log
setblock 552 265 363 minecraft:stripped_dark_oak_log
setblock 556 265 323 minecraft:stripped_dark_oak_log
setblock 558 265 328 minecraft:stripped_dark_oak_log
setblock 558 265 335 minecraft:stripped_dark_oak_log
setblock 558 265 342 minecraft:stripped_dark_oak_log
setblock 558 265 349 minecraft:stripped_dark_oak_log
setblock 558 265 356 minecraft:stripped_dark_oak_log
setblock 518 267 329 minecraft:stripped_dark_oak_log
setblock 518 267 336 minecraft:stripped_dark_oak_log
setblock 518 267 343 minecraft:stripped_dark_oak_log
setblock 518 267 350 minecraft:stripped_dark_oak_log
setblock 518 267 357 minecraft:stripped_dark_oak_log
setblock 519 267 323 minecraft:stripped_dark_oak_log
setblock 519 267 363 minecraft:stripped_dark_oak_log
setblock 526 267 323 minecraft:stripped_dark_oak_log
setblock 526 267 363 minecraft:stripped_dark_oak_log
setblock 533 267 323 minecraft:stripped_dark_oak_log
setblock 533 267 363 minecraft:stripped_dark_oak_log
setblock 540 267 323 minecraft:stripped_dark_oak_log
setblock 540 267 363 minecraft:stripped_dark_oak_log
setblock 547 267 323 minecraft:stripped_dark_oak_log
setblock 547 267 363 minecraft:stripped_dark_oak_log
fill 550 267 350 551 268 351 minecraft:pink_wool
setblock 554 267 323 minecraft:stripped_dark_oak_log
setblock 554 267 363 minecraft:stripped_dark_oak_log
setblock 558 267 326 minecraft:stripped_dark_oak_log
setblock 558 267 333 minecraft:stripped_dark_oak_log
setblock 558 267 340 minecraft:stripped_dark_oak_log
setblock 558 267 347 minecraft:stripped_dark_oak_log
setblock 558 267 354 minecraft:stripped_dark_oak_log
setblock 558 267 361 minecraft:stripped_dark_oak_log
setblock 518 268 323 minecraft:stripped_dark_oak_log
setblock 518 268 330 minecraft:stripped_dark_oak_log
setblock 518 268 337 minecraft:stripped_dark_oak_log
setblock 518 268 344 minecraft:stripped_dark_oak_log
setblock 518 268 351 minecraft:stripped_dark_oak_log
setblock 518 268 358 minecraft:stripped_dark_oak_log
setblock 520 268 325 minecraft:light[level=14]
setblock 520 268 333 minecraft:light[level=14]
setblock 520 268 341 minecraft:light[level=14]
setblock 520 268 349 minecraft:light[level=14]
setblock 520 268 357 minecraft:light[level=14]
setblock 520 268 363 minecraft:stripped_dark_oak_log
setblock 525 268 323 minecraft:stripped_dark_oak_log
setblock 527 268 363 minecraft:stripped_dark_oak_log
setblock 528 268 325 minecraft:light[level=14]
setblock 528 268 333 minecraft:light[level=14]
setblock 528 268 341 minecraft:light[level=14]
setblock 528 268 349 minecraft:light[level=14]
setblock 528 268 357 minecraft:light[level=14]
setblock 532 268 323 minecraft:stripped_dark_oak_log
setblock 534 268 363 minecraft:stripped_dark_oak_log
setblock 536 268 325 minecraft:light[level=14]
setblock 536 268 333 minecraft:light[level=14]
setblock 536 268 349 minecraft:light[level=14]
setblock 536 268 357 minecraft:light[level=14]
setblock 539 268 323 minecraft:stripped_dark_oak_log
setblock 541 268 363 minecraft:stripped_dark_oak_log
setblock 544 268 325 minecraft:light[level=14]
setblock 544 268 333 minecraft:light[level=14]
setblock 544 268 341 minecraft:light[level=14]
setblock 544 268 349 minecraft:light[level=14]
setblock 544 268 357 minecraft:light[level=14]
setblock 546 268 323 minecraft:stripped_dark_oak_log
setblock 548 268 363 minecraft:stripped_dark_oak_log
setblock 552 268 325 minecraft:light[level=14]
setblock 552 268 333 minecraft:light[level=14]
setblock 552 268 341 minecraft:light[level=14]
setblock 552 268 349 minecraft:light[level=14]
setblock 552 268 357 minecraft:light[level=14]
setblock 553 268 323 minecraft:stripped_dark_oak_log
setblock 555 268 363 minecraft:stripped_dark_oak_log
setblock 558 268 325 minecraft:stripped_dark_oak_log
setblock 558 268 332 minecraft:stripped_dark_oak_log
setblock 558 268 339 minecraft:stripped_dark_oak_log
setblock 558 268 346 minecraft:stripped_dark_oak_log
setblock 558 268 353 minecraft:stripped_dark_oak_log
setblock 558 268 360 minecraft:stripped_dark_oak_log
fill 518 269 324 518 270 324 minecraft:stripped_dark_oak_log
fill 518 269 331 518 270 331 minecraft:stripped_dark_oak_log
fill 518 269 338 518 270 338 minecraft:stripped_dark_oak_log
fill 518 269 345 518 270 345 minecraft:stripped_dark_oak_log
fill 518 269 352 518 270 352 minecraft:stripped_dark_oak_log
fill 518 269 359 518 270 359 minecraft:stripped_dark_oak_log
fill 521 269 363 521 270 363 minecraft:stripped_dark_oak_log
fill 524 269 323 524 270 323 minecraft:stripped_dark_oak_log
fill 528 269 363 528 270 363 minecraft:stripped_dark_oak_log
fill 531 269 323 531 270 323 minecraft:stripped_dark_oak_log
fill 535 269 363 535 270 363 minecraft:stripped_dark_oak_log
fill 538 269 323 538 270 323 minecraft:stripped_dark_oak_log
fill 542 269 363 542 270 363 minecraft:stripped_dark_oak_log
fill 545 269 323 545 270 323 minecraft:stripped_dark_oak_log
fill 549 269 363 549 270 363 minecraft:stripped_dark_oak_log
fill 552 269 323 552 270 323 minecraft:stripped_dark_oak_log
fill 556 269 363 556 270 363 minecraft:stripped_dark_oak_log
fill 558 269 324 558 270 324 minecraft:stripped_dark_oak_log
fill 558 269 331 558 270 331 minecraft:stripped_dark_oak_log
fill 558 269 338 558 270 338 minecraft:stripped_dark_oak_log
fill 558 269 345 558 270 345 minecraft:stripped_dark_oak_log
fill 558 269 352 558 270 352 minecraft:stripped_dark_oak_log
fill 558 269 359 558 270 359 minecraft:stripped_dark_oak_log
fill 518 270 323 519 270 323 minecraft:stripped_dark_oak_log
fill 518 270 325 518 270 327 minecraft:stripped_dark_oak_log
fill 518 270 329 518 270 330 minecraft:stripped_dark_oak_log
fill 518 270 332 518 270 334 minecraft:stripped_dark_oak_log
fill 518 270 336 518 270 337 minecraft:stripped_dark_oak_log
fill 518 270 339 518 270 341 minecraft:stripped_dark_oak_log
fill 518 270 343 518 270 344 minecraft:stripped_dark_oak_log
fill 518 270 346 518 270 348 minecraft:stripped_dark_oak_log
fill 518 270 350 518 270 351 minecraft:stripped_dark_oak_log
fill 518 270 353 518 270 355 minecraft:stripped_dark_oak_log
fill 518 270 357 518 270 358 minecraft:stripped_dark_oak_log
fill 518 270 360 518 270 362 minecraft:stripped_dark_oak_log
fill 519 270 363 520 270 363 minecraft:stripped_dark_oak_log
fill 521 270 323 523 270 323 minecraft:stripped_dark_oak_log
fill 522 270 363 524 270 363 minecraft:stripped_dark_oak_log
fill 525 270 323 526 270 323 minecraft:stripped_dark_oak_log
fill 526 270 363 527 270 363 minecraft:stripped_dark_oak_log
fill 528 270 323 530 270 323 minecraft:stripped_dark_oak_log
fill 529 270 363 531 270 363 minecraft:stripped_dark_oak_log
fill 532 270 323 533 270 323 minecraft:stripped_dark_oak_log
fill 533 270 363 534 270 363 minecraft:stripped_dark_oak_log
fill 535 270 323 537 270 323 minecraft:stripped_dark_oak_log
fill 536 270 363 538 270 363 minecraft:stripped_dark_oak_log
fill 539 270 323 540 270 323 minecraft:stripped_dark_oak_log
fill 540 270 363 541 270 363 minecraft:stripped_dark_oak_log
fill 542 270 323 544 270 323 minecraft:stripped_dark_oak_log
fill 543 270 363 545 270 363 minecraft:stripped_dark_oak_log
fill 546 270 323 547 270 323 minecraft:stripped_dark_oak_log
fill 547 270 363 548 270 363 minecraft:stripped_dark_oak_log
fill 549 270 323 551 270 323 minecraft:stripped_dark_oak_log
fill 550 270 363 552 270 363 minecraft:stripped_dark_oak_log
fill 553 270 323 554 270 323 minecraft:stripped_dark_oak_log
fill 554 270 363 555 270 363 minecraft:stripped_dark_oak_log
fill 556 270 323 558 270 323 minecraft:stripped_dark_oak_log
fill 557 270 363 558 270 363 minecraft:stripped_dark_oak_log
fill 558 270 325 558 270 326 minecraft:stripped_dark_oak_log
fill 558 270 328 558 270 330 minecraft:stripped_dark_oak_log
fill 558 270 332 558 270 333 minecraft:stripped_dark_oak_log
fill 558 270 335 558 270 337 minecraft:stripped_dark_oak_log
fill 558 270 339 558 270 340 minecraft:stripped_dark_oak_log
fill 558 270 342 558 270 344 minecraft:stripped_dark_oak_log
fill 558 270 346 558 270 347 minecraft:stripped_dark_oak_log
fill 558 270 349 558 270 351 minecraft:stripped_dark_oak_log
fill 558 270 353 558 270 354 minecraft:stripped_dark_oak_log
fill 558 270 356 558 270 358 minecraft:stripped_dark_oak_log
fill 558 270 360 558 270 361 minecraft:stripped_dark_oak_log
fill 518 276 333 533 276 353 minecraft:black_concrete
fill 519 276 331 557 276 332 minecraft:black_concrete
fill 519 276 354 557 276 355 minecraft:black_concrete
setblock 520 276 325 minecraft:light[level=14]
fill 520 276 330 556 276 330 minecraft:black_concrete
fill 520 276 356 556 276 356 minecraft:black_concrete
setblock 520 276 357 minecraft:light[level=14]
fill 521 276 329 555 276 329 minecraft:black_concrete
fill 521 276 357 555 276 357 minecraft:black_concrete
fill 522 276 328 554 276 328 minecraft:black_concrete
fill 522 276 358 554 276 358 minecraft:black_concrete
fill 523 276 327 553 276 327 minecraft:black_concrete
fill 523 276 359 553 276 359 minecraft:black_concrete
fill 524 276 326 552 276 326 minecraft:black_concrete
fill 524 276 360 552 276 360 minecraft:black_concrete
fill 525 276 325 551 276 325 minecraft:black_concrete
fill 525 276 361 551 276 361 minecraft:black_concrete
fill 526 276 324 550 276 324 minecraft:black_concrete
fill 526 276 362 550 276 362 minecraft:black_concrete
fill 528 276 323 548 276 323 minecraft:black_concrete
fill 528 276 363 548 276 363 minecraft:black_concrete
fill 534 276 333 534 276 340 minecraft:black_concrete
fill 534 276 342 534 276 353 minecraft:black_concrete
fill 535 276 333 536 276 338 minecraft:black_concrete
fill 535 276 344 536 276 353 minecraft:black_concrete
fill 537 276 333 558 276 337 minecraft:black_concrete
fill 537 276 345 558 276 353 minecraft:black_concrete
fill 538 276 338 558 276 338 minecraft:black_concrete
fill 538 276 344 558 276 344 minecraft:black_concrete
fill 540 276 339 558 276 340 minecraft:black_concrete
fill 540 276 342 558 276 343 minecraft:black_concrete
fill 541 276 341 558 276 341 minecraft:black_concrete
setblock 552 276 325 minecraft:light[level=14]
fill 518 277 334 518 277 352 minecraft:black_concrete
fill 519 277 332 519 277 333 minecraft:black_concrete
fill 519 277 334 533 277 352 minecraft:dark_oak_planks
fill 519 277 353 519 277 354 minecraft:black_concrete
setblock 520 277 331 minecraft:black_concrete
fill 520 277 332 556 277 333 minecraft:dark_oak_planks
fill 520 277 353 556 277 354 minecraft:dark_oak_planks
setblock 520 277 355 minecraft:black_concrete
setblock 521 277 330 minecraft:black_concrete
fill 521 277 331 555 277 331 minecraft:dark_oak_planks
fill 521 277 355 555 277 355 minecraft:dark_oak_planks
setblock 521 277 356 minecraft:black_concrete
fill 522 277 328 522 277 329 minecraft:black_concrete
fill 522 277 330 554 277 330 minecraft:dark_oak_planks
fill 522 277 356 554 277 356 minecraft:dark_oak_planks
fill 522 277 357 522 277 358 minecraft:black_concrete
fill 523 277 327 524 277 327 minecraft:black_concrete
fill 523 277 328 553 277 329 minecraft:dark_oak_planks
fill 523 277 357 553 277 358 minecraft:dark_oak_planks
fill 523 277 359 524 277 359 minecraft:black_concrete
setblock 525 277 326 minecraft:black_concrete
fill 525 277 327 551 277 327 minecraft:dark_oak_planks
fill 525 277 359 551 277 359 minecraft:dark_oak_planks
setblock 525 277 360 minecraft:black_concrete
setblock 526 277 325 minecraft:black_concrete
fill 526 277 326 550 277 326 minecraft:dark_oak_planks
fill 526 277 360 550 277 360 minecraft:dark_oak_planks
setblock 526 277 361 minecraft:black_concrete
fill 527 277 324 528 277 324 minecraft:black_concrete
fill 527 277 325 549 277 325 minecraft:dark_oak_planks
fill 527 277 361 549 277 361 minecraft:dark_oak_planks
fill 527 277 362 528 277 362 minecraft:black_concrete
fill 529 277 323 547 277 323 minecraft:black_concrete
fill 529 277 324 547 277 324 minecraft:dark_oak_planks
fill 529 277 362 547 277 362 minecraft:dark_oak_planks
fill 529 277 363 547 277 363 minecraft:black_concrete
fill 534 277 334 534 277 340 minecraft:dark_oak_planks
fill 534 277 342 534 277 352 minecraft:dark_oak_planks
fill 535 277 334 536 277 338 minecraft:dark_oak_planks
fill 535 277 344 536 277 352 minecraft:dark_oak_planks
fill 537 277 334 557 277 337 minecraft:dark_oak_planks
fill 537 277 345 557 277 352 minecraft:dark_oak_planks
fill 538 277 338 557 277 338 minecraft:dark_oak_planks
fill 538 277 344 557 277 344 minecraft:dark_oak_planks
fill 540 277 339 557 277 340 minecraft:dark_oak_planks
fill 540 277 342 557 277 343 minecraft:dark_oak_planks
fill 541 277 341 557 277 341 minecraft:dark_oak_planks
fill 548 277 324 549 277 324 minecraft:black_concrete
fill 548 277 362 549 277 362 minecraft:black_concrete
setblock 550 277 325 minecraft:black_concrete
setblock 550 277 361 minecraft:black_concrete
setblock 551 277 326 minecraft:black_concrete
setblock 551 277 360 minecraft:black_concrete
fill 552 277 327 553 277 327 minecraft:black_concrete
fill 552 277 359 553 277 359 minecraft:black_concrete
fill 554 277 328 554 277 329 minecraft:black_concrete
fill 554 277 357 554 277 358 minecraft:black_concrete
setblock 555 277 330 minecraft:black_concrete
setblock 555 277 356 minecraft:black_concrete
setblock 556 277 331 minecraft:black_concrete
setblock 556 277 355 minecraft:black_concrete
fill 557 277 332 557 277 333 minecraft:black_concrete
fill 557 277 353 557 277 354 minecraft:black_concrete
fill 558 277 334 558 277 352 minecraft:black_concrete
fill 518 278 336 518 278 350 minecraft:black_concrete
fill 519 278 334 519 278 335 minecraft:black_concrete
fill 519 278 336 532 278 350 minecraft:dark_oak_planks
fill 519 278 351 519 278 352 minecraft:black_concrete
fill 520 278 332 520 278 333 minecraft:black_concrete
fill 520 278 334 556 278 335 minecraft:dark_oak_planks
fill 520 278 351 556 278 352 minecraft:dark_oak_planks
fill 520 278 353 520 278 354 minecraft:black_concrete
setblock 521 278 331 minecraft:black_concrete
fill 521 278 332 555 278 333 minecraft:dark_oak_planks
fill 521 278 353 555 278 354 minecraft:dark_oak_planks
setblock 521 278 355 minecraft:black_concrete
fill 522 278 329 522 278 330 minecraft:black_concrete
fill 522 278 331 554 278 331 minecraft:dark_oak_planks
fill 522 278 355 554 278 355 minecraft:dark_oak_planks
fill 522 278 356 522 278 357 minecraft:black_concrete
setblock 523 278 328 minecraft:black_concrete
fill 523 278 329 553 278 330 minecraft:dark_oak_planks
fill 523 278 356 553 278 357 minecraft:dark_oak_planks
setblock 523 278 358 minecraft:black_concrete
fill 524 278 327 525 278 327 minecraft:black_concrete
fill 524 278 328 552 278 328 minecraft:dark_oak_planks
fill 524 278 358 552 278 358 minecraft:dark_oak_planks
fill 524 278 359 525 278 359 minecraft:black_concrete
setblock 526 278 326 minecraft:black_concrete
fill 526 278 327 550 278 327 minecraft:dark_oak_planks
fill 526 278 359 550 278 359 minecraft:dark_oak_planks
setblock 526 278 360 minecraft:black_concrete
fill 527 278 325 528 278 325 minecraft:black_concrete
fill 527 278 326 549 278 326 minecraft:dark_oak_planks
fill 527 278 360 549 278 360 minecraft:dark_oak_planks
fill 527 278 361 528 278 361 minecraft:black_concrete
fill 529 278 324 530 278 324 minecraft:black_concrete
fill 529 278 325 547 278 325 minecraft:dark_oak_planks
fill 529 278 361 547 278 361 minecraft:dark_oak_planks
fill 529 278 362 530 278 362 minecraft:black_concrete
fill 531 278 323 545 278 323 minecraft:black_concrete
fill 531 278 324 545 278 324 minecraft:dark_oak_planks
fill 531 278 362 545 278 362 minecraft:dark_oak_planks
fill 531 278 363 545 278 363 minecraft:black_concrete
fill 533 278 336 533 278 340 minecraft:dark_oak_planks
fill 533 278 341 533 278 342 minecraft:red_concrete
fill 533 278 343 533 278 350 minecraft:dark_oak_planks
fill 534 278 336 534 278 338 minecraft:dark_oak_planks
fill 534 278 339 534 278 340 minecraft:red_concrete
fill 534 278 342 534 278 344 minecraft:red_concrete
fill 534 278 345 535 278 350 minecraft:dark_oak_planks
fill 535 278 336 557 278 337 minecraft:dark_oak_planks
fill 535 278 338 536 278 338 minecraft:red_concrete
fill 535 278 344 536 278 344 minecraft:red_concrete
fill 536 278 345 538 278 345 minecraft:red_concrete
fill 536 278 346 557 278 350 minecraft:dark_oak_planks
fill 538 278 338 539 278 338 minecraft:red_concrete
fill 538 278 344 540 278 344 minecraft:red_concrete
fill 539 278 345 557 278 345 minecraft:dark_oak_planks
fill 540 278 338 557 278 338 minecraft:dark_oak_planks
fill 540 278 339 540 278 340 minecraft:red_concrete
fill 540 278 342 540 278 343 minecraft:red_concrete
fill 541 278 339 557 278 339 minecraft:dark_oak_planks
fill 541 278 340 541 278 342 minecraft:red_concrete
fill 541 278 343 557 278 344 minecraft:dark_oak_planks
fill 542 278 340 557 278 342 minecraft:dark_oak_planks
fill 546 278 324 547 278 324 minecraft:black_concrete
fill 546 278 362 547 278 362 minecraft:black_concrete
fill 548 278 325 549 278 325 minecraft:black_concrete
fill 548 278 361 549 278 361 minecraft:black_concrete
setblock 550 278 326 minecraft:black_concrete
setblock 550 278 360 minecraft:black_concrete
fill 551 278 327 552 278 327 minecraft:black_concrete
fill 551 278 359 552 278 359 minecraft:black_concrete
setblock 553 278 328 minecraft:black_concrete
setblock 553 278 358 minecraft:black_concrete
fill 554 278 329 554 278 330 minecraft:black_concrete
fill 554 278 356 554 278 357 minecraft:black_concrete
setblock 555 278 331 minecraft:black_concrete
setblock 555 278 355 minecraft:black_concrete
fill 556 278 332 556 278 333 minecraft:black_concrete
fill 556 278 353 556 278 354 minecraft:black_concrete
fill 557 278 334 557 278 335 minecraft:black_concrete
fill 557 278 351 557 278 352 minecraft:black_concrete
fill 558 278 336 558 278 350 minecraft:black_concrete
fill 518 279 323 518 279 337 minecraft:dark_oak_planks
fill 518 279 338 518 279 348 minecraft:black_concrete
fill 518 279 349 518 279 363 minecraft:dark_oak_planks
fill 519 279 323 519 279 334 minecraft:dark_oak_planks
fill 519 279 335 519 279 337 minecraft:black_concrete
fill 519 279 338 531 279 348 minecraft:dark_oak_planks
fill 519 279 349 519 279 351 minecraft:black_concrete
fill 519 279 352 519 279 363 minecraft:dark_oak_planks
fill 520 279 323 520 279 332 minecraft:dark_oak_planks
fill 520 279 333 520 279 334 minecraft:black_concrete
fill 520 279 335 533 279 337 minecraft:dark_oak_planks
fill 520 279 349 556 279 351 minecraft:dark_oak_planks
fill 520 279 352 520 279 353 minecraft:black_concrete
fill 520 279 354 520 279 363 minecraft:dark_oak_planks
fill 521 279 323 521 279 331 minecraft:dark_oak_planks
setblock 521 279 332 minecraft:black_concrete
fill 521 279 333 555 279 334 minecraft:dark_oak_planks
fill 521 279 352 555 279 353 minecraft:dark_oak_planks
setblock 521 279 354 minecraft:black_concrete
fill 521 279 355 521 279 363 minecraft:dark_oak_planks
fill 522 279 323 522 279 329 minecraft:dark_oak_planks
fill 522 279 330 522 279 331 minecraft:black_concrete
fill 522 279 332 554 279 332 minecraft:dark_oak_planks
fill 522 279 354 554 279 354 minecraft:dark_oak_planks
fill 522 279 355 522 279 356 minecraft:black_concrete
fill 522 279 357 522 279 363 minecraft:dark_oak_planks
fill 523 279 323 523 279 328 minecraft:dark_oak_planks
setblock 523 279 329 minecraft:black_concrete
fill 523 279 330 553 279 331 minecraft:dark_oak_planks
fill 523 279 355 553 279 356 minecraft:dark_oak_planks
setblock 523 279 357 minecraft:black_concrete
fill 523 279 358 523 279 363 minecraft:dark_oak_planks
fill 524 279 323 524 279 327 minecraft:dark_oak_planks
setblock 524 279 328 minecraft:black_concrete
fill 524 279 329 552 279 329 minecraft:dark_oak_planks
fill 524 279 357 552 279 357 minecraft:dark_oak_planks
setblock 524 279 358 minecraft:black_concrete
fill 524 279 359 524 279 363 minecraft:dark_oak_planks
fill 525 279 323 526 279 326 minecraft:dark_oak_planks
fill 525 279 327 526 279 327 minecraft:black_concrete
fill 525 279 328 551 279 328 minecraft:dark_oak_planks
fill 525 279 358 551 279 358 minecraft:dark_oak_planks
fill 525 279 359 526 279 359 minecraft:black_concrete
fill 525 279 360 526 279 363 minecraft:dark_oak_planks
fill 527 279 323 527 279 325 minecraft:dark_oak_planks
setblock 527 279 326 minecraft:black_concrete
fill 527 279 327 549 279 327 minecraft:dark_oak_planks
fill 527 279 359 549 279 359 minecraft:dark_oak_planks
setblock 527 279 360 minecraft:black_concrete
fill 527 279 361 527 279 363 minecraft:dark_oak_planks
fill 528 279 323 529 279 324 minecraft:dark_oak_planks
fill 528 279 325 529 279 325 minecraft:black_concrete
fill 528 279 326 548 279 326 minecraft:dark_oak_planks
fill 528 279 360 548 279 360 minecraft:dark_oak_planks
fill 528 279 361 529 279 361 minecraft:black_concrete
fill 528 279 362 529 279 363 minecraft:dark_oak_planks
fill 530 279 323 532 279 323 minecraft:dark_oak_planks
fill 530 279 324 532 279 324 minecraft:black_concrete
fill 530 279 325 546 279 325 minecraft:dark_oak_planks
fill 530 279 361 546 279 361 minecraft:dark_oak_planks
fill 530 279 362 532 279 362 minecraft:black_concrete
fill 530 279 363 532 279 363 minecraft:dark_oak_planks
setblock 532 279 338 minecraft:dark_oak_planks
fill 532 279 339 532 279 344 minecraft:red_concrete
fill 532 279 345 532 279 348 minecraft:dark_oak_planks
fill 533 279 323 543 279 323 minecraft:black_concrete
fill 533 279 324 543 279 324 minecraft:dark_oak_planks
fill 533 279 338 533 279 339 minecraft:red_concrete
fill 533 279 340 533 279 342 minecraft:shroomlight
fill 533 279 343 533 279 345 minecraft:red_concrete
fill 533 279 346 533 279 348 minecraft:dark_oak_planks
fill 533 279 362 543 279 362 minecraft:dark_oak_planks
fill 533 279 363 543 279 363 minecraft:black_concrete
fill 534 279 335 534 279 336 minecraft:dark_oak_planks
fill 534 279 337 535 279 337 minecraft:red_concrete
fill 534 279 338 534 279 340 minecraft:shroomlight
fill 534 279 342 534 279 344 minecraft:shroomlight
fill 534 279 345 535 279 346 minecraft:red_concrete
fill 534 279 347 534 279 348 minecraft:dark_oak_planks
fill 535 279 335 556 279 335 minecraft:dark_oak_planks
fill 535 279 336 539 279 336 minecraft:red_concrete
fill 535 279 338 536 279 338 minecraft:shroomlight
fill 535 279 344 536 279 344 minecraft:shroomlight
fill 535 279 347 540 279 347 minecraft:red_concrete
fill 535 279 348 557 279 348 minecraft:dark_oak_planks
fill 536 279 337 538 279 337 minecraft:shroomlight
fill 536 279 345 538 279 345 minecraft:shroomlight
fill 536 279 346 541 279 346 minecraft:red_concrete
fill 538 279 338 540 279 338 minecraft:shroomlight
fill 538 279 344 540 279 344 minecraft:shroomlight
fill 539 279 337 541 279 337 minecraft:red_concrete
fill 539 279 345 542 279 345 minecraft:red_concrete
fill 540 279 336 556 279 336 minecraft:dark_oak_planks
fill 540 279 339 540 279 340 minecraft:shroomlight
fill 540 279 342 540 279 343 minecraft:shroomlight
fill 541 279 338 542 279 339 minecraft:red_concrete
fill 541 279 340 541 279 342 minecraft:shroomlight
fill 541 279 343 542 279 344 minecraft:red_concrete
fill 541 279 347 557 279 347 minecraft:dark_oak_planks
fill 542 279 337 556 279 337 minecraft:dark_oak_planks
fill 542 279 340 543 279 342 minecraft:red_concrete
fill 542 279 346 557 279 346 minecraft:dark_oak_planks
fill 543 279 338 557 279 339 minecraft:dark_oak_planks
setblock 543 279 343 minecraft:red_concrete
fill 543 279 344 557 279 345 minecraft:dark_oak_planks
fill 544 279 323 558 279 323 minecraft:dark_oak_planks
fill 544 279 324 546 279 324 minecraft:black_concrete
fill 544 279 340 557 279 343 minecraft:dark_oak_planks
fill 544 279 362 546 279 362 minecraft:black_concrete
fill 544 279 363 558 279 363 minecraft:dark_oak_planks
fill 547 279 324 558 279 324 minecraft:dark_oak_planks
fill 547 279 325 548 279 325 minecraft:black_concrete
fill 547 279 361 548 279 361 minecraft:black_concrete
fill 547 279 362 558 279 362 minecraft:dark_oak_planks
fill 549 279 325 558 279 325 minecraft:dark_oak_planks
setblock 549 279 326 minecraft:black_concrete
setblock 549 279 360 minecraft:black_concrete
fill 549 279 361 558 279 361 minecraft:dark_oak_planks
fill 550 279 326 558 279 326 minecraft:dark_oak_planks
fill 550 279 327 551 279 327 minecraft:black_concrete
fill 550 279 359 551 279 359 minecraft:black_concrete
fill 550 279 360 558 279 360 minecraft:dark_oak_planks
fill 552 279 327 558 279 327 minecraft:dark_oak_planks
setblock 552 279 328 minecraft:black_concrete
setblock 552 279 358 minecraft:black_concrete
fill 552 279 359 558 279 359 minecraft:dark_oak_planks
fill 553 279 328 558 279 328 minecraft:dark_oak_planks
setblock 553 279 329 minecraft:black_concrete
setblock 553 279 357 minecraft:black_concrete
fill 553 279 358 558 279 358 minecraft:dark_oak_planks
fill 554 279 329 558 279 329 minecraft:dark_oak_planks
fill 554 279 330 554 279 331 minecraft:black_concrete
fill 554 279 355 554 279 356 minecraft:black_concrete
fill 554 279 357 558 279 357 minecraft:dark_oak_planks
fill 555 279 330 558 279 331 minecraft:dark_oak_planks
setblock 555 279 332 minecraft:black_concrete
setblock 555 279 354 minecraft:black_concrete
fill 555 279 355 558 279 356 minecraft:dark_oak_planks
fill 556 279 332 558 279 332 minecraft:dark_oak_planks
fill 556 279 333 556 279 334 minecraft:black_concrete
fill 556 279 352 556 279 353 minecraft:black_concrete
fill 556 279 354 558 279 354 minecraft:dark_oak_planks
fill 557 279 333 558 279 334 minecraft:dark_oak_planks
fill 557 279 335 557 279 337 minecraft:black_concrete
fill 557 279 349 557 279 351 minecraft:black_concrete
fill 557 279 352 558 279 353 minecraft:dark_oak_planks
fill 558 279 335 558 279 337 minecraft:dark_oak_planks
fill 558 279 338 558 279 348 minecraft:black_concrete
fill 558 279 349 558 279 351 minecraft:dark_oak_planks
fill 519 280 338 519 280 348 minecraft:black_concrete
fill 520 280 335 520 280 337 minecraft:black_concrete
fill 520 280 338 529 280 348 minecraft:dark_oak_planks
fill 520 280 349 520 280 351 minecraft:black_concrete
fill 521 280 333 521 280 334 minecraft:black_concrete
fill 521 280 335 531 280 337 minecraft:dark_oak_planks
fill 521 280 349 533 280 351 minecraft:dark_oak_planks
fill 521 280 352 521 280 353 minecraft:black_concrete
setblock 522 280 332 minecraft:black_concrete
fill 522 280 333 536 280 334 minecraft:dark_oak_planks
fill 522 280 352 554 280 353 minecraft:dark_oak_planks
setblock 522 280 354 minecraft:black_concrete
fill 523 280 330 523 280 331 minecraft:black_concrete
fill 523 280 332 553 280 332 minecraft:dark_oak_planks
fill 523 280 354 553 280 354 minecraft:dark_oak_planks
fill 523 280 355 523 280 356 minecraft:black_concrete
fill 524 280 329 524 280 330 minecraft:black_concrete
fill 524 280 331 552 280 331 minecraft:dark_oak_planks
fill 524 280 355 552 280 355 minecraft:dark_oak_planks
fill 524 280 356 524 280 357 minecraft:black_concrete
fill 525 280 328 525 280 329 minecraft:black_concrete
fill 525 280 330 551 280 330 minecraft:dark_oak_planks
fill 525 280 356 551 280 356 minecraft:dark_oak_planks
fill 525 280 357 525 280 358 minecraft:black_concrete
setblock 526 280 328 minecraft:black_concrete
fill 526 280 329 550 280 329 minecraft:dark_oak_planks
fill 526 280 357 550 280 357 minecraft:dark_oak_planks
setblock 526 280 358 minecraft:black_concrete
setblock 527 280 327 minecraft:black_concrete
fill 527 280 328 549 280 328 minecraft:dark_oak_planks
fill 527 280 358 549 280 358 minecraft:dark_oak_planks
setblock 527 280 359 minecraft:black_concrete
fill 528 280 326 529 280 326 minecraft:black_concrete
fill 528 280 327 548 280 327 minecraft:dark_oak_planks
fill 528 280 359 548 280 359 minecraft:dark_oak_planks
fill 528 280 360 529 280 360 minecraft:black_concrete
fill 530 280 325 532 280 325 minecraft:black_concrete
fill 530 280 326 546 280 326 minecraft:dark_oak_planks
setblock 530 280 338 minecraft:dark_oak_planks
fill 530 280 339 531 280 345 minecraft:red_concrete
fill 530 280 346 530 280 348 minecraft:dark_oak_planks
fill 530 280 360 546 280 360 minecraft:dark_oak_planks
fill 530 280 361 532 280 361 minecraft:black_concrete
fill 531 280 338 532 280 338 minecraft:red_concrete
fill 531 280 346 533 280 346 minecraft:red_concrete
fill 531 280 347 531 280 348 minecraft:dark_oak_planks
fill 532 280 335 532 280 336 minecraft:dark_oak_planks
fill 532 280 337 533 280 337 minecraft:red_concrete
setblock 532 280 345 minecraft:red_concrete
fill 532 280 347 534 280 347 minecraft:red_concrete
setblock 532 280 348 minecraft:dark_oak_planks
fill 533 280 324 543 280 324 minecraft:black_concrete
fill 533 280 325 543 280 325 minecraft:dark_oak_planks
setblock 533 280 335 minecraft:dark_oak_planks
fill 533 280 336 534 280 336 minecraft:red_concrete
fill 533 280 348 542 280 348 minecraft:red_concrete
fill 533 280 361 543 280 361 minecraft:dark_oak_planks
fill 533 280 362 543 280 362 minecraft:black_concrete
fill 534 280 335 541 280 335 minecraft:red_concrete
fill 534 280 349 541 280 349 minecraft:red_concrete
fill 534 280 350 536 280 351 minecraft:dark_oak_planks
fill 537 280 333 554 280 333 minecraft:dark_oak_planks
fill 537 280 334 538 280 334 minecraft:red_concrete
fill 537 280 350 538 280 350 minecraft:red_concrete
fill 537 280 351 555 280 351 minecraft:dark_oak_planks
fill 539 280 334 554 280 334 minecraft:dark_oak_planks
fill 539 280 350 555 280 350 minecraft:dark_oak_planks
fill 540 280 336 542 280 336 minecraft:red_concrete
fill 541 280 347 543 280 347 minecraft:red_concrete
fill 542 280 335 555 280 335 minecraft:dark_oak_planks
fill 542 280 337 543 280 337 minecraft:red_concrete
fill 542 280 346 544 280 346 minecraft:red_concrete
fill 542 280 349 555 280 349 minecraft:dark_oak_planks
fill 543 280 336 555 280 336 minecraft:dark_oak_planks
fill 543 280 338 544 280 339 minecraft:red_concrete
fill 543 280 344 545 280 345 minecraft:red_concrete
fill 543 280 348 556 280 348 minecraft:dark_oak_planks
fill 544 280 325 546 280 325 minecraft:black_concrete
fill 544 280 337 555 280 337 minecraft:dark_oak_planks
fill 544 280 340 545 280 343 minecraft:red_concrete
fill 544 280 347 556 280 347 minecraft:dark_oak_planks
fill 544 280 361 546 280 361 minecraft:black_concrete
fill 545 280 338 556 280 338 minecraft:dark_oak_planks
setblock 545 280 339 minecraft:red_concrete
fill 545 280 346 556 280 346 minecraft:dark_oak_planks
fill 546 280 339 556 280 345 minecraft:dark_oak_planks
fill 547 280 326 548 280 326 minecraft:black_concrete
fill 547 280 360 548 280 360 minecraft:black_concrete
setblock 549 280 327 minecraft:black_concrete
setblock 549 280 359 minecraft:black_concrete
fill 550 280 328 551 280 328 minecraft:black_concrete
fill 550 280 358 551 280 358 minecraft:black_concrete
fill 551 280 329 552 280 329 minecraft:black_concrete
fill 551 280 357 552 280 357 minecraft:black_concrete
fill 552 280 330 553 280 330 minecraft:black_concrete
fill 552 280 356 553 280 356 minecraft:black_concrete
setblock 553 280 331 minecraft:black_concrete
setblock 553 280 355 minecraft:black_concrete
setblock 554 280 332 minecraft:black_concrete
setblock 554 280 354 minecraft:black_concrete
fill 555 280 333 555 280 334 minecraft:black_concrete
fill 555 280 352 555 280 353 minecraft:black_concrete
fill 556 280 335 556 280 337 minecraft:black_concrete
fill 556 280 349 556 280 351 minecraft:black_concrete
fill 557 280 338 557 280 348 minecraft:black_concrete
fill 520 281 338 520 281 348 minecraft:black_concrete
fill 521 281 335 521 281 337 minecraft:black_concrete
fill 521 281 338 527 281 348 minecraft:dark_oak_planks
fill 521 281 349 521 281 351 minecraft:black_concrete
fill 522 281 333 522 281 335 minecraft:black_concrete
fill 522 281 336 529 281 337 minecraft:dark_oak_planks
fill 522 281 349 530 281 350 minecraft:dark_oak_planks
fill 522 281 351 522 281 353 minecraft:black_concrete
fill 523 281 332 523 281 333 minecraft:black_concrete
fill 523 281 334 530 281 335 minecraft:dark_oak_planks
fill 523 281 351 532 281 352 minecraft:dark_oak_planks
fill 523 281 353 523 281 354 minecraft:black_concrete
setblock 524 281 331 minecraft:black_concrete
fill 524 281 332 534 281 333 minecraft:dark_oak_planks
fill 524 281 353 552 281 354 minecraft:dark_oak_planks
setblock 524 281 355 minecraft:black_concrete
setblock 525 281 330 minecraft:black_concrete
fill 525 281 331 551 281 331 minecraft:dark_oak_planks
fill 525 281 355 551 281 355 minecraft:dark_oak_planks
setblock 525 281 356 minecraft:black_concrete
setblock 526 281 329 minecraft:black_concrete
fill 526 281 330 550 281 330 minecraft:dark_oak_planks
fill 526 281 356 550 281 356 minecraft:dark_oak_planks
setblock 526 281 357 minecraft:black_concrete
fill 527 281 328 528 281 328 minecraft:black_concrete
fill 527 281 329 549 281 329 minecraft:dark_oak_planks
fill 527 281 357 549 281 357 minecraft:dark_oak_planks
fill 527 281 358 528 281 358 minecraft:black_concrete
fill 528 281 327 530 281 327 minecraft:black_concrete
fill 528 281 338 528 281 339 minecraft:dark_oak_planks
fill 528 281 340 529 281 345 minecraft:red_concrete
fill 528 281 346 528 281 348 minecraft:dark_oak_planks
fill 528 281 359 530 281 359 minecraft:black_concrete
fill 529 281 328 547 281 328 minecraft:dark_oak_planks
fill 529 281 338 529 281 339 minecraft:red_concrete
fill 529 281 346 530 281 347 minecraft:red_concrete
setblock 529 281 348 minecraft:dark_oak_planks
fill 529 281 358 547 281 358 minecraft:dark_oak_planks
fill 530 281 326 532 281 326 minecraft:black_concrete
fill 530 281 336 530 281 338 minecraft:red_concrete
fill 530 281 348 532 281 348 minecraft:red_concrete
fill 530 281 360 532 281 360 minecraft:black_concrete
fill 531 281 327 545 281 327 minecraft:dark_oak_planks
fill 531 281 334 532 281 334 minecraft:dark_oak_planks
fill 531 281 335 531 281 337 minecraft:red_concrete
setblock 531 281 347 minecraft:red_concrete
fill 531 281 349 533 281 349 minecraft:red_concrete
setblock 531 281 350 minecraft:dark_oak_planks
fill 531 281 359 545 281 359 minecraft:dark_oak_planks
fill 532 281 335 532 281 336 minecraft:red_concrete
fill 532 281 350 536 281 350 minecraft:red_concrete
fill 533 281 325 543 281 325 minecraft:black_concrete
fill 533 281 326 543 281 326 minecraft:dark_oak_planks
fill 533 281 334 533 281 335 minecraft:red_concrete
fill 533 281 351 542 281 351 minecraft:red_concrete
fill 533 281 352 534 281 352 minecraft:dark_oak_planks
fill 533 281 360 543 281 360 minecraft:dark_oak_planks
fill 533 281 361 543 281 361 minecraft:black_concrete
fill 534 281 334 536 281 334 minecraft:red_concrete
fill 535 281 332 552 281 332 minecraft:dark_oak_planks
fill 535 281 333 541 281 333 minecraft:red_concrete
fill 535 281 352 540 281 352 minecraft:red_concrete
fill 539 281 334 543 281 334 minecraft:red_concrete
fill 539 281 350 544 281 350 minecraft:red_concrete
fill 541 281 352 553 281 352 minecraft:dark_oak_planks
fill 542 281 333 552 281 333 minecraft:dark_oak_planks
fill 542 281 335 544 281 335 minecraft:red_concrete
fill 542 281 349 545 281 349 minecraft:red_concrete
fill 543 281 336 545 281 336 minecraft:red_concrete
fill 543 281 348 546 281 348 minecraft:red_concrete
fill 543 281 351 553 281 351 minecraft:dark_oak_planks
fill 544 281 326 546 281 326 minecraft:black_concrete
fill 544 281 334 553 281 334 minecraft:dark_oak_planks
fill 544 281 337 546 281 337 minecraft:red_concrete
fill 544 281 347 546 281 347 minecraft:red_concrete
fill 544 281 360 546 281 360 minecraft:black_concrete
fill 545 281 335 553 281 335 minecraft:dark_oak_planks
fill 545 281 338 546 281 338 minecraft:red_concrete
fill 545 281 346 547 281 346 minecraft:red_concrete
fill 545 281 350 554 281 350 minecraft:dark_oak_planks
fill 546 281 327 548 281 327 minecraft:black_concrete
fill 546 281 336 554 281 336 minecraft:dark_oak_planks
fill 546 281 339 547 281 345 minecraft:red_concrete
fill 546 281 349 554 281 349 minecraft:dark_oak_planks
fill 546 281 359 548 281 359 minecraft:black_concrete
fill 547 281 337 554 281 338 minecraft:dark_oak_planks
fill 547 281 347 555 281 348 minecraft:dark_oak_planks
fill 548 281 328 549 281 328 minecraft:black_concrete
fill 548 281 339 555 281 346 minecraft:dark_oak_planks
fill 548 281 358 549 281 358 minecraft:black_concrete
setblock 550 281 329 minecraft:black_concrete
setblock 550 281 357 minecraft:black_concrete
setblock 551 281 330 minecraft:black_concrete
setblock 551 281 356 minecraft:black_concrete
setblock 552 281 331 minecraft:black_concrete
setblock 552 281 355 minecraft:black_concrete
fill 553 281 332 553 281 333 minecraft:black_concrete
fill 553 281 353 553 281 354 minecraft:black_concrete
fill 554 281 333 554 281 335 minecraft:black_concrete
fill 554 281 351 554 281 353 minecraft:black_concrete
fill 555 281 335 555 281 337 minecraft:black_concrete
setblock 555 281 338 minecraft:dark_oak_planks
fill 555 281 349 555 281 351 minecraft:black_concrete
fill 556 281 338 556 281 348 minecraft:black_concrete
fill 521 282 338 521 282 348 minecraft:black_concrete
fill 522 282 336 522 282 340 minecraft:black_concrete
fill 522 282 341 525 282 345 minecraft:dark_oak_planks
fill 522 282 346 522 282 350 minecraft:black_concrete
fill 523 282 334 523 282 336 minecraft:black_concrete
fill 523 282 337 526 282 340 minecraft:dark_oak_planks
fill 523 282 346 526 282 349 minecraft:dark_oak_planks
fill 523 282 350 523 282 352 minecraft:black_concrete
fill 524 282 332 524 282 334 minecraft:black_concrete
fill 524 282 335 527 282 336 minecraft:dark_oak_planks
fill 524 282 350 528 282 351 minecraft:dark_oak_planks
fill 524 282 352 524 282 354 minecraft:black_concrete
fill 525 282 331 525 282 333 minecraft:black_concrete
fill 525 282 334 529 282 334 minecraft:dark_oak_planks
fill 525 282 352 530 282 352 minecraft:dark_oak_planks
fill 525 282 353 525 282 355 minecraft:black_concrete
fill 526 282 330 526 282 332 minecraft:black_concrete
fill 526 282 333 530 282 333 minecraft:dark_oak_planks
setblock 526 282 341 minecraft:dark_oak_planks
fill 526 282 342 527 282 344 minecraft:red_concrete
setblock 526 282 345 minecraft:dark_oak_planks
fill 526 282 353 531 282 353 minecraft:dark_oak_planks
fill 526 282 354 526 282 356 minecraft:black_concrete
fill 527 282 329 527 282 331 minecraft:black_concrete
fill 527 282 332 532 282 332 minecraft:dark_oak_planks
setblock 527 282 337 minecraft:dark_oak_planks
fill 527 282 338 527 282 341 minecraft:red_concrete
fill 527 282 345 527 282 347 minecraft:red_concrete
fill 527 282 348 527 282 349 minecraft:dark_oak_planks
fill 527 282 354 533 282 354 minecraft:dark_oak_planks
fill 527 282 355 527 282 357 minecraft:black_concrete
fill 528 282 329 528 282 330 minecraft:black_concrete
fill 528 282 331 535 282 331 minecraft:dark_oak_planks
setblock 528 282 335 minecraft:dark_oak_planks
fill 528 282 336 528 282 339 minecraft:red_concrete
fill 528 282 346 528 282 349 minecraft:red_concrete
fill 528 282 355 548 282 355 minecraft:dark_oak_planks
fill 528 282 356 528 282 357 minecraft:black_concrete
fill 529 282 328 529 282 329 minecraft:black_concrete
fill 529 282 330 547 282 330 minecraft:dark_oak_planks
fill 529 282 335 529 282 337 minecraft:red_concrete
fill 529 282 348 529 282 350 minecraft:red_concrete
setblock 529 282 351 minecraft:dark_oak_planks
fill 529 282 356 547 282 356 minecraft:dark_oak_planks
fill 529 282 357 529 282 358 minecraft:black_concrete
fill 530 282 328 531 282 328 minecraft:black_concrete
fill 530 282 329 546 282 329 minecraft:dark_oak_planks
fill 530 282 334 530 282 335 minecraft:red_concrete
fill 530 282 349 530 282 351 minecraft:red_concrete
fill 530 282 357 546 282 357 minecraft:dark_oak_planks
fill 530 282 358 531 282 358 minecraft:black_concrete
fill 531 282 327 535 282 327 minecraft:black_concrete
fill 531 282 333 532 282 334 minecraft:red_concrete
fill 531 282 350 531 282 352 minecraft:red_concrete
fill 531 282 359 535 282 359 minecraft:black_concrete
fill 532 282 328 544 282 328 minecraft:dark_oak_planks
fill 532 282 351 532 282 353 minecraft:red_concrete
fill 532 282 358 544 282 358 minecraft:dark_oak_planks
fill 533 282 326 543 282 326 minecraft:black_concrete
fill 533 282 332 534 282 333 minecraft:red_concrete
fill 533 282 352 534 282 353 minecraft:red_concrete
fill 533 282 360 543 282 360 minecraft:black_concrete
fill 534 282 354 542 282 354 minecraft:red_concrete
fill 535 282 332 543 282 332 minecraft:red_concrete
fill 535 282 353 544 282 353 minecraft:red_concrete
fill 536 282 327 540 282 327 minecraft:dark_oak_planks
fill 536 282 331 540 282 331 minecraft:red_concrete
fill 536 282 359 540 282 359 minecraft:dark_oak_planks
fill 541 282 327 545 282 327 minecraft:black_concrete
fill 541 282 331 548 282 331 minecraft:dark_oak_planks
fill 541 282 352 545 282 352 minecraft:red_concrete
fill 541 282 359 545 282 359 minecraft:black_concrete
fill 542 282 333 544 282 333 minecraft:red_concrete
fill 543 282 351 546 282 351 minecraft:red_concrete
fill 543 282 354 549 282 354 minecraft:dark_oak_planks
fill 544 282 332 549 282 332 minecraft:dark_oak_planks
fill 544 282 334 546 282 334 minecraft:red_concrete
fill 545 282 328 547 282 328 minecraft:black_concrete
fill 545 282 333 550 282 333 minecraft:dark_oak_planks
fill 545 282 335 547 282 335 minecraft:red_concrete
fill 545 282 350 547 282 350 minecraft:red_concrete
fill 545 282 353 550 282 353 minecraft:dark_oak_planks
fill 545 282 358 547 282 358 minecraft:black_concrete
fill 546 282 336 547 282 336 minecraft:red_concrete
fill 546 282 349 548 282 349 minecraft:red_concrete
fill 546 282 352 551 282 352 minecraft:dark_oak_planks
fill 547 282 329 549 282 329 minecraft:black_concrete
fill 547 282 334 551 282 334 minecraft:dark_oak_planks
fill 547 282 337 548 282 338 minecraft:red_concrete
fill 547 282 347 548 282 348 minecraft:red_concrete
fill 547 282 351 552 282 351 minecraft:dark_oak_planks
fill 547 282 357 549 282 357 minecraft:black_concrete
fill 548 282 330 550 282 330 minecraft:black_concrete
fill 548 282 335 552 282 336 minecraft:dark_oak_planks
fill 548 282 339 549 282 346 minecraft:red_concrete
fill 548 282 350 552 282 350 minecraft:dark_oak_planks
fill 548 282 356 550 282 356 minecraft:black_concrete
fill 549 282 331 551 282 331 minecraft:black_concrete
fill 549 282 337 553 282 338 minecraft:dark_oak_planks
setblock 549 282 347 minecraft:red_concrete
fill 549 282 348 553 282 349 minecraft:dark_oak_planks
fill 549 282 355 551 282 355 minecraft:black_concrete
fill 550 282 332 552 282 332 minecraft:black_concrete
fill 550 282 339 553 282 347 minecraft:dark_oak_planks
fill 550 282 354 552 282 354 minecraft:black_concrete
fill 551 282 333 552 282 333 minecraft:black_concrete
fill 551 282 353 552 282 353 minecraft:black_concrete
fill 552 282 334 553 282 334 minecraft:black_concrete
fill 552 282 352 553 282 352 minecraft:black_concrete
fill 553 282 335 553 282 336 minecraft:black_concrete
fill 553 282 350 553 282 351 minecraft:black_concrete
fill 554 282 336 554 282 340 minecraft:black_concrete
fill 554 282 341 554 282 345 minecraft:dark_oak_planks
fill 554 282 346 554 282 350 minecraft:black_concrete
fill 555 282 338 555 282 348 minecraft:black_concrete
fill 518 283 323 527 285 328 minecraft:stripped_dark_oak_log
setblock 518 283 331 minecraft:stripped_dark_oak_log
fill 518 283 335 518 300 335 minecraft:stripped_dark_oak_log
setblock 518 283 338 minecraft:stripped_dark_oak_log
fill 518 283 342 518 300 342 minecraft:stripped_dark_oak_log
setblock 518 283 345 minecraft:stripped_dark_oak_log
fill 518 283 349 518 300 349 minecraft:stripped_dark_oak_log
setblock 518 283 352 minecraft:stripped_dark_oak_log
fill 518 283 356 518 300 356 minecraft:stripped_dark_oak_log
setblock 518 283 359 minecraft:stripped_dark_oak_log
fill 518 283 363 518 300 363 minecraft:stripped_dark_oak_log
setblock 521 283 363 minecraft:stripped_dark_oak_log
fill 522 283 341 524 283 345 minecraft:black_concrete
fill 523 283 337 525 283 340 minecraft:black_concrete
fill 523 283 346 525 283 349 minecraft:black_concrete
fill 524 283 335 526 283 336 minecraft:black_concrete
fill 524 283 350 527 283 351 minecraft:black_concrete
fill 525 283 334 528 283 334 minecraft:black_concrete
setblock 525 283 341 minecraft:black_concrete
fill 525 283 342 525 283 344 minecraft:red_concrete
setblock 525 283 345 minecraft:black_concrete
fill 525 283 352 528 283 352 minecraft:black_concrete
fill 525 283 363 525 300 363 minecraft:stripped_dark_oak_log
fill 526 283 333 529 283 333 minecraft:black_concrete
setblock 526 283 337 minecraft:black_concrete
fill 526 283 338 526 283 341 minecraft:red_concrete
fill 526 283 345 526 283 348 minecraft:red_concrete
setblock 526 283 349 minecraft:black_concrete
fill 526 283 353 529 283 353 minecraft:black_concrete
fill 527 283 332 530 283 332 minecraft:black_concrete
setblock 527 283 335 minecraft:black_concrete
fill 527 283 336 527 283 337 minecraft:red_concrete
fill 527 283 348 527 283 349 minecraft:red_concrete
fill 527 283 354 531 283 354 minecraft:black_concrete
fill 528 283 331 532 283 331 minecraft:black_concrete
setblock 528 283 335 minecraft:red_concrete
fill 528 283 350 528 283 351 minecraft:red_concrete
fill 528 283 355 532 283 355 minecraft:black_concrete
setblock 528 283 363 minecraft:stripped_dark_oak_log
fill 529 283 330 535 283 330 minecraft:black_concrete
setblock 529 283 334 minecraft:red_concrete
fill 529 283 351 529 283 352 minecraft:red_concrete
fill 529 283 356 537 283 356 minecraft:black_concrete
fill 530 283 329 546 283 329 minecraft:black_concrete
setblock 530 283 333 minecraft:red_concrete
fill 530 283 352 530 283 353 minecraft:red_concrete
fill 530 283 357 546 283 357 minecraft:black_concrete
setblock 531 283 323 minecraft:stripped_dark_oak_log
fill 531 283 332 532 283 332 minecraft:red_concrete
setblock 531 283 353 minecraft:red_concrete
fill 532 283 328 544 283 328 minecraft:black_concrete
fill 532 283 354 533 283 354 minecraft:red_concrete
fill 532 283 358 544 283 358 minecraft:black_concrete
fill 532 283 363 532 300 363 minecraft:stripped_dark_oak_log
fill 533 283 331 535 283 331 minecraft:red_concrete
fill 533 283 355 543 283 355 minecraft:red_concrete
fill 534 283 323 534 300 323 minecraft:stripped_dark_oak_log
setblock 535 283 363 minecraft:stripped_dark_oak_log
fill 536 283 327 540 283 327 minecraft:black_concrete
fill 536 283 330 540 283 330 minecraft:red_concrete
fill 536 283 359 540 283 359 minecraft:black_concrete
fill 537 283 360 537 283 362 minecraft:iron_bars
fill 538 283 323 552 283 323 minecraft:stripped_dark_oak_log
setblock 538 283 356 minecraft:red_concrete
fill 539 283 324 551 285 326 minecraft:stripped_dark_oak_log
fill 539 283 356 547 283 356 minecraft:black_concrete
fill 539 283 363 539 300 363 minecraft:stripped_dark_oak_log
fill 541 283 327 551 285 327 minecraft:stripped_dark_oak_log
fill 541 283 330 547 283 330 minecraft:black_concrete
fill 541 283 331 543 283 331 minecraft:red_concrete
setblock 542 283 363 minecraft:stripped_dark_oak_log
fill 543 283 354 544 283 354 minecraft:red_concrete
fill 544 283 331 548 283 331 minecraft:black_concrete
setblock 544 283 332 minecraft:red_concrete
fill 544 283 355 548 283 355 minecraft:black_concrete
fill 545 283 328 551 285 328 minecraft:stripped_dark_oak_log
fill 545 283 332 549 283 332 minecraft:black_concrete
fill 545 283 333 546 283 333 minecraft:red_concrete
fill 545 283 353 546 283 353 minecraft:red_concrete
fill 545 283 354 549 283 354 minecraft:black_concrete
fill 546 283 352 547 283 352 minecraft:red_concrete
fill 546 283 363 546 300 363 minecraft:stripped_dark_oak_log
fill 547 283 329 551 285 329 minecraft:stripped_dark_oak_log
fill 547 283 333 550 283 333 minecraft:black_concrete
setblock 547 283 334 minecraft:red_concrete
fill 547 283 351 548 283 351 minecraft:red_concrete
fill 547 283 353 550 283 353 minecraft:black_concrete
fill 548 283 330 551 285 330 minecraft:stripped_dark_oak_log
fill 548 283 334 551 283 334 minecraft:black_concrete
fill 548 283 335 548 283 336 minecraft:red_concrete
setblock 548 283 350 minecraft:red_concrete
fill 548 283 352 551 283 352 minecraft:black_concrete
fill 549 283 335 552 283 336 minecraft:black_concrete
fill 549 283 337 549 283 338 minecraft:red_concrete
fill 549 283 348 549 283 349 minecraft:red_concrete
fill 549 283 350 552 283 351 minecraft:black_concrete
setblock 549 283 363 minecraft:stripped_dark_oak_log
fill 550 283 337 553 283 337 minecraft:black_concrete
fill 550 283 338 550 283 348 minecraft:red_concrete
fill 550 283 349 553 283 349 minecraft:black_concrete
fill 551 283 338 553 283 342 minecraft:black_concrete
setblock 551 283 343 minecraft:red_concrete
fill 551 283 344 553 283 348 minecraft:black_concrete
fill 552 283 343 554 283 343 minecraft:black_concrete
fill 553 283 328 558 300 336 minecraft:stripped_dark_oak_log
fill 553 283 363 553 300 363 minecraft:stripped_dark_oak_log
fill 554 283 337 558 300 340 minecraft:stripped_dark_oak_log
fill 554 283 341 554 283 342 minecraft:black_concrete
fill 554 283 344 554 283 345 minecraft:black_concrete
fill 555 283 323 555 300 323 minecraft:stripped_dark_oak_log
setblock 556 283 363 minecraft:stripped_dark_oak_log
setblock 558 283 324 minecraft:stripped_dark_oak_log
fill 558 283 327 558 300 327 minecraft:stripped_dark_oak_log
fill 558 283 341 558 300 341 minecraft:stripped_dark_oak_log
setblock 558 283 345 minecraft:stripped_dark_oak_log
fill 558 283 348 558 300 348 minecraft:stripped_dark_oak_log
setblock 558 283 352 minecraft:stripped_dark_oak_log
fill 558 283 355 558 300 355 minecraft:stripped_dark_oak_log
setblock 558 283 359 minecraft:stripped_dark_oak_log
fill 558 283 362 558 300 362 minecraft:stripped_dark_oak_log
setblock 518 284 332 minecraft:stripped_dark_oak_log
setblock 518 284 339 minecraft:stripped_dark_oak_log
setblock 518 284 346 minecraft:stripped_dark_oak_log
setblock 518 284 353 minecraft:stripped_dark_oak_log
setblock 518 284 360 minecraft:stripped_dark_oak_log
setblock 520 284 333 minecraft:light[level=14]
setblock 520 284 341 minecraft:light[level=14]
setblock 520 284 349 minecraft:light[level=14]
setblock 520 284 357 minecraft:light[level=14]
setblock 522 284 363 minecraft:stripped_dark_oak_log
setblock 528 284 325 minecraft:light[level=14]
setblock 528 284 333 minecraft:light[level=14]
setblock 528 284 341 minecraft:light[level=14]
setblock 528 284 349 minecraft:light[level=14]
setblock 528 284 357 minecraft:light[level=14]
setblock 529 284 363 minecraft:stripped_dark_oak_log
setblock 530 284 323 minecraft:stripped_dark_oak_log
setblock 536 284 325 minecraft:light[level=14]
setblock 536 284 333 minecraft:light[level=14]
setblock 536 284 349 minecraft:light[level=14]
setblock 536 284 357 minecraft:light[level=14]
setblock 536 284 363 minecraft:stripped_dark_oak_log
setblock 537 284 323 minecraft:stripped_dark_oak_log
fill 539 284 323 551 285 323 minecraft:stripped_dark_oak_log
fill 539 284 327 540 285 330 minecraft:stripped_dark_oak_log
fill 541 284 328 544 285 330 minecraft:stripped_dark_oak_log
setblock 543 284 363 minecraft:stripped_dark_oak_log
setblock 544 284 333 minecraft:light[level=14]
setblock 544 284 341 minecraft:light[level=14]
setblock 544 284 349 minecraft:light[level=14]
setblock 544 284 357 minecraft:light[level=14]
fill 545 284 329 546 285 330 minecraft:stripped_dark_oak_log
fill 547 284 330 547 285 330 minecraft:stripped_dark_oak_log
setblock 550 284 363 minecraft:stripped_dark_oak_log
setblock 552 284 325 minecraft:light[level=14]
setblock 552 284 333 minecraft:light[level=14]
setblock 552 284 341 minecraft:light[level=14]
setblock 552 284 349 minecraft:light[level=14]
setblock 552 284 357 minecraft:light[level=14]
fill 553 284 337 553 300 340 minecraft:stripped_dark_oak_log
setblock 557 284 363 minecraft:stripped_dark_oak_log
setblock 558 284 323 minecraft:stripped_dark_oak_log
setblock 558 284 344 minecraft:stripped_dark_oak_log
setblock 558 284 351 minecraft:stripped_dark_oak_log
setblock 558 284 358 minecraft:stripped_dark_oak_log
setblock 518 285 333 minecraft:stripped_dark_oak_log
setblock 518 285 340 minecraft:stripped_dark_oak_log
setblock 518 285 347 minecraft:stripped_dark_oak_log
setblock 518 285 354 minecraft:stripped_dark_oak_log
setblock 518 285 361 minecraft:stripped_dark_oak_log
setblock 523 285 363 minecraft:stripped_dark_oak_log
setblock 529 285 323 minecraft:stripped_dark_oak_log
setblock 530 285 363 minecraft:stripped_dark_oak_log
setblock 536 285 323 minecraft:stripped_dark_oak_log
setblock 537 285 363 minecraft:stripped_dark_oak_log
setblock 544 285 363 minecraft:stripped_dark_oak_log
setblock 551 285 363 minecraft:stripped_dark_oak_log
setblock 557 285 323 minecraft:stripped_dark_oak_log
setblock 558 285 343 minecraft:stripped_dark_oak_log
setblock 558 285 350 minecraft:stripped_dark_oak_log
setblock 558 285 357 minecraft:stripped_dark_oak_log
setblock 558 285 363 minecraft:stripped_dark_oak_log
fill 517 286 323 517 307 323 minecraft:white_terracotta
setblock 517 286 324 minecraft:shroomlight
fill 517 286 325 517 307 325 minecraft:white_terracotta
setblock 517 286 326 minecraft:shroomlight
fill 517 286 327 517 307 327 minecraft:white_terracotta
setblock 517 286 328 minecraft:shroomlight
setblock 518 286 323 minecraft:shroomlight
fill 518 286 324 518 300 324 minecraft:stripped_dark_oak_log
setblock 518 286 325 minecraft:shroomlight
fill 518 286 326 518 300 326 minecraft:stripped_dark_oak_log
setblock 518 286 327 minecraft:shroomlight
fill 518 286 328 518 300 328 minecraft:stripped_dark_oak_log
setblock 518 286 334 minecraft:stripped_dark_oak_log
setblock 518 286 341 minecraft:stripped_dark_oak_log
setblock 518 286 348 minecraft:stripped_dark_oak_log
setblock 518 286 355 minecraft:stripped_dark_oak_log
setblock 518 286 362 minecraft:stripped_dark_oak_log
fill 519 286 323 519 300 323 minecraft:stripped_dark_oak_log
setblock 519 286 324 minecraft:shroomlight
fill 519 286 325 519 300 325 minecraft:stripped_dark_oak_log
setblock 519 286 326 minecraft:shroomlight
fill 519 286 327 519 300 327 minecraft:stripped_dark_oak_log
setblock 519 286 328 minecraft:shroomlight
setblock 520 286 323 minecraft:shroomlight
fill 520 286 324 520 300 324 minecraft:stripped_dark_oak_log
setblock 520 286 325 minecraft:shroomlight
fill 520 286 326 520 300 326 minecraft:stripped_dark_oak_log
setblock 520 286 327 minecraft:shroomlight
fill 520 286 328 520 300 328 minecraft:stripped_dark_oak_log
fill 521 286 323 521 300 323 minecraft:stripped_dark_oak_log
setblock 521 286 324 minecraft:shroomlight
fill 521 286 325 521 300 325 minecraft:stripped_dark_oak_log
setblock 521 286 326 minecraft:shroomlight
fill 521 286 327 521 300 327 minecraft:stripped_dark_oak_log
setblock 521 286 328 minecraft:shroomlight
setblock 522 286 323 minecraft:shroomlight
fill 522 286 324 522 300 324 minecraft:stripped_dark_oak_log
setblock 522 286 325 minecraft:shroomlight
fill 522 286 326 522 300 326 minecraft:stripped_dark_oak_log
setblock 522 286 327 minecraft:shroomlight
fill 522 286 328 522 300 328 minecraft:stripped_dark_oak_log
fill 523 286 323 523 300 323 minecraft:stripped_dark_oak_log
setblock 523 286 324 minecraft:shroomlight
fill 523 286 325 523 300 325 minecraft:stripped_dark_oak_log
setblock 523 286 326 minecraft:shroomlight
fill 523 286 327 523 300 327 minecraft:stripped_dark_oak_log
setblock 523 286 328 minecraft:shroomlight
setblock 524 286 323 minecraft:shroomlight
fill 524 286 324 524 300 324 minecraft:stripped_dark_oak_log
setblock 524 286 325 minecraft:shroomlight
fill 524 286 326 524 300 326 minecraft:stripped_dark_oak_log
setblock 524 286 327 minecraft:shroomlight
fill 524 286 328 524 300 328 minecraft:stripped_dark_oak_log
setblock 524 286 363 minecraft:stripped_dark_oak_log
fill 525 286 323 525 300 323 minecraft:stripped_dark_oak_log
setblock 525 286 324 minecraft:shroomlight
fill 525 286 325 525 300 325 minecraft:stripped_dark_oak_log
setblock 525 286 326 minecraft:shroomlight
fill 525 286 327 525 300 327 minecraft:stripped_dark_oak_log
setblock 525 286 328 minecraft:shroomlight
setblock 526 286 323 minecraft:shroomlight
fill 526 286 324 526 300 324 minecraft:stripped_dark_oak_log
setblock 526 286 325 minecraft:shroomlight
fill 526 286 326 526 300 326 minecraft:stripped_dark_oak_log
setblock 526 286 327 minecraft:shroomlight
fill 526 286 328 526 300 328 minecraft:stripped_dark_oak_log
fill 527 286 323 528 286 323 minecraft:stripped_dark_oak_log
setblock 527 286 324 minecraft:shroomlight
fill 527 286 325 527 300 325 minecraft:stripped_dark_oak_log
setblock 527 286 326 minecraft:shroomlight
fill 527 286 327 527 300 327 minecraft:stripped_dark_oak_log
setblock 527 286 328 minecraft:shroomlight
setblock 531 286 363 minecraft:stripped_dark_oak_log
setblock 535 286 323 minecraft:stripped_dark_oak_log
setblock 538 286 363 minecraft:stripped_dark_oak_log
fill 539 286 323 539 297 323 minecraft:stripped_dark_oak_log
setblock 539 286 324 minecraft:shroomlight
fill 539 286 325 539 297 325 minecraft:stripped_dark_oak_log
setblock 539 286 326 minecraft:shroomlight
fill 539 286 327 539 297 327 minecraft:stripped_dark_oak_log
setblock 539 286 328 minecraft:shroomlight
fill 539 286 329 539 297 329 minecraft:stripped_dark_oak_log
setblock 539 286 330 minecraft:shroomlight
setblock 540 286 323 minecraft:shroomlight
fill 540 286 324 540 297 324 minecraft:stripped_dark_oak_log
setblock 540 286 325 minecraft:shroomlight
fill 540 286 326 540 297 326 minecraft:stripped_dark_oak_log
setblock 540 286 327 minecraft:shroomlight
fill 540 286 328 540 297 328 minecraft:stripped_dark_oak_log
setblock 540 286 329 minecraft:shroomlight
fill 540 286 330 540 297 330 minecraft:stripped_dark_oak_log
fill 541 286 323 541 300 323 minecraft:stripped_dark_oak_log
setblock 541 286 324 minecraft:shroomlight
fill 541 286 325 541 297 325 minecraft:stripped_dark_oak_log
setblock 541 286 326 minecraft:shroomlight
fill 541 286 327 541 297 327 minecraft:stripped_dark_oak_log
setblock 541 286 328 minecraft:shroomlight
fill 541 286 329 541 297 329 minecraft:stripped_dark_oak_log
setblock 541 286 330 minecraft:shroomlight
setblock 542 286 323 minecraft:shroomlight
fill 542 286 324 542 297 324 minecraft:stripped_dark_oak_log
setblock 542 286 325 minecraft:shroomlight
fill 542 286 326 542 297 326 minecraft:stripped_dark_oak_log
setblock 542 286 327 minecraft:shroomlight
fill 542 286 328 542 297 328 minecraft:stripped_dark_oak_log
setblock 542 286 329 minecraft:shroomlight
fill 542 286 330 542 297 330 minecraft:stripped_dark_oak_log
fill 543 286 323 543 297 323 minecraft:stripped_dark_oak_log
setblock 543 286 324 minecraft:shroomlight
fill 543 286 325 543 297 325 minecraft:stripped_dark_oak_log
setblock 543 286 326 minecraft:shroomlight
fill 543 286 327 543 297 327 minecraft:stripped_dark_oak_log
setblock 543 286 328 minecraft:shroomlight
fill 543 286 329 543 297 329 minecraft:stripped_dark_oak_log
setblock 543 286 330 minecraft:shroomlight
fill 543 286 349 543 287 350 minecraft:cherry_leaves[persistent=true]
setblock 544 286 323 minecraft:shroomlight
fill 544 286 324 544 297 324 minecraft:stripped_dark_oak_log
setblock 544 286 325 minecraft:shroomlight
fill 544 286 326 544 297 326 minecraft:stripped_dark_oak_log
setblock 544 286 327 minecraft:shroomlight
fill 544 286 328 544 297 328 minecraft:stripped_dark_oak_log
setblock 544 286 329 minecraft:shroomlight
fill 544 286 330 544 297 330 minecraft:stripped_dark_oak_log
fill 545 286 323 545 297 323 minecraft:stripped_dark_oak_log
setblock 545 286 324 minecraft:shroomlight
fill 545 286 325 545 297 325 minecraft:stripped_dark_oak_log
setblock 545 286 326 minecraft:shroomlight
fill 545 286 327 545 297 327 minecraft:stripped_dark_oak_log
setblock 545 286 328 minecraft:shroomlight
fill 545 286 329 545 297 329 minecraft:stripped_dark_oak_log
setblock 545 286 330 minecraft:shroomlight
setblock 545 286 363 minecraft:stripped_dark_oak_log
setblock 546 286 323 minecraft:shroomlight
fill 546 286 324 546 297 324 minecraft:stripped_dark_oak_log
setblock 546 286 325 minecraft:shroomlight
fill 546 286 326 546 297 326 minecraft:stripped_dark_oak_log
setblock 546 286 327 minecraft:shroomlight
fill 546 286 328 546 297 328 minecraft:stripped_dark_oak_log
setblock 546 286 329 minecraft:shroomlight
fill 546 286 330 546 297 330 minecraft:stripped_dark_oak_log
fill 547 286 323 547 297 323 minecraft:stripped_dark_oak_log
setblock 547 286 324 minecraft:shroomlight
fill 547 286 325 547 297 325 minecraft:stripped_dark_oak_log
setblock 547 286 326 minecraft:shroomlight
fill 547 286 327 547 297 327 minecraft:stripped_dark_oak_log
setblock 547 286 328 minecraft:shroomlight
fill 547 286 329 547 297 329 minecraft:stripped_dark_oak_log
setblock 547 286 330 minecraft:shroomlight
setblock 548 286 323 minecraft:shroomlight
fill 548 286 324 548 297 324 minecraft:stripped_dark_oak_log
setblock 548 286 325 minecraft:shroomlight
fill 548 286 326 548 297 326 minecraft:stripped_dark_oak_log
setblock 548 286 327 minecraft:shroomlight
fill 548 286 328 548 297 328 minecraft:stripped_dark_oak_log
setblock 548 286 329 minecraft:shroomlight
fill 548 286 330 548 297 330 minecraft:stripped_dark_oak_log
fill 549 286 323 549 297 323 minecraft:stripped_dark_oak_log
setblock 549 286 324 minecraft:shroomlight
fill 549 286 325 549 297 325 minecraft:stripped_dark_oak_log
setblock 549 286 326 minecraft:shroomlight
fill 549 286 327 549 297 327 minecraft:stripped_dark_oak_log
setblock 549 286 328 minecraft:shroomlight
fill 549 286 329 549 297 329 minecraft:stripped_dark_oak_log
setblock 549 286 330 minecraft:shroomlight
setblock 550 286 323 minecraft:shroomlight
fill 550 286 324 550 297 324 minecraft:stripped_dark_oak_log
setblock 550 286 325 minecraft:shroomlight
fill 550 286 326 550 297 326 minecraft:stripped_dark_oak_log
setblock 550 286 327 minecraft:shroomlight
fill 550 286 328 550 297 328 minecraft:stripped_dark_oak_log
setblock 550 286 329 minecraft:shroomlight
fill 550 286 330 550 297 330 minecraft:stripped_dark_oak_log
fill 551 286 323 551 298 323 minecraft:stripped_dark_oak_log
setblock 551 286 324 minecraft:shroomlight
fill 551 286 325 551 297 325 minecraft:stripped_dark_oak_log
setblock 551 286 326 minecraft:shroomlight
fill 551 286 327 551 297 327 minecraft:stripped_dark_oak_log
setblock 551 286 328 minecraft:shroomlight
fill 551 286 329 551 297 329 minecraft:stripped_dark_oak_log
setblock 551 286 330 minecraft:shroomlight
setblock 552 286 363 minecraft:stripped_dark_oak_log
setblock 556 286 323 minecraft:stripped_dark_oak_log
setblock 558 286 342 minecraft:stripped_dark_oak_log
setblock 558 286 349 minecraft:stripped_dark_oak_log
setblock 558 286 356 minecraft:stripped_dark_oak_log
fill 517 287 324 517 288 324 minecraft:white_terracotta
fill 517 287 326 517 288 326 minecraft:white_terracotta
fill 517 287 328 517 288 328 minecraft:white_terracotta
fill 518 287 323 518 288 323 minecraft:stripped_dark_oak_log
fill 518 287 325 518 288 325 minecraft:stripped_dark_oak_log
fill 518 287 327 518 288 327 minecraft:stripped_dark_oak_log
fill 519 287 324 519 288 324 minecraft:stripped_dark_oak_log
fill 519 287 326 519 288 326 minecraft:stripped_dark_oak_log
fill 519 287 328 519 288 328 minecraft:stripped_dark_oak_log
fill 520 287 323 520 288 323 minecraft:stripped_dark_oak_log
fill 520 287 325 520 288 325 minecraft:stripped_dark_oak_log
fill 520 287 327 520 288 327 minecraft:stripped_dark_oak_log
fill 521 287 324 521 288 324 minecraft:stripped_dark_oak_log
fill 521 287 326 521 288 326 minecraft:stripped_dark_oak_log
fill 521 287 328 521 288 328 minecraft:stripped_dark_oak_log
fill 522 287 323 522 288 323 minecraft:stripped_dark_oak_log
fill 522 287 325 522 288 325 minecraft:stripped_dark_oak_log
fill 522 287 327 522 288 327 minecraft:stripped_dark_oak_log
fill 523 287 324 523 288 324 minecraft:stripped_dark_oak_log
fill 523 287 326 523 288 326 minecraft:stripped_dark_oak_log
fill 523 287 328 523 288 328 minecraft:stripped_dark_oak_log
fill 524 287 323 524 288 323 minecraft:stripped_dark_oak_log
fill 524 287 325 524 288 325 minecraft:stripped_dark_oak_log
fill 524 287 327 524 288 327 minecraft:stripped_dark_oak_log
fill 525 287 324 525 288 324 minecraft:stripped_dark_oak_log
fill 525 287 326 525 288 326 minecraft:stripped_dark_oak_log
fill 525 287 328 525 288 328 minecraft:stripped_dark_oak_log
fill 526 287 323 527 288 323 minecraft:stripped_dark_oak_log
fill 526 287 325 526 288 325 minecraft:stripped_dark_oak_log
fill 526 287 327 526 288 327 minecraft:stripped_dark_oak_log
fill 527 287 324 527 288 324 minecraft:stripped_dark_oak_log
fill 527 287 326 527 288 326 minecraft:stripped_dark_oak_log
fill 527 287 328 527 288 328 minecraft:stripped_dark_oak_log
fill 533 287 323 533 287 325 minecraft:iron_bars
fill 539 287 324 539 288 324 minecraft:stripped_dark_oak_log
fill 539 287 326 539 288 326 minecraft:stripped_dark_oak_log
fill 539 287 328 539 288 328 minecraft:stripped_dark_oak_log
fill 539 287 330 539 288 330 minecraft:stripped_dark_oak_log
fill 540 287 323 540 288 323 minecraft:stripped_dark_oak_log
fill 540 287 325 540 288 325 minecraft:stripped_dark_oak_log
fill 540 287 327 540 288 327 minecraft:stripped_dark_oak_log
fill 540 287 329 540 288 329 minecraft:stripped_dark_oak_log
fill 541 287 324 541 288 324 minecraft:stripped_dark_oak_log
fill 541 287 326 541 288 326 minecraft:stripped_dark_oak_log
fill 541 287 328 541 288 328 minecraft:stripped_dark_oak_log
fill 541 287 330 541 288 330 minecraft:stripped_dark_oak_log
fill 542 287 323 542 288 323 minecraft:stripped_dark_oak_log
fill 542 287 325 542 288 325 minecraft:stripped_dark_oak_log
fill 542 287 327 542 288 327 minecraft:stripped_dark_oak_log
fill 542 287 329 542 288 329 minecraft:stripped_dark_oak_log
fill 543 287 324 543 288 324 minecraft:stripped_dark_oak_log
fill 543 287 326 543 288 326 minecraft:stripped_dark_oak_log
fill 543 287 328 543 288 328 minecraft:stripped_dark_oak_log
fill 543 287 330 543 288 330 minecraft:stripped_dark_oak_log
fill 544 287 323 544 288 323 minecraft:stripped_dark_oak_log
fill 544 287 325 544 288 325 minecraft:stripped_dark_oak_log
fill 544 287 327 544 288 327 minecraft:stripped_dark_oak_log
fill 544 287 329 544 288 329 minecraft:stripped_dark_oak_log
fill 545 287 324 545 288 324 minecraft:stripped_dark_oak_log
fill 545 287 326 545 288 326 minecraft:stripped_dark_oak_log
fill 545 287 328 545 288 328 minecraft:stripped_dark_oak_log
fill 545 287 330 545 288 330 minecraft:stripped_dark_oak_log
fill 546 287 323 546 288 323 minecraft:stripped_dark_oak_log
fill 546 287 325 546 288 325 minecraft:stripped_dark_oak_log
fill 546 287 327 546 288 327 minecraft:stripped_dark_oak_log
fill 546 287 329 546 288 329 minecraft:stripped_dark_oak_log
fill 547 287 324 547 288 324 minecraft:stripped_dark_oak_log
fill 547 287 326 547 288 326 minecraft:stripped_dark_oak_log
fill 547 287 328 547 288 328 minecraft:stripped_dark_oak_log
fill 547 287 330 547 288 330 minecraft:stripped_dark_oak_log
fill 548 287 323 548 288 323 minecraft:stripped_dark_oak_log
fill 548 287 325 548 288 325 minecraft:stripped_dark_oak_log
fill 548 287 327 548 288 327 minecraft:stripped_dark_oak_log
fill 548 287 329 548 288 329 minecraft:stripped_dark_oak_log
fill 549 287 324 549 288 324 minecraft:stripped_dark_oak_log
fill 549 287 326 549 288 326 minecraft:stripped_dark_oak_log
fill 549 287 328 549 288 328 minecraft:stripped_dark_oak_log
fill 549 287 330 549 288 330 minecraft:stripped_dark_oak_log
fill 550 287 323 550 288 323 minecraft:stripped_dark_oak_log
fill 550 287 325 550 288 325 minecraft:stripped_dark_oak_log
fill 550 287 327 550 288 327 minecraft:stripped_dark_oak_log
fill 550 287 329 550 288 329 minecraft:stripped_dark_oak_log
fill 551 287 324 551 288 324 minecraft:stripped_dark_oak_log
fill 551 287 326 551 288 326 minecraft:stripped_dark_oak_log
fill 551 287 328 551 288 328 minecraft:stripped_dark_oak_log
fill 551 287 330 551 288 330 minecraft:stripped_dark_oak_log
setblock 518 288 329 minecraft:stripped_dark_oak_log
setblock 518 288 336 minecraft:stripped_dark_oak_log
setblock 518 288 343 minecraft:stripped_dark_oak_log
setblock 518 288 350 minecraft:stripped_dark_oak_log
setblock 518 288 357 minecraft:stripped_dark_oak_log
setblock 519 288 363 minecraft:stripped_dark_oak_log
setblock 526 288 363 minecraft:stripped_dark_oak_log
setblock 533 288 323 minecraft:stripped_dark_oak_log
fill 533 288 324 533 288 325 minecraft:iron_bars
setblock 533 288 363 minecraft:stripped_dark_oak_log
setblock 540 288 363 minecraft:stripped_dark_oak_log
setblock 547 288 363 minecraft:stripped_dark_oak_log
setblock 554 288 323 minecraft:stripped_dark_oak_log
setblock 554 288 363 minecraft:stripped_dark_oak_log
setblock 558 288 326 minecraft:stripped_dark_oak_log
setblock 558 288 347 minecraft:stripped_dark_oak_log
setblock 558 288 354 minecraft:stripped_dark_oak_log
setblock 558 288 361 minecraft:stripped_dark_oak_log
setblock 517 289 324 minecraft:shroomlight
setblock 517 289 326 minecraft:shroomlight
setblock 517 289 328 minecraft:shroomlight
setblock 518 289 323 minecraft:shroomlight
setblock 518 289 325 minecraft:shroomlight
setblock 518 289 327 minecraft:shroomlight
fill 518 289 330 518 290 330 minecraft:stripped_dark_oak_log
fill 518 289 337 518 290 337 minecraft:stripped_dark_oak_log
fill 518 289 344 518 290 344 minecraft:stripped_dark_oak_log
fill 518 289 351 518 290 351 minecraft:stripped_dark_oak_log
fill 518 289 358 518 290 358 minecraft:stripped_dark_oak_log
setblock 519 289 324 minecraft:shroomlight
setblock 519 289 326 minecraft:shroomlight
setblock 519 289 328 minecraft:shroomlight
setblock 520 289 323 minecraft:shroomlight
setblock 520 289 325 minecraft:shroomlight
setblock 520 289 327 minecraft:shroomlight
fill 520 289 363 520 290 363 minecraft:stripped_dark_oak_log
setblock 521 289 324 minecraft:shroomlight
setblock 521 289 326 minecraft:shroomlight
setblock 521 289 328 minecraft:shroomlight
setblock 522 289 323 minecraft:shroomlight
setblock 522 289 325 minecraft:shroomlight
setblock 522 289 327 minecraft:shroomlight
setblock 523 289 324 minecraft:shroomlight
setblock 523 289 326 minecraft:shroomlight
setblock 523 289 328 minecraft:shroomlight
setblock 524 289 323 minecraft:shroomlight
setblock 524 289 325 minecraft:shroomlight
setblock 524 289 327 minecraft:shroomlight
setblock 525 289 324 minecraft:shroomlight
setblock 525 289 326 minecraft:shroomlight
setblock 525 289 328 minecraft:shroomlight
setblock 526 289 323 minecraft:shroomlight
setblock 526 289 325 minecraft:shroomlight
setblock 526 289 327 minecraft:shroomlight
fill 527 289 323 527 300 323 minecraft:stripped_dark_oak_log
setblock 527 289 324 minecraft:shroomlight
setblock 527 289 326 minecraft:shroomlight
setblock 527 289 328 minecraft:shroomlight
fill 527 289 363 527 290 363 minecraft:stripped_dark_oak_log
fill 532 289 323 532 290 323 minecraft:stripped_dark_oak_log
fill 534 289 363 534 290 363 minecraft:stripped_dark_oak_log
setblock 539 289 324 minecraft:shroomlight
setblock 539 289 326 minecraft:shroomlight
setblock 539 289 328 minecraft:shroomlight
setblock 539 289 330 minecraft:shroomlight
setblock 540 289 323 minecraft:shroomlight
setblock 540 289 325 minecraft:shroomlight
setblock 540 289 327 minecraft:shroomlight
setblock 540 289 329 minecraft:shroomlight
setblock 541 289 324 minecraft:shroomlight
setblock 541 289 326 minecraft:shroomlight
setblock 541 289 328 minecraft:shroomlight
setblock 541 289 330 minecraft:shroomlight
fill 541 289 363 541 290 363 minecraft:stripped_dark_oak_log
setblock 542 289 323 minecraft:shroomlight
setblock 542 289 325 minecraft:shroomlight
setblock 542 289 327 minecraft:shroomlight
setblock 542 289 329 minecraft:shroomlight
setblock 543 289 324 minecraft:shroomlight
setblock 543 289 326 minecraft:shroomlight
setblock 543 289 328 minecraft:shroomlight
setblock 543 289 330 minecraft:shroomlight
setblock 544 289 323 minecraft:shroomlight
setblock 544 289 325 minecraft:shroomlight
setblock 544 289 327 minecraft:shroomlight
setblock 544 289 329 minecraft:shroomlight
setblock 545 289 324 minecraft:shroomlight
setblock 545 289 326 minecraft:shroomlight
setblock 545 289 328 minecraft:shroomlight
setblock 545 289 330 minecraft:shroomlight
setblock 546 289 323 minecraft:shroomlight
setblock 546 289 325 minecraft:shroomlight
setblock 546 289 327 minecraft:shroomlight
setblock 546 289 329 minecraft:shroomlight
setblock 547 289 324 minecraft:shroomlight
setblock 547 289 326 minecraft:shroomlight
setblock 547 289 328 minecraft:shroomlight
setblock 547 289 330 minecraft:shroomlight
setblock 548 289 323 minecraft:shroomlight
setblock 548 289 325 minecraft:shroomlight
setblock 548 289 327 minecraft:shroomlight
setblock 548 289 329 minecraft:shroomlight
fill 548 289 363 548 290 363 minecraft:stripped_dark_oak_log
setblock 549 289 324 minecraft:shroomlight
setblock 549 289 326 minecraft:shroomlight
setblock 549 289 328 minecraft:shroomlight
setblock 549 289 330 minecraft:shroomlight
setblock 550 289 323 minecraft:shroomlight
setblock 550 289 325 minecraft:shroomlight
setblock 550 289 327 minecraft:shroomlight
setblock 550 289 329 minecraft:shroomlight
setblock 551 289 324 minecraft:shroomlight
setblock 551 289 326 minecraft:shroomlight
setblock 551 289 328 minecraft:shroomlight
setblock 551 289 330 minecraft:shroomlight
fill 553 289 323 553 290 323 minecraft:stripped_dark_oak_log
fill 555 289 363 555 290 363 minecraft:stripped_dark_oak_log
fill 558 289 325 558 290 325 minecraft:stripped_dark_oak_log
fill 558 289 346 558 290 346 minecraft:stripped_dark_oak_log
fill 558 289 353 558 290 353 minecraft:stripped_dark_oak_log
fill 558 289 360 558 290 360 minecraft:stripped_dark_oak_log
fill 517 290 324 517 291 324 minecraft:white_terracotta
fill 517 290 326 517 291 326 minecraft:white_terracotta
fill 517 290 328 517 291 328 minecraft:white_terracotta
fill 518 290 323 518 291 323 minecraft:stripped_dark_oak_log
fill 518 290 325 518 291 325 minecraft:stripped_dark_oak_log
fill 518 290 327 518 291 327 minecraft:stripped_dark_oak_log
setblock 518 290 329 minecraft:stripped_dark_oak_log
fill 518 290 331 518 290 334 minecraft:stripped_dark_oak_log
setblock 518 290 336 minecraft:stripped_dark_oak_log
fill 518 290 338 518 290 341 minecraft:stripped_dark_oak_log
setblock 518 290 343 minecraft:stripped_dark_oak_log
fill 518 290 345 518 290 348 minecraft:stripped_dark_oak_log
setblock 518 290 350 minecraft:stripped_dark_oak_log
fill 518 290 352 518 290 355 minecraft:stripped_dark_oak_log
setblock 518 290 357 minecraft:stripped_dark_oak_log
fill 518 290 359 518 290 362 minecraft:stripped_dark_oak_log
fill 519 290 324 519 291 324 minecraft:stripped_dark_oak_log
fill 519 290 326 519 291 326 minecraft:stripped_dark_oak_log
fill 519 290 328 519 291 328 minecraft:stripped_dark_oak_log
setblock 519 290 363 minecraft:stripped_dark_oak_log
fill 520 290 323 520 291 323 minecraft:stripped_dark_oak_log
fill 520 290 325 520 291 325 minecraft:stripped_dark_oak_log
fill 520 290 327 520 291 327 minecraft:stripped_dark_oak_log
fill 521 290 324 521 291 324 minecraft:stripped_dark_oak_log
fill 521 290 326 521 291 326 minecraft:stripped_dark_oak_log
fill 521 290 328 521 291 328 minecraft:stripped_dark_oak_log
fill 521 290 363 524 290 363 minecraft:stripped_dark_oak_log
fill 522 290 323 522 291 323 minecraft:stripped_dark_oak_log
fill 522 290 325 522 291 325 minecraft:stripped_dark_oak_log
fill 522 290 327 522 291 327 minecraft:stripped_dark_oak_log
fill 523 290 324 523 291 324 minecraft:stripped_dark_oak_log
fill 523 290 326 523 291 326 minecraft:stripped_dark_oak_log
fill 523 290 328 523 291 328 minecraft:stripped_dark_oak_log
fill 524 290 323 524 291 323 minecraft:stripped_dark_oak_log
fill 524 290 325 524 291 325 minecraft:stripped_dark_oak_log
fill 524 290 327 524 291 327 minecraft:stripped_dark_oak_log
fill 525 290 324 525 291 324 minecraft:stripped_dark_oak_log
fill 525 290 326 525 291 326 minecraft:stripped_dark_oak_log
fill 525 290 328 525 291 328 minecraft:stripped_dark_oak_log
fill 526 290 323 526 291 323 minecraft:stripped_dark_oak_log
fill 526 290 325 526 291 325 minecraft:stripped_dark_oak_log
fill 526 290 327 526 291 327 minecraft:stripped_dark_oak_log
setblock 526 290 363 minecraft:stripped_dark_oak_log
fill 527 290 324 527 291 324 minecraft:stripped_dark_oak_log
fill 527 290 326 527 291 326 minecraft:stripped_dark_oak_log
fill 527 290 328 527 291 328 minecraft:stripped_dark_oak_log
fill 528 290 323 531 290 323 minecraft:stripped_dark_oak_log
fill 528 290 363 531 290 363 minecraft:stripped_dark_oak_log
setblock 533 290 323 minecraft:stripped_dark_oak_log
setblock 533 290 363 minecraft:stripped_dark_oak_log
fill 535 290 323 538 290 323 minecraft:stripped_dark_oak_log
fill 535 290 363 538 290 363 minecraft:stripped_dark_oak_log
fill 539 290 324 539 291 324 minecraft:stripped_dark_oak_log
fill 539 290 326 539 291 326 minecraft:stripped_dark_oak_log
fill 539 290 328 539 291 328 minecraft:stripped_dark_oak_log
fill 539 290 330 539 291 330 minecraft:stripped_dark_oak_log
fill 540 290 323 540 291 323 minecraft:stripped_dark_oak_log
fill 540 290 325 540 291 325 minecraft:stripped_dark_oak_log
fill 540 290 327 540 291 327 minecraft:stripped_dark_oak_log
fill 540 290 329 540 291 329 minecraft:stripped_dark_oak_log
setblock 540 290 363 minecraft:stripped_dark_oak_log
fill 541 290 324 541 291 324 minecraft:stripped_dark_oak_log
fill 541 290 326 541 291 326 minecraft:stripped_dark_oak_log
fill 541 290 328 541 291 328 minecraft:stripped_dark_oak_log
fill 541 290 330 541 291 330 minecraft:stripped_dark_oak_log
fill 542 290 323 542 291 323 minecraft:stripped_dark_oak_log
fill 542 290 325 542 291 325 minecraft:stripped_dark_oak_log
fill 542 290 327 542 291 327 minecraft:stripped_dark_oak_log
fill 542 290 329 542 291 329 minecraft:stripped_dark_oak_log
fill 542 290 363 545 290 363 minecraft:stripped_dark_oak_log
fill 543 290 324 543 291 324 minecraft:stripped_dark_oak_log
fill 543 290 326 543 291 326 minecraft:stripped_dark_oak_log
fill 543 290 328 543 291 328 minecraft:stripped_dark_oak_log
fill 543 290 330 543 291 330 minecraft:stripped_dark_oak_log
fill 544 290 323 544 291 323 minecraft:stripped_dark_oak_log
fill 544 290 325 544 291 325 minecraft:stripped_dark_oak_log
fill 544 290 327 544 291 327 minecraft:stripped_dark_oak_log
fill 544 290 329 544 291 329 minecraft:stripped_dark_oak_log
fill 545 290 324 545 291 324 minecraft:stripped_dark_oak_log
fill 545 290 326 545 291 326 minecraft:stripped_dark_oak_log
fill 545 290 328 545 291 328 minecraft:stripped_dark_oak_log
fill 545 290 330 545 291 330 minecraft:stripped_dark_oak_log
fill 546 290 323 546 291 323 minecraft:stripped_dark_oak_log
fill 546 290 325 546 291 325 minecraft:stripped_dark_oak_log
fill 546 290 327 546 291 327 minecraft:stripped_dark_oak_log
fill 546 290 329 546 291 329 minecraft:stripped_dark_oak_log
fill 547 290 324 547 291 324 minecraft:stripped_dark_oak_log
fill 547 290 326 547 291 326 minecraft:stripped_dark_oak_log
fill 547 290 328 547 291 328 minecraft:stripped_dark_oak_log
fill 547 290 330 547 291 330 minecraft:stripped_dark_oak_log
setblock 547 290 363 minecraft:stripped_dark_oak_log
fill 548 290 323 548 291 323 minecraft:stripped_dark_oak_log
fill 548 290 325 548 291 325 minecraft:stripped_dark_oak_log
fill 548 290 327 548 291 327 minecraft:stripped_dark_oak_log
fill 548 290 329 548 291 329 minecraft:stripped_dark_oak_log
fill 549 290 324 549 291 324 minecraft:stripped_dark_oak_log
fill 549 290 326 549 291 326 minecraft:stripped_dark_oak_log
fill 549 290 328 549 291 328 minecraft:stripped_dark_oak_log
fill 549 290 330 549 291 330 minecraft:stripped_dark_oak_log
fill 549 290 363 552 290 363 minecraft:stripped_dark_oak_log
fill 550 290 323 550 291 323 minecraft:stripped_dark_oak_log
fill 550 290 325 550 291 325 minecraft:stripped_dark_oak_log
fill 550 290 327 550 291 327 minecraft:stripped_dark_oak_log
fill 550 290 329 550 291 329 minecraft:stripped_dark_oak_log
fill 551 290 324 551 291 324 minecraft:stripped_dark_oak_log
fill 551 290 326 551 291 326 minecraft:stripped_dark_oak_log
fill 551 290 328 551 291 328 minecraft:stripped_dark_oak_log
fill 551 290 330 551 291 330 minecraft:stripped_dark_oak_log
setblock 552 290 323 minecraft:stripped_dark_oak_log
setblock 554 290 323 minecraft:stripped_dark_oak_log
setblock 554 290 363 minecraft:stripped_dark_oak_log
fill 556 290 323 558 290 323 minecraft:stripped_dark_oak_log
fill 556 290 363 558 290 363 minecraft:stripped_dark_oak_log
setblock 558 290 324 minecraft:stripped_dark_oak_log
setblock 558 290 326 minecraft:stripped_dark_oak_log
fill 558 290 342 558 290 345 minecraft:stripped_dark_oak_log
setblock 558 290 347 minecraft:stripped_dark_oak_log
fill 558 290 349 558 290 352 minecraft:stripped_dark_oak_log
setblock 558 290 354 minecraft:stripped_dark_oak_log
fill 558 290 356 558 290 359 minecraft:stripped_dark_oak_log
setblock 558 290 361 minecraft:stripped_dark_oak_log
setblock 518 291 332 minecraft:stripped_dark_oak_log
setblock 518 291 339 minecraft:stripped_dark_oak_log
setblock 518 291 346 minecraft:stripped_dark_oak_log
setblock 518 291 353 minecraft:stripped_dark_oak_log
setblock 518 291 360 minecraft:stripped_dark_oak_log
setblock 522 291 363 minecraft:stripped_dark_oak_log
fill 527 291 360 527 292 362 minecraft:iron_bars
setblock 529 291 363 minecraft:stripped_dark_oak_log
setblock 530 291 323 minecraft:stripped_dark_oak_log
setblock 536 291 363 minecraft:stripped_dark_oak_log
setblock 537 291 323 minecraft:stripped_dark_oak_log
setblock 543 291 363 minecraft:stripped_dark_oak_log
setblock 550 291 363 minecraft:stripped_dark_oak_log
setblock 557 291 363 minecraft:stripped_dark_oak_log
setblock 558 291 323 minecraft:stripped_dark_oak_log
setblock 558 291 344 minecraft:stripped_dark_oak_log
setblock 558 291 351 minecraft:stripped_dark_oak_log
setblock 558 291 358 minecraft:stripped_dark_oak_log
setblock 517 292 324 minecraft:shroomlight
setblock 517 292 326 minecraft:shroomlight
setblock 517 292 328 minecraft:shroomlight
setblock 518 292 323 minecraft:shroomlight
setblock 518 292 325 minecraft:shroomlight
setblock 518 292 327 minecraft:shroomlight
setblock 518 292 333 minecraft:stripped_dark_oak_log
setblock 518 292 340 minecraft:stripped_dark_oak_log
setblock 518 292 347 minecraft:stripped_dark_oak_log
setblock 518 292 354 minecraft:stripped_dark_oak_log
setblock 518 292 361 minecraft:stripped_dark_oak_log
setblock 519 292 324 minecraft:shroomlight
setblock 519 292 326 minecraft:shroomlight
setblock 519 292 328 minecraft:shroomlight
setblock 520 292 323 minecraft:shroomlight
setblock 520 292 325 minecraft:shroomlight
setblock 520 292 327 minecraft:shroomlight
setblock 520 292 333 minecraft:light[level=14]
setblock 520 292 341 minecraft:light[level=14]
setblock 520 292 349 minecraft:light[level=14]
setblock 520 292 357 minecraft:light[level=14]
setblock 521 292 324 minecraft:shroomlight
setblock 521 292 326 minecraft:shroomlight
setblock 521 292 328 minecraft:shroomlight
setblock 522 292 323 minecraft:shroomlight
setblock 522 292 325 minecraft:shroomlight
setblock 522 292 327 minecraft:shroomlight
setblock 523 292 324 minecraft:shroomlight
setblock 523 292 326 minecraft:shroomlight
setblock 523 292 328 minecraft:shroomlight
setblock 523 292 363 minecraft:stripped_dark_oak_log
setblock 524 292 323 minecraft:shroomlight
setblock 524 292 325 minecraft:shroomlight
setblock 524 292 327 minecraft:shroomlight
setblock 525 292 324 minecraft:shroomlight
setblock 525 292 326 minecraft:shroomlight
setblock 525 292 328 minecraft:shroomlight
setblock 526 292 323 minecraft:shroomlight
setblock 526 292 325 minecraft:shroomlight
setblock 526 292 327 minecraft:shroomlight
setblock 527 292 324 minecraft:shroomlight
setblock 527 292 326 minecraft:shroomlight
setblock 527 292 328 minecraft:shroomlight
setblock 528 292 325 minecraft:light[level=14]
setblock 528 292 333 minecraft:light[level=14]
setblock 528 292 341 minecraft:light[level=14]
setblock 528 292 349 minecraft:light[level=14]
setblock 528 292 357 minecraft:light[level=14]
setblock 529 292 323 minecraft:stripped_dark_oak_log
setblock 530 292 363 minecraft:stripped_dark_oak_log
setblock 536 292 323 minecraft:stripped_dark_oak_log
setblock 536 292 325 minecraft:light[level=14]
setblock 536 292 333 minecraft:light[level=14]
setblock 536 292 349 minecraft:light[level=14]
setblock 536 292 357 minecraft:light[level=14]
setblock 537 292 363 minecraft:stripped_dark_oak_log
setblock 539 292 324 minecraft:shroomlight
setblock 539 292 326 minecraft:shroomlight
setblock 539 292 328 minecraft:shroomlight
setblock 539 292 330 minecraft:shroomlight
setblock 540 292 323 minecraft:shroomlight
setblock 540 292 325 minecraft:shroomlight
setblock 540 292 327 minecraft:shroomlight
setblock 540 292 329 minecraft:shroomlight
setblock 541 292 324 minecraft:shroomlight
setblock 541 292 326 minecraft:shroomlight
setblock 541 292 328 minecraft:shroomlight
setblock 541 292 330 minecraft:shroomlight
setblock 542 292 323 minecraft:shroomlight
setblock 542 292 325 minecraft:shroomlight
setblock 542 292 327 minecraft:shroomlight
setblock 542 292 329 minecraft:shroomlight
setblock 543 292 324 minecraft:shroomlight
setblock 543 292 326 minecraft:shroomlight
setblock 543 292 328 minecraft:shroomlight
setblock 543 292 330 minecraft:shroomlight
setblock 544 292 323 minecraft:shroomlight
setblock 544 292 325 minecraft:shroomlight
setblock 544 292 327 minecraft:shroomlight
setblock 544 292 329 minecraft:shroomlight
setblock 544 292 333 minecraft:light[level=14]
setblock 544 292 341 minecraft:light[level=14]
setblock 544 292 349 minecraft:light[level=14]
setblock 544 292 357 minecraft:light[level=14]
setblock 544 292 363 minecraft:stripped_dark_oak_log
setblock 545 292 324 minecraft:shroomlight
setblock 545 292 326 minecraft:shroomlight
setblock 545 292 328 minecraft:shroomlight
setblock 545 292 330 minecraft:shroomlight
setblock 546 292 323 minecraft:shroomlight
setblock 546 292 325 minecraft:shroomlight
setblock 546 292 327 minecraft:shroomlight
setblock 546 292 329 minecraft:shroomlight
setblock 547 292 324 minecraft:shroomlight
setblock 547 292 326 minecraft:shroomlight
setblock 547 292 328 minecraft:shroomlight
setblock 547 292 330 minecraft:shroomlight
setblock 548 292 323 minecraft:shroomlight
setblock 548 292 325 minecraft:shroomlight
setblock 548 292 327 minecraft:shroomlight
setblock 548 292 329 minecraft:shroomlight
setblock 549 292 324 minecraft:shroomlight
setblock 549 292 326 minecraft:shroomlight
setblock 549 292 328 minecraft:shroomlight
setblock 549 292 330 minecraft:shroomlight
setblock 550 292 323 minecraft:shroomlight
setblock 550 292 325 minecraft:shroomlight
setblock 550 292 327 minecraft:shroomlight
setblock 550 292 329 minecraft:shroomlight
setblock 551 292 324 minecraft:shroomlight
setblock 551 292 326 minecraft:shroomlight
setblock 551 292 328 minecraft:shroomlight
setblock 551 292 330 minecraft:shroomlight
setblock 551 292 363 minecraft:stripped_dark_oak_log
setblock 552 292 325 minecraft:light[level=14]
setblock 552 292 333 minecraft:light[level=14]
setblock 552 292 341 minecraft:light[level=14]
setblock 552 292 349 minecraft:light[level=14]
setblock 552 292 357 minecraft:light[level=14]
setblock 557 292 323 minecraft:stripped_dark_oak_log
setblock 558 292 343 minecraft:stripped_dark_oak_log
setblock 558 292 350 minecraft:stripped_dark_oak_log
setblock 558 292 357 minecraft:stripped_dark_oak_log
setblock 558 292 363 minecraft:stripped_dark_oak_log
fill 517 293 324 517 294 324 minecraft:white_terracotta
fill 517 293 326 517 294 326 minecraft:white_terracotta
fill 517 293 328 517 294 328 minecraft:white_terracotta
fill 518 293 323 518 294 323 minecraft:stripped_dark_oak_log
fill 518 293 325 518 294 325 minecraft:stripped_dark_oak_log
fill 518 293 327 518 294 327 minecraft:stripped_dark_oak_log
setblock 518 293 334 minecraft:stripped_dark_oak_log
setblock 518 293 341 minecraft:stripped_dark_oak_log
setblock 518 293 348 minecraft:stripped_dark_oak_log
setblock 518 293 355 minecraft:stripped_dark_oak_log
setblock 518 293 362 minecraft:stripped_dark_oak_log
fill 519 293 324 519 294 324 minecraft:stripped_dark_oak_log
fill 519 293 326 519 294 326 minecraft:stripped_dark_oak_log
fill 519 293 328 519 294 328 minecraft:stripped_dark_oak_log
fill 520 293 323 520 294 323 minecraft:stripped_dark_oak_log
fill 520 293 325 520 294 325 minecraft:stripped_dark_oak_log
fill 520 293 327 520 294 327 minecraft:stripped_dark_oak_log
fill 521 293 324 521 294 324 minecraft:stripped_dark_oak_log
fill 521 293 326 521 294 326 minecraft:stripped_dark_oak_log
fill 521 293 328 521 294 328 minecraft:stripped_dark_oak_log
fill 522 293 323 522 294 323 minecraft:stripped_dark_oak_log
fill 522 293 325 522 294 325 minecraft:stripped_dark_oak_log
fill 522 293 327 522 294 327 minecraft:stripped_dark_oak_log
fill 523 293 324 523 294 324 minecraft:stripped_dark_oak_log
fill 523 293 326 523 294 326 minecraft:stripped_dark_oak_log
fill 523 293 328 523 294 328 minecraft:stripped_dark_oak_log
fill 524 293 323 524 294 323 minecraft:stripped_dark_oak_log
fill 524 293 325 524 294 325 minecraft:stripped_dark_oak_log
fill 524 293 327 524 294 327 minecraft:stripped_dark_oak_log
setblock 524 293 363 minecraft:stripped_dark_oak_log
fill 525 293 324 525 294 324 minecraft:stripped_dark_oak_log
fill 525 293 326 525 294 326 minecraft:stripped_dark_oak_log
fill 525 293 328 525 294 328 minecraft:stripped_dark_oak_log
fill 526 293 323 526 294 323 minecraft:stripped_dark_oak_log
fill 526 293 325 526 294 325 minecraft:stripped_dark_oak_log
fill 526 293 327 526 294 327 minecraft:stripped_dark_oak_log
fill 527 293 324 527 294 324 minecraft:stripped_dark_oak_log
fill 527 293 326 527 294 326 minecraft:stripped_dark_oak_log
fill 527 293 328 527 294 328 minecraft:stripped_dark_oak_log
setblock 528 293 323 minecraft:stripped_dark_oak_log
setblock 531 293 363 minecraft:stripped_dark_oak_log
setblock 535 293 323 minecraft:stripped_dark_oak_log
setblock 538 293 363 minecraft:stripped_dark_oak_log
fill 539 293 324 539 294 324 minecraft:stripped_dark_oak_log
fill 539 293 326 539 294 326 minecraft:stripped_dark_oak_log
fill 539 293 328 539 294 328 minecraft:stripped_dark_oak_log
fill 539 293 330 539 294 330 minecraft:stripped_dark_oak_log
fill 540 293 323 540 294 323 minecraft:stripped_dark_oak_log
fill 540 293 325 540 294 325 minecraft:stripped_dark_oak_log
fill 540 293 327 540 294 327 minecraft:stripped_dark_oak_log
fill 540 293 329 540 294 329 minecraft:stripped_dark_oak_log
fill 541 293 324 541 294 324 minecraft:stripped_dark_oak_log
fill 541 293 326 541 294 326 minecraft:stripped_dark_oak_log
fill 541 293 328 541 294 328 minecraft:stripped_dark_oak_log
fill 541 293 330 541 294 330 minecraft:stripped_dark_oak_log
fill 542 293 323 542 294 323 minecraft:stripped_dark_oak_log
fill 542 293 325 542 294 325 minecraft:stripped_dark_oak_log
fill 542 293 327 542 294 327 minecraft:stripped_dark_oak_log
fill 542 293 329 542 294 329 minecraft:stripped_dark_oak_log
fill 543 293 324 543 294 324 minecraft:stripped_dark_oak_log
fill 543 293 326 543 294 326 minecraft:stripped_dark_oak_log
fill 543 293 328 543 294 328 minecraft:stripped_dark_oak_log
fill 543 293 330 543 294 330 minecraft:stripped_dark_oak_log
fill 544 293 323 544 294 323 minecraft:stripped_dark_oak_log
fill 544 293 325 544 294 325 minecraft:stripped_dark_oak_log
fill 544 293 327 544 294 327 minecraft:stripped_dark_oak_log
fill 544 293 329 544 294 329 minecraft:stripped_dark_oak_log
fill 545 293 324 545 294 324 minecraft:stripped_dark_oak_log
fill 545 293 326 545 294 326 minecraft:stripped_dark_oak_log
fill 545 293 328 545 294 328 minecraft:stripped_dark_oak_log
fill 545 293 330 545 294 330 minecraft:stripped_dark_oak_log
setblock 545 293 363 minecraft:stripped_dark_oak_log
fill 546 293 323 546 294 323 minecraft:stripped_dark_oak_log
fill 546 293 325 546 294 325 minecraft:stripped_dark_oak_log
fill 546 293 327 546 294 327 minecraft:stripped_dark_oak_log
fill 546 293 329 546 294 329 minecraft:stripped_dark_oak_log
fill 547 293 324 547 294 324 minecraft:stripped_dark_oak_log
fill 547 293 326 547 294 326 minecraft:stripped_dark_oak_log
fill 547 293 328 547 294 328 minecraft:stripped_dark_oak_log
fill 547 293 330 547 294 330 minecraft:stripped_dark_oak_log
fill 548 293 323 548 294 323 minecraft:stripped_dark_oak_log
fill 548 293 325 548 294 325 minecraft:stripped_dark_oak_log
fill 548 293 327 548 294 327 minecraft:stripped_dark_oak_log
fill 548 293 329 548 294 329 minecraft:stripped_dark_oak_log
fill 549 293 324 549 294 324 minecraft:stripped_dark_oak_log
fill 549 293 326 549 294 326 minecraft:stripped_dark_oak_log
fill 549 293 328 549 294 328 minecraft:stripped_dark_oak_log
fill 549 293 330 549 294 330 minecraft:stripped_dark_oak_log
fill 550 293 323 550 294 323 minecraft:stripped_dark_oak_log
fill 550 293 325 550 294 325 minecraft:stripped_dark_oak_log
fill 550 293 327 550 294 327 minecraft:stripped_dark_oak_log
fill 550 293 329 550 294 329 minecraft:stripped_dark_oak_log
fill 551 293 324 551 294 324 minecraft:stripped_dark_oak_log
fill 551 293 326 551 294 326 minecraft:stripped_dark_oak_log
fill 551 293 328 551 294 328 minecraft:stripped_dark_oak_log
fill 551 293 330 551 294 330 minecraft:stripped_dark_oak_log
setblock 552 293 363 minecraft:stripped_dark_oak_log
setblock 556 293 323 minecraft:stripped_dark_oak_log
setblock 558 293 342 minecraft:stripped_dark_oak_log
setblock 558 293 349 minecraft:stripped_dark_oak_log
setblock 558 293 356 minecraft:stripped_dark_oak_log
fill 520 294 340 521 295 341 minecraft:cherry_leaves[persistent=true]
fill 528 294 323 528 295 325 minecraft:iron_bars
setblock 517 295 324 minecraft:shroomlight
setblock 517 295 326 minecraft:shroomlight
setblock 517 295 328 minecraft:shroomlight
setblock 518 295 323 minecraft:shroomlight
setblock 518 295 325 minecraft:shroomlight
setblock 518 295 327 minecraft:shroomlight
setblock 518 295 329 minecraft:stripped_dark_oak_log
setblock 518 295 336 minecraft:stripped_dark_oak_log
setblock 518 295 343 minecraft:stripped_dark_oak_log
setblock 518 295 350 minecraft:stripped_dark_oak_log
setblock 518 295 357 minecraft:stripped_dark_oak_log
setblock 519 295 324 minecraft:shroomlight
setblock 519 295 326 minecraft:shroomlight
setblock 519 295 328 minecraft:shroomlight
setblock 519 295 363 minecraft:stripped_dark_oak_log
setblock 520 295 323 minecraft:shroomlight
setblock 520 295 325 minecraft:shroomlight
setblock 520 295 327 minecraft:shroomlight
setblock 521 295 324 minecraft:shroomlight
setblock 521 295 326 minecraft:shroomlight
setblock 521 295 328 minecraft:shroomlight
setblock 522 295 323 minecraft:shroomlight
setblock 522 295 325 minecraft:shroomlight
setblock 522 295 327 minecraft:shroomlight
setblock 523 295 324 minecraft:shroomlight
setblock 523 295 326 minecraft:shroomlight
setblock 523 295 328 minecraft:shroomlight
setblock 524 295 323 minecraft:shroomlight
setblock 524 295 325 minecraft:shroomlight
setblock 524 295 327 minecraft:shroomlight
setblock 525 295 324 minecraft:shroomlight
setblock 525 295 326 minecraft:shroomlight
setblock 525 295 328 minecraft:shroomlight
setblock 526 295 323 minecraft:shroomlight
setblock 526 295 325 minecraft:shroomlight
setblock 526 295 327 minecraft:shroomlight
setblock 526 295 363 minecraft:stripped_dark_oak_log
setblock 527 295 324 minecraft:shroomlight
setblock 527 295 326 minecraft:shroomlight
setblock 527 295 328 minecraft:shroomlight
setblock 533 295 323 minecraft:stripped_dark_oak_log
setblock 533 295 363 minecraft:stripped_dark_oak_log
fill 535 295 330 537 296 330 minecraft:pink_wool
fill 536 295 329 536 296 329 minecraft:pink_wool
setblock 539 295 324 minecraft:shroomlight
setblock 539 295 326 minecraft:shroomlight
setblock 539 295 328 minecraft:shroomlight
setblock 539 295 330 minecraft:shroomlight
setblock 540 295 323 minecraft:shroomlight
setblock 540 295 325 minecraft:shroomlight
setblock 540 295 327 minecraft:shroomlight
setblock 540 295 329 minecraft:shroomlight
setblock 540 295 363 minecraft:stripped_dark_oak_log
setblock 541 295 324 minecraft:shroomlight
setblock 541 295 326 minecraft:shroomlight
setblock 541 295 328 minecraft:shroomlight
setblock 541 295 330 minecraft:shroomlight
setblock 542 295 323 minecraft:shroomlight
setblock 542 295 325 minecraft:shroomlight
setblock 542 295 327 minecraft:shroomlight
setblock 542 295 329 minecraft:shroomlight
setblock 543 295 324 minecraft:shroomlight
setblock 543 295 326 minecraft:shroomlight
setblock 543 295 328 minecraft:shroomlight
setblock 543 295 330 minecraft:shroomlight
setblock 544 295 323 minecraft:shroomlight
setblock 544 295 325 minecraft:shroomlight
setblock 544 295 327 minecraft:shroomlight
setblock 544 295 329 minecraft:shroomlight
setblock 545 295 324 minecraft:shroomlight
setblock 545 295 326 minecraft:shroomlight
setblock 545 295 328 minecraft:shroomlight
setblock 545 295 330 minecraft:shroomlight
setblock 546 295 323 minecraft:shroomlight
setblock 546 295 325 minecraft:shroomlight
setblock 546 295 327 minecraft:shroomlight
setblock 546 295 329 minecraft:shroomlight
setblock 547 295 324 minecraft:shroomlight
setblock 547 295 326 minecraft:shroomlight
setblock 547 295 328 minecraft:shroomlight
setblock 547 295 330 minecraft:shroomlight
setblock 547 295 363 minecraft:stripped_dark_oak_log
setblock 548 295 323 minecraft:shroomlight
setblock 548 295 325 minecraft:shroomlight
setblock 548 295 327 minecraft:shroomlight
setblock 548 295 329 minecraft:shroomlight
setblock 549 295 324 minecraft:shroomlight
setblock 549 295 326 minecraft:shroomlight
setblock 549 295 328 minecraft:shroomlight
setblock 549 295 330 minecraft:shroomlight
setblock 550 295 323 minecraft:shroomlight
setblock 550 295 325 minecraft:shroomlight
setblock 550 295 327 minecraft:shroomlight
setblock 550 295 329 minecraft:shroomlight
setblock 551 295 324 minecraft:shroomlight
setblock 551 295 326 minecraft:shroomlight
setblock 551 295 328 minecraft:shroomlight
setblock 551 295 330 minecraft:shroomlight
setblock 554 295 323 minecraft:stripped_dark_oak_log
setblock 554 295 363 minecraft:stripped_dark_oak_log
setblock 558 295 326 minecraft:stripped_dark_oak_log
setblock 558 295 347 minecraft:stripped_dark_oak_log
setblock 558 295 354 minecraft:stripped_dark_oak_log
setblock 558 295 361 minecraft:stripped_dark_oak_log
fill 517 296 324 517 297 324 minecraft:white_terracotta
fill 517 296 326 517 297 326 minecraft:white_terracotta
fill 517 296 328 517 297 328 minecraft:white_terracotta
fill 518 296 323 518 297 323 minecraft:stripped_dark_oak_log
fill 518 296 325 518 297 325 minecraft:stripped_dark_oak_log
fill 518 296 327 518 297 327 minecraft:stripped_dark_oak_log
setblock 518 296 330 minecraft:stripped_dark_oak_log
setblock 518 296 337 minecraft:stripped_dark_oak_log
setblock 518 296 344 minecraft:stripped_dark_oak_log
setblock 518 296 351 minecraft:stripped_dark_oak_log
setblock 518 296 358 minecraft:stripped_dark_oak_log
fill 519 296 324 519 297 324 minecraft:stripped_dark_oak_log
fill 519 296 326 519 297 326 minecraft:stripped_dark_oak_log
fill 519 296 328 519 297 328 minecraft:stripped_dark_oak_log
fill 520 296 323 520 297 323 minecraft:stripped_dark_oak_log
fill 520 296 325 520 297 325 minecraft:stripped_dark_oak_log
fill 520 296 327 520 297 327 minecraft:stripped_dark_oak_log
setblock 520 296 363 minecraft:stripped_dark_oak_log
fill 521 296 324 521 297 324 minecraft:stripped_dark_oak_log
fill 521 296 326 521 297 326 minecraft:stripped_dark_oak_log
fill 521 296 328 521 297 328 minecraft:stripped_dark_oak_log
fill 522 296 323 522 297 323 minecraft:stripped_dark_oak_log
fill 522 296 325 522 297 325 minecraft:stripped_dark_oak_log
fill 522 296 327 522 297 327 minecraft:stripped_dark_oak_log
fill 523 296 324 523 297 324 minecraft:stripped_dark_oak_log
fill 523 296 326 523 297 326 minecraft:stripped_dark_oak_log
fill 523 296 328 523 297 328 minecraft:stripped_dark_oak_log
fill 524 296 323 524 297 323 minecraft:stripped_dark_oak_log
fill 524 296 325 524 297 325 minecraft:stripped_dark_oak_log
fill 524 296 327 524 297 327 minecraft:stripped_dark_oak_log
fill 525 296 324 525 297 324 minecraft:stripped_dark_oak_log
fill 525 296 326 525 297 326 minecraft:stripped_dark_oak_log
fill 525 296 328 525 297 328 minecraft:stripped_dark_oak_log
fill 526 296 323 526 297 323 minecraft:stripped_dark_oak_log
fill 526 296 325 526 297 325 minecraft:stripped_dark_oak_log
fill 526 296 327 526 297 327 minecraft:stripped_dark_oak_log
fill 527 296 324 527 297 324 minecraft:stripped_dark_oak_log
fill 527 296 326 527 297 326 minecraft:stripped_dark_oak_log
fill 527 296 328 527 297 328 minecraft:stripped_dark_oak_log
setblock 527 296 363 minecraft:stripped_dark_oak_log
setblock 532 296 323 minecraft:stripped_dark_oak_log
setblock 534 296 363 minecraft:stripped_dark_oak_log
fill 539 296 324 539 297 324 minecraft:stripped_dark_oak_log
fill 539 296 326 539 297 326 minecraft:stripped_dark_oak_log
fill 539 296 328 539 297 328 minecraft:stripped_dark_oak_log
fill 539 296 330 539 297 330 minecraft:stripped_dark_oak_log
fill 540 296 323 540 297 323 minecraft:stripped_dark_oak_log
fill 540 296 325 540 297 325 minecraft:stripped_dark_oak_log
fill 540 296 327 540 297 327 minecraft:stripped_dark_oak_log
fill 540 296 329 540 297 329 minecraft:stripped_dark_oak_log
fill 541 296 324 541 297 324 minecraft:stripped_dark_oak_log
fill 541 296 326 541 297 326 minecraft:stripped_dark_oak_log
fill 541 296 328 541 297 328 minecraft:stripped_dark_oak_log
fill 541 296 330 541 297 330 minecraft:stripped_dark_oak_log
setblock 541 296 363 minecraft:stripped_dark_oak_log
fill 542 296 323 542 297 323 minecraft:stripped_dark_oak_log
fill 542 296 325 542 297 325 minecraft:stripped_dark_oak_log
fill 542 296 327 542 297 327 minecraft:stripped_dark_oak_log
fill 542 296 329 542 297 329 minecraft:stripped_dark_oak_log
fill 543 296 324 543 297 324 minecraft:stripped_dark_oak_log
fill 543 296 326 543 297 326 minecraft:stripped_dark_oak_log
fill 543 296 328 543 297 328 minecraft:stripped_dark_oak_log
fill 543 296 330 543 297 330 minecraft:stripped_dark_oak_log
fill 544 296 323 544 298 323 minecraft:stripped_dark_oak_log
fill 544 296 325 544 297 325 minecraft:stripped_dark_oak_log
fill 544 296 327 544 297 327 minecraft:stripped_dark_oak_log
fill 544 296 329 544 297 329 minecraft:stripped_dark_oak_log
fill 545 296 324 545 297 324 minecraft:stripped_dark_oak_log
fill 545 296 326 545 297 326 minecraft:stripped_dark_oak_log
fill 545 296 328 545 297 328 minecraft:stripped_dark_oak_log
fill 545 296 330 545 297 330 minecraft:stripped_dark_oak_log
fill 546 296 323 546 297 323 minecraft:stripped_dark_oak_log
fill 546 296 325 546 297 325 minecraft:stripped_dark_oak_log
fill 546 296 327 546 297 327 minecraft:stripped_dark_oak_log
fill 546 296 329 546 297 329 minecraft:stripped_dark_oak_log
fill 547 296 324 547 297 324 minecraft:stripped_dark_oak_log
fill 547 296 326 547 297 326 minecraft:stripped_dark_oak_log
fill 547 296 328 547 297 328 minecraft:stripped_dark_oak_log
fill 547 296 330 547 297 330 minecraft:stripped_dark_oak_log
fill 548 296 323 548 300 323 minecraft:stripped_dark_oak_log
fill 548 296 325 548 297 325 minecraft:stripped_dark_oak_log
fill 548 296 327 548 297 327 minecraft:stripped_dark_oak_log
fill 548 296 329 548 297 329 minecraft:stripped_dark_oak_log
setblock 548 296 363 minecraft:stripped_dark_oak_log
fill 549 296 324 549 297 324 minecraft:stripped_dark_oak_log
fill 549 296 326 549 297 326 minecraft:stripped_dark_oak_log
fill 549 296 328 549 297 328 minecraft:stripped_dark_oak_log
fill 549 296 330 549 297 330 minecraft:stripped_dark_oak_log
fill 550 296 323 550 297 323 minecraft:stripped_dark_oak_log
fill 550 296 325 550 297 325 minecraft:stripped_dark_oak_log
fill 550 296 327 550 297 327 minecraft:stripped_dark_oak_log
fill 550 296 329 550 297 329 minecraft:stripped_dark_oak_log
fill 551 296 324 551 297 324 minecraft:stripped_dark_oak_log
fill 551 296 326 551 297 326 minecraft:stripped_dark_oak_log
fill 551 296 328 551 297 328 minecraft:stripped_dark_oak_log
fill 551 296 330 551 297 330 minecraft:stripped_dark_oak_log
setblock 553 296 323 minecraft:stripped_dark_oak_log
setblock 555 296 363 minecraft:stripped_dark_oak_log
setblock 558 296 325 minecraft:stripped_dark_oak_log
setblock 558 296 346 minecraft:stripped_dark_oak_log
setblock 558 296 353 minecraft:stripped_dark_oak_log
setblock 558 296 360 minecraft:stripped_dark_oak_log
setblock 518 297 331 minecraft:stripped_dark_oak_log
setblock 518 297 338 minecraft:stripped_dark_oak_log
setblock 518 297 345 minecraft:stripped_dark_oak_log
setblock 518 297 352 minecraft:stripped_dark_oak_log
setblock 518 297 359 minecraft:stripped_dark_oak_log
setblock 521 297 363 minecraft:stripped_dark_oak_log
setblock 528 297 363 minecraft:stripped_dark_oak_log
setblock 531 297 323 minecraft:stripped_dark_oak_log
setblock 535 297 363 minecraft:stripped_dark_oak_log
setblock 538 297 323 minecraft:stripped_dark_oak_log
setblock 542 297 363 minecraft:stripped_dark_oak_log
setblock 549 297 363 minecraft:stripped_dark_oak_log
setblock 552 297 323 minecraft:stripped_dark_oak_log
setblock 556 297 363 minecraft:stripped_dark_oak_log
setblock 558 297 324 minecraft:stripped_dark_oak_log
setblock 558 297 345 minecraft:stripped_dark_oak_log
setblock 558 297 352 minecraft:stripped_dark_oak_log
setblock 558 297 359 minecraft:stripped_dark_oak_log
setblock 517 298 324 minecraft:shroomlight
setblock 517 298 326 minecraft:shroomlight
setblock 517 298 328 minecraft:shroomlight
setblock 518 298 323 minecraft:shroomlight
setblock 518 298 325 minecraft:shroomlight
setblock 518 298 327 minecraft:shroomlight
setblock 518 298 332 minecraft:stripped_dark_oak_log
setblock 518 298 339 minecraft:stripped_dark_oak_log
setblock 518 298 346 minecraft:stripped_dark_oak_log
setblock 518 298 353 minecraft:stripped_dark_oak_log
setblock 518 298 360 minecraft:stripped_dark_oak_log
setblock 519 298 324 minecraft:shroomlight
setblock 519 298 326 minecraft:shroomlight
setblock 519 298 328 minecraft:shroomlight
setblock 520 298 323 minecraft:shroomlight
setblock 520 298 325 minecraft:shroomlight
setblock 520 298 327 minecraft:shroomlight
setblock 521 298 324 minecraft:shroomlight
setblock 521 298 326 minecraft:shroomlight
setblock 521 298 328 minecraft:shroomlight
setblock 522 298 323 minecraft:shroomlight
setblock 522 298 325 minecraft:shroomlight
setblock 522 298 327 minecraft:shroomlight
setblock 522 298 363 minecraft:stripped_dark_oak_log
setblock 523 298 324 minecraft:shroomlight
setblock 523 298 326 minecraft:shroomlight
setblock 523 298 328 minecraft:shroomlight
setblock 524 298 323 minecraft:shroomlight
setblock 524 298 325 minecraft:shroomlight
setblock 524 298 327 minecraft:shroomlight
setblock 525 298 324 minecraft:shroomlight
setblock 525 298 326 minecraft:shroomlight
setblock 525 298 328 minecraft:shroomlight
setblock 526 298 323 minecraft:shroomlight
setblock 526 298 325 minecraft:shroomlight
setblock 526 298 327 minecraft:shroomlight
setblock 527 298 324 minecraft:shroomlight
setblock 527 298 326 minecraft:shroomlight
setblock 527 298 328 minecraft:shroomlight
setblock 529 298 363 minecraft:stripped_dark_oak_log
setblock 530 298 323 minecraft:stripped_dark_oak_log
setblock 536 298 363 minecraft:stripped_dark_oak_log
setblock 537 298 323 minecraft:stripped_dark_oak_log
fill 540 298 324 550 298 329 minecraft:red_concrete
setblock 543 298 363 minecraft:stripped_dark_oak_log
setblock 550 298 363 minecraft:stripped_dark_oak_log
setblock 557 298 363 minecraft:stripped_dark_oak_log
setblock 558 298 323 minecraft:stripped_dark_oak_log
setblock 558 298 344 minecraft:stripped_dark_oak_log
setblock 558 298 351 minecraft:stripped_dark_oak_log
setblock 558 298 358 minecraft:stripped_dark_oak_log
fill 517 299 324 517 307 324 minecraft:white_terracotta
fill 517 299 326 517 307 326 minecraft:white_terracotta
fill 517 299 328 517 307 328 minecraft:white_terracotta
fill 518 299 323 518 300 323 minecraft:stripped_dark_oak_log
fill 518 299 325 518 300 325 minecraft:stripped_dark_oak_log
fill 518 299 327 518 300 327 minecraft:stripped_dark_oak_log
fill 518 299 333 518 300 333 minecraft:stripped_dark_oak_log
fill 518 299 340 518 300 340 minecraft:stripped_dark_oak_log
fill 518 299 347 518 300 347 minecraft:stripped_dark_oak_log
fill 518 299 354 518 300 354 minecraft:stripped_dark_oak_log
fill 518 299 361 518 300 361 minecraft:stripped_dark_oak_log
fill 519 299 324 519 300 324 minecraft:stripped_dark_oak_log
fill 519 299 326 519 300 326 minecraft:stripped_dark_oak_log
fill 519 299 328 519 300 328 minecraft:stripped_dark_oak_log
fill 520 299 323 520 300 323 minecraft:stripped_dark_oak_log
fill 520 299 325 520 300 325 minecraft:stripped_dark_oak_log
fill 520 299 327 520 300 327 minecraft:stripped_dark_oak_log
fill 521 299 324 521 300 324 minecraft:stripped_dark_oak_log
fill 521 299 326 521 300 326 minecraft:stripped_dark_oak_log
fill 521 299 328 521 300 328 minecraft:stripped_dark_oak_log
fill 522 299 323 522 300 323 minecraft:stripped_dark_oak_log
fill 522 299 325 522 300 325 minecraft:stripped_dark_oak_log
fill 522 299 327 522 300 327 minecraft:stripped_dark_oak_log
fill 523 299 324 523 300 324 minecraft:stripped_dark_oak_log
fill 523 299 326 523 300 326 minecraft:stripped_dark_oak_log
fill 523 299 328 523 300 328 minecraft:stripped_dark_oak_log
fill 523 299 363 523 300 363 minecraft:stripped_dark_oak_log
schedule function dropper:buildpart/83_5 1t
