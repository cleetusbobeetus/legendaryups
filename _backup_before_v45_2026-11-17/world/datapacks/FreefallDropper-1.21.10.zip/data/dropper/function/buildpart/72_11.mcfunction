setblock 5 287 324 minecraft:yellow_terracotta
setblock 6 287 323 minecraft:yellow_terracotta
fill 6 287 333 6 300 334 minecraft:yellow_terracotta
setblock 6 287 363 minecraft:yellow_terracotta
fill 7 287 323 7 289 323 minecraft:honeycomb_block
setblock 7 287 362 minecraft:yellow_terracotta
fill 7 287 363 10 287 363 minecraft:honeycomb_block
fill 8 287 362 8 288 362 minecraft:honeycomb_block
setblock 11 287 363 minecraft:yellow_terracotta
fill 12 287 363 15 287 363 minecraft:honeycomb_block
setblock 15 287 323 minecraft:honeycomb_block
setblock 16 287 323 minecraft:yellow_terracotta
setblock 16 287 363 minecraft:yellow_terracotta
fill 17 287 323 17 290 323 minecraft:honeycomb_block
setblock 17 287 362 minecraft:yellow_terracotta
fill 17 287 363 20 287 363 minecraft:honeycomb_block
fill 18 287 324 19 287 324 minecraft:honeycomb_block
fill 18 287 362 21 287 362 minecraft:honeycomb_block
setblock 20 287 324 minecraft:yellow_terracotta
fill 21 287 322 21 308 322 minecraft:honeycomb_block
setblock 21 287 323 minecraft:yellow_terracotta
fill 21 287 324 24 287 324 minecraft:honeycomb_block
setblock 21 287 363 minecraft:yellow_terracotta
fill 22 287 323 25 287 323 minecraft:honeycomb_block
fill 22 287 325 23 287 325 minecraft:honeycomb_block
setblock 22 287 362 minecraft:yellow_terracotta
fill 22 287 363 25 287 363 minecraft:honeycomb_block
fill 23 287 357 23 290 357 minecraft:yellow_terracotta
fill 23 287 362 23 288 362 minecraft:honeycomb_block
fill 23 287 364 23 308 364 minecraft:honeycomb_block
setblock 24 287 325 minecraft:yellow_terracotta
fill 25 287 322 25 308 322 minecraft:honeycomb_block
setblock 25 287 324 minecraft:yellow_terracotta
setblock 25 287 325 minecraft:honeycomb_block
setblock 26 287 323 minecraft:yellow_terracotta
fill 26 287 324 26 290 324 minecraft:honeycomb_block
setblock 26 287 363 minecraft:yellow_terracotta
fill 27 287 323 30 287 323 minecraft:honeycomb_block
fill 27 287 363 27 289 364 minecraft:honeycomb_block
fill 28 287 363 30 287 363 minecraft:honeycomb_block
setblock 30 287 324 minecraft:yellow_terracotta
setblock 31 287 323 minecraft:yellow_terracotta
fill 31 287 324 34 287 324 minecraft:honeycomb_block
setblock 31 287 363 minecraft:yellow_terracotta
fill 32 287 323 35 287 323 minecraft:honeycomb_block
fill 32 287 363 35 287 363 minecraft:honeycomb_block
fill 33 287 345 33 287 349 minecraft:brown_terracotta
fill 34 287 344 35 287 344 minecraft:brown_terracotta
setblock 34 287 350 minecraft:brown_terracotta
fill 34 287 362 36 287 362 minecraft:honeycomb_block
setblock 35 287 324 minecraft:yellow_terracotta
fill 35 287 351 38 287 351 minecraft:brown_terracotta
setblock 36 287 323 minecraft:yellow_terracotta
fill 36 287 324 36 290 324 minecraft:honeycomb_block
fill 36 287 343 37 287 343 minecraft:brown_terracotta
setblock 36 287 363 minecraft:yellow_terracotta
fill 37 287 323 37 290 323 minecraft:honeycomb_block
fill 37 287 325 38 287 325 minecraft:honeycomb_block
fill 37 287 342 37 292 342 minecraft:brown_terracotta
setblock 37 287 361 minecraft:honeycomb_block
setblock 37 287 362 minecraft:yellow_terracotta
fill 37 287 363 37 290 363 minecraft:honeycomb_block
fill 38 287 344 39 287 344 minecraft:brown_terracotta
setblock 38 287 361 minecraft:yellow_terracotta
fill 38 287 362 38 290 362 minecraft:honeycomb_block
setblock 39 287 324 minecraft:honeycomb_block
setblock 39 287 325 minecraft:yellow_terracotta
fill 39 287 326 41 288 326 minecraft:honeycomb_block
setblock 39 287 350 minecraft:brown_terracotta
setblock 39 287 359 minecraft:honeycomb_block
setblock 39 287 360 minecraft:yellow_terracotta
fill 39 287 361 39 290 361 minecraft:honeycomb_block
fill 40 287 322 40 287 323 minecraft:honeycomb_block
setblock 40 287 324 minecraft:yellow_terracotta
fill 40 287 325 41 289 325 minecraft:honeycomb_block
fill 40 287 327 40 287 328 minecraft:honeycomb_block
setblock 40 287 329 minecraft:yellow_terracotta
setblock 40 287 330 minecraft:honeycomb_block
fill 40 287 336 40 287 338 minecraft:honeycomb_block
setblock 40 287 339 minecraft:yellow_terracotta
fill 40 287 340 40 289 340 minecraft:honeycomb_block
setblock 40 287 344 minecraft:yellow_terracotta
fill 40 287 345 40 289 346 minecraft:honeycomb_block
fill 40 287 347 40 287 349 minecraft:brown_terracotta
setblock 40 287 359 minecraft:yellow_terracotta
fill 40 287 360 40 290 360 minecraft:honeycomb_block
setblock 40 287 364 minecraft:yellow_terracotta
setblock 41 287 323 minecraft:yellow_terracotta
fill 41 287 324 41 290 324 minecraft:honeycomb_block
setblock 41 287 327 minecraft:honeycomb_block
setblock 41 287 328 minecraft:yellow_terracotta
fill 41 287 329 41 290 329 minecraft:honeycomb_block
fill 41 287 331 41 287 332 minecraft:honeycomb_block
setblock 41 287 333 minecraft:yellow_terracotta
fill 41 287 334 41 287 337 minecraft:honeycomb_block
setblock 41 287 338 minecraft:yellow_terracotta
fill 41 287 339 41 290 339 minecraft:honeycomb_block
setblock 41 287 343 minecraft:yellow_terracotta
fill 41 287 344 41 290 344 minecraft:honeycomb_block
setblock 41 287 347 minecraft:honeycomb_block
setblock 41 287 348 minecraft:yellow_terracotta
fill 41 287 349 41 287 352 minecraft:honeycomb_block
setblock 41 287 353 minecraft:yellow_terracotta
fill 41 287 354 41 290 354 minecraft:honeycomb_block
setblock 41 287 358 minecraft:yellow_terracotta
fill 41 287 359 41 290 359 minecraft:honeycomb_block
setblock 41 287 363 minecraft:yellow_terracotta
setblock 0 288 327 minecraft:orange_terracotta
setblock 0 288 329 minecraft:yellow_concrete
fill 0 288 356 1 288 356 minecraft:honeycomb_block
fill 1 288 323 1 288 326 minecraft:honeycomb_block
setblock 1 288 327 minecraft:yellow_terracotta
fill 1 288 328 1 289 329 minecraft:honeycomb_block
fill 1 288 335 1 288 336 minecraft:honeycomb_block
setblock 1 288 337 minecraft:yellow_terracotta
fill 1 288 338 1 288 341 minecraft:honeycomb_block
setblock 1 288 342 minecraft:yellow_terracotta
fill 1 288 343 1 288 346 minecraft:honeycomb_block
setblock 1 288 347 minecraft:yellow_terracotta
fill 1 288 348 1 288 351 minecraft:honeycomb_block
setblock 1 288 352 minecraft:yellow_terracotta
fill 1 288 353 1 291 353 minecraft:honeycomb_block
setblock 1 288 357 minecraft:yellow_terracotta
fill 1 288 358 1 288 361 minecraft:honeycomb_block
setblock 1 288 362 minecraft:yellow_terracotta
fill 1 288 363 4 288 363 minecraft:honeycomb_block
fill 2 288 323 4 288 323 minecraft:honeycomb_block
setblock 2 288 326 minecraft:yellow_terracotta
fill 2 288 332 3 289 332 minecraft:brown_terracotta
fill 2 288 334 2 289 335 minecraft:brown_terracotta
fill 2 288 338 2 288 340 minecraft:honeycomb_block
setblock 2 288 341 minecraft:yellow_terracotta
fill 2 288 342 2 288 345 minecraft:honeycomb_block
setblock 2 288 346 minecraft:yellow_terracotta
fill 2 288 347 2 288 350 minecraft:honeycomb_block
setblock 2 288 351 minecraft:yellow_terracotta
fill 2 288 352 2 291 352 minecraft:honeycomb_block
setblock 2 288 356 minecraft:yellow_terracotta
fill 2 288 357 2 288 360 minecraft:honeycomb_block
setblock 2 288 361 minecraft:yellow_terracotta
fill 2 288 362 5 288 362 minecraft:honeycomb_block
setblock 3 288 325 minecraft:light[level=15]
fill 3 288 336 6 289 336 minecraft:brown_terracotta
setblock 3 288 341 minecraft:honeycomb_block
setblock 3 288 344 minecraft:honeycomb_block
setblock 3 288 345 minecraft:yellow_terracotta
fill 3 288 346 3 291 346 minecraft:honeycomb_block
setblock 3 288 349 minecraft:light[level=15]
fill 3 288 354 4 300 355 minecraft:yellow_terracotta
setblock 3 288 360 minecraft:yellow_terracotta
fill 3 288 361 3 289 361 minecraft:honeycomb_block
setblock 4 288 324 minecraft:yellow_terracotta
fill 4 288 331 4 289 331 minecraft:brown_terracotta
fill 4 288 356 4 300 356 minecraft:yellow_terracotta
setblock 5 288 323 minecraft:yellow_terracotta
setblock 5 288 324 minecraft:honeycomb_block
setblock 5 288 363 minecraft:yellow_terracotta
fill 6 288 323 6 290 323 minecraft:honeycomb_block
fill 6 288 332 6 289 332 minecraft:brown_terracotta
fill 6 288 335 6 289 335 minecraft:brown_terracotta
setblock 6 288 362 minecraft:yellow_terracotta
fill 6 288 363 9 288 363 minecraft:honeycomb_block
fill 7 288 334 7 289 334 minecraft:brown_terracotta
setblock 7 288 362 minecraft:honeycomb_block
setblock 10 288 363 minecraft:yellow_terracotta
setblock 11 288 325 minecraft:light[level=15]
setblock 11 288 333 minecraft:light[level=15]
setblock 11 288 341 minecraft:light[level=15]
setblock 11 288 349 minecraft:light[level=15]
setblock 11 288 357 minecraft:light[level=15]
fill 11 288 363 14 288 363 minecraft:honeycomb_block
setblock 15 288 323 minecraft:yellow_terracotta
setblock 15 288 363 minecraft:yellow_terracotta
fill 16 288 323 16 291 323 minecraft:honeycomb_block
fill 16 288 363 19 288 363 minecraft:honeycomb_block
setblock 18 288 324 minecraft:honeycomb_block
fill 18 288 362 20 288 362 minecraft:honeycomb_block
setblock 19 288 324 minecraft:yellow_terracotta
setblock 19 288 325 minecraft:light[level=15]
setblock 19 288 333 minecraft:light[level=15]
setblock 19 288 341 minecraft:light[level=15]
setblock 19 288 349 minecraft:light[level=15]
setblock 19 288 357 minecraft:light[level=15]
setblock 20 288 323 minecraft:yellow_terracotta
fill 20 288 324 23 288 324 minecraft:honeycomb_block
setblock 20 288 363 minecraft:yellow_terracotta
fill 21 288 323 24 288 323 minecraft:honeycomb_block
fill 21 288 325 22 288 325 minecraft:honeycomb_block
setblock 21 288 362 minecraft:yellow_terracotta
fill 21 288 363 24 288 363 minecraft:honeycomb_block
fill 22 288 362 22 289 362 minecraft:honeycomb_block
setblock 23 288 325 minecraft:yellow_terracotta
setblock 24 288 324 minecraft:yellow_terracotta
fill 24 288 325 24 289 325 minecraft:honeycomb_block
setblock 25 288 323 minecraft:yellow_terracotta
fill 25 288 324 25 291 324 minecraft:honeycomb_block
setblock 25 288 363 minecraft:yellow_terracotta
fill 26 288 323 29 288 323 minecraft:honeycomb_block
fill 26 288 363 26 290 363 minecraft:honeycomb_block
setblock 27 288 325 minecraft:light[level=15]
setblock 27 288 333 minecraft:light[level=15]
setblock 27 288 341 minecraft:light[level=15]
setblock 27 288 349 minecraft:light[level=15]
setblock 27 288 357 minecraft:light[level=15]
fill 28 288 363 29 288 363 minecraft:honeycomb_block
setblock 29 288 324 minecraft:yellow_terracotta
setblock 30 288 323 minecraft:yellow_terracotta
fill 30 288 324 33 288 324 minecraft:honeycomb_block
setblock 30 288 363 minecraft:yellow_terracotta
fill 31 288 323 34 288 323 minecraft:honeycomb_block
fill 31 288 363 34 288 363 minecraft:honeycomb_block
fill 33 288 338 33 295 338 minecraft:brown_terracotta
setblock 34 288 324 minecraft:yellow_terracotta
fill 34 288 356 36 300 357 minecraft:yellow_terracotta
setblock 35 288 323 minecraft:yellow_terracotta
fill 35 288 324 35 291 324 minecraft:honeycomb_block
setblock 35 288 325 minecraft:light[level=15]
setblock 35 288 333 minecraft:light[level=15]
setblock 35 288 341 minecraft:light[level=15]
fill 35 288 358 36 300 358 minecraft:yellow_terracotta
setblock 35 288 362 minecraft:honeycomb_block
setblock 35 288 363 minecraft:yellow_terracotta
fill 36 288 323 36 291 323 minecraft:honeycomb_block
fill 36 288 325 37 288 325 minecraft:honeycomb_block
setblock 36 288 362 minecraft:yellow_terracotta
fill 36 288 363 36 291 363 minecraft:honeycomb_block
fill 37 288 362 37 291 362 minecraft:honeycomb_block
setblock 38 288 325 minecraft:yellow_terracotta
fill 38 288 361 38 289 361 minecraft:honeycomb_block
setblock 39 288 324 minecraft:yellow_terracotta
fill 39 288 325 39 291 325 minecraft:honeycomb_block
fill 39 288 327 40 288 327 minecraft:honeycomb_block
fill 39 288 360 39 289 360 minecraft:honeycomb_block
fill 40 288 322 40 308 322 minecraft:honeycomb_block
setblock 40 288 323 minecraft:yellow_terracotta
fill 40 288 324 40 291 324 minecraft:honeycomb_block
setblock 40 288 328 minecraft:yellow_terracotta
fill 40 288 329 40 291 329 minecraft:honeycomb_block
setblock 40 288 338 minecraft:yellow_terracotta
setblock 40 288 339 minecraft:honeycomb_block
setblock 40 288 343 minecraft:yellow_terracotta
fill 40 288 344 40 291 344 minecraft:honeycomb_block
setblock 40 288 347 minecraft:honeycomb_block
setblock 40 288 358 minecraft:yellow_terracotta
fill 40 288 359 40 291 359 minecraft:honeycomb_block
setblock 40 288 363 minecraft:yellow_terracotta
fill 40 288 364 40 308 364 minecraft:honeycomb_block
fill 41 288 323 41 291 323 minecraft:honeycomb_block
setblock 41 288 327 minecraft:yellow_terracotta
fill 41 288 328 41 291 328 minecraft:honeycomb_block
setblock 41 288 331 minecraft:honeycomb_block
setblock 41 288 332 minecraft:yellow_terracotta
fill 41 288 333 41 288 336 minecraft:honeycomb_block
setblock 41 288 337 minecraft:yellow_terracotta
fill 41 288 338 41 290 338 minecraft:honeycomb_block
setblock 41 288 342 minecraft:yellow_terracotta
fill 41 288 343 41 291 343 minecraft:honeycomb_block
setblock 41 288 347 minecraft:yellow_terracotta
fill 41 288 348 41 288 351 minecraft:honeycomb_block
setblock 41 288 352 minecraft:yellow_terracotta
fill 41 288 353 41 291 353 minecraft:honeycomb_block
setblock 41 288 357 minecraft:yellow_terracotta
fill 41 288 358 41 291 358 minecraft:honeycomb_block
setblock 41 288 362 minecraft:yellow_terracotta
fill 41 288 363 41 291 363 minecraft:honeycomb_block
setblock 42 288 350 minecraft:yellow_concrete
fill 0 289 327 1 292 327 minecraft:honeycomb_block
fill 0 289 329 0 303 329 minecraft:honeycomb_block
fill 0 289 356 0 308 356 minecraft:honeycomb_block
fill 1 289 323 1 289 325 minecraft:honeycomb_block
setblock 1 289 326 minecraft:yellow_terracotta
fill 1 289 332 1 289 335 minecraft:brown_terracotta
fill 1 289 337 1 289 340 minecraft:honeycomb_block
setblock 1 289 341 minecraft:yellow_terracotta
fill 1 289 342 1 289 345 minecraft:honeycomb_block
setblock 1 289 346 minecraft:yellow_terracotta
fill 1 289 347 1 289 350 minecraft:honeycomb_block
setblock 1 289 351 minecraft:yellow_terracotta
fill 1 289 352 1 292 352 minecraft:honeycomb_block
fill 1 289 354 1 289 355 minecraft:honeycomb_block
setblock 1 289 356 minecraft:yellow_terracotta
fill 1 289 357 1 289 360 minecraft:honeycomb_block
setblock 1 289 361 minecraft:yellow_terracotta
fill 1 289 362 3 289 363 minecraft:honeycomb_block
fill 2 289 323 3 289 323 minecraft:honeycomb_block
setblock 2 289 325 minecraft:yellow_terracotta
setblock 2 289 326 minecraft:honeycomb_block
fill 2 289 331 3 289 331 minecraft:brown_terracotta
setblock 2 289 336 minecraft:brown_terracotta
setblock 2 289 339 minecraft:honeycomb_block
setblock 2 289 340 minecraft:yellow_terracotta
fill 2 289 341 2 289 344 minecraft:honeycomb_block
setblock 2 289 345 minecraft:yellow_terracotta
fill 2 289 346 2 289 349 minecraft:honeycomb_block
setblock 2 289 350 minecraft:yellow_terracotta
fill 2 289 351 2 292 351 minecraft:honeycomb_block
setblock 2 289 354 minecraft:honeycomb_block
setblock 2 289 355 minecraft:yellow_terracotta
fill 2 289 356 2 289 359 minecraft:honeycomb_block
setblock 2 289 360 minecraft:yellow_terracotta
fill 2 289 361 2 292 361 minecraft:honeycomb_block
setblock 3 289 324 minecraft:yellow_terracotta
fill 3 289 337 6 289 337 minecraft:brown_terracotta
setblock 3 289 344 minecraft:yellow_terracotta
fill 3 289 345 3 291 345 minecraft:honeycomb_block
fill 3 289 349 3 291 349 minecraft:brown_terracotta
fill 3 289 357 3 290 357 minecraft:brown_terracotta
setblock 3 289 359 minecraft:yellow_terracotta
setblock 3 289 360 minecraft:honeycomb_block
setblock 4 289 323 minecraft:yellow_terracotta
setblock 4 289 324 minecraft:honeycomb_block
setblock 4 289 362 minecraft:honeycomb_block
setblock 4 289 363 minecraft:yellow_terracotta
fill 5 289 323 5 291 323 minecraft:honeycomb_block
fill 5 289 331 6 289 331 minecraft:brown_terracotta
fill 5 289 355 5 290 355 minecraft:brown_terracotta
setblock 5 289 362 minecraft:yellow_terracotta
fill 5 289 363 8 289 363 minecraft:honeycomb_block
setblock 6 289 362 minecraft:honeycomb_block
setblock 6 289 364 minecraft:orange_terracotta
fill 7 289 332 7 289 333 minecraft:brown_terracotta
fill 7 289 335 7 289 336 minecraft:brown_terracotta
setblock 9 289 363 minecraft:yellow_terracotta
setblock 10 289 363 minecraft:honeycomb_block
setblock 14 289 363 minecraft:yellow_terracotta
fill 15 289 323 15 292 323 minecraft:honeycomb_block
fill 15 289 363 18 289 363 minecraft:honeycomb_block
setblock 17 289 324 minecraft:honeycomb_block
setblock 18 289 324 minecraft:yellow_terracotta
setblock 19 289 323 minecraft:yellow_terracotta
fill 19 289 324 22 289 324 minecraft:honeycomb_block
setblock 19 289 362 minecraft:honeycomb_block
setblock 19 289 363 minecraft:yellow_terracotta
fill 20 289 323 23 289 323 minecraft:honeycomb_block
setblock 20 289 362 minecraft:yellow_terracotta
fill 20 289 363 23 289 363 minecraft:honeycomb_block
setblock 21 289 325 minecraft:honeycomb_block
setblock 21 289 362 minecraft:honeycomb_block
setblock 22 289 325 minecraft:yellow_terracotta
setblock 23 289 324 minecraft:yellow_terracotta
fill 23 289 325 23 291 325 minecraft:honeycomb_block
setblock 24 289 323 minecraft:yellow_terracotta
fill 24 289 324 24 292 324 minecraft:honeycomb_block
setblock 24 289 363 minecraft:yellow_terracotta
fill 25 289 323 28 289 323 minecraft:honeycomb_block
fill 25 289 363 25 290 363 minecraft:honeycomb_block
setblock 28 289 324 minecraft:yellow_terracotta
setblock 28 289 363 minecraft:honeycomb_block
setblock 29 289 323 minecraft:yellow_terracotta
fill 29 289 324 32 289 324 minecraft:honeycomb_block
setblock 29 289 363 minecraft:yellow_terracotta
fill 30 289 323 33 289 323 minecraft:honeycomb_block
fill 30 289 363 33 289 363 minecraft:honeycomb_block
fill 32 289 338 32 295 338 minecraft:brown_terracotta
setblock 33 289 324 minecraft:yellow_terracotta
fill 33 289 339 33 295 339 minecraft:brown_terracotta
setblock 34 289 323 minecraft:yellow_terracotta
fill 34 289 324 34 292 324 minecraft:honeycomb_block
fill 34 289 358 34 290 358 minecraft:brown_terracotta
setblock 34 289 363 minecraft:yellow_terracotta
fill 35 289 323 35 292 323 minecraft:honeycomb_block
fill 35 289 355 35 290 355 minecraft:brown_terracotta
setblock 35 289 362 minecraft:yellow_terracotta
fill 35 289 363 35 292 363 minecraft:honeycomb_block
setblock 36 289 325 minecraft:honeycomb_block
fill 36 289 362 36 292 362 minecraft:honeycomb_block
setblock 37 289 325 minecraft:yellow_terracotta
fill 37 289 357 37 290 357 minecraft:brown_terracotta
setblock 38 289 324 minecraft:yellow_terracotta
fill 38 289 325 38 292 325 minecraft:honeycomb_block
setblock 39 289 323 minecraft:yellow_terracotta
fill 39 289 324 39 292 324 minecraft:honeycomb_block
fill 39 289 326 39 289 327 minecraft:honeycomb_block
setblock 39 289 363 minecraft:yellow_terracotta
fill 40 289 323 40 292 323 minecraft:honeycomb_block
setblock 40 289 326 minecraft:honeycomb_block
setblock 40 289 327 minecraft:yellow_terracotta
fill 40 289 328 40 292 328 minecraft:honeycomb_block
setblock 40 289 342 minecraft:yellow_terracotta
fill 40 289 343 40 291 343 minecraft:honeycomb_block
setblock 40 289 347 minecraft:yellow_terracotta
setblock 40 289 357 minecraft:yellow_terracotta
fill 40 289 358 40 290 358 minecraft:honeycomb_block
setblock 40 289 362 minecraft:yellow_terracotta
fill 40 289 363 40 292 363 minecraft:honeycomb_block
setblock 41 289 326 minecraft:yellow_terracotta
fill 41 289 327 41 292 327 minecraft:honeycomb_block
setblock 41 289 331 minecraft:yellow_terracotta
fill 41 289 332 41 289 335 minecraft:honeycomb_block
setblock 41 289 336 minecraft:yellow_terracotta
setblock 41 289 337 minecraft:honeycomb_block
setblock 41 289 341 minecraft:yellow_terracotta
fill 41 289 342 41 292 342 minecraft:honeycomb_block
setblock 41 289 346 minecraft:yellow_terracotta
fill 41 289 347 41 289 350 minecraft:honeycomb_block
setblock 41 289 351 minecraft:yellow_terracotta
fill 41 289 352 41 292 352 minecraft:honeycomb_block
setblock 41 289 356 minecraft:yellow_terracotta
fill 41 289 357 41 292 357 minecraft:honeycomb_block
setblock 41 289 361 minecraft:yellow_terracotta
fill 41 289 362 41 292 362 minecraft:honeycomb_block
fill 42 289 350 42 308 350 minecraft:honeycomb_block
setblock 0 290 354 minecraft:yellow_concrete
fill 1 290 323 1 290 324 minecraft:honeycomb_block
setblock 1 290 325 minecraft:yellow_terracotta
fill 1 290 326 1 293 326 minecraft:honeycomb_block
fill 1 290 328 1 291 328 minecraft:honeycomb_block
fill 1 290 333 1 291 333 minecraft:brown_terracotta
fill 1 290 338 1 290 339 minecraft:honeycomb_block
setblock 1 290 340 minecraft:yellow_terracotta
fill 1 290 341 1 290 344 minecraft:honeycomb_block
setblock 1 290 345 minecraft:yellow_terracotta
fill 1 290 346 1 290 349 minecraft:honeycomb_block
setblock 1 290 350 minecraft:yellow_terracotta
fill 1 290 351 1 293 351 minecraft:honeycomb_block
setblock 1 290 354 minecraft:honeycomb_block
setblock 1 290 355 minecraft:yellow_terracotta
fill 1 290 356 1 290 359 minecraft:honeycomb_block
setblock 1 290 360 minecraft:yellow_terracotta
fill 1 290 361 1 291 363 minecraft:honeycomb_block
setblock 2 290 323 minecraft:honeycomb_block
setblock 2 290 324 minecraft:yellow_terracotta
fill 2 290 325 2 291 325 minecraft:honeycomb_block
fill 2 290 332 2 291 332 minecraft:brown_terracotta
fill 2 290 334 2 291 334 minecraft:brown_terracotta
fill 2 290 340 2 290 343 minecraft:honeycomb_block
setblock 2 290 344 minecraft:yellow_terracotta
fill 2 290 345 2 290 348 minecraft:honeycomb_block
setblock 2 290 349 minecraft:yellow_terracotta
fill 2 290 350 2 293 350 minecraft:honeycomb_block
setblock 2 290 354 minecraft:yellow_terracotta
fill 2 290 355 2 290 358 minecraft:honeycomb_block
setblock 2 290 359 minecraft:yellow_terracotta
fill 2 290 360 2 291 360 minecraft:honeycomb_block
fill 2 290 362 2 290 363 minecraft:honeycomb_block
setblock 3 290 323 minecraft:yellow_terracotta
setblock 3 290 324 minecraft:honeycomb_block
setblock 3 290 325 minecraft:light[level=12]
setblock 3 290 332 minecraft:light[level=12]
fill 3 290 336 5 296 336 minecraft:yellow_terracotta
setblock 3 290 339 minecraft:light[level=12]
setblock 3 290 344 minecraft:honeycomb_block
setblock 3 290 348 minecraft:yellow_terracotta
fill 3 290 353 4 290 353 minecraft:brown_terracotta
setblock 3 290 360 minecraft:light[level=12]
setblock 3 290 362 minecraft:honeycomb_block
setblock 3 290 363 minecraft:yellow_terracotta
fill 4 290 323 4 292 323 minecraft:honeycomb_block
setblock 4 290 357 minecraft:brown_terracotta
setblock 4 290 362 minecraft:yellow_terracotta
fill 4 290 363 7 290 363 minecraft:honeycomb_block
setblock 5 290 354 minecraft:brown_terracotta
setblock 5 290 356 minecraft:brown_terracotta
setblock 5 290 362 minecraft:honeycomb_block
fill 6 290 364 6 308 364 minecraft:honeycomb_block
setblock 8 290 363 minecraft:yellow_terracotta
setblock 10 290 325 minecraft:light[level=12]
setblock 10 290 332 minecraft:light[level=12]
setblock 10 290 339 minecraft:light[level=12]
setblock 10 290 346 minecraft:light[level=12]
setblock 10 290 353 minecraft:light[level=12]
setblock 10 290 360 minecraft:light[level=12]
setblock 10 290 363 minecraft:honey_block
setblock 13 290 323 minecraft:honey_block
setblock 14 290 322 minecraft:yellow_concrete
fill 14 290 323 14 293 323 minecraft:honeycomb_block
fill 15 290 363 17 290 363 minecraft:honeycomb_block
setblock 17 290 324 minecraft:yellow_terracotta
setblock 17 290 325 minecraft:light[level=12]
setblock 17 290 332 minecraft:light[level=12]
setblock 17 290 339 minecraft:light[level=12]
setblock 17 290 346 minecraft:light[level=12]
setblock 17 290 353 minecraft:light[level=12]
setblock 17 290 360 minecraft:light[level=12]
setblock 18 290 323 minecraft:yellow_terracotta
fill 18 290 324 21 290 324 minecraft:honeycomb_block
setblock 18 290 363 minecraft:yellow_terracotta
fill 19 290 323 22 290 323 minecraft:honeycomb_block
fill 19 290 363 22 290 363 minecraft:honeycomb_block
setblock 20 290 325 minecraft:honeycomb_block
setblock 21 290 325 minecraft:yellow_terracotta
setblock 22 290 324 minecraft:yellow_terracotta
fill 22 290 325 22 293 325 minecraft:honeycomb_block
fill 22 290 356 22 292 358 minecraft:flowering_azalea_leaves[persistent=true]
setblock 23 290 323 minecraft:yellow_terracotta
fill 23 290 324 23 293 324 minecraft:honeycomb_block
fill 23 290 355 23 292 356 minecraft:flowering_azalea_leaves[persistent=true]
fill 23 290 358 24 292 358 minecraft:flowering_azalea_leaves[persistent=true]
setblock 23 290 363 minecraft:yellow_terracotta
fill 24 290 323 27 290 323 minecraft:honeycomb_block
setblock 24 290 325 minecraft:light[level=12]
setblock 24 290 332 minecraft:light[level=12]
setblock 24 290 339 minecraft:light[level=12]
setblock 24 290 346 minecraft:light[level=12]
setblock 24 290 353 minecraft:light[level=12]
fill 24 290 356 24 292 357 minecraft:flowering_azalea_leaves[persistent=true]
setblock 24 290 360 minecraft:light[level=12]
fill 24 290 363 24 291 363 minecraft:honeycomb_block
fill 25 290 357 25 292 357 minecraft:flowering_azalea_leaves[persistent=true]
setblock 27 290 324 minecraft:yellow_terracotta
fill 27 290 364 27 308 364 minecraft:honeycomb_block
setblock 28 290 323 minecraft:yellow_terracotta
fill 28 290 324 31 290 324 minecraft:honeycomb_block
fill 29 290 323 32 290 323 minecraft:honeycomb_block
setblock 29 290 363 minecraft:honey_block
setblock 31 290 325 minecraft:light[level=12]
setblock 31 290 332 minecraft:light[level=12]
setblock 31 290 339 minecraft:light[level=12]
setblock 31 290 346 minecraft:light[level=12]
setblock 31 290 353 minecraft:light[level=12]
setblock 31 290 360 minecraft:light[level=12]
setblock 32 290 324 minecraft:yellow_terracotta
fill 32 290 339 32 295 339 minecraft:brown_terracotta
setblock 32 290 363 minecraft:honeycomb_block
setblock 33 290 323 minecraft:yellow_terracotta
fill 33 290 324 33 293 324 minecraft:honeycomb_block
fill 33 290 356 33 290 358 minecraft:brown_terracotta
setblock 33 290 363 minecraft:yellow_terracotta
fill 34 290 323 34 293 323 minecraft:honeycomb_block
fill 34 290 338 34 295 338 minecraft:brown_terracotta
setblock 34 290 355 minecraft:brown_terracotta
fill 34 290 359 36 290 359 minecraft:brown_terracotta
fill 34 290 363 34 293 363 minecraft:honeycomb_block
setblock 35 290 325 minecraft:honeycomb_block
setblock 35 290 362 minecraft:honeycomb_block
setblock 36 290 325 minecraft:yellow_terracotta
setblock 36 290 355 minecraft:brown_terracotta
setblock 37 290 324 minecraft:yellow_terracotta
fill 37 290 325 37 293 325 minecraft:honeycomb_block
setblock 37 290 356 minecraft:brown_terracotta
setblock 37 290 358 minecraft:brown_terracotta
setblock 38 290 323 minecraft:yellow_terracotta
fill 38 290 324 38 293 324 minecraft:honeycomb_block
setblock 38 290 332 minecraft:light[level=12]
setblock 38 290 339 minecraft:light[level=12]
setblock 38 290 353 minecraft:light[level=12]
setblock 38 290 360 minecraft:light[level=12]
setblock 38 290 363 minecraft:yellow_terracotta
fill 39 290 323 39 293 323 minecraft:honeycomb_block
setblock 39 290 326 minecraft:honeycomb_block
setblock 39 290 327 minecraft:yellow_terracotta
setblock 39 290 362 minecraft:yellow_terracotta
fill 39 290 363 39 293 363 minecraft:honeycomb_block
setblock 40 290 325 minecraft:honeycomb_block
setblock 40 290 326 minecraft:yellow_terracotta
fill 40 290 327 40 293 327 minecraft:honeycomb_block
setblock 40 290 342 minecraft:honeycomb_block
setblock 40 290 345 minecraft:honeycomb_block
setblock 40 290 346 minecraft:yellow_terracotta
fill 40 290 347 41 291 348 minecraft:honeycomb_block
setblock 40 290 361 minecraft:yellow_terracotta
fill 40 290 362 40 293 362 minecraft:honeycomb_block
setblock 41 290 325 minecraft:yellow_terracotta
fill 41 290 326 41 293 326 minecraft:honeycomb_block
setblock 41 290 330 minecraft:yellow_terracotta
fill 41 290 331 41 293 331 minecraft:honeycomb_block
setblock 41 290 340 minecraft:yellow_terracotta
fill 41 290 341 41 292 341 minecraft:honeycomb_block
setblock 41 290 345 minecraft:yellow_terracotta
fill 41 290 346 41 293 346 minecraft:honeycomb_block
setblock 41 290 349 minecraft:honeycomb_block
setblock 41 290 350 minecraft:yellow_terracotta
fill 41 290 351 41 293 351 minecraft:honeycomb_block
setblock 41 290 355 minecraft:yellow_terracotta
fill 41 290 356 41 293 356 minecraft:honeycomb_block
setblock 41 290 360 minecraft:yellow_terracotta
fill 41 290 361 41 293 361 minecraft:honeycomb_block
setblock 0 291 340 minecraft:yellow_concrete
fill 0 291 354 0 308 354 minecraft:honeycomb_block
setblock 1 291 323 minecraft:honeycomb_block
setblock 1 291 324 minecraft:yellow_terracotta
fill 1 291 325 1 294 325 minecraft:honeycomb_block
setblock 1 291 334 minecraft:honey_block
setblock 1 291 339 minecraft:yellow_terracotta
fill 1 291 340 1 291 343 minecraft:honeycomb_block
setblock 1 291 344 minecraft:yellow_terracotta
fill 1 291 345 1 291 348 minecraft:honeycomb_block
setblock 1 291 349 minecraft:yellow_terracotta
fill 1 291 350 1 294 350 minecraft:honeycomb_block
setblock 1 291 354 minecraft:yellow_terracotta
fill 1 291 355 1 291 358 minecraft:honeycomb_block
setblock 1 291 359 minecraft:yellow_terracotta
fill 1 291 360 1 294 360 minecraft:honeycomb_block
setblock 2 291 323 minecraft:yellow_terracotta
setblock 2 291 324 minecraft:honeycomb_block
fill 2 291 341 2 291 342 minecraft:honeycomb_block
setblock 2 291 343 minecraft:yellow_terracotta
fill 2 291 344 2 291 347 minecraft:honeycomb_block
setblock 2 291 348 minecraft:yellow_terracotta
fill 2 291 349 2 294 349 minecraft:honeycomb_block
setblock 2 291 353 minecraft:yellow_terracotta
fill 2 291 355 2 295 355 minecraft:yellow_terracotta
setblock 2 291 358 minecraft:yellow_terracotta
setblock 2 291 359 minecraft:honeycomb_block
setblock 2 291 362 minecraft:honeycomb_block
setblock 2 291 363 minecraft:yellow_terracotta
setblock 3 291 322 minecraft:yellow_concrete
fill 3 291 323 3 294 323 minecraft:honeycomb_block
setblock 3 291 347 minecraft:yellow_terracotta
setblock 3 291 348 minecraft:honeycomb_block
setblock 3 291 362 minecraft:yellow_terracotta
fill 3 291 363 6 291 363 minecraft:honeycomb_block
setblock 4 291 362 minecraft:honeycomb_block
setblock 7 291 323 minecraft:honey_block
fill 14 291 322 14 305 322 minecraft:honeycomb_block
setblock 16 291 324 minecraft:yellow_terracotta
setblock 16 291 363 minecraft:honeycomb_block
setblock 17 291 323 minecraft:yellow_terracotta
fill 17 291 324 20 291 324 minecraft:honeycomb_block
setblock 17 291 363 minecraft:yellow_terracotta
fill 18 291 323 21 291 323 minecraft:honeycomb_block
fill 18 291 363 21 291 363 minecraft:honeycomb_block
setblock 20 291 325 minecraft:yellow_terracotta
setblock 21 291 324 minecraft:yellow_terracotta
fill 21 291 325 21 294 325 minecraft:honeycomb_block
fill 21 291 356 21 291 358 minecraft:flowering_azalea_leaves[persistent=true]
setblock 22 291 323 minecraft:yellow_terracotta
fill 22 291 324 22 294 324 minecraft:honeycomb_block
setblock 22 291 355 minecraft:flowering_azalea_leaves[persistent=true]
fill 22 291 359 24 291 359 minecraft:flowering_azalea_leaves[persistent=true]
setblock 22 291 363 minecraft:yellow_terracotta
fill 23 291 323 26 291 323 minecraft:honeycomb_block
fill 23 291 357 23 292 357 minecraft:flowering_azalea_leaves[persistent=true]
setblock 23 291 363 minecraft:honeycomb_block
setblock 24 291 355 minecraft:flowering_azalea_leaves[persistent=true]
setblock 25 291 356 minecraft:flowering_azalea_leaves[persistent=true]
setblock 25 291 358 minecraft:flowering_azalea_leaves[persistent=true]
setblock 26 291 324 minecraft:yellow_terracotta
setblock 27 291 323 minecraft:yellow_terracotta
fill 27 291 324 30 291 324 minecraft:honeycomb_block
fill 28 291 323 31 291 323 minecraft:honeycomb_block
setblock 31 291 324 minecraft:yellow_terracotta
fill 31 291 338 31 295 338 minecraft:brown_terracotta
setblock 32 291 323 minecraft:yellow_terracotta
fill 32 291 324 32 294 324 minecraft:honeycomb_block
fill 32 291 337 33 295 337 minecraft:brown_terracotta
setblock 32 291 363 minecraft:yellow_terracotta
fill 33 291 323 33 294 323 minecraft:honeycomb_block
fill 33 291 340 33 295 340 minecraft:brown_terracotta
fill 33 291 363 33 294 363 minecraft:honeycomb_block
fill 34 291 339 34 295 339 minecraft:brown_terracotta
setblock 35 291 325 minecraft:yellow_terracotta
setblock 36 291 324 minecraft:yellow_terracotta
fill 36 291 325 36 294 325 minecraft:honeycomb_block
fill 36 291 342 36 292 342 minecraft:brown_terracotta
setblock 37 291 323 minecraft:yellow_terracotta
fill 37 291 324 37 294 324 minecraft:honeycomb_block
fill 37 291 341 37 292 341 minecraft:brown_terracotta
fill 37 291 343 37 292 343 minecraft:brown_terracotta
setblock 37 291 363 minecraft:yellow_terracotta
fill 38 291 323 38 294 323 minecraft:honeycomb_block
fill 38 291 342 38 292 342 minecraft:brown_terracotta
setblock 38 291 362 minecraft:yellow_terracotta
fill 38 291 363 38 294 363 minecraft:honeycomb_block
setblock 39 291 326 minecraft:yellow_terracotta
fill 39 291 327 39 294 327 minecraft:honeycomb_block
setblock 39 291 361 minecraft:yellow_terracotta
fill 39 291 362 39 294 362 minecraft:honeycomb_block
setblock 40 291 325 minecraft:yellow_terracotta
fill 40 291 326 40 294 326 minecraft:honeycomb_block
setblock 40 291 345 minecraft:yellow_terracotta
fill 40 291 346 40 294 346 minecraft:honeycomb_block
setblock 40 291 349 minecraft:honeycomb_block
setblock 40 291 360 minecraft:yellow_terracotta
fill 40 291 361 40 294 361 minecraft:honeycomb_block
setblock 41 291 324 minecraft:yellow_terracotta
fill 41 291 325 41 294 325 minecraft:honeycomb_block
setblock 41 291 329 minecraft:yellow_terracotta
fill 41 291 330 41 294 330 minecraft:honeycomb_block
setblock 41 291 333 minecraft:honey_block
setblock 41 291 340 minecraft:honeycomb_block
setblock 41 291 344 minecraft:yellow_terracotta
fill 41 291 345 41 294 345 minecraft:honeycomb_block
setblock 41 291 349 minecraft:yellow_terracotta
fill 41 291 350 41 294 350 minecraft:honeycomb_block
setblock 41 291 354 minecraft:yellow_terracotta
fill 41 291 355 41 294 355 minecraft:honeycomb_block
setblock 41 291 359 minecraft:yellow_terracotta
fill 41 291 360 41 294 360 minecraft:honeycomb_block
setblock 42 291 339 minecraft:yellow_terracotta
setblock 0 292 325 minecraft:orange_terracotta
setblock 0 292 326 minecraft:yellow_terracotta
fill 0 292 340 1 294 340 minecraft:honeycomb_block
setblock 1 292 323 minecraft:yellow_terracotta
fill 1 292 324 1 295 324 minecraft:honeycomb_block
setblock 1 292 328 minecraft:yellow_terracotta
fill 1 292 341 1 292 342 minecraft:honeycomb_block
setblock 1 292 343 minecraft:yellow_terracotta
fill 1 292 344 1 292 347 minecraft:honeycomb_block
setblock 1 292 348 minecraft:yellow_terracotta
fill 1 292 349 1 295 349 minecraft:honeycomb_block
setblock 1 292 353 minecraft:yellow_terracotta
fill 1 292 354 1 292 357 minecraft:honeycomb_block
setblock 1 292 358 minecraft:yellow_terracotta
fill 1 292 359 1 295 359 minecraft:honeycomb_block
fill 1 292 361 1 292 362 minecraft:honeycomb_block
setblock 1 292 363 minecraft:yellow_terracotta
fill 2 292 323 2 295 323 minecraft:honeycomb_block
setblock 2 292 342 minecraft:yellow_terracotta
fill 2 292 343 2 292 346 minecraft:honeycomb_block
setblock 2 292 347 minecraft:yellow_terracotta
fill 2 292 348 2 295 348 minecraft:honeycomb_block
setblock 2 292 352 minecraft:yellow_terracotta
fill 2 292 353 2 295 353 minecraft:honeycomb_block
setblock 2 292 362 minecraft:yellow_terracotta
fill 2 292 363 5 292 363 minecraft:honeycomb_block
fill 3 292 322 3 308 322 minecraft:honeycomb_block
setblock 3 292 346 minecraft:yellow_terracotta
fill 3 292 347 3 295 347 minecraft:honeycomb_block
setblock 16 292 323 minecraft:yellow_terracotta
fill 16 292 324 19 292 324 minecraft:honeycomb_block
setblock 16 292 363 minecraft:yellow_terracotta
fill 17 292 323 20 292 323 minecraft:honeycomb_block
fill 17 292 363 20 292 363 minecraft:honeycomb_block
setblock 19 292 325 minecraft:yellow_terracotta
setblock 20 292 324 minecraft:yellow_terracotta
fill 20 292 325 20 295 325 minecraft:honeycomb_block
setblock 21 292 323 minecraft:yellow_terracotta
fill 21 292 324 21 295 324 minecraft:honeycomb_block
setblock 21 292 363 minecraft:yellow_terracotta
fill 22 292 323 25 292 323 minecraft:honeycomb_block
setblock 22 292 363 minecraft:honeycomb_block
setblock 25 292 324 minecraft:yellow_terracotta
setblock 26 292 323 minecraft:yellow_terracotta
fill 26 292 324 29 292 324 minecraft:honeycomb_block
fill 27 292 323 30 292 323 minecraft:honeycomb_block
setblock 30 292 324 minecraft:yellow_terracotta
setblock 31 292 323 minecraft:yellow_terracotta
fill 31 292 324 31 295 324 minecraft:honeycomb_block
fill 31 292 337 31 295 337 minecraft:brown_terracotta
fill 31 292 339 31 295 339 minecraft:brown_terracotta
fill 32 292 323 32 295 323 minecraft:honeycomb_block
fill 32 292 340 32 295 340 minecraft:brown_terracotta
fill 32 292 363 32 295 363 minecraft:honeycomb_block
setblock 34 292 325 minecraft:yellow_terracotta
fill 34 292 337 34 295 337 minecraft:brown_terracotta
fill 34 292 340 34 295 340 minecraft:brown_terracotta
setblock 35 292 324 minecraft:yellow_terracotta
fill 35 292 325 35 295 325 minecraft:honeycomb_block
setblock 36 292 323 minecraft:yellow_terracotta
fill 36 292 324 36 295 324 minecraft:honeycomb_block
setblock 36 292 363 minecraft:yellow_terracotta
fill 37 292 323 37 295 323 minecraft:honeycomb_block
setblock 37 292 362 minecraft:yellow_terracotta
fill 37 292 363 37 295 363 minecraft:honeycomb_block
fill 38 292 362 38 295 362 minecraft:honeycomb_block
setblock 39 292 325 minecraft:yellow_terracotta
fill 39 292 326 39 295 326 minecraft:honeycomb_block
setblock 40 292 324 minecraft:yellow_terracotta
fill 40 292 325 40 295 325 minecraft:honeycomb_block
setblock 40 292 329 minecraft:yellow_terracotta
setblock 40 292 344 minecraft:yellow_terracotta
fill 40 292 345 40 295 345 minecraft:honeycomb_block
fill 40 292 347 40 292 348 minecraft:honeycomb_block
setblock 40 292 349 minecraft:yellow_terracotta
fill 40 292 350 40 295 350 minecraft:honeycomb_block
setblock 40 292 359 minecraft:yellow_terracotta
fill 40 292 360 40 295 360 minecraft:honeycomb_block
setblock 41 292 323 minecraft:yellow_terracotta
fill 41 292 324 41 295 324 minecraft:honeycomb_block
setblock 41 292 328 minecraft:yellow_terracotta
fill 41 292 329 41 295 329 minecraft:honeycomb_block
setblock 41 292 343 minecraft:yellow_terracotta
fill 41 292 344 41 295 344 minecraft:honeycomb_block
setblock 41 292 347 minecraft:honeycomb_block
setblock 41 292 348 minecraft:yellow_terracotta
fill 41 292 349 41 295 349 minecraft:honeycomb_block
setblock 41 292 353 minecraft:yellow_terracotta
fill 41 292 354 41 295 354 minecraft:honeycomb_block
setblock 41 292 358 minecraft:yellow_terracotta
fill 41 292 359 41 295 359 minecraft:honeycomb_block
setblock 41 292 363 minecraft:yellow_terracotta
fill 42 292 339 42 308 339 minecraft:honeycomb_block
fill 0 293 325 0 303 327 minecraft:honeycomb_block
setblock 0 293 341 minecraft:orange_terracotta
fill 1 293 323 1 296 323 minecraft:honeycomb_block
setblock 1 293 327 minecraft:yellow_terracotta
fill 1 293 328 1 295 329 minecraft:honeycomb_block
setblock 1 293 341 minecraft:honeycomb_block
setblock 1 293 342 minecraft:yellow_terracotta
fill 1 293 343 1 293 346 minecraft:honeycomb_block
setblock 1 293 347 minecraft:yellow_terracotta
fill 1 293 348 1 296 348 minecraft:honeycomb_block
setblock 1 293 352 minecraft:yellow_terracotta
fill 1 293 353 1 293 356 minecraft:honeycomb_block
setblock 1 293 357 minecraft:yellow_terracotta
fill 1 293 358 1 296 358 minecraft:honeycomb_block
setblock 1 293 361 minecraft:honeycomb_block
setblock 1 293 362 minecraft:yellow_terracotta
fill 1 293 363 4 293 363 minecraft:honeycomb_block
fill 2 293 343 2 293 345 minecraft:honeycomb_block
setblock 2 293 346 minecraft:yellow_terracotta
fill 2 293 347 2 296 347 minecraft:honeycomb_block
setblock 2 293 351 minecraft:yellow_terracotta
fill 2 293 352 2 296 352 minecraft:honeycomb_block
fill 3 293 348 3 294 348 minecraft:honeycomb_block
setblock 15 293 323 minecraft:yellow_terracotta
fill 15 293 324 18 293 324 minecraft:honeycomb_block
fill 16 293 323 19 293 323 minecraft:honeycomb_block
fill 17 293 363 19 293 363 minecraft:honeycomb_block
setblock 18 293 325 minecraft:yellow_terracotta
fill 18 293 332 18 294 332 minecraft:black_concrete
setblock 19 293 324 minecraft:yellow_terracotta
fill 19 293 325 19 296 325 minecraft:honeycomb_block
fill 19 293 332 19 294 332 minecraft:yellow_concrete
setblock 20 293 323 minecraft:yellow_terracotta
fill 20 293 324 20 296 324 minecraft:honeycomb_block
setblock 20 293 363 minecraft:yellow_terracotta
fill 21 293 323 24 293 323 minecraft:honeycomb_block
setblock 21 293 363 minecraft:honeycomb_block
setblock 24 293 324 minecraft:yellow_terracotta
setblock 25 293 323 minecraft:yellow_terracotta
fill 25 293 324 28 293 324 minecraft:honeycomb_block
fill 26 293 323 29 293 323 minecraft:honeycomb_block
setblock 28 293 363 minecraft:honey_block
setblock 29 293 324 minecraft:yellow_terracotta
setblock 30 293 323 minecraft:yellow_terracotta
fill 30 293 324 30 296 324 minecraft:honeycomb_block
fill 31 293 323 31 296 323 minecraft:honeycomb_block
fill 31 293 340 31 295 340 minecraft:brown_terracotta
fill 32 293 336 34 295 336 minecraft:brown_terracotta
fill 33 293 341 33 295 341 minecraft:brown_terracotta
setblock 34 293 324 minecraft:yellow_terracotta
fill 34 293 325 34 296 325 minecraft:honeycomb_block
setblock 35 293 323 minecraft:yellow_terracotta
fill 35 293 324 35 296 324 minecraft:honeycomb_block
fill 35 293 337 35 295 339 minecraft:brown_terracotta
setblock 35 293 362 minecraft:honeycomb_block
setblock 35 293 363 minecraft:yellow_terracotta
fill 36 293 323 36 296 323 minecraft:honeycomb_block
setblock 36 293 362 minecraft:yellow_terracotta
fill 36 293 363 36 296 363 minecraft:honeycomb_block
fill 37 293 362 37 296 362 minecraft:honeycomb_block
setblock 38 293 325 minecraft:yellow_terracotta
setblock 39 293 324 minecraft:yellow_terracotta
fill 39 293 325 39 296 325 minecraft:honeycomb_block
setblock 40 293 323 minecraft:yellow_terracotta
fill 40 293 324 40 296 324 minecraft:honeycomb_block
setblock 40 293 328 minecraft:yellow_terracotta
fill 40 293 329 40 296 329 minecraft:honeycomb_block
setblock 40 293 344 minecraft:honeycomb_block
setblock 40 293 347 minecraft:honeycomb_block
setblock 40 293 348 minecraft:yellow_terracotta
fill 40 293 349 40 296 349 minecraft:honeycomb_block
fill 40 293 351 40 294 351 minecraft:honeycomb_block
fill 40 293 359 40 296 359 minecraft:honeycomb_block
setblock 40 293 363 minecraft:yellow_terracotta
fill 41 293 323 41 296 323 minecraft:honeycomb_block
setblock 41 293 327 minecraft:yellow_terracotta
fill 41 293 328 41 296 328 minecraft:honeycomb_block
setblock 41 293 340 minecraft:honey_block
setblock 41 293 342 minecraft:yellow_terracotta
fill 41 293 343 41 296 343 minecraft:honeycomb_block
setblock 41 293 347 minecraft:yellow_terracotta
fill 41 293 348 41 296 348 minecraft:honeycomb_block
setblock 41 293 352 minecraft:yellow_terracotta
fill 41 293 353 41 296 353 minecraft:honeycomb_block
setblock 41 293 357 minecraft:yellow_terracotta
fill 41 293 358 41 296 358 minecraft:honeycomb_block
setblock 41 293 362 minecraft:yellow_terracotta
fill 41 293 363 41 296 363 minecraft:honeycomb_block
setblock 42 293 344 minecraft:yellow_concrete
fill 0 294 341 0 308 341 minecraft:honeycomb_block
setblock 1 294 326 minecraft:yellow_terracotta
fill 1 294 327 1 297 327 minecraft:honeycomb_block
setblock 1 294 341 minecraft:yellow_terracotta
fill 1 294 342 1 294 345 minecraft:honeycomb_block
setblock 1 294 346 minecraft:yellow_terracotta
fill 1 294 347 1 297 347 minecraft:honeycomb_block
setblock 1 294 351 minecraft:yellow_terracotta
fill 1 294 352 1 294 355 minecraft:honeycomb_block
setblock 1 294 356 minecraft:yellow_terracotta
fill 1 294 357 1 297 357 minecraft:honeycomb_block
setblock 1 294 361 minecraft:yellow_terracotta
fill 1 294 362 1 296 363 minecraft:honeycomb_block
fill 2 294 343 2 294 344 minecraft:honeycomb_block
setblock 2 294 345 minecraft:yellow_terracotta
fill 2 294 346 2 297 346 minecraft:honeycomb_block
setblock 2 294 350 minecraft:yellow_terracotta
fill 2 294 351 2 297 351 minecraft:honeycomb_block
setblock 2 294 354 minecraft:honeycomb_block
fill 2 294 363 3 294 363 minecraft:honeycomb_block
setblock 3 294 349 minecraft:yellow_terracotta
setblock 8 294 323 minecraft:honey_block
setblock 9 294 363 minecraft:honey_block
setblock 13 294 323 minecraft:honeycomb_block
setblock 14 294 323 minecraft:yellow_terracotta
fill 15 294 323 17 294 324 minecraft:honeycomb_block
setblock 17 294 325 minecraft:yellow_terracotta
fill 17 294 363 18 294 363 minecraft:honeycomb_block
setblock 18 294 323 minecraft:honeycomb_block
setblock 18 294 324 minecraft:yellow_terracotta
fill 18 294 325 18 297 325 minecraft:honeycomb_block
setblock 19 294 323 minecraft:yellow_terracotta
fill 19 294 324 19 297 324 minecraft:honeycomb_block
setblock 19 294 363 minecraft:yellow_terracotta
fill 20 294 323 23 294 323 minecraft:honeycomb_block
setblock 20 294 363 minecraft:honeycomb_block
setblock 22 294 325 minecraft:yellow_terracotta
setblock 23 294 324 minecraft:yellow_terracotta
setblock 24 294 323 minecraft:yellow_terracotta
fill 24 294 324 27 294 324 minecraft:honeycomb_block
fill 25 294 323 28 294 323 minecraft:honeycomb_block
setblock 28 294 324 minecraft:yellow_terracotta
setblock 29 294 323 minecraft:yellow_terracotta
fill 29 294 324 29 297 324 minecraft:honeycomb_block
fill 30 294 323 30 297 323 minecraft:honeycomb_block
fill 30 294 337 30 295 339 minecraft:brown_terracotta
fill 31 294 336 31 295 336 minecraft:brown_terracotta
fill 32 294 341 32 295 341 minecraft:brown_terracotta
setblock 33 294 324 minecraft:yellow_terracotta
fill 33 294 325 33 297 325 minecraft:honeycomb_block
setblock 34 294 323 minecraft:yellow_terracotta
fill 34 294 324 34 297 324 minecraft:honeycomb_block
fill 34 294 341 34 295 341 minecraft:brown_terracotta
setblock 34 294 363 minecraft:yellow_terracotta
fill 35 294 323 35 297 323 minecraft:honeycomb_block
fill 35 294 340 35 295 340 minecraft:brown_terracotta
setblock 35 294 362 minecraft:yellow_terracotta
fill 35 294 363 35 297 363 minecraft:honeycomb_block
fill 36 294 362 36 297 362 minecraft:honeycomb_block
setblock 37 294 325 minecraft:yellow_terracotta
setblock 38 294 324 minecraft:yellow_terracotta
fill 38 294 325 38 297 325 minecraft:honeycomb_block
setblock 39 294 323 minecraft:yellow_terracotta
fill 39 294 324 39 297 324 minecraft:honeycomb_block
setblock 39 294 328 minecraft:yellow_terracotta
setblock 39 294 363 minecraft:yellow_terracotta
fill 40 294 323 40 297 323 minecraft:honeycomb_block
setblock 40 294 327 minecraft:yellow_terracotta
fill 40 294 328 40 297 328 minecraft:honeycomb_block
setblock 40 294 347 minecraft:yellow_terracotta
fill 40 294 348 40 297 348 minecraft:honeycomb_block
setblock 40 294 352 minecraft:yellow_terracotta
fill 40 294 353 40 296 354 minecraft:honeycomb_block
setblock 40 294 362 minecraft:yellow_terracotta
fill 40 294 363 40 297 363 minecraft:honeycomb_block
setblock 41 294 326 minecraft:yellow_terracotta
fill 41 294 327 41 297 327 minecraft:honeycomb_block
setblock 41 294 331 minecraft:yellow_terracotta
setblock 41 294 334 minecraft:honey_block
setblock 41 294 342 minecraft:honeycomb_block
setblock 41 294 346 minecraft:yellow_terracotta
fill 41 294 347 41 297 347 minecraft:honeycomb_block
setblock 41 294 351 minecraft:yellow_terracotta
fill 41 294 352 41 297 352 minecraft:honeycomb_block
setblock 41 294 356 minecraft:yellow_terracotta
fill 41 294 357 41 297 357 minecraft:honeycomb_block
setblock 41 294 361 minecraft:yellow_terracotta
fill 41 294 362 41 297 362 minecraft:honeycomb_block
setblock 42 294 335 minecraft:yellow_terracotta
fill 42 294 344 42 300 344 minecraft:honeycomb_block
setblock 42 294 345 minecraft:orange_terracotta
setblock 42 294 354 minecraft:yellow_concrete
setblock 0 295 338 minecraft:orange_terracotta
fill 0 295 340 0 308 340 minecraft:honeycomb_block
setblock 0 295 342 minecraft:orange_terracotta
setblock 0 295 352 minecraft:yellow_terracotta
setblock 1 295 325 minecraft:yellow_terracotta
fill 1 295 326 1 298 326 minecraft:honeycomb_block
setblock 1 295 330 minecraft:yellow_terracotta
setblock 1 295 333 minecraft:honey_block
fill 1 295 341 1 295 344 minecraft:honeycomb_block
setblock 1 295 345 minecraft:yellow_terracotta
fill 1 295 346 1 298 346 minecraft:honeycomb_block
setblock 1 295 350 minecraft:yellow_terracotta
fill 1 295 351 1 295 354 minecraft:honeycomb_block
setblock 1 295 355 minecraft:yellow_terracotta
fill 1 295 356 1 298 356 minecraft:honeycomb_block
setblock 1 295 360 minecraft:yellow_terracotta
fill 1 295 361 1 298 361 minecraft:honeycomb_block
setblock 2 295 343 minecraft:honeycomb_block
setblock 2 295 344 minecraft:yellow_terracotta
fill 2 295 345 2 298 345 minecraft:honeycomb_block
setblock 2 295 349 minecraft:yellow_terracotta
fill 2 295 350 3 297 350 minecraft:honeycomb_block
setblock 2 295 354 minecraft:yellow_terracotta
setblock 2 295 363 minecraft:honeycomb_block
setblock 3 295 348 minecraft:yellow_terracotta
fill 3 295 349 3 298 349 minecraft:honeycomb_block
setblock 12 295 323 minecraft:honeycomb_block
setblock 13 295 323 minecraft:yellow_terracotta
fill 14 295 323 16 295 324 minecraft:honeycomb_block
setblock 15 295 363 minecraft:honey_block
setblock 16 295 325 minecraft:yellow_terracotta
setblock 17 295 323 minecraft:honeycomb_block
setblock 17 295 324 minecraft:yellow_terracotta
fill 17 295 325 17 298 325 minecraft:honeycomb_block
setblock 17 295 363 minecraft:honeycomb_block
setblock 18 295 322 minecraft:yellow_concrete
setblock 18 295 323 minecraft:yellow_terracotta
fill 18 295 324 18 298 324 minecraft:honeycomb_block
setblock 18 295 363 minecraft:yellow_terracotta
fill 19 295 323 22 295 323 minecraft:honeycomb_block
fill 19 295 363 19 296 363 minecraft:honeycomb_block
setblock 21 295 325 minecraft:yellow_terracotta
fill 21 295 363 21 296 363 minecraft:honey_block
setblock 22 295 324 minecraft:yellow_terracotta
fill 22 295 325 23 297 325 minecraft:honeycomb_block
setblock 23 295 323 minecraft:yellow_terracotta
fill 23 295 324 26 295 324 minecraft:honeycomb_block
fill 24 295 323 27 295 323 minecraft:honeycomb_block
setblock 27 295 324 minecraft:yellow_terracotta
setblock 28 295 323 minecraft:yellow_terracotta
fill 28 295 324 28 298 324 minecraft:honeycomb_block
fill 29 295 323 29 298 323 minecraft:honeycomb_block
setblock 30 295 336 minecraft:brown_terracotta
setblock 30 295 340 minecraft:brown_terracotta
setblock 31 295 325 minecraft:yellow_terracotta
setblock 31 295 341 minecraft:brown_terracotta
fill 31 295 363 31 296 363 minecraft:honeycomb_block
setblock 32 295 324 minecraft:yellow_terracotta
fill 32 295 325 32 298 325 minecraft:honeycomb_block
fill 32 295 335 34 295 335 minecraft:brown_terracotta
setblock 33 295 323 minecraft:yellow_terracotta
fill 33 295 324 33 298 324 minecraft:honeycomb_block
setblock 33 295 363 minecraft:yellow_terracotta
fill 34 295 323 34 298 323 minecraft:honeycomb_block
fill 34 295 363 34 298 363 minecraft:honeycomb_block
setblock 35 295 336 minecraft:brown_terracotta
setblock 35 295 341 minecraft:brown_terracotta
fill 35 295 362 35 298 362 minecraft:honeycomb_block
setblock 36 295 325 minecraft:yellow_terracotta
fill 36 295 326 37 297 326 minecraft:honeycomb_block
fill 36 295 337 36 295 339 minecraft:brown_terracotta
setblock 37 295 324 minecraft:yellow_terracotta
fill 37 295 325 37 298 325 minecraft:honeycomb_block
setblock 38 295 323 minecraft:yellow_terracotta
fill 38 295 324 38 298 324 minecraft:honeycomb_block
setblock 38 295 363 minecraft:yellow_terracotta
fill 39 295 323 39 298 323 minecraft:honeycomb_block
setblock 39 295 327 minecraft:yellow_terracotta
fill 39 295 328 39 298 328 minecraft:honeycomb_block
fill 39 295 349 39 296 350 minecraft:honeycomb_block
setblock 39 295 362 minecraft:yellow_terracotta
fill 39 295 363 39 298 363 minecraft:honeycomb_block
setblock 40 295 326 minecraft:yellow_terracotta
fill 40 295 327 40 298 327 minecraft:honeycomb_block
setblock 40 295 330 minecraft:honeycomb_block
setblock 40 295 346 minecraft:yellow_terracotta
fill 40 295 347 40 298 347 minecraft:honeycomb_block
setblock 40 295 351 minecraft:yellow_terracotta
fill 40 295 352 40 298 352 minecraft:honeycomb_block
setblock 40 295 355 minecraft:honeycomb_block
setblock 40 295 356 minecraft:yellow_terracotta
fill 40 295 357 40 297 358 minecraft:honeycomb_block
setblock 40 295 361 minecraft:yellow_terracotta
fill 40 295 362 40 298 362 minecraft:honeycomb_block
setblock 41 295 325 minecraft:yellow_terracotta
fill 41 295 326 41 298 326 minecraft:honeycomb_block
setblock 41 295 330 minecraft:yellow_terracotta
fill 41 295 331 41 298 331 minecraft:honeycomb_block
setblock 41 295 345 minecraft:yellow_terracotta
fill 41 295 346 41 298 346 minecraft:honeycomb_block
setblock 41 295 350 minecraft:yellow_terracotta
fill 41 295 351 41 298 351 minecraft:honeycomb_block
setblock 41 295 355 minecraft:yellow_terracotta
fill 41 295 356 41 298 356 minecraft:honeycomb_block
setblock 41 295 360 minecraft:yellow_terracotta
fill 41 295 361 41 298 361 minecraft:honeycomb_block
fill 42 295 335 42 302 335 minecraft:honeycomb_block
fill 42 295 345 42 308 345 minecraft:honeycomb_block
setblock 42 295 349 minecraft:yellow_concrete
fill 42 295 354 42 308 354 minecraft:honeycomb_block
fill 0 296 338 0 308 338 minecraft:honeycomb_block
fill 0 296 342 1 297 342 minecraft:honeycomb_block
fill 0 296 352 1 297 352 minecraft:honeycomb_block
setblock 1 296 324 minecraft:yellow_terracotta
fill 1 296 325 1 299 325 minecraft:honeycomb_block
setblock 1 296 328 minecraft:honeycomb_block
setblock 1 296 329 minecraft:yellow_terracotta
fill 1 296 330 1 298 331 minecraft:honeycomb_block
setblock 1 296 339 minecraft:honey_block
fill 1 296 341 1 298 341 minecraft:honeycomb_block
setblock 1 296 343 minecraft:honeycomb_block
setblock 1 296 344 minecraft:yellow_terracotta
fill 1 296 345 1 299 345 minecraft:honeycomb_block
setblock 1 296 349 minecraft:yellow_terracotta
fill 1 296 350 1 298 351 minecraft:honeycomb_block
setblock 1 296 353 minecraft:honeycomb_block
setblock 1 296 354 minecraft:yellow_terracotta
fill 1 296 355 2 298 355 minecraft:honeycomb_block
setblock 1 296 359 minecraft:yellow_terracotta
fill 1 296 360 1 299 360 minecraft:honeycomb_block
setblock 2 296 323 minecraft:yellow_terracotta
fill 2 296 344 2 298 344 minecraft:honeycomb_block
setblock 2 296 348 minecraft:yellow_terracotta
fill 2 296 349 2 299 349 minecraft:honeycomb_block
setblock 2 296 353 minecraft:yellow_terracotta
fill 2 296 354 2 299 354 minecraft:honeycomb_block
setblock 2 296 363 minecraft:yellow_terracotta
setblock 3 296 325 minecraft:light[level=15]
setblock 3 296 332 minecraft:light[level=12]
setblock 3 296 339 minecraft:light[level=12]
setblock 3 296 341 minecraft:light[level=15]
setblock 3 296 346 minecraft:light[level=12]
setblock 3 296 347 minecraft:yellow_terracotta
fill 3 296 348 3 299 348 minecraft:honeycomb_block
setblock 3 296 351 minecraft:honeycomb_block
setblock 3 296 353 minecraft:light[level=12]
setblock 3 296 357 minecraft:light[level=15]
setblock 3 296 360 minecraft:light[level=12]
setblock 4 296 322 minecraft:orange_terracotta
setblock 10 296 325 minecraft:light[level=12]
setblock 10 296 332 minecraft:light[level=12]
setblock 10 296 339 minecraft:light[level=12]
setblock 10 296 346 minecraft:light[level=12]
setblock 10 296 353 minecraft:light[level=12]
setblock 10 296 360 minecraft:light[level=12]
setblock 11 296 325 minecraft:light[level=15]
setblock 11 296 333 minecraft:light[level=15]
setblock 11 296 341 minecraft:light[level=15]
setblock 11 296 349 minecraft:light[level=15]
setblock 11 296 357 minecraft:light[level=15]
setblock 12 296 323 minecraft:yellow_terracotta
fill 13 296 323 15 296 324 minecraft:honeycomb_block
setblock 15 296 325 minecraft:yellow_terracotta
setblock 16 296 323 minecraft:honeycomb_block
setblock 16 296 324 minecraft:yellow_terracotta
fill 16 296 325 16 299 325 minecraft:honeycomb_block
setblock 16 296 363 minecraft:honeycomb_block
setblock 17 296 323 minecraft:yellow_terracotta
fill 17 296 324 17 299 324 minecraft:honeycomb_block
setblock 17 296 332 minecraft:light[level=12]
setblock 17 296 339 minecraft:light[level=12]
setblock 17 296 346 minecraft:light[level=12]
setblock 17 296 353 minecraft:light[level=12]
setblock 17 296 360 minecraft:light[level=12]
setblock 17 296 363 minecraft:yellow_terracotta
fill 18 296 322 18 299 323 minecraft:honeycomb_block
setblock 18 296 326 minecraft:honeycomb_block
fill 18 296 363 18 298 363 minecraft:honeycomb_block
fill 19 296 323 21 296 323 minecraft:honeycomb_block
setblock 19 296 326 minecraft:yellow_terracotta
setblock 19 296 333 minecraft:light[level=15]
setblock 19 296 341 minecraft:light[level=15]
setblock 19 296 349 minecraft:light[level=15]
setblock 19 296 357 minecraft:light[level=15]
setblock 20 296 325 minecraft:yellow_terracotta
setblock 21 296 324 minecraft:yellow_terracotta
fill 21 296 325 21 299 325 minecraft:honeycomb_block
setblock 22 296 323 minecraft:yellow_terracotta
fill 22 296 324 25 296 324 minecraft:honeycomb_block
fill 23 296 323 26 296 323 minecraft:honeycomb_block
setblock 24 296 322 minecraft:orange_terracotta
setblock 24 296 325 minecraft:light[level=12]
setblock 24 296 332 minecraft:light[level=12]
setblock 24 296 339 minecraft:light[level=12]
setblock 24 296 346 minecraft:light[level=12]
setblock 24 296 353 minecraft:light[level=12]
setblock 24 296 360 minecraft:light[level=12]
setblock 26 296 324 minecraft:yellow_terracotta
setblock 27 296 323 minecraft:yellow_terracotta
fill 27 296 324 27 299 324 minecraft:honeycomb_block
setblock 27 296 325 minecraft:light[level=15]
setblock 27 296 333 minecraft:light[level=15]
setblock 27 296 341 minecraft:light[level=15]
setblock 27 296 349 minecraft:light[level=15]
setblock 27 296 357 minecraft:light[level=15]
setblock 27 296 363 minecraft:honey_block
fill 28 296 323 28 299 323 minecraft:honeycomb_block
setblock 30 296 325 minecraft:yellow_terracotta
setblock 31 296 324 minecraft:yellow_terracotta
fill 31 296 325 31 299 325 minecraft:honeycomb_block
setblock 31 296 332 minecraft:light[level=12]
setblock 31 296 339 minecraft:light[level=12]
setblock 31 296 346 minecraft:light[level=12]
setblock 31 296 353 minecraft:light[level=12]
setblock 31 296 360 minecraft:light[level=12]
setblock 32 296 323 minecraft:yellow_terracotta
fill 32 296 324 32 299 324 minecraft:honeycomb_block
setblock 32 296 363 minecraft:yellow_terracotta
fill 33 296 323 33 299 323 minecraft:honeycomb_block
fill 33 296 338 33 298 338 minecraft:yellow_terracotta
fill 33 296 363 33 299 363 minecraft:honeycomb_block
setblock 34 296 326 minecraft:yellow_terracotta
fill 34 296 362 34 299 362 minecraft:honeycomb_block
setblock 35 296 325 minecraft:yellow_terracotta
fill 35 296 326 35 299 326 minecraft:honeycomb_block
setblock 35 296 333 minecraft:light[level=15]
setblock 35 296 341 minecraft:light[level=15]
setblock 36 296 324 minecraft:yellow_terracotta
fill 36 296 325 36 299 325 minecraft:honeycomb_block
setblock 37 296 323 minecraft:yellow_terracotta
fill 37 296 324 37 299 324 minecraft:honeycomb_block
setblock 37 296 363 minecraft:yellow_terracotta
fill 38 296 323 38 299 323 minecraft:honeycomb_block
setblock 38 296 326 minecraft:honeycomb_block
setblock 38 296 332 minecraft:light[level=12]
setblock 38 296 339 minecraft:light[level=12]
setblock 38 296 353 minecraft:light[level=12]
setblock 38 296 360 minecraft:light[level=12]
setblock 38 296 362 minecraft:yellow_terracotta
fill 38 296 363 38 299 363 minecraft:honeycomb_block
setblock 39 296 326 minecraft:yellow_terracotta
fill 39 296 327 39 299 327 minecraft:honeycomb_block
fill 39 296 329 39 297 329 minecraft:honeycomb_block
fill 39 296 347 39 298 348 minecraft:honeycomb_block
setblock 39 296 351 minecraft:yellow_terracotta
fill 39 296 352 39 298 353 minecraft:honeycomb_block
fill 39 296 362 39 299 362 minecraft:honeycomb_block
setblock 40 296 325 minecraft:yellow_terracotta
fill 40 296 326 40 299 326 minecraft:honeycomb_block
setblock 40 296 330 minecraft:yellow_terracotta
setblock 40 296 345 minecraft:yellow_terracotta
fill 40 296 346 40 299 346 minecraft:honeycomb_block
setblock 40 296 350 minecraft:yellow_terracotta
fill 40 296 351 40 299 351 minecraft:honeycomb_block
setblock 40 296 355 minecraft:yellow_terracotta
fill 40 296 356 40 299 356 minecraft:honeycomb_block
setblock 40 296 360 minecraft:yellow_terracotta
fill 40 296 361 40 299 361 minecraft:honeycomb_block
setblock 41 296 324 minecraft:yellow_terracotta
fill 41 296 325 41 299 325 minecraft:honeycomb_block
setblock 41 296 329 minecraft:yellow_terracotta
fill 41 296 330 41 299 330 minecraft:honeycomb_block
fill 41 296 332 41 297 332 minecraft:honeycomb_block
setblock 41 296 341 minecraft:honey_block
setblock 41 296 344 minecraft:yellow_terracotta
fill 41 296 345 41 299 345 minecraft:honeycomb_block
setblock 41 296 349 minecraft:yellow_terracotta
fill 41 296 350 41 299 350 minecraft:honeycomb_block
setblock 41 296 354 minecraft:yellow_terracotta
fill 41 296 355 41 299 355 minecraft:honeycomb_block
setblock 41 296 359 minecraft:yellow_terracotta
fill 41 296 360 41 299 360 minecraft:honeycomb_block
fill 42 296 349 42 308 349 minecraft:honeycomb_block
fill 0 297 339 0 298 339 minecraft:yellow_concrete
setblock 1 297 323 minecraft:yellow_terracotta
fill 1 297 324 1 298 324 minecraft:honeycomb_block
setblock 1 297 328 minecraft:yellow_terracotta
fill 1 297 329 1 300 329 minecraft:honeycomb_block
setblock 1 297 332 minecraft:honeycomb_block
fill 1 297 333 2 297 336 minecraft:honey_block
setblock 1 297 343 minecraft:yellow_terracotta
fill 1 297 344 1 300 344 minecraft:honeycomb_block
setblock 1 297 348 minecraft:yellow_terracotta
fill 1 297 349 1 300 349 minecraft:honeycomb_block
setblock 1 297 353 minecraft:yellow_terracotta
fill 1 297 354 1 300 354 minecraft:honeycomb_block
setblock 1 297 358 minecraft:yellow_terracotta
fill 1 297 359 1 300 359 minecraft:honeycomb_block
setblock 1 297 362 minecraft:honeycomb_block
setblock 1 297 363 minecraft:yellow_terracotta
setblock 1 297 364 minecraft:orange_terracotta
fill 2 297 331 3 297 332 minecraft:honey_block
fill 2 297 337 6 297 337 minecraft:honey_block
setblock 2 297 347 minecraft:yellow_terracotta
fill 2 297 348 2 300 348 minecraft:honeycomb_block
setblock 2 297 352 minecraft:yellow_terracotta
fill 2 297 353 2 300 353 minecraft:honeycomb_block
fill 2 297 356 2 297 357 minecraft:honey_block
fill 3 297 336 7 297 336 minecraft:honey_block
fill 3 297 347 3 298 347 minecraft:honeycomb_block
setblock 3 297 351 minecraft:yellow_terracotta
fill 3 297 352 3 300 352 minecraft:honeycomb_block
fill 3 297 353 5 297 353 minecraft:honey_block
fill 3 297 357 5 297 357 minecraft:honey_block
fill 4 297 322 4 308 322 minecraft:honeycomb_block
fill 4 297 330 4 297 331 minecraft:honey_block
fill 4 297 338 5 297 338 minecraft:honey_block
fill 5 297 331 6 297 331 minecraft:honey_block
fill 5 297 354 5 298 356 minecraft:honey_block
fill 6 297 332 7 297 332 minecraft:honey_block
fill 6 297 335 7 298 335 minecraft:honey_block
fill 7 297 333 8 297 334 minecraft:honey_block
setblock 8 297 363 minecraft:honey_block
setblock 9 297 323 minecraft:honey_block
setblock 11 297 323 minecraft:yellow_terracotta
fill 12 297 323 14 297 324 minecraft:honeycomb_block
setblock 14 297 325 minecraft:yellow_terracotta
setblock 15 297 323 minecraft:honeycomb_block
setblock 15 297 324 minecraft:yellow_terracotta
fill 15 297 325 15 300 325 minecraft:honeycomb_block
setblock 15 297 363 minecraft:honeycomb_block
setblock 16 297 323 minecraft:yellow_terracotta
fill 16 297 324 16 300 324 minecraft:honeycomb_block
fill 16 297 326 17 297 326 minecraft:honeycomb_block
setblock 16 297 363 minecraft:yellow_terracotta
fill 17 297 323 17 300 323 minecraft:honeycomb_block
fill 17 297 363 17 300 363 minecraft:honeycomb_block
setblock 18 297 326 minecraft:yellow_terracotta
fill 19 297 323 20 297 323 minecraft:honeycomb_block
setblock 19 297 325 minecraft:yellow_terracotta
fill 19 297 326 19 298 326 minecraft:honeycomb_block
setblock 20 297 324 minecraft:yellow_terracotta
fill 20 297 325 20 300 325 minecraft:honeycomb_block
setblock 21 297 323 minecraft:yellow_terracotta
fill 21 297 324 24 297 324 minecraft:honeycomb_block
fill 22 297 323 25 297 323 minecraft:honeycomb_block
fill 24 297 322 24 299 322 minecraft:honeycomb_block
setblock 25 297 324 minecraft:yellow_terracotta
setblock 26 297 322 minecraft:orange_terracotta
setblock 26 297 323 minecraft:yellow_terracotta
fill 26 297 324 26 300 324 minecraft:honeycomb_block
fill 27 297 323 27 300 323 minecraft:honeycomb_block
setblock 29 297 325 minecraft:yellow_terracotta
setblock 30 297 324 minecraft:yellow_terracotta
fill 30 297 325 30 300 325 minecraft:honeycomb_block
setblock 30 297 363 minecraft:honeycomb_block
setblock 31 297 323 minecraft:yellow_terracotta
fill 31 297 324 31 300 324 minecraft:honeycomb_block
setblock 31 297 363 minecraft:yellow_terracotta
fill 32 297 323 32 300 323 minecraft:honeycomb_block
fill 32 297 347 34 297 348 minecraft:honey_block
fill 32 297 363 32 300 363 minecraft:honeycomb_block
setblock 33 297 326 minecraft:yellow_terracotta
fill 33 297 345 34 297 346 minecraft:honey_block
fill 33 297 349 34 297 350 minecraft:honey_block
fill 33 297 356 33 298 358 minecraft:honey_block
fill 33 297 362 33 300 362 minecraft:honeycomb_block
setblock 34 297 325 minecraft:yellow_terracotta
fill 34 297 326 34 300 326 minecraft:honeycomb_block
fill 34 297 344 39 297 344 minecraft:honey_block
fill 34 297 351 38 297 351 minecraft:honey_block
fill 34 297 355 37 297 355 minecraft:honey_block
fill 34 297 358 34 297 359 minecraft:honey_block
setblock 35 297 324 minecraft:yellow_terracotta
fill 35 297 325 35 300 325 minecraft:honeycomb_block
fill 35 297 343 38 297 343 minecraft:honey_block
fill 35 297 345 35 299 345 minecraft:honey_block
fill 35 297 350 38 298 350 minecraft:honey_block
fill 35 297 359 36 298 359 minecraft:honey_block
setblock 36 297 323 minecraft:yellow_terracotta
fill 36 297 324 36 300 324 minecraft:honeycomb_block
setblock 36 297 363 minecraft:yellow_terracotta
fill 37 297 323 37 300 323 minecraft:honeycomb_block
fill 37 297 356 37 298 358 minecraft:honey_block
setblock 37 297 362 minecraft:yellow_terracotta
fill 37 297 363 37 300 363 minecraft:honeycomb_block
setblock 38 297 326 minecraft:yellow_terracotta
fill 38 297 345 39 298 345 minecraft:honey_block
fill 38 297 362 38 300 362 minecraft:honeycomb_block
setblock 39 297 325 minecraft:yellow_terracotta
fill 39 297 326 39 299 326 minecraft:honeycomb_block
fill 39 297 346 39 299 346 minecraft:honey_block
setblock 39 297 349 minecraft:honeycomb_block
setblock 39 297 350 minecraft:yellow_terracotta
fill 39 297 351 39 300 351 minecraft:honeycomb_block
setblock 39 297 354 minecraft:honeycomb_block
setblock 39 297 355 minecraft:yellow_terracotta
setblock 40 297 324 minecraft:yellow_terracotta
fill 40 297 325 40 300 325 minecraft:honeycomb_block
setblock 40 297 329 minecraft:yellow_terracotta
fill 40 297 330 40 299 331 minecraft:honeycomb_block
fill 40 297 345 40 298 345 minecraft:honeycomb_block
setblock 40 297 349 minecraft:yellow_terracotta
fill 40 297 350 40 300 350 minecraft:honeycomb_block
setblock 40 297 353 minecraft:honeycomb_block
setblock 40 297 354 minecraft:yellow_terracotta
fill 40 297 355 40 300 355 minecraft:honeycomb_block
setblock 40 297 359 minecraft:yellow_terracotta
fill 40 297 360 40 300 360 minecraft:honeycomb_block
setblock 41 297 323 minecraft:yellow_terracotta
fill 41 297 324 41 300 324 minecraft:honeycomb_block
setblock 41 297 328 minecraft:yellow_terracotta
fill 41 297 329 41 300 329 minecraft:honeycomb_block
setblock 41 297 333 minecraft:yellow_terracotta
setblock 41 297 335 minecraft:honey_block
setblock 41 297 343 minecraft:yellow_terracotta
fill 41 297 344 41 299 344 minecraft:honeycomb_block
setblock 41 297 348 minecraft:yellow_terracotta
fill 41 297 349 41 300 349 minecraft:honeycomb_block
setblock 41 297 353 minecraft:yellow_terracotta
fill 41 297 354 41 300 354 minecraft:honeycomb_block
setblock 41 297 358 minecraft:yellow_terracotta
fill 41 297 359 41 300 359 minecraft:honeycomb_block
setblock 41 297 363 minecraft:yellow_terracotta
fill 0 298 342 0 308 342 minecraft:honeycomb_block
fill 0 298 352 0 308 352 minecraft:honeycomb_block
setblock 1 298 323 minecraft:honeycomb_block
setblock 1 298 327 minecraft:yellow_terracotta
fill 1 298 328 1 300 328 minecraft:honeycomb_block
setblock 1 298 332 minecraft:yellow_terracotta
fill 1 298 333 1 300 334 minecraft:honeycomb_block
setblock 1 298 342 minecraft:yellow_terracotta
fill 1 298 343 1 300 343 minecraft:honeycomb_block
setblock 1 298 347 minecraft:yellow_terracotta
fill 1 298 348 1 300 348 minecraft:honeycomb_block
setblock 1 298 352 minecraft:yellow_terracotta
fill 1 298 353 1 300 353 minecraft:honeycomb_block
setblock 1 298 357 minecraft:yellow_terracotta
fill 1 298 358 1 300 358 minecraft:honeycomb_block
setblock 1 298 362 minecraft:yellow_terracotta
fill 1 298 363 1 298 364 minecraft:honeycomb_block
fill 2 298 332 2 298 336 minecraft:honey_block
setblock 2 298 346 minecraft:yellow_terracotta
fill 2 298 347 2 300 347 minecraft:honeycomb_block
setblock 2 298 350 minecraft:honeycomb_block
setblock 2 298 351 minecraft:yellow_terracotta
fill 2 298 352 2 300 352 minecraft:honeycomb_block
setblock 2 298 356 minecraft:yellow_terracotta
fill 2 298 357 4 298 357 minecraft:honey_block
setblock 3 298 323 minecraft:honey_block
fill 3 298 331 3 298 332 minecraft:honey_block
fill 3 298 336 6 298 337 minecraft:honey_block
setblock 3 298 350 minecraft:yellow_terracotta
fill 3 298 351 3 300 351 minecraft:honeycomb_block
fill 3 298 353 4 298 353 minecraft:honey_block
fill 4 298 331 5 298 331 minecraft:honey_block
fill 6 298 332 6 299 332 minecraft:honey_block
fill 7 298 333 7 298 334 minecraft:honey_block
fill 11 298 323 14 298 323 minecraft:honeycomb_block
fill 12 298 324 13 298 324 minecraft:honeycomb_block
setblock 13 298 325 minecraft:yellow_terracotta
setblock 14 298 324 minecraft:yellow_terracotta
fill 14 298 325 14 300 325 minecraft:honeycomb_block
setblock 14 298 363 minecraft:honeycomb_block
setblock 15 298 323 minecraft:yellow_terracotta
fill 15 298 324 15 300 324 minecraft:honeycomb_block
fill 15 298 326 16 298 326 minecraft:honeycomb_block
setblock 15 298 363 minecraft:yellow_terracotta
fill 16 298 323 16 300 323 minecraft:honeycomb_block
fill 16 298 363 16 300 363 minecraft:honeycomb_block
setblock 17 298 326 minecraft:yellow_terracotta
setblock 18 298 325 minecraft:yellow_terracotta
fill 18 298 326 18 299 326 minecraft:honeycomb_block
setblock 19 298 323 minecraft:honeycomb_block
setblock 19 298 324 minecraft:yellow_terracotta
fill 19 298 325 19 300 325 minecraft:honeycomb_block
setblock 20 298 323 minecraft:yellow_terracotta
fill 20 298 324 23 298 324 minecraft:honeycomb_block
fill 21 298 323 24 298 323 minecraft:honeycomb_block
setblock 22 298 325 minecraft:honeycomb_block
setblock 24 298 324 minecraft:yellow_terracotta
setblock 25 298 323 minecraft:yellow_terracotta
fill 25 298 324 25 300 324 minecraft:honeycomb_block
fill 26 298 322 26 300 323 minecraft:honeycomb_block
setblock 29 298 324 minecraft:yellow_terracotta
fill 29 298 325 29 300 325 minecraft:honeycomb_block
setblock 29 298 363 minecraft:honeycomb_block
setblock 30 298 323 minecraft:yellow_terracotta
fill 30 298 324 30 300 324 minecraft:honeycomb_block
setblock 30 298 363 minecraft:yellow_terracotta
fill 31 298 323 31 300 323 minecraft:honeycomb_block
fill 31 298 363 31 300 363 minecraft:honeycomb_block
setblock 32 298 326 minecraft:yellow_terracotta
fill 32 298 362 32 300 362 minecraft:honeycomb_block
setblock 33 298 325 minecraft:yellow_terracotta
fill 33 298 326 33 300 326 minecraft:honeycomb_block
fill 33 298 346 34 298 348 minecraft:honey_block
setblock 34 298 324 minecraft:yellow_terracotta
fill 34 298 325 34 300 325 minecraft:honeycomb_block
setblock 34 298 345 minecraft:honey_block
fill 34 298 349 34 298 350 minecraft:honey_block
fill 34 298 355 36 298 355 minecraft:honey_block
fill 34 298 358 34 299 358 minecraft:honey_block
setblock 35 298 323 minecraft:yellow_terracotta
fill 35 298 324 35 300 324 minecraft:honeycomb_block
fill 35 298 344 38 298 344 minecraft:honey_block
setblock 35 298 363 minecraft:yellow_terracotta
fill 36 298 323 36 300 323 minecraft:honeycomb_block
setblock 36 298 326 minecraft:honeycomb_block
fill 36 298 351 37 298 351 minecraft:honey_block
setblock 36 298 361 minecraft:honeycomb_block
setblock 36 298 362 minecraft:yellow_terracotta
fill 36 298 363 36 300 363 minecraft:honeycomb_block
setblock 37 298 326 minecraft:yellow_terracotta
setblock 37 298 361 minecraft:yellow_terracotta
fill 37 298 362 37 300 362 minecraft:honeycomb_block
setblock 38 298 325 minecraft:yellow_terracotta
fill 38 298 351 38 300 352 minecraft:honeycomb_block
setblock 39 298 324 minecraft:yellow_terracotta
fill 39 298 325 39 299 325 minecraft:honeycomb_block
setblock 39 298 329 minecraft:yellow_terracotta
setblock 39 298 330 minecraft:honeycomb_block
setblock 39 298 349 minecraft:yellow_terracotta
fill 39 298 350 39 300 350 minecraft:honeycomb_block
setblock 39 298 354 minecraft:yellow_terracotta
fill 39 298 355 39 299 357 minecraft:honeycomb_block
setblock 40 298 323 minecraft:yellow_terracotta
fill 40 298 324 40 299 324 minecraft:honeycomb_block
setblock 40 298 328 minecraft:yellow_terracotta
fill 40 298 329 40 300 329 minecraft:honeycomb_block
setblock 40 298 348 minecraft:yellow_terracotta
fill 40 298 349 40 300 349 minecraft:honeycomb_block
setblock 40 298 353 minecraft:yellow_terracotta
fill 40 298 354 40 300 354 minecraft:honeycomb_block
setblock 40 298 357 minecraft:honeycomb_block
setblock 40 298 358 minecraft:yellow_terracotta
fill 40 298 359 40 300 359 minecraft:honeycomb_block
setblock 40 298 363 minecraft:yellow_terracotta
fill 41 298 323 41 300 323 minecraft:honeycomb_block
setblock 41 298 327 minecraft:yellow_terracotta
fill 41 298 328 41 300 328 minecraft:honeycomb_block
setblock 41 298 332 minecraft:yellow_terracotta
fill 41 298 333 41 300 333 minecraft:honeycomb_block
setblock 41 298 347 minecraft:yellow_terracotta
fill 41 298 348 41 300 348 minecraft:honeycomb_block
setblock 41 298 352 minecraft:yellow_terracotta
fill 41 298 353 41 300 353 minecraft:honeycomb_block
setblock 41 298 357 minecraft:yellow_terracotta
fill 41 298 358 41 300 358 minecraft:honeycomb_block
setblock 41 298 362 minecraft:yellow_terracotta
fill 41 298 363 41 300 363 minecraft:honeycomb_block
fill 0 299 339 0 308 339 minecraft:honeycomb_block
setblock 0 299 343 minecraft:yellow_concrete
setblock 1 299 326 minecraft:yellow_terracotta
fill 1 299 327 1 300 327 minecraft:honeycomb_block
setblock 1 299 330 minecraft:honeycomb_block
setblock 1 299 331 minecraft:yellow_terracotta
fill 1 299 332 1 300 332 minecraft:honeycomb_block
setblock 1 299 335 minecraft:honeycomb_block
setblock 1 299 338 minecraft:honey_block
setblock 1 299 341 minecraft:yellow_terracotta
fill 1 299 342 1 300 342 minecraft:honeycomb_block
setblock 1 299 346 minecraft:yellow_terracotta
fill 1 299 347 1 300 347 minecraft:honeycomb_block
setblock 1 299 350 minecraft:honeycomb_block
setblock 1 299 351 minecraft:yellow_terracotta
fill 1 299 352 1 300 352 minecraft:honeycomb_block
setblock 1 299 355 minecraft:honeycomb_block
setblock 1 299 356 minecraft:yellow_terracotta
fill 1 299 357 1 300 357 minecraft:honeycomb_block
setblock 1 299 363 minecraft:honey_block
fill 1 299 364 1 308 364 minecraft:honeycomb_block
fill 2 299 333 2 299 335 minecraft:honey_block
setblock 2 299 345 minecraft:yellow_terracotta
fill 2 299 346 2 300 346 minecraft:honeycomb_block
setblock 2 299 350 minecraft:yellow_terracotta
fill 2 299 351 2 300 351 minecraft:honeycomb_block
setblock 2 299 355 minecraft:yellow_terracotta
fill 2 299 356 2 300 356 minecraft:honeycomb_block
setblock 3 299 332 minecraft:honey_block
fill 3 299 336 6 299 336 minecraft:honey_block
setblock 3 299 349 minecraft:yellow_terracotta
fill 3 299 350 3 300 350 minecraft:honeycomb_block
setblock 3 299 353 minecraft:honeycomb_block
fill 4 299 337 5 299 337 minecraft:honey_block
setblock 5 299 355 minecraft:honey_block
setblock 6 299 335 minecraft:honey_block
fill 10 299 323 13 299 323 minecraft:honeycomb_block
setblock 12 299 324 minecraft:honeycomb_block
setblock 13 299 324 minecraft:yellow_terracotta
fill 13 299 325 13 300 325 minecraft:honeycomb_block
setblock 14 299 323 minecraft:yellow_terracotta
fill 14 299 324 14 300 324 minecraft:honeycomb_block
setblock 14 299 363 minecraft:yellow_terracotta
fill 15 299 323 15 300 323 minecraft:honeycomb_block
setblock 15 299 326 minecraft:honeycomb_block
fill 15 299 363 15 300 363 minecraft:honeycomb_block
setblock 16 299 326 minecraft:yellow_terracotta
setblock 17 299 325 minecraft:yellow_terracotta
fill 17 299 326 17 300 326 minecraft:honeycomb_block
setblock 18 299 324 minecraft:yellow_terracotta
fill 18 299 325 18 300 325 minecraft:honeycomb_block
setblock 19 299 323 minecraft:yellow_terracotta
fill 19 299 324 22 299 324 minecraft:honeycomb_block
fill 20 299 323 23 299 323 minecraft:honeycomb_block
setblock 20 299 363 minecraft:honey_block
setblock 23 299 324 minecraft:yellow_terracotta
setblock 24 299 323 minecraft:yellow_terracotta
fill 24 299 324 24 300 324 minecraft:honeycomb_block
fill 25 299 323 25 300 323 minecraft:honeycomb_block
setblock 28 299 324 minecraft:yellow_terracotta
setblock 29 299 323 minecraft:yellow_terracotta
fill 29 299 324 29 300 324 minecraft:honeycomb_block
setblock 29 299 363 minecraft:yellow_terracotta
fill 30 299 323 30 300 323 minecraft:honeycomb_block
fill 30 299 363 30 300 363 minecraft:honeycomb_block
fill 31 299 338 34 300 339 minecraft:flowering_azalea_leaves[persistent=true]
setblock 32 299 325 minecraft:yellow_terracotta
fill 32 299 326 32 300 326 minecraft:honeycomb_block
fill 32 299 337 34 300 337 minecraft:flowering_azalea_leaves[persistent=true]
fill 32 299 340 33 300 340 minecraft:flowering_azalea_leaves[persistent=true]
setblock 33 299 324 minecraft:yellow_terracotta
fill 33 299 325 33 300 325 minecraft:honeycomb_block
setblock 34 299 323 minecraft:yellow_terracotta
fill 34 299 324 34 300 324 minecraft:honeycomb_block
fill 34 299 346 34 299 349 minecraft:honey_block
setblock 34 299 363 minecraft:yellow_terracotta
fill 35 299 323 35 300 323 minecraft:honeycomb_block
setblock 35 299 355 minecraft:honey_block
setblock 35 299 361 minecraft:honeycomb_block
setblock 35 299 362 minecraft:yellow_terracotta
fill 35 299 363 35 300 363 minecraft:honeycomb_block
setblock 36 299 326 minecraft:yellow_terracotta
fill 36 299 350 37 299 350 minecraft:honey_block
setblock 36 299 361 minecraft:yellow_terracotta
fill 36 299 362 36 300 362 minecraft:honeycomb_block
setblock 37 299 325 minecraft:yellow_terracotta
fill 37 299 361 37 300 361 minecraft:honeycomb_block
setblock 38 299 324 minecraft:yellow_terracotta
fill 38 299 325 38 300 325 minecraft:honeycomb_block
setblock 38 299 345 minecraft:honey_block
setblock 38 299 350 minecraft:honeycomb_block
setblock 38 299 353 minecraft:honeycomb_block
setblock 38 299 354 minecraft:yellow_terracotta
setblock 39 299 323 minecraft:yellow_terracotta
fill 39 299 324 39 300 324 minecraft:honeycomb_block
setblock 39 299 328 minecraft:yellow_terracotta
setblock 39 299 329 minecraft:honeycomb_block
setblock 39 299 347 minecraft:honey_block
setblock 39 299 348 minecraft:yellow_terracotta
fill 39 299 349 39 300 349 minecraft:honeycomb_block
setblock 39 299 352 minecraft:honeycomb_block
setblock 39 299 353 minecraft:yellow_terracotta
fill 39 299 354 39 300 354 minecraft:honeycomb_block
setblock 39 299 358 minecraft:yellow_terracotta
setblock 39 299 363 minecraft:yellow_terracotta
fill 40 299 323 40 300 323 minecraft:honeycomb_block
setblock 40 299 327 minecraft:yellow_terracotta
fill 40 299 328 40 300 328 minecraft:honeycomb_block
setblock 40 299 332 minecraft:yellow_terracotta
setblock 40 299 347 minecraft:yellow_terracotta
fill 40 299 348 40 300 348 minecraft:honeycomb_block
setblock 40 299 352 minecraft:yellow_terracotta
fill 40 299 353 40 300 353 minecraft:honeycomb_block
setblock 40 299 357 minecraft:yellow_terracotta
fill 40 299 358 40 300 358 minecraft:honeycomb_block
setblock 40 299 362 minecraft:yellow_terracotta
fill 40 299 363 40 300 363 minecraft:honeycomb_block
setblock 41 299 326 minecraft:yellow_terracotta
fill 41 299 327 41 300 327 minecraft:honeycomb_block
setblock 41 299 331 minecraft:yellow_terracotta
fill 41 299 332 41 300 332 minecraft:honeycomb_block
setblock 41 299 346 minecraft:yellow_terracotta
fill 41 299 347 41 300 347 minecraft:honeycomb_block
setblock 41 299 351 minecraft:yellow_terracotta
fill 41 299 352 41 300 352 minecraft:honeycomb_block
setblock 41 299 356 minecraft:yellow_terracotta
fill 41 299 357 41 300 357 minecraft:honeycomb_block
setblock 41 299 361 minecraft:yellow_terracotta
fill 41 299 362 41 300 362 minecraft:honeycomb_block
fill 0 300 343 0 308 343 minecraft:honeycomb_block
setblock 0 300 351 minecraft:orange_terracotta
setblock 1 300 325 minecraft:honey_block
setblock 1 300 326 minecraft:honeycomb_block
setblock 1 300 330 minecraft:yellow_terracotta
setblock 1 300 331 minecraft:honeycomb_block
setblock 1 300 335 minecraft:yellow_terracotta
setblock 1 300 336 minecraft:honeycomb_block
setblock 1 300 345 minecraft:yellow_terracotta
setblock 1 300 346 minecraft:honeycomb_block
setblock 1 300 350 minecraft:yellow_terracotta
setblock 1 300 351 minecraft:honeycomb_block
setblock 1 300 355 minecraft:yellow_terracotta
setblock 1 300 356 minecraft:honeycomb_block
setblock 1 300 360 minecraft:yellow_terracotta
setblock 2 300 345 minecraft:honeycomb_block
setblock 2 300 349 minecraft:yellow_terracotta
setblock 2 300 350 minecraft:honeycomb_block
setblock 2 300 354 minecraft:yellow_terracotta
setblock 2 300 355 minecraft:honeycomb_block
fill 3 300 336 5 300 336 minecraft:yellow_terracotta
setblock 3 300 349 minecraft:honeycomb_block
setblock 3 300 353 minecraft:yellow_terracotta
setblock 7 300 363 minecraft:honey_block
fill 10 300 323 12 300 323 minecraft:honeycomb_block
setblock 11 300 324 minecraft:honeycomb_block
setblock 12 300 324 minecraft:yellow_terracotta
setblock 13 300 323 minecraft:yellow_terracotta
setblock 13 300 324 minecraft:honeycomb_block
setblock 14 300 323 minecraft:honeycomb_block
setblock 14 300 363 minecraft:honeycomb_block
setblock 15 300 326 minecraft:yellow_terracotta
setblock 16 300 325 minecraft:yellow_terracotta
setblock 16 300 326 minecraft:honeycomb_block
setblock 17 300 324 minecraft:yellow_terracotta
setblock 17 300 325 minecraft:honeycomb_block
fill 18 300 322 18 308 322 minecraft:honeycomb_block
setblock 18 300 323 minecraft:yellow_terracotta
fill 18 300 324 21 300 324 minecraft:honeycomb_block
fill 19 300 323 22 300 323 minecraft:honeycomb_block
setblock 22 300 324 minecraft:yellow_terracotta
setblock 23 300 323 minecraft:yellow_terracotta
setblock 23 300 324 minecraft:honeycomb_block
setblock 24 300 322 minecraft:yellow_concrete
setblock 24 300 323 minecraft:honeycomb_block
setblock 26 300 363 minecraft:honey_block
setblock 27 300 324 minecraft:yellow_terracotta
setblock 28 300 323 minecraft:yellow_terracotta
setblock 28 300 324 minecraft:honeycomb_block
setblock 29 300 323 minecraft:honeycomb_block
setblock 29 300 363 minecraft:honeycomb_block
setblock 31 300 325 minecraft:yellow_terracotta
setblock 31 300 337 minecraft:flowering_azalea_leaves[persistent=true]
setblock 31 300 362 minecraft:honeycomb_block
setblock 32 300 324 minecraft:yellow_terracotta
setblock 32 300 325 minecraft:honeycomb_block
setblock 33 300 323 minecraft:yellow_terracotta
setblock 33 300 324 minecraft:honeycomb_block
setblock 33 300 336 minecraft:flowering_azalea_leaves[persistent=true]
setblock 33 300 363 minecraft:yellow_terracotta
setblock 34 300 323 minecraft:honeycomb_block
setblock 34 300 340 minecraft:flowering_azalea_leaves[persistent=true]
setblock 34 300 361 minecraft:honeycomb_block
setblock 34 300 362 minecraft:yellow_terracotta
setblock 34 300 363 minecraft:honeycomb_block
setblock 35 300 326 minecraft:yellow_terracotta
fill 35 300 338 35 300 339 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 300 361 minecraft:yellow_terracotta
setblock 35 300 362 minecraft:honeycomb_block
setblock 36 300 325 minecraft:yellow_terracotta
setblock 36 300 361 minecraft:honeycomb_block
setblock 37 300 324 minecraft:yellow_terracotta
setblock 37 300 325 minecraft:honeycomb_block
setblock 38 300 323 minecraft:yellow_terracotta
setblock 38 300 324 minecraft:honeycomb_block
setblock 38 300 353 minecraft:yellow_terracotta
fill 38 300 354 38 300 355 minecraft:honeycomb_block
setblock 38 300 363 minecraft:yellow_terracotta
setblock 39 300 323 minecraft:honeycomb_block
setblock 39 300 348 minecraft:honeycomb_block
setblock 39 300 352 minecraft:yellow_terracotta
setblock 39 300 353 minecraft:honeycomb_block
fill 39 300 355 39 300 356 minecraft:honeycomb_block
setblock 39 300 357 minecraft:yellow_terracotta
setblock 39 300 358 minecraft:honeycomb_block
setblock 39 300 362 minecraft:yellow_terracotta
setblock 39 300 363 minecraft:honeycomb_block
setblock 40 300 326 minecraft:yellow_terracotta
setblock 40 300 327 minecraft:honeycomb_block
setblock 40 300 330 minecraft:honeycomb_block
setblock 40 300 331 minecraft:yellow_terracotta
setblock 40 300 347 minecraft:honeycomb_block
setblock 40 300 351 minecraft:yellow_terracotta
setblock 40 300 352 minecraft:honeycomb_block
setblock 40 300 356 minecraft:yellow_terracotta
setblock 40 300 357 minecraft:honeycomb_block
setblock 40 300 361 minecraft:yellow_terracotta
setblock 40 300 362 minecraft:honeycomb_block
setblock 41 300 325 minecraft:yellow_terracotta
setblock 41 300 326 minecraft:honeycomb_block
setblock 41 300 330 minecraft:yellow_terracotta
setblock 41 300 331 minecraft:honeycomb_block
setblock 41 300 334 minecraft:honeycomb_block
setblock 41 300 342 minecraft:honey_block
setblock 41 300 345 minecraft:yellow_terracotta
setblock 41 300 346 minecraft:honeycomb_block
setblock 41 300 350 minecraft:yellow_terracotta
setblock 41 300 351 minecraft:honeycomb_block
setblock 41 300 355 minecraft:yellow_terracotta
setblock 41 300 356 minecraft:honeycomb_block
fill 41 300 360 42 300 360 minecraft:yellow_terracotta
setblock 41 300 361 minecraft:honeycomb_block
setblock 42 300 336 minecraft:yellow_concrete
setblock 0 301 336 minecraft:orange_terracotta
fill 0 301 351 0 308 351 minecraft:honeycomb_block
fill 24 301 322 24 308 322 minecraft:honeycomb_block
fill 26 301 322 26 308 322 minecraft:honeycomb_block
setblock 42 301 334 minecraft:orange_terracotta
setblock 42 301 336 minecraft:yellow_terracotta
setblock 42 301 344 minecraft:orange_terracotta
fill 42 301 360 42 308 360 minecraft:honeycomb_block
fill 0 302 336 0 308 336 minecraft:honeycomb_block
setblock 2 302 322 minecraft:yellow_terracotta
setblock 3 302 325 minecraft:light[level=12]
setblock 3 302 332 minecraft:light[level=12]
setblock 3 302 339 minecraft:light[level=12]
setblock 3 302 346 minecraft:light[level=12]
setblock 3 302 353 minecraft:light[level=12]
setblock 3 302 360 minecraft:light[level=12]
setblock 10 302 325 minecraft:light[level=12]
setblock 10 302 332 minecraft:light[level=12]
setblock 10 302 339 minecraft:light[level=12]
setblock 10 302 346 minecraft:light[level=12]
setblock 10 302 353 minecraft:light[level=12]
setblock 10 302 360 minecraft:light[level=12]
setblock 17 302 325 minecraft:light[level=12]
setblock 17 302 332 minecraft:light[level=12]
setblock 17 302 339 minecraft:light[level=12]
setblock 17 302 346 minecraft:light[level=12]
setblock 17 302 353 minecraft:light[level=12]
setblock 17 302 360 minecraft:light[level=12]
setblock 24 302 325 minecraft:light[level=12]
setblock 24 302 332 minecraft:light[level=12]
setblock 24 302 339 minecraft:light[level=12]
setblock 24 302 346 minecraft:light[level=12]
setblock 24 302 353 minecraft:light[level=12]
setblock 24 302 360 minecraft:light[level=12]
setblock 31 302 325 minecraft:light[level=12]
setblock 31 302 332 minecraft:light[level=12]
setblock 31 302 339 minecraft:light[level=12]
setblock 31 302 346 minecraft:light[level=12]
setblock 31 302 353 minecraft:light[level=12]
setblock 31 302 360 minecraft:light[level=12]
setblock 38 302 325 minecraft:light[level=12]
setblock 38 302 332 minecraft:light[level=12]
setblock 38 302 339 minecraft:light[level=12]
setblock 38 302 346 minecraft:light[level=12]
setblock 38 302 353 minecraft:light[level=12]
setblock 38 302 360 minecraft:light[level=12]
fill 42 302 334 42 308 334 minecraft:honeycomb_block
fill 42 302 336 42 308 336 minecraft:honeycomb_block
fill 42 302 344 42 308 344 minecraft:honeycomb_block
fill 2 303 322 2 308 322 minecraft:honeycomb_block
setblock 38 303 364 minecraft:orange_terracotta
setblock 42 303 335 minecraft:yellow_terracotta
fill 0 304 325 0 308 325 minecraft:honeycomb_block
setblock 0 304 326 minecraft:orange_terracotta
fill 0 304 327 0 308 327 minecraft:honeycomb_block
setblock 0 304 329 minecraft:yellow_terracotta
fill 34 304 322 35 304 322 minecraft:yellow_concrete
fill 38 304 364 38 308 364 minecraft:honeycomb_block
fill 42 304 335 42 308 335 minecraft:honeycomb_block
fill 0 305 326 0 308 326 minecraft:honeycomb_block
fill 0 305 329 0 308 329 minecraft:honeycomb_block
setblock 10 305 322 minecraft:orange_terracotta
fill 34 305 322 35 307 322 minecraft:honeycomb_block
setblock 0 306 347 minecraft:yellow_concrete
fill 10 306 322 10 308 322 minecraft:honeycomb_block
setblock 14 306 322 minecraft:orange_terracotta
fill 0 307 347 0 308 347 minecraft:honeycomb_block
fill 14 307 322 14 308 322 minecraft:honeycomb_block
setblock 39 307 364 minecraft:yellow_terracotta
setblock 0 308 362 minecraft:orange_terracotta
setblock 34 308 322 minecraft:honeycomb_block
setblock 35 308 322 minecraft:yellow_concrete
setblock 39 308 364 minecraft:honeycomb_block
