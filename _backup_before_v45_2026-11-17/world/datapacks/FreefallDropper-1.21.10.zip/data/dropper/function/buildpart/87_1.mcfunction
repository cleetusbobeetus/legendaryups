setblock 162 27 410 minecraft:white_concrete
setblock 166 27 370 minecraft:white_concrete
setblock 168 27 372 minecraft:light[level=14]
setblock 168 27 380 minecraft:light[level=14]
setblock 168 27 388 minecraft:light[level=14]
setblock 168 27 396 minecraft:light[level=14]
setblock 168 27 404 minecraft:light[level=14]
setblock 169 27 410 minecraft:white_concrete
setblock 173 27 370 minecraft:white_concrete
setblock 176 27 372 minecraft:light[level=14]
setblock 176 27 380 minecraft:light[level=14]
setblock 176 27 388 minecraft:light[level=14]
setblock 176 27 396 minecraft:light[level=14]
setblock 176 27 404 minecraft:light[level=14]
setblock 176 27 410 minecraft:white_concrete
setblock 180 27 370 minecraft:white_concrete
setblock 182 27 375 minecraft:white_concrete
setblock 182 27 382 minecraft:white_concrete
setblock 182 27 389 minecraft:white_concrete
setblock 182 27 396 minecraft:white_concrete
setblock 182 27 403 minecraft:white_concrete
fill 151 28 389 151 29 389 minecraft:purple_wool
fill 142 29 376 142 30 376 minecraft:white_concrete
fill 142 29 383 142 30 383 minecraft:white_concrete
fill 142 29 390 142 30 390 minecraft:white_concrete
fill 142 29 397 142 30 397 minecraft:white_concrete
fill 142 29 404 142 30 404 minecraft:white_concrete
fill 143 29 370 143 30 370 minecraft:white_concrete
fill 143 29 410 143 30 410 minecraft:white_concrete
fill 150 29 370 150 30 370 minecraft:white_concrete
fill 150 29 410 150 30 410 minecraft:white_concrete
fill 157 29 370 157 30 370 minecraft:white_concrete
fill 157 29 410 157 30 410 minecraft:white_concrete
fill 164 29 370 164 30 370 minecraft:white_concrete
fill 164 29 410 164 30 410 minecraft:white_concrete
fill 171 29 370 171 30 370 minecraft:white_concrete
fill 171 29 410 171 30 410 minecraft:white_concrete
fill 178 29 370 178 30 370 minecraft:white_concrete
fill 178 29 410 178 30 410 minecraft:white_concrete
fill 182 29 373 182 30 373 minecraft:white_concrete
fill 182 29 380 182 30 380 minecraft:white_concrete
fill 182 29 387 182 30 387 minecraft:white_concrete
fill 182 29 394 182 30 394 minecraft:white_concrete
fill 182 29 401 182 30 401 minecraft:white_concrete
fill 182 29 408 182 30 408 minecraft:white_concrete
fill 142 30 370 142 30 374 minecraft:white_concrete
fill 142 30 377 142 30 381 minecraft:white_concrete
fill 142 30 384 142 30 388 minecraft:white_concrete
fill 142 30 391 142 30 395 minecraft:white_concrete
fill 142 30 398 142 30 402 minecraft:white_concrete
fill 142 30 405 142 30 409 minecraft:white_concrete
fill 144 30 410 148 30 410 minecraft:white_concrete
fill 145 30 370 149 30 370 minecraft:white_concrete
fill 151 30 410 155 30 410 minecraft:white_concrete
fill 152 30 370 156 30 370 minecraft:white_concrete
fill 158 30 410 162 30 410 minecraft:white_concrete
fill 159 30 370 163 30 370 minecraft:white_concrete
fill 165 30 410 169 30 410 minecraft:white_concrete
fill 166 30 370 170 30 370 minecraft:white_concrete
fill 172 30 410 176 30 410 minecraft:white_concrete
fill 173 30 370 177 30 370 minecraft:white_concrete
fill 179 30 410 182 30 410 minecraft:white_concrete
fill 180 30 370 182 30 370 minecraft:white_concrete
fill 182 30 371 182 30 372 minecraft:white_concrete
fill 182 30 375 182 30 379 minecraft:white_concrete
fill 182 30 382 182 30 386 minecraft:white_concrete
fill 182 30 389 182 30 393 minecraft:white_concrete
fill 182 30 396 182 30 400 minecraft:white_concrete
fill 182 30 403 182 30 407 minecraft:white_concrete
setblock 142 31 371 minecraft:white_concrete
setblock 142 31 378 minecraft:white_concrete
setblock 142 31 385 minecraft:white_concrete
setblock 142 31 392 minecraft:white_concrete
setblock 142 31 399 minecraft:white_concrete
setblock 142 31 406 minecraft:white_concrete
setblock 145 31 410 minecraft:white_concrete
setblock 148 31 370 minecraft:white_concrete
setblock 152 31 410 minecraft:white_concrete
setblock 155 31 370 minecraft:white_concrete
setblock 159 31 410 minecraft:white_concrete
setblock 162 31 370 minecraft:white_concrete
setblock 166 31 410 minecraft:white_concrete
setblock 169 31 370 minecraft:white_concrete
setblock 173 31 410 minecraft:white_concrete
setblock 176 31 370 minecraft:white_concrete
setblock 180 31 410 minecraft:white_concrete
setblock 182 31 371 minecraft:white_concrete
setblock 182 31 378 minecraft:white_concrete
setblock 182 31 385 minecraft:white_concrete
setblock 182 31 392 minecraft:white_concrete
setblock 182 31 399 minecraft:white_concrete
setblock 182 31 406 minecraft:white_concrete
setblock 142 32 372 minecraft:white_concrete
setblock 142 32 379 minecraft:white_concrete
setblock 142 32 386 minecraft:white_concrete
setblock 142 32 393 minecraft:white_concrete
setblock 142 32 400 minecraft:white_concrete
setblock 142 32 407 minecraft:white_concrete
setblock 146 32 410 minecraft:white_concrete
setblock 147 32 370 minecraft:white_concrete
setblock 153 32 410 minecraft:white_concrete
setblock 154 32 370 minecraft:white_concrete
setblock 160 32 410 minecraft:white_concrete
setblock 161 32 370 minecraft:white_concrete
setblock 167 32 410 minecraft:white_concrete
setblock 168 32 370 minecraft:white_concrete
setblock 174 32 410 minecraft:white_concrete
setblock 175 32 370 minecraft:white_concrete
setblock 181 32 410 minecraft:white_concrete
setblock 182 32 370 minecraft:white_concrete
setblock 182 32 377 minecraft:white_concrete
setblock 182 32 384 minecraft:white_concrete
setblock 182 32 391 minecraft:white_concrete
setblock 182 32 398 minecraft:white_concrete
setblock 182 32 405 minecraft:white_concrete
setblock 142 33 373 minecraft:white_concrete
setblock 142 33 380 minecraft:white_concrete
setblock 142 33 387 minecraft:white_concrete
setblock 142 33 394 minecraft:white_concrete
setblock 142 33 401 minecraft:white_concrete
setblock 142 33 408 minecraft:white_concrete
setblock 146 33 370 minecraft:white_concrete
setblock 147 33 410 minecraft:white_concrete
setblock 153 33 370 minecraft:white_concrete
setblock 154 33 410 minecraft:white_concrete
setblock 160 33 370 minecraft:white_concrete
setblock 161 33 410 minecraft:white_concrete
setblock 167 33 370 minecraft:white_concrete
setblock 168 33 410 minecraft:white_concrete
setblock 174 33 370 minecraft:white_concrete
setblock 175 33 410 minecraft:white_concrete
setblock 181 33 370 minecraft:white_concrete
setblock 182 33 376 minecraft:white_concrete
setblock 182 33 383 minecraft:white_concrete
setblock 182 33 390 minecraft:white_concrete
setblock 182 33 397 minecraft:white_concrete
setblock 182 33 404 minecraft:white_concrete
setblock 182 33 410 minecraft:white_concrete
setblock 142 34 374 minecraft:white_concrete
setblock 142 34 381 minecraft:white_concrete
setblock 142 34 388 minecraft:white_concrete
setblock 142 34 395 minecraft:white_concrete
setblock 142 34 402 minecraft:white_concrete
setblock 142 34 409 minecraft:white_concrete
setblock 145 34 370 minecraft:white_concrete
setblock 148 34 410 minecraft:white_concrete
setblock 152 34 370 minecraft:white_concrete
setblock 155 34 410 minecraft:white_concrete
setblock 159 34 370 minecraft:white_concrete
setblock 162 34 410 minecraft:white_concrete
setblock 166 34 370 minecraft:white_concrete
fill 168 34 398 169 35 398 minecraft:red_wool
setblock 169 34 410 minecraft:white_concrete
setblock 173 34 370 minecraft:white_concrete
setblock 176 34 410 minecraft:white_concrete
setblock 180 34 370 minecraft:white_concrete
setblock 182 34 375 minecraft:white_concrete
setblock 182 34 382 minecraft:white_concrete
setblock 182 34 389 minecraft:white_concrete
setblock 182 34 396 minecraft:white_concrete
setblock 182 34 403 minecraft:white_concrete
setblock 144 35 372 minecraft:light[level=14]
setblock 144 35 380 minecraft:light[level=14]
setblock 144 35 388 minecraft:light[level=14]
setblock 144 35 396 minecraft:light[level=14]
setblock 144 35 404 minecraft:light[level=14]
setblock 152 35 372 minecraft:light[level=14]
setblock 152 35 380 minecraft:light[level=14]
setblock 152 35 388 minecraft:light[level=14]
setblock 152 35 396 minecraft:light[level=14]
setblock 152 35 404 minecraft:light[level=14]
setblock 160 35 372 minecraft:light[level=14]
setblock 160 35 380 minecraft:light[level=14]
setblock 160 35 388 minecraft:light[level=14]
setblock 160 35 396 minecraft:light[level=14]
setblock 160 35 404 minecraft:light[level=14]
setblock 168 35 372 minecraft:light[level=14]
setblock 168 35 380 minecraft:light[level=14]
setblock 168 35 388 minecraft:light[level=14]
setblock 168 35 396 minecraft:light[level=14]
setblock 168 35 404 minecraft:light[level=14]
setblock 176 35 372 minecraft:light[level=14]
setblock 176 35 380 minecraft:light[level=14]
setblock 176 35 388 minecraft:light[level=14]
setblock 176 35 396 minecraft:light[level=14]
setblock 176 35 404 minecraft:light[level=14]
setblock 142 36 376 minecraft:white_concrete
setblock 142 36 383 minecraft:white_concrete
setblock 142 36 390 minecraft:white_concrete
setblock 142 36 397 minecraft:white_concrete
setblock 142 36 404 minecraft:white_concrete
setblock 143 36 370 minecraft:white_concrete
setblock 143 36 410 minecraft:white_concrete
setblock 150 36 370 minecraft:white_concrete
setblock 150 36 410 minecraft:white_concrete
setblock 157 36 370 minecraft:white_concrete
setblock 157 36 410 minecraft:white_concrete
setblock 164 36 370 minecraft:white_concrete
setblock 164 36 410 minecraft:white_concrete
setblock 171 36 370 minecraft:white_concrete
setblock 171 36 410 minecraft:white_concrete
setblock 178 36 370 minecraft:white_concrete
setblock 178 36 410 minecraft:white_concrete
setblock 182 36 373 minecraft:white_concrete
setblock 182 36 380 minecraft:white_concrete
setblock 182 36 387 minecraft:white_concrete
setblock 182 36 394 minecraft:white_concrete
setblock 182 36 401 minecraft:white_concrete
setblock 182 36 408 minecraft:white_concrete
setblock 142 37 370 minecraft:white_concrete
setblock 142 37 377 minecraft:white_concrete
setblock 142 37 384 minecraft:white_concrete
setblock 142 37 391 minecraft:white_concrete
setblock 142 37 398 minecraft:white_concrete
setblock 142 37 405 minecraft:white_concrete
setblock 144 37 410 minecraft:white_concrete
setblock 149 37 370 minecraft:white_concrete
setblock 151 37 410 minecraft:white_concrete
setblock 156 37 370 minecraft:white_concrete
setblock 158 37 410 minecraft:white_concrete
setblock 163 37 370 minecraft:white_concrete
setblock 165 37 410 minecraft:white_concrete
setblock 170 37 370 minecraft:white_concrete
setblock 172 37 410 minecraft:white_concrete
setblock 177 37 370 minecraft:white_concrete
setblock 179 37 410 minecraft:white_concrete
fill 180 37 381 180 47 381 minecraft:purple_wool
setblock 182 37 372 minecraft:white_concrete
setblock 182 37 379 minecraft:white_concrete
setblock 182 37 386 minecraft:white_concrete
setblock 182 37 393 minecraft:white_concrete
setblock 182 37 400 minecraft:white_concrete
setblock 182 37 407 minecraft:white_concrete
setblock 142 38 371 minecraft:white_concrete
setblock 142 38 378 minecraft:white_concrete
setblock 142 38 385 minecraft:white_concrete
setblock 142 38 392 minecraft:white_concrete
setblock 142 38 399 minecraft:white_concrete
setblock 142 38 406 minecraft:white_concrete
setblock 145 38 410 minecraft:white_concrete
setblock 148 38 370 minecraft:white_concrete
setblock 152 38 410 minecraft:white_concrete
setblock 155 38 370 minecraft:white_concrete
setblock 159 38 410 minecraft:white_concrete
setblock 162 38 370 minecraft:white_concrete
setblock 166 38 410 minecraft:white_concrete
setblock 169 38 370 minecraft:white_concrete
setblock 173 38 410 minecraft:white_concrete
setblock 176 38 370 minecraft:white_concrete
fill 180 38 379 180 47 380 minecraft:purple_wool
fill 180 38 382 180 47 383 minecraft:purple_wool
setblock 180 38 410 minecraft:white_concrete
setblock 182 38 371 minecraft:white_concrete
setblock 182 38 378 minecraft:white_concrete
setblock 182 38 385 minecraft:white_concrete
setblock 182 38 392 minecraft:white_concrete
setblock 182 38 399 minecraft:white_concrete
setblock 182 38 406 minecraft:white_concrete
fill 142 39 372 142 40 372 minecraft:white_concrete
fill 142 39 379 142 40 379 minecraft:white_concrete
fill 142 39 386 142 40 386 minecraft:white_concrete
fill 142 39 393 142 40 393 minecraft:white_concrete
fill 142 39 400 142 40 400 minecraft:white_concrete
fill 142 39 407 142 40 407 minecraft:white_concrete
fill 146 39 410 146 40 410 minecraft:white_concrete
fill 147 39 370 147 40 370 minecraft:white_concrete
fill 153 39 410 153 40 410 minecraft:white_concrete
fill 154 39 370 154 40 370 minecraft:white_concrete
fill 160 39 410 160 40 410 minecraft:white_concrete
fill 161 39 370 161 40 370 minecraft:white_concrete
fill 167 39 410 167 40 410 minecraft:white_concrete
fill 168 39 370 168 40 370 minecraft:white_concrete
fill 174 39 410 174 40 410 minecraft:white_concrete
fill 175 39 370 175 40 370 minecraft:white_concrete
fill 181 39 410 181 40 410 minecraft:white_concrete
fill 182 39 370 182 40 370 minecraft:white_concrete
fill 182 39 377 182 40 377 minecraft:white_concrete
fill 182 39 384 182 40 384 minecraft:white_concrete
fill 182 39 391 182 40 391 minecraft:white_concrete
fill 182 39 398 182 40 398 minecraft:white_concrete
fill 182 39 405 182 40 405 minecraft:white_concrete
fill 142 40 370 142 40 371 minecraft:white_concrete
fill 142 40 373 142 40 374 minecraft:white_concrete
fill 142 40 376 142 40 378 minecraft:white_concrete
fill 142 40 380 142 40 381 minecraft:white_concrete
fill 142 40 383 142 40 385 minecraft:white_concrete
fill 142 40 387 142 40 388 minecraft:white_concrete
fill 142 40 390 142 40 392 minecraft:white_concrete
fill 142 40 394 142 40 395 minecraft:white_concrete
fill 142 40 397 142 40 399 minecraft:white_concrete
fill 142 40 401 142 40 402 minecraft:white_concrete
fill 142 40 404 142 40 406 minecraft:white_concrete
fill 142 40 408 142 40 409 minecraft:white_concrete
setblock 143 40 370 minecraft:white_concrete
fill 143 40 410 145 40 410 minecraft:white_concrete
fill 145 40 370 146 40 370 minecraft:white_concrete
fill 147 40 410 148 40 410 minecraft:white_concrete
fill 148 40 370 150 40 370 minecraft:white_concrete
fill 150 40 410 152 40 410 minecraft:white_concrete
fill 152 40 370 153 40 370 minecraft:white_concrete
fill 154 40 410 155 40 410 minecraft:white_concrete
fill 155 40 370 157 40 370 minecraft:white_concrete
fill 157 40 410 159 40 410 minecraft:white_concrete
fill 159 40 370 160 40 370 minecraft:white_concrete
fill 161 40 410 162 40 410 minecraft:white_concrete
fill 162 40 370 164 40 370 minecraft:white_concrete
fill 164 40 410 166 40 410 minecraft:white_concrete
fill 166 40 370 167 40 370 minecraft:white_concrete
fill 168 40 410 169 40 410 minecraft:white_concrete
fill 169 40 370 171 40 370 minecraft:white_concrete
fill 171 40 410 173 40 410 minecraft:white_concrete
fill 173 40 370 174 40 370 minecraft:white_concrete
fill 175 40 410 176 40 410 minecraft:white_concrete
fill 176 40 370 178 40 370 minecraft:white_concrete
fill 178 40 410 180 40 410 minecraft:white_concrete
fill 180 40 370 181 40 370 minecraft:white_concrete
fill 182 40 371 182 40 373 minecraft:white_concrete
fill 182 40 375 182 40 376 minecraft:white_concrete
fill 182 40 378 182 40 380 minecraft:white_concrete
fill 182 40 382 182 40 383 minecraft:white_concrete
fill 182 40 385 182 40 387 minecraft:white_concrete
fill 182 40 389 182 40 390 minecraft:white_concrete
fill 182 40 392 182 40 394 minecraft:white_concrete
fill 182 40 396 182 40 397 minecraft:white_concrete
fill 182 40 399 182 40 401 minecraft:white_concrete
fill 182 40 403 182 40 404 minecraft:white_concrete
fill 182 40 406 182 40 408 minecraft:white_concrete
setblock 182 40 410 minecraft:white_concrete
setblock 142 41 374 minecraft:white_concrete
setblock 142 41 381 minecraft:white_concrete
setblock 142 41 388 minecraft:white_concrete
setblock 142 41 395 minecraft:white_concrete
setblock 142 41 402 minecraft:white_concrete
setblock 142 41 409 minecraft:white_concrete
setblock 145 41 370 minecraft:white_concrete
fill 148 41 384 149 42 384 minecraft:purple_wool
setblock 148 41 410 minecraft:white_concrete
setblock 152 41 370 minecraft:white_concrete
setblock 155 41 410 minecraft:white_concrete
setblock 159 41 370 minecraft:white_concrete
setblock 162 41 410 minecraft:white_concrete
setblock 166 41 370 minecraft:white_concrete
setblock 169 41 410 minecraft:white_concrete
setblock 173 41 370 minecraft:white_concrete
setblock 176 41 410 minecraft:white_concrete
setblock 180 41 370 minecraft:white_concrete
setblock 182 41 375 minecraft:white_concrete
setblock 182 41 382 minecraft:white_concrete
setblock 182 41 389 minecraft:white_concrete
setblock 182 41 396 minecraft:white_concrete
setblock 182 41 403 minecraft:white_concrete
fill 147 42 385 148 43 386 minecraft:white_wool
setblock 142 43 376 minecraft:white_concrete
setblock 142 43 383 minecraft:white_concrete
setblock 142 43 390 minecraft:white_concrete
setblock 142 43 397 minecraft:white_concrete
setblock 142 43 404 minecraft:white_concrete
setblock 143 43 370 minecraft:white_concrete
setblock 143 43 410 minecraft:white_concrete
setblock 144 43 372 minecraft:light[level=14]
setblock 144 43 380 minecraft:light[level=14]
setblock 144 43 388 minecraft:light[level=14]
setblock 144 43 396 minecraft:light[level=14]
setblock 144 43 404 minecraft:light[level=14]
setblock 150 43 370 minecraft:white_concrete
setblock 150 43 410 minecraft:white_concrete
setblock 152 43 372 minecraft:light[level=14]
setblock 152 43 380 minecraft:light[level=14]
setblock 152 43 388 minecraft:light[level=14]
setblock 152 43 396 minecraft:light[level=14]
setblock 152 43 404 minecraft:light[level=14]
setblock 157 43 370 minecraft:white_concrete
setblock 157 43 410 minecraft:white_concrete
setblock 160 43 372 minecraft:light[level=14]
setblock 160 43 380 minecraft:light[level=14]
setblock 160 43 388 minecraft:light[level=14]
setblock 160 43 396 minecraft:light[level=14]
setblock 160 43 404 minecraft:light[level=14]
setblock 164 43 370 minecraft:white_concrete
setblock 164 43 410 minecraft:white_concrete
setblock 168 43 372 minecraft:light[level=14]
setblock 168 43 380 minecraft:light[level=14]
setblock 168 43 388 minecraft:light[level=14]
setblock 168 43 396 minecraft:light[level=14]
setblock 168 43 404 minecraft:light[level=14]
setblock 171 43 370 minecraft:white_concrete
setblock 171 43 410 minecraft:white_concrete
setblock 176 43 372 minecraft:light[level=14]
setblock 176 43 380 minecraft:light[level=14]
setblock 176 43 388 minecraft:light[level=14]
setblock 176 43 396 minecraft:light[level=14]
setblock 176 43 404 minecraft:light[level=14]
setblock 178 43 370 minecraft:white_concrete
setblock 178 43 410 minecraft:white_concrete
setblock 182 43 373 minecraft:white_concrete
setblock 182 43 380 minecraft:white_concrete
setblock 182 43 387 minecraft:white_concrete
setblock 182 43 394 minecraft:white_concrete
setblock 182 43 401 minecraft:white_concrete
setblock 182 43 408 minecraft:white_concrete
setblock 142 44 370 minecraft:white_concrete
setblock 142 44 377 minecraft:white_concrete
setblock 142 44 384 minecraft:white_concrete
setblock 142 44 391 minecraft:white_concrete
setblock 142 44 398 minecraft:white_concrete
setblock 142 44 405 minecraft:white_concrete
setblock 144 44 410 minecraft:white_concrete
setblock 149 44 370 minecraft:white_concrete
setblock 151 44 410 minecraft:white_concrete
setblock 156 44 370 minecraft:white_concrete
setblock 158 44 410 minecraft:white_concrete
setblock 163 44 370 minecraft:white_concrete
setblock 165 44 410 minecraft:white_concrete
setblock 170 44 370 minecraft:white_concrete
setblock 172 44 410 minecraft:white_concrete
setblock 177 44 370 minecraft:white_concrete
setblock 179 44 410 minecraft:white_concrete
setblock 182 44 372 minecraft:white_concrete
setblock 182 44 379 minecraft:white_concrete
setblock 182 44 386 minecraft:white_concrete
setblock 182 44 393 minecraft:white_concrete
setblock 182 44 400 minecraft:white_concrete
setblock 182 44 407 minecraft:white_concrete
setblock 142 45 371 minecraft:white_concrete
setblock 142 45 378 minecraft:white_concrete
setblock 142 45 385 minecraft:white_concrete
setblock 142 45 392 minecraft:white_concrete
setblock 142 45 399 minecraft:white_concrete
setblock 142 45 406 minecraft:white_concrete
setblock 145 45 410 minecraft:white_concrete
setblock 148 45 370 minecraft:white_concrete
setblock 152 45 410 minecraft:white_concrete
setblock 155 45 370 minecraft:white_concrete
setblock 159 45 410 minecraft:white_concrete
setblock 162 45 370 minecraft:white_concrete
setblock 166 45 410 minecraft:white_concrete
setblock 169 45 370 minecraft:white_concrete
setblock 173 45 410 minecraft:white_concrete
setblock 176 45 370 minecraft:white_concrete
setblock 180 45 410 minecraft:white_concrete
setblock 182 45 371 minecraft:white_concrete
setblock 182 45 378 minecraft:white_concrete
setblock 182 45 385 minecraft:white_concrete
setblock 182 45 392 minecraft:white_concrete
setblock 182 45 399 minecraft:white_concrete
setblock 182 45 406 minecraft:white_concrete
setblock 142 46 372 minecraft:white_concrete
setblock 142 46 379 minecraft:white_concrete
setblock 142 46 386 minecraft:white_concrete
setblock 142 46 393 minecraft:white_concrete
setblock 142 46 400 minecraft:white_concrete
setblock 142 46 407 minecraft:white_concrete
setblock 146 46 410 minecraft:white_concrete
setblock 147 46 370 minecraft:white_concrete
setblock 153 46 410 minecraft:white_concrete
setblock 154 46 370 minecraft:white_concrete
setblock 160 46 410 minecraft:white_concrete
setblock 161 46 370 minecraft:white_concrete
setblock 167 46 410 minecraft:white_concrete
setblock 168 46 370 minecraft:white_concrete
setblock 174 46 410 minecraft:white_concrete
setblock 175 46 370 minecraft:white_concrete
setblock 181 46 410 minecraft:white_concrete
setblock 182 46 370 minecraft:white_concrete
setblock 182 46 377 minecraft:white_concrete
setblock 182 46 384 minecraft:white_concrete
setblock 182 46 391 minecraft:white_concrete
setblock 182 46 398 minecraft:white_concrete
setblock 182 46 405 minecraft:white_concrete
setblock 142 47 373 minecraft:white_concrete
setblock 142 47 380 minecraft:white_concrete
setblock 142 47 387 minecraft:white_concrete
setblock 142 47 394 minecraft:white_concrete
setblock 142 47 401 minecraft:white_concrete
setblock 142 47 408 minecraft:white_concrete
setblock 146 47 370 minecraft:white_concrete
setblock 147 47 410 minecraft:white_concrete
setblock 153 47 370 minecraft:white_concrete
setblock 154 47 410 minecraft:white_concrete
setblock 160 47 370 minecraft:white_concrete
setblock 161 47 410 minecraft:white_concrete
setblock 167 47 370 minecraft:white_concrete
setblock 168 47 410 minecraft:white_concrete
setblock 174 47 370 minecraft:white_concrete
setblock 175 47 410 minecraft:white_concrete
setblock 181 47 370 minecraft:white_concrete
setblock 182 47 376 minecraft:white_concrete
setblock 182 47 383 minecraft:white_concrete
setblock 182 47 390 minecraft:white_concrete
setblock 182 47 397 minecraft:white_concrete
setblock 182 47 404 minecraft:white_concrete
setblock 182 47 410 minecraft:white_concrete
setblock 142 48 374 minecraft:white_concrete
setblock 142 48 381 minecraft:white_concrete
setblock 142 48 388 minecraft:white_concrete
setblock 142 48 395 minecraft:white_concrete
setblock 142 48 402 minecraft:white_concrete
setblock 142 48 409 minecraft:white_concrete
setblock 145 48 370 minecraft:white_concrete
setblock 148 48 410 minecraft:white_concrete
setblock 152 48 370 minecraft:white_concrete
setblock 155 48 410 minecraft:white_concrete
setblock 159 48 370 minecraft:white_concrete
setblock 162 48 410 minecraft:white_concrete
setblock 166 48 370 minecraft:white_concrete
setblock 169 48 410 minecraft:white_concrete
setblock 173 48 370 minecraft:white_concrete
setblock 176 48 410 minecraft:white_concrete
setblock 180 48 370 minecraft:white_concrete
fill 180 48 378 180 49 384 minecraft:gray_concrete
setblock 182 48 375 minecraft:white_concrete
setblock 182 48 382 minecraft:white_concrete
setblock 182 48 389 minecraft:white_concrete
setblock 182 48 396 minecraft:white_concrete
setblock 182 48 403 minecraft:white_concrete
fill 142 50 370 142 50 374 minecraft:white_concrete
fill 142 50 376 142 50 381 minecraft:white_concrete
fill 142 50 383 142 50 388 minecraft:white_concrete
fill 142 50 390 142 50 395 minecraft:white_concrete
fill 142 50 397 142 50 402 minecraft:white_concrete
fill 142 50 404 142 50 409 minecraft:white_concrete
setblock 143 50 370 minecraft:white_concrete
fill 143 50 410 148 50 410 minecraft:white_concrete
fill 145 50 370 150 50 370 minecraft:white_concrete
fill 150 50 410 155 50 410 minecraft:white_concrete
fill 152 50 370 157 50 370 minecraft:white_concrete
fill 157 50 410 162 50 410 minecraft:white_concrete
fill 159 50 370 164 50 370 minecraft:white_concrete
fill 164 50 410 169 50 410 minecraft:white_concrete
fill 166 50 370 171 50 370 minecraft:white_concrete
fill 171 50 410 176 50 410 minecraft:white_concrete
fill 173 50 370 178 50 370 minecraft:white_concrete
fill 178 50 410 182 50 410 minecraft:white_concrete
fill 180 50 370 182 50 370 minecraft:white_concrete
fill 182 50 371 182 50 373 minecraft:white_concrete
fill 182 50 375 182 50 380 minecraft:white_concrete
fill 182 50 382 182 50 387 minecraft:white_concrete
fill 182 50 389 182 50 394 minecraft:white_concrete
fill 182 50 396 182 50 401 minecraft:white_concrete
fill 182 50 403 182 50 408 minecraft:white_concrete
setblock 144 51 372 minecraft:light[level=14]
setblock 144 51 380 minecraft:light[level=14]
setblock 144 51 388 minecraft:light[level=14]
setblock 144 51 396 minecraft:light[level=14]
setblock 144 51 404 minecraft:light[level=14]
setblock 152 51 372 minecraft:light[level=14]
setblock 152 51 380 minecraft:light[level=14]
setblock 152 51 388 minecraft:light[level=14]
setblock 152 51 396 minecraft:light[level=14]
setblock 152 51 404 minecraft:light[level=14]
setblock 160 51 372 minecraft:light[level=14]
setblock 160 51 380 minecraft:light[level=14]
setblock 160 51 388 minecraft:light[level=14]
setblock 160 51 396 minecraft:light[level=14]
setblock 160 51 404 minecraft:light[level=14]
setblock 168 51 372 minecraft:light[level=14]
setblock 168 51 380 minecraft:light[level=14]
setblock 168 51 388 minecraft:light[level=14]
setblock 168 51 396 minecraft:light[level=14]
setblock 168 51 404 minecraft:light[level=14]
setblock 176 51 372 minecraft:light[level=14]
setblock 176 51 380 minecraft:light[level=14]
setblock 176 51 388 minecraft:light[level=14]
setblock 176 51 396 minecraft:light[level=14]
setblock 176 51 404 minecraft:light[level=14]
fill 149 56 389 149 58 393 minecraft:white_concrete
fill 150 56 387 150 58 390 minecraft:white_concrete
fill 150 56 391 151 57 391 minecraft:black_concrete
fill 150 56 392 150 58 395 minecraft:white_concrete
fill 151 56 385 151 58 387 minecraft:white_concrete
fill 151 56 388 151 57 388 minecraft:black_concrete
fill 151 56 389 151 57 389 minecraft:red_concrete
fill 151 56 390 152 57 390 minecraft:black_concrete
fill 151 56 392 151 57 392 minecraft:red_concrete
fill 151 56 393 151 57 394 minecraft:black_concrete
fill 151 56 395 151 58 397 minecraft:white_concrete
fill 152 56 385 152 58 386 minecraft:white_concrete
fill 152 56 387 152 57 387 minecraft:black_concrete
fill 152 56 388 152 57 388 minecraft:red_concrete
fill 152 56 389 153 57 389 minecraft:black_concrete
fill 152 56 391 152 57 391 minecraft:red_concrete
fill 152 56 392 152 57 393 minecraft:black_concrete
fill 152 56 394 152 57 394 minecraft:red_concrete
fill 152 56 395 153 57 395 minecraft:black_concrete
fill 152 56 396 152 58 397 minecraft:white_concrete
fill 153 56 384 153 58 385 minecraft:white_concrete
fill 153 56 386 153 57 386 minecraft:black_concrete
fill 153 56 387 153 57 387 minecraft:red_concrete
fill 153 56 388 154 57 388 minecraft:black_concrete
fill 153 56 390 153 57 390 minecraft:red_concrete
fill 153 56 391 153 57 392 minecraft:black_concrete
fill 153 56 393 153 57 393 minecraft:red_concrete
fill 153 56 394 154 57 394 minecraft:black_concrete
fill 153 56 396 153 57 396 minecraft:red_concrete
fill 153 56 397 153 58 398 minecraft:white_concrete
fill 154 56 384 156 58 384 minecraft:white_concrete
fill 154 56 385 154 57 385 minecraft:black_concrete
fill 154 56 386 154 57 386 minecraft:red_concrete
fill 154 56 387 155 57 387 minecraft:black_concrete
fill 154 56 389 154 57 389 minecraft:red_concrete
fill 154 56 390 154 56 391 minecraft:black_concrete
setblock 154 56 392 minecraft:red_concrete
fill 154 56 393 155 56 393 minecraft:black_concrete
fill 154 56 395 154 57 395 minecraft:red_concrete
fill 154 56 396 154 57 397 minecraft:black_concrete
fill 154 56 398 156 58 398 minecraft:white_concrete
fill 155 56 383 159 58 383 minecraft:white_concrete
fill 155 56 385 155 57 385 minecraft:red_concrete
fill 155 56 386 156 57 386 minecraft:black_concrete
fill 155 56 388 155 57 388 minecraft:red_concrete
fill 155 56 389 155 56 390 minecraft:black_concrete
setblock 155 56 392 minecraft:black_concrete
fill 155 56 394 155 57 394 minecraft:red_concrete
fill 155 56 395 155 57 396 minecraft:black_concrete
fill 155 56 397 155 57 397 minecraft:red_concrete
fill 155 56 399 159 58 399 minecraft:white_concrete
fill 156 56 385 157 57 385 minecraft:black_concrete
fill 156 56 387 156 57 387 minecraft:red_concrete
fill 156 56 388 156 56 389 minecraft:black_concrete
setblock 156 56 393 minecraft:red_concrete
fill 156 56 394 156 56 395 minecraft:black_concrete
fill 156 56 396 156 57 396 minecraft:red_concrete
fill 156 56 397 157 57 397 minecraft:black_concrete
fill 157 56 384 157 57 384 minecraft:black_concrete
fill 157 56 386 157 57 386 minecraft:red_concrete
fill 157 56 387 157 56 388 minecraft:black_concrete
setblock 157 56 394 minecraft:black_concrete
fill 157 56 395 157 57 395 minecraft:red_concrete
fill 157 56 396 158 57 396 minecraft:black_concrete
fill 157 56 398 157 57 398 minecraft:red_concrete
fill 158 56 384 161 58 384 minecraft:white_concrete
fill 158 56 385 158 57 385 minecraft:red_concrete
fill 158 56 386 158 57 387 minecraft:black_concrete
setblock 158 56 388 minecraft:red_concrete
fill 158 56 389 159 56 389 minecraft:black_concrete
setblock 158 56 393 minecraft:black_concrete
setblock 158 56 394 minecraft:red_concrete
fill 158 56 395 159 57 395 minecraft:black_concrete
fill 158 56 397 158 57 397 minecraft:red_concrete
fill 158 56 398 161 58 398 minecraft:white_concrete
fill 159 56 385 159 57 386 minecraft:black_concrete
fill 159 56 387 159 57 387 minecraft:red_concrete
fill 159 56 388 160 57 388 minecraft:black_concrete
setblock 159 56 390 minecraft:red_concrete
setblock 159 56 392 minecraft:black_concrete
setblock 159 56 393 minecraft:red_concrete
fill 159 56 394 160 57 394 minecraft:black_concrete
fill 159 56 396 159 57 396 minecraft:red_concrete
fill 159 56 397 160 57 397 minecraft:black_concrete
fill 160 56 385 160 57 385 minecraft:black_concrete
fill 160 56 386 160 57 386 minecraft:red_concrete
fill 160 56 387 161 57 387 minecraft:black_concrete
fill 160 56 389 160 57 389 minecraft:red_concrete
fill 160 56 390 160 56 391 minecraft:black_concrete
setblock 160 56 392 minecraft:red_concrete
fill 160 56 393 161 57 393 minecraft:black_concrete
fill 160 56 395 160 57 395 minecraft:red_concrete
fill 160 56 396 161 57 396 minecraft:black_concrete
fill 161 56 385 163 58 385 minecraft:white_concrete
fill 161 56 386 161 57 386 minecraft:black_concrete
fill 161 56 388 161 57 388 minecraft:red_concrete
fill 161 56 389 161 57 390 minecraft:black_concrete
fill 161 56 391 161 57 391 minecraft:red_concrete
fill 161 56 392 162 57 392 minecraft:black_concrete
fill 161 56 394 161 57 394 minecraft:red_concrete
fill 161 56 395 162 57 395 minecraft:black_concrete
fill 161 56 397 163 58 397 minecraft:white_concrete
fill 162 56 386 163 58 386 minecraft:white_concrete
fill 162 56 387 162 57 387 minecraft:red_concrete
fill 162 56 388 162 57 389 minecraft:black_concrete
fill 162 56 390 162 57 390 minecraft:red_concrete
fill 162 56 391 163 57 391 minecraft:black_concrete
fill 162 56 393 162 57 393 minecraft:red_concrete
fill 162 56 394 163 57 394 minecraft:black_concrete
fill 162 56 396 163 58 396 minecraft:white_concrete
fill 163 56 387 164 58 387 minecraft:white_concrete
fill 163 56 388 163 57 388 minecraft:black_concrete
fill 163 56 389 163 57 389 minecraft:red_concrete
fill 163 56 390 163 57 390 minecraft:black_concrete
fill 163 56 392 163 57 392 minecraft:red_concrete
fill 163 56 393 163 57 393 minecraft:black_concrete
fill 163 56 395 164 58 395 minecraft:white_concrete
fill 164 56 388 164 58 390 minecraft:white_concrete
fill 164 56 391 164 57 391 minecraft:red_concrete
fill 164 56 392 164 58 394 minecraft:white_concrete
fill 165 56 389 165 58 393 minecraft:white_concrete
fill 142 57 370 148 57 410 minecraft:black_concrete
fill 149 57 370 149 57 387 minecraft:black_concrete
setblock 149 57 388 minecraft:white_concrete
setblock 149 57 394 minecraft:white_concrete
fill 149 57 395 149 57 410 minecraft:black_concrete
fill 150 57 370 150 57 385 minecraft:black_concrete
setblock 150 57 386 minecraft:white_concrete
setblock 150 57 396 minecraft:white_concrete
fill 150 57 397 150 57 410 minecraft:black_concrete
fill 151 57 370 151 57 384 minecraft:black_concrete
fill 151 57 398 151 57 410 minecraft:black_concrete
fill 152 57 370 153 57 383 minecraft:black_concrete
setblock 152 57 384 minecraft:white_concrete
setblock 152 57 398 minecraft:white_concrete
fill 152 57 399 153 57 410 minecraft:black_concrete
fill 154 57 370 182 57 382 minecraft:black_concrete
setblock 154 57 383 minecraft:white_concrete
fill 154 57 390 154 57 392 minecraft:jack_o_lantern
setblock 154 57 393 minecraft:black_concrete
setblock 154 57 399 minecraft:white_concrete
fill 154 57 400 182 57 410 minecraft:black_concrete
fill 155 57 389 155 57 390 minecraft:jack_o_lantern
fill 155 57 392 155 57 393 minecraft:jack_o_lantern
fill 156 57 388 156 57 389 minecraft:jack_o_lantern
fill 156 57 393 156 57 394 minecraft:jack_o_lantern
setblock 156 57 395 minecraft:black_concrete
setblock 157 57 387 minecraft:black_concrete
fill 157 57 388 158 57 388 minecraft:jack_o_lantern
fill 157 57 394 158 57 394 minecraft:jack_o_lantern
fill 158 57 389 159 57 389 minecraft:jack_o_lantern
fill 158 57 393 159 57 393 minecraft:jack_o_lantern
fill 159 57 390 160 57 390 minecraft:jack_o_lantern
fill 159 57 392 160 57 392 minecraft:jack_o_lantern
setblock 160 57 383 minecraft:white_concrete
setblock 160 57 391 minecraft:jack_o_lantern
setblock 160 57 399 minecraft:white_concrete
fill 161 57 383 182 57 383 minecraft:black_concrete
fill 161 57 399 182 57 399 minecraft:black_concrete
setblock 162 57 384 minecraft:white_concrete
setblock 162 57 398 minecraft:white_concrete
fill 163 57 384 182 57 384 minecraft:black_concrete
fill 163 57 398 182 57 398 minecraft:black_concrete
fill 164 57 385 182 57 385 minecraft:black_concrete
setblock 164 57 386 minecraft:white_concrete
setblock 164 57 396 minecraft:white_concrete
fill 164 57 397 182 57 397 minecraft:black_concrete
fill 165 57 386 182 57 387 minecraft:black_concrete
setblock 165 57 388 minecraft:white_concrete
setblock 165 57 394 minecraft:white_concrete
fill 165 57 395 182 57 396 minecraft:black_concrete
fill 166 57 388 182 57 394 minecraft:black_concrete
fill 150 58 391 151 58 391 minecraft:white_concrete
fill 151 58 388 151 58 390 minecraft:white_concrete
fill 151 58 392 151 58 394 minecraft:white_concrete
fill 152 58 387 152 58 388 minecraft:white_concrete
fill 152 58 394 152 58 395 minecraft:white_concrete
fill 153 58 386 153 58 387 minecraft:white_concrete
fill 153 58 395 153 58 396 minecraft:white_concrete
fill 154 58 385 154 58 386 minecraft:white_concrete
fill 154 58 396 154 58 397 minecraft:white_concrete
fill 155 58 385 160 58 385 minecraft:white_concrete
fill 155 58 397 160 58 397 minecraft:white_concrete
setblock 157 58 384 minecraft:white_concrete
setblock 157 58 398 minecraft:white_concrete
fill 160 58 386 161 58 386 minecraft:white_concrete
fill 160 58 396 161 58 396 minecraft:white_concrete
fill 161 58 387 162 58 387 minecraft:white_concrete
fill 161 58 395 162 58 395 minecraft:white_concrete
fill 162 58 388 163 58 388 minecraft:white_concrete
fill 162 58 394 163 58 394 minecraft:white_concrete
fill 163 58 389 163 58 393 minecraft:white_concrete
setblock 164 58 391 minecraft:white_concrete
setblock 144 59 372 minecraft:light[level=14]
setblock 144 59 380 minecraft:light[level=14]
setblock 144 59 388 minecraft:light[level=14]
setblock 144 59 396 minecraft:light[level=14]
setblock 144 59 404 minecraft:light[level=14]
setblock 152 59 372 minecraft:light[level=14]
setblock 152 59 380 minecraft:light[level=14]
setblock 152 59 388 minecraft:light[level=14]
setblock 152 59 396 minecraft:light[level=14]
setblock 152 59 404 minecraft:light[level=14]
setblock 160 59 372 minecraft:light[level=14]
setblock 160 59 380 minecraft:light[level=14]
setblock 160 59 388 minecraft:light[level=14]
setblock 160 59 396 minecraft:light[level=14]
setblock 160 59 404 minecraft:light[level=14]
setblock 168 59 372 minecraft:light[level=14]
setblock 168 59 380 minecraft:light[level=14]
setblock 168 59 388 minecraft:light[level=14]
setblock 168 59 396 minecraft:light[level=14]
setblock 168 59 404 minecraft:light[level=14]
setblock 176 59 372 minecraft:light[level=14]
setblock 176 59 380 minecraft:light[level=14]
setblock 176 59 388 minecraft:light[level=14]
setblock 176 59 396 minecraft:light[level=14]
setblock 176 59 404 minecraft:light[level=14]
setblock 142 61 373 minecraft:white_concrete
fill 142 61 375 142 133 375 minecraft:white_concrete
setblock 142 61 380 minecraft:white_concrete
fill 142 61 382 142 133 382 minecraft:white_concrete
setblock 142 61 387 minecraft:white_concrete
fill 142 61 389 142 133 389 minecraft:white_concrete
setblock 142 61 394 minecraft:white_concrete
fill 142 61 396 142 133 396 minecraft:white_concrete
setblock 142 61 401 minecraft:white_concrete
fill 142 61 403 142 133 403 minecraft:white_concrete
setblock 142 61 408 minecraft:white_concrete
fill 142 61 410 142 133 410 minecraft:white_concrete
fill 144 61 370 144 133 370 minecraft:white_concrete
setblock 146 61 370 minecraft:white_concrete
setblock 147 61 410 minecraft:white_concrete
fill 149 61 410 149 133 410 minecraft:white_concrete
fill 151 61 370 151 133 370 minecraft:white_concrete
setblock 153 61 370 minecraft:white_concrete
setblock 154 61 410 minecraft:white_concrete
fill 156 61 410 156 133 410 minecraft:white_concrete
fill 158 61 370 158 133 370 minecraft:white_concrete
setblock 160 61 370 minecraft:white_concrete
setblock 161 61 410 minecraft:white_concrete
fill 163 61 410 163 133 410 minecraft:white_concrete
fill 165 61 370 165 133 370 minecraft:white_concrete
setblock 167 61 370 minecraft:white_concrete
setblock 168 61 410 minecraft:white_concrete
fill 170 61 410 170 133 410 minecraft:white_concrete
fill 172 61 370 172 133 370 minecraft:white_concrete
setblock 174 61 370 minecraft:white_concrete
setblock 175 61 410 minecraft:white_concrete
fill 177 61 410 177 133 410 minecraft:white_concrete
fill 179 61 370 179 133 370 minecraft:white_concrete
setblock 181 61 370 minecraft:white_concrete
fill 182 61 374 182 133 374 minecraft:white_concrete
setblock 182 61 376 minecraft:white_concrete
fill 182 61 381 182 133 381 minecraft:white_concrete
setblock 182 61 383 minecraft:white_concrete
fill 182 61 388 182 133 388 minecraft:white_concrete
setblock 182 61 390 minecraft:white_concrete
fill 182 61 395 182 133 395 minecraft:white_concrete
setblock 182 61 397 minecraft:white_concrete
fill 182 61 402 182 133 402 minecraft:white_concrete
setblock 182 61 404 minecraft:white_concrete
fill 182 61 409 182 61 410 minecraft:white_concrete
setblock 142 62 374 minecraft:white_concrete
setblock 142 62 381 minecraft:white_concrete
setblock 142 62 388 minecraft:white_concrete
setblock 142 62 395 minecraft:white_concrete
setblock 142 62 402 minecraft:white_concrete
setblock 142 62 409 minecraft:white_concrete
setblock 145 62 370 minecraft:white_concrete
setblock 148 62 410 minecraft:white_concrete
setblock 152 62 370 minecraft:white_concrete
setblock 155 62 410 minecraft:white_concrete
setblock 159 62 370 minecraft:white_concrete
setblock 162 62 410 minecraft:white_concrete
setblock 166 62 370 minecraft:white_concrete
setblock 169 62 410 minecraft:white_concrete
setblock 173 62 370 minecraft:white_concrete
setblock 176 62 410 minecraft:white_concrete
setblock 180 62 370 minecraft:white_concrete
setblock 182 62 375 minecraft:white_concrete
setblock 182 62 382 minecraft:white_concrete
setblock 182 62 389 minecraft:white_concrete
setblock 182 62 396 minecraft:white_concrete
setblock 182 62 403 minecraft:white_concrete
fill 182 62 409 182 133 409 minecraft:white_concrete
setblock 142 64 376 minecraft:white_concrete
setblock 142 64 383 minecraft:white_concrete
setblock 142 64 390 minecraft:white_concrete
setblock 142 64 397 minecraft:white_concrete
setblock 142 64 404 minecraft:white_concrete
setblock 143 64 370 minecraft:white_concrete
setblock 143 64 410 minecraft:white_concrete
setblock 150 64 370 minecraft:white_concrete
setblock 150 64 410 minecraft:white_concrete
setblock 157 64 370 minecraft:white_concrete
setblock 157 64 410 minecraft:white_concrete
setblock 164 64 370 minecraft:white_concrete
setblock 164 64 410 minecraft:white_concrete
setblock 171 64 370 minecraft:white_concrete
setblock 171 64 410 minecraft:white_concrete
setblock 178 64 370 minecraft:white_concrete
setblock 178 64 410 minecraft:white_concrete
setblock 182 64 373 minecraft:white_concrete
setblock 182 64 380 minecraft:white_concrete
setblock 182 64 387 minecraft:white_concrete
setblock 182 64 394 minecraft:white_concrete
setblock 182 64 401 minecraft:white_concrete
setblock 182 64 408 minecraft:white_concrete
setblock 142 65 370 minecraft:white_concrete
setblock 142 65 377 minecraft:white_concrete
setblock 142 65 384 minecraft:white_concrete
setblock 142 65 391 minecraft:white_concrete
setblock 142 65 398 minecraft:white_concrete
setblock 142 65 405 minecraft:white_concrete
setblock 144 65 410 minecraft:white_concrete
setblock 149 65 370 minecraft:white_concrete
setblock 151 65 410 minecraft:white_concrete
setblock 156 65 370 minecraft:white_concrete
setblock 158 65 410 minecraft:white_concrete
setblock 163 65 370 minecraft:white_concrete
setblock 165 65 410 minecraft:white_concrete
setblock 170 65 370 minecraft:white_concrete
setblock 172 65 410 minecraft:white_concrete
setblock 177 65 370 minecraft:white_concrete
setblock 179 65 410 minecraft:white_concrete
fill 180 65 399 180 78 399 minecraft:purple_wool
setblock 182 65 372 minecraft:white_concrete
setblock 182 65 379 minecraft:white_concrete
setblock 182 65 386 minecraft:white_concrete
setblock 182 65 393 minecraft:white_concrete
setblock 182 65 400 minecraft:white_concrete
setblock 182 65 407 minecraft:white_concrete
setblock 142 66 371 minecraft:white_concrete
setblock 142 66 378 minecraft:white_concrete
setblock 142 66 385 minecraft:white_concrete
setblock 142 66 392 minecraft:white_concrete
setblock 142 66 399 minecraft:white_concrete
setblock 142 66 406 minecraft:white_concrete
setblock 145 66 410 minecraft:white_concrete
setblock 148 66 370 minecraft:white_concrete
setblock 152 66 410 minecraft:white_concrete
setblock 155 66 370 minecraft:white_concrete
setblock 159 66 410 minecraft:white_concrete
setblock 162 66 370 minecraft:white_concrete
setblock 166 66 410 minecraft:white_concrete
setblock 169 66 370 minecraft:white_concrete
setblock 173 66 410 minecraft:white_concrete
setblock 176 66 370 minecraft:white_concrete
fill 180 66 397 180 78 398 minecraft:purple_wool
fill 180 66 400 180 78 401 minecraft:purple_wool
setblock 180 66 410 minecraft:white_concrete
setblock 182 66 371 minecraft:white_concrete
setblock 182 66 378 minecraft:white_concrete
setblock 182 66 385 minecraft:white_concrete
setblock 182 66 392 minecraft:white_concrete
setblock 182 66 399 minecraft:white_concrete
setblock 182 66 406 minecraft:white_concrete
setblock 142 67 372 minecraft:white_concrete
setblock 142 67 379 minecraft:white_concrete
setblock 142 67 386 minecraft:white_concrete
setblock 142 67 393 minecraft:white_concrete
setblock 142 67 400 minecraft:white_concrete
setblock 142 67 407 minecraft:white_concrete
setblock 144 67 372 minecraft:light[level=14]
setblock 144 67 380 minecraft:light[level=14]
setblock 144 67 388 minecraft:light[level=14]
setblock 144 67 396 minecraft:light[level=14]
setblock 144 67 404 minecraft:light[level=14]
setblock 146 67 410 minecraft:white_concrete
setblock 147 67 370 minecraft:white_concrete
setblock 152 67 372 minecraft:light[level=14]
setblock 152 67 380 minecraft:light[level=14]
setblock 152 67 388 minecraft:light[level=14]
setblock 152 67 396 minecraft:light[level=14]
setblock 152 67 404 minecraft:light[level=14]
setblock 153 67 410 minecraft:white_concrete
setblock 154 67 370 minecraft:white_concrete
setblock 160 67 372 minecraft:light[level=14]
setblock 160 67 380 minecraft:light[level=14]
setblock 160 67 388 minecraft:light[level=14]
setblock 160 67 396 minecraft:light[level=14]
setblock 160 67 404 minecraft:light[level=14]
setblock 160 67 410 minecraft:white_concrete
setblock 161 67 370 minecraft:white_concrete
setblock 167 67 410 minecraft:white_concrete
setblock 168 67 370 minecraft:white_concrete
setblock 168 67 372 minecraft:light[level=14]
setblock 168 67 380 minecraft:light[level=14]
setblock 168 67 388 minecraft:light[level=14]
setblock 168 67 396 minecraft:light[level=14]
setblock 168 67 404 minecraft:light[level=14]
setblock 174 67 410 minecraft:white_concrete
setblock 175 67 370 minecraft:white_concrete
setblock 176 67 372 minecraft:light[level=14]
setblock 176 67 380 minecraft:light[level=14]
setblock 176 67 388 minecraft:light[level=14]
setblock 176 67 396 minecraft:light[level=14]
setblock 176 67 404 minecraft:light[level=14]
setblock 181 67 410 minecraft:white_concrete
setblock 182 67 370 minecraft:white_concrete
setblock 182 67 377 minecraft:white_concrete
setblock 182 67 384 minecraft:white_concrete
setblock 182 67 391 minecraft:white_concrete
setblock 182 67 398 minecraft:white_concrete
setblock 182 67 405 minecraft:white_concrete
setblock 142 68 373 minecraft:white_concrete
setblock 142 68 380 minecraft:white_concrete
setblock 142 68 387 minecraft:white_concrete
setblock 142 68 394 minecraft:white_concrete
setblock 142 68 401 minecraft:white_concrete
setblock 142 68 408 minecraft:white_concrete
setblock 146 68 370 minecraft:white_concrete
setblock 147 68 410 minecraft:white_concrete
setblock 153 68 370 minecraft:white_concrete
setblock 154 68 410 minecraft:white_concrete
setblock 160 68 370 minecraft:white_concrete
setblock 161 68 410 minecraft:white_concrete
setblock 167 68 370 minecraft:white_concrete
setblock 168 68 410 minecraft:white_concrete
setblock 174 68 370 minecraft:white_concrete
setblock 175 68 410 minecraft:white_concrete
setblock 181 68 370 minecraft:white_concrete
setblock 182 68 376 minecraft:white_concrete
setblock 182 68 383 minecraft:white_concrete
setblock 182 68 390 minecraft:white_concrete
setblock 182 68 397 minecraft:white_concrete
setblock 182 68 404 minecraft:white_concrete
setblock 182 68 410 minecraft:white_concrete
fill 142 69 374 142 70 374 minecraft:white_concrete
fill 142 69 381 142 70 381 minecraft:white_concrete
fill 142 69 388 142 70 388 minecraft:white_concrete
fill 142 69 395 142 70 395 minecraft:white_concrete
fill 142 69 402 142 70 402 minecraft:white_concrete
fill 142 69 409 142 70 409 minecraft:white_concrete
fill 145 69 370 145 70 370 minecraft:white_concrete
fill 148 69 410 148 70 410 minecraft:white_concrete
fill 152 69 370 152 70 370 minecraft:white_concrete
fill 155 69 410 155 70 410 minecraft:white_concrete
fill 159 69 370 159 70 370 minecraft:white_concrete
fill 162 69 410 162 70 410 minecraft:white_concrete
fill 166 69 370 166 70 370 minecraft:white_concrete
fill 169 69 410 169 70 410 minecraft:white_concrete
fill 173 69 370 173 70 370 minecraft:white_concrete
fill 176 69 410 176 70 410 minecraft:white_concrete
fill 180 69 370 180 70 370 minecraft:white_concrete
fill 182 69 375 182 70 375 minecraft:white_concrete
fill 182 69 382 182 70 382 minecraft:white_concrete
fill 182 69 389 182 70 389 minecraft:white_concrete
fill 182 69 396 182 70 396 minecraft:white_concrete
fill 182 69 403 182 70 403 minecraft:white_concrete
fill 142 70 370 142 70 373 minecraft:white_concrete
fill 142 70 376 142 70 380 minecraft:white_concrete
fill 142 70 383 142 70 387 minecraft:white_concrete
fill 142 70 390 142 70 394 minecraft:white_concrete
fill 142 70 397 142 70 401 minecraft:white_concrete
fill 142 70 404 142 70 408 minecraft:white_concrete
fill 143 70 370 143 71 370 minecraft:white_concrete
fill 143 70 410 147 70 410 minecraft:white_concrete
fill 146 70 370 150 70 370 minecraft:white_concrete
fill 150 70 410 154 70 410 minecraft:white_concrete
fill 153 70 370 157 70 370 minecraft:white_concrete
fill 156 70 399 157 71 400 minecraft:purple_wool
fill 157 70 410 161 70 410 minecraft:white_concrete
fill 160 70 370 164 70 370 minecraft:white_concrete
fill 164 70 410 168 70 410 minecraft:white_concrete
fill 167 70 370 171 70 370 minecraft:white_concrete
fill 171 70 410 175 70 410 minecraft:white_concrete
fill 174 70 370 178 70 370 minecraft:white_concrete
fill 178 70 410 182 70 410 minecraft:white_concrete
fill 181 70 370 182 70 370 minecraft:white_concrete
fill 182 70 371 182 70 373 minecraft:white_concrete
fill 182 70 376 182 70 380 minecraft:white_concrete
fill 182 70 383 182 70 387 minecraft:white_concrete
fill 182 70 390 182 70 394 minecraft:white_concrete
fill 182 70 397 182 70 401 minecraft:white_concrete
fill 182 70 404 182 70 408 minecraft:white_concrete
setblock 142 71 376 minecraft:white_concrete
setblock 142 71 383 minecraft:white_concrete
setblock 142 71 390 minecraft:white_concrete
setblock 142 71 397 minecraft:white_concrete
setblock 142 71 404 minecraft:white_concrete
setblock 143 71 410 minecraft:white_concrete
setblock 150 71 370 minecraft:white_concrete
setblock 150 71 410 minecraft:white_concrete
setblock 157 71 370 minecraft:white_concrete
setblock 157 71 410 minecraft:white_concrete
setblock 164 71 370 minecraft:white_concrete
setblock 164 71 410 minecraft:white_concrete
setblock 171 71 370 minecraft:white_concrete
setblock 171 71 410 minecraft:white_concrete
setblock 178 71 370 minecraft:white_concrete
setblock 178 71 410 minecraft:white_concrete
setblock 182 71 373 minecraft:white_concrete
setblock 182 71 380 minecraft:white_concrete
setblock 182 71 387 minecraft:white_concrete
setblock 182 71 394 minecraft:white_concrete
setblock 182 71 401 minecraft:white_concrete
setblock 182 71 408 minecraft:white_concrete
setblock 142 72 370 minecraft:white_concrete
setblock 142 72 377 minecraft:white_concrete
setblock 142 72 384 minecraft:white_concrete
setblock 142 72 391 minecraft:white_concrete
setblock 142 72 398 minecraft:white_concrete
setblock 142 72 405 minecraft:white_concrete
setblock 144 72 410 minecraft:white_concrete
setblock 149 72 370 minecraft:white_concrete
setblock 151 72 410 minecraft:white_concrete
setblock 156 72 370 minecraft:white_concrete
setblock 158 72 410 minecraft:white_concrete
setblock 163 72 370 minecraft:white_concrete
setblock 165 72 410 minecraft:white_concrete
setblock 170 72 370 minecraft:white_concrete
setblock 172 72 410 minecraft:white_concrete
setblock 177 72 370 minecraft:white_concrete
setblock 179 72 410 minecraft:white_concrete
setblock 182 72 372 minecraft:white_concrete
setblock 182 72 379 minecraft:white_concrete
setblock 182 72 386 minecraft:white_concrete
setblock 182 72 393 minecraft:white_concrete
setblock 182 72 400 minecraft:white_concrete
setblock 182 72 407 minecraft:white_concrete
fill 141 73 369 141 74 383 minecraft:purple_concrete
setblock 141 73 384 minecraft:black_concrete
fill 141 73 385 141 76 386 minecraft:purple_concrete
setblock 141 73 387 minecraft:black_concrete
fill 141 73 388 141 76 388 minecraft:purple_concrete
setblock 141 73 389 minecraft:black_concrete
fill 141 73 390 141 76 394 minecraft:purple_concrete
setblock 141 73 395 minecraft:black_concrete
fill 141 73 396 141 73 408 minecraft:purple_concrete
setblock 141 73 409 minecraft:black_concrete
fill 141 73 410 141 74 411 minecraft:purple_concrete
fill 142 73 369 147 76 369 minecraft:purple_concrete
setblock 142 73 371 minecraft:white_concrete
setblock 142 73 378 minecraft:white_concrete
setblock 142 73 385 minecraft:white_concrete
setblock 142 73 392 minecraft:white_concrete
setblock 142 73 399 minecraft:white_concrete
setblock 142 73 406 minecraft:white_concrete
fill 142 73 411 159 73 411 minecraft:purple_concrete
setblock 145 73 410 minecraft:white_concrete
setblock 148 73 369 minecraft:black_concrete
setblock 148 73 370 minecraft:white_concrete
fill 149 73 369 154 73 369 minecraft:purple_concrete
setblock 152 73 410 minecraft:white_concrete
setblock 155 73 369 minecraft:black_concrete
setblock 155 73 370 minecraft:white_concrete
fill 156 73 369 160 76 369 minecraft:purple_concrete
setblock 159 73 410 minecraft:white_concrete
fill 160 73 411 161 73 411 minecraft:black_concrete
setblock 161 73 369 minecraft:black_concrete
fill 162 73 369 180 73 369 minecraft:purple_concrete
setblock 162 73 370 minecraft:white_concrete
fill 162 73 411 165 76 411 minecraft:purple_concrete
setblock 166 73 410 minecraft:white_concrete
setblock 166 73 411 minecraft:black_concrete
fill 167 73 411 168 76 411 minecraft:purple_concrete
setblock 169 73 370 minecraft:white_concrete
fill 169 73 411 170 73 411 minecraft:black_concrete
fill 171 73 411 172 76 411 minecraft:purple_concrete
setblock 173 73 410 minecraft:white_concrete
setblock 173 73 411 minecraft:black_concrete
fill 174 73 411 175 76 411 minecraft:purple_concrete
setblock 176 73 370 minecraft:white_concrete
fill 176 73 411 177 73 411 minecraft:black_concrete
fill 178 73 411 178 76 411 minecraft:purple_concrete
setblock 179 73 411 minecraft:black_concrete
setblock 180 73 410 minecraft:white_concrete
fill 180 73 411 183 74 411 minecraft:purple_concrete
setblock 181 73 369 minecraft:black_concrete
fill 182 73 369 182 74 369 minecraft:purple_concrete
setblock 182 73 371 minecraft:white_concrete
setblock 182 73 378 minecraft:white_concrete
setblock 182 73 385 minecraft:white_concrete
setblock 182 73 392 minecraft:white_concrete
setblock 182 73 399 minecraft:white_concrete
setblock 182 73 406 minecraft:white_concrete
fill 183 73 369 183 73 370 minecraft:black_concrete
fill 183 73 371 183 73 388 minecraft:purple_concrete
setblock 183 73 389 minecraft:black_concrete
fill 183 73 390 183 73 396 minecraft:purple_concrete
setblock 183 73 397 minecraft:black_concrete
fill 183 73 398 183 73 410 minecraft:purple_concrete
fill 141 74 384 141 76 384 minecraft:purple_concrete
fill 141 74 387 141 76 387 minecraft:purple_concrete
fill 141 74 389 141 76 389 minecraft:purple_concrete
fill 141 74 395 141 74 402 minecraft:purple_concrete
setblock 141 74 403 minecraft:black_concrete
fill 141 74 404 141 74 409 minecraft:purple_concrete
setblock 142 74 372 minecraft:white_concrete
setblock 142 74 379 minecraft:white_concrete
setblock 142 74 386 minecraft:white_concrete
setblock 142 74 393 minecraft:white_concrete
setblock 142 74 400 minecraft:white_concrete
setblock 142 74 407 minecraft:white_concrete
fill 142 74 411 143 76 411 minecraft:purple_concrete
fill 144 74 411 145 74 411 minecraft:black_concrete
setblock 146 74 410 minecraft:white_concrete
fill 146 74 411 161 74 411 minecraft:purple_concrete
setblock 147 74 370 minecraft:white_concrete
setblock 148 74 369 minecraft:purple_concrete
fill 149 74 369 150 74 369 minecraft:black_concrete
fill 151 74 369 155 74 369 minecraft:purple_concrete
setblock 153 74 410 minecraft:white_concrete
setblock 154 74 370 minecraft:white_concrete
setblock 160 74 410 minecraft:white_concrete
fill 161 74 369 176 74 369 minecraft:purple_concrete
setblock 161 74 370 minecraft:white_concrete
fill 166 74 411 166 76 411 minecraft:purple_concrete
setblock 167 74 410 minecraft:white_concrete
setblock 168 74 370 minecraft:white_concrete
fill 169 74 408 169 83 408 minecraft:purple_wool
fill 169 74 411 170 74 411 minecraft:purple_concrete
fill 173 74 411 173 76 411 minecraft:purple_concrete
setblock 174 74 410 minecraft:white_concrete
setblock 175 74 370 minecraft:white_concrete
fill 176 74 411 177 76 411 minecraft:purple_concrete
fill 177 74 369 178 74 369 minecraft:black_concrete
fill 179 74 369 179 77 369 minecraft:purple_concrete
fill 179 74 411 179 77 411 minecraft:purple_concrete
setblock 180 74 369 minecraft:black_concrete
fill 181 74 369 181 76 369 minecraft:purple_concrete
setblock 181 74 410 minecraft:white_concrete
setblock 182 74 370 minecraft:white_concrete
setblock 182 74 377 minecraft:white_concrete
setblock 182 74 384 minecraft:white_concrete
setblock 182 74 391 minecraft:white_concrete
setblock 182 74 398 minecraft:white_concrete
setblock 182 74 405 minecraft:white_concrete
fill 183 74 369 183 74 371 minecraft:purple_concrete
setblock 183 74 372 minecraft:black_concrete
fill 183 74 373 183 74 391 minecraft:purple_concrete
setblock 183 74 392 minecraft:black_concrete
fill 183 74 393 183 76 397 minecraft:purple_concrete
setblock 183 74 398 minecraft:black_concrete
fill 183 74 399 183 74 403 minecraft:purple_concrete
setblock 183 74 404 minecraft:black_concrete
fill 183 74 405 183 76 406 minecraft:purple_concrete
setblock 183 74 407 minecraft:black_concrete
fill 183 74 408 183 74 410 minecraft:purple_concrete
setblock 141 75 369 minecraft:black_concrete
fill 141 75 370 141 76 372 minecraft:purple_concrete
setblock 141 75 373 minecraft:black_concrete
fill 141 75 374 141 76 377 minecraft:purple_concrete
setblock 141 75 378 minecraft:black_concrete
fill 141 75 379 141 76 383 minecraft:purple_concrete
fill 141 75 395 141 75 396 minecraft:black_concrete
fill 141 75 397 141 76 399 minecraft:purple_concrete
setblock 141 75 400 minecraft:black_concrete
fill 141 75 401 141 76 403 minecraft:purple_concrete
setblock 141 75 404 minecraft:black_concrete
fill 141 75 405 141 76 410 minecraft:purple_concrete
setblock 141 75 411 minecraft:black_concrete
setblock 142 75 373 minecraft:white_concrete
setblock 142 75 380 minecraft:white_concrete
setblock 142 75 387 minecraft:white_concrete
setblock 142 75 394 minecraft:white_concrete
setblock 142 75 401 minecraft:white_concrete
setblock 142 75 408 minecraft:white_concrete
setblock 144 75 372 minecraft:light[level=14]
setblock 144 75 380 minecraft:light[level=14]
setblock 144 75 388 minecraft:light[level=14]
setblock 144 75 396 minecraft:light[level=14]
setblock 144 75 404 minecraft:light[level=14]
fill 144 75 411 154 76 411 minecraft:purple_concrete
setblock 146 75 370 minecraft:white_concrete
setblock 147 75 410 minecraft:white_concrete
setblock 148 75 369 minecraft:black_concrete
fill 149 75 369 152 76 369 minecraft:purple_concrete
setblock 152 75 372 minecraft:light[level=14]
setblock 152 75 380 minecraft:light[level=14]
setblock 152 75 388 minecraft:light[level=14]
setblock 152 75 396 minecraft:light[level=14]
setblock 152 75 404 minecraft:light[level=14]
setblock 153 75 369 minecraft:black_concrete
setblock 153 75 370 minecraft:white_concrete
fill 154 75 369 155 76 369 minecraft:purple_concrete
setblock 154 75 410 minecraft:white_concrete
setblock 155 75 411 minecraft:black_concrete
fill 156 75 411 161 76 411 minecraft:purple_concrete
setblock 160 75 370 minecraft:white_concrete
setblock 160 75 372 minecraft:light[level=14]
setblock 160 75 380 minecraft:light[level=14]
setblock 160 75 388 minecraft:light[level=14]
setblock 160 75 396 minecraft:light[level=14]
setblock 160 75 404 minecraft:light[level=14]
fill 161 75 369 165 76 369 minecraft:purple_concrete
setblock 161 75 410 minecraft:white_concrete
setblock 166 75 369 minecraft:black_concrete
fill 167 75 369 171 76 369 minecraft:purple_concrete
setblock 167 75 370 minecraft:white_concrete
fill 167 75 408 168 83 408 minecraft:purple_wool
setblock 168 75 372 minecraft:light[level=14]
setblock 168 75 380 minecraft:light[level=14]
setblock 168 75 388 minecraft:light[level=14]
setblock 168 75 396 minecraft:light[level=14]
setblock 168 75 404 minecraft:light[level=14]
setblock 168 75 410 minecraft:white_concrete
setblock 169 75 411 minecraft:black_concrete
fill 170 75 408 171 83 408 minecraft:purple_wool
fill 170 75 411 170 76 411 minecraft:purple_concrete
setblock 172 75 369 minecraft:black_concrete
fill 173 75 369 178 76 369 minecraft:purple_concrete
setblock 174 75 370 minecraft:white_concrete
setblock 175 75 410 minecraft:white_concrete
setblock 176 75 372 minecraft:light[level=14]
setblock 176 75 380 minecraft:light[level=14]
setblock 176 75 388 minecraft:light[level=14]
setblock 176 75 396 minecraft:light[level=14]
setblock 176 75 404 minecraft:light[level=14]
fill 180 75 369 180 77 369 minecraft:purple_concrete
setblock 180 75 411 minecraft:black_concrete
setblock 181 75 370 minecraft:white_concrete
fill 181 75 411 183 76 411 minecraft:purple_concrete
setblock 182 75 369 minecraft:black_concrete
setblock 182 75 376 minecraft:white_concrete
setblock 182 75 383 minecraft:white_concrete
setblock 182 75 390 minecraft:white_concrete
setblock 182 75 397 minecraft:white_concrete
setblock 182 75 404 minecraft:white_concrete
setblock 182 75 410 minecraft:white_concrete
fill 183 75 369 183 76 370 minecraft:purple_concrete
setblock 183 75 371 minecraft:black_concrete
fill 183 75 372 183 76 379 minecraft:purple_concrete
setblock 183 75 380 minecraft:black_concrete
fill 183 75 381 183 76 388 minecraft:purple_concrete
setblock 183 75 389 minecraft:black_concrete
fill 183 75 390 183 76 392 minecraft:purple_concrete
fill 183 75 398 183 76 402 minecraft:purple_concrete
setblock 183 75 403 minecraft:black_concrete
fill 183 75 404 183 76 404 minecraft:purple_concrete
fill 183 75 407 183 76 408 minecraft:purple_concrete
setblock 183 75 409 minecraft:black_concrete
fill 183 75 410 183 76 410 minecraft:purple_concrete
setblock 141 76 369 minecraft:purple_concrete
setblock 141 76 373 minecraft:purple_concrete
setblock 141 76 378 minecraft:purple_concrete
fill 141 76 395 141 76 396 minecraft:purple_concrete
setblock 141 76 400 minecraft:purple_concrete
setblock 141 76 404 minecraft:purple_concrete
setblock 141 76 411 minecraft:purple_concrete
setblock 142 76 374 minecraft:white_concrete
setblock 142 76 381 minecraft:white_concrete
setblock 142 76 388 minecraft:white_concrete
setblock 142 76 395 minecraft:white_concrete
setblock 142 76 402 minecraft:white_concrete
setblock 142 76 409 minecraft:white_concrete
setblock 145 76 370 minecraft:white_concrete
fill 148 76 369 148 77 369 minecraft:purple_concrete
setblock 148 76 410 minecraft:white_concrete
fill 149 76 371 149 87 371 minecraft:purple_wool
setblock 152 76 370 minecraft:white_concrete
setblock 153 76 369 minecraft:purple_concrete
setblock 155 76 410 minecraft:white_concrete
setblock 155 76 411 minecraft:purple_concrete
setblock 159 76 370 minecraft:white_concrete
setblock 162 76 410 minecraft:white_concrete
setblock 166 76 369 minecraft:purple_concrete
setblock 166 76 370 minecraft:white_concrete
setblock 169 76 410 minecraft:white_concrete
setblock 169 76 411 minecraft:purple_concrete
setblock 172 76 369 minecraft:purple_concrete
setblock 173 76 370 minecraft:white_concrete
setblock 176 76 410 minecraft:white_concrete
setblock 180 76 370 minecraft:white_concrete
setblock 180 76 411 minecraft:purple_concrete
fill 182 76 369 182 77 369 minecraft:purple_concrete
setblock 182 76 375 minecraft:white_concrete
setblock 182 76 382 minecraft:white_concrete
setblock 182 76 389 minecraft:white_concrete
setblock 182 76 396 minecraft:white_concrete
setblock 182 76 403 minecraft:white_concrete
setblock 183 76 371 minecraft:purple_concrete
setblock 183 76 380 minecraft:purple_concrete
setblock 183 76 389 minecraft:purple_concrete
setblock 183 76 403 minecraft:purple_concrete
setblock 183 76 409 minecraft:purple_concrete
fill 141 77 369 141 77 385 minecraft:black_concrete
setblock 141 77 386 minecraft:purple_concrete
fill 141 77 387 141 77 394 minecraft:black_concrete
setblock 141 77 395 minecraft:purple_concrete
fill 141 77 396 141 77 406 minecraft:black_concrete
setblock 141 77 407 minecraft:purple_concrete
fill 141 77 408 141 190 408 minecraft:black_concrete
fill 141 77 409 141 78 409 minecraft:purple_concrete
fill 141 77 410 141 77 411 minecraft:black_concrete
fill 142 77 369 147 77 369 minecraft:black_concrete
fill 142 77 411 151 78 411 minecraft:black_concrete
fill 147 77 371 148 87 371 minecraft:purple_wool
fill 149 77 369 157 77 369 minecraft:black_concrete
fill 150 77 371 151 87 371 minecraft:purple_wool
setblock 152 77 411 minecraft:purple_concrete
fill 153 77 411 157 77 411 minecraft:black_concrete
setblock 158 77 369 minecraft:purple_concrete
setblock 158 77 411 minecraft:purple_concrete
fill 159 77 369 159 190 369 minecraft:black_concrete
fill 159 77 411 174 189 411 minecraft:black_concrete
setblock 160 77 369 minecraft:purple_concrete
fill 161 77 369 175 77 369 minecraft:black_concrete
setblock 175 77 411 minecraft:purple_concrete
setblock 176 77 369 minecraft:purple_concrete
fill 176 77 411 178 78 411 minecraft:black_concrete
fill 177 77 369 178 188 369 minecraft:black_concrete
fill 180 77 411 183 78 411 minecraft:black_concrete
fill 181 77 369 181 189 369 minecraft:black_concrete
fill 183 77 369 183 77 375 minecraft:black_concrete
setblock 183 77 376 minecraft:purple_concrete
fill 183 77 377 183 77 407 minecraft:black_concrete
setblock 183 77 408 minecraft:purple_concrete
fill 183 77 409 183 78 410 minecraft:black_concrete
fill 141 78 369 142 78 369 minecraft:purple_concrete
fill 141 78 370 141 188 374 minecraft:black_concrete
setblock 141 78 375 minecraft:purple_concrete
fill 141 78 376 141 78 380 minecraft:black_concrete
setblock 141 78 381 minecraft:purple_concrete
fill 141 78 382 141 192 382 minecraft:black_concrete
setblock 141 78 383 minecraft:purple_concrete
fill 141 78 384 141 188 387 minecraft:black_concrete
setblock 141 78 388 minecraft:purple_concrete
fill 141 78 389 141 188 396 minecraft:black_concrete
setblock 141 78 397 minecraft:purple_concrete
fill 141 78 398 141 189 403 minecraft:black_concrete
setblock 141 78 404 minecraft:purple_concrete
fill 141 78 405 141 192 407 minecraft:black_concrete
fill 141 78 410 141 78 411 minecraft:purple_concrete
setblock 142 78 376 minecraft:white_concrete
setblock 142 78 383 minecraft:white_concrete
setblock 142 78 390 minecraft:white_concrete
setblock 142 78 397 minecraft:white_concrete
setblock 142 78 404 minecraft:white_concrete
fill 143 78 369 152 188 369 minecraft:black_concrete
setblock 143 78 370 minecraft:white_concrete
setblock 143 78 410 minecraft:white_concrete
setblock 150 78 370 minecraft:white_concrete
setblock 150 78 410 minecraft:white_concrete
fill 152 78 411 153 78 411 minecraft:black_concrete
setblock 153 78 369 minecraft:purple_concrete
fill 154 78 369 158 78 369 minecraft:black_concrete
setblock 154 78 411 minecraft:purple_concrete
fill 155 78 411 156 192 411 minecraft:black_concrete
setblock 157 78 370 minecraft:white_concrete
setblock 157 78 410 minecraft:white_concrete
setblock 157 78 411 minecraft:purple_concrete
fill 158 78 411 158 192 411 minecraft:black_concrete
fill 160 78 369 163 78 369 minecraft:black_concrete
setblock 164 78 369 minecraft:purple_concrete
setblock 164 78 370 minecraft:white_concrete
setblock 164 78 410 minecraft:white_concrete
fill 165 78 369 176 78 369 minecraft:black_concrete
setblock 171 78 370 minecraft:white_concrete
setblock 171 78 410 minecraft:white_concrete
fill 175 78 411 175 189 411 minecraft:black_concrete
setblock 178 78 370 minecraft:white_concrete
setblock 178 78 410 minecraft:white_concrete
fill 179 78 369 180 192 369 minecraft:black_concrete
fill 179 78 411 179 193 411 minecraft:black_concrete
fill 182 78 369 183 188 369 minecraft:black_concrete
setblock 182 78 373 minecraft:white_concrete
setblock 182 78 380 minecraft:white_concrete
setblock 182 78 387 minecraft:white_concrete
setblock 182 78 394 minecraft:white_concrete
setblock 182 78 401 minecraft:white_concrete
setblock 182 78 408 minecraft:white_concrete
setblock 183 78 370 minecraft:purple_concrete
fill 183 78 371 183 188 373 minecraft:black_concrete
setblock 183 78 374 minecraft:purple_concrete
fill 183 78 375 183 78 386 minecraft:black_concrete
setblock 183 78 387 minecraft:purple_concrete
fill 183 78 388 183 192 388 minecraft:black_concrete
setblock 183 78 389 minecraft:purple_concrete
fill 183 78 390 183 192 390 minecraft:black_concrete
setblock 183 78 391 minecraft:purple_concrete
fill 183 78 392 183 190 393 minecraft:black_concrete
setblock 183 78 394 minecraft:purple_concrete
fill 183 78 395 183 78 408 minecraft:black_concrete
fill 141 79 369 142 192 369 minecraft:black_concrete
fill 141 79 375 141 188 376 minecraft:black_concrete
setblock 141 79 377 minecraft:purple_concrete
fill 141 79 378 141 190 381 minecraft:black_concrete
fill 141 79 383 141 192 383 minecraft:black_concrete
fill 141 79 388 141 192 388 minecraft:black_concrete
fill 141 79 397 141 190 397 minecraft:black_concrete
fill 141 79 404 141 192 404 minecraft:black_concrete
fill 141 79 409 141 192 410 minecraft:black_concrete
setblock 141 79 411 minecraft:purple_concrete
fill 142 79 370 142 80 370 minecraft:white_concrete
fill 142 79 377 142 80 377 minecraft:white_concrete
fill 142 79 384 142 80 384 minecraft:white_concrete
fill 142 79 391 142 80 391 minecraft:white_concrete
fill 142 79 398 142 80 398 minecraft:white_concrete
fill 142 79 405 142 80 405 minecraft:white_concrete
fill 142 79 411 144 192 411 minecraft:black_concrete
fill 144 79 410 144 80 410 minecraft:white_concrete
setblock 145 79 411 minecraft:purple_concrete
fill 146 79 411 147 190 411 minecraft:black_concrete
setblock 148 79 411 minecraft:purple_concrete
fill 149 79 370 149 80 370 minecraft:white_concrete
fill 149 79 411 151 192 411 minecraft:black_concrete
fill 151 79 410 151 80 410 minecraft:white_concrete
fill 152 79 411 153 79 411 minecraft:purple_concrete
fill 153 79 369 153 192 369 minecraft:black_concrete
setblock 154 79 369 minecraft:purple_concrete
fill 154 79 411 154 192 411 minecraft:black_concrete
fill 155 79 369 158 188 369 minecraft:black_concrete
fill 156 79 370 156 80 370 minecraft:white_concrete
fill 157 79 411 157 192 411 minecraft:black_concrete
fill 158 79 410 158 80 410 minecraft:white_concrete
fill 160 79 369 162 188 369 minecraft:black_concrete
setblock 163 79 369 minecraft:purple_concrete
fill 163 79 370 163 80 370 minecraft:white_concrete
fill 164 79 369 166 190 369 minecraft:black_concrete
fill 165 79 410 165 80 410 minecraft:white_concrete
setblock 167 79 369 minecraft:purple_concrete
fill 168 79 369 168 189 369 minecraft:black_concrete
fill 169 79 369 170 79 369 minecraft:purple_concrete
fill 170 79 370 170 80 370 minecraft:white_concrete
fill 171 79 369 176 190 369 minecraft:black_concrete
fill 172 79 410 172 80 410 minecraft:white_concrete
fill 176 79 411 177 192 411 minecraft:black_concrete
fill 177 79 370 177 80 370 minecraft:white_concrete
setblock 178 79 411 minecraft:purple_concrete
fill 179 79 410 179 80 410 minecraft:white_concrete
fill 180 79 396 180 80 402 minecraft:gray_concrete
fill 180 79 411 181 192 411 minecraft:black_concrete
fill 182 79 372 182 80 372 minecraft:white_concrete
fill 182 79 379 182 80 379 minecraft:white_concrete
fill 182 79 386 182 80 386 minecraft:white_concrete
fill 182 79 393 182 80 393 minecraft:white_concrete
fill 182 79 400 182 80 400 minecraft:white_concrete
fill 182 79 407 182 80 407 minecraft:white_concrete
setblock 182 79 411 minecraft:purple_concrete
fill 183 79 370 183 192 370 minecraft:black_concrete
fill 183 79 374 183 188 381 minecraft:black_concrete
setblock 183 79 382 minecraft:purple_concrete
fill 183 79 383 183 192 383 minecraft:black_concrete
setblock 183 79 384 minecraft:purple_concrete
fill 183 79 385 183 192 387 minecraft:black_concrete
fill 183 79 389 183 192 389 minecraft:black_concrete
fill 183 79 391 183 189 391 minecraft:black_concrete
fill 183 79 394 183 188 395 minecraft:black_concrete
setblock 183 79 396 minecraft:purple_concrete
fill 183 79 397 183 188 408 minecraft:black_concrete
setblock 183 79 409 minecraft:purple_concrete
fill 183 79 410 183 189 411 minecraft:black_concrete
fill 141 80 377 141 193 377 minecraft:black_concrete
fill 141 80 411 141 193 411 minecraft:black_concrete
fill 142 80 371 142 80 374 minecraft:white_concrete
setblock 142 80 376 minecraft:white_concrete
fill 142 80 378 142 80 381 minecraft:white_concrete
setblock 142 80 383 minecraft:white_concrete
fill 142 80 385 142 80 388 minecraft:white_concrete
setblock 142 80 390 minecraft:white_concrete
fill 142 80 392 142 80 395 minecraft:white_concrete
setblock 142 80 397 minecraft:white_concrete
fill 142 80 399 142 80 402 minecraft:white_concrete
setblock 142 80 404 minecraft:white_concrete
fill 142 80 406 142 80 409 minecraft:white_concrete
setblock 143 80 370 minecraft:white_concrete
setblock 143 80 410 minecraft:white_concrete
fill 145 80 370 148 80 370 minecraft:white_concrete
fill 145 80 410 148 80 410 minecraft:white_concrete
fill 145 80 411 145 189 411 minecraft:black_concrete
fill 148 80 411 148 192 411 minecraft:black_concrete
setblock 150 80 370 minecraft:white_concrete
setblock 150 80 410 minecraft:white_concrete
fill 152 80 370 155 80 370 minecraft:white_concrete
fill 152 80 410 155 80 410 minecraft:white_concrete
fill 152 80 411 153 192 411 minecraft:black_concrete
fill 154 80 369 154 189 369 minecraft:black_concrete
setblock 157 80 370 minecraft:white_concrete
setblock 157 80 410 minecraft:white_concrete
fill 159 80 370 162 80 370 minecraft:white_concrete
fill 159 80 410 162 80 410 minecraft:white_concrete
fill 163 80 369 163 192 369 minecraft:black_concrete
setblock 164 80 370 minecraft:white_concrete
setblock 164 80 410 minecraft:white_concrete
fill 166 80 370 169 80 370 minecraft:white_concrete
fill 166 80 410 169 80 410 minecraft:white_concrete
fill 167 80 369 167 189 369 minecraft:black_concrete
fill 169 80 369 170 192 369 minecraft:black_concrete
setblock 171 80 370 minecraft:white_concrete
setblock 171 80 410 minecraft:white_concrete
fill 173 80 370 176 80 370 minecraft:white_concrete
fill 173 80 410 176 80 410 minecraft:white_concrete
setblock 178 80 370 minecraft:white_concrete
setblock 178 80 410 minecraft:white_concrete
fill 178 80 411 178 192 411 minecraft:black_concrete
fill 180 80 370 182 80 370 minecraft:white_concrete
fill 180 80 410 182 80 410 minecraft:white_concrete
setblock 182 80 371 minecraft:white_concrete
setblock 182 80 373 minecraft:white_concrete
fill 182 80 375 182 80 378 minecraft:white_concrete
setblock 182 80 380 minecraft:white_concrete
fill 182 80 382 182 80 385 minecraft:white_concrete
setblock 182 80 387 minecraft:white_concrete
fill 182 80 389 182 80 392 minecraft:white_concrete
setblock 182 80 394 minecraft:white_concrete
fill 182 80 396 182 80 399 minecraft:white_concrete
setblock 182 80 401 minecraft:white_concrete
fill 182 80 403 182 80 406 minecraft:white_concrete
setblock 182 80 408 minecraft:white_concrete
fill 182 80 411 182 192 411 minecraft:black_concrete
fill 183 80 382 183 190 382 minecraft:black_concrete
fill 183 80 384 183 192 384 minecraft:black_concrete
fill 183 80 396 183 192 396 minecraft:black_concrete
fill 183 80 409 183 192 409 minecraft:black_concrete
setblock 142 81 372 minecraft:white_concrete
setblock 142 81 379 minecraft:white_concrete
setblock 142 81 386 minecraft:white_concrete
setblock 142 81 393 minecraft:white_concrete
setblock 142 81 400 minecraft:white_concrete
setblock 142 81 407 minecraft:white_concrete
setblock 146 81 410 minecraft:white_concrete
setblock 147 81 370 minecraft:white_concrete
setblock 153 81 410 minecraft:white_concrete
setblock 154 81 370 minecraft:white_concrete
setblock 160 81 410 minecraft:white_concrete
setblock 161 81 370 minecraft:white_concrete
setblock 167 81 410 minecraft:white_concrete
setblock 168 81 370 minecraft:white_concrete
setblock 174 81 410 minecraft:white_concrete
setblock 175 81 370 minecraft:white_concrete
setblock 181 81 410 minecraft:white_concrete
setblock 182 81 370 minecraft:white_concrete
setblock 182 81 377 minecraft:white_concrete
setblock 182 81 384 minecraft:white_concrete
setblock 182 81 391 minecraft:white_concrete
setblock 182 81 398 minecraft:white_concrete
setblock 182 81 405 minecraft:white_concrete
setblock 142 82 373 minecraft:white_concrete
setblock 142 82 380 minecraft:white_concrete
setblock 142 82 387 minecraft:white_concrete
setblock 142 82 394 minecraft:white_concrete
setblock 142 82 401 minecraft:white_concrete
setblock 142 82 408 minecraft:white_concrete
setblock 146 82 370 minecraft:white_concrete
setblock 147 82 410 minecraft:white_concrete
setblock 153 82 370 minecraft:white_concrete
setblock 154 82 410 minecraft:white_concrete
setblock 160 82 370 minecraft:white_concrete
setblock 161 82 410 minecraft:white_concrete
setblock 167 82 370 minecraft:white_concrete
setblock 168 82 410 minecraft:white_concrete
setblock 174 82 370 minecraft:white_concrete
setblock 175 82 410 minecraft:white_concrete
setblock 181 82 370 minecraft:white_concrete
setblock 182 82 376 minecraft:white_concrete
setblock 182 82 383 minecraft:white_concrete
setblock 182 82 390 minecraft:white_concrete
setblock 182 82 397 minecraft:white_concrete
setblock 182 82 404 minecraft:white_concrete
setblock 182 82 410 minecraft:white_concrete
setblock 142 83 374 minecraft:white_concrete
setblock 142 83 381 minecraft:white_concrete
setblock 142 83 388 minecraft:white_concrete
setblock 142 83 395 minecraft:white_concrete
setblock 142 83 402 minecraft:white_concrete
setblock 142 83 409 minecraft:white_concrete
setblock 144 83 372 minecraft:light[level=14]
setblock 144 83 380 minecraft:light[level=14]
setblock 144 83 388 minecraft:light[level=14]
setblock 144 83 396 minecraft:light[level=14]
setblock 144 83 404 minecraft:light[level=14]
setblock 145 83 370 minecraft:white_concrete
setblock 148 83 410 minecraft:white_concrete
setblock 152 83 370 minecraft:white_concrete
setblock 152 83 372 minecraft:light[level=14]
setblock 152 83 380 minecraft:light[level=14]
setblock 152 83 388 minecraft:light[level=14]
setblock 152 83 396 minecraft:light[level=14]
setblock 152 83 404 minecraft:light[level=14]
setblock 155 83 410 minecraft:white_concrete
setblock 159 83 370 minecraft:white_concrete
setblock 160 83 372 minecraft:light[level=14]
setblock 160 83 380 minecraft:light[level=14]
setblock 160 83 388 minecraft:light[level=14]
setblock 160 83 396 minecraft:light[level=14]
setblock 160 83 404 minecraft:light[level=14]
setblock 162 83 410 minecraft:white_concrete
setblock 166 83 370 minecraft:white_concrete
setblock 168 83 372 minecraft:light[level=14]
setblock 168 83 380 minecraft:light[level=14]
setblock 168 83 388 minecraft:light[level=14]
setblock 168 83 396 minecraft:light[level=14]
setblock 168 83 404 minecraft:light[level=14]
setblock 169 83 410 minecraft:white_concrete
setblock 173 83 370 minecraft:white_concrete
setblock 176 83 372 minecraft:light[level=14]
setblock 176 83 380 minecraft:light[level=14]
setblock 176 83 388 minecraft:light[level=14]
setblock 176 83 396 minecraft:light[level=14]
setblock 176 83 404 minecraft:light[level=14]
setblock 176 83 410 minecraft:white_concrete
setblock 180 83 370 minecraft:white_concrete
setblock 182 83 375 minecraft:white_concrete
setblock 182 83 382 minecraft:white_concrete
setblock 182 83 389 minecraft:white_concrete
setblock 182 83 396 minecraft:white_concrete
setblock 182 83 403 minecraft:white_concrete
fill 166 84 408 172 85 408 minecraft:gray_concrete
setblock 142 85 376 minecraft:white_concrete
setblock 142 85 383 minecraft:white_concrete
setblock 142 85 390 minecraft:white_concrete
setblock 142 85 397 minecraft:white_concrete
setblock 142 85 404 minecraft:white_concrete
setblock 143 85 370 minecraft:white_concrete
setblock 143 85 410 minecraft:white_concrete
setblock 150 85 370 minecraft:white_concrete
setblock 150 85 410 minecraft:white_concrete
setblock 157 85 370 minecraft:white_concrete
setblock 157 85 410 minecraft:white_concrete
setblock 164 85 370 minecraft:white_concrete
setblock 164 85 410 minecraft:white_concrete
setblock 171 85 370 minecraft:white_concrete
setblock 171 85 410 minecraft:white_concrete
setblock 178 85 370 minecraft:white_concrete
setblock 178 85 410 minecraft:white_concrete
setblock 182 85 373 minecraft:white_concrete
setblock 182 85 380 minecraft:white_concrete
setblock 182 85 387 minecraft:white_concrete
setblock 182 85 394 minecraft:white_concrete
setblock 182 85 401 minecraft:white_concrete
setblock 182 85 408 minecraft:white_concrete
setblock 142 86 370 minecraft:white_concrete
setblock 142 86 377 minecraft:white_concrete
setblock 142 86 384 minecraft:white_concrete
setblock 142 86 391 minecraft:white_concrete
setblock 142 86 398 minecraft:white_concrete
setblock 142 86 405 minecraft:white_concrete
setblock 144 86 410 minecraft:white_concrete
setblock 149 86 370 minecraft:white_concrete
setblock 151 86 410 minecraft:white_concrete
setblock 156 86 370 minecraft:white_concrete
setblock 158 86 410 minecraft:white_concrete
setblock 163 86 370 minecraft:white_concrete
setblock 165 86 410 minecraft:white_concrete
setblock 170 86 370 minecraft:white_concrete
setblock 172 86 410 minecraft:white_concrete
setblock 177 86 370 minecraft:white_concrete
setblock 179 86 410 minecraft:white_concrete
setblock 182 86 372 minecraft:white_concrete
setblock 182 86 379 minecraft:white_concrete
setblock 182 86 386 minecraft:white_concrete
setblock 182 86 393 minecraft:white_concrete
setblock 182 86 400 minecraft:white_concrete
setblock 182 86 407 minecraft:white_concrete
setblock 142 87 371 minecraft:white_concrete
setblock 142 87 378 minecraft:white_concrete
setblock 142 87 385 minecraft:white_concrete
setblock 142 87 392 minecraft:white_concrete
setblock 142 87 399 minecraft:white_concrete
setblock 142 87 406 minecraft:white_concrete
setblock 145 87 410 minecraft:white_concrete
setblock 148 87 370 minecraft:white_concrete
setblock 152 87 410 minecraft:white_concrete
fill 154 87 405 154 88 405 minecraft:red_wool
setblock 155 87 370 minecraft:white_concrete
setblock 159 87 410 minecraft:white_concrete
setblock 162 87 370 minecraft:white_concrete
setblock 166 87 410 minecraft:white_concrete
setblock 169 87 370 minecraft:white_concrete
setblock 173 87 410 minecraft:white_concrete
setblock 176 87 370 minecraft:white_concrete
setblock 180 87 410 minecraft:white_concrete
setblock 182 87 371 minecraft:white_concrete
setblock 182 87 378 minecraft:white_concrete
setblock 182 87 385 minecraft:white_concrete
setblock 182 87 392 minecraft:white_concrete
setblock 182 87 399 minecraft:white_concrete
setblock 182 87 406 minecraft:white_concrete
setblock 142 88 372 minecraft:white_concrete
setblock 142 88 379 minecraft:white_concrete
setblock 142 88 386 minecraft:white_concrete
setblock 142 88 393 minecraft:white_concrete
setblock 142 88 400 minecraft:white_concrete
setblock 142 88 407 minecraft:white_concrete
fill 146 88 371 152 89 371 minecraft:gray_concrete
setblock 146 88 410 minecraft:white_concrete
setblock 147 88 370 minecraft:white_concrete
setblock 153 88 410 minecraft:white_concrete
setblock 154 88 370 minecraft:white_concrete
setblock 160 88 410 minecraft:white_concrete
setblock 161 88 370 minecraft:white_concrete
fill 163 88 401 164 89 402 minecraft:red_wool
fill 164 88 408 164 99 408 minecraft:purple_wool
setblock 167 88 410 minecraft:white_concrete
setblock 168 88 370 minecraft:white_concrete
setblock 174 88 410 minecraft:white_concrete
setblock 175 88 370 minecraft:white_concrete
setblock 181 88 410 minecraft:white_concrete
setblock 182 88 370 minecraft:white_concrete
setblock 182 88 377 minecraft:white_concrete
setblock 182 88 384 minecraft:white_concrete
setblock 182 88 391 minecraft:white_concrete
setblock 182 88 398 minecraft:white_concrete
setblock 182 88 405 minecraft:white_concrete
fill 142 89 373 142 90 373 minecraft:white_concrete
fill 142 89 380 142 90 380 minecraft:white_concrete
fill 142 89 387 142 90 387 minecraft:white_concrete
fill 142 89 394 142 90 394 minecraft:white_concrete
fill 142 89 401 142 90 401 minecraft:white_concrete
fill 142 89 408 142 90 408 minecraft:white_concrete
fill 146 89 370 146 90 370 minecraft:white_concrete
fill 147 89 410 147 90 410 minecraft:white_concrete
fill 153 89 370 153 90 370 minecraft:white_concrete
fill 154 89 410 154 90 410 minecraft:white_concrete
fill 160 89 370 160 90 370 minecraft:white_concrete
fill 161 89 410 161 90 410 minecraft:white_concrete
fill 162 89 408 163 99 408 minecraft:purple_wool
fill 165 89 408 166 99 408 minecraft:purple_wool
fill 167 89 370 167 90 370 minecraft:white_concrete
fill 168 89 410 168 90 410 minecraft:white_concrete
fill 174 89 370 174 90 370 minecraft:white_concrete
fill 175 89 410 175 90 410 minecraft:white_concrete
fill 181 89 370 181 90 370 minecraft:white_concrete
fill 182 89 376 182 90 376 minecraft:white_concrete
fill 182 89 383 182 90 383 minecraft:white_concrete
fill 182 89 390 182 90 390 minecraft:white_concrete
fill 182 89 397 182 90 397 minecraft:white_concrete
fill 182 89 404 182 90 404 minecraft:white_concrete
fill 182 89 410 182 90 410 minecraft:white_concrete
fill 142 90 370 142 90 372 minecraft:white_concrete
setblock 142 90 374 minecraft:white_concrete
fill 142 90 376 142 90 379 minecraft:white_concrete
setblock 142 90 381 minecraft:white_concrete
fill 142 90 383 142 90 386 minecraft:white_concrete
setblock 142 90 388 minecraft:white_concrete
fill 142 90 390 142 90 393 minecraft:white_concrete
setblock 142 90 395 minecraft:white_concrete
fill 142 90 397 142 90 400 minecraft:white_concrete
setblock 142 90 402 minecraft:white_concrete
fill 142 90 404 142 90 407 minecraft:white_concrete
setblock 142 90 409 minecraft:white_concrete
setblock 143 90 370 minecraft:white_concrete
fill 143 90 410 146 90 410 minecraft:white_concrete
setblock 145 90 370 minecraft:white_concrete
fill 147 90 370 150 90 370 minecraft:white_concrete
setblock 148 90 410 minecraft:white_concrete
fill 150 90 410 153 90 410 minecraft:white_concrete
setblock 152 90 370 minecraft:white_concrete
fill 154 90 370 157 90 370 minecraft:white_concrete
setblock 155 90 410 minecraft:white_concrete
fill 157 90 410 160 90 410 minecraft:white_concrete
setblock 159 90 370 minecraft:white_concrete
fill 161 90 370 164 90 370 minecraft:white_concrete
setblock 162 90 410 minecraft:white_concrete
fill 164 90 410 167 90 410 minecraft:white_concrete
setblock 166 90 370 minecraft:white_concrete
fill 168 90 370 171 90 370 minecraft:white_concrete
setblock 169 90 410 minecraft:white_concrete
fill 171 90 410 174 90 410 minecraft:white_concrete
setblock 173 90 370 minecraft:white_concrete
fill 175 90 370 178 90 370 minecraft:white_concrete
setblock 176 90 410 minecraft:white_concrete
fill 178 90 410 181 90 410 minecraft:white_concrete
setblock 180 90 370 minecraft:white_concrete
fill 182 90 370 182 90 373 minecraft:white_concrete
setblock 182 90 375 minecraft:white_concrete
fill 182 90 377 182 90 380 minecraft:white_concrete
setblock 182 90 382 minecraft:white_concrete
fill 182 90 384 182 90 387 minecraft:white_concrete
setblock 182 90 389 minecraft:white_concrete
fill 182 90 391 182 90 394 minecraft:white_concrete
setblock 182 90 396 minecraft:white_concrete
fill 182 90 398 182 90 401 minecraft:white_concrete
setblock 182 90 403 minecraft:white_concrete
fill 182 90 405 182 90 408 minecraft:white_concrete
setblock 144 91 372 minecraft:light[level=14]
setblock 144 91 380 minecraft:light[level=14]
setblock 144 91 388 minecraft:light[level=14]
setblock 144 91 396 minecraft:light[level=14]
setblock 144 91 404 minecraft:light[level=14]
setblock 152 91 372 minecraft:light[level=14]
setblock 152 91 380 minecraft:light[level=14]
setblock 152 91 388 minecraft:light[level=14]
setblock 152 91 396 minecraft:light[level=14]
setblock 152 91 404 minecraft:light[level=14]
setblock 160 91 372 minecraft:light[level=14]
setblock 160 91 380 minecraft:light[level=14]
setblock 160 91 388 minecraft:light[level=14]
setblock 160 91 396 minecraft:light[level=14]
setblock 160 91 404 minecraft:light[level=14]
setblock 168 91 372 minecraft:light[level=14]
setblock 168 91 380 minecraft:light[level=14]
setblock 168 91 388 minecraft:light[level=14]
setblock 168 91 396 minecraft:light[level=14]
setblock 168 91 404 minecraft:light[level=14]
setblock 176 91 372 minecraft:light[level=14]
setblock 176 91 380 minecraft:light[level=14]
setblock 176 91 388 minecraft:light[level=14]
setblock 176 91 396 minecraft:light[level=14]
setblock 176 91 404 minecraft:light[level=14]
setblock 142 92 376 minecraft:white_concrete
setblock 142 92 383 minecraft:white_concrete
setblock 142 92 390 minecraft:white_concrete
setblock 142 92 397 minecraft:white_concrete
setblock 142 92 404 minecraft:white_concrete
setblock 143 92 370 minecraft:white_concrete
setblock 143 92 410 minecraft:white_concrete
setblock 150 92 370 minecraft:white_concrete
setblock 150 92 410 minecraft:white_concrete
setblock 157 92 370 minecraft:white_concrete
setblock 157 92 410 minecraft:white_concrete
setblock 164 92 370 minecraft:white_concrete
setblock 164 92 410 minecraft:white_concrete
setblock 171 92 370 minecraft:white_concrete
setblock 171 92 410 minecraft:white_concrete
setblock 178 92 370 minecraft:white_concrete
setblock 178 92 410 minecraft:white_concrete
setblock 182 92 373 minecraft:white_concrete
setblock 182 92 380 minecraft:white_concrete
setblock 182 92 387 minecraft:white_concrete
setblock 182 92 394 minecraft:white_concrete
setblock 182 92 401 minecraft:white_concrete
setblock 182 92 408 minecraft:white_concrete
setblock 142 93 370 minecraft:white_concrete
setblock 142 93 377 minecraft:white_concrete
setblock 142 93 384 minecraft:white_concrete
setblock 142 93 391 minecraft:white_concrete
setblock 142 93 398 minecraft:white_concrete
setblock 142 93 405 minecraft:white_concrete
setblock 144 93 410 minecraft:white_concrete
setblock 149 93 370 minecraft:white_concrete
setblock 151 93 410 minecraft:white_concrete
setblock 156 93 370 minecraft:white_concrete
setblock 158 93 410 minecraft:white_concrete
setblock 163 93 370 minecraft:white_concrete
setblock 165 93 410 minecraft:white_concrete
setblock 170 93 370 minecraft:white_concrete
setblock 172 93 410 minecraft:white_concrete
setblock 177 93 370 minecraft:white_concrete
setblock 179 93 410 minecraft:white_concrete
setblock 182 93 372 minecraft:white_concrete
setblock 182 93 379 minecraft:white_concrete
setblock 182 93 386 minecraft:white_concrete
setblock 182 93 393 minecraft:white_concrete
setblock 182 93 400 minecraft:white_concrete
setblock 182 93 407 minecraft:white_concrete
setblock 142 94 371 minecraft:white_concrete
setblock 142 94 378 minecraft:white_concrete
setblock 142 94 385 minecraft:white_concrete
setblock 142 94 392 minecraft:white_concrete
setblock 142 94 399 minecraft:white_concrete
setblock 142 94 406 minecraft:white_concrete
setblock 145 94 410 minecraft:white_concrete
setblock 148 94 370 minecraft:white_concrete
setblock 152 94 410 minecraft:white_concrete
setblock 155 94 370 minecraft:white_concrete
setblock 159 94 410 minecraft:white_concrete
setblock 162 94 370 minecraft:white_concrete
setblock 166 94 410 minecraft:white_concrete
setblock 169 94 370 minecraft:white_concrete
setblock 173 94 410 minecraft:white_concrete
setblock 176 94 370 minecraft:white_concrete
setblock 180 94 410 minecraft:white_concrete
setblock 182 94 371 minecraft:white_concrete
setblock 182 94 378 minecraft:white_concrete
setblock 182 94 385 minecraft:white_concrete
setblock 182 94 392 minecraft:white_concrete
setblock 182 94 399 minecraft:white_concrete
setblock 182 94 406 minecraft:white_concrete
setblock 142 95 372 minecraft:white_concrete
setblock 142 95 379 minecraft:white_concrete
setblock 142 95 386 minecraft:white_concrete
setblock 142 95 393 minecraft:white_concrete
setblock 142 95 400 minecraft:white_concrete
setblock 142 95 407 minecraft:white_concrete
setblock 146 95 410 minecraft:white_concrete
setblock 147 95 370 minecraft:white_concrete
setblock 153 95 410 minecraft:white_concrete
setblock 154 95 370 minecraft:white_concrete
setblock 160 95 410 minecraft:white_concrete
setblock 161 95 370 minecraft:white_concrete
setblock 167 95 410 minecraft:white_concrete
setblock 168 95 370 minecraft:white_concrete
setblock 174 95 410 minecraft:white_concrete
setblock 175 95 370 minecraft:white_concrete
setblock 181 95 410 minecraft:white_concrete
setblock 182 95 370 minecraft:white_concrete
setblock 182 95 377 minecraft:white_concrete
setblock 182 95 384 minecraft:white_concrete
setblock 182 95 391 minecraft:white_concrete
setblock 182 95 398 minecraft:white_concrete
setblock 182 95 405 minecraft:white_concrete
setblock 142 96 373 minecraft:white_concrete
setblock 142 96 380 minecraft:white_concrete
setblock 142 96 387 minecraft:white_concrete
setblock 142 96 394 minecraft:white_concrete
setblock 142 96 401 minecraft:white_concrete
setblock 142 96 408 minecraft:white_concrete
setblock 146 96 370 minecraft:white_concrete
setblock 147 96 410 minecraft:white_concrete
setblock 153 96 370 minecraft:white_concrete
setblock 154 96 410 minecraft:white_concrete
setblock 160 96 370 minecraft:white_concrete
setblock 161 96 410 minecraft:white_concrete
setblock 167 96 370 minecraft:white_concrete
setblock 168 96 410 minecraft:white_concrete
setblock 174 96 370 minecraft:white_concrete
setblock 175 96 410 minecraft:white_concrete
setblock 181 96 370 minecraft:white_concrete
setblock 182 96 376 minecraft:white_concrete
setblock 182 96 383 minecraft:white_concrete
setblock 182 96 390 minecraft:white_concrete
setblock 182 96 397 minecraft:white_concrete
setblock 182 96 404 minecraft:white_concrete
setblock 182 96 410 minecraft:white_concrete
setblock 142 97 374 minecraft:white_concrete
setblock 142 97 381 minecraft:white_concrete
setblock 142 97 388 minecraft:white_concrete
setblock 142 97 395 minecraft:white_concrete
setblock 142 97 402 minecraft:white_concrete
setblock 142 97 409 minecraft:white_concrete
setblock 145 97 370 minecraft:white_concrete
setblock 148 97 410 minecraft:white_concrete
setblock 152 97 370 minecraft:white_concrete
setblock 155 97 410 minecraft:white_concrete
setblock 159 97 370 minecraft:white_concrete
setblock 162 97 410 minecraft:white_concrete
setblock 166 97 370 minecraft:white_concrete
setblock 169 97 410 minecraft:white_concrete
setblock 173 97 370 minecraft:white_concrete
setblock 176 97 410 minecraft:white_concrete
setblock 180 97 370 minecraft:white_concrete
setblock 182 97 375 minecraft:white_concrete
setblock 182 97 382 minecraft:white_concrete
setblock 182 97 389 minecraft:white_concrete
setblock 182 97 396 minecraft:white_concrete
setblock 182 97 403 minecraft:white_concrete
fill 171 98 378 172 99 378 minecraft:purple_wool
fill 142 99 376 142 100 376 minecraft:white_concrete
fill 142 99 383 142 100 383 minecraft:white_concrete
fill 142 99 390 142 100 390 minecraft:white_concrete
fill 142 99 397 142 100 397 minecraft:white_concrete
fill 142 99 404 142 100 404 minecraft:white_concrete
fill 143 99 370 143 100 370 minecraft:white_concrete
fill 143 99 410 143 100 410 minecraft:white_concrete
setblock 144 99 372 minecraft:light[level=14]
setblock 144 99 380 minecraft:light[level=14]
setblock 144 99 388 minecraft:light[level=14]
setblock 144 99 396 minecraft:light[level=14]
setblock 144 99 404 minecraft:light[level=14]
fill 150 99 370 150 100 370 minecraft:white_concrete
fill 150 99 410 150 100 410 minecraft:white_concrete
setblock 152 99 372 minecraft:light[level=14]
setblock 152 99 380 minecraft:light[level=14]
setblock 152 99 388 minecraft:light[level=14]
setblock 152 99 396 minecraft:light[level=14]
setblock 152 99 404 minecraft:light[level=14]
fill 157 99 370 157 100 370 minecraft:white_concrete
fill 157 99 410 157 100 410 minecraft:white_concrete
setblock 160 99 372 minecraft:light[level=14]
setblock 160 99 380 minecraft:light[level=14]
setblock 160 99 388 minecraft:light[level=14]
setblock 160 99 396 minecraft:light[level=14]
setblock 160 99 404 minecraft:light[level=14]
fill 164 99 370 164 100 370 minecraft:white_concrete
fill 164 99 410 164 100 410 minecraft:white_concrete
setblock 168 99 372 minecraft:light[level=14]
setblock 168 99 380 minecraft:light[level=14]
setblock 168 99 388 minecraft:light[level=14]
setblock 168 99 396 minecraft:light[level=14]
setblock 168 99 404 minecraft:light[level=14]
fill 171 99 370 171 100 370 minecraft:white_concrete
fill 171 99 410 171 100 410 minecraft:white_concrete
setblock 176 99 372 minecraft:light[level=14]
setblock 176 99 380 minecraft:light[level=14]
setblock 176 99 388 minecraft:light[level=14]
setblock 176 99 396 minecraft:light[level=14]
setblock 176 99 404 minecraft:light[level=14]
fill 178 99 370 178 100 370 minecraft:white_concrete
fill 178 99 410 178 100 410 minecraft:white_concrete
fill 182 99 373 182 100 373 minecraft:white_concrete
fill 182 99 380 182 100 380 minecraft:white_concrete
fill 182 99 387 182 100 387 minecraft:white_concrete
fill 182 99 394 182 100 394 minecraft:white_concrete
fill 182 99 401 182 100 401 minecraft:white_concrete
fill 182 99 408 182 100 408 minecraft:white_concrete
fill 142 100 370 142 100 374 minecraft:white_concrete
fill 142 100 377 142 100 381 minecraft:white_concrete
fill 142 100 384 142 100 388 minecraft:white_concrete
fill 142 100 391 142 100 395 minecraft:white_concrete
fill 142 100 398 142 100 402 minecraft:white_concrete
fill 142 100 405 142 100 409 minecraft:white_concrete
fill 144 100 410 148 100 410 minecraft:white_concrete
fill 145 100 370 149 100 370 minecraft:white_concrete
fill 151 100 410 155 100 410 minecraft:white_concrete
fill 152 100 370 156 100 370 minecraft:white_concrete
fill 158 100 410 162 100 410 minecraft:white_concrete
fill 159 100 370 163 100 370 minecraft:white_concrete
fill 161 100 408 167 101 408 minecraft:gray_concrete
fill 165 100 410 169 100 410 minecraft:white_concrete
fill 166 100 370 170 100 370 minecraft:white_concrete
fill 172 100 410 176 100 410 minecraft:white_concrete
fill 173 100 370 177 100 370 minecraft:white_concrete
fill 179 100 410 182 100 410 minecraft:white_concrete
fill 180 100 370 182 100 370 minecraft:white_concrete
fill 182 100 371 182 100 372 minecraft:white_concrete
fill 182 100 375 182 100 379 minecraft:white_concrete
fill 182 100 382 182 100 386 minecraft:white_concrete
fill 182 100 389 182 100 393 minecraft:white_concrete
fill 182 100 396 182 100 400 minecraft:white_concrete
fill 182 100 403 182 100 407 minecraft:white_concrete
setblock 142 101 371 minecraft:white_concrete
setblock 142 101 378 minecraft:white_concrete
setblock 142 101 385 minecraft:white_concrete
setblock 142 101 392 minecraft:white_concrete
setblock 142 101 399 minecraft:white_concrete
setblock 142 101 406 minecraft:white_concrete
setblock 145 101 410 minecraft:white_concrete
setblock 148 101 370 minecraft:white_concrete
setblock 152 101 410 minecraft:white_concrete
setblock 155 101 370 minecraft:white_concrete
setblock 159 101 410 minecraft:white_concrete
setblock 162 101 370 minecraft:white_concrete
setblock 166 101 410 minecraft:white_concrete
setblock 169 101 370 minecraft:white_concrete
setblock 173 101 410 minecraft:white_concrete
setblock 176 101 370 minecraft:white_concrete
setblock 180 101 410 minecraft:white_concrete
setblock 182 101 371 minecraft:white_concrete
setblock 182 101 378 minecraft:white_concrete
setblock 182 101 385 minecraft:white_concrete
setblock 182 101 392 minecraft:white_concrete
setblock 182 101 399 minecraft:white_concrete
setblock 182 101 406 minecraft:white_concrete
setblock 142 102 372 minecraft:white_concrete
setblock 142 102 379 minecraft:white_concrete
setblock 142 102 386 minecraft:white_concrete
setblock 142 102 393 minecraft:white_concrete
setblock 142 102 400 minecraft:white_concrete
setblock 142 102 407 minecraft:white_concrete
setblock 146 102 410 minecraft:white_concrete
setblock 147 102 370 minecraft:white_concrete
setblock 153 102 410 minecraft:white_concrete
setblock 154 102 370 minecraft:white_concrete
setblock 160 102 410 minecraft:white_concrete
setblock 161 102 370 minecraft:white_concrete
setblock 167 102 410 minecraft:white_concrete
setblock 168 102 370 minecraft:white_concrete
setblock 174 102 410 minecraft:white_concrete
setblock 175 102 370 minecraft:white_concrete
setblock 181 102 410 minecraft:white_concrete
setblock 182 102 370 minecraft:white_concrete
setblock 182 102 377 minecraft:white_concrete
setblock 182 102 384 minecraft:white_concrete
setblock 182 102 391 minecraft:white_concrete
setblock 182 102 398 minecraft:white_concrete
setblock 182 102 405 minecraft:white_concrete
setblock 142 103 373 minecraft:white_concrete
setblock 142 103 380 minecraft:white_concrete
setblock 142 103 387 minecraft:white_concrete
setblock 142 103 394 minecraft:white_concrete
setblock 142 103 401 minecraft:white_concrete
setblock 142 103 408 minecraft:white_concrete
setblock 146 103 370 minecraft:white_concrete
setblock 147 103 410 minecraft:white_concrete
setblock 153 103 370 minecraft:white_concrete
setblock 154 103 410 minecraft:white_concrete
setblock 160 103 370 minecraft:white_concrete
setblock 161 103 410 minecraft:white_concrete
setblock 167 103 370 minecraft:white_concrete
setblock 168 103 410 minecraft:white_concrete
setblock 174 103 370 minecraft:white_concrete
setblock 175 103 410 minecraft:white_concrete
setblock 181 103 370 minecraft:white_concrete
setblock 182 103 376 minecraft:white_concrete
setblock 182 103 383 minecraft:white_concrete
setblock 182 103 390 minecraft:white_concrete
setblock 182 103 397 minecraft:white_concrete
setblock 182 103 404 minecraft:white_concrete
setblock 182 103 410 minecraft:white_concrete
setblock 142 104 374 minecraft:white_concrete
setblock 142 104 381 minecraft:white_concrete
setblock 142 104 388 minecraft:white_concrete
setblock 142 104 395 minecraft:white_concrete
setblock 142 104 402 minecraft:white_concrete
setblock 142 104 409 minecraft:white_concrete
setblock 145 104 370 minecraft:white_concrete
setblock 148 104 410 minecraft:white_concrete
setblock 152 104 370 minecraft:white_concrete
setblock 155 104 410 minecraft:white_concrete
setblock 159 104 370 minecraft:white_concrete
setblock 162 104 410 minecraft:white_concrete
setblock 166 104 370 minecraft:white_concrete
setblock 169 104 410 minecraft:white_concrete
setblock 173 104 370 minecraft:white_concrete
setblock 176 104 410 minecraft:white_concrete
setblock 180 104 370 minecraft:white_concrete
setblock 182 104 375 minecraft:white_concrete
setblock 182 104 382 minecraft:white_concrete
setblock 182 104 389 minecraft:white_concrete
setblock 182 104 396 minecraft:white_concrete
setblock 182 104 403 minecraft:white_concrete
fill 142 105 398 148 105 398 minecraft:black_concrete
fill 144 105 396 148 106 397 minecraft:black_concrete
fill 144 105 399 148 106 400 minecraft:black_concrete
setblock 142 106 376 minecraft:white_concrete
setblock 142 106 383 minecraft:white_concrete
setblock 142 106 390 minecraft:white_concrete
setblock 142 106 397 minecraft:white_concrete
setblock 142 106 404 minecraft:white_concrete
setblock 143 106 370 minecraft:white_concrete
setblock 143 106 410 minecraft:white_concrete
fill 144 106 398 148 106 398 minecraft:black_concrete
setblock 150 106 370 minecraft:white_concrete
setblock 150 106 410 minecraft:white_concrete
setblock 157 106 370 minecraft:white_concrete
setblock 157 106 410 minecraft:white_concrete
setblock 164 106 370 minecraft:white_concrete
setblock 164 106 410 minecraft:white_concrete
setblock 171 106 370 minecraft:white_concrete
setblock 171 106 410 minecraft:white_concrete
setblock 178 106 370 minecraft:white_concrete
setblock 178 106 410 minecraft:white_concrete
setblock 182 106 373 minecraft:white_concrete
setblock 182 106 380 minecraft:white_concrete
setblock 182 106 387 minecraft:white_concrete
setblock 182 106 394 minecraft:white_concrete
setblock 182 106 401 minecraft:white_concrete
setblock 182 106 408 minecraft:white_concrete
setblock 142 107 370 minecraft:white_concrete
setblock 142 107 377 minecraft:white_concrete
setblock 142 107 384 minecraft:white_concrete
setblock 142 107 391 minecraft:white_concrete
setblock 142 107 398 minecraft:white_concrete
setblock 142 107 405 minecraft:white_concrete
setblock 144 107 372 minecraft:light[level=14]
setblock 144 107 380 minecraft:light[level=14]
setblock 144 107 388 minecraft:light[level=14]
setblock 144 107 396 minecraft:light[level=14]
setblock 144 107 404 minecraft:light[level=14]
setblock 144 107 410 minecraft:white_concrete
fill 146 107 398 146 112 398 minecraft:bone_block
setblock 149 107 370 minecraft:white_concrete
setblock 151 107 410 minecraft:white_concrete
setblock 152 107 372 minecraft:light[level=14]
setblock 152 107 380 minecraft:light[level=14]
setblock 152 107 388 minecraft:light[level=14]
setblock 152 107 396 minecraft:light[level=14]
setblock 152 107 404 minecraft:light[level=14]
setblock 156 107 370 minecraft:white_concrete
setblock 158 107 410 minecraft:white_concrete
setblock 160 107 372 minecraft:light[level=14]
setblock 160 107 380 minecraft:light[level=14]
setblock 160 107 388 minecraft:light[level=14]
setblock 160 107 396 minecraft:light[level=14]
setblock 160 107 404 minecraft:light[level=14]
setblock 163 107 370 minecraft:white_concrete
setblock 165 107 410 minecraft:white_concrete
setblock 168 107 372 minecraft:light[level=14]
setblock 168 107 380 minecraft:light[level=14]
setblock 168 107 388 minecraft:light[level=14]
setblock 168 107 396 minecraft:light[level=14]
setblock 168 107 404 minecraft:light[level=14]
setblock 170 107 370 minecraft:white_concrete
setblock 172 107 410 minecraft:white_concrete
setblock 176 107 372 minecraft:light[level=14]
setblock 176 107 380 minecraft:light[level=14]
setblock 176 107 388 minecraft:light[level=14]
setblock 176 107 396 minecraft:light[level=14]
setblock 176 107 404 minecraft:light[level=14]
setblock 177 107 370 minecraft:white_concrete
setblock 179 107 410 minecraft:white_concrete
setblock 182 107 372 minecraft:white_concrete
setblock 182 107 379 minecraft:white_concrete
setblock 182 107 386 minecraft:white_concrete
setblock 182 107 393 minecraft:white_concrete
setblock 182 107 400 minecraft:white_concrete
setblock 182 107 407 minecraft:white_concrete
setblock 142 108 371 minecraft:white_concrete
setblock 142 108 378 minecraft:white_concrete
setblock 142 108 385 minecraft:white_concrete
setblock 142 108 392 minecraft:white_concrete
setblock 142 108 399 minecraft:white_concrete
setblock 142 108 406 minecraft:white_concrete
fill 144 108 397 145 111 399 minecraft:bone_block
fill 145 108 396 147 111 396 minecraft:bone_block
fill 145 108 400 147 111 400 minecraft:bone_block
setblock 145 108 410 minecraft:white_concrete
fill 146 108 397 148 111 397 minecraft:bone_block
fill 146 108 399 148 111 399 minecraft:bone_block
fill 147 108 398 148 111 398 minecraft:bone_block
setblock 148 108 370 minecraft:white_concrete
setblock 152 108 410 minecraft:white_concrete
setblock 155 108 370 minecraft:white_concrete
setblock 159 108 410 minecraft:white_concrete
setblock 162 108 370 minecraft:white_concrete
setblock 166 108 410 minecraft:white_concrete
setblock 169 108 370 minecraft:white_concrete
setblock 173 108 410 minecraft:white_concrete
setblock 176 108 370 minecraft:white_concrete
setblock 180 108 410 minecraft:white_concrete
setblock 182 108 371 minecraft:white_concrete
setblock 182 108 378 minecraft:white_concrete
setblock 182 108 385 minecraft:white_concrete
setblock 182 108 392 minecraft:white_concrete
setblock 182 108 399 minecraft:white_concrete
setblock 182 108 406 minecraft:white_concrete
fill 142 109 372 142 110 372 minecraft:white_concrete
fill 142 109 379 142 110 379 minecraft:white_concrete
fill 142 109 386 142 110 386 minecraft:white_concrete
fill 142 109 393 142 110 393 minecraft:white_concrete
fill 142 109 400 142 110 400 minecraft:white_concrete
fill 142 109 407 142 110 407 minecraft:white_concrete
fill 146 109 410 146 110 410 minecraft:white_concrete
fill 147 109 370 147 110 370 minecraft:white_concrete
fill 153 109 410 153 110 410 minecraft:white_concrete
fill 154 109 370 154 110 370 minecraft:white_concrete
fill 160 109 410 160 110 410 minecraft:white_concrete
fill 161 109 370 161 110 370 minecraft:white_concrete
fill 167 109 410 167 110 410 minecraft:white_concrete
fill 168 109 370 168 110 370 minecraft:white_concrete
fill 174 109 410 174 110 410 minecraft:white_concrete
fill 175 109 370 175 110 370 minecraft:white_concrete
fill 181 109 410 181 110 410 minecraft:white_concrete
fill 182 109 370 182 110 370 minecraft:white_concrete
fill 182 109 377 182 110 377 minecraft:white_concrete
fill 182 109 384 182 110 384 minecraft:white_concrete
fill 182 109 391 182 110 391 minecraft:white_concrete
fill 182 109 398 182 110 398 minecraft:white_concrete
fill 182 109 405 182 110 405 minecraft:white_concrete
fill 142 110 370 142 110 371 minecraft:white_concrete
fill 142 110 373 142 110 374 minecraft:white_concrete
fill 142 110 376 142 110 378 minecraft:white_concrete
fill 142 110 380 142 110 381 minecraft:white_concrete
fill 142 110 383 142 110 385 minecraft:white_concrete
fill 142 110 387 142 110 388 minecraft:white_concrete
fill 142 110 390 142 110 392 minecraft:white_concrete
fill 142 110 394 142 110 395 minecraft:white_concrete
fill 142 110 397 142 110 399 minecraft:white_concrete
fill 142 110 401 142 110 402 minecraft:white_concrete
fill 142 110 404 142 110 406 minecraft:white_concrete
fill 142 110 408 142 110 409 minecraft:white_concrete
setblock 143 110 370 minecraft:white_concrete
fill 143 110 410 145 110 410 minecraft:white_concrete
fill 145 110 370 146 110 370 minecraft:white_concrete
fill 147 110 410 148 110 410 minecraft:white_concrete
fill 148 110 370 150 110 370 minecraft:white_concrete
fill 150 110 410 152 110 410 minecraft:white_concrete
fill 152 110 370 153 110 370 minecraft:white_concrete
fill 154 110 410 155 110 410 minecraft:white_concrete
fill 155 110 370 157 110 370 minecraft:white_concrete
fill 157 110 410 159 110 410 minecraft:white_concrete
fill 159 110 370 160 110 370 minecraft:white_concrete
fill 161 110 410 162 110 410 minecraft:white_concrete
fill 162 110 370 164 110 370 minecraft:white_concrete
fill 164 110 410 166 110 410 minecraft:white_concrete
fill 166 110 370 167 110 370 minecraft:white_concrete
fill 168 110 410 169 110 410 minecraft:white_concrete
fill 169 110 370 171 110 370 minecraft:white_concrete
fill 171 110 410 173 110 410 minecraft:white_concrete
fill 173 110 370 174 110 370 minecraft:white_concrete
fill 175 110 410 176 110 410 minecraft:white_concrete
fill 176 110 370 178 110 370 minecraft:white_concrete
fill 178 110 410 180 110 410 minecraft:white_concrete
fill 180 110 370 181 110 370 minecraft:white_concrete
fill 182 110 371 182 110 373 minecraft:white_concrete
fill 182 110 375 182 110 376 minecraft:white_concrete
fill 182 110 378 182 110 380 minecraft:white_concrete
fill 182 110 382 182 110 383 minecraft:white_concrete
fill 182 110 385 182 110 387 minecraft:white_concrete
fill 182 110 389 182 110 390 minecraft:white_concrete
fill 182 110 392 182 110 394 minecraft:white_concrete
fill 182 110 396 182 110 397 minecraft:white_concrete
fill 182 110 399 182 110 401 minecraft:white_concrete
fill 182 110 403 182 110 404 minecraft:white_concrete
fill 182 110 406 182 110 408 minecraft:white_concrete
setblock 182 110 410 minecraft:white_concrete
setblock 142 111 374 minecraft:white_concrete
setblock 142 111 381 minecraft:white_concrete
setblock 142 111 388 minecraft:white_concrete
setblock 142 111 395 minecraft:white_concrete
setblock 142 111 402 minecraft:white_concrete
setblock 142 111 409 minecraft:white_concrete
setblock 145 111 370 minecraft:white_concrete
setblock 148 111 410 minecraft:white_concrete
setblock 152 111 370 minecraft:white_concrete
setblock 155 111 410 minecraft:white_concrete
setblock 159 111 370 minecraft:white_concrete
setblock 162 111 410 minecraft:white_concrete
setblock 166 111 370 minecraft:white_concrete
setblock 169 111 410 minecraft:white_concrete
setblock 173 111 370 minecraft:white_concrete
setblock 176 111 410 minecraft:white_concrete
setblock 180 111 370 minecraft:white_concrete
setblock 182 111 375 minecraft:white_concrete
setblock 182 111 382 minecraft:white_concrete
setblock 182 111 389 minecraft:white_concrete
setblock 182 111 396 minecraft:white_concrete
setblock 182 111 403 minecraft:white_concrete
setblock 142 113 376 minecraft:white_concrete
setblock 142 113 383 minecraft:white_concrete
setblock 142 113 390 minecraft:white_concrete
setblock 142 113 397 minecraft:white_concrete
setblock 142 113 404 minecraft:white_concrete
setblock 143 113 370 minecraft:white_concrete
setblock 143 113 410 minecraft:white_concrete
setblock 150 113 370 minecraft:white_concrete
setblock 150 113 410 minecraft:white_concrete
setblock 157 113 370 minecraft:white_concrete
setblock 157 113 410 minecraft:white_concrete
setblock 164 113 370 minecraft:white_concrete
setblock 164 113 410 minecraft:white_concrete
setblock 171 113 370 minecraft:white_concrete
setblock 171 113 410 minecraft:white_concrete
setblock 178 113 370 minecraft:white_concrete
setblock 178 113 410 minecraft:white_concrete
setblock 182 113 373 minecraft:white_concrete
setblock 182 113 380 minecraft:white_concrete
setblock 182 113 387 minecraft:white_concrete
setblock 182 113 394 minecraft:white_concrete
setblock 182 113 401 minecraft:white_concrete
setblock 182 113 408 minecraft:white_concrete
setblock 142 114 370 minecraft:white_concrete
setblock 142 114 377 minecraft:white_concrete
setblock 142 114 384 minecraft:white_concrete
setblock 142 114 391 minecraft:white_concrete
setblock 142 114 398 minecraft:white_concrete
setblock 142 114 405 minecraft:white_concrete
setblock 144 114 410 minecraft:white_concrete
setblock 149 114 370 minecraft:white_concrete
setblock 151 114 410 minecraft:white_concrete
setblock 156 114 370 minecraft:white_concrete
setblock 158 114 410 minecraft:white_concrete
setblock 163 114 370 minecraft:white_concrete
setblock 165 114 410 minecraft:white_concrete
setblock 170 114 370 minecraft:white_concrete
setblock 172 114 410 minecraft:white_concrete
setblock 177 114 370 minecraft:white_concrete
setblock 179 114 410 minecraft:white_concrete
setblock 182 114 372 minecraft:white_concrete
setblock 182 114 379 minecraft:white_concrete
setblock 182 114 386 minecraft:white_concrete
setblock 182 114 393 minecraft:white_concrete
setblock 182 114 400 minecraft:white_concrete
setblock 182 114 407 minecraft:white_concrete
setblock 142 115 371 minecraft:white_concrete
setblock 142 115 378 minecraft:white_concrete
setblock 142 115 385 minecraft:white_concrete
setblock 142 115 392 minecraft:white_concrete
setblock 142 115 399 minecraft:white_concrete
setblock 142 115 406 minecraft:white_concrete
setblock 144 115 372 minecraft:light[level=14]
setblock 144 115 380 minecraft:light[level=14]
setblock 144 115 388 minecraft:light[level=14]
setblock 144 115 396 minecraft:light[level=14]
setblock 144 115 404 minecraft:light[level=14]
setblock 145 115 410 minecraft:white_concrete
setblock 148 115 370 minecraft:white_concrete
setblock 152 115 372 minecraft:light[level=14]
setblock 152 115 380 minecraft:light[level=14]
setblock 152 115 388 minecraft:light[level=14]
setblock 152 115 396 minecraft:light[level=14]
setblock 152 115 404 minecraft:light[level=14]
setblock 152 115 410 minecraft:white_concrete
setblock 155 115 370 minecraft:white_concrete
fill 159 115 407 159 116 409 minecraft:gray_concrete
setblock 159 115 410 minecraft:white_concrete
setblock 160 115 372 minecraft:light[level=14]
setblock 160 115 380 minecraft:light[level=14]
setblock 160 115 388 minecraft:light[level=14]
setblock 160 115 396 minecraft:light[level=14]
setblock 160 115 404 minecraft:light[level=14]
setblock 162 115 370 minecraft:white_concrete
setblock 166 115 410 minecraft:white_concrete
setblock 168 115 372 minecraft:light[level=14]
setblock 168 115 380 minecraft:light[level=14]
setblock 168 115 388 minecraft:light[level=14]
setblock 168 115 396 minecraft:light[level=14]
setblock 168 115 404 minecraft:light[level=14]
setblock 169 115 370 minecraft:white_concrete
setblock 173 115 410 minecraft:white_concrete
setblock 176 115 370 minecraft:white_concrete
setblock 176 115 372 minecraft:light[level=14]
setblock 176 115 380 minecraft:light[level=14]
setblock 176 115 388 minecraft:light[level=14]
setblock 176 115 396 minecraft:light[level=14]
setblock 176 115 404 minecraft:light[level=14]
setblock 180 115 410 minecraft:white_concrete
setblock 182 115 371 minecraft:white_concrete
setblock 182 115 378 minecraft:white_concrete
setblock 182 115 385 minecraft:white_concrete
setblock 182 115 392 minecraft:white_concrete
setblock 182 115 399 minecraft:white_concrete
setblock 182 115 406 minecraft:white_concrete
setblock 142 116 372 minecraft:white_concrete
setblock 142 116 379 minecraft:white_concrete
setblock 142 116 386 minecraft:white_concrete
setblock 142 116 393 minecraft:white_concrete
setblock 142 116 400 minecraft:white_concrete
setblock 142 116 407 minecraft:white_concrete
setblock 146 116 410 minecraft:white_concrete
setblock 147 116 370 minecraft:white_concrete
setblock 153 116 410 minecraft:white_concrete
setblock 154 116 370 minecraft:white_concrete
setblock 160 116 410 minecraft:white_concrete
setblock 161 116 370 minecraft:white_concrete
setblock 167 116 410 minecraft:white_concrete
setblock 168 116 370 minecraft:white_concrete
setblock 174 116 410 minecraft:white_concrete
setblock 175 116 370 minecraft:white_concrete
setblock 181 116 410 minecraft:white_concrete
setblock 182 116 370 minecraft:white_concrete
setblock 182 116 377 minecraft:white_concrete
setblock 182 116 384 minecraft:white_concrete
setblock 182 116 391 minecraft:white_concrete
setblock 182 116 398 minecraft:white_concrete
setblock 182 116 405 minecraft:white_concrete
setblock 142 117 373 minecraft:white_concrete
setblock 142 117 380 minecraft:white_concrete
setblock 142 117 387 minecraft:white_concrete
setblock 142 117 394 minecraft:white_concrete
setblock 142 117 401 minecraft:white_concrete
setblock 142 117 408 minecraft:white_concrete
fill 143 117 403 144 118 403 minecraft:gray_concrete
setblock 146 117 370 minecraft:white_concrete
setblock 147 117 410 minecraft:white_concrete
setblock 153 117 370 minecraft:white_concrete
setblock 154 117 410 minecraft:white_concrete
setblock 160 117 370 minecraft:white_concrete
setblock 161 117 410 minecraft:white_concrete
setblock 167 117 370 minecraft:white_concrete
setblock 168 117 410 minecraft:white_concrete
setblock 174 117 370 minecraft:white_concrete
setblock 175 117 410 minecraft:white_concrete
setblock 181 117 370 minecraft:white_concrete
setblock 182 117 376 minecraft:white_concrete
setblock 182 117 383 minecraft:white_concrete
setblock 182 117 390 minecraft:white_concrete
setblock 182 117 397 minecraft:white_concrete
setblock 182 117 404 minecraft:white_concrete
setblock 182 117 410 minecraft:white_concrete
setblock 142 118 374 minecraft:white_concrete
schedule function dropper:buildpart/87_2 1t
