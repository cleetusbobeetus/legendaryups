fill 470 110 444 470 115 445 minecraft:red_nether_bricks
fill 470 110 450 470 111 451 minecraft:orange_concrete
fill 470 110 452 470 115 453 minecraft:red_nether_bricks
setblock 470 110 454 minecraft:orange_concrete
fill 471 110 416 472 111 416 minecraft:orange_concrete
fill 474 110 458 475 111 458 minecraft:orange_concrete
fill 476 110 458 477 115 458 minecraft:red_nether_bricks
fill 477 110 416 478 115 416 minecraft:red_nether_bricks
fill 479 110 416 480 110 416 minecraft:orange_concrete
fill 481 110 416 481 115 416 minecraft:red_nether_bricks
fill 483 110 458 483 111 458 minecraft:orange_concrete
fill 484 110 458 485 111 458 minecraft:red_nether_bricks
fill 486 110 458 487 110 458 minecraft:orange_concrete
fill 488 110 458 488 115 458 minecraft:red_nether_bricks
fill 489 110 416 490 115 416 minecraft:red_nether_bricks
fill 491 110 416 492 111 416 minecraft:orange_concrete
fill 494 110 458 495 111 458 minecraft:orange_concrete
fill 496 110 458 497 115 458 minecraft:red_nether_bricks
fill 498 110 416 498 115 416 minecraft:red_nether_bricks
setblock 500 110 416 minecraft:orange_concrete
fill 501 110 416 502 115 416 minecraft:red_nether_bricks
fill 502 110 435 503 111 436 minecraft:magma_block
fill 503 110 416 503 111 416 minecraft:orange_concrete
fill 505 110 458 505 111 458 minecraft:red_nether_bricks
fill 506 110 458 507 110 458 minecraft:orange_concrete
fill 508 110 458 509 115 458 minecraft:red_nether_bricks
fill 509 110 416 510 115 416 minecraft:red_nether_bricks
fill 511 110 416 512 110 416 minecraft:orange_concrete
fill 512 110 425 512 115 426 minecraft:red_nether_bricks
fill 512 110 427 512 111 428 minecraft:orange_concrete
fill 512 110 434 512 115 434 minecraft:red_nether_bricks
fill 512 110 435 512 110 436 minecraft:orange_concrete
fill 512 110 437 512 115 437 minecraft:red_nether_bricks
fill 512 110 439 512 111 439 minecraft:orange_concrete
fill 512 110 445 512 115 446 minecraft:red_nether_bricks
fill 512 110 447 512 111 448 minecraft:orange_concrete
setblock 512 110 456 minecraft:orange_concrete
fill 512 110 457 512 115 457 minecraft:red_nether_bricks
setblock 470 111 418 minecraft:orange_concrete
fill 470 111 422 470 114 422 minecraft:red_nether_bricks
fill 470 111 438 470 111 439 minecraft:orange_concrete
setblock 470 111 442 minecraft:orange_concrete
fill 470 111 443 470 114 443 minecraft:red_nether_bricks
fill 470 111 454 470 114 454 minecraft:red_nether_bricks
setblock 471 111 458 minecraft:orange_concrete
fill 479 111 416 479 114 416 minecraft:red_nether_bricks
setblock 480 111 416 minecraft:orange_concrete
setblock 482 111 458 minecraft:orange_concrete
fill 483 111 416 484 111 416 minecraft:orange_concrete
fill 486 111 458 487 113 458 minecraft:red_nether_bricks
fill 500 111 416 500 114 416 minecraft:red_nether_bricks
fill 502 111 458 503 111 458 minecraft:orange_concrete
setblock 504 111 416 minecraft:orange_concrete
setblock 506 111 458 minecraft:orange_concrete
fill 507 111 458 507 114 458 minecraft:red_nether_bricks
fill 511 111 416 511 114 416 minecraft:red_nether_bricks
setblock 512 111 416 minecraft:orange_concrete
setblock 512 111 419 minecraft:orange_concrete
fill 512 111 435 512 114 436 minecraft:red_nether_bricks
setblock 512 111 440 minecraft:orange_concrete
setblock 512 111 451 minecraft:orange_concrete
fill 512 111 456 512 114 456 minecraft:red_nether_bricks
fill 470 112 416 470 113 417 minecraft:orange_concrete
fill 470 112 418 470 117 419 minecraft:red_nether_bricks
fill 470 112 428 470 112 429 minecraft:orange_concrete
fill 470 112 430 470 117 431 minecraft:red_nether_bricks
fill 470 112 437 470 113 437 minecraft:orange_concrete
fill 470 112 438 470 117 439 minecraft:red_nether_bricks
setblock 470 112 440 minecraft:orange_concrete
fill 470 112 442 470 117 442 minecraft:red_nether_bricks
fill 470 112 448 470 113 449 minecraft:orange_concrete
fill 470 112 450 470 117 451 minecraft:red_nether_bricks
fill 471 112 416 472 117 416 minecraft:red_nether_bricks
fill 471 112 458 471 117 458 minecraft:red_nether_bricks
fill 472 112 458 473 112 458 minecraft:orange_concrete
fill 473 112 416 474 113 416 minecraft:orange_concrete
setblock 473 112 419 minecraft:light[level=14]
setblock 473 112 427 minecraft:light[level=14]
setblock 473 112 435 minecraft:light[level=14]
setblock 473 112 443 minecraft:light[level=14]
setblock 473 112 451 minecraft:light[level=14]
fill 474 112 458 475 114 458 minecraft:red_nether_bricks
fill 480 112 416 480 117 416 minecraft:red_nether_bricks
fill 480 112 458 481 113 458 minecraft:orange_concrete
setblock 481 112 419 minecraft:light[level=14]
setblock 481 112 427 minecraft:light[level=14]
setblock 481 112 435 minecraft:light[level=14]
setblock 481 112 443 minecraft:light[level=14]
setblock 481 112 451 minecraft:light[level=14]
setblock 482 112 416 minecraft:orange_concrete
fill 482 112 458 483 117 458 minecraft:red_nether_bricks
fill 483 112 416 484 117 416 minecraft:red_nether_bricks
setblock 484 112 458 minecraft:orange_concrete
fill 485 112 416 485 113 416 minecraft:orange_concrete
fill 485 112 458 485 115 458 minecraft:red_nether_bricks
setblock 489 112 419 minecraft:light[level=14]
setblock 489 112 427 minecraft:light[level=14]
setblock 489 112 435 minecraft:light[level=14]
setblock 489 112 443 minecraft:light[level=14]
setblock 489 112 451 minecraft:light[level=14]
fill 491 112 416 492 117 416 minecraft:red_nether_bricks
fill 492 112 458 493 113 458 minecraft:orange_concrete
fill 493 112 416 494 112 416 minecraft:orange_concrete
fill 494 112 458 495 117 458 minecraft:red_nether_bricks
setblock 497 112 419 minecraft:light[level=14]
setblock 497 112 427 minecraft:light[level=14]
setblock 497 112 435 minecraft:light[level=14]
setblock 497 112 443 minecraft:light[level=14]
setblock 497 112 451 minecraft:light[level=14]
fill 501 112 458 501 113 458 minecraft:orange_concrete
fill 502 112 458 503 113 458 minecraft:red_nether_bricks
fill 503 112 416 504 117 416 minecraft:red_nether_bricks
fill 504 112 458 505 112 458 minecraft:orange_concrete
fill 505 112 416 506 113 416 minecraft:orange_concrete
setblock 505 112 419 minecraft:light[level=14]
setblock 505 112 427 minecraft:light[level=14]
setblock 505 112 435 minecraft:light[level=14]
setblock 505 112 443 minecraft:light[level=14]
setblock 505 112 451 minecraft:light[level=14]
fill 506 112 458 506 117 458 minecraft:red_nether_bricks
fill 512 112 416 512 117 416 minecraft:red_nether_bricks
fill 512 112 417 512 112 418 minecraft:orange_concrete
fill 512 112 419 512 117 419 minecraft:red_nether_bricks
fill 512 112 421 512 113 421 minecraft:orange_concrete
fill 512 112 427 512 117 428 minecraft:red_nether_bricks
fill 512 112 429 512 113 430 minecraft:orange_concrete
setblock 512 112 438 minecraft:orange_concrete
fill 512 112 439 512 117 440 minecraft:red_nether_bricks
fill 512 112 441 512 113 442 minecraft:orange_concrete
fill 512 112 447 512 117 448 minecraft:red_nether_bricks
fill 512 112 449 512 112 450 minecraft:orange_concrete
fill 512 112 451 512 117 451 minecraft:red_nether_bricks
fill 512 112 458 512 113 458 minecraft:orange_concrete
setblock 470 113 425 minecraft:orange_concrete
setblock 470 113 428 minecraft:orange_concrete
fill 470 113 429 470 116 429 minecraft:red_nether_bricks
setblock 470 113 436 minecraft:orange_concrete
fill 470 113 440 470 116 440 minecraft:red_nether_bricks
setblock 470 113 455 minecraft:red_nether_bricks
fill 470 113 456 470 113 457 minecraft:orange_concrete
setblock 472 113 458 minecraft:orange_concrete
fill 473 113 458 473 116 458 minecraft:red_nether_bricks
fill 482 113 416 482 116 416 minecraft:red_nether_bricks
fill 484 113 458 484 115 458 minecraft:red_nether_bricks
setblock 486 113 416 minecraft:orange_concrete
fill 487 113 416 488 113 416 minecraft:red_nether_bricks
setblock 489 113 458 minecraft:orange_concrete
fill 493 113 416 493 116 416 minecraft:red_nether_bricks
setblock 494 113 416 minecraft:orange_concrete
fill 495 113 416 496 113 416 minecraft:red_nether_bricks
setblock 497 113 416 minecraft:orange_concrete
setblock 500 113 458 minecraft:orange_concrete
fill 504 113 458 505 115 458 minecraft:red_nether_bricks
fill 512 113 417 512 116 418 minecraft:red_nether_bricks
setblock 512 113 422 minecraft:orange_concrete
setblock 512 113 433 minecraft:orange_concrete
fill 512 113 438 512 116 438 minecraft:red_nether_bricks
fill 512 113 449 512 116 449 minecraft:red_nether_bricks
setblock 512 113 450 minecraft:orange_concrete
fill 512 113 453 512 113 454 minecraft:orange_concrete
fill 470 114 416 470 119 417 minecraft:red_nether_bricks
fill 470 114 423 470 115 423 minecraft:orange_concrete
fill 470 114 425 471 114 425 minecraft:red_nether_bricks
fill 470 114 426 470 114 427 minecraft:orange_concrete
fill 470 114 428 471 114 428 minecraft:red_nether_bricks
fill 470 114 434 470 115 435 minecraft:orange_concrete
fill 470 114 436 471 114 437 minecraft:red_nether_bricks
fill 470 114 446 470 114 447 minecraft:orange_concrete
fill 470 114 448 471 114 449 minecraft:red_nether_bricks
fill 470 114 455 470 115 455 minecraft:orange_concrete
fill 470 114 456 471 114 457 minecraft:red_nether_bricks
setblock 470 114 458 minecraft:orange_concrete
fill 471 114 417 473 114 417 minecraft:red_nether_bricks
fill 471 114 419 471 114 421 minecraft:red_nether_bricks
fill 471 114 423 471 114 424 minecraft:red_nether_bricks
setblock 471 114 427 minecraft:red_nether_bricks
setblock 471 114 429 minecraft:red_nether_bricks
fill 471 114 431 471 114 433 minecraft:red_nether_bricks
setblock 471 114 435 minecraft:red_nether_bricks
fill 471 114 439 471 114 441 minecraft:red_nether_bricks
fill 471 114 443 471 114 445 minecraft:red_nether_bricks
setblock 471 114 447 minecraft:red_nether_bricks
fill 471 114 451 471 114 453 minecraft:red_nether_bricks
setblock 471 114 455 minecraft:red_nether_bricks
fill 472 114 458 472 116 458 minecraft:red_nether_bricks
fill 473 114 416 474 119 416 minecraft:red_nether_bricks
fill 473 114 457 475 114 457 minecraft:red_nether_bricks
fill 475 114 416 476 114 416 minecraft:orange_concrete
fill 475 114 417 477 114 417 minecraft:red_nether_bricks
fill 477 114 457 479 114 457 minecraft:red_nether_bricks
fill 478 114 458 479 115 458 minecraft:orange_concrete
fill 479 114 417 481 114 417 minecraft:red_nether_bricks
fill 480 114 458 481 119 458 minecraft:red_nether_bricks
fill 481 114 457 483 114 457 minecraft:red_nether_bricks
fill 483 114 417 485 114 417 minecraft:red_nether_bricks
fill 485 114 416 486 119 416 minecraft:red_nether_bricks
fill 485 114 457 487 114 457 minecraft:red_nether_bricks
setblock 486 114 458 minecraft:red_nether_bricks
fill 487 114 416 488 115 416 minecraft:orange_concrete
fill 487 114 417 489 114 417 minecraft:red_nether_bricks
fill 487 114 458 487 115 458 minecraft:orange_concrete
fill 489 114 457 489 114 458 minecraft:red_nether_bricks
fill 490 114 457 491 114 457 minecraft:red_nether_bricks
fill 490 114 458 491 114 458 minecraft:orange_concrete
fill 491 114 417 493 114 417 minecraft:red_nether_bricks
fill 492 114 458 493 116 458 minecraft:red_nether_bricks
fill 493 114 457 495 114 457 minecraft:red_nether_bricks
fill 494 114 416 494 119 416 minecraft:red_nether_bricks
fill 495 114 416 496 114 416 minecraft:orange_concrete
fill 495 114 417 497 114 417 minecraft:red_nether_bricks
fill 497 114 416 497 119 416 minecraft:red_nether_bricks
fill 497 114 457 499 114 457 minecraft:red_nether_bricks
fill 498 114 458 499 115 458 minecraft:orange_concrete
fill 499 114 416 499 115 416 minecraft:orange_concrete
fill 499 114 417 501 114 417 minecraft:red_nether_bricks
fill 500 114 458 501 119 458 minecraft:red_nether_bricks
fill 501 114 457 503 114 457 minecraft:red_nether_bricks
setblock 502 114 458 minecraft:orange_concrete
fill 503 114 417 505 114 417 minecraft:red_nether_bricks
fill 503 114 458 503 117 458 minecraft:red_nether_bricks
fill 505 114 416 506 119 416 minecraft:red_nether_bricks
fill 505 114 457 507 114 457 minecraft:red_nether_bricks
fill 507 114 416 508 115 416 minecraft:orange_concrete
fill 507 114 417 509 114 417 minecraft:red_nether_bricks
fill 509 114 457 511 114 457 minecraft:red_nether_bricks
fill 510 114 458 511 114 458 minecraft:orange_concrete
fill 511 114 417 511 114 419 minecraft:red_nether_bricks
fill 511 114 421 511 114 423 minecraft:red_nether_bricks
fill 511 114 425 511 114 427 minecraft:red_nether_bricks
fill 511 114 429 511 114 431 minecraft:red_nether_bricks
fill 511 114 433 511 114 435 minecraft:red_nether_bricks
fill 511 114 437 511 114 439 minecraft:red_nether_bricks
fill 511 114 441 511 114 443 minecraft:red_nether_bricks
fill 511 114 445 511 114 447 minecraft:red_nether_bricks
fill 511 114 449 511 114 451 minecraft:red_nether_bricks
fill 511 114 453 511 114 455 minecraft:red_nether_bricks
setblock 512 114 420 minecraft:orange_concrete
fill 512 114 421 512 119 422 minecraft:red_nether_bricks
fill 512 114 423 512 115 424 minecraft:orange_concrete
fill 512 114 429 512 119 430 minecraft:red_nether_bricks
fill 512 114 431 512 114 432 minecraft:orange_concrete
fill 512 114 433 512 119 433 minecraft:red_nether_bricks
fill 512 114 441 512 119 442 minecraft:red_nether_bricks
fill 512 114 443 512 115 444 minecraft:orange_concrete
fill 512 114 450 512 119 450 minecraft:red_nether_bricks
setblock 512 114 452 minecraft:orange_concrete
fill 512 114 453 512 119 454 minecraft:red_nether_bricks
fill 512 114 455 512 115 455 minecraft:orange_concrete
fill 512 114 458 512 119 458 minecraft:red_nether_bricks
setblock 470 115 422 minecraft:orange_concrete
fill 470 115 425 470 118 428 minecraft:red_nether_bricks
fill 470 115 436 470 119 437 minecraft:red_nether_bricks
setblock 470 115 443 minecraft:orange_concrete
setblock 470 115 446 minecraft:orange_concrete
fill 470 115 447 470 118 449 minecraft:red_nether_bricks
setblock 470 115 454 minecraft:orange_concrete
fill 470 115 456 470 118 458 minecraft:red_nether_bricks
fill 474 115 458 474 117 458 minecraft:red_nether_bricks
fill 475 115 416 475 118 416 minecraft:red_nether_bricks
setblock 475 115 458 minecraft:orange_concrete
setblock 476 115 416 minecraft:orange_concrete
setblock 479 115 416 minecraft:orange_concrete
setblock 486 115 458 minecraft:orange_concrete
fill 489 115 458 489 119 458 minecraft:red_nether_bricks
setblock 490 115 458 minecraft:orange_concrete
fill 491 115 458 491 118 458 minecraft:red_nether_bricks
fill 495 115 416 496 118 416 minecraft:red_nether_bricks
setblock 500 115 416 minecraft:orange_concrete
fill 502 115 458 502 117 458 minecraft:red_nether_bricks
setblock 507 115 458 minecraft:orange_concrete
setblock 510 115 458 minecraft:orange_concrete
setblock 511 115 416 minecraft:orange_concrete
fill 511 115 458 511 118 458 minecraft:red_nether_bricks
fill 512 115 420 512 118 420 minecraft:red_nether_bricks
fill 512 115 431 512 118 431 minecraft:red_nether_bricks
setblock 512 115 432 minecraft:orange_concrete
fill 512 115 435 512 115 436 minecraft:orange_concrete
fill 512 115 452 512 118 452 minecraft:red_nether_bricks
setblock 512 115 456 minecraft:orange_concrete
fill 470 116 420 470 117 421 minecraft:orange_concrete
fill 470 116 422 470 121 423 minecraft:red_nether_bricks
setblock 470 116 424 minecraft:orange_concrete
fill 470 116 432 470 117 433 minecraft:orange_concrete
fill 470 116 434 470 121 435 minecraft:red_nether_bricks
fill 470 116 441 470 117 441 minecraft:orange_concrete
fill 470 116 443 470 121 443 minecraft:red_nether_bricks
fill 470 116 444 470 116 445 minecraft:orange_concrete
fill 470 116 446 470 121 446 minecraft:red_nether_bricks
fill 470 116 452 470 117 453 minecraft:orange_concrete
fill 470 116 454 470 121 455 minecraft:red_nether_bricks
fill 475 116 458 475 117 458 minecraft:red_nether_bricks
fill 476 116 416 476 121 416 minecraft:red_nether_bricks
fill 476 116 458 477 116 458 minecraft:orange_concrete
fill 477 116 416 478 116 416 minecraft:orange_concrete
fill 478 116 458 479 121 458 minecraft:red_nether_bricks
fill 479 116 416 479 121 416 minecraft:red_nether_bricks
fill 481 116 416 481 117 416 minecraft:orange_concrete
fill 484 116 458 485 117 458 minecraft:orange_concrete
fill 486 116 458 487 121 458 minecraft:red_nether_bricks
fill 487 116 416 488 121 416 minecraft:red_nether_bricks
setblock 488 116 458 minecraft:orange_concrete
fill 489 116 416 490 117 416 minecraft:orange_concrete
fill 490 116 458 490 118 458 minecraft:red_nether_bricks
fill 496 116 458 497 117 458 minecraft:orange_concrete
setblock 498 116 416 minecraft:orange_concrete
fill 498 116 458 499 121 458 minecraft:red_nether_bricks
fill 499 116 416 500 121 416 minecraft:red_nether_bricks
fill 501 116 416 502 117 416 minecraft:orange_concrete
setblock 504 116 458 minecraft:red_nether_bricks
fill 505 116 458 505 117 458 minecraft:orange_concrete
fill 507 116 416 508 121 416 minecraft:red_nether_bricks
fill 507 116 458 507 121 458 minecraft:red_nether_bricks
fill 508 116 458 509 116 458 minecraft:orange_concrete
fill 509 116 416 510 116 416 minecraft:orange_concrete
fill 510 116 458 510 121 458 minecraft:red_nether_bricks
fill 511 116 416 511 121 416 minecraft:red_nether_bricks
fill 512 116 423 512 121 424 minecraft:red_nether_bricks
fill 512 116 425 512 117 426 minecraft:orange_concrete
fill 512 116 432 512 121 432 minecraft:red_nether_bricks
setblock 512 116 434 minecraft:orange_concrete
fill 512 116 435 512 121 436 minecraft:red_nether_bricks
fill 512 116 437 512 117 437 minecraft:orange_concrete
fill 512 116 443 512 121 444 minecraft:red_nether_bricks
fill 512 116 445 512 116 446 minecraft:orange_concrete
fill 512 116 455 512 121 456 minecraft:red_nether_bricks
fill 512 116 457 512 117 457 minecraft:orange_concrete
fill 470 117 424 470 120 424 minecraft:red_nether_bricks
setblock 470 117 429 minecraft:orange_concrete
setblock 470 117 440 minecraft:orange_concrete
fill 470 117 444 470 120 445 minecraft:red_nether_bricks
fill 472 117 458 473 117 458 minecraft:orange_concrete
setblock 476 117 458 minecraft:orange_concrete
fill 477 117 416 478 120 416 minecraft:red_nether_bricks
fill 477 117 458 477 120 458 minecraft:red_nether_bricks
setblock 482 117 416 minecraft:orange_concrete
fill 488 117 458 488 120 458 minecraft:red_nether_bricks
fill 492 117 458 492 119 458 minecraft:red_nether_bricks
setblock 493 117 416 minecraft:orange_concrete
setblock 493 117 458 minecraft:orange_concrete
fill 498 117 416 498 120 416 minecraft:red_nether_bricks
setblock 504 117 458 minecraft:orange_concrete
fill 508 117 458 509 120 458 minecraft:red_nether_bricks
fill 509 117 416 509 120 416 minecraft:red_nether_bricks
setblock 510 117 416 minecraft:orange_concrete
fill 512 117 417 512 117 418 minecraft:orange_concrete
fill 512 117 434 512 120 434 minecraft:red_nether_bricks
setblock 512 117 438 minecraft:orange_concrete
fill 512 117 445 512 120 445 minecraft:red_nether_bricks
setblock 512 117 446 minecraft:orange_concrete
setblock 512 117 449 minecraft:orange_concrete
fill 470 118 418 470 119 419 minecraft:orange_concrete
fill 470 118 420 470 123 421 minecraft:red_nether_bricks
fill 470 118 429 470 123 429 minecraft:red_nether_bricks
fill 470 118 430 470 118 431 minecraft:orange_concrete
fill 470 118 432 470 123 433 minecraft:red_nether_bricks
fill 470 118 438 470 119 439 minecraft:orange_concrete
fill 470 118 440 470 123 441 minecraft:red_nether_bricks
setblock 470 118 442 minecraft:orange_concrete
fill 470 118 450 470 119 451 minecraft:orange_concrete
fill 470 118 452 470 123 453 minecraft:red_nether_bricks
fill 471 118 416 472 119 416 minecraft:orange_concrete
fill 471 118 458 471 119 458 minecraft:orange_concrete
fill 472 118 458 473 119 458 minecraft:red_nether_bricks
fill 474 118 458 475 118 458 minecraft:orange_concrete
fill 476 118 458 476 123 458 minecraft:red_nether_bricks
setblock 480 118 416 minecraft:orange_concrete
fill 481 118 416 482 123 416 minecraft:red_nether_bricks
fill 482 118 458 483 119 458 minecraft:orange_concrete
fill 483 118 416 484 119 416 minecraft:orange_concrete
fill 484 118 458 485 123 458 minecraft:red_nether_bricks
fill 489 118 416 490 123 416 minecraft:red_nether_bricks
fill 491 118 416 492 118 416 minecraft:orange_concrete
fill 493 118 416 493 123 416 minecraft:red_nether_bricks
fill 493 118 458 493 119 458 minecraft:red_nether_bricks
fill 494 118 458 495 118 458 minecraft:orange_concrete
fill 496 118 458 497 123 458 minecraft:red_nether_bricks
fill 501 118 416 502 123 416 minecraft:red_nether_bricks
fill 502 118 458 503 119 458 minecraft:orange_concrete
fill 503 118 416 504 119 416 minecraft:orange_concrete
fill 504 118 458 505 123 458 minecraft:red_nether_bricks
setblock 506 118 458 minecraft:orange_concrete
fill 510 118 416 510 123 416 minecraft:red_nether_bricks
setblock 512 118 416 minecraft:orange_concrete
fill 512 118 417 512 123 418 minecraft:red_nether_bricks
fill 512 118 419 512 119 419 minecraft:orange_concrete
fill 512 118 425 512 123 426 minecraft:red_nether_bricks
fill 512 118 427 512 118 428 minecraft:orange_concrete
fill 512 118 437 512 123 438 minecraft:red_nether_bricks
fill 512 118 439 512 119 440 minecraft:orange_concrete
fill 512 118 446 512 123 446 minecraft:red_nether_bricks
fill 512 118 447 512 118 448 minecraft:orange_concrete
fill 512 118 449 512 123 449 minecraft:red_nether_bricks
fill 512 118 451 512 119 451 minecraft:orange_concrete
fill 512 118 457 512 123 457 minecraft:red_nether_bricks
setblock 470 119 425 minecraft:red_nether_bricks
fill 470 119 426 470 119 427 minecraft:orange_concrete
setblock 470 119 428 minecraft:red_nether_bricks
setblock 470 119 430 minecraft:orange_concrete
fill 470 119 431 470 122 431 minecraft:red_nether_bricks
fill 470 119 442 470 122 442 minecraft:red_nether_bricks
setblock 470 119 447 minecraft:orange_concrete
fill 470 119 448 470 119 449 minecraft:red_nether_bricks
fill 470 119 456 470 119 457 minecraft:red_nether_bricks
setblock 470 119 458 minecraft:orange_concrete
fill 474 119 458 475 121 458 minecraft:red_nether_bricks
setblock 475 119 416 minecraft:orange_concrete
fill 480 119 416 480 122 416 minecraft:red_nether_bricks
fill 490 119 458 491 119 458 minecraft:orange_concrete
fill 491 119 416 491 122 416 minecraft:red_nether_bricks
setblock 492 119 416 minecraft:orange_concrete
setblock 494 119 458 minecraft:orange_concrete
fill 495 119 416 496 119 416 minecraft:orange_concrete
fill 495 119 458 495 122 458 minecraft:red_nether_bricks
fill 506 119 458 506 122 458 minecraft:red_nether_bricks
fill 510 119 449 510 122 449 minecraft:magma_block
setblock 511 119 458 minecraft:orange_concrete
fill 512 119 416 512 122 416 minecraft:red_nether_bricks
setblock 512 119 420 minecraft:orange_concrete
fill 512 119 427 512 122 427 minecraft:red_nether_bricks
setblock 512 119 428 minecraft:orange_concrete
setblock 512 119 431 minecraft:orange_concrete
fill 512 119 447 512 122 448 minecraft:red_nether_bricks
setblock 512 119 452 minecraft:orange_concrete
fill 470 120 416 470 120 417 minecraft:orange_concrete
fill 470 120 418 470 125 419 minecraft:red_nether_bricks
fill 470 120 425 470 121 425 minecraft:orange_concrete
fill 470 120 426 470 125 427 minecraft:red_nether_bricks
setblock 470 120 428 minecraft:orange_concrete
fill 470 120 430 470 125 430 minecraft:red_nether_bricks
fill 470 120 436 470 121 437 minecraft:orange_concrete
fill 470 120 438 470 125 439 minecraft:red_nether_bricks
fill 470 120 447 471 120 447 minecraft:red_nether_bricks
fill 470 120 448 470 120 449 minecraft:orange_concrete
fill 470 120 450 470 122 451 minecraft:red_nether_bricks
fill 470 120 456 470 121 457 minecraft:orange_concrete
fill 470 120 458 471 125 458 minecraft:red_nether_bricks
fill 471 120 416 472 120 417 minecraft:red_nether_bricks
fill 471 120 419 471 120 421 minecraft:red_nether_bricks
fill 471 120 423 471 120 425 minecraft:red_nether_bricks
fill 471 120 427 471 120 429 minecraft:red_nether_bricks
fill 471 120 431 471 120 433 minecraft:red_nether_bricks
fill 471 120 435 471 120 437 minecraft:red_nether_bricks
fill 471 120 439 471 120 441 minecraft:red_nether_bricks
fill 471 120 443 471 120 445 minecraft:red_nether_bricks
fill 471 120 448 471 120 449 minecraft:red_nether_bricks
fill 471 120 451 471 120 453 minecraft:red_nether_bricks
fill 471 120 455 471 120 457 minecraft:red_nether_bricks
setblock 472 120 458 minecraft:orange_concrete
fill 473 120 416 474 120 416 minecraft:orange_concrete
setblock 473 120 417 minecraft:red_nether_bricks
setblock 473 120 419 minecraft:light[level=14]
setblock 473 120 427 minecraft:light[level=14]
setblock 473 120 435 minecraft:light[level=14]
setblock 473 120 443 minecraft:light[level=14]
setblock 473 120 451 minecraft:light[level=14]
fill 473 120 457 473 120 458 minecraft:red_nether_bricks
fill 474 120 457 475 120 457 minecraft:red_nether_bricks
fill 475 120 416 475 120 417 minecraft:red_nether_bricks
fill 476 120 417 477 120 417 minecraft:red_nether_bricks
fill 477 120 457 479 120 457 minecraft:red_nether_bricks
fill 479 120 417 481 120 417 minecraft:red_nether_bricks
fill 480 120 458 481 121 458 minecraft:orange_concrete
setblock 481 120 419 minecraft:light[level=14]
setblock 481 120 427 minecraft:light[level=14]
setblock 481 120 435 minecraft:light[level=14]
setblock 481 120 443 minecraft:light[level=14]
setblock 481 120 451 minecraft:light[level=14]
fill 481 120 457 483 120 457 minecraft:red_nether_bricks
fill 482 120 458 483 125 458 minecraft:red_nether_bricks
fill 483 120 416 484 120 417 minecraft:red_nether_bricks
fill 485 120 416 486 121 416 minecraft:orange_concrete
setblock 485 120 417 minecraft:red_nether_bricks
fill 485 120 457 487 120 457 minecraft:red_nether_bricks
fill 487 120 417 489 120 417 minecraft:red_nether_bricks
setblock 489 120 419 minecraft:light[level=14]
setblock 489 120 427 minecraft:light[level=14]
setblock 489 120 435 minecraft:light[level=14]
setblock 489 120 443 minecraft:light[level=14]
setblock 489 120 451 minecraft:light[level=14]
fill 489 120 457 491 120 457 minecraft:red_nether_bricks
fill 489 120 458 489 121 458 minecraft:orange_concrete
fill 490 120 458 491 121 458 minecraft:red_nether_bricks
fill 491 120 417 493 120 417 minecraft:red_nether_bricks
fill 492 120 416 492 125 416 minecraft:red_nether_bricks
fill 492 120 458 493 120 458 minecraft:orange_concrete
fill 493 120 457 495 120 457 minecraft:red_nether_bricks
setblock 494 120 416 minecraft:orange_concrete
fill 494 120 458 494 125 458 minecraft:red_nether_bricks
fill 495 120 416 496 120 417 minecraft:red_nether_bricks
fill 497 120 416 497 121 416 minecraft:orange_concrete
setblock 497 120 417 minecraft:red_nether_bricks
setblock 497 120 419 minecraft:light[level=14]
setblock 497 120 427 minecraft:light[level=14]
setblock 497 120 435 minecraft:light[level=14]
setblock 497 120 443 minecraft:light[level=14]
setblock 497 120 451 minecraft:light[level=14]
fill 497 120 457 499 120 457 minecraft:red_nether_bricks
fill 499 120 417 501 120 417 minecraft:red_nether_bricks
fill 500 120 458 501 121 458 minecraft:orange_concrete
fill 501 120 457 503 120 457 minecraft:red_nether_bricks
fill 502 120 458 503 125 458 minecraft:red_nether_bricks
fill 503 120 416 504 120 417 minecraft:red_nether_bricks
fill 504 120 418 506 123 418 minecraft:magma_block
fill 505 120 416 506 120 416 minecraft:orange_concrete
setblock 505 120 417 minecraft:red_nether_bricks
setblock 505 120 419 minecraft:light[level=14]
setblock 505 120 427 minecraft:light[level=14]
setblock 505 120 435 minecraft:light[level=14]
setblock 505 120 443 minecraft:light[level=14]
setblock 505 120 451 minecraft:light[level=14]
fill 505 120 457 507 120 457 minecraft:red_nether_bricks
fill 506 120 417 506 123 417 minecraft:magma_block
fill 507 120 417 509 120 417 minecraft:red_nether_bricks
fill 508 120 449 509 122 449 minecraft:magma_block
fill 509 120 448 511 121 448 minecraft:magma_block
fill 509 120 450 510 121 450 minecraft:magma_block
fill 509 120 457 511 120 457 minecraft:red_nether_bricks
fill 511 120 417 511 120 419 minecraft:red_nether_bricks
fill 511 120 421 511 120 423 minecraft:red_nether_bricks
fill 511 120 425 511 120 427 minecraft:red_nether_bricks
fill 511 120 429 511 120 431 minecraft:red_nether_bricks
fill 511 120 433 511 120 435 minecraft:red_nether_bricks
fill 511 120 437 511 120 439 minecraft:red_nether_bricks
fill 511 120 441 511 120 443 minecraft:red_nether_bricks
fill 511 120 445 511 120 447 minecraft:red_nether_bricks
fill 511 120 449 511 120 451 minecraft:red_nether_bricks
fill 511 120 453 511 120 455 minecraft:red_nether_bricks
fill 511 120 458 511 125 458 minecraft:red_nether_bricks
fill 512 120 419 512 125 420 minecraft:red_nether_bricks
fill 512 120 421 512 121 422 minecraft:orange_concrete
fill 512 120 428 512 125 428 minecraft:red_nether_bricks
fill 512 120 429 512 120 430 minecraft:orange_concrete
fill 512 120 431 512 125 431 minecraft:red_nether_bricks
fill 512 120 433 512 121 433 minecraft:orange_concrete
fill 512 120 439 512 125 440 minecraft:red_nether_bricks
fill 512 120 441 512 121 442 minecraft:orange_concrete
setblock 512 120 450 minecraft:orange_concrete
fill 512 120 451 512 125 452 minecraft:red_nether_bricks
fill 512 120 453 512 121 454 minecraft:orange_concrete
fill 512 120 458 512 121 458 minecraft:orange_concrete
setblock 470 121 416 minecraft:orange_concrete
fill 470 121 417 470 124 417 minecraft:red_nether_bricks
setblock 470 121 424 minecraft:orange_concrete
fill 470 121 428 470 124 428 minecraft:red_nether_bricks
fill 470 121 444 470 121 445 minecraft:orange_concrete
fill 470 121 447 470 125 447 minecraft:red_nether_bricks
setblock 470 121 448 minecraft:orange_concrete
fill 470 121 449 470 124 449 minecraft:red_nether_bricks
fill 471 121 416 473 124 416 minecraft:red_nether_bricks
fill 472 121 458 473 123 458 minecraft:red_nether_bricks
setblock 474 121 416 minecraft:orange_concrete
fill 475 121 416 475 125 416 minecraft:red_nether_bricks
fill 477 121 416 478 121 416 minecraft:orange_concrete
setblock 477 121 458 minecraft:orange_concrete
fill 483 121 416 484 125 416 minecraft:red_nether_bricks
setblock 488 121 458 minecraft:orange_concrete
fill 492 121 458 493 123 458 minecraft:red_nether_bricks
fill 494 121 416 496 124 416 minecraft:red_nether_bricks
setblock 498 121 416 minecraft:orange_concrete
fill 503 121 416 505 124 416 minecraft:red_nether_bricks
fill 503 121 417 503 122 418 minecraft:magma_block
fill 504 121 417 505 123 417 minecraft:magma_block
fill 504 121 419 506 124 419 minecraft:magma_block
setblock 506 121 416 minecraft:orange_concrete
fill 506 121 449 507 122 449 minecraft:magma_block
fill 507 121 417 507 122 418 minecraft:magma_block
fill 507 121 448 508 121 448 minecraft:magma_block
fill 507 121 450 508 121 450 minecraft:magma_block
fill 508 121 458 509 121 458 minecraft:orange_concrete
setblock 509 121 416 minecraft:orange_concrete
fill 511 121 449 511 121 450 minecraft:magma_block
fill 512 121 429 512 124 430 minecraft:red_nether_bricks
setblock 512 121 434 minecraft:orange_concrete
setblock 512 121 445 minecraft:orange_concrete
fill 512 121 450 512 124 450 minecraft:red_nether_bricks
fill 470 122 416 470 139 416 minecraft:red_nether_bricks
fill 470 122 422 470 123 423 minecraft:orange_concrete
fill 470 122 424 470 136 425 minecraft:red_nether_bricks
fill 470 122 434 470 122 435 minecraft:orange_concrete
fill 470 122 436 470 139 437 minecraft:red_nether_bricks
fill 470 122 443 470 123 443 minecraft:orange_concrete
fill 470 122 444 470 136 445 minecraft:red_nether_bricks
setblock 470 122 446 minecraft:orange_concrete
fill 470 122 448 470 124 448 minecraft:red_nether_bricks
fill 470 122 454 470 123 455 minecraft:orange_concrete
fill 470 122 456 470 139 457 minecraft:red_nether_bricks
fill 474 122 416 474 139 416 minecraft:red_nether_bricks
setblock 474 122 458 minecraft:red_nether_bricks
fill 475 122 458 475 123 458 minecraft:orange_concrete
setblock 476 122 416 minecraft:orange_concrete
fill 477 122 416 478 136 416 minecraft:red_nether_bricks
fill 477 122 458 477 136 458 minecraft:red_nether_bricks
fill 478 122 458 479 122 458 minecraft:orange_concrete
fill 479 122 416 479 123 416 minecraft:orange_concrete
fill 480 122 458 481 124 458 minecraft:red_nether_bricks
fill 485 122 416 486 139 416 minecraft:red_nether_bricks
fill 486 122 458 487 123 458 minecraft:orange_concrete
fill 487 122 416 488 122 416 minecraft:orange_concrete
fill 488 122 458 489 136 458 minecraft:red_nether_bricks
setblock 490 122 458 minecraft:orange_concrete
fill 491 122 458 491 125 458 minecraft:red_nether_bricks
fill 497 122 416 498 136 416 minecraft:red_nether_bricks
fill 498 122 458 499 122 458 minecraft:orange_concrete
fill 499 122 416 500 123 416 minecraft:orange_concrete
fill 500 122 458 501 139 458 minecraft:red_nether_bricks
fill 504 122 420 506 124 420 minecraft:magma_block
fill 504 122 449 505 122 449 minecraft:magma_block
fill 506 122 416 506 139 416 minecraft:red_nether_bricks
fill 507 122 416 508 122 416 minecraft:orange_concrete
setblock 507 122 448 minecraft:magma_block
setblock 507 122 450 minecraft:magma_block
fill 507 122 458 507 123 458 minecraft:orange_concrete
fill 508 122 458 509 136 458 minecraft:red_nether_bricks
fill 509 122 416 509 136 416 minecraft:red_nether_bricks
setblock 510 122 458 minecraft:orange_concrete
fill 511 122 416 511 123 416 minecraft:orange_concrete
fill 512 122 421 512 139 422 minecraft:red_nether_bricks
fill 512 122 423 512 123 424 minecraft:orange_concrete
setblock 512 122 432 minecraft:orange_concrete
fill 512 122 433 512 136 434 minecraft:red_nether_bricks
fill 512 122 435 512 123 436 minecraft:orange_concrete
fill 512 122 441 512 139 442 minecraft:red_nether_bricks
fill 512 122 443 512 122 444 minecraft:orange_concrete
fill 512 122 445 512 136 445 minecraft:red_nether_bricks
fill 512 122 453 512 140 454 minecraft:red_nether_bricks
fill 512 122 455 512 123 456 minecraft:orange_concrete
fill 512 122 458 512 139 458 minecraft:red_nether_bricks
setblock 470 123 431 minecraft:orange_concrete
setblock 470 123 434 minecraft:orange_concrete
fill 470 123 435 470 141 435 minecraft:red_nether_bricks
setblock 470 123 442 minecraft:orange_concrete
fill 470 123 446 470 141 446 minecraft:red_nether_bricks
fill 470 123 450 470 125 450 minecraft:red_nether_bricks
setblock 470 123 451 minecraft:orange_concrete
fill 473 123 430 475 123 431 minecraft:orange_concrete
fill 474 123 428 475 123 429 minecraft:orange_concrete
fill 474 123 432 475 123 433 minecraft:orange_concrete
setblock 474 123 458 minecraft:orange_concrete
fill 475 123 427 481 123 427 minecraft:orange_concrete
fill 475 123 434 480 123 434 minecraft:orange_concrete
fill 476 123 416 476 141 416 minecraft:red_nether_bricks
fill 476 123 426 479 123 426 minecraft:orange_concrete
fill 476 123 428 476 125 428 minecraft:orange_concrete
fill 476 123 433 481 123 433 minecraft:orange_concrete
fill 477 123 435 479 123 435 minecraft:orange_concrete
setblock 478 123 458 minecraft:orange_concrete
fill 479 123 428 481 123 428 minecraft:orange_concrete
fill 479 123 458 479 141 458 minecraft:red_nether_bricks
setblock 480 123 416 minecraft:orange_concrete
fill 480 123 429 482 123 429 minecraft:orange_concrete
fill 480 123 432 482 123 432 minecraft:orange_concrete
fill 481 123 430 482 123 431 minecraft:orange_concrete
fill 487 123 416 487 141 416 minecraft:red_nether_bricks
setblock 488 123 416 minecraft:orange_concrete
fill 490 123 458 490 125 458 minecraft:red_nether_bricks
setblock 491 123 416 minecraft:orange_concrete
setblock 495 123 458 minecraft:orange_concrete
setblock 498 123 458 minecraft:orange_concrete
fill 499 123 458 499 141 458 minecraft:red_nether_bricks
fill 503 123 449 504 123 449 minecraft:magma_block
fill 505 123 421 505 125 421 minecraft:magma_block
setblock 506 123 458 minecraft:orange_concrete
fill 507 123 416 508 141 416 minecraft:red_nether_bricks
fill 510 123 458 510 141 458 minecraft:red_nether_bricks
setblock 512 123 416 minecraft:orange_concrete
setblock 512 123 427 minecraft:orange_concrete
fill 512 123 432 512 141 432 minecraft:red_nether_bricks
fill 512 123 443 512 141 443 minecraft:red_nether_bricks
setblock 512 123 444 minecraft:orange_concrete
fill 512 123 447 512 123 448 minecraft:orange_concrete
fill 470 124 420 470 125 421 minecraft:orange_concrete
fill 470 124 422 470 137 423 minecraft:red_nether_bricks
fill 470 124 429 470 125 429 minecraft:orange_concrete
fill 470 124 431 470 137 431 minecraft:red_nether_bricks
fill 470 124 432 470 124 433 minecraft:orange_concrete
fill 470 124 434 470 141 434 minecraft:red_nether_bricks
fill 470 124 440 470 125 441 minecraft:orange_concrete
fill 470 124 442 470 137 443 minecraft:red_nether_bricks
fill 470 124 451 470 125 451 minecraft:red_nether_bricks
fill 470 124 452 470 124 453 minecraft:orange_concrete
fill 470 124 454 470 137 455 minecraft:red_nether_bricks
fill 472 124 458 473 125 458 minecraft:orange_concrete
fill 474 124 429 475 124 431 minecraft:orange_concrete
fill 474 124 458 475 137 458 minecraft:red_nether_bricks
setblock 475 124 428 minecraft:orange_concrete
fill 475 124 432 475 124 433 minecraft:orange_concrete
fill 476 124 427 479 124 427 minecraft:orange_concrete
fill 476 124 433 479 124 434 minecraft:orange_concrete
setblock 476 124 458 minecraft:orange_concrete
fill 478 124 458 478 141 458 minecraft:red_nether_bricks
fill 479 124 416 480 137 416 minecraft:red_nether_bricks
fill 479 124 428 480 124 428 minecraft:orange_concrete
fill 480 124 429 481 124 429 minecraft:orange_concrete
fill 480 124 432 480 124 433 minecraft:orange_concrete
fill 481 124 416 482 125 416 minecraft:orange_concrete
fill 481 124 430 481 124 432 minecraft:orange_concrete
fill 484 124 458 485 125 458 minecraft:orange_concrete
fill 486 124 458 487 137 458 minecraft:red_nether_bricks
fill 488 124 416 488 141 416 minecraft:red_nether_bricks
fill 489 124 416 490 124 416 minecraft:orange_concrete
fill 491 124 416 491 137 416 minecraft:red_nether_bricks
setblock 492 124 458 minecraft:red_nether_bricks
fill 493 124 416 493 125 416 minecraft:orange_concrete
fill 493 124 458 493 125 458 minecraft:orange_concrete
fill 495 124 458 495 137 458 minecraft:red_nether_bricks
fill 496 124 458 497 124 458 minecraft:orange_concrete
fill 498 124 458 498 141 458 minecraft:red_nether_bricks
fill 499 124 416 500 137 416 minecraft:red_nether_bricks
fill 501 124 416 502 125 416 minecraft:orange_concrete
setblock 504 124 421 minecraft:magma_block
fill 504 124 458 505 125 458 minecraft:orange_concrete
setblock 505 124 418 minecraft:magma_block
fill 505 124 422 505 125 422 minecraft:magma_block
setblock 506 124 421 minecraft:magma_block
fill 506 124 458 507 137 458 minecraft:red_nether_bricks
setblock 510 124 416 minecraft:orange_concrete
fill 511 124 416 512 137 416 minecraft:red_nether_bricks
fill 512 124 417 512 125 418 minecraft:orange_concrete
fill 512 124 423 512 141 424 minecraft:red_nether_bricks
fill 512 124 425 512 124 426 minecraft:orange_concrete
fill 512 124 427 512 137 427 minecraft:red_nether_bricks
fill 512 124 435 512 137 436 minecraft:red_nether_bricks
fill 512 124 437 512 125 438 minecraft:orange_concrete
fill 512 124 444 512 141 444 minecraft:red_nether_bricks
setblock 512 124 446 minecraft:orange_concrete
fill 512 124 447 512 137 448 minecraft:red_nether_bricks
fill 512 124 449 512 125 449 minecraft:orange_concrete
fill 512 124 455 512 137 456 minecraft:red_nether_bricks
setblock 512 124 457 minecraft:orange_concrete
setblock 470 125 417 minecraft:orange_concrete
setblock 470 125 428 minecraft:orange_concrete
fill 470 125 432 470 136 433 minecraft:red_nether_bricks
fill 470 125 448 470 125 449 minecraft:orange_concrete
setblock 470 125 452 minecraft:orange_concrete
fill 470 125 453 470 136 453 minecraft:red_nether_bricks
fill 471 125 416 472 125 416 minecraft:red_nether_bricks
setblock 473 125 416 minecraft:orange_concrete
fill 475 125 429 475 125 432 minecraft:orange_concrete
fill 476 125 433 479 125 433 minecraft:orange_concrete
fill 476 125 458 476 136 458 minecraft:red_nether_bricks
setblock 479 125 428 minecraft:orange_concrete
setblock 480 125 429 minecraft:orange_concrete
setblock 480 125 432 minecraft:orange_concrete
fill 480 125 458 480 139 458 minecraft:red_nether_bricks
setblock 481 125 458 minecraft:orange_concrete
fill 489 125 416 490 136 416 minecraft:red_nether_bricks
setblock 492 125 458 minecraft:orange_concrete
setblock 494 125 416 minecraft:orange_concrete
fill 495 125 416 496 125 416 minecraft:red_nether_bricks
fill 496 125 458 497 136 458 minecraft:red_nether_bricks
fill 503 125 416 504 125 416 minecraft:red_nether_bricks
setblock 505 125 416 minecraft:orange_concrete
fill 510 125 416 510 136 416 minecraft:red_nether_bricks
fill 512 125 425 512 136 425 minecraft:red_nether_bricks
setblock 512 125 426 minecraft:orange_concrete
fill 512 125 429 512 125 430 minecraft:orange_concrete
fill 512 125 446 512 136 446 minecraft:red_nether_bricks
setblock 512 125 450 minecraft:orange_concrete
fill 512 125 457 512 136 457 minecraft:red_nether_bricks
fill 470 126 417 473 126 417 minecraft:red_nether_bricks
fill 470 126 418 470 126 419 minecraft:orange_concrete
fill 470 126 420 471 126 421 minecraft:red_nether_bricks
fill 470 126 426 470 126 427 minecraft:orange_concrete
fill 470 126 428 471 126 429 minecraft:red_nether_bricks
setblock 470 126 430 minecraft:orange_concrete
fill 470 126 438 470 126 439 minecraft:orange_concrete
fill 470 126 440 471 126 441 minecraft:red_nether_bricks
setblock 470 126 447 minecraft:orange_concrete
fill 470 126 448 471 126 449 minecraft:red_nether_bricks
fill 470 126 450 470 126 451 minecraft:orange_concrete
fill 470 126 452 471 126 452 minecraft:red_nether_bricks
fill 470 126 458 471 126 458 minecraft:orange_concrete
fill 471 126 416 472 126 416 minecraft:orange_concrete
setblock 471 126 419 minecraft:red_nether_bricks
fill 471 126 423 471 126 425 minecraft:red_nether_bricks
setblock 471 126 427 minecraft:red_nether_bricks
fill 471 126 431 471 126 433 minecraft:red_nether_bricks
fill 471 126 435 471 126 437 minecraft:red_nether_bricks
setblock 471 126 439 minecraft:red_nether_bricks
fill 471 126 443 471 126 445 minecraft:red_nether_bricks
setblock 471 126 447 minecraft:red_nether_bricks
setblock 471 126 451 minecraft:red_nether_bricks
setblock 471 126 453 minecraft:red_nether_bricks
fill 471 126 455 471 126 457 minecraft:red_nether_bricks
fill 472 126 458 473 139 458 minecraft:red_nether_bricks
fill 473 126 416 473 139 416 minecraft:red_nether_bricks
fill 473 126 457 475 126 457 minecraft:red_nether_bricks
setblock 475 126 416 minecraft:orange_concrete
fill 475 126 417 477 126 417 minecraft:red_nether_bricks
fill 477 126 457 479 126 457 minecraft:red_nether_bricks
fill 479 126 417 481 126 417 minecraft:red_nether_bricks
fill 481 126 416 482 136 416 minecraft:red_nether_bricks
fill 481 126 457 481 126 458 minecraft:red_nether_bricks
fill 482 126 457 483 126 457 minecraft:red_nether_bricks
fill 482 126 458 483 126 458 minecraft:orange_concrete
fill 483 126 416 484 126 416 minecraft:orange_concrete
fill 483 126 417 485 126 417 minecraft:red_nether_bricks
fill 484 126 458 485 136 458 minecraft:red_nether_bricks
fill 485 126 457 487 126 457 minecraft:red_nether_bricks
fill 487 126 417 489 126 417 minecraft:red_nether_bricks
fill 489 126 457 491 126 457 minecraft:red_nether_bricks
fill 490 126 458 491 126 458 minecraft:orange_concrete
fill 491 126 417 493 126 417 minecraft:red_nether_bricks
setblock 492 126 416 minecraft:orange_concrete
fill 492 126 458 493 139 458 minecraft:red_nether_bricks
fill 493 126 416 494 139 416 minecraft:red_nether_bricks
fill 493 126 457 495 126 457 minecraft:red_nether_bricks
setblock 494 126 458 minecraft:orange_concrete
fill 495 126 416 496 126 416 minecraft:orange_concrete
fill 495 126 417 497 126 417 minecraft:red_nether_bricks
fill 497 126 457 499 126 457 minecraft:red_nether_bricks
fill 499 126 417 501 126 417 minecraft:red_nether_bricks
fill 501 126 416 502 136 416 minecraft:red_nether_bricks
fill 501 126 457 503 126 457 minecraft:red_nether_bricks
fill 502 126 458 503 126 458 minecraft:orange_concrete
fill 503 126 416 504 126 416 minecraft:orange_concrete
fill 503 126 417 505 126 417 minecraft:red_nether_bricks
fill 504 126 458 505 136 458 minecraft:red_nether_bricks
fill 505 126 416 505 139 416 minecraft:red_nether_bricks
fill 505 126 457 507 126 457 minecraft:red_nether_bricks
fill 507 126 417 509 126 417 minecraft:red_nether_bricks
fill 509 126 457 511 126 457 minecraft:red_nether_bricks
fill 511 126 417 511 126 419 minecraft:red_nether_bricks
fill 511 126 421 511 126 423 minecraft:red_nether_bricks
fill 511 126 425 511 126 427 minecraft:red_nether_bricks
fill 511 126 429 511 126 431 minecraft:red_nether_bricks
fill 511 126 433 511 126 435 minecraft:red_nether_bricks
fill 511 126 437 511 126 439 minecraft:red_nether_bricks
fill 511 126 441 511 126 443 minecraft:red_nether_bricks
fill 511 126 445 511 126 447 minecraft:red_nether_bricks
fill 511 126 449 511 126 451 minecraft:red_nether_bricks
fill 511 126 453 511 126 455 minecraft:red_nether_bricks
setblock 511 126 458 minecraft:orange_concrete
fill 512 126 417 512 139 418 minecraft:red_nether_bricks
fill 512 126 419 512 126 420 minecraft:orange_concrete
fill 512 126 426 512 136 426 minecraft:red_nether_bricks
setblock 512 126 428 minecraft:orange_concrete
fill 512 126 429 512 139 430 minecraft:red_nether_bricks
setblock 512 126 431 minecraft:orange_concrete
fill 512 126 437 512 136 438 minecraft:red_nether_bricks
fill 512 126 439 512 126 440 minecraft:orange_concrete
fill 512 126 449 512 139 450 minecraft:red_nether_bricks
fill 512 126 451 512 126 452 minecraft:orange_concrete
fill 470 127 417 470 136 421 minecraft:red_nether_bricks
fill 470 127 426 470 137 430 minecraft:red_nether_bricks
fill 470 127 438 470 136 441 minecraft:red_nether_bricks
fill 470 127 447 470 136 452 minecraft:red_nether_bricks
fill 470 127 458 471 138 458 minecraft:red_nether_bricks
fill 471 127 416 472 137 416 minecraft:red_nether_bricks
fill 475 127 416 475 141 416 minecraft:red_nether_bricks
fill 481 127 458 483 137 458 minecraft:red_nether_bricks
fill 483 127 416 484 138 416 minecraft:red_nether_bricks
fill 489 127 437 492 127 438 minecraft:shroomlight
fill 490 127 458 491 141 458 minecraft:red_nether_bricks
fill 491 127 439 492 127 439 minecraft:shroomlight
fill 492 127 416 492 137 416 minecraft:red_nether_bricks
setblock 492 127 440 minecraft:shroomlight
fill 494 127 458 494 137 458 minecraft:red_nether_bricks
fill 495 127 416 496 141 416 minecraft:red_nether_bricks
fill 502 127 458 503 138 458 minecraft:red_nether_bricks
fill 503 127 416 504 137 416 minecraft:red_nether_bricks
fill 511 127 458 511 141 458 minecraft:red_nether_bricks
fill 512 127 419 512 138 420 minecraft:red_nether_bricks
fill 512 127 428 512 137 428 minecraft:red_nether_bricks
fill 512 127 431 512 141 431 minecraft:red_nether_bricks
fill 512 127 439 512 137 440 minecraft:red_nether_bricks
fill 512 127 451 512 138 452 minecraft:red_nether_bricks
setblock 473 128 419 minecraft:light[level=14]
setblock 473 128 427 minecraft:light[level=14]
setblock 473 128 435 minecraft:light[level=14]
setblock 473 128 443 minecraft:light[level=14]
setblock 473 128 451 minecraft:light[level=14]
setblock 481 128 419 minecraft:light[level=14]
setblock 481 128 427 minecraft:light[level=14]
setblock 481 128 435 minecraft:light[level=14]
setblock 481 128 443 minecraft:light[level=14]
setblock 481 128 451 minecraft:light[level=14]
fill 487 128 437 488 128 440 minecraft:shroomlight
fill 488 128 436 493 128 436 minecraft:shroomlight
fill 488 128 441 489 128 441 minecraft:shroomlight
setblock 489 128 419 minecraft:light[level=14]
setblock 489 128 427 minecraft:light[level=14]
fill 489 128 435 492 128 435 minecraft:shroomlight
fill 489 128 437 492 130 438 minecraft:magma_block
fill 489 128 442 492 128 442 minecraft:shroomlight
setblock 489 128 443 minecraft:light[level=14]
setblock 489 128 451 minecraft:light[level=14]
fill 491 128 439 492 130 439 minecraft:magma_block
fill 491 128 441 493 128 441 minecraft:shroomlight
fill 492 128 440 492 130 440 minecraft:magma_block
fill 493 128 437 494 128 440 minecraft:shroomlight
setblock 497 128 419 minecraft:light[level=14]
setblock 497 128 427 minecraft:light[level=14]
setblock 497 128 435 minecraft:light[level=14]
setblock 497 128 443 minecraft:light[level=14]
setblock 497 128 451 minecraft:light[level=14]
setblock 505 128 419 minecraft:light[level=14]
setblock 505 128 427 minecraft:light[level=14]
setblock 505 128 435 minecraft:light[level=14]
setblock 505 128 443 minecraft:light[level=14]
setblock 505 128 451 minecraft:light[level=14]
fill 486 129 437 486 130 440 minecraft:shroomlight
setblock 487 129 436 minecraft:shroomlight
fill 487 129 437 488 130 440 minecraft:magma_block
setblock 487 129 441 minecraft:shroomlight
setblock 488 129 435 minecraft:shroomlight
fill 488 129 436 493 133 436 minecraft:magma_block
fill 488 129 441 489 130 441 minecraft:magma_block
setblock 488 129 442 minecraft:shroomlight
fill 489 129 434 492 130 434 minecraft:shroomlight
fill 489 129 435 492 134 435 minecraft:magma_block
fill 489 129 442 492 130 442 minecraft:magma_block
fill 489 129 443 492 130 443 minecraft:shroomlight
fill 491 129 441 493 130 441 minecraft:magma_block
setblock 493 129 435 minecraft:shroomlight
fill 493 129 437 494 132 440 minecraft:magma_block
setblock 493 129 442 minecraft:shroomlight
setblock 494 129 436 minecraft:shroomlight
setblock 494 129 441 minecraft:shroomlight
fill 495 129 437 495 130 440 minecraft:shroomlight
fill 486 130 436 486 134 436 minecraft:shroomlight
fill 486 130 441 486 133 441 minecraft:shroomlight
setblock 487 130 435 minecraft:shroomlight
fill 487 130 436 487 133 436 minecraft:magma_block
fill 487 130 441 487 132 441 minecraft:magma_block
setblock 487 130 442 minecraft:shroomlight
fill 488 130 434 488 135 434 minecraft:shroomlight
fill 488 130 435 488 134 435 minecraft:magma_block
fill 488 130 442 488 132 442 minecraft:magma_block
fill 488 130 443 488 133 443 minecraft:shroomlight
fill 493 130 434 493 135 434 minecraft:shroomlight
fill 493 130 435 493 134 435 minecraft:magma_block
fill 493 130 442 493 133 442 minecraft:magma_block
fill 493 130 443 493 133 443 minecraft:shroomlight
setblock 494 130 435 minecraft:shroomlight
fill 494 130 436 494 134 436 minecraft:magma_block
fill 494 130 441 494 133 441 minecraft:magma_block
setblock 494 130 442 minecraft:shroomlight
fill 495 130 436 495 134 436 minecraft:shroomlight
fill 495 130 441 495 133 441 minecraft:shroomlight
fill 485 131 437 485 133 440 minecraft:shroomlight
fill 486 131 435 486 134 435 minecraft:shroomlight
fill 486 131 437 487 132 440 minecraft:magma_block
fill 486 131 442 486 133 442 minecraft:shroomlight
fill 487 131 434 487 134 434 minecraft:shroomlight
fill 487 131 435 487 134 435 minecraft:magma_block
fill 487 131 442 487 133 442 minecraft:magma_block
fill 487 131 443 487 133 443 minecraft:shroomlight
fill 488 131 437 488 132 439 minecraft:magma_block
fill 488 131 441 488 132 441 minecraft:magma_block
fill 489 131 433 492 134 433 minecraft:shroomlight
fill 489 131 434 492 134 434 minecraft:magma_block
fill 489 131 437 489 132 438 minecraft:magma_block
fill 489 131 442 489 132 443 minecraft:magma_block
fill 489 131 444 492 133 444 minecraft:shroomlight
fill 490 131 437 492 132 437 minecraft:magma_block
fill 490 131 443 492 132 443 minecraft:magma_block
fill 491 131 438 492 132 438 minecraft:magma_block
fill 491 131 442 492 132 442 minecraft:magma_block
fill 492 131 439 492 132 439 minecraft:magma_block
fill 492 131 441 493 132 441 minecraft:magma_block
fill 494 131 434 494 134 434 minecraft:shroomlight
fill 494 131 435 494 134 435 minecraft:magma_block
fill 494 131 442 494 133 442 minecraft:magma_block
fill 494 131 443 494 133 443 minecraft:shroomlight
fill 495 131 435 495 134 435 minecraft:shroomlight
fill 495 131 437 495 133 440 minecraft:magma_block
fill 495 131 442 495 133 442 minecraft:shroomlight
fill 496 131 437 496 133 440 minecraft:shroomlight
fill 471 133 417 484 133 457 minecraft:blackstone
fill 485 133 417 485 133 436 minecraft:blackstone
fill 485 133 441 485 133 457 minecraft:blackstone
fill 486 133 417 486 133 434 minecraft:blackstone
fill 486 133 437 486 133 440 minecraft:magma_block
fill 486 133 443 486 133 457 minecraft:blackstone
fill 487 133 417 488 133 433 minecraft:blackstone
fill 487 133 437 487 133 438 minecraft:magma_block
setblock 487 133 439 minecraft:red_nether_bricks
fill 487 133 440 487 135 440 minecraft:quartz_block
setblock 487 133 441 minecraft:red_nether_bricks
fill 487 133 444 488 133 457 minecraft:blackstone
setblock 488 133 437 minecraft:magma_block
fill 488 133 438 488 133 439 minecraft:shroomlight
fill 488 133 441 488 133 442 minecraft:shroomlight
fill 489 133 417 511 133 432 minecraft:blackstone
fill 489 133 437 489 133 438 minecraft:shroomlight
fill 489 133 442 489 133 443 minecraft:shroomlight
fill 489 133 445 511 133 457 minecraft:blackstone
fill 490 133 437 490 135 437 minecraft:quartz_block
fill 490 133 443 490 135 443 minecraft:quartz_block
fill 491 133 437 491 133 438 minecraft:shroomlight
fill 491 133 442 491 133 443 minecraft:shroomlight
fill 492 133 437 494 133 437 minecraft:magma_block
fill 492 133 438 492 133 439 minecraft:shroomlight
fill 492 133 441 492 133 442 minecraft:shroomlight
setblock 492 133 443 minecraft:magma_block
fill 493 133 433 511 133 433 minecraft:blackstone
fill 493 133 438 494 133 438 minecraft:magma_block
setblock 493 133 439 minecraft:red_nether_bricks
fill 493 133 440 493 135 440 minecraft:quartz_block
setblock 493 133 441 minecraft:red_nether_bricks
fill 493 133 444 511 133 444 minecraft:blackstone
fill 494 133 439 494 133 440 minecraft:magma_block
fill 495 133 434 511 133 434 minecraft:blackstone
fill 495 133 443 511 133 443 minecraft:blackstone
fill 496 133 435 511 133 436 minecraft:blackstone
fill 496 133 441 511 133 442 minecraft:blackstone
fill 497 133 437 511 133 440 minecraft:blackstone
fill 484 134 440 486 134 440 minecraft:red_nether_bricks
setblock 485 134 437 minecraft:shroomlight
fill 485 134 438 486 134 439 minecraft:red_nether_bricks
fill 485 134 441 486 134 442 minecraft:red_nether_bricks
fill 486 134 437 487 139 437 minecraft:red_nether_bricks
fill 486 134 443 487 139 443 minecraft:red_nether_bricks
fill 487 134 436 493 134 436 minecraft:red_nether_bricks
fill 487 134 438 487 135 439 minecraft:quartz_block
fill 487 134 441 487 135 442 minecraft:quartz_block
fill 487 134 444 493 134 444 minecraft:red_nether_bricks
fill 488 134 437 489 135 437 minecraft:quartz_block
setblock 488 134 438 minecraft:red_nether_bricks
setblock 488 134 442 minecraft:red_nether_bricks
fill 488 134 443 489 135 443 minecraft:quartz_block
fill 491 134 437 492 135 437 minecraft:quartz_block
fill 491 134 443 492 135 443 minecraft:quartz_block
setblock 492 134 438 minecraft:red_nether_bricks
setblock 492 134 442 minecraft:red_nether_bricks
fill 493 134 437 494 136 437 minecraft:red_nether_bricks
fill 493 134 438 493 135 439 minecraft:quartz_block
fill 493 134 441 493 135 442 minecraft:quartz_block
fill 493 134 443 494 136 443 minecraft:red_nether_bricks
fill 494 134 438 495 134 442 minecraft:red_nether_bricks
setblock 495 134 437 minecraft:magma_block
fill 496 134 437 496 134 439 minecraft:shroomlight
setblock 496 134 440 minecraft:red_nether_bricks
fill 483 135 438 485 142 442 minecraft:red_nether_bricks
fill 484 135 437 485 144 437 minecraft:red_nether_bricks
fill 484 135 443 485 144 443 minecraft:red_nether_bricks
fill 485 135 436 487 142 436 minecraft:red_nether_bricks
fill 485 135 444 487 142 444 minecraft:red_nether_bricks
fill 486 135 435 494 142 435 minecraft:red_nether_bricks
setblock 486 135 438 minecraft:quartz_block
fill 486 135 439 486 139 439 minecraft:red_nether_bricks
setblock 486 135 440 minecraft:quartz_block
fill 486 135 441 486 139 441 minecraft:red_nether_bricks
setblock 486 135 442 minecraft:quartz_block
fill 486 135 445 494 142 445 minecraft:red_nether_bricks
setblock 488 135 436 minecraft:quartz_block
setblock 488 135 444 minecraft:quartz_block
fill 489 135 434 491 144 434 minecraft:red_nether_bricks
fill 489 135 436 489 139 436 minecraft:red_nether_bricks
fill 489 135 444 489 139 444 minecraft:red_nether_bricks
fill 489 135 446 491 144 446 minecraft:red_nether_bricks
setblock 490 135 436 minecraft:quartz_block
setblock 490 135 444 minecraft:quartz_block
fill 491 135 436 491 139 436 minecraft:red_nether_bricks
fill 491 135 444 491 139 444 minecraft:red_nether_bricks
setblock 492 135 434 minecraft:shroomlight
setblock 492 135 436 minecraft:quartz_block
setblock 492 135 444 minecraft:quartz_block
fill 493 135 436 495 142 436 minecraft:red_nether_bricks
fill 493 135 444 495 142 444 minecraft:red_nether_bricks
setblock 494 135 438 minecraft:quartz_block
setblock 494 135 439 minecraft:red_nether_bricks
setblock 494 135 440 minecraft:quartz_block
setblock 494 135 441 minecraft:red_nether_bricks
setblock 494 135 442 minecraft:quartz_block
fill 495 135 437 495 135 438 minecraft:red_nether_bricks
fill 495 135 439 501 141 441 minecraft:nether_bricks
fill 495 135 442 495 135 443 minecraft:red_nether_bricks
setblock 496 135 437 minecraft:red_nether_bricks
fill 496 135 438 500 141 438 minecraft:nether_bricks
fill 496 135 442 500 141 442 minecraft:nether_bricks
setblock 496 135 443 minecraft:red_nether_bricks
setblock 473 136 419 minecraft:light[level=14]
setblock 473 136 427 minecraft:light[level=14]
setblock 473 136 435 minecraft:light[level=14]
setblock 473 136 443 minecraft:light[level=14]
setblock 473 136 451 minecraft:light[level=14]
setblock 481 136 419 minecraft:light[level=14]
setblock 481 136 427 minecraft:light[level=14]
setblock 481 136 435 minecraft:light[level=14]
setblock 481 136 443 minecraft:light[level=14]
setblock 481 136 451 minecraft:light[level=14]
fill 482 136 438 482 143 442 minecraft:red_nether_bricks
fill 483 136 437 483 144 437 minecraft:red_nether_bricks
fill 483 136 443 483 144 443 minecraft:red_nether_bricks
fill 484 136 436 484 144 436 minecraft:red_nether_bricks
fill 484 136 444 484 144 444 minecraft:red_nether_bricks
fill 485 136 435 485 144 435 minecraft:red_nether_bricks
fill 485 136 445 485 144 445 minecraft:red_nether_bricks
fill 486 136 434 488 143 434 minecraft:red_nether_bricks
fill 486 136 438 487 137 438 minecraft:red_nether_bricks
fill 486 136 440 486 138 440 minecraft:red_nether_bricks
fill 486 136 442 487 137 442 minecraft:red_nether_bricks
fill 486 136 446 488 143 446 minecraft:red_nether_bricks
setblock 487 136 439 minecraft:red_nether_bricks
setblock 487 136 441 minecraft:red_nether_bricks
fill 488 136 436 488 137 437 minecraft:red_nether_bricks
fill 488 136 443 488 137 444 minecraft:red_nether_bricks
setblock 489 136 419 minecraft:light[level=14]
setblock 489 136 427 minecraft:light[level=14]
setblock 489 136 437 minecraft:red_nether_bricks
setblock 489 136 443 minecraft:red_nether_bricks
setblock 489 136 451 minecraft:light[level=14]
fill 490 136 436 490 138 436 minecraft:red_nether_bricks
fill 490 136 444 490 138 444 minecraft:red_nether_bricks
fill 491 136 437 492 136 437 minecraft:red_nether_bricks
fill 491 136 443 492 136 443 minecraft:red_nether_bricks
fill 492 136 434 494 143 434 minecraft:red_nether_bricks
fill 492 136 436 492 140 436 minecraft:red_nether_bricks
fill 492 136 444 492 140 444 minecraft:red_nether_bricks
fill 492 136 446 494 143 446 minecraft:red_nether_bricks
fill 493 136 438 493 136 439 minecraft:red_nether_bricks
fill 493 136 441 493 136 442 minecraft:red_nether_bricks
fill 494 136 438 494 138 442 minecraft:nether_bricks
fill 495 136 435 495 144 435 minecraft:red_nether_bricks
fill 495 136 437 495 140 438 minecraft:nether_bricks
fill 495 136 442 495 140 443 minecraft:nether_bricks
fill 495 136 445 495 144 445 minecraft:red_nether_bricks
setblock 496 136 436 minecraft:red_nether_bricks
fill 496 136 437 501 140 437 minecraft:nether_bricks
fill 496 136 443 501 140 443 minecraft:nether_bricks
setblock 496 136 444 minecraft:red_nether_bricks
setblock 497 136 419 minecraft:light[level=14]
setblock 497 136 427 minecraft:light[level=14]
setblock 497 136 435 minecraft:light[level=14]
setblock 497 136 451 minecraft:light[level=14]
fill 501 136 438 502 138 438 minecraft:nether_bricks
fill 501 136 442 502 138 442 minecraft:nether_bricks
fill 502 136 439 502 140 441 minecraft:nether_bricks
fill 503 136 440 503 140 440 minecraft:nether_bricks
setblock 505 136 419 minecraft:light[level=14]
setblock 505 136 427 minecraft:light[level=14]
setblock 505 136 435 minecraft:light[level=14]
setblock 505 136 443 minecraft:light[level=14]
setblock 505 136 451 minecraft:light[level=14]
fill 470 137 417 470 137 419 minecraft:red_nether_bricks
fill 470 137 420 470 137 421 minecraft:orange_concrete
setblock 470 137 424 minecraft:orange_concrete
fill 470 137 425 470 140 425 minecraft:red_nether_bricks
fill 470 137 432 470 137 433 minecraft:orange_concrete
fill 470 137 438 470 137 440 minecraft:red_nether_bricks
setblock 470 137 441 minecraft:orange_concrete
fill 470 137 444 470 137 445 minecraft:orange_concrete
fill 470 137 447 470 137 451 minecraft:red_nether_bricks
fill 470 137 452 470 137 453 minecraft:orange_concrete
fill 476 137 458 477 137 458 minecraft:orange_concrete
fill 477 137 416 478 137 416 minecraft:orange_concrete
setblock 481 137 416 minecraft:orange_concrete
fill 481 137 439 481 142 441 minecraft:red_nether_bricks
fill 482 137 416 482 139 416 minecraft:red_nether_bricks
fill 482 137 437 482 143 437 minecraft:red_nether_bricks
fill 482 137 443 482 143 443 minecraft:red_nether_bricks
fill 482 137 449 485 140 451 minecraft:red_nether_bricks
fill 483 137 436 483 143 436 minecraft:red_nether_bricks
fill 483 137 444 483 143 444 minecraft:red_nether_bricks
fill 483 137 448 484 140 448 minecraft:red_nether_bricks
fill 484 137 435 484 143 435 minecraft:red_nether_bricks
fill 484 137 445 484 143 445 minecraft:red_nether_bricks
fill 484 137 458 485 137 458 minecraft:orange_concrete
fill 485 137 434 485 142 434 minecraft:red_nether_bricks
fill 485 137 446 485 142 446 minecraft:red_nether_bricks
fill 487 137 433 493 141 433 minecraft:red_nether_bricks
fill 487 137 447 493 141 447 minecraft:red_nether_bricks
setblock 488 137 458 minecraft:orange_concrete
fill 489 137 416 490 137 416 minecraft:orange_concrete
fill 489 137 458 489 140 458 minecraft:red_nether_bricks
fill 492 137 437 493 137 437 minecraft:red_nether_bricks
fill 492 137 443 493 137 443 minecraft:red_nether_bricks
fill 493 137 421 493 138 421 minecraft:magma_block
setblock 493 137 438 minecraft:nether_bricks
setblock 493 137 442 minecraft:nether_bricks
fill 494 137 437 494 139 437 minecraft:nether_bricks
fill 494 137 443 494 139 443 minecraft:nether_bricks
fill 495 137 434 495 142 434 minecraft:red_nether_bricks
fill 495 137 446 495 142 446 minecraft:red_nether_bricks
fill 496 137 435 496 143 435 minecraft:red_nether_bricks
fill 496 137 436 500 139 436 minecraft:nether_bricks
fill 496 137 444 500 139 444 minecraft:nether_bricks
fill 496 137 445 496 143 445 minecraft:red_nether_bricks
fill 496 137 458 497 137 458 minecraft:orange_concrete
fill 497 137 416 497 140 416 minecraft:red_nether_bricks
setblock 498 137 416 minecraft:orange_concrete
fill 501 137 416 502 137 416 minecraft:orange_concrete
fill 502 137 437 502 139 437 minecraft:nether_bricks
fill 502 137 443 502 139 443 minecraft:nether_bricks
fill 503 137 438 503 139 439 minecraft:nether_bricks
fill 503 137 441 503 139 442 minecraft:nether_bricks
fill 504 137 458 504 139 458 minecraft:red_nether_bricks
setblock 505 137 458 minecraft:orange_concrete
fill 508 137 458 509 137 458 minecraft:orange_concrete
fill 509 137 416 510 137 416 minecraft:orange_concrete
fill 512 137 425 512 137 426 minecraft:orange_concrete
fill 512 137 433 512 140 433 minecraft:red_nether_bricks
setblock 512 137 434 minecraft:orange_concrete
setblock 512 137 437 minecraft:orange_concrete
fill 512 137 438 512 139 438 minecraft:red_nether_bricks
fill 512 137 445 512 137 446 minecraft:orange_concrete
setblock 512 137 457 minecraft:orange_concrete
fill 470 138 417 470 138 418 minecraft:red_nether_bricks
fill 470 138 419 470 139 419 minecraft:orange_concrete
fill 470 138 420 471 138 421 minecraft:red_nether_bricks
setblock 470 138 422 minecraft:orange_concrete
fill 470 138 423 471 138 424 minecraft:red_nether_bricks
fill 470 138 426 470 138 429 minecraft:red_nether_bricks
fill 470 138 430 470 139 431 minecraft:orange_concrete
fill 470 138 432 471 138 433 minecraft:red_nether_bricks
setblock 470 138 438 minecraft:red_nether_bricks
fill 470 138 439 470 139 439 minecraft:orange_concrete
fill 470 138 440 471 138 441 minecraft:red_nether_bricks
fill 470 138 442 470 138 443 minecraft:orange_concrete
fill 470 138 444 471 138 445 minecraft:red_nether_bricks
fill 470 138 447 471 138 449 minecraft:red_nether_bricks
fill 470 138 450 470 139 451 minecraft:orange_concrete
fill 470 138 452 471 138 453 minecraft:red_nether_bricks
setblock 470 138 454 minecraft:orange_concrete
fill 470 138 455 471 138 455 minecraft:red_nether_bricks
fill 471 138 416 472 139 416 minecraft:orange_concrete
fill 471 138 417 473 138 417 minecraft:red_nether_bricks
setblock 471 138 419 minecraft:red_nether_bricks
setblock 471 138 425 minecraft:red_nether_bricks
fill 471 138 427 471 138 429 minecraft:red_nether_bricks
setblock 471 138 431 minecraft:red_nether_bricks
fill 471 138 435 471 138 437 minecraft:red_nether_bricks
setblock 471 138 439 minecraft:red_nether_bricks
setblock 471 138 443 minecraft:red_nether_bricks
setblock 471 138 451 minecraft:red_nether_bricks
fill 471 138 456 471 138 457 minecraft:red_nether_bricks
fill 473 138 457 475 138 457 minecraft:red_nether_bricks
fill 474 138 458 475 138 458 minecraft:orange_concrete
fill 475 138 417 477 138 417 minecraft:red_nether_bricks
fill 476 138 458 477 143 458 minecraft:red_nether_bricks
fill 477 138 416 478 143 416 minecraft:red_nether_bricks
fill 477 138 457 479 138 457 minecraft:red_nether_bricks
fill 479 138 416 480 138 416 minecraft:orange_concrete
fill 479 138 417 481 138 417 minecraft:red_nether_bricks
fill 481 138 416 481 143 416 minecraft:red_nether_bricks
fill 481 138 438 481 142 438 minecraft:red_nether_bricks
fill 481 138 442 481 142 442 minecraft:red_nether_bricks
fill 481 138 449 481 139 451 minecraft:red_nether_bricks
fill 481 138 457 482 138 458 minecraft:red_nether_bricks
fill 482 138 436 482 142 436 minecraft:red_nether_bricks
fill 482 138 444 482 142 444 minecraft:red_nether_bricks
fill 482 138 448 482 139 448 minecraft:red_nether_bricks
fill 482 138 452 485 139 452 minecraft:red_nether_bricks
fill 483 138 417 485 138 417 minecraft:red_nether_bricks
fill 483 138 435 483 142 435 minecraft:red_nether_bricks
fill 483 138 445 483 142 445 minecraft:red_nether_bricks
setblock 483 138 457 minecraft:red_nether_bricks
fill 483 138 458 483 139 458 minecraft:orange_concrete
fill 484 138 434 484 141 434 minecraft:red_nether_bricks
fill 484 138 446 484 141 446 minecraft:red_nether_bricks
fill 484 138 458 485 143 458 minecraft:red_nether_bricks
fill 485 138 448 485 141 448 minecraft:red_nether_bricks
fill 485 138 457 487 138 457 minecraft:red_nether_bricks
fill 486 138 433 486 141 433 minecraft:red_nether_bricks
fill 486 138 438 486 140 438 minecraft:red_nether_bricks
fill 486 138 442 486 140 442 minecraft:red_nether_bricks
fill 486 138 447 486 141 447 minecraft:red_nether_bricks
fill 486 138 450 486 145 451 minecraft:red_nether_bricks
setblock 486 138 458 minecraft:orange_concrete
fill 487 138 417 489 138 417 minecraft:red_nether_bricks
fill 487 138 458 488 141 458 minecraft:red_nether_bricks
fill 488 138 436 488 140 436 minecraft:red_nether_bricks
fill 488 138 444 488 140 444 minecraft:red_nether_bricks
fill 489 138 416 490 143 416 minecraft:red_nether_bricks
fill 489 138 457 491 138 457 minecraft:red_nether_bricks
fill 491 138 416 492 139 416 minecraft:orange_concrete
fill 491 138 417 493 138 417 minecraft:red_nether_bricks
fill 493 138 437 493 139 437 minecraft:red_nether_bricks
fill 493 138 443 493 139 443 minecraft:red_nether_bricks
fill 493 138 457 495 138 457 minecraft:red_nether_bricks
fill 494 138 433 494 141 433 minecraft:red_nether_bricks
fill 494 138 447 494 141 447 minecraft:red_nether_bricks
fill 494 138 458 495 139 458 minecraft:orange_concrete
fill 495 138 417 497 138 417 minecraft:red_nether_bricks
fill 496 138 434 496 141 434 minecraft:red_nether_bricks
fill 496 138 446 496 141 446 minecraft:red_nether_bricks
fill 496 138 458 497 143 458 minecraft:red_nether_bricks
fill 497 138 435 497 142 435 minecraft:red_nether_bricks
fill 497 138 445 497 142 445 minecraft:red_nether_bricks
fill 497 138 457 499 138 457 minecraft:red_nether_bricks
fill 498 138 416 499 141 416 minecraft:red_nether_bricks
fill 499 138 417 501 138 417 minecraft:red_nether_bricks
setblock 500 138 416 minecraft:orange_concrete
fill 501 138 416 502 143 416 minecraft:red_nether_bricks
fill 501 138 457 503 138 457 minecraft:red_nether_bricks
fill 503 138 416 503 139 416 minecraft:orange_concrete
fill 503 138 417 505 138 417 minecraft:red_nether_bricks
setblock 504 138 416 minecraft:red_nether_bricks
fill 505 138 455 507 141 456 minecraft:magma_block
fill 505 138 457 505 138 458 minecraft:red_nether_bricks
fill 506 138 457 507 138 457 minecraft:red_nether_bricks
fill 506 138 458 507 138 458 minecraft:orange_concrete
fill 507 138 417 509 138 417 minecraft:red_nether_bricks
fill 508 138 458 509 143 458 minecraft:red_nether_bricks
fill 509 138 416 510 143 416 minecraft:red_nether_bricks
fill 509 138 457 512 138 457 minecraft:red_nether_bricks
fill 511 138 416 512 138 416 minecraft:orange_concrete
fill 511 138 417 511 138 419 minecraft:red_nether_bricks
fill 511 138 421 511 138 423 minecraft:red_nether_bricks
fill 511 138 425 511 138 427 minecraft:red_nether_bricks
fill 511 138 429 511 138 431 minecraft:red_nether_bricks
fill 511 138 433 511 138 435 minecraft:red_nether_bricks
fill 511 138 437 511 138 439 minecraft:red_nether_bricks
fill 511 138 441 511 138 443 minecraft:red_nether_bricks
fill 511 138 445 511 138 447 minecraft:red_nether_bricks
fill 511 138 449 511 138 451 minecraft:red_nether_bricks
fill 511 138 453 511 138 455 minecraft:red_nether_bricks
fill 512 138 425 512 143 426 minecraft:red_nether_bricks
fill 512 138 427 512 139 428 minecraft:orange_concrete
fill 512 138 434 512 143 434 minecraft:red_nether_bricks
fill 512 138 435 512 138 436 minecraft:orange_concrete
fill 512 138 437 512 143 437 minecraft:red_nether_bricks
fill 512 138 439 512 139 439 minecraft:orange_concrete
setblock 512 138 440 minecraft:red_nether_bricks
fill 512 138 445 512 143 446 minecraft:red_nether_bricks
fill 512 138 447 512 139 448 minecraft:orange_concrete
fill 512 138 455 512 141 455 minecraft:red_nether_bricks
setblock 512 138 456 minecraft:orange_concrete
setblock 470 139 417 minecraft:red_nether_bricks
setblock 470 139 418 minecraft:orange_concrete
fill 470 139 420 470 140 424 minecraft:red_nether_bricks
fill 470 139 426 470 141 426 minecraft:red_nether_bricks
setblock 470 139 427 minecraft:orange_concrete
fill 470 139 428 470 139 429 minecraft:red_nether_bricks
fill 470 139 432 470 143 433 minecraft:red_nether_bricks
setblock 470 139 438 minecraft:orange_concrete
fill 470 139 440 470 139 441 minecraft:red_nether_bricks
setblock 470 139 442 minecraft:orange_concrete
fill 470 139 443 470 140 445 minecraft:red_nether_bricks
fill 470 139 447 470 139 449 minecraft:red_nether_bricks
fill 470 139 452 470 141 455 minecraft:red_nether_bricks
fill 470 139 458 470 141 458 minecraft:red_nether_bricks
setblock 471 139 458 minecraft:orange_concrete
setblock 474 139 458 minecraft:orange_concrete
fill 475 139 458 475 142 458 minecraft:red_nether_bricks
fill 479 139 416 479 142 416 minecraft:red_nether_bricks
setblock 480 139 416 minecraft:orange_concrete
fill 481 139 437 481 141 437 minecraft:red_nether_bricks
fill 481 139 443 481 141 443 minecraft:red_nether_bricks
setblock 481 139 458 minecraft:red_nether_bricks
setblock 482 139 458 minecraft:orange_concrete
fill 483 139 416 484 139 416 minecraft:orange_concrete
fill 486 139 449 486 143 449 minecraft:red_nether_bricks
fill 486 139 452 486 145 452 minecraft:red_nether_bricks
fill 486 139 458 486 142 458 minecraft:red_nether_bricks
fill 487 139 451 487 146 451 minecraft:red_nether_bricks
fill 494 139 438 494 139 439 minecraft:nether_bricks
fill 494 139 441 494 139 442 minecraft:nether_bricks
fill 500 139 416 500 142 416 minecraft:red_nether_bricks
fill 501 139 438 501 141 438 minecraft:nether_bricks
fill 501 139 442 501 141 442 minecraft:nether_bricks
fill 502 139 438 502 140 438 minecraft:black_concrete
fill 502 139 442 502 140 442 minecraft:black_concrete
fill 502 139 458 503 139 458 minecraft:orange_concrete
setblock 504 139 416 minecraft:orange_concrete
fill 504 139 456 504 140 456 minecraft:magma_block
fill 505 139 454 507 140 454 minecraft:magma_block
fill 505 139 457 507 141 457 minecraft:magma_block
fill 505 139 458 505 143 458 minecraft:red_nether_bricks
fill 506 139 452 506 140 453 minecraft:magma_block
setblock 506 139 458 minecraft:orange_concrete
fill 507 139 458 507 142 458 minecraft:red_nether_bricks
fill 508 139 456 508 140 456 minecraft:magma_block
fill 511 139 416 511 142 416 minecraft:red_nether_bricks
setblock 512 139 416 minecraft:orange_concrete
setblock 512 139 419 minecraft:orange_concrete
fill 512 139 420 512 141 420 minecraft:red_nether_bricks
fill 512 139 435 512 142 436 minecraft:red_nether_bricks
setblock 512 139 440 minecraft:orange_concrete
setblock 512 139 451 minecraft:orange_concrete
fill 512 139 452 512 141 452 minecraft:red_nether_bricks
fill 512 139 456 512 142 457 minecraft:red_nether_bricks
fill 470 140 416 470 141 417 minecraft:orange_concrete
fill 470 140 418 470 145 419 minecraft:red_nether_bricks
fill 470 140 427 470 141 427 minecraft:red_nether_bricks
fill 470 140 428 470 140 429 minecraft:orange_concrete
fill 470 140 430 470 145 431 minecraft:red_nether_bricks
fill 470 140 436 470 141 437 minecraft:orange_concrete
fill 470 140 438 470 145 439 minecraft:red_nether_bricks
setblock 470 140 440 minecraft:orange_concrete
fill 470 140 441 470 142 442 minecraft:red_nether_bricks
fill 470 140 447 470 141 447 minecraft:red_nether_bricks
fill 470 140 448 470 141 449 minecraft:orange_concrete
fill 470 140 450 470 145 451 minecraft:red_nether_bricks
setblock 470 140 456 minecraft:red_nether_bricks
fill 470 140 457 470 141 457 minecraft:orange_concrete
fill 471 140 416 472 145 416 minecraft:red_nether_bricks
fill 471 140 458 471 145 458 minecraft:red_nether_bricks
fill 472 140 458 473 140 458 minecraft:orange_concrete
fill 473 140 416 474 141 416 minecraft:orange_concrete
fill 474 140 458 474 145 458 minecraft:red_nether_bricks
fill 480 140 416 480 145 416 minecraft:red_nether_bricks
fill 480 140 458 481 141 458 minecraft:orange_concrete
setblock 482 140 416 minecraft:orange_concrete
fill 482 140 458 483 145 458 minecraft:red_nether_bricks
fill 483 140 416 484 145 416 minecraft:red_nether_bricks
fill 483 140 452 485 141 452 minecraft:red_nether_bricks
fill 485 140 416 485 141 416 minecraft:orange_concrete
fill 485 140 453 485 143 453 minecraft:red_nether_bricks
setblock 486 140 416 minecraft:red_nether_bricks
fill 486 140 437 486 142 437 minecraft:red_nether_bricks
fill 486 140 443 486 142 443 minecraft:red_nether_bricks
fill 487 140 449 487 143 450 minecraft:red_nether_bricks
fill 487 140 452 487 146 452 minecraft:red_nether_bricks
fill 491 140 416 492 145 416 minecraft:red_nether_bricks
fill 492 140 458 493 140 458 minecraft:orange_concrete
fill 493 140 416 494 140 416 minecraft:orange_concrete
fill 494 140 437 494 142 437 minecraft:red_nether_bricks
setblock 494 140 438 minecraft:nether_bricks
setblock 494 140 442 minecraft:nether_bricks
fill 494 140 443 494 142 443 minecraft:red_nether_bricks
fill 494 140 458 495 145 458 minecraft:red_nether_bricks
fill 496 140 436 498 142 436 minecraft:red_nether_bricks
fill 496 140 444 498 142 444 minecraft:red_nether_bricks
setblock 500 140 458 minecraft:red_nether_bricks
fill 501 140 458 501 141 458 minecraft:orange_concrete
fill 502 140 458 503 145 458 minecraft:red_nether_bricks
fill 503 140 416 504 145 416 minecraft:red_nether_bricks
setblock 503 140 439 minecraft:nether_bricks
setblock 503 140 441 minecraft:nether_bricks
setblock 504 140 458 minecraft:orange_concrete
fill 505 140 416 506 141 416 minecraft:orange_concrete
setblock 505 140 453 minecraft:magma_block
fill 506 140 458 506 145 458 minecraft:red_nether_bricks
setblock 507 140 453 minecraft:magma_block
fill 512 140 416 512 145 416 minecraft:red_nether_bricks
fill 512 140 417 512 140 418 minecraft:orange_concrete
fill 512 140 419 512 145 419 minecraft:red_nether_bricks
fill 512 140 421 512 141 421 minecraft:orange_concrete
setblock 512 140 422 minecraft:red_nether_bricks
fill 512 140 427 512 145 428 minecraft:red_nether_bricks
fill 512 140 429 512 141 430 minecraft:orange_concrete
setblock 512 140 438 minecraft:orange_concrete
fill 512 140 439 512 145 440 minecraft:red_nether_bricks
fill 512 140 441 512 141 442 minecraft:orange_concrete
fill 512 140 447 512 145 448 minecraft:red_nether_bricks
fill 512 140 449 512 140 450 minecraft:orange_concrete
fill 512 140 451 512 145 451 minecraft:red_nether_bricks
fill 512 140 458 512 141 458 minecraft:orange_concrete
fill 470 141 420 470 141 423 minecraft:red_nether_bricks
fill 470 141 424 470 141 425 minecraft:orange_concrete
setblock 470 141 428 minecraft:orange_concrete
fill 470 141 429 470 144 429 minecraft:red_nether_bricks
fill 470 141 440 470 144 440 minecraft:red_nether_bricks
fill 470 141 443 470 142 444 minecraft:red_nether_bricks
setblock 470 141 445 minecraft:orange_concrete
setblock 470 141 456 minecraft:orange_concrete
fill 472 141 458 473 144 458 minecraft:red_nether_bricks
fill 482 141 416 482 144 416 minecraft:red_nether_bricks
fill 482 141 450 485 141 450 minecraft:red_nether_bricks
fill 483 141 449 485 141 449 minecraft:red_nether_bricks
fill 483 141 451 485 142 451 minecraft:red_nether_bricks
setblock 484 141 448 minecraft:red_nether_bricks
setblock 486 141 416 minecraft:orange_concrete
fill 486 141 453 487 145 453 minecraft:red_nether_bricks
fill 488 141 450 488 145 452 minecraft:red_nether_bricks
setblock 489 141 458 minecraft:orange_concrete
setblock 492 141 458 minecraft:orange_concrete
fill 493 141 416 493 144 416 minecraft:red_nether_bricks
fill 493 141 458 493 144 458 minecraft:red_nether_bricks
setblock 494 141 416 minecraft:orange_concrete
fill 495 141 437 496 144 437 minecraft:red_nether_bricks
setblock 495 141 438 minecraft:nether_bricks
setblock 495 141 442 minecraft:nether_bricks
fill 495 141 443 496 144 443 minecraft:red_nether_bricks
setblock 497 141 416 minecraft:orange_concrete
fill 497 141 437 499 141 437 minecraft:nether_bricks
fill 497 141 443 499 141 443 minecraft:nether_bricks
setblock 500 141 458 minecraft:orange_concrete
setblock 502 141 440 minecraft:nether_bricks
fill 504 141 458 504 144 458 minecraft:red_nether_bricks
setblock 506 141 454 minecraft:magma_block
fill 512 141 417 512 144 418 minecraft:red_nether_bricks
setblock 512 141 422 minecraft:orange_concrete
setblock 512 141 433 minecraft:orange_concrete
fill 512 141 438 512 144 438 minecraft:red_nether_bricks
fill 512 141 449 512 144 449 minecraft:red_nether_bricks
setblock 512 141 450 minecraft:orange_concrete
fill 512 141 453 512 141 454 minecraft:orange_concrete
fill 470 142 416 470 147 417 minecraft:red_nether_bricks
fill 470 142 420 470 142 422 minecraft:red_nether_bricks
fill 470 142 423 470 143 423 minecraft:orange_concrete
fill 470 142 424 470 143 425 minecraft:red_nether_bricks
fill 470 142 426 470 142 427 minecraft:orange_concrete
fill 470 142 428 470 147 428 minecraft:red_nether_bricks
fill 470 142 434 470 143 435 minecraft:orange_concrete
fill 470 142 436 470 147 437 minecraft:red_nether_bricks
fill 470 142 445 470 143 445 minecraft:red_nether_bricks
fill 470 142 446 470 142 447 minecraft:orange_concrete
fill 470 142 448 470 147 449 minecraft:red_nether_bricks
fill 470 142 452 470 143 453 minecraft:red_nether_bricks
fill 470 142 454 470 143 455 minecraft:orange_concrete
fill 470 142 456 470 147 457 minecraft:red_nether_bricks
setblock 470 142 458 minecraft:orange_concrete
fill 473 142 416 474 147 416 minecraft:red_nether_bricks
fill 475 142 416 476 142 416 minecraft:orange_concrete
fill 478 142 458 479 143 458 minecraft:orange_concrete
fill 480 142 458 481 147 458 minecraft:red_nether_bricks
fill 483 142 450 485 142 450 minecraft:red_nether_bricks
fill 484 142 449 485 142 449 minecraft:red_nether_bricks
fill 484 142 452 485 142 452 minecraft:red_nether_bricks
fill 485 142 416 486 147 416 minecraft:red_nether_bricks
fill 487 142 416 488 143 416 minecraft:orange_concrete
setblock 487 142 433 minecraft:red_nether_bricks
setblock 487 142 447 minecraft:red_nether_bricks
fill 487 142 458 487 143 458 minecraft:orange_concrete
setblock 488 142 433 minecraft:black_concrete
setblock 488 142 447 minecraft:black_concrete
fill 488 142 449 488 144 449 minecraft:red_nether_bricks
fill 488 142 453 489 147 453 minecraft:red_nether_bricks
fill 488 142 458 489 143 458 minecraft:red_nether_bricks
fill 489 142 433 493 142 433 minecraft:red_nether_bricks
fill 489 142 447 493 142 447 minecraft:red_nether_bricks
fill 489 142 450 489 147 452 minecraft:red_nether_bricks
fill 490 142 458 491 142 458 minecraft:orange_concrete
fill 492 142 458 492 147 458 minecraft:red_nether_bricks
fill 494 142 416 494 147 416 minecraft:red_nether_bricks
fill 495 142 416 496 142 416 minecraft:orange_concrete
fill 495 142 438 496 142 442 minecraft:red_nether_bricks
fill 497 142 416 498 143 416 minecraft:red_nether_bricks
fill 497 142 437 498 143 439 minecraft:red_nether_bricks
fill 497 142 440 499 142 440 minecraft:nether_bricks
fill 497 142 441 498 143 443 minecraft:red_nether_bricks
fill 498 142 458 499 143 458 minecraft:orange_concrete
fill 499 142 416 499 143 416 minecraft:orange_concrete
fill 499 142 438 499 142 439 minecraft:red_nether_bricks
fill 499 142 441 499 142 442 minecraft:red_nether_bricks
fill 500 142 458 501 147 458 minecraft:red_nether_bricks
fill 505 142 416 506 147 416 minecraft:red_nether_bricks
fill 507 142 416 508 143 416 minecraft:orange_concrete
fill 510 142 458 511 142 458 minecraft:orange_concrete
setblock 512 142 420 minecraft:orange_concrete
fill 512 142 421 512 147 422 minecraft:red_nether_bricks
fill 512 142 423 512 143 424 minecraft:orange_concrete
fill 512 142 429 512 147 430 minecraft:red_nether_bricks
fill 512 142 431 512 142 432 minecraft:orange_concrete
fill 512 142 433 512 147 433 minecraft:red_nether_bricks
fill 512 142 441 512 147 442 minecraft:red_nether_bricks
fill 512 142 443 512 143 444 minecraft:orange_concrete
fill 512 142 450 512 147 450 minecraft:red_nether_bricks
setblock 512 142 452 minecraft:orange_concrete
fill 512 142 453 512 147 454 minecraft:red_nether_bricks
fill 512 142 455 512 143 455 minecraft:orange_concrete
fill 512 142 458 512 147 458 minecraft:red_nether_bricks
fill 470 143 420 470 143 421 minecraft:red_nether_bricks
setblock 470 143 422 minecraft:orange_concrete
fill 470 143 426 470 145 427 minecraft:red_nether_bricks
setblock 470 143 441 minecraft:red_nether_bricks
fill 470 143 442 470 143 443 minecraft:orange_concrete
setblock 470 143 444 minecraft:red_nether_bricks
setblock 470 143 446 minecraft:orange_concrete
fill 470 143 447 470 146 447 minecraft:red_nether_bricks
fill 470 143 458 470 146 458 minecraft:red_nether_bricks
fill 475 143 416 475 146 416 minecraft:red_nether_bricks
setblock 475 143 458 minecraft:orange_concrete
setblock 476 143 416 minecraft:orange_concrete
setblock 479 143 416 minecraft:orange_concrete
fill 483 143 438 484 144 442 minecraft:red_nether_bricks
fill 484 143 450 485 143 451 minecraft:red_nether_bricks
fill 485 143 432 488 143 432 minecraft:black_concrete
fill 485 143 436 486 144 436 minecraft:red_nether_bricks
setblock 485 143 438 minecraft:red_nether_bricks
setblock 485 143 442 minecraft:red_nether_bricks
fill 485 143 444 486 144 444 minecraft:red_nether_bricks
fill 485 143 448 488 143 448 minecraft:black_concrete
setblock 485 143 449 minecraft:red_nether_bricks
fill 485 143 452 485 144 452 minecraft:red_nether_bricks
fill 486 143 435 488 143 435 minecraft:red_nether_bricks
fill 486 143 445 488 143 445 minecraft:red_nether_bricks
setblock 486 143 458 minecraft:orange_concrete
fill 488 143 454 488 145 454 minecraft:red_nether_bricks
fill 489 143 433 491 143 433 minecraft:red_nether_bricks
fill 489 143 447 491 143 447 minecraft:red_nether_bricks
fill 490 143 451 490 149 453 minecraft:red_nether_bricks
fill 490 143 458 491 146 458 minecraft:red_nether_bricks
fill 491 143 421 492 144 422 minecraft:magma_block
setblock 492 143 435 minecraft:red_nether_bricks
setblock 492 143 445 minecraft:red_nether_bricks
fill 493 143 435 493 144 435 minecraft:shroomlight
fill 493 143 445 493 144 445 minecraft:shroomlight
fill 494 143 435 494 143 436 minecraft:red_nether_bricks
fill 494 143 444 494 143 445 minecraft:red_nether_bricks
fill 495 143 416 496 146 416 minecraft:red_nether_bricks
fill 495 143 436 497 143 436 minecraft:red_nether_bricks
fill 495 143 438 496 143 438 minecraft:red_nether_bricks
fill 495 143 442 496 143 442 minecraft:red_nether_bricks
fill 495 143 444 497 143 444 minecraft:red_nether_bricks
fill 496 143 439 496 145 441 minecraft:red_nether_bricks
fill 497 143 440 498 144 440 minecraft:red_nether_bricks
setblock 500 143 416 minecraft:orange_concrete
setblock 507 143 458 minecraft:orange_concrete
setblock 510 143 458 minecraft:orange_concrete
setblock 511 143 416 minecraft:orange_concrete
fill 511 143 458 511 146 458 minecraft:red_nether_bricks
fill 512 143 420 512 146 420 minecraft:red_nether_bricks
fill 512 143 431 512 146 431 minecraft:red_nether_bricks
setblock 512 143 432 minecraft:orange_concrete
fill 512 143 435 512 143 436 minecraft:orange_concrete
fill 512 143 452 512 146 452 minecraft:red_nether_bricks
setblock 512 143 456 minecraft:orange_concrete
setblock 512 143 457 minecraft:red_nether_bricks
fill 470 144 420 470 145 421 minecraft:orange_concrete
fill 470 144 422 470 149 423 minecraft:red_nether_bricks
setblock 470 144 424 minecraft:orange_concrete
fill 470 144 425 471 144 425 minecraft:red_nether_bricks
fill 470 144 432 470 145 433 minecraft:orange_concrete
fill 470 144 434 470 149 435 minecraft:red_nether_bricks
fill 470 144 441 470 145 441 minecraft:orange_concrete
fill 470 144 442 470 145 443 minecraft:red_nether_bricks
fill 470 144 444 470 144 445 minecraft:orange_concrete
fill 470 144 446 470 149 446 minecraft:red_nether_bricks
fill 470 144 452 470 145 453 minecraft:orange_concrete
fill 470 144 454 470 149 455 minecraft:red_nether_bricks
fill 471 144 417 473 144 417 minecraft:red_nether_bricks
fill 471 144 419 471 144 421 minecraft:red_nether_bricks
fill 471 144 423 471 144 424 minecraft:red_nether_bricks
fill 471 144 427 471 144 429 minecraft:red_nether_bricks
fill 471 144 431 471 144 433 minecraft:red_nether_bricks
fill 471 144 435 471 144 437 minecraft:red_nether_bricks
fill 471 144 439 471 144 441 minecraft:red_nether_bricks
fill 471 144 443 471 144 445 minecraft:red_nether_bricks
fill 471 144 447 471 144 449 minecraft:red_nether_bricks
fill 471 144 451 471 144 453 minecraft:red_nether_bricks
fill 471 144 455 471 144 457 minecraft:red_nether_bricks
setblock 473 144 419 minecraft:light[level=14]
setblock 473 144 427 minecraft:light[level=14]
setblock 473 144 435 minecraft:light[level=14]
setblock 473 144 443 minecraft:light[level=14]
setblock 473 144 451 minecraft:light[level=14]
fill 473 144 457 475 144 457 minecraft:red_nether_bricks
fill 475 144 417 477 144 417 minecraft:red_nether_bricks
fill 475 144 458 475 149 458 minecraft:red_nether_bricks
fill 476 144 416 476 149 416 minecraft:red_nether_bricks
fill 476 144 458 477 144 458 minecraft:orange_concrete
fill 477 144 416 478 144 416 minecraft:orange_concrete
fill 477 144 457 479 144 457 minecraft:red_nether_bricks
fill 478 144 458 479 149 458 minecraft:red_nether_bricks
fill 479 144 416 479 144 417 minecraft:red_nether_bricks
fill 480 144 417 481 144 417 minecraft:red_nether_bricks
fill 481 144 416 481 145 416 minecraft:orange_concrete
setblock 481 144 419 minecraft:light[level=14]
setblock 481 144 427 minecraft:light[level=14]
setblock 481 144 435 minecraft:light[level=14]
setblock 481 144 443 minecraft:light[level=14]
setblock 481 144 451 minecraft:light[level=14]
fill 481 144 457 483 144 457 minecraft:red_nether_bricks
fill 482 144 430 484 144 430 minecraft:black_concrete
setblock 482 144 440 minecraft:red_nether_bricks
fill 482 144 450 484 144 450 minecraft:black_concrete
fill 483 144 417 485 144 417 minecraft:red_nether_bricks
fill 483 144 431 487 144 431 minecraft:black_concrete
fill 483 144 449 487 144 449 minecraft:black_concrete
fill 484 144 458 485 145 458 minecraft:orange_concrete
fill 485 144 450 485 144 451 minecraft:red_nether_bricks
fill 485 144 457 487 144 457 minecraft:red_nether_bricks
fill 486 144 435 487 144 435 minecraft:red_nether_bricks
fill 486 144 445 487 144 445 minecraft:red_nether_bricks
fill 486 144 458 487 149 458 minecraft:red_nether_bricks
fill 487 144 416 488 144 417 minecraft:red_nether_bricks
setblock 487 144 450 minecraft:red_nether_bricks
setblock 487 144 454 minecraft:red_nether_bricks
setblock 488 144 432 minecraft:black_concrete
setblock 488 144 434 minecraft:red_nether_bricks
setblock 488 144 446 minecraft:red_nether_bricks
setblock 488 144 448 minecraft:black_concrete
setblock 488 144 458 minecraft:orange_concrete
fill 489 144 416 490 145 416 minecraft:orange_concrete
setblock 489 144 417 minecraft:red_nether_bricks
setblock 489 144 419 minecraft:light[level=14]
setblock 489 144 427 minecraft:light[level=14]
fill 489 144 454 489 147 454 minecraft:red_nether_bricks
fill 489 144 457 489 144 458 minecraft:red_nether_bricks
fill 490 144 450 490 149 450 minecraft:red_nether_bricks
fill 490 144 457 491 144 457 minecraft:red_nether_bricks
fill 491 144 417 493 144 417 minecraft:red_nether_bricks
fill 491 144 451 491 150 453 minecraft:red_nether_bricks
setblock 492 144 434 minecraft:red_nether_bricks
setblock 492 144 446 minecraft:red_nether_bricks
fill 493 144 457 495 144 457 minecraft:red_nether_bricks
fill 494 144 435 494 144 436 minecraft:shroomlight
fill 494 144 444 494 144 445 minecraft:shroomlight
fill 495 144 417 497 144 417 minecraft:red_nether_bricks
fill 495 144 436 496 144 436 minecraft:red_nether_bricks
fill 495 144 444 496 144 444 minecraft:red_nether_bricks
fill 496 144 438 497 144 438 minecraft:red_nether_bricks
fill 496 144 442 497 144 442 minecraft:red_nether_bricks
fill 496 144 458 497 145 458 minecraft:orange_concrete
fill 497 144 416 497 147 416 minecraft:red_nether_bricks
setblock 497 144 419 minecraft:light[level=14]
setblock 497 144 427 minecraft:light[level=14]
setblock 497 144 435 minecraft:light[level=14]
setblock 497 144 437 minecraft:red_nether_bricks
setblock 497 144 439 minecraft:red_nether_bricks
setblock 497 144 441 minecraft:red_nether_bricks
setblock 497 144 443 minecraft:red_nether_bricks
setblock 497 144 451 minecraft:light[level=14]
fill 497 144 457 499 144 457 minecraft:red_nether_bricks
setblock 498 144 416 minecraft:orange_concrete
fill 498 144 458 499 149 458 minecraft:red_nether_bricks
fill 499 144 416 500 144 417 minecraft:red_nether_bricks
fill 501 144 416 502 145 416 minecraft:orange_concrete
setblock 501 144 417 minecraft:red_nether_bricks
fill 501 144 457 503 144 457 minecraft:red_nether_bricks
fill 503 144 417 505 144 417 minecraft:red_nether_bricks
setblock 505 144 419 minecraft:light[level=14]
setblock 505 144 427 minecraft:light[level=14]
setblock 505 144 435 minecraft:light[level=14]
setblock 505 144 443 minecraft:light[level=14]
setblock 505 144 451 minecraft:light[level=14]
fill 505 144 457 507 144 457 minecraft:red_nether_bricks
fill 505 144 458 505 145 458 minecraft:orange_concrete
fill 507 144 416 508 144 417 minecraft:red_nether_bricks
fill 507 144 458 507 149 458 minecraft:red_nether_bricks
fill 508 144 458 509 144 458 minecraft:orange_concrete
fill 509 144 416 510 144 416 minecraft:orange_concrete
setblock 509 144 417 minecraft:red_nether_bricks
fill 509 144 457 511 144 457 minecraft:red_nether_bricks
fill 510 144 458 510 149 458 minecraft:red_nether_bricks
fill 511 144 416 511 144 419 minecraft:red_nether_bricks
fill 511 144 421 511 144 423 minecraft:red_nether_bricks
fill 511 144 425 511 144 427 minecraft:red_nether_bricks
fill 511 144 429 511 144 431 minecraft:red_nether_bricks
fill 511 144 433 511 144 435 minecraft:red_nether_bricks
fill 511 144 437 511 144 439 minecraft:red_nether_bricks
fill 511 144 441 511 144 443 minecraft:red_nether_bricks
fill 511 144 445 511 144 447 minecraft:red_nether_bricks
fill 511 144 449 511 144 451 minecraft:red_nether_bricks
fill 511 144 453 511 144 455 minecraft:red_nether_bricks
fill 512 144 423 512 149 424 minecraft:red_nether_bricks
fill 512 144 425 512 145 426 minecraft:orange_concrete
fill 512 144 432 512 149 432 minecraft:red_nether_bricks
setblock 512 144 434 minecraft:orange_concrete
fill 512 144 435 512 149 436 minecraft:red_nether_bricks
fill 512 144 437 512 145 437 minecraft:orange_concrete
fill 512 144 443 512 149 444 minecraft:red_nether_bricks
fill 512 144 445 512 144 446 minecraft:orange_concrete
fill 512 144 455 512 149 456 minecraft:red_nether_bricks
fill 512 144 457 512 145 457 minecraft:orange_concrete
fill 470 145 424 470 147 425 minecraft:red_nether_bricks
setblock 470 145 429 minecraft:orange_concrete
setblock 470 145 440 minecraft:orange_concrete
fill 470 145 444 470 147 445 minecraft:red_nether_bricks
fill 472 145 458 473 145 458 minecraft:orange_concrete
setblock 476 145 458 minecraft:orange_concrete
fill 477 145 416 479 148 416 minecraft:red_nether_bricks
fill 477 145 458 477 148 458 minecraft:red_nether_bricks
setblock 480 145 429 minecraft:black_concrete
setblock 480 145 451 minecraft:black_concrete
setblock 482 145 416 minecraft:orange_concrete
setblock 483 145 429 minecraft:black_concrete
setblock 483 145 451 minecraft:black_concrete
fill 484 145 430 485 145 430 minecraft:black_concrete
fill 484 145 438 484 145 442 minecraft:red_nether_bricks
fill 484 145 450 485 145 450 minecraft:black_concrete
fill 487 145 416 488 149 416 minecraft:red_nether_bricks
setblock 487 145 430 minecraft:black_concrete
setblock 487 145 450 minecraft:black_concrete
setblock 488 145 431 minecraft:black_concrete
setblock 488 145 449 minecraft:black_concrete
fill 488 145 458 489 147 458 minecraft:red_nether_bricks
fill 490 145 454 490 148 454 minecraft:red_nether_bricks
fill 491 145 450 491 150 450 minecraft:red_nether_bricks
fill 492 145 451 492 152 452 minecraft:red_nether_bricks
setblock 493 145 416 minecraft:orange_concrete
setblock 493 145 458 minecraft:orange_concrete
setblock 496 145 438 minecraft:red_nether_bricks
setblock 496 145 442 minecraft:red_nether_bricks
fill 498 145 416 500 148 416 minecraft:red_nether_bricks
setblock 504 145 458 minecraft:orange_concrete
fill 507 145 416 509 148 416 minecraft:red_nether_bricks
fill 508 145 458 509 148 458 minecraft:red_nether_bricks
setblock 510 145 416 minecraft:orange_concrete
fill 511 145 416 511 149 416 minecraft:red_nether_bricks
fill 512 145 417 512 145 418 minecraft:orange_concrete
fill 512 145 434 512 148 434 minecraft:red_nether_bricks
setblock 512 145 438 minecraft:orange_concrete
fill 512 145 445 512 148 445 minecraft:red_nether_bricks
setblock 512 145 446 minecraft:orange_concrete
setblock 512 145 449 minecraft:orange_concrete
fill 470 146 418 470 147 419 minecraft:orange_concrete
fill 470 146 420 470 151 421 minecraft:red_nether_bricks
setblock 470 146 426 minecraft:red_nether_bricks
fill 470 146 427 470 147 427 minecraft:orange_concrete
fill 470 146 429 470 151 429 minecraft:red_nether_bricks
fill 470 146 430 470 146 431 minecraft:orange_concrete
fill 470 146 432 470 148 433 minecraft:red_nether_bricks
fill 470 146 438 470 147 439 minecraft:orange_concrete
fill 470 146 440 470 151 441 minecraft:red_nether_bricks
setblock 470 146 442 minecraft:orange_concrete
fill 470 146 443 470 149 443 minecraft:red_nether_bricks
fill 470 146 450 470 146 451 minecraft:orange_concrete
fill 470 146 452 470 151 453 minecraft:red_nether_bricks
fill 471 146 416 472 147 416 minecraft:orange_concrete
fill 471 146 458 471 147 458 minecraft:orange_concrete
fill 472 146 458 473 151 458 minecraft:red_nether_bricks
setblock 474 146 458 minecraft:orange_concrete
fill 476 146 427 477 146 427 minecraft:black_concrete
fill 476 146 453 477 146 453 minecraft:black_concrete
fill 476 146 458 476 151 458 minecraft:red_nether_bricks
fill 477 146 428 478 146 428 minecraft:black_concrete
fill 477 146 452 478 146 452 minecraft:black_concrete
setblock 480 146 416 minecraft:orange_concrete
fill 481 146 416 482 151 416 minecraft:red_nether_bricks
fill 481 146 428 482 146 428 minecraft:black_concrete
fill 481 146 452 482 146 452 minecraft:black_concrete
fill 482 146 458 483 147 458 minecraft:orange_concrete
fill 483 146 416 484 147 416 minecraft:orange_concrete
setblock 484 146 429 minecraft:black_concrete
setblock 484 146 451 minecraft:black_concrete
fill 484 146 458 485 151 458 minecraft:red_nether_bricks
fill 486 146 429 486 147 429 minecraft:black_concrete
setblock 486 146 435 minecraft:blackstone
setblock 486 146 445 minecraft:blackstone
fill 486 146 451 486 147 451 minecraft:black_concrete
setblock 487 146 453 minecraft:red_nether_bricks
fill 488 146 430 488 147 430 minecraft:black_concrete
fill 488 146 450 488 147 450 minecraft:black_concrete
fill 488 146 451 488 146 452 minecraft:red_nether_bricks
fill 489 146 416 490 151 416 minecraft:red_nether_bricks
fill 491 146 416 492 146 416 minecraft:orange_concrete
fill 491 146 454 491 149 454 minecraft:red_nether_bricks
fill 492 146 450 492 151 450 minecraft:red_nether_bricks
fill 492 146 453 492 151 453 minecraft:red_nether_bricks
fill 493 146 416 493 151 416 minecraft:red_nether_bricks
fill 493 146 451 493 153 452 minecraft:red_nether_bricks
fill 493 146 458 493 151 458 minecraft:red_nether_bricks
fill 494 146 458 495 146 458 minecraft:orange_concrete
fill 496 146 458 497 151 458 minecraft:red_nether_bricks
fill 500 146 430 501 147 432 minecraft:magma_block
fill 501 146 416 502 151 416 minecraft:red_nether_bricks
fill 502 146 458 503 147 458 minecraft:orange_concrete
fill 503 146 416 504 147 416 minecraft:orange_concrete
fill 504 146 458 505 151 458 minecraft:red_nether_bricks
setblock 506 146 458 minecraft:orange_concrete
fill 510 146 416 510 151 416 minecraft:red_nether_bricks
setblock 512 146 416 minecraft:orange_concrete
fill 512 146 417 512 151 418 minecraft:red_nether_bricks
fill 512 146 419 512 147 419 minecraft:orange_concrete
fill 512 146 425 512 151 426 minecraft:red_nether_bricks
fill 512 146 427 512 146 428 minecraft:orange_concrete
fill 512 146 437 512 151 438 minecraft:red_nether_bricks
fill 512 146 439 512 147 440 minecraft:orange_concrete
fill 512 146 446 512 151 446 minecraft:red_nether_bricks
fill 512 146 447 512 146 448 minecraft:orange_concrete
fill 512 146 449 512 151 449 minecraft:red_nether_bricks
fill 512 146 451 512 147 451 minecraft:orange_concrete
fill 512 146 457 512 151 457 minecraft:red_nether_bricks
setblock 470 147 426 minecraft:orange_concrete
setblock 470 147 430 minecraft:orange_concrete
fill 470 147 431 470 150 431 minecraft:red_nether_bricks
fill 470 147 442 470 149 442 minecraft:red_nether_bricks
setblock 470 147 447 minecraft:orange_concrete
setblock 470 147 450 minecraft:orange_concrete
fill 470 147 451 470 150 451 minecraft:red_nether_bricks
setblock 470 147 458 minecraft:orange_concrete
fill 474 147 458 474 150 458 minecraft:red_nether_bricks
setblock 475 147 416 minecraft:orange_concrete
setblock 476 147 427 minecraft:black_concrete
setblock 476 147 453 minecraft:black_concrete
fill 479 147 426 479 148 426 minecraft:black_concrete
fill 479 147 454 479 148 454 minecraft:black_concrete
fill 480 147 416 480 150 416 minecraft:red_nether_bricks
setblock 480 147 427 minecraft:black_concrete
setblock 480 147 453 minecraft:black_concrete
fill 483 147 428 483 148 428 minecraft:black_concrete
fill 483 147 452 483 148 452 minecraft:black_concrete
fill 485 147 434 485 149 435 minecraft:blackstone
fill 485 147 445 485 149 446 minecraft:blackstone
fill 486 147 428 486 148 428 minecraft:black_concrete
fill 486 147 434 486 148 434 minecraft:blackstone
fill 486 147 446 486 148 446 minecraft:blackstone
fill 486 147 452 486 148 452 minecraft:black_concrete
fill 488 147 429 488 148 429 minecraft:black_concrete
fill 488 147 451 488 148 451 minecraft:black_concrete
setblock 488 147 452 minecraft:red_nether_bricks
fill 490 147 458 491 147 458 minecraft:orange_concrete
fill 491 147 416 491 150 416 minecraft:red_nether_bricks
setblock 492 147 416 minecraft:orange_concrete
fill 492 147 454 492 150 454 minecraft:red_nether_bricks
fill 493 147 450 493 152 450 minecraft:red_nether_bricks
fill 493 147 453 493 152 453 minecraft:red_nether_bricks
fill 494 147 451 494 154 452 minecraft:red_nether_bricks
setblock 494 147 458 minecraft:orange_concrete
fill 495 147 416 496 147 416 minecraft:orange_concrete
fill 495 147 458 495 150 458 minecraft:red_nether_bricks
fill 506 147 458 506 150 458 minecraft:red_nether_bricks
setblock 511 147 458 minecraft:orange_concrete
fill 512 147 416 512 150 416 minecraft:red_nether_bricks
setblock 512 147 420 minecraft:orange_concrete
fill 512 147 427 512 150 427 minecraft:red_nether_bricks
setblock 512 147 428 minecraft:orange_concrete
setblock 512 147 431 minecraft:orange_concrete
fill 512 147 447 512 150 448 minecraft:red_nether_bricks
setblock 512 147 452 minecraft:orange_concrete
fill 470 148 416 470 148 417 minecraft:orange_concrete
fill 470 148 418 470 153 419 minecraft:red_nether_bricks
fill 470 148 424 470 149 425 minecraft:orange_concrete
fill 470 148 426 470 153 427 minecraft:red_nether_bricks
setblock 470 148 428 minecraft:orange_concrete
fill 470 148 430 470 150 430 minecraft:red_nether_bricks
fill 470 148 436 470 149 437 minecraft:orange_concrete
fill 470 148 438 470 153 439 minecraft:red_nether_bricks
setblock 470 148 444 minecraft:red_nether_bricks
fill 470 148 445 470 149 445 minecraft:orange_concrete
fill 470 148 447 470 153 447 minecraft:red_nether_bricks
fill 470 148 448 470 148 449 minecraft:orange_concrete
fill 470 148 450 470 153 450 minecraft:red_nether_bricks
fill 470 148 456 470 149 457 minecraft:orange_concrete
fill 470 148 458 471 153 458 minecraft:red_nether_bricks
fill 471 148 416 472 153 416 minecraft:red_nether_bricks
fill 473 148 416 474 148 416 minecraft:orange_concrete
fill 475 148 416 475 153 416 minecraft:red_nether_bricks
fill 480 148 458 481 148 458 minecraft:orange_concrete
fill 482 148 427 482 149 427 minecraft:black_concrete
fill 482 148 453 482 149 453 minecraft:black_concrete
fill 482 148 458 483 153 458 minecraft:red_nether_bricks
fill 483 148 416 484 153 416 minecraft:red_nether_bricks
fill 484 148 434 484 150 434 minecraft:blackstone
fill 484 148 446 484 150 446 minecraft:blackstone
fill 485 148 416 486 149 416 minecraft:orange_concrete
setblock 488 148 458 minecraft:red_nether_bricks
fill 489 148 451 489 148 453 minecraft:red_nether_bricks
fill 489 148 458 489 149 458 minecraft:orange_concrete
fill 490 148 458 491 153 458 minecraft:red_nether_bricks
fill 492 148 416 492 153 416 minecraft:red_nether_bricks
setblock 492 148 458 minecraft:orange_concrete
fill 493 148 454 493 151 454 minecraft:red_nether_bricks
setblock 494 148 416 minecraft:orange_concrete
fill 494 148 450 494 154 450 minecraft:red_nether_bricks
fill 494 148 453 494 153 453 minecraft:red_nether_bricks
fill 494 148 458 494 153 458 minecraft:red_nether_bricks
fill 495 148 416 496 153 416 minecraft:red_nether_bricks
fill 495 148 452 495 155 452 minecraft:red_nether_bricks
fill 497 148 416 497 149 416 minecraft:orange_concrete
fill 500 148 458 501 149 458 minecraft:orange_concrete
fill 502 148 458 503 153 458 minecraft:red_nether_bricks
fill 503 148 416 504 153 416 minecraft:red_nether_bricks
fill 505 148 416 506 148 416 minecraft:orange_concrete
fill 511 148 458 511 153 458 minecraft:red_nether_bricks
fill 512 148 419 512 153 420 minecraft:red_nether_bricks
fill 512 148 421 512 149 422 minecraft:orange_concrete
fill 512 148 428 512 153 428 minecraft:red_nether_bricks
fill 512 148 429 512 148 430 minecraft:orange_concrete
fill 512 148 431 512 153 431 minecraft:red_nether_bricks
fill 512 148 433 512 149 433 minecraft:orange_concrete
fill 512 148 439 512 153 440 minecraft:red_nether_bricks
fill 512 148 441 512 149 442 minecraft:orange_concrete
setblock 512 148 450 minecraft:orange_concrete
fill 512 148 451 512 153 452 minecraft:red_nether_bricks
fill 512 148 453 512 149 454 minecraft:orange_concrete
fill 512 148 458 512 149 458 minecraft:orange_concrete
setblock 470 149 416 minecraft:orange_concrete
fill 470 149 417 470 152 417 minecraft:red_nether_bricks
fill 470 149 428 470 152 428 minecraft:red_nether_bricks
fill 470 149 432 470 151 432 minecraft:red_nether_bricks
setblock 470 149 433 minecraft:orange_concrete
setblock 470 149 444 minecraft:orange_concrete
fill 470 149 448 470 152 449 minecraft:red_nether_bricks
fill 473 149 416 473 152 416 minecraft:red_nether_bricks
setblock 474 149 416 minecraft:orange_concrete
fill 477 149 416 478 149 416 minecraft:orange_concrete
setblock 477 149 458 minecraft:orange_concrete
setblock 479 149 416 minecraft:red_nether_bricks
setblock 480 149 458 minecraft:orange_concrete
fill 481 149 458 481 152 458 minecraft:red_nether_bricks
fill 484 149 433 485 149 433 minecraft:blackstone
fill 484 149 447 485 149 447 minecraft:blackstone
fill 485 149 426 485 149 427 minecraft:black_concrete
fill 485 149 453 485 149 454 minecraft:black_concrete
setblock 488 149 428 minecraft:black_concrete
setblock 488 149 452 minecraft:black_concrete
setblock 488 149 458 minecraft:orange_concrete
fill 492 149 458 492 152 458 minecraft:red_nether_bricks
fill 494 149 416 494 152 416 minecraft:red_nether_bricks
fill 494 149 454 494 151 454 minecraft:red_nether_bricks
fill 495 149 450 495 155 451 minecraft:red_nether_bricks
fill 495 149 453 495 154 453 minecraft:red_nether_bricks
setblock 498 149 416 minecraft:orange_concrete
fill 499 149 416 500 149 416 minecraft:red_nether_bricks
fill 505 149 416 505 152 416 minecraft:red_nether_bricks
setblock 506 149 416 minecraft:orange_concrete
fill 507 149 416 508 149 416 minecraft:red_nether_bricks
fill 508 149 458 509 149 458 minecraft:orange_concrete
setblock 509 149 416 minecraft:orange_concrete
fill 512 149 429 512 152 430 minecraft:red_nether_bricks
setblock 512 149 434 minecraft:orange_concrete
setblock 512 149 445 minecraft:orange_concrete
fill 512 149 450 512 152 450 minecraft:red_nether_bricks
fill 470 150 416 470 155 416 minecraft:red_nether_bricks
fill 470 150 422 470 151 423 minecraft:orange_concrete
fill 470 150 424 471 150 425 minecraft:red_nether_bricks
fill 470 150 433 471 150 433 minecraft:red_nether_bricks
fill 470 150 434 470 150 435 minecraft:orange_concrete
fill 470 150 436 471 150 437 minecraft:red_nether_bricks
fill 470 150 442 470 151 443 minecraft:orange_concrete
fill 470 150 444 471 150 445 minecraft:red_nether_bricks
setblock 470 150 446 minecraft:orange_concrete
fill 470 150 454 470 151 455 minecraft:orange_concrete
fill 470 150 456 471 150 457 minecraft:red_nether_bricks
fill 471 150 417 473 150 417 minecraft:red_nether_bricks
fill 471 150 419 471 150 421 minecraft:red_nether_bricks
setblock 471 150 423 minecraft:red_nether_bricks
fill 471 150 427 471 150 429 minecraft:red_nether_bricks
fill 471 150 431 471 150 432 minecraft:red_nether_bricks
setblock 471 150 435 minecraft:red_nether_bricks
fill 471 150 439 471 150 441 minecraft:red_nether_bricks
setblock 471 150 443 minecraft:red_nether_bricks
fill 471 150 447 471 150 449 minecraft:red_nether_bricks
fill 471 150 451 471 150 453 minecraft:red_nether_bricks
setblock 471 150 455 minecraft:red_nether_bricks
fill 473 150 457 475 150 457 minecraft:red_nether_bricks
fill 474 150 416 474 155 416 minecraft:red_nether_bricks
fill 475 150 417 477 150 417 minecraft:red_nether_bricks
fill 475 150 458 475 151 458 minecraft:orange_concrete
setblock 476 150 416 minecraft:orange_concrete
fill 477 150 416 478 155 416 minecraft:red_nether_bricks
fill 477 150 457 477 150 458 minecraft:red_nether_bricks
fill 478 150 457 479 150 457 minecraft:red_nether_bricks
fill 478 150 458 479 150 458 minecraft:orange_concrete
fill 479 150 416 479 151 416 minecraft:orange_concrete
fill 479 150 417 481 150 417 minecraft:red_nether_bricks
fill 480 150 458 480 155 458 minecraft:red_nether_bricks
fill 481 150 457 483 150 457 minecraft:red_nether_bricks
fill 483 150 417 485 150 417 minecraft:red_nether_bricks
fill 483 150 433 483 151 434 minecraft:blackstone
fill 483 150 446 483 151 447 minecraft:blackstone
fill 484 150 433 484 151 433 minecraft:blackstone
fill 484 150 447 484 151 447 minecraft:blackstone
fill 485 150 416 486 155 416 minecraft:red_nether_bricks
setblock 485 150 426 minecraft:black_concrete
setblock 485 150 434 minecraft:blackstone
setblock 485 150 446 minecraft:blackstone
setblock 485 150 454 minecraft:black_concrete
fill 485 150 457 487 150 457 minecraft:red_nether_bricks
fill 486 150 458 487 151 458 minecraft:orange_concrete
fill 487 150 416 488 150 416 minecraft:orange_concrete
fill 487 150 417 489 150 417 minecraft:red_nether_bricks
fill 488 150 427 488 151 427 minecraft:black_concrete
fill 488 150 453 488 151 453 minecraft:black_concrete
fill 488 150 458 489 155 458 minecraft:red_nether_bricks
fill 489 150 457 491 150 457 minecraft:red_nether_bricks
setblock 490 150 452 minecraft:red_nether_bricks
fill 491 150 417 493 150 417 minecraft:red_nether_bricks
fill 493 150 457 495 150 457 minecraft:red_nether_bricks
fill 495 150 417 497 150 417 minecraft:red_nether_bricks
fill 496 150 450 496 154 453 minecraft:red_nether_bricks
fill 497 150 416 498 155 416 minecraft:red_nether_bricks
fill 497 150 457 499 150 457 minecraft:red_nether_bricks
fill 498 150 458 499 150 458 minecraft:orange_concrete
fill 499 150 416 500 151 416 minecraft:orange_concrete
fill 499 150 417 501 150 417 minecraft:red_nether_bricks
fill 500 150 458 501 155 458 minecraft:red_nether_bricks
fill 501 150 457 503 150 457 minecraft:red_nether_bricks
fill 503 150 417 505 150 417 minecraft:red_nether_bricks
fill 505 150 457 507 150 457 minecraft:red_nether_bricks
fill 506 150 416 506 155 416 minecraft:red_nether_bricks
fill 507 150 416 508 150 416 minecraft:orange_concrete
fill 507 150 417 509 150 417 minecraft:red_nether_bricks
fill 507 150 458 507 151 458 minecraft:orange_concrete
fill 508 150 458 509 155 458 minecraft:red_nether_bricks
fill 509 150 416 509 155 416 minecraft:red_nether_bricks
fill 509 150 457 511 150 457 minecraft:red_nether_bricks
setblock 510 150 458 minecraft:orange_concrete
fill 511 150 416 511 151 416 minecraft:orange_concrete
fill 511 150 417 511 150 419 minecraft:red_nether_bricks
fill 511 150 421 511 150 423 minecraft:red_nether_bricks
fill 511 150 425 511 150 427 minecraft:red_nether_bricks
fill 511 150 429 511 150 431 minecraft:red_nether_bricks
fill 511 150 433 511 150 435 minecraft:red_nether_bricks
fill 511 150 437 511 150 439 minecraft:red_nether_bricks
fill 511 150 441 511 150 443 minecraft:red_nether_bricks
fill 511 150 445 511 150 447 minecraft:red_nether_bricks
fill 511 150 449 511 150 451 minecraft:red_nether_bricks
fill 511 150 453 511 150 455 minecraft:red_nether_bricks
fill 512 150 421 512 155 422 minecraft:red_nether_bricks
fill 512 150 423 512 151 424 minecraft:orange_concrete
setblock 512 150 432 minecraft:orange_concrete
fill 512 150 433 512 155 434 minecraft:red_nether_bricks
fill 512 150 435 512 151 436 minecraft:orange_concrete
fill 512 150 441 512 155 442 minecraft:red_nether_bricks
fill 512 150 443 512 150 444 minecraft:orange_concrete
fill 512 150 445 512 155 445 minecraft:red_nether_bricks
fill 512 150 453 512 155 454 minecraft:red_nether_bricks
fill 512 150 455 512 151 456 minecraft:orange_concrete
fill 512 150 458 512 155 458 minecraft:red_nether_bricks
fill 470 151 424 470 155 425 minecraft:red_nether_bricks
fill 470 151 430 470 151 431 minecraft:orange_concrete
setblock 470 151 433 minecraft:red_nether_bricks
setblock 470 151 434 minecraft:orange_concrete
fill 470 151 435 470 154 437 minecraft:red_nether_bricks
fill 470 151 444 470 154 446 minecraft:red_nether_bricks
setblock 470 151 451 minecraft:orange_concrete
fill 470 151 456 470 155 457 minecraft:red_nether_bricks
setblock 474 151 458 minecraft:orange_concrete
fill 476 151 416 476 154 416 minecraft:red_nether_bricks
fill 477 151 458 479 154 458 minecraft:red_nether_bricks
setblock 480 151 416 minecraft:orange_concrete
fill 482 151 432 482 152 433 minecraft:blackstone
fill 482 151 447 482 152 448 minecraft:blackstone
fill 483 151 432 483 152 432 minecraft:blackstone
fill 483 151 448 483 152 448 minecraft:blackstone
fill 487 151 416 487 154 416 minecraft:red_nether_bricks
setblock 488 151 416 minecraft:orange_concrete
setblock 491 151 416 minecraft:orange_concrete
setblock 491 151 452 minecraft:red_nether_bricks
fill 494 151 449 496 152 449 minecraft:red_nether_bricks
setblock 495 151 458 minecraft:orange_concrete
fill 497 151 450 497 156 452 minecraft:red_nether_bricks
setblock 498 151 458 minecraft:orange_concrete
fill 499 151 458 499 154 458 minecraft:red_nether_bricks
fill 503 151 423 506 215 426 minecraft:red_nether_bricks
fill 504 151 427 505 215 427 minecraft:red_nether_bricks
setblock 506 151 458 minecraft:orange_concrete
fill 507 151 416 508 154 416 minecraft:red_nether_bricks
fill 507 151 424 507 215 425 minecraft:red_nether_bricks
fill 510 151 458 510 154 458 minecraft:red_nether_bricks
setblock 512 151 416 minecraft:orange_concrete
setblock 512 151 427 minecraft:orange_concrete
fill 512 151 432 512 154 432 minecraft:red_nether_bricks
fill 512 151 443 512 154 443 minecraft:red_nether_bricks
setblock 512 151 444 minecraft:orange_concrete
fill 512 151 447 512 151 448 minecraft:orange_concrete
fill 470 152 420 470 153 421 minecraft:orange_concrete
fill 470 152 422 470 157 423 minecraft:red_nether_bricks
fill 470 152 429 470 153 429 minecraft:orange_concrete
fill 470 152 430 470 153 431 minecraft:red_nether_bricks
fill 470 152 432 470 152 433 minecraft:orange_concrete
fill 470 152 434 470 157 434 minecraft:red_nether_bricks
fill 470 152 440 470 153 441 minecraft:orange_concrete
fill 470 152 442 470 157 443 minecraft:red_nether_bricks
fill 470 152 451 470 157 451 minecraft:red_nether_bricks
fill 470 152 452 470 152 453 minecraft:orange_concrete
fill 470 152 454 470 157 455 minecraft:red_nether_bricks
fill 472 152 458 473 153 458 minecraft:orange_concrete
setblock 473 152 419 minecraft:light[level=14]
setblock 473 152 427 minecraft:light[level=14]
setblock 473 152 435 minecraft:light[level=14]
setblock 473 152 443 minecraft:light[level=14]
setblock 473 152 451 minecraft:light[level=14]
fill 474 152 458 475 157 458 minecraft:red_nether_bricks
setblock 476 152 458 minecraft:orange_concrete
fill 479 152 416 480 157 416 minecraft:red_nether_bricks
fill 481 152 416 482 153 416 minecraft:orange_concrete
setblock 481 152 419 minecraft:light[level=14]
setblock 481 152 427 minecraft:light[level=14]
setblock 481 152 435 minecraft:light[level=14]
setblock 481 152 443 minecraft:light[level=14]
setblock 481 152 451 minecraft:light[level=14]
setblock 483 152 433 minecraft:blackstone
setblock 483 152 447 minecraft:blackstone
fill 484 152 458 485 153 458 minecraft:orange_concrete
fill 486 152 458 487 157 458 minecraft:red_nether_bricks
fill 488 152 416 488 157 416 minecraft:red_nether_bricks
fill 489 152 416 490 152 416 minecraft:orange_concrete
setblock 489 152 419 minecraft:light[level=14]
setblock 489 152 427 minecraft:light[level=14]
setblock 489 152 435 minecraft:light[level=14]
setblock 489 152 443 minecraft:light[level=14]
setblock 489 152 451 minecraft:light[level=14]
fill 491 152 416 491 157 416 minecraft:red_nether_bricks
fill 493 152 416 493 153 416 minecraft:orange_concrete
fill 493 152 458 493 153 458 minecraft:orange_concrete
fill 495 152 458 495 157 458 minecraft:red_nether_bricks
fill 496 152 458 497 152 458 minecraft:orange_concrete
setblock 497 152 419 minecraft:light[level=14]
setblock 497 152 427 minecraft:light[level=14]
setblock 497 152 435 minecraft:light[level=14]
setblock 497 152 443 minecraft:light[level=14]
fill 497 152 449 497 158 449 minecraft:red_nether_bricks
fill 497 152 453 497 154 453 minecraft:red_nether_bricks
fill 498 152 450 498 157 452 minecraft:red_nether_bricks
fill 498 152 458 498 157 458 minecraft:red_nether_bricks
fill 499 152 416 500 157 416 minecraft:red_nether_bricks
fill 501 152 416 502 153 416 minecraft:orange_concrete
fill 502 152 423 502 153 427 minecraft:blackstone
fill 503 152 422 507 153 422 minecraft:blackstone
fill 503 152 427 503 153 427 minecraft:blackstone
fill 504 152 428 506 153 428 minecraft:blackstone
fill 504 152 458 505 153 458 minecraft:orange_concrete
setblock 505 152 419 minecraft:light[level=14]
setblock 505 152 435 minecraft:light[level=14]
setblock 505 152 443 minecraft:light[level=14]
setblock 505 152 451 minecraft:light[level=14]
fill 506 152 427 507 153 427 minecraft:blackstone
fill 506 152 458 507 157 458 minecraft:red_nether_bricks
fill 507 152 423 507 153 423 minecraft:blackstone
fill 507 152 426 508 153 426 minecraft:blackstone
fill 508 152 424 508 153 425 minecraft:blackstone
setblock 510 152 416 minecraft:orange_concrete
fill 511 152 416 512 157 416 minecraft:red_nether_bricks
fill 512 152 417 512 153 418 minecraft:orange_concrete
fill 512 152 423 512 157 424 minecraft:red_nether_bricks
fill 512 152 425 512 152 426 minecraft:orange_concrete
fill 512 152 427 512 157 427 minecraft:red_nether_bricks
fill 512 152 435 512 157 436 minecraft:red_nether_bricks
fill 512 152 437 512 153 438 minecraft:orange_concrete
fill 512 152 444 512 157 444 minecraft:red_nether_bricks
setblock 512 152 446 minecraft:orange_concrete
fill 512 152 447 512 157 448 minecraft:red_nether_bricks
fill 512 152 449 512 153 449 minecraft:orange_concrete
fill 512 152 455 512 157 456 minecraft:red_nether_bricks
setblock 512 152 457 minecraft:orange_concrete
setblock 470 153 417 minecraft:orange_concrete
setblock 470 153 428 minecraft:orange_concrete
fill 470 153 432 470 155 433 minecraft:red_nether_bricks
fill 470 153 448 470 153 449 minecraft:orange_concrete
setblock 470 153 452 minecraft:orange_concrete
fill 470 153 453 470 156 453 minecraft:red_nether_bricks
setblock 473 153 416 minecraft:orange_concrete
fill 476 153 458 476 156 458 minecraft:red_nether_bricks
setblock 481 153 458 minecraft:orange_concrete
setblock 482 153 432 minecraft:blackstone
setblock 482 153 448 minecraft:blackstone
fill 488 153 448 489 154 449 minecraft:shroomlight
fill 489 153 416 490 156 416 minecraft:red_nether_bricks
setblock 492 153 458 minecraft:orange_concrete
setblock 494 153 416 minecraft:orange_concrete
fill 495 153 449 496 154 449 minecraft:red_nether_bricks
fill 496 153 458 497 156 458 minecraft:red_nether_bricks
fill 498 153 449 498 159 449 minecraft:red_nether_bricks
fill 499 153 450 499 158 451 minecraft:red_nether_bricks
fill 501 153 422 501 153 427 minecraft:blackstone
fill 502 153 421 502 153 422 minecraft:blackstone
fill 502 153 428 503 153 428 minecraft:blackstone
fill 503 153 421 507 153 421 minecraft:blackstone
fill 504 153 429 506 153 429 minecraft:blackstone
setblock 505 153 416 minecraft:orange_concrete
setblock 505 153 420 minecraft:blackstone
setblock 507 153 428 minecraft:blackstone
fill 508 153 422 508 153 423 minecraft:blackstone
setblock 508 153 427 minecraft:blackstone
fill 509 153 423 509 153 426 minecraft:blackstone
fill 510 153 416 510 156 416 minecraft:red_nether_bricks
fill 512 153 425 512 156 425 minecraft:red_nether_bricks
setblock 512 153 426 minecraft:orange_concrete
fill 512 153 429 512 153 430 minecraft:orange_concrete
fill 512 153 446 512 156 446 minecraft:red_nether_bricks
setblock 512 153 450 minecraft:orange_concrete
fill 512 153 457 512 156 457 minecraft:red_nether_bricks
fill 470 154 417 470 159 417 minecraft:red_nether_bricks
fill 470 154 418 470 154 419 minecraft:orange_concrete
fill 470 154 420 470 156 421 minecraft:red_nether_bricks
fill 470 154 426 470 155 427 minecraft:orange_concrete
fill 470 154 428 470 159 429 minecraft:red_nether_bricks
setblock 470 154 430 minecraft:orange_concrete
fill 470 154 431 470 157 431 minecraft:red_nether_bricks
fill 470 154 438 470 154 439 minecraft:orange_concrete
fill 470 154 440 470 159 441 minecraft:red_nether_bricks
fill 470 154 447 470 155 447 minecraft:orange_concrete
fill 470 154 448 470 159 449 minecraft:red_nether_bricks
setblock 470 154 450 minecraft:orange_concrete
fill 470 154 452 470 159 452 minecraft:red_nether_bricks
fill 470 154 458 471 155 458 minecraft:orange_concrete
fill 471 154 416 472 154 416 minecraft:orange_concrete
fill 472 154 458 473 159 458 minecraft:red_nether_bricks
fill 473 154 416 473 159 416 minecraft:red_nether_bricks
fill 475 154 416 475 155 416 minecraft:orange_concrete
fill 481 154 416 482 159 416 minecraft:red_nether_bricks
fill 481 154 458 481 159 458 minecraft:red_nether_bricks
fill 482 154 458 483 154 458 minecraft:orange_concrete
fill 483 154 416 484 155 416 minecraft:orange_concrete
fill 484 154 458 485 159 458 minecraft:red_nether_bricks
fill 490 154 458 491 155 458 minecraft:orange_concrete
setblock 492 154 416 minecraft:orange_concrete
fill 492 154 458 493 159 458 minecraft:red_nether_bricks
fill 493 154 416 494 159 416 minecraft:red_nether_bricks
fill 493 154 451 493 155 452 minecraft:magma_block
setblock 494 154 458 minecraft:orange_concrete
fill 495 154 416 496 155 416 minecraft:orange_concrete
fill 497 154 448 498 157 448 minecraft:red_nether_bricks
fill 499 154 449 500 160 449 minecraft:red_nether_bricks
fill 499 154 452 499 157 452 minecraft:red_nether_bricks
fill 500 154 450 500 159 451 minecraft:red_nether_bricks
fill 501 154 416 502 159 416 minecraft:red_nether_bricks
fill 502 154 458 503 155 458 minecraft:orange_concrete
fill 503 154 416 504 154 416 minecraft:orange_concrete
fill 504 154 458 505 159 458 minecraft:red_nether_bricks
fill 505 154 416 505 159 416 minecraft:red_nether_bricks
fill 511 154 458 511 155 458 minecraft:orange_concrete
fill 512 154 417 512 159 418 minecraft:red_nether_bricks
fill 512 154 419 512 155 420 minecraft:orange_concrete
fill 512 154 426 512 159 426 minecraft:red_nether_bricks
setblock 512 154 428 minecraft:orange_concrete
fill 512 154 429 512 159 430 minecraft:red_nether_bricks
fill 512 154 431 512 155 431 minecraft:orange_concrete
fill 512 154 437 512 159 438 minecraft:red_nether_bricks
fill 512 154 439 512 154 440 minecraft:orange_concrete
fill 512 154 449 512 159 450 minecraft:red_nether_bricks
fill 512 154 451 512 155 452 minecraft:orange_concrete
setblock 470 155 418 minecraft:orange_concrete
fill 470 155 419 470 158 419 minecraft:red_nether_bricks
fill 470 155 430 470 157 430 minecraft:red_nether_bricks
setblock 470 155 435 minecraft:orange_concrete
fill 470 155 436 470 155 437 minecraft:red_nether_bricks
setblock 470 155 438 minecraft:orange_concrete
fill 470 155 439 470 158 439 minecraft:red_nether_bricks
fill 470 155 444 470 155 445 minecraft:red_nether_bricks
setblock 470 155 446 minecraft:orange_concrete
fill 470 155 450 470 158 450 minecraft:red_nether_bricks
fill 471 155 416 472 157 416 minecraft:red_nether_bricks
setblock 476 155 416 minecraft:orange_concrete
setblock 477 155 458 minecraft:red_nether_bricks
fill 478 155 458 479 155 458 minecraft:orange_concrete
setblock 482 155 458 minecraft:orange_concrete
fill 483 155 458 483 158 458 minecraft:red_nether_bricks
setblock 487 155 416 minecraft:orange_concrete
fill 492 155 416 492 158 416 minecraft:red_nether_bricks
setblock 494 155 452 minecraft:magma_block
fill 494 155 458 494 158 458 minecraft:red_nether_bricks
fill 496 155 449 496 156 452 minecraft:red_nether_bricks
fill 499 155 448 500 161 448 minecraft:red_nether_bricks
setblock 499 155 458 minecraft:orange_concrete
fill 501 155 449 501 160 450 minecraft:red_nether_bricks
fill 503 155 416 503 158 416 minecraft:red_nether_bricks
setblock 504 155 416 minecraft:orange_concrete
fill 507 155 416 508 155 416 minecraft:orange_concrete
setblock 510 155 458 minecraft:orange_concrete
fill 512 155 428 512 158 428 minecraft:red_nether_bricks
setblock 512 155 432 minecraft:orange_concrete
fill 512 155 439 512 158 439 minecraft:red_nether_bricks
setblock 512 155 440 minecraft:orange_concrete
setblock 512 155 443 minecraft:orange_concrete
setblock 470 156 416 minecraft:orange_concrete
fill 470 156 418 470 158 418 minecraft:red_nether_bricks
fill 470 156 424 470 157 425 minecraft:orange_concrete
fill 470 156 426 470 161 427 minecraft:red_nether_bricks
fill 470 156 432 471 156 432 minecraft:red_nether_bricks
fill 470 156 433 470 157 433 minecraft:orange_concrete
fill 470 156 435 471 156 435 minecraft:red_nether_bricks
fill 470 156 436 470 156 437 minecraft:orange_concrete
fill 470 156 438 470 161 438 minecraft:red_nether_bricks
fill 470 156 444 470 157 445 minecraft:orange_concrete
fill 470 156 446 470 161 447 minecraft:red_nether_bricks
fill 470 156 456 470 156 457 minecraft:orange_concrete
fill 470 156 458 471 161 458 minecraft:red_nether_bricks
fill 471 156 417 473 156 417 minecraft:red_nether_bricks
fill 471 156 419 471 156 421 minecraft:red_nether_bricks
fill 471 156 423 471 156 425 minecraft:red_nether_bricks
fill 471 156 427 471 156 429 minecraft:red_nether_bricks
setblock 471 156 431 minecraft:red_nether_bricks
setblock 471 156 433 minecraft:red_nether_bricks
fill 471 156 436 471 156 437 minecraft:red_nether_bricks
fill 471 156 439 471 156 441 minecraft:red_nether_bricks
fill 471 156 443 471 156 445 minecraft:red_nether_bricks
fill 471 156 447 471 156 449 minecraft:red_nether_bricks
fill 471 156 451 471 156 453 minecraft:red_nether_bricks
fill 471 156 455 471 156 457 minecraft:red_nether_bricks
fill 473 156 457 475 156 457 minecraft:red_nether_bricks
setblock 474 156 416 minecraft:orange_concrete
fill 475 156 416 476 156 417 minecraft:red_nether_bricks
fill 477 156 416 478 157 416 minecraft:orange_concrete
setblock 477 156 417 minecraft:red_nether_bricks
fill 477 156 457 479 156 457 minecraft:red_nether_bricks
fill 477 156 458 477 157 458 minecraft:orange_concrete
fill 478 156 458 479 161 458 minecraft:red_nether_bricks
fill 479 156 417 481 156 417 minecraft:red_nether_bricks
setblock 480 156 458 minecraft:orange_concrete
fill 481 156 457 483 156 457 minecraft:red_nether_bricks
fill 482 156 458 482 161 458 minecraft:red_nether_bricks
fill 483 156 416 484 156 417 minecraft:red_nether_bricks
fill 485 156 416 486 156 416 minecraft:orange_concrete
setblock 485 156 417 minecraft:red_nether_bricks
fill 485 156 457 487 156 457 minecraft:red_nether_bricks
fill 487 156 416 487 156 417 minecraft:red_nether_bricks
fill 488 156 417 489 156 417 minecraft:red_nether_bricks
fill 488 156 458 489 157 458 minecraft:orange_concrete
fill 489 156 457 491 156 457 minecraft:red_nether_bricks
fill 490 156 458 491 161 458 minecraft:red_nether_bricks
fill 491 156 417 493 156 417 minecraft:red_nether_bricks
setblock 493 156 452 minecraft:magma_block
fill 493 156 457 495 156 457 minecraft:red_nether_bricks
fill 495 156 416 496 156 417 minecraft:red_nether_bricks
fill 497 156 416 498 157 416 minecraft:orange_concrete
setblock 497 156 417 minecraft:red_nether_bricks
fill 497 156 457 499 156 457 minecraft:red_nether_bricks
fill 499 156 417 501 156 417 minecraft:red_nether_bricks
fill 499 156 447 500 160 447 minecraft:red_nether_bricks
fill 499 156 458 499 161 458 minecraft:red_nether_bricks
setblock 500 156 452 minecraft:red_nether_bricks
fill 500 156 458 501 156 458 minecraft:orange_concrete
fill 501 156 448 501 163 448 minecraft:red_nether_bricks
fill 501 156 451 501 158 451 minecraft:red_nether_bricks
fill 501 156 457 503 156 457 minecraft:red_nether_bricks
fill 502 156 458 503 161 458 minecraft:red_nether_bricks
fill 503 156 417 505 156 417 minecraft:red_nether_bricks
fill 504 156 416 504 161 416 minecraft:red_nether_bricks
fill 505 156 457 507 156 457 minecraft:red_nether_bricks
setblock 506 156 416 minecraft:orange_concrete
fill 507 156 416 508 156 417 minecraft:red_nether_bricks
fill 508 156 458 509 157 458 minecraft:orange_concrete
fill 509 156 416 509 157 416 minecraft:orange_concrete
setblock 509 156 417 minecraft:red_nether_bricks
fill 509 156 457 511 156 457 minecraft:red_nether_bricks
fill 510 156 458 511 161 458 minecraft:red_nether_bricks
fill 511 156 417 511 156 419 minecraft:red_nether_bricks
fill 511 156 421 511 156 423 minecraft:red_nether_bricks
fill 511 156 425 511 156 427 minecraft:red_nether_bricks
fill 511 156 429 511 156 431 minecraft:red_nether_bricks
fill 511 156 433 511 156 435 minecraft:red_nether_bricks
fill 511 156 437 511 156 439 minecraft:red_nether_bricks
fill 511 156 441 511 156 443 minecraft:red_nether_bricks
fill 511 156 445 511 156 447 minecraft:red_nether_bricks
fill 511 156 449 511 156 451 minecraft:red_nether_bricks
fill 511 156 453 511 156 455 minecraft:red_nether_bricks
fill 512 156 419 512 161 420 minecraft:red_nether_bricks
fill 512 156 421 512 156 422 minecraft:orange_concrete
fill 512 156 431 512 161 432 minecraft:red_nether_bricks
fill 512 156 433 512 157 434 minecraft:orange_concrete
fill 512 156 440 512 161 440 minecraft:red_nether_bricks
fill 512 156 441 512 156 442 minecraft:orange_concrete
fill 512 156 443 512 161 443 minecraft:red_nether_bricks
fill 512 156 445 512 157 445 minecraft:orange_concrete
fill 512 156 451 512 161 452 minecraft:red_nether_bricks
fill 512 156 453 512 157 454 minecraft:orange_concrete
setblock 512 156 458 minecraft:orange_concrete
fill 470 157 416 470 160 416 minecraft:red_nether_bricks
fill 470 157 420 470 159 420 minecraft:red_nether_bricks
setblock 470 157 421 minecraft:orange_concrete
setblock 470 157 432 minecraft:orange_concrete
fill 470 157 435 470 160 437 minecraft:red_nether_bricks
setblock 470 157 453 minecraft:orange_concrete
setblock 470 157 456 minecraft:orange_concrete
fill 470 157 457 470 160 457 minecraft:red_nether_bricks
fill 474 157 416 476 159 416 minecraft:red_nether_bricks
setblock 476 157 458 minecraft:orange_concrete
fill 480 157 458 480 160 458 minecraft:red_nether_bricks
fill 483 157 416 485 160 416 minecraft:red_nether_bricks
setblock 486 157 416 minecraft:orange_concrete
fill 487 157 416 487 161 416 minecraft:red_nether_bricks
fill 489 157 416 490 157 416 minecraft:orange_concrete
fill 489 157 444 491 215 445 minecraft:red_nether_bricks
fill 495 157 416 496 161 416 minecraft:red_nether_bricks
fill 496 157 458 497 157 458 minecraft:orange_concrete
fill 497 157 450 497 157 451 minecraft:red_nether_bricks
setblock 500 157 458 minecraft:orange_concrete
fill 501 157 447 502 163 447 minecraft:red_nether_bricks
fill 501 157 458 501 160 458 minecraft:red_nether_bricks
fill 502 157 448 502 160 450 minecraft:red_nether_bricks
fill 506 157 416 508 160 416 minecraft:red_nether_bricks
setblock 510 157 416 minecraft:orange_concrete
fill 512 157 421 512 160 421 minecraft:red_nether_bricks
setblock 512 157 422 minecraft:orange_concrete
setblock 512 157 425 minecraft:orange_concrete
fill 512 157 441 512 160 442 minecraft:red_nether_bricks
setblock 512 157 446 minecraft:orange_concrete
setblock 512 157 457 minecraft:orange_concrete
fill 512 157 458 512 160 458 minecraft:red_nether_bricks
fill 470 158 421 470 159 421 minecraft:red_nether_bricks
fill 470 158 422 470 158 423 minecraft:orange_concrete
fill 470 158 424 470 163 425 minecraft:red_nether_bricks
fill 470 158 430 470 159 431 minecraft:orange_concrete
fill 470 158 432 470 163 433 minecraft:red_nether_bricks
setblock 470 158 434 minecraft:orange_concrete
fill 470 158 442 470 159 443 minecraft:orange_concrete
fill 470 158 444 470 163 445 minecraft:red_nether_bricks
fill 470 158 451 470 159 451 minecraft:orange_concrete
fill 470 158 453 470 163 453 minecraft:red_nether_bricks
fill 470 158 454 470 158 455 minecraft:orange_concrete
fill 470 158 456 470 163 456 minecraft:red_nether_bricks
fill 471 158 416 471 159 416 minecraft:orange_concrete
setblock 472 158 416 minecraft:red_nether_bricks
fill 474 158 458 475 159 458 minecraft:orange_concrete
fill 476 158 458 477 163 458 minecraft:red_nether_bricks
fill 477 158 416 478 163 416 minecraft:red_nether_bricks
fill 479 158 416 480 159 416 minecraft:orange_concrete
fill 486 158 416 486 163 416 minecraft:red_nether_bricks
fill 486 158 458 487 158 458 minecraft:orange_concrete
setblock 488 158 416 minecraft:orange_concrete
fill 488 158 458 489 163 458 minecraft:red_nether_bricks
fill 489 158 416 490 163 416 minecraft:red_nether_bricks
fill 489 158 443 489 159 443 minecraft:blackstone
fill 490 158 446 490 159 446 minecraft:blackstone
fill 491 158 416 491 159 416 minecraft:orange_concrete
fill 495 158 458 495 159 458 minecraft:orange_concrete
fill 496 158 458 497 163 458 minecraft:red_nether_bricks
fill 497 158 416 498 163 416 minecraft:red_nether_bricks
fill 497 158 450 498 158 450 minecraft:red_nether_bricks
fill 498 158 448 498 159 448 minecraft:red_nether_bricks
setblock 498 158 451 minecraft:red_nether_bricks
setblock 498 158 458 minecraft:orange_concrete
fill 499 158 416 500 158 416 minecraft:orange_concrete
fill 500 158 446 502 162 446 minecraft:red_nether_bricks
fill 500 158 458 500 163 458 minecraft:red_nether_bricks
fill 503 158 447 503 163 448 minecraft:red_nether_bricks
fill 506 158 458 507 159 458 minecraft:orange_concrete
fill 508 158 458 509 163 458 minecraft:red_nether_bricks
fill 509 158 416 510 163 416 minecraft:red_nether_bricks
fill 511 158 416 512 159 416 minecraft:orange_concrete
fill 512 158 422 512 163 422 minecraft:red_nether_bricks
fill 512 158 423 512 158 424 minecraft:orange_concrete
fill 512 158 425 512 163 425 minecraft:red_nether_bricks
fill 512 158 427 512 159 427 minecraft:orange_concrete
fill 512 158 433 512 163 434 minecraft:red_nether_bricks
fill 512 158 435 512 159 436 minecraft:orange_concrete
setblock 512 158 444 minecraft:orange_concrete
fill 512 158 445 512 163 446 minecraft:red_nether_bricks
fill 512 158 447 512 159 448 minecraft:orange_concrete
fill 512 158 453 512 163 454 minecraft:red_nether_bricks
schedule function dropper:buildpart/106_4 1t
