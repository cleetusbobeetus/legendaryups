fill 242 278 311 270 278 311 minecraft:smooth_sandstone
fill 243 278 282 269 278 282 minecraft:smooth_sandstone
fill 243 278 284 243 278 308 minecraft:smooth_sandstone
fill 243 278 310 269 278 310 minecraft:smooth_sandstone
setblock 244 278 275 minecraft:lapis_block
fill 244 278 283 268 278 283 minecraft:smooth_sandstone
fill 244 278 285 244 278 307 minecraft:smooth_sandstone
fill 244 278 309 268 278 309 minecraft:smooth_sandstone
fill 245 278 275 245 285 275 minecraft:smooth_sandstone
fill 245 278 284 267 278 284 minecraft:smooth_sandstone
fill 245 278 286 245 278 306 minecraft:smooth_sandstone
fill 245 278 308 267 278 308 minecraft:smooth_sandstone
fill 246 278 285 266 278 285 minecraft:smooth_sandstone
fill 246 278 287 246 278 305 minecraft:smooth_sandstone
fill 246 278 307 266 278 307 minecraft:smooth_sandstone
fill 247 278 286 265 278 286 minecraft:smooth_sandstone
fill 247 278 288 247 278 304 minecraft:smooth_sandstone
fill 247 278 306 265 278 306 minecraft:smooth_sandstone
fill 248 278 287 264 278 287 minecraft:smooth_sandstone
fill 248 278 289 248 278 303 minecraft:smooth_sandstone
fill 248 278 305 264 278 305 minecraft:smooth_sandstone
fill 249 278 275 249 308 275 minecraft:smooth_sandstone
fill 249 278 288 263 278 288 minecraft:smooth_sandstone
fill 249 278 290 249 278 302 minecraft:smooth_sandstone
fill 249 278 304 263 278 304 minecraft:smooth_sandstone
fill 250 278 289 262 278 289 minecraft:smooth_sandstone
fill 250 278 291 250 278 301 minecraft:smooth_sandstone
fill 250 278 303 262 278 303 minecraft:smooth_sandstone
fill 251 278 290 261 278 290 minecraft:smooth_sandstone
fill 251 278 292 251 278 300 minecraft:smooth_sandstone
fill 251 278 302 261 278 302 minecraft:smooth_sandstone
fill 252 278 291 255 278 291 minecraft:smooth_sandstone
fill 252 278 293 252 278 299 minecraft:smooth_sandstone
fill 252 278 301 260 278 301 minecraft:smooth_sandstone
setblock 253 278 292 minecraft:smooth_sandstone
fill 253 278 295 253 278 298 minecraft:smooth_sandstone
fill 253 278 300 259 278 300 minecraft:smooth_sandstone
setblock 254 278 297 minecraft:smooth_sandstone
fill 254 278 299 258 278 299 minecraft:smooth_sandstone
fill 255 278 298 257 278 298 minecraft:smooth_sandstone
fill 257 278 291 260 278 291 minecraft:smooth_sandstone
fill 258 278 297 276 278 297 minecraft:smooth_sandstone
setblock 259 278 292 minecraft:smooth_sandstone
fill 259 278 295 276 278 296 minecraft:smooth_sandstone
fill 259 278 298 276 278 298 minecraft:smooth_sandstone
fill 260 278 293 276 278 294 minecraft:smooth_sandstone
fill 260 278 299 276 278 299 minecraft:smooth_sandstone
fill 261 278 292 276 278 292 minecraft:smooth_sandstone
fill 261 278 300 276 278 300 minecraft:smooth_sandstone
fill 262 278 291 276 278 291 minecraft:smooth_sandstone
fill 262 278 301 276 278 301 minecraft:smooth_sandstone
fill 263 278 290 276 278 290 minecraft:smooth_sandstone
fill 263 278 302 276 278 302 minecraft:smooth_sandstone
fill 264 278 289 276 278 289 minecraft:smooth_sandstone
fill 264 278 303 276 278 303 minecraft:smooth_sandstone
fill 265 278 288 276 278 288 minecraft:smooth_sandstone
fill 265 278 304 276 278 304 minecraft:smooth_sandstone
fill 266 278 287 276 278 287 minecraft:smooth_sandstone
fill 266 278 305 276 278 305 minecraft:smooth_sandstone
fill 267 278 286 276 278 286 minecraft:smooth_sandstone
fill 267 278 306 276 278 306 minecraft:smooth_sandstone
fill 268 278 285 276 278 285 minecraft:smooth_sandstone
fill 268 278 307 276 278 307 minecraft:smooth_sandstone
fill 269 278 284 276 278 284 minecraft:smooth_sandstone
fill 269 278 308 276 278 308 minecraft:smooth_sandstone
fill 270 278 283 276 278 283 minecraft:smooth_sandstone
fill 270 278 309 276 278 309 minecraft:smooth_sandstone
fill 271 278 282 276 278 282 minecraft:smooth_sandstone
fill 271 278 310 276 278 310 minecraft:smooth_sandstone
setblock 271 278 317 minecraft:blue_terracotta
fill 272 278 281 276 278 281 minecraft:smooth_sandstone
fill 272 278 311 276 278 311 minecraft:smooth_sandstone
fill 272 278 317 272 282 317 minecraft:smooth_sandstone
fill 273 278 280 276 278 280 minecraft:smooth_sandstone
fill 273 278 312 276 278 312 minecraft:smooth_sandstone
setblock 273 278 317 minecraft:black_terracotta
fill 274 278 279 276 278 279 minecraft:smooth_sandstone
fill 274 278 313 276 278 313 minecraft:smooth_sandstone
fill 274 278 317 274 285 317 minecraft:smooth_sandstone
fill 275 278 278 276 278 278 minecraft:smooth_sandstone
fill 275 278 314 276 278 314 minecraft:smooth_sandstone
setblock 276 278 277 minecraft:smooth_sandstone
setblock 276 278 315 minecraft:smooth_sandstone
fill 236 279 276 236 279 316 minecraft:sandstone
fill 237 279 276 276 279 276 minecraft:sandstone
fill 237 279 278 237 279 314 minecraft:sandstone
fill 237 279 316 276 279 316 minecraft:sandstone
fill 238 279 277 274 279 277 minecraft:sandstone
fill 238 279 279 238 279 313 minecraft:sandstone
fill 238 279 315 274 279 315 minecraft:sandstone
fill 239 279 278 273 279 278 minecraft:sandstone
fill 239 279 280 239 279 312 minecraft:sandstone
fill 239 279 314 273 279 314 minecraft:sandstone
fill 240 279 279 272 279 279 minecraft:sandstone
fill 240 279 281 240 279 311 minecraft:sandstone
fill 240 279 313 272 279 313 minecraft:sandstone
fill 241 279 280 271 279 280 minecraft:sandstone
fill 241 279 282 241 279 310 minecraft:sandstone
fill 241 279 312 271 279 312 minecraft:sandstone
fill 242 279 281 270 279 281 minecraft:sandstone
fill 242 279 283 242 279 309 minecraft:sandstone
fill 242 279 311 270 279 311 minecraft:sandstone
fill 243 279 282 269 279 282 minecraft:sandstone
fill 243 279 284 243 279 308 minecraft:sandstone
fill 243 279 310 269 279 310 minecraft:sandstone
fill 244 279 275 244 283 275 minecraft:smooth_sandstone
fill 244 279 283 268 279 283 minecraft:sandstone
fill 244 279 285 244 279 307 minecraft:sandstone
fill 244 279 309 268 279 309 minecraft:sandstone
fill 245 279 284 267 279 284 minecraft:sandstone
fill 245 279 286 245 279 306 minecraft:sandstone
fill 245 279 308 267 279 308 minecraft:sandstone
fill 246 279 285 266 279 285 minecraft:sandstone
fill 246 279 287 246 279 305 minecraft:sandstone
fill 246 279 307 266 279 307 minecraft:sandstone
fill 247 279 286 265 279 286 minecraft:sandstone
fill 247 279 288 247 279 304 minecraft:sandstone
fill 247 279 306 265 279 306 minecraft:sandstone
fill 248 279 287 264 279 287 minecraft:sandstone
fill 248 279 289 248 279 303 minecraft:sandstone
fill 248 279 305 264 279 305 minecraft:sandstone
fill 249 279 288 263 279 288 minecraft:sandstone
fill 249 279 290 249 279 302 minecraft:sandstone
fill 249 279 304 263 279 304 minecraft:sandstone
fill 250 279 289 262 279 289 minecraft:sandstone
fill 250 279 291 250 279 301 minecraft:sandstone
fill 250 279 303 262 279 303 minecraft:sandstone
fill 251 279 290 254 279 290 minecraft:sandstone
fill 251 279 292 251 279 300 minecraft:sandstone
fill 251 279 302 261 279 302 minecraft:sandstone
setblock 252 279 291 minecraft:sandstone
fill 252 279 293 252 279 295 minecraft:gold_block
fill 252 279 296 252 279 299 minecraft:sandstone
fill 252 279 301 260 279 301 minecraft:sandstone
fill 253 279 291 253 279 292 minecraft:gold_block
fill 253 279 295 253 279 297 minecraft:gold_block
setblock 253 279 298 minecraft:sandstone
fill 253 279 300 259 279 300 minecraft:sandstone
fill 254 279 291 255 279 291 minecraft:gold_block
setblock 254 279 297 minecraft:gold_block
fill 254 279 299 258 279 299 minecraft:sandstone
fill 255 279 290 257 279 290 minecraft:gold_block
fill 255 279 298 257 279 298 minecraft:gold_block
fill 257 279 291 259 279 291 minecraft:gold_block
fill 258 279 290 261 279 290 minecraft:sandstone
fill 258 279 297 259 279 297 minecraft:gold_block
setblock 259 279 292 minecraft:gold_block
fill 259 279 295 259 279 296 minecraft:gold_block
fill 259 279 298 276 279 298 minecraft:sandstone
setblock 260 279 291 minecraft:sandstone
fill 260 279 293 260 279 295 minecraft:gold_block
fill 260 279 296 276 279 297 minecraft:sandstone
fill 260 279 299 276 279 299 minecraft:sandstone
fill 261 279 292 276 279 295 minecraft:sandstone
fill 261 279 300 276 279 300 minecraft:sandstone
fill 262 279 291 276 279 291 minecraft:sandstone
fill 262 279 301 276 279 301 minecraft:sandstone
fill 263 279 290 276 279 290 minecraft:sandstone
fill 263 279 302 276 279 302 minecraft:sandstone
fill 264 279 289 276 279 289 minecraft:sandstone
fill 264 279 303 276 279 303 minecraft:sandstone
fill 265 279 288 276 279 288 minecraft:sandstone
fill 265 279 304 276 279 304 minecraft:sandstone
fill 266 279 287 276 279 287 minecraft:sandstone
fill 266 279 305 276 279 305 minecraft:sandstone
fill 267 279 286 276 279 286 minecraft:sandstone
fill 267 279 306 276 279 306 minecraft:sandstone
fill 268 279 285 276 279 285 minecraft:sandstone
fill 268 279 307 276 279 307 minecraft:sandstone
fill 269 279 284 276 279 284 minecraft:sandstone
fill 269 279 308 276 279 308 minecraft:sandstone
fill 270 279 283 276 279 283 minecraft:sandstone
fill 270 279 309 276 279 309 minecraft:sandstone
setblock 270 279 317 minecraft:orange_terracotta
fill 271 279 282 276 279 282 minecraft:sandstone
fill 271 279 310 276 279 310 minecraft:sandstone
fill 271 279 317 271 285 317 minecraft:smooth_sandstone
fill 272 279 281 276 279 281 minecraft:sandstone
fill 272 279 311 276 279 311 minecraft:sandstone
fill 273 279 280 276 279 280 minecraft:sandstone
fill 273 279 312 276 279 312 minecraft:sandstone
fill 273 279 317 273 285 317 minecraft:smooth_sandstone
fill 274 279 279 276 279 279 minecraft:sandstone
fill 274 279 313 276 279 313 minecraft:sandstone
fill 275 279 278 276 279 278 minecraft:sandstone
fill 275 279 314 276 279 314 minecraft:sandstone
setblock 276 279 277 minecraft:sandstone
setblock 276 279 315 minecraft:sandstone
fill 277 279 296 277 308 296 minecraft:smooth_sandstone
setblock 277 279 297 minecraft:blue_terracotta
setblock 238 280 278 minecraft:light[level=12]
setblock 238 280 285 minecraft:light[level=12]
setblock 238 280 292 minecraft:light[level=12]
setblock 238 280 299 minecraft:light[level=12]
setblock 238 280 306 minecraft:light[level=12]
setblock 238 280 313 minecraft:light[level=12]
fill 239 280 280 239 280 312 minecraft:smooth_sandstone
setblock 239 280 317 minecraft:orange_terracotta
fill 240 280 279 272 280 279 minecraft:smooth_sandstone
fill 240 280 281 240 280 311 minecraft:smooth_sandstone
fill 240 280 313 272 280 313 minecraft:smooth_sandstone
fill 241 280 280 271 280 280 minecraft:smooth_sandstone
fill 241 280 282 241 280 310 minecraft:smooth_sandstone
fill 241 280 312 271 280 312 minecraft:smooth_sandstone
fill 242 280 281 270 280 281 minecraft:smooth_sandstone
fill 242 280 283 242 280 309 minecraft:smooth_sandstone
fill 242 280 311 270 280 311 minecraft:smooth_sandstone
fill 243 280 282 269 280 282 minecraft:smooth_sandstone
fill 243 280 284 243 280 308 minecraft:smooth_sandstone
fill 243 280 310 269 280 310 minecraft:smooth_sandstone
fill 244 280 283 268 280 283 minecraft:smooth_sandstone
fill 244 280 285 244 280 307 minecraft:smooth_sandstone
fill 244 280 309 268 280 309 minecraft:smooth_sandstone
setblock 245 280 278 minecraft:light[level=12]
fill 245 280 284 267 280 284 minecraft:smooth_sandstone
fill 245 280 286 245 280 306 minecraft:smooth_sandstone
fill 245 280 308 267 280 308 minecraft:smooth_sandstone
fill 246 280 285 266 280 285 minecraft:smooth_sandstone
fill 246 280 287 246 280 305 minecraft:smooth_sandstone
fill 246 280 307 266 280 307 minecraft:smooth_sandstone
fill 247 280 286 265 280 286 minecraft:smooth_sandstone
fill 247 280 288 247 280 304 minecraft:smooth_sandstone
fill 247 280 306 265 280 306 minecraft:smooth_sandstone
fill 248 280 287 264 280 287 minecraft:smooth_sandstone
fill 248 280 289 248 280 303 minecraft:smooth_sandstone
fill 248 280 305 264 280 305 minecraft:smooth_sandstone
fill 249 280 288 263 280 288 minecraft:smooth_sandstone
fill 249 280 290 249 280 302 minecraft:smooth_sandstone
fill 249 280 304 263 280 304 minecraft:smooth_sandstone
fill 250 280 289 262 280 289 minecraft:smooth_sandstone
fill 250 280 291 250 280 301 minecraft:smooth_sandstone
fill 250 280 303 262 280 303 minecraft:smooth_sandstone
fill 251 280 290 261 280 290 minecraft:smooth_sandstone
fill 251 280 292 251 280 300 minecraft:smooth_sandstone
fill 251 280 302 261 280 302 minecraft:smooth_sandstone
setblock 252 280 278 minecraft:light[level=12]
fill 252 280 291 255 280 291 minecraft:smooth_sandstone
fill 252 280 293 252 280 299 minecraft:smooth_sandstone
fill 252 280 301 260 280 301 minecraft:smooth_sandstone
setblock 253 280 292 minecraft:smooth_sandstone
fill 253 280 295 253 280 298 minecraft:smooth_sandstone
fill 253 280 300 259 280 300 minecraft:smooth_sandstone
setblock 254 280 297 minecraft:smooth_sandstone
fill 254 280 299 258 280 299 minecraft:smooth_sandstone
fill 255 280 298 257 280 298 minecraft:smooth_sandstone
fill 257 280 291 260 280 291 minecraft:smooth_sandstone
fill 258 280 297 273 280 297 minecraft:smooth_sandstone
setblock 259 280 278 minecraft:light[level=12]
setblock 259 280 292 minecraft:smooth_sandstone
fill 259 280 295 273 280 296 minecraft:smooth_sandstone
fill 259 280 298 273 280 298 minecraft:smooth_sandstone
fill 260 280 293 273 280 294 minecraft:smooth_sandstone
fill 260 280 299 273 280 299 minecraft:smooth_sandstone
fill 261 280 292 273 280 292 minecraft:smooth_sandstone
fill 261 280 300 273 280 300 minecraft:smooth_sandstone
fill 262 280 291 273 280 291 minecraft:smooth_sandstone
fill 262 280 301 273 280 301 minecraft:smooth_sandstone
fill 263 280 290 273 280 290 minecraft:smooth_sandstone
fill 263 280 302 273 280 302 minecraft:smooth_sandstone
fill 264 280 289 273 280 289 minecraft:smooth_sandstone
fill 264 280 303 273 280 303 minecraft:smooth_sandstone
fill 265 280 288 273 280 288 minecraft:smooth_sandstone
fill 265 280 304 273 280 304 minecraft:smooth_sandstone
setblock 266 280 278 minecraft:light[level=12]
fill 266 280 287 273 280 287 minecraft:smooth_sandstone
fill 266 280 305 273 280 305 minecraft:smooth_sandstone
fill 267 280 286 273 280 286 minecraft:smooth_sandstone
fill 267 280 306 273 280 306 minecraft:smooth_sandstone
fill 268 280 285 273 280 285 minecraft:smooth_sandstone
fill 268 280 307 273 280 307 minecraft:smooth_sandstone
fill 269 280 284 273 280 284 minecraft:smooth_sandstone
fill 269 280 308 273 280 308 minecraft:smooth_sandstone
fill 270 280 283 273 280 283 minecraft:smooth_sandstone
fill 270 280 309 273 280 309 minecraft:smooth_sandstone
fill 270 280 317 270 308 317 minecraft:smooth_sandstone
fill 271 280 282 273 280 282 minecraft:smooth_sandstone
fill 271 280 310 273 280 310 minecraft:smooth_sandstone
fill 272 280 281 273 280 281 minecraft:smooth_sandstone
fill 272 280 311 273 280 311 minecraft:smooth_sandstone
setblock 273 280 278 minecraft:light[level=12]
setblock 273 280 280 minecraft:smooth_sandstone
setblock 273 280 312 minecraft:smooth_sandstone
fill 277 280 297 277 292 297 minecraft:smooth_sandstone
setblock 235 281 297 minecraft:blue_terracotta
fill 239 281 317 239 308 317 minecraft:smooth_sandstone
fill 240 281 281 240 281 311 minecraft:sandstone
fill 241 281 280 271 281 280 minecraft:sandstone
fill 241 281 282 241 281 310 minecraft:sandstone
fill 241 281 312 271 281 312 minecraft:sandstone
fill 242 281 281 270 281 281 minecraft:sandstone
fill 242 281 283 242 281 309 minecraft:sandstone
fill 242 281 311 270 281 311 minecraft:sandstone
fill 243 281 282 269 281 282 minecraft:sandstone
fill 243 281 284 243 281 308 minecraft:sandstone
fill 243 281 310 269 281 310 minecraft:sandstone
fill 244 281 283 268 281 283 minecraft:sandstone
fill 244 281 285 244 281 307 minecraft:sandstone
fill 244 281 309 268 281 309 minecraft:sandstone
fill 245 281 284 267 281 284 minecraft:sandstone
fill 245 281 286 245 281 306 minecraft:sandstone
fill 245 281 308 267 281 308 minecraft:sandstone
fill 246 281 285 266 281 285 minecraft:sandstone
fill 246 281 287 246 281 305 minecraft:sandstone
fill 246 281 307 266 281 307 minecraft:sandstone
fill 247 281 286 265 281 286 minecraft:sandstone
fill 247 281 288 247 281 304 minecraft:sandstone
fill 247 281 306 265 281 306 minecraft:sandstone
fill 248 281 287 264 281 287 minecraft:sandstone
fill 248 281 289 248 281 303 minecraft:sandstone
fill 248 281 305 264 281 305 minecraft:sandstone
fill 249 281 288 263 281 288 minecraft:sandstone
fill 249 281 290 249 281 302 minecraft:sandstone
fill 249 281 304 263 281 304 minecraft:sandstone
fill 250 281 289 262 281 289 minecraft:sandstone
fill 250 281 291 250 281 301 minecraft:sandstone
fill 250 281 303 262 281 303 minecraft:sandstone
fill 251 281 290 261 281 290 minecraft:sandstone
fill 251 281 292 251 281 300 minecraft:sandstone
fill 251 281 302 261 281 302 minecraft:sandstone
fill 252 281 291 255 281 291 minecraft:sandstone
fill 252 281 293 252 281 299 minecraft:sandstone
fill 252 281 301 260 281 301 minecraft:sandstone
setblock 253 281 292 minecraft:sandstone
fill 253 281 295 253 281 298 minecraft:sandstone
fill 253 281 300 259 281 300 minecraft:sandstone
setblock 254 281 297 minecraft:sandstone
fill 254 281 299 258 281 299 minecraft:sandstone
fill 255 281 298 257 281 298 minecraft:sandstone
fill 257 281 291 260 281 291 minecraft:sandstone
fill 258 281 297 272 281 297 minecraft:sandstone
setblock 259 281 292 minecraft:sandstone
fill 259 281 295 272 281 296 minecraft:sandstone
fill 259 281 298 272 281 298 minecraft:sandstone
fill 260 281 293 272 281 294 minecraft:sandstone
fill 260 281 299 272 281 299 minecraft:sandstone
fill 261 281 292 272 281 292 minecraft:sandstone
fill 261 281 300 272 281 300 minecraft:sandstone
fill 262 281 291 272 281 291 minecraft:sandstone
fill 262 281 301 272 281 301 minecraft:sandstone
fill 263 281 290 272 281 290 minecraft:sandstone
fill 263 281 302 272 281 302 minecraft:sandstone
fill 264 281 289 272 281 289 minecraft:sandstone
fill 264 281 303 272 281 303 minecraft:sandstone
fill 265 281 288 272 281 288 minecraft:sandstone
fill 265 281 304 272 281 304 minecraft:sandstone
fill 266 281 287 272 281 287 minecraft:sandstone
fill 266 281 305 272 281 305 minecraft:sandstone
fill 267 281 286 272 281 286 minecraft:sandstone
fill 267 281 306 272 281 306 minecraft:sandstone
fill 268 281 285 272 281 285 minecraft:sandstone
fill 268 281 307 272 281 307 minecraft:sandstone
setblock 268 281 317 minecraft:orange_terracotta
fill 269 281 284 272 281 284 minecraft:sandstone
fill 269 281 308 272 281 308 minecraft:sandstone
fill 270 281 283 272 281 283 minecraft:sandstone
fill 270 281 309 272 281 309 minecraft:sandstone
fill 271 281 282 272 281 282 minecraft:sandstone
fill 271 281 310 272 281 310 minecraft:sandstone
setblock 272 281 281 minecraft:sandstone
setblock 272 281 311 minecraft:sandstone
fill 277 281 277 277 285 277 minecraft:smooth_sandstone
setblock 277 281 278 minecraft:black_terracotta
fill 277 281 279 277 285 279 minecraft:smooth_sandstone
setblock 277 281 294 minecraft:black_terracotta
fill 277 281 295 277 308 295 minecraft:smooth_sandstone
setblock 277 281 299 minecraft:blue_terracotta
fill 277 281 300 277 285 303 minecraft:smooth_sandstone
setblock 277 281 307 minecraft:orange_terracotta
fill 235 282 297 235 308 297 minecraft:smooth_sandstone
setblock 238 282 278 minecraft:light[level=15]
setblock 238 282 286 minecraft:light[level=15]
setblock 238 282 294 minecraft:light[level=15]
setblock 238 282 302 minecraft:light[level=15]
setblock 238 282 310 minecraft:light[level=15]
fill 241 282 282 241 282 310 minecraft:smooth_sandstone
fill 242 282 281 270 282 281 minecraft:smooth_sandstone
fill 242 282 283 242 282 309 minecraft:smooth_sandstone
fill 242 282 311 270 282 311 minecraft:smooth_sandstone
fill 243 282 282 269 282 282 minecraft:smooth_sandstone
fill 243 282 284 243 282 308 minecraft:smooth_sandstone
fill 243 282 310 269 282 310 minecraft:smooth_sandstone
fill 244 282 283 268 282 283 minecraft:smooth_sandstone
fill 244 282 285 244 282 307 minecraft:smooth_sandstone
fill 244 282 309 268 282 309 minecraft:smooth_sandstone
fill 245 282 284 267 282 284 minecraft:smooth_sandstone
fill 245 282 286 245 282 306 minecraft:smooth_sandstone
fill 245 282 308 267 282 308 minecraft:smooth_sandstone
setblock 246 282 278 minecraft:light[level=15]
fill 246 282 285 266 282 285 minecraft:smooth_sandstone
fill 246 282 287 246 282 305 minecraft:smooth_sandstone
fill 246 282 307 266 282 307 minecraft:smooth_sandstone
fill 247 282 286 265 282 286 minecraft:smooth_sandstone
fill 247 282 288 247 282 304 minecraft:smooth_sandstone
fill 247 282 306 265 282 306 minecraft:smooth_sandstone
fill 247 282 317 248 285 317 minecraft:smooth_sandstone
fill 248 282 287 264 282 287 minecraft:smooth_sandstone
fill 248 282 289 248 282 303 minecraft:smooth_sandstone
fill 248 282 305 264 282 305 minecraft:smooth_sandstone
fill 249 282 288 263 282 288 minecraft:smooth_sandstone
fill 249 282 290 249 282 302 minecraft:smooth_sandstone
fill 249 282 304 263 282 304 minecraft:smooth_sandstone
setblock 249 282 317 minecraft:lapis_block
fill 250 282 289 262 282 289 minecraft:smooth_sandstone
fill 250 282 291 250 282 301 minecraft:smooth_sandstone
fill 250 282 303 262 282 303 minecraft:smooth_sandstone
fill 250 282 317 250 285 317 minecraft:smooth_sandstone
fill 251 282 290 261 282 290 minecraft:smooth_sandstone
fill 251 282 292 251 282 300 minecraft:smooth_sandstone
fill 251 282 302 261 282 302 minecraft:smooth_sandstone
fill 252 282 291 260 282 291 minecraft:smooth_sandstone
fill 252 282 293 252 282 299 minecraft:smooth_sandstone
fill 252 282 301 260 282 301 minecraft:smooth_sandstone
fill 253 282 292 259 282 292 minecraft:smooth_sandstone
fill 253 282 294 253 282 298 minecraft:smooth_sandstone
fill 253 282 300 259 282 300 minecraft:smooth_sandstone
setblock 254 282 278 minecraft:light[level=15]
fill 254 282 293 255 282 293 minecraft:smooth_sandstone
fill 254 282 294 254 291 294 minecraft:gold_block
fill 254 282 295 254 282 297 minecraft:smooth_sandstone
fill 254 282 299 258 282 299 minecraft:smooth_sandstone
fill 255 282 295 255 291 295 minecraft:gold_block
setblock 255 282 296 minecraft:smooth_sandstone
fill 255 282 298 257 282 298 minecraft:smooth_sandstone
fill 256 282 296 256 293 296 minecraft:gold_block
setblock 256 282 297 minecraft:smooth_sandstone
fill 257 282 293 258 282 293 minecraft:smooth_sandstone
fill 257 282 295 257 291 295 minecraft:gold_block
fill 257 282 296 271 282 296 minecraft:smooth_sandstone
fill 258 282 294 258 291 294 minecraft:gold_block
fill 258 282 295 271 282 295 minecraft:smooth_sandstone
fill 258 282 297 271 282 297 minecraft:smooth_sandstone
fill 259 282 294 271 282 294 minecraft:smooth_sandstone
fill 259 282 298 271 282 298 minecraft:smooth_sandstone
fill 260 282 293 271 282 293 minecraft:smooth_sandstone
fill 260 282 299 271 282 299 minecraft:smooth_sandstone
fill 261 282 292 271 282 292 minecraft:smooth_sandstone
fill 261 282 300 271 282 300 minecraft:smooth_sandstone
setblock 262 282 278 minecraft:light[level=15]
fill 262 282 291 271 282 291 minecraft:smooth_sandstone
fill 262 282 301 271 282 301 minecraft:smooth_sandstone
fill 263 282 290 271 282 290 minecraft:smooth_sandstone
fill 263 282 302 271 282 302 minecraft:smooth_sandstone
fill 264 282 289 271 282 289 minecraft:smooth_sandstone
fill 264 282 303 271 282 303 minecraft:smooth_sandstone
fill 265 282 288 271 282 288 minecraft:smooth_sandstone
fill 265 282 304 271 282 304 minecraft:smooth_sandstone
fill 266 282 287 271 282 287 minecraft:smooth_sandstone
fill 266 282 305 271 282 305 minecraft:smooth_sandstone
fill 267 282 286 271 282 286 minecraft:smooth_sandstone
fill 267 282 306 271 282 306 minecraft:smooth_sandstone
fill 268 282 285 271 282 285 minecraft:smooth_sandstone
fill 268 282 307 271 282 307 minecraft:smooth_sandstone
fill 268 282 317 268 308 317 minecraft:smooth_sandstone
setblock 269 282 275 minecraft:black_terracotta
fill 269 282 284 271 282 284 minecraft:smooth_sandstone
fill 269 282 308 271 282 308 minecraft:smooth_sandstone
setblock 270 282 278 minecraft:light[level=15]
fill 270 282 283 271 282 283 minecraft:smooth_sandstone
fill 270 282 309 271 282 309 minecraft:smooth_sandstone
setblock 271 282 282 minecraft:smooth_sandstone
setblock 271 282 310 minecraft:smooth_sandstone
fill 277 282 278 277 283 278 minecraft:smooth_sandstone
fill 277 282 294 277 308 294 minecraft:smooth_sandstone
fill 277 282 299 277 308 299 minecraft:smooth_sandstone
fill 277 282 307 277 308 307 minecraft:smooth_sandstone
setblock 235 283 277 minecraft:orange_terracotta
fill 235 283 278 235 293 278 minecraft:smooth_sandstone
fill 235 283 281 235 285 283 minecraft:smooth_sandstone
setblock 235 283 284 minecraft:lapis_block
fill 235 283 285 235 308 285 minecraft:smooth_sandstone
setblock 235 283 293 minecraft:black_terracotta
fill 235 283 294 235 285 296 minecraft:smooth_sandstone
fill 236 283 276 238 300 276 minecraft:cut_sandstone
fill 236 283 286 236 300 288 minecraft:cut_sandstone
fill 236 283 298 236 300 300 minecraft:cut_sandstone
fill 236 283 310 236 300 312 minecraft:cut_sandstone
fill 237 283 285 237 285 287 minecraft:cut_sandstone
fill 237 283 297 237 285 299 minecraft:cut_sandstone
fill 237 283 309 237 285 311 minecraft:cut_sandstone
fill 241 283 276 247 284 280 minecraft:cut_sandstone
fill 242 283 316 244 300 316 minecraft:cut_sandstone
fill 243 283 284 243 283 308 minecraft:sandstone
fill 243 283 315 245 285 315 minecraft:cut_sandstone
fill 244 283 283 268 283 283 minecraft:sandstone
fill 244 283 285 244 283 307 minecraft:sandstone
fill 244 283 309 268 283 309 minecraft:sandstone
fill 245 283 284 267 283 284 minecraft:sandstone
fill 245 283 286 245 283 306 minecraft:sandstone
fill 245 283 308 267 283 308 minecraft:sandstone
fill 246 283 285 266 283 285 minecraft:sandstone
fill 246 283 287 246 283 305 minecraft:sandstone
fill 246 283 307 266 283 307 minecraft:sandstone
fill 247 283 286 265 283 286 minecraft:sandstone
fill 247 283 288 247 283 304 minecraft:sandstone
fill 247 283 306 265 283 306 minecraft:sandstone
fill 248 283 276 249 285 277 minecraft:cut_sandstone
fill 248 283 287 264 283 287 minecraft:sandstone
fill 248 283 289 248 283 303 minecraft:sandstone
fill 248 283 305 264 283 305 minecraft:sandstone
fill 249 283 288 263 283 288 minecraft:sandstone
fill 249 283 290 249 283 302 minecraft:sandstone
fill 249 283 304 263 283 304 minecraft:sandstone
fill 249 283 317 249 285 317 minecraft:smooth_sandstone
fill 250 283 276 250 300 276 minecraft:cut_sandstone
fill 250 283 289 262 283 289 minecraft:sandstone
fill 250 283 291 250 283 301 minecraft:sandstone
fill 250 283 303 262 283 303 minecraft:sandstone
fill 251 283 290 261 283 290 minecraft:sandstone
fill 251 283 292 251 283 300 minecraft:sandstone
fill 251 283 302 261 283 302 minecraft:sandstone
fill 252 283 291 260 283 291 minecraft:sandstone
fill 252 283 293 252 283 299 minecraft:sandstone
fill 252 283 301 260 283 301 minecraft:sandstone
fill 253 283 292 259 283 292 minecraft:sandstone
fill 253 283 294 253 283 298 minecraft:sandstone
fill 253 283 300 259 283 300 minecraft:sandstone
fill 254 283 293 255 283 293 minecraft:sandstone
fill 254 283 295 254 283 297 minecraft:sandstone
fill 254 283 299 258 283 299 minecraft:sandstone
fill 254 283 316 256 300 316 minecraft:cut_sandstone
setblock 255 283 296 minecraft:sandstone
fill 255 283 298 257 283 298 minecraft:sandstone
fill 255 283 315 257 285 315 minecraft:cut_sandstone
setblock 256 283 297 minecraft:sandstone
fill 257 283 293 258 283 293 minecraft:sandstone
fill 257 283 296 269 283 296 minecraft:sandstone
fill 258 283 295 269 283 295 minecraft:sandstone
fill 258 283 297 269 283 297 minecraft:sandstone
fill 259 283 277 261 285 277 minecraft:cut_sandstone
fill 259 283 294 269 283 294 minecraft:sandstone
fill 259 283 298 269 283 298 minecraft:sandstone
fill 260 283 276 262 300 276 minecraft:cut_sandstone
fill 260 283 293 269 283 293 minecraft:sandstone
fill 260 283 299 269 283 299 minecraft:sandstone
fill 261 283 292 269 283 292 minecraft:sandstone
fill 261 283 300 269 283 300 minecraft:sandstone
fill 262 283 291 269 283 291 minecraft:sandstone
fill 262 283 301 269 283 301 minecraft:sandstone
fill 263 283 290 269 283 290 minecraft:sandstone
fill 263 283 302 269 283 302 minecraft:sandstone
fill 264 283 289 269 283 289 minecraft:sandstone
fill 264 283 303 269 283 303 minecraft:sandstone
fill 265 283 288 269 283 288 minecraft:sandstone
fill 265 283 304 269 283 304 minecraft:sandstone
fill 266 283 287 269 283 287 minecraft:sandstone
fill 266 283 305 269 283 305 minecraft:sandstone
fill 266 283 316 268 300 316 minecraft:cut_sandstone
fill 267 283 286 269 283 286 minecraft:sandstone
fill 267 283 306 269 283 306 minecraft:sandstone
fill 267 283 315 269 285 315 minecraft:cut_sandstone
fill 268 283 285 269 283 285 minecraft:sandstone
fill 268 283 307 269 283 307 minecraft:sandstone
fill 269 283 275 269 285 275 minecraft:smooth_sandstone
setblock 269 283 284 minecraft:sandstone
setblock 269 283 308 minecraft:sandstone
fill 270 283 310 270 283 311 minecraft:chiseled_sandstone
fill 270 283 312 273 300 312 minecraft:cut_sandstone
setblock 270 283 313 minecraft:chiseled_sandstone
fill 271 283 277 273 285 277 minecraft:cut_sandstone
fill 271 283 310 273 283 310 minecraft:chiseled_sandstone
fill 271 283 311 273 300 311 minecraft:cut_sandstone
fill 271 283 313 273 300 313 minecraft:cut_sandstone
fill 271 283 314 273 283 314 minecraft:chiseled_sandstone
fill 272 283 276 274 300 276 minecraft:cut_sandstone
fill 272 283 283 276 284 295 minecraft:cut_sandstone
setblock 272 283 317 minecraft:lapis_block
fill 274 283 311 274 283 313 minecraft:chiseled_sandstone
fill 275 283 297 275 285 299 minecraft:cut_sandstone
fill 275 283 309 275 285 311 minecraft:cut_sandstone
fill 276 283 296 276 300 298 minecraft:cut_sandstone
fill 276 283 308 276 300 310 minecraft:cut_sandstone
fill 235 284 277 235 308 277 minecraft:smooth_sandstone
fill 235 284 284 235 285 284 minecraft:smooth_sandstone
setblock 235 284 293 minecraft:lapis_block
setblock 244 284 275 minecraft:blue_terracotta
fill 244 284 285 244 284 307 minecraft:smooth_sandstone
fill 245 284 284 267 284 284 minecraft:smooth_sandstone
fill 245 284 286 245 284 306 minecraft:smooth_sandstone
fill 245 284 308 267 284 308 minecraft:smooth_sandstone
fill 246 284 285 266 284 285 minecraft:smooth_sandstone
fill 246 284 287 246 284 305 minecraft:smooth_sandstone
fill 246 284 307 266 284 307 minecraft:smooth_sandstone
fill 247 284 286 265 284 286 minecraft:smooth_sandstone
fill 247 284 288 247 284 304 minecraft:smooth_sandstone
fill 247 284 306 265 284 306 minecraft:smooth_sandstone
fill 248 284 287 264 284 287 minecraft:smooth_sandstone
fill 248 284 289 248 284 303 minecraft:smooth_sandstone
fill 248 284 305 264 284 305 minecraft:smooth_sandstone
fill 249 284 288 263 284 288 minecraft:smooth_sandstone
fill 249 284 290 249 284 302 minecraft:smooth_sandstone
fill 249 284 304 263 284 304 minecraft:smooth_sandstone
fill 250 284 289 262 284 289 minecraft:smooth_sandstone
fill 250 284 291 250 284 301 minecraft:smooth_sandstone
fill 250 284 303 262 284 303 minecraft:smooth_sandstone
fill 251 284 290 261 284 290 minecraft:smooth_sandstone
fill 251 284 292 251 284 300 minecraft:smooth_sandstone
fill 251 284 302 261 284 302 minecraft:smooth_sandstone
setblock 252 284 275 minecraft:blue_terracotta
fill 252 284 291 260 284 291 minecraft:smooth_sandstone
fill 252 284 293 252 284 299 minecraft:smooth_sandstone
fill 252 284 301 260 284 301 minecraft:smooth_sandstone
fill 252 284 317 252 308 317 minecraft:smooth_sandstone
fill 253 284 292 259 284 292 minecraft:smooth_sandstone
fill 253 284 294 253 284 298 minecraft:smooth_sandstone
fill 253 284 300 259 284 300 minecraft:smooth_sandstone
setblock 253 284 317 minecraft:orange_terracotta
fill 254 284 293 255 284 293 minecraft:smooth_sandstone
fill 254 284 295 254 284 297 minecraft:smooth_sandstone
fill 254 284 299 258 284 299 minecraft:smooth_sandstone
fill 254 284 317 254 303 317 minecraft:smooth_sandstone
setblock 255 284 296 minecraft:smooth_sandstone
fill 255 284 298 257 284 298 minecraft:smooth_sandstone
setblock 256 284 297 minecraft:smooth_sandstone
fill 257 284 293 258 284 293 minecraft:smooth_sandstone
fill 257 284 296 268 284 296 minecraft:smooth_sandstone
fill 258 284 295 268 284 295 minecraft:smooth_sandstone
fill 258 284 297 268 284 297 minecraft:smooth_sandstone
fill 259 284 294 268 284 294 minecraft:smooth_sandstone
fill 259 284 298 268 284 298 minecraft:smooth_sandstone
fill 260 284 293 268 284 293 minecraft:smooth_sandstone
fill 260 284 299 268 284 299 minecraft:smooth_sandstone
fill 261 284 292 268 284 292 minecraft:smooth_sandstone
fill 261 284 300 268 284 300 minecraft:smooth_sandstone
fill 262 284 291 268 284 291 minecraft:smooth_sandstone
fill 262 284 301 268 284 301 minecraft:smooth_sandstone
fill 263 284 290 268 284 290 minecraft:smooth_sandstone
fill 263 284 302 268 284 302 minecraft:smooth_sandstone
fill 264 284 289 268 284 289 minecraft:smooth_sandstone
fill 264 284 303 268 284 303 minecraft:smooth_sandstone
fill 265 284 288 268 284 288 minecraft:smooth_sandstone
fill 265 284 304 268 284 304 minecraft:smooth_sandstone
fill 266 284 287 268 284 287 minecraft:smooth_sandstone
fill 266 284 305 268 284 305 minecraft:smooth_sandstone
fill 267 284 286 268 284 286 minecraft:smooth_sandstone
fill 267 284 306 268 284 306 minecraft:smooth_sandstone
setblock 268 284 285 minecraft:smooth_sandstone
setblock 268 284 307 minecraft:smooth_sandstone
fill 272 284 317 272 285 317 minecraft:smooth_sandstone
setblock 277 284 278 minecraft:blue_terracotta
fill 277 284 312 277 285 314 minecraft:smooth_sandstone
setblock 277 284 315 minecraft:black_terracotta
setblock 235 285 276 minecraft:black_terracotta
setblock 235 285 293 minecraft:smooth_sandstone
fill 236 285 279 236 285 284 minecraft:chiseled_sandstone
fill 236 285 291 236 285 296 minecraft:chiseled_sandstone
fill 236 285 303 236 285 308 minecraft:chiseled_sandstone
fill 236 285 315 236 285 316 minecraft:chiseled_sandstone
fill 237 285 316 240 285 316 minecraft:chiseled_sandstone
fill 240 285 276 245 285 276 minecraft:chiseled_sandstone
fill 241 285 277 247 285 280 minecraft:cut_sandstone
setblock 244 285 275 minecraft:smooth_sandstone
fill 245 285 286 245 285 306 minecraft:sandstone
fill 246 285 276 247 285 276 minecraft:cut_sandstone
fill 246 285 285 266 285 285 minecraft:sandstone
fill 246 285 287 246 285 305 minecraft:sandstone
fill 246 285 307 266 285 307 minecraft:sandstone
fill 247 285 286 265 285 286 minecraft:sandstone
fill 247 285 288 247 285 304 minecraft:sandstone
fill 247 285 306 265 285 306 minecraft:sandstone
fill 247 285 316 252 285 316 minecraft:chiseled_sandstone
fill 248 285 287 264 285 287 minecraft:sandstone
fill 248 285 289 248 285 303 minecraft:sandstone
fill 248 285 305 264 285 305 minecraft:sandstone
fill 249 285 288 263 285 288 minecraft:sandstone
fill 249 285 290 249 285 302 minecraft:sandstone
fill 249 285 304 263 285 304 minecraft:sandstone
fill 250 285 289 262 285 289 minecraft:sandstone
fill 250 285 291 250 285 301 minecraft:sandstone
fill 250 285 303 262 285 303 minecraft:sandstone
fill 251 285 290 261 285 290 minecraft:sandstone
fill 251 285 292 251 285 300 minecraft:sandstone
fill 251 285 302 261 285 302 minecraft:sandstone
fill 252 285 275 252 308 275 minecraft:smooth_sandstone
fill 252 285 276 257 285 276 minecraft:chiseled_sandstone
fill 252 285 291 260 285 291 minecraft:sandstone
fill 252 285 293 252 285 299 minecraft:sandstone
fill 252 285 301 260 285 301 minecraft:sandstone
fill 253 285 292 259 285 292 minecraft:sandstone
fill 253 285 294 253 285 298 minecraft:sandstone
fill 253 285 300 259 285 300 minecraft:sandstone
fill 253 285 317 253 308 317 minecraft:smooth_sandstone
fill 254 285 293 255 285 293 minecraft:sandstone
fill 254 285 295 254 285 297 minecraft:sandstone
fill 254 285 299 258 285 299 minecraft:sandstone
setblock 255 285 296 minecraft:sandstone
fill 255 285 298 257 285 298 minecraft:sandstone
setblock 256 285 297 minecraft:sandstone
fill 257 285 293 258 285 293 minecraft:sandstone
fill 257 285 296 267 285 296 minecraft:sandstone
fill 258 285 295 267 285 295 minecraft:sandstone
fill 258 285 297 267 285 297 minecraft:sandstone
fill 259 285 294 267 285 294 minecraft:sandstone
fill 259 285 298 267 285 298 minecraft:sandstone
fill 259 285 316 264 285 316 minecraft:chiseled_sandstone
fill 260 285 293 267 285 293 minecraft:sandstone
fill 260 285 299 267 285 299 minecraft:sandstone
fill 261 285 292 267 285 292 minecraft:sandstone
fill 261 285 300 267 285 300 minecraft:sandstone
fill 262 285 291 267 285 291 minecraft:sandstone
fill 262 285 301 267 285 301 minecraft:sandstone
fill 263 285 290 267 285 290 minecraft:sandstone
fill 263 285 302 267 285 302 minecraft:sandstone
fill 264 285 276 269 285 276 minecraft:chiseled_sandstone
fill 264 285 289 267 285 289 minecraft:sandstone
fill 264 285 303 267 285 303 minecraft:sandstone
fill 265 285 288 267 285 288 minecraft:sandstone
fill 265 285 304 267 285 304 minecraft:sandstone
fill 266 285 287 267 285 287 minecraft:sandstone
fill 266 285 305 267 285 305 minecraft:sandstone
setblock 267 285 286 minecraft:sandstone
setblock 267 285 306 minecraft:sandstone
fill 271 285 316 276 285 316 minecraft:chiseled_sandstone
fill 272 285 283 275 285 295 minecraft:cut_sandstone
fill 276 285 276 276 285 281 minecraft:chiseled_sandstone
fill 276 285 283 276 285 287 minecraft:cut_sandstone
fill 276 285 288 276 285 293 minecraft:chiseled_sandstone
fill 276 285 294 276 285 295 minecraft:cut_sandstone
fill 276 285 300 276 285 305 minecraft:chiseled_sandstone
fill 276 285 312 276 285 315 minecraft:chiseled_sandstone
setblock 277 285 278 minecraft:smooth_sandstone
setblock 277 285 315 minecraft:smooth_sandstone
fill 235 286 276 235 288 276 minecraft:smooth_sandstone
fill 235 286 281 235 291 284 minecraft:glowstone
fill 235 286 293 235 291 296 minecraft:glowstone
fill 235 286 305 235 291 308 minecraft:glowstone
fill 235 286 317 238 291 317 minecraft:glowstone
setblock 238 286 278 minecraft:light[level=12]
setblock 238 286 285 minecraft:light[level=12]
setblock 238 286 292 minecraft:light[level=12]
setblock 238 286 299 minecraft:light[level=12]
setblock 238 286 306 minecraft:light[level=12]
setblock 238 286 313 minecraft:light[level=12]
fill 241 286 276 241 300 276 minecraft:cut_sandstone
setblock 241 286 277 minecraft:glowstone
fill 241 286 278 241 300 278 minecraft:cut_sandstone
setblock 241 286 279 minecraft:glowstone
fill 241 286 280 241 300 280 minecraft:cut_sandstone
fill 242 286 275 242 286 276 minecraft:glowstone
fill 242 286 277 242 300 277 minecraft:cut_sandstone
setblock 242 286 278 minecraft:glowstone
fill 242 286 279 242 300 279 minecraft:cut_sandstone
setblock 242 286 280 minecraft:glowstone
fill 243 286 275 245 291 275 minecraft:glowstone
fill 243 286 276 243 300 276 minecraft:cut_sandstone
setblock 243 286 277 minecraft:glowstone
fill 243 286 278 243 300 278 minecraft:cut_sandstone
setblock 243 286 279 minecraft:glowstone
fill 243 286 280 243 300 280 minecraft:cut_sandstone
setblock 244 286 276 minecraft:glowstone
fill 244 286 277 244 300 277 minecraft:cut_sandstone
setblock 244 286 278 minecraft:glowstone
fill 244 286 279 244 300 279 minecraft:cut_sandstone
setblock 244 286 280 minecraft:glowstone
fill 245 286 276 245 300 276 minecraft:cut_sandstone
setblock 245 286 277 minecraft:glowstone
fill 245 286 278 245 300 278 minecraft:cut_sandstone
setblock 245 286 279 minecraft:glowstone
fill 245 286 280 245 300 280 minecraft:cut_sandstone
setblock 245 286 285 minecraft:light[level=12]
setblock 245 286 292 minecraft:light[level=12]
setblock 245 286 299 minecraft:light[level=12]
setblock 245 286 306 minecraft:light[level=12]
setblock 245 286 313 minecraft:light[level=12]
setblock 246 286 276 minecraft:glowstone
fill 246 286 277 246 300 277 minecraft:cut_sandstone
setblock 246 286 278 minecraft:glowstone
fill 246 286 279 246 300 279 minecraft:cut_sandstone
setblock 246 286 280 minecraft:glowstone
fill 247 286 276 249 300 276 minecraft:cut_sandstone
setblock 247 286 277 minecraft:glowstone
fill 247 286 278 247 300 278 minecraft:cut_sandstone
setblock 247 286 279 minecraft:glowstone
fill 247 286 280 247 300 280 minecraft:cut_sandstone
fill 247 286 288 247 286 304 minecraft:smooth_sandstone
fill 247 286 317 250 291 317 minecraft:glowstone
fill 248 286 287 264 286 287 minecraft:smooth_sandstone
fill 248 286 289 248 286 303 minecraft:smooth_sandstone
fill 248 286 305 264 286 305 minecraft:smooth_sandstone
fill 249 286 288 263 286 288 minecraft:smooth_sandstone
fill 249 286 290 249 286 302 minecraft:smooth_sandstone
fill 249 286 304 263 286 304 minecraft:smooth_sandstone
fill 250 286 289 262 286 289 minecraft:smooth_sandstone
fill 250 286 291 250 286 301 minecraft:smooth_sandstone
fill 250 286 303 262 286 303 minecraft:smooth_sandstone
fill 251 286 290 261 286 290 minecraft:smooth_sandstone
fill 251 286 292 251 286 300 minecraft:smooth_sandstone
fill 251 286 302 261 286 302 minecraft:smooth_sandstone
setblock 252 286 278 minecraft:light[level=12]
setblock 252 286 285 minecraft:light[level=12]
fill 252 286 291 260 286 291 minecraft:smooth_sandstone
fill 252 286 293 252 286 299 minecraft:smooth_sandstone
fill 252 286 301 260 286 301 minecraft:smooth_sandstone
setblock 252 286 306 minecraft:light[level=12]
setblock 252 286 313 minecraft:light[level=12]
fill 253 286 292 259 286 292 minecraft:smooth_sandstone
fill 253 286 294 253 286 298 minecraft:smooth_sandstone
fill 253 286 300 259 286 300 minecraft:smooth_sandstone
fill 254 286 275 257 291 275 minecraft:glowstone
fill 254 286 293 255 286 293 minecraft:smooth_sandstone
fill 254 286 295 254 286 297 minecraft:smooth_sandstone
fill 254 286 299 258 286 299 minecraft:smooth_sandstone
setblock 255 286 296 minecraft:smooth_sandstone
fill 255 286 298 257 286 298 minecraft:smooth_sandstone
setblock 256 286 297 minecraft:smooth_sandstone
fill 257 286 293 258 286 293 minecraft:smooth_sandstone
fill 257 286 296 265 286 296 minecraft:smooth_sandstone
fill 258 286 295 265 286 295 minecraft:smooth_sandstone
fill 258 286 297 265 286 297 minecraft:smooth_sandstone
setblock 259 286 278 minecraft:light[level=12]
setblock 259 286 285 minecraft:light[level=12]
fill 259 286 294 265 286 294 minecraft:smooth_sandstone
fill 259 286 298 265 286 298 minecraft:smooth_sandstone
setblock 259 286 306 minecraft:light[level=12]
setblock 259 286 313 minecraft:light[level=12]
fill 259 286 317 262 291 317 minecraft:glowstone
fill 260 286 293 265 286 293 minecraft:smooth_sandstone
fill 260 286 299 265 286 299 minecraft:smooth_sandstone
fill 261 286 292 265 286 292 minecraft:smooth_sandstone
fill 261 286 300 265 286 300 minecraft:smooth_sandstone
fill 262 286 291 265 286 291 minecraft:smooth_sandstone
fill 262 286 301 265 286 301 minecraft:smooth_sandstone
fill 263 286 290 265 286 290 minecraft:smooth_sandstone
fill 263 286 302 265 286 302 minecraft:smooth_sandstone
fill 264 286 289 265 286 289 minecraft:smooth_sandstone
fill 264 286 303 265 286 303 minecraft:smooth_sandstone
setblock 265 286 288 minecraft:smooth_sandstone
setblock 265 286 304 minecraft:smooth_sandstone
fill 266 286 275 269 291 275 minecraft:glowstone
setblock 266 286 278 minecraft:light[level=12]
setblock 266 286 285 minecraft:light[level=12]
setblock 266 286 292 minecraft:light[level=12]
setblock 266 286 299 minecraft:light[level=12]
setblock 266 286 306 minecraft:light[level=12]
setblock 266 286 313 minecraft:light[level=12]
fill 271 286 317 274 291 317 minecraft:glowstone
fill 272 286 283 272 296 283 minecraft:cut_sandstone
setblock 272 286 284 minecraft:glowstone
fill 272 286 285 272 296 285 minecraft:cut_sandstone
setblock 272 286 286 minecraft:glowstone
fill 272 286 287 272 296 287 minecraft:cut_sandstone
setblock 272 286 288 minecraft:glowstone
fill 272 286 289 272 296 289 minecraft:cut_sandstone
setblock 272 286 290 minecraft:glowstone
fill 272 286 291 272 296 291 minecraft:cut_sandstone
setblock 272 286 292 minecraft:glowstone
fill 272 286 293 272 296 293 minecraft:cut_sandstone
setblock 272 286 294 minecraft:glowstone
fill 272 286 295 272 296 295 minecraft:cut_sandstone
setblock 273 286 278 minecraft:light[level=12]
setblock 273 286 283 minecraft:glowstone
fill 273 286 284 273 296 284 minecraft:cut_sandstone
setblock 273 286 285 minecraft:glowstone
fill 273 286 286 273 296 286 minecraft:cut_sandstone
setblock 273 286 287 minecraft:glowstone
fill 273 286 288 273 296 288 minecraft:cut_sandstone
setblock 273 286 289 minecraft:glowstone
fill 273 286 290 273 296 290 minecraft:cut_sandstone
setblock 273 286 291 minecraft:glowstone
fill 273 286 292 273 296 292 minecraft:cut_sandstone
setblock 273 286 293 minecraft:glowstone
fill 273 286 294 273 296 294 minecraft:cut_sandstone
setblock 273 286 295 minecraft:glowstone
setblock 273 286 299 minecraft:light[level=12]
setblock 273 286 306 minecraft:light[level=12]
fill 274 286 283 274 296 283 minecraft:cut_sandstone
setblock 274 286 284 minecraft:glowstone
fill 274 286 285 274 296 285 minecraft:cut_sandstone
setblock 274 286 286 minecraft:glowstone
fill 274 286 287 274 296 287 minecraft:cut_sandstone
setblock 274 286 288 minecraft:glowstone
fill 274 286 289 274 296 289 minecraft:cut_sandstone
setblock 274 286 290 minecraft:glowstone
fill 274 286 291 274 296 291 minecraft:cut_sandstone
setblock 274 286 292 minecraft:glowstone
fill 274 286 293 274 296 293 minecraft:cut_sandstone
setblock 274 286 294 minecraft:glowstone
fill 274 286 295 274 296 295 minecraft:cut_sandstone
setblock 275 286 283 minecraft:glowstone
fill 275 286 284 275 296 284 minecraft:cut_sandstone
setblock 275 286 285 minecraft:glowstone
fill 275 286 286 275 296 286 minecraft:cut_sandstone
setblock 275 286 287 minecraft:glowstone
fill 275 286 288 275 296 288 minecraft:cut_sandstone
setblock 275 286 289 minecraft:glowstone
fill 275 286 290 275 296 290 minecraft:cut_sandstone
setblock 275 286 291 minecraft:glowstone
fill 275 286 292 275 296 292 minecraft:cut_sandstone
setblock 275 286 293 minecraft:glowstone
fill 275 286 294 275 296 294 minecraft:cut_sandstone
setblock 275 286 295 minecraft:glowstone
fill 276 286 283 276 296 283 minecraft:cut_sandstone
setblock 276 286 284 minecraft:glowstone
fill 276 286 285 276 300 285 minecraft:cut_sandstone
setblock 276 286 286 minecraft:glowstone
fill 276 286 287 276 296 287 minecraft:cut_sandstone
fill 276 286 288 277 286 288 minecraft:glowstone
fill 276 286 289 276 296 289 minecraft:cut_sandstone
fill 276 286 290 277 286 290 minecraft:glowstone
fill 276 286 291 276 296 291 minecraft:cut_sandstone
setblock 276 286 292 minecraft:glowstone
fill 276 286 293 276 296 293 minecraft:cut_sandstone
setblock 276 286 294 minecraft:glowstone
fill 276 286 295 276 296 295 minecraft:cut_sandstone
fill 277 286 276 277 291 279 minecraft:glowstone
fill 277 286 289 277 292 289 minecraft:glowstone
fill 277 286 291 277 291 291 minecraft:glowstone
fill 277 286 300 277 291 303 minecraft:glowstone
setblock 277 286 308 minecraft:black_terracotta
fill 277 286 312 277 291 315 minecraft:glowstone
fill 241 287 277 241 288 277 minecraft:cut_sandstone
fill 241 287 279 241 288 279 minecraft:cut_sandstone
fill 242 287 275 242 291 275 minecraft:glowstone
fill 242 287 276 242 288 276 minecraft:cut_sandstone
fill 242 287 278 242 288 278 minecraft:cut_sandstone
fill 242 287 280 242 288 280 minecraft:cut_sandstone
fill 243 287 277 243 288 277 minecraft:cut_sandstone
fill 243 287 279 243 288 279 minecraft:cut_sandstone
fill 244 287 276 244 288 276 minecraft:cut_sandstone
fill 244 287 278 244 288 278 minecraft:cut_sandstone
fill 244 287 280 244 288 280 minecraft:cut_sandstone
fill 245 287 277 245 288 277 minecraft:cut_sandstone
fill 245 287 279 245 288 279 minecraft:cut_sandstone
fill 246 287 276 246 288 276 minecraft:cut_sandstone
fill 246 287 278 246 288 278 minecraft:cut_sandstone
fill 246 287 280 246 288 280 minecraft:cut_sandstone
fill 247 287 277 247 288 277 minecraft:cut_sandstone
fill 247 287 279 247 288 279 minecraft:cut_sandstone
fill 248 287 289 248 287 303 minecraft:sandstone
fill 249 287 288 263 287 288 minecraft:sandstone
fill 249 287 290 249 287 302 minecraft:sandstone
fill 249 287 304 263 287 304 minecraft:sandstone
fill 250 287 289 262 287 289 minecraft:sandstone
fill 250 287 291 250 287 301 minecraft:sandstone
fill 250 287 303 262 287 303 minecraft:sandstone
fill 251 287 290 261 287 290 minecraft:sandstone
fill 251 287 292 251 287 300 minecraft:sandstone
fill 251 287 302 261 287 302 minecraft:sandstone
fill 252 287 291 260 287 291 minecraft:sandstone
fill 252 287 293 252 287 299 minecraft:sandstone
fill 252 287 301 260 287 301 minecraft:sandstone
fill 253 287 292 259 287 292 minecraft:sandstone
fill 253 287 294 253 287 298 minecraft:sandstone
fill 253 287 300 259 287 300 minecraft:sandstone
fill 254 287 293 255 287 293 minecraft:sandstone
fill 254 287 295 254 287 297 minecraft:sandstone
fill 254 287 299 258 287 299 minecraft:sandstone
setblock 255 287 296 minecraft:sandstone
fill 255 287 298 257 287 298 minecraft:sandstone
setblock 256 287 297 minecraft:sandstone
fill 257 287 293 258 287 293 minecraft:sandstone
fill 257 287 296 264 287 296 minecraft:sandstone
fill 258 287 295 264 287 295 minecraft:sandstone
fill 258 287 297 264 287 297 minecraft:sandstone
fill 259 287 294 264 287 294 minecraft:sandstone
fill 259 287 298 264 287 298 minecraft:sandstone
fill 260 287 293 264 287 293 minecraft:sandstone
fill 260 287 299 264 287 299 minecraft:sandstone
fill 261 287 292 264 287 292 minecraft:sandstone
fill 261 287 300 264 287 300 minecraft:sandstone
fill 262 287 291 264 287 291 minecraft:sandstone
fill 262 287 301 264 287 301 minecraft:sandstone
fill 263 287 290 264 287 290 minecraft:sandstone
fill 263 287 302 264 287 302 minecraft:sandstone
setblock 264 287 289 minecraft:sandstone
setblock 264 287 303 minecraft:sandstone
fill 272 287 284 272 288 284 minecraft:cut_sandstone
fill 272 287 286 272 288 286 minecraft:cut_sandstone
fill 272 287 288 272 288 288 minecraft:cut_sandstone
fill 272 287 290 272 288 290 minecraft:cut_sandstone
fill 272 287 292 272 288 292 minecraft:cut_sandstone
fill 272 287 294 272 288 294 minecraft:cut_sandstone
fill 273 287 283 273 288 283 minecraft:cut_sandstone
fill 273 287 285 273 288 285 minecraft:cut_sandstone
fill 273 287 287 273 288 287 minecraft:cut_sandstone
fill 273 287 289 273 288 289 minecraft:cut_sandstone
fill 273 287 291 273 288 291 minecraft:cut_sandstone
fill 273 287 293 273 288 293 minecraft:cut_sandstone
fill 273 287 295 273 288 295 minecraft:cut_sandstone
fill 274 287 284 274 288 284 minecraft:cut_sandstone
fill 274 287 286 274 288 286 minecraft:cut_sandstone
fill 274 287 288 274 288 288 minecraft:cut_sandstone
fill 274 287 290 274 288 290 minecraft:cut_sandstone
fill 274 287 292 274 288 292 minecraft:cut_sandstone
fill 274 287 294 274 288 294 minecraft:cut_sandstone
fill 275 287 283 275 288 283 minecraft:cut_sandstone
fill 275 287 285 275 288 285 minecraft:cut_sandstone
fill 275 287 287 275 288 287 minecraft:cut_sandstone
fill 275 287 289 275 288 289 minecraft:cut_sandstone
fill 275 287 291 275 288 291 minecraft:cut_sandstone
fill 275 287 293 275 288 293 minecraft:cut_sandstone
fill 275 287 295 275 288 295 minecraft:cut_sandstone
fill 276 287 284 276 288 284 minecraft:cut_sandstone
fill 276 287 286 276 288 286 minecraft:cut_sandstone
fill 276 287 288 276 288 288 minecraft:cut_sandstone
fill 276 287 290 276 288 290 minecraft:cut_sandstone
fill 276 287 292 276 288 292 minecraft:cut_sandstone
fill 276 287 294 276 288 294 minecraft:cut_sandstone
fill 277 287 288 277 291 288 minecraft:glowstone
fill 277 287 290 277 292 290 minecraft:glowstone
fill 277 287 308 277 308 308 minecraft:smooth_sandstone
fill 249 288 290 249 288 302 minecraft:smooth_sandstone
fill 250 288 289 262 288 289 minecraft:smooth_sandstone
fill 250 288 291 250 288 301 minecraft:smooth_sandstone
fill 250 288 303 262 288 303 minecraft:smooth_sandstone
fill 251 288 290 261 288 290 minecraft:smooth_sandstone
fill 251 288 292 251 288 300 minecraft:smooth_sandstone
fill 251 288 302 261 288 302 minecraft:smooth_sandstone
fill 252 288 291 260 288 291 minecraft:smooth_sandstone
fill 252 288 293 252 288 299 minecraft:smooth_sandstone
fill 252 288 301 260 288 301 minecraft:smooth_sandstone
fill 253 288 292 259 288 292 minecraft:smooth_sandstone
fill 253 288 294 253 288 298 minecraft:smooth_sandstone
fill 253 288 300 259 288 300 minecraft:smooth_sandstone
fill 254 288 293 255 288 293 minecraft:smooth_sandstone
fill 254 288 295 254 288 297 minecraft:smooth_sandstone
fill 254 288 299 258 288 299 minecraft:smooth_sandstone
setblock 255 288 296 minecraft:smooth_sandstone
fill 255 288 298 257 288 298 minecraft:smooth_sandstone
setblock 256 288 297 minecraft:smooth_sandstone
fill 257 288 293 258 288 293 minecraft:smooth_sandstone
fill 257 288 296 263 288 296 minecraft:smooth_sandstone
fill 258 288 295 263 288 295 minecraft:smooth_sandstone
fill 258 288 297 263 288 297 minecraft:smooth_sandstone
fill 259 288 294 263 288 294 minecraft:smooth_sandstone
fill 259 288 298 263 288 298 minecraft:smooth_sandstone
fill 260 288 293 263 288 293 minecraft:smooth_sandstone
fill 260 288 299 263 288 299 minecraft:smooth_sandstone
fill 261 288 292 263 288 292 minecraft:smooth_sandstone
fill 261 288 300 263 288 300 minecraft:smooth_sandstone
fill 262 288 291 263 288 291 minecraft:smooth_sandstone
fill 262 288 301 263 288 301 minecraft:smooth_sandstone
setblock 263 288 290 minecraft:smooth_sandstone
setblock 263 288 302 minecraft:smooth_sandstone
setblock 277 288 306 minecraft:orange_terracotta
setblock 235 289 276 minecraft:black_terracotta
setblock 241 289 277 minecraft:glowstone
setblock 241 289 279 minecraft:glowstone
setblock 242 289 276 minecraft:glowstone
setblock 242 289 278 minecraft:glowstone
setblock 242 289 280 minecraft:glowstone
setblock 243 289 277 minecraft:glowstone
setblock 243 289 279 minecraft:glowstone
setblock 244 289 276 minecraft:glowstone
setblock 244 289 278 minecraft:glowstone
setblock 244 289 280 minecraft:glowstone
setblock 245 289 277 minecraft:glowstone
setblock 245 289 279 minecraft:glowstone
setblock 246 289 276 minecraft:glowstone
setblock 246 289 278 minecraft:glowstone
setblock 246 289 280 minecraft:glowstone
setblock 247 289 277 minecraft:glowstone
setblock 247 289 279 minecraft:glowstone
fill 251 289 292 251 289 300 minecraft:sandstone
fill 252 289 291 260 289 291 minecraft:sandstone
fill 252 289 293 252 289 299 minecraft:sandstone
fill 252 289 301 260 289 301 minecraft:sandstone
fill 253 289 292 259 289 292 minecraft:sandstone
fill 253 289 294 253 289 298 minecraft:sandstone
fill 253 289 300 259 289 300 minecraft:sandstone
fill 254 289 293 255 289 293 minecraft:sandstone
fill 254 289 295 254 289 297 minecraft:sandstone
fill 254 289 299 258 289 299 minecraft:sandstone
setblock 255 289 296 minecraft:sandstone
fill 255 289 298 257 289 298 minecraft:sandstone
setblock 256 289 297 minecraft:sandstone
fill 257 289 293 258 289 293 minecraft:sandstone
fill 257 289 296 261 289 296 minecraft:sandstone
fill 258 289 295 261 289 295 minecraft:sandstone
fill 258 289 297 261 289 297 minecraft:sandstone
fill 259 289 294 261 289 294 minecraft:sandstone
fill 259 289 298 261 289 298 minecraft:sandstone
fill 260 289 293 261 289 293 minecraft:sandstone
fill 260 289 299 261 289 299 minecraft:sandstone
setblock 261 289 292 minecraft:sandstone
setblock 261 289 300 minecraft:sandstone
setblock 272 289 284 minecraft:glowstone
setblock 272 289 286 minecraft:glowstone
setblock 272 289 288 minecraft:glowstone
setblock 272 289 290 minecraft:glowstone
setblock 272 289 292 minecraft:glowstone
setblock 272 289 294 minecraft:glowstone
setblock 273 289 283 minecraft:glowstone
setblock 273 289 285 minecraft:glowstone
setblock 273 289 287 minecraft:glowstone
setblock 273 289 289 minecraft:glowstone
setblock 273 289 291 minecraft:glowstone
setblock 273 289 293 minecraft:glowstone
setblock 273 289 295 minecraft:glowstone
setblock 274 289 284 minecraft:glowstone
setblock 274 289 286 minecraft:glowstone
setblock 274 289 288 minecraft:glowstone
setblock 274 289 290 minecraft:glowstone
setblock 274 289 292 minecraft:glowstone
setblock 274 289 294 minecraft:glowstone
setblock 275 289 283 minecraft:glowstone
setblock 275 289 285 minecraft:glowstone
setblock 275 289 287 minecraft:glowstone
setblock 275 289 289 minecraft:glowstone
setblock 275 289 291 minecraft:glowstone
setblock 275 289 293 minecraft:glowstone
setblock 275 289 295 minecraft:glowstone
setblock 276 289 284 minecraft:glowstone
setblock 276 289 286 minecraft:glowstone
setblock 276 289 288 minecraft:glowstone
setblock 276 289 290 minecraft:glowstone
setblock 276 289 292 minecraft:glowstone
setblock 276 289 294 minecraft:glowstone
setblock 277 289 280 minecraft:black_terracotta
fill 277 289 306 277 308 306 minecraft:smooth_sandstone
fill 235 290 276 235 308 276 minecraft:smooth_sandstone
setblock 238 290 278 minecraft:light[level=15]
setblock 238 290 286 minecraft:light[level=15]
setblock 238 290 294 minecraft:light[level=15]
setblock 238 290 302 minecraft:light[level=15]
setblock 238 290 310 minecraft:light[level=15]
fill 241 290 277 241 291 277 minecraft:cut_sandstone
fill 241 290 279 241 291 279 minecraft:cut_sandstone
fill 242 290 276 242 291 276 minecraft:cut_sandstone
fill 242 290 278 242 291 278 minecraft:cut_sandstone
fill 242 290 280 242 291 280 minecraft:cut_sandstone
fill 243 290 277 243 291 277 minecraft:cut_sandstone
fill 243 290 279 243 291 279 minecraft:cut_sandstone
fill 244 290 276 244 291 276 minecraft:cut_sandstone
fill 244 290 278 244 291 278 minecraft:cut_sandstone
fill 244 290 280 244 291 280 minecraft:cut_sandstone
fill 245 290 277 245 291 277 minecraft:cut_sandstone
fill 245 290 279 245 291 279 minecraft:cut_sandstone
fill 246 290 276 246 291 276 minecraft:cut_sandstone
fill 246 290 278 246 291 278 minecraft:cut_sandstone
fill 246 290 280 246 291 280 minecraft:cut_sandstone
setblock 246 290 286 minecraft:light[level=15]
setblock 246 290 294 minecraft:light[level=15]
setblock 246 290 302 minecraft:light[level=15]
setblock 246 290 310 minecraft:light[level=15]
fill 247 290 277 247 291 277 minecraft:cut_sandstone
fill 247 290 279 247 291 279 minecraft:cut_sandstone
fill 252 290 293 252 290 299 minecraft:smooth_sandstone
fill 253 290 292 259 290 292 minecraft:smooth_sandstone
fill 253 290 294 253 290 298 minecraft:smooth_sandstone
fill 253 290 300 259 290 300 minecraft:smooth_sandstone
setblock 254 290 278 minecraft:light[level=15]
setblock 254 290 286 minecraft:light[level=15]
fill 254 290 293 255 290 293 minecraft:smooth_sandstone
fill 254 290 295 254 290 297 minecraft:smooth_sandstone
fill 254 290 299 258 290 299 minecraft:smooth_sandstone
setblock 254 290 302 minecraft:light[level=15]
setblock 254 290 310 minecraft:light[level=15]
setblock 255 290 296 minecraft:smooth_sandstone
fill 255 290 298 257 290 298 minecraft:smooth_sandstone
setblock 256 290 297 minecraft:smooth_sandstone
fill 257 290 293 258 290 293 minecraft:smooth_sandstone
fill 257 290 296 260 290 296 minecraft:smooth_sandstone
fill 258 290 295 260 290 295 minecraft:smooth_sandstone
fill 258 290 297 260 290 297 minecraft:smooth_sandstone
fill 259 290 294 260 290 294 minecraft:smooth_sandstone
fill 259 290 298 260 290 298 minecraft:smooth_sandstone
setblock 260 290 293 minecraft:smooth_sandstone
setblock 260 290 299 minecraft:smooth_sandstone
setblock 262 290 278 minecraft:light[level=15]
setblock 262 290 286 minecraft:light[level=15]
setblock 262 290 294 minecraft:light[level=15]
setblock 262 290 302 minecraft:light[level=15]
setblock 262 290 310 minecraft:light[level=15]
setblock 270 290 278 minecraft:light[level=15]
setblock 270 290 286 minecraft:light[level=15]
setblock 270 290 294 minecraft:light[level=15]
setblock 270 290 302 minecraft:light[level=15]
setblock 270 290 310 minecraft:light[level=15]
fill 272 290 275 272 308 275 minecraft:smooth_sandstone
fill 272 290 284 272 291 284 minecraft:cut_sandstone
fill 272 290 286 272 291 286 minecraft:cut_sandstone
fill 272 290 288 272 291 288 minecraft:cut_sandstone
fill 272 290 290 272 291 290 minecraft:cut_sandstone
fill 272 290 292 272 291 292 minecraft:cut_sandstone
fill 272 290 294 272 291 294 minecraft:cut_sandstone
setblock 273 290 275 minecraft:black_terracotta
fill 273 290 283 273 291 283 minecraft:cut_sandstone
fill 273 290 285 273 291 285 minecraft:cut_sandstone
fill 273 290 287 273 291 287 minecraft:cut_sandstone
fill 273 290 289 273 291 289 minecraft:cut_sandstone
fill 273 290 291 273 291 291 minecraft:cut_sandstone
fill 273 290 293 273 291 293 minecraft:cut_sandstone
fill 273 290 295 273 291 295 minecraft:cut_sandstone
fill 274 290 284 274 291 284 minecraft:cut_sandstone
fill 274 290 286 274 291 286 minecraft:cut_sandstone
fill 274 290 288 274 291 288 minecraft:cut_sandstone
fill 274 290 290 274 291 290 minecraft:cut_sandstone
fill 274 290 292 274 291 292 minecraft:cut_sandstone
fill 274 290 294 274 291 294 minecraft:cut_sandstone
fill 275 290 283 275 291 283 minecraft:cut_sandstone
fill 275 290 285 275 291 285 minecraft:cut_sandstone
fill 275 290 287 275 291 287 minecraft:cut_sandstone
fill 275 290 289 275 291 289 minecraft:cut_sandstone
fill 275 290 291 275 291 291 minecraft:cut_sandstone
fill 275 290 293 275 291 293 minecraft:cut_sandstone
fill 275 290 295 275 291 295 minecraft:cut_sandstone
fill 276 290 284 276 291 284 minecraft:cut_sandstone
fill 276 290 286 276 291 286 minecraft:cut_sandstone
fill 276 290 288 276 291 288 minecraft:cut_sandstone
fill 276 290 290 276 291 290 minecraft:cut_sandstone
fill 276 290 292 276 291 292 minecraft:cut_sandstone
fill 276 290 294 276 291 294 minecraft:cut_sandstone
fill 277 290 280 277 304 280 minecraft:smooth_sandstone
fill 253 291 294 253 291 298 minecraft:sandstone
fill 254 291 293 255 291 293 minecraft:sandstone
fill 254 291 295 254 291 297 minecraft:sandstone
fill 254 291 299 258 291 299 minecraft:sandstone
setblock 255 291 296 minecraft:sandstone
fill 255 291 298 257 291 298 minecraft:sandstone
setblock 256 291 297 minecraft:sandstone
fill 257 291 293 258 291 293 minecraft:sandstone
fill 257 291 296 259 291 296 minecraft:sandstone
fill 258 291 295 259 291 295 minecraft:sandstone
fill 258 291 297 259 291 297 minecraft:sandstone
setblock 259 291 294 minecraft:sandstone
setblock 259 291 298 minecraft:sandstone
fill 270 291 310 270 291 311 minecraft:chiseled_sandstone
setblock 270 291 313 minecraft:chiseled_sandstone
fill 271 291 310 273 291 310 minecraft:chiseled_sandstone
fill 271 291 314 273 291 314 minecraft:chiseled_sandstone
fill 273 291 275 273 308 275 minecraft:smooth_sandstone
fill 274 291 311 274 291 313 minecraft:chiseled_sandstone
fill 235 292 281 235 308 281 minecraft:smooth_sandstone
fill 235 292 282 235 292 283 minecraft:glowstone
fill 235 292 284 235 308 284 minecraft:smooth_sandstone
fill 235 292 293 235 308 293 minecraft:smooth_sandstone
fill 235 292 294 235 292 295 minecraft:glowstone
fill 235 292 296 235 308 296 minecraft:smooth_sandstone
fill 235 292 305 235 308 305 minecraft:smooth_sandstone
fill 235 292 306 235 292 307 minecraft:glowstone
fill 235 292 308 235 308 308 minecraft:smooth_sandstone
fill 235 292 317 235 308 317 minecraft:smooth_sandstone
fill 236 292 317 237 292 317 minecraft:glowstone
setblock 238 292 278 minecraft:light[level=12]
setblock 238 292 285 minecraft:light[level=12]
setblock 238 292 292 minecraft:light[level=12]
setblock 238 292 299 minecraft:light[level=12]
setblock 238 292 306 minecraft:light[level=12]
setblock 238 292 313 minecraft:light[level=12]
fill 238 292 317 238 308 317 minecraft:smooth_sandstone
setblock 241 292 277 minecraft:glowstone
setblock 241 292 279 minecraft:glowstone
setblock 242 292 275 minecraft:smooth_sandstone
setblock 242 292 276 minecraft:glowstone
setblock 242 292 278 minecraft:glowstone
setblock 242 292 280 minecraft:glowstone
fill 243 292 275 244 292 275 minecraft:glowstone
setblock 243 292 277 minecraft:glowstone
setblock 243 292 279 minecraft:glowstone
setblock 244 292 276 minecraft:glowstone
setblock 244 292 278 minecraft:glowstone
setblock 244 292 280 minecraft:glowstone
fill 245 292 275 245 297 275 minecraft:smooth_sandstone
setblock 245 292 277 minecraft:glowstone
setblock 245 292 279 minecraft:glowstone
setblock 245 292 285 minecraft:light[level=12]
setblock 245 292 292 minecraft:light[level=12]
setblock 245 292 299 minecraft:light[level=12]
setblock 245 292 306 minecraft:light[level=12]
setblock 245 292 313 minecraft:light[level=12]
setblock 246 292 276 minecraft:glowstone
setblock 246 292 278 minecraft:glowstone
setblock 246 292 280 minecraft:glowstone
setblock 247 292 277 minecraft:glowstone
setblock 247 292 279 minecraft:glowstone
fill 247 292 317 247 308 317 minecraft:smooth_sandstone
fill 248 292 317 249 292 317 minecraft:glowstone
fill 250 292 317 250 303 317 minecraft:smooth_sandstone
setblock 252 292 278 minecraft:light[level=12]
setblock 252 292 285 minecraft:light[level=12]
setblock 252 292 292 minecraft:light[level=12]
setblock 252 292 299 minecraft:light[level=12]
setblock 252 292 306 minecraft:light[level=12]
setblock 252 292 313 minecraft:light[level=12]
fill 254 292 275 254 296 275 minecraft:smooth_sandstone
fill 255 292 275 256 292 275 minecraft:glowstone
setblock 255 292 296 minecraft:smooth_sandstone
setblock 256 292 297 minecraft:smooth_sandstone
fill 257 292 275 257 308 275 minecraft:smooth_sandstone
setblock 257 292 296 minecraft:smooth_sandstone
setblock 259 292 278 minecraft:light[level=12]
setblock 259 292 285 minecraft:light[level=12]
setblock 259 292 292 minecraft:light[level=12]
setblock 259 292 299 minecraft:light[level=12]
setblock 259 292 306 minecraft:light[level=12]
setblock 259 292 313 minecraft:light[level=12]
fill 259 292 317 259 308 317 minecraft:smooth_sandstone
fill 260 292 317 261 292 317 minecraft:glowstone
fill 262 292 317 262 308 317 minecraft:smooth_sandstone
fill 266 292 275 266 308 275 minecraft:smooth_sandstone
setblock 266 292 278 minecraft:light[level=12]
setblock 266 292 285 minecraft:light[level=12]
setblock 266 292 292 minecraft:light[level=12]
setblock 266 292 299 minecraft:light[level=12]
setblock 266 292 306 minecraft:light[level=12]
setblock 266 292 313 minecraft:light[level=12]
fill 267 292 275 268 292 275 minecraft:glowstone
fill 269 292 275 269 308 275 minecraft:smooth_sandstone
fill 271 292 317 271 308 317 minecraft:smooth_sandstone
setblock 272 292 284 minecraft:glowstone
setblock 272 292 286 minecraft:glowstone
setblock 272 292 288 minecraft:glowstone
setblock 272 292 290 minecraft:glowstone
setblock 272 292 292 minecraft:glowstone
setblock 272 292 294 minecraft:glowstone
fill 272 292 317 273 292 317 minecraft:glowstone
setblock 273 292 278 minecraft:light[level=12]
setblock 273 292 283 minecraft:glowstone
setblock 273 292 285 minecraft:glowstone
setblock 273 292 287 minecraft:glowstone
setblock 273 292 289 minecraft:glowstone
setblock 273 292 291 minecraft:glowstone
setblock 273 292 293 minecraft:glowstone
setblock 273 292 295 minecraft:glowstone
setblock 273 292 299 minecraft:light[level=12]
setblock 273 292 306 minecraft:light[level=12]
setblock 274 292 284 minecraft:glowstone
setblock 274 292 286 minecraft:glowstone
setblock 274 292 288 minecraft:glowstone
setblock 274 292 290 minecraft:glowstone
setblock 274 292 292 minecraft:glowstone
setblock 274 292 294 minecraft:glowstone
fill 274 292 317 274 308 317 minecraft:smooth_sandstone
setblock 275 292 283 minecraft:glowstone
setblock 275 292 285 minecraft:glowstone
setblock 275 292 287 minecraft:glowstone
setblock 275 292 289 minecraft:glowstone
setblock 275 292 291 minecraft:glowstone
setblock 275 292 293 minecraft:glowstone
setblock 275 292 295 minecraft:glowstone
setblock 276 292 284 minecraft:glowstone
setblock 276 292 286 minecraft:glowstone
setblock 276 292 288 minecraft:glowstone
setblock 276 292 290 minecraft:glowstone
setblock 276 292 292 minecraft:glowstone
setblock 276 292 294 minecraft:glowstone
fill 277 292 276 277 308 276 minecraft:smooth_sandstone
fill 277 292 277 277 292 278 minecraft:glowstone
fill 277 292 279 277 308 279 minecraft:smooth_sandstone
fill 277 292 288 277 308 288 minecraft:smooth_sandstone
fill 277 292 291 277 308 291 minecraft:smooth_sandstone
fill 277 292 300 277 305 300 minecraft:smooth_sandstone
fill 277 292 301 277 292 302 minecraft:glowstone
fill 277 292 303 277 308 303 minecraft:smooth_sandstone
fill 277 292 312 277 308 312 minecraft:smooth_sandstone
fill 277 292 313 277 292 314 minecraft:glowstone
fill 277 292 315 277 308 315 minecraft:smooth_sandstone
setblock 235 293 279 minecraft:orange_terracotta
fill 235 293 282 235 308 283 minecraft:smooth_sandstone
setblock 235 293 288 minecraft:black_terracotta
fill 235 293 289 235 308 289 minecraft:smooth_sandstone
fill 235 293 294 235 295 295 minecraft:smooth_sandstone
fill 235 293 306 235 308 307 minecraft:smooth_sandstone
fill 236 293 317 237 308 317 minecraft:smooth_sandstone
fill 241 293 277 241 294 277 minecraft:cut_sandstone
fill 241 293 279 241 294 279 minecraft:cut_sandstone
setblock 242 293 275 minecraft:lapis_block
fill 242 293 276 242 294 276 minecraft:cut_sandstone
fill 242 293 278 242 294 278 minecraft:cut_sandstone
fill 242 293 280 242 294 280 minecraft:cut_sandstone
fill 243 293 275 244 294 275 minecraft:smooth_sandstone
fill 243 293 277 243 294 277 minecraft:cut_sandstone
fill 243 293 279 243 294 279 minecraft:cut_sandstone
fill 244 293 276 244 294 276 minecraft:cut_sandstone
fill 244 293 278 244 294 278 minecraft:cut_sandstone
fill 244 293 280 244 294 280 minecraft:cut_sandstone
fill 245 293 277 245 294 277 minecraft:cut_sandstone
fill 245 293 279 245 294 279 minecraft:cut_sandstone
fill 246 293 276 246 294 276 minecraft:cut_sandstone
fill 246 293 278 246 294 278 minecraft:cut_sandstone
fill 246 293 280 246 294 280 minecraft:cut_sandstone
fill 247 293 277 247 294 277 minecraft:cut_sandstone
fill 247 293 279 247 294 279 minecraft:cut_sandstone
fill 248 293 317 249 300 317 minecraft:smooth_sandstone
fill 251 293 282 251 294 282 minecraft:smooth_sandstone
fill 255 293 275 256 298 275 minecraft:smooth_sandstone
fill 260 293 317 261 308 317 minecraft:smooth_sandstone
fill 267 293 275 268 293 275 minecraft:smooth_sandstone
fill 272 293 284 272 294 284 minecraft:cut_sandstone
fill 272 293 286 272 294 286 minecraft:cut_sandstone
fill 272 293 288 272 294 288 minecraft:cut_sandstone
fill 272 293 290 272 294 290 minecraft:cut_sandstone
fill 272 293 292 272 294 292 minecraft:cut_sandstone
fill 272 293 294 272 294 294 minecraft:cut_sandstone
fill 272 293 317 273 299 317 minecraft:smooth_sandstone
fill 273 293 283 273 294 283 minecraft:cut_sandstone
fill 273 293 285 273 294 285 minecraft:cut_sandstone
fill 273 293 287 273 294 287 minecraft:cut_sandstone
fill 273 293 289 273 294 289 minecraft:cut_sandstone
fill 273 293 291 273 294 291 minecraft:cut_sandstone
fill 273 293 293 273 294 293 minecraft:cut_sandstone
fill 273 293 295 273 294 295 minecraft:cut_sandstone
fill 274 293 284 274 294 284 minecraft:cut_sandstone
fill 274 293 286 274 294 286 minecraft:cut_sandstone
fill 274 293 288 274 294 288 minecraft:cut_sandstone
fill 274 293 290 274 294 290 minecraft:cut_sandstone
fill 274 293 292 274 294 292 minecraft:cut_sandstone
fill 274 293 294 274 294 294 minecraft:cut_sandstone
fill 275 293 283 275 294 283 minecraft:cut_sandstone
fill 275 293 285 275 294 285 minecraft:cut_sandstone
fill 275 293 287 275 294 287 minecraft:cut_sandstone
fill 275 293 289 275 294 289 minecraft:cut_sandstone
fill 275 293 291 275 294 291 minecraft:cut_sandstone
fill 275 293 293 275 294 293 minecraft:cut_sandstone
fill 275 293 295 275 294 295 minecraft:cut_sandstone
fill 276 293 284 276 294 284 minecraft:cut_sandstone
fill 276 293 286 276 294 286 minecraft:cut_sandstone
fill 276 293 288 276 294 288 minecraft:cut_sandstone
fill 276 293 290 276 294 290 minecraft:cut_sandstone
fill 276 293 292 276 294 292 minecraft:cut_sandstone
fill 276 293 294 276 294 294 minecraft:cut_sandstone
fill 277 293 277 277 293 278 minecraft:smooth_sandstone
fill 277 293 289 277 308 290 minecraft:smooth_sandstone
setblock 277 293 297 minecraft:lapis_block
fill 277 293 301 277 308 301 minecraft:smooth_sandstone
setblock 277 293 302 minecraft:black_terracotta
setblock 277 293 313 minecraft:blue_terracotta
fill 277 293 314 277 308 314 minecraft:smooth_sandstone
setblock 235 294 278 minecraft:orange_terracotta
fill 235 294 279 235 308 279 minecraft:smooth_sandstone
fill 235 294 288 235 308 288 minecraft:smooth_sandstone
fill 242 294 275 242 308 275 minecraft:smooth_sandstone
setblock 267 294 275 minecraft:lapis_block
setblock 267 294 317 minecraft:blue_terracotta
fill 268 294 275 268 308 275 minecraft:smooth_sandstone
fill 277 294 277 277 299 277 minecraft:smooth_sandstone
setblock 277 294 278 minecraft:orange_terracotta
fill 277 294 297 277 308 297 minecraft:smooth_sandstone
fill 277 294 302 277 308 302 minecraft:smooth_sandstone
setblock 277 294 310 minecraft:black_terracotta
fill 277 294 313 277 303 313 minecraft:smooth_sandstone
fill 235 295 278 235 301 278 minecraft:smooth_sandstone
setblock 241 295 277 minecraft:glowstone
setblock 241 295 279 minecraft:glowstone
setblock 242 295 276 minecraft:glowstone
setblock 242 295 278 minecraft:glowstone
setblock 242 295 280 minecraft:glowstone
setblock 243 295 275 minecraft:blue_terracotta
setblock 243 295 277 minecraft:glowstone
setblock 243 295 279 minecraft:glowstone
fill 244 295 275 244 308 275 minecraft:smooth_sandstone
setblock 244 295 276 minecraft:glowstone
setblock 244 295 278 minecraft:glowstone
setblock 244 295 280 minecraft:glowstone
setblock 245 295 277 minecraft:glowstone
setblock 245 295 279 minecraft:glowstone
setblock 246 295 276 minecraft:glowstone
setblock 246 295 278 minecraft:glowstone
setblock 246 295 280 minecraft:glowstone
setblock 247 295 277 minecraft:glowstone
setblock 247 295 279 minecraft:glowstone
fill 267 295 275 267 308 275 minecraft:smooth_sandstone
fill 267 295 317 267 308 317 minecraft:smooth_sandstone
setblock 272 295 284 minecraft:glowstone
setblock 272 295 286 minecraft:glowstone
setblock 272 295 288 minecraft:glowstone
setblock 272 295 290 minecraft:glowstone
setblock 272 295 292 minecraft:glowstone
setblock 272 295 294 minecraft:glowstone
setblock 273 295 283 minecraft:glowstone
setblock 273 295 285 minecraft:glowstone
setblock 273 295 287 minecraft:glowstone
setblock 273 295 289 minecraft:glowstone
setblock 273 295 291 minecraft:glowstone
setblock 273 295 293 minecraft:glowstone
setblock 273 295 295 minecraft:glowstone
setblock 274 295 284 minecraft:glowstone
setblock 274 295 286 minecraft:glowstone
setblock 274 295 288 minecraft:glowstone
setblock 274 295 290 minecraft:glowstone
setblock 274 295 292 minecraft:glowstone
setblock 274 295 294 minecraft:glowstone
setblock 275 295 283 minecraft:glowstone
setblock 275 295 285 minecraft:glowstone
setblock 275 295 287 minecraft:glowstone
setblock 275 295 289 minecraft:glowstone
setblock 275 295 291 minecraft:glowstone
setblock 275 295 293 minecraft:glowstone
setblock 275 295 295 minecraft:glowstone
setblock 276 295 284 minecraft:glowstone
setblock 276 295 286 minecraft:glowstone
setblock 276 295 288 minecraft:glowstone
setblock 276 295 290 minecraft:glowstone
setblock 276 295 292 minecraft:glowstone
setblock 276 295 294 minecraft:glowstone
fill 277 295 278 277 308 278 minecraft:smooth_sandstone
fill 277 295 310 277 308 310 minecraft:smooth_sandstone
setblock 235 296 280 minecraft:black_terracotta
setblock 235 296 294 minecraft:orange_terracotta
fill 235 296 295 235 308 295 minecraft:smooth_sandstone
setblock 237 296 275 minecraft:blue_terracotta
setblock 240 296 275 minecraft:black_terracotta
fill 241 296 277 241 297 277 minecraft:cut_sandstone
fill 241 296 279 241 297 279 minecraft:cut_sandstone
fill 242 296 276 242 297 276 minecraft:cut_sandstone
fill 242 296 278 242 297 278 minecraft:cut_sandstone
fill 242 296 280 242 297 280 minecraft:cut_sandstone
fill 243 296 275 243 308 275 minecraft:smooth_sandstone
fill 243 296 277 243 297 277 minecraft:cut_sandstone
fill 243 296 279 243 297 279 minecraft:cut_sandstone
fill 244 296 276 244 297 276 minecraft:cut_sandstone
fill 244 296 278 244 297 278 minecraft:cut_sandstone
fill 244 296 280 244 297 280 minecraft:cut_sandstone
fill 245 296 277 245 297 277 minecraft:cut_sandstone
fill 245 296 279 245 297 279 minecraft:cut_sandstone
fill 246 296 276 246 297 276 minecraft:cut_sandstone
fill 246 296 278 246 297 278 minecraft:cut_sandstone
fill 246 296 280 246 297 280 minecraft:cut_sandstone
fill 247 296 277 247 297 277 minecraft:cut_sandstone
fill 247 296 279 247 297 279 minecraft:cut_sandstone
setblock 250 296 275 minecraft:blue_terracotta
setblock 255 296 317 minecraft:blue_terracotta
setblock 272 296 284 minecraft:cut_sandstone
setblock 272 296 286 minecraft:cut_sandstone
setblock 272 296 288 minecraft:cut_sandstone
setblock 272 296 290 minecraft:cut_sandstone
setblock 272 296 292 minecraft:cut_sandstone
setblock 272 296 294 minecraft:cut_sandstone
setblock 273 296 283 minecraft:cut_sandstone
setblock 273 296 285 minecraft:cut_sandstone
setblock 273 296 287 minecraft:cut_sandstone
setblock 273 296 289 minecraft:cut_sandstone
setblock 273 296 291 minecraft:cut_sandstone
setblock 273 296 293 minecraft:cut_sandstone
setblock 273 296 295 minecraft:cut_sandstone
setblock 274 296 284 minecraft:cut_sandstone
setblock 274 296 286 minecraft:cut_sandstone
setblock 274 296 288 minecraft:cut_sandstone
setblock 274 296 290 minecraft:cut_sandstone
setblock 274 296 292 minecraft:cut_sandstone
setblock 274 296 294 minecraft:cut_sandstone
setblock 275 296 283 minecraft:cut_sandstone
setblock 275 296 285 minecraft:cut_sandstone
setblock 275 296 287 minecraft:cut_sandstone
setblock 275 296 289 minecraft:cut_sandstone
setblock 275 296 291 minecraft:cut_sandstone
setblock 275 296 293 minecraft:cut_sandstone
setblock 275 296 295 minecraft:cut_sandstone
fill 276 296 284 276 300 284 minecraft:cut_sandstone
fill 276 296 286 276 300 286 minecraft:cut_sandstone
setblock 276 296 288 minecraft:cut_sandstone
setblock 276 296 290 minecraft:cut_sandstone
setblock 276 296 292 minecraft:cut_sandstone
setblock 276 296 294 minecraft:cut_sandstone
setblock 277 296 284 minecraft:orange_terracotta
fill 277 296 285 277 308 287 minecraft:smooth_sandstone
setblock 277 296 293 minecraft:black_terracotta
fill 235 297 280 235 303 280 minecraft:smooth_sandstone
fill 235 297 294 235 308 294 minecraft:smooth_sandstone
fill 235 297 298 235 308 298 minecraft:smooth_sandstone
setblock 235 297 299 minecraft:blue_terracotta
fill 237 297 275 237 308 275 minecraft:smooth_sandstone
fill 240 297 275 240 308 275 minecraft:smooth_sandstone
fill 250 297 275 250 304 275 minecraft:smooth_sandstone
setblock 254 297 275 minecraft:black_terracotta
fill 255 297 317 255 308 317 minecraft:smooth_sandstone
fill 273 297 284 275 297 294 minecraft:lapis_block
fill 277 297 284 277 308 284 minecraft:smooth_sandstone
setblock 277 297 293 minecraft:smooth_sandstone
fill 235 298 299 235 308 299 minecraft:smooth_sandstone
setblock 238 298 278 minecraft:light[level=15]
setblock 238 298 285 minecraft:light[level=12]
setblock 238 298 286 minecraft:light[level=15]
setblock 238 298 292 minecraft:light[level=12]
setblock 238 298 294 minecraft:light[level=15]
setblock 238 298 299 minecraft:light[level=12]
setblock 238 298 302 minecraft:light[level=15]
setblock 238 298 306 minecraft:light[level=12]
setblock 238 298 310 minecraft:light[level=15]
setblock 238 298 313 minecraft:light[level=12]
setblock 241 298 277 minecraft:glowstone
setblock 241 298 279 minecraft:glowstone
setblock 242 298 276 minecraft:glowstone
setblock 242 298 278 minecraft:glowstone
setblock 242 298 280 minecraft:glowstone
setblock 243 298 277 minecraft:glowstone
setblock 243 298 279 minecraft:glowstone
setblock 244 298 276 minecraft:glowstone
setblock 244 298 278 minecraft:glowstone
setblock 244 298 280 minecraft:glowstone
setblock 245 298 275 minecraft:blue_terracotta
setblock 245 298 277 minecraft:glowstone
setblock 245 298 279 minecraft:glowstone
setblock 245 298 285 minecraft:light[level=12]
setblock 245 298 292 minecraft:light[level=12]
setblock 245 298 299 minecraft:light[level=12]
setblock 245 298 306 minecraft:light[level=12]
setblock 245 298 313 minecraft:light[level=12]
setblock 246 298 276 minecraft:glowstone
setblock 246 298 278 minecraft:glowstone
setblock 246 298 280 minecraft:glowstone
setblock 246 298 286 minecraft:light[level=15]
setblock 246 298 294 minecraft:light[level=15]
setblock 246 298 302 minecraft:light[level=15]
setblock 246 298 310 minecraft:light[level=15]
setblock 247 298 277 minecraft:glowstone
setblock 247 298 279 minecraft:glowstone
fill 247 298 307 248 299 308 minecraft:smooth_sandstone
fill 251 298 309 255 299 313 minecraft:chiseled_sandstone
setblock 252 298 278 minecraft:light[level=12]
setblock 252 298 285 minecraft:light[level=12]
setblock 252 298 292 minecraft:light[level=12]
setblock 252 298 299 minecraft:light[level=12]
setblock 252 298 306 minecraft:light[level=12]
fill 253 298 314 253 298 315 minecraft:chiseled_sandstone
fill 254 298 275 254 308 275 minecraft:smooth_sandstone
setblock 254 298 278 minecraft:light[level=15]
setblock 254 298 286 minecraft:light[level=15]
setblock 254 298 294 minecraft:light[level=15]
setblock 254 298 302 minecraft:light[level=15]
setblock 259 298 278 minecraft:light[level=12]
setblock 259 298 285 minecraft:light[level=12]
setblock 259 298 292 minecraft:light[level=12]
setblock 259 298 299 minecraft:light[level=12]
setblock 259 298 306 minecraft:light[level=12]
setblock 259 298 313 minecraft:light[level=12]
setblock 262 298 278 minecraft:light[level=15]
setblock 262 298 286 minecraft:light[level=15]
setblock 262 298 294 minecraft:light[level=15]
setblock 262 298 302 minecraft:light[level=15]
setblock 262 298 310 minecraft:light[level=15]
setblock 264 298 275 minecraft:lapis_block
setblock 266 298 278 minecraft:light[level=12]
setblock 266 298 285 minecraft:light[level=12]
setblock 266 298 292 minecraft:light[level=12]
setblock 266 298 299 minecraft:light[level=12]
setblock 266 298 306 minecraft:light[level=12]
setblock 266 298 313 minecraft:light[level=12]
setblock 270 298 278 minecraft:light[level=15]
setblock 270 298 286 minecraft:light[level=15]
setblock 270 298 294 minecraft:light[level=15]
setblock 270 298 302 minecraft:light[level=15]
setblock 270 298 310 minecraft:light[level=15]
setblock 273 298 278 minecraft:light[level=12]
setblock 273 298 285 minecraft:light[level=12]
setblock 273 298 292 minecraft:light[level=12]
setblock 273 298 299 minecraft:light[level=12]
setblock 273 298 306 minecraft:light[level=12]
fill 274 298 285 274 298 293 minecraft:lapis_block
setblock 277 298 293 minecraft:lapis_block
fill 241 299 277 241 300 277 minecraft:cut_sandstone
fill 241 299 279 241 300 279 minecraft:cut_sandstone
fill 242 299 276 242 300 276 minecraft:cut_sandstone
fill 242 299 278 242 300 278 minecraft:cut_sandstone
fill 242 299 280 242 300 280 minecraft:cut_sandstone
fill 243 299 277 243 300 277 minecraft:cut_sandstone
fill 243 299 279 243 300 279 minecraft:cut_sandstone
fill 244 299 276 244 300 276 minecraft:cut_sandstone
fill 244 299 278 244 300 278 minecraft:cut_sandstone
fill 244 299 280 244 300 280 minecraft:cut_sandstone
fill 245 299 275 245 308 275 minecraft:smooth_sandstone
fill 245 299 277 245 300 277 minecraft:cut_sandstone
fill 245 299 279 245 300 279 minecraft:cut_sandstone
fill 246 299 276 246 300 276 minecraft:cut_sandstone
fill 246 299 278 246 300 278 minecraft:cut_sandstone
fill 246 299 280 246 300 280 minecraft:cut_sandstone
fill 247 299 277 247 300 277 minecraft:cut_sandstone
fill 247 299 279 247 300 279 minecraft:cut_sandstone
fill 255 299 275 255 308 275 minecraft:smooth_sandstone
setblock 256 299 275 minecraft:lapis_block
fill 264 299 275 264 308 275 minecraft:smooth_sandstone
fill 270 299 310 270 299 311 minecraft:chiseled_sandstone
setblock 270 299 313 minecraft:chiseled_sandstone
fill 271 299 310 273 299 310 minecraft:chiseled_sandstone
fill 271 299 314 273 299 314 minecraft:chiseled_sandstone
fill 273 299 286 275 299 292 minecraft:lapis_block
fill 274 299 311 274 299 313 minecraft:chiseled_sandstone
fill 277 299 293 277 308 293 minecraft:smooth_sandstone
fill 237 300 285 237 300 287 minecraft:cut_sandstone
fill 237 300 297 237 300 299 minecraft:cut_sandstone
fill 237 300 309 237 300 311 minecraft:cut_sandstone
fill 243 300 315 245 300 315 minecraft:cut_sandstone
fill 248 300 277 249 300 277 minecraft:cut_sandstone
fill 252 300 310 254 300 312 minecraft:cut_sandstone
fill 255 300 315 257 300 315 minecraft:cut_sandstone
fill 256 300 275 256 308 275 minecraft:smooth_sandstone
fill 259 300 277 261 300 277 minecraft:cut_sandstone
fill 267 300 315 269 300 315 minecraft:cut_sandstone
setblock 270 300 311 minecraft:lapis_block
setblock 270 300 313 minecraft:lapis_block
fill 271 300 277 273 300 277 minecraft:cut_sandstone
fill 271 300 310 273 300 310 minecraft:lapis_block
fill 271 300 314 272 300 314 minecraft:lapis_block
fill 272 300 287 274 300 291 minecraft:lapis_block
setblock 272 300 317 minecraft:black_terracotta
fill 273 300 317 273 308 317 minecraft:smooth_sandstone
setblock 274 300 312 minecraft:lapis_block
fill 275 300 285 275 300 287 minecraft:cut_sandstone
fill 275 300 288 276 300 291 minecraft:lapis_block
fill 275 300 297 275 300 299 minecraft:cut_sandstone
fill 275 300 309 275 300 311 minecraft:cut_sandstone
setblock 276 300 287 minecraft:lapis_block
setblock 277 300 277 minecraft:black_terracotta
fill 248 301 317 248 308 317 minecraft:smooth_sandstone
setblock 249 301 317 minecraft:orange_terracotta
setblock 263 301 275 minecraft:lapis_block
fill 272 301 317 272 308 317 minecraft:smooth_sandstone
fill 277 301 277 277 308 277 minecraft:smooth_sandstone
setblock 235 302 278 minecraft:black_terracotta
setblock 235 302 302 minecraft:blue_terracotta
setblock 244 302 317 minecraft:blue_terracotta
fill 249 302 317 249 308 317 minecraft:smooth_sandstone
fill 263 302 275 263 308 275 minecraft:smooth_sandstone
fill 235 303 278 235 308 278 minecraft:smooth_sandstone
fill 235 303 302 235 308 302 minecraft:smooth_sandstone
fill 244 303 317 244 308 317 minecraft:smooth_sandstone
setblock 246 303 275 minecraft:orange_terracotta
setblock 235 304 280 minecraft:lapis_block
fill 246 304 275 246 308 275 minecraft:smooth_sandstone
setblock 250 304 317 minecraft:orange_terracotta
setblock 254 304 317 minecraft:blue_terracotta
setblock 277 304 313 minecraft:blue_terracotta
fill 235 305 280 235 308 280 minecraft:smooth_sandstone
setblock 250 305 275 minecraft:blue_terracotta
fill 250 305 317 250 308 317 minecraft:smooth_sandstone
fill 254 305 317 254 308 317 minecraft:smooth_sandstone
setblock 277 305 280 minecraft:black_terracotta
fill 277 305 313 277 308 313 minecraft:smooth_sandstone
setblock 242 306 317 minecraft:black_terracotta
fill 250 306 275 250 308 275 minecraft:smooth_sandstone
setblock 253 306 275 minecraft:orange_terracotta
setblock 256 306 317 minecraft:orange_terracotta
fill 277 306 280 277 307 280 minecraft:smooth_sandstone
setblock 277 306 300 minecraft:black_terracotta
fill 242 307 317 242 308 317 minecraft:smooth_sandstone
fill 253 307 275 253 308 275 minecraft:smooth_sandstone
fill 256 307 317 256 308 317 minecraft:smooth_sandstone
fill 277 307 300 277 308 300 minecraft:smooth_sandstone
setblock 277 307 305 minecraft:lapis_block
setblock 277 308 280 minecraft:orange_terracotta
setblock 277 308 305 minecraft:smooth_sandstone
