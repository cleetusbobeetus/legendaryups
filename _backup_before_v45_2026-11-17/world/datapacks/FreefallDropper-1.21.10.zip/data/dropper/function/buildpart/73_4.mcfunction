setblock 84 218 323 minecraft:stripped_dark_oak_log
fill 84 218 327 84 219 327 minecraft:stripped_dark_oak_log
fill 84 218 329 84 219 329 minecraft:stripped_dark_oak_log
fill 84 218 331 84 219 331 minecraft:stripped_dark_oak_log
fill 84 218 333 84 219 333 minecraft:stripped_dark_oak_log
fill 84 218 335 84 219 335 minecraft:stripped_dark_oak_log
fill 84 218 337 84 219 337 minecraft:stripped_dark_oak_log
setblock 84 218 363 minecraft:stripped_dark_oak_log
setblock 84 218 364 minecraft:dark_oak_planks
fill 85 218 322 85 219 322 minecraft:spruce_planks
fill 85 218 328 85 219 328 minecraft:stripped_dark_oak_log
fill 85 218 330 85 219 330 minecraft:stripped_dark_oak_log
fill 85 218 332 85 219 332 minecraft:stripped_dark_oak_log
fill 85 218 334 85 219 334 minecraft:stripped_dark_oak_log
fill 85 218 336 85 219 336 minecraft:stripped_dark_oak_log
setblock 86 218 322 minecraft:dark_oak_planks
fill 86 218 327 86 219 327 minecraft:stripped_dark_oak_log
fill 86 218 329 86 219 329 minecraft:stripped_dark_oak_log
fill 86 218 331 86 219 331 minecraft:stripped_dark_oak_log
fill 86 218 333 86 219 333 minecraft:stripped_dark_oak_log
fill 86 218 335 86 219 335 minecraft:stripped_dark_oak_log
fill 86 218 337 86 219 337 minecraft:stripped_dark_oak_log
setblock 86 218 364 minecraft:dark_oak_planks
fill 87 218 322 89 219 322 minecraft:spruce_planks
fill 87 218 328 87 219 328 minecraft:stripped_dark_oak_log
fill 87 218 330 87 219 330 minecraft:stripped_dark_oak_log
fill 87 218 332 87 219 332 minecraft:stripped_dark_oak_log
fill 87 218 334 87 219 334 minecraft:stripped_dark_oak_log
fill 87 218 336 87 219 336 minecraft:stripped_dark_oak_log
fill 87 218 364 87 219 364 minecraft:spruce_planks
fill 88 218 326 88 218 327 minecraft:stripped_dark_oak_log
fill 88 218 329 88 219 329 minecraft:stripped_dark_oak_log
fill 88 218 331 88 219 331 minecraft:stripped_dark_oak_log
fill 88 218 333 88 219 333 minecraft:stripped_dark_oak_log
fill 88 218 335 88 219 335 minecraft:stripped_dark_oak_log
fill 88 218 337 88 219 337 minecraft:stripped_dark_oak_log
setblock 88 218 340 minecraft:stripped_dark_oak_log
setblock 88 218 354 minecraft:stripped_dark_oak_log
setblock 88 218 361 minecraft:stripped_dark_oak_log
fill 89 218 323 89 219 323 minecraft:spruce_planks
fill 89 218 326 89 220 326 minecraft:spruce_planks
setblock 89 218 338 minecraft:dark_oak_planks
fill 89 218 345 89 219 346 minecraft:spruce_planks
setblock 89 218 347 minecraft:dark_oak_planks
fill 89 218 348 89 219 349 minecraft:spruce_planks
fill 89 218 354 89 218 355 minecraft:dark_oak_planks
fill 89 218 356 89 219 356 minecraft:spruce_planks
setblock 89 218 357 minecraft:dark_oak_planks
fill 89 218 363 89 219 363 minecraft:spruce_planks
setblock 47 219 333 minecraft:spruce_planks
fill 47 219 345 47 220 345 minecraft:spruce_planks
setblock 47 219 359 minecraft:spruce_planks
setblock 47 219 363 minecraft:spruce_planks
fill 48 219 323 48 220 323 minecraft:stripped_dark_oak_log
fill 48 219 330 48 220 330 minecraft:stripped_dark_oak_log
fill 48 219 337 48 221 337 minecraft:stripped_dark_oak_log
fill 48 219 344 48 220 344 minecraft:stripped_dark_oak_log
fill 48 219 351 48 220 351 minecraft:stripped_dark_oak_log
fill 48 219 358 48 220 358 minecraft:stripped_dark_oak_log
setblock 48 219 364 minecraft:spruce_planks
setblock 49 219 322 minecraft:spruce_planks
fill 50 219 363 50 220 363 minecraft:stripped_dark_oak_log
fill 52 219 364 53 219 364 minecraft:spruce_planks
fill 55 219 323 55 220 323 minecraft:stripped_dark_oak_log
setblock 56 219 322 minecraft:red_concrete
fill 57 219 363 57 220 363 minecraft:stripped_dark_oak_log
setblock 57 219 364 minecraft:spruce_planks
setblock 59 219 322 minecraft:spruce_planks
setblock 59 219 364 minecraft:red_concrete
fill 64 219 363 64 220 363 minecraft:stripped_dark_oak_log
fill 70 219 364 72 219 364 minecraft:spruce_planks
fill 71 219 363 71 220 363 minecraft:stripped_dark_oak_log
setblock 72 219 322 minecraft:spruce_planks
setblock 73 219 364 minecraft:red_concrete
fill 75 219 322 76 219 322 minecraft:spruce_planks
fill 76 219 323 76 220 323 minecraft:stripped_dark_oak_log
fill 78 219 363 78 220 363 minecraft:stripped_dark_oak_log
setblock 79 219 364 minecraft:spruce_planks
setblock 82 219 322 minecraft:spruce_planks
fill 83 219 323 83 220 323 minecraft:stripped_dark_oak_log
setblock 84 219 364 minecraft:spruce_planks
fill 85 219 363 85 220 363 minecraft:stripped_dark_oak_log
setblock 86 219 322 minecraft:spruce_planks
setblock 86 219 364 minecraft:spruce_planks
fill 88 219 325 88 220 325 minecraft:stripped_dark_oak_log
setblock 88 219 327 minecraft:stripped_dark_oak_log
fill 88 219 339 88 220 339 minecraft:stripped_dark_oak_log
fill 88 219 353 88 220 353 minecraft:stripped_dark_oak_log
fill 88 219 360 88 220 360 minecraft:stripped_dark_oak_log
setblock 89 219 338 minecraft:spruce_planks
fill 89 219 347 89 220 347 minecraft:spruce_planks
fill 89 219 354 89 219 355 minecraft:spruce_planks
setblock 89 219 357 minecraft:spruce_planks
fill 47 220 322 47 220 337 minecraft:dark_oak_planks
fill 47 220 339 47 221 344 minecraft:dark_oak_planks
fill 47 220 346 47 261 349 minecraft:dark_oak_planks
fill 47 220 351 47 220 361 minecraft:dark_oak_planks
fill 47 220 363 47 221 364 minecraft:dark_oak_planks
fill 48 220 322 52 220 322 minecraft:dark_oak_planks
fill 48 220 324 48 220 327 minecraft:stripped_dark_oak_log
setblock 48 220 329 minecraft:stripped_dark_oak_log
fill 48 220 331 48 220 334 minecraft:stripped_dark_oak_log
setblock 48 220 336 minecraft:stripped_dark_oak_log
fill 48 220 338 48 221 341 minecraft:stripped_dark_oak_log
fill 48 220 343 48 221 343 minecraft:stripped_dark_oak_log
fill 48 220 345 48 220 348 minecraft:stripped_dark_oak_log
setblock 48 220 350 minecraft:stripped_dark_oak_log
fill 48 220 352 48 220 355 minecraft:stripped_dark_oak_log
setblock 48 220 357 minecraft:stripped_dark_oak_log
fill 48 220 359 48 220 362 minecraft:stripped_dark_oak_log
fill 48 220 364 48 308 364 minecraft:dark_oak_planks
setblock 49 220 323 minecraft:stripped_dark_oak_log
fill 49 220 337 51 220 343 minecraft:dark_oak_planks
setblock 49 220 363 minecraft:stripped_dark_oak_log
fill 50 220 364 64 220 364 minecraft:dark_oak_planks
fill 51 220 323 54 220 323 minecraft:stripped_dark_oak_log
fill 51 220 363 54 220 363 minecraft:stripped_dark_oak_log
fill 53 220 322 53 221 322 minecraft:spruce_planks
fill 54 220 322 59 220 322 minecraft:dark_oak_planks
setblock 56 220 323 minecraft:stripped_dark_oak_log
setblock 56 220 363 minecraft:stripped_dark_oak_log
fill 58 220 323 60 220 323 minecraft:stripped_dark_oak_log
fill 58 220 363 61 220 363 minecraft:stripped_dark_oak_log
fill 61 220 322 64 220 322 minecraft:dark_oak_planks
setblock 61 220 324 minecraft:shroomlight
setblock 61 220 326 minecraft:shroomlight
setblock 61 220 328 minecraft:shroomlight
setblock 61 220 330 minecraft:shroomlight
setblock 62 220 323 minecraft:shroomlight
setblock 62 220 325 minecraft:shroomlight
setblock 62 220 327 minecraft:shroomlight
setblock 62 220 329 minecraft:shroomlight
setblock 62 220 331 minecraft:shroomlight
setblock 63 220 324 minecraft:shroomlight
setblock 63 220 326 minecraft:shroomlight
setblock 63 220 328 minecraft:shroomlight
setblock 63 220 330 minecraft:shroomlight
setblock 63 220 363 minecraft:stripped_dark_oak_log
setblock 64 220 323 minecraft:shroomlight
setblock 64 220 325 minecraft:shroomlight
setblock 64 220 327 minecraft:shroomlight
setblock 64 220 329 minecraft:shroomlight
setblock 64 220 331 minecraft:shroomlight
setblock 65 220 324 minecraft:shroomlight
setblock 65 220 326 minecraft:shroomlight
setblock 65 220 328 minecraft:shroomlight
setblock 65 220 330 minecraft:shroomlight
fill 65 220 363 68 220 363 minecraft:stripped_dark_oak_log
fill 66 220 322 67 252 322 minecraft:dark_oak_planks
setblock 66 220 323 minecraft:shroomlight
setblock 66 220 325 minecraft:shroomlight
setblock 66 220 327 minecraft:shroomlight
setblock 66 220 329 minecraft:shroomlight
setblock 66 220 331 minecraft:shroomlight
setblock 66 220 364 minecraft:dark_oak_planks
setblock 67 220 324 minecraft:shroomlight
setblock 67 220 326 minecraft:shroomlight
setblock 67 220 328 minecraft:shroomlight
setblock 67 220 330 minecraft:shroomlight
setblock 67 220 364 minecraft:red_concrete
setblock 68 220 323 minecraft:shroomlight
setblock 68 220 325 minecraft:shroomlight
setblock 68 220 327 minecraft:shroomlight
setblock 68 220 329 minecraft:shroomlight
setblock 68 220 331 minecraft:shroomlight
fill 68 220 364 73 220 364 minecraft:dark_oak_planks
fill 69 220 322 72 220 322 minecraft:dark_oak_planks
setblock 69 220 324 minecraft:shroomlight
setblock 69 220 326 minecraft:shroomlight
setblock 69 220 328 minecraft:shroomlight
setblock 69 220 330 minecraft:shroomlight
setblock 70 220 323 minecraft:stripped_dark_oak_log
setblock 70 220 363 minecraft:stripped_dark_oak_log
fill 72 220 323 75 220 323 minecraft:stripped_dark_oak_log
fill 72 220 363 75 220 363 minecraft:stripped_dark_oak_log
fill 74 220 322 77 231 322 minecraft:dark_oak_planks
fill 75 220 364 79 220 364 minecraft:dark_oak_planks
setblock 77 220 323 minecraft:stripped_dark_oak_log
setblock 77 220 363 minecraft:stripped_dark_oak_log
fill 79 220 322 89 220 322 minecraft:dark_oak_planks
fill 79 220 323 82 220 323 minecraft:stripped_dark_oak_log
setblock 79 220 328 minecraft:shroomlight
setblock 79 220 330 minecraft:shroomlight
setblock 79 220 332 minecraft:shroomlight
setblock 79 220 334 minecraft:shroomlight
setblock 79 220 336 minecraft:shroomlight
fill 79 220 363 82 220 363 minecraft:stripped_dark_oak_log
setblock 80 220 327 minecraft:shroomlight
setblock 80 220 329 minecraft:shroomlight
setblock 80 220 331 minecraft:shroomlight
setblock 80 220 333 minecraft:shroomlight
setblock 80 220 335 minecraft:shroomlight
setblock 80 220 337 minecraft:shroomlight
setblock 81 220 328 minecraft:shroomlight
setblock 81 220 330 minecraft:shroomlight
setblock 81 220 332 minecraft:shroomlight
setblock 81 220 334 minecraft:shroomlight
setblock 81 220 336 minecraft:shroomlight
fill 81 220 364 89 227 364 minecraft:dark_oak_planks
setblock 82 220 327 minecraft:shroomlight
setblock 82 220 329 minecraft:shroomlight
setblock 82 220 331 minecraft:shroomlight
setblock 82 220 333 minecraft:shroomlight
setblock 82 220 335 minecraft:shroomlight
setblock 82 220 337 minecraft:shroomlight
setblock 83 220 328 minecraft:shroomlight
setblock 83 220 330 minecraft:shroomlight
setblock 83 220 332 minecraft:shroomlight
setblock 83 220 334 minecraft:shroomlight
setblock 83 220 336 minecraft:shroomlight
setblock 84 220 323 minecraft:stripped_dark_oak_log
setblock 84 220 327 minecraft:shroomlight
setblock 84 220 329 minecraft:shroomlight
setblock 84 220 331 minecraft:shroomlight
setblock 84 220 333 minecraft:shroomlight
setblock 84 220 335 minecraft:shroomlight
setblock 84 220 337 minecraft:shroomlight
setblock 84 220 363 minecraft:stripped_dark_oak_log
setblock 85 220 328 minecraft:shroomlight
setblock 85 220 330 minecraft:shroomlight
setblock 85 220 332 minecraft:shroomlight
setblock 85 220 334 minecraft:shroomlight
setblock 85 220 336 minecraft:shroomlight
fill 86 220 323 88 220 323 minecraft:stripped_dark_oak_log
setblock 86 220 327 minecraft:shroomlight
setblock 86 220 329 minecraft:shroomlight
setblock 86 220 331 minecraft:shroomlight
setblock 86 220 333 minecraft:shroomlight
setblock 86 220 335 minecraft:shroomlight
setblock 86 220 337 minecraft:shroomlight
fill 86 220 363 88 220 363 minecraft:stripped_dark_oak_log
setblock 87 220 328 minecraft:shroomlight
setblock 87 220 330 minecraft:shroomlight
setblock 87 220 332 minecraft:shroomlight
setblock 87 220 334 minecraft:shroomlight
setblock 87 220 336 minecraft:shroomlight
setblock 88 220 324 minecraft:stripped_dark_oak_log
setblock 88 220 326 minecraft:stripped_dark_oak_log
setblock 88 220 327 minecraft:shroomlight
setblock 88 220 329 minecraft:shroomlight
setblock 88 220 331 minecraft:shroomlight
setblock 88 220 333 minecraft:shroomlight
setblock 88 220 335 minecraft:shroomlight
setblock 88 220 337 minecraft:shroomlight
setblock 88 220 338 minecraft:stripped_dark_oak_log
setblock 88 220 340 minecraft:stripped_dark_oak_log
fill 88 220 342 88 220 345 minecraft:stripped_dark_oak_log
setblock 88 220 354 minecraft:stripped_dark_oak_log
fill 88 220 356 88 220 359 minecraft:stripped_dark_oak_log
setblock 88 220 361 minecraft:stripped_dark_oak_log
fill 89 220 323 89 220 325 minecraft:dark_oak_planks
fill 89 220 327 89 254 332 minecraft:dark_oak_planks
setblock 89 220 333 minecraft:spruce_planks
fill 89 220 334 89 220 346 minecraft:dark_oak_planks
fill 89 220 348 89 220 363 minecraft:dark_oak_planks
fill 47 221 322 47 221 334 minecraft:dark_oak_planks
setblock 47 221 335 minecraft:spruce_planks
fill 47 221 336 47 265 338 minecraft:dark_oak_planks
fill 47 221 345 47 308 345 minecraft:dark_oak_planks
fill 47 221 350 47 254 351 minecraft:dark_oak_planks
fill 47 221 352 47 222 352 minecraft:spruce_planks
fill 47 221 353 47 227 362 minecraft:dark_oak_planks
setblock 48 221 322 minecraft:spruce_planks
setblock 48 221 325 minecraft:stripped_dark_oak_log
setblock 48 221 332 minecraft:stripped_dark_oak_log
setblock 48 221 346 minecraft:stripped_dark_oak_log
setblock 48 221 353 minecraft:stripped_dark_oak_log
setblock 48 221 360 minecraft:stripped_dark_oak_log
fill 49 221 322 52 221 322 minecraft:dark_oak_planks
fill 49 221 337 51 221 343 minecraft:stripped_dark_oak_log
fill 49 221 364 50 304 364 minecraft:dark_oak_planks
setblock 51 221 364 minecraft:spruce_planks
setblock 52 221 363 minecraft:stripped_dark_oak_log
setblock 52 221 364 minecraft:dark_oak_planks
setblock 53 221 323 minecraft:stripped_dark_oak_log
setblock 53 221 364 minecraft:spruce_planks
fill 54 221 322 56 221 322 minecraft:dark_oak_planks
fill 54 221 364 65 221 364 minecraft:dark_oak_planks
setblock 57 221 322 minecraft:spruce_planks
fill 58 221 322 63 229 322 minecraft:dark_oak_planks
setblock 59 221 363 minecraft:stripped_dark_oak_log
setblock 60 221 323 minecraft:stripped_dark_oak_log
fill 61 221 324 61 222 324 minecraft:stripped_dark_oak_log
fill 61 221 326 61 222 326 minecraft:stripped_dark_oak_log
fill 61 221 328 61 222 328 minecraft:stripped_dark_oak_log
fill 61 221 330 61 222 330 minecraft:stripped_dark_oak_log
fill 62 221 323 62 222 323 minecraft:stripped_dark_oak_log
fill 62 221 325 62 222 325 minecraft:stripped_dark_oak_log
fill 62 221 327 62 222 327 minecraft:stripped_dark_oak_log
fill 62 221 329 62 222 329 minecraft:stripped_dark_oak_log
fill 62 221 331 62 222 331 minecraft:stripped_dark_oak_log
fill 63 221 324 63 222 324 minecraft:stripped_dark_oak_log
fill 63 221 326 63 222 326 minecraft:stripped_dark_oak_log
fill 63 221 328 63 222 328 minecraft:stripped_dark_oak_log
fill 63 221 330 63 222 330 minecraft:stripped_dark_oak_log
setblock 64 221 322 minecraft:red_concrete
fill 64 221 323 64 222 323 minecraft:stripped_dark_oak_log
fill 64 221 325 64 222 325 minecraft:stripped_dark_oak_log
fill 64 221 327 64 222 327 minecraft:stripped_dark_oak_log
fill 64 221 329 64 222 329 minecraft:stripped_dark_oak_log
fill 64 221 331 64 222 331 minecraft:stripped_dark_oak_log
fill 65 221 322 65 308 322 minecraft:dark_oak_planks
fill 65 221 324 65 222 324 minecraft:stripped_dark_oak_log
fill 65 221 326 65 222 326 minecraft:stripped_dark_oak_log
fill 65 221 328 65 222 328 minecraft:stripped_dark_oak_log
fill 65 221 330 65 222 330 minecraft:stripped_dark_oak_log
fill 66 221 323 66 222 323 minecraft:stripped_dark_oak_log
fill 66 221 325 66 222 325 minecraft:stripped_dark_oak_log
fill 66 221 327 66 222 327 minecraft:stripped_dark_oak_log
fill 66 221 329 66 222 329 minecraft:stripped_dark_oak_log
fill 66 221 331 66 222 331 minecraft:stripped_dark_oak_log
setblock 66 221 363 minecraft:stripped_dark_oak_log
setblock 66 221 364 minecraft:spruce_planks
fill 67 221 324 67 222 324 minecraft:stripped_dark_oak_log
fill 67 221 326 67 222 326 minecraft:stripped_dark_oak_log
fill 67 221 328 67 222 328 minecraft:stripped_dark_oak_log
fill 67 221 330 67 222 330 minecraft:stripped_dark_oak_log
fill 67 221 364 70 237 364 minecraft:dark_oak_planks
fill 68 221 323 68 222 323 minecraft:stripped_dark_oak_log
fill 68 221 325 68 222 325 minecraft:stripped_dark_oak_log
fill 68 221 327 68 222 327 minecraft:stripped_dark_oak_log
fill 68 221 329 68 222 329 minecraft:stripped_dark_oak_log
fill 68 221 331 68 222 331 minecraft:stripped_dark_oak_log
fill 69 221 322 70 308 322 minecraft:dark_oak_planks
fill 69 221 324 69 222 324 minecraft:stripped_dark_oak_log
fill 69 221 326 69 222 326 minecraft:stripped_dark_oak_log
fill 69 221 328 69 222 328 minecraft:stripped_dark_oak_log
fill 69 221 330 69 222 330 minecraft:stripped_dark_oak_log
setblock 71 221 322 minecraft:red_concrete
setblock 71 221 364 minecraft:red_concrete
fill 72 221 322 73 228 322 minecraft:dark_oak_planks
fill 72 221 364 78 221 364 minecraft:dark_oak_planks
setblock 73 221 363 minecraft:stripped_dark_oak_log
setblock 74 221 323 minecraft:stripped_dark_oak_log
fill 78 221 322 82 244 322 minecraft:dark_oak_planks
fill 79 221 328 79 222 328 minecraft:stripped_dark_oak_log
fill 79 221 330 79 222 330 minecraft:stripped_dark_oak_log
fill 79 221 332 79 222 332 minecraft:stripped_dark_oak_log
fill 79 221 334 79 222 334 minecraft:stripped_dark_oak_log
fill 79 221 336 79 222 336 minecraft:stripped_dark_oak_log
fill 79 221 364 79 222 364 minecraft:spruce_planks
fill 80 221 327 80 222 327 minecraft:stripped_dark_oak_log
fill 80 221 329 80 222 329 minecraft:stripped_dark_oak_log
fill 80 221 331 80 222 331 minecraft:stripped_dark_oak_log
fill 80 221 333 80 222 333 minecraft:stripped_dark_oak_log
fill 80 221 335 80 222 335 minecraft:stripped_dark_oak_log
fill 80 221 337 80 222 337 minecraft:stripped_dark_oak_log
fill 80 221 340 80 230 348 minecraft:white_wool
fill 80 221 349 80 232 350 minecraft:stripped_dark_oak_log
setblock 80 221 363 minecraft:stripped_dark_oak_log
fill 80 221 364 80 257 364 minecraft:dark_oak_planks
setblock 81 221 323 minecraft:stripped_dark_oak_log
fill 81 221 328 81 222 328 minecraft:stripped_dark_oak_log
fill 81 221 330 81 222 330 minecraft:stripped_dark_oak_log
fill 81 221 332 81 222 332 minecraft:stripped_dark_oak_log
fill 81 221 334 81 222 334 minecraft:stripped_dark_oak_log
fill 81 221 336 81 222 336 minecraft:stripped_dark_oak_log
fill 82 221 327 82 222 327 minecraft:stripped_dark_oak_log
fill 82 221 329 82 222 329 minecraft:stripped_dark_oak_log
fill 82 221 331 82 222 331 minecraft:stripped_dark_oak_log
fill 82 221 333 82 222 333 minecraft:stripped_dark_oak_log
fill 82 221 335 82 222 335 minecraft:stripped_dark_oak_log
fill 82 221 337 82 222 337 minecraft:stripped_dark_oak_log
setblock 83 221 322 minecraft:spruce_planks
fill 83 221 328 83 222 328 minecraft:stripped_dark_oak_log
fill 83 221 330 83 222 330 minecraft:stripped_dark_oak_log
fill 83 221 332 83 222 332 minecraft:stripped_dark_oak_log
fill 83 221 334 83 222 334 minecraft:stripped_dark_oak_log
fill 83 221 336 83 222 336 minecraft:stripped_dark_oak_log
fill 84 221 322 89 221 322 minecraft:dark_oak_planks
fill 84 221 327 84 222 327 minecraft:stripped_dark_oak_log
fill 84 221 329 84 222 329 minecraft:stripped_dark_oak_log
fill 84 221 331 84 222 331 minecraft:stripped_dark_oak_log
fill 84 221 333 84 222 333 minecraft:stripped_dark_oak_log
fill 84 221 335 84 222 335 minecraft:stripped_dark_oak_log
fill 84 221 337 84 222 337 minecraft:stripped_dark_oak_log
fill 85 221 328 85 222 328 minecraft:stripped_dark_oak_log
fill 85 221 330 85 222 330 minecraft:stripped_dark_oak_log
fill 85 221 332 85 222 332 minecraft:stripped_dark_oak_log
fill 85 221 334 85 222 334 minecraft:stripped_dark_oak_log
fill 85 221 336 85 222 336 minecraft:stripped_dark_oak_log
fill 86 221 327 86 222 327 minecraft:stripped_dark_oak_log
fill 86 221 329 86 222 329 minecraft:stripped_dark_oak_log
fill 86 221 331 86 222 331 minecraft:stripped_dark_oak_log
fill 86 221 333 86 222 333 minecraft:stripped_dark_oak_log
fill 86 221 335 86 222 335 minecraft:stripped_dark_oak_log
fill 86 221 337 86 222 337 minecraft:stripped_dark_oak_log
fill 87 221 328 87 222 328 minecraft:stripped_dark_oak_log
fill 87 221 330 87 222 330 minecraft:stripped_dark_oak_log
fill 87 221 332 87 222 332 minecraft:stripped_dark_oak_log
fill 87 221 334 87 222 334 minecraft:stripped_dark_oak_log
fill 87 221 336 87 222 336 minecraft:stripped_dark_oak_log
setblock 87 221 363 minecraft:stripped_dark_oak_log
setblock 88 221 323 minecraft:stripped_dark_oak_log
fill 88 221 327 88 222 327 minecraft:stripped_dark_oak_log
fill 88 221 329 88 222 329 minecraft:stripped_dark_oak_log
fill 88 221 331 88 222 331 minecraft:stripped_dark_oak_log
fill 88 221 333 88 222 333 minecraft:stripped_dark_oak_log
fill 88 221 335 88 222 335 minecraft:stripped_dark_oak_log
fill 88 221 337 88 222 337 minecraft:stripped_dark_oak_log
setblock 88 221 344 minecraft:stripped_dark_oak_log
setblock 88 221 358 minecraft:stripped_dark_oak_log
setblock 89 221 323 minecraft:spruce_planks
fill 89 221 324 89 308 326 minecraft:dark_oak_planks
fill 89 221 333 89 221 336 minecraft:dark_oak_planks
setblock 89 221 337 minecraft:spruce_planks
fill 89 221 338 89 221 362 minecraft:dark_oak_planks
setblock 89 221 363 minecraft:spruce_planks
fill 47 222 322 47 307 323 minecraft:dark_oak_planks
setblock 47 222 324 minecraft:spruce_planks
fill 47 222 325 47 270 326 minecraft:dark_oak_planks
fill 47 222 327 47 222 328 minecraft:spruce_planks
fill 47 222 329 47 308 330 minecraft:dark_oak_planks
setblock 47 222 331 minecraft:spruce_planks
fill 47 222 332 47 230 333 minecraft:dark_oak_planks
setblock 47 222 334 minecraft:spruce_planks
fill 47 222 335 47 308 335 minecraft:dark_oak_planks
fill 47 222 339 47 225 341 minecraft:shroomlight
fill 47 222 342 47 308 343 minecraft:dark_oak_planks
setblock 47 222 344 minecraft:spruce_planks
setblock 47 222 363 minecraft:spruce_planks
fill 47 222 364 47 308 364 minecraft:dark_oak_planks
fill 48 222 322 51 243 322 minecraft:dark_oak_planks
setblock 48 222 326 minecraft:stripped_dark_oak_log
setblock 48 222 333 minecraft:stripped_dark_oak_log
setblock 48 222 340 minecraft:stripped_dark_oak_log
setblock 48 222 347 minecraft:stripped_dark_oak_log
setblock 48 222 354 minecraft:stripped_dark_oak_log
setblock 48 222 361 minecraft:stripped_dark_oak_log
setblock 50 222 325 minecraft:light[level=12]
setblock 50 222 332 minecraft:light[level=12]
setblock 50 222 339 minecraft:light[level=12]
setblock 50 222 346 minecraft:light[level=12]
setblock 50 222 353 minecraft:light[level=12]
setblock 50 222 360 minecraft:light[level=12]
fill 51 222 337 51 222 343 minecraft:red_concrete
fill 51 222 355 51 225 355 minecraft:iron_bars
fill 51 222 364 51 308 364 minecraft:dark_oak_planks
setblock 52 222 322 minecraft:spruce_planks
setblock 52 222 323 minecraft:stripped_dark_oak_log
setblock 52 222 364 minecraft:spruce_planks
fill 53 222 322 54 268 322 minecraft:dark_oak_planks
setblock 53 222 363 minecraft:stripped_dark_oak_log
fill 53 222 364 53 279 364 minecraft:dark_oak_planks
setblock 54 222 364 minecraft:spruce_planks
setblock 55 222 322 minecraft:spruce_planks
fill 55 222 364 60 225 364 minecraft:dark_oak_planks
fill 56 222 322 57 308 322 minecraft:dark_oak_planks
setblock 57 222 325 minecraft:light[level=12]
setblock 57 222 332 minecraft:light[level=12]
setblock 57 222 339 minecraft:light[level=12]
setblock 57 222 346 minecraft:light[level=12]
setblock 57 222 353 minecraft:light[level=12]
setblock 57 222 360 minecraft:light[level=12]
setblock 59 222 323 minecraft:stripped_dark_oak_log
setblock 60 222 363 minecraft:stripped_dark_oak_log
setblock 61 222 364 minecraft:spruce_planks
fill 62 222 364 66 224 364 minecraft:dark_oak_planks
fill 64 222 322 64 308 322 minecraft:dark_oak_planks
setblock 64 222 332 minecraft:light[level=12]
setblock 64 222 339 minecraft:light[level=12]
setblock 64 222 346 minecraft:light[level=12]
setblock 64 222 353 minecraft:light[level=12]
setblock 64 222 360 minecraft:light[level=12]
setblock 67 222 363 minecraft:stripped_dark_oak_log
fill 68 222 322 68 308 322 minecraft:dark_oak_planks
fill 71 222 322 71 226 322 minecraft:dark_oak_planks
setblock 71 222 325 minecraft:light[level=12]
setblock 71 222 332 minecraft:light[level=12]
setblock 71 222 339 minecraft:light[level=12]
setblock 71 222 346 minecraft:light[level=12]
setblock 71 222 353 minecraft:light[level=12]
setblock 71 222 360 minecraft:light[level=12]
fill 71 222 364 74 262 364 minecraft:dark_oak_planks
setblock 73 222 323 minecraft:stripped_dark_oak_log
setblock 74 222 363 minecraft:stripped_dark_oak_log
setblock 75 222 364 minecraft:spruce_planks
fill 76 222 364 78 236 364 minecraft:dark_oak_planks
setblock 78 222 325 minecraft:light[level=12]
setblock 78 222 332 minecraft:light[level=12]
setblock 78 222 339 minecraft:light[level=12]
setblock 78 222 346 minecraft:light[level=12]
setblock 78 222 353 minecraft:light[level=12]
setblock 78 222 360 minecraft:light[level=12]
setblock 80 222 323 minecraft:stripped_dark_oak_log
setblock 81 222 363 minecraft:stripped_dark_oak_log
fill 83 222 322 85 308 322 minecraft:dark_oak_planks
setblock 85 222 325 minecraft:light[level=12]
setblock 85 222 339 minecraft:light[level=12]
setblock 85 222 353 minecraft:light[level=12]
setblock 85 222 360 minecraft:light[level=12]
setblock 86 222 322 minecraft:spruce_planks
fill 87 222 322 88 301 322 minecraft:dark_oak_planks
setblock 87 222 323 minecraft:stripped_dark_oak_log
setblock 88 222 343 minecraft:stripped_dark_oak_log
setblock 88 222 357 minecraft:stripped_dark_oak_log
setblock 88 222 363 minecraft:stripped_dark_oak_log
setblock 89 222 322 minecraft:spruce_planks
fill 89 222 323 89 308 323 minecraft:dark_oak_planks
fill 89 222 333 89 266 335 minecraft:dark_oak_planks
setblock 89 222 336 minecraft:spruce_planks
fill 89 222 337 89 256 341 minecraft:dark_oak_planks
fill 89 222 342 89 222 343 minecraft:spruce_planks
fill 89 222 344 89 243 346 minecraft:dark_oak_planks
setblock 89 222 347 minecraft:spruce_planks
fill 89 222 348 89 258 349 minecraft:dark_oak_planks
setblock 89 222 350 minecraft:spruce_planks
fill 89 222 351 89 271 353 minecraft:dark_oak_planks
setblock 89 222 354 minecraft:spruce_planks
fill 89 222 355 89 308 356 minecraft:dark_oak_planks
setblock 89 222 357 minecraft:spruce_planks
fill 89 222 358 89 231 359 minecraft:dark_oak_planks
setblock 89 222 360 minecraft:spruce_planks
fill 89 222 361 89 264 363 minecraft:dark_oak_planks
fill 47 223 324 47 308 324 minecraft:dark_oak_planks
fill 47 223 327 47 225 328 minecraft:dark_oak_planks
fill 47 223 331 47 244 331 minecraft:dark_oak_planks
fill 47 223 334 47 246 334 minecraft:dark_oak_planks
fill 47 223 344 47 234 344 minecraft:dark_oak_planks
fill 47 223 352 47 308 352 minecraft:dark_oak_planks
fill 47 223 363 47 308 363 minecraft:dark_oak_planks
setblock 48 223 327 minecraft:stripped_dark_oak_log
setblock 48 223 334 minecraft:stripped_dark_oak_log
setblock 48 223 341 minecraft:stripped_dark_oak_log
setblock 48 223 348 minecraft:stripped_dark_oak_log
setblock 48 223 355 minecraft:stripped_dark_oak_log
setblock 48 223 362 minecraft:stripped_dark_oak_log
setblock 51 223 323 minecraft:stripped_dark_oak_log
setblock 51 223 337 minecraft:stripped_dark_oak_log
setblock 51 223 340 minecraft:stripped_dark_oak_log
setblock 51 223 343 minecraft:stripped_dark_oak_log
fill 52 223 322 52 308 322 minecraft:dark_oak_planks
fill 52 223 364 52 308 364 minecraft:dark_oak_planks
setblock 54 223 363 minecraft:stripped_dark_oak_log
fill 54 223 364 54 308 364 minecraft:dark_oak_planks
fill 55 223 322 55 250 322 minecraft:dark_oak_planks
setblock 58 223 323 minecraft:stripped_dark_oak_log
setblock 61 223 324 minecraft:shroomlight
setblock 61 223 326 minecraft:shroomlight
setblock 61 223 328 minecraft:shroomlight
setblock 61 223 330 minecraft:shroomlight
setblock 61 223 363 minecraft:stripped_dark_oak_log
fill 61 223 364 61 308 364 minecraft:dark_oak_planks
setblock 62 223 323 minecraft:shroomlight
setblock 62 223 325 minecraft:shroomlight
setblock 62 223 327 minecraft:shroomlight
setblock 62 223 329 minecraft:shroomlight
setblock 62 223 331 minecraft:shroomlight
setblock 63 223 324 minecraft:shroomlight
setblock 63 223 326 minecraft:shroomlight
setblock 63 223 328 minecraft:shroomlight
setblock 63 223 330 minecraft:shroomlight
setblock 64 223 323 minecraft:shroomlight
setblock 64 223 325 minecraft:shroomlight
setblock 64 223 327 minecraft:shroomlight
setblock 64 223 329 minecraft:shroomlight
setblock 64 223 331 minecraft:shroomlight
setblock 65 223 324 minecraft:shroomlight
setblock 65 223 326 minecraft:shroomlight
setblock 65 223 328 minecraft:shroomlight
setblock 65 223 330 minecraft:shroomlight
setblock 66 223 323 minecraft:shroomlight
setblock 66 223 325 minecraft:shroomlight
setblock 66 223 327 minecraft:shroomlight
setblock 66 223 329 minecraft:shroomlight
setblock 66 223 331 minecraft:shroomlight
setblock 67 223 324 minecraft:shroomlight
setblock 67 223 326 minecraft:shroomlight
setblock 67 223 328 minecraft:shroomlight
setblock 67 223 330 minecraft:shroomlight
setblock 68 223 323 minecraft:shroomlight
setblock 68 223 325 minecraft:shroomlight
setblock 68 223 327 minecraft:shroomlight
setblock 68 223 329 minecraft:shroomlight
setblock 68 223 331 minecraft:shroomlight
setblock 68 223 363 minecraft:stripped_dark_oak_log
setblock 69 223 324 minecraft:shroomlight
setblock 69 223 326 minecraft:shroomlight
setblock 69 223 328 minecraft:shroomlight
setblock 69 223 330 minecraft:shroomlight
setblock 72 223 323 minecraft:stripped_dark_oak_log
setblock 75 223 363 minecraft:stripped_dark_oak_log
fill 75 223 364 75 308 364 minecraft:dark_oak_planks
setblock 79 223 323 minecraft:stripped_dark_oak_log
setblock 79 223 328 minecraft:shroomlight
setblock 79 223 330 minecraft:shroomlight
setblock 79 223 332 minecraft:shroomlight
setblock 79 223 334 minecraft:shroomlight
setblock 79 223 336 minecraft:shroomlight
fill 79 223 364 79 235 364 minecraft:dark_oak_planks
setblock 80 223 327 minecraft:shroomlight
setblock 80 223 329 minecraft:shroomlight
setblock 80 223 331 minecraft:shroomlight
setblock 80 223 333 minecraft:shroomlight
setblock 80 223 335 minecraft:shroomlight
setblock 80 223 337 minecraft:shroomlight
setblock 81 223 328 minecraft:shroomlight
setblock 81 223 330 minecraft:shroomlight
setblock 81 223 332 minecraft:shroomlight
setblock 81 223 334 minecraft:shroomlight
setblock 81 223 336 minecraft:shroomlight
setblock 82 223 327 minecraft:shroomlight
setblock 82 223 329 minecraft:shroomlight
setblock 82 223 331 minecraft:shroomlight
setblock 82 223 333 minecraft:shroomlight
setblock 82 223 335 minecraft:shroomlight
setblock 82 223 337 minecraft:shroomlight
setblock 82 223 363 minecraft:stripped_dark_oak_log
setblock 83 223 328 minecraft:shroomlight
setblock 83 223 330 minecraft:shroomlight
setblock 83 223 332 minecraft:shroomlight
setblock 83 223 334 minecraft:shroomlight
setblock 83 223 336 minecraft:shroomlight
setblock 84 223 327 minecraft:shroomlight
setblock 84 223 329 minecraft:shroomlight
setblock 84 223 331 minecraft:shroomlight
setblock 84 223 333 minecraft:shroomlight
setblock 84 223 335 minecraft:shroomlight
setblock 84 223 337 minecraft:shroomlight
setblock 85 223 328 minecraft:shroomlight
setblock 85 223 330 minecraft:shroomlight
setblock 85 223 332 minecraft:shroomlight
setblock 85 223 334 minecraft:shroomlight
setblock 85 223 336 minecraft:shroomlight
fill 86 223 322 86 308 322 minecraft:dark_oak_planks
setblock 86 223 323 minecraft:stripped_dark_oak_log
setblock 86 223 327 minecraft:shroomlight
setblock 86 223 329 minecraft:shroomlight
setblock 86 223 331 minecraft:shroomlight
setblock 86 223 333 minecraft:shroomlight
setblock 86 223 335 minecraft:shroomlight
setblock 86 223 337 minecraft:shroomlight
setblock 87 223 328 minecraft:shroomlight
setblock 87 223 330 minecraft:shroomlight
setblock 87 223 332 minecraft:shroomlight
setblock 87 223 334 minecraft:shroomlight
setblock 87 223 336 minecraft:shroomlight
setblock 88 223 327 minecraft:shroomlight
setblock 88 223 329 minecraft:shroomlight
setblock 88 223 331 minecraft:shroomlight
setblock 88 223 333 minecraft:shroomlight
setblock 88 223 335 minecraft:shroomlight
setblock 88 223 337 minecraft:shroomlight
setblock 88 223 342 minecraft:stripped_dark_oak_log
setblock 88 223 356 minecraft:stripped_dark_oak_log
fill 89 223 322 89 308 322 minecraft:dark_oak_planks
fill 89 223 336 89 308 336 minecraft:dark_oak_planks
fill 89 223 342 89 293 343 minecraft:dark_oak_planks
fill 89 223 347 89 275 347 minecraft:dark_oak_planks
fill 89 223 350 89 308 350 minecraft:dark_oak_planks
fill 89 223 354 89 308 354 minecraft:dark_oak_planks
fill 89 223 357 89 308 357 minecraft:dark_oak_planks
fill 89 223 360 89 308 360 minecraft:dark_oak_planks
fill 50 224 358 50 224 361 minecraft:dark_oak_planks
fill 51 224 357 52 224 357 minecraft:dark_oak_planks
setblock 51 224 361 minecraft:dark_oak_planks
fill 53 224 358 54 224 358 minecraft:dark_oak_planks
setblock 53 224 361 minecraft:dark_oak_planks
fill 54 224 359 54 224 360 minecraft:dark_oak_planks
fill 61 224 324 61 225 324 minecraft:stripped_dark_oak_log
fill 61 224 326 61 225 326 minecraft:stripped_dark_oak_log
fill 61 224 328 61 225 328 minecraft:stripped_dark_oak_log
fill 61 224 330 61 225 330 minecraft:stripped_dark_oak_log
fill 62 224 323 62 225 323 minecraft:stripped_dark_oak_log
fill 62 224 325 62 225 325 minecraft:stripped_dark_oak_log
fill 62 224 327 62 225 327 minecraft:stripped_dark_oak_log
fill 62 224 329 62 225 329 minecraft:stripped_dark_oak_log
fill 62 224 331 62 225 331 minecraft:stripped_dark_oak_log
fill 63 224 324 63 225 324 minecraft:stripped_dark_oak_log
fill 63 224 326 63 225 326 minecraft:stripped_dark_oak_log
fill 63 224 328 63 225 328 minecraft:stripped_dark_oak_log
fill 63 224 330 63 225 330 minecraft:stripped_dark_oak_log
fill 64 224 323 64 225 323 minecraft:stripped_dark_oak_log
fill 64 224 325 64 225 325 minecraft:stripped_dark_oak_log
fill 64 224 327 64 225 327 minecraft:stripped_dark_oak_log
fill 64 224 329 64 225 329 minecraft:stripped_dark_oak_log
fill 64 224 331 64 225 331 minecraft:stripped_dark_oak_log
fill 65 224 324 65 225 324 minecraft:stripped_dark_oak_log
fill 65 224 326 65 225 326 minecraft:stripped_dark_oak_log
fill 65 224 328 65 225 328 minecraft:stripped_dark_oak_log
fill 65 224 330 65 225 330 minecraft:stripped_dark_oak_log
fill 66 224 323 66 225 323 minecraft:stripped_dark_oak_log
fill 66 224 325 66 225 325 minecraft:stripped_dark_oak_log
fill 66 224 327 66 225 327 minecraft:stripped_dark_oak_log
fill 66 224 329 66 225 329 minecraft:stripped_dark_oak_log
fill 66 224 331 66 225 331 minecraft:stripped_dark_oak_log
fill 67 224 324 67 225 324 minecraft:stripped_dark_oak_log
fill 67 224 326 67 225 326 minecraft:stripped_dark_oak_log
fill 67 224 328 67 225 328 minecraft:stripped_dark_oak_log
fill 67 224 330 67 225 330 minecraft:stripped_dark_oak_log
fill 68 224 323 68 225 323 minecraft:stripped_dark_oak_log
fill 68 224 325 68 225 325 minecraft:stripped_dark_oak_log
fill 68 224 327 68 225 327 minecraft:stripped_dark_oak_log
fill 68 224 329 68 225 329 minecraft:stripped_dark_oak_log
fill 68 224 331 68 225 331 minecraft:stripped_dark_oak_log
fill 69 224 324 69 225 324 minecraft:stripped_dark_oak_log
fill 69 224 326 69 225 326 minecraft:stripped_dark_oak_log
fill 69 224 328 69 225 328 minecraft:stripped_dark_oak_log
fill 69 224 330 69 225 330 minecraft:stripped_dark_oak_log
fill 79 224 328 79 225 328 minecraft:stripped_dark_oak_log
fill 79 224 330 79 225 330 minecraft:stripped_dark_oak_log
fill 79 224 332 79 225 332 minecraft:stripped_dark_oak_log
fill 79 224 334 79 225 334 minecraft:stripped_dark_oak_log
fill 79 224 336 79 225 336 minecraft:stripped_dark_oak_log
fill 80 224 327 80 225 327 minecraft:stripped_dark_oak_log
fill 80 224 329 80 225 329 minecraft:stripped_dark_oak_log
fill 80 224 331 80 225 331 minecraft:stripped_dark_oak_log
fill 80 224 333 80 225 333 minecraft:stripped_dark_oak_log
fill 80 224 335 80 225 335 minecraft:stripped_dark_oak_log
fill 80 224 337 80 225 337 minecraft:stripped_dark_oak_log
fill 81 224 328 81 225 328 minecraft:stripped_dark_oak_log
fill 81 224 330 81 225 330 minecraft:stripped_dark_oak_log
fill 81 224 332 81 225 332 minecraft:stripped_dark_oak_log
fill 81 224 334 81 225 334 minecraft:stripped_dark_oak_log
fill 81 224 336 81 225 336 minecraft:stripped_dark_oak_log
fill 82 224 327 82 225 327 minecraft:stripped_dark_oak_log
fill 82 224 329 82 225 329 minecraft:stripped_dark_oak_log
fill 82 224 331 82 225 331 minecraft:stripped_dark_oak_log
fill 82 224 333 82 225 333 minecraft:stripped_dark_oak_log
fill 82 224 335 82 225 335 minecraft:stripped_dark_oak_log
fill 82 224 337 82 225 337 minecraft:stripped_dark_oak_log
setblock 83 224 326 minecraft:dark_oak_planks
fill 83 224 328 83 225 328 minecraft:stripped_dark_oak_log
fill 83 224 330 83 225 330 minecraft:stripped_dark_oak_log
fill 83 224 332 83 225 332 minecraft:stripped_dark_oak_log
fill 83 224 334 83 225 334 minecraft:stripped_dark_oak_log
fill 83 224 336 83 225 336 minecraft:stripped_dark_oak_log
fill 84 224 325 85 224 325 minecraft:dark_oak_planks
fill 84 224 327 84 225 327 minecraft:stripped_dark_oak_log
fill 84 224 329 84 225 329 minecraft:stripped_dark_oak_log
fill 84 224 331 84 225 331 minecraft:stripped_dark_oak_log
fill 84 224 333 84 225 333 minecraft:stripped_dark_oak_log
fill 84 224 335 84 225 335 minecraft:stripped_dark_oak_log
fill 84 224 337 84 225 337 minecraft:stripped_dark_oak_log
fill 85 224 328 85 225 328 minecraft:stripped_dark_oak_log
fill 85 224 330 85 225 330 minecraft:stripped_dark_oak_log
fill 85 224 332 85 225 332 minecraft:stripped_dark_oak_log
fill 85 224 334 85 225 334 minecraft:stripped_dark_oak_log
fill 85 224 336 85 225 336 minecraft:stripped_dark_oak_log
setblock 86 224 326 minecraft:dark_oak_planks
fill 86 224 327 86 225 327 minecraft:stripped_dark_oak_log
fill 86 224 329 86 225 329 minecraft:stripped_dark_oak_log
fill 86 224 331 86 225 331 minecraft:stripped_dark_oak_log
fill 86 224 333 86 225 333 minecraft:stripped_dark_oak_log
fill 86 224 335 86 225 335 minecraft:stripped_dark_oak_log
fill 86 224 337 86 225 337 minecraft:stripped_dark_oak_log
fill 87 224 328 87 225 328 minecraft:stripped_dark_oak_log
fill 87 224 330 87 225 330 minecraft:stripped_dark_oak_log
fill 87 224 332 87 225 332 minecraft:stripped_dark_oak_log
fill 87 224 334 87 225 334 minecraft:stripped_dark_oak_log
fill 87 224 336 87 225 336 minecraft:stripped_dark_oak_log
fill 88 224 327 88 225 327 minecraft:stripped_dark_oak_log
fill 88 224 329 88 225 329 minecraft:stripped_dark_oak_log
fill 88 224 331 88 225 331 minecraft:stripped_dark_oak_log
fill 88 224 333 88 225 333 minecraft:stripped_dark_oak_log
fill 88 224 335 88 225 335 minecraft:stripped_dark_oak_log
fill 88 224 337 88 225 337 minecraft:stripped_dark_oak_log
setblock 48 225 329 minecraft:stripped_dark_oak_log
setblock 48 225 336 minecraft:stripped_dark_oak_log
setblock 48 225 343 minecraft:stripped_dark_oak_log
setblock 48 225 350 minecraft:stripped_dark_oak_log
setblock 48 225 357 minecraft:stripped_dark_oak_log
setblock 49 225 323 minecraft:stripped_dark_oak_log
setblock 49 225 363 minecraft:stripped_dark_oak_log
setblock 56 225 323 minecraft:stripped_dark_oak_log
setblock 56 225 363 minecraft:stripped_dark_oak_log
fill 62 225 364 62 243 364 minecraft:dark_oak_planks
setblock 63 225 363 minecraft:stripped_dark_oak_log
setblock 63 225 364 minecraft:red_concrete
fill 64 225 364 66 308 364 minecraft:dark_oak_planks
setblock 70 225 323 minecraft:stripped_dark_oak_log
setblock 70 225 363 minecraft:stripped_dark_oak_log
setblock 77 225 323 minecraft:stripped_dark_oak_log
setblock 77 225 363 minecraft:stripped_dark_oak_log
setblock 84 225 323 minecraft:stripped_dark_oak_log
setblock 84 225 363 minecraft:stripped_dark_oak_log
setblock 88 225 326 minecraft:stripped_dark_oak_log
setblock 88 225 340 minecraft:stripped_dark_oak_log
setblock 88 225 354 minecraft:stripped_dark_oak_log
setblock 88 225 361 minecraft:stripped_dark_oak_log
setblock 47 226 327 minecraft:red_concrete
fill 47 226 328 47 308 328 minecraft:dark_oak_planks
fill 47 226 339 47 308 341 minecraft:dark_oak_planks
setblock 48 226 323 minecraft:stripped_dark_oak_log
setblock 48 226 330 minecraft:stripped_dark_oak_log
setblock 48 226 337 minecraft:stripped_dark_oak_log
setblock 48 226 344 minecraft:stripped_dark_oak_log
fill 48 226 350 51 226 350 minecraft:dark_oak_planks
fill 48 226 351 48 227 351 minecraft:stripped_dark_oak_log
fill 48 226 352 51 226 355 minecraft:dark_oak_planks
fill 48 226 357 51 226 357 minecraft:dark_oak_planks
fill 48 226 358 48 227 358 minecraft:stripped_dark_oak_log
fill 48 226 359 50 226 360 minecraft:dark_oak_planks
fill 49 226 351 51 226 351 minecraft:dark_oak_planks
fill 49 226 356 51 226 356 minecraft:dark_oak_planks
fill 49 226 358 50 226 358 minecraft:dark_oak_planks
setblock 50 226 325 minecraft:light[level=15]
setblock 50 226 333 minecraft:light[level=15]
setblock 50 226 341 minecraft:light[level=15]
setblock 50 226 349 minecraft:light[level=15]
setblock 50 226 363 minecraft:stripped_dark_oak_log
setblock 55 226 323 minecraft:stripped_dark_oak_log
fill 55 226 364 57 308 364 minecraft:dark_oak_planks
setblock 57 226 363 minecraft:stripped_dark_oak_log
setblock 58 226 325 minecraft:light[level=15]
setblock 58 226 333 minecraft:light[level=15]
setblock 58 226 341 minecraft:light[level=15]
setblock 58 226 349 minecraft:light[level=15]
setblock 58 226 357 minecraft:light[level=15]
setblock 58 226 364 minecraft:red_concrete
fill 59 226 364 60 238 364 minecraft:dark_oak_planks
setblock 61 226 324 minecraft:shroomlight
setblock 61 226 326 minecraft:shroomlight
setblock 61 226 328 minecraft:shroomlight
setblock 61 226 330 minecraft:shroomlight
setblock 62 226 323 minecraft:shroomlight
setblock 62 226 325 minecraft:shroomlight
setblock 62 226 327 minecraft:shroomlight
setblock 62 226 329 minecraft:shroomlight
setblock 62 226 331 minecraft:shroomlight
setblock 63 226 324 minecraft:shroomlight
setblock 63 226 326 minecraft:shroomlight
setblock 63 226 328 minecraft:shroomlight
setblock 63 226 330 minecraft:shroomlight
fill 63 226 364 63 266 364 minecraft:dark_oak_planks
setblock 64 226 323 minecraft:shroomlight
setblock 64 226 325 minecraft:shroomlight
setblock 64 226 327 minecraft:shroomlight
setblock 64 226 329 minecraft:shroomlight
setblock 64 226 331 minecraft:shroomlight
setblock 64 226 363 minecraft:stripped_dark_oak_log
setblock 65 226 324 minecraft:shroomlight
setblock 65 226 326 minecraft:shroomlight
setblock 65 226 328 minecraft:shroomlight
setblock 65 226 330 minecraft:shroomlight
setblock 66 226 323 minecraft:shroomlight
setblock 66 226 325 minecraft:shroomlight
setblock 66 226 327 minecraft:shroomlight
setblock 66 226 329 minecraft:shroomlight
setblock 66 226 331 minecraft:shroomlight
setblock 66 226 333 minecraft:light[level=15]
setblock 66 226 341 minecraft:light[level=15]
setblock 66 226 349 minecraft:light[level=15]
setblock 66 226 357 minecraft:light[level=15]
setblock 67 226 324 minecraft:shroomlight
setblock 67 226 326 minecraft:shroomlight
setblock 67 226 328 minecraft:shroomlight
setblock 67 226 330 minecraft:shroomlight
setblock 68 226 323 minecraft:shroomlight
setblock 68 226 325 minecraft:shroomlight
setblock 68 226 327 minecraft:shroomlight
setblock 68 226 329 minecraft:shroomlight
setblock 68 226 331 minecraft:shroomlight
setblock 69 226 324 minecraft:shroomlight
setblock 69 226 326 minecraft:shroomlight
setblock 69 226 328 minecraft:shroomlight
setblock 69 226 330 minecraft:shroomlight
setblock 71 226 363 minecraft:stripped_dark_oak_log
setblock 74 226 325 minecraft:light[level=15]
setblock 74 226 333 minecraft:light[level=15]
setblock 74 226 341 minecraft:light[level=15]
setblock 74 226 349 minecraft:light[level=15]
setblock 74 226 357 minecraft:light[level=15]
setblock 76 226 323 minecraft:stripped_dark_oak_log
setblock 78 226 363 minecraft:stripped_dark_oak_log
setblock 79 226 328 minecraft:shroomlight
setblock 79 226 330 minecraft:shroomlight
setblock 79 226 332 minecraft:shroomlight
setblock 79 226 334 minecraft:shroomlight
setblock 79 226 336 minecraft:shroomlight
setblock 80 226 327 minecraft:shroomlight
setblock 80 226 329 minecraft:shroomlight
setblock 80 226 331 minecraft:shroomlight
setblock 80 226 333 minecraft:shroomlight
setblock 80 226 335 minecraft:shroomlight
setblock 80 226 337 minecraft:shroomlight
setblock 81 226 328 minecraft:shroomlight
setblock 81 226 330 minecraft:shroomlight
setblock 81 226 332 minecraft:shroomlight
setblock 81 226 334 minecraft:shroomlight
setblock 81 226 336 minecraft:shroomlight
setblock 82 226 325 minecraft:light[level=15]
setblock 82 226 327 minecraft:shroomlight
setblock 82 226 329 minecraft:shroomlight
setblock 82 226 331 minecraft:shroomlight
setblock 82 226 333 minecraft:shroomlight
setblock 82 226 335 minecraft:shroomlight
setblock 82 226 337 minecraft:shroomlight
setblock 82 226 341 minecraft:light[level=15]
setblock 82 226 357 minecraft:light[level=15]
setblock 83 226 323 minecraft:stripped_dark_oak_log
setblock 83 226 328 minecraft:shroomlight
setblock 83 226 330 minecraft:shroomlight
setblock 83 226 332 minecraft:shroomlight
setblock 83 226 334 minecraft:shroomlight
setblock 83 226 336 minecraft:shroomlight
setblock 84 226 327 minecraft:shroomlight
setblock 84 226 329 minecraft:shroomlight
setblock 84 226 331 minecraft:shroomlight
setblock 84 226 333 minecraft:shroomlight
setblock 84 226 335 minecraft:shroomlight
setblock 84 226 337 minecraft:shroomlight
setblock 85 226 328 minecraft:shroomlight
setblock 85 226 330 minecraft:shroomlight
setblock 85 226 332 minecraft:shroomlight
setblock 85 226 334 minecraft:shroomlight
setblock 85 226 336 minecraft:shroomlight
setblock 85 226 363 minecraft:stripped_dark_oak_log
setblock 86 226 327 minecraft:shroomlight
setblock 86 226 329 minecraft:shroomlight
setblock 86 226 331 minecraft:shroomlight
setblock 86 226 333 minecraft:shroomlight
setblock 86 226 335 minecraft:shroomlight
setblock 86 226 337 minecraft:shroomlight
fill 86 226 343 86 237 343 minecraft:red_wool
setblock 87 226 328 minecraft:shroomlight
setblock 87 226 330 minecraft:shroomlight
setblock 87 226 332 minecraft:shroomlight
setblock 87 226 334 minecraft:shroomlight
setblock 87 226 336 minecraft:shroomlight
setblock 88 226 325 minecraft:stripped_dark_oak_log
setblock 88 226 327 minecraft:shroomlight
setblock 88 226 329 minecraft:shroomlight
setblock 88 226 331 minecraft:shroomlight
setblock 88 226 333 minecraft:shroomlight
setblock 88 226 335 minecraft:shroomlight
setblock 88 226 337 minecraft:shroomlight
setblock 88 226 339 minecraft:stripped_dark_oak_log
setblock 88 226 353 minecraft:stripped_dark_oak_log
setblock 88 226 360 minecraft:stripped_dark_oak_log
fill 47 227 327 47 308 327 minecraft:dark_oak_planks
setblock 48 227 324 minecraft:stripped_dark_oak_log
setblock 48 227 331 minecraft:stripped_dark_oak_log
setblock 48 227 338 minecraft:stripped_dark_oak_log
setblock 48 227 345 minecraft:stripped_dark_oak_log
fill 48 227 350 51 227 350 minecraft:stripped_dark_oak_log
fill 48 227 352 51 227 355 minecraft:stripped_dark_oak_log
fill 48 227 357 51 227 357 minecraft:stripped_dark_oak_log
fill 48 227 359 50 227 360 minecraft:stripped_dark_oak_log
fill 49 227 351 51 227 351 minecraft:stripped_dark_oak_log
fill 49 227 356 51 227 356 minecraft:stripped_dark_oak_log
fill 49 227 358 50 227 358 minecraft:stripped_dark_oak_log
setblock 51 227 363 minecraft:stripped_dark_oak_log
setblock 54 227 323 minecraft:stripped_dark_oak_log
setblock 58 227 363 minecraft:stripped_dark_oak_log
fill 58 227 364 58 238 364 minecraft:dark_oak_planks
fill 61 227 324 61 228 324 minecraft:stripped_dark_oak_log
fill 61 227 326 61 228 326 minecraft:stripped_dark_oak_log
fill 61 227 328 61 228 328 minecraft:stripped_dark_oak_log
fill 61 227 330 61 228 330 minecraft:stripped_dark_oak_log
fill 62 227 323 62 228 323 minecraft:stripped_dark_oak_log
fill 62 227 325 62 228 325 minecraft:stripped_dark_oak_log
fill 62 227 327 62 228 327 minecraft:stripped_dark_oak_log
fill 62 227 329 62 228 329 minecraft:stripped_dark_oak_log
fill 62 227 331 62 228 331 minecraft:stripped_dark_oak_log
fill 63 227 324 63 228 324 minecraft:stripped_dark_oak_log
fill 63 227 326 63 228 326 minecraft:stripped_dark_oak_log
fill 63 227 328 63 228 328 minecraft:stripped_dark_oak_log
fill 63 227 330 63 228 330 minecraft:stripped_dark_oak_log
fill 64 227 323 64 228 323 minecraft:stripped_dark_oak_log
fill 64 227 325 64 228 325 minecraft:stripped_dark_oak_log
fill 64 227 327 64 228 327 minecraft:stripped_dark_oak_log
fill 64 227 329 64 228 329 minecraft:stripped_dark_oak_log
fill 64 227 331 64 228 331 minecraft:stripped_dark_oak_log
fill 65 227 324 65 228 324 minecraft:stripped_dark_oak_log
fill 65 227 326 65 228 326 minecraft:stripped_dark_oak_log
fill 65 227 328 65 228 328 minecraft:stripped_dark_oak_log
fill 65 227 330 65 228 330 minecraft:stripped_dark_oak_log
setblock 65 227 363 minecraft:stripped_dark_oak_log
fill 66 227 323 66 228 323 minecraft:stripped_dark_oak_log
fill 66 227 325 66 228 325 minecraft:stripped_dark_oak_log
fill 66 227 327 66 228 327 minecraft:stripped_dark_oak_log
fill 66 227 329 66 228 329 minecraft:stripped_dark_oak_log
fill 66 227 331 66 228 331 minecraft:stripped_dark_oak_log
fill 67 227 324 67 228 324 minecraft:stripped_dark_oak_log
fill 67 227 326 67 228 326 minecraft:stripped_dark_oak_log
fill 67 227 328 67 228 328 minecraft:stripped_dark_oak_log
fill 67 227 330 67 228 330 minecraft:stripped_dark_oak_log
fill 68 227 323 68 228 323 minecraft:stripped_dark_oak_log
fill 68 227 325 68 228 325 minecraft:stripped_dark_oak_log
fill 68 227 327 68 228 327 minecraft:stripped_dark_oak_log
fill 68 227 329 68 228 329 minecraft:stripped_dark_oak_log
fill 68 227 331 68 228 331 minecraft:stripped_dark_oak_log
fill 69 227 324 69 228 324 minecraft:stripped_dark_oak_log
fill 69 227 326 69 228 326 minecraft:stripped_dark_oak_log
fill 69 227 328 69 228 328 minecraft:stripped_dark_oak_log
fill 69 227 330 69 228 330 minecraft:stripped_dark_oak_log
setblock 71 227 322 minecraft:red_concrete
setblock 72 227 363 minecraft:stripped_dark_oak_log
setblock 75 227 323 minecraft:stripped_dark_oak_log
fill 79 227 328 79 228 328 minecraft:stripped_dark_oak_log
fill 79 227 330 79 228 330 minecraft:stripped_dark_oak_log
fill 79 227 332 79 228 332 minecraft:stripped_dark_oak_log
fill 79 227 334 79 228 334 minecraft:stripped_dark_oak_log
fill 79 227 336 79 228 336 minecraft:stripped_dark_oak_log
setblock 79 227 363 minecraft:stripped_dark_oak_log
fill 80 227 327 80 228 327 minecraft:stripped_dark_oak_log
fill 80 227 329 80 228 329 minecraft:stripped_dark_oak_log
fill 80 227 331 80 228 331 minecraft:stripped_dark_oak_log
fill 80 227 333 80 228 333 minecraft:stripped_dark_oak_log
fill 80 227 335 80 228 335 minecraft:stripped_dark_oak_log
fill 80 227 337 80 228 337 minecraft:stripped_dark_oak_log
fill 81 227 328 81 228 328 minecraft:stripped_dark_oak_log
fill 81 227 330 81 228 330 minecraft:stripped_dark_oak_log
fill 81 227 332 81 228 332 minecraft:stripped_dark_oak_log
fill 81 227 334 81 228 334 minecraft:stripped_dark_oak_log
fill 81 227 336 81 228 336 minecraft:stripped_dark_oak_log
setblock 82 227 323 minecraft:stripped_dark_oak_log
fill 82 227 327 82 228 327 minecraft:stripped_dark_oak_log
fill 82 227 329 82 228 329 minecraft:stripped_dark_oak_log
fill 82 227 331 82 228 331 minecraft:stripped_dark_oak_log
fill 82 227 333 82 228 333 minecraft:stripped_dark_oak_log
fill 82 227 335 82 228 335 minecraft:stripped_dark_oak_log
fill 82 227 337 82 228 337 minecraft:stripped_dark_oak_log
fill 83 227 328 83 228 328 minecraft:stripped_dark_oak_log
fill 83 227 330 83 228 330 minecraft:stripped_dark_oak_log
fill 83 227 332 83 228 332 minecraft:stripped_dark_oak_log
fill 83 227 334 83 228 334 minecraft:stripped_dark_oak_log
fill 83 227 336 83 228 336 minecraft:stripped_dark_oak_log
fill 84 227 327 84 228 327 minecraft:stripped_dark_oak_log
fill 84 227 329 84 228 329 minecraft:stripped_dark_oak_log
fill 84 227 331 84 228 331 minecraft:stripped_dark_oak_log
fill 84 227 333 84 228 333 minecraft:stripped_dark_oak_log
fill 84 227 335 84 228 335 minecraft:stripped_dark_oak_log
fill 84 227 337 84 228 337 minecraft:stripped_dark_oak_log
fill 85 227 328 85 228 328 minecraft:stripped_dark_oak_log
fill 85 227 330 85 228 330 minecraft:stripped_dark_oak_log
fill 85 227 332 85 228 332 minecraft:stripped_dark_oak_log
fill 85 227 334 85 228 334 minecraft:stripped_dark_oak_log
fill 85 227 336 85 228 336 minecraft:stripped_dark_oak_log
fill 86 227 327 86 228 327 minecraft:stripped_dark_oak_log
fill 86 227 329 86 228 329 minecraft:stripped_dark_oak_log
fill 86 227 331 86 228 331 minecraft:stripped_dark_oak_log
fill 86 227 333 86 228 333 minecraft:stripped_dark_oak_log
fill 86 227 335 86 228 335 minecraft:stripped_dark_oak_log
fill 86 227 337 86 228 337 minecraft:stripped_dark_oak_log
fill 86 227 341 86 237 342 minecraft:red_wool
fill 86 227 344 86 237 345 minecraft:red_wool
setblock 86 227 363 minecraft:stripped_dark_oak_log
fill 87 227 328 87 228 328 minecraft:stripped_dark_oak_log
fill 87 227 330 87 228 330 minecraft:stripped_dark_oak_log
fill 87 227 332 87 228 332 minecraft:stripped_dark_oak_log
fill 87 227 334 87 228 334 minecraft:stripped_dark_oak_log
fill 87 227 336 87 228 336 minecraft:stripped_dark_oak_log
setblock 88 227 324 minecraft:stripped_dark_oak_log
fill 88 227 327 88 228 327 minecraft:stripped_dark_oak_log
fill 88 227 329 88 228 329 minecraft:stripped_dark_oak_log
fill 88 227 331 88 228 331 minecraft:stripped_dark_oak_log
fill 88 227 333 88 228 333 minecraft:stripped_dark_oak_log
fill 88 227 335 88 228 335 minecraft:stripped_dark_oak_log
fill 88 227 337 88 227 338 minecraft:stripped_dark_oak_log
setblock 88 227 345 minecraft:stripped_dark_oak_log
setblock 88 227 359 minecraft:stripped_dark_oak_log
fill 47 228 353 47 308 353 minecraft:dark_oak_planks
fill 47 228 354 47 231 356 minecraft:shroomlight
fill 47 228 357 47 240 362 minecraft:dark_oak_planks
setblock 48 228 325 minecraft:stripped_dark_oak_log
setblock 48 228 332 minecraft:stripped_dark_oak_log
setblock 48 228 339 minecraft:stripped_dark_oak_log
setblock 48 228 346 minecraft:stripped_dark_oak_log
setblock 48 228 353 minecraft:stripped_dark_oak_log
setblock 48 228 360 minecraft:stripped_dark_oak_log
setblock 50 228 325 minecraft:light[level=12]
setblock 50 228 332 minecraft:light[level=12]
setblock 50 228 339 minecraft:light[level=12]
setblock 50 228 346 minecraft:light[level=12]
setblock 50 228 353 minecraft:light[level=12]
setblock 50 228 360 minecraft:light[level=12]
fill 51 228 350 51 228 357 minecraft:red_concrete
setblock 52 228 363 minecraft:stripped_dark_oak_log
setblock 53 228 323 minecraft:stripped_dark_oak_log
setblock 57 228 325 minecraft:light[level=12]
setblock 57 228 332 minecraft:light[level=12]
setblock 57 228 339 minecraft:light[level=12]
setblock 57 228 346 minecraft:light[level=12]
setblock 57 228 353 minecraft:light[level=12]
setblock 57 228 360 minecraft:light[level=12]
setblock 59 228 363 minecraft:stripped_dark_oak_log
setblock 60 228 323 minecraft:stripped_dark_oak_log
setblock 64 228 332 minecraft:light[level=12]
setblock 64 228 339 minecraft:light[level=12]
setblock 64 228 346 minecraft:light[level=12]
setblock 64 228 353 minecraft:light[level=12]
setblock 64 228 360 minecraft:light[level=12]
setblock 66 228 363 minecraft:stripped_dark_oak_log
fill 71 228 322 71 308 322 minecraft:dark_oak_planks
setblock 71 228 325 minecraft:light[level=12]
setblock 71 228 332 minecraft:light[level=12]
setblock 71 228 339 minecraft:light[level=12]
setblock 71 228 346 minecraft:light[level=12]
setblock 71 228 353 minecraft:light[level=12]
setblock 71 228 360 minecraft:light[level=12]
setblock 73 228 363 minecraft:stripped_dark_oak_log
setblock 74 228 323 minecraft:stripped_dark_oak_log
setblock 78 228 325 minecraft:light[level=12]
setblock 78 228 332 minecraft:light[level=12]
setblock 78 228 339 minecraft:light[level=12]
setblock 78 228 346 minecraft:light[level=12]
setblock 78 228 353 minecraft:light[level=12]
setblock 78 228 360 minecraft:light[level=12]
setblock 80 228 363 minecraft:stripped_dark_oak_log
setblock 81 228 323 minecraft:stripped_dark_oak_log
setblock 81 228 364 minecraft:red_concrete
fill 82 228 364 89 235 364 minecraft:dark_oak_planks
setblock 85 228 325 minecraft:light[level=12]
setblock 85 228 339 minecraft:light[level=12]
setblock 85 228 353 minecraft:light[level=12]
setblock 85 228 360 minecraft:light[level=12]
setblock 87 228 363 minecraft:stripped_dark_oak_log
setblock 88 228 323 minecraft:stripped_dark_oak_log
setblock 88 228 337 minecraft:stripped_dark_oak_log
setblock 88 228 344 minecraft:stripped_dark_oak_log
setblock 88 228 358 minecraft:stripped_dark_oak_log
fill 48 229 326 48 230 326 minecraft:stripped_dark_oak_log
fill 48 229 333 48 230 333 minecraft:stripped_dark_oak_log
fill 48 229 340 48 230 340 minecraft:stripped_dark_oak_log
fill 48 229 347 48 230 347 minecraft:stripped_dark_oak_log
fill 48 229 354 48 230 354 minecraft:stripped_dark_oak_log
fill 48 229 361 48 230 361 minecraft:stripped_dark_oak_log
setblock 51 229 350 minecraft:stripped_dark_oak_log
setblock 51 229 355 minecraft:stripped_dark_oak_log
fill 52 229 323 52 230 323 minecraft:stripped_dark_oak_log
fill 53 229 363 53 230 363 minecraft:stripped_dark_oak_log
fill 59 229 323 59 230 323 minecraft:stripped_dark_oak_log
fill 60 229 363 60 230 363 minecraft:stripped_dark_oak_log
setblock 61 229 324 minecraft:shroomlight
setblock 61 229 326 minecraft:shroomlight
setblock 61 229 328 minecraft:shroomlight
setblock 61 229 330 minecraft:shroomlight
setblock 62 229 323 minecraft:shroomlight
setblock 62 229 325 minecraft:shroomlight
setblock 62 229 327 minecraft:shroomlight
setblock 62 229 329 minecraft:shroomlight
setblock 62 229 331 minecraft:shroomlight
setblock 63 229 324 minecraft:shroomlight
setblock 63 229 326 minecraft:shroomlight
setblock 63 229 328 minecraft:shroomlight
setblock 63 229 330 minecraft:shroomlight
setblock 64 229 323 minecraft:shroomlight
setblock 64 229 325 minecraft:shroomlight
setblock 64 229 327 minecraft:shroomlight
setblock 64 229 329 minecraft:shroomlight
setblock 64 229 331 minecraft:shroomlight
setblock 65 229 324 minecraft:shroomlight
setblock 65 229 326 minecraft:shroomlight
setblock 65 229 328 minecraft:shroomlight
setblock 65 229 330 minecraft:shroomlight
setblock 66 229 323 minecraft:shroomlight
setblock 66 229 325 minecraft:shroomlight
setblock 66 229 327 minecraft:shroomlight
setblock 66 229 329 minecraft:shroomlight
setblock 66 229 331 minecraft:shroomlight
setblock 67 229 324 minecraft:shroomlight
setblock 67 229 326 minecraft:shroomlight
setblock 67 229 328 minecraft:shroomlight
setblock 67 229 330 minecraft:shroomlight
fill 67 229 363 67 230 363 minecraft:stripped_dark_oak_log
setblock 68 229 323 minecraft:shroomlight
setblock 68 229 325 minecraft:shroomlight
setblock 68 229 327 minecraft:shroomlight
setblock 68 229 329 minecraft:shroomlight
setblock 68 229 331 minecraft:shroomlight
setblock 69 229 324 minecraft:shroomlight
setblock 69 229 326 minecraft:shroomlight
setblock 69 229 328 minecraft:shroomlight
setblock 69 229 330 minecraft:shroomlight
setblock 72 229 322 minecraft:red_concrete
fill 73 229 322 73 231 322 minecraft:dark_oak_planks
fill 73 229 323 73 230 323 minecraft:stripped_dark_oak_log
fill 74 229 363 74 230 363 minecraft:stripped_dark_oak_log
setblock 79 229 328 minecraft:shroomlight
setblock 79 229 330 minecraft:shroomlight
setblock 79 229 332 minecraft:shroomlight
setblock 79 229 334 minecraft:shroomlight
setblock 79 229 336 minecraft:shroomlight
fill 80 229 323 80 230 323 minecraft:stripped_dark_oak_log
setblock 80 229 327 minecraft:shroomlight
setblock 80 229 329 minecraft:shroomlight
setblock 80 229 331 minecraft:shroomlight
setblock 80 229 333 minecraft:shroomlight
setblock 80 229 335 minecraft:shroomlight
setblock 80 229 337 minecraft:shroomlight
setblock 81 229 328 minecraft:shroomlight
setblock 81 229 330 minecraft:shroomlight
setblock 81 229 332 minecraft:shroomlight
setblock 81 229 334 minecraft:shroomlight
setblock 81 229 336 minecraft:shroomlight
fill 81 229 363 81 230 363 minecraft:stripped_dark_oak_log
fill 81 229 364 81 308 364 minecraft:dark_oak_planks
setblock 82 229 327 minecraft:shroomlight
setblock 82 229 329 minecraft:shroomlight
setblock 82 229 331 minecraft:shroomlight
setblock 82 229 333 minecraft:shroomlight
setblock 82 229 335 minecraft:shroomlight
setblock 82 229 337 minecraft:shroomlight
setblock 83 229 328 minecraft:shroomlight
setblock 83 229 330 minecraft:shroomlight
setblock 83 229 332 minecraft:shroomlight
setblock 83 229 334 minecraft:shroomlight
setblock 83 229 336 minecraft:shroomlight
setblock 84 229 327 minecraft:shroomlight
setblock 84 229 329 minecraft:shroomlight
setblock 84 229 331 minecraft:shroomlight
setblock 84 229 333 minecraft:shroomlight
setblock 84 229 335 minecraft:shroomlight
setblock 84 229 337 minecraft:shroomlight
fill 84 229 345 84 230 345 minecraft:shroomlight
setblock 85 229 328 minecraft:shroomlight
setblock 85 229 330 minecraft:shroomlight
setblock 85 229 332 minecraft:shroomlight
setblock 85 229 334 minecraft:shroomlight
setblock 85 229 336 minecraft:shroomlight
setblock 86 229 327 minecraft:shroomlight
setblock 86 229 329 minecraft:shroomlight
setblock 86 229 331 minecraft:shroomlight
setblock 86 229 333 minecraft:shroomlight
setblock 86 229 335 minecraft:shroomlight
setblock 86 229 337 minecraft:shroomlight
fill 87 229 323 87 230 323 minecraft:stripped_dark_oak_log
setblock 87 229 328 minecraft:shroomlight
setblock 87 229 330 minecraft:shroomlight
setblock 87 229 332 minecraft:shroomlight
setblock 87 229 334 minecraft:shroomlight
setblock 87 229 336 minecraft:shroomlight
setblock 88 229 327 minecraft:shroomlight
setblock 88 229 329 minecraft:shroomlight
setblock 88 229 331 minecraft:shroomlight
setblock 88 229 333 minecraft:shroomlight
setblock 88 229 335 minecraft:shroomlight
setblock 88 229 337 minecraft:shroomlight
fill 88 229 343 88 230 343 minecraft:stripped_dark_oak_log
fill 88 229 357 88 230 357 minecraft:stripped_dark_oak_log
fill 88 229 363 88 230 363 minecraft:stripped_dark_oak_log
fill 48 230 323 48 230 325 minecraft:stripped_dark_oak_log
setblock 48 230 327 minecraft:stripped_dark_oak_log
fill 48 230 329 48 230 332 minecraft:stripped_dark_oak_log
setblock 48 230 334 minecraft:stripped_dark_oak_log
fill 48 230 336 48 230 339 minecraft:stripped_dark_oak_log
setblock 48 230 341 minecraft:stripped_dark_oak_log
fill 48 230 343 48 230 346 minecraft:stripped_dark_oak_log
setblock 48 230 348 minecraft:stripped_dark_oak_log
fill 48 230 350 48 230 353 minecraft:stripped_dark_oak_log
setblock 48 230 355 minecraft:stripped_dark_oak_log
fill 48 230 357 48 230 360 minecraft:stripped_dark_oak_log
setblock 48 230 362 minecraft:stripped_dark_oak_log
setblock 49 230 323 minecraft:stripped_dark_oak_log
fill 49 230 363 52 230 363 minecraft:stripped_dark_oak_log
setblock 51 230 323 minecraft:stripped_dark_oak_log
fill 53 230 323 56 230 323 minecraft:stripped_dark_oak_log
setblock 54 230 363 minecraft:stripped_dark_oak_log
fill 56 230 363 59 230 363 minecraft:stripped_dark_oak_log
fill 58 230 322 58 308 322 minecraft:dark_oak_planks
setblock 58 230 323 minecraft:stripped_dark_oak_log
setblock 59 230 322 minecraft:red_concrete
fill 60 230 322 63 261 322 minecraft:dark_oak_planks
setblock 60 230 323 minecraft:stripped_dark_oak_log
fill 61 230 324 61 231 324 minecraft:stripped_dark_oak_log
fill 61 230 326 61 231 326 minecraft:stripped_dark_oak_log
fill 61 230 328 61 231 328 minecraft:stripped_dark_oak_log
fill 61 230 330 61 231 330 minecraft:stripped_dark_oak_log
setblock 61 230 363 minecraft:stripped_dark_oak_log
fill 62 230 323 62 231 323 minecraft:stripped_dark_oak_log
fill 62 230 325 62 231 325 minecraft:stripped_dark_oak_log
fill 62 230 327 62 231 327 minecraft:stripped_dark_oak_log
fill 62 230 329 62 231 329 minecraft:stripped_dark_oak_log
fill 62 230 331 62 231 331 minecraft:stripped_dark_oak_log
fill 63 230 324 63 231 324 minecraft:stripped_dark_oak_log
fill 63 230 326 63 231 326 minecraft:stripped_dark_oak_log
fill 63 230 328 63 231 328 minecraft:stripped_dark_oak_log
fill 63 230 330 63 231 330 minecraft:stripped_dark_oak_log
fill 63 230 363 66 230 363 minecraft:stripped_dark_oak_log
fill 64 230 323 64 231 323 minecraft:stripped_dark_oak_log
fill 64 230 325 64 231 325 minecraft:stripped_dark_oak_log
fill 64 230 327 64 231 327 minecraft:stripped_dark_oak_log
fill 64 230 329 64 231 329 minecraft:stripped_dark_oak_log
fill 64 230 331 64 231 331 minecraft:stripped_dark_oak_log
fill 65 230 324 65 231 324 minecraft:stripped_dark_oak_log
fill 65 230 326 65 231 326 minecraft:stripped_dark_oak_log
fill 65 230 328 65 231 328 minecraft:stripped_dark_oak_log
fill 65 230 330 65 231 330 minecraft:stripped_dark_oak_log
fill 66 230 323 66 231 323 minecraft:stripped_dark_oak_log
fill 66 230 325 66 231 325 minecraft:stripped_dark_oak_log
fill 66 230 327 66 231 327 minecraft:stripped_dark_oak_log
fill 66 230 329 66 231 329 minecraft:stripped_dark_oak_log
fill 66 230 331 66 231 331 minecraft:stripped_dark_oak_log
fill 67 230 324 67 231 324 minecraft:stripped_dark_oak_log
fill 67 230 326 67 231 326 minecraft:stripped_dark_oak_log
fill 67 230 328 67 231 328 minecraft:stripped_dark_oak_log
fill 67 230 330 67 231 330 minecraft:stripped_dark_oak_log
fill 68 230 323 68 231 323 minecraft:stripped_dark_oak_log
fill 68 230 325 68 231 325 minecraft:stripped_dark_oak_log
fill 68 230 327 68 231 327 minecraft:stripped_dark_oak_log
fill 68 230 329 68 231 329 minecraft:stripped_dark_oak_log
fill 68 230 331 68 231 331 minecraft:stripped_dark_oak_log
setblock 68 230 363 minecraft:stripped_dark_oak_log
fill 69 230 324 69 231 324 minecraft:stripped_dark_oak_log
fill 69 230 326 69 231 326 minecraft:stripped_dark_oak_log
fill 69 230 328 69 231 328 minecraft:stripped_dark_oak_log
fill 69 230 330 69 231 330 minecraft:stripped_dark_oak_log
setblock 70 230 323 minecraft:stripped_dark_oak_log
fill 70 230 363 73 230 363 minecraft:stripped_dark_oak_log
fill 72 230 322 72 308 322 minecraft:dark_oak_planks
setblock 72 230 323 minecraft:stripped_dark_oak_log
fill 74 230 323 77 230 323 minecraft:stripped_dark_oak_log
setblock 75 230 363 minecraft:stripped_dark_oak_log
fill 77 230 363 80 230 363 minecraft:stripped_dark_oak_log
setblock 79 230 323 minecraft:stripped_dark_oak_log
fill 79 230 328 79 232 328 minecraft:stripped_dark_oak_log
fill 79 230 330 79 232 330 minecraft:stripped_dark_oak_log
fill 79 230 332 79 232 332 minecraft:stripped_dark_oak_log
fill 79 230 334 79 232 334 minecraft:stripped_dark_oak_log
fill 79 230 336 79 232 336 minecraft:stripped_dark_oak_log
fill 80 230 327 80 232 327 minecraft:stripped_dark_oak_log
fill 80 230 329 80 232 329 minecraft:stripped_dark_oak_log
fill 80 230 331 80 232 331 minecraft:stripped_dark_oak_log
fill 80 230 333 80 232 333 minecraft:stripped_dark_oak_log
fill 80 230 335 80 232 335 minecraft:stripped_dark_oak_log
fill 80 230 337 80 232 337 minecraft:stripped_dark_oak_log
fill 81 230 323 84 230 323 minecraft:stripped_dark_oak_log
fill 81 230 328 81 232 328 minecraft:stripped_dark_oak_log
fill 81 230 330 81 232 330 minecraft:stripped_dark_oak_log
fill 81 230 332 81 232 332 minecraft:stripped_dark_oak_log
fill 81 230 334 81 232 334 minecraft:stripped_dark_oak_log
fill 81 230 336 81 232 336 minecraft:stripped_dark_oak_log
setblock 81 230 361 minecraft:red_concrete
fill 82 230 327 82 232 327 minecraft:stripped_dark_oak_log
fill 82 230 329 82 232 329 minecraft:stripped_dark_oak_log
fill 82 230 331 82 232 331 minecraft:stripped_dark_oak_log
fill 82 230 333 82 232 333 minecraft:stripped_dark_oak_log
fill 82 230 335 82 232 335 minecraft:stripped_dark_oak_log
fill 82 230 337 82 232 337 minecraft:stripped_dark_oak_log
setblock 82 230 363 minecraft:stripped_dark_oak_log
fill 83 230 328 83 232 328 minecraft:stripped_dark_oak_log
fill 83 230 330 83 232 330 minecraft:stripped_dark_oak_log
fill 83 230 332 83 232 332 minecraft:stripped_dark_oak_log
fill 83 230 334 83 232 334 minecraft:stripped_dark_oak_log
fill 83 230 336 83 232 336 minecraft:stripped_dark_oak_log
fill 84 230 327 84 269 327 minecraft:stripped_dark_oak_log
fill 84 230 329 84 232 329 minecraft:stripped_dark_oak_log
fill 84 230 331 84 232 331 minecraft:stripped_dark_oak_log
fill 84 230 333 84 232 333 minecraft:stripped_dark_oak_log
fill 84 230 335 84 232 335 minecraft:stripped_dark_oak_log
fill 84 230 337 84 232 337 minecraft:stripped_dark_oak_log
fill 84 230 363 87 230 363 minecraft:stripped_dark_oak_log
fill 85 230 328 85 232 328 minecraft:stripped_dark_oak_log
fill 85 230 330 85 232 330 minecraft:stripped_dark_oak_log
fill 85 230 332 85 232 332 minecraft:stripped_dark_oak_log
fill 85 230 334 85 232 334 minecraft:stripped_dark_oak_log
fill 85 230 336 85 232 336 minecraft:stripped_dark_oak_log
setblock 86 230 323 minecraft:stripped_dark_oak_log
fill 86 230 327 86 269 327 minecraft:stripped_dark_oak_log
fill 86 230 329 86 232 329 minecraft:stripped_dark_oak_log
fill 86 230 331 86 232 331 minecraft:stripped_dark_oak_log
fill 86 230 333 86 232 333 minecraft:stripped_dark_oak_log
fill 86 230 335 86 232 335 minecraft:stripped_dark_oak_log
fill 86 230 337 86 232 337 minecraft:stripped_dark_oak_log
fill 87 230 328 87 232 328 minecraft:stripped_dark_oak_log
fill 87 230 330 87 232 330 minecraft:stripped_dark_oak_log
fill 87 230 332 87 232 332 minecraft:stripped_dark_oak_log
fill 87 230 334 87 232 334 minecraft:stripped_dark_oak_log
fill 87 230 336 87 232 336 minecraft:stripped_dark_oak_log
fill 88 230 323 88 230 327 minecraft:stripped_dark_oak_log
fill 88 230 329 88 232 329 minecraft:stripped_dark_oak_log
fill 88 230 331 88 232 331 minecraft:stripped_dark_oak_log
fill 88 230 333 88 232 333 minecraft:stripped_dark_oak_log
fill 88 230 335 88 232 335 minecraft:stripped_dark_oak_log
fill 88 230 337 88 230 340 minecraft:stripped_dark_oak_log
setblock 88 230 342 minecraft:stripped_dark_oak_log
fill 88 230 344 88 230 345 minecraft:stripped_dark_oak_log
fill 88 230 353 88 230 354 minecraft:stripped_dark_oak_log
setblock 88 230 356 minecraft:stripped_dark_oak_log
fill 88 230 358 88 230 361 minecraft:stripped_dark_oak_log
fill 47 231 332 47 308 332 minecraft:dark_oak_planks
setblock 47 231 333 minecraft:red_concrete
fill 59 231 322 59 258 322 minecraft:dark_oak_planks
fill 80 231 344 80 232 344 minecraft:stripped_dark_oak_log
fill 80 231 346 80 232 348 minecraft:stripped_dark_oak_log
fill 81 231 361 81 232 361 minecraft:shroomlight
fill 84 231 345 84 239 345 minecraft:dark_oak_planks
fill 88 231 327 88 269 327 minecraft:stripped_dark_oak_log
fill 88 231 337 88 232 337 minecraft:stripped_dark_oak_log
fill 47 232 333 47 308 333 minecraft:dark_oak_planks
fill 47 232 354 47 277 356 minecraft:dark_oak_planks
setblock 48 232 329 minecraft:stripped_dark_oak_log
setblock 48 232 336 minecraft:stripped_dark_oak_log
setblock 48 232 343 minecraft:stripped_dark_oak_log
setblock 48 232 350 minecraft:stripped_dark_oak_log
setblock 48 232 357 minecraft:stripped_dark_oak_log
setblock 49 232 323 minecraft:stripped_dark_oak_log
setblock 49 232 363 minecraft:stripped_dark_oak_log
fill 50 232 358 50 232 361 minecraft:dark_oak_planks
fill 51 232 357 52 232 357 minecraft:dark_oak_planks
setblock 51 232 361 minecraft:dark_oak_planks
fill 53 232 358 54 232 358 minecraft:dark_oak_planks
setblock 53 232 361 minecraft:dark_oak_planks
fill 54 232 359 54 232 360 minecraft:dark_oak_planks
setblock 56 232 323 minecraft:stripped_dark_oak_log
setblock 56 232 363 minecraft:stripped_dark_oak_log
setblock 61 232 324 minecraft:shroomlight
setblock 61 232 326 minecraft:shroomlight
setblock 61 232 328 minecraft:shroomlight
setblock 61 232 330 minecraft:shroomlight
setblock 62 232 323 minecraft:shroomlight
setblock 62 232 325 minecraft:shroomlight
setblock 62 232 327 minecraft:shroomlight
setblock 62 232 329 minecraft:shroomlight
setblock 62 232 331 minecraft:shroomlight
setblock 63 232 324 minecraft:shroomlight
setblock 63 232 326 minecraft:shroomlight
setblock 63 232 328 minecraft:shroomlight
setblock 63 232 330 minecraft:shroomlight
setblock 63 232 363 minecraft:stripped_dark_oak_log
setblock 64 232 323 minecraft:shroomlight
setblock 64 232 325 minecraft:shroomlight
setblock 64 232 327 minecraft:shroomlight
setblock 64 232 329 minecraft:shroomlight
setblock 64 232 331 minecraft:shroomlight
setblock 65 232 324 minecraft:shroomlight
setblock 65 232 326 minecraft:shroomlight
setblock 65 232 328 minecraft:shroomlight
setblock 65 232 330 minecraft:shroomlight
setblock 66 232 323 minecraft:shroomlight
setblock 66 232 325 minecraft:shroomlight
setblock 66 232 327 minecraft:shroomlight
setblock 66 232 329 minecraft:shroomlight
setblock 66 232 331 minecraft:shroomlight
setblock 67 232 324 minecraft:shroomlight
setblock 67 232 326 minecraft:shroomlight
setblock 67 232 328 minecraft:shroomlight
setblock 67 232 330 minecraft:shroomlight
setblock 68 232 323 minecraft:shroomlight
setblock 68 232 325 minecraft:shroomlight
setblock 68 232 327 minecraft:shroomlight
setblock 68 232 329 minecraft:shroomlight
setblock 68 232 331 minecraft:shroomlight
setblock 69 232 324 minecraft:shroomlight
setblock 69 232 326 minecraft:shroomlight
setblock 69 232 328 minecraft:shroomlight
setblock 69 232 330 minecraft:shroomlight
setblock 70 232 323 minecraft:stripped_dark_oak_log
setblock 70 232 363 minecraft:stripped_dark_oak_log
setblock 73 232 322 minecraft:red_concrete
fill 74 232 322 75 275 322 minecraft:dark_oak_planks
setblock 76 232 322 minecraft:red_concrete
fill 77 232 322 77 308 322 minecraft:dark_oak_planks
setblock 77 232 323 minecraft:stripped_dark_oak_log
setblock 77 232 363 minecraft:stripped_dark_oak_log
setblock 83 232 326 minecraft:dark_oak_planks
fill 83 232 345 83 239 345 minecraft:dark_oak_planks
setblock 84 232 323 minecraft:stripped_dark_oak_log
fill 84 232 325 85 232 325 minecraft:dark_oak_planks
setblock 84 232 363 minecraft:stripped_dark_oak_log
setblock 86 232 326 minecraft:dark_oak_planks
setblock 88 232 326 minecraft:stripped_dark_oak_log
setblock 88 232 340 minecraft:stripped_dark_oak_log
setblock 88 232 354 minecraft:stripped_dark_oak_log
setblock 88 232 361 minecraft:stripped_dark_oak_log
setblock 89 232 358 minecraft:red_concrete
fill 89 232 359 89 308 359 minecraft:dark_oak_planks
setblock 48 233 323 minecraft:stripped_dark_oak_log
setblock 48 233 330 minecraft:stripped_dark_oak_log
setblock 48 233 337 minecraft:stripped_dark_oak_log
setblock 48 233 344 minecraft:stripped_dark_oak_log
setblock 48 233 351 minecraft:stripped_dark_oak_log
setblock 48 233 358 minecraft:stripped_dark_oak_log
setblock 50 233 363 minecraft:stripped_dark_oak_log
setblock 55 233 323 minecraft:stripped_dark_oak_log
setblock 57 233 363 minecraft:stripped_dark_oak_log
fill 61 233 324 61 234 324 minecraft:stripped_dark_oak_log
fill 61 233 326 61 234 326 minecraft:stripped_dark_oak_log
fill 61 233 328 61 234 328 minecraft:stripped_dark_oak_log
fill 61 233 330 61 234 330 minecraft:stripped_dark_oak_log
fill 62 233 323 62 234 323 minecraft:stripped_dark_oak_log
fill 62 233 325 62 234 325 minecraft:stripped_dark_oak_log
fill 62 233 327 62 234 327 minecraft:stripped_dark_oak_log
fill 62 233 329 62 234 329 minecraft:stripped_dark_oak_log
fill 62 233 331 62 234 331 minecraft:stripped_dark_oak_log
fill 63 233 324 63 234 324 minecraft:stripped_dark_oak_log
fill 63 233 326 63 234 326 minecraft:stripped_dark_oak_log
fill 63 233 328 63 234 328 minecraft:stripped_dark_oak_log
fill 63 233 330 63 234 330 minecraft:stripped_dark_oak_log
fill 64 233 323 64 234 323 minecraft:stripped_dark_oak_log
fill 64 233 325 64 234 325 minecraft:stripped_dark_oak_log
fill 64 233 327 64 234 327 minecraft:stripped_dark_oak_log
fill 64 233 329 64 234 329 minecraft:stripped_dark_oak_log
fill 64 233 331 64 234 331 minecraft:stripped_dark_oak_log
setblock 64 233 363 minecraft:stripped_dark_oak_log
fill 65 233 324 65 234 324 minecraft:stripped_dark_oak_log
fill 65 233 326 65 234 326 minecraft:stripped_dark_oak_log
fill 65 233 328 65 234 328 minecraft:stripped_dark_oak_log
fill 65 233 330 65 234 330 minecraft:stripped_dark_oak_log
fill 66 233 323 66 234 323 minecraft:stripped_dark_oak_log
fill 66 233 325 66 234 325 minecraft:stripped_dark_oak_log
fill 66 233 327 66 234 327 minecraft:stripped_dark_oak_log
fill 66 233 329 66 234 329 minecraft:stripped_dark_oak_log
fill 66 233 331 66 234 331 minecraft:stripped_dark_oak_log
fill 67 233 324 67 234 324 minecraft:stripped_dark_oak_log
fill 67 233 326 67 234 326 minecraft:stripped_dark_oak_log
fill 67 233 328 67 234 328 minecraft:stripped_dark_oak_log
fill 67 233 330 67 234 330 minecraft:stripped_dark_oak_log
fill 68 233 323 68 234 323 minecraft:stripped_dark_oak_log
fill 68 233 325 68 234 325 minecraft:stripped_dark_oak_log
fill 68 233 327 68 234 327 minecraft:stripped_dark_oak_log
fill 68 233 329 68 234 329 minecraft:stripped_dark_oak_log
fill 68 233 331 68 234 331 minecraft:stripped_dark_oak_log
fill 69 233 324 69 234 324 minecraft:stripped_dark_oak_log
fill 69 233 326 69 234 326 minecraft:stripped_dark_oak_log
fill 69 233 328 69 234 328 minecraft:stripped_dark_oak_log
fill 69 233 330 69 234 330 minecraft:stripped_dark_oak_log
setblock 71 233 363 minecraft:stripped_dark_oak_log
fill 73 233 322 73 308 322 minecraft:dark_oak_planks
fill 76 233 322 76 308 322 minecraft:dark_oak_planks
setblock 76 233 323 minecraft:stripped_dark_oak_log
setblock 78 233 363 minecraft:stripped_dark_oak_log
fill 80 233 328 87 233 336 minecraft:red_concrete
fill 81 233 347 87 233 351 minecraft:red_concrete
setblock 81 233 361 minecraft:red_concrete
setblock 83 233 323 minecraft:stripped_dark_oak_log
fill 83 233 346 85 239 346 minecraft:dark_oak_planks
fill 84 233 344 84 239 344 minecraft:dark_oak_planks
fill 85 233 345 85 239 345 minecraft:dark_oak_planks
setblock 85 233 363 minecraft:stripped_dark_oak_log
setblock 88 233 325 minecraft:stripped_dark_oak_log
setblock 88 233 339 minecraft:stripped_dark_oak_log
setblock 88 233 346 minecraft:stripped_dark_oak_log
fill 88 233 348 88 269 348 minecraft:stripped_dark_oak_log
setblock 88 233 353 minecraft:stripped_dark_oak_log
setblock 88 233 360 minecraft:stripped_dark_oak_log
fill 89 233 358 89 308 358 minecraft:dark_oak_planks
setblock 48 234 324 minecraft:stripped_dark_oak_log
setblock 48 234 331 minecraft:stripped_dark_oak_log
setblock 48 234 338 minecraft:stripped_dark_oak_log
setblock 48 234 345 minecraft:stripped_dark_oak_log
setblock 48 234 352 minecraft:stripped_dark_oak_log
setblock 48 234 359 minecraft:stripped_dark_oak_log
setblock 50 234 325 minecraft:light[level=15]
setblock 50 234 332 minecraft:light[level=12]
setblock 50 234 333 minecraft:light[level=15]
setblock 50 234 339 minecraft:light[level=12]
setblock 50 234 341 minecraft:light[level=15]
setblock 50 234 346 minecraft:light[level=12]
setblock 50 234 349 minecraft:light[level=15]
setblock 50 234 353 minecraft:light[level=12]
setblock 50 234 357 minecraft:light[level=15]
setblock 50 234 360 minecraft:light[level=12]
setblock 51 234 363 minecraft:stripped_dark_oak_log
setblock 54 234 323 minecraft:stripped_dark_oak_log
setblock 57 234 325 minecraft:light[level=12]
setblock 57 234 332 minecraft:light[level=12]
setblock 57 234 339 minecraft:light[level=12]
setblock 57 234 346 minecraft:light[level=12]
setblock 57 234 353 minecraft:light[level=12]
setblock 57 234 360 minecraft:light[level=12]
setblock 58 234 325 minecraft:light[level=15]
setblock 58 234 333 minecraft:light[level=15]
setblock 58 234 341 minecraft:light[level=15]
setblock 58 234 349 minecraft:light[level=15]
setblock 58 234 357 minecraft:light[level=15]
setblock 58 234 363 minecraft:stripped_dark_oak_log
setblock 64 234 332 minecraft:light[level=12]
setblock 64 234 339 minecraft:light[level=12]
setblock 64 234 346 minecraft:light[level=12]
setblock 64 234 353 minecraft:light[level=12]
setblock 64 234 360 minecraft:light[level=12]
setblock 65 234 363 minecraft:stripped_dark_oak_log
setblock 66 234 333 minecraft:light[level=15]
setblock 66 234 341 minecraft:light[level=15]
setblock 66 234 349 minecraft:light[level=15]
setblock 66 234 357 minecraft:light[level=15]
setblock 71 234 325 minecraft:light[level=12]
setblock 71 234 332 minecraft:light[level=12]
setblock 71 234 339 minecraft:light[level=12]
setblock 71 234 346 minecraft:light[level=12]
setblock 71 234 353 minecraft:light[level=12]
setblock 71 234 360 minecraft:light[level=12]
setblock 72 234 363 minecraft:stripped_dark_oak_log
setblock 74 234 325 minecraft:light[level=15]
setblock 74 234 333 minecraft:light[level=15]
setblock 74 234 341 minecraft:light[level=15]
setblock 74 234 349 minecraft:light[level=15]
setblock 74 234 357 minecraft:light[level=15]
setblock 75 234 323 minecraft:stripped_dark_oak_log
setblock 78 234 325 minecraft:light[level=12]
setblock 78 234 332 minecraft:light[level=12]
setblock 78 234 339 minecraft:light[level=12]
setblock 78 234 346 minecraft:light[level=12]
setblock 78 234 353 minecraft:light[level=12]
setblock 78 234 360 minecraft:light[level=12]
setblock 79 234 363 minecraft:stripped_dark_oak_log
fill 81 234 329 86 234 335 minecraft:red_concrete
setblock 82 234 323 minecraft:stripped_dark_oak_log
setblock 82 234 325 minecraft:light[level=15]
setblock 82 234 341 minecraft:light[level=15]
fill 82 234 345 82 239 346 minecraft:dark_oak_planks
fill 82 234 348 86 234 350 minecraft:red_concrete
setblock 82 234 357 minecraft:light[level=15]
fill 83 234 328 86 269 328 minecraft:stripped_dark_oak_log
fill 83 234 344 83 239 344 minecraft:dark_oak_planks
fill 83 234 347 84 239 347 minecraft:dark_oak_planks
setblock 85 234 325 minecraft:light[level=12]
setblock 85 234 339 minecraft:light[level=12]
fill 85 234 343 85 235 343 minecraft:iron_bars
fill 85 234 344 85 239 344 minecraft:dark_oak_planks
setblock 85 234 353 minecraft:light[level=12]
setblock 85 234 360 minecraft:light[level=12]
setblock 86 234 363 minecraft:stripped_dark_oak_log
fill 87 234 343 87 235 343 minecraft:iron_bars
setblock 87 234 358 minecraft:red_concrete
setblock 88 234 324 minecraft:stripped_dark_oak_log
setblock 88 234 331 minecraft:stripped_dark_oak_log
setblock 88 234 338 minecraft:stripped_dark_oak_log
setblock 88 234 345 minecraft:stripped_dark_oak_log
setblock 88 234 352 minecraft:stripped_dark_oak_log
setblock 88 234 359 minecraft:stripped_dark_oak_log
setblock 47 235 344 minecraft:red_concrete
setblock 48 235 325 minecraft:stripped_dark_oak_log
setblock 48 235 332 minecraft:stripped_dark_oak_log
setblock 48 235 339 minecraft:stripped_dark_oak_log
setblock 48 235 346 minecraft:stripped_dark_oak_log
setblock 48 235 353 minecraft:stripped_dark_oak_log
setblock 48 235 360 minecraft:stripped_dark_oak_log
setblock 52 235 363 minecraft:stripped_dark_oak_log
setblock 53 235 323 minecraft:stripped_dark_oak_log
setblock 59 235 363 minecraft:stripped_dark_oak_log
setblock 60 235 323 minecraft:stripped_dark_oak_log
setblock 61 235 324 minecraft:shroomlight
setblock 61 235 326 minecraft:shroomlight
setblock 61 235 328 minecraft:shroomlight
setblock 61 235 330 minecraft:shroomlight
setblock 62 235 323 minecraft:shroomlight
setblock 62 235 325 minecraft:shroomlight
setblock 62 235 327 minecraft:shroomlight
setblock 62 235 329 minecraft:shroomlight
setblock 62 235 331 minecraft:shroomlight
setblock 63 235 324 minecraft:shroomlight
setblock 63 235 326 minecraft:shroomlight
setblock 63 235 328 minecraft:shroomlight
setblock 63 235 330 minecraft:shroomlight
setblock 64 235 323 minecraft:shroomlight
setblock 64 235 325 minecraft:shroomlight
setblock 64 235 327 minecraft:shroomlight
setblock 64 235 329 minecraft:shroomlight
setblock 64 235 331 minecraft:shroomlight
setblock 65 235 324 minecraft:shroomlight
setblock 65 235 326 minecraft:shroomlight
setblock 65 235 328 minecraft:shroomlight
setblock 65 235 330 minecraft:shroomlight
setblock 66 235 323 minecraft:shroomlight
setblock 66 235 325 minecraft:shroomlight
setblock 66 235 327 minecraft:shroomlight
setblock 66 235 329 minecraft:shroomlight
setblock 66 235 331 minecraft:shroomlight
setblock 66 235 363 minecraft:stripped_dark_oak_log
setblock 67 235 324 minecraft:shroomlight
setblock 67 235 326 minecraft:shroomlight
setblock 67 235 328 minecraft:shroomlight
setblock 67 235 330 minecraft:shroomlight
setblock 68 235 323 minecraft:shroomlight
setblock 68 235 325 minecraft:shroomlight
setblock 68 235 327 minecraft:shroomlight
setblock 68 235 329 minecraft:shroomlight
setblock 68 235 331 minecraft:shroomlight
setblock 69 235 324 minecraft:shroomlight
setblock 69 235 326 minecraft:shroomlight
setblock 69 235 328 minecraft:shroomlight
setblock 69 235 330 minecraft:shroomlight
setblock 73 235 363 minecraft:stripped_dark_oak_log
setblock 74 235 323 minecraft:stripped_dark_oak_log
setblock 78 235 361 minecraft:red_concrete
setblock 80 235 363 minecraft:stripped_dark_oak_log
setblock 81 235 323 minecraft:stripped_dark_oak_log
fill 82 235 330 85 235 334 minecraft:red_concrete
fill 82 235 344 82 239 344 minecraft:dark_oak_planks
fill 83 235 343 84 239 343 minecraft:dark_oak_planks
fill 83 235 349 85 235 349 minecraft:red_concrete
fill 84 235 329 85 269 329 minecraft:stripped_dark_oak_log
fill 85 235 347 85 239 347 minecraft:dark_oak_planks
fill 86 235 346 86 237 346 minecraft:dark_oak_planks
fill 87 235 358 87 236 358 minecraft:shroomlight
setblock 87 235 363 minecraft:stripped_dark_oak_log
setblock 88 235 323 minecraft:stripped_dark_oak_log
setblock 88 235 330 minecraft:stripped_dark_oak_log
setblock 88 235 337 minecraft:stripped_dark_oak_log
setblock 88 235 344 minecraft:stripped_dark_oak_log
setblock 88 235 351 minecraft:stripped_dark_oak_log
setblock 88 235 358 minecraft:stripped_dark_oak_log
fill 47 236 344 47 304 344 minecraft:dark_oak_planks
setblock 48 236 326 minecraft:stripped_dark_oak_log
setblock 48 236 333 minecraft:stripped_dark_oak_log
setblock 48 236 340 minecraft:stripped_dark_oak_log
setblock 48 236 347 minecraft:stripped_dark_oak_log
setblock 48 236 354 minecraft:stripped_dark_oak_log
setblock 48 236 361 minecraft:stripped_dark_oak_log
setblock 52 236 323 minecraft:stripped_dark_oak_log
setblock 53 236 363 minecraft:stripped_dark_oak_log
setblock 59 236 323 minecraft:stripped_dark_oak_log
setblock 60 236 363 minecraft:stripped_dark_oak_log
fill 61 236 324 61 237 324 minecraft:stripped_dark_oak_log
fill 61 236 326 61 237 326 minecraft:stripped_dark_oak_log
fill 61 236 328 61 237 328 minecraft:stripped_dark_oak_log
fill 61 236 330 61 237 330 minecraft:stripped_dark_oak_log
fill 62 236 323 62 237 323 minecraft:stripped_dark_oak_log
fill 62 236 325 62 237 325 minecraft:stripped_dark_oak_log
fill 62 236 327 62 237 327 minecraft:stripped_dark_oak_log
fill 62 236 329 62 237 329 minecraft:stripped_dark_oak_log
fill 62 236 331 62 237 331 minecraft:stripped_dark_oak_log
fill 63 236 324 63 237 324 minecraft:stripped_dark_oak_log
fill 63 236 326 63 237 326 minecraft:stripped_dark_oak_log
fill 63 236 328 63 237 328 minecraft:stripped_dark_oak_log
fill 63 236 330 63 237 330 minecraft:stripped_dark_oak_log
fill 64 236 323 64 269 323 minecraft:stripped_dark_oak_log
fill 64 236 325 64 237 325 minecraft:stripped_dark_oak_log
fill 64 236 327 64 237 327 minecraft:stripped_dark_oak_log
fill 64 236 329 64 237 329 minecraft:stripped_dark_oak_log
fill 64 236 331 64 237 331 minecraft:stripped_dark_oak_log
fill 65 236 324 65 237 324 minecraft:stripped_dark_oak_log
fill 65 236 326 65 237 326 minecraft:stripped_dark_oak_log
fill 65 236 328 65 237 328 minecraft:stripped_dark_oak_log
fill 65 236 330 65 237 330 minecraft:stripped_dark_oak_log
fill 66 236 323 66 237 323 minecraft:stripped_dark_oak_log
fill 66 236 325 66 237 325 minecraft:stripped_dark_oak_log
fill 66 236 327 66 237 327 minecraft:stripped_dark_oak_log
fill 66 236 329 66 237 329 minecraft:stripped_dark_oak_log
fill 66 236 331 66 237 331 minecraft:stripped_dark_oak_log
fill 67 236 324 67 237 324 minecraft:stripped_dark_oak_log
fill 67 236 326 67 237 326 minecraft:stripped_dark_oak_log
fill 67 236 328 67 237 328 minecraft:stripped_dark_oak_log
fill 67 236 330 67 237 330 minecraft:stripped_dark_oak_log
setblock 67 236 363 minecraft:stripped_dark_oak_log
fill 68 236 323 68 237 323 minecraft:stripped_dark_oak_log
fill 68 236 325 68 237 325 minecraft:stripped_dark_oak_log
fill 68 236 327 68 237 327 minecraft:stripped_dark_oak_log
fill 68 236 329 68 237 329 minecraft:stripped_dark_oak_log
fill 68 236 331 68 237 331 minecraft:stripped_dark_oak_log
fill 69 236 324 69 237 324 minecraft:stripped_dark_oak_log
fill 69 236 326 69 237 326 minecraft:stripped_dark_oak_log
fill 69 236 328 69 237 328 minecraft:stripped_dark_oak_log
fill 69 236 330 69 237 330 minecraft:stripped_dark_oak_log
setblock 73 236 323 minecraft:stripped_dark_oak_log
setblock 74 236 363 minecraft:stripped_dark_oak_log
fill 78 236 361 78 237 361 minecraft:shroomlight
setblock 79 236 364 minecraft:red_concrete
setblock 80 236 323 minecraft:stripped_dark_oak_log
fill 81 236 345 81 239 346 minecraft:dark_oak_planks
setblock 81 236 363 minecraft:stripped_dark_oak_log
fill 82 236 343 82 239 343 minecraft:dark_oak_planks
fill 82 236 347 82 239 347 minecraft:dark_oak_planks
setblock 82 236 364 minecraft:red_concrete
fill 83 236 331 84 236 333 minecraft:red_concrete
fill 83 236 348 83 239 348 minecraft:dark_oak_planks
fill 83 236 364 89 243 364 minecraft:dark_oak_planks
fill 84 236 348 84 236 350 minecraft:red_concrete
fill 85 236 343 85 239 343 minecraft:dark_oak_planks
fill 86 236 347 86 239 347 minecraft:dark_oak_planks
setblock 87 236 323 minecraft:stripped_dark_oak_log
setblock 87 236 336 minecraft:red_concrete
setblock 88 236 329 minecraft:stripped_dark_oak_log
setblock 88 236 336 minecraft:stripped_dark_oak_log
setblock 88 236 343 minecraft:stripped_dark_oak_log
setblock 88 236 350 minecraft:stripped_dark_oak_log
setblock 88 236 357 minecraft:stripped_dark_oak_log
setblock 88 236 363 minecraft:stripped_dark_oak_log
setblock 48 237 327 minecraft:stripped_dark_oak_log
setblock 48 237 334 minecraft:stripped_dark_oak_log
setblock 48 237 341 minecraft:stripped_dark_oak_log
setblock 48 237 348 minecraft:stripped_dark_oak_log
setblock 48 237 355 minecraft:stripped_dark_oak_log
setblock 48 237 362 minecraft:stripped_dark_oak_log
setblock 51 237 323 minecraft:stripped_dark_oak_log
setblock 54 237 363 minecraft:stripped_dark_oak_log
setblock 58 237 323 minecraft:stripped_dark_oak_log
setblock 61 237 363 minecraft:stripped_dark_oak_log
setblock 68 237 363 minecraft:stripped_dark_oak_log
setblock 72 237 323 minecraft:stripped_dark_oak_log
setblock 75 237 363 minecraft:stripped_dark_oak_log
fill 76 237 364 76 308 364 minecraft:dark_oak_planks
setblock 77 237 364 minecraft:red_concrete
fill 78 237 364 79 308 364 minecraft:dark_oak_planks
setblock 79 237 323 minecraft:stripped_dark_oak_log
fill 81 237 344 81 239 344 minecraft:dark_oak_planks
fill 81 237 347 81 239 347 minecraft:dark_oak_planks
fill 82 237 348 82 239 348 minecraft:dark_oak_planks
setblock 82 237 363 minecraft:stripped_dark_oak_log
fill 82 237 364 82 308 364 minecraft:dark_oak_planks
fill 83 237 342 84 239 342 minecraft:dark_oak_planks
fill 84 237 348 85 239 348 minecraft:dark_oak_planks
setblock 86 237 323 minecraft:stripped_dark_oak_log
fill 87 237 336 87 238 336 minecraft:shroomlight
fill 87 237 344 87 239 346 minecraft:dark_oak_planks
setblock 87 237 358 minecraft:red_concrete
setblock 88 237 328 minecraft:stripped_dark_oak_log
setblock 88 237 335 minecraft:stripped_dark_oak_log
setblock 88 237 342 minecraft:stripped_dark_oak_log
setblock 88 237 349 minecraft:stripped_dark_oak_log
setblock 88 237 356 minecraft:stripped_dark_oak_log
fill 62 238 324 68 238 330 minecraft:red_concrete
fill 67 238 364 67 276 364 minecraft:dark_oak_planks
setblock 68 238 364 minecraft:red_concrete
fill 69 238 364 70 308 364 minecraft:dark_oak_planks
fill 77 238 364 77 308 364 minecraft:dark_oak_planks
setblock 78 238 361 minecraft:red_concrete
fill 80 238 345 80 239 346 minecraft:dark_oak_planks
fill 81 238 343 81 239 343 minecraft:dark_oak_planks
fill 82 238 342 82 239 342 minecraft:dark_oak_planks
fill 83 238 349 85 239 349 minecraft:dark_oak_planks
fill 85 238 342 85 239 342 minecraft:dark_oak_planks
fill 86 238 340 86 239 346 minecraft:iron_bars
fill 86 238 348 86 239 348 minecraft:dark_oak_planks
fill 87 238 347 87 239 347 minecraft:dark_oak_planks
fill 48 239 329 48 240 329 minecraft:stripped_dark_oak_log
fill 48 239 336 48 240 336 minecraft:stripped_dark_oak_log
fill 48 239 343 48 240 343 minecraft:stripped_dark_oak_log
fill 48 239 345 50 239 345 minecraft:iron_bars
fill 48 239 350 48 240 350 minecraft:stripped_dark_oak_log
fill 48 239 357 48 240 357 minecraft:stripped_dark_oak_log
fill 49 239 323 49 240 323 minecraft:stripped_dark_oak_log
fill 49 239 363 49 240 363 minecraft:stripped_dark_oak_log
fill 56 239 323 56 240 323 minecraft:stripped_dark_oak_log
fill 56 239 363 56 240 363 minecraft:stripped_dark_oak_log
fill 58 239 364 59 239 364 minecraft:red_concrete
fill 60 239 364 60 296 364 minecraft:dark_oak_planks
fill 63 239 323 63 240 323 minecraft:stripped_dark_oak_log
fill 63 239 325 67 239 329 minecraft:red_concrete
fill 63 239 363 63 240 363 minecraft:stripped_dark_oak_log
fill 68 239 364 68 308 364 minecraft:dark_oak_planks
fill 70 239 323 70 240 323 minecraft:stripped_dark_oak_log
fill 70 239 363 70 240 363 minecraft:stripped_dark_oak_log
fill 77 239 323 77 240 323 minecraft:stripped_dark_oak_log
fill 77 239 363 77 240 363 minecraft:stripped_dark_oak_log
setblock 80 239 344 minecraft:dark_oak_planks
setblock 80 239 347 minecraft:dark_oak_planks
setblock 81 239 342 minecraft:dark_oak_planks
setblock 81 239 348 minecraft:dark_oak_planks
setblock 82 239 349 minecraft:dark_oak_planks
fill 83 239 341 84 239 341 minecraft:dark_oak_planks
fill 84 239 323 84 240 323 minecraft:stripped_dark_oak_log
fill 84 239 363 84 240 363 minecraft:stripped_dark_oak_log
setblock 86 239 349 minecraft:dark_oak_planks
setblock 87 239 336 minecraft:red_concrete
setblock 87 239 343 minecraft:dark_oak_planks
setblock 87 239 348 minecraft:dark_oak_planks
fill 88 239 326 88 240 326 minecraft:stripped_dark_oak_log
fill 88 239 333 88 240 333 minecraft:stripped_dark_oak_log
fill 88 239 340 88 240 340 minecraft:stripped_dark_oak_log
fill 88 239 344 88 239 346 minecraft:dark_oak_planks
fill 88 239 347 88 240 347 minecraft:stripped_dark_oak_log
fill 88 239 354 88 240 354 minecraft:stripped_dark_oak_log
fill 88 239 361 88 240 361 minecraft:stripped_dark_oak_log
fill 48 240 323 48 240 327 minecraft:stripped_dark_oak_log
fill 48 240 330 48 240 334 minecraft:stripped_dark_oak_log
fill 48 240 337 48 240 341 minecraft:stripped_dark_oak_log
fill 48 240 344 48 240 348 minecraft:stripped_dark_oak_log
fill 48 240 351 48 240 355 minecraft:stripped_dark_oak_log
fill 48 240 358 48 240 362 minecraft:stripped_dark_oak_log
fill 49 240 345 50 240 345 minecraft:iron_bars
setblock 50 240 325 minecraft:light[level=12]
setblock 50 240 332 minecraft:light[level=12]
setblock 50 240 339 minecraft:light[level=12]
setblock 50 240 346 minecraft:light[level=12]
setblock 50 240 353 minecraft:light[level=12]
fill 50 240 358 50 240 361 minecraft:dark_oak_planks
fill 50 240 363 54 240 363 minecraft:stripped_dark_oak_log
fill 51 240 323 55 240 323 minecraft:stripped_dark_oak_log
fill 51 240 357 52 240 357 minecraft:dark_oak_planks
setblock 51 240 361 minecraft:dark_oak_planks
fill 53 240 358 54 240 358 minecraft:dark_oak_planks
setblock 53 240 361 minecraft:dark_oak_planks
fill 54 240 359 54 240 360 minecraft:dark_oak_planks
setblock 57 240 325 minecraft:light[level=12]
setblock 57 240 332 minecraft:light[level=12]
setblock 57 240 339 minecraft:light[level=12]
setblock 57 240 346 minecraft:light[level=12]
setblock 57 240 353 minecraft:light[level=12]
setblock 57 240 360 minecraft:light[level=12]
fill 57 240 363 61 240 363 minecraft:stripped_dark_oak_log
fill 58 240 323 62 240 323 minecraft:stripped_dark_oak_log
fill 58 240 364 59 253 364 minecraft:dark_oak_planks
setblock 64 240 325 minecraft:light[level=12]
fill 64 240 326 66 240 328 minecraft:red_concrete
setblock 64 240 332 minecraft:light[level=12]
setblock 64 240 339 minecraft:light[level=12]
setblock 64 240 346 minecraft:light[level=12]
setblock 64 240 353 minecraft:light[level=12]
setblock 64 240 360 minecraft:light[level=12]
fill 64 240 363 68 240 363 minecraft:stripped_dark_oak_log
fill 65 240 323 69 240 323 minecraft:stripped_dark_oak_log
setblock 71 240 325 minecraft:light[level=12]
setblock 71 240 332 minecraft:light[level=12]
setblock 71 240 339 minecraft:light[level=12]
setblock 71 240 346 minecraft:light[level=12]
setblock 71 240 353 minecraft:light[level=12]
setblock 71 240 360 minecraft:light[level=12]
fill 71 240 363 75 240 363 minecraft:stripped_dark_oak_log
fill 72 240 323 76 240 323 minecraft:stripped_dark_oak_log
setblock 78 240 325 minecraft:light[level=12]
setblock 78 240 332 minecraft:light[level=12]
setblock 78 240 339 minecraft:light[level=12]
setblock 78 240 346 minecraft:light[level=12]
setblock 78 240 353 minecraft:light[level=12]
setblock 78 240 360 minecraft:light[level=12]
fill 78 240 363 82 240 363 minecraft:stripped_dark_oak_log
fill 79 240 323 83 240 323 minecraft:stripped_dark_oak_log
fill 82 240 327 82 240 328 minecraft:dark_oak_planks
setblock 83 240 326 minecraft:dark_oak_planks
setblock 83 240 329 minecraft:dark_oak_planks
fill 84 240 325 85 240 325 minecraft:dark_oak_planks
fill 84 240 330 85 240 330 minecraft:dark_oak_planks
fill 84 240 345 84 242 345 minecraft:stripped_dark_oak_log
setblock 85 240 332 minecraft:light[level=12]
setblock 85 240 339 minecraft:light[level=12]
setblock 85 240 346 minecraft:light[level=12]
setblock 85 240 353 minecraft:light[level=12]
setblock 85 240 360 minecraft:light[level=12]
fill 85 240 363 88 240 363 minecraft:stripped_dark_oak_log
fill 86 240 323 88 240 323 minecraft:stripped_dark_oak_log
setblock 86 240 326 minecraft:dark_oak_planks
setblock 86 240 329 minecraft:dark_oak_planks
fill 88 240 324 88 240 325 minecraft:stripped_dark_oak_log
fill 88 240 328 88 240 332 minecraft:stripped_dark_oak_log
fill 88 240 335 88 240 339 minecraft:stripped_dark_oak_log
fill 88 240 342 88 240 346 minecraft:stripped_dark_oak_log
fill 88 240 349 88 240 353 minecraft:stripped_dark_oak_log
fill 88 240 356 88 240 360 minecraft:stripped_dark_oak_log
fill 47 241 357 47 291 360 minecraft:dark_oak_planks
setblock 47 241 361 minecraft:red_concrete
fill 47 241 362 47 308 362 minecraft:dark_oak_planks
setblock 48 241 324 minecraft:stripped_dark_oak_log
setblock 48 241 331 minecraft:stripped_dark_oak_log
setblock 48 241 338 minecraft:stripped_dark_oak_log
setblock 48 241 345 minecraft:stripped_dark_oak_log
setblock 48 241 352 minecraft:stripped_dark_oak_log
setblock 48 241 359 minecraft:stripped_dark_oak_log
setblock 51 241 363 minecraft:stripped_dark_oak_log
setblock 54 241 323 minecraft:stripped_dark_oak_log
setblock 58 241 363 minecraft:stripped_dark_oak_log
setblock 61 241 323 minecraft:stripped_dark_oak_log
setblock 65 241 327 minecraft:red_concrete
setblock 65 241 363 minecraft:stripped_dark_oak_log
setblock 68 241 323 minecraft:stripped_dark_oak_log
setblock 72 241 363 minecraft:stripped_dark_oak_log
setblock 75 241 323 minecraft:stripped_dark_oak_log
setblock 79 241 363 minecraft:stripped_dark_oak_log
setblock 82 241 323 minecraft:stripped_dark_oak_log
setblock 86 241 363 minecraft:stripped_dark_oak_log
setblock 88 241 324 minecraft:stripped_dark_oak_log
setblock 88 241 331 minecraft:stripped_dark_oak_log
setblock 88 241 338 minecraft:stripped_dark_oak_log
setblock 88 241 345 minecraft:stripped_dark_oak_log
setblock 88 241 352 minecraft:stripped_dark_oak_log
setblock 88 241 359 minecraft:stripped_dark_oak_log
fill 47 242 361 47 308 361 minecraft:dark_oak_planks
setblock 48 242 325 minecraft:stripped_dark_oak_log
setblock 48 242 332 minecraft:stripped_dark_oak_log
setblock 48 242 339 minecraft:stripped_dark_oak_log
setblock 48 242 346 minecraft:stripped_dark_oak_log
setblock 48 242 353 minecraft:stripped_dark_oak_log
setblock 48 242 360 minecraft:stripped_dark_oak_log
setblock 50 242 325 minecraft:light[level=15]
setblock 50 242 333 minecraft:light[level=15]
setblock 50 242 341 minecraft:light[level=15]
setblock 50 242 349 minecraft:light[level=15]
setblock 50 242 357 minecraft:light[level=15]
setblock 52 242 363 minecraft:stripped_dark_oak_log
setblock 53 242 323 minecraft:stripped_dark_oak_log
setblock 58 242 325 minecraft:light[level=15]
setblock 58 242 333 minecraft:light[level=15]
setblock 58 242 341 minecraft:light[level=15]
setblock 58 242 349 minecraft:light[level=15]
setblock 58 242 357 minecraft:light[level=15]
setblock 59 242 363 minecraft:stripped_dark_oak_log
setblock 60 242 323 minecraft:stripped_dark_oak_log
setblock 66 242 325 minecraft:light[level=15]
setblock 66 242 333 minecraft:light[level=15]
setblock 66 242 341 minecraft:light[level=15]
setblock 66 242 349 minecraft:light[level=15]
setblock 66 242 357 minecraft:light[level=15]
setblock 66 242 363 minecraft:stripped_dark_oak_log
setblock 67 242 323 minecraft:stripped_dark_oak_log
setblock 73 242 363 minecraft:stripped_dark_oak_log
setblock 74 242 323 minecraft:stripped_dark_oak_log
setblock 74 242 325 minecraft:light[level=15]
setblock 74 242 333 minecraft:light[level=15]
setblock 74 242 341 minecraft:light[level=15]
setblock 74 242 349 minecraft:light[level=15]
setblock 74 242 357 minecraft:light[level=15]
setblock 80 242 363 minecraft:stripped_dark_oak_log
setblock 81 242 323 minecraft:stripped_dark_oak_log
setblock 82 242 325 minecraft:light[level=15]
setblock 82 242 333 minecraft:light[level=15]
setblock 82 242 341 minecraft:light[level=15]
setblock 82 242 349 minecraft:light[level=15]
setblock 82 242 357 minecraft:light[level=15]
setblock 87 242 363 minecraft:stripped_dark_oak_log
setblock 88 242 323 minecraft:stripped_dark_oak_log
setblock 88 242 330 minecraft:stripped_dark_oak_log
setblock 88 242 337 minecraft:stripped_dark_oak_log
setblock 88 242 344 minecraft:stripped_dark_oak_log
setblock 88 242 351 minecraft:stripped_dark_oak_log
setblock 88 242 358 minecraft:stripped_dark_oak_log
setblock 48 243 326 minecraft:stripped_dark_oak_log
setblock 48 243 333 minecraft:stripped_dark_oak_log
setblock 48 243 340 minecraft:stripped_dark_oak_log
setblock 48 243 347 minecraft:stripped_dark_oak_log
setblock 48 243 354 minecraft:stripped_dark_oak_log
setblock 48 243 361 minecraft:stripped_dark_oak_log
setblock 52 243 323 minecraft:stripped_dark_oak_log
setblock 53 243 363 minecraft:stripped_dark_oak_log
fill 57 243 347 57 244 347 minecraft:shroomlight
setblock 59 243 323 minecraft:stripped_dark_oak_log
setblock 60 243 363 minecraft:stripped_dark_oak_log
setblock 66 243 323 minecraft:stripped_dark_oak_log
setblock 67 243 363 minecraft:stripped_dark_oak_log
setblock 73 243 323 minecraft:stripped_dark_oak_log
setblock 74 243 363 minecraft:stripped_dark_oak_log
setblock 80 243 323 minecraft:stripped_dark_oak_log
setblock 81 243 363 minecraft:stripped_dark_oak_log
fill 82 243 345 85 245 346 minecraft:cherry_leaves[persistent=true]
fill 83 243 344 85 245 344 minecraft:cherry_leaves[persistent=true]
fill 83 243 347 84 245 347 minecraft:cherry_leaves[persistent=true]
setblock 87 243 323 minecraft:stripped_dark_oak_log
setblock 88 243 329 minecraft:stripped_dark_oak_log
setblock 88 243 336 minecraft:stripped_dark_oak_log
setblock 88 243 343 minecraft:stripped_dark_oak_log
setblock 88 243 350 minecraft:stripped_dark_oak_log
setblock 88 243 357 minecraft:stripped_dark_oak_log
setblock 88 243 363 minecraft:stripped_dark_oak_log
fill 48 244 322 50 308 322 minecraft:dark_oak_planks
setblock 48 244 327 minecraft:stripped_dark_oak_log
setblock 48 244 334 minecraft:stripped_dark_oak_log
setblock 48 244 341 minecraft:stripped_dark_oak_log
setblock 48 244 348 minecraft:stripped_dark_oak_log
setblock 48 244 355 minecraft:stripped_dark_oak_log
setblock 48 244 362 minecraft:stripped_dark_oak_log
setblock 51 244 322 minecraft:red_concrete
setblock 51 244 323 minecraft:stripped_dark_oak_log
setblock 54 244 363 minecraft:stripped_dark_oak_log
setblock 58 244 323 minecraft:stripped_dark_oak_log
setblock 61 244 363 minecraft:stripped_dark_oak_log
setblock 62 244 364 minecraft:red_concrete
setblock 65 244 323 minecraft:stripped_dark_oak_log
setblock 68 244 363 minecraft:stripped_dark_oak_log
setblock 72 244 323 minecraft:stripped_dark_oak_log
setblock 75 244 363 minecraft:stripped_dark_oak_log
setblock 79 244 323 minecraft:stripped_dark_oak_log
setblock 82 244 344 minecraft:cherry_leaves[persistent=true]
setblock 82 244 363 minecraft:stripped_dark_oak_log
fill 83 244 364 86 276 364 minecraft:dark_oak_planks
setblock 84 244 343 minecraft:cherry_leaves[persistent=true]
setblock 85 244 347 minecraft:cherry_leaves[persistent=true]
setblock 86 244 323 minecraft:stripped_dark_oak_log
fill 86 244 345 86 244 346 minecraft:cherry_leaves[persistent=true]
setblock 87 244 364 minecraft:red_concrete
setblock 88 244 328 minecraft:stripped_dark_oak_log
setblock 88 244 335 minecraft:stripped_dark_oak_log
setblock 88 244 342 minecraft:stripped_dark_oak_log
setblock 88 244 349 minecraft:stripped_dark_oak_log
setblock 88 244 356 minecraft:stripped_dark_oak_log
fill 88 244 364 89 308 364 minecraft:dark_oak_planks
fill 89 244 344 89 308 345 minecraft:dark_oak_planks
setblock 89 244 346 minecraft:red_concrete
setblock 47 245 331 minecraft:red_concrete
fill 51 245 322 51 252 322 minecraft:dark_oak_planks
fill 57 245 347 57 253 347 minecraft:dark_oak_planks
fill 62 245 364 62 251 364 minecraft:dark_oak_planks
fill 78 245 322 79 308 322 minecraft:dark_oak_planks
setblock 80 245 322 minecraft:red_concrete
fill 81 245 322 82 308 322 minecraft:dark_oak_planks
fill 87 245 364 87 308 364 minecraft:dark_oak_planks
fill 89 245 346 89 265 346 minecraft:dark_oak_planks
fill 47 246 331 47 282 331 minecraft:dark_oak_planks
setblock 48 246 329 minecraft:stripped_dark_oak_log
setblock 48 246 336 minecraft:stripped_dark_oak_log
setblock 48 246 343 minecraft:stripped_dark_oak_log
setblock 48 246 350 minecraft:stripped_dark_oak_log
setblock 48 246 357 minecraft:stripped_dark_oak_log
setblock 49 246 323 minecraft:stripped_dark_oak_log
setblock 49 246 363 minecraft:stripped_dark_oak_log
setblock 50 246 325 minecraft:light[level=12]
setblock 50 246 332 minecraft:light[level=12]
fill 50 246 337 50 251 337 minecraft:red_concrete
setblock 50 246 339 minecraft:light[level=12]
setblock 50 246 346 minecraft:light[level=12]
setblock 50 246 353 minecraft:light[level=12]
setblock 50 246 360 minecraft:light[level=12]
setblock 56 246 323 minecraft:stripped_dark_oak_log
setblock 56 246 363 minecraft:stripped_dark_oak_log
setblock 57 246 325 minecraft:light[level=12]
setblock 57 246 332 minecraft:light[level=12]
setblock 57 246 339 minecraft:light[level=12]
setblock 57 246 346 minecraft:light[level=12]
setblock 57 246 353 minecraft:light[level=12]
setblock 57 246 360 minecraft:light[level=12]
setblock 63 246 323 minecraft:stripped_dark_oak_log
setblock 63 246 363 minecraft:stripped_dark_oak_log
setblock 64 246 325 minecraft:light[level=12]
setblock 64 246 332 minecraft:light[level=12]
setblock 64 246 339 minecraft:light[level=12]
setblock 64 246 346 minecraft:light[level=12]
setblock 64 246 353 minecraft:light[level=12]
setblock 64 246 360 minecraft:light[level=12]
setblock 70 246 323 minecraft:stripped_dark_oak_log
setblock 70 246 363 minecraft:stripped_dark_oak_log
setblock 71 246 325 minecraft:light[level=12]
setblock 71 246 332 minecraft:light[level=12]
setblock 71 246 339 minecraft:light[level=12]
setblock 71 246 346 minecraft:light[level=12]
setblock 71 246 353 minecraft:light[level=12]
setblock 71 246 360 minecraft:light[level=12]
setblock 77 246 323 minecraft:stripped_dark_oak_log
setblock 77 246 363 minecraft:stripped_dark_oak_log
setblock 78 246 325 minecraft:light[level=12]
setblock 78 246 332 minecraft:light[level=12]
setblock 78 246 339 minecraft:light[level=12]
setblock 78 246 346 minecraft:light[level=12]
setblock 78 246 353 minecraft:light[level=12]
setblock 78 246 360 minecraft:light[level=12]
fill 80 246 322 80 308 322 minecraft:dark_oak_planks
setblock 84 246 323 minecraft:stripped_dark_oak_log
setblock 84 246 363 minecraft:stripped_dark_oak_log
setblock 85 246 325 minecraft:light[level=12]
setblock 85 246 332 minecraft:light[level=12]
setblock 85 246 339 minecraft:light[level=12]
setblock 85 246 346 minecraft:light[level=12]
setblock 85 246 353 minecraft:light[level=12]
setblock 85 246 360 minecraft:light[level=12]
setblock 88 246 326 minecraft:stripped_dark_oak_log
setblock 88 246 333 minecraft:stripped_dark_oak_log
setblock 88 246 340 minecraft:stripped_dark_oak_log
setblock 88 246 347 minecraft:stripped_dark_oak_log
setblock 88 246 354 minecraft:stripped_dark_oak_log
setblock 88 246 361 minecraft:stripped_dark_oak_log
setblock 47 247 334 minecraft:red_concrete
setblock 48 247 323 minecraft:stripped_dark_oak_log
setblock 48 247 330 minecraft:stripped_dark_oak_log
setblock 48 247 337 minecraft:stripped_dark_oak_log
setblock 48 247 344 minecraft:stripped_dark_oak_log
setblock 48 247 351 minecraft:stripped_dark_oak_log
setblock 48 247 358 minecraft:stripped_dark_oak_log
setblock 50 247 363 minecraft:stripped_dark_oak_log
setblock 55 247 323 minecraft:stripped_dark_oak_log
fill 56 247 347 56 253 347 minecraft:dark_oak_planks
fill 57 247 346 57 253 346 minecraft:dark_oak_planks
fill 57 247 348 57 253 348 minecraft:dark_oak_planks
setblock 57 247 363 minecraft:stripped_dark_oak_log
fill 58 247 347 58 253 347 minecraft:dark_oak_planks
setblock 62 247 323 minecraft:stripped_dark_oak_log
setblock 64 247 363 minecraft:stripped_dark_oak_log
setblock 69 247 323 minecraft:stripped_dark_oak_log
setblock 71 247 363 minecraft:stripped_dark_oak_log
setblock 76 247 323 minecraft:stripped_dark_oak_log
setblock 78 247 363 minecraft:stripped_dark_oak_log
setblock 83 247 323 minecraft:stripped_dark_oak_log
setblock 85 247 363 minecraft:stripped_dark_oak_log
setblock 88 247 325 minecraft:stripped_dark_oak_log
setblock 88 247 332 minecraft:stripped_dark_oak_log
setblock 88 247 339 minecraft:stripped_dark_oak_log
setblock 88 247 346 minecraft:stripped_dark_oak_log
setblock 88 247 353 minecraft:stripped_dark_oak_log
setblock 88 247 360 minecraft:stripped_dark_oak_log
fill 47 248 334 47 308 334 minecraft:dark_oak_planks
setblock 48 248 324 minecraft:stripped_dark_oak_log
setblock 48 248 331 minecraft:stripped_dark_oak_log
setblock 48 248 338 minecraft:stripped_dark_oak_log
setblock 48 248 345 minecraft:stripped_dark_oak_log
setblock 48 248 352 minecraft:stripped_dark_oak_log
setblock 48 248 359 minecraft:stripped_dark_oak_log
fill 50 248 336 50 251 336 minecraft:red_concrete
fill 50 248 338 50 251 338 minecraft:red_concrete
fill 50 248 358 50 248 361 minecraft:dark_oak_planks
fill 51 248 337 51 251 337 minecraft:red_concrete
fill 51 248 357 52 248 357 minecraft:dark_oak_planks
setblock 51 248 361 minecraft:dark_oak_planks
setblock 51 248 363 minecraft:stripped_dark_oak_log
fill 53 248 358 54 248 358 minecraft:dark_oak_planks
setblock 53 248 361 minecraft:dark_oak_planks
setblock 54 248 323 minecraft:stripped_dark_oak_log
fill 54 248 359 54 248 360 minecraft:dark_oak_planks
fill 55 248 352 57 251 352 minecraft:cherry_leaves[persistent=true]
fill 56 248 346 56 253 346 minecraft:dark_oak_planks
fill 56 248 348 56 253 348 minecraft:dark_oak_planks
fill 56 248 351 57 251 351 minecraft:cherry_leaves[persistent=true]
fill 58 248 346 58 253 346 minecraft:dark_oak_planks
fill 58 248 348 58 253 348 minecraft:dark_oak_planks
setblock 58 248 363 minecraft:stripped_dark_oak_log
setblock 61 248 323 minecraft:stripped_dark_oak_log
setblock 65 248 363 minecraft:stripped_dark_oak_log
setblock 68 248 323 minecraft:stripped_dark_oak_log
fill 72 248 323 72 249 325 minecraft:iron_bars
setblock 72 248 363 minecraft:stripped_dark_oak_log
setblock 75 248 323 minecraft:stripped_dark_oak_log
setblock 79 248 363 minecraft:stripped_dark_oak_log
setblock 82 248 323 minecraft:stripped_dark_oak_log
fill 82 248 327 82 248 328 minecraft:dark_oak_planks
setblock 83 248 326 minecraft:dark_oak_planks
setblock 83 248 329 minecraft:dark_oak_planks
fill 84 248 325 85 248 325 minecraft:dark_oak_planks
fill 84 248 330 85 248 330 minecraft:dark_oak_planks
setblock 86 248 326 minecraft:dark_oak_planks
setblock 86 248 329 minecraft:dark_oak_planks
setblock 86 248 363 minecraft:stripped_dark_oak_log
setblock 88 248 324 minecraft:stripped_dark_oak_log
setblock 88 248 331 minecraft:stripped_dark_oak_log
setblock 88 248 338 minecraft:stripped_dark_oak_log
setblock 88 248 345 minecraft:stripped_dark_oak_log
setblock 88 248 352 minecraft:stripped_dark_oak_log
setblock 88 248 359 minecraft:stripped_dark_oak_log
fill 48 249 325 48 250 325 minecraft:stripped_dark_oak_log
fill 48 249 332 48 250 332 minecraft:stripped_dark_oak_log
fill 48 249 339 48 250 339 minecraft:stripped_dark_oak_log
fill 48 249 346 48 250 346 minecraft:stripped_dark_oak_log
fill 48 249 353 48 250 353 minecraft:stripped_dark_oak_log
fill 48 249 360 48 250 360 minecraft:stripped_dark_oak_log
fill 49 249 337 49 251 337 minecraft:red_concrete
fill 51 249 336 51 251 336 minecraft:red_concrete
fill 51 249 338 51 251 338 minecraft:red_concrete
fill 52 249 363 52 250 363 minecraft:stripped_dark_oak_log
fill 53 249 323 53 250 323 minecraft:stripped_dark_oak_log
fill 54 249 339 54 250 339 minecraft:shroomlight
fill 55 249 347 55 253 347 minecraft:dark_oak_planks
fill 55 249 350 55 250 351 minecraft:cherry_leaves[persistent=true]
fill 55 249 353 57 250 353 minecraft:cherry_leaves[persistent=true]
fill 56 249 350 57 250 350 minecraft:cherry_leaves[persistent=true]
fill 57 249 345 57 253 345 minecraft:dark_oak_planks
fill 57 249 349 57 253 349 minecraft:dark_oak_planks
fill 58 249 351 58 250 352 minecraft:cherry_leaves[persistent=true]
fill 59 249 347 59 253 347 minecraft:dark_oak_planks
fill 59 249 363 59 250 363 minecraft:stripped_dark_oak_log
fill 60 249 323 60 250 323 minecraft:stripped_dark_oak_log
fill 66 249 363 66 250 363 minecraft:stripped_dark_oak_log
fill 67 249 323 67 250 323 minecraft:stripped_dark_oak_log
fill 73 249 363 73 250 363 minecraft:stripped_dark_oak_log
fill 74 249 323 74 250 323 minecraft:stripped_dark_oak_log
fill 80 249 363 80 250 363 minecraft:stripped_dark_oak_log
fill 81 249 323 81 250 323 minecraft:stripped_dark_oak_log
fill 87 249 363 87 250 363 minecraft:stripped_dark_oak_log
fill 88 249 323 88 250 323 minecraft:stripped_dark_oak_log
fill 88 249 330 88 250 330 minecraft:stripped_dark_oak_log
fill 88 249 337 88 250 337 minecraft:stripped_dark_oak_log
fill 88 249 344 88 250 344 minecraft:stripped_dark_oak_log
fill 88 249 351 88 250 351 minecraft:stripped_dark_oak_log
fill 88 249 358 88 250 358 minecraft:stripped_dark_oak_log
fill 48 250 323 48 250 324 minecraft:stripped_dark_oak_log
fill 48 250 326 48 250 327 minecraft:stripped_dark_oak_log
fill 48 250 329 48 250 331 minecraft:stripped_dark_oak_log
fill 48 250 333 48 250 334 minecraft:stripped_dark_oak_log
fill 48 250 336 48 250 338 minecraft:stripped_dark_oak_log
fill 48 250 340 48 250 341 minecraft:stripped_dark_oak_log
fill 48 250 343 48 250 345 minecraft:stripped_dark_oak_log
fill 48 250 347 48 250 348 minecraft:stripped_dark_oak_log
fill 48 250 350 48 250 352 minecraft:stripped_dark_oak_log
fill 48 250 354 48 250 355 minecraft:stripped_dark_oak_log
fill 48 250 357 48 250 359 minecraft:stripped_dark_oak_log
fill 48 250 361 48 250 362 minecraft:stripped_dark_oak_log
setblock 49 250 323 minecraft:stripped_dark_oak_log
fill 49 250 336 49 251 336 minecraft:red_concrete
fill 49 250 338 49 251 338 minecraft:red_concrete
fill 49 250 363 51 250 363 minecraft:stripped_dark_oak_log
setblock 50 250 325 minecraft:light[level=15]
setblock 50 250 333 minecraft:light[level=15]
setblock 50 250 341 minecraft:light[level=15]
setblock 50 250 349 minecraft:light[level=15]
setblock 50 250 357 minecraft:light[level=15]
fill 51 250 323 52 250 323 minecraft:stripped_dark_oak_log
fill 52 250 337 52 251 337 minecraft:red_concrete
fill 53 250 363 54 250 363 minecraft:stripped_dark_oak_log
fill 54 250 323 56 250 323 minecraft:stripped_dark_oak_log
fill 55 250 346 55 253 346 minecraft:dark_oak_planks
fill 55 250 348 55 253 348 minecraft:dark_oak_planks
fill 56 250 345 56 253 345 minecraft:dark_oak_planks
fill 56 250 349 56 253 349 minecraft:dark_oak_planks
fill 56 250 363 58 250 363 minecraft:stripped_dark_oak_log
fill 58 250 323 59 250 323 minecraft:stripped_dark_oak_log
setblock 58 250 325 minecraft:light[level=15]
setblock 58 250 333 minecraft:light[level=15]
setblock 58 250 341 minecraft:light[level=15]
fill 58 250 345 58 253 345 minecraft:dark_oak_planks
fill 58 250 349 58 253 349 minecraft:dark_oak_planks
setblock 58 250 357 minecraft:light[level=15]
fill 59 250 346 59 253 346 minecraft:dark_oak_planks
fill 59 250 348 59 253 348 minecraft:dark_oak_planks
fill 60 250 363 61 250 363 minecraft:stripped_dark_oak_log
fill 61 250 323 63 250 323 minecraft:stripped_dark_oak_log
fill 63 250 363 65 250 363 minecraft:stripped_dark_oak_log
fill 65 250 323 66 250 323 minecraft:stripped_dark_oak_log
setblock 66 250 325 minecraft:light[level=15]
setblock 66 250 333 minecraft:light[level=15]
setblock 66 250 341 minecraft:light[level=15]
setblock 66 250 349 minecraft:light[level=15]
setblock 66 250 357 minecraft:light[level=15]
fill 67 250 363 68 250 363 minecraft:stripped_dark_oak_log
fill 68 250 323 70 250 323 minecraft:stripped_dark_oak_log
fill 70 250 363 72 250 363 minecraft:stripped_dark_oak_log
fill 72 250 323 73 250 323 minecraft:stripped_dark_oak_log
setblock 74 250 325 minecraft:light[level=15]
setblock 74 250 333 minecraft:light[level=15]
setblock 74 250 341 minecraft:light[level=15]
setblock 74 250 349 minecraft:light[level=15]
setblock 74 250 357 minecraft:light[level=15]
fill 74 250 363 75 250 363 minecraft:stripped_dark_oak_log
fill 75 250 323 77 250 323 minecraft:stripped_dark_oak_log
fill 77 250 363 79 250 363 minecraft:stripped_dark_oak_log
fill 79 250 323 80 250 323 minecraft:stripped_dark_oak_log
fill 81 250 363 82 250 363 minecraft:stripped_dark_oak_log
fill 82 250 323 84 250 323 minecraft:stripped_dark_oak_log
setblock 82 250 325 minecraft:light[level=15]
setblock 82 250 333 minecraft:light[level=15]
setblock 82 250 341 minecraft:light[level=15]
setblock 82 250 349 minecraft:light[level=15]
setblock 82 250 357 minecraft:light[level=15]
fill 84 250 363 86 250 363 minecraft:stripped_dark_oak_log
fill 86 250 323 87 250 323 minecraft:stripped_dark_oak_log
fill 88 250 324 88 250 326 minecraft:stripped_dark_oak_log
fill 88 250 328 88 250 329 minecraft:stripped_dark_oak_log
fill 88 250 331 88 250 333 minecraft:stripped_dark_oak_log
fill 88 250 335 88 250 336 minecraft:stripped_dark_oak_log
fill 88 250 338 88 250 340 minecraft:stripped_dark_oak_log
fill 88 250 342 88 250 343 minecraft:stripped_dark_oak_log
fill 88 250 345 88 250 347 minecraft:stripped_dark_oak_log
fill 88 250 349 88 250 350 minecraft:stripped_dark_oak_log
fill 88 250 352 88 250 354 minecraft:stripped_dark_oak_log
fill 88 250 356 88 250 357 minecraft:stripped_dark_oak_log
fill 88 250 359 88 250 361 minecraft:stripped_dark_oak_log
setblock 88 250 363 minecraft:stripped_dark_oak_log
setblock 48 251 327 minecraft:stripped_dark_oak_log
fill 48 251 334 48 269 334 minecraft:stripped_dark_oak_log
setblock 48 251 337 minecraft:red_concrete
fill 48 251 341 48 252 341 minecraft:stripped_dark_oak_log
setblock 48 251 348 minecraft:stripped_dark_oak_log
setblock 48 251 355 minecraft:stripped_dark_oak_log
setblock 48 251 362 minecraft:stripped_dark_oak_log
fill 50 251 335 51 251 335 minecraft:red_concrete
fill 50 251 339 51 251 339 minecraft:red_concrete
setblock 51 251 323 minecraft:stripped_dark_oak_log
setblock 52 251 336 minecraft:red_concrete
setblock 52 251 338 minecraft:red_concrete
fill 54 251 339 54 257 339 minecraft:dark_oak_planks
fill 54 251 347 54 253 347 minecraft:dark_oak_planks
setblock 54 251 363 minecraft:stripped_dark_oak_log
setblock 55 251 322 minecraft:red_concrete
fill 55 251 345 55 253 345 minecraft:dark_oak_planks
fill 55 251 349 55 253 349 minecraft:dark_oak_planks
setblock 55 251 351 minecraft:cherry_leaves[persistent=true]
setblock 56 251 350 minecraft:cherry_leaves[persistent=true]
fill 56 251 353 57 251 353 minecraft:cherry_leaves[persistent=true]
fill 57 251 344 57 253 344 minecraft:dark_oak_planks
fill 57 251 350 57 253 350 minecraft:dark_oak_planks
setblock 58 251 323 minecraft:stripped_dark_oak_log
fill 59 251 345 59 253 345 minecraft:dark_oak_planks
fill 59 251 349 59 253 349 minecraft:dark_oak_planks
fill 60 251 347 60 253 347 minecraft:dark_oak_planks
setblock 61 251 363 minecraft:stripped_dark_oak_log
setblock 65 251 323 minecraft:stripped_dark_oak_log
setblock 68 251 363 minecraft:stripped_dark_oak_log
setblock 72 251 323 minecraft:stripped_dark_oak_log
setblock 75 251 363 minecraft:stripped_dark_oak_log
setblock 79 251 323 minecraft:stripped_dark_oak_log
setblock 82 251 363 minecraft:stripped_dark_oak_log
setblock 86 251 323 minecraft:stripped_dark_oak_log
setblock 88 251 328 minecraft:stripped_dark_oak_log
setblock 88 251 335 minecraft:stripped_dark_oak_log
setblock 88 251 342 minecraft:stripped_dark_oak_log
setblock 88 251 349 minecraft:stripped_dark_oak_log
setblock 88 251 356 minecraft:stripped_dark_oak_log
fill 48 252 332 48 252 333 minecraft:stripped_dark_oak_log
fill 48 252 336 53 252 340 minecraft:stripped_dark_oak_log
fill 49 252 333 53 252 335 minecraft:stripped_dark_oak_log
fill 49 252 341 53 252 341 minecraft:stripped_dark_oak_log
setblock 50 252 325 minecraft:light[level=12]
setblock 50 252 332 minecraft:light[level=12]
setblock 50 252 346 minecraft:light[level=12]
setblock 50 252 353 minecraft:light[level=12]
setblock 50 252 360 minecraft:light[level=12]
fill 54 252 338 54 257 338 minecraft:dark_oak_planks
fill 54 252 346 54 253 346 minecraft:dark_oak_planks
fill 54 252 348 54 253 348 minecraft:dark_oak_planks
fill 55 252 322 55 308 322 minecraft:dark_oak_planks
fill 56 252 344 56 253 344 minecraft:dark_oak_planks
fill 56 252 350 56 253 350 minecraft:dark_oak_planks
setblock 57 252 325 minecraft:light[level=12]
setblock 57 252 332 minecraft:light[level=12]
setblock 57 252 339 minecraft:light[level=12]
setblock 57 252 353 minecraft:light[level=12]
setblock 57 252 360 minecraft:light[level=12]
fill 58 252 344 58 253 344 minecraft:dark_oak_planks
fill 58 252 350 58 253 350 minecraft:dark_oak_planks
fill 60 252 346 60 253 346 minecraft:dark_oak_planks
fill 60 252 348 60 253 348 minecraft:dark_oak_planks
setblock 62 252 364 minecraft:red_concrete
setblock 64 252 325 minecraft:light[level=12]
setblock 64 252 332 minecraft:light[level=12]
setblock 64 252 339 minecraft:light[level=12]
setblock 64 252 346 minecraft:light[level=12]
setblock 64 252 353 minecraft:light[level=12]
setblock 64 252 360 minecraft:light[level=12]
setblock 71 252 325 minecraft:light[level=12]
setblock 71 252 332 minecraft:light[level=12]
setblock 71 252 339 minecraft:light[level=12]
setblock 71 252 346 minecraft:light[level=12]
setblock 71 252 353 minecraft:light[level=12]
setblock 71 252 360 minecraft:light[level=12]
setblock 78 252 325 minecraft:light[level=12]
setblock 78 252 332 minecraft:light[level=12]
setblock 78 252 339 minecraft:light[level=12]
setblock 78 252 346 minecraft:light[level=12]
setblock 78 252 353 minecraft:light[level=12]
setblock 78 252 360 minecraft:light[level=12]
setblock 83 252 361 minecraft:red_concrete
setblock 85 252 325 minecraft:light[level=12]
setblock 85 252 332 minecraft:light[level=12]
setblock 85 252 339 minecraft:light[level=12]
setblock 85 252 346 minecraft:light[level=12]
setblock 85 252 353 minecraft:light[level=12]
setblock 85 252 360 minecraft:light[level=12]
fill 87 252 332 87 253 334 minecraft:stripped_dark_oak_log
fill 88 252 332 88 253 333 minecraft:stripped_dark_oak_log
setblock 48 253 329 minecraft:stripped_dark_oak_log
fill 48 253 332 49 253 332 minecraft:stripped_dark_oak_log
setblock 48 253 333 minecraft:shroomlight
setblock 48 253 335 minecraft:shroomlight
fill 48 253 336 48 269 336 minecraft:stripped_dark_oak_log
setblock 48 253 337 minecraft:shroomlight
fill 48 253 338 48 269 338 minecraft:stripped_dark_oak_log
setblock 48 253 339 minecraft:shroomlight
fill 48 253 340 48 269 340 minecraft:stripped_dark_oak_log
setblock 48 253 341 minecraft:shroomlight
setblock 48 253 343 minecraft:stripped_dark_oak_log
setblock 48 253 350 minecraft:stripped_dark_oak_log
setblock 48 253 357 minecraft:stripped_dark_oak_log
setblock 49 253 323 minecraft:stripped_dark_oak_log
fill 49 253 333 49 269 333 minecraft:stripped_dark_oak_log
setblock 49 253 334 minecraft:shroomlight
fill 49 253 335 49 269 335 minecraft:stripped_dark_oak_log
setblock 49 253 336 minecraft:shroomlight
fill 49 253 337 49 269 337 minecraft:stripped_dark_oak_log
setblock 49 253 338 minecraft:shroomlight
fill 49 253 339 49 269 339 minecraft:stripped_dark_oak_log
setblock 49 253 340 minecraft:shroomlight
fill 49 253 341 49 269 341 minecraft:stripped_dark_oak_log
setblock 49 253 363 minecraft:stripped_dark_oak_log
setblock 50 253 333 minecraft:shroomlight
fill 50 253 334 50 269 334 minecraft:stripped_dark_oak_log
setblock 50 253 335 minecraft:shroomlight
fill 50 253 336 50 269 336 minecraft:stripped_dark_oak_log
setblock 50 253 337 minecraft:shroomlight
fill 50 253 338 50 269 338 minecraft:stripped_dark_oak_log
setblock 50 253 339 minecraft:shroomlight
fill 50 253 340 50 269 340 minecraft:stripped_dark_oak_log
setblock 50 253 341 minecraft:shroomlight
setblock 51 253 322 minecraft:red_concrete
fill 51 253 333 51 269 333 minecraft:stripped_dark_oak_log
setblock 51 253 334 minecraft:shroomlight
fill 51 253 335 51 269 335 minecraft:stripped_dark_oak_log
setblock 51 253 336 minecraft:shroomlight
fill 51 253 337 51 269 337 minecraft:stripped_dark_oak_log
setblock 51 253 338 minecraft:shroomlight
fill 51 253 339 51 269 339 minecraft:stripped_dark_oak_log
setblock 51 253 340 minecraft:shroomlight
fill 51 253 341 51 269 341 minecraft:stripped_dark_oak_log
setblock 52 253 333 minecraft:shroomlight
fill 52 253 334 52 269 334 minecraft:stripped_dark_oak_log
setblock 52 253 335 minecraft:shroomlight
fill 52 253 336 52 269 336 minecraft:stripped_dark_oak_log
setblock 52 253 337 minecraft:shroomlight
fill 52 253 338 52 269 338 minecraft:stripped_dark_oak_log
setblock 52 253 339 minecraft:shroomlight
fill 52 253 340 52 269 340 minecraft:stripped_dark_oak_log
setblock 52 253 341 minecraft:shroomlight
fill 53 253 333 53 269 333 minecraft:stripped_dark_oak_log
setblock 53 253 334 minecraft:shroomlight
fill 53 253 335 53 269 335 minecraft:stripped_dark_oak_log
setblock 53 253 336 minecraft:shroomlight
fill 53 253 337 53 269 337 minecraft:stripped_dark_oak_log
setblock 53 253 338 minecraft:shroomlight
fill 53 253 339 53 269 339 minecraft:stripped_dark_oak_log
setblock 53 253 340 minecraft:shroomlight
fill 53 253 341 53 269 341 minecraft:stripped_dark_oak_log
setblock 53 253 347 minecraft:dark_oak_planks
setblock 54 253 345 minecraft:dark_oak_planks
setblock 54 253 349 minecraft:dark_oak_planks
setblock 55 253 344 minecraft:dark_oak_planks
setblock 55 253 350 minecraft:dark_oak_planks
setblock 56 253 323 minecraft:stripped_dark_oak_log
setblock 56 253 363 minecraft:stripped_dark_oak_log
setblock 57 253 343 minecraft:dark_oak_planks
setblock 57 253 351 minecraft:dark_oak_planks
setblock 59 253 344 minecraft:dark_oak_planks
setblock 59 253 350 minecraft:dark_oak_planks
setblock 60 253 345 minecraft:dark_oak_planks
setblock 60 253 349 minecraft:dark_oak_planks
setblock 61 253 347 minecraft:dark_oak_planks
fill 62 253 364 62 308 364 minecraft:dark_oak_planks
setblock 63 253 323 minecraft:stripped_dark_oak_log
setblock 63 253 363 minecraft:stripped_dark_oak_log
fill 66 253 322 66 308 322 minecraft:dark_oak_planks
setblock 67 253 322 minecraft:red_concrete
setblock 70 253 323 minecraft:stripped_dark_oak_log
setblock 70 253 363 minecraft:stripped_dark_oak_log
setblock 77 253 323 minecraft:stripped_dark_oak_log
setblock 77 253 363 minecraft:stripped_dark_oak_log
fill 83 253 361 83 254 361 minecraft:shroomlight
schedule function dropper:buildpart/73_5 1t
