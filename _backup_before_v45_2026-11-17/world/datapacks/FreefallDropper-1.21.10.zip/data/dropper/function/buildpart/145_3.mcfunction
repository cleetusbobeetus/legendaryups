setblock 66 227 623 minecraft:light[level=14]
setblock 66 227 631 minecraft:light[level=14]
setblock 66 227 639 minecraft:light[level=14]
setblock 74 227 607 minecraft:light[level=14]
setblock 74 227 615 minecraft:light[level=14]
setblock 74 227 623 minecraft:light[level=14]
setblock 74 227 631 minecraft:light[level=14]
setblock 74 227 639 minecraft:light[level=14]
setblock 82 227 607 minecraft:light[level=14]
setblock 82 227 615 minecraft:light[level=14]
setblock 82 227 623 minecraft:light[level=14]
fill 47 228 609 47 233 609 minecraft:sea_lantern
fill 47 228 610 47 307 610 minecraft:gray_concrete
fill 47 228 613 47 307 616 minecraft:gray_concrete
fill 47 228 617 47 233 617 minecraft:sea_lantern
fill 47 228 625 47 233 625 minecraft:sea_lantern
fill 47 228 626 47 307 627 minecraft:gray_concrete
fill 47 228 632 47 307 632 minecraft:gray_concrete
fill 47 228 633 47 233 633 minecraft:sea_lantern
fill 47 228 634 47 307 634 minecraft:gray_concrete
fill 47 228 636 47 307 640 minecraft:gray_concrete
fill 47 228 641 47 233 641 minecraft:sea_lantern
fill 47 228 642 47 307 643 minecraft:gray_concrete
fill 50 228 646 50 233 646 minecraft:sea_lantern
fill 52 228 604 53 307 604 minecraft:gray_concrete
fill 54 228 604 54 233 604 minecraft:sea_lantern
fill 55 228 604 59 307 604 minecraft:gray_concrete
fill 58 228 646 58 233 646 minecraft:sea_lantern
fill 62 228 604 62 233 604 minecraft:sea_lantern
fill 66 228 646 66 233 646 minecraft:sea_lantern
fill 68 228 604 69 307 604 minecraft:gray_concrete
fill 69 228 646 73 307 646 minecraft:gray_concrete
fill 70 228 604 70 233 604 minecraft:sea_lantern
fill 74 228 646 74 233 646 minecraft:sea_lantern
fill 78 228 604 78 233 604 minecraft:sea_lantern
fill 82 228 646 82 233 646 minecraft:sea_lantern
fill 83 228 604 85 307 604 minecraft:gray_concrete
fill 86 228 604 86 233 604 minecraft:sea_lantern
fill 87 228 604 87 307 604 minecraft:gray_concrete
fill 89 228 608 89 307 608 minecraft:gray_concrete
fill 89 228 609 89 233 609 minecraft:sea_lantern
fill 89 228 616 89 307 616 minecraft:gray_concrete
fill 89 228 617 89 233 617 minecraft:sea_lantern
fill 89 228 625 89 233 625 minecraft:sea_lantern
fill 89 228 633 89 233 633 minecraft:sea_lantern
fill 89 228 640 89 307 640 minecraft:gray_concrete
fill 89 228 641 89 233 641 minecraft:sea_lantern
setblock 48 229 615 minecraft:sea_lantern
setblock 48 229 617 minecraft:sea_lantern
setblock 48 229 619 minecraft:sea_lantern
setblock 48 229 621 minecraft:sea_lantern
setblock 49 229 614 minecraft:sea_lantern
setblock 49 229 616 minecraft:sea_lantern
setblock 49 229 618 minecraft:sea_lantern
setblock 49 229 620 minecraft:sea_lantern
setblock 49 229 622 minecraft:sea_lantern
setblock 50 229 615 minecraft:sea_lantern
setblock 50 229 617 minecraft:sea_lantern
setblock 50 229 619 minecraft:sea_lantern
setblock 50 229 621 minecraft:sea_lantern
setblock 51 229 614 minecraft:sea_lantern
setblock 51 229 616 minecraft:sea_lantern
setblock 51 229 618 minecraft:sea_lantern
setblock 51 229 620 minecraft:sea_lantern
setblock 51 229 622 minecraft:sea_lantern
setblock 52 229 615 minecraft:sea_lantern
setblock 52 229 617 minecraft:sea_lantern
setblock 52 229 619 minecraft:sea_lantern
setblock 52 229 621 minecraft:sea_lantern
fill 52 229 634 52 230 634 minecraft:magenta_concrete
setblock 52 229 641 minecraft:sea_lantern
setblock 52 229 643 minecraft:sea_lantern
setblock 52 229 645 minecraft:sea_lantern
setblock 53 229 606 minecraft:sea_lantern
setblock 53 229 608 minecraft:sea_lantern
setblock 53 229 610 minecraft:sea_lantern
setblock 53 229 612 minecraft:sea_lantern
setblock 53 229 614 minecraft:sea_lantern
setblock 53 229 616 minecraft:sea_lantern
setblock 53 229 618 minecraft:sea_lantern
setblock 53 229 620 minecraft:sea_lantern
setblock 53 229 622 minecraft:sea_lantern
setblock 53 229 642 minecraft:sea_lantern
setblock 53 229 644 minecraft:sea_lantern
setblock 54 229 605 minecraft:sea_lantern
setblock 54 229 607 minecraft:sea_lantern
setblock 54 229 609 minecraft:sea_lantern
setblock 54 229 611 minecraft:sea_lantern
setblock 54 229 615 minecraft:sea_lantern
setblock 54 229 617 minecraft:sea_lantern
setblock 54 229 619 minecraft:sea_lantern
setblock 54 229 621 minecraft:sea_lantern
setblock 54 229 641 minecraft:sea_lantern
setblock 54 229 643 minecraft:sea_lantern
setblock 54 229 645 minecraft:sea_lantern
setblock 55 229 606 minecraft:sea_lantern
setblock 55 229 608 minecraft:sea_lantern
setblock 55 229 610 minecraft:sea_lantern
setblock 55 229 612 minecraft:sea_lantern
setblock 55 229 614 minecraft:sea_lantern
setblock 55 229 616 minecraft:sea_lantern
setblock 55 229 618 minecraft:sea_lantern
setblock 55 229 620 minecraft:sea_lantern
setblock 55 229 622 minecraft:sea_lantern
fill 55 229 624 56 230 624 minecraft:magenta_concrete
setblock 55 229 642 minecraft:sea_lantern
setblock 55 229 644 minecraft:sea_lantern
setblock 56 229 605 minecraft:sea_lantern
setblock 56 229 607 minecraft:sea_lantern
setblock 56 229 609 minecraft:sea_lantern
setblock 56 229 611 minecraft:sea_lantern
setblock 56 229 615 minecraft:sea_lantern
setblock 56 229 617 minecraft:sea_lantern
setblock 56 229 619 minecraft:sea_lantern
setblock 56 229 621 minecraft:sea_lantern
setblock 56 229 641 minecraft:sea_lantern
setblock 56 229 643 minecraft:sea_lantern
setblock 56 229 645 minecraft:sea_lantern
setblock 57 229 606 minecraft:sea_lantern
setblock 57 229 608 minecraft:sea_lantern
setblock 57 229 610 minecraft:sea_lantern
setblock 57 229 612 minecraft:sea_lantern
setblock 57 229 642 minecraft:sea_lantern
setblock 57 229 644 minecraft:sea_lantern
setblock 58 229 605 minecraft:sea_lantern
setblock 58 229 607 minecraft:sea_lantern
setblock 58 229 609 minecraft:sea_lantern
setblock 58 229 611 minecraft:sea_lantern
setblock 58 229 641 minecraft:sea_lantern
setblock 58 229 643 minecraft:sea_lantern
setblock 58 229 645 minecraft:sea_lantern
setblock 59 229 606 minecraft:sea_lantern
setblock 59 229 608 minecraft:sea_lantern
setblock 59 229 610 minecraft:sea_lantern
setblock 59 229 612 minecraft:sea_lantern
setblock 59 229 642 minecraft:sea_lantern
setblock 59 229 644 minecraft:sea_lantern
setblock 60 229 605 minecraft:sea_lantern
setblock 60 229 607 minecraft:sea_lantern
setblock 60 229 609 minecraft:sea_lantern
setblock 60 229 611 minecraft:sea_lantern
setblock 60 229 641 minecraft:sea_lantern
setblock 60 229 643 minecraft:sea_lantern
setblock 60 229 645 minecraft:sea_lantern
setblock 61 229 606 minecraft:sea_lantern
setblock 61 229 608 minecraft:sea_lantern
setblock 61 229 610 minecraft:sea_lantern
setblock 61 229 612 minecraft:sea_lantern
setblock 61 229 642 minecraft:sea_lantern
setblock 61 229 644 minecraft:sea_lantern
setblock 62 229 605 minecraft:sea_lantern
setblock 62 229 607 minecraft:sea_lantern
setblock 62 229 609 minecraft:sea_lantern
setblock 62 229 611 minecraft:sea_lantern
setblock 62 229 641 minecraft:sea_lantern
setblock 62 229 643 minecraft:sea_lantern
setblock 62 229 645 minecraft:sea_lantern
setblock 63 229 606 minecraft:sea_lantern
setblock 63 229 608 minecraft:sea_lantern
setblock 63 229 610 minecraft:sea_lantern
setblock 63 229 612 minecraft:sea_lantern
setblock 64 229 605 minecraft:sea_lantern
setblock 64 229 607 minecraft:sea_lantern
setblock 64 229 609 minecraft:sea_lantern
setblock 64 229 611 minecraft:sea_lantern
setblock 65 229 606 minecraft:sea_lantern
setblock 65 229 608 minecraft:sea_lantern
setblock 65 229 610 minecraft:sea_lantern
setblock 65 229 612 minecraft:sea_lantern
fill 48 230 615 48 231 615 minecraft:light_gray_concrete
fill 48 230 617 48 231 617 minecraft:light_gray_concrete
fill 48 230 619 48 231 619 minecraft:light_gray_concrete
fill 48 230 621 48 231 621 minecraft:light_gray_concrete
fill 49 230 614 49 231 614 minecraft:light_gray_concrete
fill 49 230 616 49 231 616 minecraft:light_gray_concrete
fill 49 230 618 49 231 618 minecraft:light_gray_concrete
fill 49 230 620 49 231 620 minecraft:light_gray_concrete
fill 49 230 622 49 231 622 minecraft:light_gray_concrete
fill 50 230 615 50 231 615 minecraft:light_gray_concrete
fill 50 230 617 50 231 617 minecraft:light_gray_concrete
fill 50 230 619 50 231 619 minecraft:light_gray_concrete
fill 50 230 621 50 231 621 minecraft:light_gray_concrete
fill 51 230 614 51 231 614 minecraft:light_gray_concrete
fill 51 230 616 51 231 616 minecraft:light_gray_concrete
fill 51 230 618 51 231 618 minecraft:light_gray_concrete
fill 51 230 620 51 231 620 minecraft:light_gray_concrete
fill 51 230 622 51 231 622 minecraft:light_gray_concrete
fill 52 230 615 52 231 615 minecraft:light_gray_concrete
fill 52 230 617 52 231 617 minecraft:light_gray_concrete
fill 52 230 619 52 231 619 minecraft:light_gray_concrete
fill 52 230 621 52 231 621 minecraft:light_gray_concrete
fill 52 230 641 52 231 641 minecraft:light_gray_concrete
fill 52 230 643 52 231 643 minecraft:light_gray_concrete
fill 52 230 645 52 231 645 minecraft:light_gray_concrete
fill 53 230 606 53 231 606 minecraft:light_gray_concrete
fill 53 230 608 53 231 608 minecraft:light_gray_concrete
fill 53 230 610 53 231 610 minecraft:light_gray_concrete
fill 53 230 612 53 231 612 minecraft:light_gray_concrete
fill 53 230 614 53 231 614 minecraft:light_gray_concrete
fill 53 230 616 53 231 616 minecraft:light_gray_concrete
fill 53 230 618 53 231 618 minecraft:light_gray_concrete
fill 53 230 620 53 231 620 minecraft:light_gray_concrete
fill 53 230 622 53 231 622 minecraft:light_gray_concrete
fill 53 230 642 53 231 642 minecraft:light_gray_concrete
fill 53 230 644 53 231 644 minecraft:light_gray_concrete
fill 54 230 605 54 231 605 minecraft:light_gray_concrete
fill 54 230 607 54 231 607 minecraft:light_gray_concrete
fill 54 230 609 54 231 609 minecraft:light_gray_concrete
fill 54 230 611 54 231 611 minecraft:light_gray_concrete
fill 54 230 615 54 231 615 minecraft:light_gray_concrete
fill 54 230 617 54 231 617 minecraft:light_gray_concrete
fill 54 230 619 54 231 619 minecraft:light_gray_concrete
fill 54 230 621 54 231 621 minecraft:light_gray_concrete
fill 54 230 641 54 231 641 minecraft:light_gray_concrete
fill 54 230 643 54 231 643 minecraft:light_gray_concrete
fill 54 230 645 54 231 645 minecraft:light_gray_concrete
fill 55 230 606 55 231 606 minecraft:light_gray_concrete
fill 55 230 608 55 231 608 minecraft:light_gray_concrete
fill 55 230 610 55 231 610 minecraft:light_gray_concrete
fill 55 230 612 55 231 612 minecraft:light_gray_concrete
fill 55 230 614 55 231 614 minecraft:light_gray_concrete
fill 55 230 616 55 231 616 minecraft:light_gray_concrete
fill 55 230 618 55 231 618 minecraft:light_gray_concrete
fill 55 230 620 55 231 620 minecraft:light_gray_concrete
fill 55 230 622 55 231 622 minecraft:light_gray_concrete
fill 55 230 642 55 231 642 minecraft:light_gray_concrete
fill 55 230 644 55 231 644 minecraft:light_gray_concrete
fill 56 230 605 56 231 605 minecraft:light_gray_concrete
fill 56 230 607 56 231 607 minecraft:light_gray_concrete
fill 56 230 609 56 231 609 minecraft:light_gray_concrete
fill 56 230 611 56 231 611 minecraft:light_gray_concrete
fill 56 230 615 56 231 615 minecraft:light_gray_concrete
fill 56 230 617 56 231 617 minecraft:light_gray_concrete
fill 56 230 619 56 231 619 minecraft:light_gray_concrete
fill 56 230 621 56 231 621 minecraft:light_gray_concrete
fill 56 230 641 56 231 641 minecraft:light_gray_concrete
fill 56 230 643 56 231 643 minecraft:light_gray_concrete
fill 56 230 645 56 231 645 minecraft:light_gray_concrete
fill 57 230 606 57 231 606 minecraft:light_gray_concrete
fill 57 230 608 57 231 608 minecraft:light_gray_concrete
fill 57 230 610 57 231 610 minecraft:light_gray_concrete
fill 57 230 612 57 231 612 minecraft:light_gray_concrete
fill 57 230 642 57 231 642 minecraft:light_gray_concrete
fill 57 230 644 57 231 644 minecraft:light_gray_concrete
fill 58 230 605 58 231 605 minecraft:light_gray_concrete
fill 58 230 607 58 231 607 minecraft:light_gray_concrete
fill 58 230 609 58 231 609 minecraft:light_gray_concrete
fill 58 230 611 58 231 611 minecraft:light_gray_concrete
fill 58 230 641 58 231 641 minecraft:light_gray_concrete
fill 58 230 643 58 231 643 minecraft:light_gray_concrete
fill 58 230 645 58 231 645 minecraft:light_gray_concrete
fill 59 230 606 59 231 606 minecraft:light_gray_concrete
fill 59 230 608 59 231 608 minecraft:light_gray_concrete
fill 59 230 610 59 231 610 minecraft:light_gray_concrete
fill 59 230 612 59 231 612 minecraft:light_gray_concrete
fill 59 230 642 59 231 642 minecraft:light_gray_concrete
fill 59 230 644 59 231 644 minecraft:light_gray_concrete
fill 60 230 605 60 231 605 minecraft:light_gray_concrete
fill 60 230 607 60 231 607 minecraft:light_gray_concrete
fill 60 230 609 60 231 609 minecraft:light_gray_concrete
fill 60 230 611 60 231 611 minecraft:light_gray_concrete
fill 60 230 641 60 231 641 minecraft:light_gray_concrete
fill 60 230 643 60 231 643 minecraft:light_gray_concrete
fill 60 230 645 60 231 645 minecraft:light_gray_concrete
fill 61 230 606 61 231 606 minecraft:light_gray_concrete
fill 61 230 608 61 231 608 minecraft:light_gray_concrete
fill 61 230 610 61 231 610 minecraft:light_gray_concrete
fill 61 230 612 61 231 612 minecraft:light_gray_concrete
fill 61 230 642 61 231 642 minecraft:light_gray_concrete
fill 61 230 644 61 231 644 minecraft:light_gray_concrete
fill 62 230 605 62 231 605 minecraft:light_gray_concrete
fill 62 230 607 62 231 607 minecraft:light_gray_concrete
fill 62 230 609 62 231 609 minecraft:light_gray_concrete
fill 62 230 611 62 231 611 minecraft:light_gray_concrete
fill 62 230 641 62 231 641 minecraft:light_gray_concrete
fill 62 230 643 62 231 643 minecraft:light_gray_concrete
fill 62 230 645 62 231 645 minecraft:light_gray_concrete
fill 63 230 606 63 231 606 minecraft:light_gray_concrete
fill 63 230 608 63 231 608 minecraft:light_gray_concrete
fill 63 230 610 63 231 610 minecraft:light_gray_concrete
fill 63 230 612 63 231 612 minecraft:light_gray_concrete
fill 64 230 605 64 231 605 minecraft:light_gray_concrete
fill 64 230 607 64 231 607 minecraft:light_gray_concrete
fill 64 230 609 64 231 609 minecraft:light_gray_concrete
fill 64 230 611 64 231 611 minecraft:light_gray_concrete
fill 65 230 606 65 231 606 minecraft:light_gray_concrete
fill 65 230 608 65 231 608 minecraft:light_gray_concrete
fill 65 230 610 65 231 610 minecraft:light_gray_concrete
fill 65 230 612 65 231 612 minecraft:light_gray_concrete
setblock 48 232 615 minecraft:sea_lantern
setblock 48 232 617 minecraft:sea_lantern
setblock 48 232 619 minecraft:sea_lantern
setblock 48 232 621 minecraft:sea_lantern
setblock 49 232 614 minecraft:sea_lantern
setblock 49 232 616 minecraft:sea_lantern
setblock 49 232 618 minecraft:sea_lantern
setblock 49 232 620 minecraft:sea_lantern
setblock 49 232 622 minecraft:sea_lantern
setblock 50 232 615 minecraft:sea_lantern
setblock 50 232 617 minecraft:sea_lantern
setblock 50 232 619 minecraft:sea_lantern
setblock 50 232 621 minecraft:sea_lantern
setblock 51 232 614 minecraft:sea_lantern
setblock 51 232 616 minecraft:sea_lantern
setblock 51 232 618 minecraft:sea_lantern
setblock 51 232 620 minecraft:sea_lantern
setblock 51 232 622 minecraft:sea_lantern
setblock 52 232 615 minecraft:sea_lantern
setblock 52 232 617 minecraft:sea_lantern
setblock 52 232 619 minecraft:sea_lantern
setblock 52 232 621 minecraft:sea_lantern
setblock 52 232 641 minecraft:sea_lantern
setblock 52 232 643 minecraft:sea_lantern
setblock 52 232 645 minecraft:sea_lantern
setblock 53 232 606 minecraft:sea_lantern
setblock 53 232 608 minecraft:sea_lantern
setblock 53 232 610 minecraft:sea_lantern
setblock 53 232 612 minecraft:sea_lantern
setblock 53 232 614 minecraft:sea_lantern
setblock 53 232 616 minecraft:sea_lantern
setblock 53 232 618 minecraft:sea_lantern
setblock 53 232 620 minecraft:sea_lantern
setblock 53 232 622 minecraft:sea_lantern
setblock 53 232 642 minecraft:sea_lantern
setblock 53 232 644 minecraft:sea_lantern
setblock 54 232 605 minecraft:sea_lantern
setblock 54 232 607 minecraft:sea_lantern
setblock 54 232 609 minecraft:sea_lantern
setblock 54 232 611 minecraft:sea_lantern
setblock 54 232 615 minecraft:sea_lantern
setblock 54 232 617 minecraft:sea_lantern
setblock 54 232 619 minecraft:sea_lantern
setblock 54 232 621 minecraft:sea_lantern
setblock 54 232 641 minecraft:sea_lantern
setblock 54 232 643 minecraft:sea_lantern
setblock 54 232 645 minecraft:sea_lantern
setblock 55 232 606 minecraft:sea_lantern
setblock 55 232 608 minecraft:sea_lantern
setblock 55 232 610 minecraft:sea_lantern
setblock 55 232 612 minecraft:sea_lantern
setblock 55 232 614 minecraft:sea_lantern
setblock 55 232 616 minecraft:sea_lantern
setblock 55 232 618 minecraft:sea_lantern
setblock 55 232 620 minecraft:sea_lantern
setblock 55 232 622 minecraft:sea_lantern
setblock 55 232 642 minecraft:sea_lantern
setblock 55 232 644 minecraft:sea_lantern
setblock 56 232 605 minecraft:sea_lantern
setblock 56 232 607 minecraft:sea_lantern
setblock 56 232 609 minecraft:sea_lantern
setblock 56 232 611 minecraft:sea_lantern
setblock 56 232 615 minecraft:sea_lantern
setblock 56 232 617 minecraft:sea_lantern
setblock 56 232 619 minecraft:sea_lantern
setblock 56 232 621 minecraft:sea_lantern
setblock 56 232 641 minecraft:sea_lantern
setblock 56 232 643 minecraft:sea_lantern
setblock 56 232 645 minecraft:sea_lantern
setblock 57 232 606 minecraft:sea_lantern
setblock 57 232 608 minecraft:sea_lantern
setblock 57 232 610 minecraft:sea_lantern
setblock 57 232 612 minecraft:sea_lantern
setblock 57 232 642 minecraft:sea_lantern
setblock 57 232 644 minecraft:sea_lantern
setblock 58 232 605 minecraft:sea_lantern
setblock 58 232 607 minecraft:sea_lantern
setblock 58 232 609 minecraft:sea_lantern
setblock 58 232 611 minecraft:sea_lantern
setblock 58 232 641 minecraft:sea_lantern
setblock 58 232 643 minecraft:sea_lantern
setblock 58 232 645 minecraft:sea_lantern
setblock 59 232 606 minecraft:sea_lantern
setblock 59 232 608 minecraft:sea_lantern
setblock 59 232 610 minecraft:sea_lantern
setblock 59 232 612 minecraft:sea_lantern
setblock 59 232 642 minecraft:sea_lantern
setblock 59 232 644 minecraft:sea_lantern
setblock 60 232 605 minecraft:sea_lantern
setblock 60 232 607 minecraft:sea_lantern
setblock 60 232 609 minecraft:sea_lantern
setblock 60 232 611 minecraft:sea_lantern
setblock 60 232 641 minecraft:sea_lantern
setblock 60 232 643 minecraft:sea_lantern
setblock 60 232 645 minecraft:sea_lantern
setblock 61 232 606 minecraft:sea_lantern
setblock 61 232 608 minecraft:sea_lantern
setblock 61 232 610 minecraft:sea_lantern
setblock 61 232 612 minecraft:sea_lantern
setblock 61 232 642 minecraft:sea_lantern
setblock 61 232 644 minecraft:sea_lantern
setblock 62 232 605 minecraft:sea_lantern
setblock 62 232 607 minecraft:sea_lantern
setblock 62 232 609 minecraft:sea_lantern
setblock 62 232 611 minecraft:sea_lantern
setblock 62 232 641 minecraft:sea_lantern
setblock 62 232 643 minecraft:sea_lantern
setblock 62 232 645 minecraft:sea_lantern
setblock 63 232 606 minecraft:sea_lantern
setblock 63 232 608 minecraft:sea_lantern
setblock 63 232 610 minecraft:sea_lantern
setblock 63 232 612 minecraft:sea_lantern
setblock 64 232 605 minecraft:sea_lantern
setblock 64 232 607 minecraft:sea_lantern
setblock 64 232 609 minecraft:sea_lantern
setblock 64 232 611 minecraft:sea_lantern
setblock 65 232 606 minecraft:sea_lantern
setblock 65 232 608 minecraft:sea_lantern
setblock 65 232 610 minecraft:sea_lantern
setblock 65 232 612 minecraft:sea_lantern
fill 73 232 638 74 233 639 minecraft:glass
fill 74 232 640 74 233 640 minecraft:glass
fill 48 233 615 48 235 615 minecraft:light_gray_concrete
fill 48 233 617 48 235 617 minecraft:light_gray_concrete
fill 48 233 619 48 235 619 minecraft:light_gray_concrete
fill 48 233 621 48 235 621 minecraft:light_gray_concrete
fill 49 233 614 49 235 614 minecraft:light_gray_concrete
fill 49 233 616 49 235 616 minecraft:light_gray_concrete
fill 49 233 618 49 235 618 minecraft:light_gray_concrete
fill 49 233 620 49 235 620 minecraft:light_gray_concrete
fill 49 233 622 49 235 622 minecraft:light_gray_concrete
fill 50 233 615 50 235 615 minecraft:light_gray_concrete
fill 50 233 617 50 235 617 minecraft:light_gray_concrete
fill 50 233 619 50 235 619 minecraft:light_gray_concrete
fill 50 233 621 50 235 621 minecraft:light_gray_concrete
fill 51 233 614 51 235 614 minecraft:light_gray_concrete
fill 51 233 616 51 235 616 minecraft:light_gray_concrete
fill 51 233 618 51 235 618 minecraft:light_gray_concrete
fill 51 233 620 51 235 620 minecraft:light_gray_concrete
fill 51 233 622 51 235 622 minecraft:light_gray_concrete
fill 52 233 615 52 235 615 minecraft:light_gray_concrete
fill 52 233 617 52 235 617 minecraft:light_gray_concrete
fill 52 233 619 52 235 619 minecraft:light_gray_concrete
fill 52 233 621 52 235 621 minecraft:light_gray_concrete
fill 52 233 641 52 235 641 minecraft:light_gray_concrete
fill 52 233 643 52 235 643 minecraft:light_gray_concrete
fill 52 233 645 52 235 645 minecraft:light_gray_concrete
fill 53 233 606 53 235 606 minecraft:light_gray_concrete
fill 53 233 608 53 235 608 minecraft:light_gray_concrete
fill 53 233 610 53 235 610 minecraft:light_gray_concrete
fill 53 233 612 53 235 612 minecraft:light_gray_concrete
fill 53 233 614 53 235 614 minecraft:light_gray_concrete
fill 53 233 616 53 235 616 minecraft:light_gray_concrete
fill 53 233 618 53 235 618 minecraft:light_gray_concrete
fill 53 233 620 53 235 620 minecraft:light_gray_concrete
fill 53 233 622 53 235 622 minecraft:light_gray_concrete
fill 53 233 642 53 235 642 minecraft:light_gray_concrete
fill 53 233 644 53 235 644 minecraft:light_gray_concrete
fill 54 233 605 54 235 605 minecraft:light_gray_concrete
fill 54 233 607 54 235 607 minecraft:light_gray_concrete
fill 54 233 609 54 235 609 minecraft:light_gray_concrete
fill 54 233 611 54 235 611 minecraft:light_gray_concrete
fill 54 233 615 54 235 615 minecraft:light_gray_concrete
fill 54 233 617 54 235 617 minecraft:light_gray_concrete
fill 54 233 619 54 235 619 minecraft:light_gray_concrete
fill 54 233 621 54 235 621 minecraft:light_gray_concrete
fill 54 233 641 54 235 641 minecraft:light_gray_concrete
fill 54 233 643 54 235 643 minecraft:light_gray_concrete
fill 54 233 645 54 235 645 minecraft:light_gray_concrete
fill 55 233 606 55 235 606 minecraft:light_gray_concrete
fill 55 233 608 55 235 608 minecraft:light_gray_concrete
fill 55 233 610 55 235 610 minecraft:light_gray_concrete
fill 55 233 612 55 235 612 minecraft:light_gray_concrete
fill 55 233 614 55 235 614 minecraft:light_gray_concrete
fill 55 233 616 55 235 616 minecraft:light_gray_concrete
fill 55 233 618 55 235 618 minecraft:light_gray_concrete
fill 55 233 620 55 235 620 minecraft:light_gray_concrete
fill 55 233 622 55 235 622 minecraft:light_gray_concrete
fill 55 233 642 55 235 642 minecraft:light_gray_concrete
fill 55 233 644 55 235 644 minecraft:light_gray_concrete
fill 56 233 605 56 235 605 minecraft:light_gray_concrete
fill 56 233 607 56 235 607 minecraft:light_gray_concrete
fill 56 233 609 56 235 609 minecraft:light_gray_concrete
fill 56 233 611 56 235 611 minecraft:light_gray_concrete
fill 56 233 615 56 235 615 minecraft:light_gray_concrete
fill 56 233 617 56 235 617 minecraft:light_gray_concrete
fill 56 233 619 56 235 619 minecraft:light_gray_concrete
fill 56 233 621 56 235 621 minecraft:light_gray_concrete
fill 56 233 641 56 235 641 minecraft:light_gray_concrete
fill 56 233 643 56 235 643 minecraft:light_gray_concrete
fill 56 233 645 56 235 645 minecraft:light_gray_concrete
fill 57 233 606 57 235 606 minecraft:light_gray_concrete
fill 57 233 608 57 235 608 minecraft:light_gray_concrete
fill 57 233 610 57 235 610 minecraft:light_gray_concrete
fill 57 233 612 57 235 612 minecraft:light_gray_concrete
fill 57 233 642 57 235 642 minecraft:light_gray_concrete
fill 57 233 644 57 235 644 minecraft:light_gray_concrete
fill 58 233 605 58 235 605 minecraft:light_gray_concrete
fill 58 233 607 58 235 607 minecraft:light_gray_concrete
fill 58 233 609 58 235 609 minecraft:light_gray_concrete
fill 58 233 611 58 235 611 minecraft:light_gray_concrete
fill 58 233 641 58 235 641 minecraft:light_gray_concrete
fill 58 233 643 58 235 643 minecraft:light_gray_concrete
fill 58 233 645 58 235 645 minecraft:light_gray_concrete
fill 59 233 606 59 235 606 minecraft:light_gray_concrete
fill 59 233 608 59 235 608 minecraft:light_gray_concrete
fill 59 233 610 59 235 610 minecraft:light_gray_concrete
fill 59 233 612 59 235 612 minecraft:light_gray_concrete
fill 59 233 642 59 235 642 minecraft:light_gray_concrete
fill 59 233 644 59 235 644 minecraft:light_gray_concrete
fill 60 233 605 60 235 605 minecraft:light_gray_concrete
fill 60 233 607 60 235 607 minecraft:light_gray_concrete
fill 60 233 609 60 235 609 minecraft:light_gray_concrete
fill 60 233 611 60 235 611 minecraft:light_gray_concrete
fill 60 233 641 60 235 641 minecraft:light_gray_concrete
fill 60 233 643 60 235 643 minecraft:light_gray_concrete
fill 60 233 645 60 235 645 minecraft:light_gray_concrete
fill 61 233 606 61 235 606 minecraft:light_gray_concrete
fill 61 233 608 61 235 608 minecraft:light_gray_concrete
fill 61 233 610 61 235 610 minecraft:light_gray_concrete
fill 61 233 612 61 235 612 minecraft:light_gray_concrete
fill 61 233 642 61 235 642 minecraft:light_gray_concrete
fill 61 233 644 61 235 644 minecraft:light_gray_concrete
fill 62 233 605 62 235 605 minecraft:light_gray_concrete
fill 62 233 607 62 235 607 minecraft:light_gray_concrete
fill 62 233 609 62 235 609 minecraft:light_gray_concrete
fill 62 233 611 62 235 611 minecraft:light_gray_concrete
fill 62 233 641 62 235 641 minecraft:light_gray_concrete
fill 62 233 643 62 235 643 minecraft:light_gray_concrete
fill 62 233 645 62 235 645 minecraft:light_gray_concrete
fill 63 233 606 63 235 606 minecraft:light_gray_concrete
fill 63 233 608 63 235 608 minecraft:light_gray_concrete
fill 63 233 610 63 235 610 minecraft:light_gray_concrete
fill 63 233 612 63 235 612 minecraft:light_gray_concrete
fill 64 233 605 64 235 605 minecraft:light_gray_concrete
fill 64 233 607 64 235 607 minecraft:light_gray_concrete
fill 64 233 609 64 235 609 minecraft:light_gray_concrete
fill 64 233 611 64 235 611 minecraft:light_gray_concrete
fill 65 233 606 65 235 606 minecraft:light_gray_concrete
fill 65 233 608 65 235 608 minecraft:light_gray_concrete
fill 65 233 610 65 235 610 minecraft:light_gray_concrete
fill 65 233 612 65 235 612 minecraft:light_gray_concrete
fill 47 234 609 47 245 609 minecraft:gray_concrete
fill 47 234 617 47 245 617 minecraft:gray_concrete
fill 47 234 625 47 245 625 minecraft:gray_concrete
fill 47 234 633 47 245 633 minecraft:gray_concrete
fill 47 234 641 47 245 641 minecraft:gray_concrete
fill 50 234 646 50 245 646 minecraft:gray_concrete
fill 54 234 604 54 245 604 minecraft:gray_concrete
fill 58 234 646 58 245 646 minecraft:gray_concrete
fill 62 234 604 62 245 604 minecraft:gray_concrete
fill 66 234 646 66 245 646 minecraft:gray_concrete
fill 70 234 604 70 245 604 minecraft:gray_concrete
fill 74 234 646 74 245 646 minecraft:gray_concrete
fill 78 234 604 78 245 604 minecraft:gray_concrete
fill 82 234 646 82 245 646 minecraft:gray_concrete
fill 86 234 604 86 245 604 minecraft:gray_concrete
fill 89 234 609 89 245 609 minecraft:gray_concrete
fill 89 234 617 89 245 617 minecraft:gray_concrete
fill 89 234 625 89 245 625 minecraft:gray_concrete
fill 89 234 633 89 245 633 minecraft:gray_concrete
fill 89 234 641 89 245 641 minecraft:gray_concrete
setblock 50 235 607 minecraft:light[level=14]
setblock 50 235 623 minecraft:light[level=14]
setblock 50 235 631 minecraft:light[level=14]
setblock 50 235 639 minecraft:light[level=14]
setblock 58 235 615 minecraft:light[level=14]
setblock 58 235 623 minecraft:light[level=14]
setblock 58 235 631 minecraft:light[level=14]
setblock 58 235 639 minecraft:light[level=14]
setblock 66 235 607 minecraft:light[level=14]
setblock 66 235 615 minecraft:light[level=14]
setblock 66 235 623 minecraft:light[level=14]
setblock 66 235 631 minecraft:light[level=14]
setblock 66 235 639 minecraft:light[level=14]
setblock 74 235 607 minecraft:light[level=14]
setblock 74 235 615 minecraft:light[level=14]
setblock 74 235 623 minecraft:light[level=14]
setblock 74 235 631 minecraft:light[level=14]
setblock 74 235 639 minecraft:light[level=14]
setblock 82 235 607 minecraft:light[level=14]
setblock 82 235 615 minecraft:light[level=14]
setblock 82 235 623 minecraft:light[level=14]
fill 66 240 621 68 240 623 minecraft:redstone_block
fill 66 240 627 68 240 629 minecraft:redstone_block
fill 73 240 620 75 240 622 minecraft:redstone_block
fill 73 240 628 75 240 630 minecraft:redstone_block
fill 48 241 605 50 241 609 minecraft:gray_concrete
fill 48 241 610 50 241 614 minecraft:black_concrete
fill 48 241 615 50 241 619 minecraft:gray_concrete
fill 48 241 620 50 241 624 minecraft:black_concrete
fill 48 241 625 50 241 629 minecraft:gray_concrete
fill 48 241 630 50 241 634 minecraft:black_concrete
fill 48 241 635 50 241 639 minecraft:gray_concrete
fill 48 241 640 50 241 644 minecraft:black_concrete
fill 48 241 645 50 241 645 minecraft:gray_concrete
fill 51 241 605 55 241 609 minecraft:black_concrete
fill 51 241 610 55 241 614 minecraft:gray_concrete
fill 51 241 615 55 241 619 minecraft:black_concrete
fill 51 241 620 55 241 624 minecraft:gray_concrete
fill 51 241 625 55 241 629 minecraft:black_concrete
fill 51 241 630 55 241 634 minecraft:gray_concrete
fill 51 241 635 55 241 639 minecraft:black_concrete
fill 51 241 640 55 241 644 minecraft:gray_concrete
fill 51 241 645 55 241 645 minecraft:black_concrete
fill 56 241 605 60 241 609 minecraft:gray_concrete
fill 56 241 610 60 241 614 minecraft:black_concrete
fill 56 241 615 60 241 619 minecraft:gray_concrete
fill 56 241 620 60 241 624 minecraft:black_concrete
fill 56 241 625 60 241 629 minecraft:gray_concrete
fill 56 241 630 60 241 634 minecraft:black_concrete
fill 56 241 635 60 241 639 minecraft:gray_concrete
fill 56 241 640 60 241 644 minecraft:black_concrete
fill 56 241 645 60 241 645 minecraft:gray_concrete
fill 61 241 605 65 241 609 minecraft:black_concrete
fill 61 241 610 65 241 614 minecraft:gray_concrete
fill 61 241 615 65 241 619 minecraft:black_concrete
fill 61 241 620 65 241 624 minecraft:gray_concrete
fill 61 241 625 65 241 629 minecraft:black_concrete
fill 61 241 630 65 241 634 minecraft:gray_concrete
fill 61 241 635 65 241 639 minecraft:black_concrete
fill 61 241 640 65 241 644 minecraft:gray_concrete
fill 61 241 645 65 241 645 minecraft:black_concrete
fill 66 241 605 70 241 609 minecraft:gray_concrete
fill 66 241 610 70 241 614 minecraft:black_concrete
fill 66 241 615 70 241 619 minecraft:gray_concrete
fill 66 241 620 70 241 620 minecraft:black_concrete
fill 66 241 624 69 241 624 minecraft:black_concrete
fill 66 241 625 69 241 626 minecraft:gray_concrete
fill 66 241 630 70 241 634 minecraft:black_concrete
fill 66 241 635 70 241 639 minecraft:gray_concrete
fill 66 241 640 70 241 644 minecraft:black_concrete
fill 66 241 645 70 241 645 minecraft:gray_concrete
fill 69 241 621 70 241 623 minecraft:black_concrete
fill 69 241 627 70 241 629 minecraft:gray_concrete
fill 71 241 605 75 241 609 minecraft:black_concrete
fill 71 241 610 75 241 614 minecraft:gray_concrete
fill 71 241 615 75 241 619 minecraft:black_concrete
fill 71 241 620 72 241 623 minecraft:gray_concrete
fill 71 241 627 72 241 629 minecraft:black_concrete
fill 71 241 630 72 241 634 minecraft:gray_concrete
fill 71 241 635 75 241 639 minecraft:black_concrete
fill 71 241 640 75 241 644 minecraft:gray_concrete
fill 71 241 645 75 241 645 minecraft:black_concrete
fill 73 241 623 75 241 624 minecraft:gray_concrete
fill 73 241 625 75 241 627 minecraft:black_concrete
fill 73 241 631 75 241 634 minecraft:gray_concrete
fill 76 241 605 80 241 609 minecraft:gray_concrete
fill 76 241 610 80 241 614 minecraft:black_concrete
fill 76 241 615 80 241 619 minecraft:gray_concrete
fill 76 241 620 80 241 624 minecraft:black_concrete
fill 76 241 625 80 241 629 minecraft:gray_concrete
fill 76 241 630 80 241 634 minecraft:black_concrete
fill 76 241 635 80 241 639 minecraft:gray_concrete
fill 76 241 640 80 241 644 minecraft:black_concrete
fill 76 241 645 80 241 645 minecraft:gray_concrete
fill 81 241 605 85 241 609 minecraft:black_concrete
fill 81 241 610 85 241 614 minecraft:gray_concrete
fill 81 241 615 85 241 619 minecraft:black_concrete
fill 81 241 620 85 241 624 minecraft:gray_concrete
fill 81 241 625 85 241 629 minecraft:black_concrete
fill 81 241 630 85 241 634 minecraft:gray_concrete
fill 81 241 635 85 241 639 minecraft:black_concrete
fill 81 241 640 85 241 644 minecraft:gray_concrete
fill 81 241 645 85 241 645 minecraft:black_concrete
fill 86 241 605 88 241 609 minecraft:gray_concrete
fill 86 241 610 88 241 614 minecraft:black_concrete
fill 86 241 615 88 241 619 minecraft:gray_concrete
fill 86 241 620 88 241 624 minecraft:black_concrete
fill 86 241 625 88 241 629 minecraft:gray_concrete
fill 86 241 630 88 241 634 minecraft:black_concrete
fill 86 241 635 88 241 639 minecraft:gray_concrete
fill 86 241 640 88 241 644 minecraft:black_concrete
fill 86 241 645 88 241 645 minecraft:gray_concrete
fill 48 242 605 88 242 605 minecraft:magenta_concrete
fill 48 242 606 50 242 609 minecraft:gray_concrete
fill 48 242 610 88 242 610 minecraft:magenta_concrete
fill 48 242 611 50 242 614 minecraft:black_concrete
fill 48 242 615 88 242 615 minecraft:magenta_concrete
fill 48 242 616 50 242 619 minecraft:gray_concrete
fill 48 242 620 64 242 620 minecraft:magenta_concrete
fill 48 242 621 50 242 624 minecraft:black_concrete
fill 48 242 625 68 242 625 minecraft:magenta_concrete
fill 48 242 626 50 242 629 minecraft:gray_concrete
fill 48 242 630 64 242 630 minecraft:magenta_concrete
fill 48 242 631 50 242 634 minecraft:black_concrete
fill 48 242 635 88 242 635 minecraft:magenta_concrete
fill 48 242 636 50 242 639 minecraft:gray_concrete
fill 48 242 640 88 242 640 minecraft:magenta_concrete
fill 48 242 641 50 242 644 minecraft:black_concrete
fill 48 242 645 88 242 645 minecraft:magenta_concrete
fill 51 242 606 51 242 609 minecraft:magenta_concrete
fill 51 242 611 51 242 614 minecraft:magenta_concrete
fill 51 242 616 51 242 619 minecraft:magenta_concrete
fill 51 242 621 51 242 624 minecraft:magenta_concrete
fill 51 242 626 51 242 629 minecraft:magenta_concrete
fill 51 242 631 51 242 634 minecraft:magenta_concrete
fill 51 242 636 51 242 639 minecraft:magenta_concrete
fill 51 242 641 51 242 644 minecraft:magenta_concrete
fill 52 242 606 55 242 609 minecraft:black_concrete
fill 52 242 611 55 242 614 minecraft:gray_concrete
fill 52 242 616 55 242 619 minecraft:black_concrete
fill 52 242 621 55 242 624 minecraft:gray_concrete
fill 52 242 626 55 242 629 minecraft:black_concrete
fill 52 242 631 55 242 634 minecraft:gray_concrete
fill 52 242 636 55 242 639 minecraft:black_concrete
fill 52 242 641 55 242 644 minecraft:gray_concrete
fill 56 242 606 56 242 609 minecraft:magenta_concrete
fill 56 242 611 56 242 614 minecraft:magenta_concrete
fill 56 242 616 56 242 619 minecraft:magenta_concrete
fill 56 242 621 56 242 624 minecraft:magenta_concrete
fill 56 242 626 56 242 629 minecraft:magenta_concrete
fill 56 242 631 56 242 634 minecraft:magenta_concrete
fill 56 242 636 56 242 639 minecraft:magenta_concrete
fill 56 242 641 56 242 644 minecraft:magenta_concrete
fill 57 242 606 60 242 609 minecraft:gray_concrete
fill 57 242 611 60 242 614 minecraft:black_concrete
fill 57 242 616 60 242 619 minecraft:gray_concrete
fill 57 242 621 60 242 624 minecraft:black_concrete
fill 57 242 626 60 242 629 minecraft:gray_concrete
fill 57 242 631 60 242 634 minecraft:black_concrete
fill 57 242 636 60 242 639 minecraft:gray_concrete
fill 57 242 641 60 242 644 minecraft:black_concrete
fill 61 242 606 61 242 609 minecraft:magenta_concrete
fill 61 242 611 61 242 614 minecraft:magenta_concrete
fill 61 242 616 61 242 619 minecraft:magenta_concrete
fill 61 242 621 61 242 624 minecraft:magenta_concrete
fill 61 242 626 61 242 629 minecraft:magenta_concrete
fill 61 242 631 61 242 634 minecraft:magenta_concrete
fill 61 242 636 61 242 639 minecraft:magenta_concrete
fill 61 242 641 61 242 644 minecraft:magenta_concrete
fill 62 242 606 65 242 609 minecraft:black_concrete
fill 62 242 611 65 242 614 minecraft:gray_concrete
fill 62 242 616 65 242 619 minecraft:black_concrete
fill 62 242 621 64 242 624 minecraft:gray_concrete
fill 62 242 626 64 242 629 minecraft:black_concrete
fill 62 242 631 65 242 634 minecraft:gray_concrete
fill 62 242 636 65 242 639 minecraft:black_concrete
fill 62 242 641 65 242 644 minecraft:gray_concrete
fill 65 242 620 65 242 624 minecraft:sea_lantern
fill 65 242 626 65 242 630 minecraft:sea_lantern
fill 66 242 606 66 242 609 minecraft:magenta_concrete
fill 66 242 611 66 242 614 minecraft:magenta_concrete
fill 66 242 616 66 242 619 minecraft:magenta_concrete
fill 66 242 620 69 242 620 minecraft:sea_lantern
fill 66 242 621 68 242 623 minecraft:gray_concrete
fill 66 242 624 69 242 624 minecraft:sea_lantern
fill 66 242 626 69 242 626 minecraft:sea_lantern
fill 66 242 627 68 242 629 minecraft:gray_concrete
fill 66 242 630 69 242 630 minecraft:sea_lantern
fill 66 242 631 66 242 634 minecraft:magenta_concrete
fill 66 242 636 66 242 639 minecraft:magenta_concrete
fill 66 242 641 66 242 644 minecraft:magenta_concrete
fill 67 242 606 70 242 609 minecraft:gray_concrete
fill 67 242 611 70 242 614 minecraft:black_concrete
fill 67 242 616 70 242 619 minecraft:gray_concrete
fill 67 242 631 70 242 634 minecraft:black_concrete
fill 67 242 636 70 242 639 minecraft:gray_concrete
fill 67 242 641 70 242 644 minecraft:black_concrete
fill 69 242 621 69 242 623 minecraft:sea_lantern
setblock 69 242 625 minecraft:sea_lantern
fill 69 242 627 69 242 629 minecraft:sea_lantern
fill 70 242 620 71 242 620 minecraft:magenta_concrete
fill 70 242 621 70 242 622 minecraft:black_concrete
fill 70 242 623 76 242 623 minecraft:sea_lantern
fill 70 242 627 76 242 627 minecraft:sea_lantern
fill 70 242 628 70 242 629 minecraft:gray_concrete
fill 70 242 630 71 242 630 minecraft:magenta_concrete
fill 71 242 606 71 242 609 minecraft:magenta_concrete
fill 71 242 611 71 242 614 minecraft:magenta_concrete
fill 71 242 616 71 242 619 minecraft:magenta_concrete
fill 71 242 621 71 242 622 minecraft:magenta_concrete
fill 71 242 628 71 242 629 minecraft:magenta_concrete
fill 71 242 631 71 242 634 minecraft:magenta_concrete
fill 71 242 636 71 242 639 minecraft:magenta_concrete
fill 71 242 641 71 242 644 minecraft:magenta_concrete
fill 72 242 606 75 242 609 minecraft:black_concrete
fill 72 242 611 75 242 614 minecraft:gray_concrete
fill 72 242 616 75 242 618 minecraft:black_concrete
fill 72 242 619 72 242 622 minecraft:sea_lantern
fill 72 242 628 72 242 631 minecraft:sea_lantern
fill 72 242 632 75 242 634 minecraft:gray_concrete
fill 72 242 636 75 242 639 minecraft:black_concrete
fill 72 242 641 75 242 644 minecraft:gray_concrete
fill 73 242 619 76 242 619 minecraft:sea_lantern
fill 73 242 620 75 242 622 minecraft:gray_concrete
fill 73 242 624 73 242 626 minecraft:sea_lantern
fill 73 242 628 75 242 630 minecraft:gray_concrete
fill 73 242 631 76 242 631 minecraft:sea_lantern
fill 74 242 624 75 242 624 minecraft:gray_concrete
fill 74 242 625 88 242 625 minecraft:magenta_concrete
fill 74 242 626 75 242 626 minecraft:black_concrete
fill 76 242 606 76 242 609 minecraft:magenta_concrete
fill 76 242 611 76 242 614 minecraft:magenta_concrete
fill 76 242 616 76 242 618 minecraft:magenta_concrete
fill 76 242 620 76 242 622 minecraft:sea_lantern
setblock 76 242 624 minecraft:magenta_concrete
setblock 76 242 626 minecraft:magenta_concrete
fill 76 242 628 76 242 630 minecraft:sea_lantern
fill 76 242 632 76 242 634 minecraft:magenta_concrete
fill 76 242 636 76 242 639 minecraft:magenta_concrete
fill 76 242 641 76 242 644 minecraft:magenta_concrete
fill 77 242 606 80 242 609 minecraft:gray_concrete
fill 77 242 611 80 242 614 minecraft:black_concrete
fill 77 242 616 80 242 619 minecraft:gray_concrete
fill 77 242 620 88 242 620 minecraft:magenta_concrete
fill 77 242 621 80 242 624 minecraft:black_concrete
fill 77 242 626 80 242 629 minecraft:gray_concrete
fill 77 242 630 88 242 630 minecraft:magenta_concrete
fill 77 242 631 80 242 634 minecraft:black_concrete
fill 77 242 636 80 242 639 minecraft:gray_concrete
fill 77 242 641 80 242 644 minecraft:black_concrete
fill 81 242 606 81 242 609 minecraft:magenta_concrete
fill 81 242 611 81 242 614 minecraft:magenta_concrete
fill 81 242 616 81 242 619 minecraft:magenta_concrete
fill 81 242 621 81 242 624 minecraft:magenta_concrete
fill 81 242 626 81 242 629 minecraft:magenta_concrete
fill 81 242 631 81 242 634 minecraft:magenta_concrete
fill 81 242 636 81 242 639 minecraft:magenta_concrete
fill 81 242 641 81 242 644 minecraft:magenta_concrete
fill 82 242 606 85 242 609 minecraft:black_concrete
fill 82 242 611 85 242 614 minecraft:gray_concrete
fill 82 242 616 85 242 619 minecraft:black_concrete
fill 82 242 621 85 242 624 minecraft:gray_concrete
fill 82 242 626 85 242 629 minecraft:black_concrete
fill 82 242 631 85 242 634 minecraft:gray_concrete
fill 82 242 636 85 242 639 minecraft:black_concrete
fill 82 242 641 85 242 644 minecraft:gray_concrete
fill 86 242 606 86 242 609 minecraft:magenta_concrete
fill 86 242 611 86 242 614 minecraft:magenta_concrete
fill 86 242 616 86 242 619 minecraft:magenta_concrete
fill 86 242 621 86 242 624 minecraft:magenta_concrete
fill 86 242 626 86 242 629 minecraft:magenta_concrete
fill 86 242 631 86 242 634 minecraft:magenta_concrete
fill 86 242 636 86 242 639 minecraft:magenta_concrete
fill 86 242 641 86 242 644 minecraft:magenta_concrete
fill 87 242 606 88 242 609 minecraft:gray_concrete
fill 87 242 611 88 242 614 minecraft:black_concrete
fill 87 242 616 88 242 619 minecraft:gray_concrete
fill 87 242 621 88 242 624 minecraft:black_concrete
fill 87 242 626 88 242 629 minecraft:gray_concrete
fill 87 242 631 88 242 634 minecraft:black_concrete
fill 87 242 636 88 242 639 minecraft:gray_concrete
fill 87 242 641 88 242 644 minecraft:black_concrete
setblock 50 243 607 minecraft:light[level=14]
setblock 50 243 615 minecraft:light[level=14]
setblock 50 243 623 minecraft:light[level=14]
setblock 50 243 631 minecraft:light[level=14]
setblock 50 243 639 minecraft:light[level=14]
setblock 58 243 607 minecraft:light[level=14]
setblock 58 243 615 minecraft:light[level=14]
setblock 58 243 623 minecraft:light[level=14]
setblock 58 243 631 minecraft:light[level=14]
setblock 58 243 639 minecraft:light[level=14]
setblock 66 243 607 minecraft:light[level=14]
setblock 66 243 615 minecraft:light[level=14]
setblock 66 243 623 minecraft:light[level=14]
setblock 66 243 631 minecraft:light[level=14]
setblock 66 243 639 minecraft:light[level=14]
setblock 74 243 607 minecraft:light[level=14]
setblock 74 243 615 minecraft:light[level=14]
setblock 74 243 623 minecraft:light[level=14]
setblock 74 243 631 minecraft:light[level=14]
setblock 74 243 639 minecraft:light[level=14]
setblock 82 243 607 minecraft:light[level=14]
setblock 82 243 615 minecraft:light[level=14]
setblock 82 243 623 minecraft:light[level=14]
setblock 82 243 631 minecraft:light[level=14]
setblock 82 243 639 minecraft:light[level=14]
fill 47 246 609 47 247 609 minecraft:sea_lantern
fill 47 246 617 47 247 617 minecraft:sea_lantern
fill 47 246 625 47 247 625 minecraft:sea_lantern
fill 47 246 633 47 247 633 minecraft:sea_lantern
fill 47 246 641 47 247 641 minecraft:sea_lantern
fill 48 246 611 48 273 612 minecraft:light_gray_concrete
fill 48 246 619 48 252 620 minecraft:light_gray_concrete
fill 48 246 627 48 246 639 minecraft:light_gray_concrete
fill 48 246 643 48 273 644 minecraft:light_gray_concrete
fill 49 246 605 50 273 605 minecraft:light_gray_concrete
fill 49 246 629 55 246 639 minecraft:light_gray_concrete
fill 50 246 646 50 247 646 minecraft:sea_lantern
fill 52 246 619 52 251 619 minecraft:magenta_concrete
fill 54 246 604 54 247 604 minecraft:sea_lantern
fill 54 246 645 55 273 645 minecraft:light_gray_concrete
fill 56 246 634 58 246 634 minecraft:magenta_concrete
fill 57 246 605 58 273 605 minecraft:light_gray_concrete
fill 57 246 635 58 246 635 minecraft:magenta_concrete
fill 58 246 646 58 247 646 minecraft:sea_lantern
fill 62 246 604 62 247 604 minecraft:sea_lantern
fill 62 246 645 63 273 645 minecraft:light_gray_concrete
fill 65 246 605 66 273 605 minecraft:light_gray_concrete
fill 66 246 646 66 247 646 minecraft:sea_lantern
fill 70 246 604 70 247 604 minecraft:sea_lantern
fill 70 246 645 71 273 645 minecraft:light_gray_concrete
fill 73 246 605 74 273 605 minecraft:light_gray_concrete
fill 74 246 646 74 247 646 minecraft:sea_lantern
fill 78 246 604 78 247 604 minecraft:sea_lantern
fill 78 246 605 86 246 613 minecraft:light_gray_concrete
fill 78 246 645 79 273 645 minecraft:light_gray_concrete
fill 82 246 646 82 247 646 minecraft:sea_lantern
fill 86 246 604 86 247 604 minecraft:sea_lantern
fill 86 246 645 87 273 645 minecraft:light_gray_concrete
fill 88 246 606 88 273 607 minecraft:light_gray_concrete
fill 88 246 614 88 273 615 minecraft:light_gray_concrete
fill 88 246 622 88 273 623 minecraft:light_gray_concrete
fill 88 246 630 88 273 631 minecraft:light_gray_concrete
fill 88 246 638 88 273 639 minecraft:light_gray_concrete
fill 89 246 609 89 247 609 minecraft:sea_lantern
fill 89 246 617 89 247 617 minecraft:sea_lantern
fill 89 246 625 89 247 625 minecraft:sea_lantern
fill 89 246 633 89 247 633 minecraft:sea_lantern
fill 89 246 641 89 247 641 minecraft:sea_lantern
fill 48 247 627 48 273 628 minecraft:light_gray_concrete
setblock 48 247 629 minecraft:sea_lantern
fill 48 247 630 48 257 630 minecraft:light_gray_concrete
setblock 48 247 631 minecraft:sea_lantern
fill 48 247 632 48 257 632 minecraft:light_gray_concrete
setblock 48 247 633 minecraft:sea_lantern
fill 48 247 634 48 257 634 minecraft:light_gray_concrete
setblock 48 247 635 minecraft:sea_lantern
fill 48 247 636 48 273 636 minecraft:light_gray_concrete
setblock 48 247 637 minecraft:sea_lantern
fill 48 247 638 48 257 638 minecraft:light_gray_concrete
setblock 48 247 639 minecraft:sea_lantern
fill 49 247 629 49 257 629 minecraft:light_gray_concrete
setblock 49 247 630 minecraft:sea_lantern
fill 49 247 631 49 257 631 minecraft:light_gray_concrete
setblock 49 247 632 minecraft:sea_lantern
fill 49 247 633 49 257 633 minecraft:light_gray_concrete
setblock 49 247 634 minecraft:sea_lantern
fill 49 247 635 49 257 635 minecraft:light_gray_concrete
setblock 49 247 636 minecraft:sea_lantern
fill 49 247 637 49 257 637 minecraft:light_gray_concrete
setblock 49 247 638 minecraft:sea_lantern
fill 49 247 639 49 257 639 minecraft:light_gray_concrete
setblock 50 247 629 minecraft:sea_lantern
fill 50 247 630 50 257 630 minecraft:light_gray_concrete
setblock 50 247 631 minecraft:sea_lantern
fill 50 247 632 50 257 632 minecraft:light_gray_concrete
setblock 50 247 633 minecraft:sea_lantern
fill 50 247 634 50 257 634 minecraft:light_gray_concrete
setblock 50 247 635 minecraft:sea_lantern
fill 50 247 636 50 257 636 minecraft:light_gray_concrete
setblock 50 247 637 minecraft:sea_lantern
fill 50 247 638 50 257 638 minecraft:light_gray_concrete
setblock 50 247 639 minecraft:sea_lantern
fill 51 247 629 51 257 629 minecraft:light_gray_concrete
setblock 51 247 630 minecraft:sea_lantern
fill 51 247 631 51 257 631 minecraft:light_gray_concrete
setblock 51 247 632 minecraft:sea_lantern
fill 51 247 633 51 257 633 minecraft:light_gray_concrete
setblock 51 247 634 minecraft:sea_lantern
fill 51 247 635 51 257 635 minecraft:light_gray_concrete
setblock 51 247 636 minecraft:sea_lantern
fill 51 247 637 51 257 637 minecraft:light_gray_concrete
setblock 51 247 638 minecraft:sea_lantern
fill 51 247 639 51 257 639 minecraft:light_gray_concrete
fill 52 247 618 52 251 618 minecraft:magenta_concrete
fill 52 247 620 52 251 620 minecraft:magenta_concrete
setblock 52 247 629 minecraft:sea_lantern
fill 52 247 630 52 257 630 minecraft:light_gray_concrete
setblock 52 247 631 minecraft:sea_lantern
fill 52 247 632 52 257 632 minecraft:light_gray_concrete
setblock 52 247 633 minecraft:sea_lantern
fill 52 247 634 52 257 634 minecraft:light_gray_concrete
setblock 52 247 635 minecraft:sea_lantern
fill 52 247 636 52 257 636 minecraft:light_gray_concrete
setblock 52 247 637 minecraft:sea_lantern
fill 52 247 638 52 257 638 minecraft:light_gray_concrete
setblock 52 247 639 minecraft:sea_lantern
fill 53 247 619 53 251 619 minecraft:magenta_concrete
fill 53 247 629 53 257 629 minecraft:light_gray_concrete
setblock 53 247 630 minecraft:sea_lantern
fill 53 247 631 53 257 631 minecraft:light_gray_concrete
setblock 53 247 632 minecraft:sea_lantern
fill 53 247 633 53 257 633 minecraft:light_gray_concrete
setblock 53 247 634 minecraft:sea_lantern
fill 53 247 635 53 257 635 minecraft:light_gray_concrete
setblock 53 247 636 minecraft:sea_lantern
fill 53 247 637 53 257 637 minecraft:light_gray_concrete
setblock 53 247 638 minecraft:sea_lantern
fill 53 247 639 53 257 639 minecraft:light_gray_concrete
setblock 54 247 629 minecraft:sea_lantern
fill 54 247 630 54 257 630 minecraft:light_gray_concrete
setblock 54 247 631 minecraft:sea_lantern
fill 54 247 632 54 257 632 minecraft:light_gray_concrete
setblock 54 247 633 minecraft:sea_lantern
fill 54 247 634 54 257 634 minecraft:light_gray_concrete
setblock 54 247 635 minecraft:sea_lantern
fill 54 247 636 54 257 636 minecraft:light_gray_concrete
setblock 54 247 637 minecraft:sea_lantern
fill 54 247 638 54 257 638 minecraft:light_gray_concrete
setblock 54 247 639 minecraft:sea_lantern
fill 55 247 629 55 257 629 minecraft:light_gray_concrete
setblock 55 247 630 minecraft:sea_lantern
fill 55 247 631 55 257 631 minecraft:light_gray_concrete
setblock 55 247 632 minecraft:sea_lantern
fill 55 247 633 55 257 633 minecraft:light_gray_concrete
setblock 55 247 634 minecraft:sea_lantern
fill 55 247 635 55 257 635 minecraft:light_gray_concrete
setblock 55 247 636 minecraft:sea_lantern
fill 55 247 637 55 257 637 minecraft:light_gray_concrete
setblock 55 247 638 minecraft:sea_lantern
fill 55 247 639 55 257 639 minecraft:light_gray_concrete
setblock 78 247 605 minecraft:sea_lantern
fill 78 247 606 78 266 606 minecraft:light_gray_concrete
setblock 78 247 607 minecraft:sea_lantern
fill 78 247 608 78 266 608 minecraft:light_gray_concrete
setblock 78 247 609 minecraft:sea_lantern
fill 78 247 610 78 266 610 minecraft:light_gray_concrete
setblock 78 247 611 minecraft:sea_lantern
fill 78 247 612 78 266 612 minecraft:light_gray_concrete
setblock 78 247 613 minecraft:sea_lantern
fill 79 247 605 79 267 605 minecraft:light_gray_concrete
setblock 79 247 606 minecraft:sea_lantern
fill 79 247 607 79 266 607 minecraft:light_gray_concrete
setblock 79 247 608 minecraft:sea_lantern
fill 79 247 609 79 266 609 minecraft:light_gray_concrete
setblock 79 247 610 minecraft:sea_lantern
fill 79 247 611 79 266 611 minecraft:light_gray_concrete
setblock 79 247 612 minecraft:sea_lantern
fill 79 247 613 79 266 613 minecraft:light_gray_concrete
setblock 80 247 605 minecraft:sea_lantern
fill 80 247 606 80 266 606 minecraft:light_gray_concrete
setblock 80 247 607 minecraft:sea_lantern
fill 80 247 608 80 266 608 minecraft:light_gray_concrete
setblock 80 247 609 minecraft:sea_lantern
fill 80 247 610 80 266 610 minecraft:light_gray_concrete
setblock 80 247 611 minecraft:sea_lantern
fill 80 247 612 80 266 612 minecraft:light_gray_concrete
setblock 80 247 613 minecraft:sea_lantern
fill 81 247 605 81 273 605 minecraft:light_gray_concrete
setblock 81 247 606 minecraft:sea_lantern
fill 81 247 607 81 266 607 minecraft:light_gray_concrete
setblock 81 247 608 minecraft:sea_lantern
fill 81 247 609 81 266 609 minecraft:light_gray_concrete
setblock 81 247 610 minecraft:sea_lantern
fill 81 247 611 81 266 611 minecraft:light_gray_concrete
setblock 81 247 612 minecraft:sea_lantern
fill 81 247 613 81 266 613 minecraft:light_gray_concrete
setblock 82 247 605 minecraft:sea_lantern
fill 82 247 606 82 266 606 minecraft:light_gray_concrete
setblock 82 247 607 minecraft:sea_lantern
fill 82 247 608 82 266 608 minecraft:light_gray_concrete
setblock 82 247 609 minecraft:sea_lantern
fill 82 247 610 82 266 610 minecraft:light_gray_concrete
setblock 82 247 611 minecraft:sea_lantern
fill 82 247 612 82 266 612 minecraft:light_gray_concrete
setblock 82 247 613 minecraft:sea_lantern
fill 83 247 605 83 267 605 minecraft:light_gray_concrete
setblock 83 247 606 minecraft:sea_lantern
fill 83 247 607 83 266 607 minecraft:light_gray_concrete
setblock 83 247 608 minecraft:sea_lantern
fill 83 247 609 83 266 609 minecraft:light_gray_concrete
setblock 83 247 610 minecraft:sea_lantern
fill 83 247 611 83 266 611 minecraft:light_gray_concrete
setblock 83 247 612 minecraft:sea_lantern
fill 83 247 613 83 266 613 minecraft:light_gray_concrete
setblock 84 247 605 minecraft:sea_lantern
fill 84 247 606 84 266 606 minecraft:light_gray_concrete
setblock 84 247 607 minecraft:sea_lantern
fill 84 247 608 84 266 608 minecraft:light_gray_concrete
setblock 84 247 609 minecraft:sea_lantern
fill 84 247 610 84 266 610 minecraft:light_gray_concrete
setblock 84 247 611 minecraft:sea_lantern
fill 84 247 612 84 266 612 minecraft:light_gray_concrete
setblock 84 247 613 minecraft:sea_lantern
fill 85 247 605 85 267 605 minecraft:light_gray_concrete
setblock 85 247 606 minecraft:sea_lantern
fill 85 247 607 85 266 607 minecraft:light_gray_concrete
setblock 85 247 608 minecraft:sea_lantern
fill 85 247 609 85 266 609 minecraft:light_gray_concrete
setblock 85 247 610 minecraft:sea_lantern
fill 85 247 611 85 266 611 minecraft:light_gray_concrete
setblock 85 247 612 minecraft:sea_lantern
fill 85 247 613 85 266 613 minecraft:light_gray_concrete
setblock 86 247 605 minecraft:sea_lantern
fill 86 247 606 86 266 606 minecraft:light_gray_concrete
setblock 86 247 607 minecraft:sea_lantern
fill 86 247 608 86 266 608 minecraft:light_gray_concrete
setblock 86 247 609 minecraft:sea_lantern
fill 86 247 610 86 266 610 minecraft:light_gray_concrete
setblock 86 247 611 minecraft:sea_lantern
fill 86 247 612 86 266 612 minecraft:light_gray_concrete
setblock 86 247 613 minecraft:sea_lantern
fill 47 248 609 47 255 609 minecraft:gray_concrete
fill 47 248 617 47 255 617 minecraft:gray_concrete
fill 47 248 625 47 255 625 minecraft:gray_concrete
fill 47 248 633 47 255 633 minecraft:gray_concrete
fill 47 248 641 47 255 641 minecraft:gray_concrete
fill 48 248 629 48 249 629 minecraft:light_gray_concrete
fill 48 248 631 48 249 631 minecraft:light_gray_concrete
fill 48 248 633 48 249 633 minecraft:light_gray_concrete
fill 48 248 635 48 249 635 minecraft:light_gray_concrete
fill 48 248 637 48 249 637 minecraft:light_gray_concrete
fill 48 248 639 48 249 639 minecraft:light_gray_concrete
fill 49 248 630 49 249 630 minecraft:light_gray_concrete
fill 49 248 632 49 249 632 minecraft:light_gray_concrete
fill 49 248 634 49 249 634 minecraft:light_gray_concrete
fill 49 248 636 49 249 636 minecraft:light_gray_concrete
fill 49 248 638 49 249 638 minecraft:light_gray_concrete
fill 50 248 629 50 249 629 minecraft:light_gray_concrete
fill 50 248 631 50 249 631 minecraft:light_gray_concrete
fill 50 248 633 50 249 633 minecraft:light_gray_concrete
fill 50 248 635 50 249 635 minecraft:light_gray_concrete
fill 50 248 637 50 249 637 minecraft:light_gray_concrete
fill 50 248 639 50 249 639 minecraft:light_gray_concrete
fill 50 248 646 50 255 646 minecraft:gray_concrete
fill 51 248 618 51 251 620 minecraft:magenta_concrete
fill 51 248 630 51 249 630 minecraft:light_gray_concrete
fill 51 248 632 51 249 632 minecraft:light_gray_concrete
fill 51 248 634 51 249 634 minecraft:light_gray_concrete
fill 51 248 636 51 249 636 minecraft:light_gray_concrete
fill 51 248 638 51 249 638 minecraft:light_gray_concrete
fill 52 248 629 52 249 629 minecraft:light_gray_concrete
fill 52 248 631 52 249 631 minecraft:light_gray_concrete
fill 52 248 633 52 249 633 minecraft:light_gray_concrete
fill 52 248 635 52 249 635 minecraft:light_gray_concrete
fill 52 248 637 52 249 637 minecraft:light_gray_concrete
fill 52 248 639 52 249 639 minecraft:light_gray_concrete
fill 53 248 618 53 251 618 minecraft:magenta_concrete
fill 53 248 620 53 251 620 minecraft:magenta_concrete
fill 53 248 630 53 249 630 minecraft:light_gray_concrete
fill 53 248 632 53 249 632 minecraft:light_gray_concrete
fill 53 248 634 53 249 634 minecraft:light_gray_concrete
fill 53 248 636 53 249 636 minecraft:light_gray_concrete
fill 53 248 638 53 249 638 minecraft:light_gray_concrete
fill 54 248 604 54 255 604 minecraft:gray_concrete
fill 54 248 619 54 251 619 minecraft:magenta_concrete
fill 54 248 629 54 249 629 minecraft:light_gray_concrete
fill 54 248 631 54 249 631 minecraft:light_gray_concrete
fill 54 248 633 54 249 633 minecraft:light_gray_concrete
fill 54 248 635 54 249 635 minecraft:light_gray_concrete
fill 54 248 637 54 249 637 minecraft:light_gray_concrete
fill 54 248 639 54 249 639 minecraft:light_gray_concrete
fill 55 248 630 55 249 630 minecraft:light_gray_concrete
fill 55 248 632 55 249 632 minecraft:light_gray_concrete
fill 55 248 634 55 249 634 minecraft:light_gray_concrete
fill 55 248 636 55 249 636 minecraft:light_gray_concrete
fill 55 248 638 55 249 638 minecraft:light_gray_concrete
fill 58 248 646 58 255 646 minecraft:gray_concrete
fill 62 248 604 62 255 604 minecraft:gray_concrete
fill 66 248 646 66 255 646 minecraft:gray_concrete
fill 70 248 604 70 255 604 minecraft:gray_concrete
fill 74 248 646 74 255 646 minecraft:gray_concrete
fill 78 248 604 78 255 604 minecraft:gray_concrete
fill 78 248 605 78 249 605 minecraft:light_gray_concrete
fill 78 248 607 78 249 607 minecraft:light_gray_concrete
fill 78 248 609 78 249 609 minecraft:light_gray_concrete
fill 78 248 611 78 249 611 minecraft:light_gray_concrete
fill 78 248 613 78 249 613 minecraft:light_gray_concrete
fill 79 248 606 79 249 606 minecraft:light_gray_concrete
fill 79 248 608 79 249 608 minecraft:light_gray_concrete
fill 79 248 610 79 249 610 minecraft:light_gray_concrete
fill 79 248 612 79 249 612 minecraft:light_gray_concrete
fill 80 248 605 80 249 605 minecraft:light_gray_concrete
fill 80 248 607 80 249 607 minecraft:light_gray_concrete
fill 80 248 609 80 249 609 minecraft:light_gray_concrete
fill 80 248 611 80 249 611 minecraft:light_gray_concrete
fill 80 248 613 80 249 613 minecraft:light_gray_concrete
fill 81 248 606 81 249 606 minecraft:light_gray_concrete
fill 81 248 608 81 249 608 minecraft:light_gray_concrete
fill 81 248 610 81 249 610 minecraft:light_gray_concrete
fill 81 248 612 81 249 612 minecraft:light_gray_concrete
fill 82 248 605 82 249 605 minecraft:light_gray_concrete
fill 82 248 607 82 249 607 minecraft:light_gray_concrete
fill 82 248 609 82 249 609 minecraft:light_gray_concrete
fill 82 248 611 82 249 611 minecraft:light_gray_concrete
fill 82 248 613 82 249 613 minecraft:light_gray_concrete
fill 82 248 646 82 255 646 minecraft:gray_concrete
fill 83 248 606 83 249 606 minecraft:light_gray_concrete
fill 83 248 608 83 249 608 minecraft:light_gray_concrete
fill 83 248 610 83 249 610 minecraft:light_gray_concrete
fill 83 248 612 83 249 612 minecraft:light_gray_concrete
fill 84 248 605 84 249 605 minecraft:light_gray_concrete
fill 84 248 607 84 249 607 minecraft:light_gray_concrete
fill 84 248 609 84 249 609 minecraft:light_gray_concrete
fill 84 248 611 84 249 611 minecraft:light_gray_concrete
fill 84 248 613 84 249 613 minecraft:light_gray_concrete
fill 85 248 606 85 249 606 minecraft:light_gray_concrete
fill 85 248 608 85 249 608 minecraft:light_gray_concrete
fill 85 248 610 85 249 610 minecraft:light_gray_concrete
fill 85 248 612 85 249 612 minecraft:light_gray_concrete
fill 86 248 604 86 255 604 minecraft:gray_concrete
fill 86 248 605 86 249 605 minecraft:light_gray_concrete
fill 86 248 607 86 249 607 minecraft:light_gray_concrete
fill 86 248 609 86 249 609 minecraft:light_gray_concrete
fill 86 248 611 86 249 611 minecraft:light_gray_concrete
fill 86 248 613 86 249 613 minecraft:light_gray_concrete
fill 89 248 609 89 255 609 minecraft:gray_concrete
fill 89 248 617 89 255 617 minecraft:gray_concrete
fill 89 248 625 89 255 625 minecraft:gray_concrete
fill 89 248 633 89 255 633 minecraft:gray_concrete
fill 89 248 641 89 255 641 minecraft:gray_concrete
fill 50 249 618 50 251 620 minecraft:magenta_concrete
fill 51 249 617 53 251 617 minecraft:magenta_concrete
fill 51 249 621 53 251 621 minecraft:magenta_concrete
fill 54 249 618 54 251 618 minecraft:magenta_concrete
fill 54 249 620 54 251 620 minecraft:magenta_concrete
setblock 48 250 629 minecraft:sea_lantern
setblock 48 250 631 minecraft:sea_lantern
setblock 48 250 633 minecraft:sea_lantern
setblock 48 250 635 minecraft:sea_lantern
setblock 48 250 637 minecraft:sea_lantern
setblock 48 250 639 minecraft:sea_lantern
fill 49 250 619 49 251 619 minecraft:magenta_concrete
setblock 49 250 630 minecraft:sea_lantern
setblock 49 250 632 minecraft:sea_lantern
setblock 49 250 634 minecraft:sea_lantern
setblock 49 250 636 minecraft:sea_lantern
setblock 49 250 638 minecraft:sea_lantern
fill 50 250 617 50 251 617 minecraft:magenta_concrete
fill 50 250 621 50 251 621 minecraft:magenta_concrete
setblock 50 250 629 minecraft:sea_lantern
setblock 50 250 631 minecraft:sea_lantern
setblock 50 250 633 minecraft:sea_lantern
setblock 50 250 635 minecraft:sea_lantern
setblock 50 250 637 minecraft:sea_lantern
setblock 50 250 639 minecraft:sea_lantern
fill 51 250 616 53 251 616 minecraft:magenta_concrete
fill 51 250 622 53 251 622 minecraft:magenta_concrete
setblock 51 250 630 minecraft:sea_lantern
setblock 51 250 632 minecraft:sea_lantern
setblock 51 250 634 minecraft:sea_lantern
setblock 51 250 636 minecraft:sea_lantern
setblock 51 250 638 minecraft:sea_lantern
setblock 52 250 629 minecraft:sea_lantern
setblock 52 250 631 minecraft:sea_lantern
setblock 52 250 633 minecraft:sea_lantern
setblock 52 250 635 minecraft:sea_lantern
setblock 52 250 637 minecraft:sea_lantern
setblock 52 250 639 minecraft:sea_lantern
setblock 53 250 630 minecraft:sea_lantern
setblock 53 250 632 minecraft:sea_lantern
setblock 53 250 634 minecraft:sea_lantern
setblock 53 250 636 minecraft:sea_lantern
setblock 53 250 638 minecraft:sea_lantern
fill 54 250 617 54 251 617 minecraft:magenta_concrete
fill 54 250 621 54 251 621 minecraft:magenta_concrete
setblock 54 250 629 minecraft:sea_lantern
setblock 54 250 631 minecraft:sea_lantern
setblock 54 250 633 minecraft:sea_lantern
setblock 54 250 635 minecraft:sea_lantern
setblock 54 250 637 minecraft:sea_lantern
setblock 54 250 639 minecraft:sea_lantern
fill 55 250 618 55 251 620 minecraft:magenta_concrete
setblock 55 250 630 minecraft:sea_lantern
setblock 55 250 632 minecraft:sea_lantern
setblock 55 250 634 minecraft:sea_lantern
setblock 55 250 636 minecraft:sea_lantern
setblock 55 250 638 minecraft:sea_lantern
setblock 78 250 605 minecraft:sea_lantern
setblock 78 250 607 minecraft:sea_lantern
setblock 78 250 609 minecraft:sea_lantern
setblock 78 250 611 minecraft:sea_lantern
setblock 78 250 613 minecraft:sea_lantern
setblock 79 250 606 minecraft:sea_lantern
setblock 79 250 608 minecraft:sea_lantern
setblock 79 250 610 minecraft:sea_lantern
setblock 79 250 612 minecraft:sea_lantern
setblock 80 250 605 minecraft:sea_lantern
setblock 80 250 607 minecraft:sea_lantern
setblock 80 250 609 minecraft:sea_lantern
setblock 80 250 611 minecraft:sea_lantern
setblock 80 250 613 minecraft:sea_lantern
setblock 81 250 606 minecraft:sea_lantern
setblock 81 250 608 minecraft:sea_lantern
setblock 81 250 610 minecraft:sea_lantern
setblock 81 250 612 minecraft:sea_lantern
setblock 82 250 605 minecraft:sea_lantern
setblock 82 250 607 minecraft:sea_lantern
setblock 82 250 609 minecraft:sea_lantern
setblock 82 250 611 minecraft:sea_lantern
setblock 82 250 613 minecraft:sea_lantern
setblock 83 250 606 minecraft:sea_lantern
setblock 83 250 608 minecraft:sea_lantern
setblock 83 250 610 minecraft:sea_lantern
setblock 83 250 612 minecraft:sea_lantern
setblock 84 250 605 minecraft:sea_lantern
setblock 84 250 607 minecraft:sea_lantern
setblock 84 250 609 minecraft:sea_lantern
setblock 84 250 611 minecraft:sea_lantern
setblock 84 250 613 minecraft:sea_lantern
setblock 85 250 606 minecraft:sea_lantern
setblock 85 250 608 minecraft:sea_lantern
setblock 85 250 610 minecraft:sea_lantern
setblock 85 250 612 minecraft:sea_lantern
setblock 86 250 605 minecraft:sea_lantern
setblock 86 250 607 minecraft:sea_lantern
setblock 86 250 609 minecraft:sea_lantern
setblock 86 250 611 minecraft:sea_lantern
setblock 86 250 613 minecraft:sea_lantern
fill 48 251 629 48 252 629 minecraft:light_gray_concrete
fill 48 251 631 48 252 631 minecraft:light_gray_concrete
fill 48 251 633 48 252 633 minecraft:light_gray_concrete
fill 48 251 635 48 252 635 minecraft:light_gray_concrete
fill 48 251 637 48 252 637 minecraft:light_gray_concrete
fill 48 251 639 48 252 639 minecraft:light_gray_concrete
fill 49 251 617 49 251 618 minecraft:magenta_concrete
fill 49 251 620 49 251 621 minecraft:magenta_concrete
fill 49 251 630 49 252 630 minecraft:light_gray_concrete
fill 49 251 632 49 252 632 minecraft:light_gray_concrete
fill 49 251 634 49 252 634 minecraft:light_gray_concrete
fill 49 251 636 49 252 636 minecraft:light_gray_concrete
fill 49 251 638 49 252 638 minecraft:light_gray_concrete
setblock 50 251 607 minecraft:light[level=14]
setblock 50 251 615 minecraft:light[level=14]
setblock 50 251 616 minecraft:magenta_concrete
setblock 50 251 622 minecraft:magenta_concrete
setblock 50 251 623 minecraft:light[level=14]
fill 50 251 629 50 252 629 minecraft:light_gray_concrete
fill 50 251 631 50 252 631 minecraft:light_gray_concrete
fill 50 251 633 50 252 633 minecraft:light_gray_concrete
fill 50 251 635 50 252 635 minecraft:light_gray_concrete
fill 50 251 637 50 252 637 minecraft:light_gray_concrete
fill 50 251 639 50 252 639 minecraft:light_gray_concrete
fill 51 251 630 51 252 630 minecraft:light_gray_concrete
fill 51 251 632 51 252 632 minecraft:light_gray_concrete
fill 51 251 634 51 252 634 minecraft:light_gray_concrete
fill 51 251 636 51 252 636 minecraft:light_gray_concrete
fill 51 251 638 51 252 638 minecraft:light_gray_concrete
setblock 52 251 615 minecraft:magenta_concrete
setblock 52 251 623 minecraft:magenta_concrete
fill 52 251 629 52 252 629 minecraft:light_gray_concrete
fill 52 251 631 52 252 631 minecraft:light_gray_concrete
fill 52 251 633 52 252 633 minecraft:light_gray_concrete
fill 52 251 635 52 252 635 minecraft:light_gray_concrete
fill 52 251 637 52 252 637 minecraft:light_gray_concrete
fill 52 251 639 52 252 639 minecraft:light_gray_concrete
fill 53 251 630 53 252 630 minecraft:light_gray_concrete
fill 53 251 632 53 252 632 minecraft:light_gray_concrete
fill 53 251 634 53 252 634 minecraft:light_gray_concrete
fill 53 251 636 53 252 636 minecraft:light_gray_concrete
fill 53 251 638 53 252 638 minecraft:light_gray_concrete
setblock 54 251 616 minecraft:magenta_concrete
setblock 54 251 622 minecraft:magenta_concrete
fill 54 251 629 54 252 629 minecraft:light_gray_concrete
fill 54 251 631 54 252 631 minecraft:light_gray_concrete
fill 54 251 633 54 252 633 minecraft:light_gray_concrete
fill 54 251 635 54 252 635 minecraft:light_gray_concrete
fill 54 251 637 54 252 637 minecraft:light_gray_concrete
fill 54 251 639 54 252 639 minecraft:light_gray_concrete
setblock 55 251 617 minecraft:magenta_concrete
setblock 55 251 621 minecraft:magenta_concrete
fill 55 251 630 55 252 630 minecraft:light_gray_concrete
fill 55 251 632 55 252 632 minecraft:light_gray_concrete
fill 55 251 634 55 252 634 minecraft:light_gray_concrete
fill 55 251 636 55 252 636 minecraft:light_gray_concrete
fill 55 251 638 55 252 638 minecraft:light_gray_concrete
fill 56 251 618 56 251 620 minecraft:magenta_concrete
setblock 58 251 607 minecraft:light[level=14]
setblock 58 251 615 minecraft:light[level=14]
setblock 58 251 623 minecraft:light[level=14]
setblock 58 251 631 minecraft:light[level=14]
setblock 58 251 639 minecraft:light[level=14]
setblock 66 251 607 minecraft:light[level=14]
setblock 66 251 615 minecraft:light[level=14]
setblock 66 251 623 minecraft:light[level=14]
setblock 66 251 631 minecraft:light[level=14]
setblock 66 251 639 minecraft:light[level=14]
setblock 74 251 607 minecraft:light[level=14]
setblock 74 251 615 minecraft:light[level=14]
setblock 74 251 623 minecraft:light[level=14]
setblock 74 251 631 minecraft:light[level=14]
setblock 74 251 639 minecraft:light[level=14]
fill 78 251 605 78 252 605 minecraft:light_gray_concrete
fill 78 251 607 78 252 607 minecraft:light_gray_concrete
fill 78 251 609 78 252 609 minecraft:light_gray_concrete
fill 78 251 611 78 252 611 minecraft:light_gray_concrete
fill 78 251 613 78 252 613 minecraft:light_gray_concrete
fill 79 251 606 79 252 606 minecraft:light_gray_concrete
fill 79 251 608 79 252 608 minecraft:light_gray_concrete
fill 79 251 610 79 252 610 minecraft:light_gray_concrete
fill 79 251 612 79 252 612 minecraft:light_gray_concrete
fill 80 251 605 80 252 605 minecraft:light_gray_concrete
fill 80 251 607 80 252 607 minecraft:light_gray_concrete
fill 80 251 609 80 252 609 minecraft:light_gray_concrete
fill 80 251 611 80 252 611 minecraft:light_gray_concrete
fill 80 251 613 80 252 613 minecraft:light_gray_concrete
fill 81 251 606 81 252 606 minecraft:light_gray_concrete
fill 81 251 608 81 252 608 minecraft:light_gray_concrete
fill 81 251 610 81 252 610 minecraft:light_gray_concrete
fill 81 251 612 81 252 612 minecraft:light_gray_concrete
fill 82 251 605 82 252 605 minecraft:light_gray_concrete
fill 82 251 607 82 252 607 minecraft:light_gray_concrete
fill 82 251 609 82 252 609 minecraft:light_gray_concrete
fill 82 251 611 82 252 611 minecraft:light_gray_concrete
fill 82 251 613 82 252 613 minecraft:light_gray_concrete
setblock 82 251 615 minecraft:light[level=14]
setblock 82 251 623 minecraft:light[level=14]
setblock 82 251 631 minecraft:light[level=14]
setblock 82 251 639 minecraft:light[level=14]
fill 83 251 606 83 252 606 minecraft:light_gray_concrete
fill 83 251 608 83 252 608 minecraft:light_gray_concrete
fill 83 251 610 83 252 610 minecraft:light_gray_concrete
fill 83 251 612 83 252 612 minecraft:light_gray_concrete
fill 84 251 605 84 252 605 minecraft:light_gray_concrete
fill 84 251 607 84 252 607 minecraft:light_gray_concrete
fill 84 251 609 84 252 609 minecraft:light_gray_concrete
fill 84 251 611 84 252 611 minecraft:light_gray_concrete
fill 84 251 613 84 252 613 minecraft:light_gray_concrete
fill 85 251 606 85 252 606 minecraft:light_gray_concrete
fill 85 251 608 85 252 608 minecraft:light_gray_concrete
fill 85 251 610 85 252 610 minecraft:light_gray_concrete
fill 85 251 612 85 252 612 minecraft:light_gray_concrete
fill 86 251 605 86 252 605 minecraft:light_gray_concrete
fill 86 251 607 86 252 607 minecraft:light_gray_concrete
fill 86 251 609 86 252 609 minecraft:light_gray_concrete
fill 86 251 611 86 252 611 minecraft:light_gray_concrete
fill 86 251 613 86 252 613 minecraft:light_gray_concrete
fill 48 252 605 48 253 610 minecraft:light_gray_concrete
fill 48 252 613 57 252 618 minecraft:light_gray_concrete
fill 48 252 621 49 252 626 minecraft:light_gray_concrete
fill 48 252 640 49 252 642 minecraft:light_gray_concrete
fill 48 252 645 53 253 645 minecraft:light_gray_concrete
fill 49 252 606 49 252 612 minecraft:light_gray_concrete
fill 49 252 619 57 252 620 minecraft:light_gray_concrete
fill 49 252 627 49 252 628 minecraft:light_gray_concrete
fill 49 252 643 49 252 644 minecraft:light_gray_concrete
fill 50 252 606 77 252 606 minecraft:light_gray_concrete
fill 50 252 621 57 252 625 minecraft:light_gray_concrete
fill 50 252 644 88 252 644 minecraft:light_gray_concrete
fill 51 252 605 56 253 605 minecraft:light_gray_concrete
fill 56 252 645 61 253 645 minecraft:light_gray_concrete
fill 59 252 605 64 253 605 minecraft:light_gray_concrete
fill 64 252 645 69 253 645 minecraft:light_gray_concrete
fill 67 252 605 72 253 605 minecraft:light_gray_concrete
fill 72 252 645 77 253 645 minecraft:light_gray_concrete
fill 75 252 605 77 253 605 minecraft:light_gray_concrete
fill 80 252 645 85 253 645 minecraft:light_gray_concrete
fill 87 252 605 87 252 643 minecraft:light_gray_concrete
fill 88 252 605 88 253 605 minecraft:light_gray_concrete
fill 88 252 608 88 253 613 minecraft:light_gray_concrete
fill 88 252 616 88 253 621 minecraft:light_gray_concrete
fill 88 252 624 88 253 629 minecraft:light_gray_concrete
fill 88 252 632 88 253 637 minecraft:light_gray_concrete
fill 88 252 640 88 253 643 minecraft:light_gray_concrete
fill 88 252 645 88 253 645 minecraft:light_gray_concrete
setblock 48 253 613 minecraft:sea_lantern
fill 48 253 614 48 273 614 minecraft:light_gray_concrete
setblock 48 253 615 minecraft:sea_lantern
fill 48 253 616 48 273 616 minecraft:light_gray_concrete
setblock 48 253 617 minecraft:sea_lantern
fill 48 253 618 48 273 618 minecraft:light_gray_concrete
setblock 48 253 619 minecraft:sea_lantern
fill 48 253 620 48 273 620 minecraft:light_gray_concrete
setblock 48 253 621 minecraft:sea_lantern
fill 48 253 622 48 273 622 minecraft:light_gray_concrete
setblock 48 253 623 minecraft:sea_lantern
fill 48 253 624 48 273 624 minecraft:light_gray_concrete
setblock 48 253 625 minecraft:sea_lantern
setblock 48 253 626 minecraft:light_gray_concrete
setblock 48 253 629 minecraft:sea_lantern
setblock 48 253 631 minecraft:sea_lantern
setblock 48 253 633 minecraft:sea_lantern
setblock 48 253 635 minecraft:sea_lantern
setblock 48 253 637 minecraft:sea_lantern
setblock 48 253 639 minecraft:sea_lantern
fill 48 253 640 48 253 642 minecraft:light_gray_concrete
fill 49 253 613 49 273 613 minecraft:light_gray_concrete
setblock 49 253 614 minecraft:sea_lantern
fill 49 253 615 49 273 615 minecraft:light_gray_concrete
setblock 49 253 616 minecraft:sea_lantern
fill 49 253 617 49 273 617 minecraft:light_gray_concrete
setblock 49 253 618 minecraft:sea_lantern
fill 49 253 619 49 273 619 minecraft:light_gray_concrete
setblock 49 253 620 minecraft:sea_lantern
fill 49 253 621 49 273 621 minecraft:light_gray_concrete
setblock 49 253 622 minecraft:sea_lantern
fill 49 253 623 49 273 623 minecraft:light_gray_concrete
setblock 49 253 624 minecraft:sea_lantern
fill 49 253 625 49 273 625 minecraft:light_gray_concrete
setblock 49 253 630 minecraft:sea_lantern
setblock 49 253 632 minecraft:sea_lantern
setblock 49 253 634 minecraft:sea_lantern
setblock 49 253 636 minecraft:sea_lantern
setblock 49 253 638 minecraft:sea_lantern
setblock 50 253 613 minecraft:sea_lantern
fill 50 253 614 50 273 614 minecraft:light_gray_concrete
setblock 50 253 615 minecraft:sea_lantern
fill 50 253 616 50 273 616 minecraft:light_gray_concrete
setblock 50 253 617 minecraft:sea_lantern
fill 50 253 618 50 273 618 minecraft:light_gray_concrete
setblock 50 253 619 minecraft:sea_lantern
fill 50 253 620 50 273 620 minecraft:light_gray_concrete
setblock 50 253 621 minecraft:sea_lantern
fill 50 253 622 50 273 622 minecraft:light_gray_concrete
setblock 50 253 623 minecraft:sea_lantern
fill 50 253 624 50 273 624 minecraft:light_gray_concrete
setblock 50 253 625 minecraft:sea_lantern
setblock 50 253 629 minecraft:sea_lantern
setblock 50 253 631 minecraft:sea_lantern
setblock 50 253 633 minecraft:sea_lantern
setblock 50 253 635 minecraft:sea_lantern
setblock 50 253 637 minecraft:sea_lantern
setblock 50 253 639 minecraft:sea_lantern
fill 51 253 613 51 273 613 minecraft:light_gray_concrete
setblock 51 253 614 minecraft:sea_lantern
fill 51 253 615 51 273 615 minecraft:light_gray_concrete
setblock 51 253 616 minecraft:sea_lantern
fill 51 253 617 51 273 617 minecraft:light_gray_concrete
setblock 51 253 618 minecraft:sea_lantern
fill 51 253 619 51 273 619 minecraft:light_gray_concrete
setblock 51 253 620 minecraft:sea_lantern
fill 51 253 621 51 273 621 minecraft:light_gray_concrete
setblock 51 253 622 minecraft:sea_lantern
fill 51 253 623 51 273 623 minecraft:light_gray_concrete
setblock 51 253 624 minecraft:sea_lantern
fill 51 253 625 51 273 625 minecraft:light_gray_concrete
setblock 51 253 630 minecraft:sea_lantern
setblock 51 253 632 minecraft:sea_lantern
setblock 51 253 634 minecraft:sea_lantern
setblock 51 253 636 minecraft:sea_lantern
setblock 51 253 638 minecraft:sea_lantern
setblock 52 253 613 minecraft:sea_lantern
fill 52 253 614 52 273 614 minecraft:light_gray_concrete
setblock 52 253 615 minecraft:sea_lantern
fill 52 253 616 52 273 616 minecraft:light_gray_concrete
setblock 52 253 617 minecraft:sea_lantern
fill 52 253 618 52 273 618 minecraft:light_gray_concrete
setblock 52 253 619 minecraft:sea_lantern
fill 52 253 620 52 273 620 minecraft:light_gray_concrete
setblock 52 253 621 minecraft:sea_lantern
fill 52 253 622 52 273 622 minecraft:light_gray_concrete
setblock 52 253 623 minecraft:sea_lantern
fill 52 253 624 52 273 624 minecraft:light_gray_concrete
setblock 52 253 625 minecraft:sea_lantern
setblock 52 253 629 minecraft:sea_lantern
setblock 52 253 631 minecraft:sea_lantern
setblock 52 253 633 minecraft:sea_lantern
setblock 52 253 635 minecraft:sea_lantern
setblock 52 253 637 minecraft:sea_lantern
setblock 52 253 639 minecraft:sea_lantern
fill 53 253 613 53 273 613 minecraft:light_gray_concrete
setblock 53 253 614 minecraft:sea_lantern
fill 53 253 615 53 273 615 minecraft:light_gray_concrete
setblock 53 253 616 minecraft:sea_lantern
fill 53 253 617 53 273 617 minecraft:light_gray_concrete
setblock 53 253 618 minecraft:sea_lantern
fill 53 253 619 53 273 619 minecraft:light_gray_concrete
setblock 53 253 620 minecraft:sea_lantern
fill 53 253 621 53 273 621 minecraft:light_gray_concrete
setblock 53 253 622 minecraft:sea_lantern
fill 53 253 623 53 273 623 minecraft:light_gray_concrete
setblock 53 253 624 minecraft:sea_lantern
fill 53 253 625 53 273 625 minecraft:light_gray_concrete
setblock 53 253 630 minecraft:sea_lantern
setblock 53 253 632 minecraft:sea_lantern
setblock 53 253 634 minecraft:sea_lantern
setblock 53 253 636 minecraft:sea_lantern
setblock 53 253 638 minecraft:sea_lantern
setblock 54 253 613 minecraft:sea_lantern
fill 54 253 614 54 273 614 minecraft:light_gray_concrete
setblock 54 253 615 minecraft:sea_lantern
fill 54 253 616 54 273 616 minecraft:light_gray_concrete
setblock 54 253 617 minecraft:sea_lantern
fill 54 253 618 54 273 618 minecraft:light_gray_concrete
setblock 54 253 619 minecraft:sea_lantern
fill 54 253 620 54 273 620 minecraft:light_gray_concrete
setblock 54 253 621 minecraft:sea_lantern
fill 54 253 622 54 273 622 minecraft:light_gray_concrete
setblock 54 253 623 minecraft:sea_lantern
fill 54 253 624 54 273 624 minecraft:light_gray_concrete
setblock 54 253 625 minecraft:sea_lantern
setblock 54 253 629 minecraft:sea_lantern
setblock 54 253 631 minecraft:sea_lantern
setblock 54 253 633 minecraft:sea_lantern
setblock 54 253 635 minecraft:sea_lantern
setblock 54 253 637 minecraft:sea_lantern
setblock 54 253 639 minecraft:sea_lantern
fill 55 253 613 55 273 613 minecraft:light_gray_concrete
setblock 55 253 614 minecraft:sea_lantern
fill 55 253 615 55 273 615 minecraft:light_gray_concrete
setblock 55 253 616 minecraft:sea_lantern
fill 55 253 617 55 273 617 minecraft:light_gray_concrete
setblock 55 253 618 minecraft:sea_lantern
fill 55 253 619 55 273 619 minecraft:light_gray_concrete
setblock 55 253 620 minecraft:sea_lantern
fill 55 253 621 55 273 621 minecraft:light_gray_concrete
setblock 55 253 622 minecraft:sea_lantern
fill 55 253 623 55 273 623 minecraft:light_gray_concrete
setblock 55 253 624 minecraft:sea_lantern
fill 55 253 625 55 273 625 minecraft:light_gray_concrete
setblock 55 253 630 minecraft:sea_lantern
setblock 55 253 632 minecraft:sea_lantern
setblock 55 253 634 minecraft:sea_lantern
setblock 55 253 636 minecraft:sea_lantern
setblock 55 253 638 minecraft:sea_lantern
setblock 56 253 613 minecraft:sea_lantern
fill 56 253 614 56 273 614 minecraft:light_gray_concrete
setblock 56 253 615 minecraft:sea_lantern
fill 56 253 616 56 273 616 minecraft:light_gray_concrete
setblock 56 253 617 minecraft:sea_lantern
fill 56 253 618 56 273 618 minecraft:light_gray_concrete
setblock 56 253 619 minecraft:sea_lantern
fill 56 253 620 56 273 620 minecraft:light_gray_concrete
setblock 56 253 621 minecraft:sea_lantern
fill 56 253 622 56 273 622 minecraft:light_gray_concrete
setblock 56 253 623 minecraft:sea_lantern
fill 56 253 624 56 273 624 minecraft:light_gray_concrete
setblock 56 253 625 minecraft:sea_lantern
fill 57 253 613 57 273 613 minecraft:light_gray_concrete
setblock 57 253 614 minecraft:sea_lantern
fill 57 253 615 57 273 615 minecraft:light_gray_concrete
setblock 57 253 616 minecraft:sea_lantern
fill 57 253 617 57 273 617 minecraft:light_gray_concrete
setblock 57 253 618 minecraft:sea_lantern
fill 57 253 619 57 273 619 minecraft:light_gray_concrete
setblock 57 253 620 minecraft:sea_lantern
fill 57 253 621 57 273 621 minecraft:light_gray_concrete
setblock 57 253 622 minecraft:sea_lantern
fill 57 253 623 57 273 623 minecraft:light_gray_concrete
setblock 57 253 624 minecraft:sea_lantern
fill 57 253 625 57 273 625 minecraft:light_gray_concrete
fill 65 253 610 65 254 611 minecraft:glass
setblock 78 253 605 minecraft:sea_lantern
setblock 78 253 607 minecraft:sea_lantern
setblock 78 253 609 minecraft:sea_lantern
setblock 78 253 611 minecraft:sea_lantern
setblock 78 253 613 minecraft:sea_lantern
setblock 79 253 606 minecraft:sea_lantern
setblock 79 253 608 minecraft:sea_lantern
setblock 79 253 610 minecraft:sea_lantern
setblock 79 253 612 minecraft:sea_lantern
setblock 80 253 605 minecraft:sea_lantern
setblock 80 253 607 minecraft:sea_lantern
setblock 80 253 609 minecraft:sea_lantern
setblock 80 253 611 minecraft:sea_lantern
setblock 80 253 613 minecraft:sea_lantern
setblock 81 253 606 minecraft:sea_lantern
setblock 81 253 608 minecraft:sea_lantern
setblock 81 253 610 minecraft:sea_lantern
setblock 81 253 612 minecraft:sea_lantern
setblock 82 253 605 minecraft:sea_lantern
setblock 82 253 607 minecraft:sea_lantern
setblock 82 253 609 minecraft:sea_lantern
setblock 82 253 611 minecraft:sea_lantern
setblock 82 253 613 minecraft:sea_lantern
setblock 83 253 606 minecraft:sea_lantern
setblock 83 253 608 minecraft:sea_lantern
setblock 83 253 610 minecraft:sea_lantern
setblock 83 253 612 minecraft:sea_lantern
setblock 84 253 605 minecraft:sea_lantern
setblock 84 253 607 minecraft:sea_lantern
setblock 84 253 609 minecraft:sea_lantern
setblock 84 253 611 minecraft:sea_lantern
setblock 84 253 613 minecraft:sea_lantern
setblock 85 253 606 minecraft:sea_lantern
setblock 85 253 608 minecraft:sea_lantern
setblock 85 253 610 minecraft:sea_lantern
setblock 85 253 612 minecraft:sea_lantern
setblock 86 253 605 minecraft:sea_lantern
setblock 86 253 607 minecraft:sea_lantern
setblock 86 253 609 minecraft:sea_lantern
setblock 86 253 611 minecraft:sea_lantern
setblock 86 253 613 minecraft:sea_lantern
setblock 87 253 605 minecraft:light_gray_concrete
setblock 88 253 644 minecraft:light_gray_concrete
fill 48 254 613 48 255 613 minecraft:light_gray_concrete
fill 48 254 615 48 255 615 minecraft:light_gray_concrete
fill 48 254 617 48 255 617 minecraft:light_gray_concrete
fill 48 254 619 48 255 619 minecraft:light_gray_concrete
fill 48 254 621 48 255 621 minecraft:light_gray_concrete
fill 48 254 623 48 255 623 minecraft:light_gray_concrete
fill 48 254 625 48 255 625 minecraft:light_gray_concrete
fill 48 254 629 48 255 629 minecraft:light_gray_concrete
fill 48 254 631 48 255 631 minecraft:light_gray_concrete
fill 48 254 633 48 255 633 minecraft:light_gray_concrete
fill 48 254 635 48 255 635 minecraft:light_gray_concrete
fill 48 254 637 48 255 637 minecraft:light_gray_concrete
fill 48 254 639 48 255 639 minecraft:light_gray_concrete
fill 49 254 614 49 255 614 minecraft:light_gray_concrete
fill 49 254 616 49 255 616 minecraft:light_gray_concrete
fill 49 254 618 49 255 618 minecraft:light_gray_concrete
fill 49 254 620 49 255 620 minecraft:light_gray_concrete
fill 49 254 622 49 255 622 minecraft:light_gray_concrete
fill 49 254 624 49 255 624 minecraft:light_gray_concrete
fill 49 254 630 49 255 630 minecraft:light_gray_concrete
fill 49 254 632 49 255 632 minecraft:light_gray_concrete
fill 49 254 634 49 255 634 minecraft:light_gray_concrete
fill 49 254 636 49 255 636 minecraft:light_gray_concrete
fill 49 254 638 49 255 638 minecraft:light_gray_concrete
fill 50 254 613 50 255 613 minecraft:light_gray_concrete
fill 50 254 615 50 255 615 minecraft:light_gray_concrete
fill 50 254 617 50 255 617 minecraft:light_gray_concrete
fill 50 254 619 50 255 619 minecraft:light_gray_concrete
fill 50 254 621 50 255 621 minecraft:light_gray_concrete
fill 50 254 623 50 255 623 minecraft:light_gray_concrete
fill 50 254 625 50 255 625 minecraft:light_gray_concrete
fill 50 254 629 50 255 629 minecraft:light_gray_concrete
fill 50 254 631 50 255 631 minecraft:light_gray_concrete
fill 50 254 633 50 255 633 minecraft:light_gray_concrete
fill 50 254 635 50 255 635 minecraft:light_gray_concrete
fill 50 254 637 50 255 637 minecraft:light_gray_concrete
fill 50 254 639 50 255 639 minecraft:light_gray_concrete
fill 51 254 614 51 255 614 minecraft:light_gray_concrete
fill 51 254 616 51 255 616 minecraft:light_gray_concrete
fill 51 254 618 51 255 618 minecraft:light_gray_concrete
fill 51 254 620 51 255 620 minecraft:light_gray_concrete
fill 51 254 622 51 255 622 minecraft:light_gray_concrete
fill 51 254 624 51 255 624 minecraft:light_gray_concrete
fill 51 254 630 51 255 630 minecraft:light_gray_concrete
fill 51 254 632 51 255 632 minecraft:light_gray_concrete
fill 51 254 634 51 255 634 minecraft:light_gray_concrete
fill 51 254 636 51 255 636 minecraft:light_gray_concrete
fill 51 254 638 51 255 638 minecraft:light_gray_concrete
fill 52 254 613 52 255 613 minecraft:light_gray_concrete
fill 52 254 615 52 255 615 minecraft:light_gray_concrete
fill 52 254 617 52 255 617 minecraft:light_gray_concrete
fill 52 254 619 52 255 619 minecraft:light_gray_concrete
fill 52 254 621 52 255 621 minecraft:light_gray_concrete
fill 52 254 623 52 255 623 minecraft:light_gray_concrete
fill 52 254 625 52 255 625 minecraft:light_gray_concrete
fill 52 254 629 52 255 629 minecraft:light_gray_concrete
fill 52 254 631 52 255 631 minecraft:light_gray_concrete
fill 52 254 633 52 255 633 minecraft:light_gray_concrete
fill 52 254 635 52 255 635 minecraft:light_gray_concrete
fill 52 254 637 52 255 637 minecraft:light_gray_concrete
fill 52 254 639 52 255 639 minecraft:light_gray_concrete
fill 53 254 614 53 255 614 minecraft:light_gray_concrete
fill 53 254 616 53 255 616 minecraft:light_gray_concrete
fill 53 254 618 53 255 618 minecraft:light_gray_concrete
fill 53 254 620 53 255 620 minecraft:light_gray_concrete
fill 53 254 622 53 255 622 minecraft:light_gray_concrete
fill 53 254 624 53 255 624 minecraft:light_gray_concrete
fill 53 254 630 53 255 630 minecraft:light_gray_concrete
fill 53 254 632 53 255 632 minecraft:light_gray_concrete
fill 53 254 634 53 255 634 minecraft:light_gray_concrete
fill 53 254 636 53 255 636 minecraft:light_gray_concrete
fill 53 254 638 53 255 638 minecraft:light_gray_concrete
fill 54 254 613 54 255 613 minecraft:light_gray_concrete
fill 54 254 615 54 255 615 minecraft:light_gray_concrete
fill 54 254 617 54 255 617 minecraft:light_gray_concrete
fill 54 254 619 54 255 619 minecraft:light_gray_concrete
fill 54 254 621 54 255 621 minecraft:light_gray_concrete
fill 54 254 623 54 255 623 minecraft:light_gray_concrete
fill 54 254 625 54 255 625 minecraft:light_gray_concrete
fill 54 254 629 54 255 629 minecraft:light_gray_concrete
fill 54 254 631 54 255 631 minecraft:light_gray_concrete
fill 54 254 633 54 255 633 minecraft:light_gray_concrete
fill 54 254 635 54 255 635 minecraft:light_gray_concrete
fill 54 254 637 54 255 637 minecraft:light_gray_concrete
fill 54 254 639 54 255 639 minecraft:light_gray_concrete
fill 55 254 614 55 255 614 minecraft:light_gray_concrete
fill 55 254 616 55 255 616 minecraft:light_gray_concrete
fill 55 254 618 55 255 618 minecraft:light_gray_concrete
fill 55 254 620 55 255 620 minecraft:light_gray_concrete
fill 55 254 622 55 255 622 minecraft:light_gray_concrete
fill 55 254 624 55 255 624 minecraft:light_gray_concrete
fill 55 254 630 55 255 630 minecraft:light_gray_concrete
fill 55 254 632 55 255 632 minecraft:light_gray_concrete
fill 55 254 634 55 255 634 minecraft:light_gray_concrete
fill 55 254 636 55 255 636 minecraft:light_gray_concrete
fill 55 254 638 55 255 638 minecraft:light_gray_concrete
fill 56 254 613 56 255 613 minecraft:light_gray_concrete
fill 56 254 615 56 255 615 minecraft:light_gray_concrete
fill 56 254 617 56 255 617 minecraft:light_gray_concrete
fill 56 254 619 56 255 619 minecraft:light_gray_concrete
fill 56 254 621 56 255 621 minecraft:light_gray_concrete
fill 56 254 623 56 255 623 minecraft:light_gray_concrete
fill 56 254 625 56 255 625 minecraft:light_gray_concrete
fill 56 254 635 56 255 635 minecraft:glass
fill 57 254 614 57 255 614 minecraft:light_gray_concrete
fill 57 254 616 57 255 616 minecraft:light_gray_concrete
fill 57 254 618 57 255 618 minecraft:light_gray_concrete
fill 57 254 620 57 255 620 minecraft:light_gray_concrete
fill 57 254 622 57 255 622 minecraft:light_gray_concrete
fill 57 254 624 57 255 624 minecraft:light_gray_concrete
fill 78 254 605 78 255 605 minecraft:light_gray_concrete
fill 78 254 607 78 255 607 minecraft:light_gray_concrete
fill 78 254 609 78 255 609 minecraft:light_gray_concrete
fill 78 254 611 78 255 611 minecraft:light_gray_concrete
fill 78 254 613 78 255 613 minecraft:light_gray_concrete
fill 79 254 606 79 255 606 minecraft:light_gray_concrete
fill 79 254 608 79 255 608 minecraft:light_gray_concrete
fill 79 254 610 79 255 610 minecraft:light_gray_concrete
fill 79 254 612 79 255 612 minecraft:light_gray_concrete
fill 80 254 605 80 255 605 minecraft:light_gray_concrete
fill 80 254 607 80 255 607 minecraft:light_gray_concrete
fill 80 254 609 80 255 609 minecraft:light_gray_concrete
fill 80 254 611 80 255 611 minecraft:light_gray_concrete
fill 80 254 613 80 255 613 minecraft:light_gray_concrete
fill 81 254 606 81 255 606 minecraft:light_gray_concrete
fill 81 254 608 81 255 608 minecraft:light_gray_concrete
fill 81 254 610 81 255 610 minecraft:light_gray_concrete
fill 81 254 612 81 255 612 minecraft:light_gray_concrete
fill 82 254 605 82 255 605 minecraft:light_gray_concrete
fill 82 254 607 82 255 607 minecraft:light_gray_concrete
fill 82 254 609 82 255 609 minecraft:light_gray_concrete
fill 82 254 611 82 255 611 minecraft:light_gray_concrete
fill 82 254 613 82 255 613 minecraft:light_gray_concrete
fill 83 254 606 83 255 606 minecraft:light_gray_concrete
fill 83 254 608 83 255 608 minecraft:light_gray_concrete
fill 83 254 610 83 255 610 minecraft:light_gray_concrete
fill 83 254 612 83 255 612 minecraft:light_gray_concrete
fill 84 254 605 84 255 605 minecraft:light_gray_concrete
fill 84 254 607 84 255 607 minecraft:light_gray_concrete
fill 84 254 609 84 255 609 minecraft:light_gray_concrete
fill 84 254 611 84 255 611 minecraft:light_gray_concrete
fill 84 254 613 84 255 613 minecraft:light_gray_concrete
fill 85 254 606 85 255 606 minecraft:light_gray_concrete
fill 85 254 608 85 255 608 minecraft:light_gray_concrete
fill 85 254 610 85 255 610 minecraft:light_gray_concrete
fill 85 254 612 85 255 612 minecraft:light_gray_concrete
fill 86 254 605 86 255 605 minecraft:light_gray_concrete
fill 86 254 607 86 255 607 minecraft:light_gray_concrete
fill 86 254 609 86 255 609 minecraft:light_gray_concrete
fill 86 254 611 86 255 611 minecraft:light_gray_concrete
fill 86 254 613 86 255 613 minecraft:light_gray_concrete
fill 47 256 609 47 261 609 minecraft:sea_lantern
fill 47 256 617 48 256 617 minecraft:sea_lantern
fill 47 256 625 48 256 625 minecraft:sea_lantern
fill 47 256 633 48 256 633 minecraft:sea_lantern
fill 47 256 641 47 261 641 minecraft:sea_lantern
setblock 48 256 613 minecraft:sea_lantern
setblock 48 256 615 minecraft:sea_lantern
setblock 48 256 619 minecraft:sea_lantern
setblock 48 256 621 minecraft:sea_lantern
setblock 48 256 623 minecraft:sea_lantern
setblock 48 256 629 minecraft:sea_lantern
setblock 48 256 631 minecraft:sea_lantern
setblock 48 256 635 minecraft:sea_lantern
setblock 48 256 637 minecraft:sea_lantern
setblock 48 256 639 minecraft:sea_lantern
setblock 49 256 614 minecraft:sea_lantern
setblock 49 256 616 minecraft:sea_lantern
setblock 49 256 618 minecraft:sea_lantern
setblock 49 256 620 minecraft:sea_lantern
setblock 49 256 622 minecraft:sea_lantern
setblock 49 256 624 minecraft:sea_lantern
setblock 49 256 630 minecraft:sea_lantern
setblock 49 256 632 minecraft:sea_lantern
setblock 49 256 634 minecraft:sea_lantern
setblock 49 256 636 minecraft:sea_lantern
setblock 49 256 638 minecraft:sea_lantern
setblock 50 256 613 minecraft:sea_lantern
setblock 50 256 615 minecraft:sea_lantern
setblock 50 256 617 minecraft:sea_lantern
setblock 50 256 619 minecraft:sea_lantern
setblock 50 256 621 minecraft:sea_lantern
setblock 50 256 623 minecraft:sea_lantern
setblock 50 256 625 minecraft:sea_lantern
setblock 50 256 629 minecraft:sea_lantern
setblock 50 256 631 minecraft:sea_lantern
setblock 50 256 633 minecraft:sea_lantern
setblock 50 256 635 minecraft:sea_lantern
setblock 50 256 637 minecraft:sea_lantern
setblock 50 256 639 minecraft:sea_lantern
fill 50 256 646 50 261 646 minecraft:sea_lantern
setblock 51 256 614 minecraft:sea_lantern
setblock 51 256 616 minecraft:sea_lantern
setblock 51 256 618 minecraft:sea_lantern
setblock 51 256 620 minecraft:sea_lantern
setblock 51 256 622 minecraft:sea_lantern
setblock 51 256 624 minecraft:sea_lantern
setblock 51 256 630 minecraft:sea_lantern
setblock 51 256 632 minecraft:sea_lantern
setblock 51 256 634 minecraft:sea_lantern
setblock 51 256 636 minecraft:sea_lantern
setblock 51 256 638 minecraft:sea_lantern
setblock 52 256 613 minecraft:sea_lantern
setblock 52 256 615 minecraft:sea_lantern
setblock 52 256 617 minecraft:sea_lantern
setblock 52 256 619 minecraft:sea_lantern
setblock 52 256 621 minecraft:sea_lantern
setblock 52 256 623 minecraft:sea_lantern
setblock 52 256 625 minecraft:sea_lantern
setblock 52 256 629 minecraft:sea_lantern
setblock 52 256 631 minecraft:sea_lantern
setblock 52 256 633 minecraft:sea_lantern
setblock 52 256 635 minecraft:sea_lantern
setblock 52 256 637 minecraft:sea_lantern
setblock 52 256 639 minecraft:sea_lantern
setblock 53 256 614 minecraft:sea_lantern
setblock 53 256 616 minecraft:sea_lantern
setblock 53 256 618 minecraft:sea_lantern
setblock 53 256 620 minecraft:sea_lantern
setblock 53 256 622 minecraft:sea_lantern
setblock 53 256 624 minecraft:sea_lantern
setblock 53 256 630 minecraft:sea_lantern
setblock 53 256 632 minecraft:sea_lantern
setblock 53 256 634 minecraft:sea_lantern
setblock 53 256 636 minecraft:sea_lantern
setblock 53 256 638 minecraft:sea_lantern
fill 54 256 604 54 261 604 minecraft:sea_lantern
setblock 54 256 613 minecraft:sea_lantern
setblock 54 256 615 minecraft:sea_lantern
setblock 54 256 617 minecraft:sea_lantern
setblock 54 256 619 minecraft:sea_lantern
setblock 54 256 621 minecraft:sea_lantern
setblock 54 256 623 minecraft:sea_lantern
setblock 54 256 625 minecraft:sea_lantern
setblock 54 256 629 minecraft:sea_lantern
setblock 54 256 631 minecraft:sea_lantern
setblock 54 256 633 minecraft:sea_lantern
setblock 54 256 635 minecraft:sea_lantern
setblock 54 256 637 minecraft:sea_lantern
setblock 54 256 639 minecraft:sea_lantern
setblock 55 256 614 minecraft:sea_lantern
setblock 55 256 616 minecraft:sea_lantern
setblock 55 256 618 minecraft:sea_lantern
setblock 55 256 620 minecraft:sea_lantern
setblock 55 256 622 minecraft:sea_lantern
setblock 55 256 624 minecraft:sea_lantern
setblock 55 256 630 minecraft:sea_lantern
setblock 55 256 632 minecraft:sea_lantern
setblock 55 256 634 minecraft:sea_lantern
setblock 55 256 636 minecraft:sea_lantern
setblock 55 256 638 minecraft:sea_lantern
setblock 56 256 613 minecraft:sea_lantern
setblock 56 256 615 minecraft:sea_lantern
setblock 56 256 617 minecraft:sea_lantern
setblock 56 256 619 minecraft:sea_lantern
setblock 56 256 621 minecraft:sea_lantern
setblock 56 256 623 minecraft:sea_lantern
setblock 56 256 625 minecraft:sea_lantern
setblock 57 256 614 minecraft:sea_lantern
setblock 57 256 616 minecraft:sea_lantern
setblock 57 256 618 minecraft:sea_lantern
setblock 57 256 620 minecraft:sea_lantern
setblock 57 256 622 minecraft:sea_lantern
setblock 57 256 624 minecraft:sea_lantern
fill 58 256 646 58 261 646 minecraft:sea_lantern
fill 62 256 604 62 261 604 minecraft:sea_lantern
fill 66 256 646 66 261 646 minecraft:sea_lantern
fill 70 256 604 70 261 604 minecraft:sea_lantern
fill 74 256 646 74 261 646 minecraft:sea_lantern
fill 78 256 604 78 256 605 minecraft:sea_lantern
setblock 78 256 607 minecraft:sea_lantern
setblock 78 256 609 minecraft:sea_lantern
setblock 78 256 611 minecraft:sea_lantern
setblock 78 256 613 minecraft:sea_lantern
setblock 79 256 606 minecraft:sea_lantern
setblock 79 256 608 minecraft:sea_lantern
setblock 79 256 610 minecraft:sea_lantern
setblock 79 256 612 minecraft:sea_lantern
setblock 80 256 605 minecraft:sea_lantern
setblock 80 256 607 minecraft:sea_lantern
setblock 80 256 609 minecraft:sea_lantern
setblock 80 256 611 minecraft:sea_lantern
setblock 80 256 613 minecraft:sea_lantern
setblock 81 256 606 minecraft:sea_lantern
setblock 81 256 608 minecraft:sea_lantern
setblock 81 256 610 minecraft:sea_lantern
setblock 81 256 612 minecraft:sea_lantern
setblock 82 256 605 minecraft:sea_lantern
setblock 82 256 607 minecraft:sea_lantern
setblock 82 256 609 minecraft:sea_lantern
setblock 82 256 611 minecraft:sea_lantern
setblock 82 256 613 minecraft:sea_lantern
fill 82 256 646 82 261 646 minecraft:sea_lantern
setblock 83 256 606 minecraft:sea_lantern
setblock 83 256 608 minecraft:sea_lantern
setblock 83 256 610 minecraft:sea_lantern
setblock 83 256 612 minecraft:sea_lantern
setblock 84 256 605 minecraft:sea_lantern
setblock 84 256 607 minecraft:sea_lantern
setblock 84 256 609 minecraft:sea_lantern
setblock 84 256 611 minecraft:sea_lantern
setblock 84 256 613 minecraft:sea_lantern
setblock 85 256 606 minecraft:sea_lantern
setblock 85 256 608 minecraft:sea_lantern
setblock 85 256 610 minecraft:sea_lantern
setblock 85 256 612 minecraft:sea_lantern
fill 86 256 604 86 256 605 minecraft:sea_lantern
setblock 86 256 607 minecraft:sea_lantern
setblock 86 256 609 minecraft:sea_lantern
setblock 86 256 611 minecraft:sea_lantern
setblock 86 256 613 minecraft:sea_lantern
fill 89 256 609 89 261 609 minecraft:sea_lantern
fill 89 256 617 89 261 617 minecraft:sea_lantern
fill 89 256 625 89 261 625 minecraft:sea_lantern
fill 89 256 633 89 261 633 minecraft:sea_lantern
fill 89 256 641 89 261 641 minecraft:sea_lantern
fill 47 257 617 47 261 617 minecraft:sea_lantern
fill 47 257 625 47 261 625 minecraft:sea_lantern
fill 47 257 633 47 261 633 minecraft:sea_lantern
fill 48 257 613 48 258 613 minecraft:light_gray_concrete
fill 48 257 615 48 258 615 minecraft:light_gray_concrete
fill 48 257 617 48 258 617 minecraft:light_gray_concrete
fill 48 257 619 48 258 619 minecraft:light_gray_concrete
fill 48 257 621 48 258 621 minecraft:light_gray_concrete
fill 48 257 623 48 258 623 minecraft:light_gray_concrete
fill 48 257 625 48 258 625 minecraft:light_gray_concrete
setblock 48 257 629 minecraft:light_gray_concrete
setblock 48 257 631 minecraft:light_gray_concrete
setblock 48 257 633 minecraft:light_gray_concrete
fill 48 257 635 48 273 635 minecraft:light_gray_concrete
setblock 48 257 637 minecraft:light_gray_concrete
setblock 48 257 639 minecraft:light_gray_concrete
fill 49 257 614 49 258 614 minecraft:light_gray_concrete
fill 49 257 616 49 258 616 minecraft:light_gray_concrete
fill 49 257 618 49 258 618 minecraft:light_gray_concrete
fill 49 257 620 49 258 620 minecraft:light_gray_concrete
fill 49 257 622 49 258 622 minecraft:light_gray_concrete
fill 49 257 624 49 258 624 minecraft:light_gray_concrete
setblock 49 257 630 minecraft:light_gray_concrete
setblock 49 257 632 minecraft:light_gray_concrete
setblock 49 257 634 minecraft:light_gray_concrete
setblock 49 257 636 minecraft:light_gray_concrete
setblock 49 257 638 minecraft:light_gray_concrete
fill 50 257 613 50 258 613 minecraft:light_gray_concrete
fill 50 257 615 50 258 615 minecraft:light_gray_concrete
fill 50 257 617 50 258 617 minecraft:light_gray_concrete
fill 50 257 619 50 258 619 minecraft:light_gray_concrete
fill 50 257 621 50 258 621 minecraft:light_gray_concrete
fill 50 257 623 50 258 623 minecraft:light_gray_concrete
fill 50 257 625 50 258 625 minecraft:light_gray_concrete
setblock 50 257 629 minecraft:light_gray_concrete
setblock 50 257 631 minecraft:light_gray_concrete
setblock 50 257 633 minecraft:light_gray_concrete
setblock 50 257 635 minecraft:light_gray_concrete
setblock 50 257 637 minecraft:light_gray_concrete
setblock 50 257 639 minecraft:light_gray_concrete
fill 51 257 614 51 258 614 minecraft:light_gray_concrete
fill 51 257 616 51 258 616 minecraft:light_gray_concrete
fill 51 257 618 51 258 618 minecraft:light_gray_concrete
fill 51 257 620 51 258 620 minecraft:light_gray_concrete
fill 51 257 622 51 258 622 minecraft:light_gray_concrete
fill 51 257 624 51 258 624 minecraft:light_gray_concrete
setblock 51 257 630 minecraft:light_gray_concrete
setblock 51 257 632 minecraft:light_gray_concrete
setblock 51 257 634 minecraft:light_gray_concrete
setblock 51 257 636 minecraft:light_gray_concrete
setblock 51 257 638 minecraft:light_gray_concrete
fill 52 257 613 52 258 613 minecraft:light_gray_concrete
fill 52 257 615 52 258 615 minecraft:light_gray_concrete
fill 52 257 617 52 258 617 minecraft:light_gray_concrete
fill 52 257 619 52 258 619 minecraft:light_gray_concrete
fill 52 257 621 52 258 621 minecraft:light_gray_concrete
fill 52 257 623 52 258 623 minecraft:light_gray_concrete
fill 52 257 625 52 258 625 minecraft:light_gray_concrete
setblock 52 257 629 minecraft:light_gray_concrete
setblock 52 257 631 minecraft:light_gray_concrete
setblock 52 257 633 minecraft:light_gray_concrete
setblock 52 257 635 minecraft:light_gray_concrete
setblock 52 257 637 minecraft:light_gray_concrete
setblock 52 257 639 minecraft:light_gray_concrete
fill 53 257 614 53 258 614 minecraft:light_gray_concrete
fill 53 257 616 53 258 616 minecraft:light_gray_concrete
fill 53 257 618 53 258 618 minecraft:light_gray_concrete
fill 53 257 620 53 258 620 minecraft:light_gray_concrete
fill 53 257 622 53 258 622 minecraft:light_gray_concrete
fill 53 257 624 53 258 624 minecraft:light_gray_concrete
setblock 53 257 630 minecraft:light_gray_concrete
setblock 53 257 632 minecraft:light_gray_concrete
setblock 53 257 634 minecraft:light_gray_concrete
setblock 53 257 636 minecraft:light_gray_concrete
setblock 53 257 638 minecraft:light_gray_concrete
fill 54 257 613 54 258 613 minecraft:light_gray_concrete
fill 54 257 615 54 258 615 minecraft:light_gray_concrete
fill 54 257 617 54 258 617 minecraft:light_gray_concrete
fill 54 257 619 54 258 619 minecraft:light_gray_concrete
fill 54 257 621 54 258 621 minecraft:light_gray_concrete
fill 54 257 623 54 258 623 minecraft:light_gray_concrete
fill 54 257 625 54 258 625 minecraft:light_gray_concrete
setblock 54 257 629 minecraft:light_gray_concrete
setblock 54 257 631 minecraft:light_gray_concrete
setblock 54 257 633 minecraft:light_gray_concrete
setblock 54 257 635 minecraft:light_gray_concrete
setblock 54 257 637 minecraft:light_gray_concrete
setblock 54 257 639 minecraft:light_gray_concrete
fill 55 257 614 55 258 614 minecraft:light_gray_concrete
fill 55 257 616 55 258 616 minecraft:light_gray_concrete
fill 55 257 618 55 258 618 minecraft:light_gray_concrete
fill 55 257 620 55 258 620 minecraft:light_gray_concrete
fill 55 257 622 55 258 622 minecraft:light_gray_concrete
fill 55 257 624 55 258 624 minecraft:light_gray_concrete
setblock 55 257 630 minecraft:light_gray_concrete
setblock 55 257 632 minecraft:light_gray_concrete
setblock 55 257 634 minecraft:light_gray_concrete
setblock 55 257 636 minecraft:light_gray_concrete
setblock 55 257 638 minecraft:light_gray_concrete
fill 56 257 613 56 258 613 minecraft:light_gray_concrete
fill 56 257 615 56 258 615 minecraft:light_gray_concrete
fill 56 257 617 56 258 617 minecraft:light_gray_concrete
fill 56 257 619 56 258 619 minecraft:light_gray_concrete
fill 56 257 621 56 258 621 minecraft:light_gray_concrete
fill 56 257 623 56 258 623 minecraft:light_gray_concrete
fill 56 257 625 56 258 625 minecraft:light_gray_concrete
fill 57 257 614 57 258 614 minecraft:light_gray_concrete
fill 57 257 616 57 258 616 minecraft:light_gray_concrete
fill 57 257 618 57 258 618 minecraft:light_gray_concrete
fill 57 257 620 57 258 620 minecraft:light_gray_concrete
fill 57 257 622 57 258 622 minecraft:light_gray_concrete
fill 57 257 624 57 258 624 minecraft:light_gray_concrete
fill 78 257 604 78 261 604 minecraft:sea_lantern
fill 78 257 605 78 258 605 minecraft:light_gray_concrete
fill 78 257 607 78 258 607 minecraft:light_gray_concrete
fill 78 257 609 78 258 609 minecraft:light_gray_concrete
fill 78 257 611 78 258 611 minecraft:light_gray_concrete
fill 78 257 613 78 258 613 minecraft:light_gray_concrete
fill 79 257 606 79 258 606 minecraft:light_gray_concrete
fill 79 257 608 79 258 608 minecraft:light_gray_concrete
fill 79 257 610 79 258 610 minecraft:light_gray_concrete
fill 79 257 612 79 258 612 minecraft:light_gray_concrete
fill 80 257 605 80 258 605 minecraft:light_gray_concrete
fill 80 257 607 80 258 607 minecraft:light_gray_concrete
fill 80 257 609 80 258 609 minecraft:light_gray_concrete
fill 80 257 611 80 258 611 minecraft:light_gray_concrete
fill 80 257 613 80 258 613 minecraft:light_gray_concrete
fill 81 257 606 81 258 606 minecraft:light_gray_concrete
fill 81 257 608 81 258 608 minecraft:light_gray_concrete
fill 81 257 610 81 258 610 minecraft:light_gray_concrete
fill 81 257 612 81 258 612 minecraft:light_gray_concrete
fill 82 257 605 82 258 605 minecraft:light_gray_concrete
fill 82 257 607 82 258 607 minecraft:light_gray_concrete
fill 82 257 609 82 258 609 minecraft:light_gray_concrete
fill 82 257 611 82 258 611 minecraft:light_gray_concrete
fill 82 257 613 82 258 613 minecraft:light_gray_concrete
fill 83 257 606 83 258 606 minecraft:light_gray_concrete
fill 83 257 608 83 258 608 minecraft:light_gray_concrete
fill 83 257 610 83 258 610 minecraft:light_gray_concrete
fill 83 257 612 83 258 612 minecraft:light_gray_concrete
fill 84 257 605 84 258 605 minecraft:light_gray_concrete
fill 84 257 607 84 258 607 minecraft:light_gray_concrete
fill 84 257 609 84 258 609 minecraft:light_gray_concrete
fill 84 257 611 84 258 611 minecraft:light_gray_concrete
fill 84 257 613 84 258 613 minecraft:light_gray_concrete
fill 85 257 606 85 258 606 minecraft:light_gray_concrete
fill 85 257 608 85 258 608 minecraft:light_gray_concrete
fill 85 257 610 85 258 610 minecraft:light_gray_concrete
fill 85 257 612 85 258 612 minecraft:light_gray_concrete
fill 86 257 604 86 261 604 minecraft:sea_lantern
fill 86 257 605 86 258 605 minecraft:light_gray_concrete
fill 86 257 607 86 258 607 minecraft:light_gray_concrete
fill 86 257 609 86 258 609 minecraft:light_gray_concrete
fill 86 257 611 86 258 611 minecraft:light_gray_concrete
fill 86 257 613 86 258 613 minecraft:light_gray_concrete
setblock 48 259 613 minecraft:sea_lantern
setblock 48 259 615 minecraft:sea_lantern
setblock 48 259 617 minecraft:sea_lantern
setblock 48 259 619 minecraft:sea_lantern
setblock 48 259 621 minecraft:sea_lantern
setblock 48 259 623 minecraft:sea_lantern
setblock 48 259 625 minecraft:sea_lantern
setblock 49 259 614 minecraft:sea_lantern
setblock 49 259 616 minecraft:sea_lantern
setblock 49 259 618 minecraft:sea_lantern
setblock 49 259 620 minecraft:sea_lantern
setblock 49 259 622 minecraft:sea_lantern
setblock 49 259 624 minecraft:sea_lantern
setblock 50 259 607 minecraft:light[level=14]
setblock 50 259 613 minecraft:sea_lantern
setblock 50 259 615 minecraft:sea_lantern
setblock 50 259 617 minecraft:sea_lantern
setblock 50 259 619 minecraft:sea_lantern
setblock 50 259 621 minecraft:sea_lantern
setblock 50 259 623 minecraft:sea_lantern
setblock 50 259 625 minecraft:sea_lantern
setblock 50 259 631 minecraft:light[level=14]
setblock 50 259 639 minecraft:light[level=14]
setblock 51 259 614 minecraft:sea_lantern
setblock 51 259 616 minecraft:sea_lantern
setblock 51 259 618 minecraft:sea_lantern
setblock 51 259 620 minecraft:sea_lantern
setblock 51 259 622 minecraft:sea_lantern
setblock 51 259 624 minecraft:sea_lantern
setblock 52 259 613 minecraft:sea_lantern
setblock 52 259 615 minecraft:sea_lantern
setblock 52 259 617 minecraft:sea_lantern
setblock 52 259 619 minecraft:sea_lantern
setblock 52 259 621 minecraft:sea_lantern
setblock 52 259 623 minecraft:sea_lantern
setblock 52 259 625 minecraft:sea_lantern
setblock 53 259 614 minecraft:sea_lantern
setblock 53 259 616 minecraft:sea_lantern
setblock 53 259 618 minecraft:sea_lantern
setblock 53 259 620 minecraft:sea_lantern
setblock 53 259 622 minecraft:sea_lantern
setblock 53 259 624 minecraft:sea_lantern
setblock 54 259 613 minecraft:sea_lantern
setblock 54 259 615 minecraft:sea_lantern
setblock 54 259 617 minecraft:sea_lantern
setblock 54 259 619 minecraft:sea_lantern
setblock 54 259 621 minecraft:sea_lantern
setblock 54 259 623 minecraft:sea_lantern
setblock 54 259 625 minecraft:sea_lantern
setblock 55 259 614 minecraft:sea_lantern
setblock 55 259 616 minecraft:sea_lantern
setblock 55 259 618 minecraft:sea_lantern
setblock 55 259 620 minecraft:sea_lantern
setblock 55 259 622 minecraft:sea_lantern
setblock 55 259 624 minecraft:sea_lantern
setblock 56 259 613 minecraft:sea_lantern
setblock 56 259 615 minecraft:sea_lantern
setblock 56 259 617 minecraft:sea_lantern
setblock 56 259 619 minecraft:sea_lantern
setblock 56 259 621 minecraft:sea_lantern
setblock 56 259 623 minecraft:sea_lantern
setblock 56 259 625 minecraft:sea_lantern
setblock 57 259 614 minecraft:sea_lantern
setblock 57 259 616 minecraft:sea_lantern
setblock 57 259 618 minecraft:sea_lantern
setblock 57 259 620 minecraft:sea_lantern
setblock 57 259 622 minecraft:sea_lantern
setblock 57 259 624 minecraft:sea_lantern
setblock 58 259 607 minecraft:light[level=14]
setblock 58 259 615 minecraft:light[level=14]
setblock 58 259 623 minecraft:light[level=14]
setblock 58 259 631 minecraft:light[level=14]
setblock 58 259 639 minecraft:light[level=14]
setblock 66 259 607 minecraft:light[level=14]
setblock 66 259 615 minecraft:light[level=14]
setblock 66 259 623 minecraft:light[level=14]
setblock 66 259 631 minecraft:light[level=14]
setblock 66 259 639 minecraft:light[level=14]
fill 69 259 612 70 260 613 minecraft:gray_concrete
setblock 74 259 607 minecraft:light[level=14]
setblock 74 259 615 minecraft:light[level=14]
setblock 74 259 623 minecraft:light[level=14]
setblock 74 259 631 minecraft:light[level=14]
setblock 74 259 639 minecraft:light[level=14]
setblock 78 259 605 minecraft:sea_lantern
setblock 78 259 607 minecraft:sea_lantern
setblock 78 259 609 minecraft:sea_lantern
setblock 78 259 611 minecraft:sea_lantern
setblock 78 259 613 minecraft:sea_lantern
setblock 79 259 606 minecraft:sea_lantern
setblock 79 259 608 minecraft:sea_lantern
setblock 79 259 610 minecraft:sea_lantern
setblock 79 259 612 minecraft:sea_lantern
setblock 80 259 605 minecraft:sea_lantern
setblock 80 259 607 minecraft:sea_lantern
setblock 80 259 609 minecraft:sea_lantern
setblock 80 259 611 minecraft:sea_lantern
setblock 80 259 613 minecraft:sea_lantern
setblock 81 259 606 minecraft:sea_lantern
setblock 81 259 608 minecraft:sea_lantern
setblock 81 259 610 minecraft:sea_lantern
setblock 81 259 612 minecraft:sea_lantern
setblock 82 259 605 minecraft:sea_lantern
setblock 82 259 607 minecraft:sea_lantern
setblock 82 259 609 minecraft:sea_lantern
setblock 82 259 611 minecraft:sea_lantern
setblock 82 259 613 minecraft:sea_lantern
setblock 82 259 615 minecraft:light[level=14]
setblock 82 259 623 minecraft:light[level=14]
setblock 82 259 631 minecraft:light[level=14]
setblock 82 259 639 minecraft:light[level=14]
setblock 83 259 606 minecraft:sea_lantern
setblock 83 259 608 minecraft:sea_lantern
setblock 83 259 610 minecraft:sea_lantern
setblock 83 259 612 minecraft:sea_lantern
setblock 84 259 605 minecraft:sea_lantern
setblock 84 259 607 minecraft:sea_lantern
setblock 84 259 609 minecraft:sea_lantern
setblock 84 259 611 minecraft:sea_lantern
setblock 84 259 613 minecraft:sea_lantern
setblock 85 259 606 minecraft:sea_lantern
setblock 85 259 608 minecraft:sea_lantern
setblock 85 259 610 minecraft:sea_lantern
setblock 85 259 612 minecraft:sea_lantern
setblock 86 259 605 minecraft:sea_lantern
setblock 86 259 607 minecraft:sea_lantern
setblock 86 259 609 minecraft:sea_lantern
setblock 86 259 611 minecraft:sea_lantern
setblock 86 259 613 minecraft:sea_lantern
fill 48 260 613 48 261 613 minecraft:light_gray_concrete
fill 48 260 615 48 261 615 minecraft:light_gray_concrete
fill 48 260 617 48 261 617 minecraft:light_gray_concrete
fill 48 260 619 48 261 619 minecraft:light_gray_concrete
fill 48 260 621 48 261 621 minecraft:light_gray_concrete
fill 48 260 623 48 261 623 minecraft:light_gray_concrete
fill 48 260 625 48 261 625 minecraft:light_gray_concrete
fill 49 260 614 49 261 614 minecraft:light_gray_concrete
fill 49 260 616 49 261 616 minecraft:light_gray_concrete
fill 49 260 618 49 261 618 minecraft:light_gray_concrete
fill 49 260 620 49 261 620 minecraft:light_gray_concrete
fill 49 260 622 49 261 622 minecraft:light_gray_concrete
fill 49 260 624 49 261 624 minecraft:light_gray_concrete
fill 50 260 613 50 261 613 minecraft:light_gray_concrete
fill 50 260 615 50 261 615 minecraft:light_gray_concrete
fill 50 260 617 50 261 617 minecraft:light_gray_concrete
fill 50 260 619 50 261 619 minecraft:light_gray_concrete
fill 50 260 621 50 261 621 minecraft:light_gray_concrete
fill 50 260 623 50 261 623 minecraft:light_gray_concrete
fill 50 260 625 50 261 625 minecraft:light_gray_concrete
fill 51 260 614 51 261 614 minecraft:light_gray_concrete
fill 51 260 616 51 261 616 minecraft:light_gray_concrete
fill 51 260 618 51 261 618 minecraft:light_gray_concrete
fill 51 260 620 51 261 620 minecraft:light_gray_concrete
fill 51 260 622 51 261 622 minecraft:light_gray_concrete
fill 51 260 624 51 261 624 minecraft:light_gray_concrete
fill 52 260 613 52 261 613 minecraft:light_gray_concrete
fill 52 260 615 52 261 615 minecraft:light_gray_concrete
fill 52 260 617 52 261 617 minecraft:light_gray_concrete
fill 52 260 619 52 261 619 minecraft:light_gray_concrete
fill 52 260 621 52 261 621 minecraft:light_gray_concrete
fill 52 260 623 52 261 623 minecraft:light_gray_concrete
fill 52 260 625 52 261 625 minecraft:light_gray_concrete
fill 53 260 614 53 261 614 minecraft:light_gray_concrete
fill 53 260 616 53 261 616 minecraft:light_gray_concrete
fill 53 260 618 53 261 618 minecraft:light_gray_concrete
fill 53 260 620 53 261 620 minecraft:light_gray_concrete
fill 53 260 622 53 261 622 minecraft:light_gray_concrete
fill 53 260 624 53 261 624 minecraft:light_gray_concrete
fill 54 260 613 54 261 613 minecraft:light_gray_concrete
fill 54 260 615 54 261 615 minecraft:light_gray_concrete
fill 54 260 617 54 261 617 minecraft:light_gray_concrete
fill 54 260 619 54 261 619 minecraft:light_gray_concrete
fill 54 260 621 54 261 621 minecraft:light_gray_concrete
fill 54 260 623 54 261 623 minecraft:light_gray_concrete
fill 54 260 625 54 261 625 minecraft:light_gray_concrete
fill 55 260 614 55 261 614 minecraft:light_gray_concrete
fill 55 260 616 55 261 616 minecraft:light_gray_concrete
fill 55 260 618 55 261 618 minecraft:light_gray_concrete
fill 55 260 620 55 261 620 minecraft:light_gray_concrete
fill 55 260 622 55 261 622 minecraft:light_gray_concrete
fill 55 260 624 55 261 624 minecraft:light_gray_concrete
fill 56 260 613 56 261 613 minecraft:light_gray_concrete
fill 56 260 615 56 261 615 minecraft:light_gray_concrete
fill 56 260 617 56 261 617 minecraft:light_gray_concrete
fill 56 260 619 56 261 619 minecraft:light_gray_concrete
fill 56 260 621 56 261 621 minecraft:light_gray_concrete
fill 56 260 623 56 261 623 minecraft:light_gray_concrete
fill 56 260 625 56 261 625 minecraft:light_gray_concrete
fill 57 260 614 57 261 614 minecraft:light_gray_concrete
fill 57 260 616 57 261 616 minecraft:light_gray_concrete
fill 57 260 618 57 261 618 minecraft:light_gray_concrete
fill 57 260 620 57 261 620 minecraft:light_gray_concrete
fill 57 260 622 57 261 622 minecraft:light_gray_concrete
fill 57 260 624 57 261 624 minecraft:light_gray_concrete
fill 78 260 605 78 261 605 minecraft:light_gray_concrete
fill 78 260 607 78 261 607 minecraft:light_gray_concrete
fill 78 260 609 78 261 609 minecraft:light_gray_concrete
fill 78 260 611 78 261 611 minecraft:light_gray_concrete
fill 78 260 613 78 261 613 minecraft:light_gray_concrete
fill 79 260 606 79 261 606 minecraft:light_gray_concrete
fill 79 260 608 79 261 608 minecraft:light_gray_concrete
fill 79 260 610 79 261 610 minecraft:light_gray_concrete
fill 79 260 612 79 261 612 minecraft:light_gray_concrete
fill 80 260 605 80 261 605 minecraft:light_gray_concrete
fill 80 260 607 80 261 607 minecraft:light_gray_concrete
fill 80 260 609 80 261 609 minecraft:light_gray_concrete
fill 80 260 611 80 261 611 minecraft:light_gray_concrete
fill 80 260 613 80 261 613 minecraft:light_gray_concrete
fill 81 260 606 81 261 606 minecraft:light_gray_concrete
fill 81 260 608 81 261 608 minecraft:light_gray_concrete
fill 81 260 610 81 261 610 minecraft:light_gray_concrete
fill 81 260 612 81 261 612 minecraft:light_gray_concrete
fill 82 260 605 82 261 605 minecraft:light_gray_concrete
fill 82 260 607 82 261 607 minecraft:light_gray_concrete
fill 82 260 609 82 261 609 minecraft:light_gray_concrete
fill 82 260 611 82 261 611 minecraft:light_gray_concrete
fill 82 260 613 82 261 613 minecraft:light_gray_concrete
fill 83 260 606 83 261 606 minecraft:light_gray_concrete
fill 83 260 608 83 261 608 minecraft:light_gray_concrete
fill 83 260 610 83 261 610 minecraft:light_gray_concrete
fill 83 260 612 83 261 612 minecraft:light_gray_concrete
fill 84 260 605 84 261 605 minecraft:light_gray_concrete
fill 84 260 607 84 261 607 minecraft:light_gray_concrete
fill 84 260 609 84 261 609 minecraft:light_gray_concrete
fill 84 260 611 84 261 611 minecraft:light_gray_concrete
fill 84 260 613 84 261 613 minecraft:light_gray_concrete
fill 85 260 606 85 261 606 minecraft:light_gray_concrete
fill 85 260 608 85 261 608 minecraft:light_gray_concrete
fill 85 260 610 85 261 610 minecraft:light_gray_concrete
fill 85 260 612 85 261 612 minecraft:light_gray_concrete
fill 86 260 605 86 261 605 minecraft:light_gray_concrete
fill 86 260 607 86 261 607 minecraft:light_gray_concrete
fill 86 260 609 86 261 609 minecraft:light_gray_concrete
fill 86 260 611 86 261 611 minecraft:light_gray_concrete
fill 86 260 613 86 261 613 minecraft:light_gray_concrete
fill 47 262 609 47 269 609 minecraft:gray_concrete
fill 47 262 617 47 269 617 minecraft:gray_concrete
fill 47 262 625 47 269 625 minecraft:gray_concrete
fill 47 262 633 47 269 633 minecraft:gray_concrete
fill 47 262 641 47 269 641 minecraft:gray_concrete
setblock 48 262 613 minecraft:sea_lantern
setblock 48 262 615 minecraft:sea_lantern
setblock 48 262 617 minecraft:sea_lantern
setblock 48 262 619 minecraft:sea_lantern
setblock 48 262 621 minecraft:sea_lantern
setblock 48 262 623 minecraft:sea_lantern
setblock 48 262 625 minecraft:sea_lantern
setblock 49 262 614 minecraft:sea_lantern
setblock 49 262 616 minecraft:sea_lantern
setblock 49 262 618 minecraft:sea_lantern
setblock 49 262 620 minecraft:sea_lantern
setblock 49 262 622 minecraft:sea_lantern
setblock 49 262 624 minecraft:sea_lantern
setblock 50 262 613 minecraft:sea_lantern
setblock 50 262 615 minecraft:sea_lantern
setblock 50 262 617 minecraft:sea_lantern
setblock 50 262 619 minecraft:sea_lantern
setblock 50 262 621 minecraft:sea_lantern
setblock 50 262 623 minecraft:sea_lantern
setblock 50 262 625 minecraft:sea_lantern
fill 50 262 646 50 269 646 minecraft:gray_concrete
setblock 51 262 614 minecraft:sea_lantern
setblock 51 262 616 minecraft:sea_lantern
setblock 51 262 618 minecraft:sea_lantern
setblock 51 262 620 minecraft:sea_lantern
setblock 51 262 622 minecraft:sea_lantern
setblock 51 262 624 minecraft:sea_lantern
setblock 52 262 613 minecraft:sea_lantern
setblock 52 262 615 minecraft:sea_lantern
setblock 52 262 617 minecraft:sea_lantern
setblock 52 262 619 minecraft:sea_lantern
setblock 52 262 621 minecraft:sea_lantern
setblock 52 262 623 minecraft:sea_lantern
setblock 52 262 625 minecraft:sea_lantern
setblock 53 262 614 minecraft:sea_lantern
setblock 53 262 616 minecraft:sea_lantern
setblock 53 262 618 minecraft:sea_lantern
setblock 53 262 620 minecraft:sea_lantern
setblock 53 262 622 minecraft:sea_lantern
setblock 53 262 624 minecraft:sea_lantern
fill 54 262 604 54 269 604 minecraft:gray_concrete
setblock 54 262 613 minecraft:sea_lantern
setblock 54 262 615 minecraft:sea_lantern
setblock 54 262 617 minecraft:sea_lantern
setblock 54 262 619 minecraft:sea_lantern
setblock 54 262 621 minecraft:sea_lantern
setblock 54 262 623 minecraft:sea_lantern
setblock 54 262 625 minecraft:sea_lantern
setblock 55 262 614 minecraft:sea_lantern
setblock 55 262 616 minecraft:sea_lantern
setblock 55 262 618 minecraft:sea_lantern
setblock 55 262 620 minecraft:sea_lantern
setblock 55 262 622 minecraft:sea_lantern
setblock 55 262 624 minecraft:sea_lantern
setblock 56 262 613 minecraft:sea_lantern
setblock 56 262 615 minecraft:sea_lantern
setblock 56 262 617 minecraft:sea_lantern
setblock 56 262 619 minecraft:sea_lantern
setblock 56 262 621 minecraft:sea_lantern
setblock 56 262 623 minecraft:sea_lantern
setblock 56 262 625 minecraft:sea_lantern
setblock 57 262 614 minecraft:sea_lantern
setblock 57 262 616 minecraft:sea_lantern
setblock 57 262 618 minecraft:sea_lantern
setblock 57 262 620 minecraft:sea_lantern
setblock 57 262 622 minecraft:sea_lantern
setblock 57 262 624 minecraft:sea_lantern
fill 58 262 646 58 269 646 minecraft:gray_concrete
fill 62 262 604 62 269 604 minecraft:gray_concrete
fill 66 262 646 66 269 646 minecraft:gray_concrete
fill 70 262 604 70 269 604 minecraft:gray_concrete
fill 74 262 646 74 269 646 minecraft:gray_concrete
fill 78 262 604 78 269 604 minecraft:gray_concrete
setblock 78 262 605 minecraft:sea_lantern
setblock 78 262 607 minecraft:sea_lantern
setblock 78 262 609 minecraft:sea_lantern
setblock 78 262 611 minecraft:sea_lantern
setblock 78 262 613 minecraft:sea_lantern
setblock 79 262 606 minecraft:sea_lantern
setblock 79 262 608 minecraft:sea_lantern
setblock 79 262 610 minecraft:sea_lantern
setblock 79 262 612 minecraft:sea_lantern
setblock 80 262 605 minecraft:sea_lantern
setblock 80 262 607 minecraft:sea_lantern
setblock 80 262 609 minecraft:sea_lantern
setblock 80 262 611 minecraft:sea_lantern
setblock 80 262 613 minecraft:sea_lantern
setblock 81 262 606 minecraft:sea_lantern
setblock 81 262 608 minecraft:sea_lantern
setblock 81 262 610 minecraft:sea_lantern
setblock 81 262 612 minecraft:sea_lantern
setblock 82 262 605 minecraft:sea_lantern
setblock 82 262 607 minecraft:sea_lantern
setblock 82 262 609 minecraft:sea_lantern
setblock 82 262 611 minecraft:sea_lantern
setblock 82 262 613 minecraft:sea_lantern
fill 82 262 646 82 269 646 minecraft:gray_concrete
setblock 83 262 606 minecraft:sea_lantern
setblock 83 262 608 minecraft:sea_lantern
setblock 83 262 610 minecraft:sea_lantern
setblock 83 262 612 minecraft:sea_lantern
setblock 84 262 605 minecraft:sea_lantern
setblock 84 262 607 minecraft:sea_lantern
setblock 84 262 609 minecraft:sea_lantern
setblock 84 262 611 minecraft:sea_lantern
setblock 84 262 613 minecraft:sea_lantern
setblock 85 262 606 minecraft:sea_lantern
setblock 85 262 608 minecraft:sea_lantern
setblock 85 262 610 minecraft:sea_lantern
setblock 85 262 612 minecraft:sea_lantern
fill 86 262 604 86 269 604 minecraft:gray_concrete
setblock 86 262 605 minecraft:sea_lantern
setblock 86 262 607 minecraft:sea_lantern
setblock 86 262 609 minecraft:sea_lantern
setblock 86 262 611 minecraft:sea_lantern
setblock 86 262 613 minecraft:sea_lantern
fill 89 262 609 89 269 609 minecraft:gray_concrete
fill 89 262 617 89 269 617 minecraft:gray_concrete
fill 89 262 625 89 269 625 minecraft:gray_concrete
fill 89 262 633 89 269 633 minecraft:gray_concrete
fill 89 262 641 89 269 641 minecraft:gray_concrete
fill 48 263 613 48 264 613 minecraft:light_gray_concrete
fill 48 263 615 48 264 615 minecraft:light_gray_concrete
fill 48 263 617 48 264 617 minecraft:light_gray_concrete
fill 48 263 619 48 264 619 minecraft:light_gray_concrete
fill 48 263 621 48 264 621 minecraft:light_gray_concrete
fill 48 263 623 48 264 623 minecraft:light_gray_concrete
fill 48 263 625 48 264 625 minecraft:light_gray_concrete
fill 49 263 614 49 264 614 minecraft:light_gray_concrete
fill 49 263 616 49 264 616 minecraft:light_gray_concrete
fill 49 263 618 49 264 618 minecraft:light_gray_concrete
fill 49 263 620 49 264 620 minecraft:light_gray_concrete
fill 49 263 622 49 264 622 minecraft:light_gray_concrete
fill 49 263 624 49 264 624 minecraft:light_gray_concrete
fill 50 263 613 50 264 613 minecraft:light_gray_concrete
fill 50 263 615 50 264 615 minecraft:light_gray_concrete
fill 50 263 617 50 264 617 minecraft:light_gray_concrete
fill 50 263 619 50 264 619 minecraft:light_gray_concrete
fill 50 263 621 50 264 621 minecraft:light_gray_concrete
fill 50 263 623 50 264 623 minecraft:light_gray_concrete
fill 50 263 625 50 264 625 minecraft:light_gray_concrete
fill 51 263 614 51 264 614 minecraft:light_gray_concrete
schedule function dropper:buildpart/145_4 1t
