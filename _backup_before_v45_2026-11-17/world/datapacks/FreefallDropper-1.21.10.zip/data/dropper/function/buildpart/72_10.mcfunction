setblock 31 257 363 minecraft:yellow_terracotta
fill 32 257 323 35 257 323 minecraft:honeycomb_block
setblock 32 257 362 minecraft:yellow_terracotta
fill 32 257 363 32 260 363 minecraft:honeycomb_block
fill 33 257 362 33 259 362 minecraft:honeycomb_block
setblock 35 257 324 minecraft:yellow_terracotta
setblock 36 257 323 minecraft:yellow_terracotta
fill 36 257 324 36 260 324 minecraft:honeycomb_block
setblock 36 257 363 minecraft:yellow_terracotta
fill 37 257 323 37 260 323 minecraft:honeycomb_block
fill 37 257 340 37 257 341 minecraft:honeycomb_block
setblock 37 257 342 minecraft:yellow_terracotta
fill 37 257 343 37 258 344 minecraft:honeycomb_block
setblock 37 257 362 minecraft:yellow_terracotta
fill 37 257 363 37 260 363 minecraft:honeycomb_block
setblock 38 257 337 minecraft:honeycomb_block
setblock 38 257 341 minecraft:yellow_terracotta
fill 38 257 342 38 260 342 minecraft:honeycomb_block
setblock 38 257 346 minecraft:yellow_terracotta
fill 38 257 347 38 259 347 minecraft:honeycomb_block
setblock 38 257 361 minecraft:yellow_terracotta
fill 38 257 362 38 259 362 minecraft:honeycomb_block
setblock 39 257 334 minecraft:honeycomb_block
setblock 39 257 335 minecraft:yellow_terracotta
fill 39 257 336 39 258 336 minecraft:honeycomb_block
setblock 39 257 340 minecraft:yellow_terracotta
fill 39 257 341 39 260 341 minecraft:honeycomb_block
setblock 39 257 345 minecraft:yellow_terracotta
fill 39 257 346 39 260 346 minecraft:honeycomb_block
setblock 39 257 361 minecraft:honeycomb_block
setblock 40 257 323 minecraft:honeycomb_block
setblock 40 257 324 minecraft:yellow_terracotta
fill 40 257 325 40 257 328 minecraft:honeycomb_block
setblock 40 257 329 minecraft:yellow_terracotta
fill 40 257 330 40 258 330 minecraft:honeycomb_block
setblock 40 257 334 minecraft:yellow_terracotta
fill 40 257 335 40 260 335 minecraft:honeycomb_block
setblock 40 257 339 minecraft:yellow_terracotta
fill 40 257 340 40 260 340 minecraft:honeycomb_block
setblock 40 257 344 minecraft:yellow_terracotta
fill 40 257 345 40 260 345 minecraft:honeycomb_block
setblock 40 257 349 minecraft:yellow_terracotta
fill 40 257 350 40 259 350 minecraft:honeycomb_block
setblock 40 257 359 minecraft:yellow_terracotta
fill 40 257 360 40 258 360 minecraft:honeycomb_block
setblock 41 257 323 minecraft:yellow_terracotta
fill 41 257 324 41 260 324 minecraft:honeycomb_block
setblock 41 257 328 minecraft:yellow_terracotta
fill 41 257 329 41 260 329 minecraft:honeycomb_block
setblock 41 257 333 minecraft:yellow_terracotta
fill 41 257 334 41 260 334 minecraft:honeycomb_block
setblock 41 257 338 minecraft:yellow_terracotta
fill 41 257 339 41 260 339 minecraft:honeycomb_block
setblock 41 257 343 minecraft:yellow_terracotta
fill 41 257 344 41 260 344 minecraft:honeycomb_block
setblock 41 257 348 minecraft:yellow_terracotta
fill 41 257 349 41 260 349 minecraft:honeycomb_block
setblock 41 257 353 minecraft:yellow_terracotta
setblock 41 257 354 minecraft:honeycomb_block
setblock 41 257 358 minecraft:yellow_terracotta
fill 41 257 359 41 258 359 minecraft:honeycomb_block
setblock 41 257 363 minecraft:yellow_terracotta
fill 1 258 323 1 261 323 minecraft:honeycomb_block
setblock 1 258 327 minecraft:yellow_terracotta
fill 1 258 328 1 261 328 minecraft:honeycomb_block
setblock 1 258 332 minecraft:yellow_terracotta
fill 1 258 333 1 260 333 minecraft:honeycomb_block
setblock 1 258 337 minecraft:yellow_terracotta
fill 1 258 338 1 261 338 minecraft:honeycomb_block
setblock 1 258 342 minecraft:yellow_terracotta
fill 1 258 343 1 261 343 minecraft:honeycomb_block
setblock 1 258 347 minecraft:yellow_terracotta
fill 1 258 348 1 260 348 minecraft:honeycomb_block
setblock 1 258 357 minecraft:brown_terracotta
setblock 1 258 358 minecraft:honeycomb_block
setblock 1 258 362 minecraft:yellow_terracotta
fill 1 258 363 1 261 363 minecraft:honeycomb_block
setblock 2 258 326 minecraft:yellow_terracotta
fill 2 258 327 2 261 327 minecraft:honeycomb_block
fill 2 258 336 2 259 336 minecraft:yellow_terracotta
setblock 2 258 337 minecraft:honeycomb_block
setblock 2 258 341 minecraft:yellow_terracotta
fill 2 258 342 2 259 342 minecraft:honeycomb_block
setblock 2 258 362 minecraft:honeycomb_block
fill 3 258 325 3 259 325 minecraft:yellow_terracotta
setblock 4 258 324 minecraft:yellow_terracotta
setblock 4 258 363 minecraft:honeycomb_block
setblock 5 258 323 minecraft:yellow_terracotta
fill 5 258 324 8 258 324 minecraft:honeycomb_block
setblock 5 258 363 minecraft:yellow_terracotta
fill 6 258 323 6 261 323 minecraft:honeycomb_block
setblock 6 258 328 minecraft:ochre_froglight
setblock 6 258 334 minecraft:ochre_froglight
setblock 6 258 340 minecraft:ochre_froglight
setblock 6 258 346 minecraft:ochre_froglight
setblock 6 258 352 minecraft:ochre_froglight
setblock 6 258 358 minecraft:ochre_froglight
fill 6 258 363 6 261 363 minecraft:honeycomb_block
setblock 9 258 324 minecraft:yellow_terracotta
setblock 10 258 323 minecraft:yellow_terracotta
fill 10 258 324 13 258 324 minecraft:honeycomb_block
setblock 10 258 363 minecraft:yellow_terracotta
fill 11 258 323 11 261 323 minecraft:honeycomb_block
setblock 11 258 362 minecraft:yellow_terracotta
fill 11 258 363 11 261 363 minecraft:honeycomb_block
setblock 12 258 325 minecraft:honeycomb_block
setblock 12 258 328 minecraft:ochre_froglight
setblock 12 258 358 minecraft:ochre_froglight
fill 12 258 361 12 259 361 minecraft:yellow_terracotta
fill 12 258 362 12 261 362 minecraft:honeycomb_block
setblock 13 258 325 minecraft:yellow_terracotta
fill 13 258 361 13 260 361 minecraft:honeycomb_block
setblock 14 258 324 minecraft:yellow_terracotta
fill 14 258 325 17 258 325 minecraft:honeycomb_block
setblock 15 258 323 minecraft:yellow_terracotta
fill 15 258 324 15 261 324 minecraft:honeycomb_block
setblock 15 258 363 minecraft:yellow_terracotta
fill 16 258 323 16 261 323 minecraft:honeycomb_block
setblock 16 258 362 minecraft:yellow_terracotta
fill 16 258 363 16 261 363 minecraft:honeycomb_block
setblock 17 258 361 minecraft:yellow_terracotta
fill 17 258 362 17 261 362 minecraft:honeycomb_block
setblock 18 258 325 minecraft:yellow_terracotta
setblock 18 258 328 minecraft:ochre_froglight
setblock 18 258 358 minecraft:ochre_froglight
fill 18 258 360 18 259 360 minecraft:yellow_terracotta
fill 18 258 361 18 261 361 minecraft:honeycomb_block
setblock 19 258 324 minecraft:yellow_terracotta
fill 19 258 325 19 259 325 minecraft:honeycomb_block
setblock 19 258 360 minecraft:honeycomb_block
setblock 20 258 323 minecraft:yellow_terracotta
fill 20 258 324 20 261 324 minecraft:honeycomb_block
setblock 20 258 363 minecraft:yellow_terracotta
setblock 21 258 322 minecraft:orange_terracotta
fill 21 258 323 21 261 323 minecraft:honeycomb_block
setblock 21 258 362 minecraft:yellow_terracotta
fill 21 258 363 21 261 363 minecraft:honeycomb_block
setblock 22 258 361 minecraft:yellow_terracotta
fill 22 258 362 22 260 362 minecraft:honeycomb_block
setblock 23 258 361 minecraft:honeycomb_block
setblock 24 258 328 minecraft:ochre_froglight
setblock 24 258 358 minecraft:ochre_froglight
fill 24 258 364 24 308 364 minecraft:honeycomb_block
setblock 25 258 323 minecraft:yellow_terracotta
setblock 25 258 363 minecraft:yellow_terracotta
setblock 26 258 323 minecraft:honeycomb_block
fill 26 258 362 26 259 362 minecraft:yellow_terracotta
fill 26 258 363 29 258 363 minecraft:honeycomb_block
setblock 27 258 351 minecraft:flowering_azalea_leaves[persistent=true]
setblock 27 258 354 minecraft:flowering_azalea_leaves[persistent=true]
setblock 27 258 362 minecraft:honeycomb_block
setblock 29 258 322 minecraft:orange_terracotta
setblock 29 258 350 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 258 328 minecraft:ochre_froglight
setblock 30 258 354 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 258 358 minecraft:ochre_froglight
setblock 30 258 362 minecraft:honeycomb_block
setblock 30 258 363 minecraft:yellow_terracotta
fill 31 258 323 34 258 323 minecraft:honeycomb_block
setblock 31 258 352 minecraft:flowering_azalea_leaves[persistent=true]
fill 31 258 362 31 259 362 minecraft:yellow_terracotta
fill 31 258 363 31 261 363 minecraft:honeycomb_block
fill 32 258 362 32 259 362 minecraft:honeycomb_block
setblock 35 258 323 minecraft:yellow_terracotta
fill 35 258 324 35 261 324 minecraft:honeycomb_block
setblock 35 258 363 minecraft:yellow_terracotta
fill 36 258 323 36 261 323 minecraft:honeycomb_block
setblock 36 258 328 minecraft:ochre_froglight
setblock 36 258 334 minecraft:ochre_froglight
setblock 36 258 340 minecraft:ochre_froglight
setblock 36 258 346 minecraft:ochre_froglight
setblock 36 258 352 minecraft:ochre_froglight
setblock 36 258 358 minecraft:ochre_froglight
setblock 36 258 362 minecraft:yellow_terracotta
fill 36 258 363 36 261 363 minecraft:honeycomb_block
fill 37 258 341 37 259 341 minecraft:yellow_terracotta
setblock 37 258 342 minecraft:honeycomb_block
fill 37 258 362 37 260 362 minecraft:honeycomb_block
setblock 38 258 324 minecraft:honeycomb_block
setblock 38 258 340 minecraft:yellow_terracotta
fill 38 258 341 38 260 341 minecraft:honeycomb_block
setblock 38 258 345 minecraft:yellow_terracotta
fill 38 258 346 38 260 346 minecraft:honeycomb_block
setblock 39 258 324 minecraft:yellow_terracotta
setblock 39 258 335 minecraft:honeycomb_block
setblock 39 258 339 minecraft:yellow_terracotta
fill 39 258 340 39 261 340 minecraft:honeycomb_block
setblock 39 258 344 minecraft:yellow_terracotta
fill 39 258 345 39 261 345 minecraft:honeycomb_block
setblock 39 258 348 minecraft:honeycomb_block
fill 39 258 349 39 259 349 minecraft:yellow_terracotta
setblock 40 258 323 minecraft:yellow_terracotta
fill 40 258 324 40 258 327 minecraft:honeycomb_block
setblock 40 258 328 minecraft:yellow_terracotta
fill 40 258 329 40 259 329 minecraft:honeycomb_block
setblock 40 258 333 minecraft:yellow_terracotta
fill 40 258 334 40 259 334 minecraft:honeycomb_block
setblock 40 258 338 minecraft:yellow_terracotta
fill 40 258 339 40 261 339 minecraft:honeycomb_block
setblock 40 258 343 minecraft:yellow_terracotta
fill 40 258 344 40 261 344 minecraft:honeycomb_block
setblock 40 258 348 minecraft:yellow_terracotta
fill 40 258 349 40 261 349 minecraft:honeycomb_block
setblock 40 258 357 minecraft:brown_terracotta
setblock 40 258 363 minecraft:yellow_terracotta
fill 40 258 364 40 286 364 minecraft:honeycomb_block
fill 41 258 323 41 261 323 minecraft:honeycomb_block
setblock 41 258 327 minecraft:yellow_terracotta
fill 41 258 328 41 261 328 minecraft:honeycomb_block
setblock 41 258 332 minecraft:yellow_terracotta
fill 41 258 333 41 261 333 minecraft:honeycomb_block
setblock 41 258 337 minecraft:yellow_terracotta
fill 41 258 338 41 261 338 minecraft:honeycomb_block
setblock 41 258 342 minecraft:yellow_terracotta
fill 41 258 343 41 261 343 minecraft:honeycomb_block
setblock 41 258 347 minecraft:yellow_terracotta
fill 41 258 348 41 261 348 minecraft:honeycomb_block
fill 41 258 352 41 259 352 minecraft:yellow_terracotta
setblock 41 258 353 minecraft:honeycomb_block
fill 41 258 357 41 259 357 minecraft:yellow_terracotta
setblock 41 258 358 minecraft:honeycomb_block
setblock 41 258 362 minecraft:yellow_terracotta
fill 41 258 363 41 260 363 minecraft:honeycomb_block
fill 42 258 352 42 308 352 minecraft:honeycomb_block
setblock 1 259 326 minecraft:yellow_terracotta
fill 1 259 327 1 262 327 minecraft:honeycomb_block
fill 1 259 331 6 259 331 minecraft:yellow_terracotta
fill 1 259 332 1 261 332 minecraft:honeycomb_block
setblock 1 259 336 minecraft:yellow_terracotta
fill 1 259 337 1 260 337 minecraft:honeycomb_block
setblock 1 259 341 minecraft:yellow_terracotta
fill 1 259 342 1 262 342 minecraft:honeycomb_block
fill 1 259 346 6 259 346 minecraft:yellow_terracotta
fill 1 259 347 1 261 347 minecraft:honeycomb_block
fill 1 259 349 6 259 349 minecraft:yellow_terracotta
setblock 1 259 350 minecraft:honey_block
fill 1 259 351 6 259 359 minecraft:yellow_terracotta
fill 1 259 361 11 259 361 minecraft:yellow_terracotta
fill 1 259 362 1 261 362 minecraft:honeycomb_block
setblock 2 259 325 minecraft:yellow_terracotta
fill 2 259 326 2 262 326 minecraft:honeycomb_block
fill 2 259 330 6 259 330 minecraft:yellow_terracotta
fill 2 259 332 6 259 335 minecraft:yellow_terracotta
fill 2 259 337 6 259 337 minecraft:yellow_terracotta
fill 2 259 340 6 259 340 minecraft:yellow_terracotta
setblock 2 259 341 minecraft:honeycomb_block
fill 2 259 345 6 259 345 minecraft:yellow_terracotta
fill 2 259 347 6 259 348 minecraft:yellow_terracotta
fill 2 259 350 6 259 350 minecraft:yellow_terracotta
fill 2 259 360 17 259 360 minecraft:yellow_terracotta
fill 2 259 362 8 259 362 minecraft:yellow_terracotta
setblock 3 259 324 minecraft:yellow_terracotta
fill 3 259 326 6 259 329 minecraft:yellow_terracotta
fill 3 259 336 6 259 336 minecraft:yellow_terracotta
fill 3 259 338 6 259 339 minecraft:yellow_terracotta
fill 3 259 341 6 259 344 minecraft:yellow_terracotta
setblock 4 259 323 minecraft:yellow_terracotta
fill 4 259 324 7 259 324 minecraft:honeycomb_block
fill 4 259 325 12 259 325 minecraft:yellow_terracotta
setblock 4 259 363 minecraft:yellow_terracotta
fill 5 259 323 5 262 323 minecraft:honeycomb_block
fill 5 259 363 5 261 363 minecraft:honeycomb_block
fill 7 259 326 39 259 328 minecraft:yellow_terracotta
fill 7 259 358 41 259 359 minecraft:yellow_terracotta
setblock 8 259 324 minecraft:yellow_terracotta
setblock 9 259 323 minecraft:yellow_terracotta
fill 9 259 324 12 259 324 minecraft:honeycomb_block
setblock 9 259 363 minecraft:yellow_terracotta
fill 10 259 323 10 262 323 minecraft:honeycomb_block
setblock 10 259 362 minecraft:yellow_terracotta
fill 10 259 363 10 262 363 minecraft:honeycomb_block
fill 11 259 362 11 262 362 minecraft:honeycomb_block
setblock 13 259 324 minecraft:yellow_terracotta
fill 13 259 325 16 259 325 minecraft:honeycomb_block
setblock 14 259 323 minecraft:yellow_terracotta
fill 14 259 324 14 262 324 minecraft:honeycomb_block
setblock 14 259 363 minecraft:yellow_terracotta
fill 15 259 323 15 262 323 minecraft:honeycomb_block
setblock 15 259 362 minecraft:yellow_terracotta
fill 15 259 363 15 262 363 minecraft:honeycomb_block
setblock 16 259 361 minecraft:yellow_terracotta
fill 16 259 362 16 262 362 minecraft:honeycomb_block
setblock 17 259 325 minecraft:yellow_terracotta
fill 17 259 361 17 261 361 minecraft:honeycomb_block
setblock 18 259 324 minecraft:yellow_terracotta
fill 18 259 325 18 260 325 minecraft:honeycomb_block
setblock 19 259 323 minecraft:yellow_terracotta
fill 19 259 324 19 262 324 minecraft:honeycomb_block
fill 19 259 360 40 259 360 minecraft:yellow_terracotta
setblock 19 259 363 minecraft:yellow_terracotta
fill 20 259 323 20 262 323 minecraft:honeycomb_block
fill 20 259 325 39 259 325 minecraft:yellow_terracotta
setblock 20 259 362 minecraft:yellow_terracotta
fill 20 259 363 20 262 363 minecraft:honeycomb_block
fill 21 259 322 21 281 322 minecraft:honeycomb_block
setblock 21 259 361 minecraft:yellow_terracotta
fill 21 259 362 21 261 362 minecraft:honeycomb_block
setblock 22 259 361 minecraft:honeycomb_block
fill 23 259 324 33 259 324 minecraft:yellow_terracotta
fill 23 259 361 41 259 361 minecraft:yellow_terracotta
setblock 24 259 323 minecraft:yellow_terracotta
setblock 24 259 363 minecraft:yellow_terracotta
setblock 25 259 323 minecraft:honeycomb_block
setblock 25 259 362 minecraft:yellow_terracotta
fill 25 259 363 28 259 363 minecraft:honeycomb_block
fill 26 259 323 28 259 323 minecraft:yellow_terracotta
fill 27 259 362 30 259 362 minecraft:yellow_terracotta
setblock 28 259 364 minecraft:yellow_concrete
setblock 29 259 322 minecraft:yellow_concrete
setblock 29 259 323 minecraft:honey_block
setblock 29 259 363 minecraft:yellow_terracotta
setblock 30 259 323 minecraft:yellow_terracotta
fill 30 259 363 30 261 363 minecraft:honeycomb_block
fill 31 259 323 33 259 323 minecraft:honeycomb_block
fill 32 259 339 32 260 339 minecraft:black_concrete
setblock 34 259 323 minecraft:yellow_terracotta
fill 34 259 324 34 262 324 minecraft:honeycomb_block
setblock 34 259 363 minecraft:yellow_terracotta
fill 35 259 323 35 262 323 minecraft:honeycomb_block
setblock 35 259 362 minecraft:yellow_terracotta
fill 35 259 363 35 262 363 minecraft:honeycomb_block
fill 36 259 329 36 259 357 minecraft:yellow_terracotta
fill 36 259 362 36 260 362 minecraft:honeycomb_block
fill 37 259 329 37 259 340 minecraft:yellow_terracotta
fill 37 259 342 37 259 357 minecraft:yellow_terracotta
setblock 38 259 324 minecraft:yellow_terracotta
fill 38 259 329 38 259 339 minecraft:yellow_terracotta
setblock 38 259 340 minecraft:honeycomb_block
setblock 38 259 344 minecraft:yellow_terracotta
fill 38 259 345 38 261 345 minecraft:honeycomb_block
fill 38 259 348 38 259 357 minecraft:yellow_terracotta
setblock 39 259 323 minecraft:yellow_terracotta
fill 39 259 324 40 261 324 minecraft:honeycomb_block
fill 39 259 329 39 259 336 minecraft:yellow_terracotta
setblock 39 259 338 minecraft:yellow_terracotta
fill 39 259 339 39 260 339 minecraft:honeycomb_block
setblock 39 259 343 minecraft:yellow_terracotta
fill 39 259 344 39 262 344 minecraft:honeycomb_block
setblock 39 259 348 minecraft:yellow_terracotta
fill 39 259 350 39 259 357 minecraft:yellow_terracotta
setblock 39 259 363 minecraft:yellow_terracotta
fill 40 259 323 40 262 323 minecraft:honeycomb_block
fill 40 259 325 40 259 326 minecraft:honeycomb_block
setblock 40 259 327 minecraft:yellow_terracotta
fill 40 259 328 40 262 328 minecraft:honeycomb_block
fill 40 259 330 40 259 332 minecraft:yellow_terracotta
setblock 40 259 333 minecraft:honeycomb_block
setblock 40 259 337 minecraft:yellow_terracotta
fill 40 259 338 40 261 338 minecraft:honeycomb_block
setblock 40 259 342 minecraft:yellow_terracotta
fill 40 259 343 40 262 343 minecraft:honeycomb_block
setblock 40 259 347 minecraft:yellow_terracotta
fill 40 259 348 40 262 348 minecraft:honeycomb_block
fill 40 259 351 40 259 357 minecraft:yellow_terracotta
setblock 40 259 362 minecraft:yellow_terracotta
fill 40 259 363 40 261 363 minecraft:honeycomb_block
setblock 41 259 326 minecraft:yellow_terracotta
fill 41 259 327 41 262 327 minecraft:honeycomb_block
setblock 41 259 331 minecraft:yellow_terracotta
fill 41 259 332 41 262 332 minecraft:honeycomb_block
setblock 41 259 336 minecraft:yellow_terracotta
fill 41 259 337 41 262 337 minecraft:honeycomb_block
setblock 41 259 341 minecraft:yellow_terracotta
fill 41 259 342 41 262 342 minecraft:honeycomb_block
setblock 41 259 346 minecraft:yellow_terracotta
fill 41 259 347 41 262 347 minecraft:honeycomb_block
setblock 41 259 351 minecraft:yellow_terracotta
fill 41 259 353 41 259 354 minecraft:yellow_terracotta
setblock 41 259 355 minecraft:honey_block
setblock 41 259 356 minecraft:yellow_terracotta
fill 41 259 362 41 260 362 minecraft:honeycomb_block
setblock 42 259 328 minecraft:orange_terracotta
setblock 1 260 325 minecraft:yellow_terracotta
fill 1 260 326 1 263 326 minecraft:honeycomb_block
setblock 1 260 330 minecraft:yellow_terracotta
fill 1 260 331 1 263 331 minecraft:honeycomb_block
setblock 1 260 335 minecraft:yellow_terracotta
setblock 1 260 336 minecraft:honeycomb_block
setblock 1 260 340 minecraft:yellow_terracotta
fill 1 260 341 1 261 341 minecraft:honeycomb_block
setblock 1 260 345 minecraft:yellow_terracotta
fill 1 260 346 1 262 346 minecraft:honeycomb_block
setblock 1 260 356 minecraft:honey_block
setblock 1 260 361 minecraft:honeycomb_block
setblock 2 260 324 minecraft:yellow_terracotta
fill 2 260 325 2 263 325 minecraft:honeycomb_block
setblock 3 260 323 minecraft:yellow_terracotta
fill 3 260 324 6 260 324 minecraft:honeycomb_block
setblock 3 260 325 minecraft:light[level=12]
setblock 3 260 332 minecraft:light[level=12]
setblock 3 260 339 minecraft:light[level=12]
setblock 3 260 346 minecraft:light[level=12]
setblock 3 260 353 minecraft:light[level=12]
setblock 3 260 360 minecraft:light[level=12]
setblock 3 260 363 minecraft:yellow_terracotta
fill 3 260 364 3 308 364 minecraft:honeycomb_block
fill 4 260 323 4 263 323 minecraft:honeycomb_block
fill 4 260 363 4 261 363 minecraft:honeycomb_block
fill 6 260 328 6 260 358 minecraft:honey_block
setblock 7 260 324 minecraft:yellow_terracotta
fill 7 260 328 36 260 328 minecraft:honey_block
fill 7 260 358 36 260 358 minecraft:honey_block
setblock 8 260 323 minecraft:yellow_terracotta
fill 8 260 324 11 260 324 minecraft:honeycomb_block
setblock 8 260 363 minecraft:yellow_terracotta
fill 9 260 323 9 263 323 minecraft:honeycomb_block
fill 9 260 363 9 263 363 minecraft:honeycomb_block
setblock 10 260 325 minecraft:light[level=12]
setblock 10 260 332 minecraft:light[level=12]
setblock 10 260 346 minecraft:light[level=12]
setblock 10 260 353 minecraft:light[level=12]
setblock 10 260 360 minecraft:light[level=12]
fill 10 260 362 10 261 362 minecraft:honeycomb_block
setblock 12 260 324 minecraft:yellow_terracotta
fill 12 260 325 15 260 325 minecraft:honeycomb_block
setblock 13 260 323 minecraft:yellow_terracotta
fill 13 260 324 13 263 324 minecraft:honeycomb_block
setblock 13 260 363 minecraft:yellow_terracotta
fill 14 260 323 14 263 323 minecraft:honeycomb_block
setblock 14 260 362 minecraft:yellow_terracotta
fill 14 260 363 14 263 363 minecraft:honeycomb_block
setblock 15 260 361 minecraft:yellow_terracotta
fill 15 260 362 15 263 362 minecraft:honeycomb_block
setblock 16 260 325 minecraft:yellow_terracotta
fill 16 260 361 16 262 361 minecraft:honeycomb_block
setblock 17 260 324 minecraft:yellow_terracotta
fill 17 260 325 17 261 325 minecraft:honeycomb_block
setblock 17 260 332 minecraft:light[level=12]
setblock 17 260 339 minecraft:light[level=12]
setblock 17 260 346 minecraft:light[level=12]
setblock 17 260 353 minecraft:light[level=12]
setblock 17 260 360 minecraft:light[level=12]
setblock 18 260 323 minecraft:yellow_terracotta
fill 18 260 324 18 263 324 minecraft:honeycomb_block
setblock 18 260 363 minecraft:yellow_terracotta
fill 19 260 323 19 263 323 minecraft:honeycomb_block
setblock 19 260 362 minecraft:yellow_terracotta
fill 19 260 363 19 263 363 minecraft:honeycomb_block
setblock 20 260 361 minecraft:yellow_terracotta
fill 20 260 362 20 262 362 minecraft:honeycomb_block
setblock 23 260 323 minecraft:yellow_terracotta
setblock 23 260 363 minecraft:yellow_terracotta
setblock 24 260 323 minecraft:honeycomb_block
setblock 24 260 325 minecraft:light[level=12]
setblock 24 260 332 minecraft:light[level=12]
setblock 24 260 339 minecraft:light[level=12]
setblock 24 260 346 minecraft:light[level=12]
setblock 24 260 353 minecraft:light[level=12]
setblock 24 260 360 minecraft:light[level=12]
fill 24 260 363 27 260 363 minecraft:honeycomb_block
setblock 28 260 363 minecraft:yellow_terracotta
fill 28 260 364 28 278 364 minecraft:honeycomb_block
fill 29 260 322 29 308 322 minecraft:honeycomb_block
setblock 29 260 363 minecraft:honeycomb_block
fill 31 260 323 32 260 323 minecraft:honeycomb_block
setblock 31 260 325 minecraft:light[level=12]
setblock 31 260 332 minecraft:light[level=12]
setblock 31 260 339 minecraft:light[level=12]
setblock 31 260 346 minecraft:light[level=12]
setblock 31 260 353 minecraft:light[level=12]
setblock 31 260 360 minecraft:light[level=12]
setblock 33 260 323 minecraft:yellow_terracotta
setblock 33 260 363 minecraft:yellow_terracotta
fill 34 260 323 34 263 323 minecraft:honeycomb_block
setblock 34 260 362 minecraft:yellow_terracotta
fill 34 260 363 34 263 363 minecraft:honeycomb_block
fill 35 260 360 35 267 360 minecraft:iron_block
setblock 35 260 362 minecraft:honeycomb_block
fill 36 260 329 36 260 357 minecraft:honey_block
setblock 37 260 324 minecraft:yellow_terracotta
setblock 38 260 323 minecraft:yellow_terracotta
fill 38 260 324 38 263 324 minecraft:honeycomb_block
setblock 38 260 325 minecraft:light[level=12]
setblock 38 260 332 minecraft:light[level=12]
setblock 38 260 339 minecraft:light[level=12]
setblock 38 260 343 minecraft:yellow_terracotta
fill 38 260 344 38 261 344 minecraft:honeycomb_block
setblock 38 260 353 minecraft:light[level=12]
setblock 38 260 360 minecraft:light[level=12]
setblock 38 260 363 minecraft:yellow_terracotta
fill 39 260 323 39 263 323 minecraft:honeycomb_block
setblock 39 260 338 minecraft:honeycomb_block
setblock 39 260 342 minecraft:yellow_terracotta
fill 39 260 343 39 262 343 minecraft:honeycomb_block
setblock 39 260 347 minecraft:yellow_terracotta
setblock 39 260 348 minecraft:honeycomb_block
fill 39 260 363 39 261 363 minecraft:honeycomb_block
setblock 40 260 325 minecraft:honeycomb_block
setblock 40 260 326 minecraft:yellow_terracotta
fill 40 260 327 40 263 327 minecraft:honeycomb_block
setblock 40 260 336 minecraft:yellow_terracotta
fill 40 260 337 40 261 337 minecraft:honeycomb_block
setblock 40 260 341 minecraft:yellow_terracotta
fill 40 260 342 40 263 342 minecraft:honeycomb_block
setblock 40 260 346 minecraft:yellow_terracotta
fill 40 260 347 40 263 347 minecraft:honeycomb_block
setblock 41 260 325 minecraft:yellow_terracotta
fill 41 260 326 41 263 326 minecraft:honeycomb_block
setblock 41 260 330 minecraft:yellow_terracotta
fill 41 260 331 41 263 331 minecraft:honeycomb_block
setblock 41 260 335 minecraft:yellow_terracotta
fill 41 260 336 41 262 336 minecraft:honeycomb_block
setblock 41 260 340 minecraft:yellow_terracotta
fill 41 260 341 41 263 341 minecraft:honeycomb_block
setblock 41 260 345 minecraft:yellow_terracotta
fill 41 260 346 41 263 346 minecraft:honeycomb_block
setblock 41 260 350 minecraft:yellow_terracotta
setblock 41 260 351 minecraft:honeycomb_block
fill 42 260 328 42 281 328 minecraft:honeycomb_block
setblock 42 260 356 minecraft:orange_terracotta
setblock 0 261 341 minecraft:yellow_terracotta
setblock 1 261 324 minecraft:yellow_terracotta
fill 1 261 325 1 264 325 minecraft:honeycomb_block
setblock 1 261 329 minecraft:yellow_terracotta
fill 1 261 330 1 264 330 minecraft:honeycomb_block
setblock 1 261 339 minecraft:yellow_terracotta
setblock 1 261 340 minecraft:honeycomb_block
setblock 1 261 344 minecraft:yellow_terracotta
fill 1 261 345 1 262 345 minecraft:honeycomb_block
setblock 2 261 323 minecraft:yellow_terracotta
fill 2 261 324 5 261 324 minecraft:honeycomb_block
setblock 2 261 328 minecraft:yellow_terracotta
setblock 2 261 363 minecraft:yellow_terracotta
fill 3 261 323 3 264 323 minecraft:honeycomb_block
setblock 3 261 363 minecraft:honeycomb_block
setblock 6 261 324 minecraft:yellow_terracotta
setblock 7 261 323 minecraft:yellow_terracotta
fill 7 261 324 10 261 324 minecraft:honeycomb_block
setblock 7 261 363 minecraft:yellow_terracotta
fill 8 261 323 8 264 323 minecraft:honeycomb_block
fill 8 261 363 8 264 363 minecraft:honeycomb_block
fill 10 261 340 11 262 340 minecraft:yellow_concrete
setblock 11 261 324 minecraft:yellow_terracotta
fill 11 261 325 14 261 325 minecraft:honeycomb_block
setblock 12 261 323 minecraft:yellow_terracotta
fill 12 261 324 12 264 324 minecraft:honeycomb_block
setblock 12 261 363 minecraft:yellow_terracotta
fill 13 261 323 13 264 323 minecraft:honeycomb_block
setblock 13 261 362 minecraft:yellow_terracotta
fill 13 261 363 13 264 363 minecraft:honeycomb_block
setblock 14 261 361 minecraft:yellow_terracotta
fill 14 261 362 14 264 362 minecraft:honeycomb_block
setblock 15 261 325 minecraft:yellow_terracotta
fill 15 261 361 15 262 361 minecraft:honeycomb_block
setblock 16 261 324 minecraft:yellow_terracotta
fill 16 261 325 16 263 325 minecraft:honeycomb_block
setblock 17 261 323 minecraft:yellow_terracotta
fill 17 261 324 17 264 324 minecraft:honeycomb_block
setblock 17 261 363 minecraft:yellow_terracotta
fill 18 261 323 18 264 323 minecraft:honeycomb_block
setblock 18 261 362 minecraft:yellow_terracotta
fill 18 261 363 18 264 363 minecraft:honeycomb_block
fill 19 261 362 19 263 362 minecraft:honeycomb_block
setblock 22 261 323 minecraft:yellow_terracotta
setblock 22 261 363 minecraft:yellow_terracotta
setblock 23 261 323 minecraft:honeycomb_block
fill 23 261 363 25 261 363 minecraft:honeycomb_block
setblock 31 261 323 minecraft:honeycomb_block
setblock 32 261 323 minecraft:yellow_terracotta
setblock 32 261 363 minecraft:yellow_terracotta
fill 33 261 323 33 264 323 minecraft:honeycomb_block
fill 33 261 341 33 262 341 minecraft:black_concrete
fill 33 261 363 33 264 363 minecraft:honeycomb_block
setblock 36 261 324 minecraft:yellow_terracotta
setblock 37 261 323 minecraft:yellow_terracotta
fill 37 261 324 37 264 324 minecraft:honeycomb_block
setblock 37 261 363 minecraft:yellow_terracotta
fill 38 261 323 38 264 323 minecraft:honeycomb_block
setblock 38 261 343 minecraft:honeycomb_block
fill 38 261 363 38 262 363 minecraft:honeycomb_block
setblock 39 261 341 minecraft:yellow_terracotta
fill 39 261 342 39 262 342 minecraft:honeycomb_block
setblock 39 261 346 minecraft:yellow_terracotta
fill 39 261 347 39 262 347 minecraft:honeycomb_block
setblock 40 261 325 minecraft:yellow_terracotta
fill 40 261 326 40 264 326 minecraft:honeycomb_block
setblock 40 261 340 minecraft:yellow_terracotta
fill 40 261 341 40 263 341 minecraft:honeycomb_block
setblock 40 261 345 minecraft:yellow_terracotta
fill 40 261 346 40 264 346 minecraft:honeycomb_block
setblock 41 261 324 minecraft:yellow_terracotta
fill 41 261 325 41 264 325 minecraft:honeycomb_block
setblock 41 261 329 minecraft:yellow_terracotta
fill 41 261 330 41 264 330 minecraft:honeycomb_block
setblock 41 261 334 minecraft:yellow_terracotta
setblock 41 261 335 minecraft:honeycomb_block
setblock 41 261 339 minecraft:yellow_terracotta
fill 41 261 340 41 263 340 minecraft:honeycomb_block
setblock 41 261 344 minecraft:yellow_terracotta
fill 41 261 345 41 264 345 minecraft:honeycomb_block
setblock 41 261 349 minecraft:yellow_terracotta
setblock 41 261 350 minecraft:honeycomb_block
fill 42 261 356 42 278 356 minecraft:honeycomb_block
fill 0 262 341 0 268 341 minecraft:honeycomb_block
setblock 1 262 323 minecraft:yellow_terracotta
fill 1 262 324 4 262 324 minecraft:honeycomb_block
setblock 1 262 328 minecraft:yellow_terracotta
fill 1 262 329 1 265 329 minecraft:honeycomb_block
setblock 1 262 343 minecraft:yellow_terracotta
setblock 1 262 344 minecraft:honeycomb_block
setblock 1 262 349 minecraft:honey_block
setblock 1 262 363 minecraft:yellow_terracotta
fill 2 262 323 2 265 323 minecraft:honeycomb_block
setblock 2 262 327 minecraft:yellow_terracotta
setblock 5 262 324 minecraft:yellow_terracotta
setblock 6 262 323 minecraft:yellow_terracotta
fill 6 262 324 9 262 324 minecraft:honeycomb_block
setblock 6 262 363 minecraft:honey_block
fill 7 262 323 7 265 323 minecraft:honeycomb_block
fill 7 262 363 7 265 363 minecraft:honeycomb_block
setblock 10 262 324 minecraft:yellow_terracotta
setblock 11 262 323 minecraft:yellow_terracotta
fill 11 262 324 11 264 325 minecraft:honeycomb_block
setblock 11 262 363 minecraft:yellow_terracotta
fill 12 262 323 12 265 323 minecraft:honeycomb_block
fill 12 262 325 13 262 325 minecraft:honeycomb_block
setblock 12 262 362 minecraft:yellow_terracotta
fill 12 262 363 12 265 363 minecraft:honeycomb_block
fill 13 262 362 13 265 362 minecraft:honeycomb_block
setblock 14 262 325 minecraft:yellow_terracotta
setblock 15 262 324 minecraft:yellow_terracotta
fill 15 262 325 15 265 325 minecraft:honeycomb_block
setblock 16 262 323 minecraft:yellow_terracotta
fill 16 262 324 16 265 324 minecraft:honeycomb_block
setblock 16 262 363 minecraft:yellow_terracotta
fill 17 262 323 17 265 323 minecraft:honeycomb_block
setblock 17 262 362 minecraft:yellow_terracotta
fill 17 262 363 17 265 363 minecraft:honeycomb_block
fill 18 262 362 18 264 362 minecraft:honeycomb_block
setblock 21 262 323 minecraft:yellow_terracotta
setblock 21 262 363 minecraft:yellow_terracotta
setblock 22 262 323 minecraft:honeycomb_block
fill 22 262 363 23 262 363 minecraft:honeycomb_block
fill 26 262 340 28 263 341 minecraft:yellow_terracotta
fill 26 262 343 28 264 343 minecraft:yellow_terracotta
fill 27 262 325 27 269 325 minecraft:flowering_azalea_leaves[persistent=true]
fill 27 262 342 28 271 342 minecraft:yellow_terracotta
setblock 31 262 323 minecraft:yellow_terracotta
setblock 31 262 363 minecraft:yellow_terracotta
fill 32 262 323 32 265 323 minecraft:honeycomb_block
fill 32 262 363 32 263 363 minecraft:honeycomb_block
fill 33 262 324 33 263 324 minecraft:honeycomb_block
setblock 35 262 324 minecraft:yellow_terracotta
setblock 36 262 323 minecraft:yellow_terracotta
fill 36 262 324 36 265 324 minecraft:honeycomb_block
setblock 36 262 363 minecraft:yellow_terracotta
fill 37 262 323 37 265 323 minecraft:honeycomb_block
fill 37 262 363 37 263 363 minecraft:honeycomb_block
setblock 39 262 324 minecraft:honeycomb_block
setblock 39 262 345 minecraft:yellow_terracotta
setblock 39 262 346 minecraft:honeycomb_block
setblock 40 262 324 minecraft:yellow_terracotta
fill 40 262 325 40 265 325 minecraft:honeycomb_block
setblock 40 262 339 minecraft:yellow_terracotta
setblock 40 262 340 minecraft:honeycomb_block
setblock 40 262 344 minecraft:yellow_terracotta
fill 40 262 345 40 264 345 minecraft:honeycomb_block
setblock 41 262 323 minecraft:yellow_terracotta
fill 41 262 324 41 265 324 minecraft:honeycomb_block
setblock 41 262 328 minecraft:yellow_terracotta
fill 41 262 329 41 265 329 minecraft:honeycomb_block
setblock 41 262 338 minecraft:yellow_terracotta
fill 41 262 339 41 263 339 minecraft:honeycomb_block
setblock 41 262 343 minecraft:yellow_terracotta
fill 41 262 344 41 265 344 minecraft:honeycomb_block
setblock 41 262 348 minecraft:yellow_terracotta
fill 41 262 349 41 265 349 minecraft:honeycomb_block
setblock 41 262 362 minecraft:honey_block
fill 1 263 323 1 265 324 minecraft:honeycomb_block
setblock 1 263 327 minecraft:yellow_terracotta
fill 1 263 328 1 266 328 minecraft:honeycomb_block
setblock 1 263 355 minecraft:honey_block
setblock 2 263 322 minecraft:orange_terracotta
fill 2 263 324 3 263 324 minecraft:honeycomb_block
setblock 2 263 326 minecraft:yellow_terracotta
fill 2 263 327 2 266 327 minecraft:honeycomb_block
setblock 2 263 364 minecraft:yellow_terracotta
setblock 4 263 324 minecraft:yellow_terracotta
setblock 5 263 323 minecraft:yellow_terracotta
fill 5 263 324 8 263 324 minecraft:honeycomb_block
fill 6 263 323 6 266 323 minecraft:honeycomb_block
setblock 9 263 324 minecraft:yellow_terracotta
setblock 10 263 323 minecraft:yellow_terracotta
fill 10 263 324 10 266 324 minecraft:honeycomb_block
setblock 10 263 363 minecraft:yellow_terracotta
fill 11 263 323 11 266 323 minecraft:honeycomb_block
setblock 11 263 362 minecraft:yellow_terracotta
fill 11 263 363 11 266 363 minecraft:honeycomb_block
setblock 12 263 325 minecraft:honeycomb_block
fill 12 263 362 12 266 362 minecraft:honeycomb_block
setblock 13 263 325 minecraft:yellow_terracotta
setblock 14 263 324 minecraft:yellow_terracotta
fill 14 263 325 14 266 325 minecraft:honeycomb_block
setblock 15 263 323 minecraft:yellow_terracotta
fill 15 263 324 15 266 324 minecraft:honeycomb_block
setblock 15 263 363 minecraft:yellow_terracotta
fill 16 263 323 16 266 323 minecraft:honeycomb_block
setblock 16 263 362 minecraft:yellow_terracotta
fill 16 263 363 16 266 363 minecraft:honeycomb_block
fill 17 263 362 17 265 362 minecraft:honeycomb_block
setblock 19 263 324 minecraft:yellow_terracotta
setblock 20 263 323 minecraft:yellow_terracotta
setblock 20 263 363 minecraft:yellow_terracotta
setblock 21 263 323 minecraft:honeycomb_block
fill 21 263 363 22 263 363 minecraft:honeycomb_block
fill 24 263 323 24 264 323 minecraft:honey_block
setblock 28 263 322 minecraft:yellow_terracotta
setblock 30 263 323 minecraft:honey_block
fill 31 263 323 31 266 323 minecraft:honeycomb_block
setblock 34 263 324 minecraft:yellow_terracotta
setblock 35 263 323 minecraft:yellow_terracotta
fill 35 263 324 35 266 324 minecraft:honeycomb_block
setblock 35 263 363 minecraft:yellow_terracotta
fill 36 263 323 36 266 323 minecraft:honeycomb_block
setblock 36 263 363 minecraft:honeycomb_block
setblock 39 263 324 minecraft:yellow_terracotta
setblock 39 263 344 minecraft:yellow_terracotta
setblock 39 263 345 minecraft:honeycomb_block
setblock 40 263 323 minecraft:yellow_terracotta
setblock 40 263 324 minecraft:honeycomb_block
setblock 40 263 328 minecraft:yellow_terracotta
setblock 40 263 343 minecraft:yellow_terracotta
fill 40 263 344 40 264 344 minecraft:honeycomb_block
setblock 40 263 348 minecraft:yellow_terracotta
fill 41 263 323 41 266 323 minecraft:honeycomb_block
setblock 41 263 327 minecraft:yellow_terracotta
fill 41 263 328 41 266 328 minecraft:honeycomb_block
setblock 41 263 332 minecraft:yellow_terracotta
setblock 41 263 342 minecraft:yellow_terracotta
fill 41 263 343 41 266 343 minecraft:honeycomb_block
setblock 41 263 347 minecraft:yellow_terracotta
fill 41 263 348 41 266 348 minecraft:honeycomb_block
setblock 41 263 356 minecraft:honey_block
setblock 1 264 326 minecraft:yellow_terracotta
fill 1 264 327 1 267 327 minecraft:honeycomb_block
setblock 1 264 331 minecraft:yellow_terracotta
setblock 1 264 336 minecraft:honey_block
setblock 1 264 361 minecraft:honey_block
fill 2 264 322 2 301 322 minecraft:honeycomb_block
setblock 2 264 324 minecraft:honeycomb_block
setblock 2 264 325 minecraft:yellow_terracotta
fill 2 264 326 2 267 326 minecraft:honeycomb_block
fill 2 264 328 2 265 328 minecraft:honeycomb_block
fill 2 264 364 2 308 364 minecraft:honeycomb_block
setblock 3 264 324 minecraft:yellow_terracotta
setblock 3 264 325 minecraft:light[level=15]
setblock 3 264 333 minecraft:light[level=15]
setblock 3 264 341 minecraft:light[level=15]
setblock 3 264 349 minecraft:light[level=15]
setblock 3 264 357 minecraft:light[level=15]
setblock 4 264 323 minecraft:yellow_terracotta
fill 4 264 324 7 264 324 minecraft:honeycomb_block
fill 5 264 323 5 267 323 minecraft:honeycomb_block
setblock 8 264 324 minecraft:yellow_terracotta
setblock 9 264 323 minecraft:yellow_terracotta
fill 9 264 324 9 267 324 minecraft:honeycomb_block
setblock 9 264 363 minecraft:yellow_terracotta
fill 10 264 323 10 267 323 minecraft:honeycomb_block
fill 10 264 325 10 265 325 minecraft:honeycomb_block
setblock 10 264 362 minecraft:yellow_terracotta
fill 10 264 363 10 267 363 minecraft:honeycomb_block
setblock 11 264 333 minecraft:light[level=15]
setblock 11 264 341 minecraft:light[level=15]
setblock 11 264 349 minecraft:light[level=15]
setblock 11 264 357 minecraft:light[level=15]
fill 11 264 362 11 267 362 minecraft:honeycomb_block
setblock 12 264 325 minecraft:yellow_terracotta
setblock 13 264 324 minecraft:yellow_terracotta
fill 13 264 325 13 267 325 minecraft:honeycomb_block
setblock 14 264 323 minecraft:yellow_terracotta
fill 14 264 324 14 267 324 minecraft:honeycomb_block
setblock 14 264 363 minecraft:yellow_terracotta
fill 15 264 323 15 267 323 minecraft:honeycomb_block
setblock 15 264 362 minecraft:yellow_terracotta
fill 15 264 363 15 267 363 minecraft:honeycomb_block
fill 16 264 362 16 267 362 minecraft:honeycomb_block
setblock 18 264 324 minecraft:yellow_terracotta
setblock 19 264 323 minecraft:yellow_terracotta
setblock 19 264 325 minecraft:light[level=15]
setblock 19 264 333 minecraft:light[level=15]
setblock 19 264 341 minecraft:light[level=15]
setblock 19 264 349 minecraft:light[level=15]
setblock 19 264 357 minecraft:light[level=15]
setblock 19 264 363 minecraft:yellow_terracotta
setblock 20 264 323 minecraft:honeycomb_block
fill 20 264 363 21 264 363 minecraft:honeycomb_block
fill 26 264 340 28 271 340 minecraft:yellow_terracotta
setblock 27 264 333 minecraft:light[level=15]
fill 27 264 341 28 271 341 minecraft:yellow_terracotta
setblock 27 264 349 minecraft:light[level=15]
setblock 27 264 357 minecraft:light[level=15]
fill 28 264 322 28 308 322 minecraft:honeycomb_block
fill 30 264 323 30 267 323 minecraft:honeycomb_block
setblock 32 264 324 minecraft:honeycomb_block
setblock 33 264 324 minecraft:yellow_terracotta
setblock 34 264 322 minecraft:yellow_concrete
setblock 34 264 323 minecraft:yellow_terracotta
fill 34 264 324 34 267 324 minecraft:honeycomb_block
setblock 34 264 363 minecraft:yellow_terracotta
fill 35 264 323 35 267 323 minecraft:honeycomb_block
setblock 35 264 325 minecraft:light[level=15]
setblock 35 264 333 minecraft:light[level=15]
setblock 35 264 341 minecraft:light[level=15]
setblock 35 264 349 minecraft:light[level=15]
setblock 35 264 357 minecraft:light[level=15]
setblock 35 264 363 minecraft:honeycomb_block
setblock 38 264 324 minecraft:yellow_terracotta
setblock 39 264 323 minecraft:yellow_terracotta
fill 39 264 324 39 267 324 minecraft:honeycomb_block
fill 40 264 323 40 267 323 minecraft:honeycomb_block
setblock 40 264 327 minecraft:yellow_terracotta
fill 40 264 328 40 266 329 minecraft:honeycomb_block
setblock 40 264 343 minecraft:honeycomb_block
setblock 40 264 347 minecraft:yellow_terracotta
setblock 41 264 326 minecraft:yellow_terracotta
fill 41 264 327 41 267 327 minecraft:honeycomb_block
setblock 41 264 331 minecraft:yellow_terracotta
fill 41 264 332 41 267 332 minecraft:honeycomb_block
setblock 41 264 341 minecraft:yellow_terracotta
fill 41 264 342 41 265 342 minecraft:honeycomb_block
setblock 41 264 346 minecraft:yellow_terracotta
fill 41 264 347 41 267 347 minecraft:honeycomb_block
setblock 41 264 350 minecraft:honey_block
setblock 1 265 325 minecraft:yellow_terracotta
fill 1 265 326 1 268 326 minecraft:honeycomb_block
setblock 1 265 330 minecraft:yellow_terracotta
fill 1 265 331 1 267 332 minecraft:honeycomb_block
setblock 1 265 342 minecraft:honey_block
setblock 2 265 324 minecraft:yellow_terracotta
fill 2 265 325 2 268 325 minecraft:honeycomb_block
setblock 3 265 323 minecraft:yellow_terracotta
fill 3 265 324 6 265 324 minecraft:honeycomb_block
fill 4 265 323 4 268 323 minecraft:honeycomb_block
setblock 5 265 363 minecraft:honey_block
setblock 7 265 324 minecraft:yellow_terracotta
setblock 8 265 323 minecraft:yellow_terracotta
fill 8 265 324 8 268 324 minecraft:honeycomb_block
setblock 8 265 363 minecraft:yellow_terracotta
fill 9 265 323 9 268 323 minecraft:honeycomb_block
fill 9 265 325 9 266 325 minecraft:honeycomb_block
fill 9 265 363 9 268 363 minecraft:honeycomb_block
fill 10 265 362 10 268 362 minecraft:honeycomb_block
setblock 11 265 324 minecraft:honeycomb_block
setblock 11 265 325 minecraft:yellow_terracotta
setblock 12 265 324 minecraft:yellow_terracotta
fill 12 265 325 12 268 325 minecraft:honeycomb_block
setblock 13 265 323 minecraft:yellow_terracotta
fill 13 265 324 13 268 324 minecraft:honeycomb_block
setblock 13 265 363 minecraft:yellow_terracotta
fill 14 265 323 14 268 323 minecraft:honeycomb_block
setblock 14 265 362 minecraft:yellow_terracotta
fill 14 265 363 14 268 363 minecraft:honeycomb_block
fill 15 265 362 15 268 362 minecraft:honeycomb_block
setblock 17 265 324 minecraft:yellow_terracotta
setblock 18 265 323 minecraft:yellow_terracotta
setblock 18 265 363 minecraft:yellow_terracotta
fill 19 265 323 19 266 323 minecraft:honeycomb_block
fill 19 265 363 20 265 363 minecraft:honeycomb_block
setblock 24 265 363 minecraft:honey_block
setblock 25 265 322 minecraft:yellow_concrete
fill 27 265 343 28 271 343 minecraft:yellow_terracotta
fill 30 265 363 30 266 363 minecraft:honey_block
setblock 32 265 324 minecraft:yellow_terracotta
setblock 33 265 323 minecraft:yellow_terracotta
fill 33 265 324 33 268 324 minecraft:honeycomb_block
setblock 33 265 363 minecraft:yellow_terracotta
fill 34 265 322 34 268 323 minecraft:honeycomb_block
setblock 34 265 363 minecraft:honeycomb_block
setblock 37 265 324 minecraft:yellow_terracotta
setblock 38 265 323 minecraft:yellow_terracotta
fill 38 265 324 38 268 324 minecraft:honeycomb_block
fill 39 265 323 39 268 323 minecraft:honeycomb_block
setblock 40 265 326 minecraft:yellow_terracotta
fill 40 265 327 40 268 327 minecraft:honeycomb_block
setblock 40 265 330 minecraft:honeycomb_block
setblock 40 265 346 minecraft:yellow_terracotta
setblock 41 265 325 minecraft:yellow_terracotta
fill 41 265 326 41 268 326 minecraft:honeycomb_block
setblock 41 265 330 minecraft:yellow_terracotta
fill 41 265 331 41 268 331 minecraft:honeycomb_block
fill 41 265 333 41 266 333 minecraft:honeycomb_block
setblock 41 265 338 minecraft:honey_block
setblock 41 265 345 minecraft:yellow_terracotta
fill 41 265 346 41 268 346 minecraft:honeycomb_block
setblock 42 265 342 minecraft:orange_terracotta
setblock 0 266 348 minecraft:yellow_concrete
fill 0 266 349 0 280 349 minecraft:honeycomb_block
setblock 1 266 323 minecraft:honeycomb_block
setblock 1 266 324 minecraft:yellow_terracotta
fill 1 266 325 1 269 325 minecraft:honeycomb_block
setblock 1 266 329 minecraft:yellow_terracotta
fill 1 266 330 1 269 330 minecraft:honeycomb_block
setblock 1 266 348 minecraft:honey_block
fill 1 266 354 1 267 354 minecraft:honey_block
setblock 2 266 323 minecraft:yellow_terracotta
fill 2 266 324 5 266 324 minecraft:honeycomb_block
setblock 2 266 328 minecraft:yellow_terracotta
fill 2 266 329 2 269 329 minecraft:honeycomb_block
fill 3 266 323 3 269 323 minecraft:honeycomb_block
setblock 3 266 325 minecraft:light[level=12]
setblock 3 266 332 minecraft:light[level=12]
setblock 3 266 339 minecraft:light[level=12]
setblock 3 266 346 minecraft:light[level=12]
setblock 3 266 353 minecraft:light[level=12]
setblock 3 266 360 minecraft:light[level=12]
setblock 6 266 324 minecraft:yellow_terracotta
setblock 6 266 363 minecraft:honeycomb_block
setblock 7 266 323 minecraft:yellow_terracotta
fill 7 266 324 7 269 324 minecraft:honeycomb_block
setblock 7 266 363 minecraft:yellow_terracotta
fill 8 266 323 8 269 323 minecraft:honeycomb_block
fill 8 266 325 8 267 325 minecraft:honeycomb_block
fill 8 266 363 8 269 363 minecraft:honeycomb_block
fill 9 266 362 9 269 362 minecraft:honeycomb_block
setblock 10 266 325 minecraft:yellow_terracotta
setblock 10 266 332 minecraft:light[level=12]
setblock 10 266 346 minecraft:light[level=12]
setblock 10 266 353 minecraft:light[level=12]
setblock 10 266 360 minecraft:light[level=12]
setblock 11 266 324 minecraft:yellow_terracotta
fill 11 266 325 11 269 325 minecraft:honeycomb_block
setblock 12 266 323 minecraft:yellow_terracotta
fill 12 266 324 12 269 324 minecraft:honeycomb_block
setblock 12 266 363 minecraft:yellow_terracotta
fill 13 266 323 13 269 323 minecraft:honeycomb_block
setblock 13 266 362 minecraft:yellow_terracotta
fill 13 266 363 13 269 363 minecraft:honeycomb_block
fill 14 266 362 14 269 362 minecraft:honeycomb_block
setblock 15 266 325 minecraft:yellow_terracotta
setblock 16 266 324 minecraft:yellow_terracotta
setblock 17 266 323 minecraft:yellow_terracotta
setblock 17 266 324 minecraft:honeycomb_block
setblock 17 266 325 minecraft:light[level=12]
setblock 17 266 332 minecraft:light[level=12]
setblock 17 266 339 minecraft:light[level=12]
setblock 17 266 346 minecraft:light[level=12]
setblock 17 266 353 minecraft:light[level=12]
setblock 17 266 360 minecraft:light[level=12]
setblock 17 266 363 minecraft:yellow_terracotta
fill 18 266 323 18 268 323 minecraft:honeycomb_block
fill 18 266 363 19 267 363 minecraft:honeycomb_block
setblock 24 266 325 minecraft:light[level=12]
setblock 24 266 332 minecraft:light[level=12]
setblock 24 266 339 minecraft:light[level=12]
setblock 24 266 346 minecraft:light[level=12]
setblock 24 266 353 minecraft:light[level=12]
setblock 24 266 360 minecraft:light[level=12]
fill 25 266 322 25 269 322 minecraft:honeycomb_block
fill 29 266 323 29 268 323 minecraft:honeycomb_block
setblock 31 266 324 minecraft:yellow_terracotta
setblock 31 266 325 minecraft:light[level=12]
setblock 31 266 332 minecraft:light[level=12]
setblock 31 266 339 minecraft:light[level=12]
setblock 31 266 346 minecraft:light[level=12]
setblock 31 266 353 minecraft:light[level=12]
setblock 31 266 360 minecraft:light[level=12]
setblock 32 266 323 minecraft:yellow_terracotta
fill 32 266 324 32 269 324 minecraft:honeycomb_block
fill 33 266 323 33 269 323 minecraft:honeycomb_block
fill 33 266 363 33 268 363 minecraft:honeycomb_block
setblock 34 266 325 minecraft:honeycomb_block
setblock 35 266 325 minecraft:yellow_terracotta
setblock 36 266 324 minecraft:yellow_terracotta
setblock 36 266 363 minecraft:honey_block
setblock 37 266 323 minecraft:yellow_terracotta
fill 37 266 324 37 269 324 minecraft:honeycomb_block
fill 38 266 323 38 269 323 minecraft:honeycomb_block
setblock 38 266 325 minecraft:light[level=12]
setblock 38 266 332 minecraft:light[level=12]
setblock 38 266 339 minecraft:light[level=12]
setblock 38 266 346 minecraft:light[level=12]
setblock 38 266 353 minecraft:light[level=12]
setblock 38 266 360 minecraft:light[level=12]
setblock 40 266 325 minecraft:yellow_terracotta
fill 40 266 326 40 269 326 minecraft:honeycomb_block
setblock 40 266 330 minecraft:yellow_terracotta
fill 40 266 331 40 269 331 minecraft:honeycomb_block
setblock 41 266 324 minecraft:yellow_terracotta
fill 41 266 325 41 269 325 minecraft:honeycomb_block
setblock 41 266 329 minecraft:yellow_terracotta
fill 41 266 330 41 269 330 minecraft:honeycomb_block
setblock 41 266 334 minecraft:yellow_terracotta
setblock 41 266 344 minecraft:yellow_terracotta
fill 41 266 345 41 267 345 minecraft:honeycomb_block
setblock 41 266 349 minecraft:yellow_terracotta
fill 41 266 350 41 269 350 minecraft:honeycomb_block
setblock 41 266 357 minecraft:honey_block
fill 42 266 342 42 308 342 minecraft:honeycomb_block
fill 0 267 348 0 273 348 minecraft:honeycomb_block
setblock 1 267 323 minecraft:yellow_terracotta
fill 1 267 324 4 267 324 minecraft:honeycomb_block
setblock 1 267 328 minecraft:yellow_terracotta
fill 1 267 329 1 270 329 minecraft:honeycomb_block
setblock 1 267 333 minecraft:yellow_terracotta
setblock 1 267 335 minecraft:honey_block
setblock 1 267 360 minecraft:honey_block
fill 2 267 323 2 270 323 minecraft:honeycomb_block
setblock 2 267 327 minecraft:yellow_terracotta
fill 2 267 328 2 270 328 minecraft:honeycomb_block
fill 2 267 330 2 268 330 minecraft:honeycomb_block
setblock 5 267 324 minecraft:yellow_terracotta
setblock 5 267 363 minecraft:honeycomb_block
setblock 6 267 323 minecraft:yellow_terracotta
fill 6 267 324 6 270 324 minecraft:honeycomb_block
setblock 6 267 363 minecraft:yellow_terracotta
fill 7 267 323 7 270 323 minecraft:honeycomb_block
fill 7 267 325 7 268 325 minecraft:honeycomb_block
fill 7 267 363 7 270 363 minecraft:honeycomb_block
setblock 9 267 325 minecraft:yellow_terracotta
setblock 10 267 322 minecraft:yellow_terracotta
setblock 10 267 324 minecraft:yellow_terracotta
fill 10 267 325 10 270 325 minecraft:honeycomb_block
setblock 11 267 323 minecraft:yellow_terracotta
fill 11 267 324 11 270 324 minecraft:honeycomb_block
setblock 11 267 363 minecraft:yellow_terracotta
fill 12 267 323 12 270 323 minecraft:honeycomb_block
setblock 12 267 362 minecraft:yellow_terracotta
fill 12 267 363 12 270 363 minecraft:honeycomb_block
fill 13 267 362 13 270 362 minecraft:honeycomb_block
setblock 14 267 325 minecraft:yellow_terracotta
setblock 15 267 324 minecraft:yellow_terracotta
setblock 16 267 323 minecraft:yellow_terracotta
fill 16 267 324 16 268 324 minecraft:honeycomb_block
setblock 16 267 363 minecraft:yellow_terracotta
fill 17 267 323 17 269 323 minecraft:honeycomb_block
fill 17 267 363 17 270 363 minecraft:honeycomb_block
setblock 25 267 323 minecraft:honey_block
fill 28 267 323 28 269 323 minecraft:honeycomb_block
setblock 30 267 324 minecraft:yellow_terracotta
setblock 31 267 323 minecraft:yellow_terracotta
fill 31 267 324 31 270 324 minecraft:honeycomb_block
fill 32 267 323 32 270 323 minecraft:honeycomb_block
fill 32 267 363 32 270 363 minecraft:honeycomb_block
setblock 33 267 325 minecraft:honeycomb_block
setblock 34 267 325 minecraft:yellow_terracotta
setblock 35 267 324 minecraft:yellow_terracotta
fill 35 267 325 36 267 325 minecraft:honeycomb_block
setblock 36 267 323 minecraft:yellow_terracotta
fill 36 267 324 36 270 324 minecraft:honeycomb_block
fill 37 267 323 37 270 323 minecraft:honeycomb_block
fill 39 267 328 39 267 329 minecraft:honeycomb_block
fill 40 267 325 40 270 325 minecraft:honeycomb_block
setblock 40 267 328 minecraft:honeycomb_block
setblock 40 267 329 minecraft:yellow_terracotta
fill 40 267 330 40 270 330 minecraft:honeycomb_block
fill 40 267 332 40 267 333 minecraft:honeycomb_block
setblock 41 267 323 minecraft:yellow_terracotta
fill 41 267 324 41 270 324 minecraft:honeycomb_block
setblock 41 267 328 minecraft:yellow_terracotta
fill 41 267 329 41 270 329 minecraft:honeycomb_block
setblock 41 267 333 minecraft:yellow_terracotta
fill 41 267 334 41 269 335 minecraft:honeycomb_block
setblock 41 267 348 minecraft:yellow_terracotta
fill 41 267 349 41 270 349 minecraft:honeycomb_block
setblock 41 267 351 minecraft:honey_block
setblock 42 267 350 minecraft:orange_terracotta
fill 1 268 323 1 270 324 minecraft:honeycomb_block
setblock 1 268 327 minecraft:yellow_terracotta
fill 1 268 328 1 271 328 minecraft:honeycomb_block
setblock 1 268 331 minecraft:honeycomb_block
setblock 1 268 332 minecraft:yellow_terracotta
fill 1 268 333 1 271 333 minecraft:honeycomb_block
setblock 1 268 341 minecraft:honey_block
fill 2 268 324 3 268 324 minecraft:honeycomb_block
setblock 2 268 326 minecraft:yellow_terracotta
fill 2 268 327 2 271 327 minecraft:honeycomb_block
setblock 2 268 331 minecraft:yellow_terracotta
setblock 4 268 324 minecraft:yellow_terracotta
setblock 4 268 363 minecraft:honey_block
setblock 5 268 323 minecraft:yellow_terracotta
fill 5 268 324 5 271 324 minecraft:honeycomb_block
setblock 5 268 363 minecraft:yellow_terracotta
fill 6 268 323 6 271 323 minecraft:honeycomb_block
fill 6 268 325 6 269 325 minecraft:honeycomb_block
fill 6 268 336 7 268 340 minecraft:honey_block
fill 6 268 363 6 271 363 minecraft:honeycomb_block
fill 7 268 335 13 269 335 minecraft:honey_block
fill 7 268 341 12 268 341 minecraft:honey_block
setblock 8 268 325 minecraft:yellow_terracotta
fill 8 268 334 18 268 334 minecraft:honey_block
fill 8 268 340 17 268 340 minecraft:honey_block
fill 8 268 362 8 270 362 minecraft:honeycomb_block
setblock 9 268 324 minecraft:yellow_terracotta
fill 9 268 325 9 271 325 minecraft:honeycomb_block
fill 10 268 322 10 304 322 minecraft:honeycomb_block
setblock 10 268 323 minecraft:yellow_terracotta
fill 10 268 324 10 271 324 minecraft:honeycomb_block
setblock 10 268 342 minecraft:honey_block
setblock 10 268 363 minecraft:yellow_terracotta
fill 11 268 323 11 271 323 minecraft:honeycomb_block
setblock 11 268 362 minecraft:yellow_terracotta
fill 11 268 363 11 271 363 minecraft:honeycomb_block
fill 12 268 336 13 269 339 minecraft:honey_block
setblock 12 268 361 minecraft:yellow_terracotta
fill 12 268 362 12 271 362 minecraft:honeycomb_block
setblock 13 268 325 minecraft:yellow_terracotta
setblock 14 268 324 minecraft:yellow_terracotta
setblock 14 268 325 minecraft:honeycomb_block
fill 14 268 333 16 268 333 minecraft:honey_block
fill 14 268 336 17 271 336 minecraft:yellow_terracotta
fill 14 268 337 14 268 339 minecraft:honey_block
setblock 15 268 323 minecraft:yellow_terracotta
fill 15 268 324 15 269 324 minecraft:honeycomb_block
fill 15 268 337 16 271 338 minecraft:yellow_terracotta
fill 15 268 339 18 268 339 minecraft:honey_block
setblock 15 268 363 minecraft:yellow_terracotta
fill 16 268 323 16 270 323 minecraft:honeycomb_block
setblock 16 268 362 minecraft:yellow_terracotta
fill 16 268 363 16 271 363 minecraft:honeycomb_block
fill 17 268 335 18 269 335 minecraft:honey_block
fill 17 268 337 17 271 337 minecraft:yellow_terracotta
fill 17 268 338 18 269 338 minecraft:honey_block
fill 18 268 336 19 268 337 minecraft:honey_block
fill 18 268 363 18 269 363 minecraft:honeycomb_block
setblock 19 268 323 minecraft:honey_block
setblock 23 268 363 minecraft:honey_block
fill 25 268 339 29 268 339 minecraft:honey_block
fill 26 268 338 28 268 338 minecraft:honey_block
fill 26 268 344 29 268 344 minecraft:honey_block
setblock 27 268 345 minecraft:honey_block
fill 29 268 340 30 268 343 minecraft:honey_block
setblock 30 268 323 minecraft:yellow_terracotta
fill 30 268 324 30 271 324 minecraft:honeycomb_block
fill 31 268 323 31 271 323 minecraft:honeycomb_block
fill 31 268 363 31 271 363 minecraft:honeycomb_block
setblock 32 268 325 minecraft:honeycomb_block
setblock 33 268 325 minecraft:yellow_terracotta
setblock 34 268 324 minecraft:yellow_terracotta
fill 34 268 325 35 269 325 minecraft:honeycomb_block
setblock 35 268 323 minecraft:yellow_terracotta
fill 35 268 324 35 271 324 minecraft:honeycomb_block
fill 36 268 323 36 271 323 minecraft:honeycomb_block
setblock 39 268 324 minecraft:yellow_terracotta
fill 39 268 327 39 268 328 minecraft:honeycomb_block
setblock 39 268 329 minecraft:yellow_terracotta
fill 39 268 330 39 270 331 minecraft:honeycomb_block
setblock 40 268 323 minecraft:yellow_terracotta
setblock 40 268 328 minecraft:yellow_terracotta
fill 40 268 329 40 271 329 minecraft:honeycomb_block
setblock 40 268 332 minecraft:honeycomb_block
setblock 40 268 333 minecraft:yellow_terracotta
fill 40 268 334 40 271 334 minecraft:honeycomb_block
fill 41 268 323 41 271 323 minecraft:honeycomb_block
setblock 41 268 327 minecraft:yellow_terracotta
fill 41 268 328 41 271 328 minecraft:honeycomb_block
setblock 41 268 332 minecraft:yellow_terracotta
fill 41 268 333 41 271 333 minecraft:honeycomb_block
setblock 41 268 336 minecraft:honeycomb_block
setblock 41 268 345 minecraft:honey_block
setblock 41 268 347 minecraft:yellow_terracotta
fill 41 268 348 41 270 348 minecraft:honeycomb_block
setblock 41 268 351 minecraft:honeycomb_block
setblock 42 268 333 minecraft:yellow_terracotta
fill 42 268 350 42 287 350 minecraft:honeycomb_block
fill 0 269 336 0 272 336 minecraft:honeycomb_block
setblock 0 269 337 minecraft:yellow_concrete
setblock 0 269 341 minecraft:yellow_terracotta
setblock 1 269 326 minecraft:yellow_terracotta
fill 1 269 327 1 271 327 minecraft:honeycomb_block
setblock 1 269 331 minecraft:yellow_terracotta
fill 1 269 332 1 271 332 minecraft:honeycomb_block
fill 1 269 334 1 270 334 minecraft:honeycomb_block
setblock 1 269 347 minecraft:honey_block
setblock 1 269 350 minecraft:honeycomb_block
setblock 1 269 351 minecraft:yellow_terracotta
fill 1 269 352 1 271 352 minecraft:honeycomb_block
setblock 2 269 324 minecraft:honeycomb_block
setblock 2 269 325 minecraft:yellow_terracotta
fill 2 269 326 2 271 326 minecraft:honeycomb_block
setblock 2 269 330 minecraft:yellow_terracotta
fill 2 269 331 2 271 331 minecraft:honeycomb_block
setblock 3 269 324 minecraft:yellow_terracotta
setblock 4 269 323 minecraft:yellow_terracotta
fill 4 269 324 4 271 324 minecraft:honeycomb_block
setblock 4 269 363 minecraft:yellow_terracotta
fill 5 269 323 5 271 323 minecraft:honeycomb_block
fill 5 269 363 5 271 363 minecraft:honeycomb_block
fill 6 269 337 7 269 338 minecraft:honey_block
setblock 7 269 325 minecraft:yellow_terracotta
setblock 7 269 336 minecraft:honey_block
fill 7 269 339 7 269 340 minecraft:honey_block
fill 7 269 362 7 271 362 minecraft:honeycomb_block
setblock 8 269 324 minecraft:yellow_terracotta
fill 8 269 325 8 271 325 minecraft:honeycomb_block
fill 8 269 340 12 269 340 minecraft:honey_block
setblock 9 269 323 minecraft:yellow_terracotta
fill 9 269 324 9 271 324 minecraft:honeycomb_block
fill 9 269 334 10 269 334 minecraft:honey_block
fill 9 269 341 11 269 341 minecraft:honey_block
setblock 9 269 363 minecraft:yellow_terracotta
fill 10 269 323 10 271 323 minecraft:honeycomb_block
setblock 10 269 361 minecraft:honeycomb_block
setblock 10 269 362 minecraft:yellow_terracotta
fill 10 269 363 10 271 363 minecraft:honeycomb_block
setblock 11 269 361 minecraft:yellow_terracotta
fill 11 269 362 11 271 362 minecraft:honeycomb_block
setblock 12 269 325 minecraft:yellow_terracotta
fill 12 269 361 13 270 361 minecraft:honeycomb_block
setblock 13 269 324 minecraft:yellow_terracotta
setblock 13 269 325 minecraft:honeycomb_block
fill 13 269 334 17 269 334 minecraft:honey_block
setblock 14 269 323 minecraft:yellow_terracotta
fill 14 269 324 14 270 324 minecraft:honeycomb_block
fill 14 269 337 14 271 338 minecraft:yellow_terracotta
fill 14 269 339 17 269 339 minecraft:honey_block
setblock 14 269 363 minecraft:yellow_terracotta
fill 15 269 323 15 271 323 minecraft:honeycomb_block
setblock 15 269 340 minecraft:honey_block
setblock 15 269 362 minecraft:yellow_terracotta
fill 15 269 363 15 271 363 minecraft:honeycomb_block
fill 18 269 336 18 269 337 minecraft:honey_block
fill 26 269 339 28 269 339 minecraft:honey_block
fill 26 269 344 28 269 344 minecraft:honey_block
setblock 29 269 323 minecraft:yellow_terracotta
fill 29 269 324 29 271 324 minecraft:honeycomb_block
fill 29 269 340 29 269 343 minecraft:honey_block
setblock 29 269 363 minecraft:honey_block
fill 30 269 323 30 271 323 minecraft:honeycomb_block
fill 30 269 363 30 271 363 minecraft:honeycomb_block
setblock 31 269 325 minecraft:honeycomb_block
setblock 32 269 325 minecraft:yellow_terracotta
setblock 33 269 324 minecraft:yellow_terracotta
fill 33 269 325 33 270 325 minecraft:honeycomb_block
fill 34 269 322 34 303 322 minecraft:honeycomb_block
setblock 34 269 323 minecraft:yellow_terracotta
fill 34 269 324 34 271 324 minecraft:honeycomb_block
fill 35 269 323 35 271 323 minecraft:honeycomb_block
setblock 38 269 324 minecraft:yellow_terracotta
setblock 39 269 323 minecraft:yellow_terracotta
setblock 39 269 327 minecraft:honeycomb_block
setblock 39 269 328 minecraft:yellow_terracotta
fill 39 269 329 39 271 329 minecraft:honeycomb_block
setblock 39 269 332 minecraft:honeycomb_block
fill 40 269 323 40 271 323 minecraft:honeycomb_block
setblock 40 269 327 minecraft:yellow_terracotta
fill 40 269 328 40 271 328 minecraft:honeycomb_block
setblock 40 269 332 minecraft:yellow_terracotta
fill 40 269 333 40 271 333 minecraft:honeycomb_block
setblock 41 269 326 minecraft:yellow_terracotta
fill 41 269 327 41 271 327 minecraft:honeycomb_block
setblock 41 269 331 minecraft:yellow_terracotta
fill 41 269 332 41 271 332 minecraft:honeycomb_block
setblock 41 269 336 minecraft:yellow_terracotta
fill 41 269 337 41 271 337 minecraft:honeycomb_block
setblock 41 269 339 minecraft:honey_block
setblock 41 269 347 minecraft:honeycomb_block
setblock 41 269 351 minecraft:yellow_terracotta
fill 41 269 352 41 271 352 minecraft:honeycomb_block
setblock 41 269 358 minecraft:honey_block
fill 42 269 333 42 308 333 minecraft:honeycomb_block
setblock 42 269 347 minecraft:yellow_terracotta
fill 0 270 337 0 274 337 minecraft:honeycomb_block
fill 0 270 341 0 292 341 minecraft:honeycomb_block
setblock 1 270 325 minecraft:yellow_terracotta
fill 1 270 326 1 271 326 minecraft:honeycomb_block
setblock 1 270 330 minecraft:yellow_terracotta
fill 1 270 331 1 271 331 minecraft:honeycomb_block
setblock 1 270 350 minecraft:yellow_terracotta
fill 1 270 351 1 271 351 minecraft:honeycomb_block
fill 1 270 353 1 270 354 minecraft:honeycomb_block
setblock 1 270 355 minecraft:yellow_terracotta
setblock 2 270 324 minecraft:yellow_terracotta
fill 2 270 325 2 271 325 minecraft:honeycomb_block
setblock 2 270 329 minecraft:yellow_terracotta
fill 2 270 330 2 271 330 minecraft:honeycomb_block
fill 2 270 332 2 271 332 minecraft:honeycomb_block
setblock 3 270 323 minecraft:yellow_terracotta
fill 3 270 324 3 271 324 minecraft:honeycomb_block
setblock 3 270 363 minecraft:yellow_terracotta
fill 4 270 323 4 271 323 minecraft:honeycomb_block
fill 4 270 363 4 271 363 minecraft:honeycomb_block
setblock 6 270 325 minecraft:yellow_terracotta
fill 6 270 362 6 271 362 minecraft:honeycomb_block
setblock 7 270 324 minecraft:yellow_terracotta
fill 7 270 325 7 271 325 minecraft:honeycomb_block
fill 7 270 337 7 270 339 minecraft:honey_block
setblock 8 270 323 minecraft:yellow_terracotta
fill 8 270 324 8 271 324 minecraft:honeycomb_block
fill 8 270 340 11 270 340 minecraft:honey_block
setblock 8 270 363 minecraft:yellow_terracotta
fill 9 270 323 9 271 323 minecraft:honeycomb_block
fill 9 270 335 11 270 335 minecraft:honey_block
setblock 9 270 361 minecraft:honeycomb_block
setblock 9 270 362 minecraft:yellow_terracotta
fill 9 270 363 9 271 363 minecraft:honeycomb_block
setblock 10 270 361 minecraft:yellow_terracotta
fill 10 270 362 10 271 362 minecraft:honeycomb_block
setblock 11 270 325 minecraft:yellow_terracotta
fill 11 270 361 11 271 361 minecraft:honeycomb_block
setblock 12 270 324 minecraft:yellow_terracotta
setblock 12 270 325 minecraft:honeycomb_block
fill 12 270 336 12 270 339 minecraft:honey_block
setblock 13 270 323 minecraft:yellow_terracotta
fill 13 270 324 13 271 324 minecraft:honeycomb_block
setblock 13 270 335 minecraft:honey_block
fill 13 270 336 13 271 337 minecraft:yellow_terracotta
setblock 13 270 338 minecraft:honey_block
setblock 13 270 363 minecraft:yellow_terracotta
fill 14 270 323 14 271 323 minecraft:honeycomb_block
fill 14 270 339 16 270 339 minecraft:honey_block
setblock 14 270 362 minecraft:yellow_terracotta
fill 14 270 363 14 271 363 minecraft:honeycomb_block
setblock 15 270 334 minecraft:honey_block
setblock 15 270 362 minecraft:honeycomb_block
setblock 17 270 335 minecraft:honey_block
setblock 17 270 338 minecraft:honey_block
setblock 25 270 322 minecraft:yellow_concrete
setblock 26 270 323 minecraft:honey_block
setblock 27 270 323 minecraft:honeycomb_block
setblock 27 270 339 minecraft:honey_block
setblock 28 270 323 minecraft:yellow_terracotta
fill 29 270 323 29 271 323 minecraft:honeycomb_block
fill 29 270 341 29 270 342 minecraft:honey_block
setblock 31 270 325 minecraft:yellow_terracotta
setblock 32 270 324 minecraft:yellow_terracotta
setblock 32 270 325 minecraft:honeycomb_block
setblock 33 270 323 minecraft:yellow_terracotta
fill 33 270 324 33 271 324 minecraft:honeycomb_block
fill 34 270 323 34 271 323 minecraft:honeycomb_block
setblock 35 270 363 minecraft:honey_block
setblock 37 270 324 minecraft:yellow_terracotta
setblock 38 270 323 minecraft:yellow_terracotta
fill 39 270 323 39 271 323 minecraft:honeycomb_block
setblock 39 270 328 minecraft:honeycomb_block
setblock 39 270 332 minecraft:yellow_terracotta
fill 39 270 333 39 271 333 minecraft:honeycomb_block
setblock 40 270 326 minecraft:yellow_terracotta
fill 40 270 327 40 271 327 minecraft:honeycomb_block
setblock 40 270 331 minecraft:yellow_terracotta
fill 40 270 332 40 271 332 minecraft:honeycomb_block
setblock 40 270 335 minecraft:honeycomb_block
setblock 41 270 325 minecraft:yellow_terracotta
fill 41 270 326 41 271 326 minecraft:honeycomb_block
setblock 41 270 330 minecraft:yellow_terracotta
fill 41 270 331 41 271 331 minecraft:honeycomb_block
setblock 41 270 334 minecraft:honeycomb_block
setblock 41 270 335 minecraft:yellow_terracotta
fill 41 270 336 41 271 336 minecraft:honeycomb_block
setblock 41 270 350 minecraft:yellow_terracotta
fill 41 270 351 41 271 351 minecraft:honeycomb_block
fill 42 270 347 42 284 347 minecraft:honeycomb_block
setblock 1 271 323 minecraft:honeycomb_block
setblock 1 271 324 minecraft:yellow_terracotta
setblock 1 271 325 minecraft:honeycomb_block
setblock 1 271 329 minecraft:yellow_terracotta
setblock 1 271 330 minecraft:honeycomb_block
setblock 1 271 334 minecraft:yellow_terracotta
setblock 1 271 335 minecraft:honeycomb_block
setblock 1 271 340 minecraft:honey_block
setblock 1 271 350 minecraft:honeycomb_block
setblock 1 271 353 minecraft:honeycomb_block
setblock 1 271 354 minecraft:yellow_terracotta
fill 1 271 355 1 271 357 minecraft:honeycomb_block
setblock 1 271 359 minecraft:honey_block
setblock 2 271 323 minecraft:yellow_terracotta
setblock 2 271 328 minecraft:yellow_terracotta
setblock 2 271 329 minecraft:honeycomb_block
setblock 3 271 323 minecraft:honeycomb_block
setblock 3 271 363 minecraft:honeycomb_block
setblock 6 271 324 minecraft:yellow_terracotta
setblock 7 271 322 minecraft:yellow_concrete
setblock 7 271 323 minecraft:yellow_terracotta
setblock 7 271 324 minecraft:honeycomb_block
setblock 7 271 363 minecraft:yellow_terracotta
setblock 8 271 323 minecraft:honeycomb_block
setblock 8 271 361 minecraft:honeycomb_block
setblock 8 271 362 minecraft:yellow_terracotta
setblock 8 271 363 minecraft:honeycomb_block
setblock 9 271 361 minecraft:yellow_terracotta
setblock 9 271 362 minecraft:honeycomb_block
setblock 10 271 325 minecraft:yellow_terracotta
setblock 10 271 361 minecraft:honeycomb_block
setblock 11 271 324 minecraft:yellow_terracotta
setblock 11 271 325 minecraft:honeycomb_block
setblock 12 271 323 minecraft:yellow_terracotta
setblock 12 271 324 minecraft:honeycomb_block
setblock 12 271 361 minecraft:honeycomb_block
setblock 12 271 363 minecraft:yellow_terracotta
setblock 13 271 323 minecraft:honeycomb_block
setblock 13 271 362 minecraft:yellow_terracotta
setblock 13 271 363 minecraft:honeycomb_block
setblock 14 271 362 minecraft:honeycomb_block
setblock 20 271 323 minecraft:honey_block
setblock 22 271 363 minecraft:honey_block
fill 25 271 322 25 285 322 minecraft:honeycomb_block
setblock 26 271 322 minecraft:orange_terracotta
setblock 26 271 364 minecraft:yellow_concrete
setblock 27 271 323 minecraft:yellow_terracotta
setblock 28 271 323 minecraft:honeycomb_block
setblock 31 271 324 minecraft:yellow_terracotta
setblock 32 271 323 minecraft:yellow_terracotta
setblock 32 271 324 minecraft:honeycomb_block
setblock 33 271 323 minecraft:honeycomb_block
setblock 36 271 322 minecraft:orange_terracotta
setblock 37 271 323 minecraft:yellow_terracotta
setblock 38 271 323 minecraft:honeycomb_block
setblock 39 271 330 minecraft:honeycomb_block
setblock 39 271 331 minecraft:yellow_terracotta
setblock 39 271 332 minecraft:honeycomb_block
setblock 40 271 322 minecraft:yellow_terracotta
setblock 40 271 326 minecraft:honeycomb_block
setblock 40 271 330 minecraft:yellow_terracotta
setblock 40 271 331 minecraft:honeycomb_block
setblock 40 271 335 minecraft:yellow_terracotta
setblock 41 271 324 minecraft:yellow_terracotta
setblock 41 271 325 minecraft:honeycomb_block
setblock 41 271 329 minecraft:yellow_terracotta
setblock 41 271 330 minecraft:honeycomb_block
setblock 41 271 334 minecraft:yellow_terracotta
setblock 41 271 335 minecraft:honeycomb_block
setblock 41 271 346 minecraft:honey_block
setblock 41 271 350 minecraft:honeycomb_block
setblock 41 271 363 minecraft:honey_block
setblock 3 272 325 minecraft:light[level=15]
setblock 3 272 332 minecraft:light[level=12]
setblock 3 272 333 minecraft:light[level=15]
setblock 3 272 339 minecraft:light[level=12]
setblock 3 272 341 minecraft:light[level=15]
setblock 3 272 346 minecraft:light[level=12]
setblock 3 272 349 minecraft:light[level=15]
setblock 3 272 353 minecraft:light[level=12]
setblock 3 272 357 minecraft:light[level=15]
setblock 3 272 360 minecraft:light[level=12]
fill 7 272 322 7 308 322 minecraft:honeycomb_block
setblock 10 272 325 minecraft:light[level=12]
setblock 10 272 332 minecraft:light[level=12]
setblock 10 272 339 minecraft:light[level=12]
setblock 10 272 346 minecraft:light[level=12]
setblock 10 272 353 minecraft:light[level=12]
setblock 10 272 360 minecraft:light[level=12]
setblock 11 272 325 minecraft:light[level=15]
setblock 11 272 333 minecraft:light[level=15]
setblock 11 272 341 minecraft:light[level=15]
setblock 11 272 349 minecraft:light[level=15]
setblock 11 272 357 minecraft:light[level=15]
setblock 17 272 325 minecraft:light[level=12]
setblock 17 272 332 minecraft:light[level=12]
setblock 17 272 339 minecraft:light[level=12]
setblock 17 272 346 minecraft:light[level=12]
setblock 17 272 353 minecraft:light[level=12]
setblock 17 272 360 minecraft:light[level=12]
setblock 19 272 325 minecraft:light[level=15]
setblock 19 272 333 minecraft:light[level=15]
setblock 19 272 341 minecraft:light[level=15]
setblock 19 272 349 minecraft:light[level=15]
setblock 19 272 357 minecraft:light[level=15]
setblock 24 272 325 minecraft:light[level=12]
setblock 24 272 332 minecraft:light[level=12]
setblock 24 272 339 minecraft:light[level=12]
setblock 24 272 346 minecraft:light[level=12]
setblock 24 272 353 minecraft:light[level=12]
setblock 24 272 360 minecraft:light[level=12]
fill 26 272 322 26 296 322 minecraft:honeycomb_block
fill 26 272 364 26 308 364 minecraft:honeycomb_block
setblock 27 272 325 minecraft:light[level=15]
setblock 27 272 333 minecraft:light[level=15]
setblock 27 272 341 minecraft:light[level=15]
setblock 27 272 349 minecraft:light[level=15]
setblock 27 272 357 minecraft:light[level=15]
setblock 31 272 325 minecraft:light[level=12]
setblock 31 272 332 minecraft:light[level=12]
setblock 31 272 339 minecraft:light[level=12]
setblock 31 272 346 minecraft:light[level=12]
setblock 31 272 353 minecraft:light[level=12]
setblock 31 272 360 minecraft:light[level=12]
setblock 35 272 325 minecraft:light[level=15]
setblock 35 272 333 minecraft:light[level=15]
setblock 35 272 341 minecraft:light[level=15]
setblock 35 272 349 minecraft:light[level=15]
setblock 35 272 357 minecraft:light[level=15]
fill 36 272 322 36 308 322 minecraft:honeycomb_block
setblock 38 272 325 minecraft:light[level=12]
setblock 38 272 332 minecraft:light[level=12]
setblock 38 272 339 minecraft:light[level=12]
setblock 38 272 346 minecraft:light[level=12]
setblock 38 272 353 minecraft:light[level=12]
setblock 38 272 360 minecraft:light[level=12]
fill 40 272 322 40 274 322 minecraft:honeycomb_block
setblock 0 273 336 minecraft:orange_terracotta
setblock 42 273 344 minecraft:orange_terracotta
setblock 0 274 326 minecraft:yellow_terracotta
fill 0 274 336 0 300 336 minecraft:honeycomb_block
setblock 0 274 348 minecraft:orange_terracotta
setblock 42 274 336 minecraft:orange_terracotta
fill 42 274 344 42 292 344 minecraft:honeycomb_block
fill 0 275 326 0 291 326 minecraft:honeycomb_block
setblock 0 275 337 minecraft:yellow_concrete
fill 0 275 348 0 308 348 minecraft:honeycomb_block
setblock 40 275 322 minecraft:yellow_concrete
fill 42 275 336 42 299 336 minecraft:honeycomb_block
setblock 42 275 345 minecraft:yellow_concrete
fill 0 276 337 0 308 337 minecraft:honeycomb_block
setblock 12 276 364 minecraft:orange_terracotta
fill 40 276 322 40 285 322 minecraft:honeycomb_block
setblock 42 276 329 minecraft:orange_terracotta
fill 42 276 345 42 279 345 minecraft:honeycomb_block
fill 1 277 323 19 278 363 minecraft:honeycomb_block
fill 12 277 364 12 308 364 minecraft:honeycomb_block
fill 20 277 323 20 278 341 minecraft:honeycomb_block
fill 20 277 343 20 278 363 minecraft:honeycomb_block
fill 21 277 323 22 278 339 minecraft:honeycomb_block
fill 21 277 345 22 278 363 minecraft:honeycomb_block
fill 23 277 323 41 278 338 minecraft:honeycomb_block
fill 23 277 346 41 278 363 minecraft:honeycomb_block
fill 24 277 339 41 278 339 minecraft:honeycomb_block
fill 24 277 345 41 278 345 minecraft:honeycomb_block
fill 26 277 340 41 278 341 minecraft:honeycomb_block
fill 26 277 343 41 278 344 minecraft:honeycomb_block
fill 27 277 342 41 278 342 minecraft:honeycomb_block
fill 42 277 329 42 308 329 minecraft:honeycomb_block
setblock 1 278 322 minecraft:yellow_concrete
fill 1 279 322 1 308 322 minecraft:honeycomb_block
fill 1 279 323 1 279 324 minecraft:orange_terracotta
fill 1 279 325 41 279 326 minecraft:honeycomb_block
fill 1 279 327 1 279 329 minecraft:orange_terracotta
fill 1 279 330 41 279 331 minecraft:honeycomb_block
fill 1 279 332 1 279 334 minecraft:orange_terracotta
fill 1 279 335 41 279 336 minecraft:honeycomb_block
fill 1 279 337 1 279 339 minecraft:orange_terracotta
fill 1 279 340 18 279 342 minecraft:honeycomb_block
fill 1 279 343 1 279 345 minecraft:orange_terracotta
fill 1 279 346 21 279 347 minecraft:honeycomb_block
fill 1 279 348 1 279 350 minecraft:orange_terracotta
fill 1 279 351 41 279 352 minecraft:honeycomb_block
fill 1 279 353 1 279 355 minecraft:orange_terracotta
fill 1 279 356 41 279 357 minecraft:honeycomb_block
fill 1 279 358 1 279 360 minecraft:orange_terracotta
fill 1 279 361 41 279 362 minecraft:honeycomb_block
fill 1 279 363 41 279 363 minecraft:orange_terracotta
fill 2 279 323 3 279 323 minecraft:honeycomb_block
fill 2 279 324 41 279 324 minecraft:orange_terracotta
fill 2 279 327 3 279 329 minecraft:honeycomb_block
fill 2 279 332 41 279 332 minecraft:orange_terracotta
fill 2 279 333 3 279 334 minecraft:honeycomb_block
fill 2 279 337 41 279 337 minecraft:orange_terracotta
fill 2 279 338 3 279 339 minecraft:honeycomb_block
fill 2 279 343 3 279 344 minecraft:honeycomb_block
fill 2 279 345 19 279 345 minecraft:orange_terracotta
fill 2 279 348 3 279 349 minecraft:honeycomb_block
fill 2 279 350 41 279 350 minecraft:orange_terracotta
fill 2 279 353 3 279 355 minecraft:honeycomb_block
fill 2 279 358 41 279 358 minecraft:orange_terracotta
fill 2 279 359 3 279 360 minecraft:honeycomb_block
setblock 3 279 322 minecraft:orange_terracotta
setblock 4 279 323 minecraft:orange_terracotta
fill 4 279 327 4 279 329 minecraft:orange_terracotta
fill 4 279 333 4 279 334 minecraft:orange_terracotta
fill 4 279 338 4 279 339 minecraft:orange_terracotta
fill 4 279 343 4 279 344 minecraft:orange_terracotta
fill 4 279 348 4 279 349 minecraft:orange_terracotta
fill 4 279 353 4 279 355 minecraft:orange_terracotta
fill 4 279 359 4 279 360 minecraft:orange_terracotta
fill 5 279 323 6 279 323 minecraft:honeycomb_block
fill 5 279 327 6 279 329 minecraft:honeycomb_block
fill 5 279 333 6 279 334 minecraft:honeycomb_block
fill 5 279 338 6 279 339 minecraft:honeycomb_block
fill 5 279 343 6 279 344 minecraft:honeycomb_block
fill 5 279 348 6 279 349 minecraft:honeycomb_block
fill 5 279 353 6 279 355 minecraft:honeycomb_block
fill 5 279 359 6 279 360 minecraft:honeycomb_block
setblock 7 279 323 minecraft:orange_terracotta
fill 7 279 327 7 279 329 minecraft:orange_terracotta
fill 7 279 333 7 279 334 minecraft:orange_terracotta
fill 7 279 338 7 279 339 minecraft:orange_terracotta
fill 7 279 343 7 279 344 minecraft:orange_terracotta
fill 7 279 348 7 279 349 minecraft:orange_terracotta
fill 7 279 353 7 279 355 minecraft:orange_terracotta
fill 7 279 359 7 279 360 minecraft:orange_terracotta
fill 8 279 323 9 279 323 minecraft:honeycomb_block
fill 8 279 327 9 279 329 minecraft:honeycomb_block
fill 8 279 333 9 279 334 minecraft:honeycomb_block
fill 8 279 338 9 279 339 minecraft:honeycomb_block
fill 8 279 343 9 279 344 minecraft:honeycomb_block
fill 8 279 348 9 279 349 minecraft:honeycomb_block
fill 8 279 353 9 279 355 minecraft:honeycomb_block
fill 8 279 359 9 279 360 minecraft:honeycomb_block
setblock 10 279 323 minecraft:orange_terracotta
fill 10 279 327 10 279 329 minecraft:orange_terracotta
fill 10 279 333 10 279 334 minecraft:orange_terracotta
fill 10 279 338 10 279 339 minecraft:orange_terracotta
fill 10 279 343 10 279 344 minecraft:orange_terracotta
fill 10 279 348 10 279 349 minecraft:orange_terracotta
fill 10 279 353 10 279 355 minecraft:orange_terracotta
fill 10 279 359 10 279 360 minecraft:orange_terracotta
fill 11 279 323 12 279 323 minecraft:honeycomb_block
fill 11 279 327 12 279 329 minecraft:honeycomb_block
fill 11 279 333 12 279 334 minecraft:honeycomb_block
fill 11 279 338 12 279 339 minecraft:honeycomb_block
fill 11 279 343 12 279 344 minecraft:honeycomb_block
fill 11 279 348 12 279 349 minecraft:honeycomb_block
fill 11 279 353 12 279 355 minecraft:honeycomb_block
fill 11 279 359 12 279 360 minecraft:honeycomb_block
setblock 13 279 323 minecraft:orange_terracotta
fill 13 279 327 13 279 329 minecraft:orange_terracotta
fill 13 279 333 13 279 334 minecraft:orange_terracotta
fill 13 279 338 13 279 339 minecraft:orange_terracotta
fill 13 279 343 13 279 344 minecraft:orange_terracotta
fill 13 279 348 13 279 349 minecraft:orange_terracotta
fill 13 279 353 13 279 355 minecraft:orange_terracotta
fill 13 279 359 13 279 360 minecraft:orange_terracotta
fill 14 279 323 15 279 323 minecraft:honeycomb_block
fill 14 279 327 15 279 329 minecraft:honeycomb_block
fill 14 279 333 15 279 334 minecraft:honeycomb_block
fill 14 279 338 15 279 339 minecraft:honeycomb_block
fill 14 279 343 15 279 344 minecraft:honeycomb_block
fill 14 279 348 15 279 349 minecraft:honeycomb_block
fill 14 279 353 15 279 355 minecraft:honeycomb_block
fill 14 279 359 15 279 360 minecraft:honeycomb_block
setblock 15 279 322 minecraft:orange_terracotta
setblock 16 279 323 minecraft:orange_terracotta
fill 16 279 327 16 279 329 minecraft:orange_terracotta
fill 16 279 333 16 279 334 minecraft:orange_terracotta
fill 16 279 338 16 279 339 minecraft:orange_terracotta
fill 16 279 343 16 279 344 minecraft:orange_terracotta
fill 16 279 348 16 279 349 minecraft:orange_terracotta
fill 16 279 353 16 279 355 minecraft:orange_terracotta
fill 16 279 359 16 279 360 minecraft:orange_terracotta
setblock 16 279 364 minecraft:yellow_concrete
fill 17 279 323 18 279 323 minecraft:honeycomb_block
fill 17 279 327 18 279 329 minecraft:honeycomb_block
fill 17 279 333 18 279 334 minecraft:honeycomb_block
fill 17 279 338 18 279 339 minecraft:honeycomb_block
fill 17 279 343 18 279 344 minecraft:honeycomb_block
fill 17 279 348 18 279 349 minecraft:honeycomb_block
fill 17 279 353 18 279 355 minecraft:honeycomb_block
fill 17 279 359 18 279 360 minecraft:honeycomb_block
setblock 19 279 323 minecraft:orange_terracotta
fill 19 279 327 19 279 329 minecraft:orange_terracotta
fill 19 279 333 19 279 334 minecraft:orange_terracotta
fill 19 279 338 19 279 339 minecraft:orange_terracotta
setblock 19 279 340 minecraft:honeycomb_block
fill 19 279 341 19 279 343 minecraft:ochre_froglight
setblock 19 279 344 minecraft:orange_terracotta
fill 19 279 348 19 279 349 minecraft:orange_terracotta
fill 19 279 353 19 279 355 minecraft:orange_terracotta
fill 19 279 359 19 279 360 minecraft:orange_terracotta
fill 20 279 323 21 279 323 minecraft:honeycomb_block
fill 20 279 327 21 279 329 minecraft:honeycomb_block
fill 20 279 333 21 279 334 minecraft:honeycomb_block
fill 20 279 338 21 279 338 minecraft:honeycomb_block
fill 20 279 339 20 279 341 minecraft:ochre_froglight
fill 20 279 343 20 279 345 minecraft:ochre_froglight
fill 20 279 348 21 279 349 minecraft:honeycomb_block
fill 20 279 353 21 279 355 minecraft:honeycomb_block
fill 20 279 359 21 279 360 minecraft:honeycomb_block
fill 21 279 339 22 279 339 minecraft:ochre_froglight
fill 21 279 345 22 279 345 minecraft:ochre_froglight
setblock 22 279 323 minecraft:orange_terracotta
fill 22 279 327 22 279 329 minecraft:orange_terracotta
fill 22 279 333 22 279 334 minecraft:orange_terracotta
fill 22 279 338 24 279 338 minecraft:ochre_froglight
fill 22 279 346 24 279 346 minecraft:ochre_froglight
fill 22 279 347 41 279 347 minecraft:honeycomb_block
fill 22 279 348 22 279 349 minecraft:orange_terracotta
fill 22 279 353 22 279 355 minecraft:orange_terracotta
fill 22 279 359 22 279 360 minecraft:orange_terracotta
fill 23 279 323 24 279 323 minecraft:honeycomb_block
fill 23 279 327 24 279 329 minecraft:honeycomb_block
fill 23 279 333 24 279 334 minecraft:honeycomb_block
fill 23 279 348 24 279 349 minecraft:honeycomb_block
fill 23 279 353 24 279 355 minecraft:honeycomb_block
fill 23 279 359 24 279 360 minecraft:honeycomb_block
fill 24 279 339 26 279 339 minecraft:ochre_froglight
fill 24 279 345 26 279 345 minecraft:ochre_froglight
setblock 25 279 323 minecraft:orange_terracotta
fill 25 279 327 25 279 329 minecraft:orange_terracotta
fill 25 279 333 25 279 334 minecraft:orange_terracotta
setblock 25 279 338 minecraft:orange_terracotta
fill 25 279 346 41 279 346 minecraft:honeycomb_block
fill 25 279 348 25 279 349 minecraft:orange_terracotta
fill 25 279 353 25 279 355 minecraft:orange_terracotta
fill 25 279 359 25 279 360 minecraft:orange_terracotta
fill 26 279 323 27 279 323 minecraft:honeycomb_block
fill 26 279 327 27 279 329 minecraft:honeycomb_block
fill 26 279 333 27 279 334 minecraft:honeycomb_block
fill 26 279 338 27 279 338 minecraft:honeycomb_block
fill 26 279 340 26 279 341 minecraft:ochre_froglight
fill 26 279 343 26 279 344 minecraft:ochre_froglight
fill 26 279 348 27 279 349 minecraft:honeycomb_block
fill 26 279 353 27 279 355 minecraft:honeycomb_block
fill 26 279 359 27 279 360 minecraft:honeycomb_block
fill 27 279 339 27 279 340 minecraft:honeycomb_block
fill 27 279 341 27 279 343 minecraft:ochre_froglight
setblock 27 279 344 minecraft:honeycomb_block
fill 27 279 345 41 279 345 minecraft:orange_terracotta
setblock 28 279 323 minecraft:orange_terracotta
fill 28 279 327 28 279 329 minecraft:orange_terracotta
fill 28 279 333 28 279 334 minecraft:orange_terracotta
fill 28 279 338 28 279 339 minecraft:orange_terracotta
fill 28 279 340 41 279 342 minecraft:honeycomb_block
fill 28 279 343 28 279 344 minecraft:orange_terracotta
fill 28 279 348 28 279 349 minecraft:orange_terracotta
fill 28 279 353 28 279 355 minecraft:orange_terracotta
fill 28 279 359 28 279 360 minecraft:orange_terracotta
setblock 28 279 364 minecraft:yellow_terracotta
fill 29 279 323 30 279 323 minecraft:honeycomb_block
fill 29 279 327 30 279 329 minecraft:honeycomb_block
fill 29 279 333 30 279 334 minecraft:honeycomb_block
fill 29 279 338 30 279 339 minecraft:honeycomb_block
fill 29 279 343 30 279 344 minecraft:honeycomb_block
fill 29 279 348 30 279 349 minecraft:honeycomb_block
fill 29 279 353 30 279 355 minecraft:honeycomb_block
fill 29 279 359 30 279 360 minecraft:honeycomb_block
setblock 31 279 323 minecraft:orange_terracotta
fill 31 279 327 31 279 329 minecraft:orange_terracotta
fill 31 279 333 31 279 334 minecraft:orange_terracotta
fill 31 279 338 31 279 339 minecraft:orange_terracotta
fill 31 279 343 31 279 344 minecraft:orange_terracotta
fill 31 279 348 31 279 349 minecraft:orange_terracotta
fill 31 279 353 31 279 355 minecraft:orange_terracotta
fill 31 279 359 31 279 360 minecraft:orange_terracotta
fill 32 279 323 33 279 323 minecraft:honeycomb_block
fill 32 279 327 33 279 329 minecraft:honeycomb_block
fill 32 279 333 33 279 334 minecraft:honeycomb_block
fill 32 279 338 33 279 339 minecraft:honeycomb_block
fill 32 279 343 33 279 344 minecraft:honeycomb_block
fill 32 279 348 33 279 349 minecraft:honeycomb_block
fill 32 279 353 33 279 355 minecraft:honeycomb_block
fill 32 279 359 33 279 360 minecraft:honeycomb_block
setblock 34 279 323 minecraft:orange_terracotta
fill 34 279 327 34 279 329 minecraft:orange_terracotta
fill 34 279 333 34 279 334 minecraft:orange_terracotta
fill 34 279 338 34 279 339 minecraft:orange_terracotta
fill 34 279 343 34 279 344 minecraft:orange_terracotta
fill 34 279 348 34 279 349 minecraft:orange_terracotta
fill 34 279 353 34 279 355 minecraft:orange_terracotta
fill 34 279 359 34 279 360 minecraft:orange_terracotta
fill 35 279 323 36 279 323 minecraft:honeycomb_block
fill 35 279 327 36 279 329 minecraft:honeycomb_block
fill 35 279 333 36 279 334 minecraft:honeycomb_block
fill 35 279 338 36 279 339 minecraft:honeycomb_block
fill 35 279 343 36 279 344 minecraft:honeycomb_block
fill 35 279 348 36 279 349 minecraft:honeycomb_block
fill 35 279 353 36 279 355 minecraft:honeycomb_block
fill 35 279 359 36 279 360 minecraft:honeycomb_block
setblock 37 279 323 minecraft:orange_terracotta
fill 37 279 327 37 279 329 minecraft:orange_terracotta
fill 37 279 333 37 279 334 minecraft:orange_terracotta
fill 37 279 338 37 279 339 minecraft:orange_terracotta
fill 37 279 343 37 279 344 minecraft:orange_terracotta
fill 37 279 348 37 279 349 minecraft:orange_terracotta
fill 37 279 353 37 279 355 minecraft:orange_terracotta
fill 37 279 359 37 279 360 minecraft:orange_terracotta
fill 38 279 323 39 279 323 minecraft:honeycomb_block
fill 38 279 327 39 279 329 minecraft:honeycomb_block
fill 38 279 333 39 279 334 minecraft:honeycomb_block
fill 38 279 338 39 279 339 minecraft:honeycomb_block
fill 38 279 343 39 279 344 minecraft:honeycomb_block
fill 38 279 348 39 279 349 minecraft:honeycomb_block
fill 38 279 353 39 279 355 minecraft:honeycomb_block
fill 38 279 359 39 279 360 minecraft:honeycomb_block
setblock 40 279 323 minecraft:orange_terracotta
fill 40 279 327 40 279 329 minecraft:orange_terracotta
fill 40 279 333 40 279 334 minecraft:orange_terracotta
fill 40 279 338 40 279 339 minecraft:orange_terracotta
fill 40 279 343 40 279 344 minecraft:orange_terracotta
fill 40 279 348 40 279 349 minecraft:orange_terracotta
fill 40 279 353 40 279 355 minecraft:orange_terracotta
fill 40 279 359 40 279 360 minecraft:orange_terracotta
setblock 41 279 323 minecraft:honeycomb_block
fill 41 279 327 41 279 329 minecraft:honeycomb_block
fill 41 279 333 41 279 334 minecraft:honeycomb_block
fill 41 279 338 41 279 339 minecraft:honeycomb_block
fill 41 279 343 41 279 344 minecraft:honeycomb_block
fill 41 279 348 41 279 349 minecraft:honeycomb_block
fill 41 279 353 41 279 355 minecraft:honeycomb_block
fill 41 279 359 41 279 360 minecraft:honeycomb_block
setblock 42 279 332 minecraft:yellow_terracotta
setblock 42 279 356 minecraft:orange_terracotta
fill 0 280 345 0 308 345 minecraft:honeycomb_block
setblock 0 280 346 minecraft:orange_terracotta
fill 3 280 322 3 283 322 minecraft:honeycomb_block
setblock 3 280 325 minecraft:light[level=15]
setblock 3 280 333 minecraft:light[level=15]
setblock 3 280 341 minecraft:light[level=15]
setblock 3 280 349 minecraft:light[level=15]
setblock 3 280 357 minecraft:light[level=15]
setblock 11 280 325 minecraft:light[level=15]
setblock 11 280 333 minecraft:light[level=15]
setblock 11 280 341 minecraft:light[level=15]
setblock 11 280 349 minecraft:light[level=15]
setblock 11 280 357 minecraft:light[level=15]
fill 15 280 322 15 308 322 minecraft:honeycomb_block
fill 16 280 364 16 308 364 minecraft:honeycomb_block
setblock 19 280 325 minecraft:light[level=15]
setblock 19 280 333 minecraft:light[level=15]
setblock 19 280 341 minecraft:light[level=15]
setblock 19 280 349 minecraft:light[level=15]
setblock 19 280 357 minecraft:light[level=15]
setblock 27 280 325 minecraft:light[level=15]
setblock 27 280 333 minecraft:light[level=15]
setblock 27 280 341 minecraft:light[level=15]
setblock 27 280 349 minecraft:light[level=15]
setblock 27 280 357 minecraft:light[level=15]
fill 28 280 364 28 308 364 minecraft:honeycomb_block
setblock 35 280 325 minecraft:light[level=15]
setblock 35 280 333 minecraft:light[level=15]
setblock 35 280 341 minecraft:light[level=15]
setblock 35 280 349 minecraft:light[level=15]
setblock 35 280 357 minecraft:light[level=15]
fill 42 280 332 42 308 332 minecraft:honeycomb_block
setblock 42 280 345 minecraft:orange_terracotta
setblock 42 280 354 minecraft:yellow_concrete
fill 42 280 356 42 308 356 minecraft:honeycomb_block
setblock 42 280 361 minecraft:orange_terracotta
fill 0 281 346 0 308 346 minecraft:honeycomb_block
setblock 0 281 349 minecraft:orange_terracotta
setblock 8 281 364 minecraft:orange_terracotta
fill 42 281 345 42 293 345 minecraft:honeycomb_block
fill 42 281 354 42 293 354 minecraft:honeycomb_block
fill 42 281 361 42 308 361 minecraft:honeycomb_block
fill 0 282 349 0 308 349 minecraft:honeycomb_block
fill 8 282 364 8 308 364 minecraft:honeycomb_block
setblock 21 282 322 minecraft:orange_terracotta
setblock 42 282 328 minecraft:orange_terracotta
fill 1 283 323 1 283 326 minecraft:honeycomb_block
setblock 1 283 327 minecraft:yellow_terracotta
fill 1 283 328 1 283 331 minecraft:honeycomb_block
setblock 1 283 332 minecraft:yellow_terracotta
fill 1 283 333 1 283 336 minecraft:honeycomb_block
setblock 1 283 337 minecraft:yellow_terracotta
fill 1 283 338 1 283 341 minecraft:honeycomb_block
setblock 1 283 342 minecraft:yellow_terracotta
fill 1 283 343 1 283 346 minecraft:honeycomb_block
setblock 1 283 347 minecraft:yellow_terracotta
fill 1 283 348 1 283 351 minecraft:honeycomb_block
setblock 1 283 352 minecraft:yellow_terracotta
fill 1 283 353 1 283 356 minecraft:honeycomb_block
setblock 1 283 357 minecraft:yellow_terracotta
fill 1 283 358 1 283 361 minecraft:honeycomb_block
setblock 1 283 362 minecraft:yellow_terracotta
fill 1 283 363 4 283 363 minecraft:honeycomb_block
fill 2 283 323 2 283 325 minecraft:honeycomb_block
fill 2 283 334 2 283 335 minecraft:honeycomb_block
setblock 2 283 336 minecraft:yellow_terracotta
fill 2 283 337 2 283 340 minecraft:honeycomb_block
setblock 2 283 341 minecraft:yellow_terracotta
fill 2 283 342 2 283 345 minecraft:honeycomb_block
setblock 2 283 346 minecraft:yellow_terracotta
setblock 2 283 348 minecraft:brown_terracotta
setblock 2 283 350 minecraft:honeycomb_block
setblock 2 283 351 minecraft:yellow_terracotta
fill 2 283 352 2 283 355 minecraft:honeycomb_block
setblock 2 283 356 minecraft:yellow_terracotta
fill 2 283 357 2 283 360 minecraft:honeycomb_block
setblock 2 283 361 minecraft:yellow_terracotta
fill 2 283 362 5 283 362 minecraft:honeycomb_block
fill 3 283 323 3 283 324 minecraft:honeycomb_block
fill 3 283 338 3 283 339 minecraft:honeycomb_block
setblock 3 283 340 minecraft:yellow_terracotta
fill 3 283 341 3 285 342 minecraft:honeycomb_block
fill 3 283 353 3 283 354 minecraft:honeycomb_block
setblock 3 283 355 minecraft:yellow_terracotta
fill 3 283 356 3 283 359 minecraft:honeycomb_block
setblock 3 283 360 minecraft:yellow_terracotta
fill 3 283 361 6 283 361 minecraft:honeycomb_block
setblock 4 283 323 minecraft:honeycomb_block
setblock 4 283 324 minecraft:yellow_terracotta
fill 4 283 356 4 283 358 minecraft:honeycomb_block
setblock 4 283 359 minecraft:yellow_terracotta
fill 4 283 360 7 283 360 minecraft:honeycomb_block
setblock 5 283 323 minecraft:yellow_terracotta
fill 5 283 324 5 286 324 minecraft:honeycomb_block
setblock 5 283 359 minecraft:honeycomb_block
setblock 5 283 363 minecraft:yellow_terracotta
fill 6 283 323 9 283 323 minecraft:honeycomb_block
setblock 6 283 362 minecraft:yellow_terracotta
fill 6 283 363 9 283 363 minecraft:honeycomb_block
setblock 7 283 361 minecraft:yellow_terracotta
fill 7 283 362 10 283 362 minecraft:honeycomb_block
setblock 8 283 360 minecraft:yellow_terracotta
fill 8 283 361 10 284 361 minecraft:honeycomb_block
setblock 10 283 363 minecraft:yellow_terracotta
setblock 11 283 323 minecraft:honey_block
setblock 11 283 362 minecraft:yellow_terracotta
fill 11 283 363 14 283 363 minecraft:honeycomb_block
fill 12 283 362 12 285 362 minecraft:honeycomb_block
setblock 15 283 363 minecraft:yellow_terracotta
fill 16 283 363 19 283 363 minecraft:honeycomb_block
fill 19 283 362 20 283 362 minecraft:honeycomb_block
setblock 20 283 323 minecraft:yellow_terracotta
setblock 20 283 363 minecraft:yellow_terracotta
fill 21 283 322 21 286 323 minecraft:honeycomb_block
fill 21 283 357 25 286 357 minecraft:brown_terracotta
setblock 21 283 362 minecraft:yellow_terracotta
fill 21 283 363 24 283 363 minecraft:honeycomb_block
fill 22 283 323 24 283 323 minecraft:honeycomb_block
fill 22 283 356 24 286 356 minecraft:brown_terracotta
fill 22 283 358 24 286 358 minecraft:brown_terracotta
setblock 22 283 361 minecraft:yellow_terracotta
fill 22 283 362 25 283 362 minecraft:honeycomb_block
setblock 23 283 324 minecraft:honeycomb_block
fill 23 283 355 23 286 355 minecraft:brown_terracotta
fill 23 283 361 25 284 361 minecraft:honeycomb_block
setblock 24 283 324 minecraft:yellow_terracotta
setblock 25 283 323 minecraft:yellow_terracotta
fill 25 283 324 28 283 324 minecraft:honeycomb_block
setblock 25 283 363 minecraft:yellow_terracotta
fill 26 283 323 29 283 323 minecraft:honeycomb_block
setblock 26 283 362 minecraft:yellow_terracotta
fill 26 283 363 29 283 363 minecraft:honeycomb_block
fill 27 283 362 29 284 362 minecraft:honeycomb_block
setblock 30 283 323 minecraft:yellow_terracotta
setblock 30 283 363 minecraft:yellow_terracotta
fill 31 283 323 34 283 323 minecraft:honeycomb_block
fill 31 283 363 34 283 363 minecraft:honeycomb_block
setblock 35 283 323 minecraft:yellow_terracotta
fill 35 283 337 36 284 337 minecraft:yellow_concrete
setblock 35 283 363 minecraft:yellow_terracotta
fill 36 283 323 39 283 323 minecraft:honeycomb_block
fill 36 283 363 39 283 363 minecraft:honeycomb_block
fill 37 283 362 40 283 362 minecraft:honeycomb_block
setblock 38 283 324 minecraft:honeycomb_block
setblock 39 283 324 minecraft:yellow_terracotta
fill 39 283 361 41 283 361 minecraft:honeycomb_block
setblock 40 283 323 minecraft:yellow_terracotta
fill 40 283 324 40 283 327 minecraft:honeycomb_block
setblock 40 283 328 minecraft:yellow_terracotta
fill 40 283 331 40 283 332 minecraft:honeycomb_block
setblock 40 283 333 minecraft:yellow_terracotta
fill 40 283 334 40 283 337 minecraft:honeycomb_block
setblock 40 283 338 minecraft:yellow_terracotta
fill 40 283 339 40 283 342 minecraft:honeycomb_block
fill 40 283 356 40 283 357 minecraft:honeycomb_block
setblock 40 283 358 minecraft:yellow_terracotta
fill 40 283 359 41 284 360 minecraft:honeycomb_block
setblock 40 283 363 minecraft:yellow_terracotta
fill 41 283 323 41 283 326 minecraft:honeycomb_block
setblock 41 283 327 minecraft:yellow_terracotta
fill 41 283 328 41 283 331 minecraft:honeycomb_block
setblock 41 283 332 minecraft:yellow_terracotta
fill 41 283 333 41 283 336 minecraft:honeycomb_block
setblock 41 283 337 minecraft:yellow_terracotta
fill 41 283 338 41 283 341 minecraft:honeycomb_block
setblock 41 283 342 minecraft:yellow_terracotta
fill 41 283 343 41 284 345 minecraft:honeycomb_block
fill 41 283 353 41 283 356 minecraft:honeycomb_block
setblock 41 283 357 minecraft:yellow_terracotta
fill 41 283 358 41 286 358 minecraft:honeycomb_block
setblock 41 283 362 minecraft:yellow_terracotta
fill 41 283 363 41 286 363 minecraft:honeycomb_block
fill 42 283 328 42 308 328 minecraft:honeycomb_block
setblock 42 283 334 minecraft:yellow_terracotta
setblock 42 283 343 minecraft:orange_terracotta
fill 1 284 323 1 284 325 minecraft:honeycomb_block
setblock 1 284 326 minecraft:yellow_terracotta
fill 1 284 327 1 284 330 minecraft:honeycomb_block
setblock 1 284 331 minecraft:yellow_terracotta
fill 1 284 332 1 284 335 minecraft:honeycomb_block
setblock 1 284 336 minecraft:yellow_terracotta
fill 1 284 337 1 284 340 minecraft:honeycomb_block
setblock 1 284 341 minecraft:yellow_terracotta
fill 1 284 342 1 284 345 minecraft:honeycomb_block
setblock 1 284 346 minecraft:yellow_terracotta
fill 1 284 347 1 284 350 minecraft:honeycomb_block
setblock 1 284 351 minecraft:yellow_terracotta
fill 1 284 352 1 284 355 minecraft:honeycomb_block
setblock 1 284 356 minecraft:yellow_terracotta
fill 1 284 357 1 284 360 minecraft:honeycomb_block
setblock 1 284 361 minecraft:yellow_terracotta
fill 1 284 362 3 284 363 minecraft:honeycomb_block
fill 2 284 323 2 284 324 minecraft:honeycomb_block
setblock 2 284 325 minecraft:yellow_terracotta
fill 2 284 326 2 287 326 minecraft:honeycomb_block
fill 2 284 335 5 284 335 minecraft:yellow_terracotta
fill 2 284 336 2 284 339 minecraft:honeycomb_block
setblock 2 284 340 minecraft:yellow_terracotta
fill 2 284 341 2 284 344 minecraft:honeycomb_block
setblock 2 284 345 minecraft:yellow_terracotta
fill 2 284 346 2 284 349 minecraft:honeycomb_block
setblock 2 284 350 minecraft:yellow_terracotta
fill 2 284 351 2 284 354 minecraft:honeycomb_block
setblock 2 284 355 minecraft:yellow_terracotta
fill 2 284 356 2 284 359 minecraft:honeycomb_block
setblock 2 284 360 minecraft:yellow_terracotta
fill 2 284 361 5 284 361 minecraft:honeycomb_block
setblock 3 284 322 minecraft:orange_terracotta
setblock 3 284 323 minecraft:honeycomb_block
setblock 3 284 324 minecraft:yellow_terracotta
setblock 3 284 325 minecraft:light[level=12]
setblock 3 284 332 minecraft:light[level=12]
fill 3 284 336 5 287 336 minecraft:yellow_terracotta
setblock 3 284 338 minecraft:honeycomb_block
setblock 3 284 339 minecraft:yellow_terracotta
fill 3 284 340 3 287 340 minecraft:honeycomb_block
setblock 3 284 343 minecraft:honeycomb_block
setblock 3 284 344 minecraft:yellow_terracotta
setblock 3 284 346 minecraft:light[level=12]
setblock 3 284 353 minecraft:honeycomb_block
setblock 3 284 354 minecraft:yellow_terracotta
fill 3 284 355 3 284 358 minecraft:honeycomb_block
setblock 3 284 359 minecraft:yellow_terracotta
fill 3 284 360 6 284 360 minecraft:honeycomb_block
setblock 4 284 323 minecraft:yellow_terracotta
fill 4 284 324 4 287 324 minecraft:honeycomb_block
fill 4 284 334 5 300 334 minecraft:yellow_terracotta
fill 4 284 356 4 284 357 minecraft:honeycomb_block
setblock 4 284 358 minecraft:yellow_terracotta
fill 4 284 359 4 287 359 minecraft:honeycomb_block
setblock 4 284 362 minecraft:honeycomb_block
setblock 4 284 363 minecraft:yellow_terracotta
fill 5 284 323 8 284 323 minecraft:honeycomb_block
setblock 5 284 362 minecraft:yellow_terracotta
fill 5 284 363 8 284 363 minecraft:honeycomb_block
fill 6 284 324 6 285 324 minecraft:honeycomb_block
setblock 6 284 361 minecraft:yellow_terracotta
fill 6 284 362 9 284 362 minecraft:honeycomb_block
setblock 7 284 360 minecraft:yellow_terracotta
fill 7 284 361 7 287 361 minecraft:honeycomb_block
setblock 9 284 323 minecraft:yellow_terracotta
setblock 9 284 363 minecraft:yellow_terracotta
setblock 10 284 325 minecraft:light[level=12]
setblock 10 284 332 minecraft:light[level=12]
setblock 10 284 339 minecraft:light[level=12]
setblock 10 284 346 minecraft:light[level=12]
setblock 10 284 353 minecraft:light[level=12]
setblock 10 284 360 minecraft:light[level=12]
setblock 10 284 362 minecraft:yellow_terracotta
fill 10 284 363 13 284 363 minecraft:honeycomb_block
fill 11 284 362 11 286 362 minecraft:honeycomb_block
setblock 14 284 363 minecraft:yellow_terracotta
fill 15 284 363 18 284 363 minecraft:honeycomb_block
setblock 17 284 325 minecraft:light[level=12]
setblock 17 284 332 minecraft:light[level=12]
setblock 17 284 339 minecraft:light[level=12]
setblock 17 284 346 minecraft:light[level=12]
setblock 17 284 353 minecraft:light[level=12]
setblock 17 284 360 minecraft:light[level=12]
fill 17 284 362 19 284 362 minecraft:honeycomb_block
setblock 18 284 323 minecraft:honeycomb_block
setblock 19 284 323 minecraft:yellow_terracotta
setblock 19 284 363 minecraft:yellow_terracotta
fill 20 284 323 20 287 323 minecraft:honeycomb_block
setblock 20 284 362 minecraft:yellow_terracotta
fill 20 284 363 23 284 363 minecraft:honeycomb_block
fill 21 284 324 22 284 324 minecraft:honeycomb_block
fill 21 284 356 21 286 356 minecraft:brown_terracotta
fill 21 284 358 21 286 358 minecraft:brown_terracotta
setblock 21 284 361 minecraft:yellow_terracotta
fill 21 284 362 24 284 362 minecraft:honeycomb_block
setblock 22 284 322 minecraft:yellow_concrete
fill 22 284 323 23 284 323 minecraft:honeycomb_block
fill 22 284 355 22 286 355 minecraft:brown_terracotta
fill 22 284 359 24 286 359 minecraft:brown_terracotta
fill 22 284 361 22 286 361 minecraft:honeycomb_block
setblock 23 284 324 minecraft:yellow_terracotta
setblock 24 284 323 minecraft:yellow_terracotta
fill 24 284 324 27 284 324 minecraft:honeycomb_block
setblock 24 284 325 minecraft:light[level=12]
setblock 24 284 332 minecraft:light[level=12]
setblock 24 284 339 minecraft:light[level=12]
setblock 24 284 346 minecraft:light[level=12]
setblock 24 284 353 minecraft:light[level=12]
fill 24 284 355 24 286 355 minecraft:brown_terracotta
setblock 24 284 360 minecraft:light[level=12]
setblock 24 284 363 minecraft:yellow_terracotta
fill 25 284 323 28 284 323 minecraft:honeycomb_block
fill 25 284 356 25 286 356 minecraft:brown_terracotta
fill 25 284 358 25 286 358 minecraft:brown_terracotta
setblock 25 284 362 minecraft:yellow_terracotta
fill 25 284 363 28 284 363 minecraft:honeycomb_block
fill 26 284 362 26 287 362 minecraft:honeycomb_block
setblock 28 284 324 minecraft:yellow_terracotta
setblock 29 284 323 minecraft:yellow_terracotta
fill 29 284 324 29 287 324 minecraft:honeycomb_block
setblock 29 284 363 minecraft:yellow_terracotta
fill 30 284 323 33 284 323 minecraft:honeycomb_block
fill 30 284 363 33 284 363 minecraft:honeycomb_block
setblock 31 284 325 minecraft:light[level=12]
setblock 31 284 332 minecraft:light[level=12]
setblock 31 284 339 minecraft:light[level=12]
setblock 31 284 346 minecraft:light[level=12]
setblock 31 284 353 minecraft:light[level=12]
setblock 31 284 360 minecraft:light[level=12]
setblock 34 284 323 minecraft:yellow_terracotta
setblock 34 284 363 minecraft:yellow_terracotta
fill 35 284 323 38 284 323 minecraft:honeycomb_block
setblock 35 284 362 minecraft:yellow_terracotta
fill 35 284 363 38 284 363 minecraft:honeycomb_block
fill 36 284 324 37 284 324 minecraft:honeycomb_block
fill 36 284 362 39 284 362 minecraft:honeycomb_block
setblock 38 284 324 minecraft:yellow_terracotta
setblock 38 284 325 minecraft:light[level=12]
setblock 38 284 332 minecraft:light[level=12]
setblock 38 284 339 minecraft:light[level=12]
setblock 38 284 346 minecraft:light[level=12]
setblock 38 284 353 minecraft:light[level=12]
setblock 38 284 360 minecraft:light[level=12]
fill 38 284 361 40 284 361 minecraft:honeycomb_block
setblock 39 284 323 minecraft:yellow_terracotta
fill 39 284 324 41 285 324 minecraft:honeycomb_block
fill 39 284 359 39 286 360 minecraft:honeycomb_block
setblock 39 284 363 minecraft:yellow_terracotta
fill 40 284 323 41 286 323 minecraft:honeycomb_block
fill 40 284 325 40 284 326 minecraft:honeycomb_block
setblock 40 284 327 minecraft:yellow_terracotta
fill 40 284 328 40 284 331 minecraft:honeycomb_block
setblock 40 284 332 minecraft:yellow_terracotta
fill 40 284 333 40 284 336 minecraft:honeycomb_block
setblock 40 284 337 minecraft:yellow_terracotta
fill 40 284 338 40 284 341 minecraft:honeycomb_block
setblock 40 284 342 minecraft:yellow_terracotta
fill 40 284 343 40 287 343 minecraft:honeycomb_block
setblock 40 284 356 minecraft:honeycomb_block
setblock 40 284 357 minecraft:yellow_terracotta
fill 40 284 358 40 287 358 minecraft:honeycomb_block
setblock 40 284 362 minecraft:yellow_terracotta
fill 40 284 363 40 287 363 minecraft:honeycomb_block
setblock 41 284 325 minecraft:honeycomb_block
setblock 41 284 326 minecraft:yellow_terracotta
fill 41 284 327 41 284 330 minecraft:honeycomb_block
setblock 41 284 331 minecraft:yellow_terracotta
fill 41 284 332 41 284 335 minecraft:honeycomb_block
setblock 41 284 336 minecraft:yellow_terracotta
fill 41 284 337 41 284 340 minecraft:honeycomb_block
setblock 41 284 341 minecraft:yellow_terracotta
fill 41 284 342 41 287 342 minecraft:honeycomb_block
setblock 41 284 346 minecraft:yellow_terracotta
fill 41 284 347 41 286 348 minecraft:honeycomb_block
setblock 41 284 350 minecraft:honey_block
fill 41 284 352 41 284 355 minecraft:honeycomb_block
setblock 41 284 356 minecraft:yellow_terracotta
fill 41 284 357 41 287 357 minecraft:honeycomb_block
setblock 41 284 361 minecraft:yellow_terracotta
fill 41 284 362 41 287 362 minecraft:honeycomb_block
fill 42 284 334 42 300 334 minecraft:honeycomb_block
fill 42 284 343 42 308 343 minecraft:honeycomb_block
fill 1 285 323 1 285 324 minecraft:honeycomb_block
setblock 1 285 325 minecraft:yellow_terracotta
fill 1 285 326 1 285 329 minecraft:honeycomb_block
setblock 1 285 330 minecraft:yellow_terracotta
fill 1 285 331 1 285 334 minecraft:honeycomb_block
setblock 1 285 335 minecraft:yellow_terracotta
fill 1 285 336 1 285 339 minecraft:honeycomb_block
setblock 1 285 340 minecraft:yellow_terracotta
fill 1 285 341 1 285 344 minecraft:honeycomb_block
setblock 1 285 345 minecraft:yellow_terracotta
fill 1 285 346 1 285 349 minecraft:honeycomb_block
setblock 1 285 350 minecraft:yellow_terracotta
fill 1 285 351 1 285 354 minecraft:honeycomb_block
setblock 1 285 355 minecraft:yellow_terracotta
fill 1 285 356 1 285 359 minecraft:honeycomb_block
setblock 1 285 360 minecraft:yellow_terracotta
fill 1 285 361 2 285 363 minecraft:honeycomb_block
setblock 2 285 323 minecraft:honeycomb_block
setblock 2 285 324 minecraft:yellow_terracotta
fill 2 285 325 2 288 325 minecraft:honeycomb_block
fill 2 285 335 2 285 338 minecraft:honeycomb_block
setblock 2 285 339 minecraft:yellow_terracotta
fill 2 285 340 2 285 343 minecraft:honeycomb_block
setblock 2 285 344 minecraft:yellow_terracotta
fill 2 285 345 2 285 348 minecraft:honeycomb_block
setblock 2 285 349 minecraft:yellow_terracotta
fill 2 285 350 2 285 353 minecraft:honeycomb_block
setblock 2 285 354 minecraft:yellow_terracotta
fill 2 285 355 2 285 358 minecraft:honeycomb_block
setblock 2 285 359 minecraft:yellow_terracotta
fill 2 285 360 5 285 360 minecraft:honeycomb_block
fill 3 285 322 3 290 322 minecraft:honeycomb_block
setblock 3 285 323 minecraft:yellow_terracotta
fill 3 285 324 3 288 324 minecraft:honeycomb_block
fill 3 285 334 3 286 334 minecraft:brown_terracotta
fill 3 285 335 5 300 335 minecraft:yellow_terracotta
setblock 3 285 338 minecraft:yellow_terracotta
fill 3 285 339 3 286 339 minecraft:honeycomb_block
setblock 3 285 343 minecraft:yellow_terracotta
fill 3 285 344 3 286 346 minecraft:honeycomb_block
setblock 3 285 353 minecraft:yellow_terracotta
fill 3 285 354 3 285 357 minecraft:honeycomb_block
setblock 3 285 358 minecraft:yellow_terracotta
fill 3 285 359 3 288 359 minecraft:honeycomb_block
fill 3 285 361 3 285 362 minecraft:honeycomb_block
setblock 3 285 363 minecraft:yellow_terracotta
fill 4 285 323 7 285 323 minecraft:honeycomb_block
fill 4 285 333 5 286 333 minecraft:brown_terracotta
fill 4 285 337 5 286 337 minecraft:brown_terracotta
setblock 4 285 356 minecraft:honeycomb_block
setblock 4 285 357 minecraft:yellow_terracotta
fill 4 285 358 4 286 358 minecraft:honeycomb_block
setblock 4 285 361 minecraft:honeycomb_block
setblock 4 285 362 minecraft:yellow_terracotta
fill 4 285 363 7 285 363 minecraft:honeycomb_block
setblock 5 285 361 minecraft:yellow_terracotta
fill 5 285 362 8 285 362 minecraft:honeycomb_block
fill 6 285 334 6 286 336 minecraft:brown_terracotta
setblock 6 285 360 minecraft:yellow_terracotta
fill 6 285 361 6 287 361 minecraft:honeycomb_block
setblock 7 285 360 minecraft:honeycomb_block
setblock 8 285 323 minecraft:yellow_terracotta
fill 8 285 361 9 285 361 minecraft:honeycomb_block
setblock 8 285 363 minecraft:yellow_terracotta
fill 9 285 323 9 286 323 minecraft:honeycomb_block
setblock 9 285 362 minecraft:yellow_terracotta
fill 9 285 363 12 285 363 minecraft:honeycomb_block
fill 10 285 362 10 286 362 minecraft:honeycomb_block
setblock 12 285 322 minecraft:orange_terracotta
setblock 13 285 363 minecraft:yellow_terracotta
fill 14 285 363 17 285 363 minecraft:honeycomb_block
fill 16 285 362 18 285 362 minecraft:honeycomb_block
setblock 17 285 323 minecraft:honeycomb_block
setblock 18 285 323 minecraft:yellow_terracotta
setblock 18 285 363 minecraft:yellow_terracotta
fill 19 285 323 19 288 323 minecraft:honeycomb_block
setblock 19 285 362 minecraft:yellow_terracotta
fill 19 285 363 22 285 363 minecraft:honeycomb_block
fill 20 285 324 21 285 324 minecraft:honeycomb_block
fill 20 285 362 23 285 362 minecraft:honeycomb_block
fill 21 285 355 21 286 355 minecraft:brown_terracotta
fill 21 285 359 21 286 359 minecraft:brown_terracotta
fill 21 285 361 21 286 361 minecraft:honeycomb_block
fill 22 285 322 22 285 323 minecraft:honeycomb_block
setblock 22 285 324 minecraft:yellow_terracotta
setblock 23 285 323 minecraft:yellow_terracotta
fill 23 285 324 26 285 324 minecraft:honeycomb_block
fill 23 285 354 23 286 354 minecraft:brown_terracotta
fill 23 285 361 24 285 361 minecraft:honeycomb_block
setblock 23 285 363 minecraft:yellow_terracotta
fill 24 285 323 27 285 323 minecraft:honeycomb_block
setblock 24 285 362 minecraft:yellow_terracotta
fill 24 285 363 27 285 363 minecraft:honeycomb_block
fill 25 285 355 25 286 355 minecraft:brown_terracotta
fill 25 285 359 25 286 359 minecraft:brown_terracotta
fill 25 285 362 25 288 362 minecraft:honeycomb_block
setblock 27 285 324 minecraft:yellow_terracotta
fill 27 285 362 28 285 362 minecraft:honeycomb_block
setblock 28 285 323 minecraft:yellow_terracotta
fill 28 285 324 28 288 324 minecraft:honeycomb_block
setblock 28 285 363 minecraft:yellow_terracotta
fill 29 285 323 32 285 323 minecraft:honeycomb_block
setblock 29 285 362 minecraft:yellow_terracotta
fill 29 285 363 32 285 363 minecraft:honeycomb_block
fill 30 285 324 31 285 324 minecraft:honeycomb_block
setblock 32 285 324 minecraft:yellow_terracotta
setblock 33 285 323 minecraft:yellow_terracotta
fill 33 285 324 36 285 324 minecraft:honeycomb_block
setblock 33 285 363 minecraft:yellow_terracotta
fill 34 285 323 37 285 323 minecraft:honeycomb_block
fill 34 285 363 37 285 363 minecraft:honeycomb_block
fill 35 285 346 38 300 349 minecraft:yellow_terracotta
fill 35 285 362 38 285 362 minecraft:honeycomb_block
fill 36 285 345 37 300 345 minecraft:yellow_terracotta
setblock 37 285 324 minecraft:yellow_terracotta
setblock 38 285 323 minecraft:yellow_terracotta
fill 38 285 324 38 288 324 minecraft:honeycomb_block
fill 38 285 361 39 285 361 minecraft:honeycomb_block
setblock 38 285 363 minecraft:yellow_terracotta
fill 39 285 323 39 288 323 minecraft:honeycomb_block
fill 39 285 325 40 285 325 minecraft:honeycomb_block
setblock 39 285 362 minecraft:yellow_terracotta
fill 39 285 363 39 288 363 minecraft:honeycomb_block
setblock 40 285 326 minecraft:yellow_terracotta
fill 40 285 327 40 285 330 minecraft:honeycomb_block
setblock 40 285 331 minecraft:yellow_terracotta
fill 40 285 332 40 285 335 minecraft:honeycomb_block
setblock 40 285 336 minecraft:yellow_terracotta
fill 40 285 337 40 285 340 minecraft:honeycomb_block
setblock 40 285 341 minecraft:yellow_terracotta
fill 40 285 342 40 288 342 minecraft:honeycomb_block
fill 40 285 344 41 285 344 minecraft:honeycomb_block
setblock 40 285 356 minecraft:yellow_terracotta
fill 40 285 357 40 288 357 minecraft:honeycomb_block
fill 40 285 359 40 285 360 minecraft:honeycomb_block
setblock 40 285 361 minecraft:yellow_terracotta
fill 40 285 362 40 288 362 minecraft:honeycomb_block
setblock 41 285 325 minecraft:yellow_terracotta
fill 41 285 326 41 285 329 minecraft:honeycomb_block
setblock 41 285 330 minecraft:yellow_terracotta
fill 41 285 331 41 285 334 minecraft:honeycomb_block
setblock 41 285 335 minecraft:yellow_terracotta
fill 41 285 336 41 285 339 minecraft:honeycomb_block
setblock 41 285 340 minecraft:yellow_terracotta
fill 41 285 341 41 288 341 minecraft:honeycomb_block
fill 41 285 343 41 286 343 minecraft:honeycomb_block
setblock 41 285 345 minecraft:yellow_terracotta
fill 41 285 346 41 288 346 minecraft:honeycomb_block
setblock 41 285 349 minecraft:honeycomb_block
setblock 41 285 350 minecraft:yellow_terracotta
fill 41 285 351 41 285 354 minecraft:honeycomb_block
setblock 41 285 355 minecraft:yellow_terracotta
fill 41 285 356 41 288 356 minecraft:honeycomb_block
setblock 41 285 359 minecraft:honeycomb_block
setblock 41 285 360 minecraft:yellow_terracotta
fill 41 285 361 41 288 361 minecraft:honeycomb_block
setblock 42 285 347 minecraft:yellow_concrete
setblock 0 286 356 minecraft:yellow_terracotta
setblock 1 286 323 minecraft:honeycomb_block
setblock 1 286 324 minecraft:yellow_terracotta
fill 1 286 325 1 286 328 minecraft:honeycomb_block
setblock 1 286 329 minecraft:yellow_terracotta
fill 1 286 330 1 286 333 minecraft:honeycomb_block
setblock 1 286 334 minecraft:yellow_terracotta
fill 1 286 335 1 286 338 minecraft:honeycomb_block
setblock 1 286 339 minecraft:yellow_terracotta
fill 1 286 340 1 286 343 minecraft:honeycomb_block
setblock 1 286 344 minecraft:yellow_terracotta
fill 1 286 345 1 286 348 minecraft:honeycomb_block
setblock 1 286 349 minecraft:yellow_terracotta
fill 1 286 350 1 286 353 minecraft:honeycomb_block
setblock 1 286 354 minecraft:yellow_terracotta
fill 1 286 355 1 286 358 minecraft:honeycomb_block
setblock 1 286 359 minecraft:yellow_terracotta
fill 1 286 360 1 286 363 minecraft:honeycomb_block
setblock 2 286 323 minecraft:yellow_terracotta
fill 2 286 324 2 289 324 minecraft:honeycomb_block
fill 2 286 333 2 286 335 minecraft:brown_terracotta
fill 2 286 336 2 286 337 minecraft:honeycomb_block
setblock 2 286 338 minecraft:yellow_terracotta
fill 2 286 339 2 286 342 minecraft:honeycomb_block
setblock 2 286 343 minecraft:yellow_terracotta
fill 2 286 344 2 286 347 minecraft:honeycomb_block
setblock 2 286 348 minecraft:yellow_terracotta
fill 2 286 349 2 286 352 minecraft:honeycomb_block
setblock 2 286 353 minecraft:yellow_terracotta
fill 2 286 354 2 286 357 minecraft:honeycomb_block
setblock 2 286 358 minecraft:yellow_terracotta
fill 2 286 359 2 286 362 minecraft:honeycomb_block
setblock 2 286 363 minecraft:yellow_terracotta
fill 3 286 323 6 286 323 minecraft:honeycomb_block
setblock 3 286 333 minecraft:brown_terracotta
setblock 3 286 337 minecraft:brown_terracotta
setblock 3 286 341 minecraft:honeycomb_block
setblock 3 286 342 minecraft:yellow_terracotta
fill 3 286 343 3 289 343 minecraft:honeycomb_block
setblock 3 286 347 minecraft:yellow_terracotta
fill 3 286 348 3 289 348 minecraft:honeycomb_block
fill 3 286 354 3 286 356 minecraft:honeycomb_block
setblock 3 286 357 minecraft:yellow_terracotta
fill 3 286 358 3 288 358 minecraft:honeycomb_block
fill 3 286 360 3 286 361 minecraft:honeycomb_block
setblock 3 286 362 minecraft:yellow_terracotta
fill 3 286 363 6 286 363 minecraft:honeycomb_block
setblock 4 286 338 minecraft:brown_terracotta
setblock 4 286 360 minecraft:honeycomb_block
setblock 4 286 361 minecraft:yellow_terracotta
fill 4 286 362 7 286 362 minecraft:honeycomb_block
setblock 5 286 360 minecraft:yellow_terracotta
fill 5 286 361 5 288 361 minecraft:honeycomb_block
setblock 6 286 324 minecraft:yellow_terracotta
setblock 6 286 333 minecraft:brown_terracotta
setblock 6 286 337 minecraft:brown_terracotta
setblock 6 286 360 minecraft:honeycomb_block
setblock 7 286 323 minecraft:yellow_terracotta
fill 7 286 335 7 286 336 minecraft:brown_terracotta
setblock 7 286 363 minecraft:yellow_terracotta
fill 8 286 323 8 288 323 minecraft:honeycomb_block
setblock 8 286 361 minecraft:honeycomb_block
setblock 8 286 362 minecraft:yellow_terracotta
fill 8 286 363 11 286 363 minecraft:honeycomb_block
fill 9 286 362 9 287 362 minecraft:honeycomb_block
fill 12 286 322 12 308 322 minecraft:honeycomb_block
setblock 12 286 323 minecraft:honey_block
setblock 12 286 363 minecraft:yellow_terracotta
fill 13 286 363 16 286 363 minecraft:honeycomb_block
setblock 16 286 323 minecraft:honeycomb_block
fill 16 286 362 17 286 362 minecraft:honeycomb_block
setblock 17 286 323 minecraft:yellow_terracotta
setblock 17 286 363 minecraft:yellow_terracotta
fill 18 286 323 18 289 323 minecraft:honeycomb_block
setblock 18 286 362 minecraft:yellow_terracotta
fill 18 286 363 21 286 363 minecraft:honeycomb_block
fill 19 286 324 20 286 324 minecraft:honeycomb_block
fill 19 286 362 22 286 362 minecraft:honeycomb_block
fill 20 286 356 20 286 358 minecraft:brown_terracotta
setblock 21 286 324 minecraft:yellow_terracotta
fill 22 286 322 22 308 322 minecraft:honeycomb_block
setblock 22 286 323 minecraft:yellow_terracotta
fill 22 286 324 25 286 324 minecraft:honeycomb_block
setblock 22 286 354 minecraft:brown_terracotta
fill 22 286 360 24 286 360 minecraft:brown_terracotta
setblock 22 286 363 minecraft:yellow_terracotta
fill 23 286 323 26 286 323 minecraft:honeycomb_block
fill 23 286 325 24 286 325 minecraft:honeycomb_block
setblock 23 286 361 minecraft:honeycomb_block
setblock 23 286 362 minecraft:yellow_terracotta
fill 23 286 363 26 286 363 minecraft:honeycomb_block
setblock 23 286 364 minecraft:yellow_terracotta
setblock 24 286 354 minecraft:brown_terracotta
fill 24 286 362 24 288 362 minecraft:honeycomb_block
setblock 25 286 322 minecraft:yellow_terracotta
setblock 25 286 325 minecraft:yellow_terracotta
setblock 26 286 324 minecraft:yellow_terracotta
fill 26 286 356 26 286 358 minecraft:brown_terracotta
setblock 27 286 323 minecraft:yellow_terracotta
fill 27 286 324 27 289 324 minecraft:honeycomb_block
setblock 27 286 362 minecraft:honeycomb_block
setblock 27 286 363 minecraft:yellow_terracotta
setblock 27 286 364 minecraft:yellow_concrete
fill 28 286 323 31 286 323 minecraft:honeycomb_block
setblock 28 286 362 minecraft:yellow_terracotta
fill 28 286 363 31 286 363 minecraft:honeycomb_block
setblock 30 286 324 minecraft:honeycomb_block
setblock 31 286 324 minecraft:yellow_terracotta
setblock 32 286 323 minecraft:yellow_terracotta
fill 32 286 324 35 286 324 minecraft:honeycomb_block
setblock 32 286 363 minecraft:yellow_terracotta
fill 33 286 323 36 286 323 minecraft:honeycomb_block
fill 33 286 338 33 287 338 minecraft:ochre_froglight
fill 33 286 363 36 286 363 minecraft:honeycomb_block
fill 34 286 345 34 287 349 minecraft:brown_terracotta
fill 34 286 362 37 286 362 minecraft:honeycomb_block
fill 35 286 345 35 287 345 minecraft:brown_terracotta
fill 35 286 350 38 287 350 minecraft:brown_terracotta
setblock 36 286 324 minecraft:yellow_terracotta
fill 36 286 344 37 287 344 minecraft:brown_terracotta
setblock 37 286 323 minecraft:yellow_terracotta
fill 37 286 324 37 289 324 minecraft:honeycomb_block
fill 37 286 361 38 286 361 minecraft:honeycomb_block
setblock 37 286 363 minecraft:yellow_terracotta
fill 38 286 323 38 289 323 minecraft:honeycomb_block
fill 38 286 325 39 286 325 minecraft:honeycomb_block
fill 38 286 345 39 287 345 minecraft:brown_terracotta
setblock 38 286 362 minecraft:yellow_terracotta
fill 38 286 363 38 289 363 minecraft:honeycomb_block
fill 39 286 324 40 286 324 minecraft:honeycomb_block
setblock 39 286 326 minecraft:yellow_terracotta
fill 39 286 346 39 287 349 minecraft:brown_terracotta
setblock 39 286 361 minecraft:yellow_terracotta
fill 39 286 362 39 289 362 minecraft:honeycomb_block
setblock 40 286 322 minecraft:yellow_concrete
setblock 40 286 325 minecraft:yellow_terracotta
fill 40 286 326 40 286 329 minecraft:honeycomb_block
setblock 40 286 330 minecraft:yellow_terracotta
fill 40 286 331 41 286 331 minecraft:honeycomb_block
fill 40 286 333 40 286 334 minecraft:honeycomb_block
setblock 40 286 335 minecraft:yellow_terracotta
fill 40 286 336 40 286 339 minecraft:honeycomb_block
setblock 40 286 340 minecraft:yellow_terracotta
fill 40 286 341 40 289 341 minecraft:honeycomb_block
setblock 40 286 344 minecraft:honeycomb_block
setblock 40 286 345 minecraft:yellow_terracotta
fill 40 286 356 40 287 356 minecraft:honeycomb_block
setblock 40 286 359 minecraft:honeycomb_block
setblock 40 286 360 minecraft:yellow_terracotta
fill 40 286 361 40 289 361 minecraft:honeycomb_block
setblock 41 286 324 minecraft:yellow_terracotta
fill 41 286 325 41 286 328 minecraft:honeycomb_block
setblock 41 286 329 minecraft:yellow_terracotta
fill 41 286 330 41 289 330 minecraft:honeycomb_block
fill 41 286 332 41 286 333 minecraft:honeycomb_block
setblock 41 286 334 minecraft:yellow_terracotta
fill 41 286 335 41 286 338 minecraft:honeycomb_block
setblock 41 286 339 minecraft:yellow_terracotta
fill 41 286 340 41 289 340 minecraft:honeycomb_block
setblock 41 286 344 minecraft:yellow_terracotta
fill 41 286 345 41 289 345 minecraft:honeycomb_block
setblock 41 286 349 minecraft:yellow_terracotta
fill 41 286 350 41 286 353 minecraft:honeycomb_block
setblock 41 286 354 minecraft:yellow_terracotta
fill 41 286 355 41 289 355 minecraft:honeycomb_block
setblock 41 286 359 minecraft:yellow_terracotta
fill 41 286 360 41 289 360 minecraft:honeycomb_block
fill 42 286 347 42 308 347 minecraft:honeycomb_block
fill 0 287 356 2 287 356 minecraft:honeycomb_block
setblock 1 287 323 minecraft:yellow_terracotta
fill 1 287 324 1 287 327 minecraft:honeycomb_block
setblock 1 287 328 minecraft:yellow_terracotta
fill 1 287 329 1 287 330 minecraft:honeycomb_block
setblock 1 287 333 minecraft:yellow_terracotta
fill 1 287 334 1 287 337 minecraft:honeycomb_block
setblock 1 287 338 minecraft:yellow_terracotta
fill 1 287 339 1 287 342 minecraft:honeycomb_block
setblock 1 287 343 minecraft:yellow_terracotta
fill 1 287 344 1 287 347 minecraft:honeycomb_block
setblock 1 287 348 minecraft:yellow_terracotta
fill 1 287 349 1 287 352 minecraft:honeycomb_block
setblock 1 287 353 minecraft:yellow_terracotta
fill 1 287 354 2 288 355 minecraft:honeycomb_block
setblock 1 287 357 minecraft:honeycomb_block
setblock 1 287 358 minecraft:yellow_terracotta
fill 1 287 359 1 287 362 minecraft:honeycomb_block
setblock 1 287 363 minecraft:yellow_terracotta
fill 2 287 323 5 287 323 minecraft:honeycomb_block
fill 2 287 333 2 291 333 minecraft:brown_terracotta
setblock 2 287 337 minecraft:yellow_terracotta
fill 2 287 338 2 287 341 minecraft:honeycomb_block
setblock 2 287 342 minecraft:yellow_terracotta
fill 2 287 343 2 287 346 minecraft:honeycomb_block
setblock 2 287 347 minecraft:yellow_terracotta
fill 2 287 348 2 287 351 minecraft:honeycomb_block
setblock 2 287 352 minecraft:yellow_terracotta
fill 2 287 353 2 290 353 minecraft:honeycomb_block
setblock 2 287 357 minecraft:yellow_terracotta
fill 2 287 358 2 287 361 minecraft:honeycomb_block
setblock 2 287 362 minecraft:yellow_terracotta
fill 2 287 363 5 287 363 minecraft:honeycomb_block
fill 3 287 333 3 300 334 minecraft:yellow_terracotta
setblock 3 287 341 minecraft:yellow_terracotta
fill 3 287 342 3 289 342 minecraft:honeycomb_block
fill 3 287 344 3 287 345 minecraft:honeycomb_block
setblock 3 287 346 minecraft:yellow_terracotta
fill 3 287 347 3 290 347 minecraft:honeycomb_block
setblock 3 287 355 minecraft:honeycomb_block
fill 3 287 356 3 300 356 minecraft:yellow_terracotta
fill 3 287 357 3 288 357 minecraft:honeycomb_block
setblock 3 287 360 minecraft:honeycomb_block
setblock 3 287 361 minecraft:yellow_terracotta
fill 3 287 362 6 287 362 minecraft:honeycomb_block
fill 4 287 332 5 300 333 minecraft:yellow_terracotta
setblock 4 287 360 minecraft:yellow_terracotta
fill 4 287 361 4 289 361 minecraft:honeycomb_block
schedule function dropper:buildpart/72_11 1t
