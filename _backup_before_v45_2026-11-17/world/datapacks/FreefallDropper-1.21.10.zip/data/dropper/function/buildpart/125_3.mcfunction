fill 262 289 540 263 289 540 minecraft:purple_concrete
fill 262 289 541 275 289 541 minecraft:obsidian
fill 263 289 523 275 289 523 minecraft:obsidian
setblock 263 289 524 minecraft:purple_concrete
fill 263 289 539 264 289 539 minecraft:purple_concrete
fill 264 289 524 275 289 524 minecraft:obsidian
setblock 264 289 525 minecraft:purple_concrete
setblock 264 289 538 minecraft:purple_concrete
fill 264 289 540 275 289 540 minecraft:obsidian
fill 265 289 525 275 289 525 minecraft:obsidian
fill 265 289 526 265 289 527 minecraft:purple_concrete
setblock 265 289 537 minecraft:purple_concrete
fill 265 289 538 275 289 539 minecraft:obsidian
fill 266 289 526 275 289 527 minecraft:obsidian
fill 266 289 528 266 289 536 minecraft:purple_concrete
fill 266 289 537 275 289 537 minecraft:obsidian
fill 267 289 528 275 289 531 minecraft:obsidian
fill 267 289 533 275 289 536 minecraft:obsidian
setblock 269 289 512 minecraft:black_concrete
setblock 269 289 550 minecraft:black_concrete
setblock 270 289 513 minecraft:black_concrete
setblock 270 289 549 minecraft:black_concrete
setblock 271 289 514 minecraft:black_concrete
setblock 271 289 548 minecraft:black_concrete
fill 272 289 515 272 290 515 minecraft:black_concrete
fill 272 289 547 272 290 547 minecraft:black_concrete
setblock 273 289 516 minecraft:black_concrete
setblock 273 289 546 minecraft:black_concrete
setblock 274 289 517 minecraft:black_concrete
setblock 274 289 545 minecraft:black_concrete
setblock 274 289 552 minecraft:crying_obsidian
setblock 275 289 518 minecraft:black_concrete
setblock 275 289 544 minecraft:black_concrete
fill 276 289 519 276 289 543 minecraft:black_concrete
fill 235 290 520 235 307 520 minecraft:black_concrete
setblock 235 290 551 minecraft:amethyst_block
fill 236 290 532 236 290 541 minecraft:black_concrete
fill 237 290 519 237 290 520 minecraft:black_concrete
fill 237 290 521 243 290 541 minecraft:obsidian
fill 237 290 542 237 290 543 minecraft:black_concrete
setblock 238 290 518 minecraft:black_concrete
fill 238 290 519 252 290 520 minecraft:obsidian
fill 238 290 542 249 290 543 minecraft:obsidian
setblock 238 290 544 minecraft:black_concrete
setblock 239 290 517 minecraft:black_concrete
fill 239 290 518 273 290 518 minecraft:obsidian
fill 239 290 544 273 290 544 minecraft:obsidian
setblock 239 290 545 minecraft:black_concrete
setblock 240 290 516 minecraft:black_concrete
fill 240 290 517 272 290 517 minecraft:obsidian
fill 240 290 545 272 290 545 minecraft:obsidian
setblock 240 290 546 minecraft:black_concrete
setblock 241 290 515 minecraft:black_concrete
fill 241 290 516 271 290 516 minecraft:obsidian
fill 241 290 546 271 290 546 minecraft:obsidian
setblock 241 290 547 minecraft:black_concrete
setblock 242 290 514 minecraft:black_concrete
fill 242 290 515 270 290 515 minecraft:obsidian
fill 242 290 547 270 290 547 minecraft:obsidian
setblock 242 290 548 minecraft:black_concrete
setblock 243 290 510 minecraft:white_concrete
setblock 243 290 513 minecraft:black_concrete
fill 243 290 514 269 290 514 minecraft:obsidian
fill 243 290 548 269 290 548 minecraft:obsidian
setblock 243 290 549 minecraft:black_concrete
fill 244 290 512 245 290 512 minecraft:black_concrete
fill 244 290 513 268 290 513 minecraft:obsidian
fill 244 290 521 244 290 528 minecraft:obsidian
fill 244 290 529 244 290 534 minecraft:purple_concrete
fill 244 290 535 244 290 541 minecraft:obsidian
fill 244 290 549 268 290 549 minecraft:obsidian
fill 244 290 550 245 290 550 minecraft:black_concrete
fill 245 290 521 245 290 526 minecraft:obsidian
fill 245 290 527 245 290 528 minecraft:purple_concrete
fill 245 290 535 245 290 537 minecraft:purple_concrete
fill 245 290 538 245 290 541 minecraft:obsidian
fill 245 290 552 245 307 552 minecraft:black_concrete
setblock 246 290 510 minecraft:white_concrete
fill 246 290 511 266 290 511 minecraft:black_concrete
fill 246 290 512 266 290 512 minecraft:obsidian
fill 246 290 521 246 290 524 minecraft:obsidian
fill 246 290 525 246 290 526 minecraft:purple_concrete
setblock 246 290 538 minecraft:purple_concrete
fill 246 290 539 246 290 541 minecraft:obsidian
fill 246 290 550 266 290 550 minecraft:obsidian
fill 246 290 551 266 290 551 minecraft:black_concrete
fill 247 290 521 247 290 523 minecraft:obsidian
setblock 247 290 524 minecraft:purple_concrete
setblock 247 290 539 minecraft:purple_concrete
fill 247 290 540 247 290 541 minecraft:obsidian
fill 248 290 521 248 290 522 minecraft:obsidian
setblock 248 290 523 minecraft:purple_concrete
setblock 248 290 540 minecraft:purple_concrete
setblock 248 290 541 minecraft:obsidian
setblock 249 290 521 minecraft:obsidian
fill 249 290 522 250 290 522 minecraft:purple_concrete
setblock 249 290 541 minecraft:purple_concrete
fill 250 290 521 252 290 521 minecraft:purple_concrete
fill 250 290 542 251 290 542 minecraft:purple_concrete
fill 250 290 543 251 290 543 minecraft:obsidian
fill 252 290 543 254 290 543 minecraft:purple_concrete
fill 253 290 519 274 290 519 minecraft:obsidian
fill 253 290 520 259 290 520 minecraft:purple_concrete
fill 257 290 543 259 290 543 minecraft:purple_concrete
fill 260 290 520 274 290 520 minecraft:obsidian
fill 260 290 521 261 290 521 minecraft:purple_concrete
fill 260 290 542 261 290 542 minecraft:purple_concrete
fill 260 290 543 274 290 543 minecraft:obsidian
fill 262 290 521 275 290 521 minecraft:obsidian
fill 262 290 522 263 290 522 minecraft:purple_concrete
fill 262 290 541 263 290 541 minecraft:purple_concrete
fill 262 290 542 274 290 542 minecraft:obsidian
fill 263 290 523 264 290 523 minecraft:purple_concrete
fill 264 290 522 275 290 522 minecraft:obsidian
fill 264 290 524 265 290 524 minecraft:purple_concrete
setblock 264 290 540 minecraft:purple_concrete
fill 264 290 541 275 290 541 minecraft:obsidian
fill 265 290 523 275 290 523 minecraft:obsidian
setblock 265 290 525 minecraft:purple_concrete
fill 265 290 538 265 290 539 minecraft:purple_concrete
fill 265 290 540 275 290 540 minecraft:obsidian
fill 266 290 524 275 290 525 minecraft:obsidian
fill 266 290 526 266 290 527 minecraft:purple_concrete
fill 266 290 536 266 290 537 minecraft:purple_concrete
fill 266 290 538 275 290 539 minecraft:obsidian
fill 267 290 512 268 290 512 minecraft:black_concrete
fill 267 290 526 275 290 527 minecraft:obsidian
fill 267 290 528 267 290 535 minecraft:purple_concrete
fill 267 290 536 275 290 537 minecraft:obsidian
fill 267 290 550 268 290 550 minecraft:black_concrete
fill 268 290 528 275 290 535 minecraft:obsidian
setblock 269 290 513 minecraft:black_concrete
setblock 269 290 549 minecraft:black_concrete
setblock 270 290 514 minecraft:black_concrete
setblock 270 290 548 minecraft:black_concrete
setblock 271 290 515 minecraft:black_concrete
setblock 271 290 547 minecraft:black_concrete
setblock 272 290 516 minecraft:black_concrete
setblock 272 290 546 minecraft:black_concrete
setblock 273 290 517 minecraft:black_concrete
setblock 273 290 545 minecraft:black_concrete
setblock 274 290 518 minecraft:black_concrete
setblock 274 290 544 minecraft:black_concrete
fill 274 290 552 274 307 552 minecraft:black_concrete
fill 275 290 519 275 290 520 minecraft:black_concrete
fill 275 290 542 275 290 543 minecraft:black_concrete
fill 276 290 521 276 290 541 minecraft:black_concrete
setblock 277 290 511 minecraft:crying_obsidian
setblock 277 290 512 minecraft:white_concrete
fill 235 291 518 235 296 518 minecraft:black_concrete
fill 235 291 534 236 292 534 minecraft:black_concrete
setblock 235 291 543 minecraft:white_concrete
fill 235 291 550 235 296 551 minecraft:black_concrete
fill 236 291 523 236 291 526 minecraft:black_concrete
fill 236 291 532 236 292 533 minecraft:black_concrete
fill 236 291 535 236 291 539 minecraft:black_concrete
fill 237 291 521 237 291 522 minecraft:black_concrete
fill 237 291 523 242 291 539 minecraft:obsidian
fill 237 291 540 237 291 541 minecraft:black_concrete
setblock 238 291 513 minecraft:light[level=12]
fill 238 291 519 238 291 520 minecraft:black_concrete
fill 238 291 521 246 291 522 minecraft:obsidian
fill 238 291 540 246 291 541 minecraft:obsidian
fill 238 291 542 238 291 543 minecraft:black_concrete
setblock 238 291 545 minecraft:light[level=12]
fill 239 291 510 239 296 510 minecraft:black_concrete
setblock 239 291 518 minecraft:black_concrete
fill 239 291 519 249 291 520 minecraft:obsidian
fill 239 291 542 248 291 543 minecraft:obsidian
setblock 239 291 544 minecraft:black_concrete
setblock 240 291 517 minecraft:black_concrete
fill 240 291 518 272 291 518 minecraft:obsidian
fill 240 291 544 252 291 544 minecraft:obsidian
setblock 240 291 545 minecraft:black_concrete
setblock 241 291 516 minecraft:black_concrete
fill 241 291 517 271 291 517 minecraft:obsidian
fill 241 291 545 271 291 545 minecraft:obsidian
setblock 241 291 546 minecraft:black_concrete
setblock 242 291 515 minecraft:black_concrete
fill 242 291 516 270 291 516 minecraft:obsidian
fill 242 291 546 270 291 546 minecraft:obsidian
setblock 242 291 547 minecraft:black_concrete
fill 243 291 510 243 303 510 minecraft:black_concrete
setblock 243 291 514 minecraft:black_concrete
fill 243 291 515 269 291 515 minecraft:obsidian
fill 243 291 523 243 291 529 minecraft:obsidian
fill 243 291 530 243 291 533 minecraft:crying_obsidian
fill 243 291 534 243 291 539 minecraft:obsidian
fill 243 291 547 269 291 547 minecraft:obsidian
setblock 243 291 548 minecraft:black_concrete
fill 244 291 513 245 291 513 minecraft:black_concrete
fill 244 291 514 268 291 514 minecraft:obsidian
fill 244 291 523 244 291 526 minecraft:obsidian
fill 244 291 527 244 291 529 minecraft:crying_obsidian
fill 244 291 534 244 291 536 minecraft:crying_obsidian
fill 244 291 537 244 291 539 minecraft:obsidian
fill 244 291 548 268 291 548 minecraft:obsidian
fill 244 291 549 245 291 549 minecraft:black_concrete
fill 245 291 523 245 291 524 minecraft:obsidian
fill 245 291 525 245 291 526 minecraft:crying_obsidian
fill 245 291 537 245 291 538 minecraft:crying_obsidian
setblock 245 291 539 minecraft:obsidian
fill 246 291 510 246 303 510 minecraft:black_concrete
fill 246 291 512 247 291 512 minecraft:black_concrete
fill 246 291 513 266 291 513 minecraft:obsidian
setblock 246 291 523 minecraft:obsidian
setblock 246 291 524 minecraft:crying_obsidian
setblock 246 291 529 minecraft:light[level=12]
setblock 246 291 537 minecraft:light[level=12]
setblock 246 291 539 minecraft:crying_obsidian
fill 246 291 549 266 291 549 minecraft:obsidian
fill 246 291 550 247 291 550 minecraft:black_concrete
fill 247 291 521 248 291 521 minecraft:obsidian
fill 247 291 522 247 291 523 minecraft:crying_obsidian
setblock 247 291 540 minecraft:crying_obsidian
setblock 247 291 541 minecraft:obsidian
fill 248 291 511 264 291 511 minecraft:black_concrete
fill 248 291 512 264 291 512 minecraft:obsidian
setblock 248 291 522 minecraft:crying_obsidian
setblock 248 291 541 minecraft:crying_obsidian
fill 248 291 550 264 291 550 minecraft:obsidian
fill 248 291 551 264 291 551 minecraft:black_concrete
setblock 249 291 521 minecraft:crying_obsidian
setblock 249 291 542 minecraft:crying_obsidian
setblock 249 291 543 minecraft:obsidian
fill 249 291 552 249 296 552 minecraft:black_concrete
fill 250 291 519 252 291 519 minecraft:obsidian
fill 250 291 520 252 291 520 minecraft:crying_obsidian
fill 250 291 543 252 291 543 minecraft:crying_obsidian
fill 253 291 519 259 291 519 minecraft:crying_obsidian
fill 253 291 544 259 291 544 minecraft:crying_obsidian
setblock 254 291 521 minecraft:light[level=12]
setblock 254 291 529 minecraft:light[level=12]
setblock 254 291 537 minecraft:light[level=12]
fill 255 291 510 255 296 510 minecraft:black_concrete
fill 260 291 519 273 291 519 minecraft:obsidian
fill 260 291 520 261 291 520 minecraft:crying_obsidian
fill 260 291 543 261 291 543 minecraft:crying_obsidian
fill 260 291 544 272 291 544 minecraft:obsidian
fill 262 291 520 273 291 520 minecraft:obsidian
fill 262 291 521 263 291 521 minecraft:crying_obsidian
setblock 262 291 529 minecraft:light[level=12]
setblock 262 291 537 minecraft:light[level=12]
fill 262 291 542 263 291 542 minecraft:crying_obsidian
fill 262 291 543 273 291 543 minecraft:obsidian
fill 264 291 521 274 291 521 minecraft:obsidian
setblock 264 291 522 minecraft:crying_obsidian
setblock 264 291 541 minecraft:crying_obsidian
fill 264 291 542 273 291 542 minecraft:obsidian
fill 265 291 512 266 291 512 minecraft:black_concrete
fill 265 291 522 274 291 522 minecraft:obsidian
setblock 265 291 523 minecraft:crying_obsidian
setblock 265 291 540 minecraft:crying_obsidian
fill 265 291 541 274 291 541 minecraft:obsidian
fill 265 291 550 266 291 550 minecraft:black_concrete
fill 265 291 552 265 296 552 minecraft:black_concrete
fill 266 291 523 275 291 523 minecraft:obsidian
fill 266 291 524 266 291 525 minecraft:crying_obsidian
fill 266 291 538 266 291 539 minecraft:crying_obsidian
fill 266 291 540 274 291 540 minecraft:obsidian
fill 267 291 513 268 291 513 minecraft:black_concrete
fill 267 291 524 275 291 524 minecraft:obsidian
fill 267 291 525 267 291 527 minecraft:crying_obsidian
fill 267 291 536 267 291 537 minecraft:crying_obsidian
fill 267 291 538 275 291 539 minecraft:obsidian
fill 267 291 549 268 291 549 minecraft:black_concrete
fill 268 291 525 275 291 527 minecraft:obsidian
fill 268 291 528 268 291 535 minecraft:crying_obsidian
fill 268 291 536 275 291 537 minecraft:obsidian
setblock 269 291 514 minecraft:black_concrete
fill 269 291 528 275 291 535 minecraft:obsidian
setblock 269 291 548 minecraft:black_concrete
setblock 270 291 513 minecraft:light[level=12]
setblock 270 291 515 minecraft:black_concrete
setblock 270 291 547 minecraft:black_concrete
fill 271 291 510 271 296 510 minecraft:black_concrete
setblock 271 291 516 minecraft:black_concrete
setblock 271 291 546 minecraft:black_concrete
setblock 272 291 517 minecraft:black_concrete
setblock 272 291 545 minecraft:black_concrete
setblock 273 291 518 minecraft:black_concrete
setblock 273 291 544 minecraft:black_concrete
fill 274 291 519 274 291 520 minecraft:black_concrete
fill 274 291 542 274 291 543 minecraft:black_concrete
fill 275 291 521 275 291 522 minecraft:black_concrete
fill 275 291 540 275 291 541 minecraft:black_concrete
fill 276 291 523 276 291 539 minecraft:black_concrete
setblock 277 291 511 minecraft:amethyst_block
fill 277 291 512 277 307 512 minecraft:black_concrete
fill 277 291 520 277 296 520 minecraft:black_concrete
fill 277 291 536 277 296 536 minecraft:black_concrete
setblock 235 292 524 minecraft:white_concrete
fill 235 292 543 235 301 543 minecraft:black_concrete
fill 236 292 525 236 292 526 minecraft:black_concrete
fill 236 292 535 236 292 537 minecraft:black_concrete
fill 237 292 523 237 292 525 minecraft:black_concrete
fill 237 292 526 241 292 536 minecraft:obsidian
fill 237 292 537 237 292 539 minecraft:black_concrete
fill 238 292 521 238 292 522 minecraft:black_concrete
fill 238 292 523 243 292 525 minecraft:obsidian
fill 238 292 537 243 292 539 minecraft:obsidian
fill 238 292 540 238 292 541 minecraft:black_concrete
fill 239 292 519 239 292 520 minecraft:black_concrete
fill 239 292 521 245 292 522 minecraft:obsidian
fill 239 292 540 245 292 541 minecraft:obsidian
fill 239 292 542 239 292 543 minecraft:black_concrete
fill 240 292 518 240 292 519 minecraft:black_concrete
fill 240 292 520 247 292 520 minecraft:obsidian
fill 240 292 542 247 292 542 minecraft:obsidian
fill 240 292 543 240 292 544 minecraft:black_concrete
fill 241 292 517 241 292 518 minecraft:black_concrete
fill 241 292 519 249 292 519 minecraft:obsidian
fill 241 292 543 248 292 543 minecraft:obsidian
fill 241 292 544 241 292 545 minecraft:black_concrete
fill 242 292 516 243 292 516 minecraft:black_concrete
fill 242 292 517 252 292 518 minecraft:obsidian
fill 242 292 526 242 292 530 minecraft:obsidian
fill 242 292 531 242 293 532 minecraft:purple_concrete
fill 242 292 533 242 292 536 minecraft:obsidian
fill 242 292 544 250 292 545 minecraft:obsidian
fill 242 292 546 243 292 546 minecraft:black_concrete
fill 243 292 515 244 292 515 minecraft:black_concrete
setblock 243 292 526 minecraft:obsidian
fill 243 292 527 243 292 530 minecraft:purple_concrete
fill 243 292 533 243 292 536 minecraft:purple_concrete
fill 243 292 547 244 292 547 minecraft:black_concrete
fill 244 292 514 245 292 514 minecraft:black_concrete
fill 244 292 516 268 292 516 minecraft:obsidian
fill 244 292 523 244 292 524 minecraft:obsidian
fill 244 292 525 244 292 526 minecraft:purple_concrete
fill 244 292 537 244 292 538 minecraft:purple_concrete
setblock 244 292 539 minecraft:obsidian
fill 244 292 546 268 292 546 minecraft:obsidian
fill 244 292 548 245 292 548 minecraft:black_concrete
fill 245 292 515 267 292 515 minecraft:obsidian
fill 245 292 523 245 292 524 minecraft:purple_concrete
setblock 245 292 539 minecraft:purple_concrete
fill 245 292 547 267 292 547 minecraft:obsidian
fill 246 292 513 247 292 513 minecraft:black_concrete
fill 246 292 514 266 292 514 minecraft:obsidian
setblock 246 292 521 minecraft:obsidian
fill 246 292 522 246 292 523 minecraft:purple_concrete
setblock 246 292 540 minecraft:purple_concrete
setblock 246 292 541 minecraft:obsidian
fill 246 292 548 266 292 548 minecraft:obsidian
fill 246 292 549 247 292 549 minecraft:black_concrete
fill 247 292 521 248 292 521 minecraft:purple_concrete
fill 247 292 529 249 292 529 minecraft:bone_block
fill 247 292 531 248 292 531 minecraft:bone_block
fill 247 292 533 249 292 533 minecraft:bone_block
setblock 247 292 541 minecraft:purple_concrete
fill 248 292 512 250 292 512 minecraft:black_concrete
fill 248 292 513 264 292 513 minecraft:obsidian
fill 248 292 520 249 292 520 minecraft:purple_concrete
fill 248 292 527 249 292 527 minecraft:bone_block
fill 248 292 535 249 292 535 minecraft:bone_block
setblock 248 292 542 minecraft:purple_concrete
fill 248 292 549 264 292 549 minecraft:obsidian
fill 248 292 550 250 292 550 minecraft:black_concrete
fill 249 292 525 250 293 525 minecraft:bone_block
fill 249 292 537 250 293 537 minecraft:bone_block
fill 249 292 543 250 292 543 minecraft:purple_concrete
fill 250 292 511 262 292 511 minecraft:black_concrete
fill 250 292 519 252 292 519 minecraft:purple_concrete
setblock 250 292 526 minecraft:bone_block
setblock 250 292 536 minecraft:bone_block
fill 250 292 551 262 292 551 minecraft:black_concrete
fill 251 292 512 261 292 512 minecraft:obsidian
fill 251 292 523 251 293 524 minecraft:bone_block
fill 251 292 538 251 293 539 minecraft:bone_block
fill 251 292 544 253 292 544 minecraft:purple_concrete
fill 251 292 545 253 292 545 minecraft:obsidian
fill 251 292 550 261 292 550 minecraft:obsidian
setblock 252 292 525 minecraft:bone_block
setblock 252 292 537 minecraft:bone_block
fill 253 292 517 270 292 517 minecraft:obsidian
fill 253 292 518 259 292 518 minecraft:purple_concrete
fill 253 292 522 253 292 524 minecraft:bone_block
fill 253 292 538 253 292 540 minecraft:bone_block
fill 254 292 545 258 293 545 minecraft:purple_concrete
fill 255 292 522 255 293 523 minecraft:bone_block
fill 255 292 539 255 293 540 minecraft:bone_block
fill 257 292 522 257 293 523 minecraft:bone_block
fill 257 292 539 257 293 540 minecraft:bone_block
fill 259 292 522 259 292 524 minecraft:bone_block
fill 259 292 538 259 292 540 minecraft:bone_block
fill 259 292 544 261 292 544 minecraft:purple_concrete
fill 259 292 545 270 292 545 minecraft:obsidian
fill 260 292 518 270 292 518 minecraft:obsidian
fill 260 292 519 262 292 519 minecraft:purple_concrete
setblock 260 292 525 minecraft:bone_block
setblock 260 292 537 minecraft:bone_block
fill 261 292 523 261 293 524 minecraft:bone_block
fill 261 292 538 261 293 539 minecraft:bone_block
fill 262 292 512 264 292 512 minecraft:black_concrete
fill 262 292 520 263 292 520 minecraft:purple_concrete
fill 262 292 525 262 292 526 minecraft:bone_block
fill 262 292 536 262 292 537 minecraft:bone_block
fill 262 292 543 263 292 543 minecraft:purple_concrete
fill 262 292 544 270 292 544 minecraft:obsidian
fill 262 292 550 264 292 550 minecraft:black_concrete
fill 263 292 519 271 292 519 minecraft:obsidian
fill 263 292 525 263 293 525 minecraft:bone_block
fill 263 292 527 264 292 527 minecraft:bone_block
fill 263 292 529 265 292 529 minecraft:bone_block
fill 263 292 533 265 292 533 minecraft:bone_block
fill 263 292 535 264 292 535 minecraft:bone_block
fill 263 292 537 263 293 537 minecraft:bone_block
fill 264 292 520 272 292 520 minecraft:obsidian
fill 264 292 521 265 292 521 minecraft:purple_concrete
fill 264 292 531 265 292 531 minecraft:bone_block
setblock 264 292 542 minecraft:purple_concrete
fill 264 292 543 271 292 543 minecraft:obsidian
fill 265 292 513 266 292 513 minecraft:black_concrete
fill 265 292 522 266 292 522 minecraft:purple_concrete
setblock 265 292 541 minecraft:purple_concrete
fill 265 292 542 272 292 542 minecraft:obsidian
fill 265 292 549 266 292 549 minecraft:black_concrete
fill 266 292 521 273 292 521 minecraft:obsidian
setblock 266 292 523 minecraft:purple_concrete
setblock 266 292 540 minecraft:purple_concrete
fill 266 292 541 273 292 541 minecraft:obsidian
fill 267 292 514 268 292 514 minecraft:black_concrete
fill 267 292 522 273 292 523 minecraft:obsidian
setblock 267 292 524 minecraft:purple_concrete
fill 267 292 538 267 292 539 minecraft:purple_concrete
fill 267 292 540 273 292 540 minecraft:obsidian
fill 267 292 548 268 292 548 minecraft:black_concrete
fill 268 292 515 269 292 515 minecraft:black_concrete
fill 268 292 524 274 292 524 minecraft:obsidian
fill 268 292 525 268 292 527 minecraft:purple_concrete
fill 268 292 536 268 292 537 minecraft:purple_concrete
fill 268 292 538 274 292 539 minecraft:obsidian
fill 268 292 547 269 292 547 minecraft:black_concrete
fill 269 292 516 270 292 516 minecraft:black_concrete
fill 269 292 525 274 292 527 minecraft:obsidian
fill 269 292 528 269 292 535 minecraft:purple_concrete
fill 269 292 536 274 292 537 minecraft:obsidian
fill 269 292 546 270 292 546 minecraft:black_concrete
fill 270 292 528 275 292 535 minecraft:obsidian
fill 271 292 517 271 292 518 minecraft:black_concrete
fill 271 292 544 271 292 545 minecraft:black_concrete
fill 272 292 518 272 292 519 minecraft:black_concrete
fill 272 292 543 272 292 544 minecraft:black_concrete
fill 273 292 519 273 292 520 minecraft:black_concrete
fill 273 292 542 273 292 543 minecraft:black_concrete
fill 274 292 521 274 292 522 minecraft:black_concrete
setblock 274 292 523 minecraft:obsidian
fill 274 292 540 274 292 541 minecraft:black_concrete
fill 275 292 523 275 292 525 minecraft:black_concrete
fill 275 292 526 275 292 527 minecraft:obsidian
setblock 275 292 536 minecraft:obsidian
fill 275 292 537 275 292 539 minecraft:black_concrete
fill 276 292 525 276 292 537 minecraft:black_concrete
fill 277 292 511 277 307 511 minecraft:black_concrete
fill 235 293 524 235 298 524 minecraft:black_concrete
fill 235 293 527 235 302 527 minecraft:black_concrete
setblock 235 293 531 minecraft:amethyst_block
fill 235 293 534 235 296 534 minecraft:black_concrete
fill 237 293 526 237 293 536 minecraft:black_concrete
fill 238 293 523 238 293 528 minecraft:black_concrete
fill 238 293 529 241 293 533 minecraft:obsidian
fill 238 293 534 238 293 539 minecraft:black_concrete
fill 239 293 521 239 293 524 minecraft:black_concrete
fill 239 293 525 241 293 528 minecraft:obsidian
fill 239 293 534 241 293 537 minecraft:obsidian
fill 239 293 538 239 293 541 minecraft:black_concrete
fill 240 293 520 240 293 522 minecraft:black_concrete
fill 240 293 523 243 293 524 minecraft:obsidian
fill 240 293 538 242 293 539 minecraft:obsidian
fill 240 293 540 240 293 542 minecraft:black_concrete
fill 241 293 519 241 293 520 minecraft:black_concrete
fill 241 293 521 244 293 522 minecraft:obsidian
fill 241 293 540 244 293 541 minecraft:obsidian
fill 241 293 542 241 293 543 minecraft:black_concrete
fill 242 293 517 242 293 519 minecraft:black_concrete
fill 242 293 520 246 293 520 minecraft:obsidian
fill 242 293 525 242 293 526 minecraft:obsidian
fill 242 293 527 242 293 530 minecraft:purple_concrete
fill 242 293 533 242 293 535 minecraft:purple_concrete
fill 242 293 536 242 293 537 minecraft:obsidian
fill 242 293 542 246 293 542 minecraft:obsidian
fill 242 293 543 242 293 545 minecraft:black_concrete
fill 243 293 517 243 293 518 minecraft:black_concrete
fill 243 293 519 247 293 519 minecraft:obsidian
fill 243 293 525 243 293 526 minecraft:purple_concrete
fill 243 293 536 243 293 538 minecraft:purple_concrete
setblock 243 293 539 minecraft:obsidian
fill 243 293 543 247 293 543 minecraft:obsidian
fill 243 293 544 243 293 545 minecraft:black_concrete
fill 244 293 516 244 293 517 minecraft:black_concrete
fill 244 293 518 249 293 518 minecraft:obsidian
fill 244 293 523 244 293 524 minecraft:purple_concrete
fill 244 293 528 246 294 528 minecraft:bone_block
fill 244 293 531 247 293 531 minecraft:bone_block
fill 244 293 534 246 294 534 minecraft:bone_block
setblock 244 293 539 minecraft:purple_concrete
fill 244 293 544 248 293 544 minecraft:obsidian
fill 244 293 545 244 293 546 minecraft:black_concrete
fill 245 293 515 245 293 516 minecraft:black_concrete
fill 245 293 517 252 293 517 minecraft:obsidian
setblock 245 293 521 minecraft:obsidian
setblock 245 293 522 minecraft:purple_concrete
fill 245 293 525 246 294 526 minecraft:bone_block
fill 245 293 529 248 293 529 minecraft:bone_block
fill 245 293 533 248 293 533 minecraft:bone_block
fill 245 293 536 246 294 537 minecraft:bone_block
setblock 245 293 540 minecraft:purple_concrete
setblock 245 293 541 minecraft:obsidian
fill 245 293 545 250 293 545 minecraft:obsidian
fill 245 293 546 245 293 547 minecraft:black_concrete
fill 246 293 514 247 293 515 minecraft:black_concrete
fill 246 293 516 266 293 516 minecraft:obsidian
setblock 246 293 521 minecraft:purple_concrete
setblock 246 293 541 minecraft:purple_concrete
fill 246 293 546 266 293 546 minecraft:obsidian
fill 246 293 547 247 293 548 minecraft:black_concrete
setblock 247 293 520 minecraft:purple_concrete
fill 247 293 523 248 294 524 minecraft:bone_block
fill 247 293 526 247 293 527 minecraft:bone_block
fill 247 293 535 247 293 536 minecraft:bone_block
fill 247 293 538 248 294 539 minecraft:bone_block
setblock 247 293 542 minecraft:purple_concrete
fill 248 293 513 249 293 514 minecraft:black_concrete
fill 248 293 515 264 293 515 minecraft:obsidian
fill 248 293 519 249 293 519 minecraft:purple_concrete
setblock 248 293 527 minecraft:bone_block
setblock 248 293 535 minecraft:bone_block
setblock 248 293 543 minecraft:purple_concrete
fill 248 293 547 264 293 547 minecraft:obsidian
fill 248 293 548 249 293 549 minecraft:black_concrete
fill 249 293 521 250 294 522 minecraft:bone_block
setblock 249 293 524 minecraft:bone_block
setblock 249 293 538 minecraft:bone_block
fill 249 293 540 250 294 541 minecraft:bone_block
fill 249 293 544 250 293 544 minecraft:purple_concrete
fill 250 293 513 253 293 513 minecraft:black_concrete
fill 250 293 514 262 293 514 minecraft:obsidian
fill 250 293 518 252 293 518 minecraft:purple_concrete
fill 250 293 523 250 294 523 minecraft:bone_block
fill 250 293 539 250 294 539 minecraft:bone_block
fill 250 293 548 262 293 548 minecraft:obsidian
fill 250 293 549 253 293 549 minecraft:black_concrete
fill 251 293 512 261 293 512 minecraft:black_concrete
fill 251 293 520 252 294 520 minecraft:bone_block
fill 251 293 542 252 294 542 minecraft:bone_block
fill 251 293 545 253 293 545 minecraft:purple_concrete
fill 251 293 550 261 293 550 minecraft:black_concrete
fill 252 293 521 253 293 522 minecraft:bone_block
fill 252 293 540 253 293 541 minecraft:bone_block
fill 253 293 517 259 293 517 minecraft:purple_concrete
setblock 253 293 523 minecraft:bone_block
setblock 253 293 539 minecraft:bone_block
fill 254 293 513 258 293 513 minecraft:obsidian
fill 254 293 519 255 293 521 minecraft:bone_block
fill 254 293 541 255 293 543 minecraft:bone_block
fill 254 293 549 258 293 549 minecraft:obsidian
fill 257 293 519 258 293 521 minecraft:bone_block
fill 257 293 541 258 293 543 minecraft:bone_block
fill 259 293 513 264 293 513 minecraft:black_concrete
fill 259 293 521 259 293 523 minecraft:bone_block
fill 259 293 539 259 293 541 minecraft:bone_block
fill 259 293 545 260 293 545 minecraft:purple_concrete
fill 259 293 549 264 293 549 minecraft:black_concrete
fill 260 293 517 267 293 517 minecraft:obsidian
fill 260 293 518 262 293 518 minecraft:purple_concrete
fill 260 293 520 260 293 522 minecraft:bone_block
fill 260 293 523 260 294 523 minecraft:obsidian
fill 260 293 540 260 293 542 minecraft:bone_block
fill 261 293 520 261 294 520 minecraft:bone_block
fill 261 293 542 261 294 542 minecraft:bone_block
fill 261 293 544 262 293 544 minecraft:purple_concrete
fill 261 293 545 267 293 545 minecraft:obsidian
fill 262 293 521 262 294 523 minecraft:bone_block
setblock 262 293 525 minecraft:bone_block
setblock 262 293 537 minecraft:bone_block
fill 262 293 539 262 294 541 minecraft:bone_block
fill 263 293 514 266 293 514 minecraft:black_concrete
fill 263 293 518 268 293 518 minecraft:obsidian
fill 263 293 519 264 293 519 minecraft:purple_concrete
fill 263 293 521 263 294 522 minecraft:bone_block
fill 263 293 524 265 293 524 minecraft:bone_block
fill 263 293 538 265 293 538 minecraft:bone_block
fill 263 293 540 263 294 541 minecraft:bone_block
fill 263 293 543 264 293 543 minecraft:purple_concrete
fill 263 293 544 268 293 544 minecraft:obsidian
fill 263 293 548 266 293 548 minecraft:black_concrete
fill 264 293 520 265 293 520 minecraft:purple_concrete
fill 264 293 523 265 294 523 minecraft:bone_block
fill 264 293 527 265 293 527 minecraft:bone_block
fill 264 293 529 267 293 529 minecraft:bone_block
fill 264 293 533 267 293 533 minecraft:bone_block
fill 264 293 535 265 293 535 minecraft:bone_block
fill 264 293 539 265 294 539 minecraft:bone_block
fill 265 293 515 267 293 515 minecraft:black_concrete
fill 265 293 519 269 293 519 minecraft:obsidian
fill 265 293 526 267 294 526 minecraft:bone_block
fill 265 293 531 268 293 531 minecraft:bone_block
fill 265 293 536 267 294 536 minecraft:bone_block
setblock 265 293 542 minecraft:purple_concrete
fill 265 293 543 269 293 543 minecraft:obsidian
fill 265 293 547 267 293 547 minecraft:black_concrete
fill 266 293 520 270 293 520 minecraft:obsidian
setblock 266 293 521 minecraft:purple_concrete
fill 266 293 525 267 294 525 minecraft:bone_block
fill 266 293 528 268 294 528 minecraft:bone_block
fill 266 293 534 268 294 534 minecraft:bone_block
fill 266 293 537 267 294 537 minecraft:bone_block
setblock 266 293 541 minecraft:purple_concrete
fill 266 293 542 270 293 542 minecraft:obsidian
fill 267 293 516 268 293 516 minecraft:black_concrete
fill 267 293 521 271 293 521 minecraft:obsidian
fill 267 293 522 267 293 523 minecraft:purple_concrete
setblock 267 293 540 minecraft:purple_concrete
fill 267 293 541 271 293 541 minecraft:obsidian
fill 267 293 546 268 293 546 minecraft:black_concrete
fill 268 293 517 270 293 517 minecraft:black_concrete
fill 268 293 522 271 293 522 minecraft:obsidian
fill 268 293 523 268 293 524 minecraft:purple_concrete
fill 268 293 538 268 293 539 minecraft:purple_concrete
fill 268 293 540 271 293 540 minecraft:obsidian
fill 268 293 545 270 293 545 minecraft:black_concrete
fill 269 293 518 270 293 518 minecraft:black_concrete
fill 269 293 523 272 293 524 minecraft:obsidian
fill 269 293 525 269 293 527 minecraft:purple_concrete
fill 269 293 536 269 293 537 minecraft:purple_concrete
fill 269 293 538 272 293 539 minecraft:obsidian
fill 269 293 544 270 293 544 minecraft:black_concrete
fill 270 293 519 271 293 519 minecraft:black_concrete
fill 270 293 525 273 293 527 minecraft:obsidian
fill 270 293 528 270 293 535 minecraft:purple_concrete
fill 270 293 536 273 293 537 minecraft:obsidian
fill 270 293 543 271 293 543 minecraft:black_concrete
fill 271 293 520 272 293 520 minecraft:black_concrete
fill 271 293 528 273 293 535 minecraft:obsidian
fill 271 293 542 272 293 542 minecraft:black_concrete
fill 272 293 521 273 293 522 minecraft:black_concrete
fill 272 293 540 273 293 541 minecraft:black_concrete
fill 273 293 523 274 293 524 minecraft:black_concrete
fill 273 293 538 274 293 539 minecraft:black_concrete
fill 274 293 525 274 293 528 minecraft:black_concrete
fill 274 293 529 274 293 533 minecraft:obsidian
fill 274 293 534 274 293 537 minecraft:black_concrete
fill 275 293 526 275 293 536 minecraft:black_concrete
setblock 277 293 518 minecraft:white_concrete
fill 235 294 531 235 307 531 minecraft:black_concrete
fill 238 294 529 240 294 533 minecraft:black_concrete
fill 239 294 525 240 294 528 minecraft:black_concrete
fill 239 294 534 240 294 537 minecraft:black_concrete
fill 240 294 523 242 294 524 minecraft:black_concrete
fill 240 294 538 242 294 539 minecraft:black_concrete
fill 241 294 521 243 294 522 minecraft:black_concrete
fill 241 294 525 241 294 526 minecraft:black_concrete
fill 241 294 527 241 294 535 minecraft:crying_obsidian
fill 241 294 536 241 294 537 minecraft:black_concrete
fill 241 294 540 243 294 541 minecraft:black_concrete
fill 242 294 520 245 294 520 minecraft:black_concrete
fill 242 294 525 242 294 526 minecraft:crying_obsidian
fill 242 294 527 243 295 528 minecraft:bone_block
fill 242 294 530 244 294 532 minecraft:bone_block
fill 242 294 534 243 295 535 minecraft:bone_block
fill 242 294 536 242 294 537 minecraft:crying_obsidian
fill 242 294 542 245 294 542 minecraft:black_concrete
fill 243 294 519 246 294 519 minecraft:black_concrete
setblock 243 294 523 minecraft:crying_obsidian
fill 243 294 524 244 295 525 minecraft:bone_block
fill 243 294 529 246 294 529 minecraft:bone_block
fill 243 294 533 246 294 533 minecraft:bone_block
fill 243 294 537 244 295 538 minecraft:bone_block
setblock 243 294 539 minecraft:crying_obsidian
fill 243 294 543 246 294 543 minecraft:black_concrete
fill 244 294 518 247 294 518 minecraft:black_concrete
setblock 244 294 521 minecraft:black_concrete
setblock 244 294 522 minecraft:crying_obsidian
fill 244 294 526 244 295 527 minecraft:bone_block
fill 244 294 535 244 295 536 minecraft:bone_block
setblock 244 294 540 minecraft:crying_obsidian
setblock 244 294 541 minecraft:black_concrete
fill 244 294 544 247 294 544 minecraft:black_concrete
fill 245 294 517 249 294 517 minecraft:black_concrete
fill 245 294 521 246 295 522 minecraft:bone_block
fill 245 294 524 245 295 524 minecraft:bone_block
fill 245 294 531 246 294 531 minecraft:bone_block
fill 245 294 538 245 295 538 minecraft:bone_block
fill 245 294 540 246 295 541 minecraft:bone_block
fill 245 294 545 249 294 545 minecraft:black_concrete
fill 246 294 516 252 294 516 minecraft:black_concrete
setblock 246 294 520 minecraft:crying_obsidian
fill 246 294 523 246 295 523 minecraft:bone_block
fill 246 294 539 246 295 539 minecraft:bone_block
setblock 246 294 542 minecraft:crying_obsidian
fill 246 294 546 251 294 546 minecraft:black_concrete
setblock 247 294 519 minecraft:crying_obsidian
fill 247 294 520 249 295 520 minecraft:bone_block
fill 247 294 522 247 295 522 minecraft:bone_block
setblock 247 294 526 minecraft:bone_block
setblock 247 294 536 minecraft:bone_block
fill 247 294 540 247 295 540 minecraft:bone_block
fill 247 294 542 249 295 542 minecraft:bone_block
setblock 247 294 543 minecraft:crying_obsidian
setblock 247 294 552 minecraft:white_concrete
fill 248 294 515 264 294 515 minecraft:black_concrete
fill 248 294 518 249 294 518 minecraft:crying_obsidian
fill 248 294 519 249 295 519 minecraft:bone_block
fill 248 294 521 248 295 521 minecraft:bone_block
fill 248 294 541 248 295 541 minecraft:bone_block
fill 248 294 543 249 295 543 minecraft:bone_block
fill 248 294 544 249 294 544 minecraft:crying_obsidian
fill 248 294 547 264 294 547 minecraft:black_concrete
fill 250 294 514 262 294 514 minecraft:black_concrete
setblock 250 294 517 minecraft:crying_obsidian
fill 250 294 518 252 295 518 minecraft:bone_block
fill 250 294 544 252 295 544 minecraft:bone_block
setblock 250 294 545 minecraft:crying_obsidian
fill 250 294 548 262 294 548 minecraft:black_concrete
fill 251 294 517 251 295 517 minecraft:bone_block
fill 251 294 519 252 295 519 minecraft:bone_block
fill 251 294 543 252 295 543 minecraft:bone_block
fill 251 294 545 251 295 545 minecraft:bone_block
setblock 252 294 517 minecraft:crying_obsidian
fill 252 294 521 253 294 521 minecraft:bone_block
fill 252 294 541 253 294 541 minecraft:bone_block
fill 252 294 546 260 294 546 minecraft:crying_obsidian
fill 253 294 516 259 294 516 minecraft:crying_obsidian
fill 254 294 513 258 294 513 minecraft:black_concrete
fill 254 294 517 255 294 520 minecraft:bone_block
fill 254 294 542 255 294 545 minecraft:bone_block
fill 254 294 549 258 294 549 minecraft:black_concrete
setblock 255 294 521 minecraft:bone_block
setblock 255 294 541 minecraft:bone_block
fill 257 294 517 257 294 521 minecraft:bone_block
fill 257 294 541 257 294 545 minecraft:bone_block
fill 258 294 517 258 294 520 minecraft:bone_block
fill 258 294 542 258 294 545 minecraft:bone_block
fill 259 294 521 260 294 521 minecraft:bone_block
fill 259 294 522 259 294 523 minecraft:obsidian
fill 259 294 541 260 294 541 minecraft:bone_block
fill 260 294 516 266 294 516 minecraft:black_concrete
setblock 260 294 517 minecraft:crying_obsidian
fill 260 294 518 260 294 520 minecraft:bone_block
setblock 260 294 522 minecraft:obsidian
fill 260 294 542 260 294 544 minecraft:bone_block
fill 261 294 517 261 295 519 minecraft:bone_block
fill 261 294 543 261 295 545 minecraft:bone_block
fill 261 294 546 266 294 546 minecraft:black_concrete
setblock 262 294 517 minecraft:crying_obsidian
fill 262 294 518 262 295 518 minecraft:bone_block
fill 262 294 544 262 295 544 minecraft:bone_block
setblock 262 294 545 minecraft:crying_obsidian
fill 263 294 517 267 294 517 minecraft:black_concrete
fill 263 294 518 264 294 518 minecraft:crying_obsidian
fill 263 294 519 264 295 520 minecraft:bone_block
fill 263 294 542 264 295 543 minecraft:bone_block
fill 263 294 544 264 294 544 minecraft:crying_obsidian
fill 263 294 545 267 294 545 minecraft:black_concrete
fill 264 294 521 264 295 521 minecraft:bone_block
fill 264 294 524 265 294 524 minecraft:bone_block
fill 264 294 538 265 294 538 minecraft:bone_block
fill 264 294 541 264 295 541 minecraft:bone_block
fill 265 294 518 268 294 518 minecraft:black_concrete
setblock 265 294 519 minecraft:crying_obsidian
fill 265 294 520 265 295 520 minecraft:bone_block
fill 265 294 522 267 295 522 minecraft:bone_block
fill 265 294 540 267 295 540 minecraft:bone_block
fill 265 294 542 265 295 542 minecraft:bone_block
setblock 265 294 543 minecraft:crying_obsidian
fill 265 294 544 268 294 544 minecraft:black_concrete
fill 266 294 519 269 294 519 minecraft:black_concrete
setblock 266 294 520 minecraft:crying_obsidian
fill 266 294 521 267 295 521 minecraft:bone_block
fill 266 294 523 266 295 523 minecraft:bone_block
fill 266 294 529 269 294 529 minecraft:bone_block
fill 266 294 531 270 294 531 minecraft:bone_block
fill 266 294 533 269 294 533 minecraft:bone_block
fill 266 294 539 266 295 539 minecraft:bone_block
fill 266 294 541 267 295 541 minecraft:bone_block
setblock 266 294 542 minecraft:crying_obsidian
fill 266 294 543 269 294 543 minecraft:black_concrete
fill 267 294 520 270 294 520 minecraft:black_concrete
fill 267 294 524 269 295 524 minecraft:bone_block
fill 267 294 538 269 295 538 minecraft:bone_block
fill 267 294 542 270 294 542 minecraft:black_concrete
fill 268 294 521 271 294 521 minecraft:black_concrete
setblock 268 294 522 minecraft:crying_obsidian
fill 268 294 525 268 295 527 minecraft:bone_block
fill 268 294 530 270 294 530 minecraft:bone_block
fill 268 294 532 270 294 532 minecraft:bone_block
fill 268 294 535 268 295 537 minecraft:bone_block
setblock 268 294 540 minecraft:crying_obsidian
fill 268 294 541 271 294 541 minecraft:black_concrete
fill 269 294 522 271 294 522 minecraft:black_concrete
setblock 269 294 523 minecraft:crying_obsidian
fill 269 294 525 269 295 525 minecraft:bone_block
fill 269 294 527 270 295 528 minecraft:bone_block
fill 269 294 534 270 295 535 minecraft:bone_block
fill 269 294 537 269 295 537 minecraft:bone_block
setblock 269 294 539 minecraft:crying_obsidian
fill 269 294 540 271 294 540 minecraft:black_concrete
fill 270 294 523 272 294 524 minecraft:black_concrete
fill 270 294 525 270 294 526 minecraft:crying_obsidian
fill 270 294 536 270 294 537 minecraft:crying_obsidian
fill 270 294 538 272 294 539 minecraft:black_concrete
fill 271 294 525 273 294 527 minecraft:black_concrete
fill 271 294 528 271 294 534 minecraft:crying_obsidian
fill 271 294 535 273 294 537 minecraft:black_concrete
fill 272 294 528 273 294 534 minecraft:black_concrete
setblock 273 294 552 minecraft:amethyst_block
fill 274 294 529 274 294 533 minecraft:black_concrete
setblock 277 294 518 minecraft:amethyst_block
fill 240 295 531 244 295 531 minecraft:bone_block
fill 241 295 527 241 295 528 minecraft:bone_block
fill 241 295 530 243 295 530 minecraft:bone_block
fill 241 295 532 243 295 532 minecraft:bone_block
fill 241 295 534 241 295 535 minecraft:bone_block
fill 242 295 524 242 295 525 minecraft:bone_block
fill 242 295 537 242 295 538 minecraft:bone_block
setblock 243 295 523 minecraft:bone_block
setblock 243 295 529 minecraft:bone_block
setblock 243 295 533 minecraft:bone_block
setblock 243 295 539 minecraft:bone_block
fill 244 295 521 244 295 522 minecraft:bone_block
setblock 244 295 528 minecraft:bone_block
setblock 244 295 534 minecraft:bone_block
fill 244 295 540 244 295 541 minecraft:bone_block
setblock 245 295 520 minecraft:bone_block
setblock 245 295 525 minecraft:bone_block
setblock 245 295 537 minecraft:bone_block
setblock 245 295 542 minecraft:bone_block
fill 247 295 518 247 295 519 minecraft:bone_block
setblock 247 295 523 minecraft:bone_block
setblock 247 295 539 minecraft:bone_block
fill 247 295 543 247 295 544 minecraft:bone_block
fill 247 295 552 247 307 552 minecraft:black_concrete
setblock 248 295 518 minecraft:bone_block
fill 248 295 534 248 296 535 minecraft:amethyst_block
setblock 248 295 544 minecraft:bone_block
setblock 249 295 521 minecraft:bone_block
setblock 249 295 541 minecraft:bone_block
setblock 250 295 517 minecraft:bone_block
setblock 250 295 545 minecraft:bone_block
setblock 251 295 516 minecraft:bone_block
setblock 251 295 546 minecraft:bone_block
fill 252 295 517 255 295 517 minecraft:bone_block
fill 252 295 545 255 295 545 minecraft:bone_block
fill 253 295 516 255 295 516 minecraft:bone_block
fill 253 295 546 255 295 546 minecraft:bone_block
setblock 254 295 515 minecraft:bone_block
fill 254 295 518 254 295 519 minecraft:bone_block
fill 254 295 543 254 295 544 minecraft:bone_block
setblock 254 295 547 minecraft:bone_block
setblock 255 295 518 minecraft:bone_block
setblock 255 295 544 minecraft:bone_block
fill 257 295 516 258 295 518 minecraft:bone_block
fill 257 295 544 258 295 546 minecraft:bone_block
setblock 258 295 515 minecraft:bone_block
setblock 258 295 519 minecraft:bone_block
setblock 258 295 543 minecraft:bone_block
setblock 258 295 547 minecraft:bone_block
fill 259 295 516 259 295 517 minecraft:bone_block
fill 259 295 522 261 296 522 minecraft:white_concrete
fill 259 295 545 259 295 546 minecraft:bone_block
fill 260 295 517 260 295 519 minecraft:bone_block
fill 260 295 521 260 296 521 minecraft:white_concrete
fill 260 295 543 260 295 545 minecraft:bone_block
setblock 261 295 516 minecraft:bone_block
setblock 261 295 546 minecraft:bone_block
setblock 262 295 517 minecraft:bone_block
setblock 262 295 545 minecraft:bone_block
setblock 263 295 521 minecraft:bone_block
setblock 263 295 541 minecraft:bone_block
fill 264 295 518 265 295 518 minecraft:bone_block
fill 264 295 544 265 295 544 minecraft:bone_block
setblock 265 295 519 minecraft:bone_block
setblock 265 295 523 minecraft:bone_block
setblock 265 295 539 minecraft:bone_block
setblock 265 295 543 minecraft:bone_block
setblock 267 295 520 minecraft:bone_block
setblock 267 295 525 minecraft:bone_block
setblock 267 295 537 minecraft:bone_block
setblock 267 295 542 minecraft:bone_block
fill 268 295 521 268 295 522 minecraft:bone_block
setblock 268 295 528 minecraft:bone_block
fill 268 295 531 272 295 531 minecraft:bone_block
setblock 268 295 534 minecraft:bone_block
fill 268 295 540 268 295 541 minecraft:bone_block
setblock 269 295 523 minecraft:bone_block
fill 269 295 529 269 295 530 minecraft:bone_block
fill 269 295 532 269 295 533 minecraft:bone_block
setblock 269 295 539 minecraft:bone_block
fill 270 295 524 270 295 525 minecraft:bone_block
fill 270 295 530 271 295 530 minecraft:bone_block
fill 270 295 532 271 295 532 minecraft:bone_block
fill 270 295 537 270 295 538 minecraft:bone_block
fill 271 295 527 271 295 528 minecraft:bone_block
fill 271 295 534 271 295 535 minecraft:bone_block
setblock 271 295 552 minecraft:crying_obsidian
fill 273 295 552 273 307 552 minecraft:black_concrete
fill 277 295 518 277 307 518 minecraft:black_concrete
setblock 235 296 515 minecraft:crying_obsidian
setblock 235 296 536 minecraft:white_concrete
fill 248 296 525 249 297 526 minecraft:obsidian
fill 271 296 552 271 307 552 minecraft:black_concrete
fill 235 297 515 235 305 515 minecraft:black_concrete
fill 235 297 518 235 299 518 minecraft:purple_concrete
fill 235 297 534 235 299 534 minecraft:purple_concrete
fill 235 297 536 235 307 536 minecraft:black_concrete
fill 235 297 550 235 299 550 minecraft:purple_concrete
fill 235 297 551 235 307 551 minecraft:black_concrete
setblock 237 297 552 minecraft:white_concrete
fill 239 297 510 239 299 510 minecraft:purple_concrete
fill 249 297 552 249 299 552 minecraft:purple_concrete
fill 255 297 510 255 299 510 minecraft:purple_concrete
fill 265 297 552 265 299 552 minecraft:purple_concrete
fill 271 297 510 271 299 510 minecraft:purple_concrete
setblock 277 297 515 minecraft:white_concrete
fill 277 297 520 277 299 520 minecraft:purple_concrete
fill 277 297 536 277 299 536 minecraft:purple_concrete
fill 237 298 552 237 307 552 minecraft:black_concrete
fill 272 298 523 276 300 523 minecraft:amethyst_block
fill 273 298 522 276 300 522 minecraft:amethyst_block
fill 273 298 524 276 300 524 minecraft:amethyst_block
setblock 274 298 510 minecraft:white_concrete
setblock 276 298 552 minecraft:crying_obsidian
fill 277 298 515 277 305 515 minecraft:black_concrete
setblock 235 299 511 minecraft:crying_obsidian
setblock 235 299 524 minecraft:amethyst_block
setblock 238 299 513 minecraft:light[level=12]
setblock 238 299 521 minecraft:light[level=12]
setblock 238 299 529 minecraft:light[level=12]
setblock 238 299 537 minecraft:light[level=12]
setblock 238 299 545 minecraft:light[level=12]
setblock 241 299 510 minecraft:crying_obsidian
setblock 246 299 513 minecraft:light[level=12]
setblock 246 299 521 minecraft:light[level=12]
setblock 246 299 529 minecraft:light[level=12]
setblock 246 299 537 minecraft:light[level=12]
setblock 246 299 545 minecraft:light[level=12]
setblock 254 299 513 minecraft:light[level=12]
setblock 254 299 521 minecraft:light[level=12]
setblock 254 299 529 minecraft:light[level=12]
setblock 254 299 537 minecraft:light[level=12]
setblock 254 299 545 minecraft:light[level=12]
setblock 258 299 552 minecraft:amethyst_block
setblock 262 299 513 minecraft:light[level=12]
setblock 262 299 521 minecraft:light[level=12]
setblock 262 299 529 minecraft:light[level=12]
setblock 262 299 537 minecraft:light[level=12]
setblock 262 299 545 minecraft:light[level=12]
fill 269 299 523 271 299 523 minecraft:amethyst_block
setblock 270 299 513 minecraft:light[level=12]
setblock 270 299 521 minecraft:light[level=12]
setblock 270 299 529 minecraft:light[level=12]
setblock 270 299 537 minecraft:light[level=12]
setblock 270 299 545 minecraft:light[level=12]
fill 271 299 522 272 300 522 minecraft:amethyst_block
fill 271 299 524 272 300 524 minecraft:amethyst_block
fill 274 299 510 274 307 510 minecraft:black_concrete
fill 275 299 521 275 300 521 minecraft:amethyst_block
fill 275 299 525 275 300 525 minecraft:amethyst_block
fill 276 299 552 276 307 552 minecraft:black_concrete
setblock 277 299 546 minecraft:white_concrete
fill 235 300 511 235 307 511 minecraft:black_concrete
fill 235 300 518 235 307 518 minecraft:black_concrete
fill 235 300 524 235 307 524 minecraft:black_concrete
fill 235 300 534 235 307 534 minecraft:black_concrete
fill 235 300 550 235 307 550 minecraft:black_concrete
fill 239 300 510 239 307 510 minecraft:black_concrete
fill 241 300 510 241 307 510 minecraft:black_concrete
setblock 246 300 552 minecraft:white_concrete
fill 249 300 552 249 301 552 minecraft:black_concrete
fill 255 300 510 255 307 510 minecraft:black_concrete
setblock 256 300 510 minecraft:crying_obsidian
fill 258 300 552 258 307 552 minecraft:black_concrete
fill 265 300 552 265 307 552 minecraft:black_concrete
fill 270 300 523 271 300 523 minecraft:amethyst_block
fill 271 300 510 271 307 510 minecraft:black_concrete
fill 277 300 520 277 302 520 minecraft:black_concrete
fill 277 300 536 277 307 536 minecraft:black_concrete
fill 277 300 546 277 307 546 minecraft:black_concrete
setblock 235 301 537 minecraft:crying_obsidian
fill 246 301 552 246 307 552 minecraft:black_concrete
fill 256 301 510 256 307 510 minecraft:black_concrete
setblock 267 301 510 minecraft:amethyst_block
setblock 277 301 549 minecraft:amethyst_block
setblock 235 302 528 minecraft:amethyst_block
setblock 235 302 535 minecraft:white_concrete
fill 235 302 537 235 307 537 minecraft:black_concrete
setblock 235 302 543 minecraft:white_concrete
setblock 249 302 552 minecraft:amethyst_block
fill 267 302 510 267 307 510 minecraft:black_concrete
setblock 277 302 529 minecraft:white_concrete
setblock 277 302 545 minecraft:amethyst_block
fill 277 302 549 277 307 549 minecraft:black_concrete
setblock 235 303 527 minecraft:white_concrete
fill 235 303 528 235 307 528 minecraft:black_concrete
fill 235 303 535 235 307 535 minecraft:black_concrete
fill 235 303 543 235 307 543 minecraft:black_concrete
setblock 236 303 552 minecraft:amethyst_block
fill 249 303 552 249 307 552 minecraft:black_concrete
setblock 264 303 510 minecraft:crying_obsidian
setblock 277 303 513 minecraft:amethyst_block
setblock 277 303 520 minecraft:crying_obsidian
setblock 277 303 526 minecraft:white_concrete
fill 277 303 529 277 307 529 minecraft:black_concrete
fill 277 303 545 277 307 545 minecraft:black_concrete
setblock 235 304 527 minecraft:black_concrete
fill 236 304 552 236 307 552 minecraft:black_concrete
setblock 243 304 510 minecraft:white_concrete
setblock 246 304 510 minecraft:white_concrete
setblock 251 304 552 minecraft:crying_obsidian
fill 264 304 510 264 307 510 minecraft:black_concrete
fill 277 304 513 277 307 513 minecraft:black_concrete
fill 277 304 520 277 307 520 minecraft:black_concrete
fill 277 304 526 277 305 526 minecraft:black_concrete
setblock 235 305 527 minecraft:crying_obsidian
fill 243 305 510 243 307 510 minecraft:black_concrete
fill 246 305 510 246 307 510 minecraft:black_concrete
fill 251 305 552 251 307 552 minecraft:black_concrete
setblock 257 305 552 minecraft:crying_obsidian
setblock 275 305 510 minecraft:amethyst_block
setblock 235 306 515 minecraft:amethyst_block
fill 235 306 527 235 307 527 minecraft:black_concrete
fill 257 306 552 257 307 552 minecraft:black_concrete
setblock 262 306 552 minecraft:crying_obsidian
fill 275 306 510 275 307 510 minecraft:black_concrete
fill 277 306 515 277 307 515 minecraft:amethyst_block
setblock 277 306 521 minecraft:white_concrete
setblock 277 306 526 minecraft:amethyst_block
setblock 235 307 515 minecraft:black_concrete
setblock 262 307 552 minecraft:black_concrete
setblock 277 307 521 minecraft:black_concrete
setblock 277 307 526 minecraft:black_concrete
