fill 136 194 309 136 195 310 minecraft:red_concrete
fill 136 194 311 136 195 312 minecraft:white_concrete
fill 136 194 313 136 195 314 minecraft:red_concrete
fill 136 194 315 136 195 316 minecraft:white_concrete
fill 136 194 317 136 195 317 minecraft:red_concrete
setblock 97 195 278 minecraft:light[level=12]
setblock 97 195 285 minecraft:light[level=12]
setblock 97 195 292 minecraft:light[level=12]
setblock 97 195 299 minecraft:light[level=12]
setblock 97 195 306 minecraft:light[level=12]
setblock 97 195 313 minecraft:light[level=12]
setblock 104 195 278 minecraft:light[level=12]
setblock 104 195 285 minecraft:light[level=12]
setblock 104 195 292 minecraft:light[level=12]
setblock 104 195 299 minecraft:light[level=12]
setblock 104 195 306 minecraft:light[level=12]
setblock 104 195 313 minecraft:light[level=12]
fill 110 195 277 112 195 277 minecraft:green_concrete
setblock 111 195 285 minecraft:light[level=12]
setblock 111 195 292 minecraft:light[level=12]
setblock 111 195 299 minecraft:light[level=12]
setblock 111 195 306 minecraft:light[level=12]
setblock 111 195 313 minecraft:light[level=12]
setblock 118 195 278 minecraft:light[level=12]
setblock 118 195 285 minecraft:light[level=12]
setblock 118 195 292 minecraft:light[level=12]
setblock 118 195 299 minecraft:light[level=12]
setblock 118 195 306 minecraft:light[level=12]
setblock 118 195 313 minecraft:light[level=12]
setblock 125 195 278 minecraft:light[level=12]
setblock 125 195 285 minecraft:light[level=12]
setblock 125 195 292 minecraft:light[level=12]
setblock 125 195 299 minecraft:light[level=12]
setblock 125 195 306 minecraft:light[level=12]
setblock 125 195 313 minecraft:light[level=12]
fill 129 195 283 129 195 285 minecraft:red_terracotta
fill 130 195 282 132 195 282 minecraft:red_terracotta
fill 130 195 286 132 195 286 minecraft:red_terracotta
setblock 132 195 278 minecraft:light[level=12]
setblock 132 195 292 minecraft:light[level=12]
setblock 132 195 299 minecraft:light[level=12]
setblock 132 195 306 minecraft:light[level=12]
setblock 132 195 313 minecraft:light[level=12]
fill 133 195 283 133 195 285 minecraft:red_terracotta
fill 94 196 275 94 197 276 minecraft:red_concrete
fill 94 196 277 94 197 278 minecraft:white_concrete
fill 94 196 279 94 197 280 minecraft:red_concrete
fill 94 196 281 94 197 282 minecraft:white_concrete
fill 94 196 283 94 197 284 minecraft:red_concrete
fill 94 196 285 94 197 286 minecraft:white_concrete
fill 94 196 287 94 197 288 minecraft:red_concrete
fill 94 196 289 94 197 290 minecraft:white_concrete
fill 94 196 291 94 197 292 minecraft:red_concrete
fill 94 196 293 94 197 294 minecraft:white_concrete
fill 94 196 295 94 197 296 minecraft:red_concrete
fill 94 196 297 94 197 298 minecraft:white_concrete
fill 94 196 299 94 197 300 minecraft:red_concrete
fill 94 196 301 94 197 302 minecraft:white_concrete
fill 94 196 303 94 197 304 minecraft:red_concrete
fill 94 196 305 94 197 306 minecraft:white_concrete
fill 94 196 307 94 197 308 minecraft:red_concrete
fill 94 196 309 94 197 310 minecraft:white_concrete
fill 94 196 311 94 197 312 minecraft:red_concrete
fill 94 196 313 94 197 314 minecraft:white_concrete
fill 94 196 315 94 197 316 minecraft:red_concrete
fill 95 196 275 95 197 275 minecraft:red_concrete
fill 95 196 276 95 197 281 minecraft:red_terracotta
fill 95 196 284 96 196 289 minecraft:red_terracotta
fill 95 196 292 96 196 297 minecraft:red_terracotta
fill 95 196 300 96 196 305 minecraft:red_terracotta
fill 95 196 308 96 196 313 minecraft:red_terracotta
fill 95 196 316 100 197 316 minecraft:red_terracotta
fill 95 196 317 95 197 317 minecraft:red_concrete
fill 96 196 275 97 197 275 minecraft:white_concrete
fill 96 196 277 96 196 283 minecraft:red_terracotta
fill 96 196 290 96 196 291 minecraft:red_terracotta
fill 96 196 298 96 196 299 minecraft:red_terracotta
fill 96 196 306 96 196 307 minecraft:red_terracotta
fill 96 196 314 96 196 315 minecraft:red_terracotta
fill 96 196 317 97 197 317 minecraft:white_concrete
fill 97 196 277 134 196 277 minecraft:red_terracotta
fill 97 196 315 135 196 315 minecraft:red_terracotta
fill 98 196 275 99 197 275 minecraft:red_concrete
fill 98 196 276 103 197 276 minecraft:red_terracotta
fill 98 196 317 99 197 317 minecraft:red_concrete
fill 100 196 275 101 197 275 minecraft:white_concrete
fill 100 196 317 101 197 317 minecraft:white_concrete
fill 102 196 275 103 197 275 minecraft:red_concrete
fill 102 196 289 102 197 289 minecraft:green_concrete
fill 102 196 317 103 197 317 minecraft:red_concrete
fill 103 196 316 108 197 316 minecraft:red_terracotta
fill 104 196 275 105 197 275 minecraft:white_concrete
fill 104 196 317 105 197 317 minecraft:white_concrete
fill 106 196 275 107 197 275 minecraft:red_concrete
fill 106 196 276 111 197 276 minecraft:red_terracotta
fill 106 196 317 107 197 317 minecraft:red_concrete
fill 108 196 275 109 197 275 minecraft:white_concrete
fill 108 196 317 109 197 317 minecraft:white_concrete
fill 110 196 275 111 197 275 minecraft:red_concrete
fill 110 196 317 111 197 317 minecraft:red_concrete
fill 111 196 316 116 197 316 minecraft:red_terracotta
fill 112 196 275 113 197 275 minecraft:white_concrete
fill 112 196 317 113 197 317 minecraft:white_concrete
fill 114 196 275 115 197 275 minecraft:red_concrete
fill 114 196 276 119 197 276 minecraft:red_terracotta
fill 114 196 317 115 197 317 minecraft:red_concrete
fill 116 196 275 117 197 275 minecraft:white_concrete
fill 116 196 317 117 197 317 minecraft:white_concrete
fill 118 196 275 119 197 275 minecraft:red_concrete
fill 118 196 317 119 197 317 minecraft:red_concrete
fill 119 196 316 124 197 316 minecraft:red_terracotta
fill 120 196 275 121 197 275 minecraft:white_concrete
fill 120 196 317 121 197 317 minecraft:white_concrete
fill 122 196 275 123 197 275 minecraft:red_concrete
fill 122 196 276 127 197 276 minecraft:red_terracotta
fill 122 196 317 123 197 317 minecraft:red_concrete
fill 124 196 275 125 197 275 minecraft:white_concrete
fill 124 196 317 125 197 317 minecraft:white_concrete
fill 126 196 275 127 197 275 minecraft:red_concrete
fill 126 196 317 127 197 317 minecraft:red_concrete
fill 127 196 316 132 197 316 minecraft:red_terracotta
fill 128 196 275 129 197 275 minecraft:white_concrete
fill 128 196 317 129 197 317 minecraft:white_concrete
fill 130 196 275 131 197 275 minecraft:red_concrete
fill 130 196 276 135 197 276 minecraft:red_terracotta
fill 130 196 317 131 197 317 minecraft:red_concrete
fill 132 196 275 133 197 275 minecraft:white_concrete
fill 132 196 317 133 197 317 minecraft:white_concrete
fill 134 196 275 135 197 275 minecraft:red_concrete
fill 134 196 278 134 196 314 minecraft:red_terracotta
fill 134 196 317 135 197 317 minecraft:red_concrete
fill 135 196 279 135 197 284 minecraft:red_terracotta
fill 135 196 287 135 197 292 minecraft:red_terracotta
fill 135 196 295 135 197 300 minecraft:red_terracotta
fill 135 196 303 135 197 308 minecraft:red_terracotta
fill 135 196 311 135 197 314 minecraft:red_terracotta
fill 135 196 316 135 197 316 minecraft:red_terracotta
fill 136 196 276 136 197 276 minecraft:red_concrete
fill 136 196 277 136 197 278 minecraft:white_concrete
fill 136 196 279 136 197 280 minecraft:red_concrete
fill 136 196 281 136 197 282 minecraft:white_concrete
fill 136 196 283 136 197 284 minecraft:red_concrete
fill 136 196 285 136 197 286 minecraft:white_concrete
fill 136 196 287 136 197 288 minecraft:red_concrete
fill 136 196 289 136 197 290 minecraft:white_concrete
fill 136 196 291 136 197 292 minecraft:red_concrete
fill 136 196 293 136 197 294 minecraft:white_concrete
fill 136 196 295 136 197 296 minecraft:red_concrete
fill 136 196 297 136 197 298 minecraft:white_concrete
fill 136 196 299 136 197 300 minecraft:red_concrete
fill 136 196 301 136 197 302 minecraft:white_concrete
fill 136 196 303 136 197 304 minecraft:red_concrete
fill 136 196 305 136 197 306 minecraft:white_concrete
fill 136 196 307 136 197 308 minecraft:red_concrete
fill 136 196 309 136 197 310 minecraft:white_concrete
fill 136 196 311 136 197 312 minecraft:red_concrete
fill 136 196 313 136 197 314 minecraft:white_concrete
fill 136 196 315 136 197 316 minecraft:red_concrete
fill 136 196 317 136 197 317 minecraft:white_concrete
fill 95 197 284 95 197 289 minecraft:red_terracotta
fill 95 197 292 95 197 297 minecraft:red_terracotta
fill 95 197 300 95 197 305 minecraft:red_terracotta
fill 95 197 308 95 197 313 minecraft:red_terracotta
setblock 97 197 278 minecraft:light[level=15]
setblock 97 197 286 minecraft:light[level=15]
setblock 97 197 294 minecraft:light[level=15]
setblock 97 197 302 minecraft:light[level=15]
setblock 97 197 310 minecraft:light[level=15]
setblock 105 197 278 minecraft:light[level=15]
setblock 105 197 286 minecraft:light[level=15]
setblock 105 197 294 minecraft:light[level=15]
setblock 105 197 302 minecraft:light[level=15]
setblock 105 197 310 minecraft:light[level=15]
fill 107 197 279 109 197 280 minecraft:yellow_concrete
fill 108 197 277 109 197 278 minecraft:yellow_concrete
fill 108 197 281 109 197 282 minecraft:yellow_concrete
fill 109 197 283 115 197 283 minecraft:yellow_concrete
fill 110 197 277 115 197 277 minecraft:yellow_concrete
fill 110 197 282 110 199 282 minecraft:yellow_concrete
fill 110 197 284 113 197 284 minecraft:yellow_concrete
fill 113 197 282 115 197 282 minecraft:yellow_concrete
setblock 113 197 286 minecraft:light[level=15]
setblock 113 197 294 minecraft:light[level=15]
setblock 113 197 302 minecraft:light[level=15]
setblock 113 197 310 minecraft:light[level=15]
fill 114 197 278 116 197 278 minecraft:yellow_concrete
fill 114 197 281 116 197 281 minecraft:yellow_concrete
fill 115 197 279 116 197 280 minecraft:yellow_concrete
setblock 121 197 278 minecraft:light[level=15]
setblock 121 197 286 minecraft:light[level=15]
setblock 121 197 294 minecraft:light[level=15]
setblock 121 197 302 minecraft:light[level=15]
setblock 121 197 310 minecraft:light[level=15]
fill 128 197 294 129 197 295 minecraft:yellow_concrete
setblock 129 197 278 minecraft:light[level=15]
setblock 129 197 286 minecraft:light[level=15]
fill 129 197 293 130 198 293 minecraft:yellow_concrete
fill 129 197 296 130 197 297 minecraft:yellow_concrete
setblock 129 197 302 minecraft:light[level=15]
setblock 129 197 310 minecraft:light[level=15]
fill 130 197 292 132 197 292 minecraft:yellow_concrete
fill 131 197 297 133 197 297 minecraft:yellow_concrete
fill 132 197 293 133 198 293 minecraft:yellow_concrete
fill 132 197 296 133 198 296 minecraft:yellow_concrete
fill 133 197 294 134 197 295 minecraft:yellow_concrete
setblock 135 197 315 minecraft:red_terracotta
fill 94 198 275 94 199 276 minecraft:white_concrete
fill 94 198 277 94 199 278 minecraft:red_concrete
fill 94 198 279 94 199 280 minecraft:white_concrete
fill 94 198 281 94 199 282 minecraft:red_concrete
fill 94 198 283 94 199 284 minecraft:white_concrete
fill 94 198 285 94 199 286 minecraft:red_concrete
fill 94 198 287 94 199 288 minecraft:white_concrete
fill 94 198 289 94 199 290 minecraft:red_concrete
fill 94 198 291 94 199 292 minecraft:white_concrete
fill 94 198 293 94 199 294 minecraft:red_concrete
fill 94 198 295 94 199 296 minecraft:white_concrete
fill 94 198 297 94 199 298 minecraft:red_concrete
fill 94 198 299 94 199 300 minecraft:white_concrete
fill 94 198 301 94 199 302 minecraft:red_concrete
fill 94 198 303 94 199 304 minecraft:white_concrete
fill 94 198 305 94 199 306 minecraft:red_concrete
fill 94 198 307 94 199 308 minecraft:white_concrete
fill 94 198 309 94 199 310 minecraft:red_concrete
fill 94 198 311 94 199 312 minecraft:white_concrete
fill 94 198 313 94 199 314 minecraft:red_concrete
fill 94 198 315 94 199 316 minecraft:white_concrete
fill 95 198 275 95 199 275 minecraft:white_concrete
fill 95 198 317 95 199 317 minecraft:white_concrete
fill 96 198 275 97 199 275 minecraft:red_concrete
fill 96 198 317 97 199 317 minecraft:red_concrete
fill 98 198 275 99 199 275 minecraft:white_concrete
fill 98 198 317 99 199 317 minecraft:white_concrete
fill 100 198 275 101 199 275 minecraft:red_concrete
fill 100 198 317 101 199 317 minecraft:red_concrete
fill 102 198 275 103 199 275 minecraft:white_concrete
fill 102 198 317 103 199 317 minecraft:white_concrete
fill 104 198 275 105 199 275 minecraft:red_concrete
fill 104 198 317 105 199 317 minecraft:red_concrete
fill 106 198 275 107 199 275 minecraft:white_concrete
fill 106 198 317 107 199 317 minecraft:white_concrete
fill 108 198 275 109 199 275 minecraft:red_concrete
fill 108 198 279 109 198 281 minecraft:yellow_concrete
fill 108 198 317 109 199 317 minecraft:red_concrete
fill 109 198 277 109 198 278 minecraft:yellow_concrete
setblock 109 198 282 minecraft:yellow_concrete
fill 110 198 275 111 199 275 minecraft:white_concrete
fill 110 198 277 114 198 277 minecraft:yellow_concrete
fill 110 198 283 113 198 283 minecraft:yellow_concrete
fill 110 198 317 111 199 317 minecraft:white_concrete
setblock 111 198 276 minecraft:yellow_concrete
fill 112 198 275 113 199 275 minecraft:red_concrete
fill 112 198 317 113 199 317 minecraft:red_concrete
fill 113 198 282 114 199 282 minecraft:yellow_concrete
fill 114 198 275 115 199 275 minecraft:white_concrete
fill 114 198 278 115 198 278 minecraft:yellow_concrete
fill 114 198 281 115 198 281 minecraft:yellow_concrete
fill 114 198 317 115 199 317 minecraft:white_concrete
fill 115 198 279 115 198 280 minecraft:yellow_concrete
fill 116 198 275 117 199 275 minecraft:red_concrete
fill 116 198 317 117 199 317 minecraft:red_concrete
fill 118 198 275 119 199 275 minecraft:white_concrete
fill 118 198 317 119 199 317 minecraft:white_concrete
fill 120 198 275 121 199 275 minecraft:red_concrete
fill 120 198 317 121 199 317 minecraft:red_concrete
fill 122 198 275 123 199 275 minecraft:white_concrete
fill 122 198 317 123 199 317 minecraft:white_concrete
fill 124 198 275 125 199 275 minecraft:red_concrete
fill 124 198 317 125 199 317 minecraft:red_concrete
fill 126 198 275 127 199 275 minecraft:white_concrete
fill 126 198 317 127 199 317 minecraft:white_concrete
fill 128 198 275 129 199 275 minecraft:red_concrete
fill 128 198 317 129 199 317 minecraft:red_concrete
fill 129 198 294 129 198 296 minecraft:yellow_concrete
fill 130 198 275 131 199 275 minecraft:white_concrete
fill 130 198 296 130 198 297 minecraft:yellow_concrete
fill 130 198 317 131 199 317 minecraft:white_concrete
setblock 131 198 292 minecraft:yellow_concrete
fill 131 198 297 132 198 297 minecraft:yellow_concrete
fill 132 198 275 133 199 275 minecraft:red_concrete
fill 132 198 317 133 199 317 minecraft:red_concrete
fill 133 198 294 133 199 295 minecraft:yellow_concrete
fill 134 198 275 135 199 275 minecraft:white_concrete
fill 134 198 317 135 199 317 minecraft:white_concrete
fill 136 198 276 136 199 276 minecraft:white_concrete
fill 136 198 277 136 199 278 minecraft:red_concrete
fill 136 198 279 136 199 280 minecraft:white_concrete
fill 136 198 281 136 199 282 minecraft:red_concrete
fill 136 198 283 136 199 284 minecraft:white_concrete
fill 136 198 285 136 199 286 minecraft:red_concrete
fill 136 198 287 136 199 288 minecraft:white_concrete
fill 136 198 289 136 199 290 minecraft:red_concrete
fill 136 198 291 136 199 292 minecraft:white_concrete
fill 136 198 293 136 199 294 minecraft:red_concrete
fill 136 198 295 136 199 296 minecraft:white_concrete
fill 136 198 297 136 199 298 minecraft:red_concrete
fill 136 198 299 136 199 300 minecraft:white_concrete
fill 136 198 301 136 199 302 minecraft:red_concrete
fill 136 198 303 136 199 304 minecraft:white_concrete
fill 136 198 305 136 199 306 minecraft:red_concrete
fill 136 198 307 136 199 308 minecraft:white_concrete
fill 136 198 309 136 199 310 minecraft:red_concrete
fill 136 198 311 136 199 312 minecraft:white_concrete
fill 136 198 313 136 199 314 minecraft:red_concrete
fill 136 198 315 136 199 316 minecraft:white_concrete
fill 136 198 317 136 199 317 minecraft:red_concrete
fill 97 199 310 97 200 310 minecraft:yellow_concrete
fill 97 199 313 97 200 313 minecraft:yellow_concrete
fill 100 199 310 100 200 310 minecraft:yellow_concrete
fill 100 199 313 100 200 313 minecraft:yellow_concrete
fill 101 199 311 101 200 312 minecraft:yellow_concrete
fill 109 199 278 109 199 281 minecraft:yellow_concrete
fill 110 199 277 113 199 277 minecraft:yellow_concrete
setblock 114 199 278 minecraft:yellow_concrete
setblock 114 199 281 minecraft:yellow_concrete
fill 129 199 294 129 199 295 minecraft:yellow_concrete
setblock 130 199 293 minecraft:yellow_concrete
setblock 130 199 296 minecraft:yellow_concrete
setblock 132 199 293 minecraft:yellow_concrete
setblock 132 199 296 minecraft:yellow_concrete
fill 94 200 275 94 201 276 minecraft:red_concrete
fill 94 200 277 94 201 278 minecraft:white_concrete
fill 94 200 279 94 201 279 minecraft:red_concrete
setblock 94 200 280 minecraft:shroomlight
fill 94 200 281 94 201 282 minecraft:white_concrete
fill 94 200 283 94 201 284 minecraft:red_concrete
fill 94 200 285 94 201 286 minecraft:white_concrete
fill 94 200 287 94 201 287 minecraft:red_concrete
setblock 94 200 288 minecraft:shroomlight
fill 94 200 289 94 201 290 minecraft:white_concrete
fill 94 200 291 94 201 292 minecraft:red_concrete
fill 94 200 293 94 201 294 minecraft:white_concrete
fill 94 200 295 94 201 295 minecraft:red_concrete
setblock 94 200 296 minecraft:shroomlight
fill 94 200 297 94 201 298 minecraft:white_concrete
fill 94 200 299 94 201 300 minecraft:red_concrete
fill 94 200 301 94 201 302 minecraft:white_concrete
fill 94 200 303 94 201 303 minecraft:red_concrete
setblock 94 200 304 minecraft:shroomlight
fill 94 200 305 94 201 306 minecraft:white_concrete
fill 94 200 307 94 201 308 minecraft:red_concrete
fill 94 200 309 94 201 310 minecraft:white_concrete
fill 94 200 311 94 201 311 minecraft:red_concrete
setblock 94 200 312 minecraft:shroomlight
fill 94 200 313 94 201 314 minecraft:white_concrete
fill 94 200 315 94 201 316 minecraft:red_concrete
fill 95 200 275 95 201 275 minecraft:red_concrete
fill 95 200 317 95 201 317 minecraft:red_concrete
fill 96 200 275 97 201 275 minecraft:white_concrete
fill 96 200 317 96 201 317 minecraft:white_concrete
setblock 97 200 317 minecraft:shroomlight
fill 98 200 275 99 201 275 minecraft:red_concrete
fill 98 200 317 99 201 317 minecraft:red_concrete
fill 100 200 275 100 201 275 minecraft:white_concrete
fill 100 200 317 101 201 317 minecraft:white_concrete
setblock 101 200 275 minecraft:shroomlight
fill 102 200 275 103 201 275 minecraft:red_concrete
fill 102 200 317 103 201 317 minecraft:red_concrete
fill 104 200 275 105 201 275 minecraft:white_concrete
fill 104 200 317 104 201 317 minecraft:white_concrete
setblock 105 200 317 minecraft:shroomlight
fill 106 200 275 107 201 275 minecraft:red_concrete
fill 106 200 317 107 201 317 minecraft:red_concrete
fill 108 200 275 108 201 275 minecraft:white_concrete
fill 108 200 317 109 201 317 minecraft:white_concrete
setblock 109 200 275 minecraft:shroomlight
fill 110 200 275 111 201 275 minecraft:red_concrete
fill 110 200 317 111 201 317 minecraft:red_concrete
fill 112 200 275 113 201 275 minecraft:white_concrete
fill 112 200 317 112 201 317 minecraft:white_concrete
setblock 113 200 317 minecraft:shroomlight
fill 114 200 275 115 201 275 minecraft:red_concrete
fill 114 200 317 115 201 317 minecraft:red_concrete
fill 116 200 275 116 201 275 minecraft:white_concrete
fill 116 200 317 117 201 317 minecraft:white_concrete
setblock 117 200 275 minecraft:shroomlight
fill 118 200 275 119 201 275 minecraft:red_concrete
fill 118 200 317 119 201 317 minecraft:red_concrete
fill 120 200 275 121 201 275 minecraft:white_concrete
fill 120 200 317 120 201 317 minecraft:white_concrete
setblock 121 200 317 minecraft:shroomlight
fill 122 200 275 123 201 275 minecraft:red_concrete
fill 122 200 317 123 201 317 minecraft:red_concrete
fill 124 200 275 124 201 275 minecraft:white_concrete
fill 124 200 317 125 201 317 minecraft:white_concrete
setblock 125 200 275 minecraft:shroomlight
fill 126 200 275 127 201 275 minecraft:red_concrete
fill 126 200 317 127 201 317 minecraft:red_concrete
fill 128 200 275 129 201 275 minecraft:white_concrete
fill 128 200 317 128 201 317 minecraft:white_concrete
setblock 129 200 317 minecraft:shroomlight
fill 130 200 275 131 201 275 minecraft:red_concrete
fill 130 200 317 131 201 317 minecraft:red_concrete
fill 132 200 275 132 201 275 minecraft:white_concrete
fill 132 200 317 133 201 317 minecraft:white_concrete
setblock 133 200 275 minecraft:shroomlight
fill 134 200 275 135 201 275 minecraft:red_concrete
fill 134 200 317 135 201 317 minecraft:red_concrete
fill 136 200 276 136 201 276 minecraft:red_concrete
fill 136 200 277 136 201 278 minecraft:white_concrete
fill 136 200 279 136 201 279 minecraft:red_concrete
setblock 136 200 280 minecraft:shroomlight
fill 136 200 281 136 201 282 minecraft:white_concrete
fill 136 200 283 136 201 284 minecraft:red_concrete
fill 136 200 285 136 201 286 minecraft:white_concrete
fill 136 200 287 136 201 287 minecraft:red_concrete
setblock 136 200 288 minecraft:shroomlight
fill 136 200 289 136 201 290 minecraft:white_concrete
fill 136 200 291 136 201 292 minecraft:red_concrete
fill 136 200 293 136 201 294 minecraft:white_concrete
fill 136 200 295 136 201 295 minecraft:red_concrete
setblock 136 200 296 minecraft:shroomlight
fill 136 200 297 136 201 298 minecraft:white_concrete
fill 136 200 299 136 201 300 minecraft:red_concrete
fill 136 200 301 136 201 302 minecraft:white_concrete
fill 136 200 303 136 201 303 minecraft:red_concrete
setblock 136 200 304 minecraft:shroomlight
fill 136 200 305 136 201 306 minecraft:white_concrete
fill 136 200 307 136 201 308 minecraft:red_concrete
fill 136 200 309 136 201 310 minecraft:white_concrete
fill 136 200 311 136 201 311 minecraft:red_concrete
setblock 136 200 312 minecraft:shroomlight
fill 136 200 313 136 201 314 minecraft:white_concrete
fill 136 200 315 136 201 316 minecraft:red_concrete
fill 136 200 317 136 201 317 minecraft:white_concrete
setblock 94 201 280 minecraft:red_concrete
setblock 94 201 288 minecraft:red_concrete
setblock 94 201 296 minecraft:red_concrete
setblock 94 201 304 minecraft:red_concrete
setblock 94 201 312 minecraft:red_concrete
setblock 97 201 278 minecraft:light[level=12]
setblock 97 201 285 minecraft:light[level=12]
setblock 97 201 292 minecraft:light[level=12]
setblock 97 201 299 minecraft:light[level=12]
setblock 97 201 306 minecraft:light[level=12]
setblock 97 201 313 minecraft:light[level=12]
setblock 97 201 317 minecraft:white_concrete
setblock 101 201 275 minecraft:white_concrete
setblock 104 201 278 minecraft:light[level=12]
setblock 104 201 285 minecraft:light[level=12]
setblock 104 201 292 minecraft:light[level=12]
setblock 104 201 299 minecraft:light[level=12]
setblock 104 201 306 minecraft:light[level=12]
setblock 104 201 313 minecraft:light[level=12]
setblock 105 201 317 minecraft:white_concrete
setblock 109 201 275 minecraft:white_concrete
setblock 111 201 278 minecraft:light[level=12]
setblock 111 201 285 minecraft:light[level=12]
setblock 111 201 292 minecraft:light[level=12]
setblock 111 201 299 minecraft:light[level=12]
setblock 111 201 306 minecraft:light[level=12]
setblock 111 201 313 minecraft:light[level=12]
setblock 113 201 317 minecraft:white_concrete
setblock 117 201 275 minecraft:white_concrete
setblock 118 201 278 minecraft:light[level=12]
setblock 118 201 285 minecraft:light[level=12]
setblock 118 201 292 minecraft:light[level=12]
setblock 118 201 299 minecraft:light[level=12]
setblock 118 201 306 minecraft:light[level=12]
setblock 118 201 313 minecraft:light[level=12]
setblock 121 201 317 minecraft:white_concrete
setblock 125 201 275 minecraft:white_concrete
setblock 125 201 278 minecraft:light[level=12]
setblock 125 201 285 minecraft:light[level=12]
setblock 125 201 292 minecraft:light[level=12]
setblock 125 201 299 minecraft:light[level=12]
setblock 125 201 306 minecraft:light[level=12]
setblock 125 201 313 minecraft:light[level=12]
setblock 129 201 317 minecraft:white_concrete
setblock 132 201 278 minecraft:light[level=12]
setblock 132 201 285 minecraft:light[level=12]
setblock 132 201 292 minecraft:light[level=12]
setblock 132 201 299 minecraft:light[level=12]
setblock 132 201 306 minecraft:light[level=12]
setblock 132 201 313 minecraft:light[level=12]
setblock 133 201 275 minecraft:white_concrete
setblock 136 201 280 minecraft:red_concrete
setblock 136 201 288 minecraft:red_concrete
setblock 136 201 296 minecraft:red_concrete
setblock 136 201 304 minecraft:red_concrete
setblock 136 201 312 minecraft:red_concrete
fill 94 202 275 94 203 276 minecraft:white_concrete
fill 94 202 277 94 203 278 minecraft:red_concrete
fill 94 202 279 94 203 280 minecraft:white_concrete
fill 94 202 281 94 203 282 minecraft:red_concrete
fill 94 202 283 94 203 284 minecraft:white_concrete
fill 94 202 285 94 203 286 minecraft:red_concrete
fill 94 202 287 94 203 288 minecraft:white_concrete
fill 94 202 289 94 203 290 minecraft:red_concrete
fill 94 202 291 94 203 292 minecraft:white_concrete
fill 94 202 293 94 203 294 minecraft:red_concrete
fill 94 202 295 94 203 296 minecraft:white_concrete
fill 94 202 297 94 203 298 minecraft:red_concrete
fill 94 202 299 94 203 300 minecraft:white_concrete
fill 94 202 301 94 203 302 minecraft:red_concrete
fill 94 202 303 94 203 304 minecraft:white_concrete
fill 94 202 305 94 203 306 minecraft:red_concrete
fill 94 202 307 94 203 308 minecraft:white_concrete
fill 94 202 309 94 203 310 minecraft:red_concrete
fill 94 202 311 94 203 312 minecraft:white_concrete
fill 94 202 313 94 203 314 minecraft:red_concrete
fill 94 202 315 94 203 316 minecraft:white_concrete
fill 95 202 275 95 203 275 minecraft:white_concrete
fill 95 202 317 95 203 317 minecraft:white_concrete
fill 96 202 275 97 203 275 minecraft:red_concrete
fill 96 202 317 97 203 317 minecraft:red_concrete
fill 98 202 275 99 203 275 minecraft:white_concrete
fill 98 202 317 99 203 317 minecraft:white_concrete
fill 100 202 275 101 203 275 minecraft:red_concrete
fill 100 202 317 101 203 317 minecraft:red_concrete
fill 102 202 275 103 203 275 minecraft:white_concrete
fill 102 202 317 103 203 317 minecraft:white_concrete
fill 104 202 275 105 203 275 minecraft:red_concrete
fill 104 202 317 105 203 317 minecraft:red_concrete
fill 106 202 275 107 203 275 minecraft:white_concrete
fill 106 202 317 107 203 317 minecraft:white_concrete
fill 108 202 275 109 203 275 minecraft:red_concrete
fill 108 202 317 109 203 317 minecraft:red_concrete
fill 110 202 275 111 203 275 minecraft:white_concrete
fill 110 202 317 111 203 317 minecraft:white_concrete
fill 112 202 275 113 203 275 minecraft:red_concrete
fill 112 202 317 113 203 317 minecraft:red_concrete
fill 114 202 275 115 203 275 minecraft:white_concrete
fill 114 202 317 115 203 317 minecraft:white_concrete
fill 116 202 275 117 203 275 minecraft:red_concrete
fill 116 202 317 117 203 317 minecraft:red_concrete
fill 118 202 275 119 203 275 minecraft:white_concrete
fill 118 202 317 119 203 317 minecraft:white_concrete
fill 120 202 275 121 203 275 minecraft:red_concrete
fill 120 202 317 121 203 317 minecraft:red_concrete
fill 122 202 275 123 203 275 minecraft:white_concrete
fill 122 202 317 123 203 317 minecraft:white_concrete
fill 124 202 275 125 203 275 minecraft:red_concrete
fill 124 202 317 125 203 317 minecraft:red_concrete
fill 126 202 275 127 203 275 minecraft:white_concrete
fill 126 202 317 127 203 317 minecraft:white_concrete
fill 128 202 275 129 203 275 minecraft:red_concrete
fill 128 202 317 129 203 317 minecraft:red_concrete
fill 130 202 275 131 203 275 minecraft:white_concrete
fill 130 202 317 131 203 317 minecraft:white_concrete
fill 132 202 275 133 203 275 minecraft:red_concrete
fill 132 202 317 133 203 317 minecraft:red_concrete
fill 134 202 275 135 203 275 minecraft:white_concrete
fill 134 202 317 135 203 317 minecraft:white_concrete
fill 136 202 276 136 203 276 minecraft:white_concrete
fill 136 202 277 136 203 278 minecraft:red_concrete
fill 136 202 279 136 203 280 minecraft:white_concrete
fill 136 202 281 136 203 282 minecraft:red_concrete
fill 136 202 283 136 203 284 minecraft:white_concrete
fill 136 202 285 136 203 286 minecraft:red_concrete
fill 136 202 287 136 203 288 minecraft:white_concrete
fill 136 202 289 136 203 290 minecraft:red_concrete
fill 136 202 291 136 203 292 minecraft:white_concrete
fill 136 202 293 136 203 294 minecraft:red_concrete
fill 136 202 295 136 203 296 minecraft:white_concrete
fill 136 202 297 136 203 298 minecraft:red_concrete
fill 136 202 299 136 203 300 minecraft:white_concrete
fill 136 202 301 136 203 302 minecraft:red_concrete
fill 136 202 303 136 203 304 minecraft:white_concrete
fill 136 202 305 136 203 306 minecraft:red_concrete
fill 136 202 307 136 203 308 minecraft:white_concrete
fill 136 202 309 136 203 310 minecraft:red_concrete
fill 136 202 311 136 203 312 minecraft:white_concrete
fill 136 202 313 136 203 314 minecraft:red_concrete
fill 136 202 315 136 203 316 minecraft:white_concrete
fill 136 202 317 136 203 317 minecraft:red_concrete
fill 94 204 275 94 205 276 minecraft:red_concrete
fill 94 204 277 94 205 278 minecraft:white_concrete
fill 94 204 279 94 205 280 minecraft:red_concrete
fill 94 204 281 94 205 282 minecraft:white_concrete
fill 94 204 283 94 205 284 minecraft:red_concrete
fill 94 204 285 94 205 286 minecraft:white_concrete
fill 94 204 287 94 205 288 minecraft:red_concrete
fill 94 204 289 94 205 290 minecraft:white_concrete
fill 94 204 291 94 205 292 minecraft:red_concrete
fill 94 204 293 94 205 294 minecraft:white_concrete
fill 94 204 295 94 205 296 minecraft:red_concrete
fill 94 204 297 94 205 298 minecraft:white_concrete
fill 94 204 299 94 205 300 minecraft:red_concrete
fill 94 204 301 94 205 302 minecraft:white_concrete
fill 94 204 303 94 205 304 minecraft:red_concrete
fill 94 204 305 94 205 306 minecraft:white_concrete
fill 94 204 307 94 205 308 minecraft:red_concrete
fill 94 204 309 94 205 310 minecraft:white_concrete
fill 94 204 311 94 205 312 minecraft:red_concrete
fill 94 204 313 94 205 314 minecraft:white_concrete
fill 94 204 315 94 205 316 minecraft:red_concrete
fill 95 204 275 95 205 275 minecraft:red_concrete
fill 95 204 317 95 205 317 minecraft:red_concrete
fill 96 204 275 97 205 275 minecraft:white_concrete
fill 96 204 317 97 205 317 minecraft:white_concrete
fill 98 204 275 99 205 275 minecraft:red_concrete
fill 98 204 317 99 205 317 minecraft:red_concrete
fill 100 204 275 101 205 275 minecraft:white_concrete
fill 100 204 317 101 205 317 minecraft:white_concrete
fill 102 204 275 103 205 275 minecraft:red_concrete
fill 102 204 317 103 205 317 minecraft:red_concrete
fill 104 204 275 105 205 275 minecraft:white_concrete
fill 104 204 317 105 205 317 minecraft:white_concrete
fill 106 204 275 107 205 275 minecraft:red_concrete
fill 106 204 317 107 205 317 minecraft:red_concrete
fill 108 204 275 109 205 275 minecraft:white_concrete
fill 108 204 317 109 205 317 minecraft:white_concrete
fill 110 204 275 111 205 275 minecraft:red_concrete
fill 110 204 317 111 205 317 minecraft:red_concrete
fill 112 204 275 113 205 275 minecraft:white_concrete
fill 112 204 317 113 205 317 minecraft:white_concrete
fill 114 204 275 115 205 275 minecraft:red_concrete
fill 114 204 317 115 205 317 minecraft:red_concrete
fill 116 204 275 117 205 275 minecraft:white_concrete
fill 116 204 317 117 205 317 minecraft:white_concrete
fill 118 204 275 119 205 275 minecraft:red_concrete
fill 118 204 317 119 205 317 minecraft:red_concrete
fill 120 204 275 121 205 275 minecraft:white_concrete
fill 120 204 317 121 205 317 minecraft:white_concrete
fill 122 204 275 123 205 275 minecraft:red_concrete
fill 122 204 317 123 205 317 minecraft:red_concrete
fill 124 204 275 125 205 275 minecraft:white_concrete
fill 124 204 317 125 205 317 minecraft:white_concrete
fill 126 204 275 127 205 275 minecraft:red_concrete
fill 126 204 317 127 205 317 minecraft:red_concrete
fill 128 204 275 129 205 275 minecraft:white_concrete
fill 128 204 317 129 205 317 minecraft:white_concrete
fill 130 204 275 131 205 275 minecraft:red_concrete
fill 130 204 317 131 205 317 minecraft:red_concrete
fill 132 204 275 133 205 275 minecraft:white_concrete
fill 132 204 317 133 205 317 minecraft:white_concrete
fill 134 204 275 135 205 275 minecraft:red_concrete
fill 134 204 317 135 205 317 minecraft:red_concrete
fill 136 204 276 136 205 276 minecraft:red_concrete
fill 136 204 277 136 205 278 minecraft:white_concrete
fill 136 204 279 136 205 280 minecraft:red_concrete
fill 136 204 281 136 205 282 minecraft:white_concrete
fill 136 204 283 136 205 284 minecraft:red_concrete
fill 136 204 285 136 205 286 minecraft:white_concrete
fill 136 204 287 136 205 288 minecraft:red_concrete
fill 136 204 289 136 205 290 minecraft:white_concrete
fill 136 204 291 136 205 292 minecraft:red_concrete
fill 136 204 293 136 205 294 minecraft:white_concrete
fill 136 204 295 136 205 296 minecraft:red_concrete
fill 136 204 297 136 205 298 minecraft:white_concrete
fill 136 204 299 136 205 300 minecraft:red_concrete
fill 136 204 301 136 205 302 minecraft:white_concrete
fill 136 204 303 136 205 304 minecraft:red_concrete
fill 136 204 305 136 205 306 minecraft:white_concrete
fill 136 204 307 136 205 308 minecraft:red_concrete
fill 136 204 309 136 205 310 minecraft:white_concrete
fill 136 204 311 136 205 312 minecraft:red_concrete
fill 136 204 313 136 205 314 minecraft:white_concrete
fill 136 204 315 136 205 316 minecraft:red_concrete
fill 136 204 317 136 205 317 minecraft:white_concrete
setblock 97 205 278 minecraft:light[level=15]
setblock 97 205 286 minecraft:light[level=15]
setblock 97 205 294 minecraft:light[level=15]
setblock 97 205 302 minecraft:light[level=15]
setblock 97 205 310 minecraft:light[level=15]
setblock 105 205 278 minecraft:light[level=15]
setblock 105 205 286 minecraft:light[level=15]
setblock 105 205 294 minecraft:light[level=15]
setblock 105 205 302 minecraft:light[level=15]
setblock 105 205 310 minecraft:light[level=15]
setblock 113 205 278 minecraft:light[level=15]
setblock 113 205 286 minecraft:light[level=15]
setblock 113 205 294 minecraft:light[level=15]
setblock 113 205 302 minecraft:light[level=15]
setblock 113 205 310 minecraft:light[level=15]
setblock 121 205 278 minecraft:light[level=15]
setblock 121 205 286 minecraft:light[level=15]
setblock 121 205 294 minecraft:light[level=15]
setblock 121 205 302 minecraft:light[level=15]
setblock 121 205 310 minecraft:light[level=15]
setblock 129 205 278 minecraft:light[level=15]
setblock 129 205 286 minecraft:light[level=15]
setblock 129 205 294 minecraft:light[level=15]
setblock 129 205 302 minecraft:light[level=15]
setblock 129 205 310 minecraft:light[level=15]
fill 94 206 275 94 207 276 minecraft:white_concrete
fill 94 206 277 94 207 278 minecraft:red_concrete
fill 94 206 279 94 207 280 minecraft:white_concrete
fill 94 206 281 94 207 282 minecraft:red_concrete
fill 94 206 283 94 207 284 minecraft:white_concrete
fill 94 206 285 94 207 286 minecraft:red_concrete
fill 94 206 287 94 207 288 minecraft:white_concrete
fill 94 206 289 94 207 290 minecraft:red_concrete
fill 94 206 291 94 207 292 minecraft:white_concrete
fill 94 206 293 94 207 294 minecraft:red_concrete
fill 94 206 295 94 207 296 minecraft:white_concrete
fill 94 206 297 94 207 298 minecraft:red_concrete
fill 94 206 299 94 207 300 minecraft:white_concrete
fill 94 206 301 94 207 302 minecraft:red_concrete
fill 94 206 303 94 207 304 minecraft:white_concrete
fill 94 206 305 94 207 306 minecraft:red_concrete
fill 94 206 307 94 207 308 minecraft:white_concrete
fill 94 206 309 94 207 310 minecraft:red_concrete
fill 94 206 311 94 207 312 minecraft:white_concrete
fill 94 206 313 94 207 314 minecraft:red_concrete
fill 94 206 315 94 207 316 minecraft:white_concrete
fill 95 206 275 95 207 275 minecraft:white_concrete
fill 95 206 317 95 207 317 minecraft:white_concrete
fill 96 206 275 97 207 275 minecraft:red_concrete
fill 96 206 317 97 207 317 minecraft:red_concrete
fill 98 206 275 99 207 275 minecraft:white_concrete
fill 98 206 317 99 207 317 minecraft:white_concrete
fill 100 206 275 101 207 275 minecraft:red_concrete
fill 100 206 317 101 207 317 minecraft:red_concrete
fill 102 206 275 103 207 275 minecraft:white_concrete
fill 102 206 317 103 207 317 minecraft:white_concrete
fill 104 206 275 105 207 275 minecraft:red_concrete
fill 104 206 317 105 207 317 minecraft:red_concrete
fill 106 206 275 107 207 275 minecraft:white_concrete
fill 106 206 317 107 207 317 minecraft:white_concrete
fill 107 206 298 113 206 298 minecraft:iron_block
fill 108 206 275 109 207 275 minecraft:red_concrete
fill 108 206 294 108 207 294 minecraft:iron_block
fill 108 206 296 114 206 296 minecraft:iron_block
fill 108 206 299 114 206 299 minecraft:iron_block
fill 108 206 301 108 207 301 minecraft:iron_block
fill 108 206 317 109 207 317 minecraft:red_concrete
fill 109 206 293 109 207 293 minecraft:iron_block
fill 109 206 295 116 206 295 minecraft:iron_block
fill 109 206 302 123 206 302 minecraft:iron_block
fill 109 206 304 109 207 304 minecraft:iron_block
fill 110 206 275 111 207 275 minecraft:white_concrete
fill 110 206 292 110 207 292 minecraft:iron_block
fill 110 206 297 114 206 297 minecraft:iron_block
fill 110 206 300 114 206 301 minecraft:iron_block
fill 110 206 303 123 207 303 minecraft:iron_block
fill 110 206 317 111 207 317 minecraft:white_concrete
fill 111 206 290 111 207 290 minecraft:iron_block
fill 111 206 293 124 206 294 minecraft:iron_block
fill 111 206 305 111 207 305 minecraft:iron_block
fill 112 206 275 113 207 275 minecraft:red_concrete
fill 112 206 291 120 207 292 minecraft:iron_block
fill 112 206 304 122 207 304 minecraft:iron_block
fill 112 206 306 112 207 306 minecraft:iron_block
fill 112 206 317 113 207 317 minecraft:red_concrete
fill 113 206 290 113 207 290 minecraft:iron_block
fill 113 206 307 113 207 307 minecraft:iron_block
fill 114 206 275 115 207 275 minecraft:white_concrete
fill 114 206 289 114 207 289 minecraft:iron_block
fill 114 206 305 115 207 306 minecraft:iron_block
fill 114 206 317 115 207 317 minecraft:white_concrete
fill 115 206 301 116 206 301 minecraft:iron_block
fill 115 206 307 115 207 307 minecraft:iron_block
fill 116 206 275 117 207 275 minecraft:red_concrete
fill 116 206 289 117 207 290 minecraft:iron_block
fill 116 206 305 122 207 305 minecraft:iron_block
fill 116 206 317 117 207 317 minecraft:red_concrete
fill 117 206 288 117 207 288 minecraft:iron_block
fill 117 206 306 117 207 308 minecraft:iron_block
fill 118 206 275 119 207 275 minecraft:white_concrete
fill 118 206 295 124 206 295 minecraft:iron_block
fill 118 206 301 125 206 301 minecraft:iron_block
fill 118 206 306 118 207 307 minecraft:iron_block
fill 118 206 317 119 207 317 minecraft:white_concrete
fill 119 206 289 119 207 290 minecraft:iron_block
fill 120 206 275 121 207 275 minecraft:red_concrete
fill 120 206 290 120 207 290 minecraft:iron_block
fill 120 206 296 124 206 297 minecraft:iron_block
fill 120 206 299 124 206 300 minecraft:iron_block
fill 120 206 307 120 207 307 minecraft:iron_block
fill 120 206 317 121 207 317 minecraft:red_concrete
fill 121 206 289 121 207 289 minecraft:iron_block
fill 121 206 292 122 207 292 minecraft:iron_block
fill 121 206 298 127 206 298 minecraft:iron_block
fill 121 206 306 121 207 306 minecraft:iron_block
fill 122 206 275 123 207 275 minecraft:white_concrete
fill 122 206 290 122 207 290 minecraft:iron_block
fill 122 206 317 123 207 317 minecraft:white_concrete
fill 123 206 291 123 207 291 minecraft:iron_block
fill 123 206 306 123 207 306 minecraft:iron_block
fill 124 206 275 125 207 275 minecraft:red_concrete
fill 124 206 304 124 207 304 minecraft:iron_block
fill 124 206 317 125 207 317 minecraft:red_concrete
fill 125 206 292 125 207 292 minecraft:iron_block
fill 125 206 294 125 207 294 minecraft:iron_block
fill 125 206 297 126 207 297 minecraft:iron_block
fill 125 206 300 126 207 300 minecraft:iron_block
fill 125 206 303 125 207 303 minecraft:iron_block
fill 126 206 275 127 207 275 minecraft:white_concrete
fill 126 206 295 126 207 295 minecraft:iron_block
fill 126 206 302 126 207 302 minecraft:iron_block
fill 126 206 317 127 207 317 minecraft:white_concrete
fill 128 206 275 129 207 275 minecraft:red_concrete
fill 128 206 317 129 207 317 minecraft:red_concrete
fill 130 206 275 131 207 275 minecraft:white_concrete
fill 130 206 317 131 207 317 minecraft:white_concrete
fill 132 206 275 133 207 275 minecraft:red_concrete
fill 132 206 317 133 207 317 minecraft:red_concrete
fill 134 206 275 135 207 275 minecraft:white_concrete
fill 134 206 317 135 207 317 minecraft:white_concrete
fill 136 206 276 136 207 276 minecraft:white_concrete
fill 136 206 277 136 207 278 minecraft:red_concrete
fill 136 206 279 136 207 280 minecraft:white_concrete
fill 136 206 281 136 207 282 minecraft:red_concrete
fill 136 206 283 136 207 284 minecraft:white_concrete
fill 136 206 285 136 207 286 minecraft:red_concrete
fill 136 206 287 136 207 288 minecraft:white_concrete
fill 136 206 289 136 207 290 minecraft:red_concrete
fill 136 206 291 136 207 292 minecraft:white_concrete
fill 136 206 293 136 207 294 minecraft:red_concrete
fill 136 206 295 136 207 296 minecraft:white_concrete
fill 136 206 297 136 207 298 minecraft:red_concrete
fill 136 206 299 136 207 300 minecraft:white_concrete
fill 136 206 301 136 207 302 minecraft:red_concrete
fill 136 206 303 136 207 304 minecraft:white_concrete
fill 136 206 305 136 207 306 minecraft:red_concrete
fill 136 206 307 136 207 308 minecraft:white_concrete
fill 136 206 309 136 207 310 minecraft:red_concrete
fill 136 206 311 136 207 312 minecraft:white_concrete
fill 136 206 313 136 207 314 minecraft:red_concrete
fill 136 206 315 136 207 316 minecraft:white_concrete
fill 136 206 317 136 207 317 minecraft:red_concrete
fill 95 207 276 95 207 277 minecraft:white_wool
setblock 95 207 278 minecraft:white_concrete
fill 95 207 279 95 207 281 minecraft:white_wool
setblock 95 207 282 minecraft:white_concrete
fill 95 207 283 95 207 285 minecraft:white_wool
setblock 95 207 286 minecraft:white_concrete
fill 95 207 287 95 207 289 minecraft:white_wool
setblock 95 207 290 minecraft:white_concrete
fill 95 207 291 95 207 293 minecraft:white_wool
setblock 95 207 294 minecraft:white_concrete
fill 95 207 295 95 207 297 minecraft:white_wool
setblock 95 207 298 minecraft:white_concrete
fill 95 207 299 95 207 301 minecraft:white_wool
setblock 95 207 302 minecraft:white_concrete
fill 95 207 303 95 207 305 minecraft:white_wool
setblock 95 207 306 minecraft:white_concrete
fill 95 207 307 95 207 309 minecraft:white_wool
setblock 95 207 310 minecraft:white_concrete
fill 95 207 311 95 207 313 minecraft:white_wool
setblock 95 207 314 minecraft:white_concrete
fill 95 207 315 96 207 316 minecraft:white_wool
setblock 96 207 276 minecraft:white_wool
setblock 96 207 277 minecraft:white_concrete
fill 96 207 278 96 207 280 minecraft:white_wool
setblock 96 207 281 minecraft:white_concrete
fill 96 207 282 96 207 284 minecraft:white_wool
setblock 96 207 285 minecraft:white_concrete
fill 96 207 286 96 207 288 minecraft:white_wool
setblock 96 207 289 minecraft:white_concrete
fill 96 207 290 96 207 292 minecraft:white_wool
setblock 96 207 293 minecraft:white_concrete
fill 96 207 294 96 207 296 minecraft:white_wool
setblock 96 207 297 minecraft:white_concrete
fill 96 207 298 96 207 300 minecraft:white_wool
setblock 96 207 301 minecraft:white_concrete
fill 96 207 302 96 207 304 minecraft:white_wool
setblock 96 207 305 minecraft:white_concrete
fill 96 207 306 96 207 308 minecraft:white_wool
setblock 96 207 309 minecraft:white_concrete
fill 96 207 310 96 207 312 minecraft:white_wool
setblock 96 207 313 minecraft:white_concrete
fill 96 207 314 98 207 314 minecraft:white_wool
setblock 97 207 276 minecraft:white_concrete
fill 97 207 277 97 207 279 minecraft:white_wool
setblock 97 207 280 minecraft:white_concrete
fill 97 207 281 97 207 283 minecraft:white_wool
setblock 97 207 284 minecraft:white_concrete
fill 97 207 285 97 207 287 minecraft:white_wool
setblock 97 207 288 minecraft:white_concrete
fill 97 207 289 97 207 291 minecraft:white_wool
setblock 97 207 292 minecraft:white_concrete
fill 97 207 293 97 207 295 minecraft:white_wool
setblock 97 207 296 minecraft:white_concrete
fill 97 207 297 97 207 299 minecraft:white_wool
setblock 97 207 300 minecraft:white_concrete
fill 97 207 301 97 207 303 minecraft:white_wool
setblock 97 207 304 minecraft:white_concrete
fill 97 207 305 97 207 307 minecraft:white_wool
setblock 97 207 308 minecraft:white_concrete
fill 97 207 309 97 207 311 minecraft:white_wool
setblock 97 207 312 minecraft:white_concrete
fill 97 207 313 99 207 313 minecraft:white_wool
setblock 97 207 315 minecraft:white_wool
setblock 97 207 316 minecraft:white_concrete
fill 98 207 276 98 207 278 minecraft:white_wool
setblock 98 207 279 minecraft:white_concrete
fill 98 207 280 98 207 282 minecraft:white_wool
setblock 98 207 283 minecraft:white_concrete
fill 98 207 284 98 207 286 minecraft:white_wool
setblock 98 207 287 minecraft:white_concrete
fill 98 207 288 98 207 290 minecraft:white_wool
setblock 98 207 291 minecraft:white_concrete
fill 98 207 292 98 207 294 minecraft:white_wool
setblock 98 207 295 minecraft:white_concrete
fill 98 207 296 98 207 298 minecraft:white_wool
setblock 98 207 299 minecraft:white_concrete
fill 98 207 300 98 207 302 minecraft:white_wool
setblock 98 207 303 minecraft:white_concrete
fill 98 207 304 98 207 306 minecraft:white_wool
setblock 98 207 307 minecraft:white_concrete
fill 98 207 308 98 207 310 minecraft:white_wool
setblock 98 207 311 minecraft:white_concrete
fill 98 207 312 100 207 312 minecraft:white_wool
setblock 98 207 315 minecraft:white_concrete
fill 98 207 316 100 207 316 minecraft:white_wool
fill 99 207 276 99 207 277 minecraft:white_wool
setblock 99 207 278 minecraft:white_concrete
fill 99 207 279 99 207 281 minecraft:white_wool
setblock 99 207 282 minecraft:white_concrete
fill 99 207 283 99 207 285 minecraft:white_wool
setblock 99 207 286 minecraft:white_concrete
fill 99 207 287 99 207 289 minecraft:white_wool
setblock 99 207 290 minecraft:white_concrete
fill 99 207 291 99 207 293 minecraft:white_wool
setblock 99 207 294 minecraft:white_concrete
fill 99 207 295 99 207 297 minecraft:white_wool
setblock 99 207 298 minecraft:white_concrete
fill 99 207 299 99 207 301 minecraft:white_wool
setblock 99 207 302 minecraft:white_concrete
fill 99 207 303 99 207 305 minecraft:white_wool
setblock 99 207 306 minecraft:white_concrete
fill 99 207 307 99 207 309 minecraft:white_wool
setblock 99 207 310 minecraft:white_concrete
fill 99 207 311 101 207 311 minecraft:white_wool
setblock 99 207 314 minecraft:white_concrete
fill 99 207 315 101 207 315 minecraft:white_wool
setblock 100 207 276 minecraft:white_wool
setblock 100 207 277 minecraft:white_concrete
fill 100 207 278 100 207 280 minecraft:white_wool
setblock 100 207 281 minecraft:white_concrete
fill 100 207 282 100 207 284 minecraft:white_wool
setblock 100 207 285 minecraft:white_concrete
fill 100 207 286 100 207 288 minecraft:white_wool
setblock 100 207 289 minecraft:white_concrete
fill 100 207 290 100 207 292 minecraft:white_wool
setblock 100 207 293 minecraft:white_concrete
fill 100 207 294 100 207 296 minecraft:white_wool
setblock 100 207 297 minecraft:white_concrete
fill 100 207 298 100 207 300 minecraft:white_wool
setblock 100 207 301 minecraft:white_concrete
fill 100 207 302 100 207 304 minecraft:white_wool
setblock 100 207 305 minecraft:white_concrete
fill 100 207 306 100 207 308 minecraft:white_wool
setblock 100 207 309 minecraft:white_concrete
fill 100 207 310 102 207 310 minecraft:white_wool
setblock 100 207 313 minecraft:white_concrete
fill 100 207 314 102 207 314 minecraft:white_wool
setblock 101 207 276 minecraft:white_concrete
fill 101 207 277 101 207 279 minecraft:white_wool
setblock 101 207 280 minecraft:white_concrete
fill 101 207 281 101 207 283 minecraft:white_wool
setblock 101 207 284 minecraft:white_concrete
fill 101 207 285 101 207 287 minecraft:white_wool
setblock 101 207 288 minecraft:white_concrete
fill 101 207 289 101 207 291 minecraft:white_wool
setblock 101 207 292 minecraft:white_concrete
fill 101 207 293 101 207 295 minecraft:white_wool
setblock 101 207 296 minecraft:white_concrete
fill 101 207 297 101 207 299 minecraft:white_wool
setblock 101 207 300 minecraft:white_concrete
fill 101 207 301 101 207 303 minecraft:white_wool
setblock 101 207 304 minecraft:white_concrete
fill 101 207 305 101 207 307 minecraft:white_wool
setblock 101 207 308 minecraft:white_concrete
fill 101 207 309 103 207 309 minecraft:white_wool
setblock 101 207 312 minecraft:white_concrete
fill 101 207 313 103 207 313 minecraft:white_wool
setblock 101 207 316 minecraft:white_concrete
fill 102 207 276 102 207 278 minecraft:white_wool
setblock 102 207 279 minecraft:white_concrete
fill 102 207 280 102 207 282 minecraft:white_wool
setblock 102 207 283 minecraft:white_concrete
fill 102 207 284 102 207 286 minecraft:white_wool
setblock 102 207 287 minecraft:white_concrete
fill 102 207 288 102 207 290 minecraft:white_wool
setblock 102 207 291 minecraft:white_concrete
fill 102 207 292 102 207 294 minecraft:white_wool
setblock 102 207 295 minecraft:white_concrete
fill 102 207 296 102 207 298 minecraft:white_wool
setblock 102 207 299 minecraft:white_concrete
fill 102 207 300 102 207 302 minecraft:white_wool
setblock 102 207 303 minecraft:white_concrete
fill 102 207 304 102 207 306 minecraft:white_wool
setblock 102 207 307 minecraft:white_concrete
fill 102 207 308 104 207 308 minecraft:white_wool
setblock 102 207 311 minecraft:white_concrete
fill 102 207 312 104 207 312 minecraft:white_wool
setblock 102 207 315 minecraft:white_concrete
fill 102 207 316 104 207 316 minecraft:white_wool
fill 103 207 276 103 207 277 minecraft:white_wool
setblock 103 207 278 minecraft:white_concrete
fill 103 207 279 103 207 281 minecraft:white_wool
setblock 103 207 282 minecraft:white_concrete
fill 103 207 283 103 207 285 minecraft:white_wool
setblock 103 207 286 minecraft:white_concrete
fill 103 207 287 103 207 289 minecraft:white_wool
setblock 103 207 290 minecraft:white_concrete
fill 103 207 291 103 207 293 minecraft:white_wool
setblock 103 207 294 minecraft:white_concrete
fill 103 207 295 103 207 297 minecraft:white_wool
setblock 103 207 298 minecraft:white_concrete
fill 103 207 299 103 207 301 minecraft:white_wool
setblock 103 207 302 minecraft:white_concrete
fill 103 207 303 103 207 305 minecraft:white_wool
setblock 103 207 306 minecraft:white_concrete
fill 103 207 307 105 207 307 minecraft:white_wool
setblock 103 207 310 minecraft:white_concrete
fill 103 207 311 105 207 311 minecraft:white_wool
setblock 103 207 314 minecraft:white_concrete
fill 103 207 315 105 207 315 minecraft:white_wool
setblock 104 207 276 minecraft:white_wool
setblock 104 207 277 minecraft:white_concrete
fill 104 207 278 104 207 280 minecraft:white_wool
setblock 104 207 281 minecraft:white_concrete
fill 104 207 282 104 207 284 minecraft:white_wool
setblock 104 207 285 minecraft:white_concrete
fill 104 207 286 104 207 288 minecraft:white_wool
setblock 104 207 289 minecraft:white_concrete
fill 104 207 290 104 207 292 minecraft:white_wool
setblock 104 207 293 minecraft:white_concrete
fill 104 207 294 104 207 296 minecraft:white_wool
setblock 104 207 297 minecraft:white_concrete
fill 104 207 298 104 207 300 minecraft:white_wool
setblock 104 207 301 minecraft:white_concrete
fill 104 207 302 104 207 304 minecraft:white_wool
setblock 104 207 305 minecraft:white_concrete
fill 104 207 306 106 207 306 minecraft:white_wool
setblock 104 207 309 minecraft:white_concrete
fill 104 207 310 106 207 310 minecraft:white_wool
setblock 104 207 313 minecraft:white_concrete
fill 104 207 314 106 207 314 minecraft:white_wool
setblock 105 207 276 minecraft:white_concrete
fill 105 207 277 105 207 279 minecraft:white_wool
setblock 105 207 280 minecraft:white_concrete
fill 105 207 281 105 207 283 minecraft:white_wool
setblock 105 207 284 minecraft:white_concrete
fill 105 207 285 105 207 287 minecraft:white_wool
setblock 105 207 288 minecraft:white_concrete
fill 105 207 289 105 207 291 minecraft:white_wool
setblock 105 207 292 minecraft:white_concrete
fill 105 207 293 105 207 295 minecraft:white_wool
setblock 105 207 296 minecraft:white_concrete
fill 105 207 297 105 207 299 minecraft:white_wool
setblock 105 207 300 minecraft:white_concrete
fill 105 207 301 105 207 303 minecraft:white_wool
setblock 105 207 304 minecraft:white_concrete
fill 105 207 305 107 207 305 minecraft:white_wool
setblock 105 207 308 minecraft:white_concrete
fill 105 207 309 107 207 309 minecraft:white_wool
setblock 105 207 312 minecraft:white_concrete
fill 105 207 313 107 207 313 minecraft:white_wool
setblock 105 207 316 minecraft:white_concrete
fill 106 207 276 106 207 278 minecraft:white_wool
setblock 106 207 279 minecraft:white_concrete
fill 106 207 280 106 207 282 minecraft:white_wool
setblock 106 207 283 minecraft:white_concrete
fill 106 207 284 106 207 286 minecraft:white_wool
setblock 106 207 287 minecraft:white_concrete
fill 106 207 288 106 207 290 minecraft:white_wool
setblock 106 207 291 minecraft:white_concrete
fill 106 207 292 106 207 294 minecraft:white_wool
setblock 106 207 295 minecraft:white_concrete
fill 106 207 296 106 207 298 minecraft:white_wool
setblock 106 207 299 minecraft:white_concrete
fill 106 207 300 106 207 302 minecraft:white_wool
setblock 106 207 303 minecraft:white_concrete
fill 106 207 304 108 207 304 minecraft:white_wool
setblock 106 207 307 minecraft:white_concrete
fill 106 207 308 108 207 308 minecraft:white_wool
setblock 106 207 311 minecraft:white_concrete
fill 106 207 312 108 207 312 minecraft:white_wool
setblock 106 207 315 minecraft:white_concrete
fill 106 207 316 108 207 316 minecraft:white_wool
fill 107 207 276 107 207 277 minecraft:white_wool
setblock 107 207 278 minecraft:white_concrete
fill 107 207 279 107 207 281 minecraft:white_wool
setblock 107 207 282 minecraft:white_concrete
fill 107 207 283 107 207 285 minecraft:white_wool
setblock 107 207 286 minecraft:white_concrete
fill 107 207 287 107 207 289 minecraft:white_wool
setblock 107 207 290 minecraft:white_concrete
fill 107 207 291 107 207 293 minecraft:white_wool
setblock 107 207 294 minecraft:white_concrete
fill 107 207 295 107 207 297 minecraft:white_wool
fill 107 207 298 112 207 298 minecraft:iron_block
fill 107 207 299 107 207 301 minecraft:white_wool
setblock 107 207 302 minecraft:white_concrete
fill 107 207 303 109 207 303 minecraft:white_wool
setblock 107 207 306 minecraft:white_concrete
fill 107 207 307 109 207 307 minecraft:white_wool
setblock 107 207 310 minecraft:white_concrete
fill 107 207 311 109 207 311 minecraft:white_wool
setblock 107 207 314 minecraft:white_concrete
fill 107 207 315 109 207 315 minecraft:white_wool
setblock 108 207 276 minecraft:white_wool
setblock 108 207 277 minecraft:white_concrete
fill 108 207 278 108 207 280 minecraft:white_wool
setblock 108 207 281 minecraft:white_concrete
fill 108 207 282 108 207 284 minecraft:white_wool
setblock 108 207 285 minecraft:white_concrete
fill 108 207 286 108 207 288 minecraft:white_wool
setblock 108 207 289 minecraft:white_concrete
fill 108 207 290 108 207 292 minecraft:white_wool
setblock 108 207 293 minecraft:white_concrete
setblock 108 207 295 minecraft:white_wool
fill 108 207 296 113 207 296 minecraft:iron_block
setblock 108 207 297 minecraft:white_concrete
fill 108 207 299 111 207 299 minecraft:iron_block
setblock 108 207 300 minecraft:white_wool
setblock 108 207 302 minecraft:white_wool
setblock 108 207 305 minecraft:white_concrete
fill 108 207 306 110 207 306 minecraft:white_wool
setblock 108 207 309 minecraft:white_concrete
fill 108 207 310 110 207 310 minecraft:white_wool
setblock 108 207 313 minecraft:white_concrete
fill 108 207 314 110 207 314 minecraft:white_wool
setblock 109 207 276 minecraft:white_concrete
fill 109 207 277 109 207 279 minecraft:white_wool
setblock 109 207 280 minecraft:white_concrete
fill 109 207 281 109 207 283 minecraft:white_wool
setblock 109 207 284 minecraft:white_concrete
fill 109 207 285 109 207 287 minecraft:white_wool
setblock 109 207 288 minecraft:white_concrete
fill 109 207 289 109 207 291 minecraft:white_wool
setblock 109 207 292 minecraft:white_concrete
fill 109 207 294 110 207 294 minecraft:white_wool
fill 109 207 295 113 207 295 minecraft:iron_block
setblock 109 207 297 minecraft:white_wool
setblock 109 207 300 minecraft:white_concrete
setblock 109 207 301 minecraft:white_wool
fill 109 207 302 113 207 302 minecraft:iron_block
fill 109 207 305 110 207 305 minecraft:white_wool
setblock 109 207 308 minecraft:white_concrete
fill 109 207 309 111 207 309 minecraft:white_wool
setblock 109 207 312 minecraft:white_concrete
fill 109 207 313 111 207 313 minecraft:white_wool
setblock 109 207 316 minecraft:white_concrete
fill 110 207 276 110 207 278 minecraft:white_wool
setblock 110 207 279 minecraft:white_concrete
fill 110 207 280 110 207 282 minecraft:white_wool
setblock 110 207 283 minecraft:white_concrete
fill 110 207 284 110 207 286 minecraft:white_wool
setblock 110 207 287 minecraft:white_concrete
fill 110 207 288 110 207 290 minecraft:white_wool
setblock 110 207 291 minecraft:white_concrete
setblock 110 207 293 minecraft:white_wool
fill 110 207 297 112 207 297 minecraft:iron_block
fill 110 207 300 111 207 301 minecraft:iron_block
fill 110 207 304 111 207 304 minecraft:white_wool
setblock 110 207 307 minecraft:white_concrete
fill 110 207 308 112 207 308 minecraft:white_wool
setblock 110 207 311 minecraft:white_concrete
fill 110 207 312 112 207 312 minecraft:white_wool
setblock 110 207 315 minecraft:white_concrete
fill 110 207 316 112 207 316 minecraft:white_wool
fill 111 207 276 111 207 277 minecraft:white_wool
setblock 111 207 278 minecraft:white_concrete
fill 111 207 279 111 207 281 minecraft:white_wool
setblock 111 207 282 minecraft:white_concrete
fill 111 207 283 111 207 285 minecraft:white_wool
setblock 111 207 286 minecraft:white_concrete
fill 111 207 287 111 207 289 minecraft:white_wool
fill 111 207 291 111 207 292 minecraft:white_wool
fill 111 207 293 114 207 294 minecraft:iron_block
setblock 111 207 306 minecraft:white_concrete
fill 111 207 307 112 207 307 minecraft:white_wool
setblock 111 207 310 minecraft:white_concrete
fill 111 207 311 113 207 311 minecraft:white_wool
setblock 111 207 314 minecraft:white_concrete
fill 111 207 315 113 207 315 minecraft:white_wool
setblock 112 207 276 minecraft:white_wool
setblock 112 207 277 minecraft:white_concrete
fill 112 207 278 112 207 280 minecraft:white_wool
setblock 112 207 281 minecraft:white_concrete
fill 112 207 282 112 207 284 minecraft:white_wool
setblock 112 207 285 minecraft:white_concrete
fill 112 207 286 112 207 288 minecraft:white_wool
setblock 112 207 289 minecraft:white_concrete
setblock 112 207 290 minecraft:white_wool
fill 112 207 299 112 207 300 minecraft:light_gray_concrete
setblock 112 207 301 minecraft:iron_block
setblock 112 207 305 minecraft:white_concrete
setblock 112 207 309 minecraft:white_concrete
fill 112 207 310 114 207 310 minecraft:white_wool
setblock 112 207 313 minecraft:white_concrete
fill 112 207 314 114 207 314 minecraft:white_wool
setblock 113 207 276 minecraft:white_concrete
fill 113 207 277 113 207 279 minecraft:white_wool
setblock 113 207 280 minecraft:white_concrete
fill 113 207 281 113 207 283 minecraft:white_wool
setblock 113 207 284 minecraft:white_concrete
fill 113 207 285 113 207 287 minecraft:white_wool
setblock 113 207 288 minecraft:white_concrete
setblock 113 207 289 minecraft:white_wool
fill 113 207 297 113 207 299 minecraft:red_concrete
fill 113 207 300 113 207 301 minecraft:light_gray_concrete
fill 113 207 305 113 207 306 minecraft:white_wool
setblock 113 207 308 minecraft:white_concrete
fill 113 207 309 115 207 309 minecraft:white_wool
setblock 113 207 312 minecraft:white_concrete
fill 113 207 313 115 207 313 minecraft:white_wool
setblock 113 207 316 minecraft:white_concrete
fill 114 207 276 114 207 278 minecraft:white_wool
setblock 114 207 279 minecraft:white_concrete
fill 114 207 280 114 207 282 minecraft:white_wool
setblock 114 207 283 minecraft:white_concrete
fill 114 207 284 114 207 286 minecraft:white_wool
setblock 114 207 287 minecraft:white_concrete
fill 114 207 288 116 207 288 minecraft:white_wool
setblock 114 207 290 minecraft:white_wool
setblock 114 207 295 minecraft:red_concrete
fill 114 207 296 114 207 297 minecraft:shroomlight
fill 114 207 299 114 207 300 minecraft:shroomlight
setblock 114 207 301 minecraft:red_concrete
setblock 114 207 302 minecraft:light_gray_concrete
setblock 114 207 307 minecraft:white_concrete
fill 114 207 308 116 207 308 minecraft:white_wool
setblock 114 207 311 minecraft:white_concrete
fill 114 207 312 116 207 312 minecraft:white_wool
setblock 114 207 315 minecraft:white_concrete
fill 114 207 316 116 207 316 minecraft:white_wool
fill 115 207 276 115 207 277 minecraft:white_wool
setblock 115 207 278 minecraft:white_concrete
fill 115 207 279 115 207 281 minecraft:white_wool
setblock 115 207 282 minecraft:white_concrete
fill 115 207 283 115 207 285 minecraft:white_wool
setblock 115 207 286 minecraft:white_concrete
fill 115 207 287 117 207 287 minecraft:white_wool
setblock 115 207 289 minecraft:white_wool
setblock 115 207 290 minecraft:white_concrete
fill 115 207 293 115 207 294 minecraft:light_gray_concrete
fill 115 207 295 116 207 295 minecraft:shroomlight
fill 115 207 301 116 207 301 minecraft:shroomlight
setblock 115 207 302 minecraft:iron_block
setblock 115 207 310 minecraft:white_concrete
fill 115 207 311 117 207 311 minecraft:white_wool
setblock 115 207 314 minecraft:white_concrete
fill 115 207 315 117 207 315 minecraft:white_wool
setblock 116 207 276 minecraft:white_wool
setblock 116 207 277 minecraft:white_concrete
fill 116 207 278 116 207 280 minecraft:white_wool
setblock 116 207 281 minecraft:white_concrete
fill 116 207 282 116 207 284 minecraft:white_wool
setblock 116 207 285 minecraft:white_concrete
fill 116 207 286 118 207 286 minecraft:white_wool
fill 116 207 293 119 207 293 minecraft:light_gray_concrete
fill 116 207 294 118 207 294 minecraft:red_concrete
fill 116 207 302 118 207 302 minecraft:red_concrete
fill 116 207 306 116 207 307 minecraft:white_wool
setblock 116 207 309 minecraft:white_concrete
fill 116 207 310 118 207 310 minecraft:white_wool
setblock 116 207 313 minecraft:white_concrete
fill 116 207 314 118 207 314 minecraft:white_wool
setblock 117 207 276 minecraft:white_concrete
fill 117 207 277 117 207 279 minecraft:white_wool
setblock 117 207 280 minecraft:white_concrete
fill 117 207 281 117 207 283 minecraft:white_wool
setblock 117 207 284 minecraft:white_concrete
fill 117 207 285 119 207 285 minecraft:white_wool
fill 117 207 309 119 207 309 minecraft:white_wool
setblock 117 207 312 minecraft:white_concrete
fill 117 207 313 119 207 313 minecraft:white_wool
setblock 117 207 316 minecraft:white_concrete
fill 118 207 276 118 207 278 minecraft:white_wool
setblock 118 207 279 minecraft:white_concrete
fill 118 207 280 118 207 282 minecraft:white_wool
setblock 118 207 283 minecraft:white_concrete
fill 118 207 284 120 207 284 minecraft:white_wool
setblock 118 207 287 minecraft:white_concrete
fill 118 207 288 118 207 290 minecraft:white_wool
fill 118 207 295 119 207 295 minecraft:shroomlight
fill 118 207 301 119 207 301 minecraft:shroomlight
fill 118 207 308 120 207 308 minecraft:white_wool
setblock 118 207 311 minecraft:white_concrete
fill 118 207 312 120 207 312 minecraft:white_wool
setblock 118 207 315 minecraft:white_concrete
fill 118 207 316 120 207 316 minecraft:white_wool
fill 119 207 276 119 207 277 minecraft:white_wool
setblock 119 207 278 minecraft:white_concrete
fill 119 207 279 119 207 281 minecraft:white_wool
setblock 119 207 282 minecraft:white_concrete
fill 119 207 283 121 207 283 minecraft:white_wool
setblock 119 207 286 minecraft:white_concrete
fill 119 207 287 120 207 288 minecraft:white_wool
setblock 119 207 294 minecraft:light_gray_concrete
setblock 119 207 302 minecraft:iron_block
setblock 119 207 306 minecraft:white_concrete
setblock 119 207 307 minecraft:white_wool
setblock 119 207 310 minecraft:white_concrete
fill 119 207 311 121 207 311 minecraft:white_wool
setblock 119 207 314 minecraft:white_concrete
fill 119 207 315 121 207 315 minecraft:white_wool
setblock 120 207 276 minecraft:white_wool
setblock 120 207 277 minecraft:white_concrete
fill 120 207 278 120 207 280 minecraft:white_wool
setblock 120 207 281 minecraft:white_concrete
fill 120 207 282 122 207 282 minecraft:white_wool
setblock 120 207 285 minecraft:white_concrete
fill 120 207 286 122 207 286 minecraft:white_wool
setblock 120 207 289 minecraft:white_concrete
fill 120 207 293 124 207 294 minecraft:iron_block
setblock 120 207 295 minecraft:red_concrete
fill 120 207 296 120 207 297 minecraft:shroomlight
fill 120 207 299 120 207 300 minecraft:shroomlight
setblock 120 207 301 minecraft:red_concrete
setblock 120 207 302 minecraft:light_gray_concrete
setblock 120 207 306 minecraft:white_wool
setblock 120 207 309 minecraft:white_concrete
fill 120 207 310 122 207 310 minecraft:white_wool
setblock 120 207 313 minecraft:white_concrete
fill 120 207 314 122 207 314 minecraft:white_wool
setblock 121 207 276 minecraft:white_concrete
fill 121 207 277 121 207 279 minecraft:white_wool
setblock 121 207 280 minecraft:white_concrete
fill 121 207 281 123 207 281 minecraft:white_wool
setblock 121 207 284 minecraft:white_concrete
fill 121 207 285 123 207 285 minecraft:white_wool
setblock 121 207 287 minecraft:white_wool
setblock 121 207 288 minecraft:white_concrete
fill 121 207 290 121 207 291 minecraft:white_wool
fill 121 207 295 124 207 296 minecraft:iron_block
fill 121 207 297 121 207 299 minecraft:red_concrete
fill 121 207 300 121 207 301 minecraft:light_gray_concrete
fill 121 207 302 123 207 302 minecraft:iron_block
setblock 121 207 307 minecraft:white_wool
setblock 121 207 308 minecraft:white_concrete
fill 121 207 309 123 207 309 minecraft:white_wool
setblock 121 207 312 minecraft:white_concrete
fill 121 207 313 123 207 313 minecraft:white_wool
setblock 121 207 316 minecraft:white_concrete
fill 122 207 276 122 207 278 minecraft:white_wool
setblock 122 207 279 minecraft:white_concrete
fill 122 207 280 124 207 280 minecraft:white_wool
setblock 122 207 283 minecraft:white_concrete
fill 122 207 284 124 207 284 minecraft:white_wool
setblock 122 207 287 minecraft:white_concrete
fill 122 207 288 123 207 289 minecraft:white_wool
setblock 122 207 291 minecraft:white_concrete
fill 122 207 297 124 207 297 minecraft:iron_block
fill 122 207 298 122 207 300 minecraft:light_gray_concrete
fill 122 207 301 125 207 301 minecraft:iron_block
setblock 122 207 306 minecraft:white_wool
setblock 122 207 307 minecraft:white_concrete
fill 122 207 308 124 207 308 minecraft:white_wool
setblock 122 207 311 minecraft:white_concrete
fill 122 207 312 124 207 312 minecraft:white_wool
setblock 122 207 315 minecraft:white_concrete
fill 122 207 316 124 207 316 minecraft:white_wool
fill 123 207 276 123 207 277 minecraft:white_wool
setblock 123 207 278 minecraft:white_concrete
fill 123 207 279 125 207 279 minecraft:white_wool
setblock 123 207 282 minecraft:white_concrete
fill 123 207 283 125 207 283 minecraft:white_wool
setblock 123 207 286 minecraft:white_concrete
fill 123 207 287 125 207 287 minecraft:white_wool
setblock 123 207 290 minecraft:white_concrete
fill 123 207 292 124 207 292 minecraft:white_wool
fill 123 207 298 124 207 300 minecraft:iron_block
fill 123 207 304 123 207 305 minecraft:white_wool
fill 123 207 307 125 207 307 minecraft:white_wool
setblock 123 207 310 minecraft:white_concrete
fill 123 207 311 125 207 311 minecraft:white_wool
setblock 123 207 314 minecraft:white_concrete
fill 123 207 315 125 207 315 minecraft:white_wool
setblock 124 207 276 minecraft:white_wool
setblock 124 207 277 minecraft:white_concrete
fill 124 207 278 126 207 278 minecraft:white_wool
setblock 124 207 281 minecraft:white_concrete
fill 124 207 282 126 207 282 minecraft:white_wool
setblock 124 207 285 minecraft:white_concrete
fill 124 207 286 126 207 286 minecraft:white_wool
setblock 124 207 288 minecraft:white_wool
setblock 124 207 289 minecraft:white_concrete
fill 124 207 290 125 207 291 minecraft:white_wool
fill 124 207 302 124 207 303 minecraft:white_wool
setblock 124 207 305 minecraft:white_concrete
fill 124 207 306 126 207 306 minecraft:white_wool
setblock 124 207 309 minecraft:white_concrete
fill 124 207 310 126 207 310 minecraft:white_wool
setblock 124 207 313 minecraft:white_concrete
fill 124 207 314 126 207 314 minecraft:white_wool
setblock 125 207 276 minecraft:white_concrete
fill 125 207 277 127 207 277 minecraft:white_wool
setblock 125 207 280 minecraft:white_concrete
fill 125 207 281 127 207 281 minecraft:white_wool
setblock 125 207 284 minecraft:white_concrete
fill 125 207 285 127 207 285 minecraft:white_wool
setblock 125 207 288 minecraft:white_concrete
fill 125 207 289 127 207 289 minecraft:white_wool
fill 125 207 293 127 207 293 minecraft:white_wool
setblock 125 207 295 minecraft:white_wool
setblock 125 207 296 minecraft:white_concrete
fill 125 207 298 127 207 298 minecraft:iron_block
setblock 125 207 299 minecraft:white_wool
setblock 125 207 302 minecraft:white_wool
setblock 125 207 304 minecraft:white_concrete
fill 125 207 305 127 207 305 minecraft:white_wool
setblock 125 207 308 minecraft:white_concrete
fill 125 207 309 127 207 309 minecraft:white_wool
setblock 125 207 312 minecraft:white_concrete
fill 125 207 313 127 207 313 minecraft:white_wool
setblock 125 207 316 minecraft:white_concrete
fill 126 207 276 128 207 276 minecraft:white_wool
setblock 126 207 279 minecraft:white_concrete
fill 126 207 280 128 207 280 minecraft:white_wool
setblock 126 207 283 minecraft:white_concrete
fill 126 207 284 128 207 284 minecraft:white_wool
setblock 126 207 287 minecraft:white_concrete
fill 126 207 288 128 207 288 minecraft:white_wool
setblock 126 207 290 minecraft:white_wool
setblock 126 207 291 minecraft:white_concrete
fill 126 207 292 128 207 292 minecraft:white_wool
setblock 126 207 294 minecraft:white_wool
fill 126 207 296 128 207 296 minecraft:white_wool
setblock 126 207 299 minecraft:white_concrete
fill 126 207 301 127 207 301 minecraft:white_wool
setblock 126 207 303 minecraft:white_concrete
fill 126 207 304 128 207 304 minecraft:white_wool
setblock 126 207 307 minecraft:white_concrete
fill 126 207 308 128 207 308 minecraft:white_wool
setblock 126 207 311 minecraft:white_concrete
fill 126 207 312 128 207 312 minecraft:white_wool
setblock 126 207 315 minecraft:white_concrete
fill 126 207 316 128 207 316 minecraft:white_wool
setblock 127 207 278 minecraft:white_concrete
fill 127 207 279 129 207 279 minecraft:white_wool
setblock 127 207 282 minecraft:white_concrete
fill 127 207 283 129 207 283 minecraft:white_wool
setblock 127 207 286 minecraft:white_concrete
fill 127 207 287 129 207 287 minecraft:white_wool
setblock 127 207 290 minecraft:white_concrete
fill 127 207 291 129 207 291 minecraft:white_wool
setblock 127 207 294 minecraft:white_concrete
fill 127 207 295 129 207 295 minecraft:white_wool
setblock 127 207 297 minecraft:white_wool
fill 127 207 299 128 207 300 minecraft:white_wool
setblock 127 207 302 minecraft:white_concrete
fill 127 207 303 129 207 303 minecraft:white_wool
setblock 127 207 306 minecraft:white_concrete
fill 127 207 307 129 207 307 minecraft:white_wool
setblock 127 207 310 minecraft:white_concrete
fill 127 207 311 129 207 311 minecraft:white_wool
setblock 127 207 314 minecraft:white_concrete
fill 127 207 315 129 207 315 minecraft:white_wool
setblock 128 207 277 minecraft:white_concrete
fill 128 207 278 130 207 278 minecraft:white_wool
setblock 128 207 281 minecraft:white_concrete
fill 128 207 282 130 207 282 minecraft:white_wool
setblock 128 207 285 minecraft:white_concrete
fill 128 207 286 130 207 286 minecraft:white_wool
setblock 128 207 289 minecraft:white_concrete
fill 128 207 290 130 207 290 minecraft:white_wool
setblock 128 207 293 minecraft:white_concrete
fill 128 207 294 130 207 294 minecraft:white_wool
setblock 128 207 297 minecraft:white_concrete
fill 128 207 298 130 207 298 minecraft:white_wool
setblock 128 207 301 minecraft:white_concrete
fill 128 207 302 130 207 302 minecraft:white_wool
setblock 128 207 305 minecraft:white_concrete
fill 128 207 306 130 207 306 minecraft:white_wool
setblock 128 207 309 minecraft:white_concrete
fill 128 207 310 130 207 310 minecraft:white_wool
setblock 128 207 313 minecraft:white_concrete
fill 128 207 314 130 207 314 minecraft:white_wool
setblock 129 207 276 minecraft:white_concrete
fill 129 207 277 131 207 277 minecraft:white_wool
setblock 129 207 280 minecraft:white_concrete
fill 129 207 281 131 207 281 minecraft:white_wool
setblock 129 207 284 minecraft:white_concrete
fill 129 207 285 131 207 285 minecraft:white_wool
setblock 129 207 288 minecraft:white_concrete
fill 129 207 289 131 207 289 minecraft:white_wool
setblock 129 207 292 minecraft:white_concrete
fill 129 207 293 131 207 293 minecraft:white_wool
setblock 129 207 296 minecraft:white_concrete
fill 129 207 297 131 207 297 minecraft:white_wool
setblock 129 207 299 minecraft:white_wool
setblock 129 207 300 minecraft:white_concrete
fill 129 207 301 131 207 301 minecraft:white_wool
setblock 129 207 304 minecraft:white_concrete
fill 129 207 305 131 207 305 minecraft:white_wool
setblock 129 207 308 minecraft:white_concrete
fill 129 207 309 131 207 309 minecraft:white_wool
setblock 129 207 312 minecraft:white_concrete
fill 129 207 313 131 207 313 minecraft:white_wool
setblock 129 207 316 minecraft:white_concrete
fill 130 207 276 132 207 276 minecraft:white_wool
setblock 130 207 279 minecraft:white_concrete
fill 130 207 280 132 207 280 minecraft:white_wool
setblock 130 207 283 minecraft:white_concrete
fill 130 207 284 132 207 284 minecraft:white_wool
setblock 130 207 287 minecraft:white_concrete
fill 130 207 288 132 207 288 minecraft:white_wool
setblock 130 207 291 minecraft:white_concrete
fill 130 207 292 132 207 292 minecraft:white_wool
setblock 130 207 295 minecraft:white_concrete
fill 130 207 296 132 207 296 minecraft:white_wool
setblock 130 207 299 minecraft:white_concrete
fill 130 207 300 132 207 300 minecraft:white_wool
setblock 130 207 303 minecraft:white_concrete
fill 130 207 304 132 207 304 minecraft:white_wool
setblock 130 207 307 minecraft:white_concrete
fill 130 207 308 132 207 308 minecraft:white_wool
setblock 130 207 311 minecraft:white_concrete
fill 130 207 312 132 207 312 minecraft:white_wool
setblock 130 207 315 minecraft:white_concrete
fill 130 207 316 132 207 316 minecraft:white_wool
setblock 131 207 278 minecraft:white_concrete
fill 131 207 279 133 207 279 minecraft:white_wool
setblock 131 207 282 minecraft:white_concrete
fill 131 207 283 133 207 283 minecraft:white_wool
setblock 131 207 286 minecraft:white_concrete
fill 131 207 287 133 207 287 minecraft:white_wool
setblock 131 207 290 minecraft:white_concrete
fill 131 207 291 133 207 291 minecraft:white_wool
setblock 131 207 294 minecraft:white_concrete
fill 131 207 295 133 207 295 minecraft:white_wool
setblock 131 207 298 minecraft:white_concrete
fill 131 207 299 133 207 299 minecraft:white_wool
setblock 131 207 302 minecraft:white_concrete
fill 131 207 303 133 207 303 minecraft:white_wool
setblock 131 207 306 minecraft:white_concrete
fill 131 207 307 133 207 307 minecraft:white_wool
setblock 131 207 310 minecraft:white_concrete
fill 131 207 311 133 207 311 minecraft:white_wool
setblock 131 207 314 minecraft:white_concrete
fill 131 207 315 133 207 315 minecraft:white_wool
setblock 132 207 277 minecraft:white_concrete
fill 132 207 278 134 207 278 minecraft:white_wool
setblock 132 207 281 minecraft:white_concrete
fill 132 207 282 134 207 282 minecraft:white_wool
setblock 132 207 285 minecraft:white_concrete
fill 132 207 286 134 207 286 minecraft:white_wool
setblock 132 207 289 minecraft:white_concrete
fill 132 207 290 134 207 290 minecraft:white_wool
setblock 132 207 293 minecraft:white_concrete
fill 132 207 294 134 207 294 minecraft:white_wool
setblock 132 207 297 minecraft:white_concrete
fill 132 207 298 134 207 298 minecraft:white_wool
setblock 132 207 301 minecraft:white_concrete
fill 132 207 302 134 207 302 minecraft:white_wool
setblock 132 207 305 minecraft:white_concrete
fill 132 207 306 134 207 306 minecraft:white_wool
setblock 132 207 309 minecraft:white_concrete
fill 132 207 310 134 207 310 minecraft:white_wool
setblock 132 207 313 minecraft:white_concrete
fill 132 207 314 134 207 314 minecraft:white_wool
setblock 133 207 276 minecraft:white_concrete
fill 133 207 277 135 207 277 minecraft:white_wool
setblock 133 207 280 minecraft:white_concrete
fill 133 207 281 135 207 281 minecraft:white_wool
setblock 133 207 284 minecraft:white_concrete
fill 133 207 285 135 207 285 minecraft:white_wool
setblock 133 207 288 minecraft:white_concrete
fill 133 207 289 135 207 289 minecraft:white_wool
setblock 133 207 292 minecraft:white_concrete
fill 133 207 293 135 207 293 minecraft:white_wool
setblock 133 207 296 minecraft:white_concrete
fill 133 207 297 135 207 297 minecraft:white_wool
setblock 133 207 300 minecraft:white_concrete
fill 133 207 301 135 207 301 minecraft:white_wool
setblock 133 207 304 minecraft:white_concrete
fill 133 207 305 135 207 305 minecraft:white_wool
setblock 133 207 308 minecraft:white_concrete
fill 133 207 309 135 207 309 minecraft:white_wool
setblock 133 207 312 minecraft:white_concrete
fill 133 207 313 135 207 313 minecraft:white_wool
setblock 133 207 316 minecraft:white_concrete
fill 134 207 276 135 207 276 minecraft:white_wool
setblock 134 207 279 minecraft:white_concrete
fill 134 207 280 135 207 280 minecraft:white_wool
setblock 134 207 283 minecraft:white_concrete
fill 134 207 284 135 207 284 minecraft:white_wool
setblock 134 207 287 minecraft:white_concrete
fill 134 207 288 135 207 288 minecraft:white_wool
setblock 134 207 291 minecraft:white_concrete
fill 134 207 292 135 207 292 minecraft:white_wool
setblock 134 207 295 minecraft:white_concrete
fill 134 207 296 135 207 296 minecraft:white_wool
setblock 134 207 299 minecraft:white_concrete
fill 134 207 300 135 207 300 minecraft:white_wool
setblock 134 207 303 minecraft:white_concrete
fill 134 207 304 135 207 304 minecraft:white_wool
setblock 134 207 307 minecraft:white_concrete
fill 134 207 308 135 207 308 minecraft:white_wool
setblock 134 207 311 minecraft:white_concrete
fill 134 207 312 135 207 312 minecraft:white_wool
setblock 134 207 315 minecraft:white_concrete
fill 134 207 316 135 207 316 minecraft:white_wool
setblock 135 207 278 minecraft:white_concrete
setblock 135 207 279 minecraft:white_wool
setblock 135 207 282 minecraft:white_concrete
setblock 135 207 283 minecraft:white_wool
setblock 135 207 286 minecraft:white_concrete
setblock 135 207 287 minecraft:white_wool
setblock 135 207 290 minecraft:white_concrete
setblock 135 207 291 minecraft:white_wool
setblock 135 207 294 minecraft:white_concrete
setblock 135 207 295 minecraft:white_wool
setblock 135 207 298 minecraft:white_concrete
setblock 135 207 299 minecraft:white_wool
setblock 135 207 302 minecraft:white_concrete
setblock 135 207 303 minecraft:white_wool
setblock 135 207 306 minecraft:white_concrete
setblock 135 207 307 minecraft:white_wool
setblock 135 207 310 minecraft:white_concrete
setblock 135 207 311 minecraft:white_wool
setblock 135 207 314 minecraft:white_concrete
setblock 135 207 315 minecraft:white_wool
fill 94 208 275 94 209 276 minecraft:red_concrete
fill 94 208 277 94 209 278 minecraft:white_concrete
fill 94 208 279 94 209 280 minecraft:red_concrete
fill 94 208 281 94 209 282 minecraft:white_concrete
fill 94 208 283 94 209 284 minecraft:red_concrete
fill 94 208 285 94 209 286 minecraft:white_concrete
fill 94 208 287 94 209 288 minecraft:red_concrete
fill 94 208 289 94 209 290 minecraft:white_concrete
fill 94 208 291 94 209 292 minecraft:red_concrete
fill 94 208 293 94 209 294 minecraft:white_concrete
fill 94 208 295 94 209 296 minecraft:red_concrete
fill 94 208 297 94 209 298 minecraft:white_concrete
fill 94 208 299 94 209 300 minecraft:red_concrete
fill 94 208 301 94 209 302 minecraft:white_concrete
fill 94 208 303 94 209 304 minecraft:red_concrete
fill 94 208 305 94 209 306 minecraft:white_concrete
fill 94 208 307 94 209 308 minecraft:red_concrete
fill 94 208 309 94 209 310 minecraft:white_concrete
fill 94 208 311 94 209 312 minecraft:red_concrete
fill 94 208 313 94 209 314 minecraft:white_concrete
fill 94 208 315 94 209 316 minecraft:red_concrete
fill 95 208 275 95 209 275 minecraft:red_concrete
fill 95 208 288 96 208 308 minecraft:basalt
fill 95 208 317 95 209 317 minecraft:red_concrete
fill 96 208 275 97 209 275 minecraft:white_concrete
fill 96 208 286 96 208 287 minecraft:basalt
fill 96 208 309 99 208 310 minecraft:basalt
fill 96 208 317 97 209 317 minecraft:white_concrete
setblock 97 208 284 minecraft:magma_block
fill 97 208 285 99 208 286 minecraft:basalt
setblock 97 208 287 minecraft:magma_block
fill 97 208 288 99 210 289 minecraft:basalt
setblock 97 208 290 minecraft:magma_block
fill 97 208 291 99 211 292 minecraft:basalt
setblock 97 208 293 minecraft:magma_block
fill 97 208 294 99 212 295 minecraft:basalt
setblock 97 208 296 minecraft:magma_block
fill 97 208 297 99 213 298 minecraft:basalt
setblock 97 208 299 minecraft:magma_block
fill 97 208 300 99 212 301 minecraft:basalt
setblock 97 208 302 minecraft:magma_block
fill 97 208 303 99 212 304 minecraft:basalt
setblock 97 208 305 minecraft:magma_block
fill 97 208 306 99 210 307 minecraft:basalt
setblock 97 208 308 minecraft:magma_block
setblock 97 208 311 minecraft:magma_block
fill 97 208 312 102 208 312 minecraft:basalt
fill 98 208 275 99 209 275 minecraft:red_concrete
fill 98 208 283 99 208 284 minecraft:basalt
fill 98 208 287 105 209 287 minecraft:basalt
fill 98 208 290 103 212 290 minecraft:basalt
fill 98 208 293 102 208 293 minecraft:basalt
fill 98 208 296 101 214 296 minecraft:basalt
fill 98 208 299 101 214 299 minecraft:basalt
fill 98 208 302 101 213 302 minecraft:basalt
fill 98 208 305 102 212 305 minecraft:basalt
fill 98 208 308 104 211 308 minecraft:basalt
fill 98 208 311 105 209 311 minecraft:basalt
fill 98 208 313 99 208 313 minecraft:basalt
fill 98 208 317 99 209 317 minecraft:red_concrete
fill 99 208 282 102 208 282 minecraft:basalt
fill 99 208 314 105 208 314 minecraft:basalt
fill 100 208 275 101 209 275 minecraft:white_concrete
fill 100 208 281 105 208 281 minecraft:basalt
setblock 100 208 283 minecraft:magma_block
fill 100 208 284 102 210 285 minecraft:basalt
setblock 100 208 286 minecraft:magma_block
fill 100 208 288 102 213 288 minecraft:basalt
setblock 100 208 289 minecraft:magma_block
fill 100 208 291 102 215 291 minecraft:basalt
setblock 100 208 292 minecraft:magma_block
fill 100 208 294 101 216 294 minecraft:basalt
setblock 100 208 295 minecraft:magma_block
fill 100 208 297 101 216 297 minecraft:basalt
setblock 100 208 298 minecraft:magma_block
fill 100 208 300 101 216 300 minecraft:basalt
setblock 100 208 301 minecraft:magma_block
fill 100 208 303 102 215 303 minecraft:basalt
setblock 100 208 304 minecraft:magma_block
fill 100 208 306 102 214 306 minecraft:basalt
setblock 100 208 307 minecraft:magma_block
fill 100 208 309 102 212 309 minecraft:basalt
setblock 100 208 310 minecraft:magma_block
setblock 100 208 313 minecraft:magma_block
fill 100 208 315 102 208 315 minecraft:basalt
fill 100 208 317 101 209 317 minecraft:white_concrete
fill 101 208 280 108 208 280 minecraft:basalt
fill 101 208 283 108 211 283 minecraft:basalt
fill 101 208 286 106 213 286 minecraft:basalt
fill 101 208 289 104 215 289 minecraft:basalt
fill 101 208 292 102 216 292 minecraft:basalt
fill 101 208 295 101 217 295 minecraft:basalt
fill 101 208 298 101 217 298 minecraft:basalt
fill 101 208 301 101 217 301 minecraft:basalt
fill 101 208 304 102 216 304 minecraft:basalt
fill 101 208 307 104 215 307 minecraft:basalt
fill 101 208 310 106 213 310 minecraft:basalt
fill 101 208 313 108 211 313 minecraft:basalt
fill 101 208 316 108 208 316 minecraft:basalt
fill 102 208 275 103 209 275 minecraft:red_concrete
setblock 102 208 279 minecraft:basalt
fill 102 208 317 103 209 317 minecraft:red_concrete
fill 103 208 278 105 208 278 minecraft:basalt
setblock 103 208 279 minecraft:magma_block
setblock 103 208 282 minecraft:magma_block
fill 103 208 284 105 213 284 minecraft:basalt
setblock 103 208 285 minecraft:magma_block
setblock 103 208 288 minecraft:magma_block
setblock 103 208 306 minecraft:magma_block
setblock 103 208 309 minecraft:magma_block
setblock 103 208 312 minecraft:magma_block
setblock 103 208 315 minecraft:magma_block
fill 104 208 275 105 209 275 minecraft:white_concrete
fill 104 208 279 111 209 279 minecraft:basalt
fill 104 208 282 111 212 282 minecraft:basalt
fill 104 208 285 108 208 285 minecraft:basalt
fill 104 208 288 104 217 288 minecraft:basalt
fill 104 208 309 105 216 309 minecraft:basalt
fill 104 208 312 109 214 312 minecraft:basalt
fill 104 208 315 111 211 315 minecraft:basalt
fill 104 208 317 105 209 317 minecraft:white_concrete
fill 105 208 277 108 208 277 minecraft:basalt
fill 106 208 275 107 209 275 minecraft:red_concrete
setblock 106 208 278 minecraft:magma_block
setblock 106 208 281 minecraft:magma_block
setblock 106 208 284 minecraft:magma_block
setblock 106 208 311 minecraft:magma_block
setblock 106 208 314 minecraft:magma_block
fill 106 208 317 107 209 317 minecraft:red_concrete
fill 107 208 276 111 208 276 minecraft:basalt
fill 107 208 278 114 209 278 minecraft:basalt
fill 107 208 281 114 213 281 minecraft:basalt
fill 107 208 284 109 216 284 minecraft:basalt
fill 107 208 311 108 217 311 minecraft:basalt
fill 107 208 314 114 214 314 minecraft:basalt
fill 108 208 275 109 209 275 minecraft:white_concrete
fill 108 208 317 109 209 317 minecraft:white_concrete
setblock 109 208 277 minecraft:magma_block
setblock 109 208 280 minecraft:magma_block
setblock 109 208 283 minecraft:magma_block
setblock 109 208 313 minecraft:magma_block
setblock 109 208 316 minecraft:magma_block
fill 110 208 275 111 209 275 minecraft:red_concrete
fill 110 208 277 117 209 277 minecraft:basalt
fill 110 208 280 117 213 280 minecraft:basalt
fill 110 208 283 112 217 283 minecraft:basalt
fill 110 208 313 112 217 313 minecraft:basalt
fill 110 208 316 117 213 316 minecraft:basalt
fill 110 208 317 111 209 317 minecraft:red_concrete
fill 112 208 275 113 209 275 minecraft:white_concrete
setblock 112 208 276 minecraft:magma_block
setblock 112 208 279 minecraft:magma_block
setblock 112 208 282 minecraft:magma_block
setblock 112 208 315 minecraft:magma_block
fill 112 208 317 113 209 317 minecraft:white_concrete
fill 113 208 276 120 209 276 minecraft:basalt
fill 113 208 279 120 213 279 minecraft:basalt
fill 113 208 282 120 208 282 minecraft:basalt
fill 113 208 315 120 215 315 minecraft:basalt
fill 114 208 275 115 209 275 minecraft:red_concrete
fill 114 208 317 115 209 317 minecraft:red_concrete
setblock 115 208 278 minecraft:magma_block
setblock 115 208 281 minecraft:magma_block
setblock 115 208 314 minecraft:magma_block
fill 116 208 275 117 209 275 minecraft:white_concrete
fill 116 208 278 123 212 278 minecraft:basalt
fill 116 208 281 123 214 281 minecraft:basalt
fill 116 208 314 123 216 314 minecraft:basalt
fill 116 208 317 117 209 317 minecraft:white_concrete
fill 118 208 275 119 209 275 minecraft:red_concrete
setblock 118 208 277 minecraft:magma_block
setblock 118 208 280 minecraft:magma_block
setblock 118 208 316 minecraft:magma_block
fill 118 208 317 119 209 317 minecraft:red_concrete
fill 119 208 277 126 209 277 minecraft:basalt
fill 119 208 280 126 212 280 minecraft:basalt
fill 119 208 316 126 212 316 minecraft:basalt
fill 120 208 275 121 209 275 minecraft:white_concrete
fill 120 208 317 121 209 317 minecraft:white_concrete
setblock 121 208 276 minecraft:magma_block
setblock 121 208 279 minecraft:magma_block
setblock 121 208 282 minecraft:magma_block
setblock 121 208 315 minecraft:magma_block
fill 122 208 275 123 209 275 minecraft:red_concrete
fill 122 208 276 127 208 276 minecraft:basalt
fill 122 208 279 129 210 279 minecraft:basalt
fill 122 208 282 126 215 283 minecraft:basalt
fill 122 208 313 126 216 313 minecraft:basalt
fill 122 208 315 129 212 315 minecraft:basalt
fill 122 208 317 123 209 317 minecraft:red_concrete
fill 124 208 275 125 209 275 minecraft:white_concrete
setblock 124 208 278 minecraft:magma_block
setblock 124 208 281 minecraft:magma_block
setblock 124 208 314 minecraft:magma_block
fill 124 208 317 125 209 317 minecraft:white_concrete
fill 125 208 278 131 208 278 minecraft:basalt
fill 125 208 281 132 210 281 minecraft:basalt
fill 125 208 284 132 212 284 minecraft:basalt
fill 125 208 312 129 214 312 minecraft:basalt
fill 125 208 314 132 211 314 minecraft:basalt
fill 126 208 275 127 209 275 minecraft:red_concrete
fill 126 208 285 129 208 285 minecraft:basalt
fill 126 208 311 132 213 311 minecraft:basalt
fill 126 208 317 127 209 317 minecraft:red_concrete
setblock 127 208 277 minecraft:magma_block
setblock 127 208 280 minecraft:magma_block
fill 127 208 282 129 212 282 minecraft:basalt
setblock 127 208 283 minecraft:magma_block
setblock 127 208 313 minecraft:magma_block
setblock 127 208 316 minecraft:magma_block
fill 128 208 275 129 209 275 minecraft:white_concrete
fill 128 208 277 129 208 277 minecraft:basalt
fill 128 208 280 133 208 280 minecraft:basalt
fill 128 208 283 135 209 283 minecraft:basalt
fill 128 208 286 135 211 286 minecraft:basalt
fill 128 208 310 135 211 310 minecraft:basalt
fill 128 208 313 135 209 313 minecraft:basalt
fill 128 208 316 133 208 316 minecraft:basalt
fill 128 208 317 129 209 317 minecraft:white_concrete
fill 129 208 287 132 214 287 minecraft:basalt
fill 129 208 309 129 217 309 minecraft:basalt
fill 130 208 275 131 209 275 minecraft:red_concrete
setblock 130 208 279 minecraft:magma_block
setblock 130 208 282 minecraft:magma_block
setblock 130 208 285 minecraft:magma_block
setblock 130 208 288 minecraft:magma_block
fill 130 208 289 135 213 289 minecraft:basalt
fill 130 208 307 132 214 308 minecraft:basalt
setblock 130 208 309 minecraft:magma_block
setblock 130 208 312 minecraft:magma_block
setblock 130 208 315 minecraft:magma_block
fill 130 208 317 131 209 317 minecraft:red_concrete
fill 131 208 279 132 208 279 minecraft:basalt
fill 131 208 282 135 208 282 minecraft:basalt
fill 131 208 285 135 210 285 minecraft:basalt
fill 131 208 288 135 212 288 minecraft:basalt
fill 131 208 290 132 216 290 minecraft:basalt
fill 131 208 306 135 213 306 minecraft:basalt
fill 131 208 309 135 211 309 minecraft:basalt
fill 131 208 312 135 210 312 minecraft:basalt
fill 131 208 315 134 208 315 minecraft:basalt
fill 132 208 275 133 209 275 minecraft:white_concrete
fill 132 208 291 132 217 293 minecraft:basalt
fill 132 208 303 132 217 305 minecraft:basalt
fill 132 208 317 133 209 317 minecraft:white_concrete
setblock 133 208 281 minecraft:magma_block
setblock 133 208 284 minecraft:magma_block
setblock 133 208 287 minecraft:magma_block
setblock 133 208 290 minecraft:magma_block
fill 133 208 291 135 213 292 minecraft:basalt
setblock 133 208 293 minecraft:magma_block
fill 133 208 294 135 214 295 minecraft:basalt
setblock 133 208 296 minecraft:magma_block
fill 133 208 297 135 214 298 minecraft:basalt
setblock 133 208 299 minecraft:magma_block
fill 133 208 300 135 214 301 minecraft:basalt
setblock 133 208 302 minecraft:magma_block
fill 133 208 303 135 214 304 minecraft:basalt
setblock 133 208 305 minecraft:magma_block
fill 133 208 307 135 213 307 minecraft:basalt
setblock 133 208 308 minecraft:magma_block
setblock 133 208 311 minecraft:magma_block
setblock 133 208 314 minecraft:magma_block
fill 134 208 275 135 209 275 minecraft:red_concrete
setblock 134 208 281 minecraft:basalt
fill 134 208 284 135 209 284 minecraft:basalt
fill 134 208 287 135 211 287 minecraft:basalt
fill 134 208 290 135 213 290 minecraft:basalt
fill 134 208 293 135 214 293 minecraft:basalt
fill 134 208 296 135 215 296 minecraft:basalt
fill 134 208 299 135 215 299 minecraft:basalt
fill 134 208 302 135 214 302 minecraft:basalt
fill 134 208 305 135 213 305 minecraft:basalt
fill 134 208 308 135 211 308 minecraft:basalt
fill 134 208 311 135 210 311 minecraft:basalt
fill 134 208 314 135 208 314 minecraft:basalt
fill 134 208 317 135 209 317 minecraft:red_concrete
fill 136 208 276 136 209 276 minecraft:red_concrete
fill 136 208 277 136 209 278 minecraft:white_concrete
fill 136 208 279 136 209 280 minecraft:red_concrete
fill 136 208 281 136 209 282 minecraft:white_concrete
fill 136 208 283 136 209 284 minecraft:red_concrete
fill 136 208 285 136 209 286 minecraft:white_concrete
fill 136 208 287 136 209 288 minecraft:red_concrete
fill 136 208 289 136 209 290 minecraft:white_concrete
fill 136 208 291 136 209 292 minecraft:red_concrete
fill 136 208 293 136 209 294 minecraft:white_concrete
fill 136 208 295 136 209 296 minecraft:red_concrete
fill 136 208 297 136 209 298 minecraft:white_concrete
fill 136 208 299 136 209 300 minecraft:red_concrete
fill 136 208 301 136 209 302 minecraft:white_concrete
fill 136 208 303 136 209 304 minecraft:red_concrete
fill 136 208 305 136 209 306 minecraft:white_concrete
fill 136 208 307 136 209 308 minecraft:red_concrete
fill 136 208 309 136 209 310 minecraft:white_concrete
fill 136 208 311 136 209 312 minecraft:red_concrete
fill 136 208 313 136 209 314 minecraft:white_concrete
fill 136 208 315 136 209 316 minecraft:red_concrete
fill 136 208 317 136 209 317 minecraft:white_concrete
fill 95 209 290 96 209 306 minecraft:basalt
setblock 96 209 288 minecraft:basalt
setblock 96 209 289 minecraft:magma_block
setblock 96 209 307 minecraft:magma_block
fill 96 209 308 97 209 308 minecraft:basalt
fill 97 209 286 97 209 287 minecraft:basalt
fill 97 209 290 97 211 290 minecraft:basalt
fill 97 209 293 101 212 293 minecraft:basalt
fill 97 209 296 97 213 296 minecraft:basalt
fill 97 209 299 97 213 299 minecraft:basalt
fill 97 209 302 97 212 302 minecraft:basalt
fill 97 209 305 97 211 305 minecraft:basalt
fill 97 209 309 99 209 310 minecraft:basalt
fill 98 209 284 99 209 286 minecraft:basalt
fill 98 209 312 103 209 312 minecraft:basalt
fill 99 209 283 100 209 283 minecraft:basalt
fill 99 209 313 100 209 313 minecraft:basalt
fill 100 209 282 103 209 282 minecraft:basalt
fill 100 209 286 100 212 286 minecraft:basalt
fill 100 209 289 100 214 289 minecraft:basalt
fill 100 209 292 100 215 292 minecraft:basalt
fill 100 209 295 100 216 295 minecraft:basalt
fill 100 209 298 100 216 298 minecraft:basalt
fill 100 209 301 100 216 301 minecraft:basalt
fill 100 209 304 100 215 304 minecraft:basalt
fill 100 209 307 100 214 307 minecraft:basalt
fill 100 209 310 100 212 310 minecraft:basalt
fill 100 209 314 106 209 314 minecraft:basalt
fill 101 209 281 106 209 281 minecraft:basalt
fill 101 209 315 103 209 315 minecraft:basalt
fill 102 209 280 109 209 280 minecraft:basalt
setblock 102 209 293 minecraft:magma_block
fill 102 209 294 102 218 295 minecraft:basalt
setblock 102 209 296 minecraft:magma_block
fill 102 209 300 102 218 301 minecraft:basalt
setblock 102 209 302 minecraft:magma_block
fill 102 209 316 109 209 316 minecraft:basalt
setblock 103 209 279 minecraft:basalt
fill 103 209 285 107 214 285 minecraft:basalt
fill 103 209 288 103 216 288 minecraft:basalt
fill 103 209 291 103 218 292 minecraft:basalt
fill 103 209 304 103 216 306 minecraft:basalt
fill 103 209 309 103 215 309 minecraft:basalt
fill 104 209 290 104 218 290 minecraft:basalt
setblock 104 209 306 minecraft:basalt
fill 105 209 278 106 209 278 minecraft:basalt
fill 105 209 288 105 218 288 minecraft:basalt
fill 105 209 308 105 218 308 minecraft:basalt
fill 106 209 284 106 215 284 minecraft:basalt
fill 106 209 287 106 218 287 minecraft:basalt
fill 106 209 309 106 218 309 minecraft:basalt
fill 106 209 311 106 216 311 minecraft:basalt
fill 107 209 277 109 209 277 minecraft:basalt
fill 107 209 286 107 218 286 minecraft:basalt
fill 107 209 310 107 218 310 minecraft:basalt
setblock 108 209 285 minecraft:magma_block
fill 109 209 276 112 209 276 minecraft:basalt
fill 109 209 283 109 216 283 minecraft:basalt
fill 109 209 285 109 218 285 minecraft:basalt
fill 109 209 311 109 218 311 minecraft:basalt
fill 109 209 313 109 216 313 minecraft:basalt
fill 110 209 284 110 218 284 minecraft:basalt
fill 110 209 312 111 218 312 minecraft:basalt
setblock 111 209 284 minecraft:magma_block
fill 112 209 279 112 213 279 minecraft:basalt
fill 112 209 282 116 216 282 minecraft:basalt
fill 112 209 315 112 215 315 minecraft:basalt
fill 113 209 283 113 218 283 minecraft:basalt
fill 113 209 313 113 218 313 minecraft:basalt
setblock 114 209 283 minecraft:magma_block
setblock 114 209 313 minecraft:magma_block
fill 115 209 278 115 213 278 minecraft:basalt
fill 115 209 281 115 216 281 minecraft:basalt
fill 115 209 283 115 218 283 minecraft:basalt
fill 115 209 313 115 216 314 minecraft:basalt
setblock 117 209 282 minecraft:magma_block
fill 118 209 277 118 212 277 minecraft:basalt
fill 118 209 280 118 215 280 minecraft:basalt
fill 118 209 282 121 216 282 minecraft:basalt
fill 118 209 316 118 215 316 minecraft:basalt
fill 119 209 283 121 209 283 minecraft:basalt
fill 119 209 313 121 209 313 minecraft:basalt
fill 121 209 276 125 209 276 minecraft:basalt
fill 121 209 279 121 213 279 minecraft:basalt
fill 121 209 315 121 216 315 minecraft:basalt
fill 123 209 284 124 218 284 minecraft:basalt
fill 123 209 312 124 218 312 minecraft:basalt
fill 124 209 278 128 209 278 minecraft:basalt
fill 124 209 281 124 215 281 minecraft:basalt
fill 124 209 314 124 216 314 minecraft:basalt
fill 125 209 285 125 218 285 minecraft:basalt
setblock 125 209 311 minecraft:basalt
setblock 126 209 285 minecraft:magma_block
setblock 127 209 277 minecraft:basalt
fill 127 209 280 131 210 280 minecraft:basalt
fill 127 209 283 127 215 283 minecraft:basalt
fill 127 209 285 127 217 286 minecraft:basalt
fill 127 209 310 127 218 310 minecraft:basalt
fill 127 209 313 127 215 313 minecraft:basalt
fill 127 209 316 131 210 316 minecraft:basalt
fill 128 209 285 130 214 285 minecraft:basalt
fill 128 209 287 128 218 287 minecraft:basalt
fill 128 209 309 128 218 309 minecraft:basalt
setblock 129 209 278 minecraft:magma_block
fill 129 209 288 130 216 288 minecraft:basalt
setblock 129 209 308 minecraft:magma_block
fill 130 209 279 131 209 279 minecraft:basalt
fill 130 209 282 134 209 282 minecraft:basalt
fill 130 209 290 130 218 290 minecraft:basalt
fill 130 209 306 130 218 306 minecraft:basalt
fill 130 209 309 130 216 309 minecraft:basalt
fill 130 209 312 130 214 312 minecraft:basalt
fill 130 209 315 133 209 315 minecraft:basalt
fill 131 209 291 131 218 292 minecraft:basalt
fill 131 209 304 131 218 305 minecraft:basalt
setblock 132 209 280 minecraft:magma_block
fill 132 209 294 132 218 294 minecraft:basalt
setblock 132 209 295 minecraft:magma_block
fill 132 209 296 133 216 296 minecraft:basalt
fill 132 209 300 132 218 300 minecraft:basalt
setblock 132 209 301 minecraft:magma_block
fill 132 209 302 133 216 302 minecraft:basalt
setblock 132 209 316 minecraft:magma_block
setblock 133 209 281 minecraft:basalt
fill 133 209 284 133 211 284 minecraft:basalt
fill 133 209 287 133 213 287 minecraft:basalt
fill 133 209 290 133 215 290 minecraft:basalt
fill 133 209 293 133 216 293 minecraft:basalt
fill 133 209 299 133 216 299 minecraft:basalt
fill 133 209 305 133 216 305 minecraft:basalt
fill 133 209 308 133 214 308 minecraft:basalt
fill 133 209 311 133 212 311 minecraft:basalt
fill 133 209 314 134 209 314 minecraft:basalt
fill 94 210 275 94 211 276 minecraft:white_concrete
fill 94 210 277 94 211 278 minecraft:red_concrete
fill 94 210 279 94 211 280 minecraft:white_concrete
fill 94 210 281 94 211 282 minecraft:red_concrete
fill 94 210 283 94 211 284 minecraft:white_concrete
fill 94 210 285 94 211 286 minecraft:red_concrete
fill 94 210 287 94 211 288 minecraft:white_concrete
fill 94 210 289 94 211 290 minecraft:red_concrete
fill 94 210 291 94 211 292 minecraft:white_concrete
fill 94 210 293 94 211 294 minecraft:red_concrete
fill 94 210 295 94 211 296 minecraft:white_concrete
fill 94 210 297 94 211 298 minecraft:red_concrete
fill 94 210 299 94 211 300 minecraft:white_concrete
fill 94 210 301 94 211 302 minecraft:red_concrete
fill 94 210 303 94 211 304 minecraft:white_concrete
fill 94 210 305 94 211 306 minecraft:red_concrete
fill 94 210 307 94 211 308 minecraft:white_concrete
fill 94 210 309 94 211 310 minecraft:red_concrete
fill 94 210 311 94 211 312 minecraft:white_concrete
fill 94 210 313 94 211 314 minecraft:red_concrete
fill 94 210 315 94 211 316 minecraft:white_concrete
fill 95 210 275 95 211 275 minecraft:white_concrete
fill 95 210 292 96 210 293 minecraft:basalt
setblock 95 210 294 minecraft:magma_block
fill 95 210 295 96 210 296 minecraft:basalt
setblock 95 210 297 minecraft:magma_block
fill 95 210 298 96 210 299 minecraft:basalt
setblock 95 210 300 minecraft:magma_block
fill 95 210 301 96 210 302 minecraft:basalt
setblock 95 210 303 minecraft:magma_block
fill 95 210 304 96 210 304 minecraft:basalt
fill 95 210 317 95 211 317 minecraft:white_concrete
fill 96 210 275 97 211 275 minecraft:red_concrete
fill 96 210 290 96 210 291 minecraft:basalt
fill 96 210 294 96 211 294 minecraft:basalt
fill 96 210 297 96 211 297 minecraft:basalt
fill 96 210 300 96 211 300 minecraft:basalt
fill 96 210 303 96 211 303 minecraft:basalt
fill 96 210 305 96 210 306 minecraft:basalt
fill 96 210 317 97 211 317 minecraft:red_concrete
setblock 97 210 308 minecraft:basalt
fill 98 210 275 99 211 275 minecraft:white_concrete
fill 98 210 286 99 210 286 minecraft:basalt
setblock 98 210 287 minecraft:magma_block
fill 98 210 309 99 210 310 minecraft:basalt
fill 98 210 317 99 211 317 minecraft:white_concrete
fill 99 210 284 99 210 285 minecraft:basalt
fill 99 210 287 105 211 287 minecraft:basalt
fill 99 210 311 103 210 312 minecraft:basalt
fill 100 210 275 101 211 275 minecraft:red_concrete
setblock 100 210 283 minecraft:basalt
setblock 100 210 313 minecraft:basalt
fill 100 210 317 101 211 317 minecraft:red_concrete
fill 101 210 282 103 210 282 minecraft:basalt
fill 101 210 314 106 210 314 minecraft:basalt
fill 102 210 275 103 211 275 minecraft:white_concrete
fill 102 210 281 106 210 281 minecraft:basalt
fill 102 210 293 103 217 293 minecraft:basalt
fill 102 210 296 102 217 299 minecraft:basalt
fill 102 210 302 103 210 302 minecraft:basalt
fill 102 210 315 103 210 315 minecraft:basalt
fill 102 210 317 103 211 317 minecraft:white_concrete
fill 103 210 280 109 210 280 minecraft:basalt
fill 103 210 294 103 219 294 minecraft:basalt
fill 103 210 303 103 219 303 minecraft:basalt
fill 103 210 316 109 210 316 minecraft:basalt
fill 104 210 275 105 211 275 minecraft:red_concrete
setblock 104 210 291 minecraft:magma_block
fill 104 210 305 104 219 305 minecraft:basalt
setblock 104 210 306 minecraft:magma_block
fill 104 210 311 105 214 311 minecraft:basalt
fill 104 210 317 105 211 317 minecraft:red_concrete
fill 105 210 279 111 210 279 minecraft:basalt
fill 105 210 289 105 217 289 minecraft:basalt
fill 105 210 307 105 217 307 minecraft:basalt
fill 106 210 275 107 211 275 minecraft:white_concrete
fill 106 210 288 106 219 288 minecraft:basalt
fill 106 210 308 106 219 308 minecraft:basalt
fill 106 210 317 107 211 317 minecraft:white_concrete
setblock 107 210 278 minecraft:magma_block
setblock 107 210 287 minecraft:magma_block
fill 107 210 309 107 219 309 minecraft:basalt
fill 108 210 275 109 211 275 minecraft:red_concrete
fill 108 210 278 114 211 278 minecraft:basalt
fill 108 210 285 108 217 286 minecraft:basalt
fill 108 210 310 108 218 310 minecraft:basalt
fill 108 210 317 109 211 317 minecraft:red_concrete
setblock 109 210 277 minecraft:basalt
fill 110 210 275 111 211 275 minecraft:white_concrete
setblock 110 210 277 minecraft:magma_block
fill 110 210 285 110 219 285 minecraft:basalt
fill 110 210 311 110 219 311 minecraft:basalt
fill 110 210 317 111 211 317 minecraft:white_concrete
fill 111 210 276 112 210 277 minecraft:basalt
fill 111 210 284 113 217 284 minecraft:basalt
fill 112 210 275 113 211 275 minecraft:red_concrete
fill 112 210 312 112 219 312 minecraft:basalt
fill 112 210 317 113 211 317 minecraft:red_concrete
setblock 113 210 276 minecraft:magma_block
fill 113 210 277 117 210 277 minecraft:basalt
setblock 113 210 312 minecraft:magma_block
fill 114 210 275 115 211 275 minecraft:white_concrete
fill 114 210 276 121 210 276 minecraft:basalt
fill 114 210 283 114 217 283 minecraft:basalt
fill 114 210 313 114 217 313 minecraft:basalt
fill 114 210 317 115 211 317 minecraft:white_concrete
fill 116 210 275 117 211 275 minecraft:red_concrete
fill 116 210 283 118 218 283 minecraft:basalt
fill 116 210 313 118 218 313 minecraft:basalt
fill 116 210 317 117 211 317 minecraft:red_concrete
fill 117 210 282 117 217 282 minecraft:basalt
fill 118 210 275 119 211 275 minecraft:white_concrete
fill 118 210 317 119 211 317 minecraft:white_concrete
fill 119 210 277 125 210 277 minecraft:basalt
setblock 119 210 283 minecraft:magma_block
setblock 119 210 313 minecraft:magma_block
fill 120 210 275 121 211 275 minecraft:red_concrete
fill 120 210 283 121 218 283 minecraft:basalt
fill 120 210 313 121 218 313 minecraft:basalt
fill 120 210 317 121 211 317 minecraft:red_concrete
fill 121 210 284 122 210 284 minecraft:basalt
fill 121 210 312 121 219 312 minecraft:basalt
fill 122 210 275 123 211 275 minecraft:white_concrete
setblock 122 210 276 minecraft:magma_block
setblock 122 210 312 minecraft:magma_block
fill 122 210 317 123 211 317 minecraft:white_concrete
setblock 123 210 276 minecraft:basalt
fill 124 210 275 125 211 275 minecraft:red_concrete
fill 124 210 278 127 210 278 minecraft:basalt
fill 124 210 285 124 219 285 minecraft:basalt
fill 124 210 311 124 219 311 minecraft:basalt
fill 124 210 317 125 211 317 minecraft:red_concrete
setblock 125 210 311 minecraft:magma_block
fill 126 210 275 127 211 275 minecraft:white_concrete
fill 126 210 285 126 217 286 minecraft:basalt
fill 126 210 310 126 218 310 minecraft:basalt
fill 126 210 317 127 211 317 minecraft:white_concrete
fill 127 210 287 127 219 287 minecraft:basalt
fill 127 210 309 127 219 309 minecraft:basalt
fill 128 210 275 129 211 275 minecraft:red_concrete
fill 128 210 283 134 210 283 minecraft:basalt
fill 128 210 288 128 219 288 minecraft:basalt
fill 128 210 308 129 217 308 minecraft:basalt
fill 128 210 313 134 210 313 minecraft:basalt
fill 128 210 317 129 211 317 minecraft:red_concrete
fill 129 210 289 129 218 289 minecraft:basalt
fill 129 210 307 129 218 307 minecraft:basalt
fill 130 210 275 131 211 275 minecraft:white_concrete
fill 130 210 282 133 210 282 minecraft:basalt
fill 130 210 291 130 219 291 minecraft:basalt
fill 130 210 305 130 219 305 minecraft:basalt
fill 130 210 315 130 211 315 minecraft:basalt
fill 130 210 317 131 211 317 minecraft:white_concrete
fill 131 210 293 131 219 293 minecraft:basalt
setblock 131 210 294 minecraft:magma_block
fill 131 210 302 131 219 302 minecraft:basalt
setblock 131 210 303 minecraft:magma_block
setblock 131 210 315 minecraft:magma_block
fill 132 210 275 133 211 275 minecraft:red_concrete
fill 132 210 295 132 217 295 minecraft:basalt
fill 132 210 297 132 217 299 minecraft:basalt
fill 132 210 301 132 217 301 minecraft:basalt
setblock 132 210 315 minecraft:basalt
fill 132 210 317 133 211 317 minecraft:red_concrete
setblock 133 210 314 minecraft:basalt
fill 134 210 275 135 211 275 minecraft:white_concrete
setblock 134 210 284 minecraft:magma_block
fill 134 210 317 135 211 317 minecraft:white_concrete
setblock 135 210 284 minecraft:basalt
fill 136 210 276 136 211 276 minecraft:white_concrete
fill 136 210 277 136 211 278 minecraft:red_concrete
fill 136 210 279 136 211 280 minecraft:white_concrete
fill 136 210 281 136 211 282 minecraft:red_concrete
fill 136 210 283 136 211 284 minecraft:white_concrete
fill 136 210 285 136 211 286 minecraft:red_concrete
fill 136 210 287 136 211 288 minecraft:white_concrete
fill 136 210 289 136 211 290 minecraft:red_concrete
fill 136 210 291 136 211 292 minecraft:white_concrete
fill 136 210 293 136 211 294 minecraft:red_concrete
fill 136 210 295 136 211 296 minecraft:white_concrete
fill 136 210 297 136 211 298 minecraft:red_concrete
fill 136 210 299 136 211 300 minecraft:white_concrete
fill 136 210 301 136 211 302 minecraft:red_concrete
fill 136 210 303 136 211 304 minecraft:white_concrete
fill 136 210 305 136 211 306 minecraft:red_concrete
fill 136 210 307 136 211 308 minecraft:white_concrete
fill 136 210 309 136 211 310 minecraft:red_concrete
fill 136 210 311 136 211 312 minecraft:white_concrete
fill 136 210 313 136 211 314 minecraft:red_concrete
fill 136 210 315 136 211 316 minecraft:white_concrete
fill 136 210 317 136 211 317 minecraft:red_concrete
fill 95 211 276 95 211 316 minecraft:red_terracotta
fill 96 211 276 135 211 276 minecraft:red_terracotta
fill 96 211 292 96 211 293 minecraft:basalt
fill 96 211 295 96 211 296 minecraft:basalt
fill 96 211 298 96 212 299 minecraft:basalt
fill 96 211 301 96 211 302 minecraft:basalt
setblock 96 211 304 minecraft:basalt
fill 96 211 316 104 211 316 minecraft:red_terracotta
fill 97 211 279 97 211 281 minecraft:brown_terracotta
setblock 97 211 289 minecraft:magma_block
fill 97 211 306 99 211 306 minecraft:basalt
setblock 97 211 307 minecraft:magma_block
fill 98 211 278 100 211 278 minecraft:brown_terracotta
fill 98 211 279 100 217 281 minecraft:red_terracotta
fill 98 211 282 100 211 282 minecraft:brown_terracotta
fill 98 211 288 99 211 289 minecraft:basalt
fill 98 211 307 99 212 307 minecraft:basalt
setblock 99 211 286 minecraft:basalt
fill 99 211 309 99 211 310 minecraft:basalt
setblock 100 211 285 minecraft:magma_block
fill 100 211 311 103 211 311 minecraft:basalt
fill 101 211 279 101 211 281 minecraft:brown_terracotta
fill 101 211 284 102 211 285 minecraft:basalt
fill 101 211 312 103 211 312 minecraft:basalt
fill 102 211 282 103 211 282 minecraft:basalt
fill 102 211 302 102 217 302 minecraft:basalt
setblock 102 211 314 minecraft:basalt
fill 103 211 295 103 219 295 minecraft:basalt
setblock 103 211 296 minecraft:magma_block
fill 103 211 297 103 220 298 minecraft:basalt
setblock 103 211 299 minecraft:magma_block
fill 103 211 300 103 219 301 minecraft:basalt
setblock 103 211 302 minecraft:magma_block
setblock 103 211 314 minecraft:magma_block
fill 104 211 281 106 211 281 minecraft:basalt
fill 104 211 291 104 218 293 minecraft:basalt
fill 104 211 303 104 219 304 minecraft:basalt
fill 104 211 306 105 218 306 minecraft:basalt
fill 104 211 314 106 212 314 minecraft:basalt
setblock 105 211 280 minecraft:basalt
fill 105 211 290 105 211 291 minecraft:basalt
fill 105 211 305 105 220 305 minecraft:basalt
setblock 105 211 316 minecraft:basalt
setblock 106 211 280 minecraft:magma_block
setblock 106 211 289 minecraft:magma_block
setblock 106 211 307 minecraft:magma_block
setblock 106 211 316 minecraft:magma_block
fill 107 211 279 109 211 280 minecraft:basalt
fill 107 211 287 107 218 288 minecraft:basalt
fill 107 211 308 107 218 308 minecraft:basalt
fill 107 211 316 109 212 316 minecraft:basalt
fill 108 211 287 108 219 287 minecraft:basalt
fill 108 211 309 108 219 309 minecraft:basalt
fill 109 211 286 110 219 286 minecraft:basalt
fill 109 211 310 110 219 310 minecraft:basalt
fill 110 211 279 111 212 279 minecraft:basalt
fill 111 211 277 114 211 277 minecraft:basalt
fill 111 211 285 112 219 285 minecraft:basalt
fill 111 211 311 111 219 311 minecraft:basalt
setblock 112 211 311 minecraft:magma_block
fill 113 211 312 117 218 312 minecraft:basalt
fill 114 211 284 120 211 284 minecraft:basalt
setblock 115 211 277 minecraft:magma_block
fill 116 211 277 117 212 277 minecraft:basalt
setblock 118 211 312 minecraft:magma_block
fill 119 211 277 123 211 277 minecraft:basalt
fill 119 211 283 119 218 283 minecraft:basalt
fill 119 211 312 119 218 313 minecraft:basalt
fill 120 211 312 120 219 312 minecraft:basalt
setblock 121 211 284 minecraft:magma_block
fill 122 211 279 126 212 279 minecraft:basalt
fill 122 211 284 122 219 285 minecraft:basalt
fill 122 211 311 122 218 312 minecraft:basalt
fill 123 211 285 123 219 285 minecraft:basalt
fill 123 211 311 123 219 311 minecraft:basalt
fill 124 211 278 126 211 278 minecraft:basalt
setblock 124 211 286 minecraft:magma_block
setblock 124 211 310 minecraft:magma_block
fill 125 211 281 129 212 281 minecraft:basalt
fill 125 211 286 125 219 286 minecraft:basalt
fill 125 211 310 125 218 311 minecraft:basalt
fill 126 211 287 126 219 287 minecraft:basalt
fill 126 211 309 126 219 309 minecraft:basalt
setblock 127 211 279 minecraft:magma_block
fill 127 211 280 129 211 280 minecraft:basalt
setblock 127 211 288 minecraft:magma_block
fill 127 211 308 127 219 308 minecraft:basalt
fill 127 211 316 129 211 316 minecraft:basalt
fill 128 211 283 132 211 283 minecraft:basalt
fill 128 211 289 128 218 289 minecraft:basalt
fill 128 211 307 128 218 307 minecraft:basalt
fill 128 211 313 132 211 313 minecraft:basalt
fill 129 211 290 129 219 291 minecraft:basalt
fill 129 211 305 129 219 306 minecraft:basalt
setblock 130 211 281 minecraft:magma_block
fill 130 211 282 132 211 282 minecraft:basalt
fill 130 211 292 130 219 292 minecraft:basalt
setblock 130 211 293 minecraft:magma_block
fill 130 211 303 130 219 304 minecraft:basalt
fill 130 211 316 135 211 316 minecraft:red_terracotta
fill 131 211 285 134 211 285 minecraft:basalt
fill 131 211 294 131 218 301 minecraft:basalt
fill 131 211 303 131 218 303 minecraft:basalt
fill 131 211 312 133 211 312 minecraft:basalt
setblock 133 211 283 minecraft:magma_block
setblock 133 211 313 minecraft:magma_block
setblock 134 211 311 minecraft:basalt
fill 135 211 277 135 211 285 minecraft:red_terracotta
fill 135 211 311 135 211 315 minecraft:red_terracotta
fill 94 212 275 94 213 276 minecraft:red_concrete
fill 94 212 277 94 213 278 minecraft:white_concrete
fill 94 212 279 94 213 280 minecraft:red_concrete
fill 94 212 281 94 213 282 minecraft:white_concrete
fill 94 212 283 94 213 284 minecraft:red_concrete
fill 94 212 285 94 213 286 minecraft:white_concrete
fill 94 212 287 94 213 288 minecraft:red_concrete
fill 94 212 289 94 213 290 minecraft:white_concrete
fill 94 212 291 94 213 292 minecraft:red_concrete
fill 94 212 293 94 213 294 minecraft:white_concrete
fill 94 212 295 94 213 296 minecraft:red_concrete
fill 94 212 297 94 213 298 minecraft:white_concrete
fill 94 212 299 94 213 300 minecraft:red_concrete
fill 94 212 301 94 213 302 minecraft:white_concrete
fill 94 212 303 94 213 304 minecraft:red_concrete
fill 94 212 305 94 213 306 minecraft:white_concrete
fill 94 212 307 94 213 308 minecraft:red_concrete
fill 94 212 309 94 213 310 minecraft:white_concrete
fill 94 212 311 94 213 312 minecraft:red_concrete
fill 94 212 313 94 213 314 minecraft:white_concrete
fill 94 212 315 94 213 316 minecraft:red_concrete
fill 95 212 275 95 213 275 minecraft:red_concrete
fill 95 212 282 95 272 283 minecraft:red_terracotta
fill 95 212 290 95 272 291 minecraft:red_terracotta
fill 95 212 298 95 272 299 minecraft:red_terracotta
fill 95 212 306 95 272 307 minecraft:red_terracotta
fill 95 212 314 95 272 315 minecraft:red_terracotta
fill 95 212 317 95 213 317 minecraft:red_concrete
fill 96 212 275 97 213 275 minecraft:white_concrete
fill 96 212 276 97 272 276 minecraft:red_terracotta
setblock 96 212 297 minecraft:magma_block
fill 96 212 317 97 213 317 minecraft:white_concrete
fill 97 212 292 99 212 292 minecraft:basalt
fill 98 212 275 99 213 275 minecraft:red_concrete
fill 98 212 289 99 212 289 minecraft:basalt
fill 98 212 291 99 212 291 minecraft:basalt
fill 98 212 306 99 212 306 minecraft:basalt
fill 98 212 317 99 213 317 minecraft:red_concrete
setblock 99 212 288 minecraft:basalt
setblock 99 212 308 minecraft:magma_block
fill 100 212 275 101 213 275 minecraft:white_concrete
fill 100 212 287 105 212 287 minecraft:basalt
fill 100 212 308 104 213 308 minecraft:basalt
fill 100 212 317 101 213 317 minecraft:white_concrete
fill 101 212 285 102 212 285 minecraft:basalt
fill 101 212 311 103 212 311 minecraft:basalt
fill 101 212 316 102 272 316 minecraft:red_terracotta
fill 102 212 275 103 213 275 minecraft:red_concrete
setblock 102 212 284 minecraft:basalt
fill 102 212 312 103 212 312 minecraft:basalt
fill 102 212 317 103 213 317 minecraft:red_concrete
fill 103 212 283 108 212 283 minecraft:basalt
fill 103 212 296 103 219 296 minecraft:basalt
fill 103 212 299 103 219 299 minecraft:basalt
fill 103 212 302 104 219 302 minecraft:basalt
fill 103 212 313 108 212 313 minecraft:basalt
fill 104 212 275 105 213 275 minecraft:white_concrete
fill 104 212 276 105 272 276 minecraft:red_terracotta
fill 104 212 294 104 220 295 minecraft:basalt
fill 104 212 301 104 220 301 minecraft:basalt
fill 104 212 317 105 213 317 minecraft:white_concrete
fill 105 212 281 106 212 281 minecraft:basalt
fill 105 212 290 106 219 290 minecraft:basalt
setblock 105 212 291 minecraft:magma_block
fill 105 212 292 105 220 292 minecraft:basalt
fill 105 212 304 105 220 304 minecraft:basalt
setblock 105 212 315 minecraft:magma_block
fill 106 212 275 107 213 275 minecraft:red_concrete
fill 106 212 289 107 219 289 minecraft:basalt
fill 106 212 306 106 219 307 minecraft:basalt
fill 106 212 315 111 212 315 minecraft:basalt
fill 106 212 317 107 213 317 minecraft:red_concrete
fill 107 212 280 109 212 280 minecraft:basalt
fill 107 212 307 107 220 307 minecraft:basalt
fill 108 212 275 109 213 275 minecraft:white_concrete
fill 108 212 279 109 212 279 minecraft:basalt
fill 108 212 288 108 220 288 minecraft:basalt
setblock 108 212 308 minecraft:magma_block
fill 108 212 317 109 213 317 minecraft:white_concrete
fill 109 212 287 109 220 287 minecraft:basalt
fill 109 212 309 109 219 309 minecraft:basalt
fill 110 212 275 111 213 275 minecraft:red_concrete
fill 110 212 317 111 213 317 minecraft:red_concrete
fill 111 212 278 114 212 278 minecraft:basalt
setblock 111 212 286 minecraft:magma_block
fill 111 212 289 111 213 289 minecraft:red_concrete
setblock 111 212 310 minecraft:magma_block
fill 112 212 275 113 213 275 minecraft:white_concrete
fill 112 212 276 113 272 276 minecraft:red_terracotta
fill 112 212 311 114 219 311 minecraft:basalt
fill 112 212 317 113 213 317 minecraft:white_concrete
fill 113 212 285 113 220 285 minecraft:basalt
fill 114 212 275 115 213 275 minecraft:red_concrete
fill 114 212 284 116 218 284 minecraft:basalt
setblock 114 212 285 minecraft:magma_block
fill 114 212 317 115 213 317 minecraft:red_concrete
fill 116 212 275 117 213 275 minecraft:white_concrete
fill 116 212 317 117 213 317 minecraft:white_concrete
setblock 117 212 284 minecraft:magma_block
fill 118 212 275 119 213 275 minecraft:red_concrete
fill 118 212 284 121 219 284 minecraft:basalt
fill 118 212 312 118 219 312 minecraft:basalt
fill 118 212 317 119 213 317 minecraft:red_concrete
fill 120 212 275 121 213 275 minecraft:white_concrete
fill 120 212 276 121 272 276 minecraft:red_terracotta
fill 120 212 285 121 220 285 minecraft:basalt
fill 120 212 311 121 219 311 minecraft:basalt
fill 120 212 317 121 213 317 minecraft:white_concrete
fill 122 212 275 123 213 275 minecraft:red_concrete
fill 122 212 317 123 213 317 minecraft:red_concrete
fill 123 212 286 124 219 286 minecraft:basalt
fill 123 212 310 124 219 310 minecraft:basalt
fill 124 212 275 125 213 275 minecraft:white_concrete
fill 124 212 317 125 213 317 minecraft:white_concrete
fill 125 212 287 125 220 287 minecraft:basalt
fill 125 212 309 125 220 309 minecraft:basalt
fill 125 212 314 130 212 314 minecraft:basalt
fill 126 212 275 127 213 275 minecraft:red_concrete
fill 126 212 288 127 219 288 minecraft:basalt
setblock 126 212 308 minecraft:magma_block
fill 126 212 317 127 213 317 minecraft:red_concrete
setblock 127 212 280 minecraft:basalt
fill 127 212 289 127 220 289 minecraft:basalt
fill 127 212 307 127 220 307 minecraft:basalt
setblock 127 212 316 minecraft:basalt
fill 128 212 275 129 213 275 minecraft:white_concrete
fill 128 212 276 129 272 276 minecraft:red_terracotta
fill 128 212 283 131 212 283 minecraft:basalt
fill 128 212 286 134 212 286 minecraft:basalt
fill 128 212 290 128 220 290 minecraft:basalt
fill 128 212 306 128 220 306 minecraft:basalt
fill 128 212 310 134 212 310 minecraft:basalt
fill 128 212 313 131 212 313 minecraft:basalt
fill 128 212 317 129 213 317 minecraft:white_concrete
setblock 129 212 292 minecraft:magma_block
setblock 129 212 304 minecraft:magma_block
fill 130 212 275 131 213 275 minecraft:red_concrete
setblock 130 212 282 minecraft:basalt
fill 130 212 293 130 219 295 minecraft:basalt
fill 130 212 301 130 219 302 minecraft:basalt
fill 130 212 317 131 213 317 minecraft:red_concrete
fill 131 212 285 133 212 285 minecraft:basalt
fill 131 212 309 134 212 309 minecraft:basalt
fill 131 212 312 131 213 312 minecraft:basalt
fill 132 212 275 133 213 275 minecraft:white_concrete
setblock 132 212 312 minecraft:magma_block
fill 132 212 317 133 213 317 minecraft:white_concrete
fill 133 212 316 134 272 316 minecraft:red_terracotta
fill 134 212 275 135 213 275 minecraft:red_concrete
setblock 134 212 287 minecraft:basalt
fill 134 212 308 134 213 308 minecraft:basalt
fill 134 212 317 135 213 317 minecraft:red_concrete
fill 135 212 277 135 272 278 minecraft:red_terracotta
fill 135 212 285 135 272 286 minecraft:red_terracotta
setblock 135 212 308 minecraft:magma_block
fill 135 212 309 135 272 310 minecraft:red_terracotta
fill 136 212 276 136 213 276 minecraft:red_concrete
fill 136 212 277 136 213 278 minecraft:white_concrete
fill 136 212 279 136 213 280 minecraft:red_concrete
fill 136 212 281 136 213 282 minecraft:white_concrete
fill 136 212 283 136 213 284 minecraft:red_concrete
fill 136 212 285 136 213 286 minecraft:white_concrete
fill 136 212 287 136 213 288 minecraft:red_concrete
fill 136 212 289 136 213 290 minecraft:white_concrete
fill 136 212 291 136 213 292 minecraft:red_concrete
fill 136 212 293 136 213 294 minecraft:white_concrete
schedule function dropper:buildpart/62_6 1t
