fill 292 192 535 292 193 535 minecraft:gray_concrete
fill 292 192 537 292 193 537 minecraft:gray_concrete
fill 293 192 524 293 193 524 minecraft:gray_concrete
fill 293 192 539 293 193 539 minecraft:gray_concrete
fill 294 192 552 294 205 552 minecraft:white_concrete
fill 295 192 524 295 193 524 minecraft:gray_concrete
fill 295 192 539 295 193 539 minecraft:gray_concrete
fill 295 192 552 296 192 552 minecraft:pearlescent_froglight
fill 297 192 524 297 193 524 minecraft:gray_concrete
fill 297 192 539 297 193 539 minecraft:gray_concrete
fill 297 192 552 297 205 552 minecraft:white_concrete
fill 299 192 524 299 193 524 minecraft:gray_concrete
fill 299 192 539 299 193 539 minecraft:gray_concrete
fill 301 192 510 301 205 510 minecraft:white_concrete
fill 301 192 524 301 193 524 minecraft:gray_concrete
fill 301 192 539 301 193 539 minecraft:gray_concrete
fill 302 192 510 303 192 510 minecraft:pearlescent_froglight
fill 303 192 524 303 193 524 minecraft:gray_concrete
fill 303 192 539 303 193 539 minecraft:gray_concrete
fill 304 192 510 304 205 510 minecraft:white_concrete
fill 305 192 524 305 193 524 minecraft:gray_concrete
fill 305 192 539 305 193 539 minecraft:gray_concrete
fill 306 192 552 306 205 552 minecraft:white_concrete
fill 307 192 525 307 193 525 minecraft:gray_concrete
fill 307 192 527 307 193 527 minecraft:gray_concrete
fill 307 192 529 307 193 529 minecraft:gray_concrete
fill 307 192 531 307 193 531 minecraft:gray_concrete
fill 307 192 533 307 193 533 minecraft:gray_concrete
fill 307 192 535 307 193 535 minecraft:gray_concrete
fill 307 192 537 307 193 537 minecraft:gray_concrete
fill 307 192 552 308 192 552 minecraft:pearlescent_froglight
fill 309 192 552 309 205 552 minecraft:white_concrete
fill 313 192 510 313 205 510 minecraft:white_concrete
fill 314 192 510 315 192 510 minecraft:pearlescent_froglight
fill 316 192 510 316 205 510 minecraft:white_concrete
fill 318 192 552 318 205 552 minecraft:white_concrete
fill 319 192 552 320 192 552 minecraft:pearlescent_froglight
fill 321 192 552 321 205 552 minecraft:white_concrete
fill 324 192 511 324 205 511 minecraft:white_concrete
fill 324 192 512 324 192 513 minecraft:pearlescent_froglight
fill 324 192 514 324 205 514 minecraft:white_concrete
fill 324 192 523 324 205 523 minecraft:white_concrete
fill 324 192 524 324 192 525 minecraft:pearlescent_froglight
fill 324 192 526 324 205 526 minecraft:white_concrete
fill 324 192 535 324 205 535 minecraft:white_concrete
fill 324 192 536 324 192 537 minecraft:pearlescent_froglight
fill 324 192 538 324 205 538 minecraft:white_concrete
fill 324 192 547 324 205 547 minecraft:white_concrete
fill 324 192 548 324 192 549 minecraft:pearlescent_froglight
fill 324 192 550 324 205 550 minecraft:white_concrete
fill 282 193 517 282 205 518 minecraft:white_concrete
fill 282 193 529 282 205 530 minecraft:white_concrete
fill 282 193 541 282 205 542 minecraft:white_concrete
fill 283 193 552 284 205 552 minecraft:white_concrete
setblock 285 193 513 minecraft:light[level=14]
setblock 285 193 521 minecraft:light[level=14]
setblock 285 193 529 minecraft:light[level=14]
setblock 285 193 537 minecraft:light[level=14]
setblock 285 193 545 minecraft:light[level=14]
fill 290 193 510 291 205 510 minecraft:white_concrete
setblock 293 193 513 minecraft:light[level=14]
setblock 293 193 521 minecraft:light[level=14]
setblock 293 193 545 minecraft:light[level=14]
fill 295 193 552 296 205 552 minecraft:white_concrete
setblock 301 193 513 minecraft:light[level=14]
setblock 301 193 521 minecraft:light[level=14]
setblock 301 193 545 minecraft:light[level=14]
fill 302 193 510 303 205 510 minecraft:white_concrete
fill 307 193 552 308 205 552 minecraft:white_concrete
setblock 309 193 513 minecraft:light[level=14]
setblock 309 193 521 minecraft:light[level=14]
setblock 309 193 529 minecraft:light[level=14]
setblock 309 193 537 minecraft:light[level=14]
setblock 309 193 545 minecraft:light[level=14]
fill 314 193 510 315 205 510 minecraft:white_concrete
setblock 317 193 513 minecraft:light[level=14]
setblock 317 193 521 minecraft:light[level=14]
setblock 317 193 529 minecraft:light[level=14]
setblock 317 193 537 minecraft:light[level=14]
setblock 317 193 545 minecraft:light[level=14]
fill 319 193 552 320 205 552 minecraft:white_concrete
fill 324 193 512 324 205 513 minecraft:white_concrete
fill 324 193 524 324 205 525 minecraft:white_concrete
fill 324 193 536 324 205 537 minecraft:white_concrete
fill 324 193 548 324 205 549 minecraft:white_concrete
setblock 292 194 525 minecraft:sea_lantern
setblock 292 194 527 minecraft:black_stained_glass
setblock 292 194 529 minecraft:light_blue_stained_glass
setblock 292 194 531 minecraft:light_blue_stained_glass
setblock 292 194 533 minecraft:black_stained_glass
setblock 292 194 535 minecraft:black_stained_glass
setblock 292 194 537 minecraft:black_stained_glass
setblock 293 194 524 minecraft:black_stained_glass
setblock 293 194 539 minecraft:light_blue_stained_glass
setblock 295 194 524 minecraft:black_stained_glass
setblock 295 194 539 minecraft:black_stained_glass
setblock 297 194 524 minecraft:black_stained_glass
setblock 297 194 539 minecraft:sea_lantern
setblock 299 194 524 minecraft:black_stained_glass
setblock 299 194 539 minecraft:black_stained_glass
setblock 301 194 524 minecraft:sea_lantern
setblock 301 194 539 minecraft:light_blue_stained_glass
setblock 303 194 524 minecraft:black_stained_glass
setblock 303 194 539 minecraft:black_stained_glass
setblock 305 194 524 minecraft:black_stained_glass
setblock 305 194 539 minecraft:light_blue_stained_glass
setblock 307 194 525 minecraft:black_stained_glass
setblock 307 194 527 minecraft:sea_lantern
setblock 307 194 529 minecraft:black_stained_glass
setblock 307 194 531 minecraft:black_stained_glass
setblock 307 194 533 minecraft:black_stained_glass
setblock 307 194 535 minecraft:black_stained_glass
setblock 307 194 537 minecraft:light_blue_stained_glass
fill 292 195 525 292 196 525 minecraft:gray_concrete
fill 292 195 527 292 196 527 minecraft:gray_concrete
fill 292 195 529 292 196 529 minecraft:gray_concrete
fill 292 195 531 292 196 531 minecraft:gray_concrete
fill 292 195 533 292 196 533 minecraft:gray_concrete
fill 292 195 535 292 196 535 minecraft:gray_concrete
fill 292 195 537 292 196 537 minecraft:gray_concrete
fill 293 195 524 293 196 524 minecraft:gray_concrete
fill 293 195 539 293 196 539 minecraft:gray_concrete
fill 295 195 524 295 196 524 minecraft:gray_concrete
fill 295 195 539 295 196 539 minecraft:gray_concrete
fill 297 195 524 297 196 524 minecraft:gray_concrete
fill 297 195 539 297 196 539 minecraft:gray_concrete
fill 299 195 524 299 196 524 minecraft:gray_concrete
fill 299 195 539 299 196 539 minecraft:gray_concrete
fill 301 195 524 301 196 524 minecraft:gray_concrete
fill 301 195 539 301 196 539 minecraft:gray_concrete
fill 303 195 524 303 196 524 minecraft:gray_concrete
fill 303 195 539 303 196 539 minecraft:gray_concrete
fill 305 195 524 305 196 524 minecraft:gray_concrete
fill 305 195 539 305 196 539 minecraft:gray_concrete
fill 307 195 525 307 196 525 minecraft:gray_concrete
fill 307 195 527 307 196 527 minecraft:gray_concrete
fill 307 195 529 307 196 529 minecraft:gray_concrete
fill 307 195 531 307 196 531 minecraft:gray_concrete
fill 307 195 533 307 196 533 minecraft:gray_concrete
fill 307 195 535 307 196 535 minecraft:gray_concrete
fill 307 195 537 307 196 537 minecraft:gray_concrete
fill 319 196 534 319 197 534 minecraft:white_wool
setblock 292 197 525 minecraft:black_stained_glass
setblock 292 197 527 minecraft:sea_lantern
setblock 292 197 529 minecraft:black_stained_glass
setblock 292 197 531 minecraft:black_stained_glass
setblock 292 197 533 minecraft:black_stained_glass
setblock 292 197 535 minecraft:light_blue_stained_glass
setblock 292 197 537 minecraft:black_stained_glass
setblock 293 197 524 minecraft:sea_lantern
setblock 293 197 539 minecraft:black_stained_glass
setblock 295 197 524 minecraft:sea_lantern
setblock 295 197 539 minecraft:light_blue_stained_glass
setblock 297 197 524 minecraft:black_stained_glass
setblock 297 197 539 minecraft:black_stained_glass
setblock 299 197 524 minecraft:black_stained_glass
setblock 299 197 539 minecraft:black_stained_glass
setblock 301 197 524 minecraft:black_stained_glass
setblock 301 197 539 minecraft:light_blue_stained_glass
setblock 303 197 524 minecraft:black_stained_glass
setblock 303 197 539 minecraft:sea_lantern
setblock 305 197 524 minecraft:sea_lantern
setblock 305 197 539 minecraft:sea_lantern
setblock 307 197 525 minecraft:black_stained_glass
setblock 307 197 527 minecraft:black_stained_glass
setblock 307 197 529 minecraft:sea_lantern
setblock 307 197 531 minecraft:sea_lantern
setblock 307 197 533 minecraft:sea_lantern
setblock 307 197 535 minecraft:black_stained_glass
setblock 307 197 537 minecraft:sea_lantern
fill 292 198 525 292 201 525 minecraft:gray_concrete
fill 292 198 527 292 201 527 minecraft:gray_concrete
fill 292 198 529 292 201 529 minecraft:gray_concrete
fill 292 198 531 292 201 531 minecraft:gray_concrete
fill 292 198 533 292 201 533 minecraft:gray_concrete
fill 292 198 535 292 201 535 minecraft:gray_concrete
fill 292 198 537 292 201 537 minecraft:gray_concrete
fill 293 198 524 293 200 524 minecraft:gray_concrete
fill 293 198 539 293 201 539 minecraft:gray_concrete
fill 295 198 524 295 200 524 minecraft:gray_concrete
fill 295 198 539 295 201 539 minecraft:gray_concrete
fill 297 198 524 297 200 524 minecraft:gray_concrete
fill 297 198 539 297 201 539 minecraft:gray_concrete
fill 299 198 524 299 200 524 minecraft:gray_concrete
fill 299 198 539 299 201 539 minecraft:gray_concrete
fill 301 198 524 301 200 524 minecraft:gray_concrete
fill 301 198 539 301 201 539 minecraft:gray_concrete
fill 303 198 524 303 200 524 minecraft:gray_concrete
fill 303 198 539 303 201 539 minecraft:gray_concrete
fill 305 198 524 305 200 524 minecraft:gray_concrete
fill 305 198 539 305 201 539 minecraft:gray_concrete
fill 307 198 525 307 201 525 minecraft:gray_concrete
fill 307 198 527 307 201 527 minecraft:gray_concrete
fill 307 198 529 307 201 529 minecraft:gray_concrete
fill 307 198 531 307 201 531 minecraft:gray_concrete
fill 307 198 533 307 201 533 minecraft:gray_concrete
fill 307 198 535 307 201 535 minecraft:gray_concrete
fill 307 198 537 307 201 537 minecraft:gray_concrete
fill 284 200 520 284 205 522 minecraft:quartz_block
fill 284 200 532 284 205 534 minecraft:quartz_block
fill 284 200 544 284 205 546 minecraft:quartz_block
fill 287 200 530 287 201 530 minecraft:light_blue_stained_glass
fill 290 200 550 292 205 550 minecraft:quartz_block
fill 294 200 512 296 205 512 minecraft:quartz_block
fill 302 200 550 304 205 550 minecraft:quartz_block
fill 306 200 512 308 205 512 minecraft:quartz_block
fill 314 200 550 316 205 550 minecraft:quartz_block
fill 318 200 512 320 205 512 minecraft:quartz_block
fill 322 200 520 322 205 522 minecraft:quartz_block
fill 322 200 532 322 205 534 minecraft:quartz_block
fill 322 200 544 322 205 546 minecraft:quartz_block
setblock 285 201 513 minecraft:light[level=14]
setblock 285 201 521 minecraft:light[level=14]
setblock 285 201 529 minecraft:light[level=14]
setblock 285 201 537 minecraft:light[level=14]
setblock 285 201 545 minecraft:light[level=14]
fill 292 201 524 307 201 524 minecraft:yellow_concrete
setblock 293 201 513 minecraft:light[level=14]
setblock 293 201 521 minecraft:light[level=14]
setblock 293 201 545 minecraft:light[level=14]
setblock 301 201 513 minecraft:light[level=14]
setblock 301 201 521 minecraft:light[level=14]
setblock 301 201 545 minecraft:light[level=14]
setblock 309 201 513 minecraft:light[level=14]
setblock 309 201 521 minecraft:light[level=14]
setblock 309 201 529 minecraft:light[level=14]
setblock 309 201 537 minecraft:light[level=14]
setblock 309 201 545 minecraft:light[level=14]
setblock 317 201 513 minecraft:light[level=14]
setblock 317 201 521 minecraft:light[level=14]
setblock 317 201 529 minecraft:light[level=14]
setblock 317 201 537 minecraft:light[level=14]
setblock 317 201 545 minecraft:light[level=14]
fill 287 202 530 287 212 530 minecraft:smooth_quartz
fill 287 203 531 287 212 531 minecraft:smooth_quartz
fill 288 203 530 288 212 530 minecraft:smooth_quartz
fill 286 204 530 286 212 531 minecraft:smooth_quartz
fill 287 204 529 288 212 529 minecraft:smooth_quartz
fill 288 204 531 288 212 531 minecraft:smooth_quartz
fill 283 205 514 283 205 519 minecraft:smooth_quartz
fill 283 205 526 283 205 531 minecraft:smooth_quartz
fill 283 205 538 283 205 543 minecraft:smooth_quartz
fill 283 205 550 283 205 551 minecraft:smooth_quartz
fill 284 205 551 287 205 551 minecraft:smooth_quartz
fill 286 205 529 286 212 529 minecraft:smooth_quartz
fill 287 205 511 292 205 511 minecraft:smooth_quartz
fill 287 205 532 287 212 532 minecraft:smooth_quartz
fill 289 205 530 289 212 530 minecraft:smooth_quartz
fill 294 205 551 299 205 551 minecraft:smooth_quartz
fill 299 205 511 304 205 511 minecraft:smooth_quartz
fill 306 205 551 311 205 551 minecraft:smooth_quartz
fill 311 205 511 316 205 511 minecraft:smooth_quartz
fill 318 205 551 323 205 551 minecraft:smooth_quartz
fill 323 205 511 323 205 516 minecraft:smooth_quartz
fill 323 205 523 323 205 528 minecraft:smooth_quartz
fill 323 205 535 323 205 540 minecraft:smooth_quartz
fill 323 205 547 323 205 550 minecraft:smooth_quartz
fill 282 206 516 282 211 519 minecraft:pearlescent_froglight
fill 282 206 528 282 211 531 minecraft:pearlescent_froglight
fill 282 206 540 282 211 543 minecraft:pearlescent_froglight
fill 282 206 552 285 211 552 minecraft:pearlescent_froglight
fill 285 206 529 285 212 531 minecraft:smooth_quartz
fill 286 206 528 288 212 528 minecraft:smooth_quartz
fill 286 206 532 286 212 532 minecraft:smooth_quartz
fill 288 206 532 288 212 532 minecraft:smooth_quartz
fill 289 206 510 292 211 510 minecraft:pearlescent_froglight
fill 289 206 529 289 212 529 minecraft:smooth_quartz
fill 289 206 531 289 212 531 minecraft:smooth_quartz
fill 294 206 552 297 211 552 minecraft:pearlescent_froglight
fill 301 206 510 304 211 510 minecraft:pearlescent_froglight
fill 306 206 552 309 211 552 minecraft:pearlescent_froglight
fill 313 206 510 316 211 510 minecraft:pearlescent_froglight
fill 318 206 552 321 211 552 minecraft:pearlescent_froglight
fill 324 206 511 324 211 514 minecraft:pearlescent_froglight
fill 324 206 523 324 211 526 minecraft:pearlescent_froglight
fill 324 206 535 324 211 538 minecraft:pearlescent_froglight
fill 324 206 547 324 211 550 minecraft:pearlescent_froglight
fill 285 207 532 285 212 532 minecraft:smooth_quartz
fill 287 207 533 287 212 533 minecraft:smooth_quartz
fill 289 207 528 289 212 528 minecraft:smooth_quartz
fill 289 207 532 289 212 532 minecraft:smooth_quartz
fill 290 207 530 290 212 530 minecraft:smooth_quartz
fill 284 208 529 284 212 531 minecraft:smooth_quartz
fill 285 208 528 285 212 528 minecraft:smooth_quartz
fill 286 208 527 288 212 527 minecraft:smooth_quartz
fill 286 208 533 286 212 533 minecraft:smooth_quartz
fill 288 208 533 288 212 533 minecraft:smooth_quartz
fill 290 208 529 290 212 529 minecraft:smooth_quartz
fill 290 208 531 290 212 531 minecraft:smooth_quartz
fill 284 209 528 284 212 528 minecraft:smooth_quartz
fill 284 209 532 284 212 532 minecraft:smooth_quartz
setblock 285 209 513 minecraft:light[level=14]
setblock 285 209 521 minecraft:light[level=14]
fill 285 209 527 285 212 527 minecraft:smooth_quartz
fill 285 209 533 285 212 533 minecraft:smooth_quartz
setblock 285 209 537 minecraft:light[level=14]
setblock 285 209 545 minecraft:light[level=14]
fill 287 209 534 287 212 534 minecraft:smooth_quartz
fill 289 209 527 289 212 527 minecraft:smooth_quartz
fill 289 209 533 289 212 533 minecraft:smooth_quartz
fill 290 209 528 290 212 528 minecraft:smooth_quartz
fill 290 209 532 290 212 532 minecraft:smooth_quartz
fill 291 209 530 291 212 530 minecraft:smooth_quartz
setblock 293 209 513 minecraft:light[level=14]
setblock 293 209 521 minecraft:light[level=14]
setblock 293 209 529 minecraft:light[level=14]
setblock 293 209 537 minecraft:light[level=14]
setblock 293 209 545 minecraft:light[level=14]
setblock 301 209 513 minecraft:light[level=14]
setblock 301 209 521 minecraft:light[level=14]
setblock 301 209 529 minecraft:light[level=14]
setblock 301 209 537 minecraft:light[level=14]
setblock 301 209 545 minecraft:light[level=14]
setblock 309 209 513 minecraft:light[level=14]
setblock 309 209 521 minecraft:light[level=14]
setblock 309 209 529 minecraft:light[level=14]
setblock 309 209 537 minecraft:light[level=14]
setblock 309 209 545 minecraft:light[level=14]
setblock 317 209 513 minecraft:light[level=14]
setblock 317 209 521 minecraft:light[level=14]
setblock 317 209 529 minecraft:light[level=14]
setblock 317 209 537 minecraft:light[level=14]
setblock 317 209 545 minecraft:light[level=14]
fill 283 210 529 283 212 531 minecraft:smooth_quartz
fill 283 210 536 283 211 538 minecraft:quartz_block
fill 284 210 527 284 212 527 minecraft:smooth_quartz
fill 284 210 533 284 212 533 minecraft:smooth_quartz
fill 285 210 534 286 212 534 minecraft:smooth_quartz
fill 286 210 526 288 212 526 minecraft:smooth_quartz
fill 288 210 534 289 212 534 minecraft:smooth_quartz
fill 290 210 527 290 212 527 minecraft:smooth_quartz
fill 290 210 533 290 212 533 minecraft:smooth_quartz
fill 291 210 529 291 212 529 minecraft:smooth_quartz
fill 291 210 531 291 212 532 minecraft:smooth_quartz
fill 322 210 536 323 211 538 minecraft:quartz_block
fill 283 211 528 283 212 528 minecraft:smooth_quartz
fill 283 211 532 283 212 532 minecraft:smooth_quartz
fill 284 211 536 284 212 538 minecraft:quartz_block
fill 285 211 526 285 212 526 minecraft:smooth_quartz
fill 285 211 537 285 214 537 minecraft:quartz_block
fill 287 211 535 287 212 535 minecraft:smooth_quartz
fill 289 211 526 289 212 526 minecraft:smooth_quartz
fill 290 211 534 290 212 534 minecraft:smooth_quartz
fill 291 211 528 291 212 528 minecraft:smooth_quartz
fill 291 211 533 291 212 533 minecraft:smooth_quartz
fill 292 211 530 292 212 530 minecraft:smooth_quartz
fill 320 211 537 321 213 537 minecraft:quartz_block
fill 321 211 536 321 212 536 minecraft:quartz_block
fill 321 211 538 321 212 538 minecraft:quartz_block
fill 282 212 511 282 215 512 minecraft:white_concrete
setblock 282 212 513 minecraft:light_blue_concrete
fill 282 212 514 282 215 515 minecraft:white_concrete
setblock 282 212 516 minecraft:light_blue_concrete
fill 282 212 517 282 212 518 minecraft:pearlescent_froglight
setblock 282 212 519 minecraft:white_concrete
fill 282 212 523 282 213 524 minecraft:white_concrete
setblock 282 212 525 minecraft:light_blue_concrete
setblock 282 212 528 minecraft:light_blue_concrete
fill 282 212 529 282 212 530 minecraft:pearlescent_froglight
fill 282 212 531 282 215 531 minecraft:white_concrete
setblock 282 212 532 minecraft:light_blue_concrete
fill 282 212 533 282 215 533 minecraft:white_concrete
setblock 282 212 534 minecraft:light_blue_concrete
fill 282 212 540 282 215 540 minecraft:white_concrete
fill 282 212 541 282 212 542 minecraft:pearlescent_froglight
fill 282 212 543 282 212 544 minecraft:light_blue_concrete
fill 282 212 552 282 215 552 minecraft:white_concrete
setblock 283 212 527 minecraft:smooth_quartz
setblock 283 212 537 minecraft:quartz_block
fill 283 212 552 284 212 552 minecraft:pearlescent_froglight
setblock 284 212 526 minecraft:smooth_quartz
setblock 284 212 534 minecraft:smooth_quartz
fill 285 212 535 286 212 535 minecraft:smooth_quartz
fill 285 212 536 285 213 536 minecraft:quartz_block
fill 285 212 538 285 213 538 minecraft:quartz_block
fill 285 212 552 285 215 552 minecraft:white_concrete
fill 286 212 525 288 212 525 minecraft:smooth_quartz
fill 286 212 537 286 214 537 minecraft:quartz_block
fill 288 212 535 289 212 535 minecraft:smooth_quartz
fill 289 212 510 289 215 510 minecraft:white_concrete
fill 290 212 510 291 212 510 minecraft:pearlescent_froglight
setblock 290 212 526 minecraft:smooth_quartz
setblock 291 212 527 minecraft:smooth_quartz
fill 292 212 510 292 215 510 minecraft:white_concrete
fill 292 212 528 292 212 529 minecraft:smooth_quartz
fill 292 212 531 292 212 532 minecraft:smooth_quartz
fill 294 212 552 294 215 552 minecraft:white_concrete
fill 295 212 552 296 212 552 minecraft:pearlescent_froglight
setblock 297 212 552 minecraft:light_blue_concrete
fill 301 212 510 301 217 510 minecraft:white_concrete
fill 302 212 510 303 212 510 minecraft:pearlescent_froglight
fill 304 212 510 304 215 510 minecraft:white_concrete
setblock 305 212 510 minecraft:light_blue_concrete
fill 306 212 510 309 212 510 minecraft:white_concrete
fill 306 212 552 306 216 552 minecraft:white_concrete
fill 307 212 552 308 212 552 minecraft:pearlescent_froglight
fill 309 212 552 309 215 552 minecraft:white_concrete
setblock 310 212 510 minecraft:light_blue_concrete
fill 311 212 552 311 215 552 minecraft:white_concrete
setblock 312 212 552 minecraft:light_blue_concrete
fill 313 212 510 313 215 510 minecraft:white_concrete
fill 313 212 552 314 215 552 minecraft:white_concrete
fill 314 212 510 315 212 510 minecraft:pearlescent_froglight
fill 316 212 510 316 215 510 minecraft:white_concrete
fill 318 212 552 318 215 552 minecraft:white_concrete
fill 319 212 537 319 214 537 minecraft:quartz_block
fill 319 212 552 320 212 552 minecraft:pearlescent_froglight
fill 320 212 536 320 213 536 minecraft:quartz_block
fill 320 212 538 320 213 538 minecraft:quartz_block
fill 321 212 552 321 215 552 minecraft:white_concrete
setblock 322 212 537 minecraft:quartz_block
setblock 323 212 510 minecraft:light_blue_concrete
setblock 323 212 537 minecraft:gold_block
fill 324 212 510 324 215 511 minecraft:white_concrete
fill 324 212 512 324 212 513 minecraft:pearlescent_froglight
setblock 324 212 514 minecraft:light_blue_concrete
fill 324 212 520 324 212 521 minecraft:light_blue_concrete
fill 324 212 522 324 213 523 minecraft:white_concrete
fill 324 212 524 324 212 525 minecraft:pearlescent_froglight
fill 324 212 526 324 213 526 minecraft:white_concrete
setblock 324 212 527 minecraft:light_blue_concrete
setblock 324 212 529 minecraft:light_blue_concrete
fill 324 212 530 324 212 532 minecraft:white_concrete
fill 324 212 535 324 215 535 minecraft:white_concrete
fill 324 212 536 324 212 537 minecraft:pearlescent_froglight
fill 324 212 538 324 215 538 minecraft:white_concrete
fill 324 212 547 324 215 547 minecraft:white_concrete
fill 324 212 548 324 212 549 minecraft:pearlescent_froglight
setblock 324 212 550 minecraft:light_blue_concrete
fill 282 213 513 282 215 513 minecraft:white_concrete
fill 282 213 516 282 215 518 minecraft:white_concrete
fill 282 213 519 282 213 520 minecraft:light_blue_concrete
fill 282 213 521 282 215 521 minecraft:white_concrete
setblock 282 213 522 minecraft:light_blue_concrete
fill 282 213 525 282 215 525 minecraft:white_concrete
fill 282 213 526 282 214 527 minecraft:light_blue_concrete
fill 282 213 528 282 215 530 minecraft:white_concrete
fill 282 213 532 282 215 532 minecraft:white_concrete
fill 282 213 534 282 215 534 minecraft:white_concrete
fill 282 213 541 282 213 543 minecraft:white_concrete
setblock 282 213 544 minecraft:light_blue_concrete
setblock 282 213 547 minecraft:light_blue_concrete
fill 283 213 510 283 215 510 minecraft:white_concrete
setblock 283 213 537 minecraft:gold_block
fill 283 213 552 283 215 552 minecraft:white_concrete
setblock 284 213 510 minecraft:light_blue_concrete
setblock 284 213 537 minecraft:quartz_block
setblock 284 213 552 minecraft:light_blue_concrete
fill 285 213 510 287 215 510 minecraft:white_concrete
fill 286 213 536 287 214 536 minecraft:quartz_block
fill 286 213 538 287 214 538 minecraft:quartz_block
fill 287 213 530 287 216 530 minecraft:gold_block
fill 287 213 537 287 215 537 minecraft:quartz_block
setblock 288 213 510 minecraft:light_blue_concrete
fill 290 213 510 291 213 510 minecraft:white_concrete
setblock 290 213 552 minecraft:light_blue_concrete
fill 291 213 552 292 215 552 minecraft:white_concrete
fill 293 213 510 293 215 510 minecraft:white_concrete
fill 294 213 510 295 213 510 minecraft:light_blue_concrete
fill 295 213 552 297 213 552 minecraft:white_concrete
fill 296 213 510 300 215 510 minecraft:white_concrete
fill 298 213 552 298 214 552 minecraft:light_blue_concrete
fill 302 213 510 303 213 510 minecraft:white_concrete
fill 305 213 510 306 215 510 minecraft:white_concrete
fill 307 213 510 307 214 510 minecraft:light_blue_concrete
fill 307 213 552 307 215 552 minecraft:white_concrete
fill 308 213 510 310 213 510 minecraft:white_concrete
setblock 308 213 552 minecraft:light_blue_concrete
setblock 311 213 510 minecraft:light_blue_concrete
fill 312 213 510 312 215 510 minecraft:white_concrete
fill 312 213 552 312 215 552 minecraft:white_concrete
fill 314 213 510 315 213 510 minecraft:white_concrete
setblock 316 213 552 minecraft:light_blue_concrete
fill 317 213 510 317 215 510 minecraft:white_concrete
setblock 318 213 510 minecraft:light_blue_concrete
fill 318 213 536 318 214 538 minecraft:quartz_block
fill 319 213 510 320 213 510 minecraft:white_concrete
fill 319 213 536 319 214 536 minecraft:quartz_block
fill 319 213 538 319 214 538 minecraft:quartz_block
fill 319 213 552 320 215 552 minecraft:white_concrete
setblock 322 213 537 minecraft:gold_block
fill 323 213 510 323 215 510 minecraft:white_concrete
fill 324 213 512 324 213 515 minecraft:white_concrete
setblock 324 213 516 minecraft:light_blue_concrete
fill 324 213 520 324 215 521 minecraft:white_concrete
fill 324 213 524 324 215 524 minecraft:white_concrete
setblock 324 213 525 minecraft:light_blue_concrete
fill 324 213 527 324 215 527 minecraft:white_concrete
fill 324 213 529 324 216 529 minecraft:white_concrete
setblock 324 213 530 minecraft:light_blue_concrete
fill 324 213 531 324 215 532 minecraft:white_concrete
fill 324 213 536 324 215 537 minecraft:white_concrete
fill 324 213 548 324 213 550 minecraft:white_concrete
setblock 282 214 510 minecraft:light_blue_concrete
fill 282 214 519 282 215 520 minecraft:white_concrete
fill 282 214 522 282 215 523 minecraft:white_concrete
setblock 282 214 524 minecraft:light_blue_concrete
setblock 282 214 541 minecraft:light_blue_concrete
fill 282 214 542 282 215 544 minecraft:white_concrete
fill 282 214 547 282 215 547 minecraft:white_concrete
fill 284 214 510 284 215 510 minecraft:white_concrete
setblock 284 214 537 minecraft:gold_block
fill 284 214 552 284 215 552 minecraft:white_concrete
fill 286 214 521 287 215 522 minecraft:white_wool
fill 288 214 510 288 215 510 minecraft:white_concrete
fill 288 214 536 288 215 538 minecraft:quartz_block
fill 289 214 537 289 216 537 minecraft:quartz_block
setblock 290 214 510 minecraft:light_blue_concrete
fill 290 214 552 290 215 552 minecraft:white_concrete
fill 291 214 510 291 215 510 minecraft:white_concrete
fill 294 214 510 295 215 510 minecraft:white_concrete
fill 295 214 552 296 215 552 minecraft:white_concrete
setblock 297 214 552 minecraft:light_blue_concrete
fill 302 214 510 302 215 510 minecraft:white_concrete
setblock 303 214 510 minecraft:light_blue_concrete
setblock 308 214 510 minecraft:light_blue_concrete
fill 308 214 552 308 215 552 minecraft:white_concrete
fill 309 214 510 311 215 510 minecraft:white_concrete
fill 314 214 510 314 215 510 minecraft:white_concrete
setblock 315 214 510 minecraft:light_blue_concrete
fill 316 214 537 317 216 537 minecraft:quartz_block
fill 316 214 552 316 215 552 minecraft:white_concrete
fill 317 214 536 317 215 536 minecraft:quartz_block
fill 317 214 538 317 215 538 minecraft:quartz_block
fill 318 214 510 318 216 510 minecraft:white_concrete
setblock 319 214 510 minecraft:light_blue_concrete
fill 320 214 510 320 215 510 minecraft:white_concrete
setblock 320 214 537 minecraft:quartz_block
setblock 321 214 537 minecraft:gold_block
fill 324 214 512 324 216 512 minecraft:white_concrete
setblock 324 214 513 minecraft:light_blue_concrete
fill 324 214 514 324 215 516 minecraft:white_concrete
setblock 324 214 522 minecraft:light_blue_concrete
fill 324 214 523 324 215 523 minecraft:white_concrete
fill 324 214 525 324 215 525 minecraft:white_concrete
setblock 324 214 526 minecraft:light_blue_concrete
setblock 324 214 528 minecraft:light_blue_concrete
fill 324 214 530 324 215 530 minecraft:white_concrete
fill 324 214 539 324 215 539 minecraft:white_concrete
fill 324 214 540 324 214 541 minecraft:light_blue_concrete
fill 324 214 548 324 215 548 minecraft:white_concrete
setblock 324 214 549 minecraft:light_blue_concrete
fill 324 214 550 324 216 550 minecraft:white_concrete
setblock 282 215 510 minecraft:white_concrete
setblock 282 215 524 minecraft:white_concrete
fill 282 215 526 282 215 527 minecraft:white_concrete
setblock 282 215 541 minecraft:white_concrete
setblock 286 215 537 minecraft:gold_block
fill 289 215 536 289 216 536 minecraft:quartz_block
fill 289 215 538 289 216 538 minecraft:quartz_block
setblock 290 215 510 minecraft:white_concrete
fill 290 215 537 290 217 537 minecraft:quartz_block
fill 297 215 552 298 215 552 minecraft:white_concrete
setblock 303 215 510 minecraft:white_concrete
fill 307 215 510 308 215 510 minecraft:white_concrete
setblock 315 215 510 minecraft:white_concrete
fill 315 215 537 315 217 537 minecraft:quartz_block
fill 316 215 536 316 216 536 minecraft:quartz_block
fill 316 215 538 316 216 538 minecraft:quartz_block
setblock 318 215 537 minecraft:quartz_block
setblock 319 215 510 minecraft:white_concrete
setblock 319 215 537 minecraft:gold_block
setblock 324 215 513 minecraft:white_concrete
setblock 324 215 522 minecraft:white_concrete
setblock 324 215 526 minecraft:white_concrete
setblock 324 215 528 minecraft:white_concrete
fill 324 215 540 324 215 541 minecraft:white_concrete
fill 324 215 549 324 216 549 minecraft:white_concrete
fill 282 216 510 282 216 538 minecraft:light_blue_concrete
setblock 282 216 539 minecraft:white_concrete
fill 282 216 540 282 216 552 minecraft:light_blue_concrete
fill 283 216 510 300 217 510 minecraft:light_blue_concrete
fill 283 216 536 283 217 536 minecraft:quartz_block
fill 283 216 552 287 217 552 minecraft:light_blue_concrete
setblock 287 216 537 minecraft:gold_block
setblock 288 216 537 minecraft:quartz_block
setblock 288 216 552 minecraft:white_concrete
fill 289 216 552 290 216 552 minecraft:light_blue_concrete
fill 290 216 536 291 216 536 minecraft:quartz_block
fill 290 216 538 291 216 538 minecraft:quartz_block
fill 291 216 537 292 218 537 minecraft:quartz_block
setblock 291 216 552 minecraft:white_concrete
fill 292 216 552 302 216 552 minecraft:light_blue_concrete
fill 297 216 515 297 217 515 minecraft:white_wool
fill 302 216 510 306 216 510 minecraft:light_blue_concrete
fill 303 216 552 304 216 552 minecraft:white_concrete
fill 305 216 552 305 307 552 minecraft:light_blue_concrete
setblock 307 216 510 minecraft:white_concrete
fill 307 216 552 314 216 552 minecraft:light_blue_concrete
fill 308 216 510 317 216 510 minecraft:light_blue_concrete
fill 313 216 537 314 218 537 minecraft:quartz_block
fill 314 216 536 315 216 536 minecraft:quartz_block
fill 314 216 538 315 216 538 minecraft:quartz_block
fill 316 216 552 324 216 552 minecraft:light_blue_concrete
setblock 318 216 537 minecraft:gold_block
fill 319 216 510 323 217 510 minecraft:light_blue_concrete
fill 322 216 534 323 217 536 minecraft:quartz_block
setblock 324 216 510 minecraft:white_concrete
fill 324 216 511 324 225 511 minecraft:light_blue_concrete
fill 324 216 513 324 216 528 minecraft:light_blue_concrete
fill 324 216 530 324 216 540 minecraft:light_blue_concrete
setblock 324 216 541 minecraft:white_concrete
fill 324 216 542 324 216 548 minecraft:light_blue_concrete
fill 324 216 551 324 307 551 minecraft:light_blue_concrete
setblock 282 217 510 minecraft:white_concrete
fill 282 217 511 282 217 514 minecraft:light_blue_concrete
fill 282 217 515 282 217 516 minecraft:white_concrete
fill 282 217 517 282 225 519 minecraft:light_blue_concrete
setblock 282 217 520 minecraft:white_concrete
fill 282 217 521 282 217 524 minecraft:light_blue_concrete
fill 282 217 525 282 217 526 minecraft:white_concrete
fill 282 217 527 282 217 544 minecraft:light_blue_concrete
setblock 282 217 545 minecraft:white_concrete
fill 282 217 546 282 217 552 minecraft:light_blue_concrete
fill 284 217 534 284 218 536 minecraft:quartz_block
setblock 285 217 513 minecraft:light[level=14]
setblock 285 217 521 minecraft:light[level=14]
setblock 285 217 529 minecraft:light[level=14]
fill 285 217 535 285 220 535 minecraft:quartz_block
setblock 285 217 537 minecraft:light[level=14]
setblock 285 217 545 minecraft:light[level=14]
setblock 287 217 530 minecraft:pearlescent_froglight
fill 288 217 552 288 307 552 minecraft:light_blue_concrete
setblock 289 217 537 minecraft:gold_block
setblock 289 217 552 minecraft:white_concrete
fill 290 217 552 294 225 552 minecraft:light_blue_concrete
fill 291 217 536 293 217 536 minecraft:quartz_block
fill 291 217 538 293 217 538 minecraft:quartz_block
setblock 293 217 513 minecraft:light[level=14]
setblock 293 217 521 minecraft:light[level=14]
setblock 293 217 529 minecraft:light[level=14]
fill 293 217 537 294 218 537 minecraft:quartz_block
setblock 293 217 545 minecraft:light[level=14]
setblock 295 217 552 minecraft:white_concrete
fill 296 217 552 301 217 552 minecraft:light_blue_concrete
setblock 301 217 513 minecraft:light[level=14]
setblock 301 217 521 minecraft:light[level=14]
setblock 301 217 529 minecraft:light[level=14]
setblock 301 217 537 minecraft:light[level=14]
setblock 301 217 545 minecraft:light[level=14]
fill 302 217 510 303 225 510 minecraft:light_blue_concrete
setblock 302 217 552 minecraft:white_concrete
fill 303 217 552 304 307 552 minecraft:light_blue_concrete
setblock 304 217 510 minecraft:white_concrete
fill 305 217 510 313 217 510 minecraft:light_blue_concrete
fill 306 217 552 309 217 552 minecraft:light_blue_concrete
setblock 309 217 513 minecraft:light[level=14]
setblock 309 217 521 minecraft:light[level=14]
setblock 309 217 529 minecraft:light[level=14]
setblock 309 217 537 minecraft:light[level=14]
setblock 309 217 545 minecraft:light[level=14]
setblock 310 217 552 minecraft:white_concrete
fill 311 217 537 312 219 537 minecraft:quartz_block
fill 311 217 552 314 307 552 minecraft:light_blue_concrete
fill 312 217 536 314 217 536 minecraft:quartz_block
fill 312 217 538 314 217 538 minecraft:quartz_block
fill 314 217 510 315 217 510 minecraft:white_concrete
fill 316 217 510 318 225 510 minecraft:light_blue_concrete
setblock 316 217 537 minecraft:gold_block
fill 316 217 552 316 307 552 minecraft:light_blue_concrete
setblock 317 217 513 minecraft:light[level=14]
setblock 317 217 521 minecraft:light[level=14]
setblock 317 217 529 minecraft:light[level=14]
setblock 317 217 537 minecraft:light[level=14]
setblock 317 217 545 minecraft:light[level=14]
setblock 317 217 552 minecraft:white_concrete
fill 318 217 552 324 217 552 minecraft:light_blue_concrete
fill 320 217 535 321 219 535 minecraft:quartz_block
fill 321 217 534 321 218 534 minecraft:quartz_block
fill 321 217 536 321 218 536 minecraft:quartz_block
fill 324 217 510 324 307 510 minecraft:light_blue_concrete
fill 324 217 512 324 217 524 minecraft:light_blue_concrete
setblock 324 217 525 minecraft:white_concrete
fill 324 217 526 324 217 536 minecraft:light_blue_concrete
setblock 324 217 537 minecraft:white_concrete
fill 324 217 538 324 217 545 minecraft:light_blue_concrete
fill 324 217 546 324 217 547 minecraft:white_concrete
fill 324 217 548 324 225 550 minecraft:light_blue_concrete
fill 282 218 510 282 307 512 minecraft:light_blue_concrete
setblock 282 218 513 minecraft:white_concrete
fill 282 218 514 282 225 516 minecraft:light_blue_concrete
fill 282 218 520 282 307 520 minecraft:light_blue_concrete
setblock 282 218 521 minecraft:white_concrete
fill 282 218 522 282 225 531 minecraft:light_blue_concrete
setblock 282 218 532 minecraft:white_concrete
fill 282 218 533 282 225 541 minecraft:light_blue_concrete
setblock 282 218 542 minecraft:white_concrete
fill 282 218 543 282 225 545 minecraft:light_blue_concrete
setblock 282 218 546 minecraft:white_concrete
fill 282 218 547 282 307 548 minecraft:light_blue_concrete
setblock 282 218 549 minecraft:white_concrete
fill 282 218 550 282 225 552 minecraft:light_blue_concrete
fill 283 218 510 283 307 510 minecraft:light_blue_concrete
setblock 283 218 552 minecraft:white_concrete
setblock 284 218 510 minecraft:white_concrete
fill 284 218 552 287 225 552 minecraft:light_blue_concrete
fill 285 218 510 293 225 510 minecraft:light_blue_concrete
fill 285 218 534 285 219 534 minecraft:quartz_block
fill 285 218 536 285 219 536 minecraft:quartz_block
fill 286 218 535 286 220 535 minecraft:quartz_block
fill 289 218 552 289 307 552 minecraft:light_blue_concrete
setblock 290 218 537 minecraft:gold_block
fill 292 218 536 295 218 536 minecraft:quartz_block
fill 292 218 538 295 218 538 minecraft:quartz_block
setblock 294 218 510 minecraft:white_concrete
fill 295 218 510 301 225 510 minecraft:light_blue_concrete
fill 295 218 537 296 220 537 minecraft:quartz_block
fill 295 218 552 300 225 552 minecraft:light_blue_concrete
setblock 301 218 552 minecraft:white_concrete
fill 302 218 552 302 307 552 minecraft:light_blue_concrete
fill 304 218 510 307 225 510 minecraft:light_blue_concrete
fill 306 218 552 306 225 552 minecraft:light_blue_concrete
setblock 307 218 552 minecraft:white_concrete
setblock 308 218 510 minecraft:white_concrete
fill 308 218 552 310 225 552 minecraft:light_blue_concrete
fill 309 218 510 315 225 510 minecraft:light_blue_concrete
fill 309 218 537 310 220 537 minecraft:quartz_block
fill 310 218 536 313 218 536 minecraft:quartz_block
fill 310 218 538 313 218 538 minecraft:quartz_block
setblock 315 218 537 minecraft:gold_block
fill 315 218 552 315 307 552 minecraft:light_blue_concrete
fill 317 218 552 320 225 552 minecraft:light_blue_concrete
setblock 319 218 510 minecraft:white_concrete
fill 319 218 535 319 220 535 minecraft:quartz_block
fill 320 218 510 323 307 510 minecraft:light_blue_concrete
fill 320 218 534 320 219 534 minecraft:quartz_block
fill 320 218 536 320 219 536 minecraft:quartz_block
setblock 321 218 552 minecraft:white_concrete
setblock 322 218 535 minecraft:quartz_block
fill 322 218 552 324 307 552 minecraft:light_blue_concrete
setblock 323 218 535 minecraft:gold_block
fill 324 218 512 324 225 519 minecraft:light_blue_concrete
setblock 324 218 520 minecraft:white_concrete
fill 324 218 521 324 225 529 minecraft:light_blue_concrete
setblock 324 218 530 minecraft:white_concrete
fill 324 218 531 324 225 537 minecraft:light_blue_concrete
setblock 324 218 538 minecraft:white_concrete
fill 324 218 539 324 307 543 minecraft:light_blue_concrete
setblock 324 218 544 minecraft:white_concrete
fill 324 218 545 324 225 547 minecraft:light_blue_concrete
fill 282 219 513 282 307 513 minecraft:light_blue_concrete
fill 282 219 521 282 307 521 minecraft:light_blue_concrete
fill 282 219 532 282 307 532 minecraft:light_blue_concrete
fill 282 219 542 282 225 542 minecraft:light_blue_concrete
fill 282 219 546 282 307 546 minecraft:light_blue_concrete
fill 282 219 549 282 307 549 minecraft:light_blue_concrete
fill 283 219 552 283 225 552 minecraft:light_blue_concrete
fill 284 219 510 284 307 510 minecraft:light_blue_concrete
setblock 284 219 535 minecraft:quartz_block
fill 286 219 534 287 220 534 minecraft:quartz_block
fill 286 219 536 287 220 536 minecraft:quartz_block
fill 287 219 535 287 221 535 minecraft:quartz_block
fill 292 219 537 293 219 537 minecraft:gold_block
fill 294 219 510 294 307 510 minecraft:light_blue_concrete
fill 294 219 536 294 219 538 minecraft:quartz_block
fill 295 219 536 297 219 536 minecraft:quartz_block
fill 295 219 538 297 219 538 minecraft:quartz_block
fill 297 219 537 300 220 537 minecraft:quartz_block
fill 301 219 552 301 307 552 minecraft:light_blue_concrete
fill 305 219 537 308 220 537 minecraft:quartz_block
fill 307 219 552 307 225 552 minecraft:light_blue_concrete
fill 308 219 510 308 307 510 minecraft:light_blue_concrete
fill 308 219 536 311 219 536 minecraft:quartz_block
fill 308 219 538 311 219 538 minecraft:quartz_block
setblock 313 219 537 minecraft:gold_block
fill 318 219 534 318 220 536 minecraft:quartz_block
fill 319 219 510 319 307 510 minecraft:light_blue_concrete
fill 319 219 534 319 220 534 minecraft:quartz_block
fill 319 219 536 319 220 536 minecraft:quartz_block
fill 321 219 552 321 225 552 minecraft:light_blue_concrete
setblock 322 219 535 minecraft:gold_block
fill 324 219 520 324 307 520 minecraft:light_blue_concrete
fill 324 219 530 324 307 530 minecraft:light_blue_concrete
fill 324 219 538 324 225 538 minecraft:light_blue_concrete
fill 324 219 544 324 307 544 minecraft:light_blue_concrete
fill 284 220 520 284 225 522 minecraft:quartz_block
fill 284 220 532 284 225 534 minecraft:quartz_block
setblock 284 220 535 minecraft:gold_block
fill 284 220 544 284 225 546 minecraft:quartz_block
fill 288 220 534 288 221 536 minecraft:quartz_block
fill 289 220 535 289 222 535 minecraft:quartz_block
fill 290 220 550 292 225 550 minecraft:quartz_block
fill 293 220 537 294 220 537 minecraft:gold_block
fill 294 220 512 296 225 512 minecraft:quartz_block
fill 296 220 536 309 220 536 minecraft:quartz_block
fill 296 220 538 309 220 538 minecraft:quartz_block
fill 301 220 537 304 221 537 minecraft:quartz_block
fill 302 220 550 304 225 550 minecraft:quartz_block
fill 306 220 512 308 225 512 minecraft:quartz_block
fill 311 220 537 312 220 537 minecraft:gold_block
fill 314 220 550 316 225 550 minecraft:quartz_block
fill 316 220 535 317 222 535 minecraft:quartz_block
fill 317 220 534 317 221 534 minecraft:quartz_block
fill 317 220 536 317 221 536 minecraft:quartz_block
fill 318 220 512 320 225 512 minecraft:quartz_block
setblock 320 220 535 minecraft:quartz_block
setblock 321 220 535 minecraft:gold_block
fill 322 220 520 322 225 522 minecraft:quartz_block
fill 322 220 532 322 225 534 minecraft:quartz_block
fill 322 220 544 322 225 546 minecraft:quartz_block
setblock 286 221 535 minecraft:gold_block
fill 287 221 532 288 222 532 minecraft:white_wool
fill 289 221 534 289 222 534 minecraft:quartz_block
fill 289 221 536 289 222 536 minecraft:quartz_block
fill 290 221 535 290 223 535 minecraft:quartz_block
fill 295 221 537 297 221 537 minecraft:gold_block
fill 298 221 537 300 221 537 minecraft:quartz_block
fill 300 221 536 305 221 536 minecraft:quartz_block
fill 300 221 538 305 221 538 minecraft:quartz_block
fill 301 221 541 301 222 542 minecraft:white_wool
fill 305 221 537 307 221 537 minecraft:quartz_block
fill 308 221 537 310 221 537 minecraft:gold_block
fill 315 221 535 315 223 535 minecraft:quartz_block
fill 316 221 534 316 222 534 minecraft:quartz_block
fill 316 221 536 316 222 536 minecraft:quartz_block
setblock 318 221 535 minecraft:quartz_block
setblock 319 221 535 minecraft:gold_block
fill 322 221 523 323 222 523 minecraft:quartz_block
fill 323 221 522 323 222 522 minecraft:quartz_block
fill 284 222 523 284 223 523 minecraft:quartz_block
fill 285 222 522 285 225 522 minecraft:quartz_block
setblock 287 222 535 minecraft:gold_block
setblock 288 222 535 minecraft:quartz_block
fill 290 222 534 291 222 534 minecraft:quartz_block
fill 290 222 536 291 222 536 minecraft:quartz_block
fill 291 222 535 292 224 535 minecraft:quartz_block
fill 298 222 537 307 222 537 minecraft:gold_block
fill 313 222 535 314 224 535 minecraft:quartz_block
fill 314 222 534 315 222 534 minecraft:quartz_block
fill 314 222 536 315 222 536 minecraft:quartz_block
setblock 318 222 535 minecraft:gold_block
fill 320 222 522 321 224 522 minecraft:quartz_block
fill 321 222 521 321 223 521 minecraft:quartz_block
fill 321 222 523 321 223 523 minecraft:quartz_block
fill 285 223 521 285 224 521 minecraft:quartz_block
fill 285 223 523 285 224 523 minecraft:quartz_block
fill 286 223 522 286 225 522 minecraft:quartz_block
setblock 289 223 535 minecraft:gold_block
fill 291 223 534 293 223 534 minecraft:quartz_block
fill 291 223 536 293 223 536 minecraft:quartz_block
fill 293 223 535 294 224 535 minecraft:quartz_block
fill 311 223 535 312 225 535 minecraft:quartz_block
fill 312 223 534 314 223 534 minecraft:quartz_block
fill 312 223 536 314 223 536 minecraft:quartz_block
setblock 316 223 535 minecraft:gold_block
fill 319 223 522 319 225 522 minecraft:quartz_block
fill 320 223 521 320 224 521 minecraft:quartz_block
fill 320 223 523 320 224 523 minecraft:quartz_block
setblock 323 223 522 minecraft:gold_block
fill 286 224 521 287 225 521 minecraft:quartz_block
fill 286 224 523 287 225 523 minecraft:quartz_block
fill 287 224 522 287 226 522 minecraft:quartz_block
setblock 290 224 535 minecraft:gold_block
fill 292 224 534 295 224 534 minecraft:quartz_block
fill 292 224 536 295 224 536 minecraft:quartz_block
fill 295 224 535 296 226 535 minecraft:quartz_block
fill 295 224 546 296 225 547 minecraft:white_concrete
fill 309 224 535 310 226 535 minecraft:quartz_block
fill 310 224 534 313 224 534 minecraft:quartz_block
fill 310 224 536 313 224 536 minecraft:quartz_block
setblock 315 224 535 minecraft:gold_block
fill 318 224 521 318 225 523 minecraft:quartz_block
fill 319 224 521 319 225 521 minecraft:quartz_block
fill 319 224 523 319 225 523 minecraft:quartz_block
fill 283 225 514 283 225 519 minecraft:smooth_quartz
fill 283 225 526 283 225 531 minecraft:smooth_quartz
fill 283 225 538 283 225 543 minecraft:smooth_quartz
fill 283 225 550 283 225 551 minecraft:smooth_quartz
fill 284 225 551 287 225 551 minecraft:smooth_quartz
setblock 285 225 513 minecraft:light[level=14]
setblock 285 225 521 minecraft:light[level=14]
setblock 285 225 529 minecraft:light[level=14]
setblock 285 225 537 minecraft:light[level=14]
setblock 285 225 545 minecraft:light[level=14]
fill 287 225 511 292 225 511 minecraft:smooth_quartz
fill 288 225 521 288 226 523 minecraft:quartz_block
fill 289 225 522 289 227 522 minecraft:quartz_block
fill 292 225 535 293 225 535 minecraft:gold_block
setblock 293 225 513 minecraft:light[level=14]
setblock 293 225 521 minecraft:light[level=14]
setblock 293 225 529 minecraft:light[level=14]
setblock 293 225 537 minecraft:light[level=14]
setblock 293 225 545 minecraft:light[level=14]
fill 294 225 534 294 225 536 minecraft:quartz_block
fill 294 225 551 299 225 551 minecraft:smooth_quartz
fill 295 225 534 297 225 534 minecraft:quartz_block
fill 295 225 536 297 225 536 minecraft:quartz_block
fill 297 225 535 299 226 535 minecraft:quartz_block
fill 299 225 511 304 225 511 minecraft:smooth_quartz
setblock 301 225 513 minecraft:light[level=14]
setblock 301 225 521 minecraft:light[level=14]
setblock 301 225 529 minecraft:light[level=14]
setblock 301 225 537 minecraft:light[level=14]
setblock 301 225 545 minecraft:light[level=14]
fill 305 225 535 308 226 535 minecraft:quartz_block
fill 306 225 551 311 225 551 minecraft:smooth_quartz
fill 308 225 534 311 225 534 minecraft:quartz_block
fill 308 225 536 311 225 536 minecraft:quartz_block
setblock 309 225 513 minecraft:light[level=14]
setblock 309 225 521 minecraft:light[level=14]
setblock 309 225 529 minecraft:light[level=14]
setblock 309 225 537 minecraft:light[level=14]
setblock 309 225 545 minecraft:light[level=14]
fill 311 225 511 316 225 511 minecraft:smooth_quartz
setblock 313 225 535 minecraft:gold_block
fill 316 225 522 317 227 522 minecraft:quartz_block
setblock 317 225 513 minecraft:light[level=14]
fill 317 225 521 317 226 521 minecraft:quartz_block
fill 317 225 523 317 226 523 minecraft:quartz_block
setblock 317 225 529 minecraft:light[level=14]
setblock 317 225 537 minecraft:light[level=14]
setblock 317 225 545 minecraft:light[level=14]
fill 318 225 551 323 225 551 minecraft:smooth_quartz
setblock 320 225 522 minecraft:quartz_block
setblock 321 225 522 minecraft:gold_block
fill 323 225 511 323 225 516 minecraft:smooth_quartz
fill 323 225 523 323 225 528 minecraft:smooth_quartz
fill 323 225 535 323 225 540 minecraft:smooth_quartz
fill 323 225 547 323 225 550 minecraft:smooth_quartz
fill 282 226 514 282 307 515 minecraft:light_blue_concrete
fill 282 226 516 282 231 519 minecraft:pearlescent_froglight
fill 282 226 522 282 307 527 minecraft:light_blue_concrete
fill 282 226 528 282 231 531 minecraft:pearlescent_froglight
fill 282 226 533 282 307 539 minecraft:light_blue_concrete
fill 282 226 540 282 231 543 minecraft:pearlescent_froglight
fill 282 226 544 282 307 545 minecraft:light_blue_concrete
fill 282 226 550 282 307 551 minecraft:light_blue_concrete
fill 282 226 552 285 231 552 minecraft:pearlescent_froglight
fill 285 226 510 288 307 510 minecraft:light_blue_concrete
setblock 286 226 522 minecraft:gold_block
fill 286 226 552 287 307 552 minecraft:light_blue_concrete
fill 289 226 510 292 231 510 minecraft:pearlescent_froglight
fill 289 226 521 289 227 521 minecraft:quartz_block
fill 289 226 523 289 227 523 minecraft:quartz_block
fill 290 226 522 290 228 522 minecraft:quartz_block
fill 290 226 552 293 307 552 minecraft:light_blue_concrete
fill 293 226 510 293 307 510 minecraft:light_blue_concrete
fill 293 226 535 294 226 535 minecraft:gold_block
fill 294 226 552 297 231 552 minecraft:pearlescent_froglight
fill 295 226 510 300 307 510 minecraft:light_blue_concrete
fill 296 226 534 298 226 534 minecraft:quartz_block
fill 296 226 536 309 226 536 minecraft:quartz_block
fill 298 226 552 300 307 552 minecraft:light_blue_concrete
fill 301 226 510 304 231 510 minecraft:pearlescent_froglight
fill 304 226 534 304 227 535 minecraft:quartz_block
fill 305 226 510 307 307 510 minecraft:light_blue_concrete
fill 305 226 534 309 226 534 minecraft:quartz_block
fill 306 226 552 309 231 552 minecraft:pearlescent_froglight
fill 309 226 510 312 307 510 minecraft:light_blue_concrete
fill 310 226 552 310 307 552 minecraft:light_blue_concrete
fill 311 226 535 312 226 535 minecraft:gold_block
fill 313 226 510 316 231 510 minecraft:pearlescent_froglight
fill 315 226 522 315 228 522 minecraft:quartz_block
fill 316 226 521 316 227 521 minecraft:quartz_block
fill 316 226 523 316 227 523 minecraft:quartz_block
fill 317 226 510 318 307 510 minecraft:light_blue_concrete
fill 317 226 552 317 307 552 minecraft:light_blue_concrete
setblock 318 226 522 minecraft:quartz_block
fill 318 226 552 321 231 552 minecraft:pearlescent_froglight
setblock 319 226 522 minecraft:gold_block
fill 324 226 511 324 231 514 minecraft:pearlescent_froglight
fill 324 226 515 324 307 519 minecraft:light_blue_concrete
fill 324 226 521 324 307 522 minecraft:light_blue_concrete
fill 324 226 523 324 231 526 minecraft:pearlescent_froglight
fill 324 226 527 324 307 529 minecraft:light_blue_concrete
fill 324 226 531 324 307 534 minecraft:light_blue_concrete
fill 324 226 535 324 231 538 minecraft:pearlescent_froglight
fill 324 226 545 324 307 546 minecraft:light_blue_concrete
fill 324 226 547 324 231 550 minecraft:pearlescent_froglight
setblock 287 227 522 minecraft:gold_block
setblock 288 227 522 minecraft:quartz_block
fill 290 227 521 291 227 521 minecraft:quartz_block
fill 290 227 523 291 227 523 minecraft:quartz_block
fill 291 227 522 292 229 522 minecraft:quartz_block
fill 295 227 535 297 227 535 minecraft:gold_block
fill 298 227 535 299 227 535 minecraft:quartz_block
fill 300 227 536 305 227 536 minecraft:quartz_block
fill 305 227 534 305 227 535 minecraft:quartz_block
fill 306 227 535 307 227 535 minecraft:quartz_block
fill 308 227 535 310 227 535 minecraft:gold_block
fill 313 227 522 314 229 522 minecraft:quartz_block
fill 314 227 521 315 227 521 minecraft:quartz_block
fill 314 227 523 315 227 523 minecraft:quartz_block
setblock 318 227 522 minecraft:gold_block
setblock 289 228 522 minecraft:gold_block
fill 291 228 521 293 228 521 minecraft:quartz_block
fill 291 228 523 293 228 523 minecraft:quartz_block
fill 293 228 522 294 230 522 minecraft:quartz_block
fill 298 228 535 299 228 535 minecraft:gold_block
fill 304 228 535 307 228 535 minecraft:gold_block
fill 311 228 522 312 230 522 minecraft:quartz_block
fill 312 228 521 314 228 521 minecraft:quartz_block
fill 312 228 523 314 228 523 minecraft:quartz_block
setblock 316 228 522 minecraft:gold_block
setblock 290 229 522 minecraft:gold_block
fill 292 229 521 295 229 521 minecraft:quartz_block
fill 292 229 523 295 229 523 minecraft:quartz_block
fill 295 229 522 296 231 522 minecraft:quartz_block
fill 309 229 522 310 231 522 minecraft:quartz_block
fill 310 229 521 313 229 521 minecraft:quartz_block
fill 310 229 523 313 229 523 minecraft:quartz_block
setblock 315 229 522 minecraft:gold_block
setblock 292 230 522 minecraft:gold_block
fill 294 230 521 297 230 521 minecraft:quartz_block
fill 294 230 523 297 230 523 minecraft:quartz_block
fill 297 230 522 300 231 522 minecraft:quartz_block
fill 305 230 522 308 231 522 minecraft:quartz_block
fill 308 230 521 311 230 521 minecraft:quartz_block
fill 308 230 523 311 230 523 minecraft:quartz_block
setblock 313 230 522 minecraft:gold_block
fill 293 231 522 294 231 522 minecraft:gold_block
fill 297 231 521 308 231 521 minecraft:quartz_block
fill 297 231 523 308 231 523 minecraft:quartz_block
fill 301 231 522 304 231 522 minecraft:quartz_block
fill 311 231 522 312 231 522 minecraft:gold_block
fill 282 232 516 282 245 519 minecraft:light_blue_concrete
fill 282 232 528 282 245 531 minecraft:light_blue_concrete
fill 282 232 540 282 245 543 minecraft:light_blue_concrete
fill 282 232 552 285 245 552 minecraft:light_blue_concrete
fill 289 232 510 292 245 510 minecraft:light_blue_concrete
fill 294 232 552 297 245 552 minecraft:light_blue_concrete
fill 301 232 510 304 245 510 minecraft:light_blue_concrete
fill 306 232 552 309 245 552 minecraft:light_blue_concrete
fill 313 232 510 316 245 510 minecraft:light_blue_concrete
fill 318 232 552 321 245 552 minecraft:light_blue_concrete
fill 324 232 511 324 245 514 minecraft:light_blue_concrete
fill 324 232 523 324 245 526 minecraft:light_blue_concrete
fill 324 232 535 324 245 538 minecraft:light_blue_concrete
fill 324 232 547 324 245 550 minecraft:light_blue_concrete
setblock 285 233 513 minecraft:light[level=14]
setblock 285 233 521 minecraft:light[level=14]
setblock 285 233 529 minecraft:light[level=14]
setblock 285 233 537 minecraft:light[level=14]
setblock 285 233 545 minecraft:light[level=14]
setblock 293 233 513 minecraft:light[level=14]
setblock 293 233 521 minecraft:light[level=14]
setblock 293 233 529 minecraft:light[level=14]
setblock 293 233 537 minecraft:light[level=14]
setblock 293 233 545 minecraft:light[level=14]
setblock 301 233 513 minecraft:light[level=14]
setblock 301 233 521 minecraft:light[level=14]
setblock 301 233 529 minecraft:light[level=14]
setblock 301 233 537 minecraft:light[level=14]
setblock 301 233 545 minecraft:light[level=14]
setblock 309 233 513 minecraft:light[level=14]
setblock 309 233 521 minecraft:light[level=14]
setblock 309 233 529 minecraft:light[level=14]
setblock 309 233 537 minecraft:light[level=14]
setblock 309 233 545 minecraft:light[level=14]
setblock 317 233 513 minecraft:light[level=14]
setblock 317 233 521 minecraft:light[level=14]
setblock 317 233 529 minecraft:light[level=14]
setblock 317 233 537 minecraft:light[level=14]
setblock 317 233 545 minecraft:light[level=14]
fill 290 237 533 291 237 533 minecraft:gold_block
fill 291 237 529 292 237 532 minecraft:gold_block
fill 291 237 534 292 237 537 minecraft:gold_block
fill 292 237 527 293 237 528 minecraft:gold_block
fill 292 237 533 298 237 533 minecraft:white_stained_glass
fill 292 237 538 293 237 539 minecraft:gold_block
fill 293 237 526 295 237 526 minecraft:gold_block
fill 293 237 529 299 237 532 minecraft:white_stained_glass
fill 293 237 534 299 237 537 minecraft:white_stained_glass
fill 293 237 540 295 238 540 minecraft:gold_block
fill 294 237 525 296 237 525 minecraft:gold_block
fill 294 237 527 294 238 527 minecraft:gold_block
fill 294 237 528 308 238 528 minecraft:white_stained_glass
fill 294 237 538 308 238 538 minecraft:white_stained_glass
fill 294 237 539 294 238 539 minecraft:gold_block
fill 294 237 541 296 237 541 minecraft:gold_block
fill 295 237 524 300 237 524 minecraft:gold_block
fill 295 237 527 307 238 527 minecraft:white_stained_glass
fill 295 237 539 307 238 539 minecraft:white_stained_glass
fill 295 237 542 300 237 542 minecraft:gold_block
fill 296 237 526 306 238 526 minecraft:white_stained_glass
fill 296 237 540 306 238 540 minecraft:white_stained_glass
fill 297 237 523 305 237 523 minecraft:gold_block
fill 297 237 525 305 238 525 minecraft:white_stained_glass
fill 297 237 541 305 238 541 minecraft:white_stained_glass
fill 297 237 543 305 237 543 minecraft:gold_block
fill 300 237 529 300 237 531 minecraft:white_stained_glass
fill 300 237 535 300 237 537 minecraft:white_stained_glass
fill 301 237 522 301 238 522 minecraft:gold_block
fill 301 237 524 301 238 524 minecraft:white_stained_glass
fill 301 237 529 309 237 530 minecraft:white_stained_glass
fill 301 237 536 309 237 537 minecraft:white_stained_glass
fill 301 237 542 301 238 542 minecraft:white_stained_glass
fill 301 237 544 301 238 544 minecraft:gold_block
fill 302 237 524 307 237 524 minecraft:gold_block
fill 302 237 531 309 237 531 minecraft:white_stained_glass
fill 302 237 535 309 237 535 minecraft:white_stained_glass
fill 302 237 542 307 237 542 minecraft:gold_block
fill 303 237 532 309 237 532 minecraft:white_stained_glass
fill 303 237 534 309 237 534 minecraft:white_stained_glass
fill 304 237 533 310 237 533 minecraft:white_stained_glass
fill 306 237 525 308 237 525 minecraft:gold_block
fill 306 237 541 308 237 541 minecraft:gold_block
fill 307 237 526 309 238 526 minecraft:gold_block
fill 307 237 540 309 237 540 minecraft:gold_block
fill 308 237 527 310 237 527 minecraft:gold_block
fill 308 237 539 310 237 539 minecraft:gold_block
fill 309 237 528 310 238 528 minecraft:gold_block
fill 309 237 538 310 237 538 minecraft:gold_block
fill 310 237 529 311 237 532 minecraft:gold_block
fill 310 237 534 311 237 537 minecraft:gold_block
fill 311 237 533 312 237 533 minecraft:gold_block
fill 283 238 511 289 238 551 minecraft:quartz_block
fill 290 238 511 290 238 532 minecraft:quartz_block
setblock 290 238 533 minecraft:gold_block
fill 290 238 534 290 238 551 minecraft:quartz_block
fill 291 238 511 291 238 528 minecraft:quartz_block
setblock 291 238 529 minecraft:pearlescent_froglight
fill 291 238 530 291 238 532 minecraft:gold_block
setblock 291 238 533 minecraft:pearlescent_froglight
fill 291 238 534 291 238 536 minecraft:gold_block
setblock 291 238 537 minecraft:pearlescent_froglight
fill 291 238 538 291 238 551 minecraft:quartz_block
fill 292 238 511 292 238 526 minecraft:quartz_block
setblock 292 238 527 minecraft:gold_block
setblock 292 238 528 minecraft:pearlescent_froglight
fill 292 238 529 292 238 531 minecraft:gold_block
setblock 292 238 532 minecraft:pearlescent_froglight
fill 292 238 533 297 238 533 minecraft:white_stained_glass
fill 292 238 534 292 238 535 minecraft:gold_block
setblock 292 238 536 minecraft:pearlescent_froglight
fill 292 238 537 292 238 539 minecraft:gold_block
fill 292 238 540 292 238 551 minecraft:quartz_block
fill 293 238 511 293 238 525 minecraft:quartz_block
setblock 293 238 526 minecraft:gold_block
setblock 293 238 527 minecraft:pearlescent_froglight
setblock 293 238 528 minecraft:gold_block
fill 293 238 529 297 238 532 minecraft:white_stained_glass
fill 293 238 534 297 238 537 minecraft:white_stained_glass
setblock 293 238 538 minecraft:gold_block
setblock 293 238 539 minecraft:pearlescent_froglight
fill 293 238 541 293 238 551 minecraft:quartz_block
fill 294 238 511 294 238 524 minecraft:quartz_block
setblock 294 238 525 minecraft:gold_block
setblock 294 238 526 minecraft:pearlescent_froglight
setblock 294 238 541 minecraft:gold_block
fill 294 238 542 294 238 551 minecraft:quartz_block
fill 295 238 511 296 238 523 minecraft:quartz_block
setblock 295 238 524 minecraft:gold_block
setblock 295 238 525 minecraft:pearlescent_froglight
setblock 295 238 526 minecraft:gold_block
setblock 295 238 541 minecraft:pearlescent_froglight
fill 295 238 542 297 238 542 minecraft:gold_block
fill 295 238 543 296 238 551 minecraft:quartz_block
setblock 296 238 524 minecraft:pearlescent_froglight
setblock 296 238 525 minecraft:gold_block
setblock 296 238 541 minecraft:gold_block
fill 297 238 511 300 238 522 minecraft:quartz_block
setblock 297 238 523 minecraft:pearlescent_froglight
fill 297 238 524 299 238 524 minecraft:gold_block
setblock 297 238 543 minecraft:pearlescent_froglight
fill 297 238 544 300 238 551 minecraft:quartz_block
fill 298 238 523 300 238 523 minecraft:gold_block
fill 298 238 529 298 238 531 minecraft:white_stained_glass
fill 298 238 532 298 238 534 minecraft:pearlescent_froglight
fill 298 238 535 298 238 537 minecraft:white_stained_glass
setblock 298 238 542 minecraft:pearlescent_froglight
fill 298 238 543 300 238 543 minecraft:gold_block
fill 299 238 529 299 238 530 minecraft:white_stained_glass
fill 299 238 531 299 238 532 minecraft:pearlescent_froglight
fill 299 238 534 299 238 535 minecraft:pearlescent_froglight
fill 299 238 536 299 238 537 minecraft:white_stained_glass
fill 299 238 542 300 238 542 minecraft:gold_block
setblock 300 238 524 minecraft:pearlescent_froglight
fill 300 238 529 309 238 529 minecraft:white_stained_glass
fill 300 238 530 300 238 531 minecraft:pearlescent_froglight
fill 300 238 535 300 238 536 minecraft:pearlescent_froglight
fill 300 238 537 309 238 537 minecraft:white_stained_glass
fill 301 238 511 323 238 521 minecraft:quartz_block
setblock 301 238 523 minecraft:pearlescent_froglight
fill 301 238 530 302 238 530 minecraft:pearlescent_froglight
fill 301 238 536 302 238 536 minecraft:pearlescent_froglight
setblock 301 238 543 minecraft:pearlescent_froglight
fill 301 238 545 323 238 551 minecraft:quartz_block
fill 302 238 522 323 238 522 minecraft:quartz_block
fill 302 238 523 303 238 524 minecraft:gold_block
fill 302 238 531 303 238 531 minecraft:pearlescent_froglight
fill 302 238 535 303 238 535 minecraft:pearlescent_froglight
setblock 302 238 542 minecraft:pearlescent_froglight
fill 302 238 543 304 238 543 minecraft:gold_block
fill 302 238 544 323 238 544 minecraft:quartz_block
fill 303 238 530 309 238 530 minecraft:white_stained_glass
fill 303 238 532 304 238 532 minecraft:pearlescent_froglight
fill 303 238 534 304 238 534 minecraft:pearlescent_froglight
fill 303 238 536 309 238 536 minecraft:white_stained_glass
fill 303 238 542 305 238 542 minecraft:gold_block
setblock 304 238 523 minecraft:gold_block
setblock 304 238 524 minecraft:pearlescent_froglight
fill 304 238 531 309 238 531 minecraft:white_stained_glass
setblock 304 238 533 minecraft:pearlescent_froglight
fill 304 238 535 309 238 535 minecraft:white_stained_glass
setblock 305 238 523 minecraft:pearlescent_froglight
fill 305 238 524 307 238 524 minecraft:gold_block
fill 305 238 532 309 238 534 minecraft:white_stained_glass
setblock 305 238 543 minecraft:pearlescent_froglight
fill 306 238 523 323 238 523 minecraft:quartz_block
setblock 306 238 525 minecraft:gold_block
setblock 306 238 541 minecraft:gold_block
setblock 306 238 542 minecraft:pearlescent_froglight
fill 306 238 543 323 238 543 minecraft:quartz_block
setblock 307 238 525 minecraft:pearlescent_froglight
setblock 307 238 540 minecraft:gold_block
setblock 307 238 541 minecraft:pearlescent_froglight
setblock 307 238 542 minecraft:gold_block
fill 308 238 524 323 238 524 minecraft:quartz_block
setblock 308 238 525 minecraft:gold_block
setblock 308 238 527 minecraft:gold_block
setblock 308 238 539 minecraft:gold_block
setblock 308 238 540 minecraft:pearlescent_froglight
setblock 308 238 541 minecraft:gold_block
fill 308 238 542 323 238 542 minecraft:quartz_block
fill 309 238 525 323 238 525 minecraft:quartz_block
setblock 309 238 527 minecraft:pearlescent_froglight
setblock 309 238 538 minecraft:gold_block
setblock 309 238 539 minecraft:pearlescent_froglight
setblock 309 238 540 minecraft:gold_block
fill 309 238 541 323 238 541 minecraft:quartz_block
fill 310 238 526 323 238 526 minecraft:quartz_block
setblock 310 238 527 minecraft:gold_block
setblock 310 238 529 minecraft:gold_block
setblock 310 238 530 minecraft:pearlescent_froglight
fill 310 238 531 311 238 532 minecraft:gold_block
setblock 310 238 533 minecraft:white_stained_glass
setblock 310 238 534 minecraft:pearlescent_froglight
fill 310 238 535 310 238 537 minecraft:gold_block
setblock 310 238 538 minecraft:pearlescent_froglight
setblock 310 238 539 minecraft:gold_block
fill 310 238 540 323 238 540 minecraft:quartz_block
fill 311 238 527 323 238 528 minecraft:quartz_block
setblock 311 238 529 minecraft:pearlescent_froglight
setblock 311 238 530 minecraft:gold_block
setblock 311 238 533 minecraft:pearlescent_froglight
fill 311 238 534 311 238 536 minecraft:gold_block
setblock 311 238 537 minecraft:pearlescent_froglight
fill 311 238 538 323 238 539 minecraft:quartz_block
fill 312 238 529 323 238 532 minecraft:quartz_block
setblock 312 238 533 minecraft:gold_block
fill 312 238 534 323 238 537 minecraft:quartz_block
fill 313 238 533 323 238 533 minecraft:quartz_block
fill 290 239 523 292 242 523 minecraft:gold_block
fill 290 239 543 292 242 543 minecraft:gold_block
fill 291 239 522 291 242 522 minecraft:gold_block
fill 291 239 524 291 242 524 minecraft:gold_block
fill 291 239 542 291 242 542 minecraft:gold_block
fill 291 239 544 291 242 544 minecraft:gold_block
fill 310 239 523 312 242 523 minecraft:gold_block
fill 310 239 543 312 242 543 minecraft:gold_block
fill 311 239 522 311 242 522 minecraft:gold_block
fill 311 239 524 311 242 524 minecraft:gold_block
fill 311 239 542 311 242 542 minecraft:gold_block
fill 311 239 544 311 242 544 minecraft:gold_block
setblock 285 241 513 minecraft:light[level=14]
setblock 285 241 521 minecraft:light[level=14]
setblock 285 241 529 minecraft:light[level=14]
setblock 285 241 537 minecraft:light[level=14]
setblock 285 241 545 minecraft:light[level=14]
setblock 293 241 513 minecraft:light[level=14]
setblock 293 241 521 minecraft:light[level=14]
setblock 293 241 529 minecraft:light[level=14]
setblock 293 241 537 minecraft:light[level=14]
setblock 293 241 545 minecraft:light[level=14]
setblock 301 241 513 minecraft:light[level=14]
setblock 301 241 521 minecraft:light[level=14]
setblock 301 241 529 minecraft:light[level=14]
setblock 301 241 537 minecraft:light[level=14]
setblock 301 241 545 minecraft:light[level=14]
setblock 309 241 513 minecraft:light[level=14]
setblock 309 241 521 minecraft:light[level=14]
setblock 309 241 529 minecraft:light[level=14]
setblock 309 241 537 minecraft:light[level=14]
setblock 309 241 545 minecraft:light[level=14]
setblock 317 241 513 minecraft:light[level=14]
setblock 317 241 521 minecraft:light[level=14]
setblock 317 241 529 minecraft:light[level=14]
setblock 317 241 537 minecraft:light[level=14]
setblock 317 241 545 minecraft:light[level=14]
fill 283 242 511 285 273 511 minecraft:quartz_block
fill 283 242 521 283 273 523 minecraft:quartz_block
fill 283 242 533 283 273 535 minecraft:quartz_block
fill 283 242 545 283 273 547 minecraft:quartz_block
fill 284 242 515 284 242 516 minecraft:smooth_quartz
fill 284 242 520 284 245 522 minecraft:quartz_block
fill 284 242 532 284 245 534 minecraft:quartz_block
fill 284 242 544 284 245 546 minecraft:quartz_block
fill 285 242 513 288 242 513 minecraft:smooth_quartz
fill 285 242 514 285 273 516 minecraft:quartz_block
fill 285 242 517 286 242 517 minecraft:smooth_quartz
setblock 286 242 514 minecraft:smooth_quartz
fill 286 242 515 289 273 515 minecraft:quartz_block
setblock 286 242 516 minecraft:smooth_quartz
fill 287 242 514 288 273 514 minecraft:quartz_block
fill 287 242 516 288 273 517 minecraft:quartz_block
setblock 288 242 518 minecraft:smooth_quartz
setblock 289 242 514 minecraft:smooth_quartz
fill 289 242 516 289 273 516 minecraft:quartz_block
setblock 289 242 517 minecraft:smooth_quartz
fill 289 242 551 291 273 551 minecraft:quartz_block
fill 290 242 515 290 242 516 minecraft:smooth_quartz
fill 290 242 550 292 245 550 minecraft:quartz_block
fill 294 242 512 296 245 512 minecraft:quartz_block
fill 294 242 543 294 243 543 minecraft:light_blue_stained_glass
fill 295 242 511 297 273 511 minecraft:quartz_block
fill 301 242 551 303 273 551 minecraft:quartz_block
fill 302 242 550 304 245 550 minecraft:quartz_block
fill 306 242 512 308 245 512 minecraft:quartz_block
fill 307 242 511 309 273 511 minecraft:quartz_block
fill 313 242 551 315 273 551 minecraft:quartz_block
fill 314 242 550 316 245 550 minecraft:quartz_block
fill 316 242 546 316 242 548 minecraft:smooth_quartz
fill 317 242 545 318 242 545 minecraft:smooth_quartz
fill 317 242 546 317 273 548 minecraft:quartz_block
fill 317 242 549 319 242 549 minecraft:smooth_quartz
fill 318 242 512 320 245 512 minecraft:quartz_block
fill 318 242 546 318 242 547 minecraft:smooth_quartz
fill 318 242 548 318 273 548 minecraft:quartz_block
fill 319 242 511 321 273 511 minecraft:quartz_block
fill 319 242 544 321 242 544 minecraft:smooth_quartz
fill 319 242 545 321 273 547 minecraft:quartz_block
fill 319 242 548 321 242 548 minecraft:smooth_quartz
fill 322 242 520 322 245 522 minecraft:quartz_block
fill 322 242 532 322 245 534 minecraft:quartz_block
fill 322 242 544 322 245 546 minecraft:quartz_block
setblock 322 242 547 minecraft:smooth_quartz
fill 323 242 519 323 273 521 minecraft:quartz_block
fill 323 242 531 323 273 533 minecraft:quartz_block
fill 323 242 543 323 273 545 minecraft:quartz_block
fill 286 243 514 286 249 514 minecraft:quartz_block
fill 286 243 516 286 249 516 minecraft:quartz_block
fill 318 243 546 318 249 547 minecraft:quartz_block
fill 319 243 548 319 249 548 minecraft:quartz_block
fill 294 244 543 294 253 543 minecraft:smooth_quartz
fill 305 244 523 306 245 524 minecraft:white_concrete
fill 307 244 523 307 245 523 minecraft:white_concrete
fill 283 245 514 283 245 519 minecraft:smooth_quartz
fill 283 245 526 283 245 531 minecraft:smooth_quartz
fill 283 245 538 283 245 543 minecraft:smooth_quartz
fill 283 245 550 283 245 551 minecraft:smooth_quartz
fill 284 245 551 287 245 551 minecraft:smooth_quartz
fill 287 245 511 292 245 511 minecraft:smooth_quartz
fill 294 245 551 299 245 551 minecraft:smooth_quartz
fill 295 245 543 295 253 543 minecraft:smooth_quartz
fill 299 245 511 304 245 511 minecraft:smooth_quartz
fill 306 245 551 311 245 551 minecraft:smooth_quartz
fill 311 245 511 316 245 511 minecraft:smooth_quartz
fill 318 245 551 323 245 551 minecraft:smooth_quartz
fill 323 245 511 323 245 516 minecraft:smooth_quartz
fill 323 245 523 323 245 528 minecraft:smooth_quartz
fill 323 245 535 323 245 540 minecraft:smooth_quartz
fill 323 245 547 323 245 550 minecraft:smooth_quartz
fill 282 246 516 282 251 519 minecraft:pearlescent_froglight
fill 282 246 528 282 251 531 minecraft:pearlescent_froglight
fill 282 246 540 282 251 543 minecraft:pearlescent_froglight
fill 282 246 552 285 251 552 minecraft:pearlescent_froglight
fill 289 246 510 292 251 510 minecraft:pearlescent_froglight
fill 294 246 544 295 253 544 minecraft:smooth_quartz
fill 294 246 552 297 251 552 minecraft:pearlescent_froglight
fill 301 246 510 304 251 510 minecraft:pearlescent_froglight
fill 306 246 552 309 251 552 minecraft:pearlescent_froglight
fill 313 246 510 316 251 510 minecraft:pearlescent_froglight
fill 318 246 552 321 251 552 minecraft:pearlescent_froglight
fill 324 246 511 324 251 514 minecraft:pearlescent_froglight
fill 324 246 523 324 251 526 minecraft:pearlescent_froglight
fill 324 246 535 324 251 538 minecraft:pearlescent_froglight
fill 324 246 547 324 251 550 minecraft:pearlescent_froglight
fill 293 247 543 293 253 544 minecraft:smooth_quartz
fill 294 247 542 295 253 542 minecraft:smooth_quartz
fill 296 247 543 296 253 543 minecraft:smooth_quartz
fill 293 248 542 293 253 542 minecraft:smooth_quartz
fill 294 248 545 295 253 545 minecraft:smooth_quartz
fill 296 248 542 296 253 542 minecraft:smooth_quartz
fill 296 248 544 296 253 544 minecraft:smooth_quartz
fill 301 248 516 301 249 516 minecraft:white_wool
setblock 285 249 513 minecraft:light[level=14]
setblock 285 249 521 minecraft:light[level=14]
setblock 285 249 529 minecraft:light[level=14]
setblock 285 249 537 minecraft:light[level=14]
setblock 285 249 545 minecraft:light[level=14]
fill 292 249 543 292 253 544 minecraft:smooth_quartz
setblock 293 249 513 minecraft:light[level=14]
setblock 293 249 521 minecraft:light[level=14]
setblock 293 249 529 minecraft:light[level=14]
setblock 293 249 537 minecraft:light[level=14]
fill 293 249 545 293 253 545 minecraft:smooth_quartz
fill 294 249 541 295 253 541 minecraft:smooth_quartz
fill 296 249 545 296 253 545 minecraft:smooth_quartz
setblock 301 249 513 minecraft:light[level=14]
setblock 301 249 521 minecraft:light[level=14]
setblock 301 249 529 minecraft:light[level=14]
setblock 301 249 537 minecraft:light[level=14]
setblock 301 249 545 minecraft:light[level=14]
setblock 309 249 513 minecraft:light[level=14]
setblock 309 249 521 minecraft:light[level=14]
setblock 309 249 529 minecraft:light[level=14]
setblock 309 249 537 minecraft:light[level=14]
setblock 309 249 545 minecraft:light[level=14]
setblock 317 249 513 minecraft:light[level=14]
setblock 317 249 521 minecraft:light[level=14]
setblock 317 249 529 minecraft:light[level=14]
setblock 317 249 537 minecraft:light[level=14]
setblock 317 249 545 minecraft:light[level=14]
fill 284 250 515 284 250 516 minecraft:smooth_quartz
fill 285 250 513 288 250 513 minecraft:smooth_quartz
fill 285 250 517 286 250 517 minecraft:smooth_quartz
setblock 286 250 514 minecraft:smooth_quartz
setblock 286 250 516 minecraft:smooth_quartz
setblock 288 250 518 minecraft:smooth_quartz
setblock 289 250 514 minecraft:smooth_quartz
setblock 289 250 517 minecraft:smooth_quartz
fill 290 250 515 290 250 516 minecraft:smooth_quartz
fill 292 250 542 292 253 542 minecraft:smooth_quartz
fill 292 250 545 292 253 545 minecraft:smooth_quartz
fill 293 250 541 293 253 541 minecraft:smooth_quartz
fill 293 250 546 295 253 546 minecraft:smooth_quartz
fill 296 250 541 296 253 541 minecraft:smooth_quartz
fill 297 250 542 297 253 544 minecraft:smooth_quartz
fill 316 250 546 316 250 548 minecraft:smooth_quartz
fill 317 250 545 318 250 545 minecraft:smooth_quartz
fill 317 250 549 319 250 549 minecraft:smooth_quartz
fill 318 250 546 318 250 547 minecraft:smooth_quartz
fill 319 250 544 321 250 544 minecraft:smooth_quartz
fill 319 250 548 321 250 548 minecraft:smooth_quartz
fill 322 250 545 322 250 547 minecraft:smooth_quartz
fill 286 251 514 286 257 514 minecraft:quartz_block
fill 286 251 516 286 257 516 minecraft:quartz_block
fill 291 251 543 291 253 544 minecraft:smooth_quartz
fill 292 251 541 292 253 541 minecraft:smooth_quartz
fill 293 251 540 295 253 540 minecraft:smooth_quartz
fill 296 251 546 296 253 546 minecraft:smooth_quartz
fill 297 251 541 297 253 541 minecraft:smooth_quartz
fill 297 251 545 297 253 545 minecraft:smooth_quartz
fill 318 251 546 318 257 547 minecraft:quartz_block
fill 319 251 548 319 257 548 minecraft:quartz_block
fill 282 252 516 282 265 516 minecraft:light_blue_concrete
fill 282 252 517 282 252 518 minecraft:pearlescent_froglight
fill 282 252 519 282 265 519 minecraft:light_blue_concrete
fill 282 252 528 282 265 528 minecraft:light_blue_concrete
fill 282 252 529 282 252 530 minecraft:pearlescent_froglight
fill 282 252 531 282 265 531 minecraft:light_blue_concrete
fill 282 252 540 282 265 540 minecraft:light_blue_concrete
fill 282 252 541 282 252 542 minecraft:pearlescent_froglight
fill 282 252 543 282 265 543 minecraft:light_blue_concrete
fill 282 252 552 282 265 552 minecraft:light_blue_concrete
fill 283 252 552 284 252 552 minecraft:pearlescent_froglight
fill 285 252 552 285 265 552 minecraft:light_blue_concrete
fill 289 252 510 289 265 510 minecraft:light_blue_concrete
fill 290 252 510 291 252 510 minecraft:pearlescent_froglight
fill 291 252 541 291 253 542 minecraft:smooth_quartz
fill 291 252 545 291 253 545 minecraft:smooth_quartz
fill 292 252 510 292 265 510 minecraft:light_blue_concrete
fill 292 252 540 292 253 540 minecraft:smooth_quartz
fill 292 252 546 292 253 546 minecraft:smooth_quartz
fill 293 252 547 295 253 547 minecraft:smooth_quartz
fill 294 252 552 294 265 552 minecraft:light_blue_concrete
fill 295 252 552 296 252 552 minecraft:pearlescent_froglight
fill 296 252 540 296 253 540 minecraft:smooth_quartz
fill 297 252 546 297 253 546 minecraft:smooth_quartz
fill 297 252 552 297 265 552 minecraft:light_blue_concrete
fill 298 252 542 298 253 545 minecraft:smooth_quartz
fill 301 252 510 301 265 510 minecraft:light_blue_concrete
fill 302 252 510 303 252 510 minecraft:pearlescent_froglight
fill 304 252 510 304 265 510 minecraft:light_blue_concrete
fill 306 252 552 306 265 552 minecraft:light_blue_concrete
fill 307 252 552 308 252 552 minecraft:pearlescent_froglight
fill 309 252 552 309 265 552 minecraft:light_blue_concrete
fill 313 252 510 313 265 510 minecraft:light_blue_concrete
fill 314 252 510 315 252 510 minecraft:pearlescent_froglight
fill 316 252 510 316 265 510 minecraft:light_blue_concrete
fill 318 252 552 318 265 552 minecraft:light_blue_concrete
fill 319 252 552 320 252 552 minecraft:pearlescent_froglight
fill 321 252 552 321 265 552 minecraft:light_blue_concrete
fill 324 252 511 324 265 511 minecraft:light_blue_concrete
fill 324 252 512 324 252 513 minecraft:pearlescent_froglight
fill 324 252 514 324 265 514 minecraft:light_blue_concrete
fill 324 252 523 324 265 523 minecraft:light_blue_concrete
fill 324 252 524 324 252 525 minecraft:pearlescent_froglight
fill 324 252 526 324 265 526 minecraft:light_blue_concrete
fill 324 252 535 324 265 535 minecraft:light_blue_concrete
fill 324 252 536 324 252 537 minecraft:pearlescent_froglight
fill 324 252 538 324 265 538 minecraft:light_blue_concrete
fill 324 252 547 324 265 547 minecraft:light_blue_concrete
fill 324 252 548 324 252 549 minecraft:pearlescent_froglight
fill 324 252 550 324 265 550 minecraft:light_blue_concrete
fill 282 253 517 282 265 518 minecraft:light_blue_concrete
fill 282 253 529 282 265 530 minecraft:light_blue_concrete
fill 282 253 541 282 265 542 minecraft:light_blue_concrete
fill 283 253 552 284 265 552 minecraft:light_blue_concrete
fill 290 253 510 291 265 510 minecraft:light_blue_concrete
fill 290 253 543 290 253 544 minecraft:smooth_quartz
setblock 291 253 546 minecraft:smooth_quartz
setblock 292 253 547 minecraft:smooth_quartz
fill 293 253 539 295 253 539 minecraft:smooth_quartz
fill 295 253 552 296 265 552 minecraft:light_blue_concrete
setblock 296 253 547 minecraft:smooth_quartz
setblock 297 253 540 minecraft:smooth_quartz
setblock 298 253 541 minecraft:smooth_quartz
setblock 298 253 546 minecraft:smooth_quartz
fill 302 253 510 303 265 510 minecraft:light_blue_concrete
fill 307 253 552 308 265 552 minecraft:light_blue_concrete
fill 314 253 510 315 265 510 minecraft:light_blue_concrete
fill 319 253 552 320 265 552 minecraft:light_blue_concrete
fill 324 253 512 324 265 513 minecraft:light_blue_concrete
fill 324 253 524 324 265 525 minecraft:light_blue_concrete
fill 324 253 536 324 265 537 minecraft:light_blue_concrete
fill 324 253 548 324 265 549 minecraft:light_blue_concrete
fill 294 254 543 294 256 543 minecraft:gold_block
fill 298 254 544 299 255 544 minecraft:white_concrete
setblock 285 257 513 minecraft:light[level=14]
setblock 285 257 521 minecraft:light[level=14]
setblock 285 257 529 minecraft:light[level=14]
setblock 285 257 537 minecraft:light[level=14]
setblock 285 257 545 minecraft:light[level=14]
setblock 293 257 513 minecraft:light[level=14]
setblock 293 257 521 minecraft:light[level=14]
setblock 293 257 529 minecraft:light[level=14]
setblock 293 257 537 minecraft:light[level=14]
setblock 293 257 545 minecraft:light[level=14]
setblock 301 257 513 minecraft:light[level=14]
setblock 301 257 521 minecraft:light[level=14]
setblock 301 257 529 minecraft:light[level=14]
setblock 301 257 537 minecraft:light[level=14]
setblock 301 257 545 minecraft:light[level=14]
setblock 309 257 513 minecraft:light[level=14]
setblock 309 257 521 minecraft:light[level=14]
setblock 309 257 529 minecraft:light[level=14]
setblock 309 257 537 minecraft:light[level=14]
setblock 309 257 545 minecraft:light[level=14]
setblock 317 257 513 minecraft:light[level=14]
setblock 317 257 521 minecraft:light[level=14]
setblock 317 257 529 minecraft:light[level=14]
setblock 317 257 537 minecraft:light[level=14]
setblock 317 257 545 minecraft:light[level=14]
fill 284 258 515 284 258 516 minecraft:smooth_quartz
fill 285 258 513 288 258 513 minecraft:smooth_quartz
fill 285 258 517 286 258 517 minecraft:smooth_quartz
setblock 286 258 514 minecraft:smooth_quartz
setblock 286 258 516 minecraft:smooth_quartz
setblock 288 258 518 minecraft:smooth_quartz
setblock 289 258 514 minecraft:smooth_quartz
setblock 289 258 517 minecraft:smooth_quartz
fill 290 258 515 290 258 516 minecraft:smooth_quartz
setblock 294 258 543 minecraft:pearlescent_froglight
fill 316 258 546 316 258 548 minecraft:smooth_quartz
fill 317 258 545 318 258 545 minecraft:smooth_quartz
fill 317 258 549 319 258 549 minecraft:smooth_quartz
fill 318 258 546 318 258 547 minecraft:smooth_quartz
fill 319 258 544 321 258 544 minecraft:smooth_quartz
fill 319 258 548 321 258 548 minecraft:smooth_quartz
fill 322 258 545 322 258 547 minecraft:smooth_quartz
fill 286 259 514 286 265 514 minecraft:quartz_block
fill 286 259 516 286 265 516 minecraft:quartz_block
fill 318 259 546 318 265 547 minecraft:quartz_block
fill 319 259 548 319 265 548 minecraft:quartz_block
fill 284 260 520 284 265 522 minecraft:quartz_block
fill 284 260 532 284 265 534 minecraft:quartz_block
fill 284 260 544 284 265 546 minecraft:quartz_block
fill 290 260 550 292 265 550 minecraft:quartz_block
fill 294 260 512 296 265 512 minecraft:quartz_block
fill 302 260 550 304 265 550 minecraft:quartz_block
fill 306 260 512 308 265 512 minecraft:quartz_block
fill 314 260 550 316 265 550 minecraft:quartz_block
fill 318 260 512 320 265 512 minecraft:quartz_block
fill 322 260 520 322 265 522 minecraft:quartz_block
fill 322 260 532 322 265 534 minecraft:quartz_block
fill 322 260 544 322 265 546 minecraft:quartz_block
fill 291 264 538 292 265 539 minecraft:white_concrete
fill 283 265 514 283 265 519 minecraft:smooth_quartz
fill 283 265 526 283 265 531 minecraft:smooth_quartz
fill 283 265 538 283 265 543 minecraft:smooth_quartz
fill 283 265 550 283 265 551 minecraft:smooth_quartz
fill 284 265 551 287 265 551 minecraft:smooth_quartz
setblock 285 265 513 minecraft:light[level=14]
setblock 285 265 521 minecraft:light[level=14]
setblock 285 265 529 minecraft:light[level=14]
setblock 285 265 537 minecraft:light[level=14]
setblock 285 265 545 minecraft:light[level=14]
fill 287 265 511 292 265 511 minecraft:smooth_quartz
setblock 293 265 513 minecraft:light[level=14]
setblock 293 265 521 minecraft:light[level=14]
setblock 293 265 529 minecraft:light[level=14]
setblock 293 265 537 minecraft:light[level=14]
setblock 293 265 545 minecraft:light[level=14]
fill 294 265 551 299 265 551 minecraft:smooth_quartz
fill 299 265 511 304 265 511 minecraft:smooth_quartz
setblock 301 265 513 minecraft:light[level=14]
setblock 301 265 521 minecraft:light[level=14]
setblock 301 265 529 minecraft:light[level=14]
setblock 301 265 537 minecraft:light[level=14]
setblock 301 265 545 minecraft:light[level=14]
fill 306 265 551 311 265 551 minecraft:smooth_quartz
setblock 309 265 513 minecraft:light[level=14]
setblock 309 265 521 minecraft:light[level=14]
setblock 309 265 529 minecraft:light[level=14]
setblock 309 265 537 minecraft:light[level=14]
setblock 309 265 545 minecraft:light[level=14]
fill 311 265 511 316 265 511 minecraft:smooth_quartz
setblock 317 265 513 minecraft:light[level=14]
setblock 317 265 521 minecraft:light[level=14]
setblock 317 265 529 minecraft:light[level=14]
setblock 317 265 537 minecraft:light[level=14]
setblock 317 265 545 minecraft:light[level=14]
fill 318 265 551 323 265 551 minecraft:smooth_quartz
fill 323 265 511 323 265 516 minecraft:smooth_quartz
fill 323 265 523 323 265 528 minecraft:smooth_quartz
fill 323 265 535 323 265 540 minecraft:smooth_quartz
fill 323 265 547 323 265 550 minecraft:smooth_quartz
fill 282 266 516 282 271 519 minecraft:pearlescent_froglight
fill 282 266 528 282 271 531 minecraft:pearlescent_froglight
fill 282 266 540 282 271 543 minecraft:pearlescent_froglight
fill 282 266 552 285 271 552 minecraft:pearlescent_froglight
fill 284 266 515 284 266 516 minecraft:smooth_quartz
fill 285 266 513 288 266 513 minecraft:smooth_quartz
fill 285 266 517 286 266 517 minecraft:smooth_quartz
setblock 286 266 514 minecraft:smooth_quartz
setblock 286 266 516 minecraft:smooth_quartz
setblock 288 266 518 minecraft:smooth_quartz
fill 289 266 510 292 271 510 minecraft:pearlescent_froglight
setblock 289 266 514 minecraft:smooth_quartz
setblock 289 266 517 minecraft:smooth_quartz
fill 290 266 515 290 266 516 minecraft:smooth_quartz
fill 294 266 552 297 271 552 minecraft:pearlescent_froglight
fill 301 266 510 304 271 510 minecraft:pearlescent_froglight
fill 306 266 552 309 271 552 minecraft:pearlescent_froglight
fill 313 266 510 316 271 510 minecraft:pearlescent_froglight
fill 316 266 546 316 266 548 minecraft:smooth_quartz
fill 317 266 545 318 266 545 minecraft:smooth_quartz
fill 317 266 549 319 266 549 minecraft:smooth_quartz
fill 318 266 546 318 266 547 minecraft:smooth_quartz
fill 318 266 552 321 271 552 minecraft:pearlescent_froglight
fill 319 266 544 321 266 544 minecraft:smooth_quartz
fill 319 266 548 321 266 548 minecraft:smooth_quartz
fill 322 266 545 322 266 547 minecraft:smooth_quartz
fill 324 266 511 324 271 514 minecraft:pearlescent_froglight
fill 324 266 523 324 271 526 minecraft:pearlescent_froglight
fill 324 266 535 324 271 538 minecraft:pearlescent_froglight
fill 324 266 547 324 271 550 minecraft:pearlescent_froglight
fill 286 267 514 286 271 514 minecraft:quartz_block
fill 286 267 516 286 271 516 minecraft:quartz_block
fill 318 267 546 318 271 547 minecraft:quartz_block
fill 319 267 548 319 271 548 minecraft:quartz_block
fill 314 269 513 318 270 517 minecraft:smooth_quartz
fill 316 269 511 316 269 512 minecraft:smooth_quartz
fill 302 270 512 303 271 513 minecraft:white_concrete
fill 315 271 514 317 272 516 minecraft:quartz_block
fill 282 272 516 282 285 516 minecraft:light_blue_concrete
fill 282 272 517 282 272 518 minecraft:pearlescent_froglight
fill 282 272 519 282 285 519 minecraft:light_blue_concrete
fill 282 272 528 282 285 528 minecraft:light_blue_concrete
fill 282 272 529 282 272 530 minecraft:pearlescent_froglight
fill 282 272 531 282 285 531 minecraft:light_blue_concrete
fill 282 272 540 282 285 540 minecraft:light_blue_concrete
fill 282 272 541 282 272 542 minecraft:pearlescent_froglight
fill 282 272 543 282 285 543 minecraft:light_blue_concrete
fill 282 272 552 282 285 552 minecraft:light_blue_concrete
fill 283 272 552 284 272 552 minecraft:pearlescent_froglight
fill 285 272 517 286 273 517 minecraft:gold_block
fill 285 272 552 285 285 552 minecraft:light_blue_concrete
fill 286 272 513 286 273 514 minecraft:gold_block
fill 286 272 516 286 273 516 minecraft:gold_block
fill 287 272 513 287 273 513 minecraft:gold_block
fill 289 272 510 289 285 510 minecraft:light_blue_concrete
fill 289 272 514 289 273 514 minecraft:gold_block
fill 289 272 517 289 273 517 minecraft:gold_block
fill 290 272 510 291 272 510 minecraft:pearlescent_froglight
fill 290 272 515 290 273 516 minecraft:gold_block
fill 292 272 510 292 285 510 minecraft:light_blue_concrete
fill 294 272 552 294 285 552 minecraft:light_blue_concrete
fill 295 272 552 296 272 552 minecraft:pearlescent_froglight
fill 297 272 552 297 285 552 minecraft:light_blue_concrete
fill 301 272 510 301 285 510 minecraft:light_blue_concrete
fill 302 272 510 303 272 510 minecraft:pearlescent_froglight
fill 304 272 510 304 285 510 minecraft:light_blue_concrete
fill 306 272 552 306 285 552 minecraft:light_blue_concrete
fill 307 272 552 308 272 552 minecraft:pearlescent_froglight
fill 309 272 552 309 285 552 minecraft:light_blue_concrete
fill 313 272 510 313 285 510 minecraft:light_blue_concrete
fill 314 272 510 315 272 510 minecraft:pearlescent_froglight
fill 316 272 510 316 285 510 minecraft:light_blue_concrete
fill 316 272 546 316 273 548 minecraft:gold_block
fill 317 272 545 318 273 545 minecraft:gold_block
fill 317 272 549 319 273 549 minecraft:gold_block
fill 318 272 546 318 273 547 minecraft:gold_block
fill 318 272 552 318 285 552 minecraft:light_blue_concrete
fill 319 272 544 320 273 544 minecraft:gold_block
fill 319 272 548 321 273 548 minecraft:gold_block
fill 319 272 552 320 272 552 minecraft:pearlescent_froglight
fill 321 272 552 321 285 552 minecraft:light_blue_concrete
fill 322 272 546 322 273 547 minecraft:gold_block
fill 324 272 511 324 285 511 minecraft:light_blue_concrete
fill 324 272 512 324 272 513 minecraft:pearlescent_froglight
fill 324 272 514 324 285 514 minecraft:light_blue_concrete
fill 324 272 523 324 285 523 minecraft:light_blue_concrete
fill 324 272 524 324 272 525 minecraft:pearlescent_froglight
fill 324 272 526 324 285 526 minecraft:light_blue_concrete
fill 324 272 535 324 285 535 minecraft:light_blue_concrete
fill 324 272 536 324 272 537 minecraft:pearlescent_froglight
fill 324 272 538 324 285 538 minecraft:light_blue_concrete
fill 324 272 547 324 285 547 minecraft:light_blue_concrete
fill 324 272 548 324 272 549 minecraft:pearlescent_froglight
fill 324 272 550 324 285 550 minecraft:light_blue_concrete
fill 282 273 517 282 285 518 minecraft:light_blue_concrete
fill 282 273 529 282 285 530 minecraft:light_blue_concrete
fill 282 273 541 282 285 542 minecraft:light_blue_concrete
fill 283 273 552 284 285 552 minecraft:light_blue_concrete
setblock 285 273 513 minecraft:light[level=14]
setblock 285 273 521 minecraft:light[level=14]
setblock 285 273 529 minecraft:light[level=14]
setblock 285 273 537 minecraft:light[level=14]
setblock 285 273 545 minecraft:light[level=14]
fill 290 273 510 291 285 510 minecraft:light_blue_concrete
setblock 293 273 513 minecraft:light[level=14]
setblock 293 273 521 minecraft:light[level=14]
setblock 293 273 529 minecraft:light[level=14]
setblock 293 273 537 minecraft:light[level=14]
setblock 293 273 545 minecraft:light[level=14]
fill 295 273 552 296 285 552 minecraft:light_blue_concrete
setblock 301 273 513 minecraft:light[level=14]
setblock 301 273 521 minecraft:light[level=14]
setblock 301 273 529 minecraft:light[level=14]
setblock 301 273 537 minecraft:light[level=14]
setblock 301 273 545 minecraft:light[level=14]
fill 302 273 510 303 285 510 minecraft:light_blue_concrete
fill 307 273 552 308 285 552 minecraft:light_blue_concrete
setblock 309 273 513 minecraft:light[level=14]
setblock 309 273 521 minecraft:light[level=14]
setblock 309 273 529 minecraft:light[level=14]
setblock 309 273 537 minecraft:light[level=14]
setblock 309 273 545 minecraft:light[level=14]
fill 314 273 510 315 285 510 minecraft:light_blue_concrete
fill 315 273 515 317 273 515 minecraft:quartz_block
setblock 316 273 514 minecraft:quartz_block
setblock 316 273 516 minecraft:quartz_block
setblock 317 273 513 minecraft:light[level=14]
setblock 317 273 521 minecraft:light[level=14]
setblock 317 273 529 minecraft:light[level=14]
setblock 317 273 537 minecraft:light[level=14]
fill 319 273 552 320 285 552 minecraft:light_blue_concrete
fill 324 273 512 324 285 513 minecraft:light_blue_concrete
fill 324 273 524 324 285 525 minecraft:light_blue_concrete
fill 324 273 536 324 285 537 minecraft:light_blue_concrete
fill 324 273 548 324 285 549 minecraft:light_blue_concrete
fill 283 279 511 286 280 513 minecraft:light_blue_wool
fill 283 279 514 283 280 521 minecraft:white_wool
fill 283 279 522 286 280 528 minecraft:light_blue_wool
fill 283 279 529 283 280 537 minecraft:white_wool
fill 283 279 538 286 280 544 minecraft:light_blue_wool
fill 283 279 545 283 280 551 minecraft:white_wool
fill 284 279 514 323 280 520 minecraft:white_wool
fill 284 279 521 285 280 521 minecraft:light_blue_wool
fill 284 279 529 286 280 529 minecraft:light_blue_wool
fill 284 279 530 301 279 536 minecraft:white_wool
fill 284 279 537 285 280 537 minecraft:light_blue_wool
fill 284 279 545 285 280 545 minecraft:light_blue_wool
fill 284 279 546 323 280 551 minecraft:white_wool
fill 286 279 521 296 280 521 minecraft:white_wool
fill 286 279 537 295 280 537 minecraft:white_wool
fill 286 279 545 296 280 545 minecraft:white_wool
fill 287 279 511 287 280 512 minecraft:light_blue_wool
fill 287 279 513 295 280 513 minecraft:white_wool
fill 287 279 522 295 280 522 minecraft:white_wool
fill 287 279 523 287 280 528 minecraft:light_blue_wool
fill 287 279 529 295 280 529 minecraft:white_wool
fill 287 279 538 294 280 538 minecraft:white_wool
fill 287 279 539 287 280 543 minecraft:light_blue_wool
fill 287 279 544 295 280 544 minecraft:white_wool
fill 288 279 511 294 280 512 minecraft:white_wool
fill 288 279 523 293 280 524 minecraft:white_wool
fill 288 279 525 288 280 526 minecraft:light_blue_wool
fill 288 279 527 294 280 528 minecraft:white_wool
fill 288 279 539 294 280 539 minecraft:white_wool
fill 288 279 540 288 280 541 minecraft:light_blue_wool
fill 288 279 542 293 280 543 minecraft:white_wool
fill 289 279 525 293 280 526 minecraft:white_wool
fill 289 279 540 293 280 541 minecraft:white_wool
fill 294 279 523 294 280 523 minecraft:white_wool
fill 294 279 524 300 280 526 minecraft:light_blue_wool
fill 294 279 540 300 280 542 minecraft:light_blue_wool
fill 294 279 543 294 280 543 minecraft:white_wool
fill 295 279 511 299 280 512 minecraft:light_blue_wool
fill 295 279 523 300 280 523 minecraft:light_blue_wool
fill 295 279 527 299 280 528 minecraft:light_blue_wool
fill 295 279 538 299 280 539 minecraft:light_blue_wool
fill 295 279 543 300 280 543 minecraft:light_blue_wool
fill 296 279 513 298 280 513 minecraft:light_blue_wool
fill 296 279 522 299 280 522 minecraft:light_blue_wool
fill 296 279 529 298 280 529 minecraft:light_blue_wool
fill 296 279 537 298 280 537 minecraft:light_blue_wool
fill 296 279 544 299 280 544 minecraft:light_blue_wool
fill 297 279 521 298 280 521 minecraft:light_blue_wool
fill 297 279 545 298 280 545 minecraft:light_blue_wool
fill 299 279 513 307 280 513 minecraft:white_wool
fill 299 279 521 308 280 521 minecraft:white_wool
fill 299 279 529 308 280 529 minecraft:white_wool
fill 299 279 537 308 280 537 minecraft:white_wool
fill 299 279 545 308 280 545 minecraft:white_wool
fill 300 279 511 300 280 511 minecraft:light_blue_wool
fill 300 279 512 307 280 512 minecraft:white_wool
fill 300 279 522 307 280 522 minecraft:white_wool
fill 300 279 527 300 280 527 minecraft:light_blue_wool
fill 300 279 528 307 280 528 minecraft:white_wool
fill 300 279 538 307 280 538 minecraft:white_wool
fill 300 279 539 300 280 539 minecraft:light_blue_wool
fill 300 279 544 307 280 544 minecraft:white_wool
fill 301 279 511 306 280 511 minecraft:white_wool
fill 301 279 523 306 280 527 minecraft:white_wool
fill 301 279 539 306 280 543 minecraft:white_wool
fill 302 279 530 302 279 532 minecraft:white_wool
fill 302 279 534 302 279 536 minecraft:white_wool
fill 303 279 530 303 279 531 minecraft:white_wool
fill 303 279 535 303 279 536 minecraft:white_wool
fill 304 279 530 323 279 530 minecraft:white_wool
fill 304 279 536 323 279 536 minecraft:white_wool
fill 305 279 531 323 279 531 minecraft:white_wool
fill 305 279 535 323 279 535 minecraft:white_wool
fill 306 279 532 323 279 532 minecraft:white_wool
fill 306 279 534 323 279 534 minecraft:white_wool
fill 307 279 511 312 280 511 minecraft:light_blue_wool
fill 307 279 523 312 280 527 minecraft:light_blue_wool
fill 307 279 533 323 279 533 minecraft:white_wool
fill 307 279 539 312 280 543 minecraft:light_blue_wool
fill 308 279 512 311 280 513 minecraft:light_blue_wool
fill 308 279 522 311 280 522 minecraft:light_blue_wool
fill 308 279 528 312 280 528 minecraft:light_blue_wool
fill 308 279 538 312 280 538 minecraft:light_blue_wool
fill 308 279 544 311 280 544 minecraft:light_blue_wool
fill 309 279 521 310 280 521 minecraft:light_blue_wool
fill 309 279 529 311 280 529 minecraft:light_blue_wool
fill 309 279 537 311 280 537 minecraft:light_blue_wool
fill 309 279 545 310 280 545 minecraft:light_blue_wool
fill 311 279 521 321 280 521 minecraft:white_wool
fill 311 279 545 321 280 545 minecraft:white_wool
fill 312 279 512 312 280 512 minecraft:light_blue_wool
fill 312 279 513 320 280 513 minecraft:white_wool
fill 312 279 522 320 280 522 minecraft:white_wool
fill 312 279 529 320 280 529 minecraft:white_wool
fill 312 279 537 321 280 537 minecraft:white_wool
fill 312 279 544 320 280 544 minecraft:white_wool
fill 313 279 511 319 280 512 minecraft:white_wool
fill 313 279 523 319 280 523 minecraft:white_wool
fill 313 279 524 313 280 526 minecraft:light_blue_wool
fill 313 279 527 319 280 528 minecraft:white_wool
fill 313 279 538 319 280 539 minecraft:white_wool
fill 313 279 540 313 280 542 minecraft:light_blue_wool
fill 313 279 543 319 280 543 minecraft:white_wool
fill 314 279 524 318 280 526 minecraft:white_wool
fill 314 279 540 318 280 542 minecraft:white_wool
fill 319 279 524 319 280 524 minecraft:white_wool
fill 319 279 525 323 280 526 minecraft:light_blue_wool
fill 319 279 540 323 280 542 minecraft:light_blue_wool
fill 320 279 511 323 280 512 minecraft:light_blue_wool
fill 320 279 523 323 280 524 minecraft:light_blue_wool
fill 320 279 527 323 280 528 minecraft:light_blue_wool
fill 320 279 538 320 280 538 minecraft:white_wool
fill 320 279 539 323 280 539 minecraft:light_blue_wool
fill 320 279 543 323 280 543 minecraft:light_blue_wool
fill 321 279 513 323 280 513 minecraft:light_blue_wool
fill 321 279 522 323 280 522 minecraft:light_blue_wool
fill 321 279 529 323 280 529 minecraft:light_blue_wool
fill 321 279 538 323 280 538 minecraft:light_blue_wool
fill 321 279 544 323 280 544 minecraft:light_blue_wool
fill 322 279 521 323 280 521 minecraft:light_blue_wool
fill 322 279 537 323 280 537 minecraft:light_blue_wool
fill 322 279 545 323 280 545 minecraft:light_blue_wool
fill 284 280 530 300 280 536 minecraft:white_wool
fill 301 280 530 301 280 531 minecraft:white_wool
fill 301 280 532 301 280 534 minecraft:pearlescent_froglight
fill 301 280 535 301 280 536 minecraft:white_wool
setblock 302 280 530 minecraft:white_wool
fill 302 280 531 302 280 532 minecraft:pearlescent_froglight
fill 302 280 534 302 280 535 minecraft:pearlescent_froglight
setblock 302 280 536 minecraft:white_wool
fill 303 280 530 303 280 531 minecraft:pearlescent_froglight
fill 303 280 535 303 280 536 minecraft:pearlescent_froglight
fill 304 280 530 305 280 530 minecraft:pearlescent_froglight
fill 304 280 536 305 280 536 minecraft:pearlescent_froglight
fill 305 280 531 306 280 531 minecraft:pearlescent_froglight
fill 305 280 535 306 280 535 minecraft:pearlescent_froglight
fill 306 280 530 323 280 530 minecraft:white_wool
fill 306 280 532 307 280 532 minecraft:pearlescent_froglight
fill 306 280 534 307 280 534 minecraft:pearlescent_froglight
fill 306 280 536 323 280 536 minecraft:white_wool
fill 307 280 531 323 280 531 minecraft:white_wool
setblock 307 280 533 minecraft:pearlescent_froglight
fill 307 280 535 323 280 535 minecraft:white_wool
fill 308 280 532 323 280 534 minecraft:white_wool
setblock 285 281 513 minecraft:light[level=14]
setblock 285 281 521 minecraft:light[level=14]
setblock 285 281 529 minecraft:light[level=14]
setblock 285 281 537 minecraft:light[level=14]
setblock 285 281 545 minecraft:light[level=14]
setblock 293 281 513 minecraft:light[level=14]
setblock 293 281 521 minecraft:light[level=14]
setblock 293 281 529 minecraft:light[level=14]
setblock 293 281 537 minecraft:light[level=14]
setblock 293 281 545 minecraft:light[level=14]
setblock 301 281 513 minecraft:light[level=14]
setblock 301 281 521 minecraft:light[level=14]
setblock 301 281 529 minecraft:light[level=14]
setblock 301 281 537 minecraft:light[level=14]
setblock 301 281 545 minecraft:light[level=14]
setblock 309 281 513 minecraft:light[level=14]
setblock 309 281 521 minecraft:light[level=14]
setblock 309 281 529 minecraft:light[level=14]
setblock 309 281 537 minecraft:light[level=14]
setblock 309 281 545 minecraft:light[level=14]
setblock 317 281 513 minecraft:light[level=14]
setblock 317 281 521 minecraft:light[level=14]
setblock 317 281 529 minecraft:light[level=14]
setblock 317 281 537 minecraft:light[level=14]
setblock 317 281 545 minecraft:light[level=14]
fill 283 284 511 285 300 511 minecraft:quartz_block
fill 283 284 521 283 300 523 minecraft:quartz_block
fill 283 284 533 283 300 535 minecraft:quartz_block
fill 283 284 545 283 300 547 minecraft:quartz_block
fill 284 284 520 284 285 522 minecraft:quartz_block
fill 284 284 532 284 285 534 minecraft:quartz_block
fill 284 284 544 284 285 546 minecraft:quartz_block
fill 289 284 551 291 300 551 minecraft:quartz_block
fill 290 284 550 292 285 550 minecraft:quartz_block
fill 294 284 512 296 285 512 minecraft:quartz_block
fill 295 284 511 297 300 511 minecraft:quartz_block
fill 301 284 551 303 300 551 minecraft:quartz_block
fill 302 284 550 304 285 550 minecraft:quartz_block
fill 306 284 512 308 285 512 minecraft:quartz_block
fill 307 284 511 309 300 511 minecraft:quartz_block
fill 313 284 551 315 300 551 minecraft:quartz_block
fill 314 284 550 316 285 550 minecraft:quartz_block
fill 318 284 512 320 285 512 minecraft:quartz_block
fill 319 284 511 321 300 511 minecraft:quartz_block
fill 322 284 520 322 285 522 minecraft:quartz_block
fill 322 284 532 322 285 534 minecraft:quartz_block
fill 322 284 544 322 285 546 minecraft:quartz_block
fill 323 284 519 323 300 521 minecraft:quartz_block
fill 323 284 531 323 300 533 minecraft:quartz_block
fill 323 284 543 323 300 545 minecraft:quartz_block
fill 283 285 514 283 285 519 minecraft:smooth_quartz
fill 283 285 526 283 285 531 minecraft:smooth_quartz
fill 283 285 538 283 285 543 minecraft:smooth_quartz
fill 283 285 550 283 285 551 minecraft:smooth_quartz
fill 284 285 551 287 285 551 minecraft:smooth_quartz
fill 287 285 511 292 285 511 minecraft:smooth_quartz
fill 294 285 551 299 285 551 minecraft:smooth_quartz
fill 299 285 511 304 285 511 minecraft:smooth_quartz
fill 306 285 551 311 285 551 minecraft:smooth_quartz
fill 311 285 511 316 285 511 minecraft:smooth_quartz
fill 318 285 551 323 285 551 minecraft:smooth_quartz
fill 323 285 511 323 285 516 minecraft:smooth_quartz
fill 323 285 523 323 285 528 minecraft:smooth_quartz
fill 323 285 535 323 285 540 minecraft:smooth_quartz
fill 323 285 547 323 285 550 minecraft:smooth_quartz
fill 282 286 516 282 291 519 minecraft:pearlescent_froglight
fill 282 286 528 282 291 531 minecraft:pearlescent_froglight
fill 282 286 540 282 291 543 minecraft:pearlescent_froglight
fill 282 286 552 285 291 552 minecraft:pearlescent_froglight
fill 289 286 510 292 291 510 minecraft:pearlescent_froglight
fill 294 286 552 297 291 552 minecraft:pearlescent_froglight
fill 301 286 510 304 291 510 minecraft:pearlescent_froglight
fill 306 286 552 309 291 552 minecraft:pearlescent_froglight
fill 313 286 510 316 291 510 minecraft:pearlescent_froglight
fill 318 286 552 321 291 552 minecraft:pearlescent_froglight
fill 324 286 511 324 291 514 minecraft:pearlescent_froglight
fill 324 286 523 324 291 526 minecraft:pearlescent_froglight
fill 324 286 535 324 291 538 minecraft:pearlescent_froglight
fill 324 286 547 324 291 550 minecraft:pearlescent_froglight
fill 304 287 519 304 288 519 minecraft:light_blue_stained_glass
setblock 285 289 513 minecraft:light[level=14]
setblock 285 289 521 minecraft:light[level=14]
setblock 285 289 529 minecraft:light[level=14]
setblock 285 289 537 minecraft:light[level=14]
setblock 285 289 545 minecraft:light[level=14]
setblock 293 289 513 minecraft:light[level=14]
setblock 293 289 521 minecraft:light[level=14]
setblock 293 289 529 minecraft:light[level=14]
setblock 293 289 537 minecraft:light[level=14]
setblock 293 289 545 minecraft:light[level=14]
setblock 301 289 513 minecraft:light[level=14]
setblock 301 289 521 minecraft:light[level=14]
setblock 301 289 529 minecraft:light[level=14]
setblock 301 289 537 minecraft:light[level=14]
setblock 301 289 545 minecraft:light[level=14]
fill 304 289 519 304 299 519 minecraft:smooth_quartz
setblock 309 289 513 minecraft:light[level=14]
setblock 309 289 521 minecraft:light[level=14]
setblock 309 289 529 minecraft:light[level=14]
setblock 309 289 537 minecraft:light[level=14]
setblock 309 289 545 minecraft:light[level=14]
setblock 317 289 513 minecraft:light[level=14]
setblock 317 289 521 minecraft:light[level=14]
setblock 317 289 529 minecraft:light[level=14]
setblock 317 289 537 minecraft:light[level=14]
setblock 317 289 545 minecraft:light[level=14]
fill 304 290 520 304 299 520 minecraft:smooth_quartz
fill 305 290 519 305 299 519 minecraft:smooth_quartz
fill 303 291 519 303 299 520 minecraft:smooth_quartz
fill 304 291 518 304 299 518 minecraft:smooth_quartz
fill 305 291 520 305 299 520 minecraft:smooth_quartz
fill 321 291 529 322 292 529 minecraft:white_wool
fill 282 292 516 282 307 516 minecraft:light_blue_concrete
fill 282 292 517 282 292 518 minecraft:pearlescent_froglight
fill 282 292 519 282 307 519 minecraft:light_blue_concrete
fill 282 292 528 282 307 528 minecraft:light_blue_concrete
fill 282 292 529 282 292 530 minecraft:pearlescent_froglight
fill 282 292 531 282 307 531 minecraft:light_blue_concrete
fill 282 292 540 282 307 540 minecraft:light_blue_concrete
fill 282 292 541 282 292 542 minecraft:pearlescent_froglight
fill 282 292 543 282 307 543 minecraft:light_blue_concrete
fill 282 292 552 282 307 552 minecraft:light_blue_concrete
fill 283 292 552 284 292 552 minecraft:pearlescent_froglight
fill 285 292 552 285 307 552 minecraft:light_blue_concrete
fill 289 292 510 289 307 510 minecraft:light_blue_concrete
fill 290 292 510 291 292 510 minecraft:pearlescent_froglight
fill 292 292 510 292 307 510 minecraft:light_blue_concrete
fill 294 292 552 294 307 552 minecraft:light_blue_concrete
fill 295 292 552 296 292 552 minecraft:pearlescent_froglight
fill 297 292 552 297 307 552 minecraft:light_blue_concrete
fill 301 292 510 301 307 510 minecraft:light_blue_concrete
fill 302 292 510 303 292 510 minecraft:pearlescent_froglight
fill 303 292 518 303 299 518 minecraft:smooth_quartz
fill 304 292 510 304 307 510 minecraft:light_blue_concrete
fill 304 292 521 305 299 521 minecraft:smooth_quartz
fill 305 292 518 305 299 518 minecraft:smooth_quartz
fill 306 292 519 306 299 519 minecraft:smooth_quartz
fill 306 292 552 306 307 552 minecraft:light_blue_concrete
fill 307 292 552 308 292 552 minecraft:pearlescent_froglight
fill 309 292 552 309 307 552 minecraft:light_blue_concrete
fill 313 292 510 313 307 510 minecraft:light_blue_concrete
fill 314 292 510 315 292 510 minecraft:pearlescent_froglight
fill 316 292 510 316 307 510 minecraft:light_blue_concrete
fill 318 292 552 318 307 552 minecraft:light_blue_concrete
fill 319 292 552 320 292 552 minecraft:pearlescent_froglight
fill 321 292 552 321 307 552 minecraft:light_blue_concrete
fill 324 292 511 324 307 511 minecraft:light_blue_concrete
fill 324 292 512 324 292 513 minecraft:pearlescent_froglight
fill 324 292 514 324 307 514 minecraft:light_blue_concrete
fill 324 292 523 324 307 523 minecraft:light_blue_concrete
fill 324 292 524 324 292 525 minecraft:pearlescent_froglight
fill 324 292 526 324 307 526 minecraft:light_blue_concrete
fill 324 292 535 324 307 535 minecraft:light_blue_concrete
fill 324 292 536 324 292 537 minecraft:pearlescent_froglight
fill 324 292 538 324 307 538 minecraft:light_blue_concrete
fill 324 292 547 324 307 547 minecraft:light_blue_concrete
fill 324 292 548 324 292 549 minecraft:pearlescent_froglight
fill 324 292 550 324 307 550 minecraft:light_blue_concrete
fill 282 293 517 282 307 518 minecraft:light_blue_concrete
fill 282 293 529 282 307 530 minecraft:light_blue_concrete
fill 282 293 541 282 307 542 minecraft:light_blue_concrete
fill 283 293 536 283 294 538 minecraft:quartz_block
fill 283 293 552 284 307 552 minecraft:light_blue_concrete
fill 290 293 510 291 307 510 minecraft:light_blue_concrete
fill 295 293 552 296 307 552 minecraft:light_blue_concrete
fill 302 293 510 303 307 510 minecraft:light_blue_concrete
fill 302 293 519 302 299 520 minecraft:smooth_quartz
fill 303 293 521 303 299 521 minecraft:smooth_quartz
fill 306 293 518 306 299 518 minecraft:smooth_quartz
fill 306 293 520 306 299 520 minecraft:smooth_quartz
fill 307 293 552 308 307 552 minecraft:light_blue_concrete
fill 314 293 510 315 307 510 minecraft:light_blue_concrete
fill 319 293 552 320 307 552 minecraft:light_blue_concrete
fill 322 293 536 323 294 538 minecraft:quartz_block
fill 324 293 512 324 307 513 minecraft:light_blue_concrete
fill 324 293 524 324 307 525 minecraft:light_blue_concrete
fill 324 293 536 324 307 537 minecraft:light_blue_concrete
fill 324 293 548 324 307 549 minecraft:light_blue_concrete
fill 284 294 536 284 295 538 minecraft:quartz_block
fill 285 294 537 285 297 537 minecraft:quartz_block
fill 302 294 518 302 299 518 minecraft:smooth_quartz
fill 302 294 521 302 299 521 minecraft:smooth_quartz
fill 303 294 517 305 299 517 minecraft:smooth_quartz
fill 304 294 522 305 299 522 minecraft:smooth_quartz
fill 306 294 521 306 299 521 minecraft:smooth_quartz
fill 307 294 519 307 299 519 minecraft:smooth_quartz
fill 320 294 537 321 296 537 minecraft:quartz_block
fill 321 294 536 321 295 536 minecraft:quartz_block
fill 321 294 538 321 295 538 minecraft:quartz_block
setblock 283 295 537 minecraft:quartz_block
fill 285 295 536 285 296 536 minecraft:quartz_block
fill 285 295 538 285 296 538 minecraft:quartz_block
fill 286 295 537 286 297 537 minecraft:quartz_block
fill 301 295 519 301 299 520 minecraft:smooth_quartz
fill 302 295 517 302 299 517 minecraft:smooth_quartz
fill 303 295 522 303 299 522 minecraft:smooth_quartz
fill 306 295 517 306 299 517 minecraft:smooth_quartz
fill 306 295 522 306 299 522 minecraft:smooth_quartz
fill 307 295 518 307 299 518 minecraft:smooth_quartz
fill 307 295 520 307 299 521 minecraft:smooth_quartz
fill 319 295 537 319 297 537 minecraft:quartz_block
fill 320 295 536 320 296 536 minecraft:quartz_block
fill 320 295 538 320 296 538 minecraft:quartz_block
setblock 322 295 537 minecraft:quartz_block
setblock 323 295 537 minecraft:gold_block
setblock 283 296 537 minecraft:gold_block
setblock 284 296 537 minecraft:quartz_block
fill 286 296 536 287 297 536 minecraft:quartz_block
fill 286 296 538 287 297 538 minecraft:quartz_block
fill 287 296 537 287 298 537 minecraft:quartz_block
fill 301 296 518 301 299 518 minecraft:smooth_quartz
fill 301 296 521 301 299 521 minecraft:smooth_quartz
fill 302 296 522 302 299 522 minecraft:smooth_quartz
fill 303 296 516 306 299 516 minecraft:smooth_quartz
fill 303 296 523 305 299 523 minecraft:smooth_quartz
fill 307 296 517 307 299 517 minecraft:smooth_quartz
fill 308 296 519 308 299 519 minecraft:smooth_quartz
fill 318 296 536 318 297 538 minecraft:quartz_block
fill 319 296 536 319 297 536 minecraft:quartz_block
fill 319 296 538 319 297 538 minecraft:quartz_block
setblock 322 296 537 minecraft:gold_block
setblock 284 297 537 minecraft:gold_block
setblock 285 297 513 minecraft:light[level=14]
setblock 285 297 521 minecraft:light[level=14]
setblock 285 297 529 minecraft:light[level=14]
setblock 285 297 545 minecraft:light[level=14]
fill 288 297 536 288 298 538 minecraft:quartz_block
fill 289 297 537 289 299 537 minecraft:quartz_block
setblock 293 297 513 minecraft:light[level=14]
setblock 293 297 521 minecraft:light[level=14]
setblock 293 297 529 minecraft:light[level=14]
setblock 293 297 537 minecraft:light[level=14]
setblock 293 297 545 minecraft:light[level=14]
fill 300 297 519 300 299 520 minecraft:smooth_quartz
setblock 301 297 513 minecraft:light[level=14]
fill 301 297 517 301 299 517 minecraft:smooth_quartz
fill 301 297 522 301 299 522 minecraft:smooth_quartz
setblock 301 297 529 minecraft:light[level=14]
setblock 301 297 537 minecraft:light[level=14]
setblock 301 297 545 minecraft:light[level=14]
fill 302 297 516 302 299 516 minecraft:smooth_quartz
fill 302 297 523 302 299 523 minecraft:smooth_quartz
fill 306 297 523 306 299 523 minecraft:smooth_quartz
fill 307 297 522 307 299 522 minecraft:smooth_quartz
fill 308 297 518 308 299 518 minecraft:smooth_quartz
fill 308 297 520 308 299 521 minecraft:smooth_quartz
setblock 309 297 513 minecraft:light[level=14]
setblock 309 297 521 minecraft:light[level=14]
setblock 309 297 529 minecraft:light[level=14]
setblock 309 297 537 minecraft:light[level=14]
setblock 309 297 545 minecraft:light[level=14]
fill 316 297 537 317 299 537 minecraft:quartz_block
setblock 317 297 513 minecraft:light[level=14]
setblock 317 297 521 minecraft:light[level=14]
setblock 317 297 529 minecraft:light[level=14]
fill 317 297 536 317 298 536 minecraft:quartz_block
fill 317 297 538 317 298 538 minecraft:quartz_block
setblock 317 297 545 minecraft:light[level=14]
setblock 320 297 537 minecraft:quartz_block
setblock 321 297 537 minecraft:gold_block
setblock 286 298 537 minecraft:gold_block
fill 289 298 536 289 299 536 minecraft:quartz_block
fill 289 298 538 289 299 538 minecraft:quartz_block
fill 290 298 537 290 300 537 minecraft:quartz_block
fill 300 298 517 300 299 518 minecraft:smooth_quartz
fill 300 298 521 300 299 521 minecraft:smooth_quartz
fill 301 298 516 301 299 516 minecraft:smooth_quartz
fill 303 298 515 306 299 515 minecraft:smooth_quartz
fill 303 298 524 305 299 524 minecraft:smooth_quartz
fill 307 298 516 307 299 516 minecraft:smooth_quartz
fill 307 298 523 307 299 523 minecraft:smooth_quartz
fill 308 298 517 308 299 517 minecraft:smooth_quartz
fill 308 298 522 308 299 522 minecraft:smooth_quartz
fill 309 298 519 309 299 519 minecraft:smooth_quartz
fill 315 298 537 315 300 537 minecraft:quartz_block
fill 316 298 536 316 299 536 minecraft:quartz_block
fill 316 298 538 316 299 538 minecraft:quartz_block
setblock 318 298 537 minecraft:quartz_block
setblock 319 298 537 minecraft:gold_block
setblock 287 299 537 minecraft:gold_block
setblock 288 299 537 minecraft:quartz_block
fill 290 299 536 291 299 536 minecraft:quartz_block
fill 290 299 538 291 299 538 minecraft:quartz_block
fill 291 299 537 292 300 537 minecraft:quartz_block
fill 299 299 519 299 299 520 minecraft:smooth_quartz
setblock 300 299 522 minecraft:smooth_quartz
setblock 301 299 523 minecraft:smooth_quartz
setblock 302 299 515 minecraft:smooth_quartz
setblock 302 299 524 minecraft:smooth_quartz
setblock 306 299 524 minecraft:smooth_quartz
setblock 307 299 515 minecraft:smooth_quartz
setblock 308 299 516 minecraft:smooth_quartz
setblock 308 299 523 minecraft:smooth_quartz
setblock 309 299 518 minecraft:smooth_quartz
fill 309 299 520 309 299 521 minecraft:smooth_quartz
fill 313 299 537 314 300 537 minecraft:quartz_block
fill 314 299 536 315 299 536 minecraft:quartz_block
fill 314 299 538 315 299 538 minecraft:quartz_block
setblock 318 299 537 minecraft:gold_block
fill 284 300 520 284 300 522 minecraft:quartz_block
fill 284 300 532 284 300 534 minecraft:quartz_block
fill 284 300 544 284 300 546 minecraft:quartz_block
setblock 289 300 537 minecraft:gold_block
fill 290 300 550 292 300 550 minecraft:quartz_block
fill 291 300 536 293 300 536 minecraft:quartz_block
fill 291 300 538 293 300 538 minecraft:quartz_block
fill 293 300 537 294 300 537 minecraft:quartz_block
fill 294 300 512 296 300 512 minecraft:quartz_block
fill 302 300 550 304 300 550 minecraft:quartz_block
setblock 304 300 519 minecraft:gold_block
fill 306 300 512 308 300 512 minecraft:quartz_block
fill 311 300 537 312 300 537 minecraft:quartz_block
fill 312 300 536 314 300 536 minecraft:quartz_block
fill 312 300 538 314 300 538 minecraft:quartz_block
fill 314 300 550 316 300 550 minecraft:quartz_block
setblock 316 300 537 minecraft:gold_block
fill 318 300 512 320 300 512 minecraft:quartz_block
fill 322 300 520 322 300 522 minecraft:quartz_block
fill 322 300 532 322 300 534 minecraft:quartz_block
fill 322 300 544 322 300 546 minecraft:quartz_block
