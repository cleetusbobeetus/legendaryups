setblock 171 24 362 minecraft:dark_prismarine
fill 171 24 363 171 27 363 minecraft:blue_terracotta
fill 172 24 362 172 27 362 minecraft:blue_terracotta
setblock 175 24 323 minecraft:dark_prismarine
setblock 175 24 324 minecraft:blue_terracotta
setblock 175 24 363 minecraft:dark_prismarine
setblock 176 24 323 minecraft:blue_terracotta
setblock 176 24 362 minecraft:dark_prismarine
fill 176 24 363 176 27 363 minecraft:blue_terracotta
setblock 177 24 361 minecraft:dark_prismarine
fill 177 24 362 177 27 362 minecraft:blue_terracotta
setblock 178 24 360 minecraft:dark_prismarine
fill 178 24 361 178 27 361 minecraft:blue_terracotta
setblock 179 24 359 minecraft:dark_prismarine
fill 179 24 360 179 26 360 minecraft:blue_terracotta
setblock 180 24 323 minecraft:dark_prismarine
setblock 180 24 358 minecraft:dark_prismarine
fill 180 24 359 180 27 359 minecraft:blue_terracotta
setblock 180 24 363 minecraft:dark_prismarine
fill 181 24 323 181 27 323 minecraft:blue_terracotta
setblock 181 24 357 minecraft:dark_prismarine
fill 181 24 358 181 27 358 minecraft:blue_terracotta
setblock 181 24 362 minecraft:dark_prismarine
fill 181 24 363 181 27 363 minecraft:blue_terracotta
setblock 182 24 337 minecraft:blue_terracotta
setblock 182 24 341 minecraft:dark_prismarine
fill 182 24 342 182 27 342 minecraft:blue_terracotta
fill 182 24 352 182 25 352 minecraft:blue_terracotta
setblock 182 24 356 minecraft:dark_prismarine
fill 182 24 357 182 27 357 minecraft:blue_terracotta
setblock 182 24 361 minecraft:dark_prismarine
fill 182 24 362 182 27 362 minecraft:blue_terracotta
fill 141 25 363 141 131 363 minecraft:black_concrete
setblock 142 25 326 minecraft:purple_concrete
fill 142 25 336 142 27 336 minecraft:blue_terracotta
setblock 142 25 340 minecraft:dark_prismarine
fill 142 25 341 142 28 341 minecraft:blue_terracotta
setblock 142 25 345 minecraft:dark_prismarine
fill 142 25 346 142 28 346 minecraft:blue_terracotta
setblock 142 25 350 minecraft:dark_prismarine
setblock 142 25 351 minecraft:blue_terracotta
setblock 142 25 355 minecraft:dark_prismarine
fill 142 25 356 142 27 356 minecraft:blue_terracotta
setblock 142 25 360 minecraft:dark_prismarine
fill 142 25 361 142 28 361 minecraft:blue_terracotta
setblock 143 25 339 minecraft:dark_prismarine
fill 143 25 340 143 28 340 minecraft:blue_terracotta
setblock 143 25 344 minecraft:dark_prismarine
fill 147 25 349 147 33 349 minecraft:magenta_terracotta
setblock 149 25 363 minecraft:purple_concrete
setblock 150 25 323 minecraft:purple_concrete
setblock 153 25 323 minecraft:blue_terracotta
setblock 153 25 363 minecraft:blue_terracotta
setblock 154 25 323 minecraft:dark_prismarine
setblock 154 25 363 minecraft:dark_prismarine
fill 155 25 323 155 28 323 minecraft:blue_terracotta
fill 155 25 363 155 28 363 minecraft:blue_terracotta
fill 156 25 324 157 25 324 minecraft:blue_terracotta
fill 156 25 362 156 28 362 minecraft:blue_terracotta
setblock 158 25 324 minecraft:dark_prismarine
setblock 159 25 323 minecraft:dark_prismarine
fill 159 25 324 159 28 324 minecraft:blue_terracotta
setblock 159 25 363 minecraft:dark_prismarine
fill 160 25 323 160 28 323 minecraft:blue_terracotta
setblock 160 25 362 minecraft:dark_prismarine
fill 160 25 363 160 28 363 minecraft:blue_terracotta
fill 161 25 324 161 26 324 minecraft:blue_terracotta
fill 162 25 322 162 33 322 minecraft:black_concrete
fill 162 25 334 165 26 334 minecraft:dark_prismarine
fill 163 25 356 163 33 356 minecraft:magenta_terracotta
fill 163 25 359 163 33 359 minecraft:magenta_terracotta
setblock 164 25 323 minecraft:dark_prismarine
setblock 164 25 363 minecraft:dark_prismarine
fill 165 25 323 168 25 323 minecraft:blue_terracotta
fill 165 25 363 165 28 363 minecraft:blue_terracotta
fill 167 25 333 176 26 333 minecraft:dark_prismarine
fill 168 25 342 168 25 344 minecraft:purple_concrete
setblock 169 25 323 minecraft:dark_prismarine
fill 169 25 342 171 25 342 minecraft:purple_concrete
setblock 169 25 363 minecraft:dark_prismarine
setblock 170 25 323 minecraft:sea_lantern
setblock 170 25 325 minecraft:sea_lantern
fill 170 25 344 171 25 344 minecraft:purple_concrete
setblock 170 25 362 minecraft:dark_prismarine
fill 170 25 363 170 28 363 minecraft:blue_terracotta
setblock 171 25 324 minecraft:sea_lantern
setblock 171 25 326 minecraft:sea_lantern
setblock 171 25 343 minecraft:purple_concrete
fill 171 25 357 172 25 358 minecraft:purple_concrete
fill 171 25 362 171 28 362 minecraft:blue_terracotta
setblock 172 25 323 minecraft:sea_lantern
setblock 172 25 325 minecraft:sea_lantern
fill 172 25 355 173 25 356 minecraft:purple_concrete
fill 172 25 359 173 25 360 minecraft:purple_concrete
setblock 173 25 324 minecraft:sea_lantern
setblock 173 25 326 minecraft:sea_lantern
fill 173 25 332 182 26 332 minecraft:dark_prismarine
fill 173 25 361 173 27 361 minecraft:blue_terracotta
setblock 174 25 323 minecraft:sea_lantern
fill 174 25 324 174 28 324 minecraft:blue_terracotta
setblock 174 25 325 minecraft:sea_lantern
fill 174 25 354 175 25 355 minecraft:purple_concrete
fill 174 25 360 175 26 360 minecraft:purple_concrete
setblock 174 25 363 minecraft:dark_prismarine
fill 175 25 323 175 28 323 minecraft:blue_terracotta
setblock 175 25 324 minecraft:sea_lantern
setblock 175 25 326 minecraft:sea_lantern
setblock 175 25 362 minecraft:dark_prismarine
fill 175 25 363 175 28 363 minecraft:blue_terracotta
setblock 176 25 323 minecraft:sea_lantern
fill 176 25 324 176 26 324 minecraft:blue_terracotta
setblock 176 25 325 minecraft:sea_lantern
fill 176 25 355 177 25 356 minecraft:purple_concrete
fill 176 25 359 177 26 359 minecraft:purple_concrete
setblock 176 25 360 minecraft:blue_terracotta
setblock 176 25 361 minecraft:dark_prismarine
fill 176 25 362 176 28 362 minecraft:blue_terracotta
fill 177 25 323 177 26 323 minecraft:blue_terracotta
setblock 177 25 324 minecraft:sea_lantern
setblock 177 25 326 minecraft:sea_lantern
fill 177 25 336 177 33 336 minecraft:magenta_terracotta
fill 177 25 357 178 25 358 minecraft:purple_concrete
setblock 177 25 360 minecraft:dark_prismarine
fill 177 25 361 177 28 361 minecraft:blue_terracotta
setblock 178 25 323 minecraft:sea_lantern
setblock 178 25 324 minecraft:dark_prismarine
setblock 178 25 325 minecraft:sea_lantern
fill 178 25 360 178 28 360 minecraft:blue_terracotta
setblock 179 25 323 minecraft:dark_prismarine
setblock 179 25 324 minecraft:sea_lantern
setblock 179 25 326 minecraft:sea_lantern
setblock 179 25 363 minecraft:dark_prismarine
setblock 180 25 323 minecraft:sea_lantern
setblock 180 25 325 minecraft:sea_lantern
fill 180 25 331 182 26 331 minecraft:dark_prismarine
setblock 180 25 357 minecraft:dark_prismarine
fill 180 25 358 180 27 358 minecraft:blue_terracotta
setblock 180 25 362 minecraft:dark_prismarine
fill 180 25 363 180 28 363 minecraft:blue_terracotta
setblock 181 25 356 minecraft:dark_prismarine
fill 181 25 357 181 28 357 minecraft:blue_terracotta
setblock 181 25 361 minecraft:dark_prismarine
fill 181 25 362 181 28 362 minecraft:blue_terracotta
setblock 182 25 335 minecraft:purple_concrete
setblock 182 25 340 minecraft:dark_prismarine
fill 182 25 341 182 28 341 minecraft:blue_terracotta
setblock 182 25 344 minecraft:blue_terracotta
setblock 182 25 345 minecraft:dark_prismarine
fill 182 25 346 182 28 346 minecraft:blue_terracotta
setblock 182 25 355 minecraft:dark_prismarine
fill 182 25 356 182 28 356 minecraft:blue_terracotta
setblock 182 25 360 minecraft:dark_prismarine
fill 182 25 361 182 28 361 minecraft:blue_terracotta
setblock 142 26 332 minecraft:purple_concrete
setblock 142 26 339 minecraft:dark_prismarine
fill 142 26 340 142 28 340 minecraft:blue_terracotta
setblock 142 26 344 minecraft:dark_prismarine
fill 142 26 345 143 28 345 minecraft:blue_terracotta
setblock 142 26 349 minecraft:dark_prismarine
fill 142 26 350 142 28 350 minecraft:blue_terracotta
setblock 142 26 355 minecraft:blue_terracotta
setblock 142 26 359 minecraft:dark_prismarine
fill 142 26 360 142 28 360 minecraft:blue_terracotta
fill 143 26 336 144 26 337 minecraft:dark_prismarine
fill 143 26 339 143 28 339 minecraft:blue_terracotta
setblock 143 26 343 minecraft:dark_prismarine
fill 143 26 344 143 28 344 minecraft:blue_terracotta
setblock 143 26 363 minecraft:dark_prismarine
setblock 144 26 323 minecraft:purple_concrete
fill 148 26 348 148 33 348 minecraft:magenta_terracotta
fill 149 26 335 153 26 336 minecraft:dark_prismarine
fill 151 26 363 152 26 363 minecraft:blue_terracotta
setblock 152 26 323 minecraft:blue_terracotta
setblock 153 26 323 minecraft:dark_prismarine
setblock 153 26 363 minecraft:dark_prismarine
fill 154 26 323 154 28 324 minecraft:blue_terracotta
fill 154 26 334 161 26 335 minecraft:dark_prismarine
fill 154 26 363 154 28 363 minecraft:blue_terracotta
fill 155 26 324 156 26 324 minecraft:blue_terracotta
fill 155 26 362 155 28 362 minecraft:blue_terracotta
setblock 157 26 324 minecraft:dark_prismarine
setblock 158 26 323 minecraft:dark_prismarine
fill 158 26 324 158 28 324 minecraft:blue_terracotta
setblock 158 26 363 minecraft:dark_prismarine
fill 159 26 323 159 28 323 minecraft:blue_terracotta
setblock 159 26 362 minecraft:dark_prismarine
fill 159 26 363 159 28 363 minecraft:blue_terracotta
fill 160 26 362 160 28 362 minecraft:blue_terracotta
setblock 162 26 324 minecraft:dark_prismarine
fill 162 26 333 166 26 333 minecraft:dark_prismarine
setblock 163 26 323 minecraft:dark_prismarine
setblock 163 26 363 minecraft:dark_prismarine
fill 164 26 323 167 26 323 minecraft:blue_terracotta
fill 164 26 363 164 28 363 minecraft:blue_terracotta
fill 166 26 334 169 26 334 minecraft:dark_prismarine
setblock 168 26 323 minecraft:dark_prismarine
setblock 168 26 343 minecraft:purple_concrete
setblock 168 26 363 minecraft:dark_prismarine
fill 169 26 323 170 28 323 minecraft:blue_terracotta
fill 169 26 342 170 27 342 minecraft:purple_concrete
setblock 169 26 362 minecraft:dark_prismarine
fill 169 26 363 169 28 363 minecraft:blue_terracotta
fill 170 26 325 170 28 325 minecraft:dark_prismarine
fill 170 26 344 170 27 344 minecraft:purple_concrete
fill 170 26 362 170 28 362 minecraft:blue_terracotta
setblock 171 26 324 minecraft:blue_terracotta
fill 171 26 326 171 28 326 minecraft:dark_prismarine
fill 171 26 332 172 26 332 minecraft:dark_prismarine
setblock 172 26 323 minecraft:blue_terracotta
fill 172 26 325 172 28 325 minecraft:dark_prismarine
fill 172 26 356 172 26 359 minecraft:purple_concrete
fill 172 26 361 172 28 361 minecraft:blue_terracotta
setblock 173 26 323 minecraft:dark_prismarine
fill 173 26 324 173 28 324 minecraft:blue_terracotta
fill 173 26 326 173 28 326 minecraft:dark_prismarine
fill 173 26 355 173 26 356 minecraft:purple_concrete
fill 173 26 359 173 26 360 minecraft:purple_concrete
setblock 173 26 363 minecraft:dark_prismarine
fill 174 26 323 174 28 323 minecraft:blue_terracotta
fill 174 26 325 174 28 325 minecraft:dark_prismarine
fill 174 26 355 176 26 355 minecraft:purple_concrete
setblock 174 26 362 minecraft:dark_prismarine
fill 174 26 363 174 28 363 minecraft:blue_terracotta
fill 175 26 324 175 27 324 minecraft:blue_terracotta
fill 175 26 326 175 28 326 minecraft:dark_prismarine
setblock 175 26 361 minecraft:dark_prismarine
fill 175 26 362 175 28 362 minecraft:blue_terracotta
fill 176 26 323 176 27 323 minecraft:blue_terracotta
fill 176 26 325 176 27 325 minecraft:dark_prismarine
fill 176 26 356 177 26 356 minecraft:purple_concrete
setblock 176 26 360 minecraft:dark_prismarine
fill 176 26 361 176 28 361 minecraft:blue_terracotta
setblock 177 26 324 minecraft:dark_prismarine
fill 177 26 326 177 28 326 minecraft:dark_prismarine
setblock 177 26 333 minecraft:dark_prismarine
fill 177 26 357 177 26 358 minecraft:purple_concrete
fill 177 26 360 177 28 360 minecraft:blue_terracotta
setblock 178 26 323 minecraft:dark_prismarine
fill 178 26 324 179 28 324 minecraft:blue_terracotta
fill 178 26 325 178 28 325 minecraft:dark_prismarine
setblock 178 26 363 minecraft:dark_prismarine
fill 179 26 323 180 28 323 minecraft:blue_terracotta
fill 179 26 326 179 28 326 minecraft:dark_prismarine
setblock 179 26 362 minecraft:dark_prismarine
fill 179 26 363 179 28 363 minecraft:blue_terracotta
fill 180 26 325 180 28 325 minecraft:dark_prismarine
setblock 180 26 361 minecraft:dark_prismarine
fill 180 26 362 180 28 362 minecraft:blue_terracotta
fill 181 26 342 181 28 342 minecraft:blue_terracotta
fill 181 26 356 181 27 356 minecraft:blue_terracotta
setblock 181 26 360 minecraft:dark_prismarine
fill 181 26 361 181 28 361 minecraft:blue_terracotta
setblock 182 26 329 minecraft:purple_concrete
setblock 182 26 339 minecraft:dark_prismarine
fill 182 26 340 182 28 340 minecraft:blue_terracotta
setblock 182 26 344 minecraft:dark_prismarine
fill 182 26 345 182 28 345 minecraft:blue_terracotta
fill 182 26 347 182 26 348 minecraft:blue_terracotta
setblock 182 26 354 minecraft:dark_prismarine
fill 182 26 355 182 28 355 minecraft:blue_terracotta
setblock 182 26 359 minecraft:dark_prismarine
fill 182 26 360 182 28 360 minecraft:blue_terracotta
setblock 142 27 338 minecraft:dark_prismarine
fill 142 27 339 142 28 339 minecraft:blue_terracotta
setblock 142 27 343 minecraft:dark_prismarine
fill 142 27 344 142 28 344 minecraft:blue_terracotta
setblock 142 27 348 minecraft:dark_prismarine
fill 142 27 349 142 28 349 minecraft:blue_terracotta
setblock 142 27 358 minecraft:dark_prismarine
fill 142 27 359 142 28 359 minecraft:blue_terracotta
setblock 142 27 363 minecraft:dark_prismarine
fill 143 27 336 143 27 337 minecraft:dark_prismarine
setblock 143 27 342 minecraft:dark_prismarine
fill 143 27 343 143 28 343 minecraft:blue_terracotta
setblock 143 27 346 minecraft:blue_terracotta
fill 143 27 363 143 28 363 minecraft:blue_terracotta
setblock 144 27 336 minecraft:dark_prismarine
setblock 148 27 337 minecraft:magenta_terracotta
fill 149 27 335 150 27 336 minecraft:dark_prismarine
fill 150 27 323 151 27 323 minecraft:blue_terracotta
fill 150 27 363 151 27 363 minecraft:blue_terracotta
fill 151 27 335 157 27 335 minecraft:dark_prismarine
setblock 152 27 323 minecraft:dark_prismarine
setblock 152 27 363 minecraft:dark_prismarine
fill 153 27 323 153 28 324 minecraft:blue_terracotta
fill 153 27 363 153 28 363 minecraft:blue_terracotta
fill 154 27 362 154 28 362 minecraft:blue_terracotta
setblock 155 27 324 minecraft:blue_terracotta
setblock 156 27 324 minecraft:dark_prismarine
fill 156 27 325 158 28 325 minecraft:blue_terracotta
setblock 157 27 323 minecraft:dark_prismarine
fill 157 27 324 157 28 324 minecraft:blue_terracotta
setblock 157 27 363 minecraft:dark_prismarine
fill 158 27 323 158 28 323 minecraft:blue_terracotta
setblock 158 27 362 minecraft:dark_prismarine
fill 158 27 363 158 28 363 minecraft:blue_terracotta
fill 159 27 334 161 27 334 minecraft:dark_prismarine
fill 159 27 362 159 28 362 minecraft:blue_terracotta
setblock 161 27 324 minecraft:dark_prismarine
fill 161 27 362 161 28 362 minecraft:blue_terracotta
setblock 162 27 323 minecraft:dark_prismarine
fill 162 27 324 163 28 324 minecraft:blue_terracotta
fill 162 27 334 165 27 334 minecraft:purple_concrete
setblock 162 27 363 minecraft:dark_prismarine
fill 163 27 323 166 27 323 minecraft:blue_terracotta
fill 163 27 363 163 28 363 minecraft:blue_terracotta
setblock 167 27 323 minecraft:dark_prismarine
fill 167 27 333 174 27 333 minecraft:purple_concrete
setblock 167 27 363 minecraft:dark_prismarine
fill 168 27 323 168 28 323 minecraft:blue_terracotta
setblock 168 27 362 minecraft:dark_prismarine
fill 168 27 363 168 28 363 minecraft:blue_terracotta
fill 169 27 324 170 27 324 minecraft:blue_terracotta
fill 169 27 362 169 28 362 minecraft:blue_terracotta
setblock 171 27 324 minecraft:dark_prismarine
setblock 172 27 323 minecraft:dark_prismarine
fill 172 27 324 172 28 324 minecraft:blue_terracotta
setblock 172 27 358 minecraft:purple_concrete
setblock 172 27 363 minecraft:dark_prismarine
fill 173 27 323 173 28 323 minecraft:blue_terracotta
setblock 173 27 356 minecraft:purple_concrete
setblock 173 27 359 minecraft:purple_concrete
setblock 173 27 362 minecraft:dark_prismarine
fill 173 27 363 173 28 363 minecraft:blue_terracotta
fill 174 27 332 181 27 332 minecraft:purple_concrete
setblock 174 27 360 minecraft:purple_concrete
setblock 174 27 361 minecraft:dark_prismarine
fill 174 27 362 174 28 362 minecraft:blue_terracotta
setblock 175 27 360 minecraft:dark_prismarine
fill 175 27 361 175 28 361 minecraft:blue_terracotta
setblock 176 27 324 minecraft:dark_prismarine
setblock 176 27 356 minecraft:purple_concrete
setblock 176 27 359 minecraft:purple_concrete
fill 176 27 360 176 28 360 minecraft:blue_terracotta
setblock 177 27 323 minecraft:dark_prismarine
fill 177 27 324 177 28 324 minecraft:blue_terracotta
setblock 177 27 363 minecraft:dark_prismarine
fill 178 27 323 178 28 323 minecraft:blue_terracotta
setblock 178 27 362 minecraft:dark_prismarine
fill 178 27 363 178 28 363 minecraft:blue_terracotta
setblock 179 27 361 minecraft:dark_prismarine
fill 179 27 362 179 28 362 minecraft:blue_terracotta
setblock 180 27 360 minecraft:dark_prismarine
fill 180 27 361 180 28 361 minecraft:blue_terracotta
fill 181 27 341 181 28 341 minecraft:blue_terracotta
setblock 181 27 343 minecraft:blue_terracotta
setblock 181 27 344 minecraft:dark_prismarine
fill 181 27 345 181 28 345 minecraft:blue_terracotta
setblock 181 27 359 minecraft:dark_prismarine
fill 181 27 360 181 28 360 minecraft:blue_terracotta
setblock 182 27 323 minecraft:dark_prismarine
fill 182 27 324 182 28 324 minecraft:blue_terracotta
fill 182 27 339 182 28 339 minecraft:blue_terracotta
setblock 182 27 343 minecraft:dark_prismarine
fill 182 27 344 182 28 344 minecraft:blue_terracotta
setblock 182 27 347 minecraft:blue_terracotta
setblock 182 27 348 minecraft:dark_prismarine
fill 182 27 349 182 27 352 minecraft:blue_terracotta
setblock 182 27 353 minecraft:dark_prismarine
fill 182 27 354 182 28 354 minecraft:blue_terracotta
setblock 182 27 358 minecraft:dark_prismarine
fill 182 27 359 182 28 359 minecraft:blue_terracotta
setblock 182 27 363 minecraft:dark_prismarine
setblock 142 28 325 minecraft:purple_concrete
fill 142 28 336 144 28 336 minecraft:purple_concrete
setblock 142 28 337 minecraft:dark_prismarine
setblock 142 28 338 minecraft:blue_terracotta
setblock 142 28 342 minecraft:dark_prismarine
setblock 142 28 343 minecraft:blue_terracotta
setblock 142 28 347 minecraft:dark_prismarine
setblock 142 28 348 minecraft:blue_terracotta
setblock 142 28 351 minecraft:blue_terracotta
setblock 142 28 358 minecraft:blue_terracotta
setblock 142 28 362 minecraft:dark_prismarine
setblock 142 28 363 minecraft:blue_terracotta
setblock 143 28 341 minecraft:dark_prismarine
setblock 143 28 342 minecraft:blue_terracotta
setblock 143 28 346 minecraft:dark_prismarine
setblock 143 28 347 minecraft:blue_terracotta
setblock 148 28 363 minecraft:purple_concrete
fill 149 28 323 150 28 323 minecraft:blue_terracotta
fill 149 28 363 150 28 363 minecraft:blue_terracotta
fill 150 28 335 155 28 335 minecraft:purple_concrete
setblock 151 28 323 minecraft:dark_prismarine
fill 151 28 324 152 28 324 minecraft:blue_terracotta
setblock 151 28 363 minecraft:dark_prismarine
setblock 152 28 323 minecraft:blue_terracotta
setblock 152 28 363 minecraft:blue_terracotta
setblock 153 28 362 minecraft:blue_terracotta
setblock 154 28 325 minecraft:dark_prismarine
setblock 155 28 324 minecraft:dark_prismarine
setblock 155 28 325 minecraft:blue_terracotta
setblock 156 28 323 minecraft:dark_prismarine
setblock 156 28 324 minecraft:blue_terracotta
setblock 156 28 363 minecraft:dark_prismarine
setblock 157 28 323 minecraft:blue_terracotta
setblock 157 28 362 minecraft:dark_prismarine
setblock 157 28 363 minecraft:blue_terracotta
setblock 158 28 362 minecraft:blue_terracotta
setblock 159 28 325 minecraft:dark_prismarine
setblock 160 28 324 minecraft:dark_prismarine
setblock 160 28 325 minecraft:blue_terracotta
setblock 161 28 323 minecraft:dark_prismarine
setblock 161 28 324 minecraft:blue_terracotta
setblock 161 28 363 minecraft:dark_prismarine
fill 162 28 323 165 28 323 minecraft:blue_terracotta
setblock 162 28 363 minecraft:blue_terracotta
setblock 164 28 324 minecraft:blue_terracotta
setblock 165 28 324 minecraft:dark_prismarine
setblock 166 28 323 minecraft:dark_prismarine
fill 166 28 324 169 28 324 minecraft:blue_terracotta
setblock 166 28 363 minecraft:dark_prismarine
setblock 167 28 323 minecraft:blue_terracotta
setblock 167 28 362 minecraft:dark_prismarine
setblock 167 28 363 minecraft:blue_terracotta
setblock 168 28 362 minecraft:blue_terracotta
setblock 170 28 324 minecraft:dark_prismarine
setblock 171 28 323 minecraft:dark_prismarine
setblock 171 28 324 minecraft:blue_terracotta
setblock 171 28 361 minecraft:blue_terracotta
setblock 171 28 363 minecraft:dark_prismarine
setblock 172 28 323 minecraft:blue_terracotta
setblock 172 28 362 minecraft:dark_prismarine
setblock 172 28 363 minecraft:blue_terracotta
setblock 173 28 325 minecraft:blue_terracotta
setblock 173 28 361 minecraft:dark_prismarine
setblock 173 28 362 minecraft:blue_terracotta
setblock 174 28 360 minecraft:dark_prismarine
setblock 174 28 361 minecraft:blue_terracotta
setblock 175 28 324 minecraft:dark_prismarine
fill 175 28 325 176 28 325 minecraft:blue_terracotta
setblock 175 28 360 minecraft:blue_terracotta
setblock 176 28 323 minecraft:dark_prismarine
setblock 176 28 324 minecraft:blue_terracotta
setblock 176 28 363 minecraft:dark_prismarine
setblock 177 28 323 minecraft:blue_terracotta
setblock 177 28 362 minecraft:dark_prismarine
setblock 177 28 363 minecraft:blue_terracotta
setblock 178 28 361 minecraft:dark_prismarine
setblock 178 28 362 minecraft:blue_terracotta
setblock 179 28 361 minecraft:blue_terracotta
setblock 180 28 359 minecraft:dark_prismarine
setblock 180 28 360 minecraft:blue_terracotta
setblock 181 28 323 minecraft:dark_prismarine
setblock 181 28 343 minecraft:dark_prismarine
setblock 181 28 344 minecraft:blue_terracotta
fill 181 28 346 181 28 347 minecraft:blue_terracotta
setblock 181 28 358 minecraft:dark_prismarine
setblock 181 28 359 minecraft:blue_terracotta
setblock 181 28 363 minecraft:dark_prismarine
setblock 182 28 323 minecraft:blue_terracotta
setblock 182 28 336 minecraft:purple_concrete
setblock 182 28 342 minecraft:dark_prismarine
setblock 182 28 343 minecraft:blue_terracotta
setblock 182 28 347 minecraft:dark_prismarine
fill 182 28 348 182 28 351 minecraft:blue_terracotta
setblock 182 28 352 minecraft:dark_prismarine
setblock 182 28 353 minecraft:blue_terracotta
setblock 182 28 357 minecraft:dark_prismarine
setblock 182 28 358 minecraft:blue_terracotta
setblock 182 28 362 minecraft:dark_prismarine
setblock 182 28 363 minecraft:blue_terracotta
setblock 144 29 325 minecraft:light[level=13]
setblock 144 29 332 minecraft:light[level=12]
setblock 144 29 333 minecraft:light[level=13]
setblock 144 29 339 minecraft:light[level=12]
setblock 144 29 341 minecraft:light[level=13]
setblock 144 29 346 minecraft:light[level=12]
setblock 144 29 349 minecraft:light[level=13]
setblock 144 29 353 minecraft:light[level=12]
setblock 144 29 357 minecraft:light[level=13]
setblock 144 29 360 minecraft:light[level=12]
setblock 151 29 325 minecraft:light[level=12]
setblock 151 29 332 minecraft:light[level=12]
setblock 151 29 339 minecraft:light[level=12]
setblock 151 29 346 minecraft:light[level=12]
setblock 151 29 353 minecraft:light[level=12]
setblock 151 29 360 minecraft:light[level=12]
setblock 152 29 325 minecraft:light[level=13]
setblock 152 29 333 minecraft:light[level=13]
setblock 152 29 341 minecraft:light[level=13]
setblock 152 29 349 minecraft:light[level=13]
setblock 152 29 357 minecraft:light[level=13]
setblock 158 29 325 minecraft:light[level=12]
setblock 158 29 332 minecraft:light[level=12]
setblock 158 29 339 minecraft:light[level=12]
setblock 158 29 346 minecraft:light[level=12]
setblock 158 29 353 minecraft:light[level=12]
setblock 158 29 360 minecraft:light[level=12]
setblock 160 29 325 minecraft:light[level=13]
setblock 160 29 333 minecraft:light[level=13]
setblock 160 29 341 minecraft:light[level=13]
setblock 160 29 349 minecraft:light[level=13]
setblock 160 29 357 minecraft:light[level=13]
fill 161 29 330 161 33 330 minecraft:magenta_terracotta
setblock 165 29 325 minecraft:light[level=12]
setblock 165 29 332 minecraft:light[level=12]
setblock 165 29 339 minecraft:light[level=12]
setblock 165 29 346 minecraft:light[level=12]
setblock 165 29 353 minecraft:light[level=12]
setblock 165 29 360 minecraft:light[level=12]
setblock 168 29 325 minecraft:light[level=13]
setblock 168 29 333 minecraft:light[level=13]
setblock 168 29 341 minecraft:light[level=13]
setblock 168 29 349 minecraft:light[level=13]
setblock 168 29 357 minecraft:light[level=13]
setblock 172 29 325 minecraft:light[level=12]
setblock 172 29 332 minecraft:light[level=12]
setblock 172 29 339 minecraft:light[level=12]
setblock 172 29 346 minecraft:light[level=12]
setblock 172 29 353 minecraft:light[level=12]
setblock 172 29 360 minecraft:light[level=12]
setblock 176 29 325 minecraft:light[level=13]
setblock 176 29 333 minecraft:light[level=13]
fill 176 29 338 176 33 338 minecraft:magenta_terracotta
setblock 176 29 341 minecraft:light[level=13]
setblock 176 29 357 minecraft:light[level=13]
setblock 179 29 325 minecraft:light[level=12]
setblock 179 29 332 minecraft:light[level=12]
setblock 179 29 339 minecraft:light[level=12]
setblock 179 29 346 minecraft:light[level=12]
setblock 179 29 353 minecraft:light[level=12]
setblock 179 29 360 minecraft:light[level=12]
setblock 182 29 364 minecraft:cyan_concrete
fill 177 30 337 177 33 337 minecraft:magenta_terracotta
fill 182 30 364 182 131 364 minecraft:black_concrete
fill 148 31 337 148 33 337 minecraft:magenta_terracotta
fill 151 32 364 151 128 364 minecraft:black_concrete
setblock 152 32 364 minecraft:cyan_concrete
fill 153 32 364 155 36 364 minecraft:black_concrete
setblock 149 33 350 minecraft:pink_terracotta
fill 152 33 364 152 49 364 minecraft:black_concrete
setblock 159 33 327 minecraft:magenta_terracotta
setblock 160 33 329 minecraft:pink_terracotta
setblock 162 33 357 minecraft:magenta_terracotta
setblock 164 33 355 minecraft:magenta_terracotta
setblock 164 33 357 minecraft:pink_terracotta
setblock 174 33 364 minecraft:cyan_concrete
setblock 175 33 336 minecraft:pink_terracotta
fill 175 33 364 178 38 364 minecraft:black_concrete
setblock 178 33 350 minecraft:pink_terracotta
setblock 178 33 351 minecraft:magenta_terracotta
setblock 183 33 328 minecraft:light_blue_wool
fill 142 34 323 142 35 323 minecraft:blue_stained_glass
fill 142 34 324 142 35 326 minecraft:light_blue_stained_glass
fill 142 34 327 142 35 327 minecraft:white_stained_glass
fill 142 34 328 142 35 331 minecraft:blue_stained_glass
fill 142 34 332 142 35 335 minecraft:light_blue_stained_glass
fill 142 34 336 142 35 338 minecraft:white_stained_glass
fill 142 34 339 143 35 349 minecraft:blue_stained_glass
fill 142 34 350 142 35 351 minecraft:white_stained_glass
fill 142 34 352 142 35 355 minecraft:light_blue_stained_glass
fill 142 34 356 142 35 360 minecraft:blue_stained_glass
fill 142 34 361 142 35 361 minecraft:white_stained_glass
fill 142 34 362 142 35 363 minecraft:light_blue_stained_glass
fill 143 34 323 143 35 325 minecraft:light_blue_stained_glass
fill 143 34 326 143 35 326 minecraft:white_stained_glass
fill 143 34 327 143 35 330 minecraft:blue_stained_glass
fill 143 34 331 143 35 333 minecraft:light_blue_stained_glass
fill 143 34 334 143 35 335 minecraft:white_stained_glass
fill 143 34 336 144 35 338 minecraft:blue_stained_glass
fill 143 34 350 145 35 351 minecraft:blue_stained_glass
fill 143 34 352 143 35 353 minecraft:white_stained_glass
fill 143 34 354 143 35 357 minecraft:light_blue_stained_glass
fill 143 34 358 143 35 361 minecraft:blue_stained_glass
fill 143 34 362 143 35 362 minecraft:white_stained_glass
fill 143 34 363 143 35 363 minecraft:light_blue_stained_glass
fill 144 34 323 144 35 324 minecraft:light_blue_stained_glass
fill 144 34 325 144 35 325 minecraft:white_stained_glass
fill 144 34 326 144 35 329 minecraft:blue_stained_glass
fill 144 34 330 144 35 332 minecraft:light_blue_stained_glass
fill 144 34 333 144 35 333 minecraft:white_stained_glass
fill 144 34 334 146 35 335 minecraft:blue_stained_glass
fill 144 34 339 144 35 342 minecraft:blue_stained_glass
fill 144 34 343 145 35 344 minecraft:light_blue_stained_glass
fill 144 34 345 144 35 349 minecraft:blue_stained_glass
fill 144 34 352 146 35 353 minecraft:blue_stained_glass
fill 144 34 354 144 35 355 minecraft:white_stained_glass
fill 144 34 356 144 35 358 minecraft:light_blue_stained_glass
fill 144 34 359 144 35 362 minecraft:blue_stained_glass
fill 144 34 363 144 35 363 minecraft:white_stained_glass
fill 145 34 323 146 35 323 minecraft:light_blue_stained_glass
fill 145 34 324 146 35 324 minecraft:white_stained_glass
fill 145 34 325 145 35 328 minecraft:blue_stained_glass
fill 145 34 329 145 35 331 minecraft:light_blue_stained_glass
fill 145 34 332 145 35 332 minecraft:white_stained_glass
fill 145 34 333 148 35 333 minecraft:blue_stained_glass
fill 145 34 336 145 35 337 minecraft:blue_stained_glass
fill 145 34 338 145 35 342 minecraft:light_blue_stained_glass
fill 145 34 345 145 35 349 minecraft:light_blue_stained_glass
fill 145 34 354 147 35 355 minecraft:blue_stained_glass
fill 145 34 356 145 35 356 minecraft:white_stained_glass
fill 145 34 357 145 35 359 minecraft:light_blue_stained_glass
fill 145 34 360 145 35 363 minecraft:blue_stained_glass
fill 146 34 325 146 35 327 minecraft:blue_stained_glass
fill 146 34 328 146 35 330 minecraft:light_blue_stained_glass
fill 146 34 331 146 35 331 minecraft:white_stained_glass
fill 146 34 332 149 35 332 minecraft:blue_stained_glass
fill 146 34 336 146 35 341 minecraft:light_blue_stained_glass
fill 146 34 342 146 35 345 minecraft:white_stained_glass
fill 146 34 346 146 35 351 minecraft:light_blue_stained_glass
fill 146 34 356 149 35 356 minecraft:blue_stained_glass
fill 146 34 357 146 35 357 minecraft:white_stained_glass
fill 146 34 358 146 35 360 minecraft:light_blue_stained_glass
fill 146 34 361 146 35 363 minecraft:blue_stained_glass
fill 147 34 323 148 35 323 minecraft:white_stained_glass
fill 147 34 324 148 35 326 minecraft:blue_stained_glass
fill 147 34 327 147 35 329 minecraft:light_blue_stained_glass
fill 147 34 330 147 35 330 minecraft:white_stained_glass
fill 147 34 331 150 35 331 minecraft:blue_stained_glass
fill 147 34 334 147 35 334 minecraft:blue_stained_glass
fill 147 34 335 147 35 338 minecraft:light_blue_stained_glass
fill 147 34 339 147 35 340 minecraft:white_stained_glass
fill 147 34 341 149 35 346 minecraft:blue_stained_glass
fill 147 34 347 147 35 349 minecraft:white_stained_glass
fill 147 34 350 147 35 353 minecraft:light_blue_stained_glass
fill 147 34 357 150 35 357 minecraft:blue_stained_glass
fill 147 34 358 147 35 358 minecraft:white_stained_glass
fill 147 34 359 147 35 361 minecraft:light_blue_stained_glass
fill 147 34 362 148 35 363 minecraft:blue_stained_glass
fill 148 34 327 148 35 328 minecraft:light_blue_stained_glass
fill 148 34 329 148 35 329 minecraft:white_stained_glass
fill 148 34 330 152 35 330 minecraft:blue_stained_glass
fill 148 34 334 148 35 336 minecraft:light_blue_stained_glass
fill 148 34 337 148 35 337 minecraft:white_stained_glass
fill 148 34 338 150 35 340 minecraft:blue_stained_glass
fill 148 34 347 149 35 349 minecraft:blue_stained_glass
fill 148 34 350 148 35 351 minecraft:white_stained_glass
fill 148 34 352 148 35 354 minecraft:light_blue_stained_glass
fill 148 34 355 148 35 355 minecraft:blue_stained_glass
fill 148 34 358 151 35 358 minecraft:blue_stained_glass
fill 148 34 359 148 35 359 minecraft:white_stained_glass
fill 148 34 360 148 35 361 minecraft:light_blue_stained_glass
fill 149 34 323 150 35 325 minecraft:blue_stained_glass
fill 149 34 326 150 35 327 minecraft:light_blue_stained_glass
fill 149 34 328 150 35 328 minecraft:white_stained_glass
fill 149 34 329 165 35 329 minecraft:blue_stained_glass
fill 149 34 333 149 35 334 minecraft:light_blue_stained_glass
fill 149 34 335 149 35 336 minecraft:white_stained_glass
fill 149 34 337 151 35 337 minecraft:blue_stained_glass
fill 149 34 350 151 35 351 minecraft:blue_stained_glass
fill 149 34 352 149 35 352 minecraft:white_stained_glass
fill 149 34 353 149 35 355 minecraft:light_blue_stained_glass
fill 149 34 359 153 35 359 minecraft:blue_stained_glass
fill 149 34 360 149 35 360 minecraft:white_stained_glass
fill 149 34 361 149 35 362 minecraft:light_blue_stained_glass
fill 149 34 363 149 35 363 minecraft:blue_stained_glass
fill 150 34 332 151 35 333 minecraft:light_blue_stained_glass
fill 150 34 334 150 35 335 minecraft:white_stained_glass
fill 150 34 336 152 35 336 minecraft:blue_stained_glass
fill 150 34 341 151 35 347 minecraft:light_blue_stained_glass
fill 150 34 348 150 35 349 minecraft:blue_stained_glass
fill 150 34 352 153 35 352 minecraft:blue_stained_glass
fill 150 34 353 150 35 353 minecraft:white_stained_glass
fill 150 34 354 150 35 356 minecraft:light_blue_stained_glass
fill 150 34 360 155 35 360 minecraft:blue_stained_glass
fill 150 34 361 151 35 361 minecraft:white_stained_glass
fill 150 34 362 151 35 363 minecraft:light_blue_stained_glass
fill 151 34 323 153 35 324 minecraft:blue_stained_glass
fill 151 34 325 153 35 326 minecraft:light_blue_stained_glass
fill 151 34 327 152 35 327 minecraft:white_stained_glass
fill 151 34 328 164 35 328 minecraft:blue_stained_glass
fill 151 34 331 156 35 331 minecraft:light_blue_stained_glass
fill 151 34 334 151 35 334 minecraft:white_stained_glass
fill 151 34 335 154 35 335 minecraft:blue_stained_glass
fill 151 34 338 151 35 338 minecraft:blue_stained_glass
fill 151 34 339 152 35 340 minecraft:light_blue_stained_glass
fill 151 34 348 152 35 349 minecraft:light_blue_stained_glass
fill 151 34 353 154 35 353 minecraft:blue_stained_glass
fill 151 34 354 151 35 354 minecraft:white_stained_glass
fill 151 34 355 151 35 357 minecraft:light_blue_stained_glass
fill 152 34 332 152 35 332 minecraft:light_blue_stained_glass
fill 152 34 333 152 35 333 minecraft:white_stained_glass
fill 152 34 334 163 35 334 minecraft:blue_stained_glass
fill 152 34 337 153 35 338 minecraft:light_blue_stained_glass
fill 152 34 341 152 35 347 minecraft:white_stained_glass
fill 152 34 350 153 35 350 minecraft:light_blue_stained_glass
fill 152 34 351 152 35 351 minecraft:blue_stained_glass
fill 152 34 354 155 35 354 minecraft:blue_stained_glass
fill 152 34 355 152 35 355 minecraft:white_stained_glass
fill 152 34 356 152 35 358 minecraft:light_blue_stained_glass
fill 152 34 361 159 35 361 minecraft:blue_stained_glass
fill 152 34 362 153 35 362 minecraft:white_stained_glass
fill 152 34 363 153 35 363 minecraft:light_blue_stained_glass
fill 153 34 327 161 35 327 minecraft:blue_stained_glass
fill 153 34 330 162 35 330 minecraft:light_blue_stained_glass
fill 153 34 332 155 35 332 minecraft:white_stained_glass
fill 153 34 333 161 35 333 minecraft:blue_stained_glass
fill 153 34 336 161 35 336 minecraft:light_blue_stained_glass
fill 153 34 339 153 35 339 minecraft:white_stained_glass
fill 153 34 340 154 35 347 minecraft:blue_stained_glass
fill 153 34 348 153 35 348 minecraft:white_stained_glass
fill 153 34 349 153 35 349 minecraft:light_blue_stained_glass
fill 153 34 351 154 35 351 minecraft:light_blue_stained_glass
fill 153 34 355 158 35 355 minecraft:blue_stained_glass
fill 153 34 356 153 35 356 minecraft:white_stained_glass
fill 153 34 357 153 35 358 minecraft:light_blue_stained_glass
fill 154 34 323 166 35 323 minecraft:blue_stained_glass
fill 154 34 324 161 35 325 minecraft:light_blue_stained_glass
fill 154 34 326 161 35 326 minecraft:white_stained_glass
fill 154 34 337 154 35 337 minecraft:light_blue_stained_glass
fill 154 34 338 154 35 338 minecraft:white_stained_glass
fill 154 34 339 158 34 339 minecraft:blue_stained_glass
fill 154 34 348 156 35 348 minecraft:blue_stained_glass
fill 154 34 349 154 35 350 minecraft:white_stained_glass
fill 154 34 352 156 35 352 minecraft:light_blue_stained_glass
fill 154 34 356 171 35 356 minecraft:blue_stained_glass
fill 154 34 357 155 35 357 minecraft:white_stained_glass
fill 154 34 358 156 35 359 minecraft:light_blue_stained_glass
fill 154 34 362 171 35 362 minecraft:blue_stained_glass
fill 154 34 363 156 35 363 minecraft:white_stained_glass
fill 155 34 335 160 35 335 minecraft:light_blue_stained_glass
fill 155 34 337 156 35 337 minecraft:white_stained_glass
fill 155 34 338 160 34 338 minecraft:blue_stained_glass
fill 155 34 340 155 35 341 minecraft:blue_stained_glass
fill 155 34 342 156 35 345 minecraft:light_blue_stained_glass
fill 155 34 346 155 35 347 minecraft:blue_stained_glass
fill 155 34 349 158 35 350 minecraft:blue_stained_glass
fill 155 34 351 156 35 351 minecraft:white_stained_glass
fill 155 34 353 158 35 353 minecraft:light_blue_stained_glass
fill 156 34 332 159 35 332 minecraft:blue_stained_glass
fill 156 34 340 156 35 340 minecraft:blue_stained_glass
fill 156 34 341 157 34 341 minecraft:light_blue_stained_glass
fill 156 34 346 157 35 347 minecraft:light_blue_stained_glass
fill 156 34 354 169 35 354 minecraft:light_blue_stained_glass
fill 156 34 357 169 35 357 minecraft:blue_stained_glass
fill 156 34 360 169 35 360 minecraft:light_blue_stained_glass
fill 157 34 331 158 35 331 minecraft:white_stained_glass
fill 157 34 337 158 35 337 minecraft:blue_stained_glass
setblock 157 34 340 minecraft:light_blue_stained_glass
fill 157 34 342 157 34 345 minecraft:white_stained_glass
fill 157 34 348 160 35 348 minecraft:light_blue_stained_glass
fill 157 34 351 169 35 351 minecraft:blue_stained_glass
fill 157 34 352 157 35 352 minecraft:white_stained_glass
fill 157 34 358 158 35 358 minecraft:white_stained_glass
fill 157 34 359 159 35 359 minecraft:light_blue_stained_glass
fill 157 34 363 169 35 363 minecraft:blue_stained_glass
fill 158 34 343 158 34 345 minecraft:blue_stained_glass
fill 158 34 346 158 35 346 minecraft:white_stained_glass
fill 158 34 347 158 35 347 minecraft:light_blue_stained_glass
fill 158 34 352 167 35 352 minecraft:blue_stained_glass
fill 159 34 331 163 35 331 minecraft:light_blue_stained_glass
fill 159 34 337 160 35 337 minecraft:white_stained_glass
fill 159 34 344 159 34 346 minecraft:blue_stained_glass
fill 159 34 347 159 35 347 minecraft:white_stained_glass
fill 159 34 349 167 35 349 minecraft:light_blue_stained_glass
fill 159 34 350 160 35 350 minecraft:blue_stained_glass
fill 159 34 353 167 35 353 minecraft:white_stained_glass
fill 159 34 355 167 35 355 minecraft:light_blue_stained_glass
fill 159 34 358 166 35 358 minecraft:blue_stained_glass
fill 160 34 332 161 35 332 minecraft:white_stained_glass
fill 160 34 344 165 34 344 minecraft:light_blue_stained_glass
fill 160 34 345 161 35 347 minecraft:blue_stained_glass
fill 160 34 359 165 35 359 minecraft:white_stained_glass
fill 160 34 361 165 35 361 minecraft:light_blue_stained_glass
fill 161 34 335 164 35 335 minecraft:blue_stained_glass
fill 161 34 337 162 35 337 minecraft:light_blue_stained_glass
setblock 161 34 338 minecraft:white_stained_glass
fill 161 34 348 164 35 348 minecraft:white_stained_glass
fill 161 34 350 164 35 350 minecraft:light_blue_stained_glass
setblock 162 34 322 minecraft:light_blue_wool
fill 162 34 324 168 35 324 minecraft:blue_stained_glass
fill 162 34 325 164 35 326 minecraft:light_blue_stained_glass
fill 162 34 327 163 35 327 minecraft:white_stained_glass
fill 162 34 332 165 35 332 minecraft:light_blue_stained_glass
fill 162 34 333 163 35 333 minecraft:white_stained_glass
fill 162 34 336 164 35 336 minecraft:blue_stained_glass
fill 162 34 338 162 34 339 minecraft:light_blue_stained_glass
fill 162 34 343 163 34 343 minecraft:white_stained_glass
fill 162 34 345 163 35 345 minecraft:light_blue_stained_glass
fill 162 34 346 165 35 347 minecraft:blue_stained_glass
fill 163 34 330 166 35 330 minecraft:blue_stained_glass
fill 163 34 337 163 34 342 minecraft:blue_stained_glass
fill 164 34 327 167 35 327 minecraft:light_blue_stained_glass
fill 164 34 331 167 35 331 minecraft:blue_stained_glass
fill 164 34 333 165 35 333 minecraft:light_blue_stained_glass
fill 164 34 334 164 35 334 minecraft:white_stained_glass
fill 164 34 337 164 35 341 minecraft:blue_stained_glass
fill 164 34 342 164 35 342 minecraft:white_stained_glass
fill 164 34 343 166 35 343 minecraft:light_blue_stained_glass
fill 164 34 345 168 35 345 minecraft:blue_stained_glass
fill 165 34 325 169 35 325 minecraft:blue_stained_glass
fill 165 34 326 166 35 326 minecraft:light_blue_stained_glass
fill 165 34 328 165 35 328 minecraft:white_stained_glass
fill 165 34 334 166 35 334 minecraft:light_blue_stained_glass
fill 165 34 335 165 35 336 minecraft:white_stained_glass
fill 165 34 337 165 35 340 minecraft:blue_stained_glass
fill 165 34 341 165 35 341 minecraft:white_stained_glass
fill 165 34 342 167 35 342 minecraft:light_blue_stained_glass
fill 165 34 348 168 35 348 minecraft:light_blue_stained_glass
fill 165 34 350 170 35 350 minecraft:blue_stained_glass
fill 166 34 328 168 35 328 minecraft:light_blue_stained_glass
fill 166 34 329 166 35 329 minecraft:white_stained_glass
fill 166 34 332 168 35 333 minecraft:blue_stained_glass
fill 166 34 335 167 35 337 minecraft:light_blue_stained_glass
fill 166 34 338 166 35 339 minecraft:white_stained_glass
fill 166 34 340 167 35 341 minecraft:light_blue_stained_glass
fill 166 34 344 168 35 344 minecraft:blue_stained_glass
fill 166 34 346 167 35 346 minecraft:blue_stained_glass
fill 166 34 347 167 35 347 minecraft:white_stained_glass
fill 166 34 359 171 35 359 minecraft:light_blue_stained_glass
fill 166 34 361 173 35 361 minecraft:blue_stained_glass
fill 167 34 323 168 35 323 minecraft:white_stained_glass
fill 167 34 326 170 35 326 minecraft:blue_stained_glass
fill 167 34 329 169 35 329 minecraft:light_blue_stained_glass
fill 167 34 330 168 35 330 minecraft:white_stained_glass
fill 167 34 334 169 35 334 minecraft:blue_stained_glass
fill 167 34 338 167 35 339 minecraft:light_blue_stained_glass
fill 167 34 343 169 35 343 minecraft:blue_stained_glass
fill 167 34 358 169 35 358 minecraft:white_stained_glass
fill 168 34 327 171 35 327 minecraft:blue_stained_glass
fill 168 34 331 168 35 331 minecraft:white_stained_glass
fill 168 34 335 169 35 342 minecraft:blue_stained_glass
fill 168 34 346 168 35 346 minecraft:white_stained_glass
fill 168 34 347 169 35 347 minecraft:light_blue_stained_glass
fill 168 34 349 171 35 349 minecraft:blue_stained_glass
fill 168 34 352 169 35 352 minecraft:white_stained_glass
fill 168 34 353 171 35 353 minecraft:light_blue_stained_glass
fill 168 34 355 173 35 355 minecraft:blue_stained_glass
fill 169 34 323 171 35 323 minecraft:light_blue_stained_glass
fill 169 34 324 169 35 324 minecraft:white_stained_glass
fill 169 34 328 172 35 328 minecraft:blue_stained_glass
fill 169 34 330 170 35 331 minecraft:light_blue_stained_glass
fill 169 34 332 169 35 332 minecraft:white_stained_glass
fill 169 34 333 169 35 333 minecraft:blue_stained_glass
fill 169 34 344 169 35 345 minecraft:white_stained_glass
fill 169 34 346 170 35 346 minecraft:light_blue_stained_glass
fill 169 34 348 172 35 348 minecraft:blue_stained_glass
fill 170 34 324 172 35 324 minecraft:light_blue_stained_glass
fill 170 34 325 170 35 325 minecraft:white_stained_glass
fill 170 34 329 173 35 329 minecraft:blue_stained_glass
fill 170 34 332 171 35 332 minecraft:light_blue_stained_glass
fill 170 34 333 170 35 334 minecraft:white_stained_glass
fill 170 34 335 170 35 341 minecraft:blue_stained_glass
fill 170 34 342 170 35 343 minecraft:white_stained_glass
fill 170 34 344 171 35 345 minecraft:light_blue_stained_glass
fill 170 34 347 173 35 347 minecraft:blue_stained_glass
fill 170 34 351 170 35 351 minecraft:white_stained_glass
fill 170 34 352 172 35 352 minecraft:light_blue_stained_glass
fill 170 34 354 174 35 354 minecraft:blue_stained_glass
fill 170 34 357 171 35 357 minecraft:white_stained_glass
fill 170 34 358 173 35 358 minecraft:light_blue_stained_glass
fill 170 34 360 175 35 360 minecraft:blue_stained_glass
fill 170 34 363 171 35 363 minecraft:white_stained_glass
fill 171 34 325 173 35 325 minecraft:light_blue_stained_glass
fill 171 34 326 171 35 326 minecraft:white_stained_glass
fill 171 34 330 173 35 330 minecraft:blue_stained_glass
fill 171 34 331 171 35 331 minecraft:light_blue_stained_glass
fill 171 34 333 172 35 335 minecraft:light_blue_stained_glass
fill 171 34 336 171 35 341 minecraft:white_stained_glass
fill 171 34 342 172 35 343 minecraft:light_blue_stained_glass
fill 171 34 346 174 35 346 minecraft:blue_stained_glass
fill 171 34 350 171 35 350 minecraft:white_stained_glass
fill 171 34 351 173 35 351 minecraft:light_blue_stained_glass
fill 172 34 323 175 35 323 minecraft:blue_stained_glass
fill 172 34 326 174 35 326 minecraft:light_blue_stained_glass
fill 172 34 327 172 35 327 minecraft:white_stained_glass
fill 172 34 331 174 35 332 minecraft:blue_stained_glass
fill 172 34 336 173 35 341 minecraft:light_blue_stained_glass
fill 172 34 344 172 35 344 minecraft:light_blue_stained_glass
fill 172 34 345 174 35 345 minecraft:blue_stained_glass
fill 172 34 349 172 35 349 minecraft:white_stained_glass
fill 172 34 350 174 35 350 minecraft:light_blue_stained_glass
fill 172 34 353 175 35 353 minecraft:blue_stained_glass
fill 172 34 356 173 35 356 minecraft:white_stained_glass
fill 172 34 357 175 35 357 minecraft:light_blue_stained_glass
fill 172 34 359 177 35 359 minecraft:blue_stained_glass
fill 172 34 362 173 35 362 minecraft:white_stained_glass
fill 172 34 363 176 35 363 minecraft:light_blue_stained_glass
fill 173 34 324 176 35 324 minecraft:blue_stained_glass
fill 173 34 327 175 35 327 minecraft:light_blue_stained_glass
fill 173 34 328 173 35 328 minecraft:white_stained_glass
fill 173 34 333 175 35 335 minecraft:blue_stained_glass
fill 173 34 342 175 35 344 minecraft:blue_stained_glass
fill 173 34 348 173 35 348 minecraft:white_stained_glass
fill 173 34 349 175 35 349 minecraft:light_blue_stained_glass
fill 173 34 352 176 35 352 minecraft:blue_stained_glass
fill 174 34 325 177 35 325 minecraft:blue_stained_glass
fill 174 34 328 175 35 328 minecraft:light_blue_stained_glass
fill 174 34 329 174 35 330 minecraft:white_stained_glass
fill 174 34 336 175 35 341 minecraft:blue_stained_glass
fill 174 34 347 174 35 347 minecraft:white_stained_glass
fill 174 34 348 176 35 348 minecraft:light_blue_stained_glass
fill 174 34 351 177 35 351 minecraft:blue_stained_glass
fill 174 34 355 174 35 355 minecraft:white_stained_glass
fill 174 34 356 176 35 356 minecraft:light_blue_stained_glass
fill 174 34 358 178 35 358 minecraft:blue_stained_glass
fill 174 34 361 175 35 361 minecraft:white_stained_glass
fill 174 34 362 177 35 362 minecraft:light_blue_stained_glass
fill 174 34 364 174 90 364 minecraft:black_concrete
fill 175 34 326 177 35 326 minecraft:blue_stained_glass
fill 175 34 329 176 35 330 minecraft:light_blue_stained_glass
fill 175 34 331 175 35 332 minecraft:white_stained_glass
fill 175 34 345 175 35 346 minecraft:white_stained_glass
fill 175 34 347 176 35 347 minecraft:light_blue_stained_glass
fill 175 34 350 178 35 350 minecraft:blue_stained_glass
fill 175 34 354 175 35 354 minecraft:white_stained_glass
fill 175 34 355 177 35 355 minecraft:light_blue_stained_glass
fill 176 34 323 176 35 323 minecraft:white_stained_glass
fill 176 34 327 178 35 328 minecraft:blue_stained_glass
fill 176 34 331 177 35 332 minecraft:light_blue_stained_glass
fill 176 34 333 176 35 337 minecraft:white_stained_glass
fill 176 34 338 176 35 339 minecraft:blue_stained_glass
fill 176 34 340 176 35 343 minecraft:white_stained_glass
fill 176 34 344 177 35 346 minecraft:light_blue_stained_glass
fill 176 34 349 178 35 349 minecraft:blue_stained_glass
fill 176 34 353 176 35 353 minecraft:white_stained_glass
fill 176 34 354 178 35 354 minecraft:light_blue_stained_glass
fill 176 34 357 179 35 357 minecraft:blue_stained_glass
fill 176 34 360 177 35 360 minecraft:white_stained_glass
fill 176 34 361 178 35 361 minecraft:light_blue_stained_glass
fill 177 34 323 179 35 323 minecraft:light_blue_stained_glass
fill 177 34 324 177 35 324 minecraft:white_stained_glass
fill 177 34 329 179 35 330 minecraft:blue_stained_glass
fill 177 34 333 178 35 343 minecraft:light_blue_stained_glass
fill 177 34 347 179 35 348 minecraft:blue_stained_glass
fill 177 34 352 177 35 352 minecraft:white_stained_glass
fill 177 34 353 179 35 353 minecraft:light_blue_stained_glass
fill 177 34 356 180 35 356 minecraft:blue_stained_glass
fill 177 34 363 180 35 363 minecraft:blue_stained_glass
fill 178 34 324 179 35 324 minecraft:light_blue_stained_glass
fill 178 34 325 178 35 326 minecraft:white_stained_glass
fill 178 34 331 180 35 332 minecraft:blue_stained_glass
fill 178 34 344 180 35 346 minecraft:blue_stained_glass
fill 178 34 351 178 35 351 minecraft:white_stained_glass
fill 178 34 352 180 35 352 minecraft:light_blue_stained_glass
fill 178 34 355 181 35 355 minecraft:blue_stained_glass
fill 178 34 359 178 35 359 minecraft:white_stained_glass
fill 178 34 360 180 35 360 minecraft:light_blue_stained_glass
fill 178 34 362 182 35 362 minecraft:blue_stained_glass
fill 179 34 325 180 35 326 minecraft:light_blue_stained_glass
fill 179 34 327 179 35 328 minecraft:white_stained_glass
fill 179 34 333 180 35 343 minecraft:blue_stained_glass
fill 179 34 349 179 35 350 minecraft:white_stained_glass
fill 179 34 351 180 35 351 minecraft:light_blue_stained_glass
fill 179 34 354 181 35 354 minecraft:blue_stained_glass
fill 179 34 358 179 35 358 minecraft:white_stained_glass
fill 179 34 359 181 35 359 minecraft:light_blue_stained_glass
fill 179 34 361 182 35 361 minecraft:blue_stained_glass
fill 180 34 323 182 35 324 minecraft:blue_stained_glass
fill 180 34 327 181 35 328 minecraft:light_blue_stained_glass
fill 180 34 329 180 35 330 minecraft:white_stained_glass
fill 180 34 347 180 35 348 minecraft:white_stained_glass
fill 180 34 349 181 35 350 minecraft:light_blue_stained_glass
fill 180 34 353 182 35 353 minecraft:blue_stained_glass
fill 180 34 357 180 35 357 minecraft:white_stained_glass
fill 180 34 358 182 35 358 minecraft:light_blue_stained_glass
fill 181 34 325 182 35 325 minecraft:blue_stained_glass
fill 181 34 326 181 35 326 minecraft:light_blue_stained_glass
fill 181 34 329 182 35 330 minecraft:light_blue_stained_glass
fill 181 34 331 181 35 333 minecraft:white_stained_glass
fill 181 34 334 181 35 343 minecraft:blue_stained_glass
fill 181 34 344 181 35 346 minecraft:white_stained_glass
fill 181 34 347 182 35 348 minecraft:light_blue_stained_glass
fill 181 34 351 182 35 352 minecraft:blue_stained_glass
fill 181 34 356 181 35 356 minecraft:white_stained_glass
fill 181 34 357 182 35 357 minecraft:light_blue_stained_glass
fill 181 34 360 182 35 360 minecraft:blue_stained_glass
fill 181 34 363 182 35 363 minecraft:white_stained_glass
fill 182 34 326 182 35 327 minecraft:blue_stained_glass
fill 182 34 328 182 35 328 minecraft:light_blue_stained_glass
fill 182 34 331 182 35 334 minecraft:light_blue_stained_glass
fill 182 34 335 182 35 342 minecraft:white_stained_glass
fill 182 34 343 182 35 346 minecraft:light_blue_stained_glass
fill 182 34 349 182 35 350 minecraft:blue_stained_glass
fill 182 34 354 182 35 355 minecraft:white_stained_glass
fill 182 34 356 182 35 356 minecraft:light_blue_stained_glass
fill 182 34 359 182 35 359 minecraft:blue_stained_glass
fill 183 34 328 183 131 328 minecraft:black_concrete
fill 154 35 339 156 35 339 minecraft:blue_stained_glass
fill 155 35 338 157 35 338 minecraft:blue_stained_glass
setblock 156 35 341 minecraft:light_blue_stained_glass
fill 157 35 339 157 35 343 minecraft:sea_lantern
fill 157 35 344 157 35 345 minecraft:white_stained_glass
fill 158 35 338 158 35 339 minecraft:sea_lantern
fill 158 35 343 158 35 344 minecraft:sea_lantern
fill 158 35 345 159 35 345 minecraft:blue_stained_glass
fill 159 35 338 162 35 338 minecraft:sea_lantern
fill 159 35 344 162 35 344 minecraft:sea_lantern
setblock 159 35 346 minecraft:blue_stained_glass
fill 162 35 322 162 131 322 minecraft:black_concrete
fill 162 35 339 163 35 339 minecraft:sea_lantern
fill 162 35 343 163 35 343 minecraft:sea_lantern
fill 163 35 337 163 35 338 minecraft:blue_stained_glass
fill 163 35 340 163 35 342 minecraft:sea_lantern
fill 163 35 344 165 35 344 minecraft:light_blue_stained_glass
setblock 183 35 338 minecraft:light_blue_wool
fill 183 35 339 183 91 339 minecraft:black_concrete
fill 145 36 334 148 43 337 minecraft:magenta_terracotta
fill 147 36 349 150 41 351 minecraft:magenta_terracotta
fill 148 36 348 149 66 348 minecraft:magenta_terracotta
fill 158 36 328 161 40 329 minecraft:magenta_terracotta
fill 159 36 327 161 42 327 minecraft:magenta_terracotta
fill 159 36 330 161 54 330 minecraft:magenta_terracotta
fill 162 36 357 166 39 357 minecraft:magenta_terracotta
fill 163 36 356 165 52 356 minecraft:magenta_terracotta
fill 163 36 358 165 37 359 minecraft:magenta_terracotta
fill 164 36 355 164 57 355 minecraft:magenta_terracotta
setblock 166 36 358 minecraft:magenta_terracotta
fill 174 36 335 176 43 338 minecraft:magenta_terracotta
fill 176 36 349 179 52 351 minecraft:magenta_terracotta
fill 177 36 335 177 58 337 minecraft:magenta_terracotta
fill 177 36 352 178 58 352 minecraft:magenta_terracotta
fill 183 36 338 183 53 338 minecraft:black_concrete
setblock 141 37 338 minecraft:cyan_concrete
setblock 144 37 325 minecraft:light[level=13]
setblock 144 37 333 minecraft:light[level=13]
setblock 144 37 341 minecraft:light[level=13]
setblock 144 37 349 minecraft:light[level=13]
setblock 144 37 357 minecraft:light[level=13]
setblock 152 37 325 minecraft:light[level=13]
setblock 152 37 333 minecraft:light[level=13]
setblock 152 37 341 minecraft:light[level=13]
setblock 152 37 349 minecraft:light[level=13]
setblock 152 37 357 minecraft:light[level=13]
fill 153 37 364 154 84 364 minecraft:black_concrete
setblock 155 37 364 minecraft:cyan_concrete
setblock 160 37 325 minecraft:light[level=13]
setblock 160 37 333 minecraft:light[level=13]
setblock 160 37 349 minecraft:light[level=13]
setblock 160 37 357 minecraft:light[level=13]
fill 162 37 329 162 58 329 minecraft:magenta_terracotta
fill 162 37 358 162 81 358 minecraft:magenta_terracotta
setblock 168 37 325 minecraft:light[level=13]
setblock 168 37 333 minecraft:light[level=13]
setblock 168 37 341 minecraft:light[level=13]
setblock 168 37 349 minecraft:light[level=13]
setblock 168 37 357 minecraft:light[level=13]
setblock 176 37 325 minecraft:light[level=13]
setblock 176 37 333 minecraft:light[level=13]
setblock 176 37 341 minecraft:light[level=13]
setblock 176 37 357 minecraft:light[level=13]
fill 141 38 338 141 72 338 minecraft:black_concrete
setblock 141 38 356 minecraft:light_blue_wool
fill 141 38 357 141 76 362 minecraft:black_concrete
fill 155 38 364 155 110 364 minecraft:black_concrete
fill 162 38 356 162 58 356 minecraft:magenta_terracotta
fill 163 38 358 164 44 359 minecraft:magenta_terracotta
fill 165 38 358 165 48 358 minecraft:magenta_terracotta
fill 141 39 356 141 127 356 minecraft:black_concrete
fill 142 39 327 142 39 330 minecraft:blue_terracotta
setblock 142 39 331 minecraft:dark_prismarine
fill 142 39 332 142 40 334 minecraft:blue_terracotta
fill 142 39 343 152 39 343 minecraft:dark_prismarine
setblock 142 39 345 minecraft:blue_terracotta
setblock 142 39 346 minecraft:dark_prismarine
fill 142 39 347 142 39 350 minecraft:blue_terracotta
setblock 142 39 351 minecraft:dark_prismarine
fill 142 39 352 142 42 352 minecraft:blue_terracotta
setblock 142 39 353 minecraft:purple_concrete
setblock 143 39 329 minecraft:blue_terracotta
setblock 143 39 330 minecraft:dark_prismarine
fill 143 39 331 143 42 331 minecraft:blue_terracotta
fill 143 39 342 157 39 342 minecraft:dark_prismarine
setblock 145 39 323 minecraft:dark_prismarine
fill 146 39 323 149 39 323 minecraft:blue_terracotta
fill 147 39 324 148 39 324 minecraft:blue_terracotta
fill 147 39 348 147 102 348 minecraft:magenta_terracotta
setblock 148 39 325 minecraft:dark_prismarine
setblock 149 39 324 minecraft:dark_prismarine
fill 149 39 325 152 39 325 minecraft:blue_terracotta
setblock 150 39 323 minecraft:dark_prismarine
fill 150 39 324 153 39 324 minecraft:blue_terracotta
fill 151 39 323 154 39 323 minecraft:blue_terracotta
setblock 151 39 363 minecraft:purple_concrete
setblock 153 39 325 minecraft:dark_prismarine
fill 153 39 341 157 39 341 minecraft:dark_prismarine
setblock 154 39 324 minecraft:dark_prismarine
setblock 155 39 323 minecraft:dark_prismarine
setblock 155 39 324 minecraft:blue_terracotta
fill 155 39 325 157 39 325 minecraft:dark_prismarine
fill 156 39 323 159 39 323 minecraft:blue_terracotta
fill 156 39 324 158 39 324 minecraft:dark_prismarine
setblock 156 39 326 minecraft:dark_prismarine
setblock 160 39 323 minecraft:dark_prismarine
fill 161 39 323 164 39 323 minecraft:blue_terracotta
fill 162 39 328 162 84 328 minecraft:magenta_terracotta
fill 164 39 340 173 39 341 minecraft:dark_prismarine
setblock 165 39 322 minecraft:cyan_concrete
setblock 165 39 323 minecraft:dark_prismarine
fill 165 39 324 168 39 324 minecraft:blue_terracotta
setblock 165 39 363 minecraft:dark_prismarine
fill 166 39 322 166 131 322 minecraft:black_concrete
fill 166 39 323 169 39 323 minecraft:blue_terracotta
fill 166 39 363 169 39 363 minecraft:blue_terracotta
fill 168 39 362 170 39 362 minecraft:blue_terracotta
setblock 169 39 324 minecraft:dark_prismarine
setblock 170 39 323 minecraft:dark_prismarine
fill 170 39 324 171 39 324 minecraft:blue_terracotta
setblock 170 39 363 minecraft:dark_prismarine
fill 171 39 323 173 39 323 minecraft:blue_terracotta
setblock 171 39 362 minecraft:dark_prismarine
fill 171 39 363 174 39 363 minecraft:blue_terracotta
fill 174 39 340 182 40 340 minecraft:dark_prismarine
fill 175 39 364 175 60 364 minecraft:black_concrete
fill 176 39 339 182 39 339 minecraft:dark_prismarine
setblock 176 39 363 minecraft:purple_concrete
setblock 176 39 364 minecraft:cyan_concrete
fill 177 39 364 178 131 364 minecraft:black_concrete
fill 179 39 352 179 47 352 minecraft:black_concrete
fill 181 39 348 181 39 351 minecraft:blue_terracotta
setblock 182 39 333 minecraft:purple_concrete
setblock 182 39 345 minecraft:blue_terracotta
setblock 182 39 346 minecraft:dark_prismarine
fill 182 39 347 182 39 350 minecraft:blue_terracotta
setblock 182 39 351 minecraft:dark_prismarine
fill 182 39 352 182 39 355 minecraft:blue_terracotta
setblock 182 39 358 minecraft:purple_concrete
fill 142 40 322 144 64 322 minecraft:black_concrete
fill 142 40 326 142 40 329 minecraft:blue_terracotta
setblock 142 40 330 minecraft:dark_prismarine
fill 142 40 331 142 43 331 minecraft:blue_terracotta
setblock 142 40 335 minecraft:dark_prismarine
fill 142 40 336 142 43 336 minecraft:blue_terracotta
fill 142 40 343 147 40 343 minecraft:purple_concrete
setblock 142 40 345 minecraft:dark_prismarine
fill 142 40 346 142 40 349 minecraft:blue_terracotta
setblock 142 40 350 minecraft:dark_prismarine
fill 142 40 351 142 43 351 minecraft:blue_terracotta
fill 142 40 353 142 41 353 minecraft:blue_terracotta
setblock 142 40 359 minecraft:purple_concrete
setblock 143 40 328 minecraft:blue_terracotta
setblock 143 40 329 minecraft:dark_prismarine
fill 143 40 330 143 43 330 minecraft:blue_terracotta
fill 143 40 332 143 40 333 minecraft:blue_terracotta
setblock 145 40 322 minecraft:light_blue_wool
fill 145 40 323 148 40 323 minecraft:blue_terracotta
fill 146 40 322 146 65 322 minecraft:black_concrete
fill 146 40 324 147 40 324 minecraft:blue_terracotta
fill 147 40 342 157 40 342 minecraft:purple_concrete
setblock 148 40 324 minecraft:dark_prismarine
fill 148 40 325 151 40 325 minecraft:blue_terracotta
setblock 149 40 323 minecraft:dark_prismarine
fill 149 40 324 152 40 324 minecraft:blue_terracotta
fill 150 40 323 153 40 323 minecraft:blue_terracotta
setblock 152 40 325 minecraft:dark_prismarine
setblock 153 40 324 minecraft:dark_prismarine
setblock 154 40 323 minecraft:dark_prismarine
setblock 154 40 324 minecraft:blue_terracotta
fill 155 40 323 157 40 323 minecraft:blue_terracotta
setblock 157 40 363 minecraft:purple_concrete
fill 160 40 331 160 60 331 minecraft:magenta_terracotta
fill 162 40 323 163 40 323 minecraft:blue_terracotta
fill 162 40 357 165 53 357 minecraft:magenta_terracotta
fill 163 40 355 163 73 355 minecraft:magenta_terracotta
setblock 164 40 323 minecraft:dark_prismarine
fill 164 40 341 170 40 341 minecraft:dark_prismarine
setblock 164 40 363 minecraft:dark_prismarine
fill 165 40 322 165 67 322 minecraft:black_concrete
fill 165 40 323 167 40 324 minecraft:blue_terracotta
fill 165 40 363 168 40 363 minecraft:blue_terracotta
setblock 168 40 323 minecraft:blue_terracotta
setblock 168 40 324 minecraft:dark_prismarine
fill 168 40 362 169 40 362 minecraft:blue_terracotta
setblock 169 40 323 minecraft:dark_prismarine
fill 169 40 324 170 40 324 minecraft:blue_terracotta
fill 169 40 340 173 40 340 minecraft:dark_prismarine
setblock 169 40 363 minecraft:dark_prismarine
fill 170 40 323 172 40 323 minecraft:blue_terracotta
setblock 170 40 362 minecraft:dark_prismarine
fill 170 40 363 173 40 363 minecraft:blue_terracotta
fill 176 40 364 176 131 364 minecraft:black_concrete
fill 177 40 339 182 40 339 minecraft:dark_prismarine
fill 181 40 349 181 40 350 minecraft:blue_terracotta
setblock 181 40 351 minecraft:dark_prismarine
fill 181 40 352 182 42 352 minecraft:blue_terracotta
setblock 182 40 327 minecraft:purple_concrete
setblock 182 40 345 minecraft:dark_prismarine
fill 182 40 346 182 40 349 minecraft:blue_terracotta
setblock 182 40 350 minecraft:dark_prismarine
fill 182 40 351 182 43 351 minecraft:blue_terracotta
fill 182 40 353 182 40 354 minecraft:blue_terracotta
setblock 182 40 355 minecraft:dark_prismarine
setblock 182 40 363 minecraft:purple_concrete
setblock 183 40 343 minecraft:cyan_concrete
setblock 141 41 339 minecraft:light_blue_wool
fill 141 41 340 141 106 341 minecraft:black_concrete
fill 142 41 326 142 41 328 minecraft:blue_terracotta
setblock 142 41 329 minecraft:dark_prismarine
fill 142 41 330 142 44 330 minecraft:blue_terracotta
fill 142 41 332 142 41 333 minecraft:blue_terracotta
setblock 142 41 334 minecraft:dark_prismarine
fill 142 41 335 143 43 335 minecraft:blue_terracotta
fill 142 41 337 142 41 338 minecraft:blue_terracotta
setblock 142 41 340 minecraft:purple_concrete
fill 142 41 345 142 41 348 minecraft:blue_terracotta
setblock 142 41 349 minecraft:dark_prismarine
fill 142 41 350 143 43 350 minecraft:blue_terracotta
setblock 142 41 354 minecraft:dark_prismarine
setblock 143 41 327 minecraft:blue_terracotta
setblock 143 41 328 minecraft:dark_prismarine
fill 143 41 329 144 43 329 minecraft:blue_terracotta
setblock 143 41 332 minecraft:blue_terracotta
setblock 143 41 333 minecraft:dark_prismarine
fill 143 41 334 143 44 334 minecraft:blue_terracotta
fill 143 41 336 143 42 336 minecraft:blue_terracotta
fill 143 41 349 143 44 349 minecraft:blue_terracotta
fill 143 41 351 143 42 351 minecraft:blue_terracotta
setblock 144 41 325 minecraft:light[level=12]
fill 144 41 330 144 41 331 minecraft:blue_terracotta
setblock 144 41 332 minecraft:dark_prismarine
fill 144 41 333 144 44 333 minecraft:blue_terracotta
setblock 144 41 339 minecraft:light[level=12]
setblock 144 41 346 minecraft:light[level=12]
setblock 144 41 353 minecraft:light[level=12]
setblock 144 41 360 minecraft:light[level=12]
setblock 144 41 363 minecraft:purple_concrete
fill 145 41 322 145 131 322 minecraft:black_concrete
fill 145 41 323 147 41 323 minecraft:blue_terracotta
setblock 146 41 324 minecraft:blue_terracotta
setblock 147 41 324 minecraft:dark_prismarine
setblock 148 41 323 minecraft:dark_prismarine
fill 148 41 324 150 41 325 minecraft:blue_terracotta
fill 149 41 323 152 41 323 minecraft:blue_terracotta
setblock 151 41 324 minecraft:blue_terracotta
setblock 151 41 325 minecraft:dark_prismarine
setblock 151 41 332 minecraft:light[level=12]
setblock 151 41 339 minecraft:light[level=12]
setblock 151 41 346 minecraft:light[level=12]
setblock 151 41 353 minecraft:light[level=12]
setblock 151 41 360 minecraft:light[level=12]
setblock 152 41 324 minecraft:dark_prismarine
setblock 153 41 323 minecraft:dark_prismarine
fill 153 41 324 153 42 324 minecraft:blue_terracotta
fill 154 41 323 156 41 323 minecraft:blue_terracotta
setblock 158 41 325 minecraft:light[level=12]
fill 158 41 329 161 42 329 minecraft:magenta_terracotta
setblock 158 41 332 minecraft:light[level=12]
setblock 158 41 339 minecraft:light[level=12]
setblock 158 41 346 minecraft:light[level=12]
setblock 158 41 353 minecraft:light[level=12]
setblock 158 41 360 minecraft:light[level=12]
fill 159 41 328 161 52 328 minecraft:magenta_terracotta
setblock 161 41 323 minecraft:purple_concrete
setblock 162 41 323 minecraft:blue_terracotta
setblock 163 41 323 minecraft:dark_prismarine
setblock 163 41 363 minecraft:dark_prismarine
fill 164 41 323 167 41 323 minecraft:blue_terracotta
fill 164 41 341 166 41 341 minecraft:purple_concrete
fill 164 41 363 167 41 363 minecraft:blue_terracotta
fill 165 41 324 166 41 324 minecraft:blue_terracotta
setblock 165 41 325 minecraft:light[level=12]
setblock 165 41 332 minecraft:light[level=12]
setblock 165 41 339 minecraft:light[level=12]
setblock 165 41 346 minecraft:light[level=12]
setblock 165 41 353 minecraft:light[level=12]
setblock 165 41 360 minecraft:light[level=12]
fill 166 41 362 168 41 362 minecraft:blue_terracotta
setblock 167 41 324 minecraft:dark_prismarine
setblock 168 41 323 minecraft:dark_prismarine
fill 168 41 324 169 41 324 minecraft:blue_terracotta
setblock 168 41 363 minecraft:dark_prismarine
fill 169 41 323 171 42 323 minecraft:blue_terracotta
setblock 169 41 362 minecraft:dark_prismarine
fill 169 41 363 172 41 363 minecraft:blue_terracotta
fill 170 41 362 170 44 362 minecraft:blue_terracotta
fill 171 41 340 180 41 340 minecraft:purple_concrete
setblock 172 41 325 minecraft:light[level=12]
setblock 172 41 332 minecraft:light[level=12]
setblock 172 41 339 minecraft:light[level=12]
setblock 172 41 346 minecraft:light[level=12]
setblock 172 41 353 minecraft:light[level=12]
setblock 172 41 360 minecraft:light[level=12]
setblock 173 41 363 minecraft:dark_prismarine
fill 177 41 338 177 102 338 minecraft:magenta_terracotta
setblock 179 41 325 minecraft:light[level=12]
setblock 179 41 332 minecraft:light[level=12]
setblock 179 41 339 minecraft:light[level=12]
setblock 179 41 346 minecraft:light[level=12]
setblock 179 41 353 minecraft:light[level=12]
setblock 179 41 360 minecraft:light[level=12]
setblock 180 41 323 minecraft:purple_concrete
fill 180 41 339 181 41 339 minecraft:purple_concrete
fill 181 41 348 181 41 349 minecraft:blue_terracotta
setblock 181 41 350 minecraft:dark_prismarine
fill 181 41 351 181 44 351 minecraft:blue_terracotta
fill 181 41 353 182 41 353 minecraft:blue_terracotta
setblock 182 41 329 minecraft:dark_prismarine
fill 182 41 330 182 41 333 minecraft:blue_terracotta
setblock 182 41 334 minecraft:dark_prismarine
setblock 182 41 344 minecraft:dark_prismarine
fill 182 41 345 182 41 348 minecraft:blue_terracotta
setblock 182 41 349 minecraft:dark_prismarine
fill 182 41 350 182 44 350 minecraft:blue_terracotta
setblock 182 41 354 minecraft:dark_prismarine
fill 182 41 355 182 43 356 minecraft:blue_terracotta
fill 183 41 343 183 125 343 minecraft:black_concrete
fill 141 42 339 141 131 339 minecraft:black_concrete
fill 142 42 325 142 42 327 minecraft:blue_terracotta
setblock 142 42 328 minecraft:dark_prismarine
fill 142 42 329 142 45 329 minecraft:blue_terracotta
setblock 142 42 332 minecraft:blue_terracotta
setblock 142 42 333 minecraft:dark_prismarine
fill 142 42 334 142 45 334 minecraft:blue_terracotta
setblock 142 42 337 minecraft:blue_terracotta
setblock 142 42 338 minecraft:dark_prismarine
fill 142 42 339 142 42 342 minecraft:blue_terracotta
setblock 142 42 343 minecraft:dark_prismarine
fill 142 42 344 142 42 347 minecraft:blue_terracotta
setblock 142 42 348 minecraft:dark_prismarine
fill 142 42 349 142 45 349 minecraft:blue_terracotta
setblock 142 42 353 minecraft:dark_prismarine
fill 142 42 354 142 44 355 minecraft:blue_terracotta
setblock 143 42 326 minecraft:blue_terracotta
setblock 143 42 327 minecraft:dark_prismarine
fill 143 42 328 144 44 328 minecraft:blue_terracotta
setblock 143 42 332 minecraft:dark_prismarine
fill 143 42 333 143 45 333 minecraft:blue_terracotta
setblock 143 42 337 minecraft:dark_prismarine
fill 143 42 338 143 45 338 minecraft:blue_terracotta
setblock 143 42 352 minecraft:dark_prismarine
fill 143 42 353 143 45 353 minecraft:blue_terracotta
fill 144 42 323 146 42 323 minecraft:blue_terracotta
setblock 144 42 330 minecraft:blue_terracotta
setblock 144 42 331 minecraft:dark_prismarine
fill 144 42 332 145 44 332 minecraft:blue_terracotta
fill 144 42 334 144 42 335 minecraft:blue_terracotta
setblock 144 42 336 minecraft:dark_prismarine
setblock 145 42 324 minecraft:blue_terracotta
setblock 145 42 330 minecraft:dark_prismarine
fill 145 42 331 145 45 331 minecraft:blue_terracotta
fill 145 42 333 145 43 333 minecraft:blue_terracotta
setblock 146 42 324 minecraft:dark_prismarine
setblock 147 42 323 minecraft:dark_prismarine
fill 147 42 324 149 42 325 minecraft:blue_terracotta
fill 147 42 349 149 56 351 minecraft:magenta_terracotta
fill 148 42 323 151 42 323 minecraft:blue_terracotta
setblock 150 42 324 minecraft:blue_terracotta
setblock 150 42 325 minecraft:dark_prismarine
fill 150 42 349 150 50 350 minecraft:magenta_terracotta
setblock 150 42 363 minecraft:purple_concrete
setblock 151 42 324 minecraft:dark_prismarine
setblock 152 42 323 minecraft:dark_prismarine
fill 152 42 324 152 44 324 minecraft:blue_terracotta
fill 153 42 323 155 43 323 minecraft:blue_terracotta
setblock 161 42 323 minecraft:blue_terracotta
setblock 162 42 323 minecraft:dark_prismarine
fill 162 42 330 162 97 330 minecraft:magenta_terracotta
setblock 162 42 363 minecraft:dark_prismarine
fill 163 42 323 166 42 323 minecraft:blue_terracotta
fill 163 42 363 166 42 363 minecraft:blue_terracotta
setblock 165 42 324 minecraft:blue_terracotta
fill 165 42 362 167 42 362 minecraft:blue_terracotta
setblock 166 42 324 minecraft:dark_prismarine
setblock 167 42 323 minecraft:dark_prismarine
fill 167 42 324 168 43 324 minecraft:blue_terracotta
setblock 167 42 363 minecraft:dark_prismarine
fill 168 42 323 168 45 323 minecraft:blue_terracotta
setblock 168 42 362 minecraft:dark_prismarine
fill 168 42 363 171 42 363 minecraft:blue_terracotta
fill 169 42 362 169 45 362 minecraft:blue_terracotta
setblock 172 42 363 minecraft:dark_prismarine
setblock 174 42 323 minecraft:purple_concrete
setblock 181 42 348 minecraft:blue_terracotta
setblock 181 42 349 minecraft:dark_prismarine
fill 181 42 350 181 45 350 minecraft:blue_terracotta
setblock 181 42 353 minecraft:blue_terracotta
setblock 181 42 354 minecraft:dark_prismarine
fill 181 42 355 181 45 355 minecraft:blue_terracotta
setblock 182 42 328 minecraft:dark_prismarine
fill 182 42 329 182 42 332 minecraft:blue_terracotta
setblock 182 42 333 minecraft:dark_prismarine
fill 182 42 334 182 42 337 minecraft:blue_terracotta
setblock 182 42 338 minecraft:dark_prismarine
setblock 182 42 340 minecraft:purple_concrete
setblock 182 42 343 minecraft:dark_prismarine
fill 182 42 344 182 42 347 minecraft:blue_terracotta
setblock 182 42 348 minecraft:dark_prismarine
fill 182 42 349 182 45 349 minecraft:blue_terracotta
setblock 182 42 353 minecraft:dark_prismarine
fill 182 42 354 182 45 354 minecraft:blue_terracotta
setblock 182 42 357 minecraft:blue_terracotta
setblock 182 42 359 minecraft:purple_concrete
fill 142 43 325 142 43 326 minecraft:blue_terracotta
setblock 142 43 327 minecraft:dark_prismarine
fill 142 43 328 142 46 328 minecraft:blue_terracotta
setblock 142 43 332 minecraft:dark_prismarine
fill 142 43 333 142 46 333 minecraft:blue_terracotta
setblock 142 43 337 minecraft:dark_prismarine
fill 142 43 338 142 43 341 minecraft:blue_terracotta
setblock 142 43 342 minecraft:dark_prismarine
fill 142 43 343 142 43 346 minecraft:blue_terracotta
setblock 142 43 347 minecraft:dark_prismarine
fill 142 43 348 143 45 348 minecraft:blue_terracotta
setblock 142 43 352 minecraft:dark_prismarine
fill 142 43 353 142 46 353 minecraft:blue_terracotta
setblock 142 43 356 minecraft:blue_terracotta
setblock 142 43 357 minecraft:dark_prismarine
fill 143 43 323 145 43 323 minecraft:blue_terracotta
setblock 143 43 326 minecraft:dark_prismarine
fill 143 43 327 144 45 327 minecraft:blue_terracotta
setblock 143 43 331 minecraft:dark_prismarine
fill 143 43 332 143 46 332 minecraft:blue_terracotta
setblock 143 43 336 minecraft:dark_prismarine
fill 143 43 337 144 45 337 minecraft:blue_terracotta
fill 143 43 339 143 43 340 minecraft:blue_terracotta
setblock 143 43 351 minecraft:dark_prismarine
fill 143 43 352 143 46 352 minecraft:blue_terracotta
fill 143 43 354 143 43 355 minecraft:blue_terracotta
setblock 144 43 330 minecraft:dark_prismarine
fill 144 43 331 144 46 331 minecraft:blue_terracotta
setblock 144 43 334 minecraft:blue_terracotta
setblock 144 43 335 minecraft:dark_prismarine
fill 144 43 336 144 46 336 minecraft:blue_terracotta
setblock 145 43 324 minecraft:dark_prismarine
setblock 145 43 329 minecraft:dark_prismarine
fill 145 43 330 145 46 330 minecraft:blue_terracotta
setblock 146 43 323 minecraft:dark_prismarine
fill 146 43 324 149 43 324 minecraft:blue_terracotta
fill 147 43 323 150 43 323 minecraft:blue_terracotta
fill 147 43 325 148 43 325 minecraft:blue_terracotta
fill 147 43 363 150 43 363 minecraft:blue_terracotta
setblock 149 43 325 minecraft:dark_prismarine
setblock 150 43 324 minecraft:dark_prismarine
setblock 150 43 325 minecraft:blue_terracotta
setblock 151 43 323 minecraft:dark_prismarine
fill 151 43 324 151 46 324 minecraft:blue_terracotta
fill 152 43 323 152 46 323 minecraft:blue_terracotta
setblock 156 43 363 minecraft:purple_concrete
fill 159 43 329 161 56 329 minecraft:magenta_terracotta
setblock 160 43 323 minecraft:blue_terracotta
fill 160 43 327 161 48 327 minecraft:magenta_terracotta
setblock 161 43 323 minecraft:dark_prismarine
setblock 161 43 363 minecraft:dark_prismarine
fill 162 43 323 165 43 323 minecraft:blue_terracotta
fill 162 43 363 165 43 363 minecraft:blue_terracotta
fill 163 43 362 166 43 362 minecraft:blue_terracotta
setblock 164 43 324 minecraft:blue_terracotta
setblock 165 43 324 minecraft:dark_prismarine
setblock 166 43 323 minecraft:dark_prismarine
fill 166 43 324 166 46 324 minecraft:blue_terracotta
fill 166 43 361 167 43 361 minecraft:blue_terracotta
setblock 166 43 363 minecraft:dark_prismarine
fill 167 43 323 167 46 323 minecraft:blue_terracotta
setblock 167 43 362 minecraft:dark_prismarine
fill 167 43 363 170 43 363 minecraft:blue_terracotta
setblock 168 43 361 minecraft:dark_prismarine
fill 168 43 362 168 46 362 minecraft:blue_terracotta
fill 169 43 323 170 43 323 minecraft:blue_terracotta
setblock 171 43 362 minecraft:blue_terracotta
setblock 171 43 363 minecraft:dark_prismarine
fill 172 43 363 172 46 363 minecraft:blue_terracotta
setblock 175 43 363 minecraft:purple_concrete
fill 179 43 353 179 47 353 minecraft:black_concrete
setblock 180 43 352 minecraft:black_concrete
setblock 181 43 347 minecraft:blue_terracotta
setblock 181 43 348 minecraft:dark_prismarine
fill 181 43 349 181 46 349 minecraft:blue_terracotta
setblock 181 43 352 minecraft:blue_terracotta
setblock 181 43 353 minecraft:dark_prismarine
fill 181 43 354 181 46 354 minecraft:blue_terracotta
fill 181 43 356 181 44 356 minecraft:blue_terracotta
setblock 182 43 327 minecraft:dark_prismarine
fill 182 43 328 182 43 331 minecraft:blue_terracotta
setblock 182 43 332 minecraft:dark_prismarine
fill 182 43 333 182 43 336 minecraft:blue_terracotta
setblock 182 43 337 minecraft:dark_prismarine
fill 182 43 338 182 43 341 minecraft:blue_terracotta
setblock 182 43 342 minecraft:dark_prismarine
fill 182 43 343 182 43 346 minecraft:blue_terracotta
setblock 182 43 347 minecraft:dark_prismarine
fill 182 43 348 182 46 348 minecraft:blue_terracotta
setblock 182 43 352 minecraft:dark_prismarine
fill 182 43 353 182 46 353 minecraft:blue_terracotta
setblock 182 43 357 minecraft:dark_prismarine
fill 182 43 358 182 45 359 minecraft:blue_terracotta
fill 142 44 324 142 44 325 minecraft:blue_terracotta
setblock 142 44 326 minecraft:dark_prismarine
fill 142 44 327 142 47 327 minecraft:blue_terracotta
setblock 142 44 331 minecraft:dark_prismarine
fill 142 44 332 142 47 332 minecraft:blue_terracotta
setblock 142 44 335 minecraft:blue_terracotta
setblock 142 44 336 minecraft:dark_prismarine
fill 142 44 337 142 44 340 minecraft:blue_terracotta
setblock 142 44 341 minecraft:dark_prismarine
fill 142 44 342 142 44 345 minecraft:blue_terracotta
setblock 142 44 346 minecraft:dark_prismarine
fill 142 44 347 142 47 347 minecraft:blue_terracotta
setblock 142 44 350 minecraft:blue_terracotta
setblock 142 44 351 minecraft:dark_prismarine
fill 142 44 352 142 47 352 minecraft:blue_terracotta
setblock 142 44 356 minecraft:dark_prismarine
fill 142 44 357 142 45 359 minecraft:blue_terracotta
fill 143 44 323 144 44 323 minecraft:blue_terracotta
setblock 143 44 325 minecraft:dark_prismarine
fill 143 44 326 143 47 326 minecraft:blue_terracotta
setblock 143 44 329 minecraft:blue_terracotta
setblock 143 44 330 minecraft:dark_prismarine
fill 143 44 331 143 47 331 minecraft:blue_terracotta
setblock 143 44 335 minecraft:dark_prismarine
fill 143 44 336 143 47 336 minecraft:blue_terracotta
setblock 143 44 339 minecraft:blue_terracotta
setblock 143 44 340 minecraft:dark_prismarine
fill 143 44 341 143 46 342 minecraft:blue_terracotta
setblock 143 44 350 minecraft:dark_prismarine
fill 143 44 351 143 47 351 minecraft:blue_terracotta
setblock 143 44 354 minecraft:blue_terracotta
setblock 143 44 355 minecraft:dark_prismarine
fill 143 44 356 143 47 356 minecraft:blue_terracotta
setblock 144 44 324 minecraft:dark_prismarine
setblock 144 44 329 minecraft:dark_prismarine
fill 144 44 330 144 47 330 minecraft:blue_terracotta
setblock 144 44 334 minecraft:dark_prismarine
fill 144 44 335 144 47 335 minecraft:blue_terracotta
setblock 144 44 338 minecraft:blue_terracotta
setblock 144 44 339 minecraft:dark_prismarine
setblock 145 44 323 minecraft:dark_prismarine
fill 145 44 324 148 44 324 minecraft:blue_terracotta
setblock 145 44 328 minecraft:dark_prismarine
fill 145 44 329 145 47 329 minecraft:blue_terracotta
setblock 145 44 333 minecraft:dark_prismarine
fill 145 44 334 145 47 334 minecraft:blue_terracotta
fill 145 44 335 148 44 337 minecraft:magenta_terracotta
setblock 145 44 363 minecraft:dark_prismarine
fill 146 44 323 149 44 323 minecraft:blue_terracotta
fill 146 44 325 147 44 325 minecraft:blue_terracotta
setblock 146 44 331 minecraft:blue_terracotta
setblock 146 44 332 minecraft:dark_prismarine
fill 146 44 333 146 47 333 minecraft:blue_terracotta
fill 146 44 334 148 67 334 minecraft:magenta_terracotta
fill 146 44 363 149 44 363 minecraft:blue_terracotta
setblock 148 44 325 minecraft:dark_prismarine
setblock 149 44 324 minecraft:dark_prismarine
fill 149 44 325 149 45 325 minecraft:blue_terracotta
setblock 150 44 323 minecraft:dark_prismarine
fill 150 44 324 150 47 324 minecraft:blue_terracotta
setblock 150 44 363 minecraft:dark_prismarine
fill 151 44 323 151 47 323 minecraft:blue_terracotta
fill 151 44 363 151 47 363 minecraft:blue_terracotta
fill 153 44 323 154 44 323 minecraft:blue_terracotta
setblock 155 44 323 minecraft:dark_prismarine
setblock 159 44 323 minecraft:blue_terracotta
setblock 159 44 363 minecraft:blue_terracotta
setblock 160 44 323 minecraft:dark_prismarine
setblock 160 44 363 minecraft:dark_prismarine
fill 161 44 323 164 44 323 minecraft:blue_terracotta
fill 161 44 331 161 77 331 minecraft:magenta_terracotta
fill 161 44 363 164 44 363 minecraft:blue_terracotta
fill 162 44 362 165 44 362 minecraft:blue_terracotta
setblock 164 44 324 minecraft:dark_prismarine
fill 164 44 361 166 44 361 minecraft:blue_terracotta
setblock 165 44 323 minecraft:dark_prismarine
fill 165 44 324 165 46 324 minecraft:blue_terracotta
setblock 165 44 363 minecraft:dark_prismarine
fill 166 44 323 166 47 323 minecraft:blue_terracotta
setblock 166 44 362 minecraft:dark_prismarine
fill 166 44 363 169 44 363 minecraft:blue_terracotta
fill 167 44 324 167 45 324 minecraft:blue_terracotta
setblock 167 44 361 minecraft:dark_prismarine
fill 167 44 362 167 47 362 minecraft:blue_terracotta
fill 168 44 361 169 46 361 minecraft:blue_terracotta
setblock 169 44 323 minecraft:blue_terracotta
setblock 170 44 323 minecraft:dark_prismarine
setblock 170 44 363 minecraft:dark_prismarine
setblock 171 44 362 minecraft:dark_prismarine
fill 171 44 363 171 47 363 minecraft:blue_terracotta
fill 174 44 336 176 44 338 minecraft:magenta_terracotta
fill 175 44 335 176 56 335 minecraft:magenta_terracotta
setblock 180 44 352 minecraft:blue_terracotta
setblock 180 44 353 minecraft:dark_prismarine
setblock 181 44 331 minecraft:blue_terracotta
setblock 181 44 332 minecraft:dark_prismarine
fill 181 44 333 181 44 336 minecraft:blue_terracotta
setblock 181 44 337 minecraft:dark_prismarine
fill 181 44 338 182 46 338 minecraft:blue_terracotta
setblock 181 44 347 minecraft:dark_prismarine
fill 181 44 348 181 47 348 minecraft:blue_terracotta
setblock 181 44 352 minecraft:dark_prismarine
fill 181 44 353 181 47 353 minecraft:blue_terracotta
setblock 181 44 357 minecraft:dark_prismarine
setblock 181 44 363 minecraft:purple_concrete
fill 182 44 327 182 44 330 minecraft:blue_terracotta
setblock 182 44 331 minecraft:dark_prismarine
fill 182 44 332 182 44 335 minecraft:blue_terracotta
setblock 182 44 336 minecraft:dark_prismarine
fill 182 44 337 182 47 337 minecraft:blue_terracotta
fill 182 44 339 182 44 340 minecraft:blue_terracotta
setblock 182 44 341 minecraft:dark_prismarine
fill 182 44 342 182 44 345 minecraft:blue_terracotta
setblock 182 44 346 minecraft:dark_prismarine
fill 182 44 347 182 47 347 minecraft:blue_terracotta
setblock 182 44 351 minecraft:dark_prismarine
fill 182 44 352 182 47 352 minecraft:blue_terracotta
setblock 182 44 355 minecraft:blue_terracotta
setblock 182 44 356 minecraft:dark_prismarine
fill 182 44 357 182 47 357 minecraft:blue_terracotta
setblock 182 44 360 minecraft:blue_terracotta
fill 183 44 353 183 132 353 minecraft:black_concrete
setblock 183 44 354 minecraft:light_blue_wool
fill 183 44 355 183 131 356 minecraft:black_concrete
fill 142 45 323 142 45 324 minecraft:blue_terracotta
setblock 142 45 325 minecraft:dark_prismarine
fill 142 45 326 142 48 326 minecraft:blue_terracotta
setblock 142 45 330 minecraft:dark_prismarine
fill 142 45 331 142 48 331 minecraft:blue_terracotta
setblock 142 45 335 minecraft:dark_prismarine
fill 142 45 336 142 45 339 minecraft:blue_terracotta
setblock 142 45 340 minecraft:dark_prismarine
fill 142 45 341 142 45 344 minecraft:blue_terracotta
setblock 142 45 345 minecraft:dark_prismarine
fill 142 45 346 142 48 346 minecraft:blue_terracotta
setblock 142 45 350 minecraft:dark_prismarine
fill 142 45 351 142 48 351 minecraft:blue_terracotta
setblock 142 45 354 minecraft:blue_terracotta
setblock 142 45 355 minecraft:dark_prismarine
fill 142 45 356 142 48 356 minecraft:blue_terracotta
setblock 142 45 360 minecraft:dark_prismarine
setblock 143 45 323 minecraft:blue_terracotta
setblock 143 45 324 minecraft:dark_prismarine
fill 143 45 325 143 48 325 minecraft:blue_terracotta
setblock 143 45 328 minecraft:blue_terracotta
setblock 143 45 329 minecraft:dark_prismarine
fill 143 45 330 143 48 330 minecraft:blue_terracotta
setblock 143 45 334 minecraft:dark_prismarine
fill 143 45 335 143 48 335 minecraft:blue_terracotta
setblock 143 45 339 minecraft:dark_prismarine
fill 143 45 340 144 47 340 minecraft:blue_terracotta
setblock 143 45 343 minecraft:blue_terracotta
setblock 143 45 349 minecraft:dark_prismarine
fill 143 45 350 143 47 350 minecraft:blue_terracotta
setblock 143 45 354 minecraft:dark_prismarine
fill 143 45 355 143 48 355 minecraft:blue_terracotta
fill 143 45 357 143 45 358 minecraft:blue_terracotta
setblock 143 45 363 minecraft:purple_concrete
setblock 144 45 323 minecraft:dark_prismarine
fill 144 45 324 147 45 324 minecraft:blue_terracotta
setblock 144 45 325 minecraft:light[level=13]
fill 144 45 326 144 46 326 minecraft:blue_terracotta
setblock 144 45 328 minecraft:dark_prismarine
fill 144 45 329 144 48 329 minecraft:blue_terracotta
setblock 144 45 332 minecraft:blue_terracotta
setblock 144 45 333 minecraft:dark_prismarine
fill 144 45 334 144 48 334 minecraft:blue_terracotta
setblock 144 45 338 minecraft:dark_prismarine
fill 144 45 339 144 48 339 minecraft:blue_terracotta
setblock 144 45 341 minecraft:light[level=13]
setblock 144 45 349 minecraft:light[level=13]
setblock 144 45 353 minecraft:dark_prismarine
fill 144 45 354 144 47 354 minecraft:blue_terracotta
setblock 144 45 357 minecraft:light[level=13]
setblock 144 45 363 minecraft:dark_prismarine
fill 145 45 323 148 45 323 minecraft:blue_terracotta
fill 145 45 325 146 45 325 minecraft:blue_terracotta
fill 145 45 328 145 46 328 minecraft:blue_terracotta
setblock 145 45 332 minecraft:dark_prismarine
fill 145 45 333 145 48 333 minecraft:blue_terracotta
fill 145 45 335 148 58 336 minecraft:magenta_terracotta
setblock 145 45 337 minecraft:dark_prismarine
fill 145 45 338 145 48 338 minecraft:blue_terracotta
fill 145 45 363 148 45 363 minecraft:blue_terracotta
setblock 146 45 330 minecraft:blue_terracotta
setblock 146 45 331 minecraft:dark_prismarine
fill 146 45 332 146 47 332 minecraft:blue_terracotta
fill 146 45 337 148 75 337 minecraft:magenta_terracotta
setblock 147 45 325 minecraft:dark_prismarine
setblock 148 45 324 minecraft:dark_prismarine
fill 148 45 325 148 46 325 minecraft:blue_terracotta
setblock 149 45 323 minecraft:dark_prismarine
fill 149 45 324 149 48 324 minecraft:blue_terracotta
setblock 149 45 363 minecraft:dark_prismarine
fill 150 45 323 150 48 323 minecraft:blue_terracotta
fill 150 45 363 150 48 363 minecraft:blue_terracotta
setblock 152 45 325 minecraft:light[level=13]
setblock 152 45 333 minecraft:light[level=13]
setblock 152 45 341 minecraft:light[level=13]
setblock 152 45 349 minecraft:light[level=13]
setblock 152 45 357 minecraft:light[level=13]
fill 152 45 363 152 46 363 minecraft:blue_terracotta
setblock 153 45 323 minecraft:blue_terracotta
setblock 154 45 323 minecraft:dark_prismarine
fill 155 45 323 156 46 323 minecraft:blue_terracotta
setblock 158 45 323 minecraft:blue_terracotta
setblock 158 45 363 minecraft:blue_terracotta
setblock 159 45 323 minecraft:dark_prismarine
setblock 159 45 363 minecraft:dark_prismarine
fill 160 45 323 163 45 323 minecraft:blue_terracotta
setblock 160 45 325 minecraft:light[level=13]
setblock 160 45 333 minecraft:light[level=13]
setblock 160 45 341 minecraft:light[level=13]
setblock 160 45 349 minecraft:light[level=13]
setblock 160 45 357 minecraft:light[level=13]
fill 160 45 363 163 45 363 minecraft:blue_terracotta
fill 161 45 362 164 45 362 minecraft:blue_terracotta
setblock 163 45 324 minecraft:dark_prismarine
fill 163 45 358 164 60 358 minecraft:magenta_terracotta
fill 163 45 361 165 45 361 minecraft:blue_terracotta
setblock 164 45 323 minecraft:dark_prismarine
fill 164 45 324 164 47 324 minecraft:blue_terracotta
setblock 164 45 363 minecraft:dark_prismarine
fill 165 45 323 165 48 323 minecraft:blue_terracotta
fill 165 45 360 166 45 360 minecraft:blue_terracotta
setblock 165 45 362 minecraft:dark_prismarine
fill 165 45 363 168 45 363 minecraft:blue_terracotta
setblock 166 45 361 minecraft:dark_prismarine
fill 166 45 362 166 48 362 minecraft:blue_terracotta
setblock 167 45 360 minecraft:dark_prismarine
fill 167 45 361 167 48 361 minecraft:blue_terracotta
setblock 168 45 325 minecraft:light[level=13]
setblock 168 45 333 minecraft:light[level=13]
setblock 168 45 341 minecraft:light[level=13]
setblock 168 45 349 minecraft:light[level=13]
setblock 168 45 357 minecraft:light[level=13]
fill 168 45 360 168 48 360 minecraft:blue_terracotta
setblock 169 45 323 minecraft:dark_prismarine
setblock 169 45 363 minecraft:dark_prismarine
setblock 170 45 323 minecraft:blue_terracotta
setblock 170 45 361 minecraft:blue_terracotta
setblock 170 45 362 minecraft:dark_prismarine
fill 170 45 363 170 48 363 minecraft:blue_terracotta
fill 171 45 362 171 48 362 minecraft:blue_terracotta
fill 174 45 336 176 53 337 minecraft:magenta_terracotta
fill 174 45 353 174 46 354 minecraft:black_concrete
fill 175 45 323 175 46 323 minecraft:purple_concrete
fill 175 45 338 176 74 338 minecraft:magenta_terracotta
setblock 176 45 325 minecraft:light[level=13]
setblock 176 45 333 minecraft:light[level=13]
setblock 176 45 341 minecraft:light[level=13]
setblock 176 45 357 minecraft:light[level=13]
fill 178 45 353 178 47 353 minecraft:black_concrete
fill 180 45 351 180 47 351 minecraft:black_concrete
setblock 180 45 352 minecraft:dark_prismarine
fill 180 45 353 180 46 355 minecraft:blue_terracotta
setblock 181 45 323 minecraft:purple_concrete
setblock 181 45 330 minecraft:blue_terracotta
setblock 181 45 331 minecraft:dark_prismarine
fill 181 45 332 181 45 335 minecraft:blue_terracotta
setblock 181 45 336 minecraft:dark_prismarine
fill 181 45 337 181 48 337 minecraft:blue_terracotta
fill 181 45 339 181 45 340 minecraft:blue_terracotta
setblock 181 45 341 minecraft:dark_prismarine
setblock 181 45 346 minecraft:dark_prismarine
fill 181 45 347 181 48 347 minecraft:blue_terracotta
setblock 181 45 351 minecraft:dark_prismarine
fill 181 45 352 181 48 352 minecraft:blue_terracotta
setblock 181 45 356 minecraft:dark_prismarine
fill 181 45 357 181 47 358 minecraft:blue_terracotta
fill 182 45 326 182 45 329 minecraft:blue_terracotta
setblock 182 45 330 minecraft:dark_prismarine
fill 182 45 331 182 45 334 minecraft:blue_terracotta
setblock 182 45 335 minecraft:dark_prismarine
fill 182 45 336 182 48 336 minecraft:blue_terracotta
setblock 182 45 339 minecraft:blue_terracotta
setblock 182 45 340 minecraft:dark_prismarine
fill 182 45 341 182 45 344 minecraft:blue_terracotta
setblock 182 45 345 minecraft:dark_prismarine
fill 182 45 346 182 48 346 minecraft:blue_terracotta
setblock 182 45 350 minecraft:dark_prismarine
fill 182 45 351 182 48 351 minecraft:blue_terracotta
setblock 182 45 355 minecraft:dark_prismarine
fill 182 45 356 182 48 356 minecraft:blue_terracotta
setblock 182 45 360 minecraft:dark_prismarine
fill 182 45 361 182 48 361 minecraft:blue_terracotta
fill 183 45 354 183 131 354 minecraft:black_concrete
setblock 142 46 323 minecraft:blue_terracotta
setblock 142 46 324 minecraft:dark_prismarine
fill 142 46 325 142 49 325 minecraft:blue_terracotta
setblock 142 46 329 minecraft:dark_prismarine
fill 142 46 330 142 49 330 minecraft:blue_terracotta
setblock 142 46 334 minecraft:dark_prismarine
fill 142 46 335 142 46 338 minecraft:blue_terracotta
setblock 142 46 339 minecraft:dark_prismarine
fill 142 46 340 142 46 343 minecraft:blue_terracotta
setblock 142 46 344 minecraft:dark_prismarine
fill 142 46 345 142 49 345 minecraft:blue_terracotta
setblock 142 46 348 minecraft:blue_terracotta
setblock 142 46 349 minecraft:dark_prismarine
fill 142 46 350 142 49 350 minecraft:blue_terracotta
setblock 142 46 354 minecraft:dark_prismarine
fill 142 46 355 142 49 355 minecraft:blue_terracotta
fill 142 46 357 142 46 358 minecraft:blue_terracotta
setblock 142 46 359 minecraft:dark_prismarine
fill 142 46 360 142 47 362 minecraft:blue_terracotta
setblock 143 46 323 minecraft:dark_prismarine
fill 143 46 324 146 46 324 minecraft:blue_terracotta
setblock 143 46 327 minecraft:blue_terracotta
setblock 143 46 328 minecraft:dark_prismarine
fill 143 46 329 143 49 329 minecraft:blue_terracotta
setblock 143 46 333 minecraft:dark_prismarine
fill 143 46 334 143 49 334 minecraft:blue_terracotta
setblock 143 46 337 minecraft:blue_terracotta
setblock 143 46 338 minecraft:dark_prismarine
fill 143 46 339 143 49 339 minecraft:blue_terracotta
setblock 143 46 343 minecraft:dark_prismarine
fill 143 46 344 143 49 344 minecraft:blue_terracotta
setblock 143 46 348 minecraft:dark_prismarine
setblock 143 46 349 minecraft:blue_terracotta
setblock 143 46 353 minecraft:dark_prismarine
fill 143 46 354 143 49 354 minecraft:blue_terracotta
setblock 143 46 357 minecraft:blue_terracotta
setblock 143 46 358 minecraft:dark_prismarine
fill 143 46 359 143 48 360 minecraft:blue_terracotta
setblock 143 46 363 minecraft:dark_prismarine
fill 144 46 323 147 46 323 minecraft:blue_terracotta
setblock 144 46 327 minecraft:dark_prismarine
fill 144 46 328 144 49 328 minecraft:blue_terracotta
setblock 144 46 332 minecraft:dark_prismarine
fill 144 46 333 144 49 333 minecraft:blue_terracotta
setblock 144 46 337 minecraft:dark_prismarine
fill 144 46 338 144 49 338 minecraft:blue_terracotta
setblock 144 46 341 minecraft:blue_terracotta
setblock 144 46 353 minecraft:blue_terracotta
fill 144 46 355 144 46 356 minecraft:blue_terracotta
fill 144 46 363 147 46 363 minecraft:blue_terracotta
setblock 145 46 325 minecraft:blue_terracotta
setblock 145 46 331 minecraft:dark_prismarine
fill 145 46 332 145 49 332 minecraft:blue_terracotta
fill 145 46 337 145 49 337 minecraft:blue_terracotta
fill 145 46 362 148 46 362 minecraft:blue_terracotta
setblock 146 46 325 minecraft:dark_prismarine
setblock 146 46 331 minecraft:blue_terracotta
fill 146 46 350 146 102 350 minecraft:magenta_terracotta
setblock 147 46 324 minecraft:dark_prismarine
setblock 147 46 325 minecraft:blue_terracotta
setblock 148 46 323 minecraft:dark_prismarine
fill 148 46 324 148 49 324 minecraft:blue_terracotta
setblock 148 46 363 minecraft:dark_prismarine
fill 149 46 323 149 49 323 minecraft:blue_terracotta
fill 149 46 363 149 49 363 minecraft:blue_terracotta
setblock 153 46 323 minecraft:dark_prismarine
setblock 153 46 363 minecraft:dark_prismarine
fill 154 46 323 154 47 323 minecraft:blue_terracotta
fill 154 46 363 157 46 363 minecraft:blue_terracotta
setblock 157 46 323 minecraft:blue_terracotta
setblock 158 46 323 minecraft:dark_prismarine
setblock 158 46 363 minecraft:dark_prismarine
fill 159 46 323 162 46 323 minecraft:blue_terracotta
setblock 159 46 362 minecraft:dark_prismarine
fill 159 46 363 162 46 363 minecraft:blue_terracotta
fill 160 46 362 163 46 362 minecraft:blue_terracotta
fill 161 46 361 164 46 361 minecraft:blue_terracotta
setblock 163 46 323 minecraft:dark_prismarine
fill 163 46 324 163 47 324 minecraft:blue_terracotta
fill 163 46 360 165 46 360 minecraft:blue_terracotta
setblock 163 46 363 minecraft:dark_prismarine
fill 164 46 323 164 49 323 minecraft:blue_terracotta
setblock 164 46 362 minecraft:dark_prismarine
fill 164 46 363 167 46 363 minecraft:blue_terracotta
setblock 165 46 361 minecraft:dark_prismarine
fill 165 46 362 165 49 362 minecraft:blue_terracotta
setblock 166 46 360 minecraft:dark_prismarine
fill 166 46 361 166 49 361 minecraft:blue_terracotta
fill 167 46 360 167 49 360 minecraft:blue_terracotta
setblock 168 46 323 minecraft:dark_prismarine
setblock 168 46 363 minecraft:dark_prismarine
setblock 169 46 323 minecraft:blue_terracotta
setblock 169 46 362 minecraft:dark_prismarine
fill 169 46 363 169 49 363 minecraft:blue_terracotta
setblock 169 46 364 minecraft:light_blue_wool
setblock 170 46 361 minecraft:dark_prismarine
fill 170 46 362 170 49 362 minecraft:blue_terracotta
fill 170 46 364 171 128 364 minecraft:black_concrete
setblock 174 46 363 minecraft:purple_concrete
fill 180 46 334 180 46 335 minecraft:blue_terracotta
setblock 180 46 336 minecraft:dark_prismarine
setblock 180 46 352 minecraft:blue_terracotta
setblock 180 46 356 minecraft:dark_prismarine
setblock 181 46 330 minecraft:dark_prismarine
fill 181 46 331 181 46 334 minecraft:blue_terracotta
setblock 181 46 335 minecraft:dark_prismarine
fill 181 46 336 181 49 336 minecraft:blue_terracotta
setblock 181 46 339 minecraft:blue_terracotta
setblock 181 46 340 minecraft:dark_prismarine
fill 181 46 341 181 46 344 minecraft:blue_terracotta
setblock 181 46 345 minecraft:dark_prismarine
fill 181 46 346 181 49 346 minecraft:blue_terracotta
setblock 181 46 350 minecraft:dark_prismarine
fill 181 46 351 181 49 351 minecraft:blue_terracotta
setblock 181 46 355 minecraft:dark_prismarine
fill 181 46 356 181 49 356 minecraft:blue_terracotta
setblock 181 46 359 minecraft:blue_terracotta
fill 182 46 326 182 46 328 minecraft:blue_terracotta
setblock 182 46 329 minecraft:dark_prismarine
fill 182 46 330 182 46 333 minecraft:blue_terracotta
setblock 182 46 334 minecraft:dark_prismarine
fill 182 46 335 182 49 335 minecraft:blue_terracotta
setblock 182 46 339 minecraft:dark_prismarine
fill 182 46 340 182 46 343 minecraft:blue_terracotta
setblock 182 46 344 minecraft:dark_prismarine
fill 182 46 345 182 49 345 minecraft:blue_terracotta
setblock 182 46 349 minecraft:dark_prismarine
fill 182 46 350 182 49 350 minecraft:blue_terracotta
setblock 182 46 354 minecraft:dark_prismarine
fill 182 46 355 182 49 355 minecraft:blue_terracotta
setblock 182 46 358 minecraft:blue_terracotta
setblock 182 46 359 minecraft:dark_prismarine
fill 182 46 360 182 49 360 minecraft:blue_terracotta
fill 182 46 362 182 47 362 minecraft:blue_terracotta
setblock 142 47 323 minecraft:dark_prismarine
fill 142 47 324 145 47 324 minecraft:blue_terracotta
setblock 142 47 328 minecraft:dark_prismarine
fill 142 47 329 142 50 329 minecraft:blue_terracotta
setblock 142 47 333 minecraft:dark_prismarine
fill 142 47 334 142 47 337 minecraft:blue_terracotta
setblock 142 47 338 minecraft:dark_prismarine
fill 142 47 339 142 47 342 minecraft:blue_terracotta
setblock 142 47 343 minecraft:dark_prismarine
fill 142 47 344 142 50 344 minecraft:blue_terracotta
setblock 142 47 348 minecraft:dark_prismarine
fill 142 47 349 142 49 349 minecraft:blue_terracotta
setblock 142 47 353 minecraft:dark_prismarine
fill 142 47 354 142 50 354 minecraft:blue_terracotta
setblock 142 47 357 minecraft:blue_terracotta
setblock 142 47 358 minecraft:dark_prismarine
fill 142 47 359 142 50 359 minecraft:blue_terracotta
setblock 142 47 363 minecraft:dark_prismarine
fill 143 47 323 146 47 323 minecraft:blue_terracotta
setblock 143 47 327 minecraft:dark_prismarine
fill 143 47 328 143 50 328 minecraft:blue_terracotta
setblock 143 47 332 minecraft:dark_prismarine
fill 143 47 333 143 50 333 minecraft:blue_terracotta
setblock 143 47 337 minecraft:dark_prismarine
fill 143 47 338 143 50 338 minecraft:blue_terracotta
setblock 143 47 341 minecraft:blue_terracotta
setblock 143 47 342 minecraft:dark_prismarine
fill 143 47 343 143 50 343 minecraft:blue_terracotta
setblock 143 47 352 minecraft:dark_prismarine
fill 143 47 353 143 49 353 minecraft:blue_terracotta
setblock 143 47 357 minecraft:dark_prismarine
fill 143 47 358 143 50 358 minecraft:blue_terracotta
setblock 143 47 361 minecraft:blue_terracotta
fill 143 47 363 146 47 363 minecraft:blue_terracotta
setblock 144 47 325 minecraft:light[level=12]
setblock 144 47 326 minecraft:dark_prismarine
fill 144 47 327 144 48 327 minecraft:blue_terracotta
setblock 144 47 331 minecraft:dark_prismarine
fill 144 47 332 144 50 332 minecraft:blue_terracotta
setblock 144 47 336 minecraft:dark_prismarine
fill 144 47 337 144 50 337 minecraft:blue_terracotta
setblock 144 47 341 minecraft:dark_prismarine
setblock 144 47 346 minecraft:light[level=12]
setblock 144 47 353 minecraft:light[level=12]
setblock 144 47 355 minecraft:blue_terracotta
setblock 144 47 356 minecraft:dark_prismarine
fill 144 47 357 144 48 357 minecraft:blue_terracotta
setblock 144 47 360 minecraft:light[level=12]
fill 144 47 362 147 47 362 minecraft:blue_terracotta
setblock 145 47 325 minecraft:dark_prismarine
setblock 145 47 330 minecraft:dark_prismarine
fill 145 47 331 145 49 331 minecraft:blue_terracotta
setblock 145 47 339 minecraft:blue_terracotta
setblock 146 47 324 minecraft:dark_prismarine
setblock 146 47 325 minecraft:blue_terracotta
fill 146 47 349 146 84 349 minecraft:magenta_terracotta
setblock 147 47 323 minecraft:dark_prismarine
fill 147 47 324 147 50 324 minecraft:blue_terracotta
setblock 147 47 363 minecraft:dark_prismarine
fill 148 47 323 148 50 323 minecraft:blue_terracotta
setblock 148 47 362 minecraft:dark_prismarine
fill 148 47 363 148 50 363 minecraft:blue_terracotta
fill 149 47 362 149 49 362 minecraft:blue_terracotta
setblock 151 47 325 minecraft:light[level=12]
setblock 151 47 332 minecraft:light[level=12]
setblock 151 47 339 minecraft:light[level=12]
setblock 151 47 346 minecraft:light[level=12]
setblock 151 47 353 minecraft:light[level=12]
setblock 151 47 360 minecraft:light[level=12]
setblock 152 47 323 minecraft:dark_prismarine
setblock 152 47 363 minecraft:dark_prismarine
fill 153 47 323 153 48 323 minecraft:blue_terracotta
fill 153 47 363 156 47 363 minecraft:blue_terracotta
setblock 157 47 323 minecraft:dark_prismarine
setblock 157 47 363 minecraft:dark_prismarine
fill 158 47 323 161 47 323 minecraft:blue_terracotta
setblock 158 47 325 minecraft:light[level=12]
setblock 158 47 332 minecraft:light[level=12]
setblock 158 47 339 minecraft:light[level=12]
setblock 158 47 346 minecraft:light[level=12]
setblock 158 47 353 minecraft:light[level=12]
setblock 158 47 360 minecraft:light[level=12]
setblock 158 47 362 minecraft:dark_prismarine
fill 158 47 363 161 47 363 minecraft:blue_terracotta
fill 159 47 362 162 47 362 minecraft:blue_terracotta
fill 160 47 361 163 47 361 minecraft:blue_terracotta
setblock 162 47 323 minecraft:dark_prismarine
fill 162 47 360 164 47 360 minecraft:blue_terracotta
setblock 162 47 363 minecraft:dark_prismarine
fill 163 47 323 163 50 323 minecraft:blue_terracotta
setblock 163 47 362 minecraft:dark_prismarine
fill 163 47 363 166 47 363 minecraft:blue_terracotta
setblock 164 47 361 minecraft:dark_prismarine
fill 164 47 362 164 50 362 minecraft:blue_terracotta
setblock 165 47 325 minecraft:light[level=12]
setblock 165 47 332 minecraft:light[level=12]
setblock 165 47 339 minecraft:light[level=12]
setblock 165 47 346 minecraft:light[level=12]
setblock 165 47 353 minecraft:light[level=12]
setblock 165 47 359 minecraft:blue_terracotta
setblock 165 47 360 minecraft:dark_prismarine
fill 165 47 361 165 50 361 minecraft:blue_terracotta
fill 166 47 360 166 50 360 minecraft:blue_terracotta
setblock 167 47 323 minecraft:dark_prismarine
setblock 167 47 363 minecraft:dark_prismarine
fill 168 47 323 168 48 323 minecraft:blue_terracotta
setblock 168 47 361 minecraft:blue_terracotta
setblock 168 47 362 minecraft:dark_prismarine
fill 168 47 363 168 50 363 minecraft:blue_terracotta
setblock 169 47 361 minecraft:dark_prismarine
fill 169 47 362 169 50 362 minecraft:blue_terracotta
fill 169 47 364 169 90 364 minecraft:black_concrete
setblock 170 47 361 minecraft:blue_terracotta
setblock 172 47 325 minecraft:light[level=12]
setblock 172 47 332 minecraft:light[level=12]
setblock 172 47 339 minecraft:light[level=12]
setblock 172 47 346 minecraft:light[level=12]
setblock 172 47 353 minecraft:light[level=12]
setblock 172 47 360 minecraft:light[level=12]
setblock 172 47 363 minecraft:dark_prismarine
setblock 179 47 325 minecraft:light[level=12]
setblock 179 47 332 minecraft:light[level=12]
setblock 179 47 339 minecraft:light[level=12]
setblock 179 47 346 minecraft:light[level=12]
setblock 179 47 360 minecraft:light[level=12]
fill 180 47 333 180 47 334 minecraft:blue_terracotta
setblock 180 47 335 minecraft:dark_prismarine
fill 180 47 336 180 47 339 minecraft:blue_terracotta
setblock 180 47 352 minecraft:black_concrete
fill 180 47 353 180 47 354 minecraft:blue_terracotta
setblock 180 47 355 minecraft:dark_prismarine
fill 180 47 356 180 48 356 minecraft:blue_terracotta
setblock 180 47 363 minecraft:purple_concrete
fill 181 47 330 181 47 333 minecraft:blue_terracotta
setblock 181 47 334 minecraft:dark_prismarine
fill 181 47 335 181 50 335 minecraft:blue_terracotta
setblock 181 47 338 minecraft:blue_terracotta
setblock 181 47 339 minecraft:dark_prismarine
fill 181 47 340 181 47 343 minecraft:blue_terracotta
setblock 181 47 344 minecraft:dark_prismarine
fill 181 47 345 181 50 345 minecraft:blue_terracotta
setblock 181 47 349 minecraft:dark_prismarine
fill 181 47 350 181 49 350 minecraft:blue_terracotta
setblock 181 47 354 minecraft:dark_prismarine
fill 181 47 355 181 50 355 minecraft:blue_terracotta
setblock 181 47 359 minecraft:dark_prismarine
fill 181 47 360 181 50 360 minecraft:blue_terracotta
fill 182 47 326 182 47 327 minecraft:blue_terracotta
setblock 182 47 328 minecraft:dark_prismarine
fill 182 47 329 182 47 332 minecraft:blue_terracotta
setblock 182 47 333 minecraft:dark_prismarine
fill 182 47 334 182 50 334 minecraft:blue_terracotta
setblock 182 47 338 minecraft:dark_prismarine
fill 182 47 339 182 47 342 minecraft:blue_terracotta
setblock 182 47 343 minecraft:dark_prismarine
fill 182 47 344 182 50 344 minecraft:blue_terracotta
setblock 182 47 348 minecraft:dark_prismarine
fill 182 47 349 182 50 349 minecraft:blue_terracotta
setblock 182 47 353 minecraft:dark_prismarine
fill 182 47 354 182 50 354 minecraft:blue_terracotta
setblock 182 47 358 minecraft:dark_prismarine
fill 182 47 359 182 50 359 minecraft:blue_terracotta
setblock 182 47 363 minecraft:dark_prismarine
fill 142 48 323 144 48 324 minecraft:blue_terracotta
setblock 142 48 327 minecraft:dark_prismarine
fill 142 48 328 142 51 328 minecraft:blue_terracotta
setblock 142 48 332 minecraft:dark_prismarine
fill 142 48 333 142 48 336 minecraft:blue_terracotta
setblock 142 48 337 minecraft:dark_prismarine
fill 142 48 338 142 48 341 minecraft:blue_terracotta
setblock 142 48 342 minecraft:dark_prismarine
fill 142 48 343 142 51 343 minecraft:blue_terracotta
setblock 142 48 347 minecraft:dark_prismarine
fill 142 48 348 142 49 348 minecraft:blue_terracotta
setblock 142 48 352 minecraft:dark_prismarine
fill 142 48 353 142 51 353 minecraft:blue_terracotta
setblock 142 48 357 minecraft:dark_prismarine
fill 142 48 358 142 51 358 minecraft:blue_terracotta
fill 142 48 360 142 48 361 minecraft:blue_terracotta
setblock 142 48 362 minecraft:dark_prismarine
fill 142 48 363 145 48 363 minecraft:blue_terracotta
setblock 143 48 326 minecraft:dark_prismarine
fill 143 48 327 143 51 327 minecraft:blue_terracotta
setblock 143 48 331 minecraft:dark_prismarine
fill 143 48 332 143 51 332 minecraft:blue_terracotta
setblock 143 48 336 minecraft:dark_prismarine
fill 143 48 337 143 51 337 minecraft:blue_terracotta
setblock 143 48 340 minecraft:blue_terracotta
setblock 143 48 341 minecraft:dark_prismarine
fill 143 48 342 143 51 342 minecraft:blue_terracotta
setblock 143 48 351 minecraft:dark_prismarine
setblock 143 48 352 minecraft:blue_terracotta
setblock 143 48 356 minecraft:dark_prismarine
fill 143 48 357 143 51 357 minecraft:blue_terracotta
setblock 143 48 361 minecraft:dark_prismarine
fill 143 48 362 146 48 362 minecraft:blue_terracotta
setblock 144 48 330 minecraft:dark_prismarine
fill 144 48 331 144 51 331 minecraft:blue_terracotta
setblock 144 48 335 minecraft:dark_prismarine
fill 144 48 336 144 51 336 minecraft:blue_terracotta
setblock 144 48 340 minecraft:dark_prismarine
fill 144 48 341 144 50 341 minecraft:blue_terracotta
setblock 144 48 356 minecraft:blue_terracotta
setblock 144 48 358 minecraft:blue_terracotta
setblock 145 48 323 minecraft:blue_terracotta
setblock 145 48 324 minecraft:dark_prismarine
setblock 145 48 330 minecraft:blue_terracotta
setblock 145 48 334 minecraft:dark_prismarine
setblock 146 48 323 minecraft:dark_prismarine
fill 146 48 324 146 51 324 minecraft:blue_terracotta
setblock 146 48 363 minecraft:dark_prismarine
fill 147 48 323 147 51 323 minecraft:blue_terracotta
setblock 147 48 362 minecraft:dark_prismarine
fill 147 48 363 147 51 363 minecraft:blue_terracotta
fill 148 48 362 148 51 362 minecraft:blue_terracotta
setblock 151 48 323 minecraft:dark_prismarine
setblock 151 48 363 minecraft:dark_prismarine
fill 152 48 323 152 49 323 minecraft:blue_terracotta
fill 152 48 363 155 48 363 minecraft:blue_terracotta
setblock 156 48 363 minecraft:dark_prismarine
fill 157 48 323 160 48 323 minecraft:blue_terracotta
setblock 157 48 362 minecraft:dark_prismarine
fill 157 48 363 160 48 363 minecraft:blue_terracotta
fill 158 48 362 161 48 362 minecraft:blue_terracotta
fill 159 48 361 162 48 361 minecraft:blue_terracotta
setblock 161 48 323 minecraft:dark_prismarine
fill 161 48 360 163 48 360 minecraft:blue_terracotta
setblock 161 48 363 minecraft:dark_prismarine
fill 162 48 323 162 51 323 minecraft:blue_terracotta
setblock 162 48 362 minecraft:dark_prismarine
fill 162 48 363 165 48 363 minecraft:blue_terracotta
setblock 163 48 361 minecraft:dark_prismarine
fill 163 48 362 163 51 362 minecraft:blue_terracotta
setblock 164 48 359 minecraft:blue_terracotta
setblock 164 48 360 minecraft:dark_prismarine
fill 164 48 361 164 51 361 minecraft:blue_terracotta
setblock 165 48 359 minecraft:dark_prismarine
fill 165 48 360 165 51 360 minecraft:blue_terracotta
setblock 166 48 323 minecraft:dark_prismarine
setblock 166 48 363 minecraft:dark_prismarine
fill 167 48 323 167 49 323 minecraft:blue_terracotta
setblock 167 48 362 minecraft:dark_prismarine
fill 167 48 363 167 51 363 minecraft:blue_terracotta
setblock 168 48 361 minecraft:dark_prismarine
fill 168 48 362 168 51 362 minecraft:blue_terracotta
fill 169 48 361 169 49 361 minecraft:blue_terracotta
setblock 171 48 363 minecraft:dark_prismarine
setblock 172 48 363 minecraft:blue_terracotta
setblock 180 48 333 minecraft:blue_terracotta
setblock 180 48 334 minecraft:dark_prismarine
fill 180 48 335 180 48 338 minecraft:blue_terracotta
setblock 180 48 339 minecraft:dark_prismarine
fill 180 48 340 182 49 340 minecraft:blue_terracotta
setblock 180 48 354 minecraft:dark_prismarine
setblock 180 48 355 minecraft:blue_terracotta
fill 181 48 330 181 48 332 minecraft:blue_terracotta
setblock 181 48 333 minecraft:dark_prismarine
fill 181 48 334 181 51 334 minecraft:blue_terracotta
setblock 181 48 338 minecraft:dark_prismarine
fill 181 48 339 182 50 339 minecraft:blue_terracotta
fill 181 48 341 181 48 342 minecraft:blue_terracotta
setblock 181 48 343 minecraft:dark_prismarine
fill 181 48 344 181 51 344 minecraft:blue_terracotta
setblock 181 48 348 minecraft:dark_prismarine
fill 181 48 349 181 49 349 minecraft:blue_terracotta
setblock 181 48 353 minecraft:dark_prismarine
fill 181 48 354 181 51 354 minecraft:blue_terracotta
setblock 181 48 357 minecraft:blue_terracotta
setblock 181 48 358 minecraft:dark_prismarine
fill 181 48 359 181 51 359 minecraft:blue_terracotta
setblock 181 48 363 minecraft:dark_prismarine
setblock 182 48 323 minecraft:purple_concrete
setblock 182 48 326 minecraft:blue_terracotta
setblock 182 48 327 minecraft:dark_prismarine
fill 182 48 328 182 48 331 minecraft:blue_terracotta
setblock 182 48 332 minecraft:dark_prismarine
fill 182 48 333 182 51 333 minecraft:blue_terracotta
setblock 182 48 337 minecraft:dark_prismarine
fill 182 48 338 182 51 338 minecraft:blue_terracotta
setblock 182 48 341 minecraft:blue_terracotta
setblock 182 48 342 minecraft:dark_prismarine
fill 182 48 343 182 51 343 minecraft:blue_terracotta
setblock 182 48 347 minecraft:dark_prismarine
fill 182 48 348 182 51 348 minecraft:blue_terracotta
setblock 182 48 352 minecraft:dark_prismarine
fill 182 48 353 182 51 353 minecraft:blue_terracotta
setblock 182 48 357 minecraft:dark_prismarine
fill 182 48 358 182 51 358 minecraft:blue_terracotta
setblock 182 48 362 minecraft:dark_prismarine
fill 182 48 363 182 51 363 minecraft:blue_terracotta
fill 142 49 323 143 49 324 minecraft:blue_terracotta
setblock 142 49 326 minecraft:dark_prismarine
fill 142 49 327 142 52 327 minecraft:blue_terracotta
setblock 142 49 331 minecraft:dark_prismarine
fill 142 49 332 142 49 335 minecraft:blue_terracotta
setblock 142 49 336 minecraft:dark_prismarine
fill 142 49 337 142 49 340 minecraft:blue_terracotta
setblock 142 49 341 minecraft:dark_prismarine
fill 142 49 342 142 52 342 minecraft:blue_terracotta
setblock 142 49 346 minecraft:dark_prismarine
fill 142 49 347 142 50 347 minecraft:blue_terracotta
setblock 142 49 351 minecraft:dark_prismarine
fill 142 49 352 142 50 352 minecraft:blue_terracotta
setblock 142 49 356 minecraft:dark_prismarine
fill 142 49 357 142 52 357 minecraft:blue_terracotta
setblock 142 49 360 minecraft:blue_terracotta
setblock 142 49 361 minecraft:dark_prismarine
fill 142 49 362 144 49 363 minecraft:blue_terracotta
setblock 143 49 325 minecraft:dark_prismarine
fill 143 49 326 143 52 326 minecraft:blue_terracotta
setblock 143 49 330 minecraft:dark_prismarine
fill 143 49 331 143 52 331 minecraft:blue_terracotta
setblock 143 49 335 minecraft:dark_prismarine
fill 143 49 336 143 52 336 minecraft:blue_terracotta
setblock 143 49 340 minecraft:dark_prismarine
fill 143 49 341 143 52 341 minecraft:blue_terracotta
setblock 143 49 355 minecraft:dark_prismarine
fill 143 49 356 143 51 356 minecraft:blue_terracotta
setblock 143 49 359 minecraft:blue_terracotta
setblock 143 49 360 minecraft:dark_prismarine
fill 143 49 361 143 52 361 minecraft:blue_terracotta
setblock 144 49 323 minecraft:blue_terracotta
setblock 144 49 324 minecraft:dark_prismarine
setblock 144 49 329 minecraft:dark_prismarine
fill 144 49 330 144 50 330 minecraft:blue_terracotta
setblock 144 49 334 minecraft:dark_prismarine
fill 144 49 335 144 52 335 minecraft:blue_terracotta
setblock 144 49 339 minecraft:dark_prismarine
fill 144 49 340 144 52 340 minecraft:blue_terracotta
setblock 145 49 323 minecraft:dark_prismarine
fill 145 49 324 145 52 324 minecraft:blue_terracotta
setblock 145 49 333 minecraft:dark_prismarine
fill 145 49 334 145 50 334 minecraft:blue_terracotta
setblock 145 49 338 minecraft:dark_prismarine
setblock 145 49 362 minecraft:blue_terracotta
setblock 145 49 363 minecraft:dark_prismarine
fill 146 49 323 146 52 323 minecraft:blue_terracotta
setblock 146 49 362 minecraft:dark_prismarine
fill 146 49 363 146 52 363 minecraft:blue_terracotta
fill 147 49 362 147 52 362 minecraft:blue_terracotta
setblock 150 49 323 minecraft:dark_prismarine
setblock 150 49 363 minecraft:dark_prismarine
fill 151 49 323 151 50 323 minecraft:blue_terracotta
fill 151 49 363 154 49 363 minecraft:blue_terracotta
setblock 155 49 363 minecraft:dark_prismarine
setblock 156 49 362 minecraft:dark_prismarine
fill 156 49 363 159 49 363 minecraft:blue_terracotta
fill 157 49 323 159 49 323 minecraft:blue_terracotta
fill 157 49 362 160 49 362 minecraft:blue_terracotta
fill 159 49 361 161 49 361 minecraft:blue_terracotta
setblock 160 49 323 minecraft:dark_prismarine
setblock 160 49 363 minecraft:dark_prismarine
fill 161 49 323 161 52 323 minecraft:blue_terracotta
fill 161 49 327 161 50 327 minecraft:magenta_terracotta
fill 161 49 360 162 49 360 minecraft:blue_terracotta
setblock 161 49 362 minecraft:dark_prismarine
fill 161 49 363 164 49 363 minecraft:blue_terracotta
setblock 162 49 361 minecraft:dark_prismarine
fill 162 49 362 162 52 362 minecraft:blue_terracotta
setblock 163 49 360 minecraft:dark_prismarine
fill 163 49 361 163 52 361 minecraft:blue_terracotta
fill 164 49 360 164 52 360 minecraft:blue_terracotta
setblock 165 49 323 minecraft:dark_prismarine
setblock 165 49 363 minecraft:dark_prismarine
fill 166 49 323 166 50 323 minecraft:blue_terracotta
setblock 166 49 362 minecraft:dark_prismarine
fill 166 49 363 166 52 363 minecraft:blue_terracotta
setblock 167 49 361 minecraft:dark_prismarine
fill 167 49 362 167 52 362 minecraft:blue_terracotta
fill 168 49 361 168 50 361 minecraft:blue_terracotta
setblock 170 49 363 minecraft:dark_prismarine
fill 171 49 363 171 50 363 minecraft:blue_terracotta
setblock 173 49 363 minecraft:purple_concrete
setblock 176 49 323 minecraft:purple_concrete
setblock 180 49 333 minecraft:dark_prismarine
fill 180 49 334 180 49 337 minecraft:blue_terracotta
setblock 180 49 338 minecraft:dark_prismarine
fill 180 49 339 180 52 339 minecraft:blue_terracotta
fill 180 49 341 181 49 341 minecraft:blue_terracotta
fill 181 49 330 181 49 331 minecraft:blue_terracotta
setblock 181 49 332 minecraft:dark_prismarine
fill 181 49 333 181 52 333 minecraft:blue_terracotta
setblock 181 49 337 minecraft:dark_prismarine
fill 181 49 338 181 52 338 minecraft:blue_terracotta
setblock 181 49 342 minecraft:dark_prismarine
fill 181 49 343 181 52 343 minecraft:blue_terracotta
setblock 181 49 347 minecraft:dark_prismarine
setblock 181 49 348 minecraft:blue_terracotta
setblock 181 49 352 minecraft:dark_prismarine
fill 181 49 353 181 50 353 minecraft:blue_terracotta
setblock 181 49 357 minecraft:dark_prismarine
fill 181 49 358 181 52 358 minecraft:blue_terracotta
fill 181 49 363 181 52 363 minecraft:blue_terracotta
setblock 182 49 326 minecraft:dark_prismarine
fill 182 49 327 182 49 330 minecraft:blue_terracotta
setblock 182 49 331 minecraft:dark_prismarine
fill 182 49 332 182 52 332 minecraft:blue_terracotta
setblock 182 49 336 minecraft:dark_prismarine
fill 182 49 337 182 52 337 minecraft:blue_terracotta
setblock 182 49 341 minecraft:dark_prismarine
fill 182 49 342 182 52 342 minecraft:blue_terracotta
setblock 182 49 346 minecraft:dark_prismarine
fill 182 49 347 182 52 347 minecraft:blue_terracotta
setblock 182 49 351 minecraft:dark_prismarine
fill 182 49 352 182 52 352 minecraft:blue_terracotta
setblock 182 49 356 minecraft:dark_prismarine
fill 182 49 357 182 52 357 minecraft:blue_terracotta
setblock 182 49 361 minecraft:dark_prismarine
fill 182 49 362 182 52 362 minecraft:blue_terracotta
fill 142 50 323 142 50 324 minecraft:blue_terracotta
setblock 142 50 325 minecraft:dark_prismarine
fill 142 50 326 142 53 326 minecraft:blue_terracotta
setblock 142 50 330 minecraft:dark_prismarine
fill 142 50 331 142 50 334 minecraft:blue_terracotta
setblock 142 50 335 minecraft:dark_prismarine
fill 142 50 336 142 50 339 minecraft:blue_terracotta
setblock 142 50 340 minecraft:dark_prismarine
fill 142 50 341 142 53 341 minecraft:blue_terracotta
setblock 142 50 345 minecraft:dark_prismarine
fill 142 50 346 142 53 346 minecraft:blue_terracotta
setblock 142 50 350 minecraft:dark_prismarine
setblock 142 50 351 minecraft:blue_terracotta
setblock 142 50 355 minecraft:dark_prismarine
fill 142 50 356 142 53 356 minecraft:blue_terracotta
setblock 142 50 360 minecraft:dark_prismarine
fill 142 50 361 142 51 363 minecraft:blue_terracotta
setblock 143 50 323 minecraft:blue_terracotta
setblock 143 50 324 minecraft:dark_prismarine
fill 143 50 325 143 53 325 minecraft:blue_terracotta
setblock 143 50 329 minecraft:dark_prismarine
fill 143 50 330 143 53 330 minecraft:blue_terracotta
setblock 143 50 334 minecraft:dark_prismarine
fill 143 50 335 143 53 335 minecraft:blue_terracotta
setblock 143 50 339 minecraft:dark_prismarine
fill 143 50 340 143 53 340 minecraft:blue_terracotta
setblock 143 50 355 minecraft:blue_terracotta
setblock 143 50 359 minecraft:dark_prismarine
fill 143 50 360 143 53 360 minecraft:blue_terracotta
fill 143 50 362 143 50 363 minecraft:blue_terracotta
setblock 144 50 323 minecraft:dark_prismarine
fill 144 50 324 144 53 324 minecraft:blue_terracotta
setblock 144 50 329 minecraft:blue_terracotta
setblock 144 50 333 minecraft:dark_prismarine
fill 144 50 334 144 52 334 minecraft:blue_terracotta
setblock 144 50 338 minecraft:dark_prismarine
fill 144 50 339 144 53 339 minecraft:blue_terracotta
setblock 144 50 362 minecraft:blue_terracotta
setblock 144 50 363 minecraft:dark_prismarine
fill 145 50 323 145 53 323 minecraft:blue_terracotta
setblock 145 50 333 minecraft:blue_terracotta
setblock 145 50 337 minecraft:dark_prismarine
setblock 145 50 362 minecraft:dark_prismarine
fill 145 50 363 145 53 363 minecraft:blue_terracotta
fill 146 50 362 146 53 362 minecraft:blue_terracotta
setblock 149 50 323 minecraft:dark_prismarine
setblock 149 50 363 minecraft:dark_prismarine
fill 150 50 323 150 53 323 minecraft:blue_terracotta
fill 150 50 363 153 50 363 minecraft:blue_terracotta
setblock 152 50 364 minecraft:cyan_concrete
setblock 154 50 363 minecraft:dark_prismarine
fill 155 50 363 158 50 363 minecraft:blue_terracotta
fill 156 50 362 159 50 362 minecraft:blue_terracotta
fill 157 50 323 158 50 323 minecraft:blue_terracotta
fill 158 50 361 160 50 361 minecraft:blue_terracotta
setblock 159 50 323 minecraft:dark_prismarine
setblock 159 50 363 minecraft:dark_prismarine
fill 160 50 323 160 53 323 minecraft:blue_terracotta
fill 160 50 360 161 50 360 minecraft:blue_terracotta
setblock 160 50 362 minecraft:dark_prismarine
fill 160 50 363 163 50 363 minecraft:blue_terracotta
fill 161 50 357 161 84 357 minecraft:magenta_terracotta
setblock 161 50 361 minecraft:dark_prismarine
fill 161 50 362 161 53 362 minecraft:blue_terracotta
fill 162 50 355 162 86 355 minecraft:magenta_terracotta
setblock 162 50 360 minecraft:dark_prismarine
fill 162 50 361 162 53 361 minecraft:blue_terracotta
fill 163 50 360 163 53 360 minecraft:blue_terracotta
setblock 164 50 323 minecraft:dark_prismarine
setblock 164 50 363 minecraft:dark_prismarine
fill 165 50 323 165 52 323 minecraft:blue_terracotta
setblock 165 50 362 minecraft:dark_prismarine
fill 165 50 363 165 53 363 minecraft:blue_terracotta
setblock 166 50 361 minecraft:dark_prismarine
fill 166 50 362 166 53 362 minecraft:blue_terracotta
fill 167 50 361 167 52 361 minecraft:blue_terracotta
setblock 169 50 363 minecraft:dark_prismarine
setblock 170 50 323 minecraft:purple_concrete
fill 170 50 363 170 52 363 minecraft:blue_terracotta
setblock 179 50 363 minecraft:purple_concrete
fill 180 50 334 180 50 336 minecraft:blue_terracotta
setblock 180 50 337 minecraft:dark_prismarine
fill 180 50 338 180 53 338 minecraft:blue_terracotta
fill 180 50 340 180 50 341 minecraft:blue_terracotta
fill 180 50 363 180 53 363 minecraft:blue_terracotta
setblock 181 50 330 minecraft:blue_terracotta
setblock 181 50 331 minecraft:dark_prismarine
fill 181 50 332 181 53 332 minecraft:blue_terracotta
setblock 181 50 336 minecraft:dark_prismarine
fill 181 50 337 181 53 337 minecraft:blue_terracotta
setblock 181 50 340 minecraft:blue_terracotta
setblock 181 50 341 minecraft:dark_prismarine
fill 181 50 342 181 53 342 minecraft:blue_terracotta
setblock 181 50 346 minecraft:dark_prismarine
setblock 181 50 351 minecraft:dark_prismarine
setblock 181 50 352 minecraft:blue_terracotta
setblock 181 50 356 minecraft:dark_prismarine
fill 181 50 357 181 52 357 minecraft:blue_terracotta
setblock 181 50 361 minecraft:dark_prismarine
fill 182 50 326 182 50 329 minecraft:blue_terracotta
setblock 182 50 330 minecraft:dark_prismarine
fill 182 50 331 182 53 331 minecraft:blue_terracotta
setblock 182 50 335 minecraft:dark_prismarine
fill 182 50 336 182 53 336 minecraft:blue_terracotta
setblock 182 50 340 minecraft:dark_prismarine
fill 182 50 341 182 53 341 minecraft:blue_terracotta
setblock 182 50 345 minecraft:dark_prismarine
fill 182 50 346 182 53 346 minecraft:blue_terracotta
setblock 182 50 350 minecraft:dark_prismarine
fill 182 50 351 182 53 351 minecraft:blue_terracotta
setblock 182 50 355 minecraft:dark_prismarine
fill 182 50 356 182 53 356 minecraft:blue_terracotta
setblock 182 50 360 minecraft:dark_prismarine
fill 182 50 361 182 53 361 minecraft:blue_terracotta
setblock 142 51 323 minecraft:blue_terracotta
setblock 142 51 324 minecraft:dark_prismarine
fill 142 51 325 142 54 325 minecraft:blue_terracotta
setblock 142 51 329 minecraft:dark_prismarine
fill 142 51 330 142 51 333 minecraft:blue_terracotta
setblock 142 51 334 minecraft:dark_prismarine
fill 142 51 335 142 51 338 minecraft:blue_terracotta
setblock 142 51 339 minecraft:dark_prismarine
fill 142 51 340 142 54 340 minecraft:blue_terracotta
setblock 142 51 344 minecraft:dark_prismarine
fill 142 51 345 142 54 345 minecraft:blue_terracotta
setblock 142 51 354 minecraft:dark_prismarine
fill 142 51 355 142 53 355 minecraft:blue_terracotta
setblock 142 51 359 minecraft:dark_prismarine
fill 142 51 360 142 54 360 minecraft:blue_terracotta
setblock 143 51 323 minecraft:dark_prismarine
fill 143 51 324 143 54 324 minecraft:blue_terracotta
setblock 143 51 328 minecraft:dark_prismarine
fill 143 51 329 143 54 329 minecraft:blue_terracotta
setblock 143 51 333 minecraft:dark_prismarine
fill 143 51 334 143 54 334 minecraft:blue_terracotta
setblock 143 51 338 minecraft:dark_prismarine
fill 143 51 339 143 54 339 minecraft:blue_terracotta
setblock 143 51 343 minecraft:dark_prismarine
setblock 143 51 358 minecraft:dark_prismarine
fill 143 51 359 143 54 359 minecraft:blue_terracotta
setblock 143 51 362 minecraft:blue_terracotta
setblock 143 51 363 minecraft:dark_prismarine
fill 144 51 323 144 54 323 minecraft:blue_terracotta
setblock 144 51 332 minecraft:dark_prismarine
fill 144 51 333 144 52 333 minecraft:blue_terracotta
setblock 144 51 337 minecraft:dark_prismarine
fill 144 51 338 144 53 338 minecraft:blue_terracotta
setblock 144 51 362 minecraft:dark_prismarine
fill 144 51 363 144 54 363 minecraft:blue_terracotta
fill 145 51 362 145 54 362 minecraft:blue_terracotta
setblock 148 51 323 minecraft:dark_prismarine
setblock 148 51 363 minecraft:dark_prismarine
fill 149 51 323 149 54 323 minecraft:blue_terracotta
fill 149 51 363 152 51 363 minecraft:blue_terracotta
setblock 150 51 349 minecraft:magenta_terracotta
fill 152 51 364 152 131 364 minecraft:black_concrete
setblock 153 51 363 minecraft:dark_prismarine
fill 154 51 363 157 51 363 minecraft:blue_terracotta
fill 155 51 362 158 51 362 minecraft:blue_terracotta
setblock 157 51 323 minecraft:blue_terracotta
setblock 158 51 323 minecraft:dark_prismarine
fill 158 51 361 159 51 361 minecraft:blue_terracotta
setblock 158 51 363 minecraft:dark_prismarine
fill 159 51 323 159 54 323 minecraft:blue_terracotta
setblock 159 51 362 minecraft:dark_prismarine
fill 159 51 363 162 51 363 minecraft:blue_terracotta
setblock 160 51 360 minecraft:blue_terracotta
setblock 160 51 361 minecraft:dark_prismarine
fill 160 51 362 160 54 362 minecraft:blue_terracotta
setblock 161 51 360 minecraft:dark_prismarine
fill 161 51 361 161 54 361 minecraft:blue_terracotta
fill 162 51 360 162 54 360 minecraft:blue_terracotta
setblock 163 51 323 minecraft:dark_prismarine
setblock 163 51 363 minecraft:dark_prismarine
fill 164 51 323 164 54 323 minecraft:blue_terracotta
setblock 164 51 362 minecraft:dark_prismarine
fill 164 51 363 164 54 363 minecraft:blue_terracotta
setblock 165 51 361 minecraft:dark_prismarine
fill 165 51 362 165 54 362 minecraft:blue_terracotta
fill 166 51 361 166 53 361 minecraft:blue_terracotta
setblock 168 51 363 minecraft:dark_prismarine
setblock 169 51 362 minecraft:dark_prismarine
fill 169 51 363 169 54 363 minecraft:blue_terracotta
fill 178 51 337 178 102 337 minecraft:magenta_terracotta
fill 180 51 334 180 51 335 minecraft:blue_terracotta
setblock 180 51 336 minecraft:dark_prismarine
fill 180 51 337 180 54 337 minecraft:blue_terracotta
setblock 180 51 340 minecraft:blue_terracotta
setblock 180 51 341 minecraft:dark_prismarine
fill 180 51 342 180 54 342 minecraft:blue_terracotta
fill 181 51 331 181 52 331 minecraft:blue_terracotta
setblock 181 51 335 minecraft:dark_prismarine
fill 181 51 336 181 54 336 minecraft:blue_terracotta
setblock 181 51 339 minecraft:blue_terracotta
setblock 181 51 340 minecraft:dark_prismarine
fill 181 51 341 181 54 341 minecraft:blue_terracotta
setblock 181 51 345 minecraft:dark_prismarine
fill 181 51 346 181 54 346 minecraft:blue_terracotta
setblock 181 51 355 minecraft:dark_prismarine
fill 181 51 356 181 52 356 minecraft:blue_terracotta
setblock 181 51 360 minecraft:dark_prismarine
fill 181 51 361 181 54 361 minecraft:blue_terracotta
setblock 182 51 323 minecraft:blue_terracotta
setblock 182 51 324 minecraft:purple_concrete
schedule function dropper:buildpart/75_4 1t
