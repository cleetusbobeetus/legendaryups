fill 308 95 492 309 95 492 minecraft:magma_block
fill 308 95 493 312 95 493 minecraft:blackstone
fill 309 95 464 309 96 464 minecraft:polished_blackstone_bricks
fill 309 95 466 309 96 466 minecraft:polished_blackstone_bricks
fill 309 95 475 312 95 475 minecraft:blackstone
setblock 309 95 476 minecraft:magma_block
setblock 309 95 482 minecraft:light[level=14]
setblock 309 95 490 minecraft:light[level=14]
setblock 309 95 498 minecraft:light[level=14]
fill 310 95 465 310 96 465 minecraft:polished_blackstone_bricks
fill 310 95 467 310 96 467 minecraft:polished_blackstone_bricks
fill 310 95 476 313 95 476 minecraft:blackstone
setblock 310 95 477 minecraft:magma_block
setblock 310 95 491 minecraft:magma_block
fill 310 95 492 313 95 492 minecraft:blackstone
fill 311 95 464 311 96 464 minecraft:polished_blackstone_bricks
fill 311 95 466 311 96 466 minecraft:polished_blackstone_bricks
fill 311 95 477 314 95 477 minecraft:blackstone
setblock 311 95 478 minecraft:magma_block
fill 311 95 489 311 95 490 minecraft:magma_block
fill 311 95 491 314 95 491 minecraft:blackstone
fill 312 95 465 312 96 465 minecraft:polished_blackstone_bricks
fill 312 95 467 312 96 467 minecraft:polished_blackstone_bricks
fill 312 95 478 314 95 478 minecraft:blackstone
fill 312 95 479 312 95 481 minecraft:magma_block
fill 312 95 487 312 95 488 minecraft:magma_block
fill 312 95 489 314 95 490 minecraft:blackstone
fill 313 95 464 313 96 464 minecraft:polished_blackstone_bricks
fill 313 95 466 313 96 466 minecraft:polished_blackstone_bricks
fill 313 95 479 315 95 481 minecraft:blackstone
fill 313 95 482 313 95 486 minecraft:magma_block
fill 313 95 487 315 95 488 minecraft:blackstone
fill 314 95 465 314 96 465 minecraft:polished_blackstone_bricks
fill 314 95 467 314 96 467 minecraft:polished_blackstone_bricks
fill 314 95 482 316 95 486 minecraft:blackstone
fill 315 95 464 315 96 464 minecraft:polished_blackstone_bricks
fill 315 95 466 315 96 466 minecraft:polished_blackstone_bricks
setblock 315 95 489 minecraft:blackstone
fill 316 95 465 316 96 465 minecraft:polished_blackstone_bricks
fill 316 95 467 316 96 467 minecraft:polished_blackstone_bricks
fill 317 95 464 317 96 464 minecraft:polished_blackstone_bricks
fill 317 95 466 317 96 466 minecraft:polished_blackstone_bricks
setblock 317 95 474 minecraft:light[level=14]
setblock 317 95 482 minecraft:light[level=14]
setblock 317 95 490 minecraft:light[level=14]
setblock 317 95 498 minecraft:light[level=14]
fill 318 95 465 318 96 465 minecraft:polished_blackstone_bricks
fill 318 95 467 318 96 467 minecraft:polished_blackstone_bricks
fill 319 95 464 319 96 464 minecraft:polished_blackstone_bricks
fill 319 95 466 319 96 466 minecraft:polished_blackstone_bricks
fill 319 95 478 319 96 478 minecraft:polished_blackstone_bricks
fill 319 95 480 319 96 480 minecraft:polished_blackstone_bricks
fill 319 95 482 319 96 482 minecraft:polished_blackstone_bricks
fill 319 95 484 319 96 484 minecraft:polished_blackstone_bricks
fill 320 95 465 320 96 465 minecraft:polished_blackstone_bricks
fill 320 95 467 320 96 467 minecraft:polished_blackstone_bricks
fill 320 95 477 320 96 477 minecraft:polished_blackstone_bricks
fill 320 95 479 320 96 479 minecraft:polished_blackstone_bricks
fill 320 95 481 320 96 481 minecraft:polished_blackstone_bricks
fill 320 95 483 320 96 483 minecraft:polished_blackstone_bricks
fill 320 95 485 320 96 485 minecraft:polished_blackstone_bricks
fill 321 95 478 321 96 478 minecraft:polished_blackstone_bricks
fill 321 95 480 321 96 480 minecraft:polished_blackstone_bricks
fill 321 95 482 321 96 482 minecraft:polished_blackstone_bricks
fill 321 95 484 321 96 484 minecraft:polished_blackstone_bricks
fill 322 95 477 322 96 477 minecraft:polished_blackstone_bricks
fill 322 95 479 322 96 479 minecraft:polished_blackstone_bricks
fill 322 95 481 322 96 481 minecraft:polished_blackstone_bricks
fill 322 95 483 322 96 483 minecraft:polished_blackstone_bricks
fill 322 95 485 322 96 485 minecraft:polished_blackstone_bricks
fill 323 95 478 323 96 478 minecraft:polished_blackstone_bricks
fill 323 95 480 323 96 480 minecraft:polished_blackstone_bricks
fill 323 95 482 323 96 482 minecraft:polished_blackstone_bricks
fill 323 95 484 323 96 484 minecraft:polished_blackstone_bricks
setblock 282 97 463 minecraft:nether_bricks
fill 282 97 464 282 97 468 minecraft:blackstone
fill 283 97 463 286 98 463 minecraft:blackstone
fill 286 97 505 288 100 505 minecraft:blackstone
setblock 287 97 463 minecraft:nether_bricks
fill 288 97 463 288 100 463 minecraft:blackstone
setblock 289 97 505 minecraft:nether_bricks
fill 290 97 505 290 100 505 minecraft:blackstone
fill 291 97 505 291 98 505 minecraft:nether_bricks
fill 292 97 505 293 100 505 minecraft:blackstone
fill 293 97 463 294 100 463 minecraft:blackstone
setblock 295 97 463 minecraft:nether_bricks
fill 296 97 463 296 100 463 minecraft:blackstone
setblock 297 97 463 minecraft:nether_bricks
setblock 297 97 505 minecraft:nether_bricks
fill 298 97 463 300 100 463 minecraft:blackstone
fill 298 97 505 299 100 505 minecraft:blackstone
setblock 300 97 505 minecraft:nether_bricks
fill 301 97 505 305 100 505 minecraft:blackstone
fill 305 97 463 305 98 463 minecraft:nether_bricks
fill 306 97 463 306 100 463 minecraft:blackstone
setblock 306 97 505 minecraft:nether_bricks
setblock 307 97 463 minecraft:nether_bricks
fill 308 97 463 312 98 463 minecraft:blackstone
setblock 308 97 465 minecraft:shroomlight
setblock 308 97 467 minecraft:shroomlight
setblock 309 97 464 minecraft:shroomlight
setblock 309 97 466 minecraft:shroomlight
setblock 310 97 465 minecraft:shroomlight
setblock 310 97 467 minecraft:shroomlight
fill 310 97 505 314 97 505 minecraft:blackstone
setblock 311 97 464 minecraft:shroomlight
setblock 311 97 466 minecraft:shroomlight
setblock 312 97 465 minecraft:shroomlight
setblock 312 97 467 minecraft:shroomlight
setblock 313 97 464 minecraft:shroomlight
setblock 313 97 466 minecraft:shroomlight
setblock 314 97 465 minecraft:shroomlight
setblock 314 97 467 minecraft:shroomlight
setblock 315 97 464 minecraft:shroomlight
setblock 315 97 466 minecraft:shroomlight
setblock 315 97 505 minecraft:nether_bricks
setblock 316 97 465 minecraft:shroomlight
setblock 316 97 467 minecraft:shroomlight
fill 316 97 505 317 98 505 minecraft:blackstone
setblock 317 97 464 minecraft:shroomlight
setblock 317 97 466 minecraft:shroomlight
setblock 318 97 465 minecraft:shroomlight
setblock 318 97 467 minecraft:shroomlight
setblock 319 97 464 minecraft:shroomlight
setblock 319 97 466 minecraft:shroomlight
setblock 319 97 478 minecraft:shroomlight
setblock 319 97 480 minecraft:shroomlight
setblock 319 97 482 minecraft:shroomlight
setblock 319 97 484 minecraft:shroomlight
setblock 319 97 505 minecraft:nether_bricks
setblock 320 97 465 minecraft:shroomlight
setblock 320 97 467 minecraft:shroomlight
setblock 320 97 477 minecraft:shroomlight
setblock 320 97 479 minecraft:shroomlight
setblock 320 97 481 minecraft:shroomlight
setblock 320 97 483 minecraft:shroomlight
setblock 320 97 485 minecraft:shroomlight
fill 320 97 505 320 100 505 minecraft:blackstone
setblock 321 97 478 minecraft:shroomlight
setblock 321 97 480 minecraft:shroomlight
setblock 321 97 482 minecraft:shroomlight
setblock 321 97 484 minecraft:shroomlight
setblock 322 97 477 minecraft:shroomlight
setblock 322 97 479 minecraft:shroomlight
setblock 322 97 481 minecraft:shroomlight
setblock 322 97 483 minecraft:shroomlight
setblock 322 97 485 minecraft:shroomlight
fill 322 97 505 323 100 505 minecraft:blackstone
setblock 323 97 478 minecraft:shroomlight
setblock 323 97 480 minecraft:shroomlight
setblock 323 97 482 minecraft:shroomlight
setblock 323 97 484 minecraft:shroomlight
fill 324 97 465 324 100 465 minecraft:blackstone
setblock 324 97 466 minecraft:nether_bricks
fill 324 97 480 324 100 481 minecraft:blackstone
setblock 324 97 482 minecraft:nether_bricks
fill 324 97 483 324 100 487 minecraft:blackstone
setblock 324 97 489 minecraft:nether_bricks
fill 324 97 490 324 98 490 minecraft:blackstone
fill 324 97 492 324 98 495 minecraft:blackstone
setblock 324 97 496 minecraft:nether_bricks
fill 324 97 497 324 98 499 minecraft:blackstone
setblock 324 97 503 minecraft:nether_bricks
setblock 324 97 505 minecraft:nether_bricks
fill 282 98 463 282 98 467 minecraft:blackstone
setblock 282 98 468 minecraft:nether_bricks
fill 282 98 473 282 98 476 minecraft:blackstone
fill 282 98 477 282 98 479 minecraft:nether_bricks
setblock 282 98 480 minecraft:blackstone
fill 282 98 481 282 99 481 minecraft:nether_bricks
setblock 283 98 505 minecraft:nether_bricks
fill 284 98 505 284 100 505 minecraft:blackstone
fill 287 98 463 287 101 463 minecraft:blackstone
fill 289 98 505 289 100 505 minecraft:blackstone
setblock 295 98 463 minecraft:blackstone
setblock 297 98 463 minecraft:blackstone
setblock 297 98 505 minecraft:blackstone
fill 300 98 505 300 100 505 minecraft:blackstone
fill 306 98 505 306 100 505 minecraft:blackstone
fill 307 98 463 307 100 463 minecraft:blackstone
fill 308 98 465 308 99 465 minecraft:polished_blackstone_bricks
fill 308 98 467 308 99 467 minecraft:polished_blackstone_bricks
fill 309 98 464 309 99 464 minecraft:polished_blackstone_bricks
fill 309 98 466 309 99 466 minecraft:polished_blackstone_bricks
fill 310 98 465 310 99 465 minecraft:polished_blackstone_bricks
fill 310 98 467 310 99 467 minecraft:polished_blackstone_bricks
fill 310 98 505 312 100 505 minecraft:blackstone
fill 311 98 464 311 99 464 minecraft:polished_blackstone_bricks
fill 311 98 466 311 99 466 minecraft:polished_blackstone_bricks
fill 312 98 465 312 99 465 minecraft:polished_blackstone_bricks
fill 312 98 467 312 99 467 minecraft:polished_blackstone_bricks
fill 313 98 464 313 99 464 minecraft:polished_blackstone_bricks
fill 313 98 466 313 99 466 minecraft:polished_blackstone_bricks
setblock 313 98 505 minecraft:nether_bricks
fill 314 98 465 314 99 465 minecraft:polished_blackstone_bricks
fill 314 98 467 314 99 467 minecraft:polished_blackstone_bricks
fill 314 98 505 315 98 505 minecraft:blackstone
fill 315 98 464 315 99 464 minecraft:polished_blackstone_bricks
fill 315 98 466 315 99 466 minecraft:polished_blackstone_bricks
fill 316 98 465 316 99 465 minecraft:polished_blackstone_bricks
fill 316 98 467 316 99 467 minecraft:polished_blackstone_bricks
fill 317 98 463 320 100 463 minecraft:blackstone
fill 317 98 464 317 99 464 minecraft:polished_blackstone_bricks
fill 317 98 466 317 99 466 minecraft:polished_blackstone_bricks
fill 318 98 465 318 99 465 minecraft:polished_blackstone_bricks
fill 318 98 467 318 99 467 minecraft:polished_blackstone_bricks
fill 319 98 464 319 99 464 minecraft:polished_blackstone_bricks
fill 319 98 466 319 99 466 minecraft:polished_blackstone_bricks
fill 319 98 478 319 99 478 minecraft:polished_blackstone_bricks
fill 319 98 480 319 99 480 minecraft:polished_blackstone_bricks
fill 319 98 482 319 99 482 minecraft:polished_blackstone_bricks
fill 319 98 484 319 99 484 minecraft:polished_blackstone_bricks
fill 319 98 505 319 100 505 minecraft:blackstone
fill 320 98 465 320 99 465 minecraft:polished_blackstone_bricks
fill 320 98 467 320 99 467 minecraft:polished_blackstone_bricks
fill 320 98 477 320 99 477 minecraft:polished_blackstone_bricks
fill 320 98 479 320 99 479 minecraft:polished_blackstone_bricks
fill 320 98 481 320 99 481 minecraft:polished_blackstone_bricks
fill 320 98 483 320 99 483 minecraft:polished_blackstone_bricks
fill 320 98 485 320 99 485 minecraft:polished_blackstone_bricks
setblock 321 98 463 minecraft:nether_bricks
fill 321 98 478 321 99 478 minecraft:polished_blackstone_bricks
fill 321 98 480 321 99 480 minecraft:polished_blackstone_bricks
fill 321 98 482 321 99 482 minecraft:polished_blackstone_bricks
fill 321 98 484 321 99 484 minecraft:polished_blackstone_bricks
fill 322 98 463 324 98 463 minecraft:blackstone
fill 322 98 477 322 99 477 minecraft:polished_blackstone_bricks
fill 322 98 479 322 99 479 minecraft:polished_blackstone_bricks
fill 322 98 481 322 99 481 minecraft:polished_blackstone_bricks
fill 322 98 483 322 99 483 minecraft:polished_blackstone_bricks
fill 322 98 485 322 99 485 minecraft:polished_blackstone_bricks
fill 323 98 478 323 99 478 minecraft:polished_blackstone_bricks
fill 323 98 480 323 99 480 minecraft:polished_blackstone_bricks
fill 323 98 482 323 99 482 minecraft:polished_blackstone_bricks
fill 323 98 484 323 99 484 minecraft:polished_blackstone_bricks
fill 324 98 466 324 100 466 minecraft:blackstone
fill 324 98 482 324 100 482 minecraft:blackstone
fill 324 98 489 324 100 489 minecraft:blackstone
fill 324 98 496 324 101 496 minecraft:blackstone
fill 324 98 501 324 100 501 minecraft:blackstone
setblock 324 98 502 minecraft:nether_bricks
fill 324 98 503 324 100 503 minecraft:blackstone
fill 324 98 505 324 100 505 minecraft:blackstone
fill 282 99 463 282 100 464 minecraft:blackstone
setblock 282 99 465 minecraft:nether_bricks
fill 282 99 466 282 100 468 minecraft:blackstone
fill 282 99 470 282 100 470 minecraft:blackstone
setblock 282 99 471 minecraft:nether_bricks
fill 282 99 473 282 100 474 minecraft:blackstone
setblock 282 99 475 minecraft:nether_bricks
fill 282 99 476 282 100 479 minecraft:blackstone
setblock 282 99 480 minecraft:nether_bricks
setblock 282 99 484 minecraft:nether_bricks
fill 282 99 485 282 100 490 minecraft:blackstone
setblock 282 99 491 minecraft:nether_bricks
fill 282 99 492 282 100 492 minecraft:blackstone
fill 283 99 463 284 100 463 minecraft:blackstone
fill 283 99 505 283 100 505 minecraft:blackstone
setblock 285 99 463 minecraft:nether_bricks
fill 286 99 463 286 100 463 minecraft:blackstone
fill 291 99 505 291 100 505 minecraft:blackstone
setblock 295 99 463 minecraft:nether_bricks
fill 295 99 505 295 101 505 minecraft:blackstone
fill 296 99 505 297 99 505 minecraft:nether_bricks
setblock 297 99 463 minecraft:nether_bricks
fill 305 99 463 305 100 463 minecraft:blackstone
fill 308 99 463 308 100 463 minecraft:blackstone
setblock 309 99 463 minecraft:nether_bricks
setblock 309 99 505 minecraft:nether_bricks
fill 310 99 463 312 100 463 minecraft:blackstone
fill 313 99 505 314 100 505 minecraft:blackstone
setblock 314 99 463 minecraft:nether_bricks
fill 315 99 463 315 101 463 minecraft:blackstone
setblock 315 99 505 minecraft:nether_bricks
fill 316 99 505 316 100 505 minecraft:blackstone
setblock 317 99 505 minecraft:nether_bricks
fill 321 99 463 323 100 463 minecraft:blackstone
setblock 324 99 463 minecraft:nether_bricks
setblock 324 99 476 minecraft:nether_bricks
fill 324 99 477 324 100 477 minecraft:blackstone
setblock 324 99 478 minecraft:nether_bricks
setblock 324 99 490 minecraft:nether_bricks
fill 324 99 492 324 100 493 minecraft:blackstone
setblock 324 99 494 minecraft:nether_bricks
fill 324 99 495 324 100 495 minecraft:blackstone
setblock 324 99 497 minecraft:nether_bricks
fill 324 99 498 324 100 499 minecraft:blackstone
setblock 324 99 500 minecraft:nether_bricks
fill 324 99 502 324 100 502 minecraft:blackstone
setblock 282 100 465 minecraft:blackstone
setblock 282 100 471 minecraft:blackstone
setblock 282 100 475 minecraft:blackstone
fill 282 100 480 282 100 481 minecraft:blackstone
setblock 282 100 484 minecraft:blackstone
setblock 282 100 491 minecraft:blackstone
fill 284 100 473 284 105 475 minecraft:polished_blackstone_bricks
fill 284 100 485 284 105 487 minecraft:polished_blackstone_bricks
fill 284 100 497 284 105 499 minecraft:polished_blackstone_bricks
setblock 285 100 463 minecraft:blackstone
fill 290 100 503 292 105 503 minecraft:polished_blackstone_bricks
fill 294 100 465 296 105 465 minecraft:polished_blackstone_bricks
setblock 295 100 463 minecraft:blackstone
fill 296 100 505 297 100 505 minecraft:blackstone
setblock 297 100 463 minecraft:blackstone
fill 302 100 503 304 105 503 minecraft:polished_blackstone_bricks
fill 306 100 465 307 105 465 minecraft:polished_blackstone_bricks
setblock 308 100 465 minecraft:shroomlight
setblock 308 100 467 minecraft:shroomlight
fill 309 100 463 309 101 463 minecraft:blackstone
setblock 309 100 464 minecraft:shroomlight
setblock 309 100 466 minecraft:shroomlight
setblock 309 100 505 minecraft:blackstone
setblock 310 100 465 minecraft:shroomlight
setblock 310 100 467 minecraft:shroomlight
setblock 311 100 464 minecraft:shroomlight
setblock 311 100 466 minecraft:shroomlight
setblock 312 100 465 minecraft:shroomlight
setblock 312 100 467 minecraft:shroomlight
setblock 313 100 464 minecraft:shroomlight
setblock 313 100 466 minecraft:shroomlight
setblock 314 100 463 minecraft:blackstone
setblock 314 100 465 minecraft:shroomlight
setblock 314 100 467 minecraft:shroomlight
fill 314 100 503 316 105 503 minecraft:polished_blackstone_bricks
setblock 315 100 464 minecraft:shroomlight
setblock 315 100 466 minecraft:shroomlight
setblock 315 100 505 minecraft:blackstone
setblock 316 100 465 minecraft:shroomlight
setblock 316 100 467 minecraft:shroomlight
setblock 317 100 464 minecraft:shroomlight
setblock 317 100 466 minecraft:shroomlight
setblock 317 100 505 minecraft:blackstone
setblock 318 100 465 minecraft:shroomlight
setblock 318 100 467 minecraft:shroomlight
setblock 319 100 464 minecraft:shroomlight
setblock 319 100 466 minecraft:shroomlight
setblock 319 100 478 minecraft:shroomlight
setblock 319 100 480 minecraft:shroomlight
setblock 319 100 482 minecraft:shroomlight
setblock 319 100 484 minecraft:shroomlight
setblock 320 100 465 minecraft:shroomlight
setblock 320 100 467 minecraft:shroomlight
setblock 320 100 477 minecraft:shroomlight
setblock 320 100 479 minecraft:shroomlight
setblock 320 100 481 minecraft:shroomlight
setblock 320 100 483 minecraft:shroomlight
setblock 320 100 485 minecraft:shroomlight
setblock 321 100 478 minecraft:shroomlight
setblock 321 100 480 minecraft:shroomlight
setblock 321 100 482 minecraft:shroomlight
setblock 321 100 484 minecraft:shroomlight
fill 322 100 473 322 105 475 minecraft:polished_blackstone_bricks
setblock 322 100 477 minecraft:shroomlight
setblock 322 100 479 minecraft:shroomlight
setblock 322 100 481 minecraft:shroomlight
setblock 322 100 483 minecraft:shroomlight
setblock 322 100 485 minecraft:shroomlight
fill 322 100 486 322 105 487 minecraft:polished_blackstone_bricks
fill 322 100 497 322 105 499 minecraft:polished_blackstone_bricks
setblock 323 100 478 minecraft:shroomlight
setblock 323 100 480 minecraft:shroomlight
setblock 323 100 482 minecraft:shroomlight
setblock 323 100 484 minecraft:shroomlight
setblock 324 100 463 minecraft:blackstone
setblock 324 100 476 minecraft:blackstone
setblock 324 100 478 minecraft:blackstone
setblock 324 100 490 minecraft:blackstone
setblock 324 100 494 minecraft:blackstone
setblock 324 100 497 minecraft:blackstone
setblock 324 100 500 minecraft:blackstone
fill 282 101 463 282 101 479 minecraft:nether_bricks
setblock 282 101 480 minecraft:blackstone
fill 282 101 481 282 101 496 minecraft:nether_bricks
setblock 282 101 497 minecraft:blackstone
fill 282 101 498 282 204 499 minecraft:nether_bricks
setblock 282 101 500 minecraft:blackstone
fill 282 101 501 282 101 505 minecraft:nether_bricks
fill 283 101 463 283 102 463 minecraft:blackstone
fill 283 101 505 285 102 505 minecraft:nether_bricks
fill 284 101 463 286 204 463 minecraft:nether_bricks
fill 286 101 505 286 102 505 minecraft:blackstone
fill 287 101 505 294 101 505 minecraft:nether_bricks
fill 288 101 463 308 101 463 minecraft:nether_bricks
fill 296 101 505 311 101 505 minecraft:nether_bricks
fill 308 101 465 308 102 465 minecraft:polished_blackstone_bricks
fill 308 101 467 308 102 467 minecraft:polished_blackstone_bricks
fill 309 101 464 309 102 464 minecraft:polished_blackstone_bricks
fill 309 101 466 309 102 466 minecraft:polished_blackstone_bricks
fill 310 101 463 314 101 463 minecraft:nether_bricks
fill 310 101 465 310 102 465 minecraft:polished_blackstone_bricks
fill 310 101 467 310 102 467 minecraft:polished_blackstone_bricks
fill 311 101 464 311 102 464 minecraft:polished_blackstone_bricks
fill 311 101 466 311 102 466 minecraft:polished_blackstone_bricks
fill 312 101 465 312 102 465 minecraft:polished_blackstone_bricks
fill 312 101 467 312 102 467 minecraft:polished_blackstone_bricks
setblock 312 101 505 minecraft:blackstone
fill 313 101 464 313 102 464 minecraft:polished_blackstone_bricks
fill 313 101 466 313 102 466 minecraft:polished_blackstone_bricks
fill 313 101 505 324 101 505 minecraft:nether_bricks
fill 314 101 465 314 102 465 minecraft:polished_blackstone_bricks
fill 314 101 467 314 102 467 minecraft:polished_blackstone_bricks
fill 315 101 464 315 102 464 minecraft:polished_blackstone_bricks
fill 315 101 466 315 102 466 minecraft:polished_blackstone_bricks
fill 316 101 463 320 101 463 minecraft:nether_bricks
fill 316 101 465 316 102 465 minecraft:polished_blackstone_bricks
fill 316 101 467 316 102 467 minecraft:polished_blackstone_bricks
fill 317 101 464 317 102 464 minecraft:polished_blackstone_bricks
fill 317 101 466 317 102 466 minecraft:polished_blackstone_bricks
fill 318 101 465 318 102 465 minecraft:polished_blackstone_bricks
fill 318 101 467 318 102 467 minecraft:polished_blackstone_bricks
fill 319 101 464 319 102 464 minecraft:polished_blackstone_bricks
fill 319 101 466 319 102 466 minecraft:polished_blackstone_bricks
fill 319 101 478 319 102 478 minecraft:polished_blackstone_bricks
fill 319 101 480 319 102 480 minecraft:polished_blackstone_bricks
fill 319 101 482 319 102 482 minecraft:polished_blackstone_bricks
fill 319 101 484 319 102 484 minecraft:polished_blackstone_bricks
fill 320 101 465 320 102 465 minecraft:polished_blackstone_bricks
fill 320 101 467 320 102 467 minecraft:polished_blackstone_bricks
fill 320 101 477 320 102 477 minecraft:polished_blackstone_bricks
fill 320 101 479 320 102 479 minecraft:polished_blackstone_bricks
fill 320 101 481 320 102 481 minecraft:polished_blackstone_bricks
fill 320 101 483 320 102 483 minecraft:polished_blackstone_bricks
fill 320 101 485 320 102 485 minecraft:polished_blackstone_bricks
setblock 321 101 463 minecraft:blackstone
fill 321 101 478 321 102 478 minecraft:polished_blackstone_bricks
fill 321 101 480 321 102 480 minecraft:polished_blackstone_bricks
fill 321 101 482 321 102 482 minecraft:polished_blackstone_bricks
fill 321 101 484 321 102 484 minecraft:polished_blackstone_bricks
fill 322 101 463 322 102 463 minecraft:nether_bricks
fill 322 101 477 322 102 477 minecraft:polished_blackstone_bricks
fill 322 101 479 322 102 479 minecraft:polished_blackstone_bricks
fill 322 101 481 322 102 481 minecraft:polished_blackstone_bricks
fill 322 101 483 322 102 483 minecraft:polished_blackstone_bricks
fill 322 101 485 322 102 485 minecraft:polished_blackstone_bricks
setblock 323 101 463 minecraft:blackstone
fill 323 101 478 323 102 478 minecraft:polished_blackstone_bricks
fill 323 101 480 323 102 480 minecraft:polished_blackstone_bricks
fill 323 101 482 323 102 482 minecraft:polished_blackstone_bricks
fill 323 101 484 323 102 484 minecraft:polished_blackstone_bricks
fill 324 101 463 324 101 470 minecraft:nether_bricks
setblock 324 101 471 minecraft:blackstone
fill 324 101 472 324 101 495 minecraft:nether_bricks
fill 324 101 497 324 102 504 minecraft:nether_bricks
fill 282 102 463 282 105 476 minecraft:nether_bricks
fill 282 102 477 282 103 477 minecraft:blackstone
fill 282 102 478 282 102 486 minecraft:nether_bricks
setblock 282 102 487 minecraft:blackstone
fill 282 102 488 282 200 489 minecraft:nether_bricks
setblock 282 102 490 minecraft:blackstone
fill 282 102 491 282 105 497 minecraft:nether_bricks
fill 282 102 500 282 102 504 minecraft:nether_bricks
setblock 282 102 505 minecraft:blackstone
fill 287 102 463 288 201 463 minecraft:nether_bricks
fill 287 102 505 287 201 505 minecraft:nether_bricks
fill 288 102 505 288 103 505 minecraft:blackstone
setblock 289 102 463 minecraft:blackstone
fill 289 102 505 304 102 505 minecraft:nether_bricks
fill 290 102 463 312 102 463 minecraft:nether_bricks
fill 305 102 505 305 103 505 minecraft:blackstone
fill 306 102 505 317 102 505 minecraft:nether_bricks
fill 313 102 463 314 102 463 minecraft:blackstone
fill 315 102 463 316 105 463 minecraft:nether_bricks
setblock 317 102 463 minecraft:blackstone
fill 318 102 463 321 102 463 minecraft:nether_bricks
setblock 318 102 505 minecraft:blackstone
fill 319 102 505 320 102 505 minecraft:nether_bricks
setblock 321 102 505 minecraft:blackstone
fill 322 102 505 324 102 505 minecraft:nether_bricks
fill 323 102 463 324 201 463 minecraft:nether_bricks
fill 324 102 464 324 103 464 minecraft:blackstone
fill 324 102 465 324 102 466 minecraft:nether_bricks
setblock 324 102 467 minecraft:blackstone
fill 324 102 468 324 102 480 minecraft:nether_bricks
setblock 324 102 481 minecraft:blackstone
setblock 324 102 482 minecraft:nether_bricks
fill 324 102 483 324 103 483 minecraft:blackstone
fill 324 102 484 324 102 486 minecraft:nether_bricks
setblock 324 102 487 minecraft:blackstone
fill 324 102 488 324 102 496 minecraft:nether_bricks
setblock 282 103 478 minecraft:blackstone
fill 282 103 479 282 105 481 minecraft:nether_bricks
setblock 282 103 482 minecraft:blackstone
fill 282 103 483 282 105 484 minecraft:nether_bricks
setblock 282 103 485 minecraft:blackstone
fill 282 103 486 282 202 487 minecraft:nether_bricks
fill 282 103 490 282 200 490 minecraft:nether_bricks
fill 282 103 500 282 204 501 minecraft:nether_bricks
setblock 282 103 502 minecraft:blackstone
fill 282 103 503 282 105 505 minecraft:nether_bricks
fill 283 103 463 283 202 463 minecraft:nether_bricks
fill 283 103 505 284 105 505 minecraft:nether_bricks
setblock 285 103 466 minecraft:light[level=14]
setblock 285 103 474 minecraft:light[level=14]
setblock 285 103 482 minecraft:light[level=14]
setblock 285 103 490 minecraft:light[level=14]
setblock 285 103 498 minecraft:light[level=14]
setblock 285 103 505 minecraft:blackstone
fill 286 103 505 286 205 505 minecraft:nether_bricks
fill 289 103 463 293 105 463 minecraft:nether_bricks
fill 289 103 505 291 204 505 minecraft:nether_bricks
setblock 292 103 505 minecraft:blackstone
setblock 293 103 466 minecraft:light[level=14]
setblock 293 103 474 minecraft:light[level=14]
setblock 293 103 482 minecraft:light[level=14]
setblock 293 103 490 minecraft:light[level=14]
setblock 293 103 498 minecraft:light[level=14]
fill 293 103 505 300 105 505 minecraft:nether_bricks
setblock 294 103 463 minecraft:blackstone
fill 295 103 463 309 105 463 minecraft:nether_bricks
setblock 301 103 466 minecraft:light[level=14]
setblock 301 103 474 minecraft:light[level=14]
setblock 301 103 482 minecraft:light[level=14]
setblock 301 103 490 minecraft:light[level=14]
setblock 301 103 498 minecraft:light[level=14]
setblock 301 103 505 minecraft:blackstone
fill 302 103 505 304 201 505 minecraft:nether_bricks
setblock 306 103 505 minecraft:blackstone
fill 307 103 505 314 105 505 minecraft:nether_bricks
setblock 308 103 465 minecraft:shroomlight
setblock 308 103 467 minecraft:shroomlight
setblock 309 103 464 minecraft:shroomlight
setblock 309 103 466 minecraft:shroomlight
setblock 309 103 474 minecraft:light[level=14]
setblock 309 103 482 minecraft:light[level=14]
setblock 309 103 490 minecraft:light[level=14]
setblock 309 103 498 minecraft:light[level=14]
setblock 310 103 463 minecraft:blackstone
setblock 310 103 465 minecraft:shroomlight
setblock 310 103 467 minecraft:shroomlight
fill 311 103 463 313 105 463 minecraft:nether_bricks
setblock 311 103 464 minecraft:shroomlight
setblock 311 103 466 minecraft:shroomlight
setblock 312 103 465 minecraft:shroomlight
setblock 312 103 467 minecraft:shroomlight
setblock 313 103 464 minecraft:shroomlight
setblock 313 103 466 minecraft:shroomlight
setblock 314 103 463 minecraft:blackstone
setblock 314 103 465 minecraft:shroomlight
setblock 314 103 467 minecraft:shroomlight
setblock 315 103 464 minecraft:shroomlight
setblock 315 103 466 minecraft:shroomlight
setblock 315 103 505 minecraft:blackstone
setblock 316 103 465 minecraft:shroomlight
setblock 316 103 467 minecraft:shroomlight
fill 316 103 505 316 204 505 minecraft:nether_bricks
fill 317 103 463 318 204 463 minecraft:nether_bricks
setblock 317 103 464 minecraft:shroomlight
setblock 317 103 466 minecraft:shroomlight
setblock 317 103 474 minecraft:light[level=14]
setblock 317 103 482 minecraft:light[level=14]
setblock 317 103 490 minecraft:light[level=14]
setblock 317 103 498 minecraft:light[level=14]
setblock 317 103 505 minecraft:blackstone
setblock 318 103 465 minecraft:shroomlight
setblock 318 103 467 minecraft:shroomlight
fill 318 103 505 318 105 505 minecraft:nether_bricks
setblock 319 103 463 minecraft:blackstone
setblock 319 103 464 minecraft:shroomlight
setblock 319 103 466 minecraft:shroomlight
setblock 319 103 478 minecraft:shroomlight
setblock 319 103 480 minecraft:shroomlight
setblock 319 103 482 minecraft:shroomlight
setblock 319 103 484 minecraft:shroomlight
setblock 319 103 505 minecraft:blackstone
fill 320 103 463 321 204 463 minecraft:nether_bricks
setblock 320 103 465 minecraft:shroomlight
setblock 320 103 467 minecraft:shroomlight
setblock 320 103 477 minecraft:shroomlight
setblock 320 103 479 minecraft:shroomlight
setblock 320 103 481 minecraft:shroomlight
setblock 320 103 483 minecraft:shroomlight
setblock 320 103 485 minecraft:shroomlight
fill 320 103 505 321 105 505 minecraft:nether_bricks
setblock 321 103 478 minecraft:shroomlight
setblock 321 103 480 minecraft:shroomlight
setblock 321 103 482 minecraft:shroomlight
setblock 321 103 484 minecraft:shroomlight
setblock 322 103 463 minecraft:blackstone
setblock 322 103 477 minecraft:shroomlight
setblock 322 103 479 minecraft:shroomlight
setblock 322 103 481 minecraft:shroomlight
setblock 322 103 483 minecraft:shroomlight
setblock 322 103 485 minecraft:shroomlight
setblock 322 103 505 minecraft:blackstone
setblock 323 103 478 minecraft:shroomlight
setblock 323 103 480 minecraft:shroomlight
setblock 323 103 482 minecraft:shroomlight
setblock 323 103 484 minecraft:shroomlight
fill 323 103 505 324 202 505 minecraft:nether_bricks
fill 324 103 465 324 105 465 minecraft:nether_bricks
setblock 324 103 466 minecraft:blackstone
fill 324 103 467 324 105 471 minecraft:nether_bricks
setblock 324 103 472 minecraft:blackstone
fill 324 103 473 324 105 481 minecraft:nether_bricks
setblock 324 103 482 minecraft:blackstone
setblock 324 103 484 minecraft:blackstone
fill 324 103 485 324 105 488 minecraft:nether_bricks
setblock 324 103 489 minecraft:blackstone
fill 324 103 490 324 105 492 minecraft:nether_bricks
setblock 324 103 493 minecraft:blackstone
fill 324 103 494 324 204 496 minecraft:nether_bricks
setblock 324 103 497 minecraft:blackstone
fill 324 103 498 324 105 504 minecraft:nether_bricks
fill 282 104 477 282 204 478 minecraft:nether_bricks
fill 282 104 482 282 105 482 minecraft:nether_bricks
fill 282 104 485 282 204 485 minecraft:nether_bricks
fill 282 104 502 282 204 502 minecraft:nether_bricks
fill 285 104 505 285 105 505 minecraft:nether_bricks
fill 288 104 505 288 200 505 minecraft:nether_bricks
fill 292 104 505 292 204 505 minecraft:nether_bricks
fill 294 104 463 294 204 463 minecraft:nether_bricks
fill 301 104 505 301 204 505 minecraft:nether_bricks
fill 305 104 505 306 105 505 minecraft:nether_bricks
fill 308 104 465 308 105 465 minecraft:polished_blackstone_bricks
fill 308 104 467 308 105 467 minecraft:polished_blackstone_bricks
fill 309 104 464 309 105 464 minecraft:polished_blackstone_bricks
fill 309 104 466 309 105 466 minecraft:polished_blackstone_bricks
fill 310 104 463 310 204 463 minecraft:nether_bricks
fill 310 104 465 310 105 465 minecraft:polished_blackstone_bricks
fill 310 104 467 310 105 467 minecraft:polished_blackstone_bricks
setblock 311 104 464 minecraft:polished_blackstone_bricks
fill 311 104 466 311 105 466 minecraft:polished_blackstone_bricks
fill 312 104 465 312 105 465 minecraft:polished_blackstone_bricks
fill 312 104 467 312 105 467 minecraft:polished_blackstone_bricks
setblock 313 104 464 minecraft:polished_blackstone_bricks
fill 313 104 466 313 105 466 minecraft:polished_blackstone_bricks
fill 314 104 463 314 105 463 minecraft:nether_bricks
fill 314 104 465 314 105 465 minecraft:polished_blackstone_bricks
fill 314 104 467 314 105 467 minecraft:polished_blackstone_bricks
setblock 315 104 464 minecraft:polished_blackstone_bricks
fill 315 104 466 315 105 466 minecraft:polished_blackstone_bricks
fill 315 104 505 315 204 505 minecraft:nether_bricks
fill 316 104 465 316 105 465 minecraft:polished_blackstone_bricks
fill 316 104 467 316 105 467 minecraft:polished_blackstone_bricks
fill 317 104 464 317 105 464 minecraft:polished_blackstone_bricks
fill 317 104 466 317 105 466 minecraft:polished_blackstone_bricks
fill 317 104 505 317 201 505 minecraft:nether_bricks
fill 318 104 465 318 105 465 minecraft:polished_blackstone_bricks
fill 318 104 467 318 105 467 minecraft:polished_blackstone_bricks
fill 319 104 463 319 200 463 minecraft:nether_bricks
fill 319 104 464 319 105 464 minecraft:polished_blackstone_bricks
fill 319 104 466 319 105 466 minecraft:polished_blackstone_bricks
fill 319 104 478 319 105 478 minecraft:polished_blackstone_bricks
fill 319 104 480 319 105 480 minecraft:polished_blackstone_bricks
fill 319 104 482 319 105 482 minecraft:polished_blackstone_bricks
fill 319 104 484 319 105 484 minecraft:polished_blackstone_bricks
fill 319 104 505 319 105 505 minecraft:nether_bricks
fill 320 104 465 320 105 465 minecraft:polished_blackstone_bricks
fill 320 104 467 320 105 467 minecraft:polished_blackstone_bricks
fill 320 104 477 320 105 477 minecraft:polished_blackstone_bricks
fill 320 104 479 320 105 479 minecraft:polished_blackstone_bricks
fill 320 104 481 320 105 481 minecraft:polished_blackstone_bricks
fill 320 104 483 320 105 483 minecraft:polished_blackstone_bricks
fill 320 104 485 320 105 485 minecraft:polished_blackstone_bricks
fill 321 104 478 321 105 478 minecraft:polished_blackstone_bricks
fill 321 104 480 321 105 480 minecraft:polished_blackstone_bricks
fill 321 104 482 321 105 482 minecraft:polished_blackstone_bricks
fill 321 104 484 321 105 484 minecraft:polished_blackstone_bricks
fill 322 104 463 322 204 463 minecraft:nether_bricks
fill 322 104 477 322 105 477 minecraft:polished_blackstone_bricks
fill 322 104 479 322 105 479 minecraft:polished_blackstone_bricks
fill 322 104 481 322 105 481 minecraft:polished_blackstone_bricks
fill 322 104 483 322 105 483 minecraft:polished_blackstone_bricks
fill 322 104 485 322 105 485 minecraft:polished_blackstone_bricks
fill 322 104 505 322 204 505 minecraft:nether_bricks
setblock 323 104 478 minecraft:polished_blackstone_bricks
setblock 323 104 480 minecraft:polished_blackstone_bricks
fill 323 104 482 323 105 482 minecraft:polished_blackstone_bricks
fill 323 104 484 323 105 484 minecraft:polished_blackstone_bricks
fill 324 104 464 324 105 464 minecraft:nether_bricks
fill 324 104 466 324 105 466 minecraft:nether_bricks
fill 324 104 472 324 204 472 minecraft:nether_bricks
fill 324 104 482 324 204 484 minecraft:nether_bricks
fill 324 104 489 324 105 489 minecraft:nether_bricks
fill 324 104 493 324 204 493 minecraft:nether_bricks
fill 324 104 497 324 204 497 minecraft:nether_bricks
fill 283 105 467 283 105 472 minecraft:nether_bricks
fill 283 105 479 283 105 484 minecraft:nether_bricks
fill 283 105 491 283 105 496 minecraft:nether_bricks
fill 283 105 503 283 105 504 minecraft:nether_bricks
fill 284 105 504 287 105 504 minecraft:nether_bricks
fill 287 105 464 292 105 464 minecraft:nether_bricks
fill 294 105 504 299 105 504 minecraft:nether_bricks
fill 299 105 464 304 105 464 minecraft:nether_bricks
fill 306 105 504 311 105 504 minecraft:nether_bricks
fill 311 105 464 316 105 464 minecraft:nether_bricks
fill 318 105 504 323 105 504 minecraft:nether_bricks
fill 323 105 464 323 105 469 minecraft:nether_bricks
fill 323 105 476 323 105 481 minecraft:nether_bricks
fill 323 105 488 323 105 493 minecraft:nether_bricks
fill 323 105 500 323 105 503 minecraft:nether_bricks
fill 282 106 463 282 200 468 minecraft:nether_bricks
fill 282 106 469 282 111 472 minecraft:shroomlight
fill 282 106 473 282 200 476 minecraft:nether_bricks
fill 282 106 479 282 204 480 minecraft:nether_bricks
fill 282 106 481 282 111 484 minecraft:shroomlight
fill 282 106 491 282 200 492 minecraft:nether_bricks
fill 282 106 493 282 111 496 minecraft:shroomlight
fill 282 106 497 282 204 497 minecraft:nether_bricks
fill 282 106 503 282 200 504 minecraft:nether_bricks
fill 282 106 505 285 111 505 minecraft:shroomlight
fill 289 106 463 292 111 463 minecraft:shroomlight
fill 293 106 463 293 204 463 minecraft:nether_bricks
fill 293 106 505 293 204 505 minecraft:nether_bricks
fill 294 106 505 297 111 505 minecraft:shroomlight
fill 295 106 463 300 204 463 minecraft:nether_bricks
fill 298 106 505 300 204 505 minecraft:nether_bricks
fill 301 106 463 304 111 463 minecraft:shroomlight
fill 305 106 463 309 204 463 minecraft:nether_bricks
fill 305 106 505 305 205 505 minecraft:nether_bricks
fill 306 106 505 309 111 505 minecraft:shroomlight
setblock 308 106 465 minecraft:shroomlight
setblock 308 106 467 minecraft:shroomlight
setblock 309 106 464 minecraft:shroomlight
setblock 309 106 466 minecraft:shroomlight
setblock 310 106 465 minecraft:shroomlight
setblock 310 106 467 minecraft:shroomlight
fill 310 106 505 314 204 505 minecraft:nether_bricks
fill 311 106 463 312 201 463 minecraft:nether_bricks
setblock 311 106 464 minecraft:shroomlight
setblock 311 106 466 minecraft:shroomlight
fill 312 106 464 312 113 464 minecraft:polished_blackstone_bricks
setblock 312 106 465 minecraft:shroomlight
setblock 312 106 467 minecraft:shroomlight
fill 313 106 463 313 106 464 minecraft:shroomlight
setblock 313 106 466 minecraft:shroomlight
fill 314 106 463 316 111 463 minecraft:shroomlight
fill 314 106 464 314 113 464 minecraft:polished_blackstone_bricks
setblock 314 106 465 minecraft:shroomlight
setblock 314 106 467 minecraft:shroomlight
setblock 315 106 464 minecraft:shroomlight
setblock 315 106 466 minecraft:shroomlight
fill 316 106 464 316 113 464 minecraft:polished_blackstone_bricks
setblock 316 106 465 minecraft:shroomlight
setblock 316 106 467 minecraft:shroomlight
setblock 317 106 464 minecraft:shroomlight
setblock 317 106 466 minecraft:shroomlight
setblock 318 106 465 minecraft:shroomlight
setblock 318 106 467 minecraft:shroomlight
fill 318 106 505 321 111 505 minecraft:shroomlight
setblock 319 106 464 minecraft:shroomlight
setblock 319 106 466 minecraft:shroomlight
setblock 319 106 478 minecraft:shroomlight
setblock 319 106 480 minecraft:shroomlight
setblock 319 106 482 minecraft:shroomlight
setblock 319 106 484 minecraft:shroomlight
setblock 320 106 465 minecraft:shroomlight
setblock 320 106 467 minecraft:shroomlight
setblock 320 106 477 minecraft:shroomlight
setblock 320 106 479 minecraft:shroomlight
setblock 320 106 481 minecraft:shroomlight
setblock 320 106 483 minecraft:shroomlight
setblock 320 106 485 minecraft:shroomlight
setblock 321 106 478 minecraft:shroomlight
setblock 321 106 480 minecraft:shroomlight
setblock 321 106 482 minecraft:shroomlight
setblock 321 106 484 minecraft:shroomlight
setblock 322 106 477 minecraft:shroomlight
setblock 322 106 479 minecraft:shroomlight
setblock 322 106 481 minecraft:shroomlight
setblock 322 106 483 minecraft:shroomlight
setblock 322 106 485 minecraft:shroomlight
fill 323 106 477 323 119 477 minecraft:polished_blackstone_bricks
fill 323 106 478 324 106 478 minecraft:shroomlight
fill 323 106 479 323 119 479 minecraft:polished_blackstone_bricks
setblock 323 106 480 minecraft:shroomlight
fill 323 106 481 323 119 481 minecraft:polished_blackstone_bricks
setblock 323 106 482 minecraft:shroomlight
setblock 323 106 484 minecraft:shroomlight
fill 324 106 464 324 111 467 minecraft:shroomlight
fill 324 106 468 324 202 471 minecraft:nether_bricks
fill 324 106 473 324 201 475 minecraft:nether_bricks
fill 324 106 476 324 111 477 minecraft:shroomlight
fill 324 106 479 324 111 479 minecraft:shroomlight
fill 324 106 480 324 204 481 minecraft:nether_bricks
fill 324 106 485 324 204 487 minecraft:nether_bricks
fill 324 106 488 324 111 491 minecraft:shroomlight
fill 324 106 492 324 204 492 minecraft:nether_bricks
fill 324 106 498 324 204 499 minecraft:nether_bricks
fill 324 106 500 324 111 503 minecraft:shroomlight
fill 324 106 504 324 204 504 minecraft:nether_bricks
fill 308 107 465 308 108 465 minecraft:polished_blackstone_bricks
fill 308 107 467 308 108 467 minecraft:polished_blackstone_bricks
fill 309 107 464 309 108 464 minecraft:polished_blackstone_bricks
fill 309 107 466 309 108 466 minecraft:polished_blackstone_bricks
fill 310 107 465 310 108 465 minecraft:polished_blackstone_bricks
fill 310 107 467 310 108 467 minecraft:polished_blackstone_bricks
fill 311 107 464 311 108 464 minecraft:polished_blackstone_bricks
fill 311 107 466 311 108 466 minecraft:polished_blackstone_bricks
fill 312 107 465 312 108 465 minecraft:polished_blackstone_bricks
fill 312 107 467 312 108 467 minecraft:polished_blackstone_bricks
fill 313 107 463 313 111 463 minecraft:shroomlight
fill 313 107 464 313 108 464 minecraft:polished_blackstone_bricks
fill 313 107 466 313 108 466 minecraft:polished_blackstone_bricks
fill 314 107 465 314 108 465 minecraft:polished_blackstone_bricks
fill 314 107 467 314 108 467 minecraft:polished_blackstone_bricks
fill 315 107 464 315 108 464 minecraft:polished_blackstone_bricks
fill 315 107 466 315 108 466 minecraft:polished_blackstone_bricks
fill 316 107 465 316 108 465 minecraft:polished_blackstone_bricks
fill 316 107 467 316 108 467 minecraft:polished_blackstone_bricks
fill 317 107 464 317 108 464 minecraft:polished_blackstone_bricks
fill 317 107 466 317 108 466 minecraft:polished_blackstone_bricks
fill 318 107 465 318 108 465 minecraft:polished_blackstone_bricks
fill 318 107 467 318 108 467 minecraft:polished_blackstone_bricks
fill 319 107 464 319 108 464 minecraft:polished_blackstone_bricks
fill 319 107 466 319 108 466 minecraft:polished_blackstone_bricks
fill 319 107 478 319 108 478 minecraft:polished_blackstone_bricks
fill 319 107 480 319 108 480 minecraft:polished_blackstone_bricks
fill 319 107 482 319 108 482 minecraft:polished_blackstone_bricks
fill 319 107 484 319 108 484 minecraft:polished_blackstone_bricks
fill 320 107 465 320 108 465 minecraft:polished_blackstone_bricks
fill 320 107 467 320 108 467 minecraft:polished_blackstone_bricks
fill 320 107 477 320 108 477 minecraft:polished_blackstone_bricks
fill 320 107 479 320 108 479 minecraft:polished_blackstone_bricks
fill 320 107 481 320 108 481 minecraft:polished_blackstone_bricks
fill 320 107 483 320 108 483 minecraft:polished_blackstone_bricks
fill 320 107 485 320 108 485 minecraft:polished_blackstone_bricks
fill 321 107 478 321 108 478 minecraft:polished_blackstone_bricks
fill 321 107 480 321 108 480 minecraft:polished_blackstone_bricks
fill 321 107 482 321 108 482 minecraft:polished_blackstone_bricks
fill 321 107 484 321 108 484 minecraft:polished_blackstone_bricks
fill 322 107 477 322 108 477 minecraft:polished_blackstone_bricks
fill 322 107 479 322 108 479 minecraft:polished_blackstone_bricks
fill 322 107 481 322 108 481 minecraft:polished_blackstone_bricks
fill 322 107 483 322 108 483 minecraft:polished_blackstone_bricks
fill 322 107 485 322 108 485 minecraft:polished_blackstone_bricks
fill 323 107 478 323 108 478 minecraft:polished_blackstone_bricks
fill 323 107 480 323 108 480 minecraft:polished_blackstone_bricks
fill 323 107 482 323 108 482 minecraft:polished_blackstone_bricks
fill 323 107 484 323 108 484 minecraft:polished_blackstone_bricks
fill 324 107 478 324 112 478 minecraft:shroomlight
setblock 308 109 465 minecraft:shroomlight
setblock 308 109 467 minecraft:shroomlight
setblock 309 109 464 minecraft:shroomlight
setblock 309 109 466 minecraft:shroomlight
setblock 310 109 465 minecraft:shroomlight
setblock 310 109 467 minecraft:shroomlight
setblock 311 109 464 minecraft:shroomlight
setblock 311 109 466 minecraft:shroomlight
setblock 312 109 465 minecraft:shroomlight
setblock 312 109 467 minecraft:shroomlight
setblock 313 109 464 minecraft:shroomlight
setblock 313 109 466 minecraft:shroomlight
setblock 314 109 465 minecraft:shroomlight
setblock 314 109 467 minecraft:shroomlight
setblock 315 109 464 minecraft:shroomlight
setblock 315 109 466 minecraft:shroomlight
setblock 316 109 465 minecraft:shroomlight
setblock 316 109 467 minecraft:shroomlight
setblock 317 109 464 minecraft:shroomlight
setblock 317 109 466 minecraft:shroomlight
setblock 318 109 465 minecraft:shroomlight
setblock 318 109 467 minecraft:shroomlight
setblock 319 109 464 minecraft:shroomlight
setblock 319 109 466 minecraft:shroomlight
setblock 319 109 478 minecraft:shroomlight
setblock 319 109 480 minecraft:shroomlight
setblock 319 109 482 minecraft:shroomlight
setblock 319 109 484 minecraft:shroomlight
setblock 320 109 465 minecraft:shroomlight
setblock 320 109 467 minecraft:shroomlight
setblock 320 109 477 minecraft:shroomlight
setblock 320 109 479 minecraft:shroomlight
setblock 320 109 481 minecraft:shroomlight
setblock 320 109 483 minecraft:shroomlight
setblock 320 109 485 minecraft:shroomlight
setblock 321 109 478 minecraft:shroomlight
setblock 321 109 480 minecraft:shroomlight
setblock 321 109 482 minecraft:shroomlight
setblock 321 109 484 minecraft:shroomlight
setblock 322 109 477 minecraft:shroomlight
setblock 322 109 479 minecraft:shroomlight
setblock 322 109 481 minecraft:shroomlight
setblock 322 109 483 minecraft:shroomlight
setblock 322 109 485 minecraft:shroomlight
setblock 323 109 478 minecraft:shroomlight
setblock 323 109 480 minecraft:shroomlight
setblock 323 109 482 minecraft:shroomlight
setblock 323 109 484 minecraft:shroomlight
fill 308 110 465 308 111 465 minecraft:polished_blackstone_bricks
fill 308 110 467 308 111 467 minecraft:polished_blackstone_bricks
fill 309 110 464 309 111 464 minecraft:polished_blackstone_bricks
fill 309 110 466 309 111 466 minecraft:polished_blackstone_bricks
fill 310 110 465 310 111 465 minecraft:polished_blackstone_bricks
fill 310 110 467 310 111 467 minecraft:polished_blackstone_bricks
fill 311 110 464 311 111 464 minecraft:polished_blackstone_bricks
fill 311 110 466 311 111 466 minecraft:polished_blackstone_bricks
fill 312 110 465 312 111 465 minecraft:polished_blackstone_bricks
fill 312 110 467 312 111 467 minecraft:polished_blackstone_bricks
fill 313 110 464 313 111 464 minecraft:polished_blackstone_bricks
fill 313 110 466 313 111 466 minecraft:polished_blackstone_bricks
fill 314 110 465 314 111 465 minecraft:polished_blackstone_bricks
fill 314 110 467 314 111 467 minecraft:polished_blackstone_bricks
fill 315 110 464 315 111 464 minecraft:polished_blackstone_bricks
fill 315 110 466 315 111 466 minecraft:polished_blackstone_bricks
fill 316 110 465 316 111 465 minecraft:polished_blackstone_bricks
fill 316 110 467 316 111 467 minecraft:polished_blackstone_bricks
fill 317 110 464 317 111 464 minecraft:polished_blackstone_bricks
fill 317 110 466 317 111 466 minecraft:polished_blackstone_bricks
fill 318 110 465 318 111 465 minecraft:polished_blackstone_bricks
fill 318 110 467 318 111 467 minecraft:polished_blackstone_bricks
fill 319 110 464 319 111 464 minecraft:polished_blackstone_bricks
fill 319 110 466 319 111 466 minecraft:polished_blackstone_bricks
fill 319 110 478 319 111 478 minecraft:polished_blackstone_bricks
fill 319 110 480 319 111 480 minecraft:polished_blackstone_bricks
fill 319 110 482 319 111 482 minecraft:polished_blackstone_bricks
fill 319 110 484 319 111 484 minecraft:polished_blackstone_bricks
fill 320 110 465 320 111 465 minecraft:polished_blackstone_bricks
fill 320 110 467 320 111 467 minecraft:polished_blackstone_bricks
fill 320 110 477 320 111 477 minecraft:polished_blackstone_bricks
fill 320 110 479 320 111 479 minecraft:polished_blackstone_bricks
fill 320 110 481 320 111 481 minecraft:polished_blackstone_bricks
fill 320 110 483 320 111 483 minecraft:polished_blackstone_bricks
fill 320 110 485 320 111 485 minecraft:polished_blackstone_bricks
fill 321 110 478 321 111 478 minecraft:polished_blackstone_bricks
fill 321 110 480 321 111 480 minecraft:polished_blackstone_bricks
fill 321 110 482 321 111 482 minecraft:polished_blackstone_bricks
fill 321 110 484 321 111 484 minecraft:polished_blackstone_bricks
fill 322 110 477 322 111 477 minecraft:polished_blackstone_bricks
fill 322 110 479 322 111 479 minecraft:polished_blackstone_bricks
fill 322 110 481 322 111 481 minecraft:polished_blackstone_bricks
fill 322 110 483 322 111 483 minecraft:polished_blackstone_bricks
fill 322 110 485 322 111 485 minecraft:polished_blackstone_bricks
fill 323 110 478 323 111 478 minecraft:polished_blackstone_bricks
fill 323 110 480 323 111 480 minecraft:polished_blackstone_bricks
fill 323 110 482 323 111 482 minecraft:polished_blackstone_bricks
fill 323 110 484 323 111 484 minecraft:polished_blackstone_bricks
setblock 285 111 466 minecraft:light[level=14]
setblock 285 111 474 minecraft:light[level=14]
setblock 285 111 482 minecraft:light[level=14]
setblock 285 111 490 minecraft:light[level=14]
setblock 285 111 498 minecraft:light[level=14]
setblock 293 111 466 minecraft:light[level=14]
setblock 293 111 474 minecraft:light[level=14]
setblock 293 111 482 minecraft:light[level=14]
setblock 293 111 490 minecraft:light[level=14]
setblock 293 111 498 minecraft:light[level=14]
setblock 301 111 466 minecraft:light[level=14]
setblock 301 111 474 minecraft:light[level=14]
setblock 301 111 482 minecraft:light[level=14]
setblock 301 111 490 minecraft:light[level=14]
setblock 301 111 498 minecraft:light[level=14]
setblock 309 111 474 minecraft:light[level=14]
setblock 309 111 482 minecraft:light[level=14]
setblock 309 111 490 minecraft:light[level=14]
setblock 309 111 498 minecraft:light[level=14]
setblock 317 111 474 minecraft:light[level=14]
setblock 317 111 482 minecraft:light[level=14]
setblock 317 111 490 minecraft:light[level=14]
setblock 317 111 498 minecraft:light[level=14]
fill 282 112 469 282 125 469 minecraft:nether_bricks
fill 282 112 470 282 112 471 minecraft:shroomlight
fill 282 112 472 282 125 472 minecraft:nether_bricks
fill 282 112 481 282 125 481 minecraft:nether_bricks
fill 282 112 482 282 112 483 minecraft:shroomlight
fill 282 112 484 282 125 484 minecraft:nether_bricks
fill 282 112 493 282 125 493 minecraft:nether_bricks
fill 282 112 494 282 112 495 minecraft:shroomlight
fill 282 112 496 282 125 496 minecraft:nether_bricks
fill 282 112 505 282 125 505 minecraft:nether_bricks
fill 283 112 505 284 112 505 minecraft:shroomlight
fill 285 112 505 285 125 505 minecraft:nether_bricks
fill 289 112 463 289 125 463 minecraft:nether_bricks
fill 290 112 463 291 112 463 minecraft:shroomlight
fill 292 112 463 292 125 463 minecraft:nether_bricks
fill 294 112 505 294 125 505 minecraft:nether_bricks
fill 295 112 505 296 112 505 minecraft:shroomlight
fill 297 112 505 297 125 505 minecraft:nether_bricks
fill 301 112 463 301 125 463 minecraft:nether_bricks
fill 302 112 463 303 112 463 minecraft:shroomlight
fill 304 112 463 304 125 463 minecraft:nether_bricks
fill 306 112 505 306 125 505 minecraft:nether_bricks
fill 307 112 505 308 112 505 minecraft:shroomlight
setblock 308 112 465 minecraft:shroomlight
setblock 308 112 467 minecraft:shroomlight
setblock 309 112 464 minecraft:shroomlight
setblock 309 112 466 minecraft:shroomlight
fill 309 112 505 309 125 505 minecraft:nether_bricks
setblock 310 112 465 minecraft:shroomlight
setblock 310 112 467 minecraft:shroomlight
setblock 311 112 464 minecraft:shroomlight
setblock 311 112 466 minecraft:shroomlight
setblock 312 112 465 minecraft:shroomlight
setblock 312 112 467 minecraft:shroomlight
fill 313 112 463 313 125 463 minecraft:nether_bricks
setblock 313 112 464 minecraft:shroomlight
setblock 313 112 466 minecraft:shroomlight
fill 314 112 463 315 112 463 minecraft:shroomlight
setblock 314 112 465 minecraft:shroomlight
setblock 314 112 467 minecraft:shroomlight
setblock 315 112 464 minecraft:shroomlight
setblock 315 112 466 minecraft:shroomlight
fill 316 112 463 316 125 463 minecraft:nether_bricks
setblock 316 112 465 minecraft:shroomlight
setblock 316 112 467 minecraft:shroomlight
setblock 317 112 464 minecraft:shroomlight
setblock 317 112 466 minecraft:shroomlight
setblock 318 112 465 minecraft:shroomlight
setblock 318 112 467 minecraft:shroomlight
fill 318 112 505 318 125 505 minecraft:nether_bricks
setblock 319 112 464 minecraft:shroomlight
setblock 319 112 466 minecraft:shroomlight
setblock 319 112 478 minecraft:shroomlight
setblock 319 112 480 minecraft:shroomlight
setblock 319 112 482 minecraft:shroomlight
setblock 319 112 484 minecraft:shroomlight
fill 319 112 505 320 112 505 minecraft:shroomlight
setblock 320 112 465 minecraft:shroomlight
setblock 320 112 467 minecraft:shroomlight
setblock 320 112 477 minecraft:shroomlight
setblock 320 112 479 minecraft:shroomlight
setblock 320 112 481 minecraft:shroomlight
setblock 320 112 483 minecraft:shroomlight
setblock 320 112 485 minecraft:shroomlight
setblock 321 112 478 minecraft:shroomlight
setblock 321 112 480 minecraft:shroomlight
setblock 321 112 482 minecraft:shroomlight
setblock 321 112 484 minecraft:shroomlight
fill 321 112 505 321 125 505 minecraft:nether_bricks
setblock 322 112 477 minecraft:shroomlight
setblock 322 112 479 minecraft:shroomlight
setblock 322 112 481 minecraft:shroomlight
setblock 322 112 483 minecraft:shroomlight
setblock 322 112 485 minecraft:shroomlight
setblock 323 112 478 minecraft:shroomlight
setblock 323 112 480 minecraft:shroomlight
setblock 323 112 482 minecraft:shroomlight
setblock 323 112 484 minecraft:shroomlight
fill 324 112 464 324 125 464 minecraft:nether_bricks
fill 324 112 465 324 112 466 minecraft:shroomlight
fill 324 112 467 324 125 467 minecraft:nether_bricks
fill 324 112 476 324 125 476 minecraft:nether_bricks
setblock 324 112 477 minecraft:shroomlight
fill 324 112 479 324 125 479 minecraft:nether_bricks
fill 324 112 488 324 125 488 minecraft:nether_bricks
fill 324 112 489 324 112 490 minecraft:shroomlight
fill 324 112 491 324 125 491 minecraft:nether_bricks
fill 324 112 500 324 125 500 minecraft:nether_bricks
fill 324 112 501 324 112 502 minecraft:shroomlight
fill 324 112 503 324 125 503 minecraft:nether_bricks
fill 282 113 470 282 125 471 minecraft:nether_bricks
fill 282 113 482 282 125 483 minecraft:nether_bricks
fill 282 113 494 282 125 495 minecraft:nether_bricks
fill 283 113 505 284 125 505 minecraft:nether_bricks
fill 290 113 463 291 125 463 minecraft:nether_bricks
fill 295 113 505 296 125 505 minecraft:nether_bricks
fill 302 113 463 303 125 463 minecraft:nether_bricks
fill 307 113 505 308 125 505 minecraft:nether_bricks
setblock 308 113 465 minecraft:polished_blackstone_bricks
setblock 308 113 467 minecraft:polished_blackstone_bricks
fill 309 113 464 309 157 464 minecraft:polished_blackstone_bricks
setblock 309 113 466 minecraft:polished_blackstone_bricks
setblock 310 113 465 minecraft:polished_blackstone_bricks
setblock 310 113 467 minecraft:polished_blackstone_bricks
setblock 311 113 464 minecraft:polished_blackstone_bricks
setblock 311 113 466 minecraft:polished_blackstone_bricks
setblock 312 113 465 minecraft:polished_blackstone_bricks
setblock 312 113 467 minecraft:polished_blackstone_bricks
setblock 313 113 464 minecraft:polished_blackstone_bricks
setblock 313 113 466 minecraft:polished_blackstone_bricks
fill 314 113 463 315 125 463 minecraft:nether_bricks
setblock 314 113 465 minecraft:polished_blackstone_bricks
setblock 314 113 467 minecraft:polished_blackstone_bricks
setblock 315 113 464 minecraft:polished_blackstone_bricks
setblock 315 113 466 minecraft:polished_blackstone_bricks
setblock 316 113 465 minecraft:polished_blackstone_bricks
setblock 316 113 467 minecraft:polished_blackstone_bricks
setblock 317 113 464 minecraft:polished_blackstone_bricks
setblock 317 113 466 minecraft:polished_blackstone_bricks
setblock 318 113 465 minecraft:polished_blackstone_bricks
setblock 318 113 467 minecraft:polished_blackstone_bricks
fill 319 113 464 319 157 464 minecraft:polished_blackstone_bricks
setblock 319 113 466 minecraft:polished_blackstone_bricks
fill 319 113 478 319 114 478 minecraft:polished_blackstone_bricks
fill 319 113 480 319 114 480 minecraft:polished_blackstone_bricks
fill 319 113 482 319 114 482 minecraft:polished_blackstone_bricks
fill 319 113 484 319 114 484 minecraft:polished_blackstone_bricks
fill 319 113 505 320 125 505 minecraft:nether_bricks
setblock 320 113 465 minecraft:polished_blackstone_bricks
setblock 320 113 467 minecraft:polished_blackstone_bricks
fill 320 113 477 320 114 477 minecraft:polished_blackstone_bricks
fill 320 113 479 320 114 479 minecraft:polished_blackstone_bricks
fill 320 113 481 320 114 481 minecraft:polished_blackstone_bricks
fill 320 113 483 320 114 483 minecraft:polished_blackstone_bricks
fill 320 113 485 320 114 485 minecraft:polished_blackstone_bricks
fill 321 113 478 321 114 478 minecraft:polished_blackstone_bricks
fill 321 113 480 321 114 480 minecraft:polished_blackstone_bricks
fill 321 113 482 321 114 482 minecraft:polished_blackstone_bricks
fill 321 113 484 321 114 484 minecraft:polished_blackstone_bricks
fill 322 113 477 322 114 477 minecraft:polished_blackstone_bricks
fill 322 113 479 322 114 479 minecraft:polished_blackstone_bricks
fill 322 113 481 322 114 481 minecraft:polished_blackstone_bricks
fill 322 113 483 322 114 483 minecraft:polished_blackstone_bricks
fill 322 113 485 322 114 485 minecraft:polished_blackstone_bricks
fill 323 113 478 323 114 478 minecraft:polished_blackstone_bricks
fill 323 113 480 323 114 480 minecraft:polished_blackstone_bricks
fill 323 113 482 323 114 482 minecraft:polished_blackstone_bricks
fill 323 113 484 323 114 484 minecraft:polished_blackstone_bricks
fill 324 113 465 324 125 466 minecraft:nether_bricks
fill 324 113 477 324 125 478 minecraft:nether_bricks
fill 324 113 489 324 125 490 minecraft:nether_bricks
fill 324 113 501 324 125 502 minecraft:nether_bricks
fill 309 114 465 319 114 466 minecraft:gold_block
fill 310 115 465 318 115 466 minecraft:gold_block
setblock 319 115 478 minecraft:shroomlight
setblock 319 115 480 minecraft:shroomlight
setblock 319 115 482 minecraft:shroomlight
setblock 319 115 484 minecraft:shroomlight
setblock 320 115 477 minecraft:shroomlight
setblock 320 115 479 minecraft:shroomlight
setblock 320 115 481 minecraft:shroomlight
setblock 320 115 483 minecraft:shroomlight
setblock 320 115 485 minecraft:shroomlight
setblock 321 115 478 minecraft:shroomlight
setblock 321 115 480 minecraft:shroomlight
setblock 321 115 482 minecraft:shroomlight
setblock 321 115 484 minecraft:shroomlight
setblock 322 115 477 minecraft:shroomlight
setblock 322 115 479 minecraft:shroomlight
setblock 322 115 481 minecraft:shroomlight
setblock 322 115 483 minecraft:shroomlight
setblock 322 115 485 minecraft:shroomlight
setblock 323 115 478 minecraft:shroomlight
setblock 323 115 480 minecraft:shroomlight
setblock 323 115 482 minecraft:shroomlight
setblock 323 115 484 minecraft:shroomlight
fill 311 116 464 317 116 467 minecraft:gold_block
fill 319 116 478 319 117 478 minecraft:polished_blackstone_bricks
fill 319 116 480 319 117 480 minecraft:polished_blackstone_bricks
fill 319 116 482 319 117 482 minecraft:polished_blackstone_bricks
fill 319 116 484 319 117 484 minecraft:polished_blackstone_bricks
fill 320 116 477 320 117 477 minecraft:polished_blackstone_bricks
fill 320 116 479 320 117 479 minecraft:polished_blackstone_bricks
fill 320 116 481 320 117 481 minecraft:polished_blackstone_bricks
fill 320 116 483 320 117 483 minecraft:polished_blackstone_bricks
fill 320 116 485 320 117 485 minecraft:polished_blackstone_bricks
fill 321 116 478 321 117 478 minecraft:polished_blackstone_bricks
fill 321 116 480 321 117 480 minecraft:polished_blackstone_bricks
fill 321 116 482 321 117 482 minecraft:polished_blackstone_bricks
fill 321 116 484 321 117 484 minecraft:polished_blackstone_bricks
fill 322 116 477 322 117 477 minecraft:polished_blackstone_bricks
fill 322 116 479 322 117 479 minecraft:polished_blackstone_bricks
fill 322 116 481 322 117 481 minecraft:polished_blackstone_bricks
fill 322 116 483 322 117 483 minecraft:polished_blackstone_bricks
fill 322 116 485 322 117 485 minecraft:polished_blackstone_bricks
fill 323 116 478 323 117 478 minecraft:polished_blackstone_bricks
fill 323 116 480 323 117 480 minecraft:polished_blackstone_bricks
fill 323 116 482 323 117 482 minecraft:polished_blackstone_bricks
fill 323 116 484 323 117 484 minecraft:polished_blackstone_bricks
fill 301 117 465 301 130 465 minecraft:red_wool
fill 312 117 464 316 117 468 minecraft:gold_block
fill 299 118 465 300 130 465 minecraft:red_wool
fill 302 118 465 303 130 465 minecraft:red_wool
setblock 319 118 478 minecraft:shroomlight
setblock 319 118 480 minecraft:shroomlight
setblock 319 118 482 minecraft:shroomlight
setblock 319 118 484 minecraft:shroomlight
setblock 320 118 477 minecraft:shroomlight
setblock 320 118 479 minecraft:shroomlight
setblock 320 118 481 minecraft:shroomlight
setblock 320 118 483 minecraft:shroomlight
setblock 320 118 485 minecraft:shroomlight
setblock 321 118 478 minecraft:shroomlight
setblock 321 118 480 minecraft:shroomlight
setblock 321 118 482 minecraft:shroomlight
setblock 321 118 484 minecraft:shroomlight
setblock 322 118 477 minecraft:shroomlight
setblock 322 118 479 minecraft:shroomlight
setblock 322 118 481 minecraft:shroomlight
setblock 322 118 483 minecraft:shroomlight
setblock 322 118 485 minecraft:shroomlight
setblock 323 118 478 minecraft:shroomlight
setblock 323 118 480 minecraft:shroomlight
setblock 323 118 482 minecraft:shroomlight
setblock 323 118 484 minecraft:shroomlight
setblock 285 119 466 minecraft:light[level=14]
setblock 285 119 474 minecraft:light[level=14]
setblock 285 119 482 minecraft:light[level=14]
setblock 285 119 490 minecraft:light[level=14]
setblock 285 119 498 minecraft:light[level=14]
setblock 293 119 466 minecraft:light[level=14]
setblock 293 119 474 minecraft:light[level=14]
setblock 293 119 482 minecraft:light[level=14]
setblock 293 119 490 minecraft:light[level=14]
setblock 293 119 498 minecraft:light[level=14]
setblock 301 119 466 minecraft:light[level=14]
setblock 301 119 474 minecraft:light[level=14]
setblock 301 119 482 minecraft:light[level=14]
setblock 301 119 490 minecraft:light[level=14]
setblock 301 119 498 minecraft:light[level=14]
setblock 309 119 466 minecraft:light[level=14]
setblock 309 119 474 minecraft:light[level=14]
setblock 309 119 482 minecraft:light[level=14]
setblock 309 119 490 minecraft:light[level=14]
setblock 309 119 498 minecraft:light[level=14]
setblock 317 119 466 minecraft:light[level=14]
setblock 317 119 474 minecraft:light[level=14]
setblock 317 119 482 minecraft:light[level=14]
setblock 317 119 490 minecraft:light[level=14]
setblock 317 119 498 minecraft:light[level=14]
setblock 319 119 478 minecraft:polished_blackstone_bricks
setblock 319 119 480 minecraft:polished_blackstone_bricks
setblock 319 119 482 minecraft:polished_blackstone_bricks
setblock 319 119 484 minecraft:polished_blackstone_bricks
setblock 320 119 477 minecraft:polished_blackstone_bricks
setblock 320 119 479 minecraft:polished_blackstone_bricks
setblock 320 119 481 minecraft:polished_blackstone_bricks
setblock 320 119 483 minecraft:polished_blackstone_bricks
setblock 320 119 485 minecraft:polished_blackstone_bricks
setblock 321 119 478 minecraft:polished_blackstone_bricks
setblock 321 119 480 minecraft:polished_blackstone_bricks
setblock 321 119 482 minecraft:polished_blackstone_bricks
setblock 321 119 484 minecraft:polished_blackstone_bricks
setblock 322 119 477 minecraft:polished_blackstone_bricks
setblock 322 119 479 minecraft:polished_blackstone_bricks
setblock 322 119 481 minecraft:polished_blackstone_bricks
setblock 322 119 483 minecraft:polished_blackstone_bricks
fill 322 119 485 322 125 485 minecraft:polished_blackstone_bricks
setblock 323 119 478 minecraft:polished_blackstone_bricks
setblock 323 119 480 minecraft:polished_blackstone_bricks
setblock 323 119 482 minecraft:polished_blackstone_bricks
fill 323 119 484 323 157 484 minecraft:polished_blackstone_bricks
fill 284 120 473 284 125 475 minecraft:polished_blackstone_bricks
fill 284 120 485 284 125 487 minecraft:polished_blackstone_bricks
fill 284 120 497 284 125 499 minecraft:polished_blackstone_bricks
fill 290 120 503 292 125 503 minecraft:polished_blackstone_bricks
fill 294 120 465 296 125 465 minecraft:polished_blackstone_bricks
fill 302 120 503 304 125 503 minecraft:polished_blackstone_bricks
fill 306 120 465 308 125 465 minecraft:polished_blackstone_bricks
fill 314 120 503 316 125 503 minecraft:polished_blackstone_bricks
fill 316 120 476 319 121 480 minecraft:nether_bricks
fill 318 120 465 320 125 465 minecraft:polished_blackstone_bricks
fill 320 120 476 320 121 477 minecraft:nether_bricks
fill 320 120 478 322 120 484 minecraft:gold_block
fill 322 120 473 322 125 475 minecraft:polished_blackstone_bricks
fill 322 120 486 322 125 487 minecraft:polished_blackstone_bricks
fill 322 120 497 322 125 499 minecraft:polished_blackstone_bricks
fill 320 121 478 320 121 480 minecraft:nether_bricks
fill 321 121 479 321 121 483 minecraft:gold_block
fill 283 122 466 283 123 468 minecraft:polished_blackstone_bricks
fill 318 122 478 318 127 478 minecraft:bone_block
fill 320 122 480 322 122 482 minecraft:gold_block
fill 322 122 466 323 123 468 minecraft:polished_blackstone_bricks
fill 284 123 466 284 124 468 minecraft:polished_blackstone_bricks
fill 285 123 467 285 126 467 minecraft:polished_blackstone_bricks
fill 316 123 477 317 126 479 minecraft:bone_block
fill 317 123 476 319 126 476 minecraft:bone_block
fill 317 123 480 319 126 480 minecraft:bone_block
fill 318 123 477 320 126 477 minecraft:bone_block
fill 318 123 479 320 126 479 minecraft:bone_block
fill 319 123 478 320 126 478 minecraft:bone_block
fill 319 123 481 323 123 481 minecraft:gold_block
fill 320 123 467 321 125 467 minecraft:polished_blackstone_bricks
fill 321 123 466 321 124 466 minecraft:polished_blackstone_bricks
fill 321 123 468 321 124 468 minecraft:polished_blackstone_bricks
setblock 283 124 467 minecraft:polished_blackstone_bricks
fill 285 124 466 285 125 466 minecraft:polished_blackstone_bricks
fill 285 124 468 285 125 468 minecraft:polished_blackstone_bricks
fill 286 124 467 286 126 467 minecraft:polished_blackstone_bricks
fill 319 124 467 319 126 467 minecraft:polished_blackstone_bricks
fill 320 124 466 320 125 466 minecraft:polished_blackstone_bricks
fill 320 124 468 320 125 468 minecraft:polished_blackstone_bricks
setblock 322 124 467 minecraft:polished_blackstone_bricks
setblock 323 124 467 minecraft:gold_block
fill 283 125 467 283 125 472 minecraft:nether_bricks
fill 283 125 479 283 125 484 minecraft:nether_bricks
fill 283 125 491 283 125 496 minecraft:nether_bricks
fill 283 125 503 283 125 504 minecraft:nether_bricks
setblock 284 125 467 minecraft:polished_blackstone_bricks
fill 284 125 504 287 125 504 minecraft:nether_bricks
fill 286 125 466 287 126 466 minecraft:polished_blackstone_bricks
fill 286 125 468 287 126 468 minecraft:polished_blackstone_bricks
fill 287 125 464 292 125 464 minecraft:nether_bricks
fill 287 125 467 287 127 467 minecraft:polished_blackstone_bricks
fill 294 125 504 299 125 504 minecraft:nether_bricks
fill 299 125 464 304 125 464 minecraft:nether_bricks
fill 306 125 504 311 125 504 minecraft:nether_bricks
fill 311 125 464 316 125 464 minecraft:nether_bricks
fill 318 125 466 318 126 468 minecraft:polished_blackstone_bricks
fill 318 125 504 323 125 504 minecraft:nether_bricks
fill 319 125 466 319 126 466 minecraft:polished_blackstone_bricks
fill 319 125 468 319 126 468 minecraft:polished_blackstone_bricks
setblock 322 125 467 minecraft:gold_block
fill 323 125 464 323 125 469 minecraft:nether_bricks
fill 323 125 476 323 125 481 minecraft:nether_bricks
fill 323 125 488 323 125 493 minecraft:nether_bricks
fill 323 125 500 323 125 503 minecraft:nether_bricks
fill 282 126 469 282 131 472 minecraft:shroomlight
fill 282 126 481 282 131 484 minecraft:shroomlight
fill 282 126 493 282 131 496 minecraft:shroomlight
fill 282 126 505 285 131 505 minecraft:shroomlight
setblock 284 126 467 minecraft:gold_block
fill 288 126 466 288 127 468 minecraft:polished_blackstone_bricks
fill 289 126 463 292 131 463 minecraft:shroomlight
fill 289 126 467 289 128 467 minecraft:polished_blackstone_bricks
fill 294 126 505 297 131 505 minecraft:shroomlight
fill 301 126 463 304 131 463 minecraft:shroomlight
fill 306 126 505 309 131 505 minecraft:shroomlight
fill 313 126 463 316 131 463 minecraft:shroomlight
fill 316 126 467 317 128 467 minecraft:polished_blackstone_bricks
fill 317 126 466 317 127 466 minecraft:polished_blackstone_bricks
fill 317 126 468 317 127 468 minecraft:polished_blackstone_bricks
fill 318 126 505 321 131 505 minecraft:shroomlight
setblock 320 126 467 minecraft:polished_blackstone_bricks
setblock 321 126 467 minecraft:gold_block
fill 324 126 464 324 131 467 minecraft:shroomlight
fill 324 126 476 324 131 479 minecraft:shroomlight
fill 324 126 488 324 131 491 minecraft:shroomlight
fill 324 126 500 324 131 503 minecraft:shroomlight
setblock 285 127 466 minecraft:light[level=14]
setblock 285 127 474 minecraft:light[level=14]
setblock 285 127 482 minecraft:light[level=14]
setblock 285 127 490 minecraft:light[level=14]
setblock 285 127 498 minecraft:light[level=14]
setblock 286 127 467 minecraft:gold_block
fill 289 127 466 289 128 466 minecraft:polished_blackstone_bricks
fill 289 127 468 289 128 468 minecraft:polished_blackstone_bricks
fill 290 127 467 290 129 467 minecraft:polished_blackstone_bricks
setblock 293 127 466 minecraft:light[level=14]
setblock 293 127 474 minecraft:light[level=14]
setblock 293 127 482 minecraft:light[level=14]
setblock 293 127 490 minecraft:light[level=14]
setblock 293 127 498 minecraft:light[level=14]
setblock 301 127 466 minecraft:light[level=14]
setblock 301 127 474 minecraft:light[level=14]
setblock 301 127 482 minecraft:light[level=14]
setblock 301 127 490 minecraft:light[level=14]
setblock 301 127 498 minecraft:light[level=14]
fill 308 127 470 308 139 470 minecraft:gilded_blackstone
setblock 309 127 466 minecraft:light[level=14]
setblock 309 127 474 minecraft:light[level=14]
setblock 309 127 482 minecraft:light[level=14]
setblock 309 127 490 minecraft:light[level=14]
setblock 309 127 498 minecraft:light[level=14]
fill 315 127 467 315 129 467 minecraft:polished_blackstone_bricks
fill 316 127 466 316 128 466 minecraft:polished_blackstone_bricks
fill 316 127 468 316 128 468 minecraft:polished_blackstone_bricks
setblock 317 127 474 minecraft:light[level=14]
setblock 317 127 482 minecraft:light[level=14]
setblock 317 127 490 minecraft:light[level=14]
setblock 317 127 498 minecraft:light[level=14]
setblock 318 127 467 minecraft:polished_blackstone_bricks
setblock 319 127 467 minecraft:gold_block
setblock 287 128 467 minecraft:gold_block
setblock 288 128 467 minecraft:polished_blackstone_bricks
fill 290 128 466 291 128 466 minecraft:polished_blackstone_bricks
fill 290 128 468 291 128 468 minecraft:polished_blackstone_bricks
fill 291 128 467 292 130 467 minecraft:polished_blackstone_bricks
fill 313 128 467 314 130 467 minecraft:polished_blackstone_bricks
fill 314 128 466 315 128 466 minecraft:polished_blackstone_bricks
fill 314 128 468 315 128 468 minecraft:polished_blackstone_bricks
setblock 318 128 467 minecraft:gold_block
setblock 289 129 467 minecraft:gold_block
fill 291 129 466 293 129 466 minecraft:polished_blackstone_bricks
fill 291 129 468 293 129 468 minecraft:polished_blackstone_bricks
fill 293 129 467 294 130 467 minecraft:polished_blackstone_bricks
fill 311 129 467 312 131 467 minecraft:polished_blackstone_bricks
fill 312 129 466 314 129 466 minecraft:polished_blackstone_bricks
fill 312 129 468 314 129 468 minecraft:polished_blackstone_bricks
setblock 316 129 467 minecraft:gold_block
setblock 290 130 467 minecraft:gold_block
fill 292 130 466 295 130 466 minecraft:polished_blackstone_bricks
fill 292 130 468 295 130 468 minecraft:polished_blackstone_bricks
fill 295 130 467 296 132 467 minecraft:polished_blackstone_bricks
fill 309 130 467 310 132 467 minecraft:polished_blackstone_bricks
fill 310 130 466 313 130 466 minecraft:polished_blackstone_bricks
fill 310 130 468 313 130 468 minecraft:polished_blackstone_bricks
setblock 315 130 467 minecraft:gold_block
fill 292 131 467 293 131 467 minecraft:gold_block
fill 294 131 466 294 131 468 minecraft:polished_blackstone_bricks
fill 295 131 466 297 131 466 minecraft:polished_blackstone_bricks
fill 295 131 468 297 131 468 minecraft:polished_blackstone_bricks
fill 297 131 467 300 132 467 minecraft:polished_blackstone_bricks
fill 298 131 465 304 132 465 minecraft:gilded_blackstone
fill 305 131 467 308 132 467 minecraft:polished_blackstone_bricks
fill 308 131 466 311 131 466 minecraft:polished_blackstone_bricks
fill 308 131 468 311 131 468 minecraft:polished_blackstone_bricks
setblock 313 131 467 minecraft:gold_block
fill 282 132 469 282 145 469 minecraft:nether_bricks
fill 282 132 470 282 132 471 minecraft:shroomlight
fill 282 132 472 282 145 472 minecraft:nether_bricks
fill 282 132 481 282 145 481 minecraft:nether_bricks
fill 282 132 482 282 132 483 minecraft:shroomlight
fill 282 132 484 282 145 484 minecraft:nether_bricks
fill 282 132 493 282 145 493 minecraft:nether_bricks
fill 282 132 494 282 132 495 minecraft:shroomlight
fill 282 132 496 282 145 496 minecraft:nether_bricks
fill 282 132 505 282 145 505 minecraft:nether_bricks
fill 283 132 505 284 132 505 minecraft:shroomlight
fill 285 132 505 285 145 505 minecraft:nether_bricks
fill 289 132 463 289 145 463 minecraft:nether_bricks
fill 289 132 500 289 138 500 minecraft:gilded_blackstone
fill 290 132 463 291 132 463 minecraft:shroomlight
fill 291 132 464 293 133 464 minecraft:polished_blackstone_bricks
fill 291 132 503 293 133 503 minecraft:polished_blackstone_bricks
fill 292 132 463 292 145 463 minecraft:nether_bricks
fill 292 132 504 293 133 504 minecraft:polished_blackstone_bricks
fill 293 132 467 294 132 467 minecraft:gold_block
fill 294 132 505 294 145 505 minecraft:nether_bricks
fill 295 132 505 296 132 505 minecraft:shroomlight
fill 296 132 466 309 132 466 minecraft:polished_blackstone_bricks
fill 296 132 468 309 132 468 minecraft:polished_blackstone_bricks
fill 297 132 505 297 145 505 minecraft:nether_bricks
fill 301 132 463 301 145 463 minecraft:nether_bricks
fill 301 132 467 304 133 467 minecraft:polished_blackstone_bricks
fill 302 132 463 303 132 463 minecraft:shroomlight
fill 304 132 463 304 145 463 minecraft:nether_bricks
fill 306 132 505 306 145 505 minecraft:nether_bricks
fill 307 132 505 308 132 505 minecraft:shroomlight
fill 309 132 505 309 145 505 minecraft:nether_bricks
fill 311 132 467 312 132 467 minecraft:gold_block
fill 313 132 463 313 145 463 minecraft:nether_bricks
fill 314 132 463 315 132 463 minecraft:shroomlight
fill 316 132 463 316 145 463 minecraft:nether_bricks
fill 316 132 465 316 142 465 minecraft:red_wool
fill 318 132 505 318 145 505 minecraft:nether_bricks
fill 319 132 505 320 132 505 minecraft:shroomlight
fill 321 132 505 321 145 505 minecraft:nether_bricks
fill 324 132 464 324 145 464 minecraft:nether_bricks
fill 324 132 465 324 132 466 minecraft:shroomlight
fill 324 132 467 324 145 467 minecraft:nether_bricks
fill 324 132 476 324 145 476 minecraft:nether_bricks
fill 324 132 477 324 132 478 minecraft:shroomlight
fill 324 132 479 324 145 479 minecraft:nether_bricks
fill 324 132 488 324 145 488 minecraft:nether_bricks
fill 324 132 489 324 132 490 minecraft:shroomlight
fill 324 132 491 324 145 491 minecraft:nether_bricks
fill 324 132 500 324 145 500 minecraft:nether_bricks
fill 324 132 501 324 132 502 minecraft:shroomlight
fill 324 132 503 324 145 503 minecraft:nether_bricks
fill 282 133 470 282 145 471 minecraft:nether_bricks
fill 282 133 482 282 145 483 minecraft:nether_bricks
fill 282 133 494 282 145 495 minecraft:nether_bricks
fill 283 133 505 284 145 505 minecraft:nether_bricks
fill 290 133 463 291 145 463 minecraft:nether_bricks
fill 291 133 465 293 134 465 minecraft:polished_blackstone_bricks
fill 291 133 502 293 134 502 minecraft:polished_blackstone_bricks
fill 292 133 466 292 136 466 minecraft:polished_blackstone_bricks
fill 292 133 501 292 136 501 minecraft:polished_blackstone_bricks
fill 295 133 467 297 133 467 minecraft:gold_block
fill 295 133 505 296 145 505 minecraft:nether_bricks
fill 298 133 467 300 133 467 minecraft:polished_blackstone_bricks
fill 300 133 466 305 133 466 minecraft:polished_blackstone_bricks
fill 300 133 468 305 133 468 minecraft:polished_blackstone_bricks
fill 302 133 463 303 145 463 minecraft:nether_bricks
fill 305 133 467 307 133 467 minecraft:polished_blackstone_bricks
fill 307 133 505 308 145 505 minecraft:nether_bricks
fill 308 133 467 310 133 467 minecraft:gold_block
fill 314 133 463 315 145 463 minecraft:nether_bricks
fill 314 133 465 315 142 465 minecraft:red_wool
fill 317 133 465 318 139 465 minecraft:red_wool
fill 319 133 505 320 145 505 minecraft:nether_bricks
fill 324 133 465 324 145 466 minecraft:nether_bricks
fill 324 133 477 324 145 478 minecraft:nether_bricks
fill 324 133 489 324 145 490 minecraft:nether_bricks
fill 324 133 501 324 145 502 minecraft:nether_bricks
fill 291 134 466 291 135 466 minecraft:polished_blackstone_bricks
fill 291 134 501 291 135 501 minecraft:polished_blackstone_bricks
setblock 292 134 464 minecraft:polished_blackstone_bricks
fill 292 134 467 292 136 467 minecraft:polished_blackstone_bricks
fill 292 134 500 292 136 500 minecraft:polished_blackstone_bricks
setblock 292 134 503 minecraft:polished_blackstone_bricks
setblock 292 134 504 minecraft:gold_block
fill 293 134 466 293 135 466 minecraft:polished_blackstone_bricks
fill 293 134 501 293 135 501 minecraft:polished_blackstone_bricks
fill 298 134 467 307 134 467 minecraft:gold_block
fill 283 135 501 283 136 501 minecraft:polished_blackstone_bricks
setblock 285 135 466 minecraft:light[level=14]
setblock 285 135 474 minecraft:light[level=14]
setblock 285 135 482 minecraft:light[level=14]
setblock 285 135 490 minecraft:light[level=14]
setblock 285 135 498 minecraft:light[level=14]
fill 291 135 467 291 136 468 minecraft:polished_blackstone_bricks
fill 291 135 499 291 136 500 minecraft:polished_blackstone_bricks
setblock 292 135 464 minecraft:gold_block
setblock 292 135 465 minecraft:polished_blackstone_bricks
fill 292 135 468 293 136 468 minecraft:polished_blackstone_bricks
fill 292 135 499 293 136 499 minecraft:polished_blackstone_bricks
setblock 292 135 502 minecraft:polished_blackstone_bricks
setblock 292 135 503 minecraft:gold_block
fill 293 135 467 293 136 467 minecraft:polished_blackstone_bricks
setblock 293 135 474 minecraft:light[level=14]
setblock 293 135 482 minecraft:light[level=14]
setblock 293 135 490 minecraft:light[level=14]
setblock 293 135 498 minecraft:light[level=14]
fill 293 135 500 293 136 500 minecraft:polished_blackstone_bricks
setblock 301 135 466 minecraft:light[level=14]
setblock 301 135 474 minecraft:light[level=14]
setblock 301 135 482 minecraft:light[level=14]
setblock 301 135 490 minecraft:light[level=14]
setblock 301 135 498 minecraft:light[level=14]
setblock 309 135 466 minecraft:light[level=14]
setblock 309 135 474 minecraft:light[level=14]
setblock 309 135 482 minecraft:light[level=14]
setblock 309 135 490 minecraft:light[level=14]
setblock 309 135 498 minecraft:light[level=14]
setblock 317 135 466 minecraft:light[level=14]
setblock 317 135 474 minecraft:light[level=14]
setblock 317 135 482 minecraft:light[level=14]
setblock 317 135 490 minecraft:light[level=14]
setblock 317 135 498 minecraft:light[level=14]
fill 322 135 499 323 136 501 minecraft:polished_blackstone_bricks
fill 284 136 499 284 137 501 minecraft:polished_blackstone_bricks
fill 285 136 500 285 139 500 minecraft:polished_blackstone_bricks
fill 291 136 469 293 137 469 minecraft:polished_blackstone_bricks
fill 291 136 498 293 137 498 minecraft:polished_blackstone_bricks
setblock 292 136 465 minecraft:gold_block
fill 292 136 470 292 138 470 minecraft:polished_blackstone_bricks
fill 292 136 497 292 138 497 minecraft:polished_blackstone_bricks
setblock 292 136 502 minecraft:gold_block
fill 320 136 500 321 138 500 minecraft:polished_blackstone_bricks
fill 321 136 499 321 137 499 minecraft:polished_blackstone_bricks
fill 321 136 501 321 137 501 minecraft:polished_blackstone_bricks
fill 285 137 499 285 138 499 minecraft:polished_blackstone_bricks
fill 285 137 501 285 138 501 minecraft:polished_blackstone_bricks
fill 286 137 500 286 139 500 minecraft:polished_blackstone_bricks
fill 291 137 470 291 138 470 minecraft:polished_blackstone_bricks
fill 291 137 497 291 138 497 minecraft:polished_blackstone_bricks
setblock 292 137 467 minecraft:gold_block
setblock 292 137 468 minecraft:polished_blackstone_bricks
fill 292 137 471 292 139 471 minecraft:polished_blackstone_bricks
fill 292 137 496 292 139 496 minecraft:polished_blackstone_bricks
setblock 292 137 499 minecraft:polished_blackstone_bricks
setblock 292 137 500 minecraft:gold_block
fill 293 137 470 293 138 470 minecraft:polished_blackstone_bricks
fill 293 137 497 293 138 497 minecraft:polished_blackstone_bricks
fill 319 137 500 319 139 500 minecraft:polished_blackstone_bricks
fill 320 137 499 320 138 499 minecraft:polished_blackstone_bricks
fill 320 137 501 320 138 501 minecraft:polished_blackstone_bricks
setblock 322 137 500 minecraft:polished_blackstone_bricks
setblock 323 137 500 minecraft:gold_block
setblock 284 138 500 minecraft:polished_blackstone_bricks
fill 286 138 499 287 139 499 minecraft:polished_blackstone_bricks
fill 286 138 501 287 139 501 minecraft:polished_blackstone_bricks
fill 287 138 500 287 140 500 minecraft:polished_blackstone_bricks
fill 291 138 471 291 138 472 minecraft:polished_blackstone_bricks
fill 291 138 495 291 138 496 minecraft:polished_blackstone_bricks
setblock 292 138 468 minecraft:gold_block
setblock 292 138 469 minecraft:polished_blackstone_bricks
fill 292 138 472 292 140 473 minecraft:polished_blackstone_bricks
fill 292 138 494 292 140 495 minecraft:polished_blackstone_bricks
setblock 292 138 498 minecraft:polished_blackstone_bricks
setblock 292 138 499 minecraft:gold_block
fill 293 138 471 293 138 472 minecraft:polished_blackstone_bricks
fill 293 138 495 293 138 496 minecraft:polished_blackstone_bricks
fill 318 138 499 318 139 501 minecraft:polished_blackstone_bricks
fill 319 138 499 319 139 499 minecraft:polished_blackstone_bricks
fill 319 138 501 319 139 501 minecraft:polished_blackstone_bricks
setblock 322 138 500 minecraft:gold_block
setblock 284 139 500 minecraft:gold_block
fill 288 139 499 288 140 501 minecraft:polished_blackstone_bricks
fill 289 139 500 289 141 500 minecraft:polished_blackstone_bricks
fill 291 139 472 291 139 474 minecraft:polished_blackstone_bricks
fill 291 139 493 291 139 495 minecraft:polished_blackstone_bricks
setblock 292 139 470 minecraft:gold_block
fill 292 139 474 292 140 475 minecraft:polished_blackstone_bricks
fill 292 139 492 292 141 493 minecraft:polished_blackstone_bricks
setblock 292 139 497 minecraft:gold_block
fill 293 139 472 293 139 474 minecraft:polished_blackstone_bricks
fill 293 139 493 293 139 495 minecraft:polished_blackstone_bricks
fill 316 139 500 317 141 500 minecraft:polished_blackstone_bricks
fill 317 139 499 317 140 499 minecraft:polished_blackstone_bricks
fill 317 139 501 317 140 501 minecraft:polished_blackstone_bricks
setblock 320 139 500 minecraft:polished_blackstone_bricks
setblock 321 139 500 minecraft:gold_block
fill 284 140 473 284 145 475 minecraft:polished_blackstone_bricks
fill 284 140 485 284 145 487 minecraft:polished_blackstone_bricks
fill 284 140 497 284 145 499 minecraft:polished_blackstone_bricks
setblock 286 140 500 minecraft:gold_block
fill 289 140 499 289 141 499 minecraft:polished_blackstone_bricks
fill 289 140 501 289 141 501 minecraft:polished_blackstone_bricks
fill 290 140 500 290 142 500 minecraft:polished_blackstone_bricks
fill 290 140 503 292 145 503 minecraft:polished_blackstone_bricks
fill 291 140 473 291 140 476 minecraft:polished_blackstone_bricks
fill 291 140 491 291 140 494 minecraft:polished_blackstone_bricks
setblock 292 140 471 minecraft:gold_block
fill 292 140 476 292 142 477 minecraft:polished_blackstone_bricks
fill 292 140 490 292 142 491 minecraft:polished_blackstone_bricks
setblock 292 140 496 minecraft:gold_block
fill 293 140 473 293 140 476 minecraft:polished_blackstone_bricks
fill 293 140 491 293 140 494 minecraft:polished_blackstone_bricks
fill 294 140 465 296 145 465 minecraft:polished_blackstone_bricks
fill 302 140 503 304 145 503 minecraft:polished_blackstone_bricks
fill 306 140 465 308 145 465 minecraft:polished_blackstone_bricks
fill 314 140 503 316 145 503 minecraft:polished_blackstone_bricks
fill 315 140 500 315 142 500 minecraft:polished_blackstone_bricks
fill 316 140 499 316 141 499 minecraft:polished_blackstone_bricks
fill 316 140 501 316 141 501 minecraft:polished_blackstone_bricks
fill 317 140 465 317 142 465 minecraft:red_wool
fill 318 140 465 320 145 465 minecraft:polished_blackstone_bricks
setblock 318 140 500 minecraft:polished_blackstone_bricks
setblock 319 140 500 minecraft:gold_block
fill 322 140 473 322 145 475 minecraft:polished_blackstone_bricks
fill 322 140 485 322 145 487 minecraft:polished_blackstone_bricks
fill 322 140 497 322 145 499 minecraft:polished_blackstone_bricks
setblock 287 141 500 minecraft:gold_block
setblock 288 141 500 minecraft:polished_blackstone_bricks
fill 290 141 499 291 141 499 minecraft:polished_blackstone_bricks
fill 290 141 501 291 141 501 minecraft:polished_blackstone_bricks
fill 291 141 475 291 141 478 minecraft:polished_blackstone_bricks
fill 291 141 489 291 141 492 minecraft:polished_blackstone_bricks
fill 291 141 500 292 143 500 minecraft:polished_blackstone_bricks
fill 292 141 473 292 141 474 minecraft:gold_block
fill 292 141 475 293 141 475 minecraft:polished_blackstone_bricks
fill 292 141 478 292 142 481 minecraft:polished_blackstone_bricks
fill 292 141 486 292 142 489 minecraft:polished_blackstone_bricks
setblock 292 141 494 minecraft:gold_block
fill 293 141 476 293 141 478 minecraft:polished_blackstone_bricks
fill 293 141 489 293 141 492 minecraft:polished_blackstone_bricks
fill 313 141 500 314 143 500 minecraft:polished_blackstone_bricks
fill 314 141 499 315 141 499 minecraft:polished_blackstone_bricks
fill 314 141 501 315 141 501 minecraft:polished_blackstone_bricks
setblock 318 141 500 minecraft:gold_block
setblock 289 142 500 minecraft:gold_block
fill 291 142 477 291 142 490 minecraft:polished_blackstone_bricks
fill 291 142 499 293 142 499 minecraft:polished_blackstone_bricks
fill 291 142 501 293 142 501 minecraft:polished_blackstone_bricks
fill 292 142 474 292 142 475 minecraft:gold_block
fill 292 142 482 293 143 485 minecraft:polished_blackstone_bricks
fill 292 142 492 292 142 493 minecraft:gold_block
fill 293 142 477 293 142 481 minecraft:polished_blackstone_bricks
fill 293 142 486 293 142 490 minecraft:polished_blackstone_bricks
fill 293 142 500 294 144 500 minecraft:polished_blackstone_bricks
fill 311 142 500 312 144 500 minecraft:polished_blackstone_bricks
fill 312 142 499 314 142 499 minecraft:polished_blackstone_bricks
fill 312 142 501 314 142 501 minecraft:polished_blackstone_bricks
setblock 316 142 500 minecraft:gold_block
setblock 285 143 466 minecraft:light[level=14]
setblock 285 143 474 minecraft:light[level=14]
setblock 285 143 482 minecraft:light[level=14]
setblock 285 143 490 minecraft:light[level=14]
setblock 285 143 498 minecraft:light[level=14]
fill 289 143 500 289 151 500 minecraft:gilded_blackstone
setblock 290 143 500 minecraft:gold_block
fill 291 143 481 291 143 486 minecraft:polished_blackstone_bricks
fill 292 143 476 292 143 478 minecraft:gold_block
fill 292 143 479 292 143 481 minecraft:polished_blackstone_bricks
fill 292 143 486 292 143 488 minecraft:polished_blackstone_bricks
fill 292 143 489 292 143 491 minecraft:gold_block
fill 292 143 499 295 143 499 minecraft:polished_blackstone_bricks
fill 292 143 501 295 143 501 minecraft:polished_blackstone_bricks
setblock 293 143 466 minecraft:light[level=14]
setblock 293 143 474 minecraft:light[level=14]
setblock 293 143 481 minecraft:polished_blackstone_bricks
setblock 293 143 486 minecraft:polished_blackstone_bricks
setblock 293 143 490 minecraft:light[level=14]
setblock 293 143 498 minecraft:light[level=14]
fill 295 143 500 296 145 500 minecraft:polished_blackstone_bricks
setblock 301 143 466 minecraft:light[level=14]
setblock 301 143 474 minecraft:light[level=14]
setblock 301 143 482 minecraft:light[level=14]
setblock 301 143 490 minecraft:light[level=14]
setblock 301 143 498 minecraft:light[level=14]
setblock 309 143 466 minecraft:light[level=14]
setblock 309 143 474 minecraft:light[level=14]
setblock 309 143 482 minecraft:light[level=14]
setblock 309 143 490 minecraft:light[level=14]
setblock 309 143 498 minecraft:light[level=14]
fill 309 143 500 310 145 500 minecraft:polished_blackstone_bricks
fill 310 143 499 313 143 499 minecraft:polished_blackstone_bricks
fill 310 143 501 313 143 501 minecraft:polished_blackstone_bricks
fill 313 143 465 317 144 465 minecraft:gilded_blackstone
setblock 315 143 500 minecraft:gold_block
setblock 317 143 466 minecraft:light[level=14]
setblock 317 143 474 minecraft:light[level=14]
setblock 317 143 482 minecraft:light[level=14]
setblock 317 143 490 minecraft:light[level=14]
setblock 317 143 498 minecraft:light[level=14]
fill 292 144 479 292 144 488 minecraft:gold_block
setblock 292 144 500 minecraft:gold_block
fill 294 144 499 297 144 499 minecraft:polished_blackstone_bricks
fill 294 144 501 297 144 501 minecraft:polished_blackstone_bricks
fill 297 144 500 300 145 500 minecraft:polished_blackstone_bricks
fill 305 144 500 308 145 500 minecraft:polished_blackstone_bricks
fill 308 144 499 311 144 499 minecraft:polished_blackstone_bricks
fill 308 144 501 311 144 501 minecraft:polished_blackstone_bricks
setblock 313 144 500 minecraft:gold_block
fill 283 145 467 283 145 472 minecraft:nether_bricks
fill 283 145 479 283 145 484 minecraft:nether_bricks
fill 283 145 491 283 145 496 minecraft:nether_bricks
fill 283 145 503 283 145 504 minecraft:nether_bricks
fill 284 145 504 287 145 504 minecraft:nether_bricks
fill 287 145 464 292 145 464 minecraft:nether_bricks
fill 293 145 500 294 145 500 minecraft:gold_block
fill 294 145 504 299 145 504 minecraft:nether_bricks
fill 297 145 499 308 145 499 minecraft:polished_blackstone_bricks
fill 297 145 501 308 145 501 minecraft:polished_blackstone_bricks
fill 299 145 464 304 145 464 minecraft:nether_bricks
fill 301 145 500 304 146 500 minecraft:polished_blackstone_bricks
fill 306 145 504 311 145 504 minecraft:nether_bricks
fill 311 145 464 316 145 464 minecraft:nether_bricks
fill 311 145 500 312 145 500 minecraft:gold_block
fill 318 145 504 323 145 504 minecraft:nether_bricks
fill 323 145 464 323 145 469 minecraft:nether_bricks
fill 323 145 476 323 145 481 minecraft:nether_bricks
fill 323 145 488 323 145 493 minecraft:nether_bricks
fill 323 145 500 323 145 503 minecraft:nether_bricks
fill 282 146 469 282 151 472 minecraft:shroomlight
fill 282 146 481 282 151 484 minecraft:shroomlight
fill 282 146 493 282 151 496 minecraft:shroomlight
fill 282 146 505 285 151 505 minecraft:shroomlight
fill 289 146 463 292 151 463 minecraft:shroomlight
fill 294 146 505 297 151 505 minecraft:shroomlight
fill 296 146 500 297 146 500 minecraft:gold_block
fill 298 146 500 300 146 500 minecraft:polished_blackstone_bricks
fill 300 146 499 305 146 499 minecraft:polished_blackstone_bricks
fill 300 146 501 305 146 501 minecraft:polished_blackstone_bricks
fill 301 146 463 304 151 463 minecraft:shroomlight
fill 305 146 500 307 146 500 minecraft:polished_blackstone_bricks
fill 306 146 505 309 151 505 minecraft:shroomlight
fill 308 146 500 309 146 500 minecraft:gold_block
fill 313 146 463 316 151 463 minecraft:shroomlight
fill 318 146 505 321 151 505 minecraft:shroomlight
fill 324 146 464 324 151 467 minecraft:shroomlight
fill 324 146 476 324 151 479 minecraft:shroomlight
fill 324 146 488 324 151 491 minecraft:shroomlight
fill 324 146 500 324 151 503 minecraft:shroomlight
fill 298 147 500 307 147 500 minecraft:gold_block
setblock 285 151 466 minecraft:light[level=14]
setblock 285 151 474 minecraft:light[level=14]
setblock 285 151 482 minecraft:light[level=14]
setblock 285 151 490 minecraft:light[level=14]
setblock 285 151 498 minecraft:light[level=14]
setblock 293 151 466 minecraft:light[level=14]
setblock 293 151 474 minecraft:light[level=14]
setblock 293 151 482 minecraft:light[level=14]
setblock 293 151 490 minecraft:light[level=14]
setblock 293 151 498 minecraft:light[level=14]
setblock 301 151 466 minecraft:light[level=14]
setblock 301 151 474 minecraft:light[level=14]
setblock 301 151 482 minecraft:light[level=14]
setblock 301 151 490 minecraft:light[level=14]
setblock 301 151 498 minecraft:light[level=14]
setblock 309 151 466 minecraft:light[level=14]
setblock 309 151 474 minecraft:light[level=14]
setblock 309 151 482 minecraft:light[level=14]
setblock 309 151 490 minecraft:light[level=14]
setblock 309 151 498 minecraft:light[level=14]
setblock 317 151 466 minecraft:light[level=14]
setblock 317 151 474 minecraft:light[level=14]
setblock 317 151 482 minecraft:light[level=14]
setblock 317 151 490 minecraft:light[level=14]
setblock 317 151 498 minecraft:light[level=14]
fill 282 152 469 282 167 469 minecraft:nether_bricks
fill 282 152 470 282 152 471 minecraft:shroomlight
fill 282 152 472 282 167 472 minecraft:nether_bricks
fill 282 152 481 282 167 481 minecraft:nether_bricks
fill 282 152 482 282 152 483 minecraft:shroomlight
fill 282 152 484 282 167 484 minecraft:nether_bricks
fill 282 152 493 282 167 493 minecraft:nether_bricks
fill 282 152 494 282 152 495 minecraft:shroomlight
fill 282 152 496 282 167 496 minecraft:nether_bricks
fill 282 152 505 282 167 505 minecraft:nether_bricks
fill 283 152 505 284 152 505 minecraft:shroomlight
fill 285 152 505 285 167 505 minecraft:nether_bricks
fill 289 152 463 289 167 463 minecraft:nether_bricks
fill 290 152 463 291 152 463 minecraft:shroomlight
fill 292 152 463 292 167 463 minecraft:nether_bricks
fill 294 152 505 294 167 505 minecraft:nether_bricks
fill 295 152 505 296 152 505 minecraft:shroomlight
fill 297 152 505 297 167 505 minecraft:nether_bricks
fill 301 152 463 301 167 463 minecraft:nether_bricks
fill 302 152 463 303 152 463 minecraft:shroomlight
fill 304 152 463 304 167 463 minecraft:nether_bricks
fill 306 152 505 306 167 505 minecraft:nether_bricks
fill 307 152 505 308 152 505 minecraft:shroomlight
fill 309 152 505 309 167 505 minecraft:nether_bricks
fill 313 152 463 313 167 463 minecraft:nether_bricks
fill 314 152 463 315 152 463 minecraft:shroomlight
fill 316 152 463 316 167 463 minecraft:nether_bricks
fill 318 152 505 318 167 505 minecraft:nether_bricks
fill 319 152 505 320 152 505 minecraft:shroomlight
fill 321 152 505 321 167 505 minecraft:nether_bricks
fill 324 152 464 324 167 464 minecraft:nether_bricks
fill 324 152 465 324 152 466 minecraft:shroomlight
fill 324 152 467 324 167 467 minecraft:nether_bricks
fill 324 152 476 324 167 476 minecraft:nether_bricks
fill 324 152 477 324 152 478 minecraft:shroomlight
fill 324 152 479 324 167 479 minecraft:nether_bricks
fill 324 152 488 324 167 488 minecraft:nether_bricks
fill 324 152 489 324 152 490 minecraft:shroomlight
fill 324 152 491 324 167 491 minecraft:nether_bricks
fill 324 152 500 324 167 500 minecraft:nether_bricks
fill 324 152 501 324 152 502 minecraft:shroomlight
fill 324 152 503 324 167 503 minecraft:nether_bricks
fill 282 153 470 282 167 471 minecraft:nether_bricks
fill 282 153 482 282 167 483 minecraft:nether_bricks
fill 282 153 494 282 167 495 minecraft:nether_bricks
fill 283 153 505 284 167 505 minecraft:nether_bricks
fill 290 153 463 291 167 463 minecraft:nether_bricks
fill 295 153 505 296 167 505 minecraft:nether_bricks
fill 302 153 463 303 167 463 minecraft:nether_bricks
fill 307 153 505 308 167 505 minecraft:nether_bricks
fill 314 153 463 315 167 463 minecraft:nether_bricks
fill 319 153 505 320 167 505 minecraft:nether_bricks
fill 324 153 465 324 167 466 minecraft:nether_bricks
fill 324 153 477 324 167 478 minecraft:nether_bricks
fill 324 153 489 324 167 490 minecraft:nether_bricks
fill 324 153 501 324 167 502 minecraft:nether_bricks
setblock 285 159 466 minecraft:light[level=14]
setblock 285 159 474 minecraft:light[level=14]
setblock 285 159 482 minecraft:light[level=14]
setblock 285 159 490 minecraft:light[level=14]
setblock 285 159 498 minecraft:light[level=14]
setblock 293 159 466 minecraft:light[level=14]
setblock 293 159 474 minecraft:light[level=14]
setblock 293 159 482 minecraft:light[level=14]
setblock 293 159 490 minecraft:light[level=14]
setblock 293 159 498 minecraft:light[level=14]
setblock 301 159 466 minecraft:light[level=14]
setblock 301 159 474 minecraft:light[level=14]
setblock 301 159 482 minecraft:light[level=14]
setblock 301 159 490 minecraft:light[level=14]
setblock 301 159 498 minecraft:light[level=14]
setblock 309 159 466 minecraft:light[level=14]
setblock 309 159 474 minecraft:light[level=14]
setblock 309 159 482 minecraft:light[level=14]
setblock 309 159 490 minecraft:light[level=14]
setblock 309 159 498 minecraft:light[level=14]
setblock 317 159 466 minecraft:light[level=14]
setblock 317 159 474 minecraft:light[level=14]
setblock 317 159 482 minecraft:light[level=14]
setblock 317 159 490 minecraft:light[level=14]
setblock 317 159 498 minecraft:light[level=14]
fill 300 162 486 302 162 488 minecraft:redstone_block
fill 303 162 477 305 162 479 minecraft:redstone_block
fill 308 162 483 310 162 485 minecraft:redstone_block
fill 293 163 475 298 164 476 minecraft:red_concrete
fill 293 163 490 298 164 491 minecraft:red_concrete
fill 294 163 477 302 163 479 minecraft:red_concrete
fill 294 163 487 299 163 489 minecraft:red_concrete
fill 295 163 480 313 163 480 minecraft:red_concrete
fill 295 163 486 299 163 486 minecraft:red_concrete
fill 296 163 481 315 163 481 minecraft:red_concrete
fill 296 163 485 307 163 485 minecraft:red_concrete
fill 297 163 482 302 163 482 minecraft:red_concrete
fill 297 163 484 302 163 484 minecraft:red_concrete
fill 298 163 483 302 163 483 minecraft:red_concrete
fill 299 163 476 300 164 476 minecraft:red_concrete
fill 299 163 490 300 164 490 minecraft:red_concrete
fill 300 163 489 309 163 489 minecraft:red_concrete
fill 303 163 475 309 163 476 minecraft:red_concrete
fill 303 163 486 309 163 488 minecraft:red_concrete
fill 303 163 490 309 163 491 minecraft:red_concrete
fill 304 163 473 309 163 474 minecraft:red_concrete
fill 304 163 492 309 163 493 minecraft:red_concrete
fill 305 163 472 309 164 472 minecraft:red_concrete
fill 305 163 494 309 164 494 minecraft:red_concrete
fill 306 163 471 309 164 471 minecraft:red_concrete
fill 306 163 477 309 163 479 minecraft:red_concrete
fill 306 163 482 307 163 484 minecraft:red_concrete
fill 306 163 495 309 164 495 minecraft:red_concrete
fill 308 163 470 308 164 470 minecraft:red_concrete
fill 308 163 482 317 163 482 minecraft:red_concrete
fill 308 163 496 308 164 496 minecraft:red_concrete
fill 310 163 486 313 163 486 minecraft:red_concrete
fill 311 163 483 315 163 485 minecraft:red_concrete
fill 316 163 483 317 164 484 minecraft:red_concrete
fill 318 163 483 318 164 483 minecraft:red_concrete
fill 283 164 464 292 164 504 minecraft:nether_bricks
fill 293 164 464 303 164 474 minecraft:nether_bricks
fill 293 164 477 293 164 489 minecraft:nether_bricks
fill 293 164 492 303 164 504 minecraft:nether_bricks
fill 294 164 477 296 164 479 minecraft:red_concrete
fill 294 164 480 294 164 486 minecraft:nether_bricks
fill 294 164 487 296 164 489 minecraft:red_concrete
fill 295 164 480 296 164 480 minecraft:red_concrete
fill 295 164 481 295 164 485 minecraft:nether_bricks
fill 295 164 486 296 164 486 minecraft:red_concrete
fill 296 164 481 297 164 481 minecraft:red_concrete
fill 296 164 482 296 164 484 minecraft:nether_bricks
fill 296 164 485 297 164 485 minecraft:red_concrete
fill 297 164 477 301 164 477 minecraft:red_concrete
fill 297 164 478 301 164 480 minecraft:gold_block
fill 297 164 482 298 164 482 minecraft:red_concrete
setblock 297 164 483 minecraft:nether_bricks
fill 297 164 484 298 164 484 minecraft:red_concrete
fill 297 164 486 298 164 488 minecraft:gold_block
fill 297 164 489 298 164 489 minecraft:red_concrete
fill 298 164 481 300 164 481 minecraft:gold_block
fill 298 164 483 299 164 483 minecraft:red_concrete
setblock 298 164 485 minecraft:gold_block
fill 299 164 475 302 164 475 minecraft:nether_bricks
fill 299 164 482 300 164 482 minecraft:gold_block
fill 299 164 484 300 164 484 minecraft:gold_block
fill 299 164 485 299 164 489 minecraft:shroomlight
fill 299 164 491 302 164 491 minecraft:nether_bricks
fill 300 164 483 301 164 483 minecraft:magma_block
fill 300 164 485 302 164 485 minecraft:shroomlight
fill 300 164 486 302 164 488 minecraft:nether_bricks
fill 300 164 489 303 164 489 minecraft:shroomlight
setblock 301 164 476 minecraft:nether_bricks
fill 301 164 481 301 164 482 minecraft:magma_block
setblock 301 164 484 minecraft:magma_block
fill 301 164 490 302 164 490 minecraft:nether_bricks
fill 302 164 476 302 164 481 minecraft:shroomlight
fill 302 164 482 302 164 484 minecraft:sea_lantern
fill 303 164 475 304 164 475 minecraft:red_concrete
fill 303 164 476 306 164 476 minecraft:shroomlight
fill 303 164 477 305 164 479 minecraft:nether_bricks
fill 303 164 480 306 164 480 minecraft:shroomlight
fill 303 164 481 305 164 481 minecraft:sea_lantern
fill 303 164 485 305 164 485 minecraft:sea_lantern
fill 303 164 486 303 164 488 minecraft:shroomlight
fill 303 164 490 303 164 491 minecraft:red_concrete
fill 304 164 464 304 164 472 minecraft:nether_bricks
fill 304 164 473 306 164 474 minecraft:red_concrete
fill 304 164 486 304 164 487 minecraft:magma_block
fill 304 164 488 307 164 490 minecraft:gold_block
fill 304 164 491 304 164 493 minecraft:red_concrete
fill 304 164 494 304 164 504 minecraft:nether_bricks
fill 305 164 464 305 164 471 minecraft:nether_bricks
fill 305 164 475 307 164 475 minecraft:gold_block
fill 305 164 486 306 164 486 minecraft:magma_block
fill 305 164 487 308 164 487 minecraft:gold_block
fill 305 164 491 307 164 491 minecraft:gold_block
fill 305 164 492 306 164 493 minecraft:red_concrete
fill 305 164 495 305 164 504 minecraft:nether_bricks
fill 306 164 464 307 164 470 minecraft:nether_bricks
fill 306 164 477 306 164 479 minecraft:shroomlight
setblock 306 164 481 minecraft:shroomlight
fill 306 164 482 306 164 484 minecraft:sea_lantern
fill 306 164 485 307 164 485 minecraft:shroomlight
fill 306 164 496 307 164 504 minecraft:nether_bricks
fill 307 164 473 309 164 473 minecraft:red_concrete
setblock 307 164 474 minecraft:gold_block
fill 307 164 476 307 164 480 minecraft:gold_block
setblock 307 164 481 minecraft:magma_block
fill 307 164 482 307 164 484 minecraft:shroomlight
fill 307 164 486 311 164 486 minecraft:shroomlight
setblock 307 164 492 minecraft:gold_block
fill 307 164 493 309 164 493 minecraft:red_concrete
fill 308 164 464 323 164 469 minecraft:nether_bricks
fill 308 164 474 309 164 476 minecraft:red_concrete
fill 308 164 477 308 164 479 minecraft:gold_block
fill 308 164 480 313 164 480 minecraft:red_concrete
fill 308 164 481 311 164 481 minecraft:gold_block
fill 308 164 482 311 164 482 minecraft:shroomlight
fill 308 164 483 310 164 485 minecraft:nether_bricks
fill 308 164 488 308 164 489 minecraft:gold_block
fill 308 164 490 309 164 492 minecraft:red_concrete
fill 308 164 497 323 164 504 minecraft:nether_bricks
fill 309 164 470 323 164 470 minecraft:nether_bricks
fill 309 164 477 309 164 479 minecraft:red_concrete
fill 309 164 487 309 164 489 minecraft:red_concrete
fill 309 164 496 323 164 496 minecraft:nether_bricks
fill 310 164 471 323 164 479 minecraft:nether_bricks
fill 310 164 487 323 164 495 minecraft:nether_bricks
fill 311 164 483 311 164 485 minecraft:shroomlight
fill 312 164 481 315 164 481 minecraft:red_concrete
fill 312 164 482 312 164 484 minecraft:gold_block
fill 312 164 485 313 164 486 minecraft:red_concrete
fill 313 164 482 317 164 482 minecraft:red_concrete
setblock 313 164 483 minecraft:gold_block
fill 313 164 484 315 164 484 minecraft:red_concrete
fill 314 164 480 323 164 480 minecraft:nether_bricks
fill 314 164 483 315 164 483 minecraft:red_concrete
fill 314 164 485 315 164 485 minecraft:red_concrete
fill 314 164 486 323 164 486 minecraft:nether_bricks
fill 316 164 481 323 164 481 minecraft:nether_bricks
fill 316 164 485 323 164 485 minecraft:nether_bricks
fill 318 164 482 323 164 482 minecraft:nether_bricks
fill 318 164 484 323 164 484 minecraft:nether_bricks
fill 319 164 483 323 164 483 minecraft:nether_bricks
fill 292 165 471 302 165 495 minecraft:prismarine_bricks
fill 303 165 471 316 165 481 minecraft:prismarine_bricks
fill 303 165 485 316 165 495 minecraft:prismarine_bricks
fill 306 165 482 316 165 484 minecraft:prismarine_bricks
fill 292 166 471 301 166 495 minecraft:prismarine_bricks
fill 302 166 471 302 166 482 minecraft:prismarine_bricks
fill 302 166 484 302 166 495 minecraft:prismarine_bricks
fill 303 166 471 303 166 481 minecraft:prismarine_bricks
fill 303 166 485 303 166 495 minecraft:prismarine_bricks
fill 304 166 471 316 166 480 minecraft:prismarine_bricks
fill 304 166 486 316 166 495 minecraft:prismarine_bricks
fill 305 166 481 316 166 481 minecraft:prismarine_bricks
fill 305 166 485 316 166 485 minecraft:prismarine_bricks
fill 306 166 482 316 166 482 minecraft:prismarine_bricks
fill 306 166 484 316 166 484 minecraft:prismarine_bricks
fill 307 166 483 316 166 483 minecraft:prismarine_bricks
setblock 285 167 466 minecraft:light[level=14]
setblock 285 167 474 minecraft:light[level=14]
setblock 285 167 482 minecraft:light[level=14]
setblock 285 167 490 minecraft:light[level=14]
setblock 285 167 498 minecraft:light[level=14]
setblock 293 167 466 minecraft:light[level=14]
fill 293 167 472 293 168 472 minecraft:sea_lantern
setblock 293 167 474 minecraft:light[level=14]
setblock 293 167 482 minecraft:light[level=14]
setblock 293 167 490 minecraft:light[level=14]
fill 293 167 494 293 168 494 minecraft:sea_lantern
setblock 293 167 498 minecraft:light[level=14]
fill 294 167 473 301 168 493 minecraft:dark_prismarine
setblock 301 167 466 minecraft:light[level=14]
setblock 301 167 498 minecraft:light[level=14]
fill 302 167 473 302 168 481 minecraft:dark_prismarine
fill 302 167 485 302 168 493 minecraft:dark_prismarine
fill 303 167 473 314 168 480 minecraft:dark_prismarine
fill 303 167 486 314 168 493 minecraft:dark_prismarine
fill 306 167 481 314 168 481 minecraft:dark_prismarine
fill 306 167 485 314 168 485 minecraft:dark_prismarine
fill 307 167 482 314 168 484 minecraft:dark_prismarine
setblock 309 167 466 minecraft:light[level=14]
setblock 309 167 498 minecraft:light[level=14]
fill 315 167 472 315 168 472 minecraft:sea_lantern
fill 315 167 494 315 168 494 minecraft:sea_lantern
setblock 317 167 466 minecraft:light[level=14]
setblock 317 167 474 minecraft:light[level=14]
setblock 317 167 482 minecraft:light[level=14]
setblock 317 167 490 minecraft:light[level=14]
setblock 317 167 498 minecraft:light[level=14]
fill 282 168 469 282 171 472 minecraft:shroomlight
fill 282 168 481 282 171 484 minecraft:shroomlight
fill 282 168 493 282 171 496 minecraft:shroomlight
fill 282 168 505 285 171 505 minecraft:shroomlight
fill 283 168 464 285 222 464 minecraft:polished_blackstone_bricks
fill 283 168 474 283 222 476 minecraft:polished_blackstone_bricks
fill 283 168 486 283 222 488 minecraft:polished_blackstone_bricks
fill 283 168 498 283 222 500 minecraft:polished_blackstone_bricks
fill 284 168 491 284 175 491 minecraft:gilded_blackstone
fill 289 168 463 292 171 463 minecraft:shroomlight
fill 289 168 495 295 168 504 minecraft:polished_blackstone_bricks
fill 294 168 505 297 171 505 minecraft:shroomlight
fill 295 168 464 297 222 464 minecraft:polished_blackstone_bricks
fill 301 168 463 304 171 463 minecraft:shroomlight
fill 301 168 504 303 222 504 minecraft:polished_blackstone_bricks
fill 306 168 505 309 171 505 minecraft:shroomlight
fill 307 168 464 309 222 464 minecraft:polished_blackstone_bricks
fill 313 168 463 316 171 463 minecraft:shroomlight
fill 313 168 504 315 222 504 minecraft:polished_blackstone_bricks
fill 318 168 505 321 171 505 minecraft:shroomlight
fill 319 168 464 321 222 464 minecraft:polished_blackstone_bricks
fill 323 168 472 323 222 474 minecraft:polished_blackstone_bricks
fill 323 168 484 323 222 486 minecraft:polished_blackstone_bricks
fill 323 168 496 323 222 498 minecraft:polished_blackstone_bricks
fill 324 168 464 324 171 467 minecraft:shroomlight
fill 324 168 476 324 171 479 minecraft:shroomlight
fill 324 168 488 324 171 491 minecraft:shroomlight
fill 324 168 500 324 171 503 minecraft:shroomlight
fill 289 169 495 289 187 495 minecraft:polished_blackstone_bricks
setblock 289 169 496 minecraft:shroomlight
fill 289 169 497 289 187 497 minecraft:polished_blackstone_bricks
setblock 289 169 498 minecraft:shroomlight
fill 289 169 499 289 187 499 minecraft:polished_blackstone_bricks
setblock 289 169 500 minecraft:shroomlight
fill 289 169 501 289 187 501 minecraft:polished_blackstone_bricks
setblock 289 169 502 minecraft:shroomlight
fill 289 169 503 289 187 503 minecraft:polished_blackstone_bricks
setblock 289 169 504 minecraft:shroomlight
setblock 290 169 495 minecraft:shroomlight
fill 290 169 496 290 187 496 minecraft:polished_blackstone_bricks
setblock 290 169 497 minecraft:shroomlight
fill 290 169 498 290 187 498 minecraft:polished_blackstone_bricks
setblock 290 169 499 minecraft:shroomlight
fill 290 169 500 290 187 500 minecraft:polished_blackstone_bricks
setblock 290 169 501 minecraft:shroomlight
fill 290 169 502 290 187 502 minecraft:polished_blackstone_bricks
setblock 290 169 503 minecraft:shroomlight
fill 290 169 504 290 222 504 minecraft:polished_blackstone_bricks
fill 291 169 495 291 187 495 minecraft:polished_blackstone_bricks
setblock 291 169 496 minecraft:shroomlight
fill 291 169 497 291 187 497 minecraft:polished_blackstone_bricks
setblock 291 169 498 minecraft:shroomlight
fill 291 169 499 291 187 499 minecraft:polished_blackstone_bricks
setblock 291 169 500 minecraft:shroomlight
fill 291 169 501 291 187 501 minecraft:polished_blackstone_bricks
setblock 291 169 502 minecraft:shroomlight
fill 291 169 503 291 187 503 minecraft:polished_blackstone_bricks
setblock 291 169 504 minecraft:shroomlight
setblock 292 169 495 minecraft:shroomlight
fill 292 169 496 292 187 496 minecraft:polished_blackstone_bricks
setblock 292 169 497 minecraft:shroomlight
fill 292 169 498 292 187 498 minecraft:polished_blackstone_bricks
setblock 292 169 499 minecraft:shroomlight
fill 292 169 500 292 187 500 minecraft:polished_blackstone_bricks
setblock 292 169 501 minecraft:shroomlight
fill 292 169 502 292 187 502 minecraft:polished_blackstone_bricks
setblock 292 169 503 minecraft:shroomlight
fill 292 169 504 292 187 504 minecraft:polished_blackstone_bricks
fill 293 169 495 293 187 495 minecraft:polished_blackstone_bricks
setblock 293 169 496 minecraft:shroomlight
fill 293 169 497 293 187 497 minecraft:polished_blackstone_bricks
setblock 293 169 498 minecraft:shroomlight
fill 293 169 499 293 187 499 minecraft:polished_blackstone_bricks
setblock 293 169 500 minecraft:shroomlight
fill 293 169 501 293 187 501 minecraft:polished_blackstone_bricks
setblock 293 169 502 minecraft:shroomlight
fill 293 169 503 293 187 503 minecraft:polished_blackstone_bricks
setblock 293 169 504 minecraft:shroomlight
setblock 294 169 495 minecraft:shroomlight
fill 294 169 496 294 187 496 minecraft:polished_blackstone_bricks
setblock 294 169 497 minecraft:shroomlight
fill 294 169 498 294 187 498 minecraft:polished_blackstone_bricks
setblock 294 169 499 minecraft:shroomlight
fill 294 169 500 294 187 500 minecraft:polished_blackstone_bricks
setblock 294 169 501 minecraft:shroomlight
fill 294 169 502 294 187 502 minecraft:polished_blackstone_bricks
setblock 294 169 503 minecraft:shroomlight
fill 294 169 504 294 184 504 minecraft:polished_blackstone_bricks
fill 295 169 495 295 187 495 minecraft:polished_blackstone_bricks
setblock 295 169 496 minecraft:shroomlight
fill 295 169 497 295 187 497 minecraft:polished_blackstone_bricks
setblock 295 169 498 minecraft:shroomlight
fill 295 169 499 295 187 499 minecraft:polished_blackstone_bricks
setblock 295 169 500 minecraft:shroomlight
fill 295 169 501 295 187 501 minecraft:polished_blackstone_bricks
setblock 295 169 502 minecraft:shroomlight
fill 295 169 503 295 187 503 minecraft:polished_blackstone_bricks
setblock 295 169 504 minecraft:shroomlight
fill 296 169 475 301 170 491 minecraft:prismarine_bricks
fill 302 169 475 302 170 481 minecraft:prismarine_bricks
fill 302 169 485 302 170 491 minecraft:prismarine_bricks
fill 303 169 475 312 170 480 minecraft:prismarine_bricks
fill 303 169 486 312 170 491 minecraft:prismarine_bricks
fill 306 169 481 312 170 481 minecraft:prismarine_bricks
fill 306 169 485 312 170 485 minecraft:prismarine_bricks
fill 307 169 482 312 170 484 minecraft:prismarine_bricks
fill 289 170 496 289 171 496 minecraft:polished_blackstone_bricks
fill 289 170 498 289 171 498 minecraft:polished_blackstone_bricks
fill 289 170 500 289 171 500 minecraft:polished_blackstone_bricks
fill 289 170 502 289 171 502 minecraft:polished_blackstone_bricks
fill 289 170 504 289 171 504 minecraft:polished_blackstone_bricks
fill 290 170 495 290 171 495 minecraft:polished_blackstone_bricks
fill 290 170 497 290 171 497 minecraft:polished_blackstone_bricks
fill 290 170 499 290 171 499 minecraft:polished_blackstone_bricks
fill 290 170 501 290 171 501 minecraft:polished_blackstone_bricks
fill 290 170 503 290 171 503 minecraft:polished_blackstone_bricks
fill 291 170 496 291 171 496 minecraft:polished_blackstone_bricks
fill 291 170 498 291 171 498 minecraft:polished_blackstone_bricks
fill 291 170 500 291 171 500 minecraft:polished_blackstone_bricks
fill 291 170 502 291 171 502 minecraft:polished_blackstone_bricks
fill 291 170 504 291 171 504 minecraft:polished_blackstone_bricks
fill 292 170 495 292 171 495 minecraft:polished_blackstone_bricks
fill 292 170 497 292 171 497 minecraft:polished_blackstone_bricks
fill 292 170 499 292 171 499 minecraft:polished_blackstone_bricks
fill 292 170 501 292 171 501 minecraft:polished_blackstone_bricks
fill 292 170 503 292 171 503 minecraft:polished_blackstone_bricks
fill 293 170 496 293 171 496 minecraft:polished_blackstone_bricks
fill 293 170 498 293 171 498 minecraft:polished_blackstone_bricks
fill 293 170 500 293 171 500 minecraft:polished_blackstone_bricks
fill 293 170 502 293 171 502 minecraft:polished_blackstone_bricks
fill 293 170 504 293 171 504 minecraft:polished_blackstone_bricks
fill 294 170 495 294 171 495 minecraft:polished_blackstone_bricks
fill 294 170 497 294 171 497 minecraft:polished_blackstone_bricks
fill 294 170 499 294 171 499 minecraft:polished_blackstone_bricks
fill 294 170 501 294 171 501 minecraft:polished_blackstone_bricks
fill 294 170 503 294 171 503 minecraft:polished_blackstone_bricks
fill 295 170 496 295 171 496 minecraft:polished_blackstone_bricks
fill 295 170 498 295 171 498 minecraft:polished_blackstone_bricks
fill 295 170 500 295 171 500 minecraft:polished_blackstone_bricks
fill 295 170 502 295 171 502 minecraft:polished_blackstone_bricks
fill 295 170 504 295 171 504 minecraft:polished_blackstone_bricks
fill 321 170 483 321 184 483 minecraft:red_wool
fill 298 171 477 301 171 489 minecraft:dark_prismarine
fill 302 171 477 310 171 480 minecraft:dark_prismarine
fill 302 171 486 310 171 489 minecraft:dark_prismarine
fill 307 171 481 310 171 485 minecraft:dark_prismarine
fill 321 171 481 321 184 482 minecraft:red_wool
fill 321 171 484 321 184 485 minecraft:red_wool
fill 282 172 469 282 185 469 minecraft:nether_bricks
fill 282 172 470 282 172 471 minecraft:shroomlight
fill 282 172 472 282 185 472 minecraft:nether_bricks
fill 282 172 481 282 185 481 minecraft:nether_bricks
fill 282 172 482 282 172 483 minecraft:shroomlight
fill 282 172 484 282 185 484 minecraft:nether_bricks
fill 282 172 493 282 185 493 minecraft:nether_bricks
fill 282 172 494 282 172 495 minecraft:shroomlight
fill 282 172 496 282 185 496 minecraft:nether_bricks
fill 282 172 505 282 185 505 minecraft:nether_bricks
fill 283 172 505 284 172 505 minecraft:shroomlight
fill 285 172 505 285 185 505 minecraft:nether_bricks
fill 289 172 463 289 185 463 minecraft:nether_bricks
setblock 289 172 496 minecraft:shroomlight
setblock 289 172 498 minecraft:shroomlight
setblock 289 172 500 minecraft:shroomlight
setblock 289 172 502 minecraft:shroomlight
setblock 289 172 504 minecraft:shroomlight
fill 290 172 463 291 172 463 minecraft:shroomlight
setblock 290 172 495 minecraft:shroomlight
setblock 290 172 497 minecraft:shroomlight
setblock 290 172 499 minecraft:shroomlight
setblock 290 172 501 minecraft:shroomlight
setblock 290 172 503 minecraft:shroomlight
setblock 291 172 496 minecraft:shroomlight
setblock 291 172 498 minecraft:shroomlight
setblock 291 172 500 minecraft:shroomlight
setblock 291 172 502 minecraft:shroomlight
setblock 291 172 504 minecraft:shroomlight
fill 292 172 463 292 185 463 minecraft:nether_bricks
setblock 292 172 495 minecraft:shroomlight
setblock 292 172 497 minecraft:shroomlight
setblock 292 172 499 minecraft:shroomlight
setblock 292 172 501 minecraft:shroomlight
setblock 292 172 503 minecraft:shroomlight
setblock 293 172 496 minecraft:shroomlight
setblock 293 172 498 minecraft:shroomlight
setblock 293 172 500 minecraft:shroomlight
setblock 293 172 502 minecraft:shroomlight
setblock 293 172 504 minecraft:shroomlight
setblock 294 172 495 minecraft:shroomlight
setblock 294 172 497 minecraft:shroomlight
setblock 294 172 499 minecraft:shroomlight
setblock 294 172 501 minecraft:shroomlight
setblock 294 172 503 minecraft:shroomlight
fill 294 172 505 294 185 505 minecraft:nether_bricks
setblock 295 172 496 minecraft:shroomlight
setblock 295 172 498 minecraft:shroomlight
setblock 295 172 500 minecraft:shroomlight
setblock 295 172 502 minecraft:shroomlight
fill 295 172 504 295 172 505 minecraft:shroomlight
setblock 296 172 505 minecraft:shroomlight
fill 297 172 505 297 185 505 minecraft:nether_bricks
fill 298 172 477 300 172 489 minecraft:dark_prismarine
fill 301 172 463 301 185 463 minecraft:nether_bricks
fill 301 172 477 301 172 482 minecraft:dark_prismarine
fill 301 172 484 301 172 489 minecraft:dark_prismarine
fill 302 172 463 303 172 463 minecraft:shroomlight
fill 302 172 477 303 172 480 minecraft:dark_prismarine
fill 302 172 486 303 172 489 minecraft:dark_prismarine
fill 304 172 463 304 185 463 minecraft:nether_bricks
fill 304 172 477 310 172 479 minecraft:dark_prismarine
fill 304 172 487 310 172 489 minecraft:dark_prismarine
fill 305 172 480 310 172 480 minecraft:dark_prismarine
fill 305 172 486 310 172 486 minecraft:dark_prismarine
fill 306 172 505 306 185 505 minecraft:nether_bricks
fill 307 172 481 310 172 482 minecraft:dark_prismarine
fill 307 172 484 310 172 485 minecraft:dark_prismarine
fill 307 172 505 308 172 505 minecraft:shroomlight
fill 308 172 483 310 172 483 minecraft:dark_prismarine
fill 309 172 505 309 185 505 minecraft:nether_bricks
fill 313 172 463 313 185 463 minecraft:nether_bricks
fill 314 172 463 315 172 463 minecraft:shroomlight
fill 316 172 463 316 185 463 minecraft:nether_bricks
fill 318 172 505 318 185 505 minecraft:nether_bricks
fill 319 172 505 320 172 505 minecraft:shroomlight
fill 321 172 505 321 185 505 minecraft:nether_bricks
fill 324 172 464 324 185 464 minecraft:nether_bricks
fill 324 172 465 324 172 466 minecraft:shroomlight
fill 324 172 467 324 185 467 minecraft:nether_bricks
fill 324 172 476 324 185 476 minecraft:nether_bricks
fill 324 172 477 324 172 478 minecraft:shroomlight
fill 324 172 479 324 185 479 minecraft:nether_bricks
fill 324 172 488 324 185 488 minecraft:nether_bricks
fill 324 172 489 324 172 490 minecraft:shroomlight
fill 324 172 491 324 185 491 minecraft:nether_bricks
fill 324 172 500 324 185 500 minecraft:nether_bricks
fill 324 172 501 324 172 502 minecraft:shroomlight
fill 324 172 503 324 185 503 minecraft:nether_bricks
fill 282 173 470 282 185 471 minecraft:nether_bricks
fill 282 173 482 282 185 483 minecraft:nether_bricks
fill 282 173 494 282 185 495 minecraft:nether_bricks
fill 283 173 505 284 185 505 minecraft:nether_bricks
fill 289 173 496 289 174 496 minecraft:polished_blackstone_bricks
fill 289 173 498 289 174 498 minecraft:polished_blackstone_bricks
fill 289 173 500 289 174 500 minecraft:polished_blackstone_bricks
fill 289 173 502 289 174 502 minecraft:polished_blackstone_bricks
fill 289 173 504 289 174 504 minecraft:polished_blackstone_bricks
fill 290 173 463 291 185 463 minecraft:nether_bricks
fill 290 173 495 290 174 495 minecraft:polished_blackstone_bricks
fill 290 173 497 290 174 497 minecraft:polished_blackstone_bricks
fill 290 173 499 290 174 499 minecraft:polished_blackstone_bricks
fill 290 173 501 290 174 501 minecraft:polished_blackstone_bricks
fill 290 173 503 290 174 503 minecraft:polished_blackstone_bricks
fill 291 173 496 291 174 496 minecraft:polished_blackstone_bricks
fill 291 173 498 291 174 498 minecraft:polished_blackstone_bricks
fill 291 173 500 291 174 500 minecraft:polished_blackstone_bricks
fill 291 173 502 291 174 502 minecraft:polished_blackstone_bricks
fill 291 173 504 291 174 504 minecraft:polished_blackstone_bricks
fill 292 173 495 292 174 495 minecraft:polished_blackstone_bricks
fill 292 173 497 292 174 497 minecraft:polished_blackstone_bricks
fill 292 173 499 292 174 499 minecraft:polished_blackstone_bricks
fill 292 173 501 292 174 501 minecraft:polished_blackstone_bricks
fill 292 173 503 292 174 503 minecraft:polished_blackstone_bricks
fill 293 173 496 293 174 496 minecraft:polished_blackstone_bricks
fill 293 173 498 293 174 498 minecraft:polished_blackstone_bricks
fill 293 173 500 293 174 500 minecraft:polished_blackstone_bricks
fill 293 173 502 293 174 502 minecraft:polished_blackstone_bricks
fill 293 173 504 293 174 504 minecraft:polished_blackstone_bricks
fill 294 173 495 294 174 495 minecraft:polished_blackstone_bricks
fill 294 173 497 294 174 497 minecraft:polished_blackstone_bricks
fill 294 173 499 294 174 499 minecraft:polished_blackstone_bricks
fill 294 173 501 294 174 501 minecraft:polished_blackstone_bricks
fill 294 173 503 294 174 503 minecraft:polished_blackstone_bricks
fill 295 173 496 295 174 496 minecraft:polished_blackstone_bricks
fill 295 173 498 295 174 498 minecraft:polished_blackstone_bricks
fill 295 173 500 295 174 500 minecraft:polished_blackstone_bricks
fill 295 173 502 295 174 502 minecraft:polished_blackstone_bricks
fill 295 173 504 295 174 504 minecraft:polished_blackstone_bricks
fill 295 173 505 296 185 505 minecraft:nether_bricks
fill 300 173 479 300 174 487 minecraft:prismarine_bricks
fill 301 173 479 301 174 481 minecraft:prismarine_bricks
fill 301 173 485 301 174 487 minecraft:prismarine_bricks
fill 302 173 463 303 185 463 minecraft:nether_bricks
fill 302 173 479 302 174 480 minecraft:prismarine_bricks
fill 302 173 486 302 174 487 minecraft:prismarine_bricks
fill 303 173 479 308 174 479 minecraft:prismarine_bricks
fill 303 173 487 308 174 487 minecraft:prismarine_bricks
fill 306 173 480 308 174 480 minecraft:prismarine_bricks
fill 306 173 486 308 174 486 minecraft:prismarine_bricks
fill 307 173 481 308 174 481 minecraft:prismarine_bricks
fill 307 173 485 308 174 485 minecraft:prismarine_bricks
fill 307 173 505 308 185 505 minecraft:nether_bricks
fill 308 173 482 308 174 484 minecraft:prismarine_bricks
fill 314 173 463 315 185 463 minecraft:nether_bricks
fill 319 173 505 320 185 505 minecraft:nether_bricks
fill 324 173 465 324 185 466 minecraft:nether_bricks
fill 324 173 477 324 185 478 minecraft:nether_bricks
fill 324 173 489 324 185 490 minecraft:nether_bricks
fill 324 173 501 324 185 502 minecraft:nether_bricks
fill 321 174 492 321 183 492 minecraft:red_wool
setblock 285 175 466 minecraft:light[level=14]
setblock 285 175 474 minecraft:light[level=14]
setblock 285 175 482 minecraft:light[level=14]
setblock 285 175 490 minecraft:light[level=14]
setblock 285 175 498 minecraft:light[level=14]
setblock 289 175 496 minecraft:shroomlight
setblock 289 175 498 minecraft:shroomlight
setblock 289 175 500 minecraft:shroomlight
setblock 289 175 502 minecraft:shroomlight
setblock 289 175 504 minecraft:shroomlight
setblock 290 175 495 minecraft:shroomlight
setblock 290 175 497 minecraft:shroomlight
setblock 290 175 499 minecraft:shroomlight
setblock 290 175 501 minecraft:shroomlight
setblock 290 175 503 minecraft:shroomlight
setblock 291 175 496 minecraft:shroomlight
setblock 291 175 498 minecraft:shroomlight
setblock 291 175 500 minecraft:shroomlight
setblock 291 175 502 minecraft:shroomlight
setblock 291 175 504 minecraft:shroomlight
setblock 292 175 495 minecraft:shroomlight
setblock 292 175 497 minecraft:shroomlight
setblock 292 175 499 minecraft:shroomlight
setblock 292 175 501 minecraft:shroomlight
setblock 292 175 503 minecraft:shroomlight
setblock 293 175 466 minecraft:light[level=14]
setblock 293 175 474 minecraft:light[level=14]
setblock 293 175 482 minecraft:light[level=14]
setblock 293 175 490 minecraft:light[level=14]
setblock 293 175 496 minecraft:shroomlight
setblock 293 175 498 minecraft:shroomlight
setblock 293 175 500 minecraft:shroomlight
setblock 293 175 502 minecraft:shroomlight
setblock 293 175 504 minecraft:shroomlight
setblock 294 175 495 minecraft:shroomlight
setblock 294 175 497 minecraft:shroomlight
setblock 294 175 499 minecraft:shroomlight
setblock 294 175 501 minecraft:shroomlight
setblock 294 175 503 minecraft:shroomlight
setblock 295 175 496 minecraft:shroomlight
setblock 295 175 498 minecraft:shroomlight
setblock 295 175 500 minecraft:shroomlight
setblock 295 175 502 minecraft:shroomlight
setblock 295 175 504 minecraft:shroomlight
setblock 301 175 466 minecraft:light[level=14]
setblock 301 175 474 minecraft:light[level=14]
setblock 301 175 490 minecraft:light[level=14]
setblock 301 175 498 minecraft:light[level=14]
setblock 309 175 466 minecraft:light[level=14]
setblock 309 175 474 minecraft:light[level=14]
setblock 309 175 482 minecraft:light[level=14]
setblock 309 175 490 minecraft:light[level=14]
setblock 309 175 498 minecraft:light[level=14]
setblock 317 175 466 minecraft:light[level=14]
setblock 317 175 474 minecraft:light[level=14]
setblock 317 175 482 minecraft:light[level=14]
setblock 317 175 490 minecraft:light[level=14]
setblock 317 175 498 minecraft:light[level=14]
fill 321 175 490 321 183 491 minecraft:red_wool
fill 321 175 493 321 183 494 minecraft:red_wool
fill 289 176 496 289 177 496 minecraft:polished_blackstone_bricks
fill 289 176 498 289 177 498 minecraft:polished_blackstone_bricks
fill 289 176 500 289 177 500 minecraft:polished_blackstone_bricks
fill 289 176 502 289 177 502 minecraft:polished_blackstone_bricks
fill 289 176 504 289 177 504 minecraft:polished_blackstone_bricks
fill 290 176 495 290 177 495 minecraft:polished_blackstone_bricks
fill 290 176 497 290 177 497 minecraft:polished_blackstone_bricks
fill 290 176 499 290 177 499 minecraft:polished_blackstone_bricks
fill 290 176 501 290 177 501 minecraft:polished_blackstone_bricks
fill 290 176 503 290 177 503 minecraft:polished_blackstone_bricks
fill 291 176 496 291 177 496 minecraft:polished_blackstone_bricks
fill 291 176 498 291 177 498 minecraft:polished_blackstone_bricks
fill 291 176 500 291 177 500 minecraft:polished_blackstone_bricks
fill 291 176 502 291 177 502 minecraft:polished_blackstone_bricks
fill 291 176 504 291 177 504 minecraft:polished_blackstone_bricks
fill 292 176 495 292 177 495 minecraft:polished_blackstone_bricks
fill 292 176 497 292 177 497 minecraft:polished_blackstone_bricks
fill 292 176 499 292 177 499 minecraft:polished_blackstone_bricks
fill 292 176 501 292 177 501 minecraft:polished_blackstone_bricks
fill 292 176 503 292 177 503 minecraft:polished_blackstone_bricks
fill 293 176 496 293 177 496 minecraft:polished_blackstone_bricks
fill 293 176 498 293 177 498 minecraft:polished_blackstone_bricks
fill 293 176 500 293 177 500 minecraft:polished_blackstone_bricks
fill 293 176 502 293 177 502 minecraft:polished_blackstone_bricks
fill 293 176 504 293 177 504 minecraft:polished_blackstone_bricks
fill 294 176 495 294 177 495 minecraft:polished_blackstone_bricks
fill 294 176 497 294 177 497 minecraft:polished_blackstone_bricks
fill 294 176 499 294 177 499 minecraft:polished_blackstone_bricks
fill 294 176 501 294 177 501 minecraft:polished_blackstone_bricks
fill 294 176 503 294 177 503 minecraft:polished_blackstone_bricks
fill 295 176 496 295 177 496 minecraft:polished_blackstone_bricks
fill 295 176 498 295 177 498 minecraft:polished_blackstone_bricks
fill 295 176 500 295 177 500 minecraft:polished_blackstone_bricks
fill 295 176 502 295 177 502 minecraft:polished_blackstone_bricks
fill 295 176 504 295 177 504 minecraft:polished_blackstone_bricks
setblock 289 178 496 minecraft:shroomlight
setblock 289 178 498 minecraft:shroomlight
setblock 289 178 500 minecraft:shroomlight
setblock 289 178 502 minecraft:shroomlight
setblock 289 178 504 minecraft:shroomlight
setblock 290 178 495 minecraft:shroomlight
setblock 290 178 497 minecraft:shroomlight
setblock 290 178 499 minecraft:shroomlight
setblock 290 178 501 minecraft:shroomlight
setblock 290 178 503 minecraft:shroomlight
setblock 291 178 496 minecraft:shroomlight
setblock 291 178 498 minecraft:shroomlight
setblock 291 178 500 minecraft:shroomlight
setblock 291 178 502 minecraft:shroomlight
setblock 291 178 504 minecraft:shroomlight
setblock 292 178 495 minecraft:shroomlight
setblock 292 178 497 minecraft:shroomlight
setblock 292 178 499 minecraft:shroomlight
setblock 292 178 501 minecraft:shroomlight
setblock 292 178 503 minecraft:shroomlight
setblock 293 178 496 minecraft:shroomlight
setblock 293 178 498 minecraft:shroomlight
setblock 293 178 500 minecraft:shroomlight
setblock 293 178 502 minecraft:shroomlight
setblock 293 178 504 minecraft:shroomlight
setblock 294 178 495 minecraft:shroomlight
setblock 294 178 497 minecraft:shroomlight
setblock 294 178 499 minecraft:shroomlight
setblock 294 178 501 minecraft:shroomlight
setblock 294 178 503 minecraft:shroomlight
setblock 295 178 496 minecraft:shroomlight
setblock 295 178 498 minecraft:shroomlight
setblock 295 178 500 minecraft:shroomlight
setblock 295 178 502 minecraft:shroomlight
setblock 295 178 504 minecraft:shroomlight
fill 289 179 496 289 180 496 minecraft:polished_blackstone_bricks
fill 289 179 498 289 180 498 minecraft:polished_blackstone_bricks
fill 289 179 500 289 180 500 minecraft:polished_blackstone_bricks
fill 289 179 502 289 180 502 minecraft:polished_blackstone_bricks
fill 289 179 504 289 180 504 minecraft:polished_blackstone_bricks
fill 290 179 495 290 180 495 minecraft:polished_blackstone_bricks
fill 290 179 497 290 180 497 minecraft:polished_blackstone_bricks
fill 290 179 499 290 180 499 minecraft:polished_blackstone_bricks
fill 290 179 501 290 180 501 minecraft:polished_blackstone_bricks
fill 290 179 503 290 180 503 minecraft:polished_blackstone_bricks
fill 291 179 496 291 180 496 minecraft:polished_blackstone_bricks
fill 291 179 498 291 180 498 minecraft:polished_blackstone_bricks
fill 291 179 500 291 180 500 minecraft:polished_blackstone_bricks
fill 291 179 502 291 180 502 minecraft:polished_blackstone_bricks
fill 291 179 504 291 180 504 minecraft:polished_blackstone_bricks
fill 292 179 495 292 180 495 minecraft:polished_blackstone_bricks
fill 292 179 497 292 180 497 minecraft:polished_blackstone_bricks
fill 292 179 499 292 180 499 minecraft:polished_blackstone_bricks
fill 292 179 501 292 180 501 minecraft:polished_blackstone_bricks
fill 292 179 503 292 180 503 minecraft:polished_blackstone_bricks
fill 293 179 496 293 180 496 minecraft:polished_blackstone_bricks
fill 293 179 498 293 180 498 minecraft:polished_blackstone_bricks
fill 293 179 500 293 180 500 minecraft:polished_blackstone_bricks
fill 293 179 502 293 180 502 minecraft:polished_blackstone_bricks
fill 293 179 504 293 180 504 minecraft:polished_blackstone_bricks
fill 294 179 495 294 180 495 minecraft:polished_blackstone_bricks
fill 294 179 497 294 180 497 minecraft:polished_blackstone_bricks
fill 294 179 499 294 180 499 minecraft:polished_blackstone_bricks
fill 294 179 501 294 180 501 minecraft:polished_blackstone_bricks
fill 294 179 503 294 180 503 minecraft:polished_blackstone_bricks
fill 295 179 496 295 180 496 minecraft:polished_blackstone_bricks
fill 295 179 498 295 180 498 minecraft:polished_blackstone_bricks
fill 295 179 500 295 180 500 minecraft:polished_blackstone_bricks
fill 295 179 502 295 180 502 minecraft:polished_blackstone_bricks
fill 295 179 504 295 180 504 minecraft:polished_blackstone_bricks
fill 284 180 473 284 185 475 minecraft:polished_blackstone_bricks
fill 284 180 485 284 185 487 minecraft:polished_blackstone_bricks
fill 284 180 497 284 185 499 minecraft:polished_blackstone_bricks
fill 294 180 465 296 185 465 minecraft:polished_blackstone_bricks
fill 302 180 503 304 185 503 minecraft:polished_blackstone_bricks
fill 306 180 465 308 185 465 minecraft:polished_blackstone_bricks
fill 314 180 503 316 185 503 minecraft:polished_blackstone_bricks
fill 318 180 465 320 185 465 minecraft:polished_blackstone_bricks
fill 322 180 473 322 185 475 minecraft:polished_blackstone_bricks
fill 322 180 485 322 185 487 minecraft:polished_blackstone_bricks
fill 322 180 497 322 185 499 minecraft:polished_blackstone_bricks
setblock 289 181 496 minecraft:shroomlight
setblock 289 181 498 minecraft:shroomlight
setblock 289 181 500 minecraft:shroomlight
setblock 289 181 502 minecraft:shroomlight
setblock 289 181 504 minecraft:shroomlight
setblock 290 181 495 minecraft:shroomlight
setblock 290 181 497 minecraft:shroomlight
setblock 290 181 499 minecraft:shroomlight
setblock 290 181 501 minecraft:shroomlight
setblock 290 181 503 minecraft:shroomlight
setblock 291 181 496 minecraft:shroomlight
setblock 291 181 498 minecraft:shroomlight
setblock 291 181 500 minecraft:shroomlight
setblock 291 181 502 minecraft:shroomlight
schedule function dropper:buildpart/114_2 1t
