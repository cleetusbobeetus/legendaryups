fill 336 279 337 336 279 338 minecraft:gold_block
fill 336 279 339 358 279 339 minecraft:smooth_quartz
setblock 336 279 340 minecraft:black_concrete
fill 336 279 341 343 279 342 minecraft:smooth_quartz
fill 336 279 344 336 279 345 minecraft:smooth_quartz
setblock 336 279 346 minecraft:black_concrete
fill 336 279 347 350 279 347 minecraft:smooth_quartz
fill 336 279 348 336 279 349 minecraft:gold_block
fill 336 279 350 336 279 363 minecraft:bricks
fill 337 279 323 337 279 334 minecraft:bricks
fill 337 279 335 337 279 336 minecraft:gold_block
fill 337 279 337 357 279 338 minecraft:smooth_quartz
fill 337 279 340 344 279 340 minecraft:smooth_quartz
fill 337 279 344 339 279 344 minecraft:smooth_quartz
fill 337 279 345 339 279 345 minecraft:black_concrete
fill 337 279 346 344 279 346 minecraft:smooth_quartz
fill 337 279 348 351 279 349 minecraft:smooth_quartz
fill 337 279 350 337 279 351 minecraft:gold_block
fill 337 279 352 337 279 363 minecraft:bricks
fill 338 279 323 338 279 333 minecraft:bricks
fill 338 279 334 338 279 335 minecraft:gold_block
fill 338 279 336 356 279 336 minecraft:smooth_quartz
fill 338 279 350 353 279 350 minecraft:smooth_quartz
fill 338 279 351 338 279 352 minecraft:gold_block
fill 338 279 353 338 279 363 minecraft:bricks
fill 339 279 323 340 279 332 minecraft:bricks
fill 339 279 333 339 279 334 minecraft:gold_block
setblock 339 279 335 minecraft:black_concrete
setblock 339 279 351 minecraft:black_concrete
fill 339 279 352 339 279 353 minecraft:gold_block
fill 339 279 354 340 279 363 minecraft:bricks
setblock 340 279 333 minecraft:gold_block
fill 340 279 334 354 279 335 minecraft:smooth_quartz
fill 340 279 344 343 279 344 minecraft:black_concrete
fill 340 279 345 343 279 345 minecraft:smooth_quartz
fill 340 279 351 354 279 352 minecraft:smooth_quartz
setblock 340 279 353 minecraft:gold_block
fill 341 279 323 341 279 331 minecraft:bricks
fill 341 279 332 342 279 332 minecraft:gold_block
fill 341 279 333 353 279 333 minecraft:smooth_quartz
fill 341 279 353 353 279 353 minecraft:smooth_quartz
fill 341 279 354 342 279 354 minecraft:gold_block
fill 341 279 355 341 279 363 minecraft:bricks
fill 342 279 323 346 279 330 minecraft:bricks
setblock 342 279 331 minecraft:smooth_quartz
setblock 342 279 355 minecraft:smooth_quartz
fill 342 279 356 346 279 363 minecraft:bricks
fill 343 279 331 346 279 331 minecraft:gold_block
setblock 343 279 332 minecraft:smooth_quartz
setblock 343 279 354 minecraft:smooth_quartz
fill 343 279 355 346 279 355 minecraft:gold_block
setblock 344 279 332 minecraft:black_concrete
fill 344 279 341 344 279 345 minecraft:gold_block
setblock 344 279 354 minecraft:black_concrete
fill 345 279 332 349 279 332 minecraft:smooth_quartz
fill 345 279 340 345 279 341 minecraft:gold_block
fill 345 279 345 345 279 346 minecraft:gold_block
fill 345 279 354 349 279 354 minecraft:smooth_quartz
fill 346 279 340 349 279 340 minecraft:gold_block
fill 346 279 346 349 279 346 minecraft:gold_block
fill 347 279 323 370 279 329 minecraft:bricks
fill 347 279 330 347 279 331 minecraft:smooth_quartz
fill 347 279 355 347 279 356 minecraft:smooth_quartz
fill 347 279 357 370 279 363 minecraft:bricks
fill 348 279 330 370 279 330 minecraft:bricks
fill 348 279 331 351 279 331 minecraft:gold_block
fill 348 279 355 351 279 355 minecraft:gold_block
fill 348 279 356 370 279 356 minecraft:bricks
fill 349 279 341 350 279 341 minecraft:gold_block
fill 349 279 345 350 279 345 minecraft:gold_block
setblock 350 279 332 minecraft:black_concrete
fill 350 279 340 357 279 340 minecraft:smooth_quartz
fill 350 279 342 350 279 344 minecraft:gold_block
setblock 350 279 346 minecraft:black_concrete
setblock 350 279 354 minecraft:black_concrete
setblock 351 279 332 minecraft:smooth_quartz
fill 351 279 341 357 279 346 minecraft:smooth_quartz
setblock 351 279 347 minecraft:black_concrete
setblock 351 279 354 minecraft:smooth_quartz
setblock 352 279 331 minecraft:smooth_quartz
fill 352 279 332 353 279 332 minecraft:gold_block
fill 352 279 347 358 279 347 minecraft:smooth_quartz
setblock 352 279 348 minecraft:black_concrete
setblock 352 279 349 minecraft:smooth_quartz
fill 352 279 354 353 279 354 minecraft:gold_block
setblock 352 279 355 minecraft:smooth_quartz
fill 353 279 331 370 279 331 minecraft:bricks
fill 353 279 348 357 279 348 minecraft:smooth_quartz
setblock 353 279 349 minecraft:black_concrete
fill 353 279 355 370 279 355 minecraft:bricks
fill 354 279 332 370 279 332 minecraft:bricks
fill 354 279 333 355 279 333 minecraft:gold_block
fill 354 279 349 357 279 349 minecraft:smooth_quartz
setblock 354 279 350 minecraft:black_concrete
fill 354 279 353 355 279 353 minecraft:gold_block
fill 354 279 354 370 279 354 minecraft:bricks
fill 355 279 334 356 279 334 minecraft:gold_block
setblock 355 279 335 minecraft:black_concrete
fill 355 279 350 356 279 350 minecraft:smooth_quartz
setblock 355 279 351 minecraft:black_concrete
fill 355 279 352 356 279 352 minecraft:gold_block
fill 356 279 333 370 279 333 minecraft:bricks
fill 356 279 335 357 279 335 minecraft:gold_block
fill 356 279 351 357 279 351 minecraft:gold_block
fill 356 279 353 370 279 353 minecraft:bricks
fill 357 279 334 370 279 334 minecraft:bricks
setblock 357 279 336 minecraft:gold_block
setblock 357 279 350 minecraft:gold_block
fill 357 279 352 370 279 352 minecraft:bricks
fill 358 279 335 370 279 336 minecraft:bricks
fill 358 279 337 358 279 338 minecraft:gold_block
setblock 358 279 340 minecraft:black_concrete
fill 358 279 341 358 279 345 minecraft:smooth_quartz
setblock 358 279 346 minecraft:black_concrete
fill 358 279 348 358 279 349 minecraft:gold_block
fill 358 279 350 370 279 351 minecraft:bricks
fill 359 279 337 370 279 337 minecraft:bricks
setblock 359 279 338 minecraft:smooth_quartz
fill 359 279 339 359 279 342 minecraft:gold_block
fill 359 279 343 360 279 343 minecraft:smooth_quartz
fill 359 279 344 359 279 347 minecraft:gold_block
setblock 359 279 348 minecraft:smooth_quartz
fill 359 279 349 370 279 349 minecraft:bricks
fill 360 279 338 370 279 342 minecraft:bricks
fill 360 279 344 370 279 348 minecraft:bricks
fill 361 279 343 370 279 343 minecraft:bricks
setblock 330 280 336 minecraft:waxed_copper_block
fill 330 280 340 330 282 340 minecraft:waxed_copper_block
setblock 332 280 325 minecraft:light[level=12]
setblock 332 280 332 minecraft:light[level=12]
setblock 332 280 339 minecraft:light[level=12]
setblock 332 280 346 minecraft:light[level=12]
setblock 332 280 353 minecraft:light[level=12]
setblock 332 280 360 minecraft:light[level=12]
setblock 339 280 325 minecraft:light[level=12]
setblock 339 280 332 minecraft:light[level=12]
setblock 339 280 339 minecraft:light[level=12]
setblock 339 280 346 minecraft:light[level=12]
setblock 339 280 353 minecraft:light[level=12]
setblock 339 280 360 minecraft:light[level=12]
setblock 346 280 325 minecraft:light[level=12]
setblock 346 280 332 minecraft:light[level=12]
setblock 346 280 339 minecraft:light[level=12]
setblock 346 280 346 minecraft:light[level=12]
setblock 346 280 353 minecraft:light[level=12]
setblock 346 280 360 minecraft:light[level=12]
setblock 353 280 325 minecraft:light[level=12]
setblock 353 280 332 minecraft:light[level=12]
setblock 353 280 339 minecraft:light[level=12]
setblock 353 280 346 minecraft:light[level=12]
setblock 353 280 353 minecraft:light[level=12]
setblock 353 280 360 minecraft:light[level=12]
setblock 360 280 325 minecraft:light[level=12]
setblock 360 280 332 minecraft:light[level=12]
setblock 360 280 339 minecraft:light[level=12]
setblock 360 280 346 minecraft:light[level=12]
setblock 360 280 353 minecraft:light[level=12]
setblock 360 280 360 minecraft:light[level=12]
setblock 367 280 325 minecraft:light[level=12]
setblock 367 280 332 minecraft:light[level=12]
setblock 367 280 339 minecraft:light[level=12]
setblock 367 280 346 minecraft:light[level=12]
setblock 367 280 353 minecraft:light[level=12]
setblock 367 280 360 minecraft:light[level=12]
setblock 330 281 343 minecraft:waxed_copper_block
fill 330 283 323 332 300 323 minecraft:polished_andesite
fill 330 283 333 330 300 335 minecraft:polished_andesite
fill 330 283 345 330 300 347 minecraft:polished_andesite
fill 330 283 357 330 300 359 minecraft:polished_andesite
fill 331 283 332 331 285 334 minecraft:polished_andesite
fill 331 283 344 331 285 346 minecraft:polished_andesite
fill 331 283 356 331 285 358 minecraft:polished_andesite
fill 332 283 329 332 287 329 minecraft:iron_block
fill 336 283 363 338 300 363 minecraft:polished_andesite
fill 337 283 362 339 286 362 minecraft:polished_andesite
fill 341 283 324 343 285 324 minecraft:polished_andesite
fill 342 283 323 344 300 323 minecraft:polished_andesite
fill 348 283 363 350 300 363 minecraft:polished_andesite
fill 349 283 362 351 286 362 minecraft:polished_andesite
fill 353 283 324 355 285 324 minecraft:polished_andesite
fill 354 283 323 356 300 323 minecraft:polished_andesite
fill 359 283 359 359 294 359 minecraft:iron_block
fill 360 283 363 362 300 363 minecraft:polished_andesite
fill 361 283 362 363 286 362 minecraft:polished_andesite
fill 365 283 324 367 285 324 minecraft:polished_andesite
fill 366 283 323 368 300 323 minecraft:polished_andesite
fill 369 283 332 369 285 334 minecraft:polished_andesite
fill 369 283 344 369 285 346 minecraft:polished_andesite
fill 369 283 356 369 285 358 minecraft:polished_andesite
fill 370 283 331 370 300 333 minecraft:polished_andesite
fill 370 283 343 370 300 345 minecraft:polished_andesite
fill 370 283 355 370 300 357 minecraft:polished_andesite
setblock 332 284 325 minecraft:light[level=15]
setblock 332 284 333 minecraft:light[level=15]
setblock 332 284 341 minecraft:light[level=15]
setblock 332 284 349 minecraft:light[level=15]
setblock 332 284 357 minecraft:light[level=15]
setblock 340 284 325 minecraft:light[level=15]
setblock 340 284 333 minecraft:light[level=15]
setblock 340 284 341 minecraft:light[level=15]
setblock 340 284 349 minecraft:light[level=15]
setblock 340 284 357 minecraft:light[level=15]
setblock 348 284 325 minecraft:light[level=15]
setblock 348 284 333 minecraft:light[level=15]
setblock 348 284 341 minecraft:light[level=15]
setblock 348 284 349 minecraft:light[level=15]
setblock 348 284 357 minecraft:light[level=15]
fill 355 284 332 368 284 332 minecraft:polished_andesite
setblock 356 284 325 minecraft:light[level=15]
setblock 356 284 333 minecraft:light[level=15]
setblock 356 284 341 minecraft:light[level=15]
setblock 356 284 349 minecraft:light[level=15]
setblock 356 284 357 minecraft:light[level=15]
fill 359 284 338 370 284 338 minecraft:polished_andesite
setblock 364 284 325 minecraft:light[level=15]
setblock 364 284 333 minecraft:light[level=15]
setblock 364 284 341 minecraft:light[level=15]
setblock 364 284 349 minecraft:light[level=15]
setblock 364 284 357 minecraft:light[level=15]
fill 330 285 326 330 285 331 minecraft:stone_bricks
fill 330 285 332 330 286 332 minecraft:polished_andesite
fill 330 285 338 330 285 343 minecraft:stone_bricks
fill 330 285 344 330 286 344 minecraft:polished_andesite
fill 330 285 350 330 285 355 minecraft:stone_bricks
fill 330 285 356 330 286 356 minecraft:polished_andesite
fill 330 285 362 330 285 363 minecraft:stone_bricks
fill 331 285 326 332 286 326 minecraft:polished_andesite
fill 331 285 338 365 285 338 minecraft:polished_andesite
fill 331 285 350 333 286 350 minecraft:polished_andesite
fill 331 285 362 336 286 362 minecraft:polished_andesite
fill 331 285 363 334 285 363 minecraft:stone_bricks
fill 332 285 332 359 285 332 minecraft:polished_andesite
fill 332 285 344 333 286 344 minecraft:polished_andesite
fill 332 285 356 342 286 356 minecraft:polished_andesite
fill 334 285 323 339 285 323 minecraft:stone_bricks
fill 341 285 363 346 285 363 minecraft:stone_bricks
fill 346 285 323 351 285 323 minecraft:stone_bricks
fill 353 285 363 358 285 363 minecraft:stone_bricks
fill 358 285 323 363 285 323 minecraft:stone_bricks
fill 365 285 363 370 285 363 minecraft:stone_bricks
fill 370 285 323 370 285 328 minecraft:stone_bricks
fill 370 285 335 370 285 340 minecraft:stone_bricks
fill 370 285 347 370 285 352 minecraft:stone_bricks
fill 370 285 359 370 285 362 minecraft:stone_bricks
fill 329 286 328 329 291 331 minecraft:ochre_froglight
fill 329 286 340 329 291 343 minecraft:ochre_froglight
fill 329 286 352 329 291 355 minecraft:ochre_froglight
fill 329 286 364 332 291 364 minecraft:ochre_froglight
setblock 330 286 326 minecraft:polished_andesite
fill 330 286 338 332 286 338 minecraft:polished_andesite
setblock 330 286 350 minecraft:polished_andesite
setblock 330 286 362 minecraft:polished_andesite
fill 331 286 332 332 286 332 minecraft:polished_andesite
setblock 331 286 344 minecraft:polished_andesite
setblock 331 286 356 minecraft:polished_andesite
setblock 332 286 325 minecraft:light[level=12]
setblock 332 286 339 minecraft:light[level=12]
setblock 332 286 346 minecraft:light[level=12]
setblock 332 286 353 minecraft:light[level=12]
setblock 332 286 360 minecraft:light[level=12]
fill 333 286 326 364 286 326 minecraft:polished_andesite
fill 334 286 344 343 286 344 minecraft:polished_andesite
fill 334 286 350 368 286 350 minecraft:polished_andesite
fill 336 286 322 339 291 322 minecraft:ochre_froglight
setblock 339 286 325 minecraft:light[level=12]
setblock 339 286 332 minecraft:light[level=12]
setblock 339 286 339 minecraft:light[level=12]
setblock 339 286 346 minecraft:light[level=12]
setblock 339 286 353 minecraft:light[level=12]
setblock 339 286 360 minecraft:light[level=12]
fill 340 286 362 348 286 362 minecraft:polished_andesite
fill 341 286 364 344 291 364 minecraft:ochre_froglight
fill 343 286 356 369 286 356 minecraft:polished_andesite
setblock 346 286 325 minecraft:light[level=12]
setblock 346 286 332 minecraft:light[level=12]
setblock 346 286 339 minecraft:light[level=12]
setblock 346 286 346 minecraft:light[level=12]
setblock 346 286 353 minecraft:light[level=12]
setblock 346 286 360 minecraft:light[level=12]
fill 348 286 322 351 291 322 minecraft:ochre_froglight
fill 351 286 344 369 286 344 minecraft:polished_andesite
fill 352 286 362 360 286 362 minecraft:polished_andesite
setblock 353 286 325 minecraft:light[level=12]
setblock 353 286 332 minecraft:light[level=12]
setblock 353 286 339 minecraft:light[level=12]
setblock 353 286 346 minecraft:light[level=12]
setblock 353 286 353 minecraft:light[level=12]
setblock 353 286 360 minecraft:light[level=12]
fill 353 286 364 356 291 364 minecraft:ochre_froglight
fill 360 286 322 363 291 322 minecraft:ochre_froglight
setblock 360 286 325 minecraft:light[level=12]
setblock 360 286 332 minecraft:light[level=12]
setblock 360 286 339 minecraft:light[level=12]
setblock 360 286 346 minecraft:light[level=12]
setblock 360 286 353 minecraft:light[level=12]
setblock 360 286 360 minecraft:light[level=12]
fill 364 286 362 370 286 362 minecraft:polished_andesite
fill 365 286 364 368 291 364 minecraft:ochre_froglight
setblock 367 286 325 minecraft:light[level=12]
setblock 367 286 332 minecraft:light[level=12]
setblock 367 286 339 minecraft:light[level=12]
setblock 367 286 346 minecraft:light[level=12]
setblock 367 286 353 minecraft:light[level=12]
setblock 367 286 360 minecraft:light[level=12]
fill 371 286 323 371 291 326 minecraft:ochre_froglight
fill 371 286 335 371 291 338 minecraft:ochre_froglight
fill 371 286 347 371 291 350 minecraft:ochre_froglight
fill 371 286 359 371 291 362 minecraft:ochre_froglight
fill 333 287 323 333 288 328 minecraft:iron_block
fill 339 287 323 339 287 363 minecraft:iron_block
fill 345 287 323 345 288 329 minecraft:iron_block
fill 351 287 323 351 287 363 minecraft:iron_block
fill 357 287 323 357 288 326 minecraft:iron_block
fill 358 287 326 370 287 326 minecraft:polished_andesite
fill 362 287 350 369 287 350 minecraft:polished_andesite
fill 363 287 323 363 288 325 minecraft:iron_block
fill 363 287 327 363 288 349 minecraft:iron_block
fill 363 287 351 363 288 362 minecraft:iron_block
fill 366 287 344 369 287 344 minecraft:polished_andesite
fill 369 287 323 369 288 325 minecraft:iron_block
fill 369 287 327 369 288 329 minecraft:iron_block
fill 333 288 329 333 288 363 minecraft:iron_block
fill 339 288 323 339 288 328 minecraft:iron_block
fill 345 288 330 345 288 340 minecraft:iron_block
fill 345 288 346 345 288 363 minecraft:iron_block
fill 351 288 323 351 288 330 minecraft:iron_block
fill 357 288 327 357 288 361 minecraft:iron_block
setblock 363 288 326 minecraft:iron_block
setblock 363 288 350 minecraft:iron_block
setblock 369 288 326 minecraft:iron_block
fill 369 288 330 369 288 363 minecraft:iron_block
fill 357 289 355 357 289 362 minecraft:iron_block
fill 329 292 328 329 308 328 minecraft:bricks
fill 329 292 329 329 292 330 minecraft:ochre_froglight
fill 329 292 331 329 308 331 minecraft:bricks
fill 329 292 340 329 308 340 minecraft:bricks
fill 329 292 341 329 292 342 minecraft:ochre_froglight
fill 329 292 343 329 308 343 minecraft:bricks
fill 329 292 352 329 308 352 minecraft:bricks
fill 329 292 353 329 292 354 minecraft:ochre_froglight
fill 329 292 355 329 308 355 minecraft:bricks
fill 329 292 364 329 308 364 minecraft:bricks
fill 330 292 364 331 292 364 minecraft:ochre_froglight
setblock 332 292 325 minecraft:light[level=15]
setblock 332 292 332 minecraft:light[level=12]
setblock 332 292 333 minecraft:light[level=15]
setblock 332 292 339 minecraft:light[level=12]
setblock 332 292 341 minecraft:light[level=15]
setblock 332 292 346 minecraft:light[level=12]
setblock 332 292 349 minecraft:light[level=15]
setblock 332 292 353 minecraft:light[level=12]
setblock 332 292 357 minecraft:light[level=15]
setblock 332 292 360 minecraft:light[level=12]
fill 332 292 364 332 308 364 minecraft:bricks
fill 336 292 322 336 308 322 minecraft:bricks
fill 337 292 322 338 292 322 minecraft:ochre_froglight
fill 339 292 322 339 308 322 minecraft:bricks
setblock 339 292 325 minecraft:light[level=12]
setblock 339 292 332 minecraft:light[level=12]
setblock 339 292 339 minecraft:light[level=12]
setblock 339 292 346 minecraft:light[level=12]
setblock 339 292 353 minecraft:light[level=12]
setblock 339 292 360 minecraft:light[level=12]
setblock 340 292 325 minecraft:light[level=15]
setblock 340 292 333 minecraft:light[level=15]
setblock 340 292 341 minecraft:light[level=15]
setblock 340 292 349 minecraft:light[level=15]
setblock 340 292 357 minecraft:light[level=15]
fill 341 292 364 341 308 364 minecraft:bricks
fill 342 292 364 343 292 364 minecraft:ochre_froglight
fill 344 292 364 344 308 364 minecraft:bricks
setblock 346 292 325 minecraft:light[level=12]
setblock 346 292 332 minecraft:light[level=12]
setblock 346 292 339 minecraft:light[level=12]
setblock 346 292 346 minecraft:light[level=12]
setblock 346 292 353 minecraft:light[level=12]
setblock 346 292 360 minecraft:light[level=12]
fill 348 292 322 348 308 322 minecraft:bricks
setblock 348 292 325 minecraft:light[level=15]
setblock 348 292 333 minecraft:light[level=15]
setblock 348 292 341 minecraft:light[level=15]
setblock 348 292 349 minecraft:light[level=15]
setblock 348 292 357 minecraft:light[level=15]
fill 349 292 322 350 292 322 minecraft:ochre_froglight
fill 351 292 322 351 308 322 minecraft:bricks
setblock 353 292 325 minecraft:light[level=12]
setblock 353 292 332 minecraft:light[level=12]
setblock 353 292 339 minecraft:light[level=12]
setblock 353 292 346 minecraft:light[level=12]
setblock 353 292 353 minecraft:light[level=12]
setblock 353 292 360 minecraft:light[level=12]
fill 353 292 364 353 308 364 minecraft:bricks
fill 354 292 364 355 292 364 minecraft:ochre_froglight
setblock 356 292 325 minecraft:light[level=15]
setblock 356 292 333 minecraft:light[level=15]
setblock 356 292 341 minecraft:light[level=15]
setblock 356 292 349 minecraft:light[level=15]
setblock 356 292 357 minecraft:light[level=15]
fill 356 292 364 356 308 364 minecraft:bricks
fill 360 292 322 360 308 322 minecraft:bricks
setblock 360 292 325 minecraft:light[level=12]
setblock 360 292 332 minecraft:light[level=12]
setblock 360 292 339 minecraft:light[level=12]
setblock 360 292 346 minecraft:light[level=12]
setblock 360 292 353 minecraft:light[level=12]
setblock 360 292 360 minecraft:light[level=12]
fill 361 292 322 362 292 322 minecraft:ochre_froglight
fill 363 292 322 363 308 322 minecraft:bricks
setblock 364 292 325 minecraft:light[level=15]
setblock 364 292 333 minecraft:light[level=15]
setblock 364 292 341 minecraft:light[level=15]
setblock 364 292 349 minecraft:light[level=15]
setblock 364 292 357 minecraft:light[level=15]
fill 365 292 364 365 308 364 minecraft:bricks
fill 366 292 364 367 292 364 minecraft:ochre_froglight
setblock 367 292 325 minecraft:light[level=12]
setblock 367 292 332 minecraft:light[level=12]
setblock 367 292 339 minecraft:light[level=12]
setblock 367 292 346 minecraft:light[level=12]
setblock 367 292 353 minecraft:light[level=12]
setblock 367 292 360 minecraft:light[level=12]
fill 368 292 364 368 308 364 minecraft:bricks
fill 371 292 323 371 308 323 minecraft:bricks
fill 371 292 324 371 292 325 minecraft:ochre_froglight
fill 371 292 326 371 308 326 minecraft:bricks
fill 371 292 335 371 308 335 minecraft:bricks
fill 371 292 336 371 292 337 minecraft:ochre_froglight
fill 371 292 338 371 308 338 minecraft:bricks
fill 371 292 347 371 308 347 minecraft:bricks
fill 371 292 348 371 292 349 minecraft:ochre_froglight
fill 371 292 350 371 308 350 minecraft:bricks
fill 371 292 359 371 308 359 minecraft:bricks
fill 371 292 360 371 292 361 minecraft:ochre_froglight
fill 371 292 362 371 308 362 minecraft:bricks
fill 329 293 329 329 308 330 minecraft:bricks
fill 329 293 341 329 308 342 minecraft:bricks
fill 329 293 353 329 308 354 minecraft:bricks
fill 330 293 364 331 308 364 minecraft:bricks
fill 337 293 322 338 308 322 minecraft:bricks
fill 342 293 364 343 308 364 minecraft:bricks
fill 349 293 322 350 308 322 minecraft:bricks
fill 354 293 364 355 308 364 minecraft:bricks
fill 361 293 322 362 308 322 minecraft:bricks
fill 366 293 364 367 308 364 minecraft:bricks
fill 371 293 324 371 308 325 minecraft:bricks
fill 371 293 336 371 308 337 minecraft:bricks
fill 371 293 348 371 308 349 minecraft:bricks
fill 371 293 360 371 308 361 minecraft:bricks
setblock 332 298 325 minecraft:light[level=12]
setblock 332 298 332 minecraft:light[level=12]
setblock 332 298 339 minecraft:light[level=12]
setblock 332 298 346 minecraft:light[level=12]
setblock 332 298 353 minecraft:light[level=12]
setblock 332 298 360 minecraft:light[level=12]
setblock 339 298 325 minecraft:light[level=12]
setblock 339 298 332 minecraft:light[level=12]
setblock 339 298 339 minecraft:light[level=12]
setblock 339 298 346 minecraft:light[level=12]
setblock 339 298 353 minecraft:light[level=12]
setblock 339 298 360 minecraft:light[level=12]
setblock 346 298 325 minecraft:light[level=12]
setblock 346 298 332 minecraft:light[level=12]
setblock 346 298 339 minecraft:light[level=12]
setblock 346 298 346 minecraft:light[level=12]
setblock 346 298 353 minecraft:light[level=12]
setblock 346 298 360 minecraft:light[level=12]
setblock 353 298 325 minecraft:light[level=12]
setblock 353 298 332 minecraft:light[level=12]
setblock 353 298 339 minecraft:light[level=12]
setblock 353 298 346 minecraft:light[level=12]
setblock 353 298 353 minecraft:light[level=12]
setblock 353 298 360 minecraft:light[level=12]
setblock 360 298 325 minecraft:light[level=12]
setblock 360 298 332 minecraft:light[level=12]
setblock 360 298 339 minecraft:light[level=12]
setblock 360 298 346 minecraft:light[level=12]
setblock 360 298 353 minecraft:light[level=12]
setblock 360 298 360 minecraft:light[level=12]
setblock 367 298 325 minecraft:light[level=12]
setblock 367 298 332 minecraft:light[level=12]
setblock 367 298 339 minecraft:light[level=12]
setblock 367 298 346 minecraft:light[level=12]
setblock 367 298 353 minecraft:light[level=12]
setblock 367 298 360 minecraft:light[level=12]
fill 331 300 332 331 300 334 minecraft:polished_andesite
fill 331 300 344 331 300 346 minecraft:polished_andesite
fill 331 300 356 331 300 358 minecraft:polished_andesite
setblock 332 300 325 minecraft:light[level=15]
setblock 332 300 333 minecraft:light[level=15]
setblock 332 300 341 minecraft:light[level=15]
setblock 332 300 349 minecraft:light[level=15]
setblock 332 300 357 minecraft:light[level=15]
fill 337 300 362 339 300 362 minecraft:polished_andesite
setblock 340 300 325 minecraft:light[level=15]
setblock 340 300 333 minecraft:light[level=15]
setblock 340 300 341 minecraft:light[level=15]
setblock 340 300 349 minecraft:light[level=15]
setblock 340 300 357 minecraft:light[level=15]
fill 341 300 324 343 300 324 minecraft:polished_andesite
setblock 348 300 325 minecraft:light[level=15]
setblock 348 300 333 minecraft:light[level=15]
setblock 348 300 341 minecraft:light[level=15]
setblock 348 300 349 minecraft:light[level=15]
setblock 348 300 357 minecraft:light[level=15]
fill 349 300 362 351 300 362 minecraft:polished_andesite
fill 353 300 324 355 300 324 minecraft:polished_andesite
setblock 356 300 325 minecraft:light[level=15]
setblock 356 300 333 minecraft:light[level=15]
setblock 356 300 341 minecraft:light[level=15]
setblock 356 300 349 minecraft:light[level=15]
setblock 356 300 357 minecraft:light[level=15]
fill 361 300 362 363 300 362 minecraft:polished_andesite
setblock 364 300 325 minecraft:light[level=15]
setblock 364 300 333 minecraft:light[level=15]
setblock 364 300 341 minecraft:light[level=15]
setblock 364 300 349 minecraft:light[level=15]
setblock 364 300 357 minecraft:light[level=15]
fill 365 300 324 367 300 324 minecraft:polished_andesite
fill 369 300 332 369 300 334 minecraft:polished_andesite
fill 369 300 344 369 300 346 minecraft:polished_andesite
fill 369 300 356 369 300 358 minecraft:polished_andesite
