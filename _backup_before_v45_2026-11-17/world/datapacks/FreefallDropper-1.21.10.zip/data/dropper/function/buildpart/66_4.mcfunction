fill 282 249 275 282 250 276 minecraft:yellow_concrete
fill 282 249 277 282 250 278 minecraft:black_concrete
fill 282 249 279 282 250 280 minecraft:yellow_concrete
fill 282 249 281 282 250 282 minecraft:black_concrete
fill 282 249 283 282 250 284 minecraft:yellow_concrete
fill 282 249 285 282 250 286 minecraft:black_concrete
fill 282 249 287 282 250 288 minecraft:yellow_concrete
fill 282 249 289 282 250 290 minecraft:black_concrete
fill 282 249 291 282 250 292 minecraft:yellow_concrete
fill 282 249 293 282 250 294 minecraft:black_concrete
fill 282 249 295 282 250 296 minecraft:yellow_concrete
fill 282 249 297 282 250 298 minecraft:black_concrete
fill 282 249 299 282 250 300 minecraft:yellow_concrete
fill 282 249 301 282 250 302 minecraft:black_concrete
fill 282 249 303 282 250 304 minecraft:yellow_concrete
fill 282 249 305 282 250 306 minecraft:black_concrete
fill 282 249 307 282 250 308 minecraft:yellow_concrete
fill 282 249 309 282 250 310 minecraft:black_concrete
fill 282 249 311 282 250 312 minecraft:yellow_concrete
fill 282 249 313 282 250 314 minecraft:black_concrete
fill 282 249 315 282 250 316 minecraft:yellow_concrete
fill 282 249 317 282 250 317 minecraft:black_concrete
fill 283 249 275 283 250 275 minecraft:yellow_concrete
fill 283 249 317 283 250 317 minecraft:yellow_concrete
fill 284 249 275 285 250 275 minecraft:black_concrete
fill 284 249 294 284 249 296 minecraft:iron_block
fill 284 249 312 284 249 314 minecraft:iron_block
fill 284 249 317 285 250 317 minecraft:black_concrete
fill 285 249 293 287 249 293 minecraft:iron_block
fill 285 249 297 287 249 297 minecraft:iron_block
fill 285 249 311 287 249 311 minecraft:iron_block
fill 285 249 315 287 249 315 minecraft:iron_block
fill 286 249 275 287 250 275 minecraft:yellow_concrete
fill 286 249 317 287 250 317 minecraft:yellow_concrete
fill 288 249 275 289 250 275 minecraft:black_concrete
fill 288 249 294 288 249 296 minecraft:iron_block
fill 288 249 312 288 249 314 minecraft:iron_block
fill 288 249 317 289 250 317 minecraft:black_concrete
fill 290 249 275 291 250 275 minecraft:yellow_concrete
fill 290 249 317 291 250 317 minecraft:yellow_concrete
fill 292 249 275 293 250 275 minecraft:black_concrete
fill 292 249 317 293 250 317 minecraft:black_concrete
fill 294 249 275 295 250 275 minecraft:yellow_concrete
fill 294 249 317 295 250 317 minecraft:yellow_concrete
fill 296 249 275 297 250 275 minecraft:black_concrete
fill 296 249 317 297 250 317 minecraft:black_concrete
fill 298 249 275 299 250 275 minecraft:yellow_concrete
fill 298 249 317 299 250 317 minecraft:yellow_concrete
fill 300 249 275 301 250 275 minecraft:black_concrete
fill 300 249 317 301 250 317 minecraft:black_concrete
fill 302 249 275 303 250 275 minecraft:yellow_concrete
fill 302 249 317 303 250 317 minecraft:yellow_concrete
fill 304 249 275 305 250 275 minecraft:black_concrete
fill 304 249 317 305 250 317 minecraft:black_concrete
fill 306 249 275 307 250 275 minecraft:yellow_concrete
fill 306 249 317 307 250 317 minecraft:yellow_concrete
fill 308 249 275 309 250 275 minecraft:black_concrete
fill 308 249 317 309 250 317 minecraft:black_concrete
fill 310 249 275 311 250 275 minecraft:yellow_concrete
fill 310 249 317 311 250 317 minecraft:yellow_concrete
fill 312 249 275 313 250 275 minecraft:black_concrete
fill 312 249 317 313 250 317 minecraft:black_concrete
fill 314 249 275 315 250 275 minecraft:yellow_concrete
fill 314 249 317 315 250 317 minecraft:yellow_concrete
fill 316 249 275 317 250 275 minecraft:black_concrete
fill 316 249 317 317 250 317 minecraft:black_concrete
fill 318 249 275 319 250 275 minecraft:yellow_concrete
fill 318 249 317 319 250 317 minecraft:yellow_concrete
setblock 319 249 294 minecraft:iron_block
setblock 319 249 296 minecraft:iron_block
fill 320 249 275 321 250 275 minecraft:black_concrete
fill 320 249 317 321 250 317 minecraft:black_concrete
setblock 321 249 294 minecraft:iron_block
setblock 321 249 296 minecraft:iron_block
fill 322 249 275 323 250 275 minecraft:yellow_concrete
fill 322 249 317 323 250 317 minecraft:yellow_concrete
fill 324 249 275 324 250 275 minecraft:black_concrete
fill 324 249 276 324 250 276 minecraft:yellow_concrete
fill 324 249 277 324 250 278 minecraft:black_concrete
fill 324 249 279 324 250 280 minecraft:yellow_concrete
fill 324 249 281 324 250 282 minecraft:black_concrete
fill 324 249 283 324 250 284 minecraft:yellow_concrete
fill 324 249 285 324 250 286 minecraft:black_concrete
fill 324 249 287 324 250 288 minecraft:yellow_concrete
fill 324 249 289 324 250 290 minecraft:black_concrete
fill 324 249 291 324 250 292 minecraft:yellow_concrete
fill 324 249 293 324 250 294 minecraft:black_concrete
fill 324 249 295 324 250 296 minecraft:yellow_concrete
fill 324 249 297 324 250 298 minecraft:black_concrete
fill 324 249 299 324 250 300 minecraft:yellow_concrete
fill 324 249 301 324 250 302 minecraft:black_concrete
fill 324 249 303 324 250 304 minecraft:yellow_concrete
fill 324 249 305 324 250 306 minecraft:black_concrete
fill 324 249 307 324 250 308 minecraft:yellow_concrete
fill 324 249 309 324 250 310 minecraft:black_concrete
fill 324 249 311 324 250 312 minecraft:yellow_concrete
fill 324 249 313 324 250 314 minecraft:black_concrete
fill 324 249 315 324 250 316 minecraft:yellow_concrete
fill 324 249 317 324 250 317 minecraft:black_concrete
fill 282 251 275 282 251 317 minecraft:light_gray_concrete
fill 283 251 275 324 255 275 minecraft:light_gray_concrete
fill 283 251 317 324 255 317 minecraft:light_gray_concrete
fill 303 251 277 303 251 279 minecraft:iron_block
fill 304 251 277 305 251 277 minecraft:iron_block
fill 304 251 279 305 251 279 minecraft:iron_block
setblock 305 251 278 minecraft:iron_block
fill 324 251 276 324 252 316 minecraft:light_gray_concrete
fill 282 252 275 282 255 281 minecraft:light_gray_concrete
setblock 282 252 282 minecraft:sea_lantern
fill 282 252 283 282 255 317 minecraft:light_gray_concrete
setblock 283 252 278 minecraft:iron_block
fill 283 252 280 283 252 283 minecraft:iron_block
setblock 283 252 288 minecraft:iron_block
fill 283 252 290 283 252 293 minecraft:iron_block
setblock 283 252 298 minecraft:iron_block
fill 283 252 300 283 252 303 minecraft:iron_block
setblock 283 252 308 minecraft:iron_block
fill 283 252 310 283 252 313 minecraft:iron_block
fill 284 252 276 287 252 276 minecraft:iron_block
setblock 285 252 278 minecraft:light[level=12]
setblock 285 252 285 minecraft:light[level=12]
setblock 285 252 292 minecraft:light[level=12]
setblock 285 252 299 minecraft:light[level=12]
setblock 285 252 306 minecraft:light[level=12]
fill 285 252 316 285 254 316 minecraft:iron_block
fill 287 252 316 290 252 316 minecraft:iron_block
setblock 289 252 276 minecraft:iron_block
setblock 292 252 278 minecraft:light[level=12]
setblock 292 252 285 minecraft:light[level=12]
setblock 292 252 292 minecraft:light[level=12]
setblock 292 252 299 minecraft:light[level=12]
setblock 292 252 306 minecraft:light[level=12]
setblock 292 252 313 minecraft:light[level=12]
fill 294 252 276 297 252 276 minecraft:iron_block
setblock 295 252 316 minecraft:iron_block
fill 297 252 316 300 252 316 minecraft:iron_block
setblock 299 252 276 minecraft:iron_block
setblock 299 252 278 minecraft:light[level=12]
setblock 299 252 285 minecraft:light[level=12]
setblock 299 252 292 minecraft:light[level=12]
setblock 299 252 299 minecraft:light[level=12]
setblock 299 252 306 minecraft:light[level=12]
setblock 299 252 313 minecraft:light[level=12]
fill 304 252 276 307 252 276 minecraft:iron_block
setblock 305 252 316 minecraft:iron_block
setblock 306 252 278 minecraft:light[level=12]
setblock 306 252 285 minecraft:light[level=12]
setblock 306 252 292 minecraft:light[level=12]
setblock 306 252 299 minecraft:light[level=12]
setblock 306 252 306 minecraft:light[level=12]
setblock 306 252 313 minecraft:light[level=12]
fill 307 252 316 310 252 316 minecraft:iron_block
setblock 309 252 276 minecraft:iron_block
setblock 313 252 278 minecraft:light[level=12]
setblock 313 252 285 minecraft:light[level=12]
setblock 313 252 292 minecraft:light[level=12]
setblock 313 252 299 minecraft:light[level=12]
setblock 313 252 306 minecraft:light[level=12]
setblock 313 252 313 minecraft:light[level=12]
fill 314 252 276 317 252 276 minecraft:iron_block
setblock 315 252 316 minecraft:iron_block
fill 317 252 316 320 252 316 minecraft:iron_block
setblock 319 252 276 minecraft:iron_block
setblock 320 252 278 minecraft:light[level=12]
setblock 320 252 285 minecraft:light[level=12]
setblock 320 252 292 minecraft:light[level=12]
setblock 320 252 299 minecraft:light[level=12]
setblock 320 252 306 minecraft:light[level=12]
setblock 320 252 313 minecraft:light[level=12]
fill 323 252 277 323 252 280 minecraft:iron_block
setblock 323 252 282 minecraft:iron_block
fill 323 252 287 323 252 290 minecraft:iron_block
setblock 323 252 292 minecraft:iron_block
fill 323 252 297 323 252 300 minecraft:iron_block
setblock 323 252 302 minecraft:iron_block
fill 323 252 307 323 252 310 minecraft:iron_block
setblock 323 252 312 minecraft:iron_block
fill 282 253 282 282 255 282 minecraft:light_gray_concrete
fill 285 253 315 287 254 315 minecraft:iron_block
fill 286 253 316 287 254 316 minecraft:iron_block
fill 324 253 276 324 254 300 minecraft:light_gray_concrete
setblock 324 253 301 minecraft:redstone_block
fill 324 253 302 324 255 316 minecraft:light_gray_concrete
setblock 286 254 311 minecraft:pearlescent_froglight
fill 324 254 301 324 276 301 minecraft:light_gray_concrete
fill 324 255 276 324 255 294 minecraft:light_gray_concrete
setblock 324 255 295 minecraft:sea_lantern
fill 324 255 296 324 255 300 minecraft:light_gray_concrete
fill 282 256 275 282 276 280 minecraft:light_gray_concrete
fill 282 256 281 282 256 284 minecraft:pearlescent_froglight
fill 282 256 285 282 276 290 minecraft:light_gray_concrete
fill 282 256 291 282 256 294 minecraft:pearlescent_froglight
fill 282 256 295 282 267 300 minecraft:light_gray_concrete
fill 282 256 301 282 256 304 minecraft:pearlescent_froglight
fill 282 256 305 282 268 310 minecraft:light_gray_concrete
fill 282 256 311 282 256 314 minecraft:pearlescent_froglight
fill 282 256 315 282 276 317 minecraft:light_gray_concrete
fill 283 256 275 284 276 275 minecraft:light_gray_concrete
fill 283 256 317 285 276 317 minecraft:light_gray_concrete
fill 284 256 294 284 256 296 minecraft:iron_block
fill 284 256 312 284 256 314 minecraft:iron_block
fill 285 256 275 288 256 275 minecraft:pearlescent_froglight
setblock 285 256 278 minecraft:light[level=15]
setblock 285 256 286 minecraft:light[level=15]
fill 285 256 293 287 256 293 minecraft:iron_block
fill 285 256 297 287 256 297 minecraft:iron_block
setblock 285 256 302 minecraft:light[level=15]
setblock 285 256 310 minecraft:light[level=15]
fill 285 256 311 287 256 311 minecraft:iron_block
fill 285 256 315 287 256 315 minecraft:iron_block
fill 286 256 317 289 256 317 minecraft:pearlescent_froglight
fill 288 256 294 288 256 296 minecraft:iron_block
fill 288 256 312 288 256 314 minecraft:iron_block
fill 289 256 275 294 271 275 minecraft:light_gray_concrete
fill 290 256 317 295 266 317 minecraft:light_gray_concrete
setblock 293 256 278 minecraft:light[level=15]
setblock 293 256 286 minecraft:light[level=15]
setblock 293 256 294 minecraft:light[level=15]
setblock 293 256 302 minecraft:light[level=15]
setblock 293 256 310 minecraft:light[level=15]
fill 295 256 275 298 256 275 minecraft:pearlescent_froglight
fill 296 256 317 299 256 317 minecraft:pearlescent_froglight
fill 299 256 275 304 276 275 minecraft:light_gray_concrete
fill 300 256 317 305 276 317 minecraft:light_gray_concrete
setblock 301 256 278 minecraft:light[level=15]
setblock 301 256 286 minecraft:light[level=15]
setblock 301 256 294 minecraft:light[level=15]
setblock 301 256 302 minecraft:light[level=15]
setblock 301 256 310 minecraft:light[level=15]
fill 304 256 276 304 257 277 minecraft:iron_block
fill 305 256 275 308 256 275 minecraft:pearlescent_froglight
fill 306 256 317 309 256 317 minecraft:pearlescent_froglight
fill 309 256 275 314 262 275 minecraft:light_gray_concrete
setblock 309 256 278 minecraft:light[level=15]
setblock 309 256 286 minecraft:light[level=15]
setblock 309 256 294 minecraft:light[level=15]
setblock 309 256 302 minecraft:light[level=15]
setblock 309 256 310 minecraft:light[level=15]
fill 310 256 317 315 276 317 minecraft:light_gray_concrete
fill 315 256 275 318 256 275 minecraft:pearlescent_froglight
fill 316 256 317 319 256 317 minecraft:pearlescent_froglight
setblock 317 256 278 minecraft:light[level=15]
setblock 317 256 286 minecraft:light[level=15]
setblock 317 256 294 minecraft:light[level=15]
setblock 317 256 302 minecraft:light[level=15]
setblock 317 256 310 minecraft:light[level=15]
fill 319 256 275 324 257 275 minecraft:light_gray_concrete
setblock 319 256 294 minecraft:iron_block
setblock 319 256 296 minecraft:iron_block
fill 320 256 317 324 276 317 minecraft:light_gray_concrete
setblock 321 256 294 minecraft:iron_block
setblock 321 256 296 minecraft:iron_block
fill 324 256 276 324 256 279 minecraft:pearlescent_froglight
fill 324 256 280 324 271 285 minecraft:light_gray_concrete
fill 324 256 286 324 256 289 minecraft:pearlescent_froglight
fill 324 256 290 324 264 295 minecraft:light_gray_concrete
fill 324 256 296 324 256 299 minecraft:pearlescent_froglight
fill 324 256 300 324 276 300 minecraft:light_gray_concrete
fill 324 256 302 324 276 305 minecraft:light_gray_concrete
fill 324 256 306 324 256 309 minecraft:pearlescent_froglight
fill 324 256 310 324 273 315 minecraft:light_gray_concrete
setblock 324 256 316 minecraft:pearlescent_froglight
fill 282 257 281 282 264 284 minecraft:light_gray_concrete
fill 282 257 291 282 264 294 minecraft:light_gray_concrete
fill 282 257 301 282 264 304 minecraft:light_gray_concrete
fill 282 257 311 282 262 314 minecraft:light_gray_concrete
fill 283 257 309 289 258 310 minecraft:iron_block
fill 285 257 275 288 264 275 minecraft:light_gray_concrete
fill 286 257 317 289 264 317 minecraft:light_gray_concrete
fill 290 257 310 291 258 310 minecraft:iron_block
fill 295 257 275 298 264 275 minecraft:light_gray_concrete
fill 296 257 317 299 264 317 minecraft:light_gray_concrete
fill 303 257 277 303 257 279 minecraft:iron_block
fill 304 257 279 305 257 279 minecraft:iron_block
fill 305 257 275 308 261 275 minecraft:light_gray_concrete
fill 305 257 277 305 257 278 minecraft:iron_block
fill 306 257 317 309 264 317 minecraft:light_gray_concrete
fill 315 257 275 318 264 275 minecraft:light_gray_concrete
fill 316 257 317 319 264 317 minecraft:light_gray_concrete
fill 324 257 276 324 264 279 minecraft:light_gray_concrete
fill 324 257 286 324 264 289 minecraft:light_gray_concrete
fill 324 257 296 324 264 299 minecraft:light_gray_concrete
fill 324 257 306 324 264 309 minecraft:light_gray_concrete
fill 324 257 316 324 264 316 minecraft:light_gray_concrete
setblock 283 258 278 minecraft:iron_block
setblock 283 258 288 minecraft:iron_block
setblock 283 258 298 minecraft:iron_block
setblock 283 258 308 minecraft:iron_block
setblock 285 258 278 minecraft:light[level=12]
setblock 285 258 285 minecraft:light[level=12]
setblock 285 258 292 minecraft:light[level=12]
setblock 285 258 299 minecraft:light[level=12]
setblock 285 258 306 minecraft:light[level=12]
setblock 285 258 316 minecraft:iron_block
setblock 289 258 276 minecraft:iron_block
fill 290 258 309 296 258 309 minecraft:iron_block
setblock 292 258 278 minecraft:light[level=12]
setblock 292 258 285 minecraft:light[level=12]
setblock 292 258 292 minecraft:light[level=12]
setblock 292 258 299 minecraft:light[level=12]
setblock 292 258 306 minecraft:light[level=12]
fill 292 258 310 308 258 310 minecraft:iron_block
setblock 292 258 313 minecraft:light[level=12]
setblock 295 258 316 minecraft:iron_block
fill 298 258 311 312 258 311 minecraft:iron_block
setblock 299 258 276 minecraft:iron_block
setblock 299 258 278 minecraft:light[level=12]
setblock 299 258 285 minecraft:light[level=12]
setblock 299 258 292 minecraft:light[level=12]
setblock 299 258 299 minecraft:light[level=12]
setblock 299 258 306 minecraft:light[level=12]
setblock 299 258 313 minecraft:light[level=12]
setblock 305 258 316 minecraft:iron_block
setblock 306 258 278 minecraft:light[level=12]
setblock 306 258 285 minecraft:light[level=12]
setblock 306 258 292 minecraft:light[level=12]
setblock 306 258 299 minecraft:light[level=12]
setblock 306 258 306 minecraft:light[level=12]
setblock 306 258 313 minecraft:light[level=12]
setblock 309 258 276 minecraft:iron_block
setblock 313 258 278 minecraft:light[level=12]
setblock 313 258 285 minecraft:light[level=12]
setblock 313 258 292 minecraft:light[level=12]
setblock 313 258 299 minecraft:light[level=12]
setblock 313 258 306 minecraft:light[level=12]
setblock 313 258 313 minecraft:light[level=12]
setblock 315 258 316 minecraft:iron_block
setblock 319 258 275 minecraft:sea_lantern
setblock 319 258 276 minecraft:iron_block
fill 320 258 275 324 276 275 minecraft:light_gray_concrete
setblock 320 258 278 minecraft:light[level=12]
setblock 320 258 285 minecraft:light[level=12]
setblock 320 258 292 minecraft:light[level=12]
setblock 320 258 299 minecraft:light[level=12]
setblock 320 258 306 minecraft:light[level=12]
setblock 320 258 313 minecraft:light[level=12]
setblock 323 258 282 minecraft:iron_block
setblock 323 258 292 minecraft:iron_block
setblock 323 258 302 minecraft:iron_block
fill 323 258 312 323 260 312 minecraft:iron_block
fill 283 259 309 288 259 309 minecraft:light_gray_concrete
fill 288 259 310 293 259 310 minecraft:light_gray_concrete
fill 294 259 310 315 259 310 minecraft:iron_block
fill 301 259 311 323 259 311 minecraft:iron_block
fill 316 259 312 322 259 312 minecraft:iron_block
fill 319 259 275 319 276 275 minecraft:light_gray_concrete
fill 295 260 310 306 260 310 minecraft:light_gray_concrete
fill 306 260 311 312 260 311 minecraft:light_gray_concrete
fill 313 260 311 323 260 311 minecraft:iron_block
fill 320 260 312 322 260 312 minecraft:iron_block
fill 283 261 280 283 261 283 minecraft:iron_block
fill 283 261 290 283 261 293 minecraft:iron_block
fill 283 261 300 283 261 303 minecraft:iron_block
fill 283 261 310 283 261 313 minecraft:iron_block
fill 284 261 276 287 261 276 minecraft:iron_block
fill 287 261 316 290 261 316 minecraft:iron_block
fill 294 261 276 297 261 276 minecraft:iron_block
fill 297 261 316 300 261 316 minecraft:iron_block
fill 304 261 276 307 261 276 minecraft:iron_block
fill 307 261 316 310 261 316 minecraft:iron_block
fill 314 261 276 317 261 276 minecraft:iron_block
fill 314 261 311 322 261 311 minecraft:light_gray_concrete
fill 317 261 316 320 261 316 minecraft:iron_block
fill 323 261 277 323 261 280 minecraft:iron_block
fill 323 261 287 323 261 290 minecraft:iron_block
fill 323 261 297 323 261 300 minecraft:iron_block
fill 323 261 307 323 261 310 minecraft:iron_block
setblock 305 262 275 minecraft:sea_lantern
fill 306 262 275 308 264 275 minecraft:light_gray_concrete
fill 282 263 311 282 264 313 minecraft:light_gray_concrete
setblock 282 263 314 minecraft:redstone_block
fill 284 263 294 284 263 296 minecraft:iron_block
fill 284 263 312 284 263 314 minecraft:iron_block
fill 285 263 293 287 263 293 minecraft:iron_block
fill 285 263 297 287 263 297 minecraft:iron_block
fill 285 263 311 287 263 311 minecraft:iron_block
fill 285 263 315 287 263 315 minecraft:iron_block
fill 288 263 294 288 263 296 minecraft:iron_block
fill 288 263 312 288 263 314 minecraft:iron_block
fill 303 263 277 303 263 279 minecraft:iron_block
fill 304 263 277 305 263 277 minecraft:iron_block
fill 304 263 279 305 263 279 minecraft:iron_block
fill 305 263 275 305 264 275 minecraft:light_gray_concrete
setblock 305 263 278 minecraft:iron_block
fill 309 263 275 311 276 275 minecraft:light_gray_concrete
setblock 312 263 275 minecraft:redstone_block
fill 313 263 275 314 276 275 minecraft:light_gray_concrete
setblock 319 263 294 minecraft:iron_block
setblock 319 263 296 minecraft:iron_block
setblock 321 263 294 minecraft:iron_block
setblock 321 263 296 minecraft:iron_block
setblock 282 264 314 minecraft:light_gray_concrete
setblock 283 264 278 minecraft:iron_block
setblock 283 264 288 minecraft:iron_block
setblock 283 264 298 minecraft:iron_block
setblock 283 264 308 minecraft:iron_block
setblock 285 264 278 minecraft:light[level=15]
setblock 285 264 285 minecraft:light[level=12]
setblock 285 264 286 minecraft:light[level=15]
setblock 285 264 292 minecraft:light[level=12]
setblock 285 264 299 minecraft:light[level=12]
setblock 285 264 302 minecraft:light[level=15]
setblock 285 264 306 minecraft:light[level=12]
setblock 285 264 310 minecraft:light[level=15]
setblock 285 264 316 minecraft:iron_block
setblock 289 264 276 minecraft:iron_block
setblock 292 264 278 minecraft:light[level=12]
setblock 292 264 285 minecraft:light[level=12]
setblock 292 264 292 minecraft:light[level=12]
setblock 292 264 299 minecraft:light[level=12]
setblock 292 264 306 minecraft:light[level=12]
setblock 292 264 313 minecraft:light[level=12]
setblock 293 264 278 minecraft:light[level=15]
setblock 293 264 286 minecraft:light[level=15]
setblock 293 264 294 minecraft:light[level=15]
setblock 293 264 302 minecraft:light[level=15]
setblock 293 264 310 minecraft:light[level=15]
setblock 295 264 316 minecraft:iron_block
setblock 299 264 276 minecraft:iron_block
setblock 299 264 278 minecraft:light[level=12]
setblock 299 264 285 minecraft:light[level=12]
setblock 299 264 292 minecraft:light[level=12]
setblock 299 264 299 minecraft:light[level=12]
setblock 299 264 306 minecraft:light[level=12]
setblock 299 264 313 minecraft:light[level=12]
setblock 301 264 278 minecraft:light[level=15]
setblock 301 264 286 minecraft:light[level=15]
setblock 301 264 294 minecraft:light[level=15]
setblock 301 264 302 minecraft:light[level=15]
setblock 301 264 310 minecraft:light[level=15]
setblock 305 264 316 minecraft:iron_block
setblock 306 264 278 minecraft:light[level=12]
setblock 306 264 285 minecraft:light[level=12]
setblock 306 264 292 minecraft:light[level=12]
setblock 306 264 299 minecraft:light[level=12]
setblock 306 264 306 minecraft:light[level=12]
setblock 306 264 313 minecraft:light[level=12]
setblock 309 264 276 minecraft:iron_block
setblock 309 264 278 minecraft:light[level=15]
setblock 309 264 286 minecraft:light[level=15]
setblock 309 264 294 minecraft:light[level=15]
setblock 309 264 302 minecraft:light[level=15]
setblock 309 264 310 minecraft:light[level=15]
fill 312 264 275 312 276 275 minecraft:light_gray_concrete
setblock 313 264 278 minecraft:light[level=12]
setblock 313 264 285 minecraft:light[level=12]
setblock 313 264 292 minecraft:light[level=12]
setblock 313 264 299 minecraft:light[level=12]
setblock 313 264 306 minecraft:light[level=12]
setblock 313 264 313 minecraft:light[level=12]
setblock 315 264 316 minecraft:iron_block
setblock 317 264 278 minecraft:light[level=15]
setblock 317 264 286 minecraft:light[level=15]
setblock 317 264 294 minecraft:light[level=15]
setblock 317 264 302 minecraft:light[level=15]
setblock 317 264 310 minecraft:light[level=15]
setblock 319 264 276 minecraft:iron_block
setblock 320 264 278 minecraft:light[level=12]
setblock 320 264 285 minecraft:light[level=12]
setblock 320 264 292 minecraft:light[level=12]
setblock 320 264 299 minecraft:light[level=12]
setblock 320 264 306 minecraft:light[level=12]
setblock 320 264 313 minecraft:light[level=12]
setblock 323 264 282 minecraft:iron_block
setblock 323 264 292 minecraft:iron_block
setblock 323 264 302 minecraft:iron_block
setblock 323 264 312 minecraft:iron_block
fill 282 265 281 282 265 284 minecraft:pearlescent_froglight
fill 282 265 291 282 265 294 minecraft:pearlescent_froglight
fill 282 265 301 282 265 304 minecraft:pearlescent_froglight
fill 282 265 311 282 265 314 minecraft:pearlescent_froglight
fill 285 265 275 288 265 275 minecraft:pearlescent_froglight
fill 286 265 317 289 265 317 minecraft:pearlescent_froglight
fill 295 265 275 298 265 275 minecraft:pearlescent_froglight
fill 296 265 317 299 265 317 minecraft:pearlescent_froglight
fill 305 265 275 308 265 275 minecraft:pearlescent_froglight
fill 306 265 317 309 265 317 minecraft:pearlescent_froglight
fill 315 265 275 318 265 275 minecraft:pearlescent_froglight
fill 316 265 317 319 265 317 minecraft:pearlescent_froglight
fill 320 265 291 322 266 291 minecraft:iron_block
fill 324 265 276 324 265 279 minecraft:pearlescent_froglight
fill 324 265 286 324 265 289 minecraft:pearlescent_froglight
fill 324 265 290 324 271 292 minecraft:light_gray_concrete
setblock 324 265 293 minecraft:sea_lantern
fill 324 265 294 324 276 295 minecraft:light_gray_concrete
fill 324 265 296 324 265 299 minecraft:pearlescent_froglight
fill 324 265 306 324 265 309 minecraft:pearlescent_froglight
setblock 324 265 316 minecraft:pearlescent_froglight
fill 282 266 281 282 269 284 minecraft:light_gray_concrete
fill 282 266 291 282 272 294 minecraft:light_gray_concrete
fill 282 266 301 282 276 304 minecraft:light_gray_concrete
fill 282 266 311 282 275 314 minecraft:light_gray_concrete
fill 283 266 310 285 267 310 minecraft:iron_block
fill 285 266 275 288 276 275 minecraft:light_gray_concrete
fill 286 266 317 289 276 317 minecraft:light_gray_concrete
fill 287 266 311 288 267 311 minecraft:iron_block
fill 287 266 315 288 267 316 minecraft:iron_block
fill 288 266 299 288 267 310 minecraft:iron_block
fill 288 266 312 288 267 314 minecraft:iron_block
fill 289 266 287 289 267 307 minecraft:iron_block
fill 290 266 277 290 267 295 minecraft:iron_block
fill 291 266 276 291 267 283 minecraft:iron_block
fill 295 266 275 298 276 275 minecraft:light_gray_concrete
fill 296 266 317 299 271 317 minecraft:light_gray_concrete
fill 305 266 275 308 276 275 minecraft:light_gray_concrete
fill 306 266 317 309 269 317 minecraft:light_gray_concrete
fill 315 266 275 318 276 275 minecraft:light_gray_concrete
fill 316 266 317 319 266 317 minecraft:light_gray_concrete
fill 322 266 295 323 267 295 minecraft:iron_block
fill 324 266 276 324 276 279 minecraft:light_gray_concrete
fill 324 266 286 324 276 289 minecraft:light_gray_concrete
fill 324 266 293 324 276 293 minecraft:light_gray_concrete
fill 324 266 296 324 276 299 minecraft:light_gray_concrete
fill 324 266 306 324 275 309 minecraft:light_gray_concrete
fill 324 266 316 324 276 316 minecraft:light_gray_concrete
fill 290 267 317 294 276 317 minecraft:light_gray_concrete
setblock 295 267 317 minecraft:sea_lantern
fill 316 267 317 318 272 317 minecraft:light_gray_concrete
setblock 318 267 295 minecraft:pearlescent_froglight
setblock 319 267 317 minecraft:sea_lantern
fill 282 268 295 282 269 299 minecraft:light_gray_concrete
setblock 282 268 300 minecraft:sea_lantern
fill 287 268 315 288 268 315 minecraft:light_gray_concrete
fill 288 268 303 288 268 314 minecraft:light_gray_concrete
fill 289 268 291 289 268 303 minecraft:light_gray_concrete
fill 290 268 280 290 268 291 minecraft:light_gray_concrete
fill 291 268 276 291 268 280 minecraft:light_gray_concrete
fill 295 268 317 295 276 317 minecraft:light_gray_concrete
fill 316 268 290 316 270 290 minecraft:iron_block
fill 319 268 317 319 276 317 minecraft:light_gray_concrete
fill 282 269 300 282 276 300 minecraft:light_gray_concrete
fill 282 269 305 282 276 305 minecraft:light_gray_concrete
setblock 282 269 306 minecraft:redstone_block
fill 282 269 307 282 276 310 minecraft:light_gray_concrete
fill 303 269 277 303 269 279 minecraft:iron_block
fill 304 269 277 305 269 277 minecraft:iron_block
fill 304 269 279 305 269 279 minecraft:iron_block
setblock 305 269 278 minecraft:iron_block
setblock 282 270 281 minecraft:sea_lantern
fill 282 270 282 282 276 284 minecraft:light_gray_concrete
fill 282 270 295 282 276 296 minecraft:light_gray_concrete
setblock 282 270 297 minecraft:redstone_block
fill 282 270 298 282 276 299 minecraft:light_gray_concrete
fill 282 270 306 282 276 306 minecraft:light_gray_concrete
setblock 283 270 278 minecraft:iron_block
fill 283 270 280 283 270 283 minecraft:iron_block
setblock 283 270 288 minecraft:iron_block
fill 283 270 290 283 270 293 minecraft:iron_block
setblock 283 270 298 minecraft:iron_block
fill 283 270 300 283 270 303 minecraft:iron_block
setblock 283 270 308 minecraft:iron_block
fill 283 270 310 283 270 313 minecraft:iron_block
fill 284 270 276 287 270 276 minecraft:iron_block
setblock 285 270 278 minecraft:light[level=12]
setblock 285 270 285 minecraft:light[level=12]
setblock 285 270 292 minecraft:light[level=12]
setblock 285 270 299 minecraft:light[level=12]
setblock 285 270 306 minecraft:light[level=12]
setblock 285 270 316 minecraft:iron_block
fill 287 270 316 290 270 316 minecraft:iron_block
setblock 289 270 276 minecraft:iron_block
setblock 292 270 278 minecraft:light[level=12]
setblock 292 270 285 minecraft:light[level=12]
setblock 292 270 292 minecraft:light[level=12]
setblock 292 270 299 minecraft:light[level=12]
setblock 292 270 306 minecraft:light[level=12]
setblock 292 270 313 minecraft:light[level=12]
fill 294 270 276 297 270 276 minecraft:iron_block
setblock 295 270 316 minecraft:iron_block
fill 297 270 316 300 270 316 minecraft:iron_block
setblock 299 270 276 minecraft:iron_block
setblock 299 270 278 minecraft:light[level=12]
setblock 299 270 285 minecraft:light[level=12]
setblock 299 270 292 minecraft:light[level=12]
setblock 299 270 299 minecraft:light[level=12]
setblock 299 270 306 minecraft:light[level=12]
setblock 299 270 313 minecraft:light[level=12]
fill 304 270 276 307 270 276 minecraft:iron_block
setblock 305 270 316 minecraft:iron_block
setblock 306 270 278 minecraft:light[level=12]
setblock 306 270 285 minecraft:light[level=12]
setblock 306 270 292 minecraft:light[level=12]
setblock 306 270 299 minecraft:light[level=12]
setblock 306 270 306 minecraft:light[level=12]
setblock 306 270 313 minecraft:light[level=12]
fill 306 270 317 307 276 317 minecraft:light_gray_concrete
fill 307 270 316 310 270 316 minecraft:iron_block
setblock 308 270 317 minecraft:sea_lantern
setblock 309 270 276 minecraft:iron_block
fill 309 270 317 309 276 317 minecraft:light_gray_concrete
setblock 313 270 278 minecraft:light[level=12]
setblock 313 270 285 minecraft:light[level=12]
setblock 313 270 292 minecraft:light[level=12]
setblock 313 270 299 minecraft:light[level=12]
setblock 313 270 306 minecraft:light[level=12]
setblock 313 270 313 minecraft:light[level=12]
fill 314 270 276 317 270 276 minecraft:iron_block
setblock 315 270 316 minecraft:iron_block
fill 317 270 316 320 270 316 minecraft:iron_block
setblock 319 270 276 minecraft:iron_block
setblock 320 270 278 minecraft:light[level=12]
setblock 320 270 285 minecraft:light[level=12]
setblock 320 270 292 minecraft:light[level=12]
setblock 320 270 299 minecraft:light[level=12]
setblock 320 270 306 minecraft:light[level=12]
setblock 320 270 313 minecraft:light[level=12]
fill 323 270 277 323 270 280 minecraft:iron_block
setblock 323 270 282 minecraft:iron_block
fill 323 270 287 323 270 290 minecraft:iron_block
setblock 323 270 292 minecraft:iron_block
fill 323 270 297 323 270 300 minecraft:iron_block
setblock 323 270 302 minecraft:iron_block
fill 323 270 307 323 270 310 minecraft:iron_block
setblock 323 270 312 minecraft:iron_block
fill 282 271 281 282 276 281 minecraft:light_gray_concrete
fill 282 271 297 282 276 297 minecraft:light_gray_concrete
fill 308 271 317 308 276 317 minecraft:light_gray_concrete
setblock 285 272 278 minecraft:light[level=15]
setblock 285 272 286 minecraft:light[level=15]
setblock 285 272 294 minecraft:light[level=15]
setblock 285 272 302 minecraft:light[level=15]
setblock 285 272 310 minecraft:light[level=15]
fill 289 272 275 293 276 275 minecraft:light_gray_concrete
setblock 293 272 278 minecraft:light[level=15]
setblock 293 272 286 minecraft:light[level=15]
setblock 293 272 294 minecraft:light[level=15]
setblock 293 272 302 minecraft:light[level=15]
setblock 293 272 310 minecraft:light[level=15]
setblock 294 272 275 minecraft:redstone_block
setblock 296 272 317 minecraft:sea_lantern
fill 297 272 317 299 273 317 minecraft:light_gray_concrete
setblock 301 272 278 minecraft:light[level=15]
setblock 301 272 286 minecraft:light[level=15]
setblock 301 272 294 minecraft:light[level=15]
setblock 301 272 302 minecraft:light[level=15]
setblock 301 272 310 minecraft:light[level=15]
setblock 309 272 278 minecraft:light[level=15]
setblock 309 272 286 minecraft:light[level=15]
setblock 309 272 294 minecraft:light[level=15]
setblock 309 272 302 minecraft:light[level=15]
setblock 309 272 310 minecraft:light[level=15]
setblock 317 272 278 minecraft:light[level=15]
setblock 317 272 286 minecraft:light[level=15]
setblock 317 272 294 minecraft:light[level=15]
setblock 317 272 302 minecraft:light[level=15]
setblock 317 272 310 minecraft:light[level=15]
fill 324 272 280 324 276 282 minecraft:light_gray_concrete
setblock 324 272 283 minecraft:redstone_block
fill 324 272 284 324 276 285 minecraft:light_gray_concrete
fill 324 272 290 324 276 290 minecraft:light_gray_concrete
setblock 324 272 291 minecraft:sea_lantern
fill 324 272 292 324 276 292 minecraft:light_gray_concrete
fill 282 273 291 282 276 291 minecraft:light_gray_concrete
setblock 282 273 292 minecraft:redstone_block
fill 282 273 293 282 276 294 minecraft:light_gray_concrete
fill 294 273 275 294 276 275 minecraft:light_gray_concrete
fill 296 273 317 296 276 317 minecraft:light_gray_concrete
fill 316 273 317 316 276 317 minecraft:light_gray_concrete
setblock 317 273 317 minecraft:redstone_block
fill 318 273 317 318 276 317 minecraft:light_gray_concrete
fill 324 273 283 324 276 283 minecraft:light_gray_concrete
fill 324 273 291 324 276 291 minecraft:light_gray_concrete
fill 282 274 292 282 276 292 minecraft:light_gray_concrete
setblock 297 274 317 minecraft:redstone_block
fill 298 274 317 299 276 317 minecraft:light_gray_concrete
fill 317 274 317 317 276 317 minecraft:light_gray_concrete
fill 324 274 310 324 276 311 minecraft:light_gray_concrete
setblock 324 274 312 minecraft:sea_lantern
fill 324 274 313 324 276 315 minecraft:light_gray_concrete
fill 297 275 317 297 276 317 minecraft:light_gray_concrete
fill 324 275 312 324 276 312 minecraft:light_gray_concrete
setblock 282 276 311 minecraft:sea_lantern
fill 282 276 312 282 276 314 minecraft:light_gray_concrete
setblock 285 276 278 minecraft:light[level=12]
setblock 285 276 285 minecraft:light[level=12]
setblock 285 276 292 minecraft:light[level=12]
setblock 285 276 299 minecraft:light[level=12]
setblock 285 276 306 minecraft:light[level=12]
setblock 285 276 313 minecraft:light[level=12]
setblock 292 276 278 minecraft:light[level=12]
fill 292 276 285 301 278 306 minecraft:iron_block
setblock 292 276 313 minecraft:light[level=12]
setblock 299 276 278 minecraft:light[level=12]
setblock 299 276 313 minecraft:light[level=12]
fill 302 276 285 302 278 296 minecraft:iron_block
fill 302 276 298 302 278 306 minecraft:iron_block
fill 303 276 285 304 278 294 minecraft:iron_block
fill 303 276 300 304 278 306 minecraft:iron_block
fill 305 276 285 313 278 293 minecraft:iron_block
fill 305 276 301 313 278 306 minecraft:iron_block
setblock 306 276 278 minecraft:light[level=12]
fill 306 276 294 313 278 294 minecraft:iron_block
fill 306 276 300 313 278 300 minecraft:iron_block
setblock 306 276 313 minecraft:light[level=12]
fill 308 276 295 313 278 296 minecraft:iron_block
fill 308 276 298 313 278 299 minecraft:iron_block
fill 309 276 297 313 278 297 minecraft:iron_block
setblock 313 276 278 minecraft:light[level=12]
setblock 313 276 313 minecraft:light[level=12]
setblock 320 276 278 minecraft:light[level=12]
setblock 320 276 285 minecraft:light[level=12]
setblock 320 276 292 minecraft:light[level=12]
setblock 320 276 299 minecraft:light[level=12]
setblock 320 276 306 minecraft:light[level=12]
setblock 320 276 313 minecraft:light[level=12]
fill 324 276 306 324 276 308 minecraft:light_gray_concrete
setblock 324 276 309 minecraft:redstone_block
fill 282 277 275 282 278 276 minecraft:yellow_concrete
fill 282 277 277 282 278 278 minecraft:black_concrete
fill 282 277 279 282 278 280 minecraft:yellow_concrete
fill 282 277 281 282 278 282 minecraft:black_concrete
fill 282 277 283 282 278 284 minecraft:yellow_concrete
fill 282 277 285 282 278 286 minecraft:black_concrete
fill 282 277 287 282 278 288 minecraft:yellow_concrete
fill 282 277 289 282 278 290 minecraft:black_concrete
fill 282 277 291 282 278 292 minecraft:yellow_concrete
fill 282 277 293 282 278 294 minecraft:black_concrete
fill 282 277 295 282 278 296 minecraft:yellow_concrete
fill 282 277 297 282 278 298 minecraft:black_concrete
fill 282 277 299 282 278 300 minecraft:yellow_concrete
fill 282 277 301 282 278 302 minecraft:black_concrete
fill 282 277 303 282 278 304 minecraft:yellow_concrete
fill 282 277 305 282 278 306 minecraft:black_concrete
fill 282 277 307 282 278 308 minecraft:yellow_concrete
fill 282 277 309 282 278 310 minecraft:black_concrete
fill 282 277 311 282 278 312 minecraft:yellow_concrete
fill 282 277 313 282 278 314 minecraft:black_concrete
fill 282 277 315 282 278 316 minecraft:yellow_concrete
fill 282 277 317 282 278 317 minecraft:black_concrete
fill 283 277 275 283 278 275 minecraft:yellow_concrete
fill 283 277 317 283 278 317 minecraft:yellow_concrete
fill 284 277 275 285 278 275 minecraft:black_concrete
fill 284 277 317 285 278 317 minecraft:black_concrete
fill 286 277 275 287 278 275 minecraft:yellow_concrete
fill 286 277 317 287 278 317 minecraft:yellow_concrete
fill 288 277 275 289 278 275 minecraft:black_concrete
fill 288 277 317 289 278 317 minecraft:black_concrete
fill 290 277 275 291 278 275 minecraft:yellow_concrete
fill 290 277 317 291 278 317 minecraft:yellow_concrete
fill 292 277 275 293 278 275 minecraft:black_concrete
fill 292 277 317 293 278 317 minecraft:black_concrete
fill 294 277 275 295 278 275 minecraft:yellow_concrete
fill 294 277 317 295 278 317 minecraft:yellow_concrete
fill 296 277 275 297 278 275 minecraft:black_concrete
fill 296 277 317 297 278 317 minecraft:black_concrete
fill 298 277 275 299 278 275 minecraft:yellow_concrete
fill 298 277 317 299 278 317 minecraft:yellow_concrete
fill 300 277 275 301 278 275 minecraft:black_concrete
fill 300 277 317 301 278 317 minecraft:black_concrete
fill 302 277 275 303 278 275 minecraft:yellow_concrete
fill 302 277 317 303 278 317 minecraft:yellow_concrete
fill 304 277 275 305 278 275 minecraft:black_concrete
fill 304 277 317 305 278 317 minecraft:black_concrete
fill 306 277 275 307 278 275 minecraft:yellow_concrete
fill 306 277 317 307 278 317 minecraft:yellow_concrete
fill 308 277 275 309 278 275 minecraft:black_concrete
fill 308 277 317 309 278 317 minecraft:black_concrete
fill 310 277 275 311 278 275 minecraft:yellow_concrete
fill 310 277 317 311 278 317 minecraft:yellow_concrete
fill 312 277 275 313 278 275 minecraft:black_concrete
fill 312 277 317 313 278 317 minecraft:black_concrete
fill 314 277 275 315 278 275 minecraft:yellow_concrete
fill 314 277 317 315 278 317 minecraft:yellow_concrete
fill 316 277 275 317 278 275 minecraft:black_concrete
fill 316 277 317 317 278 317 minecraft:black_concrete
fill 318 277 275 319 278 275 minecraft:yellow_concrete
fill 318 277 317 319 278 317 minecraft:yellow_concrete
fill 320 277 275 321 278 275 minecraft:black_concrete
fill 320 277 317 321 278 317 minecraft:black_concrete
fill 322 277 275 323 278 275 minecraft:yellow_concrete
fill 322 277 317 323 278 317 minecraft:yellow_concrete
fill 324 277 275 324 278 275 minecraft:black_concrete
fill 324 277 276 324 278 276 minecraft:yellow_concrete
fill 324 277 277 324 278 278 minecraft:black_concrete
fill 324 277 279 324 278 280 minecraft:yellow_concrete
fill 324 277 281 324 278 282 minecraft:black_concrete
fill 324 277 283 324 278 284 minecraft:yellow_concrete
fill 324 277 285 324 278 286 minecraft:black_concrete
fill 324 277 287 324 278 288 minecraft:yellow_concrete
fill 324 277 289 324 278 290 minecraft:black_concrete
fill 324 277 291 324 278 292 minecraft:yellow_concrete
fill 324 277 293 324 278 294 minecraft:black_concrete
fill 324 277 295 324 278 296 minecraft:yellow_concrete
fill 324 277 297 324 278 298 minecraft:black_concrete
fill 324 277 299 324 278 300 minecraft:yellow_concrete
fill 324 277 301 324 278 302 minecraft:black_concrete
fill 324 277 303 324 278 304 minecraft:yellow_concrete
fill 324 277 305 324 278 306 minecraft:black_concrete
fill 324 277 307 324 278 308 minecraft:yellow_concrete
fill 324 277 309 324 278 310 minecraft:black_concrete
fill 324 277 311 324 278 312 minecraft:yellow_concrete
fill 324 277 313 324 278 314 minecraft:black_concrete
fill 324 277 315 324 278 316 minecraft:yellow_concrete
fill 324 277 317 324 278 317 minecraft:black_concrete
fill 282 279 275 282 282 317 minecraft:light_gray_concrete
fill 283 279 275 324 280 275 minecraft:light_gray_concrete
fill 283 279 276 323 279 277 minecraft:gray_concrete
setblock 283 279 278 minecraft:yellow_concrete
fill 283 279 279 283 279 283 minecraft:gray_concrete
setblock 283 279 284 minecraft:yellow_concrete
fill 283 279 285 283 279 289 minecraft:gray_concrete
setblock 283 279 290 minecraft:yellow_concrete
fill 283 279 291 283 279 295 minecraft:gray_concrete
setblock 283 279 296 minecraft:yellow_concrete
fill 283 279 297 283 279 301 minecraft:gray_concrete
setblock 283 279 302 minecraft:yellow_concrete
fill 283 279 303 283 279 307 minecraft:gray_concrete
setblock 283 279 308 minecraft:yellow_concrete
fill 283 279 309 283 279 313 minecraft:gray_concrete
setblock 283 279 314 minecraft:yellow_concrete
fill 283 279 315 323 279 316 minecraft:gray_concrete
fill 283 279 317 324 279 317 minecraft:light_gray_concrete
fill 284 279 278 284 279 280 minecraft:gray_concrete
setblock 284 279 281 minecraft:yellow_concrete
fill 284 279 282 284 279 286 minecraft:gray_concrete
setblock 284 279 287 minecraft:yellow_concrete
fill 284 279 288 284 279 292 minecraft:gray_concrete
setblock 284 279 293 minecraft:yellow_concrete
fill 284 279 294 284 279 298 minecraft:gray_concrete
setblock 284 279 299 minecraft:yellow_concrete
fill 284 279 300 284 279 304 minecraft:gray_concrete
setblock 284 279 305 minecraft:yellow_concrete
fill 284 279 306 284 279 310 minecraft:gray_concrete
setblock 284 279 311 minecraft:yellow_concrete
fill 284 279 312 284 279 314 minecraft:gray_concrete
setblock 285 279 278 minecraft:yellow_concrete
fill 285 279 279 285 279 283 minecraft:gray_concrete
setblock 285 279 284 minecraft:yellow_concrete
fill 285 279 285 285 279 289 minecraft:gray_concrete
setblock 285 279 290 minecraft:yellow_concrete
fill 285 279 291 285 279 295 minecraft:gray_concrete
setblock 285 279 296 minecraft:yellow_concrete
fill 285 279 297 285 279 301 minecraft:gray_concrete
setblock 285 279 302 minecraft:yellow_concrete
fill 285 279 303 285 279 307 minecraft:gray_concrete
setblock 285 279 308 minecraft:yellow_concrete
fill 285 279 309 285 279 313 minecraft:gray_concrete
setblock 285 279 314 minecraft:yellow_concrete
fill 286 279 278 286 279 280 minecraft:gray_concrete
setblock 286 279 281 minecraft:yellow_concrete
fill 286 279 282 286 279 286 minecraft:gray_concrete
setblock 286 279 287 minecraft:yellow_concrete
fill 286 279 288 286 279 292 minecraft:gray_concrete
setblock 286 279 293 minecraft:yellow_concrete
fill 286 279 294 286 279 298 minecraft:gray_concrete
setblock 286 279 299 minecraft:yellow_concrete
fill 286 279 300 286 279 304 minecraft:gray_concrete
setblock 286 279 305 minecraft:yellow_concrete
fill 286 279 306 286 279 310 minecraft:gray_concrete
setblock 286 279 311 minecraft:yellow_concrete
fill 286 279 312 286 279 314 minecraft:gray_concrete
setblock 287 279 278 minecraft:yellow_concrete
fill 287 279 279 287 279 283 minecraft:gray_concrete
setblock 287 279 284 minecraft:yellow_concrete
fill 287 279 285 287 279 289 minecraft:gray_concrete
setblock 287 279 290 minecraft:yellow_concrete
fill 287 279 291 287 279 295 minecraft:gray_concrete
setblock 287 279 296 minecraft:yellow_concrete
fill 287 279 297 287 279 301 minecraft:gray_concrete
setblock 287 279 302 minecraft:yellow_concrete
fill 287 279 303 287 279 307 minecraft:gray_concrete
setblock 287 279 308 minecraft:yellow_concrete
fill 287 279 309 287 279 313 minecraft:gray_concrete
setblock 287 279 314 minecraft:yellow_concrete
fill 288 279 278 288 279 280 minecraft:gray_concrete
setblock 288 279 281 minecraft:yellow_concrete
fill 288 279 282 288 279 286 minecraft:gray_concrete
setblock 288 279 287 minecraft:yellow_concrete
fill 288 279 288 288 279 292 minecraft:gray_concrete
setblock 288 279 293 minecraft:yellow_concrete
fill 288 279 294 288 279 298 minecraft:gray_concrete
setblock 288 279 299 minecraft:yellow_concrete
fill 288 279 300 288 279 304 minecraft:gray_concrete
setblock 288 279 305 minecraft:yellow_concrete
fill 288 279 306 288 279 310 minecraft:gray_concrete
setblock 288 279 311 minecraft:yellow_concrete
fill 288 279 312 288 279 314 minecraft:gray_concrete
setblock 289 279 278 minecraft:yellow_concrete
fill 289 279 279 289 279 283 minecraft:gray_concrete
setblock 289 279 284 minecraft:yellow_concrete
fill 289 279 285 289 279 289 minecraft:gray_concrete
setblock 289 279 290 minecraft:yellow_concrete
fill 289 279 291 289 279 295 minecraft:gray_concrete
setblock 289 279 296 minecraft:yellow_concrete
fill 289 279 297 289 279 301 minecraft:gray_concrete
setblock 289 279 302 minecraft:yellow_concrete
fill 289 279 303 289 279 307 minecraft:gray_concrete
setblock 289 279 308 minecraft:yellow_concrete
fill 289 279 309 289 279 313 minecraft:gray_concrete
setblock 289 279 314 minecraft:yellow_concrete
fill 290 279 278 290 279 280 minecraft:gray_concrete
setblock 290 279 281 minecraft:yellow_concrete
fill 290 279 282 290 279 286 minecraft:gray_concrete
setblock 290 279 287 minecraft:yellow_concrete
fill 290 279 288 290 279 292 minecraft:gray_concrete
setblock 290 279 293 minecraft:yellow_concrete
fill 290 279 294 290 279 298 minecraft:gray_concrete
setblock 290 279 299 minecraft:yellow_concrete
fill 290 279 300 290 279 304 minecraft:gray_concrete
setblock 290 279 305 minecraft:yellow_concrete
fill 290 279 306 290 279 310 minecraft:gray_concrete
setblock 290 279 311 minecraft:yellow_concrete
fill 290 279 312 290 279 314 minecraft:gray_concrete
setblock 291 279 278 minecraft:yellow_concrete
fill 291 279 279 291 279 283 minecraft:gray_concrete
setblock 291 279 284 minecraft:yellow_concrete
fill 291 279 285 291 279 289 minecraft:gray_concrete
setblock 291 279 290 minecraft:yellow_concrete
fill 291 279 291 291 279 295 minecraft:gray_concrete
setblock 291 279 296 minecraft:yellow_concrete
fill 291 279 297 291 279 301 minecraft:gray_concrete
setblock 291 279 302 minecraft:yellow_concrete
fill 291 279 303 291 279 307 minecraft:gray_concrete
setblock 291 279 308 minecraft:yellow_concrete
fill 291 279 309 291 279 313 minecraft:gray_concrete
setblock 291 279 314 minecraft:yellow_concrete
fill 292 279 278 292 279 280 minecraft:gray_concrete
setblock 292 279 281 minecraft:yellow_concrete
fill 292 279 282 292 279 284 minecraft:gray_concrete
fill 292 279 285 294 279 306 minecraft:iron_block
fill 292 279 307 292 279 310 minecraft:gray_concrete
setblock 292 279 311 minecraft:yellow_concrete
fill 292 279 312 292 279 314 minecraft:gray_concrete
setblock 293 279 278 minecraft:yellow_concrete
fill 293 279 279 293 279 283 minecraft:gray_concrete
setblock 293 279 284 minecraft:yellow_concrete
fill 293 279 307 323 279 307 minecraft:gray_concrete
setblock 293 279 308 minecraft:yellow_concrete
fill 293 279 309 293 279 313 minecraft:gray_concrete
setblock 293 279 314 minecraft:yellow_concrete
fill 294 279 278 294 279 280 minecraft:gray_concrete
setblock 294 279 281 minecraft:yellow_concrete
fill 294 279 282 294 279 284 minecraft:gray_concrete
fill 294 279 308 294 279 310 minecraft:gray_concrete
setblock 294 279 311 minecraft:yellow_concrete
fill 294 279 312 294 279 314 minecraft:gray_concrete
setblock 295 279 278 minecraft:yellow_concrete
fill 295 279 279 295 279 283 minecraft:gray_concrete
setblock 295 279 284 minecraft:yellow_concrete
fill 295 279 285 295 279 299 minecraft:iron_block
fill 295 279 300 295 279 302 minecraft:redstone_block
fill 295 279 303 295 279 306 minecraft:iron_block
setblock 295 279 308 minecraft:yellow_concrete
fill 295 279 309 295 279 313 minecraft:gray_concrete
setblock 295 279 314 minecraft:yellow_concrete
fill 296 279 278 296 279 280 minecraft:gray_concrete
setblock 296 279 281 minecraft:yellow_concrete
fill 296 279 282 296 279 284 minecraft:gray_concrete
fill 296 279 285 297 279 298 minecraft:iron_block
fill 296 279 299 296 279 300 minecraft:redstone_block
fill 296 279 301 298 279 301 minecraft:white_concrete
fill 296 279 302 296 279 303 minecraft:redstone_block
fill 296 279 304 313 279 306 minecraft:iron_block
fill 296 279 308 296 279 310 minecraft:gray_concrete
setblock 296 279 311 minecraft:yellow_concrete
fill 296 279 312 296 279 314 minecraft:gray_concrete
setblock 297 279 278 minecraft:yellow_concrete
fill 297 279 279 297 279 283 minecraft:gray_concrete
setblock 297 279 284 minecraft:yellow_concrete
fill 297 279 299 298 279 299 minecraft:redstone_block
setblock 297 279 300 minecraft:white_concrete
setblock 297 279 302 minecraft:white_concrete
fill 297 279 303 298 279 303 minecraft:redstone_block
setblock 297 279 308 minecraft:yellow_concrete
fill 297 279 309 297 279 313 minecraft:gray_concrete
setblock 297 279 314 minecraft:yellow_concrete
fill 298 279 278 298 279 280 minecraft:gray_concrete
setblock 298 279 281 minecraft:yellow_concrete
fill 298 279 282 298 279 284 minecraft:gray_concrete
fill 298 279 285 313 279 287 minecraft:iron_block
fill 298 279 288 298 279 290 minecraft:black_concrete
fill 298 279 291 300 279 298 minecraft:iron_block
fill 298 279 300 299 279 300 minecraft:redstone_block
fill 298 279 302 299 279 302 minecraft:redstone_block
fill 298 279 308 298 279 310 minecraft:gray_concrete
setblock 298 279 311 minecraft:yellow_concrete
fill 298 279 312 298 279 314 minecraft:gray_concrete
setblock 299 279 278 minecraft:yellow_concrete
fill 299 279 279 299 279 283 minecraft:gray_concrete
setblock 299 279 284 minecraft:yellow_concrete
fill 299 279 288 299 279 290 minecraft:iron_block
fill 299 279 299 301 279 299 minecraft:iron_block
setblock 299 279 301 minecraft:redstone_block
fill 299 279 303 307 279 303 minecraft:iron_block
setblock 299 279 308 minecraft:yellow_concrete
fill 299 279 309 299 279 313 minecraft:gray_concrete
setblock 299 279 314 minecraft:yellow_concrete
fill 300 279 278 300 279 280 minecraft:gray_concrete
setblock 300 279 281 minecraft:yellow_concrete
fill 300 279 282 300 279 284 minecraft:gray_concrete
fill 300 279 288 300 279 290 minecraft:black_concrete
fill 300 279 300 301 279 302 minecraft:iron_block
fill 300 279 308 300 279 310 minecraft:gray_concrete
setblock 300 279 311 minecraft:yellow_concrete
fill 300 279 312 300 279 314 minecraft:gray_concrete
setblock 301 279 278 minecraft:yellow_concrete
fill 301 279 279 301 279 283 minecraft:gray_concrete
setblock 301 279 284 minecraft:yellow_concrete
fill 301 279 288 301 279 295 minecraft:iron_block
fill 301 279 296 301 279 298 minecraft:lime_concrete
setblock 301 279 308 minecraft:yellow_concrete
fill 301 279 309 301 279 313 minecraft:gray_concrete
setblock 301 279 314 minecraft:yellow_concrete
fill 302 279 278 302 279 280 minecraft:gray_concrete
setblock 302 279 281 minecraft:yellow_concrete
fill 302 279 282 302 279 284 minecraft:gray_concrete
fill 302 279 288 302 279 290 minecraft:black_concrete
fill 302 279 291 303 279 293 minecraft:iron_block
fill 302 279 294 302 279 296 minecraft:lime_concrete
fill 302 279 298 302 279 300 minecraft:lime_concrete
fill 302 279 301 303 279 302 minecraft:iron_block
fill 302 279 308 302 279 310 minecraft:gray_concrete
setblock 302 279 311 minecraft:yellow_concrete
fill 302 279 312 302 279 314 minecraft:gray_concrete
setblock 303 279 278 minecraft:yellow_concrete
fill 303 279 279 303 279 283 minecraft:gray_concrete
setblock 303 279 284 minecraft:yellow_concrete
fill 303 279 288 303 279 290 minecraft:iron_block
fill 303 279 294 304 279 294 minecraft:lime_concrete
fill 303 279 300 304 279 300 minecraft:lime_concrete
setblock 303 279 308 minecraft:yellow_concrete
fill 303 279 309 303 279 313 minecraft:gray_concrete
setblock 303 279 314 minecraft:yellow_concrete
fill 304 279 278 304 279 280 minecraft:gray_concrete
setblock 304 279 281 minecraft:yellow_concrete
fill 304 279 282 304 279 284 minecraft:gray_concrete
fill 304 279 288 304 279 290 minecraft:black_concrete
fill 304 279 291 313 279 292 minecraft:iron_block
fill 304 279 293 306 279 293 minecraft:lime_concrete
fill 304 279 301 306 279 301 minecraft:lime_concrete
fill 304 279 302 306 279 302 minecraft:iron_block
fill 304 279 308 304 279 310 minecraft:gray_concrete
setblock 304 279 311 minecraft:yellow_concrete
fill 304 279 312 304 279 314 minecraft:gray_concrete
setblock 305 279 278 minecraft:yellow_concrete
fill 305 279 279 305 279 283 minecraft:gray_concrete
setblock 305 279 284 minecraft:yellow_concrete
fill 305 279 288 305 279 290 minecraft:iron_block
setblock 305 279 308 minecraft:yellow_concrete
fill 305 279 309 305 279 313 minecraft:gray_concrete
setblock 305 279 314 minecraft:yellow_concrete
fill 306 279 278 306 279 280 minecraft:gray_concrete
setblock 306 279 281 minecraft:yellow_concrete
fill 306 279 282 306 279 284 minecraft:gray_concrete
fill 306 279 288 306 279 290 minecraft:black_concrete
fill 306 279 294 308 279 294 minecraft:lime_concrete
fill 306 279 300 308 279 300 minecraft:lime_concrete
fill 306 279 308 306 279 310 minecraft:gray_concrete
setblock 306 279 311 minecraft:yellow_concrete
fill 306 279 312 306 279 314 minecraft:gray_concrete
setblock 307 279 278 minecraft:yellow_concrete
fill 307 279 279 307 279 283 minecraft:gray_concrete
setblock 307 279 284 minecraft:yellow_concrete
fill 307 279 288 307 279 290 minecraft:iron_block
fill 307 279 293 313 279 293 minecraft:iron_block
fill 307 279 301 307 279 302 minecraft:redstone_block
setblock 307 279 308 minecraft:yellow_concrete
fill 307 279 309 307 279 313 minecraft:gray_concrete
setblock 307 279 314 minecraft:yellow_concrete
fill 308 279 278 308 279 280 minecraft:gray_concrete
setblock 308 279 281 minecraft:yellow_concrete
fill 308 279 282 308 279 284 minecraft:gray_concrete
fill 308 279 288 308 279 290 minecraft:black_concrete
fill 308 279 295 308 279 296 minecraft:lime_concrete
fill 308 279 298 308 279 299 minecraft:lime_concrete
fill 308 279 301 310 279 301 minecraft:white_concrete
fill 308 279 302 308 279 303 minecraft:redstone_block
fill 308 279 308 308 279 310 minecraft:gray_concrete
setblock 308 279 311 minecraft:yellow_concrete
fill 308 279 312 308 279 314 minecraft:gray_concrete
setblock 309 279 278 minecraft:yellow_concrete
fill 309 279 279 309 279 283 minecraft:gray_concrete
setblock 309 279 284 minecraft:yellow_concrete
fill 309 279 288 313 279 290 minecraft:iron_block
fill 309 279 294 313 279 295 minecraft:iron_block
fill 309 279 296 309 279 298 minecraft:lime_concrete
fill 309 279 299 310 279 299 minecraft:redstone_block
setblock 309 279 300 minecraft:white_concrete
setblock 309 279 302 minecraft:white_concrete
fill 309 279 303 310 279 303 minecraft:redstone_block
setblock 309 279 308 minecraft:yellow_concrete
fill 309 279 309 309 279 313 minecraft:gray_concrete
setblock 309 279 314 minecraft:yellow_concrete
fill 310 279 278 310 279 280 minecraft:gray_concrete
setblock 310 279 281 minecraft:yellow_concrete
fill 310 279 282 310 279 284 minecraft:gray_concrete
fill 310 279 296 313 279 298 minecraft:iron_block
fill 310 279 300 311 279 300 minecraft:redstone_block
fill 310 279 302 311 279 302 minecraft:redstone_block
fill 310 279 308 310 279 310 minecraft:gray_concrete
setblock 310 279 311 minecraft:yellow_concrete
fill 310 279 312 310 279 314 minecraft:gray_concrete
setblock 311 279 278 minecraft:yellow_concrete
fill 311 279 279 311 279 283 minecraft:gray_concrete
setblock 311 279 284 minecraft:yellow_concrete
fill 311 279 299 313 279 299 minecraft:iron_block
setblock 311 279 301 minecraft:redstone_block
fill 311 279 303 313 279 303 minecraft:iron_block
setblock 311 279 308 minecraft:yellow_concrete
fill 311 279 309 311 279 313 minecraft:gray_concrete
setblock 311 279 314 minecraft:yellow_concrete
fill 312 279 278 312 279 280 minecraft:gray_concrete
setblock 312 279 281 minecraft:yellow_concrete
fill 312 279 282 312 279 284 minecraft:gray_concrete
fill 312 279 300 313 279 302 minecraft:iron_block
fill 312 279 308 312 279 310 minecraft:gray_concrete
setblock 312 279 311 minecraft:yellow_concrete
fill 312 279 312 312 279 314 minecraft:gray_concrete
setblock 313 279 278 minecraft:yellow_concrete
fill 313 279 279 313 279 283 minecraft:gray_concrete
setblock 313 279 284 minecraft:yellow_concrete
setblock 313 279 308 minecraft:yellow_concrete
fill 313 279 309 313 279 313 minecraft:gray_concrete
setblock 313 279 314 minecraft:yellow_concrete
fill 314 279 278 314 279 280 minecraft:gray_concrete
setblock 314 279 281 minecraft:yellow_concrete
fill 314 279 282 314 279 286 minecraft:gray_concrete
setblock 314 279 287 minecraft:yellow_concrete
fill 314 279 288 314 279 292 minecraft:gray_concrete
setblock 314 279 293 minecraft:yellow_concrete
fill 314 279 294 314 279 298 minecraft:gray_concrete
setblock 314 279 299 minecraft:yellow_concrete
fill 314 279 300 314 279 304 minecraft:gray_concrete
setblock 314 279 305 minecraft:yellow_concrete
fill 314 279 306 323 279 306 minecraft:gray_concrete
fill 314 279 308 314 279 310 minecraft:gray_concrete
setblock 314 279 311 minecraft:yellow_concrete
fill 314 279 312 314 279 314 minecraft:gray_concrete
setblock 315 279 278 minecraft:yellow_concrete
fill 315 279 279 315 279 283 minecraft:gray_concrete
setblock 315 279 284 minecraft:yellow_concrete
fill 315 279 285 315 279 289 minecraft:gray_concrete
setblock 315 279 290 minecraft:yellow_concrete
fill 315 279 291 315 279 295 minecraft:gray_concrete
setblock 315 279 296 minecraft:yellow_concrete
fill 315 279 297 315 279 301 minecraft:gray_concrete
setblock 315 279 302 minecraft:yellow_concrete
fill 315 279 303 315 279 305 minecraft:gray_concrete
setblock 315 279 308 minecraft:yellow_concrete
fill 315 279 309 315 279 313 minecraft:gray_concrete
setblock 315 279 314 minecraft:yellow_concrete
fill 316 279 278 316 279 280 minecraft:gray_concrete
setblock 316 279 281 minecraft:yellow_concrete
fill 316 279 282 316 279 286 minecraft:gray_concrete
setblock 316 279 287 minecraft:yellow_concrete
fill 316 279 288 316 279 292 minecraft:gray_concrete
setblock 316 279 293 minecraft:yellow_concrete
fill 316 279 294 316 279 298 minecraft:gray_concrete
setblock 316 279 299 minecraft:yellow_concrete
fill 316 279 300 316 279 304 minecraft:gray_concrete
setblock 316 279 305 minecraft:yellow_concrete
fill 316 279 308 316 279 310 minecraft:gray_concrete
setblock 316 279 311 minecraft:yellow_concrete
fill 316 279 312 316 279 314 minecraft:gray_concrete
setblock 317 279 278 minecraft:yellow_concrete
fill 317 279 279 317 279 283 minecraft:gray_concrete
setblock 317 279 284 minecraft:yellow_concrete
fill 317 279 285 317 279 289 minecraft:gray_concrete
setblock 317 279 290 minecraft:yellow_concrete
fill 317 279 291 317 279 295 minecraft:gray_concrete
setblock 317 279 296 minecraft:yellow_concrete
fill 317 279 297 317 279 301 minecraft:gray_concrete
setblock 317 279 302 minecraft:yellow_concrete
fill 317 279 303 317 279 305 minecraft:gray_concrete
setblock 317 279 308 minecraft:yellow_concrete
fill 317 279 309 317 279 313 minecraft:gray_concrete
setblock 317 279 314 minecraft:yellow_concrete
fill 318 279 278 318 279 280 minecraft:gray_concrete
setblock 318 279 281 minecraft:yellow_concrete
fill 318 279 282 318 279 286 minecraft:gray_concrete
setblock 318 279 287 minecraft:yellow_concrete
fill 318 279 288 318 279 292 minecraft:gray_concrete
setblock 318 279 293 minecraft:yellow_concrete
fill 318 279 294 318 279 298 minecraft:gray_concrete
setblock 318 279 299 minecraft:yellow_concrete
fill 318 279 300 318 279 304 minecraft:gray_concrete
setblock 318 279 305 minecraft:yellow_concrete
fill 318 279 308 318 279 310 minecraft:gray_concrete
setblock 318 279 311 minecraft:yellow_concrete
fill 318 279 312 318 279 314 minecraft:gray_concrete
setblock 319 279 278 minecraft:yellow_concrete
fill 319 279 279 319 279 283 minecraft:gray_concrete
setblock 319 279 284 minecraft:yellow_concrete
fill 319 279 285 319 279 289 minecraft:gray_concrete
setblock 319 279 290 minecraft:yellow_concrete
fill 319 279 291 319 279 295 minecraft:gray_concrete
setblock 319 279 296 minecraft:yellow_concrete
fill 319 279 297 319 279 301 minecraft:gray_concrete
setblock 319 279 302 minecraft:yellow_concrete
fill 319 279 303 319 279 305 minecraft:gray_concrete
setblock 319 279 308 minecraft:yellow_concrete
fill 319 279 309 319 279 313 minecraft:gray_concrete
setblock 319 279 314 minecraft:yellow_concrete
fill 320 279 278 320 279 280 minecraft:gray_concrete
setblock 320 279 281 minecraft:yellow_concrete
fill 320 279 282 320 279 286 minecraft:gray_concrete
setblock 320 279 287 minecraft:yellow_concrete
fill 320 279 288 320 279 292 minecraft:gray_concrete
setblock 320 279 293 minecraft:yellow_concrete
fill 320 279 294 320 279 298 minecraft:gray_concrete
setblock 320 279 299 minecraft:yellow_concrete
fill 320 279 300 320 279 304 minecraft:gray_concrete
setblock 320 279 305 minecraft:yellow_concrete
fill 320 279 308 320 279 310 minecraft:gray_concrete
setblock 320 279 311 minecraft:yellow_concrete
fill 320 279 312 320 279 314 minecraft:gray_concrete
setblock 321 279 278 minecraft:yellow_concrete
fill 321 279 279 321 279 283 minecraft:gray_concrete
setblock 321 279 284 minecraft:yellow_concrete
fill 321 279 285 321 279 289 minecraft:gray_concrete
setblock 321 279 290 minecraft:yellow_concrete
fill 321 279 291 321 279 295 minecraft:gray_concrete
setblock 321 279 296 minecraft:yellow_concrete
fill 321 279 297 321 279 301 minecraft:gray_concrete
setblock 321 279 302 minecraft:yellow_concrete
fill 321 279 303 321 279 305 minecraft:gray_concrete
setblock 321 279 308 minecraft:yellow_concrete
fill 321 279 309 321 279 313 minecraft:gray_concrete
setblock 321 279 314 minecraft:yellow_concrete
fill 322 279 278 322 279 280 minecraft:gray_concrete
setblock 322 279 281 minecraft:yellow_concrete
fill 322 279 282 322 279 286 minecraft:gray_concrete
setblock 322 279 287 minecraft:yellow_concrete
fill 322 279 288 322 279 292 minecraft:gray_concrete
setblock 322 279 293 minecraft:yellow_concrete
fill 322 279 294 322 279 298 minecraft:gray_concrete
setblock 322 279 299 minecraft:yellow_concrete
fill 322 279 300 322 279 304 minecraft:gray_concrete
setblock 322 279 305 minecraft:yellow_concrete
fill 322 279 308 322 279 310 minecraft:gray_concrete
setblock 322 279 311 minecraft:yellow_concrete
fill 322 279 312 322 279 314 minecraft:gray_concrete
setblock 323 279 278 minecraft:yellow_concrete
fill 323 279 279 323 279 283 minecraft:gray_concrete
setblock 323 279 284 minecraft:yellow_concrete
fill 323 279 285 323 279 289 minecraft:gray_concrete
setblock 323 279 290 minecraft:yellow_concrete
fill 323 279 291 323 279 295 minecraft:gray_concrete
setblock 323 279 296 minecraft:yellow_concrete
fill 323 279 297 323 279 301 minecraft:gray_concrete
setblock 323 279 302 minecraft:yellow_concrete
fill 323 279 303 323 279 305 minecraft:gray_concrete
setblock 323 279 308 minecraft:yellow_concrete
fill 323 279 309 323 279 313 minecraft:gray_concrete
setblock 323 279 314 minecraft:yellow_concrete
fill 324 279 276 324 279 316 minecraft:light_gray_concrete
fill 283 280 317 321 282 317 minecraft:light_gray_concrete
setblock 285 280 278 minecraft:light[level=15]
setblock 285 280 286 minecraft:light[level=15]
setblock 285 280 294 minecraft:light[level=15]
setblock 285 280 302 minecraft:light[level=15]
setblock 285 280 310 minecraft:light[level=15]
setblock 293 280 278 minecraft:light[level=15]
setblock 293 280 286 minecraft:light[level=15]
setblock 293 280 294 minecraft:light[level=15]
setblock 293 280 302 minecraft:light[level=15]
setblock 293 280 310 minecraft:light[level=15]
setblock 301 280 278 minecraft:light[level=15]
setblock 301 280 286 minecraft:light[level=15]
setblock 301 280 294 minecraft:light[level=15]
setblock 301 280 302 minecraft:light[level=15]
setblock 301 280 310 minecraft:light[level=15]
setblock 309 280 278 minecraft:light[level=15]
setblock 309 280 286 minecraft:light[level=15]
setblock 309 280 294 minecraft:light[level=15]
setblock 309 280 302 minecraft:light[level=15]
setblock 309 280 310 minecraft:light[level=15]
setblock 317 280 278 minecraft:light[level=15]
setblock 317 280 286 minecraft:light[level=15]
setblock 317 280 294 minecraft:light[level=15]
setblock 317 280 302 minecraft:light[level=15]
setblock 317 280 310 minecraft:light[level=15]
setblock 322 280 317 minecraft:redstone_block
fill 323 280 317 324 304 317 minecraft:light_gray_concrete
fill 324 280 276 324 282 283 minecraft:light_gray_concrete
setblock 324 280 284 minecraft:redstone_block
fill 324 280 285 324 282 306 minecraft:light_gray_concrete
setblock 324 280 307 minecraft:sea_lantern
fill 324 280 308 324 282 316 minecraft:light_gray_concrete
fill 283 281 275 299 282 275 minecraft:light_gray_concrete
setblock 300 281 275 minecraft:redstone_block
fill 301 281 275 324 282 275 minecraft:light_gray_concrete
fill 322 281 317 322 304 317 minecraft:light_gray_concrete
fill 324 281 284 324 304 284 minecraft:light_gray_concrete
fill 324 281 307 324 282 307 minecraft:light_gray_concrete
setblock 285 282 278 minecraft:light[level=12]
setblock 285 282 285 minecraft:light[level=12]
setblock 285 282 292 minecraft:light[level=12]
setblock 285 282 299 minecraft:light[level=12]
setblock 285 282 306 minecraft:light[level=12]
setblock 285 282 313 minecraft:light[level=12]
setblock 292 282 278 minecraft:light[level=12]
setblock 292 282 285 minecraft:light[level=12]
setblock 292 282 292 minecraft:light[level=12]
setblock 292 282 299 minecraft:light[level=12]
setblock 292 282 306 minecraft:light[level=12]
setblock 292 282 313 minecraft:light[level=12]
setblock 299 282 278 minecraft:light[level=12]
setblock 299 282 285 minecraft:light[level=12]
setblock 299 282 292 minecraft:light[level=12]
setblock 299 282 299 minecraft:light[level=12]
setblock 299 282 306 minecraft:light[level=12]
setblock 299 282 313 minecraft:light[level=12]
fill 300 282 275 300 304 275 minecraft:light_gray_concrete
setblock 306 282 278 minecraft:light[level=12]
setblock 306 282 285 minecraft:light[level=12]
setblock 306 282 292 minecraft:light[level=12]
setblock 306 282 299 minecraft:light[level=12]
setblock 306 282 306 minecraft:light[level=12]
setblock 306 282 313 minecraft:light[level=12]
setblock 313 282 278 minecraft:light[level=12]
setblock 313 282 285 minecraft:light[level=12]
setblock 313 282 292 minecraft:light[level=12]
setblock 313 282 299 minecraft:light[level=12]
setblock 313 282 306 minecraft:light[level=12]
setblock 313 282 313 minecraft:light[level=12]
setblock 320 282 278 minecraft:light[level=12]
setblock 320 282 285 minecraft:light[level=12]
setblock 320 282 292 minecraft:light[level=12]
setblock 320 282 299 minecraft:light[level=12]
setblock 320 282 306 minecraft:light[level=12]
setblock 320 282 313 minecraft:light[level=12]
fill 282 283 275 282 304 280 minecraft:light_gray_concrete
fill 282 283 281 282 283 284 minecraft:pearlescent_froglight
fill 282 283 285 282 287 290 minecraft:light_gray_concrete
fill 282 283 291 282 283 294 minecraft:pearlescent_froglight
fill 282 283 295 282 304 300 minecraft:light_gray_concrete
fill 282 283 301 282 283 304 minecraft:pearlescent_froglight
fill 282 283 305 282 283 310 minecraft:light_gray_concrete
fill 282 283 311 282 283 314 minecraft:pearlescent_froglight
fill 282 283 315 282 284 317 minecraft:light_gray_concrete
fill 283 283 275 284 285 275 minecraft:light_gray_concrete
fill 283 283 276 289 285 281 minecraft:iron_block
fill 283 283 287 283 300 287 minecraft:iron_block
fill 283 283 297 283 300 297 minecraft:iron_block
fill 283 283 307 283 300 307 minecraft:iron_block
fill 283 283 317 285 304 317 minecraft:light_gray_concrete
fill 284 283 286 286 300 286 minecraft:iron_block
fill 284 283 316 284 300 316 minecraft:iron_block
fill 285 283 275 288 283 275 minecraft:pearlescent_froglight
fill 285 283 285 285 300 285 minecraft:iron_block
fill 285 283 287 285 300 287 minecraft:iron_block
fill 286 283 317 289 283 317 minecraft:pearlescent_froglight
fill 288 283 282 288 288 282 minecraft:iron_block
fill 289 283 275 294 286 275 minecraft:light_gray_concrete
fill 290 283 276 290 300 276 minecraft:iron_block
fill 290 283 317 295 290 317 minecraft:light_gray_concrete
fill 292 283 278 294 300 278 minecraft:iron_block
fill 293 283 277 293 300 277 minecraft:iron_block
fill 293 283 279 293 300 279 minecraft:iron_block
fill 294 283 316 294 300 316 minecraft:iron_block
fill 295 283 275 298 283 275 minecraft:pearlescent_froglight
fill 296 283 317 299 283 317 minecraft:pearlescent_froglight
fill 299 283 275 299 304 275 minecraft:light_gray_concrete
fill 300 283 276 300 300 276 minecraft:iron_block
fill 300 283 317 305 304 317 minecraft:light_gray_concrete
fill 301 283 275 304 288 275 minecraft:light_gray_concrete
fill 304 283 316 304 300 316 minecraft:iron_block
fill 305 283 275 308 283 275 minecraft:pearlescent_froglight
fill 306 283 309 312 285 316 minecraft:iron_block
fill 306 283 317 309 283 317 minecraft:pearlescent_froglight
fill 309 283 275 314 284 275 minecraft:light_gray_concrete
fill 310 283 276 310 300 276 minecraft:iron_block
fill 310 283 317 315 304 317 minecraft:light_gray_concrete
fill 313 283 276 319 285 284 minecraft:iron_block
fill 314 283 316 314 300 316 minecraft:iron_block
fill 315 283 275 318 283 275 minecraft:pearlescent_froglight
fill 316 283 290 316 285 290 minecraft:iron_block
fill 316 283 317 319 283 317 minecraft:pearlescent_froglight
fill 319 283 275 324 304 275 minecraft:light_gray_concrete
fill 320 283 276 320 300 276 minecraft:iron_block
fill 320 283 279 321 283 279 minecraft:gray_concrete
fill 320 283 280 320 300 282 minecraft:iron_block
setblock 320 283 283 minecraft:gray_concrete
fill 320 283 317 321 304 317 minecraft:light_gray_concrete
fill 321 283 280 321 283 282 minecraft:gray_concrete
fill 323 283 283 323 300 283 minecraft:iron_block
fill 323 283 293 323 300 293 minecraft:iron_block
fill 323 283 303 323 300 303 minecraft:iron_block
fill 323 283 313 323 300 313 minecraft:iron_block
fill 324 283 276 324 283 279 minecraft:pearlescent_froglight
fill 324 283 280 324 288 283 minecraft:light_gray_concrete
fill 324 283 285 324 297 285 minecraft:light_gray_concrete
fill 324 283 286 324 283 289 minecraft:pearlescent_froglight
fill 324 283 290 324 297 295 minecraft:light_gray_concrete
fill 324 283 296 324 283 299 minecraft:pearlescent_froglight
fill 324 283 300 324 304 305 minecraft:light_gray_concrete
fill 324 283 306 324 283 309 minecraft:pearlescent_froglight
fill 324 283 310 324 288 315 minecraft:light_gray_concrete
setblock 324 283 316 minecraft:pearlescent_froglight
fill 282 284 281 282 291 284 minecraft:light_gray_concrete
fill 282 284 291 282 291 294 minecraft:light_gray_concrete
fill 282 284 301 282 284 307 minecraft:light_gray_concrete
setblock 282 284 308 minecraft:redstone_block
fill 282 284 309 282 291 314 minecraft:light_gray_concrete
fill 285 284 275 288 285 275 minecraft:light_gray_concrete
fill 286 284 317 289 291 317 minecraft:light_gray_concrete
fill 294 284 313 294 285 315 minecraft:iron_block
fill 295 284 275 298 287 275 minecraft:light_gray_concrete
fill 296 284 317 299 290 317 minecraft:light_gray_concrete
fill 305 284 275 308 291 275 minecraft:light_gray_concrete
fill 306 284 317 309 291 317 minecraft:light_gray_concrete
fill 315 284 275 318 291 275 minecraft:light_gray_concrete
fill 316 284 317 319 291 317 minecraft:light_gray_concrete
fill 324 284 276 324 291 279 minecraft:light_gray_concrete
fill 324 284 286 324 291 289 minecraft:light_gray_concrete
fill 324 284 296 324 291 299 minecraft:light_gray_concrete
fill 324 284 306 324 291 309 minecraft:light_gray_concrete
fill 324 284 316 324 291 316 minecraft:light_gray_concrete
fill 282 285 301 282 291 302 minecraft:light_gray_concrete
setblock 282 285 303 minecraft:redstone_block
fill 282 285 304 282 291 308 minecraft:light_gray_concrete
setblock 282 285 315 minecraft:sea_lantern
fill 282 285 316 282 304 317 minecraft:light_gray_concrete
setblock 284 285 285 minecraft:iron_block
setblock 284 285 287 minecraft:iron_block
setblock 286 285 285 minecraft:iron_block
setblock 286 285 287 minecraft:iron_block
setblock 292 285 277 minecraft:iron_block
setblock 292 285 279 minecraft:iron_block
setblock 294 285 277 minecraft:iron_block
setblock 294 285 279 minecraft:iron_block
fill 309 285 275 312 304 275 minecraft:light_gray_concrete
setblock 313 285 275 minecraft:sea_lantern
fill 314 285 275 314 304 275 minecraft:light_gray_concrete
fill 282 286 303 282 291 303 minecraft:light_gray_concrete
fill 282 286 315 282 304 315 minecraft:light_gray_concrete
fill 283 286 275 283 304 275 minecraft:light_gray_concrete
setblock 283 286 276 minecraft:pearlescent_froglight
fill 283 286 277 283 300 277 minecraft:iron_block
setblock 283 286 278 minecraft:pearlescent_froglight
fill 283 286 279 283 297 279 minecraft:iron_block
setblock 283 286 280 minecraft:pearlescent_froglight
fill 283 286 281 283 297 281 minecraft:iron_block
fill 283 286 286 283 287 286 minecraft:iron_block
setblock 284 286 275 minecraft:pearlescent_froglight
fill 284 286 276 284 297 276 minecraft:iron_block
setblock 284 286 277 minecraft:pearlescent_froglight
fill 284 286 278 284 297 278 minecraft:iron_block
setblock 284 286 279 minecraft:pearlescent_froglight
fill 284 286 280 284 297 280 minecraft:iron_block
setblock 284 286 281 minecraft:pearlescent_froglight
fill 285 286 275 285 291 275 minecraft:light_gray_concrete
setblock 285 286 276 minecraft:pearlescent_froglight
fill 285 286 277 285 297 277 minecraft:iron_block
setblock 285 286 278 minecraft:pearlescent_froglight
fill 285 286 279 285 297 279 minecraft:iron_block
setblock 285 286 280 minecraft:pearlescent_froglight
fill 285 286 281 285 297 281 minecraft:iron_block
setblock 286 286 275 minecraft:pearlescent_froglight
fill 286 286 276 286 297 276 minecraft:iron_block
setblock 286 286 277 minecraft:pearlescent_froglight
fill 286 286 278 286 297 278 minecraft:iron_block
setblock 286 286 279 minecraft:pearlescent_froglight
fill 286 286 280 286 297 280 minecraft:iron_block
setblock 286 286 281 minecraft:pearlescent_froglight
fill 287 286 275 287 291 275 minecraft:light_gray_concrete
setblock 287 286 276 minecraft:pearlescent_froglight
fill 287 286 277 287 297 277 minecraft:iron_block
setblock 287 286 278 minecraft:pearlescent_froglight
fill 287 286 279 287 297 279 minecraft:iron_block
setblock 287 286 280 minecraft:pearlescent_froglight
fill 287 286 281 287 297 281 minecraft:iron_block
setblock 288 286 275 minecraft:pearlescent_froglight
fill 288 286 276 288 297 276 minecraft:iron_block
setblock 288 286 277 minecraft:pearlescent_froglight
fill 288 286 278 288 297 278 minecraft:iron_block
setblock 288 286 279 minecraft:pearlescent_froglight
fill 288 286 280 288 297 280 minecraft:iron_block
setblock 288 286 281 minecraft:pearlescent_froglight
setblock 289 286 276 minecraft:pearlescent_froglight
fill 289 286 277 289 297 277 minecraft:iron_block
setblock 289 286 278 minecraft:pearlescent_froglight
fill 289 286 279 289 297 279 minecraft:iron_block
setblock 289 286 280 minecraft:pearlescent_froglight
fill 289 286 281 289 297 281 minecraft:iron_block
setblock 306 286 309 minecraft:pearlescent_froglight
fill 306 286 310 306 300 310 minecraft:iron_block
setblock 306 286 311 minecraft:pearlescent_froglight
fill 306 286 312 306 300 312 minecraft:iron_block
setblock 306 286 313 minecraft:pearlescent_froglight
fill 306 286 314 306 300 314 minecraft:iron_block
setblock 306 286 315 minecraft:pearlescent_froglight
fill 306 286 316 306 300 316 minecraft:iron_block
fill 307 286 309 307 300 309 minecraft:iron_block
setblock 307 286 310 minecraft:pearlescent_froglight
fill 307 286 311 307 300 311 minecraft:iron_block
setblock 307 286 312 minecraft:pearlescent_froglight
fill 307 286 313 307 300 313 minecraft:iron_block
setblock 307 286 314 minecraft:pearlescent_froglight
fill 307 286 315 307 300 315 minecraft:iron_block
setblock 307 286 316 minecraft:pearlescent_froglight
setblock 308 286 309 minecraft:pearlescent_froglight
fill 308 286 310 308 300 310 minecraft:iron_block
setblock 308 286 311 minecraft:pearlescent_froglight
fill 308 286 312 308 300 312 minecraft:iron_block
setblock 308 286 313 minecraft:pearlescent_froglight
fill 308 286 314 308 300 314 minecraft:iron_block
setblock 308 286 315 minecraft:pearlescent_froglight
fill 308 286 316 308 300 316 minecraft:iron_block
fill 309 286 309 309 300 309 minecraft:iron_block
setblock 309 286 310 minecraft:pearlescent_froglight
fill 309 286 311 309 300 311 minecraft:iron_block
setblock 309 286 312 minecraft:pearlescent_froglight
fill 309 286 313 309 300 313 minecraft:iron_block
setblock 309 286 314 minecraft:pearlescent_froglight
fill 309 286 315 309 300 315 minecraft:iron_block
setblock 309 286 316 minecraft:pearlescent_froglight
setblock 310 286 309 minecraft:pearlescent_froglight
fill 310 286 310 310 300 310 minecraft:iron_block
setblock 310 286 311 minecraft:pearlescent_froglight
fill 310 286 312 310 300 312 minecraft:iron_block
setblock 310 286 313 minecraft:pearlescent_froglight
fill 310 286 314 310 300 314 minecraft:iron_block
setblock 310 286 315 minecraft:pearlescent_froglight
fill 310 286 316 310 300 316 minecraft:iron_block
fill 311 286 309 311 300 309 minecraft:iron_block
setblock 311 286 310 minecraft:pearlescent_froglight
fill 311 286 311 311 300 311 minecraft:iron_block
setblock 311 286 312 minecraft:pearlescent_froglight
fill 311 286 313 311 300 313 minecraft:iron_block
setblock 311 286 314 minecraft:pearlescent_froglight
fill 311 286 315 311 300 315 minecraft:iron_block
setblock 311 286 316 minecraft:pearlescent_froglight
setblock 312 286 309 minecraft:pearlescent_froglight
fill 312 286 310 312 300 310 minecraft:iron_block
setblock 312 286 311 minecraft:pearlescent_froglight
fill 312 286 312 312 300 312 minecraft:iron_block
setblock 312 286 313 minecraft:pearlescent_froglight
fill 312 286 314 312 300 314 minecraft:iron_block
setblock 312 286 315 minecraft:pearlescent_froglight
fill 312 286 316 312 300 316 minecraft:iron_block
fill 313 286 275 313 304 275 minecraft:light_gray_concrete
setblock 313 286 276 minecraft:pearlescent_froglight
fill 313 286 277 313 297 277 minecraft:iron_block
setblock 313 286 278 minecraft:pearlescent_froglight
fill 313 286 279 313 297 279 minecraft:iron_block
setblock 313 286 280 minecraft:pearlescent_froglight
fill 313 286 281 313 297 281 minecraft:iron_block
setblock 313 286 282 minecraft:pearlescent_froglight
fill 313 286 283 313 297 283 minecraft:iron_block
setblock 313 286 284 minecraft:pearlescent_froglight
fill 314 286 276 314 297 276 minecraft:iron_block
setblock 314 286 277 minecraft:pearlescent_froglight
fill 314 286 278 314 297 278 minecraft:iron_block
setblock 314 286 279 minecraft:pearlescent_froglight
fill 314 286 280 314 297 280 minecraft:iron_block
setblock 314 286 281 minecraft:pearlescent_froglight
fill 314 286 282 314 297 282 minecraft:iron_block
setblock 314 286 283 minecraft:pearlescent_froglight
fill 314 286 284 314 297 284 minecraft:iron_block
setblock 315 286 276 minecraft:pearlescent_froglight
fill 315 286 277 315 297 277 minecraft:iron_block
setblock 315 286 278 minecraft:pearlescent_froglight
fill 315 286 279 315 297 279 minecraft:iron_block
setblock 315 286 280 minecraft:pearlescent_froglight
fill 315 286 281 315 297 281 minecraft:iron_block
setblock 315 286 282 minecraft:pearlescent_froglight
fill 315 286 283 315 297 283 minecraft:iron_block
setblock 315 286 284 minecraft:pearlescent_froglight
fill 316 286 276 316 297 276 minecraft:iron_block
setblock 316 286 277 minecraft:pearlescent_froglight
fill 316 286 278 316 297 278 minecraft:iron_block
setblock 316 286 279 minecraft:pearlescent_froglight
fill 316 286 280 316 297 280 minecraft:iron_block
setblock 316 286 281 minecraft:pearlescent_froglight
fill 316 286 282 316 297 282 minecraft:iron_block
setblock 316 286 283 minecraft:pearlescent_froglight
fill 316 286 284 316 297 284 minecraft:iron_block
setblock 317 286 276 minecraft:pearlescent_froglight
fill 317 286 277 317 297 277 minecraft:iron_block
setblock 317 286 278 minecraft:pearlescent_froglight
fill 317 286 279 317 297 279 minecraft:iron_block
setblock 317 286 280 minecraft:pearlescent_froglight
fill 317 286 281 317 297 281 minecraft:iron_block
setblock 317 286 282 minecraft:pearlescent_froglight
fill 317 286 283 317 297 283 minecraft:iron_block
setblock 317 286 284 minecraft:pearlescent_froglight
fill 318 286 276 318 297 276 minecraft:iron_block
setblock 318 286 277 minecraft:pearlescent_froglight
fill 318 286 278 318 297 278 minecraft:iron_block
setblock 318 286 279 minecraft:pearlescent_froglight
fill 318 286 280 318 300 280 minecraft:iron_block
setblock 318 286 281 minecraft:pearlescent_froglight
fill 318 286 282 318 300 282 minecraft:iron_block
setblock 318 286 283 minecraft:pearlescent_froglight
fill 318 286 284 318 297 284 minecraft:iron_block
setblock 319 286 276 minecraft:pearlescent_froglight
fill 319 286 277 319 297 277 minecraft:iron_block
setblock 319 286 278 minecraft:pearlescent_froglight
fill 319 286 279 319 300 279 minecraft:iron_block
setblock 319 286 280 minecraft:pearlescent_froglight
fill 319 286 281 319 300 281 minecraft:iron_block
setblock 319 286 282 minecraft:pearlescent_froglight
fill 319 286 283 319 297 283 minecraft:iron_block
setblock 319 286 284 minecraft:pearlescent_froglight
fill 283 287 276 283 288 276 minecraft:iron_block
fill 283 287 278 283 288 278 minecraft:iron_block
fill 283 287 280 283 288 280 minecraft:iron_block
fill 283 287 295 289 287 295 minecraft:gray_concrete
fill 284 287 275 284 288 275 minecraft:light_gray_concrete
fill 284 287 277 284 288 277 minecraft:iron_block
fill 284 287 279 284 288 279 minecraft:iron_block
fill 284 287 281 284 288 281 minecraft:iron_block
fill 285 287 276 285 288 276 minecraft:iron_block
fill 285 287 278 285 288 278 minecraft:iron_block
fill 285 287 280 285 288 280 minecraft:iron_block
fill 285 287 293 289 288 294 minecraft:gray_concrete
fill 285 287 296 289 288 297 minecraft:gray_concrete
fill 286 287 275 286 288 275 minecraft:light_gray_concrete
fill 286 287 277 286 288 277 minecraft:iron_block
fill 286 287 279 286 288 279 minecraft:iron_block
fill 286 287 281 286 288 281 minecraft:iron_block
fill 287 287 276 287 288 276 minecraft:iron_block
fill 287 287 278 287 288 278 minecraft:iron_block
fill 287 287 280 287 288 280 minecraft:iron_block
setblock 287 287 286 minecraft:pearlescent_froglight
fill 288 287 275 288 288 275 minecraft:light_gray_concrete
fill 288 287 277 288 288 277 minecraft:iron_block
fill 288 287 279 288 288 279 minecraft:iron_block
fill 288 287 281 288 288 281 minecraft:iron_block
setblock 289 287 275 minecraft:redstone_block
fill 289 287 276 289 288 276 minecraft:iron_block
fill 289 287 278 289 288 278 minecraft:iron_block
fill 289 287 280 289 288 280 minecraft:iron_block
fill 290 287 275 294 304 275 minecraft:light_gray_concrete
fill 306 287 309 306 288 309 minecraft:iron_block
fill 306 287 311 306 288 311 minecraft:iron_block
fill 306 287 313 306 288 313 minecraft:iron_block
fill 306 287 315 306 288 315 minecraft:iron_block
fill 307 287 310 307 288 310 minecraft:iron_block
fill 307 287 312 307 288 312 minecraft:iron_block
fill 307 287 314 307 288 314 minecraft:iron_block
fill 307 287 316 307 288 316 minecraft:iron_block
fill 308 287 309 308 288 309 minecraft:iron_block
fill 308 287 311 308 288 311 minecraft:iron_block
fill 308 287 313 308 288 313 minecraft:iron_block
fill 308 287 315 308 288 315 minecraft:iron_block
fill 309 287 310 309 288 310 minecraft:iron_block
fill 309 287 312 309 288 312 minecraft:iron_block
fill 309 287 314 309 288 314 minecraft:iron_block
fill 309 287 316 309 288 316 minecraft:iron_block
fill 310 287 309 310 288 309 minecraft:iron_block
fill 310 287 311 310 288 311 minecraft:iron_block
fill 310 287 313 310 288 313 minecraft:iron_block
fill 310 287 315 310 288 315 minecraft:iron_block
fill 311 287 310 311 288 310 minecraft:iron_block
fill 311 287 312 311 288 312 minecraft:iron_block
fill 311 287 314 311 288 314 minecraft:iron_block
fill 311 287 316 311 288 316 minecraft:iron_block
fill 312 287 309 312 288 309 minecraft:iron_block
fill 312 287 311 312 288 311 minecraft:iron_block
fill 312 287 313 312 288 313 minecraft:iron_block
fill 312 287 315 312 288 315 minecraft:iron_block
fill 313 287 276 313 288 276 minecraft:iron_block
fill 313 287 278 313 288 278 minecraft:iron_block
fill 313 287 280 313 288 280 minecraft:iron_block
fill 313 287 282 313 288 282 minecraft:iron_block
fill 313 287 284 313 288 284 minecraft:iron_block
fill 314 287 277 314 288 277 minecraft:iron_block
fill 314 287 279 314 288 279 minecraft:iron_block
fill 314 287 281 314 288 281 minecraft:iron_block
fill 314 287 283 314 288 283 minecraft:iron_block
fill 315 287 276 315 288 276 minecraft:iron_block
fill 315 287 278 315 288 278 minecraft:iron_block
fill 315 287 280 315 288 280 minecraft:iron_block
fill 315 287 282 315 288 282 minecraft:iron_block
fill 315 287 284 315 288 284 minecraft:iron_block
fill 316 287 277 316 288 277 minecraft:iron_block
fill 316 287 279 316 288 279 minecraft:iron_block
fill 316 287 281 316 288 281 minecraft:iron_block
fill 316 287 283 316 288 283 minecraft:iron_block
fill 317 287 276 317 288 276 minecraft:iron_block
fill 317 287 278 317 288 278 minecraft:iron_block
fill 317 287 280 317 288 280 minecraft:iron_block
fill 317 287 282 317 288 282 minecraft:iron_block
fill 317 287 284 317 288 284 minecraft:iron_block
fill 318 287 277 318 288 277 minecraft:iron_block
fill 318 287 279 318 288 279 minecraft:iron_block
fill 318 287 281 318 288 281 minecraft:iron_block
fill 318 287 283 318 288 283 minecraft:iron_block
fill 319 287 276 319 288 276 minecraft:iron_block
fill 319 287 278 319 288 278 minecraft:iron_block
fill 319 287 280 319 288 280 minecraft:iron_block
fill 319 287 282 319 288 282 minecraft:iron_block
fill 319 287 284 319 288 284 minecraft:iron_block
fill 282 288 285 282 304 286 minecraft:light_gray_concrete
setblock 282 288 287 minecraft:redstone_block
fill 282 288 288 282 304 290 minecraft:light_gray_concrete
fill 283 288 282 283 288 283 minecraft:iron_block
setblock 283 288 288 minecraft:iron_block
fill 283 288 290 283 288 293 minecraft:iron_block
setblock 283 288 298 minecraft:iron_block
fill 283 288 300 283 288 303 minecraft:iron_block
setblock 283 288 308 minecraft:iron_block
fill 283 288 310 283 288 313 minecraft:iron_block
setblock 285 288 292 minecraft:light[level=12]
fill 285 288 295 289 288 295 minecraft:gray_concrete
setblock 285 288 299 minecraft:light[level=12]
setblock 285 288 302 minecraft:light[level=15]
setblock 285 288 306 minecraft:light[level=12]
setblock 285 288 310 minecraft:light[level=15]
setblock 285 288 313 minecraft:light[level=12]
setblock 285 288 316 minecraft:iron_block
fill 287 288 316 290 288 316 minecraft:iron_block
fill 289 288 275 289 304 275 minecraft:light_gray_concrete
setblock 292 288 285 minecraft:light[level=12]
setblock 292 288 292 minecraft:light[level=12]
setblock 292 288 299 minecraft:light[level=12]
setblock 292 288 306 minecraft:light[level=12]
setblock 292 288 313 minecraft:light[level=12]
fill 293 288 276 297 288 276 minecraft:iron_block
setblock 293 288 286 minecraft:light[level=15]
setblock 293 288 294 minecraft:light[level=15]
setblock 293 288 302 minecraft:light[level=15]
setblock 293 288 310 minecraft:light[level=15]
fill 295 288 275 297 291 275 minecraft:light_gray_concrete
setblock 295 288 316 minecraft:iron_block
fill 297 288 316 300 288 316 minecraft:iron_block
setblock 298 288 275 minecraft:sea_lantern
setblock 299 288 276 minecraft:iron_block
setblock 299 288 278 minecraft:light[level=12]
setblock 299 288 285 minecraft:light[level=12]
setblock 299 288 292 minecraft:light[level=12]
setblock 299 288 299 minecraft:light[level=12]
setblock 299 288 306 minecraft:light[level=12]
setblock 299 288 313 minecraft:light[level=12]
setblock 301 288 278 minecraft:light[level=15]
setblock 301 288 286 minecraft:light[level=15]
setblock 301 288 294 minecraft:light[level=15]
setblock 301 288 302 minecraft:light[level=15]
setblock 301 288 310 minecraft:light[level=15]
fill 304 288 276 307 288 276 minecraft:iron_block
setblock 305 288 316 minecraft:iron_block
setblock 306 288 278 minecraft:light[level=12]
setblock 306 288 285 minecraft:light[level=12]
setblock 306 288 292 minecraft:light[level=12]
setblock 306 288 299 minecraft:light[level=12]
setblock 306 288 306 minecraft:light[level=12]
setblock 309 288 276 minecraft:iron_block
setblock 309 288 278 minecraft:light[level=15]
setblock 309 288 286 minecraft:light[level=15]
setblock 309 288 294 minecraft:light[level=15]
setblock 309 288 302 minecraft:light[level=15]
setblock 313 288 285 minecraft:light[level=12]
setblock 313 288 292 minecraft:light[level=12]
setblock 313 288 299 minecraft:light[level=12]
setblock 313 288 306 minecraft:light[level=12]
setblock 313 288 313 minecraft:light[level=12]
setblock 315 288 316 minecraft:iron_block
setblock 317 288 286 minecraft:light[level=15]
setblock 317 288 294 minecraft:light[level=15]
setblock 317 288 302 minecraft:light[level=15]
setblock 317 288 310 minecraft:light[level=15]
fill 317 288 316 320 288 316 minecraft:iron_block
setblock 320 288 278 minecraft:light[level=12]
setblock 320 288 285 minecraft:light[level=12]
setblock 320 288 292 minecraft:light[level=12]
setblock 320 288 299 minecraft:light[level=12]
setblock 320 288 306 minecraft:light[level=12]
setblock 320 288 313 minecraft:light[level=12]
fill 323 288 277 323 288 280 minecraft:iron_block
setblock 323 288 282 minecraft:iron_block
fill 323 288 287 323 288 290 minecraft:iron_block
setblock 323 288 292 minecraft:iron_block
fill 323 288 297 323 288 300 minecraft:iron_block
setblock 323 288 302 minecraft:iron_block
fill 323 288 307 323 288 310 minecraft:iron_block
setblock 323 288 312 minecraft:iron_block
fill 282 289 287 282 294 287 minecraft:light_gray_concrete
setblock 283 289 276 minecraft:pearlescent_froglight
setblock 283 289 278 minecraft:pearlescent_froglight
setblock 283 289 280 minecraft:pearlescent_froglight
setblock 284 289 275 minecraft:pearlescent_froglight
setblock 284 289 277 minecraft:pearlescent_froglight
setblock 284 289 279 minecraft:pearlescent_froglight
setblock 284 289 281 minecraft:pearlescent_froglight
setblock 285 289 276 minecraft:pearlescent_froglight
setblock 285 289 278 minecraft:pearlescent_froglight
setblock 285 289 280 minecraft:pearlescent_froglight
setblock 286 289 275 minecraft:pearlescent_froglight
setblock 286 289 277 minecraft:pearlescent_froglight
setblock 286 289 279 minecraft:pearlescent_froglight
setblock 286 289 281 minecraft:pearlescent_froglight
setblock 287 289 276 minecraft:pearlescent_froglight
setblock 287 289 278 minecraft:pearlescent_froglight
setblock 287 289 280 minecraft:pearlescent_froglight
setblock 288 289 275 minecraft:pearlescent_froglight
setblock 288 289 277 minecraft:pearlescent_froglight
setblock 288 289 279 minecraft:pearlescent_froglight
setblock 288 289 281 minecraft:pearlescent_froglight
setblock 289 289 276 minecraft:pearlescent_froglight
setblock 289 289 278 minecraft:pearlescent_froglight
setblock 289 289 280 minecraft:pearlescent_froglight
setblock 293 289 276 minecraft:iron_block
setblock 293 289 280 minecraft:pearlescent_froglight
fill 298 289 275 298 291 275 minecraft:light_gray_concrete
fill 301 289 275 301 304 275 minecraft:light_gray_concrete
setblock 302 289 275 minecraft:sea_lantern
fill 303 289 275 304 304 275 minecraft:light_gray_concrete
setblock 306 289 309 minecraft:pearlescent_froglight
setblock 306 289 311 minecraft:pearlescent_froglight
setblock 306 289 313 minecraft:pearlescent_froglight
setblock 306 289 315 minecraft:pearlescent_froglight
setblock 307 289 310 minecraft:pearlescent_froglight
setblock 307 289 312 minecraft:pearlescent_froglight
setblock 307 289 314 minecraft:pearlescent_froglight
setblock 307 289 316 minecraft:pearlescent_froglight
setblock 308 289 309 minecraft:pearlescent_froglight
setblock 308 289 311 minecraft:pearlescent_froglight
setblock 308 289 313 minecraft:pearlescent_froglight
setblock 308 289 315 minecraft:pearlescent_froglight
setblock 309 289 310 minecraft:pearlescent_froglight
setblock 309 289 312 minecraft:pearlescent_froglight
setblock 309 289 314 minecraft:pearlescent_froglight
setblock 309 289 316 minecraft:pearlescent_froglight
setblock 310 289 309 minecraft:pearlescent_froglight
setblock 310 289 311 minecraft:pearlescent_froglight
setblock 310 289 313 minecraft:pearlescent_froglight
setblock 310 289 315 minecraft:pearlescent_froglight
setblock 311 289 310 minecraft:pearlescent_froglight
setblock 311 289 312 minecraft:pearlescent_froglight
setblock 311 289 314 minecraft:pearlescent_froglight
setblock 311 289 316 minecraft:pearlescent_froglight
setblock 312 289 309 minecraft:pearlescent_froglight
setblock 312 289 311 minecraft:pearlescent_froglight
setblock 312 289 313 minecraft:pearlescent_froglight
setblock 312 289 315 minecraft:pearlescent_froglight
setblock 313 289 276 minecraft:pearlescent_froglight
setblock 313 289 278 minecraft:pearlescent_froglight
setblock 313 289 280 minecraft:pearlescent_froglight
setblock 313 289 282 minecraft:pearlescent_froglight
setblock 313 289 284 minecraft:pearlescent_froglight
setblock 314 289 277 minecraft:pearlescent_froglight
setblock 314 289 279 minecraft:pearlescent_froglight
setblock 314 289 281 minecraft:pearlescent_froglight
setblock 314 289 283 minecraft:pearlescent_froglight
setblock 315 289 276 minecraft:pearlescent_froglight
setblock 315 289 278 minecraft:pearlescent_froglight
setblock 315 289 280 minecraft:pearlescent_froglight
setblock 315 289 282 minecraft:pearlescent_froglight
setblock 315 289 284 minecraft:pearlescent_froglight
setblock 316 289 277 minecraft:pearlescent_froglight
setblock 316 289 279 minecraft:pearlescent_froglight
setblock 316 289 281 minecraft:pearlescent_froglight
setblock 316 289 283 minecraft:pearlescent_froglight
setblock 317 289 276 minecraft:pearlescent_froglight
setblock 317 289 278 minecraft:pearlescent_froglight
setblock 317 289 280 minecraft:pearlescent_froglight
setblock 317 289 282 minecraft:pearlescent_froglight
setblock 317 289 284 minecraft:pearlescent_froglight
setblock 318 289 277 minecraft:pearlescent_froglight
setblock 318 289 279 minecraft:pearlescent_froglight
setblock 318 289 281 minecraft:pearlescent_froglight
setblock 318 289 283 minecraft:pearlescent_froglight
setblock 319 289 276 minecraft:pearlescent_froglight
setblock 319 289 278 minecraft:pearlescent_froglight
setblock 319 289 280 minecraft:pearlescent_froglight
setblock 319 289 282 minecraft:pearlescent_froglight
setblock 319 289 284 minecraft:pearlescent_froglight
setblock 324 289 280 minecraft:redstone_block
fill 324 289 281 324 304 283 minecraft:light_gray_concrete
fill 324 289 310 324 297 313 minecraft:light_gray_concrete
setblock 324 289 314 minecraft:sea_lantern
fill 324 289 315 324 304 315 minecraft:light_gray_concrete
fill 283 290 276 283 291 276 minecraft:iron_block
fill 283 290 278 283 291 278 minecraft:iron_block
fill 283 290 280 283 291 280 minecraft:iron_block
fill 284 290 275 284 291 275 minecraft:light_gray_concrete
fill 284 290 277 284 291 277 minecraft:iron_block
fill 284 290 279 284 291 279 minecraft:iron_block
fill 284 290 281 284 291 281 minecraft:iron_block
fill 285 290 276 285 291 276 minecraft:iron_block
fill 285 290 278 285 291 278 minecraft:iron_block
fill 285 290 280 285 291 280 minecraft:iron_block
fill 286 290 275 286 291 275 minecraft:light_gray_concrete
fill 286 290 277 286 291 277 minecraft:iron_block
fill 286 290 279 286 291 279 minecraft:iron_block
fill 286 290 281 286 291 281 minecraft:iron_block
fill 287 290 276 287 291 276 minecraft:iron_block
fill 287 290 278 287 291 278 minecraft:iron_block
fill 287 290 280 287 291 280 minecraft:iron_block
fill 288 290 275 288 291 275 minecraft:light_gray_concrete
fill 288 290 277 288 291 277 minecraft:iron_block
fill 288 290 279 288 291 279 minecraft:iron_block
fill 288 290 281 288 291 281 minecraft:iron_block
fill 289 290 276 289 291 276 minecraft:iron_block
fill 289 290 278 289 291 278 minecraft:iron_block
fill 289 290 280 289 291 280 minecraft:iron_block
fill 302 290 275 302 304 275 minecraft:light_gray_concrete
fill 306 290 309 306 291 309 minecraft:iron_block
fill 306 290 311 306 291 311 minecraft:iron_block
fill 306 290 313 306 291 313 minecraft:iron_block
fill 306 290 315 306 291 315 minecraft:iron_block
fill 307 290 310 307 291 310 minecraft:iron_block
fill 307 290 312 307 291 312 minecraft:iron_block
fill 307 290 314 307 291 314 minecraft:iron_block
fill 307 290 316 307 291 316 minecraft:iron_block
fill 308 290 309 308 291 309 minecraft:iron_block
fill 308 290 311 308 291 311 minecraft:iron_block
fill 308 290 313 308 291 313 minecraft:iron_block
fill 308 290 315 308 291 315 minecraft:iron_block
fill 309 290 310 309 291 310 minecraft:iron_block
fill 309 290 312 309 291 312 minecraft:iron_block
fill 309 290 314 309 291 314 minecraft:iron_block
fill 309 290 316 309 291 316 minecraft:iron_block
fill 310 290 309 310 291 309 minecraft:iron_block
fill 310 290 311 310 291 311 minecraft:iron_block
fill 310 290 313 310 291 313 minecraft:iron_block
fill 310 290 315 310 291 315 minecraft:iron_block
fill 311 290 310 311 291 310 minecraft:iron_block
fill 311 290 312 311 291 312 minecraft:iron_block
fill 311 290 314 311 291 314 minecraft:iron_block
fill 311 290 316 311 291 316 minecraft:iron_block
fill 312 290 309 312 291 309 minecraft:iron_block
fill 312 290 311 312 291 311 minecraft:iron_block
fill 312 290 313 312 291 313 minecraft:iron_block
fill 312 290 315 312 291 315 minecraft:iron_block
fill 313 290 276 313 291 276 minecraft:iron_block
fill 313 290 278 313 291 278 minecraft:iron_block
fill 313 290 280 313 291 280 minecraft:iron_block
fill 313 290 282 313 291 282 minecraft:iron_block
fill 313 290 284 313 291 284 minecraft:iron_block
fill 314 290 277 314 291 277 minecraft:iron_block
fill 314 290 279 314 291 279 minecraft:iron_block
fill 314 290 281 314 291 281 minecraft:iron_block
fill 314 290 283 314 291 283 minecraft:iron_block
fill 315 290 276 315 291 276 minecraft:iron_block
fill 315 290 278 315 291 278 minecraft:iron_block
fill 315 290 280 315 291 280 minecraft:iron_block
fill 315 290 282 315 291 282 minecraft:iron_block
fill 315 290 284 315 291 284 minecraft:iron_block
fill 316 290 277 316 291 277 minecraft:iron_block
fill 316 290 279 316 291 279 minecraft:iron_block
fill 316 290 281 316 291 281 minecraft:iron_block
fill 316 290 283 316 291 283 minecraft:iron_block
fill 317 290 276 317 291 276 minecraft:iron_block
fill 317 290 278 317 291 278 minecraft:iron_block
fill 317 290 280 317 291 280 minecraft:iron_block
fill 317 290 282 317 291 282 minecraft:iron_block
fill 317 290 284 317 291 284 minecraft:iron_block
fill 318 290 277 318 291 277 minecraft:iron_block
fill 318 290 279 318 291 279 minecraft:iron_block
fill 318 290 281 318 291 281 minecraft:iron_block
fill 318 290 283 318 291 283 minecraft:iron_block
fill 319 290 276 319 291 276 minecraft:iron_block
fill 319 290 278 319 291 278 minecraft:iron_block
fill 319 290 280 319 291 280 minecraft:iron_block
fill 319 290 282 319 291 282 minecraft:iron_block
fill 319 290 284 319 291 284 minecraft:iron_block
fill 324 290 280 324 301 280 minecraft:light_gray_concrete
fill 324 290 314 324 304 314 minecraft:light_gray_concrete
fill 290 291 317 291 304 317 minecraft:light_gray_concrete
setblock 292 291 317 minecraft:sea_lantern
fill 293 291 317 298 291 317 minecraft:light_gray_concrete
fill 298 291 276 298 292 278 minecraft:iron_block
setblock 299 291 317 minecraft:sea_lantern
fill 320 291 279 321 291 279 minecraft:gray_concrete
setblock 320 291 283 minecraft:gray_concrete
fill 321 291 280 321 291 282 minecraft:gray_concrete
fill 282 292 281 282 292 284 minecraft:pearlescent_froglight
fill 282 292 291 282 292 294 minecraft:pearlescent_froglight
fill 282 292 301 282 292 304 minecraft:pearlescent_froglight
fill 282 292 305 282 304 310 minecraft:light_gray_concrete
fill 282 292 311 282 292 314 minecraft:pearlescent_froglight
setblock 283 292 276 minecraft:pearlescent_froglight
setblock 283 292 278 minecraft:pearlescent_froglight
setblock 283 292 280 minecraft:pearlescent_froglight
fill 284 292 275 288 292 275 minecraft:pearlescent_froglight
setblock 284 292 277 minecraft:pearlescent_froglight
setblock 284 292 279 minecraft:pearlescent_froglight
setblock 284 292 281 minecraft:pearlescent_froglight
fill 284 292 293 284 293 297 minecraft:iron_block
setblock 285 292 276 minecraft:pearlescent_froglight
setblock 285 292 278 minecraft:pearlescent_froglight
setblock 285 292 280 minecraft:pearlescent_froglight
fill 285 292 292 285 293 293 minecraft:iron_block
fill 285 292 295 290 293 295 minecraft:iron_block
fill 285 292 297 285 293 298 minecraft:iron_block
setblock 286 292 277 minecraft:pearlescent_froglight
setblock 286 292 279 minecraft:pearlescent_froglight
setblock 286 292 281 minecraft:pearlescent_froglight
fill 286 292 292 289 293 292 minecraft:iron_block
fill 286 292 298 289 293 298 minecraft:iron_block
fill 286 292 317 289 292 317 minecraft:pearlescent_froglight
setblock 287 292 276 minecraft:pearlescent_froglight
setblock 287 292 278 minecraft:pearlescent_froglight
setblock 287 292 280 minecraft:pearlescent_froglight
fill 287 292 293 287 293 294 minecraft:iron_block
fill 287 292 296 287 293 297 minecraft:iron_block
setblock 288 292 277 minecraft:pearlescent_froglight
setblock 288 292 279 minecraft:pearlescent_froglight
setblock 288 292 281 minecraft:pearlescent_froglight
setblock 289 292 276 minecraft:pearlescent_froglight
setblock 289 292 278 minecraft:pearlescent_froglight
setblock 289 292 280 minecraft:pearlescent_froglight
fill 289 292 293 290 293 293 minecraft:iron_block
fill 289 292 297 290 293 297 minecraft:iron_block
fill 290 292 294 290 293 294 minecraft:iron_block
fill 290 292 296 290 293 296 minecraft:iron_block
setblock 292 292 277 minecraft:iron_block
setblock 292 292 279 minecraft:iron_block
fill 292 292 317 295 304 317 minecraft:light_gray_concrete
setblock 294 292 277 minecraft:iron_block
setblock 294 292 279 minecraft:iron_block
fill 295 292 275 298 292 275 minecraft:pearlescent_froglight
fill 296 292 317 299 292 317 minecraft:pearlescent_froglight
fill 305 292 275 308 292 275 minecraft:pearlescent_froglight
setblock 306 292 309 minecraft:pearlescent_froglight
setblock 306 292 311 minecraft:pearlescent_froglight
setblock 306 292 313 minecraft:pearlescent_froglight
setblock 306 292 315 minecraft:pearlescent_froglight
fill 306 292 317 309 292 317 minecraft:pearlescent_froglight
setblock 307 292 310 minecraft:pearlescent_froglight
setblock 307 292 312 minecraft:pearlescent_froglight
setblock 307 292 314 minecraft:pearlescent_froglight
setblock 307 292 316 minecraft:pearlescent_froglight
setblock 308 292 309 minecraft:pearlescent_froglight
setblock 308 292 311 minecraft:pearlescent_froglight
setblock 308 292 313 minecraft:pearlescent_froglight
setblock 308 292 315 minecraft:pearlescent_froglight
setblock 309 292 310 minecraft:pearlescent_froglight
setblock 309 292 312 minecraft:pearlescent_froglight
setblock 309 292 314 minecraft:pearlescent_froglight
setblock 309 292 316 minecraft:pearlescent_froglight
setblock 310 292 309 minecraft:pearlescent_froglight
setblock 310 292 311 minecraft:pearlescent_froglight
setblock 310 292 313 minecraft:pearlescent_froglight
setblock 310 292 315 minecraft:pearlescent_froglight
setblock 311 292 310 minecraft:pearlescent_froglight
setblock 311 292 312 minecraft:pearlescent_froglight
setblock 311 292 314 minecraft:pearlescent_froglight
setblock 311 292 316 minecraft:pearlescent_froglight
setblock 312 292 309 minecraft:pearlescent_froglight
setblock 312 292 311 minecraft:pearlescent_froglight
setblock 312 292 313 minecraft:pearlescent_froglight
setblock 312 292 315 minecraft:pearlescent_froglight
setblock 313 292 276 minecraft:pearlescent_froglight
setblock 313 292 278 minecraft:pearlescent_froglight
setblock 313 292 280 minecraft:pearlescent_froglight
setblock 313 292 282 minecraft:pearlescent_froglight
setblock 313 292 284 minecraft:pearlescent_froglight
setblock 314 292 277 minecraft:pearlescent_froglight
setblock 314 292 279 minecraft:pearlescent_froglight
setblock 314 292 281 minecraft:pearlescent_froglight
setblock 314 292 283 minecraft:pearlescent_froglight
fill 315 292 275 315 292 276 minecraft:pearlescent_froglight
setblock 315 292 278 minecraft:pearlescent_froglight
setblock 315 292 280 minecraft:pearlescent_froglight
setblock 315 292 282 minecraft:pearlescent_froglight
setblock 315 292 284 minecraft:pearlescent_froglight
fill 316 292 275 318 292 275 minecraft:pearlescent_froglight
setblock 316 292 277 minecraft:pearlescent_froglight
setblock 316 292 279 minecraft:pearlescent_froglight
setblock 316 292 281 minecraft:pearlescent_froglight
setblock 316 292 283 minecraft:pearlescent_froglight
fill 316 292 317 319 292 317 minecraft:pearlescent_froglight
setblock 317 292 276 minecraft:pearlescent_froglight
setblock 317 292 278 minecraft:pearlescent_froglight
setblock 317 292 280 minecraft:pearlescent_froglight
setblock 317 292 282 minecraft:pearlescent_froglight
setblock 317 292 284 minecraft:pearlescent_froglight
setblock 318 292 277 minecraft:pearlescent_froglight
setblock 318 292 279 minecraft:pearlescent_froglight
setblock 318 292 281 minecraft:pearlescent_froglight
setblock 318 292 283 minecraft:pearlescent_froglight
setblock 319 292 276 minecraft:pearlescent_froglight
setblock 319 292 278 minecraft:pearlescent_froglight
setblock 319 292 280 minecraft:pearlescent_froglight
setblock 319 292 282 minecraft:pearlescent_froglight
setblock 319 292 284 minecraft:pearlescent_froglight
fill 324 292 276 324 292 279 minecraft:pearlescent_froglight
fill 324 292 286 324 292 289 minecraft:pearlescent_froglight
fill 324 292 296 324 292 299 minecraft:pearlescent_froglight
fill 324 292 306 324 292 309 minecraft:pearlescent_froglight
setblock 324 292 316 minecraft:pearlescent_froglight
fill 282 293 281 282 300 284 minecraft:light_gray_concrete
fill 282 293 291 282 294 294 minecraft:light_gray_concrete
fill 282 293 301 282 302 304 minecraft:light_gray_concrete
fill 282 293 311 282 304 314 minecraft:light_gray_concrete
fill 283 293 276 283 294 276 minecraft:iron_block
fill 283 293 278 283 294 278 minecraft:iron_block
fill 283 293 280 283 294 280 minecraft:iron_block
fill 284 293 275 288 294 275 minecraft:light_gray_concrete
fill 284 293 277 284 294 277 minecraft:iron_block
fill 284 293 279 284 294 279 minecraft:iron_block
fill 284 293 281 284 294 281 minecraft:iron_block
setblock 284 293 285 minecraft:iron_block
setblock 284 293 287 minecraft:iron_block
fill 285 293 276 285 294 276 minecraft:iron_block
fill 285 293 278 285 294 278 minecraft:iron_block
fill 285 293 280 285 294 280 minecraft:iron_block
fill 286 293 277 286 294 277 minecraft:iron_block
fill 286 293 279 286 294 279 minecraft:iron_block
fill 286 293 281 286 294 281 minecraft:iron_block
setblock 286 293 285 minecraft:iron_block
setblock 286 293 287 minecraft:iron_block
fill 286 293 317 289 304 317 minecraft:light_gray_concrete
fill 287 293 276 287 294 276 minecraft:iron_block
fill 287 293 278 287 294 278 minecraft:iron_block
fill 287 293 280 287 294 280 minecraft:iron_block
fill 288 293 277 288 294 277 minecraft:iron_block
fill 288 293 279 288 294 279 minecraft:iron_block
fill 288 293 281 288 294 281 minecraft:iron_block
fill 289 293 276 289 294 276 minecraft:iron_block
fill 289 293 278 289 294 278 minecraft:iron_block
fill 289 293 280 289 294 280 minecraft:iron_block
fill 295 293 275 298 301 275 minecraft:light_gray_concrete
fill 296 293 317 299 304 317 minecraft:light_gray_concrete
fill 305 293 275 308 304 275 minecraft:light_gray_concrete
fill 306 293 309 306 294 309 minecraft:iron_block
fill 306 293 311 306 294 311 minecraft:iron_block
fill 306 293 313 306 294 313 minecraft:iron_block
fill 306 293 315 306 294 315 minecraft:iron_block
fill 306 293 317 309 304 317 minecraft:light_gray_concrete
fill 307 293 310 307 294 310 minecraft:iron_block
fill 307 293 312 307 294 312 minecraft:iron_block
fill 307 293 314 307 294 314 minecraft:iron_block
fill 307 293 316 307 294 316 minecraft:iron_block
fill 308 293 309 308 294 309 minecraft:iron_block
fill 308 293 311 308 294 311 minecraft:iron_block
fill 308 293 313 308 294 313 minecraft:iron_block
fill 308 293 315 308 294 315 minecraft:iron_block
fill 309 293 310 309 294 310 minecraft:iron_block
fill 309 293 312 309 294 312 minecraft:iron_block
fill 309 293 314 309 294 314 minecraft:iron_block
fill 309 293 316 309 294 316 minecraft:iron_block
fill 310 293 309 310 294 309 minecraft:iron_block
fill 310 293 311 310 294 311 minecraft:iron_block
fill 310 293 313 310 294 313 minecraft:iron_block
fill 310 293 315 310 294 315 minecraft:iron_block
fill 311 293 310 311 294 310 minecraft:iron_block
fill 311 293 312 311 294 312 minecraft:iron_block
fill 311 293 314 311 294 314 minecraft:iron_block
fill 311 293 316 311 294 316 minecraft:iron_block
fill 312 293 309 312 294 309 minecraft:iron_block
fill 312 293 311 312 294 311 minecraft:iron_block
fill 312 293 313 312 294 313 minecraft:iron_block
fill 312 293 315 312 294 315 minecraft:iron_block
fill 313 293 276 313 294 276 minecraft:iron_block
fill 313 293 278 313 294 278 minecraft:iron_block
fill 313 293 280 313 294 280 minecraft:iron_block
fill 313 293 282 313 294 282 minecraft:iron_block
fill 313 293 284 313 294 284 minecraft:iron_block
fill 314 293 277 314 294 277 minecraft:iron_block
fill 314 293 279 314 294 279 minecraft:iron_block
fill 314 293 281 314 294 281 minecraft:iron_block
fill 314 293 283 314 294 283 minecraft:iron_block
fill 315 293 275 318 304 275 minecraft:light_gray_concrete
fill 315 293 276 315 294 276 minecraft:iron_block
fill 315 293 278 315 294 278 minecraft:iron_block
fill 315 293 280 315 294 280 minecraft:iron_block
fill 315 293 282 315 294 282 minecraft:iron_block
fill 315 293 284 315 294 284 minecraft:iron_block
fill 316 293 277 316 294 277 minecraft:iron_block
fill 316 293 279 316 294 279 minecraft:iron_block
fill 316 293 281 316 294 281 minecraft:iron_block
fill 316 293 283 316 294 283 minecraft:iron_block
fill 316 293 317 319 304 317 minecraft:light_gray_concrete
fill 317 293 276 317 294 276 minecraft:iron_block
fill 317 293 278 317 294 278 minecraft:iron_block
fill 317 293 280 317 294 280 minecraft:iron_block
fill 317 293 282 317 294 282 minecraft:iron_block
fill 317 293 284 317 294 284 minecraft:iron_block
fill 318 293 277 318 294 277 minecraft:iron_block
fill 318 293 279 318 294 279 minecraft:iron_block
fill 318 293 281 318 294 281 minecraft:iron_block
fill 318 293 283 318 294 283 minecraft:iron_block
fill 319 293 276 319 294 276 minecraft:iron_block
fill 319 293 278 319 294 278 minecraft:iron_block
fill 319 293 280 319 294 280 minecraft:iron_block
fill 319 293 282 319 294 282 minecraft:iron_block
fill 319 293 284 319 294 284 minecraft:iron_block
fill 324 293 276 324 295 279 minecraft:light_gray_concrete
fill 324 293 286 324 302 289 minecraft:light_gray_concrete
fill 324 293 296 324 304 299 minecraft:light_gray_concrete
fill 324 293 306 324 304 309 minecraft:light_gray_concrete
fill 324 293 316 324 304 316 minecraft:light_gray_concrete
setblock 283 294 288 minecraft:iron_block
setblock 283 294 298 minecraft:iron_block
setblock 283 294 308 minecraft:iron_block
setblock 285 294 292 minecraft:light[level=12]
setblock 285 294 299 minecraft:light[level=12]
setblock 285 294 306 minecraft:light[level=12]
setblock 285 294 313 minecraft:light[level=12]
setblock 285 294 316 minecraft:iron_block
setblock 292 294 285 minecraft:light[level=12]
setblock 292 294 292 minecraft:light[level=12]
setblock 292 294 299 minecraft:light[level=12]
setblock 292 294 306 minecraft:light[level=12]
setblock 292 294 313 minecraft:light[level=12]
setblock 295 294 316 minecraft:iron_block
setblock 299 294 276 minecraft:iron_block
setblock 299 294 278 minecraft:light[level=12]
setblock 299 294 285 minecraft:light[level=12]
setblock 299 294 292 minecraft:light[level=12]
setblock 299 294 299 minecraft:light[level=12]
setblock 299 294 306 minecraft:light[level=12]
setblock 299 294 313 minecraft:light[level=12]
setblock 305 294 316 minecraft:iron_block
setblock 306 294 278 minecraft:light[level=12]
setblock 306 294 285 minecraft:light[level=12]
setblock 306 294 292 minecraft:light[level=12]
setblock 306 294 299 minecraft:light[level=12]
setblock 306 294 306 minecraft:light[level=12]
setblock 309 294 276 minecraft:iron_block
setblock 313 294 285 minecraft:light[level=12]
setblock 313 294 292 minecraft:light[level=12]
setblock 313 294 299 minecraft:light[level=12]
setblock 313 294 306 minecraft:light[level=12]
setblock 313 294 313 minecraft:light[level=12]
setblock 315 294 316 minecraft:iron_block
setblock 320 294 278 minecraft:light[level=12]
setblock 320 294 285 minecraft:light[level=12]
setblock 320 294 292 minecraft:light[level=12]
setblock 320 294 299 minecraft:light[level=12]
setblock 320 294 306 minecraft:light[level=12]
setblock 320 294 313 minecraft:light[level=12]
setblock 323 294 282 minecraft:iron_block
setblock 323 294 292 minecraft:iron_block
setblock 323 294 302 minecraft:iron_block
setblock 323 294 312 minecraft:iron_block
setblock 282 295 287 minecraft:redstone_block
setblock 282 295 291 minecraft:redstone_block
fill 282 295 292 282 304 294 minecraft:light_gray_concrete
setblock 283 295 276 minecraft:pearlescent_froglight
setblock 283 295 278 minecraft:pearlescent_froglight
setblock 283 295 280 minecraft:pearlescent_froglight
setblock 284 295 275 minecraft:pearlescent_froglight
setblock 284 295 277 minecraft:pearlescent_froglight
setblock 284 295 279 minecraft:pearlescent_froglight
setblock 284 295 281 minecraft:pearlescent_froglight
fill 285 295 275 285 304 275 minecraft:light_gray_concrete
setblock 285 295 276 minecraft:pearlescent_froglight
setblock 285 295 278 minecraft:pearlescent_froglight
setblock 285 295 280 minecraft:pearlescent_froglight
setblock 286 295 275 minecraft:pearlescent_froglight
setblock 286 295 277 minecraft:pearlescent_froglight
setblock 286 295 279 minecraft:pearlescent_froglight
setblock 286 295 281 minecraft:pearlescent_froglight
fill 287 295 275 287 304 275 minecraft:light_gray_concrete
setblock 287 295 276 minecraft:pearlescent_froglight
setblock 287 295 278 minecraft:pearlescent_froglight
setblock 287 295 280 minecraft:pearlescent_froglight
setblock 288 295 275 minecraft:pearlescent_froglight
setblock 288 295 277 minecraft:pearlescent_froglight
setblock 288 295 279 minecraft:pearlescent_froglight
setblock 288 295 281 minecraft:pearlescent_froglight
setblock 289 295 276 minecraft:pearlescent_froglight
setblock 289 295 278 minecraft:pearlescent_froglight
setblock 289 295 280 minecraft:pearlescent_froglight
setblock 306 295 309 minecraft:pearlescent_froglight
setblock 306 295 311 minecraft:pearlescent_froglight
setblock 306 295 313 minecraft:pearlescent_froglight
setblock 306 295 315 minecraft:pearlescent_froglight
setblock 307 295 310 minecraft:pearlescent_froglight
setblock 307 295 312 minecraft:pearlescent_froglight
setblock 307 295 314 minecraft:pearlescent_froglight
setblock 307 295 316 minecraft:pearlescent_froglight
setblock 308 295 309 minecraft:pearlescent_froglight
setblock 308 295 311 minecraft:pearlescent_froglight
setblock 308 295 313 minecraft:pearlescent_froglight
setblock 308 295 315 minecraft:pearlescent_froglight
setblock 309 295 310 minecraft:pearlescent_froglight
setblock 309 295 312 minecraft:pearlescent_froglight
setblock 309 295 314 minecraft:pearlescent_froglight
setblock 309 295 316 minecraft:pearlescent_froglight
setblock 310 295 309 minecraft:pearlescent_froglight
setblock 310 295 311 minecraft:pearlescent_froglight
setblock 310 295 313 minecraft:pearlescent_froglight
setblock 310 295 315 minecraft:pearlescent_froglight
setblock 311 295 310 minecraft:pearlescent_froglight
setblock 311 295 312 minecraft:pearlescent_froglight
setblock 311 295 314 minecraft:pearlescent_froglight
setblock 311 295 316 minecraft:pearlescent_froglight
setblock 312 295 309 minecraft:pearlescent_froglight
setblock 312 295 311 minecraft:pearlescent_froglight
setblock 312 295 313 minecraft:pearlescent_froglight
setblock 312 295 315 minecraft:pearlescent_froglight
setblock 313 295 276 minecraft:pearlescent_froglight
setblock 313 295 278 minecraft:pearlescent_froglight
setblock 313 295 280 minecraft:pearlescent_froglight
setblock 313 295 282 minecraft:pearlescent_froglight
setblock 313 295 284 minecraft:pearlescent_froglight
setblock 314 295 277 minecraft:pearlescent_froglight
setblock 314 295 279 minecraft:pearlescent_froglight
setblock 314 295 281 minecraft:pearlescent_froglight
setblock 314 295 283 minecraft:pearlescent_froglight
setblock 315 295 276 minecraft:pearlescent_froglight
setblock 315 295 278 minecraft:pearlescent_froglight
setblock 315 295 280 minecraft:pearlescent_froglight
setblock 315 295 282 minecraft:pearlescent_froglight
setblock 315 295 284 minecraft:pearlescent_froglight
setblock 316 295 277 minecraft:pearlescent_froglight
setblock 316 295 279 minecraft:pearlescent_froglight
setblock 316 295 281 minecraft:pearlescent_froglight
setblock 316 295 283 minecraft:pearlescent_froglight
setblock 317 295 276 minecraft:pearlescent_froglight
setblock 317 295 278 minecraft:pearlescent_froglight
setblock 317 295 280 minecraft:pearlescent_froglight
setblock 317 295 282 minecraft:pearlescent_froglight
setblock 317 295 284 minecraft:pearlescent_froglight
setblock 318 295 277 minecraft:pearlescent_froglight
setblock 318 295 279 minecraft:pearlescent_froglight
setblock 318 295 281 minecraft:pearlescent_froglight
setblock 318 295 283 minecraft:pearlescent_froglight
setblock 319 295 276 minecraft:pearlescent_froglight
setblock 319 295 278 minecraft:pearlescent_froglight
setblock 319 295 280 minecraft:pearlescent_froglight
setblock 319 295 282 minecraft:pearlescent_froglight
setblock 319 295 284 minecraft:pearlescent_froglight
fill 282 296 287 282 304 287 minecraft:light_gray_concrete
fill 282 296 291 282 304 291 minecraft:light_gray_concrete
fill 283 296 276 283 297 276 minecraft:iron_block
fill 283 296 278 283 297 278 minecraft:iron_block
fill 283 296 280 283 297 280 minecraft:iron_block
fill 284 296 275 284 304 275 minecraft:light_gray_concrete
fill 284 296 277 284 297 277 minecraft:iron_block
fill 284 296 279 284 297 279 minecraft:iron_block
fill 284 296 281 284 297 281 minecraft:iron_block
fill 285 296 276 285 297 276 minecraft:iron_block
fill 285 296 278 285 297 278 minecraft:iron_block
fill 285 296 280 285 297 280 minecraft:iron_block
setblock 285 296 294 minecraft:light[level=15]
setblock 285 296 302 minecraft:light[level=15]
setblock 285 296 310 minecraft:light[level=15]
fill 286 296 275 286 304 275 minecraft:light_gray_concrete
fill 286 296 277 286 297 277 minecraft:iron_block
fill 286 296 279 286 297 279 minecraft:iron_block
fill 286 296 281 286 297 281 minecraft:iron_block
fill 287 296 276 287 297 276 minecraft:iron_block
fill 287 296 278 287 297 278 minecraft:iron_block
fill 287 296 280 287 297 280 minecraft:iron_block
fill 288 296 275 288 304 275 minecraft:light_gray_concrete
fill 288 296 277 288 297 277 minecraft:iron_block
fill 288 296 279 288 297 279 minecraft:iron_block
fill 288 296 281 288 297 281 minecraft:iron_block
fill 289 296 276 289 297 276 minecraft:iron_block
fill 289 296 278 289 297 278 minecraft:iron_block
fill 289 296 280 289 297 280 minecraft:iron_block
setblock 293 296 286 minecraft:light[level=15]
setblock 293 296 294 minecraft:light[level=15]
setblock 293 296 302 minecraft:light[level=15]
setblock 293 296 310 minecraft:light[level=15]
setblock 301 296 278 minecraft:light[level=15]
setblock 301 296 286 minecraft:light[level=15]
setblock 301 296 294 minecraft:light[level=15]
setblock 301 296 302 minecraft:light[level=15]
setblock 301 296 310 minecraft:light[level=15]
fill 306 296 309 306 297 309 minecraft:iron_block
fill 306 296 311 306 297 311 minecraft:iron_block
fill 306 296 313 306 297 313 minecraft:iron_block
fill 306 296 315 306 297 315 minecraft:iron_block
fill 307 296 310 307 297 310 minecraft:iron_block
fill 307 296 312 307 297 312 minecraft:iron_block
fill 307 296 314 307 297 314 minecraft:iron_block
fill 307 296 316 307 297 316 minecraft:iron_block
fill 308 296 309 308 297 309 minecraft:iron_block
fill 308 296 311 308 297 311 minecraft:iron_block
fill 308 296 313 308 297 313 minecraft:iron_block
fill 308 296 315 308 297 315 minecraft:iron_block
setblock 309 296 278 minecraft:light[level=15]
setblock 309 296 286 minecraft:light[level=15]
setblock 309 296 294 minecraft:light[level=15]
setblock 309 296 302 minecraft:light[level=15]
fill 309 296 310 309 297 310 minecraft:iron_block
fill 309 296 312 309 297 312 minecraft:iron_block
fill 309 296 314 309 297 314 minecraft:iron_block
fill 309 296 316 309 297 316 minecraft:iron_block
fill 310 296 309 310 297 309 minecraft:iron_block
fill 310 296 311 310 297 311 minecraft:iron_block
fill 310 296 313 310 297 313 minecraft:iron_block
fill 310 296 315 310 297 315 minecraft:iron_block
fill 311 296 310 311 297 310 minecraft:iron_block
fill 311 296 312 311 297 312 minecraft:iron_block
fill 311 296 314 311 297 314 minecraft:iron_block
fill 311 296 316 311 297 316 minecraft:iron_block
fill 312 296 309 312 297 309 minecraft:iron_block
fill 312 296 311 312 297 311 minecraft:iron_block
fill 312 296 313 312 297 313 minecraft:iron_block
fill 312 296 315 312 297 315 minecraft:iron_block
fill 313 296 276 313 297 276 minecraft:iron_block
fill 313 296 278 313 297 278 minecraft:iron_block
fill 313 296 280 313 297 280 minecraft:iron_block
fill 313 296 282 313 297 282 minecraft:iron_block
fill 313 296 284 313 297 284 minecraft:iron_block
fill 314 296 277 314 297 277 minecraft:iron_block
fill 314 296 279 314 297 279 minecraft:iron_block
fill 314 296 281 314 297 281 minecraft:iron_block
fill 314 296 283 314 297 283 minecraft:iron_block
fill 315 296 276 315 297 276 minecraft:iron_block
fill 315 296 278 315 297 278 minecraft:iron_block
fill 315 296 280 315 297 280 minecraft:iron_block
fill 315 296 282 315 297 282 minecraft:iron_block
fill 315 296 284 315 297 284 minecraft:iron_block
fill 316 296 277 316 297 277 minecraft:iron_block
fill 316 296 279 316 297 279 minecraft:iron_block
fill 316 296 281 316 297 281 minecraft:iron_block
fill 316 296 283 316 297 283 minecraft:iron_block
fill 317 296 276 317 297 276 minecraft:iron_block
fill 317 296 278 317 297 278 minecraft:iron_block
fill 317 296 280 317 297 280 minecraft:iron_block
fill 317 296 282 317 297 282 minecraft:iron_block
fill 317 296 284 317 297 284 minecraft:iron_block
setblock 317 296 286 minecraft:light[level=15]
setblock 317 296 294 minecraft:light[level=15]
setblock 317 296 302 minecraft:light[level=15]
setblock 317 296 310 minecraft:light[level=15]
fill 318 296 277 318 297 277 minecraft:iron_block
fill 318 296 279 318 297 279 minecraft:iron_block
fill 318 296 281 318 300 281 minecraft:iron_block
fill 318 296 283 318 297 283 minecraft:iron_block
fill 319 296 276 319 297 276 minecraft:iron_block
fill 319 296 278 319 297 278 minecraft:iron_block
fill 319 296 280 319 300 280 minecraft:iron_block
fill 319 296 282 319 300 282 minecraft:iron_block
fill 319 296 284 319 297 284 minecraft:iron_block
fill 324 296 276 324 297 278 minecraft:light_gray_concrete
setblock 324 296 279 minecraft:redstone_block
fill 283 297 282 283 297 283 minecraft:iron_block
fill 283 297 290 283 297 293 minecraft:iron_block
fill 283 297 300 283 297 303 minecraft:iron_block
fill 283 297 310 283 297 313 minecraft:iron_block
fill 287 297 316 290 297 316 minecraft:iron_block
fill 294 297 276 297 297 276 minecraft:iron_block
fill 297 297 316 300 297 316 minecraft:iron_block
fill 304 297 276 307 297 276 minecraft:iron_block
fill 317 297 316 320 297 316 minecraft:iron_block
fill 323 297 277 323 297 280 minecraft:iron_block
fill 323 297 287 323 297 290 minecraft:iron_block
fill 323 297 297 323 297 300 minecraft:iron_block
fill 323 297 307 323 297 310 minecraft:iron_block
fill 324 297 279 324 304 279 minecraft:light_gray_concrete
setblock 306 298 309 minecraft:pearlescent_froglight
setblock 306 298 311 minecraft:pearlescent_froglight
setblock 306 298 313 minecraft:pearlescent_froglight
setblock 306 298 315 minecraft:pearlescent_froglight
setblock 307 298 310 minecraft:pearlescent_froglight
setblock 307 298 312 minecraft:pearlescent_froglight
setblock 307 298 314 minecraft:pearlescent_froglight
setblock 307 298 316 minecraft:pearlescent_froglight
setblock 308 298 309 minecraft:pearlescent_froglight
setblock 308 298 311 minecraft:pearlescent_froglight
setblock 308 298 313 minecraft:pearlescent_froglight
setblock 308 298 315 minecraft:pearlescent_froglight
setblock 309 298 310 minecraft:pearlescent_froglight
setblock 309 298 312 minecraft:pearlescent_froglight
setblock 309 298 314 minecraft:pearlescent_froglight
setblock 309 298 316 minecraft:pearlescent_froglight
setblock 310 298 309 minecraft:pearlescent_froglight
setblock 310 298 311 minecraft:pearlescent_froglight
setblock 310 298 313 minecraft:pearlescent_froglight
setblock 310 298 315 minecraft:pearlescent_froglight
setblock 311 298 310 minecraft:pearlescent_froglight
setblock 311 298 312 minecraft:pearlescent_froglight
setblock 311 298 314 minecraft:pearlescent_froglight
setblock 311 298 316 minecraft:pearlescent_froglight
setblock 312 298 309 minecraft:pearlescent_froglight
setblock 312 298 311 minecraft:pearlescent_froglight
setblock 312 298 313 minecraft:pearlescent_froglight
setblock 312 298 315 minecraft:pearlescent_froglight
fill 324 298 276 324 304 277 minecraft:light_gray_concrete
setblock 324 298 278 minecraft:sea_lantern
setblock 324 298 285 minecraft:redstone_block
fill 324 298 290 324 304 291 minecraft:light_gray_concrete
setblock 324 298 292 minecraft:redstone_block
fill 324 298 293 324 304 295 minecraft:light_gray_concrete
fill 324 298 310 324 304 311 minecraft:light_gray_concrete
setblock 324 298 312 minecraft:sea_lantern
fill 324 298 313 324 304 313 minecraft:light_gray_concrete
setblock 292 299 277 minecraft:iron_block
setblock 292 299 279 minecraft:iron_block
setblock 294 299 277 minecraft:iron_block
setblock 294 299 279 minecraft:iron_block
fill 306 299 309 306 300 309 minecraft:iron_block
fill 306 299 311 306 300 311 minecraft:iron_block
fill 306 299 313 306 300 313 minecraft:iron_block
fill 306 299 315 306 300 315 minecraft:iron_block
fill 307 299 310 307 300 310 minecraft:iron_block
fill 307 299 312 307 300 312 minecraft:iron_block
fill 307 299 314 307 300 314 minecraft:iron_block
fill 307 299 316 307 300 316 minecraft:iron_block
fill 308 299 309 308 300 309 minecraft:iron_block
fill 308 299 311 308 300 311 minecraft:iron_block
fill 308 299 313 308 300 313 minecraft:iron_block
fill 308 299 315 308 300 315 minecraft:iron_block
fill 309 299 310 309 300 310 minecraft:iron_block
fill 309 299 312 309 300 312 minecraft:iron_block
fill 309 299 314 309 300 314 minecraft:iron_block
fill 309 299 316 309 300 316 minecraft:iron_block
fill 310 299 309 310 300 309 minecraft:iron_block
fill 310 299 311 310 300 311 minecraft:iron_block
fill 310 299 313 310 300 313 minecraft:iron_block
fill 310 299 315 310 300 315 minecraft:iron_block
fill 311 299 310 311 300 310 minecraft:iron_block
fill 311 299 312 311 300 312 minecraft:iron_block
fill 311 299 314 311 300 314 minecraft:iron_block
fill 311 299 316 311 300 316 minecraft:iron_block
fill 312 299 309 312 300 309 minecraft:iron_block
fill 312 299 311 312 300 311 minecraft:iron_block
schedule function dropper:buildpart/66_5 1t
