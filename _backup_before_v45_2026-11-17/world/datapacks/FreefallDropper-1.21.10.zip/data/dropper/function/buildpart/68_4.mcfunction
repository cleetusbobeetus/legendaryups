fill 414 168 314 414 171 314 minecraft:red_terracotta
setblock 415 168 291 minecraft:red_terracotta
setblock 415 168 292 minecraft:stripped_oak_log
fill 415 168 293 415 168 296 minecraft:red_terracotta
setblock 415 168 306 minecraft:red_terracotta
setblock 415 168 307 minecraft:stripped_oak_log
fill 415 168 308 415 171 308 minecraft:red_terracotta
setblock 415 168 312 minecraft:stripped_oak_log
fill 415 168 313 415 171 313 minecraft:red_terracotta
setblock 416 168 276 minecraft:stripped_oak_log
fill 416 168 287 416 168 290 minecraft:red_terracotta
setblock 416 168 291 minecraft:stripped_oak_log
fill 416 168 292 416 168 295 minecraft:red_terracotta
setblock 416 168 296 minecraft:stripped_oak_log
fill 416 168 297 416 168 300 minecraft:red_terracotta
setblock 416 168 301 minecraft:stripped_oak_log
fill 416 168 302 416 168 305 minecraft:red_terracotta
setblock 416 168 306 minecraft:stripped_oak_log
fill 416 168 307 416 171 307 minecraft:red_terracotta
setblock 416 168 311 minecraft:stripped_oak_log
fill 416 168 312 416 171 312 minecraft:red_terracotta
setblock 416 168 316 minecraft:stripped_oak_log
fill 417 168 276 417 171 276 minecraft:red_terracotta
setblock 417 168 279 minecraft:red_terracotta
fill 417 168 283 417 169 283 minecraft:red_terracotta
setblock 417 168 285 minecraft:stripped_oak_log
fill 417 168 286 417 171 286 minecraft:red_terracotta
setblock 417 168 290 minecraft:stripped_oak_log
fill 417 168 291 417 171 291 minecraft:red_terracotta
setblock 417 168 294 minecraft:red_terracotta
setblock 417 168 295 minecraft:stripped_oak_log
fill 417 168 296 417 168 299 minecraft:red_terracotta
setblock 417 168 300 minecraft:stripped_oak_log
fill 417 168 301 417 168 304 minecraft:red_terracotta
setblock 417 168 305 minecraft:stripped_oak_log
fill 417 168 306 417 171 306 minecraft:red_terracotta
setblock 417 168 310 minecraft:stripped_oak_log
fill 417 168 311 417 171 311 minecraft:red_terracotta
setblock 417 168 315 minecraft:stripped_oak_log
fill 417 168 316 417 171 316 minecraft:red_terracotta
fill 418 168 276 418 171 316 minecraft:orange_terracotta
setblock 377 169 279 minecraft:stripped_oak_log
fill 377 169 280 377 169 283 minecraft:red_terracotta
setblock 377 169 284 minecraft:stripped_oak_log
fill 377 169 285 377 169 288 minecraft:red_terracotta
setblock 377 169 289 minecraft:stripped_oak_log
fill 377 169 290 377 169 293 minecraft:red_terracotta
setblock 377 169 294 minecraft:stripped_oak_log
fill 377 169 295 377 169 298 minecraft:red_terracotta
setblock 377 169 299 minecraft:stripped_oak_log
fill 377 169 300 377 169 303 minecraft:red_terracotta
setblock 377 169 304 minecraft:stripped_oak_log
fill 377 169 305 377 172 305 minecraft:red_terracotta
fill 377 169 307 377 170 307 minecraft:red_terracotta
setblock 377 169 308 minecraft:shroomlight
setblock 377 169 309 minecraft:stripped_oak_log
setblock 377 169 310 minecraft:shroomlight
setblock 377 169 312 minecraft:shroomlight
setblock 377 169 314 minecraft:shroomlight
fill 377 169 315 377 172 315 minecraft:red_terracotta
setblock 377 169 316 minecraft:shroomlight
setblock 378 169 277 minecraft:red_terracotta
fill 378 169 284 378 171 284 minecraft:red_terracotta
setblock 378 169 288 minecraft:stripped_oak_log
fill 378 169 289 378 172 289 minecraft:red_terracotta
setblock 378 169 293 minecraft:stripped_oak_log
fill 378 169 294 378 169 297 minecraft:red_terracotta
setblock 378 169 298 minecraft:stripped_oak_log
fill 378 169 299 378 169 302 minecraft:red_terracotta
setblock 378 169 303 minecraft:stripped_oak_log
fill 378 169 304 378 171 304 minecraft:red_terracotta
setblock 378 169 308 minecraft:stripped_oak_log
setblock 378 169 309 minecraft:shroomlight
setblock 378 169 311 minecraft:shroomlight
setblock 378 169 313 minecraft:shroomlight
fill 378 169 314 378 172 314 minecraft:red_terracotta
setblock 378 169 315 minecraft:shroomlight
fill 378 169 316 378 170 316 minecraft:red_terracotta
setblock 379 169 276 minecraft:red_terracotta
setblock 379 169 277 minecraft:stripped_oak_log
setblock 379 169 287 minecraft:stripped_oak_log
fill 379 169 288 379 171 288 minecraft:red_terracotta
setblock 379 169 292 minecraft:stripped_oak_log
fill 379 169 293 379 172 293 minecraft:red_terracotta
setblock 379 169 296 minecraft:red_terracotta
setblock 379 169 297 minecraft:stripped_oak_log
fill 379 169 298 379 172 298 minecraft:red_terracotta
setblock 379 169 308 minecraft:shroomlight
fill 379 169 309 379 177 309 minecraft:stripped_oak_log
setblock 379 169 310 minecraft:shroomlight
setblock 379 169 312 minecraft:shroomlight
setblock 379 169 313 minecraft:red_terracotta
setblock 379 169 314 minecraft:shroomlight
fill 379 169 315 379 170 315 minecraft:red_terracotta
setblock 379 169 316 minecraft:shroomlight
setblock 380 169 276 minecraft:stripped_oak_log
setblock 380 169 291 minecraft:stripped_oak_log
fill 380 169 292 380 171 292 minecraft:red_terracotta
setblock 380 169 296 minecraft:stripped_oak_log
fill 380 169 297 380 171 297 minecraft:red_terracotta
setblock 380 169 309 minecraft:shroomlight
setblock 380 169 311 minecraft:shroomlight
setblock 380 169 313 minecraft:shroomlight
setblock 380 169 315 minecraft:shroomlight
setblock 380 169 316 minecraft:stripped_oak_log
fill 381 169 276 381 172 276 minecraft:red_terracotta
setblock 381 169 308 minecraft:shroomlight
setblock 381 169 310 minecraft:shroomlight
setblock 381 169 312 minecraft:shroomlight
setblock 381 169 314 minecraft:shroomlight
setblock 381 169 315 minecraft:stripped_oak_log
setblock 381 169 316 minecraft:shroomlight
setblock 382 169 309 minecraft:shroomlight
setblock 382 169 311 minecraft:shroomlight
setblock 382 169 313 minecraft:shroomlight
setblock 382 169 315 minecraft:shroomlight
setblock 383 169 308 minecraft:shroomlight
setblock 383 169 310 minecraft:shroomlight
setblock 383 169 312 minecraft:shroomlight
setblock 383 169 314 minecraft:shroomlight
setblock 383 169 316 minecraft:shroomlight
setblock 384 169 276 minecraft:red_terracotta
setblock 384 169 309 minecraft:shroomlight
setblock 384 169 311 minecraft:shroomlight
setblock 384 169 313 minecraft:shroomlight
setblock 384 169 315 minecraft:shroomlight
setblock 384 169 316 minecraft:red_terracotta
setblock 385 169 276 minecraft:stripped_oak_log
setblock 385 169 308 minecraft:shroomlight
setblock 385 169 310 minecraft:shroomlight
setblock 385 169 312 minecraft:shroomlight
setblock 385 169 314 minecraft:shroomlight
setblock 385 169 316 minecraft:shroomlight
fill 386 169 276 389 169 276 minecraft:red_terracotta
fill 386 169 316 389 169 316 minecraft:red_terracotta
setblock 390 169 276 minecraft:stripped_oak_log
setblock 390 169 316 minecraft:stripped_oak_log
fill 391 169 276 391 171 277 minecraft:red_terracotta
setblock 391 169 315 minecraft:stripped_oak_log
fill 391 169 316 394 169 316 minecraft:red_terracotta
fill 392 169 314 392 175 314 minecraft:green_concrete
fill 392 169 315 395 169 315 minecraft:red_terracotta
setblock 393 169 278 minecraft:stripped_oak_log
fill 393 169 314 396 169 314 minecraft:red_terracotta
setblock 394 169 277 minecraft:stripped_oak_log
fill 394 169 278 394 172 278 minecraft:red_terracotta
setblock 395 169 276 minecraft:stripped_oak_log
fill 395 169 277 395 172 277 minecraft:red_terracotta
setblock 395 169 316 minecraft:stripped_oak_log
fill 396 169 276 396 172 276 minecraft:red_terracotta
setblock 396 169 315 minecraft:stripped_oak_log
fill 396 169 316 399 169 316 minecraft:red_terracotta
setblock 397 169 313 minecraft:red_terracotta
setblock 397 169 314 minecraft:stripped_oak_log
fill 397 169 315 397 172 315 minecraft:red_terracotta
fill 398 169 276 398 170 276 minecraft:red_terracotta
setblock 398 169 278 minecraft:stripped_oak_log
setblock 398 169 313 minecraft:stripped_oak_log
fill 398 169 314 398 172 314 minecraft:red_terracotta
setblock 399 169 276 minecraft:shroomlight
setblock 399 169 277 minecraft:stripped_oak_log
setblock 399 169 278 minecraft:shroomlight
setblock 399 169 280 minecraft:shroomlight
setblock 399 169 282 minecraft:shroomlight
fill 399 169 313 399 170 313 minecraft:red_terracotta
setblock 400 169 276 minecraft:stripped_oak_log
setblock 400 169 277 minecraft:shroomlight
setblock 400 169 279 minecraft:shroomlight
setblock 400 169 281 minecraft:shroomlight
setblock 400 169 316 minecraft:stripped_oak_log
setblock 401 169 276 minecraft:shroomlight
setblock 401 169 278 minecraft:shroomlight
setblock 401 169 280 minecraft:shroomlight
setblock 401 169 282 minecraft:shroomlight
setblock 401 169 315 minecraft:stripped_oak_log
fill 401 169 316 401 172 316 minecraft:red_terracotta
setblock 402 169 277 minecraft:shroomlight
setblock 402 169 279 minecraft:shroomlight
setblock 402 169 281 minecraft:shroomlight
setblock 402 169 314 minecraft:stripped_oak_log
fill 402 169 315 402 172 315 minecraft:red_terracotta
setblock 403 169 276 minecraft:shroomlight
setblock 403 169 278 minecraft:shroomlight
setblock 403 169 280 minecraft:shroomlight
setblock 403 169 282 minecraft:shroomlight
fill 403 169 314 403 171 314 minecraft:red_terracotta
setblock 404 169 277 minecraft:shroomlight
setblock 404 169 279 minecraft:shroomlight
setblock 404 169 281 minecraft:shroomlight
setblock 405 169 276 minecraft:shroomlight
setblock 405 169 278 minecraft:shroomlight
setblock 405 169 280 minecraft:shroomlight
setblock 405 169 282 minecraft:shroomlight
setblock 405 169 316 minecraft:stripped_oak_log
fill 406 169 276 406 172 276 minecraft:red_terracotta
setblock 406 169 277 minecraft:shroomlight
setblock 406 169 279 minecraft:shroomlight
setblock 406 169 281 minecraft:shroomlight
setblock 406 169 314 minecraft:red_terracotta
setblock 406 169 315 minecraft:stripped_oak_log
fill 406 169 316 406 172 316 minecraft:red_terracotta
setblock 407 169 276 minecraft:shroomlight
setblock 407 169 278 minecraft:shroomlight
setblock 407 169 280 minecraft:shroomlight
setblock 407 169 282 minecraft:shroomlight
setblock 407 169 314 minecraft:stripped_oak_log
fill 407 169 315 410 169 315 minecraft:red_terracotta
fill 408 169 276 408 170 276 minecraft:red_terracotta
setblock 408 169 277 minecraft:shroomlight
setblock 408 169 279 minecraft:shroomlight
setblock 408 169 281 minecraft:shroomlight
fill 408 169 314 411 169 314 minecraft:red_terracotta
setblock 409 169 276 minecraft:shroomlight
setblock 409 169 278 minecraft:shroomlight
setblock 409 169 280 minecraft:shroomlight
setblock 409 169 282 minecraft:shroomlight
setblock 410 169 276 minecraft:stripped_oak_log
setblock 410 169 316 minecraft:stripped_oak_log
fill 411 169 276 414 169 276 minecraft:red_terracotta
setblock 411 169 315 minecraft:stripped_oak_log
fill 411 169 316 411 172 316 minecraft:red_terracotta
setblock 412 169 313 minecraft:red_terracotta
setblock 412 169 314 minecraft:stripped_oak_log
fill 412 169 315 412 172 315 minecraft:red_terracotta
setblock 413 169 313 minecraft:stripped_oak_log
fill 413 169 314 413 172 314 minecraft:red_terracotta
fill 414 169 310 414 169 311 minecraft:red_terracotta
setblock 414 169 312 minecraft:stripped_oak_log
fill 414 169 313 414 172 313 minecraft:red_terracotta
setblock 415 169 276 minecraft:stripped_oak_log
fill 415 169 277 416 171 277 minecraft:red_terracotta
setblock 415 169 290 minecraft:red_terracotta
setblock 415 169 291 minecraft:stripped_oak_log
fill 415 169 292 415 169 295 minecraft:red_terracotta
setblock 415 169 296 minecraft:stripped_oak_log
fill 415 169 297 415 169 300 minecraft:red_terracotta
setblock 415 169 306 minecraft:stripped_oak_log
fill 415 169 307 415 172 307 minecraft:red_terracotta
setblock 415 169 311 minecraft:stripped_oak_log
fill 415 169 312 415 172 312 minecraft:red_terracotta
setblock 415 169 316 minecraft:stripped_oak_log
fill 416 169 276 416 172 276 minecraft:red_terracotta
fill 416 169 287 416 169 289 minecraft:red_terracotta
setblock 416 169 290 minecraft:stripped_oak_log
fill 416 169 291 416 169 294 minecraft:red_terracotta
setblock 416 169 295 minecraft:stripped_oak_log
fill 416 169 296 416 169 299 minecraft:red_terracotta
setblock 416 169 300 minecraft:stripped_oak_log
fill 416 169 301 416 169 304 minecraft:red_terracotta
setblock 416 169 305 minecraft:stripped_oak_log
fill 416 169 306 416 172 306 minecraft:red_terracotta
setblock 416 169 310 minecraft:stripped_oak_log
fill 416 169 311 416 172 311 minecraft:red_terracotta
setblock 416 169 315 minecraft:stripped_oak_log
fill 416 169 316 416 172 316 minecraft:red_terracotta
setblock 417 169 279 minecraft:stripped_oak_log
fill 417 169 280 417 170 282 minecraft:red_terracotta
setblock 417 169 284 minecraft:stripped_oak_log
fill 417 169 285 417 172 285 minecraft:red_terracotta
setblock 417 169 289 minecraft:stripped_oak_log
fill 417 169 290 417 172 290 minecraft:red_terracotta
setblock 417 169 294 minecraft:stripped_oak_log
fill 417 169 295 417 169 298 minecraft:red_terracotta
setblock 417 169 299 minecraft:stripped_oak_log
fill 417 169 300 417 169 303 minecraft:red_terracotta
setblock 417 169 304 minecraft:stripped_oak_log
fill 417 169 305 417 172 305 minecraft:red_terracotta
setblock 417 169 309 minecraft:stripped_oak_log
fill 417 169 310 417 172 310 minecraft:red_terracotta
setblock 417 169 314 minecraft:stripped_oak_log
fill 417 169 315 417 172 315 minecraft:red_terracotta
setblock 377 170 277 minecraft:red_terracotta
setblock 377 170 278 minecraft:stripped_oak_log
fill 377 170 279 377 170 282 minecraft:red_terracotta
setblock 377 170 283 minecraft:stripped_oak_log
fill 377 170 284 377 170 287 minecraft:red_terracotta
setblock 377 170 288 minecraft:stripped_oak_log
fill 377 170 289 377 170 292 minecraft:red_terracotta
setblock 377 170 293 minecraft:stripped_oak_log
fill 377 170 294 377 170 297 minecraft:red_terracotta
setblock 377 170 298 minecraft:stripped_oak_log
fill 377 170 299 377 170 302 minecraft:red_terracotta
setblock 377 170 303 minecraft:stripped_oak_log
fill 377 170 304 377 173 304 minecraft:red_terracotta
setblock 377 170 308 minecraft:stripped_oak_log
fill 377 170 309 377 171 310 minecraft:red_terracotta
setblock 377 170 312 minecraft:red_terracotta
setblock 377 170 313 minecraft:stripped_oak_log
fill 377 170 314 377 171 314 minecraft:red_terracotta
fill 377 170 316 377 171 316 minecraft:red_terracotta
setblock 378 170 277 minecraft:stripped_oak_log
fill 378 170 278 378 173 278 minecraft:red_terracotta
setblock 378 170 287 minecraft:stripped_oak_log
fill 378 170 288 378 173 288 minecraft:red_terracotta
setblock 378 170 292 minecraft:stripped_oak_log
fill 378 170 293 378 170 296 minecraft:red_terracotta
setblock 378 170 297 minecraft:stripped_oak_log
fill 378 170 298 378 170 301 minecraft:red_terracotta
setblock 378 170 302 minecraft:stripped_oak_log
fill 378 170 303 378 173 303 minecraft:red_terracotta
setblock 378 170 307 minecraft:stripped_oak_log
fill 378 170 308 378 171 309 minecraft:red_terracotta
setblock 378 170 311 minecraft:red_terracotta
fill 378 170 312 379 170 312 minecraft:stripped_oak_log
fill 378 170 313 378 171 313 minecraft:red_terracotta
fill 378 170 315 378 171 315 minecraft:red_terracotta
setblock 379 170 276 minecraft:stripped_oak_log
fill 379 170 277 380 172 277 minecraft:red_terracotta
setblock 379 170 287 minecraft:red_terracotta
setblock 379 170 291 minecraft:stripped_oak_log
fill 379 170 292 379 173 292 minecraft:red_terracotta
setblock 379 170 295 minecraft:red_terracotta
setblock 379 170 296 minecraft:stripped_oak_log
fill 379 170 297 379 173 297 minecraft:red_terracotta
fill 379 170 308 379 171 308 minecraft:stripped_oak_log
fill 379 170 310 379 171 311 minecraft:stripped_oak_log
fill 379 170 313 379 171 314 minecraft:stripped_oak_log
setblock 379 170 316 minecraft:stripped_oak_log
fill 380 170 276 380 173 276 minecraft:red_terracotta
setblock 380 170 290 minecraft:stripped_oak_log
fill 380 170 291 380 171 291 minecraft:red_terracotta
setblock 380 170 295 minecraft:stripped_oak_log
fill 380 170 296 380 171 296 minecraft:red_terracotta
fill 380 170 309 380 171 309 minecraft:stripped_oak_log
fill 380 170 311 380 171 311 minecraft:stripped_oak_log
fill 380 170 313 380 171 313 minecraft:stripped_oak_log
setblock 380 170 315 minecraft:stripped_oak_log
fill 380 170 316 381 171 316 minecraft:red_terracotta
fill 381 170 308 381 171 308 minecraft:stripped_oak_log
fill 381 170 310 381 171 310 minecraft:stripped_oak_log
fill 381 170 312 381 171 312 minecraft:stripped_oak_log
fill 381 170 314 381 171 314 minecraft:stripped_oak_log
setblock 381 170 315 minecraft:red_terracotta
fill 382 170 309 382 171 309 minecraft:stripped_oak_log
fill 382 170 311 382 171 311 minecraft:stripped_oak_log
fill 382 170 313 382 171 313 minecraft:stripped_oak_log
fill 382 170 315 382 171 315 minecraft:stripped_oak_log
fill 383 170 308 383 171 308 minecraft:stripped_oak_log
fill 383 170 310 383 171 310 minecraft:stripped_oak_log
fill 383 170 312 383 171 312 minecraft:stripped_oak_log
fill 383 170 314 383 171 314 minecraft:stripped_oak_log
setblock 383 170 316 minecraft:red_terracotta
setblock 384 170 276 minecraft:stripped_oak_log
fill 384 170 309 384 171 309 minecraft:stripped_oak_log
fill 384 170 311 384 171 311 minecraft:stripped_oak_log
fill 384 170 313 384 171 313 minecraft:stripped_oak_log
fill 384 170 315 384 170 316 minecraft:stripped_oak_log
fill 385 170 276 388 170 276 minecraft:red_terracotta
fill 385 170 308 385 171 308 minecraft:stripped_oak_log
fill 385 170 310 385 171 310 minecraft:stripped_oak_log
fill 385 170 312 385 171 312 minecraft:stripped_oak_log
fill 385 170 314 385 171 314 minecraft:stripped_oak_log
fill 385 170 316 388 170 316 minecraft:red_terracotta
setblock 389 170 276 minecraft:stripped_oak_log
fill 389 170 277 390 172 277 minecraft:red_terracotta
setblock 389 170 316 minecraft:stripped_oak_log
fill 390 170 276 390 173 276 minecraft:red_terracotta
setblock 390 170 315 minecraft:stripped_oak_log
fill 390 170 316 393 170 316 minecraft:red_terracotta
fill 391 170 315 394 170 315 minecraft:red_terracotta
setblock 392 170 278 minecraft:stripped_oak_log
setblock 393 170 276 minecraft:red_terracotta
setblock 393 170 277 minecraft:stripped_oak_log
fill 393 170 278 393 173 278 minecraft:red_terracotta
fill 393 170 314 395 170 314 minecraft:red_terracotta
setblock 394 170 276 minecraft:stripped_oak_log
fill 394 170 277 394 173 277 minecraft:red_terracotta
setblock 394 170 316 minecraft:stripped_oak_log
fill 395 170 276 395 173 276 minecraft:red_terracotta
setblock 395 170 315 minecraft:stripped_oak_log
fill 395 170 316 398 170 316 minecraft:red_terracotta
setblock 396 170 313 minecraft:red_terracotta
setblock 396 170 314 minecraft:stripped_oak_log
fill 396 170 315 396 173 315 minecraft:red_terracotta
setblock 397 170 277 minecraft:red_terracotta
setblock 397 170 278 minecraft:stripped_oak_log
setblock 397 170 313 minecraft:stripped_oak_log
fill 397 170 314 397 173 314 minecraft:red_terracotta
setblock 398 170 277 minecraft:stripped_oak_log
fill 398 170 278 399 171 278 minecraft:red_terracotta
setblock 398 170 313 minecraft:red_terracotta
setblock 399 170 276 minecraft:stripped_oak_log
fill 399 170 277 400 171 277 minecraft:red_terracotta
fill 399 170 280 399 171 280 minecraft:stripped_oak_log
fill 399 170 282 399 171 282 minecraft:stripped_oak_log
setblock 399 170 316 minecraft:stripped_oak_log
fill 400 170 276 401 171 276 minecraft:red_terracotta
fill 400 170 279 400 171 279 minecraft:stripped_oak_log
fill 400 170 281 400 171 281 minecraft:stripped_oak_log
setblock 400 170 315 minecraft:stripped_oak_log
fill 400 170 316 400 173 316 minecraft:red_terracotta
fill 401 170 278 401 171 278 minecraft:stripped_oak_log
fill 401 170 280 401 171 280 minecraft:stripped_oak_log
fill 401 170 282 401 171 282 minecraft:stripped_oak_log
setblock 401 170 314 minecraft:stripped_oak_log
fill 401 170 315 401 173 315 minecraft:red_terracotta
setblock 402 170 277 minecraft:red_terracotta
fill 402 170 279 402 171 279 minecraft:stripped_oak_log
fill 402 170 281 402 171 281 minecraft:stripped_oak_log
fill 402 170 314 402 172 314 minecraft:red_terracotta
setblock 403 170 276 minecraft:red_terracotta
fill 403 170 277 403 170 278 minecraft:stripped_oak_log
fill 403 170 280 403 171 280 minecraft:stripped_oak_log
fill 403 170 282 403 171 282 minecraft:stripped_oak_log
setblock 404 170 276 minecraft:stripped_oak_log
fill 404 170 277 404 171 277 minecraft:red_terracotta
fill 404 170 279 404 171 279 minecraft:stripped_oak_log
fill 404 170 281 404 171 281 minecraft:stripped_oak_log
setblock 404 170 316 minecraft:stripped_oak_log
fill 405 170 276 405 171 276 minecraft:red_terracotta
fill 405 170 278 405 171 278 minecraft:stripped_oak_log
fill 405 170 280 405 171 280 minecraft:stripped_oak_log
fill 405 170 282 405 171 282 minecraft:stripped_oak_log
setblock 405 170 315 minecraft:stripped_oak_log
fill 405 170 316 405 173 316 minecraft:red_terracotta
fill 406 170 277 406 171 277 minecraft:stripped_oak_log
fill 406 170 279 406 171 279 minecraft:stripped_oak_log
fill 406 170 281 406 171 281 minecraft:stripped_oak_log
setblock 406 170 314 minecraft:stripped_oak_log
fill 406 170 315 409 170 315 minecraft:red_terracotta
fill 407 170 276 407 171 276 minecraft:red_terracotta
fill 407 170 278 407 171 278 minecraft:stripped_oak_log
fill 407 170 280 407 171 280 minecraft:stripped_oak_log
fill 407 170 282 407 171 282 minecraft:stripped_oak_log
fill 407 170 314 410 170 314 minecraft:red_terracotta
fill 408 170 277 408 171 277 minecraft:stripped_oak_log
fill 408 170 279 408 171 279 minecraft:stripped_oak_log
fill 408 170 281 408 171 281 minecraft:stripped_oak_log
setblock 409 170 276 minecraft:stripped_oak_log
fill 409 170 278 409 171 278 minecraft:stripped_oak_log
fill 409 170 280 409 171 280 minecraft:stripped_oak_log
fill 409 170 282 409 171 282 minecraft:stripped_oak_log
setblock 409 170 316 minecraft:stripped_oak_log
fill 410 170 276 413 170 276 minecraft:red_terracotta
setblock 410 170 315 minecraft:stripped_oak_log
fill 410 170 316 410 173 316 minecraft:red_terracotta
setblock 411 170 314 minecraft:stripped_oak_log
fill 411 170 315 411 173 315 minecraft:red_terracotta
setblock 412 170 313 minecraft:stripped_oak_log
fill 412 170 314 412 173 314 minecraft:red_terracotta
setblock 413 170 277 minecraft:stripped_oak_log
fill 413 170 313 413 172 313 minecraft:red_terracotta
setblock 414 170 276 minecraft:stripped_oak_log
fill 414 170 277 414 173 277 minecraft:red_terracotta
setblock 414 170 310 minecraft:red_terracotta
setblock 414 170 311 minecraft:stripped_oak_log
fill 414 170 312 414 171 312 minecraft:red_terracotta
setblock 414 170 316 minecraft:stripped_oak_log
fill 415 170 276 415 173 276 minecraft:red_terracotta
setblock 415 170 290 minecraft:stripped_oak_log
fill 415 170 291 415 170 294 minecraft:red_terracotta
setblock 415 170 295 minecraft:stripped_oak_log
fill 415 170 296 415 170 299 minecraft:red_terracotta
setblock 415 170 300 minecraft:stripped_oak_log
fill 415 170 301 415 170 304 minecraft:red_terracotta
setblock 415 170 305 minecraft:stripped_oak_log
fill 415 170 306 415 172 306 minecraft:red_terracotta
setblock 415 170 310 minecraft:stripped_oak_log
fill 415 170 311 415 173 311 minecraft:red_terracotta
setblock 415 170 315 minecraft:stripped_oak_log
fill 415 170 316 415 173 316 minecraft:red_terracotta
fill 416 170 287 416 170 288 minecraft:red_terracotta
setblock 416 170 289 minecraft:stripped_oak_log
fill 416 170 290 416 170 293 minecraft:red_terracotta
setblock 416 170 294 minecraft:stripped_oak_log
fill 416 170 295 416 170 298 minecraft:red_terracotta
setblock 416 170 299 minecraft:stripped_oak_log
fill 416 170 300 416 170 303 minecraft:red_terracotta
setblock 416 170 304 minecraft:stripped_oak_log
fill 416 170 305 416 173 305 minecraft:red_terracotta
setblock 416 170 309 minecraft:stripped_oak_log
fill 416 170 310 416 173 310 minecraft:red_terracotta
setblock 416 170 314 minecraft:stripped_oak_log
fill 416 170 315 416 173 315 minecraft:red_terracotta
setblock 417 170 277 minecraft:red_terracotta
setblock 417 170 278 minecraft:stripped_oak_log
fill 417 170 279 417 173 279 minecraft:red_terracotta
setblock 417 170 283 minecraft:stripped_oak_log
fill 417 170 284 417 171 284 minecraft:red_terracotta
setblock 417 170 288 minecraft:stripped_oak_log
fill 417 170 289 417 173 289 minecraft:red_terracotta
setblock 417 170 293 minecraft:stripped_oak_log
fill 417 170 294 417 170 297 minecraft:red_terracotta
setblock 417 170 298 minecraft:stripped_oak_log
fill 417 170 299 417 170 302 minecraft:red_terracotta
setblock 417 170 303 minecraft:stripped_oak_log
fill 417 170 304 417 173 304 minecraft:red_terracotta
setblock 417 170 308 minecraft:stripped_oak_log
fill 417 170 309 417 173 309 minecraft:red_terracotta
setblock 417 170 313 minecraft:stripped_oak_log
fill 417 170 314 417 173 314 minecraft:red_terracotta
setblock 377 171 277 minecraft:stripped_oak_log
fill 377 171 278 377 171 281 minecraft:red_terracotta
setblock 377 171 282 minecraft:stripped_oak_log
fill 377 171 283 377 171 286 minecraft:red_terracotta
setblock 377 171 287 minecraft:stripped_oak_log
fill 377 171 288 377 171 291 minecraft:red_terracotta
setblock 377 171 292 minecraft:stripped_oak_log
fill 377 171 293 377 171 296 minecraft:red_terracotta
setblock 377 171 297 minecraft:stripped_oak_log
fill 377 171 298 377 171 301 minecraft:red_terracotta
setblock 377 171 302 minecraft:stripped_oak_log
fill 377 171 303 377 174 303 minecraft:red_terracotta
setblock 377 171 307 minecraft:stripped_oak_log
setblock 377 171 308 minecraft:red_terracotta
setblock 377 171 312 minecraft:stripped_oak_log
fill 377 171 313 377 174 313 minecraft:red_terracotta
setblock 378 171 276 minecraft:stripped_oak_log
fill 378 171 277 378 174 277 minecraft:red_terracotta
fill 378 171 279 378 172 279 minecraft:red_terracotta
setblock 378 171 286 minecraft:stripped_oak_log
fill 378 171 287 378 173 287 minecraft:red_terracotta
setblock 378 171 291 minecraft:stripped_oak_log
fill 378 171 292 378 171 295 minecraft:red_terracotta
setblock 378 171 296 minecraft:stripped_oak_log
fill 378 171 297 378 171 300 minecraft:red_terracotta
setblock 378 171 301 minecraft:stripped_oak_log
fill 378 171 302 378 174 302 minecraft:red_terracotta
setblock 378 171 311 minecraft:stripped_oak_log
fill 378 171 312 378 172 312 minecraft:red_terracotta
setblock 378 171 316 minecraft:stripped_oak_log
fill 379 171 276 379 174 276 minecraft:red_terracotta
setblock 379 171 290 minecraft:stripped_oak_log
fill 379 171 291 379 173 291 minecraft:red_terracotta
setblock 379 171 295 minecraft:stripped_oak_log
fill 379 171 296 379 174 296 minecraft:red_terracotta
setblock 379 171 299 minecraft:red_terracotta
setblock 379 171 300 minecraft:stripped_oak_log
setblock 379 171 312 minecraft:stripped_oak_log
setblock 379 171 315 minecraft:stripped_oak_log
setblock 379 171 316 minecraft:red_terracotta
setblock 380 171 294 minecraft:stripped_oak_log
fill 380 171 295 380 172 295 minecraft:red_terracotta
setblock 380 171 315 minecraft:red_terracotta
fill 381 171 315 381 177 315 minecraft:stripped_oak_log
setblock 382 171 276 minecraft:red_terracotta
setblock 383 171 276 minecraft:stripped_oak_log
setblock 383 171 316 minecraft:stripped_oak_log
fill 384 171 276 387 171 276 minecraft:red_terracotta
setblock 384 171 315 minecraft:stripped_oak_log
fill 384 171 316 387 171 316 minecraft:red_terracotta
setblock 388 171 276 minecraft:stripped_oak_log
fill 388 171 277 388 174 277 minecraft:red_terracotta
setblock 388 171 316 minecraft:stripped_oak_log
fill 389 171 276 389 174 276 minecraft:red_terracotta
fill 389 171 316 392 171 316 minecraft:red_terracotta
fill 390 171 315 393 171 315 minecraft:red_terracotta
setblock 391 171 278 minecraft:stripped_oak_log
setblock 392 171 276 minecraft:red_terracotta
setblock 392 171 277 minecraft:stripped_oak_log
fill 392 171 278 392 174 278 minecraft:red_terracotta
setblock 393 171 276 minecraft:stripped_oak_log
fill 393 171 277 393 174 277 minecraft:red_terracotta
fill 393 171 314 394 171 314 minecraft:red_terracotta
setblock 393 171 316 minecraft:stripped_oak_log
fill 394 171 276 394 174 276 minecraft:red_terracotta
setblock 394 171 315 minecraft:stripped_oak_log
fill 394 171 316 397 171 316 minecraft:red_terracotta
setblock 395 171 278 minecraft:red_terracotta
setblock 395 171 314 minecraft:stripped_oak_log
fill 395 171 315 395 174 315 minecraft:red_terracotta
setblock 396 171 278 minecraft:stripped_oak_log
fill 396 171 314 396 174 314 minecraft:red_terracotta
setblock 397 171 277 minecraft:stripped_oak_log
fill 397 171 278 397 174 278 minecraft:red_terracotta
setblock 398 171 276 minecraft:stripped_oak_log
fill 398 171 277 398 174 277 minecraft:red_terracotta
setblock 398 171 316 minecraft:stripped_oak_log
setblock 399 171 276 minecraft:red_terracotta
setblock 399 171 315 minecraft:stripped_oak_log
fill 399 171 316 399 174 316 minecraft:red_terracotta
setblock 400 171 314 minecraft:stripped_oak_log
fill 400 171 315 400 174 315 minecraft:red_terracotta
fill 401 171 314 401 172 314 minecraft:red_terracotta
setblock 402 171 277 minecraft:stripped_oak_log
setblock 403 171 276 minecraft:stripped_oak_log
fill 403 171 277 403 172 277 minecraft:red_terracotta
setblock 403 171 278 minecraft:stripped_oak_log
setblock 403 171 316 minecraft:stripped_oak_log
fill 404 171 276 404 174 276 minecraft:red_terracotta
setblock 404 171 315 minecraft:stripped_oak_log
fill 404 171 316 404 174 316 minecraft:red_terracotta
setblock 405 171 314 minecraft:stripped_oak_log
fill 405 171 315 408 171 315 minecraft:red_terracotta
fill 406 171 314 409 171 314 minecraft:red_terracotta
setblock 408 171 276 minecraft:stripped_oak_log
setblock 408 171 316 minecraft:stripped_oak_log
fill 409 171 276 412 171 276 minecraft:red_terracotta
setblock 409 171 315 minecraft:stripped_oak_log
fill 409 171 316 409 174 316 minecraft:red_terracotta
setblock 410 171 314 minecraft:stripped_oak_log
fill 410 171 315 410 174 315 minecraft:red_terracotta
fill 411 171 314 411 174 314 minecraft:red_terracotta
setblock 412 171 277 minecraft:stripped_oak_log
setblock 412 171 313 minecraft:red_terracotta
setblock 413 171 276 minecraft:stripped_oak_log
fill 413 171 277 413 174 277 minecraft:red_terracotta
setblock 413 171 316 minecraft:stripped_oak_log
fill 414 171 276 414 174 276 minecraft:red_terracotta
setblock 414 171 295 minecraft:stripped_oak_log
fill 414 171 296 417 171 296 minecraft:red_terracotta
setblock 414 171 311 minecraft:red_terracotta
setblock 414 171 315 minecraft:stripped_oak_log
fill 414 171 316 414 174 316 minecraft:red_terracotta
fill 415 171 291 415 171 293 minecraft:red_terracotta
setblock 415 171 294 minecraft:stripped_oak_log
fill 415 171 295 417 172 295 minecraft:red_terracotta
fill 415 171 297 415 171 298 minecraft:red_terracotta
setblock 415 171 299 minecraft:stripped_oak_log
fill 415 171 300 415 171 303 minecraft:red_terracotta
setblock 415 171 304 minecraft:stripped_oak_log
fill 415 171 305 415 172 305 minecraft:red_terracotta
setblock 415 171 309 minecraft:stripped_oak_log
fill 415 171 310 415 173 310 minecraft:red_terracotta
setblock 415 171 314 minecraft:stripped_oak_log
fill 415 171 315 415 174 315 minecraft:red_terracotta
setblock 416 171 278 minecraft:stripped_oak_log
setblock 416 171 288 minecraft:stripped_oak_log
fill 416 171 289 416 171 292 minecraft:red_terracotta
setblock 416 171 293 minecraft:stripped_oak_log
fill 416 171 294 417 173 294 minecraft:red_terracotta
setblock 416 171 297 minecraft:red_terracotta
setblock 416 171 298 minecraft:stripped_oak_log
fill 416 171 299 416 171 302 minecraft:red_terracotta
setblock 416 171 303 minecraft:stripped_oak_log
fill 416 171 304 416 174 304 minecraft:red_terracotta
setblock 416 171 308 minecraft:stripped_oak_log
fill 416 171 309 416 174 309 minecraft:red_terracotta
setblock 416 171 313 minecraft:stripped_oak_log
fill 416 171 314 416 174 314 minecraft:red_terracotta
setblock 417 171 277 minecraft:stripped_oak_log
fill 417 171 278 417 174 278 minecraft:red_terracotta
fill 417 171 280 417 171 281 minecraft:red_terracotta
setblock 417 171 282 minecraft:stripped_oak_log
setblock 417 171 283 minecraft:red_terracotta
setblock 417 171 287 minecraft:stripped_oak_log
fill 417 171 288 417 174 288 minecraft:red_terracotta
setblock 417 171 292 minecraft:stripped_oak_log
fill 417 171 293 417 174 293 minecraft:red_terracotta
setblock 417 171 297 minecraft:stripped_oak_log
fill 417 171 298 417 171 301 minecraft:red_terracotta
setblock 417 171 302 minecraft:stripped_oak_log
fill 417 171 303 417 174 303 minecraft:red_terracotta
setblock 417 171 307 minecraft:stripped_oak_log
fill 417 171 308 417 174 308 minecraft:red_terracotta
setblock 417 171 312 minecraft:stripped_oak_log
fill 417 171 313 417 174 313 minecraft:red_terracotta
fill 376 172 275 376 175 317 minecraft:red_terracotta
fill 377 172 275 418 175 275 minecraft:red_terracotta
setblock 377 172 276 minecraft:stripped_oak_log
fill 377 172 277 377 172 280 minecraft:red_terracotta
setblock 377 172 281 minecraft:stripped_oak_log
fill 377 172 282 377 172 285 minecraft:red_terracotta
setblock 377 172 286 minecraft:stripped_oak_log
fill 377 172 287 377 172 290 minecraft:red_terracotta
setblock 377 172 291 minecraft:stripped_oak_log
fill 377 172 292 377 172 295 minecraft:red_terracotta
setblock 377 172 296 minecraft:stripped_oak_log
fill 377 172 297 377 172 300 minecraft:red_terracotta
setblock 377 172 301 minecraft:stripped_oak_log
fill 377 172 302 377 175 302 minecraft:red_terracotta
setblock 377 172 306 minecraft:stripped_oak_log
fill 377 172 307 377 173 307 minecraft:red_terracotta
setblock 377 172 308 minecraft:shroomlight
fill 377 172 309 377 173 309 minecraft:red_terracotta
setblock 377 172 310 minecraft:shroomlight
setblock 377 172 311 minecraft:stripped_oak_log
setblock 377 172 312 minecraft:shroomlight
setblock 377 172 314 minecraft:shroomlight
setblock 377 172 316 minecraft:shroomlight
fill 377 172 317 418 175 317 minecraft:red_terracotta
fill 378 172 276 378 175 276 minecraft:red_terracotta
setblock 378 172 286 minecraft:red_terracotta
setblock 378 172 290 minecraft:stripped_oak_log
fill 378 172 291 378 172 294 minecraft:red_terracotta
setblock 378 172 295 minecraft:stripped_oak_log
fill 378 172 296 378 172 299 minecraft:red_terracotta
setblock 378 172 300 minecraft:stripped_oak_log
fill 378 172 301 378 175 301 minecraft:red_terracotta
fill 378 172 308 378 177 308 minecraft:stripped_oak_log
setblock 378 172 309 minecraft:shroomlight
fill 378 172 310 378 177 310 minecraft:stripped_oak_log
setblock 378 172 311 minecraft:shroomlight
setblock 378 172 313 minecraft:shroomlight
setblock 378 172 315 minecraft:shroomlight
fill 378 172 316 378 175 316 minecraft:red_terracotta
setblock 379 172 289 minecraft:stripped_oak_log
setblock 379 172 290 minecraft:red_terracotta
setblock 379 172 294 minecraft:stripped_oak_log
fill 379 172 295 379 174 295 minecraft:red_terracotta
setblock 379 172 299 minecraft:stripped_oak_log
setblock 379 172 300 minecraft:red_terracotta
setblock 379 172 308 minecraft:shroomlight
setblock 379 172 310 minecraft:shroomlight
fill 379 172 311 379 177 311 minecraft:stripped_oak_log
setblock 379 172 312 minecraft:shroomlight
fill 379 172 313 379 177 313 minecraft:stripped_oak_log
setblock 379 172 314 minecraft:shroomlight
setblock 379 172 315 minecraft:red_terracotta
setblock 379 172 316 minecraft:shroomlight
setblock 380 172 293 minecraft:stripped_oak_log
setblock 380 172 294 minecraft:red_terracotta
setblock 380 172 309 minecraft:shroomlight
setblock 380 172 311 minecraft:shroomlight
setblock 380 172 313 minecraft:shroomlight
setblock 380 172 315 minecraft:shroomlight
fill 380 172 316 380 173 316 minecraft:red_terracotta
setblock 381 172 308 minecraft:shroomlight
setblock 381 172 310 minecraft:shroomlight
setblock 381 172 312 minecraft:shroomlight
setblock 381 172 314 minecraft:shroomlight
setblock 381 172 316 minecraft:shroomlight
setblock 382 172 276 minecraft:stripped_oak_log
setblock 382 172 309 minecraft:shroomlight
setblock 382 172 311 minecraft:shroomlight
setblock 382 172 313 minecraft:shroomlight
setblock 382 172 315 minecraft:shroomlight
fill 382 172 316 382 177 316 minecraft:stripped_oak_log
fill 383 172 276 386 172 276 minecraft:red_terracotta
setblock 383 172 308 minecraft:shroomlight
setblock 383 172 310 minecraft:shroomlight
setblock 383 172 312 minecraft:shroomlight
setblock 383 172 314 minecraft:shroomlight
setblock 383 172 316 minecraft:shroomlight
setblock 384 172 309 minecraft:shroomlight
setblock 384 172 311 minecraft:shroomlight
setblock 384 172 313 minecraft:shroomlight
setblock 384 172 315 minecraft:shroomlight
setblock 384 172 316 minecraft:red_terracotta
setblock 385 172 308 minecraft:shroomlight
setblock 385 172 310 minecraft:shroomlight
setblock 385 172 312 minecraft:shroomlight
setblock 385 172 314 minecraft:shroomlight
setblock 385 172 316 minecraft:shroomlight
setblock 386 172 316 minecraft:red_terracotta
setblock 387 172 276 minecraft:stripped_oak_log
fill 387 172 277 387 175 277 minecraft:red_terracotta
setblock 387 172 316 minecraft:stripped_oak_log
fill 388 172 276 388 175 276 minecraft:red_terracotta
fill 388 172 316 391 172 316 minecraft:red_terracotta
fill 390 172 315 392 172 315 minecraft:red_terracotta
setblock 391 172 276 minecraft:red_terracotta
setblock 391 172 277 minecraft:stripped_oak_log
fill 391 172 278 391 175 278 minecraft:red_terracotta
setblock 392 172 276 minecraft:stripped_oak_log
fill 392 172 277 392 175 277 minecraft:red_terracotta
setblock 392 172 316 minecraft:stripped_oak_log
fill 393 172 276 393 175 276 minecraft:red_terracotta
fill 393 172 314 393 174 314 minecraft:green_concrete
setblock 393 172 315 minecraft:stripped_oak_log
fill 393 172 316 396 172 316 minecraft:red_terracotta
setblock 394 172 314 minecraft:stripped_oak_log
fill 394 172 315 394 175 315 minecraft:red_terracotta
setblock 395 172 278 minecraft:stripped_oak_log
fill 395 172 314 395 174 314 minecraft:red_terracotta
setblock 396 172 277 minecraft:stripped_oak_log
fill 396 172 278 396 175 278 minecraft:red_terracotta
setblock 397 172 276 minecraft:stripped_oak_log
fill 397 172 277 397 175 277 minecraft:red_terracotta
setblock 397 172 316 minecraft:stripped_oak_log
fill 398 172 276 398 175 276 minecraft:red_terracotta
fill 398 172 278 398 173 278 minecraft:red_terracotta
setblock 398 172 315 minecraft:stripped_oak_log
fill 398 172 316 398 175 316 minecraft:red_terracotta
setblock 399 172 276 minecraft:shroomlight
fill 399 172 277 399 173 277 minecraft:red_terracotta
setblock 399 172 278 minecraft:shroomlight
setblock 399 172 280 minecraft:shroomlight
setblock 399 172 282 minecraft:shroomlight
setblock 399 172 314 minecraft:stripped_oak_log
fill 399 172 315 399 175 315 minecraft:red_terracotta
fill 400 172 276 400 173 276 minecraft:red_terracotta
setblock 400 172 277 minecraft:shroomlight
fill 400 172 278 400 183 278 minecraft:stripped_oak_log
setblock 400 172 279 minecraft:shroomlight
setblock 400 172 281 minecraft:shroomlight
fill 400 172 314 400 173 314 minecraft:red_terracotta
setblock 401 172 276 minecraft:shroomlight
setblock 401 172 277 minecraft:stripped_oak_log
setblock 401 172 278 minecraft:shroomlight
setblock 401 172 280 minecraft:shroomlight
setblock 401 172 282 minecraft:shroomlight
setblock 402 172 276 minecraft:stripped_oak_log
setblock 402 172 277 minecraft:shroomlight
setblock 402 172 279 minecraft:shroomlight
setblock 402 172 281 minecraft:shroomlight
setblock 402 172 316 minecraft:stripped_oak_log
setblock 403 172 276 minecraft:shroomlight
setblock 403 172 278 minecraft:shroomlight
setblock 403 172 280 minecraft:shroomlight
setblock 403 172 282 minecraft:shroomlight
setblock 403 172 315 minecraft:stripped_oak_log
fill 403 172 316 403 175 316 minecraft:red_terracotta
setblock 404 172 277 minecraft:shroomlight
setblock 404 172 279 minecraft:shroomlight
setblock 404 172 281 minecraft:shroomlight
fill 404 172 315 407 172 315 minecraft:red_terracotta
setblock 405 172 276 minecraft:shroomlight
setblock 405 172 278 minecraft:shroomlight
setblock 405 172 280 minecraft:shroomlight
setblock 405 172 282 minecraft:shroomlight
setblock 406 172 277 minecraft:shroomlight
setblock 406 172 279 minecraft:shroomlight
setblock 406 172 281 minecraft:shroomlight
setblock 407 172 276 minecraft:shroomlight
setblock 407 172 278 minecraft:shroomlight
setblock 407 172 280 minecraft:shroomlight
setblock 407 172 282 minecraft:shroomlight
setblock 407 172 316 minecraft:stripped_oak_log
fill 408 172 276 408 175 276 minecraft:red_terracotta
setblock 408 172 277 minecraft:shroomlight
setblock 408 172 279 minecraft:shroomlight
setblock 408 172 281 minecraft:shroomlight
setblock 408 172 314 minecraft:red_terracotta
setblock 408 172 315 minecraft:stripped_oak_log
fill 408 172 316 408 175 316 minecraft:red_terracotta
setblock 409 172 276 minecraft:shroomlight
setblock 409 172 278 minecraft:shroomlight
setblock 409 172 280 minecraft:shroomlight
setblock 409 172 282 minecraft:shroomlight
setblock 409 172 314 minecraft:stripped_oak_log
fill 409 172 315 409 175 315 minecraft:red_terracotta
fill 410 172 276 411 172 276 minecraft:red_terracotta
fill 410 172 314 410 173 314 minecraft:red_terracotta
setblock 411 172 277 minecraft:stripped_oak_log
setblock 412 172 276 minecraft:stripped_oak_log
fill 412 172 277 412 175 277 minecraft:red_terracotta
setblock 412 172 316 minecraft:stripped_oak_log
fill 413 172 276 413 175 276 minecraft:red_terracotta
setblock 413 172 315 minecraft:stripped_oak_log
fill 413 172 316 413 175 316 minecraft:red_terracotta
fill 414 172 295 414 172 298 minecraft:red_terracotta
setblock 414 172 314 minecraft:stripped_oak_log
fill 414 172 315 414 175 315 minecraft:red_terracotta
setblock 415 172 277 minecraft:red_terracotta
fill 415 172 291 415 172 292 minecraft:red_terracotta
setblock 415 172 293 minecraft:stripped_oak_log
fill 415 172 294 415 175 294 minecraft:red_terracotta
fill 415 172 296 415 172 297 minecraft:red_terracotta
setblock 415 172 298 minecraft:stripped_oak_log
fill 415 172 299 415 172 302 minecraft:red_terracotta
setblock 415 172 303 minecraft:stripped_oak_log
fill 415 172 304 415 174 304 minecraft:red_terracotta
setblock 415 172 308 minecraft:stripped_oak_log
setblock 415 172 309 minecraft:red_terracotta
setblock 415 172 313 minecraft:stripped_oak_log
fill 415 172 314 415 174 314 minecraft:red_terracotta
setblock 416 172 277 minecraft:stripped_oak_log
fill 416 172 278 416 174 278 minecraft:red_terracotta
fill 416 172 289 416 172 291 minecraft:red_terracotta
setblock 416 172 292 minecraft:stripped_oak_log
fill 416 172 293 416 175 293 minecraft:red_terracotta
setblock 416 172 296 minecraft:red_terracotta
setblock 416 172 297 minecraft:stripped_oak_log
fill 416 172 298 416 172 301 minecraft:red_terracotta
setblock 416 172 302 minecraft:stripped_oak_log
fill 416 172 303 416 175 303 minecraft:red_terracotta
setblock 416 172 307 minecraft:stripped_oak_log
fill 416 172 308 416 174 308 minecraft:red_terracotta
setblock 416 172 312 minecraft:stripped_oak_log
fill 416 172 313 416 175 313 minecraft:red_terracotta
setblock 417 172 276 minecraft:stripped_oak_log
fill 417 172 277 418 175 277 minecraft:red_terracotta
fill 417 172 280 418 172 280 minecraft:red_terracotta
setblock 417 172 281 minecraft:stripped_oak_log
setblock 417 172 286 minecraft:stripped_oak_log
fill 417 172 287 418 173 287 minecraft:red_terracotta
setblock 417 172 291 minecraft:stripped_oak_log
fill 417 172 292 418 175 292 minecraft:red_terracotta
setblock 417 172 296 minecraft:stripped_oak_log
fill 417 172 297 418 172 300 minecraft:red_terracotta
setblock 417 172 301 minecraft:stripped_oak_log
fill 417 172 302 418 175 302 minecraft:red_terracotta
setblock 417 172 306 minecraft:stripped_oak_log
fill 417 172 307 418 175 307 minecraft:red_terracotta
setblock 417 172 311 minecraft:stripped_oak_log
fill 417 172 312 418 175 312 minecraft:red_terracotta
setblock 417 172 316 minecraft:stripped_oak_log
fill 418 172 276 418 175 276 minecraft:red_terracotta
fill 418 172 278 418 175 279 minecraft:red_terracotta
fill 418 172 281 418 175 286 minecraft:red_terracotta
fill 418 172 288 418 175 291 minecraft:red_terracotta
fill 418 172 293 418 175 296 minecraft:red_terracotta
fill 418 172 301 418 175 301 minecraft:red_terracotta
fill 418 172 303 418 175 306 minecraft:red_terracotta
fill 418 172 308 418 175 311 minecraft:red_terracotta
fill 418 172 313 418 175 316 minecraft:red_terracotta
fill 377 173 276 377 173 279 minecraft:red_terracotta
setblock 377 173 280 minecraft:stripped_oak_log
fill 377 173 281 377 173 284 minecraft:red_terracotta
setblock 377 173 285 minecraft:stripped_oak_log
fill 377 173 286 377 173 289 minecraft:red_terracotta
setblock 377 173 290 minecraft:stripped_oak_log
fill 377 173 291 377 173 294 minecraft:red_terracotta
setblock 377 173 295 minecraft:stripped_oak_log
fill 377 173 296 377 173 299 minecraft:red_terracotta
setblock 377 173 300 minecraft:stripped_oak_log
fill 377 173 301 377 176 301 minecraft:red_terracotta
setblock 377 173 305 minecraft:stripped_oak_log
fill 377 173 306 377 174 306 minecraft:red_terracotta
setblock 377 173 308 minecraft:red_terracotta
fill 377 173 310 377 174 310 minecraft:stripped_oak_log
fill 377 173 311 377 173 312 minecraft:red_terracotta
setblock 377 173 314 minecraft:red_terracotta
setblock 377 173 315 minecraft:stripped_oak_log
fill 377 173 316 377 174 316 minecraft:red_terracotta
setblock 378 173 279 minecraft:stripped_oak_log
setblock 378 173 289 minecraft:stripped_oak_log
fill 378 173 290 378 173 293 minecraft:red_terracotta
setblock 378 173 294 minecraft:stripped_oak_log
fill 378 173 295 378 173 298 minecraft:red_terracotta
setblock 378 173 299 minecraft:stripped_oak_log
fill 378 173 300 378 176 300 minecraft:red_terracotta
fill 378 173 309 378 174 309 minecraft:stripped_oak_log
fill 378 173 311 378 174 314 minecraft:stripped_oak_log
setblock 378 173 315 minecraft:red_terracotta
setblock 379 173 277 minecraft:red_terracotta
setblock 379 173 293 minecraft:stripped_oak_log
fill 379 173 294 379 174 294 minecraft:red_terracotta
setblock 379 173 298 minecraft:stripped_oak_log
setblock 379 173 299 minecraft:red_terracotta
fill 379 173 308 379 174 308 minecraft:stripped_oak_log
fill 379 173 310 379 174 310 minecraft:stripped_oak_log
fill 379 173 312 379 174 312 minecraft:stripped_oak_log
fill 379 173 314 379 174 315 minecraft:stripped_oak_log
fill 379 173 316 379 174 316 minecraft:red_terracotta
fill 380 173 309 380 174 309 minecraft:stripped_oak_log
fill 380 173 311 380 174 311 minecraft:stripped_oak_log
fill 380 173 313 380 174 313 minecraft:stripped_oak_log
fill 380 173 315 380 174 315 minecraft:stripped_oak_log
setblock 381 173 276 minecraft:stripped_oak_log
fill 381 173 308 381 174 308 minecraft:stripped_oak_log
fill 381 173 310 381 174 310 minecraft:stripped_oak_log
fill 381 173 312 381 174 312 minecraft:stripped_oak_log
fill 381 173 314 381 174 314 minecraft:stripped_oak_log
fill 381 173 316 381 174 316 minecraft:stripped_oak_log
fill 382 173 276 385 173 276 minecraft:red_terracotta
fill 382 173 309 382 174 309 minecraft:stripped_oak_log
fill 382 173 311 382 174 311 minecraft:stripped_oak_log
fill 382 173 313 382 174 313 minecraft:stripped_oak_log
fill 382 173 315 382 174 315 minecraft:stripped_oak_log
fill 383 173 308 383 174 308 minecraft:stripped_oak_log
fill 383 173 310 383 174 310 minecraft:stripped_oak_log
fill 383 173 312 383 174 312 minecraft:stripped_oak_log
fill 383 173 314 383 174 314 minecraft:stripped_oak_log
fill 383 173 316 385 174 316 minecraft:stripped_oak_log
fill 384 173 309 384 174 309 minecraft:stripped_oak_log
fill 384 173 311 384 174 311 minecraft:stripped_oak_log
fill 384 173 313 384 174 313 minecraft:stripped_oak_log
fill 384 173 315 384 174 315 minecraft:stripped_oak_log
fill 385 173 308 385 174 308 minecraft:stripped_oak_log
fill 385 173 310 385 174 310 minecraft:stripped_oak_log
fill 385 173 312 385 174 312 minecraft:stripped_oak_log
fill 385 173 314 385 174 314 minecraft:stripped_oak_log
setblock 386 173 276 minecraft:stripped_oak_log
fill 387 173 276 387 176 276 minecraft:red_terracotta
fill 387 173 316 390 173 316 minecraft:red_terracotta
setblock 389 173 277 minecraft:red_terracotta
setblock 390 173 277 minecraft:stripped_oak_log
fill 390 173 278 390 176 278 minecraft:red_terracotta
fill 390 173 315 391 173 315 minecraft:red_terracotta
setblock 391 173 276 minecraft:stripped_oak_log
fill 391 173 277 391 176 277 minecraft:red_terracotta
setblock 391 173 316 minecraft:stripped_oak_log
fill 392 173 276 392 176 276 minecraft:red_terracotta
setblock 392 173 315 minecraft:stripped_oak_log
fill 392 173 316 395 173 316 minecraft:red_terracotta
fill 393 173 315 393 176 315 minecraft:red_terracotta
setblock 394 173 278 minecraft:stripped_oak_log
fill 394 173 314 394 174 314 minecraft:red_terracotta
setblock 395 173 277 minecraft:stripped_oak_log
fill 395 173 278 395 176 278 minecraft:red_terracotta
setblock 396 173 276 minecraft:stripped_oak_log
fill 396 173 277 396 176 277 minecraft:red_terracotta
setblock 396 173 316 minecraft:stripped_oak_log
fill 397 173 276 397 176 276 minecraft:red_terracotta
setblock 397 173 315 minecraft:stripped_oak_log
fill 397 173 316 397 176 316 minecraft:red_terracotta
setblock 398 173 314 minecraft:stripped_oak_log
fill 398 173 315 398 176 315 minecraft:red_terracotta
fill 399 173 276 399 174 276 minecraft:red_terracotta
fill 399 173 278 399 174 278 minecraft:stripped_oak_log
fill 399 173 280 399 174 280 minecraft:stripped_oak_log
fill 399 173 282 399 174 282 minecraft:stripped_oak_log
setblock 399 173 314 minecraft:red_terracotta
setblock 400 173 277 minecraft:stripped_oak_log
fill 400 173 279 400 174 279 minecraft:stripped_oak_log
fill 400 173 281 400 174 281 minecraft:stripped_oak_log
setblock 401 173 276 minecraft:stripped_oak_log
fill 401 173 277 402 174 277 minecraft:red_terracotta
fill 401 173 278 401 174 278 minecraft:stripped_oak_log
fill 401 173 280 401 174 280 minecraft:stripped_oak_log
fill 401 173 282 401 174 282 minecraft:stripped_oak_log
setblock 401 173 316 minecraft:stripped_oak_log
fill 402 173 276 403 174 276 minecraft:red_terracotta
fill 402 173 279 402 174 279 minecraft:stripped_oak_log
fill 402 173 281 402 174 281 minecraft:stripped_oak_log
setblock 402 173 315 minecraft:stripped_oak_log
fill 402 173 316 402 176 316 minecraft:red_terracotta
fill 403 173 277 403 174 278 minecraft:stripped_oak_log
fill 403 173 280 403 174 280 minecraft:stripped_oak_log
fill 403 173 282 403 174 282 minecraft:stripped_oak_log
fill 403 173 315 406 173 315 minecraft:red_terracotta
fill 404 173 277 404 174 277 minecraft:stripped_oak_log
fill 404 173 279 404 174 279 minecraft:stripped_oak_log
fill 404 173 281 404 174 281 minecraft:stripped_oak_log
setblock 405 173 276 minecraft:red_terracotta
fill 405 173 278 405 174 278 minecraft:stripped_oak_log
fill 405 173 280 405 174 280 minecraft:stripped_oak_log
fill 405 173 282 405 174 282 minecraft:stripped_oak_log
fill 406 173 276 406 173 277 minecraft:stripped_oak_log
fill 406 173 279 406 174 279 minecraft:stripped_oak_log
fill 406 173 281 406 174 281 minecraft:stripped_oak_log
setblock 406 173 316 minecraft:stripped_oak_log
fill 407 173 276 407 174 276 minecraft:red_terracotta
fill 407 173 278 407 174 278 minecraft:stripped_oak_log
fill 407 173 280 407 174 280 minecraft:stripped_oak_log
fill 407 173 282 407 174 282 minecraft:stripped_oak_log
setblock 407 173 315 minecraft:stripped_oak_log
fill 407 173 316 407 176 316 minecraft:red_terracotta
fill 408 173 277 408 174 277 minecraft:stripped_oak_log
fill 408 173 279 408 174 279 minecraft:stripped_oak_log
fill 408 173 281 408 174 281 minecraft:stripped_oak_log
fill 408 173 315 408 176 315 minecraft:red_terracotta
fill 409 173 276 410 173 276 minecraft:red_terracotta
fill 409 173 278 409 174 278 minecraft:stripped_oak_log
fill 409 173 280 409 174 280 minecraft:stripped_oak_log
fill 409 173 282 409 174 282 minecraft:stripped_oak_log
setblock 409 173 314 minecraft:red_terracotta
setblock 411 173 276 minecraft:stripped_oak_log
fill 411 173 277 411 176 277 minecraft:red_terracotta
setblock 411 173 316 minecraft:stripped_oak_log
fill 412 173 276 412 176 276 minecraft:red_terracotta
setblock 412 173 315 minecraft:stripped_oak_log
fill 412 173 316 412 176 316 minecraft:red_terracotta
setblock 413 173 314 minecraft:stripped_oak_log
fill 413 173 315 413 176 315 minecraft:red_terracotta
fill 414 173 295 414 173 297 minecraft:red_terracotta
setblock 414 173 298 minecraft:stripped_oak_log
fill 414 173 299 418 173 299 minecraft:red_terracotta
fill 414 173 314 414 174 314 minecraft:red_terracotta
setblock 415 173 277 minecraft:stripped_oak_log
setblock 415 173 292 minecraft:stripped_oak_log
fill 415 173 293 415 174 293 minecraft:red_terracotta
fill 415 173 295 415 173 296 minecraft:red_terracotta
setblock 415 173 297 minecraft:stripped_oak_log
fill 415 173 298 418 174 298 minecraft:red_terracotta
fill 415 173 300 415 173 301 minecraft:red_terracotta
setblock 415 173 302 minecraft:stripped_oak_log
fill 415 173 303 415 176 303 minecraft:red_terracotta
setblock 415 173 312 minecraft:stripped_oak_log
fill 415 173 313 415 174 313 minecraft:red_terracotta
setblock 416 173 276 minecraft:stripped_oak_log
fill 416 173 277 416 175 277 minecraft:red_terracotta
fill 416 173 289 416 173 290 minecraft:red_terracotta
setblock 416 173 291 minecraft:stripped_oak_log
fill 416 173 292 416 176 292 minecraft:red_terracotta
setblock 416 173 295 minecraft:red_terracotta
setblock 416 173 296 minecraft:stripped_oak_log
fill 416 173 297 418 175 297 minecraft:red_terracotta
setblock 416 173 300 minecraft:red_terracotta
setblock 416 173 301 minecraft:stripped_oak_log
fill 416 173 302 416 176 302 minecraft:red_terracotta
setblock 416 173 306 minecraft:stripped_oak_log
fill 416 173 307 416 175 307 minecraft:red_terracotta
setblock 416 173 311 minecraft:stripped_oak_log
fill 416 173 312 416 175 312 minecraft:red_terracotta
setblock 416 173 316 minecraft:stripped_oak_log
fill 417 173 276 417 176 276 minecraft:red_terracotta
setblock 417 173 280 minecraft:stripped_oak_log
setblock 417 173 281 minecraft:red_terracotta
setblock 417 173 290 minecraft:stripped_oak_log
fill 417 173 291 417 176 291 minecraft:red_terracotta
setblock 417 173 295 minecraft:stripped_oak_log
fill 417 173 296 417 176 296 minecraft:red_terracotta
setblock 417 173 300 minecraft:stripped_oak_log
fill 417 173 301 417 176 301 minecraft:red_terracotta
setblock 417 173 305 minecraft:stripped_oak_log
fill 417 173 306 417 176 306 minecraft:red_terracotta
setblock 417 173 310 minecraft:stripped_oak_log
fill 417 173 311 417 176 311 minecraft:red_terracotta
setblock 417 173 315 minecraft:stripped_oak_log
fill 417 173 316 417 176 316 minecraft:red_terracotta
fill 418 173 280 418 175 280 minecraft:red_terracotta
fill 418 173 300 418 175 300 minecraft:red_terracotta
fill 377 174 276 377 174 278 minecraft:red_terracotta
setblock 377 174 279 minecraft:stripped_oak_log
fill 377 174 280 377 174 283 minecraft:red_terracotta
setblock 377 174 284 minecraft:stripped_oak_log
fill 377 174 285 377 174 288 minecraft:red_terracotta
setblock 377 174 289 minecraft:stripped_oak_log
fill 377 174 290 377 174 293 minecraft:red_terracotta
setblock 377 174 294 minecraft:stripped_oak_log
fill 377 174 295 377 174 298 minecraft:red_terracotta
setblock 377 174 299 minecraft:stripped_oak_log
fill 377 174 300 377 177 300 minecraft:red_terracotta
setblock 377 174 304 minecraft:stripped_oak_log
fill 377 174 305 377 175 305 minecraft:red_terracotta
fill 377 174 308 377 174 309 minecraft:stripped_oak_log
fill 377 174 311 377 177 311 minecraft:stripped_oak_log
setblock 377 174 312 minecraft:red_terracotta
setblock 377 174 314 minecraft:stripped_oak_log
fill 377 174 315 377 175 315 minecraft:red_terracotta
setblock 378 174 278 minecraft:stripped_oak_log
fill 378 174 289 378 174 292 minecraft:red_terracotta
setblock 378 174 293 minecraft:stripped_oak_log
fill 378 174 294 378 174 297 minecraft:red_terracotta
setblock 378 174 298 minecraft:stripped_oak_log
fill 378 174 299 378 177 299 minecraft:red_terracotta
setblock 378 174 315 minecraft:stripped_oak_log
setblock 379 174 278 minecraft:light[level=12]
setblock 379 174 285 minecraft:light[level=12]
setblock 379 174 292 minecraft:light[level=12]
setblock 379 174 293 minecraft:red_terracotta
setblock 379 174 297 minecraft:stripped_oak_log
setblock 379 174 298 minecraft:red_terracotta
setblock 379 174 299 minecraft:light[level=12]
setblock 379 174 306 minecraft:light[level=12]
setblock 380 174 276 minecraft:stripped_oak_log
fill 380 174 316 380 177 316 minecraft:stripped_oak_log
fill 381 174 276 384 174 276 minecraft:red_terracotta
setblock 385 174 276 minecraft:stripped_oak_log
fill 386 174 276 386 176 277 minecraft:red_terracotta
setblock 386 174 278 minecraft:light[level=12]
setblock 386 174 285 minecraft:light[level=12]
setblock 386 174 292 minecraft:light[level=12]
setblock 386 174 306 minecraft:light[level=12]
setblock 386 174 313 minecraft:light[level=12]
fill 387 174 316 389 174 316 minecraft:red_terracotta
setblock 389 174 277 minecraft:stripped_oak_log
fill 389 174 278 389 177 278 minecraft:red_terracotta
setblock 390 174 276 minecraft:stripped_oak_log
fill 390 174 277 390 177 277 minecraft:red_terracotta
setblock 390 174 315 minecraft:red_terracotta
setblock 390 174 316 minecraft:stripped_oak_log
fill 391 174 276 391 177 276 minecraft:red_terracotta
setblock 391 174 315 minecraft:stripped_oak_log
fill 391 174 316 394 174 316 minecraft:red_terracotta
fill 392 174 315 392 177 315 minecraft:red_terracotta
setblock 393 174 278 minecraft:stripped_oak_log
setblock 393 174 285 minecraft:light[level=12]
setblock 393 174 292 minecraft:light[level=12]
setblock 393 174 299 minecraft:light[level=12]
setblock 393 174 306 minecraft:light[level=12]
setblock 393 174 313 minecraft:light[level=12]
setblock 394 174 277 minecraft:stripped_oak_log
fill 394 174 278 394 177 278 minecraft:red_terracotta
setblock 395 174 276 minecraft:stripped_oak_log
fill 395 174 277 395 177 277 minecraft:red_terracotta
setblock 395 174 316 minecraft:stripped_oak_log
fill 396 174 276 396 177 276 minecraft:red_terracotta
setblock 396 174 315 minecraft:stripped_oak_log
fill 396 174 316 396 177 316 minecraft:red_terracotta
setblock 397 174 314 minecraft:stripped_oak_log
fill 397 174 315 397 177 315 minecraft:red_terracotta
setblock 398 174 278 minecraft:stripped_oak_log
setblock 398 174 314 minecraft:red_terracotta
setblock 399 174 277 minecraft:stripped_oak_log
setblock 400 174 276 minecraft:stripped_oak_log
setblock 400 174 277 minecraft:red_terracotta
setblock 400 174 285 minecraft:light[level=12]
setblock 400 174 292 minecraft:light[level=12]
setblock 400 174 299 minecraft:light[level=12]
setblock 400 174 306 minecraft:light[level=12]
setblock 400 174 313 minecraft:light[level=12]
setblock 400 174 316 minecraft:stripped_oak_log
setblock 401 174 276 minecraft:red_terracotta
setblock 401 174 315 minecraft:stripped_oak_log
fill 401 174 316 401 177 316 minecraft:red_terracotta
fill 402 174 315 405 174 315 minecraft:red_terracotta
setblock 405 174 276 minecraft:stripped_oak_log
setblock 405 174 316 minecraft:stripped_oak_log
fill 406 174 276 406 177 276 minecraft:red_terracotta
setblock 406 174 277 minecraft:stripped_oak_log
setblock 406 174 315 minecraft:stripped_oak_log
fill 406 174 316 406 177 316 minecraft:red_terracotta
setblock 407 174 285 minecraft:light[level=12]
setblock 407 174 292 minecraft:light[level=12]
setblock 407 174 299 minecraft:light[level=12]
setblock 407 174 306 minecraft:light[level=12]
setblock 407 174 313 minecraft:light[level=12]
fill 407 174 315 407 175 315 minecraft:red_terracotta
setblock 409 174 276 minecraft:red_terracotta
setblock 410 174 276 minecraft:stripped_oak_log
setblock 410 174 316 minecraft:stripped_oak_log
fill 411 174 276 411 177 276 minecraft:red_terracotta
setblock 411 174 315 minecraft:stripped_oak_log
fill 411 174 316 411 177 316 minecraft:red_terracotta
setblock 412 174 314 minecraft:stripped_oak_log
fill 412 174 315 412 177 315 minecraft:red_terracotta
fill 413 174 314 413 175 314 minecraft:red_terracotta
setblock 414 174 277 minecraft:stripped_oak_log
setblock 414 174 278 minecraft:light[level=12]
setblock 414 174 285 minecraft:light[level=12]
setblock 414 174 292 minecraft:light[level=12]
setblock 414 174 296 minecraft:red_terracotta
setblock 414 174 297 minecraft:stripped_oak_log
fill 414 174 298 414 176 299 minecraft:red_terracotta
setblock 414 174 306 minecraft:light[level=12]
setblock 414 174 313 minecraft:light[level=12]
setblock 415 174 276 minecraft:stripped_oak_log
fill 415 174 277 415 176 277 minecraft:red_terracotta
setblock 415 174 295 minecraft:red_terracotta
setblock 415 174 296 minecraft:stripped_oak_log
fill 415 174 297 415 177 297 minecraft:red_terracotta
fill 415 174 299 415 174 300 minecraft:red_terracotta
setblock 415 174 301 minecraft:stripped_oak_log
fill 415 174 302 415 177 302 minecraft:red_terracotta
setblock 415 174 316 minecraft:stripped_oak_log
fill 416 174 276 416 177 276 minecraft:red_terracotta
setblock 416 174 290 minecraft:stripped_oak_log
fill 416 174 291 416 175 291 minecraft:red_terracotta
setblock 416 174 294 minecraft:red_terracotta
setblock 416 174 295 minecraft:stripped_oak_log
fill 416 174 296 416 177 296 minecraft:red_terracotta
setblock 416 174 299 minecraft:red_terracotta
setblock 416 174 300 minecraft:stripped_oak_log
fill 416 174 301 416 177 301 minecraft:red_terracotta
setblock 416 174 305 minecraft:stripped_oak_log
fill 416 174 306 416 176 306 minecraft:red_terracotta
setblock 416 174 310 minecraft:stripped_oak_log
setblock 416 174 311 minecraft:red_terracotta
setblock 416 174 315 minecraft:stripped_oak_log
fill 416 174 316 416 177 316 minecraft:red_terracotta
setblock 417 174 279 minecraft:stripped_oak_log
fill 417 174 280 417 177 280 minecraft:red_terracotta
setblock 417 174 289 minecraft:stripped_oak_log
fill 417 174 290 417 176 290 minecraft:red_terracotta
setblock 417 174 294 minecraft:stripped_oak_log
fill 417 174 295 417 177 295 minecraft:red_terracotta
setblock 417 174 299 minecraft:stripped_oak_log
fill 417 174 300 417 177 300 minecraft:red_terracotta
setblock 417 174 304 minecraft:stripped_oak_log
fill 417 174 305 417 177 305 minecraft:red_terracotta
setblock 417 174 309 minecraft:stripped_oak_log
fill 417 174 310 417 175 310 minecraft:red_terracotta
setblock 417 174 314 minecraft:stripped_oak_log
fill 417 174 315 417 177 315 minecraft:red_terracotta
fill 418 174 287 418 175 287 minecraft:red_terracotta
fill 418 174 299 418 175 299 minecraft:red_terracotta
fill 377 175 276 377 175 277 minecraft:red_terracotta
setblock 377 175 278 minecraft:stripped_oak_log
fill 377 175 279 377 175 282 minecraft:red_terracotta
setblock 377 175 283 minecraft:stripped_oak_log
fill 377 175 284 377 175 287 minecraft:red_terracotta
setblock 377 175 288 minecraft:stripped_oak_log
fill 377 175 289 377 175 292 minecraft:red_terracotta
setblock 377 175 293 minecraft:stripped_oak_log
fill 377 175 294 377 175 297 minecraft:red_terracotta
setblock 377 175 298 minecraft:stripped_oak_log
fill 377 175 299 377 178 299 minecraft:red_terracotta
setblock 377 175 303 minecraft:stripped_oak_log
fill 377 175 304 377 178 304 minecraft:red_terracotta
setblock 377 175 308 minecraft:shroomlight
fill 377 175 309 377 177 309 minecraft:stripped_oak_log
setblock 377 175 310 minecraft:shroomlight
setblock 377 175 312 minecraft:shroomlight
fill 377 175 313 377 177 313 minecraft:stripped_oak_log
setblock 377 175 314 minecraft:shroomlight
setblock 377 175 316 minecraft:shroomlight
setblock 378 175 277 minecraft:stripped_oak_log
setblock 378 175 291 minecraft:red_terracotta
setblock 378 175 292 minecraft:stripped_oak_log
fill 378 175 293 378 175 296 minecraft:red_terracotta
setblock 378 175 297 minecraft:stripped_oak_log
fill 378 175 298 378 178 298 minecraft:red_terracotta
setblock 378 175 309 minecraft:shroomlight
setblock 378 175 311 minecraft:shroomlight
fill 378 175 312 378 177 312 minecraft:stripped_oak_log
setblock 378 175 313 minecraft:shroomlight
fill 378 175 314 378 177 314 minecraft:stripped_oak_log
setblock 378 175 315 minecraft:shroomlight
setblock 379 175 276 minecraft:stripped_oak_log
setblock 379 175 296 minecraft:stripped_oak_log
setblock 379 175 308 minecraft:shroomlight
setblock 379 175 310 minecraft:shroomlight
setblock 379 175 312 minecraft:shroomlight
setblock 379 175 314 minecraft:shroomlight
fill 379 175 315 379 177 315 minecraft:stripped_oak_log
setblock 379 175 316 minecraft:shroomlight
fill 380 175 276 383 175 276 minecraft:red_terracotta
setblock 380 175 309 minecraft:shroomlight
setblock 380 175 311 minecraft:shroomlight
setblock 380 175 313 minecraft:shroomlight
setblock 380 175 315 minecraft:shroomlight
fill 381 175 279 385 181 280 minecraft:stripped_oak_log
setblock 381 175 308 minecraft:shroomlight
setblock 381 175 310 minecraft:shroomlight
setblock 381 175 312 minecraft:shroomlight
setblock 381 175 314 minecraft:shroomlight
setblock 381 175 316 minecraft:shroomlight
fill 382 175 278 385 179 278 minecraft:stripped_oak_log
fill 382 175 281 385 218 281 minecraft:stripped_oak_log
setblock 382 175 309 minecraft:shroomlight
setblock 382 175 311 minecraft:shroomlight
setblock 382 175 313 minecraft:shroomlight
setblock 382 175 315 minecraft:shroomlight
fill 383 175 277 384 179 277 minecraft:stripped_oak_log
setblock 383 175 308 minecraft:shroomlight
setblock 383 175 310 minecraft:shroomlight
setblock 383 175 312 minecraft:shroomlight
setblock 383 175 314 minecraft:shroomlight
setblock 383 175 316 minecraft:shroomlight
setblock 384 175 276 minecraft:stripped_oak_log
setblock 384 175 309 minecraft:shroomlight
setblock 384 175 311 minecraft:shroomlight
setblock 384 175 313 minecraft:shroomlight
setblock 384 175 315 minecraft:shroomlight
fill 384 175 316 384 177 316 minecraft:stripped_oak_log
fill 385 175 276 385 178 276 minecraft:red_terracotta
setblock 385 175 308 minecraft:shroomlight
setblock 385 175 310 minecraft:shroomlight
setblock 385 175 312 minecraft:shroomlight
setblock 385 175 314 minecraft:shroomlight
setblock 385 175 316 minecraft:shroomlight
fill 387 175 316 388 175 316 minecraft:red_terracotta
setblock 388 175 277 minecraft:stripped_oak_log
setblock 389 175 276 minecraft:stripped_oak_log
fill 389 175 277 389 178 277 minecraft:red_terracotta
setblock 389 175 316 minecraft:stripped_oak_log
fill 390 175 276 390 178 276 minecraft:red_terracotta
setblock 390 175 315 minecraft:stripped_oak_log
fill 390 175 316 393 175 316 minecraft:red_terracotta
fill 391 175 315 391 178 315 minecraft:red_terracotta
setblock 392 175 278 minecraft:stripped_oak_log
setblock 393 175 277 minecraft:stripped_oak_log
fill 393 175 278 393 178 278 minecraft:red_terracotta
setblock 394 175 276 minecraft:stripped_oak_log
fill 394 175 277 394 178 277 minecraft:red_terracotta
setblock 394 175 316 minecraft:stripped_oak_log
fill 395 175 276 395 178 276 minecraft:red_terracotta
setblock 395 175 315 minecraft:stripped_oak_log
fill 395 175 316 395 178 316 minecraft:red_terracotta
fill 396 175 315 396 178 315 minecraft:red_terracotta
setblock 397 175 278 minecraft:stripped_oak_log
setblock 398 175 277 minecraft:stripped_oak_log
setblock 398 175 278 minecraft:red_terracotta
setblock 399 175 276 minecraft:shroomlight
fill 399 175 277 399 178 277 minecraft:red_terracotta
setblock 399 175 278 minecraft:shroomlight
setblock 399 175 280 minecraft:shroomlight
setblock 399 175 282 minecraft:shroomlight
setblock 399 175 316 minecraft:stripped_oak_log
fill 400 175 276 400 178 276 minecraft:red_terracotta
setblock 400 175 277 minecraft:shroomlight
setblock 400 175 279 minecraft:shroomlight
setblock 400 175 281 minecraft:shroomlight
setblock 400 175 315 minecraft:stripped_oak_log
fill 400 175 316 400 178 316 minecraft:red_terracotta
setblock 401 175 276 minecraft:shroomlight
setblock 401 175 277 minecraft:red_terracotta
setblock 401 175 278 minecraft:shroomlight
setblock 401 175 280 minecraft:shroomlight
setblock 401 175 282 minecraft:shroomlight
setblock 401 175 315 minecraft:red_terracotta
fill 402 175 276 402 176 276 minecraft:red_terracotta
setblock 402 175 277 minecraft:shroomlight
setblock 402 175 279 minecraft:shroomlight
setblock 402 175 281 minecraft:shroomlight
setblock 403 175 276 minecraft:shroomlight
fill 403 175 277 403 183 277 minecraft:stripped_oak_log
setblock 403 175 278 minecraft:shroomlight
setblock 403 175 280 minecraft:shroomlight
setblock 403 175 282 minecraft:shroomlight
setblock 404 175 276 minecraft:stripped_oak_log
setblock 404 175 277 minecraft:shroomlight
setblock 404 175 279 minecraft:shroomlight
setblock 404 175 281 minecraft:shroomlight
setblock 404 175 316 minecraft:stripped_oak_log
setblock 405 175 276 minecraft:shroomlight
setblock 405 175 278 minecraft:shroomlight
setblock 405 175 280 minecraft:shroomlight
setblock 405 175 282 minecraft:shroomlight
fill 405 175 316 405 178 316 minecraft:red_terracotta
setblock 406 175 277 minecraft:shroomlight
setblock 406 175 279 minecraft:shroomlight
setblock 406 175 281 minecraft:shroomlight
setblock 407 175 276 minecraft:shroomlight
setblock 407 175 278 minecraft:shroomlight
setblock 407 175 280 minecraft:shroomlight
setblock 407 175 282 minecraft:shroomlight
setblock 408 175 277 minecraft:shroomlight
setblock 408 175 279 minecraft:shroomlight
setblock 408 175 281 minecraft:shroomlight
setblock 409 175 276 minecraft:shroomlight
setblock 409 175 278 minecraft:shroomlight
setblock 409 175 280 minecraft:shroomlight
setblock 409 175 282 minecraft:shroomlight
setblock 409 175 316 minecraft:stripped_oak_log
fill 410 175 276 410 178 276 minecraft:red_terracotta
setblock 410 175 315 minecraft:stripped_oak_log
fill 410 175 316 410 178 316 minecraft:red_terracotta
fill 411 175 315 411 178 315 minecraft:red_terracotta
setblock 413 175 277 minecraft:stripped_oak_log
setblock 414 175 276 minecraft:stripped_oak_log
fill 414 175 277 414 178 277 minecraft:red_terracotta
setblock 414 175 297 minecraft:red_terracotta
setblock 414 175 300 minecraft:red_terracotta
setblock 414 175 316 minecraft:stripped_oak_log
fill 415 175 276 415 178 276 minecraft:red_terracotta
setblock 415 175 295 minecraft:stripped_oak_log
fill 415 175 296 415 178 296 minecraft:red_terracotta
fill 415 175 298 415 175 299 minecraft:red_terracotta
setblock 415 175 300 minecraft:stripped_oak_log
fill 415 175 301 415 178 301 minecraft:red_terracotta
setblock 415 175 315 minecraft:stripped_oak_log
fill 415 175 316 415 178 316 minecraft:red_terracotta
setblock 416 175 294 minecraft:stripped_oak_log
fill 416 175 295 416 178 295 minecraft:red_terracotta
setblock 416 175 298 minecraft:red_terracotta
setblock 416 175 299 minecraft:stripped_oak_log
fill 416 175 300 416 178 300 minecraft:red_terracotta
setblock 416 175 304 minecraft:stripped_oak_log
fill 416 175 305 416 178 305 minecraft:red_terracotta
setblock 416 175 314 minecraft:stripped_oak_log
fill 416 175 315 416 176 315 minecraft:red_terracotta
setblock 417 175 278 minecraft:stripped_oak_log
fill 417 175 279 417 178 279 minecraft:red_terracotta
setblock 417 175 289 minecraft:red_terracotta
setblock 417 175 293 minecraft:stripped_oak_log
fill 417 175 294 417 178 294 minecraft:red_terracotta
setblock 417 175 298 minecraft:stripped_oak_log
fill 417 175 299 417 178 299 minecraft:red_terracotta
setblock 417 175 303 minecraft:stripped_oak_log
fill 417 175 304 417 178 304 minecraft:red_terracotta
setblock 417 175 308 minecraft:stripped_oak_log
fill 417 175 309 417 176 309 minecraft:red_terracotta
setblock 417 175 313 minecraft:stripped_oak_log
fill 417 175 314 417 176 314 minecraft:red_terracotta
setblock 418 175 298 minecraft:red_terracotta
fill 376 176 275 376 179 317 minecraft:yellow_terracotta
fill 377 176 275 418 179 275 minecraft:yellow_terracotta
setblock 377 176 276 minecraft:red_terracotta
setblock 377 176 277 minecraft:stripped_oak_log
fill 377 176 278 377 176 281 minecraft:red_terracotta
setblock 377 176 282 minecraft:stripped_oak_log
fill 377 176 283 377 176 286 minecraft:red_terracotta
setblock 377 176 287 minecraft:stripped_oak_log
fill 377 176 288 377 176 291 minecraft:red_terracotta
setblock 377 176 292 minecraft:stripped_oak_log
fill 377 176 293 377 176 296 minecraft:red_terracotta
setblock 377 176 297 minecraft:stripped_oak_log
fill 377 176 298 377 179 298 minecraft:red_terracotta
setblock 377 176 302 minecraft:stripped_oak_log
fill 377 176 303 377 179 303 minecraft:red_terracotta
fill 377 176 308 377 177 308 minecraft:stripped_oak_log
fill 377 176 310 377 177 310 minecraft:stripped_oak_log
fill 377 176 312 377 177 312 minecraft:stripped_oak_log
fill 377 176 314 377 177 316 minecraft:stripped_oak_log
fill 377 176 317 418 179 317 minecraft:yellow_terracotta
setblock 378 176 276 minecraft:stripped_oak_log
fill 378 176 292 378 176 295 minecraft:red_terracotta
setblock 378 176 296 minecraft:stripped_oak_log
fill 378 176 297 378 178 297 minecraft:red_terracotta
setblock 378 176 301 minecraft:stripped_oak_log
fill 378 176 309 378 177 309 minecraft:stripped_oak_log
fill 378 176 311 378 177 311 minecraft:stripped_oak_log
fill 378 176 313 378 177 313 minecraft:stripped_oak_log
fill 378 176 315 378 177 316 minecraft:stripped_oak_log
fill 379 176 276 382 176 276 minecraft:red_terracotta
setblock 379 176 278 minecraft:light[level=15]
setblock 379 176 286 minecraft:light[level=15]
setblock 379 176 294 minecraft:light[level=15]
setblock 379 176 302 minecraft:light[level=15]
fill 379 176 308 379 177 308 minecraft:stripped_oak_log
fill 379 176 310 379 177 310 minecraft:stripped_oak_log
fill 379 176 312 379 177 312 minecraft:stripped_oak_log
fill 379 176 314 379 177 314 minecraft:stripped_oak_log
fill 379 176 316 379 177 316 minecraft:stripped_oak_log
fill 380 176 279 380 177 280 minecraft:brown_terracotta
fill 380 176 309 380 177 309 minecraft:stripped_oak_log
fill 380 176 311 380 177 311 minecraft:stripped_oak_log
fill 380 176 313 380 177 313 minecraft:stripped_oak_log
fill 380 176 315 380 177 315 minecraft:stripped_oak_log
fill 381 176 277 381 177 278 minecraft:brown_terracotta
fill 381 176 281 381 177 281 minecraft:brown_terracotta
fill 381 176 308 381 177 308 minecraft:stripped_oak_log
fill 381 176 310 381 177 310 minecraft:stripped_oak_log
fill 381 176 312 381 177 312 minecraft:stripped_oak_log
fill 381 176 314 381 177 314 minecraft:stripped_oak_log
fill 381 176 316 381 177 316 minecraft:stripped_oak_log
fill 382 176 277 382 177 277 minecraft:brown_terracotta
fill 382 176 282 385 177 282 minecraft:brown_terracotta
fill 382 176 309 382 177 309 minecraft:stripped_oak_log
fill 382 176 311 382 177 311 minecraft:stripped_oak_log
fill 382 176 313 382 177 313 minecraft:stripped_oak_log
fill 382 176 315 382 177 315 minecraft:stripped_oak_log
setblock 383 176 276 minecraft:stripped_oak_log
fill 383 176 308 383 177 308 minecraft:stripped_oak_log
fill 383 176 310 383 177 310 minecraft:stripped_oak_log
fill 383 176 312 383 177 312 minecraft:stripped_oak_log
fill 383 176 314 383 177 314 minecraft:stripped_oak_log
fill 383 176 316 383 177 316 minecraft:stripped_oak_log
fill 384 176 276 384 179 276 minecraft:red_terracotta
fill 384 176 309 384 177 309 minecraft:stripped_oak_log
fill 384 176 311 384 177 311 minecraft:stripped_oak_log
fill 384 176 313 384 177 313 minecraft:stripped_oak_log
fill 384 176 315 384 177 315 minecraft:stripped_oak_log
setblock 385 176 277 minecraft:brown_terracotta
fill 385 176 308 385 177 308 minecraft:stripped_oak_log
fill 385 176 310 385 177 310 minecraft:stripped_oak_log
fill 385 176 312 385 177 312 minecraft:stripped_oak_log
fill 385 176 314 385 177 314 minecraft:stripped_oak_log
fill 385 176 316 385 177 316 minecraft:stripped_oak_log
fill 386 176 278 386 177 281 minecraft:brown_terracotta
setblock 387 176 277 minecraft:stripped_oak_log
setblock 387 176 278 minecraft:light[level=15]
setblock 387 176 286 minecraft:light[level=15]
setblock 387 176 294 minecraft:light[level=15]
setblock 387 176 310 minecraft:light[level=15]
setblock 388 176 276 minecraft:stripped_oak_log
fill 388 176 277 388 178 278 minecraft:red_terracotta
setblock 388 176 316 minecraft:stripped_oak_log
fill 389 176 276 389 179 276 minecraft:red_terracotta
fill 389 176 316 392 176 316 minecraft:red_terracotta
setblock 391 176 278 minecraft:stripped_oak_log
setblock 392 176 277 minecraft:stripped_oak_log
fill 392 176 278 392 179 278 minecraft:red_terracotta
setblock 393 176 276 minecraft:stripped_oak_log
fill 393 176 277 393 179 277 minecraft:red_terracotta
setblock 393 176 316 minecraft:stripped_oak_log
fill 394 176 276 394 179 276 minecraft:red_terracotta
setblock 394 176 315 minecraft:stripped_oak_log
fill 394 176 316 394 179 316 minecraft:red_terracotta
setblock 395 176 286 minecraft:light[level=15]
setblock 395 176 294 minecraft:light[level=15]
setblock 395 176 302 minecraft:light[level=15]
setblock 395 176 310 minecraft:light[level=15]
fill 395 176 315 395 179 315 minecraft:red_terracotta
setblock 396 176 278 minecraft:stripped_oak_log
setblock 397 176 277 minecraft:stripped_oak_log
fill 397 176 278 397 177 278 minecraft:red_terracotta
setblock 398 176 276 minecraft:stripped_oak_log
fill 398 176 277 398 179 277 minecraft:red_terracotta
setblock 398 176 316 minecraft:stripped_oak_log
fill 399 176 276 399 177 276 minecraft:red_terracotta
fill 399 176 278 399 177 278 minecraft:stripped_oak_log
fill 399 176 280 399 177 280 minecraft:stripped_oak_log
fill 399 176 282 399 177 282 minecraft:stripped_oak_log
setblock 399 176 315 minecraft:stripped_oak_log
fill 399 176 316 399 179 316 minecraft:red_terracotta
setblock 400 176 277 minecraft:red_terracotta
fill 400 176 279 400 177 279 minecraft:stripped_oak_log
fill 400 176 281 400 177 281 minecraft:stripped_oak_log
fill 401 176 276 401 177 276 minecraft:red_terracotta
fill 401 176 277 401 177 278 minecraft:stripped_oak_log
fill 401 176 280 401 177 280 minecraft:stripped_oak_log
fill 401 176 282 401 177 282 minecraft:stripped_oak_log
fill 402 176 277 402 177 277 minecraft:stripped_oak_log
fill 402 176 279 402 177 279 minecraft:stripped_oak_log
fill 402 176 281 402 177 281 minecraft:stripped_oak_log
setblock 403 176 276 minecraft:stripped_oak_log
fill 403 176 278 403 177 278 minecraft:stripped_oak_log
fill 403 176 280 403 177 280 minecraft:stripped_oak_log
fill 403 176 282 403 177 282 minecraft:stripped_oak_log
setblock 403 176 286 minecraft:light[level=15]
setblock 403 176 294 minecraft:light[level=15]
setblock 403 176 302 minecraft:light[level=15]
setblock 403 176 310 minecraft:light[level=15]
setblock 403 176 316 minecraft:stripped_oak_log
fill 404 176 276 405 177 276 minecraft:red_terracotta
fill 404 176 277 404 177 277 minecraft:stripped_oak_log
fill 404 176 279 404 177 279 minecraft:stripped_oak_log
fill 404 176 281 404 177 281 minecraft:stripped_oak_log
fill 404 176 316 404 179 316 minecraft:red_terracotta
fill 405 176 278 405 177 278 minecraft:stripped_oak_log
fill 405 176 280 405 177 280 minecraft:stripped_oak_log
fill 405 176 282 405 177 282 minecraft:stripped_oak_log
fill 406 176 277 406 177 277 minecraft:stripped_oak_log
fill 406 176 279 406 177 279 minecraft:stripped_oak_log
fill 406 176 281 406 177 281 minecraft:stripped_oak_log
setblock 407 176 276 minecraft:red_terracotta
fill 407 176 278 407 177 278 minecraft:stripped_oak_log
fill 407 176 280 407 177 280 minecraft:stripped_oak_log
fill 407 176 282 407 177 282 minecraft:stripped_oak_log
fill 408 176 276 408 176 277 minecraft:stripped_oak_log
fill 408 176 279 408 177 279 minecraft:stripped_oak_log
fill 408 176 281 408 177 281 minecraft:stripped_oak_log
setblock 408 176 316 minecraft:stripped_oak_log
fill 409 176 276 409 177 276 minecraft:red_terracotta
fill 409 176 278 409 177 278 minecraft:stripped_oak_log
fill 409 176 280 409 177 280 minecraft:stripped_oak_log
fill 409 176 282 409 177 282 minecraft:stripped_oak_log
setblock 409 176 315 minecraft:stripped_oak_log
fill 409 176 316 409 179 316 minecraft:red_terracotta
fill 410 176 315 410 179 315 minecraft:red_terracotta
setblock 411 176 278 minecraft:light[level=15]
setblock 411 176 286 minecraft:light[level=15]
setblock 411 176 294 minecraft:light[level=15]
setblock 411 176 302 minecraft:light[level=15]
setblock 411 176 310 minecraft:light[level=15]
setblock 412 176 277 minecraft:stripped_oak_log
setblock 413 176 276 minecraft:stripped_oak_log
fill 413 176 277 413 179 277 minecraft:red_terracotta
setblock 413 176 316 minecraft:stripped_oak_log
fill 414 176 276 414 179 276 minecraft:red_terracotta
setblock 414 176 300 minecraft:stripped_oak_log
setblock 414 176 315 minecraft:stripped_oak_log
fill 414 176 316 414 179 316 minecraft:red_terracotta
setblock 415 176 294 minecraft:stripped_oak_log
fill 415 176 295 415 177 295 minecraft:red_terracotta
setblock 415 176 298 minecraft:red_terracotta
setblock 415 176 299 minecraft:stripped_oak_log
fill 415 176 300 415 179 300 minecraft:red_terracotta
setblock 415 176 315 minecraft:red_terracotta
setblock 416 176 293 minecraft:stripped_oak_log
fill 416 176 294 416 179 294 minecraft:red_terracotta
setblock 416 176 297 minecraft:red_terracotta
setblock 416 176 298 minecraft:stripped_oak_log
fill 416 176 299 416 179 299 minecraft:red_terracotta
setblock 416 176 303 minecraft:stripped_oak_log
fill 416 176 304 416 179 304 minecraft:red_terracotta
setblock 417 176 277 minecraft:stripped_oak_log
fill 417 176 278 417 179 278 minecraft:red_terracotta
setblock 417 176 292 minecraft:stripped_oak_log
fill 417 176 293 417 179 293 minecraft:red_terracotta
setblock 417 176 297 minecraft:stripped_oak_log
fill 417 176 298 417 179 298 minecraft:red_terracotta
setblock 417 176 302 minecraft:stripped_oak_log
fill 417 176 303 417 179 303 minecraft:red_terracotta
setblock 417 176 307 minecraft:stripped_oak_log
setblock 417 176 308 minecraft:red_terracotta
setblock 417 176 312 minecraft:stripped_oak_log
setblock 417 176 313 minecraft:red_terracotta
fill 418 176 276 418 179 316 minecraft:yellow_terracotta
setblock 377 177 276 minecraft:stripped_oak_log
fill 377 177 277 377 177 280 minecraft:red_terracotta
setblock 377 177 281 minecraft:stripped_oak_log
fill 377 177 282 377 177 285 minecraft:red_terracotta
setblock 377 177 286 minecraft:stripped_oak_log
fill 377 177 287 377 177 290 minecraft:red_terracotta
setblock 377 177 291 minecraft:stripped_oak_log
fill 377 177 292 377 177 295 minecraft:red_terracotta
setblock 377 177 296 minecraft:stripped_oak_log
fill 377 177 297 377 180 297 minecraft:red_terracotta
setblock 377 177 301 minecraft:stripped_oak_log
fill 377 177 302 377 180 302 minecraft:red_terracotta
fill 378 177 276 381 177 276 minecraft:red_terracotta
setblock 378 177 294 minecraft:red_terracotta
setblock 378 177 295 minecraft:stripped_oak_log
fill 378 177 296 378 178 296 minecraft:red_terracotta
setblock 378 177 300 minecraft:stripped_oak_log
fill 379 177 279 379 177 280 minecraft:brown_terracotta
fill 380 177 277 380 177 278 minecraft:brown_terracotta
fill 380 177 281 380 177 282 minecraft:brown_terracotta
fill 381 177 282 381 177 283 minecraft:brown_terracotta
setblock 382 177 276 minecraft:stripped_oak_log
fill 382 177 283 385 177 283 minecraft:brown_terracotta
fill 383 177 276 383 180 276 minecraft:red_terracotta
setblock 385 177 277 minecraft:red_terracotta
setblock 386 177 276 minecraft:red_terracotta
setblock 386 177 277 minecraft:stripped_oak_log
setblock 386 177 282 minecraft:brown_terracotta
setblock 387 177 276 minecraft:stripped_oak_log
fill 387 177 277 387 180 277 minecraft:red_terracotta
fill 387 177 278 387 177 281 minecraft:brown_terracotta
fill 388 177 276 388 180 276 minecraft:red_terracotta
fill 388 177 316 391 177 316 minecraft:red_terracotta
setblock 390 177 278 minecraft:stripped_oak_log
setblock 391 177 277 minecraft:stripped_oak_log
fill 391 177 278 391 180 278 minecraft:red_terracotta
setblock 392 177 276 minecraft:stripped_oak_log
fill 392 177 277 392 180 277 minecraft:red_terracotta
fill 392 177 279 393 177 279 minecraft:red_terracotta
setblock 392 177 316 minecraft:stripped_oak_log
fill 393 177 276 393 180 276 minecraft:red_terracotta
setblock 393 177 315 minecraft:stripped_oak_log
fill 393 177 316 393 180 316 minecraft:red_terracotta
fill 394 177 315 394 180 315 minecraft:red_terracotta
setblock 395 177 278 minecraft:stripped_oak_log
setblock 396 177 277 minecraft:stripped_oak_log
fill 396 177 278 396 180 278 minecraft:red_terracotta
setblock 397 177 276 minecraft:stripped_oak_log
fill 397 177 277 397 180 277 minecraft:red_terracotta
setblock 397 177 316 minecraft:stripped_oak_log
fill 398 177 276 398 180 276 minecraft:red_terracotta
fill 398 177 316 398 180 316 minecraft:red_terracotta
setblock 400 177 277 minecraft:stripped_oak_log
setblock 402 177 276 minecraft:stripped_oak_log
setblock 402 177 316 minecraft:stripped_oak_log
setblock 403 177 276 minecraft:red_terracotta
fill 403 177 316 403 180 316 minecraft:red_terracotta
setblock 407 177 276 minecraft:stripped_oak_log
setblock 407 177 316 minecraft:stripped_oak_log
fill 408 177 276 408 180 276 minecraft:red_terracotta
setblock 408 177 277 minecraft:stripped_oak_log
fill 408 177 316 408 180 316 minecraft:red_terracotta
fill 409 177 315 409 180 315 minecraft:red_terracotta
setblock 410 177 277 minecraft:red_terracotta
setblock 411 177 277 minecraft:stripped_oak_log
setblock 412 177 276 minecraft:stripped_oak_log
fill 412 177 277 412 180 277 minecraft:red_terracotta
setblock 412 177 316 minecraft:stripped_oak_log
fill 413 177 276 413 180 276 minecraft:red_terracotta
setblock 413 177 315 minecraft:stripped_oak_log
fill 413 177 316 413 180 316 minecraft:red_terracotta
setblock 414 177 298 minecraft:red_terracotta
setblock 414 177 299 minecraft:stripped_oak_log
fill 414 177 300 414 180 300 minecraft:red_terracotta
setblock 414 177 315 minecraft:red_terracotta
setblock 415 177 298 minecraft:stripped_oak_log
fill 415 177 299 415 180 299 minecraft:red_terracotta
setblock 415 177 303 minecraft:stripped_oak_log
setblock 416 177 293 minecraft:red_terracotta
setblock 416 177 297 minecraft:stripped_oak_log
fill 416 177 298 416 180 298 minecraft:red_terracotta
setblock 416 177 302 minecraft:stripped_oak_log
fill 416 177 303 416 180 303 minecraft:red_terracotta
setblock 417 177 276 minecraft:stripped_oak_log
fill 417 177 277 417 180 277 minecraft:red_terracotta
setblock 417 177 291 minecraft:stripped_oak_log
fill 417 177 292 417 180 292 minecraft:red_terracotta
setblock 417 177 296 minecraft:stripped_oak_log
fill 417 177 297 417 180 297 minecraft:red_terracotta
setblock 417 177 301 minecraft:stripped_oak_log
fill 417 177 302 417 180 302 minecraft:red_terracotta
setblock 417 177 306 minecraft:stripped_oak_log
fill 417 177 307 417 180 307 minecraft:red_terracotta
setblock 417 177 316 minecraft:stripped_oak_log
fill 377 178 276 377 178 279 minecraft:red_terracotta
setblock 377 178 280 minecraft:stripped_oak_log
fill 377 178 281 377 178 284 minecraft:red_terracotta
setblock 377 178 285 minecraft:stripped_oak_log
fill 377 178 286 377 181 286 minecraft:red_terracotta
setblock 377 178 289 minecraft:red_terracotta
setblock 377 178 290 minecraft:stripped_oak_log
fill 377 178 291 377 178 294 minecraft:red_terracotta
setblock 377 178 295 minecraft:stripped_oak_log
fill 377 178 296 377 181 296 minecraft:red_terracotta
setblock 377 178 300 minecraft:stripped_oak_log
fill 377 178 301 377 181 301 minecraft:red_terracotta
fill 378 178 276 380 178 276 minecraft:red_terracotta
fill 378 178 284 379 179 284 minecraft:iron_bars
setblock 378 178 299 minecraft:stripped_oak_log
setblock 378 178 300 minecraft:red_terracotta
setblock 381 178 276 minecraft:stripped_oak_log
fill 382 178 276 382 181 276 minecraft:red_terracotta
setblock 385 178 277 minecraft:stripped_oak_log
setblock 386 178 276 minecraft:stripped_oak_log
fill 386 178 277 386 181 277 minecraft:red_terracotta
fill 387 178 276 387 181 276 minecraft:red_terracotta
fill 387 178 278 387 179 278 minecraft:red_terracotta
fill 387 178 316 390 178 316 minecraft:red_terracotta
setblock 389 178 278 minecraft:stripped_oak_log
setblock 390 178 277 minecraft:stripped_oak_log
fill 390 178 278 390 180 279 minecraft:red_terracotta
setblock 391 178 276 minecraft:stripped_oak_log
fill 391 178 277 391 181 277 minecraft:red_terracotta
fill 391 178 279 392 178 279 minecraft:red_terracotta
setblock 391 178 316 minecraft:stripped_oak_log
fill 392 178 276 392 181 276 minecraft:red_terracotta
setblock 392 178 315 minecraft:stripped_oak_log
fill 392 178 316 392 181 316 minecraft:red_terracotta
setblock 393 178 279 minecraft:stripped_oak_log
fill 393 178 315 393 181 315 minecraft:red_terracotta
setblock 394 178 278 minecraft:stripped_oak_log
setblock 395 178 277 minecraft:stripped_oak_log
fill 395 178 278 395 181 278 minecraft:red_terracotta
setblock 396 178 276 minecraft:stripped_oak_log
fill 396 178 277 396 181 277 minecraft:red_terracotta
setblock 396 178 316 minecraft:stripped_oak_log
fill 397 178 276 397 181 276 minecraft:red_terracotta
fill 397 178 316 397 181 316 minecraft:red_terracotta
setblock 399 178 276 minecraft:shroomlight
setblock 399 178 278 minecraft:shroomlight
setblock 399 178 280 minecraft:shroomlight
setblock 399 178 282 minecraft:shroomlight
setblock 400 178 277 minecraft:shroomlight
setblock 400 178 279 minecraft:shroomlight
setblock 400 178 281 minecraft:shroomlight
setblock 401 178 276 minecraft:shroomlight
fill 401 178 277 401 183 277 minecraft:stripped_oak_log
setblock 401 178 278 minecraft:shroomlight
setblock 401 178 280 minecraft:shroomlight
setblock 401 178 282 minecraft:shroomlight
setblock 401 178 316 minecraft:stripped_oak_log
fill 402 178 276 402 181 276 minecraft:red_terracotta
setblock 402 178 277 minecraft:shroomlight
setblock 402 178 279 minecraft:shroomlight
setblock 402 178 281 minecraft:shroomlight
fill 402 178 316 402 181 316 minecraft:red_terracotta
setblock 403 178 276 minecraft:shroomlight
setblock 403 178 278 minecraft:shroomlight
setblock 403 178 280 minecraft:shroomlight
setblock 403 178 282 minecraft:shroomlight
fill 404 178 276 404 179 276 minecraft:red_terracotta
setblock 404 178 277 minecraft:shroomlight
setblock 404 178 279 minecraft:shroomlight
setblock 404 178 281 minecraft:shroomlight
setblock 405 178 276 minecraft:shroomlight
setblock 405 178 278 minecraft:shroomlight
setblock 405 178 280 minecraft:shroomlight
setblock 405 178 282 minecraft:shroomlight
setblock 406 178 276 minecraft:stripped_oak_log
setblock 406 178 277 minecraft:shroomlight
setblock 406 178 279 minecraft:shroomlight
setblock 406 178 281 minecraft:shroomlight
setblock 406 178 316 minecraft:stripped_oak_log
setblock 407 178 276 minecraft:shroomlight
setblock 407 178 278 minecraft:shroomlight
setblock 407 178 280 minecraft:shroomlight
setblock 407 178 282 minecraft:shroomlight
fill 407 178 316 407 181 316 minecraft:red_terracotta
setblock 408 178 277 minecraft:shroomlight
setblock 408 178 279 minecraft:shroomlight
setblock 408 178 281 minecraft:shroomlight
setblock 409 178 276 minecraft:shroomlight
setblock 409 178 278 minecraft:shroomlight
setblock 409 178 280 minecraft:shroomlight
setblock 409 178 282 minecraft:shroomlight
setblock 410 178 277 minecraft:stripped_oak_log
setblock 411 178 276 minecraft:stripped_oak_log
fill 411 178 277 411 181 277 minecraft:red_terracotta
setblock 411 178 316 minecraft:stripped_oak_log
fill 412 178 276 412 181 276 minecraft:red_terracotta
setblock 412 178 315 minecraft:stripped_oak_log
fill 412 178 316 412 181 316 minecraft:red_terracotta
setblock 413 178 315 minecraft:red_terracotta
setblock 414 178 298 minecraft:stripped_oak_log
fill 414 178 299 414 181 299 minecraft:red_terracotta
fill 414 178 301 414 179 301 minecraft:red_terracotta
setblock 415 178 297 minecraft:stripped_oak_log
fill 415 178 298 415 181 298 minecraft:red_terracotta
setblock 415 178 302 minecraft:stripped_oak_log
fill 415 178 303 415 180 304 minecraft:red_terracotta
setblock 416 178 276 minecraft:stripped_oak_log
setblock 416 178 296 minecraft:stripped_oak_log
fill 416 178 297 416 181 297 minecraft:red_terracotta
setblock 416 178 301 minecraft:stripped_oak_log
fill 416 178 302 416 181 302 minecraft:red_terracotta
setblock 416 178 316 minecraft:stripped_oak_log
setblock 417 178 276 minecraft:red_terracotta
setblock 417 178 280 minecraft:stripped_oak_log
fill 417 178 281 417 181 281 minecraft:red_terracotta
setblock 417 178 295 minecraft:stripped_oak_log
fill 417 178 296 417 181 296 minecraft:red_terracotta
setblock 417 178 300 minecraft:stripped_oak_log
fill 417 178 301 417 181 301 minecraft:red_terracotta
setblock 417 178 305 minecraft:stripped_oak_log
fill 417 178 306 417 181 306 minecraft:red_terracotta
fill 377 179 276 377 179 278 minecraft:red_terracotta
setblock 377 179 279 minecraft:stripped_oak_log
fill 377 179 280 377 179 283 minecraft:red_terracotta
setblock 377 179 284 minecraft:stripped_oak_log
fill 377 179 285 377 182 285 minecraft:red_terracotta
fill 377 179 287 377 179 288 minecraft:red_terracotta
fill 377 179 290 377 179 293 minecraft:red_terracotta
setblock 377 179 294 minecraft:stripped_oak_log
fill 377 179 295 377 182 295 minecraft:red_terracotta
setblock 377 179 299 minecraft:stripped_oak_log
fill 377 179 300 377 182 300 minecraft:red_terracotta
setblock 377 179 304 minecraft:stripped_oak_log
fill 378 179 276 379 179 276 minecraft:red_terracotta
fill 378 179 279 378 181 280 minecraft:red_terracotta
setblock 378 179 298 minecraft:stripped_oak_log
setblock 378 179 299 minecraft:red_terracotta
setblock 380 179 276 minecraft:stripped_oak_log
fill 381 179 276 381 182 276 minecraft:red_terracotta
setblock 385 179 276 minecraft:stripped_oak_log
fill 385 179 277 385 182 277 minecraft:red_terracotta
fill 386 179 276 386 182 276 minecraft:red_terracotta
fill 386 179 278 386 180 278 minecraft:red_terracotta
fill 387 179 316 389 179 316 minecraft:red_terracotta
setblock 388 179 277 minecraft:red_terracotta
setblock 388 179 278 minecraft:stripped_oak_log
setblock 389 179 277 minecraft:stripped_oak_log
fill 389 179 278 389 181 279 minecraft:red_terracotta
setblock 390 179 276 minecraft:stripped_oak_log
fill 390 179 277 390 182 277 minecraft:red_terracotta
setblock 390 179 315 minecraft:red_terracotta
setblock 390 179 316 minecraft:stripped_oak_log
fill 391 179 276 391 182 276 minecraft:red_terracotta
setblock 391 179 279 minecraft:red_terracotta
setblock 391 179 315 minecraft:stripped_oak_log
fill 391 179 316 391 182 316 minecraft:red_terracotta
setblock 392 179 279 minecraft:stripped_oak_log
fill 392 179 315 392 182 315 minecraft:red_terracotta
setblock 393 179 278 minecraft:stripped_oak_log
fill 393 179 279 393 182 279 minecraft:red_terracotta
setblock 394 179 277 minecraft:stripped_oak_log
fill 394 179 278 394 182 278 minecraft:red_terracotta
setblock 395 179 276 minecraft:stripped_oak_log
fill 395 179 277 395 182 277 minecraft:red_terracotta
setblock 395 179 316 minecraft:stripped_oak_log
fill 396 179 276 396 182 276 minecraft:red_terracotta
fill 396 179 316 396 182 316 minecraft:red_terracotta
setblock 399 179 276 minecraft:red_terracotta
fill 399 179 277 399 180 278 minecraft:stripped_oak_log
fill 399 179 280 399 180 280 minecraft:stripped_oak_log
fill 399 179 282 399 180 282 minecraft:stripped_oak_log
fill 400 179 276 400 179 277 minecraft:stripped_oak_log
fill 400 179 279 400 180 279 minecraft:stripped_oak_log
fill 400 179 281 400 180 281 minecraft:stripped_oak_log
setblock 400 179 316 minecraft:stripped_oak_log
fill 401 179 276 401 180 276 minecraft:red_terracotta
fill 401 179 278 401 180 278 minecraft:stripped_oak_log
fill 401 179 280 401 180 280 minecraft:stripped_oak_log
fill 401 179 282 401 180 282 minecraft:stripped_oak_log
fill 401 179 316 401 182 316 minecraft:red_terracotta
fill 402 179 277 402 180 277 minecraft:stripped_oak_log
fill 402 179 279 402 180 279 minecraft:stripped_oak_log
fill 402 179 281 402 180 281 minecraft:stripped_oak_log
fill 403 179 276 403 180 276 minecraft:red_terracotta
fill 403 179 278 403 180 278 minecraft:stripped_oak_log
fill 403 179 280 403 180 280 minecraft:stripped_oak_log
fill 403 179 282 403 180 282 minecraft:stripped_oak_log
fill 404 179 277 404 180 277 minecraft:stripped_oak_log
fill 404 179 279 404 180 279 minecraft:stripped_oak_log
fill 404 179 281 404 180 281 minecraft:stripped_oak_log
setblock 405 179 276 minecraft:stripped_oak_log
fill 405 179 278 405 180 278 minecraft:stripped_oak_log
fill 405 179 280 405 180 280 minecraft:stripped_oak_log
fill 405 179 282 405 180 282 minecraft:stripped_oak_log
setblock 405 179 316 minecraft:stripped_oak_log
fill 406 179 276 407 180 276 minecraft:red_terracotta
fill 406 179 277 406 180 277 minecraft:stripped_oak_log
fill 406 179 279 406 180 279 minecraft:stripped_oak_log
fill 406 179 281 406 180 281 minecraft:stripped_oak_log
fill 406 179 316 406 182 316 minecraft:red_terracotta
fill 407 179 278 407 180 278 minecraft:stripped_oak_log
fill 407 179 280 407 180 280 minecraft:stripped_oak_log
fill 407 179 282 407 180 282 minecraft:stripped_oak_log
fill 408 179 277 408 180 277 minecraft:stripped_oak_log
fill 408 179 279 408 180 279 minecraft:stripped_oak_log
fill 408 179 281 408 180 281 minecraft:stripped_oak_log
setblock 409 179 276 minecraft:red_terracotta
fill 409 179 278 409 180 278 minecraft:stripped_oak_log
fill 409 179 280 409 180 280 minecraft:stripped_oak_log
fill 409 179 282 409 180 282 minecraft:stripped_oak_log
setblock 410 179 276 minecraft:stripped_oak_log
fill 410 179 277 410 182 277 minecraft:red_terracotta
setblock 410 179 316 minecraft:stripped_oak_log
fill 411 179 276 411 182 276 minecraft:red_terracotta
setblock 411 179 315 minecraft:stripped_oak_log
fill 411 179 316 411 182 316 minecraft:red_terracotta
setblock 412 179 315 minecraft:red_terracotta
setblock 414 179 302 minecraft:stripped_oak_log
setblock 415 179 276 minecraft:stripped_oak_log
setblock 415 179 296 minecraft:stripped_oak_log
fill 415 179 297 415 182 297 minecraft:red_terracotta
setblock 415 179 301 minecraft:stripped_oak_log
fill 415 179 302 415 182 302 minecraft:red_terracotta
setblock 415 179 316 minecraft:stripped_oak_log
fill 416 179 276 416 181 276 minecraft:red_terracotta
setblock 416 179 295 minecraft:stripped_oak_log
fill 416 179 296 416 182 296 minecraft:red_terracotta
setblock 416 179 300 minecraft:stripped_oak_log
fill 416 179 301 416 182 301 minecraft:red_terracotta
setblock 416 179 305 minecraft:stripped_oak_log
fill 416 179 306 416 182 306 minecraft:red_terracotta
setblock 417 179 279 minecraft:stripped_oak_log
fill 417 179 280 417 182 280 minecraft:red_terracotta
fill 417 179 282 417 180 282 minecraft:red_terracotta
setblock 417 179 294 minecraft:stripped_oak_log
fill 417 179 295 417 182 295 minecraft:red_terracotta
setblock 417 179 299 minecraft:stripped_oak_log
fill 417 179 300 417 182 300 minecraft:red_terracotta
setblock 417 179 304 minecraft:stripped_oak_log
fill 417 179 305 417 182 305 minecraft:red_terracotta
fill 376 180 275 376 183 317 minecraft:white_terracotta
fill 377 180 275 418 183 275 minecraft:white_terracotta
fill 377 180 276 377 180 277 minecraft:red_terracotta
setblock 377 180 278 minecraft:stripped_oak_log
fill 377 180 279 377 180 282 minecraft:red_terracotta
setblock 377 180 283 minecraft:stripped_oak_log
fill 377 180 284 377 183 284 minecraft:red_terracotta
setblock 377 180 287 minecraft:red_terracotta
setblock 377 180 288 minecraft:stripped_oak_log
fill 377 180 289 377 180 292 minecraft:red_terracotta
setblock 377 180 293 minecraft:stripped_oak_log
fill 377 180 294 377 182 294 minecraft:red_terracotta
setblock 377 180 298 minecraft:stripped_oak_log
fill 377 180 299 377 183 299 minecraft:red_terracotta
setblock 377 180 303 minecraft:stripped_oak_log
fill 377 180 304 377 183 304 minecraft:red_terracotta
fill 377 180 317 418 183 317 minecraft:white_terracotta
setblock 378 180 276 minecraft:red_terracotta
setblock 378 180 281 minecraft:red_terracotta
setblock 378 180 282 minecraft:stripped_oak_log
setblock 379 180 276 minecraft:stripped_oak_log
setblock 379 180 278 minecraft:light[level=12]
setblock 379 180 285 minecraft:light[level=12]
setblock 379 180 292 minecraft:light[level=12]
setblock 379 180 299 minecraft:light[level=12]
setblock 379 180 306 minecraft:light[level=12]
setblock 379 180 313 minecraft:light[level=12]
fill 380 180 276 380 183 276 minecraft:red_terracotta
fill 382 180 278 384 180 278 minecraft:stripped_oak_log
setblock 383 180 277 minecraft:stripped_oak_log
setblock 384 180 276 minecraft:stripped_oak_log
fill 384 180 277 384 183 277 minecraft:red_terracotta
fill 385 180 276 385 183 276 minecraft:red_terracotta
fill 385 180 278 385 181 278 minecraft:red_terracotta
setblock 386 180 285 minecraft:light[level=12]
setblock 386 180 292 minecraft:light[level=12]
setblock 386 180 306 minecraft:light[level=12]
setblock 386 180 313 minecraft:light[level=12]
fill 386 180 316 388 180 316 minecraft:red_terracotta
setblock 387 180 278 minecraft:stripped_oak_log
setblock 388 180 277 minecraft:stripped_oak_log
fill 388 180 278 388 182 279 minecraft:red_terracotta
setblock 389 180 276 minecraft:stripped_oak_log
fill 389 180 277 389 183 277 minecraft:red_terracotta
setblock 389 180 316 minecraft:stripped_oak_log
fill 390 180 276 390 183 276 minecraft:red_terracotta
setblock 390 180 315 minecraft:stripped_oak_log
fill 390 180 316 390 183 316 minecraft:red_terracotta
setblock 391 180 279 minecraft:stripped_oak_log
fill 391 180 315 391 183 315 minecraft:red_terracotta
setblock 392 180 278 minecraft:stripped_oak_log
fill 392 180 279 392 183 279 minecraft:red_terracotta
setblock 393 180 277 minecraft:stripped_oak_log
fill 393 180 278 393 183 278 minecraft:red_terracotta
setblock 393 180 285 minecraft:light[level=12]
setblock 393 180 292 minecraft:light[level=12]
setblock 393 180 299 minecraft:light[level=12]
setblock 393 180 306 minecraft:light[level=12]
setblock 393 180 313 minecraft:light[level=12]
setblock 394 180 276 minecraft:stripped_oak_log
fill 394 180 277 394 183 277 minecraft:red_terracotta
setblock 394 180 316 minecraft:stripped_oak_log
fill 395 180 276 395 183 276 minecraft:red_terracotta
setblock 395 180 315 minecraft:stripped_oak_log
fill 395 180 316 395 183 316 minecraft:red_terracotta
setblock 398 180 277 minecraft:stripped_oak_log
setblock 399 180 276 minecraft:stripped_oak_log
setblock 399 180 316 minecraft:stripped_oak_log
fill 400 180 276 400 183 276 minecraft:red_terracotta
setblock 400 180 277 minecraft:stripped_oak_log
setblock 400 180 285 minecraft:light[level=12]
setblock 400 180 292 minecraft:light[level=12]
setblock 400 180 299 minecraft:light[level=12]
setblock 400 180 306 minecraft:light[level=12]
setblock 400 180 313 minecraft:light[level=12]
fill 400 180 316 400 183 316 minecraft:red_terracotta
setblock 404 180 276 minecraft:stripped_oak_log
setblock 404 180 316 minecraft:stripped_oak_log
setblock 405 180 276 minecraft:red_terracotta
fill 405 180 316 405 183 316 minecraft:red_terracotta
setblock 407 180 285 minecraft:light[level=12]
setblock 407 180 292 minecraft:light[level=12]
setblock 407 180 299 minecraft:light[level=12]
setblock 407 180 306 minecraft:light[level=12]
setblock 407 180 313 minecraft:light[level=12]
setblock 409 180 276 minecraft:stripped_oak_log
fill 409 180 277 409 183 277 minecraft:red_terracotta
setblock 409 180 316 minecraft:stripped_oak_log
fill 410 180 276 410 183 276 minecraft:red_terracotta
setblock 410 180 315 minecraft:stripped_oak_log
fill 410 180 316 410 183 316 minecraft:red_terracotta
fill 411 180 315 411 181 315 minecraft:red_terracotta
setblock 413 180 277 minecraft:stripped_oak_log
setblock 414 180 276 minecraft:stripped_oak_log
setblock 414 180 278 minecraft:light[level=12]
setblock 414 180 285 minecraft:light[level=12]
setblock 414 180 292 minecraft:light[level=12]
setblock 414 180 301 minecraft:stripped_oak_log
fill 414 180 302 414 182 303 minecraft:red_terracotta
setblock 414 180 306 minecraft:light[level=12]
setblock 414 180 313 minecraft:light[level=12]
setblock 414 180 316 minecraft:stripped_oak_log
fill 415 180 276 415 182 276 minecraft:red_terracotta
setblock 415 180 296 minecraft:red_terracotta
setblock 415 180 300 minecraft:stripped_oak_log
fill 415 180 301 415 183 301 minecraft:red_terracotta
setblock 415 180 305 minecraft:stripped_oak_log
setblock 415 180 316 minecraft:red_terracotta
setblock 416 180 294 minecraft:stripped_oak_log
fill 416 180 295 416 182 295 minecraft:red_terracotta
setblock 416 180 299 minecraft:stripped_oak_log
fill 416 180 300 416 183 300 minecraft:red_terracotta
setblock 416 180 304 minecraft:stripped_oak_log
fill 416 180 305 416 183 305 minecraft:red_terracotta
setblock 417 180 278 minecraft:stripped_oak_log
fill 417 180 279 417 183 279 minecraft:red_terracotta
setblock 417 180 283 minecraft:stripped_oak_log
fill 417 180 284 417 183 284 minecraft:red_terracotta
setblock 417 180 293 minecraft:stripped_oak_log
fill 417 180 294 417 183 294 minecraft:red_terracotta
setblock 417 180 298 minecraft:stripped_oak_log
fill 417 180 299 417 183 299 minecraft:red_terracotta
setblock 417 180 303 minecraft:stripped_oak_log
fill 417 180 304 417 183 304 minecraft:red_terracotta
fill 418 180 276 418 183 316 minecraft:white_terracotta
setblock 377 181 276 minecraft:red_terracotta
setblock 377 181 277 minecraft:stripped_oak_log
fill 377 181 278 377 181 281 minecraft:red_terracotta
setblock 377 181 282 minecraft:stripped_oak_log
fill 377 181 283 378 183 283 minecraft:red_terracotta
setblock 377 181 287 minecraft:stripped_oak_log
fill 377 181 288 377 181 291 minecraft:red_terracotta
setblock 377 181 292 minecraft:stripped_oak_log
fill 377 181 293 377 182 293 minecraft:red_terracotta
setblock 377 181 297 minecraft:stripped_oak_log
fill 377 181 298 377 184 298 minecraft:red_terracotta
setblock 377 181 302 minecraft:stripped_oak_log
fill 377 181 303 377 184 303 minecraft:red_terracotta
fill 377 181 305 377 182 305 minecraft:red_terracotta
setblock 378 181 276 minecraft:stripped_oak_log
fill 378 181 278 378 183 278 minecraft:red_terracotta
setblock 378 181 281 minecraft:stripped_oak_log
fill 378 181 282 378 184 282 minecraft:red_terracotta
fill 378 181 284 378 182 284 minecraft:red_terracotta
fill 379 181 276 379 184 276 minecraft:red_terracotta
fill 382 181 277 382 181 278 minecraft:stripped_oak_log
setblock 383 181 276 minecraft:stripped_oak_log
fill 383 181 277 383 184 277 minecraft:red_terracotta
setblock 383 181 278 minecraft:stripped_oak_log
fill 384 181 276 384 184 276 minecraft:red_terracotta
fill 384 181 278 384 182 278 minecraft:red_terracotta
setblock 386 181 278 minecraft:stripped_oak_log
fill 386 181 279 387 183 279 minecraft:red_terracotta
fill 386 181 316 387 181 316 minecraft:red_terracotta
setblock 387 181 277 minecraft:stripped_oak_log
fill 387 181 278 387 184 278 minecraft:red_terracotta
setblock 388 181 276 minecraft:stripped_oak_log
fill 388 181 277 388 184 277 minecraft:red_terracotta
setblock 388 181 316 minecraft:stripped_oak_log
fill 389 181 276 389 184 276 minecraft:red_terracotta
setblock 389 181 315 minecraft:stripped_oak_log
fill 389 181 316 389 184 316 minecraft:red_terracotta
setblock 390 181 278 minecraft:red_terracotta
setblock 390 181 279 minecraft:stripped_oak_log
fill 390 181 315 390 184 315 minecraft:red_terracotta
setblock 391 181 278 minecraft:stripped_oak_log
fill 391 181 279 391 184 279 minecraft:red_terracotta
setblock 392 181 277 minecraft:stripped_oak_log
fill 392 181 278 392 184 278 minecraft:red_terracotta
setblock 393 181 276 minecraft:stripped_oak_log
fill 393 181 277 393 184 277 minecraft:red_terracotta
setblock 393 181 316 minecraft:stripped_oak_log
fill 394 181 276 394 184 276 minecraft:red_terracotta
setblock 394 181 315 minecraft:stripped_oak_log
fill 394 181 316 394 184 316 minecraft:red_terracotta
setblock 397 181 277 minecraft:stripped_oak_log
setblock 398 181 276 minecraft:stripped_oak_log
setblock 398 181 277 minecraft:red_terracotta
setblock 398 181 316 minecraft:stripped_oak_log
setblock 399 181 276 minecraft:shroomlight
fill 399 181 277 399 183 277 minecraft:stripped_oak_log
setblock 399 181 278 minecraft:shroomlight
setblock 399 181 280 minecraft:shroomlight
setblock 399 181 282 minecraft:shroomlight
fill 399 181 316 399 184 316 minecraft:red_terracotta
setblock 400 181 277 minecraft:shroomlight
setblock 400 181 279 minecraft:shroomlight
setblock 400 181 281 minecraft:shroomlight
setblock 401 181 276 minecraft:shroomlight
setblock 401 181 278 minecraft:shroomlight
setblock 401 181 280 minecraft:shroomlight
setblock 401 181 282 minecraft:shroomlight
setblock 402 181 277 minecraft:shroomlight
setblock 402 181 279 minecraft:shroomlight
setblock 402 181 281 minecraft:shroomlight
setblock 403 181 276 minecraft:shroomlight
setblock 403 181 278 minecraft:shroomlight
setblock 403 181 280 minecraft:shroomlight
setblock 403 181 282 minecraft:shroomlight
setblock 403 181 316 minecraft:stripped_oak_log
fill 404 181 276 404 184 276 minecraft:red_terracotta
setblock 404 181 277 minecraft:shroomlight
setblock 404 181 279 minecraft:shroomlight
setblock 404 181 281 minecraft:shroomlight
fill 404 181 316 404 184 316 minecraft:red_terracotta
setblock 405 181 276 minecraft:shroomlight
setblock 405 181 278 minecraft:shroomlight
setblock 405 181 280 minecraft:shroomlight
setblock 405 181 282 minecraft:shroomlight
fill 406 181 276 406 182 276 minecraft:red_terracotta
setblock 406 181 277 minecraft:shroomlight
setblock 406 181 279 minecraft:shroomlight
setblock 406 181 281 minecraft:shroomlight
setblock 407 181 276 minecraft:shroomlight
setblock 407 181 278 minecraft:shroomlight
setblock 407 181 280 minecraft:shroomlight
setblock 407 181 282 minecraft:shroomlight
setblock 408 181 276 minecraft:stripped_oak_log
setblock 408 181 277 minecraft:shroomlight
setblock 408 181 279 minecraft:shroomlight
setblock 408 181 281 minecraft:shroomlight
setblock 408 181 315 minecraft:red_terracotta
setblock 408 181 316 minecraft:stripped_oak_log
setblock 409 181 276 minecraft:shroomlight
setblock 409 181 278 minecraft:shroomlight
setblock 409 181 280 minecraft:shroomlight
setblock 409 181 282 minecraft:shroomlight
setblock 409 181 315 minecraft:stripped_oak_log
fill 409 181 316 409 184 316 minecraft:red_terracotta
fill 410 181 315 410 183 315 minecraft:red_terracotta
setblock 412 181 277 minecraft:stripped_oak_log
setblock 413 181 276 minecraft:stripped_oak_log
fill 413 181 277 413 182 277 minecraft:red_terracotta
setblock 413 181 316 minecraft:stripped_oak_log
fill 414 181 276 414 183 276 minecraft:red_terracotta
setblock 414 181 300 minecraft:stripped_oak_log
fill 414 181 301 414 184 301 minecraft:red_terracotta
setblock 414 181 316 minecraft:red_terracotta
setblock 415 181 299 minecraft:stripped_oak_log
fill 415 181 300 415 184 300 minecraft:red_terracotta
setblock 415 181 303 minecraft:red_terracotta
setblock 415 181 304 minecraft:stripped_oak_log
fill 415 181 305 415 184 305 minecraft:red_terracotta
setblock 416 181 298 minecraft:stripped_oak_log
fill 416 181 299 416 184 299 minecraft:red_terracotta
setblock 416 181 303 minecraft:stripped_oak_log
fill 416 181 304 416 184 304 minecraft:red_terracotta
setblock 417 181 277 minecraft:stripped_oak_log
fill 417 181 278 417 184 278 minecraft:red_terracotta
setblock 417 181 282 minecraft:stripped_oak_log
fill 417 181 283 417 184 283 minecraft:red_terracotta
fill 417 181 285 417 181 286 minecraft:red_terracotta
setblock 417 181 292 minecraft:stripped_oak_log
fill 417 181 293 417 184 293 minecraft:red_terracotta
setblock 417 181 297 minecraft:stripped_oak_log
fill 417 181 298 417 184 298 minecraft:red_terracotta
setblock 417 181 302 minecraft:stripped_oak_log
fill 417 181 303 417 184 303 minecraft:red_terracotta
setblock 417 181 307 minecraft:stripped_oak_log
fill 417 181 308 417 184 308 minecraft:red_terracotta
setblock 377 182 276 minecraft:stripped_oak_log
fill 377 182 277 377 182 280 minecraft:red_terracotta
setblock 377 182 281 minecraft:stripped_oak_log
fill 377 182 282 377 185 282 minecraft:red_terracotta
setblock 377 182 286 minecraft:stripped_oak_log
fill 377 182 287 377 182 290 minecraft:red_terracotta
setblock 377 182 291 minecraft:stripped_oak_log
fill 377 182 292 377 183 292 minecraft:red_terracotta
setblock 377 182 296 minecraft:stripped_oak_log
fill 377 182 297 377 184 297 minecraft:red_terracotta
setblock 377 182 301 minecraft:stripped_oak_log
fill 377 182 302 377 185 302 minecraft:red_terracotta
fill 378 182 276 378 185 276 minecraft:red_terracotta
setblock 378 182 279 minecraft:red_terracotta
setblock 378 182 280 minecraft:stripped_oak_log
fill 378 182 281 378 185 281 minecraft:red_terracotta
setblock 378 182 285 minecraft:stripped_oak_log
setblock 381 182 277 minecraft:stripped_oak_log
fill 381 182 279 384 183 280 minecraft:stripped_oak_log
setblock 382 182 276 minecraft:stripped_oak_log
fill 382 182 277 382 185 277 minecraft:red_terracotta
fill 382 182 278 382 183 278 minecraft:stripped_oak_log
fill 383 182 276 383 185 276 minecraft:red_terracotta
fill 383 182 278 383 183 278 minecraft:red_terracotta
setblock 385 182 278 minecraft:stripped_oak_log
fill 385 182 279 385 185 279 minecraft:red_terracotta
fill 385 182 280 385 218 280 minecraft:stripped_oak_log
fill 385 182 316 386 182 316 minecraft:red_terracotta
setblock 386 182 277 minecraft:stripped_oak_log
fill 386 182 278 386 185 278 minecraft:red_terracotta
setblock 387 182 276 minecraft:stripped_oak_log
fill 387 182 277 387 185 277 minecraft:red_terracotta
setblock 387 182 316 minecraft:stripped_oak_log
fill 388 182 276 388 185 276 minecraft:red_terracotta
setblock 388 182 315 minecraft:stripped_oak_log
fill 388 182 316 388 185 316 minecraft:red_terracotta
setblock 389 182 278 minecraft:red_terracotta
setblock 389 182 279 minecraft:stripped_oak_log
fill 389 182 315 389 185 315 minecraft:red_terracotta
setblock 390 182 278 minecraft:stripped_oak_log
fill 390 182 279 390 185 279 minecraft:red_terracotta
setblock 391 182 277 minecraft:stripped_oak_log
fill 391 182 278 391 185 278 minecraft:red_terracotta
setblock 392 182 276 minecraft:stripped_oak_log
fill 392 182 277 392 185 277 minecraft:red_terracotta
setblock 392 182 316 minecraft:stripped_oak_log
fill 393 182 276 393 185 276 minecraft:red_terracotta
setblock 393 182 315 minecraft:stripped_oak_log
fill 393 182 316 393 185 316 minecraft:red_terracotta
fill 394 182 315 394 184 315 minecraft:red_terracotta
setblock 395 182 278 minecraft:stripped_oak_log
setblock 396 182 277 minecraft:stripped_oak_log
setblock 397 182 276 minecraft:stripped_oak_log
setblock 397 182 277 minecraft:red_terracotta
setblock 397 182 316 minecraft:stripped_oak_log
fill 398 182 276 399 184 276 minecraft:red_terracotta
fill 398 182 316 398 185 316 minecraft:red_terracotta
fill 399 182 278 399 183 278 minecraft:stripped_oak_log
fill 399 182 280 399 183 280 minecraft:stripped_oak_log
fill 399 182 282 399 183 282 minecraft:stripped_oak_log
fill 400 182 277 400 183 277 minecraft:stripped_oak_log
fill 400 182 279 400 183 279 minecraft:stripped_oak_log
fill 400 182 281 400 183 281 minecraft:stripped_oak_log
setblock 401 182 276 minecraft:red_terracotta
fill 401 182 278 401 183 278 minecraft:stripped_oak_log
fill 401 182 280 401 183 280 minecraft:stripped_oak_log
fill 401 182 282 401 183 282 minecraft:stripped_oak_log
fill 402 182 276 402 182 277 minecraft:stripped_oak_log
fill 402 182 279 402 183 279 minecraft:stripped_oak_log
fill 402 182 281 402 183 281 minecraft:stripped_oak_log
setblock 402 182 316 minecraft:stripped_oak_log
fill 403 182 276 403 185 276 minecraft:red_terracotta
fill 403 182 278 403 183 278 minecraft:stripped_oak_log
fill 403 182 280 403 183 280 minecraft:stripped_oak_log
fill 403 182 282 403 183 282 minecraft:stripped_oak_log
fill 403 182 316 403 185 316 minecraft:red_terracotta
fill 404 182 277 404 183 277 minecraft:stripped_oak_log
fill 404 182 279 404 183 279 minecraft:stripped_oak_log
fill 404 182 281 404 183 281 minecraft:stripped_oak_log
fill 405 182 276 405 183 276 minecraft:red_terracotta
fill 405 182 278 405 183 278 minecraft:stripped_oak_log
fill 405 182 280 405 183 280 minecraft:stripped_oak_log
fill 405 182 282 405 183 282 minecraft:stripped_oak_log
setblock 406 182 277 minecraft:stripped_oak_log
fill 406 182 279 406 183 279 minecraft:stripped_oak_log
fill 406 182 281 406 183 281 minecraft:stripped_oak_log
setblock 407 182 276 minecraft:stripped_oak_log
fill 407 182 277 408 184 277 minecraft:red_terracotta
fill 407 182 278 407 183 278 minecraft:stripped_oak_log
fill 407 182 280 407 183 280 minecraft:stripped_oak_log
fill 407 182 282 407 183 282 minecraft:stripped_oak_log
setblock 407 182 315 minecraft:red_terracotta
setblock 407 182 316 minecraft:stripped_oak_log
fill 408 182 276 409 184 276 minecraft:red_terracotta
fill 408 182 279 408 183 279 minecraft:stripped_oak_log
fill 408 182 281 408 183 281 minecraft:stripped_oak_log
setblock 408 182 315 minecraft:stripped_oak_log
fill 408 182 316 408 185 316 minecraft:red_terracotta
fill 409 182 278 409 183 278 minecraft:stripped_oak_log
fill 409 182 280 409 183 280 minecraft:stripped_oak_log
fill 409 182 282 409 183 282 minecraft:stripped_oak_log
fill 409 182 315 409 185 315 minecraft:red_terracotta
setblock 411 182 277 minecraft:stripped_oak_log
setblock 412 182 276 minecraft:stripped_oak_log
fill 412 182 277 412 183 277 minecraft:red_terracotta
setblock 412 182 316 minecraft:stripped_oak_log
fill 413 182 276 413 184 276 minecraft:red_terracotta
fill 413 182 316 413 183 316 minecraft:red_terracotta
setblock 414 182 299 minecraft:stripped_oak_log
fill 414 182 300 414 183 300 minecraft:red_terracotta
setblock 414 182 304 minecraft:stripped_oak_log
setblock 415 182 298 minecraft:stripped_oak_log
fill 415 182 299 415 184 299 minecraft:red_terracotta
setblock 415 182 303 minecraft:stripped_oak_log
fill 415 182 304 415 185 304 minecraft:red_terracotta
fill 415 182 306 415 183 306 minecraft:red_terracotta
setblock 416 182 281 minecraft:red_terracotta
setblock 416 182 282 minecraft:stripped_oak_log
fill 416 182 283 416 185 283 minecraft:red_terracotta
setblock 416 182 297 minecraft:stripped_oak_log
fill 416 182 298 416 185 298 minecraft:red_terracotta
setblock 416 182 302 minecraft:stripped_oak_log
fill 416 182 303 416 185 303 minecraft:red_terracotta
setblock 416 182 307 minecraft:stripped_oak_log
setblock 417 182 281 minecraft:stripped_oak_log
fill 417 182 282 417 185 282 minecraft:red_terracotta
setblock 417 182 285 minecraft:red_terracotta
setblock 417 182 286 minecraft:stripped_oak_log
fill 417 182 287 417 182 290 minecraft:red_terracotta
setblock 417 182 291 minecraft:stripped_oak_log
fill 417 182 292 417 185 292 minecraft:red_terracotta
setblock 417 182 296 minecraft:stripped_oak_log
fill 417 182 297 417 185 297 minecraft:red_terracotta
setblock 417 182 301 minecraft:stripped_oak_log
fill 417 182 302 417 185 302 minecraft:red_terracotta
setblock 417 182 306 minecraft:stripped_oak_log
fill 417 182 307 417 185 307 minecraft:red_terracotta
fill 377 183 276 377 183 279 minecraft:red_terracotta
setblock 377 183 280 minecraft:stripped_oak_log
fill 377 183 281 377 186 281 minecraft:red_terracotta
setblock 377 183 285 minecraft:stripped_oak_log
fill 377 183 286 377 183 289 minecraft:red_terracotta
setblock 377 183 290 minecraft:stripped_oak_log
fill 377 183 291 377 186 291 minecraft:red_terracotta
setblock 377 183 295 minecraft:stripped_oak_log
setblock 377 183 296 minecraft:red_terracotta
setblock 377 183 300 minecraft:stripped_oak_log
fill 377 183 301 377 185 301 minecraft:red_terracotta
setblock 377 183 305 minecraft:stripped_oak_log
fill 377 183 306 377 186 306 minecraft:red_terracotta
setblock 378 183 279 minecraft:stripped_oak_log
fill 378 183 280 378 186 280 minecraft:red_terracotta
setblock 378 183 284 minecraft:stripped_oak_log
fill 378 183 285 378 184 287 minecraft:red_terracotta
setblock 379 183 282 minecraft:red_terracotta
setblock 381 183 276 minecraft:stripped_oak_log
fill 381 183 277 381 186 277 minecraft:red_terracotta
fill 382 183 276 382 186 276 minecraft:red_terracotta
setblock 384 183 278 minecraft:stripped_oak_log
setblock 385 183 277 minecraft:stripped_oak_log
fill 385 183 278 385 186 278 minecraft:red_terracotta
setblock 385 183 316 minecraft:red_terracotta
setblock 386 183 276 minecraft:stripped_oak_log
fill 386 183 277 386 186 277 minecraft:red_terracotta
setblock 386 183 316 minecraft:stripped_oak_log
fill 387 183 276 387 186 276 minecraft:red_terracotta
setblock 387 183 315 minecraft:stripped_oak_log
fill 387 183 316 387 186 316 minecraft:red_terracotta
setblock 388 183 278 minecraft:red_terracotta
setblock 388 183 279 minecraft:stripped_oak_log
fill 388 183 280 389 184 280 minecraft:red_terracotta
fill 388 183 315 388 186 315 minecraft:red_terracotta
setblock 389 183 278 minecraft:stripped_oak_log
fill 389 183 279 389 186 279 minecraft:red_terracotta
setblock 390 183 277 minecraft:stripped_oak_log
fill 390 183 278 390 186 278 minecraft:red_terracotta
setblock 391 183 276 minecraft:stripped_oak_log
fill 391 183 277 391 186 277 minecraft:red_terracotta
setblock 391 183 316 minecraft:stripped_oak_log
fill 392 183 276 392 186 276 minecraft:red_terracotta
setblock 392 183 315 minecraft:stripped_oak_log
fill 392 183 316 392 186 316 minecraft:red_terracotta
setblock 393 183 279 minecraft:stripped_oak_log
fill 393 183 315 393 185 315 minecraft:red_terracotta
setblock 394 183 278 minecraft:stripped_oak_log
setblock 395 183 277 minecraft:stripped_oak_log
setblock 396 183 276 minecraft:stripped_oak_log
fill 396 183 277 396 184 277 minecraft:red_terracotta
setblock 396 183 316 minecraft:stripped_oak_log
fill 397 183 276 397 185 276 minecraft:red_terracotta
fill 397 183 316 397 185 316 minecraft:red_terracotta
setblock 401 183 276 minecraft:stripped_oak_log
setblock 401 183 316 minecraft:stripped_oak_log
fill 402 183 276 402 184 276 minecraft:red_terracotta
setblock 402 183 277 minecraft:stripped_oak_log
fill 402 183 316 402 186 316 minecraft:red_terracotta
setblock 406 183 276 minecraft:stripped_oak_log
fill 406 183 277 406 184 277 minecraft:red_terracotta
setblock 406 183 315 minecraft:red_terracotta
setblock 406 183 316 minecraft:stripped_oak_log
fill 407 183 276 407 186 276 minecraft:red_terracotta
setblock 407 183 315 minecraft:stripped_oak_log
fill 407 183 316 407 186 316 minecraft:red_terracotta
fill 408 183 315 408 186 315 minecraft:red_terracotta
setblock 410 183 277 minecraft:stripped_oak_log
setblock 411 183 276 minecraft:stripped_oak_log
fill 411 183 277 411 184 277 minecraft:red_terracotta
setblock 411 183 316 minecraft:stripped_oak_log
fill 412 183 276 412 185 276 minecraft:red_terracotta
fill 412 183 316 412 184 316 minecraft:red_terracotta
setblock 414 183 302 minecraft:red_terracotta
setblock 414 183 303 minecraft:stripped_oak_log
fill 414 183 304 414 184 304 minecraft:red_terracotta
setblock 415 183 298 minecraft:red_terracotta
setblock 415 183 302 minecraft:stripped_oak_log
fill 415 183 303 415 185 303 minecraft:red_terracotta
setblock 416 183 280 minecraft:red_terracotta
setblock 416 183 281 minecraft:stripped_oak_log
fill 416 183 282 416 186 282 minecraft:red_terracotta
fill 416 183 284 416 183 285 minecraft:red_terracotta
setblock 416 183 296 minecraft:stripped_oak_log
fill 416 183 297 416 184 297 minecraft:red_terracotta
setblock 416 183 301 minecraft:stripped_oak_log
fill 416 183 302 416 186 302 minecraft:red_terracotta
setblock 416 183 306 minecraft:stripped_oak_log
fill 416 183 307 416 186 307 minecraft:red_terracotta
setblock 417 183 280 minecraft:stripped_oak_log
fill 417 183 281 417 186 281 minecraft:red_terracotta
setblock 417 183 285 minecraft:stripped_oak_log
fill 417 183 286 417 183 289 minecraft:red_terracotta
setblock 417 183 290 minecraft:stripped_oak_log
fill 417 183 291 417 186 291 minecraft:red_terracotta
setblock 417 183 295 minecraft:stripped_oak_log
fill 417 183 296 417 186 296 minecraft:red_terracotta
setblock 417 183 300 minecraft:stripped_oak_log
fill 417 183 301 417 186 301 minecraft:red_terracotta
setblock 417 183 305 minecraft:stripped_oak_log
fill 417 183 306 417 186 306 minecraft:red_terracotta
fill 376 184 275 376 187 317 minecraft:terracotta
fill 377 184 275 418 187 275 minecraft:terracotta
fill 377 184 276 377 184 278 minecraft:red_terracotta
setblock 377 184 279 minecraft:stripped_oak_log
fill 377 184 280 377 187 280 minecraft:red_terracotta
setblock 377 184 283 minecraft:red_terracotta
setblock 377 184 284 minecraft:stripped_oak_log
fill 377 184 285 377 184 288 minecraft:red_terracotta
setblock 377 184 289 minecraft:stripped_oak_log
fill 377 184 290 377 187 290 minecraft:red_terracotta
setblock 377 184 299 minecraft:stripped_oak_log
fill 377 184 300 377 185 300 minecraft:red_terracotta
setblock 377 184 304 minecraft:stripped_oak_log
fill 377 184 305 377 186 305 minecraft:red_terracotta
fill 377 184 317 418 187 317 minecraft:terracotta
setblock 378 184 278 minecraft:stripped_oak_log
fill 378 184 279 378 186 279 minecraft:red_terracotta
setblock 378 184 283 minecraft:stripped_oak_log
fill 378 184 284 379 186 284 minecraft:red_terracotta
setblock 379 184 278 minecraft:light[level=15]
setblock 379 184 281 minecraft:red_terracotta
setblock 379 184 282 minecraft:stripped_oak_log
fill 379 184 283 379 187 283 minecraft:red_terracotta
setblock 379 184 286 minecraft:light[level=15]
setblock 379 184 294 minecraft:light[level=15]
setblock 379 184 302 minecraft:light[level=15]
setblock 379 184 310 minecraft:light[level=15]
setblock 380 184 276 minecraft:stripped_oak_log
fill 381 184 276 381 187 276 minecraft:red_terracotta
fill 381 184 279 383 218 280 minecraft:stripped_oak_log
setblock 382 184 278 minecraft:red_terracotta
setblock 383 184 278 minecraft:stripped_oak_log
setblock 384 184 277 minecraft:stripped_oak_log
fill 384 184 278 384 185 279 minecraft:red_terracotta
fill 384 184 280 384 218 280 minecraft:stripped_oak_log
setblock 384 184 316 minecraft:red_terracotta
setblock 385 184 276 minecraft:stripped_oak_log
fill 385 184 277 385 187 277 minecraft:red_terracotta
setblock 385 184 316 minecraft:stripped_oak_log
fill 386 184 276 386 187 276 minecraft:red_terracotta
setblock 386 184 279 minecraft:red_terracotta
fill 386 184 316 386 187 316 minecraft:red_terracotta
setblock 387 184 279 minecraft:stripped_oak_log
schedule function dropper:buildpart/68_5 1t
