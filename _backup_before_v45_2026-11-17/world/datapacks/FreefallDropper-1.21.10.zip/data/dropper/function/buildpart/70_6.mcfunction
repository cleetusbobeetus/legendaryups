fill 482 135 315 483 135 315 minecraft:deepslate_tiles
setblock 483 135 276 minecraft:cobbled_deepslate
setblock 483 135 316 minecraft:cobbled_deepslate
fill 484 135 276 484 138 276 minecraft:deepslate_tiles
setblock 484 135 314 minecraft:deepslate_tiles
setblock 484 135 315 minecraft:cobbled_deepslate
fill 484 135 316 484 138 316 minecraft:deepslate_tiles
setblock 485 135 314 minecraft:cobbled_deepslate
fill 485 135 315 485 138 315 minecraft:deepslate_tiles
setblock 486 135 313 minecraft:cobbled_deepslate
fill 486 135 314 489 135 314 minecraft:deepslate_tiles
setblock 487 135 277 minecraft:cobbled_deepslate
fill 487 135 313 490 135 313 minecraft:deepslate_tiles
setblock 488 135 276 minecraft:cobbled_deepslate
fill 488 135 277 488 137 277 minecraft:deepslate_tiles
setblock 488 135 316 minecraft:cobbled_deepslate
fill 489 135 276 489 138 276 minecraft:deepslate_tiles
fill 489 135 312 491 135 312 minecraft:deepslate_tiles
setblock 489 135 315 minecraft:cobbled_deepslate
fill 489 135 316 489 138 316 minecraft:deepslate_tiles
setblock 490 135 314 minecraft:cobbled_deepslate
fill 490 135 315 490 138 315 minecraft:deepslate_tiles
setblock 491 135 313 minecraft:cobbled_deepslate
fill 491 135 314 491 138 314 minecraft:deepslate_tiles
setblock 492 135 312 minecraft:cobbled_deepslate
fill 492 135 313 492 138 313 minecraft:deepslate_tiles
setblock 493 135 276 minecraft:cobbled_deepslate
setblock 493 135 316 minecraft:cobbled_deepslate
setblock 494 135 276 minecraft:deepslate_tiles
setblock 494 135 315 minecraft:cobbled_deepslate
fill 494 135 316 494 138 316 minecraft:deepslate_tiles
setblock 495 135 314 minecraft:cobbled_deepslate
fill 495 135 315 495 138 315 minecraft:deepslate_tiles
setblock 496 135 314 minecraft:deepslate_tiles
setblock 498 135 316 minecraft:cobbled_deepslate
fill 499 135 316 499 136 316 minecraft:deepslate_tiles
fill 501 135 275 502 142 275 minecraft:black_concrete
setblock 503 135 275 minecraft:redstone_block
fill 504 135 275 504 202 275 minecraft:black_concrete
fill 505 135 316 507 135 316 minecraft:deepslate_tiles
setblock 508 135 276 minecraft:cobbled_deepslate
setblock 508 135 286 minecraft:cobbled_deepslate
fill 508 135 287 508 135 290 minecraft:deepslate_tiles
setblock 508 135 291 minecraft:cobbled_deepslate
fill 508 135 292 509 136 293 minecraft:deepslate_tiles
setblock 508 135 315 minecraft:deepslate_tiles
setblock 508 135 316 minecraft:cobbled_deepslate
fill 509 135 276 509 138 276 minecraft:deepslate_tiles
fill 509 135 283 509 135 284 minecraft:deepslate_tiles
setblock 509 135 285 minecraft:cobbled_deepslate
fill 509 135 286 509 138 286 minecraft:deepslate_tiles
setblock 509 135 290 minecraft:cobbled_deepslate
fill 509 135 291 509 138 291 minecraft:deepslate_tiles
setblock 509 135 294 minecraft:deepslate_tiles
setblock 509 135 295 minecraft:cobbled_deepslate
fill 509 135 296 509 138 296 minecraft:deepslate_tiles
fill 509 135 298 509 136 298 minecraft:deepslate_tiles
setblock 509 135 305 minecraft:cobbled_deepslate
fill 509 135 306 509 136 306 minecraft:deepslate_tiles
setblock 509 135 309 minecraft:deepslate_tiles
setblock 509 135 310 minecraft:cobbled_deepslate
fill 509 135 311 509 137 311 minecraft:deepslate_tiles
fill 509 135 313 509 136 313 minecraft:deepslate_tiles
setblock 509 135 315 minecraft:cobbled_deepslate
fill 509 135 316 509 138 316 minecraft:deepslate_tiles
fill 510 135 280 510 135 283 minecraft:deepslate_tiles
setblock 510 135 284 minecraft:cobbled_deepslate
fill 510 135 285 510 138 285 minecraft:deepslate_tiles
setblock 510 135 289 minecraft:cobbled_deepslate
fill 510 135 290 510 138 290 minecraft:deepslate_tiles
setblock 510 135 293 minecraft:deepslate_tiles
setblock 510 135 294 minecraft:cobbled_deepslate
fill 510 135 295 510 138 295 minecraft:deepslate_tiles
setblock 510 135 299 minecraft:cobbled_deepslate
fill 510 135 300 510 138 300 minecraft:deepslate_tiles
setblock 510 135 304 minecraft:cobbled_deepslate
fill 510 135 305 510 137 305 minecraft:deepslate_tiles
setblock 510 135 309 minecraft:cobbled_deepslate
fill 510 135 310 510 138 310 minecraft:deepslate_tiles
setblock 510 135 314 minecraft:cobbled_deepslate
fill 510 135 315 510 138 315 minecraft:deepslate_tiles
setblock 511 135 278 minecraft:cobbled_deepslate
fill 511 135 279 511 138 279 minecraft:deepslate_tiles
setblock 511 135 283 minecraft:cobbled_deepslate
fill 511 135 284 511 138 284 minecraft:deepslate_tiles
setblock 511 135 288 minecraft:cobbled_deepslate
fill 511 135 289 511 138 289 minecraft:deepslate_tiles
setblock 511 135 293 minecraft:cobbled_deepslate
fill 511 135 294 511 138 294 minecraft:deepslate_tiles
setblock 511 135 298 minecraft:cobbled_deepslate
fill 511 135 299 511 138 299 minecraft:deepslate_tiles
setblock 511 135 303 minecraft:cobbled_deepslate
fill 511 135 304 511 138 304 minecraft:deepslate_tiles
setblock 511 135 308 minecraft:cobbled_deepslate
fill 511 135 309 511 138 309 minecraft:deepslate_tiles
setblock 511 135 313 minecraft:cobbled_deepslate
fill 511 135 314 511 138 314 minecraft:deepslate_tiles
setblock 471 136 277 minecraft:cobbled_deepslate
fill 471 136 278 471 139 278 minecraft:deepslate_tiles
setblock 471 136 282 minecraft:cobbled_deepslate
fill 471 136 283 471 139 283 minecraft:deepslate_tiles
setblock 471 136 287 minecraft:cobbled_deepslate
fill 471 136 288 471 139 288 minecraft:deepslate_tiles
setblock 471 136 292 minecraft:cobbled_deepslate
fill 471 136 293 471 139 293 minecraft:deepslate_tiles
setblock 471 136 297 minecraft:cobbled_deepslate
fill 471 136 298 471 139 298 minecraft:deepslate_tiles
setblock 471 136 302 minecraft:cobbled_deepslate
setblock 471 136 303 minecraft:deepslate_tiles
setblock 471 136 307 minecraft:cobbled_deepslate
fill 471 136 308 471 139 308 minecraft:deepslate_tiles
setblock 471 136 312 minecraft:cobbled_deepslate
fill 471 136 313 471 139 313 minecraft:deepslate_tiles
setblock 472 136 276 minecraft:cobbled_deepslate
fill 472 136 277 472 139 277 minecraft:deepslate_tiles
setblock 472 136 281 minecraft:cobbled_deepslate
fill 472 136 282 472 138 282 minecraft:deepslate_tiles
setblock 472 136 286 minecraft:cobbled_deepslate
fill 472 136 287 472 139 287 minecraft:deepslate_tiles
setblock 472 136 291 minecraft:cobbled_deepslate
fill 472 136 292 472 139 292 minecraft:deepslate_tiles
setblock 472 136 296 minecraft:cobbled_deepslate
setblock 472 136 307 minecraft:deepslate_tiles
fill 472 136 309 472 137 309 minecraft:deepslate_tiles
setblock 472 136 311 minecraft:cobbled_deepslate
fill 472 136 312 472 139 312 minecraft:deepslate_tiles
setblock 472 136 315 minecraft:deepslate_tiles
setblock 472 136 316 minecraft:cobbled_deepslate
fill 473 136 276 473 139 276 minecraft:deepslate_tiles
setblock 473 136 285 minecraft:cobbled_deepslate
fill 473 136 286 473 137 286 minecraft:deepslate_tiles
setblock 473 136 290 minecraft:cobbled_deepslate
fill 473 136 291 473 138 291 minecraft:deepslate_tiles
setblock 473 136 315 minecraft:cobbled_deepslate
fill 473 136 316 473 139 316 minecraft:deepslate_tiles
fill 474 136 315 474 139 315 minecraft:deepslate_tiles
fill 476 136 315 476 136 316 minecraft:deepslate_tiles
setblock 477 136 276 minecraft:cobbled_deepslate
setblock 477 136 316 minecraft:cobbled_deepslate
fill 478 136 276 481 136 276 minecraft:deepslate_tiles
fill 478 136 316 481 136 316 minecraft:deepslate_tiles
fill 479 136 291 480 136 291 minecraft:white_wool
fill 481 136 315 482 136 315 minecraft:deepslate_tiles
setblock 482 136 276 minecraft:cobbled_deepslate
setblock 482 136 316 minecraft:cobbled_deepslate
fill 483 136 276 483 139 276 minecraft:deepslate_tiles
setblock 483 136 315 minecraft:cobbled_deepslate
fill 483 136 316 483 139 316 minecraft:deepslate_tiles
setblock 484 136 314 minecraft:cobbled_deepslate
fill 484 136 315 484 139 315 minecraft:deepslate_tiles
fill 485 136 314 488 136 314 minecraft:deepslate_tiles
fill 486 136 313 489 136 313 minecraft:deepslate_tiles
setblock 487 136 276 minecraft:cobbled_deepslate
fill 487 136 277 487 137 277 minecraft:deepslate_tiles
setblock 487 136 316 minecraft:cobbled_deepslate
fill 488 136 276 488 139 276 minecraft:deepslate_tiles
fill 488 136 312 490 136 312 minecraft:deepslate_tiles
setblock 488 136 315 minecraft:cobbled_deepslate
fill 488 136 316 488 139 316 minecraft:deepslate_tiles
setblock 489 136 314 minecraft:cobbled_deepslate
fill 489 136 315 489 139 315 minecraft:deepslate_tiles
setblock 490 136 277 minecraft:deepslate_tiles
setblock 490 136 313 minecraft:cobbled_deepslate
fill 490 136 314 490 139 314 minecraft:deepslate_tiles
setblock 491 136 312 minecraft:cobbled_deepslate
fill 491 136 313 491 139 313 minecraft:deepslate_tiles
setblock 492 136 276 minecraft:cobbled_deepslate
setblock 492 136 312 minecraft:deepslate_tiles
setblock 492 136 316 minecraft:cobbled_deepslate
fill 493 136 276 493 137 276 minecraft:deepslate_tiles
setblock 493 136 315 minecraft:cobbled_deepslate
fill 493 136 316 493 139 316 minecraft:deepslate_tiles
setblock 494 136 314 minecraft:cobbled_deepslate
fill 494 136 315 494 139 315 minecraft:deepslate_tiles
fill 495 136 314 495 137 314 minecraft:deepslate_tiles
setblock 497 136 316 minecraft:cobbled_deepslate
fill 498 136 316 498 138 316 minecraft:deepslate_tiles
fill 503 136 275 503 159 275 minecraft:black_concrete
fill 504 136 316 506 136 316 minecraft:deepslate_tiles
setblock 507 136 315 minecraft:deepslate_tiles
setblock 507 136 316 minecraft:cobbled_deepslate
fill 508 136 276 508 139 276 minecraft:deepslate_tiles
fill 508 136 286 508 136 289 minecraft:deepslate_tiles
setblock 508 136 290 minecraft:cobbled_deepslate
fill 508 136 291 508 139 291 minecraft:deepslate_tiles
setblock 508 136 294 minecraft:deepslate_tiles
fill 508 136 298 508 138 298 minecraft:black_concrete
setblock 508 136 315 minecraft:cobbled_deepslate
fill 508 136 316 508 139 316 minecraft:deepslate_tiles
setblock 509 136 283 minecraft:deepslate_tiles
setblock 509 136 284 minecraft:cobbled_deepslate
fill 509 136 285 509 138 285 minecraft:deepslate_tiles
setblock 509 136 289 minecraft:cobbled_deepslate
fill 509 136 290 509 139 290 minecraft:deepslate_tiles
setblock 509 136 294 minecraft:cobbled_deepslate
fill 509 136 295 509 139 295 minecraft:deepslate_tiles
fill 509 136 299 509 138 299 minecraft:black_concrete
setblock 509 136 305 minecraft:deepslate_tiles
setblock 509 136 309 minecraft:cobbled_deepslate
fill 509 136 310 509 137 310 minecraft:deepslate_tiles
fill 509 136 315 509 139 315 minecraft:deepslate_tiles
fill 510 136 280 510 136 282 minecraft:deepslate_tiles
setblock 510 136 283 minecraft:cobbled_deepslate
fill 510 136 284 510 139 284 minecraft:deepslate_tiles
setblock 510 136 288 minecraft:cobbled_deepslate
fill 510 136 289 510 139 289 minecraft:deepslate_tiles
setblock 510 136 293 minecraft:cobbled_deepslate
fill 510 136 294 510 139 294 minecraft:deepslate_tiles
setblock 510 136 298 minecraft:cobbled_deepslate
fill 510 136 299 510 139 299 minecraft:deepslate_tiles
setblock 510 136 303 minecraft:cobbled_deepslate
fill 510 136 304 510 137 304 minecraft:deepslate_tiles
setblock 510 136 308 minecraft:cobbled_deepslate
fill 510 136 309 510 139 309 minecraft:deepslate_tiles
setblock 510 136 313 minecraft:cobbled_deepslate
fill 510 136 314 510 139 314 minecraft:deepslate_tiles
setblock 511 136 277 minecraft:cobbled_deepslate
fill 511 136 278 511 139 278 minecraft:deepslate_tiles
setblock 511 136 282 minecraft:cobbled_deepslate
fill 511 136 283 511 139 283 minecraft:deepslate_tiles
setblock 511 136 287 minecraft:cobbled_deepslate
fill 511 136 288 511 139 288 minecraft:deepslate_tiles
setblock 511 136 292 minecraft:cobbled_deepslate
fill 511 136 293 511 139 293 minecraft:deepslate_tiles
setblock 511 136 297 minecraft:cobbled_deepslate
fill 511 136 298 511 139 298 minecraft:deepslate_tiles
setblock 511 136 302 minecraft:cobbled_deepslate
fill 511 136 303 511 138 303 minecraft:deepslate_tiles
setblock 511 136 307 minecraft:cobbled_deepslate
fill 511 136 308 511 139 308 minecraft:deepslate_tiles
setblock 511 136 312 minecraft:cobbled_deepslate
fill 511 136 313 511 139 313 minecraft:deepslate_tiles
setblock 471 137 276 minecraft:cobbled_deepslate
fill 471 137 277 471 139 277 minecraft:deepslate_tiles
setblock 471 137 281 minecraft:cobbled_deepslate
fill 471 137 282 471 139 282 minecraft:deepslate_tiles
setblock 471 137 286 minecraft:cobbled_deepslate
fill 471 137 287 471 139 287 minecraft:deepslate_tiles
setblock 471 137 291 minecraft:cobbled_deepslate
fill 471 137 292 471 139 292 minecraft:deepslate_tiles
setblock 471 137 296 minecraft:cobbled_deepslate
fill 471 137 297 471 139 297 minecraft:deepslate_tiles
setblock 471 137 306 minecraft:cobbled_deepslate
fill 471 137 307 471 138 307 minecraft:deepslate_tiles
setblock 471 137 311 minecraft:cobbled_deepslate
fill 471 137 312 471 139 312 minecraft:deepslate_tiles
setblock 471 137 316 minecraft:cobbled_deepslate
fill 472 137 276 472 139 276 minecraft:deepslate_tiles
setblock 472 137 280 minecraft:cobbled_deepslate
fill 472 137 281 472 138 281 minecraft:deepslate_tiles
setblock 472 137 285 minecraft:cobbled_deepslate
fill 472 137 286 472 139 286 minecraft:deepslate_tiles
setblock 472 137 290 minecraft:cobbled_deepslate
fill 472 137 291 472 139 291 minecraft:deepslate_tiles
setblock 472 137 295 minecraft:cobbled_deepslate
setblock 472 137 310 minecraft:cobbled_deepslate
fill 472 137 311 472 138 311 minecraft:deepslate_tiles
setblock 472 137 315 minecraft:cobbled_deepslate
fill 472 137 316 472 139 316 minecraft:deepslate_tiles
setblock 473 137 284 minecraft:cobbled_deepslate
setblock 473 137 285 minecraft:deepslate_tiles
setblock 473 137 289 minecraft:cobbled_deepslate
fill 473 137 290 473 138 290 minecraft:deepslate_tiles
fill 473 137 315 473 139 315 minecraft:deepslate_tiles
setblock 476 137 276 minecraft:cobbled_deepslate
setblock 476 137 316 minecraft:cobbled_deepslate
fill 477 137 276 480 137 276 minecraft:deepslate_tiles
fill 477 137 316 480 137 316 minecraft:deepslate_tiles
setblock 480 137 291 minecraft:white_wool
fill 480 137 315 481 137 315 minecraft:deepslate_tiles
setblock 481 137 276 minecraft:cobbled_deepslate
setblock 481 137 316 minecraft:cobbled_deepslate
fill 482 137 276 482 139 276 minecraft:deepslate_tiles
setblock 482 137 315 minecraft:cobbled_deepslate
fill 482 137 316 482 139 316 minecraft:deepslate_tiles
setblock 483 137 314 minecraft:cobbled_deepslate
fill 483 137 315 483 139 315 minecraft:deepslate_tiles
fill 484 137 314 487 137 314 minecraft:deepslate_tiles
fill 485 137 313 488 137 313 minecraft:deepslate_tiles
setblock 486 137 276 minecraft:cobbled_deepslate
setblock 486 137 316 minecraft:cobbled_deepslate
fill 487 137 276 487 139 276 minecraft:deepslate_tiles
setblock 487 137 315 minecraft:cobbled_deepslate
fill 487 137 316 487 139 316 minecraft:deepslate_tiles
fill 488 137 312 489 137 312 minecraft:deepslate_tiles
setblock 488 137 314 minecraft:cobbled_deepslate
fill 488 137 315 488 139 315 minecraft:deepslate_tiles
setblock 489 137 313 minecraft:cobbled_deepslate
fill 489 137 314 489 139 314 minecraft:deepslate_tiles
setblock 490 137 312 minecraft:cobbled_deepslate
fill 490 137 313 490 139 313 minecraft:deepslate_tiles
setblock 491 137 276 minecraft:cobbled_deepslate
setblock 491 137 316 minecraft:cobbled_deepslate
fill 492 137 276 492 139 276 minecraft:deepslate_tiles
setblock 492 137 315 minecraft:cobbled_deepslate
fill 492 137 316 492 139 316 minecraft:deepslate_tiles
setblock 493 137 275 minecraft:white_wool
setblock 493 137 314 minecraft:cobbled_deepslate
fill 493 137 315 493 139 315 minecraft:deepslate_tiles
fill 494 137 314 494 138 314 minecraft:deepslate_tiles
setblock 496 137 316 minecraft:cobbled_deepslate
fill 497 137 316 497 139 316 minecraft:deepslate_tiles
fill 503 137 316 505 137 316 minecraft:deepslate_tiles
setblock 506 137 315 minecraft:deepslate_tiles
setblock 506 137 316 minecraft:cobbled_deepslate
fill 507 137 276 507 139 276 minecraft:deepslate_tiles
setblock 507 137 315 minecraft:cobbled_deepslate
fill 507 137 316 507 139 316 minecraft:deepslate_tiles
fill 508 137 287 508 137 288 minecraft:deepslate_tiles
setblock 508 137 289 minecraft:cobbled_deepslate
fill 508 137 290 508 139 290 minecraft:deepslate_tiles
fill 508 137 292 508 137 293 minecraft:deepslate_tiles
setblock 508 137 294 minecraft:cobbled_deepslate
fill 508 137 295 508 139 295 minecraft:deepslate_tiles
fill 508 137 297 508 138 297 minecraft:black_concrete
fill 508 137 299 508 138 299 minecraft:black_concrete
fill 508 137 315 508 139 315 minecraft:deepslate_tiles
setblock 509 137 284 minecraft:deepslate_tiles
setblock 509 137 288 minecraft:cobbled_deepslate
fill 509 137 289 509 139 289 minecraft:deepslate_tiles
setblock 509 137 292 minecraft:deepslate_tiles
setblock 509 137 293 minecraft:cobbled_deepslate
fill 509 137 294 509 139 294 minecraft:deepslate_tiles
setblock 509 137 298 minecraft:cobbled_deepslate
setblock 509 137 308 minecraft:cobbled_deepslate
setblock 509 137 309 minecraft:deepslate_tiles
setblock 509 137 313 minecraft:cobbled_deepslate
setblock 510 137 281 minecraft:deepslate_tiles
setblock 510 137 282 minecraft:cobbled_deepslate
fill 510 137 283 510 139 283 minecraft:deepslate_tiles
setblock 510 137 287 minecraft:cobbled_deepslate
fill 510 137 288 510 139 288 minecraft:deepslate_tiles
setblock 510 137 292 minecraft:cobbled_deepslate
fill 510 137 293 510 139 293 minecraft:deepslate_tiles
setblock 510 137 297 minecraft:cobbled_deepslate
fill 510 137 298 510 139 298 minecraft:deepslate_tiles
setblock 510 137 302 minecraft:cobbled_deepslate
setblock 510 137 303 minecraft:deepslate_tiles
setblock 510 137 307 minecraft:cobbled_deepslate
fill 510 137 308 510 138 308 minecraft:deepslate_tiles
setblock 510 137 312 minecraft:cobbled_deepslate
fill 510 137 313 510 139 313 minecraft:deepslate_tiles
setblock 511 137 276 minecraft:cobbled_deepslate
fill 511 137 277 511 139 277 minecraft:deepslate_tiles
setblock 511 137 281 minecraft:cobbled_deepslate
fill 511 137 282 511 139 282 minecraft:deepslate_tiles
setblock 511 137 286 minecraft:cobbled_deepslate
fill 511 137 287 511 139 287 minecraft:deepslate_tiles
setblock 511 137 291 minecraft:cobbled_deepslate
fill 511 137 292 511 139 292 minecraft:deepslate_tiles
setblock 511 137 296 minecraft:cobbled_deepslate
fill 511 137 297 511 139 297 minecraft:deepslate_tiles
setblock 511 137 301 minecraft:cobbled_deepslate
fill 511 137 302 511 139 302 minecraft:deepslate_tiles
setblock 511 137 306 minecraft:cobbled_deepslate
fill 511 137 307 511 139 307 minecraft:deepslate_tiles
setblock 511 137 311 minecraft:cobbled_deepslate
fill 511 137 312 511 139 312 minecraft:deepslate_tiles
setblock 511 137 316 minecraft:cobbled_deepslate
setblock 470 138 284 minecraft:redstone_block
fill 470 138 285 470 179 289 minecraft:black_concrete
fill 471 138 276 471 139 276 minecraft:deepslate_tiles
setblock 471 138 280 minecraft:cobbled_deepslate
fill 471 138 281 471 139 281 minecraft:deepslate_tiles
setblock 471 138 285 minecraft:cobbled_deepslate
fill 471 138 286 471 139 286 minecraft:deepslate_tiles
setblock 471 138 290 minecraft:cobbled_deepslate
fill 471 138 291 471 139 291 minecraft:deepslate_tiles
setblock 471 138 295 minecraft:cobbled_deepslate
fill 471 138 296 471 139 296 minecraft:deepslate_tiles
setblock 471 138 306 minecraft:deepslate_tiles
setblock 471 138 310 minecraft:cobbled_deepslate
fill 471 138 311 471 139 311 minecraft:deepslate_tiles
setblock 471 138 315 minecraft:cobbled_deepslate
fill 471 138 316 471 139 316 minecraft:deepslate_tiles
setblock 472 138 279 minecraft:cobbled_deepslate
setblock 472 138 280 minecraft:deepslate_tiles
setblock 472 138 284 minecraft:cobbled_deepslate
fill 472 138 285 472 139 285 minecraft:deepslate_tiles
setblock 472 138 289 minecraft:cobbled_deepslate
fill 472 138 290 472 139 290 minecraft:deepslate_tiles
setblock 472 138 294 minecraft:cobbled_deepslate
setblock 472 138 295 minecraft:deepslate_tiles
setblock 472 138 310 minecraft:deepslate_tiles
setblock 472 138 314 minecraft:cobbled_deepslate
fill 472 138 315 472 139 315 minecraft:deepslate_tiles
setblock 473 138 288 minecraft:cobbled_deepslate
setblock 473 138 289 minecraft:deepslate_tiles
fill 474 138 291 475 139 292 minecraft:white_wool
setblock 475 138 276 minecraft:cobbled_deepslate
setblock 475 138 316 minecraft:cobbled_deepslate
fill 476 138 276 479 138 276 minecraft:deepslate_tiles
fill 476 138 316 479 138 316 minecraft:deepslate_tiles
setblock 480 138 276 minecraft:cobbled_deepslate
setblock 480 138 315 minecraft:deepslate_tiles
setblock 480 138 316 minecraft:cobbled_deepslate
fill 481 138 276 481 139 276 minecraft:deepslate_tiles
setblock 481 138 315 minecraft:cobbled_deepslate
fill 481 138 316 481 139 316 minecraft:deepslate_tiles
fill 482 138 315 482 139 315 minecraft:deepslate_tiles
fill 483 138 314 486 138 314 minecraft:deepslate_tiles
fill 483 138 317 485 201 317 minecraft:black_concrete
setblock 485 138 276 minecraft:cobbled_deepslate
fill 485 138 313 487 138 313 minecraft:deepslate_tiles
setblock 485 138 316 minecraft:cobbled_deepslate
fill 486 138 276 486 139 276 minecraft:deepslate_tiles
setblock 486 138 315 minecraft:cobbled_deepslate
fill 486 138 316 486 139 316 minecraft:deepslate_tiles
setblock 486 138 317 minecraft:white_wool
setblock 487 138 314 minecraft:cobbled_deepslate
fill 487 138 315 487 139 315 minecraft:deepslate_tiles
setblock 488 138 313 minecraft:cobbled_deepslate
fill 488 138 314 488 139 314 minecraft:deepslate_tiles
setblock 488 138 317 minecraft:white_wool
fill 489 138 313 489 139 313 minecraft:deepslate_tiles
fill 489 138 317 489 201 317 minecraft:black_concrete
setblock 490 138 276 minecraft:cobbled_deepslate
setblock 490 138 316 minecraft:cobbled_deepslate
fill 491 138 276 491 139 276 minecraft:deepslate_tiles
setblock 491 138 315 minecraft:cobbled_deepslate
fill 491 138 316 491 139 316 minecraft:deepslate_tiles
setblock 492 138 314 minecraft:cobbled_deepslate
fill 492 138 315 492 139 315 minecraft:deepslate_tiles
fill 493 138 275 493 201 275 minecraft:black_concrete
fill 493 138 314 493 139 314 minecraft:deepslate_tiles
setblock 495 138 316 minecraft:cobbled_deepslate
setblock 496 138 315 minecraft:cobbled_deepslate
fill 496 138 316 496 139 316 minecraft:deepslate_tiles
fill 503 138 316 504 138 316 minecraft:deepslate_tiles
setblock 505 138 316 minecraft:cobbled_deepslate
setblock 506 138 315 minecraft:cobbled_deepslate
fill 506 138 316 506 139 316 minecraft:deepslate_tiles
fill 507 138 315 507 139 315 minecraft:deepslate_tiles
setblock 508 138 288 minecraft:cobbled_deepslate
fill 508 138 289 508 139 289 minecraft:deepslate_tiles
setblock 508 138 292 minecraft:deepslate_tiles
setblock 508 138 293 minecraft:cobbled_deepslate
fill 508 138 294 508 139 294 minecraft:deepslate_tiles
setblock 509 138 287 minecraft:cobbled_deepslate
fill 509 138 288 509 139 288 minecraft:deepslate_tiles
setblock 509 138 292 minecraft:cobbled_deepslate
fill 509 138 293 509 139 293 minecraft:deepslate_tiles
setblock 509 138 297 minecraft:cobbled_deepslate
setblock 509 138 298 minecraft:black_concrete
setblock 510 138 276 minecraft:cobbled_deepslate
setblock 510 138 282 minecraft:deepslate_tiles
setblock 510 138 286 minecraft:cobbled_deepslate
fill 510 138 287 510 139 287 minecraft:deepslate_tiles
setblock 510 138 291 minecraft:cobbled_deepslate
fill 510 138 292 510 139 292 minecraft:deepslate_tiles
setblock 510 138 296 minecraft:cobbled_deepslate
fill 510 138 297 510 139 297 minecraft:deepslate_tiles
setblock 510 138 306 minecraft:cobbled_deepslate
setblock 510 138 307 minecraft:deepslate_tiles
setblock 510 138 311 minecraft:cobbled_deepslate
fill 510 138 312 510 139 312 minecraft:deepslate_tiles
setblock 510 138 316 minecraft:cobbled_deepslate
fill 511 138 276 511 139 276 minecraft:deepslate_tiles
setblock 511 138 280 minecraft:cobbled_deepslate
fill 511 138 281 511 139 281 minecraft:deepslate_tiles
setblock 511 138 285 minecraft:cobbled_deepslate
fill 511 138 286 511 139 286 minecraft:deepslate_tiles
setblock 511 138 290 minecraft:cobbled_deepslate
fill 511 138 291 511 139 291 minecraft:deepslate_tiles
setblock 511 138 295 minecraft:cobbled_deepslate
fill 511 138 296 511 139 296 minecraft:deepslate_tiles
setblock 511 138 300 minecraft:cobbled_deepslate
fill 511 138 301 511 139 301 minecraft:deepslate_tiles
setblock 511 138 305 minecraft:cobbled_deepslate
fill 511 138 306 511 139 306 minecraft:deepslate_tiles
setblock 511 138 310 minecraft:cobbled_deepslate
fill 511 138 311 511 139 311 minecraft:deepslate_tiles
setblock 511 138 315 minecraft:cobbled_deepslate
fill 511 138 316 511 139 316 minecraft:deepslate_tiles
fill 470 139 284 470 197 284 minecraft:black_concrete
setblock 471 139 279 minecraft:cobbled_deepslate
setblock 471 139 280 minecraft:deepslate_tiles
setblock 471 139 284 minecraft:cobbled_deepslate
setblock 471 139 285 minecraft:deepslate_tiles
setblock 471 139 289 minecraft:cobbled_deepslate
setblock 471 139 290 minecraft:deepslate_tiles
setblock 471 139 294 minecraft:cobbled_deepslate
setblock 471 139 295 minecraft:deepslate_tiles
setblock 471 139 309 minecraft:cobbled_deepslate
setblock 471 139 310 minecraft:deepslate_tiles
setblock 471 139 314 minecraft:cobbled_deepslate
setblock 471 139 315 minecraft:deepslate_tiles
setblock 472 139 284 minecraft:deepslate_tiles
setblock 472 139 288 minecraft:cobbled_deepslate
setblock 472 139 289 minecraft:deepslate_tiles
setblock 472 139 293 minecraft:cobbled_deepslate
setblock 472 139 294 minecraft:deepslate_tiles
setblock 472 139 313 minecraft:cobbled_deepslate
setblock 472 139 314 minecraft:deepslate_tiles
setblock 473 139 278 minecraft:light[level=12]
setblock 473 139 285 minecraft:light[level=12]
setblock 473 139 292 minecraft:light[level=12]
setblock 473 139 299 minecraft:light[level=12]
setblock 473 139 306 minecraft:light[level=12]
setblock 473 139 313 minecraft:light[level=12]
setblock 474 139 276 minecraft:cobbled_deepslate
setblock 474 139 316 minecraft:cobbled_deepslate
fill 475 139 276 478 139 276 minecraft:deepslate_tiles
fill 475 139 316 478 139 316 minecraft:deepslate_tiles
setblock 479 139 276 minecraft:cobbled_deepslate
setblock 479 139 316 minecraft:cobbled_deepslate
setblock 480 139 276 minecraft:deepslate_tiles
setblock 480 139 278 minecraft:light[level=12]
setblock 480 139 285 minecraft:light[level=12]
setblock 480 139 292 minecraft:light[level=12]
setblock 480 139 299 minecraft:light[level=12]
setblock 480 139 306 minecraft:light[level=12]
setblock 480 139 313 minecraft:light[level=12]
setblock 480 139 315 minecraft:cobbled_deepslate
setblock 480 139 316 minecraft:deepslate_tiles
setblock 481 139 315 minecraft:deepslate_tiles
fill 482 139 314 485 139 314 minecraft:deepslate_tiles
setblock 484 139 276 minecraft:cobbled_deepslate
setblock 484 139 316 minecraft:cobbled_deepslate
setblock 485 139 276 minecraft:deepslate_tiles
fill 485 139 313 486 139 313 minecraft:deepslate_tiles
setblock 485 139 315 minecraft:cobbled_deepslate
setblock 485 139 316 minecraft:deepslate_tiles
setblock 486 139 314 minecraft:cobbled_deepslate
setblock 486 139 315 minecraft:deepslate_tiles
fill 486 139 317 486 201 317 minecraft:black_concrete
setblock 487 139 278 minecraft:light[level=12]
setblock 487 139 285 minecraft:light[level=12]
setblock 487 139 292 minecraft:light[level=12]
setblock 487 139 299 minecraft:light[level=12]
setblock 487 139 306 minecraft:light[level=12]
setblock 487 139 313 minecraft:cobbled_deepslate
setblock 487 139 314 minecraft:deepslate_tiles
setblock 488 139 313 minecraft:deepslate_tiles
fill 488 139 317 488 145 317 minecraft:black_concrete
setblock 489 139 276 minecraft:cobbled_deepslate
setblock 489 139 316 minecraft:cobbled_deepslate
setblock 490 139 276 minecraft:deepslate_tiles
setblock 490 139 315 minecraft:cobbled_deepslate
setblock 490 139 316 minecraft:deepslate_tiles
setblock 491 139 314 minecraft:cobbled_deepslate
setblock 491 139 315 minecraft:deepslate_tiles
setblock 492 139 314 minecraft:deepslate_tiles
fill 494 139 275 496 201 275 minecraft:black_concrete
setblock 494 139 278 minecraft:light[level=12]
setblock 494 139 285 minecraft:light[level=12]
setblock 494 139 292 minecraft:light[level=12]
setblock 494 139 299 minecraft:light[level=12]
setblock 494 139 306 minecraft:light[level=12]
setblock 494 139 313 minecraft:light[level=12]
setblock 494 139 316 minecraft:cobbled_deepslate
setblock 495 139 315 minecraft:cobbled_deepslate
setblock 495 139 316 minecraft:deepslate_tiles
setblock 497 139 275 minecraft:redstone_block
fill 498 139 275 500 198 275 minecraft:black_concrete
setblock 501 139 278 minecraft:light[level=12]
setblock 501 139 285 minecraft:light[level=12]
setblock 501 139 292 minecraft:light[level=12]
setblock 501 139 299 minecraft:light[level=12]
setblock 501 139 306 minecraft:light[level=12]
setblock 501 139 313 minecraft:light[level=12]
setblock 503 139 316 minecraft:deepslate_tiles
setblock 504 139 316 minecraft:cobbled_deepslate
setblock 505 139 316 minecraft:deepslate_tiles
setblock 506 139 276 minecraft:deepslate_tiles
setblock 506 139 315 minecraft:deepslate_tiles
setblock 508 139 278 minecraft:light[level=12]
setblock 508 139 285 minecraft:light[level=12]
setblock 508 139 288 minecraft:deepslate_tiles
setblock 508 139 292 minecraft:cobbled_deepslate
setblock 508 139 293 minecraft:deepslate_tiles
setblock 508 139 299 minecraft:light[level=12]
setblock 508 139 306 minecraft:light[level=12]
setblock 508 139 313 minecraft:light[level=12]
setblock 509 139 276 minecraft:cobbled_deepslate
setblock 509 139 286 minecraft:cobbled_deepslate
setblock 509 139 287 minecraft:deepslate_tiles
setblock 509 139 291 minecraft:cobbled_deepslate
setblock 509 139 292 minecraft:deepslate_tiles
setblock 509 139 296 minecraft:cobbled_deepslate
setblock 509 139 297 minecraft:deepslate_tiles
setblock 509 139 316 minecraft:cobbled_deepslate
setblock 510 139 276 minecraft:deepslate_tiles
setblock 510 139 285 minecraft:cobbled_deepslate
setblock 510 139 286 minecraft:deepslate_tiles
setblock 510 139 290 minecraft:cobbled_deepslate
setblock 510 139 291 minecraft:deepslate_tiles
setblock 510 139 295 minecraft:cobbled_deepslate
setblock 510 139 296 minecraft:deepslate_tiles
setblock 510 139 310 minecraft:cobbled_deepslate
setblock 510 139 311 minecraft:deepslate_tiles
setblock 510 139 315 minecraft:cobbled_deepslate
setblock 510 139 316 minecraft:deepslate_tiles
setblock 511 139 279 minecraft:cobbled_deepslate
setblock 511 139 280 minecraft:deepslate_tiles
setblock 511 139 284 minecraft:cobbled_deepslate
setblock 511 139 285 minecraft:deepslate_tiles
setblock 511 139 289 minecraft:cobbled_deepslate
setblock 511 139 290 minecraft:deepslate_tiles
setblock 511 139 294 minecraft:cobbled_deepslate
setblock 511 139 295 minecraft:deepslate_tiles
setblock 511 139 299 minecraft:cobbled_deepslate
setblock 511 139 300 minecraft:deepslate_tiles
setblock 511 139 309 minecraft:cobbled_deepslate
setblock 511 139 310 minecraft:deepslate_tiles
setblock 511 139 314 minecraft:cobbled_deepslate
setblock 511 139 315 minecraft:deepslate_tiles
fill 487 140 283 488 143 284 minecraft:white_terracotta
fill 497 140 275 497 201 275 minecraft:black_concrete
fill 470 141 314 470 153 314 minecraft:black_concrete
setblock 470 141 315 minecraft:redstone_block
fill 470 141 316 470 201 316 minecraft:black_concrete
setblock 473 141 278 minecraft:light[level=13]
setblock 473 141 286 minecraft:light[level=13]
setblock 473 141 294 minecraft:light[level=13]
setblock 473 141 302 minecraft:light[level=13]
setblock 473 141 310 minecraft:light[level=13]
setblock 481 141 278 minecraft:light[level=13]
setblock 481 141 286 minecraft:light[level=13]
setblock 481 141 294 minecraft:light[level=13]
setblock 481 141 302 minecraft:light[level=13]
setblock 481 141 310 minecraft:light[level=13]
setblock 489 141 278 minecraft:light[level=13]
setblock 489 141 286 minecraft:light[level=13]
setblock 489 141 302 minecraft:light[level=13]
setblock 489 141 310 minecraft:light[level=13]
fill 495 141 317 496 201 317 minecraft:black_concrete
setblock 497 141 278 minecraft:light[level=13]
setblock 497 141 286 minecraft:light[level=13]
setblock 497 141 294 minecraft:light[level=13]
setblock 497 141 302 minecraft:light[level=13]
setblock 497 141 310 minecraft:light[level=13]
setblock 497 141 317 minecraft:redstone_block
fill 500 141 302 501 144 302 minecraft:white_terracotta
fill 501 141 303 501 144 303 minecraft:white_terracotta
setblock 503 141 315 minecraft:white_wool
setblock 504 141 314 minecraft:white_wool
setblock 505 141 278 minecraft:light[level=13]
setblock 505 141 286 minecraft:light[level=13]
setblock 505 141 294 minecraft:light[level=13]
setblock 505 141 302 minecraft:light[level=13]
setblock 505 141 310 minecraft:light[level=13]
setblock 505 141 313 minecraft:white_wool
setblock 506 141 312 minecraft:white_wool
fill 470 142 315 470 199 315 minecraft:black_concrete
fill 497 142 317 497 186 317 minecraft:black_concrete
fill 500 142 303 500 143 303 minecraft:white_terracotta
fill 501 142 301 501 143 301 minecraft:white_terracotta
fill 502 142 302 502 143 302 minecraft:white_terracotta
setblock 507 142 311 minecraft:white_wool
setblock 508 142 310 minecraft:white_wool
setblock 509 142 309 minecraft:white_wool
setblock 510 142 308 minecraft:white_wool
setblock 482 143 275 minecraft:redstone_block
fill 501 143 275 501 199 275 minecraft:black_concrete
setblock 502 143 275 minecraft:white_wool
fill 482 144 275 482 198 275 minecraft:black_concrete
fill 502 144 275 502 201 275 minecraft:black_concrete
fill 471 145 276 471 146 276 minecraft:white_terracotta
fill 471 145 277 471 146 279 minecraft:white_wool
fill 471 145 280 471 146 280 minecraft:white_terracotta
fill 471 145 281 471 146 283 minecraft:white_wool
fill 471 145 284 471 146 284 minecraft:white_terracotta
fill 471 145 285 471 146 287 minecraft:white_wool
fill 471 145 288 471 146 288 minecraft:white_terracotta
fill 471 145 289 471 146 291 minecraft:white_wool
fill 471 145 292 471 146 292 minecraft:white_terracotta
fill 471 145 293 471 146 295 minecraft:white_wool
fill 471 145 296 471 146 296 minecraft:white_terracotta
fill 471 145 297 471 146 299 minecraft:white_wool
fill 471 145 300 471 146 300 minecraft:white_terracotta
fill 471 145 301 471 146 303 minecraft:white_wool
fill 471 145 304 471 146 304 minecraft:white_terracotta
fill 471 145 305 471 146 307 minecraft:white_wool
fill 471 145 308 471 146 308 minecraft:white_terracotta
fill 471 145 309 471 146 311 minecraft:white_wool
fill 471 145 312 471 146 312 minecraft:white_terracotta
fill 471 145 313 471 146 315 minecraft:white_wool
fill 471 145 316 471 146 316 minecraft:white_terracotta
fill 472 145 276 474 146 276 minecraft:white_wool
fill 472 145 277 472 146 277 minecraft:white_terracotta
fill 472 145 278 472 146 280 minecraft:white_wool
fill 472 145 281 472 146 281 minecraft:white_terracotta
fill 472 145 282 472 146 284 minecraft:white_wool
fill 472 145 285 472 146 285 minecraft:white_terracotta
fill 472 145 286 472 146 288 minecraft:white_wool
fill 472 145 289 472 146 289 minecraft:white_terracotta
fill 472 145 290 472 146 292 minecraft:white_wool
fill 472 145 293 472 146 293 minecraft:white_terracotta
fill 472 145 294 472 146 296 minecraft:white_wool
fill 472 145 297 472 146 297 minecraft:white_terracotta
fill 472 145 298 472 146 300 minecraft:white_wool
fill 472 145 301 472 146 301 minecraft:white_terracotta
fill 472 145 302 472 146 304 minecraft:white_wool
fill 472 145 305 472 146 305 minecraft:white_terracotta
fill 472 145 306 472 146 308 minecraft:white_wool
fill 472 145 309 472 146 309 minecraft:white_terracotta
fill 472 145 310 472 146 312 minecraft:white_wool
fill 472 145 313 472 146 313 minecraft:white_terracotta
fill 472 145 314 472 146 316 minecraft:white_wool
fill 473 145 277 475 146 277 minecraft:white_wool
fill 473 145 278 473 146 278 minecraft:white_terracotta
fill 473 145 279 473 146 281 minecraft:white_wool
fill 473 145 282 473 146 282 minecraft:white_terracotta
fill 473 145 283 473 146 285 minecraft:white_wool
fill 473 145 286 473 146 286 minecraft:white_terracotta
fill 473 145 287 473 146 289 minecraft:white_wool
fill 473 145 290 473 146 290 minecraft:white_terracotta
fill 473 145 291 473 146 293 minecraft:white_wool
fill 473 145 294 473 146 294 minecraft:white_terracotta
fill 473 145 295 473 146 297 minecraft:white_wool
fill 473 145 298 473 146 298 minecraft:white_terracotta
fill 473 145 299 473 146 301 minecraft:white_wool
fill 473 145 302 473 146 302 minecraft:white_terracotta
fill 473 145 303 473 146 305 minecraft:white_wool
fill 473 145 306 473 146 306 minecraft:white_terracotta
fill 473 145 307 473 146 309 minecraft:white_wool
fill 473 145 310 473 146 310 minecraft:white_terracotta
fill 473 145 311 473 146 313 minecraft:white_wool
fill 473 145 314 473 146 314 minecraft:white_terracotta
fill 473 145 315 473 146 316 minecraft:white_wool
fill 474 145 278 476 146 278 minecraft:white_wool
fill 474 145 279 474 146 279 minecraft:white_terracotta
fill 474 145 280 474 146 282 minecraft:white_wool
fill 474 145 283 474 146 283 minecraft:white_terracotta
fill 474 145 284 474 146 286 minecraft:white_wool
fill 474 145 287 474 146 287 minecraft:white_terracotta
fill 474 145 288 474 146 290 minecraft:white_wool
fill 474 145 291 474 146 291 minecraft:white_terracotta
fill 474 145 292 474 146 294 minecraft:white_wool
fill 474 145 295 474 146 295 minecraft:white_terracotta
fill 474 145 296 474 146 298 minecraft:white_wool
fill 474 145 299 474 146 299 minecraft:white_terracotta
fill 474 145 300 474 146 302 minecraft:white_wool
fill 474 145 303 474 146 303 minecraft:white_terracotta
fill 474 145 304 474 146 306 minecraft:white_wool
fill 474 145 307 474 146 307 minecraft:white_terracotta
fill 474 145 308 474 146 310 minecraft:white_wool
fill 474 145 311 474 148 311 minecraft:white_terracotta
fill 474 145 312 474 145 314 minecraft:white_wool
fill 474 145 315 474 146 315 minecraft:white_terracotta
fill 474 145 316 474 146 316 minecraft:white_wool
fill 475 145 276 475 146 276 minecraft:white_terracotta
fill 475 145 279 477 146 279 minecraft:white_wool
fill 475 145 280 475 146 280 minecraft:white_terracotta
fill 475 145 281 475 146 283 minecraft:white_wool
fill 475 145 284 475 146 284 minecraft:white_terracotta
fill 475 145 285 475 146 287 minecraft:white_wool
fill 475 145 288 475 146 288 minecraft:white_terracotta
fill 475 145 289 475 146 291 minecraft:white_wool
fill 475 145 292 475 146 292 minecraft:white_terracotta
fill 475 145 293 475 146 295 minecraft:white_wool
fill 475 145 296 475 146 296 minecraft:white_terracotta
fill 475 145 297 475 146 299 minecraft:white_wool
fill 475 145 300 475 146 300 minecraft:white_terracotta
fill 475 145 301 475 145 303 minecraft:white_wool
fill 475 145 304 475 146 304 minecraft:white_terracotta
fill 475 145 305 475 146 307 minecraft:white_wool
fill 475 145 308 475 146 308 minecraft:white_terracotta
fill 475 145 309 475 146 311 minecraft:white_wool
fill 475 145 312 475 148 312 minecraft:white_terracotta
fill 475 145 313 475 145 315 minecraft:white_wool
fill 475 145 316 475 146 316 minecraft:white_terracotta
fill 476 145 276 478 146 276 minecraft:white_wool
fill 476 145 277 476 146 277 minecraft:white_terracotta
fill 476 145 280 478 146 280 minecraft:white_wool
fill 476 145 281 476 146 281 minecraft:white_terracotta
fill 476 145 282 476 146 284 minecraft:white_wool
fill 476 145 285 476 146 285 minecraft:white_terracotta
fill 476 145 286 476 146 288 minecraft:white_wool
fill 476 145 289 476 146 289 minecraft:white_terracotta
fill 476 145 290 476 146 292 minecraft:white_wool
fill 476 145 293 476 146 293 minecraft:white_terracotta
fill 476 145 294 476 146 296 minecraft:white_wool
fill 476 145 297 476 146 297 minecraft:white_terracotta
fill 476 145 298 476 146 300 minecraft:white_wool
fill 476 145 301 476 146 301 minecraft:white_terracotta
fill 476 145 302 476 145 304 minecraft:white_wool
fill 476 145 305 476 146 305 minecraft:white_terracotta
fill 476 145 306 476 146 308 minecraft:white_wool
fill 476 145 309 476 146 309 minecraft:white_terracotta
fill 476 145 310 476 146 312 minecraft:white_wool
fill 476 145 313 476 146 313 minecraft:white_terracotta
fill 476 145 314 476 146 316 minecraft:white_wool
fill 477 145 277 479 146 277 minecraft:white_wool
fill 477 145 278 477 146 278 minecraft:white_terracotta
fill 477 145 281 479 146 281 minecraft:white_wool
fill 477 145 282 477 146 282 minecraft:white_terracotta
fill 477 145 283 477 146 285 minecraft:white_wool
fill 477 145 286 477 146 286 minecraft:white_terracotta
fill 477 145 287 477 146 289 minecraft:white_wool
fill 477 145 290 477 146 290 minecraft:white_terracotta
fill 477 145 291 477 146 293 minecraft:white_wool
fill 477 145 294 477 146 294 minecraft:white_terracotta
fill 477 145 295 477 146 297 minecraft:white_wool
fill 477 145 298 477 146 298 minecraft:white_terracotta
fill 477 145 299 477 146 301 minecraft:white_wool
fill 477 145 302 477 146 302 minecraft:white_terracotta
fill 477 145 303 477 146 305 minecraft:white_wool
fill 477 145 306 477 146 306 minecraft:white_terracotta
fill 477 145 307 477 146 309 minecraft:white_wool
fill 477 145 310 477 146 310 minecraft:white_terracotta
fill 477 145 311 477 146 313 minecraft:white_wool
fill 477 145 314 477 146 314 minecraft:white_terracotta
fill 477 145 315 477 146 316 minecraft:white_wool
fill 478 145 278 480 145 278 minecraft:white_wool
fill 478 145 279 478 146 279 minecraft:white_terracotta
fill 478 145 282 480 146 282 minecraft:white_wool
fill 478 145 283 478 146 283 minecraft:white_terracotta
fill 478 145 284 478 146 286 minecraft:white_wool
fill 478 145 287 478 146 287 minecraft:white_terracotta
fill 478 145 288 478 146 290 minecraft:white_wool
fill 478 145 291 478 146 291 minecraft:white_terracotta
fill 478 145 292 478 146 294 minecraft:white_wool
fill 478 145 295 478 146 295 minecraft:white_terracotta
fill 478 145 296 478 146 298 minecraft:white_wool
fill 478 145 299 478 146 299 minecraft:white_terracotta
fill 478 145 300 478 146 302 minecraft:white_wool
fill 478 145 303 478 146 303 minecraft:white_terracotta
fill 478 145 304 478 146 306 minecraft:white_wool
fill 478 145 307 478 146 307 minecraft:white_terracotta
fill 478 145 308 478 146 310 minecraft:white_wool
fill 478 145 311 478 146 311 minecraft:white_terracotta
fill 478 145 312 478 146 314 minecraft:white_wool
fill 478 145 315 478 146 315 minecraft:white_terracotta
fill 478 145 316 478 146 316 minecraft:white_wool
fill 479 145 276 479 146 276 minecraft:white_terracotta
fill 479 145 279 481 145 279 minecraft:white_wool
fill 479 145 280 479 147 280 minecraft:white_terracotta
fill 479 145 283 481 146 283 minecraft:white_wool
fill 479 145 284 479 146 284 minecraft:white_terracotta
fill 479 145 285 479 146 287 minecraft:white_wool
fill 479 145 288 479 146 288 minecraft:white_terracotta
fill 479 145 289 479 146 291 minecraft:white_wool
fill 479 145 292 479 146 292 minecraft:white_terracotta
fill 479 145 293 479 146 295 minecraft:white_wool
fill 479 145 296 479 146 296 minecraft:white_terracotta
fill 479 145 297 479 146 299 minecraft:white_wool
fill 479 145 300 479 146 300 minecraft:white_terracotta
fill 479 145 301 479 146 303 minecraft:white_wool
fill 479 145 304 479 146 304 minecraft:white_terracotta
fill 479 145 305 479 146 307 minecraft:white_wool
fill 479 145 308 479 146 308 minecraft:white_terracotta
fill 479 145 309 479 146 311 minecraft:white_wool
fill 479 145 312 479 146 312 minecraft:white_terracotta
fill 479 145 313 479 146 315 minecraft:white_wool
fill 479 145 316 479 146 316 minecraft:white_terracotta
fill 480 145 276 482 146 276 minecraft:white_wool
fill 480 145 277 480 146 277 minecraft:white_terracotta
fill 480 145 280 482 145 280 minecraft:white_wool
fill 480 145 281 480 146 281 minecraft:white_terracotta
fill 480 145 284 482 146 284 minecraft:white_wool
fill 480 145 285 480 146 285 minecraft:white_terracotta
fill 480 145 286 480 146 288 minecraft:white_wool
fill 480 145 289 480 146 289 minecraft:white_terracotta
fill 480 145 290 480 146 292 minecraft:white_wool
fill 480 145 293 480 146 293 minecraft:white_terracotta
fill 480 145 294 480 146 296 minecraft:white_wool
fill 480 145 297 480 146 297 minecraft:white_terracotta
fill 480 145 298 480 146 300 minecraft:white_wool
fill 480 145 301 480 146 301 minecraft:white_terracotta
fill 480 145 302 480 146 304 minecraft:white_wool
fill 480 145 305 480 146 305 minecraft:white_terracotta
fill 480 145 306 480 146 308 minecraft:white_wool
fill 480 145 309 480 146 309 minecraft:white_terracotta
fill 480 145 310 480 146 312 minecraft:white_wool
fill 480 145 313 480 146 313 minecraft:white_terracotta
fill 480 145 314 480 146 316 minecraft:white_wool
fill 481 145 277 483 146 277 minecraft:white_wool
fill 481 145 278 481 147 278 minecraft:white_terracotta
fill 481 145 281 483 146 281 minecraft:white_wool
fill 481 145 282 481 146 282 minecraft:white_terracotta
fill 481 145 285 483 146 285 minecraft:white_wool
fill 481 145 286 481 146 286 minecraft:white_terracotta
fill 481 145 287 481 146 289 minecraft:white_wool
fill 481 145 290 481 146 290 minecraft:white_terracotta
fill 481 145 291 481 146 293 minecraft:white_wool
fill 481 145 294 481 146 294 minecraft:white_terracotta
fill 481 145 295 481 146 297 minecraft:white_wool
fill 481 145 298 481 146 298 minecraft:white_terracotta
fill 481 145 299 481 146 301 minecraft:white_wool
fill 481 145 302 481 146 302 minecraft:white_terracotta
fill 481 145 303 481 146 305 minecraft:white_wool
fill 481 145 306 481 146 306 minecraft:white_terracotta
fill 481 145 307 481 146 309 minecraft:white_wool
fill 481 145 310 481 146 310 minecraft:white_terracotta
fill 481 145 311 481 146 313 minecraft:white_wool
fill 481 145 314 481 146 314 minecraft:white_terracotta
fill 481 145 315 481 146 316 minecraft:white_wool
fill 482 145 278 484 146 278 minecraft:white_wool
fill 482 145 279 482 146 279 minecraft:white_terracotta
fill 482 145 282 484 146 282 minecraft:white_wool
fill 482 145 283 482 146 283 minecraft:white_terracotta
fill 482 145 286 484 146 286 minecraft:white_wool
fill 482 145 287 482 146 287 minecraft:white_terracotta
fill 482 145 288 482 146 290 minecraft:white_wool
fill 482 145 291 482 146 291 minecraft:white_terracotta
fill 482 145 292 482 146 294 minecraft:white_wool
fill 482 145 295 482 146 295 minecraft:white_terracotta
fill 482 145 296 482 145 298 minecraft:white_wool
fill 482 145 299 482 146 299 minecraft:white_terracotta
fill 482 145 300 482 146 302 minecraft:white_wool
fill 482 145 303 482 146 303 minecraft:white_terracotta
fill 482 145 304 482 146 306 minecraft:white_wool
fill 482 145 307 482 146 307 minecraft:white_terracotta
fill 482 145 308 482 146 310 minecraft:white_wool
fill 482 145 311 482 146 311 minecraft:white_terracotta
fill 482 145 312 482 146 314 minecraft:white_wool
fill 482 145 315 482 146 315 minecraft:white_terracotta
fill 482 145 316 482 146 316 minecraft:white_wool
fill 483 145 276 483 146 276 minecraft:white_terracotta
fill 483 145 279 485 146 279 minecraft:white_wool
fill 483 145 280 483 146 280 minecraft:white_terracotta
fill 483 145 283 485 146 283 minecraft:white_wool
fill 483 145 284 483 146 284 minecraft:white_terracotta
fill 483 145 287 485 146 287 minecraft:white_wool
fill 483 145 288 483 146 288 minecraft:white_terracotta
fill 483 145 289 483 146 291 minecraft:white_wool
fill 483 145 292 483 146 292 minecraft:white_terracotta
fill 483 145 293 483 146 295 minecraft:white_wool
fill 483 145 296 483 146 296 minecraft:white_terracotta
fill 483 145 297 483 145 299 minecraft:white_wool
fill 483 145 300 483 146 300 minecraft:white_terracotta
fill 483 145 301 483 146 303 minecraft:white_wool
fill 483 145 304 483 146 304 minecraft:white_terracotta
fill 483 145 305 483 146 307 minecraft:white_wool
fill 483 145 308 483 146 308 minecraft:white_terracotta
fill 483 145 309 483 146 311 minecraft:white_wool
fill 483 145 312 483 146 312 minecraft:white_terracotta
fill 483 145 313 483 146 315 minecraft:white_wool
fill 483 145 316 483 146 316 minecraft:white_terracotta
fill 484 145 276 486 146 276 minecraft:white_wool
fill 484 145 277 484 146 277 minecraft:white_terracotta
fill 484 145 280 486 146 280 minecraft:white_wool
fill 484 145 281 484 146 281 minecraft:white_terracotta
fill 484 145 284 486 146 284 minecraft:white_wool
fill 484 145 285 484 146 285 minecraft:white_terracotta
fill 484 145 288 486 146 288 minecraft:white_wool
fill 484 145 289 484 146 289 minecraft:white_terracotta
fill 484 145 290 484 146 292 minecraft:white_wool
fill 484 145 293 484 146 293 minecraft:white_terracotta
fill 484 145 294 484 146 296 minecraft:white_wool
fill 484 145 297 484 146 297 minecraft:white_terracotta
fill 484 145 298 484 146 300 minecraft:white_wool
fill 484 145 301 484 146 301 minecraft:white_terracotta
fill 484 145 302 484 146 304 minecraft:white_wool
fill 484 145 305 484 146 305 minecraft:white_terracotta
fill 484 145 306 484 146 308 minecraft:white_wool
fill 484 145 309 484 146 309 minecraft:white_terracotta
fill 484 145 310 484 146 312 minecraft:white_wool
fill 484 145 313 484 146 313 minecraft:white_terracotta
fill 484 145 314 484 146 316 minecraft:white_wool
fill 485 145 277 487 146 277 minecraft:white_wool
fill 485 145 278 485 146 278 minecraft:white_terracotta
fill 485 145 281 487 146 281 minecraft:white_wool
fill 485 145 282 485 146 282 minecraft:white_terracotta
fill 485 145 285 487 146 285 minecraft:white_wool
fill 485 145 286 485 146 286 minecraft:white_terracotta
fill 485 145 289 487 146 289 minecraft:white_wool
fill 485 145 290 485 146 290 minecraft:white_terracotta
fill 485 145 291 485 146 293 minecraft:white_wool
fill 485 145 294 485 146 294 minecraft:white_terracotta
fill 485 145 295 485 146 297 minecraft:white_wool
fill 485 145 298 485 146 298 minecraft:white_terracotta
fill 485 145 299 485 146 301 minecraft:white_wool
fill 485 145 302 485 146 302 minecraft:white_terracotta
fill 485 145 303 485 146 305 minecraft:white_wool
fill 485 145 306 485 146 306 minecraft:white_terracotta
fill 485 145 307 485 146 309 minecraft:white_wool
fill 485 145 310 485 146 310 minecraft:white_terracotta
fill 485 145 311 485 145 313 minecraft:white_wool
fill 485 145 314 485 146 314 minecraft:white_terracotta
fill 485 145 315 485 146 316 minecraft:white_wool
fill 486 145 278 488 146 278 minecraft:white_wool
fill 486 145 279 486 146 279 minecraft:white_terracotta
fill 486 145 282 488 146 282 minecraft:white_wool
fill 486 145 283 486 146 283 minecraft:white_terracotta
fill 486 145 286 488 146 286 minecraft:white_wool
fill 486 145 287 486 146 287 minecraft:white_terracotta
fill 486 145 290 488 146 290 minecraft:white_wool
fill 486 145 291 486 146 291 minecraft:white_terracotta
fill 486 145 292 486 145 294 minecraft:white_wool
setblock 486 145 295 minecraft:white_terracotta
fill 486 145 296 486 145 298 minecraft:white_wool
fill 486 145 299 486 146 299 minecraft:white_terracotta
fill 486 145 300 486 146 302 minecraft:white_wool
fill 486 145 303 486 146 303 minecraft:white_terracotta
fill 486 145 304 486 146 306 minecraft:white_wool
fill 486 145 307 486 149 307 minecraft:white_terracotta
fill 486 145 308 486 146 310 minecraft:white_wool
fill 486 145 311 486 148 311 minecraft:white_terracotta
fill 486 145 312 486 145 314 minecraft:white_wool
fill 486 145 315 486 146 315 minecraft:white_terracotta
fill 486 145 316 486 146 316 minecraft:white_wool
fill 487 145 276 487 146 276 minecraft:white_terracotta
fill 487 145 279 489 146 279 minecraft:white_wool
fill 487 145 280 487 146 280 minecraft:white_terracotta
fill 487 145 283 489 146 283 minecraft:white_wool
fill 487 145 284 487 146 284 minecraft:white_terracotta
fill 487 145 287 489 146 287 minecraft:white_wool
fill 487 145 288 487 146 288 minecraft:white_terracotta
fill 487 145 291 489 145 291 minecraft:white_wool
setblock 487 145 292 minecraft:white_terracotta
setblock 487 145 296 minecraft:white_terracotta
fill 487 145 297 487 145 299 minecraft:white_wool
fill 487 145 300 487 146 300 minecraft:white_terracotta
fill 487 145 301 487 146 303 minecraft:white_wool
fill 487 145 304 487 146 304 minecraft:white_terracotta
fill 487 145 305 487 146 307 minecraft:white_wool
fill 487 145 308 487 149 308 minecraft:white_terracotta
fill 487 145 309 487 146 311 minecraft:white_wool
fill 487 145 312 487 147 312 minecraft:white_terracotta
fill 487 145 313 487 146 315 minecraft:white_wool
fill 487 145 316 487 146 316 minecraft:white_terracotta
fill 488 145 276 490 146 276 minecraft:white_wool
fill 488 145 277 488 146 277 minecraft:white_terracotta
fill 488 145 280 490 146 280 minecraft:white_wool
fill 488 145 281 488 146 281 minecraft:white_terracotta
fill 488 145 284 490 146 284 minecraft:white_wool
fill 488 145 285 488 146 285 minecraft:white_terracotta
fill 488 145 288 490 146 288 minecraft:white_wool
fill 488 145 289 488 146 289 minecraft:white_terracotta
setblock 488 145 297 minecraft:white_terracotta
fill 488 145 298 488 146 300 minecraft:white_wool
fill 488 145 301 488 146 301 minecraft:white_terracotta
fill 488 145 302 488 146 304 minecraft:white_wool
fill 488 145 305 488 146 305 minecraft:white_terracotta
fill 488 145 306 488 146 308 minecraft:white_wool
fill 488 145 309 488 146 309 minecraft:white_terracotta
fill 488 145 310 488 146 312 minecraft:white_wool
fill 488 145 313 488 146 313 minecraft:white_terracotta
fill 488 145 314 488 146 316 minecraft:white_wool
fill 489 145 277 491 146 277 minecraft:white_wool
fill 489 145 278 489 146 278 minecraft:white_terracotta
fill 489 145 281 491 146 281 minecraft:white_wool
fill 489 145 282 489 147 282 minecraft:white_terracotta
fill 489 145 285 491 146 285 minecraft:white_wool
fill 489 145 286 489 146 286 minecraft:white_terracotta
fill 489 145 289 491 146 289 minecraft:white_wool
fill 489 145 290 489 146 290 minecraft:white_terracotta
fill 489 145 297 491 145 297 minecraft:white_wool
fill 489 145 298 489 146 298 minecraft:white_terracotta
fill 489 145 299 489 146 301 minecraft:white_wool
fill 489 145 302 489 146 302 minecraft:white_terracotta
fill 489 145 303 489 146 305 minecraft:white_wool
fill 489 145 306 489 146 306 minecraft:white_terracotta
fill 489 145 307 489 146 309 minecraft:white_wool
fill 489 145 310 489 146 310 minecraft:white_terracotta
fill 489 145 311 489 146 313 minecraft:white_wool
fill 489 145 314 489 146 314 minecraft:white_terracotta
fill 489 145 315 489 146 316 minecraft:white_wool
fill 490 145 278 492 146 278 minecraft:white_wool
fill 490 145 279 490 146 279 minecraft:white_terracotta
fill 490 145 282 492 145 282 minecraft:white_wool
fill 490 145 283 490 148 283 minecraft:white_terracotta
fill 490 145 286 492 146 286 minecraft:white_wool
fill 490 145 287 490 146 287 minecraft:white_terracotta
fill 490 145 290 492 146 290 minecraft:white_wool
setblock 490 145 291 minecraft:white_terracotta
fill 490 145 298 492 146 298 minecraft:white_wool
fill 490 145 299 490 146 299 minecraft:white_terracotta
fill 490 145 300 490 146 302 minecraft:white_wool
fill 490 145 303 490 146 303 minecraft:white_terracotta
fill 490 145 304 490 146 306 minecraft:white_wool
fill 490 145 307 490 146 307 minecraft:white_terracotta
fill 490 145 308 490 146 310 minecraft:white_wool
fill 490 145 311 490 146 311 minecraft:white_terracotta
fill 490 145 312 490 146 314 minecraft:white_wool
fill 490 145 315 490 146 315 minecraft:white_terracotta
fill 490 145 316 490 146 316 minecraft:white_wool
fill 491 145 276 491 146 276 minecraft:white_terracotta
fill 491 145 279 493 146 279 minecraft:white_wool
fill 491 145 280 491 146 280 minecraft:white_terracotta
fill 491 145 283 493 145 283 minecraft:white_wool
fill 491 145 284 491 146 284 minecraft:white_terracotta
fill 491 145 287 493 146 287 minecraft:white_wool
fill 491 145 288 491 146 288 minecraft:white_terracotta
fill 491 145 291 493 145 291 minecraft:white_wool
setblock 491 145 292 minecraft:white_terracotta
setblock 491 145 296 minecraft:white_terracotta
fill 491 145 299 493 146 299 minecraft:white_wool
fill 491 145 300 491 146 300 minecraft:white_terracotta
fill 491 145 301 491 146 303 minecraft:white_wool
fill 491 145 304 491 146 304 minecraft:white_terracotta
fill 491 145 305 491 146 307 minecraft:white_wool
fill 491 145 308 491 146 308 minecraft:white_terracotta
fill 491 145 309 491 146 311 minecraft:white_wool
fill 491 145 312 491 146 312 minecraft:white_terracotta
fill 491 145 313 491 146 315 minecraft:white_wool
fill 491 145 316 491 146 316 minecraft:white_terracotta
fill 492 145 276 494 146 276 minecraft:white_wool
fill 492 145 277 492 146 277 minecraft:white_terracotta
fill 492 145 280 494 146 280 minecraft:white_wool
fill 492 145 281 492 146 281 minecraft:white_terracotta
fill 492 145 284 494 146 284 minecraft:white_wool
fill 492 145 285 492 146 285 minecraft:white_terracotta
fill 492 145 288 494 146 288 minecraft:white_wool
fill 492 145 289 492 146 289 minecraft:white_terracotta
fill 492 145 292 494 145 292 minecraft:white_wool
setblock 492 145 293 minecraft:white_terracotta
fill 492 145 294 492 145 296 minecraft:white_wool
fill 492 145 297 492 146 297 minecraft:white_terracotta
fill 492 145 300 494 146 300 minecraft:white_wool
fill 492 145 301 492 146 301 minecraft:white_terracotta
fill 492 145 302 492 146 304 minecraft:white_wool
fill 492 145 305 492 146 305 minecraft:white_terracotta
fill 492 145 306 492 146 308 minecraft:white_wool
fill 492 145 309 492 146 309 minecraft:white_terracotta
fill 492 145 310 492 146 312 minecraft:white_wool
fill 492 145 313 492 146 313 minecraft:white_terracotta
fill 492 145 314 492 146 316 minecraft:white_wool
fill 493 145 277 495 146 277 minecraft:white_wool
fill 493 145 278 493 146 278 minecraft:white_terracotta
fill 493 145 281 495 146 281 minecraft:white_wool
fill 493 145 282 493 146 282 minecraft:white_terracotta
fill 493 145 285 495 146 285 minecraft:white_wool
fill 493 145 286 493 146 286 minecraft:white_terracotta
fill 493 145 289 495 146 289 minecraft:white_wool
fill 493 145 290 493 146 290 minecraft:white_terracotta
fill 493 145 293 495 146 293 minecraft:white_wool
fill 493 145 294 493 146 294 minecraft:white_terracotta
fill 493 145 295 493 146 297 minecraft:white_wool
fill 493 145 298 493 146 298 minecraft:white_terracotta
fill 493 145 301 495 146 301 minecraft:white_wool
fill 493 145 302 493 146 302 minecraft:white_terracotta
fill 493 145 303 493 146 305 minecraft:white_wool
fill 493 145 306 493 146 306 minecraft:white_terracotta
fill 493 145 307 493 146 309 minecraft:white_wool
fill 493 145 310 493 146 310 minecraft:white_terracotta
fill 493 145 311 493 146 313 minecraft:white_wool
fill 493 145 314 493 146 314 minecraft:white_terracotta
fill 493 145 315 493 146 316 minecraft:white_wool
fill 494 145 278 496 145 278 minecraft:white_wool
fill 494 145 279 494 148 279 minecraft:white_terracotta
fill 494 145 282 496 146 282 minecraft:white_wool
fill 494 145 283 494 146 283 minecraft:white_terracotta
fill 494 145 286 496 146 286 minecraft:white_wool
fill 494 145 287 494 146 287 minecraft:white_terracotta
fill 494 145 290 496 146 290 minecraft:white_wool
fill 494 145 291 494 146 291 minecraft:white_terracotta
fill 494 145 294 496 146 294 minecraft:white_wool
fill 494 145 295 494 146 295 minecraft:white_terracotta
fill 494 145 296 494 146 298 minecraft:white_wool
fill 494 145 299 494 146 299 minecraft:white_terracotta
fill 494 145 302 496 146 302 minecraft:white_wool
fill 494 145 303 494 146 303 minecraft:white_terracotta
fill 494 145 304 494 146 306 minecraft:white_wool
fill 494 145 307 494 146 307 minecraft:white_terracotta
fill 494 145 308 494 146 310 minecraft:white_wool
fill 494 145 311 494 146 311 minecraft:white_terracotta
fill 494 145 312 494 146 314 minecraft:white_wool
fill 494 145 315 494 146 315 minecraft:white_terracotta
fill 494 145 316 494 146 316 minecraft:white_wool
fill 495 145 276 495 146 276 minecraft:white_terracotta
fill 495 145 279 497 145 279 minecraft:white_wool
fill 495 145 280 495 147 280 minecraft:white_terracotta
fill 495 145 283 497 146 283 minecraft:white_wool
fill 495 145 284 495 146 284 minecraft:white_terracotta
fill 495 145 287 497 146 287 minecraft:white_wool
fill 495 145 288 495 146 288 minecraft:white_terracotta
fill 495 145 291 497 146 291 minecraft:white_wool
fill 495 145 292 495 146 292 minecraft:white_terracotta
fill 495 145 295 497 146 295 minecraft:white_wool
fill 495 145 296 495 146 296 minecraft:white_terracotta
fill 495 145 297 495 146 299 minecraft:white_wool
fill 495 145 300 495 146 300 minecraft:white_terracotta
fill 495 145 303 497 146 303 minecraft:white_wool
fill 495 145 304 495 146 304 minecraft:white_terracotta
fill 495 145 305 495 146 307 minecraft:white_wool
fill 495 145 308 495 146 308 minecraft:white_terracotta
fill 495 145 309 495 146 311 minecraft:white_wool
fill 495 145 312 495 146 312 minecraft:white_terracotta
fill 495 145 313 495 146 315 minecraft:white_wool
fill 495 145 316 495 146 316 minecraft:white_terracotta
fill 496 145 276 498 146 276 minecraft:white_wool
fill 496 145 277 496 146 277 minecraft:white_terracotta
fill 496 145 280 498 146 280 minecraft:white_wool
fill 496 145 281 496 146 281 minecraft:white_terracotta
fill 496 145 284 498 146 284 minecraft:white_wool
fill 496 145 285 496 146 285 minecraft:white_terracotta
fill 496 145 288 498 146 288 minecraft:white_wool
fill 496 145 289 496 146 289 minecraft:white_terracotta
fill 496 145 292 498 146 292 minecraft:white_wool
fill 496 145 293 496 146 293 minecraft:white_terracotta
fill 496 145 296 498 146 296 minecraft:white_wool
fill 496 145 297 496 146 297 minecraft:white_terracotta
fill 496 145 298 496 146 300 minecraft:white_wool
fill 496 145 301 496 146 301 minecraft:white_terracotta
fill 496 145 304 498 146 304 minecraft:white_wool
fill 496 145 305 496 146 305 minecraft:white_terracotta
fill 496 145 306 496 146 308 minecraft:white_wool
fill 496 145 309 496 146 309 minecraft:white_terracotta
fill 496 145 310 496 146 312 minecraft:white_wool
fill 496 145 313 496 146 313 minecraft:white_terracotta
fill 496 145 314 496 146 316 minecraft:white_wool
fill 497 145 277 499 146 277 minecraft:white_wool
fill 497 145 278 497 146 278 minecraft:white_terracotta
fill 497 145 281 499 146 281 minecraft:white_wool
fill 497 145 282 497 146 282 minecraft:white_terracotta
fill 497 145 285 499 146 285 minecraft:white_wool
fill 497 145 286 497 146 286 minecraft:white_terracotta
fill 497 145 289 499 146 289 minecraft:white_wool
fill 497 145 290 497 146 290 minecraft:white_terracotta
fill 497 145 293 499 146 293 minecraft:white_wool
fill 497 145 294 497 146 294 minecraft:white_terracotta
fill 497 145 297 499 146 297 minecraft:white_wool
fill 497 145 298 497 146 298 minecraft:white_terracotta
fill 497 145 299 497 146 301 minecraft:white_wool
fill 497 145 302 497 146 302 minecraft:white_terracotta
fill 497 145 305 499 146 305 minecraft:white_wool
fill 497 145 306 497 146 306 minecraft:white_terracotta
fill 497 145 307 497 146 309 minecraft:white_wool
fill 497 145 310 497 146 310 minecraft:white_terracotta
fill 497 145 311 497 146 313 minecraft:white_wool
fill 497 145 314 497 146 314 minecraft:white_terracotta
fill 497 145 315 497 146 316 minecraft:white_wool
fill 498 145 278 500 146 278 minecraft:white_wool
fill 498 145 279 498 146 279 minecraft:white_terracotta
fill 498 145 282 500 146 282 minecraft:white_wool
fill 498 145 283 498 146 283 minecraft:white_terracotta
fill 498 145 286 500 146 286 minecraft:white_wool
fill 498 145 287 498 146 287 minecraft:white_terracotta
fill 498 145 290 500 146 290 minecraft:white_wool
fill 498 145 291 498 146 291 minecraft:white_terracotta
fill 498 145 294 500 146 294 minecraft:white_wool
fill 498 145 295 498 146 295 minecraft:white_terracotta
fill 498 145 298 500 146 298 minecraft:white_wool
fill 498 145 299 498 146 299 minecraft:white_terracotta
fill 498 145 300 498 146 302 minecraft:white_wool
fill 498 145 303 498 146 303 minecraft:white_terracotta
fill 498 145 306 500 146 306 minecraft:white_wool
fill 498 145 307 498 146 307 minecraft:white_terracotta
fill 498 145 308 498 146 310 minecraft:white_wool
fill 498 145 311 498 146 311 minecraft:white_terracotta
fill 498 145 312 498 146 314 minecraft:white_wool
fill 498 145 315 498 146 315 minecraft:white_terracotta
fill 498 145 316 498 146 316 minecraft:white_wool
fill 499 145 276 499 146 276 minecraft:white_terracotta
fill 499 145 279 501 146 279 minecraft:white_wool
fill 499 145 280 499 146 280 minecraft:white_terracotta
fill 499 145 283 501 146 283 minecraft:white_wool
fill 499 145 284 499 146 284 minecraft:white_terracotta
fill 499 145 287 501 146 287 minecraft:white_wool
fill 499 145 288 499 146 288 minecraft:white_terracotta
fill 499 145 291 501 146 291 minecraft:white_wool
fill 499 145 292 499 146 292 minecraft:white_terracotta
fill 499 145 295 501 146 295 minecraft:white_wool
fill 499 145 296 499 146 296 minecraft:white_terracotta
fill 499 145 299 501 146 299 minecraft:white_wool
fill 499 145 300 499 146 300 minecraft:white_terracotta
fill 499 145 301 499 146 303 minecraft:white_wool
fill 499 145 304 499 146 304 minecraft:white_terracotta
fill 499 145 307 501 146 307 minecraft:white_wool
fill 499 145 308 499 146 308 minecraft:white_terracotta
fill 499 145 309 499 146 311 minecraft:white_wool
fill 499 145 312 499 146 312 minecraft:white_terracotta
fill 499 145 313 499 146 315 minecraft:white_wool
fill 499 145 316 499 146 316 minecraft:white_terracotta
fill 500 145 276 502 146 276 minecraft:white_wool
fill 500 145 277 500 146 277 minecraft:white_terracotta
fill 500 145 280 502 146 280 minecraft:white_wool
fill 500 145 281 500 146 281 minecraft:white_terracotta
fill 500 145 284 502 146 284 minecraft:white_wool
fill 500 145 285 500 146 285 minecraft:white_terracotta
fill 500 145 288 502 146 288 minecraft:white_wool
fill 500 145 289 500 146 289 minecraft:white_terracotta
fill 500 145 292 502 146 292 minecraft:white_wool
fill 500 145 293 500 146 293 minecraft:white_terracotta
fill 500 145 296 502 146 296 minecraft:white_wool
fill 500 145 297 500 146 297 minecraft:white_terracotta
fill 500 145 300 502 146 300 minecraft:white_wool
fill 500 145 301 500 146 301 minecraft:white_terracotta
fill 500 145 302 500 146 304 minecraft:white_wool
fill 500 145 305 500 146 305 minecraft:white_terracotta
fill 500 145 308 502 146 308 minecraft:white_wool
fill 500 145 309 500 146 309 minecraft:white_terracotta
fill 500 145 310 500 146 312 minecraft:white_wool
fill 500 145 313 500 146 313 minecraft:white_terracotta
fill 500 145 314 500 146 316 minecraft:white_wool
fill 501 145 277 503 146 277 minecraft:white_wool
fill 501 145 278 501 146 278 minecraft:white_terracotta
fill 501 145 281 503 145 281 minecraft:white_wool
fill 501 145 282 501 146 282 minecraft:white_terracotta
fill 501 145 285 503 146 285 minecraft:white_wool
fill 501 145 286 501 146 286 minecraft:white_terracotta
fill 501 145 289 503 146 289 minecraft:white_wool
fill 501 145 290 501 146 290 minecraft:white_terracotta
fill 501 145 293 503 146 293 minecraft:white_wool
fill 501 145 294 501 146 294 minecraft:white_terracotta
fill 501 145 297 503 146 297 minecraft:white_wool
fill 501 145 298 501 146 298 minecraft:white_terracotta
fill 501 145 301 503 146 301 minecraft:white_wool
fill 501 145 302 501 146 302 minecraft:white_terracotta
fill 501 145 303 501 146 305 minecraft:white_wool
fill 501 145 306 501 146 306 minecraft:white_terracotta
fill 501 145 309 503 146 309 minecraft:white_wool
fill 501 145 310 501 146 310 minecraft:white_terracotta
fill 501 145 311 501 146 313 minecraft:white_wool
fill 501 145 314 501 146 314 minecraft:white_terracotta
fill 501 145 315 501 146 316 minecraft:white_wool
fill 502 145 278 504 146 278 minecraft:white_wool
fill 502 145 279 502 146 279 minecraft:white_terracotta
fill 502 145 282 504 145 282 minecraft:white_wool
fill 502 145 283 502 148 283 minecraft:white_terracotta
fill 502 145 286 504 146 286 minecraft:white_wool
fill 502 145 287 502 146 287 minecraft:white_terracotta
fill 502 145 290 504 146 290 minecraft:white_wool
fill 502 145 291 502 146 291 minecraft:white_terracotta
fill 502 145 294 504 146 294 minecraft:white_wool
fill 502 145 295 502 146 295 minecraft:white_terracotta
fill 502 145 298 504 146 298 minecraft:white_wool
fill 502 145 299 502 146 299 minecraft:white_terracotta
fill 502 145 302 504 146 302 minecraft:white_wool
fill 502 145 303 502 146 303 minecraft:white_terracotta
fill 502 145 304 502 145 306 minecraft:white_wool
fill 502 145 307 502 146 307 minecraft:white_terracotta
fill 502 145 310 504 146 310 minecraft:white_wool
fill 502 145 311 502 146 311 minecraft:white_terracotta
fill 502 145 312 502 146 314 minecraft:white_wool
fill 502 145 315 502 146 315 minecraft:white_terracotta
fill 502 145 316 502 146 316 minecraft:white_wool
fill 503 145 276 503 146 276 minecraft:white_terracotta
fill 503 145 279 505 145 279 minecraft:white_wool
fill 503 145 280 503 148 280 minecraft:white_terracotta
fill 503 145 283 505 145 283 minecraft:white_wool
fill 503 145 284 503 147 284 minecraft:white_terracotta
fill 503 145 287 505 146 287 minecraft:white_wool
fill 503 145 288 503 146 288 minecraft:white_terracotta
fill 503 145 291 505 146 291 minecraft:white_wool
fill 503 145 292 503 146 292 minecraft:white_terracotta
fill 503 145 295 505 146 295 minecraft:white_wool
fill 503 145 296 503 146 296 minecraft:white_terracotta
fill 503 145 299 505 146 299 minecraft:white_wool
fill 503 145 300 503 146 300 minecraft:white_terracotta
fill 503 145 303 505 146 303 minecraft:white_wool
fill 503 145 304 503 148 304 minecraft:white_terracotta
fill 503 145 305 503 145 307 minecraft:white_wool
fill 503 145 308 503 146 308 minecraft:white_terracotta
fill 503 145 311 505 146 311 minecraft:white_wool
fill 503 145 312 503 146 312 minecraft:white_terracotta
fill 503 145 313 503 146 315 minecraft:white_wool
fill 503 145 316 503 146 316 minecraft:white_terracotta
fill 504 145 276 506 146 276 minecraft:white_wool
fill 504 145 277 504 146 277 minecraft:white_terracotta
fill 504 145 280 506 145 280 minecraft:white_wool
fill 504 145 281 504 147 281 minecraft:white_terracotta
fill 504 145 284 506 146 284 minecraft:white_wool
fill 504 145 285 504 146 285 minecraft:white_terracotta
fill 504 145 288 506 146 288 minecraft:white_wool
fill 504 145 289 504 146 289 minecraft:white_terracotta
fill 504 145 292 506 146 292 minecraft:white_wool
fill 504 145 293 504 146 293 minecraft:white_terracotta
fill 504 145 296 506 146 296 minecraft:white_wool
fill 504 145 297 504 146 297 minecraft:white_terracotta
fill 504 145 300 506 146 300 minecraft:white_wool
fill 504 145 301 504 146 301 minecraft:white_terracotta
fill 504 145 304 506 145 304 minecraft:white_wool
fill 504 145 305 504 148 305 minecraft:white_terracotta
fill 504 145 306 504 146 308 minecraft:white_wool
fill 504 145 309 504 146 309 minecraft:white_terracotta
fill 504 145 312 506 146 312 minecraft:white_wool
fill 504 145 313 504 146 313 minecraft:white_terracotta
fill 504 145 314 504 146 316 minecraft:white_wool
fill 505 145 277 507 146 277 minecraft:white_wool
fill 505 145 278 505 148 278 minecraft:white_terracotta
fill 505 145 281 507 146 281 minecraft:white_wool
fill 505 145 282 505 148 282 minecraft:white_terracotta
fill 505 145 285 507 146 285 minecraft:white_wool
fill 505 145 286 505 146 286 minecraft:white_terracotta
fill 505 145 289 507 146 289 minecraft:white_wool
fill 505 145 290 505 146 290 minecraft:white_terracotta
fill 505 145 293 507 146 293 minecraft:white_wool
fill 505 145 294 505 146 294 minecraft:white_terracotta
fill 505 145 297 507 146 297 minecraft:white_wool
fill 505 145 298 505 146 298 minecraft:white_terracotta
fill 505 145 301 507 146 301 minecraft:white_wool
fill 505 145 302 505 146 302 minecraft:white_terracotta
fill 505 145 305 507 145 305 minecraft:white_wool
fill 505 145 306 505 146 306 minecraft:white_terracotta
fill 505 145 307 505 146 309 minecraft:white_wool
fill 505 145 310 505 146 310 minecraft:white_terracotta
fill 505 145 313 507 146 313 minecraft:white_wool
fill 505 145 314 505 146 314 minecraft:white_terracotta
fill 505 145 315 505 146 316 minecraft:white_wool
fill 506 145 278 508 145 278 minecraft:white_wool
fill 506 145 279 506 148 279 minecraft:white_terracotta
fill 506 145 282 508 146 282 minecraft:white_wool
fill 506 145 283 506 147 283 minecraft:white_terracotta
fill 506 145 286 508 146 286 minecraft:white_wool
fill 506 145 287 506 146 287 minecraft:white_terracotta
fill 506 145 290 508 146 290 minecraft:white_wool
fill 506 145 291 506 146 291 minecraft:white_terracotta
fill 506 145 294 508 146 294 minecraft:white_wool
fill 506 145 295 506 146 295 minecraft:white_terracotta
fill 506 145 298 508 146 298 minecraft:white_wool
fill 506 145 299 506 146 299 minecraft:white_terracotta
fill 506 145 302 508 146 302 minecraft:white_wool
fill 506 145 303 506 146 303 minecraft:white_terracotta
fill 506 145 306 508 146 306 minecraft:white_wool
fill 506 145 307 506 146 307 minecraft:white_terracotta
fill 506 145 308 506 146 310 minecraft:white_wool
fill 506 145 311 506 146 311 minecraft:white_terracotta
fill 506 145 314 508 146 314 minecraft:white_wool
fill 506 145 315 506 146 315 minecraft:white_terracotta
fill 506 145 316 506 146 316 minecraft:white_wool
fill 507 145 276 507 146 276 minecraft:white_terracotta
fill 507 145 279 509 146 279 minecraft:white_wool
fill 507 145 280 507 146 280 minecraft:white_terracotta
fill 507 145 283 509 146 283 minecraft:white_wool
fill 507 145 284 507 146 284 minecraft:white_terracotta
fill 507 145 287 509 146 287 minecraft:white_wool
fill 507 145 288 507 146 288 minecraft:white_terracotta
fill 507 145 291 509 146 291 minecraft:white_wool
fill 507 145 292 507 146 292 minecraft:white_terracotta
fill 507 145 295 509 146 295 minecraft:white_wool
fill 507 145 296 507 146 296 minecraft:white_terracotta
fill 507 145 299 509 146 299 minecraft:white_wool
fill 507 145 300 507 146 300 minecraft:white_terracotta
fill 507 145 303 509 146 303 minecraft:white_wool
fill 507 145 304 507 148 304 minecraft:white_terracotta
fill 507 145 307 509 146 307 minecraft:white_wool
fill 507 145 308 507 147 308 minecraft:white_terracotta
fill 507 145 309 507 145 311 minecraft:white_wool
fill 507 145 312 507 146 312 minecraft:white_terracotta
fill 507 145 315 509 146 315 minecraft:white_wool
fill 507 145 316 507 146 316 minecraft:white_terracotta
fill 508 145 276 510 146 276 minecraft:white_wool
fill 508 145 277 508 146 277 minecraft:white_terracotta
fill 508 145 280 510 146 280 minecraft:white_wool
fill 508 145 281 508 146 281 minecraft:white_terracotta
fill 508 145 284 510 146 284 minecraft:white_wool
fill 508 145 285 508 146 285 minecraft:white_terracotta
fill 508 145 288 510 146 288 minecraft:white_wool
fill 508 145 289 508 146 289 minecraft:white_terracotta
fill 508 145 292 510 146 292 minecraft:white_wool
fill 508 145 293 508 146 293 minecraft:white_terracotta
fill 508 145 296 510 146 296 minecraft:white_wool
fill 508 145 297 508 146 297 minecraft:white_terracotta
fill 508 145 300 510 146 300 minecraft:white_wool
fill 508 145 301 508 146 301 minecraft:white_terracotta
fill 508 145 304 510 145 304 minecraft:white_wool
fill 508 145 305 508 147 305 minecraft:white_terracotta
fill 508 145 308 510 146 308 minecraft:white_wool
fill 508 145 309 508 148 309 minecraft:white_terracotta
fill 508 145 310 508 145 312 minecraft:white_wool
fill 508 145 313 508 146 313 minecraft:white_terracotta
fill 508 145 316 510 146 316 minecraft:white_wool
fill 509 145 277 511 146 277 minecraft:white_wool
fill 509 145 278 509 146 278 minecraft:white_terracotta
fill 509 145 281 511 146 281 minecraft:white_wool
fill 509 145 282 509 146 282 minecraft:white_terracotta
fill 509 145 285 511 146 285 minecraft:white_wool
fill 509 145 286 509 146 286 minecraft:white_terracotta
fill 509 145 289 511 146 289 minecraft:white_wool
fill 509 145 290 509 146 290 minecraft:white_terracotta
fill 509 145 293 511 146 293 minecraft:white_wool
fill 509 145 294 509 146 294 minecraft:white_terracotta
fill 509 145 297 511 146 297 minecraft:white_wool
fill 509 145 298 509 146 298 minecraft:white_terracotta
fill 509 145 301 511 146 301 minecraft:white_wool
fill 509 145 302 509 146 302 minecraft:white_terracotta
fill 509 145 305 511 146 305 minecraft:white_wool
fill 509 145 306 509 146 306 minecraft:white_terracotta
fill 509 145 309 511 146 309 minecraft:white_wool
fill 509 145 310 509 146 310 minecraft:white_terracotta
fill 509 145 311 509 146 313 minecraft:white_wool
fill 509 145 314 509 146 314 minecraft:white_terracotta
fill 510 145 278 511 146 278 minecraft:white_wool
fill 510 145 279 510 146 279 minecraft:white_terracotta
fill 510 145 282 511 146 282 minecraft:white_wool
fill 510 145 283 510 146 283 minecraft:white_terracotta
fill 510 145 286 511 146 286 minecraft:white_wool
fill 510 145 287 510 146 287 minecraft:white_terracotta
fill 510 145 290 511 146 290 minecraft:white_wool
fill 510 145 291 510 146 291 minecraft:white_terracotta
fill 510 145 294 511 146 294 minecraft:white_wool
fill 510 145 295 510 146 295 minecraft:white_terracotta
fill 510 145 298 511 146 298 minecraft:white_wool
fill 510 145 299 510 146 299 minecraft:white_terracotta
fill 510 145 302 511 146 302 minecraft:white_wool
fill 510 145 303 510 146 303 minecraft:white_terracotta
fill 510 145 306 511 146 306 minecraft:white_wool
fill 510 145 307 510 146 307 minecraft:white_terracotta
fill 510 145 310 511 146 310 minecraft:white_wool
fill 510 145 311 510 146 311 minecraft:white_terracotta
fill 510 145 312 510 146 314 minecraft:white_wool
fill 510 145 315 510 146 315 minecraft:white_terracotta
fill 511 145 276 511 146 276 minecraft:white_terracotta
fill 511 145 279 511 146 279 minecraft:white_wool
fill 511 145 280 511 146 280 minecraft:white_terracotta
fill 511 145 283 511 146 283 minecraft:white_wool
fill 511 145 284 511 146 284 minecraft:white_terracotta
fill 511 145 287 511 146 287 minecraft:white_wool
fill 511 145 288 511 146 288 minecraft:white_terracotta
fill 511 145 291 511 146 291 minecraft:white_wool
fill 511 145 292 511 146 292 minecraft:white_terracotta
fill 511 145 295 511 146 295 minecraft:white_wool
fill 511 145 296 511 146 296 minecraft:white_terracotta
fill 511 145 299 511 146 299 minecraft:white_wool
fill 511 145 300 511 146 300 minecraft:white_terracotta
fill 511 145 303 511 146 303 minecraft:white_wool
fill 511 145 304 511 146 304 minecraft:white_terracotta
fill 511 145 307 511 146 307 minecraft:white_wool
fill 511 145 308 511 146 308 minecraft:white_terracotta
fill 511 145 311 511 146 311 minecraft:white_wool
fill 511 145 312 511 146 312 minecraft:white_terracotta
fill 511 145 313 511 146 315 minecraft:white_wool
fill 511 145 316 511 146 316 minecraft:white_terracotta
fill 474 146 312 474 148 313 minecraft:white_terracotta
fill 474 146 314 475 146 314 minecraft:white_wool
fill 475 146 301 475 148 302 minecraft:white_terracotta
fill 475 146 303 476 146 303 minecraft:white_wool
fill 475 146 313 475 148 313 minecraft:white_terracotta
setblock 475 146 315 minecraft:white_wool
setblock 476 146 302 minecraft:white_terracotta
setblock 476 146 304 minecraft:white_wool
fill 478 146 278 479 146 278 minecraft:white_wool
fill 479 146 279 481 148 279 minecraft:white_terracotta
fill 480 146 278 480 148 278 minecraft:white_terracotta
fill 480 146 280 480 148 280 minecraft:white_terracotta
fill 481 146 280 482 146 280 minecraft:white_wool
fill 482 146 296 482 146 297 minecraft:white_wool
fill 482 146 298 483 146 298 minecraft:white_terracotta
setblock 483 146 297 minecraft:white_wool
setblock 483 146 299 minecraft:white_terracotta
fill 485 146 311 485 148 312 minecraft:white_terracotta
fill 485 146 313 486 146 313 minecraft:white_wool
setblock 486 146 292 minecraft:redstone_block
fill 486 146 293 486 146 295 minecraft:ochre_froglight
setblock 486 146 296 minecraft:redstone_block
fill 486 146 297 486 146 298 minecraft:white_wool
fill 486 146 312 486 148 312 minecraft:white_terracotta
setblock 486 146 314 minecraft:white_wool
setblock 487 146 291 minecraft:redstone_block
setblock 487 146 292 minecraft:ochre_froglight
setblock 487 146 296 minecraft:ochre_froglight
setblock 487 146 297 minecraft:redstone_block
fill 487 146 298 487 146 299 minecraft:white_wool
fill 488 146 291 490 146 291 minecraft:ochre_froglight
fill 488 146 297 490 146 297 minecraft:ochre_froglight
setblock 488 146 317 minecraft:redstone_block
fill 490 146 282 491 148 282 minecraft:white_terracotta
fill 491 146 283 491 148 283 minecraft:white_terracotta
setblock 491 146 291 minecraft:redstone_block
setblock 491 146 292 minecraft:ochre_froglight
setblock 491 146 296 minecraft:ochre_froglight
setblock 491 146 297 minecraft:redstone_block
fill 492 146 282 492 146 283 minecraft:white_wool
fill 492 146 291 493 146 291 minecraft:white_wool
setblock 492 146 292 minecraft:redstone_block
fill 492 146 293 492 146 295 minecraft:ochre_froglight
setblock 492 146 296 minecraft:redstone_block
setblock 493 146 283 minecraft:white_wool
fill 493 146 292 494 146 292 minecraft:white_wool
fill 494 146 278 496 148 278 minecraft:white_terracotta
fill 495 146 279 496 148 279 minecraft:white_terracotta
setblock 497 146 279 minecraft:white_wool
setblock 501 146 281 minecraft:white_wool
fill 502 146 281 503 148 282 minecraft:white_terracotta
setblock 502 146 304 minecraft:white_wool
fill 502 146 305 503 148 305 minecraft:white_terracotta
fill 502 146 306 503 146 306 minecraft:white_wool
fill 503 146 279 504 146 279 minecraft:white_wool
fill 503 146 283 505 148 283 minecraft:white_terracotta
setblock 503 146 307 minecraft:white_wool
fill 504 146 280 505 146 280 minecraft:white_wool
fill 504 146 282 504 148 282 minecraft:white_terracotta
fill 504 146 304 504 148 304 minecraft:white_terracotta
fill 505 146 279 505 148 279 minecraft:white_terracotta
fill 505 146 304 505 146 305 minecraft:white_wool
fill 506 146 278 506 148 278 minecraft:white_terracotta
fill 506 146 280 506 148 280 minecraft:white_terracotta
fill 506 146 304 506 148 305 minecraft:white_terracotta
fill 507 146 278 508 146 278 minecraft:white_wool
fill 507 146 305 507 148 305 minecraft:white_terracotta
fill 507 146 309 507 148 310 minecraft:white_terracotta
fill 507 146 311 508 146 311 minecraft:white_wool
fill 508 146 304 508 148 304 minecraft:white_terracotta
fill 508 146 310 508 148 310 minecraft:white_terracotta
setblock 508 146 312 minecraft:white_wool
fill 509 146 304 510 146 304 minecraft:white_wool
setblock 473 147 312 minecraft:white_terracotta
fill 474 147 301 474 147 302 minecraft:white_terracotta
setblock 475 147 311 minecraft:white_terracotta
fill 476 147 285 484 155 303 minecraft:smooth_stone
setblock 479 147 278 minecraft:white_terracotta
fill 485 147 285 485 155 303 minecraft:oak_planks
fill 486 147 308 486 149 308 minecraft:white_terracotta
fill 487 147 307 487 149 307 minecraft:white_terracotta
setblock 487 147 311 minecraft:white_terracotta
fill 488 147 317 488 201 317 minecraft:black_concrete
setblock 489 147 283 minecraft:white_terracotta
setblock 490 147 281 minecraft:white_terracotta
fill 494 147 285 494 155 303 minecraft:oak_planks
fill 495 147 285 502 155 303 minecraft:smooth_stone
setblock 502 147 280 minecraft:white_terracotta
setblock 502 147 284 minecraft:white_terracotta
setblock 502 147 304 minecraft:white_terracotta
setblock 503 147 306 minecraft:white_terracotta
fill 505 147 280 505 147 281 minecraft:white_terracotta
setblock 506 147 282 minecraft:white_terracotta
fill 506 147 309 506 147 310 minecraft:white_terracotta
setblock 507 147 279 minecraft:white_terracotta
setblock 507 147 303 minecraft:white_terracotta
setblock 508 147 308 minecraft:white_terracotta
setblock 512 147 289 minecraft:white_wool
fill 512 147 290 512 201 290 minecraft:black_concrete
fill 512 148 289 512 198 289 minecraft:black_concrete
setblock 473 149 278 minecraft:light[level=13]
setblock 473 149 286 minecraft:light[level=13]
setblock 473 149 294 minecraft:light[level=13]
setblock 473 149 302 minecraft:light[level=13]
setblock 473 149 310 minecraft:light[level=13]
setblock 481 149 278 minecraft:light[level=13]
setblock 481 149 310 minecraft:light[level=13]
setblock 489 149 278 minecraft:light[level=13]
setblock 489 149 286 minecraft:light[level=13]
setblock 489 149 302 minecraft:light[level=13]
setblock 489 149 310 minecraft:light[level=13]
setblock 497 149 278 minecraft:light[level=13]
setblock 497 149 310 minecraft:light[level=13]
setblock 505 149 278 minecraft:light[level=13]
setblock 505 149 286 minecraft:light[level=13]
setblock 505 149 294 minecraft:light[level=13]
setblock 505 149 302 minecraft:light[level=13]
setblock 505 149 310 minecraft:light[level=13]
fill 471 150 276 471 150 277 minecraft:deepslate_tiles
setblock 471 150 278 minecraft:cobbled_deepslate
fill 471 150 279 471 150 282 minecraft:deepslate_tiles
setblock 471 150 283 minecraft:cobbled_deepslate
setblock 471 150 284 minecraft:deepslate_tiles
fill 471 150 299 471 150 301 minecraft:deepslate_tiles
fill 471 150 314 471 150 316 minecraft:deepslate_tiles
setblock 472 150 276 minecraft:deepslate_tiles
setblock 472 150 277 minecraft:cobbled_deepslate
fill 472 150 278 472 150 281 minecraft:deepslate_tiles
setblock 472 150 316 minecraft:deepslate_tiles
setblock 473 150 276 minecraft:cobbled_deepslate
fill 473 150 277 476 150 277 minecraft:deepslate_tiles
fill 473 150 303 473 155 303 minecraft:black_concrete
setblock 473 150 316 minecraft:cobbled_deepslate
fill 474 150 276 477 150 276 minecraft:deepslate_tiles
fill 474 150 316 477 150 316 minecraft:deepslate_tiles
setblock 475 150 278 minecraft:deepslate_tiles
fill 475 150 315 478 150 315 minecraft:deepslate_tiles
setblock 476 150 278 minecraft:cobbled_deepslate
setblock 477 150 277 minecraft:cobbled_deepslate
fill 477 150 278 480 150 278 minecraft:deepslate_tiles
setblock 478 150 276 minecraft:cobbled_deepslate
fill 478 150 277 481 150 277 minecraft:deepslate_tiles
fill 478 150 312 478 157 312 minecraft:black_concrete
fill 478 150 314 479 150 314 minecraft:deepslate_tiles
setblock 478 150 316 minecraft:cobbled_deepslate
fill 479 150 276 482 150 276 minecraft:deepslate_tiles
setblock 479 150 315 minecraft:cobbled_deepslate
fill 479 150 316 482 150 316 minecraft:deepslate_tiles
setblock 480 150 314 minecraft:cobbled_deepslate
fill 480 150 315 483 150 315 minecraft:deepslate_tiles
setblock 481 150 278 minecraft:cobbled_deepslate
fill 481 150 314 484 150 314 minecraft:deepslate_tiles
setblock 482 150 277 minecraft:cobbled_deepslate
fill 482 150 278 485 150 278 minecraft:deepslate_tiles
setblock 483 150 276 minecraft:cobbled_deepslate
fill 483 150 277 486 150 277 minecraft:deepslate_tiles
setblock 483 150 316 minecraft:cobbled_deepslate
fill 484 150 276 487 150 276 minecraft:deepslate_tiles
setblock 484 150 315 minecraft:cobbled_deepslate
fill 484 150 316 487 150 316 minecraft:deepslate_tiles
setblock 485 150 314 minecraft:cobbled_deepslate
fill 485 150 315 487 150 315 minecraft:deepslate_tiles
setblock 487 150 277 minecraft:cobbled_deepslate
setblock 488 150 276 minecraft:cobbled_deepslate
setblock 488 150 316 minecraft:cobbled_deepslate
fill 489 150 276 491 150 276 minecraft:deepslate_tiles
fill 489 150 316 490 150 316 minecraft:deepslate_tiles
fill 494 150 276 497 150 276 minecraft:deepslate_tiles
setblock 497 150 277 minecraft:cobbled_deepslate
setblock 497 150 316 minecraft:deepslate_tiles
setblock 498 150 276 minecraft:cobbled_deepslate
fill 498 150 277 501 150 277 minecraft:deepslate_tiles
setblock 498 150 316 minecraft:cobbled_deepslate
fill 499 150 276 502 150 276 minecraft:deepslate_tiles
fill 499 150 278 500 150 278 minecraft:deepslate_tiles
fill 499 150 316 502 150 316 minecraft:deepslate_tiles
setblock 501 150 278 minecraft:cobbled_deepslate
setblock 502 150 277 minecraft:cobbled_deepslate
fill 502 150 278 504 150 279 minecraft:deepslate_tiles
setblock 503 150 276 minecraft:cobbled_deepslate
fill 503 150 277 506 150 277 minecraft:deepslate_tiles
setblock 503 150 316 minecraft:cobbled_deepslate
fill 504 150 276 507 150 276 minecraft:deepslate_tiles
fill 504 150 316 507 150 316 minecraft:deepslate_tiles
setblock 505 150 278 minecraft:deepslate_tiles
setblock 505 150 279 minecraft:cobbled_deepslate
setblock 506 150 278 minecraft:cobbled_deepslate
setblock 506 150 279 minecraft:deepslate_tiles
setblock 507 150 277 minecraft:cobbled_deepslate
fill 507 150 278 510 150 278 minecraft:deepslate_tiles
fill 507 150 293 507 153 293 minecraft:white_wool
setblock 508 150 276 minecraft:cobbled_deepslate
fill 508 150 277 511 150 277 minecraft:deepslate_tiles
setblock 508 150 316 minecraft:cobbled_deepslate
fill 509 150 276 511 151 276 minecraft:deepslate_tiles
setblock 509 150 279 minecraft:deepslate_tiles
setblock 509 150 280 minecraft:cobbled_deepslate
fill 509 150 281 511 150 282 minecraft:deepslate_tiles
fill 509 150 316 510 150 316 minecraft:deepslate_tiles
setblock 510 150 279 minecraft:cobbled_deepslate
fill 510 150 280 511 152 280 minecraft:deepslate_tiles
setblock 510 150 283 minecraft:deepslate_tiles
setblock 510 150 284 minecraft:cobbled_deepslate
setblock 511 150 278 minecraft:cobbled_deepslate
fill 511 150 279 511 153 279 minecraft:deepslate_tiles
setblock 511 150 283 minecraft:cobbled_deepslate
fill 511 150 284 511 150 287 minecraft:deepslate_tiles
setblock 511 150 293 minecraft:cobbled_deepslate
fill 511 150 294 511 150 297 minecraft:deepslate_tiles
setblock 511 150 298 minecraft:cobbled_deepslate
fill 511 150 299 511 151 301 minecraft:deepslate_tiles
setblock 471 151 276 minecraft:deepslate_tiles
setblock 471 151 277 minecraft:cobbled_deepslate
fill 471 151 278 471 151 281 minecraft:deepslate_tiles
setblock 471 151 282 minecraft:cobbled_deepslate
fill 471 151 283 471 154 283 minecraft:deepslate_tiles
fill 471 151 315 471 151 316 minecraft:deepslate_tiles
setblock 472 151 276 minecraft:cobbled_deepslate
fill 472 151 277 472 151 280 minecraft:deepslate_tiles
setblock 472 151 281 minecraft:cobbled_deepslate
fill 472 151 297 472 157 297 minecraft:black_concrete
setblock 472 151 316 minecraft:cobbled_deepslate
fill 473 151 276 475 151 277 minecraft:deepslate_tiles
setblock 473 151 278 minecraft:light[level=12]
setblock 473 151 285 minecraft:light[level=12]
setblock 473 151 292 minecraft:light[level=12]
setblock 473 151 299 minecraft:light[level=12]
setblock 473 151 306 minecraft:light[level=12]
setblock 473 151 313 minecraft:light[level=12]
fill 473 151 316 476 151 316 minecraft:deepslate_tiles
setblock 475 151 278 minecraft:cobbled_deepslate
fill 475 151 315 477 151 315 minecraft:deepslate_tiles
setblock 476 151 276 minecraft:deepslate_tiles
setblock 476 151 277 minecraft:cobbled_deepslate
fill 476 151 278 479 151 278 minecraft:deepslate_tiles
setblock 477 151 276 minecraft:cobbled_deepslate
fill 477 151 277 480 151 277 minecraft:deepslate_tiles
setblock 477 151 316 minecraft:cobbled_deepslate
fill 478 151 276 481 151 276 minecraft:deepslate_tiles
setblock 478 151 315 minecraft:cobbled_deepslate
fill 478 151 316 481 151 316 minecraft:deepslate_tiles
setblock 479 151 314 minecraft:cobbled_deepslate
fill 479 151 315 482 151 315 minecraft:deepslate_tiles
setblock 480 151 278 minecraft:cobbled_deepslate
setblock 480 151 306 minecraft:light[level=12]
setblock 480 151 313 minecraft:light[level=12]
fill 480 151 314 483 151 314 minecraft:deepslate_tiles
setblock 481 151 277 minecraft:cobbled_deepslate
fill 481 151 278 484 151 278 minecraft:deepslate_tiles
setblock 482 151 276 minecraft:cobbled_deepslate
fill 482 151 277 485 151 277 minecraft:deepslate_tiles
setblock 482 151 316 minecraft:cobbled_deepslate
fill 483 151 276 486 151 276 minecraft:deepslate_tiles
setblock 483 151 315 minecraft:cobbled_deepslate
fill 483 151 316 486 151 316 minecraft:deepslate_tiles
fill 484 151 315 486 151 315 minecraft:deepslate_tiles
setblock 486 151 277 minecraft:cobbled_deepslate
setblock 487 151 276 minecraft:cobbled_deepslate
setblock 487 151 278 minecraft:light[level=12]
setblock 487 151 285 minecraft:light[level=12]
setblock 487 151 292 minecraft:light[level=12]
setblock 487 151 299 minecraft:light[level=12]
setblock 487 151 306 minecraft:light[level=12]
setblock 487 151 313 minecraft:light[level=12]
setblock 487 151 316 minecraft:cobbled_deepslate
fill 488 151 276 489 151 276 minecraft:deepslate_tiles
fill 488 151 316 489 151 316 minecraft:deepslate_tiles
setblock 494 151 278 minecraft:light[level=12]
setblock 494 151 306 minecraft:light[level=12]
setblock 494 151 313 minecraft:light[level=12]
fill 495 151 276 496 151 276 minecraft:deepslate_tiles
setblock 497 151 276 minecraft:cobbled_deepslate
fill 497 151 277 500 151 277 minecraft:deepslate_tiles
fill 498 151 276 501 151 276 minecraft:deepslate_tiles
fill 498 151 316 501 151 316 minecraft:deepslate_tiles
setblock 499 151 278 minecraft:deepslate_tiles
setblock 500 151 278 minecraft:cobbled_deepslate
setblock 501 151 277 minecraft:cobbled_deepslate
fill 501 151 278 503 151 279 minecraft:deepslate_tiles
setblock 501 151 306 minecraft:light[level=12]
setblock 501 151 313 minecraft:light[level=12]
setblock 502 151 276 minecraft:cobbled_deepslate
fill 502 151 277 505 151 277 minecraft:deepslate_tiles
setblock 502 151 316 minecraft:cobbled_deepslate
fill 503 151 276 506 151 276 minecraft:deepslate_tiles
fill 503 151 316 506 151 316 minecraft:deepslate_tiles
setblock 504 151 278 minecraft:deepslate_tiles
setblock 504 151 279 minecraft:cobbled_deepslate
setblock 505 151 278 minecraft:cobbled_deepslate
setblock 505 151 279 minecraft:deepslate_tiles
setblock 506 151 277 minecraft:cobbled_deepslate
fill 506 151 278 509 151 278 minecraft:deepslate_tiles
setblock 507 151 276 minecraft:cobbled_deepslate
fill 507 151 277 510 151 277 minecraft:deepslate_tiles
setblock 507 151 316 minecraft:cobbled_deepslate
fill 508 151 276 508 154 276 minecraft:deepslate_tiles
setblock 508 151 285 minecraft:light[level=12]
setblock 508 151 292 minecraft:light[level=12]
setblock 508 151 299 minecraft:light[level=12]
setblock 508 151 306 minecraft:light[level=12]
setblock 508 151 313 minecraft:light[level=12]
setblock 509 151 279 minecraft:cobbled_deepslate
fill 509 151 280 509 151 281 minecraft:deepslate_tiles
setblock 510 151 278 minecraft:cobbled_deepslate
fill 510 151 279 510 154 279 minecraft:deepslate_tiles
fill 510 151 281 510 151 282 minecraft:deepslate_tiles
setblock 510 151 283 minecraft:cobbled_deepslate
fill 510 151 284 511 152 284 minecraft:deepslate_tiles
setblock 511 151 277 minecraft:cobbled_deepslate
fill 511 151 278 511 154 278 minecraft:deepslate_tiles
setblock 511 151 281 minecraft:deepslate_tiles
setblock 511 151 282 minecraft:cobbled_deepslate
fill 511 151 283 511 154 283 minecraft:deepslate_tiles
fill 511 151 285 511 151 286 minecraft:deepslate_tiles
setblock 511 151 296 minecraft:deepslate_tiles
setblock 511 151 297 minecraft:cobbled_deepslate
setblock 511 151 298 minecraft:deepslate_tiles
setblock 512 151 276 minecraft:white_wool
fill 512 151 277 512 197 277 minecraft:black_concrete
fill 512 151 291 512 159 299 minecraft:black_concrete
setblock 512 151 300 minecraft:white_wool
setblock 471 152 276 minecraft:cobbled_deepslate
fill 471 152 277 471 152 280 minecraft:deepslate_tiles
setblock 471 152 281 minecraft:cobbled_deepslate
fill 471 152 282 471 155 282 minecraft:deepslate_tiles
setblock 471 152 316 minecraft:cobbled_deepslate
fill 472 152 276 472 152 279 minecraft:deepslate_tiles
setblock 472 152 280 minecraft:cobbled_deepslate
setblock 472 152 281 minecraft:deepslate_tiles
fill 472 152 316 475 152 316 minecraft:deepslate_tiles
fill 473 152 276 474 152 277 minecraft:deepslate_tiles
setblock 475 152 276 minecraft:deepslate_tiles
setblock 475 152 277 minecraft:cobbled_deepslate
setblock 476 152 276 minecraft:cobbled_deepslate
fill 476 152 277 478 152 278 minecraft:deepslate_tiles
setblock 476 152 315 minecraft:deepslate_tiles
setblock 476 152 316 minecraft:cobbled_deepslate
fill 477 152 276 480 152 276 minecraft:deepslate_tiles
setblock 477 152 315 minecraft:cobbled_deepslate
fill 477 152 316 480 152 316 minecraft:deepslate_tiles
fill 478 152 315 481 152 315 minecraft:deepslate_tiles
setblock 479 152 277 minecraft:deepslate_tiles
setblock 479 152 278 minecraft:cobbled_deepslate
setblock 480 152 277 minecraft:cobbled_deepslate
fill 480 152 278 482 152 278 minecraft:deepslate_tiles
fill 480 152 314 481 152 314 minecraft:deepslate_tiles
setblock 481 152 276 minecraft:cobbled_deepslate
fill 481 152 277 484 152 277 minecraft:deepslate_tiles
setblock 481 152 316 minecraft:cobbled_deepslate
fill 482 152 276 485 152 276 minecraft:deepslate_tiles
setblock 482 152 315 minecraft:cobbled_deepslate
fill 482 152 316 485 152 316 minecraft:deepslate_tiles
fill 483 152 315 485 152 315 minecraft:deepslate_tiles
setblock 485 152 277 minecraft:cobbled_deepslate
setblock 486 152 276 minecraft:cobbled_deepslate
setblock 486 152 316 minecraft:cobbled_deepslate
setblock 487 152 276 minecraft:deepslate_tiles
setblock 487 152 316 minecraft:deepslate_tiles
setblock 495 152 276 minecraft:deepslate_tiles
setblock 496 152 276 minecraft:cobbled_deepslate
fill 497 152 276 499 152 277 minecraft:deepslate_tiles
setblock 499 152 278 minecraft:cobbled_deepslate
fill 499 152 316 500 152 316 minecraft:deepslate_tiles
setblock 500 152 276 minecraft:deepslate_tiles
setblock 500 152 277 minecraft:cobbled_deepslate
fill 500 152 278 503 152 278 minecraft:deepslate_tiles
setblock 501 152 276 minecraft:cobbled_deepslate
fill 501 152 277 504 152 277 minecraft:deepslate_tiles
fill 501 152 279 502 152 279 minecraft:deepslate_tiles
setblock 501 152 316 minecraft:cobbled_deepslate
fill 502 152 276 505 152 276 minecraft:deepslate_tiles
fill 502 152 316 505 152 316 minecraft:deepslate_tiles
setblock 503 152 279 minecraft:cobbled_deepslate
setblock 504 152 278 minecraft:cobbled_deepslate
setblock 504 152 279 minecraft:deepslate_tiles
setblock 505 152 277 minecraft:cobbled_deepslate
fill 505 152 278 508 152 278 minecraft:deepslate_tiles
setblock 506 152 276 minecraft:cobbled_deepslate
fill 506 152 277 509 152 277 minecraft:deepslate_tiles
fill 507 152 276 507 155 276 minecraft:deepslate_tiles
fill 509 152 276 510 152 276 minecraft:deepslate_tiles
fill 509 152 279 509 152 280 minecraft:deepslate_tiles
setblock 510 152 277 minecraft:cobbled_deepslate
fill 510 152 278 510 154 278 minecraft:deepslate_tiles
setblock 510 152 281 minecraft:deepslate_tiles
setblock 510 152 282 minecraft:cobbled_deepslate
fill 510 152 283 510 155 283 minecraft:deepslate_tiles
setblock 511 152 276 minecraft:cobbled_deepslate
fill 511 152 277 511 155 277 minecraft:deepslate_tiles
setblock 511 152 281 minecraft:cobbled_deepslate
fill 511 152 282 511 155 282 minecraft:deepslate_tiles
setblock 511 152 285 minecraft:deepslate_tiles
setblock 511 152 286 minecraft:cobbled_deepslate
fill 512 152 276 512 201 276 minecraft:black_concrete
fill 512 152 300 512 198 300 minecraft:black_concrete
fill 471 153 276 471 153 279 minecraft:deepslate_tiles
setblock 471 153 280 minecraft:cobbled_deepslate
fill 471 153 281 471 156 281 minecraft:deepslate_tiles
fill 472 153 276 472 153 278 minecraft:deepslate_tiles
setblock 472 153 279 minecraft:cobbled_deepslate
setblock 472 153 280 minecraft:deepslate_tiles
fill 472 153 303 472 155 303 minecraft:black_concrete
fill 472 153 316 474 153 316 minecraft:deepslate_tiles
fill 473 153 276 473 153 277 minecraft:deepslate_tiles
fill 473 153 302 473 155 302 minecraft:black_concrete
fill 473 153 304 473 155 304 minecraft:black_concrete
setblock 474 153 276 minecraft:deepslate_tiles
setblock 474 153 277 minecraft:cobbled_deepslate
fill 474 153 303 474 155 303 minecraft:black_concrete
setblock 475 153 276 minecraft:cobbled_deepslate
fill 475 153 277 478 153 277 minecraft:deepslate_tiles
setblock 475 153 316 minecraft:cobbled_deepslate
fill 476 153 276 479 153 276 minecraft:deepslate_tiles
setblock 476 153 315 minecraft:cobbled_deepslate
fill 476 153 316 479 153 316 minecraft:deepslate_tiles
fill 477 153 315 480 153 315 minecraft:deepslate_tiles
setblock 478 153 278 minecraft:cobbled_deepslate
setblock 479 153 277 minecraft:cobbled_deepslate
fill 479 153 278 481 153 278 minecraft:deepslate_tiles
setblock 480 153 276 minecraft:cobbled_deepslate
fill 480 153 277 483 153 277 minecraft:deepslate_tiles
setblock 480 153 316 minecraft:cobbled_deepslate
fill 481 153 276 484 153 276 minecraft:deepslate_tiles
setblock 481 153 315 minecraft:cobbled_deepslate
fill 481 153 316 484 153 316 minecraft:deepslate_tiles
fill 482 153 315 483 153 315 minecraft:deepslate_tiles
setblock 484 153 277 minecraft:cobbled_deepslate
setblock 485 153 276 minecraft:cobbled_deepslate
setblock 485 153 316 minecraft:cobbled_deepslate
setblock 486 153 316 minecraft:deepslate_tiles
fill 496 153 276 499 153 276 minecraft:deepslate_tiles
fill 497 153 277 498 153 277 minecraft:deepslate_tiles
setblock 499 153 277 minecraft:cobbled_deepslate
fill 499 153 278 502 153 278 minecraft:deepslate_tiles
setblock 500 153 276 minecraft:cobbled_deepslate
fill 500 153 277 503 153 277 minecraft:deepslate_tiles
fill 501 153 276 504 153 276 minecraft:deepslate_tiles
fill 501 153 316 502 153 316 minecraft:deepslate_tiles
setblock 503 153 278 minecraft:cobbled_deepslate
setblock 504 153 277 minecraft:cobbled_deepslate
fill 504 153 278 506 153 278 minecraft:deepslate_tiles
setblock 505 153 276 minecraft:cobbled_deepslate
fill 505 153 277 508 153 277 minecraft:deepslate_tiles
fill 506 153 276 506 155 276 minecraft:deepslate_tiles
setblock 509 153 276 minecraft:deepslate_tiles
setblock 509 153 277 minecraft:cobbled_deepslate
setblock 510 153 276 minecraft:cobbled_deepslate
setblock 510 153 277 minecraft:deepslate_tiles
setblock 510 153 280 minecraft:deepslate_tiles
setblock 510 153 281 minecraft:cobbled_deepslate
fill 510 153 282 510 156 282 minecraft:deepslate_tiles
fill 511 153 276 511 155 276 minecraft:deepslate_tiles
setblock 511 153 280 minecraft:cobbled_deepslate
fill 511 153 281 511 156 281 minecraft:deepslate_tiles
setblock 511 153 284 minecraft:deepslate_tiles
setblock 511 153 285 minecraft:cobbled_deepslate
setblock 470 154 314 minecraft:white_wool
fill 471 154 276 471 154 278 minecraft:deepslate_tiles
setblock 471 154 279 minecraft:cobbled_deepslate
fill 471 154 280 471 157 280 minecraft:deepslate_tiles
fill 472 154 276 473 154 276 minecraft:deepslate_tiles
fill 472 154 302 472 155 302 minecraft:black_concrete
fill 472 154 304 472 155 304 minecraft:black_concrete
setblock 473 154 316 minecraft:deepslate_tiles
setblock 474 154 276 minecraft:cobbled_deepslate
fill 474 154 277 477 154 277 minecraft:deepslate_tiles
fill 474 154 302 474 155 302 minecraft:black_concrete
fill 474 154 304 474 155 304 minecraft:black_concrete
setblock 474 154 316 minecraft:cobbled_deepslate
fill 475 154 276 478 154 276 minecraft:deepslate_tiles
fill 475 154 316 478 154 316 minecraft:deepslate_tiles
fill 477 154 312 477 157 312 minecraft:black_concrete
fill 477 154 315 479 154 315 minecraft:deepslate_tiles
setblock 478 154 277 minecraft:cobbled_deepslate
fill 478 154 311 478 157 311 minecraft:black_concrete
fill 478 154 313 478 157 313 minecraft:black_concrete
setblock 479 154 276 minecraft:cobbled_deepslate
fill 479 154 277 482 154 277 minecraft:deepslate_tiles
fill 479 154 312 479 157 312 minecraft:black_concrete
setblock 479 154 316 minecraft:cobbled_deepslate
fill 480 154 276 483 154 276 minecraft:deepslate_tiles
setblock 480 154 315 minecraft:cobbled_deepslate
fill 480 154 316 483 154 316 minecraft:deepslate_tiles
setblock 481 154 315 minecraft:deepslate_tiles
setblock 484 154 276 minecraft:cobbled_deepslate
setblock 484 154 316 minecraft:cobbled_deepslate
fill 496 154 276 498 154 276 minecraft:deepslate_tiles
setblock 498 154 277 minecraft:cobbled_deepslate
setblock 499 154 276 minecraft:cobbled_deepslate
fill 499 154 277 502 154 277 minecraft:deepslate_tiles
fill 500 154 276 503 154 276 minecraft:deepslate_tiles
fill 500 154 278 501 154 278 minecraft:deepslate_tiles
setblock 502 154 278 minecraft:cobbled_deepslate
setblock 503 154 277 minecraft:cobbled_deepslate
fill 503 154 278 504 154 278 minecraft:deepslate_tiles
setblock 504 154 276 minecraft:cobbled_deepslate
fill 504 154 277 507 154 277 minecraft:deepslate_tiles
fill 505 154 276 505 156 276 minecraft:deepslate_tiles
setblock 509 154 276 minecraft:cobbled_deepslate
fill 510 154 276 510 155 276 minecraft:deepslate_tiles
setblock 510 154 280 minecraft:cobbled_deepslate
fill 510 154 281 510 157 281 minecraft:deepslate_tiles
setblock 511 154 279 minecraft:cobbled_deepslate
fill 511 154 280 511 157 280 minecraft:deepslate_tiles
setblock 511 154 284 minecraft:cobbled_deepslate
fill 511 154 285 511 157 285 minecraft:deepslate_tiles
fill 470 155 314 470 202 314 minecraft:black_concrete
fill 471 155 276 471 155 277 minecraft:deepslate_tiles
setblock 471 155 278 minecraft:cobbled_deepslate
fill 471 155 279 471 158 279 minecraft:deepslate_tiles
setblock 471 155 283 minecraft:cobbled_deepslate
setblock 471 155 303 minecraft:black_concrete
setblock 472 155 276 minecraft:deepslate_tiles
setblock 473 155 276 minecraft:cobbled_deepslate
setblock 473 155 301 minecraft:black_concrete
setblock 473 155 305 minecraft:black_concrete
fill 474 155 276 477 155 276 minecraft:deepslate_tiles
fill 474 155 316 477 155 316 minecraft:deepslate_tiles
setblock 475 155 303 minecraft:black_concrete
setblock 476 155 277 minecraft:deepslate_tiles
setblock 477 155 277 minecraft:cobbled_deepslate
setblock 478 155 276 minecraft:cobbled_deepslate
fill 478 155 277 480 155 277 minecraft:deepslate_tiles
setblock 478 155 315 minecraft:deepslate_tiles
setblock 478 155 316 minecraft:cobbled_deepslate
fill 479 155 276 482 155 276 minecraft:deepslate_tiles
setblock 479 155 315 minecraft:cobbled_deepslate
fill 479 155 316 482 155 316 minecraft:deepslate_tiles
setblock 480 155 315 minecraft:deepslate_tiles
setblock 483 155 316 minecraft:cobbled_deepslate
setblock 497 155 276 minecraft:deepslate_tiles
setblock 498 155 276 minecraft:cobbled_deepslate
fill 498 155 277 501 155 277 minecraft:deepslate_tiles
fill 499 155 276 502 155 276 minecraft:deepslate_tiles
setblock 502 155 277 minecraft:cobbled_deepslate
setblock 503 155 276 minecraft:cobbled_deepslate
fill 503 155 277 505 155 277 minecraft:deepslate_tiles
fill 504 155 276 504 157 276 minecraft:deepslate_tiles
setblock 508 155 276 minecraft:cobbled_deepslate
setblock 509 155 276 minecraft:deepslate_tiles
setblock 510 155 279 minecraft:cobbled_deepslate
setblock 510 155 280 minecraft:deepslate_tiles
setblock 511 155 278 minecraft:cobbled_deepslate
fill 511 155 279 511 158 279 minecraft:deepslate_tiles
setblock 511 155 283 minecraft:cobbled_deepslate
fill 511 155 284 511 158 284 minecraft:deepslate_tiles
fill 471 156 278 471 157 278 minecraft:deepslate_tiles
setblock 471 156 282 minecraft:cobbled_deepslate
fill 471 156 283 471 159 283 minecraft:deepslate_tiles
fill 471 156 297 471 157 297 minecraft:black_concrete
fill 471 156 304 471 156 306 minecraft:deepslate_tiles
setblock 471 156 307 minecraft:cobbled_deepslate
fill 472 156 296 472 157 296 minecraft:black_concrete
fill 472 156 298 472 157 298 minecraft:black_concrete
fill 473 156 276 476 156 276 minecraft:deepslate_tiles
fill 473 156 297 473 157 297 minecraft:black_concrete
fill 474 156 316 476 156 316 minecraft:deepslate_tiles
setblock 477 156 276 minecraft:cobbled_deepslate
setblock 477 156 316 minecraft:cobbled_deepslate
fill 478 156 276 481 156 276 minecraft:deepslate_tiles
fill 478 156 316 481 156 316 minecraft:deepslate_tiles
setblock 479 156 317 minecraft:redstone_block
fill 480 156 317 482 201 317 minecraft:black_concrete
setblock 482 156 316 minecraft:cobbled_deepslate
fill 496 156 312 496 162 312 minecraft:black_concrete
setblock 497 156 276 minecraft:cobbled_deepslate
fill 498 156 276 501 156 276 minecraft:deepslate_tiles
fill 499 156 277 500 156 277 minecraft:deepslate_tiles
setblock 501 156 277 minecraft:cobbled_deepslate
setblock 502 156 276 minecraft:cobbled_deepslate
fill 502 156 277 503 156 277 minecraft:deepslate_tiles
fill 503 156 276 503 158 276 minecraft:deepslate_tiles
setblock 511 156 277 minecraft:cobbled_deepslate
fill 511 156 278 511 159 278 minecraft:deepslate_tiles
setblock 511 156 282 minecraft:cobbled_deepslate
fill 511 156 283 511 159 283 minecraft:deepslate_tiles
setblock 511 156 286 minecraft:deepslate_tiles
setblock 471 157 281 minecraft:cobbled_deepslate
fill 471 157 282 471 160 282 minecraft:deepslate_tiles
fill 471 157 303 471 157 305 minecraft:deepslate_tiles
setblock 471 157 306 minecraft:cobbled_deepslate
fill 471 157 307 471 158 309 minecraft:deepslate_tiles
fill 473 157 276 475 157 276 minecraft:deepslate_tiles
setblock 473 157 278 minecraft:light[level=13]
setblock 473 157 285 minecraft:light[level=12]
setblock 473 157 286 minecraft:light[level=13]
setblock 473 157 292 minecraft:light[level=12]
setblock 473 157 294 minecraft:light[level=13]
setblock 473 157 299 minecraft:light[level=12]
setblock 473 157 302 minecraft:light[level=13]
setblock 473 157 306 minecraft:light[level=12]
setblock 473 157 310 minecraft:light[level=13]
setblock 473 157 313 minecraft:light[level=12]
fill 473 157 316 475 157 316 minecraft:deepslate_tiles
setblock 476 157 276 minecraft:cobbled_deepslate
setblock 476 157 316 minecraft:cobbled_deepslate
fill 477 157 276 480 157 276 minecraft:deepslate_tiles
setblock 477 157 311 minecraft:black_concrete
setblock 477 157 313 minecraft:black_concrete
fill 477 157 316 480 157 316 minecraft:deepslate_tiles
setblock 479 157 311 minecraft:black_concrete
setblock 479 157 313 minecraft:black_concrete
fill 479 157 317 479 197 317 minecraft:black_concrete
setblock 480 157 278 minecraft:light[level=12]
setblock 480 157 285 minecraft:light[level=12]
setblock 480 157 292 minecraft:light[level=12]
setblock 480 157 299 minecraft:light[level=12]
setblock 480 157 306 minecraft:light[level=12]
setblock 480 157 313 minecraft:light[level=12]
setblock 481 157 278 minecraft:light[level=13]
setblock 481 157 286 minecraft:light[level=13]
setblock 481 157 294 minecraft:light[level=13]
setblock 481 157 302 minecraft:light[level=13]
setblock 481 157 310 minecraft:light[level=13]
setblock 481 157 316 minecraft:cobbled_deepslate
setblock 487 157 278 minecraft:light[level=12]
setblock 487 157 285 minecraft:light[level=12]
setblock 487 157 292 minecraft:light[level=12]
setblock 487 157 299 minecraft:light[level=12]
setblock 487 157 306 minecraft:light[level=12]
setblock 487 157 313 minecraft:light[level=12]
setblock 489 157 278 minecraft:light[level=13]
setblock 489 157 286 minecraft:light[level=13]
setblock 489 157 302 minecraft:light[level=13]
setblock 489 157 310 minecraft:light[level=13]
setblock 494 157 278 minecraft:light[level=12]
setblock 494 157 285 minecraft:light[level=12]
setblock 494 157 292 minecraft:light[level=12]
setblock 494 157 299 minecraft:light[level=12]
setblock 494 157 306 minecraft:light[level=12]
setblock 494 157 313 minecraft:light[level=12]
fill 497 157 276 500 157 276 minecraft:deepslate_tiles
setblock 497 157 278 minecraft:light[level=13]
setblock 497 157 286 minecraft:light[level=13]
setblock 497 157 294 minecraft:light[level=13]
setblock 497 157 302 minecraft:light[level=13]
setblock 497 157 310 minecraft:light[level=13]
setblock 499 157 277 minecraft:deepslate_tiles
setblock 500 157 277 minecraft:cobbled_deepslate
setblock 501 157 276 minecraft:cobbled_deepslate
setblock 501 157 277 minecraft:deepslate_tiles
setblock 501 157 278 minecraft:light[level=12]
setblock 501 157 285 minecraft:light[level=12]
setblock 501 157 292 minecraft:light[level=12]
setblock 501 157 299 minecraft:light[level=12]
setblock 501 157 306 minecraft:light[level=12]
setblock 501 157 313 minecraft:light[level=12]
fill 502 157 276 502 160 276 minecraft:deepslate_tiles
setblock 505 157 278 minecraft:light[level=13]
setblock 505 157 286 minecraft:light[level=13]
setblock 505 157 294 minecraft:light[level=13]
setblock 505 157 302 minecraft:light[level=13]
setblock 505 157 310 minecraft:light[level=13]
setblock 508 157 278 minecraft:light[level=12]
setblock 508 157 285 minecraft:light[level=12]
setblock 508 157 292 minecraft:light[level=12]
setblock 508 157 299 minecraft:light[level=12]
setblock 508 157 306 minecraft:light[level=12]
setblock 508 157 313 minecraft:light[level=12]
setblock 510 157 282 minecraft:cobbled_deepslate
fill 510 157 283 510 160 283 minecraft:deepslate_tiles
fill 511 157 277 511 160 277 minecraft:deepslate_tiles
setblock 511 157 281 minecraft:cobbled_deepslate
fill 511 157 282 511 160 282 minecraft:deepslate_tiles
setblock 511 157 286 minecraft:cobbled_deepslate
fill 470 158 277 470 201 277 minecraft:black_concrete
setblock 470 158 278 minecraft:redstone_block
fill 470 158 279 470 199 279 minecraft:black_concrete
setblock 471 158 280 minecraft:cobbled_deepslate
fill 471 158 281 471 161 281 minecraft:deepslate_tiles
setblock 471 158 284 minecraft:deepslate_tiles
fill 471 158 303 471 158 304 minecraft:deepslate_tiles
setblock 471 158 305 minecraft:cobbled_deepslate
fill 471 158 306 472 160 306 minecraft:deepslate_tiles
setblock 471 158 310 minecraft:cobbled_deepslate
fill 471 158 311 471 160 312 minecraft:deepslate_tiles
setblock 472 158 304 minecraft:cobbled_deepslate
fill 472 158 305 472 161 305 minecraft:deepslate_tiles
fill 472 158 307 472 158 308 minecraft:deepslate_tiles
setblock 472 158 309 minecraft:cobbled_deepslate
fill 473 158 316 474 158 316 minecraft:deepslate_tiles
setblock 474 158 276 minecraft:deepslate_tiles
setblock 475 158 276 minecraft:cobbled_deepslate
setblock 475 158 316 minecraft:cobbled_deepslate
fill 476 158 276 479 158 276 minecraft:deepslate_tiles
fill 476 158 292 502 159 293 minecraft:iron_block
setblock 476 158 315 minecraft:cobbled_deepslate
fill 476 158 316 479 158 316 minecraft:deepslate_tiles
fill 477 158 315 478 160 315 minecraft:deepslate_tiles
setblock 480 158 316 minecraft:cobbled_deepslate
setblock 481 158 316 minecraft:deepslate_tiles
fill 497 158 276 499 158 276 minecraft:deepslate_tiles
setblock 500 158 276 minecraft:cobbled_deepslate
fill 501 158 276 501 161 276 minecraft:deepslate_tiles
setblock 510 158 281 minecraft:cobbled_deepslate
fill 510 158 282 510 161 282 minecraft:deepslate_tiles
fill 510 158 284 510 159 284 minecraft:deepslate_tiles
setblock 511 158 280 minecraft:cobbled_deepslate
fill 511 158 281 511 161 281 minecraft:deepslate_tiles
setblock 511 158 285 minecraft:cobbled_deepslate
fill 511 158 286 511 160 287 minecraft:deepslate_tiles
fill 470 159 278 470 201 278 minecraft:black_concrete
setblock 471 159 279 minecraft:cobbled_deepslate
fill 471 159 280 471 162 280 minecraft:deepslate_tiles
setblock 471 159 284 minecraft:cobbled_deepslate
fill 471 159 285 471 161 286 minecraft:deepslate_tiles
fill 471 159 302 471 159 303 minecraft:deepslate_tiles
setblock 471 159 304 minecraft:cobbled_deepslate
fill 471 159 305 471 162 305 minecraft:deepslate_tiles
fill 471 159 307 471 159 308 minecraft:deepslate_tiles
setblock 471 159 309 minecraft:cobbled_deepslate
fill 471 159 310 473 160 310 minecraft:deepslate_tiles
setblock 471 159 313 minecraft:deepslate_tiles
setblock 471 159 314 minecraft:cobbled_deepslate
fill 471 159 315 471 161 316 minecraft:deepslate_tiles
setblock 472 159 303 minecraft:cobbled_deepslate
fill 472 159 304 472 162 304 minecraft:deepslate_tiles
setblock 472 159 307 minecraft:deepslate_tiles
setblock 472 159 308 minecraft:cobbled_deepslate
fill 472 159 309 473 161 309 minecraft:deepslate_tiles
fill 472 159 311 472 159 312 minecraft:deepslate_tiles
fill 472 159 316 473 159 316 minecraft:deepslate_tiles
setblock 473 159 276 minecraft:deepslate_tiles
fill 473 159 305 473 159 306 minecraft:deepslate_tiles
setblock 473 159 307 minecraft:cobbled_deepslate
fill 473 159 308 473 162 308 minecraft:deepslate_tiles
setblock 474 159 276 minecraft:cobbled_deepslate
setblock 474 159 315 minecraft:deepslate_tiles
setblock 474 159 316 minecraft:cobbled_deepslate
fill 475 159 276 478 159 276 minecraft:deepslate_tiles
setblock 475 159 315 minecraft:cobbled_deepslate
fill 475 159 316 478 159 316 minecraft:deepslate_tiles
fill 476 159 315 476 162 315 minecraft:deepslate_tiles
setblock 479 159 316 minecraft:cobbled_deepslate
fill 480 159 316 480 162 316 minecraft:deepslate_tiles
fill 496 159 276 498 159 276 minecraft:deepslate_tiles
setblock 499 159 276 minecraft:cobbled_deepslate
fill 500 159 276 500 162 276 minecraft:deepslate_tiles
fill 510 159 281 510 162 281 minecraft:deepslate_tiles
setblock 510 159 285 minecraft:cobbled_deepslate
fill 511 159 276 511 161 276 minecraft:deepslate_tiles
setblock 511 159 279 minecraft:cobbled_deepslate
fill 511 159 280 511 162 280 minecraft:deepslate_tiles
setblock 511 159 284 minecraft:cobbled_deepslate
fill 511 159 285 511 162 285 minecraft:deepslate_tiles
setblock 511 159 288 minecraft:deepslate_tiles
fill 511 159 305 511 159 308 minecraft:deepslate_tiles
setblock 511 159 309 minecraft:cobbled_deepslate
setblock 471 160 278 minecraft:cobbled_deepslate
fill 471 160 279 471 163 279 minecraft:deepslate_tiles
setblock 471 160 283 minecraft:cobbled_deepslate
fill 471 160 284 472 162 284 minecraft:deepslate_tiles
setblock 471 160 287 minecraft:deepslate_tiles
setblock 471 160 288 minecraft:cobbled_deepslate
fill 471 160 301 471 160 302 minecraft:deepslate_tiles
setblock 471 160 303 minecraft:cobbled_deepslate
fill 471 160 304 471 163 304 minecraft:deepslate_tiles
setblock 471 160 307 minecraft:deepslate_tiles
setblock 471 160 308 minecraft:cobbled_deepslate
fill 471 160 309 471 163 309 minecraft:deepslate_tiles
setblock 471 160 313 minecraft:cobbled_deepslate
fill 471 160 314 472 162 314 minecraft:deepslate_tiles
setblock 472 160 276 minecraft:deepslate_tiles
fill 472 160 303 472 163 303 minecraft:deepslate_tiles
setblock 472 160 307 minecraft:cobbled_deepslate
fill 472 160 308 472 163 308 minecraft:deepslate_tiles
setblock 472 160 311 minecraft:deepslate_tiles
setblock 472 160 312 minecraft:cobbled_deepslate
fill 472 160 313 472 163 313 minecraft:deepslate_tiles
setblock 472 160 316 minecraft:deepslate_tiles
setblock 473 160 276 minecraft:cobbled_deepslate
fill 473 160 304 473 160 305 minecraft:deepslate_tiles
setblock 473 160 306 minecraft:cobbled_deepslate
fill 473 160 307 474 162 307 minecraft:deepslate_tiles
setblock 473 160 311 minecraft:cobbled_deepslate
fill 473 160 312 473 163 312 minecraft:deepslate_tiles
setblock 473 160 315 minecraft:deepslate_tiles
setblock 473 160 316 minecraft:cobbled_deepslate
fill 474 160 276 477 160 276 minecraft:deepslate_tiles
fill 474 160 306 474 163 306 minecraft:deepslate_tiles
fill 474 160 308 474 160 309 minecraft:deepslate_tiles
setblock 474 160 315 minecraft:cobbled_deepslate
fill 474 160 316 477 160 316 minecraft:deepslate_tiles
fill 475 160 315 475 163 315 minecraft:deepslate_tiles
fill 476 160 314 476 163 314 minecraft:deepslate_tiles
setblock 478 160 276 minecraft:cobbled_deepslate
setblock 478 160 316 minecraft:cobbled_deepslate
setblock 479 160 315 minecraft:cobbled_deepslate
fill 479 160 316 479 163 316 minecraft:deepslate_tiles
fill 495 160 276 497 160 276 minecraft:deepslate_tiles
fill 495 160 312 495 162 312 minecraft:black_concrete
fill 496 160 311 496 162 311 minecraft:black_concrete
fill 496 160 313 496 162 313 minecraft:black_concrete
fill 497 160 312 497 162 312 minecraft:black_concrete
setblock 498 160 276 minecraft:cobbled_deepslate
fill 498 160 277 499 162 277 minecraft:deepslate_tiles
fill 499 160 276 499 163 276 minecraft:deepslate_tiles
setblock 503 160 275 minecraft:white_wool
fill 510 160 276 510 162 276 minecraft:deepslate_tiles
fill 510 160 280 510 163 280 minecraft:deepslate_tiles
setblock 510 160 284 minecraft:cobbled_deepslate
fill 510 160 285 510 162 286 minecraft:deepslate_tiles
setblock 511 160 278 minecraft:cobbled_deepslate
fill 511 160 279 511 163 279 minecraft:deepslate_tiles
setblock 511 160 283 minecraft:cobbled_deepslate
fill 511 160 284 511 163 284 minecraft:deepslate_tiles
setblock 511 160 288 minecraft:cobbled_deepslate
fill 511 160 289 511 163 289 minecraft:deepslate_tiles
fill 511 160 304 511 160 307 minecraft:deepslate_tiles
setblock 511 160 308 minecraft:cobbled_deepslate
fill 511 160 309 511 160 312 minecraft:deepslate_tiles
setblock 511 160 313 minecraft:cobbled_deepslate
fill 512 160 291 512 191 294 minecraft:black_concrete
setblock 512 160 295 minecraft:white_wool
fill 512 160 296 512 166 299 minecraft:black_concrete
setblock 471 161 276 minecraft:deepslate_tiles
setblock 471 161 277 minecraft:cobbled_deepslate
fill 471 161 278 471 164 278 minecraft:deepslate_tiles
setblock 471 161 282 minecraft:cobbled_deepslate
fill 471 161 283 472 163 283 minecraft:deepslate_tiles
setblock 471 161 287 minecraft:cobbled_deepslate
fill 471 161 288 471 162 290 minecraft:deepslate_tiles
setblock 471 161 301 minecraft:deepslate_tiles
setblock 471 161 302 minecraft:cobbled_deepslate
fill 471 161 303 471 164 303 minecraft:deepslate_tiles
setblock 471 161 306 minecraft:deepslate_tiles
setblock 471 161 307 minecraft:cobbled_deepslate
fill 471 161 308 471 164 308 minecraft:deepslate_tiles
fill 471 161 310 471 161 311 minecraft:deepslate_tiles
setblock 471 161 312 minecraft:cobbled_deepslate
fill 471 161 313 471 164 313 minecraft:deepslate_tiles
setblock 472 161 276 minecraft:cobbled_deepslate
fill 472 161 282 472 163 282 minecraft:deepslate_tiles
setblock 472 161 285 minecraft:deepslate_tiles
setblock 472 161 286 minecraft:cobbled_deepslate
fill 472 161 287 472 164 287 minecraft:deepslate_tiles
fill 472 161 302 472 164 302 minecraft:deepslate_tiles
setblock 472 161 306 minecraft:cobbled_deepslate
fill 472 161 307 472 164 307 minecraft:deepslate_tiles
setblock 472 161 310 minecraft:deepslate_tiles
setblock 472 161 311 minecraft:cobbled_deepslate
fill 472 161 312 472 164 312 minecraft:deepslate_tiles
setblock 472 161 315 minecraft:deepslate_tiles
setblock 472 161 316 minecraft:cobbled_deepslate
fill 473 161 276 476 161 276 minecraft:deepslate_tiles
fill 473 161 303 473 161 304 minecraft:deepslate_tiles
setblock 473 161 305 minecraft:cobbled_deepslate
fill 473 161 306 473 164 306 minecraft:deepslate_tiles
setblock 473 161 310 minecraft:cobbled_deepslate
fill 473 161 311 474 163 311 minecraft:deepslate_tiles
fill 473 161 313 473 161 314 minecraft:deepslate_tiles
setblock 473 161 315 minecraft:cobbled_deepslate
fill 473 161 316 476 161 316 minecraft:deepslate_tiles
fill 474 161 305 474 164 305 minecraft:deepslate_tiles
setblock 474 161 308 minecraft:deepslate_tiles
setblock 474 161 309 minecraft:cobbled_deepslate
fill 474 161 310 474 164 310 minecraft:deepslate_tiles
fill 474 161 312 474 162 312 minecraft:deepslate_tiles
setblock 474 161 314 minecraft:cobbled_deepslate
fill 474 161 315 474 164 315 minecraft:deepslate_tiles
fill 475 161 314 475 164 314 minecraft:deepslate_tiles
setblock 476 161 317 minecraft:redstone_block
setblock 477 161 276 minecraft:cobbled_deepslate
fill 477 161 314 477 161 315 minecraft:deepslate_tiles
setblock 477 161 316 minecraft:cobbled_deepslate
setblock 478 161 276 minecraft:deepslate_tiles
setblock 478 161 314 minecraft:deepslate_tiles
setblock 478 161 315 minecraft:cobbled_deepslate
fill 478 161 316 478 164 316 minecraft:deepslate_tiles
fill 479 161 315 479 164 315 minecraft:deepslate_tiles
setblock 481 161 316 minecraft:deepslate_tiles
fill 486 161 309 486 177 309 minecraft:white_wool
fill 488 161 288 490 162 288 minecraft:white_wool
fill 489 161 287 489 162 287 minecraft:white_wool
fill 494 161 276 496 161 276 minecraft:deepslate_tiles
setblock 497 161 276 minecraft:cobbled_deepslate
fill 497 161 277 497 164 277 minecraft:deepslate_tiles
fill 498 161 276 498 164 276 minecraft:deepslate_tiles
setblock 502 161 276 minecraft:cobbled_deepslate
fill 503 161 275 503 201 275 minecraft:black_concrete
fill 509 161 276 509 163 276 minecraft:deepslate_tiles
setblock 510 161 283 minecraft:cobbled_deepslate
fill 510 161 284 510 164 284 minecraft:deepslate_tiles
setblock 510 161 287 minecraft:deepslate_tiles
setblock 510 161 288 minecraft:cobbled_deepslate
setblock 511 161 277 minecraft:cobbled_deepslate
fill 511 161 278 511 164 278 minecraft:deepslate_tiles
setblock 511 161 282 minecraft:cobbled_deepslate
fill 511 161 283 511 164 283 minecraft:deepslate_tiles
setblock 511 161 286 minecraft:deepslate_tiles
setblock 511 161 287 minecraft:cobbled_deepslate
fill 511 161 288 511 164 288 minecraft:deepslate_tiles
fill 511 161 290 511 161 291 minecraft:deepslate_tiles
fill 511 161 303 511 161 306 minecraft:deepslate_tiles
setblock 511 161 307 minecraft:cobbled_deepslate
fill 511 161 308 511 161 311 minecraft:deepslate_tiles
setblock 511 161 312 minecraft:cobbled_deepslate
fill 511 161 313 511 161 316 minecraft:deepslate_tiles
fill 512 161 295 512 201 295 minecraft:black_concrete
setblock 471 162 276 minecraft:cobbled_deepslate
fill 471 162 277 471 165 277 minecraft:deepslate_tiles
setblock 471 162 281 minecraft:cobbled_deepslate
fill 471 162 282 471 165 282 minecraft:deepslate_tiles
setblock 471 162 285 minecraft:deepslate_tiles
setblock 471 162 286 minecraft:cobbled_deepslate
fill 471 162 287 471 165 287 minecraft:deepslate_tiles
setblock 471 162 291 minecraft:cobbled_deepslate
fill 471 162 292 471 165 292 minecraft:deepslate_tiles
setblock 471 162 300 minecraft:deepslate_tiles
setblock 471 162 301 minecraft:cobbled_deepslate
fill 471 162 302 471 165 302 minecraft:deepslate_tiles
setblock 471 162 306 minecraft:cobbled_deepslate
fill 471 162 307 471 165 307 minecraft:deepslate_tiles
setblock 471 162 310 minecraft:deepslate_tiles
setblock 471 162 311 minecraft:cobbled_deepslate
fill 471 162 312 471 165 312 minecraft:deepslate_tiles
setblock 471 162 315 minecraft:deepslate_tiles
setblock 471 162 316 minecraft:cobbled_deepslate
fill 472 162 276 475 162 276 minecraft:deepslate_tiles
setblock 472 162 285 minecraft:cobbled_deepslate
fill 472 162 286 472 165 286 minecraft:deepslate_tiles
fill 472 162 288 472 162 289 minecraft:deepslate_tiles
fill 472 162 301 472 165 301 minecraft:deepslate_tiles
setblock 472 162 305 minecraft:cobbled_deepslate
fill 472 162 306 472 165 306 minecraft:deepslate_tiles
setblock 472 162 309 minecraft:deepslate_tiles
setblock 472 162 310 minecraft:cobbled_deepslate
fill 472 162 311 472 165 311 minecraft:deepslate_tiles
setblock 472 162 315 minecraft:cobbled_deepslate
fill 472 162 316 475 162 316 minecraft:deepslate_tiles
setblock 473 162 303 minecraft:deepslate_tiles
setblock 473 162 304 minecraft:cobbled_deepslate
fill 473 162 305 473 165 305 minecraft:deepslate_tiles
setblock 473 162 309 minecraft:cobbled_deepslate
fill 473 162 310 473 165 310 minecraft:deepslate_tiles
setblock 473 162 313 minecraft:deepslate_tiles
setblock 473 162 314 minecraft:cobbled_deepslate
fill 473 162 315 473 165 315 minecraft:deepslate_tiles
fill 474 162 304 474 164 304 minecraft:deepslate_tiles
setblock 474 162 308 minecraft:cobbled_deepslate
fill 474 162 309 475 164 309 minecraft:deepslate_tiles
setblock 474 162 313 minecraft:cobbled_deepslate
fill 474 162 314 474 165 314 minecraft:deepslate_tiles
setblock 475 162 307 minecraft:cobbled_deepslate
fill 475 162 308 475 165 308 minecraft:deepslate_tiles
fill 475 162 310 475 163 310 minecraft:deepslate_tiles
fill 475 162 313 476 164 313 minecraft:deepslate_tiles
setblock 476 162 276 minecraft:cobbled_deepslate
setblock 476 162 316 minecraft:cobbled_deepslate
fill 476 162 317 476 201 317 minecraft:black_concrete
fill 477 162 276 477 164 276 minecraft:deepslate_tiles
setblock 477 162 314 minecraft:deepslate_tiles
setblock 477 162 315 minecraft:cobbled_deepslate
fill 477 162 316 477 165 316 minecraft:deepslate_tiles
setblock 478 162 314 minecraft:cobbled_deepslate
fill 478 162 315 478 165 315 minecraft:deepslate_tiles
setblock 481 162 316 minecraft:cobbled_deepslate
fill 493 162 276 495 162 276 minecraft:deepslate_tiles
fill 494 162 316 495 162 316 minecraft:deepslate_tiles
setblock 495 162 311 minecraft:black_concrete
setblock 495 162 313 minecraft:black_concrete
setblock 496 162 276 minecraft:cobbled_deepslate
fill 496 162 277 496 165 277 minecraft:deepslate_tiles
setblock 496 162 316 minecraft:cobbled_deepslate
fill 497 162 276 497 165 276 minecraft:deepslate_tiles
setblock 497 162 311 minecraft:black_concrete
setblock 497 162 313 minecraft:black_concrete
fill 497 162 316 499 163 316 minecraft:deepslate_tiles
setblock 501 162 276 minecraft:cobbled_deepslate
fill 502 162 276 503 164 276 minecraft:deepslate_tiles
fill 508 162 276 508 164 276 minecraft:deepslate_tiles
fill 509 162 316 510 162 316 minecraft:deepslate_tiles
fill 510 162 279 510 164 279 minecraft:deepslate_tiles
setblock 510 162 282 minecraft:cobbled_deepslate
fill 510 162 283 510 165 283 minecraft:deepslate_tiles
setblock 510 162 287 minecraft:cobbled_deepslate
fill 510 162 288 510 164 289 minecraft:deepslate_tiles
setblock 510 162 307 minecraft:cobbled_deepslate
fill 510 162 308 510 162 311 minecraft:deepslate_tiles
setblock 510 162 312 minecraft:cobbled_deepslate
fill 510 162 313 511 164 313 minecraft:deepslate_tiles
setblock 511 162 276 minecraft:cobbled_deepslate
fill 511 162 277 511 165 277 minecraft:deepslate_tiles
setblock 511 162 281 minecraft:cobbled_deepslate
fill 511 162 282 511 165 282 minecraft:deepslate_tiles
setblock 511 162 286 minecraft:cobbled_deepslate
fill 511 162 287 511 165 287 minecraft:deepslate_tiles
setblock 511 162 290 minecraft:deepslate_tiles
setblock 511 162 291 minecraft:cobbled_deepslate
fill 511 162 292 511 165 292 minecraft:deepslate_tiles
fill 511 162 303 511 162 305 minecraft:deepslate_tiles
setblock 511 162 306 minecraft:cobbled_deepslate
schedule function dropper:buildpart/70_7 1t
