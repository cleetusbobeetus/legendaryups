setblock 509 290 295 minecraft:cobbled_deepslate
setblock 509 290 315 minecraft:cobbled_deepslate
fill 509 290 316 509 293 316 minecraft:deepslate_tiles
setblock 510 290 278 minecraft:deepslate_tiles
setblock 510 290 284 minecraft:cobbled_deepslate
fill 510 290 285 510 291 285 minecraft:deepslate_tiles
setblock 510 290 289 minecraft:cobbled_deepslate
fill 510 290 290 510 293 290 minecraft:deepslate_tiles
setblock 510 290 294 minecraft:cobbled_deepslate
fill 510 290 295 510 293 295 minecraft:deepslate_tiles
setblock 510 290 314 minecraft:cobbled_deepslate
fill 510 290 315 510 293 315 minecraft:deepslate_tiles
setblock 511 290 278 minecraft:cobbled_deepslate
fill 511 290 279 511 293 279 minecraft:deepslate_tiles
setblock 511 290 283 minecraft:cobbled_deepslate
fill 511 290 284 511 293 284 minecraft:deepslate_tiles
setblock 511 290 288 minecraft:cobbled_deepslate
fill 511 290 289 511 293 289 minecraft:deepslate_tiles
setblock 511 290 293 minecraft:cobbled_deepslate
fill 511 290 294 511 293 294 minecraft:deepslate_tiles
setblock 511 290 313 minecraft:cobbled_deepslate
fill 511 290 314 511 293 314 minecraft:deepslate_tiles
fill 470 291 288 470 292 289 minecraft:deepslate_tiles
setblock 470 291 290 minecraft:white_wool
setblock 471 291 276 minecraft:deepslate_tiles
setblock 471 291 277 minecraft:cobbled_deepslate
fill 471 291 278 471 294 278 minecraft:deepslate_tiles
setblock 471 291 288 minecraft:deepslate_tiles
setblock 471 291 292 minecraft:cobbled_deepslate
fill 471 291 293 471 294 293 minecraft:deepslate_tiles
setblock 471 291 312 minecraft:cobbled_deepslate
fill 471 291 313 471 294 313 minecraft:deepslate_tiles
setblock 472 291 276 minecraft:cobbled_deepslate
fill 472 291 312 472 294 312 minecraft:deepslate_tiles
setblock 472 291 316 minecraft:cobbled_deepslate
fill 473 291 276 473 294 276 minecraft:deepslate_tiles
setblock 473 291 315 minecraft:cobbled_deepslate
fill 473 291 316 476 291 316 minecraft:deepslate_tiles
fill 474 291 315 477 291 315 minecraft:deepslate_tiles
setblock 476 291 276 minecraft:deepslate_tiles
setblock 477 291 276 minecraft:cobbled_deepslate
setblock 477 291 316 minecraft:cobbled_deepslate
fill 478 291 276 481 291 276 minecraft:deepslate_tiles
setblock 478 291 315 minecraft:cobbled_deepslate
fill 478 291 316 481 291 316 minecraft:deepslate_tiles
setblock 479 291 314 minecraft:cobbled_deepslate
fill 479 291 315 482 291 315 minecraft:deepslate_tiles
fill 480 291 314 483 291 314 minecraft:deepslate_tiles
setblock 482 291 276 minecraft:cobbled_deepslate
setblock 482 291 316 minecraft:cobbled_deepslate
fill 483 291 276 483 294 276 minecraft:deepslate_tiles
fill 483 291 313 483 292 313 minecraft:deepslate_tiles
setblock 483 291 315 minecraft:cobbled_deepslate
fill 483 291 316 486 291 316 minecraft:deepslate_tiles
setblock 484 291 314 minecraft:cobbled_deepslate
fill 484 291 315 484 294 315 minecraft:deepslate_tiles
setblock 485 291 313 minecraft:cobbled_deepslate
fill 485 291 314 485 294 314 minecraft:deepslate_tiles
setblock 486 291 276 minecraft:deepslate_tiles
fill 486 291 313 486 293 313 minecraft:deepslate_tiles
setblock 487 291 276 minecraft:cobbled_deepslate
setblock 487 291 316 minecraft:cobbled_deepslate
fill 488 291 276 488 294 276 minecraft:deepslate_tiles
setblock 488 291 315 minecraft:cobbled_deepslate
fill 488 291 316 488 294 316 minecraft:deepslate_tiles
setblock 489 291 314 minecraft:cobbled_deepslate
fill 489 291 315 489 294 315 minecraft:deepslate_tiles
setblock 492 291 316 minecraft:cobbled_deepslate
fill 493 291 316 493 294 316 minecraft:deepslate_tiles
fill 500 291 316 501 291 316 minecraft:deepslate_tiles
setblock 501 291 276 minecraft:deepslate_tiles
setblock 502 291 276 minecraft:cobbled_deepslate
setblock 502 291 316 minecraft:cobbled_deepslate
fill 503 291 276 503 293 277 minecraft:deepslate_tiles
setblock 503 291 315 minecraft:cobbled_deepslate
fill 503 291 316 503 294 316 minecraft:deepslate_tiles
fill 504 291 277 505 291 277 minecraft:deepslate_tiles
fill 504 291 315 507 291 315 minecraft:deepslate_tiles
setblock 506 291 277 minecraft:cobbled_deepslate
setblock 507 291 276 minecraft:cobbled_deepslate
fill 507 291 277 507 294 277 minecraft:deepslate_tiles
setblock 507 291 316 minecraft:cobbled_deepslate
fill 508 291 276 508 294 276 minecraft:deepslate_tiles
setblock 508 291 315 minecraft:cobbled_deepslate
fill 508 291 316 508 294 316 minecraft:deepslate_tiles
fill 509 291 277 510 291 277 minecraft:deepslate_tiles
setblock 509 291 289 minecraft:cobbled_deepslate
fill 509 291 290 509 293 290 minecraft:deepslate_tiles
setblock 509 291 294 minecraft:cobbled_deepslate
fill 509 291 295 509 294 295 minecraft:deepslate_tiles
fill 509 291 315 509 294 315 minecraft:deepslate_tiles
setblock 510 291 278 minecraft:cobbled_deepslate
fill 510 291 279 510 293 280 minecraft:deepslate_tiles
setblock 510 291 288 minecraft:cobbled_deepslate
fill 510 291 289 510 294 289 minecraft:deepslate_tiles
setblock 510 291 293 minecraft:cobbled_deepslate
fill 510 291 294 510 294 294 minecraft:deepslate_tiles
setblock 510 291 313 minecraft:cobbled_deepslate
fill 510 291 314 510 294 314 minecraft:deepslate_tiles
setblock 511 291 277 minecraft:cobbled_deepslate
fill 511 291 278 511 294 278 minecraft:deepslate_tiles
setblock 511 291 282 minecraft:cobbled_deepslate
fill 511 291 283 511 294 283 minecraft:deepslate_tiles
setblock 511 291 287 minecraft:cobbled_deepslate
fill 511 291 288 511 294 288 minecraft:deepslate_tiles
setblock 511 291 292 minecraft:cobbled_deepslate
fill 511 291 293 511 294 293 minecraft:deepslate_tiles
setblock 511 291 297 minecraft:cobbled_deepslate
fill 511 291 298 511 294 298 minecraft:deepslate_tiles
setblock 511 291 312 minecraft:cobbled_deepslate
fill 511 291 313 511 294 313 minecraft:deepslate_tiles
setblock 470 292 286 minecraft:white_wool
fill 470 292 290 470 308 290 minecraft:deepslate_tiles
setblock 471 292 276 minecraft:cobbled_deepslate
fill 471 292 277 472 294 277 minecraft:deepslate_tiles
setblock 471 292 291 minecraft:cobbled_deepslate
fill 471 292 292 471 294 292 minecraft:deepslate_tiles
setblock 471 292 296 minecraft:cobbled_deepslate
setblock 471 292 311 minecraft:cobbled_deepslate
fill 471 292 312 471 295 312 minecraft:deepslate_tiles
setblock 471 292 315 minecraft:deepslate_tiles
setblock 471 292 316 minecraft:cobbled_deepslate
fill 472 292 276 472 295 276 minecraft:deepslate_tiles
setblock 472 292 315 minecraft:cobbled_deepslate
fill 472 292 316 475 292 316 minecraft:deepslate_tiles
fill 473 292 315 476 292 315 minecraft:deepslate_tiles
setblock 476 292 276 minecraft:cobbled_deepslate
setblock 476 292 316 minecraft:cobbled_deepslate
fill 477 292 276 480 292 276 minecraft:deepslate_tiles
setblock 477 292 315 minecraft:cobbled_deepslate
fill 477 292 316 480 292 316 minecraft:deepslate_tiles
setblock 478 292 314 minecraft:cobbled_deepslate
fill 478 292 315 481 292 315 minecraft:deepslate_tiles
fill 479 292 314 482 292 314 minecraft:deepslate_tiles
setblock 481 292 276 minecraft:cobbled_deepslate
setblock 481 292 316 minecraft:cobbled_deepslate
fill 482 292 276 482 295 276 minecraft:deepslate_tiles
fill 482 292 313 482 293 313 minecraft:deepslate_tiles
setblock 482 292 315 minecraft:cobbled_deepslate
fill 482 292 316 485 292 316 minecraft:deepslate_tiles
fill 483 292 277 484 292 277 minecraft:deepslate_tiles
setblock 483 292 314 minecraft:cobbled_deepslate
fill 483 292 315 483 295 315 minecraft:deepslate_tiles
setblock 484 292 313 minecraft:cobbled_deepslate
fill 484 292 314 484 295 314 minecraft:deepslate_tiles
setblock 485 292 277 minecraft:cobbled_deepslate
fill 485 292 313 485 294 313 minecraft:deepslate_tiles
setblock 486 292 276 minecraft:cobbled_deepslate
fill 486 292 277 486 295 277 minecraft:deepslate_tiles
setblock 486 292 316 minecraft:cobbled_deepslate
fill 487 292 276 487 295 276 minecraft:deepslate_tiles
setblock 487 292 315 minecraft:cobbled_deepslate
fill 487 292 316 487 295 316 minecraft:deepslate_tiles
setblock 488 292 314 minecraft:cobbled_deepslate
fill 488 292 315 488 295 315 minecraft:deepslate_tiles
fill 489 292 314 489 293 314 minecraft:deepslate_tiles
setblock 490 292 276 minecraft:deepslate_tiles
setblock 491 292 316 minecraft:cobbled_deepslate
fill 492 292 316 492 295 316 minecraft:deepslate_tiles
fill 497 292 303 498 293 303 minecraft:white_wool
fill 499 292 276 500 292 276 minecraft:deepslate_tiles
fill 499 292 316 500 292 316 minecraft:deepslate_tiles
setblock 501 292 276 minecraft:cobbled_deepslate
setblock 501 292 316 minecraft:cobbled_deepslate
fill 502 292 276 502 294 277 minecraft:deepslate_tiles
setblock 502 292 315 minecraft:cobbled_deepslate
fill 502 292 316 502 295 316 minecraft:deepslate_tiles
fill 503 292 315 506 292 315 minecraft:deepslate_tiles
setblock 504 292 277 minecraft:deepslate_tiles
setblock 505 292 277 minecraft:cobbled_deepslate
fill 505 292 278 508 292 278 minecraft:deepslate_tiles
setblock 506 292 276 minecraft:cobbled_deepslate
fill 506 292 277 506 295 277 minecraft:deepslate_tiles
setblock 506 292 316 minecraft:cobbled_deepslate
fill 507 292 276 507 295 276 minecraft:deepslate_tiles
setblock 507 292 315 minecraft:cobbled_deepslate
fill 507 292 316 507 295 316 minecraft:deepslate_tiles
fill 508 292 315 508 295 315 minecraft:deepslate_tiles
setblock 509 292 277 minecraft:deepslate_tiles
setblock 509 292 278 minecraft:cobbled_deepslate
setblock 509 292 289 minecraft:deepslate_tiles
setblock 509 292 293 minecraft:cobbled_deepslate
fill 509 292 294 509 294 294 minecraft:deepslate_tiles
setblock 510 292 276 minecraft:deepslate_tiles
setblock 510 292 277 minecraft:cobbled_deepslate
fill 510 292 278 510 295 278 minecraft:deepslate_tiles
setblock 510 292 281 minecraft:deepslate_tiles
setblock 510 292 287 minecraft:cobbled_deepslate
fill 510 292 288 510 293 288 minecraft:deepslate_tiles
setblock 510 292 292 minecraft:cobbled_deepslate
fill 510 292 293 510 295 293 minecraft:deepslate_tiles
setblock 510 292 297 minecraft:cobbled_deepslate
fill 510 292 313 510 293 313 minecraft:deepslate_tiles
setblock 511 292 276 minecraft:cobbled_deepslate
fill 511 292 277 511 295 277 minecraft:deepslate_tiles
setblock 511 292 281 minecraft:cobbled_deepslate
fill 511 292 282 511 295 282 minecraft:deepslate_tiles
setblock 511 292 286 minecraft:cobbled_deepslate
fill 511 292 287 511 295 287 minecraft:deepslate_tiles
setblock 511 292 291 minecraft:cobbled_deepslate
fill 511 292 292 511 295 292 minecraft:deepslate_tiles
setblock 511 292 296 minecraft:cobbled_deepslate
fill 511 292 297 511 295 297 minecraft:deepslate_tiles
setblock 511 292 311 minecraft:cobbled_deepslate
fill 511 292 312 511 295 312 minecraft:deepslate_tiles
setblock 511 292 316 minecraft:cobbled_deepslate
setblock 512 292 294 minecraft:white_wool
fill 512 292 295 512 308 295 minecraft:deepslate_tiles
fill 470 293 286 470 308 286 minecraft:deepslate_tiles
setblock 470 293 288 minecraft:redstone_block
fill 470 293 289 470 308 289 minecraft:deepslate_tiles
fill 471 293 276 471 296 276 minecraft:deepslate_tiles
setblock 471 293 280 minecraft:cobbled_deepslate
fill 471 293 281 471 296 281 minecraft:deepslate_tiles
setblock 471 293 291 minecraft:deepslate_tiles
setblock 471 293 294 minecraft:deepslate_tiles
setblock 471 293 295 minecraft:cobbled_deepslate
fill 471 293 296 471 295 297 minecraft:deepslate_tiles
setblock 471 293 310 minecraft:cobbled_deepslate
fill 471 293 311 471 296 311 minecraft:deepslate_tiles
setblock 471 293 315 minecraft:cobbled_deepslate
fill 471 293 316 474 293 316 minecraft:deepslate_tiles
setblock 472 293 314 minecraft:cobbled_deepslate
fill 472 293 315 475 293 315 minecraft:deepslate_tiles
setblock 473 293 278 minecraft:light[level=13]
setblock 473 293 286 minecraft:light[level=13]
setblock 473 293 294 minecraft:light[level=13]
setblock 473 293 302 minecraft:light[level=13]
setblock 473 293 310 minecraft:light[level=13]
setblock 474 293 276 minecraft:deepslate_tiles
setblock 475 293 276 minecraft:cobbled_deepslate
setblock 475 293 316 minecraft:cobbled_deepslate
fill 476 293 276 479 293 276 minecraft:deepslate_tiles
setblock 476 293 315 minecraft:cobbled_deepslate
fill 476 293 316 479 293 316 minecraft:deepslate_tiles
setblock 477 293 314 minecraft:cobbled_deepslate
fill 477 293 315 480 293 315 minecraft:deepslate_tiles
fill 478 293 314 481 293 314 minecraft:deepslate_tiles
setblock 480 293 276 minecraft:cobbled_deepslate
fill 480 293 277 483 293 277 minecraft:deepslate_tiles
setblock 480 293 316 minecraft:cobbled_deepslate
fill 481 293 276 481 296 276 minecraft:deepslate_tiles
setblock 481 293 278 minecraft:light[level=13]
setblock 481 293 286 minecraft:light[level=13]
setblock 481 293 294 minecraft:light[level=13]
setblock 481 293 302 minecraft:light[level=13]
setblock 481 293 310 minecraft:light[level=13]
fill 481 293 313 481 294 313 minecraft:deepslate_tiles
setblock 481 293 315 minecraft:cobbled_deepslate
fill 481 293 316 484 293 316 minecraft:deepslate_tiles
setblock 482 293 314 minecraft:cobbled_deepslate
fill 482 293 315 482 296 315 minecraft:deepslate_tiles
setblock 483 293 313 minecraft:cobbled_deepslate
fill 483 293 314 483 296 314 minecraft:deepslate_tiles
setblock 484 293 277 minecraft:cobbled_deepslate
fill 484 293 313 484 295 313 minecraft:deepslate_tiles
setblock 485 293 276 minecraft:cobbled_deepslate
fill 485 293 277 485 296 277 minecraft:deepslate_tiles
setblock 485 293 316 minecraft:cobbled_deepslate
fill 486 293 276 486 296 276 minecraft:deepslate_tiles
setblock 486 293 315 minecraft:cobbled_deepslate
fill 486 293 316 486 296 316 minecraft:deepslate_tiles
fill 487 293 277 487 294 277 minecraft:deepslate_tiles
setblock 487 293 314 minecraft:cobbled_deepslate
fill 487 293 315 487 296 315 minecraft:deepslate_tiles
fill 488 293 314 488 294 314 minecraft:deepslate_tiles
setblock 489 293 278 minecraft:light[level=13]
setblock 489 293 286 minecraft:light[level=13]
setblock 489 293 294 minecraft:light[level=13]
setblock 489 293 302 minecraft:light[level=13]
setblock 489 293 310 minecraft:light[level=13]
setblock 490 293 276 minecraft:cobbled_deepslate
setblock 490 293 316 minecraft:cobbled_deepslate
fill 491 293 276 491 296 276 minecraft:deepslate_tiles
setblock 491 293 315 minecraft:cobbled_deepslate
fill 491 293 316 491 296 316 minecraft:deepslate_tiles
setblock 494 293 316 minecraft:deepslate_tiles
setblock 497 293 278 minecraft:light[level=13]
setblock 497 293 286 minecraft:light[level=13]
setblock 497 293 294 minecraft:light[level=13]
setblock 497 293 302 minecraft:light[level=13]
setblock 497 293 310 minecraft:light[level=13]
fill 497 293 316 499 293 316 minecraft:deepslate_tiles
fill 498 293 276 499 293 276 minecraft:deepslate_tiles
setblock 500 293 276 minecraft:cobbled_deepslate
fill 500 293 277 501 295 277 minecraft:deepslate_tiles
fill 500 293 300 511 293 300 minecraft:cobbled_deepslate
setblock 500 293 316 minecraft:cobbled_deepslate
fill 501 293 276 501 296 276 minecraft:deepslate_tiles
setblock 501 293 315 minecraft:cobbled_deepslate
fill 501 293 316 501 296 316 minecraft:deepslate_tiles
fill 502 293 315 505 293 315 minecraft:deepslate_tiles
setblock 503 293 278 minecraft:cobbled_deepslate
setblock 504 293 277 minecraft:cobbled_deepslate
fill 504 293 278 507 293 278 minecraft:deepslate_tiles
setblock 505 293 276 minecraft:cobbled_deepslate
fill 505 293 277 505 296 277 minecraft:deepslate_tiles
setblock 505 293 286 minecraft:light[level=13]
setblock 505 293 294 minecraft:light[level=13]
setblock 505 293 302 minecraft:light[level=13]
setblock 505 293 310 minecraft:light[level=13]
setblock 505 293 316 minecraft:cobbled_deepslate
fill 506 293 276 506 296 276 minecraft:deepslate_tiles
setblock 506 293 315 minecraft:cobbled_deepslate
fill 506 293 316 506 296 316 minecraft:deepslate_tiles
fill 507 293 315 507 296 315 minecraft:deepslate_tiles
setblock 508 293 278 minecraft:cobbled_deepslate
setblock 509 293 277 minecraft:cobbled_deepslate
fill 509 293 278 509 295 279 minecraft:deepslate_tiles
setblock 509 293 292 minecraft:cobbled_deepslate
fill 509 293 293 509 294 293 minecraft:deepslate_tiles
setblock 510 293 276 minecraft:cobbled_deepslate
fill 510 293 277 510 296 277 minecraft:deepslate_tiles
setblock 510 293 281 minecraft:cobbled_deepslate
fill 510 293 282 510 296 282 minecraft:deepslate_tiles
setblock 510 293 287 minecraft:deepslate_tiles
setblock 510 293 291 minecraft:cobbled_deepslate
fill 510 293 292 510 295 292 minecraft:deepslate_tiles
setblock 510 293 296 minecraft:cobbled_deepslate
fill 510 293 297 510 295 297 minecraft:deepslate_tiles
setblock 510 293 316 minecraft:cobbled_deepslate
fill 511 293 276 511 296 276 minecraft:deepslate_tiles
setblock 511 293 280 minecraft:cobbled_deepslate
fill 511 293 281 511 296 281 minecraft:deepslate_tiles
setblock 511 293 285 minecraft:cobbled_deepslate
fill 511 293 286 511 295 286 minecraft:deepslate_tiles
setblock 511 293 290 minecraft:cobbled_deepslate
fill 511 293 291 511 296 291 minecraft:deepslate_tiles
setblock 511 293 295 minecraft:cobbled_deepslate
fill 511 293 296 511 296 296 minecraft:deepslate_tiles
setblock 511 293 299 minecraft:deepslate_tiles
setblock 511 293 311 minecraft:deepslate_tiles
setblock 511 293 315 minecraft:cobbled_deepslate
fill 511 293 316 511 296 316 minecraft:deepslate_tiles
fill 512 293 294 512 308 294 minecraft:deepslate_tiles
fill 470 294 288 470 308 288 minecraft:deepslate_tiles
setblock 471 294 279 minecraft:cobbled_deepslate
fill 471 294 280 471 297 280 minecraft:deepslate_tiles
fill 471 294 284 472 295 284 minecraft:cobbled_deepslate
fill 471 294 288 473 295 288 minecraft:cobbled_deepslate
setblock 471 294 294 minecraft:cobbled_deepslate
fill 471 294 295 471 296 295 minecraft:deepslate_tiles
setblock 471 294 298 minecraft:deepslate_tiles
fill 471 294 299 471 294 300 minecraft:cobbled_deepslate
fill 471 294 304 511 294 304 minecraft:cobbled_deepslate
fill 471 294 308 511 294 308 minecraft:cobbled_deepslate
fill 471 294 310 471 295 310 minecraft:deepslate_tiles
setblock 471 294 314 minecraft:cobbled_deepslate
fill 471 294 315 473 294 316 minecraft:deepslate_tiles
setblock 472 294 278 minecraft:cobbled_deepslate
fill 472 294 280 508 294 280 minecraft:cobbled_deepslate
fill 472 294 292 473 295 292 minecraft:cobbled_deepslate
fill 472 294 296 488 294 296 minecraft:cobbled_deepslate
fill 472 294 300 502 294 300 minecraft:cobbled_deepslate
setblock 472 294 313 minecraft:cobbled_deepslate
fill 472 294 314 472 297 314 minecraft:deepslate_tiles
setblock 473 294 277 minecraft:cobbled_deepslate
fill 473 294 312 510 294 312 minecraft:cobbled_deepslate
setblock 474 294 276 minecraft:cobbled_deepslate
setblock 474 294 315 minecraft:deepslate_tiles
setblock 474 294 316 minecraft:cobbled_deepslate
fill 475 294 276 478 294 276 minecraft:deepslate_tiles
setblock 475 294 315 minecraft:cobbled_deepslate
fill 475 294 316 478 294 316 minecraft:deepslate_tiles
fill 476 294 315 479 294 315 minecraft:deepslate_tiles
fill 477 294 314 480 294 314 minecraft:deepslate_tiles
setblock 478 294 277 minecraft:cobbled_deepslate
setblock 479 294 276 minecraft:cobbled_deepslate
fill 479 294 277 482 294 277 minecraft:deepslate_tiles
setblock 479 294 316 minecraft:cobbled_deepslate
fill 480 294 276 480 297 276 minecraft:deepslate_tiles
setblock 480 294 315 minecraft:cobbled_deepslate
fill 480 294 316 483 294 316 minecraft:deepslate_tiles
setblock 481 294 314 minecraft:cobbled_deepslate
fill 481 294 315 481 297 315 minecraft:deepslate_tiles
setblock 482 294 313 minecraft:cobbled_deepslate
fill 482 294 314 482 297 314 minecraft:deepslate_tiles
setblock 483 294 277 minecraft:cobbled_deepslate
fill 483 294 313 483 295 313 minecraft:deepslate_tiles
setblock 484 294 276 minecraft:cobbled_deepslate
fill 484 294 277 484 297 277 minecraft:deepslate_tiles
setblock 484 294 316 minecraft:cobbled_deepslate
fill 485 294 276 485 297 276 minecraft:deepslate_tiles
setblock 485 294 315 minecraft:cobbled_deepslate
fill 485 294 316 485 297 316 minecraft:deepslate_tiles
setblock 486 294 314 minecraft:cobbled_deepslate
fill 486 294 315 486 297 315 minecraft:deepslate_tiles
fill 487 294 314 487 295 314 minecraft:deepslate_tiles
setblock 488 294 277 minecraft:cobbled_deepslate
setblock 489 294 276 minecraft:cobbled_deepslate
setblock 489 294 288 minecraft:white_wool
setblock 489 294 316 minecraft:cobbled_deepslate
fill 490 294 276 490 297 276 minecraft:deepslate_tiles
setblock 490 294 315 minecraft:cobbled_deepslate
fill 490 294 316 490 297 316 minecraft:deepslate_tiles
fill 492 294 276 492 295 276 minecraft:deepslate_tiles
setblock 494 294 316 minecraft:cobbled_deepslate
fill 495 294 316 498 294 316 minecraft:deepslate_tiles
fill 496 294 276 498 294 276 minecraft:deepslate_tiles
fill 496 294 296 509 294 296 minecraft:cobbled_deepslate
setblock 499 294 276 minecraft:cobbled_deepslate
fill 499 294 277 499 297 277 minecraft:deepslate_tiles
setblock 499 294 316 minecraft:cobbled_deepslate
fill 500 294 276 500 297 276 minecraft:deepslate_tiles
setblock 500 294 315 minecraft:cobbled_deepslate
fill 500 294 316 500 297 316 minecraft:deepslate_tiles
setblock 501 294 278 minecraft:deepslate_tiles
fill 501 294 315 504 294 315 minecraft:deepslate_tiles
setblock 502 294 278 minecraft:cobbled_deepslate
setblock 503 294 276 minecraft:deepslate_tiles
setblock 503 294 277 minecraft:cobbled_deepslate
fill 503 294 278 506 294 278 minecraft:deepslate_tiles
setblock 504 294 276 minecraft:cobbled_deepslate
fill 504 294 277 504 297 277 minecraft:deepslate_tiles
setblock 504 294 316 minecraft:cobbled_deepslate
fill 505 294 276 505 297 276 minecraft:deepslate_tiles
setblock 505 294 315 minecraft:cobbled_deepslate
fill 505 294 316 505 297 316 minecraft:deepslate_tiles
fill 506 294 315 506 297 315 minecraft:deepslate_tiles
setblock 507 294 278 minecraft:cobbled_deepslate
setblock 508 294 277 minecraft:cobbled_deepslate
fill 508 294 278 508 297 278 minecraft:deepslate_tiles
setblock 509 294 276 minecraft:cobbled_deepslate
fill 509 294 277 509 297 277 minecraft:deepslate_tiles
setblock 509 294 280 minecraft:deepslate_tiles
setblock 509 294 292 minecraft:deepslate_tiles
setblock 509 294 316 minecraft:cobbled_deepslate
fill 510 294 276 510 297 276 minecraft:deepslate_tiles
setblock 510 294 279 minecraft:deepslate_tiles
setblock 510 294 280 minecraft:cobbled_deepslate
fill 510 294 281 510 297 281 minecraft:deepslate_tiles
setblock 510 294 290 minecraft:cobbled_deepslate
fill 510 294 291 510 295 291 minecraft:deepslate_tiles
setblock 510 294 295 minecraft:cobbled_deepslate
fill 510 294 296 510 295 296 minecraft:deepslate_tiles
setblock 510 294 315 minecraft:cobbled_deepslate
fill 510 294 316 510 297 316 minecraft:deepslate_tiles
setblock 511 294 279 minecraft:cobbled_deepslate
fill 511 294 280 511 297 280 minecraft:deepslate_tiles
setblock 511 294 284 minecraft:cobbled_deepslate
fill 511 294 285 511 295 285 minecraft:deepslate_tiles
setblock 511 294 289 minecraft:cobbled_deepslate
fill 511 294 290 511 295 290 minecraft:deepslate_tiles
setblock 511 294 294 minecraft:cobbled_deepslate
fill 511 294 295 511 297 295 minecraft:deepslate_tiles
setblock 511 294 299 minecraft:cobbled_deepslate
setblock 511 294 314 minecraft:cobbled_deepslate
fill 511 294 315 511 297 315 minecraft:deepslate_tiles
fill 470 295 298 470 308 301 minecraft:deepslate_tiles
setblock 470 295 302 minecraft:redstone_block
fill 470 295 303 470 297 304 minecraft:deepslate_tiles
setblock 471 295 277 minecraft:deepslate_tiles
setblock 471 295 278 minecraft:cobbled_deepslate
fill 471 295 279 471 298 279 minecraft:deepslate_tiles
setblock 471 295 292 minecraft:cobbled_deepslate
setblock 471 295 294 minecraft:deepslate_tiles
setblock 471 295 298 minecraft:cobbled_deepslate
fill 471 295 299 471 297 300 minecraft:deepslate_tiles
fill 471 295 304 475 295 304 minecraft:cobbled_deepslate
fill 471 295 308 475 295 308 minecraft:cobbled_deepslate
setblock 471 295 313 minecraft:cobbled_deepslate
fill 471 295 314 471 296 316 minecraft:deepslate_tiles
setblock 472 295 277 minecraft:cobbled_deepslate
fill 472 295 278 472 297 278 minecraft:deepslate_tiles
setblock 472 295 280 minecraft:cobbled_deepslate
fill 472 295 296 473 295 296 minecraft:cobbled_deepslate
setblock 472 295 300 minecraft:cobbled_deepslate
setblock 472 295 312 minecraft:cobbled_deepslate
fill 472 295 313 472 296 313 minecraft:deepslate_tiles
fill 472 295 315 472 295 316 minecraft:deepslate_tiles
setblock 473 295 276 minecraft:cobbled_deepslate
fill 473 295 277 476 295 277 minecraft:deepslate_tiles
setblock 473 295 278 minecraft:light[level=12]
fill 473 295 284 508 295 284 minecraft:cobbled_deepslate
setblock 473 295 285 minecraft:light[level=12]
setblock 473 295 299 minecraft:light[level=12]
setblock 473 295 306 minecraft:light[level=12]
setblock 473 295 313 minecraft:light[level=12]
setblock 473 295 315 minecraft:deepslate_tiles
setblock 473 295 316 minecraft:cobbled_deepslate
fill 474 295 276 477 295 276 minecraft:deepslate_tiles
fill 474 295 288 511 295 288 minecraft:cobbled_deepslate
fill 474 295 292 489 295 292 minecraft:cobbled_deepslate
setblock 474 295 315 minecraft:cobbled_deepslate
fill 474 295 316 477 295 316 minecraft:deepslate_tiles
fill 475 295 315 478 295 315 minecraft:deepslate_tiles
setblock 477 295 277 minecraft:cobbled_deepslate
fill 477 295 314 479 295 314 minecraft:deepslate_tiles
setblock 478 295 276 minecraft:cobbled_deepslate
fill 478 295 277 481 295 277 minecraft:deepslate_tiles
setblock 478 295 316 minecraft:cobbled_deepslate
fill 479 295 276 479 298 276 minecraft:deepslate_tiles
setblock 479 295 315 minecraft:cobbled_deepslate
fill 479 295 316 482 295 316 minecraft:deepslate_tiles
setblock 480 295 278 minecraft:light[level=12]
setblock 480 295 285 minecraft:light[level=12]
setblock 480 295 299 minecraft:light[level=12]
setblock 480 295 306 minecraft:light[level=12]
setblock 480 295 313 minecraft:light[level=12]
setblock 480 295 314 minecraft:cobbled_deepslate
fill 480 295 315 480 298 315 minecraft:deepslate_tiles
setblock 481 295 313 minecraft:cobbled_deepslate
fill 481 295 314 481 298 314 minecraft:deepslate_tiles
setblock 482 295 277 minecraft:cobbled_deepslate
setblock 482 295 313 minecraft:deepslate_tiles
setblock 483 295 276 minecraft:cobbled_deepslate
fill 483 295 277 483 298 277 minecraft:deepslate_tiles
setblock 483 295 316 minecraft:cobbled_deepslate
fill 484 295 276 484 298 276 minecraft:deepslate_tiles
setblock 484 295 315 minecraft:cobbled_deepslate
fill 484 295 316 484 298 316 minecraft:deepslate_tiles
setblock 485 295 314 minecraft:cobbled_deepslate
fill 485 295 315 485 298 315 minecraft:deepslate_tiles
fill 486 295 314 486 296 314 minecraft:deepslate_tiles
setblock 487 295 277 minecraft:cobbled_deepslate
setblock 487 295 278 minecraft:light[level=12]
setblock 487 295 285 minecraft:light[level=12]
setblock 487 295 299 minecraft:light[level=12]
setblock 487 295 306 minecraft:light[level=12]
setblock 487 295 313 minecraft:light[level=12]
setblock 488 295 276 minecraft:cobbled_deepslate
fill 488 295 277 488 296 277 minecraft:deepslate_tiles
setblock 488 295 316 minecraft:cobbled_deepslate
fill 489 295 276 489 298 276 minecraft:deepslate_tiles
setblock 489 295 315 minecraft:cobbled_deepslate
fill 489 295 316 489 297 316 minecraft:deepslate_tiles
setblock 490 295 315 minecraft:deepslate_tiles
fill 491 295 307 491 295 315 minecraft:white_wool
setblock 493 295 276 minecraft:cobbled_deepslate
setblock 493 295 316 minecraft:cobbled_deepslate
fill 494 295 276 497 295 276 minecraft:deepslate_tiles
setblock 494 295 278 minecraft:light[level=12]
setblock 494 295 285 minecraft:light[level=12]
setblock 494 295 292 minecraft:light[level=12]
setblock 494 295 299 minecraft:light[level=12]
setblock 494 295 306 minecraft:light[level=12]
setblock 494 295 313 minecraft:light[level=12]
fill 494 295 316 497 295 316 minecraft:deepslate_tiles
fill 495 295 292 509 295 292 minecraft:cobbled_deepslate
fill 495 295 302 495 295 315 minecraft:white_wool
setblock 498 295 276 minecraft:cobbled_deepslate
fill 498 295 277 498 298 277 minecraft:deepslate_tiles
setblock 498 295 316 minecraft:cobbled_deepslate
fill 499 295 276 499 298 276 minecraft:deepslate_tiles
fill 499 295 316 499 298 316 minecraft:deepslate_tiles
setblock 500 295 278 minecraft:deepslate_tiles
fill 500 295 315 503 295 315 minecraft:deepslate_tiles
setblock 501 295 278 minecraft:cobbled_deepslate
setblock 501 295 285 minecraft:light[level=12]
setblock 501 295 299 minecraft:light[level=12]
setblock 501 295 306 minecraft:light[level=12]
setblock 501 295 313 minecraft:light[level=12]
setblock 502 295 276 minecraft:deepslate_tiles
setblock 502 295 277 minecraft:cobbled_deepslate
fill 502 295 278 505 295 278 minecraft:deepslate_tiles
setblock 503 295 276 minecraft:cobbled_deepslate
fill 503 295 277 503 298 277 minecraft:deepslate_tiles
fill 503 295 279 504 295 279 minecraft:deepslate_tiles
setblock 503 295 316 minecraft:cobbled_deepslate
fill 504 295 276 504 298 276 minecraft:deepslate_tiles
setblock 504 295 315 minecraft:cobbled_deepslate
fill 504 295 316 504 298 316 minecraft:deepslate_tiles
setblock 505 295 279 minecraft:cobbled_deepslate
fill 505 295 315 505 298 315 minecraft:deepslate_tiles
setblock 506 295 278 minecraft:cobbled_deepslate
fill 506 295 279 507 297 279 minecraft:deepslate_tiles
setblock 507 295 277 minecraft:cobbled_deepslate
fill 507 295 278 507 298 278 minecraft:deepslate_tiles
setblock 508 295 276 minecraft:cobbled_deepslate
fill 508 295 277 508 298 277 minecraft:deepslate_tiles
setblock 508 295 285 minecraft:light[level=12]
setblock 508 295 299 minecraft:light[level=12]
setblock 508 295 306 minecraft:light[level=12]
setblock 508 295 313 minecraft:light[level=12]
setblock 508 295 316 minecraft:cobbled_deepslate
fill 509 295 276 509 298 276 minecraft:deepslate_tiles
setblock 509 295 280 minecraft:cobbled_deepslate
setblock 509 295 315 minecraft:cobbled_deepslate
fill 509 295 316 509 298 316 minecraft:deepslate_tiles
setblock 510 295 279 minecraft:cobbled_deepslate
fill 510 295 280 510 298 280 minecraft:deepslate_tiles
setblock 510 295 294 minecraft:cobbled_deepslate
fill 510 295 295 510 296 295 minecraft:deepslate_tiles
setblock 510 295 314 minecraft:cobbled_deepslate
fill 510 295 315 510 296 315 minecraft:deepslate_tiles
setblock 511 295 278 minecraft:cobbled_deepslate
fill 511 295 279 511 298 279 minecraft:deepslate_tiles
setblock 511 295 283 minecraft:cobbled_deepslate
fill 511 295 284 511 296 284 minecraft:deepslate_tiles
setblock 511 295 289 minecraft:deepslate_tiles
setblock 511 295 293 minecraft:cobbled_deepslate
fill 511 295 294 511 297 294 minecraft:deepslate_tiles
setblock 511 295 298 minecraft:cobbled_deepslate
fill 511 295 299 511 297 299 minecraft:deepslate_tiles
setblock 511 295 313 minecraft:cobbled_deepslate
fill 511 295 314 511 297 314 minecraft:deepslate_tiles
fill 470 296 302 470 299 302 minecraft:deepslate_tiles
setblock 471 296 277 minecraft:cobbled_deepslate
fill 471 296 278 471 299 278 minecraft:deepslate_tiles
setblock 471 296 296 minecraft:deepslate_tiles
setblock 471 296 297 minecraft:cobbled_deepslate
fill 471 296 298 471 298 298 minecraft:deepslate_tiles
setblock 471 296 312 minecraft:cobbled_deepslate
fill 471 296 313 471 298 313 minecraft:deepslate_tiles
setblock 472 296 276 minecraft:cobbled_deepslate
fill 472 296 277 475 296 277 minecraft:deepslate_tiles
setblock 472 296 315 minecraft:deepslate_tiles
setblock 472 296 316 minecraft:cobbled_deepslate
fill 473 296 276 476 296 276 minecraft:deepslate_tiles
setblock 473 296 315 minecraft:cobbled_deepslate
fill 473 296 316 476 296 316 minecraft:deepslate_tiles
fill 474 296 315 477 296 315 minecraft:deepslate_tiles
setblock 476 296 277 minecraft:cobbled_deepslate
setblock 477 296 276 minecraft:cobbled_deepslate
fill 477 296 277 480 296 277 minecraft:deepslate_tiles
fill 477 296 314 478 296 314 minecraft:deepslate_tiles
setblock 477 296 316 minecraft:cobbled_deepslate
fill 478 296 276 478 299 276 minecraft:deepslate_tiles
setblock 478 296 315 minecraft:cobbled_deepslate
fill 478 296 316 481 296 316 minecraft:deepslate_tiles
setblock 479 296 314 minecraft:cobbled_deepslate
fill 479 296 315 479 299 315 minecraft:deepslate_tiles
fill 480 296 314 480 298 314 minecraft:deepslate_tiles
setblock 481 296 277 minecraft:cobbled_deepslate
setblock 482 296 276 minecraft:cobbled_deepslate
fill 482 296 277 482 299 277 minecraft:deepslate_tiles
setblock 482 296 316 minecraft:cobbled_deepslate
fill 483 296 276 483 299 276 minecraft:deepslate_tiles
fill 483 296 278 483 296 313 minecraft:white_wool
setblock 483 296 315 minecraft:cobbled_deepslate
fill 483 296 316 483 299 316 minecraft:deepslate_tiles
setblock 484 296 314 minecraft:cobbled_deepslate
fill 484 296 315 484 299 315 minecraft:deepslate_tiles
fill 485 296 314 485 297 314 minecraft:deepslate_tiles
setblock 486 296 277 minecraft:cobbled_deepslate
setblock 487 296 276 minecraft:cobbled_deepslate
fill 487 296 277 487 297 277 minecraft:deepslate_tiles
fill 487 296 278 487 297 294 minecraft:white_wool
setblock 487 296 316 minecraft:cobbled_deepslate
fill 488 296 276 488 299 276 minecraft:deepslate_tiles
setblock 488 296 315 minecraft:cobbled_deepslate
fill 488 296 316 488 298 316 minecraft:deepslate_tiles
setblock 489 296 315 minecraft:deepslate_tiles
fill 491 296 277 491 296 291 minecraft:white_wool
fill 491 296 299 491 296 310 minecraft:white_wool
setblock 491 296 317 minecraft:white_wool
setblock 492 296 276 minecraft:cobbled_deepslate
setblock 492 296 316 minecraft:cobbled_deepslate
fill 493 296 276 496 296 276 minecraft:deepslate_tiles
fill 495 296 277 495 296 293 minecraft:white_wool
fill 495 296 297 495 296 303 minecraft:white_wool
setblock 496 296 316 minecraft:deepslate_tiles
setblock 497 296 276 minecraft:cobbled_deepslate
fill 497 296 277 497 299 277 minecraft:deepslate_tiles
setblock 497 296 316 minecraft:cobbled_deepslate
fill 498 296 276 498 299 276 minecraft:deepslate_tiles
fill 498 296 316 498 299 316 minecraft:deepslate_tiles
setblock 499 296 278 minecraft:deepslate_tiles
fill 499 296 279 499 297 280 minecraft:white_wool
setblock 500 296 277 minecraft:deepslate_tiles
setblock 500 296 278 minecraft:cobbled_deepslate
fill 500 296 315 502 296 315 minecraft:deepslate_tiles
setblock 501 296 277 minecraft:cobbled_deepslate
fill 501 296 278 504 296 278 minecraft:deepslate_tiles
setblock 502 296 276 minecraft:cobbled_deepslate
fill 502 296 277 502 299 277 minecraft:deepslate_tiles
fill 502 296 279 503 296 279 minecraft:deepslate_tiles
setblock 502 296 316 minecraft:cobbled_deepslate
fill 503 296 276 503 299 276 minecraft:deepslate_tiles
setblock 503 296 315 minecraft:cobbled_deepslate
fill 503 296 316 503 299 316 minecraft:deepslate_tiles
setblock 504 296 279 minecraft:cobbled_deepslate
fill 504 296 315 504 298 315 minecraft:deepslate_tiles
setblock 505 296 278 minecraft:cobbled_deepslate
fill 505 296 279 505 299 279 minecraft:deepslate_tiles
setblock 506 296 277 minecraft:cobbled_deepslate
fill 506 296 278 506 299 278 minecraft:deepslate_tiles
fill 506 296 284 510 296 284 minecraft:cobbled_deepslate
setblock 507 296 276 minecraft:cobbled_deepslate
fill 507 296 277 507 299 277 minecraft:deepslate_tiles
fill 507 296 280 507 296 283 minecraft:white_wool
fill 507 296 285 507 296 314 minecraft:white_wool
setblock 507 296 316 minecraft:cobbled_deepslate
fill 508 296 276 508 299 276 minecraft:deepslate_tiles
setblock 508 296 315 minecraft:cobbled_deepslate
fill 508 296 316 508 299 316 minecraft:deepslate_tiles
setblock 509 296 278 minecraft:deepslate_tiles
setblock 509 296 279 minecraft:cobbled_deepslate
fill 509 296 280 509 297 280 minecraft:deepslate_tiles
fill 509 296 315 509 297 315 minecraft:deepslate_tiles
setblock 510 296 278 minecraft:cobbled_deepslate
fill 510 296 279 510 299 279 minecraft:deepslate_tiles
setblock 511 296 277 minecraft:cobbled_deepslate
fill 511 296 278 511 299 278 minecraft:deepslate_tiles
setblock 511 296 282 minecraft:cobbled_deepslate
fill 511 296 283 511 299 283 minecraft:deepslate_tiles
setblock 511 296 292 minecraft:cobbled_deepslate
setblock 511 296 293 minecraft:deepslate_tiles
setblock 511 296 297 minecraft:cobbled_deepslate
fill 511 296 298 511 297 298 minecraft:deepslate_tiles
setblock 511 296 313 minecraft:deepslate_tiles
setblock 512 296 303 minecraft:redstone_block
setblock 471 297 276 minecraft:cobbled_deepslate
fill 471 297 277 474 297 277 minecraft:deepslate_tiles
setblock 471 297 281 minecraft:cobbled_deepslate
setblock 471 297 296 minecraft:cobbled_deepslate
setblock 471 297 297 minecraft:deepslate_tiles
setblock 471 297 301 minecraft:cobbled_deepslate
setblock 471 297 311 minecraft:cobbled_deepslate
setblock 471 297 312 minecraft:deepslate_tiles
fill 471 297 314 471 297 315 minecraft:deepslate_tiles
setblock 471 297 316 minecraft:cobbled_deepslate
fill 472 297 276 475 297 276 minecraft:deepslate_tiles
setblock 472 297 315 minecraft:cobbled_deepslate
fill 472 297 316 475 297 316 minecraft:deepslate_tiles
fill 473 297 315 476 297 315 minecraft:deepslate_tiles
setblock 475 297 277 minecraft:cobbled_deepslate
fill 475 297 278 475 297 305 minecraft:white_wool
setblock 476 297 276 minecraft:cobbled_deepslate
fill 476 297 277 479 297 277 minecraft:deepslate_tiles
setblock 476 297 316 minecraft:cobbled_deepslate
fill 477 297 276 477 300 276 minecraft:deepslate_tiles
setblock 477 297 315 minecraft:cobbled_deepslate
fill 477 297 316 480 297 316 minecraft:deepslate_tiles
setblock 478 297 314 minecraft:cobbled_deepslate
fill 478 297 315 478 300 315 minecraft:deepslate_tiles
fill 479 297 278 479 297 309 minecraft:white_wool
fill 479 297 314 479 298 314 minecraft:deepslate_tiles
setblock 480 297 277 minecraft:cobbled_deepslate
setblock 481 297 276 minecraft:cobbled_deepslate
fill 481 297 277 481 300 277 minecraft:deepslate_tiles
setblock 481 297 316 minecraft:cobbled_deepslate
fill 482 297 276 482 300 276 minecraft:deepslate_tiles
setblock 482 297 315 minecraft:cobbled_deepslate
fill 482 297 316 482 300 316 minecraft:deepslate_tiles
setblock 483 297 278 minecraft:white_wool
setblock 483 297 314 minecraft:cobbled_deepslate
fill 483 297 315 483 299 315 minecraft:deepslate_tiles
setblock 484 297 314 minecraft:deepslate_tiles
setblock 485 297 277 minecraft:cobbled_deepslate
setblock 486 297 276 minecraft:cobbled_deepslate
fill 486 297 277 486 298 277 minecraft:deepslate_tiles
setblock 486 297 316 minecraft:cobbled_deepslate
fill 487 297 276 487 299 276 minecraft:deepslate_tiles
fill 487 297 295 487 297 314 minecraft:white_wool
setblock 487 297 315 minecraft:cobbled_deepslate
fill 487 297 316 487 299 316 minecraft:deepslate_tiles
setblock 491 297 276 minecraft:cobbled_deepslate
setblock 491 297 277 minecraft:white_wool
fill 491 297 317 491 308 317 minecraft:deepslate_tiles
fill 492 297 276 495 297 276 minecraft:deepslate_tiles
fill 496 297 275 496 308 275 minecraft:deepslate_tiles
setblock 496 297 276 minecraft:cobbled_deepslate
fill 496 297 277 496 300 277 minecraft:deepslate_tiles
setblock 496 297 316 minecraft:cobbled_deepslate
setblock 497 297 275 minecraft:redstone_block
fill 497 297 276 497 300 276 minecraft:deepslate_tiles
fill 497 297 316 497 298 316 minecraft:deepslate_tiles
fill 498 297 275 499 308 275 minecraft:deepslate_tiles
setblock 499 297 278 minecraft:cobbled_deepslate
fill 499 297 281 499 297 315 minecraft:white_wool
setblock 500 297 277 minecraft:cobbled_deepslate
fill 500 297 278 503 297 278 minecraft:deepslate_tiles
fill 500 297 315 501 297 315 minecraft:deepslate_tiles
setblock 501 297 276 minecraft:cobbled_deepslate
fill 501 297 277 501 300 277 minecraft:deepslate_tiles
fill 501 297 279 502 297 279 minecraft:deepslate_tiles
setblock 501 297 316 minecraft:cobbled_deepslate
fill 502 297 276 502 300 276 minecraft:deepslate_tiles
setblock 502 297 315 minecraft:cobbled_deepslate
fill 502 297 316 502 300 316 minecraft:deepslate_tiles
setblock 503 297 279 minecraft:cobbled_deepslate
fill 503 297 280 503 297 315 minecraft:white_wool
setblock 504 297 278 minecraft:cobbled_deepslate
fill 504 297 279 504 300 279 minecraft:deepslate_tiles
setblock 504 297 314 minecraft:white_wool
setblock 505 297 277 minecraft:cobbled_deepslate
fill 505 297 278 505 300 278 minecraft:deepslate_tiles
setblock 505 297 313 minecraft:white_wool
setblock 506 297 276 minecraft:cobbled_deepslate
fill 506 297 277 506 300 277 minecraft:deepslate_tiles
setblock 506 297 312 minecraft:white_wool
setblock 506 297 316 minecraft:cobbled_deepslate
fill 507 297 276 507 300 276 minecraft:deepslate_tiles
setblock 507 297 315 minecraft:cobbled_deepslate
fill 507 297 316 507 300 316 minecraft:deepslate_tiles
setblock 508 297 315 minecraft:deepslate_tiles
setblock 509 297 278 minecraft:cobbled_deepslate
fill 509 297 279 509 298 279 minecraft:deepslate_tiles
setblock 510 297 277 minecraft:cobbled_deepslate
fill 510 297 278 510 300 278 minecraft:deepslate_tiles
setblock 510 297 282 minecraft:cobbled_deepslate
setblock 511 297 276 minecraft:cobbled_deepslate
fill 511 297 277 511 300 277 minecraft:deepslate_tiles
setblock 511 297 281 minecraft:cobbled_deepslate
fill 511 297 282 512 300 282 minecraft:deepslate_tiles
setblock 511 297 296 minecraft:cobbled_deepslate
setblock 511 297 297 minecraft:deepslate_tiles
setblock 511 297 316 minecraft:cobbled_deepslate
setblock 512 297 283 minecraft:white_wool
fill 512 297 303 512 308 303 minecraft:deepslate_tiles
fill 470 298 303 470 308 303 minecraft:deepslate_tiles
setblock 470 298 304 minecraft:white_wool
fill 471 298 276 473 298 277 minecraft:deepslate_tiles
setblock 471 298 280 minecraft:cobbled_deepslate
setblock 471 298 299 minecraft:deepslate_tiles
setblock 471 298 300 minecraft:cobbled_deepslate
fill 471 298 301 471 300 301 minecraft:deepslate_tiles
setblock 471 298 314 minecraft:deepslate_tiles
setblock 471 298 315 minecraft:cobbled_deepslate
fill 471 298 316 474 298 316 minecraft:deepslate_tiles
fill 473 298 315 475 298 315 minecraft:deepslate_tiles
setblock 474 298 276 minecraft:deepslate_tiles
setblock 474 298 277 minecraft:cobbled_deepslate
setblock 475 298 276 minecraft:cobbled_deepslate
fill 475 298 277 478 298 277 minecraft:deepslate_tiles
fill 475 298 303 475 298 314 minecraft:white_wool
setblock 475 298 316 minecraft:cobbled_deepslate
fill 476 298 276 476 300 276 minecraft:deepslate_tiles
setblock 476 298 315 minecraft:cobbled_deepslate
fill 476 298 316 479 298 316 minecraft:deepslate_tiles
fill 477 298 315 477 300 315 minecraft:deepslate_tiles
setblock 479 298 277 minecraft:cobbled_deepslate
fill 479 298 307 479 298 313 minecraft:white_wool
setblock 480 298 276 minecraft:cobbled_deepslate
fill 480 298 277 480 300 277 minecraft:deepslate_tiles
setblock 480 298 316 minecraft:cobbled_deepslate
fill 481 298 276 481 300 276 minecraft:deepslate_tiles
setblock 481 298 315 minecraft:cobbled_deepslate
fill 481 298 316 481 300 316 minecraft:deepslate_tiles
setblock 482 298 314 minecraft:cobbled_deepslate
fill 482 298 315 482 300 315 minecraft:deepslate_tiles
setblock 483 298 314 minecraft:deepslate_tiles
setblock 484 298 277 minecraft:cobbled_deepslate
setblock 485 298 276 minecraft:cobbled_deepslate
fill 485 298 277 485 299 277 minecraft:deepslate_tiles
setblock 485 298 316 minecraft:cobbled_deepslate
fill 486 298 276 486 300 276 minecraft:deepslate_tiles
setblock 486 298 315 minecraft:cobbled_deepslate
fill 486 298 316 486 299 316 minecraft:deepslate_tiles
setblock 490 298 276 minecraft:cobbled_deepslate
fill 493 298 276 494 298 276 minecraft:deepslate_tiles
setblock 495 298 276 minecraft:cobbled_deepslate
fill 496 298 276 496 300 276 minecraft:deepslate_tiles
fill 497 298 275 497 308 275 minecraft:deepslate_tiles
setblock 498 298 278 minecraft:cobbled_deepslate
setblock 499 298 277 minecraft:cobbled_deepslate
fill 499 298 278 502 298 278 minecraft:deepslate_tiles
setblock 500 298 276 minecraft:cobbled_deepslate
fill 500 298 277 500 300 277 minecraft:deepslate_tiles
setblock 500 298 316 minecraft:cobbled_deepslate
fill 501 298 276 501 300 276 minecraft:deepslate_tiles
setblock 501 298 279 minecraft:deepslate_tiles
setblock 501 298 315 minecraft:cobbled_deepslate
fill 501 298 316 501 300 316 minecraft:deepslate_tiles
setblock 502 298 279 minecraft:cobbled_deepslate
fill 502 298 315 503 298 315 minecraft:deepslate_tiles
setblock 503 298 278 minecraft:cobbled_deepslate
fill 503 298 279 503 300 279 minecraft:deepslate_tiles
setblock 504 298 277 minecraft:cobbled_deepslate
fill 504 298 278 504 300 278 minecraft:deepslate_tiles
setblock 505 298 276 minecraft:cobbled_deepslate
fill 505 298 277 505 300 277 minecraft:deepslate_tiles
setblock 505 298 316 minecraft:cobbled_deepslate
fill 506 298 276 506 300 276 minecraft:deepslate_tiles
setblock 506 298 279 minecraft:deepslate_tiles
setblock 506 298 315 minecraft:cobbled_deepslate
fill 506 298 316 506 300 316 minecraft:deepslate_tiles
setblock 507 298 311 minecraft:white_wool
setblock 508 298 278 minecraft:cobbled_deepslate
setblock 508 298 310 minecraft:white_wool
setblock 509 298 277 minecraft:cobbled_deepslate
fill 509 298 278 509 299 278 minecraft:deepslate_tiles
setblock 509 298 309 minecraft:white_wool
setblock 510 298 276 minecraft:cobbled_deepslate
fill 510 298 277 510 300 277 minecraft:deepslate_tiles
setblock 510 298 281 minecraft:cobbled_deepslate
setblock 510 298 308 minecraft:white_wool
setblock 510 298 316 minecraft:cobbled_deepslate
fill 511 298 276 511 300 276 minecraft:deepslate_tiles
setblock 511 298 280 minecraft:cobbled_deepslate
fill 511 298 281 511 300 281 minecraft:deepslate_tiles
setblock 511 298 315 minecraft:cobbled_deepslate
fill 511 298 316 511 299 316 minecraft:deepslate_tiles
fill 512 298 283 512 308 283 minecraft:deepslate_tiles
fill 512 298 298 512 308 298 minecraft:deepslate_tiles
setblock 512 298 299 minecraft:redstone_block
fill 470 299 304 470 305 304 minecraft:deepslate_tiles
fill 471 299 276 471 300 277 minecraft:deepslate_tiles
setblock 471 299 279 minecraft:cobbled_deepslate
setblock 471 299 280 minecraft:deepslate_tiles
setblock 471 299 300 minecraft:deepslate_tiles
setblock 471 299 314 minecraft:cobbled_deepslate
fill 471 299 315 471 300 316 minecraft:deepslate_tiles
fill 472 299 276 473 299 276 minecraft:deepslate_tiles
fill 472 299 316 473 299 316 minecraft:deepslate_tiles
setblock 474 299 276 minecraft:cobbled_deepslate
setblock 474 299 316 minecraft:cobbled_deepslate
fill 475 299 276 475 300 276 minecraft:deepslate_tiles
setblock 475 299 315 minecraft:cobbled_deepslate
fill 475 299 316 478 299 316 minecraft:deepslate_tiles
fill 476 299 277 477 299 277 minecraft:deepslate_tiles
setblock 476 299 315 minecraft:deepslate_tiles
setblock 478 299 277 minecraft:cobbled_deepslate
setblock 479 299 276 minecraft:cobbled_deepslate
fill 479 299 277 479 300 277 minecraft:deepslate_tiles
setblock 479 299 316 minecraft:cobbled_deepslate
fill 480 299 276 480 300 276 minecraft:deepslate_tiles
setblock 480 299 315 minecraft:cobbled_deepslate
fill 480 299 316 480 300 316 minecraft:deepslate_tiles
fill 481 299 315 481 300 315 minecraft:deepslate_tiles
setblock 483 299 277 minecraft:cobbled_deepslate
setblock 484 299 276 minecraft:cobbled_deepslate
setblock 484 299 277 minecraft:deepslate_tiles
setblock 484 299 316 minecraft:cobbled_deepslate
fill 485 299 276 485 300 276 minecraft:deepslate_tiles
fill 485 299 316 485 300 316 minecraft:deepslate_tiles
setblock 494 299 276 minecraft:cobbled_deepslate
fill 495 299 276 495 300 276 minecraft:deepslate_tiles
setblock 498 299 277 minecraft:cobbled_deepslate
fill 498 299 278 501 299 278 minecraft:deepslate_tiles
setblock 499 299 276 minecraft:cobbled_deepslate
fill 499 299 277 499 300 277 minecraft:deepslate_tiles
setblock 499 299 316 minecraft:cobbled_deepslate
fill 500 299 276 500 300 276 minecraft:deepslate_tiles
setblock 500 299 279 minecraft:deepslate_tiles
fill 500 299 316 500 300 316 minecraft:deepslate_tiles
setblock 501 299 279 minecraft:cobbled_deepslate
setblock 502 299 278 minecraft:cobbled_deepslate
fill 502 299 279 502 300 279 minecraft:deepslate_tiles
setblock 503 299 277 minecraft:cobbled_deepslate
fill 503 299 278 503 300 278 minecraft:deepslate_tiles
setblock 504 299 276 minecraft:cobbled_deepslate
fill 504 299 277 504 300 277 minecraft:deepslate_tiles
setblock 504 299 316 minecraft:cobbled_deepslate
fill 505 299 276 505 300 276 minecraft:deepslate_tiles
fill 505 299 316 505 300 316 minecraft:deepslate_tiles
setblock 507 299 278 minecraft:cobbled_deepslate
setblock 508 299 277 minecraft:cobbled_deepslate
setblock 508 299 278 minecraft:deepslate_tiles
setblock 509 299 276 minecraft:cobbled_deepslate
fill 509 299 277 509 300 277 minecraft:deepslate_tiles
setblock 509 299 316 minecraft:cobbled_deepslate
fill 510 299 276 510 300 276 minecraft:deepslate_tiles
setblock 510 299 280 minecraft:cobbled_deepslate
setblock 510 299 281 minecraft:deepslate_tiles
setblock 510 299 316 minecraft:deepslate_tiles
setblock 511 299 279 minecraft:cobbled_deepslate
fill 511 299 280 511 300 280 minecraft:deepslate_tiles
fill 512 299 299 512 308 299 minecraft:deepslate_tiles
setblock 512 299 302 minecraft:redstone_block
setblock 470 300 302 minecraft:white_wool
setblock 471 300 278 minecraft:cobbled_deepslate
setblock 471 300 279 minecraft:deepslate_tiles
setblock 472 300 276 minecraft:deepslate_tiles
setblock 472 300 316 minecraft:deepslate_tiles
setblock 473 300 276 minecraft:cobbled_deepslate
setblock 473 300 316 minecraft:cobbled_deepslate
setblock 474 300 276 minecraft:deepslate_tiles
fill 474 300 316 477 300 316 minecraft:deepslate_tiles
setblock 477 300 277 minecraft:cobbled_deepslate
setblock 478 300 276 minecraft:cobbled_deepslate
setblock 478 300 277 minecraft:deepslate_tiles
setblock 478 300 316 minecraft:cobbled_deepslate
setblock 479 300 276 minecraft:deepslate_tiles
setblock 479 300 315 minecraft:cobbled_deepslate
setblock 479 300 316 minecraft:deepslate_tiles
setblock 480 300 315 minecraft:deepslate_tiles
setblock 482 300 277 minecraft:cobbled_deepslate
setblock 483 300 276 minecraft:cobbled_deepslate
setblock 483 300 277 minecraft:deepslate_tiles
setblock 483 300 316 minecraft:cobbled_deepslate
setblock 484 300 276 minecraft:deepslate_tiles
setblock 484 300 316 minecraft:deepslate_tiles
setblock 494 300 276 minecraft:deepslate_tiles
setblock 497 300 277 minecraft:cobbled_deepslate
setblock 498 300 276 minecraft:cobbled_deepslate
fill 498 300 277 498 300 278 minecraft:deepslate_tiles
setblock 498 300 316 minecraft:cobbled_deepslate
setblock 499 300 276 minecraft:deepslate_tiles
fill 499 300 278 500 300 278 minecraft:deepslate_tiles
setblock 499 300 316 minecraft:deepslate_tiles
setblock 500 300 279 minecraft:cobbled_deepslate
setblock 501 300 278 minecraft:cobbled_deepslate
setblock 501 300 279 minecraft:deepslate_tiles
setblock 502 300 277 minecraft:cobbled_deepslate
setblock 502 300 278 minecraft:deepslate_tiles
setblock 503 300 276 minecraft:cobbled_deepslate
setblock 503 300 277 minecraft:deepslate_tiles
setblock 503 300 316 minecraft:cobbled_deepslate
setblock 504 300 276 minecraft:deepslate_tiles
setblock 504 300 316 minecraft:deepslate_tiles
setblock 506 300 278 minecraft:cobbled_deepslate
setblock 507 300 277 minecraft:cobbled_deepslate
setblock 507 300 278 minecraft:deepslate_tiles
setblock 508 300 276 minecraft:cobbled_deepslate
setblock 508 300 277 minecraft:deepslate_tiles
setblock 508 300 316 minecraft:cobbled_deepslate
setblock 509 300 276 minecraft:deepslate_tiles
setblock 510 300 279 minecraft:cobbled_deepslate
setblock 510 300 280 minecraft:deepslate_tiles
setblock 511 300 278 minecraft:cobbled_deepslate
setblock 511 300 279 minecraft:deepslate_tiles
fill 512 300 302 512 308 302 minecraft:deepslate_tiles
fill 470 301 302 470 308 302 minecraft:deepslate_tiles
setblock 473 301 278 minecraft:light[level=13]
setblock 473 301 285 minecraft:light[level=12]
setblock 473 301 286 minecraft:light[level=13]
setblock 473 301 292 minecraft:light[level=12]
setblock 473 301 294 minecraft:light[level=13]
setblock 473 301 299 minecraft:light[level=12]
setblock 473 301 302 minecraft:light[level=13]
setblock 473 301 306 minecraft:light[level=12]
setblock 473 301 310 minecraft:light[level=13]
setblock 473 301 313 minecraft:light[level=12]
setblock 480 301 278 minecraft:light[level=12]
setblock 480 301 285 minecraft:light[level=12]
setblock 480 301 292 minecraft:light[level=12]
setblock 480 301 299 minecraft:light[level=12]
setblock 480 301 306 minecraft:light[level=12]
setblock 480 301 313 minecraft:light[level=12]
setblock 481 301 278 minecraft:light[level=13]
setblock 481 301 286 minecraft:light[level=13]
setblock 481 301 294 minecraft:light[level=13]
setblock 481 301 302 minecraft:light[level=13]
setblock 481 301 310 minecraft:light[level=13]
setblock 487 301 278 minecraft:light[level=12]
setblock 487 301 285 minecraft:light[level=12]
setblock 487 301 292 minecraft:light[level=12]
setblock 487 301 299 minecraft:light[level=12]
setblock 487 301 306 minecraft:light[level=12]
setblock 487 301 313 minecraft:light[level=12]
setblock 489 301 278 minecraft:light[level=13]
setblock 489 301 286 minecraft:light[level=13]
setblock 489 301 294 minecraft:light[level=13]
setblock 489 301 302 minecraft:light[level=13]
setblock 489 301 310 minecraft:light[level=13]
setblock 494 301 278 minecraft:light[level=12]
setblock 494 301 285 minecraft:light[level=12]
setblock 494 301 292 minecraft:light[level=12]
setblock 494 301 299 minecraft:light[level=12]
setblock 494 301 306 minecraft:light[level=12]
setblock 494 301 313 minecraft:light[level=12]
setblock 497 301 278 minecraft:light[level=13]
setblock 497 301 286 minecraft:light[level=13]
setblock 497 301 294 minecraft:light[level=13]
setblock 497 301 302 minecraft:light[level=13]
setblock 497 301 310 minecraft:light[level=13]
setblock 501 301 278 minecraft:light[level=12]
setblock 501 301 285 minecraft:light[level=12]
setblock 501 301 292 minecraft:light[level=12]
setblock 501 301 299 minecraft:light[level=12]
setblock 501 301 306 minecraft:light[level=12]
setblock 501 301 313 minecraft:light[level=12]
setblock 505 301 278 minecraft:light[level=13]
setblock 505 301 286 minecraft:light[level=13]
setblock 505 301 294 minecraft:light[level=13]
setblock 505 301 302 minecraft:light[level=13]
setblock 505 301 310 minecraft:light[level=13]
setblock 508 301 278 minecraft:light[level=12]
setblock 508 301 285 minecraft:light[level=12]
setblock 508 301 292 minecraft:light[level=12]
setblock 508 301 299 minecraft:light[level=12]
setblock 508 301 306 minecraft:light[level=12]
setblock 508 301 313 minecraft:light[level=12]
fill 512 301 282 512 308 282 minecraft:deepslate_tiles
fill 471 303 275 474 308 275 minecraft:deepslate_tiles
setblock 474 303 317 minecraft:redstone_block
setblock 475 303 275 minecraft:redstone_block
fill 474 304 317 474 308 317 minecraft:deepslate_tiles
fill 475 304 275 475 308 275 minecraft:deepslate_tiles
setblock 479 304 317 minecraft:white_wool
fill 479 305 317 479 308 317 minecraft:deepslate_tiles
setblock 470 306 304 minecraft:white_wool
setblock 494 306 317 minecraft:redstone_block
setblock 503 306 317 minecraft:redstone_block
fill 504 306 317 505 308 317 minecraft:deepslate_tiles
fill 470 307 304 470 308 304 minecraft:deepslate_tiles
fill 494 307 317 494 308 317 minecraft:deepslate_tiles
fill 503 307 317 503 308 317 minecraft:deepslate_tiles
fill 510 307 317 510 308 317 minecraft:deepslate_tiles
setblock 511 307 317 minecraft:redstone_block
fill 512 307 317 512 308 317 minecraft:deepslate_tiles
setblock 511 308 317 minecraft:deepslate_tiles
