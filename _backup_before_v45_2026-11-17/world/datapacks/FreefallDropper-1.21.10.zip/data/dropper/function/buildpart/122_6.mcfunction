setblock 127 164 512 minecraft:smooth_basalt
fill 127 164 513 127 167 513 minecraft:blackstone
setblock 128 164 511 minecraft:smooth_basalt
fill 128 164 512 130 165 512 minecraft:blackstone
setblock 128 164 551 minecraft:smooth_basalt
fill 129 164 511 132 164 511 minecraft:blackstone
setblock 129 164 550 minecraft:smooth_basalt
fill 129 164 551 132 164 551 minecraft:blackstone
setblock 130 164 550 minecraft:blackstone
setblock 133 164 511 minecraft:smooth_basalt
setblock 133 164 551 minecraft:smooth_basalt
fill 134 164 511 135 166 511 minecraft:blackstone
fill 134 164 551 135 166 551 minecraft:blackstone
fill 135 164 512 135 165 512 minecraft:blackstone
setblock 135 164 548 minecraft:blackstone
setblock 135 164 549 minecraft:smooth_basalt
fill 135 164 550 135 167 550 minecraft:blackstone
fill 95 165 530 95 165 532 minecraft:blackstone
setblock 95 165 533 minecraft:smooth_basalt
fill 95 165 534 95 166 536 minecraft:blackstone
setblock 95 165 547 minecraft:blackstone
setblock 95 165 548 minecraft:smooth_basalt
fill 95 165 549 95 166 551 minecraft:blackstone
setblock 96 165 511 minecraft:blackstone
fill 96 165 550 96 165 551 minecraft:blackstone
setblock 97 165 511 minecraft:smooth_basalt
setblock 97 165 550 minecraft:blackstone
setblock 97 165 551 minecraft:smooth_basalt
fill 98 165 511 101 165 511 minecraft:blackstone
setblock 98 165 550 minecraft:smooth_basalt
fill 98 165 551 101 165 551 minecraft:blackstone
fill 99 165 550 102 165 550 minecraft:blackstone
setblock 102 165 511 minecraft:smooth_basalt
setblock 102 165 551 minecraft:smooth_basalt
fill 103 165 511 106 165 511 minecraft:blackstone
setblock 103 165 550 minecraft:smooth_basalt
fill 103 165 551 106 165 551 minecraft:blackstone
fill 104 165 550 105 165 550 minecraft:blackstone
setblock 107 165 511 minecraft:smooth_basalt
setblock 107 165 551 minecraft:smooth_basalt
fill 108 165 511 108 168 511 minecraft:blackstone
setblock 108 165 551 minecraft:blackstone
fill 115 165 511 116 165 511 minecraft:blackstone
setblock 117 165 511 minecraft:smooth_basalt
fill 117 165 512 120 165 512 minecraft:blackstone
fill 118 165 511 121 165 511 minecraft:blackstone
fill 118 165 551 121 165 551 minecraft:blackstone
setblock 120 165 513 minecraft:smooth_basalt
setblock 121 165 512 minecraft:smooth_basalt
fill 121 165 513 124 165 513 minecraft:blackstone
fill 121 165 550 122 165 550 minecraft:blackstone
setblock 122 165 511 minecraft:smooth_basalt
fill 122 165 512 125 165 512 minecraft:blackstone
setblock 122 165 551 minecraft:smooth_basalt
fill 123 165 511 126 165 511 minecraft:blackstone
setblock 123 165 550 minecraft:smooth_basalt
fill 123 165 551 126 165 551 minecraft:blackstone
fill 124 165 550 127 165 550 minecraft:blackstone
setblock 125 165 513 minecraft:smooth_basalt
setblock 126 165 512 minecraft:smooth_basalt
fill 126 165 513 126 168 513 minecraft:blackstone
setblock 127 165 511 minecraft:smooth_basalt
fill 127 165 512 127 168 512 minecraft:blackstone
setblock 127 165 551 minecraft:smooth_basalt
fill 128 165 511 131 165 511 minecraft:blackstone
setblock 128 165 550 minecraft:smooth_basalt
fill 128 165 551 131 165 551 minecraft:blackstone
setblock 129 165 550 minecraft:blackstone
setblock 131 165 512 minecraft:smooth_basalt
setblock 132 165 511 minecraft:smooth_basalt
setblock 132 165 551 minecraft:smooth_basalt
fill 133 165 511 133 168 511 minecraft:blackstone
fill 133 165 551 133 168 551 minecraft:blackstone
setblock 135 165 513 minecraft:smooth_basalt
setblock 135 165 548 minecraft:smooth_basalt
fill 135 165 549 135 168 549 minecraft:blackstone
setblock 95 166 511 minecraft:blackstone
fill 95 166 529 95 166 531 minecraft:blackstone
setblock 95 166 532 minecraft:smooth_basalt
fill 95 166 533 96 168 533 minecraft:blackstone
setblock 95 166 537 minecraft:smooth_basalt
fill 95 166 538 95 168 539 minecraft:blackstone
setblock 95 166 546 minecraft:blackstone
setblock 95 166 547 minecraft:smooth_basalt
fill 95 166 548 95 169 548 minecraft:blackstone
setblock 96 166 511 minecraft:smooth_basalt
setblock 96 166 531 minecraft:smooth_basalt
fill 96 166 532 96 169 532 minecraft:blackstone
fill 96 166 534 96 166 535 minecraft:blackstone
setblock 96 166 536 minecraft:smooth_basalt
setblock 96 166 550 minecraft:blackstone
setblock 96 166 551 minecraft:smooth_basalt
fill 97 166 511 100 166 511 minecraft:blackstone
setblock 97 166 550 minecraft:smooth_basalt
fill 97 166 551 100 166 551 minecraft:blackstone
fill 98 166 550 101 166 550 minecraft:blackstone
setblock 100 166 512 minecraft:smooth_basalt
setblock 101 166 511 minecraft:smooth_basalt
fill 101 166 512 104 166 512 minecraft:blackstone
setblock 101 166 551 minecraft:smooth_basalt
fill 102 166 511 105 166 511 minecraft:blackstone
setblock 102 166 550 minecraft:smooth_basalt
fill 102 166 551 105 166 551 minecraft:blackstone
fill 103 166 550 104 167 550 minecraft:blackstone
setblock 106 166 511 minecraft:smooth_basalt
setblock 106 166 551 minecraft:smooth_basalt
fill 107 166 511 107 169 511 minecraft:blackstone
fill 107 166 551 107 167 551 minecraft:blackstone
fill 109 166 511 109 167 511 minecraft:blackstone
fill 113 166 511 115 166 511 minecraft:blackstone
setblock 116 166 511 minecraft:smooth_basalt
fill 116 166 512 119 166 512 minecraft:blackstone
fill 117 166 511 120 166 511 minecraft:blackstone
fill 117 166 525 120 171 527 minecraft:smooth_basalt
fill 117 166 551 120 166 551 minecraft:blackstone
fill 118 166 524 119 172 524 minecraft:smooth_basalt
setblock 119 166 513 minecraft:smooth_basalt
setblock 120 166 512 minecraft:smooth_basalt
fill 120 166 513 123 166 513 minecraft:blackstone
fill 120 166 550 121 166 550 minecraft:blackstone
setblock 121 166 511 minecraft:smooth_basalt
fill 121 166 512 124 166 512 minecraft:blackstone
setblock 121 166 551 minecraft:smooth_basalt
fill 122 166 511 125 166 511 minecraft:blackstone
setblock 122 166 550 minecraft:smooth_basalt
fill 122 166 551 125 166 551 minecraft:blackstone
fill 123 166 550 126 166 550 minecraft:blackstone
setblock 124 166 513 minecraft:smooth_basalt
setblock 125 166 512 minecraft:smooth_basalt
fill 125 166 513 125 169 513 minecraft:blackstone
setblock 126 166 511 minecraft:smooth_basalt
fill 126 166 512 126 169 512 minecraft:blackstone
setblock 126 166 551 minecraft:smooth_basalt
fill 127 166 511 130 166 511 minecraft:blackstone
setblock 127 166 550 minecraft:smooth_basalt
fill 127 166 551 130 166 551 minecraft:blackstone
fill 128 166 512 129 166 512 minecraft:blackstone
fill 128 166 550 128 168 550 minecraft:blackstone
setblock 130 166 512 minecraft:smooth_basalt
setblock 131 166 511 minecraft:smooth_basalt
fill 131 166 512 131 169 512 minecraft:blackstone
setblock 131 166 551 minecraft:smooth_basalt
fill 132 166 511 132 169 511 minecraft:blackstone
fill 132 166 551 132 169 551 minecraft:blackstone
setblock 135 166 512 minecraft:smooth_basalt
fill 135 166 513 135 168 514 minecraft:blackstone
setblock 135 166 547 minecraft:smooth_basalt
fill 135 166 548 135 169 548 minecraft:blackstone
setblock 95 167 511 minecraft:smooth_basalt
fill 95 167 512 95 169 513 minecraft:blackstone
fill 95 167 529 95 167 530 minecraft:blackstone
setblock 95 167 531 minecraft:smooth_basalt
fill 95 167 532 95 170 532 minecraft:blackstone
fill 95 167 534 95 167 535 minecraft:blackstone
setblock 95 167 536 minecraft:smooth_basalt
fill 95 167 537 97 168 537 minecraft:blackstone
setblock 95 167 540 minecraft:blackstone
setblock 95 167 541 minecraft:smooth_basalt
fill 95 167 542 95 167 545 minecraft:blackstone
setblock 95 167 546 minecraft:smooth_basalt
fill 95 167 547 95 170 547 minecraft:blackstone
fill 95 167 549 95 167 550 minecraft:blackstone
setblock 95 167 551 minecraft:smooth_basalt
fill 96 167 511 99 167 511 minecraft:blackstone
setblock 96 167 530 minecraft:smooth_basalt
fill 96 167 531 97 169 531 minecraft:blackstone
setblock 96 167 534 minecraft:blackstone
setblock 96 167 535 minecraft:smooth_basalt
fill 96 167 536 97 169 536 minecraft:blackstone
fill 96 167 538 96 167 539 minecraft:blackstone
setblock 96 167 550 minecraft:smooth_basalt
fill 96 167 551 99 167 551 minecraft:blackstone
fill 97 167 532 97 167 533 minecraft:blackstone
setblock 97 167 534 minecraft:smooth_basalt
fill 97 167 535 97 170 535 minecraft:blackstone
fill 97 167 550 100 167 550 minecraft:blackstone
setblock 98 167 512 minecraft:blackstone
setblock 99 167 512 minecraft:smooth_basalt
setblock 100 167 511 minecraft:smooth_basalt
fill 100 167 512 103 167 512 minecraft:blackstone
setblock 100 167 551 minecraft:smooth_basalt
fill 101 167 511 104 167 511 minecraft:blackstone
setblock 101 167 550 minecraft:smooth_basalt
fill 101 167 551 104 167 551 minecraft:blackstone
fill 102 167 550 102 170 550 minecraft:blackstone
setblock 104 167 512 minecraft:smooth_basalt
setblock 105 167 511 minecraft:smooth_basalt
fill 105 167 512 105 170 512 minecraft:blackstone
setblock 105 167 551 minecraft:smooth_basalt
fill 106 167 511 106 170 511 minecraft:blackstone
fill 106 167 551 106 168 551 minecraft:blackstone
setblock 110 167 511 minecraft:smooth_basalt
fill 111 167 511 114 167 511 minecraft:blackstone
setblock 115 167 511 minecraft:smooth_basalt
fill 115 167 512 118 167 512 minecraft:blackstone
fill 116 167 511 119 167 511 minecraft:blackstone
fill 116 167 525 116 168 527 minecraft:blackstone
fill 116 167 551 119 167 551 minecraft:blackstone
setblock 117 167 513 minecraft:blackstone
fill 117 167 524 117 168 524 minecraft:blackstone
fill 117 167 528 120 168 528 minecraft:blackstone
setblock 118 167 513 minecraft:smooth_basalt
setblock 119 167 512 minecraft:smooth_basalt
fill 119 167 513 122 167 513 minecraft:blackstone
fill 119 167 523 119 168 523 minecraft:blackstone
setblock 120 167 511 minecraft:smooth_basalt
fill 120 167 512 123 167 512 minecraft:blackstone
fill 120 167 514 121 167 514 minecraft:blackstone
fill 120 167 524 120 168 524 minecraft:blackstone
setblock 120 167 550 minecraft:blackstone
setblock 120 167 551 minecraft:smooth_basalt
fill 121 167 511 124 167 511 minecraft:blackstone
fill 121 167 525 121 168 527 minecraft:blackstone
setblock 121 167 550 minecraft:smooth_basalt
fill 121 167 551 124 167 551 minecraft:blackstone
setblock 122 167 514 minecraft:smooth_basalt
fill 122 167 550 125 167 550 minecraft:blackstone
setblock 123 167 513 minecraft:smooth_basalt
fill 123 167 514 124 169 514 minecraft:blackstone
setblock 124 167 512 minecraft:smooth_basalt
fill 124 167 513 124 170 513 minecraft:blackstone
setblock 125 167 511 minecraft:smooth_basalt
fill 125 167 512 125 170 512 minecraft:blackstone
setblock 125 167 551 minecraft:smooth_basalt
fill 126 167 511 129 167 511 minecraft:blackstone
setblock 126 167 550 minecraft:smooth_basalt
fill 126 167 551 129 167 551 minecraft:blackstone
fill 127 167 550 127 169 550 minecraft:blackstone
setblock 128 167 512 minecraft:blackstone
setblock 128 167 513 minecraft:smooth_basalt
setblock 129 167 512 minecraft:smooth_basalt
setblock 130 167 511 minecraft:smooth_basalt
fill 130 167 512 130 170 512 minecraft:blackstone
setblock 130 167 551 minecraft:smooth_basalt
fill 131 167 511 131 170 511 minecraft:blackstone
fill 131 167 551 131 170 551 minecraft:blackstone
fill 132 167 512 133 167 512 minecraft:blackstone
setblock 134 167 511 minecraft:blackstone
setblock 134 167 512 minecraft:smooth_basalt
fill 134 167 550 134 167 551 minecraft:blackstone
setblock 135 167 511 minecraft:smooth_basalt
fill 135 167 512 135 170 512 minecraft:blackstone
setblock 135 167 515 minecraft:blackstone
fill 135 167 532 135 167 535 minecraft:blackstone
setblock 135 167 536 minecraft:smooth_basalt
fill 135 167 547 135 170 547 minecraft:blackstone
setblock 135 167 551 minecraft:smooth_basalt
fill 95 168 511 98 168 511 minecraft:blackstone
setblock 95 168 514 minecraft:blackstone
setblock 95 168 515 minecraft:smooth_basalt
fill 95 168 528 95 168 529 minecraft:blackstone
setblock 95 168 530 minecraft:smooth_basalt
fill 95 168 531 95 171 531 minecraft:blackstone
setblock 95 168 534 minecraft:blackstone
setblock 95 168 535 minecraft:smooth_basalt
fill 95 168 536 95 171 536 minecraft:blackstone
setblock 95 168 540 minecraft:smooth_basalt
fill 95 168 541 95 168 544 minecraft:blackstone
setblock 95 168 545 minecraft:smooth_basalt
fill 95 168 546 95 171 546 minecraft:blackstone
setblock 95 168 549 minecraft:blackstone
setblock 95 168 550 minecraft:smooth_basalt
fill 95 168 551 98 168 551 minecraft:blackstone
setblock 96 168 529 minecraft:smooth_basalt
fill 96 168 530 97 170 530 minecraft:blackstone
setblock 96 168 534 minecraft:smooth_basalt
fill 96 168 535 96 171 535 minecraft:blackstone
setblock 96 168 538 minecraft:blackstone
setblock 96 168 539 minecraft:smooth_basalt
fill 96 168 540 96 170 541 minecraft:blackstone
setblock 96 168 549 minecraft:smooth_basalt
fill 96 168 550 99 168 550 minecraft:blackstone
setblock 97 168 512 minecraft:blackstone
setblock 97 168 513 minecraft:light[level=12]
setblock 97 168 521 minecraft:light[level=12]
setblock 97 168 529 minecraft:light[level=12]
setblock 97 168 532 minecraft:blackstone
setblock 97 168 533 minecraft:smooth_basalt
fill 97 168 534 98 170 534 minecraft:blackstone
setblock 97 168 538 minecraft:smooth_basalt
fill 97 168 539 97 171 539 minecraft:blackstone
setblock 97 168 545 minecraft:light[level=12]
setblock 98 168 512 minecraft:smooth_basalt
setblock 98 168 532 minecraft:smooth_basalt
fill 98 168 533 98 171 533 minecraft:blackstone
fill 98 168 535 98 168 536 minecraft:blackstone
setblock 98 168 537 minecraft:smooth_basalt
setblock 99 168 511 minecraft:smooth_basalt
fill 99 168 512 102 168 512 minecraft:blackstone
setblock 99 168 551 minecraft:smooth_basalt
fill 100 168 511 103 168 511 minecraft:blackstone
setblock 100 168 550 minecraft:smooth_basalt
fill 100 168 551 103 168 551 minecraft:blackstone
fill 101 168 550 101 170 550 minecraft:blackstone
setblock 103 168 512 minecraft:smooth_basalt
setblock 103 168 550 minecraft:blackstone
setblock 104 168 511 minecraft:smooth_basalt
fill 104 168 512 104 171 512 minecraft:blackstone
setblock 104 168 551 minecraft:smooth_basalt
fill 105 168 511 105 171 511 minecraft:blackstone
setblock 105 168 513 minecraft:light[level=12]
setblock 105 168 521 minecraft:light[level=12]
setblock 105 168 529 minecraft:light[level=12]
setblock 105 168 537 minecraft:light[level=12]
setblock 105 168 545 minecraft:light[level=12]
fill 105 168 551 105 170 551 minecraft:blackstone
fill 106 168 512 106 169 512 minecraft:blackstone
setblock 109 168 511 minecraft:smooth_basalt
fill 110 168 511 113 168 511 minecraft:blackstone
setblock 113 168 513 minecraft:light[level=12]
setblock 113 168 521 minecraft:light[level=12]
setblock 113 168 537 minecraft:light[level=12]
setblock 113 168 545 minecraft:light[level=12]
setblock 114 168 511 minecraft:smooth_basalt
fill 114 168 512 117 168 512 minecraft:blackstone
fill 115 168 511 118 168 511 minecraft:blackstone
fill 115 168 525 115 168 526 minecraft:blackstone
setblock 116 168 513 minecraft:blackstone
setblock 116 168 524 minecraft:blackstone
setblock 116 168 528 minecraft:blackstone
fill 116 168 551 118 168 551 minecraft:blackstone
setblock 117 168 513 minecraft:smooth_basalt
fill 117 168 523 118 168 523 minecraft:blackstone
fill 117 168 529 120 168 529 minecraft:blackstone
setblock 118 168 512 minecraft:smooth_basalt
fill 118 168 513 120 168 514 minecraft:blackstone
setblock 119 168 511 minecraft:smooth_basalt
fill 119 168 512 122 168 512 minecraft:blackstone
setblock 119 168 550 minecraft:blackstone
setblock 119 168 551 minecraft:smooth_basalt
fill 120 168 511 123 168 511 minecraft:blackstone
fill 120 168 523 121 168 523 minecraft:blackstone
setblock 120 168 550 minecraft:smooth_basalt
fill 120 168 551 123 168 551 minecraft:blackstone
setblock 121 168 513 minecraft:blackstone
setblock 121 168 514 minecraft:smooth_basalt
setblock 121 168 521 minecraft:light[level=12]
setblock 121 168 524 minecraft:blackstone
setblock 121 168 528 minecraft:blackstone
setblock 121 168 537 minecraft:light[level=12]
setblock 121 168 545 minecraft:light[level=12]
fill 121 168 550 124 168 550 minecraft:blackstone
setblock 122 168 513 minecraft:smooth_basalt
fill 122 168 514 122 171 514 minecraft:blackstone
fill 122 168 525 122 168 527 minecraft:blackstone
setblock 123 168 512 minecraft:smooth_basalt
fill 123 168 513 123 171 513 minecraft:blackstone
setblock 124 168 511 minecraft:smooth_basalt
fill 124 168 512 124 171 512 minecraft:blackstone
setblock 124 168 551 minecraft:smooth_basalt
fill 125 168 511 128 168 511 minecraft:blackstone
setblock 125 168 514 minecraft:blackstone
setblock 125 168 550 minecraft:smooth_basalt
fill 125 168 551 128 168 551 minecraft:blackstone
fill 126 168 550 126 170 550 minecraft:blackstone
setblock 127 168 513 minecraft:smooth_basalt
setblock 128 168 512 minecraft:smooth_basalt
fill 128 168 513 128 171 513 minecraft:blackstone
setblock 129 168 511 minecraft:smooth_basalt
fill 129 168 512 129 171 512 minecraft:blackstone
setblock 129 168 513 minecraft:light[level=12]
setblock 129 168 521 minecraft:light[level=12]
setblock 129 168 529 minecraft:light[level=12]
setblock 129 168 537 minecraft:light[level=12]
setblock 129 168 545 minecraft:light[level=12]
setblock 129 168 551 minecraft:smooth_basalt
fill 130 168 511 130 171 511 minecraft:blackstone
fill 130 168 551 130 171 551 minecraft:blackstone
setblock 132 168 512 minecraft:blackstone
setblock 133 168 512 minecraft:smooth_basalt
setblock 134 168 511 minecraft:smooth_basalt
fill 134 168 512 134 170 513 minecraft:blackstone
setblock 134 168 550 minecraft:blackstone
setblock 134 168 551 minecraft:smooth_basalt
fill 135 168 511 135 171 511 minecraft:blackstone
setblock 135 168 515 minecraft:smooth_basalt
fill 135 168 516 135 171 516 minecraft:blackstone
fill 135 168 531 135 168 534 minecraft:blackstone
setblock 135 168 535 minecraft:smooth_basalt
fill 135 168 536 135 168 539 minecraft:blackstone
setblock 135 168 540 minecraft:smooth_basalt
fill 135 168 541 135 171 541 minecraft:blackstone
setblock 135 168 545 minecraft:smooth_basalt
fill 135 168 546 135 171 546 minecraft:blackstone
setblock 135 168 550 minecraft:smooth_basalt
fill 135 168 551 135 171 551 minecraft:blackstone
fill 95 169 511 97 169 511 minecraft:blackstone
setblock 95 169 514 minecraft:smooth_basalt
fill 95 169 515 95 171 516 minecraft:blackstone
fill 95 169 527 95 169 528 minecraft:blackstone
setblock 95 169 529 minecraft:smooth_basalt
fill 95 169 530 95 172 530 minecraft:blackstone
setblock 95 169 533 minecraft:blackstone
setblock 95 169 534 minecraft:smooth_basalt
fill 95 169 535 95 172 535 minecraft:blackstone
fill 95 169 537 95 169 538 minecraft:blackstone
setblock 95 169 539 minecraft:smooth_basalt
fill 95 169 540 95 169 543 minecraft:blackstone
setblock 95 169 544 minecraft:smooth_basalt
fill 95 169 545 95 172 545 minecraft:blackstone
setblock 95 169 549 minecraft:smooth_basalt
fill 95 169 550 97 169 551 minecraft:blackstone
setblock 96 169 512 minecraft:blackstone
fill 96 169 513 99 169 513 minecraft:smooth_basalt
fill 96 169 514 96 172 514 minecraft:blackstone
fill 96 169 529 96 172 529 minecraft:blackstone
setblock 96 169 533 minecraft:smooth_basalt
fill 96 169 534 96 172 534 minecraft:blackstone
setblock 96 169 537 minecraft:blackstone
setblock 96 169 538 minecraft:smooth_basalt
fill 96 169 539 96 172 539 minecraft:blackstone
setblock 96 169 542 minecraft:blackstone
setblock 96 169 543 minecraft:smooth_basalt
fill 96 169 544 96 172 544 minecraft:blackstone
setblock 96 169 548 minecraft:smooth_basalt
fill 96 169 549 96 172 549 minecraft:blackstone
setblock 97 169 512 minecraft:smooth_basalt
fill 97 169 514 98 171 515 minecraft:smooth_basalt
setblock 97 169 532 minecraft:smooth_basalt
fill 97 169 533 97 172 533 minecraft:blackstone
setblock 97 169 537 minecraft:smooth_basalt
fill 97 169 538 98 171 538 minecraft:blackstone
fill 97 169 540 97 169 541 minecraft:blackstone
setblock 98 169 511 minecraft:smooth_basalt
fill 98 169 512 101 169 512 minecraft:blackstone
setblock 98 169 531 minecraft:smooth_basalt
fill 98 169 532 98 172 532 minecraft:blackstone
setblock 98 169 535 minecraft:blackstone
setblock 98 169 536 minecraft:smooth_basalt
fill 98 169 537 98 172 537 minecraft:blackstone
fill 98 169 539 98 170 539 minecraft:blackstone
setblock 98 169 550 minecraft:blackstone
setblock 98 169 551 minecraft:smooth_basalt
fill 99 169 511 102 169 511 minecraft:blackstone
fill 99 169 514 99 198 514 minecraft:smooth_basalt
setblock 99 169 534 minecraft:blackstone
setblock 99 169 535 minecraft:smooth_basalt
setblock 99 169 550 minecraft:smooth_basalt
fill 99 169 551 102 169 551 minecraft:blackstone
setblock 100 169 513 minecraft:blackstone
fill 100 169 550 100 171 550 minecraft:blackstone
setblock 101 169 513 minecraft:smooth_basalt
setblock 102 169 512 minecraft:smooth_basalt
fill 102 169 513 102 171 513 minecraft:blackstone
setblock 103 169 511 minecraft:smooth_basalt
fill 103 169 512 103 172 512 minecraft:blackstone
setblock 103 169 551 minecraft:smooth_basalt
fill 104 169 511 104 172 511 minecraft:blackstone
fill 104 169 551 104 171 551 minecraft:blackstone
setblock 108 169 511 minecraft:smooth_basalt
fill 109 169 511 112 169 511 minecraft:blackstone
setblock 112 169 512 minecraft:smooth_basalt
setblock 113 169 511 minecraft:smooth_basalt
fill 113 169 512 116 169 512 minecraft:blackstone
fill 114 169 511 117 169 511 minecraft:blackstone
setblock 115 169 513 minecraft:blackstone
fill 115 169 551 117 169 551 minecraft:blackstone
setblock 116 169 513 minecraft:smooth_basalt
setblock 117 169 512 minecraft:smooth_basalt
fill 117 169 513 119 169 514 minecraft:blackstone
setblock 118 169 511 minecraft:smooth_basalt
fill 118 169 512 121 169 512 minecraft:blackstone
setblock 118 169 550 minecraft:blackstone
setblock 118 169 551 minecraft:smooth_basalt
fill 119 169 511 122 169 511 minecraft:blackstone
setblock 119 169 550 minecraft:smooth_basalt
fill 119 169 551 122 169 551 minecraft:blackstone
setblock 120 169 513 minecraft:blackstone
setblock 120 169 514 minecraft:smooth_basalt
fill 120 169 550 123 169 550 minecraft:blackstone
setblock 121 169 513 minecraft:smooth_basalt
fill 121 169 514 121 172 514 minecraft:blackstone
setblock 122 169 512 minecraft:smooth_basalt
fill 122 169 513 122 172 513 minecraft:blackstone
setblock 123 169 511 minecraft:smooth_basalt
fill 123 169 512 123 172 512 minecraft:blackstone
setblock 123 169 551 minecraft:smooth_basalt
fill 124 169 511 127 169 511 minecraft:blackstone
setblock 124 169 550 minecraft:smooth_basalt
fill 124 169 551 127 169 551 minecraft:blackstone
setblock 125 169 514 minecraft:smooth_basalt
fill 125 169 550 125 171 550 minecraft:blackstone
setblock 126 169 513 minecraft:smooth_basalt
setblock 127 169 512 minecraft:smooth_basalt
fill 127 169 513 127 171 513 minecraft:blackstone
setblock 128 169 511 minecraft:smooth_basalt
fill 128 169 512 128 172 512 minecraft:blackstone
setblock 128 169 551 minecraft:smooth_basalt
fill 129 169 511 129 172 511 minecraft:blackstone
fill 129 169 551 129 172 551 minecraft:blackstone
setblock 132 169 512 minecraft:smooth_basalt
setblock 133 169 511 minecraft:smooth_basalt
fill 133 169 512 133 172 512 minecraft:blackstone
setblock 133 169 550 minecraft:blackstone
setblock 133 169 551 minecraft:smooth_basalt
fill 134 169 511 134 172 511 minecraft:blackstone
setblock 134 169 514 minecraft:blackstone
setblock 134 169 515 minecraft:smooth_basalt
setblock 134 169 549 minecraft:blackstone
setblock 134 169 550 minecraft:smooth_basalt
fill 134 169 551 134 172 551 minecraft:blackstone
setblock 135 169 513 minecraft:blackstone
setblock 135 169 514 minecraft:smooth_basalt
fill 135 169 515 135 172 515 minecraft:blackstone
fill 135 169 517 135 170 517 minecraft:blackstone
fill 135 169 530 135 169 533 minecraft:blackstone
setblock 135 169 534 minecraft:smooth_basalt
fill 135 169 535 135 169 538 minecraft:blackstone
setblock 135 169 539 minecraft:smooth_basalt
fill 135 169 540 135 172 540 minecraft:blackstone
fill 135 169 542 135 169 543 minecraft:blackstone
setblock 135 169 544 minecraft:smooth_basalt
fill 135 169 545 135 172 545 minecraft:blackstone
setblock 135 169 549 minecraft:smooth_basalt
fill 135 169 550 135 172 550 minecraft:blackstone
fill 95 170 511 95 170 512 minecraft:blackstone
setblock 95 170 513 minecraft:smooth_basalt
fill 95 170 514 95 173 514 minecraft:blackstone
setblock 95 170 517 minecraft:blackstone
setblock 95 170 518 minecraft:smooth_basalt
setblock 95 170 527 minecraft:blackstone
setblock 95 170 528 minecraft:smooth_basalt
fill 95 170 529 95 173 529 minecraft:blackstone
setblock 95 170 533 minecraft:smooth_basalt
fill 95 170 534 95 173 534 minecraft:blackstone
setblock 95 170 537 minecraft:blackstone
setblock 95 170 538 minecraft:smooth_basalt
fill 95 170 539 95 170 542 minecraft:blackstone
setblock 95 170 543 minecraft:smooth_basalt
fill 95 170 544 95 173 544 minecraft:blackstone
setblock 95 170 548 minecraft:smooth_basalt
fill 95 170 549 95 171 551 minecraft:blackstone
setblock 96 170 511 minecraft:blackstone
setblock 96 170 512 minecraft:smooth_basalt
fill 96 170 513 96 173 513 minecraft:blackstone
fill 96 170 515 96 170 516 minecraft:blackstone
fill 96 170 528 96 173 528 minecraft:blackstone
setblock 96 170 531 minecraft:blackstone
setblock 96 170 532 minecraft:smooth_basalt
fill 96 170 533 96 173 533 minecraft:blackstone
setblock 96 170 536 minecraft:blackstone
setblock 96 170 537 minecraft:smooth_basalt
fill 96 170 538 96 173 538 minecraft:blackstone
setblock 96 170 542 minecraft:smooth_basalt
fill 96 170 543 96 173 543 minecraft:blackstone
fill 96 170 545 96 170 546 minecraft:blackstone
setblock 96 170 547 minecraft:smooth_basalt
fill 96 170 548 96 172 548 minecraft:blackstone
fill 96 170 550 96 170 551 minecraft:blackstone
setblock 97 170 511 minecraft:smooth_basalt
fill 97 170 512 100 170 512 minecraft:blackstone
fill 97 170 513 97 198 513 minecraft:smooth_basalt
fill 97 170 516 98 171 516 minecraft:blackstone
fill 97 170 529 97 171 529 minecraft:blackstone
setblock 97 170 531 minecraft:smooth_basalt
fill 97 170 532 97 173 532 minecraft:blackstone
setblock 97 170 536 minecraft:smooth_basalt
fill 97 170 537 97 173 537 minecraft:blackstone
setblock 97 170 540 minecraft:blackstone
setblock 97 170 541 minecraft:smooth_basalt
fill 97 170 542 97 173 542 minecraft:blackstone
setblock 97 170 550 minecraft:blackstone
setblock 97 170 551 minecraft:smooth_basalt
fill 98 170 511 101 170 511 minecraft:blackstone
fill 98 170 513 99 170 513 minecraft:blackstone
fill 98 170 531 98 172 531 minecraft:blackstone
setblock 98 170 535 minecraft:smooth_basalt
fill 98 170 536 99 172 536 minecraft:blackstone
setblock 98 170 540 minecraft:smooth_basalt
setblock 98 170 550 minecraft:smooth_basalt
fill 98 170 551 101 170 551 minecraft:blackstone
fill 99 170 515 100 171 515 minecraft:blackstone
setblock 99 170 533 minecraft:blackstone
setblock 99 170 534 minecraft:smooth_basalt
fill 99 170 535 99 173 535 minecraft:blackstone
fill 99 170 537 99 171 537 minecraft:blackstone
fill 99 170 550 99 172 550 minecraft:blackstone
setblock 100 170 513 minecraft:smooth_basalt
fill 100 170 514 100 171 514 minecraft:blackstone
setblock 101 170 512 minecraft:smooth_basalt
fill 101 170 513 101 172 513 minecraft:blackstone
setblock 102 170 511 minecraft:smooth_basalt
fill 102 170 512 102 173 512 minecraft:blackstone
setblock 102 170 551 minecraft:smooth_basalt
fill 103 170 511 103 173 511 minecraft:blackstone
fill 103 170 551 103 171 551 minecraft:blackstone
setblock 106 170 512 minecraft:smooth_basalt
setblock 107 170 511 minecraft:smooth_basalt
fill 108 170 511 111 170 511 minecraft:blackstone
setblock 111 170 512 minecraft:smooth_basalt
setblock 112 170 511 minecraft:smooth_basalt
fill 112 170 512 115 170 512 minecraft:blackstone
fill 113 170 511 116 170 511 minecraft:blackstone
setblock 114 170 513 minecraft:blackstone
setblock 115 170 513 minecraft:smooth_basalt
fill 115 170 551 116 170 551 minecraft:blackstone
setblock 116 170 512 minecraft:smooth_basalt
fill 116 170 513 118 170 514 minecraft:blackstone
setblock 117 170 511 minecraft:smooth_basalt
fill 117 170 512 120 170 512 minecraft:blackstone
setblock 117 170 551 minecraft:smooth_basalt
fill 118 170 511 121 170 511 minecraft:blackstone
setblock 118 170 550 minecraft:smooth_basalt
fill 118 170 551 121 170 551 minecraft:blackstone
setblock 119 170 513 minecraft:blackstone
setblock 119 170 514 minecraft:smooth_basalt
fill 119 170 515 122 170 515 minecraft:blackstone
fill 119 170 550 122 170 550 minecraft:blackstone
setblock 120 170 513 minecraft:smooth_basalt
fill 120 170 514 120 173 514 minecraft:blackstone
setblock 121 170 512 minecraft:smooth_basalt
fill 121 170 513 121 173 513 minecraft:blackstone
setblock 122 170 511 minecraft:smooth_basalt
fill 122 170 512 122 173 512 minecraft:blackstone
setblock 122 170 551 minecraft:smooth_basalt
fill 123 170 511 126 170 511 minecraft:blackstone
setblock 123 170 514 minecraft:blackstone
setblock 123 170 550 minecraft:smooth_basalt
fill 123 170 551 126 170 551 minecraft:blackstone
setblock 124 170 514 minecraft:smooth_basalt
fill 124 170 550 124 171 550 minecraft:blackstone
setblock 125 170 513 minecraft:smooth_basalt
fill 125 170 514 125 171 514 minecraft:blackstone
setblock 126 170 512 minecraft:smooth_basalt
fill 126 170 513 126 172 513 minecraft:blackstone
setblock 127 170 511 minecraft:smooth_basalt
fill 127 170 512 127 173 512 minecraft:blackstone
setblock 127 170 551 minecraft:smooth_basalt
fill 128 170 511 128 173 511 minecraft:blackstone
fill 128 170 551 128 173 551 minecraft:blackstone
setblock 131 170 512 minecraft:smooth_basalt
setblock 132 170 511 minecraft:smooth_basalt
fill 132 170 512 132 173 512 minecraft:blackstone
setblock 132 170 551 minecraft:smooth_basalt
fill 133 170 511 133 173 511 minecraft:blackstone
setblock 133 170 550 minecraft:smooth_basalt
fill 133 170 551 133 173 551 minecraft:blackstone
setblock 134 170 514 minecraft:smooth_basalt
fill 134 170 515 134 172 516 minecraft:blackstone
setblock 134 170 533 minecraft:blackstone
setblock 134 170 534 minecraft:smooth_basalt
fill 134 170 535 134 170 538 minecraft:blackstone
setblock 134 170 539 minecraft:smooth_basalt
fill 134 170 540 134 173 540 minecraft:blackstone
setblock 134 170 549 minecraft:smooth_basalt
fill 134 170 550 134 173 550 minecraft:blackstone
setblock 135 170 513 minecraft:smooth_basalt
fill 135 170 514 135 173 514 minecraft:blackstone
setblock 135 170 518 minecraft:smooth_basalt
fill 135 170 530 135 170 532 minecraft:blackstone
setblock 135 170 533 minecraft:smooth_basalt
fill 135 170 534 135 170 537 minecraft:blackstone
setblock 135 170 538 minecraft:smooth_basalt
fill 135 170 539 135 173 539 minecraft:blackstone
setblock 135 170 542 minecraft:blackstone
setblock 135 170 543 minecraft:smooth_basalt
fill 135 170 544 135 173 544 minecraft:blackstone
setblock 135 170 548 minecraft:smooth_basalt
fill 135 170 549 135 173 549 minecraft:blackstone
setblock 95 171 511 minecraft:blackstone
setblock 95 171 512 minecraft:smooth_basalt
fill 95 171 513 95 174 513 minecraft:blackstone
setblock 95 171 517 minecraft:smooth_basalt
fill 95 171 518 95 171 521 minecraft:blackstone
setblock 95 171 526 minecraft:blackstone
setblock 95 171 527 minecraft:smooth_basalt
fill 95 171 528 95 174 528 minecraft:blackstone
setblock 95 171 532 minecraft:smooth_basalt
fill 95 171 533 95 174 533 minecraft:blackstone
setblock 95 171 537 minecraft:smooth_basalt
fill 95 171 538 95 171 541 minecraft:blackstone
setblock 95 171 542 minecraft:smooth_basalt
fill 95 171 543 95 174 543 minecraft:blackstone
setblock 95 171 547 minecraft:smooth_basalt
fill 95 171 548 95 174 548 minecraft:blackstone
setblock 96 171 511 minecraft:smooth_basalt
fill 96 171 512 99 171 512 minecraft:blackstone
setblock 96 171 515 minecraft:blackstone
setblock 96 171 516 minecraft:smooth_basalt
fill 96 171 517 96 173 518 minecraft:blackstone
setblock 96 171 530 minecraft:blackstone
setblock 96 171 531 minecraft:smooth_basalt
fill 96 171 532 96 174 532 minecraft:blackstone
setblock 96 171 536 minecraft:smooth_basalt
fill 96 171 537 96 174 537 minecraft:blackstone
setblock 96 171 540 minecraft:blackstone
setblock 96 171 541 minecraft:smooth_basalt
fill 96 171 542 96 174 542 minecraft:blackstone
setblock 96 171 545 minecraft:blackstone
setblock 96 171 546 minecraft:smooth_basalt
fill 96 171 547 96 173 547 minecraft:blackstone
setblock 96 171 550 minecraft:blackstone
setblock 96 171 551 minecraft:smooth_basalt
fill 97 171 511 100 171 511 minecraft:blackstone
fill 97 171 517 98 171 517 minecraft:blackstone
setblock 97 171 530 minecraft:smooth_basalt
fill 97 171 531 97 174 531 minecraft:blackstone
setblock 97 171 534 minecraft:blackstone
setblock 97 171 535 minecraft:smooth_basalt
fill 97 171 536 97 174 536 minecraft:blackstone
setblock 97 171 540 minecraft:smooth_basalt
fill 97 171 541 98 173 541 minecraft:blackstone
fill 97 171 543 97 172 543 minecraft:blackstone
setblock 97 171 550 minecraft:smooth_basalt
fill 97 171 551 100 171 551 minecraft:blackstone
setblock 98 171 513 minecraft:blackstone
setblock 98 171 534 minecraft:smooth_basalt
fill 98 171 535 98 174 535 minecraft:blackstone
setblock 98 171 539 minecraft:smooth_basalt
fill 98 171 540 98 174 540 minecraft:blackstone
fill 98 171 550 98 172 550 minecraft:blackstone
setblock 99 171 513 minecraft:smooth_basalt
fill 99 171 516 100 171 516 minecraft:blackstone
setblock 99 171 533 minecraft:smooth_basalt
fill 99 171 534 99 172 534 minecraft:blackstone
setblock 99 171 538 minecraft:smooth_basalt
setblock 100 171 512 minecraft:smooth_basalt
fill 100 171 513 100 172 513 minecraft:blackstone
setblock 101 171 511 minecraft:smooth_basalt
fill 101 171 512 101 173 512 minecraft:blackstone
fill 101 171 514 101 171 515 minecraft:blackstone
setblock 101 171 551 minecraft:smooth_basalt
fill 102 171 511 102 174 511 minecraft:blackstone
fill 102 171 551 102 172 551 minecraft:blackstone
setblock 105 171 512 minecraft:smooth_basalt
setblock 106 171 511 minecraft:smooth_basalt
fill 107 171 511 110 171 511 minecraft:blackstone
setblock 111 171 511 minecraft:smooth_basalt
fill 111 171 512 114 171 512 minecraft:blackstone
fill 112 171 511 115 171 511 minecraft:blackstone
setblock 113 171 513 minecraft:blackstone
setblock 114 171 513 minecraft:smooth_basalt
setblock 115 171 512 minecraft:smooth_basalt
fill 115 171 513 117 171 514 minecraft:blackstone
setblock 115 171 551 minecraft:blackstone
setblock 116 171 511 minecraft:smooth_basalt
fill 116 171 512 119 171 512 minecraft:blackstone
setblock 116 171 551 minecraft:smooth_basalt
fill 117 171 511 120 171 511 minecraft:blackstone
fill 117 171 551 120 171 551 minecraft:blackstone
setblock 118 171 513 minecraft:blackstone
setblock 118 171 514 minecraft:smooth_basalt
fill 118 171 515 121 171 515 minecraft:blackstone
fill 118 171 550 121 171 550 minecraft:blackstone
setblock 119 171 513 minecraft:smooth_basalt
fill 119 171 514 119 174 514 minecraft:blackstone
setblock 120 171 512 minecraft:smooth_basalt
fill 120 171 513 120 174 513 minecraft:blackstone
setblock 121 171 511 minecraft:smooth_basalt
fill 121 171 512 121 174 512 minecraft:blackstone
setblock 121 171 551 minecraft:smooth_basalt
fill 122 171 511 125 171 511 minecraft:blackstone
setblock 122 171 515 minecraft:smooth_basalt
setblock 122 171 550 minecraft:smooth_basalt
fill 122 171 551 125 171 551 minecraft:blackstone
setblock 123 171 514 minecraft:smooth_basalt
fill 123 171 550 123 172 550 minecraft:blackstone
setblock 124 171 513 minecraft:smooth_basalt
fill 124 171 514 124 172 514 minecraft:blackstone
setblock 125 171 512 minecraft:smooth_basalt
fill 125 171 513 125 173 513 minecraft:blackstone
setblock 126 171 511 minecraft:smooth_basalt
fill 126 171 512 126 174 512 minecraft:blackstone
setblock 126 171 551 minecraft:smooth_basalt
fill 127 171 511 127 174 511 minecraft:blackstone
fill 127 171 551 127 173 551 minecraft:blackstone
setblock 130 171 512 minecraft:smooth_basalt
setblock 131 171 511 minecraft:smooth_basalt
fill 131 171 512 131 173 512 minecraft:blackstone
setblock 131 171 551 minecraft:smooth_basalt
fill 132 171 511 132 174 511 minecraft:blackstone
fill 132 171 551 132 174 551 minecraft:blackstone
fill 133 171 550 133 172 550 minecraft:blackstone
setblock 134 171 512 minecraft:blackstone
setblock 134 171 513 minecraft:smooth_basalt
fill 134 171 514 134 174 514 minecraft:blackstone
setblock 134 171 533 minecraft:smooth_basalt
fill 134 171 534 134 171 537 minecraft:blackstone
setblock 134 171 538 minecraft:smooth_basalt
fill 134 171 539 134 174 539 minecraft:blackstone
fill 134 171 541 134 171 542 minecraft:blackstone
setblock 134 171 543 minecraft:smooth_basalt
fill 134 171 549 134 174 549 minecraft:blackstone
setblock 135 171 512 minecraft:smooth_basalt
fill 135 171 513 135 174 513 minecraft:blackstone
setblock 135 171 517 minecraft:smooth_basalt
fill 135 171 518 135 172 520 minecraft:blackstone
fill 135 171 529 135 171 531 minecraft:blackstone
setblock 135 171 532 minecraft:smooth_basalt
fill 135 171 533 135 171 536 minecraft:blackstone
setblock 135 171 537 minecraft:smooth_basalt
fill 135 171 538 135 174 538 minecraft:blackstone
setblock 135 171 542 minecraft:smooth_basalt
fill 135 171 543 135 174 543 minecraft:blackstone
setblock 135 171 547 minecraft:smooth_basalt
fill 135 171 548 135 174 548 minecraft:blackstone
setblock 95 172 511 minecraft:smooth_basalt
fill 95 172 512 98 172 512 minecraft:blackstone
setblock 95 172 515 minecraft:blackstone
setblock 95 172 516 minecraft:smooth_basalt
fill 95 172 517 95 172 520 minecraft:blackstone
setblock 95 172 521 minecraft:smooth_basalt
fill 95 172 522 95 172 525 minecraft:blackstone
setblock 95 172 526 minecraft:smooth_basalt
fill 95 172 527 96 173 527 minecraft:blackstone
setblock 95 172 531 minecraft:smooth_basalt
fill 95 172 532 95 175 532 minecraft:blackstone
setblock 95 172 536 minecraft:smooth_basalt
fill 95 172 537 95 172 540 minecraft:blackstone
setblock 95 172 541 minecraft:smooth_basalt
fill 95 172 542 95 175 542 minecraft:blackstone
setblock 95 172 546 minecraft:smooth_basalt
fill 95 172 547 95 175 547 minecraft:blackstone
fill 95 172 549 95 172 550 minecraft:blackstone
setblock 95 172 551 minecraft:smooth_basalt
fill 96 172 511 99 172 511 minecraft:blackstone
setblock 96 172 515 minecraft:smooth_basalt
fill 96 172 516 97 174 516 minecraft:blackstone
setblock 96 172 519 minecraft:blackstone
setblock 96 172 520 minecraft:smooth_basalt
setblock 96 172 530 minecraft:smooth_basalt
fill 96 172 531 96 175 531 minecraft:blackstone
setblock 96 172 535 minecraft:smooth_basalt
fill 96 172 536 96 175 536 minecraft:blackstone
setblock 96 172 540 minecraft:smooth_basalt
fill 96 172 541 96 175 541 minecraft:blackstone
setblock 96 172 545 minecraft:smooth_basalt
fill 96 172 546 96 175 546 minecraft:blackstone
setblock 96 172 550 minecraft:smooth_basalt
fill 96 172 551 99 172 551 minecraft:blackstone
fill 97 172 514 98 198 514 minecraft:smooth_basalt
fill 97 172 515 97 173 515 minecraft:blackstone
setblock 97 172 529 minecraft:smooth_basalt
fill 97 172 530 97 173 530 minecraft:blackstone
setblock 97 172 534 minecraft:smooth_basalt
fill 97 172 535 97 175 535 minecraft:blackstone
setblock 97 172 538 minecraft:blackstone
setblock 97 172 539 minecraft:smooth_basalt
fill 97 172 540 97 175 540 minecraft:blackstone
setblock 97 172 544 minecraft:smooth_basalt
setblock 97 172 550 minecraft:blackstone
fill 98 172 513 98 197 513 minecraft:smooth_basalt
fill 98 172 515 98 200 515 minecraft:smooth_basalt
setblock 98 172 533 minecraft:smooth_basalt
fill 98 172 534 98 174 534 minecraft:blackstone
setblock 98 172 538 minecraft:smooth_basalt
fill 98 172 539 98 175 539 minecraft:blackstone
setblock 99 172 512 minecraft:smooth_basalt
setblock 99 172 513 minecraft:blackstone
setblock 99 172 537 minecraft:smooth_basalt
fill 99 172 538 99 173 538 minecraft:blackstone
setblock 100 172 511 minecraft:smooth_basalt
fill 100 172 512 100 174 512 minecraft:blackstone
setblock 100 172 551 minecraft:smooth_basalt
fill 101 172 511 101 174 511 minecraft:blackstone
fill 101 172 551 101 173 551 minecraft:blackstone
setblock 104 172 512 minecraft:smooth_basalt
setblock 105 172 511 minecraft:smooth_basalt
fill 106 172 511 109 172 511 minecraft:blackstone
setblock 110 172 511 minecraft:smooth_basalt
fill 111 172 511 113 172 512 minecraft:blackstone
fill 111 172 527 119 174 527 minecraft:jungle_leaves[persistent=true]
fill 111 172 535 119 174 535 minecraft:jungle_leaves[persistent=true]
setblock 113 172 513 minecraft:smooth_basalt
fill 113 172 526 117 179 526 minecraft:jungle_leaves[persistent=true]
fill 113 172 536 117 179 536 minecraft:jungle_leaves[persistent=true]
setblock 114 172 511 minecraft:blackstone
setblock 114 172 512 minecraft:smooth_basalt
fill 114 172 513 117 172 513 minecraft:blackstone
fill 114 172 531 114 173 531 minecraft:jungle_log
setblock 115 172 511 minecraft:smooth_basalt
fill 115 172 512 118 172 512 minecraft:blackstone
fill 115 172 514 116 172 514 minecraft:blackstone
fill 115 172 528 120 176 528 minecraft:jungle_leaves[persistent=true]
fill 115 172 534 120 176 534 minecraft:jungle_leaves[persistent=true]
setblock 115 172 551 minecraft:smooth_basalt
fill 116 172 511 119 172 511 minecraft:blackstone
fill 116 172 529 120 172 533 minecraft:jungle_leaves[persistent=true]
fill 116 172 551 119 172 551 minecraft:blackstone
setblock 117 172 514 minecraft:smooth_basalt
fill 117 172 515 120 172 515 minecraft:blackstone
fill 117 172 525 120 172 525 minecraft:smooth_basalt
setblock 118 172 513 minecraft:smooth_basalt
fill 118 172 514 118 175 514 minecraft:blackstone
fill 118 172 526 120 172 526 minecraft:smooth_basalt
fill 118 172 550 120 172 550 minecraft:blackstone
setblock 119 172 512 minecraft:smooth_basalt
fill 119 172 513 119 175 513 minecraft:blackstone
setblock 120 172 511 minecraft:smooth_basalt
fill 120 172 512 120 175 512 minecraft:blackstone
setblock 120 172 527 minecraft:smooth_basalt
setblock 120 172 551 minecraft:smooth_basalt
fill 121 172 511 124 172 511 minecraft:blackstone
setblock 121 172 515 minecraft:smooth_basalt
fill 121 172 530 121 174 532 minecraft:jungle_leaves[persistent=true]
setblock 121 172 550 minecraft:smooth_basalt
fill 121 172 551 124 172 551 minecraft:blackstone
setblock 122 172 514 minecraft:smooth_basalt
fill 122 172 530 126 172 532 minecraft:jungle_log
setblock 122 172 550 minecraft:blackstone
setblock 123 172 513 minecraft:smooth_basalt
fill 123 172 514 123 173 514 minecraft:blackstone
setblock 124 172 512 minecraft:smooth_basalt
fill 124 172 513 124 174 513 minecraft:blackstone
fill 124 172 544 125 173 544 minecraft:gilded_blackstone
setblock 125 172 511 minecraft:smooth_basalt
fill 125 172 512 125 174 512 minecraft:blackstone
setblock 125 172 551 minecraft:smooth_basalt
fill 126 172 511 126 175 511 minecraft:blackstone
fill 126 172 551 126 174 551 minecraft:blackstone
setblock 129 172 512 minecraft:smooth_basalt
setblock 130 172 511 minecraft:smooth_basalt
fill 130 172 512 130 173 512 minecraft:blackstone
setblock 130 172 551 minecraft:smooth_basalt
fill 131 172 511 131 175 511 minecraft:blackstone
fill 131 172 551 131 175 551 minecraft:blackstone
fill 132 172 531 132 173 531 minecraft:jungle_log
setblock 134 172 512 minecraft:smooth_basalt
fill 134 172 513 134 175 513 minecraft:blackstone
setblock 134 172 517 minecraft:smooth_basalt
fill 134 172 533 134 172 536 minecraft:blackstone
setblock 134 172 537 minecraft:smooth_basalt
fill 134 172 538 134 175 538 minecraft:blackstone
setblock 134 172 541 minecraft:blackstone
setblock 134 172 542 minecraft:smooth_basalt
fill 134 172 543 134 172 546 minecraft:blackstone
fill 134 172 548 134 175 548 minecraft:blackstone
setblock 135 172 511 minecraft:smooth_basalt
fill 135 172 512 135 175 512 minecraft:blackstone
setblock 135 172 516 minecraft:smooth_basalt
fill 135 172 517 135 175 517 minecraft:blackstone
fill 135 172 529 135 172 530 minecraft:blackstone
setblock 135 172 531 minecraft:smooth_basalt
fill 135 172 532 135 172 535 minecraft:blackstone
setblock 135 172 536 minecraft:smooth_basalt
fill 135 172 537 135 175 537 minecraft:blackstone
setblock 135 172 541 minecraft:smooth_basalt
fill 135 172 542 135 175 542 minecraft:blackstone
setblock 135 172 546 minecraft:smooth_basalt
fill 135 172 547 135 175 547 minecraft:blackstone
setblock 135 172 551 minecraft:smooth_basalt
fill 95 173 511 97 173 512 minecraft:blackstone
setblock 95 173 515 minecraft:smooth_basalt
fill 95 173 516 95 173 519 minecraft:blackstone
setblock 95 173 520 minecraft:smooth_basalt
fill 95 173 521 95 173 524 minecraft:blackstone
setblock 95 173 525 minecraft:smooth_basalt
fill 95 173 526 95 176 526 minecraft:blackstone
setblock 95 173 530 minecraft:smooth_basalt
fill 95 173 531 95 176 531 minecraft:blackstone
setblock 95 173 535 minecraft:smooth_basalt
fill 95 173 536 95 173 539 minecraft:blackstone
setblock 95 173 540 minecraft:smooth_basalt
fill 95 173 541 95 176 541 minecraft:blackstone
setblock 95 173 545 minecraft:smooth_basalt
fill 95 173 546 95 176 546 minecraft:blackstone
setblock 95 173 549 minecraft:blackstone
setblock 95 173 550 minecraft:smooth_basalt
fill 95 173 551 98 173 551 minecraft:blackstone
setblock 96 173 514 minecraft:smooth_basalt
fill 96 173 515 96 176 515 minecraft:blackstone
setblock 96 173 519 minecraft:smooth_basalt
fill 96 173 520 96 175 521 minecraft:blackstone
setblock 96 173 529 minecraft:smooth_basalt
fill 96 173 530 96 176 530 minecraft:blackstone
setblock 96 173 534 minecraft:smooth_basalt
fill 96 173 535 96 176 535 minecraft:blackstone
setblock 96 173 539 minecraft:smooth_basalt
fill 96 173 540 96 176 540 minecraft:blackstone
setblock 96 173 544 minecraft:smooth_basalt
fill 96 173 545 96 176 545 minecraft:blackstone
setblock 97 173 517 minecraft:blackstone
setblock 97 173 533 minecraft:smooth_basalt
fill 97 173 534 97 176 534 minecraft:blackstone
setblock 97 173 538 minecraft:smooth_basalt
fill 97 173 539 97 176 539 minecraft:blackstone
setblock 97 173 543 minecraft:smooth_basalt
fill 97 173 544 97 174 544 minecraft:blackstone
setblock 98 173 511 minecraft:blackstone
setblock 98 173 512 minecraft:smooth_basalt
setblock 98 173 532 minecraft:smooth_basalt
fill 98 173 533 98 174 533 minecraft:blackstone
setblock 98 173 536 minecraft:blackstone
setblock 98 173 537 minecraft:smooth_basalt
fill 98 173 538 98 176 538 minecraft:blackstone
setblock 99 173 511 minecraft:smooth_basalt
fill 99 173 512 99 174 512 minecraft:blackstone
fill 99 173 513 99 196 513 minecraft:smooth_basalt
setblock 99 173 536 minecraft:smooth_basalt
setblock 99 173 537 minecraft:blackstone
setblock 99 173 551 minecraft:smooth_basalt
fill 100 173 511 100 175 511 minecraft:blackstone
setblock 100 173 551 minecraft:blackstone
setblock 104 173 511 minecraft:smooth_basalt
setblock 105 173 511 minecraft:blackstone
fill 105 173 530 108 174 532 minecraft:jungle_leaves[persistent=true]
fill 106 173 528 108 177 529 minecraft:jungle_leaves[persistent=true]
fill 106 173 533 108 177 534 minecraft:jungle_leaves[persistent=true]
fill 107 173 526 110 177 527 minecraft:jungle_leaves[persistent=true]
fill 107 173 535 110 177 536 minecraft:jungle_leaves[persistent=true]
fill 108 173 525 118 178 525 minecraft:jungle_leaves[persistent=true]
fill 108 173 537 118 178 537 minecraft:jungle_leaves[persistent=true]
setblock 109 173 511 minecraft:smooth_basalt
fill 109 173 528 109 176 528 minecraft:jungle_leaves[persistent=true]
fill 109 173 534 109 176 534 minecraft:jungle_leaves[persistent=true]
fill 110 173 511 113 173 511 minecraft:blackstone
fill 110 173 524 118 178 524 minecraft:jungle_leaves[persistent=true]
fill 110 173 538 118 178 538 minecraft:jungle_leaves[persistent=true]
fill 111 173 512 112 173 512 minecraft:blackstone
fill 111 173 526 112 178 526 minecraft:jungle_leaves[persistent=true]
fill 111 173 536 112 178 536 minecraft:jungle_leaves[persistent=true]
fill 112 173 523 118 178 523 minecraft:jungle_leaves[persistent=true]
fill 112 173 539 118 178 539 minecraft:jungle_leaves[persistent=true]
setblock 113 173 512 minecraft:smooth_basalt
fill 113 173 513 116 173 513 minecraft:blackstone
setblock 114 173 511 minecraft:smooth_basalt
fill 114 173 512 117 173 512 minecraft:blackstone
fill 114 173 514 115 173 514 minecraft:blackstone
fill 115 173 511 118 173 511 minecraft:blackstone
fill 115 173 531 117 173 531 minecraft:jungle_log
fill 115 173 551 118 173 551 minecraft:blackstone
setblock 116 173 514 minecraft:smooth_basalt
fill 116 173 529 120 175 530 minecraft:jungle_leaves[persistent=true]
fill 116 173 532 120 175 533 minecraft:jungle_leaves[persistent=true]
setblock 117 173 513 minecraft:smooth_basalt
fill 117 173 514 117 173 515 minecraft:blackstone
setblock 118 173 512 minecraft:smooth_basalt
fill 118 173 513 118 176 513 minecraft:blackstone
fill 118 173 515 119 173 515 minecraft:blackstone
fill 118 173 526 119 178 526 minecraft:jungle_leaves[persistent=true]
fill 118 173 531 120 173 531 minecraft:jungle_leaves[persistent=true]
fill 118 173 536 119 178 536 minecraft:jungle_leaves[persistent=true]
setblock 119 173 511 minecraft:smooth_basalt
fill 119 173 512 119 176 512 minecraft:blackstone
fill 119 173 524 119 173 525 minecraft:jungle_log
fill 119 173 537 119 173 538 minecraft:jungle_log
setblock 119 173 550 minecraft:blackstone
setblock 119 173 551 minecraft:smooth_basalt
fill 120 173 511 123 173 511 minecraft:blackstone
setblock 120 173 515 minecraft:smooth_basalt
fill 120 173 524 120 178 524 minecraft:jungle_leaves[persistent=true]
fill 120 173 525 120 173 526 minecraft:jungle_log
fill 120 173 527 123 173 527 minecraft:jungle_leaves[persistent=true]
fill 120 173 535 123 173 535 minecraft:jungle_leaves[persistent=true]
fill 120 173 536 120 173 537 minecraft:jungle_log
fill 120 173 538 120 178 538 minecraft:jungle_leaves[persistent=true]
setblock 120 173 550 minecraft:smooth_basalt
fill 120 173 551 123 173 551 minecraft:blackstone
setblock 121 173 514 minecraft:smooth_basalt
fill 121 173 525 122 178 526 minecraft:jungle_leaves[persistent=true]
fill 121 173 528 124 173 529 minecraft:jungle_leaves[persistent=true]
fill 121 173 533 124 173 534 minecraft:jungle_leaves[persistent=true]
fill 121 173 536 122 178 537 minecraft:jungle_leaves[persistent=true]
setblock 121 173 550 minecraft:blackstone
setblock 122 173 513 minecraft:smooth_basalt
fill 122 173 514 122 174 514 minecraft:blackstone
fill 122 173 530 125 174 532 minecraft:jungle_leaves[persistent=true]
setblock 123 173 512 minecraft:smooth_basalt
fill 123 173 513 123 174 513 minecraft:blackstone
fill 123 173 526 123 182 526 minecraft:jungle_leaves[persistent=true]
fill 123 173 536 123 182 536 minecraft:jungle_leaves[persistent=true]
setblock 124 173 511 minecraft:smooth_basalt
fill 124 173 512 124 175 512 minecraft:blackstone
setblock 124 173 551 minecraft:smooth_basalt
fill 125 173 511 125 175 511 minecraft:blackstone
setblock 125 173 529 minecraft:jungle_log
setblock 125 173 533 minecraft:jungle_log
fill 125 173 551 125 174 551 minecraft:blackstone
fill 126 173 525 126 173 526 minecraft:jungle_log
fill 126 173 530 126 173 532 minecraft:jungle_log
fill 126 173 536 126 173 537 minecraft:jungle_log
fill 127 173 524 127 173 525 minecraft:jungle_log
fill 127 173 537 127 173 538 minecraft:jungle_log
setblock 128 173 512 minecraft:smooth_basalt
setblock 129 173 511 minecraft:smooth_basalt
setblock 129 173 512 minecraft:blackstone
fill 129 173 531 131 173 531 minecraft:jungle_log
setblock 129 173 551 minecraft:smooth_basalt
fill 130 173 511 130 175 511 minecraft:blackstone
fill 130 173 551 130 174 551 minecraft:blackstone
setblock 133 173 512 minecraft:smooth_basalt
setblock 134 173 511 minecraft:smooth_basalt
fill 134 173 512 134 174 512 minecraft:blackstone
setblock 134 173 515 minecraft:blackstone
setblock 134 173 516 minecraft:smooth_basalt
fill 134 173 517 134 176 517 minecraft:blackstone
fill 134 173 533 134 173 535 minecraft:blackstone
setblock 134 173 536 minecraft:smooth_basalt
fill 134 173 537 134 176 537 minecraft:blackstone
setblock 134 173 541 minecraft:smooth_basalt
fill 134 173 542 134 173 545 minecraft:blackstone
setblock 134 173 546 minecraft:smooth_basalt
fill 134 173 547 134 176 547 minecraft:blackstone
setblock 134 173 551 minecraft:smooth_basalt
fill 135 173 511 135 176 511 minecraft:blackstone
setblock 135 173 515 minecraft:smooth_basalt
fill 135 173 516 135 176 516 minecraft:blackstone
fill 135 173 518 135 173 519 minecraft:blackstone
setblock 135 173 520 minecraft:smooth_basalt
fill 135 173 521 135 176 521 minecraft:blackstone
setblock 135 173 530 minecraft:smooth_basalt
fill 135 173 531 135 173 534 minecraft:blackstone
setblock 135 173 535 minecraft:smooth_basalt
fill 135 173 536 135 176 536 minecraft:blackstone
setblock 135 173 540 minecraft:smooth_basalt
fill 135 173 541 135 176 541 minecraft:blackstone
setblock 135 173 545 minecraft:smooth_basalt
fill 135 173 546 135 176 546 minecraft:blackstone
setblock 135 173 550 minecraft:smooth_basalt
fill 135 173 551 135 176 551 minecraft:blackstone
fill 95 174 511 96 174 512 minecraft:blackstone
setblock 95 174 514 minecraft:smooth_basalt
fill 95 174 515 95 174 518 minecraft:blackstone
setblock 95 174 519 minecraft:smooth_basalt
fill 95 174 520 95 174 523 minecraft:blackstone
setblock 95 174 524 minecraft:smooth_basalt
fill 95 174 525 95 177 525 minecraft:blackstone
fill 95 174 527 95 175 527 minecraft:blackstone
setblock 95 174 529 minecraft:smooth_basalt
fill 95 174 530 95 177 530 minecraft:blackstone
setblock 95 174 534 minecraft:smooth_basalt
fill 95 174 535 95 174 538 minecraft:blackstone
setblock 95 174 539 minecraft:smooth_basalt
fill 95 174 540 95 177 540 minecraft:blackstone
setblock 95 174 544 minecraft:smooth_basalt
fill 95 174 545 95 177 545 minecraft:blackstone
setblock 95 174 549 minecraft:smooth_basalt
fill 95 174 550 95 175 551 minecraft:blackstone
fill 96 174 513 96 196 513 minecraft:smooth_basalt
fill 96 174 514 96 175 514 minecraft:blackstone
setblock 96 174 517 minecraft:blackstone
setblock 96 174 518 minecraft:smooth_basalt
fill 96 174 519 96 177 519 minecraft:blackstone
setblock 96 174 522 minecraft:blackstone
setblock 96 174 523 minecraft:smooth_basalt
setblock 96 174 528 minecraft:smooth_basalt
fill 96 174 529 96 176 529 minecraft:blackstone
setblock 96 174 533 minecraft:smooth_basalt
fill 96 174 534 96 177 534 minecraft:blackstone
setblock 96 174 538 minecraft:smooth_basalt
fill 96 174 539 96 177 539 minecraft:blackstone
setblock 96 174 543 minecraft:smooth_basalt
fill 96 174 544 96 177 544 minecraft:blackstone
fill 96 174 551 97 174 551 minecraft:blackstone
setblock 97 174 511 minecraft:blackstone
fill 97 174 512 97 196 512 minecraft:smooth_basalt
fill 97 174 515 97 198 515 minecraft:smooth_basalt
setblock 97 174 517 minecraft:smooth_basalt
fill 97 174 518 97 175 518 minecraft:blackstone
setblock 97 174 532 minecraft:smooth_basalt
fill 97 174 533 97 176 533 minecraft:blackstone
setblock 97 174 537 minecraft:smooth_basalt
fill 97 174 538 97 177 538 minecraft:blackstone
setblock 97 174 541 minecraft:blackstone
setblock 97 174 542 minecraft:smooth_basalt
fill 97 174 543 97 177 543 minecraft:blackstone
setblock 98 174 511 minecraft:smooth_basalt
setblock 98 174 512 minecraft:blackstone
setblock 98 174 536 minecraft:smooth_basalt
fill 98 174 537 98 176 537 minecraft:blackstone
setblock 98 174 541 minecraft:smooth_basalt
setblock 98 174 551 minecraft:smooth_basalt
fill 99 174 511 99 175 511 minecraft:blackstone
setblock 99 174 551 minecraft:blackstone
fill 103 174 531 104 177 531 minecraft:jungle_leaves[persistent=true]
fill 104 174 527 104 177 530 minecraft:jungle_leaves[persistent=true]
fill 104 174 532 104 177 535 minecraft:jungle_leaves[persistent=true]
fill 105 174 526 105 177 529 minecraft:jungle_leaves[persistent=true]
fill 105 174 533 105 177 536 minecraft:jungle_leaves[persistent=true]
fill 106 174 525 106 177 527 minecraft:jungle_leaves[persistent=true]
fill 106 174 535 106 177 537 minecraft:jungle_leaves[persistent=true]
fill 107 174 524 107 177 525 minecraft:jungle_leaves[persistent=true]
fill 107 174 537 107 177 538 minecraft:jungle_leaves[persistent=true]
fill 108 174 523 109 177 524 minecraft:jungle_leaves[persistent=true]
fill 108 174 538 109 177 539 minecraft:jungle_leaves[persistent=true]
fill 110 174 511 112 174 511 minecraft:blackstone
fill 110 174 522 111 177 523 minecraft:jungle_leaves[persistent=true]
fill 110 174 539 111 177 540 minecraft:jungle_leaves[persistent=true]
setblock 112 174 512 minecraft:smooth_basalt
fill 112 174 522 120 177 522 minecraft:jungle_leaves[persistent=true]
fill 112 174 540 120 177 540 minecraft:jungle_leaves[persistent=true]
setblock 113 174 511 minecraft:smooth_basalt
fill 113 174 512 115 174 513 minecraft:blackstone
fill 113 174 521 117 177 521 minecraft:jungle_leaves[persistent=true]
fill 113 174 541 117 177 541 minecraft:jungle_leaves[persistent=true]
fill 114 174 511 117 174 511 minecraft:blackstone
setblock 115 174 514 minecraft:smooth_basalt
fill 115 174 551 117 174 551 minecraft:blackstone
setblock 116 174 512 minecraft:blackstone
setblock 116 174 513 minecraft:smooth_basalt
fill 116 174 514 117 176 514 minecraft:blackstone
setblock 116 174 531 minecraft:jungle_leaves[persistent=true]
setblock 117 174 512 minecraft:smooth_basalt
fill 117 174 513 117 177 513 minecraft:blackstone
fill 117 174 531 120 174 531 minecraft:jungle_log
setblock 118 174 511 minecraft:smooth_basalt
fill 118 174 512 118 177 512 minecraft:blackstone
setblock 118 174 515 minecraft:blackstone
setblock 118 174 551 minecraft:smooth_basalt
fill 119 174 511 122 174 511 minecraft:blackstone
fill 119 174 523 119 177 525 minecraft:jungle_leaves[persistent=true]
fill 119 174 537 119 177 539 minecraft:jungle_leaves[persistent=true]
fill 119 174 551 122 174 551 minecraft:blackstone
setblock 120 174 514 minecraft:smooth_basalt
fill 120 174 523 122 177 523 minecraft:jungle_leaves[persistent=true]
fill 120 174 525 120 178 525 minecraft:jungle_leaves[persistent=true]
setblock 120 174 526 minecraft:jungle_log
fill 120 174 527 120 182 527 minecraft:jungle_leaves[persistent=true]
fill 120 174 535 120 182 535 minecraft:jungle_leaves[persistent=true]
setblock 120 174 536 minecraft:jungle_log
fill 120 174 537 120 178 537 minecraft:jungle_leaves[persistent=true]
fill 120 174 539 122 177 539 minecraft:jungle_leaves[persistent=true]
setblock 121 174 513 minecraft:smooth_basalt
setblock 121 174 514 minecraft:blackstone
fill 121 174 524 123 177 524 minecraft:jungle_leaves[persistent=true]
fill 121 174 527 121 174 528 minecraft:jungle_log
fill 121 174 529 126 174 529 minecraft:jungle_leaves[persistent=true]
fill 121 174 533 126 174 533 minecraft:jungle_leaves[persistent=true]
fill 121 174 534 121 174 535 minecraft:jungle_log
fill 121 174 538 123 177 538 minecraft:jungle_leaves[persistent=true]
setblock 122 174 512 minecraft:smooth_basalt
fill 122 174 513 122 175 513 minecraft:blackstone
fill 122 174 527 124 177 528 minecraft:jungle_leaves[persistent=true]
fill 122 174 534 124 177 535 minecraft:jungle_leaves[persistent=true]
setblock 123 174 511 minecraft:smooth_basalt
fill 123 174 512 123 175 512 minecraft:blackstone
fill 123 174 525 124 177 525 minecraft:jungle_leaves[persistent=true]
fill 123 174 537 124 177 537 minecraft:jungle_leaves[persistent=true]
setblock 123 174 551 minecraft:smooth_basalt
fill 124 174 511 124 176 511 minecraft:blackstone
fill 124 174 526 125 177 526 minecraft:jungle_leaves[persistent=true]
fill 124 174 536 125 177 536 minecraft:jungle_leaves[persistent=true]
setblock 124 174 551 minecraft:blackstone
fill 125 174 527 125 174 528 minecraft:jungle_log
fill 125 174 534 125 174 535 minecraft:jungle_log
setblock 126 174 526 minecraft:jungle_log
fill 126 174 527 126 177 528 minecraft:jungle_leaves[persistent=true]
fill 126 174 530 126 183 530 minecraft:jungle_leaves[persistent=true]
fill 126 174 531 129 174 531 minecraft:jungle_log
fill 126 174 532 126 183 532 minecraft:jungle_leaves[persistent=true]
fill 126 174 534 126 177 535 minecraft:jungle_leaves[persistent=true]
setblock 126 174 536 minecraft:jungle_log
setblock 128 174 511 minecraft:smooth_basalt
setblock 129 174 511 minecraft:blackstone
setblock 133 174 511 minecraft:smooth_basalt
setblock 133 174 512 minecraft:blackstone
fill 133 174 538 133 174 540 minecraft:blackstone
setblock 133 174 541 minecraft:smooth_basalt
setblock 133 174 551 minecraft:smooth_basalt
fill 134 174 511 134 177 511 minecraft:blackstone
setblock 134 174 515 minecraft:smooth_basalt
fill 134 174 516 134 176 516 minecraft:blackstone
fill 134 174 518 135 174 518 minecraft:blackstone
fill 134 174 533 134 174 534 minecraft:blackstone
setblock 134 174 535 minecraft:smooth_basalt
fill 134 174 536 134 177 536 minecraft:blackstone
setblock 134 174 540 minecraft:smooth_basalt
fill 134 174 541 134 174 544 minecraft:blackstone
setblock 134 174 545 minecraft:smooth_basalt
fill 134 174 546 134 177 546 minecraft:blackstone
setblock 134 174 550 minecraft:smooth_basalt
fill 134 174 551 134 177 551 minecraft:blackstone
setblock 135 174 514 minecraft:smooth_basalt
fill 135 174 515 135 177 515 minecraft:blackstone
setblock 135 174 519 minecraft:smooth_basalt
fill 135 174 520 135 177 520 minecraft:blackstone
fill 135 174 522 135 175 522 minecraft:blackstone
fill 135 174 530 135 174 533 minecraft:blackstone
setblock 135 174 534 minecraft:smooth_basalt
fill 135 174 535 135 177 535 minecraft:blackstone
setblock 135 174 539 minecraft:smooth_basalt
fill 135 174 540 135 177 540 minecraft:blackstone
setblock 135 174 544 minecraft:smooth_basalt
fill 135 174 545 135 177 545 minecraft:blackstone
setblock 135 174 549 minecraft:smooth_basalt
fill 135 174 550 135 177 550 minecraft:blackstone
fill 95 175 511 95 175 512 minecraft:blackstone
setblock 95 175 513 minecraft:smooth_basalt
fill 95 175 514 95 175 517 minecraft:blackstone
setblock 95 175 518 minecraft:smooth_basalt
fill 95 175 519 95 175 522 minecraft:blackstone
setblock 95 175 523 minecraft:smooth_basalt
fill 95 175 524 96 177 524 minecraft:blackstone
setblock 95 175 528 minecraft:smooth_basalt
fill 95 175 529 95 178 529 minecraft:blackstone
setblock 95 175 533 minecraft:smooth_basalt
fill 95 175 534 95 175 537 minecraft:blackstone
setblock 95 175 538 minecraft:smooth_basalt
fill 95 175 539 95 178 539 minecraft:blackstone
setblock 95 175 543 minecraft:smooth_basalt
fill 95 175 544 95 178 544 minecraft:blackstone
setblock 95 175 548 minecraft:smooth_basalt
fill 95 175 549 95 176 549 minecraft:blackstone
setblock 96 175 511 minecraft:blackstone
fill 96 175 512 96 196 512 minecraft:smooth_basalt
setblock 96 175 516 minecraft:blackstone
setblock 96 175 517 minecraft:smooth_basalt
fill 96 175 518 96 178 518 minecraft:blackstone
setblock 96 175 522 minecraft:smooth_basalt
fill 96 175 523 96 178 523 minecraft:blackstone
setblock 96 175 528 minecraft:blackstone
setblock 96 175 532 minecraft:smooth_basalt
fill 96 175 533 96 178 533 minecraft:blackstone
setblock 96 175 537 minecraft:smooth_basalt
fill 96 175 538 96 178 538 minecraft:blackstone
setblock 96 175 542 minecraft:smooth_basalt
fill 96 175 543 96 178 543 minecraft:blackstone
setblock 96 175 551 minecraft:blackstone
setblock 97 175 511 minecraft:smooth_basalt
setblock 97 175 532 minecraft:blackstone
setblock 97 175 536 minecraft:smooth_basalt
fill 97 175 537 97 178 537 minecraft:blackstone
setblock 97 175 541 minecraft:smooth_basalt
fill 97 175 542 97 178 542 minecraft:blackstone
setblock 97 175 551 minecraft:smooth_basalt
setblock 98 175 511 minecraft:blackstone
fill 98 175 512 99 194 512 minecraft:smooth_basalt
setblock 98 175 535 minecraft:smooth_basalt
setblock 98 175 536 minecraft:blackstone
setblock 98 175 540 minecraft:smooth_basalt
setblock 98 175 541 minecraft:blackstone
fill 103 175 527 103 176 530 minecraft:jungle_leaves[persistent=true]
fill 103 175 532 103 176 535 minecraft:jungle_leaves[persistent=true]
fill 104 175 526 104 176 526 minecraft:jungle_leaves[persistent=true]
fill 104 175 536 104 176 536 minecraft:jungle_leaves[persistent=true]
fill 105 175 525 105 176 525 minecraft:jungle_leaves[persistent=true]
fill 105 175 530 107 178 532 minecraft:jungle_leaves[persistent=true]
fill 105 175 537 105 176 537 minecraft:jungle_leaves[persistent=true]
fill 106 175 524 106 176 524 minecraft:jungle_leaves[persistent=true]
fill 106 175 538 106 176 538 minecraft:jungle_leaves[persistent=true]
fill 107 175 523 107 176 523 minecraft:jungle_leaves[persistent=true]
fill 107 175 539 107 176 539 minecraft:jungle_leaves[persistent=true]
fill 108 175 522 109 176 522 minecraft:jungle_leaves[persistent=true]
setblock 108 175 530 minecraft:jungle_leaves[persistent=true]
setblock 108 175 532 minecraft:jungle_leaves[persistent=true]
fill 108 175 540 109 176 540 minecraft:jungle_leaves[persistent=true]
fill 110 175 521 112 176 521 minecraft:jungle_leaves[persistent=true]
fill 110 175 541 112 176 541 minecraft:jungle_leaves[persistent=true]
setblock 111 175 511 minecraft:blackstone
setblock 111 175 527 minecraft:jungle_leaves[persistent=true]
setblock 111 175 535 minecraft:jungle_leaves[persistent=true]
setblock 112 175 511 minecraft:smooth_basalt
fill 112 175 512 115 175 512 minecraft:blackstone
fill 113 175 511 116 175 511 minecraft:blackstone
fill 113 175 513 114 175 513 minecraft:blackstone
fill 113 175 527 119 175 527 minecraft:jungle_leaves[persistent=true]
fill 113 175 535 119 175 535 minecraft:jungle_leaves[persistent=true]
setblock 115 175 513 minecraft:smooth_basalt
setblock 115 175 514 minecraft:blackstone
fill 115 175 551 116 175 551 minecraft:blackstone
setblock 116 175 512 minecraft:smooth_basalt
fill 116 175 513 116 178 513 minecraft:blackstone
setblock 117 175 511 minecraft:smooth_basalt
fill 117 175 512 117 178 512 minecraft:blackstone
fill 117 175 531 119 182 531 minecraft:jungle_leaves[persistent=true]
setblock 117 175 551 minecraft:smooth_basalt
fill 118 175 511 121 175 511 minecraft:blackstone
fill 118 175 521 120 176 521 minecraft:jungle_leaves[persistent=true]
fill 118 175 541 120 176 541 minecraft:jungle_leaves[persistent=true]
fill 118 175 551 121 175 551 minecraft:blackstone
setblock 119 175 514 minecraft:smooth_basalt
setblock 120 175 513 minecraft:smooth_basalt
setblock 120 175 514 minecraft:blackstone
fill 120 175 526 120 182 526 minecraft:jungle_leaves[persistent=true]
fill 120 175 531 126 175 531 minecraft:jungle_log
fill 120 175 536 120 182 536 minecraft:jungle_leaves[persistent=true]
setblock 121 175 512 minecraft:smooth_basalt
setblock 121 175 513 minecraft:blackstone
fill 121 175 522 122 176 522 minecraft:jungle_leaves[persistent=true]
fill 121 175 527 121 182 530 minecraft:jungle_leaves[persistent=true]
fill 121 175 532 121 182 535 minecraft:jungle_leaves[persistent=true]
fill 121 175 540 122 176 540 minecraft:jungle_leaves[persistent=true]
setblock 122 175 511 minecraft:smooth_basalt
fill 122 175 512 122 176 512 minecraft:blackstone
fill 122 175 529 122 175 530 minecraft:jungle_log
fill 122 175 532 122 175 533 minecraft:jungle_log
setblock 122 175 551 minecraft:smooth_basalt
fill 123 175 511 123 177 511 minecraft:blackstone
fill 123 175 523 123 176 523 minecraft:jungle_leaves[persistent=true]
fill 123 175 529 123 183 529 minecraft:jungle_leaves[persistent=true]
fill 123 175 530 124 175 530 minecraft:jungle_log
fill 123 175 532 124 175 532 minecraft:jungle_log
fill 123 175 533 123 183 533 minecraft:jungle_leaves[persistent=true]
fill 123 175 539 123 176 539 minecraft:jungle_leaves[persistent=true]
setblock 123 175 551 minecraft:blackstone
fill 124 175 524 124 176 524 minecraft:jungle_leaves[persistent=true]
setblock 124 175 529 minecraft:jungle_log
setblock 124 175 533 minecraft:jungle_log
fill 124 175 538 124 176 538 minecraft:jungle_leaves[persistent=true]
fill 125 175 525 125 176 525 minecraft:jungle_leaves[persistent=true]
fill 125 175 527 125 177 530 minecraft:jungle_leaves[persistent=true]
fill 125 175 532 125 177 535 minecraft:jungle_leaves[persistent=true]
fill 125 175 537 125 176 537 minecraft:jungle_leaves[persistent=true]
fill 126 175 526 126 176 526 minecraft:jungle_leaves[persistent=true]
fill 126 175 529 127 176 529 minecraft:jungle_leaves[persistent=true]
fill 126 175 533 127 176 533 minecraft:jungle_leaves[persistent=true]
fill 126 175 536 126 176 536 minecraft:jungle_leaves[persistent=true]
setblock 127 175 511 minecraft:smooth_basalt
fill 127 175 527 127 176 528 minecraft:jungle_leaves[persistent=true]
fill 127 175 530 127 176 532 minecraft:jungle_leaves[persistent=true]
fill 127 175 534 127 176 535 minecraft:jungle_leaves[persistent=true]
setblock 132 175 511 minecraft:smooth_basalt
setblock 132 175 551 minecraft:smooth_basalt
fill 133 175 511 133 176 511 minecraft:blackstone
fill 133 175 538 133 175 539 minecraft:blackstone
setblock 133 175 540 minecraft:smooth_basalt
fill 133 175 541 134 176 542 minecraft:blackstone
fill 133 175 551 133 178 551 minecraft:blackstone
setblock 134 175 514 minecraft:smooth_basalt
setblock 134 175 515 minecraft:blackstone
setblock 134 175 518 minecraft:blackstone
setblock 134 175 534 minecraft:smooth_basalt
fill 134 175 535 134 178 535 minecraft:blackstone
setblock 134 175 539 minecraft:smooth_basalt
fill 134 175 540 134 178 540 minecraft:blackstone
setblock 134 175 543 minecraft:blackstone
setblock 134 175 544 minecraft:smooth_basalt
fill 134 175 545 134 178 545 minecraft:blackstone
setblock 135 175 513 minecraft:smooth_basalt
fill 135 175 514 135 178 514 minecraft:blackstone
setblock 135 175 518 minecraft:smooth_basalt
fill 135 175 519 135 178 519 minecraft:blackstone
fill 135 175 530 135 175 532 minecraft:blackstone
setblock 135 175 533 minecraft:smooth_basalt
fill 135 175 534 135 178 534 minecraft:blackstone
setblock 135 175 538 minecraft:smooth_basalt
fill 135 175 539 135 178 539 minecraft:blackstone
setblock 135 175 543 minecraft:smooth_basalt
fill 135 175 544 135 178 544 minecraft:blackstone
setblock 135 175 548 minecraft:smooth_basalt
fill 135 175 549 135 178 549 minecraft:blackstone
setblock 95 176 512 minecraft:smooth_basalt
fill 95 176 513 95 176 516 minecraft:blackstone
setblock 95 176 517 minecraft:smooth_basalt
fill 95 176 518 95 176 521 minecraft:blackstone
setblock 95 176 522 minecraft:smooth_basalt
fill 95 176 523 95 179 523 minecraft:blackstone
setblock 95 176 527 minecraft:smooth_basalt
fill 95 176 528 95 179 528 minecraft:blackstone
setblock 95 176 532 minecraft:smooth_basalt
fill 95 176 533 95 176 536 minecraft:blackstone
setblock 95 176 537 minecraft:smooth_basalt
fill 95 176 538 95 179 538 minecraft:blackstone
setblock 95 176 542 minecraft:smooth_basalt
fill 95 176 543 95 179 543 minecraft:blackstone
setblock 95 176 547 minecraft:smooth_basalt
fill 95 176 548 95 179 548 minecraft:blackstone
fill 96 176 514 96 196 514 minecraft:smooth_basalt
setblock 96 176 516 minecraft:smooth_basalt
fill 96 176 517 96 179 517 minecraft:blackstone
setblock 96 176 520 minecraft:blackstone
setblock 96 176 521 minecraft:smooth_basalt
fill 96 176 522 96 179 522 minecraft:blackstone
setblock 96 176 525 minecraft:blackstone
setblock 96 176 531 minecraft:smooth_basalt
fill 96 176 532 96 179 532 minecraft:blackstone
setblock 96 176 536 minecraft:smooth_basalt
fill 96 176 537 96 179 537 minecraft:blackstone
setblock 96 176 541 minecraft:smooth_basalt
fill 96 176 542 96 179 542 minecraft:blackstone
setblock 96 176 546 minecraft:smooth_basalt
setblock 97 176 521 minecraft:light[level=12]
setblock 97 176 529 minecraft:light[level=12]
setblock 97 176 535 minecraft:smooth_basalt
fill 97 176 536 97 178 536 minecraft:blackstone
setblock 97 176 540 minecraft:smooth_basalt
fill 97 176 541 97 179 541 minecraft:blackstone
setblock 97 176 545 minecraft:light[level=12]
setblock 98 176 539 minecraft:smooth_basalt
setblock 98 176 540 minecraft:blackstone
setblock 105 176 513 minecraft:light[level=12]
setblock 105 176 521 minecraft:light[level=12]
setblock 105 176 545 minecraft:light[level=12]
setblock 111 176 511 minecraft:smooth_basalt
fill 112 176 511 114 176 512 minecraft:blackstone
setblock 113 176 513 minecraft:light[level=12]
setblock 113 176 545 minecraft:light[level=12]
setblock 114 176 513 minecraft:smooth_basalt
fill 114 176 527 119 177 527 minecraft:jungle_leaves[persistent=true]
fill 114 176 535 119 177 535 minecraft:jungle_leaves[persistent=true]
setblock 115 176 511 minecraft:blackstone
setblock 115 176 512 minecraft:smooth_basalt
fill 115 176 513 115 178 513 minecraft:blackstone
setblock 116 176 511 minecraft:smooth_basalt
fill 116 176 512 116 179 512 minecraft:blackstone
fill 116 176 529 120 177 529 minecraft:jungle_leaves[persistent=true]
fill 116 176 533 120 177 533 minecraft:jungle_leaves[persistent=true]
setblock 116 176 551 minecraft:smooth_basalt
fill 117 176 511 120 176 511 minecraft:blackstone
fill 117 176 530 120 181 530 minecraft:jungle_leaves[persistent=true]
fill 117 176 532 120 181 532 minecraft:jungle_leaves[persistent=true]
fill 117 176 551 120 176 551 minecraft:blackstone
setblock 118 176 514 minecraft:smooth_basalt
setblock 119 176 513 minecraft:smooth_basalt
setblock 120 176 512 minecraft:smooth_basalt
setblock 120 176 513 minecraft:blackstone
fill 120 176 531 122 183 531 minecraft:jungle_leaves[persistent=true]
setblock 121 176 511 minecraft:smooth_basalt
fill 121 176 512 121 177 512 minecraft:blackstone
setblock 121 176 513 minecraft:light[level=12]
setblock 121 176 521 minecraft:light[level=12]
setblock 121 176 545 minecraft:light[level=12]
setblock 121 176 551 minecraft:smooth_basalt
fill 122 176 511 122 177 511 minecraft:blackstone
fill 122 176 529 122 183 530 minecraft:jungle_leaves[persistent=true]
fill 122 176 532 122 183 533 minecraft:jungle_leaves[persistent=true]
fill 123 176 530 124 183 530 minecraft:jungle_leaves[persistent=true]
setblock 123 176 531 minecraft:jungle_log
fill 123 176 532 124 183 532 minecraft:jungle_leaves[persistent=true]
fill 124 176 529 124 183 529 minecraft:jungle_leaves[persistent=true]
fill 124 176 531 126 183 531 minecraft:jungle_leaves[persistent=true]
fill 124 176 533 124 183 533 minecraft:jungle_leaves[persistent=true]
setblock 129 176 513 minecraft:light[level=12]
setblock 129 176 521 minecraft:light[level=12]
setblock 129 176 529 minecraft:light[level=12]
setblock 129 176 537 minecraft:light[level=12]
setblock 129 176 545 minecraft:light[level=12]
fill 132 176 551 132 179 551 minecraft:blackstone
setblock 133 176 538 minecraft:blackstone
setblock 133 176 539 minecraft:smooth_basalt
fill 133 176 540 133 179 540 minecraft:blackstone
setblock 133 176 543 minecraft:blackstone
setblock 134 176 518 minecraft:smooth_basalt
setblock 134 176 534 minecraft:blackstone
setblock 134 176 538 minecraft:smooth_basalt
fill 134 176 539 134 179 539 minecraft:blackstone
setblock 134 176 543 minecraft:smooth_basalt
fill 134 176 544 134 179 544 minecraft:blackstone
setblock 134 176 548 minecraft:smooth_basalt
setblock 135 176 512 minecraft:smooth_basalt
fill 135 176 513 135 178 513 minecraft:blackstone
setblock 135 176 517 minecraft:smooth_basalt
fill 135 176 518 135 179 518 minecraft:blackstone
setblock 135 176 522 minecraft:smooth_basalt
fill 135 176 523 135 179 523 minecraft:blackstone
setblock 135 176 531 minecraft:blackstone
setblock 135 176 532 minecraft:smooth_basalt
fill 135 176 533 135 179 533 minecraft:blackstone
setblock 135 176 537 minecraft:smooth_basalt
fill 135 176 538 135 179 538 minecraft:blackstone
setblock 135 176 542 minecraft:smooth_basalt
fill 135 176 543 135 179 543 minecraft:blackstone
setblock 135 176 547 minecraft:smooth_basalt
fill 135 176 548 135 179 548 minecraft:blackstone
fill 95 177 513 95 177 515 minecraft:blackstone
setblock 95 177 516 minecraft:smooth_basalt
fill 95 177 517 95 177 520 minecraft:blackstone
setblock 95 177 521 minecraft:smooth_basalt
fill 95 177 522 95 180 522 minecraft:blackstone
setblock 95 177 526 minecraft:smooth_basalt
fill 95 177 527 95 180 527 minecraft:blackstone
setblock 95 177 531 minecraft:smooth_basalt
fill 95 177 532 95 177 535 minecraft:blackstone
setblock 95 177 536 minecraft:smooth_basalt
fill 95 177 537 95 180 537 minecraft:blackstone
setblock 95 177 541 minecraft:smooth_basalt
fill 95 177 542 95 180 542 minecraft:blackstone
setblock 95 177 546 minecraft:smooth_basalt
fill 95 177 547 95 180 547 minecraft:blackstone
setblock 96 177 515 minecraft:smooth_basalt
fill 96 177 516 96 179 516 minecraft:blackstone
setblock 96 177 520 minecraft:smooth_basalt
fill 96 177 521 96 180 521 minecraft:blackstone
setblock 96 177 525 minecraft:smooth_basalt
fill 96 177 526 96 180 526 minecraft:blackstone
setblock 96 177 530 minecraft:smooth_basalt
fill 96 177 531 96 180 531 minecraft:blackstone
setblock 96 177 535 minecraft:smooth_basalt
fill 96 177 536 96 180 536 minecraft:blackstone
setblock 96 177 540 minecraft:smooth_basalt
fill 96 177 541 96 180 541 minecraft:blackstone
setblock 96 177 545 minecraft:smooth_basalt
fill 96 177 546 96 180 546 minecraft:blackstone
setblock 97 177 534 minecraft:smooth_basalt
fill 97 177 535 97 178 535 minecraft:blackstone
setblock 97 177 539 minecraft:smooth_basalt
fill 97 177 540 97 180 540 minecraft:blackstone
fill 111 177 511 114 177 511 minecraft:blackstone
setblock 113 177 512 minecraft:blackstone
setblock 114 177 512 minecraft:smooth_basalt
setblock 114 177 513 minecraft:blackstone
setblock 115 177 511 minecraft:smooth_basalt
fill 115 177 512 115 180 512 minecraft:blackstone
fill 116 177 511 119 177 511 minecraft:blackstone
fill 116 177 528 120 179 528 minecraft:jungle_leaves[persistent=true]
fill 116 177 534 120 179 534 minecraft:jungle_leaves[persistent=true]
fill 116 177 551 119 177 551 minecraft:blackstone
setblock 118 177 513 minecraft:smooth_basalt
setblock 119 177 512 minecraft:smooth_basalt
setblock 119 177 513 minecraft:blackstone
setblock 120 177 511 minecraft:smooth_basalt
setblock 120 177 512 minecraft:blackstone
setblock 120 177 551 minecraft:smooth_basalt
fill 121 177 511 121 178 511 minecraft:blackstone
fill 123 177 531 123 183 531 minecraft:jungle_leaves[persistent=true]
fill 126 177 529 126 183 529 minecraft:jungle_leaves[persistent=true]
fill 126 177 533 126 183 533 minecraft:jungle_leaves[persistent=true]
setblock 127 177 531 minecraft:jungle_leaves[persistent=true]
setblock 133 177 538 minecraft:smooth_basalt
fill 133 177 539 133 180 539 minecraft:blackstone
fill 133 177 541 133 177 542 minecraft:blackstone
setblock 133 177 543 minecraft:smooth_basalt
fill 133 177 544 133 180 544 minecraft:blackstone
setblock 134 177 537 minecraft:smooth_basalt
fill 134 177 538 134 180 538 minecraft:blackstone
setblock 134 177 541 minecraft:blackstone
setblock 134 177 542 minecraft:smooth_basalt
fill 134 177 543 134 180 543 minecraft:blackstone
setblock 134 177 547 minecraft:smooth_basalt
fill 134 177 548 134 180 548 minecraft:blackstone
setblock 135 177 511 minecraft:smooth_basalt
setblock 135 177 512 minecraft:blackstone
setblock 135 177 516 minecraft:smooth_basalt
fill 135 177 517 135 180 517 minecraft:blackstone
setblock 135 177 521 minecraft:smooth_basalt
fill 135 177 522 135 180 522 minecraft:blackstone
fill 135 177 524 135 178 524 minecraft:blackstone
setblock 135 177 531 minecraft:smooth_basalt
fill 135 177 532 135 180 532 minecraft:blackstone
setblock 135 177 536 minecraft:smooth_basalt
fill 135 177 537 135 180 537 minecraft:blackstone
setblock 135 177 541 minecraft:smooth_basalt
fill 135 177 542 135 180 542 minecraft:blackstone
setblock 135 177 546 minecraft:smooth_basalt
fill 135 177 547 135 180 547 minecraft:blackstone
setblock 135 177 551 minecraft:smooth_basalt
setblock 95 178 514 minecraft:blackstone
setblock 95 178 515 minecraft:smooth_basalt
fill 95 178 516 95 178 519 minecraft:blackstone
setblock 95 178 520 minecraft:smooth_basalt
fill 95 178 521 95 181 521 minecraft:blackstone
setblock 95 178 524 minecraft:blackstone
setblock 95 178 525 minecraft:smooth_basalt
fill 95 178 526 95 181 526 minecraft:blackstone
setblock 95 178 530 minecraft:smooth_basalt
fill 95 178 531 95 178 534 minecraft:blackstone
setblock 95 178 535 minecraft:smooth_basalt
fill 95 178 536 95 181 536 minecraft:blackstone
setblock 95 178 540 minecraft:smooth_basalt
fill 95 178 541 95 181 541 minecraft:blackstone
setblock 95 178 545 minecraft:smooth_basalt
fill 95 178 546 95 181 546 minecraft:blackstone
setblock 96 178 519 minecraft:smooth_basalt
fill 96 178 520 96 181 520 minecraft:blackstone
setblock 96 178 524 minecraft:smooth_basalt
fill 96 178 525 96 181 525 minecraft:blackstone
fill 96 178 527 96 179 527 minecraft:blackstone
fill 96 178 530 96 181 530 minecraft:blackstone
setblock 96 178 534 minecraft:smooth_basalt
fill 96 178 535 96 181 535 minecraft:blackstone
setblock 96 178 539 minecraft:smooth_basalt
fill 96 178 540 96 181 540 minecraft:blackstone
setblock 96 178 544 minecraft:smooth_basalt
fill 96 178 545 96 181 545 minecraft:blackstone
setblock 97 178 538 minecraft:smooth_basalt
fill 97 178 539 97 181 539 minecraft:blackstone
setblock 97 178 543 minecraft:smooth_basalt
fill 106 178 528 107 178 529 minecraft:jungle_leaves[persistent=true]
fill 106 178 533 107 178 534 minecraft:jungle_leaves[persistent=true]
fill 107 178 526 109 178 527 minecraft:jungle_leaves[persistent=true]
fill 107 178 535 109 178 536 minecraft:jungle_leaves[persistent=true]
setblock 108 178 528 minecraft:jungle_leaves[persistent=true]
setblock 108 178 534 minecraft:jungle_leaves[persistent=true]
setblock 110 178 526 minecraft:jungle_leaves[persistent=true]
setblock 110 178 536 minecraft:jungle_leaves[persistent=true]
fill 111 178 511 113 178 511 minecraft:blackstone
setblock 113 178 512 minecraft:smooth_basalt
setblock 114 178 511 minecraft:smooth_basalt
fill 114 178 512 114 181 512 minecraft:blackstone
fill 115 178 511 118 178 511 minecraft:blackstone
fill 115 178 527 119 179 527 minecraft:jungle_leaves[persistent=true]
fill 115 178 535 119 179 535 minecraft:jungle_leaves[persistent=true]
fill 115 178 551 118 178 551 minecraft:blackstone
setblock 117 178 513 minecraft:smooth_basalt
fill 117 178 529 120 181 529 minecraft:jungle_leaves[persistent=true]
fill 117 178 533 120 181 533 minecraft:jungle_leaves[persistent=true]
setblock 118 178 512 minecraft:smooth_basalt
setblock 119 178 511 minecraft:smooth_basalt
setblock 119 178 512 minecraft:blackstone
fill 119 178 524 119 178 525 minecraft:jungle_leaves[persistent=true]
fill 119 178 537 119 178 538 minecraft:jungle_leaves[persistent=true]
setblock 119 178 551 minecraft:smooth_basalt
fill 120 178 511 120 181 511 minecraft:blackstone
fill 122 178 527 123 182 528 minecraft:jungle_leaves[persistent=true]
fill 122 178 534 123 182 535 minecraft:jungle_leaves[persistent=true]
fill 124 178 528 125 183 528 minecraft:jungle_leaves[persistent=true]
fill 124 178 534 125 183 534 minecraft:jungle_leaves[persistent=true]
fill 125 178 529 125 183 530 minecraft:jungle_leaves[persistent=true]
fill 125 178 532 125 183 533 minecraft:jungle_leaves[persistent=true]
fill 133 178 538 133 181 538 minecraft:blackstone
setblock 133 178 541 minecraft:blackstone
setblock 133 178 542 minecraft:smooth_basalt
fill 133 178 543 133 181 543 minecraft:blackstone
fill 133 178 545 133 179 545 minecraft:blackstone
setblock 134 178 536 minecraft:smooth_basalt
fill 134 178 537 134 181 537 minecraft:blackstone
setblock 134 178 541 minecraft:smooth_basalt
fill 134 178 542 134 181 542 minecraft:blackstone
setblock 134 178 546 minecraft:smooth_basalt
fill 134 178 547 134 181 547 minecraft:blackstone
setblock 134 178 551 minecraft:smooth_basalt
setblock 135 178 515 minecraft:smooth_basalt
fill 135 178 516 135 181 516 minecraft:blackstone
setblock 135 178 520 minecraft:smooth_basalt
fill 135 178 521 135 181 521 minecraft:blackstone
setblock 135 178 525 minecraft:smooth_basalt
fill 135 178 531 135 181 531 minecraft:blackstone
setblock 135 178 535 minecraft:smooth_basalt
fill 135 178 536 135 181 536 minecraft:blackstone
setblock 135 178 540 minecraft:smooth_basalt
fill 135 178 541 135 181 541 minecraft:blackstone
setblock 135 178 545 minecraft:smooth_basalt
fill 135 178 546 135 181 546 minecraft:blackstone
setblock 135 178 550 minecraft:smooth_basalt
fill 135 178 551 135 181 551 minecraft:blackstone
setblock 95 179 514 minecraft:smooth_basalt
fill 95 179 515 95 179 518 minecraft:blackstone
setblock 95 179 519 minecraft:smooth_basalt
fill 95 179 520 95 182 520 minecraft:blackstone
setblock 95 179 524 minecraft:smooth_basalt
fill 95 179 525 95 182 525 minecraft:blackstone
setblock 95 179 529 minecraft:smooth_basalt
fill 95 179 530 95 179 533 minecraft:blackstone
setblock 95 179 534 minecraft:smooth_basalt
fill 95 179 535 95 182 535 minecraft:blackstone
setblock 95 179 539 minecraft:smooth_basalt
fill 95 179 540 95 182 540 minecraft:blackstone
setblock 95 179 544 minecraft:smooth_basalt
fill 95 179 545 95 182 545 minecraft:blackstone
setblock 95 179 549 minecraft:smooth_basalt
setblock 96 179 518 minecraft:smooth_basalt
fill 96 179 519 96 182 519 minecraft:blackstone
setblock 96 179 523 minecraft:smooth_basalt
fill 96 179 524 96 182 524 minecraft:blackstone
setblock 96 179 528 minecraft:smooth_basalt
fill 96 179 529 96 182 529 minecraft:blackstone
setblock 96 179 533 minecraft:smooth_basalt
fill 96 179 534 96 182 534 minecraft:blackstone
setblock 96 179 538 minecraft:smooth_basalt
fill 96 179 539 96 182 539 minecraft:blackstone
setblock 96 179 543 minecraft:smooth_basalt
fill 96 179 544 96 182 544 minecraft:blackstone
fill 97 179 520 97 179 521 minecraft:blackstone
setblock 97 179 522 minecraft:smooth_basalt
fill 97 179 523 97 182 523 minecraft:blackstone
setblock 97 179 537 minecraft:smooth_basalt
fill 97 179 538 97 180 538 minecraft:blackstone
setblock 97 179 542 minecraft:smooth_basalt
fill 97 179 543 97 182 543 minecraft:blackstone
fill 111 179 511 112 179 511 minecraft:blackstone
setblock 113 179 511 minecraft:smooth_basalt
fill 113 179 512 113 182 512 minecraft:blackstone
fill 114 179 511 117 179 511 minecraft:blackstone
fill 114 179 551 117 179 551 minecraft:blackstone
setblock 117 179 512 minecraft:smooth_basalt
fill 117 179 525 120 179 525 minecraft:smooth_basalt
setblock 118 179 511 minecraft:smooth_basalt
setblock 118 179 512 minecraft:blackstone
fill 118 179 524 119 221 524 minecraft:smooth_basalt
fill 118 179 526 119 179 526 minecraft:smooth_basalt
setblock 118 179 551 minecraft:smooth_basalt
fill 119 179 511 119 182 511 minecraft:blackstone
fill 119 179 551 119 182 551 minecraft:blackstone
fill 121 179 526 122 182 526 minecraft:jungle_leaves[persistent=true]
fill 121 179 536 122 182 536 minecraft:jungle_leaves[persistent=true]
fill 123 179 525 123 182 525 minecraft:jungle_leaves[persistent=true]
fill 123 179 537 123 182 537 minecraft:jungle_leaves[persistent=true]
fill 124 179 526 126 182 527 minecraft:jungle_leaves[persistent=true]
fill 124 179 535 126 182 536 minecraft:jungle_leaves[persistent=true]
fill 126 179 528 128 182 528 minecraft:jungle_leaves[persistent=true]
fill 126 179 534 128 182 534 minecraft:jungle_leaves[persistent=true]
fill 127 179 527 127 182 527 minecraft:jungle_leaves[persistent=true]
fill 127 179 529 128 182 533 minecraft:jungle_leaves[persistent=true]
fill 127 179 535 127 182 535 minecraft:jungle_leaves[persistent=true]
fill 129 179 531 129 182 531 minecraft:jungle_leaves[persistent=true]
fill 131 179 551 131 180 551 minecraft:blackstone
setblock 133 179 541 minecraft:smooth_basalt
fill 133 179 542 133 182 542 minecraft:blackstone
setblock 133 179 546 minecraft:smooth_basalt
setblock 133 179 551 minecraft:smooth_basalt
setblock 134 179 519 minecraft:blackstone
setblock 134 179 520 minecraft:smooth_basalt
fill 134 179 521 134 182 521 minecraft:blackstone
setblock 134 179 535 minecraft:smooth_basalt
fill 134 179 536 134 182 536 minecraft:blackstone
setblock 134 179 540 minecraft:smooth_basalt
fill 134 179 541 134 182 541 minecraft:blackstone
setblock 134 179 545 minecraft:smooth_basalt
fill 134 179 546 134 182 546 minecraft:blackstone
setblock 134 179 549 minecraft:blackstone
fill 134 179 551 134 182 551 minecraft:blackstone
setblock 135 179 514 minecraft:smooth_basalt
fill 135 179 515 135 182 515 minecraft:blackstone
setblock 135 179 519 minecraft:smooth_basalt
fill 135 179 520 135 182 520 minecraft:blackstone
setblock 135 179 524 minecraft:smooth_basalt
fill 135 179 525 135 179 528 minecraft:blackstone
fill 135 179 530 135 182 530 minecraft:blackstone
setblock 135 179 534 minecraft:smooth_basalt
fill 135 179 535 135 182 535 minecraft:blackstone
setblock 135 179 539 minecraft:smooth_basalt
fill 135 179 540 135 182 540 minecraft:blackstone
setblock 135 179 544 minecraft:smooth_basalt
fill 135 179 545 135 182 545 minecraft:blackstone
setblock 135 179 549 minecraft:smooth_basalt
fill 135 179 550 135 182 550 minecraft:blackstone
fill 95 180 514 95 180 517 minecraft:blackstone
setblock 95 180 518 minecraft:smooth_basalt
fill 95 180 519 95 183 519 minecraft:blackstone
setblock 95 180 523 minecraft:smooth_basalt
fill 95 180 524 95 183 524 minecraft:blackstone
setblock 95 180 528 minecraft:smooth_basalt
fill 95 180 529 95 180 532 minecraft:blackstone
setblock 95 180 533 minecraft:smooth_basalt
fill 95 180 534 95 183 534 minecraft:blackstone
setblock 95 180 538 minecraft:smooth_basalt
fill 95 180 539 95 183 539 minecraft:blackstone
setblock 95 180 543 minecraft:smooth_basalt
fill 95 180 544 95 183 544 minecraft:blackstone
setblock 95 180 548 minecraft:smooth_basalt
fill 95 180 549 95 183 549 minecraft:blackstone
setblock 96 180 517 minecraft:smooth_basalt
fill 96 180 518 96 183 518 minecraft:blackstone
setblock 96 180 522 minecraft:smooth_basalt
fill 96 180 523 96 183 523 minecraft:blackstone
setblock 96 180 527 minecraft:smooth_basalt
fill 96 180 528 96 183 528 minecraft:blackstone
setblock 96 180 532 minecraft:smooth_basalt
fill 96 180 533 96 183 533 minecraft:blackstone
setblock 96 180 537 minecraft:smooth_basalt
fill 96 180 538 96 183 538 minecraft:blackstone
setblock 96 180 542 minecraft:smooth_basalt
fill 96 180 543 96 183 543 minecraft:blackstone
setblock 97 180 520 minecraft:blackstone
setblock 97 180 521 minecraft:smooth_basalt
fill 97 180 522 97 183 522 minecraft:blackstone
fill 97 180 524 97 181 524 minecraft:blackstone
setblock 97 180 541 minecraft:smooth_basalt
fill 97 180 542 97 182 542 minecraft:blackstone
setblock 111 180 511 minecraft:blackstone
setblock 112 180 511 minecraft:smooth_basalt
fill 112 180 512 112 183 512 minecraft:blackstone
fill 113 180 511 116 180 511 minecraft:blackstone
fill 113 180 551 116 180 551 minecraft:blackstone
setblock 116 180 512 minecraft:smooth_basalt
setblock 117 180 511 minecraft:smooth_basalt
fill 117 180 512 117 183 512 minecraft:blackstone
fill 117 180 525 117 221 527 minecraft:smooth_basalt
fill 117 180 528 120 181 528 minecraft:jungle_leaves[persistent=true]
fill 117 180 534 120 181 534 minecraft:jungle_leaves[persistent=true]
setblock 117 180 551 minecraft:smooth_basalt
fill 118 180 511 118 183 511 minecraft:blackstone
fill 118 180 525 118 221 526 minecraft:smooth_basalt
fill 118 180 527 119 181 527 minecraft:jungle_leaves[persistent=true]
fill 118 180 535 119 181 535 minecraft:jungle_leaves[persistent=true]
fill 118 180 551 118 183 551 minecraft:blackstone
fill 119 180 525 119 221 525 minecraft:smooth_basalt
fill 119 180 526 119 181 526 minecraft:jungle_leaves[persistent=true]
fill 119 180 536 119 181 536 minecraft:jungle_leaves[persistent=true]
fill 120 180 525 122 181 525 minecraft:jungle_leaves[persistent=true]
fill 120 180 537 122 181 537 minecraft:jungle_leaves[persistent=true]
fill 124 180 525 126 181 525 minecraft:jungle_leaves[persistent=true]
fill 124 180 537 126 181 537 minecraft:jungle_leaves[persistent=true]
fill 127 180 526 127 181 526 minecraft:jungle_leaves[persistent=true]
fill 127 180 536 127 181 536 minecraft:jungle_leaves[persistent=true]
fill 128 180 527 128 181 527 minecraft:jungle_leaves[persistent=true]
fill 128 180 535 128 181 535 minecraft:jungle_leaves[persistent=true]
fill 129 180 528 129 181 530 minecraft:jungle_leaves[persistent=true]
fill 129 180 532 129 181 534 minecraft:jungle_leaves[persistent=true]
fill 130 180 551 130 181 551 minecraft:blackstone
setblock 132 180 551 minecraft:smooth_basalt
setblock 133 180 540 minecraft:smooth_basalt
fill 133 180 541 133 183 541 minecraft:blackstone
setblock 133 180 545 minecraft:smooth_basalt
fill 133 180 546 133 182 547 minecraft:blackstone
setblock 133 180 550 minecraft:smooth_basalt
fill 133 180 551 133 183 551 minecraft:blackstone
setblock 134 180 519 minecraft:smooth_basalt
fill 134 180 520 134 183 520 minecraft:blackstone
fill 134 180 522 134 180 523 minecraft:blackstone
fill 134 180 535 134 183 535 minecraft:blackstone
setblock 134 180 539 minecraft:smooth_basalt
fill 134 180 540 134 183 540 minecraft:blackstone
setblock 134 180 544 minecraft:smooth_basalt
fill 134 180 545 134 183 545 minecraft:blackstone
setblock 134 180 549 minecraft:smooth_basalt
fill 134 180 550 134 183 550 minecraft:blackstone
setblock 135 180 514 minecraft:blackstone
setblock 135 180 518 minecraft:smooth_basalt
fill 135 180 519 135 183 519 minecraft:blackstone
setblock 135 180 523 minecraft:smooth_basalt
fill 135 180 524 135 180 527 minecraft:blackstone
setblock 135 180 528 minecraft:smooth_basalt
fill 135 180 529 135 183 529 minecraft:blackstone
setblock 135 180 533 minecraft:smooth_basalt
fill 135 180 534 135 183 534 minecraft:blackstone
setblock 135 180 538 minecraft:smooth_basalt
fill 135 180 539 135 183 539 minecraft:blackstone
setblock 135 180 543 minecraft:smooth_basalt
fill 135 180 544 135 183 544 minecraft:blackstone
setblock 135 180 548 minecraft:smooth_basalt
fill 135 180 549 135 183 549 minecraft:blackstone
fill 95 181 514 95 181 516 minecraft:blackstone
setblock 95 181 517 minecraft:smooth_basalt
fill 95 181 518 95 184 518 minecraft:blackstone
setblock 95 181 522 minecraft:smooth_basalt
fill 95 181 523 95 184 523 minecraft:blackstone
setblock 95 181 527 minecraft:smooth_basalt
fill 95 181 528 95 181 531 minecraft:blackstone
setblock 95 181 532 minecraft:smooth_basalt
fill 95 181 533 95 184 533 minecraft:blackstone
setblock 95 181 537 minecraft:smooth_basalt
fill 95 181 538 95 184 538 minecraft:blackstone
setblock 95 181 542 minecraft:smooth_basalt
fill 95 181 543 95 184 543 minecraft:blackstone
setblock 95 181 547 minecraft:smooth_basalt
fill 95 181 548 95 184 548 minecraft:blackstone
fill 95 181 550 95 182 550 minecraft:blackstone
fill 96 181 517 96 184 517 minecraft:blackstone
setblock 96 181 521 minecraft:smooth_basalt
fill 96 181 522 96 184 522 minecraft:blackstone
setblock 96 181 526 minecraft:smooth_basalt
fill 96 181 527 96 184 527 minecraft:blackstone
setblock 96 181 531 minecraft:smooth_basalt
fill 96 181 532 96 184 532 minecraft:blackstone
setblock 96 181 536 minecraft:smooth_basalt
fill 96 181 537 96 184 537 minecraft:blackstone
setblock 96 181 541 minecraft:smooth_basalt
fill 96 181 542 96 184 542 minecraft:blackstone
setblock 96 181 546 minecraft:smooth_basalt
fill 96 181 547 96 184 547 minecraft:blackstone
setblock 97 181 520 minecraft:smooth_basalt
fill 97 181 521 97 184 521 minecraft:blackstone
setblock 97 181 525 minecraft:smooth_basalt
fill 97 181 526 97 184 526 minecraft:blackstone
setblock 97 181 540 minecraft:smooth_basalt
fill 97 181 541 97 182 541 minecraft:blackstone
setblock 110 181 511 minecraft:blackstone
setblock 111 181 511 minecraft:smooth_basalt
fill 112 181 511 115 181 511 minecraft:blackstone
fill 112 181 551 115 181 551 minecraft:blackstone
setblock 115 181 512 minecraft:smooth_basalt
fill 115 181 550 116 181 550 minecraft:blackstone
setblock 116 181 511 minecraft:smooth_basalt
fill 116 181 512 116 184 512 minecraft:blackstone
setblock 116 181 551 minecraft:smooth_basalt
fill 117 181 511 117 184 511 minecraft:blackstone
fill 117 181 551 117 184 551 minecraft:blackstone
setblock 120 181 551 minecraft:blackstone
fill 128 181 551 129 182 551 minecraft:blackstone
fill 130 181 550 131 181 550 minecraft:blackstone
setblock 131 181 551 minecraft:smooth_basalt
fill 132 181 541 132 181 544 minecraft:blackstone
setblock 132 181 545 minecraft:smooth_basalt
setblock 132 181 550 minecraft:smooth_basalt
fill 132 181 551 132 184 551 minecraft:blackstone
fill 133 181 537 133 182 537 minecraft:blackstone
setblock 133 181 539 minecraft:smooth_basalt
fill 133 181 540 133 184 540 minecraft:blackstone
setblock 133 181 544 minecraft:smooth_basalt
fill 133 181 545 133 184 545 minecraft:blackstone
setblock 133 181 548 minecraft:blackstone
fill 133 181 550 133 184 550 minecraft:blackstone
setblock 134 181 518 minecraft:smooth_basalt
fill 134 181 519 134 184 519 minecraft:blackstone
setblock 134 181 522 minecraft:blackstone
setblock 134 181 523 minecraft:smooth_basalt
fill 134 181 524 135 181 526 minecraft:blackstone
fill 134 181 534 134 184 534 minecraft:blackstone
setblock 134 181 538 minecraft:smooth_basalt
fill 134 181 539 134 184 539 minecraft:blackstone
setblock 134 181 543 minecraft:smooth_basalt
fill 134 181 544 134 184 544 minecraft:blackstone
setblock 134 181 548 minecraft:smooth_basalt
fill 134 181 549 134 184 549 minecraft:blackstone
setblock 135 181 517 minecraft:smooth_basalt
fill 135 181 518 135 184 518 minecraft:blackstone
setblock 135 181 522 minecraft:smooth_basalt
fill 135 181 523 135 184 523 minecraft:blackstone
setblock 135 181 527 minecraft:smooth_basalt
fill 135 181 528 135 184 528 minecraft:blackstone
setblock 135 181 532 minecraft:smooth_basalt
fill 135 181 533 135 184 533 minecraft:blackstone
setblock 135 181 537 minecraft:smooth_basalt
fill 135 181 538 135 184 538 minecraft:blackstone
setblock 135 181 542 minecraft:smooth_basalt
fill 135 181 543 135 184 543 minecraft:blackstone
setblock 135 181 547 minecraft:smooth_basalt
fill 135 181 548 135 184 548 minecraft:blackstone
fill 95 182 514 95 182 515 minecraft:blackstone
setblock 95 182 516 minecraft:smooth_basalt
fill 95 182 517 95 185 517 minecraft:blackstone
setblock 95 182 521 minecraft:smooth_basalt
fill 95 182 522 95 185 522 minecraft:blackstone
setblock 95 182 526 minecraft:smooth_basalt
fill 95 182 527 95 182 530 minecraft:blackstone
setblock 95 182 531 minecraft:smooth_basalt
fill 95 182 532 95 185 532 minecraft:blackstone
setblock 95 182 536 minecraft:smooth_basalt
fill 95 182 537 95 185 537 minecraft:blackstone
setblock 95 182 541 minecraft:smooth_basalt
fill 95 182 542 95 185 542 minecraft:blackstone
setblock 95 182 546 minecraft:smooth_basalt
fill 95 182 547 95 185 547 minecraft:blackstone
setblock 95 182 551 minecraft:smooth_basalt
setblock 96 182 520 minecraft:smooth_basalt
fill 96 182 521 96 185 521 minecraft:blackstone
setblock 96 182 525 minecraft:smooth_basalt
fill 96 182 526 96 185 526 minecraft:blackstone
setblock 96 182 530 minecraft:smooth_basalt
fill 96 182 531 96 185 531 minecraft:blackstone
setblock 96 182 535 minecraft:smooth_basalt
fill 96 182 536 96 184 536 minecraft:blackstone
setblock 96 182 540 minecraft:smooth_basalt
fill 96 182 541 96 185 541 minecraft:blackstone
setblock 96 182 545 minecraft:smooth_basalt
fill 96 182 546 96 185 546 minecraft:blackstone
fill 97 182 520 97 185 520 minecraft:blackstone
setblock 97 182 524 minecraft:smooth_basalt
fill 97 182 525 97 185 525 minecraft:blackstone
fill 97 182 527 97 183 527 minecraft:blackstone
setblock 109 182 511 minecraft:blackstone
setblock 110 182 511 minecraft:smooth_basalt
setblock 110 182 551 minecraft:smooth_basalt
fill 111 182 511 111 184 512 minecraft:blackstone
fill 111 182 551 114 182 551 minecraft:blackstone
fill 112 182 511 114 182 511 minecraft:blackstone
fill 112 182 550 115 182 550 minecraft:blackstone
setblock 114 182 512 minecraft:smooth_basalt
setblock 115 182 511 minecraft:smooth_basalt
fill 115 182 512 115 185 512 minecraft:blackstone
setblock 115 182 551 minecraft:smooth_basalt
fill 116 182 511 116 185 511 minecraft:blackstone
setblock 116 182 550 minecraft:smooth_basalt
fill 116 182 551 116 185 551 minecraft:blackstone
fill 117 182 550 118 184 550 minecraft:blackstone
fill 118 182 527 118 221 527 minecraft:smooth_basalt
fill 118 182 528 120 182 530 minecraft:jungle_leaves[persistent=true]
fill 118 182 532 120 182 534 minecraft:jungle_leaves[persistent=true]
fill 119 182 526 119 221 526 minecraft:smooth_basalt
setblock 119 182 527 minecraft:jungle_leaves[persistent=true]
setblock 119 182 535 minecraft:jungle_leaves[persistent=true]
setblock 120 182 511 minecraft:smooth_basalt
fill 120 182 525 120 221 525 minecraft:smooth_basalt
setblock 120 182 551 minecraft:smooth_basalt
fill 121 182 551 122 184 551 minecraft:blackstone
setblock 125 182 551 minecraft:smooth_basalt
fill 126 182 551 127 184 551 minecraft:blackstone
fill 128 182 550 130 182 550 minecraft:blackstone
setblock 130 182 551 minecraft:smooth_basalt
setblock 131 182 549 minecraft:blackstone
setblock 131 182 550 minecraft:smooth_basalt
fill 131 182 551 131 185 551 minecraft:blackstone
fill 132 182 540 132 182 543 minecraft:blackstone
setblock 132 182 544 minecraft:smooth_basalt
fill 132 182 545 132 183 547 minecraft:blackstone
setblock 132 182 549 minecraft:smooth_basalt
fill 132 182 550 132 185 550 minecraft:blackstone
setblock 133 182 538 minecraft:smooth_basalt
fill 133 182 539 133 185 539 minecraft:blackstone
setblock 133 182 543 minecraft:smooth_basalt
fill 133 182 544 133 185 544 minecraft:blackstone
setblock 133 182 548 minecraft:smooth_basalt
fill 133 182 549 133 185 549 minecraft:blackstone
fill 134 182 518 134 184 518 minecraft:blackstone
setblock 134 182 522 minecraft:smooth_basalt
fill 134 182 523 134 182 526 minecraft:blackstone
setblock 134 182 527 minecraft:smooth_basalt
fill 134 182 528 134 183 530 minecraft:blackstone
setblock 134 182 532 minecraft:smooth_basalt
fill 134 182 533 134 185 533 minecraft:blackstone
setblock 134 182 537 minecraft:smooth_basalt
fill 134 182 538 134 185 538 minecraft:blackstone
setblock 134 182 542 minecraft:smooth_basalt
fill 134 182 543 134 185 543 minecraft:blackstone
setblock 134 182 547 minecraft:smooth_basalt
fill 134 182 548 134 185 548 minecraft:blackstone
setblock 135 182 516 minecraft:smooth_basalt
fill 135 182 517 135 185 517 minecraft:blackstone
setblock 135 182 521 minecraft:smooth_basalt
fill 135 182 522 135 185 522 minecraft:blackstone
fill 135 182 524 135 182 525 minecraft:blackstone
setblock 135 182 526 minecraft:smooth_basalt
fill 135 182 527 135 185 527 minecraft:blackstone
setblock 135 182 531 minecraft:smooth_basalt
fill 135 182 532 135 185 532 minecraft:blackstone
setblock 135 182 536 minecraft:smooth_basalt
fill 135 182 537 135 185 537 minecraft:blackstone
setblock 135 182 541 minecraft:smooth_basalt
fill 135 182 542 135 185 542 minecraft:blackstone
setblock 135 182 546 minecraft:smooth_basalt
fill 135 182 547 135 185 547 minecraft:blackstone
setblock 135 182 551 minecraft:smooth_basalt
setblock 95 183 514 minecraft:blackstone
setblock 95 183 515 minecraft:smooth_basalt
fill 95 183 516 95 186 516 minecraft:blackstone
setblock 95 183 520 minecraft:smooth_basalt
fill 95 183 521 95 186 521 minecraft:blackstone
setblock 95 183 525 minecraft:smooth_basalt
fill 95 183 526 95 183 529 minecraft:blackstone
setblock 95 183 530 minecraft:smooth_basalt
fill 95 183 531 95 186 531 minecraft:blackstone
setblock 95 183 535 minecraft:smooth_basalt
fill 95 183 536 95 186 536 minecraft:blackstone
setblock 95 183 540 minecraft:smooth_basalt
fill 95 183 541 95 186 541 minecraft:blackstone
setblock 95 183 545 minecraft:smooth_basalt
fill 95 183 546 95 186 546 minecraft:blackstone
setblock 95 183 550 minecraft:smooth_basalt
fill 95 183 551 96 185 551 minecraft:blackstone
setblock 96 183 519 minecraft:smooth_basalt
fill 96 183 520 96 186 520 minecraft:blackstone
setblock 96 183 524 minecraft:smooth_basalt
fill 96 183 525 96 186 525 minecraft:blackstone
setblock 96 183 529 minecraft:smooth_basalt
fill 96 183 530 96 186 530 minecraft:blackstone
setblock 96 183 534 minecraft:smooth_basalt
fill 96 183 535 96 185 535 minecraft:blackstone
setblock 96 183 539 minecraft:smooth_basalt
fill 96 183 540 96 185 540 minecraft:blackstone
setblock 96 183 544 minecraft:smooth_basalt
fill 96 183 545 96 186 545 minecraft:blackstone
setblock 96 183 548 minecraft:blackstone
setblock 97 183 523 minecraft:smooth_basalt
fill 97 183 524 97 186 524 minecraft:blackstone
setblock 97 183 528 minecraft:smooth_basalt
setblock 108 183 511 minecraft:blackstone
setblock 109 183 511 minecraft:smooth_basalt
setblock 109 183 551 minecraft:smooth_basalt
fill 110 183 511 110 185 512 minecraft:blackstone
setblock 110 183 550 minecraft:smooth_basalt
fill 110 183 551 113 183 551 minecraft:blackstone
fill 111 183 550 114 183 550 minecraft:blackstone
fill 112 183 511 113 183 511 minecraft:blackstone
setblock 113 183 512 minecraft:smooth_basalt
fill 113 183 513 113 186 513 minecraft:blackstone
fill 113 183 549 115 183 549 minecraft:blackstone
setblock 114 183 511 minecraft:smooth_basalt
fill 114 183 512 114 186 512 minecraft:blackstone
setblock 114 183 551 minecraft:smooth_basalt
fill 115 183 511 115 186 511 minecraft:blackstone
setblock 115 183 550 minecraft:smooth_basalt
fill 115 183 551 115 186 551 minecraft:blackstone
setblock 116 183 549 minecraft:smooth_basalt
fill 116 183 550 116 186 550 minecraft:blackstone
setblock 119 183 511 minecraft:smooth_basalt
fill 119 183 527 120 221 527 minecraft:smooth_basalt
setblock 119 183 550 minecraft:blackstone
setblock 119 183 551 minecraft:smooth_basalt
fill 120 183 511 120 186 511 minecraft:blackstone
fill 120 183 526 120 221 526 minecraft:smooth_basalt
fill 120 183 529 121 183 530 minecraft:jungle_leaves[persistent=true]
fill 120 183 532 121 183 533 minecraft:jungle_leaves[persistent=true]
setblock 120 183 550 minecraft:smooth_basalt
fill 120 183 551 120 186 551 minecraft:blackstone
fill 121 183 528 123 183 528 minecraft:jungle_leaves[persistent=true]
fill 121 183 534 123 183 534 minecraft:jungle_leaves[persistent=true]
setblock 123 183 551 minecraft:blackstone
setblock 124 183 551 minecraft:smooth_basalt
fill 125 183 551 125 186 551 minecraft:blackstone
fill 126 183 550 129 183 550 minecraft:blackstone
fill 128 183 549 130 183 549 minecraft:blackstone
setblock 128 183 551 minecraft:blackstone
setblock 129 183 551 minecraft:smooth_basalt
setblock 130 183 550 minecraft:smooth_basalt
fill 130 183 551 130 186 551 minecraft:blackstone
fill 131 183 511 133 183 511 minecraft:blackstone
setblock 131 183 548 minecraft:blackstone
setblock 131 183 549 minecraft:smooth_basalt
fill 131 183 550 131 186 550 minecraft:blackstone
fill 132 183 540 132 183 542 minecraft:blackstone
setblock 132 183 543 minecraft:smooth_basalt
fill 132 183 544 132 186 544 minecraft:blackstone
setblock 132 183 548 minecraft:smooth_basalt
fill 132 183 549 132 186 549 minecraft:blackstone
setblock 133 183 522 minecraft:smooth_basalt
fill 133 183 523 133 183 526 minecraft:blackstone
setblock 133 183 537 minecraft:smooth_basalt
fill 133 183 538 133 186 538 minecraft:blackstone
setblock 133 183 542 minecraft:smooth_basalt
fill 133 183 543 133 186 543 minecraft:blackstone
setblock 133 183 546 minecraft:blackstone
setblock 133 183 547 minecraft:smooth_basalt
fill 133 183 548 133 186 548 minecraft:blackstone
setblock 134 183 521 minecraft:smooth_basalt
fill 134 183 522 134 183 525 minecraft:blackstone
setblock 134 183 526 minecraft:smooth_basalt
fill 134 183 527 134 186 527 minecraft:blackstone
setblock 134 183 531 minecraft:smooth_basalt
fill 134 183 532 134 186 532 minecraft:blackstone
setblock 134 183 536 minecraft:smooth_basalt
fill 134 183 537 134 186 537 minecraft:blackstone
setblock 134 183 541 minecraft:smooth_basalt
fill 134 183 542 134 186 542 minecraft:blackstone
setblock 134 183 546 minecraft:smooth_basalt
fill 134 183 547 134 186 547 minecraft:blackstone
setblock 134 183 551 minecraft:smooth_basalt
setblock 135 183 515 minecraft:smooth_basalt
fill 135 183 516 135 185 516 minecraft:blackstone
setblock 135 183 520 minecraft:smooth_basalt
fill 135 183 521 135 186 521 minecraft:blackstone
setblock 135 183 524 minecraft:blackstone
setblock 135 183 525 minecraft:smooth_basalt
fill 135 183 526 135 186 526 minecraft:blackstone
setblock 135 183 530 minecraft:smooth_basalt
fill 135 183 531 135 186 531 minecraft:blackstone
setblock 135 183 535 minecraft:smooth_basalt
fill 135 183 536 135 186 536 minecraft:blackstone
setblock 135 183 540 minecraft:smooth_basalt
fill 135 183 541 135 186 541 minecraft:blackstone
setblock 135 183 545 minecraft:smooth_basalt
fill 135 183 546 135 186 546 minecraft:blackstone
setblock 135 183 550 minecraft:smooth_basalt
fill 135 183 551 135 186 551 minecraft:blackstone
setblock 95 184 514 minecraft:smooth_basalt
fill 95 184 515 95 186 515 minecraft:blackstone
setblock 95 184 519 minecraft:smooth_basalt
fill 95 184 520 95 187 520 minecraft:blackstone
setblock 95 184 524 minecraft:smooth_basalt
fill 95 184 525 95 184 528 minecraft:blackstone
setblock 95 184 529 minecraft:smooth_basalt
fill 95 184 530 95 187 530 minecraft:blackstone
setblock 95 184 534 minecraft:smooth_basalt
fill 95 184 535 95 187 535 minecraft:blackstone
setblock 95 184 539 minecraft:smooth_basalt
fill 95 184 540 95 187 540 minecraft:blackstone
setblock 95 184 544 minecraft:smooth_basalt
fill 95 184 545 95 187 545 minecraft:blackstone
setblock 95 184 549 minecraft:smooth_basalt
fill 95 184 550 95 187 550 minecraft:blackstone
setblock 96 184 518 minecraft:smooth_basalt
fill 96 184 519 96 187 519 minecraft:blackstone
setblock 96 184 523 minecraft:smooth_basalt
fill 96 184 524 96 187 524 minecraft:blackstone
setblock 96 184 528 minecraft:smooth_basalt
fill 96 184 529 97 186 529 minecraft:blackstone
setblock 96 184 533 minecraft:smooth_basalt
fill 96 184 534 96 186 534 minecraft:blackstone
setblock 96 184 538 minecraft:smooth_basalt
fill 96 184 539 96 185 539 minecraft:blackstone
setblock 96 184 543 minecraft:smooth_basalt
fill 96 184 544 96 187 544 minecraft:blackstone
setblock 96 184 548 minecraft:smooth_basalt
setblock 97 184 522 minecraft:smooth_basalt
fill 97 184 523 97 187 523 minecraft:blackstone
setblock 97 184 527 minecraft:smooth_basalt
fill 97 184 528 97 187 528 minecraft:blackstone
setblock 97 184 537 minecraft:light[level=12]
setblock 97 184 545 minecraft:light[level=12]
setblock 105 184 513 minecraft:light[level=12]
setblock 105 184 521 minecraft:light[level=12]
setblock 105 184 529 minecraft:light[level=12]
setblock 105 184 537 minecraft:light[level=12]
setblock 105 184 545 minecraft:light[level=12]
fill 106 184 511 107 184 511 minecraft:blackstone
setblock 107 184 551 minecraft:blackstone
setblock 108 184 511 minecraft:smooth_basalt
setblock 108 184 551 minecraft:smooth_basalt
fill 109 184 511 109 186 512 minecraft:blackstone
setblock 109 184 550 minecraft:smooth_basalt
fill 109 184 551 112 184 551 minecraft:blackstone
fill 110 184 550 113 184 550 minecraft:blackstone
setblock 111 184 513 minecraft:smooth_basalt
fill 111 184 549 114 184 549 minecraft:blackstone
setblock 112 184 511 minecraft:blackstone
setblock 112 184 512 minecraft:smooth_basalt
fill 112 184 513 112 187 513 minecraft:blackstone
setblock 113 184 511 minecraft:smooth_basalt
fill 113 184 512 113 187 512 minecraft:blackstone
setblock 113 184 521 minecraft:light[level=12]
setblock 113 184 529 minecraft:light[level=12]
setblock 113 184 537 minecraft:light[level=12]
setblock 113 184 545 minecraft:light[level=12]
setblock 113 184 551 minecraft:smooth_basalt
fill 114 184 511 114 187 511 minecraft:blackstone
setblock 114 184 550 minecraft:smooth_basalt
fill 114 184 551 114 187 551 minecraft:blackstone
setblock 115 184 549 minecraft:smooth_basalt
fill 115 184 550 115 187 550 minecraft:blackstone
fill 116 184 549 117 186 549 minecraft:blackstone
setblock 117 184 512 minecraft:smooth_basalt
setblock 118 184 511 minecraft:smooth_basalt
setblock 118 184 551 minecraft:smooth_basalt
fill 119 184 511 119 187 511 minecraft:blackstone
setblock 119 184 550 minecraft:smooth_basalt
fill 119 184 551 119 187 551 minecraft:blackstone
fill 120 184 550 123 184 550 minecraft:blackstone
setblock 121 184 513 minecraft:light[level=12]
setblock 121 184 521 minecraft:light[level=12]
setblock 121 184 529 minecraft:light[level=12]
setblock 121 184 537 minecraft:light[level=12]
setblock 121 184 545 minecraft:light[level=12]
setblock 123 184 551 minecraft:smooth_basalt
setblock 124 184 550 minecraft:smooth_basalt
fill 124 184 551 124 187 551 minecraft:blackstone
fill 125 184 550 128 184 550 minecraft:blackstone
fill 127 184 549 129 184 549 minecraft:blackstone
setblock 128 184 551 minecraft:smooth_basalt
fill 129 184 511 132 184 511 minecraft:blackstone
setblock 129 184 513 minecraft:light[level=12]
setblock 129 184 521 minecraft:light[level=12]
setblock 129 184 529 minecraft:light[level=12]
setblock 129 184 537 minecraft:light[level=12]
setblock 129 184 545 minecraft:light[level=12]
fill 129 184 548 130 184 548 minecraft:blackstone
setblock 129 184 550 minecraft:smooth_basalt
fill 129 184 551 129 187 551 minecraft:blackstone
setblock 130 184 549 minecraft:smooth_basalt
fill 130 184 550 130 187 550 minecraft:blackstone
fill 131 184 544 131 185 546 minecraft:blackstone
setblock 131 184 548 minecraft:smooth_basalt
fill 131 184 549 131 187 549 minecraft:blackstone
fill 132 184 540 132 184 541 minecraft:blackstone
setblock 132 184 542 minecraft:smooth_basalt
fill 132 184 543 132 187 543 minecraft:blackstone
fill 132 184 545 132 184 546 minecraft:blackstone
setblock 132 184 547 minecraft:smooth_basalt
fill 132 184 548 132 187 548 minecraft:blackstone
setblock 133 184 511 minecraft:smooth_basalt
setblock 133 184 521 minecraft:smooth_basalt
fill 133 184 522 133 184 525 minecraft:blackstone
setblock 133 184 526 minecraft:smooth_basalt
fill 133 184 527 133 185 529 minecraft:blackstone
setblock 133 184 536 minecraft:smooth_basalt
fill 133 184 537 133 186 537 minecraft:blackstone
setblock 133 184 541 minecraft:smooth_basalt
fill 133 184 542 133 187 542 minecraft:blackstone
setblock 133 184 546 minecraft:smooth_basalt
fill 133 184 547 133 187 547 minecraft:blackstone
setblock 133 184 551 minecraft:smooth_basalt
fill 134 184 511 134 187 511 minecraft:blackstone
setblock 134 184 520 minecraft:smooth_basalt
fill 134 184 521 134 184 524 minecraft:blackstone
setblock 134 184 525 minecraft:smooth_basalt
fill 134 184 526 134 187 526 minecraft:blackstone
fill 134 184 528 134 184 529 minecraft:blackstone
setblock 134 184 530 minecraft:smooth_basalt
fill 134 184 531 134 187 531 minecraft:blackstone
setblock 134 184 535 minecraft:smooth_basalt
fill 134 184 536 134 187 536 minecraft:blackstone
setblock 134 184 540 minecraft:smooth_basalt
fill 134 184 541 134 187 541 minecraft:blackstone
setblock 134 184 545 minecraft:smooth_basalt
fill 134 184 546 134 187 546 minecraft:blackstone
setblock 134 184 550 minecraft:smooth_basalt
fill 134 184 551 134 187 551 minecraft:blackstone
setblock 135 184 519 minecraft:smooth_basalt
fill 135 184 520 135 187 520 minecraft:blackstone
setblock 135 184 524 minecraft:smooth_basalt
fill 135 184 525 135 187 525 minecraft:blackstone
setblock 135 184 529 minecraft:smooth_basalt
fill 135 184 530 135 187 530 minecraft:blackstone
setblock 135 184 534 minecraft:smooth_basalt
fill 135 184 535 135 187 535 minecraft:blackstone
setblock 135 184 539 minecraft:smooth_basalt
fill 135 184 540 135 187 540 minecraft:blackstone
setblock 135 184 544 minecraft:smooth_basalt
fill 135 184 545 135 187 545 minecraft:blackstone
setblock 135 184 549 minecraft:smooth_basalt
fill 135 184 550 135 187 550 minecraft:blackstone
fill 95 185 514 95 186 514 minecraft:blackstone
setblock 95 185 518 minecraft:smooth_basalt
fill 95 185 519 95 188 519 minecraft:blackstone
setblock 95 185 523 minecraft:smooth_basalt
fill 95 185 524 95 185 527 minecraft:blackstone
setblock 95 185 528 minecraft:smooth_basalt
fill 95 185 529 95 188 529 minecraft:blackstone
setblock 95 185 533 minecraft:smooth_basalt
fill 95 185 534 95 188 534 minecraft:blackstone
setblock 95 185 538 minecraft:smooth_basalt
fill 95 185 539 95 188 539 minecraft:blackstone
setblock 95 185 543 minecraft:smooth_basalt
fill 95 185 544 95 188 544 minecraft:blackstone
setblock 95 185 548 minecraft:smooth_basalt
fill 95 185 549 96 186 549 minecraft:blackstone
fill 96 185 518 96 186 518 minecraft:blackstone
setblock 96 185 522 minecraft:smooth_basalt
fill 96 185 523 96 188 523 minecraft:blackstone
setblock 96 185 527 minecraft:smooth_basalt
fill 96 185 528 96 188 528 minecraft:blackstone
setblock 96 185 532 minecraft:smooth_basalt
fill 96 185 533 96 187 533 minecraft:blackstone
setblock 96 185 537 minecraft:smooth_basalt
setblock 96 185 538 minecraft:blackstone
setblock 96 185 542 minecraft:smooth_basalt
fill 96 185 543 96 186 543 minecraft:blackstone
setblock 96 185 547 minecraft:smooth_basalt
fill 96 185 548 96 187 548 minecraft:blackstone
setblock 97 185 521 minecraft:smooth_basalt
fill 97 185 522 97 187 522 minecraft:blackstone
setblock 97 185 526 minecraft:smooth_basalt
fill 97 185 527 97 188 527 minecraft:blackstone
fill 105 185 511 106 185 511 minecraft:blackstone
setblock 106 185 551 minecraft:blackstone
setblock 107 185 511 minecraft:smooth_basalt
setblock 107 185 551 minecraft:smooth_basalt
fill 108 185 511 108 187 512 minecraft:blackstone
setblock 108 185 550 minecraft:smooth_basalt
fill 108 185 551 111 185 551 minecraft:blackstone
fill 109 185 550 112 185 550 minecraft:blackstone
setblock 110 185 513 minecraft:smooth_basalt
fill 110 185 549 113 185 549 minecraft:blackstone
setblock 111 185 511 minecraft:blackstone
setblock 111 185 512 minecraft:smooth_basalt
fill 111 185 513 111 188 513 minecraft:blackstone
setblock 112 185 511 minecraft:smooth_basalt
fill 112 185 512 112 188 512 minecraft:blackstone
setblock 112 185 551 minecraft:smooth_basalt
fill 113 185 511 113 188 511 minecraft:blackstone
fill 113 185 539 115 186 539 minecraft:gilded_blackstone
fill 113 185 548 113 186 548 minecraft:blackstone
setblock 113 185 550 minecraft:smooth_basalt
fill 113 185 551 113 188 551 minecraft:blackstone
fill 114 185 538 114 186 538 minecraft:gilded_blackstone
fill 114 185 540 114 186 540 minecraft:gilded_blackstone
setblock 114 185 549 minecraft:smooth_basalt
fill 114 185 550 114 188 550 minecraft:blackstone
fill 115 185 549 115 188 549 minecraft:blackstone
setblock 116 185 512 minecraft:smooth_basalt
setblock 117 185 511 minecraft:smooth_basalt
setblock 117 185 512 minecraft:blackstone
setblock 117 185 550 minecraft:blackstone
setblock 117 185 551 minecraft:smooth_basalt
fill 118 185 511 118 188 511 minecraft:blackstone
setblock 118 185 549 minecraft:blackstone
setblock 118 185 550 minecraft:smooth_basalt
fill 118 185 551 118 188 551 minecraft:blackstone
fill 119 185 550 122 185 550 minecraft:blackstone
setblock 121 185 551 minecraft:blackstone
setblock 122 185 551 minecraft:smooth_basalt
setblock 123 185 550 minecraft:smooth_basalt
fill 123 185 551 123 188 551 minecraft:blackstone
fill 124 185 550 127 185 550 minecraft:blackstone
fill 125 185 549 128 185 549 minecraft:blackstone
setblock 126 185 551 minecraft:blackstone
setblock 127 185 511 minecraft:smooth_basalt
fill 127 185 548 129 185 548 minecraft:blackstone
setblock 127 185 551 minecraft:smooth_basalt
fill 128 185 511 131 185 511 minecraft:blackstone
setblock 128 185 550 minecraft:smooth_basalt
fill 128 185 551 128 188 551 minecraft:blackstone
setblock 129 185 549 minecraft:smooth_basalt
fill 129 185 550 129 188 550 minecraft:blackstone
setblock 130 185 548 minecraft:smooth_basalt
fill 130 185 549 130 188 549 minecraft:blackstone
setblock 131 185 543 minecraft:blackstone
setblock 131 185 547 minecraft:smooth_basalt
fill 131 185 548 131 188 548 minecraft:blackstone
setblock 132 185 511 minecraft:smooth_basalt
setblock 132 185 540 minecraft:blackstone
setblock 132 185 541 minecraft:smooth_basalt
fill 132 185 542 132 187 542 minecraft:blackstone
setblock 132 185 545 minecraft:blackstone
setblock 132 185 546 minecraft:smooth_basalt
fill 132 185 547 132 188 547 minecraft:blackstone
setblock 132 185 551 minecraft:smooth_basalt
fill 133 185 511 133 188 511 minecraft:blackstone
fill 133 185 521 133 185 524 minecraft:blackstone
setblock 133 185 525 minecraft:smooth_basalt
fill 133 185 526 133 188 526 minecraft:blackstone
setblock 133 185 530 minecraft:smooth_basalt
fill 133 185 531 133 188 531 minecraft:blackstone
fill 133 185 536 133 186 536 minecraft:blackstone
setblock 133 185 540 minecraft:smooth_basalt
fill 133 185 541 133 188 541 minecraft:blackstone
setblock 133 185 545 minecraft:smooth_basalt
fill 133 185 546 133 188 546 minecraft:blackstone
setblock 133 185 550 minecraft:smooth_basalt
fill 133 185 551 133 188 551 minecraft:blackstone
setblock 134 185 519 minecraft:smooth_basalt
fill 134 185 520 134 185 523 minecraft:blackstone
setblock 134 185 524 minecraft:smooth_basalt
fill 134 185 525 134 188 525 minecraft:blackstone
setblock 134 185 528 minecraft:blackstone
setblock 134 185 529 minecraft:smooth_basalt
fill 134 185 530 134 188 530 minecraft:blackstone
setblock 134 185 534 minecraft:smooth_basalt
fill 134 185 535 134 188 535 minecraft:blackstone
setblock 134 185 539 minecraft:smooth_basalt
fill 134 185 540 134 188 540 minecraft:blackstone
setblock 134 185 544 minecraft:smooth_basalt
fill 134 185 545 134 188 545 minecraft:blackstone
setblock 134 185 549 minecraft:smooth_basalt
fill 134 185 550 134 188 550 minecraft:blackstone
setblock 135 185 518 minecraft:smooth_basalt
fill 135 185 519 135 187 519 minecraft:blackstone
setblock 135 185 523 minecraft:smooth_basalt
fill 135 185 524 135 188 524 minecraft:blackstone
setblock 135 185 528 minecraft:smooth_basalt
fill 135 185 529 135 188 529 minecraft:blackstone
setblock 135 185 533 minecraft:smooth_basalt
fill 135 185 534 135 188 534 minecraft:blackstone
setblock 135 185 538 minecraft:smooth_basalt
fill 135 185 539 135 188 539 minecraft:blackstone
setblock 135 185 543 minecraft:smooth_basalt
fill 135 185 544 135 188 544 minecraft:blackstone
setblock 135 185 548 minecraft:smooth_basalt
fill 135 185 549 135 188 549 minecraft:blackstone
setblock 95 186 511 minecraft:blackstone
setblock 95 186 517 minecraft:smooth_basalt
schedule function dropper:buildpart/122_7 1t
