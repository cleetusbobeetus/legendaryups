setblock 180 245 241 minecraft:blue_wool
setblock 180 245 242 minecraft:lime_wool
setblock 180 245 245 minecraft:cyan_wool
setblock 180 245 247 minecraft:light_blue_wool
setblock 180 245 249 minecraft:red_wool
setblock 180 245 250 minecraft:light_blue_wool
setblock 180 245 251 minecraft:cyan_wool
setblock 180 245 252 minecraft:blue_wool
setblock 180 245 256 minecraft:red_wool
setblock 180 245 259 minecraft:blue_wool
setblock 180 245 260 minecraft:cyan_wool
setblock 180 245 261 minecraft:lime_wool
setblock 180 245 263 minecraft:blue_wool
fill 142 246 229 142 247 269 minecraft:gray_concrete
fill 143 246 229 182 247 229 minecraft:gray_concrete
fill 143 246 230 143 246 236 minecraft:blue_concrete
setblock 143 246 237 minecraft:light_gray_concrete
fill 143 246 238 143 246 242 minecraft:blue_concrete
fill 143 246 243 143 246 245 minecraft:orange_concrete
setblock 143 246 246 minecraft:light_gray_concrete
fill 143 246 247 143 246 254 minecraft:blue_concrete
setblock 143 246 255 minecraft:light_gray_concrete
fill 143 246 256 143 246 263 minecraft:blue_concrete
setblock 143 246 264 minecraft:light_gray_concrete
fill 143 246 265 143 246 266 minecraft:orange_concrete
fill 143 246 267 143 246 268 minecraft:blue_concrete
fill 143 246 269 182 247 269 minecraft:gray_concrete
fill 144 246 230 149 246 230 minecraft:blue_concrete
setblock 144 246 231 minecraft:pink_terracotta
setblock 144 246 234 minecraft:pink_terracotta
setblock 144 246 235 minecraft:orange_terracotta
setblock 144 246 236 minecraft:pink_terracotta
setblock 144 246 238 minecraft:light[level=15]
fill 144 246 239 144 246 240 minecraft:pink_terracotta
setblock 144 246 242 minecraft:white_terracotta
setblock 144 246 243 minecraft:orange_terracotta
setblock 144 246 244 minecraft:white_terracotta
setblock 144 246 245 minecraft:orange_terracotta
setblock 144 246 248 minecraft:orange_terracotta
setblock 144 246 251 minecraft:brown_terracotta
setblock 144 246 252 minecraft:yellow_terracotta
setblock 144 246 253 minecraft:pink_terracotta
setblock 144 246 254 minecraft:white_terracotta
setblock 144 246 256 minecraft:yellow_terracotta
setblock 144 246 257 minecraft:brown_terracotta
setblock 144 246 259 minecraft:light[level=15]
setblock 144 246 262 minecraft:orange_terracotta
setblock 144 246 266 minecraft:brown_terracotta
fill 144 246 268 149 246 268 minecraft:blue_concrete
setblock 146 246 231 minecraft:orange_terracotta
setblock 148 246 231 minecraft:orange_terracotta
setblock 149 246 231 minecraft:yellow_terracotta
setblock 149 246 267 minecraft:brown_terracotta
setblock 150 246 230 minecraft:light_gray_concrete
setblock 150 246 268 minecraft:light_gray_concrete
fill 151 246 230 155 246 230 minecraft:blue_concrete
setblock 151 246 231 minecraft:light[level=15]
setblock 151 246 238 minecraft:light[level=15]
setblock 151 246 245 minecraft:light[level=15]
setblock 151 246 252 minecraft:light[level=15]
setblock 151 246 259 minecraft:light[level=15]
setblock 151 246 266 minecraft:light[level=15]
setblock 151 246 267 minecraft:white_terracotta
fill 151 246 268 155 246 268 minecraft:blue_concrete
setblock 154 246 231 minecraft:yellow_terracotta
fill 154 246 246 154 260 248 minecraft:orange_concrete
setblock 154 246 249 minecraft:black_concrete
fill 154 246 250 154 260 252 minecraft:orange_concrete
setblock 154 246 267 minecraft:yellow_terracotta
setblock 155 246 231 minecraft:orange_terracotta
fill 155 246 244 155 263 245 minecraft:orange_concrete
setblock 155 246 246 minecraft:orange_terracotta
fill 155 246 249 156 260 249 minecraft:orange_concrete
fill 155 246 252 155 260 254 minecraft:orange_concrete
setblock 155 246 267 minecraft:pink_terracotta
fill 156 246 230 158 246 230 minecraft:orange_concrete
setblock 156 246 231 minecraft:yellow_terracotta
fill 156 246 243 156 246 244 minecraft:black_concrete
fill 156 246 245 157 264 245 minecraft:orange_concrete
fill 156 246 253 157 260 253 minecraft:orange_concrete
fill 156 246 254 156 246 255 minecraft:black_concrete
setblock 156 246 267 minecraft:yellow_terracotta
fill 156 246 268 158 246 268 minecraft:orange_concrete
setblock 157 246 231 minecraft:brown_concrete
fill 157 246 242 157 264 243 minecraft:orange_concrete
fill 157 246 255 157 264 256 minecraft:orange_concrete
setblock 158 246 231 minecraft:brown_terracotta
setblock 158 246 238 minecraft:light[level=15]
fill 158 246 242 160 263 242 minecraft:orange_concrete
fill 158 246 256 159 264 256 minecraft:orange_concrete
setblock 158 246 259 minecraft:light[level=15]
setblock 158 246 266 minecraft:light[level=15]
setblock 159 246 230 minecraft:light_gray_concrete
fill 159 246 241 161 264 241 minecraft:orange_concrete
fill 159 246 246 159 248 248 minecraft:black_concrete
fill 159 246 257 161 263 257 minecraft:orange_concrete
setblock 159 246 268 minecraft:light_gray_concrete
fill 160 246 230 167 246 230 minecraft:blue_concrete
fill 160 246 245 160 248 246 minecraft:black_concrete
fill 160 246 248 160 248 249 minecraft:black_concrete
fill 160 246 268 167 246 268 minecraft:blue_concrete
setblock 161 246 231 minecraft:brown_concrete
fill 161 246 244 161 248 245 minecraft:black_concrete
fill 161 246 249 161 248 250 minecraft:black_concrete
fill 161 246 255 162 264 255 minecraft:orange_concrete
setblock 162 246 241 minecraft:black_concrete
fill 162 246 242 162 264 243 minecraft:orange_concrete
fill 162 246 244 163 248 244 minecraft:black_concrete
fill 162 246 250 163 248 250 minecraft:black_concrete
fill 162 246 256 162 264 256 minecraft:orange_concrete
setblock 162 246 257 minecraft:black_concrete
fill 163 246 241 165 263 241 minecraft:orange_concrete
fill 163 246 245 164 248 245 minecraft:black_concrete
fill 163 246 249 164 248 249 minecraft:black_concrete
fill 163 246 257 165 264 257 minecraft:orange_concrete
setblock 164 246 231 minecraft:yellow_terracotta
fill 164 246 246 165 248 246 minecraft:black_concrete
fill 164 246 248 165 248 248 minecraft:black_concrete
setblock 165 246 231 minecraft:light[level=15]
setblock 165 246 238 minecraft:light[level=15]
fill 165 246 242 167 264 242 minecraft:orange_concrete
fill 165 246 247 165 248 247 minecraft:black_concrete
fill 165 246 256 167 263 256 minecraft:orange_concrete
setblock 165 246 259 minecraft:light[level=15]
setblock 165 246 266 minecraft:light[level=15]
fill 166 246 243 167 264 243 minecraft:orange_concrete
fill 166 246 254 166 260 254 minecraft:orange_concrete
setblock 166 246 267 minecraft:pink_terracotta
setblock 167 246 231 minecraft:white_terracotta
fill 167 246 245 169 264 245 minecraft:orange_concrete
fill 167 246 253 169 260 253 minecraft:orange_concrete
fill 167 246 255 167 260 255 minecraft:orange_concrete
setblock 168 246 230 minecraft:light_gray_concrete
fill 168 246 243 168 246 244 minecraft:black_concrete
fill 168 246 247 168 265 247 minecraft:orange_concrete
fill 168 246 249 169 264 249 minecraft:orange_concrete
fill 168 246 254 168 246 255 minecraft:black_concrete
setblock 168 246 268 minecraft:light_gray_concrete
fill 169 246 230 176 246 230 minecraft:blue_concrete
fill 169 246 244 169 264 244 minecraft:orange_concrete
fill 169 246 246 170 264 246 minecraft:orange_concrete
setblock 169 246 252 minecraft:orange_terracotta
fill 169 246 254 169 264 254 minecraft:orange_concrete
fill 169 246 268 176 246 268 minecraft:blue_concrete
fill 170 246 247 170 264 248 minecraft:orange_concrete
setblock 170 246 249 minecraft:black_concrete
fill 170 246 250 170 264 252 minecraft:orange_concrete
fill 171 246 231 172 246 231 minecraft:orange_terracotta
setblock 172 246 238 minecraft:light[level=15]
setblock 172 246 245 minecraft:light[level=15]
setblock 172 246 252 minecraft:light[level=15]
setblock 172 246 259 minecraft:light[level=15]
setblock 172 246 266 minecraft:light[level=15]
setblock 173 246 231 minecraft:brown_terracotta
setblock 173 246 267 minecraft:white_terracotta
fill 174 246 231 175 246 231 minecraft:orange_terracotta
setblock 175 246 267 minecraft:yellow_terracotta
setblock 176 246 267 minecraft:brown_concrete
setblock 177 246 230 minecraft:light_gray_concrete
setblock 177 246 268 minecraft:light_gray_concrete
fill 178 246 230 179 246 230 minecraft:orange_concrete
setblock 178 246 267 minecraft:orange_terracotta
fill 178 246 268 179 246 268 minecraft:orange_concrete
setblock 179 246 231 minecraft:brown_concrete
setblock 179 246 238 minecraft:light[level=15]
setblock 179 246 245 minecraft:light[level=15]
setblock 179 246 252 minecraft:light[level=15]
setblock 179 246 259 minecraft:light[level=15]
setblock 179 246 266 minecraft:light[level=15]
fill 180 246 230 181 246 230 minecraft:blue_concrete
setblock 180 246 231 minecraft:brown_terracotta
setblock 180 246 235 minecraft:brown_terracotta
setblock 180 246 238 minecraft:white_terracotta
setblock 180 246 239 minecraft:brown_terracotta
setblock 180 246 241 minecraft:yellow_terracotta
setblock 180 246 242 minecraft:brown_concrete
setblock 180 246 245 minecraft:pink_terracotta
setblock 180 246 247 minecraft:brown_terracotta
setblock 180 246 249 minecraft:brown_concrete
setblock 180 246 251 minecraft:brown_terracotta
setblock 180 246 256 minecraft:brown_terracotta
setblock 180 246 259 minecraft:pink_terracotta
setblock 180 246 260 minecraft:white_terracotta
setblock 180 246 261 minecraft:orange_terracotta
fill 180 246 268 181 246 268 minecraft:blue_concrete
fill 181 246 231 181 246 236 minecraft:blue_concrete
setblock 181 246 237 minecraft:light_gray_concrete
fill 181 246 238 181 246 242 minecraft:blue_concrete
fill 181 246 243 181 246 245 minecraft:orange_concrete
setblock 181 246 246 minecraft:light_gray_concrete
fill 181 246 247 181 246 254 minecraft:blue_concrete
setblock 181 246 255 minecraft:light_gray_concrete
fill 181 246 256 181 246 263 minecraft:blue_concrete
setblock 181 246 264 minecraft:light_gray_concrete
fill 181 246 265 181 246 266 minecraft:orange_concrete
setblock 181 246 267 minecraft:blue_concrete
fill 182 246 230 182 247 268 minecraft:gray_concrete
setblock 143 247 230 minecraft:yellow_wool
setblock 143 247 233 minecraft:magenta_wool
setblock 143 247 235 minecraft:light_blue_wool
setblock 143 247 236 minecraft:red_wool
setblock 143 247 239 minecraft:black_wool
setblock 143 247 241 minecraft:cyan_wool
setblock 143 247 243 minecraft:orange_wool
setblock 143 247 244 minecraft:lime_wool
fill 143 247 248 143 247 249 minecraft:red_wool
setblock 143 247 250 minecraft:lime_wool
setblock 143 247 253 minecraft:yellow_wool
setblock 143 247 256 minecraft:magenta_wool
setblock 143 247 258 minecraft:red_wool
setblock 143 247 260 minecraft:purple_wool
setblock 143 247 262 minecraft:red_wool
setblock 143 247 265 minecraft:yellow_wool
setblock 143 247 266 minecraft:magenta_wool
setblock 143 247 268 minecraft:orange_wool
setblock 144 247 230 minecraft:cyan_wool
setblock 145 247 230 minecraft:light_blue_wool
setblock 145 247 268 minecraft:magenta_wool
setblock 146 247 230 minecraft:white_wool
setblock 146 247 268 minecraft:blue_wool
setblock 148 247 230 minecraft:magenta_wool
setblock 148 247 268 minecraft:purple_wool
setblock 149 247 230 minecraft:purple_wool
setblock 149 247 268 minecraft:white_wool
setblock 151 247 230 minecraft:white_wool
setblock 151 247 268 minecraft:lime_wool
setblock 152 247 230 minecraft:black_wool
fill 152 247 268 153 247 268 minecraft:gray_wool
fill 153 247 246 153 261 248 minecraft:orange_concrete
setblock 153 247 249 minecraft:black_concrete
fill 153 247 250 153 260 252 minecraft:orange_concrete
setblock 154 247 230 minecraft:magenta_wool
fill 154 247 244 154 263 245 minecraft:orange_concrete
fill 154 247 249 154 260 249 minecraft:orange_concrete
fill 154 247 253 154 263 254 minecraft:orange_concrete
setblock 155 247 230 minecraft:yellow_wool
setblock 155 247 243 minecraft:black_concrete
fill 155 247 246 155 264 246 minecraft:orange_concrete
setblock 155 247 255 minecraft:black_concrete
setblock 155 247 268 minecraft:cyan_wool
setblock 156 247 230 minecraft:light_blue_wool
fill 156 247 242 156 263 244 minecraft:orange_concrete
fill 156 247 254 156 263 256 minecraft:orange_concrete
setblock 157 247 230 minecraft:magenta_wool
fill 157 247 241 158 263 241 minecraft:orange_concrete
fill 157 247 257 158 262 257 minecraft:orange_concrete
setblock 157 247 268 minecraft:black_wool
setblock 158 247 268 minecraft:magenta_wool
fill 159 247 240 161 263 240 minecraft:orange_concrete
fill 159 247 258 161 261 258 minecraft:orange_concrete
setblock 160 247 268 minecraft:orange_wool
setblock 161 247 268 minecraft:light_blue_wool
setblock 162 247 230 minecraft:cyan_wool
setblock 162 247 240 minecraft:black_concrete
fill 162 247 241 162 263 241 minecraft:orange_concrete
fill 162 247 257 162 263 257 minecraft:orange_concrete
setblock 162 247 258 minecraft:black_concrete
setblock 162 247 268 minecraft:orange_wool
fill 163 247 240 165 262 240 minecraft:orange_concrete
fill 163 247 258 164 262 258 minecraft:orange_concrete
setblock 163 247 268 minecraft:black_wool
setblock 164 247 230 minecraft:cyan_wool
setblock 165 247 258 minecraft:orange_terracotta
fill 166 247 241 167 263 241 minecraft:orange_concrete
fill 166 247 257 167 263 257 minecraft:orange_concrete
setblock 166 247 268 minecraft:magenta_wool
setblock 167 247 230 minecraft:cyan_wool
setblock 168 247 242 minecraft:orange_terracotta
fill 168 247 243 168 263 244 minecraft:orange_concrete
fill 168 247 254 168 260 256 minecraft:orange_concrete
setblock 169 247 230 minecraft:magenta_wool
setblock 169 247 243 minecraft:black_concrete
fill 169 247 252 169 260 252 minecraft:orange_concrete
setblock 169 247 255 minecraft:black_concrete
setblock 169 247 268 minecraft:black_wool
setblock 170 247 230 minecraft:white_wool
fill 170 247 244 170 263 245 minecraft:orange_concrete
fill 170 247 249 170 263 249 minecraft:orange_concrete
fill 170 247 253 170 263 254 minecraft:orange_concrete
setblock 170 247 268 minecraft:blue_wool
setblock 171 247 230 minecraft:magenta_wool
fill 171 247 246 171 263 247 minecraft:orange_concrete
setblock 171 247 248 minecraft:orange_terracotta
setblock 171 247 249 minecraft:black_concrete
fill 171 247 250 171 262 252 minecraft:orange_concrete
setblock 171 247 268 minecraft:yellow_wool
setblock 173 247 230 minecraft:orange_wool
fill 174 247 230 176 247 230 minecraft:black_wool
setblock 174 247 268 minecraft:orange_wool
setblock 175 247 268 minecraft:red_wool
setblock 176 247 268 minecraft:cyan_wool
setblock 178 247 230 minecraft:yellow_wool
setblock 178 247 268 minecraft:purple_wool
setblock 179 247 230 minecraft:magenta_wool
setblock 179 247 268 minecraft:cyan_wool
setblock 180 247 268 minecraft:white_wool
setblock 181 247 230 minecraft:purple_wool
setblock 181 247 234 minecraft:magenta_wool
setblock 181 247 241 minecraft:purple_wool
setblock 181 247 244 minecraft:magenta_wool
setblock 181 247 245 minecraft:orange_wool
setblock 181 247 249 minecraft:yellow_wool
setblock 181 247 251 minecraft:gray_wool
setblock 181 247 253 minecraft:magenta_wool
setblock 181 247 256 minecraft:blue_wool
setblock 181 247 257 minecraft:red_wool
setblock 181 247 258 minecraft:light_blue_wool
setblock 181 247 259 minecraft:red_wool
setblock 181 247 261 minecraft:light_blue_wool
setblock 181 247 262 minecraft:lime_wool
setblock 181 247 265 minecraft:white_wool
setblock 181 247 268 minecraft:magenta_wool
fill 142 248 229 142 248 269 minecraft:sea_lantern
fill 143 248 229 182 248 229 minecraft:sea_lantern
setblock 143 248 230 minecraft:brown_terracotta
setblock 143 248 233 minecraft:pink_terracotta
setblock 143 248 235 minecraft:white_terracotta
setblock 143 248 236 minecraft:yellow_terracotta
setblock 143 248 239 minecraft:pink_terracotta
setblock 143 248 244 minecraft:yellow_terracotta
setblock 143 248 248 minecraft:white_terracotta
setblock 143 248 249 minecraft:brown_concrete
setblock 143 248 250 minecraft:pink_terracotta
setblock 143 248 253 minecraft:brown_concrete
setblock 143 248 258 minecraft:pink_terracotta
setblock 143 248 260 minecraft:orange_terracotta
setblock 143 248 262 minecraft:white_terracotta
setblock 143 248 265 minecraft:orange_terracotta
setblock 143 248 266 minecraft:yellow_terracotta
setblock 143 248 268 minecraft:brown_concrete
fill 143 248 269 182 248 269 minecraft:sea_lantern
setblock 144 248 230 minecraft:yellow_terracotta
fill 145 248 230 146 248 230 minecraft:orange_terracotta
setblock 148 248 230 minecraft:white_terracotta
fill 148 248 268 149 248 268 minecraft:white_terracotta
setblock 149 248 230 minecraft:brown_concrete
setblock 151 248 230 minecraft:brown_concrete
fill 151 248 268 152 248 268 minecraft:pink_terracotta
fill 152 248 247 152 262 248 minecraft:orange_concrete
fill 152 248 249 152 249 249 minecraft:black_concrete
fill 152 248 250 152 262 251 minecraft:orange_concrete
fill 153 248 244 153 262 245 minecraft:orange_concrete
fill 153 248 249 153 260 249 minecraft:orange_concrete
fill 153 248 253 153 260 254 minecraft:orange_concrete
setblock 153 248 268 minecraft:yellow_terracotta
setblock 154 248 230 minecraft:brown_concrete
fill 154 248 243 155 262 243 minecraft:orange_concrete
fill 154 248 255 155 262 255 minecraft:orange_concrete
setblock 155 248 242 minecraft:black_concrete
setblock 155 248 256 minecraft:black_concrete
setblock 155 248 268 minecraft:yellow_terracotta
setblock 156 248 230 minecraft:yellow_terracotta
fill 156 248 241 156 261 241 minecraft:orange_concrete
fill 156 248 257 156 262 257 minecraft:orange_concrete
setblock 157 248 230 minecraft:brown_concrete
fill 157 248 240 158 260 240 minecraft:orange_concrete
fill 157 248 258 157 262 258 minecraft:orange_concrete
setblock 158 248 258 minecraft:orange_terracotta
setblock 158 248 268 minecraft:white_terracotta
fill 160 248 239 161 262 239 minecraft:orange_concrete
fill 160 248 259 161 260 259 minecraft:orange_concrete
setblock 161 248 268 minecraft:white_terracotta
setblock 162 248 230 minecraft:brown_concrete
fill 162 248 239 162 249 239 minecraft:black_concrete
fill 162 248 240 162 262 240 minecraft:orange_concrete
fill 162 248 258 162 262 258 minecraft:orange_concrete
fill 162 248 259 162 249 259 minecraft:black_concrete
setblock 162 248 268 minecraft:pink_terracotta
fill 163 248 239 164 262 239 minecraft:orange_concrete
fill 163 248 259 163 262 259 minecraft:orange_concrete
setblock 163 248 268 minecraft:brown_terracotta
setblock 164 248 230 minecraft:brown_terracotta
setblock 164 248 259 minecraft:orange_terracotta
fill 165 248 258 167 262 258 minecraft:orange_concrete
fill 166 248 240 167 262 240 minecraft:orange_concrete
setblock 166 248 268 minecraft:brown_concrete
setblock 167 248 230 minecraft:pink_terracotta
fill 168 248 241 168 262 242 minecraft:orange_concrete
fill 168 248 257 168 262 257 minecraft:orange_concrete
setblock 169 248 230 minecraft:white_terracotta
setblock 169 248 242 minecraft:black_concrete
fill 169 248 243 170 262 243 minecraft:orange_concrete
fill 169 248 255 170 262 255 minecraft:orange_concrete
setblock 169 248 256 minecraft:black_concrete
setblock 169 248 268 minecraft:pink_terracotta
setblock 170 248 230 minecraft:brown_concrete
setblock 171 248 230 minecraft:pink_terracotta
fill 171 248 244 171 262 245 minecraft:orange_concrete
fill 171 248 248 171 262 249 minecraft:orange_concrete
fill 171 248 253 171 248 254 minecraft:orange_concrete
setblock 171 248 268 minecraft:orange_terracotta
fill 172 248 247 172 260 248 minecraft:orange_concrete
fill 172 248 249 172 249 249 minecraft:black_concrete
fill 172 248 250 172 261 251 minecraft:orange_concrete
setblock 173 248 230 minecraft:white_terracotta
setblock 174 248 230 minecraft:yellow_terracotta
setblock 174 248 268 minecraft:white_terracotta
setblock 175 248 268 minecraft:orange_terracotta
setblock 176 248 230 minecraft:brown_terracotta
setblock 176 248 268 minecraft:white_terracotta
setblock 178 248 230 minecraft:yellow_terracotta
setblock 178 248 268 minecraft:yellow_terracotta
setblock 179 248 268 minecraft:orange_terracotta
setblock 180 248 268 minecraft:brown_terracotta
setblock 181 248 230 minecraft:pink_terracotta
setblock 181 248 244 minecraft:yellow_terracotta
setblock 181 248 245 minecraft:white_terracotta
setblock 181 248 249 minecraft:yellow_terracotta
setblock 181 248 251 minecraft:brown_terracotta
setblock 181 248 253 minecraft:yellow_terracotta
setblock 181 248 256 minecraft:yellow_terracotta
fill 181 248 257 181 248 258 minecraft:brown_concrete
setblock 181 248 259 minecraft:orange_terracotta
setblock 181 248 261 minecraft:orange_terracotta
setblock 181 248 262 minecraft:white_terracotta
setblock 181 248 268 minecraft:white_terracotta
fill 182 248 230 182 248 268 minecraft:sea_lantern
fill 142 249 229 142 254 235 minecraft:black_concrete
fill 142 249 236 142 252 236 minecraft:ochre_froglight
fill 142 249 237 142 252 237 minecraft:black_concrete
fill 142 249 238 142 253 238 minecraft:ochre_froglight
fill 142 249 239 142 254 239 minecraft:black_concrete
fill 142 249 240 142 249 242 minecraft:ochre_froglight
fill 142 249 243 142 250 249 minecraft:black_concrete
fill 142 249 250 142 253 250 minecraft:ochre_froglight
fill 142 249 251 142 249 252 minecraft:black_concrete
setblock 142 249 253 minecraft:ochre_froglight
fill 142 249 254 142 249 255 minecraft:black_concrete
fill 142 249 256 142 250 256 minecraft:ochre_froglight
fill 142 249 257 142 250 257 minecraft:black_concrete
fill 142 249 258 142 253 258 minecraft:ochre_froglight
fill 142 249 259 142 249 260 minecraft:black_concrete
fill 142 249 261 142 249 262 minecraft:ochre_froglight
fill 142 249 263 142 254 269 minecraft:black_concrete
fill 143 249 229 182 254 229 minecraft:black_concrete
fill 143 249 269 145 251 269 minecraft:black_concrete
fill 146 249 269 146 251 269 minecraft:ochre_froglight
fill 147 249 269 148 251 269 minecraft:black_concrete
fill 149 249 269 149 250 269 minecraft:ochre_froglight
fill 150 249 269 150 250 269 minecraft:black_concrete
fill 151 249 269 151 253 269 minecraft:ochre_froglight
fill 152 249 245 152 261 246 minecraft:orange_concrete
fill 152 249 252 152 260 253 minecraft:orange_concrete
fill 152 249 269 152 254 269 minecraft:black_concrete
setblock 153 249 243 minecraft:orange_concrete
fill 153 249 255 153 261 255 minecraft:orange_concrete
fill 153 249 269 153 252 269 minecraft:ochre_froglight
setblock 154 249 242 minecraft:black_concrete
setblock 154 249 256 minecraft:black_concrete
fill 154 249 269 154 250 269 minecraft:black_concrete
fill 155 249 241 155 261 242 minecraft:orange_concrete
fill 155 249 256 155 261 257 minecraft:orange_concrete
fill 155 249 269 155 252 269 minecraft:ochre_froglight
fill 156 249 240 156 261 240 minecraft:orange_concrete
fill 156 249 258 156 261 258 minecraft:orange_concrete
fill 156 249 269 157 249 269 minecraft:black_concrete
setblock 158 249 239 minecraft:orange_terracotta
fill 158 249 258 158 261 259 minecraft:orange_concrete
fill 158 249 269 159 249 269 minecraft:ochre_froglight
fill 159 249 239 159 261 239 minecraft:orange_concrete
fill 159 249 246 159 249 248 minecraft:glowstone
fill 159 249 259 159 261 259 minecraft:orange_concrete
fill 160 249 245 160 249 246 minecraft:glowstone
fill 160 249 248 160 249 249 minecraft:glowstone
fill 160 249 269 160 254 269 minecraft:black_concrete
fill 161 249 244 161 249 245 minecraft:glowstone
fill 161 249 249 161 249 250 minecraft:glowstone
fill 161 249 269 161 252 269 minecraft:ochre_froglight
fill 162 249 244 163 249 244 minecraft:glowstone
fill 162 249 250 163 249 250 minecraft:glowstone
fill 162 249 269 162 252 269 minecraft:black_concrete
fill 163 249 245 164 249 245 minecraft:glowstone
fill 163 249 249 164 249 249 minecraft:glowstone
fill 163 249 269 163 253 269 minecraft:ochre_froglight
fill 164 249 246 165 249 246 minecraft:glowstone
fill 164 249 248 165 249 248 minecraft:glowstone
fill 164 249 259 166 261 259 minecraft:orange_concrete
fill 164 249 269 164 254 269 minecraft:black_concrete
fill 165 249 239 166 261 239 minecraft:orange_concrete
setblock 165 249 247 minecraft:glowstone
fill 165 249 269 167 249 269 minecraft:ochre_froglight
setblock 168 249 240 minecraft:orange_concrete
fill 168 249 258 168 261 258 minecraft:orange_concrete
fill 168 249 269 168 254 269 minecraft:black_concrete
fill 169 249 241 169 261 242 minecraft:orange_concrete
fill 169 249 256 169 261 257 minecraft:orange_concrete
fill 169 249 269 170 249 269 minecraft:ochre_froglight
setblock 170 249 242 minecraft:black_concrete
setblock 170 249 256 minecraft:black_concrete
setblock 171 249 243 minecraft:orange_terracotta
fill 171 249 253 172 261 253 minecraft:orange_concrete
setblock 171 249 254 minecraft:orange_terracotta
fill 171 249 255 171 261 255 minecraft:orange_concrete
fill 171 249 269 172 249 269 minecraft:black_concrete
setblock 172 249 245 minecraft:orange_terracotta
fill 172 249 246 172 261 246 minecraft:orange_concrete
fill 172 249 252 172 261 252 minecraft:orange_concrete
fill 173 249 269 175 249 269 minecraft:ochre_froglight
fill 176 249 269 176 254 269 minecraft:black_concrete
fill 177 249 269 179 249 269 minecraft:ochre_froglight
fill 180 249 269 182 254 269 minecraft:black_concrete
fill 182 249 230 182 254 241 minecraft:black_concrete
fill 182 249 242 182 249 244 minecraft:ochre_froglight
fill 182 249 245 182 254 245 minecraft:black_concrete
fill 182 249 246 182 249 248 minecraft:ochre_froglight
fill 182 249 249 182 249 250 minecraft:black_concrete
setblock 182 249 251 minecraft:ochre_froglight
fill 182 249 252 182 249 253 minecraft:black_concrete
fill 182 249 254 182 249 256 minecraft:ochre_froglight
fill 182 249 257 182 254 268 minecraft:black_concrete
fill 142 250 240 142 252 240 minecraft:black_concrete
fill 142 250 241 142 253 241 minecraft:ochre_froglight
fill 142 250 242 142 252 242 minecraft:black_concrete
fill 142 250 251 142 254 251 minecraft:black_concrete
fill 142 250 252 142 252 252 minecraft:ochre_froglight
fill 142 250 253 142 252 253 minecraft:black_concrete
fill 142 250 254 142 252 254 minecraft:ochre_froglight
fill 142 250 255 142 254 255 minecraft:black_concrete
fill 142 250 259 142 254 259 minecraft:black_concrete
fill 142 250 260 142 252 260 minecraft:ochre_froglight
fill 142 250 261 142 252 261 minecraft:black_concrete
fill 142 250 262 142 253 262 minecraft:ochre_froglight
fill 151 250 246 151 259 248 minecraft:orange_concrete
fill 151 250 249 151 251 249 minecraft:black_concrete
setblock 151 250 250 minecraft:orange_terracotta
fill 151 250 251 151 257 252 minecraft:orange_concrete
setblock 152 250 244 minecraft:orange_concrete
fill 152 250 249 152 260 249 minecraft:orange_concrete
fill 152 250 254 152 260 254 minecraft:orange_concrete
fill 153 250 242 154 260 242 minecraft:orange_concrete
setblock 153 250 243 minecraft:orange_terracotta
fill 153 250 256 154 257 256 minecraft:orange_concrete
fill 154 250 241 154 251 241 minecraft:black_concrete
fill 154 250 257 154 251 257 minecraft:black_concrete
fill 155 250 240 155 260 240 minecraft:orange_concrete
setblock 155 250 258 minecraft:orange_terracotta
fill 156 250 269 156 254 269 minecraft:black_concrete
fill 157 250 239 158 259 239 minecraft:orange_concrete
fill 157 250 259 157 259 259 minecraft:orange_concrete
fill 157 250 269 157 252 269 minecraft:ochre_froglight
fill 158 250 269 158 252 269 minecraft:black_concrete
fill 159 250 238 161 250 238 minecraft:orange_concrete
fill 159 250 246 159 252 248 minecraft:black_concrete
fill 159 250 260 161 250 260 minecraft:orange_concrete
fill 159 250 269 159 253 269 minecraft:ochre_froglight
fill 160 250 245 160 252 246 minecraft:black_concrete
fill 160 250 248 160 252 249 minecraft:black_concrete
fill 161 250 244 161 252 245 minecraft:black_concrete
fill 161 250 249 161 252 250 minecraft:black_concrete
fill 162 250 238 162 251 238 minecraft:black_concrete
fill 162 250 239 162 260 239 minecraft:orange_concrete
fill 162 250 244 163 252 244 minecraft:black_concrete
fill 162 250 250 163 252 250 minecraft:black_concrete
fill 162 250 259 162 260 259 minecraft:orange_concrete
fill 162 250 260 162 251 260 minecraft:black_concrete
fill 163 250 238 165 251 238 minecraft:orange_concrete
fill 163 250 245 164 252 245 minecraft:black_concrete
fill 163 250 249 164 252 249 minecraft:black_concrete
fill 163 250 260 165 251 260 minecraft:orange_concrete
fill 164 250 246 165 252 246 minecraft:black_concrete
fill 164 250 248 165 252 248 minecraft:black_concrete
fill 165 250 247 165 252 247 minecraft:black_concrete
fill 165 250 269 166 250 269 minecraft:black_concrete
fill 167 250 239 167 260 239 minecraft:orange_concrete
fill 167 250 259 167 260 259 minecraft:orange_concrete
fill 167 250 269 167 253 269 minecraft:ochre_froglight
setblock 168 250 240 minecraft:orange_terracotta
fill 169 250 240 169 260 240 minecraft:orange_concrete
fill 169 250 258 169 258 258 minecraft:orange_concrete
fill 169 250 269 169 251 269 minecraft:ochre_froglight
fill 170 250 241 170 251 241 minecraft:black_concrete
fill 170 250 242 171 260 242 minecraft:orange_concrete
fill 170 250 256 171 260 256 minecraft:orange_concrete
fill 170 250 257 170 251 257 minecraft:black_concrete
fill 170 250 269 170 252 269 minecraft:black_concrete
fill 171 250 243 171 259 243 minecraft:orange_concrete
fill 171 250 254 172 260 254 minecraft:orange_concrete
fill 171 250 269 171 252 269 minecraft:ochre_froglight
fill 172 250 244 172 259 245 minecraft:orange_concrete
fill 172 250 249 172 260 249 minecraft:orange_concrete
fill 172 250 269 174 250 269 minecraft:black_concrete
fill 173 250 246 173 259 248 minecraft:orange_concrete
fill 173 250 249 173 251 249 minecraft:black_concrete
setblock 173 250 250 minecraft:orange_terracotta
fill 173 250 251 173 257 252 minecraft:orange_concrete
fill 175 250 269 175 253 269 minecraft:ochre_froglight
fill 177 250 269 178 254 269 minecraft:black_concrete
fill 179 250 269 179 253 269 minecraft:ochre_froglight
fill 182 250 242 182 253 242 minecraft:ochre_froglight
fill 182 250 243 182 254 244 minecraft:black_concrete
fill 182 250 246 182 252 246 minecraft:black_concrete
fill 182 250 247 182 253 247 minecraft:ochre_froglight
fill 182 250 248 182 252 249 minecraft:black_concrete
fill 182 250 250 182 253 250 minecraft:ochre_froglight
fill 182 250 251 182 254 251 minecraft:black_concrete
fill 182 250 252 182 253 252 minecraft:ochre_froglight
fill 182 250 253 182 254 253 minecraft:black_concrete
fill 182 250 254 182 253 254 minecraft:ochre_froglight
fill 182 250 255 182 250 256 minecraft:black_concrete
fill 142 251 243 142 251 248 minecraft:black_concrete
setblock 142 251 249 minecraft:ochre_froglight
setblock 142 251 256 minecraft:black_concrete
setblock 142 251 257 minecraft:ochre_froglight
setblock 149 251 269 minecraft:black_concrete
setblock 150 251 269 minecraft:ochre_froglight
setblock 151 251 245 minecraft:orange_concrete
fill 151 251 250 151 260 250 minecraft:orange_concrete
setblock 151 251 253 minecraft:orange_terracotta
fill 152 251 243 153 254 243 minecraft:orange_concrete
setblock 152 251 244 minecraft:orange_terracotta
setblock 152 251 255 minecraft:orange_terracotta
setblock 154 251 269 minecraft:ochre_froglight
fill 155 251 258 155 260 258 minecraft:orange_concrete
fill 156 251 239 156 253 239 minecraft:orange_concrete
fill 156 251 259 156 254 259 minecraft:orange_concrete
fill 158 251 238 159 254 238 minecraft:orange_concrete
fill 158 251 260 159 254 260 minecraft:orange_concrete
setblock 160 251 238 minecraft:orange_terracotta
setblock 160 251 260 minecraft:orange_terracotta
fill 161 251 238 161 260 238 minecraft:orange_concrete
fill 161 251 260 161 260 260 minecraft:orange_concrete
fill 165 251 269 165 252 269 minecraft:black_concrete
fill 166 251 238 166 254 238 minecraft:orange_concrete
fill 166 251 260 166 254 260 minecraft:orange_concrete
setblock 166 251 269 minecraft:ochre_froglight
fill 168 251 239 168 254 240 minecraft:orange_concrete
fill 168 251 259 168 254 259 minecraft:orange_concrete
setblock 172 251 243 minecraft:orange_concrete
fill 172 251 255 172 254 255 minecraft:orange_concrete
fill 172 251 269 173 252 269 minecraft:black_concrete
setblock 173 251 245 minecraft:orange_concrete
fill 173 251 250 173 260 250 minecraft:orange_concrete
setblock 173 251 253 minecraft:orange_terracotta
setblock 174 251 269 minecraft:ochre_froglight
setblock 182 251 255 minecraft:ochre_froglight
fill 182 251 256 182 252 256 minecraft:black_concrete
fill 142 252 243 142 254 247 minecraft:black_concrete
setblock 142 252 248 minecraft:ochre_froglight
setblock 142 252 249 minecraft:black_concrete
setblock 142 252 256 minecraft:ochre_froglight
setblock 142 252 257 minecraft:black_concrete
fill 143 252 269 144 254 269 minecraft:black_concrete
setblock 144 252 231 minecraft:light[level=15]
setblock 144 252 238 minecraft:light[level=15]
setblock 144 252 245 minecraft:light[level=15]
setblock 144 252 252 minecraft:light[level=15]
setblock 144 252 259 minecraft:light[level=15]
setblock 144 252 266 minecraft:light[level=15]
fill 145 252 269 145 253 269 minecraft:ochre_froglight
fill 146 252 269 146 254 269 minecraft:black_concrete
fill 147 252 269 147 253 269 minecraft:ochre_froglight
fill 148 252 269 148 254 269 minecraft:black_concrete
setblock 149 252 269 minecraft:ochre_froglight
fill 150 252 248 150 254 248 minecraft:orange_concrete
fill 150 252 249 150 254 249 minecraft:black_concrete
fill 150 252 250 150 254 250 minecraft:orange_concrete
setblock 150 252 269 minecraft:black_concrete
setblock 151 252 231 minecraft:light[level=15]
setblock 151 252 238 minecraft:light[level=15]
fill 151 252 244 152 254 244 minecraft:orange_concrete
setblock 151 252 245 minecraft:orange_terracotta
fill 151 252 249 151 258 249 minecraft:orange_concrete
fill 151 252 253 151 254 254 minecraft:orange_concrete
setblock 151 252 259 minecraft:light[level=15]
setblock 151 252 266 minecraft:light[level=15]
fill 152 252 255 152 254 255 minecraft:orange_concrete
fill 153 252 241 153 254 241 minecraft:black_concrete
fill 153 252 257 153 254 257 minecraft:black_concrete
setblock 154 252 240 minecraft:orange_terracotta
fill 154 252 241 154 258 241 minecraft:orange_concrete
fill 154 252 257 154 254 258 minecraft:orange_concrete
setblock 154 252 269 minecraft:black_concrete
setblock 157 252 238 minecraft:orange_concrete
setblock 157 252 260 minecraft:orange_concrete
setblock 158 252 231 minecraft:light[level=15]
setblock 158 252 266 minecraft:light[level=15]
fill 160 252 238 160 260 238 minecraft:orange_concrete
fill 160 252 260 160 260 260 minecraft:orange_concrete
fill 161 252 237 161 254 237 minecraft:orange_concrete
fill 161 252 261 161 254 261 minecraft:orange_concrete
fill 162 252 237 162 254 237 minecraft:black_concrete
fill 162 252 238 163 258 238 minecraft:orange_concrete
fill 162 252 260 163 258 260 minecraft:orange_concrete
fill 162 252 261 162 254 261 minecraft:black_concrete
fill 163 252 237 163 254 237 minecraft:orange_concrete
setblock 163 252 261 minecraft:orange_concrete
setblock 164 252 238 minecraft:orange_terracotta
setblock 164 252 260 minecraft:orange_terracotta
setblock 165 252 231 minecraft:light[level=15]
fill 165 252 238 165 260 238 minecraft:orange_concrete
fill 165 252 260 165 260 260 minecraft:orange_concrete
setblock 165 252 266 minecraft:light[level=15]
setblock 166 252 269 minecraft:black_concrete
fill 167 252 238 167 254 238 minecraft:orange_concrete
fill 167 252 260 167 254 260 minecraft:orange_concrete
setblock 169 252 269 minecraft:black_concrete
fill 170 252 240 170 254 241 minecraft:orange_concrete
fill 170 252 257 170 254 258 minecraft:orange_concrete
fill 171 252 241 171 254 241 minecraft:black_concrete
fill 171 252 257 171 254 257 minecraft:black_concrete
setblock 172 252 231 minecraft:light[level=15]
setblock 172 252 238 minecraft:light[level=15]
setblock 172 252 243 minecraft:orange_terracotta
setblock 172 252 259 minecraft:light[level=15]
setblock 172 252 266 minecraft:light[level=15]
fill 173 252 244 173 254 244 minecraft:orange_concrete
setblock 173 252 245 minecraft:orange_terracotta
fill 173 252 249 173 258 249 minecraft:orange_concrete
fill 173 252 253 173 254 254 minecraft:orange_concrete
fill 174 252 248 174 254 248 minecraft:orange_concrete
fill 174 252 249 174 254 249 minecraft:black_concrete
setblock 174 252 250 minecraft:orange_concrete
setblock 174 252 269 minecraft:black_concrete
setblock 179 252 231 minecraft:light[level=15]
setblock 179 252 238 minecraft:light[level=15]
setblock 179 252 245 minecraft:light[level=15]
setblock 179 252 252 minecraft:light[level=15]
setblock 179 252 259 minecraft:light[level=15]
setblock 179 252 266 minecraft:light[level=15]
setblock 182 252 255 minecraft:black_concrete
fill 142 253 236 142 254 236 minecraft:black_concrete
setblock 142 253 237 minecraft:ochre_froglight
setblock 142 253 240 minecraft:ochre_froglight
setblock 142 253 242 minecraft:ochre_froglight
fill 142 253 248 142 254 248 minecraft:black_concrete
setblock 142 253 249 minecraft:ochre_froglight
fill 142 253 252 142 254 252 minecraft:black_concrete
setblock 142 253 253 minecraft:ochre_froglight
fill 142 253 254 142 254 254 minecraft:black_concrete
fill 142 253 256 142 254 256 minecraft:black_concrete
setblock 142 253 257 minecraft:ochre_froglight
fill 142 253 260 142 254 260 minecraft:black_concrete
setblock 142 253 261 minecraft:ochre_froglight
fill 149 253 269 149 254 269 minecraft:black_concrete
fill 150 253 247 150 254 247 minecraft:orange_concrete
fill 150 253 251 150 254 251 minecraft:orange_concrete
setblock 150 253 269 minecraft:ochre_froglight
fill 151 253 245 151 254 245 minecraft:orange_concrete
setblock 152 253 242 minecraft:orange_concrete
fill 152 253 256 152 254 256 minecraft:orange_concrete
fill 153 253 269 153 254 269 minecraft:black_concrete
fill 154 253 240 154 254 240 minecraft:orange_concrete
setblock 154 253 269 minecraft:ochre_froglight
fill 155 253 239 155 254 239 minecraft:orange_concrete
setblock 155 253 259 minecraft:orange_concrete
fill 155 253 269 155 254 269 minecraft:black_concrete
setblock 157 253 238 minecraft:orange_terracotta
setblock 157 253 260 minecraft:orange_terracotta
fill 157 253 269 157 254 269 minecraft:black_concrete
setblock 158 253 269 minecraft:ochre_froglight
fill 159 253 246 159 253 248 minecraft:glowstone
fill 160 253 237 160 254 237 minecraft:orange_concrete
fill 160 253 245 160 253 246 minecraft:glowstone
fill 160 253 248 160 253 249 minecraft:glowstone
fill 160 253 261 160 254 261 minecraft:orange_concrete
fill 161 253 244 161 253 245 minecraft:glowstone
fill 161 253 249 161 253 250 minecraft:glowstone
fill 161 253 269 161 254 269 minecraft:black_concrete
fill 162 253 244 163 253 244 minecraft:glowstone
fill 162 253 250 163 253 250 minecraft:glowstone
setblock 162 253 269 minecraft:ochre_froglight
fill 163 253 245 164 253 245 minecraft:glowstone
fill 163 253 249 164 253 249 minecraft:glowstone
setblock 163 253 261 minecraft:orange_terracotta
fill 164 253 237 164 254 238 minecraft:orange_concrete
fill 164 253 246 165 253 246 minecraft:glowstone
fill 164 253 248 165 253 248 minecraft:glowstone
fill 164 253 260 164 254 261 minecraft:orange_concrete
setblock 165 253 247 minecraft:glowstone
fill 165 253 269 166 253 269 minecraft:ochre_froglight
fill 169 253 239 169 254 239 minecraft:orange_concrete
fill 169 253 259 169 254 259 minecraft:orange_concrete
fill 169 253 269 170 253 269 minecraft:ochre_froglight
fill 171 253 269 172 254 269 minecraft:black_concrete
fill 172 253 242 172 254 243 minecraft:orange_concrete
fill 172 253 256 172 254 256 minecraft:orange_concrete
fill 173 253 245 173 254 245 minecraft:orange_concrete
fill 173 253 269 174 253 269 minecraft:ochre_froglight
fill 174 253 247 174 254 247 minecraft:orange_concrete
setblock 174 253 250 minecraft:orange_terracotta
fill 174 253 251 174 254 251 minecraft:orange_concrete
setblock 182 253 246 minecraft:ochre_froglight
setblock 182 253 248 minecraft:ochre_froglight
fill 182 253 249 182 254 249 minecraft:black_concrete
fill 182 253 255 182 253 256 minecraft:ochre_froglight
fill 142 254 237 154 254 238 minecraft:black_concrete
fill 142 254 240 150 254 242 minecraft:black_concrete
fill 142 254 249 148 254 250 minecraft:black_concrete
fill 142 254 253 149 254 253 minecraft:black_concrete
fill 142 254 257 151 254 258 minecraft:black_concrete
fill 142 254 261 155 254 262 minecraft:black_concrete
fill 143 254 230 158 254 236 minecraft:black_concrete
fill 143 254 239 152 254 239 minecraft:black_concrete
fill 143 254 243 148 254 248 minecraft:black_concrete
fill 143 254 251 148 254 252 minecraft:black_concrete
fill 143 254 254 149 254 256 minecraft:black_concrete
fill 143 254 259 152 254 260 minecraft:black_concrete
fill 143 254 263 181 254 268 minecraft:black_concrete
setblock 145 254 269 minecraft:black_concrete
setblock 147 254 269 minecraft:black_concrete
fill 149 254 243 149 254 245 minecraft:black_concrete
setblock 150 254 246 minecraft:orange_concrete
setblock 150 254 252 minecraft:orange_concrete
setblock 150 254 256 minecraft:black_concrete
fill 150 254 269 151 254 269 minecraft:black_concrete
fill 151 254 240 151 254 241 minecraft:black_concrete
setblock 152 254 242 minecraft:orange_terracotta
fill 153 254 260 154 254 260 minecraft:black_concrete
setblock 154 254 269 minecraft:black_concrete
setblock 155 254 237 minecraft:black_concrete
setblock 155 254 259 minecraft:orange_terracotta
setblock 156 254 239 minecraft:orange_terracotta
fill 156 254 262 158 254 262 minecraft:black_concrete
setblock 157 254 238 minecraft:orange_concrete
setblock 157 254 260 minecraft:orange_concrete
fill 158 254 269 159 254 269 minecraft:black_concrete
fill 159 254 230 181 254 235 minecraft:black_concrete
setblock 159 254 237 minecraft:orange_concrete
fill 159 254 246 159 256 248 minecraft:black_concrete
setblock 159 254 261 minecraft:orange_concrete
fill 160 254 245 160 256 246 minecraft:black_concrete
fill 160 254 248 160 256 249 minecraft:black_concrete
fill 161 254 244 161 256 245 minecraft:black_concrete
fill 161 254 249 161 256 250 minecraft:black_concrete
fill 162 254 244 163 256 244 minecraft:black_concrete
fill 162 254 250 163 256 250 minecraft:black_concrete
fill 162 254 269 163 254 269 minecraft:black_concrete
fill 163 254 245 164 256 245 minecraft:black_concrete
fill 163 254 249 164 256 249 minecraft:black_concrete
setblock 163 254 261 minecraft:orange_concrete
fill 164 254 246 165 256 246 minecraft:black_concrete
fill 164 254 248 165 256 248 minecraft:black_concrete
setblock 165 254 237 minecraft:orange_concrete
fill 165 254 247 165 256 247 minecraft:black_concrete
setblock 165 254 261 minecraft:orange_concrete
fill 165 254 269 167 254 269 minecraft:black_concrete
fill 166 254 236 181 254 236 minecraft:black_concrete
fill 166 254 262 181 254 262 minecraft:black_concrete
fill 169 254 237 181 254 237 minecraft:black_concrete
fill 169 254 261 181 254 261 minecraft:black_concrete
fill 169 254 269 170 254 269 minecraft:black_concrete
fill 170 254 238 181 254 238 minecraft:black_concrete
fill 170 254 260 181 254 260 minecraft:black_concrete
fill 172 254 239 181 254 239 minecraft:black_concrete
fill 172 254 259 181 254 259 minecraft:black_concrete
fill 173 254 240 181 254 241 minecraft:black_concrete
fill 173 254 257 181 254 258 minecraft:black_concrete
fill 173 254 269 175 254 269 minecraft:black_concrete
fill 174 254 242 182 254 242 minecraft:black_concrete
setblock 174 254 246 minecraft:orange_concrete
setblock 174 254 250 minecraft:orange_concrete
setblock 174 254 252 minecraft:orange_concrete
fill 174 254 256 182 254 256 minecraft:black_concrete
fill 175 254 243 181 254 245 minecraft:black_concrete
fill 175 254 253 181 254 255 minecraft:black_concrete
fill 176 254 246 181 254 252 minecraft:black_concrete
setblock 179 254 269 minecraft:black_concrete
fill 182 254 246 182 254 248 minecraft:black_concrete
setblock 182 254 250 minecraft:black_concrete
setblock 182 254 252 minecraft:black_concrete
fill 182 254 254 182 254 255 minecraft:black_concrete
fill 142 255 229 143 255 269 minecraft:polished_blackstone
fill 144 255 229 144 255 244 minecraft:polished_blackstone
fill 144 255 245 144 255 253 minecraft:blue_concrete
fill 144 255 254 144 255 269 minecraft:polished_blackstone
fill 145 255 229 145 255 241 minecraft:polished_blackstone
fill 145 255 242 145 255 245 minecraft:blue_concrete
fill 145 255 246 145 255 247 minecraft:polished_blackstone
fill 145 255 248 146 255 250 minecraft:orange_concrete
fill 145 255 251 145 255 252 minecraft:polished_blackstone
fill 145 255 253 145 255 256 minecraft:blue_concrete
fill 145 255 257 145 255 269 minecraft:polished_blackstone
fill 146 255 229 146 255 239 minecraft:polished_blackstone
fill 146 255 240 146 255 242 minecraft:blue_concrete
fill 146 255 243 146 255 247 minecraft:orange_concrete
fill 146 255 251 146 255 255 minecraft:orange_concrete
fill 146 255 256 146 255 258 minecraft:blue_concrete
fill 146 255 259 146 255 269 minecraft:polished_blackstone
fill 147 255 229 147 255 238 minecraft:polished_blackstone
fill 147 255 239 147 255 240 minecraft:blue_concrete
fill 147 255 241 147 255 243 minecraft:orange_concrete
fill 147 255 244 148 255 254 minecraft:polished_blackstone
fill 147 255 255 147 255 257 minecraft:orange_concrete
fill 147 255 258 147 255 259 minecraft:blue_concrete
fill 147 255 260 147 255 269 minecraft:polished_blackstone
fill 148 255 229 148 255 236 minecraft:polished_blackstone
fill 148 255 237 148 255 238 minecraft:blue_concrete
setblock 148 255 239 minecraft:polished_blackstone
fill 148 255 240 148 255 241 minecraft:orange_concrete
fill 148 255 242 149 255 243 minecraft:polished_blackstone
fill 148 255 255 149 255 256 minecraft:polished_blackstone
fill 148 255 257 148 255 258 minecraft:orange_concrete
setblock 148 255 259 minecraft:polished_blackstone
fill 148 255 260 148 255 261 minecraft:blue_concrete
fill 148 255 262 148 255 269 minecraft:polished_blackstone
fill 149 255 229 149 255 235 minecraft:polished_blackstone
fill 149 255 236 149 255 237 minecraft:blue_concrete
fill 149 255 238 149 255 239 minecraft:orange_concrete
fill 149 255 240 151 255 241 minecraft:polished_blackstone
fill 149 255 244 149 255 245 minecraft:polished_blackstone
fill 149 255 246 150 255 252 minecraft:ochre_froglight
fill 149 255 253 149 255 254 minecraft:polished_blackstone
fill 149 255 257 151 255 258 minecraft:polished_blackstone
fill 149 255 259 149 255 260 minecraft:orange_concrete
fill 149 255 261 149 255 262 minecraft:blue_concrete
fill 149 255 263 149 255 269 minecraft:polished_blackstone
fill 150 255 229 151 255 234 minecraft:polished_blackstone
fill 150 255 235 150 255 236 minecraft:blue_concrete
fill 150 255 237 150 255 238 minecraft:orange_concrete
fill 150 255 239 152 255 239 minecraft:polished_blackstone
setblock 150 255 242 minecraft:polished_blackstone
fill 150 255 243 151 255 245 minecraft:ochre_froglight
fill 150 255 253 151 255 255 minecraft:ochre_froglight
setblock 150 255 256 minecraft:polished_blackstone
fill 150 255 259 152 255 259 minecraft:polished_blackstone
fill 150 255 260 150 255 261 minecraft:orange_concrete
fill 150 255 262 150 255 263 minecraft:blue_concrete
fill 150 255 264 151 255 269 minecraft:polished_blackstone
setblock 151 255 235 minecraft:blue_concrete
fill 151 255 236 151 255 237 minecraft:orange_concrete
fill 151 255 238 154 255 238 minecraft:polished_blackstone
fill 151 255 242 152 255 242 minecraft:ochre_froglight
fill 151 255 256 152 255 256 minecraft:ochre_froglight
fill 151 255 260 154 255 260 minecraft:polished_blackstone
fill 151 255 261 151 255 262 minecraft:orange_concrete
setblock 151 255 263 minecraft:blue_concrete
fill 152 255 229 152 255 233 minecraft:polished_blackstone
fill 152 255 234 153 255 234 minecraft:blue_concrete
setblock 152 255 235 minecraft:polished_blackstone
setblock 152 255 236 minecraft:orange_concrete
fill 152 255 237 155 255 237 minecraft:polished_blackstone
fill 152 255 240 153 255 241 minecraft:ochre_froglight
setblock 152 255 243 minecraft:ochre_froglight
fill 152 255 244 152 260 244 minecraft:orange_concrete
setblock 152 255 255 minecraft:ochre_froglight
fill 152 255 257 153 255 258 minecraft:ochre_froglight
fill 152 255 261 155 255 261 minecraft:polished_blackstone
setblock 152 255 262 minecraft:orange_concrete
setblock 152 255 263 minecraft:polished_blackstone
fill 152 255 264 153 255 264 minecraft:blue_concrete
fill 152 255 265 152 255 269 minecraft:polished_blackstone
fill 153 255 229 154 255 232 minecraft:polished_blackstone
fill 153 255 233 155 255 233 minecraft:blue_concrete
fill 153 255 235 154 255 235 minecraft:orange_concrete
fill 153 255 236 158 255 236 minecraft:polished_blackstone
fill 153 255 239 156 255 239 minecraft:ochre_froglight
fill 153 255 243 153 260 243 minecraft:orange_concrete
fill 153 255 259 156 255 259 minecraft:ochre_froglight
fill 153 255 262 158 255 262 minecraft:polished_blackstone
fill 153 255 263 154 255 263 minecraft:orange_concrete
fill 153 255 265 155 255 265 minecraft:blue_concrete
fill 153 255 266 154 255 269 minecraft:polished_blackstone
fill 154 255 234 156 255 234 minecraft:orange_concrete
setblock 154 255 240 minecraft:ochre_froglight
fill 154 255 257 154 258 257 minecraft:orange_concrete
setblock 154 255 258 minecraft:ochre_froglight
fill 154 255 264 156 255 264 minecraft:orange_concrete
fill 155 255 229 157 255 231 minecraft:polished_blackstone
fill 155 255 232 158 255 232 minecraft:blue_concrete
fill 155 255 235 169 255 235 minecraft:polished_blackstone
fill 155 255 238 158 255 238 minecraft:ochre_froglight
fill 155 255 260 158 255 260 minecraft:ochre_froglight
fill 155 255 263 169 255 263 minecraft:polished_blackstone
fill 155 255 266 158 255 266 minecraft:blue_concrete
fill 155 255 267 157 255 269 minecraft:polished_blackstone
fill 156 255 233 168 255 233 minecraft:orange_concrete
fill 156 255 237 168 255 237 minecraft:ochre_froglight
fill 156 255 261 168 255 261 minecraft:ochre_froglight
fill 156 255 265 168 255 265 minecraft:orange_concrete
fill 157 255 234 167 255 234 minecraft:polished_blackstone
fill 157 255 264 167 255 264 minecraft:polished_blackstone
fill 158 255 229 182 255 230 minecraft:polished_blackstone
fill 158 255 231 166 255 231 minecraft:blue_concrete
fill 158 255 267 166 255 267 minecraft:blue_concrete
fill 158 255 268 182 255 269 minecraft:polished_blackstone
fill 159 255 232 160 255 232 minecraft:polished_blackstone
fill 159 255 236 165 255 236 minecraft:ochre_froglight
fill 159 255 238 159 258 238 minecraft:orange_concrete
fill 159 255 260 159 258 260 minecraft:orange_concrete
fill 159 255 262 165 255 262 minecraft:ochre_froglight
fill 159 255 266 160 255 266 minecraft:polished_blackstone
fill 161 255 232 163 255 232 minecraft:orange_concrete
fill 161 255 266 163 255 266 minecraft:orange_concrete
fill 164 255 232 165 255 232 minecraft:polished_blackstone
fill 164 255 238 164 260 238 minecraft:orange_concrete
fill 164 255 260 164 260 260 minecraft:orange_concrete
fill 164 255 266 165 255 266 minecraft:polished_blackstone
fill 166 255 232 169 255 232 minecraft:blue_concrete
fill 166 255 236 171 255 236 minecraft:polished_blackstone
fill 166 255 238 169 255 238 minecraft:ochre_froglight
fill 166 255 260 169 255 260 minecraft:ochre_froglight
fill 166 255 262 171 255 262 minecraft:polished_blackstone
fill 166 255 266 169 255 266 minecraft:blue_concrete
fill 167 255 231 182 255 231 minecraft:polished_blackstone
fill 167 255 267 182 255 267 minecraft:polished_blackstone
fill 168 255 234 170 255 234 minecraft:orange_concrete
fill 168 255 239 171 255 239 minecraft:ochre_froglight
fill 168 255 240 168 260 240 minecraft:orange_concrete
fill 168 255 259 171 255 259 minecraft:ochre_froglight
fill 168 255 264 170 255 264 minecraft:orange_concrete
fill 169 255 233 171 255 233 minecraft:blue_concrete
fill 169 255 237 172 255 237 minecraft:polished_blackstone
fill 169 255 261 172 255 261 minecraft:polished_blackstone
fill 169 255 265 171 255 265 minecraft:blue_concrete
fill 170 255 232 182 255 232 minecraft:polished_blackstone
fill 170 255 235 171 255 235 minecraft:orange_concrete
fill 170 255 238 173 255 238 minecraft:polished_blackstone
fill 170 255 240 172 255 240 minecraft:ochre_froglight
fill 170 255 241 170 258 241 minecraft:orange_concrete
fill 170 255 257 170 258 257 minecraft:orange_concrete
fill 170 255 258 172 255 258 minecraft:ochre_froglight
fill 170 255 260 173 255 260 minecraft:polished_blackstone
fill 170 255 263 171 255 263 minecraft:orange_concrete
fill 170 255 266 182 255 266 minecraft:polished_blackstone
fill 171 255 234 172 255 234 minecraft:blue_concrete
fill 171 255 241 172 255 241 minecraft:ochre_froglight
fill 171 255 257 172 255 257 minecraft:ochre_froglight
fill 171 255 264 172 255 264 minecraft:blue_concrete
fill 172 255 233 182 255 233 minecraft:polished_blackstone
setblock 172 255 235 minecraft:polished_blackstone
fill 172 255 236 173 255 236 minecraft:orange_concrete
fill 172 255 239 174 255 239 minecraft:polished_blackstone
fill 172 255 242 173 255 243 minecraft:ochre_froglight
fill 172 255 255 173 255 256 minecraft:ochre_froglight
fill 172 255 259 174 255 259 minecraft:polished_blackstone
fill 172 255 262 173 255 262 minecraft:orange_concrete
setblock 172 255 263 minecraft:polished_blackstone
fill 172 255 265 182 255 265 minecraft:polished_blackstone
fill 173 255 234 182 255 234 minecraft:polished_blackstone
fill 173 255 235 174 255 235 minecraft:blue_concrete
fill 173 255 237 174 255 237 minecraft:orange_concrete
fill 173 255 240 175 255 241 minecraft:polished_blackstone
fill 173 255 244 174 255 245 minecraft:ochre_froglight
fill 173 255 253 174 255 254 minecraft:ochre_froglight
fill 173 255 257 175 255 258 minecraft:polished_blackstone
fill 173 255 261 174 255 261 minecraft:orange_concrete
fill 173 255 263 174 255 263 minecraft:blue_concrete
fill 173 255 264 182 255 264 minecraft:polished_blackstone
fill 174 255 236 175 255 236 minecraft:blue_concrete
fill 174 255 238 175 255 238 minecraft:orange_concrete
fill 174 255 242 176 255 242 minecraft:polished_blackstone
setblock 174 255 243 minecraft:ochre_froglight
fill 174 255 246 175 255 252 minecraft:ochre_froglight
setblock 174 255 255 minecraft:ochre_froglight
fill 174 255 256 176 255 256 minecraft:polished_blackstone
fill 174 255 260 175 255 260 minecraft:orange_concrete
fill 174 255 262 175 255 262 minecraft:blue_concrete
fill 175 255 235 182 255 235 minecraft:polished_blackstone
fill 175 255 237 176 255 237 minecraft:blue_concrete
setblock 175 255 239 minecraft:orange_concrete
fill 175 255 243 176 255 245 minecraft:polished_blackstone
fill 175 255 253 176 255 255 minecraft:polished_blackstone
setblock 175 255 259 minecraft:orange_concrete
fill 175 255 261 176 255 261 minecraft:blue_concrete
fill 175 255 263 182 255 263 minecraft:polished_blackstone
fill 176 255 236 182 255 236 minecraft:polished_blackstone
setblock 176 255 238 minecraft:blue_concrete
setblock 176 255 239 minecraft:polished_blackstone
fill 176 255 240 176 255 241 minecraft:orange_concrete
fill 176 255 246 177 255 252 minecraft:polished_blackstone
fill 176 255 257 176 255 258 minecraft:orange_concrete
setblock 176 255 259 minecraft:polished_blackstone
setblock 176 255 260 minecraft:blue_concrete
fill 176 255 262 182 255 262 minecraft:polished_blackstone
fill 177 255 237 182 255 238 minecraft:polished_blackstone
fill 177 255 239 177 255 240 minecraft:blue_concrete
fill 177 255 241 177 255 243 minecraft:orange_concrete
fill 177 255 244 177 255 245 minecraft:polished_blackstone
fill 177 255 253 177 255 254 minecraft:polished_blackstone
fill 177 255 255 177 255 257 minecraft:orange_concrete
fill 177 255 258 177 255 259 minecraft:blue_concrete
fill 177 255 260 182 255 261 minecraft:polished_blackstone
fill 178 255 239 182 255 239 minecraft:polished_blackstone
fill 178 255 240 178 255 242 minecraft:blue_concrete
fill 178 255 243 178 255 255 minecraft:orange_concrete
fill 178 255 256 178 255 258 minecraft:blue_concrete
fill 178 255 259 182 255 259 minecraft:polished_blackstone
fill 179 255 240 182 255 241 minecraft:polished_blackstone
fill 179 255 242 179 255 245 minecraft:blue_concrete
fill 179 255 246 179 255 247 minecraft:polished_blackstone
fill 179 255 248 179 255 250 minecraft:orange_concrete
fill 179 255 251 179 255 252 minecraft:polished_blackstone
fill 179 255 253 179 255 256 minecraft:blue_concrete
fill 179 255 257 182 255 258 minecraft:polished_blackstone
fill 180 255 242 182 255 244 minecraft:polished_blackstone
fill 180 255 245 180 255 253 minecraft:blue_concrete
fill 180 255 254 182 255 256 minecraft:polished_blackstone
fill 181 255 245 182 255 253 minecraft:polished_blackstone
fill 142 256 229 145 256 269 minecraft:gray_concrete
fill 146 256 229 182 256 232 minecraft:gray_concrete
fill 146 256 266 182 256 269 minecraft:gray_concrete
fill 150 256 246 150 256 248 minecraft:orange_concrete
fill 150 256 249 150 258 249 minecraft:black_concrete
fill 150 256 250 150 256 252 minecraft:orange_concrete
fill 151 256 244 151 258 245 minecraft:orange_concrete
fill 151 256 253 151 258 254 minecraft:orange_concrete
fill 152 256 242 152 257 243 minecraft:orange_concrete
fill 152 256 255 152 257 256 minecraft:orange_concrete
fill 153 256 241 153 258 241 minecraft:black_concrete
fill 153 256 257 153 258 257 minecraft:black_concrete
fill 154 256 240 154 258 240 minecraft:orange_concrete
fill 154 256 258 154 257 258 minecraft:orange_concrete
fill 155 256 239 156 257 239 minecraft:orange_concrete
fill 155 256 259 156 256 259 minecraft:orange_concrete
fill 157 256 238 157 258 238 minecraft:orange_concrete
fill 157 256 260 157 258 260 minecraft:orange_concrete
setblock 158 256 238 minecraft:orange_terracotta
setblock 158 256 260 minecraft:orange_terracotta
fill 159 256 237 161 256 237 minecraft:orange_concrete
fill 159 256 261 161 256 261 minecraft:orange_concrete
fill 162 256 237 162 258 237 minecraft:black_concrete
fill 162 256 261 162 258 261 minecraft:black_concrete
setblock 163 256 237 minecraft:orange_terracotta
fill 163 256 261 163 258 261 minecraft:orange_concrete
fill 164 256 237 165 256 237 minecraft:orange_concrete
setblock 164 256 261 minecraft:orange_terracotta
setblock 165 256 261 minecraft:orange_concrete
fill 166 256 238 167 257 238 minecraft:orange_concrete
fill 166 256 260 167 257 260 minecraft:orange_concrete
fill 168 256 239 169 256 239 minecraft:orange_concrete
fill 168 256 259 169 257 259 minecraft:orange_concrete
setblock 170 256 240 minecraft:orange_terracotta
fill 170 256 258 170 258 258 minecraft:orange_concrete
fill 171 256 241 171 258 241 minecraft:black_concrete
fill 171 256 257 171 258 257 minecraft:black_concrete
fill 172 256 242 172 257 243 minecraft:orange_concrete
setblock 172 256 255 minecraft:orange_terracotta
fill 172 256 256 172 257 256 minecraft:orange_concrete
fill 173 256 244 173 258 245 minecraft:orange_concrete
fill 173 256 253 173 258 254 minecraft:orange_concrete
fill 174 256 246 174 256 247 minecraft:orange_concrete
setblock 174 256 248 minecraft:orange_terracotta
fill 174 256 249 174 258 249 minecraft:black_concrete
fill 174 256 250 174 256 252 minecraft:orange_concrete
fill 179 256 233 182 256 265 minecraft:gray_concrete
fill 142 257 229 144 258 269 minecraft:gray_concrete
fill 145 257 229 182 258 231 minecraft:gray_concrete
fill 145 257 232 145 257 236 minecraft:orange_concrete
setblock 145 257 237 minecraft:light_gray_concrete
fill 145 257 238 145 257 245 minecraft:orange_concrete
setblock 145 257 246 minecraft:light_gray_concrete
fill 145 257 247 145 257 248 minecraft:orange_concrete
fill 145 257 249 145 257 251 minecraft:blue_concrete
fill 145 257 252 145 257 254 minecraft:orange_concrete
setblock 145 257 255 minecraft:light_gray_concrete
fill 145 257 256 145 257 263 minecraft:orange_concrete
setblock 145 257 264 minecraft:light_gray_concrete
fill 145 257 265 145 257 266 minecraft:orange_concrete
fill 145 257 267 182 258 269 minecraft:gray_concrete
fill 146 257 232 149 257 232 minecraft:orange_concrete
fill 146 257 266 149 257 266 minecraft:orange_concrete
setblock 150 257 232 minecraft:light_gray_concrete
setblock 150 257 247 minecraft:orange_terracotta
fill 150 257 248 150 258 248 minecraft:orange_concrete
fill 150 257 250 150 257 251 minecraft:orange_concrete
setblock 150 257 266 minecraft:light_gray_concrete
fill 151 257 232 158 257 232 minecraft:orange_concrete
fill 151 257 266 158 257 266 minecraft:orange_concrete
setblock 155 257 259 minecraft:orange_concrete
setblock 156 257 259 minecraft:orange_terracotta
fill 158 257 238 158 259 238 minecraft:orange_concrete
fill 158 257 260 158 259 260 minecraft:orange_concrete
setblock 159 257 232 minecraft:light_gray_concrete
fill 159 257 246 159 257 248 minecraft:glowstone
setblock 159 257 266 minecraft:light_gray_concrete
fill 160 257 232 161 257 232 minecraft:orange_concrete
fill 160 257 237 161 257 237 minecraft:orange_concrete
fill 160 257 245 160 257 246 minecraft:glowstone
fill 160 257 248 160 257 249 minecraft:glowstone
fill 160 257 261 161 257 261 minecraft:orange_concrete
fill 160 257 266 161 257 266 minecraft:orange_concrete
fill 161 257 244 161 257 245 minecraft:glowstone
fill 161 257 249 161 257 250 minecraft:glowstone
fill 162 257 232 164 257 232 minecraft:blue_concrete
fill 162 257 244 163 257 244 minecraft:glowstone
fill 162 257 250 163 257 250 minecraft:glowstone
fill 162 257 266 164 257 266 minecraft:blue_concrete
fill 163 257 237 164 257 237 minecraft:orange_concrete
fill 163 257 245 164 257 245 minecraft:glowstone
fill 163 257 249 164 257 249 minecraft:glowstone
fill 164 257 246 165 257 246 minecraft:glowstone
fill 164 257 248 165 257 248 minecraft:glowstone
setblock 164 257 261 minecraft:orange_concrete
fill 165 257 232 167 257 232 minecraft:orange_concrete
setblock 165 257 247 minecraft:glowstone
fill 165 257 266 167 257 266 minecraft:orange_concrete
setblock 168 257 232 minecraft:light_gray_concrete
setblock 168 257 239 minecraft:orange_terracotta
setblock 168 257 266 minecraft:light_gray_concrete
fill 169 257 232 176 257 232 minecraft:orange_concrete
setblock 169 257 239 minecraft:orange_concrete
fill 169 257 266 176 257 266 minecraft:orange_concrete
fill 170 257 240 170 258 240 minecraft:orange_concrete
fill 172 257 255 172 259 255 minecraft:orange_concrete
fill 174 257 247 174 257 248 minecraft:orange_concrete
fill 174 257 250 174 258 250 minecraft:orange_concrete
setblock 174 257 251 minecraft:orange_terracotta
setblock 177 257 232 minecraft:light_gray_concrete
setblock 177 257 266 minecraft:light_gray_concrete
fill 178 257 232 179 257 232 minecraft:orange_concrete
fill 178 257 266 179 257 266 minecraft:orange_concrete
fill 179 257 233 179 257 236 minecraft:orange_concrete
setblock 179 257 237 minecraft:light_gray_concrete
fill 179 257 238 179 257 245 minecraft:orange_concrete
setblock 179 257 246 minecraft:light_gray_concrete
fill 179 257 247 179 257 248 minecraft:orange_concrete
fill 179 257 249 179 257 251 minecraft:blue_concrete
fill 179 257 252 179 257 254 minecraft:orange_concrete
setblock 179 257 255 minecraft:light_gray_concrete
fill 179 257 256 179 257 263 minecraft:orange_concrete
setblock 179 257 264 minecraft:light_gray_concrete
setblock 179 257 265 minecraft:orange_concrete
fill 180 257 232 182 258 266 minecraft:gray_concrete
setblock 145 258 232 minecraft:light_blue_wool
setblock 145 258 233 minecraft:gray_wool
fill 145 258 234 145 258 235 minecraft:orange_wool
setblock 145 258 236 minecraft:blue_wool
setblock 145 258 238 minecraft:red_wool
setblock 145 258 240 minecraft:red_wool
setblock 145 258 243 minecraft:gray_wool
setblock 145 258 244 minecraft:blue_wool
setblock 145 258 245 minecraft:cyan_wool
setblock 145 258 247 minecraft:black_wool
setblock 145 258 249 minecraft:black_wool
setblock 145 258 250 minecraft:orange_wool
setblock 145 258 251 minecraft:lime_wool
setblock 145 258 252 minecraft:purple_wool
setblock 145 258 254 minecraft:blue_wool
setblock 145 258 258 minecraft:gray_wool
setblock 145 258 260 minecraft:gray_wool
setblock 145 258 261 minecraft:magenta_wool
setblock 145 258 262 minecraft:light_blue_wool
setblock 145 258 263 minecraft:yellow_wool
setblock 145 258 265 minecraft:lime_wool
setblock 146 258 266 minecraft:orange_wool
setblock 147 258 232 minecraft:white_wool
setblock 147 258 266 minecraft:red_wool
setblock 148 258 266 minecraft:blue_wool
setblock 149 258 266 minecraft:magenta_wool
setblock 150 258 250 minecraft:orange_terracotta
setblock 151 258 238 minecraft:light[level=15]
fill 151 258 251 151 260 251 minecraft:orange_concrete
setblock 151 258 252 minecraft:orange_terracotta
setblock 151 258 259 minecraft:light[level=15]
setblock 151 258 266 minecraft:cyan_wool
setblock 152 258 232 minecraft:lime_wool
setblock 152 258 243 minecraft:orange_terracotta
fill 152 258 255 152 259 255 minecraft:orange_concrete
setblock 152 258 266 minecraft:orange_wool
setblock 153 258 256 minecraft:orange_terracotta
setblock 154 258 232 minecraft:blue_wool
fill 154 258 256 154 260 256 minecraft:orange_concrete
setblock 154 258 258 minecraft:orange_terracotta
setblock 155 258 232 minecraft:white_wool
setblock 156 258 232 minecraft:red_wool
fill 156 258 239 156 259 239 minecraft:orange_concrete
fill 156 258 259 156 259 259 minecraft:orange_concrete
setblock 157 258 232 minecraft:gray_wool
setblock 157 258 266 minecraft:black_wool
setblock 158 258 232 minecraft:cyan_wool
setblock 158 258 266 minecraft:light[level=15]
fill 159 258 246 159 260 248 minecraft:black_concrete
setblock 160 258 232 minecraft:blue_wool
fill 160 258 245 160 260 246 minecraft:black_concrete
fill 160 258 248 160 260 249 minecraft:black_concrete
setblock 160 258 266 minecraft:cyan_wool
setblock 161 258 237 minecraft:orange_concrete
fill 161 258 244 161 260 245 minecraft:black_concrete
fill 161 258 249 161 260 250 minecraft:black_concrete
setblock 161 258 261 minecraft:orange_terracotta
setblock 161 258 266 minecraft:gray_wool
setblock 162 258 232 minecraft:magenta_wool
fill 162 258 244 163 260 244 minecraft:black_concrete
fill 162 258 250 163 260 250 minecraft:black_concrete
setblock 162 258 266 minecraft:orange_wool
setblock 163 258 237 minecraft:orange_concrete
fill 163 258 245 164 260 245 minecraft:black_concrete
fill 163 258 249 164 260 249 minecraft:black_concrete
fill 164 258 246 165 260 246 minecraft:black_concrete
fill 164 258 248 165 260 248 minecraft:black_concrete
setblock 164 258 266 minecraft:light_blue_wool
fill 165 258 247 165 260 247 minecraft:black_concrete
setblock 165 258 266 minecraft:blue_wool
setblock 166 258 232 minecraft:orange_wool
setblock 166 258 238 minecraft:orange_terracotta
setblock 166 258 260 minecraft:orange_terracotta
setblock 166 258 266 minecraft:black_wool
setblock 167 258 232 minecraft:purple_wool
setblock 167 258 238 minecraft:orange_concrete
setblock 167 258 260 minecraft:orange_concrete
setblock 167 258 266 minecraft:light_blue_wool
fill 168 258 239 168 259 239 minecraft:orange_concrete
fill 168 258 259 168 259 259 minecraft:orange_concrete
setblock 169 258 232 minecraft:orange_wool
setblock 169 258 266 minecraft:gray_wool
setblock 171 258 266 minecraft:cyan_wool
setblock 172 258 232 minecraft:lime_wool
setblock 172 258 238 minecraft:light[level=15]
fill 172 258 243 172 259 243 minecraft:orange_concrete
setblock 172 258 259 minecraft:light[level=15]
setblock 172 258 266 minecraft:light[level=15]
setblock 173 258 232 minecraft:black_wool
fill 173 258 251 173 260 251 minecraft:orange_concrete
setblock 173 258 252 minecraft:orange_terracotta
setblock 174 258 232 minecraft:gray_wool
setblock 174 258 248 minecraft:orange_concrete
setblock 174 258 266 minecraft:yellow_wool
setblock 176 258 266 minecraft:lime_wool
setblock 178 258 266 minecraft:black_wool
setblock 179 258 232 minecraft:lime_wool
setblock 179 258 233 minecraft:magenta_wool
setblock 179 258 234 minecraft:orange_wool
setblock 179 258 238 minecraft:magenta_wool
setblock 179 258 240 minecraft:magenta_wool
setblock 179 258 242 minecraft:magenta_wool
fill 179 258 244 179 258 245 minecraft:light_blue_wool
setblock 179 258 247 minecraft:yellow_wool
setblock 179 258 250 minecraft:white_wool
setblock 179 258 251 minecraft:purple_wool
setblock 179 258 252 minecraft:cyan_wool
setblock 179 258 256 minecraft:lime_wool
setblock 179 258 257 minecraft:magenta_wool
setblock 179 258 259 minecraft:magenta_wool
setblock 179 258 260 minecraft:black_wool
setblock 179 258 261 minecraft:red_wool
setblock 179 258 262 minecraft:white_wool
setblock 179 258 265 minecraft:lime_wool
setblock 179 258 266 minecraft:light_blue_wool
fill 142 259 229 143 260 269 minecraft:gray_concrete
fill 144 259 229 182 260 230 minecraft:gray_concrete
fill 144 259 231 144 259 236 minecraft:orange_concrete
setblock 144 259 237 minecraft:light_gray_concrete
fill 144 259 238 144 259 245 minecraft:orange_concrete
setblock 144 259 246 minecraft:light_gray_concrete
fill 144 259 247 144 259 248 minecraft:blue_concrete
fill 144 259 249 144 259 254 minecraft:orange_concrete
setblock 144 259 255 minecraft:light_gray_concrete
fill 144 259 256 144 259 263 minecraft:orange_concrete
setblock 144 259 264 minecraft:light_gray_concrete
fill 144 259 265 144 259 266 minecraft:orange_concrete
setblock 144 259 267 minecraft:blue_concrete
fill 144 259 268 182 260 269 minecraft:gray_concrete
fill 145 259 231 149 259 231 minecraft:orange_concrete
setblock 145 259 232 minecraft:pink_terracotta
setblock 145 259 233 minecraft:white_terracotta
setblock 145 259 234 minecraft:brown_terracotta
setblock 145 259 235 minecraft:orange_terracotta
setblock 145 259 236 minecraft:white_terracotta
setblock 145 259 238 minecraft:orange_terracotta
setblock 145 259 240 minecraft:orange_terracotta
setblock 145 259 243 minecraft:orange_terracotta
fill 145 259 244 145 259 245 minecraft:white_terracotta
setblock 145 259 247 minecraft:brown_terracotta
setblock 145 259 249 minecraft:pink_terracotta
setblock 145 259 250 minecraft:orange_terracotta
setblock 145 259 251 minecraft:brown_terracotta
setblock 145 259 252 minecraft:brown_concrete
setblock 145 259 254 minecraft:yellow_terracotta
setblock 145 259 258 minecraft:brown_terracotta
setblock 145 259 260 minecraft:yellow_terracotta
setblock 145 259 261 minecraft:orange_terracotta
setblock 145 259 262 minecraft:yellow_terracotta
setblock 145 259 263 minecraft:brown_terracotta
setblock 145 259 265 minecraft:white_terracotta
fill 145 259 267 149 259 267 minecraft:orange_concrete
setblock 146 259 266 minecraft:yellow_terracotta
setblock 147 259 232 minecraft:pink_terracotta
setblock 147 259 266 minecraft:brown_concrete
setblock 149 259 266 minecraft:pink_terracotta
setblock 150 259 231 minecraft:light_gray_concrete
setblock 150 259 267 minecraft:light_gray_concrete
fill 151 259 231 158 259 231 minecraft:orange_concrete
setblock 151 259 245 minecraft:orange_concrete
fill 151 259 249 151 260 249 minecraft:black_concrete
fill 151 259 252 151 259 253 minecraft:orange_concrete
setblock 151 259 266 minecraft:brown_concrete
fill 151 259 267 158 259 267 minecraft:orange_concrete
setblock 152 259 232 minecraft:orange_terracotta
setblock 152 259 243 minecraft:orange_concrete
fill 153 259 256 153 260 256 minecraft:orange_concrete
setblock 154 259 232 minecraft:pink_terracotta
fill 154 259 241 154 260 241 minecraft:black_concrete
fill 154 259 257 154 260 257 minecraft:black_concrete
setblock 156 259 232 minecraft:yellow_terracotta
setblock 157 259 232 minecraft:orange_terracotta
setblock 157 259 266 minecraft:orange_terracotta
setblock 158 259 232 minecraft:brown_concrete
setblock 159 259 231 minecraft:light_gray_concrete
setblock 159 259 238 minecraft:orange_terracotta
setblock 159 259 260 minecraft:orange_terracotta
setblock 159 259 267 minecraft:light_gray_concrete
fill 160 259 231 161 259 231 minecraft:blue_concrete
setblock 160 259 232 minecraft:pink_terracotta
setblock 160 259 266 minecraft:white_terracotta
fill 160 259 267 161 259 267 minecraft:blue_concrete
fill 161 259 266 162 259 266 minecraft:brown_terracotta
fill 162 259 231 167 259 231 minecraft:orange_concrete
setblock 162 259 232 minecraft:brown_concrete
fill 162 259 238 162 260 238 minecraft:black_concrete
fill 162 259 260 162 260 260 minecraft:black_concrete
fill 162 259 267 167 259 267 minecraft:orange_concrete
setblock 163 259 238 minecraft:orange_concrete
setblock 163 259 260 minecraft:orange_concrete
fill 164 259 266 165 259 266 minecraft:yellow_terracotta
setblock 166 259 232 minecraft:pink_terracotta
setblock 166 259 238 minecraft:orange_concrete
setblock 166 259 260 minecraft:orange_concrete
setblock 166 259 266 minecraft:brown_concrete
setblock 167 259 232 minecraft:brown_terracotta
setblock 167 259 266 minecraft:brown_terracotta
setblock 168 259 231 minecraft:light_gray_concrete
setblock 168 259 267 minecraft:light_gray_concrete
fill 169 259 231 176 259 231 minecraft:orange_concrete
setblock 169 259 232 minecraft:brown_concrete
setblock 169 259 258 minecraft:orange_terracotta
setblock 169 259 266 minecraft:yellow_terracotta
fill 169 259 267 176 259 267 minecraft:orange_concrete
fill 170 259 241 170 260 241 minecraft:black_concrete
fill 170 259 257 170 260 257 minecraft:black_concrete
setblock 171 259 266 minecraft:orange_terracotta
setblock 172 259 232 minecraft:orange_terracotta
setblock 173 259 232 minecraft:white_terracotta
setblock 173 259 245 minecraft:orange_concrete
fill 173 259 249 173 260 249 minecraft:black_concrete
fill 173 259 252 173 259 253 minecraft:orange_concrete
setblock 174 259 232 minecraft:yellow_terracotta
setblock 177 259 231 minecraft:light_gray_concrete
setblock 177 259 267 minecraft:light_gray_concrete
fill 178 259 231 180 259 231 minecraft:orange_concrete
setblock 178 259 266 minecraft:brown_terracotta
fill 178 259 267 179 259 267 minecraft:orange_concrete
setblock 179 259 233 minecraft:white_terracotta
setblock 179 259 238 minecraft:white_terracotta
setblock 179 259 240 minecraft:pink_terracotta
setblock 179 259 242 minecraft:orange_terracotta
setblock 179 259 245 minecraft:brown_terracotta
setblock 179 259 250 minecraft:orange_terracotta
setblock 179 259 251 minecraft:brown_terracotta
setblock 179 259 252 minecraft:brown_concrete
setblock 179 259 256 minecraft:orange_terracotta
setblock 179 259 257 minecraft:pink_terracotta
setblock 179 259 259 minecraft:orange_terracotta
fill 179 259 260 179 259 261 minecraft:yellow_terracotta
setblock 179 259 262 minecraft:brown_concrete
setblock 179 259 265 minecraft:brown_concrete
setblock 179 259 266 minecraft:yellow_terracotta
fill 180 259 232 180 259 236 minecraft:orange_concrete
setblock 180 259 237 minecraft:light_gray_concrete
fill 180 259 238 180 259 245 minecraft:orange_concrete
setblock 180 259 246 minecraft:light_gray_concrete
fill 180 259 247 180 259 248 minecraft:blue_concrete
fill 180 259 249 180 259 254 minecraft:orange_concrete
setblock 180 259 255 minecraft:light_gray_concrete
fill 180 259 256 180 259 263 minecraft:orange_concrete
setblock 180 259 264 minecraft:light_gray_concrete
fill 180 259 265 180 259 266 minecraft:orange_concrete
setblock 180 259 267 minecraft:blue_concrete
fill 181 259 231 182 260 267 minecraft:gray_concrete
setblock 144 260 231 minecraft:white_wool
setblock 144 260 232 minecraft:cyan_wool
setblock 144 260 235 minecraft:light_blue_wool
setblock 144 260 236 minecraft:orange_wool
setblock 144 260 239 minecraft:yellow_wool
setblock 144 260 241 minecraft:gray_wool
setblock 144 260 242 minecraft:blue_wool
setblock 144 260 243 minecraft:magenta_wool
setblock 144 260 247 minecraft:yellow_wool
setblock 144 260 248 minecraft:blue_wool
setblock 144 260 249 minecraft:black_wool
fill 144 260 252 144 260 253 minecraft:white_wool
setblock 144 260 256 minecraft:gray_wool
setblock 144 260 257 minecraft:yellow_wool
setblock 144 260 258 minecraft:magenta_wool
setblock 144 260 262 minecraft:gray_wool
setblock 144 260 263 minecraft:lime_wool
setblock 144 260 265 minecraft:light_blue_wool
setblock 144 260 266 minecraft:black_wool
setblock 144 260 267 minecraft:red_wool
setblock 146 260 231 minecraft:orange_wool
setblock 146 260 267 minecraft:yellow_wool
fill 147 260 267 148 260 267 minecraft:gray_wool
setblock 149 260 267 minecraft:magenta_wool
setblock 151 260 231 minecraft:red_wool
setblock 151 260 246 minecraft:orange_concrete
setblock 151 260 247 minecraft:orange_terracotta
setblock 151 260 248 minecraft:orange_concrete
setblock 151 260 252 minecraft:orange_concrete
setblock 153 260 231 minecraft:gray_wool
setblock 154 260 231 minecraft:magenta_wool
setblock 155 260 231 minecraft:white_wool
setblock 156 260 231 minecraft:magenta_wool
setblock 157 260 239 minecraft:orange_concrete
setblock 157 260 259 minecraft:orange_terracotta
setblock 158 260 239 minecraft:orange_terracotta
setblock 158 260 267 minecraft:yellow_wool
setblock 159 260 238 minecraft:orange_concrete
setblock 159 260 260 minecraft:orange_concrete
setblock 161 260 267 minecraft:orange_wool
setblock 162 260 231 minecraft:black_wool
setblock 162 260 267 minecraft:red_wool
setblock 163 260 231 minecraft:gray_wool
setblock 163 260 238 minecraft:orange_terracotta
setblock 163 260 260 minecraft:orange_terracotta
setblock 163 260 267 minecraft:orange_wool
setblock 164 260 231 minecraft:yellow_wool
fill 165 260 231 166 260 231 minecraft:white_wool
setblock 165 260 267 minecraft:orange_wool
setblock 166 260 267 minecraft:red_wool
setblock 167 260 231 minecraft:gray_wool
setblock 169 260 231 minecraft:orange_wool
setblock 169 260 258 minecraft:orange_concrete
setblock 170 260 231 minecraft:red_wool
setblock 171 260 231 minecraft:orange_wool
setblock 171 260 243 minecraft:orange_terracotta
setblock 172 260 244 minecraft:orange_concrete
setblock 172 260 245 minecraft:orange_terracotta
setblock 172 260 267 minecraft:purple_wool
setblock 173 260 231 minecraft:gray_wool
setblock 173 260 246 minecraft:orange_concrete
setblock 173 260 247 minecraft:orange_terracotta
setblock 173 260 248 minecraft:orange_concrete
setblock 173 260 252 minecraft:orange_concrete
setblock 173 260 267 minecraft:magenta_wool
setblock 174 260 267 minecraft:black_wool
setblock 175 260 231 minecraft:blue_wool
setblock 178 260 267 minecraft:magenta_wool
setblock 179 260 231 minecraft:blue_wool
setblock 179 260 267 minecraft:lime_wool
setblock 180 260 231 minecraft:gray_wool
setblock 180 260 232 minecraft:orange_wool
setblock 180 260 234 minecraft:light_blue_wool
setblock 180 260 235 minecraft:lime_wool
setblock 180 260 238 minecraft:cyan_wool
setblock 180 260 240 minecraft:lime_wool
setblock 180 260 241 minecraft:magenta_wool
setblock 180 260 243 minecraft:light_blue_wool
setblock 180 260 247 minecraft:lime_wool
setblock 180 260 248 minecraft:red_wool
setblock 180 260 249 minecraft:cyan_wool
setblock 180 260 252 minecraft:blue_wool
setblock 180 260 254 minecraft:blue_wool
setblock 180 260 258 minecraft:magenta_wool
setblock 180 260 259 minecraft:gray_wool
setblock 180 260 260 minecraft:white_wool
setblock 180 260 261 minecraft:orange_wool
setblock 180 260 262 minecraft:blue_wool
setblock 180 260 263 minecraft:cyan_wool
setblock 180 260 265 minecraft:cyan_wool
setblock 180 260 266 minecraft:yellow_wool
setblock 180 260 267 minecraft:cyan_wool
fill 142 261 229 142 262 269 minecraft:gray_concrete
fill 143 261 229 182 262 229 minecraft:gray_concrete
fill 143 261 230 143 261 236 minecraft:orange_concrete
setblock 143 261 237 minecraft:light_gray_concrete
fill 143 261 238 143 261 242 minecraft:orange_concrete
fill 143 261 243 143 261 245 minecraft:blue_concrete
setblock 143 261 246 minecraft:light_gray_concrete
fill 143 261 247 143 261 254 minecraft:orange_concrete
setblock 143 261 255 minecraft:light_gray_concrete
fill 143 261 256 143 261 263 minecraft:orange_concrete
setblock 143 261 264 minecraft:light_gray_concrete
fill 143 261 265 143 261 266 minecraft:blue_concrete
fill 143 261 267 143 261 268 minecraft:orange_concrete
fill 143 261 269 182 262 269 minecraft:gray_concrete
fill 144 261 230 149 261 230 minecraft:orange_concrete
setblock 144 261 231 minecraft:brown_concrete
setblock 144 261 232 minecraft:brown_terracotta
setblock 144 261 235 minecraft:pink_terracotta
setblock 144 261 236 minecraft:white_terracotta
setblock 144 261 239 minecraft:brown_concrete
setblock 144 261 242 minecraft:brown_concrete
setblock 144 261 243 minecraft:orange_terracotta
setblock 144 261 249 minecraft:white_terracotta
setblock 144 261 252 minecraft:brown_terracotta
setblock 144 261 253 minecraft:pink_terracotta
setblock 144 261 256 minecraft:pink_terracotta
setblock 144 261 257 minecraft:white_terracotta
setblock 144 261 258 minecraft:orange_terracotta
setblock 144 261 263 minecraft:pink_terracotta
fill 144 261 266 144 261 267 minecraft:orange_terracotta
fill 144 261 268 149 261 268 minecraft:orange_concrete
setblock 146 261 231 minecraft:white_terracotta
setblock 146 261 267 minecraft:white_terracotta
setblock 147 261 267 minecraft:pink_terracotta
fill 148 261 267 149 261 267 minecraft:yellow_terracotta
setblock 150 261 230 minecraft:light_gray_concrete
setblock 150 261 268 minecraft:light_gray_concrete
fill 151 261 230 155 261 230 minecraft:orange_concrete
setblock 151 261 231 minecraft:pink_terracotta
fill 151 261 268 155 261 268 minecraft:orange_concrete
fill 152 261 249 154 262 249 minecraft:black_concrete
setblock 152 261 252 minecraft:orange_terracotta
fill 152 261 253 153 261 253 minecraft:orange_concrete
setblock 153 261 243 minecraft:orange_terracotta
fill 153 261 250 153 265 251 minecraft:black_concrete
fill 153 261 252 153 263 252 minecraft:orange_concrete
setblock 153 261 254 minecraft:orange_terracotta
setblock 154 261 231 minecraft:brown_terracotta
setblock 154 261 242 minecraft:black_concrete
fill 154 261 246 154 264 247 minecraft:orange_concrete
fill 154 261 248 155 265 248 minecraft:black_concrete
fill 154 261 250 158 261 250 minecraft:red_concrete
fill 154 261 251 154 265 252 minecraft:black_concrete
setblock 154 261 256 minecraft:black_concrete
setblock 155 261 231 minecraft:white_terracotta
fill 155 261 247 157 265 247 minecraft:black_concrete
fill 155 261 249 157 261 249 minecraft:red_concrete
fill 155 261 251 157 261 251 minecraft:red_concrete
fill 155 261 252 155 265 253 minecraft:black_concrete
fill 155 261 254 155 264 254 minecraft:orange_concrete
fill 156 261 230 158 261 230 minecraft:blue_concrete
setblock 156 261 248 minecraft:red_concrete
setblock 156 261 252 minecraft:red_concrete
fill 156 261 253 157 265 253 minecraft:black_concrete
fill 156 261 268 158 261 268 minecraft:blue_concrete
setblock 157 261 240 minecraft:orange_terracotta
fill 157 261 248 158 265 248 minecraft:black_concrete
fill 157 261 252 158 265 252 minecraft:black_concrete
fill 158 261 239 158 261 240 minecraft:orange_concrete
fill 158 261 247 158 266 247 minecraft:orange_concrete
fill 158 261 249 159 265 249 minecraft:black_concrete
fill 158 261 251 159 265 251 minecraft:black_concrete
fill 158 261 253 159 266 253 minecraft:orange_concrete
setblock 159 261 230 minecraft:light_gray_concrete
fill 159 261 246 159 261 248 minecraft:glowstone
fill 159 261 250 159 265 250 minecraft:black_concrete
fill 159 261 252 159 266 252 minecraft:orange_concrete
fill 159 261 254 159 266 254 minecraft:orange_concrete
setblock 159 261 268 minecraft:light_gray_concrete
fill 160 261 230 167 261 230 minecraft:orange_concrete
fill 160 261 245 160 261 246 minecraft:glowstone
fill 160 261 248 160 261 249 minecraft:glowstone
fill 160 261 250 160 267 250 minecraft:orange_concrete
fill 160 261 259 160 262 259 minecraft:orange_concrete
fill 160 261 268 167 261 268 minecraft:orange_concrete
fill 161 261 244 161 261 245 minecraft:glowstone
fill 161 261 249 161 261 250 minecraft:glowstone
setblock 161 261 259 minecraft:orange_terracotta
setblock 161 261 267 minecraft:brown_concrete
setblock 162 261 231 minecraft:orange_terracotta
fill 162 261 239 162 262 239 minecraft:black_concrete
fill 162 261 244 163 261 244 minecraft:glowstone
fill 162 261 250 163 261 250 minecraft:glowstone
fill 162 261 259 162 262 259 minecraft:black_concrete
setblock 162 261 267 minecraft:yellow_terracotta
setblock 163 261 231 minecraft:pink_terracotta
fill 163 261 245 164 261 245 minecraft:glowstone
fill 163 261 249 164 261 249 minecraft:glowstone
fill 163 261 251 163 265 253 minecraft:black_concrete
fill 163 261 254 163 266 254 minecraft:orange_concrete
setblock 164 261 231 minecraft:brown_terracotta
fill 164 261 246 165 261 246 minecraft:glowstone
fill 164 261 248 165 261 248 minecraft:glowstone
fill 164 261 250 164 265 251 minecraft:black_concrete
fill 164 261 252 168 261 252 minecraft:red_concrete
fill 164 261 253 164 265 254 minecraft:black_concrete
setblock 165 261 231 minecraft:brown_concrete
setblock 165 261 247 minecraft:glowstone
fill 165 261 249 165 265 250 minecraft:black_concrete
fill 165 261 251 167 261 251 minecraft:red_concrete
fill 165 261 253 167 261 253 minecraft:red_concrete
fill 165 261 254 165 265 255 minecraft:black_concrete
setblock 165 261 267 minecraft:orange_terracotta
setblock 166 261 231 minecraft:white_terracotta
fill 166 261 249 167 266 249 minecraft:black_concrete
setblock 166 261 250 minecraft:red_concrete
setblock 166 261 254 minecraft:red_concrete
fill 166 261 255 167 265 255 minecraft:black_concrete
setblock 166 261 267 minecraft:yellow_terracotta
fill 167 261 250 168 265 250 minecraft:black_concrete
fill 167 261 254 168 265 254 minecraft:black_concrete
setblock 168 261 230 minecraft:light_gray_concrete
setblock 168 261 240 minecraft:orange_terracotta
fill 168 261 251 169 265 251 minecraft:black_concrete
fill 168 261 253 169 265 253 minecraft:black_concrete
fill 168 261 255 168 263 256 minecraft:orange_concrete
setblock 168 261 268 minecraft:light_gray_concrete
fill 169 261 230 176 261 230 minecraft:orange_concrete
fill 169 261 250 169 265 250 minecraft:orange_concrete
fill 169 261 252 169 265 252 minecraft:black_concrete
fill 169 261 268 176 261 268 minecraft:orange_concrete
setblock 170 261 231 minecraft:white_terracotta
setblock 170 261 242 minecraft:black_concrete
setblock 170 261 256 minecraft:black_concrete
setblock 171 261 231 minecraft:yellow_terracotta
setblock 171 261 243 minecraft:orange_concrete
fill 171 261 254 171 262 254 minecraft:orange_concrete
setblock 172 261 245 minecraft:orange_concrete
fill 172 261 247 172 262 247 minecraft:orange_concrete
setblock 172 261 248 minecraft:orange_terracotta
fill 172 261 249 172 262 249 minecraft:black_concrete
fill 172 261 267 174 261 267 minecraft:pink_terracotta
setblock 173 261 231 minecraft:yellow_terracotta
setblock 175 261 231 minecraft:brown_terracotta
setblock 177 261 230 minecraft:light_gray_concrete
setblock 177 261 268 minecraft:light_gray_concrete
fill 178 261 230 179 261 230 minecraft:blue_concrete
fill 178 261 267 179 261 267 minecraft:orange_terracotta
fill 178 261 268 179 261 268 minecraft:blue_concrete
fill 179 261 231 180 261 231 minecraft:white_terracotta
fill 180 261 230 181 261 230 minecraft:orange_concrete
setblock 180 261 232 minecraft:brown_terracotta
setblock 180 261 234 minecraft:yellow_terracotta
setblock 180 261 235 minecraft:pink_terracotta
setblock 180 261 240 minecraft:brown_concrete
setblock 180 261 241 minecraft:white_terracotta
setblock 180 261 247 minecraft:yellow_terracotta
setblock 180 261 248 minecraft:brown_terracotta
setblock 180 261 249 minecraft:pink_terracotta
setblock 180 261 252 minecraft:yellow_terracotta
setblock 180 261 254 minecraft:brown_concrete
setblock 180 261 258 minecraft:white_terracotta
setblock 180 261 259 minecraft:brown_terracotta
setblock 180 261 260 minecraft:pink_terracotta
setblock 180 261 261 minecraft:white_terracotta
setblock 180 261 263 minecraft:brown_terracotta
setblock 180 261 265 minecraft:pink_terracotta
setblock 180 261 266 minecraft:orange_terracotta
setblock 180 261 267 minecraft:yellow_terracotta
fill 180 261 268 181 261 268 minecraft:orange_concrete
fill 181 261 231 181 261 236 minecraft:orange_concrete
setblock 181 261 237 minecraft:light_gray_concrete
fill 181 261 238 181 261 242 minecraft:orange_concrete
fill 181 261 243 181 261 245 minecraft:blue_concrete
setblock 181 261 246 minecraft:light_gray_concrete
fill 181 261 247 181 261 254 minecraft:orange_concrete
setblock 181 261 255 minecraft:light_gray_concrete
fill 181 261 256 181 261 263 minecraft:orange_concrete
setblock 181 261 264 minecraft:light_gray_concrete
fill 181 261 265 181 261 266 minecraft:blue_concrete
setblock 181 261 267 minecraft:orange_concrete
fill 182 261 230 182 262 268 minecraft:gray_concrete
setblock 143 262 231 minecraft:lime_wool
setblock 143 262 234 minecraft:gray_wool
setblock 143 262 238 minecraft:magenta_wool
setblock 143 262 244 minecraft:gray_wool
setblock 143 262 248 minecraft:white_wool
setblock 143 262 249 minecraft:gray_wool
setblock 143 262 250 minecraft:yellow_wool
setblock 143 262 253 minecraft:orange_wool
fill 143 262 256 143 262 257 minecraft:lime_wool
setblock 143 262 258 minecraft:orange_wool
setblock 143 262 259 minecraft:yellow_wool
setblock 143 262 263 minecraft:light_blue_wool
setblock 143 262 267 minecraft:cyan_wool
setblock 143 262 268 minecraft:red_wool
setblock 144 262 230 minecraft:magenta_wool
setblock 146 262 230 minecraft:red_wool
setblock 151 262 230 minecraft:lime_wool
setblock 151 262 268 minecraft:white_wool
setblock 153 262 230 minecraft:blue_wool
setblock 153 262 246 minecraft:orange_terracotta
fill 153 262 247 153 263 248 minecraft:orange_concrete
fill 153 262 253 153 262 254 minecraft:orange_concrete
setblock 153 262 268 minecraft:yellow_wool
setblock 154 262 230 minecraft:red_wool
setblock 154 262 268 minecraft:orange_wool
setblock 155 262 242 minecraft:black_concrete
setblock 155 262 256 minecraft:black_concrete
setblock 156 262 230 minecraft:magenta_wool
setblock 156 262 241 minecraft:orange_terracotta
setblock 156 262 268 minecraft:black_wool
fill 157 262 240 158 262 240 minecraft:orange_concrete
setblock 158 262 258 minecraft:orange_concrete
setblock 158 262 268 minecraft:cyan_wool
fill 159 262 246 159 264 248 minecraft:black_concrete
setblock 159 262 258 minecraft:orange_terracotta
setblock 160 262 230 minecraft:yellow_wool
fill 160 262 245 160 264 246 minecraft:black_concrete
fill 160 262 248 160 264 249 minecraft:black_concrete
fill 160 262 258 161 263 258 minecraft:orange_concrete
setblock 160 262 268 minecraft:blue_wool
fill 161 262 244 161 264 245 minecraft:black_concrete
fill 161 262 249 161 264 250 minecraft:black_concrete
setblock 161 262 259 minecraft:orange_concrete
fill 162 262 244 163 264 244 minecraft:black_concrete
fill 162 262 250 163 264 250 minecraft:black_concrete
setblock 163 262 230 minecraft:blue_wool
fill 163 262 245 164 264 245 minecraft:black_concrete
fill 163 262 249 164 264 249 minecraft:black_concrete
fill 164 262 246 165 264 246 minecraft:black_concrete
fill 164 262 248 165 264 248 minecraft:black_concrete
setblock 164 262 259 minecraft:orange_concrete
setblock 165 262 230 minecraft:red_wool
fill 165 262 247 165 264 247 minecraft:black_concrete
setblock 166 262 230 minecraft:black_wool
setblock 166 262 268 minecraft:blue_wool
setblock 169 262 242 minecraft:black_concrete
setblock 169 262 256 minecraft:black_concrete
setblock 169 262 268 minecraft:white_wool
setblock 170 262 268 minecraft:yellow_wool
setblock 171 262 230 minecraft:white_wool
setblock 171 262 253 minecraft:orange_concrete
fill 171 262 268 172 262 268 minecraft:lime_wool
setblock 172 262 248 minecraft:orange_concrete
setblock 172 262 250 minecraft:orange_concrete
setblock 172 262 251 minecraft:orange_terracotta
setblock 175 262 230 minecraft:yellow_wool
setblock 178 262 230 minecraft:purple_wool
setblock 179 262 230 minecraft:gray_wool
setblock 180 262 230 minecraft:magenta_wool
setblock 180 262 268 minecraft:cyan_wool
setblock 181 262 231 minecraft:cyan_wool
setblock 181 262 232 minecraft:lime_wool
setblock 181 262 233 minecraft:red_wool
setblock 181 262 234 minecraft:magenta_wool
setblock 181 262 236 minecraft:white_wool
setblock 181 262 238 minecraft:blue_wool
setblock 181 262 240 minecraft:blue_wool
setblock 181 262 242 minecraft:purple_wool
setblock 181 262 243 minecraft:orange_wool
setblock 181 262 245 minecraft:blue_wool
setblock 181 262 250 minecraft:light_blue_wool
setblock 181 262 254 minecraft:light_blue_wool
setblock 181 262 257 minecraft:orange_wool
setblock 181 262 262 minecraft:lime_wool
setblock 181 262 263 minecraft:purple_wool
setblock 181 262 266 minecraft:blue_wool
fill 142 263 229 142 263 236 minecraft:orange_concrete
setblock 142 263 237 minecraft:light_gray_concrete
fill 142 263 238 142 263 239 minecraft:orange_concrete
fill 142 263 240 142 263 242 minecraft:blue_concrete
fill 142 263 243 142 263 245 minecraft:orange_concrete
setblock 142 263 246 minecraft:light_gray_concrete
fill 142 263 247 142 263 254 minecraft:orange_concrete
setblock 142 263 255 minecraft:light_gray_concrete
fill 142 263 256 142 263 260 minecraft:orange_concrete
fill 142 263 261 142 263 263 minecraft:blue_concrete
setblock 142 263 264 minecraft:light_gray_concrete
fill 142 263 265 142 263 269 minecraft:orange_concrete
fill 143 263 229 149 263 229 minecraft:orange_concrete
setblock 143 263 231 minecraft:orange_terracotta
setblock 143 263 234 minecraft:yellow_terracotta
setblock 143 263 238 minecraft:brown_concrete
setblock 143 263 244 minecraft:yellow_terracotta
setblock 143 263 248 minecraft:pink_terracotta
setblock 143 263 249 minecraft:brown_concrete
setblock 143 263 250 minecraft:brown_terracotta
setblock 143 263 253 minecraft:yellow_terracotta
setblock 143 263 257 minecraft:pink_terracotta
setblock 143 263 258 minecraft:yellow_terracotta
setblock 143 263 263 minecraft:orange_terracotta
setblock 143 263 267 minecraft:pink_terracotta
setblock 143 263 268 minecraft:yellow_terracotta
fill 143 263 269 149 263 269 minecraft:orange_concrete
setblock 144 263 230 minecraft:brown_terracotta
setblock 146 263 230 minecraft:yellow_terracotta
setblock 150 263 229 minecraft:light_gray_concrete
setblock 150 263 269 minecraft:light_gray_concrete
fill 151 263 229 152 263 229 minecraft:orange_concrete
setblock 151 263 230 minecraft:pink_terracotta
setblock 151 263 268 minecraft:pink_terracotta
fill 151 263 269 152 263 269 minecraft:orange_concrete
fill 153 263 229 155 263 229 minecraft:blue_concrete
setblock 153 263 230 minecraft:pink_terracotta
setblock 153 263 246 minecraft:orange_concrete
fill 153 263 249 154 265 249 minecraft:black_concrete
setblock 153 263 268 minecraft:pink_terracotta
fill 153 263 269 155 263 269 minecraft:blue_concrete
setblock 154 263 230 minecraft:yellow_terracotta
setblock 154 263 268 minecraft:orange_terracotta
setblock 155 263 243 minecraft:black_concrete
setblock 155 263 255 minecraft:black_concrete
fill 156 263 229 158 263 229 minecraft:orange_concrete
setblock 156 263 230 minecraft:orange_terracotta
setblock 156 263 268 minecraft:yellow_terracotta
fill 156 263 269 158 263 269 minecraft:orange_concrete
setblock 157 263 257 minecraft:orange_terracotta
setblock 158 263 257 minecraft:orange_concrete
setblock 158 263 268 minecraft:brown_concrete
setblock 159 263 229 minecraft:light_gray_concrete
setblock 159 263 258 minecraft:orange_concrete
setblock 159 263 269 minecraft:light_gray_concrete
fill 160 263 229 167 263 229 minecraft:orange_concrete
setblock 160 263 230 minecraft:pink_terracotta
setblock 160 263 268 minecraft:white_terracotta
fill 160 263 269 167 263 269 minecraft:orange_concrete
setblock 162 263 240 minecraft:black_concrete
setblock 162 263 258 minecraft:black_concrete
setblock 163 263 230 minecraft:white_terracotta
fill 163 263 240 164 263 240 minecraft:orange_concrete
setblock 163 263 258 minecraft:orange_terracotta
fill 164 263 258 165 263 258 minecraft:orange_concrete
setblock 165 263 230 minecraft:brown_terracotta
setblock 165 263 240 minecraft:orange_terracotta
setblock 166 263 230 minecraft:yellow_terracotta
setblock 166 263 268 minecraft:brown_terracotta
setblock 168 263 229 minecraft:light_gray_concrete
setblock 168 263 242 minecraft:orange_concrete
setblock 168 263 269 minecraft:light_gray_concrete
fill 169 263 229 173 263 229 minecraft:orange_concrete
setblock 169 263 243 minecraft:black_concrete
setblock 169 263 255 minecraft:black_concrete
setblock 169 263 268 minecraft:white_terracotta
fill 169 263 269 173 263 269 minecraft:orange_concrete
setblock 170 263 268 minecraft:yellow_terracotta
setblock 171 263 230 minecraft:yellow_terracotta
setblock 171 263 248 minecraft:orange_concrete
setblock 171 263 249 minecraft:black_concrete
fill 171 263 250 171 263 251 minecraft:orange_concrete
setblock 171 263 252 minecraft:orange_terracotta
setblock 171 263 268 minecraft:pink_terracotta
setblock 172 263 268 minecraft:brown_concrete
fill 174 263 229 176 263 229 minecraft:blue_concrete
fill 174 263 269 176 263 269 minecraft:blue_concrete
setblock 175 263 230 minecraft:white_terracotta
setblock 177 263 229 minecraft:light_gray_concrete
setblock 177 263 269 minecraft:light_gray_concrete
fill 178 263 229 182 263 229 minecraft:orange_concrete
setblock 178 263 230 minecraft:brown_concrete
fill 178 263 269 182 263 269 minecraft:orange_concrete
setblock 179 263 230 minecraft:pink_terracotta
setblock 180 263 230 minecraft:white_terracotta
setblock 180 263 268 minecraft:yellow_terracotta
setblock 181 263 232 minecraft:brown_concrete
setblock 181 263 233 minecraft:pink_terracotta
setblock 181 263 234 minecraft:brown_terracotta
setblock 181 263 236 minecraft:orange_terracotta
setblock 181 263 240 minecraft:orange_terracotta
setblock 181 263 243 minecraft:brown_concrete
setblock 181 263 245 minecraft:yellow_terracotta
setblock 181 263 250 minecraft:orange_terracotta
setblock 181 263 254 minecraft:pink_terracotta
setblock 181 263 262 minecraft:orange_terracotta
setblock 181 263 266 minecraft:brown_terracotta
fill 182 263 230 182 263 236 minecraft:orange_concrete
setblock 182 263 237 minecraft:light_gray_concrete
fill 182 263 238 182 263 239 minecraft:orange_concrete
fill 182 263 240 182 263 242 minecraft:blue_concrete
fill 182 263 243 182 263 245 minecraft:orange_concrete
setblock 182 263 246 minecraft:light_gray_concrete
fill 182 263 247 182 263 254 minecraft:orange_concrete
setblock 182 263 255 minecraft:light_gray_concrete
fill 182 263 256 182 263 260 minecraft:orange_concrete
fill 182 263 261 182 263 263 minecraft:blue_concrete
setblock 182 263 264 minecraft:light_gray_concrete
fill 182 263 265 182 263 268 minecraft:orange_concrete
setblock 142 264 230 minecraft:lime_wool
setblock 142 264 231 minecraft:light_blue_wool
setblock 142 264 234 minecraft:yellow_wool
setblock 142 264 236 minecraft:magenta_wool
setblock 142 264 238 minecraft:red_wool
setblock 142 264 240 minecraft:orange_wool
setblock 142 264 241 minecraft:gray_wool
setblock 142 264 248 minecraft:magenta_wool
setblock 142 264 250 minecraft:orange_wool
setblock 142 264 251 minecraft:red_wool
setblock 142 264 252 minecraft:cyan_wool
setblock 142 264 253 minecraft:blue_wool
setblock 142 264 258 minecraft:cyan_wool
setblock 142 264 260 minecraft:white_wool
setblock 142 264 261 minecraft:magenta_wool
setblock 142 264 262 minecraft:yellow_wool
setblock 142 264 263 minecraft:red_wool
setblock 142 264 266 minecraft:orange_wool
setblock 142 264 268 minecraft:cyan_wool
setblock 142 264 269 minecraft:magenta_wool
setblock 144 264 229 minecraft:gray_wool
setblock 144 264 231 minecraft:light[level=15]
setblock 144 264 238 minecraft:light[level=15]
setblock 144 264 245 minecraft:light[level=15]
setblock 144 264 252 minecraft:light[level=15]
setblock 144 264 259 minecraft:light[level=15]
setblock 144 264 266 minecraft:light[level=15]
setblock 147 264 229 minecraft:light_blue_wool
setblock 148 264 229 minecraft:cyan_wool
setblock 149 264 229 minecraft:orange_wool
setblock 151 264 229 minecraft:black_wool
setblock 151 264 231 minecraft:light[level=15]
setblock 151 264 238 minecraft:light[level=15]
setblock 151 264 245 minecraft:light[level=15]
setblock 151 264 252 minecraft:light[level=15]
setblock 151 264 259 minecraft:light[level=15]
setblock 151 264 266 minecraft:light[level=15]
fill 151 264 269 152 264 269 minecraft:lime_wool
setblock 153 264 229 minecraft:black_wool
setblock 153 264 269 minecraft:cyan_wool
fill 155 264 229 156 264 229 minecraft:black_wool
setblock 155 264 244 minecraft:orange_concrete
setblock 155 264 245 minecraft:orange_terracotta
setblock 155 264 269 minecraft:magenta_wool
fill 156 264 243 156 264 244 minecraft:black_concrete
fill 156 264 254 156 264 255 minecraft:black_concrete
setblock 157 264 229 minecraft:yellow_wool
setblock 158 264 229 minecraft:black_wool
setblock 158 264 231 minecraft:light[level=15]
setblock 158 264 238 minecraft:light[level=15]
setblock 158 264 242 minecraft:orange_concrete
setblock 158 264 259 minecraft:light[level=15]
setblock 158 264 266 minecraft:light[level=15]
setblock 159 264 242 minecraft:orange_terracotta
fill 159 264 257 160 264 257 minecraft:orange_concrete
fill 160 264 229 161 264 229 minecraft:black_wool
fill 160 264 242 160 265 242 minecraft:orange_concrete
setblock 160 264 269 minecraft:orange_wool
setblock 161 264 257 minecraft:orange_terracotta
setblock 161 264 269 minecraft:yellow_wool
setblock 162 264 241 minecraft:black_concrete
setblock 162 264 257 minecraft:black_concrete
setblock 162 264 269 minecraft:lime_wool
setblock 163 264 241 minecraft:orange_concrete
setblock 163 264 269 minecraft:orange_wool
setblock 164 264 241 minecraft:orange_terracotta
setblock 165 264 231 minecraft:light[level=15]
setblock 165 264 238 minecraft:light[level=15]
setblock 165 264 241 minecraft:orange_concrete
setblock 165 264 252 minecraft:light[level=15]
setblock 165 264 256 minecraft:orange_concrete
setblock 165 264 259 minecraft:light[level=15]
setblock 165 264 266 minecraft:light[level=15]
setblock 166 264 229 minecraft:blue_wool
setblock 166 264 256 minecraft:orange_terracotta
setblock 166 264 269 minecraft:magenta_wool
setblock 167 264 229 minecraft:gray_wool
setblock 167 264 256 minecraft:orange_concrete
fill 168 264 243 168 264 244 minecraft:black_concrete
setblock 168 264 255 minecraft:black_concrete
setblock 169 264 229 minecraft:purple_wool
setblock 169 264 269 minecraft:white_wool
setblock 170 264 249 minecraft:black_concrete
setblock 170 264 269 minecraft:yellow_wool
setblock 171 264 269 minecraft:cyan_wool
setblock 172 264 231 minecraft:light[level=15]
setblock 172 264 238 minecraft:light[level=15]
setblock 172 264 245 minecraft:light[level=15]
setblock 172 264 252 minecraft:light[level=15]
setblock 172 264 259 minecraft:light[level=15]
setblock 172 264 266 minecraft:light[level=15]
setblock 172 264 269 minecraft:red_wool
setblock 173 264 229 minecraft:cyan_wool
setblock 173 264 269 minecraft:white_wool
setblock 174 264 269 minecraft:gray_wool
setblock 175 264 229 minecraft:purple_wool
setblock 176 264 229 minecraft:lime_wool
setblock 176 264 269 minecraft:light_blue_wool
setblock 178 264 229 minecraft:gray_wool
setblock 178 264 269 minecraft:lime_wool
setblock 179 264 231 minecraft:light[level=15]
setblock 179 264 238 minecraft:light[level=15]
setblock 179 264 245 minecraft:light[level=15]
setblock 179 264 252 minecraft:light[level=15]
setblock 179 264 259 minecraft:light[level=15]
setblock 179 264 266 minecraft:light[level=15]
setblock 179 264 269 minecraft:red_wool
setblock 180 264 269 minecraft:lime_wool
fill 181 264 229 182 264 229 minecraft:red_wool
setblock 181 264 269 minecraft:yellow_wool
setblock 182 264 230 minecraft:lime_wool
setblock 182 264 232 minecraft:light_blue_wool
setblock 182 264 233 minecraft:yellow_wool
setblock 182 264 234 minecraft:cyan_wool
setblock 182 264 240 minecraft:light_blue_wool
setblock 182 264 245 minecraft:magenta_wool
setblock 182 264 247 minecraft:gray_wool
setblock 182 264 249 minecraft:magenta_wool
setblock 182 264 252 minecraft:red_wool
setblock 182 264 254 minecraft:lime_wool
setblock 182 264 256 minecraft:orange_wool
setblock 182 264 257 minecraft:cyan_wool
setblock 182 264 258 minecraft:orange_wool
setblock 182 264 259 minecraft:cyan_wool
setblock 182 264 260 minecraft:black_wool
setblock 182 264 261 minecraft:lime_wool
setblock 182 264 262 minecraft:gray_wool
setblock 182 264 263 minecraft:cyan_wool
setblock 182 264 265 minecraft:blue_wool
setblock 182 264 267 minecraft:red_wool
setblock 182 264 268 minecraft:black_wool
setblock 142 265 230 minecraft:pink_terracotta
setblock 142 265 231 minecraft:orange_terracotta
setblock 142 265 234 minecraft:orange_terracotta
setblock 142 265 236 minecraft:brown_terracotta
setblock 142 265 238 minecraft:brown_concrete
setblock 142 265 240 minecraft:white_terracotta
setblock 142 265 250 minecraft:white_terracotta
setblock 142 265 251 minecraft:yellow_terracotta
fill 142 265 252 142 265 253 minecraft:brown_terracotta
setblock 142 265 258 minecraft:brown_concrete
setblock 142 265 260 minecraft:brown_concrete
setblock 142 265 261 minecraft:orange_terracotta
setblock 142 265 262 minecraft:pink_terracotta
setblock 142 265 263 minecraft:brown_terracotta
setblock 142 265 266 minecraft:yellow_terracotta
setblock 142 265 268 minecraft:yellow_terracotta
setblock 142 265 269 minecraft:orange_terracotta
setblock 144 265 229 minecraft:brown_terracotta
setblock 147 265 229 minecraft:orange_terracotta
setblock 148 265 229 minecraft:brown_terracotta
setblock 149 265 229 minecraft:pink_terracotta
setblock 151 265 229 minecraft:yellow_terracotta
setblock 151 265 269 minecraft:orange_terracotta
setblock 152 265 269 minecraft:brown_terracotta
setblock 153 265 229 minecraft:orange_terracotta
setblock 153 265 269 minecraft:white_terracotta
setblock 155 265 229 minecraft:brown_terracotta
setblock 155 265 269 minecraft:white_terracotta
setblock 156 265 229 minecraft:yellow_terracotta
fill 156 265 245 157 265 245 minecraft:black_concrete
setblock 157 265 229 minecraft:pink_terracotta
setblock 157 265 254 minecraft:orange_concrete
setblock 158 265 243 minecraft:orange_terracotta
setblock 158 265 254 minecraft:orange_terracotta
fill 159 265 243 161 265 243 minecraft:orange_concrete
fill 159 265 246 159 265 248 minecraft:glowstone
setblock 160 265 229 minecraft:brown_terracotta
fill 160 265 245 160 265 246 minecraft:glowstone
fill 160 265 248 160 265 249 minecraft:glowstone
setblock 160 265 269 minecraft:brown_concrete
setblock 161 265 229 minecraft:orange_terracotta
fill 161 265 244 161 265 245 minecraft:glowstone
fill 161 265 249 161 265 250 minecraft:glowstone
setblock 161 265 255 minecraft:orange_concrete
setblock 161 265 269 minecraft:yellow_terracotta
fill 162 265 242 162 265 243 minecraft:black_concrete
fill 162 265 244 163 265 244 minecraft:glowstone
fill 162 265 250 163 265 250 minecraft:glowstone
fill 162 265 255 162 265 256 minecraft:black_concrete
setblock 162 265 269 minecraft:brown_concrete
setblock 163 265 242 minecraft:orange_terracotta
fill 163 265 243 164 265 243 minecraft:orange_concrete
fill 163 265 245 164 265 245 minecraft:glowstone
fill 163 265 249 164 265 249 minecraft:glowstone
fill 163 265 255 163 265 256 minecraft:orange_concrete
setblock 163 265 269 minecraft:white_terracotta
setblock 164 265 242 minecraft:orange_concrete
fill 164 265 246 165 265 246 minecraft:glowstone
fill 164 265 248 165 265 248 minecraft:glowstone
setblock 164 265 255 minecraft:orange_terracotta
setblock 164 265 256 minecraft:orange_concrete
setblock 165 265 247 minecraft:glowstone
setblock 166 265 229 minecraft:white_terracotta
setblock 166 265 243 minecraft:orange_concrete
setblock 166 265 269 minecraft:brown_concrete
setblock 167 265 229 minecraft:yellow_terracotta
fill 167 265 245 168 265 245 minecraft:black_concrete
fill 168 265 249 169 265 249 minecraft:black_concrete
setblock 169 265 229 minecraft:pink_terracotta
setblock 169 265 269 minecraft:orange_terracotta
fill 170 265 269 171 265 269 minecraft:yellow_terracotta
setblock 172 265 269 minecraft:brown_concrete
setblock 173 265 229 minecraft:brown_terracotta
fill 173 265 269 174 265 269 minecraft:white_terracotta
setblock 176 265 229 minecraft:brown_terracotta
setblock 176 265 269 minecraft:white_terracotta
setblock 178 265 269 minecraft:white_terracotta
setblock 181 265 229 minecraft:pink_terracotta
setblock 181 265 269 minecraft:orange_terracotta
fill 182 265 229 182 265 230 minecraft:yellow_terracotta
setblock 182 265 232 minecraft:brown_concrete
setblock 182 265 233 minecraft:orange_terracotta
setblock 182 265 240 minecraft:yellow_terracotta
setblock 182 265 245 minecraft:orange_terracotta
setblock 182 265 247 minecraft:brown_concrete
setblock 182 265 249 minecraft:brown_terracotta
setblock 182 265 252 minecraft:orange_terracotta
setblock 182 265 254 minecraft:pink_terracotta
setblock 182 265 256 minecraft:orange_terracotta
setblock 182 265 257 minecraft:brown_concrete
setblock 182 265 258 minecraft:yellow_terracotta
setblock 182 265 259 minecraft:brown_terracotta
setblock 182 265 260 minecraft:brown_concrete
setblock 182 265 261 minecraft:yellow_terracotta
fill 182 265 262 182 265 263 minecraft:pink_terracotta
fill 182 265 267 182 265 268 minecraft:brown_concrete
fill 142 266 229 142 269 232 minecraft:light_blue_stained_glass
fill 142 266 233 142 269 233 minecraft:sea_lantern
fill 142 266 234 142 269 238 minecraft:light_blue_stained_glass
fill 142 266 239 142 269 239 minecraft:sea_lantern
fill 142 266 240 142 269 244 minecraft:light_blue_stained_glass
fill 142 266 245 142 269 245 minecraft:sea_lantern
fill 142 266 246 142 269 250 minecraft:light_blue_stained_glass
fill 142 266 251 142 269 251 minecraft:sea_lantern
fill 142 266 252 142 269 256 minecraft:light_blue_stained_glass
fill 142 266 257 142 269 257 minecraft:sea_lantern
fill 142 266 258 142 269 262 minecraft:light_blue_stained_glass
fill 142 266 263 142 269 263 minecraft:sea_lantern
fill 142 266 264 142 269 268 minecraft:light_blue_stained_glass
fill 142 266 269 142 269 269 minecraft:sea_lantern
fill 143 266 229 145 269 229 minecraft:light_blue_stained_glass
fill 143 266 269 147 269 269 minecraft:light_blue_stained_glass
fill 146 266 229 146 269 229 minecraft:sea_lantern
fill 147 266 229 151 269 229 minecraft:light_blue_stained_glass
fill 148 266 269 148 269 269 minecraft:sea_lantern
fill 149 266 269 153 269 269 minecraft:light_blue_stained_glass
fill 152 266 229 152 269 229 minecraft:sea_lantern
fill 153 266 229 157 269 229 minecraft:light_blue_stained_glass
fill 154 266 269 154 269 269 minecraft:sea_lantern
fill 155 266 269 159 269 269 minecraft:light_blue_stained_glass
fill 157 266 246 157 266 252 minecraft:black_concrete
fill 158 266 229 158 269 229 minecraft:sea_lantern
setblock 158 266 246 minecraft:orange_terracotta
setblock 158 266 248 minecraft:orange_concrete
setblock 158 266 249 minecraft:black_concrete
fill 158 266 250 158 266 252 minecraft:orange_concrete
fill 159 266 229 163 269 229 minecraft:light_blue_stained_glass
fill 159 266 246 159 266 248 minecraft:black_concrete
fill 159 266 249 159 266 251 minecraft:orange_concrete
fill 160 266 245 160 266 246 minecraft:black_concrete
fill 160 266 248 160 267 249 minecraft:black_concrete
fill 160 266 269 160 269 269 minecraft:sea_lantern
fill 161 266 244 161 266 245 minecraft:black_concrete
fill 161 266 249 161 267 250 minecraft:black_concrete
fill 161 266 269 165 269 269 minecraft:light_blue_stained_glass
fill 162 266 244 163 266 244 minecraft:black_concrete
fill 162 266 250 163 267 250 minecraft:black_concrete
fill 162 266 253 162 266 254 minecraft:black_concrete
fill 163 266 245 164 266 245 minecraft:black_concrete
fill 163 266 249 164 267 249 minecraft:black_concrete
fill 163 266 251 165 266 253 minecraft:orange_concrete
fill 164 266 229 164 269 229 minecraft:sea_lantern
fill 164 266 246 165 266 246 minecraft:black_concrete
fill 164 266 248 165 267 248 minecraft:black_concrete
fill 164 266 250 166 266 250 minecraft:orange_concrete
fill 164 266 254 165 266 254 minecraft:orange_concrete
fill 165 266 229 169 269 229 minecraft:light_blue_stained_glass
setblock 165 266 247 minecraft:black_concrete
setblock 165 266 249 minecraft:orange_concrete
setblock 166 266 251 minecraft:orange_terracotta
fill 166 266 252 166 266 253 minecraft:orange_concrete
fill 166 266 269 166 269 269 minecraft:sea_lantern
fill 167 266 246 167 266 248 minecraft:black_concrete
fill 167 266 250 167 266 252 minecraft:black_concrete
fill 167 266 269 171 269 269 minecraft:light_blue_stained_glass
fill 170 266 229 170 269 229 minecraft:sea_lantern
fill 171 266 229 175 269 229 minecraft:light_blue_stained_glass
fill 172 266 269 172 269 269 minecraft:sea_lantern
fill 173 266 269 177 269 269 minecraft:light_blue_stained_glass
fill 176 266 229 176 269 229 minecraft:sea_lantern
fill 177 266 229 181 269 229 minecraft:light_blue_stained_glass
fill 178 266 269 178 269 269 minecraft:sea_lantern
fill 179 266 269 182 269 269 minecraft:light_blue_stained_glass
fill 182 266 229 182 269 229 minecraft:sea_lantern
fill 182 266 230 182 269 234 minecraft:light_blue_stained_glass
fill 182 266 235 182 269 235 minecraft:sea_lantern
fill 182 266 236 182 269 240 minecraft:light_blue_stained_glass
fill 182 266 241 182 269 241 minecraft:sea_lantern
fill 182 266 242 182 269 246 minecraft:light_blue_stained_glass
fill 182 266 247 182 269 247 minecraft:sea_lantern
fill 182 266 248 182 269 252 minecraft:light_blue_stained_glass
fill 182 266 253 182 269 253 minecraft:sea_lantern
fill 182 266 254 182 269 258 minecraft:light_blue_stained_glass
fill 182 266 259 182 269 259 minecraft:sea_lantern
fill 182 266 260 182 269 264 minecraft:light_blue_stained_glass
fill 182 266 265 182 269 265 minecraft:sea_lantern
fill 182 266 266 182 269 268 minecraft:light_blue_stained_glass
fill 159 267 248 159 267 249 minecraft:black_concrete
setblock 159 267 250 minecraft:orange_concrete
fill 162 267 251 162 267 252 minecraft:black_concrete
fill 163 267 251 163 267 252 minecraft:orange_concrete
setblock 164 267 250 minecraft:orange_terracotta
setblock 164 267 251 minecraft:orange_concrete
setblock 165 267 249 minecraft:black_concrete
setblock 165 267 250 minecraft:orange_concrete
fill 142 270 229 143 270 269 minecraft:gray_concrete
fill 144 270 229 182 270 230 minecraft:gray_concrete
setblock 144 270 231 minecraft:light[level=15]
setblock 144 270 238 minecraft:light[level=15]
setblock 144 270 245 minecraft:light[level=15]
setblock 144 270 252 minecraft:light[level=15]
setblock 144 270 259 minecraft:light[level=15]
setblock 144 270 266 minecraft:light[level=15]
fill 144 270 268 182 270 269 minecraft:gray_concrete
setblock 151 270 231 minecraft:light[level=15]
setblock 151 270 238 minecraft:light[level=15]
setblock 151 270 245 minecraft:light[level=15]
setblock 151 270 252 minecraft:light[level=15]
setblock 151 270 259 minecraft:light[level=15]
setblock 151 270 266 minecraft:light[level=15]
setblock 158 270 231 minecraft:light[level=15]
setblock 158 270 238 minecraft:light[level=15]
setblock 158 270 245 minecraft:light[level=15]
setblock 158 270 252 minecraft:light[level=15]
setblock 158 270 259 minecraft:light[level=15]
setblock 158 270 266 minecraft:light[level=15]
setblock 165 270 231 minecraft:light[level=15]
setblock 165 270 238 minecraft:light[level=15]
setblock 165 270 245 minecraft:light[level=15]
setblock 165 270 252 minecraft:light[level=15]
setblock 165 270 259 minecraft:light[level=15]
setblock 165 270 266 minecraft:light[level=15]
setblock 172 270 231 minecraft:light[level=15]
setblock 172 270 238 minecraft:light[level=15]
setblock 172 270 245 minecraft:light[level=15]
setblock 172 270 252 minecraft:light[level=15]
setblock 172 270 259 minecraft:light[level=15]
setblock 172 270 266 minecraft:light[level=15]
setblock 179 270 231 minecraft:light[level=15]
setblock 179 270 238 minecraft:light[level=15]
setblock 179 270 245 minecraft:light[level=15]
setblock 179 270 252 minecraft:light[level=15]
setblock 179 270 259 minecraft:light[level=15]
setblock 179 270 266 minecraft:light[level=15]
fill 181 270 231 182 270 267 minecraft:gray_concrete
setblock 144 276 231 minecraft:light[level=15]
setblock 144 276 238 minecraft:light[level=15]
setblock 144 276 245 minecraft:light[level=15]
setblock 144 276 252 minecraft:light[level=15]
setblock 144 276 259 minecraft:light[level=15]
setblock 144 276 266 minecraft:light[level=15]
setblock 151 276 231 minecraft:light[level=15]
setblock 151 276 238 minecraft:light[level=15]
setblock 151 276 245 minecraft:light[level=15]
setblock 151 276 252 minecraft:light[level=15]
setblock 151 276 259 minecraft:light[level=15]
setblock 151 276 266 minecraft:light[level=15]
fill 156 276 243 156 285 243 minecraft:sea_lantern
fill 156 276 244 156 276 254 minecraft:gold_block
fill 156 276 255 156 285 255 minecraft:sea_lantern
fill 157 276 243 167 276 243 minecraft:gold_block
fill 157 276 244 157 285 254 minecraft:black_concrete
fill 157 276 255 167 276 255 minecraft:gold_block
setblock 158 276 231 minecraft:light[level=15]
setblock 158 276 238 minecraft:light[level=15]
fill 158 276 244 161 285 244 minecraft:black_concrete
setblock 158 276 245 minecraft:light[level=15]
setblock 158 276 252 minecraft:light[level=15]
fill 158 276 254 167 285 254 minecraft:black_concrete
setblock 158 276 259 minecraft:light[level=15]
setblock 158 276 266 minecraft:light[level=15]
fill 160 276 246 160 276 248 minecraft:shroomlight
fill 161 276 245 161 276 246 minecraft:shroomlight
fill 161 276 248 161 276 249 minecraft:shroomlight
fill 162 276 244 162 276 245 minecraft:shroomlight
fill 162 276 249 162 276 250 minecraft:shroomlight
fill 163 276 244 164 276 244 minecraft:shroomlight
fill 163 276 250 164 276 250 minecraft:shroomlight
fill 164 276 245 165 276 245 minecraft:shroomlight
fill 164 276 249 165 276 249 minecraft:shroomlight
setblock 165 276 231 minecraft:light[level=15]
setblock 165 276 238 minecraft:light[level=15]
fill 165 276 244 167 285 244 minecraft:black_concrete
fill 165 276 246 166 276 246 minecraft:shroomlight
fill 165 276 248 166 276 248 minecraft:shroomlight
setblock 165 276 252 minecraft:light[level=15]
setblock 165 276 259 minecraft:light[level=15]
setblock 165 276 266 minecraft:light[level=15]
setblock 166 276 247 minecraft:shroomlight
fill 167 276 245 167 285 253 minecraft:black_concrete
fill 168 276 243 168 285 243 minecraft:sea_lantern
fill 168 276 244 168 276 254 minecraft:gold_block
fill 168 276 255 168 285 255 minecraft:sea_lantern
setblock 172 276 231 minecraft:light[level=15]
setblock 172 276 238 minecraft:light[level=15]
setblock 172 276 245 minecraft:light[level=15]
setblock 172 276 252 minecraft:light[level=15]
setblock 172 276 259 minecraft:light[level=15]
setblock 172 276 266 minecraft:light[level=15]
setblock 179 276 231 minecraft:light[level=15]
setblock 179 276 238 minecraft:light[level=15]
setblock 179 276 245 minecraft:light[level=15]
setblock 179 276 252 minecraft:light[level=15]
setblock 179 276 259 minecraft:light[level=15]
setblock 179 276 266 minecraft:light[level=15]
fill 156 277 244 156 277 254 minecraft:blue_concrete
fill 157 277 243 167 277 243 minecraft:blue_concrete
fill 157 277 255 167 277 255 minecraft:blue_concrete
fill 160 277 246 160 278 248 minecraft:glass
fill 161 277 245 161 278 246 minecraft:glass
fill 161 277 248 161 278 249 minecraft:glass
fill 162 277 244 162 278 245 minecraft:glass
fill 162 277 249 162 278 250 minecraft:glass
fill 163 277 244 164 278 244 minecraft:glass
fill 163 277 250 164 278 250 minecraft:glass
fill 164 277 245 165 278 245 minecraft:glass
fill 164 277 249 165 278 249 minecraft:glass
fill 165 277 246 166 278 246 minecraft:glass
fill 165 277 248 166 278 248 minecraft:glass
fill 166 277 247 166 278 247 minecraft:glass
fill 168 277 244 168 277 254 minecraft:blue_concrete
fill 156 278 244 156 278 246 minecraft:black_concrete
fill 156 278 247 156 278 248 minecraft:ochre_froglight
fill 156 278 249 156 279 251 minecraft:black_concrete
fill 156 278 252 156 282 252 minecraft:ochre_froglight
fill 156 278 253 156 283 254 minecraft:black_concrete
fill 157 278 243 158 283 243 minecraft:black_concrete
fill 157 278 255 158 283 255 minecraft:black_concrete
fill 159 278 243 161 278 243 minecraft:ochre_froglight
fill 159 278 255 161 278 255 minecraft:ochre_froglight
fill 162 278 243 162 283 243 minecraft:black_concrete
fill 162 278 255 163 281 255 minecraft:black_concrete
fill 163 278 243 165 278 243 minecraft:ochre_froglight
fill 164 278 255 164 280 255 minecraft:ochre_froglight
fill 165 278 255 167 280 255 minecraft:black_concrete
fill 166 278 243 167 283 243 minecraft:black_concrete
fill 168 278 244 168 283 245 minecraft:black_concrete
fill 168 278 246 168 282 246 minecraft:ochre_froglight
fill 168 278 247 168 279 249 minecraft:black_concrete
fill 168 278 250 168 278 252 minecraft:ochre_froglight
fill 168 278 253 168 283 254 minecraft:black_concrete
fill 156 279 244 156 283 245 minecraft:black_concrete
fill 156 279 246 156 279 247 minecraft:ochre_froglight
setblock 156 279 248 minecraft:black_concrete
fill 159 279 243 159 282 243 minecraft:ochre_froglight
fill 159 279 255 159 282 255 minecraft:ochre_froglight
setblock 160 279 243 minecraft:black_concrete
fill 160 279 246 160 279 248 minecraft:shroomlight
setblock 160 279 255 minecraft:black_concrete
fill 161 279 243 161 282 243 minecraft:ochre_froglight
fill 161 279 245 161 279 246 minecraft:shroomlight
fill 161 279 248 161 279 249 minecraft:shroomlight
fill 161 279 255 161 282 255 minecraft:ochre_froglight
fill 162 279 244 162 279 245 minecraft:shroomlight
fill 162 279 249 162 279 250 minecraft:shroomlight
fill 163 279 243 163 282 243 minecraft:ochre_froglight
fill 163 279 244 164 279 244 minecraft:shroomlight
fill 163 279 250 164 279 250 minecraft:shroomlight
setblock 164 279 243 minecraft:black_concrete
fill 164 279 245 165 279 245 minecraft:shroomlight
fill 164 279 249 165 279 249 minecraft:shroomlight
fill 165 279 243 165 282 243 minecraft:ochre_froglight
fill 165 279 246 166 279 246 minecraft:shroomlight
fill 165 279 248 166 279 248 minecraft:shroomlight
setblock 166 279 247 minecraft:shroomlight
fill 168 279 250 168 279 251 minecraft:black_concrete
setblock 168 279 252 minecraft:ochre_froglight
fill 156 280 246 156 281 246 minecraft:ochre_froglight
fill 156 280 247 156 281 247 minecraft:black_concrete
fill 156 280 248 156 281 248 minecraft:ochre_froglight
fill 156 280 249 156 283 249 minecraft:black_concrete
fill 156 280 250 156 280 251 minecraft:ochre_froglight
setblock 160 280 243 minecraft:ochre_froglight
fill 160 280 246 160 281 248 minecraft:glass
setblock 160 280 255 minecraft:ochre_froglight
fill 161 280 245 161 281 246 minecraft:glass
fill 161 280 248 161 281 249 minecraft:glass
fill 162 280 244 162 281 245 minecraft:glass
fill 162 280 249 162 281 250 minecraft:glass
fill 163 280 244 164 281 244 minecraft:glass
fill 163 280 250 164 281 250 minecraft:glass
setblock 164 280 243 minecraft:ochre_froglight
fill 164 280 245 165 281 245 minecraft:glass
fill 164 280 249 165 281 249 minecraft:glass
fill 165 280 246 166 281 246 minecraft:glass
fill 165 280 248 166 281 248 minecraft:glass
fill 166 280 247 166 281 247 minecraft:glass
fill 168 280 247 168 280 248 minecraft:ochre_froglight
fill 168 280 249 168 280 250 minecraft:black_concrete
setblock 168 280 251 minecraft:ochre_froglight
fill 168 280 252 168 281 252 minecraft:black_concrete
fill 156 281 250 156 282 250 minecraft:ochre_froglight
fill 156 281 251 156 283 251 minecraft:black_concrete
setblock 160 281 243 minecraft:black_concrete
setblock 160 281 255 minecraft:black_concrete
setblock 164 281 243 minecraft:black_concrete
setblock 164 281 255 minecraft:black_concrete
fill 165 281 255 165 282 255 minecraft:ochre_froglight
fill 166 281 255 167 283 255 minecraft:black_concrete
fill 168 281 247 168 283 247 minecraft:black_concrete
fill 168 281 248 168 282 248 minecraft:ochre_froglight
fill 168 281 249 168 283 249 minecraft:black_concrete
setblock 168 281 250 minecraft:ochre_froglight
setblock 168 281 251 minecraft:black_concrete
setblock 144 282 231 minecraft:light[level=15]
setblock 144 282 238 minecraft:light[level=15]
setblock 144 282 245 minecraft:light[level=15]
setblock 144 282 252 minecraft:light[level=15]
setblock 144 282 259 minecraft:light[level=15]
setblock 144 282 266 minecraft:light[level=15]
setblock 151 282 231 minecraft:light[level=15]
setblock 151 282 238 minecraft:light[level=15]
setblock 151 282 245 minecraft:light[level=15]
setblock 151 282 252 minecraft:light[level=15]
setblock 151 282 259 minecraft:light[level=15]
setblock 151 282 266 minecraft:light[level=15]
fill 156 282 246 156 283 246 minecraft:black_concrete
setblock 156 282 247 minecraft:ochre_froglight
fill 156 282 248 156 283 248 minecraft:black_concrete
setblock 158 282 231 minecraft:light[level=15]
setblock 158 282 238 minecraft:light[level=15]
setblock 158 282 245 minecraft:light[level=15]
setblock 158 282 252 minecraft:light[level=15]
setblock 158 282 259 minecraft:light[level=15]
setblock 158 282 266 minecraft:light[level=15]
setblock 160 282 243 minecraft:ochre_froglight
fill 160 282 246 160 282 248 minecraft:shroomlight
setblock 160 282 255 minecraft:ochre_froglight
fill 161 282 245 161 282 246 minecraft:shroomlight
fill 161 282 248 161 282 249 minecraft:shroomlight
fill 162 282 244 162 282 245 minecraft:shroomlight
fill 162 282 249 162 282 250 minecraft:shroomlight
fill 162 282 255 162 283 255 minecraft:black_concrete
fill 163 282 244 164 282 244 minecraft:shroomlight
fill 163 282 250 164 282 250 minecraft:shroomlight
fill 163 282 255 164 282 255 minecraft:ochre_froglight
setblock 164 282 243 minecraft:ochre_froglight
fill 164 282 245 165 282 245 minecraft:shroomlight
fill 164 282 249 165 282 249 minecraft:shroomlight
setblock 165 282 231 minecraft:light[level=15]
setblock 165 282 238 minecraft:light[level=15]
fill 165 282 246 166 282 246 minecraft:shroomlight
fill 165 282 248 166 282 248 minecraft:shroomlight
setblock 165 282 252 minecraft:light[level=15]
setblock 165 282 259 minecraft:light[level=15]
setblock 165 282 266 minecraft:light[level=15]
setblock 166 282 247 minecraft:shroomlight
fill 168 282 250 168 283 250 minecraft:black_concrete
fill 168 282 251 168 282 252 minecraft:ochre_froglight
setblock 172 282 231 minecraft:light[level=15]
setblock 172 282 238 minecraft:light[level=15]
setblock 172 282 245 minecraft:light[level=15]
schedule function dropper:buildpart/51_2 1t
