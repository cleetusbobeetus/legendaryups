fill 500 145 503 500 148 503 minecraft:red_terracotta
setblock 503 145 464 minecraft:terracotta
setblock 503 145 504 minecraft:terracotta
fill 504 145 464 504 148 464 minecraft:red_terracotta
setblock 504 145 503 minecraft:terracotta
fill 504 145 504 504 148 504 minecraft:red_terracotta
setblock 505 145 502 minecraft:terracotta
fill 505 145 503 505 148 503 minecraft:red_terracotta
setblock 506 145 501 minecraft:terracotta
fill 506 145 502 506 148 502 minecraft:red_terracotta
fill 507 145 501 507 148 501 minecraft:red_terracotta
setblock 508 145 464 minecraft:terracotta
setblock 508 145 500 minecraft:red_terracotta
setblock 508 145 504 minecraft:terracotta
fill 509 145 464 509 148 464 minecraft:red_terracotta
setblock 509 145 498 minecraft:terracotta
fill 509 145 499 509 148 499 minecraft:red_terracotta
setblock 509 145 503 minecraft:terracotta
fill 509 145 504 509 148 504 minecraft:red_terracotta
setblock 510 145 482 minecraft:terracotta
fill 510 145 483 510 148 483 minecraft:red_terracotta
setblock 510 145 486 minecraft:red_terracotta
setblock 510 145 497 minecraft:terracotta
fill 510 145 498 510 148 498 minecraft:red_terracotta
setblock 510 145 502 minecraft:terracotta
fill 510 145 503 510 148 503 minecraft:red_terracotta
setblock 511 145 476 minecraft:terracotta
fill 511 145 477 511 146 477 minecraft:red_terracotta
setblock 511 145 481 minecraft:terracotta
fill 511 145 482 511 148 482 minecraft:red_terracotta
setblock 511 145 486 minecraft:terracotta
fill 511 145 487 511 148 487 minecraft:red_terracotta
setblock 511 145 491 minecraft:terracotta
fill 511 145 492 511 148 492 minecraft:red_terracotta
setblock 511 145 496 minecraft:terracotta
fill 511 145 497 511 148 497 minecraft:red_terracotta
setblock 511 145 501 minecraft:terracotta
fill 511 145 502 511 148 502 minecraft:red_terracotta
setblock 471 146 475 minecraft:terracotta
fill 471 146 476 471 149 476 minecraft:red_terracotta
setblock 471 146 480 minecraft:terracotta
fill 471 146 481 471 149 481 minecraft:red_terracotta
setblock 471 146 485 minecraft:terracotta
fill 471 146 486 471 149 486 minecraft:red_terracotta
setblock 471 146 490 minecraft:terracotta
fill 471 146 491 471 149 491 minecraft:red_terracotta
setblock 471 146 495 minecraft:terracotta
setblock 471 146 496 minecraft:red_terracotta
setblock 471 146 500 minecraft:terracotta
fill 471 146 501 471 149 501 minecraft:red_terracotta
setblock 472 146 479 minecraft:terracotta
fill 472 146 480 472 149 480 minecraft:red_terracotta
setblock 472 146 484 minecraft:terracotta
fill 472 146 485 472 149 485 minecraft:red_terracotta
setblock 472 146 504 minecraft:terracotta
setblock 482 146 464 minecraft:terracotta
setblock 482 146 504 minecraft:terracotta
fill 483 146 464 483 149 464 minecraft:red_terracotta
fill 483 146 504 483 149 504 minecraft:red_terracotta
fill 484 146 465 484 147 465 minecraft:red_terracotta
setblock 486 146 465 minecraft:terracotta
setblock 487 146 464 minecraft:terracotta
fill 487 146 465 487 149 465 minecraft:red_terracotta
setblock 487 146 504 minecraft:terracotta
fill 488 146 464 488 149 464 minecraft:red_terracotta
setblock 488 146 503 minecraft:terracotta
fill 488 146 504 488 149 504 minecraft:red_terracotta
fill 489 146 503 489 149 503 minecraft:red_terracotta
setblock 491 146 465 minecraft:terracotta
setblock 492 146 464 minecraft:terracotta
fill 492 146 465 492 149 465 minecraft:red_terracotta
setblock 492 146 504 minecraft:terracotta
fill 493 146 464 493 149 464 minecraft:red_terracotta
setblock 493 146 503 minecraft:terracotta
fill 493 146 504 496 146 504 minecraft:red_terracotta
setblock 496 146 464 minecraft:red_terracotta
setblock 497 146 464 minecraft:terracotta
fill 497 146 471 499 147 471 minecraft:magma_block
setblock 497 146 504 minecraft:terracotta
fill 498 146 464 498 149 464 minecraft:red_terracotta
fill 498 146 470 498 147 470 minecraft:magma_block
fill 498 146 504 498 149 504 minecraft:red_terracotta
fill 499 146 503 499 149 503 minecraft:red_terracotta
setblock 502 146 464 minecraft:terracotta
fill 502 146 502 502 147 502 minecraft:red_terracotta
setblock 502 146 504 minecraft:terracotta
fill 503 146 464 503 149 464 minecraft:red_terracotta
setblock 503 146 503 minecraft:terracotta
fill 503 146 504 503 149 504 minecraft:red_terracotta
setblock 504 146 502 minecraft:terracotta
fill 504 146 503 504 149 503 minecraft:red_terracotta
fill 505 146 502 505 149 502 minecraft:red_terracotta
fill 506 146 501 506 149 501 minecraft:red_terracotta
setblock 507 146 464 minecraft:terracotta
setblock 507 146 504 minecraft:terracotta
fill 508 146 464 508 149 464 minecraft:red_terracotta
setblock 508 146 503 minecraft:terracotta
fill 508 146 504 508 149 504 minecraft:red_terracotta
setblock 509 146 498 minecraft:red_terracotta
setblock 509 146 502 minecraft:terracotta
fill 509 146 503 509 149 503 minecraft:red_terracotta
setblock 510 146 481 minecraft:terracotta
fill 510 146 482 510 149 482 minecraft:red_terracotta
setblock 510 146 486 minecraft:terracotta
fill 510 146 487 510 149 487 minecraft:red_terracotta
setblock 510 146 496 minecraft:terracotta
fill 510 146 497 510 149 497 minecraft:red_terracotta
setblock 510 146 501 minecraft:terracotta
fill 510 146 502 510 149 502 minecraft:red_terracotta
setblock 511 146 480 minecraft:terracotta
fill 511 146 481 511 149 481 minecraft:red_terracotta
setblock 511 146 485 minecraft:terracotta
fill 511 146 486 511 149 486 minecraft:red_terracotta
setblock 511 146 490 minecraft:terracotta
fill 511 146 491 511 149 491 minecraft:red_terracotta
setblock 511 146 495 minecraft:terracotta
fill 511 146 496 511 149 496 minecraft:red_terracotta
setblock 511 146 500 minecraft:terracotta
fill 511 146 501 511 149 501 minecraft:red_terracotta
setblock 471 147 479 minecraft:terracotta
fill 471 147 480 471 150 480 minecraft:red_terracotta
setblock 471 147 484 minecraft:terracotta
fill 471 147 485 471 150 485 minecraft:red_terracotta
setblock 471 147 489 minecraft:terracotta
fill 471 147 490 471 150 490 minecraft:red_terracotta
setblock 471 147 499 minecraft:terracotta
fill 471 147 500 471 148 500 minecraft:red_terracotta
setblock 471 147 504 minecraft:terracotta
setblock 472 147 478 minecraft:terracotta
fill 472 147 479 472 150 479 minecraft:red_terracotta
setblock 472 147 483 minecraft:terracotta
fill 472 147 484 472 150 484 minecraft:red_terracotta
setblock 472 147 487 minecraft:red_terracotta
fill 472 147 504 472 149 504 minecraft:red_terracotta
setblock 480 147 464 minecraft:red_terracotta
setblock 481 147 464 minecraft:terracotta
setblock 481 147 504 minecraft:terracotta
fill 482 147 464 482 150 464 minecraft:red_terracotta
fill 482 147 504 482 150 504 minecraft:red_terracotta
fill 483 147 465 483 148 465 minecraft:red_terracotta
fill 484 147 503 484 149 503 minecraft:red_terracotta
setblock 485 147 465 minecraft:terracotta
setblock 486 147 464 minecraft:terracotta
fill 486 147 465 486 150 465 minecraft:red_terracotta
setblock 486 147 504 minecraft:terracotta
fill 487 147 464 487 150 464 minecraft:red_terracotta
fill 487 147 466 488 147 466 minecraft:red_terracotta
setblock 487 147 503 minecraft:terracotta
fill 487 147 504 487 150 504 minecraft:red_terracotta
fill 488 147 503 488 150 503 minecraft:red_terracotta
setblock 490 147 465 minecraft:terracotta
setblock 491 147 464 minecraft:terracotta
fill 491 147 465 491 150 465 minecraft:red_terracotta
setblock 491 147 504 minecraft:terracotta
fill 492 147 464 492 150 464 minecraft:red_terracotta
setblock 492 147 503 minecraft:terracotta
fill 492 147 504 495 147 504 minecraft:red_terracotta
fill 493 147 503 493 150 503 minecraft:red_terracotta
setblock 496 147 464 minecraft:terracotta
setblock 496 147 504 minecraft:terracotta
fill 497 147 464 497 150 464 minecraft:red_terracotta
fill 497 147 504 497 150 504 minecraft:red_terracotta
fill 498 147 503 498 150 503 minecraft:red_terracotta
setblock 501 147 464 minecraft:terracotta
fill 501 147 502 501 148 502 minecraft:red_terracotta
setblock 501 147 504 minecraft:terracotta
fill 502 147 464 502 150 464 minecraft:red_terracotta
setblock 502 147 503 minecraft:terracotta
fill 502 147 504 502 150 504 minecraft:red_terracotta
setblock 503 147 502 minecraft:terracotta
fill 503 147 503 503 150 503 minecraft:red_terracotta
setblock 504 147 465 minecraft:red_terracotta
fill 504 147 502 504 150 502 minecraft:red_terracotta
setblock 505 147 465 minecraft:terracotta
fill 505 147 501 505 150 501 minecraft:red_terracotta
setblock 506 147 464 minecraft:terracotta
fill 506 147 465 507 149 465 minecraft:red_terracotta
setblock 506 147 504 minecraft:terracotta
fill 507 147 464 507 150 464 minecraft:red_terracotta
setblock 507 147 503 minecraft:terracotta
fill 507 147 504 507 150 504 minecraft:red_terracotta
setblock 508 147 502 minecraft:terracotta
fill 508 147 503 508 150 503 minecraft:red_terracotta
setblock 509 147 501 minecraft:terracotta
fill 509 147 502 509 150 502 minecraft:red_terracotta
setblock 510 147 480 minecraft:terracotta
fill 510 147 481 510 150 481 minecraft:red_terracotta
setblock 510 147 485 minecraft:terracotta
fill 510 147 486 510 150 486 minecraft:red_terracotta
fill 510 147 488 510 148 488 minecraft:red_terracotta
setblock 510 147 496 minecraft:red_terracotta
setblock 510 147 500 minecraft:terracotta
fill 510 147 501 510 150 501 minecraft:red_terracotta
setblock 511 147 464 minecraft:terracotta
setblock 511 147 479 minecraft:terracotta
fill 511 147 480 511 150 480 minecraft:red_terracotta
setblock 511 147 484 minecraft:terracotta
fill 511 147 485 511 150 485 minecraft:red_terracotta
setblock 511 147 489 minecraft:terracotta
fill 511 147 490 511 150 490 minecraft:red_terracotta
setblock 511 147 494 minecraft:terracotta
fill 511 147 495 511 150 495 minecraft:red_terracotta
setblock 511 147 499 minecraft:terracotta
fill 511 147 500 511 150 500 minecraft:red_terracotta
setblock 511 147 504 minecraft:terracotta
setblock 471 148 478 minecraft:terracotta
fill 471 148 479 471 151 479 minecraft:red_terracotta
setblock 471 148 483 minecraft:terracotta
fill 471 148 484 471 151 484 minecraft:red_terracotta
setblock 471 148 488 minecraft:terracotta
fill 471 148 489 471 151 489 minecraft:red_terracotta
setblock 471 148 499 minecraft:red_terracotta
setblock 471 148 503 minecraft:terracotta
fill 471 148 504 471 151 504 minecraft:red_terracotta
setblock 472 148 482 minecraft:terracotta
fill 472 148 483 472 151 483 minecraft:red_terracotta
setblock 472 148 487 minecraft:terracotta
setblock 479 148 464 minecraft:red_terracotta
setblock 480 148 464 minecraft:terracotta
setblock 480 148 504 minecraft:terracotta
fill 481 148 464 481 150 465 minecraft:red_terracotta
fill 481 148 504 481 151 504 minecraft:red_terracotta
fill 482 148 465 482 149 465 minecraft:red_terracotta
fill 483 148 503 483 150 503 minecraft:red_terracotta
setblock 484 148 465 minecraft:terracotta
fill 484 148 466 487 148 466 minecraft:red_terracotta
setblock 485 148 464 minecraft:terracotta
fill 485 148 465 485 151 465 minecraft:red_terracotta
setblock 485 148 504 minecraft:terracotta
fill 486 148 464 486 151 464 minecraft:red_terracotta
setblock 486 148 503 minecraft:terracotta
fill 486 148 504 486 151 504 minecraft:red_terracotta
fill 487 148 503 487 151 503 minecraft:red_terracotta
setblock 488 148 466 minecraft:terracotta
setblock 489 148 465 minecraft:terracotta
fill 489 148 466 489 151 466 minecraft:red_terracotta
setblock 490 148 464 minecraft:terracotta
fill 490 148 465 490 151 465 minecraft:red_terracotta
setblock 490 148 504 minecraft:terracotta
fill 491 148 464 491 151 464 minecraft:red_terracotta
setblock 491 148 503 minecraft:terracotta
fill 491 148 504 494 148 504 minecraft:red_terracotta
fill 492 148 503 492 151 503 minecraft:red_terracotta
setblock 493 148 465 minecraft:red_terracotta
fill 494 148 503 495 148 503 minecraft:red_terracotta
setblock 495 148 464 minecraft:terracotta
setblock 495 148 504 minecraft:terracotta
fill 496 148 464 496 151 464 minecraft:red_terracotta
setblock 496 148 503 minecraft:terracotta
fill 496 148 504 496 151 504 minecraft:red_terracotta
fill 497 148 503 497 151 503 minecraft:red_terracotta
setblock 499 148 464 minecraft:red_terracotta
setblock 500 148 464 minecraft:terracotta
setblock 500 148 504 minecraft:terracotta
fill 501 148 464 501 150 465 minecraft:red_terracotta
setblock 501 148 503 minecraft:terracotta
fill 501 148 504 501 151 504 minecraft:red_terracotta
fill 502 148 465 503 148 465 minecraft:red_terracotta
setblock 502 148 502 minecraft:terracotta
fill 502 148 503 502 151 503 minecraft:red_terracotta
fill 503 148 502 503 151 502 minecraft:red_terracotta
setblock 504 148 465 minecraft:terracotta
setblock 505 148 464 minecraft:terracotta
fill 505 148 465 505 151 465 minecraft:red_terracotta
setblock 505 148 504 minecraft:terracotta
fill 506 148 464 506 151 464 minecraft:red_terracotta
setblock 506 148 503 minecraft:terracotta
fill 506 148 504 506 151 504 minecraft:red_terracotta
setblock 507 148 502 minecraft:terracotta
fill 507 148 503 507 151 503 minecraft:red_terracotta
setblock 508 148 465 minecraft:red_terracotta
fill 508 148 502 508 151 502 minecraft:red_terracotta
fill 509 148 483 509 148 484 minecraft:red_terracotta
setblock 509 148 485 minecraft:terracotta
setblock 509 148 500 minecraft:terracotta
fill 509 148 501 509 150 501 minecraft:red_terracotta
setblock 510 148 464 minecraft:terracotta
fill 510 148 480 510 150 480 minecraft:red_terracotta
setblock 510 148 484 minecraft:terracotta
fill 510 148 485 510 151 485 minecraft:red_terracotta
setblock 510 148 489 minecraft:terracotta
fill 510 148 490 510 151 490 minecraft:red_terracotta
setblock 510 148 499 minecraft:terracotta
fill 510 148 500 510 151 500 minecraft:red_terracotta
setblock 510 148 504 minecraft:terracotta
fill 511 148 464 511 151 464 minecraft:red_terracotta
setblock 511 148 478 minecraft:terracotta
fill 511 148 479 511 151 479 minecraft:red_terracotta
setblock 511 148 483 minecraft:terracotta
fill 511 148 484 511 151 484 minecraft:red_terracotta
setblock 511 148 488 minecraft:terracotta
fill 511 148 489 511 151 489 minecraft:red_terracotta
setblock 511 148 493 minecraft:terracotta
fill 511 148 494 511 151 494 minecraft:red_terracotta
setblock 511 148 498 minecraft:terracotta
fill 511 148 499 511 151 499 minecraft:red_terracotta
setblock 511 148 503 minecraft:terracotta
fill 511 148 504 511 151 504 minecraft:red_terracotta
fill 471 149 464 471 151 464 minecraft:red_terracotta
setblock 471 149 477 minecraft:terracotta
fill 471 149 478 471 152 478 minecraft:red_terracotta
setblock 471 149 482 minecraft:terracotta
fill 471 149 483 471 152 483 minecraft:red_terracotta
setblock 471 149 487 minecraft:terracotta
fill 471 149 488 472 151 488 minecraft:red_terracotta
setblock 471 149 502 minecraft:terracotta
fill 471 149 503 471 150 503 minecraft:red_terracotta
setblock 472 149 481 minecraft:terracotta
fill 472 149 482 472 152 482 minecraft:red_terracotta
setblock 472 149 486 minecraft:terracotta
fill 472 149 487 472 152 487 minecraft:red_terracotta
setblock 473 149 466 minecraft:light[level=14]
setblock 473 149 474 minecraft:light[level=14]
setblock 473 149 482 minecraft:light[level=14]
setblock 473 149 490 minecraft:light[level=14]
setblock 473 149 498 minecraft:light[level=14]
fill 477 149 464 478 149 464 minecraft:red_terracotta
fill 478 149 472 479 150 472 minecraft:orange_concrete
setblock 479 149 464 minecraft:terracotta
setblock 479 149 504 minecraft:terracotta
fill 480 149 464 480 151 465 minecraft:red_terracotta
fill 480 149 504 480 152 504 minecraft:red_terracotta
setblock 481 149 466 minecraft:light[level=14]
setblock 481 149 474 minecraft:light[level=14]
setblock 481 149 482 minecraft:light[level=14]
setblock 481 149 490 minecraft:light[level=14]
setblock 481 149 498 minecraft:light[level=14]
setblock 482 149 466 minecraft:terracotta
fill 482 149 503 482 151 503 minecraft:red_terracotta
setblock 483 149 465 minecraft:terracotta
fill 483 149 466 486 149 466 minecraft:red_terracotta
setblock 484 149 464 minecraft:terracotta
fill 484 149 465 484 152 465 minecraft:red_terracotta
setblock 484 149 504 minecraft:terracotta
fill 485 149 464 485 152 464 minecraft:red_terracotta
setblock 485 149 503 minecraft:terracotta
fill 485 149 504 485 152 504 minecraft:red_terracotta
fill 486 149 503 486 152 503 minecraft:red_terracotta
setblock 487 149 466 minecraft:terracotta
setblock 488 149 465 minecraft:terracotta
fill 488 149 466 488 152 466 minecraft:red_terracotta
setblock 489 149 464 minecraft:terracotta
fill 489 149 465 489 152 465 minecraft:red_terracotta
setblock 489 149 474 minecraft:light[level=14]
setblock 489 149 482 minecraft:light[level=14]
setblock 489 149 490 minecraft:light[level=14]
setblock 489 149 498 minecraft:light[level=14]
setblock 489 149 504 minecraft:terracotta
fill 490 149 464 490 152 464 minecraft:red_terracotta
fill 490 149 466 490 150 466 minecraft:red_terracotta
setblock 490 149 503 minecraft:terracotta
fill 490 149 504 493 149 504 minecraft:red_terracotta
fill 491 149 503 491 152 503 minecraft:red_terracotta
setblock 493 149 465 minecraft:terracotta
setblock 494 149 464 minecraft:terracotta
fill 494 149 465 494 152 465 minecraft:red_terracotta
setblock 494 149 503 minecraft:red_terracotta
setblock 494 149 504 minecraft:terracotta
fill 495 149 464 495 152 464 minecraft:red_terracotta
setblock 495 149 503 minecraft:terracotta
fill 495 149 504 495 152 504 minecraft:red_terracotta
fill 496 149 503 496 152 503 minecraft:red_terracotta
setblock 497 149 466 minecraft:light[level=14]
setblock 497 149 474 minecraft:light[level=14]
setblock 497 149 482 minecraft:light[level=14]
setblock 497 149 490 minecraft:light[level=14]
setblock 497 149 498 minecraft:light[level=14]
setblock 498 149 465 minecraft:terracotta
setblock 499 149 464 minecraft:terracotta
fill 499 149 465 500 151 465 minecraft:red_terracotta
setblock 499 149 504 minecraft:terracotta
fill 500 149 464 500 152 464 minecraft:red_terracotta
setblock 500 149 502 minecraft:red_terracotta
setblock 500 149 503 minecraft:terracotta
fill 500 149 504 500 152 504 minecraft:red_terracotta
setblock 501 149 502 minecraft:terracotta
fill 501 149 503 501 152 503 minecraft:red_terracotta
setblock 502 149 465 minecraft:red_terracotta
fill 502 149 502 502 152 502 minecraft:red_terracotta
setblock 503 149 465 minecraft:terracotta
setblock 504 149 464 minecraft:terracotta
fill 504 149 465 504 152 465 minecraft:red_terracotta
fill 504 149 501 504 151 501 minecraft:red_terracotta
setblock 504 149 504 minecraft:terracotta
fill 505 149 464 505 152 464 minecraft:red_terracotta
setblock 505 149 466 minecraft:light[level=14]
setblock 505 149 474 minecraft:light[level=14]
setblock 505 149 482 minecraft:light[level=14]
setblock 505 149 490 minecraft:light[level=14]
setblock 505 149 498 minecraft:light[level=14]
setblock 505 149 503 minecraft:terracotta
fill 505 149 504 505 152 504 minecraft:red_terracotta
setblock 506 149 502 minecraft:terracotta
fill 506 149 503 506 152 503 minecraft:red_terracotta
fill 507 149 502 507 152 502 minecraft:red_terracotta
setblock 508 149 465 minecraft:terracotta
setblock 509 149 464 minecraft:terracotta
setblock 509 149 483 minecraft:red_terracotta
setblock 509 149 484 minecraft:terracotta
fill 509 149 485 509 150 487 minecraft:red_terracotta
setblock 509 149 500 minecraft:red_terracotta
setblock 509 149 504 minecraft:terracotta
fill 510 149 464 510 152 464 minecraft:red_terracotta
setblock 510 149 483 minecraft:terracotta
fill 510 149 484 510 152 484 minecraft:red_terracotta
setblock 510 149 488 minecraft:terracotta
fill 510 149 489 510 152 489 minecraft:red_terracotta
fill 510 149 491 510 150 491 minecraft:red_terracotta
setblock 510 149 498 minecraft:terracotta
fill 510 149 499 510 150 499 minecraft:red_terracotta
setblock 510 149 503 minecraft:terracotta
fill 510 149 504 510 152 504 minecraft:red_terracotta
fill 511 149 465 511 150 465 minecraft:red_terracotta
setblock 511 149 478 minecraft:red_terracotta
setblock 511 149 482 minecraft:terracotta
fill 511 149 483 511 152 483 minecraft:red_terracotta
setblock 511 149 487 minecraft:terracotta
fill 511 149 488 511 152 488 minecraft:red_terracotta
setblock 511 149 492 minecraft:terracotta
fill 511 149 493 511 152 493 minecraft:red_terracotta
setblock 511 149 497 minecraft:terracotta
fill 511 149 498 511 152 498 minecraft:red_terracotta
setblock 511 149 502 minecraft:terracotta
fill 511 149 503 511 152 503 minecraft:red_terracotta
setblock 471 150 465 minecraft:red_terracotta
setblock 471 150 466 minecraft:terracotta
setblock 471 150 476 minecraft:terracotta
fill 471 150 477 471 153 477 minecraft:red_terracotta
setblock 471 150 481 minecraft:terracotta
fill 471 150 482 471 153 482 minecraft:red_terracotta
setblock 471 150 486 minecraft:terracotta
fill 471 150 487 471 153 487 minecraft:red_terracotta
setblock 471 150 491 minecraft:terracotta
fill 471 150 492 471 153 492 minecraft:red_terracotta
setblock 471 150 502 minecraft:red_terracotta
setblock 472 150 464 minecraft:red_terracotta
setblock 472 150 480 minecraft:terracotta
fill 472 150 481 472 153 481 minecraft:red_terracotta
setblock 472 150 485 minecraft:terracotta
fill 472 150 486 472 153 486 minecraft:red_terracotta
setblock 473 150 464 minecraft:terracotta
fill 474 150 464 477 150 464 minecraft:red_terracotta
setblock 478 150 464 minecraft:terracotta
fill 478 150 465 479 152 465 minecraft:red_terracotta
setblock 478 150 504 minecraft:terracotta
fill 479 150 464 479 153 464 minecraft:red_terracotta
fill 479 150 504 479 153 504 minecraft:red_terracotta
setblock 481 150 466 minecraft:terracotta
fill 481 150 503 481 152 503 minecraft:red_terracotta
setblock 482 150 465 minecraft:terracotta
fill 482 150 466 485 150 466 minecraft:red_terracotta
setblock 483 150 464 minecraft:terracotta
fill 483 150 465 483 153 465 minecraft:red_terracotta
setblock 483 150 504 minecraft:terracotta
fill 484 150 464 484 153 464 minecraft:red_terracotta
setblock 484 150 467 minecraft:red_terracotta
setblock 484 150 503 minecraft:terracotta
fill 484 150 504 484 153 504 minecraft:red_terracotta
setblock 485 150 467 minecraft:terracotta
fill 485 150 503 485 153 503 minecraft:red_terracotta
setblock 486 150 466 minecraft:terracotta
fill 486 150 467 486 153 467 minecraft:red_terracotta
setblock 487 150 465 minecraft:terracotta
fill 487 150 466 487 153 466 minecraft:red_terracotta
setblock 488 150 464 minecraft:terracotta
fill 488 150 465 488 153 465 minecraft:red_terracotta
setblock 488 150 504 minecraft:terracotta
fill 489 150 464 489 153 464 minecraft:red_terracotta
setblock 489 150 503 minecraft:terracotta
fill 489 150 504 492 150 504 minecraft:red_terracotta
fill 490 150 503 490 153 503 minecraft:red_terracotta
setblock 492 150 465 minecraft:terracotta
setblock 493 150 464 minecraft:terracotta
fill 493 150 465 493 153 465 minecraft:red_terracotta
setblock 493 150 504 minecraft:terracotta
fill 494 150 464 494 153 464 minecraft:red_terracotta
setblock 494 150 503 minecraft:terracotta
fill 494 150 504 494 153 504 minecraft:red_terracotta
fill 495 150 465 496 150 465 minecraft:red_terracotta
fill 495 150 503 495 153 503 minecraft:red_terracotta
setblock 497 150 465 minecraft:terracotta
setblock 498 150 464 minecraft:terracotta
fill 498 150 465 498 153 465 minecraft:red_terracotta
setblock 498 150 504 minecraft:terracotta
fill 499 150 464 499 153 464 minecraft:red_terracotta
setblock 499 150 502 minecraft:red_terracotta
setblock 499 150 503 minecraft:terracotta
fill 499 150 504 499 153 504 minecraft:red_terracotta
setblock 500 150 502 minecraft:terracotta
fill 500 150 503 500 153 503 minecraft:red_terracotta
fill 501 150 502 501 153 502 minecraft:red_terracotta
setblock 502 150 465 minecraft:terracotta
setblock 503 150 464 minecraft:terracotta
fill 503 150 465 503 153 465 minecraft:red_terracotta
fill 503 150 501 503 151 501 minecraft:red_terracotta
setblock 503 150 504 minecraft:terracotta
fill 504 150 464 504 153 464 minecraft:red_terracotta
setblock 504 150 503 minecraft:terracotta
fill 504 150 504 504 153 504 minecraft:red_terracotta
setblock 505 150 502 minecraft:terracotta
fill 505 150 503 505 153 503 minecraft:red_terracotta
setblock 506 150 465 minecraft:red_terracotta
fill 506 150 480 508 160 482 minecraft:terracotta
setblock 506 150 501 minecraft:terracotta
fill 506 150 502 506 153 502 minecraft:red_terracotta
setblock 507 150 465 minecraft:terracotta
setblock 508 150 464 minecraft:terracotta
fill 508 150 465 509 152 465 minecraft:red_terracotta
setblock 508 150 504 minecraft:terracotta
fill 509 150 464 509 153 464 minecraft:red_terracotta
fill 509 150 480 509 160 481 minecraft:terracotta
setblock 509 150 482 minecraft:red_terracotta
setblock 509 150 483 minecraft:terracotta
fill 509 150 484 509 153 484 minecraft:red_terracotta
setblock 509 150 488 minecraft:terracotta
fill 509 150 489 509 153 489 minecraft:red_terracotta
setblock 509 150 503 minecraft:terracotta
fill 509 150 504 509 153 504 minecraft:red_terracotta
setblock 510 150 482 minecraft:terracotta
fill 510 150 483 510 153 483 minecraft:red_terracotta
setblock 510 150 487 minecraft:terracotta
fill 510 150 488 510 153 488 minecraft:red_terracotta
setblock 510 150 492 minecraft:terracotta
setblock 510 150 498 minecraft:red_terracotta
setblock 510 150 502 minecraft:terracotta
fill 510 150 503 510 152 503 minecraft:red_terracotta
setblock 511 150 481 minecraft:terracotta
fill 511 150 482 511 153 482 minecraft:red_terracotta
setblock 511 150 486 minecraft:terracotta
fill 511 150 487 511 153 487 minecraft:red_terracotta
setblock 511 150 491 minecraft:terracotta
fill 511 150 492 511 153 492 minecraft:red_terracotta
setblock 511 150 496 minecraft:terracotta
fill 511 150 497 511 152 497 minecraft:red_terracotta
setblock 511 150 501 minecraft:terracotta
fill 511 150 502 511 153 502 minecraft:red_terracotta
setblock 471 151 465 minecraft:terracotta
fill 471 151 466 471 152 468 minecraft:red_terracotta
fill 471 151 476 471 152 476 minecraft:red_terracotta
setblock 471 151 480 minecraft:terracotta
fill 471 151 481 471 154 481 minecraft:red_terracotta
setblock 471 151 485 minecraft:terracotta
fill 471 151 486 471 154 486 minecraft:red_terracotta
setblock 471 151 490 minecraft:terracotta
fill 471 151 491 471 154 491 minecraft:red_terracotta
setblock 472 151 464 minecraft:terracotta
fill 472 151 480 472 152 480 minecraft:red_terracotta
setblock 472 151 484 minecraft:terracotta
fill 472 151 485 473 152 485 minecraft:red_terracotta
setblock 472 151 489 minecraft:terracotta
fill 473 151 464 476 151 464 minecraft:red_terracotta
fill 473 151 484 473 152 484 minecraft:red_terracotta
setblock 477 151 464 minecraft:terracotta
fill 477 151 465 477 154 465 minecraft:red_terracotta
setblock 477 151 504 minecraft:terracotta
fill 478 151 464 478 154 464 minecraft:red_terracotta
fill 478 151 504 478 154 504 minecraft:red_terracotta
setblock 479 151 466 minecraft:red_terracotta
setblock 480 151 466 minecraft:terracotta
setblock 481 151 464 minecraft:red_terracotta
setblock 481 151 465 minecraft:terracotta
fill 481 151 466 484 151 466 minecraft:red_terracotta
setblock 482 151 464 minecraft:terracotta
fill 482 151 465 482 154 465 minecraft:red_terracotta
fill 482 151 467 483 151 467 minecraft:red_terracotta
setblock 482 151 504 minecraft:terracotta
fill 483 151 464 483 154 464 minecraft:red_terracotta
setblock 483 151 503 minecraft:terracotta
fill 483 151 504 483 154 504 minecraft:red_terracotta
setblock 484 151 467 minecraft:terracotta
fill 484 151 503 484 154 503 minecraft:red_terracotta
setblock 485 151 466 minecraft:terracotta
fill 485 151 467 485 154 467 minecraft:red_terracotta
setblock 486 151 465 minecraft:terracotta
fill 486 151 466 486 154 466 minecraft:red_terracotta
setblock 487 151 464 minecraft:terracotta
fill 487 151 465 487 154 465 minecraft:red_terracotta
fill 487 151 467 487 152 467 minecraft:red_terracotta
setblock 487 151 504 minecraft:terracotta
fill 488 151 464 488 154 464 minecraft:red_terracotta
setblock 488 151 503 minecraft:terracotta
fill 488 151 504 491 151 504 minecraft:red_terracotta
fill 489 151 503 489 154 503 minecraft:red_terracotta
setblock 490 151 466 minecraft:terracotta
setblock 491 151 465 minecraft:terracotta
fill 491 151 466 491 154 466 minecraft:red_terracotta
setblock 492 151 464 minecraft:terracotta
fill 492 151 465 492 154 465 minecraft:red_terracotta
setblock 492 151 504 minecraft:terracotta
fill 493 151 464 493 154 464 minecraft:red_terracotta
setblock 493 151 503 minecraft:terracotta
fill 493 151 504 493 154 504 minecraft:red_terracotta
fill 494 151 503 494 154 503 minecraft:red_terracotta
setblock 495 151 465 minecraft:red_terracotta
setblock 496 151 465 minecraft:terracotta
setblock 497 151 464 minecraft:terracotta
fill 497 151 465 497 154 465 minecraft:red_terracotta
setblock 497 151 504 minecraft:terracotta
fill 498 151 464 498 154 464 minecraft:red_terracotta
setblock 498 151 503 minecraft:terracotta
fill 498 151 504 498 154 504 minecraft:red_terracotta
setblock 499 151 502 minecraft:terracotta
fill 499 151 503 499 154 503 minecraft:red_terracotta
fill 500 151 502 500 154 502 minecraft:red_terracotta
setblock 501 151 464 minecraft:red_terracotta
setblock 501 151 465 minecraft:terracotta
fill 501 151 466 504 151 466 minecraft:red_terracotta
setblock 502 151 464 minecraft:terracotta
fill 502 151 465 502 154 465 minecraft:red_terracotta
setblock 502 151 504 minecraft:terracotta
fill 503 151 464 503 154 464 minecraft:red_terracotta
setblock 503 151 503 minecraft:terracotta
fill 503 151 504 503 154 504 minecraft:red_terracotta
setblock 504 151 502 minecraft:terracotta
fill 504 151 503 504 154 503 minecraft:red_terracotta
setblock 505 151 466 minecraft:terracotta
setblock 505 151 501 minecraft:terracotta
fill 505 151 502 505 154 502 minecraft:red_terracotta
setblock 506 151 465 minecraft:terracotta
setblock 507 151 464 minecraft:terracotta
fill 507 151 465 507 154 465 minecraft:red_terracotta
setblock 507 151 504 minecraft:terracotta
fill 508 151 464 508 154 464 minecraft:red_terracotta
setblock 508 151 503 minecraft:terracotta
fill 508 151 504 508 154 504 minecraft:red_terracotta
fill 509 151 482 509 160 482 minecraft:terracotta
fill 509 151 483 509 153 483 minecraft:red_terracotta
fill 509 151 485 509 151 486 minecraft:red_terracotta
setblock 509 151 487 minecraft:terracotta
fill 509 151 488 509 154 488 minecraft:red_terracotta
fill 509 151 490 509 152 490 minecraft:red_terracotta
fill 509 151 503 509 153 503 minecraft:red_terracotta
setblock 510 151 481 minecraft:terracotta
fill 510 151 482 510 154 482 minecraft:red_terracotta
setblock 510 151 486 minecraft:terracotta
fill 510 151 487 510 154 487 minecraft:red_terracotta
setblock 510 151 491 minecraft:terracotta
fill 510 151 492 510 153 493 minecraft:red_terracotta
setblock 510 151 501 minecraft:terracotta
fill 510 151 502 510 152 502 minecraft:red_terracotta
setblock 511 151 465 minecraft:terracotta
fill 511 151 466 511 154 466 minecraft:red_terracotta
setblock 511 151 480 minecraft:terracotta
fill 511 151 481 511 154 481 minecraft:red_terracotta
setblock 511 151 485 minecraft:terracotta
fill 511 151 486 511 154 486 minecraft:red_terracotta
setblock 511 151 490 minecraft:terracotta
fill 511 151 491 511 154 491 minecraft:red_terracotta
setblock 511 151 495 minecraft:terracotta
fill 511 151 496 511 153 496 minecraft:red_terracotta
setblock 511 151 500 minecraft:terracotta
fill 511 151 501 511 153 501 minecraft:red_terracotta
fill 470 152 474 470 155 475 minecraft:brown_terracotta
setblock 470 152 476 minecraft:red_terracotta
fill 470 152 477 470 155 482 minecraft:brown_terracotta
fill 470 152 484 470 153 484 minecraft:red_terracotta
fill 470 152 485 470 152 490 minecraft:brown_terracotta
fill 470 152 496 470 157 496 minecraft:brown_terracotta
fill 470 152 497 470 152 498 minecraft:red_terracotta
fill 470 152 499 470 155 501 minecraft:brown_terracotta
fill 470 152 503 470 155 503 minecraft:brown_terracotta
setblock 470 152 504 minecraft:red_terracotta
setblock 471 152 464 minecraft:terracotta
fill 471 152 465 471 155 465 minecraft:red_terracotta
setblock 471 152 469 minecraft:terracotta
fill 471 152 470 471 155 470 minecraft:red_terracotta
setblock 471 152 479 minecraft:terracotta
fill 471 152 480 471 155 480 minecraft:red_terracotta
setblock 471 152 484 minecraft:terracotta
fill 471 152 485 471 155 485 minecraft:red_terracotta
setblock 471 152 488 minecraft:red_terracotta
setblock 471 152 489 minecraft:terracotta
fill 471 152 490 471 155 490 minecraft:red_terracotta
fill 472 152 464 475 152 464 minecraft:red_terracotta
setblock 472 152 483 minecraft:terracotta
fill 472 152 484 472 155 484 minecraft:red_terracotta
setblock 472 152 488 minecraft:terracotta
fill 472 152 489 472 155 489 minecraft:red_terracotta
setblock 472 152 505 minecraft:red_terracotta
fill 476 152 463 476 153 463 minecraft:red_terracotta
setblock 476 152 464 minecraft:terracotta
fill 476 152 465 476 155 465 minecraft:red_terracotta
fill 477 152 463 478 152 463 minecraft:brown_terracotta
fill 477 152 464 477 155 464 minecraft:red_terracotta
fill 477 152 504 477 155 504 minecraft:red_terracotta
setblock 478 152 466 minecraft:red_terracotta
setblock 479 152 466 minecraft:terracotta
setblock 480 152 464 minecraft:red_terracotta
setblock 480 152 465 minecraft:terracotta
fill 480 152 466 483 152 466 minecraft:red_terracotta
fill 480 152 503 480 153 503 minecraft:red_terracotta
setblock 481 152 464 minecraft:terracotta
fill 481 152 465 481 155 465 minecraft:red_terracotta
fill 481 152 467 482 152 467 minecraft:red_terracotta
setblock 481 152 504 minecraft:terracotta
fill 482 152 464 482 155 464 minecraft:red_terracotta
setblock 482 152 503 minecraft:terracotta
fill 482 152 504 482 155 504 minecraft:red_terracotta
setblock 483 152 467 minecraft:terracotta
fill 483 152 503 483 155 503 minecraft:red_terracotta
setblock 484 152 466 minecraft:terracotta
fill 484 152 467 484 155 467 minecraft:red_terracotta
setblock 485 152 465 minecraft:terracotta
fill 485 152 466 485 155 466 minecraft:red_terracotta
setblock 485 152 505 minecraft:red_terracotta
setblock 486 152 464 minecraft:terracotta
fill 486 152 465 486 155 465 minecraft:red_terracotta
setblock 486 152 504 minecraft:terracotta
fill 486 152 505 492 152 505 minecraft:brown_terracotta
fill 487 152 464 487 155 464 minecraft:red_terracotta
setblock 487 152 503 minecraft:terracotta
fill 487 152 504 490 152 504 minecraft:red_terracotta
setblock 488 152 467 minecraft:terracotta
fill 488 152 503 488 154 503 minecraft:red_terracotta
setblock 489 152 466 minecraft:terracotta
setblock 490 152 465 minecraft:terracotta
fill 490 152 466 490 155 466 minecraft:red_terracotta
setblock 491 152 464 minecraft:terracotta
fill 491 152 465 491 155 465 minecraft:red_terracotta
setblock 491 152 504 minecraft:terracotta
fill 492 152 464 492 155 464 minecraft:red_terracotta
setblock 492 152 503 minecraft:terracotta
fill 492 152 504 492 155 504 minecraft:red_terracotta
fill 493 152 503 493 153 503 minecraft:red_terracotta
setblock 493 152 505 minecraft:red_terracotta
setblock 495 152 465 minecraft:terracotta
setblock 496 152 464 minecraft:terracotta
fill 496 152 465 496 155 465 minecraft:red_terracotta
setblock 496 152 504 minecraft:terracotta
fill 497 152 464 497 155 464 minecraft:red_terracotta
setblock 497 152 503 minecraft:terracotta
fill 497 152 504 497 155 504 minecraft:red_terracotta
fill 498 152 503 498 155 503 minecraft:red_terracotta
fill 499 152 463 504 153 463 minecraft:brown_terracotta
setblock 499 152 465 minecraft:red_terracotta
setblock 499 152 466 minecraft:terracotta
fill 499 152 502 499 155 502 minecraft:red_terracotta
setblock 500 152 465 minecraft:terracotta
fill 500 152 466 503 152 466 minecraft:red_terracotta
setblock 501 152 464 minecraft:terracotta
fill 501 152 465 501 155 465 minecraft:red_terracotta
setblock 501 152 504 minecraft:terracotta
fill 502 152 464 502 155 464 minecraft:red_terracotta
setblock 502 152 503 minecraft:terracotta
fill 502 152 504 502 155 504 minecraft:red_terracotta
setblock 503 152 502 minecraft:terracotta
fill 503 152 503 503 155 503 minecraft:red_terracotta
fill 503 152 505 503 155 505 minecraft:brown_terracotta
setblock 504 152 466 minecraft:terracotta
fill 504 152 502 504 155 502 minecraft:red_terracotta
setblock 504 152 505 minecraft:red_terracotta
setblock 505 152 463 minecraft:red_terracotta
setblock 505 152 465 minecraft:terracotta
fill 505 152 466 506 153 466 minecraft:red_terracotta
fill 505 152 505 509 155 505 minecraft:brown_terracotta
setblock 506 152 464 minecraft:terracotta
fill 506 152 465 506 155 465 minecraft:red_terracotta
setblock 506 152 504 minecraft:terracotta
fill 507 152 463 507 152 464 minecraft:red_terracotta
setblock 507 152 503 minecraft:terracotta
fill 507 152 504 507 155 504 minecraft:red_terracotta
fill 508 152 463 508 155 463 minecraft:brown_terracotta
setblock 508 152 486 minecraft:red_terracotta
setblock 508 152 487 minecraft:terracotta
fill 508 152 488 508 153 488 minecraft:red_terracotta
setblock 508 152 502 minecraft:terracotta
fill 508 152 503 508 154 503 minecraft:red_terracotta
setblock 509 152 485 minecraft:red_terracotta
setblock 509 152 486 minecraft:terracotta
fill 509 152 487 509 155 487 minecraft:red_terracotta
setblock 509 152 491 minecraft:terracotta
setblock 510 152 481 minecraft:red_terracotta
setblock 510 152 485 minecraft:terracotta
fill 510 152 486 510 155 486 minecraft:red_terracotta
setblock 510 152 490 minecraft:terracotta
fill 510 152 491 510 155 491 minecraft:red_terracotta
setblock 510 152 505 minecraft:red_terracotta
setblock 511 152 464 minecraft:terracotta
fill 511 152 465 511 154 465 minecraft:red_terracotta
fill 511 152 467 511 153 467 minecraft:red_terracotta
setblock 511 152 479 minecraft:terracotta
fill 511 152 480 512 152 480 minecraft:red_terracotta
setblock 511 152 484 minecraft:terracotta
fill 511 152 485 511 155 485 minecraft:red_terracotta
setblock 511 152 489 minecraft:terracotta
fill 511 152 490 511 155 490 minecraft:red_terracotta
setblock 511 152 494 minecraft:terracotta
fill 511 152 495 511 155 495 minecraft:red_terracotta
setblock 511 152 499 minecraft:terracotta
setblock 511 152 500 minecraft:red_terracotta
setblock 511 152 504 minecraft:terracotta
fill 511 152 505 512 152 505 minecraft:brown_terracotta
fill 512 152 475 512 155 476 minecraft:brown_terracotta
setblock 512 152 477 minecraft:red_terracotta
fill 512 152 478 512 155 478 minecraft:brown_terracotta
setblock 512 152 479 minecraft:red_terracotta
setblock 512 152 481 minecraft:red_terracotta
setblock 512 152 483 minecraft:red_terracotta
fill 512 152 484 512 153 487 minecraft:brown_terracotta
setblock 512 152 488 minecraft:red_terracotta
fill 512 152 489 512 153 491 minecraft:brown_terracotta
setblock 512 152 498 minecraft:red_terracotta
fill 512 152 499 512 155 499 minecraft:brown_terracotta
fill 470 153 464 474 153 464 minecraft:red_terracotta
fill 470 153 465 470 153 467 minecraft:brown_terracotta
fill 470 153 476 470 155 476 minecraft:brown_terracotta
fill 470 153 485 470 156 485 minecraft:brown_terracotta
setblock 470 153 486 minecraft:red_terracotta
fill 470 153 487 470 153 490 minecraft:brown_terracotta
fill 470 153 492 470 153 493 minecraft:brown_terracotta
fill 470 153 494 470 153 495 minecraft:red_terracotta
fill 470 153 497 470 155 498 minecraft:brown_terracotta
setblock 470 153 502 minecraft:red_terracotta
fill 470 153 504 470 155 504 minecraft:brown_terracotta
fill 471 153 466 471 153 467 minecraft:red_terracotta
setblock 471 153 468 minecraft:terracotta
fill 471 153 469 471 156 469 minecraft:red_terracotta
fill 471 153 471 471 154 471 minecraft:red_terracotta
setblock 471 153 478 minecraft:terracotta
fill 471 153 479 471 155 479 minecraft:red_terracotta
setblock 471 153 483 minecraft:terracotta
fill 471 153 484 471 156 484 minecraft:red_terracotta
setblock 471 153 488 minecraft:terracotta
fill 471 153 489 471 156 489 minecraft:red_terracotta
setblock 472 153 482 minecraft:terracotta
fill 472 153 483 472 155 483 minecraft:red_terracotta
fill 472 153 485 472 154 485 minecraft:red_terracotta
setblock 472 153 487 minecraft:terracotta
fill 472 153 488 472 156 488 minecraft:red_terracotta
fill 472 153 490 472 154 490 minecraft:red_terracotta
fill 472 153 505 472 155 505 minecraft:brown_terracotta
fill 474 153 505 474 155 505 minecraft:brown_terracotta
setblock 475 153 464 minecraft:terracotta
fill 475 153 465 475 156 465 minecraft:red_terracotta
fill 475 153 505 476 153 505 minecraft:red_terracotta
fill 476 153 464 476 156 464 minecraft:red_terracotta
fill 477 153 463 477 155 463 minecraft:brown_terracotta
setblock 477 153 466 minecraft:red_terracotta
fill 477 153 505 478 155 505 minecraft:brown_terracotta
setblock 478 153 463 minecraft:red_terracotta
setblock 478 153 465 minecraft:red_terracotta
setblock 478 153 466 minecraft:terracotta
setblock 479 153 465 minecraft:terracotta
fill 479 153 466 481 153 467 minecraft:red_terracotta
setblock 480 153 464 minecraft:terracotta
fill 480 153 465 480 156 465 minecraft:red_terracotta
setblock 480 153 504 minecraft:terracotta
fill 480 153 505 482 155 505 minecraft:brown_terracotta
fill 481 153 464 481 156 464 minecraft:red_terracotta
setblock 481 153 503 minecraft:terracotta
fill 481 153 504 481 156 504 minecraft:red_terracotta
setblock 482 153 466 minecraft:red_terracotta
setblock 482 153 467 minecraft:terracotta
fill 482 153 503 482 156 503 minecraft:red_terracotta
fill 483 153 463 486 153 463 minecraft:brown_terracotta
setblock 483 153 466 minecraft:terracotta
fill 483 153 467 483 156 467 minecraft:red_terracotta
setblock 483 153 505 minecraft:red_terracotta
setblock 484 153 465 minecraft:terracotta
fill 484 153 466 484 156 466 minecraft:red_terracotta
setblock 485 153 464 minecraft:terracotta
fill 485 153 465 485 156 465 minecraft:red_terracotta
setblock 485 153 504 minecraft:terracotta
fill 485 153 505 485 155 505 minecraft:brown_terracotta
fill 486 153 464 486 156 464 minecraft:red_terracotta
setblock 486 153 503 minecraft:terracotta
fill 486 153 504 486 153 505 minecraft:red_terracotta
setblock 487 153 463 minecraft:red_terracotta
setblock 487 153 467 minecraft:terracotta
fill 487 153 503 487 154 504 minecraft:red_terracotta
fill 487 153 505 487 155 505 minecraft:brown_terracotta
setblock 488 153 466 minecraft:terracotta
setblock 488 153 467 minecraft:red_terracotta
fill 488 153 504 488 153 505 minecraft:red_terracotta
setblock 489 153 463 minecraft:red_terracotta
setblock 489 153 465 minecraft:terracotta
fill 489 153 466 489 155 466 minecraft:red_terracotta
setblock 489 153 504 minecraft:red_terracotta
fill 489 153 505 493 155 505 minecraft:brown_terracotta
fill 490 153 463 493 155 463 minecraft:brown_terracotta
setblock 490 153 464 minecraft:terracotta
fill 490 153 465 490 156 465 minecraft:red_terracotta
setblock 490 153 504 minecraft:terracotta
fill 491 153 464 491 156 464 minecraft:red_terracotta
setblock 491 153 503 minecraft:terracotta
fill 491 153 504 491 156 504 minecraft:red_terracotta
setblock 492 153 503 minecraft:red_terracotta
setblock 494 153 463 minecraft:red_terracotta
setblock 494 153 465 minecraft:terracotta
setblock 494 153 505 minecraft:red_terracotta
fill 495 153 463 495 155 463 minecraft:brown_terracotta
setblock 495 153 464 minecraft:terracotta
fill 495 153 465 495 156 465 minecraft:red_terracotta
setblock 495 153 504 minecraft:terracotta
fill 495 153 505 498 155 505 minecraft:brown_terracotta
fill 496 153 463 496 153 464 minecraft:red_terracotta
setblock 496 153 503 minecraft:terracotta
fill 496 153 504 496 156 504 minecraft:red_terracotta
fill 497 153 463 497 155 463 minecraft:brown_terracotta
setblock 497 153 466 minecraft:red_terracotta
fill 497 153 503 497 156 503 minecraft:red_terracotta
setblock 498 153 466 minecraft:terracotta
setblock 498 153 502 minecraft:red_terracotta
setblock 499 153 465 minecraft:terracotta
fill 499 153 466 502 153 466 minecraft:red_terracotta
setblock 499 153 505 minecraft:red_terracotta
setblock 500 153 464 minecraft:terracotta
fill 500 153 465 500 156 465 minecraft:red_terracotta
setblock 500 153 504 minecraft:terracotta
fill 501 153 464 501 156 464 minecraft:red_terracotta
setblock 501 153 503 minecraft:terracotta
fill 501 153 504 501 156 504 minecraft:red_terracotta
setblock 502 153 502 minecraft:terracotta
fill 502 153 503 502 156 503 minecraft:red_terracotta
setblock 502 153 505 minecraft:red_terracotta
setblock 503 153 466 minecraft:terracotta
fill 503 153 502 503 155 502 minecraft:red_terracotta
setblock 504 153 465 minecraft:terracotta
fill 504 153 466 504 155 466 minecraft:red_terracotta
fill 504 153 505 504 155 505 minecraft:brown_terracotta
fill 505 153 463 505 155 463 minecraft:brown_terracotta
setblock 505 153 464 minecraft:terracotta
fill 505 153 465 505 156 465 minecraft:red_terracotta
setblock 505 153 504 minecraft:terracotta
fill 506 153 464 507 155 464 minecraft:red_terracotta
setblock 506 153 503 minecraft:terracotta
fill 506 153 504 506 156 504 minecraft:red_terracotta
fill 507 153 463 507 155 463 minecraft:brown_terracotta
setblock 507 153 502 minecraft:terracotta
fill 507 153 503 507 155 503 minecraft:red_terracotta
setblock 508 153 465 minecraft:red_terracotta
setblock 508 153 486 minecraft:terracotta
setblock 508 153 487 minecraft:red_terracotta
setblock 509 153 465 minecraft:terracotta
setblock 509 153 485 minecraft:terracotta
fill 509 153 486 509 155 486 minecraft:red_terracotta
setblock 509 153 490 minecraft:terracotta
fill 509 153 491 509 155 491 minecraft:red_terracotta
setblock 510 153 464 minecraft:terracotta
setblock 510 153 484 minecraft:terracotta
fill 510 153 485 510 156 485 minecraft:red_terracotta
setblock 510 153 489 minecraft:terracotta
fill 510 153 490 510 156 490 minecraft:red_terracotta
setblock 510 153 504 minecraft:terracotta
fill 510 153 505 511 155 505 minecraft:brown_terracotta
fill 511 153 464 511 154 464 minecraft:red_terracotta
fill 511 153 480 511 154 480 minecraft:red_terracotta
setblock 511 153 483 minecraft:terracotta
fill 511 153 484 511 156 484 minecraft:red_terracotta
setblock 511 153 488 minecraft:terracotta
fill 511 153 489 511 156 489 minecraft:red_terracotta
setblock 511 153 493 minecraft:terracotta
fill 511 153 494 511 156 494 minecraft:red_terracotta
setblock 511 153 503 minecraft:terracotta
fill 511 153 504 511 154 504 minecraft:red_terracotta
fill 512 153 467 512 154 467 minecraft:red_terracotta
fill 512 153 470 512 153 471 minecraft:brown_terracotta
setblock 512 153 472 minecraft:red_terracotta
fill 512 153 473 512 155 474 minecraft:brown_terracotta
fill 512 153 477 512 155 477 minecraft:brown_terracotta
fill 512 153 479 512 155 481 minecraft:brown_terracotta
fill 512 153 483 512 155 483 minecraft:brown_terracotta
fill 512 153 488 512 155 488 minecraft:brown_terracotta
fill 512 153 492 512 153 493 minecraft:red_terracotta
fill 512 153 494 512 155 495 minecraft:brown_terracotta
fill 512 153 498 512 155 498 minecraft:brown_terracotta
setblock 512 153 505 minecraft:red_terracotta
fill 470 154 464 470 155 464 minecraft:brown_terracotta
setblock 470 154 465 minecraft:red_terracotta
fill 470 154 466 470 155 467 minecraft:brown_terracotta
fill 470 154 484 470 155 484 minecraft:brown_terracotta
fill 470 154 486 470 155 489 minecraft:brown_terracotta
setblock 470 154 490 minecraft:red_terracotta
fill 470 154 492 470 155 492 minecraft:brown_terracotta
setblock 470 154 493 minecraft:red_terracotta
fill 470 154 494 470 155 494 minecraft:brown_terracotta
setblock 470 154 495 minecraft:red_terracotta
fill 470 154 502 470 155 502 minecraft:brown_terracotta
fill 471 154 464 473 154 464 minecraft:red_terracotta
setblock 471 154 466 minecraft:red_terracotta
setblock 471 154 467 minecraft:terracotta
fill 471 154 468 471 157 468 minecraft:red_terracotta
setblock 471 154 472 minecraft:terracotta
setblock 471 154 478 minecraft:red_terracotta
setblock 471 154 482 minecraft:terracotta
fill 471 154 483 471 157 483 minecraft:red_terracotta
setblock 471 154 487 minecraft:terracotta
fill 471 154 488 471 157 488 minecraft:red_terracotta
setblock 471 154 492 minecraft:terracotta
setblock 472 154 482 minecraft:red_terracotta
setblock 472 154 486 minecraft:terracotta
fill 472 154 487 472 156 487 minecraft:red_terracotta
setblock 474 154 464 minecraft:terracotta
fill 474 154 465 474 156 465 minecraft:red_terracotta
fill 475 154 464 475 157 464 minecraft:red_terracotta
fill 475 154 505 476 155 505 minecraft:brown_terracotta
fill 476 154 463 476 156 463 minecraft:brown_terracotta
setblock 477 154 466 minecraft:terracotta
fill 478 154 463 479 155 463 minecraft:brown_terracotta
setblock 478 154 465 minecraft:terracotta
fill 478 154 466 481 154 466 minecraft:red_terracotta
setblock 479 154 464 minecraft:terracotta
fill 479 154 465 479 157 465 minecraft:red_terracotta
fill 479 154 467 480 154 467 minecraft:red_terracotta
setblock 479 154 504 minecraft:terracotta
fill 480 154 463 480 154 464 minecraft:red_terracotta
setblock 480 154 503 minecraft:terracotta
fill 480 154 504 480 157 504 minecraft:red_terracotta
setblock 481 154 463 minecraft:red_terracotta
setblock 481 154 467 minecraft:terracotta
fill 481 154 503 481 155 503 minecraft:red_terracotta
fill 482 154 463 482 155 463 minecraft:brown_terracotta
setblock 482 154 466 minecraft:terracotta
fill 482 154 467 482 155 468 minecraft:red_terracotta
setblock 483 154 463 minecraft:red_terracotta
setblock 483 154 465 minecraft:terracotta
fill 483 154 466 483 157 466 minecraft:red_terracotta
setblock 483 154 468 minecraft:red_terracotta
fill 483 154 505 483 155 505 minecraft:brown_terracotta
fill 484 154 463 484 155 463 minecraft:brown_terracotta
setblock 484 154 464 minecraft:terracotta
fill 484 154 465 484 157 465 minecraft:red_terracotta
setblock 484 154 504 minecraft:terracotta
fill 485 154 463 485 154 464 minecraft:red_terracotta
setblock 485 154 503 minecraft:terracotta
fill 485 154 504 486 156 504 minecraft:red_terracotta
fill 486 154 463 487 155 463 minecraft:brown_terracotta
setblock 486 154 467 minecraft:terracotta
fill 486 154 503 486 155 503 minecraft:red_terracotta
fill 486 154 505 486 156 505 minecraft:brown_terracotta
setblock 487 154 466 minecraft:terracotta
fill 487 154 467 487 155 467 minecraft:red_terracotta
setblock 488 154 465 minecraft:terracotta
fill 488 154 466 488 156 466 minecraft:red_terracotta
setblock 488 154 504 minecraft:red_terracotta
fill 488 154 505 488 155 505 minecraft:brown_terracotta
fill 489 154 463 489 155 463 minecraft:brown_terracotta
setblock 489 154 464 minecraft:terracotta
fill 489 154 465 489 157 465 minecraft:red_terracotta
setblock 489 154 504 minecraft:terracotta
fill 490 154 464 490 157 464 minecraft:red_terracotta
fill 490 154 504 490 156 504 minecraft:red_terracotta
setblock 493 154 465 minecraft:terracotta
fill 494 154 463 494 155 463 minecraft:brown_terracotta
setblock 494 154 464 minecraft:terracotta
fill 494 154 465 494 157 465 minecraft:red_terracotta
setblock 494 154 504 minecraft:terracotta
fill 494 154 505 494 155 505 minecraft:brown_terracotta
fill 495 154 464 496 156 464 minecraft:red_terracotta
setblock 495 154 503 minecraft:terracotta
fill 495 154 504 495 157 504 minecraft:red_terracotta
fill 496 154 463 496 156 463 minecraft:brown_terracotta
fill 496 154 503 496 156 503 minecraft:red_terracotta
setblock 497 154 466 minecraft:terracotta
setblock 498 154 465 minecraft:terracotta
fill 498 154 466 501 154 466 minecraft:red_terracotta
fill 499 154 463 503 155 463 minecraft:brown_terracotta
setblock 499 154 464 minecraft:terracotta
fill 499 154 465 499 157 465 minecraft:red_terracotta
setblock 499 154 504 minecraft:terracotta
fill 499 154 505 499 155 505 minecraft:brown_terracotta
fill 500 154 464 500 157 464 minecraft:red_terracotta
setblock 500 154 503 minecraft:terracotta
fill 500 154 504 500 157 504 minecraft:red_terracotta
setblock 501 154 502 minecraft:terracotta
fill 501 154 503 501 157 503 minecraft:red_terracotta
setblock 502 154 466 minecraft:terracotta
fill 502 154 502 502 155 502 minecraft:red_terracotta
fill 502 154 505 502 155 505 minecraft:brown_terracotta
setblock 503 154 465 minecraft:terracotta
fill 503 154 466 503 156 466 minecraft:red_terracotta
setblock 504 154 463 minecraft:red_terracotta
setblock 504 154 464 minecraft:terracotta
fill 504 154 465 504 157 465 minecraft:red_terracotta
setblock 504 154 504 minecraft:terracotta
fill 505 154 464 505 157 464 minecraft:red_terracotta
setblock 505 154 466 minecraft:red_terracotta
setblock 505 154 503 minecraft:terracotta
fill 505 154 504 505 157 504 minecraft:red_terracotta
fill 506 154 503 506 155 503 minecraft:red_terracotta
setblock 508 154 465 minecraft:terracotta
setblock 509 154 464 minecraft:terracotta
setblock 509 154 484 minecraft:terracotta
setblock 509 154 485 minecraft:red_terracotta
setblock 509 154 489 minecraft:terracotta
fill 509 154 490 509 156 490 minecraft:red_terracotta
setblock 509 154 504 minecraft:terracotta
setblock 510 154 464 minecraft:red_terracotta
setblock 510 154 483 minecraft:terracotta
fill 510 154 484 510 155 484 minecraft:red_terracotta
setblock 510 154 488 minecraft:terracotta
fill 510 154 489 510 157 489 minecraft:red_terracotta
setblock 510 154 492 minecraft:red_terracotta
setblock 510 154 493 minecraft:terracotta
setblock 510 154 504 minecraft:red_terracotta
setblock 511 154 467 minecraft:terracotta
setblock 511 154 482 minecraft:terracotta
fill 511 154 483 511 157 483 minecraft:red_terracotta
setblock 511 154 487 minecraft:terracotta
fill 511 154 488 511 157 488 minecraft:red_terracotta
setblock 511 154 492 minecraft:terracotta
fill 511 154 493 511 157 493 minecraft:red_terracotta
fill 512 154 470 512 154 471 minecraft:red_terracotta
fill 512 154 472 512 155 472 minecraft:brown_terracotta
setblock 512 154 482 minecraft:red_terracotta
fill 512 154 484 512 154 485 minecraft:red_terracotta
fill 512 154 486 512 155 487 minecraft:brown_terracotta
fill 512 154 489 512 155 489 minecraft:brown_terracotta
setblock 512 154 490 minecraft:red_terracotta
fill 512 154 491 512 155 491 minecraft:brown_terracotta
setblock 512 154 492 minecraft:red_terracotta
fill 512 154 493 512 155 493 minecraft:brown_terracotta
fill 512 154 501 512 155 503 minecraft:brown_terracotta
setblock 512 154 504 minecraft:red_terracotta
fill 512 154 505 512 155 505 minecraft:brown_terracotta
setblock 470 155 465 minecraft:brown_terracotta
fill 470 155 490 470 156 490 minecraft:brown_terracotta
setblock 470 155 493 minecraft:brown_terracotta
setblock 470 155 495 minecraft:brown_terracotta
fill 471 155 464 472 155 464 minecraft:red_terracotta
setblock 471 155 466 minecraft:terracotta
fill 471 155 467 471 158 467 minecraft:red_terracotta
setblock 471 155 471 minecraft:terracotta
fill 471 155 472 471 157 473 minecraft:red_terracotta
setblock 471 155 481 minecraft:terracotta
fill 471 155 482 471 156 482 minecraft:red_terracotta
setblock 471 155 486 minecraft:terracotta
fill 471 155 487 471 158 487 minecraft:red_terracotta
setblock 471 155 491 minecraft:terracotta
fill 471 155 492 471 157 492 minecraft:red_terracotta
setblock 472 155 485 minecraft:terracotta
fill 472 155 486 472 156 486 minecraft:red_terracotta
setblock 473 155 464 minecraft:terracotta
fill 474 155 464 474 158 464 minecraft:red_terracotta
setblock 476 155 466 minecraft:terracotta
setblock 477 155 465 minecraft:terracotta
fill 477 155 466 480 155 466 minecraft:red_terracotta
setblock 478 155 464 minecraft:terracotta
fill 478 155 465 478 158 465 minecraft:red_terracotta
fill 478 155 467 479 155 467 minecraft:red_terracotta
setblock 478 155 504 minecraft:terracotta
fill 479 155 464 480 157 464 minecraft:red_terracotta
fill 479 155 504 479 158 504 minecraft:red_terracotta
fill 480 155 463 481 155 463 minecraft:brown_terracotta
setblock 480 155 467 minecraft:terracotta
setblock 481 155 466 minecraft:terracotta
fill 481 155 467 481 158 467 minecraft:red_terracotta
setblock 482 155 465 minecraft:terracotta
fill 482 155 466 482 158 466 minecraft:red_terracotta
setblock 483 155 463 minecraft:brown_terracotta
setblock 483 155 464 minecraft:terracotta
fill 483 155 465 483 158 465 minecraft:red_terracotta
setblock 483 155 504 minecraft:terracotta
fill 484 155 464 485 157 464 minecraft:red_terracotta
setblock 484 155 503 minecraft:terracotta
fill 484 155 504 484 158 504 minecraft:red_terracotta
setblock 485 155 463 minecraft:brown_terracotta
setblock 485 155 467 minecraft:terracotta
setblock 485 155 503 minecraft:red_terracotta
setblock 486 155 466 minecraft:terracotta
fill 486 155 467 486 156 467 minecraft:red_terracotta
setblock 487 155 465 minecraft:terracotta
fill 487 155 466 487 157 466 minecraft:red_terracotta
setblock 487 155 504 minecraft:red_terracotta
setblock 488 155 464 minecraft:terracotta
fill 488 155 465 488 158 465 minecraft:red_terracotta
setblock 488 155 504 minecraft:terracotta
fill 489 155 464 489 158 464 minecraft:red_terracotta
fill 489 155 504 489 157 504 minecraft:red_terracotta
setblock 492 155 465 minecraft:terracotta
setblock 493 155 464 minecraft:terracotta
fill 493 155 465 493 156 465 minecraft:red_terracotta
setblock 493 155 504 minecraft:terracotta
fill 494 155 464 494 158 464 minecraft:red_terracotta
fill 494 155 504 494 158 504 minecraft:red_terracotta
setblock 495 155 503 minecraft:red_terracotta
setblock 497 155 465 minecraft:terracotta
fill 497 155 466 500 155 466 minecraft:red_terracotta
setblock 498 155 464 minecraft:terracotta
fill 498 155 465 498 158 465 minecraft:red_terracotta
setblock 498 155 504 minecraft:terracotta
fill 499 155 464 499 158 464 minecraft:red_terracotta
setblock 499 155 503 minecraft:terracotta
fill 499 155 504 499 158 504 minecraft:red_terracotta
setblock 500 155 502 minecraft:terracotta
fill 500 155 503 500 158 503 minecraft:red_terracotta
setblock 501 155 466 minecraft:terracotta
fill 501 155 502 501 156 502 minecraft:red_terracotta
setblock 502 155 465 minecraft:terracotta
fill 502 155 466 502 156 466 minecraft:red_terracotta
setblock 503 155 464 minecraft:terracotta
fill 503 155 465 503 157 465 minecraft:red_terracotta
setblock 503 155 504 minecraft:terracotta
setblock 504 155 463 minecraft:brown_terracotta
fill 504 155 464 504 158 464 minecraft:red_terracotta
setblock 504 155 503 minecraft:terracotta
fill 504 155 504 504 158 504 minecraft:red_terracotta
fill 505 155 503 505 156 503 minecraft:red_terracotta
setblock 507 155 465 minecraft:terracotta
setblock 508 155 464 minecraft:terracotta
setblock 508 155 504 minecraft:terracotta
setblock 509 155 464 minecraft:red_terracotta
setblock 509 155 488 minecraft:terracotta
fill 509 155 489 509 156 489 minecraft:red_terracotta
setblock 509 155 504 minecraft:red_terracotta
setblock 510 155 483 minecraft:red_terracotta
setblock 510 155 487 minecraft:terracotta
fill 510 155 488 510 158 488 minecraft:red_terracotta
setblock 510 155 492 minecraft:terracotta
fill 510 155 493 510 156 493 minecraft:red_terracotta
setblock 511 155 481 minecraft:terracotta
fill 511 155 482 511 156 482 minecraft:red_terracotta
setblock 511 155 486 minecraft:terracotta
fill 511 155 487 511 158 487 minecraft:red_terracotta
setblock 511 155 491 minecraft:terracotta
fill 511 155 492 511 158 492 minecraft:red_terracotta
setblock 512 155 467 minecraft:brown_terracotta
fill 512 155 470 512 155 471 minecraft:brown_terracotta
setblock 512 155 482 minecraft:brown_terracotta
fill 512 155 484 512 155 485 minecraft:brown_terracotta
setblock 512 155 490 minecraft:brown_terracotta
setblock 512 155 492 minecraft:brown_terracotta
setblock 512 155 504 minecraft:brown_terracotta
fill 470 156 463 470 156 481 minecraft:red_terracotta
setblock 470 156 482 minecraft:brown_terracotta
fill 470 156 483 470 165 484 minecraft:red_terracotta
fill 470 156 486 470 156 489 minecraft:red_terracotta
fill 470 156 491 470 165 495 minecraft:red_terracotta
fill 470 156 497 470 156 504 minecraft:red_terracotta
setblock 471 156 465 minecraft:terracotta
fill 471 156 466 471 158 466 minecraft:red_terracotta
setblock 471 156 470 minecraft:terracotta
fill 471 156 471 471 159 471 minecraft:red_terracotta
setblock 471 156 481 minecraft:red_terracotta
setblock 471 156 485 minecraft:terracotta
fill 471 156 486 471 158 486 minecraft:red_terracotta
setblock 471 156 490 minecraft:terracotta
fill 471 156 491 471 159 491 minecraft:red_terracotta
fill 471 156 505 483 157 505 minecraft:red_terracotta
fill 472 156 463 475 228 463 minecraft:red_terracotta
setblock 472 156 464 minecraft:terracotta
setblock 472 156 485 minecraft:red_terracotta
fill 473 156 464 473 157 464 minecraft:red_terracotta
setblock 476 156 465 minecraft:terracotta
fill 476 156 466 479 156 466 minecraft:red_terracotta
fill 477 156 463 478 156 463 minecraft:red_terracotta
setblock 477 156 464 minecraft:terracotta
fill 477 156 465 477 159 465 minecraft:red_terracotta
fill 478 156 464 478 159 464 minecraft:red_terracotta
setblock 478 156 467 minecraft:red_terracotta
fill 478 156 504 478 157 504 minecraft:red_terracotta
setblock 479 156 463 minecraft:brown_terracotta
setblock 479 156 467 minecraft:terracotta
fill 480 156 463 495 156 463 minecraft:red_terracotta
setblock 480 156 466 minecraft:terracotta
fill 480 156 467 480 159 467 minecraft:red_terracotta
setblock 481 156 465 minecraft:terracotta
fill 481 156 466 481 159 466 minecraft:red_terracotta
setblock 482 156 464 minecraft:terracotta
fill 482 156 465 482 159 465 minecraft:red_terracotta
fill 482 156 467 482 157 467 minecraft:red_terracotta
setblock 482 156 504 minecraft:terracotta
fill 483 156 464 483 159 464 minecraft:red_terracotta
setblock 483 156 503 minecraft:terracotta
fill 483 156 504 483 159 504 minecraft:red_terracotta
setblock 484 156 467 minecraft:terracotta
setblock 485 156 466 minecraft:terracotta
setblock 485 156 467 minecraft:red_terracotta
fill 485 156 505 485 231 505 minecraft:red_terracotta
setblock 486 156 465 minecraft:terracotta
fill 486 156 466 486 157 466 minecraft:red_terracotta
setblock 487 156 464 minecraft:terracotta
fill 487 156 465 487 158 465 minecraft:red_terracotta
setblock 487 156 504 minecraft:terracotta
fill 487 156 505 488 227 505 minecraft:red_terracotta
fill 488 156 464 488 159 464 minecraft:red_terracotta
fill 488 156 504 488 157 504 minecraft:red_terracotta
setblock 489 156 505 minecraft:brown_terracotta
fill 490 156 505 512 157 505 minecraft:red_terracotta
setblock 491 156 465 minecraft:terracotta
setblock 492 156 464 minecraft:terracotta
setblock 492 156 465 minecraft:red_terracotta
setblock 492 156 504 minecraft:terracotta
fill 493 156 464 493 159 464 minecraft:red_terracotta
fill 493 156 504 493 157 504 minecraft:red_terracotta
setblock 496 156 465 minecraft:terracotta
fill 497 156 463 498 157 463 minecraft:red_terracotta
setblock 497 156 464 minecraft:terracotta
fill 497 156 465 497 159 465 minecraft:red_terracotta
setblock 497 156 504 minecraft:terracotta
fill 498 156 464 498 159 464 minecraft:red_terracotta
fill 498 156 466 499 156 466 minecraft:red_terracotta
setblock 498 156 503 minecraft:terracotta
fill 498 156 504 498 159 504 minecraft:red_terracotta
setblock 499 156 463 minecraft:brown_terracotta
fill 499 156 503 499 159 503 minecraft:red_terracotta
fill 500 156 463 501 229 463 minecraft:red_terracotta
setblock 500 156 466 minecraft:terracotta
setblock 501 156 465 minecraft:terracotta
setblock 501 156 466 minecraft:red_terracotta
setblock 502 156 463 minecraft:brown_terracotta
setblock 502 156 464 minecraft:terracotta
fill 502 156 465 502 158 465 minecraft:red_terracotta
setblock 502 156 504 minecraft:terracotta
fill 503 156 463 503 159 464 minecraft:red_terracotta
setblock 503 156 503 minecraft:terracotta
fill 503 156 504 503 159 504 minecraft:red_terracotta
fill 504 156 463 509 229 463 minecraft:red_terracotta
setblock 504 156 503 minecraft:red_terracotta
setblock 506 156 464 minecraft:red_terracotta
setblock 507 156 464 minecraft:terracotta
setblock 507 156 504 minecraft:terracotta
setblock 508 156 464 minecraft:red_terracotta
setblock 509 156 487 minecraft:terracotta
setblock 509 156 488 minecraft:red_terracotta
fill 510 156 463 510 157 463 minecraft:brown_terracotta
setblock 510 156 486 minecraft:terracotta
fill 510 156 487 510 158 487 minecraft:red_terracotta
setblock 510 156 491 minecraft:terracotta
fill 510 156 492 510 158 492 minecraft:red_terracotta
fill 511 156 463 511 231 463 minecraft:red_terracotta
setblock 511 156 485 minecraft:terracotta
fill 511 156 486 512 157 486 minecraft:red_terracotta
setblock 511 156 490 minecraft:terracotta
fill 511 156 491 512 156 491 minecraft:red_terracotta
setblock 512 156 463 minecraft:brown_terracotta
fill 512 156 465 512 227 479 minecraft:red_terracotta
setblock 512 156 480 minecraft:brown_terracotta
fill 512 156 481 512 157 485 minecraft:red_terracotta
fill 512 156 487 512 157 490 minecraft:red_terracotta
fill 512 156 492 512 228 494 minecraft:red_terracotta
fill 512 156 495 512 157 495 minecraft:brown_terracotta
fill 512 156 496 512 156 504 minecraft:red_terracotta
fill 470 157 463 470 229 465 minecraft:red_terracotta
setblock 470 157 466 minecraft:brown_terracotta
fill 470 157 467 470 157 476 minecraft:red_terracotta
setblock 470 157 477 minecraft:brown_terracotta
fill 470 157 478 470 157 482 minecraft:red_terracotta
fill 470 157 485 471 158 485 minecraft:red_terracotta
setblock 470 157 486 minecraft:brown_terracotta
fill 470 157 487 470 165 490 minecraft:red_terracotta
setblock 470 157 497 minecraft:brown_terracotta
fill 470 157 498 470 228 502 minecraft:red_terracotta
fill 470 157 503 470 157 504 minecraft:brown_terracotta
setblock 470 157 505 minecraft:red_terracotta
fill 471 157 463 471 231 463 minecraft:red_terracotta
setblock 471 157 469 minecraft:terracotta
fill 471 157 470 471 160 470 minecraft:red_terracotta
setblock 471 157 484 minecraft:terracotta
setblock 471 157 489 minecraft:terracotta
fill 471 157 490 471 160 490 minecraft:red_terracotta
setblock 473 157 466 minecraft:light[level=14]
setblock 473 157 474 minecraft:light[level=14]
setblock 473 157 482 minecraft:light[level=14]
setblock 473 157 490 minecraft:light[level=14]
setblock 473 157 498 minecraft:light[level=14]
setblock 475 157 465 minecraft:terracotta
fill 476 157 463 477 157 463 minecraft:red_terracotta
setblock 476 157 464 minecraft:terracotta
fill 476 157 465 476 158 466 minecraft:red_terracotta
fill 477 157 464 477 160 464 minecraft:red_terracotta
fill 477 157 466 478 157 466 minecraft:red_terracotta
setblock 478 157 463 minecraft:brown_terracotta
setblock 478 157 467 minecraft:terracotta
fill 479 157 463 484 231 463 minecraft:red_terracotta
setblock 479 157 466 minecraft:terracotta
fill 479 157 467 479 160 467 minecraft:red_terracotta
setblock 480 157 465 minecraft:terracotta
fill 480 157 466 480 160 466 minecraft:red_terracotta
setblock 481 157 464 minecraft:terracotta
fill 481 157 465 481 160 465 minecraft:red_terracotta
setblock 481 157 474 minecraft:light[level=14]
setblock 481 157 482 minecraft:light[level=14]
setblock 481 157 490 minecraft:light[level=14]
setblock 481 157 498 minecraft:light[level=14]
setblock 481 157 504 minecraft:terracotta
fill 482 157 464 482 160 464 minecraft:red_terracotta
fill 482 157 504 482 160 504 minecraft:red_terracotta
setblock 483 157 467 minecraft:terracotta
setblock 484 157 466 minecraft:terracotta
setblock 484 157 467 minecraft:red_terracotta
fill 484 157 505 484 227 505 minecraft:red_terracotta
setblock 485 157 463 minecraft:brown_terracotta
setblock 485 157 465 minecraft:terracotta
fill 485 157 466 485 158 466 minecraft:red_terracotta
setblock 485 157 504 minecraft:red_terracotta
fill 486 157 463 487 231 463 minecraft:red_terracotta
setblock 486 157 464 minecraft:terracotta
fill 486 157 465 486 159 465 minecraft:red_terracotta
setblock 486 157 504 minecraft:terracotta
fill 486 157 505 486 231 505 minecraft:red_terracotta
fill 487 157 464 487 160 464 minecraft:red_terracotta
setblock 487 157 504 minecraft:red_terracotta
setblock 488 157 463 minecraft:brown_terracotta
fill 489 157 463 496 157 463 minecraft:red_terracotta
setblock 489 157 466 minecraft:light[level=14]
setblock 489 157 474 minecraft:light[level=14]
setblock 489 157 482 minecraft:light[level=14]
setblock 489 157 490 minecraft:light[level=14]
setblock 489 157 498 minecraft:light[level=14]
fill 489 157 505 489 231 505 minecraft:red_terracotta
setblock 490 157 465 minecraft:terracotta
setblock 491 157 464 minecraft:terracotta
setblock 491 157 465 minecraft:red_terracotta
fill 492 157 464 492 159 464 minecraft:red_terracotta
setblock 492 157 504 minecraft:red_terracotta
fill 494 157 491 495 157 495 minecraft:orange_concrete
setblock 495 157 464 minecraft:red_terracotta
setblock 495 157 465 minecraft:terracotta
fill 495 157 489 501 157 490 minecraft:orange_concrete
fill 495 157 496 501 157 496 minecraft:orange_concrete
setblock 496 157 464 minecraft:terracotta
fill 496 157 465 496 158 465 minecraft:red_terracotta
fill 496 157 491 496 159 491 minecraft:orange_concrete
fill 496 157 494 496 159 495 minecraft:orange_concrete
setblock 496 157 504 minecraft:terracotta
fill 497 157 464 497 160 464 minecraft:red_terracotta
setblock 497 157 466 minecraft:light[level=14]
setblock 497 157 474 minecraft:light[level=14]
setblock 497 157 482 minecraft:light[level=14]
fill 497 157 488 499 157 488 minecraft:orange_concrete
fill 497 157 495 497 159 495 minecraft:orange_concrete
fill 497 157 497 500 157 497 minecraft:orange_concrete
setblock 497 157 498 minecraft:light[level=14]
setblock 497 157 503 minecraft:terracotta
fill 497 157 504 497 160 504 minecraft:red_terracotta
fill 498 157 503 498 158 503 minecraft:red_terracotta
fill 499 157 463 499 231 463 minecraft:red_terracotta
setblock 500 157 465 minecraft:terracotta
setblock 500 157 466 minecraft:red_terracotta
fill 500 157 495 502 157 495 minecraft:orange_concrete
setblock 501 157 464 minecraft:terracotta
fill 501 157 465 501 158 465 minecraft:red_terracotta
fill 501 157 491 502 158 494 minecraft:orange_concrete
setblock 501 157 504 minecraft:terracotta
fill 502 157 463 502 160 464 minecraft:red_terracotta
setblock 502 157 490 minecraft:orange_concrete
setblock 502 157 503 minecraft:terracotta
fill 502 157 504 502 160 504 minecraft:red_terracotta
fill 503 157 492 503 157 493 minecraft:orange_concrete
setblock 503 157 503 minecraft:red_terracotta
fill 504 157 479 505 157 483 minecraft:orange_concrete
setblock 505 157 466 minecraft:light[level=14]
setblock 505 157 474 minecraft:light[level=14]
fill 505 157 478 510 157 478 minecraft:orange_concrete
fill 505 157 484 510 157 484 minecraft:orange_concrete
setblock 505 157 490 minecraft:light[level=14]
setblock 505 157 498 minecraft:light[level=14]
setblock 506 157 464 minecraft:terracotta
fill 506 157 479 506 159 479 minecraft:orange_concrete
fill 506 157 483 506 159 483 minecraft:orange_concrete
fill 506 157 485 508 157 485 minecraft:orange_concrete
setblock 506 157 504 minecraft:terracotta
fill 507 157 477 508 157 477 minecraft:orange_concrete
fill 509 157 479 510 158 479 minecraft:orange_concrete
fill 509 157 483 510 158 483 minecraft:orange_concrete
fill 510 157 480 511 157 482 minecraft:orange_concrete
setblock 510 157 486 minecraft:red_terracotta
setblock 510 157 490 minecraft:terracotta
fill 510 157 491 511 159 491 minecraft:red_terracotta
setblock 511 157 484 minecraft:terracotta
fill 511 157 485 511 159 485 minecraft:red_terracotta
setblock 511 157 489 minecraft:terracotta
fill 511 157 490 511 160 490 minecraft:red_terracotta
setblock 511 157 494 minecraft:terracotta
setblock 512 157 463 minecraft:red_terracotta
fill 512 157 480 512 229 480 minecraft:red_terracotta
setblock 512 157 491 minecraft:brown_terracotta
setblock 512 157 496 minecraft:red_terracotta
setblock 512 157 497 minecraft:brown_terracotta
fill 512 157 498 512 157 500 minecraft:red_terracotta
setblock 512 157 501 minecraft:brown_terracotta
fill 512 157 502 512 228 504 minecraft:red_terracotta
fill 470 158 466 470 227 470 minecraft:red_terracotta
setblock 470 158 471 minecraft:brown_terracotta
fill 470 158 472 470 165 478 minecraft:red_terracotta
setblock 470 158 479 minecraft:brown_terracotta
fill 470 158 480 470 165 482 minecraft:red_terracotta
fill 470 158 486 470 165 486 minecraft:red_terracotta
fill 470 158 496 470 231 497 minecraft:red_terracotta
fill 470 158 503 470 227 504 minecraft:red_terracotta
setblock 470 158 505 minecraft:brown_terracotta
setblock 471 158 468 minecraft:terracotta
fill 471 158 469 471 160 469 minecraft:red_terracotta
setblock 471 158 472 minecraft:red_terracotta
setblock 471 158 473 minecraft:terracotta
fill 471 158 474 471 160 474 minecraft:red_terracotta
setblock 471 158 488 minecraft:terracotta
fill 471 158 489 471 160 489 minecraft:red_terracotta
fill 471 158 505 477 228 505 minecraft:red_terracotta
setblock 475 158 464 minecraft:terracotta
fill 475 158 465 475 160 465 minecraft:red_terracotta
setblock 476 158 463 minecraft:brown_terracotta
fill 476 158 464 476 160 464 minecraft:red_terracotta
fill 477 158 463 478 228 463 minecraft:red_terracotta
setblock 477 158 466 minecraft:red_terracotta
setblock 478 158 466 minecraft:terracotta
setblock 478 158 467 minecraft:red_terracotta
setblock 478 158 505 minecraft:brown_terracotta
setblock 479 158 464 minecraft:red_terracotta
setblock 479 158 465 minecraft:terracotta
fill 479 158 466 479 160 466 minecraft:red_terracotta
fill 479 158 505 483 228 505 minecraft:red_terracotta
setblock 480 158 464 minecraft:terracotta
fill 480 158 465 480 160 465 minecraft:red_terracotta
setblock 480 158 504 minecraft:terracotta
fill 481 158 464 481 160 464 minecraft:red_terracotta
fill 481 158 504 481 160 504 minecraft:red_terracotta
setblock 482 158 467 minecraft:terracotta
setblock 483 158 466 minecraft:terracotta
setblock 483 158 467 minecraft:red_terracotta
setblock 484 158 464 minecraft:red_terracotta
setblock 484 158 465 minecraft:terracotta
fill 484 158 466 484 159 466 minecraft:red_terracotta
fill 485 158 463 485 231 463 minecraft:red_terracotta
setblock 485 158 464 minecraft:terracotta
fill 485 158 465 485 160 465 minecraft:red_terracotta
setblock 485 158 504 minecraft:terracotta
fill 486 158 464 486 160 464 minecraft:red_terracotta
setblock 486 158 504 minecraft:red_terracotta
fill 488 158 463 490 231 463 minecraft:red_terracotta
setblock 490 158 464 minecraft:terracotta
fill 490 158 505 497 228 505 minecraft:red_terracotta
setblock 491 158 463 minecraft:brown_terracotta
fill 491 158 464 491 159 464 minecraft:red_terracotta
fill 492 158 463 496 227 463 minecraft:red_terracotta
setblock 495 158 464 minecraft:terracotta
fill 495 158 491 495 158 495 minecraft:orange_concrete
setblock 495 158 504 minecraft:terracotta
fill 496 158 464 496 160 464 minecraft:red_terracotta
fill 496 158 490 501 158 490 minecraft:orange_concrete
fill 496 158 496 500 158 496 minecraft:orange_concrete
fill 496 158 504 496 160 504 minecraft:red_terracotta
setblock 497 158 463 minecraft:brown_terracotta
fill 497 158 489 500 158 489 minecraft:orange_concrete
fill 498 158 463 498 229 463 minecraft:red_terracotta
fill 498 158 505 499 158 505 minecraft:brown_terracotta
setblock 499 158 465 minecraft:terracotta
setblock 500 158 464 minecraft:terracotta
fill 500 158 465 500 159 465 minecraft:red_terracotta
fill 500 158 495 501 158 495 minecraft:orange_concrete
setblock 500 158 504 minecraft:terracotta
fill 500 158 505 512 227 505 minecraft:red_terracotta
fill 501 158 464 501 160 464 minecraft:red_terracotta
setblock 501 158 503 minecraft:terracotta
fill 501 158 504 501 160 504 minecraft:red_terracotta
setblock 502 158 503 minecraft:red_terracotta
fill 504 158 480 505 158 482 minecraft:orange_concrete
setblock 505 158 479 minecraft:orange_concrete
setblock 505 158 483 minecraft:orange_concrete
fill 506 158 478 508 158 478 minecraft:orange_concrete
fill 506 158 484 509 158 484 minecraft:orange_concrete
fill 510 158 463 510 227 463 minecraft:red_terracotta
fill 510 158 480 510 158 482 minecraft:orange_concrete
setblock 510 158 489 minecraft:terracotta
fill 510 158 490 510 159 490 minecraft:red_terracotta
fill 511 158 484 512 158 484 minecraft:red_terracotta
fill 511 158 486 511 159 486 minecraft:red_terracotta
setblock 511 158 488 minecraft:terracotta
fill 511 158 489 512 160 489 minecraft:red_terracotta
setblock 511 158 493 minecraft:terracotta
fill 511 158 494 511 160 494 minecraft:red_terracotta
setblock 512 158 463 minecraft:brown_terracotta
fill 512 158 464 512 231 464 minecraft:red_terracotta
fill 512 158 481 512 231 481 minecraft:red_terracotta
setblock 512 158 482 minecraft:brown_terracotta
fill 512 158 483 512 227 483 minecraft:red_terracotta
fill 512 158 485 512 231 485 minecraft:red_terracotta
setblock 512 158 486 minecraft:brown_terracotta
fill 512 158 487 512 231 488 minecraft:red_terracotta
setblock 512 158 490 minecraft:brown_terracotta
fill 512 158 491 512 231 491 minecraft:red_terracotta
fill 512 158 495 512 231 495 minecraft:red_terracotta
setblock 512 158 496 minecraft:brown_terracotta
fill 512 158 497 512 229 498 minecraft:red_terracotta
setblock 512 158 499 minecraft:brown_terracotta
fill 512 158 500 512 229 501 minecraft:red_terracotta
fill 470 159 471 470 231 471 minecraft:red_terracotta
fill 470 159 479 470 165 479 minecraft:red_terracotta
fill 470 159 485 470 165 485 minecraft:red_terracotta
fill 470 159 505 470 231 505 minecraft:red_terracotta
setblock 471 159 467 minecraft:terracotta
fill 471 159 468 471 160 468 minecraft:red_terracotta
setblock 471 159 472 minecraft:terracotta
fill 471 159 473 471 160 473 minecraft:red_terracotta
setblock 471 159 487 minecraft:terracotta
setblock 471 159 488 minecraft:red_terracotta
fill 472 159 469 472 159 470 minecraft:red_terracotta
setblock 472 159 471 minecraft:terracotta
setblock 474 159 464 minecraft:terracotta
fill 475 159 464 475 160 464 minecraft:red_terracotta
fill 476 159 463 476 231 463 minecraft:red_terracotta
fill 476 159 465 476 160 465 minecraft:red_terracotta
setblock 477 159 466 minecraft:terracotta
setblock 478 159 465 minecraft:terracotta
fill 478 159 466 478 160 466 minecraft:red_terracotta
fill 478 159 505 478 229 505 minecraft:red_terracotta
setblock 479 159 464 minecraft:terracotta
fill 479 159 465 479 160 465 minecraft:red_terracotta
setblock 479 159 504 minecraft:terracotta
fill 480 159 464 480 160 464 minecraft:red_terracotta
fill 480 159 504 480 160 504 minecraft:red_terracotta
setblock 481 159 467 minecraft:terracotta
setblock 482 159 466 minecraft:terracotta
setblock 482 159 467 minecraft:red_terracotta
setblock 483 159 465 minecraft:terracotta
fill 483 159 466 483 160 466 minecraft:red_terracotta
setblock 484 159 464 minecraft:terracotta
fill 484 159 465 484 160 465 minecraft:red_terracotta
setblock 484 159 504 minecraft:terracotta
fill 485 159 464 485 160 464 minecraft:red_terracotta
setblock 489 159 464 minecraft:terracotta
setblock 490 159 464 minecraft:red_terracotta
fill 491 159 463 491 228 463 minecraft:red_terracotta
setblock 494 159 464 minecraft:terracotta
setblock 494 159 504 minecraft:terracotta
fill 495 159 464 495 160 464 minecraft:red_terracotta
fill 495 159 492 495 159 493 minecraft:orange_concrete
fill 495 159 504 495 160 504 minecraft:red_terracotta
fill 497 159 463 497 231 463 minecraft:red_terracotta
fill 497 159 490 500 159 490 minecraft:orange_concrete
setblock 498 159 465 minecraft:terracotta
fill 498 159 505 499 231 505 minecraft:red_terracotta
setblock 499 159 464 minecraft:terracotta
setblock 499 159 465 minecraft:red_terracotta
setblock 499 159 504 minecraft:terracotta
fill 500 159 464 500 160 464 minecraft:red_terracotta
setblock 500 159 495 minecraft:orange_concrete
setblock 500 159 503 minecraft:terracotta
fill 500 159 504 500 160 504 minecraft:red_terracotta
fill 501 159 491 501 159 494 minecraft:orange_concrete
fill 505 159 480 505 159 482 minecraft:orange_concrete
setblock 509 159 479 minecraft:orange_concrete
setblock 509 159 483 minecraft:orange_concrete
setblock 510 159 481 minecraft:orange_concrete
setblock 510 159 489 minecraft:red_terracotta
setblock 511 159 487 minecraft:terracotta
fill 511 159 488 511 160 488 minecraft:red_terracotta
setblock 511 159 492 minecraft:terracotta
fill 511 159 493 511 160 493 minecraft:red_terracotta
fill 512 159 463 512 232 463 minecraft:red_terracotta
fill 512 159 482 512 231 482 minecraft:red_terracotta
fill 512 159 484 512 231 484 minecraft:red_terracotta
fill 512 159 486 512 231 486 minecraft:red_terracotta
fill 512 159 490 512 229 490 minecraft:red_terracotta
fill 512 159 496 512 231 496 minecraft:red_terracotta
fill 512 159 499 512 231 499 minecraft:red_terracotta
setblock 471 160 467 minecraft:red_terracotta
setblock 471 160 471 minecraft:terracotta
fill 471 160 472 472 160 472 minecraft:red_terracotta
setblock 471 160 475 minecraft:red_terracotta
setblock 472 160 469 minecraft:red_terracotta
setblock 472 160 470 minecraft:terracotta
setblock 472 160 471 minecraft:red_terracotta
setblock 472 160 473 minecraft:red_terracotta
setblock 474 160 464 minecraft:red_terracotta
setblock 477 160 465 minecraft:terracotta
setblock 477 160 466 minecraft:red_terracotta
setblock 478 160 464 minecraft:terracotta
setblock 478 160 465 minecraft:red_terracotta
setblock 479 160 464 minecraft:red_terracotta
setblock 479 160 504 minecraft:red_terracotta
setblock 480 160 467 minecraft:terracotta
setblock 481 160 466 minecraft:terracotta
setblock 482 160 465 minecraft:terracotta
setblock 482 160 466 minecraft:red_terracotta
setblock 483 160 464 minecraft:terracotta
setblock 483 160 465 minecraft:red_terracotta
setblock 484 160 464 minecraft:red_terracotta
setblock 494 160 464 minecraft:red_terracotta
setblock 494 160 504 minecraft:red_terracotta
setblock 498 160 464 minecraft:terracotta
setblock 498 160 504 minecraft:terracotta
setblock 499 160 464 minecraft:red_terracotta
setblock 499 160 504 minecraft:red_terracotta
fill 503 160 463 503 229 463 minecraft:red_terracotta
setblock 511 160 486 minecraft:terracotta
setblock 511 160 487 minecraft:red_terracotta
setblock 511 160 491 minecraft:terracotta
setblock 511 160 492 minecraft:red_terracotta
fill 502 161 463 502 227 463 minecraft:red_terracotta
fill 512 161 489 512 231 489 minecraft:red_terracotta
setblock 473 165 466 minecraft:light[level=14]
setblock 473 165 474 minecraft:light[level=14]
setblock 473 165 482 minecraft:light[level=14]
setblock 473 165 490 minecraft:light[level=14]
setblock 473 165 498 minecraft:light[level=14]
setblock 481 165 466 minecraft:light[level=14]
setblock 481 165 474 minecraft:light[level=14]
setblock 481 165 482 minecraft:light[level=14]
setblock 481 165 490 minecraft:light[level=14]
setblock 481 165 498 minecraft:light[level=14]
fill 482 165 479 484 165 481 minecraft:redstone_block
fill 488 165 479 490 165 481 minecraft:redstone_block
setblock 489 165 466 minecraft:light[level=14]
setblock 489 165 474 minecraft:light[level=14]
setblock 489 165 482 minecraft:light[level=14]
fill 489 165 486 491 165 488 minecraft:redstone_block
setblock 489 165 490 minecraft:light[level=14]
setblock 489 165 498 minecraft:light[level=14]
setblock 497 165 466 minecraft:light[level=14]
setblock 497 165 474 minecraft:light[level=14]
setblock 497 165 482 minecraft:light[level=14]
setblock 497 165 490 minecraft:light[level=14]
setblock 497 165 498 minecraft:light[level=14]
setblock 505 165 466 minecraft:light[level=14]
setblock 505 165 474 minecraft:light[level=14]
setblock 505 165 482 minecraft:light[level=14]
setblock 505 165 490 minecraft:light[level=14]
setblock 505 165 498 minecraft:light[level=14]
fill 470 166 472 470 229 475 minecraft:red_terracotta
fill 470 166 476 481 166 492 minecraft:blackstone
fill 470 166 493 470 228 495 minecraft:red_terracotta
fill 471 166 475 501 166 475 minecraft:blackstone
fill 471 166 493 501 166 493 minecraft:blackstone
fill 472 166 473 500 166 474 minecraft:blackstone
fill 472 166 494 500 166 495 minecraft:blackstone
fill 473 166 472 499 166 472 minecraft:blackstone
fill 473 166 496 499 166 496 minecraft:blackstone
fill 474 166 471 498 166 471 minecraft:blackstone
fill 474 166 497 498 166 497 minecraft:blackstone
fill 475 166 470 497 166 470 minecraft:blackstone
fill 475 166 498 497 166 498 minecraft:blackstone
fill 477 166 469 495 166 469 minecraft:blackstone
fill 477 166 499 495 166 499 minecraft:blackstone
fill 478 166 468 494 166 468 minecraft:blackstone
fill 478 166 500 494 166 500 minecraft:blackstone
fill 481 166 467 491 166 467 minecraft:blackstone
fill 481 166 501 491 166 501 minecraft:blackstone
fill 482 166 476 502 166 478 minecraft:blackstone
fill 482 166 482 484 166 492 minecraft:blackstone
fill 485 166 479 487 166 482 minecraft:blackstone
fill 485 166 486 488 166 492 minecraft:blackstone
fill 486 166 466 486 173 466 minecraft:blackstone
fill 486 166 502 486 173 502 minecraft:blackstone
fill 488 166 482 503 166 485 minecraft:blackstone
fill 489 166 489 502 166 492 minecraft:blackstone
fill 491 166 479 503 166 481 minecraft:blackstone
fill 492 166 486 503 166 488 minecraft:blackstone
fill 503 166 489 503 173 489 minecraft:blackstone
fill 504 166 484 504 173 484 minecraft:blackstone
fill 470 167 476 471 173 480 minecraft:blackstone
fill 470 167 481 470 173 481 minecraft:orange_concrete
fill 470 167 482 470 173 487 minecraft:blackstone
fill 470 167 488 470 173 488 minecraft:orange_concrete
fill 470 167 489 474 167 492 minecraft:blackstone
fill 471 167 464 471 167 475 minecraft:blackstone
fill 471 167 481 471 173 486 minecraft:blackstone
fill 471 167 487 471 173 487 minecraft:orange_concrete
fill 471 167 488 476 167 488 minecraft:blackstone
fill 471 167 493 472 167 504 minecraft:blackstone
fill 472 167 464 476 167 473 minecraft:blackstone
fill 472 167 474 473 173 474 minecraft:orange_concrete
fill 472 167 475 476 167 479 minecraft:blackstone
fill 472 167 480 473 167 480 minecraft:orange_concrete
fill 472 167 481 473 167 485 minecraft:blackstone
fill 472 167 486 472 173 486 minecraft:orange_concrete
fill 472 167 487 477 167 487 minecraft:blackstone
fill 473 167 486 481 167 486 minecraft:blackstone
fill 473 167 493 473 167 495 minecraft:blackstone
fill 473 167 496 473 173 496 minecraft:orange_concrete
fill 473 167 497 478 167 504 minecraft:blackstone
fill 474 167 474 483 171 474 minecraft:blackstone
fill 474 167 480 478 167 484 minecraft:blackstone
setblock 474 167 485 minecraft:orange_concrete
setblock 474 167 493 minecraft:orange_concrete
fill 474 167 494 478 172 496 minecraft:blackstone
fill 475 167 485 481 167 485 minecraft:blackstone
fill 475 167 489 475 167 490 minecraft:blackstone
setblock 475 167 491 minecraft:orange_concrete
fill 475 167 492 486 167 493 minecraft:blackstone
setblock 476 167 489 minecraft:orange_concrete
fill 476 167 490 511 167 491 minecraft:blackstone
fill 477 167 464 484 167 468 minecraft:blackstone
fill 477 167 469 478 173 469 minecraft:orange_concrete
fill 477 167 470 480 172 473 minecraft:blackstone
fill 477 167 475 478 167 475 minecraft:orange_concrete
fill 477 167 476 479 167 479 minecraft:blackstone
setblock 477 167 488 minecraft:orange_concrete
fill 477 167 489 485 167 489 minecraft:blackstone
setblock 478 167 487 minecraft:orange_concrete
fill 478 167 488 483 167 488 minecraft:blackstone
fill 479 167 469 511 167 469 minecraft:blackstone
fill 479 167 475 497 167 475 minecraft:blackstone
fill 479 167 480 479 167 482 minecraft:blackstone
setblock 479 167 483 minecraft:orange_concrete
fill 479 167 484 481 167 484 minecraft:blackstone
fill 479 167 487 482 167 487 minecraft:blackstone
fill 479 167 494 479 172 498 minecraft:orange_concrete
fill 479 167 499 485 167 504 minecraft:blackstone
setblock 480 167 476 minecraft:orange_concrete
fill 480 167 477 480 167 479 minecraft:blackstone
setblock 480 167 480 minecraft:orange_concrete
fill 480 167 481 480 167 483 minecraft:blackstone
fill 480 167 494 483 171 498 minecraft:blackstone
fill 481 167 470 486 173 470 minecraft:blackstone
fill 481 167 471 481 173 471 minecraft:orange_concrete
fill 481 167 472 481 172 473 minecraft:blackstone
fill 481 167 476 484 167 477 minecraft:blackstone
fill 481 167 478 481 167 482 minecraft:shroomlight
setblock 481 167 483 minecraft:blackstone
fill 482 167 471 492 172 471 minecraft:blackstone
fill 482 167 472 482 172 472 minecraft:orange_concrete
fill 482 167 473 482 172 473 minecraft:blackstone
fill 482 167 478 485 167 478 minecraft:shroomlight
fill 482 167 479 484 167 481 minecraft:blackstone
fill 482 167 482 484 167 482 minecraft:shroomlight
fill 482 167 483 483 167 486 minecraft:magma_block
fill 483 167 472 487 172 472 minecraft:blackstone
fill 483 167 473 483 172 473 minecraft:orange_concrete
fill 483 167 487 487 167 487 minecraft:magma_block
fill 484 167 473 487 171 473 minecraft:blackstone
fill 484 167 474 484 171 474 minecraft:orange_concrete
fill 484 167 483 484 167 485 minecraft:ochre_froglight
setblock 484 167 486 minecraft:shroomlight
fill 484 167 488 487 168 488 minecraft:magma_block
fill 484 167 494 487 171 494 minecraft:blackstone
fill 484 167 495 484 171 496 minecraft:orange_concrete
fill 484 167 497 484 172 498 minecraft:blackstone
fill 485 167 464 485 167 466 minecraft:blackstone
fill 485 167 467 485 173 467 minecraft:orange_concrete
fill 485 167 468 485 173 468 minecraft:blackstone
fill 485 167 474 492 171 474 minecraft:blackstone
fill 485 167 476 485 170 476 minecraft:orange_concrete
fill 485 167 477 496 167 477 minecraft:blackstone
fill 485 167 479 485 167 481 minecraft:shroomlight
fill 485 167 482 487 167 482 minecraft:ochre_froglight
fill 485 167 486 487 167 486 minecraft:ochre_froglight
fill 485 167 495 488 171 497 minecraft:blackstone
fill 485 167 498 485 173 498 minecraft:orange_concrete
fill 486 167 464 511 167 465 minecraft:blackstone
fill 486 167 467 511 167 467 minecraft:blackstone
fill 486 167 468 486 173 468 minecraft:orange_concrete
fill 486 167 476 511 167 476 minecraft:blackstone
fill 486 167 478 486 169 478 minecraft:blackstone
fill 486 167 479 486 169 479 minecraft:orange_concrete
fill 486 167 480 486 168 481 minecraft:magma_block
fill 486 167 489 486 169 489 minecraft:orange_concrete
fill 486 167 498 493 173 499 minecraft:blackstone
fill 486 167 500 486 173 500 minecraft:orange_concrete
fill 486 167 501 486 173 501 minecraft:blackstone
fill 486 167 503 511 167 504 minecraft:blackstone
fill 487 167 466 511 167 466 minecraft:blackstone
fill 487 167 468 511 167 468 minecraft:blackstone
fill 487 167 470 487 173 470 minecraft:orange_concrete
fill 487 167 478 487 167 481 minecraft:shroomlight
fill 487 167 489 487 169 489 minecraft:blackstone
fill 487 167 492 487 170 492 minecraft:orange_concrete
fill 487 167 493 493 167 493 minecraft:blackstone
fill 487 167 500 511 167 500 minecraft:blackstone
fill 487 167 501 487 173 501 minecraft:orange_concrete
fill 487 167 502 511 167 502 minecraft:blackstone
fill 488 167 470 492 173 470 minecraft:blackstone
fill 488 167 472 488 171 473 minecraft:orange_concrete
fill 488 167 478 491 167 478 minecraft:shroomlight
fill 488 167 479 490 167 481 minecraft:blackstone
fill 488 167 482 491 167 482 minecraft:shroomlight
fill 488 167 483 488 167 485 minecraft:ochre_froglight
fill 488 167 486 488 167 489 minecraft:shroomlight
fill 488 167 492 491 167 492 minecraft:blackstone
fill 488 167 494 488 171 494 minecraft:orange_concrete
fill 488 167 501 511 167 501 minecraft:blackstone
fill 489 167 472 492 172 473 minecraft:blackstone
fill 489 167 483 490 167 484 minecraft:magma_block
fill 489 167 485 492 167 485 minecraft:shroomlight
fill 489 167 486 491 167 488 minecraft:blackstone
fill 489 167 489 492 167 489 minecraft:shroomlight
fill 489 167 494 498 171 494 minecraft:blackstone
fill 489 167 495 489 172 495 minecraft:orange_concrete
fill 489 167 496 489 172 497 minecraft:blackstone
fill 490 167 495 511 167 495 minecraft:blackstone
fill 490 167 496 490 172 496 minecraft:orange_concrete
fill 490 167 497 490 173 497 minecraft:blackstone
fill 491 167 479 491 167 481 minecraft:shroomlight
fill 491 167 483 497 167 484 minecraft:blackstone
fill 491 167 496 511 167 496 minecraft:blackstone
fill 491 167 497 491 173 497 minecraft:orange_concrete
fill 492 167 478 493 167 482 minecraft:blackstone
fill 492 167 486 492 167 488 minecraft:shroomlight
setblock 492 167 492 minecraft:orange_concrete
fill 492 167 497 511 167 497 minecraft:blackstone
fill 493 167 470 493 172 474 minecraft:orange_concrete
setblock 493 167 485 minecraft:orange_concrete
fill 493 167 486 498 167 489 minecraft:blackstone
fill 493 167 492 511 167 492 minecraft:blackstone
fill 494 167 470 498 167 474 minecraft:blackstone
fill 494 167 478 494 167 480 minecraft:blackstone
setblock 494 167 481 minecraft:orange_concrete
fill 494 167 482 499 167 482 minecraft:blackstone
fill 494 167 485 511 167 485 minecraft:blackstone
fill 494 167 493 495 167 493 minecraft:orange_concrete
fill 494 167 498 511 167 498 minecraft:blackstone
fill 494 167 499 495 173 499 minecraft:orange_concrete
fill 495 167 478 495 167 479 minecraft:blackstone
setblock 495 167 480 minecraft:orange_concrete
fill 495 167 481 500 167 481 minecraft:blackstone
fill 496 167 478 511 167 478 minecraft:blackstone
setblock 496 167 479 minecraft:orange_concrete
fill 496 167 480 501 167 480 minecraft:blackstone
fill 496 167 493 511 167 493 minecraft:blackstone
fill 496 167 499 511 167 499 minecraft:blackstone
setblock 497 167 477 minecraft:orange_concrete
fill 497 167 479 511 167 479 minecraft:blackstone
setblock 498 167 475 minecraft:orange_concrete
fill 498 167 477 511 167 477 minecraft:blackstone
setblock 498 167 483 minecraft:orange_concrete
fill 498 167 484 503 167 484 minecraft:blackstone
fill 499 167 470 511 167 471 minecraft:blackstone
fill 499 167 472 499 173 472 minecraft:orange_concrete
fill 499 167 473 511 167 475 minecraft:blackstone
fill 499 167 483 511 167 483 minecraft:blackstone
fill 499 167 486 501 167 487 minecraft:blackstone
fill 499 167 488 500 167 488 minecraft:orange_concrete
fill 499 167 489 502 167 489 minecraft:blackstone
fill 499 167 494 500 173 494 minecraft:orange_concrete
fill 500 167 472 511 167 472 minecraft:blackstone
fill 500 167 482 500 173 482 minecraft:orange_concrete
fill 501 167 481 501 173 481 minecraft:orange_concrete
fill 501 167 482 511 167 482 minecraft:blackstone
fill 501 167 488 511 167 488 minecraft:blackstone
fill 501 167 494 511 167 494 minecraft:blackstone
fill 502 167 480 502 173 480 minecraft:orange_concrete
fill 502 167 481 511 167 481 minecraft:blackstone
fill 502 167 486 511 167 486 minecraft:blackstone
fill 502 167 487 503 173 487 minecraft:orange_concrete
fill 503 167 480 511 167 480 minecraft:blackstone
fill 504 167 487 511 167 487 minecraft:blackstone
fill 504 167 489 511 167 489 minecraft:blackstone
fill 505 167 484 511 167 484 minecraft:blackstone
fill 470 168 489 472 173 492 minecraft:blackstone
fill 471 168 475 472 173 475 minecraft:blackstone
fill 471 168 488 472 173 488 minecraft:blackstone
fill 471 168 493 472 173 493 minecraft:blackstone
fill 472 168 473 476 173 473 minecraft:blackstone
fill 472 168 476 472 173 479 minecraft:blackstone
fill 472 168 480 472 173 480 minecraft:orange_concrete
fill 472 168 481 472 173 485 minecraft:blackstone
fill 472 168 487 472 173 487 minecraft:blackstone
fill 472 168 494 473 173 495 minecraft:blackstone
fill 473 168 472 476 173 472 minecraft:blackstone
fill 473 168 475 482 176 493 minecraft:smooth_stone
fill 474 168 471 476 173 471 minecraft:blackstone
fill 474 168 497 478 173 497 minecraft:blackstone
fill 475 168 470 476 173 470 minecraft:blackstone
fill 475 168 498 478 173 498 minecraft:blackstone
fill 477 168 499 485 173 499 minecraft:blackstone
fill 478 168 468 484 173 468 minecraft:blackstone
fill 478 168 500 485 173 500 minecraft:blackstone
fill 479 168 469 495 173 469 minecraft:blackstone
fill 481 168 467 484 173 467 minecraft:blackstone
fill 481 168 501 485 173 501 minecraft:blackstone
fill 483 168 475 483 176 493 minecraft:oak_planks
fill 484 168 475 484 169 479 minecraft:blackstone
fill 484 168 480 484 168 482 minecraft:magma_block
fill 484 168 486 484 168 487 minecraft:magma_block
fill 484 168 489 485 169 493 minecraft:blackstone
fill 485 168 475 489 170 475 minecraft:blackstone
fill 485 168 477 485 169 479 minecraft:blackstone
fill 485 168 480 485 168 481 minecraft:magma_block
fill 485 168 487 489 168 487 minecraft:magma_block
fill 486 168 467 491 173 467 minecraft:blackstone
fill 486 168 476 489 170 477 minecraft:blackstone
fill 486 168 490 486 169 493 minecraft:blackstone
fill 487 168 468 494 173 468 minecraft:blackstone
fill 487 168 478 489 169 479 minecraft:blackstone
fill 487 168 480 488 168 481 minecraft:magma_block
fill 487 168 490 489 169 491 minecraft:blackstone
fill 487 168 493 489 170 493 minecraft:blackstone
fill 487 168 500 494 173 500 minecraft:blackstone
fill 488 168 482 489 168 482 minecraft:magma_block
fill 488 168 486 489 168 486 minecraft:magma_block
setblock 488 168 488 minecraft:magma_block
fill 488 168 489 489 169 489 minecraft:blackstone
fill 488 168 492 489 170 492 minecraft:blackstone
fill 488 168 501 491 173 501 minecraft:blackstone
fill 489 168 480 489 169 480 minecraft:blackstone
setblock 489 168 481 minecraft:magma_block
fill 489 168 483 489 168 485 minecraft:magma_block
fill 489 168 488 489 169 488 minecraft:blackstone
fill 490 168 475 490 176 493 minecraft:oak_planks
fill 490 168 495 500 172 495 minecraft:blackstone
fill 491 168 475 499 176 493 minecraft:smooth_stone
fill 491 168 496 499 172 496 minecraft:blackstone
fill 492 168 497 498 173 497 minecraft:blackstone
fill 494 168 470 497 172 474 minecraft:blackstone
fill 494 168 498 497 173 498 minecraft:blackstone
fill 498 168 471 498 173 474 minecraft:blackstone
fill 499 168 473 500 173 474 minecraft:blackstone
fill 500 168 475 500 173 481 minecraft:blackstone
fill 500 168 483 501 173 487 minecraft:blackstone
fill 500 168 488 500 173 488 minecraft:orange_concrete
fill 500 168 489 501 173 493 minecraft:blackstone
fill 501 168 475 501 173 480 minecraft:blackstone
fill 501 168 482 503 173 482 minecraft:blackstone
fill 501 168 488 503 173 488 minecraft:blackstone
fill 502 168 476 502 173 479 minecraft:blackstone
fill 502 168 481 503 173 481 minecraft:blackstone
fill 502 168 483 503 173 486 minecraft:blackstone
fill 502 168 489 502 173 492 minecraft:blackstone
fill 503 168 479 503 173 480 minecraft:blackstone
fill 484 170 475 484 170 477 minecraft:blackstone
fill 484 170 491 486 170 493 minecraft:blackstone
setblock 485 170 477 minecraft:blackstone
fill 487 170 491 489 170 491 minecraft:blackstone
setblock 471 171 464 minecraft:red_terracotta
setblock 471 171 465 minecraft:terracotta
fill 471 171 466 471 171 469 minecraft:red_terracotta
setblock 471 171 470 minecraft:terracotta
fill 471 171 471 471 171 474 minecraft:red_terracotta
setblock 471 171 494 minecraft:red_terracotta
setblock 471 171 495 minecraft:terracotta
fill 471 171 496 471 171 499 minecraft:red_terracotta
setblock 471 171 500 minecraft:terracotta
fill 471 171 501 471 171 504 minecraft:red_terracotta
setblock 472 171 464 minecraft:terracotta
fill 472 171 465 472 171 468 minecraft:red_terracotta
setblock 472 171 469 minecraft:terracotta
fill 472 171 470 472 172 472 minecraft:red_terracotta
fill 472 171 496 472 171 498 minecraft:red_terracotta
setblock 472 171 499 minecraft:terracotta
fill 472 171 500 472 171 503 minecraft:red_terracotta
setblock 472 171 504 minecraft:terracotta
fill 473 171 464 475 171 465 minecraft:red_terracotta
fill 473 171 470 473 171 471 minecraft:red_terracotta
setblock 473 171 498 minecraft:terracotta
fill 473 171 499 473 171 502 minecraft:red_terracotta
setblock 473 171 503 minecraft:terracotta
fill 473 171 504 476 171 504 minecraft:red_terracotta
setblock 474 171 502 minecraft:terracotta
fill 474 171 503 477 171 503 minecraft:red_terracotta
fill 475 171 502 477 171 502 minecraft:red_terracotta
setblock 476 171 464 minecraft:red_terracotta
setblock 476 171 465 minecraft:terracotta
setblock 477 171 464 minecraft:terracotta
setblock 477 171 465 minecraft:red_terracotta
setblock 477 171 504 minecraft:terracotta
fill 478 171 464 480 172 464 minecraft:red_terracotta
setblock 478 171 503 minecraft:terracotta
fill 478 171 504 481 171 504 minecraft:red_terracotta
fill 479 171 503 482 171 503 minecraft:red_terracotta
setblock 482 171 504 minecraft:terracotta
setblock 483 171 503 minecraft:terracotta
fill 483 171 504 486 171 504 minecraft:red_terracotta
setblock 484 171 475 minecraft:blackstone
setblock 484 171 493 minecraft:blackstone
fill 484 171 503 487 171 503 minecraft:red_terracotta
fill 487 171 502 488 171 502 minecraft:red_terracotta
setblock 487 171 504 minecraft:terracotta
fill 488 171 475 489 171 475 minecraft:blackstone
fill 488 171 493 489 171 493 minecraft:blackstone
setblock 488 171 503 minecraft:terracotta
fill 488 171 504 491 171 504 minecraft:red_terracotta
setblock 489 171 502 minecraft:terracotta
fill 489 171 503 492 171 503 minecraft:red_terracotta
fill 490 171 464 491 171 464 minecraft:red_terracotta
fill 490 171 502 493 171 502 minecraft:red_terracotta
setblock 492 171 464 minecraft:terracotta
fill 492 171 501 494 171 501 minecraft:red_terracotta
setblock 492 171 504 minecraft:terracotta
fill 493 171 464 495 171 464 minecraft:red_terracotta
setblock 493 171 503 minecraft:terracotta
fill 493 171 504 496 171 504 minecraft:red_terracotta
setblock 494 171 502 minecraft:terracotta
fill 494 171 503 497 171 503 minecraft:red_terracotta
setblock 495 171 501 minecraft:terracotta
fill 495 171 502 497 171 502 minecraft:red_terracotta
setblock 497 171 504 minecraft:terracotta
setblock 498 171 503 minecraft:terracotta
fill 498 171 504 499 172 504 minecraft:red_terracotta
fill 509 171 474 509 171 476 minecraft:red_terracotta
setblock 509 171 477 minecraft:terracotta
fill 509 171 478 509 171 481 minecraft:red_terracotta
setblock 509 171 482 minecraft:terracotta
setblock 510 171 471 minecraft:terracotta
fill 510 171 472 510 171 475 minecraft:red_terracotta
setblock 510 171 476 minecraft:terracotta
fill 510 171 477 510 171 480 minecraft:red_terracotta
setblock 510 171 481 minecraft:terracotta
fill 510 171 482 510 171 485 minecraft:red_terracotta
setblock 510 171 496 minecraft:terracotta
fill 510 171 497 510 171 500 minecraft:red_terracotta
fill 510 171 504 511 171 504 minecraft:red_terracotta
setblock 511 171 464 minecraft:red_terracotta
setblock 511 171 465 minecraft:terracotta
fill 511 171 466 511 171 469 minecraft:red_terracotta
setblock 511 171 470 minecraft:terracotta
fill 511 171 471 511 171 474 minecraft:red_terracotta
setblock 511 171 475 minecraft:terracotta
fill 511 171 476 511 171 479 minecraft:red_terracotta
setblock 511 171 480 minecraft:terracotta
fill 511 171 481 511 171 484 minecraft:red_terracotta
setblock 511 171 485 minecraft:terracotta
fill 511 171 486 511 171 489 minecraft:red_terracotta
setblock 511 171 490 minecraft:terracotta
fill 511 171 491 511 171 494 minecraft:red_terracotta
setblock 511 171 495 minecraft:terracotta
fill 511 171 496 511 171 499 minecraft:red_terracotta
setblock 511 171 500 minecraft:terracotta
fill 511 171 501 511 172 503 minecraft:red_terracotta
setblock 471 172 464 minecraft:terracotta
fill 471 172 465 471 172 468 minecraft:red_terracotta
setblock 471 172 469 minecraft:terracotta
fill 471 172 470 471 172 473 minecraft:red_terracotta
setblock 471 172 474 minecraft:terracotta
setblock 471 172 494 minecraft:terracotta
fill 471 172 495 471 172 498 minecraft:red_terracotta
setblock 471 172 499 minecraft:terracotta
fill 471 172 500 471 172 503 minecraft:red_terracotta
setblock 471 172 504 minecraft:terracotta
fill 472 172 464 472 172 467 minecraft:red_terracotta
setblock 472 172 468 minecraft:terracotta
fill 472 172 469 472 175 469 minecraft:red_terracotta
setblock 472 172 497 minecraft:red_terracotta
setblock 472 172 498 minecraft:terracotta
fill 472 172 499 472 172 502 minecraft:red_terracotta
setblock 472 172 503 minecraft:terracotta
fill 472 172 504 475 172 504 minecraft:red_terracotta
fill 473 172 464 474 172 465 minecraft:red_terracotta
fill 473 172 499 473 172 501 minecraft:red_terracotta
setblock 473 172 502 minecraft:terracotta
fill 473 172 503 476 172 503 minecraft:red_terracotta
fill 474 172 474 480 172 474 minecraft:blackstone
fill 474 172 502 476 172 502 minecraft:red_terracotta
setblock 475 172 464 minecraft:red_terracotta
setblock 475 172 465 minecraft:terracotta
setblock 476 172 464 minecraft:terracotta
setblock 476 172 465 minecraft:red_terracotta
setblock 476 172 504 minecraft:terracotta
fill 477 172 464 477 175 464 minecraft:red_terracotta
setblock 477 172 503 minecraft:terracotta
fill 477 172 504 480 172 504 minecraft:red_terracotta
fill 478 172 503 481 172 503 minecraft:red_terracotta
fill 480 172 494 480 172 498 minecraft:blackstone
fill 481 172 495 483 172 498 minecraft:blackstone
setblock 481 172 504 minecraft:terracotta
setblock 482 172 503 minecraft:terracotta
fill 482 172 504 485 172 504 minecraft:red_terracotta
fill 483 172 503 486 172 503 minecraft:red_terracotta
setblock 484 172 496 minecraft:orange_concrete
fill 485 172 496 488 172 497 minecraft:blackstone
setblock 486 172 504 minecraft:terracotta
setblock 487 172 502 minecraft:red_terracotta
setblock 487 172 503 minecraft:terracotta
fill 487 172 504 490 172 504 minecraft:red_terracotta
setblock 488 172 472 minecraft:orange_concrete
setblock 488 172 502 minecraft:terracotta
fill 488 172 503 491 172 503 minecraft:red_terracotta
fill 489 172 464 490 172 464 minecraft:red_terracotta
fill 489 172 502 492 172 502 minecraft:red_terracotta
setblock 491 172 464 minecraft:terracotta
setblock 491 172 504 minecraft:terracotta
fill 492 172 464 494 172 464 minecraft:red_terracotta
setblock 492 172 474 minecraft:blackstone
fill 492 172 494 498 172 494 minecraft:blackstone
fill 492 172 501 493 172 501 minecraft:red_terracotta
setblock 492 172 503 minecraft:terracotta
fill 492 172 504 495 172 504 minecraft:red_terracotta
setblock 493 172 502 minecraft:terracotta
fill 493 172 503 496 172 503 minecraft:red_terracotta
setblock 494 172 501 minecraft:terracotta
fill 494 172 502 496 172 502 minecraft:red_terracotta
setblock 496 172 504 minecraft:terracotta
setblock 497 172 503 minecraft:terracotta
fill 497 172 504 497 175 504 minecraft:red_terracotta
setblock 509 172 475 minecraft:red_terracotta
setblock 509 172 476 minecraft:terracotta
fill 509 172 477 509 172 480 minecraft:red_terracotta
setblock 509 172 481 minecraft:terracotta
fill 509 172 482 511 173 482 minecraft:red_terracotta
fill 509 172 504 510 172 504 minecraft:red_terracotta
setblock 510 172 464 minecraft:red_terracotta
fill 510 172 471 510 172 474 minecraft:red_terracotta
setblock 510 172 475 minecraft:terracotta
fill 510 172 476 510 172 479 minecraft:red_terracotta
setblock 510 172 480 minecraft:terracotta
fill 510 172 481 511 174 481 minecraft:red_terracotta
fill 510 172 483 510 172 484 minecraft:red_terracotta
setblock 510 172 485 minecraft:terracotta
setblock 510 172 499 minecraft:red_terracotta
setblock 510 172 500 minecraft:terracotta
setblock 511 172 464 minecraft:terracotta
fill 511 172 465 511 172 468 minecraft:red_terracotta
setblock 511 172 469 minecraft:terracotta
fill 511 172 470 511 172 473 minecraft:red_terracotta
setblock 511 172 474 minecraft:terracotta
fill 511 172 475 511 172 478 minecraft:red_terracotta
setblock 511 172 479 minecraft:terracotta
fill 511 172 480 511 175 480 minecraft:red_terracotta
setblock 511 172 483 minecraft:red_terracotta
setblock 511 172 484 minecraft:terracotta
fill 511 172 485 511 172 488 minecraft:red_terracotta
setblock 511 172 489 minecraft:terracotta
fill 511 172 490 511 172 493 minecraft:red_terracotta
setblock 511 172 494 minecraft:terracotta
fill 511 172 495 511 172 498 minecraft:red_terracotta
setblock 511 172 499 minecraft:terracotta
fill 511 172 500 511 175 500 minecraft:red_terracotta
setblock 511 172 504 minecraft:terracotta
fill 471 173 464 471 173 467 minecraft:red_terracotta
setblock 471 173 468 minecraft:terracotta
fill 471 173 469 471 173 472 minecraft:red_terracotta
setblock 471 173 473 minecraft:terracotta
fill 471 173 474 471 176 474 minecraft:red_terracotta
fill 471 173 495 471 173 497 minecraft:red_terracotta
setblock 471 173 498 minecraft:terracotta
fill 471 173 499 471 173 502 minecraft:red_terracotta
setblock 471 173 503 minecraft:terracotta
fill 471 173 504 474 173 504 minecraft:red_terracotta
fill 472 173 464 472 173 466 minecraft:red_terracotta
setblock 472 173 467 minecraft:terracotta
fill 472 173 468 472 176 468 minecraft:red_terracotta
fill 472 173 470 472 173 471 minecraft:red_terracotta
setblock 472 173 472 minecraft:terracotta
setblock 472 173 497 minecraft:terracotta
fill 472 173 498 472 173 501 minecraft:red_terracotta
setblock 472 173 502 minecraft:terracotta
fill 472 173 503 475 173 503 minecraft:red_terracotta
fill 473 173 464 473 173 465 minecraft:red_terracotta
setblock 473 173 466 minecraft:light[level=14]
setblock 473 173 498 minecraft:light[level=14]
setblock 473 173 500 minecraft:red_terracotta
setblock 473 173 501 minecraft:terracotta
fill 473 173 502 475 174 502 minecraft:red_terracotta
setblock 474 173 464 minecraft:red_terracotta
setblock 474 173 465 minecraft:terracotta
fill 474 173 474 477 173 474 minecraft:blackstone
fill 474 173 494 477 173 496 minecraft:blackstone
setblock 475 173 464 minecraft:terracotta
fill 475 173 465 475 176 465 minecraft:red_terracotta
setblock 475 173 504 minecraft:terracotta
fill 476 173 464 476 176 464 minecraft:red_terracotta
setblock 476 173 503 minecraft:terracotta
fill 476 173 504 479 173 504 minecraft:red_terracotta
fill 477 173 470 478 173 473 minecraft:blackstone
fill 477 173 503 480 173 503 minecraft:red_terracotta
fill 478 173 464 479 173 464 minecraft:red_terracotta
fill 478 173 495 478 173 496 minecraft:blackstone
fill 479 173 470 479 173 472 minecraft:blackstone
fill 479 173 496 479 173 498 minecraft:orange_concrete
fill 480 173 470 480 173 471 minecraft:blackstone
fill 480 173 497 482 173 498 minecraft:blackstone
setblock 480 173 504 minecraft:terracotta
setblock 481 173 466 minecraft:light[level=14]
setblock 481 173 474 minecraft:light[level=14]
setblock 481 173 503 minecraft:terracotta
fill 481 173 504 484 173 504 minecraft:red_terracotta
setblock 482 173 471 minecraft:blackstone
fill 482 173 503 485 173 503 minecraft:red_terracotta
fill 483 173 498 484 173 498 minecraft:blackstone
setblock 485 173 504 minecraft:terracotta
setblock 486 173 503 minecraft:terracotta
fill 486 173 504 489 173 504 minecraft:red_terracotta
setblock 487 173 502 minecraft:terracotta
fill 487 173 503 490 173 503 minecraft:red_terracotta
fill 488 173 502 491 173 502 minecraft:red_terracotta
setblock 489 173 464 minecraft:red_terracotta
setblock 489 173 466 minecraft:light[level=14]
setblock 489 173 474 minecraft:light[level=14]
setblock 489 173 482 minecraft:light[level=14]
setblock 489 173 490 minecraft:light[level=14]
setblock 490 173 464 minecraft:terracotta
fill 490 173 471 492 173 471 minecraft:blackstone
setblock 490 173 504 minecraft:terracotta
fill 491 173 464 493 174 464 minecraft:red_terracotta
setblock 491 173 503 minecraft:terracotta
fill 491 173 504 494 173 504 minecraft:red_terracotta
setblock 492 173 501 minecraft:red_terracotta
setblock 492 173 502 minecraft:terracotta
fill 492 173 503 495 173 503 minecraft:red_terracotta
fill 493 173 470 493 173 472 minecraft:orange_concrete
fill 493 173 496 499 173 496 minecraft:blackstone
setblock 493 173 501 minecraft:terracotta
fill 493 173 502 495 174 502 minecraft:red_terracotta
fill 494 173 470 497 173 473 minecraft:blackstone
fill 494 173 495 500 173 495 minecraft:blackstone
fill 495 173 474 497 173 474 minecraft:blackstone
fill 495 173 494 498 173 494 minecraft:blackstone
setblock 495 173 504 minecraft:terracotta
setblock 496 173 503 minecraft:terracotta
fill 496 173 504 496 176 504 minecraft:red_terracotta
setblock 497 173 466 minecraft:light[level=14]
setblock 497 173 503 minecraft:red_terracotta
fill 498 173 504 498 174 504 minecraft:red_terracotta
setblock 505 173 466 minecraft:light[level=14]
setblock 505 173 474 minecraft:light[level=14]
setblock 505 173 482 minecraft:light[level=14]
setblock 505 173 490 minecraft:light[level=14]
setblock 505 173 498 minecraft:light[level=14]
setblock 509 173 475 minecraft:terracotta
fill 509 173 476 509 173 479 minecraft:red_terracotta
setblock 509 173 480 minecraft:terracotta
fill 509 173 481 509 176 481 minecraft:red_terracotta
fill 509 173 483 510 173 483 minecraft:red_terracotta
setblock 509 173 504 minecraft:red_terracotta
setblock 510 173 464 minecraft:terracotta
fill 510 173 472 510 173 473 minecraft:red_terracotta
setblock 510 173 474 minecraft:terracotta
fill 510 173 475 510 173 478 minecraft:red_terracotta
setblock 510 173 479 minecraft:terracotta
fill 510 173 480 510 176 480 minecraft:red_terracotta
setblock 510 173 484 minecraft:terracotta
fill 510 173 485 511 175 485 minecraft:red_terracotta
setblock 510 173 504 minecraft:terracotta
fill 511 173 464 511 173 467 minecraft:red_terracotta
setblock 511 173 468 minecraft:terracotta
fill 511 173 469 511 173 472 minecraft:red_terracotta
setblock 511 173 473 minecraft:terracotta
fill 511 173 474 511 173 477 minecraft:red_terracotta
setblock 511 173 478 minecraft:terracotta
fill 511 173 479 511 176 479 minecraft:red_terracotta
setblock 511 173 483 minecraft:terracotta
fill 511 173 484 511 176 484 minecraft:red_terracotta
fill 511 173 486 511 173 487 minecraft:red_terracotta
setblock 511 173 488 minecraft:terracotta
setblock 511 173 489 minecraft:red_terracotta
fill 511 173 494 511 173 497 minecraft:red_terracotta
setblock 511 173 498 minecraft:terracotta
fill 511 173 499 511 176 499 minecraft:red_terracotta
fill 511 173 501 511 173 502 minecraft:red_terracotta
setblock 511 173 503 minecraft:terracotta
fill 511 173 504 511 176 504 minecraft:red_terracotta
fill 470 174 476 470 227 492 minecraft:red_terracotta
fill 471 174 464 471 174 466 minecraft:red_terracotta
setblock 471 174 467 minecraft:terracotta
fill 471 174 468 471 174 471 minecraft:red_terracotta
setblock 471 174 472 minecraft:terracotta
fill 471 174 473 472 175 473 minecraft:red_terracotta
fill 471 174 475 471 174 476 minecraft:red_terracotta
setblock 471 174 477 minecraft:terracotta
fill 471 174 478 471 174 481 minecraft:red_terracotta
setblock 471 174 482 minecraft:terracotta
fill 471 174 483 471 174 486 minecraft:red_terracotta
fill 471 174 487 471 175 487 minecraft:shroomlight
fill 471 174 488 471 176 488 minecraft:magma_block
setblock 471 174 496 minecraft:red_terracotta
setblock 471 174 497 minecraft:terracotta
fill 471 174 498 471 174 501 minecraft:red_terracotta
setblock 471 174 502 minecraft:terracotta
fill 471 174 503 473 174 504 minecraft:red_terracotta
fill 472 174 464 472 174 465 minecraft:red_terracotta
setblock 472 174 466 minecraft:terracotta
fill 472 174 467 472 177 467 minecraft:red_terracotta
setblock 472 174 470 minecraft:red_terracotta
setblock 472 174 471 minecraft:terracotta
setblock 472 174 472 minecraft:red_terracotta
fill 472 174 474 472 174 475 minecraft:red_terracotta
setblock 472 174 476 minecraft:terracotta
fill 472 174 477 472 174 480 minecraft:red_terracotta
setblock 472 174 481 minecraft:terracotta
fill 472 174 482 472 176 483 minecraft:red_terracotta
fill 472 174 498 472 174 500 minecraft:red_terracotta
setblock 472 174 501 minecraft:terracotta
fill 472 174 502 472 177 502 minecraft:red_terracotta
setblock 473 174 464 minecraft:red_terracotta
setblock 473 174 465 minecraft:terracotta
fill 473 174 501 473 175 501 minecraft:red_terracotta
setblock 474 174 464 minecraft:terracotta
fill 474 174 465 474 177 465 minecraft:red_terracotta
setblock 474 174 503 minecraft:red_terracotta
setblock 474 174 504 minecraft:terracotta
fill 475 174 464 475 177 464 minecraft:red_terracotta
setblock 475 174 503 minecraft:terracotta
fill 475 174 504 478 174 504 minecraft:red_terracotta
fill 476 174 503 479 174 503 minecraft:red_terracotta
setblock 478 174 464 minecraft:red_terracotta
setblock 479 174 464 minecraft:terracotta
setblock 479 174 504 minecraft:terracotta
setblock 480 174 503 minecraft:terracotta
fill 480 174 504 483 174 504 minecraft:red_terracotta
fill 481 174 503 484 174 503 minecraft:red_terracotta
setblock 484 174 504 minecraft:terracotta
setblock 485 174 503 minecraft:terracotta
fill 485 174 504 488 174 504 minecraft:red_terracotta
setblock 486 174 502 minecraft:terracotta
fill 486 174 503 489 174 503 minecraft:red_terracotta
fill 487 174 502 490 174 502 minecraft:red_terracotta
setblock 488 174 464 minecraft:red_terracotta
setblock 489 174 464 minecraft:terracotta
setblock 489 174 504 minecraft:terracotta
fill 490 174 464 490 177 464 minecraft:red_terracotta
fill 490 174 501 491 174 501 minecraft:red_terracotta
setblock 490 174 503 minecraft:terracotta
fill 490 174 504 493 174 504 minecraft:red_terracotta
setblock 491 174 502 minecraft:terracotta
fill 491 174 503 494 174 503 minecraft:red_terracotta
setblock 492 174 501 minecraft:terracotta
fill 492 174 502 492 177 502 minecraft:red_terracotta
setblock 494 174 504 minecraft:terracotta
setblock 495 174 503 minecraft:terracotta
fill 495 174 504 495 177 504 minecraft:red_terracotta
fill 496 174 503 496 175 503 minecraft:red_terracotta
setblock 508 174 504 minecraft:red_terracotta
setblock 509 174 464 minecraft:terracotta
fill 509 174 476 509 174 478 minecraft:red_terracotta
setblock 509 174 479 minecraft:terracotta
fill 509 174 480 509 177 480 minecraft:red_terracotta
fill 509 174 482 509 174 483 minecraft:red_terracotta
setblock 509 174 504 minecraft:terracotta
fill 510 174 464 511 176 464 minecraft:red_terracotta
setblock 510 174 472 minecraft:red_terracotta
setblock 510 174 473 minecraft:terracotta
fill 510 174 474 510 174 477 minecraft:red_terracotta
setblock 510 174 478 minecraft:terracotta
fill 510 174 479 510 177 479 minecraft:red_terracotta
setblock 510 174 482 minecraft:red_terracotta
setblock 510 174 483 minecraft:terracotta
fill 510 174 484 510 177 484 minecraft:red_terracotta
fill 510 174 486 511 174 486 minecraft:red_terracotta
fill 510 174 504 510 177 504 minecraft:red_terracotta
fill 511 174 465 511 174 466 minecraft:red_terracotta
setblock 511 174 467 minecraft:terracotta
fill 511 174 468 511 174 471 minecraft:red_terracotta
setblock 511 174 472 minecraft:terracotta
fill 511 174 473 511 174 476 minecraft:red_terracotta
setblock 511 174 477 minecraft:terracotta
fill 511 174 478 511 177 478 minecraft:red_terracotta
setblock 511 174 482 minecraft:terracotta
fill 511 174 483 511 177 483 minecraft:red_terracotta
setblock 511 174 487 minecraft:terracotta
fill 511 174 488 511 177 488 minecraft:red_terracotta
setblock 511 174 496 minecraft:red_terracotta
setblock 511 174 497 minecraft:terracotta
fill 511 174 498 511 177 498 minecraft:red_terracotta
setblock 511 174 501 minecraft:red_terracotta
setblock 511 174 502 minecraft:terracotta
fill 511 174 503 511 177 503 minecraft:red_terracotta
fill 471 175 464 471 175 465 minecraft:red_terracotta
setblock 471 175 466 minecraft:terracotta
fill 471 175 467 471 175 470 minecraft:red_terracotta
setblock 471 175 471 minecraft:terracotta
fill 471 175 472 471 178 472 minecraft:red_terracotta
setblock 471 175 475 minecraft:red_terracotta
setblock 471 175 476 minecraft:terracotta
fill 471 175 477 471 175 480 minecraft:red_terracotta
setblock 471 175 481 minecraft:terracotta
fill 471 175 482 471 175 485 minecraft:red_terracotta
setblock 471 175 486 minecraft:terracotta
setblock 471 175 496 minecraft:terracotta
fill 471 175 497 471 175 500 minecraft:red_terracotta
setblock 471 175 501 minecraft:terracotta
fill 471 175 502 471 176 504 minecraft:red_terracotta
setblock 472 175 464 minecraft:red_terracotta
setblock 472 175 465 minecraft:terracotta
fill 472 175 466 472 178 466 minecraft:red_terracotta
setblock 472 175 474 minecraft:red_terracotta
setblock 472 175 475 minecraft:terracotta
fill 472 175 476 472 175 479 minecraft:red_terracotta
setblock 472 175 480 minecraft:terracotta
fill 472 175 481 472 178 481 minecraft:red_terracotta
setblock 472 175 499 minecraft:red_terracotta
setblock 472 175 500 minecraft:terracotta
fill 472 175 501 472 178 501 minecraft:red_terracotta
fill 472 175 503 472 175 504 minecraft:red_terracotta
setblock 473 175 464 minecraft:terracotta
fill 473 175 465 473 178 465 minecraft:red_terracotta
fill 473 175 502 473 175 503 minecraft:red_terracotta
setblock 473 175 504 minecraft:terracotta
fill 474 175 464 474 178 464 minecraft:red_terracotta
setblock 474 175 502 minecraft:red_terracotta
setblock 474 175 503 minecraft:terracotta
fill 474 175 504 477 175 504 minecraft:red_terracotta
fill 475 175 503 478 175 503 minecraft:red_terracotta
setblock 478 175 464 minecraft:terracotta
setblock 478 175 504 minecraft:terracotta
fill 479 175 464 479 178 464 minecraft:red_terracotta
setblock 479 175 503 minecraft:terracotta
fill 479 175 504 482 175 504 minecraft:red_terracotta
fill 480 175 503 483 175 503 minecraft:red_terracotta
setblock 483 175 504 minecraft:terracotta
setblock 484 175 503 minecraft:terracotta
fill 484 175 504 487 175 504 minecraft:red_terracotta
fill 485 175 503 488 175 503 minecraft:red_terracotta
fill 486 175 464 487 175 464 minecraft:red_terracotta
fill 486 175 502 489 175 502 minecraft:red_terracotta
setblock 488 175 464 minecraft:terracotta
setblock 488 175 504 minecraft:terracotta
fill 489 175 464 489 178 464 minecraft:red_terracotta
setblock 489 175 503 minecraft:terracotta
fill 489 175 504 492 175 504 minecraft:red_terracotta
setblock 490 175 502 minecraft:terracotta
fill 490 175 503 493 175 503 minecraft:red_terracotta
fill 491 175 464 492 175 464 minecraft:red_terracotta
fill 491 175 502 491 178 502 minecraft:red_terracotta
setblock 493 175 464 minecraft:terracotta
fill 493 175 502 494 175 502 minecraft:red_terracotta
setblock 493 175 504 minecraft:terracotta
setblock 494 175 503 minecraft:terracotta
fill 494 175 504 494 178 504 minecraft:red_terracotta
fill 495 175 503 495 178 503 minecraft:red_terracotta
setblock 507 175 504 minecraft:red_terracotta
setblock 508 175 464 minecraft:terracotta
setblock 508 175 504 minecraft:terracotta
fill 509 175 464 509 178 464 minecraft:red_terracotta
fill 509 175 476 509 175 477 minecraft:red_terracotta
setblock 509 175 478 minecraft:terracotta
fill 509 175 479 509 178 479 minecraft:red_terracotta
setblock 509 175 482 minecraft:red_terracotta
setblock 509 175 483 minecraft:terracotta
fill 509 175 484 509 178 484 minecraft:red_terracotta
fill 509 175 504 509 178 504 minecraft:red_terracotta
schedule function dropper:buildpart/118_6 1t
