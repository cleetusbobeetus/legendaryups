setblock 147 292 403 minecraft:jack_o_lantern
setblock 147 292 405 minecraft:jack_o_lantern
setblock 147 292 407 minecraft:jack_o_lantern
setblock 147 292 409 minecraft:jack_o_lantern
setblock 147 292 411 minecraft:jack_o_lantern
setblock 148 292 400 minecraft:jack_o_lantern
setblock 148 292 402 minecraft:jack_o_lantern
setblock 148 292 404 minecraft:jack_o_lantern
setblock 148 292 406 minecraft:jack_o_lantern
setblock 148 292 408 minecraft:jack_o_lantern
setblock 148 292 410 minecraft:jack_o_lantern
setblock 153 292 370 minecraft:white_concrete
setblock 154 292 410 minecraft:white_concrete
setblock 160 292 370 minecraft:white_concrete
setblock 161 292 410 minecraft:white_concrete
setblock 167 292 370 minecraft:white_concrete
setblock 168 292 410 minecraft:white_concrete
setblock 170 292 400 minecraft:jack_o_lantern
setblock 170 292 402 minecraft:jack_o_lantern
setblock 170 292 404 minecraft:jack_o_lantern
setblock 170 292 406 minecraft:jack_o_lantern
setblock 170 292 408 minecraft:jack_o_lantern
setblock 170 292 410 minecraft:jack_o_lantern
setblock 171 292 401 minecraft:jack_o_lantern
setblock 171 292 403 minecraft:jack_o_lantern
setblock 171 292 405 minecraft:jack_o_lantern
setblock 171 292 407 minecraft:jack_o_lantern
setblock 171 292 409 minecraft:jack_o_lantern
setblock 172 292 400 minecraft:jack_o_lantern
setblock 172 292 402 minecraft:jack_o_lantern
setblock 172 292 404 minecraft:jack_o_lantern
setblock 172 292 406 minecraft:jack_o_lantern
setblock 172 292 408 minecraft:jack_o_lantern
setblock 172 292 410 minecraft:jack_o_lantern
setblock 173 292 401 minecraft:jack_o_lantern
setblock 173 292 403 minecraft:jack_o_lantern
setblock 173 292 405 minecraft:jack_o_lantern
setblock 173 292 407 minecraft:jack_o_lantern
setblock 173 292 409 minecraft:jack_o_lantern
setblock 174 292 370 minecraft:white_concrete
setblock 174 292 400 minecraft:jack_o_lantern
setblock 174 292 402 minecraft:jack_o_lantern
setblock 174 292 404 minecraft:jack_o_lantern
setblock 174 292 406 minecraft:jack_o_lantern
setblock 174 292 408 minecraft:jack_o_lantern
setblock 174 292 410 minecraft:jack_o_lantern
setblock 175 292 401 minecraft:jack_o_lantern
setblock 175 292 403 minecraft:jack_o_lantern
setblock 175 292 405 minecraft:jack_o_lantern
setblock 175 292 407 minecraft:jack_o_lantern
setblock 175 292 409 minecraft:jack_o_lantern
setblock 176 292 400 minecraft:jack_o_lantern
setblock 176 292 402 minecraft:jack_o_lantern
setblock 176 292 404 minecraft:jack_o_lantern
setblock 176 292 406 minecraft:jack_o_lantern
setblock 176 292 408 minecraft:jack_o_lantern
setblock 176 292 410 minecraft:jack_o_lantern
setblock 177 292 401 minecraft:jack_o_lantern
setblock 177 292 403 minecraft:jack_o_lantern
setblock 177 292 405 minecraft:jack_o_lantern
setblock 177 292 407 minecraft:jack_o_lantern
setblock 177 292 409 minecraft:jack_o_lantern
setblock 178 292 400 minecraft:jack_o_lantern
setblock 178 292 402 minecraft:jack_o_lantern
setblock 178 292 404 minecraft:jack_o_lantern
setblock 178 292 406 minecraft:jack_o_lantern
setblock 178 292 408 minecraft:jack_o_lantern
setblock 178 292 410 minecraft:jack_o_lantern
setblock 181 292 370 minecraft:white_concrete
setblock 182 292 376 minecraft:white_concrete
setblock 182 292 383 minecraft:white_concrete
setblock 182 292 390 minecraft:white_concrete
setblock 182 292 397 minecraft:white_concrete
setblock 182 292 404 minecraft:white_concrete
setblock 182 292 410 minecraft:white_concrete
setblock 142 293 374 minecraft:white_concrete
setblock 142 293 381 minecraft:white_concrete
setblock 142 293 388 minecraft:white_concrete
setblock 142 293 395 minecraft:white_concrete
fill 142 293 400 142 294 400 minecraft:white_concrete
fill 142 293 402 142 294 402 minecraft:white_concrete
fill 142 293 404 142 294 404 minecraft:white_concrete
fill 142 293 406 142 294 406 minecraft:white_concrete
fill 142 293 408 142 294 408 minecraft:white_concrete
fill 142 293 410 142 294 410 minecraft:white_concrete
fill 143 293 399 143 294 399 minecraft:white_concrete
fill 143 293 401 143 294 401 minecraft:white_concrete
fill 143 293 403 143 294 403 minecraft:white_concrete
fill 143 293 405 143 294 405 minecraft:white_concrete
fill 143 293 407 143 294 407 minecraft:white_concrete
fill 143 293 409 143 294 409 minecraft:white_concrete
fill 143 293 411 143 294 411 minecraft:purple_terracotta
fill 144 293 400 144 294 400 minecraft:white_concrete
fill 144 293 402 144 294 402 minecraft:white_concrete
fill 144 293 404 144 294 404 minecraft:white_concrete
fill 144 293 406 144 294 406 minecraft:white_concrete
fill 144 293 408 144 294 408 minecraft:white_concrete
fill 144 293 410 144 294 410 minecraft:white_concrete
setblock 145 293 370 minecraft:white_concrete
fill 145 293 399 145 294 399 minecraft:white_concrete
fill 145 293 401 145 294 401 minecraft:white_concrete
fill 145 293 403 145 294 403 minecraft:white_concrete
fill 145 293 405 145 294 405 minecraft:white_concrete
fill 145 293 407 145 294 407 minecraft:white_concrete
fill 145 293 409 145 294 409 minecraft:white_concrete
fill 145 293 411 145 294 411 minecraft:purple_terracotta
fill 146 293 400 146 294 400 minecraft:white_concrete
fill 146 293 402 146 294 402 minecraft:white_concrete
fill 146 293 404 146 294 404 minecraft:white_concrete
fill 146 293 406 146 294 406 minecraft:white_concrete
fill 146 293 408 146 294 408 minecraft:white_concrete
fill 146 293 410 146 294 410 minecraft:white_concrete
fill 147 293 399 147 294 399 minecraft:white_concrete
fill 147 293 401 147 294 401 minecraft:white_concrete
fill 147 293 403 147 294 403 minecraft:white_concrete
fill 147 293 405 147 294 405 minecraft:white_concrete
fill 147 293 407 147 294 407 minecraft:white_concrete
fill 147 293 409 147 294 409 minecraft:white_concrete
fill 147 293 411 147 294 411 minecraft:purple_terracotta
fill 148 293 400 148 294 400 minecraft:white_concrete
fill 148 293 402 148 294 402 minecraft:white_concrete
fill 148 293 404 148 294 404 minecraft:white_concrete
fill 148 293 406 148 294 406 minecraft:white_concrete
fill 148 293 408 148 294 408 minecraft:white_concrete
fill 148 293 410 148 294 410 minecraft:white_concrete
setblock 152 293 370 minecraft:white_concrete
setblock 155 293 410 minecraft:white_concrete
setblock 159 293 370 minecraft:white_concrete
setblock 162 293 410 minecraft:white_concrete
setblock 166 293 370 minecraft:white_concrete
fill 169 293 410 170 293 410 minecraft:white_concrete
fill 170 293 400 170 294 400 minecraft:white_concrete
fill 170 293 402 170 294 402 minecraft:white_concrete
fill 170 293 404 170 294 404 minecraft:white_concrete
fill 170 293 406 170 294 406 minecraft:white_concrete
fill 170 293 408 170 294 408 minecraft:white_concrete
fill 171 293 401 171 294 401 minecraft:white_concrete
fill 171 293 403 171 294 403 minecraft:white_concrete
fill 171 293 405 171 294 405 minecraft:white_concrete
fill 171 293 407 171 294 407 minecraft:white_concrete
fill 171 293 409 171 294 409 minecraft:white_concrete
fill 172 293 400 172 294 400 minecraft:white_concrete
fill 172 293 402 172 294 402 minecraft:white_concrete
fill 172 293 404 172 294 404 minecraft:white_concrete
fill 172 293 406 172 294 406 minecraft:white_concrete
fill 172 293 408 172 294 408 minecraft:white_concrete
fill 172 293 410 172 294 410 minecraft:white_concrete
setblock 173 293 370 minecraft:white_concrete
fill 173 293 401 173 294 401 minecraft:white_concrete
fill 173 293 403 173 294 403 minecraft:white_concrete
fill 173 293 405 173 294 405 minecraft:white_concrete
fill 173 293 407 173 294 407 minecraft:white_concrete
fill 173 293 409 173 294 409 minecraft:white_concrete
fill 174 293 400 174 294 400 minecraft:white_concrete
fill 174 293 402 174 294 402 minecraft:white_concrete
fill 174 293 404 174 294 404 minecraft:white_concrete
fill 174 293 406 174 294 406 minecraft:white_concrete
fill 174 293 408 174 294 408 minecraft:white_concrete
fill 174 293 410 174 294 410 minecraft:white_concrete
fill 175 293 401 175 294 401 minecraft:white_concrete
fill 175 293 403 175 294 403 minecraft:white_concrete
fill 175 293 405 175 294 405 minecraft:white_concrete
fill 175 293 407 175 294 407 minecraft:white_concrete
fill 175 293 409 175 294 409 minecraft:white_concrete
fill 176 293 400 176 294 400 minecraft:white_concrete
fill 176 293 402 176 294 402 minecraft:white_concrete
fill 176 293 404 176 294 404 minecraft:white_concrete
fill 176 293 406 176 294 406 minecraft:white_concrete
fill 176 293 408 176 294 408 minecraft:white_concrete
fill 176 293 410 176 294 410 minecraft:white_concrete
fill 177 293 401 177 294 401 minecraft:white_concrete
fill 177 293 403 177 294 403 minecraft:white_concrete
fill 177 293 405 177 294 405 minecraft:white_concrete
fill 177 293 407 177 294 407 minecraft:white_concrete
fill 177 293 409 177 294 409 minecraft:white_concrete
fill 178 293 400 178 294 400 minecraft:white_concrete
fill 178 293 402 178 294 402 minecraft:white_concrete
fill 178 293 404 178 294 404 minecraft:white_concrete
fill 178 293 406 178 294 406 minecraft:white_concrete
fill 178 293 408 178 294 408 minecraft:white_concrete
fill 178 293 410 178 294 410 minecraft:white_concrete
setblock 180 293 370 minecraft:white_concrete
setblock 182 293 375 minecraft:white_concrete
setblock 182 293 382 minecraft:white_concrete
setblock 182 293 389 minecraft:white_concrete
setblock 182 293 396 minecraft:white_concrete
setblock 182 293 403 minecraft:white_concrete
setblock 170 294 410 minecraft:white_concrete
setblock 142 295 376 minecraft:white_concrete
setblock 142 295 383 minecraft:white_concrete
setblock 142 295 390 minecraft:white_concrete
setblock 142 295 397 minecraft:white_concrete
setblock 142 295 400 minecraft:jack_o_lantern
setblock 142 295 402 minecraft:jack_o_lantern
setblock 142 295 404 minecraft:jack_o_lantern
setblock 142 295 406 minecraft:jack_o_lantern
setblock 142 295 408 minecraft:jack_o_lantern
setblock 142 295 410 minecraft:jack_o_lantern
setblock 143 295 370 minecraft:white_concrete
setblock 143 295 399 minecraft:jack_o_lantern
setblock 143 295 401 minecraft:jack_o_lantern
setblock 143 295 403 minecraft:jack_o_lantern
setblock 143 295 405 minecraft:jack_o_lantern
setblock 143 295 407 minecraft:jack_o_lantern
setblock 143 295 409 minecraft:jack_o_lantern
setblock 143 295 411 minecraft:jack_o_lantern
setblock 144 295 400 minecraft:jack_o_lantern
setblock 144 295 402 minecraft:jack_o_lantern
setblock 144 295 404 minecraft:jack_o_lantern
setblock 144 295 406 minecraft:jack_o_lantern
setblock 144 295 408 minecraft:jack_o_lantern
setblock 144 295 410 minecraft:jack_o_lantern
setblock 145 295 399 minecraft:jack_o_lantern
setblock 145 295 401 minecraft:jack_o_lantern
setblock 145 295 403 minecraft:jack_o_lantern
setblock 145 295 405 minecraft:jack_o_lantern
setblock 145 295 407 minecraft:jack_o_lantern
setblock 145 295 409 minecraft:jack_o_lantern
setblock 145 295 411 minecraft:jack_o_lantern
setblock 146 295 400 minecraft:jack_o_lantern
setblock 146 295 402 minecraft:jack_o_lantern
setblock 146 295 404 minecraft:jack_o_lantern
setblock 146 295 406 minecraft:jack_o_lantern
setblock 146 295 408 minecraft:jack_o_lantern
setblock 146 295 410 minecraft:jack_o_lantern
setblock 147 295 399 minecraft:jack_o_lantern
setblock 147 295 401 minecraft:jack_o_lantern
setblock 147 295 403 minecraft:jack_o_lantern
setblock 147 295 405 minecraft:jack_o_lantern
setblock 147 295 407 minecraft:jack_o_lantern
setblock 147 295 409 minecraft:jack_o_lantern
setblock 147 295 411 minecraft:jack_o_lantern
setblock 148 295 400 minecraft:jack_o_lantern
setblock 148 295 402 minecraft:jack_o_lantern
setblock 148 295 404 minecraft:jack_o_lantern
setblock 148 295 406 minecraft:jack_o_lantern
setblock 148 295 408 minecraft:jack_o_lantern
setblock 148 295 410 minecraft:jack_o_lantern
setblock 150 295 370 minecraft:white_concrete
setblock 150 295 410 minecraft:white_concrete
setblock 157 295 370 minecraft:white_concrete
setblock 157 295 410 minecraft:white_concrete
setblock 164 295 370 minecraft:white_concrete
setblock 164 295 410 minecraft:white_concrete
setblock 170 295 400 minecraft:jack_o_lantern
setblock 170 295 402 minecraft:jack_o_lantern
setblock 170 295 404 minecraft:jack_o_lantern
setblock 170 295 406 minecraft:jack_o_lantern
setblock 170 295 408 minecraft:jack_o_lantern
setblock 170 295 410 minecraft:jack_o_lantern
setblock 171 295 370 minecraft:white_concrete
setblock 171 295 401 minecraft:jack_o_lantern
setblock 171 295 403 minecraft:jack_o_lantern
setblock 171 295 405 minecraft:jack_o_lantern
setblock 171 295 407 minecraft:jack_o_lantern
setblock 171 295 409 minecraft:jack_o_lantern
setblock 172 295 400 minecraft:jack_o_lantern
setblock 172 295 402 minecraft:jack_o_lantern
setblock 172 295 404 minecraft:jack_o_lantern
setblock 172 295 406 minecraft:jack_o_lantern
setblock 172 295 408 minecraft:jack_o_lantern
setblock 172 295 410 minecraft:jack_o_lantern
setblock 173 295 401 minecraft:jack_o_lantern
setblock 173 295 403 minecraft:jack_o_lantern
setblock 173 295 405 minecraft:jack_o_lantern
setblock 173 295 407 minecraft:jack_o_lantern
setblock 173 295 409 minecraft:jack_o_lantern
setblock 174 295 400 minecraft:jack_o_lantern
setblock 174 295 402 minecraft:jack_o_lantern
setblock 174 295 404 minecraft:jack_o_lantern
setblock 174 295 406 minecraft:jack_o_lantern
setblock 174 295 408 minecraft:jack_o_lantern
setblock 174 295 410 minecraft:jack_o_lantern
setblock 175 295 401 minecraft:jack_o_lantern
setblock 175 295 403 minecraft:jack_o_lantern
setblock 175 295 405 minecraft:jack_o_lantern
setblock 175 295 407 minecraft:jack_o_lantern
setblock 175 295 409 minecraft:jack_o_lantern
setblock 176 295 400 minecraft:jack_o_lantern
setblock 176 295 402 minecraft:jack_o_lantern
setblock 176 295 404 minecraft:jack_o_lantern
setblock 176 295 406 minecraft:jack_o_lantern
setblock 176 295 408 minecraft:jack_o_lantern
setblock 176 295 410 minecraft:jack_o_lantern
setblock 177 295 401 minecraft:jack_o_lantern
setblock 177 295 403 minecraft:jack_o_lantern
setblock 177 295 405 minecraft:jack_o_lantern
setblock 177 295 407 minecraft:jack_o_lantern
setblock 177 295 409 minecraft:jack_o_lantern
setblock 178 295 370 minecraft:white_concrete
setblock 178 295 400 minecraft:jack_o_lantern
setblock 178 295 402 minecraft:jack_o_lantern
setblock 178 295 404 minecraft:jack_o_lantern
setblock 178 295 406 minecraft:jack_o_lantern
setblock 178 295 408 minecraft:jack_o_lantern
setblock 178 295 410 minecraft:jack_o_lantern
setblock 182 295 373 minecraft:white_concrete
setblock 182 295 380 minecraft:white_concrete
setblock 182 295 387 minecraft:white_concrete
setblock 182 295 394 minecraft:white_concrete
setblock 182 295 401 minecraft:white_concrete
setblock 182 295 408 minecraft:white_concrete
setblock 142 296 370 minecraft:white_concrete
setblock 142 296 377 minecraft:white_concrete
setblock 142 296 384 minecraft:white_concrete
setblock 142 296 391 minecraft:white_concrete
setblock 142 296 398 minecraft:white_concrete
fill 142 296 400 142 297 400 minecraft:white_concrete
fill 142 296 402 142 297 402 minecraft:white_concrete
fill 142 296 404 142 297 404 minecraft:white_concrete
fill 142 296 406 142 297 406 minecraft:white_concrete
fill 142 296 408 142 297 408 minecraft:white_concrete
fill 142 296 410 142 297 410 minecraft:white_concrete
fill 143 296 399 143 297 399 minecraft:white_concrete
fill 143 296 401 143 297 401 minecraft:white_concrete
fill 143 296 403 143 297 403 minecraft:white_concrete
fill 143 296 405 143 297 405 minecraft:white_concrete
fill 143 296 407 143 297 407 minecraft:white_concrete
fill 143 296 409 143 297 409 minecraft:white_concrete
fill 143 296 411 143 297 411 minecraft:purple_terracotta
fill 144 296 400 144 297 400 minecraft:white_concrete
fill 144 296 402 144 297 402 minecraft:white_concrete
fill 144 296 404 144 297 404 minecraft:white_concrete
fill 144 296 406 144 297 406 minecraft:white_concrete
fill 144 296 408 144 297 408 minecraft:white_concrete
fill 144 296 410 144 297 410 minecraft:white_concrete
fill 145 296 399 145 297 399 minecraft:white_concrete
fill 145 296 401 145 297 401 minecraft:white_concrete
fill 145 296 403 145 297 403 minecraft:white_concrete
fill 145 296 405 145 297 405 minecraft:white_concrete
fill 145 296 407 145 297 407 minecraft:white_concrete
fill 145 296 409 145 297 409 minecraft:white_concrete
fill 145 296 411 145 297 411 minecraft:purple_terracotta
fill 146 296 400 146 297 400 minecraft:white_concrete
fill 146 296 402 146 297 402 minecraft:white_concrete
fill 146 296 404 146 297 404 minecraft:white_concrete
fill 146 296 406 146 297 406 minecraft:white_concrete
fill 146 296 408 146 297 408 minecraft:white_concrete
fill 146 296 410 146 297 410 minecraft:white_concrete
fill 147 296 399 147 297 399 minecraft:white_concrete
fill 147 296 401 147 297 401 minecraft:white_concrete
fill 147 296 403 147 297 403 minecraft:white_concrete
fill 147 296 405 147 297 405 minecraft:white_concrete
fill 147 296 407 147 297 407 minecraft:white_concrete
fill 147 296 409 147 297 409 minecraft:white_concrete
fill 147 296 411 147 297 411 minecraft:purple_terracotta
fill 148 296 400 148 297 400 minecraft:white_concrete
fill 148 296 402 148 297 402 minecraft:white_concrete
fill 148 296 404 148 297 404 minecraft:white_concrete
fill 148 296 406 148 297 406 minecraft:white_concrete
fill 148 296 408 148 297 408 minecraft:white_concrete
fill 148 296 410 148 297 410 minecraft:white_concrete
setblock 149 296 370 minecraft:white_concrete
setblock 151 296 410 minecraft:white_concrete
setblock 156 296 370 minecraft:white_concrete
setblock 158 296 410 minecraft:white_concrete
setblock 163 296 370 minecraft:white_concrete
setblock 165 296 410 minecraft:white_concrete
setblock 170 296 370 minecraft:white_concrete
fill 170 296 400 170 297 400 minecraft:white_concrete
fill 170 296 402 170 297 402 minecraft:white_concrete
fill 170 296 404 170 297 404 minecraft:white_concrete
fill 170 296 406 170 297 406 minecraft:white_concrete
fill 170 296 408 170 297 408 minecraft:white_concrete
fill 170 296 410 170 297 410 minecraft:white_concrete
fill 171 296 401 171 297 401 minecraft:white_concrete
fill 171 296 403 171 297 403 minecraft:white_concrete
fill 171 296 405 171 297 405 minecraft:white_concrete
fill 171 296 407 171 297 407 minecraft:white_concrete
fill 171 296 409 171 297 409 minecraft:white_concrete
fill 172 296 400 172 297 400 minecraft:white_concrete
fill 172 296 402 172 297 402 minecraft:white_concrete
fill 172 296 404 172 297 404 minecraft:white_concrete
fill 172 296 406 172 297 406 minecraft:white_concrete
fill 172 296 408 172 297 408 minecraft:white_concrete
fill 172 296 410 172 297 410 minecraft:white_concrete
fill 173 296 401 173 297 401 minecraft:white_concrete
fill 173 296 403 173 297 403 minecraft:white_concrete
fill 173 296 405 173 297 405 minecraft:white_concrete
fill 173 296 407 173 297 407 minecraft:white_concrete
fill 173 296 409 173 297 409 minecraft:white_concrete
fill 174 296 400 174 297 400 minecraft:white_concrete
fill 174 296 402 174 297 402 minecraft:white_concrete
fill 174 296 404 174 297 404 minecraft:white_concrete
fill 174 296 406 174 297 406 minecraft:white_concrete
fill 174 296 408 174 297 408 minecraft:white_concrete
fill 174 296 410 174 297 410 minecraft:white_concrete
fill 175 296 401 175 297 401 minecraft:white_concrete
fill 175 296 403 175 297 403 minecraft:white_concrete
fill 175 296 405 175 297 405 minecraft:white_concrete
fill 175 296 407 175 297 407 minecraft:white_concrete
fill 175 296 409 175 297 409 minecraft:white_concrete
fill 176 296 400 176 297 400 minecraft:white_concrete
fill 176 296 402 176 297 402 minecraft:white_concrete
fill 176 296 404 176 297 404 minecraft:white_concrete
fill 176 296 406 176 297 406 minecraft:white_concrete
fill 176 296 408 176 297 408 minecraft:white_concrete
fill 176 296 410 176 297 410 minecraft:white_concrete
setblock 177 296 370 minecraft:white_concrete
fill 177 296 401 177 297 401 minecraft:white_concrete
fill 177 296 403 177 297 403 minecraft:white_concrete
fill 177 296 405 177 297 405 minecraft:white_concrete
fill 177 296 407 177 297 407 minecraft:white_concrete
fill 177 296 409 177 297 409 minecraft:white_concrete
fill 178 296 400 178 297 400 minecraft:white_concrete
fill 178 296 402 178 297 402 minecraft:white_concrete
fill 178 296 404 178 297 404 minecraft:white_concrete
fill 178 296 406 178 297 406 minecraft:white_concrete
fill 178 296 408 178 297 408 minecraft:white_concrete
fill 178 296 410 179 296 410 minecraft:white_concrete
setblock 182 296 372 minecraft:white_concrete
setblock 182 296 379 minecraft:white_concrete
setblock 182 296 386 minecraft:white_concrete
setblock 182 296 393 minecraft:white_concrete
setblock 182 296 400 minecraft:white_concrete
setblock 182 296 407 minecraft:white_concrete
setblock 142 297 371 minecraft:white_concrete
setblock 142 297 378 minecraft:white_concrete
setblock 142 297 385 minecraft:white_concrete
setblock 142 297 392 minecraft:white_concrete
setblock 148 297 370 minecraft:white_concrete
setblock 152 297 410 minecraft:white_concrete
setblock 155 297 370 minecraft:white_concrete
setblock 159 297 410 minecraft:white_concrete
setblock 162 297 370 minecraft:white_concrete
setblock 166 297 410 minecraft:white_concrete
setblock 169 297 370 minecraft:white_concrete
setblock 176 297 370 minecraft:white_concrete
setblock 178 297 410 minecraft:white_concrete
setblock 180 297 410 minecraft:white_concrete
setblock 182 297 371 minecraft:white_concrete
setblock 182 297 378 minecraft:white_concrete
setblock 182 297 385 minecraft:white_concrete
setblock 182 297 392 minecraft:white_concrete
setblock 182 297 399 minecraft:white_concrete
setblock 182 297 406 minecraft:white_concrete
setblock 142 298 372 minecraft:white_concrete
setblock 142 298 379 minecraft:white_concrete
setblock 142 298 386 minecraft:white_concrete
setblock 142 298 393 minecraft:white_concrete
setblock 142 298 400 minecraft:jack_o_lantern
setblock 142 298 402 minecraft:jack_o_lantern
setblock 142 298 404 minecraft:jack_o_lantern
setblock 142 298 406 minecraft:jack_o_lantern
setblock 142 298 408 minecraft:jack_o_lantern
setblock 142 298 410 minecraft:jack_o_lantern
setblock 143 298 399 minecraft:jack_o_lantern
setblock 143 298 401 minecraft:jack_o_lantern
setblock 143 298 403 minecraft:jack_o_lantern
setblock 143 298 405 minecraft:jack_o_lantern
setblock 143 298 407 minecraft:jack_o_lantern
setblock 143 298 409 minecraft:jack_o_lantern
setblock 143 298 411 minecraft:jack_o_lantern
setblock 144 298 400 minecraft:jack_o_lantern
setblock 144 298 402 minecraft:jack_o_lantern
setblock 144 298 404 minecraft:jack_o_lantern
setblock 144 298 406 minecraft:jack_o_lantern
setblock 144 298 408 minecraft:jack_o_lantern
setblock 144 298 410 minecraft:jack_o_lantern
setblock 145 298 399 minecraft:jack_o_lantern
setblock 145 298 401 minecraft:jack_o_lantern
setblock 145 298 403 minecraft:jack_o_lantern
setblock 145 298 405 minecraft:jack_o_lantern
setblock 145 298 407 minecraft:jack_o_lantern
setblock 145 298 409 minecraft:jack_o_lantern
setblock 145 298 411 minecraft:jack_o_lantern
setblock 146 298 400 minecraft:jack_o_lantern
setblock 146 298 402 minecraft:jack_o_lantern
setblock 146 298 404 minecraft:jack_o_lantern
setblock 146 298 406 minecraft:jack_o_lantern
setblock 146 298 408 minecraft:jack_o_lantern
setblock 146 298 410 minecraft:jack_o_lantern
setblock 147 298 370 minecraft:white_concrete
setblock 147 298 399 minecraft:jack_o_lantern
setblock 147 298 401 minecraft:jack_o_lantern
setblock 147 298 403 minecraft:jack_o_lantern
setblock 147 298 405 minecraft:jack_o_lantern
setblock 147 298 407 minecraft:jack_o_lantern
setblock 147 298 409 minecraft:jack_o_lantern
setblock 147 298 411 minecraft:jack_o_lantern
setblock 148 298 400 minecraft:jack_o_lantern
setblock 148 298 402 minecraft:jack_o_lantern
setblock 148 298 404 minecraft:jack_o_lantern
setblock 148 298 406 minecraft:jack_o_lantern
setblock 148 298 408 minecraft:jack_o_lantern
setblock 148 298 410 minecraft:jack_o_lantern
setblock 153 298 410 minecraft:white_concrete
setblock 154 298 370 minecraft:white_concrete
setblock 160 298 410 minecraft:white_concrete
setblock 161 298 370 minecraft:white_concrete
setblock 167 298 410 minecraft:white_concrete
setblock 168 298 370 minecraft:white_concrete
setblock 170 298 400 minecraft:jack_o_lantern
setblock 170 298 402 minecraft:jack_o_lantern
setblock 170 298 404 minecraft:jack_o_lantern
setblock 170 298 406 minecraft:jack_o_lantern
setblock 170 298 408 minecraft:jack_o_lantern
setblock 170 298 410 minecraft:jack_o_lantern
setblock 171 298 401 minecraft:jack_o_lantern
setblock 171 298 403 minecraft:jack_o_lantern
setblock 171 298 405 minecraft:jack_o_lantern
setblock 171 298 407 minecraft:jack_o_lantern
setblock 171 298 409 minecraft:jack_o_lantern
setblock 172 298 400 minecraft:jack_o_lantern
setblock 172 298 402 minecraft:jack_o_lantern
setblock 172 298 404 minecraft:jack_o_lantern
setblock 172 298 406 minecraft:jack_o_lantern
setblock 172 298 408 minecraft:jack_o_lantern
setblock 172 298 410 minecraft:jack_o_lantern
setblock 173 298 401 minecraft:jack_o_lantern
setblock 173 298 403 minecraft:jack_o_lantern
setblock 173 298 405 minecraft:jack_o_lantern
setblock 173 298 407 minecraft:jack_o_lantern
setblock 173 298 409 minecraft:jack_o_lantern
setblock 174 298 400 minecraft:jack_o_lantern
setblock 174 298 402 minecraft:jack_o_lantern
setblock 174 298 404 minecraft:jack_o_lantern
setblock 174 298 406 minecraft:jack_o_lantern
setblock 174 298 408 minecraft:jack_o_lantern
setblock 174 298 410 minecraft:jack_o_lantern
setblock 175 298 370 minecraft:white_concrete
setblock 175 298 401 minecraft:jack_o_lantern
setblock 175 298 403 minecraft:jack_o_lantern
setblock 175 298 405 minecraft:jack_o_lantern
setblock 175 298 407 minecraft:jack_o_lantern
setblock 175 298 409 minecraft:jack_o_lantern
setblock 176 298 400 minecraft:jack_o_lantern
setblock 176 298 402 minecraft:jack_o_lantern
setblock 176 298 404 minecraft:jack_o_lantern
setblock 176 298 406 minecraft:jack_o_lantern
setblock 176 298 408 minecraft:jack_o_lantern
setblock 176 298 410 minecraft:jack_o_lantern
setblock 177 298 401 minecraft:jack_o_lantern
setblock 177 298 403 minecraft:jack_o_lantern
setblock 177 298 405 minecraft:jack_o_lantern
setblock 177 298 407 minecraft:jack_o_lantern
setblock 177 298 409 minecraft:jack_o_lantern
setblock 178 298 400 minecraft:jack_o_lantern
setblock 178 298 402 minecraft:jack_o_lantern
setblock 178 298 404 minecraft:jack_o_lantern
setblock 178 298 406 minecraft:jack_o_lantern
setblock 178 298 408 minecraft:jack_o_lantern
setblock 178 298 410 minecraft:jack_o_lantern
fill 179 298 380 181 299 380 minecraft:gray_concrete
setblock 181 298 410 minecraft:white_concrete
setblock 182 298 370 minecraft:white_concrete
setblock 182 298 377 minecraft:white_concrete
setblock 182 298 384 minecraft:white_concrete
setblock 182 298 391 minecraft:white_concrete
setblock 182 298 398 minecraft:white_concrete
setblock 182 298 405 minecraft:white_concrete
fill 142 299 373 142 300 373 minecraft:white_concrete
fill 142 299 380 142 300 380 minecraft:white_concrete
fill 142 299 387 142 300 387 minecraft:white_concrete
fill 142 299 394 142 300 394 minecraft:white_concrete
fill 142 299 400 142 300 400 minecraft:white_concrete
fill 142 299 402 142 300 402 minecraft:white_concrete
fill 142 299 404 142 300 404 minecraft:white_concrete
fill 142 299 406 142 300 406 minecraft:white_concrete
fill 142 299 408 142 300 408 minecraft:white_concrete
fill 142 299 410 142 300 410 minecraft:white_concrete
fill 143 299 399 143 300 399 minecraft:white_concrete
fill 143 299 401 143 300 401 minecraft:white_concrete
fill 143 299 403 143 300 403 minecraft:white_concrete
fill 143 299 405 143 300 405 minecraft:white_concrete
fill 143 299 407 143 300 407 minecraft:white_concrete
fill 143 299 409 143 300 409 minecraft:white_concrete
fill 143 299 411 143 307 411 minecraft:purple_terracotta
setblock 144 299 372 minecraft:light[level=14]
setblock 144 299 380 minecraft:light[level=14]
setblock 144 299 388 minecraft:light[level=14]
setblock 144 299 396 minecraft:light[level=14]
fill 144 299 400 144 300 400 minecraft:white_concrete
fill 144 299 402 144 300 402 minecraft:white_concrete
fill 144 299 404 144 300 404 minecraft:white_concrete
fill 144 299 406 144 300 406 minecraft:white_concrete
fill 144 299 408 144 300 408 minecraft:white_concrete
fill 144 299 410 144 300 410 minecraft:white_concrete
fill 145 299 399 145 300 399 minecraft:white_concrete
fill 145 299 401 145 300 401 minecraft:white_concrete
fill 145 299 403 145 300 403 minecraft:white_concrete
fill 145 299 405 145 300 405 minecraft:white_concrete
fill 145 299 407 145 300 407 minecraft:white_concrete
fill 145 299 409 145 300 409 minecraft:white_concrete
fill 145 299 411 145 307 411 minecraft:purple_terracotta
fill 146 299 370 146 300 370 minecraft:white_concrete
fill 146 299 400 146 300 400 minecraft:white_concrete
fill 146 299 402 146 300 402 minecraft:white_concrete
fill 146 299 404 146 300 404 minecraft:white_concrete
fill 146 299 406 146 300 406 minecraft:white_concrete
fill 146 299 408 146 300 408 minecraft:white_concrete
fill 146 299 410 146 300 410 minecraft:white_concrete
fill 147 299 399 147 300 399 minecraft:white_concrete
fill 147 299 401 147 300 401 minecraft:white_concrete
fill 147 299 403 147 300 403 minecraft:white_concrete
fill 147 299 405 147 300 405 minecraft:white_concrete
fill 147 299 407 147 300 407 minecraft:white_concrete
fill 147 299 409 147 300 409 minecraft:white_concrete
fill 147 299 411 147 307 411 minecraft:purple_terracotta
fill 148 299 400 148 300 400 minecraft:white_concrete
fill 148 299 402 148 300 402 minecraft:white_concrete
fill 148 299 404 148 300 404 minecraft:white_concrete
fill 148 299 406 148 300 406 minecraft:white_concrete
fill 148 299 408 148 300 408 minecraft:white_concrete
fill 148 299 410 148 300 410 minecraft:white_concrete
setblock 152 299 372 minecraft:light[level=14]
setblock 152 299 380 minecraft:light[level=14]
setblock 152 299 388 minecraft:light[level=14]
setblock 152 299 396 minecraft:light[level=14]
setblock 152 299 404 minecraft:light[level=14]
fill 153 299 370 153 300 370 minecraft:white_concrete
fill 154 299 410 154 300 410 minecraft:white_concrete
fill 160 299 370 160 300 370 minecraft:white_concrete
setblock 160 299 372 minecraft:light[level=14]
setblock 160 299 380 minecraft:light[level=14]
setblock 160 299 388 minecraft:light[level=14]
setblock 160 299 396 minecraft:light[level=14]
setblock 160 299 404 minecraft:light[level=14]
fill 161 299 410 161 300 410 minecraft:white_concrete
fill 167 299 370 167 300 370 minecraft:white_concrete
setblock 168 299 372 minecraft:light[level=14]
setblock 168 299 380 minecraft:light[level=14]
setblock 168 299 388 minecraft:light[level=14]
setblock 168 299 396 minecraft:light[level=14]
setblock 168 299 404 minecraft:light[level=14]
fill 168 299 410 168 300 410 minecraft:white_concrete
fill 170 299 400 170 300 400 minecraft:white_concrete
fill 170 299 402 170 300 402 minecraft:white_concrete
fill 170 299 404 170 300 404 minecraft:white_concrete
fill 170 299 406 170 300 406 minecraft:white_concrete
fill 170 299 408 170 300 408 minecraft:white_concrete
fill 170 299 410 170 300 410 minecraft:white_concrete
fill 171 299 401 171 300 401 minecraft:white_concrete
fill 171 299 403 171 300 403 minecraft:white_concrete
fill 171 299 405 171 300 405 minecraft:white_concrete
fill 171 299 407 171 300 407 minecraft:white_concrete
fill 171 299 409 171 300 409 minecraft:white_concrete
fill 172 299 400 172 300 400 minecraft:white_concrete
fill 172 299 402 172 300 402 minecraft:white_concrete
fill 172 299 404 172 300 404 minecraft:white_concrete
fill 172 299 406 172 300 406 minecraft:white_concrete
fill 172 299 408 172 300 408 minecraft:white_concrete
fill 172 299 410 172 300 410 minecraft:white_concrete
fill 173 299 401 173 300 401 minecraft:white_concrete
fill 173 299 403 173 300 403 minecraft:white_concrete
fill 173 299 405 173 300 405 minecraft:white_concrete
fill 173 299 407 173 300 407 minecraft:white_concrete
fill 173 299 409 173 300 409 minecraft:white_concrete
fill 174 299 370 174 300 370 minecraft:white_concrete
fill 174 299 400 174 300 400 minecraft:white_concrete
fill 174 299 402 174 300 402 minecraft:white_concrete
fill 174 299 404 174 300 404 minecraft:white_concrete
fill 174 299 406 174 300 406 minecraft:white_concrete
fill 174 299 408 174 300 408 minecraft:white_concrete
fill 174 299 410 174 300 410 minecraft:white_concrete
fill 175 299 401 175 300 401 minecraft:white_concrete
fill 175 299 403 175 300 403 minecraft:white_concrete
fill 175 299 405 175 300 405 minecraft:white_concrete
fill 175 299 407 175 300 407 minecraft:white_concrete
fill 175 299 409 175 300 409 minecraft:white_concrete
setblock 176 299 372 minecraft:light[level=14]
setblock 176 299 380 minecraft:light[level=14]
setblock 176 299 388 minecraft:light[level=14]
setblock 176 299 396 minecraft:light[level=14]
fill 176 299 400 176 300 400 minecraft:white_concrete
fill 176 299 402 176 300 402 minecraft:white_concrete
fill 176 299 404 176 300 404 minecraft:white_concrete
fill 176 299 406 176 300 406 minecraft:white_concrete
fill 176 299 408 176 300 408 minecraft:white_concrete
fill 176 299 410 176 300 410 minecraft:white_concrete
fill 177 299 401 177 300 401 minecraft:white_concrete
fill 177 299 403 177 300 403 minecraft:white_concrete
fill 177 299 405 177 300 405 minecraft:white_concrete
fill 177 299 407 177 300 407 minecraft:white_concrete
fill 177 299 409 177 300 409 minecraft:white_concrete
fill 178 299 400 178 300 400 minecraft:white_concrete
fill 178 299 402 178 300 402 minecraft:white_concrete
fill 178 299 404 178 300 404 minecraft:white_concrete
fill 178 299 406 178 300 406 minecraft:white_concrete
fill 178 299 408 178 300 408 minecraft:white_concrete
fill 178 299 410 178 300 410 minecraft:white_concrete
fill 181 299 370 181 300 370 minecraft:white_concrete
fill 182 299 376 182 300 376 minecraft:white_concrete
fill 182 299 383 182 300 383 minecraft:white_concrete
fill 182 299 390 182 300 390 minecraft:white_concrete
fill 182 299 397 182 300 397 minecraft:white_concrete
fill 182 299 404 182 300 404 minecraft:white_concrete
fill 182 299 410 182 300 410 minecraft:white_concrete
fill 142 300 370 142 300 372 minecraft:white_concrete
setblock 142 300 374 minecraft:white_concrete
fill 142 300 376 142 300 379 minecraft:white_concrete
setblock 142 300 381 minecraft:white_concrete
fill 142 300 383 142 300 386 minecraft:white_concrete
setblock 142 300 388 minecraft:white_concrete
fill 142 300 390 142 300 393 minecraft:white_concrete
setblock 142 300 395 minecraft:white_concrete
fill 142 300 397 142 300 398 minecraft:white_concrete
setblock 143 300 370 minecraft:white_concrete
setblock 145 300 370 minecraft:white_concrete
fill 147 300 370 150 300 370 minecraft:white_concrete
fill 150 300 410 153 300 410 minecraft:white_concrete
setblock 152 300 370 minecraft:white_concrete
fill 154 300 370 157 300 370 minecraft:white_concrete
setblock 155 300 410 minecraft:white_concrete
fill 157 300 410 160 300 410 minecraft:white_concrete
setblock 159 300 370 minecraft:white_concrete
fill 161 300 370 164 300 370 minecraft:white_concrete
setblock 162 300 410 minecraft:white_concrete
fill 164 300 410 167 300 410 minecraft:white_concrete
setblock 166 300 370 minecraft:white_concrete
fill 168 300 370 171 300 370 minecraft:white_concrete
setblock 169 300 410 minecraft:white_concrete
setblock 173 300 370 minecraft:white_concrete
fill 175 300 370 178 300 370 minecraft:white_concrete
fill 179 300 410 181 300 410 minecraft:white_concrete
setblock 180 300 370 minecraft:white_concrete
fill 182 300 370 182 300 373 minecraft:white_concrete
setblock 182 300 375 minecraft:white_concrete
fill 182 300 377 182 300 380 minecraft:white_concrete
setblock 182 300 382 minecraft:white_concrete
fill 182 300 384 182 300 387 minecraft:white_concrete
setblock 182 300 389 minecraft:white_concrete
fill 182 300 391 182 300 394 minecraft:white_concrete
setblock 182 300 396 minecraft:white_concrete
fill 182 300 398 182 300 401 minecraft:white_concrete
setblock 182 300 403 minecraft:white_concrete
fill 182 300 405 182 300 408 minecraft:white_concrete
