setblock 293 106 639 minecraft:light[level=13]
setblock 294 106 604 minecraft:amethyst_block
setblock 296 106 646 minecraft:black_concrete
fill 299 106 646 299 108 646 minecraft:black_concrete
setblock 300 106 646 minecraft:purple_concrete
setblock 301 106 604 minecraft:purple_concrete
setblock 301 106 607 minecraft:light[level=13]
setblock 301 106 615 minecraft:light[level=13]
setblock 301 106 623 minecraft:light[level=13]
setblock 301 106 631 minecraft:light[level=13]
setblock 301 106 639 minecraft:light[level=13]
setblock 302 106 646 minecraft:purple_concrete
setblock 305 106 646 minecraft:purple_concrete
setblock 307 106 604 minecraft:white_concrete
setblock 308 106 646 minecraft:purple_concrete
setblock 309 106 607 minecraft:light[level=13]
setblock 309 106 615 minecraft:light[level=13]
setblock 309 106 623 minecraft:light[level=13]
setblock 309 106 631 minecraft:light[level=13]
setblock 309 106 639 minecraft:light[level=13]
fill 309 106 646 309 108 646 minecraft:black_concrete
fill 310 106 604 310 108 604 minecraft:black_concrete
fill 311 106 646 311 108 646 minecraft:black_concrete
fill 312 106 604 312 108 604 minecraft:black_concrete
fill 314 106 646 314 108 646 minecraft:black_concrete
setblock 317 106 607 minecraft:light[level=13]
setblock 317 106 615 minecraft:light[level=13]
setblock 317 106 623 minecraft:light[level=13]
setblock 317 106 631 minecraft:light[level=13]
setblock 317 106 639 minecraft:light[level=13]
fill 319 106 646 319 108 646 minecraft:black_concrete
fill 320 106 604 322 106 604 minecraft:black_concrete
setblock 322 106 646 minecraft:purple_concrete
setblock 324 106 606 minecraft:purple_concrete
setblock 324 106 613 minecraft:purple_concrete
fill 324 106 623 324 108 623 minecraft:black_concrete
setblock 324 106 625 minecraft:purple_concrete
fill 324 106 626 324 108 626 minecraft:black_concrete
fill 324 106 628 324 108 628 minecraft:black_concrete
setblock 324 106 630 minecraft:purple_concrete
setblock 324 106 632 minecraft:purple_concrete
fill 324 106 635 324 108 635 minecraft:black_concrete
setblock 324 106 640 minecraft:purple_concrete
fill 324 106 646 324 111 646 minecraft:black_concrete
fill 282 107 606 282 108 606 minecraft:black_concrete
setblock 282 107 608 minecraft:purple_concrete
fill 282 107 610 282 109 610 minecraft:black_concrete
setblock 282 107 611 minecraft:purple_concrete
fill 282 107 612 282 108 612 minecraft:black_concrete
setblock 282 107 617 minecraft:purple_concrete
fill 282 107 629 282 108 629 minecraft:black_concrete
fill 282 107 632 282 108 632 minecraft:black_concrete
setblock 282 107 635 minecraft:purple_concrete
fill 282 107 636 282 108 636 minecraft:black_concrete
fill 282 107 639 282 108 639 minecraft:black_concrete
fill 283 107 634 284 110 636 minecraft:amethyst_block
setblock 284 107 604 minecraft:purple_concrete
fill 285 107 634 286 107 634 minecraft:amethyst_block
fill 285 107 636 286 107 636 minecraft:amethyst_block
fill 287 107 646 287 108 646 minecraft:black_concrete
setblock 291 107 646 minecraft:purple_concrete
setblock 293 107 646 minecraft:purple_concrete
setblock 294 107 604 minecraft:black_concrete
setblock 296 107 646 minecraft:purple_concrete
setblock 300 107 604 minecraft:purple_concrete
fill 300 107 646 300 108 646 minecraft:black_concrete
fill 301 107 604 301 108 604 minecraft:black_concrete
fill 302 107 646 302 108 646 minecraft:black_concrete
fill 305 107 646 305 109 646 minecraft:black_concrete
fill 307 107 604 307 108 604 minecraft:black_concrete
fill 308 107 646 308 108 646 minecraft:black_concrete
fill 313 107 640 314 108 641 minecraft:obsidian
fill 314 107 639 314 108 639 minecraft:obsidian
setblock 316 107 646 minecraft:purple_concrete
setblock 320 107 604 minecraft:purple_concrete
fill 320 107 646 320 108 646 minecraft:black_concrete
fill 321 107 604 322 108 604 minecraft:black_concrete
setblock 321 107 646 minecraft:purple_concrete
fill 322 107 646 322 108 646 minecraft:black_concrete
setblock 324 107 606 minecraft:black_concrete
setblock 324 107 610 minecraft:purple_concrete
fill 324 107 613 324 108 613 minecraft:black_concrete
fill 324 107 615 324 107 616 minecraft:purple_concrete
fill 324 107 625 324 108 625 minecraft:black_concrete
fill 324 107 630 324 108 630 minecraft:black_concrete
fill 324 107 632 324 108 632 minecraft:black_concrete
fill 324 107 638 324 108 638 minecraft:black_concrete
fill 324 107 640 324 109 640 minecraft:black_concrete
fill 324 107 643 324 108 643 minecraft:black_concrete
setblock 282 108 608 minecraft:black_concrete
setblock 282 108 611 minecraft:black_concrete
setblock 282 108 617 minecraft:black_concrete
setblock 282 108 635 minecraft:black_concrete
fill 283 108 633 283 109 633 minecraft:amethyst_block
fill 283 108 637 283 109 637 minecraft:amethyst_block
setblock 284 108 604 minecraft:black_concrete
fill 285 108 634 285 109 636 minecraft:amethyst_block
setblock 286 108 635 minecraft:amethyst_block
setblock 291 108 646 minecraft:black_concrete
setblock 293 108 646 minecraft:black_concrete
setblock 294 108 604 minecraft:pearlescent_froglight
setblock 296 108 646 minecraft:black_concrete
setblock 300 108 604 minecraft:black_concrete
setblock 316 108 646 minecraft:black_concrete
setblock 320 108 604 minecraft:amethyst_block
setblock 321 108 646 minecraft:black_concrete
setblock 324 108 606 minecraft:white_concrete
setblock 324 108 610 minecraft:black_concrete
fill 324 108 615 324 108 616 minecraft:black_concrete
fill 282 109 604 282 114 606 minecraft:purple_concrete
fill 282 109 608 282 123 609 minecraft:purple_concrete
fill 282 109 611 282 162 611 minecraft:purple_concrete
fill 282 109 612 282 110 612 minecraft:gold_block
fill 282 109 613 282 109 626 minecraft:purple_concrete
fill 282 109 628 282 110 628 minecraft:gold_block
fill 282 109 629 282 121 632 minecraft:purple_concrete
fill 282 109 634 282 110 641 minecraft:purple_concrete
fill 282 109 643 282 175 643 minecraft:purple_concrete
fill 282 109 644 282 110 644 minecraft:gold_block
setblock 282 109 645 minecraft:pearlescent_froglight
fill 282 109 646 294 109 646 minecraft:purple_concrete
fill 283 109 604 285 110 604 minecraft:purple_concrete
fill 286 109 604 286 110 604 minecraft:gold_block
fill 287 109 604 294 109 604 minecraft:purple_concrete
fill 294 109 607 295 110 609 minecraft:end_stone
fill 296 109 604 301 109 604 minecraft:purple_concrete
fill 296 109 646 296 110 646 minecraft:gold_block
fill 297 109 646 300 109 646 minecraft:purple_concrete
fill 302 109 604 302 110 604 minecraft:gold_block
fill 302 109 646 303 138 646 minecraft:purple_concrete
fill 303 109 604 308 110 604 minecraft:purple_concrete
fill 306 109 646 311 110 646 minecraft:purple_concrete
fill 310 109 604 313 109 604 minecraft:purple_concrete
fill 312 109 646 312 110 646 minecraft:gold_block
fill 313 109 646 323 109 646 minecraft:purple_concrete
fill 315 109 604 317 110 604 minecraft:purple_concrete
fill 318 109 604 318 110 604 minecraft:gold_block
fill 320 109 604 324 109 604 minecraft:purple_concrete
fill 324 109 605 324 109 613 minecraft:purple_concrete
fill 324 109 614 324 110 614 minecraft:gold_block
fill 324 109 615 324 113 618 minecraft:purple_concrete
fill 324 109 620 324 109 629 minecraft:purple_concrete
fill 324 109 630 324 110 630 minecraft:gold_block
fill 324 109 631 324 109 639 minecraft:purple_concrete
fill 324 109 641 324 109 645 minecraft:purple_concrete
fill 282 110 607 282 154 607 minecraft:purple_concrete
fill 282 110 610 282 118 610 minecraft:purple_concrete
fill 282 110 613 282 111 615 minecraft:purple_concrete
setblock 282 110 616 minecraft:black_concrete
fill 282 110 617 282 110 625 minecraft:purple_concrete
setblock 282 110 626 minecraft:white_concrete
fill 282 110 627 282 115 627 minecraft:purple_concrete
fill 282 110 633 282 116 633 minecraft:purple_concrete
fill 282 110 642 282 175 642 minecraft:purple_concrete
fill 282 110 645 282 121 646 minecraft:purple_concrete
fill 283 110 646 285 110 646 minecraft:purple_concrete
setblock 286 110 646 minecraft:black_concrete
fill 287 110 604 290 110 604 minecraft:purple_concrete
fill 287 110 646 288 133 646 minecraft:purple_concrete
setblock 289 110 646 minecraft:black_concrete
fill 290 110 646 293 127 646 minecraft:purple_concrete
setblock 291 110 604 minecraft:black_concrete
fill 292 110 604 296 110 604 minecraft:purple_concrete
setblock 294 110 646 minecraft:black_concrete
fill 295 110 646 295 147 646 minecraft:purple_concrete
setblock 297 110 604 minecraft:black_concrete
setblock 297 110 646 minecraft:black_concrete
fill 298 110 604 301 125 604 minecraft:purple_concrete
fill 298 110 646 298 160 646 minecraft:purple_concrete
setblock 299 110 646 minecraft:black_concrete
fill 300 110 646 301 131 646 minecraft:purple_concrete
fill 304 110 646 305 139 646 minecraft:purple_concrete
fill 309 110 604 309 167 604 minecraft:purple_concrete
setblock 310 110 604 minecraft:black_concrete
fill 311 110 604 314 110 604 minecraft:purple_concrete
fill 313 110 646 316 131 646 minecraft:purple_concrete
setblock 317 110 646 minecraft:black_concrete
fill 318 110 646 321 110 646 minecraft:purple_concrete
fill 320 110 604 322 110 604 minecraft:purple_concrete
fill 322 110 646 323 110 646 minecraft:black_concrete
setblock 323 110 604 minecraft:black_concrete
fill 324 110 604 324 134 611 minecraft:purple_concrete
setblock 324 110 612 minecraft:amethyst_block
fill 324 110 613 324 123 613 minecraft:purple_concrete
fill 324 110 619 324 115 624 minecraft:purple_concrete
fill 324 110 625 324 110 626 minecraft:black_concrete
fill 324 110 627 324 110 629 minecraft:purple_concrete
setblock 324 110 631 minecraft:black_concrete
fill 324 110 632 324 110 642 minecraft:purple_concrete
setblock 324 110 643 minecraft:black_concrete
fill 324 110 644 324 121 645 minecraft:purple_concrete
fill 282 111 612 282 117 612 minecraft:purple_concrete
fill 282 111 616 282 151 617 minecraft:purple_concrete
setblock 282 111 618 minecraft:black_concrete
fill 282 111 619 282 116 626 minecraft:purple_concrete
fill 282 111 628 282 117 628 minecraft:purple_concrete
setblock 282 111 634 minecraft:black_concrete
fill 282 111 635 282 112 640 minecraft:purple_concrete
setblock 282 111 641 minecraft:black_concrete
setblock 282 111 644 minecraft:black_concrete
fill 283 111 604 284 111 604 minecraft:black_concrete
setblock 283 111 646 minecraft:white_concrete
fill 284 111 646 286 123 646 minecraft:purple_concrete
fill 285 111 604 288 117 604 minecraft:purple_concrete
setblock 289 111 604 minecraft:black_concrete
fill 289 111 646 289 161 646 minecraft:purple_concrete
fill 290 111 604 291 175 604 minecraft:purple_concrete
setblock 292 111 604 minecraft:black_concrete
fill 293 111 604 295 127 604 minecraft:purple_concrete
fill 294 111 646 294 114 646 minecraft:purple_concrete
setblock 296 111 604 minecraft:black_concrete
fill 296 111 646 297 117 646 minecraft:purple_concrete
fill 297 111 604 297 172 604 minecraft:purple_concrete
fill 299 111 646 299 126 646 minecraft:purple_concrete
fill 302 111 604 303 113 604 minecraft:purple_concrete
setblock 304 111 604 minecraft:black_concrete
fill 305 111 604 307 120 604 minecraft:purple_concrete
fill 306 111 646 309 136 646 minecraft:purple_concrete
setblock 308 111 604 minecraft:black_concrete
fill 310 111 604 312 111 604 minecraft:purple_concrete
setblock 310 111 646 minecraft:black_concrete
fill 311 111 646 312 117 646 minecraft:purple_concrete
setblock 313 111 604 minecraft:black_concrete
fill 314 111 604 314 159 604 minecraft:purple_concrete
setblock 315 111 604 minecraft:black_concrete
fill 316 111 604 318 117 604 minecraft:purple_concrete
fill 317 111 646 317 173 646 minecraft:purple_concrete
setblock 318 111 646 minecraft:black_concrete
fill 319 111 646 321 132 646 minecraft:purple_concrete
fill 320 111 604 321 157 604 minecraft:purple_concrete
setblock 322 111 604 minecraft:black_concrete
setblock 322 111 646 minecraft:black_concrete
fill 323 111 604 323 136 604 minecraft:purple_concrete
fill 323 111 646 323 125 646 minecraft:purple_concrete
setblock 324 111 612 minecraft:black_concrete
fill 324 111 614 324 117 614 minecraft:purple_concrete
fill 324 111 625 324 116 628 minecraft:purple_concrete
setblock 324 111 629 minecraft:black_concrete
fill 324 111 630 324 117 634 minecraft:purple_concrete
setblock 324 111 635 minecraft:amethyst_block
fill 324 111 636 324 114 643 minecraft:purple_concrete
fill 282 112 613 282 160 614 minecraft:purple_concrete
setblock 282 112 615 minecraft:white_concrete
fill 282 112 618 282 149 618 minecraft:purple_concrete
fill 282 112 634 282 175 634 minecraft:purple_concrete
fill 282 112 641 282 175 641 minecraft:purple_concrete
fill 282 112 644 282 117 644 minecraft:purple_concrete
fill 283 112 604 284 132 604 minecraft:purple_concrete
fill 283 112 646 283 176 646 minecraft:purple_concrete
fill 289 112 604 289 146 604 minecraft:purple_concrete
fill 292 112 604 292 117 604 minecraft:purple_concrete
fill 296 112 604 296 115 604 minecraft:purple_concrete
fill 304 112 604 304 175 604 minecraft:purple_concrete
fill 308 112 604 308 175 604 minecraft:purple_concrete
setblock 310 112 604 minecraft:white_concrete
fill 310 112 646 310 119 646 minecraft:purple_concrete
fill 311 112 604 313 134 604 minecraft:purple_concrete
fill 315 112 604 315 161 604 minecraft:purple_concrete
fill 318 112 646 318 136 646 minecraft:purple_concrete
fill 319 112 604 319 114 604 minecraft:purple_concrete
fill 322 112 604 322 130 604 minecraft:purple_concrete
fill 322 112 646 322 175 646 minecraft:purple_concrete
fill 324 112 612 324 121 612 minecraft:purple_concrete
fill 324 112 629 324 169 629 minecraft:purple_concrete
fill 324 112 635 324 158 635 minecraft:purple_concrete
fill 324 112 646 324 175 646 minecraft:purple_concrete
fill 282 113 615 282 175 615 minecraft:purple_concrete
setblock 282 113 635 minecraft:amethyst_block
fill 282 113 636 282 158 640 minecraft:purple_concrete
fill 296 113 632 297 114 633 minecraft:obsidian
fill 310 113 604 310 175 604 minecraft:purple_concrete
fill 282 114 635 282 131 635 minecraft:purple_concrete
setblock 285 114 607 minecraft:light[level=13]
setblock 285 114 615 minecraft:light[level=13]
setblock 285 114 623 minecraft:light[level=13]
setblock 285 114 631 minecraft:light[level=13]
setblock 285 114 639 minecraft:light[level=13]
setblock 293 114 607 minecraft:light[level=13]
setblock 293 114 615 minecraft:light[level=13]
setblock 293 114 623 minecraft:light[level=13]
setblock 293 114 631 minecraft:light[level=13]
setblock 293 114 639 minecraft:light[level=13]
setblock 301 114 607 minecraft:light[level=13]
setblock 301 114 615 minecraft:light[level=13]
setblock 301 114 623 minecraft:light[level=13]
setblock 301 114 631 minecraft:light[level=13]
setblock 301 114 639 minecraft:light[level=13]
setblock 302 114 604 minecraft:amethyst_block
fill 303 114 604 303 174 604 minecraft:purple_concrete
setblock 309 114 607 minecraft:light[level=13]
setblock 309 114 615 minecraft:light[level=13]
setblock 309 114 623 minecraft:light[level=13]
setblock 309 114 631 minecraft:light[level=13]
setblock 309 114 639 minecraft:light[level=13]
setblock 317 114 607 minecraft:light[level=13]
setblock 317 114 615 minecraft:light[level=13]
setblock 317 114 623 minecraft:light[level=13]
setblock 317 114 631 minecraft:light[level=13]
setblock 317 114 639 minecraft:light[level=13]
fill 324 114 615 324 122 615 minecraft:purple_concrete
setblock 324 114 616 minecraft:amethyst_block
fill 324 114 617 324 165 618 minecraft:purple_concrete
fill 282 115 604 282 172 604 minecraft:purple_concrete
setblock 282 115 605 minecraft:amethyst_block
fill 282 115 606 282 134 606 minecraft:purple_concrete
fill 292 115 636 293 116 637 minecraft:end_stone
setblock 294 115 646 minecraft:amethyst_block
fill 302 115 604 302 117 604 minecraft:purple_concrete
setblock 319 115 604 minecraft:white_concrete
fill 324 115 616 324 125 616 minecraft:purple_concrete
fill 324 115 636 324 173 636 minecraft:purple_concrete
setblock 324 115 637 minecraft:amethyst_block
fill 324 115 638 324 121 643 minecraft:purple_concrete
fill 282 116 605 282 176 605 minecraft:purple_concrete
setblock 282 116 627 minecraft:white_concrete
fill 294 116 646 294 146 646 minecraft:purple_concrete
setblock 296 116 604 minecraft:amethyst_block
fill 319 116 604 319 175 604 minecraft:purple_concrete
fill 324 116 619 324 133 623 minecraft:purple_concrete
setblock 324 116 624 minecraft:pearlescent_froglight
fill 324 116 637 324 145 637 minecraft:purple_concrete
fill 282 117 619 282 175 619 minecraft:purple_concrete
setblock 282 117 620 minecraft:pearlescent_froglight
fill 282 117 621 282 118 627 minecraft:purple_concrete
setblock 282 117 633 minecraft:amethyst_block
fill 296 117 604 296 130 604 minecraft:purple_concrete
fill 324 117 624 324 120 626 minecraft:purple_concrete
setblock 324 117 627 minecraft:white_concrete
fill 324 117 628 324 122 628 minecraft:purple_concrete
fill 282 118 612 282 119 612 minecraft:gold_block
fill 282 118 620 282 149 620 minecraft:purple_concrete
fill 282 118 628 282 119 628 minecraft:gold_block
fill 282 118 633 282 173 633 minecraft:purple_concrete
fill 282 118 644 282 119 644 minecraft:gold_block
fill 285 118 604 285 162 604 minecraft:purple_concrete
fill 286 118 604 286 119 604 minecraft:gold_block
fill 287 118 604 288 150 604 minecraft:purple_concrete
setblock 292 118 604 minecraft:pearlescent_froglight
fill 296 118 646 296 119 646 minecraft:gold_block
fill 297 118 646 297 175 646 minecraft:purple_concrete
fill 302 118 604 302 119 604 minecraft:gold_block
fill 311 118 646 311 175 646 minecraft:purple_concrete
fill 312 118 646 312 119 646 minecraft:gold_block
fill 316 118 604 317 119 604 minecraft:purple_concrete
fill 318 118 604 318 119 604 minecraft:gold_block
fill 324 118 614 324 119 614 minecraft:gold_block
fill 324 118 627 324 172 627 minecraft:purple_concrete
fill 324 118 630 324 119 630 minecraft:gold_block
fill 324 118 631 324 126 634 minecraft:purple_concrete
setblock 282 119 610 minecraft:white_concrete
fill 282 119 621 282 124 624 minecraft:purple_concrete
setblock 282 119 625 minecraft:pearlescent_froglight
fill 282 119 626 282 174 627 minecraft:purple_concrete
fill 292 119 604 292 175 604 minecraft:purple_concrete
fill 282 120 610 282 144 610 minecraft:purple_concrete
fill 282 120 612 282 135 612 minecraft:purple_concrete
fill 282 120 625 282 150 625 minecraft:purple_concrete
fill 282 120 628 282 135 628 minecraft:purple_concrete
fill 282 120 644 282 135 644 minecraft:purple_concrete
fill 286 120 604 286 135 604 minecraft:purple_concrete
fill 296 120 646 296 135 646 minecraft:purple_concrete
fill 302 120 604 302 135 604 minecraft:purple_concrete
setblock 310 120 646 minecraft:amethyst_block
fill 312 120 646 312 135 646 minecraft:purple_concrete
setblock 316 120 604 minecraft:amethyst_block
fill 317 120 604 318 135 604 minecraft:purple_concrete
fill 324 120 614 324 130 614 minecraft:purple_concrete
fill 324 120 630 324 135 630 minecraft:purple_concrete
setblock 305 121 604 minecraft:amethyst_block
fill 306 121 604 307 123 604 minecraft:purple_concrete
fill 310 121 646 310 137 646 minecraft:purple_concrete
fill 316 121 604 316 177 604 minecraft:purple_concrete
fill 324 121 624 324 171 624 minecraft:purple_concrete
setblock 324 121 625 minecraft:amethyst_block
fill 324 121 626 324 123 626 minecraft:purple_concrete
fill 282 122 629 282 175 629 minecraft:purple_concrete
setblock 282 122 630 minecraft:pearlescent_froglight
fill 282 122 631 282 142 632 minecraft:purple_concrete
setblock 282 122 645 minecraft:pearlescent_froglight
fill 282 122 646 282 175 646 minecraft:purple_concrete
setblock 285 122 607 minecraft:light[level=13]
setblock 285 122 615 minecraft:light[level=13]
setblock 285 122 623 minecraft:light[level=13]
setblock 285 122 631 minecraft:light[level=13]
setblock 285 122 639 minecraft:light[level=13]
setblock 293 122 607 minecraft:light[level=13]
setblock 293 122 615 minecraft:light[level=13]
setblock 293 122 623 minecraft:light[level=13]
setblock 293 122 631 minecraft:light[level=13]
setblock 293 122 639 minecraft:light[level=13]
setblock 301 122 607 minecraft:light[level=13]
setblock 301 122 615 minecraft:light[level=13]
setblock 301 122 623 minecraft:light[level=13]
setblock 301 122 631 minecraft:light[level=13]
setblock 301 122 639 minecraft:light[level=13]
fill 305 122 604 305 171 604 minecraft:purple_concrete
setblock 309 122 607 minecraft:light[level=13]
setblock 309 122 615 minecraft:light[level=13]
setblock 309 122 623 minecraft:light[level=13]
setblock 309 122 631 minecraft:light[level=13]
setblock 309 122 639 minecraft:light[level=13]
setblock 317 122 607 minecraft:light[level=13]
setblock 317 122 615 minecraft:light[level=13]
setblock 317 122 623 minecraft:light[level=13]
setblock 317 122 631 minecraft:light[level=13]
setblock 317 122 639 minecraft:light[level=13]
setblock 324 122 612 minecraft:white_concrete
fill 324 122 625 324 175 625 minecraft:purple_concrete
setblock 324 122 638 minecraft:amethyst_block
fill 324 122 639 324 133 644 minecraft:purple_concrete
setblock 324 122 645 minecraft:white_concrete
fill 282 123 630 282 133 630 minecraft:purple_concrete
setblock 282 123 645 minecraft:purple_concrete
fill 324 123 612 324 134 612 minecraft:purple_concrete
setblock 324 123 615 minecraft:white_concrete
setblock 324 123 628 minecraft:amethyst_block
fill 324 123 638 324 156 638 minecraft:purple_concrete
fill 324 123 645 324 144 645 minecraft:purple_concrete
setblock 282 124 608 minecraft:purple_concrete
setblock 282 124 609 minecraft:white_concrete
setblock 282 124 645 minecraft:white_concrete
fill 284 124 646 285 175 646 minecraft:purple_concrete
setblock 286 124 646 minecraft:pearlescent_froglight
setblock 306 124 604 minecraft:amethyst_block
fill 307 124 604 307 145 604 minecraft:purple_concrete
setblock 324 124 613 minecraft:white_concrete
fill 324 124 615 324 139 615 minecraft:purple_concrete
setblock 324 124 626 minecraft:white_concrete
fill 324 124 628 324 144 628 minecraft:purple_concrete
setblock 282 125 608 minecraft:pearlescent_froglight
fill 282 125 609 282 175 609 minecraft:purple_concrete
fill 282 125 621 282 146 623 minecraft:purple_concrete
setblock 282 125 624 minecraft:white_concrete
fill 282 125 645 282 175 645 minecraft:purple_concrete
fill 286 125 646 286 175 646 minecraft:purple_concrete
fill 298 125 621 300 125 623 minecraft:redstone_block
fill 299 125 628 301 125 630 minecraft:redstone_block
fill 303 125 619 305 125 621 minecraft:redstone_block
fill 305 125 628 307 125 630 minecraft:redstone_block
fill 306 125 604 306 132 604 minecraft:purple_concrete
fill 307 125 623 309 125 625 minecraft:redstone_block
fill 324 125 613 324 175 613 minecraft:purple_concrete
fill 324 125 626 324 175 626 minecraft:purple_concrete
fill 282 126 608 282 127 608 minecraft:purple_concrete
fill 282 126 624 282 175 624 minecraft:purple_concrete
fill 287 126 625 290 127 625 minecraft:black_concrete
fill 288 126 620 288 127 623 minecraft:purple_concrete
fill 288 126 624 291 127 624 minecraft:black_concrete
fill 288 126 626 288 127 630 minecraft:black_concrete
fill 289 126 618 289 127 622 minecraft:purple_concrete
fill 289 126 623 293 127 623 minecraft:black_concrete
fill 289 126 626 289 127 627 minecraft:black_concrete
fill 289 126 628 293 127 632 minecraft:purple_concrete
fill 290 126 616 290 127 621 minecraft:purple_concrete
fill 290 126 622 295 127 622 minecraft:black_concrete
fill 290 126 626 290 127 626 minecraft:black_concrete
fill 290 126 627 295 127 627 minecraft:purple_concrete
fill 290 126 633 293 127 634 minecraft:purple_concrete
fill 291 126 615 292 127 620 minecraft:purple_concrete
fill 291 126 621 297 126 621 minecraft:black_concrete
fill 291 126 625 296 127 626 minecraft:purple_concrete
fill 291 126 635 293 127 635 minecraft:purple_concrete
fill 292 126 614 302 127 614 minecraft:black_concrete
fill 292 126 624 299 126 624 minecraft:purple_concrete
fill 292 126 636 293 127 636 minecraft:purple_concrete
fill 293 126 613 301 127 613 minecraft:black_concrete
fill 293 126 615 298 127 619 minecraft:purple_concrete
fill 293 126 620 299 126 620 minecraft:black_concrete
fill 293 126 637 293 127 637 minecraft:purple_concrete
fill 294 126 612 299 127 612 minecraft:black_concrete
fill 294 126 623 297 126 623 minecraft:purple_concrete
fill 294 126 628 294 127 629 minecraft:purple_concrete
fill 294 126 630 296 127 637 minecraft:black_concrete
fill 294 126 638 294 127 638 minecraft:purple_concrete
fill 295 126 628 297 127 629 minecraft:black_concrete
fill 295 126 638 298 127 638 minecraft:black_concrete
fill 296 126 611 296 127 611 minecraft:black_concrete
fill 296 126 622 297 126 622 minecraft:purple_concrete
fill 296 126 627 298 126 627 minecraft:black_concrete
fill 296 126 639 298 127 639 minecraft:black_concrete
fill 297 126 611 307 127 611 minecraft:purple_concrete
fill 297 126 625 297 127 625 minecraft:purple_concrete
fill 297 126 626 299 127 626 minecraft:black_concrete
fill 297 126 630 298 126 635 minecraft:purple_concrete
fill 297 126 636 297 127 637 minecraft:black_concrete
setblock 298 126 604 minecraft:purple_concrete
fill 298 126 610 306 127 610 minecraft:purple_concrete
fill 298 126 625 299 127 625 minecraft:black_concrete
fill 298 126 628 298 126 629 minecraft:purple_concrete
fill 298 126 636 303 127 637 minecraft:purple_concrete
fill 298 126 640 299 127 640 minecraft:black_concrete
setblock 299 126 604 minecraft:amethyst_block
fill 299 126 615 303 127 615 minecraft:black_concrete
fill 299 126 616 300 127 619 minecraft:purple_concrete
fill 299 126 627 300 126 627 minecraft:purple_concrete
fill 299 126 631 300 126 635 minecraft:purple_concrete
fill 299 126 638 306 127 639 minecraft:purple_concrete
fill 300 126 604 301 164 604 minecraft:purple_concrete
fill 300 126 612 307 127 612 minecraft:purple_concrete
fill 300 126 620 302 126 620 minecraft:purple_concrete
fill 300 126 624 301 126 626 minecraft:crying_obsidian
fill 300 126 640 308 127 640 minecraft:purple_concrete
fill 301 126 616 304 127 616 minecraft:black_concrete
fill 301 126 617 301 127 619 minecraft:purple_concrete
fill 301 126 621 302 126 621 minecraft:purple_concrete
setblock 301 126 622 minecraft:black_concrete
fill 301 126 623 305 126 623 minecraft:crying_obsidian
fill 301 126 627 305 126 627 minecraft:crying_obsidian
fill 301 126 631 302 126 632 minecraft:black_concrete
fill 301 126 633 301 127 635 minecraft:purple_concrete
fill 302 126 613 308 127 613 minecraft:purple_concrete
fill 302 126 617 304 127 617 minecraft:black_concrete
fill 302 126 618 302 126 619 minecraft:purple_concrete
fill 302 126 622 304 126 622 minecraft:crying_obsidian
fill 302 126 628 304 126 628 minecraft:crying_obsidian
fill 302 126 629 302 126 630 minecraft:black_concrete
fill 302 126 633 304 127 634 minecraft:black_concrete
fill 302 126 635 302 127 635 minecraft:purple_concrete
fill 303 126 609 303 127 609 minecraft:purple_concrete
fill 303 126 614 308 127 614 minecraft:purple_concrete
fill 303 126 618 305 126 618 minecraft:black_concrete
fill 303 126 629 304 126 631 minecraft:purple_concrete
fill 303 126 632 303 127 632 minecraft:black_concrete
fill 303 126 635 307 127 635 minecraft:black_concrete
fill 303 126 641 303 127 641 minecraft:purple_concrete
fill 304 126 615 309 127 615 minecraft:purple_concrete
fill 304 126 632 317 127 632 minecraft:purple_concrete
fill 304 126 636 314 127 636 minecraft:black_concrete
fill 304 126 637 304 127 637 minecraft:purple_concrete
fill 305 126 616 309 127 617 minecraft:purple_concrete
setblock 305 126 622 minecraft:black_concrete
fill 305 126 624 306 126 626 minecraft:crying_obsidian
fill 305 126 631 317 126 631 minecraft:purple_concrete
fill 305 126 633 316 127 633 minecraft:purple_concrete
fill 305 126 634 305 127 634 minecraft:black_concrete
fill 305 126 637 313 127 637 minecraft:black_concrete
fill 306 126 618 306 126 623 minecraft:purple_concrete
fill 306 126 627 312 126 627 minecraft:purple_concrete
fill 306 126 634 316 127 634 minecraft:purple_concrete
fill 307 126 610 308 127 610 minecraft:black_concrete
fill 307 126 618 308 126 622 minecraft:purple_concrete
fill 307 126 626 314 126 626 minecraft:purple_concrete
fill 307 126 638 312 127 638 minecraft:black_concrete
fill 307 126 639 309 127 639 minecraft:purple_concrete
fill 308 126 611 310 127 612 minecraft:black_concrete
fill 308 126 628 310 126 628 minecraft:purple_concrete
fill 308 126 629 313 126 630 minecraft:black_concrete
fill 308 126 635 315 127 635 minecraft:purple_concrete
fill 309 126 613 312 127 614 minecraft:black_concrete
fill 309 126 618 309 127 620 minecraft:purple_concrete
fill 309 126 621 311 126 622 minecraft:black_concrete
fill 310 126 615 312 127 620 minecraft:black_concrete
setblock 310 126 623 minecraft:black_concrete
fill 310 126 624 315 126 625 minecraft:purple_concrete
fill 310 126 639 310 127 639 minecraft:black_concrete
fill 311 126 612 311 127 612 minecraft:black_concrete
fill 311 126 623 316 127 623 minecraft:purple_concrete
fill 311 126 628 316 127 628 minecraft:black_concrete
fill 312 126 612 312 127 612 minecraft:purple_concrete
fill 312 126 621 317 127 622 minecraft:purple_concrete
fill 313 126 613 313 127 620 minecraft:purple_concrete
fill 313 126 627 317 127 627 minecraft:black_concrete
fill 314 126 614 314 127 620 minecraft:purple_concrete
fill 314 126 629 315 127 629 minecraft:black_concrete
fill 314 126 630 318 127 630 minecraft:purple_concrete
fill 315 126 615 315 127 620 minecraft:purple_concrete
fill 315 126 626 318 127 626 minecraft:black_concrete
fill 316 126 616 316 127 620 minecraft:purple_concrete
fill 316 126 624 318 127 625 minecraft:black_concrete
fill 316 126 629 318 127 629 minecraft:purple_concrete
fill 317 126 618 317 127 620 minecraft:purple_concrete
fill 317 126 623 318 127 623 minecraft:black_concrete
fill 317 126 628 318 127 628 minecraft:purple_concrete
fill 318 126 620 318 127 622 minecraft:black_concrete
fill 318 126 627 318 127 627 minecraft:purple_concrete
fill 319 126 625 319 127 625 minecraft:black_concrete
setblock 323 126 646 minecraft:pearlescent_froglight
setblock 324 126 616 minecraft:amethyst_block
fill 283 127 605 286 127 645 minecraft:black_concrete
fill 287 127 605 287 127 624 minecraft:black_concrete
fill 287 127 626 287 127 645 minecraft:black_concrete
fill 288 127 605 288 127 619 minecraft:black_concrete
fill 288 127 631 288 127 645 minecraft:black_concrete
fill 289 127 605 289 127 617 minecraft:black_concrete
fill 289 127 633 289 127 645 minecraft:black_concrete
fill 290 127 605 290 127 615 minecraft:black_concrete
fill 290 127 635 290 127 645 minecraft:black_concrete
fill 291 127 605 291 127 614 minecraft:black_concrete
fill 291 127 621 296 127 621 minecraft:black_concrete
fill 291 127 636 291 127 645 minecraft:black_concrete
fill 292 127 605 292 127 613 minecraft:black_concrete
fill 292 127 624 296 127 624 minecraft:purple_concrete
fill 292 127 637 292 127 645 minecraft:black_concrete
fill 293 127 605 293 127 612 minecraft:black_concrete
fill 293 127 620 296 127 620 minecraft:black_concrete
fill 293 127 638 293 127 645 minecraft:black_concrete
fill 294 127 605 295 127 611 minecraft:black_concrete
fill 294 127 623 296 127 623 minecraft:purple_concrete
fill 294 127 639 295 127 645 minecraft:black_concrete
fill 296 127 605 297 127 610 minecraft:black_concrete
setblock 296 127 622 minecraft:purple_concrete
fill 296 127 627 297 127 627 minecraft:black_concrete
fill 296 127 640 297 127 645 minecraft:black_concrete
fill 297 127 620 297 127 624 minecraft:pearlescent_froglight
fill 297 127 630 297 127 635 minecraft:purple_concrete
setblock 298 127 604 minecraft:amethyst_block
fill 298 127 605 302 127 609 minecraft:black_concrete
fill 298 127 620 302 127 620 minecraft:pearlescent_froglight
fill 298 127 621 300 127 623 minecraft:black_concrete
fill 298 127 624 300 127 624 minecraft:pearlescent_froglight
fill 298 127 627 298 127 631 minecraft:pearlescent_froglight
fill 298 127 632 300 127 635 minecraft:purple_concrete
fill 298 127 641 302 127 645 minecraft:black_concrete
fill 299 127 604 299 138 604 minecraft:purple_concrete
fill 299 127 627 301 127 627 minecraft:pearlescent_froglight
fill 299 127 628 301 127 630 minecraft:black_concrete
fill 299 127 631 302 127 631 minecraft:pearlescent_froglight
setblock 299 127 646 minecraft:pearlescent_froglight
fill 300 127 625 300 127 626 minecraft:crying_obsidian
fill 301 127 621 301 127 623 minecraft:pearlescent_froglight
fill 301 127 624 301 127 626 minecraft:shroomlight
fill 301 127 632 302 127 632 minecraft:black_concrete
fill 302 127 618 302 127 619 minecraft:pearlescent_froglight
fill 302 127 621 302 127 622 minecraft:pearlescent_froglight
fill 302 127 623 304 127 623 minecraft:shroomlight
fill 302 127 627 304 127 627 minecraft:shroomlight
fill 302 127 628 302 127 630 minecraft:pearlescent_froglight
fill 303 127 605 323 127 608 minecraft:black_concrete
fill 303 127 618 306 127 618 minecraft:pearlescent_froglight
fill 303 127 619 305 127 621 minecraft:black_concrete
fill 303 127 622 310 127 622 minecraft:pearlescent_froglight
setblock 303 127 628 minecraft:crying_obsidian
fill 303 127 629 303 127 631 minecraft:purple_concrete
fill 303 127 642 323 127 645 minecraft:black_concrete
fill 304 127 609 323 127 609 minecraft:black_concrete
fill 304 127 628 304 127 631 minecraft:pearlescent_froglight
fill 304 127 641 323 127 641 minecraft:black_concrete
fill 305 127 623 306 127 623 minecraft:pearlescent_froglight
fill 305 127 624 305 127 626 minecraft:shroomlight
fill 305 127 627 308 127 627 minecraft:pearlescent_froglight
fill 305 127 628 307 127 630 minecraft:black_concrete
fill 305 127 631 308 127 631 minecraft:pearlescent_froglight
fill 306 127 619 306 127 621 minecraft:pearlescent_froglight
fill 306 127 624 306 127 626 minecraft:pearlescent_froglight
fill 307 127 618 308 127 621 minecraft:purple_concrete
fill 307 127 623 309 127 625 minecraft:black_concrete
fill 307 127 626 310 127 626 minecraft:pearlescent_froglight
fill 308 127 628 308 127 630 minecraft:pearlescent_froglight
fill 309 127 610 323 127 610 minecraft:black_concrete
fill 309 127 621 311 127 621 minecraft:black_concrete
fill 309 127 627 310 127 628 minecraft:purple_concrete
fill 309 127 629 313 127 630 minecraft:black_concrete
fill 309 127 631 317 127 631 minecraft:purple_concrete
fill 309 127 640 323 127 640 minecraft:black_concrete
fill 310 127 623 310 127 625 minecraft:pearlescent_froglight
fill 311 127 611 323 127 611 minecraft:black_concrete
setblock 311 127 622 minecraft:black_concrete
fill 311 127 624 312 127 627 minecraft:purple_concrete
fill 311 127 639 323 127 639 minecraft:black_concrete
fill 313 127 612 323 127 612 minecraft:black_concrete
fill 313 127 624 314 127 626 minecraft:purple_concrete
fill 313 127 638 323 127 638 minecraft:black_concrete
fill 314 127 613 323 127 613 minecraft:black_concrete
fill 314 127 637 323 127 637 minecraft:black_concrete
fill 315 127 614 323 127 614 minecraft:black_concrete
fill 315 127 624 315 127 625 minecraft:purple_concrete
fill 315 127 636 323 127 636 minecraft:black_concrete
fill 316 127 615 323 127 615 minecraft:black_concrete
fill 316 127 635 323 127 635 minecraft:black_concrete
fill 317 127 616 323 127 617 minecraft:black_concrete
fill 317 127 633 323 127 634 minecraft:black_concrete
fill 318 127 618 323 127 619 minecraft:black_concrete
fill 318 127 631 323 127 632 minecraft:black_concrete
fill 319 127 620 323 127 624 minecraft:black_concrete
fill 319 127 626 323 127 630 minecraft:black_concrete
fill 320 127 625 323 127 625 minecraft:black_concrete
fill 323 127 646 323 128 646 minecraft:purple_concrete
fill 324 127 616 324 175 616 minecraft:purple_concrete
fill 324 127 631 324 135 631 minecraft:purple_concrete
setblock 324 127 632 minecraft:amethyst_block
fill 324 127 633 324 128 634 minecraft:purple_concrete
setblock 282 128 608 minecraft:pearlescent_froglight
fill 283 128 614 283 128 636 minecraft:basalt
setblock 284 128 612 minecraft:magma_block
fill 284 128 613 286 128 614 minecraft:basalt
setblock 284 128 615 minecraft:magma_block
fill 284 128 616 286 130 617 minecraft:basalt
setblock 284 128 618 minecraft:magma_block
fill 284 128 619 286 130 620 minecraft:basalt
setblock 284 128 621 minecraft:magma_block
fill 284 128 622 286 132 623 minecraft:basalt
setblock 284 128 624 minecraft:magma_block
fill 284 128 625 286 132 626 minecraft:basalt
setblock 284 128 627 minecraft:magma_block
fill 284 128 628 286 132 629 minecraft:basalt
setblock 284 128 630 minecraft:magma_block
fill 284 128 631 286 130 632 minecraft:basalt
setblock 284 128 633 minecraft:magma_block
fill 284 128 634 286 129 635 minecraft:basalt
setblock 284 128 636 minecraft:magma_block
fill 284 128 637 286 128 638 minecraft:basalt
fill 285 128 611 286 128 612 minecraft:basalt
fill 285 128 615 292 129 615 minecraft:basalt
fill 285 128 618 290 132 618 minecraft:basalt
fill 285 128 621 289 133 621 minecraft:basalt
fill 285 128 624 288 133 624 minecraft:basalt
fill 285 128 627 288 133 627 minecraft:basalt
fill 285 128 630 289 133 630 minecraft:basalt
fill 285 128 633 291 131 633 minecraft:basalt
fill 285 128 636 292 129 636 minecraft:basalt
fill 285 128 639 292 128 639 minecraft:basalt
fill 286 128 610 289 128 610 minecraft:basalt
fill 286 128 640 289 128 640 minecraft:basalt
fill 287 128 609 292 128 609 minecraft:basalt
setblock 287 128 611 minecraft:magma_block
fill 287 128 612 289 130 613 minecraft:basalt
setblock 287 128 614 minecraft:magma_block
fill 287 128 616 289 133 616 minecraft:basalt
setblock 287 128 617 minecraft:magma_block
fill 287 128 619 289 134 619 minecraft:basalt
setblock 287 128 620 minecraft:magma_block
fill 287 128 622 289 135 622 minecraft:basalt
setblock 287 128 623 minecraft:magma_block
fill 287 128 625 288 136 625 minecraft:basalt
setblock 287 128 626 minecraft:magma_block
fill 287 128 628 289 135 628 minecraft:basalt
setblock 287 128 629 minecraft:magma_block
fill 287 128 631 289 134 631 minecraft:basalt
setblock 287 128 632 minecraft:magma_block
fill 287 128 634 289 133 634 minecraft:basalt
setblock 287 128 635 minecraft:magma_block
fill 287 128 637 289 130 637 minecraft:basalt
setblock 287 128 638 minecraft:magma_block
setblock 287 128 641 minecraft:magma_block
fill 288 128 608 295 128 608 minecraft:basalt
fill 288 128 611 295 129 611 minecraft:basalt
fill 288 128 614 294 133 614 minecraft:basalt
fill 288 128 617 291 134 617 minecraft:basalt
fill 288 128 620 289 136 620 minecraft:basalt
fill 288 128 623 288 137 623 minecraft:basalt
fill 288 128 626 288 137 626 minecraft:basalt
fill 288 128 629 289 136 629 minecraft:basalt
fill 288 128 632 290 135 632 minecraft:basalt
fill 288 128 635 292 133 635 minecraft:basalt
fill 288 128 638 295 131 638 minecraft:basalt
fill 288 128 641 292 128 642 minecraft:basalt
setblock 289 128 607 minecraft:basalt
setblock 289 128 643 minecraft:basalt
fill 290 128 606 292 128 606 minecraft:basalt
setblock 290 128 607 minecraft:magma_block
setblock 290 128 610 minecraft:magma_block
fill 290 128 612 292 133 612 minecraft:basalt
setblock 290 128 613 minecraft:magma_block
setblock 290 128 616 minecraft:magma_block
setblock 290 128 619 minecraft:magma_block
setblock 290 128 631 minecraft:magma_block
setblock 290 128 634 minecraft:magma_block
setblock 290 128 637 minecraft:magma_block
setblock 290 128 640 minecraft:magma_block
setblock 290 128 643 minecraft:magma_block
fill 290 128 644 295 128 644 minecraft:basalt
fill 290 128 646 290 175 646 minecraft:purple_concrete
fill 291 128 607 298 129 607 minecraft:basalt
fill 291 128 610 298 132 610 minecraft:basalt
fill 291 128 613 295 134 613 minecraft:basalt
fill 291 128 616 292 137 616 minecraft:basalt
fill 291 128 634 292 137 634 minecraft:basalt
fill 291 128 637 295 134 637 minecraft:basalt
fill 291 128 640 298 132 640 minecraft:basalt
fill 291 128 643 298 129 643 minecraft:basalt
setblock 291 128 646 minecraft:white_concrete
fill 292 128 605 295 128 605 minecraft:basalt
setblock 292 128 645 minecraft:basalt
fill 292 128 646 292 131 646 minecraft:purple_concrete
fill 293 128 604 294 146 604 minecraft:purple_concrete
setblock 293 128 606 minecraft:magma_block
setblock 293 128 609 minecraft:magma_block
setblock 293 128 612 minecraft:magma_block
setblock 293 128 636 minecraft:magma_block
setblock 293 128 639 minecraft:magma_block
fill 293 128 641 295 132 641 minecraft:basalt
setblock 293 128 642 minecraft:magma_block
setblock 293 128 645 minecraft:magma_block
setblock 293 128 646 minecraft:pearlescent_froglight
fill 294 128 606 301 129 606 minecraft:basalt
fill 294 128 609 301 133 609 minecraft:basalt
fill 294 128 612 297 136 612 minecraft:basalt
fill 294 128 636 294 138 636 minecraft:basalt
fill 294 128 639 300 135 639 minecraft:basalt
fill 294 128 642 301 131 642 minecraft:basalt
fill 294 128 645 301 129 645 minecraft:basalt
setblock 295 128 604 minecraft:amethyst_block
setblock 296 128 605 minecraft:magma_block
setblock 296 128 608 minecraft:magma_block
setblock 296 128 611 minecraft:magma_block
setblock 296 128 638 minecraft:magma_block
setblock 296 128 641 minecraft:magma_block
setblock 296 128 644 minecraft:magma_block
fill 297 128 605 304 129 605 minecraft:basalt
fill 297 128 608 304 133 608 minecraft:basalt
fill 297 128 611 300 136 611 minecraft:basalt
fill 297 128 638 297 137 638 minecraft:basalt
fill 297 128 641 304 134 641 minecraft:basalt
fill 297 128 644 304 131 644 minecraft:basalt
fill 298 128 604 298 173 604 minecraft:purple_concrete
setblock 299 128 607 minecraft:magma_block
setblock 299 128 610 minecraft:magma_block
setblock 299 128 640 minecraft:magma_block
setblock 299 128 643 minecraft:magma_block
fill 299 128 646 299 175 646 minecraft:purple_concrete
fill 300 128 607 307 132 607 minecraft:basalt
fill 300 128 610 307 136 610 minecraft:basalt
fill 300 128 640 307 136 640 minecraft:basalt
fill 300 128 643 307 132 643 minecraft:basalt
setblock 302 128 606 minecraft:magma_block
setblock 302 128 609 minecraft:magma_block
setblock 302 128 642 minecraft:magma_block
setblock 302 128 645 minecraft:magma_block
fill 303 128 606 310 130 606 minecraft:basalt
fill 303 128 609 310 134 609 minecraft:basalt
fill 303 128 642 310 132 642 minecraft:basalt
fill 303 128 645 310 130 645 minecraft:basalt
setblock 305 128 605 minecraft:magma_block
setblock 305 128 608 minecraft:magma_block
setblock 305 128 641 minecraft:magma_block
setblock 305 128 644 minecraft:magma_block
fill 306 128 605 313 128 605 minecraft:basalt
fill 306 128 608 313 131 608 minecraft:basalt
fill 306 128 611 313 134 611 minecraft:basalt
fill 306 128 639 310 136 639 minecraft:basalt
fill 306 128 641 313 132 641 minecraft:basalt
fill 306 128 644 313 129 644 minecraft:basalt
setblock 308 128 607 minecraft:magma_block
setblock 308 128 610 minecraft:magma_block
setblock 308 128 640 minecraft:magma_block
setblock 308 128 643 minecraft:magma_block
fill 309 128 607 316 128 607 minecraft:basalt
fill 309 128 610 316 131 610 minecraft:basalt
fill 309 128 612 310 137 612 minecraft:basalt
fill 309 128 638 313 134 638 minecraft:basalt
fill 309 128 640 316 131 640 minecraft:basalt
fill 309 128 643 316 128 643 minecraft:basalt
setblock 311 128 606 minecraft:magma_block
setblock 311 128 609 minecraft:magma_block
setblock 311 128 612 minecraft:magma_block
fill 311 128 613 316 134 613 minecraft:basalt
fill 311 128 637 316 134 637 minecraft:basalt
setblock 311 128 639 minecraft:magma_block
setblock 311 128 642 minecraft:magma_block
setblock 311 128 645 minecraft:magma_block
fill 312 128 606 316 128 606 minecraft:basalt
fill 312 128 609 319 128 609 minecraft:basalt
fill 312 128 612 319 130 612 minecraft:basalt
fill 312 128 614 313 137 614 minecraft:basalt
fill 312 128 636 319 132 636 minecraft:basalt
fill 312 128 639 319 130 639 minecraft:basalt
fill 312 128 642 318 128 642 minecraft:basalt
fill 312 128 645 314 128 645 minecraft:basalt
setblock 314 128 605 minecraft:magma_block
setblock 314 128 608 minecraft:magma_block
setblock 314 128 611 minecraft:magma_block
setblock 314 128 614 minecraft:magma_block
fill 314 128 615 316 135 616 minecraft:basalt
fill 314 128 634 316 136 634 minecraft:basalt
setblock 314 128 635 minecraft:magma_block
setblock 314 128 638 minecraft:magma_block
setblock 314 128 641 minecraft:magma_block
setblock 314 128 644 minecraft:magma_block
fill 315 128 608 318 128 608 minecraft:basalt
fill 315 128 611 321 128 611 minecraft:basalt
fill 315 128 614 322 129 614 minecraft:basalt
fill 315 128 617 322 130 617 minecraft:basalt
fill 315 128 633 319 133 633 minecraft:basalt
fill 315 128 635 322 129 635 minecraft:basalt
fill 315 128 638 322 128 638 minecraft:basalt
fill 315 128 641 319 128 641 minecraft:basalt
fill 315 128 644 316 128 644 minecraft:basalt
fill 316 128 618 316 137 619 minecraft:basalt
fill 316 128 631 316 137 632 minecraft:basalt
setblock 317 128 607 minecraft:magma_block
setblock 317 128 610 minecraft:magma_block
setblock 317 128 613 minecraft:magma_block
fill 317 128 615 319 132 615 minecraft:basalt
setblock 317 128 616 minecraft:magma_block
fill 317 128 618 319 134 618 minecraft:basalt
setblock 317 128 619 minecraft:magma_block
fill 317 128 620 319 134 621 minecraft:basalt
setblock 317 128 622 minecraft:magma_block
setblock 317 128 628 minecraft:magma_block
fill 317 128 629 319 134 630 minecraft:basalt
setblock 317 128 631 minecraft:magma_block
fill 317 128 632 322 131 632 minecraft:basalt
setblock 317 128 634 minecraft:magma_block
setblock 317 128 637 minecraft:magma_block
setblock 317 128 640 minecraft:magma_block
setblock 317 128 643 minecraft:magma_block
fill 318 128 610 320 128 610 minecraft:basalt
fill 318 128 613 322 128 613 minecraft:basalt
fill 318 128 616 323 129 616 minecraft:basalt
fill 318 128 619 323 130 619 minecraft:basalt
fill 318 128 622 319 134 628 minecraft:basalt
fill 318 128 631 323 130 631 minecraft:basalt
fill 318 128 634 323 129 634 minecraft:basalt
fill 318 128 637 322 128 637 minecraft:basalt
fill 318 128 640 320 128 640 minecraft:basalt
setblock 320 128 612 minecraft:magma_block
setblock 320 128 615 minecraft:magma_block
setblock 320 128 618 minecraft:magma_block
fill 320 128 620 322 131 620 minecraft:basalt
setblock 320 128 621 minecraft:magma_block
fill 320 128 622 322 132 623 minecraft:basalt
setblock 320 128 624 minecraft:magma_block
fill 320 128 625 322 132 626 minecraft:basalt
setblock 320 128 627 minecraft:magma_block
fill 320 128 628 322 132 629 minecraft:basalt
setblock 320 128 630 minecraft:magma_block
setblock 320 128 633 minecraft:magma_block
setblock 320 128 636 minecraft:magma_block
setblock 320 128 639 minecraft:magma_block
fill 321 128 612 322 128 612 minecraft:basalt
fill 321 128 615 323 128 615 minecraft:basalt
fill 321 128 618 323 130 618 minecraft:basalt
fill 321 128 621 323 131 621 minecraft:basalt
fill 321 128 624 323 131 624 minecraft:basalt
fill 321 128 627 323 131 627 minecraft:basalt
fill 321 128 630 323 130 630 minecraft:basalt
fill 321 128 633 323 129 633 minecraft:basalt
fill 321 128 636 323 128 636 minecraft:basalt
setblock 321 128 639 minecraft:basalt
setblock 323 128 614 minecraft:magma_block
setblock 323 128 617 minecraft:magma_block
setblock 323 128 620 minecraft:magma_block
fill 323 128 622 323 130 622 minecraft:basalt
setblock 323 128 623 minecraft:magma_block
fill 323 128 625 323 130 625 minecraft:basalt
setblock 323 128 626 minecraft:magma_block
fill 323 128 628 323 130 628 minecraft:basalt
setblock 323 128 629 minecraft:magma_block
setblock 323 128 632 minecraft:magma_block
setblock 323 128 635 minecraft:magma_block
fill 324 128 632 324 171 632 minecraft:purple_concrete
fill 282 129 608 282 171 608 minecraft:purple_concrete
setblock 283 129 616 minecraft:basalt
setblock 283 129 617 minecraft:magma_block
fill 283 129 618 283 129 634 minecraft:basalt
fill 284 129 614 284 129 615 minecraft:basalt
fill 284 129 618 284 131 618 minecraft:basalt
fill 284 129 621 284 132 621 minecraft:basalt
fill 284 129 624 284 132 624 minecraft:basalt
fill 284 129 627 284 132 627 minecraft:basalt
fill 284 129 630 284 131 630 minecraft:basalt
fill 284 129 633 284 130 633 minecraft:basalt
setblock 284 129 636 minecraft:basalt
fill 285 129 613 286 129 614 minecraft:basalt
fill 285 129 637 286 129 637 minecraft:basalt
fill 286 129 611 286 129 612 minecraft:basalt
fill 286 129 638 287 129 639 minecraft:basalt
fill 287 129 610 287 129 611 minecraft:basalt
fill 287 129 614 287 132 614 minecraft:basalt
fill 287 129 617 287 133 617 minecraft:basalt
fill 287 129 620 287 135 620 minecraft:basalt
fill 287 129 623 287 135 623 minecraft:basalt
fill 287 129 626 287 136 626 minecraft:basalt
fill 287 129 629 287 135 629 minecraft:basalt
fill 287 129 632 287 134 632 minecraft:basalt
fill 287 129 635 287 132 635 minecraft:basalt
fill 287 129 640 290 129 640 minecraft:basalt
fill 288 129 609 290 129 610 minecraft:basalt
fill 288 129 639 293 130 639 minecraft:basalt
fill 288 129 641 292 129 641 minecraft:basalt
fill 289 129 608 296 129 608 minecraft:basalt
fill 289 129 623 289 138 623 minecraft:basalt
setblock 289 129 624 minecraft:magma_block
fill 289 129 625 289 138 626 minecraft:basalt
setblock 289 129 627 minecraft:magma_block
setblock 289 129 642 minecraft:magma_block
fill 290 129 613 290 134 613 minecraft:basalt
fill 290 129 616 290 136 616 minecraft:basalt
fill 290 129 619 290 136 621 minecraft:basalt
fill 290 129 629 290 136 631 minecraft:basalt
fill 290 129 634 290 136 634 minecraft:basalt
fill 290 129 637 290 134 637 minecraft:basalt
fill 290 129 642 293 129 642 minecraft:basalt
fill 291 129 609 293 131 609 minecraft:basalt
fill 291 129 618 291 138 618 minecraft:basalt
fill 291 129 632 291 138 632 minecraft:basalt
fill 291 129 646 291 175 646 minecraft:purple_concrete
fill 292 129 606 293 129 606 minecraft:basalt
setblock 292 129 617 minecraft:magma_block
fill 292 129 633 292 138 633 minecraft:basalt
setblock 292 129 644 minecraft:magma_block
fill 293 129 612 293 135 612 minecraft:basalt
fill 293 129 615 293 138 615 minecraft:basalt
fill 293 129 635 293 136 636 minecraft:basalt
fill 293 129 644 296 129 644 minecraft:basalt
fill 293 129 646 293 171 646 minecraft:purple_concrete
fill 294 129 605 296 129 605 minecraft:basalt
fill 295 129 604 295 157 604 minecraft:purple_concrete
fill 295 129 614 295 138 614 minecraft:basalt
fill 295 129 636 295 138 636 minecraft:basalt
fill 296 129 611 296 136 611 minecraft:basalt
fill 296 129 613 296 138 613 minecraft:basalt
fill 296 129 637 296 136 638 minecraft:basalt
fill 296 129 641 296 134 641 minecraft:basalt
setblock 298 129 612 minecraft:magma_block
fill 298 129 638 299 138 638 minecraft:basalt
fill 299 129 607 299 133 607 minecraft:basalt
fill 299 129 610 299 136 610 minecraft:basalt
fill 299 129 612 299 138 612 minecraft:basalt
fill 299 129 640 299 136 640 minecraft:basalt
fill 299 129 643 299 133 643 minecraft:basalt
setblock 301 129 611 minecraft:magma_block
fill 301 129 639 305 138 639 minecraft:basalt
fill 302 129 606 302 132 606 minecraft:basalt
fill 302 129 609 302 136 609 minecraft:basalt
fill 302 129 611 305 138 611 minecraft:basalt
fill 302 129 642 302 134 642 minecraft:basalt
fill 302 129 645 302 131 645 minecraft:basalt
fill 305 129 605 312 129 605 minecraft:basalt
fill 305 129 608 305 134 608 minecraft:basalt
fill 305 129 641 305 135 641 minecraft:basalt
fill 305 129 644 305 132 644 minecraft:basalt
setblock 307 129 612 minecraft:magma_block
fill 307 129 638 308 138 638 minecraft:basalt
fill 308 129 607 315 129 607 minecraft:basalt
fill 308 129 610 308 136 610 minecraft:basalt
fill 308 129 612 308 138 612 minecraft:basalt
fill 308 129 640 308 136 640 minecraft:basalt
fill 308 129 643 315 129 643 minecraft:basalt
fill 310 129 613 310 138 613 minecraft:basalt
fill 310 129 637 310 138 637 minecraft:basalt
fill 311 129 606 314 129 606 minecraft:basalt
fill 311 129 609 318 129 609 minecraft:basalt
fill 311 129 612 311 136 612 minecraft:basalt
fill 311 129 614 311 138 614 minecraft:basalt
fill 311 129 636 311 138 636 minecraft:basalt
fill 311 129 639 311 135 639 minecraft:basalt
fill 311 129 642 315 130 642 minecraft:basalt
fill 311 129 645 312 129 645 minecraft:basalt
fill 313 129 615 313 138 615 minecraft:basalt
fill 313 129 635 314 136 635 minecraft:basalt
fill 314 129 608 317 129 608 minecraft:basalt
fill 314 129 611 320 129 611 minecraft:basalt
fill 314 129 614 314 136 614 minecraft:basalt
fill 314 129 617 314 138 617 minecraft:basalt
fill 314 129 633 314 138 633 minecraft:basalt
fill 314 129 638 320 129 638 minecraft:basalt
fill 314 129 641 318 129 641 minecraft:basalt
setblock 314 129 644 minecraft:basalt
fill 315 129 618 315 138 618 minecraft:basalt
fill 315 129 632 315 138 632 minecraft:basalt
fill 316 129 620 316 138 620 minecraft:basalt
setblock 316 129 621 minecraft:magma_block
fill 316 129 629 316 138 629 minecraft:basalt
setblock 316 129 630 minecraft:magma_block
setblock 316 129 642 minecraft:magma_block
fill 317 129 610 319 129 610 minecraft:basalt
fill 317 129 613 321 129 613 minecraft:basalt
fill 317 129 616 317 135 616 minecraft:basalt
fill 317 129 619 317 136 619 minecraft:basalt
fill 317 129 622 317 136 628 minecraft:basalt
fill 317 129 631 317 136 631 minecraft:basalt
fill 317 129 634 317 135 634 minecraft:basalt
fill 317 129 637 321 129 637 minecraft:basalt
fill 317 129 640 319 129 640 minecraft:basalt
setblock 317 129 642 minecraft:basalt
setblock 320 129 612 minecraft:basalt
fill 320 129 615 322 129 615 minecraft:basalt
fill 320 129 618 320 133 618 minecraft:basalt
fill 320 129 621 320 134 621 minecraft:basalt
fill 320 129 624 320 134 624 minecraft:basalt
fill 320 129 627 320 134 627 minecraft:basalt
fill 320 129 630 320 134 630 minecraft:basalt
fill 320 129 633 320 132 633 minecraft:basalt
fill 320 129 636 322 129 636 minecraft:basalt
setblock 320 129 639 minecraft:basalt
setblock 323 129 617 minecraft:basalt
fill 323 129 620 323 130 620 minecraft:basalt
fill 323 129 623 323 131 623 minecraft:basalt
fill 323 129 626 323 131 626 minecraft:basalt
fill 323 129 629 323 131 629 minecraft:basalt
fill 323 129 632 323 130 632 minecraft:basalt
setblock 323 129 646 minecraft:pearlescent_froglight
fill 324 129 633 324 176 633 minecraft:purple_concrete
setblock 324 129 634 minecraft:pearlescent_froglight
fill 283 130 618 283 130 632 minecraft:basalt
fill 284 130 634 286 130 634 minecraft:basalt
setblock 285 130 607 minecraft:light[level=13]
fill 285 130 614 286 130 614 minecraft:basalt
setblock 285 130 615 minecraft:magma_block
fill 285 130 635 286 130 635 minecraft:basalt
setblock 285 130 636 minecraft:magma_block
setblock 285 130 639 minecraft:light[level=13]
setblock 286 130 613 minecraft:basalt
fill 286 130 615 292 131 615 minecraft:basalt
fill 286 130 636 286 130 637 minecraft:basalt
setblock 287 130 611 minecraft:basalt
fill 287 130 636 292 132 636 minecraft:basalt
fill 287 130 638 287 130 639 minecraft:basalt
fill 288 130 610 290 130 610 minecraft:basalt
setblock 288 130 611 minecraft:magma_block
fill 288 130 640 290 130 640 minecraft:basalt
fill 289 130 609 290 130 609 minecraft:basalt
fill 289 130 611 295 131 611 minecraft:basalt
fill 289 130 624 290 130 624 minecraft:basalt
fill 289 130 627 290 130 627 minecraft:basalt
fill 289 130 641 292 130 641 minecraft:basalt
fill 290 130 622 290 139 623 minecraft:basalt
fill 290 130 625 290 139 626 minecraft:basalt
fill 290 130 628 290 139 628 minecraft:basalt
fill 291 130 608 296 130 608 minecraft:basalt
setblock 291 130 619 minecraft:magma_block
fill 291 130 620 291 139 620 minecraft:basalt
fill 291 130 630 291 139 630 minecraft:basalt
setblock 291 130 631 minecraft:magma_block
fill 291 130 642 293 130 642 minecraft:basalt
fill 292 130 607 298 130 607 minecraft:basalt
fill 292 130 617 292 137 618 minecraft:basalt
fill 292 130 632 292 139 632 minecraft:basalt
fill 292 130 643 298 130 643 minecraft:basalt
fill 293 130 616 293 138 616 minecraft:basalt
setblock 293 130 623 minecraft:light[level=13]
setblock 293 130 631 minecraft:light[level=13]
fill 293 130 634 293 138 634 minecraft:basalt
setblock 294 130 606 minecraft:magma_block
setblock 294 130 615 minecraft:magma_block
fill 294 130 635 294 138 635 minecraft:basalt
fill 294 130 644 296 130 644 minecraft:basalt
fill 295 130 606 301 130 606 minecraft:basalt
setblock 296 130 605 minecraft:basalt
fill 296 130 614 296 139 614 minecraft:basalt
fill 296 130 636 296 139 636 minecraft:basalt
fill 296 130 645 301 130 645 minecraft:basalt
setblock 297 130 605 minecraft:magma_block
fill 297 130 613 298 139 613 minecraft:basalt
fill 297 130 637 298 139 637 minecraft:basalt
fill 298 130 605 310 130 605 minecraft:basalt
fill 298 130 612 298 137 612 minecraft:basalt
fill 300 130 612 302 139 612 minecraft:basalt
fill 300 130 638 305 130 638 minecraft:basalt
fill 301 130 611 301 137 611 minecraft:basalt
setblock 301 130 615 minecraft:light[level=13]
setblock 301 130 623 minecraft:light[level=13]
setblock 301 130 631 minecraft:light[level=13]
setblock 303 130 612 minecraft:magma_block
fill 304 130 612 307 137 612 minecraft:basalt
setblock 306 130 638 minecraft:magma_block
fill 306 130 644 312 130 644 minecraft:basalt
fill 308 130 607 314 130 607 minecraft:basalt
fill 308 130 613 308 139 613 minecraft:basalt
fill 308 130 637 308 139 637 minecraft:basalt
fill 308 130 643 314 130 643 minecraft:basalt
setblock 309 130 613 minecraft:magma_block
setblock 309 130 615 minecraft:light[level=13]
setblock 309 130 623 minecraft:light[level=13]
setblock 309 130 631 minecraft:light[level=13]
setblock 309 130 637 minecraft:magma_block
fill 310 130 614 310 139 614 minecraft:basalt
fill 310 130 636 310 139 636 minecraft:basalt
setblock 311 130 606 minecraft:basalt
fill 311 130 609 317 130 609 minecraft:basalt
setblock 312 130 606 minecraft:magma_block
setblock 312 130 615 minecraft:magma_block
fill 312 130 635 312 138 635 minecraft:basalt
fill 313 130 616 313 137 616 minecraft:basalt
fill 313 130 634 313 137 634 minecraft:basalt
fill 314 130 608 314 131 608 minecraft:basalt
fill 314 130 611 319 130 611 minecraft:basalt
fill 314 130 618 314 139 618 minecraft:basalt
fill 314 130 632 314 139 632 minecraft:basalt
fill 314 130 638 319 130 638 minecraft:basalt
fill 314 130 641 317 130 641 minecraft:basalt
setblock 315 130 608 minecraft:magma_block
fill 315 130 614 321 130 614 minecraft:basalt
fill 315 130 619 315 139 619 minecraft:basalt
setblock 315 130 620 minecraft:magma_block
fill 315 130 630 315 139 631 minecraft:basalt
fill 315 130 635 321 130 635 minecraft:basalt
fill 316 130 621 316 137 628 minecraft:basalt
fill 316 130 630 316 137 630 minecraft:basalt
setblock 317 130 607 minecraft:light[level=13]
setblock 317 130 610 minecraft:basalt
fill 317 130 613 320 130 613 minecraft:basalt
fill 317 130 637 320 130 637 minecraft:basalt
setblock 317 130 640 minecraft:basalt
setblock 318 130 610 minecraft:magma_block
fill 318 130 616 322 130 616 minecraft:basalt
fill 318 130 634 322 130 634 minecraft:basalt
setblock 318 130 640 minecraft:magma_block
fill 320 130 615 320 131 615 minecraft:basalt
fill 320 130 636 320 131 636 minecraft:basalt
setblock 321 130 615 minecraft:magma_block
fill 321 130 633 322 130 633 minecraft:basalt
setblock 321 130 636 minecraft:magma_block
fill 323 130 646 323 156 646 minecraft:purple_concrete
fill 324 130 634 324 146 634 minecraft:purple_concrete
fill 283 131 621 283 131 629 minecraft:basalt
fill 284 131 619 286 131 619 minecraft:basalt
setblock 284 131 620 minecraft:magma_block
fill 284 131 631 286 131 631 minecraft:basalt
setblock 284 131 632 minecraft:magma_block
fill 285 131 616 286 131 617 minecraft:basalt
fill 285 131 620 286 132 620 minecraft:basalt
fill 285 131 632 286 132 632 minecraft:basalt
fill 285 131 634 286 131 634 minecraft:basalt
setblock 286 131 614 minecraft:basalt
fill 286 131 635 286 131 636 minecraft:basalt
setblock 287 131 613 minecraft:magma_block
setblock 287 131 637 minecraft:magma_block
fill 288 131 612 289 131 613 minecraft:basalt
fill 288 131 637 289 132 637 minecraft:basalt
fill 289 131 624 289 137 624 minecraft:basalt
fill 289 131 627 289 137 627 minecraft:basalt
fill 289 131 639 293 131 639 minecraft:basalt
setblock 290 131 610 minecraft:basalt
setblock 290 131 624 minecraft:magma_block
setblock 290 131 627 minecraft:magma_block
setblock 290 131 640 minecraft:basalt
fill 291 131 619 292 131 619 minecraft:basalt
fill 291 131 621 291 139 622 minecraft:basalt
fill 291 131 628 291 139 629 minecraft:basalt
fill 291 131 631 292 131 631 minecraft:basalt
fill 291 131 641 292 131 641 minecraft:basalt
setblock 292 131 608 minecraft:basalt
fill 292 131 642 293 131 642 minecraft:basalt
setblock 293 131 608 minecraft:magma_block
setblock 293 131 617 minecraft:magma_block
fill 293 131 633 293 139 633 minecraft:basalt
fill 294 131 607 296 131 608 minecraft:basalt
fill 294 131 615 294 138 616 minecraft:basalt
fill 294 131 634 294 139 634 minecraft:basalt
fill 294 131 643 298 131 643 minecraft:basalt
fill 295 131 615 295 139 615 minecraft:basalt
fill 295 131 635 295 139 635 minecraft:basalt
setblock 296 131 604 minecraft:white_concrete
fill 296 131 606 301 131 606 minecraft:basalt
setblock 296 131 644 minecraft:basalt
fill 297 131 607 298 132 607 minecraft:basalt
fill 297 131 614 297 140 614 minecraft:basalt
fill 297 131 636 297 140 636 minecraft:basalt
fill 299 131 605 301 131 605 minecraft:basalt
fill 299 131 613 300 139 613 minecraft:basalt
fill 299 131 637 300 139 637 minecraft:basalt
setblock 299 131 645 minecraft:magma_block
fill 300 131 638 301 139 638 minecraft:basalt
fill 300 131 645 301 131 645 minecraft:basalt
setblock 302 131 605 minecraft:magma_block
setblock 302 131 638 minecraft:magma_block
fill 303 131 605 307 131 606 minecraft:basalt
fill 303 131 612 303 138 612 minecraft:basalt
fill 303 131 638 306 138 638 minecraft:basalt
fill 303 131 645 307 131 645 minecraft:basalt
fill 306 131 613 307 139 613 minecraft:basalt
fill 306 131 637 307 139 637 minecraft:basalt
fill 306 131 644 310 131 644 minecraft:basalt
setblock 308 131 606 minecraft:magma_block
fill 308 131 607 312 131 607 minecraft:basalt
fill 308 131 643 312 131 643 minecraft:basalt
fill 309 131 606 310 131 606 minecraft:basalt
fill 309 131 613 309 138 614 minecraft:basalt
fill 309 131 636 309 138 637 minecraft:basalt
fill 311 131 609 315 131 609 minecraft:basalt
fill 311 131 615 312 138 615 minecraft:basalt
setblock 311 131 635 minecraft:magma_block
fill 311 131 642 314 131 642 minecraft:basalt
fill 312 131 612 318 131 612 minecraft:basalt
fill 312 131 616 312 139 616 minecraft:basalt
fill 312 131 634 312 139 634 minecraft:basalt
fill 312 131 639 316 132 639 minecraft:basalt
fill 313 131 617 313 139 617 minecraft:basalt
fill 313 131 633 313 139 633 minecraft:basalt
fill 314 131 611 317 131 611 minecraft:basalt
setblock 314 131 619 minecraft:magma_block
setblock 314 131 631 minecraft:magma_block
fill 314 131 638 318 131 638 minecraft:basalt
fill 314 131 641 315 131 641 minecraft:basalt
fill 315 131 614 319 132 614 minecraft:basalt
fill 315 131 617 321 131 617 minecraft:basalt
fill 315 131 620 315 138 622 minecraft:basalt
fill 315 131 628 315 138 629 minecraft:basalt
fill 315 131 635 319 132 635 minecraft:basalt
fill 317 131 613 319 131 613 minecraft:basalt
fill 317 131 637 319 131 637 minecraft:basalt
setblock 317 131 639 minecraft:magma_block
fill 318 131 616 321 131 616 minecraft:basalt
fill 318 131 619 322 131 619 minecraft:basalt
fill 318 131 631 322 131 631 minecraft:basalt
fill 318 131 634 321 131 634 minecraft:basalt
setblock 320 131 614 minecraft:magma_block
setblock 320 131 635 minecraft:magma_block
fill 321 131 618 322 131 618 minecraft:basalt
fill 321 131 630 322 131 630 minecraft:basalt
setblock 321 131 633 minecraft:basalt
setblock 322 131 604 minecraft:pearlescent_froglight
setblock 323 131 622 minecraft:magma_block
setblock 323 131 625 minecraft:magma_block
setblock 323 131 628 minecraft:magma_block
setblock 324 131 614 minecraft:pearlescent_froglight
setblock 282 132 635 minecraft:amethyst_block
fill 285 132 619 286 132 619 minecraft:basalt
fill 285 132 631 286 132 631 minecraft:basalt
fill 286 132 616 286 132 617 minecraft:basalt
setblock 286 132 633 minecraft:magma_block
setblock 286 132 634 minecraft:basalt
fill 287 132 615 292 132 615 minecraft:basalt
fill 287 132 633 291 133 633 minecraft:basalt
fill 288 132 613 289 132 613 minecraft:basalt
setblock 289 132 612 minecraft:basalt
setblock 289 132 638 minecraft:magma_block
fill 290 132 611 295 132 611 minecraft:basalt
fill 290 132 624 291 132 624 minecraft:basalt
fill 290 132 627 291 139 627 minecraft:basalt
fill 290 132 638 293 132 639 minecraft:basalt
fill 291 132 619 291 138 619 minecraft:basalt
fill 291 132 623 291 140 623 minecraft:basalt
fill 291 132 625 291 140 626 minecraft:basalt
fill 291 132 631 291 138 631 minecraft:basalt
fill 292 132 609 293 132 609 minecraft:basalt
setblock 292 132 619 minecraft:magma_block
fill 292 132 620 292 140 621 minecraft:basalt
fill 292 132 629 292 140 630 minecraft:basalt
setblock 292 132 631 minecraft:magma_block
setblock 292 132 641 minecraft:basalt
setblock 292 132 646 minecraft:white_concrete
fill 293 132 617 293 139 618 minecraft:basalt
fill 293 132 632 293 139 632 minecraft:basalt
fill 294 132 608 296 132 608 minecraft:basalt
fill 294 132 617 294 140 617 minecraft:basalt
fill 294 132 633 294 140 633 minecraft:basalt
fill 294 132 638 295 136 638 minecraft:basalt
setblock 294 132 642 minecraft:basalt
fill 295 132 616 295 140 616 minecraft:basalt
fill 295 132 634 295 140 634 minecraft:basalt
setblock 295 132 642 minecraft:magma_block
fill 296 132 604 296 175 604 minecraft:purple_concrete
setblock 296 132 607 minecraft:basalt
fill 296 132 615 296 140 615 minecraft:basalt
fill 296 132 635 296 140 635 minecraft:basalt
fill 296 132 642 298 132 643 minecraft:basalt
setblock 298 132 614 minecraft:magma_block
fill 298 132 636 299 139 636 minecraft:basalt
fill 299 132 606 301 132 606 minecraft:basalt
fill 299 132 614 299 140 614 minecraft:basalt
fill 299 132 642 301 134 642 minecraft:basalt
fill 299 132 644 304 132 644 minecraft:basalt
fill 300 132 646 300 158 646 minecraft:purple_concrete
setblock 301 132 613 minecraft:magma_block
setblock 301 132 637 minecraft:magma_block
setblock 301 132 646 minecraft:pearlescent_froglight
fill 302 132 613 305 139 613 minecraft:basalt
fill 302 132 637 302 139 638 minecraft:basalt
setblock 303 132 606 minecraft:basalt
fill 303 132 637 305 139 637 minecraft:basalt
setblock 304 132 606 minecraft:magma_block
fill 305 132 606 307 132 606 minecraft:basalt
fill 306 132 608 312 132 608 minecraft:basalt
setblock 306 132 644 minecraft:basalt
setblock 307 132 614 minecraft:magma_block
fill 307 132 636 308 139 636 minecraft:basalt
setblock 307 132 644 minecraft:magma_block
fill 308 132 607 309 132 607 minecraft:basalt
fill 308 132 614 308 140 614 minecraft:basalt
fill 308 132 643 309 132 643 minecraft:basalt
fill 309 132 610 315 132 610 minecraft:basalt
fill 309 132 640 315 132 640 minecraft:basalt
setblock 310 132 607 minecraft:magma_block
fill 310 132 615 310 140 615 minecraft:basalt
fill 310 132 635 311 139 635 minecraft:basalt
setblock 310 132 643 minecraft:magma_block
fill 311 132 609 312 133 609 minecraft:basalt
fill 311 132 616 311 140 616 minecraft:basalt
fill 311 132 634 311 140 634 minecraft:basalt
fill 311 132 642 312 132 642 minecraft:basalt
fill 312 132 612 317 132 612 minecraft:basalt
fill 312 132 617 312 140 617 minecraft:basalt
fill 312 132 633 312 140 633 minecraft:basalt
setblock 313 132 609 minecraft:magma_block
setblock 313 132 618 minecraft:magma_block
fill 313 132 632 313 140 632 minecraft:basalt
fill 313 132 646 314 138 646 minecraft:purple_concrete
setblock 314 132 609 minecraft:basalt
fill 314 132 611 315 133 611 minecraft:basalt
fill 314 132 619 314 139 621 minecraft:basalt
fill 314 132 629 314 139 631 minecraft:basalt
fill 314 132 638 317 132 638 minecraft:basalt
setblock 314 132 641 minecraft:basalt
fill 315 132 617 320 132 617 minecraft:basalt
fill 315 132 623 315 132 627 minecraft:basalt
setblock 315 132 646 minecraft:amethyst_block
setblock 316 132 611 minecraft:magma_block
fill 316 132 646 316 175 646 minecraft:purple_concrete
fill 317 132 613 318 132 613 minecraft:basalt
fill 317 132 632 321 132 632 minecraft:basalt
fill 317 132 637 318 132 637 minecraft:basalt
fill 318 132 616 320 132 616 minecraft:basalt
fill 318 132 619 321 132 619 minecraft:basalt
fill 318 132 631 321 132 631 minecraft:basalt
fill 318 132 634 320 132 634 minecraft:basalt
fill 320 132 620 321 132 620 minecraft:basalt
setblock 321 132 618 minecraft:basalt
fill 321 132 621 321 133 621 minecraft:basalt
fill 321 132 624 321 133 624 minecraft:basalt
fill 321 132 627 321 133 627 minecraft:basalt
fill 321 132 630 321 133 630 minecraft:basalt
fill 322 132 604 322 175 604 minecraft:purple_concrete
setblock 322 132 621 minecraft:magma_block
setblock 322 132 624 minecraft:magma_block
setblock 322 132 627 minecraft:magma_block
fill 324 132 614 324 135 614 minecraft:purple_concrete
fill 282 133 635 282 155 635 minecraft:purple_concrete
fill 283 133 604 283 173 604 minecraft:purple_concrete
setblock 284 133 604 minecraft:white_concrete
setblock 285 133 620 minecraft:magma_block
fill 285 133 622 286 133 622 minecraft:basalt
setblock 285 133 623 minecraft:magma_block
fill 285 133 625 286 133 625 minecraft:basalt
setblock 285 133 626 minecraft:magma_block
fill 285 133 628 286 133 628 minecraft:basalt
setblock 285 133 629 minecraft:magma_block
fill 286 133 618 286 133 620 minecraft:basalt
fill 286 133 623 286 134 623 minecraft:basalt
fill 286 133 626 286 134 626 minecraft:basalt
fill 286 133 629 286 134 629 minecraft:basalt
fill 286 133 631 286 133 632 minecraft:basalt
fill 287 133 618 290 133 618 minecraft:basalt
fill 288 133 615 292 133 615 minecraft:basalt
fill 288 133 636 292 133 636 minecraft:basalt
setblock 289 133 613 minecraft:basalt
setblock 289 133 637 minecraft:basalt
fill 290 133 624 290 139 624 minecraft:basalt
fill 290 133 638 293 133 638 minecraft:basalt
fill 291 133 611 295 133 611 minecraft:basalt
setblock 291 133 624 minecraft:magma_block
setblock 291 133 639 minecraft:magma_block
fill 292 133 610 298 133 610 minecraft:basalt
fill 292 133 619 293 140 619 minecraft:basalt
fill 292 133 622 292 140 623 minecraft:basalt
fill 292 133 627 292 140 628 minecraft:basalt
fill 292 133 631 293 140 631 minecraft:basalt
fill 292 133 639 293 133 640 minecraft:basalt
fill 292 133 646 292 154 646 minecraft:purple_concrete
fill 293 133 620 293 141 620 minecraft:basalt
fill 293 133 630 293 141 630 minecraft:basalt
fill 294 133 618 294 141 618 minecraft:basalt
setblock 294 133 632 minecraft:magma_block
fill 294 133 640 298 134 640 minecraft:basalt
setblock 294 133 641 minecraft:magma_block
fill 295 133 617 295 141 617 minecraft:basalt
fill 295 133 633 295 140 633 minecraft:basalt
setblock 295 133 641 minecraft:basalt
setblock 296 133 608 minecraft:basalt
fill 296 133 616 296 141 616 minecraft:basalt
fill 296 133 634 296 141 634 minecraft:basalt
fill 296 133 642 298 133 642 minecraft:basalt
fill 297 133 615 298 141 615 minecraft:basalt
fill 297 133 635 298 140 635 minecraft:basalt
setblock 298 133 607 minecraft:basalt
fill 298 133 614 298 140 614 minecraft:basalt
setblock 298 133 643 minecraft:basalt
fill 300 133 607 305 133 607 minecraft:basalt
fill 300 133 614 301 141 614 minecraft:basalt
setblock 300 133 636 minecraft:magma_block
fill 300 133 643 305 133 643 minecraft:basalt
fill 301 133 613 301 140 613 minecraft:basalt
fill 301 133 636 301 140 637 minecraft:basalt
fill 301 133 646 301 147 646 minecraft:purple_concrete
fill 303 133 642 308 133 642 minecraft:basalt
fill 305 133 614 307 140 614 minecraft:basalt
fill 305 133 636 306 133 636 minecraft:basalt
setblock 306 133 604 minecraft:white_concrete
setblock 306 133 607 minecraft:magma_block
fill 306 133 608 310 133 608 minecraft:basalt
fill 306 133 641 311 133 641 minecraft:basalt
setblock 306 133 643 minecraft:magma_block
fill 307 133 607 308 133 607 minecraft:basalt
fill 307 133 643 308 133 643 minecraft:basalt
fill 308 133 615 308 141 615 minecraft:basalt
fill 308 133 635 309 133 635 minecraft:basalt
fill 309 133 610 314 133 610 minecraft:basalt
setblock 309 133 615 minecraft:magma_block
fill 309 133 640 314 133 640 minecraft:basalt
setblock 309 133 642 minecraft:magma_block
fill 310 133 616 310 140 616 minecraft:basalt
fill 310 133 634 310 140 634 minecraft:basalt
setblock 310 133 642 minecraft:basalt
fill 311 133 617 311 141 617 minecraft:basalt
fill 311 133 633 311 141 633 minecraft:basalt
fill 312 133 612 316 133 612 minecraft:basalt
fill 312 133 618 313 140 618 minecraft:basalt
setblock 312 133 632 minecraft:magma_block
fill 312 133 636 317 134 636 minecraft:basalt
fill 312 133 639 315 133 639 minecraft:basalt
setblock 312 133 641 minecraft:magma_block
fill 313 133 619 313 141 620 minecraft:basalt
fill 313 133 630 313 140 631 minecraft:basalt
fill 314 133 622 314 141 623 minecraft:basalt
fill 314 133 627 314 133 628 minecraft:basalt
fill 314 133 638 316 133 638 minecraft:basalt
fill 315 133 614 318 133 614 minecraft:basalt
fill 315 133 617 319 133 617 minecraft:basalt
fill 315 133 623 315 140 624 minecraft:basalt
setblock 315 133 625 minecraft:magma_block
fill 315 133 626 315 140 627 minecraft:basalt
fill 315 133 635 318 133 635 minecraft:basalt
fill 315 133 646 315 173 646 minecraft:purple_concrete
setblock 317 133 613 minecraft:basalt
fill 317 133 615 317 134 615 minecraft:basalt
fill 317 133 632 320 133 632 minecraft:basalt
setblock 317 133 637 minecraft:basalt
setblock 318 133 615 minecraft:magma_block
fill 318 133 616 319 133 616 minecraft:basalt
fill 318 133 619 320 133 619 minecraft:basalt
fill 318 133 631 320 133 631 minecraft:basalt
fill 318 133 634 319 133 634 minecraft:basalt
setblock 318 133 636 minecraft:magma_block
setblock 319 133 646 minecraft:amethyst_block
fill 320 133 620 320 134 620 minecraft:basalt
fill 320 133 622 320 133 623 minecraft:basalt
fill 320 133 625 320 133 626 minecraft:basalt
fill 320 133 628 320 133 629 minecraft:basalt
fill 320 133 646 321 146 646 minecraft:purple_concrete
setblock 321 133 620 minecraft:magma_block
setblock 321 133 622 minecraft:basalt
setblock 321 133 623 minecraft:magma_block
setblock 321 133 625 minecraft:basalt
setblock 321 133 626 minecraft:magma_block
setblock 321 133 628 minecraft:basalt
setblock 321 133 629 minecraft:magma_block
setblock 282 134 630 minecraft:white_concrete
fill 284 134 604 284 174 604 minecraft:purple_concrete
fill 286 134 620 286 134 622 minecraft:basalt
fill 286 134 624 286 134 625 minecraft:basalt
fill 286 134 627 286 134 628 minecraft:basalt
fill 286 134 630 289 134 630 minecraft:basalt
setblock 287 134 618 minecraft:magma_block
fill 287 134 621 289 135 621 minecraft:basalt
fill 287 134 624 288 136 624 minecraft:basalt
fill 287 134 627 288 135 627 minecraft:basalt
fill 287 134 646 287 175 646 minecraft:purple_concrete
fill 288 134 616 289 134 616 minecraft:basalt
fill 288 134 618 290 135 618 minecraft:basalt
fill 288 134 633 289 134 634 minecraft:basalt
setblock 288 134 646 minecraft:pearlescent_froglight
fill 289 134 614 289 134 615 minecraft:basalt
fill 289 134 635 292 134 636 minecraft:basalt
setblock 290 134 614 minecraft:magma_block
fill 290 134 615 292 135 615 minecraft:basalt
fill 290 134 633 291 136 633 minecraft:basalt
fill 291 134 612 292 134 612 minecraft:basalt
fill 291 134 614 294 135 614 minecraft:basalt
fill 291 134 624 292 140 624 minecraft:basalt
fill 291 134 638 293 134 638 minecraft:basalt
fill 292 134 611 295 134 611 minecraft:basalt
fill 292 134 625 292 140 626 minecraft:basalt
fill 292 134 639 293 134 639 minecraft:basalt
fill 293 134 621 293 142 621 minecraft:basalt
setblock 293 134 622 minecraft:magma_block
setblock 293 134 628 minecraft:magma_block
fill 293 134 629 293 142 629 minecraft:basalt
fill 294 134 610 298 134 610 minecraft:basalt
fill 294 134 619 294 141 619 minecraft:basalt
fill 294 134 631 294 141 632 minecraft:basalt
fill 295 134 618 295 142 618 minecraft:basalt
fill 295 134 632 295 142 632 minecraft:basalt
setblock 296 134 609 minecraft:magma_block
fill 296 134 617 296 142 617 minecraft:basalt
setblock 296 134 633 minecraft:magma_block
fill 297 134 609 301 134 609 minecraft:basalt
fill 297 134 616 297 141 616 minecraft:basalt
fill 297 134 634 297 141 634 minecraft:basalt
setblock 298 134 608 minecraft:basalt
setblock 298 134 642 minecraft:basalt
setblock 299 134 608 minecraft:magma_block
fill 299 134 615 300 141 615 minecraft:basalt
setblock 299 134 635 minecraft:magma_block
fill 300 134 608 304 134 608 minecraft:basalt
fill 300 134 635 300 141 636 minecraft:basalt
fill 302 134 614 304 141 614 minecraft:basalt
fill 302 134 636 304 140 636 minecraft:basalt
fill 303 134 642 304 134 642 minecraft:basalt
setblock 305 134 636 minecraft:magma_block
setblock 305 134 642 minecraft:magma_block
fill 306 134 604 306 156 604 minecraft:purple_concrete
fill 306 134 608 307 134 608 minecraft:basalt
fill 306 134 615 307 142 615 minecraft:basalt
fill 306 134 635 306 141 636 minecraft:basalt
fill 306 134 641 308 134 642 minecraft:basalt
fill 307 134 635 307 140 635 minecraft:basalt
setblock 308 134 608 minecraft:magma_block
setblock 308 134 635 minecraft:magma_block
fill 309 134 610 310 135 610 minecraft:basalt
fill 309 134 615 309 141 616 minecraft:basalt
fill 309 134 634 309 141 635 minecraft:basalt
fill 309 134 640 310 134 641 minecraft:basalt
fill 310 134 617 310 142 617 minecraft:basalt
fill 310 134 633 310 142 633 minecraft:basalt
setblock 311 134 610 minecraft:magma_block
fill 311 134 618 311 142 618 minecraft:basalt
fill 311 134 632 312 141 632 minecraft:basalt
setblock 311 134 640 minecraft:magma_block
setblock 312 134 610 minecraft:basalt
fill 312 134 612 313 135 612 minecraft:basalt
fill 312 134 619 312 141 619 minecraft:basalt
fill 312 134 631 312 141 631 minecraft:basalt
fill 312 134 639 312 134 640 minecraft:basalt
fill 313 134 621 313 140 622 minecraft:basalt
fill 313 134 628 313 142 629 minecraft:basalt
setblock 313 134 639 minecraft:basalt
setblock 314 134 611 minecraft:basalt
setblock 314 134 612 minecraft:magma_block
setblock 314 134 624 minecraft:magma_block
fill 314 134 625 314 141 626 minecraft:basalt
setblock 314 134 627 minecraft:magma_block
fill 314 134 628 314 141 628 minecraft:basalt
fill 314 134 638 315 134 638 minecraft:basalt
setblock 314 134 639 minecraft:magma_block
setblock 315 134 612 minecraft:basalt
fill 315 134 614 316 134 614 minecraft:basalt
fill 315 134 617 318 134 617 minecraft:basalt
fill 315 134 625 315 140 625 minecraft:basalt
fill 315 134 633 318 134 633 minecraft:basalt
fill 315 134 635 316 135 635 minecraft:basalt
setblock 317 134 614 minecraft:magma_block
fill 317 134 632 319 134 632 minecraft:basalt
setblock 317 134 635 minecraft:magma_block
setblock 318 134 616 minecraft:basalt
fill 318 134 619 319 134 619 minecraft:basalt
fill 318 134 631 319 134 631 minecraft:basalt
setblock 318 134 634 minecraft:basalt
fill 319 134 646 319 154 646 minecraft:purple_concrete
setblock 320 134 622 minecraft:magma_block
setblock 320 134 623 minecraft:basalt
setblock 320 134 625 minecraft:magma_block
setblock 320 134 626 minecraft:basalt
setblock 320 134 628 minecraft:magma_block
setblock 320 134 629 minecraft:basalt
fill 324 134 619 324 149 621 minecraft:purple_concrete
setblock 324 134 622 minecraft:white_concrete
fill 324 134 623 324 160 623 minecraft:purple_concrete
fill 324 134 639 324 148 640 minecraft:purple_concrete
setblock 324 134 641 minecraft:amethyst_block
fill 324 134 642 324 138 644 minecraft:purple_concrete
setblock 282 135 606 minecraft:white_concrete
fill 282 135 630 282 162 630 minecraft:purple_concrete
fill 287 135 630 289 135 630 minecraft:basalt
fill 288 135 619 289 135 619 minecraft:basalt
fill 288 135 631 289 135 631 minecraft:basalt
fill 288 135 646 288 139 646 minecraft:purple_concrete
setblock 289 135 616 minecraft:magma_block
fill 289 135 617 291 135 617 minecraft:basalt
setblock 289 135 633 minecraft:basalt
setblock 289 135 634 minecraft:magma_block
fill 290 135 635 292 135 635 minecraft:basalt
fill 291 135 636 292 135 636 minecraft:basalt
fill 292 135 613 295 135 613 minecraft:basalt
fill 292 135 637 295 135 637 minecraft:basalt
fill 293 135 622 293 142 628 minecraft:basalt
setblock 293 135 638 minecraft:basalt
setblock 294 135 611 minecraft:basalt
fill 294 135 620 294 141 621 minecraft:basalt
fill 294 135 629 294 142 630 minecraft:basalt
setblock 295 135 611 minecraft:magma_block
fill 295 135 619 295 142 619 minecraft:basalt
fill 295 135 631 295 142 631 minecraft:basalt
fill 296 135 610 298 135 610 minecraft:basalt
fill 296 135 618 296 142 618 minecraft:basalt
fill 296 135 632 296 142 633 minecraft:basalt
fill 296 135 640 298 135 640 minecraft:basalt
fill 297 135 617 297 142 617 minecraft:basalt
fill 297 135 633 297 142 633 minecraft:basalt
fill 298 135 609 300 135 609 minecraft:basalt
setblock 298 135 616 minecraft:magma_block
setblock 298 135 634 minecraft:magma_block
fill 298 135 641 303 135 641 minecraft:basalt
fill 299 135 616 299 143 616 minecraft:basalt
fill 299 135 634 299 142 635 minecraft:basalt
setblock 301 135 609 minecraft:magma_block
setblock 301 135 615 minecraft:magma_block
fill 301 135 635 303 141 635 minecraft:basalt
fill 302 135 615 305 142 615 minecraft:basalt
fill 303 135 609 308 135 609 minecraft:basalt
setblock 304 135 635 minecraft:magma_block
setblock 304 135 641 minecraft:magma_block
fill 305 135 635 305 141 636 minecraft:basalt
fill 306 135 611 312 135 611 minecraft:basalt
fill 306 135 641 308 135 641 minecraft:basalt
setblock 307 135 616 minecraft:magma_block
setblock 307 135 634 minecraft:magma_block
fill 308 135 616 308 142 616 minecraft:basalt
fill 308 135 634 308 141 635 minecraft:basalt
fill 309 135 617 309 142 617 minecraft:basalt
fill 309 135 633 309 141 633 minecraft:basalt
fill 309 135 638 312 136 638 minecraft:basalt
fill 309 135 640 310 135 640 minecraft:basalt
setblock 310 135 618 minecraft:magma_block
fill 310 135 632 310 143 632 minecraft:basalt
fill 311 135 604 312 172 604 minecraft:purple_concrete
fill 311 135 613 314 135 613 minecraft:basalt
fill 311 135 619 311 142 619 minecraft:basalt
fill 311 135 631 311 142 631 minecraft:basalt
fill 311 135 637 314 135 637 minecraft:basalt
fill 312 135 620 312 141 621 minecraft:basalt
fill 312 135 629 312 142 630 minecraft:basalt
fill 312 135 636 315 135 636 minecraft:basalt
setblock 312 135 639 minecraft:basalt
setblock 313 135 604 minecraft:amethyst_block
setblock 313 135 623 minecraft:magma_block
fill 313 135 624 313 142 625 minecraft:basalt
setblock 313 135 626 minecraft:magma_block
fill 313 135 627 314 141 627 minecraft:basalt
setblock 313 135 638 minecraft:magma_block
fill 314 135 624 314 141 624 minecraft:basalt
setblock 315 135 614 minecraft:basalt
fill 315 135 617 317 135 617 minecraft:basalt
fill 315 135 633 317 135 633 minecraft:basalt
fill 317 135 618 318 135 618 minecraft:basalt
fill 317 135 620 318 135 621 minecraft:basalt
fill 317 135 629 318 135 630 minecraft:basalt
fill 317 135 632 318 135 632 minecraft:basalt
setblock 318 135 619 minecraft:basalt
fill 318 135 622 318 135 628 minecraft:basalt
setblock 318 135 631 minecraft:basalt
setblock 319 135 620 minecraft:basalt
setblock 319 135 621 minecraft:magma_block
fill 319 135 622 319 135 623 minecraft:basalt
setblock 319 135 624 minecraft:magma_block
fill 319 135 625 319 136 626 minecraft:basalt
setblock 319 135 627 minecraft:magma_block
fill 319 135 628 319 135 629 minecraft:basalt
setblock 319 135 630 minecraft:magma_block
fill 324 135 604 324 175 604 minecraft:purple_concrete
setblock 324 135 605 minecraft:pearlescent_froglight
fill 324 135 606 324 153 611 minecraft:purple_concrete
setblock 324 135 612 minecraft:amethyst_block
fill 324 135 622 324 168 622 minecraft:purple_concrete
fill 324 135 641 324 175 641 minecraft:purple_concrete
fill 282 136 606 282 175 606 minecraft:purple_concrete
fill 282 136 612 282 137 612 minecraft:gold_block
fill 282 136 628 282 137 628 minecraft:gold_block
fill 282 136 644 282 137 644 minecraft:gold_block
fill 286 136 604 286 137 604 minecraft:gold_block
setblock 288 136 621 minecraft:magma_block
fill 288 136 622 289 136 622 minecraft:basalt
setblock 288 136 627 minecraft:magma_block
fill 288 136 628 289 136 628 minecraft:basalt
setblock 288 136 630 minecraft:magma_block
fill 289 136 618 289 136 619 minecraft:basalt
fill 289 136 621 289 137 621 minecraft:basalt
fill 289 136 630 289 136 632 minecraft:basalt
fill 290 136 617 290 136 618 minecraft:basalt
fill 290 136 632 290 137 632 minecraft:basalt
fill 291 136 615 292 136 615 minecraft:basalt
fill 291 136 617 291 137 617 minecraft:basalt
setblock 291 136 635 minecraft:magma_block
fill 292 136 614 294 136 614 minecraft:basalt
fill 292 136 635 292 136 636 minecraft:basalt
fill 293 136 613 295 136 613 minecraft:basalt
fill 293 136 637 295 136 637 minecraft:basalt
setblock 294 136 622 minecraft:magma_block
fill 294 136 623 294 143 623 minecraft:basalt
fill 294 136 627 294 143 627 minecraft:basalt
setblock 294 136 628 minecraft:magma_block
fill 295 136 620 295 143 620 minecraft:basalt
fill 295 136 630 295 143 630 minecraft:basalt
fill 296 136 619 296 143 619 minecraft:basalt
fill 296 136 631 296 143 631 minecraft:basalt
setblock 296 136 639 minecraft:basalt
fill 296 136 646 296 137 646 minecraft:gold_block
setblock 297 136 618 minecraft:magma_block
fill 297 136 632 297 143 632 minecraft:basalt
setblock 297 136 639 minecraft:magma_block
setblock 298 136 610 minecraft:basalt
fill 298 136 616 298 142 617 minecraft:basalt
fill 298 136 633 298 142 634 minecraft:basalt
fill 298 136 639 298 136 640 minecraft:basalt
fill 299 136 639 300 137 639 minecraft:basalt
fill 300 136 616 301 143 616 minecraft:basalt
fill 300 136 634 301 143 634 minecraft:basalt
fill 301 136 615 301 142 615 minecraft:basalt
fill 302 136 604 302 137 604 minecraft:gold_block
fill 302 136 641 304 136 641 minecraft:basalt
fill 303 136 609 304 136 609 minecraft:basalt
fill 304 136 635 304 142 635 minecraft:basalt
fill 305 136 616 307 143 616 minecraft:basalt
fill 305 136 634 307 143 634 minecraft:basalt
fill 306 136 611 308 137 611 minecraft:basalt
fill 308 136 617 308 142 617 minecraft:basalt
fill 308 136 633 308 143 633 minecraft:basalt
setblock 309 136 611 minecraft:magma_block
fill 309 136 618 310 143 618 minecraft:basalt
setblock 309 136 632 minecraft:magma_block
setblock 310 136 611 minecraft:basalt
fill 310 136 619 310 143 619 minecraft:basalt
fill 310 136 631 310 143 631 minecraft:basalt
fill 311 136 613 313 136 613 minecraft:basalt
fill 311 136 620 311 143 620 minecraft:basalt
fill 311 136 630 311 143 630 minecraft:basalt
fill 311 136 637 313 136 637 minecraft:basalt
setblock 312 136 612 minecraft:basalt
setblock 312 136 622 minecraft:magma_block
fill 312 136 623 313 142 623 minecraft:basalt
fill 312 136 627 312 143 627 minecraft:basalt
setblock 312 136 628 minecraft:magma_block
fill 312 136 636 314 136 636 minecraft:basalt
fill 312 136 646 312 137 646 minecraft:gold_block
fill 313 136 604 313 175 604 minecraft:purple_concrete
fill 313 136 626 313 142 626 minecraft:basalt
fill 314 136 615 314 137 616 minecraft:basalt
setblock 315 136 615 minecraft:magma_block
fill 315 136 616 316 136 617 minecraft:basalt
fill 315 136 633 316 136 633 minecraft:basalt
setblock 315 136 635 minecraft:basalt
fill 317 136 604 317 175 604 minecraft:purple_concrete
setblock 317 136 618 minecraft:basalt
fill 317 136 620 317 137 621 minecraft:basalt
fill 317 136 629 317 137 630 minecraft:basalt
setblock 317 136 632 minecraft:basalt
fill 318 136 604 318 137 604 minecraft:gold_block
setblock 318 136 620 minecraft:magma_block
fill 318 136 621 318 136 622 minecraft:basalt
setblock 318 136 623 minecraft:magma_block
fill 318 136 624 318 136 628 minecraft:basalt
setblock 318 136 629 minecraft:magma_block
setblock 318 136 630 minecraft:basalt
setblock 319 136 624 minecraft:basalt
fill 324 136 605 324 156 605 minecraft:purple_concrete
fill 324 136 612 324 156 612 minecraft:purple_concrete
fill 324 136 614 324 137 614 minecraft:gold_block
fill 324 136 630 324 137 630 minecraft:gold_block
setblock 324 136 631 minecraft:pearlescent_froglight
fill 288 137 624 288 137 625 minecraft:basalt
setblock 288 137 627 minecraft:basalt
fill 289 137 620 290 137 620 minecraft:basalt
setblock 289 137 622 minecraft:basalt
fill 289 137 628 289 137 630 minecraft:basalt
setblock 290 137 618 minecraft:basalt
setblock 290 137 619 minecraft:magma_block
fill 290 137 621 290 138 621 minecraft:basalt
fill 290 137 629 290 138 630 minecraft:basalt
setblock 290 137 631 minecraft:magma_block
setblock 291 137 633 minecraft:basalt
setblock 292 137 615 minecraft:basalt
fill 292 137 635 293 137 635 minecraft:basalt
fill 293 137 614 294 137 614 minecraft:basalt
setblock 293 137 636 minecraft:magma_block
fill 294 137 613 295 137 613 minecraft:basalt
fill 294 137 622 294 143 622 minecraft:basalt
fill 294 137 624 294 143 626 minecraft:basalt
fill 294 137 628 294 143 628 minecraft:basalt
fill 294 137 637 296 137 637 minecraft:basalt
fill 295 137 621 295 143 621 minecraft:basalt
fill 295 137 629 295 143 629 minecraft:basalt
fill 296 137 612 297 137 612 minecraft:basalt
setblock 296 137 620 minecraft:magma_block
fill 296 137 630 296 142 630 minecraft:basalt
setblock 296 137 638 minecraft:magma_block
fill 297 137 618 298 137 618 minecraft:basalt
fill 298 137 611 300 137 611 minecraft:basalt
fill 298 137 632 298 143 632 minecraft:basalt
setblock 298 137 639 minecraft:basalt
fill 299 137 617 299 142 617 minecraft:basalt
fill 299 137 633 299 143 633 minecraft:basalt
fill 301 137 610 305 137 610 minecraft:basalt
fill 301 137 640 305 137 640 minecraft:basalt
fill 302 137 616 304 142 616 minecraft:basalt
fill 302 137 634 304 142 634 minecraft:basalt
fill 306 137 639 308 137 639 minecraft:basalt
setblock 306 137 646 minecraft:amethyst_block
fill 307 137 617 307 143 617 minecraft:basalt
fill 307 137 633 307 143 633 minecraft:basalt
fill 307 137 646 309 158 646 minecraft:purple_concrete
fill 308 137 618 308 143 618 minecraft:basalt
fill 308 137 632 309 142 632 minecraft:basalt
fill 309 137 638 310 137 638 minecraft:basalt
setblock 310 137 620 minecraft:basalt
fill 310 137 630 310 143 630 minecraft:basalt
fill 311 137 613 312 137 613 minecraft:basalt
setblock 311 137 621 minecraft:magma_block
fill 311 137 629 311 143 629 minecraft:basalt
fill 311 137 637 312 137 637 minecraft:basalt
fill 312 137 622 312 143 622 minecraft:basalt
fill 312 137 624 312 143 626 minecraft:basalt
fill 312 137 628 312 143 628 minecraft:basalt
fill 312 137 636 313 137 636 minecraft:basalt
fill 313 137 635 313 138 635 minecraft:basalt
fill 314 137 634 315 137 634 minecraft:basalt
setblock 314 137 635 minecraft:magma_block
fill 315 137 616 315 137 617 minecraft:basalt
setblock 315 137 633 minecraft:basalt
setblock 317 137 622 minecraft:magma_block
fill 317 137 623 318 137 627 minecraft:basalt
setblock 317 137 628 minecraft:magma_block
setblock 318 137 646 minecraft:white_concrete
setblock 323 137 604 minecraft:white_concrete
fill 324 137 631 324 144 631 minecraft:purple_concrete
fill 282 138 612 282 144 612 minecraft:purple_concrete
fill 282 138 628 282 144 628 minecraft:purple_concrete
fill 282 138 644 282 144 644 minecraft:purple_concrete
setblock 285 138 607 minecraft:light[level=13]
setblock 285 138 615 minecraft:light[level=13]
setblock 285 138 623 minecraft:light[level=13]
setblock 285 138 631 minecraft:light[level=13]
setblock 285 138 639 minecraft:light[level=13]
fill 286 138 604 286 144 604 minecraft:purple_concrete
setblock 289 138 624 minecraft:magma_block
setblock 289 138 627 minecraft:magma_block
setblock 290 138 620 minecraft:basalt
setblock 292 138 616 minecraft:basalt
setblock 292 138 617 minecraft:magma_block
fill 292 138 618 292 139 618 minecraft:basalt
setblock 292 138 634 minecraft:basalt
setblock 293 138 607 minecraft:light[level=13]
setblock 293 138 635 minecraft:basalt
setblock 293 138 639 minecraft:light[level=13]
setblock 294 138 614 minecraft:basalt
setblock 295 138 622 minecraft:magma_block
fill 295 138 623 295 143 624 minecraft:basalt
setblock 295 138 625 minecraft:magma_block
fill 295 138 626 295 143 627 minecraft:basalt
setblock 295 138 628 minecraft:magma_block
fill 296 138 620 296 142 621 minecraft:basalt
fill 296 138 629 296 143 629 minecraft:basalt
setblock 296 138 637 minecraft:basalt
fill 296 138 646 296 142 646 minecraft:purple_concrete
fill 297 138 618 297 143 619 minecraft:basalt
fill 297 138 631 297 143 631 minecraft:basalt
setblock 298 138 612 minecraft:magma_block
setblock 298 138 618 minecraft:magma_block
fill 299 138 618 299 143 618 minecraft:basalt
fill 299 138 632 299 142 632 minecraft:basalt
fill 300 138 617 300 143 617 minecraft:basalt
fill 300 138 633 306 138 633 minecraft:basalt
setblock 301 138 607 minecraft:light[level=13]
setblock 301 138 611 minecraft:magma_block
setblock 301 138 617 minecraft:magma_block
setblock 301 138 623 minecraft:light[level=13]
setblock 301 138 631 minecraft:light[level=13]
fill 302 138 604 302 144 604 minecraft:purple_concrete
fill 302 138 617 306 143 617 minecraft:basalt
fill 304 138 612 306 139 612 minecraft:basalt
fill 306 138 646 306 167 646 minecraft:purple_concrete
setblock 307 138 612 minecraft:magma_block
setblock 307 138 618 minecraft:magma_block
fill 307 138 632 307 143 632 minecraft:basalt
setblock 309 138 607 minecraft:light[level=13]
fill 309 138 619 309 143 619 minecraft:basalt
setblock 309 138 623 minecraft:light[level=13]
fill 309 138 631 309 143 631 minecraft:basalt
setblock 309 138 639 minecraft:light[level=13]
setblock 310 138 620 minecraft:magma_block
fill 310 138 621 311 143 621 minecraft:basalt
setblock 310 138 629 minecraft:magma_block
setblock 310 138 646 minecraft:amethyst_block
fill 311 138 622 311 142 628 minecraft:basalt
setblock 312 138 614 minecraft:basalt
setblock 312 138 636 minecraft:basalt
fill 312 138 646 312 144 646 minecraft:purple_concrete
setblock 313 138 616 minecraft:magma_block
setblock 313 138 634 minecraft:magma_block
setblock 314 138 616 minecraft:basalt
setblock 314 138 634 minecraft:basalt
setblock 316 138 621 minecraft:magma_block
fill 316 138 622 316 139 628 minecraft:basalt
setblock 316 138 630 minecraft:magma_block
setblock 317 138 607 minecraft:light[level=13]
setblock 317 138 615 minecraft:light[level=13]
fill 317 138 623 317 138 627 minecraft:basalt
setblock 317 138 631 minecraft:light[level=13]
setblock 317 138 639 minecraft:light[level=13]
fill 318 138 604 318 144 604 minecraft:purple_concrete
fill 318 138 646 318 152 646 minecraft:purple_concrete
fill 323 138 604 323 171 604 minecraft:purple_concrete
fill 324 138 614 324 144 614 minecraft:purple_concrete
fill 324 138 630 324 143 630 minecraft:purple_concrete
setblock 291 139 619 minecraft:magma_block
setblock 291 139 631 minecraft:magma_block
setblock 294 139 616 minecraft:basalt
fill 295 139 622 296 143 622 minecraft:basalt
fill 295 139 625 295 143 625 minecraft:basalt
fill 295 139 628 296 143 628 minecraft:basalt
setblock 297 139 620 minecraft:magma_block
fill 297 139 630 297 143 630 minecraft:basalt
fill 298 139 618 298 143 619 minecraft:basalt
fill 298 139 631 298 143 631 minecraft:basalt
setblock 299 139 604 minecraft:white_concrete
fill 300 139 618 300 143 618 minecraft:basalt
fill 300 139 632 300 143 633 minecraft:basalt
fill 301 139 617 301 143 617 minecraft:basalt
fill 301 139 633 302 143 633 minecraft:basalt
setblock 302 139 646 minecraft:white_concrete
setblock 303 139 612 minecraft:magma_block
setblock 303 139 633 minecraft:magma_block
fill 303 139 638 305 139 638 minecraft:basalt
fill 303 139 646 303 175 646 minecraft:purple_concrete
fill 304 139 633 306 142 633 minecraft:basalt
fill 306 139 618 307 143 618 minecraft:basalt
setblock 306 139 632 minecraft:magma_block
setblock 306 139 638 minecraft:magma_block
fill 308 139 619 308 143 619 minecraft:basalt
fill 308 139 631 308 143 631 minecraft:basalt
setblock 309 139 613 minecraft:magma_block
fill 309 139 614 309 140 614 minecraft:basalt
fill 309 139 620 310 143 620 minecraft:basalt
fill 309 139 630 309 143 630 minecraft:basalt
fill 309 139 636 309 140 636 minecraft:basalt
setblock 309 139 637 minecraft:magma_block
fill 310 139 622 310 143 622 minecraft:basalt
fill 310 139 628 310 143 629 minecraft:basalt
fill 310 139 646 310 172 646 minecraft:purple_concrete
setblock 311 139 615 minecraft:basalt
setblock 313 139 646 minecraft:amethyst_block
fill 314 139 646 314 160 646 minecraft:purple_concrete
setblock 315 139 620 minecraft:magma_block
fill 315 139 621 315 139 622 minecraft:basalt
fill 315 139 628 315 140 628 minecraft:basalt
setblock 315 139 629 minecraft:magma_block
fill 324 139 642 324 175 642 minecraft:purple_concrete
setblock 324 139 643 minecraft:white_concrete
fill 324 139 644 324 169 644 minecraft:purple_concrete
setblock 288 140 646 minecraft:white_concrete
setblock 291 140 622 minecraft:basalt
fill 291 140 627 291 140 628 minecraft:basalt
setblock 293 140 618 minecraft:basalt
setblock 293 140 632 minecraft:magma_block
fill 296 140 623 296 142 624 minecraft:basalt
setblock 296 140 625 minecraft:magma_block
fill 296 140 626 296 142 627 minecraft:basalt
fill 297 140 620 297 143 622 minecraft:basalt
fill 297 140 628 297 143 629 minecraft:basalt
fill 298 140 620 298 143 620 minecraft:basalt
fill 298 140 630 298 143 630 minecraft:basalt
setblock 298 140 636 minecraft:basalt
fill 299 140 604 299 175 604 minecraft:purple_concrete
fill 299 140 619 300 143 619 minecraft:basalt
fill 299 140 631 300 143 631 minecraft:basalt
setblock 299 140 636 minecraft:magma_block
setblock 300 140 613 minecraft:basalt
setblock 300 140 637 minecraft:basalt
fill 301 140 618 305 142 618 minecraft:basalt
fill 301 140 632 301 143 632 minecraft:basalt
fill 302 140 613 304 140 613 minecraft:basalt
setblock 302 140 632 minecraft:magma_block
fill 302 140 637 304 140 637 minecraft:basalt
fill 302 140 646 302 175 646 minecraft:purple_concrete
fill 303 140 632 303 143 633 minecraft:basalt
fill 304 140 632 306 143 632 minecraft:basalt
setblock 304 140 646 minecraft:amethyst_block
setblock 305 140 613 minecraft:magma_block
setblock 305 140 637 minecraft:magma_block
fill 305 140 646 305 175 646 minecraft:purple_concrete
setblock 306 140 613 minecraft:basalt
fill 306 140 619 307 143 619 minecraft:basalt
fill 306 140 631 307 143 631 minecraft:basalt
setblock 306 140 637 minecraft:basalt
setblock 307 140 636 minecraft:basalt
fill 308 140 620 308 142 620 minecraft:basalt
setblock 308 140 630 minecraft:magma_block
setblock 308 140 636 minecraft:magma_block
fill 309 140 621 309 143 622 minecraft:basalt
fill 309 140 628 309 143 629 minecraft:basalt
fill 310 140 623 310 140 627 minecraft:basalt
setblock 310 140 635 minecraft:basalt
fill 313 140 646 313 175 646 minecraft:purple_concrete
setblock 314 140 619 minecraft:magma_block
fill 314 140 620 314 140 621 minecraft:basalt
fill 314 140 629 314 140 630 minecraft:basalt
setblock 314 140 631 minecraft:magma_block
setblock 315 140 622 minecraft:basalt
setblock 324 140 615 minecraft:amethyst_block
fill 324 140 643 324 147 643 minecraft:purple_concrete
fill 288 141 646 288 149 646 minecraft:purple_concrete
setblock 292 141 622 minecraft:magma_block
fill 292 141 623 292 141 624 minecraft:basalt
setblock 292 141 625 minecraft:magma_block
fill 292 141 626 292 141 627 minecraft:basalt
setblock 292 141 628 minecraft:magma_block
setblock 293 141 619 minecraft:basalt
setblock 293 141 631 minecraft:basalt
setblock 295 141 633 minecraft:magma_block
fill 296 141 625 296 143 625 minecraft:basalt
fill 297 141 623 297 143 624 minecraft:basalt
fill 297 141 626 297 143 627 minecraft:basalt
setblock 297 141 635 minecraft:basalt
fill 298 141 621 298 143 621 minecraft:basalt
setblock 298 141 629 minecraft:magma_block
setblock 298 141 635 minecraft:magma_block
fill 299 141 620 299 142 620 minecraft:basalt
fill 299 141 630 299 143 630 minecraft:basalt
setblock 301 141 619 minecraft:magma_block
setblock 301 141 631 minecraft:magma_block
fill 301 141 636 303 141 636 minecraft:basalt
fill 302 141 619 302 142 619 minecraft:basalt
fill 302 141 631 302 142 632 minecraft:basalt
fill 304 141 619 305 143 619 minecraft:basalt
fill 304 141 631 305 143 631 minecraft:basalt
setblock 304 141 636 minecraft:magma_block
fill 304 141 646 304 175 646 minecraft:purple_concrete
fill 305 141 614 306 141 614 minecraft:basalt
setblock 307 141 620 minecraft:magma_block
fill 307 141 630 308 143 630 minecraft:basalt
setblock 307 141 635 minecraft:magma_block
fill 308 141 621 308 143 621 minecraft:basalt
fill 308 141 629 308 142 629 minecraft:basalt
fill 309 141 623 310 141 624 minecraft:basalt
fill 309 141 626 310 141 627 minecraft:basalt
setblock 310 141 616 minecraft:magma_block
setblock 310 141 625 minecraft:magma_block
setblock 310 141 634 minecraft:magma_block
setblock 312 141 618 minecraft:basalt
setblock 313 141 621 minecraft:magma_block
fill 313 141 622 313 142 622 minecraft:basalt
setblock 313 141 630 minecraft:magma_block
setblock 313 141 631 minecraft:basalt
fill 324 141 615 324 175 615 minecraft:purple_concrete
setblock 294 142 620 minecraft:magma_block
fill 294 142 621 294 143 621 minecraft:basalt
setblock 297 142 625 minecraft:magma_block
fill 298 142 622 298 143 622 minecraft:basalt
fill 298 142 628 298 143 629 minecraft:basalt
setblock 299 142 615 minecraft:basalt
setblock 299 142 621 minecraft:basalt
setblock 299 142 629 minecraft:basalt
setblock 300 142 615 minecraft:magma_block
fill 300 142 620 300 143 620 minecraft:basalt
setblock 300 142 630 minecraft:magma_block
fill 300 142 635 302 142 635 minecraft:basalt
fill 301 142 619 301 143 619 minecraft:basalt
fill 301 142 631 301 143 631 minecraft:basalt
fill 303 142 619 303 143 619 minecraft:basalt
fill 303 142 631 303 143 631 minecraft:basalt
setblock 303 142 635 minecraft:magma_block
fill 305 142 635 307 142 635 minecraft:basalt
fill 306 142 620 307 143 620 minecraft:basalt
fill 306 142 630 306 143 630 minecraft:basalt
setblock 307 142 621 minecraft:basalt
setblock 307 142 629 minecraft:basalt
fill 308 142 622 308 143 622 minecraft:basalt
fill 308 142 628 308 143 628 minecraft:basalt
setblock 308 142 634 minecraft:basalt
fill 309 142 623 310 143 623 minecraft:basalt
setblock 309 142 624 minecraft:magma_block
fill 309 142 625 310 143 626 minecraft:basalt
setblock 309 142 627 minecraft:magma_block
setblock 309 142 633 minecraft:magma_block
fill 310 142 624 310 143 624 minecraft:basalt
fill 310 142 627 310 143 627 minecraft:basalt
setblock 311 142 632 minecraft:basalt
setblock 312 142 620 minecraft:magma_block
fill 312 142 621 313 142 621 minecraft:basalt
setblock 313 142 627 minecraft:basalt
setblock 282 143 631 minecraft:pearlescent_froglight
fill 282 143 632 282 158 632 minecraft:purple_concrete
setblock 294 143 629 minecraft:basalt
setblock 296 143 618 minecraft:magma_block
setblock 296 143 620 minecraft:basalt
setblock 296 143 621 minecraft:magma_block
setblock 296 143 623 minecraft:basalt
setblock 296 143 624 minecraft:magma_block
setblock 296 143 626 minecraft:basalt
setblock 296 143 627 minecraft:magma_block
setblock 296 143 630 minecraft:magma_block
setblock 296 143 632 minecraft:basalt
setblock 296 143 646 minecraft:pearlescent_froglight
setblock 297 143 625 minecraft:basalt
setblock 298 143 617 minecraft:basalt
fill 298 143 623 298 143 627 minecraft:magma_block
setblock 298 143 633 minecraft:basalt
setblock 299 143 617 minecraft:magma_block
fill 299 143 620 299 143 622 minecraft:magma_block
fill 299 143 628 299 143 629 minecraft:magma_block
setblock 299 143 632 minecraft:magma_block
setblock 299 143 634 minecraft:basalt
setblock 300 143 621 minecraft:magma_block
setblock 300 143 629 minecraft:magma_block
setblock 300 143 630 minecraft:basalt
fill 301 143 618 304 143 618 minecraft:basalt
fill 301 143 620 305 143 620 minecraft:magma_block
fill 301 143 630 305 143 630 minecraft:magma_block
setblock 302 143 616 minecraft:magma_block
setblock 302 143 619 minecraft:magma_block
setblock 302 143 631 minecraft:magma_block
setblock 302 143 632 minecraft:basalt
setblock 302 143 634 minecraft:magma_block
fill 303 143 616 304 143 616 minecraft:basalt
fill 303 143 634 304 143 634 minecraft:basalt
setblock 304 143 633 minecraft:basalt
setblock 305 143 618 minecraft:magma_block
setblock 305 143 633 minecraft:magma_block
fill 306 143 621 307 143 621 minecraft:magma_block
fill 306 143 629 308 143 629 minecraft:magma_block
setblock 306 143 633 minecraft:basalt
setblock 307 143 622 minecraft:magma_block
setblock 307 143 628 minecraft:magma_block
setblock 308 143 617 minecraft:magma_block
setblock 308 143 620 minecraft:magma_block
fill 308 143 623 308 143 627 minecraft:magma_block
setblock 308 143 632 minecraft:magma_block
setblock 309 143 624 minecraft:basalt
setblock 309 143 627 minecraft:basalt
setblock 309 143 632 minecraft:basalt
setblock 311 143 622 minecraft:magma_block
fill 311 143 623 311 143 624 minecraft:basalt
setblock 311 143 625 minecraft:magma_block
fill 311 143 626 311 143 627 minecraft:basalt
setblock 311 143 628 minecraft:magma_block
setblock 312 143 621 minecraft:basalt
setblock 312 143 623 minecraft:basalt
setblock 312 143 629 minecraft:basalt
fill 282 144 631 282 172 631 minecraft:purple_concrete
setblock 296 144 646 minecraft:purple_concrete
setblock 324 144 630 minecraft:white_concrete
setblock 282 145 610 minecraft:pearlescent_froglight
fill 282 145 612 282 146 612 minecraft:gold_block
fill 282 145 628 282 146 628 minecraft:gold_block
fill 282 145 644 282 146 644 minecraft:gold_block
fill 286 145 604 286 146 604 minecraft:gold_block
fill 296 145 646 296 146 646 minecraft:gold_block
fill 302 145 604 302 146 604 minecraft:gold_block
fill 304 145 608 305 146 609 minecraft:white_concrete
fill 312 145 646 312 146 646 minecraft:gold_block
fill 318 145 604 318 146 604 minecraft:gold_block
fill 324 145 614 324 146 614 minecraft:gold_block
setblock 324 145 628 minecraft:pearlescent_froglight
fill 324 145 630 324 146 630 minecraft:gold_block
setblock 324 145 631 minecraft:white_concrete
setblock 324 145 645 minecraft:amethyst_block
fill 282 146 610 282 175 610 minecraft:purple_concrete
setblock 285 146 607 minecraft:light[level=13]
setblock 285 146 615 minecraft:light[level=13]
setblock 285 146 623 minecraft:light[level=13]
setblock 285 146 631 minecraft:light[level=13]
setblock 285 146 639 minecraft:light[level=13]
setblock 293 146 607 minecraft:light[level=13]
setblock 293 146 615 minecraft:light[level=13]
setblock 293 146 623 minecraft:light[level=13]
setblock 293 146 631 minecraft:light[level=13]
setblock 293 146 639 minecraft:light[level=13]
setblock 301 146 607 minecraft:light[level=13]
setblock 301 146 615 minecraft:light[level=13]
setblock 301 146 623 minecraft:light[level=13]
setblock 301 146 631 minecraft:light[level=13]
setblock 301 146 639 minecraft:light[level=13]
setblock 307 146 604 minecraft:white_concrete
setblock 309 146 607 minecraft:light[level=13]
setblock 309 146 615 minecraft:light[level=13]
setblock 309 146 623 minecraft:light[level=13]
setblock 309 146 631 minecraft:light[level=13]
setblock 309 146 639 minecraft:light[level=13]
setblock 317 146 607 minecraft:light[level=13]
setblock 317 146 615 minecraft:light[level=13]
setblock 317 146 623 minecraft:light[level=13]
setblock 317 146 631 minecraft:light[level=13]
setblock 317 146 639 minecraft:light[level=13]
fill 324 146 628 324 164 628 minecraft:purple_concrete
fill 324 146 631 324 175 631 minecraft:purple_concrete
setblock 324 146 637 minecraft:white_concrete
fill 324 146 645 324 172 645 minecraft:purple_concrete
fill 282 147 612 282 153 612 minecraft:purple_concrete
fill 282 147 621 282 175 621 minecraft:purple_concrete
setblock 282 147 622 minecraft:amethyst_block
fill 282 147 623 282 175 623 minecraft:purple_concrete
fill 282 147 628 282 153 628 minecraft:purple_concrete
fill 282 147 644 282 153 644 minecraft:purple_concrete
fill 286 147 604 286 153 604 minecraft:purple_concrete
setblock 289 147 604 minecraft:amethyst_block
fill 293 147 604 293 176 604 minecraft:purple_concrete
setblock 294 147 604 minecraft:pearlescent_froglight
setblock 294 147 646 minecraft:amethyst_block
fill 296 147 646 296 153 646 minecraft:purple_concrete
fill 302 147 604 302 153 604 minecraft:purple_concrete
fill 307 147 604 307 175 604 minecraft:purple_concrete
fill 312 147 646 312 153 646 minecraft:purple_concrete
fill 318 147 604 318 153 604 minecraft:purple_concrete
fill 320 147 646 320 175 646 minecraft:purple_concrete
setblock 321 147 646 minecraft:pearlescent_froglight
fill 324 147 614 324 153 614 minecraft:purple_concrete
fill 324 147 630 324 150 630 minecraft:purple_concrete
setblock 324 147 634 minecraft:pearlescent_froglight
fill 324 147 637 324 170 637 minecraft:purple_concrete
fill 282 148 622 282 175 622 minecraft:purple_concrete
fill 289 148 604 289 175 604 minecraft:purple_concrete
fill 292 148 643 294 151 645 minecraft:amethyst_block
fill 293 148 642 293 151 642 minecraft:amethyst_block
fill 294 148 604 294 155 604 minecraft:purple_concrete
fill 294 148 646 294 158 646 minecraft:purple_concrete
setblock 295 148 646 minecraft:white_concrete
setblock 301 148 646 minecraft:pearlescent_froglight
fill 311 148 616 312 149 617 minecraft:end_stone
fill 321 148 646 321 158 646 minecraft:purple_concrete
fill 324 148 634 324 176 634 minecraft:purple_concrete
setblock 324 148 643 minecraft:pearlescent_froglight
fill 291 149 643 291 150 645 minecraft:amethyst_block
fill 292 149 641 292 150 642 minecraft:amethyst_block
fill 293 149 639 293 150 641 minecraft:amethyst_block
fill 294 149 641 294 150 642 minecraft:amethyst_block
fill 295 149 643 295 150 645 minecraft:amethyst_block
fill 295 149 646 295 172 646 minecraft:purple_concrete
fill 301 149 646 301 175 646 minecraft:purple_concrete
setblock 324 149 639 minecraft:white_concrete
fill 324 149 640 324 175 640 minecraft:purple_concrete
fill 324 149 643 324 156 643 minecraft:purple_concrete
setblock 282 150 618 minecraft:white_concrete
setblock 282 150 620 minecraft:pearlescent_froglight
setblock 288 150 646 minecraft:amethyst_block
fill 314 150 625 314 151 626 minecraft:amethyst_block
fill 315 150 626 315 151 626 minecraft:amethyst_block
setblock 324 150 619 minecraft:pearlescent_froglight
fill 324 150 620 324 164 621 minecraft:purple_concrete
fill 324 150 639 324 151 639 minecraft:purple_concrete
fill 282 151 618 282 156 618 minecraft:purple_concrete
fill 282 151 620 282 175 620 minecraft:purple_concrete
setblock 282 151 625 minecraft:amethyst_block
fill 287 151 604 287 173 604 minecraft:purple_concrete
setblock 288 151 604 minecraft:white_concrete
fill 288 151 646 288 175 646 minecraft:purple_concrete
fill 293 151 620 294 152 622 minecraft:gold_block
fill 324 151 619 324 173 619 minecraft:purple_concrete
setblock 324 151 630 minecraft:white_concrete
setblock 282 152 616 minecraft:white_concrete
fill 282 152 617 282 175 617 minecraft:purple_concrete
fill 282 152 625 282 176 625 minecraft:purple_concrete
fill 288 152 604 288 173 604 minecraft:purple_concrete
fill 309 152 619 309 153 620 minecraft:white_concrete
fill 324 152 630 324 153 630 minecraft:purple_concrete
setblock 324 152 639 minecraft:white_concrete
fill 282 153 616 282 175 616 minecraft:purple_concrete
fill 305 153 635 306 154 636 minecraft:gold_block
setblock 318 153 646 minecraft:amethyst_block
setblock 324 153 639 minecraft:pearlescent_froglight
fill 282 154 612 282 155 612 minecraft:gold_block
fill 282 154 628 282 155 628 minecraft:gold_block
fill 282 154 644 282 155 644 minecraft:gold_block
setblock 285 154 607 minecraft:light[level=13]
setblock 285 154 615 minecraft:light[level=13]
setblock 285 154 623 minecraft:light[level=13]
setblock 285 154 631 minecraft:light[level=13]
setblock 285 154 639 minecraft:light[level=13]
fill 286 154 604 286 155 604 minecraft:gold_block
setblock 293 154 607 minecraft:light[level=13]
setblock 293 154 615 minecraft:light[level=13]
setblock 293 154 623 minecraft:light[level=13]
setblock 293 154 631 minecraft:light[level=13]
setblock 293 154 639 minecraft:light[level=13]
fill 296 154 646 296 155 646 minecraft:gold_block
setblock 301 154 607 minecraft:light[level=13]
setblock 301 154 615 minecraft:light[level=13]
setblock 301 154 623 minecraft:light[level=13]
setblock 301 154 631 minecraft:light[level=13]
setblock 301 154 639 minecraft:light[level=13]
fill 302 154 604 302 155 604 minecraft:gold_block
setblock 309 154 607 minecraft:light[level=13]
setblock 309 154 615 minecraft:light[level=13]
setblock 309 154 623 minecraft:light[level=13]
setblock 309 154 631 minecraft:light[level=13]
setblock 309 154 639 minecraft:light[level=13]
fill 312 154 646 312 155 646 minecraft:gold_block
setblock 317 154 607 minecraft:light[level=13]
setblock 317 154 615 minecraft:light[level=13]
setblock 317 154 623 minecraft:light[level=13]
setblock 317 154 631 minecraft:light[level=13]
setblock 317 154 639 minecraft:light[level=13]
fill 318 154 604 318 155 604 minecraft:gold_block
fill 318 154 646 318 172 646 minecraft:purple_concrete
setblock 324 154 606 minecraft:white_concrete
fill 324 154 607 324 171 611 minecraft:purple_concrete
fill 324 154 614 324 155 614 minecraft:gold_block
fill 324 154 630 324 155 630 minecraft:gold_block
fill 324 154 639 324 175 639 minecraft:purple_concrete
setblock 282 155 607 minecraft:amethyst_block
setblock 292 155 646 minecraft:amethyst_block
setblock 319 155 646 minecraft:pearlescent_froglight
fill 324 155 606 324 175 606 minecraft:purple_concrete
fill 282 156 607 282 175 607 minecraft:purple_concrete
fill 282 156 612 282 161 612 minecraft:purple_concrete
fill 282 156 628 282 161 628 minecraft:purple_concrete
setblock 282 156 635 minecraft:amethyst_block
fill 282 156 644 282 161 644 minecraft:purple_concrete
fill 286 156 604 286 161 604 minecraft:purple_concrete
fill 292 156 646 292 163 646 minecraft:purple_concrete
setblock 294 156 604 minecraft:white_concrete
fill 296 156 646 296 161 646 minecraft:purple_concrete
fill 302 156 604 302 161 604 minecraft:purple_concrete
fill 312 156 646 312 161 646 minecraft:purple_concrete
fill 318 156 604 318 161 604 minecraft:purple_concrete
fill 319 156 646 319 165 646 minecraft:purple_concrete
fill 324 156 614 324 161 614 minecraft:purple_concrete
fill 324 156 630 324 161 630 minecraft:purple_concrete
setblock 282 157 618 minecraft:pearlescent_froglight
fill 282 157 635 282 175 635 minecraft:purple_concrete
fill 294 157 604 294 175 604 minecraft:purple_concrete
fill 304 157 637 304 158 637 minecraft:amethyst_block
setblock 306 157 604 minecraft:white_concrete
fill 323 157 646 323 158 646 minecraft:amethyst_block
setblock 324 157 605 minecraft:white_concrete
setblock 324 157 612 minecraft:amethyst_block
setblock 324 157 638 minecraft:pearlescent_froglight
setblock 324 157 643 minecraft:amethyst_block
fill 282 158 618 282 172 618 minecraft:purple_concrete
setblock 295 158 604 minecraft:amethyst_block
fill 295 158 621 296 159 621 minecraft:end_stone
fill 306 158 604 306 175 604 minecraft:purple_concrete
fill 318 158 625 319 159 625 minecraft:amethyst_block
fill 320 158 604 320 167 604 minecraft:purple_concrete
setblock 321 158 604 minecraft:white_concrete
fill 324 158 605 324 164 605 minecraft:purple_concrete
fill 324 158 612 324 160 612 minecraft:purple_concrete
fill 324 158 638 324 175 638 minecraft:purple_concrete
fill 324 158 643 324 176 643 minecraft:purple_concrete
setblock 282 159 632 minecraft:pearlescent_froglight
fill 282 159 636 282 174 636 minecraft:purple_concrete
setblock 282 159 637 minecraft:white_concrete
fill 282 159 638 282 171 640 minecraft:purple_concrete
setblock 294 159 646 minecraft:pearlescent_froglight
fill 295 159 604 295 172 604 minecraft:purple_concrete
setblock 300 159 646 minecraft:white_concrete
fill 304 159 637 304 167 637 minecraft:black_concrete
fill 307 159 646 308 171 646 minecraft:purple_concrete
setblock 309 159 646 minecraft:amethyst_block
fill 319 159 624 323 159 624 minecraft:amethyst_block
fill 319 159 626 323 159 626 minecraft:amethyst_block
fill 320 159 625 323 161 625 minecraft:amethyst_block
fill 321 159 604 321 175 604 minecraft:purple_concrete
setblock 321 159 646 minecraft:amethyst_block
fill 323 159 646 323 177 646 minecraft:purple_concrete
setblock 324 159 635 minecraft:amethyst_block
fill 282 160 632 282 175 632 minecraft:purple_concrete
fill 282 160 637 282 175 637 minecraft:purple_concrete
fill 294 160 646 294 171 646 minecraft:purple_concrete
fill 300 160 646 300 175 646 minecraft:purple_concrete
fill 304 160 636 304 167 636 minecraft:black_concrete
fill 309 160 646 309 175 646 minecraft:purple_concrete
setblock 314 160 604 minecraft:pearlescent_froglight
setblock 319 160 625 minecraft:amethyst_block
fill 320 160 624 323 160 624 minecraft:amethyst_block
fill 320 160 626 323 160 626 minecraft:amethyst_block
fill 321 160 646 321 173 646 minecraft:purple_concrete
fill 322 160 623 322 161 623 minecraft:amethyst_block
fill 322 160 627 322 161 627 minecraft:amethyst_block
fill 324 160 635 324 175 635 minecraft:purple_concrete
fill 282 161 613 282 174 613 minecraft:purple_concrete
setblock 282 161 614 minecraft:white_concrete
setblock 298 161 646 minecraft:white_concrete
fill 303 161 636 303 167 637 minecraft:black_concrete
fill 304 161 638 304 167 638 minecraft:black_concrete
fill 305 161 636 305 167 637 minecraft:black_concrete
fill 314 161 604 314 173 604 minecraft:purple_concrete
setblock 314 161 646 minecraft:white_concrete
fill 321 161 624 323 162 624 minecraft:amethyst_block
fill 321 161 626 323 162 626 minecraft:amethyst_block
setblock 324 161 612 minecraft:amethyst_block
setblock 324 161 623 minecraft:pearlescent_froglight
fill 282 162 612 282 164 612 minecraft:gold_block
fill 282 162 614 282 175 614 minecraft:purple_concrete
fill 282 162 628 282 164 628 minecraft:gold_block
fill 282 162 644 282 164 644 minecraft:gold_block
setblock 285 162 607 minecraft:light[level=13]
setblock 285 162 615 minecraft:light[level=13]
setblock 285 162 623 minecraft:light[level=13]
setblock 285 162 631 minecraft:light[level=13]
setblock 285 162 639 minecraft:light[level=13]
fill 286 162 604 286 164 604 minecraft:gold_block
setblock 289 162 646 minecraft:amethyst_block
setblock 293 162 607 minecraft:light[level=13]
setblock 293 162 615 minecraft:light[level=13]
setblock 293 162 623 minecraft:light[level=13]
setblock 293 162 631 minecraft:light[level=13]
setblock 293 162 639 minecraft:light[level=13]
fill 296 162 646 296 164 646 minecraft:gold_block
fill 298 162 646 298 175 646 minecraft:purple_concrete
setblock 301 162 607 minecraft:light[level=13]
setblock 301 162 615 minecraft:light[level=13]
setblock 301 162 623 minecraft:light[level=13]
setblock 301 162 631 minecraft:light[level=13]
setblock 301 162 639 minecraft:light[level=13]
fill 302 162 604 302 164 604 minecraft:gold_block
fill 303 162 638 303 167 638 minecraft:black_concrete
fill 304 162 635 304 167 635 minecraft:black_concrete
fill 305 162 638 305 167 638 minecraft:black_concrete
setblock 309 162 607 minecraft:light[level=13]
setblock 309 162 615 minecraft:light[level=13]
setblock 309 162 623 minecraft:light[level=13]
setblock 309 162 631 minecraft:light[level=13]
setblock 309 162 639 minecraft:light[level=13]
fill 312 162 646 312 164 646 minecraft:gold_block
fill 314 162 646 314 175 646 minecraft:purple_concrete
setblock 315 162 604 minecraft:pearlescent_froglight
setblock 317 162 607 minecraft:light[level=13]
setblock 317 162 615 minecraft:light[level=13]
setblock 317 162 623 minecraft:light[level=13]
setblock 317 162 631 minecraft:light[level=13]
setblock 317 162 639 minecraft:light[level=13]
fill 318 162 604 318 164 604 minecraft:gold_block
fill 321 162 625 323 162 625 minecraft:amethyst_block
setblock 324 162 612 minecraft:purple_concrete
fill 324 162 614 324 164 614 minecraft:gold_block
fill 324 162 623 324 175 623 minecraft:purple_concrete
fill 324 162 630 324 164 630 minecraft:gold_block
setblock 282 163 611 minecraft:amethyst_block
setblock 282 163 630 minecraft:white_concrete
setblock 285 163 604 minecraft:white_concrete
schedule function dropper:buildpart/150_2 1t
