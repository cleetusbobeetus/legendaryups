setblock 84 253 323 minecraft:stripped_dark_oak_log
setblock 84 253 363 minecraft:stripped_dark_oak_log
fill 85 253 333 86 255 333 minecraft:stripped_dark_oak_log
fill 86 253 332 86 254 332 minecraft:stripped_dark_oak_log
fill 86 253 334 86 254 334 minecraft:stripped_dark_oak_log
setblock 88 253 326 minecraft:stripped_dark_oak_log
setblock 88 253 340 minecraft:stripped_dark_oak_log
setblock 88 253 347 minecraft:stripped_dark_oak_log
setblock 88 253 354 minecraft:stripped_dark_oak_log
setblock 88 253 361 minecraft:stripped_dark_oak_log
setblock 48 254 323 minecraft:stripped_dark_oak_log
setblock 48 254 330 minecraft:stripped_dark_oak_log
fill 48 254 333 48 255 333 minecraft:stripped_dark_oak_log
fill 48 254 335 48 255 335 minecraft:stripped_dark_oak_log
fill 48 254 337 48 255 337 minecraft:stripped_dark_oak_log
fill 48 254 339 48 255 339 minecraft:stripped_dark_oak_log
fill 48 254 341 48 255 341 minecraft:stripped_dark_oak_log
setblock 48 254 344 minecraft:stripped_dark_oak_log
setblock 48 254 351 minecraft:stripped_dark_oak_log
setblock 48 254 358 minecraft:stripped_dark_oak_log
fill 49 254 332 50 254 332 minecraft:stripped_dark_oak_log
fill 49 254 334 49 255 334 minecraft:stripped_dark_oak_log
fill 49 254 336 49 255 336 minecraft:stripped_dark_oak_log
fill 49 254 338 49 255 338 minecraft:stripped_dark_oak_log
fill 49 254 340 49 255 340 minecraft:stripped_dark_oak_log
fill 50 254 333 50 255 333 minecraft:stripped_dark_oak_log
fill 50 254 335 50 255 335 minecraft:stripped_dark_oak_log
fill 50 254 337 50 255 337 minecraft:stripped_dark_oak_log
fill 50 254 339 50 255 339 minecraft:stripped_dark_oak_log
fill 50 254 341 50 255 341 minecraft:stripped_dark_oak_log
setblock 50 254 363 minecraft:stripped_dark_oak_log
fill 51 254 322 51 308 322 minecraft:dark_oak_planks
fill 51 254 334 51 255 334 minecraft:stripped_dark_oak_log
fill 51 254 336 51 255 336 minecraft:stripped_dark_oak_log
fill 51 254 338 51 255 338 minecraft:stripped_dark_oak_log
fill 51 254 340 51 255 340 minecraft:stripped_dark_oak_log
fill 52 254 333 52 255 333 minecraft:stripped_dark_oak_log
fill 52 254 335 52 255 335 minecraft:stripped_dark_oak_log
fill 52 254 337 52 255 337 minecraft:stripped_dark_oak_log
fill 52 254 339 52 255 339 minecraft:stripped_dark_oak_log
fill 52 254 341 52 255 341 minecraft:stripped_dark_oak_log
fill 53 254 334 53 255 334 minecraft:stripped_dark_oak_log
fill 53 254 336 53 255 336 minecraft:stripped_dark_oak_log
fill 53 254 338 53 255 338 minecraft:stripped_dark_oak_log
fill 53 254 340 53 255 340 minecraft:stripped_dark_oak_log
fill 54 254 337 54 257 337 minecraft:dark_oak_planks
fill 54 254 340 54 257 340 minecraft:dark_oak_planks
setblock 55 254 323 minecraft:stripped_dark_oak_log
fill 55 254 338 55 257 339 minecraft:dark_oak_planks
fill 57 254 347 57 257 347 minecraft:stripped_dark_oak_log
setblock 57 254 363 minecraft:stripped_dark_oak_log
fill 58 254 364 58 258 364 minecraft:dark_oak_planks
setblock 59 254 364 minecraft:red_concrete
setblock 62 254 323 minecraft:stripped_dark_oak_log
setblock 64 254 363 minecraft:stripped_dark_oak_log
fill 67 254 322 67 308 322 minecraft:dark_oak_planks
setblock 69 254 323 minecraft:stripped_dark_oak_log
setblock 71 254 363 minecraft:stripped_dark_oak_log
setblock 76 254 323 minecraft:stripped_dark_oak_log
setblock 78 254 363 minecraft:stripped_dark_oak_log
setblock 83 254 323 minecraft:stripped_dark_oak_log
fill 84 254 333 84 256 333 minecraft:stripped_dark_oak_log
fill 85 254 332 85 255 332 minecraft:stripped_dark_oak_log
fill 85 254 334 85 255 334 minecraft:stripped_dark_oak_log
setblock 85 254 363 minecraft:stripped_dark_oak_log
setblock 87 254 333 minecraft:stripped_dark_oak_log
setblock 88 254 325 minecraft:stripped_dark_oak_log
setblock 88 254 332 minecraft:stripped_dark_oak_log
setblock 88 254 333 minecraft:red_concrete
setblock 88 254 339 minecraft:stripped_dark_oak_log
setblock 88 254 346 minecraft:stripped_dark_oak_log
setblock 88 254 353 minecraft:stripped_dark_oak_log
setblock 88 254 360 minecraft:stripped_dark_oak_log
fill 47 255 350 47 308 350 minecraft:dark_oak_planks
setblock 47 255 351 minecraft:red_concrete
setblock 48 255 324 minecraft:stripped_dark_oak_log
setblock 48 255 331 minecraft:stripped_dark_oak_log
setblock 48 255 345 minecraft:stripped_dark_oak_log
setblock 48 255 352 minecraft:stripped_dark_oak_log
fill 48 255 353 50 255 353 minecraft:iron_bars
setblock 48 255 359 minecraft:stripped_dark_oak_log
fill 50 255 332 51 255 332 minecraft:stripped_dark_oak_log
setblock 51 255 363 minecraft:stripped_dark_oak_log
setblock 54 255 323 minecraft:stripped_dark_oak_log
fill 55 255 337 55 257 337 minecraft:dark_oak_planks
fill 55 255 340 55 257 340 minecraft:dark_oak_planks
setblock 58 255 363 minecraft:stripped_dark_oak_log
fill 59 255 364 59 308 364 minecraft:dark_oak_planks
setblock 61 255 323 minecraft:stripped_dark_oak_log
setblock 65 255 363 minecraft:stripped_dark_oak_log
setblock 68 255 323 minecraft:stripped_dark_oak_log
setblock 72 255 363 minecraft:stripped_dark_oak_log
setblock 75 255 323 minecraft:stripped_dark_oak_log
setblock 79 255 363 minecraft:stripped_dark_oak_log
setblock 82 255 323 minecraft:stripped_dark_oak_log
fill 83 255 333 83 257 333 minecraft:stripped_dark_oak_log
setblock 83 255 361 minecraft:red_concrete
fill 84 255 332 84 256 332 minecraft:stripped_dark_oak_log
fill 84 255 334 84 256 334 minecraft:stripped_dark_oak_log
setblock 86 255 363 minecraft:stripped_dark_oak_log
setblock 87 255 333 minecraft:red_concrete
setblock 88 255 324 minecraft:stripped_dark_oak_log
setblock 88 255 331 minecraft:stripped_dark_oak_log
setblock 88 255 338 minecraft:stripped_dark_oak_log
setblock 88 255 345 minecraft:stripped_dark_oak_log
setblock 88 255 352 minecraft:stripped_dark_oak_log
setblock 88 255 359 minecraft:stripped_dark_oak_log
fill 89 255 327 89 308 327 minecraft:dark_oak_planks
setblock 89 255 328 minecraft:red_concrete
fill 89 255 329 89 308 332 minecraft:dark_oak_planks
fill 47 256 351 47 308 351 minecraft:dark_oak_planks
setblock 48 256 325 minecraft:stripped_dark_oak_log
setblock 48 256 332 minecraft:stripped_dark_oak_log
setblock 48 256 333 minecraft:shroomlight
setblock 48 256 335 minecraft:shroomlight
setblock 48 256 337 minecraft:shroomlight
setblock 48 256 339 minecraft:shroomlight
setblock 48 256 341 minecraft:shroomlight
setblock 48 256 346 minecraft:stripped_dark_oak_log
setblock 48 256 353 minecraft:stripped_dark_oak_log
setblock 48 256 360 minecraft:stripped_dark_oak_log
setblock 49 256 334 minecraft:shroomlight
setblock 49 256 336 minecraft:shroomlight
setblock 49 256 338 minecraft:shroomlight
setblock 49 256 340 minecraft:shroomlight
fill 49 256 353 50 256 353 minecraft:iron_bars
fill 49 256 356 50 257 356 minecraft:iron_bars
setblock 50 256 333 minecraft:shroomlight
setblock 50 256 335 minecraft:shroomlight
setblock 50 256 337 minecraft:shroomlight
setblock 50 256 339 minecraft:shroomlight
setblock 50 256 341 minecraft:shroomlight
fill 50 256 358 50 256 361 minecraft:dark_oak_planks
fill 51 256 332 53 256 332 minecraft:stripped_dark_oak_log
setblock 51 256 334 minecraft:shroomlight
setblock 51 256 336 minecraft:shroomlight
setblock 51 256 338 minecraft:shroomlight
setblock 51 256 340 minecraft:shroomlight
fill 51 256 357 52 256 357 minecraft:dark_oak_planks
setblock 51 256 361 minecraft:dark_oak_planks
setblock 52 256 333 minecraft:shroomlight
setblock 52 256 335 minecraft:shroomlight
setblock 52 256 337 minecraft:shroomlight
setblock 52 256 339 minecraft:shroomlight
setblock 52 256 341 minecraft:shroomlight
setblock 52 256 363 minecraft:stripped_dark_oak_log
setblock 53 256 323 minecraft:stripped_dark_oak_log
setblock 53 256 334 minecraft:shroomlight
setblock 53 256 336 minecraft:shroomlight
setblock 53 256 338 minecraft:shroomlight
setblock 53 256 340 minecraft:shroomlight
fill 53 256 358 54 256 358 minecraft:dark_oak_planks
setblock 53 256 361 minecraft:dark_oak_planks
fill 54 256 333 54 258 333 minecraft:stripped_dark_oak_log
fill 54 256 341 54 257 341 minecraft:dark_oak_planks
fill 54 256 359 54 256 360 minecraft:dark_oak_planks
fill 56 256 338 56 257 339 minecraft:dark_oak_planks
setblock 59 256 363 minecraft:stripped_dark_oak_log
setblock 60 256 323 minecraft:stripped_dark_oak_log
setblock 66 256 363 minecraft:stripped_dark_oak_log
setblock 67 256 323 minecraft:stripped_dark_oak_log
fill 71 256 330 73 258 330 minecraft:cherry_leaves[persistent=true]
fill 72 256 328 73 258 329 minecraft:cherry_leaves[persistent=true]
setblock 73 256 363 minecraft:stripped_dark_oak_log
setblock 74 256 323 minecraft:stripped_dark_oak_log
fill 74 256 328 74 259 328 minecraft:cherry_leaves[persistent=true]
setblock 80 256 363 minecraft:stripped_dark_oak_log
setblock 81 256 323 minecraft:stripped_dark_oak_log
fill 81 256 333 82 258 333 minecraft:stripped_dark_oak_log
fill 82 256 327 82 256 328 minecraft:dark_oak_planks
fill 82 256 332 83 256 332 minecraft:stripped_dark_oak_log
fill 82 256 334 83 256 334 minecraft:stripped_dark_oak_log
setblock 83 256 326 minecraft:dark_oak_planks
setblock 83 256 329 minecraft:dark_oak_planks
fill 84 256 325 85 256 325 minecraft:dark_oak_planks
fill 84 256 330 85 256 330 minecraft:dark_oak_planks
setblock 85 256 333 minecraft:stripped_dark_oak_log
setblock 86 256 326 minecraft:dark_oak_planks
setblock 86 256 329 minecraft:dark_oak_planks
setblock 86 256 333 minecraft:red_concrete
setblock 87 256 363 minecraft:stripped_dark_oak_log
setblock 88 256 323 minecraft:stripped_dark_oak_log
setblock 88 256 330 minecraft:stripped_dark_oak_log
setblock 88 256 337 minecraft:stripped_dark_oak_log
setblock 88 256 344 minecraft:stripped_dark_oak_log
setblock 88 256 351 minecraft:stripped_dark_oak_log
setblock 88 256 358 minecraft:stripped_dark_oak_log
fill 89 256 328 89 308 328 minecraft:dark_oak_planks
setblock 48 257 326 minecraft:stripped_dark_oak_log
fill 48 257 333 48 258 333 minecraft:stripped_dark_oak_log
fill 48 257 335 48 258 335 minecraft:stripped_dark_oak_log
fill 48 257 337 48 258 337 minecraft:stripped_dark_oak_log
fill 48 257 339 48 258 339 minecraft:stripped_dark_oak_log
fill 48 257 341 48 258 341 minecraft:stripped_dark_oak_log
setblock 48 257 347 minecraft:stripped_dark_oak_log
setblock 48 257 354 minecraft:stripped_dark_oak_log
setblock 48 257 361 minecraft:stripped_dark_oak_log
fill 49 257 334 49 258 334 minecraft:stripped_dark_oak_log
fill 49 257 336 49 258 336 minecraft:stripped_dark_oak_log
fill 49 257 338 49 258 338 minecraft:stripped_dark_oak_log
fill 49 257 340 49 258 340 minecraft:stripped_dark_oak_log
fill 50 257 333 50 258 333 minecraft:stripped_dark_oak_log
fill 50 257 335 50 258 335 minecraft:stripped_dark_oak_log
fill 50 257 337 50 258 337 minecraft:stripped_dark_oak_log
fill 50 257 339 50 258 339 minecraft:stripped_dark_oak_log
fill 50 257 341 50 258 341 minecraft:stripped_dark_oak_log
fill 51 257 334 51 258 334 minecraft:stripped_dark_oak_log
fill 51 257 336 51 258 336 minecraft:stripped_dark_oak_log
fill 51 257 338 51 258 338 minecraft:stripped_dark_oak_log
fill 51 257 340 51 258 340 minecraft:stripped_dark_oak_log
setblock 52 257 323 minecraft:stripped_dark_oak_log
fill 52 257 333 52 258 333 minecraft:stripped_dark_oak_log
fill 52 257 335 52 258 335 minecraft:stripped_dark_oak_log
fill 52 257 337 52 258 337 minecraft:stripped_dark_oak_log
fill 52 257 339 52 258 339 minecraft:stripped_dark_oak_log
fill 52 257 341 52 258 341 minecraft:stripped_dark_oak_log
fill 53 257 332 54 257 332 minecraft:stripped_dark_oak_log
fill 53 257 334 54 258 334 minecraft:stripped_dark_oak_log
fill 53 257 336 53 258 336 minecraft:stripped_dark_oak_log
fill 53 257 338 53 258 338 minecraft:stripped_dark_oak_log
fill 53 257 340 53 258 340 minecraft:stripped_dark_oak_log
setblock 53 257 363 minecraft:stripped_dark_oak_log
fill 54 257 336 55 257 336 minecraft:dark_oak_planks
fill 55 257 333 55 259 333 minecraft:stripped_dark_oak_log
setblock 55 257 341 minecraft:dark_oak_planks
setblock 56 257 337 minecraft:dark_oak_planks
setblock 56 257 340 minecraft:dark_oak_planks
fill 56 257 346 56 259 348 minecraft:cherry_leaves[persistent=true]
fill 57 257 346 58 259 346 minecraft:cherry_leaves[persistent=true]
fill 57 257 348 57 259 349 minecraft:cherry_leaves[persistent=true]
fill 57 257 359 57 260 359 minecraft:iron_bars
fill 58 257 347 58 259 348 minecraft:cherry_leaves[persistent=true]
setblock 59 257 323 minecraft:stripped_dark_oak_log
fill 59 257 347 59 259 347 minecraft:cherry_leaves[persistent=true]
setblock 60 257 363 minecraft:stripped_dark_oak_log
setblock 66 257 323 minecraft:stripped_dark_oak_log
setblock 67 257 363 minecraft:stripped_dark_oak_log
fill 71 257 329 71 258 329 minecraft:cherry_leaves[persistent=true]
fill 72 257 327 73 257 327 minecraft:cherry_leaves[persistent=true]
fill 72 257 331 73 258 331 minecraft:cherry_leaves[persistent=true]
setblock 73 257 323 minecraft:stripped_dark_oak_log
fill 74 257 329 74 259 330 minecraft:cherry_leaves[persistent=true]
setblock 74 257 363 minecraft:stripped_dark_oak_log
setblock 80 257 323 minecraft:stripped_dark_oak_log
fill 80 257 333 80 259 333 minecraft:stripped_dark_oak_log
fill 81 257 332 82 257 332 minecraft:stripped_dark_oak_log
fill 81 257 334 82 257 334 minecraft:stripped_dark_oak_log
setblock 81 257 363 minecraft:stripped_dark_oak_log
setblock 84 257 333 minecraft:red_concrete
setblock 87 257 323 minecraft:stripped_dark_oak_log
setblock 88 257 329 minecraft:stripped_dark_oak_log
setblock 88 257 336 minecraft:stripped_dark_oak_log
setblock 88 257 343 minecraft:stripped_dark_oak_log
setblock 88 257 350 minecraft:stripped_dark_oak_log
setblock 88 257 357 minecraft:stripped_dark_oak_log
setblock 88 257 363 minecraft:stripped_dark_oak_log
fill 89 257 337 89 308 338 minecraft:dark_oak_planks
setblock 89 257 339 minecraft:red_concrete
fill 89 257 340 89 308 341 minecraft:dark_oak_planks
setblock 48 258 327 minecraft:stripped_dark_oak_log
setblock 48 258 348 minecraft:stripped_dark_oak_log
setblock 48 258 355 minecraft:stripped_dark_oak_log
setblock 48 258 362 minecraft:stripped_dark_oak_log
setblock 50 258 325 minecraft:light[level=15]
setblock 50 258 332 minecraft:light[level=12]
setblock 50 258 346 minecraft:light[level=12]
setblock 50 258 349 minecraft:light[level=15]
setblock 50 258 353 minecraft:light[level=12]
setblock 50 258 357 minecraft:light[level=15]
setblock 50 258 360 minecraft:light[level=12]
setblock 51 258 323 minecraft:stripped_dark_oak_log
fill 54 258 332 56 258 332 minecraft:stripped_dark_oak_log
fill 54 258 339 54 260 339 minecraft:stripped_dark_oak_log
setblock 54 258 363 minecraft:stripped_dark_oak_log
fill 55 258 334 56 258 334 minecraft:stripped_dark_oak_log
fill 55 258 346 55 258 348 minecraft:cherry_leaves[persistent=true]
fill 56 258 333 57 259 333 minecraft:stripped_dark_oak_log
fill 56 258 345 58 258 345 minecraft:cherry_leaves[persistent=true]
setblock 56 258 349 minecraft:cherry_leaves[persistent=true]
setblock 57 258 325 minecraft:light[level=12]
setblock 57 258 332 minecraft:light[level=12]
setblock 57 258 339 minecraft:light[level=12]
fill 57 258 347 57 259 347 minecraft:cherry_leaves[persistent=true]
setblock 57 258 353 minecraft:light[level=12]
setblock 57 258 360 minecraft:light[level=12]
setblock 58 258 323 minecraft:stripped_dark_oak_log
setblock 58 258 325 minecraft:light[level=15]
setblock 58 258 333 minecraft:light[level=15]
setblock 58 258 341 minecraft:light[level=15]
setblock 58 258 349 minecraft:cherry_leaves[persistent=true]
setblock 58 258 357 minecraft:light[level=15]
setblock 59 258 346 minecraft:cherry_leaves[persistent=true]
setblock 59 258 348 minecraft:cherry_leaves[persistent=true]
setblock 61 258 363 minecraft:stripped_dark_oak_log
setblock 64 258 325 minecraft:light[level=12]
setblock 64 258 332 minecraft:light[level=12]
setblock 64 258 339 minecraft:light[level=12]
setblock 64 258 346 minecraft:light[level=12]
setblock 64 258 353 minecraft:light[level=12]
setblock 64 258 360 minecraft:light[level=12]
setblock 65 258 323 minecraft:stripped_dark_oak_log
setblock 66 258 325 minecraft:light[level=15]
setblock 66 258 333 minecraft:light[level=15]
setblock 66 258 341 minecraft:light[level=15]
setblock 66 258 349 minecraft:light[level=15]
setblock 66 258 357 minecraft:light[level=15]
setblock 68 258 363 minecraft:stripped_dark_oak_log
setblock 71 258 325 minecraft:light[level=12]
setblock 71 258 332 minecraft:light[level=12]
setblock 71 258 339 minecraft:light[level=12]
setblock 71 258 346 minecraft:light[level=12]
setblock 71 258 353 minecraft:light[level=12]
setblock 71 258 360 minecraft:light[level=12]
setblock 72 258 323 minecraft:stripped_dark_oak_log
setblock 74 258 325 minecraft:light[level=15]
setblock 74 258 333 minecraft:light[level=15]
setblock 74 258 341 minecraft:light[level=15]
setblock 74 258 349 minecraft:light[level=15]
setblock 74 258 357 minecraft:light[level=15]
fill 75 258 329 75 258 330 minecraft:cherry_leaves[persistent=true]
setblock 75 258 363 minecraft:stripped_dark_oak_log
setblock 78 258 325 minecraft:light[level=12]
setblock 78 258 332 minecraft:light[level=12]
fill 78 258 333 79 260 333 minecraft:stripped_dark_oak_log
setblock 78 258 339 minecraft:light[level=12]
setblock 78 258 346 minecraft:light[level=12]
setblock 78 258 353 minecraft:light[level=12]
setblock 78 258 360 minecraft:light[level=12]
setblock 79 258 323 minecraft:stripped_dark_oak_log
fill 79 258 332 81 258 332 minecraft:stripped_dark_oak_log
fill 79 258 334 81 258 334 minecraft:stripped_dark_oak_log
setblock 80 258 364 minecraft:red_concrete
setblock 82 258 325 minecraft:light[level=15]
setblock 82 258 341 minecraft:light[level=15]
setblock 82 258 349 minecraft:light[level=15]
setblock 82 258 357 minecraft:light[level=15]
setblock 82 258 363 minecraft:stripped_dark_oak_log
setblock 83 258 333 minecraft:red_concrete
setblock 85 258 325 minecraft:light[level=12]
setblock 85 258 332 minecraft:light[level=12]
setblock 85 258 339 minecraft:light[level=12]
setblock 85 258 346 minecraft:light[level=12]
setblock 85 258 353 minecraft:light[level=12]
setblock 85 258 360 minecraft:light[level=12]
setblock 86 258 323 minecraft:stripped_dark_oak_log
setblock 88 258 328 minecraft:stripped_dark_oak_log
setblock 88 258 335 minecraft:stripped_dark_oak_log
setblock 88 258 342 minecraft:stripped_dark_oak_log
setblock 88 258 349 minecraft:stripped_dark_oak_log
setblock 88 258 356 minecraft:stripped_dark_oak_log
fill 89 258 339 89 308 339 minecraft:dark_oak_planks
setblock 48 259 333 minecraft:shroomlight
setblock 48 259 335 minecraft:shroomlight
setblock 48 259 337 minecraft:shroomlight
setblock 48 259 339 minecraft:shroomlight
setblock 48 259 341 minecraft:shroomlight
setblock 49 259 334 minecraft:shroomlight
setblock 49 259 336 minecraft:shroomlight
setblock 49 259 338 minecraft:shroomlight
setblock 49 259 340 minecraft:shroomlight
setblock 50 259 333 minecraft:shroomlight
setblock 50 259 335 minecraft:shroomlight
setblock 50 259 337 minecraft:shroomlight
setblock 50 259 339 minecraft:shroomlight
setblock 50 259 341 minecraft:shroomlight
setblock 51 259 334 minecraft:shroomlight
setblock 51 259 336 minecraft:shroomlight
setblock 51 259 338 minecraft:shroomlight
setblock 51 259 340 minecraft:shroomlight
setblock 52 259 333 minecraft:shroomlight
setblock 52 259 335 minecraft:shroomlight
setblock 52 259 337 minecraft:shroomlight
setblock 52 259 339 minecraft:shroomlight
setblock 52 259 341 minecraft:shroomlight
setblock 53 259 334 minecraft:shroomlight
setblock 53 259 336 minecraft:shroomlight
setblock 53 259 338 minecraft:shroomlight
setblock 53 259 340 minecraft:shroomlight
setblock 54 259 333 minecraft:red_concrete
fill 56 259 332 58 259 332 minecraft:stripped_dark_oak_log
fill 56 259 334 58 259 334 minecraft:stripped_dark_oak_log
fill 58 259 333 59 261 333 minecraft:stripped_dark_oak_log
setblock 58 259 364 minecraft:red_concrete
setblock 59 259 322 minecraft:red_concrete
fill 72 259 329 73 259 330 minecraft:cherry_leaves[persistent=true]
setblock 73 259 328 minecraft:cherry_leaves[persistent=true]
setblock 73 259 331 minecraft:cherry_leaves[persistent=true]
fill 76 259 333 77 261 333 minecraft:stripped_dark_oak_log
fill 77 259 332 79 259 332 minecraft:stripped_dark_oak_log
fill 77 259 334 79 259 334 minecraft:stripped_dark_oak_log
fill 80 259 364 80 276 364 minecraft:dark_oak_planks
setblock 81 259 333 minecraft:red_concrete
setblock 89 259 348 minecraft:red_concrete
fill 89 259 349 89 308 349 minecraft:dark_oak_planks
fill 48 260 323 48 260 327 minecraft:stripped_dark_oak_log
fill 48 260 329 48 260 333 minecraft:stripped_dark_oak_log
fill 48 260 335 48 261 335 minecraft:stripped_dark_oak_log
fill 48 260 337 48 261 337 minecraft:stripped_dark_oak_log
fill 48 260 339 48 261 339 minecraft:stripped_dark_oak_log
fill 48 260 341 48 261 341 minecraft:stripped_dark_oak_log
fill 48 260 343 48 260 348 minecraft:stripped_dark_oak_log
fill 48 260 350 48 260 355 minecraft:stripped_dark_oak_log
fill 48 260 357 48 260 362 minecraft:stripped_dark_oak_log
setblock 49 260 323 minecraft:stripped_dark_oak_log
fill 49 260 334 49 261 334 minecraft:stripped_dark_oak_log
fill 49 260 336 49 261 336 minecraft:stripped_dark_oak_log
fill 49 260 338 49 261 338 minecraft:stripped_dark_oak_log
fill 49 260 340 49 261 340 minecraft:stripped_dark_oak_log
fill 49 260 363 54 260 363 minecraft:stripped_dark_oak_log
fill 50 260 333 50 261 333 minecraft:stripped_dark_oak_log
fill 50 260 335 50 261 335 minecraft:stripped_dark_oak_log
fill 50 260 337 50 261 337 minecraft:stripped_dark_oak_log
fill 50 260 339 50 261 339 minecraft:stripped_dark_oak_log
fill 50 260 341 50 261 341 minecraft:stripped_dark_oak_log
fill 51 260 323 56 260 323 minecraft:stripped_dark_oak_log
fill 51 260 334 51 261 334 minecraft:stripped_dark_oak_log
fill 51 260 336 51 261 336 minecraft:stripped_dark_oak_log
fill 51 260 338 51 261 338 minecraft:stripped_dark_oak_log
fill 51 260 340 51 261 340 minecraft:stripped_dark_oak_log
fill 52 260 333 52 261 333 minecraft:stripped_dark_oak_log
fill 52 260 335 52 261 335 minecraft:stripped_dark_oak_log
fill 52 260 337 52 261 337 minecraft:stripped_dark_oak_log
fill 52 260 339 52 261 339 minecraft:stripped_dark_oak_log
fill 52 260 341 52 261 341 minecraft:stripped_dark_oak_log
fill 53 260 334 53 261 334 minecraft:stripped_dark_oak_log
fill 53 260 336 53 261 336 minecraft:stripped_dark_oak_log
fill 53 260 338 53 261 338 minecraft:stripped_dark_oak_log
fill 53 260 340 53 261 340 minecraft:stripped_dark_oak_log
fill 55 260 333 56 260 333 minecraft:red_concrete
fill 56 260 363 61 260 363 minecraft:stripped_dark_oak_log
fill 57 260 332 57 260 334 minecraft:stripped_dark_oak_log
fill 58 260 323 63 260 323 minecraft:stripped_dark_oak_log
fill 58 260 332 60 260 332 minecraft:stripped_dark_oak_log
fill 58 260 334 60 260 334 minecraft:stripped_dark_oak_log
fill 58 260 364 58 308 364 minecraft:dark_oak_planks
fill 59 260 322 59 308 322 minecraft:dark_oak_planks
fill 60 260 333 61 261 333 minecraft:stripped_dark_oak_log
fill 63 260 363 68 260 363 minecraft:stripped_dark_oak_log
fill 65 260 323 70 260 323 minecraft:stripped_dark_oak_log
fill 66 260 324 66 261 325 minecraft:iron_bars
fill 70 260 363 75 260 363 minecraft:stripped_dark_oak_log
fill 72 260 323 77 260 323 minecraft:stripped_dark_oak_log
fill 74 260 333 75 262 333 minecraft:stripped_dark_oak_log
fill 75 260 332 78 260 332 minecraft:stripped_dark_oak_log
fill 75 260 334 78 260 334 minecraft:stripped_dark_oak_log
fill 77 260 363 82 260 363 minecraft:stripped_dark_oak_log
fill 79 260 323 84 260 323 minecraft:stripped_dark_oak_log
setblock 80 260 333 minecraft:red_concrete
fill 84 260 363 88 260 363 minecraft:stripped_dark_oak_log
fill 86 260 323 88 260 323 minecraft:stripped_dark_oak_log
fill 88 260 324 88 260 326 minecraft:stripped_dark_oak_log
fill 88 260 328 88 260 333 minecraft:stripped_dark_oak_log
fill 88 260 335 88 260 340 minecraft:stripped_dark_oak_log
fill 88 260 342 88 260 347 minecraft:stripped_dark_oak_log
fill 88 260 349 88 260 354 minecraft:stripped_dark_oak_log
fill 88 260 356 88 260 361 minecraft:stripped_dark_oak_log
fill 89 260 348 89 308 348 minecraft:dark_oak_planks
setblock 48 261 323 minecraft:stripped_dark_oak_log
setblock 48 261 330 minecraft:stripped_dark_oak_log
setblock 48 261 333 minecraft:stripped_dark_oak_log
setblock 48 261 344 minecraft:stripped_dark_oak_log
setblock 48 261 351 minecraft:stripped_dark_oak_log
setblock 48 261 358 minecraft:stripped_dark_oak_log
setblock 50 261 363 minecraft:stripped_dark_oak_log
fill 54 261 337 54 263 340 minecraft:cherry_leaves[persistent=true]
fill 54 261 359 60 261 362 minecraft:dark_oak_planks
setblock 55 261 323 minecraft:stripped_dark_oak_log
fill 55 261 338 55 263 340 minecraft:cherry_leaves[persistent=true]
setblock 57 261 333 minecraft:red_concrete
setblock 57 261 363 minecraft:stripped_dark_oak_log
fill 59 261 332 62 261 332 minecraft:stripped_dark_oak_log
fill 59 261 334 62 261 334 minecraft:stripped_dark_oak_log
setblock 62 261 323 minecraft:stripped_dark_oak_log
fill 62 261 333 65 262 333 minecraft:stripped_dark_oak_log
setblock 64 261 363 minecraft:stripped_dark_oak_log
setblock 66 261 323 minecraft:iron_bars
setblock 69 261 323 minecraft:stripped_dark_oak_log
fill 70 261 333 73 262 333 minecraft:stripped_dark_oak_log
setblock 71 261 363 minecraft:stripped_dark_oak_log
fill 73 261 332 76 261 332 minecraft:stripped_dark_oak_log
fill 73 261 334 76 261 334 minecraft:stripped_dark_oak_log
setblock 76 261 323 minecraft:stripped_dark_oak_log
setblock 78 261 333 minecraft:red_concrete
setblock 78 261 363 minecraft:stripped_dark_oak_log
setblock 83 261 323 minecraft:stripped_dark_oak_log
setblock 85 261 363 minecraft:stripped_dark_oak_log
setblock 88 261 325 minecraft:stripped_dark_oak_log
setblock 88 261 332 minecraft:stripped_dark_oak_log
setblock 88 261 339 minecraft:stripped_dark_oak_log
setblock 88 261 346 minecraft:stripped_dark_oak_log
setblock 88 261 353 minecraft:stripped_dark_oak_log
setblock 88 261 360 minecraft:stripped_dark_oak_log
fill 47 262 346 47 308 348 minecraft:dark_oak_planks
setblock 47 262 349 minecraft:red_concrete
setblock 48 262 324 minecraft:stripped_dark_oak_log
setblock 48 262 331 minecraft:stripped_dark_oak_log
setblock 48 262 333 minecraft:shroomlight
setblock 48 262 335 minecraft:shroomlight
setblock 48 262 337 minecraft:shroomlight
setblock 48 262 339 minecraft:shroomlight
setblock 48 262 341 minecraft:shroomlight
setblock 48 262 345 minecraft:stripped_dark_oak_log
setblock 48 262 352 minecraft:stripped_dark_oak_log
setblock 48 262 359 minecraft:stripped_dark_oak_log
setblock 49 262 334 minecraft:shroomlight
setblock 49 262 336 minecraft:shroomlight
setblock 49 262 338 minecraft:shroomlight
setblock 49 262 340 minecraft:shroomlight
setblock 50 262 333 minecraft:shroomlight
setblock 50 262 335 minecraft:shroomlight
setblock 50 262 337 minecraft:shroomlight
setblock 50 262 339 minecraft:shroomlight
setblock 50 262 341 minecraft:shroomlight
setblock 51 262 334 minecraft:shroomlight
setblock 51 262 336 minecraft:shroomlight
setblock 51 262 338 minecraft:shroomlight
setblock 51 262 340 minecraft:shroomlight
setblock 51 262 363 minecraft:stripped_dark_oak_log
setblock 52 262 333 minecraft:shroomlight
setblock 52 262 335 minecraft:shroomlight
setblock 52 262 337 minecraft:shroomlight
setblock 52 262 339 minecraft:shroomlight
setblock 52 262 341 minecraft:shroomlight
setblock 53 262 334 minecraft:shroomlight
setblock 53 262 336 minecraft:shroomlight
setblock 53 262 338 minecraft:shroomlight
setblock 53 262 340 minecraft:shroomlight
setblock 54 262 323 minecraft:stripped_dark_oak_log
fill 54 262 359 60 262 362 minecraft:stripped_dark_oak_log
setblock 55 262 337 minecraft:cherry_leaves[persistent=true]
setblock 56 262 339 minecraft:cherry_leaves[persistent=true]
fill 58 262 333 60 262 333 minecraft:red_concrete
setblock 58 262 363 minecraft:stripped_dark_oak_log
fill 60 262 322 62 308 322 minecraft:dark_oak_planks
setblock 61 262 323 minecraft:stripped_dark_oak_log
setblock 61 262 333 minecraft:stripped_dark_oak_log
fill 62 262 332 73 262 332 minecraft:stripped_dark_oak_log
fill 62 262 334 73 262 334 minecraft:stripped_dark_oak_log
setblock 63 262 322 minecraft:red_concrete
setblock 65 262 363 minecraft:stripped_dark_oak_log
fill 66 262 333 69 263 333 minecraft:stripped_dark_oak_log
setblock 68 262 323 minecraft:stripped_dark_oak_log
setblock 72 262 363 minecraft:stripped_dark_oak_log
setblock 75 262 323 minecraft:stripped_dark_oak_log
fill 76 262 333 77 262 333 minecraft:red_concrete
setblock 79 262 363 minecraft:stripped_dark_oak_log
setblock 82 262 323 minecraft:stripped_dark_oak_log
fill 85 262 340 87 263 340 minecraft:iron_bars
setblock 86 262 363 minecraft:stripped_dark_oak_log
setblock 88 262 324 minecraft:stripped_dark_oak_log
setblock 88 262 331 minecraft:stripped_dark_oak_log
setblock 88 262 338 minecraft:stripped_dark_oak_log
setblock 88 262 345 minecraft:stripped_dark_oak_log
setblock 88 262 352 minecraft:stripped_dark_oak_log
setblock 88 262 359 minecraft:stripped_dark_oak_log
fill 47 263 349 47 272 349 minecraft:dark_oak_planks
setblock 48 263 325 minecraft:stripped_dark_oak_log
fill 48 263 332 48 263 333 minecraft:stripped_dark_oak_log
fill 48 263 335 48 264 335 minecraft:stripped_dark_oak_log
fill 48 263 337 48 264 337 minecraft:stripped_dark_oak_log
fill 48 263 339 48 264 339 minecraft:stripped_dark_oak_log
fill 48 263 341 48 264 341 minecraft:stripped_dark_oak_log
setblock 48 263 346 minecraft:stripped_dark_oak_log
setblock 48 263 353 minecraft:stripped_dark_oak_log
setblock 48 263 360 minecraft:stripped_dark_oak_log
fill 49 263 334 49 264 334 minecraft:stripped_dark_oak_log
fill 49 263 336 49 264 336 minecraft:stripped_dark_oak_log
fill 49 263 338 49 264 338 minecraft:stripped_dark_oak_log
fill 49 263 340 49 264 340 minecraft:stripped_dark_oak_log
fill 50 263 333 50 264 333 minecraft:stripped_dark_oak_log
fill 50 263 335 50 264 335 minecraft:stripped_dark_oak_log
fill 50 263 337 50 264 337 minecraft:stripped_dark_oak_log
fill 50 263 339 50 264 339 minecraft:stripped_dark_oak_log
fill 50 263 341 50 264 341 minecraft:stripped_dark_oak_log
fill 51 263 334 51 264 334 minecraft:stripped_dark_oak_log
fill 51 263 336 51 264 336 minecraft:stripped_dark_oak_log
fill 51 263 338 51 264 338 minecraft:stripped_dark_oak_log
fill 51 263 340 51 264 340 minecraft:stripped_dark_oak_log
fill 52 263 333 52 264 333 minecraft:stripped_dark_oak_log
fill 52 263 335 52 264 335 minecraft:stripped_dark_oak_log
fill 52 263 337 52 264 337 minecraft:stripped_dark_oak_log
fill 52 263 339 52 264 339 minecraft:stripped_dark_oak_log
fill 52 263 341 52 264 341 minecraft:stripped_dark_oak_log
setblock 52 263 363 minecraft:stripped_dark_oak_log
setblock 53 263 323 minecraft:stripped_dark_oak_log
fill 53 263 334 53 264 334 minecraft:stripped_dark_oak_log
fill 53 263 336 53 264 336 minecraft:stripped_dark_oak_log
fill 53 263 338 53 264 338 minecraft:stripped_dark_oak_log
fill 53 263 340 53 264 340 minecraft:stripped_dark_oak_log
fill 54 263 359 60 263 359 minecraft:red_concrete
fill 56 263 363 58 266 363 minecraft:shroomlight
setblock 59 263 363 minecraft:stripped_dark_oak_log
setblock 60 263 323 minecraft:stripped_dark_oak_log
fill 60 263 333 62 263 333 minecraft:red_concrete
fill 63 263 322 63 308 322 minecraft:dark_oak_planks
fill 63 263 333 65 263 333 minecraft:stripped_dark_oak_log
fill 66 263 332 69 263 332 minecraft:stripped_dark_oak_log
fill 66 263 334 69 263 334 minecraft:stripped_dark_oak_log
setblock 66 263 363 minecraft:stripped_dark_oak_log
setblock 67 263 323 minecraft:stripped_dark_oak_log
fill 70 263 333 72 263 333 minecraft:stripped_dark_oak_log
fill 71 263 364 71 308 364 minecraft:dark_oak_planks
setblock 72 263 364 minecraft:red_concrete
fill 73 263 333 75 263 333 minecraft:red_concrete
setblock 73 263 363 minecraft:stripped_dark_oak_log
fill 73 263 364 74 308 364 minecraft:dark_oak_planks
setblock 74 263 323 minecraft:stripped_dark_oak_log
setblock 80 263 363 minecraft:stripped_dark_oak_log
setblock 81 263 323 minecraft:stripped_dark_oak_log
setblock 87 263 363 minecraft:stripped_dark_oak_log
setblock 88 263 323 minecraft:stripped_dark_oak_log
setblock 88 263 330 minecraft:stripped_dark_oak_log
setblock 88 263 337 minecraft:stripped_dark_oak_log
setblock 88 263 344 minecraft:stripped_dark_oak_log
setblock 88 263 351 minecraft:stripped_dark_oak_log
setblock 88 263 358 minecraft:stripped_dark_oak_log
setblock 48 264 326 minecraft:stripped_dark_oak_log
setblock 48 264 333 minecraft:stripped_dark_oak_log
setblock 48 264 347 minecraft:stripped_dark_oak_log
setblock 48 264 354 minecraft:stripped_dark_oak_log
setblock 48 264 361 minecraft:stripped_dark_oak_log
setblock 50 264 325 minecraft:light[level=12]
setblock 50 264 332 minecraft:light[level=12]
setblock 50 264 346 minecraft:light[level=12]
setblock 50 264 353 minecraft:light[level=12]
fill 50 264 358 50 264 361 minecraft:dark_oak_planks
fill 51 264 357 52 264 357 minecraft:dark_oak_planks
setblock 51 264 361 minecraft:dark_oak_planks
setblock 52 264 323 minecraft:stripped_dark_oak_log
fill 53 264 358 54 264 358 minecraft:dark_oak_planks
setblock 53 264 361 minecraft:dark_oak_planks
setblock 53 264 363 minecraft:stripped_dark_oak_log
fill 54 264 359 54 264 360 minecraft:dark_oak_planks
setblock 57 264 325 minecraft:light[level=12]
setblock 57 264 332 minecraft:light[level=12]
setblock 57 264 339 minecraft:light[level=12]
setblock 57 264 346 minecraft:light[level=12]
setblock 57 264 353 minecraft:light[level=12]
setblock 57 264 359 minecraft:stripped_dark_oak_log
setblock 57 264 360 minecraft:light[level=12]
setblock 59 264 323 minecraft:stripped_dark_oak_log
setblock 60 264 359 minecraft:stripped_dark_oak_log
setblock 60 264 363 minecraft:stripped_dark_oak_log
fill 63 264 333 72 264 333 minecraft:red_concrete
setblock 64 264 325 minecraft:light[level=12]
setblock 64 264 332 minecraft:light[level=12]
setblock 64 264 339 minecraft:light[level=12]
setblock 64 264 346 minecraft:light[level=12]
setblock 64 264 353 minecraft:light[level=12]
setblock 64 264 360 minecraft:light[level=12]
setblock 66 264 323 minecraft:stripped_dark_oak_log
setblock 67 264 363 minecraft:stripped_dark_oak_log
setblock 71 264 325 minecraft:light[level=12]
setblock 71 264 332 minecraft:light[level=12]
setblock 71 264 339 minecraft:light[level=12]
setblock 71 264 346 minecraft:light[level=12]
setblock 71 264 353 minecraft:light[level=12]
setblock 71 264 360 minecraft:light[level=12]
fill 72 264 364 72 308 364 minecraft:dark_oak_planks
setblock 73 264 323 minecraft:stripped_dark_oak_log
setblock 74 264 363 minecraft:stripped_dark_oak_log
setblock 78 264 325 minecraft:light[level=12]
setblock 78 264 332 minecraft:light[level=12]
setblock 78 264 339 minecraft:light[level=12]
setblock 78 264 346 minecraft:light[level=12]
setblock 78 264 353 minecraft:light[level=12]
setblock 78 264 360 minecraft:light[level=12]
setblock 80 264 323 minecraft:stripped_dark_oak_log
setblock 81 264 363 minecraft:stripped_dark_oak_log
fill 82 264 327 82 264 328 minecraft:dark_oak_planks
setblock 83 264 326 minecraft:dark_oak_planks
setblock 83 264 329 minecraft:dark_oak_planks
fill 84 264 325 85 264 325 minecraft:dark_oak_planks
fill 84 264 330 85 264 330 minecraft:dark_oak_planks
setblock 85 264 332 minecraft:light[level=12]
setblock 85 264 339 minecraft:light[level=12]
setblock 85 264 346 minecraft:light[level=12]
setblock 85 264 353 minecraft:light[level=12]
setblock 85 264 360 minecraft:light[level=12]
setblock 86 264 326 minecraft:dark_oak_planks
setblock 86 264 329 minecraft:dark_oak_planks
setblock 87 264 323 minecraft:stripped_dark_oak_log
setblock 88 264 329 minecraft:stripped_dark_oak_log
setblock 88 264 336 minecraft:stripped_dark_oak_log
setblock 88 264 343 minecraft:stripped_dark_oak_log
setblock 88 264 350 minecraft:stripped_dark_oak_log
setblock 88 264 357 minecraft:stripped_dark_oak_log
setblock 88 264 363 minecraft:stripped_dark_oak_log
setblock 48 265 327 minecraft:stripped_dark_oak_log
setblock 48 265 333 minecraft:shroomlight
setblock 48 265 335 minecraft:shroomlight
setblock 48 265 337 minecraft:shroomlight
setblock 48 265 339 minecraft:shroomlight
setblock 48 265 341 minecraft:shroomlight
setblock 48 265 348 minecraft:stripped_dark_oak_log
setblock 48 265 355 minecraft:stripped_dark_oak_log
setblock 48 265 362 minecraft:stripped_dark_oak_log
setblock 49 265 334 minecraft:shroomlight
setblock 49 265 336 minecraft:shroomlight
setblock 49 265 338 minecraft:shroomlight
setblock 49 265 340 minecraft:shroomlight
setblock 50 265 333 minecraft:shroomlight
setblock 50 265 335 minecraft:shroomlight
setblock 50 265 337 minecraft:shroomlight
setblock 50 265 339 minecraft:shroomlight
setblock 50 265 341 minecraft:shroomlight
setblock 51 265 323 minecraft:stripped_dark_oak_log
setblock 51 265 334 minecraft:shroomlight
setblock 51 265 336 minecraft:shroomlight
setblock 51 265 338 minecraft:shroomlight
setblock 51 265 340 minecraft:shroomlight
setblock 52 265 333 minecraft:shroomlight
setblock 52 265 335 minecraft:shroomlight
setblock 52 265 337 minecraft:shroomlight
setblock 52 265 339 minecraft:shroomlight
setblock 52 265 341 minecraft:shroomlight
setblock 53 265 334 minecraft:shroomlight
setblock 53 265 336 minecraft:shroomlight
setblock 53 265 338 minecraft:shroomlight
setblock 53 265 340 minecraft:shroomlight
setblock 54 265 363 minecraft:stripped_dark_oak_log
setblock 58 265 323 minecraft:stripped_dark_oak_log
setblock 61 265 363 minecraft:stripped_dark_oak_log
setblock 65 265 323 minecraft:stripped_dark_oak_log
setblock 68 265 363 minecraft:stripped_dark_oak_log
setblock 72 265 323 minecraft:stripped_dark_oak_log
setblock 75 265 363 minecraft:stripped_dark_oak_log
setblock 79 265 323 minecraft:stripped_dark_oak_log
setblock 82 265 363 minecraft:stripped_dark_oak_log
setblock 86 265 323 minecraft:stripped_dark_oak_log
setblock 88 265 328 minecraft:stripped_dark_oak_log
setblock 88 265 335 minecraft:stripped_dark_oak_log
setblock 88 265 342 minecraft:stripped_dark_oak_log
setblock 88 265 349 minecraft:stripped_dark_oak_log
setblock 88 265 356 minecraft:stripped_dark_oak_log
fill 89 265 361 89 308 361 minecraft:dark_oak_planks
setblock 89 265 362 minecraft:red_concrete
fill 89 265 363 89 308 363 minecraft:dark_oak_planks
fill 47 266 336 47 308 336 minecraft:dark_oak_planks
setblock 47 266 337 minecraft:red_concrete
fill 47 266 338 47 308 338 minecraft:dark_oak_planks
fill 48 266 333 48 267 333 minecraft:stripped_dark_oak_log
fill 48 266 335 48 267 335 minecraft:stripped_dark_oak_log
fill 48 266 337 48 267 337 minecraft:stripped_dark_oak_log
fill 48 266 339 48 267 339 minecraft:stripped_dark_oak_log
fill 48 266 341 48 267 341 minecraft:stripped_dark_oak_log
fill 49 266 334 49 267 334 minecraft:stripped_dark_oak_log
fill 49 266 336 49 267 336 minecraft:stripped_dark_oak_log
fill 49 266 338 49 267 338 minecraft:stripped_dark_oak_log
fill 49 266 340 49 267 340 minecraft:stripped_dark_oak_log
setblock 50 266 325 minecraft:light[level=15]
fill 50 266 333 50 267 333 minecraft:stripped_dark_oak_log
fill 50 266 335 50 267 335 minecraft:stripped_dark_oak_log
fill 50 266 337 50 267 337 minecraft:stripped_dark_oak_log
fill 50 266 339 50 267 339 minecraft:stripped_dark_oak_log
fill 50 266 341 50 267 341 minecraft:stripped_dark_oak_log
setblock 50 266 349 minecraft:light[level=15]
setblock 50 266 357 minecraft:light[level=15]
fill 51 266 334 51 267 334 minecraft:stripped_dark_oak_log
fill 51 266 336 51 267 336 minecraft:stripped_dark_oak_log
fill 51 266 338 51 267 338 minecraft:stripped_dark_oak_log
fill 51 266 340 51 267 340 minecraft:stripped_dark_oak_log
fill 52 266 333 52 267 333 minecraft:stripped_dark_oak_log
fill 52 266 335 52 267 335 minecraft:stripped_dark_oak_log
fill 52 266 337 52 267 337 minecraft:stripped_dark_oak_log
fill 52 266 339 52 267 339 minecraft:stripped_dark_oak_log
fill 52 266 341 52 267 341 minecraft:stripped_dark_oak_log
fill 53 266 334 53 267 334 minecraft:stripped_dark_oak_log
fill 53 266 336 53 267 336 minecraft:stripped_dark_oak_log
fill 53 266 338 53 267 338 minecraft:stripped_dark_oak_log
fill 53 266 340 53 267 340 minecraft:stripped_dark_oak_log
setblock 58 266 325 minecraft:light[level=15]
setblock 58 266 333 minecraft:light[level=15]
setblock 58 266 341 minecraft:light[level=15]
setblock 58 266 349 minecraft:light[level=15]
setblock 58 266 357 minecraft:light[level=15]
setblock 66 266 325 minecraft:light[level=15]
setblock 66 266 333 minecraft:light[level=15]
setblock 66 266 341 minecraft:light[level=15]
setblock 66 266 349 minecraft:light[level=15]
setblock 66 266 357 minecraft:light[level=15]
setblock 74 266 325 minecraft:light[level=15]
setblock 74 266 333 minecraft:light[level=15]
setblock 74 266 341 minecraft:light[level=15]
setblock 74 266 349 minecraft:light[level=15]
setblock 74 266 357 minecraft:light[level=15]
setblock 82 266 325 minecraft:light[level=15]
setblock 82 266 333 minecraft:light[level=15]
setblock 82 266 341 minecraft:light[level=15]
setblock 82 266 349 minecraft:light[level=15]
setblock 82 266 357 minecraft:light[level=15]
setblock 89 266 346 minecraft:red_concrete
fill 89 266 362 89 308 362 minecraft:dark_oak_planks
fill 47 267 337 47 308 337 minecraft:dark_oak_planks
setblock 48 267 329 minecraft:stripped_dark_oak_log
setblock 48 267 343 minecraft:stripped_dark_oak_log
setblock 48 267 350 minecraft:stripped_dark_oak_log
setblock 48 267 357 minecraft:stripped_dark_oak_log
setblock 49 267 323 minecraft:stripped_dark_oak_log
setblock 49 267 363 minecraft:stripped_dark_oak_log
setblock 56 267 323 minecraft:stripped_dark_oak_log
setblock 56 267 363 minecraft:stripped_dark_oak_log
setblock 63 267 323 minecraft:stripped_dark_oak_log
setblock 63 267 363 minecraft:stripped_dark_oak_log
setblock 63 267 364 minecraft:red_concrete
setblock 70 267 323 minecraft:stripped_dark_oak_log
setblock 70 267 363 minecraft:stripped_dark_oak_log
setblock 77 267 323 minecraft:stripped_dark_oak_log
setblock 77 267 363 minecraft:stripped_dark_oak_log
setblock 84 267 323 minecraft:stripped_dark_oak_log
setblock 84 267 363 minecraft:stripped_dark_oak_log
setblock 88 267 326 minecraft:stripped_dark_oak_log
setblock 88 267 333 minecraft:stripped_dark_oak_log
setblock 88 267 340 minecraft:stripped_dark_oak_log
setblock 88 267 347 minecraft:stripped_dark_oak_log
setblock 88 267 354 minecraft:stripped_dark_oak_log
setblock 88 267 361 minecraft:stripped_dark_oak_log
fill 89 267 333 89 273 334 minecraft:dark_oak_planks
setblock 89 267 335 minecraft:red_concrete
fill 89 267 346 89 308 346 minecraft:dark_oak_planks
setblock 48 268 323 minecraft:stripped_dark_oak_log
setblock 48 268 330 minecraft:stripped_dark_oak_log
setblock 48 268 333 minecraft:shroomlight
setblock 48 268 335 minecraft:shroomlight
setblock 48 268 337 minecraft:shroomlight
setblock 48 268 339 minecraft:shroomlight
setblock 48 268 341 minecraft:shroomlight
setblock 48 268 344 minecraft:stripped_dark_oak_log
setblock 48 268 351 minecraft:stripped_dark_oak_log
setblock 48 268 358 minecraft:stripped_dark_oak_log
setblock 49 268 334 minecraft:shroomlight
setblock 49 268 336 minecraft:shroomlight
setblock 49 268 338 minecraft:shroomlight
setblock 49 268 340 minecraft:shroomlight
setblock 50 268 333 minecraft:shroomlight
setblock 50 268 335 minecraft:shroomlight
setblock 50 268 337 minecraft:shroomlight
setblock 50 268 339 minecraft:shroomlight
setblock 50 268 341 minecraft:shroomlight
fill 50 268 358 50 269 360 minecraft:red_concrete
setblock 50 268 363 minecraft:stripped_dark_oak_log
setblock 51 268 334 minecraft:shroomlight
setblock 51 268 336 minecraft:shroomlight
setblock 51 268 338 minecraft:shroomlight
setblock 51 268 340 minecraft:shroomlight
fill 51 268 361 51 269 361 minecraft:red_concrete
setblock 52 268 333 minecraft:shroomlight
setblock 52 268 335 minecraft:shroomlight
setblock 52 268 337 minecraft:shroomlight
setblock 52 268 339 minecraft:shroomlight
setblock 52 268 341 minecraft:shroomlight
fill 52 268 357 52 269 357 minecraft:red_concrete
setblock 53 268 334 minecraft:shroomlight
setblock 53 268 336 minecraft:shroomlight
setblock 53 268 338 minecraft:shroomlight
setblock 53 268 340 minecraft:shroomlight
fill 53 268 358 53 269 358 minecraft:red_concrete
fill 53 268 361 53 269 361 minecraft:red_concrete
fill 54 268 359 54 269 360 minecraft:red_concrete
setblock 55 268 323 minecraft:stripped_dark_oak_log
setblock 57 268 363 minecraft:stripped_dark_oak_log
setblock 62 268 323 minecraft:stripped_dark_oak_log
fill 63 268 364 63 308 364 minecraft:dark_oak_planks
setblock 64 268 363 minecraft:stripped_dark_oak_log
setblock 69 268 323 minecraft:stripped_dark_oak_log
fill 71 268 328 71 270 330 minecraft:cherry_leaves[persistent=true]
setblock 71 268 363 minecraft:stripped_dark_oak_log
fill 72 268 328 73 270 329 minecraft:cherry_leaves[persistent=true]
setblock 76 268 323 minecraft:stripped_dark_oak_log
setblock 78 268 363 minecraft:stripped_dark_oak_log
setblock 83 268 323 minecraft:stripped_dark_oak_log
fill 83 268 326 83 269 326 minecraft:red_concrete
fill 83 268 329 83 269 329 minecraft:red_concrete
setblock 85 268 363 minecraft:stripped_dark_oak_log
fill 86 268 326 86 269 326 minecraft:red_concrete
fill 86 268 329 86 269 329 minecraft:red_concrete
setblock 88 268 325 minecraft:stripped_dark_oak_log
setblock 88 268 332 minecraft:stripped_dark_oak_log
setblock 88 268 339 minecraft:stripped_dark_oak_log
setblock 88 268 346 minecraft:stripped_dark_oak_log
setblock 88 268 353 minecraft:stripped_dark_oak_log
setblock 88 268 360 minecraft:stripped_dark_oak_log
fill 89 268 335 89 308 335 minecraft:dark_oak_planks
setblock 48 269 324 minecraft:stripped_dark_oak_log
setblock 48 269 331 minecraft:stripped_dark_oak_log
setblock 48 269 333 minecraft:stripped_dark_oak_log
setblock 48 269 335 minecraft:stripped_dark_oak_log
setblock 48 269 337 minecraft:stripped_dark_oak_log
setblock 48 269 339 minecraft:stripped_dark_oak_log
setblock 48 269 341 minecraft:stripped_dark_oak_log
setblock 48 269 345 minecraft:stripped_dark_oak_log
setblock 48 269 352 minecraft:stripped_dark_oak_log
setblock 48 269 359 minecraft:stripped_dark_oak_log
setblock 49 269 334 minecraft:stripped_dark_oak_log
setblock 49 269 336 minecraft:stripped_dark_oak_log
setblock 49 269 338 minecraft:stripped_dark_oak_log
setblock 49 269 340 minecraft:stripped_dark_oak_log
setblock 50 269 333 minecraft:stripped_dark_oak_log
setblock 50 269 335 minecraft:stripped_dark_oak_log
setblock 50 269 337 minecraft:stripped_dark_oak_log
setblock 50 269 339 minecraft:stripped_dark_oak_log
setblock 50 269 341 minecraft:stripped_dark_oak_log
setblock 51 269 334 minecraft:stripped_dark_oak_log
setblock 51 269 336 minecraft:stripped_dark_oak_log
setblock 51 269 338 minecraft:stripped_dark_oak_log
setblock 51 269 340 minecraft:stripped_dark_oak_log
setblock 51 269 363 minecraft:stripped_dark_oak_log
setblock 52 269 333 minecraft:stripped_dark_oak_log
setblock 52 269 335 minecraft:stripped_dark_oak_log
setblock 52 269 337 minecraft:stripped_dark_oak_log
setblock 52 269 339 minecraft:stripped_dark_oak_log
setblock 52 269 341 minecraft:stripped_dark_oak_log
fill 53 269 322 53 308 322 minecraft:dark_oak_planks
setblock 53 269 334 minecraft:stripped_dark_oak_log
setblock 53 269 336 minecraft:stripped_dark_oak_log
setblock 53 269 338 minecraft:stripped_dark_oak_log
setblock 53 269 340 minecraft:stripped_dark_oak_log
setblock 54 269 322 minecraft:red_concrete
setblock 54 269 323 minecraft:stripped_dark_oak_log
setblock 58 269 363 minecraft:stripped_dark_oak_log
setblock 61 269 323 minecraft:stripped_dark_oak_log
setblock 65 269 363 minecraft:stripped_dark_oak_log
setblock 68 269 323 minecraft:stripped_dark_oak_log
fill 70 269 328 70 270 329 minecraft:cherry_leaves[persistent=true]
fill 71 269 327 73 270 327 minecraft:cherry_leaves[persistent=true]
fill 72 269 330 73 271 330 minecraft:cherry_leaves[persistent=true]
setblock 72 269 363 minecraft:stripped_dark_oak_log
setblock 75 269 323 minecraft:stripped_dark_oak_log
setblock 79 269 363 minecraft:stripped_dark_oak_log
setblock 82 269 323 minecraft:stripped_dark_oak_log
setblock 86 269 363 minecraft:stripped_dark_oak_log
setblock 88 269 324 minecraft:stripped_dark_oak_log
setblock 88 269 331 minecraft:stripped_dark_oak_log
setblock 88 269 338 minecraft:stripped_dark_oak_log
setblock 88 269 345 minecraft:stripped_dark_oak_log
setblock 88 269 352 minecraft:stripped_dark_oak_log
setblock 88 269 359 minecraft:stripped_dark_oak_log
setblock 50 270 325 minecraft:light[level=12]
setblock 50 270 332 minecraft:light[level=12]
setblock 50 270 339 minecraft:light[level=12]
setblock 50 270 346 minecraft:light[level=12]
setblock 50 270 353 minecraft:light[level=12]
setblock 50 270 360 minecraft:light[level=12]
fill 54 270 322 54 308 322 minecraft:dark_oak_planks
fill 56 270 352 57 272 354 minecraft:cherry_leaves[persistent=true]
setblock 57 270 325 minecraft:light[level=12]
setblock 57 270 332 minecraft:light[level=12]
setblock 57 270 339 minecraft:light[level=12]
setblock 57 270 346 minecraft:light[level=12]
setblock 57 270 360 minecraft:light[level=12]
fill 58 270 353 58 272 354 minecraft:cherry_leaves[persistent=true]
setblock 64 270 325 minecraft:light[level=12]
setblock 64 270 332 minecraft:light[level=12]
setblock 64 270 339 minecraft:light[level=12]
setblock 64 270 346 minecraft:light[level=12]
setblock 64 270 353 minecraft:light[level=12]
setblock 64 270 360 minecraft:light[level=12]
setblock 71 270 325 minecraft:light[level=12]
setblock 71 270 332 minecraft:light[level=12]
setblock 71 270 339 minecraft:light[level=12]
setblock 71 270 346 minecraft:light[level=12]
setblock 71 270 353 minecraft:light[level=12]
setblock 71 270 360 minecraft:light[level=12]
setblock 78 270 325 minecraft:light[level=12]
setblock 78 270 332 minecraft:light[level=12]
setblock 78 270 339 minecraft:light[level=12]
setblock 78 270 346 minecraft:light[level=12]
setblock 78 270 353 minecraft:light[level=12]
setblock 78 270 360 minecraft:light[level=12]
setblock 85 270 325 minecraft:light[level=12]
setblock 85 270 332 minecraft:light[level=12]
setblock 85 270 339 minecraft:light[level=12]
setblock 85 270 346 minecraft:light[level=12]
setblock 85 270 353 minecraft:light[level=12]
setblock 85 270 360 minecraft:light[level=12]
fill 47 271 325 47 308 325 minecraft:dark_oak_planks
setblock 47 271 326 minecraft:red_concrete
fill 55 271 353 55 272 353 minecraft:cherry_leaves[persistent=true]
fill 58 271 352 59 272 352 minecraft:cherry_leaves[persistent=true]
fill 59 271 353 59 272 354 minecraft:cherry_leaves[persistent=true]
fill 70 271 329 72 271 329 minecraft:cherry_leaves[persistent=true]
fill 71 271 328 72 271 328 minecraft:cherry_leaves[persistent=true]
setblock 72 271 327 minecraft:cherry_leaves[persistent=true]
fill 47 272 326 47 308 326 minecraft:dark_oak_planks
fill 89 272 351 89 308 351 minecraft:dark_oak_planks
setblock 89 272 352 minecraft:red_concrete
fill 89 272 353 89 308 353 minecraft:dark_oak_planks
setblock 47 273 349 minecraft:red_concrete
fill 49 273 324 49 274 324 minecraft:red_concrete
fill 49 273 325 49 274 361 minecraft:deepslate_tiles
fill 49 273 362 49 274 362 minecraft:red_concrete
fill 50 273 324 86 274 324 minecraft:deepslate_tiles
fill 50 273 325 50 275 325 minecraft:red_concrete
fill 50 273 326 50 275 360 minecraft:deepslate_tiles
fill 50 273 361 50 275 361 minecraft:red_concrete
fill 50 273 362 86 274 362 minecraft:deepslate_tiles
fill 51 273 325 85 275 325 minecraft:deepslate_tiles
fill 51 273 326 51 275 326 minecraft:red_concrete
fill 51 273 327 51 275 359 minecraft:deepslate_tiles
fill 51 273 360 51 275 360 minecraft:red_concrete
fill 51 273 361 85 275 361 minecraft:deepslate_tiles
fill 52 273 326 84 275 326 minecraft:deepslate_tiles
fill 52 273 327 52 276 327 minecraft:red_concrete
fill 52 273 328 52 276 358 minecraft:deepslate_tiles
fill 52 273 359 52 276 359 minecraft:red_concrete
fill 52 273 360 84 275 360 minecraft:deepslate_tiles
fill 53 273 327 83 276 327 minecraft:deepslate_tiles
fill 53 273 328 53 276 328 minecraft:red_concrete
fill 53 273 329 53 276 357 minecraft:deepslate_tiles
fill 53 273 358 53 276 358 minecraft:red_concrete
fill 53 273 359 83 276 359 minecraft:deepslate_tiles
fill 54 273 328 82 276 328 minecraft:deepslate_tiles
fill 54 273 329 54 277 329 minecraft:red_concrete
fill 54 273 330 54 277 356 minecraft:deepslate_tiles
fill 54 273 357 54 277 357 minecraft:red_concrete
fill 54 273 358 82 276 358 minecraft:deepslate_tiles
fill 55 273 329 81 277 329 minecraft:deepslate_tiles
fill 55 273 330 55 277 330 minecraft:red_concrete
fill 55 273 331 55 277 355 minecraft:deepslate_tiles
fill 55 273 356 55 277 356 minecraft:red_concrete
fill 55 273 357 81 277 357 minecraft:deepslate_tiles
fill 56 273 330 80 277 330 minecraft:deepslate_tiles
fill 56 273 331 56 278 331 minecraft:red_concrete
fill 56 273 332 56 279 354 minecraft:deepslate_tiles
fill 56 273 355 56 278 355 minecraft:red_concrete
fill 56 273 356 80 277 356 minecraft:deepslate_tiles
fill 57 273 331 79 279 331 minecraft:deepslate_tiles
fill 57 273 332 57 278 332 minecraft:red_concrete
fill 57 273 333 57 279 353 minecraft:deepslate_tiles
fill 57 273 354 57 278 354 minecraft:red_concrete
fill 57 273 355 79 279 355 minecraft:deepslate_tiles
fill 58 273 332 78 279 332 minecraft:deepslate_tiles
fill 58 273 333 58 279 333 minecraft:red_concrete
fill 58 273 334 58 279 352 minecraft:deepslate_tiles
fill 58 273 353 58 279 353 minecraft:red_concrete
fill 58 273 354 78 279 354 minecraft:deepslate_tiles
fill 59 273 333 77 279 333 minecraft:deepslate_tiles
fill 59 273 334 59 279 334 minecraft:red_concrete
fill 59 273 335 59 279 351 minecraft:deepslate_tiles
fill 59 273 352 59 279 352 minecraft:red_concrete
fill 59 273 353 77 279 353 minecraft:deepslate_tiles
fill 60 273 334 76 279 334 minecraft:deepslate_tiles
fill 60 273 335 60 279 335 minecraft:red_concrete
fill 60 273 336 60 279 350 minecraft:deepslate_tiles
fill 60 273 351 60 279 351 minecraft:red_concrete
fill 60 273 352 76 279 352 minecraft:deepslate_tiles
fill 61 273 335 75 279 335 minecraft:deepslate_tiles
fill 61 273 336 61 279 336 minecraft:red_concrete
fill 61 273 337 61 279 349 minecraft:deepslate_tiles
fill 61 273 350 61 279 350 minecraft:red_concrete
fill 61 273 351 75 279 351 minecraft:deepslate_tiles
fill 62 273 336 74 279 336 minecraft:deepslate_tiles
fill 62 273 337 62 279 337 minecraft:red_concrete
fill 62 273 338 62 279 348 minecraft:deepslate_tiles
fill 62 273 349 62 279 349 minecraft:red_concrete
fill 62 273 350 74 279 350 minecraft:deepslate_tiles
fill 63 273 337 73 279 337 minecraft:deepslate_tiles
fill 63 273 338 63 279 338 minecraft:red_concrete
fill 63 273 339 63 279 347 minecraft:deepslate_tiles
fill 63 273 348 63 279 348 minecraft:red_concrete
fill 63 273 349 73 279 349 minecraft:deepslate_tiles
fill 64 273 338 72 278 338 minecraft:deepslate_tiles
fill 64 273 339 64 279 339 minecraft:red_concrete
fill 64 273 340 64 279 346 minecraft:deepslate_tiles
fill 64 273 347 64 279 347 minecraft:red_concrete
fill 64 273 348 72 279 348 minecraft:deepslate_tiles
fill 65 273 339 71 273 339 minecraft:deepslate_tiles
fill 65 273 340 65 279 340 minecraft:red_concrete
fill 65 273 341 65 279 345 minecraft:deepslate_tiles
fill 65 273 346 65 279 346 minecraft:red_concrete
fill 65 273 347 71 279 347 minecraft:deepslate_tiles
fill 66 273 340 70 273 340 minecraft:deepslate_tiles
fill 66 273 341 66 278 341 minecraft:red_concrete
fill 66 273 342 66 278 344 minecraft:deepslate_tiles
fill 66 273 345 66 279 345 minecraft:red_concrete
fill 66 273 346 70 278 346 minecraft:deepslate_tiles
fill 67 273 341 69 273 341 minecraft:deepslate_tiles
setblock 67 273 342 minecraft:red_concrete
fill 67 273 343 67 278 343 minecraft:deepslate_tiles
fill 67 273 344 67 278 344 minecraft:red_concrete
fill 67 273 345 69 278 345 minecraft:deepslate_tiles
setblock 68 273 342 minecraft:deepslate_tiles
setblock 68 273 343 minecraft:red_concrete
setblock 68 273 344 minecraft:deepslate_tiles
setblock 69 273 343 minecraft:deepslate_tiles
setblock 69 273 344 minecraft:red_concrete
fill 70 273 344 87 273 344 minecraft:deepslate_tiles
setblock 70 273 345 minecraft:red_concrete
setblock 71 273 340 minecraft:red_concrete
fill 71 273 341 87 273 341 minecraft:deepslate_tiles
fill 71 273 343 87 273 343 minecraft:deepslate_tiles
fill 71 273 345 87 274 345 minecraft:deepslate_tiles
fill 71 273 346 71 278 346 minecraft:red_concrete
fill 72 273 339 72 278 339 minecraft:red_concrete
fill 72 273 340 87 273 340 minecraft:deepslate_tiles
fill 72 273 342 87 273 342 minecraft:deepslate_tiles
fill 72 273 346 87 274 346 minecraft:deepslate_tiles
fill 72 273 347 72 279 347 minecraft:red_concrete
fill 73 273 338 73 279 338 minecraft:red_concrete
fill 73 273 339 87 274 339 minecraft:deepslate_tiles
fill 73 273 347 87 274 347 minecraft:deepslate_tiles
fill 73 273 348 73 279 348 minecraft:red_concrete
fill 74 273 337 74 279 337 minecraft:red_concrete
fill 74 273 338 87 274 338 minecraft:deepslate_tiles
fill 74 273 348 87 274 348 minecraft:deepslate_tiles
fill 74 273 349 74 279 349 minecraft:red_concrete
fill 75 273 336 75 279 336 minecraft:red_concrete
fill 75 273 337 87 274 337 minecraft:deepslate_tiles
fill 75 273 349 87 274 349 minecraft:deepslate_tiles
fill 75 273 350 75 279 350 minecraft:red_concrete
fill 76 273 335 76 279 335 minecraft:red_concrete
fill 76 273 336 87 274 336 minecraft:deepslate_tiles
fill 76 273 350 87 274 350 minecraft:deepslate_tiles
fill 76 273 351 76 279 351 minecraft:red_concrete
fill 77 273 334 77 279 334 minecraft:red_concrete
fill 77 273 335 87 274 335 minecraft:deepslate_tiles
fill 77 273 351 87 274 351 minecraft:deepslate_tiles
fill 77 273 352 77 279 352 minecraft:red_concrete
fill 78 273 333 78 279 333 minecraft:red_concrete
fill 78 273 334 87 274 334 minecraft:deepslate_tiles
fill 78 273 352 87 274 352 minecraft:deepslate_tiles
fill 78 273 353 78 279 353 minecraft:red_concrete
fill 79 273 332 79 278 332 minecraft:red_concrete
fill 79 273 333 87 274 333 minecraft:deepslate_tiles
fill 79 273 353 87 274 353 minecraft:deepslate_tiles
fill 79 273 354 79 278 354 minecraft:red_concrete
fill 80 273 331 80 278 331 minecraft:red_concrete
fill 80 273 332 87 274 332 minecraft:deepslate_tiles
fill 80 273 354 87 274 354 minecraft:deepslate_tiles
fill 80 273 355 80 278 355 minecraft:red_concrete
fill 81 273 330 81 277 330 minecraft:red_concrete
fill 81 273 331 87 274 331 minecraft:deepslate_tiles
fill 81 273 355 87 274 355 minecraft:deepslate_tiles
fill 81 273 356 81 277 356 minecraft:red_concrete
fill 82 273 329 82 277 329 minecraft:red_concrete
fill 82 273 330 87 274 330 minecraft:deepslate_tiles
fill 82 273 356 87 274 356 minecraft:deepslate_tiles
fill 82 273 357 82 277 357 minecraft:red_concrete
fill 83 273 328 83 276 328 minecraft:red_concrete
fill 83 273 329 87 274 329 minecraft:deepslate_tiles
fill 83 273 357 87 274 357 minecraft:deepslate_tiles
fill 83 273 358 83 276 358 minecraft:red_concrete
fill 84 273 327 84 276 327 minecraft:red_concrete
fill 84 273 328 87 274 328 minecraft:deepslate_tiles
fill 84 273 358 87 274 358 minecraft:deepslate_tiles
fill 84 273 359 84 276 359 minecraft:red_concrete
fill 85 273 326 85 275 326 minecraft:red_concrete
fill 85 273 327 87 274 327 minecraft:deepslate_tiles
fill 85 273 359 87 274 359 minecraft:deepslate_tiles
fill 85 273 360 85 275 360 minecraft:red_concrete
fill 86 273 325 86 275 325 minecraft:red_concrete
fill 86 273 326 87 274 326 minecraft:deepslate_tiles
fill 86 273 360 87 274 360 minecraft:deepslate_tiles
fill 86 273 361 86 275 361 minecraft:red_concrete
fill 87 273 324 87 274 324 minecraft:red_concrete
fill 87 273 325 87 274 325 minecraft:deepslate_tiles
fill 87 273 361 87 274 361 minecraft:deepslate_tiles
fill 87 273 362 87 274 362 minecraft:red_concrete
setblock 89 273 352 minecraft:dark_oak_planks
fill 47 274 349 47 308 349 minecraft:dark_oak_planks
fill 65 274 339 69 278 339 minecraft:deepslate_tiles
fill 66 274 340 67 278 340 minecraft:deepslate_tiles
fill 67 274 341 67 278 341 minecraft:deepslate_tiles
fill 71 274 339 71 278 339 minecraft:deepslate_tiles
fill 73 274 340 87 274 341 minecraft:deepslate_tiles
fill 73 274 343 87 274 344 minecraft:deepslate_tiles
fill 74 274 342 87 274 342 minecraft:deepslate_tiles
setblock 89 274 333 minecraft:red_concrete
fill 89 274 334 89 308 334 minecraft:dark_oak_planks
setblock 89 274 352 minecraft:red_concrete
fill 71 275 345 86 275 345 minecraft:deepslate_tiles
fill 72 275 346 86 275 346 minecraft:deepslate_tiles
fill 73 275 339 86 275 341 minecraft:deepslate_tiles
fill 73 275 343 86 275 344 minecraft:deepslate_tiles
fill 73 275 347 86 275 347 minecraft:deepslate_tiles
fill 74 275 338 86 275 338 minecraft:deepslate_tiles
fill 74 275 342 86 275 342 minecraft:deepslate_tiles
fill 74 275 348 86 275 348 minecraft:deepslate_tiles
fill 75 275 337 86 275 337 minecraft:deepslate_tiles
fill 75 275 349 86 275 349 minecraft:deepslate_tiles
fill 76 275 336 86 275 336 minecraft:deepslate_tiles
fill 76 275 350 86 275 350 minecraft:deepslate_tiles
fill 77 275 335 86 275 335 minecraft:deepslate_tiles
fill 77 275 351 86 275 351 minecraft:deepslate_tiles
fill 78 275 334 86 275 334 minecraft:deepslate_tiles
fill 78 275 352 86 275 352 minecraft:deepslate_tiles
fill 79 275 333 86 275 333 minecraft:deepslate_tiles
fill 79 275 353 86 275 353 minecraft:deepslate_tiles
fill 80 275 332 86 275 332 minecraft:deepslate_tiles
fill 80 275 354 86 275 354 minecraft:deepslate_tiles
fill 81 275 331 86 275 331 minecraft:deepslate_tiles
fill 81 275 355 86 275 355 minecraft:deepslate_tiles
fill 82 275 330 86 275 330 minecraft:deepslate_tiles
fill 82 275 356 86 275 356 minecraft:deepslate_tiles
fill 83 275 329 86 275 329 minecraft:deepslate_tiles
fill 83 275 357 86 275 357 minecraft:deepslate_tiles
fill 84 275 328 86 275 328 minecraft:deepslate_tiles
fill 84 275 358 86 275 358 minecraft:deepslate_tiles
fill 85 275 327 86 275 327 minecraft:deepslate_tiles
fill 85 275 359 86 275 359 minecraft:deepslate_tiles
setblock 86 275 326 minecraft:deepslate_tiles
setblock 86 275 360 minecraft:deepslate_tiles
fill 89 275 333 89 308 333 minecraft:dark_oak_planks
fill 89 275 352 89 308 352 minecraft:dark_oak_planks
setblock 50 276 325 minecraft:light[level=12]
setblock 50 276 332 minecraft:light[level=12]
setblock 50 276 339 minecraft:light[level=12]
setblock 50 276 346 minecraft:light[level=12]
setblock 50 276 353 minecraft:light[level=12]
setblock 50 276 360 minecraft:light[level=12]
setblock 57 276 325 minecraft:light[level=12]
setblock 57 276 360 minecraft:light[level=12]
setblock 64 276 325 minecraft:light[level=12]
setblock 64 276 360 minecraft:light[level=12]
setblock 71 276 325 minecraft:light[level=12]
fill 71 276 345 84 276 345 minecraft:deepslate_tiles
setblock 71 276 360 minecraft:light[level=12]
fill 72 276 346 84 276 346 minecraft:deepslate_tiles
fill 73 276 339 84 276 341 minecraft:deepslate_tiles
fill 73 276 343 84 276 344 minecraft:deepslate_tiles
fill 73 276 347 84 276 347 minecraft:deepslate_tiles
fill 74 276 322 74 308 322 minecraft:dark_oak_planks
fill 74 276 338 84 276 338 minecraft:deepslate_tiles
fill 74 276 342 84 276 342 minecraft:deepslate_tiles
fill 74 276 348 84 276 348 minecraft:deepslate_tiles
setblock 75 276 322 minecraft:red_concrete
fill 75 276 337 84 276 337 minecraft:deepslate_tiles
fill 75 276 349 84 276 349 minecraft:deepslate_tiles
fill 76 276 336 84 276 336 minecraft:deepslate_tiles
fill 76 276 350 84 276 350 minecraft:deepslate_tiles
fill 77 276 335 84 276 335 minecraft:deepslate_tiles
fill 77 276 351 84 276 351 minecraft:deepslate_tiles
setblock 78 276 325 minecraft:light[level=12]
fill 78 276 334 84 276 334 minecraft:deepslate_tiles
fill 78 276 352 84 276 352 minecraft:deepslate_tiles
setblock 78 276 360 minecraft:light[level=12]
fill 79 276 333 84 276 333 minecraft:deepslate_tiles
fill 79 276 353 84 276 353 minecraft:deepslate_tiles
fill 80 276 332 84 276 332 minecraft:deepslate_tiles
fill 80 276 354 84 276 354 minecraft:deepslate_tiles
fill 81 276 331 84 276 331 minecraft:deepslate_tiles
fill 81 276 355 84 276 355 minecraft:deepslate_tiles
fill 82 276 330 84 276 330 minecraft:deepslate_tiles
fill 82 276 356 84 276 356 minecraft:deepslate_tiles
fill 83 276 329 84 276 329 minecraft:deepslate_tiles
fill 83 276 357 84 276 357 minecraft:deepslate_tiles
setblock 84 276 328 minecraft:deepslate_tiles
setblock 84 276 358 minecraft:deepslate_tiles
setblock 85 276 325 minecraft:light[level=12]
setblock 85 276 332 minecraft:light[level=12]
setblock 85 276 339 minecraft:light[level=12]
setblock 85 276 346 minecraft:light[level=12]
setblock 85 276 353 minecraft:light[level=12]
setblock 85 276 360 minecraft:light[level=12]
setblock 89 276 347 minecraft:red_concrete
setblock 67 277 364 minecraft:red_concrete
fill 71 277 345 82 277 345 minecraft:deepslate_tiles
fill 72 277 346 82 277 346 minecraft:deepslate_tiles
fill 73 277 339 82 277 341 minecraft:deepslate_tiles
fill 73 277 343 82 277 344 minecraft:deepslate_tiles
fill 73 277 347 82 277 347 minecraft:deepslate_tiles
fill 74 277 338 82 277 338 minecraft:deepslate_tiles
fill 74 277 342 82 277 342 minecraft:deepslate_tiles
fill 74 277 348 82 277 348 minecraft:deepslate_tiles
fill 75 277 322 75 308 322 minecraft:dark_oak_planks
fill 75 277 337 82 277 337 minecraft:deepslate_tiles
fill 75 277 349 82 277 349 minecraft:deepslate_tiles
fill 76 277 336 82 277 336 minecraft:deepslate_tiles
fill 76 277 350 82 277 350 minecraft:deepslate_tiles
fill 77 277 335 82 277 335 minecraft:deepslate_tiles
fill 77 277 351 82 277 351 minecraft:deepslate_tiles
fill 78 277 334 82 277 334 minecraft:deepslate_tiles
fill 78 277 352 82 277 352 minecraft:deepslate_tiles
fill 79 277 333 82 277 333 minecraft:deepslate_tiles
fill 79 277 353 82 277 353 minecraft:deepslate_tiles
fill 80 277 332 82 277 332 minecraft:deepslate_tiles
fill 80 277 354 82 277 354 minecraft:deepslate_tiles
setblock 80 277 364 minecraft:red_concrete
fill 81 277 331 82 277 331 minecraft:deepslate_tiles
fill 81 277 355 82 277 355 minecraft:deepslate_tiles
setblock 82 277 330 minecraft:deepslate_tiles
setblock 82 277 356 minecraft:deepslate_tiles
setblock 83 277 364 minecraft:red_concrete
fill 84 277 364 86 286 364 minecraft:dark_oak_planks
fill 89 277 347 89 308 347 minecraft:dark_oak_planks
fill 47 278 354 47 308 354 minecraft:dark_oak_planks
setblock 47 278 355 minecraft:red_concrete
fill 47 278 356 47 308 356 minecraft:dark_oak_planks
fill 67 278 364 67 308 364 minecraft:dark_oak_planks
fill 71 278 345 80 278 345 minecraft:deepslate_tiles
fill 72 278 346 80 279 346 minecraft:deepslate_tiles
fill 73 278 339 80 278 341 minecraft:deepslate_tiles
fill 73 278 343 80 278 344 minecraft:deepslate_tiles
fill 73 278 347 80 279 347 minecraft:deepslate_tiles
fill 74 278 338 80 279 338 minecraft:deepslate_tiles
fill 74 278 342 80 278 342 minecraft:deepslate_tiles
fill 74 278 348 80 279 348 minecraft:deepslate_tiles
fill 75 278 337 80 279 337 minecraft:deepslate_tiles
fill 75 278 349 80 279 349 minecraft:deepslate_tiles
fill 76 278 336 80 279 336 minecraft:deepslate_tiles
fill 76 278 350 80 279 350 minecraft:deepslate_tiles
fill 77 278 335 80 279 335 minecraft:deepslate_tiles
fill 77 278 351 80 279 351 minecraft:deepslate_tiles
fill 78 278 334 80 279 334 minecraft:deepslate_tiles
fill 78 278 352 80 279 352 minecraft:deepslate_tiles
fill 79 278 333 80 279 333 minecraft:deepslate_tiles
fill 79 278 353 80 279 353 minecraft:deepslate_tiles
fill 80 278 332 80 279 332 minecraft:deepslate_tiles
fill 80 278 354 80 279 354 minecraft:deepslate_tiles
fill 80 278 364 80 308 364 minecraft:dark_oak_planks
fill 83 278 364 83 308 364 minecraft:dark_oak_planks
fill 47 279 355 47 308 355 minecraft:dark_oak_planks
fill 48 279 323 55 279 363 minecraft:deepslate_tiles
fill 56 279 323 56 279 331 minecraft:deepslate_tiles
fill 56 279 355 56 279 363 minecraft:deepslate_tiles
fill 57 279 323 88 279 330 minecraft:deepslate_tiles
setblock 57 279 332 minecraft:deepslate_tiles
setblock 57 279 354 minecraft:deepslate_tiles
fill 57 279 356 88 279 363 minecraft:deepslate_tiles
fill 64 279 338 68 279 338 minecraft:deepslate_tiles
fill 65 279 339 66 279 339 minecraft:deepslate_tiles
setblock 66 279 340 minecraft:deepslate_tiles
fill 66 279 341 66 279 343 minecraft:gold_block
setblock 66 279 344 minecraft:deepslate_tiles
fill 66 279 346 68 279 346 minecraft:deepslate_tiles
fill 67 279 339 67 279 341 minecraft:gold_block
fill 67 279 343 67 279 345 minecraft:gold_block
fill 68 279 339 69 279 339 minecraft:gold_block
fill 68 279 345 69 279 345 minecraft:gold_block
fill 69 279 338 71 279 338 minecraft:gold_block
fill 69 279 346 71 279 346 minecraft:gold_block
fill 71 279 339 73 279 339 minecraft:gold_block
fill 71 279 345 73 279 345 minecraft:gold_block
setblock 72 279 338 minecraft:deepslate_tiles
fill 73 279 340 73 279 341 minecraft:gold_block
fill 73 279 343 73 279 344 minecraft:gold_block
fill 74 279 339 88 279 340 minecraft:deepslate_tiles
fill 74 279 341 74 279 343 minecraft:gold_block
fill 74 279 344 88 279 345 minecraft:deepslate_tiles
fill 75 279 341 88 279 343 minecraft:deepslate_tiles
setblock 79 279 332 minecraft:deepslate_tiles
setblock 79 279 354 minecraft:deepslate_tiles
fill 80 279 331 88 279 331 minecraft:deepslate_tiles
fill 80 279 355 88 279 355 minecraft:deepslate_tiles
fill 81 279 332 88 279 338 minecraft:deepslate_tiles
fill 81 279 346 88 279 354 minecraft:deepslate_tiles
fill 53 280 364 53 281 364 minecraft:red_concrete
setblock 50 282 325 minecraft:light[level=15]
setblock 50 282 332 minecraft:light[level=12]
setblock 50 282 333 minecraft:light[level=15]
setblock 50 282 339 minecraft:light[level=12]
setblock 50 282 341 minecraft:light[level=15]
setblock 50 282 346 minecraft:light[level=12]
setblock 50 282 349 minecraft:light[level=15]
setblock 50 282 353 minecraft:light[level=12]
setblock 50 282 357 minecraft:light[level=15]
setblock 50 282 360 minecraft:light[level=12]
fill 53 282 364 53 308 364 minecraft:dark_oak_planks
setblock 57 282 325 minecraft:light[level=12]
setblock 57 282 332 minecraft:light[level=12]
setblock 57 282 339 minecraft:light[level=12]
setblock 57 282 346 minecraft:light[level=12]
setblock 57 282 353 minecraft:light[level=12]
setblock 57 282 360 minecraft:light[level=12]
setblock 58 282 325 minecraft:light[level=15]
setblock 58 282 333 minecraft:light[level=15]
setblock 58 282 341 minecraft:light[level=15]
setblock 58 282 349 minecraft:light[level=15]
setblock 58 282 357 minecraft:light[level=15]
setblock 64 282 325 minecraft:light[level=12]
setblock 64 282 332 minecraft:light[level=12]
setblock 64 282 339 minecraft:light[level=12]
setblock 64 282 346 minecraft:light[level=12]
setblock 64 282 353 minecraft:light[level=12]
setblock 64 282 360 minecraft:light[level=12]
setblock 66 282 325 minecraft:light[level=15]
setblock 66 282 333 minecraft:light[level=15]
setblock 66 282 341 minecraft:light[level=15]
setblock 66 282 349 minecraft:light[level=15]
setblock 66 282 357 minecraft:light[level=15]
setblock 71 282 325 minecraft:light[level=12]
setblock 71 282 332 minecraft:light[level=12]
setblock 71 282 339 minecraft:light[level=12]
setblock 71 282 346 minecraft:light[level=12]
setblock 71 282 353 minecraft:light[level=12]
setblock 71 282 360 minecraft:light[level=12]
setblock 74 282 325 minecraft:light[level=15]
setblock 74 282 333 minecraft:light[level=15]
setblock 74 282 341 minecraft:light[level=15]
setblock 74 282 349 minecraft:light[level=15]
setblock 74 282 357 minecraft:light[level=15]
setblock 78 282 325 minecraft:light[level=12]
setblock 78 282 332 minecraft:light[level=12]
setblock 78 282 339 minecraft:light[level=12]
setblock 78 282 346 minecraft:light[level=12]
setblock 78 282 353 minecraft:light[level=12]
setblock 78 282 360 minecraft:light[level=12]
setblock 82 282 325 minecraft:light[level=15]
setblock 82 282 333 minecraft:light[level=15]
setblock 82 282 341 minecraft:light[level=15]
setblock 82 282 349 minecraft:light[level=15]
setblock 82 282 357 minecraft:light[level=15]
setblock 85 282 325 minecraft:light[level=12]
setblock 85 282 332 minecraft:light[level=12]
setblock 85 282 339 minecraft:light[level=12]
setblock 85 282 346 minecraft:light[level=12]
setblock 85 282 353 minecraft:light[level=12]
setblock 85 282 360 minecraft:light[level=12]
setblock 47 283 331 minecraft:red_concrete
setblock 48 283 324 minecraft:stripped_dark_oak_log
fill 48 283 328 48 300 328 minecraft:stripped_dark_oak_log
setblock 48 283 331 minecraft:stripped_dark_oak_log
fill 48 283 335 48 300 335 minecraft:stripped_dark_oak_log
setblock 48 283 338 minecraft:stripped_dark_oak_log
fill 48 283 342 48 300 342 minecraft:stripped_dark_oak_log
setblock 48 283 345 minecraft:stripped_dark_oak_log
fill 48 283 349 48 300 349 minecraft:stripped_dark_oak_log
setblock 48 283 352 minecraft:stripped_dark_oak_log
fill 48 283 356 48 300 356 minecraft:stripped_dark_oak_log
setblock 48 283 359 minecraft:stripped_dark_oak_log
fill 48 283 363 48 300 363 minecraft:stripped_dark_oak_log
fill 50 283 323 50 300 323 minecraft:stripped_dark_oak_log
setblock 51 283 363 minecraft:stripped_dark_oak_log
setblock 54 283 323 minecraft:stripped_dark_oak_log
fill 55 283 363 55 300 363 minecraft:stripped_dark_oak_log
fill 57 283 323 57 300 323 minecraft:stripped_dark_oak_log
setblock 58 283 363 minecraft:stripped_dark_oak_log
setblock 60 283 335 minecraft:red_concrete
fill 60 283 336 60 283 350 minecraft:deepslate_tiles
setblock 60 283 351 minecraft:red_concrete
setblock 61 283 323 minecraft:stripped_dark_oak_log
fill 61 283 335 75 283 335 minecraft:deepslate_tiles
setblock 61 283 336 minecraft:red_concrete
fill 61 283 337 61 283 349 minecraft:deepslate_tiles
setblock 61 283 350 minecraft:red_concrete
fill 61 283 351 75 283 351 minecraft:deepslate_tiles
fill 62 283 336 74 283 336 minecraft:deepslate_tiles
fill 62 283 337 62 284 337 minecraft:red_concrete
fill 62 283 338 62 284 348 minecraft:deepslate_tiles
fill 62 283 349 62 284 349 minecraft:red_concrete
fill 62 283 350 74 283 350 minecraft:deepslate_tiles
fill 62 283 363 62 300 363 minecraft:stripped_dark_oak_log
fill 63 283 337 73 284 337 minecraft:deepslate_tiles
fill 63 283 338 63 284 338 minecraft:red_concrete
fill 63 283 339 63 284 347 minecraft:deepslate_tiles
fill 63 283 348 63 284 348 minecraft:red_concrete
fill 63 283 349 73 284 349 minecraft:deepslate_tiles
fill 64 283 323 64 300 323 minecraft:stripped_dark_oak_log
fill 64 283 338 72 284 338 minecraft:deepslate_tiles
fill 64 283 339 64 285 339 minecraft:red_concrete
fill 64 283 340 64 285 346 minecraft:deepslate_tiles
fill 64 283 347 64 285 347 minecraft:red_concrete
fill 64 283 348 72 284 348 minecraft:deepslate_tiles
fill 65 283 324 69 283 324 minecraft:red_wool
fill 65 283 339 71 285 339 minecraft:deepslate_tiles
fill 65 283 340 65 285 340 minecraft:red_concrete
fill 65 283 341 65 285 345 minecraft:deepslate_tiles
fill 65 283 346 65 285 346 minecraft:red_concrete
fill 65 283 347 71 285 347 minecraft:deepslate_tiles
setblock 65 283 363 minecraft:stripped_dark_oak_log
fill 66 283 340 70 285 340 minecraft:deepslate_tiles
fill 66 283 341 66 285 341 minecraft:red_concrete
fill 66 283 342 66 285 344 minecraft:deepslate_tiles
fill 66 283 345 66 285 345 minecraft:red_concrete
fill 66 283 346 70 285 346 minecraft:deepslate_tiles
fill 67 283 341 69 285 341 minecraft:deepslate_tiles
fill 67 283 342 67 285 342 minecraft:red_concrete
fill 67 283 343 67 285 343 minecraft:deepslate_tiles
fill 67 283 344 67 285 344 minecraft:red_concrete
fill 67 283 345 69 285 345 minecraft:deepslate_tiles
setblock 68 283 323 minecraft:stripped_dark_oak_log
fill 68 283 342 68 285 342 minecraft:deepslate_tiles
fill 68 283 343 68 285 343 minecraft:red_concrete
fill 68 283 344 68 285 344 minecraft:deepslate_tiles
fill 69 283 343 69 285 343 minecraft:deepslate_tiles
fill 69 283 344 69 285 344 minecraft:red_concrete
fill 69 283 363 69 300 363 minecraft:stripped_dark_oak_log
fill 70 283 344 76 283 344 minecraft:deepslate_tiles
fill 70 283 345 70 285 345 minecraft:red_concrete
fill 71 283 323 71 300 323 minecraft:stripped_dark_oak_log
fill 71 283 340 71 285 340 minecraft:red_concrete
fill 71 283 341 76 283 341 minecraft:deepslate_tiles
fill 71 283 343 76 283 343 minecraft:deepslate_tiles
fill 71 283 345 76 283 345 minecraft:deepslate_tiles
fill 71 283 346 71 285 346 minecraft:red_concrete
fill 72 283 339 72 285 339 minecraft:red_concrete
fill 72 283 340 76 283 340 minecraft:deepslate_tiles
fill 72 283 342 76 283 342 minecraft:deepslate_tiles
fill 72 283 346 76 283 346 minecraft:deepslate_tiles
fill 72 283 347 72 285 347 minecraft:red_concrete
setblock 72 283 363 minecraft:stripped_dark_oak_log
setblock 73 283 324 minecraft:red_concrete
fill 73 283 338 73 284 338 minecraft:red_concrete
fill 73 283 339 76 283 339 minecraft:deepslate_tiles
fill 73 283 347 76 283 347 minecraft:deepslate_tiles
fill 73 283 348 73 284 348 minecraft:red_concrete
fill 74 283 337 74 284 337 minecraft:red_concrete
fill 74 283 338 76 283 338 minecraft:deepslate_tiles
fill 74 283 348 76 283 348 minecraft:deepslate_tiles
fill 74 283 349 74 284 349 minecraft:red_concrete
fill 74 283 358 84 285 363 minecraft:stripped_dark_oak_log
setblock 75 283 323 minecraft:stripped_dark_oak_log
setblock 75 283 336 minecraft:red_concrete
fill 75 283 337 76 283 337 minecraft:deepslate_tiles
fill 75 283 349 76 283 349 minecraft:deepslate_tiles
setblock 75 283 350 minecraft:red_concrete
setblock 76 283 335 minecraft:red_concrete
setblock 76 283 336 minecraft:deepslate_tiles
setblock 76 283 350 minecraft:deepslate_tiles
setblock 76 283 351 minecraft:red_concrete
fill 78 283 323 78 300 323 minecraft:stripped_dark_oak_log
fill 78 283 341 88 285 351 minecraft:stripped_dark_oak_log
fill 79 283 338 88 285 340 minecraft:stripped_dark_oak_log
setblock 82 283 323 minecraft:stripped_dark_oak_log
fill 85 283 323 85 300 323 minecraft:stripped_dark_oak_log
fill 86 283 326 86 283 330 minecraft:red_wool
setblock 86 283 363 minecraft:stripped_dark_oak_log
setblock 88 283 324 minecraft:stripped_dark_oak_log
fill 88 283 327 88 300 327 minecraft:stripped_dark_oak_log
setblock 88 283 331 minecraft:stripped_dark_oak_log
fill 88 283 334 88 300 334 minecraft:stripped_dark_oak_log
setblock 88 283 352 minecraft:stripped_dark_oak_log
fill 88 283 355 88 300 355 minecraft:stripped_dark_oak_log
setblock 88 283 359 minecraft:stripped_dark_oak_log
fill 88 283 362 88 300 362 minecraft:stripped_dark_oak_log
fill 47 284 331 47 308 331 minecraft:dark_oak_planks
setblock 48 284 325 minecraft:stripped_dark_oak_log
setblock 48 284 332 minecraft:stripped_dark_oak_log
setblock 48 284 339 minecraft:stripped_dark_oak_log
setblock 48 284 346 minecraft:stripped_dark_oak_log
setblock 48 284 353 minecraft:stripped_dark_oak_log
setblock 48 284 360 minecraft:stripped_dark_oak_log
setblock 52 284 363 minecraft:stripped_dark_oak_log
setblock 53 284 323 minecraft:stripped_dark_oak_log
setblock 59 284 363 minecraft:stripped_dark_oak_log
setblock 60 284 323 minecraft:stripped_dark_oak_log
fill 64 284 324 70 285 324 minecraft:iron_bars
fill 64 284 360 64 289 360 minecraft:red_concrete
setblock 66 284 363 minecraft:stripped_dark_oak_log
setblock 67 284 323 minecraft:stripped_dark_oak_log
fill 70 284 344 74 284 344 minecraft:deepslate_tiles
fill 71 284 341 74 284 341 minecraft:deepslate_tiles
fill 71 284 343 74 284 343 minecraft:deepslate_tiles
fill 71 284 345 74 284 345 minecraft:deepslate_tiles
fill 72 284 340 74 284 340 minecraft:deepslate_tiles
fill 72 284 342 74 284 342 minecraft:deepslate_tiles
fill 72 284 346 74 284 346 minecraft:deepslate_tiles
fill 73 284 324 73 285 324 minecraft:shroomlight
fill 73 284 339 74 284 339 minecraft:deepslate_tiles
fill 73 284 347 74 284 347 minecraft:deepslate_tiles
setblock 73 284 363 minecraft:stripped_dark_oak_log
setblock 74 284 323 minecraft:stripped_dark_oak_log
setblock 74 284 338 minecraft:deepslate_tiles
setblock 74 284 348 minecraft:deepslate_tiles
fill 78 284 353 80 286 354 minecraft:cherry_leaves[persistent=true]
fill 79 284 355 81 287 355 minecraft:cherry_leaves[persistent=true]
setblock 81 284 323 minecraft:stripped_dark_oak_log
fill 81 284 354 81 287 354 minecraft:cherry_leaves[persistent=true]
fill 86 284 325 86 285 331 minecraft:iron_bars
setblock 87 284 363 minecraft:stripped_dark_oak_log
setblock 88 284 323 minecraft:stripped_dark_oak_log
setblock 88 284 330 minecraft:stripped_dark_oak_log
setblock 88 284 337 minecraft:stripped_dark_oak_log
setblock 88 284 358 minecraft:stripped_dark_oak_log
setblock 48 285 326 minecraft:stripped_dark_oak_log
setblock 48 285 333 minecraft:stripped_dark_oak_log
setblock 48 285 340 minecraft:stripped_dark_oak_log
setblock 48 285 347 minecraft:stripped_dark_oak_log
setblock 48 285 354 minecraft:stripped_dark_oak_log
setblock 48 285 361 minecraft:stripped_dark_oak_log
setblock 52 285 323 minecraft:stripped_dark_oak_log
setblock 53 285 363 minecraft:stripped_dark_oak_log
setblock 59 285 323 minecraft:stripped_dark_oak_log
setblock 60 285 363 minecraft:stripped_dark_oak_log
setblock 66 285 323 minecraft:stripped_dark_oak_log
setblock 67 285 363 minecraft:stripped_dark_oak_log
fill 68 285 327 68 286 327 minecraft:shroomlight
fill 70 285 344 72 285 344 minecraft:deepslate_tiles
fill 71 285 341 72 285 341 minecraft:deepslate_tiles
fill 71 285 343 72 285 343 minecraft:deepslate_tiles
fill 71 285 345 72 285 345 minecraft:deepslate_tiles
setblock 72 285 340 minecraft:deepslate_tiles
setblock 72 285 342 minecraft:deepslate_tiles
setblock 72 285 346 minecraft:deepslate_tiles
setblock 73 285 323 minecraft:stripped_dark_oak_log
fill 78 285 355 78 286 355 minecraft:cherry_leaves[persistent=true]
fill 79 285 356 80 285 356 minecraft:cherry_leaves[persistent=true]
setblock 80 285 323 minecraft:stripped_dark_oak_log
fill 81 285 353 81 286 353 minecraft:cherry_leaves[persistent=true]
setblock 87 285 323 minecraft:stripped_dark_oak_log
setblock 88 285 329 minecraft:stripped_dark_oak_log
setblock 88 285 336 minecraft:stripped_dark_oak_log
setblock 88 285 357 minecraft:stripped_dark_oak_log
setblock 88 285 363 minecraft:stripped_dark_oak_log
setblock 48 286 327 minecraft:stripped_dark_oak_log
setblock 48 286 334 minecraft:stripped_dark_oak_log
setblock 48 286 341 minecraft:stripped_dark_oak_log
setblock 48 286 348 minecraft:stripped_dark_oak_log
fill 48 286 353 50 287 353 minecraft:iron_bars
setblock 48 286 355 minecraft:stripped_dark_oak_log
setblock 48 286 362 minecraft:stripped_dark_oak_log
setblock 51 286 323 minecraft:stripped_dark_oak_log
setblock 54 286 363 minecraft:stripped_dark_oak_log
setblock 58 286 323 minecraft:stripped_dark_oak_log
setblock 61 286 363 minecraft:stripped_dark_oak_log
fill 63 286 360 63 289 360 minecraft:red_concrete
fill 64 286 359 64 289 359 minecraft:red_concrete
setblock 65 286 323 minecraft:stripped_dark_oak_log
fill 65 286 360 65 289 360 minecraft:red_concrete
setblock 68 286 363 minecraft:stripped_dark_oak_log
setblock 72 286 323 minecraft:stripped_dark_oak_log
setblock 73 286 324 minecraft:red_concrete
fill 74 286 358 74 297 358 minecraft:stripped_dark_oak_log
setblock 74 286 359 minecraft:shroomlight
fill 74 286 360 74 297 360 minecraft:stripped_dark_oak_log
setblock 74 286 361 minecraft:shroomlight
fill 74 286 362 74 297 362 minecraft:stripped_dark_oak_log
setblock 74 286 363 minecraft:shroomlight
setblock 75 286 358 minecraft:shroomlight
fill 75 286 359 75 297 359 minecraft:stripped_dark_oak_log
setblock 75 286 360 minecraft:shroomlight
fill 75 286 361 75 297 361 minecraft:stripped_dark_oak_log
setblock 75 286 362 minecraft:shroomlight
fill 75 286 363 75 297 363 minecraft:stripped_dark_oak_log
fill 76 286 358 76 297 358 minecraft:stripped_dark_oak_log
setblock 76 286 359 minecraft:shroomlight
fill 76 286 360 76 297 360 minecraft:stripped_dark_oak_log
setblock 76 286 361 minecraft:shroomlight
fill 76 286 362 76 297 362 minecraft:stripped_dark_oak_log
setblock 76 286 363 minecraft:shroomlight
setblock 77 286 358 minecraft:shroomlight
fill 77 286 359 77 297 359 minecraft:stripped_dark_oak_log
setblock 77 286 360 minecraft:shroomlight
fill 77 286 361 77 297 361 minecraft:stripped_dark_oak_log
setblock 77 286 362 minecraft:shroomlight
fill 77 286 363 77 297 363 minecraft:stripped_dark_oak_log
fill 78 286 341 79 300 351 minecraft:stripped_dark_oak_log
fill 78 286 358 78 297 358 minecraft:stripped_dark_oak_log
setblock 78 286 359 minecraft:shroomlight
fill 78 286 360 78 297 360 minecraft:stripped_dark_oak_log
setblock 78 286 361 minecraft:shroomlight
fill 78 286 362 78 297 362 minecraft:stripped_dark_oak_log
setblock 78 286 363 minecraft:shroomlight
setblock 79 286 323 minecraft:stripped_dark_oak_log
fill 79 286 338 79 300 340 minecraft:stripped_dark_oak_log
setblock 79 286 358 minecraft:shroomlight
fill 79 286 359 79 297 359 minecraft:stripped_dark_oak_log
setblock 79 286 360 minecraft:shroomlight
fill 79 286 361 79 297 361 minecraft:stripped_dark_oak_log
setblock 79 286 362 minecraft:shroomlight
fill 79 286 363 79 297 363 minecraft:stripped_dark_oak_log
fill 80 286 338 80 300 338 minecraft:stripped_dark_oak_log
setblock 80 286 339 minecraft:shroomlight
fill 80 286 340 80 300 340 minecraft:stripped_dark_oak_log
setblock 80 286 341 minecraft:shroomlight
fill 80 286 342 80 300 342 minecraft:stripped_dark_oak_log
setblock 80 286 343 minecraft:shroomlight
fill 80 286 344 80 300 344 minecraft:stripped_dark_oak_log
setblock 80 286 345 minecraft:shroomlight
fill 80 286 346 80 300 346 minecraft:stripped_dark_oak_log
setblock 80 286 347 minecraft:shroomlight
fill 80 286 348 80 300 348 minecraft:stripped_dark_oak_log
setblock 80 286 349 minecraft:shroomlight
fill 80 286 350 80 300 351 minecraft:stripped_dark_oak_log
setblock 80 286 356 minecraft:cherry_leaves[persistent=true]
fill 80 286 358 80 297 358 minecraft:stripped_dark_oak_log
setblock 80 286 359 minecraft:shroomlight
fill 80 286 360 80 297 360 minecraft:stripped_dark_oak_log
setblock 80 286 361 minecraft:shroomlight
fill 80 286 362 80 297 362 minecraft:stripped_dark_oak_log
setblock 80 286 363 minecraft:shroomlight
setblock 81 286 338 minecraft:shroomlight
fill 81 286 339 81 300 339 minecraft:stripped_dark_oak_log
setblock 81 286 340 minecraft:shroomlight
fill 81 286 341 81 300 341 minecraft:stripped_dark_oak_log
setblock 81 286 342 minecraft:shroomlight
fill 81 286 343 81 300 343 minecraft:stripped_dark_oak_log
setblock 81 286 344 minecraft:shroomlight
fill 81 286 345 81 300 345 minecraft:stripped_dark_oak_log
setblock 81 286 346 minecraft:shroomlight
fill 81 286 347 81 300 347 minecraft:stripped_dark_oak_log
setblock 81 286 348 minecraft:shroomlight
fill 81 286 349 81 300 349 minecraft:stripped_dark_oak_log
setblock 81 286 350 minecraft:shroomlight
fill 81 286 351 88 300 351 minecraft:stripped_dark_oak_log
setblock 81 286 358 minecraft:shroomlight
fill 81 286 359 81 297 359 minecraft:stripped_dark_oak_log
setblock 81 286 360 minecraft:shroomlight
fill 81 286 361 81 297 361 minecraft:stripped_dark_oak_log
setblock 81 286 362 minecraft:shroomlight
fill 81 286 363 81 297 363 minecraft:stripped_dark_oak_log
fill 82 286 338 82 300 338 minecraft:stripped_dark_oak_log
setblock 82 286 339 minecraft:shroomlight
fill 82 286 340 82 300 340 minecraft:stripped_dark_oak_log
setblock 82 286 341 minecraft:shroomlight
fill 82 286 342 82 300 342 minecraft:stripped_dark_oak_log
setblock 82 286 343 minecraft:shroomlight
fill 82 286 344 82 300 344 minecraft:stripped_dark_oak_log
setblock 82 286 345 minecraft:shroomlight
fill 82 286 346 82 300 346 minecraft:stripped_dark_oak_log
setblock 82 286 347 minecraft:shroomlight
fill 82 286 348 82 300 348 minecraft:stripped_dark_oak_log
setblock 82 286 349 minecraft:shroomlight
fill 82 286 350 82 300 350 minecraft:stripped_dark_oak_log
fill 82 286 358 82 297 358 minecraft:stripped_dark_oak_log
setblock 82 286 359 minecraft:shroomlight
fill 82 286 360 82 297 360 minecraft:stripped_dark_oak_log
setblock 82 286 361 minecraft:shroomlight
fill 82 286 362 82 297 362 minecraft:stripped_dark_oak_log
setblock 82 286 363 minecraft:shroomlight
setblock 83 286 338 minecraft:shroomlight
fill 83 286 339 83 300 339 minecraft:stripped_dark_oak_log
setblock 83 286 340 minecraft:shroomlight
fill 83 286 341 83 300 341 minecraft:stripped_dark_oak_log
setblock 83 286 342 minecraft:shroomlight
fill 83 286 343 83 300 343 minecraft:stripped_dark_oak_log
setblock 83 286 344 minecraft:shroomlight
fill 83 286 345 83 300 345 minecraft:stripped_dark_oak_log
setblock 83 286 346 minecraft:shroomlight
fill 83 286 347 83 300 347 minecraft:stripped_dark_oak_log
setblock 83 286 348 minecraft:shroomlight
fill 83 286 349 83 300 349 minecraft:stripped_dark_oak_log
setblock 83 286 350 minecraft:shroomlight
setblock 83 286 358 minecraft:shroomlight
fill 83 286 359 83 297 359 minecraft:stripped_dark_oak_log
setblock 83 286 360 minecraft:shroomlight
setblock 83 286 361 minecraft:stripped_dark_oak_log
setblock 83 286 362 minecraft:shroomlight
fill 83 286 363 83 300 363 minecraft:stripped_dark_oak_log
fill 84 286 338 84 300 338 minecraft:stripped_dark_oak_log
setblock 84 286 339 minecraft:shroomlight
fill 84 286 340 84 300 340 minecraft:stripped_dark_oak_log
setblock 84 286 341 minecraft:shroomlight
fill 84 286 342 84 300 342 minecraft:stripped_dark_oak_log
setblock 84 286 343 minecraft:shroomlight
fill 84 286 344 84 300 344 minecraft:stripped_dark_oak_log
setblock 84 286 345 minecraft:shroomlight
fill 84 286 346 84 300 346 minecraft:stripped_dark_oak_log
setblock 84 286 347 minecraft:shroomlight
fill 84 286 348 84 300 348 minecraft:stripped_dark_oak_log
setblock 84 286 349 minecraft:shroomlight
fill 84 286 350 84 300 350 minecraft:stripped_dark_oak_log
fill 84 286 358 84 297 358 minecraft:stripped_dark_oak_log
setblock 84 286 359 minecraft:shroomlight
fill 84 286 360 84 297 360 minecraft:stripped_dark_oak_log
setblock 84 286 361 minecraft:shroomlight
fill 84 286 362 84 297 362 minecraft:stripped_dark_oak_log
setblock 84 286 363 minecraft:shroomlight
setblock 85 286 338 minecraft:shroomlight
fill 85 286 339 85 300 339 minecraft:stripped_dark_oak_log
setblock 85 286 340 minecraft:shroomlight
fill 85 286 341 85 300 341 minecraft:stripped_dark_oak_log
setblock 85 286 342 minecraft:shroomlight
fill 85 286 343 85 300 343 minecraft:stripped_dark_oak_log
setblock 85 286 344 minecraft:shroomlight
fill 85 286 345 85 300 345 minecraft:stripped_dark_oak_log
setblock 85 286 346 minecraft:shroomlight
fill 85 286 347 85 300 347 minecraft:stripped_dark_oak_log
setblock 85 286 348 minecraft:shroomlight
fill 85 286 349 85 300 349 minecraft:stripped_dark_oak_log
setblock 85 286 350 minecraft:shroomlight
setblock 86 286 323 minecraft:stripped_dark_oak_log
fill 86 286 338 86 300 338 minecraft:stripped_dark_oak_log
setblock 86 286 339 minecraft:shroomlight
fill 86 286 340 86 300 340 minecraft:stripped_dark_oak_log
setblock 86 286 341 minecraft:shroomlight
fill 86 286 342 86 300 342 minecraft:stripped_dark_oak_log
setblock 86 286 343 minecraft:shroomlight
fill 86 286 344 86 300 344 minecraft:stripped_dark_oak_log
setblock 86 286 345 minecraft:shroomlight
fill 86 286 346 86 300 346 minecraft:stripped_dark_oak_log
setblock 86 286 347 minecraft:shroomlight
fill 86 286 348 86 300 348 minecraft:stripped_dark_oak_log
setblock 86 286 349 minecraft:shroomlight
fill 86 286 350 86 300 350 minecraft:stripped_dark_oak_log
setblock 87 286 338 minecraft:shroomlight
fill 87 286 339 87 300 339 minecraft:stripped_dark_oak_log
setblock 87 286 340 minecraft:shroomlight
fill 87 286 341 87 300 341 minecraft:stripped_dark_oak_log
setblock 87 286 342 minecraft:shroomlight
fill 87 286 343 87 300 343 minecraft:stripped_dark_oak_log
setblock 87 286 344 minecraft:shroomlight
fill 87 286 345 87 300 345 minecraft:stripped_dark_oak_log
setblock 87 286 346 minecraft:shroomlight
fill 87 286 347 87 300 347 minecraft:stripped_dark_oak_log
setblock 87 286 348 minecraft:shroomlight
fill 87 286 349 87 300 349 minecraft:stripped_dark_oak_log
setblock 87 286 350 minecraft:shroomlight
setblock 88 286 328 minecraft:stripped_dark_oak_log
setblock 88 286 335 minecraft:stripped_dark_oak_log
fill 88 286 338 88 300 338 minecraft:stripped_dark_oak_log
setblock 88 286 339 minecraft:shroomlight
fill 88 286 340 88 300 340 minecraft:stripped_dark_oak_log
setblock 88 286 341 minecraft:shroomlight
fill 88 286 342 88 300 342 minecraft:stripped_dark_oak_log
setblock 88 286 343 minecraft:shroomlight
fill 88 286 344 88 300 344 minecraft:stripped_dark_oak_log
setblock 88 286 345 minecraft:shroomlight
fill 88 286 346 88 300 346 minecraft:stripped_dark_oak_log
setblock 88 286 347 minecraft:shroomlight
fill 88 286 348 88 300 348 minecraft:stripped_dark_oak_log
setblock 88 286 349 minecraft:shroomlight
fill 88 286 350 88 300 350 minecraft:stripped_dark_oak_log
setblock 88 286 356 minecraft:stripped_dark_oak_log
fill 63 287 359 63 289 359 minecraft:red_concrete
fill 64 287 361 64 289 361 minecraft:red_concrete
fill 65 287 359 65 289 359 minecraft:red_concrete
fill 68 287 327 68 296 327 minecraft:dark_oak_planks
fill 74 287 359 74 288 359 minecraft:stripped_dark_oak_log
fill 74 287 361 74 288 361 minecraft:stripped_dark_oak_log
fill 74 287 363 74 288 363 minecraft:stripped_dark_oak_log
fill 75 287 358 75 288 358 minecraft:stripped_dark_oak_log
fill 75 287 360 75 288 360 minecraft:stripped_dark_oak_log
fill 75 287 362 75 288 362 minecraft:stripped_dark_oak_log
fill 76 287 359 76 288 359 minecraft:stripped_dark_oak_log
fill 76 287 361 76 288 361 minecraft:stripped_dark_oak_log
fill 76 287 363 76 288 363 minecraft:stripped_dark_oak_log
fill 77 287 358 77 288 358 minecraft:stripped_dark_oak_log
fill 77 287 360 77 288 360 minecraft:stripped_dark_oak_log
fill 77 287 362 77 288 362 minecraft:stripped_dark_oak_log
fill 78 287 359 78 288 359 minecraft:stripped_dark_oak_log
fill 78 287 361 78 288 361 minecraft:stripped_dark_oak_log
fill 78 287 363 78 288 363 minecraft:stripped_dark_oak_log
fill 79 287 353 80 287 354 minecraft:cherry_leaves[persistent=true]
fill 79 287 358 79 288 358 minecraft:stripped_dark_oak_log
fill 79 287 360 79 288 360 minecraft:stripped_dark_oak_log
fill 79 287 362 79 288 362 minecraft:stripped_dark_oak_log
fill 80 287 339 80 288 339 minecraft:stripped_dark_oak_log
fill 80 287 341 80 288 341 minecraft:stripped_dark_oak_log
fill 80 287 343 80 288 343 minecraft:stripped_dark_oak_log
fill 80 287 345 80 288 345 minecraft:stripped_dark_oak_log
fill 80 287 347 80 288 347 minecraft:stripped_dark_oak_log
fill 80 287 349 80 288 349 minecraft:stripped_dark_oak_log
fill 80 287 359 80 288 359 minecraft:stripped_dark_oak_log
fill 80 287 361 80 288 361 minecraft:stripped_dark_oak_log
fill 80 287 363 80 288 363 minecraft:stripped_dark_oak_log
fill 81 287 338 81 288 338 minecraft:stripped_dark_oak_log
fill 81 287 340 81 288 340 minecraft:stripped_dark_oak_log
fill 81 287 342 81 288 342 minecraft:stripped_dark_oak_log
fill 81 287 344 81 288 344 minecraft:stripped_dark_oak_log
fill 81 287 346 81 288 346 minecraft:stripped_dark_oak_log
fill 81 287 348 81 288 348 minecraft:stripped_dark_oak_log
fill 81 287 350 81 288 350 minecraft:stripped_dark_oak_log
fill 81 287 358 81 288 358 minecraft:stripped_dark_oak_log
fill 81 287 360 81 288 360 minecraft:stripped_dark_oak_log
fill 81 287 362 81 288 362 minecraft:stripped_dark_oak_log
fill 82 287 339 82 288 339 minecraft:stripped_dark_oak_log
fill 82 287 341 82 288 341 minecraft:stripped_dark_oak_log
fill 82 287 343 82 288 343 minecraft:stripped_dark_oak_log
fill 82 287 345 82 288 345 minecraft:stripped_dark_oak_log
fill 82 287 347 82 288 347 minecraft:stripped_dark_oak_log
fill 82 287 349 82 288 349 minecraft:stripped_dark_oak_log
fill 82 287 359 82 288 359 minecraft:stripped_dark_oak_log
fill 82 287 361 82 288 361 minecraft:stripped_dark_oak_log
fill 82 287 363 82 288 363 minecraft:stripped_dark_oak_log
fill 83 287 338 83 288 338 minecraft:stripped_dark_oak_log
fill 83 287 340 83 288 340 minecraft:stripped_dark_oak_log
fill 83 287 342 83 288 342 minecraft:stripped_dark_oak_log
fill 83 287 344 83 288 344 minecraft:stripped_dark_oak_log
fill 83 287 346 83 288 346 minecraft:stripped_dark_oak_log
fill 83 287 348 83 288 348 minecraft:stripped_dark_oak_log
fill 83 287 350 83 288 350 minecraft:stripped_dark_oak_log
fill 83 287 358 83 288 358 minecraft:stripped_dark_oak_log
fill 83 287 360 83 288 360 minecraft:stripped_dark_oak_log
setblock 83 287 361 minecraft:red_concrete
fill 83 287 362 83 288 362 minecraft:stripped_dark_oak_log
fill 84 287 339 84 288 339 minecraft:stripped_dark_oak_log
fill 84 287 341 84 288 341 minecraft:stripped_dark_oak_log
fill 84 287 343 84 288 343 minecraft:stripped_dark_oak_log
fill 84 287 345 84 288 345 minecraft:stripped_dark_oak_log
fill 84 287 347 84 288 347 minecraft:stripped_dark_oak_log
fill 84 287 349 84 288 349 minecraft:stripped_dark_oak_log
fill 84 287 359 84 288 359 minecraft:stripped_dark_oak_log
fill 84 287 361 84 288 361 minecraft:stripped_dark_oak_log
fill 84 287 363 84 288 363 minecraft:stripped_dark_oak_log
fill 84 287 364 85 308 364 minecraft:dark_oak_planks
fill 85 287 338 85 288 338 minecraft:stripped_dark_oak_log
fill 85 287 340 85 288 340 minecraft:stripped_dark_oak_log
fill 85 287 342 85 288 342 minecraft:stripped_dark_oak_log
fill 85 287 344 85 288 344 minecraft:stripped_dark_oak_log
fill 85 287 346 85 288 346 minecraft:stripped_dark_oak_log
fill 85 287 348 85 288 348 minecraft:stripped_dark_oak_log
fill 85 287 350 85 288 350 minecraft:stripped_dark_oak_log
fill 86 287 339 86 288 339 minecraft:stripped_dark_oak_log
fill 86 287 341 86 288 341 minecraft:stripped_dark_oak_log
fill 86 287 343 86 288 343 minecraft:stripped_dark_oak_log
fill 86 287 345 86 288 345 minecraft:stripped_dark_oak_log
fill 86 287 347 86 288 347 minecraft:stripped_dark_oak_log
fill 86 287 349 86 288 349 minecraft:stripped_dark_oak_log
setblock 86 287 364 minecraft:red_concrete
fill 87 287 338 87 288 338 minecraft:stripped_dark_oak_log
fill 87 287 340 87 288 340 minecraft:stripped_dark_oak_log
fill 87 287 342 87 288 342 minecraft:stripped_dark_oak_log
fill 87 287 344 87 288 344 minecraft:stripped_dark_oak_log
fill 87 287 346 87 288 346 minecraft:stripped_dark_oak_log
fill 87 287 348 87 288 348 minecraft:stripped_dark_oak_log
fill 87 287 350 87 288 350 minecraft:stripped_dark_oak_log
fill 88 287 339 88 288 339 minecraft:stripped_dark_oak_log
fill 88 287 341 88 288 341 minecraft:stripped_dark_oak_log
fill 88 287 343 88 288 343 minecraft:stripped_dark_oak_log
fill 88 287 345 88 288 345 minecraft:stripped_dark_oak_log
fill 88 287 347 88 288 347 minecraft:stripped_dark_oak_log
fill 88 287 349 88 288 349 minecraft:stripped_dark_oak_log
setblock 48 288 329 minecraft:stripped_dark_oak_log
setblock 48 288 336 minecraft:stripped_dark_oak_log
setblock 48 288 343 minecraft:stripped_dark_oak_log
setblock 48 288 350 minecraft:stripped_dark_oak_log
setblock 48 288 357 minecraft:stripped_dark_oak_log
setblock 49 288 323 minecraft:stripped_dark_oak_log
setblock 49 288 357 minecraft:red_concrete
setblock 49 288 363 minecraft:stripped_dark_oak_log
setblock 50 288 325 minecraft:light[level=12]
setblock 50 288 332 minecraft:light[level=12]
setblock 50 288 339 minecraft:light[level=12]
setblock 50 288 346 minecraft:light[level=12]
setblock 50 288 353 minecraft:light[level=12]
setblock 50 288 360 minecraft:light[level=12]
setblock 56 288 323 minecraft:stripped_dark_oak_log
setblock 56 288 363 minecraft:stripped_dark_oak_log
setblock 57 288 325 minecraft:light[level=12]
setblock 57 288 332 minecraft:light[level=12]
setblock 57 288 339 minecraft:light[level=12]
setblock 57 288 346 minecraft:light[level=12]
setblock 57 288 353 minecraft:light[level=12]
setblock 57 288 360 minecraft:light[level=12]
setblock 63 288 323 minecraft:stripped_dark_oak_log
fill 63 288 361 63 289 361 minecraft:red_concrete
setblock 63 288 363 minecraft:stripped_dark_oak_log
setblock 64 288 325 minecraft:light[level=12]
setblock 64 288 332 minecraft:light[level=12]
setblock 64 288 339 minecraft:light[level=12]
setblock 64 288 346 minecraft:light[level=12]
setblock 64 288 353 minecraft:light[level=12]
fill 64 288 358 64 289 358 minecraft:red_concrete
fill 65 288 361 65 289 361 minecraft:red_concrete
fill 67 288 327 67 296 327 minecraft:dark_oak_planks
fill 68 288 326 68 296 326 minecraft:dark_oak_planks
setblock 70 288 323 minecraft:stripped_dark_oak_log
fill 70 288 363 73 288 363 minecraft:stripped_dark_oak_log
setblock 71 288 325 minecraft:light[level=12]
setblock 71 288 332 minecraft:light[level=12]
setblock 71 288 339 minecraft:light[level=12]
setblock 71 288 346 minecraft:light[level=12]
setblock 71 288 353 minecraft:light[level=12]
setblock 71 288 360 minecraft:light[level=12]
fill 71 288 362 73 289 362 minecraft:stripped_dark_oak_log
fill 72 288 323 73 290 323 minecraft:stripped_dark_oak_log
setblock 77 288 323 minecraft:stripped_dark_oak_log
setblock 78 288 325 minecraft:light[level=12]
setblock 78 288 332 minecraft:light[level=12]
setblock 78 288 339 minecraft:light[level=12]
setblock 78 288 353 minecraft:light[level=12]
fill 83 288 361 83 289 361 minecraft:shroomlight
setblock 84 288 323 minecraft:stripped_dark_oak_log
setblock 85 288 325 minecraft:light[level=12]
setblock 85 288 332 minecraft:light[level=12]
setblock 85 288 353 minecraft:light[level=12]
setblock 85 288 360 minecraft:light[level=12]
fill 86 288 364 86 291 364 minecraft:dark_oak_planks
setblock 88 288 326 minecraft:stripped_dark_oak_log
setblock 88 288 333 minecraft:stripped_dark_oak_log
setblock 88 288 354 minecraft:stripped_dark_oak_log
setblock 88 288 361 minecraft:stripped_dark_oak_log
fill 48 289 323 48 290 323 minecraft:stripped_dark_oak_log
fill 48 289 330 48 290 330 minecraft:stripped_dark_oak_log
fill 48 289 337 48 290 337 minecraft:stripped_dark_oak_log
fill 48 289 344 48 290 344 minecraft:stripped_dark_oak_log
fill 48 289 351 48 290 351 minecraft:stripped_dark_oak_log
fill 48 289 358 48 290 358 minecraft:stripped_dark_oak_log
fill 49 289 357 49 290 357 minecraft:shroomlight
fill 50 289 363 50 290 363 minecraft:stripped_dark_oak_log
fill 55 289 323 55 290 323 minecraft:stripped_dark_oak_log
fill 57 289 363 57 290 363 minecraft:stripped_dark_oak_log
fill 62 289 323 62 290 323 minecraft:stripped_dark_oak_log
fill 62 289 359 62 289 360 minecraft:red_concrete
setblock 63 289 358 minecraft:red_concrete
setblock 64 289 362 minecraft:red_concrete
fill 64 289 363 64 300 363 minecraft:stripped_dark_oak_log
setblock 65 289 358 minecraft:red_concrete
fill 66 289 359 66 289 360 minecraft:red_concrete
fill 67 289 326 67 296 326 minecraft:dark_oak_planks
fill 69 289 323 69 290 323 minecraft:stripped_dark_oak_log
fill 71 289 324 73 290 324 minecraft:stripped_dark_oak_log
fill 71 289 361 73 290 361 minecraft:stripped_dark_oak_log
fill 71 289 363 73 290 363 minecraft:stripped_dark_oak_log
fill 72 289 325 72 292 325 minecraft:stripped_dark_oak_log
fill 72 289 360 72 292 360 minecraft:stripped_dark_oak_log
setblock 74 289 359 minecraft:shroomlight
setblock 74 289 361 minecraft:shroomlight
setblock 74 289 363 minecraft:shroomlight
setblock 75 289 358 minecraft:shroomlight
setblock 75 289 360 minecraft:shroomlight
setblock 75 289 362 minecraft:shroomlight
fill 76 289 323 76 290 323 minecraft:stripped_dark_oak_log
setblock 76 289 359 minecraft:shroomlight
setblock 76 289 361 minecraft:shroomlight
setblock 76 289 363 minecraft:shroomlight
setblock 77 289 358 minecraft:shroomlight
setblock 77 289 360 minecraft:shroomlight
setblock 77 289 362 minecraft:shroomlight
setblock 78 289 359 minecraft:shroomlight
setblock 78 289 361 minecraft:shroomlight
setblock 78 289 363 minecraft:shroomlight
setblock 79 289 358 minecraft:shroomlight
setblock 79 289 360 minecraft:shroomlight
setblock 79 289 362 minecraft:shroomlight
setblock 80 289 339 minecraft:shroomlight
setblock 80 289 341 minecraft:shroomlight
setblock 80 289 343 minecraft:shroomlight
setblock 80 289 345 minecraft:shroomlight
setblock 80 289 347 minecraft:shroomlight
setblock 80 289 349 minecraft:shroomlight
setblock 80 289 359 minecraft:shroomlight
setblock 80 289 361 minecraft:shroomlight
setblock 80 289 363 minecraft:shroomlight
setblock 81 289 338 minecraft:shroomlight
setblock 81 289 340 minecraft:shroomlight
setblock 81 289 342 minecraft:shroomlight
setblock 81 289 344 minecraft:shroomlight
setblock 81 289 346 minecraft:shroomlight
setblock 81 289 348 minecraft:shroomlight
setblock 81 289 350 minecraft:shroomlight
setblock 81 289 358 minecraft:shroomlight
setblock 81 289 360 minecraft:shroomlight
setblock 81 289 362 minecraft:shroomlight
setblock 82 289 339 minecraft:shroomlight
setblock 82 289 341 minecraft:shroomlight
setblock 82 289 343 minecraft:shroomlight
setblock 82 289 345 minecraft:shroomlight
setblock 82 289 347 minecraft:shroomlight
setblock 82 289 349 minecraft:shroomlight
setblock 82 289 359 minecraft:shroomlight
setblock 82 289 361 minecraft:shroomlight
setblock 82 289 363 minecraft:shroomlight
fill 83 289 323 83 290 323 minecraft:stripped_dark_oak_log
setblock 83 289 338 minecraft:shroomlight
setblock 83 289 340 minecraft:shroomlight
setblock 83 289 342 minecraft:shroomlight
setblock 83 289 344 minecraft:shroomlight
setblock 83 289 346 minecraft:shroomlight
setblock 83 289 348 minecraft:shroomlight
setblock 83 289 350 minecraft:shroomlight
setblock 83 289 358 minecraft:shroomlight
setblock 83 289 360 minecraft:shroomlight
setblock 83 289 362 minecraft:shroomlight
setblock 84 289 339 minecraft:shroomlight
setblock 84 289 341 minecraft:shroomlight
setblock 84 289 343 minecraft:shroomlight
setblock 84 289 345 minecraft:shroomlight
setblock 84 289 347 minecraft:shroomlight
setblock 84 289 349 minecraft:shroomlight
setblock 84 289 359 minecraft:shroomlight
setblock 84 289 361 minecraft:shroomlight
setblock 84 289 363 minecraft:shroomlight
setblock 85 289 338 minecraft:shroomlight
setblock 85 289 340 minecraft:shroomlight
setblock 85 289 342 minecraft:shroomlight
setblock 85 289 344 minecraft:shroomlight
setblock 85 289 346 minecraft:shroomlight
setblock 85 289 348 minecraft:shroomlight
setblock 85 289 350 minecraft:shroomlight
fill 85 289 363 85 290 363 minecraft:stripped_dark_oak_log
setblock 86 289 339 minecraft:shroomlight
setblock 86 289 341 minecraft:shroomlight
setblock 86 289 343 minecraft:shroomlight
setblock 86 289 345 minecraft:shroomlight
setblock 86 289 347 minecraft:shroomlight
setblock 86 289 349 minecraft:shroomlight
setblock 87 289 338 minecraft:shroomlight
setblock 87 289 340 minecraft:shroomlight
setblock 87 289 342 minecraft:shroomlight
setblock 87 289 344 minecraft:shroomlight
setblock 87 289 346 minecraft:shroomlight
setblock 87 289 348 minecraft:shroomlight
setblock 87 289 350 minecraft:shroomlight
fill 88 289 325 88 290 325 minecraft:stripped_dark_oak_log
fill 88 289 332 88 290 332 minecraft:stripped_dark_oak_log
setblock 88 289 339 minecraft:shroomlight
setblock 88 289 341 minecraft:shroomlight
setblock 88 289 343 minecraft:shroomlight
setblock 88 289 345 minecraft:shroomlight
setblock 88 289 347 minecraft:shroomlight
setblock 88 289 349 minecraft:shroomlight
fill 88 289 353 88 290 353 minecraft:stripped_dark_oak_log
fill 88 289 360 88 290 360 minecraft:stripped_dark_oak_log
fill 48 290 324 48 290 327 minecraft:stripped_dark_oak_log
setblock 48 290 329 minecraft:stripped_dark_oak_log
fill 48 290 331 48 290 334 minecraft:stripped_dark_oak_log
setblock 48 290 336 minecraft:stripped_dark_oak_log
fill 48 290 338 48 290 341 minecraft:stripped_dark_oak_log
setblock 48 290 343 minecraft:stripped_dark_oak_log
fill 48 290 345 48 290 348 minecraft:stripped_dark_oak_log
setblock 48 290 350 minecraft:stripped_dark_oak_log
fill 48 290 352 48 290 355 minecraft:stripped_dark_oak_log
setblock 48 290 357 minecraft:stripped_dark_oak_log
fill 48 290 359 48 290 362 minecraft:stripped_dark_oak_log
setblock 49 290 323 minecraft:stripped_dark_oak_log
setblock 49 290 363 minecraft:stripped_dark_oak_log
setblock 50 290 325 minecraft:light[level=15]
setblock 50 290 333 minecraft:light[level=15]
setblock 50 290 341 minecraft:light[level=15]
setblock 50 290 349 minecraft:light[level=15]
setblock 50 290 357 minecraft:light[level=15]
fill 51 290 323 54 290 323 minecraft:stripped_dark_oak_log
fill 51 290 363 54 290 363 minecraft:stripped_dark_oak_log
setblock 56 290 323 minecraft:stripped_dark_oak_log
setblock 56 290 363 minecraft:stripped_dark_oak_log
fill 58 290 323 61 290 323 minecraft:stripped_dark_oak_log
setblock 58 290 325 minecraft:light[level=15]
setblock 58 290 333 minecraft:light[level=15]
setblock 58 290 341 minecraft:light[level=15]
setblock 58 290 349 minecraft:light[level=15]
setblock 58 290 357 minecraft:light[level=15]
fill 58 290 363 61 290 363 minecraft:stripped_dark_oak_log
fill 59 290 357 69 300 362 minecraft:stripped_dark_oak_log
setblock 63 290 323 minecraft:stripped_dark_oak_log
fill 63 290 363 63 300 363 minecraft:stripped_dark_oak_log
fill 65 290 323 68 290 323 minecraft:stripped_dark_oak_log
fill 65 290 363 68 300 363 minecraft:stripped_dark_oak_log
setblock 66 290 325 minecraft:light[level=15]
fill 66 290 327 66 296 327 minecraft:dark_oak_planks
setblock 66 290 333 minecraft:light[level=15]
setblock 66 290 341 minecraft:light[level=15]
setblock 66 290 349 minecraft:light[level=15]
fill 67 290 328 68 296 328 minecraft:dark_oak_planks
fill 68 290 325 68 296 325 minecraft:dark_oak_planks
fill 69 290 326 69 296 327 minecraft:dark_oak_planks
setblock 70 290 323 minecraft:stripped_dark_oak_log
setblock 70 290 363 minecraft:stripped_dark_oak_log
fill 71 290 325 71 291 325 minecraft:stripped_dark_oak_log
fill 71 290 360 71 291 360 minecraft:stripped_dark_oak_log
fill 72 290 326 72 292 326 minecraft:stripped_dark_oak_log
fill 72 290 359 72 292 359 minecraft:stripped_dark_oak_log
setblock 72 290 362 minecraft:stripped_dark_oak_log
fill 73 290 325 73 291 325 minecraft:stripped_dark_oak_log
fill 73 290 360 73 291 360 minecraft:stripped_dark_oak_log
fill 74 290 323 75 290 323 minecraft:stripped_dark_oak_log
setblock 74 290 325 minecraft:light[level=15]
setblock 74 290 333 minecraft:light[level=15]
setblock 74 290 341 minecraft:light[level=15]
setblock 74 290 349 minecraft:light[level=15]
setblock 74 290 357 minecraft:light[level=15]
fill 74 290 359 74 291 359 minecraft:stripped_dark_oak_log
fill 74 290 361 74 291 361 minecraft:stripped_dark_oak_log
fill 74 290 363 74 291 363 minecraft:stripped_dark_oak_log
fill 75 290 358 75 291 358 minecraft:stripped_dark_oak_log
fill 75 290 360 75 291 360 minecraft:stripped_dark_oak_log
fill 75 290 362 75 291 362 minecraft:stripped_dark_oak_log
fill 76 290 359 76 291 359 minecraft:stripped_dark_oak_log
fill 76 290 361 76 291 361 minecraft:stripped_dark_oak_log
fill 76 290 363 76 291 363 minecraft:stripped_dark_oak_log
setblock 77 290 323 minecraft:stripped_dark_oak_log
fill 77 290 358 77 291 358 minecraft:stripped_dark_oak_log
fill 77 290 360 77 291 360 minecraft:stripped_dark_oak_log
fill 77 290 362 77 291 362 minecraft:stripped_dark_oak_log
fill 78 290 359 78 291 359 minecraft:stripped_dark_oak_log
fill 78 290 361 78 291 361 minecraft:stripped_dark_oak_log
fill 78 290 363 78 291 363 minecraft:stripped_dark_oak_log
fill 79 290 323 82 290 323 minecraft:stripped_dark_oak_log
fill 79 290 358 79 291 358 minecraft:stripped_dark_oak_log
fill 79 290 360 79 291 360 minecraft:stripped_dark_oak_log
fill 79 290 362 79 291 362 minecraft:stripped_dark_oak_log
fill 80 290 339 80 291 339 minecraft:stripped_dark_oak_log
fill 80 290 341 80 291 341 minecraft:stripped_dark_oak_log
fill 80 290 343 80 291 343 minecraft:stripped_dark_oak_log
fill 80 290 345 80 291 345 minecraft:stripped_dark_oak_log
fill 80 290 347 80 291 347 minecraft:stripped_dark_oak_log
fill 80 290 349 80 291 349 minecraft:stripped_dark_oak_log
fill 80 290 359 80 291 359 minecraft:stripped_dark_oak_log
fill 80 290 361 80 291 361 minecraft:stripped_dark_oak_log
fill 80 290 363 80 291 363 minecraft:stripped_dark_oak_log
fill 81 290 338 81 291 338 minecraft:stripped_dark_oak_log
fill 81 290 340 81 291 340 minecraft:stripped_dark_oak_log
fill 81 290 342 81 291 342 minecraft:stripped_dark_oak_log
fill 81 290 344 81 291 344 minecraft:stripped_dark_oak_log
fill 81 290 346 81 291 346 minecraft:stripped_dark_oak_log
fill 81 290 348 81 291 348 minecraft:stripped_dark_oak_log
fill 81 290 350 81 291 350 minecraft:stripped_dark_oak_log
fill 81 290 358 81 291 358 minecraft:stripped_dark_oak_log
fill 81 290 360 81 291 360 minecraft:stripped_dark_oak_log
fill 81 290 362 81 291 362 minecraft:stripped_dark_oak_log
setblock 82 290 325 minecraft:light[level=15]
setblock 82 290 333 minecraft:light[level=15]
fill 82 290 339 82 291 339 minecraft:stripped_dark_oak_log
fill 82 290 341 82 291 341 minecraft:stripped_dark_oak_log
fill 82 290 343 82 291 343 minecraft:stripped_dark_oak_log
fill 82 290 345 82 291 345 minecraft:stripped_dark_oak_log
fill 82 290 347 82 291 347 minecraft:stripped_dark_oak_log
fill 82 290 349 82 291 349 minecraft:stripped_dark_oak_log
setblock 82 290 357 minecraft:light[level=15]
fill 82 290 359 82 291 359 minecraft:stripped_dark_oak_log
fill 82 290 361 82 291 361 minecraft:stripped_dark_oak_log
fill 82 290 363 82 291 363 minecraft:stripped_dark_oak_log
fill 83 290 338 83 291 338 minecraft:stripped_dark_oak_log
fill 83 290 340 83 291 340 minecraft:stripped_dark_oak_log
fill 83 290 342 83 291 342 minecraft:stripped_dark_oak_log
fill 83 290 344 83 291 344 minecraft:stripped_dark_oak_log
fill 83 290 346 83 291 346 minecraft:stripped_dark_oak_log
fill 83 290 348 83 291 348 minecraft:stripped_dark_oak_log
fill 83 290 350 83 291 350 minecraft:stripped_dark_oak_log
fill 83 290 358 83 291 358 minecraft:stripped_dark_oak_log
fill 83 290 360 83 291 360 minecraft:stripped_dark_oak_log
setblock 83 290 361 minecraft:red_concrete
fill 83 290 362 83 291 362 minecraft:stripped_dark_oak_log
setblock 84 290 323 minecraft:stripped_dark_oak_log
fill 84 290 339 84 291 339 minecraft:stripped_dark_oak_log
fill 84 290 341 84 291 341 minecraft:stripped_dark_oak_log
fill 84 290 343 84 291 343 minecraft:stripped_dark_oak_log
fill 84 290 345 84 291 345 minecraft:stripped_dark_oak_log
fill 84 290 347 84 291 347 minecraft:stripped_dark_oak_log
fill 84 290 349 84 291 349 minecraft:stripped_dark_oak_log
fill 84 290 359 84 291 359 minecraft:stripped_dark_oak_log
fill 84 290 361 84 291 361 minecraft:stripped_dark_oak_log
fill 84 290 363 84 291 363 minecraft:stripped_dark_oak_log
fill 85 290 338 85 291 338 minecraft:stripped_dark_oak_log
fill 85 290 340 85 291 340 minecraft:stripped_dark_oak_log
fill 85 290 342 85 291 342 minecraft:stripped_dark_oak_log
fill 85 290 344 85 291 344 minecraft:stripped_dark_oak_log
fill 85 290 346 85 291 346 minecraft:stripped_dark_oak_log
fill 85 290 348 85 291 348 minecraft:stripped_dark_oak_log
fill 85 290 350 85 291 350 minecraft:stripped_dark_oak_log
fill 86 290 323 88 290 323 minecraft:stripped_dark_oak_log
fill 86 290 339 86 291 339 minecraft:stripped_dark_oak_log
fill 86 290 341 86 291 341 minecraft:stripped_dark_oak_log
fill 86 290 343 86 291 343 minecraft:stripped_dark_oak_log
fill 86 290 345 86 291 345 minecraft:stripped_dark_oak_log
fill 86 290 347 86 291 347 minecraft:stripped_dark_oak_log
fill 86 290 349 86 291 349 minecraft:stripped_dark_oak_log
fill 86 290 363 88 290 363 minecraft:stripped_dark_oak_log
fill 87 290 338 87 291 338 minecraft:stripped_dark_oak_log
fill 87 290 340 87 291 340 minecraft:stripped_dark_oak_log
fill 87 290 342 87 291 342 minecraft:stripped_dark_oak_log
fill 87 290 344 87 291 344 minecraft:stripped_dark_oak_log
fill 87 290 346 87 291 346 minecraft:stripped_dark_oak_log
fill 87 290 348 87 291 348 minecraft:stripped_dark_oak_log
fill 87 290 350 87 291 350 minecraft:stripped_dark_oak_log
setblock 88 290 324 minecraft:stripped_dark_oak_log
setblock 88 290 326 minecraft:stripped_dark_oak_log
fill 88 290 328 88 290 331 minecraft:stripped_dark_oak_log
setblock 88 290 333 minecraft:stripped_dark_oak_log
fill 88 290 335 88 290 337 minecraft:stripped_dark_oak_log
fill 88 290 339 88 291 339 minecraft:stripped_dark_oak_log
fill 88 290 341 88 291 341 minecraft:stripped_dark_oak_log
fill 88 290 343 88 291 343 minecraft:stripped_dark_oak_log
fill 88 290 345 88 291 345 minecraft:stripped_dark_oak_log
fill 88 290 347 88 291 347 minecraft:stripped_dark_oak_log
fill 88 290 349 88 291 349 minecraft:stripped_dark_oak_log
setblock 88 290 352 minecraft:stripped_dark_oak_log
setblock 88 290 354 minecraft:stripped_dark_oak_log
fill 88 290 356 88 290 359 minecraft:stripped_dark_oak_log
setblock 88 290 361 minecraft:stripped_dark_oak_log
setblock 48 291 325 minecraft:stripped_dark_oak_log
setblock 48 291 332 minecraft:stripped_dark_oak_log
setblock 48 291 339 minecraft:stripped_dark_oak_log
setblock 48 291 346 minecraft:stripped_dark_oak_log
setblock 48 291 353 minecraft:stripped_dark_oak_log
setblock 48 291 360 minecraft:stripped_dark_oak_log
setblock 49 291 357 minecraft:red_concrete
setblock 52 291 363 minecraft:stripped_dark_oak_log
setblock 53 291 323 minecraft:stripped_dark_oak_log
fill 59 291 363 61 300 363 minecraft:stripped_dark_oak_log
setblock 60 291 323 minecraft:stripped_dark_oak_log
fill 66 291 326 66 296 326 minecraft:dark_oak_planks
fill 66 291 328 66 296 328 minecraft:dark_oak_planks
setblock 67 291 323 minecraft:stripped_dark_oak_log
fill 67 291 325 67 296 325 minecraft:dark_oak_planks
fill 69 291 325 69 296 325 minecraft:dark_oak_planks
fill 69 291 328 69 296 328 minecraft:dark_oak_planks
fill 71 291 326 71 292 327 minecraft:stripped_dark_oak_log
fill 71 291 358 71 292 359 minecraft:stripped_dark_oak_log
setblock 72 291 323 minecraft:red_concrete
setblock 72 291 324 minecraft:stripped_dark_oak_log
fill 72 291 327 73 292 327 minecraft:stripped_dark_oak_log
fill 72 291 358 73 292 358 minecraft:stripped_dark_oak_log
setblock 72 291 361 minecraft:stripped_dark_oak_log
setblock 72 291 362 minecraft:red_concrete
fill 73 291 326 73 292 326 minecraft:stripped_dark_oak_log
fill 73 291 359 73 292 359 minecraft:stripped_dark_oak_log
setblock 73 291 363 minecraft:stripped_dark_oak_log
setblock 74 291 323 minecraft:stripped_dark_oak_log
setblock 81 291 323 minecraft:stripped_dark_oak_log
fill 83 291 361 83 297 361 minecraft:stripped_dark_oak_log
setblock 87 291 363 minecraft:stripped_dark_oak_log
setblock 88 291 323 minecraft:stripped_dark_oak_log
setblock 88 291 330 minecraft:stripped_dark_oak_log
setblock 88 291 337 minecraft:stripped_dark_oak_log
setblock 88 291 358 minecraft:stripped_dark_oak_log
fill 47 292 357 47 308 358 minecraft:dark_oak_planks
setblock 47 292 359 minecraft:red_concrete
fill 47 292 360 47 308 360 minecraft:dark_oak_planks
setblock 48 292 326 minecraft:stripped_dark_oak_log
setblock 48 292 333 minecraft:stripped_dark_oak_log
setblock 48 292 340 minecraft:stripped_dark_oak_log
setblock 48 292 347 minecraft:stripped_dark_oak_log
setblock 48 292 354 minecraft:stripped_dark_oak_log
setblock 48 292 361 minecraft:stripped_dark_oak_log
setblock 52 292 323 minecraft:stripped_dark_oak_log
setblock 53 292 363 minecraft:stripped_dark_oak_log
setblock 59 292 323 minecraft:stripped_dark_oak_log
fill 65 292 327 65 296 327 minecraft:dark_oak_planks
setblock 66 292 323 minecraft:stripped_dark_oak_log
fill 66 292 325 66 296 325 minecraft:dark_oak_planks
fill 67 292 329 69 296 329 minecraft:dark_oak_planks
fill 68 292 324 68 296 324 minecraft:dark_oak_planks
fill 70 292 326 70 296 328 minecraft:dark_oak_planks
fill 71 292 328 73 293 328 minecraft:stripped_dark_oak_log
fill 71 292 357 73 293 357 minecraft:stripped_dark_oak_log
setblock 72 292 324 minecraft:red_concrete
fill 72 292 329 72 294 329 minecraft:stripped_dark_oak_log
fill 72 292 356 72 294 356 minecraft:stripped_dark_oak_log
setblock 72 292 361 minecraft:red_concrete
setblock 73 292 323 minecraft:stripped_dark_oak_log
setblock 74 292 359 minecraft:shroomlight
setblock 74 292 361 minecraft:shroomlight
setblock 74 292 363 minecraft:shroomlight
setblock 75 292 358 minecraft:shroomlight
setblock 75 292 360 minecraft:shroomlight
setblock 75 292 362 minecraft:shroomlight
setblock 76 292 359 minecraft:shroomlight
setblock 76 292 361 minecraft:shroomlight
setblock 76 292 363 minecraft:shroomlight
setblock 77 292 358 minecraft:shroomlight
setblock 77 292 360 minecraft:shroomlight
setblock 77 292 362 minecraft:shroomlight
setblock 78 292 359 minecraft:shroomlight
setblock 78 292 361 minecraft:shroomlight
setblock 78 292 363 minecraft:shroomlight
setblock 79 292 358 minecraft:shroomlight
setblock 79 292 360 minecraft:shroomlight
setblock 79 292 362 minecraft:shroomlight
setblock 80 292 323 minecraft:stripped_dark_oak_log
setblock 80 292 339 minecraft:shroomlight
setblock 80 292 341 minecraft:shroomlight
setblock 80 292 343 minecraft:shroomlight
setblock 80 292 345 minecraft:shroomlight
setblock 80 292 347 minecraft:shroomlight
setblock 80 292 349 minecraft:shroomlight
setblock 80 292 359 minecraft:shroomlight
setblock 80 292 361 minecraft:shroomlight
setblock 80 292 363 minecraft:shroomlight
setblock 81 292 338 minecraft:shroomlight
setblock 81 292 340 minecraft:shroomlight
setblock 81 292 342 minecraft:shroomlight
setblock 81 292 344 minecraft:shroomlight
setblock 81 292 346 minecraft:shroomlight
setblock 81 292 348 minecraft:shroomlight
setblock 81 292 350 minecraft:shroomlight
setblock 81 292 358 minecraft:shroomlight
setblock 81 292 360 minecraft:shroomlight
setblock 81 292 362 minecraft:shroomlight
setblock 82 292 339 minecraft:shroomlight
setblock 82 292 341 minecraft:shroomlight
setblock 82 292 343 minecraft:shroomlight
setblock 82 292 345 minecraft:shroomlight
setblock 82 292 347 minecraft:shroomlight
setblock 82 292 349 minecraft:shroomlight
setblock 82 292 359 minecraft:shroomlight
setblock 82 292 361 minecraft:shroomlight
setblock 82 292 363 minecraft:shroomlight
setblock 83 292 338 minecraft:shroomlight
setblock 83 292 340 minecraft:shroomlight
setblock 83 292 342 minecraft:shroomlight
setblock 83 292 344 minecraft:shroomlight
setblock 83 292 346 minecraft:shroomlight
setblock 83 292 348 minecraft:shroomlight
setblock 83 292 350 minecraft:shroomlight
setblock 83 292 358 minecraft:shroomlight
setblock 83 292 360 minecraft:shroomlight
setblock 83 292 362 minecraft:shroomlight
setblock 84 292 339 minecraft:shroomlight
setblock 84 292 341 minecraft:shroomlight
setblock 84 292 343 minecraft:shroomlight
setblock 84 292 345 minecraft:shroomlight
setblock 84 292 347 minecraft:shroomlight
setblock 84 292 349 minecraft:shroomlight
setblock 84 292 359 minecraft:shroomlight
setblock 84 292 361 minecraft:shroomlight
setblock 84 292 363 minecraft:shroomlight
setblock 85 292 338 minecraft:shroomlight
setblock 85 292 340 minecraft:shroomlight
setblock 85 292 342 minecraft:shroomlight
setblock 85 292 344 minecraft:shroomlight
setblock 85 292 346 minecraft:shroomlight
setblock 85 292 348 minecraft:shroomlight
setblock 85 292 350 minecraft:shroomlight
setblock 86 292 339 minecraft:shroomlight
setblock 86 292 341 minecraft:shroomlight
setblock 86 292 343 minecraft:shroomlight
setblock 86 292 345 minecraft:shroomlight
setblock 86 292 347 minecraft:shroomlight
setblock 86 292 349 minecraft:shroomlight
setblock 86 292 364 minecraft:red_concrete
setblock 87 292 323 minecraft:stripped_dark_oak_log
setblock 87 292 338 minecraft:shroomlight
setblock 87 292 340 minecraft:shroomlight
setblock 87 292 342 minecraft:shroomlight
setblock 87 292 344 minecraft:shroomlight
setblock 87 292 346 minecraft:shroomlight
setblock 87 292 348 minecraft:shroomlight
setblock 87 292 350 minecraft:shroomlight
setblock 88 292 329 minecraft:stripped_dark_oak_log
setblock 88 292 336 minecraft:stripped_dark_oak_log
setblock 88 292 339 minecraft:shroomlight
setblock 88 292 341 minecraft:shroomlight
setblock 88 292 343 minecraft:shroomlight
setblock 88 292 345 minecraft:shroomlight
setblock 88 292 347 minecraft:shroomlight
setblock 88 292 349 minecraft:shroomlight
setblock 88 292 357 minecraft:stripped_dark_oak_log
setblock 88 292 363 minecraft:stripped_dark_oak_log
fill 47 293 359 47 308 359 minecraft:dark_oak_planks
setblock 48 293 327 minecraft:stripped_dark_oak_log
setblock 48 293 334 minecraft:stripped_dark_oak_log
setblock 48 293 341 minecraft:stripped_dark_oak_log
setblock 48 293 348 minecraft:stripped_dark_oak_log
setblock 48 293 355 minecraft:stripped_dark_oak_log
setblock 48 293 362 minecraft:stripped_dark_oak_log
setblock 51 293 323 minecraft:stripped_dark_oak_log
setblock 54 293 363 minecraft:stripped_dark_oak_log
setblock 58 293 323 minecraft:stripped_dark_oak_log
setblock 65 293 323 minecraft:stripped_dark_oak_log
fill 65 293 325 65 296 326 minecraft:dark_oak_planks
fill 65 293 328 65 296 328 minecraft:dark_oak_planks
fill 66 293 324 67 296 324 minecraft:dark_oak_planks
fill 66 293 329 66 296 329 minecraft:dark_oak_planks
fill 69 293 324 69 296 324 minecraft:dark_oak_planks
fill 70 293 325 70 296 325 minecraft:dark_oak_planks
fill 70 293 329 70 296 329 minecraft:dark_oak_planks
fill 71 293 329 71 294 329 minecraft:stripped_dark_oak_log
fill 71 293 356 71 294 356 minecraft:stripped_dark_oak_log
setblock 72 293 323 minecraft:stripped_dark_oak_log
setblock 72 293 326 minecraft:red_concrete
setblock 72 293 327 minecraft:stripped_dark_oak_log
fill 72 293 330 72 295 330 minecraft:stripped_dark_oak_log
fill 72 293 355 72 295 355 minecraft:stripped_dark_oak_log
setblock 72 293 358 minecraft:stripped_dark_oak_log
setblock 72 293 359 minecraft:red_concrete
fill 73 293 329 73 294 329 minecraft:stripped_dark_oak_log
fill 73 293 356 73 294 356 minecraft:stripped_dark_oak_log
fill 74 293 359 74 294 359 minecraft:stripped_dark_oak_log
fill 74 293 361 74 294 361 minecraft:stripped_dark_oak_log
fill 74 293 363 74 294 363 minecraft:stripped_dark_oak_log
fill 75 293 358 75 294 358 minecraft:stripped_dark_oak_log
fill 75 293 360 75 294 360 minecraft:stripped_dark_oak_log
fill 75 293 362 75 294 362 minecraft:stripped_dark_oak_log
fill 76 293 359 76 294 359 minecraft:stripped_dark_oak_log
fill 76 293 361 76 294 361 minecraft:stripped_dark_oak_log
fill 76 293 363 76 294 363 minecraft:stripped_dark_oak_log
fill 77 293 358 77 294 358 minecraft:stripped_dark_oak_log
fill 77 293 360 77 294 360 minecraft:stripped_dark_oak_log
fill 77 293 362 77 294 362 minecraft:stripped_dark_oak_log
fill 78 293 359 78 294 359 minecraft:stripped_dark_oak_log
fill 78 293 361 78 294 361 minecraft:stripped_dark_oak_log
fill 78 293 363 78 294 363 minecraft:stripped_dark_oak_log
setblock 79 293 323 minecraft:stripped_dark_oak_log
fill 79 293 358 79 294 358 minecraft:stripped_dark_oak_log
fill 79 293 360 79 294 360 minecraft:stripped_dark_oak_log
fill 79 293 362 79 294 362 minecraft:stripped_dark_oak_log
fill 80 293 339 80 294 339 minecraft:stripped_dark_oak_log
fill 80 293 341 80 294 341 minecraft:stripped_dark_oak_log
fill 80 293 343 80 294 343 minecraft:stripped_dark_oak_log
fill 80 293 345 80 294 345 minecraft:stripped_dark_oak_log
fill 80 293 347 80 294 347 minecraft:stripped_dark_oak_log
fill 80 293 349 80 294 349 minecraft:stripped_dark_oak_log
fill 80 293 359 80 294 359 minecraft:stripped_dark_oak_log
fill 80 293 361 80 294 361 minecraft:stripped_dark_oak_log
fill 80 293 363 80 294 363 minecraft:stripped_dark_oak_log
fill 81 293 338 81 294 338 minecraft:stripped_dark_oak_log
fill 81 293 340 81 294 340 minecraft:stripped_dark_oak_log
fill 81 293 342 81 294 342 minecraft:stripped_dark_oak_log
fill 81 293 344 81 294 344 minecraft:stripped_dark_oak_log
fill 81 293 346 81 294 346 minecraft:stripped_dark_oak_log
fill 81 293 348 81 294 348 minecraft:stripped_dark_oak_log
fill 81 293 350 81 294 350 minecraft:stripped_dark_oak_log
fill 81 293 358 81 294 358 minecraft:stripped_dark_oak_log
fill 81 293 360 81 294 360 minecraft:stripped_dark_oak_log
fill 81 293 362 81 294 362 minecraft:stripped_dark_oak_log
fill 82 293 339 82 294 339 minecraft:stripped_dark_oak_log
fill 82 293 341 82 294 341 minecraft:stripped_dark_oak_log
fill 82 293 343 82 294 343 minecraft:stripped_dark_oak_log
fill 82 293 345 82 294 345 minecraft:stripped_dark_oak_log
fill 82 293 347 82 294 347 minecraft:stripped_dark_oak_log
fill 82 293 349 82 294 349 minecraft:stripped_dark_oak_log
fill 82 293 359 82 294 359 minecraft:stripped_dark_oak_log
fill 82 293 361 82 294 361 minecraft:stripped_dark_oak_log
fill 82 293 363 82 294 363 minecraft:stripped_dark_oak_log
fill 83 293 338 83 294 338 minecraft:stripped_dark_oak_log
fill 83 293 340 83 294 340 minecraft:stripped_dark_oak_log
fill 83 293 342 83 294 342 minecraft:stripped_dark_oak_log
fill 83 293 344 83 294 344 minecraft:stripped_dark_oak_log
fill 83 293 346 83 294 346 minecraft:stripped_dark_oak_log
fill 83 293 348 83 294 348 minecraft:stripped_dark_oak_log
fill 83 293 350 83 294 350 minecraft:stripped_dark_oak_log
fill 83 293 358 83 294 358 minecraft:stripped_dark_oak_log
fill 83 293 360 83 294 360 minecraft:stripped_dark_oak_log
fill 83 293 362 83 294 362 minecraft:stripped_dark_oak_log
fill 84 293 339 84 294 339 minecraft:stripped_dark_oak_log
fill 84 293 341 84 294 341 minecraft:stripped_dark_oak_log
fill 84 293 343 84 294 343 minecraft:stripped_dark_oak_log
fill 84 293 345 84 294 345 minecraft:stripped_dark_oak_log
schedule function dropper:buildpart/73_6 1t
