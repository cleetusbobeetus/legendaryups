fill 122 248 549 122 250 549 minecraft:blackstone
setblock 124 248 511 minecraft:smooth_basalt
setblock 124 248 551 minecraft:smooth_basalt
fill 125 248 511 125 249 511 minecraft:blackstone
setblock 125 248 550 minecraft:smooth_basalt
fill 125 248 551 128 248 551 minecraft:blackstone
fill 126 248 550 129 248 550 minecraft:blackstone
setblock 129 248 521 minecraft:light[level=12]
setblock 129 248 529 minecraft:light[level=12]
setblock 129 248 537 minecraft:light[level=12]
setblock 129 248 545 minecraft:light[level=12]
setblock 129 248 551 minecraft:smooth_basalt
setblock 130 248 550 minecraft:smooth_basalt
fill 130 248 551 130 251 551 minecraft:blackstone
fill 131 248 550 131 251 550 minecraft:blackstone
fill 132 248 549 132 251 549 minecraft:blackstone
setblock 133 248 547 minecraft:smooth_basalt
fill 133 248 548 133 251 548 minecraft:blackstone
setblock 134 248 511 minecraft:smooth_basalt
setblock 134 248 525 minecraft:blackstone
setblock 134 248 526 minecraft:smooth_basalt
fill 134 248 527 134 251 527 minecraft:blackstone
fill 134 248 529 134 248 530 minecraft:blackstone
setblock 134 248 541 minecraft:smooth_basalt
fill 134 248 542 134 251 542 minecraft:blackstone
setblock 134 248 546 minecraft:smooth_basalt
fill 134 248 547 134 251 547 minecraft:blackstone
setblock 134 248 551 minecraft:smooth_basalt
fill 135 248 511 135 251 511 minecraft:blackstone
setblock 135 248 521 minecraft:blackstone
setblock 135 248 525 minecraft:smooth_basalt
fill 135 248 526 135 251 526 minecraft:blackstone
setblock 135 248 530 minecraft:smooth_basalt
fill 135 248 531 135 251 531 minecraft:blackstone
setblock 135 248 535 minecraft:smooth_basalt
fill 135 248 536 135 251 536 minecraft:blackstone
setblock 135 248 540 minecraft:smooth_basalt
fill 135 248 541 135 251 541 minecraft:blackstone
setblock 135 248 545 minecraft:smooth_basalt
fill 135 248 546 135 251 546 minecraft:blackstone
setblock 135 248 550 minecraft:smooth_basalt
fill 135 248 551 135 251 551 minecraft:blackstone
fill 95 249 511 95 251 511 minecraft:blackstone
setblock 95 249 519 minecraft:smooth_basalt
fill 95 249 520 95 249 523 minecraft:blackstone
setblock 95 249 524 minecraft:smooth_basalt
fill 95 249 525 95 249 528 minecraft:blackstone
setblock 95 249 529 minecraft:smooth_basalt
fill 95 249 530 95 252 530 minecraft:blackstone
setblock 95 249 534 minecraft:smooth_basalt
fill 95 249 535 95 252 535 minecraft:blackstone
setblock 95 249 539 minecraft:smooth_basalt
fill 95 249 540 95 252 540 minecraft:blackstone
setblock 95 249 544 minecraft:smooth_basalt
fill 95 249 545 95 249 548 minecraft:blackstone
setblock 95 249 549 minecraft:smooth_basalt
fill 95 249 550 95 252 550 minecraft:blackstone
setblock 96 249 523 minecraft:smooth_basalt
fill 96 249 524 96 249 527 minecraft:blackstone
setblock 96 249 528 minecraft:smooth_basalt
fill 96 249 529 96 252 529 minecraft:blackstone
setblock 96 249 533 minecraft:smooth_basalt
fill 96 249 534 96 252 534 minecraft:blackstone
setblock 96 249 538 minecraft:smooth_basalt
setblock 96 249 539 minecraft:blackstone
setblock 96 249 543 minecraft:smooth_basalt
fill 96 249 544 96 250 544 minecraft:blackstone
setblock 96 249 548 minecraft:smooth_basalt
fill 96 249 549 96 252 549 minecraft:blackstone
setblock 97 249 511 minecraft:blackstone
setblock 97 249 523 minecraft:blackstone
setblock 97 249 527 minecraft:smooth_basalt
fill 97 249 528 97 252 528 minecraft:blackstone
setblock 97 249 532 minecraft:smooth_basalt
fill 97 249 533 97 252 533 minecraft:blackstone
setblock 98 249 511 minecraft:smooth_basalt
setblock 98 249 526 minecraft:smooth_basalt
fill 98 249 527 98 251 527 minecraft:blackstone
setblock 98 249 551 minecraft:smooth_basalt
fill 99 249 511 99 252 511 minecraft:blackstone
setblock 99 249 550 minecraft:smooth_basalt
fill 99 249 551 99 252 551 minecraft:blackstone
fill 100 249 526 101 250 527 minecraft:gold_block
setblock 100 249 550 minecraft:blackstone
fill 110 249 511 112 249 511 minecraft:blackstone
fill 111 249 551 112 249 551 minecraft:blackstone
setblock 113 249 511 minecraft:smooth_basalt
fill 113 249 512 113 252 512 minecraft:blackstone
setblock 113 249 550 minecraft:blackstone
setblock 113 249 551 minecraft:smooth_basalt
fill 114 249 511 117 249 511 minecraft:blackstone
setblock 114 249 550 minecraft:smooth_basalt
fill 114 249 551 114 252 551 minecraft:blackstone
setblock 115 249 549 minecraft:smooth_basalt
fill 115 249 550 115 252 550 minecraft:blackstone
fill 116 249 549 116 252 549 minecraft:blackstone
setblock 117 249 512 minecraft:smooth_basalt
setblock 118 249 511 minecraft:smooth_basalt
fill 118 249 512 118 252 512 minecraft:blackstone
setblock 118 249 551 minecraft:smooth_basalt
fill 119 249 511 119 252 511 minecraft:blackstone
setblock 119 249 550 minecraft:smooth_basalt
fill 119 249 551 119 252 551 minecraft:blackstone
setblock 120 249 549 minecraft:smooth_basalt
fill 120 249 550 120 252 550 minecraft:blackstone
fill 121 249 549 121 251 549 minecraft:blackstone
setblock 123 249 511 minecraft:smooth_basalt
setblock 123 249 551 minecraft:smooth_basalt
fill 124 249 511 124 252 511 minecraft:blackstone
setblock 124 249 550 minecraft:smooth_basalt
fill 124 249 551 127 249 551 minecraft:blackstone
fill 125 249 550 128 249 550 minecraft:blackstone
setblock 128 249 551 minecraft:smooth_basalt
setblock 129 249 550 minecraft:smooth_basalt
fill 129 249 551 129 252 551 minecraft:blackstone
fill 130 249 550 130 252 550 minecraft:blackstone
setblock 133 249 546 minecraft:smooth_basalt
fill 133 249 547 133 252 547 minecraft:blackstone
setblock 133 249 551 minecraft:smooth_basalt
fill 134 249 511 134 252 511 minecraft:blackstone
fill 134 249 526 134 252 526 minecraft:blackstone
setblock 134 249 529 minecraft:blackstone
setblock 134 249 530 minecraft:smooth_basalt
fill 134 249 531 134 251 532 minecraft:blackstone
fill 134 249 541 134 250 541 minecraft:blackstone
setblock 134 249 545 minecraft:smooth_basalt
fill 134 249 546 134 252 546 minecraft:blackstone
setblock 134 249 550 minecraft:smooth_basalt
fill 134 249 551 134 252 551 minecraft:blackstone
setblock 135 249 524 minecraft:smooth_basalt
fill 135 249 525 135 252 525 minecraft:blackstone
setblock 135 249 529 minecraft:smooth_basalt
fill 135 249 530 135 252 530 minecraft:blackstone
setblock 135 249 534 minecraft:smooth_basalt
fill 135 249 535 135 252 535 minecraft:blackstone
setblock 135 249 539 minecraft:smooth_basalt
fill 135 249 540 135 252 540 minecraft:blackstone
setblock 135 249 544 minecraft:smooth_basalt
fill 135 249 545 135 252 545 minecraft:blackstone
setblock 135 249 549 minecraft:smooth_basalt
fill 135 249 550 135 252 550 minecraft:blackstone
fill 95 250 520 95 250 522 minecraft:blackstone
setblock 95 250 523 minecraft:smooth_basalt
fill 95 250 524 95 250 527 minecraft:blackstone
setblock 95 250 528 minecraft:smooth_basalt
fill 95 250 529 95 253 529 minecraft:blackstone
setblock 95 250 533 minecraft:smooth_basalt
fill 95 250 534 95 253 534 minecraft:blackstone
setblock 95 250 538 minecraft:smooth_basalt
fill 95 250 539 95 253 539 minecraft:blackstone
setblock 95 250 543 minecraft:smooth_basalt
fill 95 250 544 95 250 547 minecraft:blackstone
setblock 95 250 548 minecraft:smooth_basalt
fill 95 250 549 95 253 549 minecraft:blackstone
setblock 96 250 522 minecraft:smooth_basalt
fill 96 250 523 96 250 526 minecraft:blackstone
setblock 96 250 527 minecraft:smooth_basalt
fill 96 250 528 96 253 528 minecraft:blackstone
setblock 96 250 532 minecraft:smooth_basalt
fill 96 250 533 96 253 533 minecraft:blackstone
setblock 96 250 537 minecraft:smooth_basalt
setblock 96 250 543 minecraft:blackstone
setblock 96 250 547 minecraft:smooth_basalt
fill 96 250 548 96 253 548 minecraft:blackstone
setblock 97 250 511 minecraft:smooth_basalt
setblock 97 250 526 minecraft:smooth_basalt
fill 97 250 527 97 253 527 minecraft:blackstone
setblock 97 250 531 minecraft:smooth_basalt
fill 97 250 532 97 253 532 minecraft:blackstone
setblock 97 250 551 minecraft:smooth_basalt
fill 98 250 511 98 253 511 minecraft:blackstone
setblock 98 250 526 minecraft:blackstone
setblock 98 250 530 minecraft:smooth_basalt
setblock 98 250 550 minecraft:smooth_basalt
fill 98 250 551 98 253 551 minecraft:blackstone
setblock 99 250 550 minecraft:blackstone
fill 110 250 511 111 250 511 minecraft:blackstone
fill 110 250 551 111 250 551 minecraft:blackstone
setblock 112 250 511 minecraft:smooth_basalt
fill 112 250 512 112 253 512 minecraft:blackstone
setblock 112 250 551 minecraft:smooth_basalt
fill 113 250 511 116 250 511 minecraft:blackstone
setblock 113 250 550 minecraft:smooth_basalt
fill 113 250 551 113 253 551 minecraft:blackstone
fill 114 250 550 114 253 550 minecraft:blackstone
fill 115 250 549 115 253 549 minecraft:blackstone
setblock 116 250 512 minecraft:smooth_basalt
setblock 117 250 511 minecraft:smooth_basalt
fill 117 250 512 117 253 512 minecraft:blackstone
setblock 117 250 551 minecraft:smooth_basalt
fill 118 250 511 118 253 511 minecraft:blackstone
setblock 118 250 550 minecraft:smooth_basalt
fill 118 250 551 118 253 551 minecraft:blackstone
setblock 119 250 549 minecraft:smooth_basalt
fill 119 250 550 119 253 550 minecraft:blackstone
fill 120 250 549 120 252 549 minecraft:blackstone
setblock 121 250 512 minecraft:smooth_basalt
setblock 122 250 511 minecraft:smooth_basalt
setblock 122 250 551 minecraft:smooth_basalt
fill 123 250 511 123 253 511 minecraft:blackstone
setblock 123 250 550 minecraft:smooth_basalt
fill 123 250 551 126 250 551 minecraft:blackstone
fill 124 250 550 127 250 550 minecraft:blackstone
setblock 127 250 551 minecraft:smooth_basalt
setblock 128 250 550 minecraft:smooth_basalt
fill 128 250 551 128 253 551 minecraft:blackstone
fill 129 250 550 129 253 550 minecraft:blackstone
setblock 132 250 551 minecraft:smooth_basalt
fill 133 250 511 133 253 511 minecraft:blackstone
setblock 133 250 546 minecraft:blackstone
setblock 133 250 550 minecraft:smooth_basalt
fill 133 250 551 133 253 551 minecraft:blackstone
setblock 134 250 529 minecraft:smooth_basalt
fill 134 250 530 134 253 530 minecraft:blackstone
setblock 134 250 533 minecraft:blackstone
setblock 134 250 544 minecraft:smooth_basalt
fill 134 250 545 134 253 545 minecraft:blackstone
setblock 134 250 549 minecraft:smooth_basalt
fill 134 250 550 134 253 550 minecraft:blackstone
setblock 135 250 512 minecraft:blackstone
setblock 135 250 523 minecraft:smooth_basalt
fill 135 250 524 135 253 524 minecraft:blackstone
setblock 135 250 528 minecraft:smooth_basalt
fill 135 250 529 135 253 529 minecraft:blackstone
setblock 135 250 533 minecraft:smooth_basalt
fill 135 250 534 135 253 534 minecraft:blackstone
setblock 135 250 538 minecraft:smooth_basalt
fill 135 250 539 135 253 539 minecraft:blackstone
setblock 135 250 543 minecraft:smooth_basalt
fill 135 250 544 135 253 544 minecraft:blackstone
setblock 135 250 548 minecraft:smooth_basalt
fill 135 250 549 135 253 549 minecraft:blackstone
setblock 95 251 512 minecraft:smooth_basalt
fill 95 251 520 95 251 521 minecraft:blackstone
setblock 95 251 522 minecraft:smooth_basalt
fill 95 251 523 95 251 526 minecraft:blackstone
setblock 95 251 527 minecraft:smooth_basalt
fill 95 251 528 95 254 528 minecraft:blackstone
setblock 95 251 532 minecraft:smooth_basalt
fill 95 251 533 95 254 533 minecraft:blackstone
setblock 95 251 537 minecraft:smooth_basalt
fill 95 251 538 95 254 538 minecraft:blackstone
setblock 95 251 542 minecraft:smooth_basalt
fill 95 251 543 95 251 546 minecraft:blackstone
setblock 95 251 547 minecraft:smooth_basalt
fill 95 251 548 95 254 548 minecraft:blackstone
setblock 96 251 511 minecraft:smooth_basalt
fill 96 251 522 96 251 525 minecraft:blackstone
setblock 96 251 526 minecraft:smooth_basalt
fill 96 251 527 96 254 527 minecraft:blackstone
setblock 96 251 531 minecraft:smooth_basalt
fill 96 251 532 96 254 532 minecraft:blackstone
setblock 96 251 536 minecraft:smooth_basalt
fill 96 251 537 96 254 537 minecraft:blackstone
setblock 96 251 546 minecraft:smooth_basalt
fill 96 251 547 96 252 547 minecraft:blackstone
setblock 96 251 551 minecraft:smooth_basalt
fill 97 251 511 97 254 511 minecraft:blackstone
setblock 97 251 525 minecraft:smooth_basalt
fill 97 251 526 97 254 526 minecraft:blackstone
setblock 97 251 530 minecraft:smooth_basalt
fill 97 251 531 97 254 531 minecraft:blackstone
setblock 97 251 534 minecraft:blackstone
setblock 97 251 550 minecraft:smooth_basalt
fill 97 251 551 97 254 551 minecraft:blackstone
setblock 98 251 529 minecraft:smooth_basalt
setblock 98 251 530 minecraft:blackstone
setblock 98 251 550 minecraft:blackstone
setblock 101 251 551 minecraft:smooth_basalt
fill 108 251 511 110 251 511 minecraft:blackstone
setblock 110 251 551 minecraft:blackstone
setblock 111 251 511 minecraft:smooth_basalt
setblock 111 251 551 minecraft:smooth_basalt
fill 112 251 511 115 251 511 minecraft:blackstone
setblock 112 251 550 minecraft:smooth_basalt
fill 112 251 551 112 254 551 minecraft:blackstone
fill 113 251 550 113 254 550 minecraft:blackstone
setblock 115 251 512 minecraft:smooth_basalt
setblock 116 251 511 minecraft:smooth_basalt
fill 116 251 512 116 254 512 minecraft:blackstone
setblock 116 251 551 minecraft:smooth_basalt
fill 117 251 511 117 254 511 minecraft:blackstone
setblock 117 251 550 minecraft:smooth_basalt
fill 117 251 551 117 254 551 minecraft:blackstone
setblock 118 251 549 minecraft:smooth_basalt
fill 118 251 550 118 254 550 minecraft:blackstone
fill 119 251 549 119 254 549 minecraft:blackstone
setblock 120 251 512 minecraft:smooth_basalt
setblock 121 251 511 minecraft:smooth_basalt
fill 121 251 512 121 254 512 minecraft:blackstone
setblock 121 251 551 minecraft:smooth_basalt
fill 122 251 511 122 254 511 minecraft:blackstone
setblock 122 251 550 minecraft:smooth_basalt
fill 122 251 551 125 251 551 minecraft:blackstone
fill 123 251 550 126 251 550 minecraft:blackstone
setblock 126 251 551 minecraft:smooth_basalt
setblock 127 251 550 minecraft:smooth_basalt
fill 127 251 551 127 254 551 minecraft:blackstone
fill 128 251 550 128 254 550 minecraft:blackstone
setblock 131 251 551 minecraft:smooth_basalt
fill 132 251 511 132 254 511 minecraft:blackstone
setblock 132 251 550 minecraft:smooth_basalt
fill 132 251 551 132 254 551 minecraft:blackstone
setblock 133 251 549 minecraft:smooth_basalt
fill 133 251 550 133 254 550 minecraft:blackstone
setblock 134 251 528 minecraft:smooth_basalt
fill 134 251 529 134 254 529 minecraft:blackstone
setblock 134 251 533 minecraft:smooth_basalt
fill 134 251 534 134 253 535 minecraft:blackstone
setblock 134 251 543 minecraft:smooth_basalt
fill 134 251 544 134 254 544 minecraft:blackstone
setblock 134 251 548 minecraft:smooth_basalt
fill 134 251 549 134 254 549 minecraft:blackstone
setblock 135 251 512 minecraft:smooth_basalt
fill 135 251 523 135 254 523 minecraft:blackstone
setblock 135 251 527 minecraft:smooth_basalt
fill 135 251 528 135 254 528 minecraft:blackstone
setblock 135 251 532 minecraft:smooth_basalt
fill 135 251 533 135 254 533 minecraft:blackstone
setblock 135 251 537 minecraft:smooth_basalt
fill 135 251 538 135 254 538 minecraft:blackstone
setblock 135 251 542 minecraft:smooth_basalt
fill 135 251 543 135 254 543 minecraft:blackstone
setblock 135 251 547 minecraft:smooth_basalt
fill 135 251 548 135 254 548 minecraft:blackstone
setblock 95 252 511 minecraft:smooth_basalt
fill 95 252 512 95 253 514 minecraft:blackstone
setblock 95 252 520 minecraft:blackstone
setblock 95 252 521 minecraft:smooth_basalt
fill 95 252 522 95 252 525 minecraft:blackstone
setblock 95 252 526 minecraft:smooth_basalt
fill 95 252 527 95 255 527 minecraft:blackstone
setblock 95 252 531 minecraft:smooth_basalt
fill 95 252 532 95 255 532 minecraft:blackstone
setblock 95 252 536 minecraft:smooth_basalt
fill 95 252 537 95 255 537 minecraft:blackstone
setblock 95 252 541 minecraft:smooth_basalt
fill 95 252 542 95 252 545 minecraft:blackstone
setblock 95 252 546 minecraft:smooth_basalt
fill 95 252 547 95 255 547 minecraft:blackstone
setblock 95 252 551 minecraft:smooth_basalt
fill 96 252 511 96 255 511 minecraft:blackstone
fill 96 252 522 96 252 524 minecraft:blackstone
setblock 96 252 525 minecraft:smooth_basalt
fill 96 252 526 96 255 526 minecraft:blackstone
setblock 96 252 530 minecraft:smooth_basalt
fill 96 252 531 96 255 531 minecraft:blackstone
setblock 96 252 535 minecraft:smooth_basalt
fill 96 252 536 96 255 536 minecraft:blackstone
setblock 96 252 550 minecraft:smooth_basalt
fill 96 252 551 96 255 551 minecraft:blackstone
fill 97 252 525 97 254 525 minecraft:blackstone
setblock 97 252 529 minecraft:smooth_basalt
fill 97 252 530 97 255 530 minecraft:blackstone
setblock 97 252 534 minecraft:smooth_basalt
fill 97 252 550 97 253 550 minecraft:blackstone
setblock 98 252 529 minecraft:blackstone
setblock 100 252 511 minecraft:smooth_basalt
setblock 100 252 551 minecraft:smooth_basalt
fill 101 252 511 101 255 511 minecraft:blackstone
fill 107 252 511 109 252 511 minecraft:blackstone
setblock 109 252 551 minecraft:blackstone
setblock 110 252 511 minecraft:smooth_basalt
fill 110 252 512 111 254 512 minecraft:blackstone
setblock 110 252 551 minecraft:smooth_basalt
fill 111 252 511 114 252 511 minecraft:blackstone
fill 111 252 551 111 255 551 minecraft:blackstone
fill 112 252 550 112 255 550 minecraft:blackstone
setblock 114 252 512 minecraft:smooth_basalt
fill 114 252 513 117 252 513 minecraft:blackstone
setblock 115 252 511 minecraft:smooth_basalt
fill 115 252 512 115 255 512 minecraft:blackstone
setblock 115 252 551 minecraft:smooth_basalt
fill 116 252 511 116 255 511 minecraft:blackstone
setblock 116 252 550 minecraft:smooth_basalt
fill 116 252 551 116 255 551 minecraft:blackstone
setblock 117 252 549 minecraft:smooth_basalt
fill 117 252 550 117 255 550 minecraft:blackstone
fill 118 252 549 118 255 549 minecraft:blackstone
setblock 119 252 512 minecraft:smooth_basalt
setblock 120 252 511 minecraft:smooth_basalt
fill 120 252 512 120 255 512 minecraft:blackstone
setblock 120 252 551 minecraft:smooth_basalt
fill 121 252 511 121 255 511 minecraft:blackstone
setblock 121 252 550 minecraft:smooth_basalt
fill 121 252 551 124 252 551 minecraft:blackstone
fill 122 252 550 125 252 550 minecraft:blackstone
setblock 125 252 551 minecraft:smooth_basalt
setblock 126 252 550 minecraft:smooth_basalt
fill 126 252 551 126 255 551 minecraft:blackstone
fill 127 252 550 127 255 550 minecraft:blackstone
setblock 130 252 511 minecraft:smooth_basalt
setblock 130 252 551 minecraft:smooth_basalt
fill 131 252 511 131 255 511 minecraft:blackstone
setblock 131 252 550 minecraft:smooth_basalt
fill 131 252 551 131 255 551 minecraft:blackstone
setblock 132 252 549 minecraft:smooth_basalt
fill 132 252 550 132 255 550 minecraft:blackstone
setblock 133 252 548 minecraft:smooth_basalt
fill 133 252 549 133 255 549 minecraft:blackstone
setblock 134 252 527 minecraft:smooth_basalt
fill 134 252 528 134 255 528 minecraft:blackstone
setblock 134 252 531 minecraft:blackstone
setblock 134 252 532 minecraft:smooth_basalt
fill 134 252 533 134 255 533 minecraft:blackstone
setblock 134 252 536 minecraft:blackstone
setblock 134 252 537 minecraft:smooth_basalt
fill 134 252 538 134 255 538 minecraft:blackstone
setblock 134 252 541 minecraft:blackstone
setblock 134 252 542 minecraft:smooth_basalt
fill 134 252 543 134 255 543 minecraft:blackstone
setblock 134 252 547 minecraft:smooth_basalt
fill 134 252 548 134 255 548 minecraft:blackstone
setblock 135 252 511 minecraft:smooth_basalt
fill 135 252 512 135 254 513 minecraft:blackstone
setblock 135 252 526 minecraft:smooth_basalt
fill 135 252 527 135 255 527 minecraft:blackstone
setblock 135 252 531 minecraft:smooth_basalt
fill 135 252 532 135 255 532 minecraft:blackstone
setblock 135 252 536 minecraft:smooth_basalt
fill 135 252 537 135 255 537 minecraft:blackstone
setblock 135 252 541 minecraft:smooth_basalt
fill 135 252 542 135 255 542 minecraft:blackstone
setblock 135 252 546 minecraft:smooth_basalt
fill 135 252 547 135 255 547 minecraft:blackstone
setblock 135 252 551 minecraft:smooth_basalt
fill 95 253 511 95 256 511 minecraft:blackstone
setblock 95 253 515 minecraft:smooth_basalt
fill 95 253 516 95 253 519 minecraft:blackstone
setblock 95 253 520 minecraft:smooth_basalt
fill 95 253 521 95 253 524 minecraft:blackstone
setblock 95 253 525 minecraft:smooth_basalt
fill 95 253 526 95 256 526 minecraft:blackstone
setblock 95 253 530 minecraft:smooth_basalt
fill 95 253 531 95 256 531 minecraft:blackstone
setblock 95 253 535 minecraft:smooth_basalt
fill 95 253 536 95 256 536 minecraft:blackstone
setblock 95 253 540 minecraft:smooth_basalt
fill 95 253 541 95 253 544 minecraft:blackstone
setblock 95 253 545 minecraft:smooth_basalt
fill 95 253 546 95 256 546 minecraft:blackstone
setblock 95 253 550 minecraft:smooth_basalt
fill 95 253 551 95 256 551 minecraft:blackstone
fill 96 253 522 96 253 523 minecraft:blackstone
setblock 96 253 524 minecraft:smooth_basalt
fill 96 253 525 96 256 525 minecraft:blackstone
setblock 96 253 529 minecraft:smooth_basalt
fill 96 253 530 96 256 530 minecraft:blackstone
setblock 96 253 534 minecraft:smooth_basalt
fill 96 253 535 96 256 535 minecraft:blackstone
setblock 96 253 538 minecraft:blackstone
setblock 96 253 549 minecraft:smooth_basalt
fill 96 253 550 96 256 550 minecraft:blackstone
setblock 97 253 528 minecraft:smooth_basalt
fill 97 253 529 97 256 529 minecraft:blackstone
setblock 97 253 533 minecraft:smooth_basalt
fill 97 253 534 97 256 534 minecraft:blackstone
setblock 99 253 511 minecraft:smooth_basalt
setblock 99 253 551 minecraft:smooth_basalt
fill 100 253 511 100 256 511 minecraft:blackstone
fill 100 253 551 100 256 551 minecraft:blackstone
fill 102 253 511 103 253 511 minecraft:blackstone
setblock 104 253 511 minecraft:smooth_basalt
fill 105 253 511 108 253 511 minecraft:blackstone
setblock 108 253 551 minecraft:blackstone
setblock 109 253 511 minecraft:smooth_basalt
fill 109 253 512 109 256 512 minecraft:blackstone
setblock 109 253 551 minecraft:smooth_basalt
fill 110 253 511 113 253 511 minecraft:blackstone
fill 110 253 551 110 256 551 minecraft:blackstone
fill 111 253 550 111 256 550 minecraft:blackstone
setblock 112 253 513 minecraft:smooth_basalt
setblock 113 253 512 minecraft:smooth_basalt
fill 113 253 513 116 253 513 minecraft:blackstone
setblock 114 253 511 minecraft:smooth_basalt
fill 114 253 512 114 256 512 minecraft:blackstone
fill 114 253 549 114 254 549 minecraft:blackstone
setblock 114 253 551 minecraft:smooth_basalt
fill 115 253 511 115 256 511 minecraft:blackstone
setblock 115 253 550 minecraft:smooth_basalt
fill 115 253 551 115 256 551 minecraft:blackstone
setblock 116 253 549 minecraft:smooth_basalt
fill 116 253 550 116 256 550 minecraft:blackstone
setblock 117 253 513 minecraft:smooth_basalt
fill 117 253 549 117 256 549 minecraft:blackstone
setblock 118 253 512 minecraft:smooth_basalt
setblock 119 253 511 minecraft:smooth_basalt
fill 119 253 512 119 256 512 minecraft:blackstone
setblock 119 253 551 minecraft:smooth_basalt
fill 120 253 511 120 256 511 minecraft:blackstone
setblock 120 253 550 minecraft:smooth_basalt
fill 120 253 551 123 253 551 minecraft:blackstone
fill 121 253 550 124 253 550 minecraft:blackstone
setblock 124 253 511 minecraft:smooth_basalt
setblock 124 253 551 minecraft:smooth_basalt
fill 125 253 511 128 253 511 minecraft:blackstone
setblock 125 253 550 minecraft:smooth_basalt
fill 125 253 551 125 256 551 minecraft:blackstone
fill 126 253 550 126 256 550 minecraft:blackstone
setblock 129 253 511 minecraft:smooth_basalt
setblock 129 253 551 minecraft:smooth_basalt
fill 130 253 511 130 256 511 minecraft:blackstone
setblock 130 253 550 minecraft:smooth_basalt
fill 130 253 551 130 256 551 minecraft:blackstone
setblock 131 253 549 minecraft:smooth_basalt
fill 131 253 550 131 256 550 minecraft:blackstone
fill 132 253 549 132 256 549 minecraft:blackstone
fill 133 253 530 133 253 531 minecraft:blackstone
setblock 133 253 532 minecraft:smooth_basalt
fill 133 253 533 133 255 534 minecraft:blackstone
setblock 133 253 547 minecraft:smooth_basalt
fill 133 253 548 133 256 548 minecraft:blackstone
setblock 134 253 511 minecraft:smooth_basalt
setblock 134 253 526 minecraft:smooth_basalt
fill 134 253 527 134 256 527 minecraft:blackstone
setblock 134 253 531 minecraft:smooth_basalt
fill 134 253 532 134 256 532 minecraft:blackstone
setblock 134 253 536 minecraft:smooth_basalt
fill 134 253 537 134 256 537 minecraft:blackstone
fill 134 253 539 134 253 540 minecraft:blackstone
setblock 134 253 541 minecraft:smooth_basalt
fill 134 253 542 134 256 542 minecraft:blackstone
setblock 134 253 546 minecraft:smooth_basalt
fill 134 253 547 134 256 547 minecraft:blackstone
setblock 134 253 551 minecraft:smooth_basalt
fill 135 253 511 135 256 511 minecraft:blackstone
setblock 135 253 514 minecraft:blackstone
setblock 135 253 525 minecraft:smooth_basalt
fill 135 253 526 135 256 526 minecraft:blackstone
setblock 135 253 530 minecraft:smooth_basalt
fill 135 253 531 135 256 531 minecraft:blackstone
setblock 135 253 535 minecraft:smooth_basalt
fill 135 253 536 135 256 536 minecraft:blackstone
setblock 135 253 540 minecraft:smooth_basalt
fill 135 253 541 135 256 541 minecraft:blackstone
setblock 135 253 545 minecraft:smooth_basalt
fill 135 253 546 135 256 546 minecraft:blackstone
setblock 135 253 550 minecraft:smooth_basalt
fill 135 253 551 135 256 551 minecraft:blackstone
fill 95 254 512 95 254 513 minecraft:blackstone
fill 95 254 514 98 254 514 minecraft:smooth_basalt
fill 95 254 515 95 254 518 minecraft:blackstone
setblock 95 254 519 minecraft:smooth_basalt
fill 95 254 520 95 254 523 minecraft:blackstone
setblock 95 254 524 minecraft:smooth_basalt
fill 95 254 525 95 257 525 minecraft:blackstone
setblock 95 254 529 minecraft:smooth_basalt
fill 95 254 530 95 257 530 minecraft:blackstone
setblock 95 254 534 minecraft:smooth_basalt
fill 95 254 535 95 257 535 minecraft:blackstone
setblock 95 254 539 minecraft:smooth_basalt
fill 95 254 540 95 254 543 minecraft:blackstone
setblock 95 254 544 minecraft:smooth_basalt
fill 95 254 545 95 257 545 minecraft:blackstone
setblock 95 254 549 minecraft:smooth_basalt
fill 95 254 550 95 257 550 minecraft:blackstone
setblock 96 254 512 minecraft:blackstone
fill 96 254 513 98 254 513 minecraft:smooth_basalt
setblock 96 254 522 minecraft:blackstone
setblock 96 254 523 minecraft:smooth_basalt
fill 96 254 524 96 257 524 minecraft:blackstone
setblock 96 254 528 minecraft:smooth_basalt
fill 96 254 529 96 257 529 minecraft:blackstone
setblock 96 254 533 minecraft:smooth_basalt
fill 96 254 534 96 257 534 minecraft:blackstone
setblock 96 254 538 minecraft:smooth_basalt
setblock 96 254 549 minecraft:blackstone
setblock 97 254 512 minecraft:smooth_basalt
setblock 97 254 527 minecraft:smooth_basalt
fill 97 254 528 97 257 528 minecraft:blackstone
setblock 97 254 532 minecraft:smooth_basalt
fill 97 254 533 97 257 533 minecraft:blackstone
fill 97 254 535 97 255 535 minecraft:blackstone
setblock 98 254 511 minecraft:smooth_basalt
fill 98 254 512 98 257 512 minecraft:blackstone
setblock 98 254 551 minecraft:smooth_basalt
fill 99 254 511 99 257 511 minecraft:blackstone
fill 99 254 551 99 257 551 minecraft:blackstone
setblock 102 254 511 minecraft:blackstone
setblock 103 254 511 minecraft:smooth_basalt
fill 104 254 511 107 254 511 minecraft:blackstone
setblock 107 254 512 minecraft:smooth_basalt
setblock 107 254 551 minecraft:blackstone
setblock 108 254 511 minecraft:smooth_basalt
fill 108 254 512 108 257 512 minecraft:blackstone
setblock 108 254 551 minecraft:smooth_basalt
fill 109 254 511 112 254 511 minecraft:blackstone
fill 109 254 551 109 257 551 minecraft:blackstone
fill 110 254 550 110 257 550 minecraft:blackstone
setblock 111 254 513 minecraft:smooth_basalt
setblock 112 254 512 minecraft:smooth_basalt
fill 112 254 513 115 254 513 minecraft:blackstone
setblock 113 254 511 minecraft:smooth_basalt
fill 113 254 512 113 257 512 minecraft:blackstone
fill 113 254 549 113 255 549 minecraft:blackstone
setblock 113 254 551 minecraft:smooth_basalt
fill 114 254 511 114 257 511 minecraft:blackstone
setblock 114 254 550 minecraft:smooth_basalt
fill 114 254 551 114 257 551 minecraft:blackstone
setblock 115 254 549 minecraft:smooth_basalt
fill 115 254 550 115 257 550 minecraft:blackstone
setblock 116 254 513 minecraft:smooth_basalt
fill 116 254 549 116 257 549 minecraft:blackstone
setblock 117 254 512 minecraft:smooth_basalt
fill 117 254 513 118 256 513 minecraft:blackstone
setblock 118 254 511 minecraft:smooth_basalt
fill 118 254 512 118 257 512 minecraft:blackstone
setblock 118 254 551 minecraft:smooth_basalt
fill 119 254 511 119 257 511 minecraft:blackstone
setblock 119 254 550 minecraft:smooth_basalt
fill 119 254 551 122 254 551 minecraft:blackstone
fill 120 254 550 123 254 550 minecraft:blackstone
setblock 123 254 511 minecraft:smooth_basalt
setblock 123 254 551 minecraft:smooth_basalt
fill 124 254 511 127 254 511 minecraft:blackstone
setblock 124 254 550 minecraft:smooth_basalt
fill 124 254 551 124 257 551 minecraft:blackstone
fill 125 254 550 125 257 550 minecraft:blackstone
setblock 128 254 511 minecraft:smooth_basalt
setblock 128 254 551 minecraft:smooth_basalt
fill 129 254 511 129 257 511 minecraft:blackstone
setblock 129 254 550 minecraft:smooth_basalt
fill 129 254 551 129 257 551 minecraft:blackstone
fill 130 254 550 130 257 550 minecraft:blackstone
fill 131 254 549 131 257 549 minecraft:blackstone
setblock 133 254 511 minecraft:smooth_basalt
fill 133 254 512 134 256 512 minecraft:blackstone
fill 133 254 529 133 254 530 minecraft:blackstone
setblock 133 254 531 minecraft:smooth_basalt
fill 133 254 532 133 257 532 minecraft:blackstone
setblock 133 254 535 minecraft:blackstone
setblock 133 254 536 minecraft:smooth_basalt
fill 133 254 547 133 257 547 minecraft:blackstone
setblock 133 254 551 minecraft:smooth_basalt
fill 134 254 511 134 257 511 minecraft:blackstone
fill 134 254 526 134 257 526 minecraft:blackstone
setblock 134 254 530 minecraft:smooth_basalt
fill 134 254 531 134 257 531 minecraft:blackstone
setblock 134 254 534 minecraft:blackstone
setblock 134 254 535 minecraft:smooth_basalt
fill 134 254 536 134 257 536 minecraft:blackstone
setblock 134 254 539 minecraft:blackstone
setblock 134 254 540 minecraft:smooth_basalt
fill 134 254 541 134 257 541 minecraft:blackstone
setblock 134 254 545 minecraft:smooth_basalt
fill 134 254 546 134 257 546 minecraft:blackstone
setblock 134 254 550 minecraft:smooth_basalt
fill 134 254 551 134 257 551 minecraft:blackstone
setblock 135 254 514 minecraft:smooth_basalt
fill 135 254 515 135 257 515 minecraft:blackstone
setblock 135 254 524 minecraft:smooth_basalt
fill 135 254 525 135 257 525 minecraft:blackstone
setblock 135 254 529 minecraft:smooth_basalt
fill 135 254 530 135 257 530 minecraft:blackstone
setblock 135 254 534 minecraft:smooth_basalt
fill 135 254 535 135 257 535 minecraft:blackstone
setblock 135 254 539 minecraft:smooth_basalt
fill 135 254 540 135 257 540 minecraft:blackstone
setblock 135 254 544 minecraft:smooth_basalt
fill 135 254 545 135 257 545 minecraft:blackstone
setblock 135 254 549 minecraft:smooth_basalt
fill 135 254 550 135 257 550 minecraft:blackstone
setblock 95 255 512 minecraft:blackstone
setblock 95 255 513 minecraft:smooth_basalt
fill 95 255 514 95 255 517 minecraft:blackstone
setblock 95 255 518 minecraft:smooth_basalt
fill 95 255 519 95 255 522 minecraft:blackstone
setblock 95 255 523 minecraft:smooth_basalt
fill 95 255 524 95 258 524 minecraft:blackstone
setblock 95 255 528 minecraft:smooth_basalt
fill 95 255 529 95 258 529 minecraft:blackstone
setblock 95 255 533 minecraft:smooth_basalt
fill 95 255 534 95 258 534 minecraft:blackstone
setblock 95 255 538 minecraft:smooth_basalt
fill 95 255 539 95 255 542 minecraft:blackstone
setblock 95 255 543 minecraft:smooth_basalt
fill 95 255 544 95 258 544 minecraft:blackstone
setblock 95 255 548 minecraft:smooth_basalt
fill 95 255 549 95 258 549 minecraft:blackstone
setblock 96 255 512 minecraft:smooth_basalt
fill 96 255 513 96 255 516 minecraft:blackstone
setblock 96 255 522 minecraft:smooth_basalt
fill 96 255 523 96 258 523 minecraft:blackstone
setblock 96 255 527 minecraft:smooth_basalt
fill 96 255 528 96 258 528 minecraft:blackstone
setblock 96 255 532 minecraft:smooth_basalt
fill 96 255 533 96 258 533 minecraft:blackstone
setblock 96 255 537 minecraft:smooth_basalt
fill 96 255 538 96 257 539 minecraft:blackstone
setblock 97 255 511 minecraft:smooth_basalt
fill 97 255 512 97 258 512 minecraft:blackstone
fill 97 255 513 98 256 514 minecraft:smooth_basalt
setblock 97 255 526 minecraft:smooth_basalt
fill 97 255 527 97 257 527 minecraft:blackstone
setblock 97 255 531 minecraft:smooth_basalt
fill 97 255 532 97 258 532 minecraft:blackstone
setblock 97 255 551 minecraft:smooth_basalt
fill 98 255 511 98 258 511 minecraft:blackstone
fill 98 255 551 98 258 551 minecraft:blackstone
fill 99 255 512 99 256 512 minecraft:blackstone
setblock 102 255 511 minecraft:smooth_basalt
fill 103 255 511 106 255 511 minecraft:blackstone
setblock 105 255 512 minecraft:blackstone
setblock 106 255 512 minecraft:smooth_basalt
setblock 106 255 551 minecraft:blackstone
setblock 107 255 511 minecraft:smooth_basalt
fill 107 255 512 107 258 512 minecraft:blackstone
setblock 107 255 551 minecraft:smooth_basalt
fill 108 255 511 111 255 511 minecraft:blackstone
fill 108 255 551 108 258 551 minecraft:blackstone
setblock 109 255 513 minecraft:blackstone
fill 109 255 550 109 258 550 minecraft:blackstone
setblock 110 255 512 minecraft:blackstone
setblock 110 255 513 minecraft:smooth_basalt
setblock 111 255 512 minecraft:smooth_basalt
fill 111 255 513 114 255 513 minecraft:blackstone
setblock 112 255 511 minecraft:smooth_basalt
fill 112 255 512 112 258 512 minecraft:blackstone
setblock 112 255 551 minecraft:smooth_basalt
fill 113 255 511 113 258 511 minecraft:blackstone
setblock 113 255 514 minecraft:blackstone
setblock 113 255 550 minecraft:smooth_basalt
fill 113 255 551 113 258 551 minecraft:blackstone
setblock 114 255 514 minecraft:smooth_basalt
setblock 114 255 549 minecraft:smooth_basalt
fill 114 255 550 114 258 550 minecraft:blackstone
setblock 115 255 513 minecraft:smooth_basalt
fill 115 255 549 115 258 549 minecraft:blackstone
setblock 116 255 512 minecraft:smooth_basalt
fill 116 255 513 116 258 513 minecraft:blackstone
setblock 117 255 511 minecraft:smooth_basalt
fill 117 255 512 117 258 512 minecraft:blackstone
setblock 117 255 551 minecraft:smooth_basalt
fill 118 255 511 118 258 511 minecraft:blackstone
setblock 118 255 550 minecraft:smooth_basalt
fill 118 255 551 121 255 551 minecraft:blackstone
fill 119 255 550 122 255 550 minecraft:blackstone
setblock 121 255 512 minecraft:smooth_basalt
setblock 122 255 511 minecraft:smooth_basalt
setblock 122 255 551 minecraft:smooth_basalt
fill 123 255 511 126 255 511 minecraft:blackstone
setblock 123 255 550 minecraft:smooth_basalt
fill 123 255 551 123 258 551 minecraft:blackstone
fill 124 255 550 124 258 550 minecraft:blackstone
setblock 127 255 511 minecraft:smooth_basalt
setblock 127 255 551 minecraft:smooth_basalt
fill 128 255 511 128 258 511 minecraft:blackstone
setblock 128 255 550 minecraft:smooth_basalt
fill 128 255 551 128 258 551 minecraft:blackstone
fill 129 255 550 129 258 550 minecraft:blackstone
setblock 130 255 512 minecraft:blackstone
fill 130 255 549 130 258 549 minecraft:blackstone
setblock 132 255 511 minecraft:smooth_basalt
fill 132 255 512 132 258 512 minecraft:blackstone
setblock 132 255 551 minecraft:smooth_basalt
fill 133 255 511 133 258 511 minecraft:blackstone
fill 133 255 528 133 255 529 minecraft:blackstone
setblock 133 255 530 minecraft:smooth_basalt
fill 133 255 531 133 258 531 minecraft:blackstone
setblock 133 255 535 minecraft:smooth_basalt
fill 133 255 536 133 255 539 minecraft:blackstone
setblock 133 255 550 minecraft:smooth_basalt
fill 133 255 551 133 258 551 minecraft:blackstone
setblock 134 255 513 minecraft:blackstone
fill 134 255 525 134 258 525 minecraft:blackstone
setblock 134 255 529 minecraft:smooth_basalt
fill 134 255 530 134 258 530 minecraft:blackstone
setblock 134 255 534 minecraft:smooth_basalt
fill 134 255 535 134 258 535 minecraft:blackstone
setblock 134 255 539 minecraft:smooth_basalt
fill 134 255 540 134 258 540 minecraft:blackstone
setblock 134 255 544 minecraft:smooth_basalt
fill 134 255 545 134 258 545 minecraft:blackstone
setblock 134 255 549 minecraft:smooth_basalt
fill 134 255 550 134 258 550 minecraft:blackstone
setblock 135 255 512 minecraft:blackstone
setblock 135 255 513 minecraft:smooth_basalt
fill 135 255 514 135 258 514 minecraft:blackstone
fill 135 255 516 135 255 517 minecraft:blackstone
setblock 135 255 522 minecraft:blackstone
setblock 135 255 523 minecraft:smooth_basalt
fill 135 255 524 135 258 524 minecraft:blackstone
setblock 135 255 528 minecraft:smooth_basalt
fill 135 255 529 135 258 529 minecraft:blackstone
setblock 135 255 533 minecraft:smooth_basalt
fill 135 255 534 135 258 534 minecraft:blackstone
setblock 135 255 538 minecraft:smooth_basalt
fill 135 255 539 135 258 539 minecraft:blackstone
setblock 135 255 543 minecraft:smooth_basalt
fill 135 255 544 135 258 544 minecraft:blackstone
setblock 135 255 548 minecraft:smooth_basalt
fill 135 255 549 135 258 549 minecraft:blackstone
setblock 95 256 512 minecraft:smooth_basalt
fill 95 256 513 95 256 516 minecraft:blackstone
setblock 95 256 517 minecraft:smooth_basalt
fill 95 256 518 95 256 521 minecraft:blackstone
setblock 95 256 522 minecraft:smooth_basalt
fill 95 256 523 95 259 523 minecraft:blackstone
setblock 95 256 527 minecraft:smooth_basalt
fill 95 256 528 95 259 528 minecraft:blackstone
setblock 95 256 532 minecraft:smooth_basalt
fill 95 256 533 95 259 533 minecraft:blackstone
setblock 95 256 537 minecraft:smooth_basalt
fill 95 256 538 95 256 541 minecraft:blackstone
setblock 95 256 542 minecraft:smooth_basalt
fill 95 256 543 95 259 543 minecraft:blackstone
setblock 95 256 547 minecraft:smooth_basalt
fill 95 256 548 95 258 548 minecraft:blackstone
setblock 96 256 511 minecraft:smooth_basalt
fill 96 256 512 96 256 515 minecraft:blackstone
setblock 96 256 516 minecraft:smooth_basalt
fill 96 256 517 96 256 520 minecraft:blackstone
setblock 96 256 521 minecraft:smooth_basalt
fill 96 256 522 96 259 522 minecraft:blackstone
setblock 96 256 526 minecraft:smooth_basalt
fill 96 256 527 96 259 527 minecraft:blackstone
setblock 96 256 531 minecraft:smooth_basalt
fill 96 256 532 96 259 532 minecraft:blackstone
setblock 96 256 536 minecraft:smooth_basalt
fill 96 256 537 96 259 537 minecraft:blackstone
setblock 96 256 551 minecraft:smooth_basalt
fill 97 256 511 97 259 511 minecraft:blackstone
setblock 97 256 521 minecraft:light[level=12]
setblock 97 256 526 minecraft:blackstone
setblock 97 256 530 minecraft:smooth_basalt
fill 97 256 531 97 259 531 minecraft:blackstone
setblock 97 256 535 minecraft:smooth_basalt
fill 97 256 536 97 259 536 minecraft:blackstone
setblock 97 256 537 minecraft:light[level=12]
setblock 97 256 545 minecraft:light[level=12]
fill 97 256 551 97 259 551 minecraft:blackstone
setblock 100 256 512 minecraft:smooth_basalt
setblock 101 256 511 minecraft:smooth_basalt
fill 101 256 512 104 256 512 minecraft:blackstone
fill 102 256 511 105 256 511 minecraft:blackstone
setblock 105 256 512 minecraft:smooth_basalt
setblock 105 256 513 minecraft:light[level=12]
setblock 105 256 521 minecraft:light[level=12]
setblock 105 256 529 minecraft:light[level=12]
setblock 105 256 537 minecraft:light[level=12]
setblock 105 256 545 minecraft:light[level=12]
setblock 105 256 551 minecraft:blackstone
setblock 106 256 511 minecraft:smooth_basalt
fill 106 256 512 106 259 512 minecraft:blackstone
setblock 106 256 551 minecraft:smooth_basalt
fill 107 256 511 110 256 511 minecraft:blackstone
fill 107 256 513 108 256 513 minecraft:blackstone
fill 107 256 551 107 259 551 minecraft:blackstone
setblock 109 256 513 minecraft:smooth_basalt
setblock 110 256 512 minecraft:smooth_basalt
fill 110 256 513 113 256 513 minecraft:blackstone
setblock 111 256 511 minecraft:smooth_basalt
fill 111 256 512 111 259 512 minecraft:blackstone
fill 111 256 514 112 256 514 minecraft:blackstone
setblock 111 256 551 minecraft:smooth_basalt
fill 112 256 511 112 259 511 minecraft:blackstone
setblock 112 256 549 minecraft:blackstone
setblock 112 256 550 minecraft:smooth_basalt
fill 112 256 551 112 259 551 minecraft:blackstone
setblock 113 256 514 minecraft:smooth_basalt
setblock 113 256 521 minecraft:light[level=12]
setblock 113 256 529 minecraft:light[level=12]
setblock 113 256 537 minecraft:light[level=12]
setblock 113 256 545 minecraft:light[level=12]
setblock 113 256 549 minecraft:smooth_basalt
fill 113 256 550 113 259 550 minecraft:blackstone
setblock 114 256 513 minecraft:smooth_basalt
fill 114 256 514 115 258 514 minecraft:blackstone
fill 114 256 549 114 259 549 minecraft:blackstone
setblock 115 256 512 minecraft:smooth_basalt
fill 115 256 513 115 259 513 minecraft:blackstone
setblock 116 256 511 minecraft:smooth_basalt
fill 116 256 512 116 259 512 minecraft:blackstone
setblock 116 256 551 minecraft:smooth_basalt
fill 117 256 511 117 259 511 minecraft:blackstone
setblock 117 256 550 minecraft:smooth_basalt
fill 117 256 551 120 256 551 minecraft:blackstone
setblock 118 256 549 minecraft:smooth_basalt
fill 118 256 550 121 256 550 minecraft:blackstone
setblock 119 256 513 minecraft:smooth_basalt
setblock 120 256 512 minecraft:smooth_basalt
setblock 121 256 511 minecraft:smooth_basalt
fill 121 256 512 122 258 512 minecraft:blackstone
setblock 121 256 513 minecraft:light[level=12]
setblock 121 256 521 minecraft:light[level=12]
setblock 121 256 529 minecraft:light[level=12]
setblock 121 256 537 minecraft:light[level=12]
setblock 121 256 545 minecraft:light[level=12]
setblock 121 256 551 minecraft:smooth_basalt
fill 122 256 511 125 256 511 minecraft:blackstone
setblock 122 256 550 minecraft:smooth_basalt
fill 122 256 551 122 259 551 minecraft:blackstone
fill 123 256 550 123 258 550 minecraft:blackstone
setblock 126 256 511 minecraft:smooth_basalt
setblock 126 256 551 minecraft:smooth_basalt
fill 127 256 511 127 259 511 minecraft:blackstone
setblock 127 256 550 minecraft:smooth_basalt
fill 127 256 551 127 259 551 minecraft:blackstone
fill 128 256 512 129 256 512 minecraft:blackstone
fill 128 256 550 128 259 550 minecraft:blackstone
setblock 129 256 521 minecraft:light[level=12]
setblock 129 256 529 minecraft:light[level=12]
setblock 129 256 537 minecraft:light[level=12]
setblock 129 256 545 minecraft:light[level=12]
setblock 130 256 512 minecraft:smooth_basalt
setblock 131 256 511 minecraft:smooth_basalt
fill 131 256 512 131 259 512 minecraft:blackstone
setblock 131 256 551 minecraft:smooth_basalt
fill 132 256 511 132 259 511 minecraft:blackstone
fill 132 256 531 132 256 534 minecraft:blackstone
setblock 132 256 535 minecraft:smooth_basalt
fill 132 256 536 133 258 536 minecraft:blackstone
setblock 132 256 550 minecraft:smooth_basalt
fill 132 256 551 132 259 551 minecraft:blackstone
setblock 133 256 528 minecraft:blackstone
setblock 133 256 529 minecraft:smooth_basalt
fill 133 256 530 133 259 530 minecraft:blackstone
setblock 133 256 533 minecraft:blackstone
setblock 133 256 534 minecraft:smooth_basalt
fill 133 256 535 133 259 535 minecraft:blackstone
fill 133 256 537 133 256 538 minecraft:blackstone
setblock 133 256 539 minecraft:smooth_basalt
fill 133 256 540 133 258 541 minecraft:blackstone
setblock 133 256 549 minecraft:smooth_basalt
fill 133 256 550 133 259 550 minecraft:blackstone
setblock 134 256 513 minecraft:smooth_basalt
fill 134 256 514 134 258 515 minecraft:blackstone
setblock 134 256 528 minecraft:smooth_basalt
fill 134 256 529 134 259 529 minecraft:blackstone
setblock 134 256 533 minecraft:smooth_basalt
fill 134 256 534 134 259 534 minecraft:blackstone
setblock 134 256 538 minecraft:smooth_basalt
fill 134 256 539 134 259 539 minecraft:blackstone
setblock 134 256 543 minecraft:smooth_basalt
fill 134 256 544 134 259 544 minecraft:blackstone
setblock 134 256 548 minecraft:smooth_basalt
fill 134 256 549 134 259 549 minecraft:blackstone
setblock 135 256 512 minecraft:smooth_basalt
fill 135 256 513 135 259 513 minecraft:blackstone
setblock 135 256 516 minecraft:blackstone
setblock 135 256 517 minecraft:smooth_basalt
fill 135 256 518 135 256 521 minecraft:blackstone
setblock 135 256 522 minecraft:smooth_basalt
fill 135 256 523 135 259 523 minecraft:blackstone
setblock 135 256 527 minecraft:smooth_basalt
fill 135 256 528 135 259 528 minecraft:blackstone
setblock 135 256 532 minecraft:smooth_basalt
fill 135 256 533 135 259 533 minecraft:blackstone
setblock 135 256 537 minecraft:smooth_basalt
fill 135 256 538 135 259 538 minecraft:blackstone
setblock 135 256 542 minecraft:smooth_basalt
fill 135 256 543 135 259 543 minecraft:blackstone
setblock 135 256 547 minecraft:smooth_basalt
fill 135 256 548 135 259 548 minecraft:blackstone
setblock 95 257 511 minecraft:smooth_basalt
fill 95 257 512 95 257 515 minecraft:blackstone
setblock 95 257 516 minecraft:smooth_basalt
fill 95 257 517 95 257 520 minecraft:blackstone
setblock 95 257 521 minecraft:smooth_basalt
fill 95 257 522 95 260 522 minecraft:blackstone
setblock 95 257 526 minecraft:smooth_basalt
fill 95 257 527 95 260 527 minecraft:blackstone
setblock 95 257 531 minecraft:smooth_basalt
fill 95 257 532 95 260 532 minecraft:blackstone
setblock 95 257 536 minecraft:smooth_basalt
fill 95 257 537 95 257 540 minecraft:blackstone
setblock 95 257 541 minecraft:smooth_basalt
fill 95 257 542 95 260 542 minecraft:blackstone
setblock 95 257 546 minecraft:smooth_basalt
fill 95 257 547 95 258 547 minecraft:blackstone
setblock 95 257 551 minecraft:smooth_basalt
fill 96 257 511 96 257 514 minecraft:blackstone
setblock 96 257 515 minecraft:smooth_basalt
fill 96 257 516 96 257 519 minecraft:blackstone
setblock 96 257 520 minecraft:smooth_basalt
fill 96 257 521 96 260 521 minecraft:blackstone
setblock 96 257 525 minecraft:smooth_basalt
fill 96 257 526 96 260 526 minecraft:blackstone
setblock 96 257 530 minecraft:smooth_basalt
fill 96 257 531 96 260 531 minecraft:blackstone
setblock 96 257 535 minecraft:smooth_basalt
fill 96 257 536 96 260 536 minecraft:blackstone
fill 96 257 551 96 259 551 minecraft:blackstone
setblock 97 257 513 minecraft:blackstone
fill 97 257 514 98 257 514 minecraft:smooth_basalt
setblock 97 257 529 minecraft:smooth_basalt
fill 97 257 530 97 259 530 minecraft:blackstone
setblock 97 257 534 minecraft:smooth_basalt
fill 97 257 535 97 260 535 minecraft:blackstone
fill 98 257 513 98 273 513 minecraft:smooth_basalt
setblock 99 257 512 minecraft:smooth_basalt
setblock 100 257 511 minecraft:smooth_basalt
fill 100 257 512 103 257 512 minecraft:blackstone
fill 101 257 511 104 257 511 minecraft:blackstone
setblock 104 257 512 minecraft:smooth_basalt
setblock 105 257 511 minecraft:smooth_basalt
fill 105 257 512 105 260 512 minecraft:blackstone
setblock 105 257 551 minecraft:smooth_basalt
fill 106 257 511 109 257 511 minecraft:blackstone
fill 106 257 513 107 257 513 minecraft:blackstone
fill 106 257 551 106 260 551 minecraft:blackstone
setblock 108 257 513 minecraft:smooth_basalt
fill 108 257 550 108 259 550 minecraft:blackstone
setblock 109 257 512 minecraft:smooth_basalt
fill 109 257 513 111 257 514 minecraft:blackstone
setblock 110 257 511 minecraft:smooth_basalt
fill 110 257 512 110 260 512 minecraft:blackstone
setblock 110 257 551 minecraft:smooth_basalt
fill 111 257 511 111 260 511 minecraft:blackstone
setblock 111 257 550 minecraft:smooth_basalt
fill 111 257 551 111 260 551 minecraft:blackstone
setblock 112 257 513 minecraft:blackstone
setblock 112 257 514 minecraft:smooth_basalt
setblock 112 257 549 minecraft:smooth_basalt
fill 112 257 550 112 260 550 minecraft:blackstone
setblock 113 257 513 minecraft:smooth_basalt
fill 113 257 514 113 260 514 minecraft:blackstone
fill 113 257 549 113 259 549 minecraft:blackstone
setblock 114 257 512 minecraft:smooth_basalt
fill 114 257 513 114 260 513 minecraft:blackstone
setblock 115 257 511 minecraft:smooth_basalt
fill 115 257 512 115 260 512 minecraft:blackstone
setblock 115 257 551 minecraft:smooth_basalt
fill 116 257 511 116 260 511 minecraft:blackstone
setblock 116 257 514 minecraft:blackstone
setblock 116 257 550 minecraft:smooth_basalt
fill 116 257 551 119 257 551 minecraft:blackstone
setblock 117 257 513 minecraft:blackstone
setblock 117 257 549 minecraft:smooth_basalt
fill 117 257 550 120 257 550 minecraft:blackstone
setblock 118 257 513 minecraft:smooth_basalt
setblock 119 257 512 minecraft:smooth_basalt
fill 119 257 513 119 258 513 minecraft:blackstone
setblock 120 257 511 minecraft:smooth_basalt
fill 120 257 512 120 260 512 minecraft:blackstone
setblock 120 257 551 minecraft:smooth_basalt
fill 121 257 511 124 257 511 minecraft:blackstone
setblock 121 257 550 minecraft:smooth_basalt
fill 121 257 551 121 260 551 minecraft:blackstone
fill 122 257 550 122 258 550 minecraft:blackstone
setblock 123 257 512 minecraft:blackstone
setblock 125 257 511 minecraft:smooth_basalt
setblock 125 257 551 minecraft:smooth_basalt
fill 126 257 511 126 259 512 minecraft:blackstone
setblock 126 257 550 minecraft:smooth_basalt
fill 126 257 551 126 260 551 minecraft:blackstone
fill 127 257 512 128 257 512 minecraft:blackstone
fill 127 257 550 127 260 550 minecraft:blackstone
setblock 129 257 512 minecraft:smooth_basalt
fill 129 257 549 129 258 549 minecraft:blackstone
setblock 130 257 511 minecraft:smooth_basalt
fill 130 257 512 130 260 512 minecraft:blackstone
setblock 130 257 551 minecraft:smooth_basalt
fill 131 257 511 131 260 511 minecraft:blackstone
setblock 131 257 550 minecraft:smooth_basalt
fill 131 257 551 131 260 551 minecraft:blackstone
fill 132 257 530 132 257 533 minecraft:blackstone
setblock 132 257 534 minecraft:smooth_basalt
fill 132 257 535 132 260 535 minecraft:blackstone
fill 132 257 537 132 257 538 minecraft:blackstone
setblock 132 257 549 minecraft:smooth_basalt
fill 132 257 550 132 260 550 minecraft:blackstone
setblock 133 257 512 minecraft:blackstone
setblock 133 257 527 minecraft:blackstone
setblock 133 257 528 minecraft:smooth_basalt
fill 133 257 529 133 260 529 minecraft:blackstone
setblock 133 257 533 minecraft:smooth_basalt
fill 133 257 534 133 260 534 minecraft:blackstone
setblock 133 257 537 minecraft:blackstone
setblock 133 257 538 minecraft:smooth_basalt
fill 133 257 539 133 260 539 minecraft:blackstone
setblock 133 257 542 minecraft:blackstone
setblock 133 257 548 minecraft:smooth_basalt
fill 133 257 549 133 258 549 minecraft:blackstone
setblock 134 257 512 minecraft:smooth_basalt
fill 134 257 513 134 260 513 minecraft:blackstone
setblock 134 257 516 minecraft:blackstone
setblock 134 257 527 minecraft:smooth_basalt
fill 134 257 528 134 260 528 minecraft:blackstone
setblock 134 257 532 minecraft:smooth_basalt
fill 134 257 533 134 260 533 minecraft:blackstone
setblock 134 257 537 minecraft:smooth_basalt
fill 134 257 538 134 260 538 minecraft:blackstone
setblock 134 257 542 minecraft:smooth_basalt
fill 134 257 543 134 260 543 minecraft:blackstone
setblock 134 257 547 minecraft:smooth_basalt
fill 134 257 548 134 259 548 minecraft:blackstone
setblock 135 257 511 minecraft:smooth_basalt
fill 135 257 512 135 260 512 minecraft:blackstone
setblock 135 257 516 minecraft:smooth_basalt
fill 135 257 517 135 257 520 minecraft:blackstone
setblock 135 257 521 minecraft:smooth_basalt
fill 135 257 522 135 260 522 minecraft:blackstone
setblock 135 257 526 minecraft:smooth_basalt
fill 135 257 527 135 260 527 minecraft:blackstone
setblock 135 257 531 minecraft:smooth_basalt
fill 135 257 532 135 260 532 minecraft:blackstone
setblock 135 257 536 minecraft:smooth_basalt
fill 135 257 537 135 260 537 minecraft:blackstone
setblock 135 257 541 minecraft:smooth_basalt
fill 135 257 542 135 260 542 minecraft:blackstone
setblock 135 257 546 minecraft:smooth_basalt
fill 135 257 547 135 260 547 minecraft:blackstone
setblock 135 257 551 minecraft:smooth_basalt
fill 95 258 511 95 258 514 minecraft:blackstone
setblock 95 258 515 minecraft:smooth_basalt
fill 95 258 516 95 258 519 minecraft:blackstone
setblock 95 258 520 minecraft:smooth_basalt
fill 95 258 521 95 261 521 minecraft:blackstone
setblock 95 258 525 minecraft:smooth_basalt
fill 95 258 526 95 261 526 minecraft:blackstone
setblock 95 258 530 minecraft:smooth_basalt
fill 95 258 531 95 261 531 minecraft:blackstone
setblock 95 258 535 minecraft:smooth_basalt
fill 95 258 536 95 258 539 minecraft:blackstone
setblock 95 258 540 minecraft:smooth_basalt
fill 95 258 541 95 261 541 minecraft:blackstone
setblock 95 258 545 minecraft:smooth_basalt
setblock 95 258 546 minecraft:blackstone
setblock 95 258 550 minecraft:smooth_basalt
fill 95 258 551 95 260 551 minecraft:blackstone
fill 96 258 511 96 258 513 minecraft:blackstone
setblock 96 258 514 minecraft:smooth_basalt
fill 96 258 515 96 258 518 minecraft:blackstone
setblock 96 258 519 minecraft:smooth_basalt
fill 96 258 520 96 261 520 minecraft:blackstone
setblock 96 258 524 minecraft:smooth_basalt
fill 96 258 525 96 260 525 minecraft:blackstone
setblock 96 258 529 minecraft:smooth_basalt
fill 96 258 530 96 261 530 minecraft:blackstone
setblock 96 258 534 minecraft:smooth_basalt
fill 96 258 535 96 261 535 minecraft:blackstone
setblock 96 258 538 minecraft:blackstone
setblock 96 258 539 minecraft:smooth_basalt
setblock 96 258 540 minecraft:blackstone
setblock 97 258 513 minecraft:smooth_basalt
fill 97 258 514 97 260 515 minecraft:blackstone
setblock 97 258 528 minecraft:smooth_basalt
fill 97 258 529 97 259 529 minecraft:blackstone
setblock 97 258 533 minecraft:smooth_basalt
fill 97 258 534 97 260 534 minecraft:blackstone
setblock 98 258 512 minecraft:smooth_basalt
fill 98 258 514 98 273 514 minecraft:smooth_basalt
setblock 99 258 511 minecraft:smooth_basalt
fill 99 258 512 102 258 512 minecraft:blackstone
fill 100 258 511 103 258 511 minecraft:blackstone
setblock 103 258 512 minecraft:smooth_basalt
setblock 104 258 511 minecraft:smooth_basalt
fill 104 258 512 104 260 513 minecraft:blackstone
setblock 104 258 551 minecraft:smooth_basalt
fill 105 258 511 108 258 511 minecraft:blackstone
fill 105 258 513 106 258 513 minecraft:blackstone
fill 105 258 551 105 261 551 minecraft:blackstone
setblock 107 258 513 minecraft:smooth_basalt
setblock 108 258 512 minecraft:smooth_basalt
fill 108 258 513 110 258 514 minecraft:blackstone
setblock 109 258 511 minecraft:smooth_basalt
fill 109 258 512 109 261 512 minecraft:blackstone
setblock 109 258 551 minecraft:smooth_basalt
fill 110 258 511 110 261 511 minecraft:blackstone
setblock 110 258 550 minecraft:smooth_basalt
fill 110 258 551 110 261 551 minecraft:blackstone
setblock 111 258 513 minecraft:blackstone
setblock 111 258 514 minecraft:smooth_basalt
setblock 111 258 549 minecraft:smooth_basalt
fill 111 258 550 111 261 550 minecraft:blackstone
setblock 112 258 513 minecraft:smooth_basalt
fill 112 258 514 112 261 514 minecraft:blackstone
fill 112 258 549 112 259 549 minecraft:blackstone
setblock 113 258 512 minecraft:smooth_basalt
fill 113 258 513 113 261 513 minecraft:blackstone
setblock 114 258 511 minecraft:smooth_basalt
fill 114 258 512 114 261 512 minecraft:blackstone
setblock 114 258 551 minecraft:smooth_basalt
fill 115 258 511 115 261 511 minecraft:blackstone
setblock 115 258 550 minecraft:smooth_basalt
fill 115 258 551 118 258 551 minecraft:blackstone
setblock 116 258 514 minecraft:smooth_basalt
setblock 116 258 549 minecraft:smooth_basalt
fill 116 258 550 119 258 550 minecraft:blackstone
setblock 117 258 513 minecraft:smooth_basalt
setblock 118 258 512 minecraft:smooth_basalt
fill 118 258 513 118 259 513 minecraft:blackstone
setblock 119 258 511 minecraft:smooth_basalt
fill 119 258 512 119 261 512 minecraft:blackstone
setblock 119 258 551 minecraft:smooth_basalt
fill 120 258 511 123 258 511 minecraft:blackstone
setblock 120 258 550 minecraft:smooth_basalt
fill 120 258 551 120 261 551 minecraft:blackstone
fill 121 258 550 121 259 550 minecraft:blackstone
setblock 123 258 512 minecraft:smooth_basalt
setblock 124 258 511 minecraft:smooth_basalt
fill 124 258 512 125 259 512 minecraft:blackstone
setblock 124 258 551 minecraft:smooth_basalt
fill 125 258 511 125 261 511 minecraft:blackstone
setblock 125 258 550 minecraft:smooth_basalt
fill 125 258 551 125 261 551 minecraft:blackstone
fill 126 258 550 126 260 550 minecraft:blackstone
setblock 127 258 512 minecraft:blackstone
setblock 128 258 512 minecraft:smooth_basalt
setblock 129 258 511 minecraft:smooth_basalt
fill 129 258 512 129 261 512 minecraft:blackstone
setblock 129 258 551 minecraft:smooth_basalt
fill 130 258 511 130 261 511 minecraft:blackstone
setblock 130 258 513 minecraft:smooth_basalt
setblock 130 258 550 minecraft:smooth_basalt
fill 130 258 551 130 261 551 minecraft:blackstone
setblock 131 258 513 minecraft:blackstone
setblock 131 258 549 minecraft:smooth_basalt
fill 131 258 550 131 261 550 minecraft:blackstone
setblock 132 258 513 minecraft:smooth_basalt
fill 132 258 530 132 258 532 minecraft:blackstone
setblock 132 258 533 minecraft:smooth_basalt
fill 132 258 534 132 261 534 minecraft:blackstone
setblock 132 258 537 minecraft:blackstone
setblock 132 258 538 minecraft:smooth_basalt
fill 132 258 539 132 261 539 minecraft:blackstone
setblock 132 258 549 minecraft:blackstone
setblock 133 258 512 minecraft:smooth_basalt
fill 133 258 513 133 260 514 minecraft:blackstone
setblock 133 258 527 minecraft:smooth_basalt
fill 133 258 528 133 260 528 minecraft:blackstone
setblock 133 258 532 minecraft:smooth_basalt
fill 133 258 533 133 261 533 minecraft:blackstone
setblock 133 258 537 minecraft:smooth_basalt
fill 133 258 538 133 261 538 minecraft:blackstone
setblock 133 258 542 minecraft:smooth_basalt
fill 133 258 543 133 260 543 minecraft:blackstone
setblock 134 258 511 minecraft:smooth_basalt
fill 134 258 512 134 261 512 minecraft:blackstone
setblock 134 258 516 minecraft:smooth_basalt
fill 134 258 517 135 259 518 minecraft:blackstone
setblock 134 258 526 minecraft:smooth_basalt
fill 134 258 527 134 261 527 minecraft:blackstone
setblock 134 258 531 minecraft:smooth_basalt
fill 134 258 532 134 261 532 minecraft:blackstone
setblock 134 258 536 minecraft:smooth_basalt
fill 134 258 537 134 261 537 minecraft:blackstone
setblock 134 258 541 minecraft:smooth_basalt
fill 134 258 542 134 261 542 minecraft:blackstone
setblock 134 258 546 minecraft:smooth_basalt
fill 134 258 547 134 259 547 minecraft:blackstone
setblock 134 258 551 minecraft:smooth_basalt
fill 135 258 511 135 261 511 minecraft:blackstone
setblock 135 258 515 minecraft:smooth_basalt
fill 135 258 516 135 261 516 minecraft:blackstone
setblock 135 258 519 minecraft:blackstone
setblock 135 258 520 minecraft:smooth_basalt
fill 135 258 521 135 261 521 minecraft:blackstone
setblock 135 258 525 minecraft:smooth_basalt
fill 135 258 526 135 261 526 minecraft:blackstone
setblock 135 258 530 minecraft:smooth_basalt
fill 135 258 531 135 261 531 minecraft:blackstone
setblock 135 258 535 minecraft:smooth_basalt
fill 135 258 536 135 261 536 minecraft:blackstone
setblock 135 258 540 minecraft:smooth_basalt
fill 135 258 541 135 261 541 minecraft:blackstone
setblock 135 258 545 minecraft:smooth_basalt
fill 135 258 546 135 261 546 minecraft:blackstone
setblock 135 258 550 minecraft:smooth_basalt
fill 135 258 551 135 261 551 minecraft:blackstone
fill 95 259 511 95 259 513 minecraft:blackstone
setblock 95 259 514 minecraft:smooth_basalt
fill 95 259 515 95 259 518 minecraft:blackstone
setblock 95 259 519 minecraft:smooth_basalt
fill 95 259 520 95 262 520 minecraft:blackstone
setblock 95 259 524 minecraft:smooth_basalt
fill 95 259 525 95 262 525 minecraft:blackstone
setblock 95 259 529 minecraft:smooth_basalt
fill 95 259 530 95 262 530 minecraft:blackstone
setblock 95 259 534 minecraft:smooth_basalt
fill 95 259 535 95 259 538 minecraft:blackstone
setblock 95 259 539 minecraft:smooth_basalt
fill 95 259 540 95 262 540 minecraft:blackstone
setblock 95 259 549 minecraft:smooth_basalt
setblock 95 259 550 minecraft:blackstone
fill 96 259 511 96 259 512 minecraft:blackstone
setblock 96 259 513 minecraft:smooth_basalt
fill 96 259 514 96 259 517 minecraft:blackstone
setblock 96 259 518 minecraft:smooth_basalt
fill 96 259 519 96 262 519 minecraft:blackstone
setblock 96 259 523 minecraft:smooth_basalt
fill 96 259 524 96 260 524 minecraft:blackstone
setblock 96 259 528 minecraft:smooth_basalt
fill 96 259 529 96 261 529 minecraft:blackstone
setblock 96 259 533 minecraft:smooth_basalt
fill 96 259 534 96 262 534 minecraft:blackstone
setblock 96 259 538 minecraft:smooth_basalt
fill 96 259 539 96 261 539 minecraft:blackstone
setblock 97 259 512 minecraft:smooth_basalt
setblock 97 259 513 minecraft:blackstone
setblock 97 259 516 minecraft:blackstone
setblock 97 259 532 minecraft:smooth_basalt
fill 97 259 533 97 260 533 minecraft:blackstone
setblock 98 259 511 minecraft:smooth_basalt
fill 98 259 512 101 259 512 minecraft:blackstone
fill 99 259 511 102 259 511 minecraft:blackstone
setblock 102 259 512 minecraft:smooth_basalt
setblock 103 259 511 minecraft:smooth_basalt
fill 103 259 512 103 261 513 minecraft:blackstone
fill 104 259 511 107 259 511 minecraft:blackstone
setblock 104 259 551 minecraft:blackstone
setblock 105 259 513 minecraft:blackstone
setblock 106 259 513 minecraft:smooth_basalt
setblock 107 259 512 minecraft:smooth_basalt
fill 107 259 513 109 259 514 minecraft:blackstone
setblock 108 259 511 minecraft:smooth_basalt
fill 108 259 512 108 262 512 minecraft:blackstone
setblock 108 259 551 minecraft:smooth_basalt
fill 109 259 511 109 262 511 minecraft:blackstone
setblock 109 259 550 minecraft:smooth_basalt
fill 109 259 551 109 262 551 minecraft:blackstone
setblock 110 259 513 minecraft:blackstone
setblock 110 259 514 minecraft:smooth_basalt
fill 110 259 550 110 262 550 minecraft:blackstone
setblock 111 259 513 minecraft:smooth_basalt
fill 111 259 514 111 262 514 minecraft:blackstone
setblock 112 259 512 minecraft:smooth_basalt
fill 112 259 513 112 262 513 minecraft:blackstone
setblock 113 259 511 minecraft:smooth_basalt
fill 113 259 512 113 262 512 minecraft:blackstone
setblock 113 259 551 minecraft:smooth_basalt
fill 114 259 511 114 262 511 minecraft:blackstone
setblock 114 259 514 minecraft:blackstone
setblock 114 259 550 minecraft:smooth_basalt
fill 114 259 551 117 259 551 minecraft:blackstone
setblock 115 259 514 minecraft:smooth_basalt
setblock 115 259 549 minecraft:smooth_basalt
fill 115 259 550 118 259 550 minecraft:blackstone
setblock 116 259 513 minecraft:smooth_basalt
setblock 116 259 514 minecraft:blackstone
setblock 117 259 512 minecraft:smooth_basalt
fill 117 259 513 117 260 513 minecraft:blackstone
setblock 118 259 511 minecraft:smooth_basalt
fill 118 259 512 118 261 512 minecraft:blackstone
setblock 118 259 551 minecraft:smooth_basalt
fill 119 259 511 122 259 511 minecraft:blackstone
setblock 119 259 550 minecraft:smooth_basalt
fill 119 259 551 119 262 551 minecraft:blackstone
setblock 120 259 550 minecraft:blackstone
setblock 121 259 512 minecraft:blackstone
setblock 122 259 512 minecraft:smooth_basalt
setblock 123 259 511 minecraft:smooth_basalt
setblock 123 259 512 minecraft:blackstone
setblock 123 259 551 minecraft:smooth_basalt
fill 124 259 511 124 262 511 minecraft:blackstone
setblock 124 259 550 minecraft:smooth_basalt
fill 124 259 551 124 262 551 minecraft:blackstone
fill 125 259 550 125 260 550 minecraft:blackstone
setblock 127 259 512 minecraft:smooth_basalt
setblock 128 259 511 minecraft:smooth_basalt
fill 128 259 512 128 262 512 minecraft:blackstone
setblock 128 259 551 minecraft:smooth_basalt
fill 129 259 511 129 262 511 minecraft:blackstone
setblock 129 259 550 minecraft:smooth_basalt
fill 129 259 551 129 262 551 minecraft:blackstone
setblock 130 259 513 minecraft:blackstone
setblock 130 259 549 minecraft:smooth_basalt
fill 130 259 550 130 262 550 minecraft:blackstone
setblock 131 259 513 minecraft:smooth_basalt
fill 131 259 534 131 260 536 minecraft:blackstone
setblock 131 259 549 minecraft:blackstone
setblock 132 259 512 minecraft:smooth_basalt
fill 132 259 513 132 260 513 minecraft:blackstone
fill 132 259 530 132 259 531 minecraft:blackstone
setblock 132 259 532 minecraft:smooth_basalt
fill 132 259 533 132 262 533 minecraft:blackstone
setblock 132 259 536 minecraft:blackstone
setblock 132 259 537 minecraft:smooth_basalt
fill 132 259 538 132 262 538 minecraft:blackstone
fill 132 259 540 133 259 540 minecraft:blackstone
setblock 133 259 511 minecraft:smooth_basalt
fill 133 259 512 133 262 512 minecraft:blackstone
setblock 133 259 531 minecraft:smooth_basalt
fill 133 259 532 133 262 532 minecraft:blackstone
setblock 133 259 536 minecraft:smooth_basalt
fill 133 259 537 133 262 537 minecraft:blackstone
setblock 133 259 541 minecraft:smooth_basalt
fill 133 259 542 133 262 542 minecraft:blackstone
setblock 133 259 551 minecraft:smooth_basalt
fill 134 259 511 134 262 511 minecraft:blackstone
setblock 134 259 514 minecraft:blackstone
setblock 134 259 515 minecraft:smooth_basalt
fill 134 259 516 134 262 516 minecraft:blackstone
setblock 134 259 519 minecraft:blackstone
setblock 134 259 525 minecraft:smooth_basalt
fill 134 259 526 134 260 526 minecraft:blackstone
setblock 134 259 530 minecraft:smooth_basalt
fill 134 259 531 134 262 531 minecraft:blackstone
setblock 134 259 535 minecraft:smooth_basalt
fill 134 259 536 134 262 536 minecraft:blackstone
setblock 134 259 540 minecraft:smooth_basalt
fill 134 259 541 134 262 541 minecraft:blackstone
setblock 134 259 545 minecraft:smooth_basalt
fill 134 259 546 134 260 546 minecraft:blackstone
setblock 134 259 550 minecraft:smooth_basalt
fill 134 259 551 134 262 551 minecraft:blackstone
setblock 135 259 514 minecraft:smooth_basalt
fill 135 259 515 135 262 515 minecraft:blackstone
setblock 135 259 519 minecraft:smooth_basalt
fill 135 259 520 135 262 520 minecraft:blackstone
setblock 135 259 524 minecraft:smooth_basalt
fill 135 259 525 135 262 525 minecraft:blackstone
setblock 135 259 529 minecraft:smooth_basalt
fill 135 259 530 135 262 530 minecraft:blackstone
setblock 135 259 534 minecraft:smooth_basalt
fill 135 259 535 135 262 535 minecraft:blackstone
setblock 135 259 539 minecraft:smooth_basalt
fill 135 259 540 135 262 540 minecraft:blackstone
setblock 135 259 544 minecraft:smooth_basalt
fill 135 259 545 135 262 545 minecraft:blackstone
setblock 135 259 549 minecraft:smooth_basalt
fill 135 259 550 135 261 550 minecraft:blackstone
fill 95 260 511 95 260 512 minecraft:blackstone
setblock 95 260 513 minecraft:smooth_basalt
fill 95 260 514 95 260 517 minecraft:blackstone
setblock 95 260 518 minecraft:smooth_basalt
fill 95 260 519 95 263 519 minecraft:blackstone
setblock 95 260 523 minecraft:smooth_basalt
fill 95 260 524 95 263 524 minecraft:blackstone
setblock 95 260 528 minecraft:smooth_basalt
fill 95 260 529 95 263 529 minecraft:blackstone
setblock 95 260 533 minecraft:smooth_basalt
fill 95 260 534 95 260 537 minecraft:blackstone
setblock 95 260 538 minecraft:smooth_basalt
fill 95 260 539 95 263 539 minecraft:blackstone
setblock 95 260 543 minecraft:smooth_basalt
setblock 96 260 511 minecraft:blackstone
setblock 96 260 512 minecraft:smooth_basalt
fill 96 260 513 96 260 516 minecraft:blackstone
setblock 96 260 517 minecraft:smooth_basalt
fill 96 260 518 96 263 518 minecraft:blackstone
setblock 96 260 522 minecraft:smooth_basalt
setblock 96 260 523 minecraft:blackstone
setblock 96 260 527 minecraft:smooth_basalt
fill 96 260 528 96 261 528 minecraft:blackstone
setblock 96 260 532 minecraft:smooth_basalt
fill 96 260 533 96 262 533 minecraft:blackstone
setblock 96 260 537 minecraft:smooth_basalt
fill 96 260 538 96 262 538 minecraft:blackstone
setblock 97 260 511 minecraft:smooth_basalt
fill 97 260 512 100 260 512 minecraft:blackstone
fill 97 260 513 97 273 513 minecraft:smooth_basalt
setblock 97 260 516 minecraft:smooth_basalt
setblock 97 260 532 minecraft:blackstone
fill 98 260 511 101 260 511 minecraft:blackstone
setblock 101 260 512 minecraft:smooth_basalt
setblock 102 260 511 minecraft:smooth_basalt
fill 102 260 512 102 263 512 minecraft:blackstone
fill 103 260 511 106 260 511 minecraft:blackstone
setblock 105 260 513 minecraft:smooth_basalt
setblock 106 260 512 minecraft:smooth_basalt
fill 106 260 513 108 260 514 minecraft:blackstone
setblock 107 260 511 minecraft:smooth_basalt
fill 107 260 512 107 263 512 minecraft:blackstone
setblock 107 260 551 minecraft:smooth_basalt
fill 108 260 511 108 263 511 minecraft:blackstone
setblock 108 260 550 minecraft:smooth_basalt
fill 108 260 551 108 263 551 minecraft:blackstone
setblock 109 260 513 minecraft:blackstone
setblock 109 260 514 minecraft:smooth_basalt
fill 109 260 550 109 263 550 minecraft:blackstone
setblock 110 260 513 minecraft:smooth_basalt
fill 110 260 514 110 260 515 minecraft:blackstone
setblock 111 260 512 minecraft:smooth_basalt
fill 111 260 513 111 263 513 minecraft:blackstone
setblock 111 260 515 minecraft:blackstone
setblock 112 260 511 minecraft:smooth_basalt
fill 112 260 512 112 263 512 minecraft:blackstone
setblock 112 260 551 minecraft:smooth_basalt
fill 113 260 511 113 263 511 minecraft:blackstone
setblock 113 260 550 minecraft:smooth_basalt
fill 113 260 551 116 260 551 minecraft:blackstone
setblock 114 260 514 minecraft:smooth_basalt
fill 114 260 550 117 260 550 minecraft:blackstone
setblock 115 260 513 minecraft:smooth_basalt
setblock 115 260 514 minecraft:blackstone
setblock 116 260 512 minecraft:smooth_basalt
fill 116 260 513 116 261 513 minecraft:blackstone
setblock 117 260 511 minecraft:smooth_basalt
fill 117 260 512 117 262 512 minecraft:blackstone
setblock 117 260 551 minecraft:smooth_basalt
fill 118 260 511 121 260 511 minecraft:blackstone
setblock 118 260 550 minecraft:smooth_basalt
fill 118 260 551 118 262 551 minecraft:blackstone
setblock 121 260 512 minecraft:smooth_basalt
setblock 122 260 511 minecraft:smooth_basalt
setblock 122 260 551 minecraft:smooth_basalt
fill 123 260 511 123 262 511 minecraft:blackstone
fill 123 260 551 123 262 551 minecraft:blackstone
setblock 125 260 512 minecraft:blackstone
setblock 126 260 511 minecraft:blackstone
setblock 126 260 512 minecraft:smooth_basalt
setblock 127 260 511 minecraft:smooth_basalt
fill 127 260 512 127 262 512 minecraft:blackstone
setblock 127 260 551 minecraft:smooth_basalt
fill 128 260 511 128 263 511 minecraft:blackstone
setblock 128 260 550 minecraft:smooth_basalt
fill 128 260 551 128 263 551 minecraft:blackstone
fill 129 260 550 129 262 550 minecraft:blackstone
fill 130 260 513 130 273 513 minecraft:smooth_basalt
setblock 131 260 512 minecraft:smooth_basalt
setblock 131 260 513 minecraft:blackstone
setblock 131 260 537 minecraft:smooth_basalt
setblock 132 260 511 minecraft:smooth_basalt
fill 132 260 512 132 262 512 minecraft:blackstone
setblock 132 260 531 minecraft:smooth_basalt
fill 132 260 532 132 261 532 minecraft:blackstone
setblock 132 260 536 minecraft:smooth_basalt
fill 132 260 537 132 263 537 minecraft:blackstone
setblock 132 260 540 minecraft:blackstone
setblock 132 260 551 minecraft:smooth_basalt
fill 133 260 511 133 263 511 minecraft:blackstone
setblock 133 260 530 minecraft:smooth_basalt
fill 133 260 531 133 262 531 minecraft:blackstone
setblock 133 260 535 minecraft:smooth_basalt
fill 133 260 536 133 263 536 minecraft:blackstone
setblock 133 260 540 minecraft:smooth_basalt
fill 133 260 541 133 263 541 minecraft:blackstone
setblock 133 260 550 minecraft:smooth_basalt
fill 133 260 551 133 262 551 minecraft:blackstone
setblock 134 260 514 minecraft:smooth_basalt
fill 134 260 515 134 263 515 minecraft:blackstone
fill 134 260 517 134 260 518 minecraft:blackstone
setblock 134 260 519 minecraft:smooth_basalt
setblock 134 260 525 minecraft:blackstone
setblock 134 260 529 minecraft:smooth_basalt
fill 134 260 530 134 263 530 minecraft:blackstone
setblock 134 260 534 minecraft:smooth_basalt
fill 134 260 535 134 263 535 minecraft:blackstone
setblock 134 260 539 minecraft:smooth_basalt
fill 134 260 540 134 263 540 minecraft:blackstone
setblock 134 260 544 minecraft:smooth_basalt
setblock 134 260 545 minecraft:blackstone
setblock 134 260 549 minecraft:smooth_basalt
setblock 134 260 550 minecraft:blackstone
setblock 135 260 513 minecraft:smooth_basalt
fill 135 260 514 135 263 514 minecraft:blackstone
setblock 135 260 517 minecraft:blackstone
setblock 135 260 518 minecraft:smooth_basalt
fill 135 260 519 135 263 519 minecraft:blackstone
setblock 135 260 523 minecraft:smooth_basalt
fill 135 260 524 135 263 524 minecraft:blackstone
setblock 135 260 528 minecraft:smooth_basalt
fill 135 260 529 135 263 529 minecraft:blackstone
setblock 135 260 533 minecraft:smooth_basalt
fill 135 260 534 135 263 534 minecraft:blackstone
setblock 135 260 538 minecraft:smooth_basalt
fill 135 260 539 135 263 539 minecraft:blackstone
setblock 135 260 543 minecraft:smooth_basalt
fill 135 260 544 135 263 544 minecraft:blackstone
setblock 135 260 548 minecraft:smooth_basalt
fill 135 260 549 135 261 549 minecraft:blackstone
setblock 95 261 511 minecraft:blackstone
setblock 95 261 512 minecraft:smooth_basalt
fill 95 261 513 95 261 516 minecraft:blackstone
setblock 95 261 517 minecraft:smooth_basalt
fill 95 261 518 95 264 518 minecraft:blackstone
setblock 95 261 522 minecraft:smooth_basalt
fill 95 261 523 95 264 523 minecraft:blackstone
setblock 95 261 527 minecraft:smooth_basalt
fill 95 261 528 95 263 528 minecraft:blackstone
setblock 95 261 532 minecraft:smooth_basalt
fill 95 261 533 95 261 536 minecraft:blackstone
setblock 95 261 537 minecraft:smooth_basalt
fill 95 261 538 95 264 538 minecraft:blackstone
setblock 95 261 542 minecraft:smooth_basalt
setblock 96 261 511 minecraft:smooth_basalt
fill 96 261 512 96 261 515 minecraft:blackstone
setblock 96 261 516 minecraft:smooth_basalt
fill 96 261 517 96 264 517 minecraft:blackstone
setblock 96 261 521 minecraft:smooth_basalt
setblock 96 261 522 minecraft:blackstone
setblock 96 261 531 minecraft:smooth_basalt
fill 96 261 532 96 262 532 minecraft:blackstone
setblock 96 261 536 minecraft:smooth_basalt
fill 96 261 537 96 262 537 minecraft:blackstone
fill 97 261 511 99 261 512 minecraft:blackstone
fill 97 261 514 97 273 514 minecraft:smooth_basalt
setblock 100 261 511 minecraft:blackstone
setblock 100 261 512 minecraft:smooth_basalt
setblock 101 261 511 minecraft:smooth_basalt
fill 101 261 512 101 262 512 minecraft:blackstone
fill 102 261 511 105 261 511 minecraft:blackstone
setblock 104 261 512 minecraft:blackstone
setblock 104 261 513 minecraft:smooth_basalt
setblock 105 261 512 minecraft:smooth_basalt
fill 105 261 513 108 261 513 minecraft:blackstone
setblock 106 261 511 minecraft:smooth_basalt
fill 106 261 512 106 264 512 minecraft:blackstone
fill 106 261 514 107 261 514 minecraft:blackstone
setblock 106 261 551 minecraft:smooth_basalt
fill 107 261 511 107 264 511 minecraft:blackstone
fill 107 261 551 107 264 551 minecraft:blackstone
setblock 108 261 514 minecraft:smooth_basalt
fill 108 261 550 108 262 550 minecraft:blackstone
setblock 109 261 513 minecraft:smooth_basalt
fill 109 261 514 110 263 514 minecraft:blackstone
setblock 110 261 512 minecraft:smooth_basalt
fill 110 261 513 110 264 513 minecraft:blackstone
setblock 111 261 511 minecraft:smooth_basalt
fill 111 261 512 111 264 512 minecraft:blackstone
setblock 111 261 551 minecraft:smooth_basalt
fill 112 261 511 112 264 511 minecraft:blackstone
setblock 112 261 550 minecraft:smooth_basalt
fill 112 261 551 115 261 551 minecraft:blackstone
setblock 113 261 514 minecraft:smooth_basalt
fill 113 261 550 116 261 550 minecraft:blackstone
setblock 114 261 513 minecraft:smooth_basalt
setblock 114 261 514 minecraft:blackstone
setblock 115 261 512 minecraft:smooth_basalt
fill 115 261 513 115 262 513 minecraft:blackstone
setblock 116 261 511 minecraft:smooth_basalt
fill 116 261 512 116 263 512 minecraft:blackstone
setblock 116 261 551 minecraft:smooth_basalt
fill 117 261 511 120 261 511 minecraft:blackstone
fill 117 261 551 117 263 551 minecraft:blackstone
setblock 121 261 511 minecraft:smooth_basalt
setblock 121 261 551 minecraft:smooth_basalt
fill 122 261 511 122 262 511 minecraft:blackstone
fill 122 261 551 122 262 551 minecraft:blackstone
setblock 126 261 511 minecraft:smooth_basalt
setblock 126 261 512 minecraft:blackstone
setblock 126 261 551 minecraft:smooth_basalt
fill 127 261 511 127 264 511 minecraft:blackstone
setblock 127 261 550 minecraft:smooth_basalt
fill 127 261 551 127 264 551 minecraft:blackstone
fill 128 261 550 128 262 550 minecraft:blackstone
setblock 130 261 512 minecraft:smooth_basalt
setblock 131 261 511 minecraft:smooth_basalt
fill 131 261 512 131 262 512 minecraft:blackstone
fill 131 261 513 132 273 513 minecraft:smooth_basalt
setblock 131 261 535 minecraft:blackstone
setblock 131 261 536 minecraft:smooth_basalt
setblock 131 261 537 minecraft:blackstone
setblock 131 261 551 minecraft:smooth_basalt
fill 132 261 511 132 263 511 minecraft:blackstone
setblock 132 261 535 minecraft:smooth_basalt
fill 132 261 536 132 264 536 minecraft:blackstone
setblock 132 261 540 minecraft:smooth_basalt
setblock 132 261 550 minecraft:smooth_basalt
fill 132 261 551 132 263 551 minecraft:blackstone
setblock 133 261 529 minecraft:smooth_basalt
fill 133 261 530 133 262 530 minecraft:blackstone
setblock 133 261 534 minecraft:smooth_basalt
fill 133 261 535 133 264 535 minecraft:blackstone
setblock 133 261 539 minecraft:smooth_basalt
fill 133 261 540 133 264 540 minecraft:blackstone
setblock 134 261 513 minecraft:smooth_basalt
fill 134 261 514 134 262 514 minecraft:blackstone
setblock 134 261 517 minecraft:blackstone
setblock 134 261 518 minecraft:smooth_basalt
fill 134 261 519 134 263 519 minecraft:blackstone
setblock 134 261 528 minecraft:smooth_basalt
fill 134 261 529 134 262 529 minecraft:blackstone
setblock 134 261 533 minecraft:smooth_basalt
fill 134 261 534 134 264 534 minecraft:blackstone
setblock 134 261 538 minecraft:smooth_basalt
fill 134 261 539 134 264 539 minecraft:blackstone
setblock 134 261 543 minecraft:smooth_basalt
setblock 134 261 544 minecraft:blackstone
setblock 135 261 512 minecraft:smooth_basalt
fill 135 261 513 135 263 513 minecraft:blackstone
setblock 135 261 517 minecraft:smooth_basalt
fill 135 261 518 135 264 518 minecraft:blackstone
setblock 135 261 522 minecraft:smooth_basalt
fill 135 261 523 135 264 523 minecraft:blackstone
setblock 135 261 527 minecraft:smooth_basalt
fill 135 261 528 135 263 528 minecraft:blackstone
setblock 135 261 532 minecraft:smooth_basalt
fill 135 261 533 135 264 533 minecraft:blackstone
setblock 135 261 537 minecraft:smooth_basalt
fill 135 261 538 135 264 538 minecraft:blackstone
setblock 135 261 542 minecraft:smooth_basalt
fill 135 261 543 135 264 543 minecraft:blackstone
setblock 135 261 547 minecraft:smooth_basalt
setblock 95 262 511 minecraft:smooth_basalt
fill 95 262 512 95 262 515 minecraft:blackstone
setblock 95 262 516 minecraft:smooth_basalt
fill 95 262 517 95 265 517 minecraft:blackstone
setblock 95 262 521 minecraft:smooth_basalt
fill 95 262 522 95 265 522 minecraft:blackstone
setblock 95 262 526 minecraft:smooth_basalt
fill 95 262 527 95 263 527 minecraft:blackstone
setblock 95 262 531 minecraft:smooth_basalt
fill 95 262 532 95 262 535 minecraft:blackstone
setblock 95 262 536 minecraft:smooth_basalt
fill 95 262 537 95 265 537 minecraft:blackstone
setblock 95 262 541 minecraft:smooth_basalt
fill 96 262 511 96 262 514 minecraft:blackstone
setblock 96 262 515 minecraft:smooth_basalt
fill 96 262 516 96 265 516 minecraft:blackstone
setblock 96 262 520 minecraft:smooth_basalt
setblock 96 262 521 minecraft:blackstone
setblock 96 262 531 minecraft:blackstone
setblock 96 262 535 minecraft:smooth_basalt
setblock 96 262 536 minecraft:blackstone
fill 97 262 511 99 262 511 minecraft:blackstone
fill 97 262 512 98 273 512 minecraft:smooth_basalt
setblock 100 262 511 minecraft:smooth_basalt
fill 101 262 511 104 262 511 minecraft:blackstone
setblock 103 262 512 minecraft:blackstone
setblock 104 262 512 minecraft:smooth_basalt
fill 104 262 513 107 262 513 minecraft:blackstone
setblock 105 262 511 minecraft:smooth_basalt
fill 105 262 512 105 265 512 minecraft:blackstone
setblock 105 262 551 minecraft:smooth_basalt
fill 106 262 511 106 265 511 minecraft:blackstone
setblock 106 262 514 minecraft:blackstone
fill 106 262 551 106 265 551 minecraft:blackstone
setblock 107 262 514 minecraft:smooth_basalt
setblock 108 262 513 minecraft:smooth_basalt
fill 108 262 514 108 264 514 minecraft:blackstone
setblock 109 262 512 minecraft:smooth_basalt
fill 109 262 513 109 265 513 minecraft:blackstone
setblock 110 262 511 minecraft:smooth_basalt
fill 110 262 512 110 265 512 minecraft:blackstone
setblock 110 262 551 minecraft:smooth_basalt
fill 111 262 511 111 265 511 minecraft:blackstone
setblock 111 262 550 minecraft:smooth_basalt
fill 111 262 551 114 262 551 minecraft:blackstone
setblock 112 262 514 minecraft:smooth_basalt
fill 112 262 550 115 262 550 minecraft:blackstone
setblock 113 262 513 minecraft:smooth_basalt
setblock 113 262 514 minecraft:blackstone
setblock 114 262 512 minecraft:smooth_basalt
fill 114 262 513 114 263 513 minecraft:blackstone
setblock 115 262 511 minecraft:smooth_basalt
fill 115 262 512 115 263 512 minecraft:blackstone
setblock 115 262 551 minecraft:smooth_basalt
fill 116 262 511 119 262 511 minecraft:blackstone
fill 116 262 551 116 263 551 minecraft:blackstone
setblock 120 262 511 minecraft:smooth_basalt
setblock 120 262 551 minecraft:smooth_basalt
setblock 121 262 511 minecraft:blackstone
setblock 121 262 551 minecraft:blackstone
setblock 125 262 511 minecraft:smooth_basalt
setblock 125 262 551 minecraft:smooth_basalt
fill 126 262 511 126 264 511 minecraft:blackstone
fill 126 262 551 126 264 551 minecraft:blackstone
setblock 129 262 512 minecraft:smooth_basalt
setblock 130 262 511 minecraft:smooth_basalt
fill 130 262 512 130 263 512 minecraft:blackstone
setblock 130 262 551 minecraft:smooth_basalt
fill 131 262 511 131 264 511 minecraft:blackstone
fill 131 262 551 131 263 551 minecraft:blackstone
setblock 132 262 534 minecraft:smooth_basalt
fill 132 262 535 132 263 535 minecraft:blackstone
setblock 132 262 539 minecraft:smooth_basalt
setblock 132 262 540 minecraft:blackstone
setblock 133 262 533 minecraft:smooth_basalt
fill 133 262 534 133 264 534 minecraft:blackstone
setblock 133 262 538 minecraft:smooth_basalt
fill 133 262 539 133 265 539 minecraft:blackstone
setblock 134 262 513 minecraft:blackstone
setblock 134 262 517 minecraft:smooth_basalt
fill 134 262 518 134 263 518 minecraft:blackstone
setblock 134 262 528 minecraft:blackstone
setblock 134 262 532 minecraft:smooth_basalt
fill 134 262 533 134 265 533 minecraft:blackstone
setblock 134 262 537 minecraft:smooth_basalt
fill 134 262 538 134 265 538 minecraft:blackstone
setblock 134 262 542 minecraft:smooth_basalt
fill 134 262 543 134 263 543 minecraft:blackstone
setblock 135 262 511 minecraft:smooth_basalt
fill 135 262 512 135 263 512 minecraft:blackstone
setblock 135 262 516 minecraft:smooth_basalt
fill 135 262 517 135 265 517 minecraft:blackstone
setblock 135 262 521 minecraft:smooth_basalt
fill 135 262 522 135 265 522 minecraft:blackstone
setblock 135 262 526 minecraft:smooth_basalt
fill 135 262 527 135 263 527 minecraft:blackstone
setblock 135 262 531 minecraft:smooth_basalt
fill 135 262 532 135 265 532 minecraft:blackstone
setblock 135 262 536 minecraft:smooth_basalt
fill 135 262 537 135 265 537 minecraft:blackstone
setblock 135 262 541 minecraft:smooth_basalt
fill 135 262 542 135 265 542 minecraft:blackstone
fill 95 263 511 95 263 514 minecraft:blackstone
setblock 95 263 515 minecraft:smooth_basalt
fill 95 263 516 95 266 516 minecraft:blackstone
setblock 95 263 520 minecraft:smooth_basalt
fill 95 263 521 95 266 521 minecraft:blackstone
setblock 95 263 525 minecraft:smooth_basalt
setblock 95 263 526 minecraft:blackstone
setblock 95 263 530 minecraft:smooth_basalt
fill 95 263 531 95 263 534 minecraft:blackstone
setblock 95 263 535 minecraft:smooth_basalt
fill 95 263 536 95 265 536 minecraft:blackstone
setblock 95 263 540 minecraft:smooth_basalt
setblock 95 263 541 minecraft:blackstone
fill 96 263 511 98 263 511 minecraft:blackstone
fill 96 263 512 96 273 512 minecraft:smooth_basalt
setblock 96 263 513 minecraft:blackstone
fill 96 263 514 96 273 514 minecraft:smooth_basalt
fill 96 263 515 96 264 515 minecraft:blackstone
setblock 96 263 519 minecraft:smooth_basalt
fill 96 263 520 96 266 520 minecraft:blackstone
setblock 99 263 511 minecraft:smooth_basalt
fill 100 263 511 103 263 511 minecraft:blackstone
setblock 103 263 512 minecraft:smooth_basalt
setblock 104 263 511 minecraft:smooth_basalt
fill 104 263 512 104 263 513 minecraft:blackstone
fill 105 263 511 105 266 511 minecraft:blackstone
fill 105 263 513 106 263 513 minecraft:blackstone
setblock 107 263 513 minecraft:smooth_basalt
fill 107 263 514 107 264 514 minecraft:blackstone
setblock 108 263 512 minecraft:smooth_basalt
fill 108 263 513 108 266 513 minecraft:blackstone
setblock 109 263 511 minecraft:smooth_basalt
fill 109 263 512 109 266 512 minecraft:blackstone
setblock 109 263 551 minecraft:smooth_basalt
fill 110 263 511 110 266 511 minecraft:blackstone
setblock 110 263 550 minecraft:smooth_basalt
fill 110 263 551 113 263 551 minecraft:blackstone
setblock 111 263 514 minecraft:smooth_basalt
fill 111 263 550 113 263 550 minecraft:blackstone
setblock 112 263 513 minecraft:smooth_basalt
setblock 113 263 512 minecraft:smooth_basalt
setblock 113 263 513 minecraft:blackstone
setblock 114 263 511 minecraft:smooth_basalt
fill 114 263 512 114 264 512 minecraft:blackstone
setblock 114 263 551 minecraft:smooth_basalt
fill 115 263 511 118 263 511 minecraft:blackstone
fill 115 263 551 115 264 551 minecraft:blackstone
setblock 124 263 551 minecraft:smooth_basalt
setblock 125 263 511 minecraft:blackstone
fill 125 263 551 125 264 551 minecraft:blackstone
setblock 129 263 511 minecraft:smooth_basalt
setblock 129 263 512 minecraft:blackstone
setblock 129 263 551 minecraft:smooth_basalt
fill 130 263 511 130 264 511 minecraft:blackstone
fill 130 263 551 130 264 551 minecraft:blackstone
fill 131 263 512 132 273 512 minecraft:smooth_basalt
setblock 132 263 534 minecraft:blackstone
setblock 132 263 538 minecraft:smooth_basalt
setblock 132 263 539 minecraft:blackstone
setblock 133 263 532 minecraft:smooth_basalt
setblock 133 263 533 minecraft:blackstone
setblock 133 263 537 minecraft:smooth_basalt
fill 133 263 538 133 266 538 minecraft:blackstone
setblock 134 263 511 minecraft:smooth_basalt
setblock 134 263 516 minecraft:smooth_basalt
setblock 134 263 517 minecraft:blackstone
setblock 134 263 531 minecraft:smooth_basalt
fill 134 263 532 134 264 532 minecraft:blackstone
setblock 134 263 536 minecraft:smooth_basalt
fill 134 263 537 134 266 537 minecraft:blackstone
setblock 134 263 541 minecraft:smooth_basalt
fill 134 263 542 134 264 542 minecraft:blackstone
setblock 135 263 515 minecraft:smooth_basalt
fill 135 263 516 135 266 516 minecraft:blackstone
setblock 135 263 520 minecraft:smooth_basalt
fill 135 263 521 135 266 521 minecraft:blackstone
setblock 135 263 525 minecraft:smooth_basalt
setblock 135 263 526 minecraft:blackstone
setblock 135 263 530 minecraft:smooth_basalt
fill 135 263 531 135 265 531 minecraft:blackstone
setblock 135 263 535 minecraft:smooth_basalt
fill 135 263 536 135 266 536 minecraft:blackstone
setblock 135 263 540 minecraft:smooth_basalt
fill 135 263 541 135 266 541 minecraft:blackstone
fill 95 264 512 95 264 513 minecraft:blackstone
setblock 95 264 514 minecraft:smooth_basalt
fill 95 264 515 95 267 515 minecraft:blackstone
setblock 95 264 519 minecraft:smooth_basalt
fill 95 264 520 95 267 520 minecraft:blackstone
setblock 95 264 524 minecraft:smooth_basalt
setblock 95 264 525 minecraft:blackstone
fill 95 264 531 95 264 533 minecraft:blackstone
setblock 95 264 534 minecraft:smooth_basalt
fill 95 264 535 95 265 535 minecraft:blackstone
setblock 95 264 539 minecraft:smooth_basalt
setblock 95 264 540 minecraft:blackstone
fill 96 264 513 96 273 513 minecraft:smooth_basalt
setblock 96 264 518 minecraft:smooth_basalt
fill 96 264 519 96 267 519 minecraft:blackstone
setblock 97 264 521 minecraft:light[level=12]
setblock 97 264 529 minecraft:light[level=12]
setblock 97 264 537 minecraft:light[level=12]
setblock 97 264 545 minecraft:light[level=12]
fill 101 264 511 102 264 511 minecraft:blackstone
setblock 103 264 511 minecraft:smooth_basalt
fill 103 264 512 104 266 512 minecraft:blackstone
fill 104 264 511 104 267 511 minecraft:blackstone
setblock 105 264 513 minecraft:blackstone
setblock 105 264 521 minecraft:light[level=12]
setblock 105 264 529 minecraft:light[level=12]
setblock 105 264 537 minecraft:light[level=12]
setblock 105 264 545 minecraft:light[level=12]
setblock 106 264 513 minecraft:smooth_basalt
setblock 107 264 512 minecraft:smooth_basalt
fill 107 264 513 107 267 513 minecraft:blackstone
setblock 108 264 511 minecraft:smooth_basalt
fill 108 264 512 108 267 512 minecraft:blackstone
setblock 108 264 551 minecraft:smooth_basalt
fill 109 264 511 109 267 511 minecraft:blackstone
setblock 109 264 514 minecraft:blackstone
fill 109 264 551 112 264 551 minecraft:blackstone
setblock 110 264 514 minecraft:smooth_basalt
setblock 111 264 513 minecraft:smooth_basalt
setblock 112 264 512 minecraft:smooth_basalt
setblock 112 264 513 minecraft:blackstone
setblock 113 264 511 minecraft:smooth_basalt
fill 113 264 512 113 265 512 minecraft:blackstone
setblock 113 264 513 minecraft:light[level=12]
setblock 113 264 521 minecraft:light[level=12]
setblock 113 264 537 minecraft:light[level=12]
setblock 113 264 545 minecraft:light[level=12]
setblock 113 264 551 minecraft:smooth_basalt
fill 114 264 511 116 264 511 minecraft:blackstone
fill 114 264 551 114 265 551 minecraft:blackstone
setblock 121 264 513 minecraft:light[level=12]
setblock 121 264 521 minecraft:light[level=12]
setblock 121 264 529 minecraft:light[level=12]
setblock 121 264 537 minecraft:light[level=12]
setblock 121 264 545 minecraft:light[level=12]
setblock 128 264 511 minecraft:smooth_basalt
setblock 128 264 551 minecraft:smooth_basalt
setblock 129 264 511 minecraft:blackstone
setblock 129 264 521 minecraft:light[level=12]
setblock 129 264 529 minecraft:light[level=12]
setblock 129 264 537 minecraft:light[level=12]
setblock 129 264 545 minecraft:light[level=12]
setblock 129 264 551 minecraft:blackstone
fill 130 264 512 130 273 512 minecraft:smooth_basalt
setblock 132 264 537 minecraft:smooth_basalt
setblock 132 264 538 minecraft:blackstone
setblock 133 264 536 minecraft:smooth_basalt
fill 133 264 537 133 265 537 minecraft:blackstone
setblock 133 264 541 minecraft:smooth_basalt
setblock 134 264 531 minecraft:blackstone
setblock 134 264 535 minecraft:smooth_basalt
fill 134 264 536 134 266 536 minecraft:blackstone
setblock 134 264 540 minecraft:smooth_basalt
fill 134 264 541 134 267 541 minecraft:blackstone
setblock 135 264 514 minecraft:smooth_basalt
fill 135 264 515 135 265 515 minecraft:blackstone
setblock 135 264 519 minecraft:smooth_basalt
fill 135 264 520 135 267 520 minecraft:blackstone
setblock 135 264 529 minecraft:smooth_basalt
setblock 135 264 530 minecraft:blackstone
setblock 135 264 534 minecraft:smooth_basalt
fill 135 264 535 135 267 535 minecraft:blackstone
setblock 135 264 539 minecraft:smooth_basalt
fill 135 264 540 135 267 540 minecraft:blackstone
setblock 95 265 513 minecraft:smooth_basalt
fill 95 265 514 95 268 514 minecraft:blackstone
setblock 95 265 518 minecraft:smooth_basalt
fill 95 265 519 95 268 519 minecraft:blackstone
setblock 95 265 523 minecraft:smooth_basalt
fill 95 265 524 95 268 524 minecraft:blackstone
setblock 95 265 538 minecraft:smooth_basalt
setblock 95 265 539 minecraft:blackstone
setblock 96 265 517 minecraft:smooth_basalt
fill 96 265 518 96 268 518 minecraft:blackstone
setblock 102 265 511 minecraft:smooth_basalt
fill 103 265 511 103 268 511 minecraft:blackstone
setblock 105 265 513 minecraft:smooth_basalt
setblock 106 265 512 minecraft:smooth_basalt
fill 106 265 513 106 268 513 minecraft:blackstone
setblock 107 265 511 minecraft:smooth_basalt
fill 107 265 512 107 268 512 minecraft:blackstone
setblock 107 265 551 minecraft:smooth_basalt
fill 108 265 511 108 268 511 minecraft:blackstone
fill 108 265 551 111 265 551 minecraft:blackstone
setblock 110 265 513 minecraft:smooth_basalt
setblock 111 265 512 minecraft:smooth_basalt
setblock 111 265 513 minecraft:blackstone
setblock 112 265 511 minecraft:smooth_basalt
fill 112 265 512 112 266 512 minecraft:blackstone
setblock 112 265 551 minecraft:smooth_basalt
fill 113 265 511 115 265 511 minecraft:blackstone
fill 113 265 551 113 266 551 minecraft:blackstone
setblock 127 265 551 minecraft:smooth_basalt
setblock 128 265 551 minecraft:blackstone
setblock 133 265 535 minecraft:smooth_basalt
setblock 133 265 536 minecraft:blackstone
setblock 133 265 540 minecraft:smooth_basalt
setblock 134 265 534 minecraft:smooth_basalt
fill 134 265 535 134 266 535 minecraft:blackstone
setblock 134 265 539 minecraft:smooth_basalt
fill 134 265 540 134 268 540 minecraft:blackstone
setblock 135 265 518 minecraft:smooth_basalt
fill 135 265 519 135 268 519 minecraft:blackstone
setblock 135 265 523 minecraft:smooth_basalt
setblock 135 265 533 minecraft:smooth_basalt
fill 135 265 534 135 267 534 minecraft:blackstone
setblock 135 265 538 minecraft:smooth_basalt
fill 135 265 539 135 268 539 minecraft:blackstone
setblock 135 265 543 minecraft:smooth_basalt
setblock 95 266 513 minecraft:blackstone
setblock 95 266 517 minecraft:smooth_basalt
fill 95 266 518 95 269 518 minecraft:blackstone
setblock 95 266 522 minecraft:smooth_basalt
fill 95 266 523 95 269 523 minecraft:blackstone
fill 96 266 517 96 269 517 minecraft:blackstone
fill 102 266 511 102 269 511 minecraft:blackstone
setblock 105 266 512 minecraft:smooth_basalt
setblock 105 266 513 minecraft:blackstone
setblock 105 266 551 minecraft:blackstone
setblock 106 266 511 minecraft:smooth_basalt
fill 106 266 512 106 269 512 minecraft:blackstone
setblock 106 266 551 minecraft:smooth_basalt
fill 107 266 511 107 269 511 minecraft:blackstone
fill 107 266 551 110 266 551 minecraft:blackstone
setblock 109 266 513 minecraft:smooth_basalt
setblock 110 266 512 minecraft:smooth_basalt
setblock 111 266 511 minecraft:smooth_basalt
fill 111 266 512 111 267 512 minecraft:blackstone
setblock 111 266 551 minecraft:smooth_basalt
fill 112 266 511 113 266 511 minecraft:blackstone
fill 112 266 551 112 269 551 minecraft:blackstone
setblock 134 266 538 minecraft:smooth_basalt
fill 134 266 539 134 268 539 minecraft:blackstone
setblock 135 266 517 minecraft:smooth_basalt
fill 135 266 518 135 269 518 minecraft:blackstone
setblock 135 266 522 minecraft:smooth_basalt
fill 135 266 523 135 269 523 minecraft:blackstone
setblock 135 266 532 minecraft:smooth_basalt
setblock 135 266 533 minecraft:blackstone
setblock 135 266 537 minecraft:smooth_basalt
fill 135 266 538 135 269 538 minecraft:blackstone
setblock 135 266 542 minecraft:smooth_basalt
setblock 95 267 516 minecraft:smooth_basalt
fill 95 267 517 95 270 517 minecraft:blackstone
setblock 95 267 521 minecraft:smooth_basalt
fill 95 267 522 95 270 522 minecraft:blackstone
setblock 96 267 520 minecraft:smooth_basalt
setblock 103 267 512 minecraft:blackstone
setblock 104 267 512 minecraft:smooth_basalt
setblock 105 267 511 minecraft:smooth_basalt
fill 105 267 512 105 270 512 minecraft:blackstone
setblock 105 267 551 minecraft:smooth_basalt
fill 106 267 511 106 270 511 minecraft:blackstone
fill 106 267 551 109 267 551 minecraft:blackstone
setblock 108 267 513 minecraft:smooth_basalt
setblock 109 267 512 minecraft:smooth_basalt
setblock 110 267 511 minecraft:smooth_basalt
fill 110 267 512 110 268 512 minecraft:blackstone
setblock 110 267 551 minecraft:smooth_basalt
fill 111 267 511 112 268 511 minecraft:blackstone
fill 111 267 551 111 270 551 minecraft:blackstone
setblock 134 267 537 minecraft:smooth_basalt
fill 134 267 538 134 268 538 minecraft:blackstone
setblock 135 267 516 minecraft:smooth_basalt
fill 135 267 517 135 270 517 minecraft:blackstone
setblock 135 267 521 minecraft:smooth_basalt
fill 135 267 522 135 270 522 minecraft:blackstone
fill 135 267 524 135 268 524 minecraft:blackstone
setblock 135 267 536 minecraft:smooth_basalt
fill 135 267 537 135 270 537 minecraft:blackstone
setblock 135 267 541 minecraft:smooth_basalt
fill 135 267 542 135 270 542 minecraft:blackstone
setblock 95 268 515 minecraft:smooth_basalt
fill 95 268 516 95 271 516 minecraft:blackstone
setblock 95 268 520 minecraft:smooth_basalt
fill 95 268 521 96 270 521 minecraft:blackstone
setblock 95 268 525 minecraft:smooth_basalt
setblock 96 268 519 minecraft:smooth_basalt
fill 96 268 520 96 271 520 minecraft:blackstone
fill 101 268 511 101 270 511 minecraft:blackstone
setblock 103 268 512 minecraft:smooth_basalt
setblock 104 268 511 minecraft:smooth_basalt
fill 104 268 512 104 271 512 minecraft:blackstone
setblock 104 268 551 minecraft:smooth_basalt
fill 105 268 511 105 271 511 minecraft:blackstone
fill 105 268 551 108 268 551 minecraft:blackstone
setblock 107 268 513 minecraft:smooth_basalt
fill 107 268 550 109 268 550 minecraft:blackstone
setblock 108 268 512 minecraft:smooth_basalt
setblock 109 268 511 minecraft:smooth_basalt
fill 109 268 512 109 271 512 minecraft:blackstone
setblock 109 268 551 minecraft:smooth_basalt
fill 110 268 511 110 271 511 minecraft:blackstone
fill 110 268 551 110 271 551 minecraft:blackstone
fill 119 268 546 120 269 546 minecraft:gilded_blackstone
fill 125 268 551 126 270 551 minecraft:blackstone
setblock 134 268 520 minecraft:blackstone
setblock 134 268 521 minecraft:smooth_basalt
setblock 135 268 520 minecraft:smooth_basalt
fill 135 268 521 135 271 521 minecraft:blackstone
setblock 135 268 525 minecraft:smooth_basalt
setblock 135 268 535 minecraft:smooth_basalt
fill 135 268 536 135 269 536 minecraft:blackstone
setblock 135 268 540 minecraft:smooth_basalt
fill 135 268 541 135 271 541 minecraft:blackstone
fill 135 268 543 135 269 543 minecraft:blackstone
setblock 95 269 514 minecraft:smooth_basalt
fill 95 269 515 95 272 515 minecraft:blackstone
setblock 95 269 519 minecraft:smooth_basalt
fill 95 269 520 95 272 520 minecraft:blackstone
setblock 95 269 524 minecraft:smooth_basalt
fill 95 269 525 95 272 525 minecraft:blackstone
setblock 96 269 518 minecraft:smooth_basalt
fill 96 269 519 96 272 519 minecraft:blackstone
setblock 96 269 522 minecraft:blackstone
fill 100 269 511 100 271 511 minecraft:blackstone
setblock 102 269 512 minecraft:smooth_basalt
setblock 103 269 511 minecraft:smooth_basalt
fill 103 269 512 103 272 512 minecraft:blackstone
setblock 103 269 551 minecraft:smooth_basalt
fill 104 269 511 104 272 511 minecraft:blackstone
fill 104 269 551 107 269 551 minecraft:blackstone
setblock 105 269 513 minecraft:blackstone
fill 105 269 550 108 269 550 minecraft:blackstone
setblock 106 269 513 minecraft:smooth_basalt
setblock 107 269 512 minecraft:smooth_basalt
setblock 108 269 511 minecraft:smooth_basalt
fill 108 269 512 108 272 512 minecraft:blackstone
setblock 108 269 551 minecraft:smooth_basalt
fill 109 269 511 109 272 511 minecraft:blackstone
setblock 109 269 550 minecraft:smooth_basalt
fill 109 269 551 109 272 551 minecraft:blackstone
fill 110 269 550 110 272 550 minecraft:blackstone
fill 111 269 511 111 270 511 minecraft:blackstone
fill 111 269 549 112 269 550 minecraft:gold_block
setblock 113 269 551 minecraft:smooth_basalt
setblock 123 269 551 minecraft:smooth_basalt
fill 124 269 551 124 272 551 minecraft:blackstone
setblock 127 269 551 minecraft:blackstone
setblock 134 269 519 minecraft:blackstone
setblock 134 269 520 minecraft:smooth_basalt
fill 134 269 521 134 270 523 minecraft:blackstone
setblock 135 269 519 minecraft:smooth_basalt
fill 135 269 520 135 272 520 minecraft:blackstone
setblock 135 269 524 minecraft:smooth_basalt
fill 135 269 525 135 270 527 minecraft:blackstone
setblock 135 269 539 minecraft:smooth_basalt
fill 135 269 540 135 272 540 minecraft:blackstone
fill 95 270 511 95 270 513 minecraft:gold_block
fill 95 270 514 95 273 514 minecraft:blackstone
setblock 95 270 518 minecraft:smooth_basalt
fill 95 270 519 95 273 519 minecraft:blackstone
setblock 95 270 523 minecraft:smooth_basalt
fill 95 270 524 95 273 524 minecraft:blackstone
fill 95 270 526 95 271 526 minecraft:blackstone
fill 96 270 511 98 270 511 minecraft:gold_block
fill 96 270 515 99 270 516 minecraft:gold_block
setblock 96 270 517 minecraft:smooth_basalt
fill 96 270 518 96 273 518 minecraft:blackstone
setblock 96 270 522 minecraft:smooth_basalt
fill 96 270 523 96 273 523 minecraft:blackstone
fill 99 270 511 99 272 511 minecraft:blackstone
fill 99 270 512 100 270 512 minecraft:gold_block
fill 99 270 514 100 271 514 minecraft:gold_block
fill 100 270 513 100 271 513 minecraft:gold_block
setblock 100 270 515 minecraft:gold_block
setblock 101 270 551 minecraft:blackstone
setblock 102 270 511 minecraft:smooth_basalt
fill 102 270 512 102 273 512 minecraft:blackstone
setblock 102 270 551 minecraft:smooth_basalt
fill 103 270 511 103 273 511 minecraft:blackstone
setblock 103 270 550 minecraft:smooth_basalt
fill 103 270 551 106 270 551 minecraft:blackstone
setblock 104 270 513 minecraft:blackstone
fill 104 270 550 107 270 550 minecraft:blackstone
setblock 105 270 513 minecraft:smooth_basalt
setblock 106 270 512 minecraft:smooth_basalt
fill 106 270 513 106 271 513 minecraft:blackstone
setblock 107 270 511 minecraft:smooth_basalt
fill 107 270 512 107 273 512 minecraft:blackstone
setblock 107 270 551 minecraft:smooth_basalt
fill 108 270 511 108 273 511 minecraft:blackstone
setblock 108 270 550 minecraft:smooth_basalt
fill 108 270 551 108 273 551 minecraft:blackstone
fill 109 270 550 109 273 550 minecraft:blackstone
fill 111 270 549 112 270 549 minecraft:gold_block
fill 111 270 550 111 271 550 minecraft:blackstone
setblock 112 270 550 minecraft:gold_block
setblock 112 270 551 minecraft:smooth_basalt
fill 113 270 551 113 273 551 minecraft:blackstone
setblock 121 270 551 minecraft:blackstone
setblock 122 270 551 minecraft:smooth_basalt
fill 123 270 551 123 273 551 minecraft:blackstone
fill 127 270 513 128 270 514 minecraft:gold_block
setblock 127 270 551 minecraft:smooth_basalt
fill 128 270 511 129 270 512 minecraft:gold_block
fill 128 270 515 129 270 516 minecraft:gold_block
fill 128 270 551 128 273 551 minecraft:blackstone
fill 129 270 517 132 270 517 minecraft:gold_block
fill 130 270 511 133 271 511 minecraft:gold_block
fill 130 270 516 133 270 516 minecraft:gold_block
fill 133 270 512 134 270 515 minecraft:gold_block
setblock 134 270 519 minecraft:smooth_basalt
fill 134 270 520 134 273 520 minecraft:blackstone
setblock 134 270 524 minecraft:smooth_basalt
fill 134 270 525 134 273 525 minecraft:blackstone
fill 135 270 516 135 271 516 minecraft:blackstone
setblock 135 270 518 minecraft:smooth_basalt
fill 135 270 519 135 273 519 minecraft:blackstone
setblock 135 270 523 minecraft:smooth_basalt
fill 135 270 524 135 273 524 minecraft:blackstone
setblock 135 270 528 minecraft:smooth_basalt
setblock 135 270 538 minecraft:smooth_basalt
fill 135 270 539 135 272 539 minecraft:blackstone
setblock 135 270 543 minecraft:smooth_basalt
fill 135 270 544 135 273 544 minecraft:blackstone
fill 95 271 512 95 271 513 minecraft:gold_block
setblock 95 271 517 minecraft:smooth_basalt
fill 95 271 518 95 273 518 minecraft:blackstone
setblock 95 271 521 minecraft:blackstone
setblock 95 271 522 minecraft:smooth_basalt
fill 95 271 523 95 273 523 minecraft:blackstone
setblock 95 271 527 minecraft:smooth_basalt
fill 96 271 511 97 271 511 minecraft:gold_block
fill 96 271 515 99 271 515 minecraft:gold_block
fill 96 271 517 96 273 517 minecraft:blackstone
setblock 96 271 521 minecraft:smooth_basalt
fill 96 271 522 96 273 522 minecraft:blackstone
fill 96 271 524 96 272 524 minecraft:blackstone
setblock 97 271 520 minecraft:smooth_basalt
fill 97 271 521 97 273 521 minecraft:blackstone
fill 98 271 511 98 273 511 minecraft:blackstone
fill 99 271 512 99 272 512 minecraft:gold_block
setblock 100 271 551 minecraft:blackstone
setblock 101 271 511 minecraft:smooth_basalt
fill 101 271 512 101 273 512 minecraft:blackstone
setblock 101 271 551 minecraft:smooth_basalt
fill 102 271 511 102 273 511 minecraft:blackstone
setblock 102 271 550 minecraft:smooth_basalt
fill 102 271 551 105 271 551 minecraft:blackstone
fill 103 271 550 106 271 550 minecraft:blackstone
setblock 104 271 513 minecraft:smooth_basalt
fill 104 271 549 107 271 549 minecraft:blackstone
setblock 105 271 512 minecraft:smooth_basalt
fill 105 271 513 105 272 513 minecraft:blackstone
setblock 106 271 511 minecraft:smooth_basalt
fill 106 271 512 106 273 512 minecraft:blackstone
setblock 106 271 551 minecraft:smooth_basalt
fill 107 271 511 107 273 511 minecraft:blackstone
setblock 107 271 550 minecraft:smooth_basalt
fill 107 271 551 107 273 551 minecraft:blackstone
setblock 108 271 549 minecraft:smooth_basalt
fill 108 271 550 108 273 550 minecraft:blackstone
fill 109 271 549 109 273 549 minecraft:blackstone
setblock 111 271 511 minecraft:smooth_basalt
fill 111 271 518 111 272 518 minecraft:gilded_blackstone
setblock 111 271 551 minecraft:smooth_basalt
fill 112 271 551 112 273 551 minecraft:blackstone
fill 114 271 551 115 271 551 minecraft:blackstone
fill 118 271 551 120 271 551 minecraft:blackstone
setblock 121 271 551 minecraft:smooth_basalt
setblock 122 271 550 minecraft:smooth_basalt
fill 122 271 551 122 273 551 minecraft:blackstone
fill 123 271 550 126 271 550 minecraft:blackstone
setblock 125 271 551 minecraft:blackstone
setblock 126 271 551 minecraft:smooth_basalt
fill 127 271 551 127 273 551 minecraft:blackstone
fill 128 271 512 128 271 515 minecraft:gold_block
fill 129 271 511 129 271 512 minecraft:gold_block
fill 129 271 515 129 271 516 minecraft:gold_block
fill 130 271 516 132 271 516 minecraft:gold_block
fill 133 271 512 133 271 515 minecraft:gold_block
fill 134 271 513 134 271 514 minecraft:gold_block
fill 134 271 519 134 273 519 minecraft:blackstone
fill 134 271 521 134 271 522 minecraft:blackstone
setblock 134 271 523 minecraft:smooth_basalt
fill 134 271 524 134 273 524 minecraft:blackstone
fill 134 271 526 135 271 526 minecraft:blackstone
setblock 135 271 517 minecraft:smooth_basalt
fill 135 271 518 135 273 518 minecraft:blackstone
setblock 135 271 522 minecraft:smooth_basalt
fill 135 271 523 135 273 523 minecraft:blackstone
fill 135 271 525 135 272 525 minecraft:blackstone
setblock 135 271 527 minecraft:smooth_basalt
fill 135 271 528 135 273 529 minecraft:blackstone
setblock 135 271 538 minecraft:blackstone
setblock 135 271 542 minecraft:smooth_basalt
fill 135 271 543 135 273 543 minecraft:blackstone
setblock 95 272 516 minecraft:smooth_basalt
fill 95 272 517 95 273 517 minecraft:blackstone
setblock 95 272 521 minecraft:smooth_basalt
fill 95 272 522 95 273 522 minecraft:blackstone
setblock 95 272 526 minecraft:smooth_basalt
fill 95 272 527 95 273 528 minecraft:blackstone
fill 95 272 544 95 273 544 minecraft:blackstone
fill 96 272 515 98 272 515 minecraft:gold_block
setblock 96 272 520 minecraft:smooth_basalt
fill 96 272 521 96 273 521 minecraft:blackstone
setblock 96 272 525 minecraft:smooth_basalt
fill 97 272 511 97 273 511 minecraft:blackstone
fill 97 272 520 97 273 520 minecraft:blackstone
fill 97 272 522 97 273 522 minecraft:blackstone
setblock 97 272 529 minecraft:light[level=12]
setblock 97 272 537 minecraft:light[level=12]
setblock 97 272 545 minecraft:light[level=12]
setblock 99 272 514 minecraft:gold_block
setblock 99 272 551 minecraft:blackstone
setblock 100 272 511 minecraft:smooth_basalt
fill 100 272 512 100 273 512 minecraft:blackstone
setblock 100 272 551 minecraft:smooth_basalt
fill 101 272 511 101 273 511 minecraft:blackstone
setblock 101 272 550 minecraft:smooth_basalt
fill 101 272 551 104 272 551 minecraft:blackstone
setblock 102 272 549 minecraft:smooth_basalt
fill 102 272 550 105 272 550 minecraft:blackstone
setblock 103 272 513 minecraft:smooth_basalt
fill 103 272 549 106 272 549 minecraft:blackstone
setblock 104 272 512 minecraft:smooth_basalt
fill 104 272 513 104 273 513 minecraft:blackstone
setblock 105 272 511 minecraft:smooth_basalt
fill 105 272 512 105 273 512 minecraft:blackstone
setblock 105 272 521 minecraft:light[level=12]
setblock 105 272 529 minecraft:light[level=12]
setblock 105 272 537 minecraft:light[level=12]
setblock 105 272 545 minecraft:light[level=12]
fill 105 272 548 107 272 548 minecraft:blackstone
setblock 105 272 551 minecraft:smooth_basalt
fill 106 272 511 106 273 511 minecraft:blackstone
setblock 106 272 550 minecraft:smooth_basalt
fill 106 272 551 106 273 551 minecraft:blackstone
setblock 107 272 549 minecraft:smooth_basalt
fill 107 272 550 107 273 550 minecraft:blackstone
fill 108 272 549 108 273 549 minecraft:blackstone
setblock 110 272 511 minecraft:smooth_basalt
fill 110 272 549 110 273 549 minecraft:blackstone
setblock 110 272 551 minecraft:smooth_basalt
setblock 111 272 550 minecraft:smooth_basalt
fill 111 272 551 111 273 551 minecraft:blackstone
fill 112 272 550 112 273 550 minecraft:blackstone
setblock 113 272 513 minecraft:light[level=12]
setblock 113 272 521 minecraft:light[level=12]
setblock 113 272 537 minecraft:light[level=12]
setblock 113 272 545 minecraft:light[level=12]
setblock 114 272 551 minecraft:blackstone
setblock 115 272 551 minecraft:smooth_basalt
fill 116 272 551 119 272 551 minecraft:blackstone
fill 119 272 550 120 272 550 minecraft:blackstone
setblock 120 272 551 minecraft:smooth_basalt
setblock 121 272 513 minecraft:light[level=12]
setblock 121 272 521 minecraft:light[level=12]
setblock 121 272 529 minecraft:light[level=12]
setblock 121 272 537 minecraft:light[level=12]
setblock 121 272 545 minecraft:light[level=12]
setblock 121 272 550 minecraft:smooth_basalt
fill 121 272 551 121 273 551 minecraft:blackstone
setblock 122 272 549 minecraft:smooth_basalt
fill 122 272 550 125 272 550 minecraft:blackstone
fill 123 272 549 125 273 549 minecraft:blackstone
setblock 125 272 551 minecraft:smooth_basalt
setblock 126 272 550 minecraft:smooth_basalt
fill 126 272 551 126 273 551 minecraft:blackstone
fill 127 272 550 127 273 550 minecraft:blackstone
setblock 129 272 512 minecraft:gold_block
setblock 129 272 515 minecraft:gold_block
setblock 129 272 521 minecraft:light[level=12]
setblock 129 272 529 minecraft:light[level=12]
setblock 129 272 537 minecraft:light[level=12]
setblock 129 272 545 minecraft:light[level=12]
setblock 129 272 551 minecraft:blackstone
fill 130 272 511 131 272 511 minecraft:gold_block
fill 130 272 516 131 272 516 minecraft:gold_block
fill 133 272 512 133 272 514 minecraft:gold_block
setblock 133 272 522 minecraft:blackstone
setblock 133 272 523 minecraft:smooth_basalt
fill 133 272 524 133 273 524 minecraft:blackstone
setblock 134 272 521 minecraft:blackstone
setblock 134 272 522 minecraft:smooth_basalt
fill 134 272 523 134 273 523 minecraft:blackstone
setblock 134 272 526 minecraft:blackstone
setblock 134 272 527 minecraft:smooth_basalt
setblock 135 272 516 minecraft:smooth_basalt
fill 135 272 517 135 273 517 minecraft:blackstone
setblock 135 272 521 minecraft:smooth_basalt
fill 135 272 522 135 273 522 minecraft:blackstone
setblock 135 272 526 minecraft:smooth_basalt
fill 135 272 527 135 273 527 minecraft:blackstone
setblock 135 272 530 minecraft:blackstone
setblock 135 272 541 minecraft:smooth_basalt
fill 135 272 542 135 273 542 minecraft:blackstone
setblock 135 272 545 minecraft:blackstone
setblock 95 273 515 minecraft:smooth_basalt
setblock 95 273 516 minecraft:blackstone
setblock 95 273 520 minecraft:smooth_basalt
setblock 95 273 521 minecraft:blackstone
setblock 95 273 525 minecraft:smooth_basalt
fill 95 273 526 96 273 526 minecraft:blackstone
setblock 95 273 543 minecraft:blackstone
setblock 95 273 545 minecraft:smooth_basalt
fill 95 273 546 95 273 547 minecraft:blackstone
setblock 96 273 511 minecraft:blackstone
setblock 96 273 519 minecraft:smooth_basalt
setblock 96 273 520 minecraft:blackstone
setblock 96 273 524 minecraft:smooth_basalt
setblock 96 273 525 minecraft:blackstone
setblock 97 273 523 minecraft:smooth_basalt
fill 97 273 551 98 273 551 minecraft:blackstone
setblock 99 273 511 minecraft:smooth_basalt
setblock 99 273 512 minecraft:blackstone
setblock 99 273 550 minecraft:blackstone
setblock 99 273 551 minecraft:smooth_basalt
setblock 100 273 511 minecraft:blackstone
setblock 100 273 550 minecraft:smooth_basalt
fill 100 273 551 103 273 551 minecraft:blackstone
setblock 101 273 549 minecraft:smooth_basalt
fill 101 273 550 104 273 550 minecraft:blackstone
fill 102 273 549 105 273 549 minecraft:blackstone
setblock 103 273 512 minecraft:smooth_basalt
setblock 103 273 513 minecraft:blackstone
fill 103 273 548 106 273 548 minecraft:blackstone
setblock 104 273 511 minecraft:smooth_basalt
setblock 104 273 512 minecraft:blackstone
setblock 104 273 551 minecraft:smooth_basalt
setblock 105 273 511 minecraft:blackstone
setblock 105 273 550 minecraft:smooth_basalt
setblock 105 273 551 minecraft:blackstone
setblock 106 273 549 minecraft:smooth_basalt
setblock 106 273 550 minecraft:blackstone
setblock 107 273 548 minecraft:smooth_basalt
setblock 107 273 549 minecraft:blackstone
setblock 108 273 512 minecraft:smooth_basalt
setblock 108 273 548 minecraft:blackstone
setblock 109 273 511 minecraft:smooth_basalt
setblock 109 273 551 minecraft:smooth_basalt
setblock 110 273 511 minecraft:blackstone
setblock 110 273 550 minecraft:smooth_basalt
setblock 110 273 551 minecraft:blackstone
setblock 111 273 550 minecraft:blackstone
setblock 113 273 550 minecraft:blackstone
setblock 114 273 551 minecraft:smooth_basalt
fill 115 273 551 118 273 551 minecraft:blackstone
fill 117 273 550 119 273 550 minecraft:blackstone
setblock 119 273 551 minecraft:smooth_basalt
setblock 120 273 549 minecraft:blackstone
setblock 120 273 550 minecraft:smooth_basalt
setblock 120 273 551 minecraft:blackstone
setblock 121 273 549 minecraft:smooth_basalt
fill 121 273 550 124 273 550 minecraft:blackstone
setblock 122 273 549 minecraft:blackstone
setblock 123 273 511 minecraft:blackstone
setblock 124 273 511 minecraft:smooth_basalt
setblock 124 273 551 minecraft:smooth_basalt
setblock 125 273 511 minecraft:blackstone
setblock 125 273 550 minecraft:smooth_basalt
setblock 125 273 551 minecraft:blackstone
setblock 126 273 549 minecraft:smooth_basalt
setblock 126 273 550 minecraft:blackstone
setblock 129 273 551 minecraft:smooth_basalt
setblock 133 273 522 minecraft:smooth_basalt
setblock 133 273 523 minecraft:blackstone
setblock 133 273 525 minecraft:blackstone
setblock 134 273 521 minecraft:smooth_basalt
setblock 134 273 522 minecraft:blackstone
setblock 134 273 526 minecraft:smooth_basalt
fill 134 273 527 134 273 528 minecraft:blackstone
setblock 135 273 516 minecraft:blackstone
setblock 135 273 520 minecraft:smooth_basalt
setblock 135 273 521 minecraft:blackstone
setblock 135 273 525 minecraft:smooth_basalt
setblock 135 273 526 minecraft:blackstone
setblock 135 273 530 minecraft:smooth_basalt
setblock 135 273 531 minecraft:blackstone
setblock 135 273 540 minecraft:smooth_basalt
setblock 135 273 541 minecraft:blackstone
setblock 135 273 545 minecraft:smooth_basalt
setblock 135 273 546 minecraft:blackstone
fill 98 279 529 101 280 529 minecraft:light_blue_concrete
fill 99 279 524 99 280 524 minecraft:blue_concrete
fill 99 279 525 102 280 528 minecraft:light_blue_concrete
fill 99 279 530 101 280 534 minecraft:light_blue_concrete
fill 100 279 522 100 280 523 minecraft:blue_concrete
fill 100 279 524 105 280 524 minecraft:light_blue_concrete
fill 100 279 535 101 280 536 minecraft:light_blue_concrete
fill 101 279 520 101 280 522 minecraft:blue_concrete
fill 101 279 523 106 280 523 minecraft:light_blue_concrete
fill 101 279 537 102 280 538 minecraft:light_blue_concrete
fill 102 279 519 102 280 521 minecraft:blue_concrete
fill 102 279 522 108 280 522 minecraft:light_blue_concrete
fill 102 279 529 107 280 536 minecraft:blue_concrete
fill 102 279 539 103 280 539 minecraft:light_blue_concrete
fill 103 279 518 103 280 520 minecraft:blue_concrete
fill 103 279 521 118 280 521 minecraft:light_blue_concrete
fill 103 279 525 103 280 526 minecraft:light_blue_concrete
fill 103 279 527 109 280 528 minecraft:blue_concrete
fill 103 279 537 109 280 538 minecraft:blue_concrete
fill 103 279 540 103 280 540 minecraft:light_blue_concrete
fill 104 279 517 105 280 519 minecraft:blue_concrete
fill 104 279 520 117 280 520 minecraft:light_blue_concrete
fill 104 279 525 104 280 525 minecraft:light_blue_concrete
fill 104 279 526 112 280 526 minecraft:blue_concrete
fill 104 279 539 112 280 540 minecraft:blue_concrete
fill 104 279 541 104 280 541 minecraft:light_blue_concrete
fill 105 279 516 122 280 516 minecraft:blue_concrete
fill 105 279 525 116 280 525 minecraft:blue_concrete
fill 105 279 541 124 280 541 minecraft:blue_concrete
fill 105 279 542 105 280 542 minecraft:light_blue_concrete
fill 106 279 517 107 280 518 minecraft:blue_concrete
fill 106 279 519 115 280 519 minecraft:light_blue_concrete
fill 106 279 524 115 280 524 minecraft:blue_concrete
fill 106 279 542 123 280 542 minecraft:blue_concrete
fill 107 279 515 121 280 515 minecraft:blue_concrete
fill 107 279 523 114 280 523 minecraft:blue_concrete
fill 107 279 543 121 280 543 minecraft:blue_concrete
fill 108 279 517 123 280 517 minecraft:blue_concrete
fill 108 279 518 113 280 518 minecraft:light_blue_concrete
fill 108 279 529 108 280 531 minecraft:blue_concrete
fill 108 279 532 111 280 532 minecraft:light_blue_concrete
fill 108 279 533 108 280 536 minecraft:blue_concrete
fill 109 279 514 119 280 514 minecraft:blue_concrete
schedule function dropper:buildpart/122_10 1t
