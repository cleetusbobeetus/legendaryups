fill 190 236 301 190 237 301 minecraft:prismarine_bricks
fill 190 236 303 190 237 303 minecraft:prismarine_bricks
fill 191 236 294 191 237 294 minecraft:prismarine_bricks
fill 191 236 296 191 237 296 minecraft:quartz_pillar
fill 191 236 298 191 237 298 minecraft:prismarine_bricks
fill 191 236 300 191 237 300 minecraft:prismarine_bricks
fill 191 236 302 191 237 302 minecraft:prismarine_bricks
fill 191 236 304 191 237 304 minecraft:prismarine_bricks
fill 191 236 317 192 245 317 minecraft:prismarine
fill 192 236 295 192 237 295 minecraft:quartz_pillar
fill 192 236 297 192 237 297 minecraft:quartz_pillar
fill 192 236 299 192 237 299 minecraft:prismarine_bricks
fill 192 236 301 192 237 301 minecraft:prismarine_bricks
fill 192 236 303 192 237 303 minecraft:prismarine_bricks
fill 193 236 275 193 295 275 minecraft:prismarine
fill 193 236 294 193 237 294 minecraft:prismarine_bricks
fill 193 236 296 193 237 296 minecraft:prismarine_bricks
fill 193 236 298 193 237 298 minecraft:prismarine_bricks
fill 193 236 300 193 237 300 minecraft:prismarine_bricks
fill 193 236 302 193 237 302 minecraft:prismarine_bricks
fill 193 236 304 193 237 304 minecraft:prismarine_bricks
setblock 193 236 317 minecraft:prismarine_bricks
fill 194 236 317 196 245 317 minecraft:prismarine
fill 202 236 311 202 237 311 minecraft:prismarine_bricks
fill 202 236 313 202 237 313 minecraft:prismarine_bricks
fill 202 236 315 202 237 315 minecraft:prismarine_bricks
fill 203 236 310 203 237 310 minecraft:prismarine_bricks
fill 203 236 312 203 237 312 minecraft:prismarine_bricks
fill 203 236 314 203 237 314 minecraft:prismarine_bricks
fill 203 236 316 203 237 316 minecraft:prismarine_bricks
fill 204 236 311 204 237 311 minecraft:prismarine_bricks
fill 204 236 313 204 237 313 minecraft:prismarine_bricks
fill 204 236 315 204 237 315 minecraft:prismarine_bricks
fill 204 236 317 208 247 317 minecraft:prismarine
fill 205 236 310 205 237 310 minecraft:prismarine_bricks
fill 205 236 312 205 237 312 minecraft:prismarine_bricks
fill 205 236 314 205 237 314 minecraft:prismarine_bricks
fill 205 236 316 205 237 316 minecraft:prismarine_bricks
fill 206 236 311 206 237 311 minecraft:prismarine_bricks
fill 206 236 313 206 237 313 minecraft:prismarine_bricks
fill 206 236 315 206 237 315 minecraft:prismarine_bricks
fill 207 236 310 207 237 310 minecraft:prismarine_bricks
fill 207 236 312 207 237 312 minecraft:prismarine_bricks
fill 207 236 314 207 237 314 minecraft:prismarine_bricks
fill 207 236 316 207 237 316 minecraft:prismarine_bricks
fill 208 236 311 208 237 311 minecraft:prismarine_bricks
fill 208 236 313 208 237 313 minecraft:quartz_pillar
fill 208 236 315 208 237 315 minecraft:quartz_pillar
fill 209 236 310 209 237 310 minecraft:prismarine_bricks
fill 209 236 312 209 237 312 minecraft:prismarine_bricks
fill 209 236 314 209 237 314 minecraft:quartz_pillar
fill 209 236 316 209 236 317 minecraft:prismarine_bricks
fill 210 236 311 210 237 311 minecraft:prismarine_bricks
fill 210 236 313 210 237 313 minecraft:quartz_pillar
fill 210 236 315 210 237 315 minecraft:quartz_pillar
fill 210 236 317 211 289 317 minecraft:prismarine
setblock 220 236 275 minecraft:prismarine_bricks
fill 221 236 275 221 245 275 minecraft:prismarine
fill 221 236 276 221 237 276 minecraft:prismarine_bricks
fill 221 236 278 221 237 278 minecraft:prismarine_bricks
fill 221 236 280 221 237 280 minecraft:prismarine_bricks
fill 221 236 282 221 237 282 minecraft:prismarine_bricks
fill 221 236 284 221 237 284 minecraft:prismarine_bricks
fill 221 236 286 221 237 286 minecraft:prismarine_bricks
fill 222 236 277 222 237 277 minecraft:prismarine_bricks
fill 222 236 279 222 237 279 minecraft:prismarine_bricks
fill 222 236 281 222 237 281 minecraft:prismarine_bricks
fill 222 236 283 222 237 283 minecraft:prismarine_bricks
fill 222 236 285 222 237 285 minecraft:prismarine_bricks
fill 222 236 301 222 237 301 minecraft:prismarine_bricks
fill 222 236 303 222 237 303 minecraft:prismarine_bricks
fill 222 236 305 222 237 305 minecraft:prismarine_bricks
fill 222 236 307 222 237 307 minecraft:prismarine_bricks
fill 222 236 309 222 237 309 minecraft:prismarine_bricks
fill 223 236 276 223 237 276 minecraft:prismarine_bricks
fill 223 236 278 223 237 278 minecraft:prismarine_bricks
fill 223 236 280 223 237 280 minecraft:prismarine_bricks
fill 223 236 282 223 237 282 minecraft:prismarine_bricks
fill 223 236 284 223 237 284 minecraft:prismarine_bricks
fill 223 236 286 223 237 286 minecraft:prismarine_bricks
fill 223 236 302 223 237 302 minecraft:prismarine_bricks
fill 223 236 304 223 237 304 minecraft:prismarine_bricks
fill 223 236 306 223 237 306 minecraft:prismarine_bricks
fill 223 236 308 223 237 308 minecraft:prismarine_bricks
fill 224 236 277 224 237 277 minecraft:prismarine_bricks
fill 224 236 279 224 237 279 minecraft:prismarine_bricks
fill 224 236 281 224 237 281 minecraft:prismarine_bricks
fill 224 236 283 224 237 283 minecraft:prismarine_bricks
fill 224 236 285 224 237 285 minecraft:prismarine_bricks
fill 224 236 301 224 237 301 minecraft:prismarine_bricks
fill 224 236 303 224 237 303 minecraft:prismarine_bricks
fill 224 236 305 224 237 305 minecraft:prismarine_bricks
fill 224 236 307 224 237 307 minecraft:prismarine_bricks
fill 224 236 309 224 237 309 minecraft:prismarine_bricks
fill 225 236 276 225 237 276 minecraft:prismarine_bricks
fill 225 236 278 225 237 278 minecraft:quartz_pillar
fill 225 236 280 225 237 280 minecraft:quartz_pillar
fill 225 236 282 225 237 282 minecraft:prismarine_bricks
fill 225 236 284 225 237 284 minecraft:prismarine_bricks
fill 225 236 286 225 237 286 minecraft:prismarine_bricks
fill 225 236 302 225 237 302 minecraft:prismarine_bricks
fill 225 236 304 225 237 304 minecraft:prismarine_bricks
fill 225 236 306 225 237 306 minecraft:prismarine_bricks
fill 225 236 308 225 237 308 minecraft:prismarine_bricks
fill 226 236 277 226 237 277 minecraft:prismarine_bricks
fill 226 236 279 226 237 279 minecraft:quartz_pillar
fill 226 236 281 226 237 281 minecraft:prismarine_bricks
fill 226 236 283 226 237 283 minecraft:prismarine_bricks
fill 226 236 285 226 237 285 minecraft:prismarine_bricks
fill 226 236 301 226 237 301 minecraft:prismarine_bricks
fill 226 236 303 226 237 303 minecraft:prismarine_bricks
fill 226 236 305 226 237 305 minecraft:prismarine_bricks
fill 226 236 307 226 237 307 minecraft:prismarine_bricks
fill 226 236 309 226 237 309 minecraft:prismarine_bricks
fill 227 236 276 227 237 276 minecraft:prismarine_bricks
fill 227 236 278 227 237 278 minecraft:quartz_pillar
fill 227 236 280 227 237 280 minecraft:quartz_pillar
fill 227 236 282 227 237 282 minecraft:prismarine_bricks
fill 227 236 284 227 237 284 minecraft:prismarine_bricks
fill 227 236 286 227 237 286 minecraft:prismarine_bricks
fill 227 236 302 227 237 302 minecraft:prismarine_bricks
fill 227 236 304 227 237 304 minecraft:prismarine_bricks
fill 227 236 306 227 237 306 minecraft:prismarine_bricks
fill 227 236 308 227 237 308 minecraft:prismarine_bricks
fill 228 236 277 228 237 277 minecraft:prismarine_bricks
fill 228 236 279 228 237 279 minecraft:prismarine_bricks
fill 228 236 281 228 237 281 minecraft:prismarine_bricks
fill 228 236 283 228 237 283 minecraft:prismarine_bricks
fill 228 236 285 228 237 285 minecraft:prismarine_bricks
fill 228 236 301 228 237 301 minecraft:prismarine_bricks
fill 228 236 303 228 237 303 minecraft:prismarine_bricks
fill 228 236 305 228 237 305 minecraft:prismarine_bricks
fill 228 236 307 228 237 307 minecraft:prismarine_bricks
fill 228 236 309 228 237 309 minecraft:prismarine_bricks
fill 229 236 276 229 237 276 minecraft:prismarine_bricks
fill 229 236 278 229 237 278 minecraft:prismarine_bricks
fill 229 236 280 229 237 280 minecraft:prismarine_bricks
fill 229 236 282 229 237 282 minecraft:prismarine_bricks
fill 229 236 284 229 237 284 minecraft:prismarine_bricks
fill 229 236 286 229 237 286 minecraft:prismarine_bricks
fill 229 236 302 229 237 302 minecraft:prismarine_bricks
fill 229 236 304 229 237 304 minecraft:prismarine_bricks
fill 229 236 306 229 237 306 minecraft:prismarine_bricks
fill 229 236 308 229 237 308 minecraft:prismarine_bricks
setblock 230 236 300 minecraft:prismarine_bricks
setblock 188 237 313 minecraft:prismarine_bricks
setblock 191 237 285 minecraft:light[level=12]
setblock 191 237 292 minecraft:light[level=12]
setblock 191 237 306 minecraft:light[level=12]
fill 193 237 317 193 308 317 minecraft:prismarine
setblock 198 237 278 minecraft:light[level=12]
setblock 198 237 285 minecraft:light[level=12]
setblock 198 237 292 minecraft:light[level=12]
setblock 198 237 299 minecraft:light[level=12]
setblock 198 237 306 minecraft:light[level=12]
setblock 198 237 313 minecraft:light[level=12]
setblock 205 237 278 minecraft:light[level=12]
setblock 205 237 285 minecraft:light[level=12]
setblock 205 237 292 minecraft:light[level=12]
setblock 205 237 299 minecraft:light[level=12]
setblock 205 237 306 minecraft:light[level=12]
setblock 209 237 316 minecraft:prismarine_bricks
fill 209 237 317 209 241 317 minecraft:prismarine
setblock 212 237 278 minecraft:light[level=12]
setblock 212 237 285 minecraft:light[level=12]
setblock 212 237 292 minecraft:light[level=12]
setblock 212 237 299 minecraft:light[level=12]
setblock 212 237 306 minecraft:light[level=12]
setblock 212 237 313 minecraft:light[level=12]
setblock 219 237 278 minecraft:light[level=12]
setblock 219 237 285 minecraft:light[level=12]
setblock 219 237 292 minecraft:light[level=12]
setblock 219 237 299 minecraft:light[level=12]
setblock 219 237 306 minecraft:light[level=12]
setblock 219 237 313 minecraft:light[level=12]
fill 220 237 275 220 245 275 minecraft:prismarine
setblock 226 237 292 minecraft:light[level=12]
setblock 226 237 299 minecraft:light[level=12]
fill 230 237 300 230 245 300 minecraft:prismarine
fill 188 238 297 188 245 300 minecraft:prismarine
setblock 188 238 301 minecraft:sea_lantern
fill 188 238 313 188 303 313 minecraft:prismarine
setblock 189 238 294 minecraft:sea_lantern
setblock 189 238 296 minecraft:sea_lantern
setblock 189 238 298 minecraft:sea_lantern
setblock 189 238 300 minecraft:sea_lantern
setblock 189 238 302 minecraft:sea_lantern
setblock 189 238 304 minecraft:sea_lantern
setblock 190 238 295 minecraft:sea_lantern
setblock 190 238 297 minecraft:sea_lantern
setblock 190 238 299 minecraft:sea_lantern
setblock 190 238 301 minecraft:sea_lantern
setblock 190 238 303 minecraft:sea_lantern
setblock 191 238 294 minecraft:sea_lantern
setblock 191 238 296 minecraft:sea_lantern
setblock 191 238 298 minecraft:sea_lantern
setblock 191 238 300 minecraft:sea_lantern
setblock 191 238 302 minecraft:sea_lantern
setblock 191 238 304 minecraft:sea_lantern
setblock 192 238 295 minecraft:sea_lantern
setblock 192 238 297 minecraft:sea_lantern
setblock 192 238 299 minecraft:sea_lantern
setblock 192 238 301 minecraft:sea_lantern
setblock 192 238 303 minecraft:sea_lantern
setblock 193 238 294 minecraft:sea_lantern
setblock 193 238 296 minecraft:sea_lantern
setblock 193 238 298 minecraft:sea_lantern
setblock 193 238 300 minecraft:sea_lantern
setblock 193 238 302 minecraft:sea_lantern
setblock 193 238 304 minecraft:sea_lantern
setblock 202 238 311 minecraft:sea_lantern
setblock 202 238 313 minecraft:sea_lantern
setblock 202 238 315 minecraft:sea_lantern
setblock 203 238 310 minecraft:sea_lantern
setblock 203 238 312 minecraft:sea_lantern
setblock 203 238 314 minecraft:sea_lantern
setblock 203 238 316 minecraft:sea_lantern
setblock 204 238 311 minecraft:sea_lantern
setblock 204 238 313 minecraft:sea_lantern
setblock 204 238 315 minecraft:sea_lantern
setblock 205 238 310 minecraft:sea_lantern
setblock 205 238 312 minecraft:sea_lantern
setblock 205 238 314 minecraft:sea_lantern
setblock 205 238 316 minecraft:sea_lantern
setblock 206 238 311 minecraft:sea_lantern
setblock 206 238 313 minecraft:sea_lantern
setblock 206 238 315 minecraft:sea_lantern
setblock 207 238 310 minecraft:sea_lantern
setblock 207 238 312 minecraft:sea_lantern
setblock 207 238 314 minecraft:sea_lantern
setblock 207 238 316 minecraft:sea_lantern
setblock 208 238 311 minecraft:sea_lantern
setblock 208 238 313 minecraft:sea_lantern
setblock 208 238 315 minecraft:sea_lantern
setblock 209 238 310 minecraft:sea_lantern
setblock 209 238 312 minecraft:sea_lantern
setblock 209 238 314 minecraft:sea_lantern
setblock 209 238 316 minecraft:sea_lantern
setblock 210 238 311 minecraft:sea_lantern
setblock 210 238 313 minecraft:sea_lantern
setblock 210 238 315 minecraft:sea_lantern
setblock 213 238 317 minecraft:prismarine_bricks
fill 214 238 317 214 245 317 minecraft:prismarine
setblock 221 238 276 minecraft:sea_lantern
setblock 221 238 278 minecraft:sea_lantern
setblock 221 238 280 minecraft:sea_lantern
setblock 221 238 282 minecraft:sea_lantern
setblock 221 238 284 minecraft:sea_lantern
setblock 221 238 286 minecraft:sea_lantern
setblock 222 238 277 minecraft:sea_lantern
setblock 222 238 279 minecraft:sea_lantern
setblock 222 238 281 minecraft:sea_lantern
setblock 222 238 283 minecraft:sea_lantern
setblock 222 238 285 minecraft:sea_lantern
setblock 222 238 301 minecraft:sea_lantern
setblock 222 238 303 minecraft:sea_lantern
setblock 222 238 305 minecraft:sea_lantern
setblock 222 238 307 minecraft:sea_lantern
setblock 222 238 309 minecraft:sea_lantern
setblock 223 238 276 minecraft:sea_lantern
setblock 223 238 278 minecraft:sea_lantern
setblock 223 238 280 minecraft:sea_lantern
setblock 223 238 282 minecraft:sea_lantern
setblock 223 238 284 minecraft:sea_lantern
setblock 223 238 286 minecraft:sea_lantern
setblock 223 238 302 minecraft:sea_lantern
setblock 223 238 304 minecraft:sea_lantern
setblock 223 238 306 minecraft:sea_lantern
setblock 223 238 308 minecraft:sea_lantern
setblock 224 238 277 minecraft:sea_lantern
setblock 224 238 279 minecraft:sea_lantern
setblock 224 238 281 minecraft:sea_lantern
setblock 224 238 283 minecraft:sea_lantern
setblock 224 238 285 minecraft:sea_lantern
setblock 224 238 301 minecraft:sea_lantern
setblock 224 238 303 minecraft:sea_lantern
setblock 224 238 305 minecraft:sea_lantern
setblock 224 238 307 minecraft:sea_lantern
setblock 224 238 309 minecraft:sea_lantern
setblock 225 238 276 minecraft:sea_lantern
setblock 225 238 278 minecraft:sea_lantern
setblock 225 238 280 minecraft:sea_lantern
setblock 225 238 282 minecraft:sea_lantern
setblock 225 238 284 minecraft:sea_lantern
setblock 225 238 286 minecraft:sea_lantern
setblock 225 238 302 minecraft:sea_lantern
setblock 225 238 304 minecraft:sea_lantern
setblock 225 238 306 minecraft:sea_lantern
setblock 225 238 308 minecraft:sea_lantern
setblock 226 238 277 minecraft:sea_lantern
setblock 226 238 279 minecraft:sea_lantern
setblock 226 238 281 minecraft:sea_lantern
setblock 226 238 283 minecraft:sea_lantern
setblock 226 238 285 minecraft:sea_lantern
setblock 226 238 301 minecraft:sea_lantern
setblock 226 238 303 minecraft:sea_lantern
setblock 226 238 305 minecraft:sea_lantern
setblock 226 238 307 minecraft:sea_lantern
setblock 226 238 309 minecraft:sea_lantern
setblock 227 238 276 minecraft:sea_lantern
setblock 227 238 278 minecraft:sea_lantern
setblock 227 238 280 minecraft:sea_lantern
setblock 227 238 282 minecraft:sea_lantern
setblock 227 238 284 minecraft:sea_lantern
setblock 227 238 286 minecraft:sea_lantern
setblock 227 238 302 minecraft:sea_lantern
setblock 227 238 304 minecraft:sea_lantern
setblock 227 238 306 minecraft:sea_lantern
setblock 227 238 308 minecraft:sea_lantern
setblock 228 238 277 minecraft:sea_lantern
setblock 228 238 279 minecraft:sea_lantern
setblock 228 238 281 minecraft:sea_lantern
setblock 228 238 283 minecraft:sea_lantern
setblock 228 238 285 minecraft:sea_lantern
setblock 228 238 301 minecraft:sea_lantern
setblock 228 238 303 minecraft:sea_lantern
setblock 228 238 305 minecraft:sea_lantern
setblock 228 238 307 minecraft:sea_lantern
setblock 228 238 309 minecraft:sea_lantern
setblock 229 238 276 minecraft:sea_lantern
setblock 229 238 278 minecraft:sea_lantern
setblock 229 238 280 minecraft:sea_lantern
setblock 229 238 282 minecraft:sea_lantern
setblock 229 238 284 minecraft:sea_lantern
setblock 229 238 286 minecraft:sea_lantern
setblock 229 238 302 minecraft:sea_lantern
setblock 229 238 304 minecraft:sea_lantern
setblock 229 238 306 minecraft:sea_lantern
setblock 229 238 308 minecraft:sea_lantern
fill 188 239 301 188 255 301 minecraft:prismarine
setblock 188 239 312 minecraft:prismarine_bricks
fill 189 239 294 189 240 294 minecraft:prismarine_bricks
fill 189 239 296 189 240 296 minecraft:prismarine_bricks
fill 189 239 298 189 240 298 minecraft:prismarine_bricks
fill 189 239 300 189 240 300 minecraft:prismarine_bricks
fill 189 239 302 189 240 302 minecraft:prismarine_bricks
fill 189 239 304 189 240 304 minecraft:prismarine_bricks
fill 190 239 295 190 240 295 minecraft:quartz_pillar
fill 190 239 297 190 240 297 minecraft:quartz_pillar
fill 190 239 299 190 240 299 minecraft:prismarine_bricks
fill 190 239 301 190 240 301 minecraft:prismarine_bricks
fill 190 239 303 190 240 303 minecraft:prismarine_bricks
setblock 191 239 286 minecraft:light[level=15]
fill 191 239 294 191 240 294 minecraft:prismarine_bricks
fill 191 239 296 191 240 296 minecraft:quartz_pillar
fill 191 239 298 191 240 298 minecraft:prismarine_bricks
fill 191 239 300 191 240 300 minecraft:prismarine_bricks
fill 191 239 302 191 240 302 minecraft:prismarine_bricks
fill 191 239 304 191 240 304 minecraft:prismarine_bricks
setblock 191 239 310 minecraft:light[level=15]
fill 192 239 295 192 240 295 minecraft:quartz_pillar
fill 192 239 297 192 240 297 minecraft:quartz_pillar
fill 192 239 299 192 240 299 minecraft:prismarine_bricks
fill 192 239 301 192 240 301 minecraft:prismarine_bricks
fill 192 239 303 192 240 303 minecraft:prismarine_bricks
fill 193 239 294 193 240 294 minecraft:prismarine_bricks
fill 193 239 296 193 240 296 minecraft:prismarine_bricks
fill 193 239 298 193 240 298 minecraft:prismarine_bricks
fill 193 239 300 193 240 300 minecraft:prismarine_bricks
fill 193 239 302 193 240 302 minecraft:prismarine_bricks
fill 193 239 304 193 240 304 minecraft:prismarine_bricks
setblock 199 239 278 minecraft:light[level=15]
setblock 199 239 286 minecraft:light[level=15]
setblock 199 239 294 minecraft:light[level=15]
setblock 199 239 302 minecraft:light[level=15]
setblock 199 239 310 minecraft:light[level=15]
fill 202 239 311 202 240 311 minecraft:prismarine_bricks
fill 202 239 313 202 240 313 minecraft:prismarine_bricks
fill 202 239 315 202 240 315 minecraft:prismarine_bricks
fill 203 239 310 203 240 310 minecraft:prismarine_bricks
fill 203 239 312 203 240 312 minecraft:prismarine_bricks
fill 203 239 314 203 240 314 minecraft:prismarine_bricks
fill 203 239 316 203 240 316 minecraft:prismarine_bricks
fill 204 239 311 204 240 311 minecraft:prismarine_bricks
fill 204 239 313 204 240 313 minecraft:prismarine_bricks
fill 204 239 315 204 240 315 minecraft:prismarine_bricks
fill 205 239 310 205 240 310 minecraft:prismarine_bricks
fill 205 239 312 205 240 312 minecraft:prismarine_bricks
fill 205 239 314 205 240 314 minecraft:prismarine_bricks
fill 205 239 316 205 240 316 minecraft:prismarine_bricks
fill 206 239 311 206 240 311 minecraft:prismarine_bricks
fill 206 239 313 206 240 313 minecraft:prismarine_bricks
fill 206 239 315 206 240 315 minecraft:prismarine_bricks
setblock 207 239 278 minecraft:light[level=15]
setblock 207 239 286 minecraft:light[level=15]
setblock 207 239 294 minecraft:light[level=15]
setblock 207 239 302 minecraft:light[level=15]
fill 207 239 310 207 240 310 minecraft:prismarine_bricks
fill 207 239 312 207 240 312 minecraft:prismarine_bricks
fill 207 239 314 207 240 314 minecraft:prismarine_bricks
fill 207 239 316 207 240 316 minecraft:prismarine_bricks
fill 208 239 311 208 240 311 minecraft:prismarine_bricks
fill 208 239 313 208 240 313 minecraft:quartz_pillar
fill 208 239 315 208 240 315 minecraft:quartz_pillar
fill 209 239 310 209 240 310 minecraft:prismarine_bricks
fill 209 239 312 209 240 312 minecraft:prismarine_bricks
fill 209 239 314 209 240 314 minecraft:quartz_pillar
fill 209 239 316 209 240 316 minecraft:prismarine_bricks
fill 210 239 311 210 240 311 minecraft:prismarine_bricks
fill 210 239 313 210 240 313 minecraft:quartz_pillar
fill 210 239 315 210 240 315 minecraft:quartz_pillar
fill 213 239 317 213 245 317 minecraft:prismarine
fill 214 239 279 214 253 279 minecraft:green_terracotta
setblock 215 239 278 minecraft:light[level=15]
setblock 215 239 286 minecraft:light[level=15]
setblock 215 239 294 minecraft:light[level=15]
setblock 215 239 302 minecraft:light[level=15]
setblock 215 239 310 minecraft:light[level=15]
fill 218 239 280 219 240 280 minecraft:light_blue_stained_glass
setblock 219 239 275 minecraft:prismarine_bricks
fill 221 239 276 221 240 276 minecraft:prismarine_bricks
fill 221 239 278 221 240 278 minecraft:prismarine_bricks
fill 221 239 280 221 240 280 minecraft:prismarine_bricks
fill 221 239 282 221 240 282 minecraft:prismarine_bricks
fill 221 239 284 221 240 284 minecraft:prismarine_bricks
fill 221 239 286 221 240 286 minecraft:prismarine_bricks
fill 222 239 277 222 240 277 minecraft:prismarine_bricks
fill 222 239 279 222 240 279 minecraft:prismarine_bricks
fill 222 239 281 222 240 281 minecraft:prismarine_bricks
fill 222 239 283 222 240 283 minecraft:prismarine_bricks
fill 222 239 285 222 240 285 minecraft:prismarine_bricks
setblock 222 239 301 minecraft:prismarine_bricks
setblock 222 239 303 minecraft:prismarine_bricks
setblock 222 239 305 minecraft:prismarine_bricks
setblock 222 239 307 minecraft:prismarine_bricks
setblock 222 239 309 minecraft:prismarine_bricks
fill 223 239 276 223 240 276 minecraft:prismarine_bricks
fill 223 239 278 223 240 278 minecraft:prismarine_bricks
fill 223 239 280 223 240 280 minecraft:prismarine_bricks
fill 223 239 282 223 240 282 minecraft:prismarine_bricks
fill 223 239 284 223 240 284 minecraft:prismarine_bricks
fill 223 239 286 223 240 286 minecraft:prismarine_bricks
setblock 223 239 294 minecraft:light[level=15]
setblock 223 239 302 minecraft:prismarine_bricks
setblock 223 239 304 minecraft:prismarine_bricks
setblock 223 239 306 minecraft:prismarine_bricks
setblock 223 239 308 minecraft:prismarine_bricks
setblock 223 239 310 minecraft:light[level=15]
fill 224 239 277 224 240 277 minecraft:prismarine_bricks
fill 224 239 279 224 240 279 minecraft:prismarine_bricks
fill 224 239 281 224 240 281 minecraft:prismarine_bricks
fill 224 239 283 224 240 283 minecraft:prismarine_bricks
fill 224 239 285 224 240 285 minecraft:prismarine_bricks
setblock 224 239 301 minecraft:prismarine_bricks
fill 224 239 302 228 239 310 minecraft:gold_block
fill 225 239 276 225 240 276 minecraft:prismarine_bricks
fill 225 239 278 225 240 278 minecraft:quartz_pillar
fill 225 239 280 225 240 280 minecraft:quartz_pillar
fill 225 239 282 225 240 282 minecraft:prismarine_bricks
fill 225 239 284 225 240 284 minecraft:prismarine_bricks
fill 225 239 286 225 240 286 minecraft:prismarine_bricks
fill 226 239 277 226 240 277 minecraft:prismarine_bricks
fill 226 239 279 226 240 279 minecraft:quartz_pillar
fill 226 239 281 226 240 281 minecraft:prismarine_bricks
fill 226 239 283 226 240 283 minecraft:prismarine_bricks
fill 226 239 285 226 240 285 minecraft:prismarine_bricks
setblock 226 239 301 minecraft:prismarine_bricks
fill 227 239 276 227 240 276 minecraft:prismarine_bricks
fill 227 239 278 227 240 278 minecraft:quartz_pillar
fill 227 239 280 227 240 280 minecraft:quartz_pillar
fill 227 239 282 227 240 282 minecraft:prismarine_bricks
fill 227 239 284 227 240 284 minecraft:prismarine_bricks
fill 227 239 286 227 240 286 minecraft:prismarine_bricks
fill 228 239 277 228 240 277 minecraft:prismarine_bricks
fill 228 239 279 228 240 279 minecraft:prismarine_bricks
fill 228 239 281 228 240 281 minecraft:prismarine_bricks
fill 228 239 283 228 240 283 minecraft:prismarine_bricks
fill 228 239 285 228 240 285 minecraft:prismarine_bricks
setblock 228 239 301 minecraft:prismarine_bricks
fill 229 239 276 229 240 276 minecraft:prismarine_bricks
fill 229 239 278 229 240 278 minecraft:prismarine_bricks
fill 229 239 280 229 240 280 minecraft:prismarine_bricks
fill 229 239 282 229 240 282 minecraft:prismarine_bricks
fill 229 239 284 229 240 284 minecraft:prismarine_bricks
fill 229 239 286 229 240 286 minecraft:prismarine_bricks
setblock 229 239 302 minecraft:prismarine_bricks
setblock 229 239 304 minecraft:prismarine_bricks
setblock 229 239 306 minecraft:prismarine_bricks
fill 229 239 308 229 272 308 minecraft:prismarine_bricks
fill 229 239 310 229 272 310 minecraft:prismarine_bricks
setblock 188 240 282 minecraft:sea_lantern
fill 188 240 312 188 245 312 minecraft:prismarine
fill 190 240 285 190 245 287 minecraft:prismarine_bricks
fill 190 240 309 190 245 311 minecraft:prismarine_bricks
fill 196 240 315 198 245 315 minecraft:prismarine_bricks
fill 200 240 277 202 245 277 minecraft:prismarine_bricks
fill 212 240 277 214 245 277 minecraft:prismarine_bricks
setblock 218 240 317 minecraft:prismarine_bricks
fill 219 240 275 219 245 275 minecraft:prismarine
fill 219 240 317 219 243 317 minecraft:prismarine
fill 220 240 315 222 245 315 minecraft:prismarine_bricks
fill 223 240 302 228 240 308 minecraft:gold_block
fill 225 240 309 227 240 309 minecraft:gold_block
fill 228 240 287 228 245 287 minecraft:prismarine_bricks
fill 228 240 298 228 245 299 minecraft:prismarine_bricks
fill 228 240 309 228 245 311 minecraft:prismarine_bricks
fill 188 241 282 188 245 282 minecraft:prismarine
setblock 189 241 294 minecraft:sea_lantern
setblock 189 241 296 minecraft:sea_lantern
setblock 189 241 298 minecraft:sea_lantern
setblock 189 241 300 minecraft:sea_lantern
setblock 189 241 302 minecraft:sea_lantern
setblock 189 241 304 minecraft:sea_lantern
setblock 190 241 295 minecraft:sea_lantern
setblock 190 241 297 minecraft:sea_lantern
setblock 190 241 299 minecraft:sea_lantern
setblock 190 241 301 minecraft:sea_lantern
setblock 190 241 303 minecraft:sea_lantern
setblock 191 241 294 minecraft:sea_lantern
setblock 191 241 296 minecraft:sea_lantern
setblock 191 241 298 minecraft:sea_lantern
setblock 191 241 300 minecraft:sea_lantern
setblock 191 241 302 minecraft:sea_lantern
setblock 191 241 304 minecraft:sea_lantern
setblock 192 241 295 minecraft:sea_lantern
setblock 192 241 297 minecraft:sea_lantern
setblock 192 241 299 minecraft:sea_lantern
setblock 192 241 301 minecraft:sea_lantern
setblock 192 241 303 minecraft:sea_lantern
setblock 193 241 294 minecraft:sea_lantern
setblock 193 241 296 minecraft:sea_lantern
setblock 193 241 298 minecraft:sea_lantern
setblock 193 241 300 minecraft:sea_lantern
setblock 193 241 302 minecraft:sea_lantern
setblock 193 241 304 minecraft:sea_lantern
setblock 202 241 311 minecraft:sea_lantern
setblock 202 241 313 minecraft:sea_lantern
setblock 202 241 315 minecraft:sea_lantern
setblock 203 241 310 minecraft:sea_lantern
setblock 203 241 312 minecraft:sea_lantern
setblock 203 241 314 minecraft:sea_lantern
setblock 203 241 316 minecraft:sea_lantern
setblock 204 241 311 minecraft:sea_lantern
setblock 204 241 313 minecraft:sea_lantern
setblock 204 241 315 minecraft:sea_lantern
setblock 205 241 310 minecraft:sea_lantern
setblock 205 241 312 minecraft:sea_lantern
setblock 205 241 314 minecraft:sea_lantern
setblock 205 241 316 minecraft:sea_lantern
setblock 206 241 311 minecraft:sea_lantern
setblock 206 241 313 minecraft:sea_lantern
setblock 206 241 315 minecraft:sea_lantern
setblock 207 241 310 minecraft:sea_lantern
setblock 207 241 312 minecraft:sea_lantern
setblock 207 241 314 minecraft:sea_lantern
setblock 207 241 316 minecraft:sea_lantern
setblock 208 241 311 minecraft:sea_lantern
setblock 208 241 313 minecraft:sea_lantern
setblock 208 241 315 minecraft:sea_lantern
setblock 209 241 310 minecraft:sea_lantern
setblock 209 241 312 minecraft:sea_lantern
setblock 209 241 314 minecraft:sea_lantern
setblock 209 241 316 minecraft:sea_lantern
setblock 210 241 311 minecraft:sea_lantern
setblock 210 241 313 minecraft:sea_lantern
setblock 210 241 315 minecraft:sea_lantern
fill 218 241 317 218 271 317 minecraft:prismarine
setblock 221 241 276 minecraft:sea_lantern
setblock 221 241 278 minecraft:sea_lantern
setblock 221 241 280 minecraft:sea_lantern
setblock 221 241 282 minecraft:sea_lantern
setblock 221 241 284 minecraft:sea_lantern
setblock 221 241 286 minecraft:sea_lantern
setblock 222 241 277 minecraft:sea_lantern
setblock 222 241 279 minecraft:sea_lantern
setblock 222 241 281 minecraft:sea_lantern
setblock 222 241 283 minecraft:sea_lantern
setblock 222 241 285 minecraft:sea_lantern
setblock 223 241 276 minecraft:sea_lantern
setblock 223 241 278 minecraft:sea_lantern
setblock 223 241 280 minecraft:sea_lantern
setblock 223 241 282 minecraft:sea_lantern
setblock 223 241 284 minecraft:sea_lantern
setblock 223 241 286 minecraft:sea_lantern
setblock 224 241 277 minecraft:sea_lantern
setblock 224 241 279 minecraft:sea_lantern
setblock 224 241 281 minecraft:sea_lantern
setblock 224 241 283 minecraft:sea_lantern
setblock 224 241 285 minecraft:sea_lantern
fill 224 241 303 227 241 307 minecraft:gold_block
setblock 225 241 276 minecraft:sea_lantern
setblock 225 241 278 minecraft:sea_lantern
setblock 225 241 280 minecraft:sea_lantern
setblock 225 241 282 minecraft:sea_lantern
setblock 225 241 284 minecraft:sea_lantern
setblock 225 241 286 minecraft:sea_lantern
setblock 226 241 277 minecraft:sea_lantern
setblock 226 241 279 minecraft:sea_lantern
setblock 226 241 281 minecraft:sea_lantern
setblock 226 241 283 minecraft:sea_lantern
setblock 226 241 285 minecraft:sea_lantern
setblock 226 241 308 minecraft:gold_block
setblock 227 241 276 minecraft:sea_lantern
setblock 227 241 278 minecraft:sea_lantern
setblock 227 241 280 minecraft:sea_lantern
setblock 227 241 282 minecraft:sea_lantern
setblock 227 241 284 minecraft:sea_lantern
setblock 227 241 286 minecraft:sea_lantern
setblock 228 241 277 minecraft:sea_lantern
setblock 228 241 279 minecraft:sea_lantern
setblock 228 241 281 minecraft:sea_lantern
setblock 228 241 283 minecraft:sea_lantern
setblock 228 241 285 minecraft:sea_lantern
setblock 229 241 276 minecraft:sea_lantern
setblock 229 241 278 minecraft:sea_lantern
setblock 229 241 280 minecraft:sea_lantern
setblock 229 241 282 minecraft:sea_lantern
setblock 229 241 284 minecraft:sea_lantern
setblock 229 241 286 minecraft:sea_lantern
setblock 230 241 296 minecraft:sea_lantern
setblock 230 241 306 minecraft:prismarine_bricks
fill 230 241 307 230 308 307 minecraft:prismarine
setblock 230 241 308 minecraft:sea_lantern
fill 188 242 294 188 245 294 minecraft:prismarine
setblock 188 242 295 minecraft:sea_lantern
fill 189 242 294 189 243 294 minecraft:prismarine_bricks
fill 189 242 296 189 243 296 minecraft:prismarine_bricks
fill 189 242 298 189 243 298 minecraft:prismarine_bricks
fill 189 242 300 189 243 300 minecraft:prismarine_bricks
fill 189 242 302 189 243 302 minecraft:prismarine_bricks
fill 189 242 304 189 243 304 minecraft:prismarine_bricks
fill 190 242 295 190 243 295 minecraft:quartz_pillar
fill 190 242 297 190 243 297 minecraft:quartz_pillar
fill 190 242 299 190 243 299 minecraft:prismarine_bricks
fill 190 242 301 190 243 301 minecraft:prismarine_bricks
fill 190 242 303 190 243 303 minecraft:prismarine_bricks
fill 191 242 294 191 243 294 minecraft:prismarine_bricks
fill 191 242 296 191 243 296 minecraft:quartz_pillar
fill 191 242 298 191 243 298 minecraft:prismarine_bricks
fill 191 242 300 191 243 300 minecraft:prismarine_bricks
fill 191 242 302 191 243 302 minecraft:prismarine_bricks
fill 191 242 304 191 243 304 minecraft:prismarine_bricks
fill 192 242 295 192 243 295 minecraft:quartz_pillar
fill 192 242 297 192 243 297 minecraft:quartz_pillar
fill 192 242 299 192 243 299 minecraft:prismarine_bricks
fill 192 242 301 192 243 301 minecraft:prismarine_bricks
fill 192 242 303 192 243 303 minecraft:prismarine_bricks
fill 193 242 294 193 243 294 minecraft:prismarine_bricks
fill 193 242 296 193 243 296 minecraft:prismarine_bricks
fill 193 242 298 193 243 298 minecraft:prismarine_bricks
fill 193 242 300 193 243 300 minecraft:prismarine_bricks
fill 193 242 302 193 243 302 minecraft:prismarine_bricks
fill 193 242 304 193 243 304 minecraft:prismarine_bricks
fill 202 242 311 202 243 311 minecraft:prismarine_bricks
fill 202 242 313 202 243 313 minecraft:prismarine_bricks
fill 202 242 315 202 243 315 minecraft:prismarine_bricks
fill 203 242 310 203 243 310 minecraft:prismarine_bricks
fill 203 242 312 203 243 312 minecraft:prismarine_bricks
fill 203 242 314 203 243 314 minecraft:prismarine_bricks
fill 203 242 316 203 243 316 minecraft:prismarine_bricks
fill 204 242 311 204 243 311 minecraft:prismarine_bricks
fill 204 242 313 204 243 313 minecraft:prismarine_bricks
fill 204 242 315 204 243 315 minecraft:prismarine_bricks
fill 205 242 310 205 243 310 minecraft:prismarine_bricks
fill 205 242 312 205 243 312 minecraft:prismarine_bricks
fill 205 242 314 205 243 314 minecraft:prismarine_bricks
fill 205 242 316 205 243 316 minecraft:prismarine_bricks
fill 206 242 311 206 243 311 minecraft:prismarine_bricks
fill 206 242 313 206 243 313 minecraft:prismarine_bricks
fill 206 242 315 206 243 315 minecraft:prismarine_bricks
fill 207 242 310 207 243 310 minecraft:prismarine_bricks
fill 207 242 312 207 243 312 minecraft:prismarine_bricks
fill 207 242 314 207 243 314 minecraft:prismarine_bricks
fill 207 242 316 207 272 316 minecraft:prismarine_bricks
fill 208 242 311 208 243 311 minecraft:prismarine_bricks
fill 208 242 313 208 255 313 minecraft:quartz_pillar
fill 208 242 315 208 255 315 minecraft:quartz_pillar
fill 209 242 310 209 243 310 minecraft:prismarine_bricks
fill 209 242 312 209 243 312 minecraft:prismarine_bricks
fill 209 242 314 209 255 314 minecraft:quartz_pillar
fill 209 242 316 209 242 317 minecraft:prismarine_bricks
fill 210 242 311 210 243 311 minecraft:prismarine_bricks
fill 210 242 313 210 255 313 minecraft:quartz_pillar
fill 210 242 315 210 255 315 minecraft:quartz_pillar
setblock 221 242 276 minecraft:prismarine_bricks
setblock 221 242 278 minecraft:prismarine_bricks
setblock 221 242 280 minecraft:prismarine_bricks
setblock 221 242 282 minecraft:prismarine_bricks
setblock 221 242 284 minecraft:prismarine_bricks
setblock 221 242 286 minecraft:prismarine_bricks
setblock 222 242 277 minecraft:prismarine_bricks
setblock 222 242 279 minecraft:prismarine_bricks
setblock 222 242 281 minecraft:prismarine_bricks
setblock 222 242 283 minecraft:prismarine_bricks
setblock 222 242 285 minecraft:prismarine_bricks
setblock 223 242 276 minecraft:prismarine_bricks
setblock 223 242 278 minecraft:prismarine_bricks
setblock 223 242 280 minecraft:prismarine_bricks
setblock 223 242 282 minecraft:prismarine_bricks
setblock 223 242 284 minecraft:prismarine_bricks
setblock 223 242 286 minecraft:prismarine_bricks
fill 224 242 277 224 245 277 minecraft:prismarine_bricks
setblock 224 242 279 minecraft:prismarine_bricks
setblock 224 242 281 minecraft:prismarine_bricks
setblock 224 242 283 minecraft:prismarine_bricks
setblock 224 242 285 minecraft:prismarine_bricks
fill 225 242 276 225 272 276 minecraft:prismarine_bricks
fill 225 242 278 225 255 278 minecraft:quartz_pillar
fill 225 242 280 225 255 280 minecraft:quartz_pillar
setblock 225 242 282 minecraft:prismarine_bricks
setblock 225 242 284 minecraft:prismarine_bricks
setblock 225 242 286 minecraft:prismarine_bricks
fill 225 242 304 226 242 307 minecraft:gold_block
fill 226 242 277 226 245 277 minecraft:prismarine_bricks
fill 226 242 279 226 255 279 minecraft:quartz_pillar
setblock 226 242 281 minecraft:prismarine_bricks
setblock 226 242 283 minecraft:prismarine_bricks
setblock 226 242 285 minecraft:prismarine_bricks
fill 227 242 276 227 272 276 minecraft:prismarine_bricks
fill 227 242 278 227 255 278 minecraft:quartz_pillar
fill 227 242 280 227 255 280 minecraft:quartz_pillar
setblock 227 242 282 minecraft:prismarine_bricks
setblock 227 242 284 minecraft:prismarine_bricks
setblock 227 242 286 minecraft:prismarine_bricks
fill 227 242 305 227 242 307 minecraft:gold_block
setblock 228 242 277 minecraft:prismarine_bricks
setblock 228 242 279 minecraft:prismarine_bricks
setblock 228 242 281 minecraft:prismarine_bricks
setblock 228 242 283 minecraft:prismarine_bricks
fill 228 242 285 228 245 285 minecraft:prismarine_bricks
setblock 229 242 276 minecraft:prismarine_bricks
setblock 229 242 278 minecraft:prismarine_bricks
setblock 229 242 280 minecraft:prismarine_bricks
setblock 229 242 282 minecraft:prismarine_bricks
fill 229 242 284 229 272 284 minecraft:prismarine_bricks
fill 229 242 286 229 272 286 minecraft:prismarine_bricks
fill 230 242 296 230 308 296 minecraft:prismarine
fill 230 242 306 230 298 306 minecraft:prismarine
setblock 230 242 308 minecraft:prismarine
fill 188 243 295 188 245 295 minecraft:prismarine
setblock 191 243 285 minecraft:light[level=12]
setblock 191 243 292 minecraft:light[level=12]
setblock 191 243 306 minecraft:light[level=12]
setblock 198 243 278 minecraft:light[level=12]
setblock 198 243 285 minecraft:light[level=12]
setblock 198 243 292 minecraft:light[level=12]
setblock 198 243 299 minecraft:light[level=12]
setblock 198 243 306 minecraft:light[level=12]
setblock 198 243 313 minecraft:light[level=12]
setblock 200 243 317 minecraft:prismarine_bricks
setblock 203 243 275 minecraft:sea_lantern
fill 204 243 275 204 285 275 minecraft:prismarine
setblock 205 243 278 minecraft:light[level=12]
setblock 205 243 285 minecraft:light[level=12]
setblock 205 243 292 minecraft:light[level=12]
setblock 205 243 299 minecraft:light[level=12]
setblock 205 243 306 minecraft:light[level=12]
fill 209 243 316 209 272 316 minecraft:prismarine_bricks
fill 209 243 317 209 256 317 minecraft:prismarine
setblock 212 243 278 minecraft:light[level=12]
setblock 212 243 285 minecraft:light[level=12]
setblock 212 243 292 minecraft:light[level=12]
setblock 212 243 299 minecraft:light[level=12]
setblock 212 243 306 minecraft:light[level=12]
setblock 212 243 313 minecraft:light[level=12]
setblock 219 243 278 minecraft:light[level=12]
setblock 219 243 285 minecraft:light[level=12]
setblock 219 243 292 minecraft:light[level=12]
setblock 219 243 299 minecraft:light[level=12]
setblock 219 243 306 minecraft:light[level=12]
setblock 219 243 313 minecraft:light[level=12]
fill 222 243 277 223 243 285 minecraft:gold_block
fill 224 243 278 224 243 285 minecraft:gold_block
fill 225 243 281 227 243 285 minecraft:gold_block
fill 225 243 305 226 243 305 minecraft:gold_block
setblock 226 243 292 minecraft:light[level=12]
setblock 226 243 299 minecraft:light[level=12]
setblock 226 243 306 minecraft:light[level=12]
fill 227 243 277 228 243 277 minecraft:gold_block
fill 228 243 278 228 243 284 minecraft:gold_block
setblock 230 243 308 minecraft:prismarine_bricks
setblock 189 244 294 minecraft:sea_lantern
setblock 189 244 296 minecraft:sea_lantern
setblock 189 244 298 minecraft:sea_lantern
setblock 189 244 300 minecraft:sea_lantern
setblock 189 244 302 minecraft:sea_lantern
setblock 189 244 304 minecraft:sea_lantern
setblock 190 244 295 minecraft:sea_lantern
setblock 190 244 297 minecraft:sea_lantern
setblock 190 244 299 minecraft:sea_lantern
setblock 190 244 301 minecraft:sea_lantern
setblock 190 244 303 minecraft:sea_lantern
setblock 191 244 294 minecraft:sea_lantern
setblock 191 244 296 minecraft:sea_lantern
setblock 191 244 298 minecraft:sea_lantern
setblock 191 244 300 minecraft:sea_lantern
setblock 191 244 302 minecraft:sea_lantern
setblock 191 244 304 minecraft:sea_lantern
setblock 192 244 295 minecraft:sea_lantern
setblock 192 244 297 minecraft:sea_lantern
setblock 192 244 299 minecraft:sea_lantern
setblock 192 244 301 minecraft:sea_lantern
setblock 192 244 303 minecraft:sea_lantern
setblock 193 244 294 minecraft:sea_lantern
setblock 193 244 296 minecraft:sea_lantern
setblock 193 244 298 minecraft:sea_lantern
setblock 193 244 300 minecraft:sea_lantern
setblock 193 244 302 minecraft:sea_lantern
setblock 193 244 304 minecraft:sea_lantern
fill 195 244 282 195 257 282 minecraft:iron_block
fill 200 244 317 200 245 317 minecraft:prismarine
setblock 203 244 275 minecraft:prismarine
fill 203 244 311 207 244 315 minecraft:gold_block
fill 208 244 311 209 244 312 minecraft:gold_block
setblock 219 244 317 minecraft:prismarine_bricks
setblock 222 244 280 minecraft:prismarine_bricks
fill 223 244 278 224 244 284 minecraft:gold_block
fill 225 244 281 227 244 284 minecraft:gold_block
fill 230 244 308 230 308 308 minecraft:prismarine
setblock 188 245 284 minecraft:prismarine_bricks
fill 189 245 279 189 245 284 minecraft:dark_prismarine
fill 189 245 291 189 245 296 minecraft:dark_prismarine
fill 189 245 298 189 246 298 minecraft:prismarine_bricks
fill 189 245 300 189 246 300 minecraft:prismarine_bricks
fill 189 245 302 189 246 302 minecraft:prismarine_bricks
fill 189 245 303 189 245 308 minecraft:dark_prismarine
fill 189 245 315 189 245 316 minecraft:dark_prismarine
fill 190 245 295 190 246 295 minecraft:quartz_pillar
fill 190 245 297 190 246 297 minecraft:quartz_pillar
fill 190 245 299 190 246 299 minecraft:prismarine_bricks
fill 190 245 301 190 246 301 minecraft:prismarine_bricks
fill 190 245 303 190 246 303 minecraft:prismarine_bricks
fill 190 245 316 193 245 316 minecraft:dark_prismarine
fill 191 245 294 191 246 294 minecraft:prismarine_bricks
fill 191 245 296 191 246 296 minecraft:quartz_pillar
fill 191 245 298 191 246 298 minecraft:prismarine_bricks
fill 191 245 300 191 246 300 minecraft:prismarine_bricks
fill 191 245 302 191 246 302 minecraft:prismarine_bricks
fill 191 245 304 191 246 304 minecraft:prismarine_bricks
fill 192 245 295 192 246 295 minecraft:quartz_pillar
fill 192 245 297 192 246 297 minecraft:quartz_pillar
fill 192 245 299 192 246 299 minecraft:prismarine_bricks
fill 192 245 301 192 246 301 minecraft:prismarine_bricks
fill 192 245 303 192 246 303 minecraft:prismarine_bricks
fill 193 245 276 198 245 276 minecraft:dark_prismarine
fill 193 245 294 193 246 294 minecraft:prismarine_bricks
fill 193 245 296 193 246 296 minecraft:prismarine_bricks
fill 193 245 298 193 246 298 minecraft:prismarine_bricks
fill 193 245 300 193 246 300 minecraft:prismarine_bricks
fill 193 245 302 193 246 302 minecraft:prismarine_bricks
fill 193 245 304 193 246 304 minecraft:prismarine_bricks
fill 200 245 316 205 245 316 minecraft:dark_prismarine
setblock 203 245 275 minecraft:sea_lantern
fill 204 245 312 207 245 314 minecraft:gold_block
fill 205 245 276 210 245 276 minecraft:dark_prismarine
setblock 208 245 312 minecraft:gold_block
fill 212 245 316 217 245 316 minecraft:dark_prismarine
fill 217 245 276 222 245 276 minecraft:dark_prismarine
fill 219 245 317 219 303 317 minecraft:prismarine
setblock 222 245 280 minecraft:sea_lantern
fill 224 245 279 224 245 283 minecraft:gold_block
fill 224 245 316 229 245 316 minecraft:dark_prismarine
fill 225 245 281 226 245 283 minecraft:gold_block
fill 226 245 289 226 246 290 minecraft:white_stained_glass
fill 229 245 276 229 245 281 minecraft:dark_prismarine
fill 229 245 288 229 245 293 minecraft:dark_prismarine
fill 229 245 300 229 245 305 minecraft:dark_prismarine
fill 229 245 312 229 245 315 minecraft:dark_prismarine
fill 188 246 281 188 251 284 minecraft:sea_lantern
fill 188 246 293 188 251 296 minecraft:sea_lantern
fill 188 246 297 188 261 299 minecraft:prismarine
setblock 188 246 300 minecraft:prismarine_bricks
fill 188 246 303 188 287 303 minecraft:prismarine
fill 188 246 304 189 246 304 minecraft:prismarine_bricks
fill 188 246 305 188 251 308 minecraft:sea_lantern
setblock 188 246 312 minecraft:prismarine_bricks
fill 188 246 317 191 251 317 minecraft:sea_lantern
fill 189 246 294 189 246 296 minecraft:prismarine_bricks
fill 189 246 303 189 252 303 minecraft:prismarine_bricks
fill 192 246 317 192 308 317 minecraft:prismarine
setblock 194 246 317 minecraft:prismarine_bricks
fill 195 246 275 198 251 275 minecraft:sea_lantern
fill 195 246 317 196 257 317 minecraft:prismarine
fill 200 246 317 203 251 317 minecraft:sea_lantern
fill 203 246 275 203 308 275 minecraft:prismarine
fill 205 246 313 207 246 313 minecraft:gold_block
fill 207 246 275 210 251 275 minecraft:sea_lantern
fill 212 246 317 215 251 317 minecraft:sea_lantern
fill 219 246 275 222 251 275 minecraft:sea_lantern
fill 224 246 317 227 251 317 minecraft:sea_lantern
fill 225 246 281 225 246 282 minecraft:gold_block
fill 230 246 276 230 251 279 minecraft:sea_lantern
fill 230 246 288 230 251 291 minecraft:sea_lantern
fill 230 246 300 230 251 303 minecraft:sea_lantern
fill 230 246 312 230 251 315 minecraft:sea_lantern
fill 188 247 300 188 308 300 minecraft:prismarine
fill 188 247 304 188 276 304 minecraft:prismarine
fill 188 247 312 188 250 312 minecraft:prismarine
setblock 189 247 294 minecraft:sea_lantern
fill 189 247 295 189 252 295 minecraft:prismarine_bricks
setblock 189 247 296 minecraft:sea_lantern
setblock 189 247 298 minecraft:sea_lantern
setblock 189 247 300 minecraft:sea_lantern
setblock 189 247 302 minecraft:sea_lantern
setblock 189 247 304 minecraft:sea_lantern
setblock 190 247 295 minecraft:sea_lantern
setblock 190 247 297 minecraft:sea_lantern
setblock 190 247 299 minecraft:sea_lantern
setblock 190 247 301 minecraft:sea_lantern
setblock 190 247 303 minecraft:sea_lantern
setblock 191 247 286 minecraft:light[level=15]
setblock 191 247 294 minecraft:sea_lantern
setblock 191 247 296 minecraft:sea_lantern
setblock 191 247 298 minecraft:sea_lantern
setblock 191 247 300 minecraft:sea_lantern
setblock 191 247 302 minecraft:sea_lantern
setblock 191 247 304 minecraft:sea_lantern
setblock 191 247 310 minecraft:light[level=15]
setblock 192 247 295 minecraft:sea_lantern
setblock 192 247 297 minecraft:sea_lantern
setblock 192 247 299 minecraft:sea_lantern
setblock 192 247 301 minecraft:sea_lantern
setblock 192 247 303 minecraft:sea_lantern
setblock 193 247 294 minecraft:sea_lantern
setblock 193 247 296 minecraft:sea_lantern
setblock 193 247 298 minecraft:sea_lantern
setblock 193 247 300 minecraft:sea_lantern
setblock 193 247 302 minecraft:sea_lantern
setblock 193 247 304 minecraft:sea_lantern
fill 194 247 317 194 308 317 minecraft:prismarine
setblock 199 247 278 minecraft:light[level=15]
setblock 199 247 286 minecraft:light[level=15]
setblock 199 247 294 minecraft:light[level=15]
setblock 199 247 302 minecraft:light[level=15]
setblock 199 247 310 minecraft:light[level=15]
fill 206 247 312 206 247 314 minecraft:gold_block
setblock 207 247 278 minecraft:light[level=15]
setblock 207 247 286 minecraft:light[level=15]
setblock 207 247 294 minecraft:light[level=15]
setblock 207 247 302 minecraft:light[level=15]
setblock 207 247 310 minecraft:light[level=15]
setblock 215 247 278 minecraft:light[level=15]
setblock 215 247 286 minecraft:light[level=15]
setblock 215 247 294 minecraft:light[level=15]
setblock 215 247 302 minecraft:light[level=15]
setblock 215 247 310 minecraft:light[level=15]
setblock 223 247 278 minecraft:light[level=15]
setblock 223 247 286 minecraft:light[level=15]
setblock 223 247 294 minecraft:light[level=15]
setblock 223 247 302 minecraft:light[level=15]
setblock 223 247 310 minecraft:light[level=15]
fill 189 248 294 189 249 294 minecraft:prismarine_bricks
fill 189 248 296 189 249 296 minecraft:prismarine_bricks
fill 189 248 298 189 249 298 minecraft:prismarine_bricks
fill 189 248 300 189 249 300 minecraft:prismarine_bricks
fill 189 248 302 189 249 302 minecraft:prismarine_bricks
fill 189 248 304 189 249 304 minecraft:prismarine_bricks
fill 190 248 295 190 249 295 minecraft:quartz_pillar
fill 190 248 297 190 249 297 minecraft:quartz_pillar
fill 190 248 299 190 249 299 minecraft:prismarine_bricks
fill 190 248 301 190 249 301 minecraft:prismarine_bricks
fill 190 248 303 190 249 303 minecraft:prismarine_bricks
fill 191 248 294 191 249 294 minecraft:prismarine_bricks
fill 191 248 296 191 249 296 minecraft:quartz_pillar
fill 191 248 298 191 249 298 minecraft:prismarine_bricks
fill 191 248 300 191 249 300 minecraft:prismarine_bricks
fill 191 248 302 191 249 302 minecraft:prismarine_bricks
fill 191 248 304 191 249 304 minecraft:prismarine_bricks
fill 192 248 295 192 249 295 minecraft:quartz_pillar
fill 192 248 297 192 249 297 minecraft:quartz_pillar
fill 192 248 299 192 249 299 minecraft:prismarine_bricks
fill 192 248 301 192 249 301 minecraft:prismarine_bricks
fill 192 248 303 192 249 303 minecraft:prismarine_bricks
fill 193 248 294 193 249 294 minecraft:prismarine_bricks
fill 193 248 296 193 249 296 minecraft:prismarine_bricks
fill 193 248 298 193 249 298 minecraft:prismarine_bricks
fill 193 248 300 193 249 300 minecraft:prismarine_bricks
fill 193 248 302 193 249 302 minecraft:prismarine_bricks
fill 193 248 304 193 249 304 minecraft:prismarine_bricks
fill 197 248 314 197 265 314 minecraft:iron_block
fill 204 248 317 206 265 317 minecraft:prismarine
setblock 207 248 317 minecraft:prismarine_bricks
fill 208 248 317 208 308 317 minecraft:prismarine
setblock 230 248 293 minecraft:prismarine_bricks
setblock 191 249 285 minecraft:light[level=12]
setblock 191 249 292 minecraft:light[level=12]
setblock 191 249 306 minecraft:light[level=12]
setblock 198 249 278 minecraft:light[level=12]
setblock 198 249 285 minecraft:light[level=12]
setblock 198 249 292 minecraft:light[level=12]
setblock 198 249 299 minecraft:light[level=12]
setblock 198 249 306 minecraft:light[level=12]
setblock 198 249 313 minecraft:light[level=12]
setblock 205 249 278 minecraft:light[level=12]
setblock 205 249 285 minecraft:light[level=12]
setblock 205 249 292 minecraft:light[level=12]
setblock 205 249 299 minecraft:light[level=12]
setblock 205 249 306 minecraft:light[level=12]
setblock 205 249 313 minecraft:light[level=12]
fill 207 249 317 207 292 317 minecraft:prismarine
setblock 212 249 278 minecraft:light[level=12]
setblock 212 249 285 minecraft:light[level=12]
setblock 212 249 292 minecraft:light[level=12]
setblock 212 249 299 minecraft:light[level=12]
setblock 212 249 306 minecraft:light[level=12]
setblock 212 249 313 minecraft:light[level=12]
setblock 219 249 278 minecraft:light[level=12]
setblock 219 249 285 minecraft:light[level=12]
setblock 219 249 292 minecraft:light[level=12]
setblock 219 249 299 minecraft:light[level=12]
setblock 219 249 306 minecraft:light[level=12]
setblock 219 249 313 minecraft:light[level=12]
setblock 226 249 285 minecraft:light[level=12]
setblock 226 249 292 minecraft:light[level=12]
setblock 226 249 299 minecraft:light[level=12]
setblock 226 249 306 minecraft:light[level=12]
fill 230 249 293 230 308 293 minecraft:prismarine
setblock 189 250 294 minecraft:sea_lantern
setblock 189 250 296 minecraft:sea_lantern
setblock 189 250 298 minecraft:sea_lantern
setblock 189 250 300 minecraft:sea_lantern
setblock 189 250 302 minecraft:sea_lantern
setblock 189 250 304 minecraft:sea_lantern
setblock 190 250 295 minecraft:sea_lantern
setblock 190 250 297 minecraft:sea_lantern
setblock 190 250 299 minecraft:sea_lantern
setblock 190 250 301 minecraft:sea_lantern
setblock 190 250 303 minecraft:sea_lantern
setblock 191 250 294 minecraft:sea_lantern
setblock 191 250 296 minecraft:sea_lantern
setblock 191 250 298 minecraft:sea_lantern
setblock 191 250 300 minecraft:sea_lantern
setblock 191 250 302 minecraft:sea_lantern
setblock 191 250 304 minecraft:sea_lantern
setblock 192 250 295 minecraft:sea_lantern
setblock 192 250 297 minecraft:sea_lantern
setblock 192 250 299 minecraft:sea_lantern
setblock 192 250 301 minecraft:sea_lantern
setblock 192 250 303 minecraft:sea_lantern
setblock 193 250 294 minecraft:sea_lantern
setblock 193 250 296 minecraft:sea_lantern
setblock 193 250 298 minecraft:sea_lantern
setblock 193 250 300 minecraft:sea_lantern
setblock 193 250 302 minecraft:sea_lantern
setblock 193 250 304 minecraft:sea_lantern
fill 223 250 302 224 251 303 minecraft:light_blue_stained_glass
setblock 188 251 312 minecraft:prismarine_bricks
fill 189 251 294 189 252 294 minecraft:prismarine_bricks
fill 189 251 296 189 252 296 minecraft:prismarine_bricks
fill 189 251 298 189 272 298 minecraft:prismarine_bricks
fill 189 251 300 189 272 300 minecraft:prismarine_bricks
fill 189 251 302 189 252 302 minecraft:prismarine_bricks
fill 189 251 304 189 252 304 minecraft:prismarine_bricks
fill 190 251 295 190 255 295 minecraft:quartz_pillar
fill 190 251 297 190 255 297 minecraft:quartz_pillar
fill 190 251 299 190 252 299 minecraft:prismarine_bricks
fill 190 251 301 190 252 301 minecraft:prismarine_bricks
fill 190 251 303 190 252 303 minecraft:prismarine_bricks
fill 191 251 294 191 252 294 minecraft:prismarine_bricks
fill 191 251 296 191 255 296 minecraft:quartz_pillar
fill 191 251 298 191 252 298 minecraft:prismarine_bricks
fill 191 251 300 191 252 300 minecraft:prismarine_bricks
fill 191 251 302 191 252 302 minecraft:prismarine_bricks
fill 191 251 304 191 252 304 minecraft:prismarine_bricks
fill 192 251 295 192 255 295 minecraft:quartz_pillar
fill 192 251 297 192 255 297 minecraft:quartz_pillar
fill 192 251 299 192 252 299 minecraft:prismarine_bricks
fill 192 251 301 192 252 301 minecraft:prismarine_bricks
fill 192 251 303 192 252 303 minecraft:prismarine_bricks
fill 193 251 294 193 252 294 minecraft:prismarine_bricks
fill 193 251 296 193 252 296 minecraft:prismarine_bricks
fill 193 251 298 193 252 298 minecraft:prismarine_bricks
fill 193 251 300 193 252 300 minecraft:prismarine_bricks
fill 193 251 302 193 252 302 minecraft:prismarine_bricks
fill 193 251 304 193 252 304 minecraft:prismarine_bricks
fill 188 252 281 188 254 281 minecraft:prismarine
fill 188 252 282 188 252 283 minecraft:sea_lantern
fill 188 252 284 188 265 284 minecraft:prismarine
fill 188 252 293 188 252 295 minecraft:sea_lantern
fill 188 252 296 188 265 296 minecraft:prismarine
fill 188 252 305 188 265 305 minecraft:prismarine
fill 188 252 306 188 252 307 minecraft:sea_lantern
fill 188 252 308 188 256 308 minecraft:prismarine
setblock 188 252 311 minecraft:sea_lantern
fill 188 252 312 188 308 312 minecraft:prismarine
fill 188 252 317 188 265 317 minecraft:prismarine
fill 189 252 317 190 252 317 minecraft:sea_lantern
fill 191 252 317 191 265 317 minecraft:prismarine
fill 195 252 275 195 265 275 minecraft:prismarine
fill 196 252 275 197 252 275 minecraft:sea_lantern
fill 198 252 275 198 265 275 minecraft:prismarine
fill 200 252 317 200 265 317 minecraft:prismarine
fill 201 252 317 202 252 317 minecraft:sea_lantern
fill 203 252 317 203 265 317 minecraft:prismarine
fill 207 252 275 207 265 275 minecraft:prismarine
fill 208 252 275 209 252 275 minecraft:sea_lantern
fill 210 252 275 210 265 275 minecraft:prismarine
fill 212 252 317 212 265 317 minecraft:prismarine
fill 213 252 317 214 252 317 minecraft:sea_lantern
fill 215 252 317 215 265 317 minecraft:prismarine
fill 219 252 275 219 265 275 minecraft:prismarine
fill 220 252 275 221 252 275 minecraft:sea_lantern
fill 222 252 275 222 265 275 minecraft:prismarine
fill 224 252 317 224 265 317 minecraft:prismarine
fill 225 252 317 226 252 317 minecraft:sea_lantern
fill 227 252 317 227 265 317 minecraft:prismarine
fill 230 252 276 230 265 276 minecraft:prismarine
fill 230 252 277 230 252 278 minecraft:sea_lantern
fill 230 252 279 230 265 279 minecraft:prismarine
fill 230 252 288 230 265 288 minecraft:prismarine
fill 230 252 289 230 252 290 minecraft:sea_lantern
fill 230 252 291 230 265 291 minecraft:prismarine
fill 230 252 300 230 265 300 minecraft:prismarine
fill 230 252 301 230 252 302 minecraft:sea_lantern
fill 230 252 303 230 265 303 minecraft:prismarine
fill 230 252 312 230 264 312 minecraft:prismarine
fill 230 252 313 230 252 314 minecraft:sea_lantern
fill 230 252 315 230 265 315 minecraft:prismarine
fill 188 253 282 188 265 283 minecraft:prismarine
fill 188 253 293 188 265 295 minecraft:prismarine
fill 188 253 306 188 265 307 minecraft:prismarine
fill 188 253 311 188 278 311 minecraft:prismarine
fill 189 253 317 190 265 317 minecraft:prismarine
fill 190 253 298 192 253 303 minecraft:gold_block
fill 196 253 275 197 265 275 minecraft:prismarine
fill 199 253 275 199 271 275 minecraft:prismarine
setblock 200 253 275 minecraft:sea_lantern
fill 201 253 317 201 265 317 minecraft:prismarine
setblock 202 253 317 minecraft:sea_lantern
fill 208 253 275 209 256 275 minecraft:prismarine
fill 213 253 317 214 265 317 minecraft:prismarine
fill 220 253 275 221 265 275 minecraft:prismarine
fill 225 253 317 226 265 317 minecraft:prismarine
fill 230 253 277 230 265 278 minecraft:prismarine
fill 230 253 289 230 265 290 minecraft:prismarine
fill 230 253 301 230 265 302 minecraft:prismarine
fill 230 253 313 230 265 314 minecraft:prismarine
fill 191 254 298 191 254 302 minecraft:gold_block
fill 200 254 275 200 308 275 minecraft:prismarine
fill 202 254 317 202 265 317 minecraft:prismarine
fill 212 254 275 213 308 275 minecraft:prismarine
setblock 214 254 275 minecraft:prismarine_bricks
setblock 188 255 281 minecraft:prismarine_bricks
setblock 188 255 302 minecraft:prismarine_bricks
fill 190 255 298 192 255 301 minecraft:gold_block
setblock 191 255 285 minecraft:light[level=12]
setblock 191 255 286 minecraft:light[level=15]
setblock 191 255 292 minecraft:light[level=12]
setblock 191 255 294 minecraft:light[level=15]
setblock 191 255 302 minecraft:light[level=15]
setblock 191 255 306 minecraft:light[level=12]
setblock 191 255 310 minecraft:light[level=15]
setblock 198 255 278 minecraft:light[level=12]
setblock 198 255 285 minecraft:light[level=12]
setblock 198 255 292 minecraft:light[level=12]
setblock 198 255 299 minecraft:light[level=12]
setblock 198 255 306 minecraft:light[level=12]
setblock 198 255 313 minecraft:light[level=12]
setblock 199 255 278 minecraft:light[level=15]
setblock 199 255 286 minecraft:light[level=15]
setblock 199 255 294 minecraft:light[level=15]
setblock 199 255 302 minecraft:light[level=15]
setblock 199 255 310 minecraft:light[level=15]
setblock 205 255 278 minecraft:light[level=12]
setblock 205 255 285 minecraft:light[level=12]
setblock 205 255 292 minecraft:light[level=12]
setblock 205 255 299 minecraft:light[level=12]
setblock 205 255 306 minecraft:light[level=12]
setblock 205 255 313 minecraft:light[level=12]
setblock 207 255 278 minecraft:light[level=15]
setblock 207 255 286 minecraft:light[level=15]
setblock 207 255 294 minecraft:light[level=15]
setblock 207 255 302 minecraft:light[level=15]
setblock 207 255 310 minecraft:light[level=15]
setblock 212 255 278 minecraft:light[level=12]
setblock 212 255 285 minecraft:light[level=12]
setblock 212 255 292 minecraft:light[level=12]
setblock 212 255 299 minecraft:light[level=12]
setblock 212 255 306 minecraft:light[level=12]
setblock 212 255 313 minecraft:light[level=12]
fill 214 255 275 214 308 275 minecraft:prismarine
setblock 215 255 278 minecraft:light[level=15]
setblock 215 255 286 minecraft:light[level=15]
setblock 215 255 294 minecraft:light[level=15]
setblock 215 255 302 minecraft:light[level=15]
setblock 215 255 310 minecraft:light[level=15]
setblock 219 255 278 minecraft:light[level=12]
setblock 219 255 285 minecraft:light[level=12]
setblock 219 255 292 minecraft:light[level=12]
setblock 219 255 299 minecraft:light[level=12]
setblock 219 255 306 minecraft:light[level=12]
setblock 219 255 313 minecraft:light[level=12]
setblock 223 255 278 minecraft:light[level=15]
setblock 223 255 286 minecraft:light[level=15]
setblock 223 255 294 minecraft:light[level=15]
setblock 223 255 302 minecraft:light[level=15]
setblock 223 255 310 minecraft:light[level=15]
setblock 226 255 285 minecraft:light[level=12]
setblock 226 255 292 minecraft:light[level=12]
setblock 226 255 299 minecraft:light[level=12]
setblock 226 255 306 minecraft:light[level=12]
fill 188 256 277 188 258 278 minecraft:prismarine
setblock 188 256 279 minecraft:prismarine_bricks
fill 188 256 280 188 265 281 minecraft:prismarine
setblock 188 256 301 minecraft:sea_lantern
fill 188 256 302 188 308 302 minecraft:prismarine
setblock 188 256 309 minecraft:prismarine_bricks
setblock 188 256 310 minecraft:prismarine
fill 189 256 296 193 257 296 minecraft:prismarine_bricks
fill 190 256 279 194 257 279 minecraft:prismarine_bricks
fill 190 256 295 192 257 295 minecraft:prismarine_bricks
fill 190 256 297 192 257 297 minecraft:prismarine_bricks
fill 190 256 298 190 256 300 minecraft:gold_block
fill 190 256 313 194 257 313 minecraft:prismarine_bricks
fill 191 256 278 193 257 278 minecraft:prismarine_bricks
fill 191 256 280 193 257 280 minecraft:prismarine_bricks
fill 191 256 294 191 257 294 minecraft:prismarine_bricks
fill 191 256 298 191 257 298 minecraft:prismarine_bricks
fill 191 256 299 193 256 300 minecraft:gold_block
fill 191 256 312 193 257 312 minecraft:prismarine_bricks
fill 191 256 314 193 257 314 minecraft:prismarine_bricks
fill 192 256 277 192 257 277 minecraft:prismarine_bricks
fill 192 256 281 192 257 281 minecraft:prismarine_bricks
fill 192 256 298 193 256 298 minecraft:gold_block
fill 192 256 311 192 257 311 minecraft:prismarine_bricks
fill 192 256 315 192 257 315 minecraft:prismarine_bricks
fill 207 256 278 211 257 278 minecraft:prismarine_bricks
fill 207 256 314 211 257 314 minecraft:prismarine_bricks
fill 208 256 277 210 257 277 minecraft:prismarine_bricks
fill 208 256 279 210 257 279 minecraft:prismarine_bricks
fill 208 256 313 210 257 313 minecraft:prismarine_bricks
fill 208 256 315 210 257 315 minecraft:prismarine_bricks
fill 209 256 276 209 257 276 minecraft:prismarine_bricks
fill 209 256 280 209 257 280 minecraft:prismarine_bricks
fill 209 256 312 209 257 312 minecraft:prismarine_bricks
fill 224 256 279 228 257 279 minecraft:prismarine_bricks
fill 224 256 313 228 257 313 minecraft:prismarine_bricks
fill 225 256 278 227 257 278 minecraft:prismarine_bricks
fill 225 256 280 227 257 280 minecraft:prismarine_bricks
fill 225 256 296 228 257 296 minecraft:prismarine_bricks
fill 225 256 312 227 257 312 minecraft:prismarine_bricks
fill 225 256 314 227 257 314 minecraft:prismarine_bricks
fill 226 256 277 226 257 277 minecraft:prismarine_bricks
fill 226 256 281 226 257 281 minecraft:prismarine_bricks
fill 226 256 295 228 257 295 minecraft:prismarine_bricks
fill 226 256 297 228 257 297 minecraft:prismarine_bricks
fill 226 256 311 226 257 311 minecraft:prismarine_bricks
fill 226 256 315 226 257 315 minecraft:prismarine_bricks
fill 227 256 294 227 257 294 minecraft:prismarine_bricks
fill 227 256 298 227 257 298 minecraft:prismarine_bricks
fill 188 257 279 188 264 279 minecraft:prismarine
fill 188 257 301 188 308 301 minecraft:prismarine
setblock 188 257 308 minecraft:prismarine_bricks
fill 188 257 309 188 278 309 minecraft:prismarine
fill 188 257 310 188 258 310 minecraft:sea_lantern
fill 199 257 290 199 258 290 minecraft:sea_lantern
fill 208 257 275 208 265 275 minecraft:prismarine
setblock 209 257 275 minecraft:sea_lantern
setblock 209 257 317 minecraft:sea_lantern
fill 230 257 281 230 286 284 minecraft:prismarine
setblock 230 257 285 minecraft:prismarine_bricks
fill 230 257 286 230 282 286 minecraft:prismarine
fill 188 258 308 188 265 308 minecraft:prismarine
fill 190 258 295 192 285 297 minecraft:quartz_pillar
fill 191 258 278 193 285 280 minecraft:quartz_pillar
fill 191 258 312 193 285 314 minecraft:quartz_pillar
fill 194 258 278 198 259 282 minecraft:dark_prismarine
fill 195 258 317 195 268 317 minecraft:prismarine
fill 196 258 276 196 258 277 minecraft:dark_prismarine
setblock 196 258 317 minecraft:prismarine_bricks
fill 208 258 277 210 285 279 minecraft:quartz_pillar
fill 208 258 313 210 285 315 minecraft:quartz_pillar
fill 209 258 275 209 265 275 minecraft:prismarine
fill 209 258 317 209 308 317 minecraft:prismarine
fill 225 258 278 227 285 280 minecraft:quartz_pillar
fill 225 258 312 227 285 314 minecraft:quartz_pillar
fill 226 258 295 228 285 297 minecraft:quartz_pillar
fill 230 258 285 230 267 285 minecraft:prismarine
setblock 188 259 277 minecraft:sea_lantern
fill 188 259 278 188 308 278 minecraft:prismarine
fill 188 259 310 188 308 310 minecraft:prismarine
fill 196 259 317 196 264 317 minecraft:prismarine
fill 199 259 290 199 266 290 minecraft:dark_prismarine
fill 205 259 275 206 259 275 minecraft:prismarine_bricks
fill 188 260 277 188 308 277 minecraft:prismarine
fill 190 260 285 190 265 287 minecraft:prismarine_bricks
fill 190 260 298 190 265 299 minecraft:prismarine_bricks
fill 190 260 309 190 265 311 minecraft:prismarine_bricks
fill 195 260 279 197 261 281 minecraft:prismarine_bricks
fill 196 260 315 198 265 315 minecraft:prismarine_bricks
fill 200 260 277 202 265 277 minecraft:prismarine_bricks
fill 205 260 275 206 308 275 minecraft:prismarine
fill 212 260 277 214 265 277 minecraft:prismarine_bricks
fill 220 260 315 222 265 315 minecraft:prismarine_bricks
fill 224 260 277 226 265 277 minecraft:prismarine_bricks
fill 224 260 304 225 261 304 minecraft:white_stained_glass
fill 228 260 285 228 265 287 minecraft:prismarine_bricks
fill 228 260 298 228 265 299 minecraft:prismarine_bricks
fill 228 260 309 228 265 311 minecraft:prismarine_bricks
fill 188 261 285 188 265 285 minecraft:prismarine
setblock 188 261 286 minecraft:prismarine_bricks
fill 188 261 287 188 308 287 minecraft:prismarine
setblock 191 261 285 minecraft:light[level=12]
setblock 191 261 292 minecraft:light[level=12]
setblock 191 261 299 minecraft:light[level=12]
setblock 191 261 306 minecraft:light[level=12]
setblock 198 261 278 minecraft:light[level=12]
setblock 198 261 285 minecraft:light[level=12]
setblock 198 261 292 minecraft:light[level=12]
setblock 198 261 299 minecraft:light[level=12]
setblock 198 261 306 minecraft:light[level=12]
setblock 198 261 313 minecraft:light[level=12]
fill 199 261 289 199 266 289 minecraft:dark_prismarine
fill 199 261 291 199 266 291 minecraft:dark_prismarine
fill 200 261 290 200 266 290 minecraft:dark_prismarine
setblock 205 261 278 minecraft:light[level=12]
setblock 205 261 285 minecraft:light[level=12]
setblock 205 261 292 minecraft:light[level=12]
setblock 205 261 299 minecraft:light[level=12]
setblock 205 261 306 minecraft:light[level=12]
setblock 205 261 313 minecraft:light[level=12]
setblock 212 261 278 minecraft:light[level=12]
setblock 212 261 285 minecraft:light[level=12]
setblock 212 261 292 minecraft:light[level=12]
setblock 212 261 299 minecraft:light[level=12]
setblock 212 261 306 minecraft:light[level=12]
setblock 212 261 313 minecraft:light[level=12]
setblock 219 261 278 minecraft:light[level=12]
setblock 219 261 285 minecraft:light[level=12]
setblock 219 261 292 minecraft:light[level=12]
setblock 219 261 299 minecraft:light[level=12]
setblock 219 261 306 minecraft:light[level=12]
setblock 219 261 313 minecraft:light[level=12]
setblock 226 261 285 minecraft:light[level=12]
setblock 226 261 292 minecraft:light[level=12]
setblock 226 261 299 minecraft:light[level=12]
setblock 226 261 306 minecraft:light[level=12]
setblock 230 261 287 minecraft:sea_lantern
fill 188 262 286 188 308 286 minecraft:prismarine
fill 188 262 297 188 308 297 minecraft:prismarine
setblock 188 262 298 minecraft:sea_lantern
fill 188 262 299 188 269 299 minecraft:prismarine
fill 195 262 280 197 264 280 minecraft:prismarine_bricks
fill 196 262 279 196 264 279 minecraft:prismarine_bricks
fill 196 262 281 196 264 281 minecraft:prismarine_bricks
fill 198 262 290 198 266 290 minecraft:dark_prismarine
fill 200 262 289 200 266 289 minecraft:dark_prismarine
fill 200 262 291 200 266 291 minecraft:dark_prismarine
setblock 216 262 275 minecraft:sea_lantern
fill 217 262 275 217 308 275 minecraft:prismarine
fill 230 262 287 230 308 287 minecraft:prismarine
fill 188 263 298 188 308 298 minecraft:prismarine
setblock 191 263 286 minecraft:light[level=15]
setblock 191 263 294 minecraft:light[level=15]
setblock 191 263 302 minecraft:light[level=15]
setblock 191 263 310 minecraft:light[level=15]
setblock 197 263 317 minecraft:sea_lantern
fill 198 263 289 198 266 289 minecraft:dark_prismarine
fill 198 263 291 198 266 291 minecraft:dark_prismarine
setblock 199 263 278 minecraft:light[level=15]
setblock 199 263 286 minecraft:light[level=15]
setblock 199 263 294 minecraft:light[level=15]
setblock 199 263 302 minecraft:light[level=15]
setblock 199 263 310 minecraft:light[level=15]
fill 201 263 290 201 266 290 minecraft:dark_prismarine
setblock 207 263 278 minecraft:light[level=15]
setblock 207 263 286 minecraft:light[level=15]
setblock 207 263 294 minecraft:light[level=15]
setblock 207 263 302 minecraft:light[level=15]
setblock 207 263 310 minecraft:light[level=15]
setblock 215 263 278 minecraft:light[level=15]
setblock 215 263 286 minecraft:light[level=15]
setblock 215 263 294 minecraft:light[level=15]
setblock 215 263 302 minecraft:light[level=15]
setblock 215 263 310 minecraft:light[level=15]
fill 216 263 275 216 297 275 minecraft:prismarine
setblock 223 263 278 minecraft:light[level=15]
setblock 223 263 286 minecraft:light[level=15]
setblock 223 263 294 minecraft:light[level=15]
setblock 223 263 302 minecraft:light[level=15]
setblock 223 263 310 minecraft:light[level=15]
fill 197 264 290 197 266 290 minecraft:dark_prismarine
fill 197 264 317 197 308 317 minecraft:prismarine
fill 198 264 288 200 266 288 minecraft:dark_prismarine
fill 198 264 292 200 266 292 minecraft:dark_prismarine
fill 201 264 289 201 266 289 minecraft:dark_prismarine
fill 201 264 291 201 266 291 minecraft:dark_prismarine
fill 210 264 308 212 265 308 minecraft:white_stained_glass
fill 211 264 307 211 265 307 minecraft:white_stained_glass
fill 211 264 309 211 265 309 minecraft:white_stained_glass
fill 188 265 275 190 308 275 minecraft:prismarine
setblock 188 265 279 minecraft:prismarine_bricks
fill 189 265 279 189 265 284 minecraft:dark_prismarine
fill 189 265 291 189 265 296 minecraft:dark_prismarine
fill 189 265 303 189 265 308 minecraft:dark_prismarine
fill 189 265 315 189 265 316 minecraft:dark_prismarine
fill 190 265 316 193 265 316 minecraft:dark_prismarine
setblock 191 265 275 minecraft:sea_lantern
fill 192 265 275 192 281 275 minecraft:prismarine
fill 193 265 276 198 265 276 minecraft:dark_prismarine
fill 196 265 280 196 269 280 minecraft:prismarine_bricks
setblock 196 265 317 minecraft:sea_lantern
fill 197 265 289 197 266 289 minecraft:dark_prismarine
fill 197 265 291 197 266 291 minecraft:dark_prismarine
fill 200 265 316 205 265 316 minecraft:dark_prismarine
fill 201 265 288 201 266 288 minecraft:dark_prismarine
fill 201 265 292 201 266 292 minecraft:dark_prismarine
fill 202 265 290 202 266 290 minecraft:dark_prismarine
fill 205 265 276 210 265 276 minecraft:dark_prismarine
fill 212 265 316 217 265 316 minecraft:dark_prismarine
fill 217 265 276 222 265 276 minecraft:dark_prismarine
fill 224 265 316 229 265 316 minecraft:dark_prismarine
fill 229 265 276 229 265 281 minecraft:dark_prismarine
fill 229 265 288 229 265 293 minecraft:dark_prismarine
fill 229 265 300 229 265 305 minecraft:dark_prismarine
fill 229 265 312 229 265 315 minecraft:dark_prismarine
setblock 230 265 312 minecraft:prismarine_bricks
fill 188 266 279 188 269 280 minecraft:prismarine
fill 188 266 281 188 266 285 minecraft:sea_lantern
fill 188 266 293 188 271 296 minecraft:sea_lantern
fill 188 266 305 188 271 308 minecraft:sea_lantern
fill 188 266 317 191 271 317 minecraft:sea_lantern
fill 191 266 275 191 267 275 minecraft:prismarine
fill 195 266 275 198 271 275 minecraft:sea_lantern
setblock 196 266 290 minecraft:dark_prismarine
fill 196 266 317 196 268 317 minecraft:prismarine
setblock 197 266 288 minecraft:dark_prismarine
setblock 197 266 292 minecraft:dark_prismarine
fill 198 266 287 200 266 287 minecraft:dark_prismarine
fill 198 266 293 200 266 293 minecraft:dark_prismarine
fill 200 266 317 203 271 317 minecraft:sea_lantern
setblock 202 266 289 minecraft:dark_prismarine
setblock 202 266 291 minecraft:dark_prismarine
fill 204 266 317 205 308 317 minecraft:prismarine
setblock 206 266 317 minecraft:prismarine_bricks
fill 207 266 275 210 271 275 minecraft:sea_lantern
fill 212 266 317 215 271 317 minecraft:sea_lantern
fill 219 266 275 222 271 275 minecraft:sea_lantern
fill 224 266 317 227 271 317 minecraft:sea_lantern
fill 230 266 276 230 271 279 minecraft:sea_lantern
fill 230 266 288 230 271 291 minecraft:sea_lantern
fill 230 266 300 230 271 303 minecraft:sea_lantern
fill 230 266 312 230 271 315 minecraft:sea_lantern
setblock 230 266 316 minecraft:prismarine_bricks
fill 188 267 281 188 271 284 minecraft:sea_lantern
fill 188 267 285 188 308 285 minecraft:prismarine
setblock 191 267 285 minecraft:light[level=12]
setblock 191 267 292 minecraft:light[level=12]
setblock 191 267 299 minecraft:light[level=12]
setblock 191 267 306 minecraft:light[level=12]
setblock 194 267 275 minecraft:prismarine_bricks
setblock 198 267 278 minecraft:light[level=12]
setblock 198 267 285 minecraft:light[level=12]
fill 198 267 289 198 271 289 minecraft:prismarine_bricks
setblock 198 267 292 minecraft:light[level=12]
setblock 198 267 299 minecraft:light[level=12]
setblock 198 267 306 minecraft:light[level=12]
setblock 198 267 313 minecraft:light[level=12]
fill 199 267 292 199 271 292 minecraft:prismarine_bricks
fill 201 267 289 201 268 289 minecraft:prismarine_bricks
setblock 205 267 278 minecraft:light[level=12]
setblock 205 267 285 minecraft:light[level=12]
setblock 205 267 292 minecraft:light[level=12]
setblock 205 267 299 minecraft:light[level=12]
setblock 205 267 306 minecraft:light[level=12]
setblock 205 267 313 minecraft:light[level=12]
fill 206 267 317 206 303 317 minecraft:prismarine
setblock 212 267 278 minecraft:light[level=12]
setblock 212 267 285 minecraft:light[level=12]
setblock 212 267 292 minecraft:light[level=12]
setblock 212 267 299 minecraft:light[level=12]
setblock 212 267 306 minecraft:light[level=12]
setblock 212 267 313 minecraft:light[level=12]
setblock 219 267 278 minecraft:light[level=12]
setblock 219 267 285 minecraft:light[level=12]
setblock 219 267 292 minecraft:light[level=12]
setblock 219 267 299 minecraft:light[level=12]
setblock 219 267 306 minecraft:light[level=12]
setblock 219 267 313 minecraft:light[level=12]
setblock 226 267 285 minecraft:light[level=12]
setblock 226 267 292 minecraft:light[level=12]
setblock 226 267 299 minecraft:light[level=12]
setblock 226 267 306 minecraft:light[level=12]
fill 230 267 316 230 308 316 minecraft:prismarine
setblock 191 268 275 minecraft:prismarine_bricks
fill 194 268 275 194 306 275 minecraft:prismarine
setblock 230 268 285 minecraft:prismarine_bricks
fill 191 269 275 191 308 275 minecraft:prismarine
fill 195 269 317 196 269 317 minecraft:sea_lantern
fill 200 269 290 200 271 290 minecraft:cyan_stained_glass
fill 200 269 291 200 272 291 minecraft:prismarine_bricks
fill 200 269 292 200 272 296 minecraft:cyan_stained_glass
fill 200 269 297 200 272 297 minecraft:prismarine_bricks
fill 200 269 298 200 271 298 minecraft:cyan_stained_glass
fill 201 269 288 201 271 289 minecraft:cyan_stained_glass
fill 201 269 299 201 271 300 minecraft:cyan_stained_glass
fill 202 269 287 202 272 287 minecraft:cyan_stained_glass
fill 202 269 301 202 272 301 minecraft:cyan_stained_glass
fill 203 269 286 203 272 286 minecraft:prismarine_bricks
fill 203 269 302 203 272 302 minecraft:prismarine_bricks
fill 204 269 285 204 272 285 minecraft:cyan_stained_glass
fill 204 269 303 204 272 303 minecraft:cyan_stained_glass
fill 205 269 284 206 271 284 minecraft:cyan_stained_glass
fill 205 269 304 206 271 304 minecraft:cyan_stained_glass
fill 207 269 283 207 271 283 minecraft:cyan_stained_glass
fill 207 269 305 207 271 305 minecraft:cyan_stained_glass
fill 208 269 283 208 272 283 minecraft:prismarine_bricks
fill 208 269 305 208 272 305 minecraft:prismarine_bricks
fill 209 269 283 213 272 283 minecraft:cyan_stained_glass
fill 209 269 305 213 272 305 minecraft:cyan_stained_glass
fill 214 269 283 214 272 283 minecraft:prismarine_bricks
fill 214 269 305 214 272 305 minecraft:prismarine_bricks
fill 215 269 283 215 271 283 minecraft:cyan_stained_glass
fill 215 269 305 215 271 305 minecraft:cyan_stained_glass
fill 216 269 284 217 271 284 minecraft:cyan_stained_glass
fill 216 269 304 217 271 304 minecraft:cyan_stained_glass
fill 218 269 285 218 272 285 minecraft:cyan_stained_glass
fill 218 269 303 218 272 303 minecraft:cyan_stained_glass
fill 219 269 286 219 272 286 minecraft:prismarine_bricks
fill 219 269 302 219 272 302 minecraft:prismarine_bricks
fill 220 269 287 220 272 287 minecraft:cyan_stained_glass
fill 220 269 301 220 272 301 minecraft:cyan_stained_glass
fill 221 269 288 221 271 289 minecraft:cyan_stained_glass
fill 221 269 299 221 271 300 minecraft:cyan_stained_glass
fill 222 269 290 222 271 290 minecraft:cyan_stained_glass
fill 222 269 291 222 272 291 minecraft:prismarine_bricks
fill 222 269 292 222 272 296 minecraft:cyan_stained_glass
fill 222 269 297 222 272 297 minecraft:prismarine_bricks
fill 222 269 298 222 271 298 minecraft:cyan_stained_glass
fill 230 269 285 230 308 285 minecraft:prismarine
setblock 188 270 279 minecraft:sea_lantern
fill 188 270 280 188 295 280 minecraft:prismarine
setblock 188 270 299 minecraft:sea_lantern
fill 195 270 317 196 308 317 minecraft:prismarine
setblock 196 270 280 minecraft:sea_lantern
fill 202 270 288 202 273 288 minecraft:cyan_stained_glass
fill 202 270 300 202 273 300 minecraft:cyan_stained_glass
fill 205 270 285 205 273 285 minecraft:cyan_stained_glass
fill 205 270 303 205 273 303 minecraft:cyan_stained_glass
fill 217 270 285 217 273 285 minecraft:cyan_stained_glass
fill 217 270 303 217 273 303 minecraft:cyan_stained_glass
fill 220 270 288 220 273 288 minecraft:cyan_stained_glass
fill 220 270 300 220 273 300 minecraft:cyan_stained_glass
fill 223 270 286 223 272 286 minecraft:iron_block
setblock 228 270 317 minecraft:prismarine_bricks
fill 229 270 317 229 306 317 minecraft:prismarine
fill 188 271 279 188 308 279 minecraft:prismarine
fill 188 271 299 188 306 299 minecraft:prismarine
setblock 191 271 286 minecraft:light[level=15]
setblock 191 271 294 minecraft:light[level=15]
setblock 191 271 302 minecraft:light[level=15]
setblock 191 271 310 minecraft:light[level=15]
setblock 199 271 278 minecraft:light[level=15]
setblock 199 271 286 minecraft:light[level=15]
setblock 199 271 294 minecraft:light[level=15]
setblock 199 271 302 minecraft:light[level=15]
setblock 199 271 310 minecraft:light[level=15]
fill 201 271 290 201 273 290 minecraft:cyan_stained_glass
fill 201 271 298 201 273 298 minecraft:cyan_stained_glass
fill 203 271 287 203 274 287 minecraft:cyan_stained_glass
fill 203 271 301 203 274 301 minecraft:cyan_stained_glass
fill 204 271 286 204 274 286 minecraft:cyan_stained_glass
fill 204 271 302 204 274 302 minecraft:cyan_stained_glass
fill 206 271 309 207 272 309 minecraft:white_stained_glass
setblock 207 271 278 minecraft:light[level=15]
fill 207 271 284 207 273 284 minecraft:cyan_stained_glass
setblock 207 271 286 minecraft:light[level=15]
setblock 207 271 294 minecraft:light[level=15]
setblock 207 271 302 minecraft:light[level=15]
fill 207 271 304 207 273 304 minecraft:cyan_stained_glass
fill 207 271 308 207 272 308 minecraft:white_stained_glass
setblock 207 271 310 minecraft:light[level=15]
setblock 215 271 278 minecraft:light[level=15]
fill 215 271 284 215 273 284 minecraft:cyan_stained_glass
setblock 215 271 286 minecraft:light[level=15]
setblock 215 271 294 minecraft:light[level=15]
setblock 215 271 302 minecraft:light[level=15]
fill 215 271 304 215 273 304 minecraft:cyan_stained_glass
setblock 215 271 310 minecraft:light[level=15]
fill 218 271 286 218 274 286 minecraft:cyan_stained_glass
fill 218 271 302 218 274 302 minecraft:cyan_stained_glass
fill 219 271 287 219 274 287 minecraft:cyan_stained_glass
fill 219 271 301 219 274 301 minecraft:cyan_stained_glass
fill 221 271 290 221 273 290 minecraft:cyan_stained_glass
fill 221 271 298 221 273 298 minecraft:cyan_stained_glass
setblock 223 271 278 minecraft:light[level=15]
setblock 223 271 294 minecraft:light[level=15]
setblock 223 271 302 minecraft:light[level=15]
setblock 223 271 310 minecraft:light[level=15]
fill 228 271 317 228 308 317 minecraft:prismarine
setblock 230 271 294 minecraft:sea_lantern
fill 188 272 281 188 285 281 minecraft:prismarine
fill 188 272 282 188 272 283 minecraft:sea_lantern
fill 188 272 284 188 284 284 minecraft:prismarine
fill 188 272 293 188 285 293 minecraft:prismarine
fill 188 272 294 188 272 295 minecraft:sea_lantern
fill 188 272 296 188 281 296 minecraft:prismarine
fill 188 272 305 188 285 305 minecraft:prismarine
fill 188 272 306 188 272 307 minecraft:sea_lantern
setblock 188 272 308 minecraft:prismarine
fill 188 272 317 188 285 317 minecraft:prismarine
fill 189 272 317 190 272 317 minecraft:sea_lantern
fill 191 272 317 191 285 317 minecraft:prismarine
fill 195 272 275 195 285 275 minecraft:prismarine
fill 196 272 275 197 272 275 minecraft:sea_lantern
fill 198 272 275 198 285 275 minecraft:prismarine
setblock 199 272 275 minecraft:prismarine_bricks
fill 200 272 317 200 285 317 minecraft:prismarine
setblock 201 272 289 minecraft:cyan_stained_glass
fill 201 272 291 201 274 291 minecraft:prismarine_bricks
fill 201 272 297 201 274 297 minecraft:prismarine_bricks
setblock 201 272 299 minecraft:cyan_stained_glass
fill 201 272 317 202 272 317 minecraft:sea_lantern
fill 203 272 317 203 285 317 minecraft:prismarine
setblock 206 272 284 minecraft:cyan_stained_glass
setblock 206 272 304 minecraft:cyan_stained_glass
fill 207 272 275 207 285 275 minecraft:prismarine
fill 208 272 275 209 272 275 minecraft:sea_lantern
fill 208 272 284 208 274 284 minecraft:prismarine_bricks
fill 208 272 304 208 274 304 minecraft:prismarine_bricks
fill 210 272 275 210 285 275 minecraft:prismarine
fill 212 272 317 212 285 317 minecraft:prismarine
fill 213 272 317 214 272 317 minecraft:sea_lantern
fill 214 272 284 214 274 284 minecraft:prismarine_bricks
fill 214 272 304 214 274 304 minecraft:prismarine_bricks
fill 215 272 317 215 285 317 minecraft:prismarine
setblock 216 272 284 minecraft:cyan_stained_glass
setblock 216 272 304 minecraft:cyan_stained_glass
setblock 218 272 275 minecraft:sea_lantern
setblock 218 272 317 minecraft:sea_lantern
fill 219 272 275 219 285 275 minecraft:prismarine
fill 220 272 275 221 272 275 minecraft:sea_lantern
setblock 221 272 289 minecraft:cyan_stained_glass
fill 221 272 291 221 274 291 minecraft:prismarine_bricks
fill 221 272 297 221 274 297 minecraft:prismarine_bricks
setblock 221 272 299 minecraft:cyan_stained_glass
fill 222 272 275 222 278 275 minecraft:prismarine
fill 224 272 317 224 285 317 minecraft:prismarine
fill 225 272 317 226 272 317 minecraft:sea_lantern
fill 227 272 317 227 285 317 minecraft:prismarine
fill 230 272 276 230 285 276 minecraft:prismarine
fill 230 272 277 230 272 278 minecraft:sea_lantern
fill 230 272 279 230 285 279 minecraft:prismarine
fill 230 272 288 230 285 288 minecraft:prismarine
fill 230 272 289 230 272 290 minecraft:sea_lantern
fill 230 272 291 230 285 291 minecraft:prismarine
fill 230 272 294 230 308 294 minecraft:prismarine
fill 230 272 300 230 284 300 minecraft:prismarine
fill 230 272 301 230 272 302 minecraft:sea_lantern
fill 230 272 303 230 285 303 minecraft:prismarine
fill 230 272 312 230 275 312 minecraft:prismarine
fill 230 272 313 230 272 314 minecraft:sea_lantern
fill 230 272 315 230 285 315 minecraft:prismarine
fill 188 273 282 188 285 283 minecraft:prismarine
fill 188 273 294 188 273 295 minecraft:prismarine
fill 188 273 306 188 285 307 minecraft:prismarine
setblock 188 273 308 minecraft:prismarine_bricks
fill 189 273 317 190 285 317 minecraft:prismarine
setblock 191 273 285 minecraft:light[level=12]
setblock 191 273 292 minecraft:light[level=12]
setblock 191 273 299 minecraft:light[level=12]
setblock 191 273 306 minecraft:light[level=12]
fill 196 273 275 197 285 275 minecraft:prismarine
setblock 198 273 278 minecraft:light[level=12]
setblock 198 273 285 minecraft:light[level=12]
setblock 198 273 292 minecraft:light[level=12]
setblock 198 273 299 minecraft:light[level=12]
setblock 198 273 306 minecraft:light[level=12]
setblock 198 273 313 minecraft:light[level=12]
setblock 199 273 275 minecraft:prismarine
fill 200 273 293 201 273 295 minecraft:cyan_stained_glass
fill 201 273 292 201 274 292 minecraft:cyan_stained_glass
fill 201 273 296 201 274 296 minecraft:cyan_stained_glass
fill 201 273 317 202 285 317 minecraft:prismarine
fill 202 273 289 202 274 289 minecraft:cyan_stained_glass
fill 202 273 299 202 274 299 minecraft:cyan_stained_glass
fill 203 273 288 203 275 288 minecraft:cyan_stained_glass
fill 203 273 300 203 275 300 minecraft:cyan_stained_glass
setblock 205 273 278 minecraft:light[level=12]
fill 205 273 286 205 275 286 minecraft:cyan_stained_glass
setblock 205 273 292 minecraft:light[level=12]
setblock 205 273 299 minecraft:light[level=12]
fill 205 273 302 205 275 302 minecraft:cyan_stained_glass
setblock 205 273 306 minecraft:light[level=12]
setblock 205 273 313 minecraft:light[level=12]
fill 206 273 285 206 274 285 minecraft:cyan_stained_glass
fill 206 273 303 206 274 303 minecraft:cyan_stained_glass
fill 208 273 275 209 285 275 minecraft:prismarine
fill 209 273 284 213 274 284 minecraft:cyan_stained_glass
fill 209 273 304 213 274 304 minecraft:cyan_stained_glass
fill 210 273 283 212 273 283 minecraft:cyan_stained_glass
fill 210 273 305 212 273 305 minecraft:cyan_stained_glass
setblock 212 273 278 minecraft:light[level=12]
setblock 212 273 285 minecraft:light[level=12]
setblock 212 273 292 minecraft:light[level=12]
setblock 212 273 299 minecraft:light[level=12]
setblock 212 273 306 minecraft:light[level=12]
setblock 212 273 313 minecraft:light[level=12]
setblock 213 273 317 minecraft:sea_lantern
fill 214 273 317 214 285 317 minecraft:prismarine
fill 216 273 285 216 274 285 minecraft:cyan_stained_glass
fill 216 273 303 216 274 303 minecraft:cyan_stained_glass
fill 217 273 286 217 275 286 minecraft:cyan_stained_glass
fill 217 273 302 217 275 302 minecraft:cyan_stained_glass
fill 218 273 275 218 283 275 minecraft:prismarine
fill 218 273 317 218 292 317 minecraft:prismarine
setblock 219 273 278 minecraft:light[level=12]
setblock 219 273 285 minecraft:light[level=12]
fill 219 273 288 219 275 288 minecraft:cyan_stained_glass
setblock 219 273 292 minecraft:light[level=12]
setblock 219 273 299 minecraft:light[level=12]
fill 219 273 300 219 275 300 minecraft:cyan_stained_glass
setblock 219 273 306 minecraft:light[level=12]
setblock 219 273 313 minecraft:light[level=12]
fill 220 273 275 221 282 275 minecraft:prismarine
fill 220 273 289 220 274 289 minecraft:cyan_stained_glass
fill 220 273 299 220 274 299 minecraft:cyan_stained_glass
fill 221 273 292 221 274 296 minecraft:cyan_stained_glass
fill 222 273 293 222 273 295 minecraft:cyan_stained_glass
fill 225 273 317 226 283 317 minecraft:prismarine
setblock 226 273 285 minecraft:light[level=12]
setblock 226 273 292 minecraft:light[level=12]
setblock 226 273 299 minecraft:light[level=12]
setblock 226 273 306 minecraft:light[level=12]
fill 230 273 277 230 285 278 minecraft:prismarine
fill 230 273 289 230 285 290 minecraft:prismarine
fill 230 273 301 230 285 302 minecraft:prismarine
fill 230 273 313 230 284 314 minecraft:prismarine
fill 188 274 294 188 285 294 minecraft:prismarine
setblock 188 274 295 minecraft:prismarine_bricks
fill 188 274 308 188 283 308 minecraft:prismarine
setblock 199 274 275 minecraft:prismarine_bricks
fill 201 274 293 201 275 295 minecraft:cyan_stained_glass
fill 202 274 290 202 275 291 minecraft:cyan_stained_glass
fill 202 274 297 202 275 298 minecraft:cyan_stained_glass
fill 203 274 289 203 275 289 minecraft:cyan_stained_glass
fill 203 274 299 203 275 299 minecraft:cyan_stained_glass
fill 204 274 287 204 275 287 minecraft:prismarine_bricks
fill 204 274 301 204 275 301 minecraft:prismarine_bricks
fill 206 274 286 206 275 286 minecraft:cyan_stained_glass
fill 206 274 302 206 275 302 minecraft:cyan_stained_glass
fill 207 274 285 208 275 285 minecraft:cyan_stained_glass
fill 207 274 303 208 275 303 minecraft:cyan_stained_glass
fill 213 274 317 213 285 317 minecraft:prismarine
fill 214 274 285 215 275 285 minecraft:cyan_stained_glass
fill 214 274 303 215 275 303 minecraft:cyan_stained_glass
fill 216 274 286 216 275 286 minecraft:cyan_stained_glass
fill 216 274 302 216 275 302 minecraft:cyan_stained_glass
fill 218 274 287 218 275 287 minecraft:prismarine_bricks
fill 218 274 301 218 275 301 minecraft:prismarine_bricks
fill 219 274 289 219 275 289 minecraft:cyan_stained_glass
fill 219 274 299 219 275 299 minecraft:cyan_stained_glass
fill 220 274 290 220 275 291 minecraft:cyan_stained_glass
fill 220 274 297 220 275 298 minecraft:cyan_stained_glass
fill 188 275 295 188 285 295 minecraft:prismarine
fill 199 275 275 199 308 275 minecraft:prismarine
fill 202 275 292 202 276 296 minecraft:cyan_stained_glass
fill 203 275 290 203 276 290 minecraft:cyan_stained_glass
fill 203 275 298 203 276 298 minecraft:cyan_stained_glass
fill 204 275 288 204 276 288 minecraft:cyan_stained_glass
fill 204 275 300 204 276 300 minecraft:cyan_stained_glass
fill 205 275 287 205 276 287 minecraft:cyan_stained_glass
fill 205 275 301 205 276 301 minecraft:cyan_stained_glass
fill 207 275 286 207 276 286 minecraft:cyan_stained_glass
fill 207 275 302 207 276 302 minecraft:cyan_stained_glass
fill 209 275 285 213 276 285 minecraft:cyan_stained_glass
fill 209 275 303 213 276 303 minecraft:cyan_stained_glass
fill 210 275 284 212 275 284 minecraft:cyan_stained_glass
fill 210 275 304 212 275 304 minecraft:cyan_stained_glass
fill 215 275 286 215 276 286 minecraft:cyan_stained_glass
fill 215 275 302 215 276 302 minecraft:cyan_stained_glass
fill 217 275 287 217 276 287 minecraft:cyan_stained_glass
fill 217 275 301 217 276 301 minecraft:cyan_stained_glass
fill 218 275 288 218 276 288 minecraft:cyan_stained_glass
fill 218 275 300 218 276 300 minecraft:cyan_stained_glass
fill 219 275 290 219 276 290 minecraft:cyan_stained_glass
fill 219 275 298 219 276 298 minecraft:cyan_stained_glass
fill 220 275 292 220 276 296 minecraft:cyan_stained_glass
fill 221 275 293 221 275 295 minecraft:cyan_stained_glass
setblock 203 276 291 minecraft:cyan_stained_glass
fill 203 276 292 203 277 292 minecraft:prismarine_bricks
fill 203 276 293 203 277 295 minecraft:cyan_stained_glass
fill 203 276 296 203 277 296 minecraft:prismarine_bricks
setblock 203 276 297 minecraft:cyan_stained_glass
fill 204 276 289 204 276 290 minecraft:cyan_stained_glass
fill 204 276 298 204 276 299 minecraft:cyan_stained_glass
setblock 205 276 288 minecraft:prismarine_bricks
setblock 205 276 300 minecraft:prismarine_bricks
fill 206 276 287 207 276 287 minecraft:cyan_stained_glass
fill 206 276 301 207 276 301 minecraft:cyan_stained_glass
setblock 208 276 286 minecraft:cyan_stained_glass
setblock 208 276 302 minecraft:cyan_stained_glass
fill 209 276 286 209 277 286 minecraft:prismarine_bricks
fill 209 276 302 209 277 302 minecraft:prismarine_bricks
fill 210 276 286 212 277 286 minecraft:cyan_stained_glass
fill 210 276 302 212 277 302 minecraft:cyan_stained_glass
fill 213 276 286 213 277 286 minecraft:prismarine_bricks
fill 213 276 302 213 277 302 minecraft:prismarine_bricks
setblock 214 276 286 minecraft:cyan_stained_glass
setblock 214 276 302 minecraft:cyan_stained_glass
fill 215 276 287 216 276 287 minecraft:cyan_stained_glass
fill 215 276 301 216 276 301 minecraft:cyan_stained_glass
setblock 217 276 288 minecraft:prismarine_bricks
setblock 217 276 300 minecraft:prismarine_bricks
fill 218 276 289 218 276 290 minecraft:cyan_stained_glass
fill 218 276 298 218 276 299 minecraft:cyan_stained_glass
setblock 219 276 291 minecraft:cyan_stained_glass
fill 219 276 292 219 277 292 minecraft:prismarine_bricks
fill 219 276 293 219 277 295 minecraft:cyan_stained_glass
fill 219 276 296 219 277 296 minecraft:prismarine_bricks
setblock 219 276 297 minecraft:cyan_stained_glass
setblock 230 276 312 minecraft:sea_lantern
setblock 188 277 304 minecraft:sea_lantern
fill 204 277 290 204 277 291 minecraft:cyan_stained_glass
fill 204 277 292 204 278 292 minecraft:prismarine_bricks
fill 204 277 293 204 279 295 minecraft:cyan_stained_glass
fill 204 277 296 204 278 296 minecraft:prismarine_bricks
fill 204 277 297 204 277 298 minecraft:cyan_stained_glass
fill 205 277 289 205 277 290 minecraft:cyan_stained_glass
fill 205 277 298 205 277 299 minecraft:cyan_stained_glass
fill 206 277 288 207 277 288 minecraft:cyan_stained_glass
fill 206 277 289 206 278 289 minecraft:prismarine_bricks
fill 206 277 299 206 278 299 minecraft:prismarine_bricks
fill 206 277 300 207 277 300 minecraft:cyan_stained_glass
fill 207 277 287 208 277 287 minecraft:cyan_stained_glass
fill 207 277 301 208 277 301 minecraft:cyan_stained_glass
fill 209 277 287 209 278 287 minecraft:prismarine_bricks
fill 209 277 301 209 278 301 minecraft:prismarine_bricks
fill 210 277 287 212 279 287 minecraft:cyan_stained_glass
fill 210 277 301 212 279 301 minecraft:cyan_stained_glass
fill 213 277 287 213 278 287 minecraft:prismarine_bricks
fill 213 277 301 213 278 301 minecraft:prismarine_bricks
fill 214 277 287 215 277 287 minecraft:cyan_stained_glass
fill 214 277 301 215 277 301 minecraft:cyan_stained_glass
fill 215 277 288 216 277 288 minecraft:cyan_stained_glass
fill 215 277 300 216 277 300 minecraft:cyan_stained_glass
fill 216 277 289 216 278 289 minecraft:prismarine_bricks
fill 216 277 299 216 278 299 minecraft:prismarine_bricks
fill 217 277 289 217 277 290 minecraft:cyan_stained_glass
fill 217 277 298 217 277 299 minecraft:cyan_stained_glass
fill 218 277 290 218 277 291 minecraft:cyan_stained_glass
fill 218 277 292 218 278 292 minecraft:prismarine_bricks
fill 218 277 293 218 279 295 minecraft:cyan_stained_glass
fill 218 277 296 218 278 296 minecraft:prismarine_bricks
fill 218 277 297 218 277 298 minecraft:cyan_stained_glass
fill 230 277 312 230 285 312 minecraft:prismarine
fill 188 278 304 188 308 304 minecraft:prismarine
fill 205 278 290 205 279 298 minecraft:cyan_stained_glass
fill 206 278 290 206 279 292 minecraft:cyan_stained_glass
fill 206 278 296 206 279 298 minecraft:cyan_stained_glass
fill 207 278 288 209 279 289 minecraft:cyan_stained_glass
setblock 207 278 290 minecraft:prismarine_bricks
setblock 207 278 298 minecraft:prismarine_bricks
fill 207 278 299 209 279 300 minecraft:cyan_stained_glass
fill 210 278 288 215 279 288 minecraft:cyan_stained_glass
fill 210 278 300 215 279 300 minecraft:cyan_stained_glass
fill 213 278 289 215 279 289 minecraft:cyan_stained_glass
fill 213 278 299 215 279 299 minecraft:cyan_stained_glass
setblock 215 278 290 minecraft:prismarine_bricks
setblock 215 278 298 minecraft:prismarine_bricks
fill 216 278 290 217 279 292 minecraft:cyan_stained_glass
fill 216 278 296 217 279 298 minecraft:cyan_stained_glass
fill 217 278 293 217 279 295 minecraft:cyan_stained_glass
fill 188 279 309 194 279 309 minecraft:prismarine_bricks
setblock 188 279 311 minecraft:sea_lantern
fill 189 279 276 189 279 308 minecraft:prismarine_bricks
fill 189 279 310 190 279 316 minecraft:prismarine_bricks
fill 190 279 276 190 279 294 minecraft:prismarine_bricks
fill 190 279 298 194 279 308 minecraft:prismarine_bricks
fill 191 279 276 194 279 277 minecraft:prismarine_bricks
fill 191 279 281 194 279 294 minecraft:prismarine_bricks
fill 191 279 310 194 279 311 minecraft:prismarine_bricks
fill 191 279 315 194 279 316 minecraft:prismarine_bricks
fill 193 279 295 194 279 297 minecraft:prismarine_bricks
fill 194 279 278 194 279 280 minecraft:prismarine_bricks
fill 194 279 312 194 279 314 minecraft:prismarine_bricks
fill 195 279 276 195 279 316 minecraft:sea_lantern
fill 196 279 276 201 279 316 minecraft:prismarine_bricks
fill 202 279 276 202 279 290 minecraft:sea_lantern
fill 202 279 291 203 279 297 minecraft:cyan_stained_glass
fill 202 279 298 202 279 316 minecraft:sea_lantern
fill 203 279 276 203 279 288 minecraft:prismarine_bricks
fill 203 279 289 204 279 290 minecraft:cyan_stained_glass
fill 203 279 298 204 279 299 minecraft:cyan_stained_glass
fill 203 279 300 203 279 316 minecraft:prismarine_bricks
fill 204 279 276 204 279 287 minecraft:prismarine_bricks
fill 204 279 288 206 279 288 minecraft:cyan_stained_glass
fill 204 279 291 204 279 292 minecraft:cyan_stained_glass
fill 204 279 296 204 279 297 minecraft:cyan_stained_glass
fill 204 279 300 206 279 300 minecraft:cyan_stained_glass
fill 204 279 301 204 279 316 minecraft:prismarine_bricks
fill 205 279 276 205 279 286 minecraft:prismarine_bricks
fill 205 279 287 209 279 287 minecraft:cyan_stained_glass
fill 205 279 289 206 279 289 minecraft:cyan_stained_glass
fill 205 279 299 206 279 299 minecraft:cyan_stained_glass
fill 205 279 301 209 279 301 minecraft:cyan_stained_glass
fill 205 279 302 205 279 316 minecraft:prismarine_bricks
fill 206 279 276 207 279 285 minecraft:prismarine_bricks
fill 206 279 286 216 279 286 minecraft:cyan_stained_glass
fill 206 279 293 206 279 295 minecraft:cyan_stained_glass
fill 206 279 302 216 279 302 minecraft:cyan_stained_glass
fill 206 279 303 207 279 316 minecraft:prismarine_bricks
fill 207 279 290 207 279 292 minecraft:cyan_stained_glass
fill 207 279 293 207 279 295 minecraft:sea_lantern
fill 207 279 296 207 279 298 minecraft:cyan_stained_glass
setblock 208 279 276 minecraft:prismarine_bricks
fill 208 279 280 208 279 284 minecraft:prismarine_bricks
fill 208 279 285 214 279 285 minecraft:cyan_stained_glass
fill 208 279 290 209 279 290 minecraft:cyan_stained_glass
fill 208 279 291 208 279 293 minecraft:sea_lantern
fill 208 279 295 208 279 297 minecraft:sea_lantern
fill 208 279 298 209 279 298 minecraft:cyan_stained_glass
fill 208 279 303 214 279 303 minecraft:cyan_stained_glass
fill 208 279 304 208 279 312 minecraft:prismarine_bricks
setblock 208 279 316 minecraft:prismarine_bricks
setblock 209 279 276 minecraft:sea_lantern
fill 209 279 280 209 279 284 minecraft:sea_lantern
fill 209 279 291 210 279 291 minecraft:sea_lantern
fill 209 279 297 210 279 297 minecraft:sea_lantern
fill 209 279 304 209 279 312 minecraft:sea_lantern
setblock 209 279 316 minecraft:sea_lantern
fill 210 279 276 215 279 276 minecraft:prismarine_bricks
fill 210 279 280 215 279 284 minecraft:prismarine_bricks
fill 210 279 289 212 279 289 minecraft:cyan_stained_glass
fill 210 279 290 212 279 290 minecraft:sea_lantern
fill 210 279 298 212 279 298 minecraft:sea_lantern
fill 210 279 299 212 279 299 minecraft:cyan_stained_glass
fill 210 279 304 215 279 312 minecraft:prismarine_bricks
fill 210 279 316 215 279 316 minecraft:prismarine_bricks
fill 211 279 277 215 279 279 minecraft:prismarine_bricks
fill 211 279 313 215 279 315 minecraft:prismarine_bricks
fill 212 279 291 214 279 291 minecraft:sea_lantern
fill 212 279 297 214 279 297 minecraft:sea_lantern
fill 213 279 287 217 279 287 minecraft:cyan_stained_glass
fill 213 279 290 215 279 290 minecraft:cyan_stained_glass
fill 213 279 298 215 279 298 minecraft:cyan_stained_glass
fill 213 279 301 217 279 301 minecraft:cyan_stained_glass
fill 214 279 292 214 279 293 minecraft:sea_lantern
fill 214 279 295 214 279 296 minecraft:sea_lantern
setblock 215 279 285 minecraft:prismarine_bricks
fill 215 279 291 215 279 292 minecraft:cyan_stained_glass
fill 215 279 293 215 279 295 minecraft:sea_lantern
fill 215 279 296 215 279 297 minecraft:cyan_stained_glass
setblock 215 279 303 minecraft:prismarine_bricks
fill 216 279 276 216 279 285 minecraft:sea_lantern
fill 216 279 288 218 279 289 minecraft:cyan_stained_glass
fill 216 279 293 216 279 295 minecraft:cyan_stained_glass
fill 216 279 299 218 279 300 minecraft:cyan_stained_glass
fill 216 279 303 216 279 316 minecraft:sea_lantern
fill 217 279 276 222 279 286 minecraft:prismarine_bricks
fill 217 279 302 222 279 316 minecraft:prismarine_bricks
fill 218 279 287 222 279 287 minecraft:prismarine_bricks
fill 218 279 290 219 279 292 minecraft:cyan_stained_glass
fill 218 279 296 219 279 298 minecraft:cyan_stained_glass
fill 218 279 301 222 279 301 minecraft:prismarine_bricks
fill 219 279 288 222 279 288 minecraft:prismarine_bricks
setblock 219 279 289 minecraft:cyan_stained_glass
fill 219 279 293 220 279 295 minecraft:cyan_stained_glass
setblock 219 279 299 minecraft:cyan_stained_glass
fill 219 279 300 222 279 300 minecraft:prismarine_bricks
fill 220 279 289 222 279 290 minecraft:prismarine_bricks
fill 220 279 291 220 279 292 minecraft:cyan_stained_glass
fill 220 279 296 220 279 297 minecraft:cyan_stained_glass
fill 220 279 298 222 279 299 minecraft:prismarine_bricks
fill 221 279 291 222 279 297 minecraft:prismarine_bricks
setblock 222 279 275 minecraft:sea_lantern
fill 223 279 276 223 279 316 minecraft:sea_lantern
fill 224 279 276 224 279 316 minecraft:prismarine_bricks
fill 225 279 276 229 279 277 minecraft:prismarine_bricks
fill 225 279 281 225 279 311 minecraft:prismarine_bricks
fill 225 279 315 229 279 316 minecraft:prismarine_bricks
fill 226 279 281 229 279 294 minecraft:prismarine_bricks
fill 226 279 298 229 279 311 minecraft:prismarine_bricks
fill 228 279 278 229 279 280 minecraft:prismarine_bricks
fill 228 279 312 229 279 314 minecraft:prismarine_bricks
fill 229 279 295 229 279 297 minecraft:prismarine_bricks
setblock 230 279 304 minecraft:sea_lantern
fill 188 280 309 188 308 309 minecraft:prismarine
fill 188 280 311 188 308 311 minecraft:prismarine
setblock 208 280 293 minecraft:cyan_stained_glass
setblock 208 280 295 minecraft:cyan_stained_glass
setblock 210 280 291 minecraft:cyan_stained_glass
setblock 210 280 297 minecraft:cyan_stained_glass
setblock 212 280 291 minecraft:cyan_stained_glass
setblock 212 280 297 minecraft:cyan_stained_glass
setblock 214 280 293 minecraft:cyan_stained_glass
setblock 214 280 295 minecraft:cyan_stained_glass
fill 222 280 275 222 285 275 minecraft:prismarine
fill 230 280 304 230 308 304 minecraft:prismarine
setblock 188 282 296 minecraft:prismarine_bricks
setblock 192 282 275 minecraft:sea_lantern
fill 188 283 296 188 285 296 minecraft:prismarine
fill 189 283 276 191 300 276 minecraft:prismarine_bricks
fill 189 283 286 189 300 288 minecraft:prismarine_bricks
fill 189 283 298 190 284 307 minecraft:prismarine_bricks
fill 189 283 310 189 300 312 minecraft:prismarine_bricks
fill 190 283 285 190 285 287 minecraft:prismarine_bricks
fill 190 283 309 190 285 311 minecraft:prismarine_bricks
fill 191 283 299 194 285 307 minecraft:prismarine_bricks
fill 192 283 275 192 308 275 minecraft:prismarine
fill 195 283 316 197 300 316 minecraft:prismarine_bricks
fill 196 283 315 198 285 315 minecraft:prismarine_bricks
fill 200 283 277 202 285 277 minecraft:prismarine_bricks
fill 201 283 276 203 300 276 minecraft:prismarine_bricks
fill 203 283 311 207 284 316 minecraft:prismarine_bricks
fill 207 283 308 213 285 310 minecraft:prismarine_bricks
fill 208 283 311 213 285 312 minecraft:prismarine_bricks
fill 208 283 316 213 284 316 minecraft:prismarine_bricks
fill 211 283 313 213 285 315 minecraft:prismarine_bricks
fill 212 283 277 214 285 277 minecraft:prismarine_bricks
fill 213 283 276 215 300 276 minecraft:prismarine_bricks
fill 217 283 276 224 284 282 minecraft:prismarine_bricks
fill 218 283 287 221 289 287 minecraft:dark_prismarine
fill 219 283 286 220 289 286 minecraft:dark_prismarine
fill 219 283 288 220 289 288 minecraft:dark_prismarine
fill 219 283 316 221 300 316 minecraft:prismarine_bricks
fill 220 283 275 220 285 275 minecraft:prismarine
fill 220 283 315 222 285 315 minecraft:prismarine_bricks
setblock 221 283 275 minecraft:sea_lantern
fill 221 283 291 225 300 303 minecraft:prismarine_bricks
fill 223 283 286 223 287 286 minecraft:iron_block
fill 224 283 310 224 283 313 minecraft:dark_prismarine
fill 225 283 276 226 285 277 minecraft:prismarine_bricks
fill 225 283 281 226 285 282 minecraft:prismarine_bricks
fill 225 283 283 226 283 283 minecraft:dark_prismarine
fill 225 283 309 227 283 309 minecraft:dark_prismarine
fill 225 283 310 228 285 311 minecraft:prismarine_bricks
fill 226 283 291 229 284 294 minecraft:prismarine_bricks
fill 226 283 298 229 284 303 minecraft:prismarine_bricks
fill 227 283 276 227 300 276 minecraft:prismarine_bricks
fill 227 283 281 227 300 281 minecraft:prismarine_bricks
setblock 227 283 282 minecraft:dark_prismarine
fill 228 283 280 228 283 281 minecraft:dark_prismarine
fill 228 283 285 228 285 287 minecraft:prismarine_bricks
fill 228 283 309 229 285 309 minecraft:prismarine_bricks
setblock 228 283 312 minecraft:dark_prismarine
fill 229 283 284 229 300 286 minecraft:prismarine_bricks
fill 229 283 295 229 300 297 minecraft:prismarine_bricks
fill 229 283 308 229 300 308 minecraft:prismarine_bricks
fill 229 283 310 229 300 310 minecraft:prismarine_bricks
setblock 230 283 286 minecraft:sea_lantern
setblock 188 284 308 minecraft:prismarine_bricks
fill 202 284 305 203 285 305 minecraft:light_blue_stained_glass
fill 213 284 307 214 285 307 minecraft:light_blue_stained_glass
setblock 218 284 275 minecraft:sea_lantern
fill 218 284 286 218 289 286 minecraft:dark_prismarine
fill 218 284 288 218 289 288 minecraft:dark_prismarine
fill 219 284 285 220 289 285 minecraft:dark_prismarine
fill 221 284 275 221 285 275 minecraft:prismarine
fill 221 284 286 221 289 286 minecraft:dark_prismarine
fill 221 284 288 221 289 288 minecraft:dark_prismarine
setblock 225 284 317 minecraft:prismarine_bricks
fill 226 284 317 226 285 317 minecraft:prismarine
fill 230 284 286 230 308 286 minecraft:prismarine
fill 188 285 284 188 291 284 minecraft:sea_lantern
setblock 188 285 308 minecraft:prismarine
fill 189 285 279 189 285 284 minecraft:dark_prismarine
fill 189 285 291 189 285 296 minecraft:dark_prismarine
fill 189 285 298 190 285 302 minecraft:prismarine_bricks
fill 189 285 303 189 285 308 minecraft:dark_prismarine
fill 189 285 315 189 285 316 minecraft:dark_prismarine
fill 190 285 303 190 285 307 minecraft:prismarine_bricks
fill 190 285 316 193 285 316 minecraft:dark_prismarine
setblock 191 285 285 minecraft:light[level=12]
setblock 191 285 292 minecraft:light[level=12]
fill 193 285 276 198 285 276 minecraft:dark_prismarine
setblock 198 285 278 minecraft:light[level=12]
setblock 198 285 285 minecraft:light[level=12]
setblock 198 285 292 minecraft:light[level=12]
setblock 198 285 299 minecraft:light[level=12]
setblock 198 285 306 minecraft:light[level=12]
setblock 198 285 313 minecraft:light[level=12]
fill 200 285 316 205 285 316 minecraft:dark_prismarine
fill 203 285 311 207 285 315 minecraft:prismarine_bricks
fill 205 285 276 210 285 276 minecraft:dark_prismarine
setblock 205 285 278 minecraft:light[level=12]
setblock 205 285 285 minecraft:light[level=12]
setblock 205 285 292 minecraft:light[level=12]
setblock 205 285 299 minecraft:light[level=12]
setblock 205 285 306 minecraft:light[level=12]
fill 206 285 316 211 285 316 minecraft:prismarine_bricks
setblock 212 285 278 minecraft:light[level=12]
setblock 212 285 285 minecraft:light[level=12]
setblock 212 285 292 minecraft:light[level=12]
setblock 212 285 299 minecraft:light[level=12]
setblock 212 285 306 minecraft:light[level=12]
fill 212 285 316 217 285 316 minecraft:dark_prismarine
fill 217 285 276 222 285 276 minecraft:dark_prismarine
fill 217 285 277 224 285 282 minecraft:prismarine_bricks
fill 217 285 287 217 289 287 minecraft:dark_prismarine
fill 218 285 275 218 308 275 minecraft:prismarine
fill 218 285 285 218 289 285 minecraft:dark_prismarine
fill 219 285 289 220 289 289 minecraft:dark_prismarine
setblock 219 285 292 minecraft:light[level=12]
setblock 219 285 299 minecraft:light[level=12]
setblock 219 285 306 minecraft:light[level=12]
setblock 219 285 313 minecraft:light[level=12]
fill 221 285 285 221 289 285 minecraft:dark_prismarine
fill 223 285 276 224 285 276 minecraft:prismarine_bricks
fill 224 285 316 229 285 316 minecraft:dark_prismarine
setblock 225 285 317 minecraft:prismarine
setblock 226 285 285 minecraft:light[level=12]
fill 226 285 291 228 300 294 minecraft:prismarine_bricks
fill 226 285 298 228 300 303 minecraft:prismarine_bricks
setblock 226 285 306 minecraft:light[level=12]
setblock 229 285 275 minecraft:prismarine_bricks
fill 229 285 276 229 285 281 minecraft:dark_prismarine
fill 229 285 288 229 285 293 minecraft:dark_prismarine
fill 229 285 294 229 300 294 minecraft:prismarine_bricks
fill 229 285 298 229 300 299 minecraft:prismarine_bricks
fill 229 285 300 229 285 305 minecraft:dark_prismarine
fill 229 285 312 229 285 315 minecraft:dark_prismarine
setblock 230 285 300 minecraft:prismarine_bricks
setblock 230 285 313 minecraft:prismarine
fill 230 285 314 230 292 314 minecraft:sea_lantern
fill 188 286 281 188 291 283 minecraft:sea_lantern
fill 188 286 293 188 291 296 minecraft:sea_lantern
fill 188 286 305 188 291 308 minecraft:sea_lantern
fill 188 286 317 191 291 317 minecraft:sea_lantern
fill 189 286 296 193 287 296 minecraft:prismarine_bricks
fill 189 286 298 189 300 299 minecraft:prismarine_bricks
setblock 189 286 300 minecraft:sea_lantern
fill 189 286 301 189 300 301 minecraft:prismarine_bricks
setblock 189 286 302 minecraft:sea_lantern
fill 189 286 303 189 300 303 minecraft:prismarine_bricks
setblock 189 286 304 minecraft:sea_lantern
fill 189 286 305 189 300 305 minecraft:prismarine_bricks
setblock 189 286 306 minecraft:sea_lantern
fill 189 286 307 189 300 307 minecraft:prismarine_bricks
fill 190 286 279 194 287 279 minecraft:prismarine_bricks
fill 190 286 295 192 287 295 minecraft:prismarine_bricks
fill 190 286 297 192 287 297 minecraft:prismarine_bricks
setblock 190 286 299 minecraft:sea_lantern
fill 190 286 300 190 300 300 minecraft:prismarine_bricks
setblock 190 286 301 minecraft:sea_lantern
fill 190 286 302 190 300 302 minecraft:prismarine_bricks
setblock 190 286 303 minecraft:sea_lantern
fill 190 286 304 190 300 304 minecraft:prismarine_bricks
setblock 190 286 305 minecraft:sea_lantern
fill 190 286 306 190 300 306 minecraft:prismarine_bricks
setblock 190 286 307 minecraft:sea_lantern
fill 190 286 313 194 287 313 minecraft:prismarine_bricks
fill 191 286 278 193 287 278 minecraft:prismarine_bricks
fill 191 286 280 193 287 280 minecraft:prismarine_bricks
fill 191 286 294 191 287 294 minecraft:prismarine_bricks
fill 191 286 298 191 287 299 minecraft:prismarine_bricks
setblock 191 286 300 minecraft:sea_lantern
fill 191 286 301 191 300 301 minecraft:prismarine_bricks
setblock 191 286 302 minecraft:sea_lantern
fill 191 286 303 191 300 303 minecraft:prismarine_bricks
setblock 191 286 304 minecraft:sea_lantern
fill 191 286 305 191 300 305 minecraft:prismarine_bricks
setblock 191 286 306 minecraft:sea_lantern
fill 191 286 307 191 300 307 minecraft:prismarine_bricks
fill 191 286 312 193 287 312 minecraft:prismarine_bricks
fill 191 286 314 193 287 314 minecraft:prismarine_bricks
fill 192 286 277 192 287 277 minecraft:prismarine_bricks
fill 192 286 281 192 287 281 minecraft:prismarine_bricks
setblock 192 286 299 minecraft:sea_lantern
fill 192 286 300 192 300 300 minecraft:prismarine_bricks
setblock 192 286 301 minecraft:sea_lantern
fill 192 286 302 192 300 302 minecraft:prismarine_bricks
setblock 192 286 303 minecraft:sea_lantern
fill 192 286 304 192 300 304 minecraft:prismarine_bricks
setblock 192 286 305 minecraft:sea_lantern
fill 192 286 306 192 300 306 minecraft:prismarine_bricks
setblock 192 286 307 minecraft:sea_lantern
fill 192 286 311 192 287 311 minecraft:prismarine_bricks
fill 192 286 315 192 287 315 minecraft:prismarine_bricks
fill 193 286 299 193 300 299 minecraft:prismarine_bricks
setblock 193 286 300 minecraft:sea_lantern
fill 193 286 301 193 300 301 minecraft:prismarine_bricks
setblock 193 286 302 minecraft:sea_lantern
fill 193 286 303 193 300 303 minecraft:prismarine_bricks
setblock 193 286 304 minecraft:sea_lantern
fill 193 286 305 193 300 305 minecraft:prismarine_bricks
setblock 193 286 306 minecraft:sea_lantern
fill 193 286 307 193 300 307 minecraft:prismarine_bricks
setblock 194 286 299 minecraft:sea_lantern
fill 194 286 300 194 300 300 minecraft:prismarine_bricks
setblock 194 286 301 minecraft:sea_lantern
fill 194 286 302 194 300 302 minecraft:prismarine_bricks
setblock 194 286 303 minecraft:sea_lantern
fill 194 286 304 194 300 304 minecraft:prismarine_bricks
setblock 194 286 305 minecraft:sea_lantern
fill 194 286 306 194 300 306 minecraft:prismarine_bricks
setblock 194 286 307 minecraft:sea_lantern
fill 195 286 275 198 291 275 minecraft:sea_lantern
fill 200 286 317 203 291 317 minecraft:sea_lantern
fill 203 286 311 203 300 311 minecraft:prismarine_bricks
setblock 203 286 312 minecraft:sea_lantern
fill 203 286 313 203 300 313 minecraft:prismarine_bricks
setblock 203 286 314 minecraft:sea_lantern
fill 203 286 315 203 300 315 minecraft:prismarine_bricks
setblock 203 286 316 minecraft:sea_lantern
setblock 204 286 275 minecraft:sea_lantern
setblock 204 286 311 minecraft:sea_lantern
fill 204 286 312 204 300 312 minecraft:prismarine_bricks
setblock 204 286 313 minecraft:sea_lantern
fill 204 286 314 204 300 314 minecraft:prismarine_bricks
setblock 204 286 315 minecraft:sea_lantern
fill 204 286 316 204 300 316 minecraft:prismarine_bricks
fill 205 286 311 205 300 311 minecraft:prismarine_bricks
setblock 205 286 312 minecraft:sea_lantern
fill 205 286 313 205 300 313 minecraft:prismarine_bricks
setblock 205 286 314 minecraft:sea_lantern
fill 205 286 315 205 300 315 minecraft:prismarine_bricks
setblock 205 286 316 minecraft:sea_lantern
setblock 206 286 311 minecraft:sea_lantern
fill 206 286 312 206 300 312 minecraft:prismarine_bricks
setblock 206 286 313 minecraft:sea_lantern
fill 206 286 314 206 300 314 minecraft:prismarine_bricks
setblock 206 286 315 minecraft:sea_lantern
fill 206 286 316 206 300 316 minecraft:prismarine_bricks
fill 207 286 275 210 291 275 minecraft:sea_lantern
fill 207 286 278 211 287 278 minecraft:prismarine_bricks
setblock 207 286 308 minecraft:sea_lantern
fill 207 286 309 207 300 309 minecraft:prismarine_bricks
setblock 207 286 310 minecraft:sea_lantern
fill 207 286 311 207 300 311 minecraft:prismarine_bricks
setblock 207 286 312 minecraft:sea_lantern
fill 207 286 313 207 300 313 minecraft:prismarine_bricks
setblock 207 286 314 minecraft:sea_lantern
fill 207 286 315 207 300 315 minecraft:prismarine_bricks
setblock 207 286 316 minecraft:sea_lantern
fill 208 286 277 210 287 277 minecraft:prismarine_bricks
fill 208 286 279 210 287 279 minecraft:prismarine_bricks
fill 208 286 308 208 300 308 minecraft:prismarine_bricks
setblock 208 286 309 minecraft:sea_lantern
fill 208 286 310 208 300 310 minecraft:prismarine_bricks
setblock 208 286 311 minecraft:sea_lantern
fill 208 286 312 208 300 312 minecraft:prismarine_bricks
setblock 208 286 313 minecraft:sea_lantern
fill 208 286 314 208 287 314 minecraft:prismarine_bricks
setblock 208 286 315 minecraft:sea_lantern
fill 208 286 316 208 300 316 minecraft:prismarine_bricks
fill 209 286 276 209 287 276 minecraft:prismarine_bricks
fill 209 286 280 209 287 280 minecraft:prismarine_bricks
setblock 209 286 308 minecraft:sea_lantern
fill 209 286 309 209 300 309 minecraft:prismarine_bricks
setblock 209 286 310 minecraft:sea_lantern
fill 209 286 311 209 300 311 minecraft:prismarine_bricks
setblock 209 286 312 minecraft:sea_lantern
fill 209 286 313 209 287 313 minecraft:prismarine_bricks
setblock 209 286 314 minecraft:sea_lantern
fill 209 286 315 209 287 315 minecraft:prismarine_bricks
setblock 209 286 316 minecraft:sea_lantern
fill 210 286 308 210 300 308 minecraft:prismarine_bricks
setblock 210 286 309 minecraft:sea_lantern
fill 210 286 310 210 300 310 minecraft:prismarine_bricks
setblock 210 286 311 minecraft:sea_lantern
fill 210 286 312 210 300 312 minecraft:prismarine_bricks
setblock 210 286 313 minecraft:sea_lantern
fill 210 286 314 210 287 314 minecraft:prismarine_bricks
setblock 210 286 315 minecraft:sea_lantern
fill 210 286 316 210 300 316 minecraft:prismarine_bricks
setblock 211 286 308 minecraft:sea_lantern
fill 211 286 309 211 300 309 minecraft:prismarine_bricks
setblock 211 286 310 minecraft:sea_lantern
fill 211 286 311 211 300 311 minecraft:prismarine_bricks
setblock 211 286 312 minecraft:sea_lantern
fill 211 286 313 211 300 313 minecraft:prismarine_bricks
setblock 211 286 314 minecraft:sea_lantern
fill 211 286 315 211 300 315 minecraft:prismarine_bricks
setblock 211 286 316 minecraft:sea_lantern
fill 212 286 308 212 300 308 minecraft:prismarine_bricks
setblock 212 286 309 minecraft:sea_lantern
fill 212 286 310 212 300 310 minecraft:prismarine_bricks
setblock 212 286 311 minecraft:sea_lantern
fill 212 286 312 212 300 312 minecraft:prismarine_bricks
setblock 212 286 313 minecraft:sea_lantern
fill 212 286 314 212 300 314 minecraft:prismarine_bricks
setblock 212 286 315 minecraft:sea_lantern
fill 212 286 316 212 300 316 minecraft:prismarine_bricks
fill 212 286 317 215 291 317 minecraft:sea_lantern
setblock 213 286 308 minecraft:sea_lantern
fill 213 286 309 213 300 309 minecraft:prismarine_bricks
setblock 213 286 310 minecraft:sea_lantern
fill 213 286 311 213 300 311 minecraft:prismarine_bricks
setblock 213 286 312 minecraft:sea_lantern
fill 213 286 313 213 300 313 minecraft:prismarine_bricks
setblock 213 286 314 minecraft:sea_lantern
fill 213 286 315 213 300 315 minecraft:prismarine_bricks
setblock 213 286 316 minecraft:sea_lantern
setblock 217 286 276 minecraft:sea_lantern
fill 217 286 277 217 300 277 minecraft:prismarine_bricks
setblock 217 286 278 minecraft:sea_lantern
fill 217 286 279 217 300 279 minecraft:prismarine_bricks
setblock 217 286 280 minecraft:sea_lantern
fill 217 286 281 217 300 281 minecraft:prismarine_bricks
setblock 217 286 282 minecraft:sea_lantern
fill 217 286 286 217 289 286 minecraft:dark_prismarine
fill 217 286 288 217 289 288 minecraft:dark_prismarine
fill 218 286 276 218 300 276 minecraft:prismarine_bricks
setblock 218 286 277 minecraft:sea_lantern
fill 218 286 278 218 300 278 minecraft:prismarine_bricks
setblock 218 286 279 minecraft:sea_lantern
fill 218 286 280 218 300 280 minecraft:prismarine_bricks
setblock 218 286 281 minecraft:sea_lantern
fill 218 286 282 218 300 282 minecraft:prismarine_bricks
fill 218 286 289 218 289 289 minecraft:dark_prismarine
fill 218 286 308 219 287 308 minecraft:white_stained_glass
fill 219 286 275 219 286 276 minecraft:sea_lantern
fill 219 286 277 219 300 277 minecraft:prismarine_bricks
setblock 219 286 278 minecraft:sea_lantern
fill 219 286 279 219 300 279 minecraft:prismarine_bricks
setblock 219 286 280 minecraft:sea_lantern
fill 219 286 281 219 300 281 minecraft:prismarine_bricks
setblock 219 286 282 minecraft:sea_lantern
fill 219 286 284 220 289 284 minecraft:dark_prismarine
fill 220 286 275 222 291 275 minecraft:sea_lantern
fill 220 286 276 220 300 276 minecraft:prismarine_bricks
setblock 220 286 277 minecraft:sea_lantern
fill 220 286 278 220 300 278 minecraft:prismarine_bricks
setblock 220 286 279 minecraft:sea_lantern
fill 220 286 280 220 300 280 minecraft:prismarine_bricks
setblock 220 286 281 minecraft:sea_lantern
fill 220 286 282 220 300 282 minecraft:prismarine_bricks
setblock 221 286 276 minecraft:sea_lantern
fill 221 286 277 221 300 277 minecraft:prismarine_bricks
setblock 221 286 278 minecraft:sea_lantern
fill 221 286 279 221 300 279 minecraft:prismarine_bricks
setblock 221 286 280 minecraft:sea_lantern
fill 221 286 281 221 300 281 minecraft:prismarine_bricks
setblock 221 286 282 minecraft:sea_lantern
fill 221 286 289 221 289 289 minecraft:dark_prismarine
fill 222 286 276 222 300 276 minecraft:prismarine_bricks
setblock 222 286 277 minecraft:sea_lantern
fill 222 286 278 222 300 278 minecraft:prismarine_bricks
setblock 222 286 279 minecraft:sea_lantern
fill 222 286 280 222 300 280 minecraft:prismarine_bricks
setblock 222 286 281 minecraft:sea_lantern
fill 222 286 282 222 300 282 minecraft:prismarine_bricks
fill 222 286 286 222 289 288 minecraft:dark_prismarine
setblock 223 286 276 minecraft:sea_lantern
fill 223 286 277 223 300 277 minecraft:prismarine_bricks
setblock 223 286 278 minecraft:sea_lantern
fill 223 286 279 223 300 279 minecraft:prismarine_bricks
setblock 223 286 280 minecraft:sea_lantern
fill 223 286 281 223 300 281 minecraft:prismarine_bricks
setblock 223 286 282 minecraft:sea_lantern
fill 224 286 276 224 300 276 minecraft:prismarine_bricks
setblock 224 286 277 minecraft:sea_lantern
fill 224 286 278 224 300 278 minecraft:prismarine_bricks
setblock 224 286 279 minecraft:sea_lantern
fill 224 286 280 224 300 280 minecraft:prismarine_bricks
setblock 224 286 281 minecraft:sea_lantern
fill 224 286 282 224 300 282 minecraft:prismarine_bricks
fill 224 286 313 228 287 313 minecraft:prismarine_bricks
fill 224 286 317 227 291 317 minecraft:sea_lantern
setblock 225 286 276 minecraft:sea_lantern
fill 225 286 277 226 287 277 minecraft:prismarine_bricks
setblock 225 286 278 minecraft:sea_lantern
fill 225 286 279 228 287 279 minecraft:prismarine_bricks
setblock 225 286 280 minecraft:sea_lantern
fill 225 286 281 226 300 281 minecraft:prismarine_bricks
setblock 225 286 282 minecraft:sea_lantern
fill 225 286 310 227 287 312 minecraft:prismarine_bricks
fill 225 286 314 227 287 314 minecraft:prismarine_bricks
fill 226 286 276 226 300 276 minecraft:prismarine_bricks
fill 226 286 278 227 287 278 minecraft:prismarine_bricks
fill 226 286 280 227 287 280 minecraft:prismarine_bricks
fill 226 286 282 226 300 282 minecraft:prismarine_bricks
fill 226 286 295 228 287 297 minecraft:prismarine_bricks
fill 226 286 315 226 287 315 minecraft:prismarine_bricks
fill 229 286 275 229 308 275 minecraft:prismarine
fill 229 286 291 229 300 293 minecraft:prismarine_bricks
fill 229 286 300 229 300 303 minecraft:prismarine_bricks
fill 229 286 309 229 300 309 minecraft:prismarine_bricks
fill 230 286 276 230 291 279 minecraft:sea_lantern
fill 230 286 288 230 291 291 minecraft:sea_lantern
setblock 230 286 297 minecraft:sea_lantern
fill 230 286 300 230 291 303 minecraft:sea_lantern
fill 230 286 312 230 291 313 minecraft:sea_lantern
fill 230 286 315 230 291 315 minecraft:sea_lantern
fill 189 287 300 189 288 300 minecraft:prismarine_bricks
fill 189 287 302 189 288 302 minecraft:prismarine_bricks
fill 189 287 304 189 288 304 minecraft:prismarine_bricks
fill 189 287 306 189 288 306 minecraft:prismarine_bricks
fill 190 287 299 190 288 299 minecraft:prismarine_bricks
fill 190 287 301 190 288 301 minecraft:prismarine_bricks
fill 190 287 303 190 288 303 minecraft:prismarine_bricks
fill 190 287 305 190 288 305 minecraft:prismarine_bricks
fill 190 287 307 190 288 307 minecraft:prismarine_bricks
setblock 191 287 286 minecraft:light[level=15]
fill 191 287 300 191 288 300 minecraft:prismarine_bricks
fill 191 287 302 191 288 302 minecraft:prismarine_bricks
fill 191 287 304 191 288 304 minecraft:prismarine_bricks
fill 191 287 306 191 288 306 minecraft:prismarine_bricks
setblock 191 287 310 minecraft:light[level=15]
fill 192 287 299 192 288 299 minecraft:prismarine_bricks
fill 192 287 301 192 288 301 minecraft:prismarine_bricks
fill 192 287 303 192 288 303 minecraft:prismarine_bricks
fill 192 287 305 192 288 305 minecraft:prismarine_bricks
fill 192 287 307 192 288 307 minecraft:prismarine_bricks
fill 193 287 300 193 288 300 minecraft:prismarine_bricks
fill 193 287 302 193 288 302 minecraft:prismarine_bricks
fill 193 287 304 193 288 304 minecraft:prismarine_bricks
fill 193 287 306 193 288 306 minecraft:prismarine_bricks
fill 194 287 299 194 288 299 minecraft:prismarine_bricks
fill 194 287 301 194 288 301 minecraft:prismarine_bricks
fill 194 287 303 194 288 303 minecraft:prismarine_bricks
fill 194 287 305 194 288 305 minecraft:prismarine_bricks
fill 194 287 307 194 288 307 minecraft:prismarine_bricks
setblock 199 287 278 minecraft:light[level=15]
setblock 199 287 286 minecraft:light[level=15]
setblock 199 287 294 minecraft:light[level=15]
setblock 199 287 302 minecraft:light[level=15]
setblock 199 287 310 minecraft:light[level=15]
fill 203 287 312 203 288 312 minecraft:prismarine_bricks
fill 203 287 314 203 288 314 minecraft:prismarine_bricks
fill 203 287 316 203 288 316 minecraft:prismarine_bricks
fill 204 287 275 204 308 275 minecraft:prismarine
fill 204 287 311 204 288 311 minecraft:prismarine_bricks
fill 204 287 313 204 288 313 minecraft:prismarine_bricks
fill 204 287 315 204 288 315 minecraft:prismarine_bricks
fill 205 287 312 205 288 312 minecraft:prismarine_bricks
fill 205 287 314 205 288 314 minecraft:prismarine_bricks
fill 205 287 316 205 288 316 minecraft:prismarine_bricks
fill 206 287 311 206 288 311 minecraft:prismarine_bricks
fill 206 287 313 206 288 313 minecraft:prismarine_bricks
fill 206 287 315 206 288 315 minecraft:prismarine_bricks
setblock 207 287 286 minecraft:light[level=15]
setblock 207 287 294 minecraft:light[level=15]
setblock 207 287 302 minecraft:light[level=15]
fill 207 287 308 207 288 308 minecraft:prismarine_bricks
fill 207 287 310 207 288 310 minecraft:prismarine_bricks
fill 207 287 312 207 288 312 minecraft:prismarine_bricks
fill 207 287 314 207 288 314 minecraft:prismarine_bricks
fill 207 287 316 207 288 316 minecraft:prismarine_bricks
fill 208 287 309 208 288 309 minecraft:prismarine_bricks
fill 208 287 311 208 288 311 minecraft:prismarine_bricks
setblock 208 287 313 minecraft:prismarine_bricks
setblock 208 287 315 minecraft:prismarine_bricks
fill 209 287 308 209 288 308 minecraft:prismarine_bricks
fill 209 287 310 209 288 310 minecraft:prismarine_bricks
fill 209 287 312 209 288 312 minecraft:prismarine_bricks
setblock 209 287 314 minecraft:prismarine_bricks
fill 209 287 316 209 288 316 minecraft:prismarine_bricks
fill 210 287 309 210 288 309 minecraft:prismarine_bricks
fill 210 287 311 210 288 311 minecraft:prismarine_bricks
setblock 210 287 313 minecraft:prismarine_bricks
setblock 210 287 315 minecraft:prismarine_bricks
fill 211 287 308 211 288 308 minecraft:prismarine_bricks
fill 211 287 310 211 288 310 minecraft:prismarine_bricks
fill 211 287 312 211 288 312 minecraft:prismarine_bricks
fill 211 287 314 211 288 314 minecraft:prismarine_bricks
fill 211 287 316 211 288 316 minecraft:prismarine_bricks
fill 212 287 309 212 288 309 minecraft:prismarine_bricks
fill 212 287 311 212 288 311 minecraft:prismarine_bricks
fill 212 287 313 212 288 313 minecraft:prismarine_bricks
fill 212 287 315 212 288 315 minecraft:prismarine_bricks
fill 213 287 308 213 288 308 minecraft:prismarine_bricks
fill 213 287 310 213 288 310 minecraft:prismarine_bricks
fill 213 287 312 213 288 312 minecraft:prismarine_bricks
fill 213 287 314 213 288 314 minecraft:prismarine_bricks
fill 213 287 316 213 288 316 minecraft:prismarine_bricks
setblock 215 287 278 minecraft:light[level=15]
setblock 215 287 286 minecraft:light[level=15]
setblock 215 287 294 minecraft:light[level=15]
setblock 215 287 302 minecraft:light[level=15]
setblock 215 287 310 minecraft:light[level=15]
fill 216 287 287 216 289 287 minecraft:dark_prismarine
fill 217 287 276 217 288 276 minecraft:prismarine_bricks
fill 217 287 278 217 288 278 minecraft:prismarine_bricks
fill 217 287 280 217 288 280 minecraft:prismarine_bricks
fill 217 287 282 217 288 282 minecraft:prismarine_bricks
fill 217 287 285 217 289 285 minecraft:dark_prismarine
fill 217 287 289 217 289 289 minecraft:dark_prismarine
fill 218 287 277 218 288 277 minecraft:prismarine_bricks
fill 218 287 279 218 288 279 minecraft:prismarine_bricks
fill 218 287 281 218 288 281 minecraft:prismarine_bricks
fill 218 287 284 218 289 284 minecraft:dark_prismarine
fill 219 287 275 219 291 275 minecraft:sea_lantern
fill 219 287 276 219 288 276 minecraft:prismarine_bricks
fill 219 287 278 219 288 278 minecraft:prismarine_bricks
fill 219 287 280 219 288 280 minecraft:prismarine_bricks
fill 219 287 282 219 288 282 minecraft:prismarine_bricks
fill 219 287 290 220 289 290 minecraft:dark_prismarine
fill 220 287 277 220 288 277 minecraft:prismarine_bricks
fill 220 287 279 220 288 279 minecraft:prismarine_bricks
fill 220 287 281 220 288 281 minecraft:prismarine_bricks
fill 221 287 276 221 288 276 minecraft:prismarine_bricks
fill 221 287 278 221 288 278 minecraft:prismarine_bricks
fill 221 287 280 221 288 280 minecraft:prismarine_bricks
fill 221 287 282 221 288 282 minecraft:prismarine_bricks
fill 221 287 284 221 289 284 minecraft:dark_prismarine
fill 222 287 277 222 288 277 minecraft:prismarine_bricks
fill 222 287 279 222 288 279 minecraft:prismarine_bricks
fill 222 287 281 222 288 281 minecraft:prismarine_bricks
fill 222 287 285 222 289 285 minecraft:dark_prismarine
fill 222 287 289 222 289 289 minecraft:dark_prismarine
fill 223 287 276 223 288 276 minecraft:prismarine_bricks
fill 223 287 278 223 288 278 minecraft:prismarine_bricks
fill 223 287 280 223 288 280 minecraft:prismarine_bricks
fill 223 287 282 223 288 282 minecraft:prismarine_bricks
setblock 223 287 310 minecraft:light[level=15]
fill 224 287 277 224 288 277 minecraft:prismarine_bricks
fill 224 287 279 224 288 279 minecraft:prismarine_bricks
fill 224 287 281 224 288 281 minecraft:prismarine_bricks
fill 225 287 276 225 288 276 minecraft:prismarine_bricks
setblock 225 287 278 minecraft:prismarine_bricks
setblock 225 287 280 minecraft:prismarine_bricks
fill 225 287 282 225 288 282 minecraft:prismarine_bricks
fill 230 287 281 230 308 281 minecraft:prismarine
setblock 230 287 282 minecraft:sea_lantern
fill 230 287 283 230 297 284 minecraft:prismarine
fill 230 287 297 230 308 297 minecraft:prismarine
setblock 188 288 303 minecraft:sea_lantern
fill 190 288 295 192 303 297 minecraft:quartz_pillar
schedule function dropper:buildpart/64_4 1t
