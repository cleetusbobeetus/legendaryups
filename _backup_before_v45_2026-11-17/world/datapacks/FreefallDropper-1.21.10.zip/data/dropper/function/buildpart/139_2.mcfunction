setblock 348 98 559 minecraft:oak_log
setblock 348 98 594 minecraft:oak_log
fill 348 98 595 348 101 595 minecraft:green_terracotta
setblock 349 98 558 minecraft:oak_log
fill 349 98 559 349 101 559 minecraft:green_terracotta
fill 349 98 594 349 100 594 minecraft:green_terracotta
setblock 349 98 598 minecraft:oak_log
fill 350 98 558 350 101 558 minecraft:green_terracotta
setblock 350 98 597 minecraft:oak_log
fill 350 98 598 350 101 598 minecraft:green_terracotta
fill 351 98 559 351 99 559 minecraft:green_terracotta
setblock 351 98 596 minecraft:oak_log
fill 351 98 597 351 101 597 minecraft:green_terracotta
setblock 352 98 595 minecraft:oak_log
fill 352 98 596 352 101 596 minecraft:green_terracotta
fill 353 98 595 353 99 595 minecraft:green_terracotta
setblock 354 98 558 minecraft:oak_log
setblock 354 98 598 minecraft:oak_log
setblock 355 98 597 minecraft:oak_log
fill 355 98 598 355 101 598 minecraft:green_terracotta
fill 356 98 597 356 101 597 minecraft:green_terracotta
fill 358 98 597 358 99 597 minecraft:green_terracotta
setblock 359 98 598 minecraft:oak_log
setblock 360 98 558 minecraft:oak_leaves[persistent=true]
fill 360 98 598 363 98 598 minecraft:green_terracotta
fill 362 98 597 364 98 597 minecraft:green_terracotta
setblock 364 98 598 minecraft:oak_log
fill 365 98 558 368 98 558 minecraft:green_terracotta
setblock 365 98 597 minecraft:oak_log
fill 365 98 598 365 101 598 minecraft:green_terracotta
setblock 366 98 596 minecraft:oak_log
fill 366 98 597 366 101 597 minecraft:green_terracotta
setblock 367 98 570 minecraft:oak_log
fill 367 98 571 367 101 571 minecraft:green_terracotta
setblock 367 98 575 minecraft:oak_log
fill 367 98 576 367 101 576 minecraft:green_terracotta
fill 367 98 578 367 98 579 minecraft:green_terracotta
fill 367 98 596 368 100 596 minecraft:green_terracotta
fill 368 98 567 368 99 567 minecraft:green_terracotta
setblock 368 98 569 minecraft:oak_log
fill 368 98 570 368 101 570 minecraft:green_terracotta
setblock 368 98 574 minecraft:oak_log
fill 368 98 575 368 101 575 minecraft:green_terracotta
setblock 368 98 578 minecraft:green_terracotta
setblock 368 98 579 minecraft:oak_log
fill 368 98 580 368 99 582 minecraft:green_terracotta
fill 368 98 592 368 98 593 minecraft:green_terracotta
setblock 368 98 594 minecraft:oak_log
fill 368 98 595 368 100 595 minecraft:green_terracotta
setblock 369 98 558 minecraft:oak_log
fill 369 98 559 369 101 559 minecraft:green_terracotta
fill 369 98 564 369 101 564 minecraft:green_terracotta
setblock 369 98 568 minecraft:oak_log
fill 369 98 569 369 101 569 minecraft:green_terracotta
setblock 369 98 573 minecraft:oak_log
fill 369 98 574 369 101 574 minecraft:green_terracotta
setblock 369 98 578 minecraft:oak_log
fill 369 98 579 369 101 579 minecraft:green_terracotta
setblock 369 98 582 minecraft:green_terracotta
setblock 369 98 583 minecraft:oak_log
fill 369 98 584 369 101 584 minecraft:green_terracotta
setblock 369 98 588 minecraft:oak_log
fill 369 98 589 369 100 589 minecraft:green_terracotta
setblock 369 98 593 minecraft:oak_log
fill 369 98 594 369 101 594 minecraft:green_terracotta
setblock 369 98 598 minecraft:oak_log
fill 370 98 558 370 101 558 minecraft:green_terracotta
setblock 370 98 562 minecraft:oak_log
fill 370 98 563 370 101 563 minecraft:green_terracotta
setblock 370 98 567 minecraft:oak_log
fill 370 98 568 370 101 568 minecraft:green_terracotta
setblock 370 98 572 minecraft:oak_log
fill 370 98 573 370 101 573 minecraft:green_terracotta
setblock 370 98 577 minecraft:oak_log
fill 370 98 578 370 101 578 minecraft:green_terracotta
setblock 370 98 582 minecraft:oak_log
fill 370 98 583 370 101 583 minecraft:green_terracotta
setblock 370 98 587 minecraft:oak_log
fill 370 98 588 370 101 588 minecraft:green_terracotta
setblock 370 98 592 minecraft:oak_log
fill 370 98 593 370 101 593 minecraft:green_terracotta
setblock 370 98 597 minecraft:oak_log
fill 370 98 598 370 101 598 minecraft:green_terracotta
setblock 330 99 560 minecraft:green_terracotta
setblock 330 99 561 minecraft:oak_log
fill 330 99 562 330 102 562 minecraft:green_terracotta
setblock 330 99 566 minecraft:oak_log
fill 330 99 567 330 102 567 minecraft:green_terracotta
setblock 330 99 571 minecraft:oak_log
fill 330 99 572 330 102 572 minecraft:green_terracotta
setblock 330 99 576 minecraft:oak_log
fill 330 99 577 330 102 577 minecraft:green_terracotta
setblock 330 99 581 minecraft:oak_log
fill 330 99 582 330 102 582 minecraft:green_terracotta
setblock 330 99 587 minecraft:green_terracotta
setblock 330 99 591 minecraft:oak_log
fill 330 99 592 330 102 592 minecraft:green_terracotta
setblock 330 99 596 minecraft:oak_log
fill 330 99 597 330 102 597 minecraft:green_terracotta
setblock 331 99 559 minecraft:green_terracotta
setblock 331 99 560 minecraft:oak_log
fill 331 99 561 331 102 561 minecraft:green_terracotta
setblock 331 99 565 minecraft:oak_log
fill 331 99 566 331 101 566 minecraft:green_terracotta
setblock 331 99 570 minecraft:oak_log
fill 331 99 571 331 102 571 minecraft:green_terracotta
setblock 331 99 575 minecraft:oak_log
fill 331 99 576 331 102 576 minecraft:green_terracotta
setblock 331 99 580 minecraft:oak_log
setblock 331 99 595 minecraft:oak_log
fill 331 99 596 332 99 596 minecraft:green_terracotta
setblock 332 99 559 minecraft:oak_log
setblock 332 99 569 minecraft:oak_log
fill 332 99 570 332 100 570 minecraft:green_terracotta
setblock 332 99 574 minecraft:oak_log
fill 332 99 575 332 100 575 minecraft:green_terracotta
setblock 333 99 558 minecraft:oak_log
fill 333 99 559 333 102 559 minecraft:green_terracotta
fill 333 99 574 333 100 574 minecraft:oak_leaves[persistent=true]
setblock 333 99 597 minecraft:green_terracotta
setblock 333 99 598 minecraft:oak_log
fill 334 99 558 334 102 558 minecraft:green_terracotta
setblock 334 99 597 minecraft:oak_log
fill 334 99 598 337 99 598 minecraft:green_terracotta
fill 335 99 597 338 99 597 minecraft:green_terracotta
setblock 336 99 559 minecraft:green_terracotta
setblock 337 99 558 minecraft:green_terracotta
setblock 338 99 558 minecraft:oak_log
setblock 338 99 598 minecraft:oak_log
fill 339 99 558 339 102 558 minecraft:green_terracotta
setblock 339 99 597 minecraft:oak_log
fill 339 99 598 339 102 598 minecraft:green_terracotta
fill 340 99 597 340 102 597 minecraft:green_terracotta
setblock 341 99 559 minecraft:green_terracotta
fill 341 99 596 341 102 596 minecraft:green_terracotta
setblock 342 99 558 minecraft:green_terracotta
setblock 342 99 559 minecraft:oak_log
setblock 343 99 558 minecraft:oak_log
fill 343 99 559 346 99 559 minecraft:green_terracotta
fill 343 99 595 345 99 595 minecraft:green_terracotta
setblock 343 99 598 minecraft:oak_log
fill 344 99 558 344 102 558 minecraft:green_terracotta
setblock 344 99 596 minecraft:green_terracotta
setblock 344 99 597 minecraft:oak_log
fill 344 99 598 344 102 598 minecraft:green_terracotta
setblock 345 99 596 minecraft:oak_log
fill 345 99 597 345 102 597 minecraft:green_terracotta
setblock 346 99 595 minecraft:oak_log
fill 346 99 596 346 102 596 minecraft:green_terracotta
setblock 347 99 559 minecraft:oak_log
setblock 347 99 594 minecraft:oak_log
fill 347 99 595 347 102 595 minecraft:green_terracotta
setblock 348 99 558 minecraft:oak_log
fill 348 99 559 348 102 559 minecraft:green_terracotta
fill 348 99 594 348 100 594 minecraft:green_terracotta
setblock 348 99 598 minecraft:oak_log
fill 349 99 558 349 102 558 minecraft:green_terracotta
setblock 349 99 597 minecraft:oak_log
fill 349 99 598 349 102 598 minecraft:green_terracotta
setblock 350 99 596 minecraft:oak_log
fill 350 99 597 350 102 597 minecraft:green_terracotta
setblock 351 99 595 minecraft:oak_log
fill 351 99 596 351 102 596 minecraft:green_terracotta
fill 352 99 595 352 100 595 minecraft:green_terracotta
setblock 353 99 558 minecraft:oak_log
setblock 353 99 598 minecraft:oak_log
fill 354 99 558 354 101 558 minecraft:green_terracotta
setblock 354 99 597 minecraft:oak_log
fill 354 99 598 354 102 598 minecraft:green_terracotta
setblock 355 99 596 minecraft:oak_log
fill 355 99 597 355 102 597 minecraft:green_terracotta
setblock 358 99 598 minecraft:oak_log
setblock 359 99 597 minecraft:oak_log
fill 359 99 598 362 99 598 minecraft:green_terracotta
fill 360 99 597 363 99 597 minecraft:green_terracotta
setblock 363 99 598 minecraft:oak_log
fill 364 99 558 367 99 558 minecraft:green_terracotta
setblock 364 99 597 minecraft:oak_log
fill 364 99 598 364 102 598 minecraft:green_terracotta
setblock 365 99 596 minecraft:oak_log
fill 365 99 597 365 102 597 minecraft:green_terracotta
setblock 366 99 574 minecraft:green_terracotta
setblock 366 99 575 minecraft:oak_log
fill 366 99 596 366 101 596 minecraft:green_terracotta
setblock 367 99 559 minecraft:oak_log
fill 367 99 570 367 100 570 minecraft:green_terracotta
setblock 367 99 573 minecraft:green_terracotta
setblock 367 99 574 minecraft:oak_log
fill 367 99 575 367 102 575 minecraft:green_terracotta
fill 367 99 577 367 99 578 minecraft:green_terracotta
setblock 367 99 579 minecraft:oak_log
fill 367 99 580 367 102 580 minecraft:green_terracotta
setblock 368 99 558 minecraft:oak_log
fill 368 99 559 368 102 559 minecraft:green_terracotta
setblock 368 99 568 minecraft:oak_log
fill 368 99 569 368 102 569 minecraft:green_terracotta
setblock 368 99 573 minecraft:oak_log
fill 368 99 574 368 102 574 minecraft:green_terracotta
setblock 368 99 577 minecraft:green_terracotta
setblock 368 99 578 minecraft:oak_log
fill 368 99 579 368 102 579 minecraft:green_terracotta
setblock 368 99 592 minecraft:green_terracotta
setblock 368 99 593 minecraft:oak_log
fill 368 99 594 368 100 594 minecraft:green_terracotta
setblock 368 99 597 minecraft:green_terracotta
setblock 368 99 598 minecraft:oak_log
fill 369 99 558 369 102 558 minecraft:green_terracotta
fill 369 99 560 369 99 561 minecraft:green_terracotta
setblock 369 99 562 minecraft:oak_log
fill 369 99 563 369 102 563 minecraft:green_terracotta
setblock 369 99 567 minecraft:oak_log
fill 369 99 568 369 102 568 minecraft:green_terracotta
setblock 369 99 572 minecraft:oak_log
fill 369 99 573 369 102 573 minecraft:green_terracotta
setblock 369 99 577 minecraft:oak_log
fill 369 99 578 369 102 578 minecraft:green_terracotta
setblock 369 99 582 minecraft:oak_log
fill 369 99 583 369 102 583 minecraft:green_terracotta
setblock 369 99 587 minecraft:oak_log
fill 369 99 588 369 100 588 minecraft:green_terracotta
setblock 369 99 592 minecraft:oak_log
fill 369 99 593 369 101 593 minecraft:green_terracotta
setblock 369 99 597 minecraft:oak_log
fill 369 99 598 369 102 598 minecraft:green_terracotta
setblock 370 99 560 minecraft:green_terracotta
setblock 370 99 561 minecraft:oak_log
fill 370 99 562 370 102 562 minecraft:green_terracotta
setblock 370 99 566 minecraft:oak_log
fill 370 99 567 370 102 567 minecraft:green_terracotta
setblock 370 99 571 minecraft:oak_log
fill 370 99 572 370 102 572 minecraft:green_terracotta
setblock 370 99 576 minecraft:oak_log
fill 370 99 577 370 102 577 minecraft:green_terracotta
setblock 370 99 581 minecraft:oak_log
fill 370 99 582 370 102 582 minecraft:green_terracotta
setblock 370 99 586 minecraft:oak_log
fill 370 99 587 370 101 587 minecraft:green_terracotta
setblock 370 99 591 minecraft:oak_log
fill 370 99 592 370 102 592 minecraft:green_terracotta
setblock 370 99 596 minecraft:oak_log
fill 370 99 597 370 102 597 minecraft:green_terracotta
setblock 330 100 560 minecraft:oak_log
fill 330 100 561 330 103 561 minecraft:green_terracotta
setblock 330 100 565 minecraft:oak_log
fill 330 100 566 330 103 566 minecraft:green_terracotta
setblock 330 100 570 minecraft:oak_log
fill 330 100 571 330 103 571 minecraft:green_terracotta
setblock 330 100 575 minecraft:oak_log
fill 330 100 576 330 103 576 minecraft:green_terracotta
setblock 330 100 580 minecraft:oak_log
fill 330 100 581 330 103 581 minecraft:green_terracotta
setblock 330 100 590 minecraft:oak_log
fill 330 100 591 330 101 591 minecraft:green_terracotta
setblock 330 100 595 minecraft:oak_log
fill 330 100 596 331 102 596 minecraft:green_terracotta
setblock 331 100 559 minecraft:oak_log
fill 331 100 560 331 103 560 minecraft:green_terracotta
setblock 331 100 564 minecraft:oak_log
fill 331 100 565 331 101 565 minecraft:green_terracotta
setblock 331 100 569 minecraft:oak_log
fill 331 100 570 331 102 570 minecraft:green_terracotta
setblock 331 100 574 minecraft:oak_log
fill 331 100 575 331 103 575 minecraft:green_terracotta
setblock 331 100 579 minecraft:oak_log
fill 331 100 580 331 101 580 minecraft:green_terracotta
setblock 331 100 594 minecraft:oak_log
fill 331 100 595 331 102 595 minecraft:green_terracotta
setblock 332 100 558 minecraft:oak_log
fill 332 100 559 332 103 559 minecraft:green_terracotta
setblock 332 100 573 minecraft:oak_log
setblock 332 100 574 minecraft:green_terracotta
setblock 332 100 598 minecraft:oak_log
fill 333 100 558 333 103 558 minecraft:green_terracotta
setblock 333 100 597 minecraft:oak_log
fill 333 100 598 336 100 598 minecraft:green_terracotta
fill 334 100 597 337 100 597 minecraft:green_terracotta
setblock 336 100 559 minecraft:oak_log
setblock 337 100 558 minecraft:oak_log
fill 337 100 559 340 100 559 minecraft:green_terracotta
setblock 337 100 598 minecraft:oak_log
fill 338 100 558 338 103 558 minecraft:green_terracotta
setblock 338 100 597 minecraft:oak_log
fill 338 100 598 338 103 598 minecraft:green_terracotta
fill 339 100 597 339 103 597 minecraft:green_terracotta
fill 340 100 596 340 103 596 minecraft:green_terracotta
setblock 341 100 559 minecraft:oak_log
setblock 342 100 558 minecraft:oak_log
fill 342 100 559 345 100 559 minecraft:green_terracotta
setblock 342 100 598 minecraft:oak_log
fill 343 100 558 343 103 558 minecraft:green_terracotta
fill 343 100 595 344 100 595 minecraft:green_terracotta
setblock 343 100 597 minecraft:oak_log
fill 343 100 598 343 103 598 minecraft:green_terracotta
setblock 344 100 596 minecraft:oak_log
fill 344 100 597 344 103 597 minecraft:green_terracotta
setblock 345 100 595 minecraft:oak_log
fill 345 100 596 345 103 596 minecraft:green_terracotta
setblock 346 100 559 minecraft:oak_log
fill 346 100 595 346 103 595 minecraft:green_terracotta
setblock 347 100 558 minecraft:oak_log
fill 347 100 559 347 103 559 minecraft:green_terracotta
setblock 347 100 594 minecraft:green_terracotta
setblock 347 100 598 minecraft:oak_log
fill 348 100 558 348 103 558 minecraft:green_terracotta
setblock 348 100 597 minecraft:oak_log
fill 348 100 598 348 103 598 minecraft:green_terracotta
setblock 349 100 596 minecraft:oak_log
fill 349 100 597 349 103 597 minecraft:green_terracotta
setblock 350 100 595 minecraft:oak_log
fill 350 100 596 350 103 596 minecraft:green_terracotta
setblock 351 100 559 minecraft:oak_log
fill 351 100 595 351 101 595 minecraft:green_terracotta
setblock 352 100 558 minecraft:oak_log
setblock 352 100 598 minecraft:oak_log
fill 353 100 558 353 103 558 minecraft:green_terracotta
setblock 353 100 597 minecraft:oak_log
fill 353 100 598 353 103 598 minecraft:green_terracotta
setblock 354 100 596 minecraft:oak_log
fill 354 100 597 354 103 597 minecraft:green_terracotta
setblock 355 100 596 minecraft:green_terracotta
setblock 357 100 598 minecraft:oak_log
setblock 358 100 597 minecraft:oak_log
fill 358 100 598 361 100 598 minecraft:green_terracotta
fill 359 100 597 362 100 597 minecraft:green_terracotta
setblock 362 100 558 minecraft:oak_log
setblock 362 100 598 minecraft:oak_log
fill 363 100 558 366 100 558 minecraft:green_terracotta
setblock 363 100 597 minecraft:oak_log
fill 363 100 598 363 103 598 minecraft:green_terracotta
fill 364 100 597 364 103 597 minecraft:green_terracotta
fill 365 100 596 365 101 596 minecraft:green_terracotta
setblock 366 100 559 minecraft:oak_log
setblock 366 100 574 minecraft:oak_log
fill 366 100 575 366 101 577 minecraft:green_terracotta
setblock 367 100 558 minecraft:oak_log
fill 367 100 559 367 103 559 minecraft:green_terracotta
setblock 367 100 573 minecraft:oak_log
fill 367 100 574 367 103 574 minecraft:green_terracotta
setblock 367 100 577 minecraft:green_terracotta
setblock 367 100 578 minecraft:oak_log
fill 367 100 579 367 103 579 minecraft:green_terracotta
setblock 367 100 598 minecraft:oak_log
fill 368 100 558 368 103 558 minecraft:green_terracotta
setblock 368 100 567 minecraft:oak_log
fill 368 100 568 368 101 568 minecraft:green_terracotta
setblock 368 100 572 minecraft:oak_log
fill 368 100 573 368 103 573 minecraft:green_terracotta
setblock 368 100 577 minecraft:oak_log
fill 368 100 578 368 103 578 minecraft:green_terracotta
fill 368 100 580 368 100 581 minecraft:green_terracotta
setblock 368 100 582 minecraft:oak_log
fill 368 100 583 368 101 583 minecraft:green_terracotta
setblock 368 100 593 minecraft:green_terracotta
setblock 368 100 597 minecraft:oak_log
fill 368 100 598 368 103 598 minecraft:green_terracotta
setblock 369 100 560 minecraft:green_terracotta
setblock 369 100 561 minecraft:oak_log
fill 369 100 562 369 103 562 minecraft:green_terracotta
setblock 369 100 566 minecraft:oak_log
fill 369 100 567 369 103 567 minecraft:green_terracotta
setblock 369 100 571 minecraft:oak_log
fill 369 100 572 369 103 572 minecraft:green_terracotta
setblock 369 100 576 minecraft:oak_log
fill 369 100 577 369 103 577 minecraft:green_terracotta
setblock 369 100 581 minecraft:oak_log
fill 369 100 582 369 103 582 minecraft:green_terracotta
setblock 369 100 586 minecraft:oak_log
setblock 369 100 591 minecraft:oak_log
fill 369 100 592 369 101 592 minecraft:green_terracotta
setblock 369 100 596 minecraft:oak_log
fill 369 100 597 369 103 597 minecraft:green_terracotta
setblock 370 100 560 minecraft:oak_log
fill 370 100 561 370 103 561 minecraft:green_terracotta
setblock 370 100 565 minecraft:oak_log
fill 370 100 566 370 103 566 minecraft:green_terracotta
setblock 370 100 570 minecraft:oak_log
fill 370 100 571 370 103 571 minecraft:green_terracotta
setblock 370 100 575 minecraft:oak_log
fill 370 100 576 370 103 576 minecraft:green_terracotta
setblock 370 100 580 minecraft:oak_log
fill 370 100 581 370 103 581 minecraft:green_terracotta
setblock 370 100 585 minecraft:oak_log
fill 370 100 586 370 102 586 minecraft:green_terracotta
setblock 370 100 590 minecraft:oak_log
fill 370 100 591 370 102 591 minecraft:green_terracotta
setblock 370 100 595 minecraft:oak_log
fill 370 100 596 370 103 596 minecraft:green_terracotta
setblock 330 101 559 minecraft:oak_log
fill 330 101 560 330 104 560 minecraft:green_terracotta
setblock 330 101 564 minecraft:oak_log
fill 330 101 565 330 104 565 minecraft:green_terracotta
setblock 330 101 569 minecraft:oak_log
fill 330 101 570 330 104 570 minecraft:green_terracotta
setblock 330 101 574 minecraft:oak_log
fill 330 101 575 330 104 575 minecraft:green_terracotta
setblock 330 101 579 minecraft:oak_log
fill 330 101 580 330 104 580 minecraft:green_terracotta
setblock 330 101 594 minecraft:oak_log
fill 330 101 595 330 104 595 minecraft:green_terracotta
setblock 331 101 558 minecraft:oak_log
fill 331 101 559 331 104 559 minecraft:green_terracotta
setblock 331 101 563 minecraft:oak_log
fill 331 101 564 331 102 564 minecraft:green_terracotta
setblock 331 101 568 minecraft:oak_log
fill 331 101 569 331 102 569 minecraft:green_terracotta
setblock 331 101 573 minecraft:oak_log
fill 331 101 574 331 103 574 minecraft:green_terracotta
setblock 331 101 578 minecraft:oak_log
fill 331 101 579 331 102 579 minecraft:green_terracotta
setblock 331 101 594 minecraft:green_terracotta
setblock 331 101 598 minecraft:oak_log
fill 332 101 558 332 104 558 minecraft:green_terracotta
setblock 332 101 597 minecraft:oak_log
fill 332 101 598 335 101 598 minecraft:green_terracotta
fill 333 101 597 336 101 597 minecraft:green_terracotta
setblock 334 101 559 minecraft:green_terracotta
setblock 335 101 559 minecraft:oak_log
setblock 336 101 558 minecraft:oak_log
fill 336 101 559 339 101 559 minecraft:green_terracotta
setblock 336 101 598 minecraft:oak_log
fill 337 101 558 337 104 558 minecraft:green_terracotta
setblock 337 101 597 minecraft:oak_log
fill 337 101 598 337 104 598 minecraft:green_terracotta
fill 338 101 597 338 104 597 minecraft:green_terracotta
setblock 340 101 559 minecraft:oak_log
setblock 341 101 558 minecraft:oak_log
fill 341 101 559 344 101 559 minecraft:green_terracotta
setblock 341 101 598 minecraft:oak_log
fill 342 101 558 342 104 558 minecraft:green_terracotta
setblock 342 101 597 minecraft:oak_log
fill 342 101 598 342 104 598 minecraft:green_terracotta
setblock 343 101 595 minecraft:green_terracotta
setblock 343 101 596 minecraft:oak_log
fill 343 101 597 343 104 597 minecraft:green_terracotta
setblock 344 101 595 minecraft:oak_log
fill 344 101 596 344 104 596 minecraft:green_terracotta
setblock 345 101 559 minecraft:oak_log
fill 345 101 595 345 103 595 minecraft:green_terracotta
setblock 346 101 558 minecraft:oak_log
fill 346 101 559 346 104 559 minecraft:green_terracotta
setblock 346 101 598 minecraft:oak_log
fill 347 101 558 347 104 558 minecraft:green_terracotta
setblock 347 101 597 minecraft:oak_log
fill 347 101 598 347 104 598 minecraft:green_terracotta
setblock 348 101 596 minecraft:oak_log
fill 348 101 597 348 104 597 minecraft:green_terracotta
setblock 349 101 595 minecraft:oak_log
fill 349 101 596 349 104 596 minecraft:green_terracotta
setblock 350 101 559 minecraft:oak_log
fill 350 101 595 350 102 595 minecraft:green_terracotta
setblock 351 101 558 minecraft:oak_log
setblock 351 101 559 minecraft:green_terracotta
setblock 351 101 598 minecraft:oak_log
fill 352 101 558 352 104 558 minecraft:green_terracotta
setblock 352 101 597 minecraft:oak_log
fill 352 101 598 352 104 598 minecraft:green_terracotta
setblock 353 101 596 minecraft:oak_log
fill 353 101 597 353 103 597 minecraft:green_terracotta
setblock 354 101 596 minecraft:green_terracotta
setblock 356 101 598 minecraft:oak_log
setblock 357 101 597 minecraft:oak_log
fill 357 101 598 360 101 598 minecraft:green_terracotta
fill 358 101 597 361 101 597 minecraft:green_terracotta
setblock 361 101 558 minecraft:oak_log
setblock 361 101 598 minecraft:oak_log
fill 362 101 558 365 101 558 minecraft:green_terracotta
setblock 362 101 597 minecraft:oak_log
fill 362 101 598 362 104 598 minecraft:green_terracotta
fill 363 101 597 363 104 597 minecraft:green_terracotta
setblock 365 101 559 minecraft:oak_log
fill 365 101 572 366 102 573 minecraft:oak_leaves[persistent=true]
setblock 366 101 558 minecraft:oak_log
fill 366 101 559 366 104 559 minecraft:green_terracotta
setblock 366 101 574 minecraft:green_terracotta
setblock 366 101 578 minecraft:oak_log
setblock 366 101 598 minecraft:oak_log
fill 367 101 558 367 104 558 minecraft:green_terracotta
setblock 367 101 572 minecraft:oak_log
fill 367 101 573 367 103 573 minecraft:green_terracotta
setblock 367 101 577 minecraft:oak_log
fill 367 101 578 367 104 578 minecraft:green_terracotta
setblock 367 101 581 minecraft:green_terracotta
setblock 367 101 596 minecraft:green_terracotta
setblock 367 101 597 minecraft:oak_log
fill 367 101 598 367 104 598 minecraft:green_terracotta
setblock 368 101 571 minecraft:oak_log
fill 368 101 572 368 104 572 minecraft:green_terracotta
setblock 368 101 576 minecraft:oak_log
fill 368 101 577 368 104 577 minecraft:green_terracotta
setblock 368 101 580 minecraft:green_terracotta
setblock 368 101 581 minecraft:oak_log
fill 368 101 582 368 103 582 minecraft:green_terracotta
setblock 368 101 596 minecraft:oak_log
fill 368 101 597 368 103 597 minecraft:green_terracotta
setblock 369 101 560 minecraft:oak_log
fill 369 101 561 369 104 561 minecraft:green_terracotta
setblock 369 101 565 minecraft:oak_log
fill 369 101 566 369 103 566 minecraft:green_terracotta
setblock 369 101 570 minecraft:oak_log
fill 369 101 571 369 104 571 minecraft:green_terracotta
setblock 369 101 575 minecraft:oak_log
fill 369 101 576 369 104 576 minecraft:green_terracotta
setblock 369 101 580 minecraft:oak_log
fill 369 101 581 369 104 581 minecraft:green_terracotta
setblock 369 101 585 minecraft:oak_log
setblock 369 101 595 minecraft:oak_log
fill 369 101 596 369 103 596 minecraft:green_terracotta
setblock 370 101 559 minecraft:oak_log
fill 370 101 560 370 104 560 minecraft:green_terracotta
setblock 370 101 564 minecraft:oak_log
fill 370 101 565 370 104 565 minecraft:green_terracotta
setblock 370 101 569 minecraft:oak_log
fill 370 101 570 370 104 570 minecraft:green_terracotta
setblock 370 101 574 minecraft:oak_log
fill 370 101 575 370 104 575 minecraft:green_terracotta
setblock 370 101 579 minecraft:oak_log
fill 370 101 580 370 104 580 minecraft:green_terracotta
setblock 370 101 584 minecraft:oak_log
fill 370 101 585 370 103 585 minecraft:green_terracotta
setblock 370 101 589 minecraft:oak_log
setblock 370 101 590 minecraft:green_terracotta
setblock 370 101 594 minecraft:oak_log
fill 370 101 595 370 103 595 minecraft:green_terracotta
setblock 330 102 558 minecraft:oak_log
fill 330 102 559 330 105 559 minecraft:green_terracotta
setblock 330 102 563 minecraft:oak_log
fill 330 102 564 330 105 564 minecraft:green_terracotta
setblock 330 102 568 minecraft:oak_log
fill 330 102 569 330 104 569 minecraft:green_terracotta
setblock 330 102 573 minecraft:oak_log
fill 330 102 574 330 105 574 minecraft:green_terracotta
setblock 330 102 578 minecraft:oak_log
fill 330 102 579 330 105 579 minecraft:green_terracotta
setblock 330 102 583 minecraft:oak_log
setblock 330 102 588 minecraft:oak_leaves[persistent=true]
setblock 330 102 593 minecraft:oak_log
fill 330 102 594 330 103 594 minecraft:green_terracotta
setblock 330 102 598 minecraft:oak_log
fill 331 102 558 331 105 558 minecraft:green_terracotta
setblock 331 102 562 minecraft:oak_log
fill 331 102 563 331 103 563 minecraft:green_terracotta
setblock 331 102 572 minecraft:oak_log
fill 331 102 573 331 103 573 minecraft:green_terracotta
setblock 331 102 577 minecraft:oak_log
fill 331 102 578 331 103 578 minecraft:green_terracotta
setblock 331 102 597 minecraft:oak_log
fill 331 102 598 334 102 598 minecraft:green_terracotta
fill 332 102 597 335 102 597 minecraft:green_terracotta
setblock 334 102 559 minecraft:oak_log
setblock 335 102 558 minecraft:oak_log
fill 335 102 559 338 102 559 minecraft:green_terracotta
setblock 335 102 598 minecraft:oak_log
fill 336 102 558 336 105 558 minecraft:green_terracotta
setblock 336 102 597 minecraft:oak_log
fill 336 102 598 336 105 598 minecraft:green_terracotta
fill 337 102 597 337 104 597 minecraft:green_terracotta
setblock 339 102 559 minecraft:oak_log
setblock 340 102 558 minecraft:oak_log
fill 340 102 559 343 102 559 minecraft:green_terracotta
setblock 340 102 598 minecraft:oak_log
fill 341 102 558 341 105 558 minecraft:green_terracotta
setblock 341 102 597 minecraft:oak_log
fill 341 102 598 341 105 598 minecraft:green_terracotta
setblock 342 102 596 minecraft:oak_log
fill 342 102 597 342 105 597 minecraft:green_terracotta
setblock 343 102 595 minecraft:oak_log
fill 343 102 596 343 105 596 minecraft:green_terracotta
setblock 344 102 559 minecraft:oak_log
fill 344 102 595 344 103 595 minecraft:green_terracotta
setblock 345 102 558 minecraft:oak_log
fill 345 102 559 345 102 560 minecraft:green_terracotta
setblock 345 102 598 minecraft:oak_log
fill 346 102 558 346 105 558 minecraft:green_terracotta
setblock 346 102 597 minecraft:oak_log
fill 346 102 598 346 105 598 minecraft:green_terracotta
setblock 347 102 596 minecraft:oak_log
fill 347 102 597 347 105 597 minecraft:green_terracotta
setblock 348 102 595 minecraft:oak_log
fill 348 102 596 348 105 596 minecraft:green_terracotta
setblock 349 102 559 minecraft:oak_log
setblock 349 102 595 minecraft:green_terracotta
setblock 350 102 558 minecraft:oak_log
setblock 350 102 559 minecraft:green_terracotta
setblock 350 102 598 minecraft:oak_log
fill 351 102 558 351 105 558 minecraft:green_terracotta
setblock 351 102 597 minecraft:oak_log
fill 351 102 598 351 105 598 minecraft:green_terracotta
setblock 352 102 596 minecraft:oak_log
fill 352 102 597 352 104 597 minecraft:green_terracotta
setblock 355 102 598 minecraft:oak_log
fill 356 102 598 359 102 598 minecraft:green_terracotta
setblock 360 102 598 minecraft:oak_log
fill 361 102 558 364 102 558 minecraft:green_terracotta
setblock 361 102 597 minecraft:oak_log
fill 361 102 598 361 105 598 minecraft:green_terracotta
fill 362 102 597 362 103 597 minecraft:green_terracotta
setblock 364 102 559 minecraft:oak_log
setblock 365 102 558 minecraft:oak_log
fill 365 102 559 365 105 559 minecraft:green_terracotta
setblock 365 102 598 minecraft:oak_log
fill 366 102 558 366 105 558 minecraft:green_terracotta
fill 366 102 575 366 102 576 minecraft:green_terracotta
setblock 366 102 577 minecraft:oak_log
setblock 366 102 578 minecraft:green_terracotta
setblock 366 102 597 minecraft:oak_log
fill 366 102 598 366 105 598 minecraft:green_terracotta
setblock 367 102 572 minecraft:green_terracotta
setblock 367 102 576 minecraft:oak_log
fill 367 102 577 367 105 577 minecraft:green_terracotta
fill 367 102 597 367 104 597 minecraft:green_terracotta
setblock 368 102 570 minecraft:oak_log
fill 368 102 571 368 103 571 minecraft:green_terracotta
setblock 368 102 575 minecraft:oak_log
fill 368 102 576 368 105 576 minecraft:green_terracotta
setblock 368 102 580 minecraft:oak_log
fill 368 102 581 368 105 581 minecraft:green_terracotta
setblock 369 102 559 minecraft:oak_log
fill 369 102 560 369 105 560 minecraft:green_terracotta
setblock 369 102 564 minecraft:oak_log
fill 369 102 565 369 103 565 minecraft:green_terracotta
setblock 369 102 569 minecraft:oak_log
fill 369 102 570 369 104 570 minecraft:green_terracotta
setblock 369 102 574 minecraft:oak_log
fill 369 102 575 369 105 575 minecraft:green_terracotta
setblock 369 102 579 minecraft:oak_log
fill 369 102 580 369 105 580 minecraft:green_terracotta
setblock 369 102 584 minecraft:oak_log
setblock 369 102 594 minecraft:oak_log
setblock 369 102 595 minecraft:green_terracotta
setblock 370 102 558 minecraft:oak_log
fill 370 102 559 370 105 559 minecraft:green_terracotta
setblock 370 102 563 minecraft:oak_log
fill 370 102 564 370 105 564 minecraft:green_terracotta
setblock 370 102 568 minecraft:oak_log
fill 370 102 569 370 105 569 minecraft:green_terracotta
setblock 370 102 573 minecraft:oak_log
fill 370 102 574 370 105 574 minecraft:green_terracotta
setblock 370 102 578 minecraft:oak_log
fill 370 102 579 370 105 579 minecraft:green_terracotta
setblock 370 102 583 minecraft:oak_log
fill 370 102 584 370 104 584 minecraft:green_terracotta
setblock 370 102 593 minecraft:oak_log
fill 370 102 594 370 103 594 minecraft:green_terracotta
setblock 370 102 598 minecraft:oak_log
fill 330 103 558 330 106 558 minecraft:green_terracotta
setblock 330 103 562 minecraft:oak_log
fill 330 103 563 330 106 563 minecraft:green_terracotta
setblock 330 103 567 minecraft:oak_log
fill 330 103 568 330 104 568 minecraft:green_terracotta
setblock 330 103 572 minecraft:oak_log
fill 330 103 573 330 105 573 minecraft:green_terracotta
setblock 330 103 577 minecraft:oak_log
fill 330 103 578 330 106 578 minecraft:green_terracotta
setblock 330 103 582 minecraft:oak_log
setblock 330 103 596 minecraft:green_terracotta
setblock 330 103 597 minecraft:oak_log
fill 330 103 598 333 103 598 minecraft:green_terracotta
setblock 331 103 561 minecraft:oak_log
fill 331 103 562 331 104 562 minecraft:green_terracotta
setblock 331 103 576 minecraft:oak_log
setblock 331 103 577 minecraft:green_terracotta
setblock 331 103 596 minecraft:oak_log
fill 331 103 597 333 103 597 minecraft:green_terracotta
setblock 333 103 559 minecraft:oak_log
setblock 334 103 558 minecraft:oak_log
fill 334 103 559 337 103 559 minecraft:green_terracotta
setblock 334 103 598 minecraft:oak_log
fill 335 103 558 335 106 558 minecraft:green_terracotta
fill 335 103 585 335 115 585 minecraft:oak_leaves[persistent=true]
fill 335 103 598 335 106 598 minecraft:green_terracotta
setblock 336 103 597 minecraft:green_terracotta
setblock 338 103 559 minecraft:oak_log
setblock 339 103 558 minecraft:oak_log
fill 339 103 559 342 103 559 minecraft:green_terracotta
setblock 339 103 598 minecraft:oak_log
fill 340 103 558 340 106 558 minecraft:green_terracotta
setblock 340 103 597 minecraft:oak_log
fill 340 103 598 340 106 598 minecraft:green_terracotta
setblock 341 103 596 minecraft:oak_log
fill 341 103 597 341 106 597 minecraft:green_terracotta
fill 342 103 596 342 106 596 minecraft:green_terracotta
setblock 343 103 559 minecraft:oak_log
setblock 344 103 558 minecraft:oak_log
fill 344 103 559 345 105 559 minecraft:green_terracotta
setblock 344 103 598 minecraft:oak_log
fill 345 103 558 345 106 558 minecraft:green_terracotta
setblock 345 103 597 minecraft:oak_log
fill 345 103 598 345 106 598 minecraft:green_terracotta
setblock 346 103 596 minecraft:oak_log
fill 346 103 597 346 106 597 minecraft:green_terracotta
setblock 347 103 595 minecraft:oak_log
fill 347 103 596 347 105 596 minecraft:green_terracotta
setblock 348 103 559 minecraft:oak_log
setblock 348 103 595 minecraft:green_terracotta
setblock 349 103 558 minecraft:oak_log
fill 349 103 559 349 104 559 minecraft:green_terracotta
setblock 349 103 598 minecraft:oak_log
fill 350 103 558 350 106 558 minecraft:green_terracotta
setblock 350 103 597 minecraft:oak_log
fill 350 103 598 350 106 598 minecraft:green_terracotta
setblock 351 103 596 minecraft:oak_log
fill 351 103 597 351 104 597 minecraft:green_terracotta
setblock 354 103 598 minecraft:oak_log
setblock 355 103 558 minecraft:oak_leaves[persistent=true]
fill 355 103 598 358 103 598 minecraft:green_terracotta
setblock 359 103 598 minecraft:oak_log
fill 360 103 558 363 103 558 minecraft:green_terracotta
fill 360 103 598 360 106 598 minecraft:green_terracotta
setblock 363 103 559 minecraft:oak_log
setblock 364 103 558 minecraft:oak_log
fill 364 103 559 364 106 559 minecraft:green_terracotta
setblock 364 103 598 minecraft:oak_log
fill 365 103 558 365 106 558 minecraft:green_terracotta
setblock 365 103 597 minecraft:oak_log
fill 365 103 598 365 106 598 minecraft:green_terracotta
fill 366 103 597 366 104 597 minecraft:green_terracotta
setblock 367 103 575 minecraft:oak_log
fill 367 103 576 367 104 576 minecraft:green_terracotta
setblock 367 103 580 minecraft:oak_log
setblock 368 103 559 minecraft:oak_log
setblock 368 103 570 minecraft:green_terracotta
setblock 368 103 574 minecraft:oak_log
fill 368 103 575 368 105 575 minecraft:green_terracotta
setblock 368 103 579 minecraft:oak_log
fill 368 103 580 368 106 580 minecraft:green_terracotta
setblock 369 103 558 minecraft:oak_log
fill 369 103 559 369 106 559 minecraft:green_terracotta
setblock 369 103 563 minecraft:oak_log
setblock 369 103 564 minecraft:green_terracotta
setblock 369 103 568 minecraft:oak_log
fill 369 103 569 369 104 569 minecraft:green_terracotta
setblock 369 103 573 minecraft:oak_log
fill 369 103 574 369 106 574 minecraft:green_terracotta
setblock 369 103 578 minecraft:oak_log
fill 369 103 579 369 106 579 minecraft:green_terracotta
setblock 369 103 583 minecraft:oak_log
setblock 369 103 598 minecraft:oak_log
fill 370 103 558 370 106 558 minecraft:green_terracotta
setblock 370 103 562 minecraft:oak_log
fill 370 103 563 370 106 563 minecraft:green_terracotta
setblock 370 103 567 minecraft:oak_log
fill 370 103 568 370 105 568 minecraft:green_terracotta
setblock 370 103 572 minecraft:oak_log
fill 370 103 573 370 106 573 minecraft:green_terracotta
setblock 370 103 577 minecraft:oak_log
fill 370 103 578 370 106 578 minecraft:green_terracotta
setblock 370 103 582 minecraft:oak_log
fill 370 103 583 370 106 583 minecraft:green_terracotta
setblock 370 103 587 minecraft:oak_leaves[persistent=true]
setblock 370 103 597 minecraft:oak_log
fill 370 103 598 370 105 598 minecraft:green_terracotta
setblock 330 104 561 minecraft:oak_log
fill 330 104 562 330 107 562 minecraft:green_terracotta
setblock 330 104 566 minecraft:oak_log
setblock 330 104 567 minecraft:green_terracotta
setblock 330 104 571 minecraft:oak_log
setblock 330 104 572 minecraft:green_terracotta
setblock 330 104 576 minecraft:oak_log
fill 330 104 577 330 106 577 minecraft:green_terracotta
setblock 330 104 581 minecraft:oak_log
setblock 330 104 596 minecraft:oak_log
fill 330 104 597 330 106 598 minecraft:green_terracotta
setblock 331 104 560 minecraft:oak_log
fill 331 104 561 331 107 561 minecraft:green_terracotta
fill 331 104 598 332 104 598 minecraft:green_terracotta
setblock 332 104 559 minecraft:oak_log
setblock 332 104 560 minecraft:light[level=14]
setblock 332 104 568 minecraft:light[level=14]
setblock 332 104 576 minecraft:light[level=14]
setblock 332 104 584 minecraft:light[level=14]
setblock 332 104 592 minecraft:light[level=14]
setblock 333 104 558 minecraft:oak_log
fill 333 104 559 336 104 559 minecraft:green_terracotta
setblock 333 104 598 minecraft:oak_log
fill 334 104 558 334 107 558 minecraft:green_terracotta
fill 334 104 598 334 107 598 minecraft:green_terracotta
setblock 337 104 559 minecraft:oak_log
setblock 338 104 558 minecraft:oak_log
fill 338 104 559 341 104 559 minecraft:green_terracotta
setblock 338 104 598 minecraft:oak_log
fill 339 104 558 339 107 558 minecraft:green_terracotta
setblock 339 104 597 minecraft:oak_log
fill 339 104 598 339 107 598 minecraft:green_terracotta
setblock 340 104 560 minecraft:light[level=14]
setblock 340 104 568 minecraft:light[level=14]
setblock 340 104 576 minecraft:light[level=14]
setblock 340 104 584 minecraft:light[level=14]
setblock 340 104 592 minecraft:light[level=14]
fill 340 104 597 340 107 597 minecraft:green_terracotta
fill 341 104 596 341 105 596 minecraft:green_terracotta
setblock 342 104 559 minecraft:oak_log
setblock 343 104 558 minecraft:oak_log
fill 343 104 559 343 107 559 minecraft:green_terracotta
setblock 343 104 598 minecraft:oak_log
fill 344 104 558 344 107 558 minecraft:green_terracotta
setblock 344 104 597 minecraft:oak_log
fill 344 104 598 344 107 598 minecraft:green_terracotta
setblock 345 104 596 minecraft:oak_log
fill 345 104 597 345 107 597 minecraft:green_terracotta
fill 346 104 596 346 106 596 minecraft:green_terracotta
setblock 347 104 559 minecraft:oak_log
setblock 348 104 558 minecraft:oak_log
fill 348 104 559 348 105 559 minecraft:green_terracotta
setblock 348 104 560 minecraft:light[level=14]
setblock 348 104 568 minecraft:light[level=14]
setblock 348 104 576 minecraft:light[level=14]
setblock 348 104 584 minecraft:light[level=14]
setblock 348 104 592 minecraft:light[level=14]
setblock 348 104 598 minecraft:oak_log
fill 349 104 558 349 107 558 minecraft:green_terracotta
setblock 349 104 597 minecraft:oak_log
fill 349 104 598 349 107 598 minecraft:green_terracotta
fill 350 104 597 350 105 597 minecraft:green_terracotta
setblock 353 104 598 minecraft:oak_log
fill 354 104 598 357 104 598 minecraft:green_terracotta
setblock 356 104 560 minecraft:light[level=14]
setblock 356 104 568 minecraft:light[level=14]
setblock 356 104 576 minecraft:light[level=14]
setblock 356 104 584 minecraft:light[level=14]
setblock 356 104 592 minecraft:light[level=14]
setblock 358 104 598 minecraft:oak_log
fill 359 104 598 359 105 598 minecraft:green_terracotta
fill 360 104 558 362 104 558 minecraft:green_terracotta
setblock 363 104 558 minecraft:oak_log
fill 363 104 559 363 107 559 minecraft:green_terracotta
setblock 363 104 598 minecraft:oak_log
fill 364 104 558 364 107 558 minecraft:green_terracotta
setblock 364 104 560 minecraft:light[level=14]
setblock 364 104 568 minecraft:light[level=14]
setblock 364 104 576 minecraft:light[level=14]
setblock 364 104 584 minecraft:light[level=14]
setblock 364 104 592 minecraft:light[level=14]
setblock 364 104 597 minecraft:oak_log
fill 364 104 598 364 107 598 minecraft:green_terracotta
setblock 365 104 597 minecraft:green_terracotta
setblock 367 104 559 minecraft:oak_log
setblock 367 104 575 minecraft:green_terracotta
setblock 367 104 579 minecraft:oak_log
setblock 367 104 580 minecraft:green_terracotta
setblock 368 104 558 minecraft:oak_log
fill 368 104 559 368 107 559 minecraft:green_terracotta
setblock 368 104 573 minecraft:oak_log
fill 368 104 574 368 105 574 minecraft:green_terracotta
setblock 368 104 578 minecraft:oak_log
fill 368 104 579 368 106 579 minecraft:green_terracotta
setblock 368 104 598 minecraft:oak_log
fill 369 104 558 369 107 558 minecraft:green_terracotta
setblock 369 104 562 minecraft:oak_log
fill 369 104 563 369 105 563 minecraft:green_terracotta
setblock 369 104 572 minecraft:oak_log
fill 369 104 573 369 105 573 minecraft:green_terracotta
setblock 369 104 577 minecraft:oak_log
fill 369 104 578 369 107 578 minecraft:green_terracotta
setblock 369 104 582 minecraft:oak_log
setblock 369 104 583 minecraft:green_terracotta
fill 369 104 598 369 106 598 minecraft:green_terracotta
setblock 370 104 561 minecraft:oak_log
fill 370 104 562 370 107 562 minecraft:green_terracotta
setblock 370 104 566 minecraft:oak_log
fill 370 104 567 370 106 567 minecraft:green_terracotta
setblock 370 104 571 minecraft:oak_log
fill 370 104 572 370 106 572 minecraft:green_terracotta
setblock 370 104 576 minecraft:oak_log
fill 370 104 577 370 107 577 minecraft:green_terracotta
setblock 370 104 581 minecraft:oak_log
fill 370 104 582 370 107 582 minecraft:green_terracotta
setblock 370 104 596 minecraft:oak_log
setblock 370 104 597 minecraft:green_terracotta
setblock 330 105 560 minecraft:oak_log
fill 330 105 561 330 108 561 minecraft:green_terracotta
setblock 330 105 565 minecraft:oak_log
setblock 330 105 566 minecraft:green_terracotta
setblock 330 105 575 minecraft:oak_log
setblock 330 105 576 minecraft:green_terracotta
setblock 330 105 580 minecraft:oak_log
setblock 330 105 581 minecraft:green_terracotta
setblock 330 105 596 minecraft:green_terracotta
setblock 331 105 559 minecraft:oak_log
fill 331 105 560 331 108 560 minecraft:green_terracotta
setblock 331 105 598 minecraft:green_terracotta
setblock 332 105 558 minecraft:oak_log
fill 332 105 559 335 105 559 minecraft:green_terracotta
setblock 332 105 598 minecraft:oak_log
fill 333 105 558 333 108 558 minecraft:green_terracotta
fill 333 105 598 333 108 598 minecraft:green_terracotta
setblock 336 105 559 minecraft:oak_log
setblock 337 105 558 minecraft:oak_log
fill 337 105 559 340 105 559 minecraft:green_terracotta
setblock 337 105 598 minecraft:oak_log
fill 338 105 558 338 108 558 minecraft:green_terracotta
setblock 338 105 597 minecraft:oak_log
fill 338 105 598 338 108 598 minecraft:green_terracotta
fill 339 105 597 339 108 597 minecraft:green_terracotta
setblock 341 105 559 minecraft:oak_log
setblock 342 105 558 minecraft:oak_log
fill 342 105 559 342 108 559 minecraft:green_terracotta
setblock 342 105 598 minecraft:oak_log
fill 343 105 558 343 108 558 minecraft:green_terracotta
setblock 343 105 597 minecraft:oak_log
fill 343 105 598 343 108 598 minecraft:green_terracotta
setblock 344 105 596 minecraft:oak_log
fill 344 105 597 344 108 597 minecraft:green_terracotta
fill 345 105 596 345 106 596 minecraft:green_terracotta
setblock 346 105 559 minecraft:oak_log
setblock 347 105 558 minecraft:oak_log
fill 347 105 559 347 107 559 minecraft:green_terracotta
setblock 347 105 598 minecraft:oak_log
fill 348 105 558 348 108 558 minecraft:green_terracotta
setblock 348 105 597 minecraft:oak_log
fill 348 105 598 348 108 598 minecraft:green_terracotta
fill 349 105 597 349 106 597 minecraft:green_terracotta
setblock 352 105 598 minecraft:oak_log
setblock 353 105 598 minecraft:green_terracotta
setblock 357 105 598 minecraft:oak_leaves[persistent=true]
fill 360 105 558 361 105 558 minecraft:green_terracotta
setblock 362 105 558 minecraft:oak_log
setblock 362 105 598 minecraft:oak_log
fill 363 105 558 363 108 558 minecraft:green_terracotta
fill 363 105 598 363 108 598 minecraft:green_terracotta
setblock 366 105 559 minecraft:oak_log
setblock 367 105 558 minecraft:oak_log
fill 367 105 559 367 108 559 minecraft:green_terracotta
setblock 367 105 578 minecraft:oak_log
setblock 367 105 598 minecraft:oak_log
fill 368 105 558 368 108 558 minecraft:green_terracotta
setblock 368 105 577 minecraft:oak_log
fill 368 105 578 368 106 578 minecraft:green_terracotta
fill 368 105 598 368 106 598 minecraft:green_terracotta
setblock 369 105 561 minecraft:oak_log
fill 369 105 562 369 108 562 minecraft:green_terracotta
setblock 369 105 571 minecraft:oak_log
setblock 369 105 572 minecraft:green_terracotta
setblock 369 105 576 minecraft:oak_log
fill 369 105 577 369 107 577 minecraft:green_terracotta
setblock 369 105 581 minecraft:oak_log
fill 369 105 582 369 106 582 minecraft:green_terracotta
setblock 370 105 560 minecraft:oak_log
fill 370 105 561 370 108 561 minecraft:green_terracotta
setblock 370 105 565 minecraft:oak_log
fill 370 105 566 370 108 566 minecraft:green_terracotta
setblock 370 105 570 minecraft:oak_log
fill 370 105 571 370 106 571 minecraft:green_terracotta
setblock 370 105 575 minecraft:oak_log
fill 370 105 576 370 108 576 minecraft:green_terracotta
setblock 370 105 580 minecraft:oak_log
fill 370 105 581 370 108 581 minecraft:green_terracotta
setblock 370 105 594 minecraft:oak_leaves[persistent=true]
setblock 330 106 559 minecraft:oak_log
fill 330 106 560 330 109 560 minecraft:green_terracotta
setblock 330 106 564 minecraft:oak_log
fill 330 106 565 330 109 565 minecraft:green_terracotta
setblock 330 106 568 minecraft:oak_leaves[persistent=true]
setblock 330 106 579 minecraft:oak_log
setblock 330 106 587 minecraft:oak_leaves[persistent=true]
setblock 331 106 558 minecraft:oak_log
fill 331 106 559 334 106 559 minecraft:green_terracotta
setblock 331 106 598 minecraft:oak_log
fill 332 106 558 332 109 558 minecraft:green_terracotta
fill 332 106 598 332 107 598 minecraft:green_terracotta
setblock 335 106 559 minecraft:oak_log
setblock 336 106 558 minecraft:oak_log
fill 336 106 559 339 106 559 minecraft:green_terracotta
setblock 336 106 598 minecraft:oak_log
fill 337 106 558 337 109 558 minecraft:green_terracotta
fill 337 106 598 337 109 598 minecraft:green_terracotta
fill 338 106 597 338 109 597 minecraft:green_terracotta
setblock 340 106 559 minecraft:oak_log
setblock 341 106 558 minecraft:oak_log
fill 341 106 559 341 109 559 minecraft:green_terracotta
setblock 341 106 598 minecraft:oak_log
fill 342 106 558 342 109 558 minecraft:green_terracotta
setblock 342 106 597 minecraft:oak_log
fill 342 106 598 342 109 598 minecraft:green_terracotta
setblock 343 106 596 minecraft:oak_log
fill 343 106 597 343 109 597 minecraft:green_terracotta
setblock 344 106 559 minecraft:green_terracotta
fill 344 106 596 344 107 596 minecraft:green_terracotta
setblock 345 106 559 minecraft:oak_log
setblock 346 106 558 minecraft:oak_log
fill 346 106 559 346 109 559 minecraft:green_terracotta
setblock 346 106 598 minecraft:oak_log
fill 347 106 558 347 109 558 minecraft:green_terracotta
setblock 347 106 597 minecraft:oak_log
fill 347 106 598 347 109 598 minecraft:green_terracotta
fill 348 106 597 348 107 597 minecraft:green_terracotta
setblock 351 106 598 minecraft:oak_log
setblock 352 106 598 minecraft:green_terracotta
setblock 356 106 558 minecraft:oak_leaves[persistent=true]
setblock 360 106 558 minecraft:green_terracotta
setblock 361 106 558 minecraft:oak_log
setblock 361 106 598 minecraft:oak_log
fill 362 106 558 362 108 559 minecraft:green_terracotta
fill 362 106 598 362 109 598 minecraft:green_terracotta
setblock 365 106 559 minecraft:oak_log
setblock 366 106 558 minecraft:oak_log
fill 366 106 559 366 109 559 minecraft:green_terracotta
setblock 366 106 598 minecraft:oak_log
fill 367 106 558 367 109 558 minecraft:green_terracotta
fill 367 106 598 367 107 598 minecraft:green_terracotta
setblock 368 106 576 minecraft:oak_log
setblock 368 106 577 minecraft:green_terracotta
setblock 369 106 560 minecraft:oak_log
fill 369 106 561 369 109 561 minecraft:green_terracotta
setblock 369 106 575 minecraft:oak_log
fill 369 106 576 369 107 576 minecraft:green_terracotta
setblock 369 106 580 minecraft:oak_log
fill 369 106 581 369 107 581 minecraft:green_terracotta
setblock 370 106 559 minecraft:oak_log
fill 370 106 560 370 109 560 minecraft:green_terracotta
setblock 370 106 564 minecraft:oak_log
fill 370 106 565 370 109 565 minecraft:green_terracotta
setblock 370 106 569 minecraft:oak_leaves[persistent=true]
setblock 370 106 570 minecraft:green_terracotta
setblock 370 106 574 minecraft:oak_log
fill 370 106 575 370 108 575 minecraft:green_terracotta
setblock 370 106 579 minecraft:oak_log
fill 370 106 580 370 109 580 minecraft:green_terracotta
setblock 370 106 588 minecraft:oak_leaves[persistent=true]
setblock 330 107 558 minecraft:oak_log
fill 330 107 559 333 107 559 minecraft:green_terracotta
setblock 330 107 563 minecraft:oak_log
fill 330 107 564 330 110 564 minecraft:green_terracotta
setblock 330 107 574 minecraft:oak_leaves[persistent=true]
setblock 330 107 593 minecraft:oak_leaves[persistent=true]
setblock 330 107 598 minecraft:oak_log
fill 331 107 558 331 110 558 minecraft:green_terracotta
fill 331 107 598 331 108 598 minecraft:green_terracotta
setblock 334 107 559 minecraft:oak_log
setblock 335 107 558 minecraft:oak_log
fill 335 107 559 338 107 559 minecraft:green_terracotta
setblock 335 107 598 minecraft:oak_log
fill 336 107 558 336 110 558 minecraft:green_terracotta
fill 336 107 598 336 110 598 minecraft:green_terracotta
setblock 339 107 559 minecraft:oak_log
setblock 340 107 558 minecraft:oak_log
fill 340 107 559 340 110 559 minecraft:green_terracotta
setblock 340 107 598 minecraft:oak_log
fill 341 107 558 341 110 558 minecraft:green_terracotta
setblock 341 107 597 minecraft:oak_log
fill 341 107 598 341 110 598 minecraft:green_terracotta
setblock 342 107 596 minecraft:oak_log
fill 342 107 597 342 110 597 minecraft:green_terracotta
setblock 343 107 596 minecraft:green_terracotta
setblock 344 107 559 minecraft:oak_log
setblock 345 107 558 minecraft:oak_log
fill 345 107 559 345 110 559 minecraft:green_terracotta
setblock 345 107 598 minecraft:oak_log
fill 346 107 558 346 110 558 minecraft:green_terracotta
setblock 346 107 597 minecraft:oak_log
fill 346 107 598 346 110 598 minecraft:green_terracotta
fill 347 107 597 347 108 597 minecraft:green_terracotta
setblock 350 107 558 minecraft:oak_leaves[persistent=true]
setblock 350 107 598 minecraft:oak_log
setblock 351 107 598 minecraft:green_terracotta
setblock 359 107 558 minecraft:green_terracotta
setblock 360 107 558 minecraft:oak_log
setblock 360 107 598 minecraft:oak_log
fill 361 107 558 361 109 559 minecraft:green_terracotta
fill 361 107 598 361 110 598 minecraft:green_terracotta
setblock 364 107 559 minecraft:oak_log
setblock 365 107 558 minecraft:oak_log
fill 365 107 559 365 110 559 minecraft:green_terracotta
setblock 365 107 598 minecraft:oak_log
fill 366 107 558 366 110 558 minecraft:green_terracotta
fill 366 107 598 366 108 598 minecraft:green_terracotta
setblock 369 107 559 minecraft:oak_log
fill 369 107 560 369 110 560 minecraft:green_terracotta
setblock 369 107 563 minecraft:green_terracotta
setblock 369 107 579 minecraft:oak_log
fill 369 107 580 369 108 580 minecraft:green_terracotta
setblock 369 107 598 minecraft:oak_leaves[persistent=true]
setblock 370 107 558 minecraft:oak_log
fill 370 107 559 370 110 559 minecraft:green_terracotta
setblock 370 107 563 minecraft:oak_log
fill 370 107 564 370 110 564 minecraft:green_terracotta
setblock 370 107 573 minecraft:oak_log
setblock 370 107 574 minecraft:green_terracotta
setblock 370 107 578 minecraft:oak_log
fill 370 107 579 370 110 579 minecraft:green_terracotta
setblock 370 107 583 minecraft:oak_log
fill 329 108 557 329 108 558 minecraft:dirt
setblock 329 108 559 minecraft:brown_terracotta
fill 329 108 560 329 109 579 minecraft:dirt
setblock 329 108 580 minecraft:brown_terracotta
fill 329 108 581 329 108 592 minecraft:dirt
setblock 329 108 593 minecraft:brown_terracotta
fill 329 108 594 329 109 599 minecraft:dirt
fill 330 108 557 335 108 557 minecraft:dirt
fill 330 108 558 330 110 559 minecraft:green_terracotta
setblock 330 108 562 minecraft:oak_log
fill 330 108 563 330 111 563 minecraft:green_terracotta
setblock 330 108 580 minecraft:oak_leaves[persistent=true]
setblock 330 108 598 minecraft:green_terracotta
fill 330 108 599 330 112 599 minecraft:dirt
fill 331 108 559 332 108 559 minecraft:green_terracotta
setblock 331 108 561 minecraft:oak_log
setblock 331 108 599 minecraft:brown_terracotta
fill 332 108 599 335 108 599 minecraft:dirt
setblock 333 108 559 minecraft:oak_log
setblock 334 108 558 minecraft:oak_log
fill 334 108 559 337 108 559 minecraft:green_terracotta
setblock 334 108 598 minecraft:oak_log
fill 335 108 558 335 111 558 minecraft:green_terracotta
fill 335 108 598 335 111 598 minecraft:green_terracotta
setblock 336 108 557 minecraft:brown_terracotta
setblock 336 108 599 minecraft:brown_terracotta
fill 337 108 557 340 109 557 minecraft:dirt
fill 337 108 599 346 108 599 minecraft:dirt
setblock 338 108 559 minecraft:oak_log
setblock 339 108 558 minecraft:oak_log
fill 339 108 559 339 111 559 minecraft:green_terracotta
fill 339 108 565 339 109 565 minecraft:oak_leaves[persistent=true]
setblock 339 108 598 minecraft:oak_log
fill 340 108 558 340 111 558 minecraft:green_terracotta
setblock 340 108 597 minecraft:oak_log
fill 340 108 598 340 111 598 minecraft:green_terracotta
setblock 341 108 557 minecraft:brown_terracotta
setblock 341 108 560 minecraft:green_terracotta
fill 341 108 597 341 111 597 minecraft:green_terracotta
fill 342 108 557 345 108 557 minecraft:dirt
setblock 342 108 560 minecraft:oak_log
setblock 343 108 559 minecraft:oak_log
fill 343 108 560 343 111 560 minecraft:green_terracotta
setblock 344 108 558 minecraft:oak_log
fill 344 108 559 344 111 559 minecraft:green_terracotta
setblock 344 108 598 minecraft:oak_log
fill 345 108 558 345 111 558 minecraft:green_terracotta
setblock 345 108 597 minecraft:oak_log
fill 345 108 598 345 111 598 minecraft:green_terracotta
setblock 346 108 557 minecraft:brown_terracotta
fill 346 108 597 346 110 597 minecraft:green_terracotta
fill 347 108 557 371 108 557 minecraft:dirt
setblock 347 108 599 minecraft:brown_terracotta
fill 348 108 599 353 108 599 minecraft:dirt
setblock 349 108 558 minecraft:oak_log
setblock 349 108 598 minecraft:oak_log
setblock 350 108 598 minecraft:green_terracotta
setblock 354 108 599 minecraft:brown_terracotta
fill 355 108 599 371 108 599 minecraft:dirt
setblock 356 108 598 minecraft:oak_leaves[persistent=true]
setblock 358 108 558 minecraft:green_terracotta
setblock 359 108 558 minecraft:oak_log
fill 360 108 558 360 111 558 minecraft:green_terracotta
setblock 363 108 559 minecraft:oak_log
setblock 364 108 558 minecraft:oak_log
fill 364 108 559 364 110 560 minecraft:green_terracotta
setblock 364 108 598 minecraft:oak_log
fill 365 108 558 365 111 558 minecraft:green_terracotta
fill 365 108 560 366 108 560 minecraft:green_terracotta
fill 365 108 598 365 110 598 minecraft:green_terracotta
setblock 368 108 559 minecraft:oak_log
setblock 369 108 558 minecraft:oak_log
fill 369 108 559 369 111 559 minecraft:green_terracotta
setblock 369 108 563 minecraft:oak_log
fill 369 108 564 369 111 564 minecraft:green_terracotta
setblock 369 108 578 minecraft:oak_log
setblock 369 108 579 minecraft:green_terracotta
fill 370 108 558 370 111 558 minecraft:green_terracotta
setblock 370 108 562 minecraft:oak_log
fill 370 108 563 370 111 563 minecraft:green_terracotta
setblock 370 108 577 minecraft:oak_log
fill 370 108 578 370 110 578 minecraft:green_terracotta
setblock 370 108 582 minecraft:oak_log
fill 370 108 583 370 111 583 minecraft:green_terracotta
setblock 370 108 595 minecraft:oak_leaves[persistent=true]
fill 371 108 558 371 109 563 minecraft:dirt
setblock 371 108 564 minecraft:brown_terracotta
fill 371 108 565 371 108 580 minecraft:dirt
fill 371 108 581 371 109 581 minecraft:brown_terracotta
fill 371 108 582 371 108 591 minecraft:dirt
setblock 371 108 592 minecraft:brown_terracotta
fill 371 108 593 371 111 594 minecraft:dirt
setblock 371 108 595 minecraft:brown_terracotta
fill 371 108 596 371 111 598 minecraft:dirt
fill 329 109 557 331 109 557 minecraft:dirt
setblock 329 109 558 minecraft:brown_terracotta
fill 329 109 559 329 111 559 minecraft:dirt
fill 329 109 580 329 111 581 minecraft:dirt
setblock 329 109 582 minecraft:brown_terracotta
setblock 329 109 583 minecraft:dirt
setblock 329 109 584 minecraft:brown_terracotta
fill 329 109 585 329 109 593 minecraft:dirt
setblock 330 109 561 minecraft:oak_log
fill 330 109 562 331 111 562 minecraft:green_terracotta
setblock 330 109 567 minecraft:oak_leaves[persistent=true]
setblock 330 109 586 minecraft:oak_leaves[persistent=true]
setblock 331 109 559 minecraft:green_terracotta
setblock 331 109 560 minecraft:oak_log
fill 331 109 561 331 112 561 minecraft:green_terracotta
fill 331 109 599 333 111 599 minecraft:dirt
fill 332 109 557 332 110 557 minecraft:brown_terracotta
setblock 332 109 559 minecraft:oak_log
fill 333 109 557 333 111 557 minecraft:dirt
setblock 333 109 558 minecraft:oak_log
fill 333 109 559 336 109 559 minecraft:green_terracotta
setblock 333 109 598 minecraft:oak_log
fill 334 109 557 334 110 557 minecraft:brown_terracotta
fill 334 109 558 334 112 558 minecraft:green_terracotta
fill 334 109 598 334 112 598 minecraft:green_terracotta
setblock 334 109 599 minecraft:brown_terracotta
fill 335 109 557 336 111 557 minecraft:dirt
fill 335 109 599 336 111 599 minecraft:dirt
setblock 337 109 559 minecraft:oak_log
setblock 337 109 599 minecraft:brown_terracotta
setblock 338 109 558 minecraft:oak_log
fill 338 109 559 338 112 559 minecraft:green_terracotta
setblock 338 109 598 minecraft:oak_log
fill 338 109 599 348 111 599 minecraft:dirt
fill 339 109 558 339 112 558 minecraft:green_terracotta
fill 339 109 560 340 109 560 minecraft:green_terracotta
setblock 339 109 597 minecraft:oak_log
fill 339 109 598 339 112 598 minecraft:green_terracotta
fill 340 109 597 340 112 597 minecraft:green_terracotta
fill 341 109 557 341 111 557 minecraft:dirt
setblock 341 109 560 minecraft:oak_log
setblock 342 109 557 minecraft:brown_terracotta
setblock 342 109 559 minecraft:oak_log
fill 342 109 560 342 112 560 minecraft:green_terracotta
fill 343 109 557 360 111 557 minecraft:dirt
setblock 343 109 558 minecraft:oak_log
fill 343 109 559 343 112 559 minecraft:green_terracotta
setblock 343 109 598 minecraft:oak_log
fill 344 109 558 344 112 558 minecraft:green_terracotta
setblock 344 109 597 minecraft:oak_log
fill 344 109 598 344 112 598 minecraft:green_terracotta
fill 345 109 597 345 112 597 minecraft:green_terracotta
setblock 348 109 558 minecraft:oak_log
setblock 348 109 598 minecraft:oak_log
setblock 349 109 598 minecraft:green_terracotta
setblock 349 109 599 minecraft:brown_terracotta
fill 350 109 599 363 109 599 minecraft:dirt
setblock 357 109 558 minecraft:oak_leaves[persistent=true]
setblock 358 109 558 minecraft:oak_log
fill 359 109 558 359 112 558 minecraft:green_terracotta
fill 360 109 559 360 110 559 minecraft:green_terracotta
fill 360 109 598 360 111 598 minecraft:green_terracotta
fill 361 109 557 361 110 557 minecraft:brown_terracotta
fill 362 109 557 371 109 557 minecraft:dirt
setblock 362 109 558 minecraft:green_terracotta
setblock 362 109 559 minecraft:oak_log
fill 362 109 560 363 111 560 minecraft:green_terracotta
setblock 363 109 558 minecraft:oak_log
fill 363 109 559 363 112 559 minecraft:green_terracotta
setblock 363 109 598 minecraft:oak_log
fill 364 109 558 364 112 558 minecraft:green_terracotta
fill 364 109 598 364 112 598 minecraft:green_terracotta
fill 364 109 599 365 109 599 minecraft:brown_terracotta
setblock 365 109 560 minecraft:green_terracotta
setblock 366 109 560 minecraft:oak_log
fill 366 109 599 371 109 599 minecraft:dirt
setblock 367 109 559 minecraft:oak_log
setblock 368 109 558 minecraft:oak_log
fill 368 109 559 368 112 559 minecraft:green_terracotta
fill 369 109 558 369 112 558 minecraft:green_terracotta
setblock 369 109 562 minecraft:oak_log
fill 369 109 563 369 112 563 minecraft:green_terracotta
setblock 370 109 561 minecraft:oak_log
fill 370 109 562 370 112 562 minecraft:green_terracotta
setblock 370 109 566 minecraft:oak_log
fill 370 109 567 370 112 567 minecraft:green_terracotta
setblock 370 109 570 minecraft:oak_leaves[persistent=true]
setblock 370 109 577 minecraft:green_terracotta
setblock 370 109 581 minecraft:oak_log
fill 370 109 582 370 112 582 minecraft:green_terracotta
setblock 370 109 589 minecraft:oak_leaves[persistent=true]
fill 371 109 564 371 111 570 minecraft:dirt
setblock 371 109 571 minecraft:brown_terracotta
setblock 371 109 572 minecraft:dirt
fill 371 109 573 371 109 574 minecraft:brown_terracotta
fill 371 109 575 371 111 575 minecraft:dirt
setblock 371 109 576 minecraft:brown_terracotta
fill 371 109 577 371 111 577 minecraft:dirt
setblock 371 109 578 minecraft:brown_terracotta
fill 371 109 579 371 111 580 minecraft:dirt
fill 371 109 582 371 111 588 minecraft:dirt
setblock 371 109 589 minecraft:brown_terracotta
fill 371 109 590 371 111 590 minecraft:dirt
setblock 371 109 591 minecraft:brown_terracotta
fill 371 109 592 371 111 592 minecraft:dirt
fill 371 109 595 371 111 595 minecraft:dirt
setblock 329 110 557 minecraft:brown_terracotta
fill 329 110 558 329 111 558 minecraft:dirt
fill 329 110 560 329 111 561 minecraft:dirt
setblock 329 110 562 minecraft:brown_terracotta
fill 329 110 563 329 111 568 minecraft:dirt
setblock 329 110 569 minecraft:brown_terracotta
fill 329 110 570 329 111 575 minecraft:dirt
setblock 329 110 576 minecraft:brown_terracotta
fill 329 110 577 329 111 579 minecraft:dirt
fill 329 110 582 329 111 582 minecraft:dirt
setblock 329 110 583 minecraft:brown_terracotta
fill 329 110 584 329 111 589 minecraft:dirt
fill 329 110 590 329 110 591 minecraft:brown_terracotta
fill 329 110 592 329 111 598 minecraft:dirt
setblock 329 110 599 minecraft:brown_terracotta
fill 330 110 557 331 111 557 minecraft:dirt
setblock 330 110 560 minecraft:oak_log
fill 330 110 561 330 113 561 minecraft:green_terracotta
setblock 330 110 565 minecraft:oak_log
fill 330 110 566 330 113 566 minecraft:green_terracotta
setblock 330 110 573 minecraft:oak_leaves[persistent=true]
setblock 330 110 592 minecraft:oak_leaves[persistent=true]
setblock 331 110 559 minecraft:oak_log
fill 331 110 560 331 113 560 minecraft:green_terracotta
setblock 332 110 558 minecraft:oak_log
fill 332 110 559 335 110 559 minecraft:green_terracotta
fill 333 110 558 333 113 558 minecraft:green_terracotta
fill 333 110 598 333 113 598 minecraft:green_terracotta
fill 334 110 599 334 111 599 minecraft:dirt
setblock 336 110 559 minecraft:oak_log
fill 337 110 557 337 111 557 minecraft:dirt
setblock 337 110 558 minecraft:oak_log
fill 337 110 559 337 113 559 minecraft:green_terracotta
setblock 337 110 597 minecraft:green_terracotta
setblock 337 110 598 minecraft:oak_log
fill 337 110 599 337 111 599 minecraft:dirt
setblock 338 110 557 minecraft:brown_terracotta
fill 338 110 558 338 113 558 minecraft:green_terracotta
fill 338 110 560 339 110 560 minecraft:green_terracotta
setblock 338 110 597 minecraft:oak_log
fill 338 110 598 338 113 598 minecraft:green_terracotta
fill 339 110 557 339 111 557 minecraft:dirt
fill 339 110 597 339 113 597 minecraft:green_terracotta
setblock 340 110 557 minecraft:brown_terracotta
setblock 340 110 560 minecraft:oak_log
setblock 341 110 559 minecraft:oak_log
fill 341 110 560 341 113 560 minecraft:green_terracotta
fill 342 110 557 342 111 557 minecraft:dirt
setblock 342 110 558 minecraft:oak_log
fill 342 110 559 342 113 559 minecraft:green_terracotta
setblock 342 110 598 minecraft:oak_log
fill 343 110 558 343 113 558 minecraft:green_terracotta
setblock 343 110 597 minecraft:oak_log
fill 343 110 598 343 113 598 minecraft:green_terracotta
fill 344 110 597 344 113 597 minecraft:green_terracotta
setblock 346 110 559 minecraft:oak_log
setblock 347 110 558 minecraft:oak_log
setblock 347 110 598 minecraft:oak_log
setblock 348 110 558 minecraft:green_terracotta
fill 348 110 598 348 111 598 minecraft:green_terracotta
setblock 349 110 598 minecraft:oak_leaves[persistent=true]
fill 349 110 599 356 111 599 minecraft:dirt
setblock 351 110 558 minecraft:oak_leaves[persistent=true]
setblock 357 110 558 minecraft:oak_log
setblock 357 110 599 minecraft:brown_terracotta
fill 358 110 558 358 113 558 minecraft:green_terracotta
fill 358 110 599 362 111 599 minecraft:dirt
fill 359 110 559 359 111 559 minecraft:green_terracotta
setblock 361 110 558 minecraft:green_terracotta
setblock 361 110 559 minecraft:oak_log
fill 361 110 560 361 113 560 minecraft:green_terracotta
fill 362 110 557 362 111 557 minecraft:dirt
setblock 362 110 558 minecraft:oak_log
fill 362 110 559 362 113 559 minecraft:green_terracotta
setblock 362 110 598 minecraft:oak_log
setblock 363 110 557 minecraft:brown_terracotta
fill 363 110 558 363 113 558 minecraft:green_terracotta
fill 363 110 598 363 113 598 minecraft:green_terracotta
setblock 363 110 599 minecraft:brown_terracotta
fill 364 110 557 367 111 557 minecraft:dirt
fill 364 110 599 364 111 599 minecraft:dirt
setblock 365 110 560 minecraft:oak_log
setblock 365 110 599 minecraft:brown_terracotta
setblock 366 110 559 minecraft:oak_log
fill 366 110 560 367 112 560 minecraft:green_terracotta
fill 366 110 599 370 111 599 minecraft:dirt
setblock 367 110 558 minecraft:oak_log
fill 367 110 559 367 113 559 minecraft:green_terracotta
setblock 368 110 557 minecraft:brown_terracotta
fill 368 110 558 368 113 558 minecraft:green_terracotta
setblock 368 110 562 minecraft:oak_log
fill 368 110 581 368 129 581 minecraft:iron_block
setblock 368 110 598 minecraft:oak_leaves[persistent=true]
fill 369 110 557 371 111 557 minecraft:dirt
setblock 369 110 561 minecraft:oak_log
fill 369 110 562 369 113 562 minecraft:green_terracotta
setblock 369 110 565 minecraft:green_terracotta
setblock 369 110 566 minecraft:oak_log
setblock 370 110 560 minecraft:oak_log
fill 370 110 561 370 113 561 minecraft:green_terracotta
setblock 370 110 565 minecraft:oak_log
fill 370 110 566 370 113 566 minecraft:green_terracotta
fill 370 110 568 370 111 568 minecraft:green_terracotta
setblock 370 110 580 minecraft:oak_log
fill 370 110 581 370 112 581 minecraft:green_terracotta
fill 371 110 558 371 111 560 minecraft:dirt
setblock 371 110 561 minecraft:brown_terracotta
fill 371 110 562 371 111 563 minecraft:dirt
fill 371 110 571 371 111 571 minecraft:dirt
setblock 371 110 572 minecraft:brown_terracotta
fill 371 110 573 371 111 574 minecraft:dirt
fill 371 110 576 371 111 576 minecraft:dirt
fill 371 110 578 371 111 578 minecraft:dirt
fill 371 110 581 371 111 581 minecraft:dirt
fill 371 110 589 371 111 589 minecraft:dirt
fill 371 110 591 371 111 591 minecraft:dirt
setblock 371 110 599 minecraft:brown_terracotta
setblock 329 111 557 minecraft:dirt
setblock 329 111 562 minecraft:dirt
setblock 329 111 569 minecraft:dirt
setblock 329 111 576 minecraft:dirt
setblock 329 111 583 minecraft:dirt
fill 329 111 590 329 111 591 minecraft:dirt
setblock 329 111 599 minecraft:dirt
setblock 330 111 558 minecraft:green_terracotta
setblock 330 111 559 minecraft:oak_log
fill 330 111 560 330 114 560 minecraft:green_terracotta
setblock 330 111 564 minecraft:oak_log
fill 330 111 565 330 114 565 minecraft:green_terracotta
setblock 330 111 579 minecraft:oak_leaves[persistent=true]
setblock 330 111 598 minecraft:oak_leaves[persistent=true]
setblock 331 111 558 minecraft:oak_log
fill 331 111 559 334 111 559 minecraft:green_terracotta
setblock 331 111 563 minecraft:oak_log
setblock 332 111 557 minecraft:dirt
fill 332 111 558 332 114 558 minecraft:green_terracotta
fill 332 111 598 332 114 598 minecraft:green_terracotta
setblock 334 111 557 minecraft:dirt
setblock 335 111 559 minecraft:oak_log
setblock 336 111 558 minecraft:oak_log
fill 336 111 559 336 113 560 minecraft:green_terracotta
setblock 336 111 598 minecraft:oak_log
fill 337 111 558 337 114 558 minecraft:green_terracotta
fill 337 111 560 338 111 560 minecraft:green_terracotta
setblock 337 111 597 minecraft:oak_log
fill 337 111 598 337 114 598 minecraft:green_terracotta
setblock 338 111 557 minecraft:dirt
fill 338 111 597 338 114 597 minecraft:green_terracotta
setblock 339 111 560 minecraft:oak_log
setblock 340 111 557 minecraft:dirt
setblock 340 111 559 minecraft:oak_log
fill 340 111 560 340 114 560 minecraft:green_terracotta
setblock 341 111 558 minecraft:oak_log
fill 341 111 559 341 114 559 minecraft:green_terracotta
setblock 341 111 598 minecraft:oak_log
fill 342 111 558 342 114 558 minecraft:green_terracotta
setblock 342 111 597 minecraft:oak_log
fill 342 111 598 342 114 598 minecraft:green_terracotta
fill 343 111 597 343 114 597 minecraft:green_terracotta
setblock 345 111 559 minecraft:oak_log
setblock 346 111 558 minecraft:oak_log
setblock 346 111 598 minecraft:oak_log
fill 347 111 558 347 112 558 minecraft:green_terracotta
fill 347 111 598 347 112 598 minecraft:green_terracotta
setblock 355 111 598 minecraft:oak_leaves[persistent=true]
setblock 356 111 558 minecraft:oak_log
fill 357 111 558 357 114 558 minecraft:green_terracotta
setblock 357 111 599 minecraft:dirt
fill 358 111 559 358 112 559 minecraft:green_terracotta
fill 359 111 598 359 112 598 minecraft:green_terracotta
setblock 360 111 559 minecraft:oak_log
fill 360 111 560 360 114 560 minecraft:green_terracotta
setblock 361 111 557 minecraft:dirt
setblock 361 111 558 minecraft:oak_log
fill 361 111 559 361 114 559 minecraft:green_terracotta
setblock 361 111 598 minecraft:oak_log
fill 362 111 558 362 114 558 minecraft:green_terracotta
fill 362 111 598 362 114 598 minecraft:green_terracotta
setblock 363 111 557 minecraft:dirt
setblock 363 111 599 minecraft:dirt
setblock 364 111 559 minecraft:green_terracotta
setblock 364 111 560 minecraft:oak_log
setblock 365 111 559 minecraft:oak_log
fill 365 111 560 365 114 560 minecraft:green_terracotta
setblock 365 111 599 minecraft:dirt
setblock 366 111 558 minecraft:oak_log
fill 366 111 559 366 114 559 minecraft:green_terracotta
fill 367 111 558 367 114 558 minecraft:green_terracotta
setblock 368 111 557 minecraft:dirt
setblock 368 111 561 minecraft:oak_log
fill 368 111 562 368 112 564 minecraft:green_terracotta
setblock 369 111 560 minecraft:oak_log
fill 369 111 561 369 114 561 minecraft:green_terracotta
setblock 369 111 565 minecraft:oak_log
fill 369 111 566 369 113 567 minecraft:green_terracotta
setblock 370 111 559 minecraft:oak_log
fill 370 111 560 370 114 560 minecraft:green_terracotta
setblock 370 111 564 minecraft:oak_log
fill 370 111 565 370 114 565 minecraft:green_terracotta
setblock 370 111 569 minecraft:oak_log
setblock 370 111 577 minecraft:oak_leaves[persistent=true]
setblock 370 111 579 minecraft:oak_log
setblock 370 111 580 minecraft:green_terracotta
setblock 370 111 584 minecraft:oak_log
setblock 371 111 561 minecraft:dirt
setblock 371 111 572 minecraft:dirt
setblock 371 111 599 minecraft:dirt
fill 329 112 557 329 112 566 minecraft:brown_terracotta
setblock 329 112 567 minecraft:dirt
fill 329 112 568 329 112 579 minecraft:brown_terracotta
setblock 329 112 580 minecraft:dirt
fill 329 112 581 329 112 583 minecraft:brown_terracotta
setblock 329 112 584 minecraft:dirt
fill 329 112 585 329 113 586 minecraft:brown_terracotta
setblock 329 112 587 minecraft:dirt
fill 329 112 588 329 112 599 minecraft:brown_terracotta
fill 330 112 557 351 112 557 minecraft:brown_terracotta
setblock 330 112 558 minecraft:oak_log
fill 330 112 559 333 112 559 minecraft:green_terracotta
setblock 330 112 562 minecraft:green_terracotta
setblock 330 112 563 minecraft:oak_log
fill 330 112 564 331 114 564 minecraft:green_terracotta
setblock 330 112 567 minecraft:green_terracotta
setblock 330 112 585 minecraft:oak_leaves[persistent=true]
fill 331 112 558 331 115 558 minecraft:green_terracotta
setblock 331 112 562 minecraft:oak_log
fill 331 112 563 331 115 563 minecraft:green_terracotta
fill 331 112 598 331 115 598 minecraft:green_terracotta
fill 331 112 599 354 112 599 minecraft:brown_terracotta
setblock 332 112 560 minecraft:light[level=14]
setblock 332 112 568 minecraft:light[level=14]
setblock 332 112 576 minecraft:light[level=14]
setblock 332 112 584 minecraft:light[level=14]
setblock 332 112 592 minecraft:light[level=14]
setblock 334 112 559 minecraft:oak_log
setblock 335 112 558 minecraft:oak_log
fill 335 112 559 335 114 560 minecraft:green_terracotta
setblock 335 112 598 minecraft:oak_log
fill 336 112 558 336 115 558 minecraft:green_terracotta
setblock 336 112 597 minecraft:oak_log
fill 336 112 598 336 115 598 minecraft:green_terracotta
setblock 337 112 560 minecraft:green_terracotta
fill 337 112 597 337 115 597 minecraft:green_terracotta
setblock 338 112 560 minecraft:oak_log
setblock 339 112 559 minecraft:oak_log
fill 339 112 560 339 115 560 minecraft:green_terracotta
setblock 340 112 558 minecraft:oak_log
fill 340 112 559 340 115 559 minecraft:green_terracotta
setblock 340 112 568 minecraft:light[level=14]
setblock 340 112 576 minecraft:light[level=14]
setblock 340 112 584 minecraft:light[level=14]
setblock 340 112 592 minecraft:light[level=14]
fill 340 112 596 341 112 596 minecraft:green_terracotta
setblock 340 112 598 minecraft:oak_log
fill 341 112 558 341 115 558 minecraft:green_terracotta
setblock 341 112 597 minecraft:oak_log
fill 341 112 598 341 115 598 minecraft:green_terracotta
fill 342 112 597 342 115 597 minecraft:green_terracotta
setblock 343 112 560 minecraft:oak_log
setblock 344 112 559 minecraft:oak_log
setblock 345 112 558 minecraft:oak_log
setblock 345 112 559 minecraft:green_terracotta
setblock 345 112 598 minecraft:oak_log
fill 346 112 558 346 113 558 minecraft:green_terracotta
fill 346 112 598 346 114 598 minecraft:green_terracotta
setblock 348 112 560 minecraft:light[level=14]
setblock 348 112 568 minecraft:light[level=14]
setblock 348 112 576 minecraft:light[level=14]
setblock 348 112 584 minecraft:light[level=14]
setblock 348 112 592 minecraft:light[level=14]
fill 352 112 557 352 113 557 minecraft:dirt
fill 353 112 557 364 112 557 minecraft:brown_terracotta
setblock 355 112 599 minecraft:dirt
fill 356 112 558 356 115 558 minecraft:green_terracotta
setblock 356 112 560 minecraft:light[level=14]
setblock 356 112 568 minecraft:light[level=14]
setblock 356 112 576 minecraft:light[level=14]
setblock 356 112 584 minecraft:light[level=14]
setblock 356 112 592 minecraft:light[level=14]
fill 356 112 599 365 112 599 minecraft:brown_terracotta
fill 357 112 559 357 113 559 minecraft:green_terracotta
setblock 359 112 559 minecraft:oak_log
fill 359 112 560 359 115 560 minecraft:green_terracotta
setblock 360 112 558 minecraft:oak_log
fill 360 112 559 360 115 559 minecraft:green_terracotta
setblock 360 112 598 minecraft:oak_log
fill 361 112 558 361 115 558 minecraft:green_terracotta
fill 361 112 598 361 115 598 minecraft:green_terracotta
setblock 362 112 560 minecraft:green_terracotta
setblock 362 112 561 minecraft:oak_log
setblock 363 112 560 minecraft:oak_log
fill 363 112 561 364 113 561 minecraft:green_terracotta
setblock 364 112 559 minecraft:oak_log
fill 364 112 560 364 115 560 minecraft:green_terracotta
setblock 364 112 568 minecraft:light[level=14]
setblock 364 112 576 minecraft:light[level=14]
setblock 364 112 584 minecraft:light[level=14]
setblock 364 112 592 minecraft:light[level=14]
fill 365 112 557 365 114 557 minecraft:dirt
setblock 365 112 558 minecraft:oak_log
fill 365 112 559 365 115 559 minecraft:green_terracotta
fill 366 112 557 371 113 557 minecraft:brown_terracotta
fill 366 112 558 366 115 558 minecraft:green_terracotta
setblock 366 112 599 minecraft:dirt
fill 367 112 599 371 172 599 minecraft:brown_terracotta
fill 368 112 561 368 114 561 minecraft:green_terracotta
setblock 368 112 565 minecraft:oak_log
setblock 369 112 559 minecraft:oak_log
fill 369 112 560 369 115 560 minecraft:green_terracotta
setblock 369 112 564 minecraft:oak_log
fill 369 112 565 369 115 565 minecraft:green_terracotta
setblock 370 112 558 minecraft:oak_log
fill 370 112 559 370 115 559 minecraft:green_terracotta
setblock 370 112 563 minecraft:oak_log
fill 370 112 564 370 115 564 minecraft:green_terracotta
setblock 370 112 568 minecraft:oak_log
fill 370 112 569 370 114 570 minecraft:green_terracotta
setblock 370 112 571 minecraft:oak_leaves[persistent=true]
setblock 370 112 583 minecraft:oak_log
fill 370 112 584 370 114 584 minecraft:green_terracotta
setblock 370 112 596 minecraft:oak_leaves[persistent=true]
fill 371 112 558 371 112 578 minecraft:brown_terracotta
setblock 371 112 579 minecraft:dirt
fill 371 112 580 371 112 593 minecraft:brown_terracotta
setblock 371 112 594 minecraft:dirt
fill 371 112 595 371 112 598 minecraft:brown_terracotta
fill 329 113 557 329 113 564 minecraft:brown_terracotta
setblock 329 113 565 minecraft:dirt
fill 329 113 566 329 176 568 minecraft:brown_terracotta
setblock 329 113 569 minecraft:dirt
fill 329 113 570 329 113 572 minecraft:brown_terracotta
setblock 329 113 573 minecraft:dirt
fill 329 113 574 329 172 581 minecraft:brown_terracotta
setblock 329 113 582 minecraft:dirt
fill 329 113 583 329 173 584 minecraft:brown_terracotta
fill 329 113 587 329 113 595 minecraft:brown_terracotta
setblock 329 113 596 minecraft:dirt
fill 329 113 597 329 172 599 minecraft:brown_terracotta
fill 330 113 557 336 172 557 minecraft:brown_terracotta
fill 330 113 558 330 115 559 minecraft:green_terracotta
setblock 330 113 562 minecraft:oak_log
fill 330 113 563 330 116 563 minecraft:green_terracotta
setblock 330 113 567 minecraft:oak_log
fill 330 113 584 330 113 586 minecraft:green_terracotta
setblock 330 113 587 minecraft:oak_log
setblock 330 113 591 minecraft:oak_leaves[persistent=true]
fill 330 113 599 338 113 599 minecraft:brown_terracotta
fill 331 113 559 332 113 559 minecraft:green_terracotta
setblock 331 113 561 minecraft:oak_log
fill 331 113 562 331 116 562 minecraft:green_terracotta
setblock 331 113 565 minecraft:green_terracotta
setblock 333 113 559 minecraft:oak_log
setblock 334 113 558 minecraft:oak_log
fill 334 113 559 334 116 559 minecraft:green_terracotta
setblock 334 113 598 minecraft:oak_log
fill 335 113 558 335 116 558 minecraft:green_terracotta
setblock 335 113 597 minecraft:oak_log
fill 335 113 598 335 116 598 minecraft:green_terracotta
fill 336 113 597 336 116 597 minecraft:green_terracotta
setblock 337 113 557 minecraft:dirt
setblock 337 113 560 minecraft:oak_log
fill 338 113 557 338 176 557 minecraft:brown_terracotta
setblock 338 113 559 minecraft:oak_log
fill 338 113 560 338 115 560 minecraft:green_terracotta
setblock 339 113 557 minecraft:dirt
setblock 339 113 558 minecraft:oak_log
fill 339 113 559 339 116 559 minecraft:green_terracotta
fill 339 113 596 340 113 596 minecraft:green_terracotta
setblock 339 113 598 minecraft:oak_log
setblock 339 113 599 minecraft:dirt
fill 340 113 557 351 113 557 minecraft:brown_terracotta
fill 340 113 558 340 116 558 minecraft:green_terracotta
setblock 340 113 597 minecraft:oak_log
fill 340 113 598 340 116 598 minecraft:green_terracotta
fill 340 113 599 350 172 599 minecraft:brown_terracotta
setblock 341 113 596 minecraft:oak_log
fill 341 113 597 341 116 597 minecraft:green_terracotta
setblock 342 113 560 minecraft:oak_log
setblock 343 113 559 minecraft:oak_log
setblock 344 113 558 minecraft:oak_log
setblock 344 113 559 minecraft:green_terracotta
setblock 344 113 598 minecraft:oak_log
fill 345 113 558 345 114 558 minecraft:green_terracotta
fill 345 113 598 345 115 598 minecraft:green_terracotta
setblock 351 113 599 minecraft:dirt
fill 352 113 599 353 113 599 minecraft:brown_terracotta
fill 353 113 557 359 113 557 minecraft:brown_terracotta
fill 354 113 599 354 114 599 minecraft:dirt
fill 355 113 558 355 116 558 minecraft:green_terracotta
fill 355 113 599 356 174 599 minecraft:brown_terracotta
setblock 357 113 599 minecraft:dirt
setblock 358 113 559 minecraft:oak_log
fill 358 113 560 358 115 560 minecraft:green_terracotta
setblock 358 113 598 minecraft:green_terracotta
fill 358 113 599 366 113 599 minecraft:brown_terracotta
setblock 359 113 558 minecraft:oak_log
fill 359 113 559 359 116 559 minecraft:green_terracotta
setblock 359 113 598 minecraft:oak_log
setblock 360 113 557 minecraft:dirt
fill 360 113 558 360 116 558 minecraft:green_terracotta
fill 360 113 598 360 115 598 minecraft:green_terracotta
fill 361 113 557 364 113 557 minecraft:brown_terracotta
setblock 361 113 561 minecraft:oak_log
setblock 362 113 560 minecraft:oak_log
fill 362 113 561 362 114 561 minecraft:green_terracotta
setblock 363 113 559 minecraft:oak_log
fill 363 113 560 363 115 560 minecraft:green_terracotta
setblock 364 113 558 minecraft:oak_log
fill 364 113 559 364 116 559 minecraft:green_terracotta
fill 365 113 558 365 116 558 minecraft:green_terracotta
setblock 366 113 560 minecraft:green_terracotta
setblock 367 113 560 minecraft:oak_log
setblock 367 113 598 minecraft:oak_leaves[persistent=true]
setblock 368 113 559 minecraft:oak_log
fill 368 113 562 368 113 563 minecraft:green_terracotta
setblock 368 113 564 minecraft:oak_log
fill 368 113 565 368 115 566 minecraft:green_terracotta
setblock 369 113 558 minecraft:oak_log
fill 369 113 559 369 115 559 minecraft:green_terracotta
setblock 369 113 563 minecraft:oak_log
fill 369 113 564 369 116 564 minecraft:green_terracotta
setblock 369 113 568 minecraft:oak_log
fill 370 113 558 370 116 558 minecraft:green_terracotta
setblock 370 113 562 minecraft:oak_log
fill 370 113 563 370 116 563 minecraft:green_terracotta
setblock 370 113 567 minecraft:oak_log
fill 370 113 568 370 116 568 minecraft:green_terracotta
setblock 370 113 582 minecraft:oak_log
fill 370 113 583 370 114 583 minecraft:green_terracotta
fill 370 113 585 370 114 585 minecraft:green_terracotta
setblock 370 113 590 minecraft:oak_leaves[persistent=true]
fill 371 113 558 371 172 562 minecraft:brown_terracotta
setblock 371 113 563 minecraft:dirt
fill 371 113 564 371 113 575 minecraft:brown_terracotta
setblock 371 113 576 minecraft:dirt
fill 371 113 577 371 172 582 minecraft:brown_terracotta
setblock 371 113 583 minecraft:dirt
fill 371 113 584 371 113 595 minecraft:brown_terracotta
setblock 371 113 596 minecraft:dirt
fill 371 113 597 371 113 598 minecraft:brown_terracotta
fill 329 114 557 329 176 558 minecraft:brown_terracotta
fill 329 114 559 329 114 560 minecraft:dirt
fill 329 114 561 329 176 562 minecraft:brown_terracotta
setblock 329 114 563 minecraft:dirt
fill 329 114 564 329 176 565 minecraft:brown_terracotta
fill 329 114 569 329 176 569 minecraft:brown_terracotta
setblock 329 114 570 minecraft:dirt
fill 329 114 571 329 176 571 minecraft:brown_terracotta
setblock 329 114 572 minecraft:dirt
fill 329 114 573 329 176 573 minecraft:brown_terracotta
fill 329 114 582 329 173 582 minecraft:brown_terracotta
setblock 329 114 585 minecraft:dirt
fill 329 114 586 329 172 586 minecraft:brown_terracotta
setblock 329 114 587 minecraft:dirt
fill 329 114 588 329 172 593 minecraft:brown_terracotta
setblock 329 114 594 minecraft:dirt
fill 329 114 595 329 172 596 minecraft:brown_terracotta
setblock 330 114 561 minecraft:oak_log
fill 330 114 562 330 117 562 minecraft:green_terracotta
setblock 330 114 566 minecraft:oak_log
fill 330 114 567 330 116 568 minecraft:green_terracotta
setblock 330 114 572 minecraft:oak_leaves[persistent=true]
fill 330 114 584 330 114 585 minecraft:green_terracotta
setblock 330 114 586 minecraft:oak_log
fill 330 114 587 330 114 590 minecraft:green_terracotta
setblock 330 114 597 minecraft:oak_leaves[persistent=true]
fill 330 114 599 332 176 599 minecraft:brown_terracotta
setblock 331 114 559 minecraft:green_terracotta
setblock 331 114 560 minecraft:oak_log
fill 331 114 561 331 116 561 minecraft:green_terracotta
setblock 331 114 565 minecraft:oak_log
setblock 332 114 559 minecraft:oak_log
setblock 333 114 558 minecraft:oak_log
fill 333 114 559 333 116 559 minecraft:green_terracotta
setblock 333 114 598 minecraft:oak_log
setblock 333 114 599 minecraft:dirt
fill 334 114 558 334 117 558 minecraft:green_terracotta
fill 334 114 598 334 117 598 minecraft:green_terracotta
fill 334 114 599 339 176 599 minecraft:brown_terracotta
fill 335 114 597 335 117 597 minecraft:green_terracotta
setblock 336 114 559 minecraft:green_terracotta
setblock 336 114 560 minecraft:oak_log
fill 337 114 557 337 177 557 minecraft:brown_terracotta
setblock 337 114 559 minecraft:oak_log
fill 337 114 560 337 115 560 minecraft:green_terracotta
setblock 338 114 558 minecraft:oak_log
fill 338 114 559 338 117 559 minecraft:green_terracotta
fill 338 114 596 339 114 596 minecraft:green_terracotta
setblock 338 114 598 minecraft:oak_log
fill 339 114 557 340 176 557 minecraft:brown_terracotta
fill 339 114 558 339 117 558 minecraft:green_terracotta
setblock 339 114 597 minecraft:oak_log
fill 339 114 598 339 117 598 minecraft:green_terracotta
setblock 340 114 596 minecraft:oak_log
fill 340 114 597 340 117 597 minecraft:green_terracotta
setblock 341 114 557 minecraft:dirt
setblock 341 114 560 minecraft:oak_log
setblock 341 114 596 minecraft:green_terracotta
fill 342 114 557 357 172 557 minecraft:brown_terracotta
setblock 342 114 559 minecraft:oak_log
setblock 343 114 558 minecraft:oak_log
setblock 343 114 559 minecraft:green_terracotta
setblock 343 114 598 minecraft:oak_log
fill 344 114 558 344 115 558 minecraft:green_terracotta
fill 344 114 598 344 116 598 minecraft:green_terracotta
fill 346 114 558 346 115 558 minecraft:oak_leaves[persistent=true]
setblock 348 114 598 minecraft:oak_leaves[persistent=true]
fill 351 114 599 351 176 599 minecraft:brown_terracotta
setblock 352 114 558 minecraft:oak_leaves[persistent=true]
setblock 352 114 599 minecraft:dirt
fill 353 114 599 353 176 599 minecraft:brown_terracotta
setblock 357 114 559 minecraft:oak_log
fill 357 114 599 357 176 599 minecraft:brown_terracotta
setblock 358 114 557 minecraft:dirt
setblock 358 114 558 minecraft:oak_log
fill 358 114 559 358 117 559 minecraft:green_terracotta
setblock 358 114 598 minecraft:oak_log
setblock 358 114 599 minecraft:dirt
fill 359 114 557 362 172 557 minecraft:brown_terracotta
fill 359 114 558 359 117 558 minecraft:green_terracotta
fill 359 114 598 359 115 598 minecraft:green_terracotta
fill 359 114 599 363 172 599 minecraft:brown_terracotta
setblock 360 114 561 minecraft:oak_log
setblock 361 114 560 minecraft:oak_log
setblock 361 114 561 minecraft:green_terracotta
setblock 362 114 559 minecraft:oak_log
fill 362 114 560 362 116 560 minecraft:green_terracotta
setblock 363 114 557 minecraft:dirt
setblock 363 114 558 minecraft:oak_log
fill 363 114 559 363 116 559 minecraft:green_terracotta
setblock 363 114 561 minecraft:green_terracotta
fill 364 114 557 364 173 557 minecraft:brown_terracotta
fill 364 114 558 364 117 558 minecraft:green_terracotta
setblock 364 114 599 minecraft:dirt
fill 365 114 599 366 176 599 minecraft:brown_terracotta
fill 366 114 557 366 176 557 minecraft:brown_terracotta
setblock 366 114 560 minecraft:oak_log
setblock 367 114 557 minecraft:dirt
setblock 367 114 559 minecraft:oak_log
fill 368 114 557 371 172 557 minecraft:brown_terracotta
setblock 368 114 558 minecraft:oak_log
fill 368 114 559 368 115 559 minecraft:green_terracotta
setblock 368 114 562 minecraft:green_terracotta
setblock 368 114 563 minecraft:oak_log
fill 368 114 564 368 116 564 minecraft:green_terracotta
fill 369 114 558 369 116 558 minecraft:green_terracotta
setblock 369 114 562 minecraft:oak_log
fill 369 114 563 369 117 563 minecraft:green_terracotta
setblock 369 114 566 minecraft:green_terracotta
setblock 369 114 567 minecraft:oak_log
fill 369 114 568 369 117 568 minecraft:green_terracotta
setblock 370 114 561 minecraft:oak_log
fill 370 114 562 370 117 562 minecraft:green_terracotta
setblock 370 114 566 minecraft:oak_log
fill 370 114 567 370 117 567 minecraft:green_terracotta
setblock 370 114 571 minecraft:oak_log
setblock 370 114 586 minecraft:oak_log
fill 371 114 563 371 173 566 minecraft:brown_terracotta
setblock 371 114 567 minecraft:dirt
fill 371 114 568 371 172 571 minecraft:brown_terracotta
setblock 371 114 572 minecraft:dirt
fill 371 114 573 371 173 576 minecraft:brown_terracotta
fill 371 114 583 371 172 585 minecraft:brown_terracotta
setblock 371 114 586 minecraft:dirt
fill 371 114 587 371 172 597 minecraft:brown_terracotta
setblock 371 114 598 minecraft:dirt
fill 329 115 559 329 172 560 minecraft:brown_terracotta
fill 329 115 563 329 176 563 minecraft:brown_terracotta
fill 329 115 570 329 176 570 minecraft:brown_terracotta
fill 329 115 572 329 176 572 minecraft:brown_terracotta
fill 329 115 585 329 176 585 minecraft:brown_terracotta
fill 329 115 587 329 177 587 minecraft:brown_terracotta
fill 329 115 594 329 176 594 minecraft:brown_terracotta
setblock 330 115 560 minecraft:oak_log
fill 330 115 561 330 118 561 minecraft:green_terracotta
setblock 330 115 564 minecraft:green_terracotta
setblock 330 115 565 minecraft:oak_log
fill 330 115 566 331 116 566 minecraft:green_terracotta
setblock 330 115 578 minecraft:oak_leaves[persistent=true]
setblock 330 115 584 minecraft:green_terracotta
setblock 330 115 585 minecraft:oak_log
fill 330 115 586 330 115 589 minecraft:green_terracotta
setblock 330 115 590 minecraft:oak_log
fill 330 115 591 330 117 592 minecraft:green_terracotta
setblock 331 115 559 minecraft:oak_log
setblock 331 115 560 minecraft:green_terracotta
setblock 331 115 564 minecraft:oak_log
fill 331 115 565 331 117 565 minecraft:green_terracotta
setblock 332 115 558 minecraft:oak_log
setblock 332 115 559 minecraft:green_terracotta
setblock 332 115 598 minecraft:oak_log
fill 333 115 558 333 118 558 minecraft:green_terracotta
fill 333 115 598 333 118 598 minecraft:green_terracotta
fill 333 115 599 333 173 599 minecraft:brown_terracotta
fill 334 115 597 334 118 597 minecraft:green_terracotta
setblock 335 115 559 minecraft:green_terracotta
setblock 336 115 559 minecraft:oak_log
setblock 336 115 560 minecraft:green_terracotta
setblock 337 115 558 minecraft:oak_log
fill 337 115 559 337 117 559 minecraft:green_terracotta
setblock 337 115 598 minecraft:oak_log
fill 338 115 558 338 118 558 minecraft:green_terracotta
setblock 338 115 596 minecraft:green_terracotta
setblock 338 115 597 minecraft:oak_log
fill 338 115 598 338 118 598 minecraft:green_terracotta
setblock 339 115 596 minecraft:oak_log
fill 339 115 597 339 118 597 minecraft:green_terracotta
setblock 340 115 560 minecraft:oak_log
setblock 340 115 596 minecraft:green_terracotta
fill 341 115 557 341 176 557 minecraft:brown_terracotta
setblock 341 115 559 minecraft:oak_log
setblock 342 115 558 minecraft:oak_log
setblock 342 115 559 minecraft:green_terracotta
setblock 342 115 598 minecraft:oak_log
fill 343 115 558 343 116 558 minecraft:green_terracotta
setblock 343 115 597 minecraft:oak_log
fill 343 115 598 343 117 598 minecraft:green_terracotta
fill 352 115 599 352 174 599 minecraft:brown_terracotta
setblock 354 115 598 minecraft:oak_leaves[persistent=true]
fill 354 115 599 354 176 599 minecraft:brown_terracotta
setblock 357 115 558 minecraft:oak_log
fill 357 115 559 357 116 559 minecraft:green_terracotta
fill 358 115 557 358 176 557 minecraft:brown_terracotta
fill 358 115 558 358 118 558 minecraft:green_terracotta
fill 358 115 599 358 172 599 minecraft:brown_terracotta
setblock 360 115 560 minecraft:oak_log
setblock 361 115 559 minecraft:oak_log
fill 361 115 560 361 116 560 minecraft:green_terracotta
setblock 362 115 558 minecraft:oak_log
fill 362 115 559 362 117 559 minecraft:green_terracotta
fill 363 115 557 363 172 557 minecraft:brown_terracotta
fill 363 115 558 363 118 558 minecraft:green_terracotta
fill 364 115 599 364 176 599 minecraft:brown_terracotta
fill 365 115 557 365 176 557 minecraft:brown_terracotta
setblock 366 115 559 minecraft:oak_log
fill 367 115 557 367 176 557 minecraft:brown_terracotta
setblock 367 115 558 minecraft:oak_log
setblock 367 115 559 minecraft:green_terracotta
fill 368 115 558 368 116 558 minecraft:green_terracotta
setblock 368 115 562 minecraft:oak_log
setblock 368 115 563 minecraft:green_terracotta
setblock 369 115 561 minecraft:oak_log
fill 369 115 562 369 117 562 minecraft:green_terracotta
setblock 369 115 566 minecraft:oak_log
fill 369 115 567 369 118 567 minecraft:green_terracotta
fill 369 115 569 370 115 569 minecraft:green_terracotta
setblock 370 115 560 minecraft:oak_log
fill 370 115 561 370 118 561 minecraft:green_terracotta
setblock 370 115 565 minecraft:oak_log
fill 370 115 566 370 118 566 minecraft:green_terracotta
setblock 370 115 570 minecraft:oak_log
fill 370 115 571 370 118 571 minecraft:green_terracotta
fill 370 115 572 370 116 572 minecraft:oak_leaves[persistent=true]
setblock 370 115 578 minecraft:oak_leaves[persistent=true]
setblock 370 115 585 minecraft:oak_log
setblock 370 115 586 minecraft:green_terracotta
setblock 370 115 597 minecraft:oak_leaves[persistent=true]
fill 371 115 567 371 176 567 minecraft:brown_terracotta
fill 371 115 572 371 173 572 minecraft:brown_terracotta
fill 371 115 586 371 176 586 minecraft:brown_terracotta
fill 371 115 598 371 176 598 minecraft:brown_terracotta
setblock 330 116 558 minecraft:green_terracotta
setblock 330 116 559 minecraft:oak_log
fill 330 116 560 330 118 560 minecraft:green_terracotta
setblock 330 116 564 minecraft:oak_log
fill 330 116 565 330 119 565 minecraft:green_terracotta
setblock 330 116 584 minecraft:oak_log
fill 330 116 585 330 116 588 minecraft:green_terracotta
setblock 330 116 589 minecraft:oak_log
fill 330 116 590 330 119 590 minecraft:green_terracotta
setblock 330 116 593 minecraft:green_terracotta
setblock 331 116 558 minecraft:oak_log
setblock 331 116 563 minecraft:oak_log
fill 331 116 564 331 117 564 minecraft:green_terracotta
setblock 331 116 587 minecraft:green_terracotta
setblock 331 116 588 minecraft:oak_log
fill 331 116 589 331 119 589 minecraft:green_terracotta
setblock 331 116 598 minecraft:oak_log
fill 332 116 558 332 118 558 minecraft:green_terracotta
fill 332 116 598 332 119 598 minecraft:green_terracotta
setblock 335 116 559 minecraft:oak_log
setblock 336 116 558 minecraft:oak_log
fill 336 116 559 336 117 559 minecraft:green_terracotta
setblock 336 116 598 minecraft:oak_log
fill 337 116 558 337 119 558 minecraft:green_terracotta
setblock 337 116 596 minecraft:green_terracotta
setblock 337 116 597 minecraft:oak_log
fill 337 116 598 337 119 598 minecraft:green_terracotta
setblock 338 116 596 minecraft:oak_log
fill 338 116 597 338 119 597 minecraft:green_terracotta
setblock 339 116 596 minecraft:green_terracotta
setblock 340 116 559 minecraft:oak_log
setblock 341 116 558 minecraft:oak_log
setblock 341 116 559 minecraft:green_terracotta
setblock 341 116 598 minecraft:oak_log
setblock 342 116 558 minecraft:green_terracotta
setblock 342 116 597 minecraft:oak_log
fill 342 116 598 342 118 598 minecraft:green_terracotta
setblock 356 116 558 minecraft:oak_log
fill 357 116 558 357 119 558 minecraft:green_terracotta
setblock 359 116 560 minecraft:oak_log
setblock 360 116 559 minecraft:oak_log
setblock 360 116 560 minecraft:green_terracotta
setblock 360 116 598 minecraft:oak_leaves[persistent=true]
setblock 361 116 558 minecraft:oak_log
fill 361 116 559 361 117 559 minecraft:green_terracotta
fill 362 116 558 362 118 558 minecraft:green_terracotta
setblock 365 116 559 minecraft:oak_log
setblock 366 116 558 minecraft:oak_log
fill 366 116 598 366 117 598 minecraft:oak_leaves[persistent=true]
setblock 367 116 558 minecraft:green_terracotta
setblock 368 116 565 minecraft:green_terracotta
setblock 368 116 566 minecraft:oak_log
setblock 369 116 560 minecraft:oak_log
fill 369 116 561 369 117 561 minecraft:green_terracotta
setblock 369 116 565 minecraft:oak_log
fill 369 116 566 369 119 566 minecraft:green_terracotta
setblock 369 116 569 minecraft:green_terracotta
setblock 370 116 559 minecraft:oak_log
fill 370 116 560 370 119 560 minecraft:green_terracotta
setblock 370 116 564 minecraft:oak_log
fill 370 116 565 370 119 565 minecraft:green_terracotta
setblock 370 116 569 minecraft:oak_log
fill 370 116 570 370 119 570 minecraft:green_terracotta
setblock 370 116 591 minecraft:oak_leaves[persistent=true]
setblock 330 117 558 minecraft:oak_log
setblock 330 117 559 minecraft:green_terracotta
setblock 330 117 563 minecraft:oak_log
fill 330 117 564 330 120 564 minecraft:green_terracotta
fill 330 117 566 330 117 567 minecraft:green_terracotta
setblock 330 117 568 minecraft:oak_log
setblock 330 117 571 minecraft:oak_leaves[persistent=true]
fill 330 117 585 330 117 587 minecraft:green_terracotta
setblock 330 117 588 minecraft:oak_log
fill 330 117 589 330 120 589 minecraft:green_terracotta
setblock 330 117 593 minecraft:oak_log
fill 330 117 594 330 120 594 minecraft:green_terracotta
fill 330 117 596 330 118 596 minecraft:oak_leaves[persistent=true]
setblock 331 117 558 minecraft:green_terracotta
setblock 331 117 563 minecraft:green_terracotta
setblock 331 117 587 minecraft:oak_log
fill 331 117 588 331 120 588 minecraft:green_terracotta
fill 331 117 590 331 117 591 minecraft:green_terracotta
fill 331 117 598 331 120 598 minecraft:green_terracotta
setblock 334 117 559 minecraft:oak_log
setblock 335 117 558 minecraft:oak_log
setblock 335 117 559 minecraft:green_terracotta
setblock 335 117 598 minecraft:oak_log
fill 336 117 558 336 120 558 minecraft:green_terracotta
setblock 336 117 597 minecraft:oak_log
fill 336 117 598 336 120 598 minecraft:green_terracotta
setblock 337 117 596 minecraft:oak_log
fill 337 117 597 337 120 597 minecraft:green_terracotta
setblock 338 117 596 minecraft:green_terracotta
setblock 339 117 559 minecraft:oak_log
setblock 340 117 558 minecraft:oak_log
setblock 340 117 598 minecraft:oak_log
setblock 341 117 558 minecraft:green_terracotta
setblock 341 117 597 minecraft:oak_log
fill 341 117 598 341 119 598 minecraft:green_terracotta
setblock 347 117 598 minecraft:oak_leaves[persistent=true]
setblock 353 117 558 minecraft:oak_leaves[persistent=true]
fill 356 117 558 356 118 558 minecraft:green_terracotta
setblock 359 117 559 minecraft:oak_log
setblock 360 117 558 minecraft:oak_log
setblock 360 117 559 minecraft:green_terracotta
fill 361 117 558 361 119 558 minecraft:green_terracotta
setblock 365 117 558 minecraft:oak_log
setblock 366 117 558 minecraft:green_terracotta
setblock 369 117 564 minecraft:oak_log
fill 369 117 565 369 119 565 minecraft:green_terracotta
setblock 369 117 569 minecraft:oak_log
setblock 370 117 558 minecraft:oak_log
fill 370 117 559 370 118 559 minecraft:green_terracotta
setblock 370 117 563 minecraft:oak_log
fill 370 117 564 370 120 564 minecraft:green_terracotta
setblock 370 117 568 minecraft:oak_log
fill 370 117 569 370 120 569 minecraft:green_terracotta
setblock 370 117 585 minecraft:oak_leaves[persistent=true]
fill 330 118 558 330 119 558 minecraft:oak_leaves[persistent=true]
setblock 330 118 562 minecraft:oak_log
fill 330 118 563 330 119 563 minecraft:green_terracotta
setblock 330 118 566 minecraft:green_terracotta
setblock 330 118 567 minecraft:oak_log
fill 330 118 568 330 121 568 minecraft:green_terracotta
setblock 330 118 577 minecraft:oak_leaves[persistent=true]
fill 330 118 585 330 118 586 minecraft:green_terracotta
setblock 330 118 587 minecraft:oak_log
fill 330 118 588 330 121 588 minecraft:green_terracotta
setblock 330 118 591 minecraft:green_terracotta
setblock 330 118 592 minecraft:oak_log
fill 330 118 593 330 121 593 minecraft:green_terracotta
fill 330 118 595 330 119 595 minecraft:green_terracotta
fill 331 118 587 331 119 587 minecraft:green_terracotta
setblock 331 118 590 minecraft:green_terracotta
setblock 331 118 591 minecraft:oak_log
fill 331 118 592 331 121 592 minecraft:green_terracotta
setblock 334 118 558 minecraft:oak_log
setblock 334 118 598 minecraft:oak_log
fill 335 118 558 335 120 558 minecraft:green_terracotta
setblock 335 118 597 minecraft:oak_log
fill 335 118 598 335 121 598 minecraft:green_terracotta
fill 336 118 597 336 121 597 minecraft:green_terracotta
setblock 339 118 558 minecraft:oak_log
setblock 339 118 598 minecraft:oak_log
setblock 340 118 558 minecraft:green_terracotta
setblock 340 118 597 minecraft:oak_log
fill 340 118 598 340 121 598 minecraft:green_terracotta
setblock 347 118 558 minecraft:oak_leaves[persistent=true]
setblock 353 118 598 minecraft:oak_leaves[persistent=true]
setblock 359 118 558 minecraft:oak_log
fill 360 118 558 360 119 558 minecraft:green_terracotta
setblock 366 118 558 minecraft:oak_leaves[persistent=true]
setblock 369 118 563 minecraft:oak_log
fill 369 118 564 369 119 564 minecraft:green_terracotta
setblock 369 118 568 minecraft:oak_log
setblock 370 118 562 minecraft:oak_log
fill 370 118 563 370 121 563 minecraft:green_terracotta
setblock 370 118 567 minecraft:oak_log
fill 370 118 568 370 121 568 minecraft:green_terracotta
setblock 370 118 579 minecraft:oak_leaves[persistent=true]
setblock 330 119 562 minecraft:green_terracotta
setblock 330 119 566 minecraft:oak_log
fill 330 119 567 330 122 567 minecraft:green_terracotta
setblock 330 119 583 minecraft:oak_leaves[persistent=true]
setblock 330 119 586 minecraft:oak_log
fill 330 119 587 330 122 587 minecraft:green_terracotta
setblock 330 119 591 minecraft:oak_log
fill 330 119 592 330 122 592 minecraft:green_terracotta
setblock 330 119 596 minecraft:oak_log
setblock 331 119 590 minecraft:oak_log
fill 331 119 591 331 122 591 minecraft:green_terracotta
fill 331 119 593 331 120 593 minecraft:green_terracotta
setblock 333 119 558 minecraft:oak_log
setblock 333 119 598 minecraft:oak_log
fill 334 119 558 334 120 558 minecraft:green_terracotta
setblock 334 119 597 minecraft:oak_log
fill 334 119 598 334 122 598 minecraft:green_terracotta
fill 335 119 597 335 122 597 minecraft:green_terracotta
setblock 338 119 558 minecraft:oak_log
setblock 338 119 598 minecraft:oak_log
setblock 339 119 597 minecraft:oak_log
fill 339 119 598 339 122 598 minecraft:green_terracotta
setblock 341 119 558 minecraft:oak_leaves[persistent=true]
fill 341 119 583 341 120 583 minecraft:glowstone
setblock 358 119 558 minecraft:oak_log
setblock 359 119 558 minecraft:green_terracotta
setblock 359 119 598 minecraft:oak_leaves[persistent=true]
setblock 369 119 567 minecraft:oak_log
setblock 369 119 568 minecraft:green_terracotta
setblock 370 119 561 minecraft:oak_log
fill 370 119 562 370 122 562 minecraft:green_terracotta
setblock 370 119 566 minecraft:oak_log
fill 370 119 567 370 122 567 minecraft:green_terracotta
setblock 370 119 571 minecraft:oak_log
setblock 370 119 573 minecraft:oak_leaves[persistent=true]
setblock 370 119 592 minecraft:oak_leaves[persistent=true]
setblock 330 120 565 minecraft:oak_log
fill 330 120 566 330 121 566 minecraft:green_terracotta
setblock 330 120 570 minecraft:oak_leaves[persistent=true]
fill 330 120 586 330 123 586 minecraft:green_terracotta
setblock 330 120 590 minecraft:oak_log
fill 330 120 591 330 123 591 minecraft:green_terracotta
setblock 330 120 595 minecraft:oak_log
fill 330 120 596 330 122 597 minecraft:green_terracotta
setblock 331 120 589 minecraft:oak_log
fill 331 120 590 332 122 590 minecraft:green_terracotta
setblock 331 120 594 minecraft:oak_log
setblock 332 120 560 minecraft:light[level=14]
setblock 332 120 568 minecraft:light[level=14]
setblock 332 120 576 minecraft:light[level=14]
setblock 332 120 584 minecraft:light[level=14]
fill 332 120 591 332 120 592 minecraft:green_terracotta
setblock 332 120 598 minecraft:oak_log
setblock 333 120 597 minecraft:oak_log
fill 333 120 598 333 123 598 minecraft:green_terracotta
fill 334 120 597 334 123 597 minecraft:green_terracotta
setblock 337 120 598 minecraft:oak_log
setblock 338 120 597 minecraft:oak_log
fill 338 120 598 338 123 598 minecraft:green_terracotta
setblock 339 120 597 minecraft:green_terracotta
setblock 340 120 560 minecraft:light[level=14]
setblock 340 120 568 minecraft:light[level=14]
setblock 340 120 576 minecraft:light[level=14]
setblock 340 120 584 minecraft:light[level=14]
setblock 340 120 592 minecraft:light[level=14]
setblock 346 120 598 minecraft:oak_leaves[persistent=true]
setblock 348 120 560 minecraft:light[level=14]
setblock 348 120 568 minecraft:light[level=14]
setblock 348 120 576 minecraft:light[level=14]
setblock 348 120 584 minecraft:light[level=14]
setblock 348 120 592 minecraft:light[level=14]
setblock 354 120 558 minecraft:oak_leaves[persistent=true]
setblock 356 120 560 minecraft:light[level=14]
setblock 356 120 568 minecraft:light[level=14]
setblock 356 120 576 minecraft:light[level=14]
setblock 356 120 584 minecraft:light[level=14]
setblock 356 120 592 minecraft:light[level=14]
setblock 364 120 560 minecraft:light[level=14]
setblock 364 120 568 minecraft:light[level=14]
setblock 364 120 576 minecraft:light[level=14]
setblock 364 120 584 minecraft:light[level=14]
setblock 364 120 592 minecraft:light[level=14]
setblock 365 120 598 minecraft:oak_leaves[persistent=true]
setblock 369 120 566 minecraft:oak_log
setblock 369 120 567 minecraft:green_terracotta
setblock 370 120 561 minecraft:green_terracotta
setblock 370 120 565 minecraft:oak_log
fill 370 120 566 370 123 566 minecraft:green_terracotta
setblock 370 120 570 minecraft:oak_log
fill 370 120 571 370 123 571 minecraft:green_terracotta
setblock 370 120 586 minecraft:oak_leaves[persistent=true]
setblock 330 121 576 minecraft:oak_leaves[persistent=true]
setblock 330 121 589 minecraft:oak_log
fill 330 121 590 330 124 590 minecraft:green_terracotta
setblock 330 121 594 minecraft:oak_log
fill 330 121 595 331 123 595 minecraft:green_terracotta
setblock 330 121 598 minecraft:green_terracotta
setblock 331 121 588 minecraft:oak_log
fill 331 121 589 332 123 589 minecraft:green_terracotta
setblock 331 121 593 minecraft:oak_log
fill 331 121 594 331 124 594 minecraft:green_terracotta
fill 331 121 596 331 122 596 minecraft:green_terracotta
setblock 331 121 598 minecraft:oak_log
setblock 332 121 591 minecraft:green_terracotta
setblock 332 121 592 minecraft:oak_log
fill 332 121 593 332 124 593 minecraft:green_terracotta
setblock 332 121 597 minecraft:oak_log
fill 332 121 598 332 124 598 minecraft:green_terracotta
fill 333 121 597 333 124 597 minecraft:green_terracotta
fill 335 121 596 336 122 596 minecraft:green_terracotta
setblock 336 121 598 minecraft:oak_log
setblock 337 121 597 minecraft:oak_log
fill 337 121 598 337 124 598 minecraft:green_terracotta
fill 338 121 597 338 124 597 minecraft:green_terracotta
setblock 348 121 558 minecraft:oak_leaves[persistent=true]
setblock 352 121 598 minecraft:oak_leaves[persistent=true]
setblock 370 121 561 minecraft:oak_leaves[persistent=true]
setblock 370 121 564 minecraft:oak_log
fill 370 121 565 370 124 565 minecraft:green_terracotta
setblock 370 121 569 minecraft:oak_log
fill 370 121 570 370 124 570 minecraft:green_terracotta
setblock 370 121 580 minecraft:oak_leaves[persistent=true]
fill 370 121 590 370 121 593 minecraft:green_terracotta
setblock 330 122 568 minecraft:oak_log
fill 330 122 569 330 124 570 minecraft:green_terracotta
setblock 330 122 582 minecraft:oak_leaves[persistent=true]
setblock 330 122 588 minecraft:oak_log
fill 330 122 589 330 125 589 minecraft:green_terracotta
setblock 330 122 593 minecraft:oak_log
fill 330 122 594 330 125 594 minecraft:green_terracotta
setblock 330 122 598 minecraft:oak_log
setblock 331 122 587 minecraft:oak_log
fill 331 122 588 331 125 588 minecraft:green_terracotta
setblock 331 122 592 minecraft:oak_log
fill 331 122 593 331 125 593 minecraft:green_terracotta
setblock 331 122 597 minecraft:oak_log
fill 331 122 598 331 125 598 minecraft:green_terracotta
setblock 332 122 591 minecraft:oak_log
fill 332 122 592 332 125 592 minecraft:green_terracotta
fill 332 122 594 332 122 595 minecraft:green_terracotta
fill 332 122 597 332 125 597 minecraft:green_terracotta
fill 333 122 596 334 124 596 minecraft:green_terracotta
setblock 335 122 598 minecraft:oak_log
setblock 336 122 597 minecraft:oak_log
fill 336 122 598 336 125 598 minecraft:green_terracotta
fill 337 122 597 337 125 597 minecraft:green_terracotta
setblock 342 122 558 minecraft:oak_leaves[persistent=true]
setblock 358 122 598 minecraft:oak_leaves[persistent=true]
setblock 367 122 558 minecraft:oak_leaves[persistent=true]
setblock 370 122 563 minecraft:oak_log
fill 370 122 564 370 125 564 minecraft:green_terracotta
setblock 370 122 568 minecraft:oak_log
fill 370 122 569 370 125 569 minecraft:green_terracotta
setblock 370 122 572 minecraft:green_terracotta
setblock 370 122 574 minecraft:oak_leaves[persistent=true]
fill 370 122 589 370 122 592 minecraft:green_terracotta
setblock 370 122 593 minecraft:oak_log
fill 370 122 594 370 123 596 minecraft:green_terracotta
setblock 330 123 563 minecraft:oak_leaves[persistent=true]
setblock 330 123 567 minecraft:oak_log
fill 330 123 568 330 126 568 minecraft:green_terracotta
setblock 330 123 571 minecraft:green_terracotta
setblock 330 123 572 minecraft:oak_log
setblock 330 123 587 minecraft:oak_log
fill 330 123 588 330 126 588 minecraft:green_terracotta
setblock 330 123 592 minecraft:oak_log
fill 330 123 593 330 126 593 minecraft:green_terracotta
setblock 330 123 596 minecraft:green_terracotta
setblock 330 123 597 minecraft:oak_log
fill 330 123 598 330 126 598 minecraft:green_terracotta
fill 331 123 587 331 126 587 minecraft:green_terracotta
setblock 331 123 590 minecraft:green_terracotta
setblock 331 123 591 minecraft:oak_log
fill 331 123 592 331 126 592 minecraft:green_terracotta
setblock 331 123 596 minecraft:oak_log
fill 331 123 597 331 126 597 minecraft:green_terracotta
fill 332 123 588 332 124 588 minecraft:green_terracotta
setblock 332 123 590 minecraft:oak_log
fill 332 123 591 333 125 591 minecraft:green_terracotta
setblock 332 123 594 minecraft:green_terracotta
setblock 332 123 595 minecraft:oak_log
fill 332 123 596 332 126 596 minecraft:green_terracotta
setblock 333 123 558 minecraft:green_terracotta
fill 333 123 592 333 123 593 minecraft:green_terracotta
setblock 333 123 594 minecraft:oak_log
setblock 334 123 558 minecraft:oak_log
setblock 334 123 598 minecraft:oak_log
setblock 335 123 596 minecraft:green_terracotta
setblock 335 123 597 minecraft:oak_log
fill 335 123 598 335 126 598 minecraft:green_terracotta
setblock 336 123 558 minecraft:oak_leaves[persistent=true]
setblock 336 123 596 minecraft:oak_log
fill 336 123 597 336 126 597 minecraft:green_terracotta
fill 337 123 596 337 126 596 minecraft:green_terracotta
setblock 339 123 598 minecraft:oak_log
fill 340 123 598 340 126 598 minecraft:green_terracotta
fill 356 123 558 357 124 558 minecraft:green_terracotta
setblock 361 123 558 minecraft:oak_leaves[persistent=true]
setblock 364 123 598 minecraft:oak_leaves[persistent=true]
fill 370 123 558 370 126 558 minecraft:green_terracotta
setblock 370 123 561 minecraft:green_terracotta
setblock 370 123 562 minecraft:oak_log
fill 370 123 563 370 126 563 minecraft:green_terracotta
setblock 370 123 567 minecraft:oak_log
fill 370 123 568 370 126 568 minecraft:green_terracotta
setblock 370 123 572 minecraft:oak_log
fill 370 123 573 370 126 573 minecraft:green_terracotta
fill 370 123 589 370 123 591 minecraft:green_terracotta
setblock 370 123 592 minecraft:oak_log
fill 370 123 593 370 126 593 minecraft:green_terracotta
setblock 370 123 597 minecraft:oak_log
fill 370 123 598 370 126 598 minecraft:green_terracotta
setblock 330 124 566 minecraft:oak_log
fill 330 124 567 330 127 567 minecraft:green_terracotta
setblock 330 124 571 minecraft:oak_log
fill 330 124 572 330 125 574 minecraft:green_terracotta
setblock 330 124 585 minecraft:green_terracotta
setblock 330 124 586 minecraft:oak_log
fill 330 124 587 330 127 587 minecraft:green_terracotta
setblock 330 124 591 minecraft:oak_log
fill 330 124 592 330 127 592 minecraft:green_terracotta
setblock 330 124 595 minecraft:green_terracotta
setblock 330 124 596 minecraft:oak_log
fill 330 124 597 330 127 597 minecraft:green_terracotta
fill 331 124 558 332 124 558 minecraft:green_terracotta
setblock 331 124 589 minecraft:green_terracotta
setblock 331 124 590 minecraft:oak_log
fill 331 124 591 331 127 591 minecraft:green_terracotta
setblock 331 124 595 minecraft:oak_log
fill 331 124 596 331 127 596 minecraft:green_terracotta
setblock 332 124 589 minecraft:oak_log
fill 332 124 590 333 126 590 minecraft:green_terracotta
setblock 332 124 594 minecraft:oak_log
fill 332 124 595 335 124 595 minecraft:green_terracotta
setblock 333 124 558 minecraft:oak_log
fill 333 124 569 335 125 570 minecraft:glowstone
setblock 333 124 592 minecraft:green_terracotta
setblock 333 124 593 minecraft:oak_log
fill 333 124 594 333 127 594 minecraft:green_terracotta
setblock 333 124 598 minecraft:oak_log
fill 334 124 558 335 126 558 minecraft:green_terracotta
setblock 334 124 597 minecraft:oak_log
fill 334 124 598 334 127 598 minecraft:green_terracotta
setblock 335 124 596 minecraft:oak_log
fill 335 124 597 335 127 597 minecraft:green_terracotta
fill 336 124 596 336 127 596 minecraft:green_terracotta
setblock 338 124 598 minecraft:oak_log
setblock 339 124 597 minecraft:oak_log
fill 339 124 598 339 127 598 minecraft:green_terracotta
setblock 345 124 598 minecraft:oak_leaves[persistent=true]
fill 349 124 558 349 125 558 minecraft:oak_leaves[persistent=true]
setblock 353 124 598 minecraft:oak_log
fill 354 124 558 355 126 558 minecraft:green_terracotta
fill 354 124 598 357 124 598 minecraft:green_terracotta
setblock 358 124 558 minecraft:oak_log
setblock 368 124 598 minecraft:oak_log
fill 369 124 558 369 127 558 minecraft:green_terracotta
fill 369 124 568 369 125 570 minecraft:green_terracotta
fill 369 124 593 369 125 595 minecraft:green_terracotta
fill 369 124 598 369 127 598 minecraft:green_terracotta
fill 370 124 559 370 124 560 minecraft:green_terracotta
setblock 370 124 561 minecraft:oak_log
fill 370 124 562 370 127 562 minecraft:green_terracotta
setblock 370 124 566 minecraft:oak_log
fill 370 124 567 370 127 567 minecraft:green_terracotta
setblock 370 124 571 minecraft:oak_log
fill 370 124 572 370 127 572 minecraft:green_terracotta
fill 370 124 574 370 125 574 minecraft:green_terracotta
setblock 370 124 587 minecraft:oak_leaves[persistent=true]
fill 370 124 588 370 124 590 minecraft:green_terracotta
setblock 370 124 591 minecraft:oak_log
fill 370 124 592 370 127 592 minecraft:green_terracotta
fill 370 124 594 370 124 595 minecraft:green_terracotta
setblock 370 124 596 minecraft:oak_log
fill 370 124 597 370 127 597 minecraft:green_terracotta
fill 330 125 558 330 125 559 minecraft:green_terracotta
fill 330 125 566 330 128 566 minecraft:green_terracotta
setblock 330 125 569 minecraft:green_terracotta
setblock 330 125 570 minecraft:oak_log
fill 330 125 571 331 127 571 minecraft:green_terracotta
setblock 330 125 575 minecraft:oak_log
fill 330 125 576 330 127 577 minecraft:green_terracotta
setblock 330 125 584 minecraft:green_terracotta
setblock 330 125 585 minecraft:oak_log
fill 330 125 586 331 127 586 minecraft:green_terracotta
setblock 330 125 590 minecraft:oak_log
fill 330 125 591 330 128 591 minecraft:green_terracotta
setblock 330 125 595 minecraft:oak_log
fill 330 125 596 330 128 596 minecraft:green_terracotta
setblock 331 125 558 minecraft:green_terracotta
setblock 331 125 569 minecraft:oak_log
fill 331 125 570 331 128 570 minecraft:green_terracotta
fill 331 125 572 331 125 573 minecraft:green_terracotta
setblock 331 125 574 minecraft:oak_log
setblock 331 125 589 minecraft:oak_log
fill 331 125 590 331 128 590 minecraft:green_terracotta
setblock 331 125 594 minecraft:oak_log
fill 331 125 595 334 125 595 minecraft:green_terracotta
setblock 332 125 558 minecraft:oak_log
setblock 332 125 588 minecraft:oak_log
fill 332 125 589 333 127 589 minecraft:green_terracotta
setblock 332 125 593 minecraft:oak_log
fill 332 125 594 332 128 594 minecraft:green_terracotta
setblock 332 125 598 minecraft:oak_log
fill 333 125 558 333 128 558 minecraft:green_terracotta
setblock 333 125 592 minecraft:oak_log
fill 333 125 593 333 128 593 minecraft:green_terracotta
setblock 333 125 596 minecraft:green_terracotta
setblock 333 125 597 minecraft:oak_log
fill 333 125 598 333 128 598 minecraft:green_terracotta
setblock 334 125 596 minecraft:oak_log
fill 334 125 597 334 128 597 minecraft:green_terracotta
setblock 335 125 595 minecraft:oak_log
fill 335 125 596 335 128 596 minecraft:green_terracotta
fill 336 125 595 336 128 595 minecraft:green_terracotta
setblock 337 125 598 minecraft:oak_log
setblock 338 125 596 minecraft:green_terracotta
setblock 338 125 597 minecraft:oak_log
fill 338 125 598 338 128 598 minecraft:green_terracotta
fill 339 125 597 339 128 597 minecraft:green_terracotta
setblock 343 125 558 minecraft:oak_leaves[persistent=true]
setblock 351 125 598 minecraft:green_terracotta
setblock 352 125 558 minecraft:oak_log
setblock 352 125 598 minecraft:oak_log
fill 353 125 558 353 128 558 minecraft:green_terracotta
fill 353 125 598 356 125 598 minecraft:green_terracotta
fill 354 125 597 355 127 597 minecraft:green_terracotta
setblock 356 125 558 minecraft:green_terracotta
setblock 357 125 558 minecraft:oak_log
setblock 357 125 598 minecraft:oak_log
fill 358 125 558 360 126 558 minecraft:green_terracotta
fill 358 125 598 359 127 598 minecraft:green_terracotta
setblock 366 125 598 minecraft:green_terracotta
setblock 367 125 558 minecraft:oak_log
setblock 367 125 598 minecraft:oak_log
fill 368 125 558 368 128 558 minecraft:green_terracotta
setblock 368 125 597 minecraft:oak_log
fill 368 125 598 368 128 598 minecraft:green_terracotta
fill 369 125 567 369 128 567 minecraft:green_terracotta
setblock 369 125 571 minecraft:oak_log
fill 369 125 572 369 128 572 minecraft:green_terracotta
setblock 369 125 591 minecraft:oak_log
fill 369 125 592 369 128 592 minecraft:green_terracotta
setblock 369 125 596 minecraft:oak_log
fill 369 125 597 369 128 597 minecraft:green_terracotta
setblock 370 125 559 minecraft:green_terracotta
setblock 370 125 560 minecraft:oak_log
fill 370 125 561 370 128 561 minecraft:green_terracotta
setblock 370 125 565 minecraft:oak_log
fill 370 125 566 370 128 566 minecraft:green_terracotta
setblock 370 125 570 minecraft:oak_log
fill 370 125 571 370 128 571 minecraft:green_terracotta
setblock 370 125 575 minecraft:oak_log
fill 370 125 576 370 128 576 minecraft:green_terracotta
setblock 370 125 581 minecraft:oak_leaves[persistent=true]
fill 370 125 588 370 125 589 minecraft:green_terracotta
setblock 370 125 590 minecraft:oak_log
fill 370 125 591 370 128 591 minecraft:green_terracotta
setblock 370 125 594 minecraft:green_terracotta
setblock 370 125 595 minecraft:oak_log
fill 370 125 596 370 128 596 minecraft:green_terracotta
setblock 330 126 558 minecraft:green_terracotta
setblock 330 126 559 minecraft:oak_log
fill 330 126 560 330 129 560 minecraft:green_terracotta
setblock 330 126 562 minecraft:oak_leaves[persistent=true]
fill 330 126 565 330 129 565 minecraft:green_terracotta
setblock 330 126 569 minecraft:oak_log
fill 330 126 570 330 129 570 minecraft:green_terracotta
fill 330 126 572 330 126 573 minecraft:green_terracotta
setblock 330 126 574 minecraft:oak_log
fill 330 126 575 331 128 575 minecraft:green_terracotta
setblock 330 126 578 minecraft:green_terracotta
setblock 330 126 579 minecraft:oak_log
fill 330 126 580 330 126 583 minecraft:green_terracotta
setblock 330 126 584 minecraft:oak_log
fill 330 126 585 331 128 585 minecraft:green_terracotta
setblock 330 126 589 minecraft:oak_log
fill 330 126 590 330 129 590 minecraft:green_terracotta
setblock 330 126 594 minecraft:oak_log
fill 330 126 595 333 126 595 minecraft:green_terracotta
setblock 331 126 558 minecraft:oak_log
fill 331 126 569 331 129 569 minecraft:green_terracotta
setblock 331 126 572 minecraft:green_terracotta
setblock 331 126 573 minecraft:oak_log
fill 331 126 574 331 129 574 minecraft:green_terracotta
fill 331 126 576 331 126 577 minecraft:green_terracotta
setblock 331 126 588 minecraft:oak_log
fill 331 126 589 331 129 589 minecraft:green_terracotta
setblock 331 126 593 minecraft:oak_log
fill 331 126 594 331 129 594 minecraft:green_terracotta
setblock 331 126 598 minecraft:oak_log
fill 332 126 558 332 129 558 minecraft:green_terracotta
setblock 332 126 587 minecraft:oak_log
fill 332 126 588 332 129 588 minecraft:green_terracotta
setblock 332 126 591 minecraft:green_terracotta
setblock 332 126 592 minecraft:oak_log
fill 332 126 593 332 129 593 minecraft:green_terracotta
setblock 332 126 597 minecraft:oak_log
fill 332 126 598 332 129 598 minecraft:green_terracotta
schedule function dropper:buildpart/139_3 1t
