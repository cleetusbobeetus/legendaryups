fill 115 241 277 116 241 277 minecraft:red_terracotta
fill 115 241 279 116 241 279 minecraft:red_terracotta
setblock 116 241 278 minecraft:red_terracotta
fill 94 242 275 94 243 276 minecraft:white_concrete
fill 94 242 277 94 243 278 minecraft:red_concrete
fill 94 242 279 94 243 279 minecraft:white_concrete
fill 94 242 280 94 247 280 minecraft:shroomlight
fill 94 242 281 94 243 282 minecraft:red_concrete
fill 94 242 283 94 243 284 minecraft:white_concrete
fill 94 242 285 94 243 286 minecraft:red_concrete
fill 94 242 287 94 243 287 minecraft:white_concrete
fill 94 242 288 94 247 288 minecraft:shroomlight
fill 94 242 289 94 243 290 minecraft:red_concrete
fill 94 242 291 94 243 292 minecraft:white_concrete
fill 94 242 293 94 243 294 minecraft:red_concrete
fill 94 242 295 94 243 295 minecraft:white_concrete
fill 94 242 296 94 247 296 minecraft:shroomlight
fill 94 242 297 94 243 298 minecraft:red_concrete
fill 94 242 299 94 243 300 minecraft:white_concrete
fill 94 242 301 94 243 302 minecraft:red_concrete
fill 94 242 303 94 243 303 minecraft:white_concrete
fill 94 242 304 94 247 304 minecraft:shroomlight
fill 94 242 305 94 243 306 minecraft:red_concrete
fill 94 242 307 94 243 308 minecraft:white_concrete
fill 94 242 309 94 243 310 minecraft:red_concrete
fill 94 242 311 94 243 311 minecraft:white_concrete
fill 94 242 312 94 247 312 minecraft:shroomlight
fill 94 242 313 94 243 314 minecraft:red_concrete
fill 94 242 315 94 243 316 minecraft:white_concrete
fill 95 242 275 95 243 275 minecraft:white_concrete
fill 95 242 317 95 243 317 minecraft:white_concrete
fill 96 242 275 97 243 275 minecraft:red_concrete
fill 96 242 317 96 243 317 minecraft:red_concrete
fill 97 242 317 97 247 317 minecraft:shroomlight
fill 98 242 275 99 243 275 minecraft:white_concrete
fill 98 242 317 99 243 317 minecraft:white_concrete
fill 100 242 275 100 243 275 minecraft:red_concrete
fill 100 242 317 101 243 317 minecraft:red_concrete
fill 101 242 275 101 247 275 minecraft:shroomlight
fill 102 242 275 103 243 275 minecraft:white_concrete
fill 102 242 317 103 243 317 minecraft:white_concrete
fill 104 242 275 105 243 275 minecraft:red_concrete
fill 104 242 317 104 243 317 minecraft:red_concrete
fill 105 242 317 105 247 317 minecraft:shroomlight
fill 106 242 275 107 243 275 minecraft:white_concrete
fill 106 242 317 107 243 317 minecraft:white_concrete
fill 108 242 275 108 243 275 minecraft:red_concrete
fill 108 242 317 109 243 317 minecraft:red_concrete
fill 109 242 275 109 247 275 minecraft:shroomlight
fill 110 242 275 111 243 275 minecraft:white_concrete
fill 110 242 317 111 243 317 minecraft:white_concrete
fill 112 242 275 113 243 275 minecraft:red_concrete
fill 112 242 317 112 243 317 minecraft:red_concrete
fill 113 242 317 113 247 317 minecraft:shroomlight
fill 114 242 275 115 243 275 minecraft:white_concrete
fill 114 242 317 115 243 317 minecraft:white_concrete
fill 116 242 275 116 243 275 minecraft:red_concrete
fill 116 242 317 117 243 317 minecraft:red_concrete
fill 117 242 275 117 247 275 minecraft:shroomlight
fill 118 242 275 119 243 275 minecraft:white_concrete
fill 118 242 317 119 243 317 minecraft:white_concrete
fill 120 242 275 121 243 275 minecraft:red_concrete
fill 120 242 317 120 243 317 minecraft:red_concrete
fill 121 242 317 121 247 317 minecraft:shroomlight
fill 122 242 275 123 243 275 minecraft:white_concrete
fill 122 242 317 123 243 317 minecraft:white_concrete
fill 124 242 275 124 243 275 minecraft:red_concrete
fill 124 242 317 125 243 317 minecraft:red_concrete
fill 125 242 275 125 247 275 minecraft:shroomlight
fill 126 242 275 127 243 275 minecraft:white_concrete
fill 126 242 317 127 243 317 minecraft:white_concrete
fill 128 242 275 129 243 275 minecraft:red_concrete
fill 128 242 317 128 243 317 minecraft:red_concrete
fill 129 242 317 129 247 317 minecraft:shroomlight
fill 130 242 275 131 243 275 minecraft:white_concrete
fill 130 242 317 131 243 317 minecraft:white_concrete
fill 132 242 275 132 243 275 minecraft:red_concrete
fill 132 242 317 133 243 317 minecraft:red_concrete
fill 133 242 275 133 247 275 minecraft:shroomlight
fill 134 242 275 135 243 275 minecraft:white_concrete
fill 134 242 317 135 243 317 minecraft:white_concrete
fill 136 242 276 136 243 276 minecraft:white_concrete
fill 136 242 277 136 243 278 minecraft:red_concrete
fill 136 242 279 136 243 279 minecraft:white_concrete
fill 136 242 280 136 247 280 minecraft:shroomlight
fill 136 242 281 136 243 282 minecraft:red_concrete
fill 136 242 283 136 243 284 minecraft:white_concrete
fill 136 242 285 136 243 286 minecraft:red_concrete
fill 136 242 287 136 243 287 minecraft:white_concrete
fill 136 242 288 136 247 288 minecraft:shroomlight
fill 136 242 289 136 243 290 minecraft:red_concrete
fill 136 242 291 136 243 292 minecraft:white_concrete
fill 136 242 293 136 243 294 minecraft:red_concrete
fill 136 242 295 136 243 295 minecraft:white_concrete
fill 136 242 296 136 247 296 minecraft:shroomlight
fill 136 242 297 136 243 298 minecraft:red_concrete
fill 136 242 299 136 243 300 minecraft:white_concrete
fill 136 242 301 136 243 302 minecraft:red_concrete
fill 136 242 303 136 243 303 minecraft:white_concrete
fill 136 242 304 136 247 304 minecraft:shroomlight
fill 136 242 305 136 243 306 minecraft:red_concrete
fill 136 242 307 136 243 308 minecraft:white_concrete
fill 136 242 309 136 243 310 minecraft:red_concrete
fill 136 242 311 136 243 311 minecraft:white_concrete
fill 136 242 312 136 247 312 minecraft:shroomlight
fill 136 242 313 136 243 314 minecraft:red_concrete
fill 136 242 315 136 243 316 minecraft:white_concrete
fill 136 242 317 136 243 317 minecraft:red_concrete
setblock 97 243 278 minecraft:light[level=12]
fill 97 243 279 97 243 281 minecraft:brown_terracotta
setblock 97 243 292 minecraft:light[level=12]
setblock 97 243 299 minecraft:light[level=12]
setblock 97 243 306 minecraft:light[level=12]
setblock 97 243 313 minecraft:light[level=12]
fill 98 243 278 100 243 278 minecraft:brown_terracotta
fill 98 243 282 100 243 282 minecraft:brown_terracotta
fill 101 243 279 101 243 281 minecraft:brown_terracotta
setblock 104 243 278 minecraft:light[level=12]
setblock 104 243 285 minecraft:light[level=12]
setblock 104 243 292 minecraft:light[level=12]
setblock 104 243 299 minecraft:light[level=12]
setblock 104 243 306 minecraft:light[level=12]
setblock 104 243 313 minecraft:light[level=12]
setblock 111 243 278 minecraft:light[level=12]
setblock 111 243 285 minecraft:light[level=12]
setblock 111 243 292 minecraft:light[level=12]
setblock 111 243 299 minecraft:light[level=12]
setblock 111 243 306 minecraft:light[level=12]
setblock 111 243 313 minecraft:light[level=12]
setblock 118 243 278 minecraft:light[level=12]
setblock 118 243 285 minecraft:light[level=12]
setblock 118 243 292 minecraft:light[level=12]
setblock 118 243 299 minecraft:light[level=12]
setblock 118 243 306 minecraft:light[level=12]
setblock 118 243 313 minecraft:light[level=12]
fill 123 243 295 124 244 296 minecraft:red_concrete
setblock 125 243 278 minecraft:light[level=12]
setblock 125 243 285 minecraft:light[level=12]
setblock 125 243 292 minecraft:light[level=12]
setblock 125 243 299 minecraft:light[level=12]
setblock 125 243 306 minecraft:light[level=12]
setblock 125 243 313 minecraft:light[level=12]
setblock 132 243 278 minecraft:light[level=12]
setblock 132 243 285 minecraft:light[level=12]
setblock 132 243 292 minecraft:light[level=12]
setblock 132 243 299 minecraft:light[level=12]
setblock 132 243 306 minecraft:light[level=12]
setblock 132 243 313 minecraft:light[level=12]
fill 94 244 275 94 245 276 minecraft:red_concrete
fill 94 244 277 94 245 278 minecraft:white_concrete
fill 94 244 279 94 245 279 minecraft:red_concrete
fill 94 244 281 94 245 282 minecraft:white_concrete
fill 94 244 283 94 245 284 minecraft:red_concrete
fill 94 244 285 94 245 286 minecraft:white_concrete
fill 94 244 287 94 245 287 minecraft:red_concrete
fill 94 244 289 94 245 290 minecraft:white_concrete
fill 94 244 291 94 245 292 minecraft:red_concrete
fill 94 244 293 94 245 294 minecraft:white_concrete
fill 94 244 295 94 245 295 minecraft:red_concrete
fill 94 244 297 94 245 298 minecraft:white_concrete
fill 94 244 299 94 245 300 minecraft:red_concrete
fill 94 244 301 94 245 302 minecraft:white_concrete
fill 94 244 303 94 245 303 minecraft:red_concrete
fill 94 244 305 94 245 306 minecraft:white_concrete
fill 94 244 307 94 245 308 minecraft:red_concrete
fill 94 244 309 94 245 310 minecraft:white_concrete
fill 94 244 311 94 245 311 minecraft:red_concrete
fill 94 244 313 94 245 314 minecraft:white_concrete
fill 94 244 315 94 245 316 minecraft:red_concrete
fill 95 244 275 95 245 275 minecraft:red_concrete
fill 95 244 317 95 245 317 minecraft:red_concrete
fill 96 244 275 97 245 275 minecraft:white_concrete
fill 96 244 317 96 245 317 minecraft:white_concrete
fill 98 244 275 99 245 275 minecraft:red_concrete
fill 98 244 317 99 245 317 minecraft:red_concrete
fill 100 244 275 100 245 275 minecraft:white_concrete
fill 100 244 317 101 245 317 minecraft:white_concrete
fill 102 244 275 103 245 275 minecraft:red_concrete
fill 102 244 317 103 245 317 minecraft:red_concrete
fill 104 244 275 105 245 275 minecraft:white_concrete
fill 104 244 317 104 245 317 minecraft:white_concrete
fill 106 244 275 107 245 275 minecraft:red_concrete
fill 106 244 317 107 245 317 minecraft:red_concrete
fill 108 244 275 108 245 275 minecraft:white_concrete
fill 108 244 317 109 245 317 minecraft:white_concrete
fill 110 244 275 111 245 275 minecraft:red_concrete
fill 110 244 317 111 245 317 minecraft:red_concrete
fill 112 244 275 113 245 275 minecraft:white_concrete
fill 112 244 317 112 245 317 minecraft:white_concrete
fill 114 244 275 115 245 275 minecraft:red_concrete
fill 114 244 317 115 245 317 minecraft:red_concrete
fill 116 244 275 116 245 275 minecraft:white_concrete
fill 116 244 317 117 245 317 minecraft:white_concrete
fill 118 244 275 119 245 275 minecraft:red_concrete
fill 118 244 317 119 245 317 minecraft:red_concrete
fill 120 244 275 121 245 275 minecraft:white_concrete
fill 120 244 317 120 245 317 minecraft:white_concrete
fill 122 244 275 123 245 275 minecraft:red_concrete
fill 122 244 317 123 245 317 minecraft:red_concrete
fill 124 244 275 124 245 275 minecraft:white_concrete
fill 124 244 317 125 245 317 minecraft:white_concrete
fill 126 244 275 127 245 275 minecraft:red_concrete
fill 126 244 317 127 245 317 minecraft:red_concrete
fill 128 244 275 129 245 275 minecraft:white_concrete
fill 128 244 317 128 245 317 minecraft:white_concrete
fill 130 244 275 131 245 275 minecraft:red_concrete
fill 130 244 317 131 245 317 minecraft:red_concrete
fill 132 244 275 132 245 275 minecraft:white_concrete
fill 132 244 317 133 245 317 minecraft:white_concrete
fill 134 244 275 135 245 275 minecraft:red_concrete
fill 134 244 317 135 245 317 minecraft:red_concrete
fill 136 244 276 136 245 276 minecraft:red_concrete
fill 136 244 277 136 245 278 minecraft:white_concrete
fill 136 244 279 136 245 279 minecraft:red_concrete
fill 136 244 281 136 245 282 minecraft:white_concrete
fill 136 244 283 136 245 284 minecraft:red_concrete
fill 136 244 285 136 245 286 minecraft:white_concrete
fill 136 244 287 136 245 287 minecraft:red_concrete
fill 136 244 289 136 245 290 minecraft:white_concrete
fill 136 244 291 136 245 292 minecraft:red_concrete
fill 136 244 293 136 245 294 minecraft:white_concrete
fill 136 244 295 136 245 295 minecraft:red_concrete
fill 136 244 297 136 245 298 minecraft:white_concrete
fill 136 244 299 136 245 300 minecraft:red_concrete
fill 136 244 301 136 245 302 minecraft:white_concrete
fill 136 244 303 136 245 303 minecraft:red_concrete
fill 136 244 305 136 245 306 minecraft:white_concrete
fill 136 244 307 136 245 308 minecraft:red_concrete
fill 136 244 309 136 245 310 minecraft:white_concrete
fill 136 244 311 136 245 311 minecraft:red_concrete
fill 136 244 313 136 245 314 minecraft:white_concrete
fill 136 244 315 136 245 316 minecraft:red_concrete
fill 136 244 317 136 245 317 minecraft:white_concrete
setblock 97 245 278 minecraft:light[level=15]
setblock 97 245 294 minecraft:light[level=15]
setblock 97 245 300 minecraft:red_terracotta
setblock 97 245 302 minecraft:red_terracotta
setblock 97 245 310 minecraft:light[level=15]
setblock 99 245 300 minecraft:red_terracotta
setblock 99 245 302 minecraft:red_terracotta
setblock 105 245 278 minecraft:light[level=15]
setblock 105 245 286 minecraft:light[level=15]
setblock 105 245 294 minecraft:light[level=15]
setblock 105 245 302 minecraft:light[level=15]
setblock 105 245 310 minecraft:light[level=15]
setblock 113 245 278 minecraft:light[level=15]
setblock 113 245 286 minecraft:light[level=15]
setblock 113 245 294 minecraft:light[level=15]
setblock 113 245 302 minecraft:light[level=15]
setblock 113 245 310 minecraft:light[level=15]
setblock 121 245 278 minecraft:light[level=15]
setblock 121 245 286 minecraft:light[level=15]
setblock 121 245 294 minecraft:light[level=15]
setblock 121 245 302 minecraft:light[level=15]
setblock 121 245 310 minecraft:light[level=15]
setblock 129 245 278 minecraft:light[level=15]
setblock 129 245 286 minecraft:light[level=15]
setblock 129 245 294 minecraft:light[level=15]
setblock 129 245 302 minecraft:light[level=15]
setblock 129 245 310 minecraft:light[level=15]
fill 94 246 275 94 247 276 minecraft:white_concrete
fill 94 246 277 94 247 278 minecraft:red_concrete
fill 94 246 279 94 247 279 minecraft:white_concrete
fill 94 246 281 94 247 282 minecraft:red_concrete
fill 94 246 283 94 247 284 minecraft:white_concrete
fill 94 246 285 94 247 286 minecraft:red_concrete
fill 94 246 287 94 247 287 minecraft:white_concrete
fill 94 246 289 94 247 290 minecraft:red_concrete
fill 94 246 291 94 247 292 minecraft:white_concrete
fill 94 246 293 94 247 294 minecraft:red_concrete
fill 94 246 295 94 247 295 minecraft:white_concrete
fill 94 246 297 94 247 298 minecraft:red_concrete
fill 94 246 299 94 247 300 minecraft:white_concrete
fill 94 246 301 94 247 302 minecraft:red_concrete
fill 94 246 303 94 247 303 minecraft:white_concrete
fill 94 246 305 94 247 306 minecraft:red_concrete
fill 94 246 307 94 247 308 minecraft:white_concrete
fill 94 246 309 94 247 310 minecraft:red_concrete
fill 94 246 311 94 247 311 minecraft:white_concrete
fill 94 246 313 94 247 314 minecraft:red_concrete
fill 94 246 315 94 247 316 minecraft:white_concrete
fill 95 246 275 95 247 275 minecraft:white_concrete
fill 95 246 317 95 247 317 minecraft:white_concrete
fill 96 246 275 97 247 275 minecraft:red_concrete
fill 96 246 317 96 247 317 minecraft:red_concrete
fill 98 246 275 99 247 275 minecraft:white_concrete
fill 98 246 317 99 247 317 minecraft:white_concrete
fill 100 246 275 100 247 275 minecraft:red_concrete
fill 100 246 317 101 247 317 minecraft:red_concrete
fill 102 246 275 103 247 275 minecraft:white_concrete
fill 102 246 317 103 247 317 minecraft:white_concrete
fill 104 246 275 105 247 275 minecraft:red_concrete
fill 104 246 317 104 247 317 minecraft:red_concrete
fill 106 246 275 107 247 275 minecraft:white_concrete
fill 106 246 317 107 247 317 minecraft:white_concrete
fill 108 246 275 108 247 275 minecraft:red_concrete
fill 108 246 317 109 247 317 minecraft:red_concrete
fill 110 246 275 111 247 275 minecraft:white_concrete
fill 110 246 317 111 247 317 minecraft:white_concrete
fill 112 246 275 113 247 275 minecraft:red_concrete
fill 112 246 317 112 247 317 minecraft:red_concrete
fill 114 246 275 115 247 275 minecraft:white_concrete
fill 114 246 317 115 247 317 minecraft:white_concrete
fill 116 246 275 116 247 275 minecraft:red_concrete
fill 116 246 317 117 247 317 minecraft:red_concrete
fill 118 246 275 119 247 275 minecraft:white_concrete
fill 118 246 317 119 247 317 minecraft:white_concrete
fill 120 246 275 121 247 275 minecraft:red_concrete
fill 120 246 317 120 247 317 minecraft:red_concrete
fill 122 246 275 123 247 275 minecraft:white_concrete
fill 122 246 317 123 247 317 minecraft:white_concrete
fill 124 246 275 124 247 275 minecraft:red_concrete
fill 124 246 317 125 247 317 minecraft:red_concrete
fill 126 246 275 127 247 275 minecraft:white_concrete
fill 126 246 317 127 247 317 minecraft:white_concrete
fill 128 246 275 129 247 275 minecraft:red_concrete
fill 128 246 317 128 247 317 minecraft:red_concrete
fill 130 246 275 131 247 275 minecraft:white_concrete
fill 130 246 317 131 247 317 minecraft:white_concrete
fill 132 246 275 132 247 275 minecraft:red_concrete
fill 132 246 317 133 247 317 minecraft:red_concrete
fill 134 246 275 135 247 275 minecraft:white_concrete
fill 134 246 317 135 247 317 minecraft:white_concrete
fill 136 246 276 136 247 276 minecraft:white_concrete
fill 136 246 277 136 247 278 minecraft:red_concrete
fill 136 246 279 136 247 279 minecraft:white_concrete
fill 136 246 281 136 247 282 minecraft:red_concrete
fill 136 246 283 136 247 284 minecraft:white_concrete
fill 136 246 285 136 247 286 minecraft:red_concrete
fill 136 246 287 136 247 287 minecraft:white_concrete
fill 136 246 289 136 247 290 minecraft:red_concrete
fill 136 246 291 136 247 292 minecraft:white_concrete
fill 136 246 293 136 247 294 minecraft:red_concrete
fill 136 246 295 136 247 295 minecraft:white_concrete
fill 136 246 297 136 247 298 minecraft:red_concrete
fill 136 246 299 136 247 300 minecraft:white_concrete
fill 136 246 301 136 247 302 minecraft:red_concrete
fill 136 246 303 136 247 303 minecraft:white_concrete
fill 136 246 305 136 247 306 minecraft:red_concrete
fill 136 246 307 136 247 308 minecraft:white_concrete
fill 136 246 309 136 247 310 minecraft:red_concrete
fill 136 246 311 136 247 311 minecraft:white_concrete
fill 136 246 313 136 247 314 minecraft:red_concrete
fill 136 246 315 136 247 316 minecraft:white_concrete
fill 136 246 317 136 247 317 minecraft:red_concrete
fill 95 247 301 96 248 301 minecraft:iron_block
fill 94 248 275 94 249 276 minecraft:red_concrete
fill 94 248 277 94 249 278 minecraft:white_concrete
fill 94 248 279 94 249 280 minecraft:red_concrete
fill 94 248 281 94 249 282 minecraft:white_concrete
fill 94 248 283 94 249 284 minecraft:red_concrete
fill 94 248 285 94 249 286 minecraft:white_concrete
fill 94 248 287 94 249 288 minecraft:red_concrete
fill 94 248 289 94 249 290 minecraft:white_concrete
fill 94 248 291 94 249 292 minecraft:red_concrete
fill 94 248 293 94 249 294 minecraft:white_concrete
fill 94 248 295 94 249 296 minecraft:red_concrete
fill 94 248 297 94 249 298 minecraft:white_concrete
fill 94 248 299 94 249 300 minecraft:red_concrete
fill 94 248 301 94 249 302 minecraft:white_concrete
fill 94 248 303 94 249 304 minecraft:red_concrete
fill 94 248 305 94 249 306 minecraft:white_concrete
fill 94 248 307 94 249 308 minecraft:red_concrete
fill 94 248 309 94 249 310 minecraft:white_concrete
fill 94 248 311 94 249 312 minecraft:red_concrete
fill 94 248 313 94 249 314 minecraft:white_concrete
fill 94 248 315 94 249 316 minecraft:red_concrete
fill 95 248 275 95 249 275 minecraft:red_concrete
fill 95 248 317 95 249 317 minecraft:red_concrete
fill 96 248 275 97 249 275 minecraft:white_concrete
fill 96 248 317 97 249 317 minecraft:white_concrete
fill 98 248 275 99 249 275 minecraft:red_concrete
fill 98 248 317 99 249 317 minecraft:red_concrete
fill 100 248 275 101 249 275 minecraft:white_concrete
setblock 100 248 301 minecraft:shroomlight
fill 100 248 317 101 249 317 minecraft:white_concrete
fill 102 248 275 103 249 275 minecraft:red_concrete
fill 102 248 317 103 249 317 minecraft:red_concrete
fill 104 248 275 105 249 275 minecraft:white_concrete
fill 104 248 317 105 249 317 minecraft:white_concrete
fill 106 248 275 107 249 275 minecraft:red_concrete
fill 106 248 317 107 249 317 minecraft:red_concrete
fill 108 248 275 109 249 275 minecraft:white_concrete
fill 108 248 317 109 249 317 minecraft:white_concrete
fill 110 248 275 111 249 275 minecraft:red_concrete
fill 110 248 317 111 249 317 minecraft:red_concrete
fill 112 248 275 113 249 275 minecraft:white_concrete
fill 112 248 317 113 249 317 minecraft:white_concrete
fill 114 248 275 115 249 275 minecraft:red_concrete
fill 114 248 277 114 248 279 minecraft:red_terracotta
fill 114 248 317 115 249 317 minecraft:red_concrete
fill 115 248 277 116 248 277 minecraft:red_terracotta
fill 115 248 279 116 248 279 minecraft:red_terracotta
fill 116 248 275 117 249 275 minecraft:white_concrete
setblock 116 248 278 minecraft:red_terracotta
fill 116 248 317 117 249 317 minecraft:white_concrete
fill 118 248 275 119 249 275 minecraft:red_concrete
fill 118 248 317 119 249 317 minecraft:red_concrete
fill 120 248 275 121 249 275 minecraft:white_concrete
fill 120 248 317 121 249 317 minecraft:white_concrete
fill 122 248 275 123 249 275 minecraft:red_concrete
fill 122 248 317 123 249 317 minecraft:red_concrete
fill 124 248 275 125 249 275 minecraft:white_concrete
fill 124 248 317 125 249 317 minecraft:white_concrete
fill 126 248 275 127 249 275 minecraft:red_concrete
fill 126 248 317 127 249 317 minecraft:red_concrete
fill 128 248 275 129 249 275 minecraft:white_concrete
fill 128 248 317 129 249 317 minecraft:white_concrete
fill 130 248 275 131 249 275 minecraft:red_concrete
fill 130 248 317 131 249 317 minecraft:red_concrete
fill 132 248 275 133 249 275 minecraft:white_concrete
fill 132 248 317 133 249 317 minecraft:white_concrete
fill 134 248 275 135 249 275 minecraft:red_concrete
fill 134 248 317 135 249 317 minecraft:red_concrete
fill 136 248 276 136 249 276 minecraft:red_concrete
fill 136 248 277 136 249 278 minecraft:white_concrete
fill 136 248 279 136 249 280 minecraft:red_concrete
fill 136 248 281 136 249 282 minecraft:white_concrete
fill 136 248 283 136 249 284 minecraft:red_concrete
fill 136 248 285 136 249 286 minecraft:white_concrete
fill 136 248 287 136 249 288 minecraft:red_concrete
fill 136 248 289 136 249 290 minecraft:white_concrete
fill 136 248 291 136 249 292 minecraft:red_concrete
fill 136 248 293 136 249 294 minecraft:white_concrete
fill 136 248 295 136 249 296 minecraft:red_concrete
fill 136 248 297 136 249 298 minecraft:white_concrete
fill 136 248 299 136 249 300 minecraft:red_concrete
fill 136 248 301 136 249 302 minecraft:white_concrete
fill 136 248 303 136 249 304 minecraft:red_concrete
fill 136 248 305 136 249 306 minecraft:white_concrete
fill 136 248 307 136 249 308 minecraft:red_concrete
fill 136 248 309 136 249 310 minecraft:white_concrete
fill 136 248 311 136 249 312 minecraft:red_concrete
fill 136 248 313 136 249 314 minecraft:white_concrete
fill 136 248 315 136 249 316 minecraft:red_concrete
fill 136 248 317 136 249 317 minecraft:white_concrete
setblock 97 249 278 minecraft:light[level=12]
setblock 97 249 292 minecraft:light[level=12]
setblock 97 249 299 minecraft:light[level=12]
setblock 97 249 306 minecraft:light[level=12]
setblock 97 249 313 minecraft:light[level=12]
setblock 104 249 278 minecraft:light[level=12]
setblock 104 249 285 minecraft:light[level=12]
setblock 104 249 292 minecraft:light[level=12]
setblock 104 249 299 minecraft:light[level=12]
setblock 104 249 306 minecraft:light[level=12]
setblock 104 249 313 minecraft:light[level=12]
setblock 111 249 278 minecraft:light[level=12]
setblock 111 249 285 minecraft:light[level=12]
setblock 111 249 292 minecraft:light[level=12]
setblock 111 249 299 minecraft:light[level=12]
setblock 111 249 306 minecraft:light[level=12]
setblock 111 249 313 minecraft:light[level=12]
setblock 118 249 278 minecraft:light[level=12]
setblock 118 249 285 minecraft:light[level=12]
setblock 118 249 292 minecraft:light[level=12]
setblock 118 249 299 minecraft:light[level=12]
setblock 118 249 306 minecraft:light[level=12]
setblock 118 249 313 minecraft:light[level=12]
setblock 125 249 278 minecraft:light[level=12]
setblock 125 249 285 minecraft:light[level=12]
setblock 125 249 292 minecraft:light[level=12]
setblock 125 249 299 minecraft:light[level=12]
setblock 125 249 306 minecraft:light[level=12]
setblock 125 249 313 minecraft:light[level=12]
setblock 132 249 278 minecraft:light[level=12]
setblock 132 249 285 minecraft:light[level=12]
setblock 132 249 292 minecraft:light[level=12]
setblock 132 249 299 minecraft:light[level=12]
setblock 132 249 306 minecraft:light[level=12]
setblock 132 249 313 minecraft:light[level=12]
fill 94 250 275 94 251 276 minecraft:white_concrete
fill 94 250 277 94 251 278 minecraft:red_concrete
fill 94 250 279 94 251 280 minecraft:white_concrete
fill 94 250 281 94 251 282 minecraft:red_concrete
fill 94 250 283 94 251 284 minecraft:white_concrete
fill 94 250 285 94 251 286 minecraft:red_concrete
fill 94 250 287 94 251 288 minecraft:white_concrete
fill 94 250 289 94 251 290 minecraft:red_concrete
fill 94 250 291 94 251 292 minecraft:white_concrete
fill 94 250 293 94 251 294 minecraft:red_concrete
fill 94 250 295 94 251 296 minecraft:white_concrete
fill 94 250 297 94 251 298 minecraft:red_concrete
fill 94 250 299 94 251 300 minecraft:white_concrete
fill 94 250 301 94 251 302 minecraft:red_concrete
fill 94 250 303 94 251 304 minecraft:white_concrete
fill 94 250 305 94 251 306 minecraft:red_concrete
fill 94 250 307 94 251 308 minecraft:white_concrete
fill 94 250 309 94 251 310 minecraft:red_concrete
fill 94 250 311 94 251 312 minecraft:white_concrete
fill 94 250 313 94 251 314 minecraft:red_concrete
fill 94 250 315 94 251 316 minecraft:white_concrete
fill 95 250 275 95 251 275 minecraft:white_concrete
fill 95 250 317 95 251 317 minecraft:white_concrete
fill 96 250 275 97 251 275 minecraft:red_concrete
fill 96 250 317 97 251 317 minecraft:red_concrete
fill 98 250 275 99 251 275 minecraft:white_concrete
fill 98 250 317 99 251 317 minecraft:white_concrete
fill 100 250 275 101 251 275 minecraft:red_concrete
fill 100 250 317 101 251 317 minecraft:red_concrete
fill 102 250 275 103 251 275 minecraft:white_concrete
fill 102 250 317 103 251 317 minecraft:white_concrete
fill 104 250 275 105 251 275 minecraft:red_concrete
fill 104 250 317 105 251 317 minecraft:red_concrete
fill 106 250 275 107 251 275 minecraft:white_concrete
fill 106 250 317 107 251 317 minecraft:white_concrete
fill 108 250 275 109 251 275 minecraft:red_concrete
fill 108 250 317 109 251 317 minecraft:red_concrete
fill 110 250 275 111 251 275 minecraft:white_concrete
fill 110 250 317 111 251 317 minecraft:white_concrete
fill 112 250 275 113 251 275 minecraft:red_concrete
fill 112 250 317 113 251 317 minecraft:red_concrete
fill 114 250 275 115 251 275 minecraft:white_concrete
fill 114 250 317 115 251 317 minecraft:white_concrete
fill 116 250 275 117 251 275 minecraft:red_concrete
fill 116 250 317 117 251 317 minecraft:red_concrete
fill 118 250 275 119 251 275 minecraft:white_concrete
fill 118 250 317 119 251 317 minecraft:white_concrete
fill 120 250 275 121 251 275 minecraft:red_concrete
fill 120 250 317 121 251 317 minecraft:red_concrete
fill 122 250 275 123 251 275 minecraft:white_concrete
fill 122 250 317 123 251 317 minecraft:white_concrete
fill 124 250 275 125 251 275 minecraft:red_concrete
fill 124 250 317 125 251 317 minecraft:red_concrete
fill 126 250 275 127 251 275 minecraft:white_concrete
fill 126 250 317 127 251 317 minecraft:white_concrete
fill 128 250 275 129 251 275 minecraft:red_concrete
fill 128 250 317 129 251 317 minecraft:red_concrete
fill 130 250 275 131 251 275 minecraft:white_concrete
fill 130 250 317 131 251 317 minecraft:white_concrete
fill 132 250 275 133 251 275 minecraft:red_concrete
fill 132 250 317 133 251 317 minecraft:red_concrete
fill 134 250 275 135 251 275 minecraft:white_concrete
fill 134 250 317 135 251 317 minecraft:white_concrete
fill 136 250 276 136 251 276 minecraft:white_concrete
fill 136 250 277 136 251 278 minecraft:red_concrete
fill 136 250 279 136 251 280 minecraft:white_concrete
fill 136 250 281 136 251 282 minecraft:red_concrete
fill 136 250 283 136 251 284 minecraft:white_concrete
fill 136 250 285 136 251 286 minecraft:red_concrete
fill 136 250 287 136 251 288 minecraft:white_concrete
fill 136 250 289 136 251 290 minecraft:red_concrete
fill 136 250 291 136 251 292 minecraft:white_concrete
fill 136 250 293 136 251 294 minecraft:red_concrete
fill 136 250 295 136 251 296 minecraft:white_concrete
fill 136 250 297 136 251 298 minecraft:red_concrete
fill 136 250 299 136 251 300 minecraft:white_concrete
fill 136 250 301 136 251 302 minecraft:red_concrete
fill 136 250 303 136 251 304 minecraft:white_concrete
fill 136 250 305 136 251 306 minecraft:red_concrete
fill 136 250 307 136 251 308 minecraft:white_concrete
fill 136 250 309 136 251 310 minecraft:red_concrete
fill 136 250 311 136 251 312 minecraft:white_concrete
fill 136 250 313 136 251 314 minecraft:red_concrete
fill 136 250 315 136 251 316 minecraft:white_concrete
fill 136 250 317 136 251 317 minecraft:red_concrete
fill 97 251 279 97 251 281 minecraft:brown_terracotta
fill 98 251 278 100 251 278 minecraft:brown_terracotta
fill 98 251 282 100 251 282 minecraft:brown_terracotta
fill 101 251 279 101 251 281 minecraft:brown_terracotta
fill 94 252 275 94 253 276 minecraft:red_concrete
fill 94 252 277 94 253 278 minecraft:white_concrete
fill 94 252 279 94 253 280 minecraft:red_concrete
fill 94 252 281 94 253 282 minecraft:white_concrete
fill 94 252 283 94 253 284 minecraft:red_concrete
fill 94 252 285 94 253 286 minecraft:white_concrete
fill 94 252 287 94 253 288 minecraft:red_concrete
fill 94 252 289 94 253 290 minecraft:white_concrete
fill 94 252 291 94 253 292 minecraft:red_concrete
fill 94 252 293 94 253 294 minecraft:white_concrete
fill 94 252 295 94 253 296 minecraft:red_concrete
fill 94 252 297 94 253 298 minecraft:white_concrete
fill 94 252 299 94 253 300 minecraft:red_concrete
fill 94 252 301 94 253 302 minecraft:white_concrete
fill 94 252 303 94 253 304 minecraft:red_concrete
fill 94 252 305 94 253 306 minecraft:white_concrete
fill 94 252 307 94 253 308 minecraft:red_concrete
fill 94 252 309 94 253 310 minecraft:white_concrete
fill 94 252 311 94 253 312 minecraft:red_concrete
fill 94 252 313 94 253 314 minecraft:white_concrete
fill 94 252 315 94 253 316 minecraft:red_concrete
fill 95 252 275 95 253 275 minecraft:red_concrete
fill 95 252 276 95 253 281 minecraft:red_terracotta
fill 95 252 284 96 252 284 minecraft:red_terracotta
fill 95 252 288 95 253 289 minecraft:red_terracotta
fill 95 252 292 96 252 297 minecraft:red_terracotta
fill 95 252 300 96 252 305 minecraft:red_terracotta
fill 95 252 308 96 252 313 minecraft:red_terracotta
fill 95 252 316 100 253 316 minecraft:red_terracotta
fill 95 252 317 95 253 317 minecraft:red_concrete
fill 96 252 275 97 253 275 minecraft:white_concrete
fill 96 252 277 96 252 283 minecraft:red_terracotta
fill 96 252 289 96 252 291 minecraft:red_terracotta
fill 96 252 298 96 252 299 minecraft:red_terracotta
fill 96 252 306 96 252 307 minecraft:red_terracotta
fill 96 252 314 96 252 315 minecraft:red_terracotta
fill 96 252 317 97 253 317 minecraft:white_concrete
fill 97 252 277 134 252 277 minecraft:red_terracotta
fill 97 252 315 135 252 315 minecraft:red_terracotta
fill 98 252 275 99 253 275 minecraft:red_concrete
fill 98 252 276 103 253 276 minecraft:red_terracotta
fill 98 252 317 99 253 317 minecraft:red_concrete
fill 100 252 275 101 253 275 minecraft:white_concrete
fill 100 252 317 101 253 317 minecraft:white_concrete
fill 102 252 275 103 253 275 minecraft:red_concrete
fill 102 252 317 103 253 317 minecraft:red_concrete
fill 103 252 316 108 253 316 minecraft:red_terracotta
fill 104 252 275 105 253 275 minecraft:white_concrete
fill 104 252 317 105 253 317 minecraft:white_concrete
fill 106 252 275 107 253 275 minecraft:red_concrete
fill 106 252 276 111 253 276 minecraft:red_terracotta
fill 106 252 317 107 253 317 minecraft:red_concrete
fill 108 252 275 109 253 275 minecraft:white_concrete
fill 108 252 317 109 253 317 minecraft:white_concrete
fill 110 252 275 111 253 275 minecraft:red_concrete
fill 110 252 317 111 253 317 minecraft:red_concrete
fill 111 252 316 116 253 316 minecraft:red_terracotta
fill 112 252 275 113 253 275 minecraft:white_concrete
fill 112 252 317 113 253 317 minecraft:white_concrete
fill 114 252 275 115 253 275 minecraft:red_concrete
fill 114 252 276 119 253 276 minecraft:red_terracotta
fill 114 252 317 115 253 317 minecraft:red_concrete
fill 116 252 275 117 253 275 minecraft:white_concrete
fill 116 252 317 117 253 317 minecraft:white_concrete
fill 118 252 275 119 253 275 minecraft:red_concrete
fill 118 252 317 119 253 317 minecraft:red_concrete
fill 119 252 316 124 253 316 minecraft:red_terracotta
fill 120 252 275 121 253 275 minecraft:white_concrete
fill 120 252 317 121 253 317 minecraft:white_concrete
fill 122 252 275 123 253 275 minecraft:red_concrete
fill 122 252 276 127 253 276 minecraft:red_terracotta
fill 122 252 317 123 253 317 minecraft:red_concrete
fill 124 252 275 125 253 275 minecraft:white_concrete
fill 124 252 317 125 253 317 minecraft:white_concrete
fill 126 252 275 127 253 275 minecraft:red_concrete
fill 126 252 317 127 253 317 minecraft:red_concrete
fill 127 252 316 132 253 316 minecraft:red_terracotta
fill 128 252 275 129 253 275 minecraft:white_concrete
fill 128 252 317 129 253 317 minecraft:white_concrete
fill 130 252 275 131 253 275 minecraft:red_concrete
fill 130 252 276 135 253 276 minecraft:red_terracotta
fill 130 252 317 131 253 317 minecraft:red_concrete
fill 132 252 275 133 253 275 minecraft:white_concrete
fill 132 252 317 133 253 317 minecraft:white_concrete
fill 134 252 275 135 253 275 minecraft:red_concrete
fill 134 252 278 134 252 314 minecraft:red_terracotta
fill 134 252 317 135 253 317 minecraft:red_concrete
fill 135 252 279 135 253 284 minecraft:red_terracotta
fill 135 252 287 135 253 292 minecraft:red_terracotta
fill 135 252 295 135 253 300 minecraft:red_terracotta
fill 135 252 303 135 253 308 minecraft:red_terracotta
fill 135 252 311 135 253 314 minecraft:red_terracotta
fill 135 252 316 135 253 316 minecraft:red_terracotta
fill 136 252 276 136 253 276 minecraft:red_concrete
fill 136 252 277 136 253 278 minecraft:white_concrete
fill 136 252 279 136 253 280 minecraft:red_concrete
fill 136 252 281 136 253 282 minecraft:white_concrete
fill 136 252 283 136 253 284 minecraft:red_concrete
fill 136 252 285 136 253 286 minecraft:white_concrete
fill 136 252 287 136 253 288 minecraft:red_concrete
fill 136 252 289 136 253 290 minecraft:white_concrete
fill 136 252 291 136 253 292 minecraft:red_concrete
fill 136 252 293 136 253 294 minecraft:white_concrete
fill 136 252 295 136 253 296 minecraft:red_concrete
fill 136 252 297 136 253 298 minecraft:white_concrete
fill 136 252 299 136 253 300 minecraft:red_concrete
fill 136 252 301 136 253 302 minecraft:white_concrete
fill 136 252 303 136 253 304 minecraft:red_concrete
fill 136 252 305 136 253 306 minecraft:white_concrete
fill 136 252 307 136 253 308 minecraft:red_concrete
fill 136 252 309 136 253 310 minecraft:white_concrete
fill 136 252 311 136 253 312 minecraft:red_concrete
fill 136 252 313 136 253 314 minecraft:white_concrete
fill 136 252 315 136 253 316 minecraft:red_concrete
fill 136 252 317 136 253 317 minecraft:white_concrete
setblock 95 253 284 minecraft:red_terracotta
fill 95 253 292 95 253 297 minecraft:red_terracotta
fill 95 253 300 95 253 305 minecraft:red_terracotta
fill 95 253 308 95 253 313 minecraft:red_terracotta
setblock 97 253 278 minecraft:light[level=15]
setblock 97 253 294 minecraft:light[level=15]
setblock 97 253 300 minecraft:red_terracotta
setblock 97 253 302 minecraft:red_terracotta
setblock 97 253 310 minecraft:light[level=15]
setblock 99 253 300 minecraft:red_terracotta
setblock 99 253 302 minecraft:red_terracotta
setblock 105 253 278 minecraft:light[level=15]
setblock 105 253 286 minecraft:light[level=15]
setblock 105 253 294 minecraft:light[level=15]
setblock 105 253 302 minecraft:light[level=15]
setblock 105 253 310 minecraft:light[level=15]
setblock 113 253 278 minecraft:light[level=15]
setblock 113 253 286 minecraft:light[level=15]
setblock 113 253 294 minecraft:light[level=15]
setblock 113 253 302 minecraft:light[level=15]
setblock 113 253 310 minecraft:light[level=15]
setblock 121 253 278 minecraft:light[level=15]
setblock 121 253 286 minecraft:light[level=15]
setblock 121 253 294 minecraft:light[level=15]
setblock 121 253 302 minecraft:light[level=15]
setblock 121 253 310 minecraft:light[level=15]
setblock 129 253 278 minecraft:light[level=15]
setblock 129 253 286 minecraft:light[level=15]
setblock 129 253 294 minecraft:light[level=15]
setblock 129 253 302 minecraft:light[level=15]
setblock 129 253 310 minecraft:light[level=15]
setblock 135 253 315 minecraft:red_terracotta
fill 94 254 275 94 255 276 minecraft:white_concrete
fill 94 254 277 94 255 278 minecraft:red_concrete
fill 94 254 279 94 255 280 minecraft:white_concrete
fill 94 254 281 94 255 282 minecraft:red_concrete
fill 94 254 283 94 255 284 minecraft:white_concrete
fill 94 254 285 94 255 286 minecraft:red_concrete
fill 94 254 287 94 255 288 minecraft:white_concrete
fill 94 254 289 94 255 290 minecraft:red_concrete
fill 94 254 291 94 255 292 minecraft:white_concrete
fill 94 254 293 94 255 294 minecraft:red_concrete
fill 94 254 295 94 255 296 minecraft:white_concrete
fill 94 254 297 94 255 298 minecraft:red_concrete
fill 94 254 299 94 255 300 minecraft:white_concrete
fill 94 254 301 94 255 302 minecraft:red_concrete
fill 94 254 303 94 255 304 minecraft:white_concrete
fill 94 254 305 94 255 306 minecraft:red_concrete
fill 94 254 307 94 255 308 minecraft:white_concrete
fill 94 254 309 94 255 310 minecraft:red_concrete
fill 94 254 311 94 255 312 minecraft:white_concrete
fill 94 254 313 94 255 314 minecraft:red_concrete
fill 94 254 315 94 255 316 minecraft:white_concrete
fill 95 254 275 95 255 275 minecraft:white_concrete
fill 95 254 317 95 255 317 minecraft:white_concrete
fill 96 254 275 97 255 275 minecraft:red_concrete
fill 96 254 317 97 255 317 minecraft:red_concrete
fill 98 254 275 99 255 275 minecraft:white_concrete
fill 98 254 317 99 255 317 minecraft:white_concrete
fill 100 254 275 101 255 275 minecraft:red_concrete
fill 100 254 317 101 255 317 minecraft:red_concrete
fill 102 254 275 103 255 275 minecraft:white_concrete
fill 102 254 317 103 255 317 minecraft:white_concrete
fill 104 254 275 105 255 275 minecraft:red_concrete
fill 104 254 317 105 255 317 minecraft:red_concrete
fill 106 254 275 107 255 275 minecraft:white_concrete
fill 106 254 317 107 255 317 minecraft:white_concrete
fill 108 254 275 109 255 275 minecraft:red_concrete
fill 108 254 317 109 255 317 minecraft:red_concrete
fill 110 254 275 111 255 275 minecraft:white_concrete
fill 110 254 317 111 255 317 minecraft:white_concrete
fill 112 254 275 113 255 275 minecraft:red_concrete
fill 112 254 317 113 255 317 minecraft:red_concrete
fill 114 254 275 115 255 275 minecraft:white_concrete
fill 114 254 317 115 255 317 minecraft:white_concrete
fill 116 254 275 117 255 275 minecraft:red_concrete
fill 116 254 317 117 255 317 minecraft:red_concrete
fill 118 254 275 119 255 275 minecraft:white_concrete
fill 118 254 317 119 255 317 minecraft:white_concrete
fill 120 254 275 121 255 275 minecraft:red_concrete
fill 120 254 317 121 255 317 minecraft:red_concrete
fill 122 254 275 123 255 275 minecraft:white_concrete
fill 122 254 317 123 255 317 minecraft:white_concrete
fill 124 254 275 125 255 275 minecraft:red_concrete
fill 124 254 317 125 255 317 minecraft:red_concrete
fill 126 254 275 127 255 275 minecraft:white_concrete
fill 126 254 317 127 255 317 minecraft:white_concrete
fill 128 254 275 129 255 275 minecraft:red_concrete
fill 128 254 317 129 255 317 minecraft:red_concrete
fill 130 254 275 131 255 275 minecraft:white_concrete
fill 130 254 317 131 255 317 minecraft:white_concrete
fill 132 254 275 133 255 275 minecraft:red_concrete
fill 132 254 317 133 255 317 minecraft:red_concrete
fill 134 254 275 135 255 275 minecraft:white_concrete
fill 134 254 317 135 255 317 minecraft:white_concrete
fill 136 254 276 136 255 276 minecraft:white_concrete
fill 136 254 277 136 255 278 minecraft:red_concrete
fill 136 254 279 136 255 280 minecraft:white_concrete
fill 136 254 281 136 255 282 minecraft:red_concrete
fill 136 254 283 136 255 284 minecraft:white_concrete
fill 136 254 285 136 255 286 minecraft:red_concrete
fill 136 254 287 136 255 288 minecraft:white_concrete
fill 136 254 289 136 255 290 minecraft:red_concrete
fill 136 254 291 136 255 292 minecraft:white_concrete
fill 136 254 293 136 255 294 minecraft:red_concrete
fill 136 254 295 136 255 296 minecraft:white_concrete
fill 136 254 297 136 255 298 minecraft:red_concrete
fill 136 254 299 136 255 300 minecraft:white_concrete
fill 136 254 301 136 255 302 minecraft:red_concrete
fill 136 254 303 136 255 304 minecraft:white_concrete
fill 136 254 305 136 255 306 minecraft:red_concrete
fill 136 254 307 136 255 308 minecraft:white_concrete
fill 136 254 309 136 255 310 minecraft:red_concrete
fill 136 254 311 136 255 312 minecraft:white_concrete
fill 136 254 313 136 255 314 minecraft:red_concrete
fill 136 254 315 136 255 316 minecraft:white_concrete
fill 136 254 317 136 255 317 minecraft:red_concrete
setblock 97 255 278 minecraft:light[level=12]
setblock 97 255 292 minecraft:light[level=12]
setblock 97 255 299 minecraft:light[level=12]
setblock 97 255 306 minecraft:light[level=12]
setblock 97 255 313 minecraft:light[level=12]
setblock 104 255 278 minecraft:light[level=12]
setblock 104 255 285 minecraft:light[level=12]
setblock 104 255 292 minecraft:light[level=12]
setblock 104 255 299 minecraft:light[level=12]
setblock 104 255 306 minecraft:light[level=12]
setblock 104 255 313 minecraft:light[level=12]
setblock 111 255 278 minecraft:light[level=12]
setblock 111 255 285 minecraft:light[level=12]
setblock 111 255 292 minecraft:light[level=12]
setblock 111 255 299 minecraft:light[level=12]
setblock 111 255 306 minecraft:light[level=12]
setblock 111 255 313 minecraft:light[level=12]
fill 114 255 277 114 255 279 minecraft:red_terracotta
fill 115 255 277 116 255 277 minecraft:red_terracotta
fill 115 255 279 116 255 279 minecraft:red_terracotta
setblock 116 255 278 minecraft:red_terracotta
setblock 118 255 278 minecraft:light[level=12]
setblock 118 255 285 minecraft:light[level=12]
setblock 118 255 292 minecraft:light[level=12]
setblock 118 255 299 minecraft:light[level=12]
setblock 118 255 306 minecraft:light[level=12]
setblock 118 255 313 minecraft:light[level=12]
setblock 125 255 278 minecraft:light[level=12]
setblock 125 255 285 minecraft:light[level=12]
setblock 125 255 292 minecraft:light[level=12]
setblock 125 255 299 minecraft:light[level=12]
setblock 125 255 306 minecraft:light[level=12]
setblock 125 255 313 minecraft:light[level=12]
setblock 132 255 278 minecraft:light[level=12]
setblock 132 255 285 minecraft:light[level=12]
setblock 132 255 292 minecraft:light[level=12]
setblock 132 255 299 minecraft:light[level=12]
setblock 132 255 306 minecraft:light[level=12]
setblock 132 255 313 minecraft:light[level=12]
fill 94 256 275 94 257 276 minecraft:red_concrete
fill 94 256 277 94 257 278 minecraft:white_concrete
fill 94 256 279 94 257 279 minecraft:red_concrete
fill 94 256 280 94 261 280 minecraft:shroomlight
fill 94 256 281 94 257 282 minecraft:white_concrete
fill 94 256 283 94 257 284 minecraft:red_concrete
fill 94 256 285 94 257 286 minecraft:white_concrete
fill 94 256 287 94 257 287 minecraft:red_concrete
fill 94 256 288 94 261 288 minecraft:shroomlight
fill 94 256 289 94 257 290 minecraft:white_concrete
fill 94 256 291 94 257 292 minecraft:red_concrete
fill 94 256 293 94 257 294 minecraft:white_concrete
fill 94 256 295 94 257 295 minecraft:red_concrete
fill 94 256 296 94 261 296 minecraft:shroomlight
fill 94 256 297 94 257 298 minecraft:white_concrete
fill 94 256 299 94 257 300 minecraft:red_concrete
fill 94 256 301 94 257 302 minecraft:white_concrete
fill 94 256 303 94 257 303 minecraft:red_concrete
fill 94 256 304 94 261 304 minecraft:shroomlight
fill 94 256 305 94 257 306 minecraft:white_concrete
fill 94 256 307 94 257 308 minecraft:red_concrete
fill 94 256 309 94 257 310 minecraft:white_concrete
fill 94 256 311 94 257 311 minecraft:red_concrete
fill 94 256 312 94 261 312 minecraft:shroomlight
fill 94 256 313 94 257 314 minecraft:white_concrete
fill 94 256 315 94 257 316 minecraft:red_concrete
fill 95 256 275 95 257 275 minecraft:red_concrete
fill 95 256 317 95 257 317 minecraft:red_concrete
fill 96 256 275 97 257 275 minecraft:white_concrete
fill 96 256 317 96 257 317 minecraft:white_concrete
fill 97 256 317 97 261 317 minecraft:shroomlight
fill 98 256 275 99 257 275 minecraft:red_concrete
fill 98 256 317 99 257 317 minecraft:red_concrete
fill 100 256 275 100 257 275 minecraft:white_concrete
fill 100 256 317 101 257 317 minecraft:white_concrete
fill 101 256 275 101 261 275 minecraft:shroomlight
fill 102 256 275 103 257 275 minecraft:red_concrete
fill 102 256 317 103 257 317 minecraft:red_concrete
fill 104 256 275 105 257 275 minecraft:white_concrete
fill 104 256 317 104 257 317 minecraft:white_concrete
fill 105 256 317 105 261 317 minecraft:shroomlight
fill 106 256 275 107 257 275 minecraft:red_concrete
fill 106 256 317 107 257 317 minecraft:red_concrete
fill 108 256 275 108 257 275 minecraft:white_concrete
fill 108 256 317 109 257 317 minecraft:white_concrete
fill 109 256 275 109 261 275 minecraft:shroomlight
fill 110 256 275 111 257 275 minecraft:red_concrete
fill 110 256 317 111 257 317 minecraft:red_concrete
fill 112 256 275 113 257 275 minecraft:white_concrete
fill 112 256 317 112 257 317 minecraft:white_concrete
fill 113 256 317 113 261 317 minecraft:shroomlight
fill 114 256 275 115 257 275 minecraft:red_concrete
fill 114 256 317 115 257 317 minecraft:red_concrete
fill 116 256 275 116 257 275 minecraft:white_concrete
fill 116 256 317 117 257 317 minecraft:white_concrete
fill 117 256 275 117 261 275 minecraft:shroomlight
fill 118 256 275 119 257 275 minecraft:red_concrete
fill 118 256 317 119 257 317 minecraft:red_concrete
fill 120 256 275 121 257 275 minecraft:white_concrete
fill 120 256 317 120 257 317 minecraft:white_concrete
fill 121 256 317 121 261 317 minecraft:shroomlight
fill 122 256 275 123 257 275 minecraft:red_concrete
fill 122 256 317 123 257 317 minecraft:red_concrete
fill 124 256 275 124 257 275 minecraft:white_concrete
fill 124 256 317 125 257 317 minecraft:white_concrete
fill 125 256 275 125 261 275 minecraft:shroomlight
fill 126 256 275 127 257 275 minecraft:red_concrete
fill 126 256 317 127 257 317 minecraft:red_concrete
fill 128 256 275 129 257 275 minecraft:white_concrete
fill 128 256 317 128 257 317 minecraft:white_concrete
fill 129 256 317 129 261 317 minecraft:shroomlight
fill 130 256 275 131 257 275 minecraft:red_concrete
fill 130 256 317 131 257 317 minecraft:red_concrete
fill 132 256 275 132 257 275 minecraft:white_concrete
fill 132 256 317 133 257 317 minecraft:white_concrete
fill 133 256 275 133 261 275 minecraft:shroomlight
fill 134 256 275 135 257 275 minecraft:red_concrete
fill 134 256 317 135 257 317 minecraft:red_concrete
fill 136 256 276 136 257 276 minecraft:red_concrete
fill 136 256 277 136 257 278 minecraft:white_concrete
fill 136 256 279 136 257 279 minecraft:red_concrete
fill 136 256 280 136 261 280 minecraft:shroomlight
fill 136 256 281 136 257 282 minecraft:white_concrete
fill 136 256 283 136 257 284 minecraft:red_concrete
fill 136 256 285 136 257 286 minecraft:white_concrete
fill 136 256 287 136 257 287 minecraft:red_concrete
fill 136 256 288 136 261 288 minecraft:shroomlight
fill 136 256 289 136 257 290 minecraft:white_concrete
fill 136 256 291 136 257 292 minecraft:red_concrete
fill 136 256 293 136 257 294 minecraft:white_concrete
fill 136 256 295 136 257 295 minecraft:red_concrete
fill 136 256 296 136 261 296 minecraft:shroomlight
fill 136 256 297 136 257 298 minecraft:white_concrete
fill 136 256 299 136 257 300 minecraft:red_concrete
fill 136 256 301 136 257 302 minecraft:white_concrete
fill 136 256 303 136 257 303 minecraft:red_concrete
fill 136 256 304 136 261 304 minecraft:shroomlight
fill 136 256 305 136 257 306 minecraft:white_concrete
fill 136 256 307 136 257 308 minecraft:red_concrete
fill 136 256 309 136 257 310 minecraft:white_concrete
fill 136 256 311 136 257 311 minecraft:red_concrete
fill 136 256 312 136 261 312 minecraft:shroomlight
fill 136 256 313 136 257 314 minecraft:white_concrete
fill 136 256 315 136 257 316 minecraft:red_concrete
fill 136 256 317 136 257 317 minecraft:white_concrete
fill 94 258 275 94 259 276 minecraft:white_concrete
fill 94 258 277 94 259 278 minecraft:red_concrete
fill 94 258 279 94 259 279 minecraft:white_concrete
fill 94 258 281 94 259 282 minecraft:red_concrete
fill 94 258 283 94 259 284 minecraft:white_concrete
fill 94 258 285 94 259 286 minecraft:red_concrete
fill 94 258 287 94 259 287 minecraft:white_concrete
fill 94 258 289 94 259 290 minecraft:red_concrete
fill 94 258 291 94 259 292 minecraft:white_concrete
fill 94 258 293 94 259 294 minecraft:red_concrete
fill 94 258 295 94 259 295 minecraft:white_concrete
fill 94 258 297 94 259 298 minecraft:red_concrete
fill 94 258 299 94 259 300 minecraft:white_concrete
fill 94 258 301 94 259 302 minecraft:red_concrete
fill 94 258 303 94 259 303 minecraft:white_concrete
fill 94 258 305 94 259 306 minecraft:red_concrete
fill 94 258 307 94 259 308 minecraft:white_concrete
fill 94 258 309 94 259 310 minecraft:red_concrete
fill 94 258 311 94 259 311 minecraft:white_concrete
fill 94 258 313 94 259 314 minecraft:red_concrete
fill 94 258 315 94 259 316 minecraft:white_concrete
fill 95 258 275 95 259 275 minecraft:white_concrete
fill 95 258 317 95 259 317 minecraft:white_concrete
fill 96 258 275 97 259 275 minecraft:red_concrete
fill 96 258 317 96 259 317 minecraft:red_concrete
fill 98 258 275 99 259 275 minecraft:white_concrete
fill 98 258 317 99 259 317 minecraft:white_concrete
fill 100 258 275 100 259 275 minecraft:red_concrete
fill 100 258 317 101 259 317 minecraft:red_concrete
fill 102 258 275 103 259 275 minecraft:white_concrete
fill 102 258 317 103 259 317 minecraft:white_concrete
fill 104 258 275 105 259 275 minecraft:red_concrete
fill 104 258 317 104 259 317 minecraft:red_concrete
fill 106 258 275 107 259 275 minecraft:white_concrete
fill 106 258 317 107 259 317 minecraft:white_concrete
fill 108 258 275 108 259 275 minecraft:red_concrete
fill 108 258 317 109 259 317 minecraft:red_concrete
fill 110 258 275 111 259 275 minecraft:white_concrete
fill 110 258 317 111 259 317 minecraft:white_concrete
fill 112 258 275 113 259 275 minecraft:red_concrete
fill 112 258 317 112 259 317 minecraft:red_concrete
fill 114 258 275 115 259 275 minecraft:white_concrete
fill 114 258 317 115 259 317 minecraft:white_concrete
fill 116 258 275 116 259 275 minecraft:red_concrete
fill 116 258 317 117 259 317 minecraft:red_concrete
fill 118 258 275 119 259 275 minecraft:white_concrete
fill 118 258 317 119 259 317 minecraft:white_concrete
fill 120 258 275 121 259 275 minecraft:red_concrete
fill 120 258 317 120 259 317 minecraft:red_concrete
fill 122 258 275 123 259 275 minecraft:white_concrete
fill 122 258 317 123 259 317 minecraft:white_concrete
fill 124 258 275 124 259 275 minecraft:red_concrete
fill 124 258 317 125 259 317 minecraft:red_concrete
fill 126 258 275 127 259 275 minecraft:white_concrete
fill 126 258 317 127 259 317 minecraft:white_concrete
fill 128 258 275 129 259 275 minecraft:red_concrete
fill 128 258 317 128 259 317 minecraft:red_concrete
fill 130 258 275 131 259 275 minecraft:white_concrete
fill 130 258 317 131 259 317 minecraft:white_concrete
fill 132 258 275 132 259 275 minecraft:red_concrete
fill 132 258 317 133 259 317 minecraft:red_concrete
fill 134 258 275 135 259 275 minecraft:white_concrete
fill 134 258 317 135 259 317 minecraft:white_concrete
fill 136 258 276 136 259 276 minecraft:white_concrete
fill 136 258 277 136 259 278 minecraft:red_concrete
fill 136 258 279 136 259 279 minecraft:white_concrete
fill 136 258 281 136 259 282 minecraft:red_concrete
fill 136 258 283 136 259 284 minecraft:white_concrete
fill 136 258 285 136 259 286 minecraft:red_concrete
fill 136 258 287 136 259 287 minecraft:white_concrete
fill 136 258 289 136 259 290 minecraft:red_concrete
fill 136 258 291 136 259 292 minecraft:white_concrete
fill 136 258 293 136 259 294 minecraft:red_concrete
fill 136 258 295 136 259 295 minecraft:white_concrete
fill 136 258 297 136 259 298 minecraft:red_concrete
fill 136 258 299 136 259 300 minecraft:white_concrete
fill 136 258 301 136 259 302 minecraft:red_concrete
fill 136 258 303 136 259 303 minecraft:white_concrete
fill 136 258 305 136 259 306 minecraft:red_concrete
fill 136 258 307 136 259 308 minecraft:white_concrete
fill 136 258 309 136 259 310 minecraft:red_concrete
fill 136 258 311 136 259 311 minecraft:white_concrete
fill 136 258 313 136 259 314 minecraft:red_concrete
fill 136 258 315 136 259 316 minecraft:white_concrete
fill 136 258 317 136 259 317 minecraft:red_concrete
fill 97 259 279 97 259 281 minecraft:brown_terracotta
fill 98 259 278 100 259 278 minecraft:brown_terracotta
fill 98 259 282 100 259 282 minecraft:brown_terracotta
fill 101 259 279 101 259 281 minecraft:brown_terracotta
fill 102 259 301 103 260 301 minecraft:brown_terracotta
fill 94 260 275 94 261 276 minecraft:red_concrete
fill 94 260 277 94 261 278 minecraft:white_concrete
fill 94 260 279 94 261 279 minecraft:red_concrete
fill 94 260 281 94 261 282 minecraft:white_concrete
fill 94 260 283 94 261 284 minecraft:red_concrete
fill 94 260 285 94 261 286 minecraft:white_concrete
fill 94 260 287 94 261 287 minecraft:red_concrete
fill 94 260 289 94 261 290 minecraft:white_concrete
fill 94 260 291 94 261 292 minecraft:red_concrete
fill 94 260 293 94 261 294 minecraft:white_concrete
fill 94 260 295 94 261 295 minecraft:red_concrete
fill 94 260 297 94 261 298 minecraft:white_concrete
fill 94 260 299 94 261 300 minecraft:red_concrete
fill 94 260 301 94 261 302 minecraft:white_concrete
fill 94 260 303 94 261 303 minecraft:red_concrete
fill 94 260 305 94 261 306 minecraft:white_concrete
fill 94 260 307 94 261 308 minecraft:red_concrete
fill 94 260 309 94 261 310 minecraft:white_concrete
fill 94 260 311 94 261 311 minecraft:red_concrete
fill 94 260 313 94 261 314 minecraft:white_concrete
fill 94 260 315 94 261 316 minecraft:red_concrete
fill 95 260 275 95 261 275 minecraft:red_concrete
fill 95 260 317 95 261 317 minecraft:red_concrete
fill 96 260 275 97 261 275 minecraft:white_concrete
fill 96 260 317 96 261 317 minecraft:white_concrete
fill 98 260 275 99 261 275 minecraft:red_concrete
fill 98 260 317 99 261 317 minecraft:red_concrete
fill 100 260 275 100 261 275 minecraft:white_concrete
fill 100 260 317 101 261 317 minecraft:white_concrete
fill 102 260 275 103 261 275 minecraft:red_concrete
fill 102 260 317 103 261 317 minecraft:red_concrete
fill 104 260 275 105 261 275 minecraft:white_concrete
fill 104 260 317 104 261 317 minecraft:white_concrete
fill 106 260 275 107 261 275 minecraft:red_concrete
fill 106 260 317 107 261 317 minecraft:red_concrete
fill 108 260 275 108 261 275 minecraft:white_concrete
fill 108 260 317 109 261 317 minecraft:white_concrete
fill 110 260 275 111 261 275 minecraft:red_concrete
fill 110 260 317 111 261 317 minecraft:red_concrete
fill 112 260 275 113 261 275 minecraft:white_concrete
fill 112 260 317 112 261 317 minecraft:white_concrete
fill 114 260 275 115 261 275 minecraft:red_concrete
fill 114 260 317 115 261 317 minecraft:red_concrete
fill 116 260 275 116 261 275 minecraft:white_concrete
fill 116 260 317 117 261 317 minecraft:white_concrete
fill 118 260 275 119 261 275 minecraft:red_concrete
fill 118 260 317 119 261 317 minecraft:red_concrete
fill 120 260 275 121 261 275 minecraft:white_concrete
fill 120 260 317 120 261 317 minecraft:white_concrete
fill 122 260 275 123 261 275 minecraft:red_concrete
fill 122 260 317 123 261 317 minecraft:red_concrete
fill 124 260 275 124 261 275 minecraft:white_concrete
fill 124 260 317 125 261 317 minecraft:white_concrete
fill 126 260 275 127 261 275 minecraft:red_concrete
fill 126 260 317 127 261 317 minecraft:red_concrete
fill 128 260 275 129 261 275 minecraft:white_concrete
fill 128 260 317 128 261 317 minecraft:white_concrete
fill 130 260 275 131 261 275 minecraft:red_concrete
fill 130 260 317 131 261 317 minecraft:red_concrete
fill 132 260 275 132 261 275 minecraft:white_concrete
fill 132 260 317 133 261 317 minecraft:white_concrete
fill 134 260 275 135 261 275 minecraft:red_concrete
fill 134 260 317 135 261 317 minecraft:red_concrete
fill 136 260 276 136 261 276 minecraft:red_concrete
fill 136 260 277 136 261 278 minecraft:white_concrete
fill 136 260 279 136 261 279 minecraft:red_concrete
fill 136 260 281 136 261 282 minecraft:white_concrete
fill 136 260 283 136 261 284 minecraft:red_concrete
fill 136 260 285 136 261 286 minecraft:white_concrete
fill 136 260 287 136 261 287 minecraft:red_concrete
fill 136 260 289 136 261 290 minecraft:white_concrete
fill 136 260 291 136 261 292 minecraft:red_concrete
fill 136 260 293 136 261 294 minecraft:white_concrete
fill 136 260 295 136 261 295 minecraft:red_concrete
fill 136 260 297 136 261 298 minecraft:white_concrete
fill 136 260 299 136 261 300 minecraft:red_concrete
fill 136 260 301 136 261 302 minecraft:white_concrete
fill 136 260 303 136 261 303 minecraft:red_concrete
fill 136 260 305 136 261 306 minecraft:white_concrete
fill 136 260 307 136 261 308 minecraft:red_concrete
fill 136 260 309 136 261 310 minecraft:white_concrete
fill 136 260 311 136 261 311 minecraft:red_concrete
fill 136 260 313 136 261 314 minecraft:white_concrete
fill 136 260 315 136 261 316 minecraft:red_concrete
fill 136 260 317 136 261 317 minecraft:white_concrete
setblock 97 261 278 minecraft:light[level=15]
setblock 97 261 292 minecraft:light[level=12]
setblock 97 261 294 minecraft:light[level=15]
setblock 97 261 299 minecraft:light[level=12]
setblock 97 261 300 minecraft:red_terracotta
setblock 97 261 302 minecraft:red_terracotta
setblock 97 261 306 minecraft:light[level=12]
setblock 97 261 310 minecraft:light[level=15]
setblock 97 261 313 minecraft:light[level=12]
setblock 99 261 300 minecraft:red_terracotta
setblock 99 261 302 minecraft:red_terracotta
setblock 104 261 278 minecraft:light[level=12]
setblock 104 261 285 minecraft:light[level=12]
setblock 104 261 292 minecraft:light[level=12]
setblock 104 261 299 minecraft:light[level=12]
setblock 104 261 306 minecraft:light[level=12]
setblock 104 261 313 minecraft:light[level=12]
setblock 105 261 278 minecraft:light[level=15]
setblock 105 261 286 minecraft:light[level=15]
setblock 105 261 294 minecraft:light[level=15]
setblock 105 261 302 minecraft:light[level=15]
setblock 105 261 310 minecraft:light[level=15]
setblock 111 261 278 minecraft:light[level=12]
setblock 111 261 285 minecraft:light[level=12]
setblock 111 261 292 minecraft:light[level=12]
setblock 111 261 299 minecraft:light[level=12]
setblock 111 261 306 minecraft:light[level=12]
setblock 111 261 313 minecraft:light[level=12]
setblock 113 261 278 minecraft:light[level=15]
setblock 113 261 286 minecraft:light[level=15]
setblock 113 261 294 minecraft:light[level=15]
setblock 113 261 302 minecraft:light[level=15]
setblock 113 261 310 minecraft:light[level=15]
setblock 118 261 278 minecraft:light[level=12]
setblock 118 261 285 minecraft:light[level=12]
setblock 118 261 292 minecraft:light[level=12]
setblock 118 261 299 minecraft:light[level=12]
setblock 118 261 306 minecraft:light[level=12]
setblock 118 261 313 minecraft:light[level=12]
setblock 121 261 278 minecraft:light[level=15]
setblock 121 261 286 minecraft:light[level=15]
setblock 121 261 294 minecraft:light[level=15]
setblock 121 261 302 minecraft:light[level=15]
setblock 121 261 310 minecraft:light[level=15]
setblock 125 261 278 minecraft:light[level=12]
setblock 125 261 285 minecraft:light[level=12]
setblock 125 261 292 minecraft:light[level=12]
setblock 125 261 299 minecraft:light[level=12]
setblock 125 261 306 minecraft:light[level=12]
setblock 125 261 313 minecraft:light[level=12]
setblock 129 261 278 minecraft:light[level=15]
setblock 129 261 286 minecraft:light[level=15]
setblock 129 261 294 minecraft:light[level=15]
setblock 129 261 302 minecraft:light[level=15]
setblock 129 261 310 minecraft:light[level=15]
setblock 132 261 278 minecraft:light[level=12]
setblock 132 261 285 minecraft:light[level=12]
setblock 132 261 292 minecraft:light[level=12]
setblock 132 261 299 minecraft:light[level=12]
setblock 132 261 306 minecraft:light[level=12]
setblock 132 261 313 minecraft:light[level=12]
fill 94 262 275 94 263 276 minecraft:white_concrete
fill 94 262 277 94 263 278 minecraft:red_concrete
fill 94 262 279 94 263 280 minecraft:white_concrete
fill 94 262 281 94 263 282 minecraft:red_concrete
fill 94 262 283 94 263 284 minecraft:white_concrete
fill 94 262 285 94 263 286 minecraft:red_concrete
fill 94 262 287 94 263 288 minecraft:white_concrete
fill 94 262 289 94 263 290 minecraft:red_concrete
fill 94 262 291 94 263 292 minecraft:white_concrete
fill 94 262 293 94 263 294 minecraft:red_concrete
fill 94 262 295 94 263 296 minecraft:white_concrete
fill 94 262 297 94 263 298 minecraft:red_concrete
fill 94 262 299 94 263 300 minecraft:white_concrete
fill 94 262 301 94 263 302 minecraft:red_concrete
fill 94 262 303 94 263 304 minecraft:white_concrete
fill 94 262 305 94 263 306 minecraft:red_concrete
fill 94 262 307 94 263 308 minecraft:white_concrete
fill 94 262 309 94 263 310 minecraft:red_concrete
fill 94 262 311 94 263 312 minecraft:white_concrete
fill 94 262 313 94 263 314 minecraft:red_concrete
fill 94 262 315 94 263 316 minecraft:white_concrete
fill 95 262 275 95 263 275 minecraft:white_concrete
fill 95 262 317 95 263 317 minecraft:white_concrete
fill 96 262 275 97 263 275 minecraft:red_concrete
fill 96 262 317 97 263 317 minecraft:red_concrete
fill 98 262 275 99 263 275 minecraft:white_concrete
fill 98 262 317 99 263 317 minecraft:white_concrete
fill 100 262 275 101 263 275 minecraft:red_concrete
fill 100 262 317 101 263 317 minecraft:red_concrete
fill 102 262 275 103 263 275 minecraft:white_concrete
fill 102 262 317 103 263 317 minecraft:white_concrete
fill 104 262 275 105 263 275 minecraft:red_concrete
fill 104 262 317 105 263 317 minecraft:red_concrete
fill 106 262 275 107 263 275 minecraft:white_concrete
fill 106 262 317 107 263 317 minecraft:white_concrete
fill 108 262 275 109 263 275 minecraft:red_concrete
fill 108 262 317 109 263 317 minecraft:red_concrete
fill 110 262 275 111 263 275 minecraft:white_concrete
fill 110 262 317 111 263 317 minecraft:white_concrete
fill 112 262 275 113 263 275 minecraft:red_concrete
fill 112 262 317 113 263 317 minecraft:red_concrete
fill 114 262 275 115 263 275 minecraft:white_concrete
fill 114 262 277 114 262 279 minecraft:red_terracotta
fill 114 262 317 115 263 317 minecraft:white_concrete
fill 115 262 277 116 262 277 minecraft:red_terracotta
fill 115 262 279 116 262 279 minecraft:red_terracotta
fill 116 262 275 117 263 275 minecraft:red_concrete
setblock 116 262 278 minecraft:red_terracotta
fill 116 262 317 117 263 317 minecraft:red_concrete
fill 118 262 275 119 263 275 minecraft:white_concrete
fill 118 262 317 119 263 317 minecraft:white_concrete
fill 120 262 275 121 263 275 minecraft:red_concrete
fill 120 262 317 121 263 317 minecraft:red_concrete
fill 122 262 275 123 263 275 minecraft:white_concrete
fill 122 262 317 123 263 317 minecraft:white_concrete
fill 124 262 275 125 263 275 minecraft:red_concrete
fill 124 262 317 125 263 317 minecraft:red_concrete
fill 126 262 275 127 263 275 minecraft:white_concrete
fill 126 262 317 127 263 317 minecraft:white_concrete
fill 128 262 275 129 263 275 minecraft:red_concrete
fill 128 262 317 129 263 317 minecraft:red_concrete
fill 130 262 275 131 263 275 minecraft:white_concrete
fill 130 262 317 131 263 317 minecraft:white_concrete
fill 132 262 275 133 263 275 minecraft:red_concrete
fill 132 262 317 133 263 317 minecraft:red_concrete
fill 134 262 275 135 263 275 minecraft:white_concrete
fill 134 262 317 135 263 317 minecraft:white_concrete
fill 136 262 276 136 263 276 minecraft:white_concrete
fill 136 262 277 136 263 278 minecraft:red_concrete
fill 136 262 279 136 263 280 minecraft:white_concrete
fill 136 262 281 136 263 282 minecraft:red_concrete
fill 136 262 283 136 263 284 minecraft:white_concrete
fill 136 262 285 136 263 286 minecraft:red_concrete
fill 136 262 287 136 263 288 minecraft:white_concrete
fill 136 262 289 136 263 290 minecraft:red_concrete
fill 136 262 291 136 263 292 minecraft:white_concrete
fill 136 262 293 136 263 294 minecraft:red_concrete
fill 136 262 295 136 263 296 minecraft:white_concrete
fill 136 262 297 136 263 298 minecraft:red_concrete
fill 136 262 299 136 263 300 minecraft:white_concrete
fill 136 262 301 136 263 302 minecraft:red_concrete
fill 136 262 303 136 263 304 minecraft:white_concrete
fill 136 262 305 136 263 306 minecraft:red_concrete
fill 136 262 307 136 263 308 minecraft:white_concrete
fill 136 262 309 136 263 310 minecraft:red_concrete
fill 136 262 311 136 263 312 minecraft:white_concrete
fill 136 262 313 136 263 314 minecraft:red_concrete
fill 136 262 315 136 263 316 minecraft:white_concrete
fill 136 262 317 136 263 317 minecraft:red_concrete
fill 129 263 302 129 266 302 minecraft:iron_block
fill 94 264 275 94 265 276 minecraft:red_concrete
fill 94 264 277 94 265 278 minecraft:white_concrete
fill 94 264 279 94 265 280 minecraft:red_concrete
fill 94 264 281 94 265 282 minecraft:white_concrete
fill 94 264 283 94 265 284 minecraft:red_concrete
fill 94 264 285 94 265 286 minecraft:white_concrete
fill 94 264 287 94 265 288 minecraft:red_concrete
fill 94 264 289 94 265 290 minecraft:white_concrete
fill 94 264 291 94 265 292 minecraft:red_concrete
fill 94 264 293 94 265 294 minecraft:white_concrete
fill 94 264 295 94 265 296 minecraft:red_concrete
fill 94 264 297 94 265 298 minecraft:white_concrete
fill 94 264 299 94 265 300 minecraft:red_concrete
fill 94 264 301 94 265 302 minecraft:white_concrete
fill 94 264 303 94 265 304 minecraft:red_concrete
fill 94 264 305 94 265 306 minecraft:white_concrete
fill 94 264 307 94 265 308 minecraft:red_concrete
fill 94 264 309 94 265 310 minecraft:white_concrete
fill 94 264 311 94 265 312 minecraft:red_concrete
fill 94 264 313 94 265 314 minecraft:white_concrete
fill 94 264 315 94 265 316 minecraft:red_concrete
fill 95 264 275 95 265 275 minecraft:red_concrete
fill 95 264 317 95 265 317 minecraft:red_concrete
fill 96 264 275 97 265 275 minecraft:white_concrete
fill 96 264 317 97 265 317 minecraft:white_concrete
fill 98 264 275 99 265 275 minecraft:red_concrete
fill 98 264 317 99 265 317 minecraft:red_concrete
fill 100 264 275 101 265 275 minecraft:white_concrete
fill 100 264 317 101 265 317 minecraft:white_concrete
fill 102 264 275 103 265 275 minecraft:red_concrete
fill 102 264 317 103 265 317 minecraft:red_concrete
fill 104 264 275 105 265 275 minecraft:white_concrete
fill 104 264 317 105 265 317 minecraft:white_concrete
fill 106 264 275 107 265 275 minecraft:red_concrete
fill 106 264 317 107 265 317 minecraft:red_concrete
fill 108 264 275 109 265 275 minecraft:white_concrete
fill 108 264 317 109 265 317 minecraft:white_concrete
fill 110 264 275 111 265 275 minecraft:red_concrete
fill 110 264 317 111 265 317 minecraft:red_concrete
fill 112 264 275 113 265 275 minecraft:white_concrete
fill 112 264 317 113 265 317 minecraft:white_concrete
fill 114 264 275 115 265 275 minecraft:red_concrete
fill 114 264 317 115 265 317 minecraft:red_concrete
fill 116 264 275 117 265 275 minecraft:white_concrete
fill 116 264 317 117 265 317 minecraft:white_concrete
fill 118 264 275 119 265 275 minecraft:red_concrete
fill 118 264 317 119 265 317 minecraft:red_concrete
fill 120 264 275 121 265 275 minecraft:white_concrete
fill 120 264 317 121 265 317 minecraft:white_concrete
fill 122 264 275 123 265 275 minecraft:red_concrete
fill 122 264 317 123 265 317 minecraft:red_concrete
fill 124 264 275 125 265 275 minecraft:white_concrete
fill 124 264 317 125 265 317 minecraft:white_concrete
fill 126 264 275 127 265 275 minecraft:red_concrete
fill 126 264 317 127 265 317 minecraft:red_concrete
fill 128 264 275 129 265 275 minecraft:white_concrete
fill 128 264 317 129 265 317 minecraft:white_concrete
fill 130 264 275 131 265 275 minecraft:red_concrete
fill 130 264 317 131 265 317 minecraft:red_concrete
fill 132 264 275 133 265 275 minecraft:white_concrete
fill 132 264 317 133 265 317 minecraft:white_concrete
fill 134 264 275 135 265 275 minecraft:red_concrete
fill 134 264 317 135 265 317 minecraft:red_concrete
fill 136 264 276 136 265 276 minecraft:red_concrete
fill 136 264 277 136 265 278 minecraft:white_concrete
fill 136 264 279 136 265 280 minecraft:red_concrete
fill 136 264 281 136 265 282 minecraft:white_concrete
fill 136 264 283 136 265 284 minecraft:red_concrete
fill 136 264 285 136 265 286 minecraft:white_concrete
fill 136 264 287 136 265 288 minecraft:red_concrete
fill 136 264 289 136 265 290 minecraft:white_concrete
fill 136 264 291 136 265 292 minecraft:red_concrete
fill 136 264 293 136 265 294 minecraft:white_concrete
fill 136 264 295 136 265 296 minecraft:red_concrete
fill 136 264 297 136 265 298 minecraft:white_concrete
fill 136 264 299 136 265 300 minecraft:red_concrete
fill 136 264 301 136 265 302 minecraft:white_concrete
fill 136 264 303 136 265 304 minecraft:red_concrete
fill 136 264 305 136 265 306 minecraft:white_concrete
fill 136 264 307 136 265 308 minecraft:red_concrete
fill 136 264 309 136 265 310 minecraft:white_concrete
fill 136 264 311 136 265 312 minecraft:red_concrete
fill 136 264 313 136 265 314 minecraft:white_concrete
fill 136 264 315 136 265 316 minecraft:red_concrete
fill 136 264 317 136 265 317 minecraft:white_concrete
fill 94 266 275 94 267 276 minecraft:white_concrete
fill 94 266 277 94 267 278 minecraft:red_concrete
fill 94 266 279 94 267 280 minecraft:white_concrete
fill 94 266 281 94 267 282 minecraft:red_concrete
fill 94 266 283 94 267 284 minecraft:white_concrete
fill 94 266 285 94 267 286 minecraft:red_concrete
fill 94 266 287 94 267 288 minecraft:white_concrete
fill 94 266 289 94 267 290 minecraft:red_concrete
fill 94 266 291 94 267 292 minecraft:white_concrete
fill 94 266 293 94 267 294 minecraft:red_concrete
fill 94 266 295 94 267 296 minecraft:white_concrete
fill 94 266 297 94 267 298 minecraft:red_concrete
fill 94 266 299 94 267 300 minecraft:white_concrete
fill 94 266 301 94 267 302 minecraft:red_concrete
fill 94 266 303 94 267 304 minecraft:white_concrete
fill 94 266 305 94 267 306 minecraft:red_concrete
fill 94 266 307 94 267 308 minecraft:white_concrete
fill 94 266 309 94 267 310 minecraft:red_concrete
fill 94 266 311 94 267 312 minecraft:white_concrete
fill 94 266 313 94 267 314 minecraft:red_concrete
fill 94 266 315 94 267 316 minecraft:white_concrete
fill 95 266 275 95 267 275 minecraft:white_concrete
fill 95 266 276 95 267 281 minecraft:red_terracotta
fill 95 266 284 96 266 284 minecraft:red_terracotta
fill 95 266 288 95 267 289 minecraft:red_terracotta
fill 95 266 292 96 266 297 minecraft:red_terracotta
fill 95 266 300 96 266 305 minecraft:red_terracotta
fill 95 266 308 96 266 313 minecraft:red_terracotta
fill 95 266 316 100 267 316 minecraft:red_terracotta
fill 95 266 317 95 267 317 minecraft:white_concrete
fill 96 266 275 97 267 275 minecraft:red_concrete
fill 96 266 277 96 266 283 minecraft:red_terracotta
fill 96 266 289 96 266 291 minecraft:red_terracotta
fill 96 266 298 96 266 299 minecraft:red_terracotta
fill 96 266 306 96 266 307 minecraft:red_terracotta
fill 96 266 314 96 266 315 minecraft:red_terracotta
fill 96 266 317 97 267 317 minecraft:red_concrete
fill 97 266 277 134 266 277 minecraft:red_terracotta
fill 97 266 315 135 266 315 minecraft:red_terracotta
fill 98 266 275 99 267 275 minecraft:white_concrete
fill 98 266 276 103 267 276 minecraft:red_terracotta
fill 98 266 317 99 267 317 minecraft:white_concrete
fill 100 266 275 101 267 275 minecraft:red_concrete
fill 100 266 317 101 267 317 minecraft:red_concrete
fill 102 266 275 103 267 275 minecraft:white_concrete
fill 102 266 317 103 267 317 minecraft:white_concrete
fill 103 266 316 108 267 316 minecraft:red_terracotta
fill 104 266 275 105 267 275 minecraft:red_concrete
fill 104 266 317 105 267 317 minecraft:red_concrete
fill 106 266 275 107 267 275 minecraft:white_concrete
fill 106 266 276 111 267 276 minecraft:red_terracotta
fill 106 266 317 107 267 317 minecraft:white_concrete
fill 108 266 275 109 267 275 minecraft:red_concrete
fill 108 266 317 109 267 317 minecraft:red_concrete
fill 110 266 275 111 267 275 minecraft:white_concrete
fill 110 266 317 111 267 317 minecraft:white_concrete
fill 111 266 316 116 267 316 minecraft:red_terracotta
fill 112 266 275 113 267 275 minecraft:red_concrete
fill 112 266 317 113 267 317 minecraft:red_concrete
fill 114 266 275 115 267 275 minecraft:white_concrete
fill 114 266 276 119 267 276 minecraft:red_terracotta
fill 114 266 317 115 267 317 minecraft:white_concrete
fill 116 266 275 117 267 275 minecraft:red_concrete
fill 116 266 317 117 267 317 minecraft:red_concrete
fill 118 266 275 119 267 275 minecraft:white_concrete
fill 118 266 317 119 267 317 minecraft:white_concrete
fill 119 266 316 124 267 316 minecraft:red_terracotta
fill 120 266 275 121 267 275 minecraft:red_concrete
fill 120 266 317 121 267 317 minecraft:red_concrete
fill 122 266 275 123 267 275 minecraft:white_concrete
fill 122 266 276 127 267 276 minecraft:red_terracotta
fill 122 266 317 123 267 317 minecraft:white_concrete
fill 124 266 275 125 267 275 minecraft:red_concrete
fill 124 266 317 125 267 317 minecraft:red_concrete
fill 126 266 275 127 267 275 minecraft:white_concrete
fill 126 266 317 127 267 317 minecraft:white_concrete
fill 127 266 316 132 267 316 minecraft:red_terracotta
fill 128 266 275 129 267 275 minecraft:red_concrete
fill 128 266 317 129 267 317 minecraft:red_concrete
fill 130 266 275 131 267 275 minecraft:white_concrete
fill 130 266 276 135 267 276 minecraft:red_terracotta
fill 130 266 317 131 267 317 minecraft:white_concrete
fill 132 266 275 133 267 275 minecraft:red_concrete
fill 132 266 317 133 267 317 minecraft:red_concrete
fill 134 266 275 135 267 275 minecraft:white_concrete
fill 134 266 278 134 266 314 minecraft:red_terracotta
fill 134 266 317 135 267 317 minecraft:white_concrete
fill 135 266 279 135 267 284 minecraft:red_terracotta
fill 135 266 287 135 267 292 minecraft:red_terracotta
fill 135 266 295 135 267 300 minecraft:red_terracotta
fill 135 266 303 135 267 308 minecraft:red_terracotta
fill 135 266 311 135 267 314 minecraft:red_terracotta
fill 135 266 316 135 267 316 minecraft:red_terracotta
fill 136 266 276 136 267 276 minecraft:white_concrete
fill 136 266 277 136 267 278 minecraft:red_concrete
fill 136 266 279 136 267 280 minecraft:white_concrete
fill 136 266 281 136 267 282 minecraft:red_concrete
fill 136 266 283 136 267 284 minecraft:white_concrete
fill 136 266 285 136 267 286 minecraft:red_concrete
fill 136 266 287 136 267 288 minecraft:white_concrete
fill 136 266 289 136 267 290 minecraft:red_concrete
fill 136 266 291 136 267 292 minecraft:white_concrete
fill 136 266 293 136 267 294 minecraft:red_concrete
fill 136 266 295 136 267 296 minecraft:white_concrete
fill 136 266 297 136 267 298 minecraft:red_concrete
fill 136 266 299 136 267 300 minecraft:white_concrete
fill 136 266 301 136 267 302 minecraft:red_concrete
fill 136 266 303 136 267 304 minecraft:white_concrete
fill 136 266 305 136 267 306 minecraft:red_concrete
fill 136 266 307 136 267 308 minecraft:white_concrete
fill 136 266 309 136 267 310 minecraft:red_concrete
fill 136 266 311 136 267 312 minecraft:white_concrete
fill 136 266 313 136 267 314 minecraft:red_concrete
fill 136 266 315 136 267 316 minecraft:white_concrete
fill 136 266 317 136 267 317 minecraft:red_concrete
setblock 95 267 284 minecraft:red_terracotta
fill 95 267 292 95 267 297 minecraft:red_terracotta
fill 95 267 300 95 267 305 minecraft:red_terracotta
fill 95 267 308 95 267 313 minecraft:red_terracotta
setblock 97 267 278 minecraft:light[level=12]
fill 97 267 279 97 267 281 minecraft:brown_terracotta
setblock 97 267 292 minecraft:light[level=12]
setblock 97 267 299 minecraft:light[level=12]
setblock 97 267 306 minecraft:light[level=12]
setblock 97 267 313 minecraft:light[level=12]
fill 98 267 278 100 267 278 minecraft:brown_terracotta
fill 98 267 282 100 267 282 minecraft:brown_terracotta
fill 101 267 279 101 267 281 minecraft:brown_terracotta
setblock 104 267 278 minecraft:light[level=12]
setblock 104 267 285 minecraft:light[level=12]
setblock 104 267 292 minecraft:light[level=12]
setblock 104 267 299 minecraft:light[level=12]
setblock 104 267 306 minecraft:light[level=12]
setblock 104 267 313 minecraft:light[level=12]
setblock 111 267 278 minecraft:light[level=12]
setblock 111 267 285 minecraft:light[level=12]
setblock 111 267 292 minecraft:light[level=12]
setblock 111 267 299 minecraft:light[level=12]
setblock 111 267 306 minecraft:light[level=12]
setblock 111 267 313 minecraft:light[level=12]
setblock 118 267 278 minecraft:light[level=12]
setblock 118 267 285 minecraft:light[level=12]
setblock 118 267 292 minecraft:light[level=12]
setblock 118 267 299 minecraft:light[level=12]
setblock 118 267 306 minecraft:light[level=12]
setblock 118 267 313 minecraft:light[level=12]
setblock 125 267 278 minecraft:light[level=12]
setblock 125 267 285 minecraft:light[level=12]
setblock 125 267 292 minecraft:light[level=12]
setblock 125 267 299 minecraft:light[level=12]
setblock 125 267 306 minecraft:light[level=12]
setblock 125 267 313 minecraft:light[level=12]
fill 129 267 297 134 267 307 minecraft:brown_terracotta
setblock 132 267 278 minecraft:light[level=12]
setblock 132 267 285 minecraft:light[level=12]
setblock 132 267 292 minecraft:light[level=12]
setblock 132 267 313 minecraft:light[level=12]
setblock 135 267 315 minecraft:red_terracotta
fill 94 268 275 94 269 276 minecraft:red_concrete
fill 94 268 277 94 269 278 minecraft:white_concrete
fill 94 268 279 94 269 280 minecraft:red_concrete
fill 94 268 281 94 269 282 minecraft:white_concrete
fill 94 268 283 94 269 284 minecraft:red_concrete
fill 94 268 285 94 269 286 minecraft:white_concrete
fill 94 268 287 94 269 288 minecraft:red_concrete
fill 94 268 289 94 269 290 minecraft:white_concrete
fill 94 268 291 94 269 292 minecraft:red_concrete
fill 94 268 293 94 269 294 minecraft:white_concrete
fill 94 268 295 94 269 296 minecraft:red_concrete
fill 94 268 297 94 269 298 minecraft:white_concrete
fill 94 268 299 94 269 300 minecraft:red_concrete
fill 94 268 301 94 269 302 minecraft:white_concrete
fill 94 268 303 94 269 304 minecraft:red_concrete
fill 94 268 305 94 269 306 minecraft:white_concrete
fill 94 268 307 94 269 308 minecraft:red_concrete
fill 94 268 309 94 269 310 minecraft:white_concrete
fill 94 268 311 94 269 312 minecraft:red_concrete
fill 94 268 313 94 269 314 minecraft:white_concrete
fill 94 268 315 94 269 316 minecraft:red_concrete
fill 95 268 275 95 269 275 minecraft:red_concrete
fill 95 268 317 95 269 317 minecraft:red_concrete
fill 96 268 275 97 269 275 minecraft:white_concrete
fill 96 268 317 97 269 317 minecraft:white_concrete
fill 98 268 275 99 269 275 minecraft:red_concrete
fill 98 268 317 99 269 317 minecraft:red_concrete
fill 100 268 275 101 269 275 minecraft:white_concrete
fill 100 268 317 101 269 317 minecraft:white_concrete
fill 102 268 275 103 269 275 minecraft:red_concrete
fill 102 268 317 103 269 317 minecraft:red_concrete
fill 104 268 275 105 269 275 minecraft:white_concrete
fill 104 268 317 105 269 317 minecraft:white_concrete
fill 106 268 275 107 269 275 minecraft:red_concrete
fill 106 268 317 107 269 317 minecraft:red_concrete
fill 108 268 275 109 269 275 minecraft:white_concrete
fill 108 268 317 109 269 317 minecraft:white_concrete
fill 110 268 275 111 269 275 minecraft:red_concrete
fill 110 268 317 111 269 317 minecraft:red_concrete
fill 112 268 275 113 269 275 minecraft:white_concrete
fill 112 268 317 113 269 317 minecraft:white_concrete
fill 114 268 275 115 269 275 minecraft:red_concrete
fill 114 268 317 115 269 317 minecraft:red_concrete
fill 116 268 275 117 269 275 minecraft:white_concrete
fill 116 268 317 117 269 317 minecraft:white_concrete
fill 118 268 275 119 269 275 minecraft:red_concrete
fill 118 268 317 119 269 317 minecraft:red_concrete
fill 120 268 275 121 269 275 minecraft:white_concrete
fill 120 268 317 121 269 317 minecraft:white_concrete
fill 122 268 275 123 269 275 minecraft:red_concrete
fill 122 268 317 123 269 317 minecraft:red_concrete
fill 124 268 275 125 269 275 minecraft:white_concrete
fill 124 268 317 125 269 317 minecraft:white_concrete
fill 126 268 275 127 269 275 minecraft:red_concrete
fill 126 268 317 127 269 317 minecraft:red_concrete
fill 128 268 275 129 269 275 minecraft:white_concrete
fill 128 268 317 129 269 317 minecraft:white_concrete
fill 129 268 297 134 268 307 minecraft:red_terracotta
fill 130 268 275 131 269 275 minecraft:red_concrete
fill 130 268 317 131 269 317 minecraft:red_concrete
fill 132 268 275 133 269 275 minecraft:white_concrete
fill 132 268 317 133 269 317 minecraft:white_concrete
fill 134 268 275 135 269 275 minecraft:red_concrete
fill 134 268 317 135 269 317 minecraft:red_concrete
fill 136 268 276 136 269 276 minecraft:red_concrete
fill 136 268 277 136 269 278 minecraft:white_concrete
fill 136 268 279 136 269 280 minecraft:red_concrete
fill 136 268 281 136 269 282 minecraft:white_concrete
fill 136 268 283 136 269 284 minecraft:red_concrete
fill 136 268 285 136 269 286 minecraft:white_concrete
fill 136 268 287 136 269 288 minecraft:red_concrete
fill 136 268 289 136 269 290 minecraft:white_concrete
fill 136 268 291 136 269 292 minecraft:red_concrete
fill 136 268 293 136 269 294 minecraft:white_concrete
fill 136 268 295 136 269 296 minecraft:red_concrete
fill 136 268 297 136 269 298 minecraft:white_concrete
fill 136 268 299 136 269 300 minecraft:red_concrete
fill 136 268 301 136 269 302 minecraft:white_concrete
fill 136 268 303 136 269 304 minecraft:red_concrete
fill 136 268 305 136 269 306 minecraft:white_concrete
fill 136 268 307 136 269 308 minecraft:red_concrete
fill 136 268 309 136 269 310 minecraft:white_concrete
fill 136 268 311 136 269 312 minecraft:red_concrete
fill 136 268 313 136 269 314 minecraft:white_concrete
fill 136 268 315 136 269 316 minecraft:red_concrete
fill 136 268 317 136 269 317 minecraft:white_concrete
fill 95 269 284 96 271 284 minecraft:yellow_concrete
fill 95 269 288 95 270 289 minecraft:yellow_concrete
fill 96 269 283 99 269 283 minecraft:yellow_concrete
fill 96 269 289 98 269 290 minecraft:yellow_concrete
setblock 97 269 278 minecraft:light[level=15]
setblock 97 269 282 minecraft:yellow_concrete
setblock 97 269 294 minecraft:light[level=15]
setblock 97 269 300 minecraft:red_terracotta
setblock 97 269 302 minecraft:red_terracotta
setblock 97 269 310 minecraft:light[level=15]
fill 98 269 284 100 269 284 minecraft:yellow_concrete
fill 99 269 285 101 269 285 minecraft:yellow_concrete
fill 99 269 288 100 269 289 minecraft:yellow_concrete
setblock 99 269 300 minecraft:red_terracotta
setblock 99 269 302 minecraft:red_terracotta
fill 100 269 286 101 269 287 minecraft:yellow_concrete
setblock 105 269 278 minecraft:light[level=15]
setblock 105 269 286 minecraft:light[level=15]
setblock 105 269 294 minecraft:light[level=15]
setblock 105 269 302 minecraft:light[level=15]
setblock 105 269 310 minecraft:light[level=15]
setblock 113 269 278 minecraft:light[level=15]
setblock 113 269 286 minecraft:light[level=15]
setblock 113 269 294 minecraft:light[level=15]
setblock 113 269 302 minecraft:light[level=15]
setblock 113 269 310 minecraft:light[level=15]
fill 114 269 277 114 269 279 minecraft:red_terracotta
fill 115 269 277 116 269 277 minecraft:red_terracotta
fill 115 269 279 116 269 279 minecraft:red_terracotta
setblock 116 269 278 minecraft:red_terracotta
setblock 121 269 278 minecraft:light[level=15]
setblock 121 269 286 minecraft:light[level=15]
setblock 121 269 294 minecraft:light[level=15]
setblock 121 269 302 minecraft:light[level=15]
setblock 121 269 310 minecraft:light[level=15]
fill 124 269 291 125 269 292 minecraft:yellow_concrete
fill 125 269 289 125 269 290 minecraft:yellow_concrete
fill 125 269 293 128 269 293 minecraft:yellow_concrete
fill 126 269 289 128 269 289 minecraft:yellow_concrete
fill 126 269 294 127 269 294 minecraft:yellow_concrete
fill 128 269 290 129 269 290 minecraft:yellow_concrete
setblock 129 269 278 minecraft:light[level=15]
setblock 129 269 286 minecraft:light[level=15]
fill 129 269 291 129 270 292 minecraft:yellow_concrete
setblock 129 269 294 minecraft:light[level=15]
fill 129 269 297 129 269 307 minecraft:yellow_concrete
setblock 129 269 310 minecraft:light[level=15]
fill 135 269 301 135 272 303 minecraft:shroomlight
fill 94 270 275 94 271 276 minecraft:white_concrete
fill 94 270 277 94 271 278 minecraft:red_concrete
fill 94 270 279 94 271 279 minecraft:white_concrete
fill 94 270 280 94 272 280 minecraft:shroomlight
fill 94 270 281 94 271 282 minecraft:red_concrete
fill 94 270 283 94 271 284 minecraft:white_concrete
fill 94 270 285 94 271 286 minecraft:red_concrete
fill 94 270 287 94 271 287 minecraft:white_concrete
fill 94 270 288 94 272 288 minecraft:shroomlight
fill 94 270 289 94 271 290 minecraft:red_concrete
fill 94 270 291 94 271 292 minecraft:white_concrete
fill 94 270 293 94 271 294 minecraft:red_concrete
fill 94 270 295 94 271 295 minecraft:white_concrete
fill 94 270 296 94 272 296 minecraft:shroomlight
fill 94 270 297 94 271 298 minecraft:red_concrete
fill 94 270 299 94 271 300 minecraft:white_concrete
fill 94 270 301 94 271 302 minecraft:red_concrete
fill 94 270 303 94 271 303 minecraft:white_concrete
fill 94 270 304 94 272 304 minecraft:shroomlight
fill 94 270 305 94 271 306 minecraft:red_concrete
fill 94 270 307 94 271 308 minecraft:white_concrete
fill 94 270 309 94 271 310 minecraft:red_concrete
fill 94 270 311 94 271 311 minecraft:white_concrete
fill 94 270 312 94 272 312 minecraft:shroomlight
fill 94 270 313 94 271 314 minecraft:red_concrete
fill 94 270 315 94 271 316 minecraft:white_concrete
fill 95 270 275 95 271 275 minecraft:white_concrete
fill 95 270 317 95 271 317 minecraft:white_concrete
fill 96 270 275 97 271 275 minecraft:red_concrete
fill 96 270 283 98 270 283 minecraft:yellow_concrete
fill 96 270 289 99 270 289 minecraft:yellow_concrete
fill 96 270 317 96 271 317 minecraft:red_concrete
fill 97 270 317 97 272 317 minecraft:shroomlight
fill 98 270 275 99 271 275 minecraft:white_concrete
fill 98 270 284 99 270 284 minecraft:yellow_concrete
fill 98 270 317 99 271 317 minecraft:white_concrete
fill 99 270 285 100 270 285 minecraft:yellow_concrete
fill 99 270 288 100 270 288 minecraft:yellow_concrete
fill 100 270 275 100 271 275 minecraft:red_concrete
fill 100 270 286 100 270 287 minecraft:yellow_concrete
fill 100 270 317 101 271 317 minecraft:red_concrete
fill 101 270 275 101 272 275 minecraft:shroomlight
fill 102 270 275 103 271 275 minecraft:white_concrete
fill 102 270 317 103 271 317 minecraft:white_concrete
fill 104 270 275 105 271 275 minecraft:red_concrete
fill 104 270 317 104 271 317 minecraft:red_concrete
fill 105 270 317 105 272 317 minecraft:shroomlight
fill 106 270 275 107 271 275 minecraft:white_concrete
fill 106 270 317 107 271 317 minecraft:white_concrete
fill 108 270 275 108 271 275 minecraft:red_concrete
fill 108 270 317 109 271 317 minecraft:red_concrete
fill 109 270 275 109 272 275 minecraft:shroomlight
fill 110 270 275 111 271 275 minecraft:white_concrete
fill 110 270 317 111 271 317 minecraft:white_concrete
fill 112 270 275 113 271 275 minecraft:red_concrete
fill 112 270 317 112 271 317 minecraft:red_concrete
fill 113 270 317 113 272 317 minecraft:shroomlight
fill 114 270 275 115 271 275 minecraft:white_concrete
fill 114 270 317 115 271 317 minecraft:white_concrete
fill 116 270 275 116 271 275 minecraft:red_concrete
fill 116 270 317 117 271 317 minecraft:red_concrete
fill 117 270 275 117 272 275 minecraft:shroomlight
fill 118 270 275 119 271 275 minecraft:white_concrete
fill 118 270 317 119 271 317 minecraft:white_concrete
fill 120 270 275 121 271 275 minecraft:red_concrete
fill 120 270 317 120 271 317 minecraft:red_concrete
fill 121 270 317 121 272 317 minecraft:shroomlight
fill 122 270 275 123 271 275 minecraft:white_concrete
fill 122 270 317 123 271 317 minecraft:white_concrete
fill 124 270 275 124 271 275 minecraft:red_concrete
fill 124 270 317 125 271 317 minecraft:red_concrete
fill 125 270 275 125 272 275 minecraft:shroomlight
fill 125 270 290 125 270 292 minecraft:yellow_concrete
fill 126 270 275 127 271 275 minecraft:white_concrete
fill 126 270 289 127 270 289 minecraft:yellow_concrete
fill 126 270 293 128 270 293 minecraft:yellow_concrete
fill 126 270 317 127 271 317 minecraft:white_concrete
fill 128 270 275 129 271 275 minecraft:red_concrete
fill 128 270 290 128 271 290 minecraft:yellow_concrete
fill 128 270 317 128 271 317 minecraft:red_concrete
setblock 129 270 297 minecraft:red_terracotta
setblock 129 270 302 minecraft:red_terracotta
setblock 129 270 307 minecraft:red_terracotta
fill 129 270 317 129 272 317 minecraft:shroomlight
fill 130 270 275 131 271 275 minecraft:white_concrete
fill 130 270 317 131 271 317 minecraft:white_concrete
fill 132 270 275 132 271 275 minecraft:red_concrete
fill 132 270 317 133 271 317 minecraft:red_concrete
fill 133 270 275 133 272 275 minecraft:shroomlight
fill 134 270 275 135 271 275 minecraft:white_concrete
fill 134 270 317 135 271 317 minecraft:white_concrete
fill 136 270 276 136 271 276 minecraft:white_concrete
fill 136 270 277 136 271 278 minecraft:red_concrete
fill 136 270 279 136 271 279 minecraft:white_concrete
fill 136 270 280 136 272 280 minecraft:shroomlight
fill 136 270 281 136 271 282 minecraft:red_concrete
fill 136 270 283 136 271 284 minecraft:white_concrete
fill 136 270 285 136 271 286 minecraft:red_concrete
fill 136 270 287 136 271 287 minecraft:white_concrete
fill 136 270 288 136 272 288 minecraft:shroomlight
fill 136 270 289 136 271 290 minecraft:red_concrete
fill 136 270 291 136 271 292 minecraft:white_concrete
fill 136 270 293 136 271 294 minecraft:red_concrete
fill 136 270 295 136 271 295 minecraft:white_concrete
fill 136 270 296 136 272 296 minecraft:shroomlight
fill 136 270 297 136 271 298 minecraft:red_concrete
fill 136 270 299 136 271 300 minecraft:white_concrete
fill 136 270 301 136 271 302 minecraft:red_concrete
fill 136 270 303 136 271 303 minecraft:white_concrete
fill 136 270 304 136 272 304 minecraft:shroomlight
fill 136 270 305 136 271 306 minecraft:red_concrete
fill 136 270 307 136 271 308 minecraft:white_concrete
fill 136 270 309 136 271 310 minecraft:red_concrete
fill 136 270 311 136 271 311 minecraft:white_concrete
fill 136 270 312 136 272 312 minecraft:shroomlight
fill 136 270 313 136 271 314 minecraft:red_concrete
fill 136 270 315 136 271 316 minecraft:white_concrete
fill 136 270 317 136 271 317 minecraft:red_concrete
setblock 95 271 288 minecraft:yellow_concrete
fill 96 271 289 97 271 289 minecraft:yellow_concrete
fill 97 271 279 97 272 281 minecraft:yellow_concrete
fill 98 271 278 100 272 278 minecraft:yellow_concrete
fill 98 271 282 100 272 282 minecraft:yellow_concrete
setblock 98 271 284 minecraft:yellow_concrete
setblock 99 271 285 minecraft:yellow_concrete
setblock 99 271 288 minecraft:yellow_concrete
fill 101 271 279 101 272 281 minecraft:yellow_concrete
fill 125 271 291 125 271 292 minecraft:yellow_concrete
fill 126 271 293 127 271 293 minecraft:yellow_concrete
fill 94 272 275 94 273 276 minecraft:red_concrete
fill 94 272 277 94 273 278 minecraft:white_concrete
fill 94 272 279 94 273 279 minecraft:red_concrete
fill 94 272 281 94 273 282 minecraft:white_concrete
fill 94 272 283 94 273 284 minecraft:red_concrete
fill 94 272 285 94 273 286 minecraft:white_concrete
fill 94 272 287 94 273 287 minecraft:red_concrete
fill 94 272 289 94 273 290 minecraft:white_concrete
fill 94 272 291 94 273 292 minecraft:red_concrete
fill 94 272 293 94 273 294 minecraft:white_concrete
fill 94 272 295 94 273 295 minecraft:red_concrete
fill 94 272 297 94 273 298 minecraft:white_concrete
fill 94 272 299 94 273 300 minecraft:red_concrete
fill 94 272 301 94 273 302 minecraft:white_concrete
fill 94 272 303 94 273 303 minecraft:red_concrete
fill 94 272 305 94 273 306 minecraft:white_concrete
fill 94 272 307 94 273 308 minecraft:red_concrete
fill 94 272 309 94 273 310 minecraft:white_concrete
fill 94 272 311 94 273 311 minecraft:red_concrete
fill 94 272 313 94 273 314 minecraft:white_concrete
fill 94 272 315 94 273 316 minecraft:red_concrete
fill 95 272 275 95 273 275 minecraft:red_concrete
fill 95 272 317 95 273 317 minecraft:red_concrete
fill 96 272 275 97 273 275 minecraft:white_concrete
fill 96 272 317 96 273 317 minecraft:white_concrete
fill 98 272 275 99 273 275 minecraft:red_concrete
fill 98 272 317 99 273 317 minecraft:red_concrete
fill 100 272 275 100 273 275 minecraft:white_concrete
fill 100 272 317 101 273 317 minecraft:white_concrete
fill 102 272 275 103 273 275 minecraft:red_concrete
fill 102 272 317 103 273 317 minecraft:red_concrete
fill 104 272 275 105 273 275 minecraft:white_concrete
fill 104 272 317 104 273 317 minecraft:white_concrete
fill 106 272 275 107 273 275 minecraft:red_concrete
fill 106 272 317 107 273 317 minecraft:red_concrete
fill 108 272 275 108 273 275 minecraft:white_concrete
fill 108 272 317 109 273 317 minecraft:white_concrete
fill 110 272 275 111 273 275 minecraft:red_concrete
fill 110 272 317 111 273 317 minecraft:red_concrete
fill 112 272 275 113 273 275 minecraft:white_concrete
fill 112 272 317 112 273 317 minecraft:white_concrete
fill 114 272 275 115 273 275 minecraft:red_concrete
fill 114 272 317 115 273 317 minecraft:red_concrete
fill 116 272 275 116 273 275 minecraft:white_concrete
fill 116 272 317 117 273 317 minecraft:white_concrete
fill 118 272 275 119 273 275 minecraft:red_concrete
fill 118 272 317 119 273 317 minecraft:red_concrete
fill 120 272 275 121 273 275 minecraft:white_concrete
fill 120 272 317 120 273 317 minecraft:white_concrete
fill 122 272 275 123 273 275 minecraft:red_concrete
fill 122 272 317 123 273 317 minecraft:red_concrete
fill 124 272 275 124 273 275 minecraft:white_concrete
fill 124 272 317 125 273 317 minecraft:white_concrete
fill 126 272 275 127 273 275 minecraft:red_concrete
fill 126 272 317 127 273 317 minecraft:red_concrete
fill 128 272 275 129 273 275 minecraft:white_concrete
fill 128 272 317 128 273 317 minecraft:white_concrete
fill 130 272 275 131 273 275 minecraft:red_concrete
fill 130 272 317 131 273 317 minecraft:red_concrete
fill 132 272 275 132 273 275 minecraft:white_concrete
fill 132 272 317 133 273 317 minecraft:white_concrete
fill 134 272 275 135 273 275 minecraft:red_concrete
fill 134 272 317 135 273 317 minecraft:red_concrete
fill 136 272 276 136 273 276 minecraft:red_concrete
fill 136 272 277 136 273 278 minecraft:white_concrete
fill 136 272 279 136 273 279 minecraft:red_concrete
fill 136 272 281 136 273 282 minecraft:white_concrete
fill 136 272 283 136 273 284 minecraft:red_concrete
fill 136 272 285 136 273 286 minecraft:white_concrete
fill 136 272 287 136 273 287 minecraft:red_concrete
fill 136 272 289 136 273 290 minecraft:white_concrete
fill 136 272 291 136 273 292 minecraft:red_concrete
fill 136 272 293 136 273 294 minecraft:white_concrete
fill 136 272 295 136 273 295 minecraft:red_concrete
fill 136 272 297 136 273 298 minecraft:white_concrete
fill 136 272 299 136 273 300 minecraft:red_concrete
fill 136 272 301 136 273 302 minecraft:white_concrete
fill 136 272 303 136 273 303 minecraft:red_concrete
fill 136 272 305 136 273 306 minecraft:white_concrete
fill 136 272 307 136 273 308 minecraft:red_concrete
fill 136 272 309 136 273 310 minecraft:white_concrete
fill 136 272 311 136 273 311 minecraft:red_concrete
fill 136 272 313 136 273 314 minecraft:white_concrete
fill 136 272 315 136 273 316 minecraft:red_concrete
fill 136 272 317 136 273 317 minecraft:white_concrete
setblock 94 273 280 minecraft:red_concrete
setblock 94 273 288 minecraft:red_concrete
setblock 94 273 296 minecraft:red_concrete
setblock 94 273 304 minecraft:red_concrete
setblock 94 273 312 minecraft:red_concrete
setblock 97 273 278 minecraft:light[level=12]
setblock 97 273 285 minecraft:light[level=12]
setblock 97 273 292 minecraft:light[level=12]
setblock 97 273 299 minecraft:light[level=12]
setblock 97 273 306 minecraft:light[level=12]
setblock 97 273 313 minecraft:light[level=12]
setblock 97 273 317 minecraft:white_concrete
setblock 101 273 275 minecraft:white_concrete
setblock 104 273 278 minecraft:light[level=12]
setblock 104 273 285 minecraft:light[level=12]
setblock 104 273 292 minecraft:light[level=12]
setblock 104 273 299 minecraft:light[level=12]
setblock 104 273 306 minecraft:light[level=12]
setblock 104 273 313 minecraft:light[level=12]
setblock 105 273 317 minecraft:white_concrete
setblock 109 273 275 minecraft:white_concrete
setblock 111 273 278 minecraft:light[level=12]
setblock 111 273 285 minecraft:light[level=12]
setblock 111 273 292 minecraft:light[level=12]
setblock 111 273 299 minecraft:light[level=12]
setblock 111 273 306 minecraft:light[level=12]
setblock 111 273 313 minecraft:light[level=12]
setblock 113 273 317 minecraft:white_concrete
setblock 117 273 275 minecraft:white_concrete
setblock 118 273 278 minecraft:light[level=12]
setblock 118 273 285 minecraft:light[level=12]
setblock 118 273 292 minecraft:light[level=12]
setblock 118 273 299 minecraft:light[level=12]
setblock 118 273 306 minecraft:light[level=12]
setblock 118 273 313 minecraft:light[level=12]
setblock 121 273 317 minecraft:white_concrete
setblock 125 273 275 minecraft:white_concrete
setblock 125 273 278 minecraft:light[level=12]
setblock 125 273 285 minecraft:light[level=12]
setblock 125 273 292 minecraft:light[level=12]
setblock 125 273 299 minecraft:light[level=12]
setblock 125 273 306 minecraft:light[level=12]
setblock 125 273 313 minecraft:light[level=12]
setblock 129 273 317 minecraft:white_concrete
setblock 132 273 278 minecraft:light[level=12]
setblock 132 273 285 minecraft:light[level=12]
setblock 132 273 292 minecraft:light[level=12]
setblock 132 273 299 minecraft:light[level=12]
setblock 132 273 306 minecraft:light[level=12]
setblock 132 273 313 minecraft:light[level=12]
setblock 133 273 275 minecraft:white_concrete
setblock 136 273 280 minecraft:red_concrete
setblock 136 273 288 minecraft:red_concrete
setblock 136 273 296 minecraft:red_concrete
setblock 136 273 304 minecraft:red_concrete
setblock 136 273 312 minecraft:red_concrete
fill 94 274 275 94 275 276 minecraft:white_concrete
fill 94 274 277 94 275 278 minecraft:red_concrete
fill 94 274 279 94 275 280 minecraft:white_concrete
fill 94 274 281 94 275 282 minecraft:red_concrete
fill 94 274 283 94 275 284 minecraft:white_concrete
fill 94 274 285 94 275 286 minecraft:red_concrete
fill 94 274 287 94 275 288 minecraft:white_concrete
fill 94 274 289 94 275 290 minecraft:red_concrete
fill 94 274 291 94 275 292 minecraft:white_concrete
fill 94 274 293 94 275 294 minecraft:red_concrete
fill 94 274 295 94 275 296 minecraft:white_concrete
fill 94 274 297 94 275 298 minecraft:red_concrete
fill 94 274 299 94 275 300 minecraft:white_concrete
fill 94 274 301 94 275 302 minecraft:red_concrete
fill 94 274 303 94 275 304 minecraft:white_concrete
fill 94 274 305 94 275 306 minecraft:red_concrete
fill 94 274 307 94 275 308 minecraft:white_concrete
fill 94 274 309 94 275 310 minecraft:red_concrete
fill 94 274 311 94 275 312 minecraft:white_concrete
fill 94 274 313 94 275 314 minecraft:red_concrete
fill 94 274 315 94 275 316 minecraft:white_concrete
fill 95 274 275 95 275 275 minecraft:white_concrete
fill 95 274 317 95 275 317 minecraft:white_concrete
fill 96 274 275 97 275 275 minecraft:red_concrete
fill 96 274 317 97 275 317 minecraft:red_concrete
fill 98 274 275 99 275 275 minecraft:white_concrete
fill 98 274 317 99 275 317 minecraft:white_concrete
fill 100 274 275 101 275 275 minecraft:red_concrete
fill 100 274 317 101 275 317 minecraft:red_concrete
fill 102 274 275 103 275 275 minecraft:white_concrete
fill 102 274 317 103 275 317 minecraft:white_concrete
fill 104 274 275 105 275 275 minecraft:red_concrete
fill 104 274 317 105 275 317 minecraft:red_concrete
fill 106 274 275 107 275 275 minecraft:white_concrete
fill 106 274 317 107 275 317 minecraft:white_concrete
fill 108 274 275 109 275 275 minecraft:red_concrete
fill 108 274 317 109 275 317 minecraft:red_concrete
fill 110 274 275 111 275 275 minecraft:white_concrete
fill 110 274 317 111 275 317 minecraft:white_concrete
fill 112 274 275 113 275 275 minecraft:red_concrete
fill 112 274 317 113 275 317 minecraft:red_concrete
fill 114 274 275 115 275 275 minecraft:white_concrete
fill 114 274 317 115 275 317 minecraft:white_concrete
fill 116 274 275 117 275 275 minecraft:red_concrete
fill 116 274 317 117 275 317 minecraft:red_concrete
fill 118 274 275 119 275 275 minecraft:white_concrete
fill 118 274 317 119 275 317 minecraft:white_concrete
fill 120 274 275 121 275 275 minecraft:red_concrete
fill 120 274 317 121 275 317 minecraft:red_concrete
fill 122 274 275 123 275 275 minecraft:white_concrete
fill 122 274 317 123 275 317 minecraft:white_concrete
fill 124 274 275 125 275 275 minecraft:red_concrete
fill 124 274 317 125 275 317 minecraft:red_concrete
fill 126 274 275 127 275 275 minecraft:white_concrete
fill 126 274 317 127 275 317 minecraft:white_concrete
fill 128 274 275 129 275 275 minecraft:red_concrete
fill 128 274 317 129 275 317 minecraft:red_concrete
fill 130 274 275 131 275 275 minecraft:white_concrete
fill 130 274 317 131 275 317 minecraft:white_concrete
fill 132 274 275 133 275 275 minecraft:red_concrete
fill 132 274 317 133 275 317 minecraft:red_concrete
fill 134 274 275 135 275 275 minecraft:white_concrete
fill 134 274 317 135 275 317 minecraft:white_concrete
fill 136 274 276 136 275 276 minecraft:white_concrete
fill 136 274 277 136 275 278 minecraft:red_concrete
fill 136 274 279 136 275 280 minecraft:white_concrete
fill 136 274 281 136 275 282 minecraft:red_concrete
fill 136 274 283 136 275 284 minecraft:white_concrete
fill 136 274 285 136 275 286 minecraft:red_concrete
fill 136 274 287 136 275 288 minecraft:white_concrete
fill 136 274 289 136 275 290 minecraft:red_concrete
fill 136 274 291 136 275 292 minecraft:white_concrete
fill 136 274 293 136 275 294 minecraft:red_concrete
fill 136 274 295 136 275 296 minecraft:white_concrete
fill 136 274 297 136 275 298 minecraft:red_concrete
fill 136 274 299 136 275 300 minecraft:white_concrete
fill 136 274 301 136 275 302 minecraft:red_concrete
fill 136 274 303 136 275 304 minecraft:white_concrete
fill 136 274 305 136 275 306 minecraft:red_concrete
fill 136 274 307 136 275 308 minecraft:white_concrete
fill 136 274 309 136 275 310 minecraft:red_concrete
fill 136 274 311 136 275 312 minecraft:white_concrete
fill 136 274 313 136 275 314 minecraft:red_concrete
fill 136 274 315 136 275 316 minecraft:white_concrete
fill 136 274 317 136 275 317 minecraft:red_concrete
fill 94 276 275 94 277 276 minecraft:red_concrete
fill 94 276 277 94 277 278 minecraft:white_concrete
fill 94 276 279 94 277 280 minecraft:red_concrete
fill 94 276 281 94 277 282 minecraft:white_concrete
fill 94 276 283 94 277 284 minecraft:red_concrete
fill 94 276 285 94 277 286 minecraft:white_concrete
fill 94 276 287 94 277 288 minecraft:red_concrete
fill 94 276 289 94 277 290 minecraft:white_concrete
fill 94 276 291 94 277 292 minecraft:red_concrete
fill 94 276 293 94 277 294 minecraft:white_concrete
fill 94 276 295 94 277 296 minecraft:red_concrete
fill 94 276 297 94 277 298 minecraft:white_concrete
fill 94 276 299 94 277 300 minecraft:red_concrete
fill 94 276 301 94 277 302 minecraft:white_concrete
fill 94 276 303 94 277 304 minecraft:red_concrete
fill 94 276 305 94 277 306 minecraft:white_concrete
fill 94 276 307 94 277 308 minecraft:red_concrete
fill 94 276 309 94 277 310 minecraft:white_concrete
fill 94 276 311 94 277 312 minecraft:red_concrete
fill 94 276 313 94 277 314 minecraft:white_concrete
fill 94 276 315 94 277 316 minecraft:red_concrete
fill 95 276 275 95 277 275 minecraft:red_concrete
fill 95 276 317 95 277 317 minecraft:red_concrete
fill 96 276 275 97 277 275 minecraft:white_concrete
fill 96 276 317 97 277 317 minecraft:white_concrete
fill 98 276 275 99 277 275 minecraft:red_concrete
fill 98 276 317 99 277 317 minecraft:red_concrete
fill 100 276 275 101 277 275 minecraft:white_concrete
fill 100 276 317 101 277 317 minecraft:white_concrete
fill 102 276 275 103 277 275 minecraft:red_concrete
fill 102 276 317 103 277 317 minecraft:red_concrete
fill 104 276 275 105 277 275 minecraft:white_concrete
fill 104 276 317 105 277 317 minecraft:white_concrete
fill 106 276 275 107 277 275 minecraft:red_concrete
fill 106 276 317 107 277 317 minecraft:red_concrete
fill 108 276 275 109 277 275 minecraft:white_concrete
fill 108 276 317 109 277 317 minecraft:white_concrete
fill 110 276 275 111 277 275 minecraft:red_concrete
fill 110 276 317 111 277 317 minecraft:red_concrete
fill 112 276 275 113 277 275 minecraft:white_concrete
fill 112 276 317 113 277 317 minecraft:white_concrete
fill 114 276 275 115 277 275 minecraft:red_concrete
fill 114 276 317 115 277 317 minecraft:red_concrete
fill 116 276 275 117 277 275 minecraft:white_concrete
fill 116 276 317 117 277 317 minecraft:white_concrete
fill 118 276 275 119 277 275 minecraft:red_concrete
fill 118 276 317 119 277 317 minecraft:red_concrete
fill 120 276 275 121 277 275 minecraft:white_concrete
fill 120 276 317 121 277 317 minecraft:white_concrete
fill 122 276 275 123 277 275 minecraft:red_concrete
fill 122 276 317 123 277 317 minecraft:red_concrete
fill 124 276 275 125 277 275 minecraft:white_concrete
fill 124 276 317 125 277 317 minecraft:white_concrete
fill 126 276 275 127 277 275 minecraft:red_concrete
fill 126 276 317 127 277 317 minecraft:red_concrete
fill 128 276 275 129 277 275 minecraft:white_concrete
fill 128 276 317 129 277 317 minecraft:white_concrete
fill 130 276 275 131 277 275 minecraft:red_concrete
fill 130 276 317 131 277 317 minecraft:red_concrete
fill 132 276 275 133 277 275 minecraft:white_concrete
fill 132 276 317 133 277 317 minecraft:white_concrete
fill 134 276 275 135 277 275 minecraft:red_concrete
fill 134 276 317 135 277 317 minecraft:red_concrete
fill 136 276 276 136 277 276 minecraft:red_concrete
fill 136 276 277 136 277 278 minecraft:white_concrete
fill 136 276 279 136 277 280 minecraft:red_concrete
fill 136 276 281 136 277 282 minecraft:white_concrete
fill 136 276 283 136 277 284 minecraft:red_concrete
fill 136 276 285 136 277 286 minecraft:white_concrete
fill 136 276 287 136 277 288 minecraft:red_concrete
fill 136 276 289 136 277 290 minecraft:white_concrete
fill 136 276 291 136 277 292 minecraft:red_concrete
fill 136 276 293 136 277 294 minecraft:white_concrete
fill 136 276 295 136 277 296 minecraft:red_concrete
fill 136 276 297 136 277 298 minecraft:white_concrete
fill 136 276 299 136 277 300 minecraft:red_concrete
fill 136 276 301 136 277 302 minecraft:white_concrete
fill 136 276 303 136 277 304 minecraft:red_concrete
fill 136 276 305 136 277 306 minecraft:white_concrete
fill 136 276 307 136 277 308 minecraft:red_concrete
fill 136 276 309 136 277 310 minecraft:white_concrete
fill 136 276 311 136 277 312 minecraft:red_concrete
fill 136 276 313 136 277 314 minecraft:white_concrete
fill 136 276 315 136 277 316 minecraft:red_concrete
fill 136 276 317 136 277 317 minecraft:white_concrete
setblock 97 277 278 minecraft:light[level=15]
setblock 97 277 286 minecraft:light[level=15]
setblock 97 277 294 minecraft:light[level=15]
setblock 97 277 302 minecraft:light[level=15]
setblock 97 277 310 minecraft:light[level=15]
setblock 105 277 278 minecraft:light[level=15]
setblock 105 277 286 minecraft:light[level=15]
setblock 105 277 294 minecraft:light[level=15]
setblock 105 277 302 minecraft:light[level=15]
setblock 105 277 310 minecraft:light[level=15]
setblock 113 277 278 minecraft:light[level=15]
setblock 113 277 286 minecraft:light[level=15]
setblock 113 277 294 minecraft:light[level=15]
setblock 113 277 302 minecraft:light[level=15]
setblock 113 277 310 minecraft:light[level=15]
setblock 121 277 278 minecraft:light[level=15]
setblock 121 277 286 minecraft:light[level=15]
setblock 121 277 294 minecraft:light[level=15]
setblock 121 277 302 minecraft:light[level=15]
setblock 121 277 310 minecraft:light[level=15]
setblock 129 277 278 minecraft:light[level=15]
setblock 129 277 286 minecraft:light[level=15]
setblock 129 277 294 minecraft:light[level=15]
setblock 129 277 302 minecraft:light[level=15]
setblock 129 277 310 minecraft:light[level=15]
fill 94 278 275 94 279 276 minecraft:white_concrete
fill 94 278 277 94 279 278 minecraft:red_concrete
fill 94 278 279 94 279 280 minecraft:white_concrete
fill 94 278 281 94 279 282 minecraft:red_concrete
fill 94 278 283 94 279 284 minecraft:white_concrete
fill 94 278 285 94 279 286 minecraft:red_concrete
fill 94 278 287 94 279 288 minecraft:white_concrete
fill 94 278 289 94 279 290 minecraft:red_concrete
fill 94 278 291 94 279 292 minecraft:white_concrete
fill 94 278 293 94 279 294 minecraft:red_concrete
fill 94 278 295 94 279 296 minecraft:white_concrete
fill 94 278 297 94 279 298 minecraft:red_concrete
fill 94 278 299 94 279 300 minecraft:white_concrete
fill 94 278 301 94 279 302 minecraft:red_concrete
fill 94 278 303 94 279 304 minecraft:white_concrete
fill 94 278 305 94 279 306 minecraft:red_concrete
fill 94 278 307 94 279 308 minecraft:white_concrete
fill 94 278 309 94 279 310 minecraft:red_concrete
fill 94 278 311 94 279 312 minecraft:white_concrete
fill 94 278 313 94 279 314 minecraft:red_concrete
fill 94 278 315 94 279 316 minecraft:white_concrete
fill 95 278 275 95 279 275 minecraft:white_concrete
fill 95 278 317 95 279 317 minecraft:white_concrete
fill 96 278 275 97 279 275 minecraft:red_concrete
fill 96 278 317 97 279 317 minecraft:red_concrete
fill 98 278 275 99 279 275 minecraft:white_concrete
fill 98 278 317 99 279 317 minecraft:white_concrete
fill 100 278 275 101 279 275 minecraft:red_concrete
fill 100 278 317 101 279 317 minecraft:red_concrete
fill 102 278 275 103 279 275 minecraft:white_concrete
fill 102 278 317 103 279 317 minecraft:white_concrete
fill 104 278 275 105 279 275 minecraft:red_concrete
fill 104 278 295 113 278 295 minecraft:orange_terracotta
fill 104 278 317 105 279 317 minecraft:red_concrete
fill 105 278 290 114 278 294 minecraft:orange_terracotta
fill 105 278 296 114 278 300 minecraft:orange_terracotta
fill 106 278 275 107 279 275 minecraft:white_concrete
fill 106 278 289 128 278 289 minecraft:orange_terracotta
fill 106 278 301 128 278 301 minecraft:orange_terracotta
fill 106 278 317 107 279 317 minecraft:white_concrete
fill 107 278 287 127 278 288 minecraft:orange_terracotta
fill 107 278 302 127 278 303 minecraft:orange_terracotta
fill 108 278 275 109 279 275 minecraft:red_concrete
fill 108 278 286 126 278 286 minecraft:orange_terracotta
fill 108 278 304 126 278 304 minecraft:orange_terracotta
fill 108 278 317 109 279 317 minecraft:red_concrete
fill 109 278 285 125 278 285 minecraft:orange_terracotta
fill 109 278 305 125 278 305 minecraft:orange_terracotta
fill 110 278 275 111 279 275 minecraft:white_concrete
fill 110 278 317 111 279 317 minecraft:white_concrete
fill 111 278 284 123 278 284 minecraft:orange_terracotta
fill 111 278 306 123 278 306 minecraft:orange_terracotta
fill 112 278 275 113 279 275 minecraft:red_concrete
fill 112 278 283 122 278 283 minecraft:orange_terracotta
fill 112 278 307 122 278 307 minecraft:orange_terracotta
fill 112 278 317 113 279 317 minecraft:red_concrete
fill 114 278 275 115 279 275 minecraft:white_concrete
fill 114 278 317 115 279 317 minecraft:white_concrete
fill 115 278 290 116 278 292 minecraft:orange_terracotta
fill 115 278 298 116 278 300 minecraft:orange_terracotta
fill 116 278 275 117 279 275 minecraft:red_concrete
fill 116 278 317 117 279 317 minecraft:red_concrete
fill 117 278 282 117 279 282 minecraft:orange_terracotta
fill 117 278 290 129 278 291 minecraft:orange_terracotta
fill 117 278 299 129 278 300 minecraft:orange_terracotta
fill 117 278 308 117 279 308 minecraft:orange_terracotta
fill 118 278 275 119 279 275 minecraft:white_concrete
fill 118 278 292 129 278 292 minecraft:orange_terracotta
fill 118 278 298 129 278 298 minecraft:orange_terracotta
fill 118 278 317 119 279 317 minecraft:white_concrete
fill 120 278 275 121 279 275 minecraft:red_concrete
fill 120 278 293 129 278 294 minecraft:orange_terracotta
fill 120 278 296 129 278 297 minecraft:orange_terracotta
fill 120 278 317 121 279 317 minecraft:red_concrete
fill 121 278 295 130 278 295 minecraft:orange_terracotta
fill 122 278 275 123 279 275 minecraft:white_concrete
fill 122 278 317 123 279 317 minecraft:white_concrete
fill 124 278 275 125 279 275 minecraft:red_concrete
fill 124 278 317 125 279 317 minecraft:red_concrete
fill 126 278 275 127 279 275 minecraft:white_concrete
fill 126 278 317 127 279 317 minecraft:white_concrete
fill 128 278 275 129 279 275 minecraft:red_concrete
fill 128 278 317 129 279 317 minecraft:red_concrete
fill 130 278 275 131 279 275 minecraft:white_concrete
fill 130 278 317 131 279 317 minecraft:white_concrete
fill 132 278 275 133 279 275 minecraft:red_concrete
fill 132 278 317 133 279 317 minecraft:red_concrete
fill 134 278 275 135 279 275 minecraft:white_concrete
fill 134 278 317 135 279 317 minecraft:white_concrete
fill 136 278 276 136 279 276 minecraft:white_concrete
fill 136 278 277 136 279 278 minecraft:red_concrete
fill 136 278 279 136 279 280 minecraft:white_concrete
fill 136 278 281 136 279 282 minecraft:red_concrete
fill 136 278 283 136 279 284 minecraft:white_concrete
fill 136 278 285 136 279 286 minecraft:red_concrete
fill 136 278 287 136 279 288 minecraft:white_concrete
fill 136 278 289 136 279 290 minecraft:red_concrete
fill 136 278 291 136 279 292 minecraft:white_concrete
fill 136 278 293 136 279 294 minecraft:red_concrete
fill 136 278 295 136 279 296 minecraft:white_concrete
fill 136 278 297 136 279 298 minecraft:red_concrete
fill 136 278 299 136 279 300 minecraft:white_concrete
fill 136 278 301 136 279 302 minecraft:red_concrete
fill 136 278 303 136 279 304 minecraft:white_concrete
fill 136 278 305 136 279 306 minecraft:red_concrete
fill 136 278 307 136 279 308 minecraft:white_concrete
fill 136 278 309 136 279 310 minecraft:red_concrete
fill 136 278 311 136 279 312 minecraft:white_concrete
fill 136 278 313 136 279 314 minecraft:red_concrete
fill 136 278 315 136 279 316 minecraft:white_concrete
fill 136 278 317 136 279 317 minecraft:red_concrete
fill 95 279 276 95 279 277 minecraft:light_gray_concrete
setblock 95 279 278 minecraft:white_concrete
fill 95 279 279 95 279 281 minecraft:light_gray_concrete
setblock 95 279 282 minecraft:white_concrete
fill 95 279 283 95 279 285 minecraft:light_gray_concrete
setblock 95 279 286 minecraft:white_concrete
fill 95 279 287 95 279 289 minecraft:light_gray_concrete
setblock 95 279 290 minecraft:white_concrete
fill 95 279 291 95 279 293 minecraft:light_gray_concrete
setblock 95 279 294 minecraft:white_concrete
fill 95 279 295 95 279 297 minecraft:light_gray_concrete
setblock 95 279 298 minecraft:white_concrete
fill 95 279 299 95 279 301 minecraft:light_gray_concrete
setblock 95 279 302 minecraft:white_concrete
fill 95 279 303 95 279 305 minecraft:light_gray_concrete
setblock 95 279 306 minecraft:white_concrete
fill 95 279 307 95 279 309 minecraft:light_gray_concrete
setblock 95 279 310 minecraft:white_concrete
fill 95 279 311 95 279 313 minecraft:light_gray_concrete
setblock 95 279 314 minecraft:white_concrete
fill 95 279 315 96 279 316 minecraft:light_gray_concrete
setblock 96 279 276 minecraft:light_gray_concrete
setblock 96 279 277 minecraft:white_concrete
fill 96 279 278 96 279 280 minecraft:light_gray_concrete
setblock 96 279 281 minecraft:white_concrete
fill 96 279 282 96 279 284 minecraft:light_gray_concrete
setblock 96 279 285 minecraft:white_concrete
fill 96 279 286 96 279 288 minecraft:light_gray_concrete
setblock 96 279 289 minecraft:white_concrete
fill 96 279 290 96 279 292 minecraft:light_gray_concrete
setblock 96 279 293 minecraft:white_concrete
fill 96 279 294 96 279 296 minecraft:light_gray_concrete
setblock 96 279 297 minecraft:white_concrete
fill 96 279 298 96 279 300 minecraft:light_gray_concrete
setblock 96 279 301 minecraft:white_concrete
fill 96 279 302 96 279 304 minecraft:light_gray_concrete
setblock 96 279 305 minecraft:white_concrete
fill 96 279 306 96 279 308 minecraft:light_gray_concrete
setblock 96 279 309 minecraft:white_concrete
fill 96 279 310 96 279 312 minecraft:light_gray_concrete
setblock 96 279 313 minecraft:white_concrete
fill 96 279 314 98 279 314 minecraft:light_gray_concrete
setblock 97 279 276 minecraft:white_concrete
fill 97 279 277 97 279 279 minecraft:light_gray_concrete
setblock 97 279 280 minecraft:white_concrete
fill 97 279 281 97 279 283 minecraft:light_gray_concrete
setblock 97 279 284 minecraft:white_concrete
fill 97 279 285 97 279 287 minecraft:light_gray_concrete
setblock 97 279 288 minecraft:white_concrete
fill 97 279 289 97 279 291 minecraft:light_gray_concrete
setblock 97 279 292 minecraft:white_concrete
fill 97 279 293 97 279 295 minecraft:light_gray_concrete
setblock 97 279 296 minecraft:white_concrete
fill 97 279 297 97 279 299 minecraft:light_gray_concrete
setblock 97 279 300 minecraft:white_concrete
fill 97 279 301 97 279 303 minecraft:light_gray_concrete
setblock 97 279 304 minecraft:white_concrete
fill 97 279 305 97 279 307 minecraft:light_gray_concrete
setblock 97 279 308 minecraft:white_concrete
fill 97 279 309 97 279 311 minecraft:light_gray_concrete
setblock 97 279 312 minecraft:white_concrete
fill 97 279 313 99 279 313 minecraft:light_gray_concrete
setblock 97 279 315 minecraft:light_gray_concrete
setblock 97 279 316 minecraft:white_concrete
fill 98 279 276 98 279 278 minecraft:light_gray_concrete
setblock 98 279 279 minecraft:white_concrete
fill 98 279 280 98 279 282 minecraft:light_gray_concrete
setblock 98 279 283 minecraft:white_concrete
fill 98 279 284 98 279 286 minecraft:light_gray_concrete
setblock 98 279 287 minecraft:white_concrete
fill 98 279 288 98 279 290 minecraft:light_gray_concrete
setblock 98 279 291 minecraft:white_concrete
fill 98 279 292 98 279 294 minecraft:light_gray_concrete
setblock 98 279 295 minecraft:white_concrete
fill 98 279 296 98 279 298 minecraft:light_gray_concrete
setblock 98 279 299 minecraft:white_concrete
fill 98 279 300 98 279 302 minecraft:light_gray_concrete
setblock 98 279 303 minecraft:white_concrete
fill 98 279 304 98 279 306 minecraft:light_gray_concrete
setblock 98 279 307 minecraft:white_concrete
fill 98 279 308 98 279 310 minecraft:light_gray_concrete
setblock 98 279 311 minecraft:white_concrete
fill 98 279 312 100 279 312 minecraft:light_gray_concrete
setblock 98 279 315 minecraft:white_concrete
fill 98 279 316 100 279 316 minecraft:light_gray_concrete
fill 99 279 276 99 279 277 minecraft:light_gray_concrete
setblock 99 279 278 minecraft:white_concrete
fill 99 279 279 99 279 281 minecraft:light_gray_concrete
setblock 99 279 282 minecraft:white_concrete
fill 99 279 283 99 279 285 minecraft:light_gray_concrete
setblock 99 279 286 minecraft:white_concrete
fill 99 279 287 99 279 289 minecraft:light_gray_concrete
setblock 99 279 290 minecraft:white_concrete
fill 99 279 291 99 279 293 minecraft:light_gray_concrete
setblock 99 279 294 minecraft:white_concrete
fill 99 279 295 99 279 297 minecraft:light_gray_concrete
setblock 99 279 298 minecraft:white_concrete
fill 99 279 299 99 279 301 minecraft:light_gray_concrete
setblock 99 279 302 minecraft:white_concrete
fill 99 279 303 99 279 305 minecraft:light_gray_concrete
setblock 99 279 306 minecraft:white_concrete
fill 99 279 307 99 279 309 minecraft:light_gray_concrete
setblock 99 279 310 minecraft:white_concrete
fill 99 279 311 101 279 311 minecraft:light_gray_concrete
setblock 99 279 314 minecraft:white_concrete
fill 99 279 315 101 279 315 minecraft:light_gray_concrete
setblock 100 279 276 minecraft:light_gray_concrete
setblock 100 279 277 minecraft:white_concrete
fill 100 279 278 100 279 280 minecraft:light_gray_concrete
setblock 100 279 281 minecraft:white_concrete
fill 100 279 282 100 279 284 minecraft:light_gray_concrete
setblock 100 279 285 minecraft:white_concrete
fill 100 279 286 100 279 288 minecraft:light_gray_concrete
setblock 100 279 289 minecraft:white_concrete
fill 100 279 290 100 279 292 minecraft:light_gray_concrete
setblock 100 279 293 minecraft:white_concrete
fill 100 279 294 100 279 296 minecraft:light_gray_concrete
setblock 100 279 297 minecraft:white_concrete
fill 100 279 298 100 279 300 minecraft:light_gray_concrete
setblock 100 279 301 minecraft:white_concrete
fill 100 279 302 100 279 304 minecraft:light_gray_concrete
setblock 100 279 305 minecraft:white_concrete
fill 100 279 306 100 279 308 minecraft:light_gray_concrete
setblock 100 279 309 minecraft:white_concrete
fill 100 279 310 102 279 310 minecraft:light_gray_concrete
setblock 100 279 313 minecraft:white_concrete
fill 100 279 314 102 279 314 minecraft:light_gray_concrete
setblock 101 279 276 minecraft:white_concrete
fill 101 279 277 101 279 279 minecraft:light_gray_concrete
setblock 101 279 280 minecraft:white_concrete
fill 101 279 281 101 279 283 minecraft:light_gray_concrete
setblock 101 279 284 minecraft:white_concrete
fill 101 279 285 101 279 287 minecraft:light_gray_concrete
setblock 101 279 288 minecraft:white_concrete
fill 101 279 289 101 279 291 minecraft:light_gray_concrete
setblock 101 279 292 minecraft:white_concrete
fill 101 279 293 101 279 295 minecraft:light_gray_concrete
setblock 101 279 296 minecraft:white_concrete
fill 101 279 297 101 279 299 minecraft:light_gray_concrete
setblock 101 279 300 minecraft:white_concrete
fill 101 279 301 101 279 303 minecraft:light_gray_concrete
setblock 101 279 304 minecraft:white_concrete
fill 101 279 305 101 279 307 minecraft:light_gray_concrete
setblock 101 279 308 minecraft:white_concrete
fill 101 279 309 103 279 309 minecraft:light_gray_concrete
setblock 101 279 312 minecraft:white_concrete
fill 101 279 313 103 279 313 minecraft:light_gray_concrete
setblock 101 279 316 minecraft:white_concrete
fill 102 279 276 102 279 278 minecraft:light_gray_concrete
setblock 102 279 279 minecraft:white_concrete
fill 102 279 280 102 279 282 minecraft:light_gray_concrete
setblock 102 279 283 minecraft:white_concrete
fill 102 279 284 102 279 286 minecraft:light_gray_concrete
setblock 102 279 287 minecraft:white_concrete
fill 102 279 288 102 279 290 minecraft:light_gray_concrete
setblock 102 279 291 minecraft:white_concrete
fill 102 279 292 102 279 294 minecraft:light_gray_concrete
setblock 102 279 295 minecraft:white_concrete
fill 102 279 296 102 279 298 minecraft:light_gray_concrete
setblock 102 279 299 minecraft:white_concrete
fill 102 279 300 102 279 302 minecraft:light_gray_concrete
setblock 102 279 303 minecraft:white_concrete
fill 102 279 304 102 279 306 minecraft:light_gray_concrete
setblock 102 279 307 minecraft:white_concrete
fill 102 279 308 104 279 308 minecraft:light_gray_concrete
setblock 102 279 311 minecraft:white_concrete
fill 102 279 312 104 279 312 minecraft:light_gray_concrete
setblock 102 279 315 minecraft:white_concrete
fill 102 279 316 104 279 316 minecraft:light_gray_concrete
fill 103 279 276 103 279 277 minecraft:light_gray_concrete
setblock 103 279 278 minecraft:white_concrete
fill 103 279 279 103 279 281 minecraft:light_gray_concrete
setblock 103 279 282 minecraft:white_concrete
fill 103 279 283 103 279 285 minecraft:light_gray_concrete
setblock 103 279 286 minecraft:white_concrete
fill 103 279 287 103 279 289 minecraft:light_gray_concrete
setblock 103 279 290 minecraft:white_concrete
fill 103 279 291 103 279 293 minecraft:light_gray_concrete
setblock 103 279 294 minecraft:white_concrete
fill 103 279 295 103 279 297 minecraft:light_gray_concrete
setblock 103 279 298 minecraft:white_concrete
fill 103 279 299 103 279 301 minecraft:light_gray_concrete
setblock 103 279 302 minecraft:white_concrete
fill 103 279 303 103 279 305 minecraft:light_gray_concrete
setblock 103 279 306 minecraft:white_concrete
fill 103 279 307 105 279 307 minecraft:light_gray_concrete
setblock 103 279 310 minecraft:white_concrete
fill 103 279 311 105 279 311 minecraft:light_gray_concrete
setblock 103 279 314 minecraft:white_concrete
fill 103 279 315 105 279 315 minecraft:light_gray_concrete
setblock 104 279 276 minecraft:light_gray_concrete
setblock 104 279 277 minecraft:white_concrete
fill 104 279 278 104 279 280 minecraft:light_gray_concrete
setblock 104 279 281 minecraft:white_concrete
fill 104 279 282 104 279 284 minecraft:light_gray_concrete
setblock 104 279 285 minecraft:white_concrete
fill 104 279 286 104 279 288 minecraft:light_gray_concrete
setblock 104 279 289 minecraft:white_concrete
fill 104 279 290 104 279 292 minecraft:light_gray_concrete
setblock 104 279 293 minecraft:white_concrete
setblock 104 279 294 minecraft:light_gray_concrete
fill 104 279 295 105 279 295 minecraft:orange_terracotta
setblock 104 279 296 minecraft:light_gray_concrete
setblock 104 279 297 minecraft:white_concrete
fill 104 279 298 104 279 300 minecraft:light_gray_concrete
setblock 104 279 301 minecraft:white_concrete
fill 104 279 302 104 279 304 minecraft:light_gray_concrete
setblock 104 279 305 minecraft:white_concrete
fill 104 279 306 106 279 306 minecraft:light_gray_concrete
setblock 104 279 309 minecraft:white_concrete
fill 104 279 310 106 279 310 minecraft:light_gray_concrete
setblock 104 279 313 minecraft:white_concrete
fill 104 279 314 106 279 314 minecraft:light_gray_concrete
setblock 105 279 276 minecraft:white_concrete
fill 105 279 277 105 279 279 minecraft:light_gray_concrete
setblock 105 279 280 minecraft:white_concrete
fill 105 279 281 105 279 283 minecraft:light_gray_concrete
setblock 105 279 284 minecraft:white_concrete
fill 105 279 285 105 279 287 minecraft:light_gray_concrete
setblock 105 279 288 minecraft:white_concrete
setblock 105 279 289 minecraft:light_gray_concrete
setblock 105 279 290 minecraft:brown_terracotta
fill 105 279 291 105 279 294 minecraft:orange_terracotta
fill 105 279 296 105 279 299 minecraft:orange_terracotta
setblock 105 279 300 minecraft:brown_terracotta
fill 105 279 301 105 279 303 minecraft:light_gray_concrete
setblock 105 279 304 minecraft:white_concrete
fill 105 279 305 107 279 305 minecraft:light_gray_concrete
setblock 105 279 308 minecraft:white_concrete
fill 105 279 309 107 279 309 minecraft:light_gray_concrete
setblock 105 279 312 minecraft:white_concrete
fill 105 279 313 107 279 313 minecraft:light_gray_concrete
setblock 105 279 316 minecraft:white_concrete
fill 106 279 276 106 279 278 minecraft:light_gray_concrete
setblock 106 279 279 minecraft:white_concrete
fill 106 279 280 106 279 282 minecraft:light_gray_concrete
setblock 106 279 283 minecraft:white_concrete
fill 106 279 284 106 279 286 minecraft:light_gray_concrete
setblock 106 279 287 minecraft:white_concrete
setblock 106 279 288 minecraft:light_gray_concrete
fill 106 279 289 106 279 291 minecraft:orange_terracotta
fill 106 279 292 108 279 293 minecraft:red_concrete
fill 106 279 294 107 279 295 minecraft:yellow_wool
fill 106 279 296 106 279 298 minecraft:red_concrete
fill 106 279 299 106 279 301 minecraft:orange_terracotta
setblock 106 279 302 minecraft:light_gray_concrete
setblock 106 279 303 minecraft:white_concrete
fill 106 279 304 107 279 304 minecraft:light_gray_concrete
setblock 106 279 307 minecraft:white_concrete
fill 106 279 308 108 279 308 minecraft:light_gray_concrete
setblock 106 279 311 minecraft:white_concrete
fill 106 279 312 108 279 312 minecraft:light_gray_concrete
setblock 106 279 315 minecraft:white_concrete
fill 106 279 316 108 279 316 minecraft:light_gray_concrete
fill 107 279 276 107 279 277 minecraft:light_gray_concrete
setblock 107 279 278 minecraft:white_concrete
fill 107 279 279 107 279 281 minecraft:light_gray_concrete
setblock 107 279 282 minecraft:white_concrete
fill 107 279 283 107 279 285 minecraft:light_gray_concrete
setblock 107 279 286 minecraft:white_concrete
fill 107 279 287 107 279 288 minecraft:orange_terracotta
fill 107 279 289 110 279 289 minecraft:red_concrete
setblock 107 279 290 minecraft:yellow_wool
fill 107 279 291 108 279 291 minecraft:brown_terracotta
fill 107 279 296 110 279 297 minecraft:red_terracotta
fill 107 279 298 108 279 298 minecraft:red_concrete
fill 107 279 299 108 279 299 minecraft:brown_terracotta
setblock 107 279 300 minecraft:yellow_wool
fill 107 279 301 110 279 301 minecraft:red_concrete
fill 107 279 302 107 279 303 minecraft:orange_terracotta
setblock 107 279 306 minecraft:white_concrete
fill 107 279 307 109 279 307 minecraft:light_gray_concrete
setblock 107 279 310 minecraft:white_concrete
fill 107 279 311 109 279 311 minecraft:light_gray_concrete
setblock 107 279 314 minecraft:white_concrete
fill 107 279 315 109 279 315 minecraft:light_gray_concrete
setblock 108 279 276 minecraft:light_gray_concrete
setblock 108 279 277 minecraft:white_concrete
fill 108 279 278 108 279 280 minecraft:light_gray_concrete
setblock 108 279 281 minecraft:white_concrete
fill 108 279 282 108 279 284 minecraft:light_gray_concrete
setblock 108 279 285 minecraft:white_concrete
fill 108 279 286 108 279 287 minecraft:orange_terracotta
fill 108 279 288 110 279 288 minecraft:red_concrete
fill 108 279 290 110 279 290 minecraft:red_concrete
schedule function dropper:buildpart/62_8 1t
