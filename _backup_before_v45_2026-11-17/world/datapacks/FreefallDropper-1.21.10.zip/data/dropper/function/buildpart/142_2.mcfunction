fill 499 284 594 501 284 594 minecraft:smooth_quartz
fill 500 284 572 507 284 573 minecraft:quartz_block
setblock 500 284 574 minecraft:gold_block
setblock 500 284 582 minecraft:gold_block
fill 500 284 583 507 284 584 minecraft:quartz_block
fill 501 284 563 502 284 563 minecraft:smooth_quartz
fill 501 284 574 508 284 582 minecraft:quartz_block
fill 501 284 593 502 284 593 minecraft:smooth_quartz
fill 501 284 598 503 300 598 minecraft:quartz_pillar
fill 502 284 597 504 285 597 minecraft:quartz_pillar
setblock 503 284 564 minecraft:smooth_quartz
setblock 503 284 592 minecraft:smooth_quartz
setblock 504 284 565 minecraft:smooth_quartz
setblock 504 284 591 minecraft:smooth_quartz
setblock 505 284 566 minecraft:smooth_quartz
setblock 505 284 590 minecraft:smooth_quartz
fill 506 284 559 508 285 559 minecraft:quartz_pillar
fill 506 284 567 506 284 568 minecraft:smooth_quartz
fill 506 284 588 506 284 589 minecraft:smooth_quartz
fill 507 284 558 509 300 558 minecraft:quartz_pillar
fill 507 284 568 507 284 570 minecraft:smooth_quartz
fill 507 284 586 507 284 588 minecraft:smooth_quartz
fill 508 284 570 508 284 572 minecraft:smooth_quartz
setblock 508 284 573 minecraft:quartz_block
setblock 508 284 583 minecraft:quartz_block
fill 508 284 584 508 284 586 minecraft:smooth_quartz
fill 509 284 573 509 284 583 minecraft:smooth_quartz
fill 510 284 567 510 285 569 minecraft:quartz_pillar
fill 510 284 579 510 285 581 minecraft:quartz_pillar
fill 510 284 591 510 285 593 minecraft:quartz_pillar
fill 511 284 566 511 300 568 minecraft:quartz_pillar
fill 511 284 578 511 300 580 minecraft:quartz_pillar
fill 511 284 590 511 300 592 minecraft:quartz_pillar
fill 471 285 561 471 285 566 minecraft:smooth_quartz
fill 471 285 573 471 285 578 minecraft:smooth_quartz
fill 471 285 585 471 285 590 minecraft:smooth_quartz
fill 471 285 597 471 285 598 minecraft:smooth_quartz
fill 472 285 598 475 285 598 minecraft:smooth_quartz
fill 474 285 573 474 285 583 minecraft:smooth_quartz
fill 475 285 558 480 285 558 minecraft:smooth_quartz
fill 475 285 571 475 285 575 minecraft:smooth_quartz
fill 475 285 576 478 285 580 minecraft:quartz_block
fill 475 285 581 475 285 585 minecraft:smooth_quartz
fill 476 285 569 476 285 571 minecraft:smooth_quartz
fill 476 285 572 478 285 575 minecraft:quartz_block
fill 476 285 581 478 285 584 minecraft:quartz_block
fill 476 285 585 476 285 587 minecraft:smooth_quartz
fill 477 285 567 477 285 569 minecraft:smooth_quartz
fill 477 285 570 480 285 571 minecraft:quartz_block
fill 477 285 585 480 285 586 minecraft:quartz_block
fill 477 285 587 477 285 589 minecraft:smooth_quartz
fill 478 285 566 478 285 568 minecraft:smooth_quartz
fill 478 285 569 482 285 569 minecraft:quartz_block
fill 478 285 587 482 285 587 minecraft:quartz_block
fill 478 285 588 478 285 590 minecraft:smooth_quartz
fill 479 285 565 479 285 567 minecraft:smooth_quartz
fill 479 285 568 483 285 568 minecraft:quartz_block
fill 479 285 572 479 285 574 minecraft:quartz_block
fill 479 285 575 479 285 581 minecraft:gold_block
fill 479 285 582 479 285 584 minecraft:quartz_block
fill 479 285 588 483 285 588 minecraft:quartz_block
fill 479 285 589 479 285 591 minecraft:smooth_quartz
fill 480 285 564 480 285 566 minecraft:smooth_quartz
fill 480 285 567 485 285 567 minecraft:quartz_block
setblock 480 285 572 minecraft:quartz_block
fill 480 285 573 480 285 575 minecraft:gold_block
fill 480 285 581 480 285 583 minecraft:gold_block
setblock 480 285 584 minecraft:quartz_block
fill 480 285 589 485 285 589 minecraft:quartz_block
fill 480 285 590 480 285 592 minecraft:smooth_quartz
fill 480 285 596 480 294 596 minecraft:blue_wool
fill 481 285 564 481 285 565 minecraft:smooth_quartz
fill 481 285 566 488 285 566 minecraft:quartz_block
setblock 481 285 570 minecraft:quartz_block
fill 481 285 571 481 285 573 minecraft:gold_block
fill 481 285 583 481 285 585 minecraft:gold_block
setblock 481 285 586 minecraft:quartz_block
fill 481 285 590 488 285 590 minecraft:quartz_block
fill 481 285 591 481 285 592 minecraft:smooth_quartz
fill 482 285 563 482 285 564 minecraft:smooth_quartz
fill 482 285 565 500 285 565 minecraft:quartz_block
fill 482 285 570 482 285 571 minecraft:gold_block
fill 482 285 585 482 285 586 minecraft:gold_block
fill 482 285 591 500 285 591 minecraft:quartz_block
fill 482 285 592 482 285 593 minecraft:smooth_quartz
fill 482 285 598 487 285 598 minecraft:smooth_quartz
fill 483 285 563 484 285 563 minecraft:smooth_quartz
fill 483 285 564 499 285 564 minecraft:quartz_block
fill 483 285 569 483 285 570 minecraft:gold_block
fill 483 285 586 483 285 587 minecraft:gold_block
fill 483 285 592 499 285 592 minecraft:quartz_block
fill 483 285 593 484 285 593 minecraft:smooth_quartz
fill 484 285 562 488 285 562 minecraft:smooth_quartz
fill 484 285 568 484 285 569 minecraft:gold_block
fill 484 285 587 484 285 588 minecraft:gold_block
fill 484 285 594 488 285 594 minecraft:smooth_quartz
fill 485 285 563 497 285 563 minecraft:quartz_block
fill 485 285 568 486 285 568 minecraft:gold_block
fill 485 285 588 486 285 588 minecraft:gold_block
fill 485 285 593 497 285 593 minecraft:quartz_block
fill 486 285 561 496 285 561 minecraft:smooth_quartz
fill 486 285 567 496 285 567 minecraft:gold_block
fill 486 285 589 496 285 589 minecraft:gold_block
fill 486 285 595 496 285 595 minecraft:smooth_quartz
fill 487 285 558 492 285 558 minecraft:smooth_quartz
fill 489 285 562 493 285 562 minecraft:quartz_block
fill 489 285 566 492 285 566 minecraft:gold_block
fill 489 285 590 492 285 590 minecraft:gold_block
fill 489 285 594 493 285 594 minecraft:quartz_block
fill 490 285 596 494 297 596 minecraft:blue_wool
fill 493 285 566 501 285 566 minecraft:quartz_block
fill 493 285 590 501 285 590 minecraft:quartz_block
fill 494 285 562 498 285 562 minecraft:smooth_quartz
fill 494 285 568 497 285 568 minecraft:gold_block
fill 494 285 588 497 285 588 minecraft:gold_block
fill 494 285 594 498 285 594 minecraft:smooth_quartz
fill 494 285 598 499 285 598 minecraft:smooth_quartz
fill 496 285 569 499 285 569 minecraft:gold_block
fill 496 285 587 499 285 587 minecraft:gold_block
fill 497 285 567 502 285 567 minecraft:quartz_block
fill 497 285 589 502 285 589 minecraft:quartz_block
fill 498 285 563 500 285 563 minecraft:smooth_quartz
fill 498 285 568 503 285 568 minecraft:quartz_block
fill 498 285 570 499 285 570 minecraft:gold_block
fill 498 285 586 499 285 586 minecraft:gold_block
fill 498 285 588 503 285 588 minecraft:quartz_block
fill 498 285 593 500 285 593 minecraft:smooth_quartz
fill 499 285 558 504 285 558 minecraft:smooth_quartz
fill 499 285 571 500 285 571 minecraft:gold_block
fill 499 285 585 500 285 585 minecraft:gold_block
fill 500 285 564 502 285 564 minecraft:smooth_quartz
fill 500 285 569 504 285 570 minecraft:quartz_block
fill 500 285 572 501 285 573 minecraft:gold_block
fill 500 285 583 501 285 584 minecraft:gold_block
fill 500 285 586 504 285 587 minecraft:quartz_block
fill 500 285 592 502 285 592 minecraft:smooth_quartz
fill 501 285 565 503 285 565 minecraft:smooth_quartz
fill 501 285 571 505 285 571 minecraft:quartz_block
fill 501 285 574 502 285 582 minecraft:gold_block
fill 501 285 585 505 285 585 minecraft:quartz_block
fill 501 285 591 503 285 591 minecraft:smooth_quartz
fill 502 285 566 504 285 566 minecraft:smooth_quartz
fill 502 285 572 506 285 573 minecraft:quartz_block
fill 502 285 583 506 285 584 minecraft:quartz_block
fill 502 285 590 504 285 590 minecraft:smooth_quartz
fill 503 285 567 505 285 567 minecraft:smooth_quartz
fill 503 285 574 506 285 582 minecraft:quartz_block
fill 503 285 589 505 285 589 minecraft:smooth_quartz
fill 504 285 568 505 285 568 minecraft:smooth_quartz
fill 504 285 588 505 285 588 minecraft:smooth_quartz
fill 505 285 569 506 285 569 minecraft:smooth_quartz
setblock 505 285 570 minecraft:quartz_block
setblock 505 285 586 minecraft:quartz_block
fill 505 285 587 506 285 587 minecraft:smooth_quartz
fill 506 285 570 506 285 571 minecraft:smooth_quartz
fill 506 285 585 506 285 586 minecraft:smooth_quartz
fill 506 285 598 511 285 598 minecraft:smooth_quartz
fill 507 285 571 507 285 575 minecraft:smooth_quartz
fill 507 285 576 507 285 580 minecraft:quartz_block
fill 507 285 581 507 285 585 minecraft:smooth_quartz
fill 508 285 573 508 285 583 minecraft:smooth_quartz
fill 511 285 558 511 285 563 minecraft:smooth_quartz
fill 511 285 570 511 285 575 minecraft:smooth_quartz
fill 511 285 582 511 285 587 minecraft:smooth_quartz
fill 511 285 594 511 285 597 minecraft:smooth_quartz
fill 470 286 563 470 291 566 minecraft:pearlescent_froglight
fill 470 286 575 470 291 578 minecraft:pearlescent_froglight
fill 470 286 587 470 291 590 minecraft:pearlescent_froglight
fill 470 286 599 473 291 599 minecraft:pearlescent_froglight
fill 475 286 576 477 286 580 minecraft:smooth_quartz
fill 476 286 572 477 286 575 minecraft:smooth_quartz
fill 476 286 581 477 286 584 minecraft:smooth_quartz
fill 477 286 557 480 291 557 minecraft:pearlescent_froglight
fill 477 286 570 479 286 571 minecraft:smooth_quartz
fill 477 286 585 479 286 586 minecraft:smooth_quartz
fill 478 286 569 481 286 569 minecraft:smooth_quartz
fill 478 286 572 478 286 574 minecraft:smooth_quartz
fill 478 286 575 478 286 581 minecraft:gold_block
fill 478 286 582 478 286 584 minecraft:smooth_quartz
fill 478 286 587 481 286 587 minecraft:smooth_quartz
fill 478 286 596 479 294 596 minecraft:blue_wool
fill 479 286 568 482 286 568 minecraft:smooth_quartz
setblock 479 286 572 minecraft:smooth_quartz
fill 479 286 573 479 286 574 minecraft:gold_block
fill 479 286 582 479 286 583 minecraft:gold_block
setblock 479 286 584 minecraft:smooth_quartz
fill 479 286 588 482 286 588 minecraft:smooth_quartz
fill 480 286 567 483 286 567 minecraft:smooth_quartz
setblock 480 286 570 minecraft:smooth_quartz
fill 480 286 571 480 286 572 minecraft:gold_block
fill 480 286 584 480 286 585 minecraft:gold_block
setblock 480 286 586 minecraft:smooth_quartz
fill 480 286 589 483 286 589 minecraft:smooth_quartz
fill 481 286 566 485 286 566 minecraft:smooth_quartz
setblock 481 286 570 minecraft:gold_block
setblock 481 286 586 minecraft:gold_block
fill 481 286 590 485 286 590 minecraft:smooth_quartz
fill 481 286 596 482 294 596 minecraft:blue_wool
fill 482 286 565 488 286 565 minecraft:smooth_quartz
setblock 482 286 569 minecraft:gold_block
setblock 482 286 587 minecraft:gold_block
fill 482 286 591 488 286 591 minecraft:smooth_quartz
fill 482 286 599 485 291 599 minecraft:pearlescent_froglight
fill 483 286 564 499 286 564 minecraft:smooth_quartz
setblock 483 286 568 minecraft:gold_block
setblock 483 286 588 minecraft:gold_block
fill 483 286 592 499 286 592 minecraft:smooth_quartz
fill 484 286 567 485 286 567 minecraft:gold_block
fill 484 286 589 485 286 589 minecraft:gold_block
fill 485 286 563 497 286 563 minecraft:smooth_quartz
fill 485 286 593 497 286 593 minecraft:smooth_quartz
fill 486 286 566 488 286 566 minecraft:gold_block
fill 486 286 590 488 286 590 minecraft:gold_block
fill 489 286 557 492 291 557 minecraft:pearlescent_froglight
fill 489 286 562 493 286 562 minecraft:smooth_quartz
fill 489 286 565 492 286 565 minecraft:gold_block
fill 489 286 591 492 286 591 minecraft:gold_block
fill 489 286 594 493 286 594 minecraft:smooth_quartz
fill 493 286 565 500 286 565 minecraft:smooth_quartz
fill 493 286 566 496 286 566 minecraft:gold_block
fill 493 286 590 496 286 590 minecraft:gold_block
fill 493 286 591 500 286 591 minecraft:smooth_quartz
fill 494 286 599 497 291 599 minecraft:pearlescent_froglight
fill 497 286 566 501 286 566 minecraft:smooth_quartz
setblock 497 286 567 minecraft:gold_block
setblock 497 286 589 minecraft:gold_block
fill 497 286 590 501 286 590 minecraft:smooth_quartz
fill 498 286 567 502 286 567 minecraft:smooth_quartz
fill 498 286 568 499 286 568 minecraft:gold_block
fill 498 286 588 499 286 588 minecraft:gold_block
fill 498 286 589 502 286 589 minecraft:smooth_quartz
fill 500 286 568 503 286 568 minecraft:smooth_quartz
fill 500 286 569 500 286 570 minecraft:gold_block
fill 500 286 586 500 286 587 minecraft:gold_block
fill 500 286 588 503 286 588 minecraft:smooth_quartz
fill 501 286 557 504 291 557 minecraft:pearlescent_froglight
fill 501 286 569 504 286 569 minecraft:smooth_quartz
fill 501 286 570 501 286 571 minecraft:gold_block
fill 501 286 585 501 286 586 minecraft:gold_block
fill 501 286 587 504 286 587 minecraft:smooth_quartz
fill 502 286 570 505 286 571 minecraft:smooth_quartz
fill 502 286 572 502 286 573 minecraft:gold_block
fill 502 286 583 502 286 584 minecraft:gold_block
fill 502 286 585 505 286 586 minecraft:smooth_quartz
fill 503 286 572 506 286 572 minecraft:smooth_quartz
fill 503 286 573 503 286 583 minecraft:gold_block
fill 503 286 584 506 286 584 minecraft:smooth_quartz
fill 504 286 573 506 286 577 minecraft:smooth_quartz
setblock 504 286 578 minecraft:gold_block
fill 504 286 579 506 286 583 minecraft:smooth_quartz
fill 505 286 578 507 286 578 minecraft:smooth_quartz
fill 506 286 599 509 291 599 minecraft:pearlescent_froglight
fill 507 286 576 507 286 577 minecraft:smooth_quartz
fill 507 286 579 507 286 580 minecraft:smooth_quartz
fill 512 286 558 512 291 561 minecraft:pearlescent_froglight
fill 512 286 570 512 291 573 minecraft:pearlescent_froglight
fill 512 286 582 512 291 585 minecraft:pearlescent_froglight
fill 512 286 594 512 291 597 minecraft:pearlescent_froglight
setblock 473 289 560 minecraft:light[level=14]
setblock 473 289 568 minecraft:light[level=14]
setblock 473 289 576 minecraft:light[level=14]
setblock 473 289 584 minecraft:light[level=14]
setblock 473 289 592 minecraft:light[level=14]
setblock 481 289 560 minecraft:light[level=14]
setblock 481 289 568 minecraft:light[level=14]
setblock 481 289 576 minecraft:light[level=14]
setblock 481 289 584 minecraft:light[level=14]
setblock 481 289 592 minecraft:light[level=14]
setblock 489 289 560 minecraft:light[level=14]
setblock 489 289 568 minecraft:light[level=14]
setblock 489 289 576 minecraft:light[level=14]
setblock 489 289 584 minecraft:light[level=14]
setblock 489 289 592 minecraft:light[level=14]
setblock 497 289 560 minecraft:light[level=14]
setblock 497 289 568 minecraft:light[level=14]
setblock 497 289 576 minecraft:light[level=14]
setblock 497 289 584 minecraft:light[level=14]
setblock 497 289 592 minecraft:light[level=14]
setblock 505 289 560 minecraft:light[level=14]
setblock 505 289 568 minecraft:light[level=14]
setblock 505 289 576 minecraft:light[level=14]
setblock 505 289 584 minecraft:light[level=14]
setblock 505 289 592 minecraft:light[level=14]
fill 470 292 563 470 307 563 minecraft:quartz_block
fill 470 292 564 470 292 565 minecraft:pearlescent_froglight
fill 470 292 566 470 307 566 minecraft:quartz_block
fill 470 292 575 470 307 575 minecraft:quartz_block
fill 470 292 576 470 292 577 minecraft:pearlescent_froglight
fill 470 292 578 470 307 578 minecraft:quartz_block
fill 470 292 587 470 307 587 minecraft:quartz_block
fill 470 292 588 470 292 589 minecraft:pearlescent_froglight
fill 470 292 590 470 307 590 minecraft:quartz_block
fill 470 292 599 470 307 599 minecraft:quartz_block
fill 471 292 599 472 292 599 minecraft:pearlescent_froglight
fill 473 292 599 473 307 599 minecraft:quartz_block
fill 477 292 557 477 307 557 minecraft:quartz_block
fill 478 292 557 479 292 557 minecraft:pearlescent_froglight
fill 480 292 557 480 307 557 minecraft:quartz_block
fill 482 292 599 482 307 599 minecraft:quartz_block
fill 483 292 599 484 292 599 minecraft:pearlescent_froglight
fill 485 292 599 485 307 599 minecraft:quartz_block
fill 489 292 557 489 307 557 minecraft:quartz_block
fill 490 292 557 491 292 557 minecraft:pearlescent_froglight
fill 492 292 557 492 307 557 minecraft:quartz_block
fill 494 292 599 494 307 599 minecraft:quartz_block
fill 495 292 599 496 292 599 minecraft:pearlescent_froglight
fill 497 292 599 497 307 599 minecraft:quartz_block
fill 501 292 557 501 307 557 minecraft:quartz_block
fill 502 292 557 503 292 557 minecraft:pearlescent_froglight
fill 504 292 557 504 307 557 minecraft:quartz_block
fill 506 292 599 506 307 599 minecraft:quartz_block
fill 507 292 599 508 292 599 minecraft:pearlescent_froglight
fill 509 292 599 509 307 599 minecraft:quartz_block
fill 512 292 558 512 307 558 minecraft:quartz_block
fill 512 292 559 512 292 560 minecraft:pearlescent_froglight
fill 512 292 561 512 307 561 minecraft:quartz_block
fill 512 292 570 512 307 570 minecraft:quartz_block
fill 512 292 571 512 292 572 minecraft:pearlescent_froglight
fill 512 292 573 512 307 573 minecraft:quartz_block
fill 512 292 582 512 307 582 minecraft:quartz_block
fill 512 292 583 512 292 584 minecraft:pearlescent_froglight
fill 512 292 585 512 307 585 minecraft:quartz_block
fill 512 292 594 512 307 594 minecraft:quartz_block
fill 512 292 595 512 292 596 minecraft:pearlescent_froglight
fill 512 292 597 512 307 597 minecraft:quartz_block
fill 470 293 564 470 307 565 minecraft:quartz_block
fill 470 293 576 470 307 577 minecraft:quartz_block
fill 470 293 588 470 307 589 minecraft:quartz_block
fill 471 293 599 472 307 599 minecraft:quartz_block
fill 478 293 557 479 307 557 minecraft:quartz_block
fill 483 293 599 484 307 599 minecraft:quartz_block
fill 490 293 557 491 307 557 minecraft:quartz_block
fill 495 293 599 496 307 599 minecraft:quartz_block
fill 502 293 557 503 307 557 minecraft:quartz_block
fill 507 293 599 508 307 599 minecraft:quartz_block
fill 512 293 559 512 307 560 minecraft:quartz_block
fill 512 293 571 512 307 572 minecraft:quartz_block
fill 512 293 583 512 307 584 minecraft:quartz_block
fill 512 293 595 512 307 596 minecraft:quartz_block
fill 477 295 596 483 296 596 minecraft:iron_block
setblock 473 297 560 minecraft:light[level=14]
setblock 473 297 568 minecraft:light[level=14]
setblock 473 297 576 minecraft:light[level=14]
setblock 473 297 584 minecraft:light[level=14]
setblock 473 297 592 minecraft:light[level=14]
setblock 481 297 560 minecraft:light[level=14]
setblock 481 297 568 minecraft:light[level=14]
setblock 481 297 576 minecraft:light[level=14]
setblock 481 297 584 minecraft:light[level=14]
setblock 481 297 592 minecraft:light[level=14]
setblock 489 297 560 minecraft:light[level=14]
setblock 489 297 568 minecraft:light[level=14]
setblock 489 297 576 minecraft:light[level=14]
setblock 489 297 584 minecraft:light[level=14]
setblock 489 297 592 minecraft:light[level=14]
setblock 497 297 560 minecraft:light[level=14]
setblock 497 297 568 minecraft:light[level=14]
setblock 497 297 576 minecraft:light[level=14]
setblock 497 297 584 minecraft:light[level=14]
setblock 497 297 592 minecraft:light[level=14]
setblock 505 297 560 minecraft:light[level=14]
setblock 505 297 568 minecraft:light[level=14]
setblock 505 297 576 minecraft:light[level=14]
setblock 505 297 584 minecraft:light[level=14]
setblock 505 297 592 minecraft:light[level=14]
fill 489 298 596 495 299 596 minecraft:iron_block
fill 501 298 591 505 299 595 minecraft:smooth_quartz
fill 503 298 596 503 298 597 minecraft:smooth_quartz
fill 472 300 567 472 300 569 minecraft:quartz_pillar
fill 472 300 579 472 300 581 minecraft:quartz_pillar
fill 472 300 591 472 300 593 minecraft:quartz_pillar
fill 478 300 597 480 300 597 minecraft:quartz_pillar
fill 482 300 559 484 300 559 minecraft:quartz_pillar
fill 490 300 597 492 300 597 minecraft:quartz_pillar
fill 494 300 559 496 300 559 minecraft:quartz_pillar
fill 502 300 592 504 300 594 minecraft:quartz_pillar
fill 502 300 597 504 300 597 minecraft:quartz_pillar
fill 506 300 559 508 300 559 minecraft:quartz_pillar
fill 510 300 567 510 300 569 minecraft:quartz_pillar
fill 510 300 579 510 300 581 minecraft:quartz_pillar
fill 510 300 591 510 300 593 minecraft:quartz_pillar
