setblock 101 196 484 minecraft:sea_lantern
setblock 101 196 486 minecraft:sea_lantern
setblock 101 196 488 minecraft:sea_lantern
fill 110 196 464 112 199 464 minecraft:cyan_stained_glass
fill 111 196 465 111 199 465 minecraft:cyan_stained_glass
fill 130 196 493 130 197 493 minecraft:deepslate_bricks
fill 95 197 484 95 198 484 minecraft:deepslate_bricks
fill 95 197 486 95 228 486 minecraft:deepslate_bricks
fill 95 197 488 95 228 488 minecraft:deepslate_bricks
fill 96 197 483 96 198 483 minecraft:deepslate_bricks
fill 96 197 485 96 198 485 minecraft:deepslate_bricks
fill 96 197 487 96 198 487 minecraft:deepslate_bricks
fill 96 197 489 96 198 489 minecraft:deepslate_bricks
fill 97 197 484 97 198 484 minecraft:deepslate_bricks
fill 97 197 486 97 198 486 minecraft:deepslate_bricks
fill 97 197 488 97 198 488 minecraft:deepslate_bricks
setblock 98 197 483 minecraft:deepslate_bricks
setblock 98 197 485 minecraft:deepslate_bricks
setblock 98 197 487 minecraft:deepslate_bricks
fill 98 197 489 98 198 489 minecraft:deepslate_bricks
setblock 99 197 484 minecraft:deepslate_bricks
setblock 99 197 486 minecraft:deepslate_bricks
setblock 99 197 488 minecraft:deepslate_bricks
fill 100 197 483 100 198 483 minecraft:deepslate_bricks
fill 100 197 485 100 198 485 minecraft:deepslate_bricks
fill 100 197 487 100 198 487 minecraft:deepslate_bricks
setblock 100 197 489 minecraft:deepslate_bricks
fill 101 197 484 101 198 484 minecraft:deepslate_bricks
fill 101 197 486 101 198 486 minecraft:deepslate_bricks
fill 101 197 488 101 198 488 minecraft:deepslate_bricks
fill 110 197 465 110 198 466 minecraft:cyan_stained_glass
fill 111 197 466 111 197 467 minecraft:cyan_stained_glass
fill 112 197 465 112 198 466 minecraft:cyan_stained_glass
fill 98 198 480 99 199 488 minecraft:sculk
fill 99 198 477 100 199 479 minecraft:sculk
fill 99 198 489 100 199 491 minecraft:sculk
fill 100 198 475 101 199 476 minecraft:sculk
fill 100 198 480 100 199 480 minecraft:sculk
fill 100 198 488 100 199 488 minecraft:sculk
fill 100 198 492 101 199 493 minecraft:sculk
fill 101 198 474 103 199 474 minecraft:sculk
fill 101 198 477 101 199 477 minecraft:sculk
fill 101 198 491 101 199 491 minecraft:sculk
fill 101 198 494 103 199 494 minecraft:sculk
fill 102 198 473 104 199 473 minecraft:sculk
fill 102 198 475 102 199 475 minecraft:sculk
fill 102 198 493 102 199 493 minecraft:sculk
fill 102 198 495 104 199 495 minecraft:sculk
fill 103 198 472 105 199 472 minecraft:sculk
fill 103 198 496 105 199 496 minecraft:sculk
fill 104 198 471 106 199 471 minecraft:sculk
fill 104 198 497 106 199 497 minecraft:sculk
fill 105 198 470 108 199 470 minecraft:sculk
fill 105 198 498 108 199 498 minecraft:sculk
fill 106 198 469 111 199 469 minecraft:sculk
fill 106 198 499 111 199 499 minecraft:sculk
fill 108 198 468 122 199 468 minecraft:sculk
fill 108 198 500 122 199 500 minecraft:sculk
setblock 110 198 467 minecraft:cyan_stained_glass
fill 111 198 466 111 199 466 minecraft:cyan_stained_glass
fill 111 198 467 119 199 467 minecraft:sculk
fill 111 198 501 119 199 501 minecraft:sculk
fill 119 198 469 124 199 469 minecraft:sculk
fill 119 198 499 124 199 499 minecraft:sculk
fill 122 198 470 125 199 470 minecraft:sculk
fill 122 198 498 125 199 498 minecraft:sculk
fill 124 198 471 126 199 471 minecraft:sculk
fill 124 198 497 126 199 497 minecraft:sculk
fill 125 198 472 127 199 472 minecraft:sculk
fill 125 198 496 127 199 496 minecraft:sculk
fill 126 198 473 128 199 473 minecraft:sculk
fill 126 198 495 128 199 495 minecraft:sculk
fill 127 198 474 129 199 474 minecraft:sculk
fill 127 198 494 129 199 494 minecraft:sculk
fill 128 198 475 130 199 475 minecraft:sculk
fill 128 198 493 130 199 493 minecraft:sculk
fill 129 198 476 130 199 477 minecraft:sculk
fill 129 198 491 130 199 492 minecraft:sculk
fill 130 198 478 131 199 480 minecraft:sculk
fill 130 198 488 131 199 490 minecraft:sculk
fill 131 198 477 131 199 477 minecraft:sculk
fill 131 198 481 132 199 487 minecraft:sculk
fill 131 198 491 131 199 491 minecraft:sculk
fill 132 198 480 132 199 480 minecraft:sculk
fill 132 198 488 132 199 488 minecraft:sculk
fill 96 199 484 97 199 488 minecraft:cyan_concrete
setblock 97 199 466 minecraft:light[level=11]
setblock 97 199 474 minecraft:light[level=11]
setblock 97 199 482 minecraft:light[level=11]
setblock 97 199 490 minecraft:light[level=11]
setblock 97 199 498 minecraft:light[level=11]
fill 100 199 484 100 199 487 minecraft:cyan_concrete
setblock 105 199 466 minecraft:light[level=11]
setblock 105 199 474 minecraft:light[level=11]
setblock 105 199 482 minecraft:light[level=11]
setblock 105 199 490 minecraft:light[level=11]
setblock 113 199 466 minecraft:light[level=11]
setblock 113 199 474 minecraft:light[level=11]
setblock 113 199 482 minecraft:light[level=11]
setblock 113 199 490 minecraft:light[level=11]
setblock 113 199 498 minecraft:light[level=11]
setblock 121 199 466 minecraft:light[level=11]
setblock 121 199 474 minecraft:light[level=11]
setblock 121 199 482 minecraft:light[level=11]
setblock 121 199 490 minecraft:light[level=11]
setblock 121 199 498 minecraft:light[level=11]
fill 125 199 464 127 200 465 minecraft:cyan_stained_glass
fill 126 199 466 126 200 467 minecraft:cyan_stained_glass
setblock 129 199 466 minecraft:light[level=11]
setblock 129 199 482 minecraft:light[level=11]
setblock 129 199 490 minecraft:light[level=11]
setblock 129 199 498 minecraft:light[level=11]
fill 96 200 473 96 205 475 minecraft:deepslate_bricks
fill 96 200 485 96 205 487 minecraft:deepslate_bricks
fill 96 200 497 96 205 499 minecraft:deepslate_bricks
fill 97 200 485 99 200 487 minecraft:cyan_concrete
fill 102 200 503 104 205 503 minecraft:deepslate_bricks
fill 106 200 465 108 205 465 minecraft:deepslate_bricks
fill 114 200 503 116 205 503 minecraft:deepslate_bricks
fill 118 200 465 120 205 465 minecraft:deepslate_bricks
fill 125 200 466 125 200 467 minecraft:cyan_stained_glass
fill 126 200 468 126 201 469 minecraft:cyan_stained_glass
fill 126 200 503 128 205 503 minecraft:deepslate_bricks
fill 127 200 466 127 200 467 minecraft:cyan_stained_glass
fill 130 200 465 132 205 465 minecraft:deepslate_bricks
fill 130 200 493 130 228 493 minecraft:deepslate_bricks
fill 134 200 473 134 205 475 minecraft:deepslate_bricks
fill 134 200 485 134 205 487 minecraft:deepslate_bricks
fill 134 200 497 134 205 499 minecraft:deepslate_bricks
fill 98 201 486 98 202 486 minecraft:cyan_concrete
setblock 126 201 465 minecraft:cyan_stained_glass
setblock 126 201 470 minecraft:cyan_stained_glass
fill 97 202 485 97 202 487 minecraft:cyan_concrete
fill 98 202 485 99 202 485 minecraft:cyan_concrete
fill 98 202 487 99 202 487 minecraft:cyan_concrete
setblock 99 202 486 minecraft:cyan_concrete
fill 95 205 467 95 205 472 minecraft:sculk
fill 95 205 479 95 205 484 minecraft:sculk
fill 95 205 491 95 205 496 minecraft:sculk
fill 95 205 503 95 205 504 minecraft:sculk
fill 96 205 504 99 205 504 minecraft:sculk
fill 99 205 464 104 205 464 minecraft:sculk
fill 106 205 504 111 205 504 minecraft:sculk
fill 111 205 464 116 205 464 minecraft:sculk
fill 118 205 504 123 205 504 minecraft:sculk
fill 123 205 464 128 205 464 minecraft:sculk
fill 130 205 504 135 205 504 minecraft:sculk
fill 135 205 464 135 205 469 minecraft:sculk
fill 135 205 476 135 205 481 minecraft:sculk
fill 135 205 488 135 205 493 minecraft:sculk
fill 135 205 500 135 205 503 minecraft:sculk
fill 94 206 469 94 211 472 minecraft:sea_lantern
fill 94 206 481 94 211 484 minecraft:sea_lantern
fill 94 206 493 94 211 496 minecraft:sea_lantern
fill 94 206 505 97 211 505 minecraft:sea_lantern
fill 101 206 463 104 211 463 minecraft:sea_lantern
fill 106 206 505 109 211 505 minecraft:sea_lantern
fill 113 206 463 116 211 463 minecraft:sea_lantern
fill 118 206 505 121 211 505 minecraft:sea_lantern
fill 125 206 463 128 211 463 minecraft:sea_lantern
fill 130 206 505 133 211 505 minecraft:sea_lantern
fill 136 206 464 136 211 467 minecraft:sea_lantern
fill 136 206 476 136 211 479 minecraft:sea_lantern
fill 136 206 488 136 211 491 minecraft:sea_lantern
fill 136 206 500 136 211 503 minecraft:sea_lantern
setblock 97 207 466 minecraft:light[level=11]
setblock 97 207 474 minecraft:light[level=11]
setblock 97 207 482 minecraft:light[level=11]
setblock 97 207 490 minecraft:light[level=11]
setblock 97 207 498 minecraft:light[level=11]
setblock 105 207 466 minecraft:light[level=11]
setblock 105 207 474 minecraft:light[level=11]
setblock 105 207 482 minecraft:light[level=11]
setblock 105 207 490 minecraft:light[level=11]
setblock 105 207 498 minecraft:light[level=11]
setblock 113 207 466 minecraft:light[level=11]
setblock 113 207 474 minecraft:light[level=11]
setblock 113 207 482 minecraft:light[level=11]
setblock 113 207 490 minecraft:light[level=11]
setblock 113 207 498 minecraft:light[level=11]
setblock 121 207 466 minecraft:light[level=11]
setblock 121 207 474 minecraft:light[level=11]
setblock 121 207 482 minecraft:light[level=11]
setblock 121 207 490 minecraft:light[level=11]
setblock 121 207 498 minecraft:light[level=11]
setblock 129 207 466 minecraft:light[level=11]
setblock 129 207 474 minecraft:light[level=11]
setblock 129 207 482 minecraft:light[level=11]
setblock 129 207 490 minecraft:light[level=11]
setblock 129 207 498 minecraft:light[level=11]
fill 128 208 481 128 213 481 minecraft:reinforced_deepslate
fill 128 208 501 130 208 502 minecraft:deepslate_bricks
fill 131 208 501 134 209 501 minecraft:cyan_concrete
fill 131 208 502 131 228 502 minecraft:deepslate_bricks
setblock 94 209 463 minecraft:deepslate_tiles
fill 94 209 464 94 209 468 minecraft:sculk
fill 94 209 497 94 210 498 minecraft:sculk
fill 94 209 499 94 209 500 minecraft:deepslate_tiles
setblock 107 209 463 minecraft:deepslate_tiles
fill 108 209 463 110 209 463 minecraft:sculk
fill 110 209 505 110 212 505 minecraft:sculk
setblock 111 209 505 minecraft:deepslate_tiles
setblock 122 209 505 minecraft:deepslate_tiles
fill 123 209 505 124 212 505 minecraft:sculk
setblock 125 209 505 minecraft:deepslate_tiles
fill 126 209 505 126 212 505 minecraft:sculk
fill 128 209 501 128 228 502 minecraft:deepslate_bricks
setblock 129 209 463 minecraft:deepslate_tiles
fill 129 209 501 130 209 501 minecraft:cyan_concrete
fill 129 209 502 130 228 502 minecraft:deepslate_bricks
fill 130 209 463 132 212 463 minecraft:sculk
setblock 136 209 468 minecraft:deepslate_tiles
fill 136 209 496 136 209 497 minecraft:sculk
setblock 136 209 498 minecraft:deepslate_tiles
fill 136 209 499 136 212 499 minecraft:sculk
setblock 136 209 504 minecraft:sculk
fill 136 209 505 136 211 505 minecraft:deepslate_tiles
fill 94 210 463 94 212 467 minecraft:sculk
setblock 94 210 468 minecraft:deepslate_tiles
fill 94 210 485 94 210 487 minecraft:sculk
fill 94 210 488 94 211 488 minecraft:deepslate_tiles
fill 94 210 489 94 214 489 minecraft:sculk
setblock 94 210 490 minecraft:deepslate_tiles
fill 94 210 491 94 212 492 minecraft:sculk
fill 94 210 499 94 212 500 minecraft:sculk
fill 94 210 502 94 210 503 minecraft:sculk
setblock 94 210 504 minecraft:deepslate_tiles
setblock 106 210 463 minecraft:deepslate_tiles
fill 107 210 463 108 212 463 minecraft:sculk
setblock 109 210 463 minecraft:deepslate_tiles
fill 110 210 463 110 212 463 minecraft:sculk
setblock 111 210 505 minecraft:sculk
fill 117 210 463 120 212 463 minecraft:sculk
fill 121 210 463 122 210 463 minecraft:deepslate_tiles
fill 122 210 505 122 212 505 minecraft:sculk
fill 123 210 463 124 212 463 minecraft:sculk
fill 125 210 505 125 212 505 minecraft:sculk
setblock 129 210 463 minecraft:sculk
fill 129 210 492 130 210 492 minecraft:cyan_concrete
fill 129 210 501 131 228 501 minecraft:deepslate_bricks
fill 136 210 468 136 212 471 minecraft:sculk
setblock 136 210 472 minecraft:deepslate_tiles
fill 136 210 473 136 210 475 minecraft:sculk
fill 136 210 496 136 213 496 minecraft:sculk
setblock 136 210 497 minecraft:deepslate_tiles
fill 136 210 498 136 212 498 minecraft:sculk
setblock 136 210 504 minecraft:deepslate_tiles
fill 94 211 468 94 212 468 minecraft:sculk
fill 94 211 473 94 212 476 minecraft:sculk
setblock 94 211 477 minecraft:deepslate_tiles
fill 94 211 485 94 212 485 minecraft:sculk
setblock 94 211 486 minecraft:deepslate_tiles
fill 94 211 487 94 212 487 minecraft:sculk
fill 94 211 490 94 212 490 minecraft:sculk
fill 94 211 497 94 212 497 minecraft:sculk
setblock 94 211 498 minecraft:deepslate_tiles
fill 94 211 502 94 212 502 minecraft:sculk
setblock 94 211 503 minecraft:deepslate_tiles
fill 94 211 504 94 212 504 minecraft:sculk
setblock 100 211 463 minecraft:deepslate_tiles
setblock 100 211 505 minecraft:deepslate_tiles
setblock 103 211 505 minecraft:deepslate_tiles
fill 104 211 505 104 212 505 minecraft:sculk
setblock 105 211 463 minecraft:deepslate_tiles
fill 106 211 463 106 212 463 minecraft:sculk
fill 109 211 463 109 212 463 minecraft:sculk
fill 111 211 505 112 211 505 minecraft:deepslate_tiles
setblock 114 211 505 minecraft:deepslate_tiles
fill 115 211 505 115 212 505 minecraft:sculk
setblock 121 211 463 minecraft:deepslate_tiles
fill 122 211 463 122 212 463 minecraft:sculk
fill 128 211 505 128 212 505 minecraft:sculk
setblock 129 211 463 minecraft:deepslate_tiles
fill 129 211 472 129 212 472 minecraft:cyan_concrete
setblock 129 211 505 minecraft:deepslate_tiles
fill 130 211 492 132 211 492 minecraft:cyan_concrete
fill 131 211 493 133 228 494 minecraft:deepslate_bricks
setblock 133 211 492 minecraft:deepslate_bricks
setblock 136 211 463 minecraft:deepslate_tiles
fill 136 211 472 136 212 474 minecraft:sculk
setblock 136 211 475 minecraft:deepslate_tiles
setblock 136 211 480 minecraft:deepslate_tiles
fill 136 211 481 136 212 481 minecraft:sculk
setblock 136 211 482 minecraft:deepslate_tiles
fill 136 211 483 136 212 487 minecraft:sculk
fill 136 211 492 136 212 493 minecraft:sculk
setblock 136 211 494 minecraft:deepslate_tiles
fill 136 211 497 136 212 497 minecraft:sculk
fill 136 211 504 136 212 504 minecraft:sculk
setblock 94 212 469 minecraft:sculk
fill 94 212 470 94 212 471 minecraft:sea_lantern
setblock 94 212 472 minecraft:sculk
setblock 94 212 477 minecraft:sculk
setblock 94 212 481 minecraft:sculk
fill 94 212 482 94 212 483 minecraft:sea_lantern
setblock 94 212 484 minecraft:sculk
fill 94 212 486 94 214 486 minecraft:sculk
setblock 94 212 488 minecraft:sculk
setblock 94 212 493 minecraft:sculk
fill 94 212 494 94 212 495 minecraft:sea_lantern
setblock 94 212 496 minecraft:sculk
fill 94 212 498 94 214 498 minecraft:sculk
setblock 94 212 503 minecraft:sculk
fill 94 212 505 94 213 505 minecraft:sculk
fill 95 212 505 96 212 505 minecraft:sea_lantern
fill 97 212 505 97 213 505 minecraft:sculk
fill 100 212 463 101 212 463 minecraft:sculk
setblock 100 212 505 minecraft:sculk
fill 102 212 463 103 212 463 minecraft:sea_lantern
setblock 103 212 505 minecraft:sculk
fill 104 212 463 105 212 463 minecraft:sculk
setblock 106 212 505 minecraft:sculk
fill 107 212 505 108 212 505 minecraft:sea_lantern
setblock 109 212 505 minecraft:sculk
fill 111 212 505 112 212 505 minecraft:sculk
setblock 113 212 463 minecraft:sculk
fill 114 212 463 115 212 463 minecraft:sea_lantern
setblock 114 212 505 minecraft:sculk
setblock 116 212 463 minecraft:sculk
setblock 118 212 505 minecraft:sculk
fill 119 212 505 120 212 505 minecraft:sea_lantern
setblock 121 212 463 minecraft:sculk
setblock 121 212 505 minecraft:sculk
fill 125 212 463 125 214 463 minecraft:sculk
fill 126 212 463 127 212 463 minecraft:sea_lantern
fill 128 212 463 129 212 463 minecraft:sculk
fill 129 212 505 130 212 505 minecraft:sculk
fill 130 212 472 131 213 472 minecraft:cyan_concrete
fill 131 212 492 131 228 492 minecraft:deepslate_bricks
fill 131 212 505 132 212 505 minecraft:sea_lantern
fill 132 212 492 134 212 492 minecraft:cyan_concrete
setblock 133 212 505 minecraft:sculk
fill 136 212 463 136 212 464 minecraft:sculk
fill 136 212 465 136 212 466 minecraft:sea_lantern
fill 136 212 467 136 213 467 minecraft:sculk
fill 136 212 475 136 212 476 minecraft:sculk
fill 136 212 477 136 212 478 minecraft:sea_lantern
fill 136 212 479 136 212 480 minecraft:sculk
fill 136 212 482 136 214 482 minecraft:sculk
setblock 136 212 488 minecraft:sculk
fill 136 212 489 136 212 490 minecraft:sea_lantern
setblock 136 212 491 minecraft:sculk
setblock 136 212 494 minecraft:sculk
setblock 136 212 500 minecraft:sculk
fill 136 212 501 136 212 502 minecraft:sea_lantern
setblock 136 212 503 minecraft:sculk
setblock 136 212 505 minecraft:sculk
fill 94 213 463 104 213 463 minecraft:deepslate_tiles
setblock 94 213 464 minecraft:sculk
fill 94 213 465 94 307 465 minecraft:deepslate_tiles
setblock 94 213 466 minecraft:sculk
fill 94 213 467 94 214 474 minecraft:deepslate_tiles
setblock 94 213 475 minecraft:sculk
fill 94 213 476 94 213 485 minecraft:deepslate_tiles
fill 94 213 487 94 307 488 minecraft:deepslate_tiles
fill 94 213 490 94 213 497 minecraft:deepslate_tiles
fill 94 213 499 94 213 504 minecraft:deepslate_tiles
fill 95 213 505 95 225 505 minecraft:deepslate_tiles
setblock 96 213 505 minecraft:sculk
fill 98 213 505 101 307 505 minecraft:deepslate_tiles
fill 103 213 505 123 213 505 minecraft:deepslate_tiles
setblock 105 213 463 minecraft:sculk
fill 106 213 463 124 213 463 minecraft:deepslate_tiles
setblock 124 213 505 minecraft:sculk
fill 125 213 505 136 214 505 minecraft:deepslate_tiles
fill 126 213 463 136 225 463 minecraft:deepslate_tiles
fill 132 213 472 133 214 472 minecraft:cyan_concrete
fill 132 213 492 133 228 492 minecraft:deepslate_bricks
setblock 134 213 492 minecraft:cyan_concrete
fill 136 213 464 136 225 466 minecraft:deepslate_tiles
fill 136 213 468 136 213 481 minecraft:deepslate_tiles
setblock 136 213 483 minecraft:sculk
fill 136 213 484 136 225 495 minecraft:deepslate_tiles
fill 136 213 497 136 213 504 minecraft:deepslate_tiles
fill 94 214 463 94 307 464 minecraft:deepslate_tiles
fill 94 214 466 94 307 466 minecraft:deepslate_tiles
fill 94 214 475 94 307 477 minecraft:deepslate_tiles
fill 94 214 478 94 215 478 minecraft:sculk
fill 94 214 479 94 214 485 minecraft:deepslate_tiles
fill 94 214 490 94 307 491 minecraft:deepslate_tiles
setblock 94 214 492 minecraft:sculk
fill 94 214 493 94 225 497 minecraft:deepslate_tiles
fill 94 214 499 94 307 499 minecraft:deepslate_tiles
setblock 94 214 500 minecraft:sculk
fill 94 214 501 94 307 503 minecraft:deepslate_tiles
setblock 94 214 504 minecraft:sculk
fill 94 214 505 94 225 505 minecraft:deepslate_tiles
setblock 95 214 463 minecraft:sculk
fill 96 214 463 116 214 463 minecraft:deepslate_tiles
fill 96 214 505 97 214 505 minecraft:deepslate_tiles
fill 102 214 505 111 214 505 minecraft:deepslate_tiles
setblock 112 214 505 minecraft:sculk
fill 113 214 505 124 214 505 minecraft:deepslate_tiles
setblock 117 214 463 minecraft:sculk
fill 118 214 463 121 307 463 minecraft:deepslate_tiles
setblock 122 214 463 minecraft:sculk
fill 123 214 463 124 307 463 minecraft:deepslate_tiles
setblock 128 214 481 minecraft:cyan_stained_glass
fill 134 214 472 134 215 472 minecraft:cyan_concrete
fill 136 214 467 136 225 472 minecraft:deepslate_tiles
setblock 136 214 473 minecraft:sculk
fill 136 214 474 136 307 474 minecraft:deepslate_tiles
setblock 136 214 475 minecraft:sculk
fill 136 214 476 136 225 481 minecraft:deepslate_tiles
fill 136 214 483 136 307 483 minecraft:deepslate_tiles
fill 136 214 496 136 307 496 minecraft:deepslate_tiles
setblock 136 214 497 minecraft:sculk
fill 136 214 498 136 225 501 minecraft:deepslate_tiles
setblock 136 214 502 minecraft:sculk
fill 136 214 503 136 225 504 minecraft:deepslate_tiles
fill 94 215 467 94 307 467 minecraft:deepslate_tiles
setblock 94 215 468 minecraft:sculk
fill 94 215 469 94 225 474 minecraft:deepslate_tiles
fill 94 215 479 94 307 479 minecraft:deepslate_tiles
setblock 94 215 480 minecraft:sculk
fill 94 215 481 94 225 484 minecraft:deepslate_tiles
setblock 94 215 485 minecraft:sculk
fill 94 215 486 94 307 486 minecraft:deepslate_tiles
fill 94 215 489 94 307 489 minecraft:deepslate_tiles
fill 94 215 492 94 307 492 minecraft:deepslate_tiles
fill 94 215 498 94 307 498 minecraft:deepslate_tiles
fill 94 215 500 94 307 500 minecraft:deepslate_tiles
fill 94 215 504 94 307 504 minecraft:deepslate_tiles
fill 95 215 463 101 225 463 minecraft:deepslate_tiles
fill 96 215 505 96 225 505 minecraft:deepslate_tiles
setblock 97 215 466 minecraft:light[level=11]
setblock 97 215 474 minecraft:light[level=11]
setblock 97 215 482 minecraft:light[level=11]
setblock 97 215 490 minecraft:light[level=11]
setblock 97 215 498 minecraft:light[level=11]
setblock 97 215 505 minecraft:sculk
setblock 102 215 463 minecraft:sculk
fill 102 215 505 105 307 505 minecraft:deepslate_tiles
fill 103 215 463 114 225 463 minecraft:deepslate_tiles
setblock 105 215 466 minecraft:light[level=11]
setblock 105 215 474 minecraft:light[level=11]
setblock 105 215 482 minecraft:light[level=11]
setblock 105 215 490 minecraft:light[level=11]
setblock 105 215 498 minecraft:light[level=11]
setblock 106 215 505 minecraft:sculk
fill 107 215 505 107 225 505 minecraft:deepslate_tiles
setblock 108 215 505 minecraft:sculk
fill 109 215 505 112 225 505 minecraft:deepslate_tiles
setblock 113 215 466 minecraft:light[level=11]
setblock 113 215 474 minecraft:light[level=11]
setblock 113 215 482 minecraft:light[level=11]
setblock 113 215 490 minecraft:light[level=11]
setblock 113 215 498 minecraft:light[level=11]
setblock 113 215 505 minecraft:sculk
fill 114 215 505 114 307 505 minecraft:deepslate_tiles
fill 115 215 463 116 215 463 minecraft:sculk
setblock 115 215 505 minecraft:sculk
fill 116 215 505 125 225 505 minecraft:deepslate_tiles
fill 117 215 463 117 307 463 minecraft:deepslate_tiles
setblock 121 215 466 minecraft:light[level=11]
setblock 121 215 474 minecraft:light[level=11]
setblock 121 215 482 minecraft:light[level=11]
setblock 121 215 490 minecraft:light[level=11]
setblock 121 215 498 minecraft:light[level=11]
fill 122 215 463 122 307 463 minecraft:deepslate_tiles
fill 125 215 463 125 225 463 minecraft:deepslate_tiles
setblock 126 215 505 minecraft:sculk
fill 127 215 505 132 225 505 minecraft:deepslate_tiles
fill 128 215 481 128 226 481 minecraft:reinforced_deepslate
setblock 129 215 466 minecraft:light[level=11]
setblock 129 215 474 minecraft:light[level=11]
fill 129 215 481 133 215 481 minecraft:cyan_stained_glass
setblock 129 215 482 minecraft:light[level=11]
setblock 129 215 490 minecraft:light[level=11]
setblock 129 215 498 minecraft:light[level=11]
setblock 133 215 505 minecraft:sculk
fill 134 215 505 136 307 505 minecraft:deepslate_tiles
fill 136 215 473 136 307 473 minecraft:deepslate_tiles
fill 136 215 475 136 307 475 minecraft:deepslate_tiles
fill 136 215 482 136 307 482 minecraft:deepslate_tiles
fill 136 215 497 136 307 497 minecraft:deepslate_tiles
fill 136 215 502 136 225 502 minecraft:deepslate_tiles
fill 94 216 468 94 307 468 minecraft:deepslate_tiles
fill 94 216 478 94 307 478 minecraft:deepslate_tiles
fill 94 216 480 94 307 480 minecraft:deepslate_tiles
fill 94 216 485 94 307 485 minecraft:deepslate_tiles
fill 97 216 505 97 225 505 minecraft:deepslate_tiles
fill 102 216 463 102 225 463 minecraft:deepslate_tiles
fill 106 216 505 106 225 505 minecraft:deepslate_tiles
fill 108 216 505 108 225 505 minecraft:deepslate_tiles
fill 113 216 505 113 307 505 minecraft:deepslate_tiles
fill 115 216 463 116 225 463 minecraft:deepslate_tiles
fill 115 216 505 115 307 505 minecraft:deepslate_tiles
fill 126 216 505 126 307 505 minecraft:deepslate_tiles
fill 130 216 481 135 216 481 minecraft:cyan_stained_glass
fill 133 216 480 134 216 480 minecraft:cyan_stained_glass
fill 133 216 482 134 216 482 minecraft:cyan_stained_glass
fill 133 216 505 133 225 505 minecraft:deepslate_tiles
fill 132 217 481 135 217 481 minecraft:cyan_stained_glass
setblock 134 217 480 minecraft:cyan_stained_glass
setblock 134 217 482 minecraft:cyan_stained_glass
fill 96 220 473 96 225 475 minecraft:deepslate_bricks
fill 96 220 485 96 225 487 minecraft:deepslate_bricks
fill 96 220 497 96 225 499 minecraft:deepslate_bricks
fill 102 220 503 104 225 503 minecraft:deepslate_bricks
fill 106 220 465 108 225 465 minecraft:deepslate_bricks
fill 114 220 503 116 225 503 minecraft:deepslate_bricks
fill 118 220 465 120 225 465 minecraft:deepslate_bricks
fill 126 220 503 128 225 503 minecraft:deepslate_bricks
fill 130 220 465 132 225 465 minecraft:deepslate_bricks
fill 134 220 469 134 221 469 minecraft:cyan_concrete
fill 134 220 473 134 225 475 minecraft:deepslate_bricks
fill 134 220 485 134 225 487 minecraft:deepslate_bricks
fill 134 220 497 134 225 499 minecraft:deepslate_bricks
fill 95 221 472 95 224 473 minecraft:cyan_stained_glass
fill 97 221 473 97 224 475 minecraft:cyan_stained_glass
fill 132 221 469 133 222 469 minecraft:cyan_concrete
fill 96 222 472 96 223 472 minecraft:cyan_stained_glass
fill 96 222 476 96 223 476 minecraft:cyan_stained_glass
fill 98 222 473 98 224 475 minecraft:cyan_stained_glass
fill 99 222 474 100 224 474 minecraft:cyan_stained_glass
fill 131 222 469 131 223 469 minecraft:cyan_concrete
setblock 97 223 466 minecraft:light[level=11]
setblock 97 223 472 minecraft:cyan_stained_glass
setblock 97 223 476 minecraft:cyan_stained_glass
setblock 97 223 482 minecraft:light[level=11]
setblock 97 223 490 minecraft:light[level=11]
setblock 97 223 498 minecraft:light[level=11]
fill 99 223 473 100 223 473 minecraft:cyan_stained_glass
fill 99 223 475 100 223 475 minecraft:cyan_stained_glass
fill 101 223 474 102 224 474 minecraft:cyan_stained_glass
setblock 105 223 466 minecraft:light[level=11]
setblock 105 223 474 minecraft:light[level=11]
setblock 105 223 482 minecraft:light[level=11]
setblock 105 223 490 minecraft:light[level=11]
setblock 105 223 498 minecraft:light[level=11]
setblock 113 223 466 minecraft:light[level=11]
setblock 113 223 474 minecraft:light[level=11]
setblock 113 223 482 minecraft:light[level=11]
setblock 113 223 490 minecraft:light[level=11]
setblock 113 223 498 minecraft:light[level=11]
fill 118 223 502 120 224 504 minecraft:cyan_stained_glass
fill 119 223 501 119 226 501 minecraft:cyan_stained_glass
setblock 121 223 466 minecraft:light[level=11]
setblock 121 223 474 minecraft:light[level=11]
setblock 121 223 482 minecraft:light[level=11]
setblock 121 223 490 minecraft:light[level=11]
setblock 121 223 498 minecraft:light[level=11]
setblock 129 223 466 minecraft:light[level=11]
fill 129 223 469 130 224 469 minecraft:cyan_concrete
setblock 129 223 474 minecraft:light[level=11]
setblock 129 223 482 minecraft:light[level=11]
setblock 129 223 490 minecraft:light[level=11]
setblock 129 223 498 minecraft:light[level=11]
setblock 99 224 473 minecraft:cyan_stained_glass
setblock 99 224 475 minecraft:cyan_stained_glass
fill 117 224 502 117 225 504 minecraft:cyan_stained_glass
fill 118 224 500 118 225 501 minecraft:cyan_stained_glass
fill 119 224 499 119 225 500 minecraft:cyan_stained_glass
fill 120 224 500 120 225 501 minecraft:cyan_stained_glass
fill 121 224 502 121 224 504 minecraft:cyan_stained_glass
fill 95 225 467 95 225 472 minecraft:sculk
fill 95 225 479 95 225 484 minecraft:sculk
fill 95 225 491 95 225 496 minecraft:sculk
fill 95 225 503 95 225 504 minecraft:sculk
fill 96 225 504 99 225 504 minecraft:sculk
fill 99 225 464 104 225 464 minecraft:sculk
fill 106 225 504 111 225 504 minecraft:sculk
fill 111 225 464 116 225 464 minecraft:sculk
fill 118 225 502 121 225 503 minecraft:cyan_stained_glass
fill 118 225 504 123 225 504 minecraft:sculk
fill 123 225 464 128 225 464 minecraft:sculk
fill 127 225 500 127 225 502 minecraft:cyan_concrete
fill 128 225 499 128 225 500 minecraft:cyan_concrete
fill 128 225 504 129 225 504 minecraft:cyan_concrete
fill 129 225 491 129 225 495 minecraft:cyan_concrete
fill 129 225 499 131 225 499 minecraft:cyan_concrete
fill 130 225 490 130 225 492 minecraft:cyan_concrete
fill 130 225 494 130 225 496 minecraft:cyan_concrete
fill 130 225 504 135 225 504 minecraft:sculk
fill 131 225 490 133 225 491 minecraft:cyan_concrete
fill 131 225 495 133 225 496 minecraft:cyan_concrete
fill 131 225 500 132 225 500 minecraft:cyan_concrete
fill 131 225 503 132 225 503 minecraft:cyan_concrete
fill 132 225 501 132 226 502 minecraft:cyan_concrete
fill 134 225 491 134 225 495 minecraft:cyan_concrete
fill 135 225 464 135 225 469 minecraft:sculk
fill 135 225 476 135 225 481 minecraft:sculk
fill 135 225 488 135 225 493 minecraft:sculk
setblock 135 225 494 minecraft:cyan_concrete
fill 135 225 500 135 225 503 minecraft:sculk
fill 94 226 469 94 228 472 minecraft:sea_lantern
fill 94 226 473 94 307 474 minecraft:deepslate_tiles
fill 94 226 481 94 228 484 minecraft:sea_lantern
fill 94 226 493 94 228 496 minecraft:sea_lantern
fill 94 226 497 94 307 497 minecraft:deepslate_tiles
fill 94 226 505 97 228 505 minecraft:sea_lantern
fill 95 226 463 100 307 463 minecraft:deepslate_tiles
fill 101 226 463 104 228 463 minecraft:sea_lantern
fill 105 226 463 112 307 463 minecraft:deepslate_tiles
fill 106 226 505 109 228 505 minecraft:sea_lantern
fill 110 226 505 112 307 505 minecraft:deepslate_tiles
fill 113 226 463 116 228 463 minecraft:sea_lantern
fill 116 226 505 117 307 505 minecraft:deepslate_tiles
fill 118 226 502 120 226 504 minecraft:cyan_stained_glass
fill 118 226 505 121 228 505 minecraft:sea_lantern
fill 122 226 505 125 307 505 minecraft:deepslate_tiles
fill 125 226 463 128 228 463 minecraft:sea_lantern
fill 127 226 501 127 226 502 minecraft:cyan_concrete
fill 127 226 505 129 307 505 minecraft:deepslate_tiles
fill 128 226 500 128 227 500 minecraft:cyan_concrete
fill 128 226 503 128 227 503 minecraft:cyan_concrete
fill 129 226 463 136 307 463 minecraft:deepslate_tiles
fill 129 226 492 129 226 494 minecraft:cyan_concrete
fill 129 226 499 130 226 499 minecraft:cyan_concrete
fill 129 226 504 130 226 504 minecraft:cyan_concrete
fill 130 226 491 130 226 492 minecraft:cyan_concrete
fill 130 226 494 130 226 495 minecraft:cyan_concrete
fill 130 226 505 133 228 505 minecraft:sea_lantern
fill 131 226 490 132 226 491 minecraft:cyan_concrete
fill 131 226 495 133 227 495 minecraft:cyan_concrete
fill 131 226 500 131 227 500 minecraft:cyan_concrete
fill 131 226 503 131 227 503 minecraft:cyan_concrete
fill 133 226 491 134 226 491 minecraft:cyan_concrete
fill 134 226 492 134 226 494 minecraft:cyan_concrete
fill 136 226 464 136 228 467 minecraft:sea_lantern
fill 136 226 468 136 307 472 minecraft:deepslate_tiles
fill 136 226 476 136 228 479 minecraft:sea_lantern
fill 136 226 480 136 307 481 minecraft:deepslate_tiles
fill 136 226 484 136 307 487 minecraft:deepslate_tiles
fill 136 226 488 136 228 491 minecraft:sea_lantern
fill 136 226 492 136 307 495 minecraft:deepslate_tiles
fill 136 226 498 136 307 499 minecraft:deepslate_tiles
fill 136 226 500 136 228 503 minecraft:sea_lantern
fill 136 226 504 136 307 504 minecraft:deepslate_tiles
setblock 130 227 492 minecraft:cyan_concrete
setblock 130 227 494 minecraft:cyan_concrete
fill 131 227 491 133 227 491 minecraft:cyan_concrete
fill 134 227 492 134 227 493 minecraft:cyan_concrete
fill 94 229 469 94 245 472 minecraft:deepslate_tiles
fill 94 229 481 94 245 484 minecraft:deepslate_tiles
fill 94 229 493 94 245 496 minecraft:deepslate_tiles
fill 94 229 505 97 245 505 minecraft:deepslate_tiles
fill 101 229 463 104 245 463 minecraft:deepslate_tiles
fill 106 229 505 109 245 505 minecraft:deepslate_tiles
fill 113 229 463 116 245 463 minecraft:deepslate_tiles
fill 118 229 505 121 245 505 minecraft:deepslate_tiles
fill 125 229 463 128 245 463 minecraft:deepslate_tiles
fill 130 229 505 133 245 505 minecraft:deepslate_tiles
fill 136 229 464 136 245 467 minecraft:deepslate_tiles
fill 136 229 476 136 245 479 minecraft:deepslate_tiles
fill 136 229 488 136 245 491 minecraft:deepslate_tiles
fill 136 229 500 136 245 503 minecraft:deepslate_tiles
setblock 97 231 466 minecraft:light[level=11]
setblock 97 231 474 minecraft:light[level=11]
setblock 97 231 482 minecraft:light[level=11]
setblock 97 231 490 minecraft:light[level=11]
setblock 97 231 498 minecraft:light[level=11]
setblock 105 231 466 minecraft:light[level=11]
setblock 105 231 474 minecraft:light[level=11]
setblock 105 231 482 minecraft:light[level=11]
setblock 105 231 490 minecraft:light[level=11]
setblock 105 231 498 minecraft:light[level=11]
setblock 113 231 466 minecraft:light[level=11]
setblock 113 231 474 minecraft:light[level=11]
setblock 113 231 482 minecraft:light[level=11]
setblock 113 231 490 minecraft:light[level=11]
setblock 113 231 498 minecraft:light[level=11]
setblock 121 231 466 minecraft:light[level=11]
setblock 121 231 474 minecraft:light[level=11]
setblock 121 231 482 minecraft:light[level=11]
setblock 121 231 490 minecraft:light[level=11]
setblock 121 231 498 minecraft:light[level=11]
setblock 129 231 466 minecraft:light[level=11]
setblock 129 231 474 minecraft:light[level=11]
setblock 129 231 482 minecraft:light[level=11]
setblock 129 231 490 minecraft:light[level=11]
setblock 129 231 498 minecraft:light[level=11]
fill 101 234 483 111 234 483 minecraft:sculk
fill 103 234 482 112 234 482 minecraft:sculk
fill 103 234 484 112 234 484 minecraft:sculk
fill 104 234 481 113 234 481 minecraft:sculk
fill 104 234 485 113 234 485 minecraft:sculk
fill 108 234 472 108 235 478 minecraft:sculk
fill 108 234 488 108 235 494 minecraft:sculk
fill 109 234 473 110 234 480 minecraft:sculk
fill 109 234 486 110 234 493 minecraft:sculk
fill 111 234 474 111 234 480 minecraft:sculk
fill 111 234 486 111 234 492 minecraft:sculk
fill 112 234 475 112 234 480 minecraft:sculk
fill 112 234 486 112 234 491 minecraft:sculk
fill 113 234 476 113 234 480 minecraft:sculk
fill 113 234 486 113 234 490 minecraft:sculk
fill 114 234 478 119 234 480 minecraft:sculk
fill 114 234 486 119 234 488 minecraft:sculk
fill 115 234 476 120 234 477 minecraft:sculk
fill 115 234 481 124 234 481 minecraft:sculk
fill 115 234 485 124 234 485 minecraft:sculk
fill 115 234 489 120 234 490 minecraft:sculk
fill 116 234 475 120 235 475 minecraft:sculk
fill 116 234 482 125 234 482 minecraft:sculk
fill 116 234 484 125 234 484 minecraft:sculk
fill 116 234 491 120 235 491 minecraft:sculk
fill 117 234 474 120 235 474 minecraft:sculk
fill 117 234 483 127 234 483 minecraft:sculk
fill 117 234 492 120 235 492 minecraft:sculk
fill 118 234 473 120 235 473 minecraft:sculk
fill 118 234 493 120 235 493 minecraft:sculk
fill 120 234 472 120 235 472 minecraft:sculk
fill 120 234 478 120 235 478 minecraft:sculk
fill 120 234 488 120 235 488 minecraft:sculk
fill 120 234 494 120 235 494 minecraft:sculk
fill 95 235 464 104 235 504 minecraft:sculk
fill 105 235 464 106 235 482 minecraft:sculk
fill 105 235 483 109 235 483 minecraft:cyan_concrete
fill 105 235 484 106 235 504 minecraft:sculk
fill 107 235 464 107 235 481 minecraft:sculk
fill 107 235 482 110 235 482 minecraft:cyan_concrete
fill 107 235 484 110 235 484 minecraft:cyan_concrete
fill 107 235 485 107 235 504 minecraft:sculk
fill 108 235 464 135 235 471 minecraft:sculk
fill 108 235 479 108 235 481 minecraft:sculk
fill 108 235 485 108 235 487 minecraft:sculk
fill 108 235 495 135 235 504 minecraft:sculk
fill 109 235 472 109 235 480 minecraft:sculk
fill 109 235 481 110 235 481 minecraft:cyan_concrete
fill 109 235 485 110 235 485 minecraft:cyan_concrete
fill 109 235 486 109 235 494 minecraft:sculk
fill 110 235 472 115 235 475 minecraft:sculk
fill 110 235 476 111 235 480 minecraft:cyan_concrete
setblock 110 235 483 minecraft:bone_block
fill 110 235 486 111 235 490 minecraft:cyan_concrete
fill 110 235 491 115 235 494 minecraft:sculk
setblock 111 235 481 minecraft:bone_block
fill 111 235 482 111 235 484 minecraft:sea_lantern
setblock 111 235 485 minecraft:bone_block
fill 112 235 476 116 235 476 minecraft:sculk
fill 112 235 477 112 235 479 minecraft:cyan_concrete
setblock 112 235 480 minecraft:bone_block
fill 112 235 481 112 235 482 minecraft:shroomlight
fill 112 235 484 112 235 485 minecraft:shroomlight
setblock 112 235 486 minecraft:bone_block
fill 112 235 487 112 235 489 minecraft:cyan_concrete
fill 112 235 490 116 235 490 minecraft:sculk
fill 113 235 477 115 235 477 minecraft:sculk
fill 113 235 478 113 235 479 minecraft:cyan_concrete
fill 113 235 480 115 235 480 minecraft:sea_lantern
setblock 113 235 481 minecraft:shroomlight
setblock 113 235 485 minecraft:shroomlight
fill 113 235 486 115 235 486 minecraft:sea_lantern
fill 113 235 487 113 235 488 minecraft:cyan_concrete
fill 113 235 489 115 235 489 minecraft:sculk
setblock 114 235 478 minecraft:sculk
setblock 114 235 479 minecraft:bone_block
setblock 114 235 487 minecraft:bone_block
setblock 114 235 488 minecraft:sculk
fill 115 235 478 118 235 479 minecraft:cyan_concrete
fill 115 235 481 116 235 481 minecraft:shroomlight
fill 115 235 485 116 235 485 minecraft:shroomlight
fill 115 235 487 118 235 488 minecraft:cyan_concrete
fill 116 235 472 116 235 474 minecraft:sculk
fill 116 235 477 118 235 477 minecraft:cyan_concrete
setblock 116 235 480 minecraft:bone_block
setblock 116 235 482 minecraft:shroomlight
setblock 116 235 484 minecraft:shroomlight
setblock 116 235 486 minecraft:bone_block
fill 116 235 489 118 235 489 minecraft:cyan_concrete
fill 116 235 492 116 235 494 minecraft:sculk
fill 117 235 472 117 235 473 minecraft:sculk
fill 117 235 476 118 235 476 minecraft:cyan_concrete
fill 117 235 480 118 235 480 minecraft:cyan_concrete
setblock 117 235 481 minecraft:bone_block
fill 117 235 482 117 235 484 minecraft:sea_lantern
setblock 117 235 485 minecraft:bone_block
fill 117 235 486 118 235 486 minecraft:cyan_concrete
fill 117 235 490 118 235 490 minecraft:cyan_concrete
fill 117 235 493 117 235 494 minecraft:sculk
fill 118 235 472 119 235 472 minecraft:sculk
fill 118 235 481 119 235 482 minecraft:cyan_concrete
setblock 118 235 483 minecraft:bone_block
fill 118 235 484 119 235 485 minecraft:cyan_concrete
fill 118 235 494 119 235 494 minecraft:sculk
fill 119 235 476 119 235 480 minecraft:sculk
fill 119 235 483 123 235 483 minecraft:cyan_concrete
fill 119 235 486 119 235 490 minecraft:sculk
fill 120 235 476 135 235 477 minecraft:sculk
fill 120 235 479 135 235 481 minecraft:sculk
fill 120 235 482 121 235 482 minecraft:cyan_concrete
fill 120 235 484 121 235 484 minecraft:cyan_concrete
fill 120 235 485 135 235 487 minecraft:sculk
fill 120 235 489 135 235 490 minecraft:sculk
fill 121 235 472 135 235 475 minecraft:sculk
fill 121 235 478 135 235 478 minecraft:sculk
fill 121 235 488 135 235 488 minecraft:sculk
fill 121 235 491 135 235 494 minecraft:sculk
fill 122 235 482 135 235 482 minecraft:sculk
fill 122 235 484 135 235 484 minecraft:sculk
fill 124 235 483 135 235 483 minecraft:sculk
fill 95 236 470 95 236 496 minecraft:basalt
setblock 96 236 468 minecraft:magma_block
fill 96 236 469 98 236 470 minecraft:basalt
setblock 96 236 471 minecraft:magma_block
fill 96 236 472 98 238 473 minecraft:basalt
setblock 96 236 474 minecraft:magma_block
fill 96 236 475 98 240 476 minecraft:basalt
setblock 96 236 477 minecraft:magma_block
fill 96 236 478 98 241 479 minecraft:basalt
setblock 96 236 480 minecraft:magma_block
fill 96 236 481 98 241 482 minecraft:basalt
setblock 96 236 483 minecraft:magma_block
fill 96 236 484 98 241 485 minecraft:basalt
setblock 96 236 486 minecraft:magma_block
fill 96 236 487 98 241 488 minecraft:basalt
setblock 96 236 489 minecraft:magma_block
fill 96 236 490 98 240 491 minecraft:basalt
setblock 96 236 492 minecraft:magma_block
fill 96 236 493 98 238 494 minecraft:basalt
setblock 96 236 495 minecraft:magma_block
fill 96 236 496 98 236 497 minecraft:basalt
setblock 96 236 498 minecraft:magma_block
fill 97 236 467 98 236 468 minecraft:basalt
fill 97 236 471 104 239 471 minecraft:basalt
fill 97 236 474 102 240 474 minecraft:basalt
fill 97 236 477 100 242 477 minecraft:basalt
fill 97 236 480 99 243 480 minecraft:basalt
fill 97 236 483 99 243 483 minecraft:basalt
fill 97 236 486 99 243 486 minecraft:basalt
fill 97 236 489 100 242 489 minecraft:basalt
fill 97 236 492 102 240 492 minecraft:basalt
fill 97 236 495 104 239 495 minecraft:basalt
fill 97 236 498 101 236 499 minecraft:basalt
fill 98 236 466 101 236 466 minecraft:basalt
setblock 98 236 500 minecraft:basalt
fill 99 236 465 104 236 465 minecraft:basalt
setblock 99 236 467 minecraft:magma_block
fill 99 236 468 101 238 469 minecraft:basalt
setblock 99 236 470 minecraft:magma_block
fill 99 236 472 101 241 472 minecraft:basalt
setblock 99 236 473 minecraft:magma_block
fill 99 236 475 101 243 475 minecraft:basalt
setblock 99 236 476 minecraft:magma_block
fill 99 236 478 100 244 478 minecraft:basalt
setblock 99 236 479 minecraft:magma_block
fill 99 236 481 99 245 481 minecraft:basalt
setblock 99 236 482 minecraft:magma_block
fill 99 236 484 99 245 484 minecraft:basalt
setblock 99 236 485 minecraft:magma_block
fill 99 236 487 99 245 487 minecraft:basalt
setblock 99 236 488 minecraft:magma_block
fill 99 236 490 101 244 490 minecraft:basalt
setblock 99 236 491 minecraft:magma_block
fill 99 236 493 101 242 493 minecraft:basalt
setblock 99 236 494 minecraft:magma_block
fill 99 236 496 101 240 496 minecraft:basalt
setblock 99 236 497 minecraft:magma_block
setblock 99 236 500 minecraft:magma_block
fill 99 236 501 104 236 501 minecraft:basalt
fill 100 236 467 107 237 467 minecraft:basalt
fill 100 236 470 107 241 470 minecraft:basalt
fill 100 236 473 103 243 473 minecraft:basalt
fill 100 236 476 101 245 476 minecraft:basalt
fill 100 236 488 100 245 488 minecraft:basalt
fill 100 236 491 101 244 491 minecraft:basalt
fill 100 236 494 104 242 494 minecraft:basalt
fill 100 236 497 107 240 497 minecraft:basalt
fill 100 236 500 107 237 500 minecraft:basalt
fill 101 236 464 107 236 464 minecraft:basalt
setblock 101 236 502 minecraft:basalt
setblock 102 236 466 minecraft:magma_block
fill 102 236 468 104 240 468 minecraft:basalt
setblock 102 236 469 minecraft:magma_block
setblock 102 236 472 minecraft:magma_block
setblock 102 236 493 minecraft:magma_block
setblock 102 236 496 minecraft:magma_block
fill 102 236 498 104 240 498 minecraft:basalt
setblock 102 236 499 minecraft:magma_block
setblock 102 236 502 minecraft:magma_block
fill 102 236 503 107 236 503 minecraft:basalt
fill 103 236 466 110 239 466 minecraft:basalt
fill 103 236 469 109 242 469 minecraft:basalt
fill 103 236 472 104 245 472 minecraft:basalt
fill 103 236 493 103 245 493 minecraft:basalt
fill 103 236 496 107 236 496 minecraft:basalt
fill 103 236 499 110 240 499 minecraft:basalt
fill 103 236 502 110 237 502 minecraft:basalt
setblock 104 236 504 minecraft:basalt
setblock 105 236 465 minecraft:magma_block
setblock 105 236 468 minecraft:magma_block
setblock 105 236 471 minecraft:magma_block
setblock 105 236 495 minecraft:magma_block
setblock 105 236 498 minecraft:magma_block
setblock 105 236 501 minecraft:magma_block
setblock 105 236 504 minecraft:magma_block
fill 106 236 465 113 239 465 minecraft:basalt
fill 106 236 468 113 243 468 minecraft:basalt
fill 106 236 498 113 243 498 minecraft:basalt
fill 106 236 501 113 239 501 minecraft:basalt
fill 106 236 504 113 237 504 minecraft:basalt
setblock 108 236 464 minecraft:magma_block
setblock 108 236 467 minecraft:magma_block
setblock 108 236 497 minecraft:magma_block
setblock 108 236 500 minecraft:magma_block
setblock 108 236 503 minecraft:magma_block
fill 109 236 464 116 239 464 minecraft:basalt
fill 109 236 467 116 243 467 minecraft:basalt
fill 109 236 497 109 245 497 minecraft:basalt
fill 109 236 500 116 242 500 minecraft:basalt
fill 109 236 503 116 238 503 minecraft:basalt
setblock 111 236 466 minecraft:magma_block
setblock 111 236 499 minecraft:magma_block
setblock 111 236 502 minecraft:magma_block
fill 112 236 466 119 242 466 minecraft:basalt
fill 112 236 499 119 242 499 minecraft:basalt
fill 112 236 502 119 240 502 minecraft:basalt
setblock 114 236 465 minecraft:magma_block
setblock 114 236 468 minecraft:magma_block
setblock 114 236 498 minecraft:magma_block
setblock 114 236 501 minecraft:magma_block
setblock 114 236 504 minecraft:magma_block
fill 115 236 465 122 240 465 minecraft:basalt
fill 115 236 468 122 242 468 minecraft:basalt
fill 115 236 498 122 242 498 minecraft:basalt
fill 115 236 501 122 240 501 minecraft:basalt
fill 115 236 504 122 237 504 minecraft:basalt
setblock 117 236 464 minecraft:magma_block
setblock 117 236 467 minecraft:magma_block
setblock 117 236 500 minecraft:magma_block
setblock 117 236 503 minecraft:magma_block
fill 118 236 464 125 237 464 minecraft:basalt
fill 118 236 467 125 240 467 minecraft:basalt
fill 118 236 500 125 239 500 minecraft:basalt
fill 118 236 503 125 236 503 minecraft:basalt
fill 119 236 469 119 245 469 minecraft:basalt
fill 119 236 497 125 242 497 minecraft:basalt
setblock 120 236 466 minecraft:magma_block
setblock 120 236 469 minecraft:magma_block
setblock 120 236 499 minecraft:magma_block
setblock 120 236 502 minecraft:magma_block
fill 121 236 466 128 237 466 minecraft:basalt
fill 121 236 469 125 242 470 minecraft:basalt
fill 121 236 496 128 240 496 minecraft:basalt
fill 121 236 499 128 238 499 minecraft:basalt
fill 121 236 502 127 236 502 minecraft:basalt
setblock 123 236 465 minecraft:magma_block
setblock 123 236 468 minecraft:magma_block
setblock 123 236 471 minecraft:magma_block
setblock 123 236 495 minecraft:magma_block
setblock 123 236 498 minecraft:magma_block
setblock 123 236 501 minecraft:magma_block
setblock 123 236 504 minecraft:magma_block
fill 124 236 465 129 236 465 minecraft:basalt
fill 124 236 468 131 237 468 minecraft:basalt
fill 124 236 471 128 241 472 minecraft:basalt
fill 124 236 494 125 244 495 minecraft:basalt
fill 124 236 498 131 237 498 minecraft:basalt
fill 124 236 501 129 236 501 minecraft:basalt
setblock 124 236 504 minecraft:basalt
fill 125 236 473 125 245 473 minecraft:basalt
fill 125 236 493 128 242 493 minecraft:basalt
setblock 126 236 464 minecraft:magma_block
setblock 126 236 467 minecraft:magma_block
fill 126 236 469 128 240 469 minecraft:basalt
setblock 126 236 470 minecraft:magma_block
setblock 126 236 473 minecraft:magma_block
fill 126 236 474 131 240 474 minecraft:basalt
fill 126 236 492 131 240 492 minecraft:basalt
setblock 126 236 494 minecraft:magma_block
fill 126 236 495 131 239 495 minecraft:basalt
setblock 126 236 497 minecraft:magma_block
setblock 126 236 500 minecraft:magma_block
setblock 126 236 503 minecraft:magma_block
setblock 127 236 464 minecraft:basalt
fill 127 236 467 131 236 467 minecraft:basalt
fill 127 236 470 133 236 470 minecraft:basalt
fill 127 236 473 134 237 473 minecraft:basalt
fill 127 236 475 128 244 476 minecraft:basalt
fill 127 236 490 128 244 491 minecraft:basalt
fill 127 236 494 134 236 494 minecraft:basalt
fill 127 236 497 132 236 497 minecraft:basalt
fill 127 236 500 130 236 500 minecraft:basalt
fill 128 236 477 128 245 478 minecraft:basalt
fill 128 236 488 131 242 489 minecraft:basalt
setblock 129 236 466 minecraft:magma_block
setblock 129 236 469 minecraft:magma_block
fill 129 236 471 131 239 471 minecraft:basalt
setblock 129 236 472 minecraft:magma_block
setblock 129 236 475 minecraft:magma_block
fill 129 236 476 131 241 477 minecraft:basalt
setblock 129 236 478 minecraft:magma_block
fill 129 236 479 131 242 480 minecraft:basalt
setblock 129 236 481 minecraft:magma_block
fill 129 236 482 131 242 483 minecraft:basalt
setblock 129 236 484 minecraft:magma_block
fill 129 236 485 131 242 486 minecraft:basalt
setblock 129 236 487 minecraft:magma_block
setblock 129 236 490 minecraft:magma_block
fill 129 236 491 134 238 491 minecraft:basalt
setblock 129 236 493 minecraft:magma_block
setblock 129 236 496 minecraft:magma_block
setblock 129 236 499 minecraft:magma_block
setblock 130 236 466 minecraft:basalt
fill 130 236 469 132 236 469 minecraft:basalt
fill 130 236 472 134 236 472 minecraft:basalt
fill 130 236 475 135 237 475 minecraft:basalt
fill 130 236 478 135 238 478 minecraft:basalt
fill 130 236 481 135 238 481 minecraft:basalt
fill 130 236 484 135 238 484 minecraft:basalt
fill 130 236 487 135 238 487 minecraft:basalt
fill 130 236 490 135 237 490 minecraft:basalt
fill 130 236 493 135 236 493 minecraft:basalt
fill 130 236 496 133 236 496 minecraft:basalt
fill 130 236 499 131 236 499 minecraft:basalt
setblock 132 236 468 minecraft:magma_block
setblock 132 236 471 minecraft:magma_block
setblock 132 236 474 minecraft:magma_block
fill 132 236 476 134 238 476 minecraft:basalt
setblock 132 236 477 minecraft:magma_block
fill 132 236 479 134 239 479 minecraft:basalt
setblock 132 236 480 minecraft:magma_block
fill 132 236 482 134 240 482 minecraft:basalt
setblock 132 236 483 minecraft:magma_block
fill 132 236 485 134 239 485 minecraft:basalt
setblock 132 236 486 minecraft:magma_block
fill 132 236 488 134 239 488 minecraft:basalt
setblock 132 236 489 minecraft:magma_block
setblock 132 236 492 minecraft:magma_block
setblock 132 236 495 minecraft:magma_block
setblock 132 236 498 minecraft:magma_block
fill 133 236 471 134 236 471 minecraft:basalt
fill 133 236 474 135 236 474 minecraft:basalt
fill 133 236 477 135 237 477 minecraft:basalt
fill 133 236 480 135 238 480 minecraft:basalt
fill 133 236 483 135 238 483 minecraft:basalt
fill 133 236 486 135 238 486 minecraft:basalt
fill 133 236 489 135 237 489 minecraft:basalt
fill 133 236 492 135 236 492 minecraft:basalt
fill 133 236 495 134 236 495 minecraft:basalt
setblock 135 236 473 minecraft:magma_block
setblock 135 236 476 minecraft:magma_block
setblock 135 236 479 minecraft:magma_block
setblock 135 236 482 minecraft:magma_block
setblock 135 236 485 minecraft:magma_block
setblock 135 236 488 minecraft:magma_block
setblock 135 236 491 minecraft:magma_block
fill 95 237 471 95 237 493 minecraft:basalt
setblock 95 237 494 minecraft:magma_block
fill 95 237 495 96 237 495 minecraft:basalt
fill 96 237 470 96 237 471 minecraft:basalt
fill 96 237 474 96 239 474 minecraft:basalt
fill 96 237 477 96 241 477 minecraft:basalt
fill 96 237 480 96 242 480 minecraft:basalt
fill 96 237 483 96 242 483 minecraft:basalt
fill 96 237 486 96 242 486 minecraft:basalt
fill 96 237 489 96 241 489 minecraft:basalt
fill 96 237 492 96 239 492 minecraft:basalt
fill 96 237 496 98 237 496 minecraft:basalt
fill 97 237 468 98 237 470 minecraft:basalt
fill 97 237 497 99 237 498 minecraft:basalt
fill 98 237 467 99 237 467 minecraft:basalt
setblock 98 237 499 minecraft:magma_block
fill 99 237 466 102 237 466 minecraft:basalt
fill 99 237 470 99 240 470 minecraft:basalt
fill 99 237 473 99 242 473 minecraft:basalt
fill 99 237 476 99 244 476 minecraft:basalt
fill 99 237 479 100 244 479 minecraft:basalt
fill 99 237 482 99 244 482 minecraft:basalt
fill 99 237 485 100 237 485 minecraft:basalt
fill 99 237 488 99 244 488 minecraft:basalt
fill 99 237 491 99 243 491 minecraft:basalt
fill 99 237 494 99 241 494 minecraft:basalt
fill 99 237 499 99 237 500 minecraft:basalt
fill 100 237 480 100 246 481 minecraft:basalt
fill 100 237 486 100 246 487 minecraft:basalt
fill 100 237 498 101 238 499 minecraft:basalt
setblock 101 237 465 minecraft:magma_block
setblock 101 237 477 minecraft:magma_block
setblock 101 237 489 minecraft:magma_block
setblock 101 237 501 minecraft:magma_block
fill 102 237 464 105 237 465 minecraft:basalt
fill 102 237 469 102 241 469 minecraft:basalt
fill 102 237 472 102 244 472 minecraft:basalt
fill 102 237 475 102 246 475 minecraft:basalt
fill 102 237 491 102 246 491 minecraft:basalt
fill 102 237 493 102 244 493 minecraft:basalt
fill 102 237 496 106 242 496 minecraft:basalt
fill 102 237 499 102 240 499 minecraft:basalt
fill 102 237 501 102 237 502 minecraft:basalt
fill 103 237 474 103 246 474 minecraft:basalt
fill 103 237 492 103 246 492 minecraft:basalt
fill 103 237 501 105 238 501 minecraft:basalt
setblock 104 237 473 minecraft:magma_block
fill 104 237 493 104 246 493 minecraft:basalt
setblock 104 237 503 minecraft:magma_block
fill 105 237 468 105 242 468 minecraft:basalt
fill 105 237 471 105 244 472 minecraft:basalt
fill 105 237 494 105 244 495 minecraft:basalt
fill 105 237 498 105 242 498 minecraft:basalt
fill 105 237 503 108 237 503 minecraft:basalt
fill 106 237 464 108 239 464 minecraft:basalt
fill 106 237 471 106 246 471 minecraft:basalt
fill 106 237 495 106 246 495 minecraft:basalt
setblock 107 237 496 minecraft:magma_block
fill 108 237 467 108 243 467 minecraft:basalt
fill 108 237 470 108 246 470 minecraft:basalt
fill 108 237 496 108 244 497 minecraft:basalt
fill 108 237 500 108 242 500 minecraft:basalt
fill 110 237 469 112 237 469 minecraft:basalt
fill 110 237 497 112 246 497 minecraft:basalt
fill 111 237 466 111 243 466 minecraft:basalt
fill 111 237 499 111 244 499 minecraft:basalt
fill 111 237 502 111 240 502 minecraft:basalt
fill 114 237 465 114 242 465 minecraft:basalt
fill 114 237 468 114 244 468 minecraft:basalt
fill 114 237 498 114 244 498 minecraft:basalt
fill 114 237 501 114 242 501 minecraft:basalt
fill 114 237 504 114 238 504 minecraft:basalt
setblock 116 237 469 minecraft:magma_block
fill 116 237 497 118 246 497 minecraft:basalt
fill 117 237 464 117 240 464 minecraft:basalt
fill 117 237 467 117 244 467 minecraft:basalt
fill 117 237 469 118 246 469 minecraft:basalt
fill 117 237 500 117 243 500 minecraft:basalt
fill 117 237 503 124 237 503 minecraft:basalt
fill 120 237 466 120 242 466 minecraft:basalt
fill 120 237 469 120 244 470 minecraft:basalt
fill 120 237 496 120 246 496 minecraft:basalt
fill 120 237 499 120 243 499 minecraft:basalt
fill 120 237 502 124 238 502 minecraft:basalt
fill 122 237 471 123 244 471 minecraft:basalt
fill 122 237 495 123 244 495 minecraft:basalt
fill 123 237 465 127 237 465 minecraft:basalt
fill 123 237 468 123 242 468 minecraft:basalt
fill 123 237 472 123 246 472 minecraft:basalt
fill 123 237 494 123 246 494 minecraft:basalt
fill 123 237 498 123 242 498 minecraft:basalt
fill 123 237 501 127 237 501 minecraft:basalt
fill 124 237 473 124 246 473 minecraft:basalt
fill 124 237 493 124 246 493 minecraft:basalt
fill 125 237 474 125 246 474 minecraft:basalt
fill 125 237 492 125 246 492 minecraft:basalt
setblock 125 237 502 minecraft:magma_block
setblock 126 237 464 minecraft:basalt
fill 126 237 467 130 237 467 minecraft:basalt
fill 126 237 470 132 237 470 minecraft:basalt
fill 126 237 473 126 244 473 minecraft:basalt
fill 126 237 475 126 246 475 minecraft:basalt
fill 126 237 491 126 246 491 minecraft:basalt
fill 126 237 494 133 237 494 minecraft:basalt
fill 126 237 497 130 238 497 minecraft:basalt
fill 126 237 500 129 237 500 minecraft:basalt
setblock 126 237 502 minecraft:basalt
fill 127 237 477 127 246 477 minecraft:basalt
fill 127 237 489 127 246 489 minecraft:basalt
fill 128 237 479 128 246 479 minecraft:basalt
setblock 128 237 480 minecraft:magma_block
fill 128 237 481 129 244 481 minecraft:basalt
fill 128 237 485 128 246 485 minecraft:basalt
setblock 128 237 486 minecraft:magma_block
fill 128 237 487 129 244 487 minecraft:basalt
setblock 129 237 466 minecraft:basalt
fill 129 237 469 131 237 469 minecraft:basalt
fill 129 237 472 133 237 472 minecraft:basalt
fill 129 237 475 129 243 475 minecraft:basalt
fill 129 237 478 129 244 478 minecraft:basalt
fill 129 237 484 129 244 484 minecraft:basalt
fill 129 237 490 129 244 490 minecraft:basalt
fill 129 237 493 133 238 493 minecraft:basalt
fill 129 237 496 132 237 496 minecraft:basalt
fill 129 237 499 130 237 499 minecraft:basalt
setblock 131 237 497 minecraft:magma_block
fill 132 237 471 133 237 471 minecraft:basalt
fill 132 237 474 134 237 474 minecraft:basalt
fill 132 237 477 132 241 477 minecraft:basalt
fill 132 237 480 132 242 480 minecraft:basalt
fill 132 237 483 132 242 483 minecraft:basalt
fill 132 237 486 132 242 486 minecraft:basalt
fill 132 237 489 132 241 489 minecraft:basalt
fill 132 237 492 134 237 492 minecraft:basalt
fill 132 237 495 133 237 495 minecraft:basalt
setblock 134 237 493 minecraft:magma_block
setblock 135 237 476 minecraft:basalt
fill 135 237 479 135 238 479 minecraft:basalt
fill 135 237 482 135 238 482 minecraft:basalt
fill 135 237 485 135 238 485 minecraft:basalt
fill 135 237 488 135 238 488 minecraft:basalt
setblock 135 237 491 minecraft:basalt
fill 95 238 473 95 238 493 minecraft:basalt
setblock 96 238 471 minecraft:basalt
setblock 96 238 495 minecraft:basalt
fill 97 238 470 98 238 470 minecraft:basalt
fill 97 238 496 98 238 496 minecraft:basalt
setblock 98 238 469 minecraft:basalt
fill 98 238 497 99 238 497 minecraft:basalt
fill 99 238 485 99 244 485 minecraft:basalt
setblock 99 238 498 minecraft:basalt
setblock 100 238 467 minecraft:magma_block
setblock 100 238 482 minecraft:magma_block
fill 100 238 483 100 246 484 minecraft:basalt
setblock 100 238 485 minecraft:magma_block
fill 101 238 466 102 238 467 minecraft:basalt
fill 101 238 477 101 245 479 minecraft:basalt
fill 101 238 487 101 245 489 minecraft:basalt
fill 101 238 500 107 238 500 minecraft:basalt
fill 102 238 465 105 238 465 minecraft:basalt
fill 102 238 476 102 247 476 minecraft:basalt
fill 102 238 490 102 247 490 minecraft:basalt
setblock 102 238 501 minecraft:basalt
fill 103 238 467 107 240 467 minecraft:basalt
setblock 103 238 475 minecraft:magma_block
fill 103 238 491 103 247 491 minecraft:basalt
fill 104 238 464 105 238 464 minecraft:basalt
fill 104 238 473 104 245 474 minecraft:basalt
fill 104 238 492 104 247 492 minecraft:basalt
fill 104 238 502 110 238 502 minecraft:basalt
setblock 105 238 473 minecraft:basalt
fill 105 238 493 105 247 493 minecraft:basalt
fill 106 238 472 106 247 472 minecraft:basalt
fill 106 238 494 106 247 494 minecraft:basalt
fill 106 238 503 108 238 503 minecraft:basalt
fill 107 238 471 107 247 471 minecraft:basalt
fill 107 238 495 107 245 496 minecraft:basalt
setblock 109 238 470 minecraft:magma_block
fill 109 238 496 110 247 496 minecraft:basalt
fill 109 238 504 113 238 504 minecraft:basalt
fill 110 238 469 110 246 470 minecraft:basalt
fill 111 238 469 111 246 469 minecraft:basalt
setblock 112 238 469 minecraft:magma_block
fill 113 238 469 116 245 469 minecraft:basalt
fill 113 238 497 115 245 497 minecraft:basalt
setblock 115 238 504 minecraft:magma_block
fill 116 238 504 119 238 504 minecraft:basalt
fill 117 238 503 122 238 503 minecraft:basalt
fill 118 238 464 124 238 464 minecraft:basalt
setblock 118 238 470 minecraft:magma_block
fill 118 238 496 119 247 496 minecraft:basalt
fill 119 238 470 119 247 470 minecraft:basalt
fill 121 238 466 127 238 466 minecraft:basalt
fill 121 238 471 121 247 471 minecraft:basalt
fill 121 238 495 121 247 495 minecraft:basalt
fill 122 238 472 122 247 472 minecraft:basalt
fill 122 238 494 122 247 494 minecraft:basalt
fill 123 238 465 126 238 465 minecraft:basalt
setblock 123 238 473 minecraft:basalt
fill 123 238 493 123 247 493 minecraft:basalt
fill 123 238 501 126 238 501 minecraft:basalt
fill 124 238 468 129 238 468 minecraft:basalt
setblock 124 238 474 minecraft:magma_block
setblock 124 238 492 minecraft:magma_block
fill 124 238 498 129 238 498 minecraft:basalt
fill 125 238 475 125 247 475 minecraft:basalt
fill 125 238 491 125 247 491 minecraft:basalt
fill 126 238 467 128 238 467 minecraft:basalt
fill 126 238 470 131 238 470 minecraft:basalt
fill 126 238 476 126 247 476 minecraft:basalt
fill 126 238 490 126 247 490 minecraft:basalt
fill 126 238 494 132 238 494 minecraft:basalt
fill 126 238 500 126 239 500 minecraft:basalt
fill 127 238 473 133 238 473 minecraft:basalt
fill 127 238 478 127 247 478 minecraft:basalt
setblock 127 238 479 minecraft:magma_block
fill 127 238 487 127 247 487 minecraft:basalt
setblock 127 238 488 minecraft:magma_block
setblock 127 238 500 minecraft:magma_block
fill 128 238 480 128 245 480 minecraft:basalt
fill 128 238 482 128 245 484 minecraft:basalt
fill 128 238 486 128 245 486 minecraft:basalt
fill 129 238 469 129 239 469 minecraft:basalt
fill 129 238 472 132 238 472 minecraft:basalt
fill 129 238 496 131 238 496 minecraft:basalt
setblock 130 238 469 minecraft:magma_block
fill 130 238 475 134 238 475 minecraft:basalt
fill 130 238 490 134 238 490 minecraft:basalt
setblock 132 238 471 minecraft:basalt
fill 132 238 474 132 239 474 minecraft:basalt
fill 132 238 492 132 239 492 minecraft:basalt
setblock 132 238 495 minecraft:basalt
setblock 133 238 474 minecraft:magma_block
fill 133 238 477 134 239 477 minecraft:basalt
fill 133 238 489 134 239 489 minecraft:basalt
setblock 133 238 492 minecraft:magma_block
fill 95 239 464 97 273 464 minecraft:deepslate_bricks
fill 95 239 474 95 273 474 minecraft:deepslate_bricks
fill 95 239 475 95 239 491 minecraft:basalt
fill 95 239 498 95 273 500 minecraft:deepslate_bricks
setblock 96 239 473 minecraft:magma_block
fill 96 239 493 98 239 493 minecraft:basalt
setblock 97 239 466 minecraft:light[level=11]
fill 97 239 472 98 239 473 minecraft:basalt
fill 97 239 494 98 239 494 minecraft:basalt
setblock 97 239 498 minecraft:light[level=11]
setblock 98 239 470 minecraft:basalt
setblock 98 239 496 minecraft:basalt
setblock 99 239 469 minecraft:magma_block
setblock 99 239 497 minecraft:basalt
fill 100 239 468 101 239 469 minecraft:basalt
fill 100 239 482 101 239 482 minecraft:basalt
fill 100 239 485 101 239 485 minecraft:basalt
fill 100 239 498 101 239 498 minecraft:basalt
fill 101 239 467 102 239 467 minecraft:basalt
fill 101 239 480 101 247 481 minecraft:basalt
fill 101 239 483 101 248 484 minecraft:basalt
fill 101 239 486 101 247 486 minecraft:basalt
setblock 101 239 499 minecraft:basalt
fill 101 239 504 103 273 504 minecraft:deepslate_bricks
setblock 102 239 466 minecraft:basalt
setblock 102 239 477 minecraft:magma_block
fill 102 239 478 102 248 478 minecraft:basalt
fill 102 239 488 102 248 488 minecraft:basalt
setblock 102 239 489 minecraft:magma_block
fill 102 239 500 107 239 500 minecraft:basalt
fill 103 239 475 103 246 476 minecraft:basalt
fill 103 239 490 103 248 490 minecraft:basalt
fill 104 239 465 105 239 465 minecraft:basalt
fill 104 239 501 105 239 501 minecraft:basalt
setblock 105 239 473 minecraft:magma_block
setblock 105 239 474 minecraft:light[level=11]
setblock 105 239 482 minecraft:light[level=11]
setblock 105 239 490 minecraft:light[level=11]
fill 106 239 502 110 239 502 minecraft:basalt
fill 107 239 472 107 248 472 minecraft:basalt
fill 107 239 494 107 248 494 minecraft:basalt
fill 108 239 471 109 247 471 minecraft:basalt
fill 108 239 495 109 247 495 minecraft:basalt
fill 108 239 503 113 239 503 minecraft:basalt
fill 109 239 470 109 246 470 minecraft:basalt
fill 111 239 470 113 247 470 minecraft:basalt
fill 111 239 496 116 239 496 minecraft:basalt
fill 112 239 469 112 246 469 minecraft:basalt
setblock 113 239 474 minecraft:light[level=11]
setblock 113 239 482 minecraft:light[level=11]
setblock 113 239 490 minecraft:light[level=11]
fill 113 239 504 115 273 504 minecraft:deepslate_bricks
setblock 114 239 470 minecraft:magma_block
setblock 114 239 503 minecraft:magma_block
fill 115 239 470 118 246 470 minecraft:basalt
fill 115 239 503 120 239 503 minecraft:basalt
setblock 117 239 496 minecraft:magma_block
fill 118 239 464 122 239 464 minecraft:basalt
fill 119 239 471 119 248 471 minecraft:basalt
fill 119 239 495 119 248 495 minecraft:basalt
setblock 120 239 471 minecraft:magma_block
setblock 120 239 495 minecraft:magma_block
fill 120 239 502 122 239 502 minecraft:basalt
fill 121 239 466 125 239 466 minecraft:basalt
fill 121 239 472 121 248 472 minecraft:basalt
setblock 121 239 474 minecraft:light[level=11]
setblock 121 239 482 minecraft:light[level=11]
setblock 121 239 490 minecraft:light[level=11]
fill 121 239 494 121 248 494 minecraft:basalt
fill 121 239 499 127 239 499 minecraft:basalt
fill 123 239 465 124 239 465 minecraft:basalt
setblock 123 239 473 minecraft:magma_block
fill 123 239 501 124 239 501 minecraft:basalt
fill 124 239 468 128 239 468 minecraft:basalt
fill 124 239 474 124 246 474 minecraft:basalt
fill 124 239 492 124 246 492 minecraft:basalt
fill 124 239 498 128 239 498 minecraft:basalt
fill 125 239 476 125 248 476 minecraft:basalt
fill 125 239 490 125 248 490 minecraft:basalt
fill 125 239 504 127 273 504 minecraft:deepslate_bricks
setblock 126 239 466 minecraft:magma_block
fill 126 239 467 127 239 467 minecraft:basalt
fill 126 239 470 130 239 470 minecraft:basalt
fill 126 239 477 126 247 477 minecraft:basalt
setblock 126 239 478 minecraft:magma_block
fill 126 239 488 126 247 489 minecraft:basalt
fill 126 239 494 131 239 494 minecraft:basalt
fill 126 239 497 129 239 497 minecraft:basalt
fill 127 239 473 131 240 473 minecraft:basalt
fill 127 239 479 127 246 486 minecraft:basalt
fill 127 239 488 127 246 488 minecraft:basalt
setblock 129 239 466 minecraft:light[level=11]
fill 129 239 472 131 239 472 minecraft:basalt
fill 129 239 491 133 239 491 minecraft:basalt
fill 129 239 493 132 239 493 minecraft:basalt
fill 129 239 496 130 239 496 minecraft:basalt
setblock 129 239 498 minecraft:light[level=11]
fill 130 239 475 133 239 475 minecraft:basalt
fill 130 239 478 134 239 478 minecraft:basalt
fill 130 239 481 134 239 481 minecraft:basalt
fill 130 239 484 134 240 484 minecraft:basalt
fill 130 239 487 134 239 487 minecraft:basalt
fill 130 239 490 133 239 490 minecraft:basalt
fill 131 239 464 133 273 464 minecraft:deepslate_bricks
setblock 132 239 473 minecraft:magma_block
fill 132 239 476 133 239 476 minecraft:basalt
fill 133 239 480 134 239 480 minecraft:basalt
fill 133 239 483 134 239 483 minecraft:basalt
fill 133 239 486 134 239 486 minecraft:basalt
fill 135 239 472 135 273 474 minecraft:deepslate_bricks
fill 135 239 484 135 273 486 minecraft:deepslate_bricks
fill 135 239 496 135 273 498 minecraft:deepslate_bricks
fill 95 240 475 95 273 476 minecraft:deepslate_bricks
setblock 95 240 477 minecraft:basalt
setblock 95 240 478 minecraft:magma_block
fill 95 240 479 95 240 480 minecraft:basalt
setblock 95 240 481 minecraft:magma_block
fill 95 240 482 95 240 486 minecraft:basalt
setblock 95 240 487 minecraft:magma_block
fill 95 240 488 95 240 489 minecraft:basalt
fill 96 240 473 96 245 474 minecraft:deepslate_bricks
fill 96 240 497 96 245 499 minecraft:deepslate_bricks
fill 97 240 473 98 240 473 minecraft:basalt
fill 97 240 493 98 240 493 minecraft:basalt
setblock 98 240 471 minecraft:magma_block
setblock 98 240 472 minecraft:basalt
setblock 98 240 494 minecraft:basalt
setblock 98 240 495 minecraft:magma_block
fill 99 240 471 104 240 471 minecraft:basalt
fill 99 240 495 104 240 495 minecraft:basalt
fill 100 240 469 101 240 469 minecraft:basalt
fill 100 240 482 100 246 482 minecraft:basalt
fill 100 240 485 100 246 485 minecraft:basalt
setblock 101 240 468 minecraft:basalt
setblock 101 240 482 minecraft:magma_block
setblock 101 240 485 minecraft:magma_block
setblock 101 240 498 minecraft:basalt
setblock 102 240 467 minecraft:basalt
fill 102 240 477 103 247 477 minecraft:basalt
fill 102 240 479 102 247 480 minecraft:basalt
fill 102 240 486 102 247 487 minecraft:basalt
fill 102 240 489 103 247 489 minecraft:basalt
fill 102 240 503 104 245 503 minecraft:deepslate_bricks
setblock 104 240 466 minecraft:magma_block
setblock 104 240 475 minecraft:magma_block
fill 104 240 476 104 248 476 minecraft:basalt
setblock 104 240 490 minecraft:magma_block
fill 104 240 491 104 248 491 minecraft:basalt
fill 104 240 500 107 240 500 minecraft:basalt
fill 105 240 466 110 240 466 minecraft:basalt
fill 105 240 473 105 247 474 minecraft:basalt
fill 105 240 492 105 248 492 minecraft:basalt
setblock 106 240 465 minecraft:basalt
fill 106 240 473 107 248 473 minecraft:basalt
fill 106 240 493 107 248 493 minecraft:basalt
setblock 106 240 501 minecraft:basalt
fill 107 240 464 107 273 464 minecraft:deepslate_bricks
setblock 107 240 465 minecraft:magma_block
setblock 107 240 501 minecraft:magma_block
fill 108 240 464 109 240 465 minecraft:basalt
fill 108 240 472 108 247 472 minecraft:basalt
fill 108 240 494 108 248 494 minecraft:basalt
fill 108 240 501 110 240 502 minecraft:basalt
setblock 110 240 464 minecraft:magma_block
fill 110 240 465 113 241 465 minecraft:basalt
fill 110 240 471 111 247 471 minecraft:basalt
fill 110 240 495 111 247 495 minecraft:basalt
fill 111 240 464 116 240 464 minecraft:basalt
fill 111 240 496 112 246 496 minecraft:basalt
fill 111 240 501 113 242 501 minecraft:basalt
setblock 113 240 496 minecraft:magma_block
fill 113 240 503 115 240 503 minecraft:basalt
fill 114 240 470 114 247 470 minecraft:basalt
fill 114 240 496 117 247 496 minecraft:basalt
fill 116 240 503 116 245 503 minecraft:deepslate_bricks
fill 117 240 471 118 248 471 minecraft:basalt
fill 117 240 495 118 248 495 minecraft:basalt
setblock 118 240 464 minecraft:basalt
fill 118 240 500 124 240 500 minecraft:basalt
setblock 119 240 464 minecraft:magma_block
setblock 120 240 464 minecraft:basalt
fill 120 240 471 120 247 472 minecraft:basalt
fill 120 240 494 120 247 495 minecraft:basalt
setblock 120 240 502 minecraft:basalt
fill 121 240 464 121 273 464 minecraft:deepslate_bricks
fill 121 240 466 124 240 466 minecraft:basalt
fill 121 240 473 123 247 473 minecraft:basalt
fill 121 240 493 121 248 493 minecraft:basalt
fill 121 240 499 126 240 499 minecraft:basalt
setblock 122 240 493 minecraft:magma_block
fill 123 240 474 123 248 474 minecraft:basalt
fill 123 240 492 123 248 492 minecraft:basalt
fill 124 240 468 127 240 468 minecraft:basalt
fill 124 240 475 124 240 476 minecraft:basalt
fill 124 240 490 124 248 491 minecraft:basalt
fill 124 240 498 127 240 498 minecraft:basalt
setblock 125 240 477 minecraft:magma_block
setblock 125 240 489 minecraft:magma_block
setblock 126 240 467 minecraft:basalt
fill 126 240 470 129 240 470 minecraft:basalt
fill 126 240 478 126 247 480 minecraft:basalt
fill 126 240 486 126 247 487 minecraft:basalt
fill 126 240 494 130 240 495 minecraft:basalt
fill 126 240 497 127 241 497 minecraft:basalt
fill 126 240 503 128 245 503 minecraft:deepslate_bricks
setblock 128 240 497 minecraft:magma_block
fill 129 240 471 130 240 472 minecraft:basalt
fill 129 240 491 132 240 491 minecraft:basalt
fill 129 240 493 130 241 493 minecraft:basalt
setblock 129 240 496 minecraft:basalt
fill 130 240 465 132 245 465 minecraft:deepslate_bricks
fill 130 240 475 132 240 475 minecraft:basalt
fill 130 240 478 133 240 478 minecraft:basalt
fill 130 240 481 133 241 481 minecraft:basalt
fill 130 240 487 133 240 487 minecraft:basalt
fill 130 240 490 132 240 490 minecraft:basalt
setblock 131 240 493 minecraft:magma_block
setblock 132 240 476 minecraft:basalt
fill 132 240 479 133 240 479 minecraft:basalt
fill 132 240 485 133 240 485 minecraft:basalt
fill 132 240 488 133 240 488 minecraft:basalt
setblock 133 240 477 minecraft:basalt
setblock 133 240 480 minecraft:basalt
fill 133 240 483 133 241 483 minecraft:basalt
setblock 133 240 486 minecraft:basalt
setblock 133 240 489 minecraft:basalt
fill 134 240 473 134 245 475 minecraft:deepslate_bricks
fill 134 240 481 134 243 481 minecraft:cyan_stained_glass
setblock 134 240 483 minecraft:magma_block
fill 134 240 485 134 245 487 minecraft:deepslate_bricks
fill 134 240 497 134 245 499 minecraft:deepslate_bricks
fill 95 241 481 95 241 485 minecraft:basalt
fill 95 241 486 95 273 488 minecraft:deepslate_bricks
fill 96 241 475 96 245 475 minecraft:deepslate_bricks
fill 97 241 475 98 241 475 minecraft:basalt
setblock 97 241 476 minecraft:magma_block
fill 97 241 490 98 241 490 minecraft:basalt
setblock 97 241 491 minecraft:magma_block
fill 98 241 473 98 241 474 minecraft:basalt
fill 98 241 476 98 242 476 minecraft:basalt
fill 98 241 491 98 241 493 minecraft:basalt
fill 99 241 474 102 241 474 minecraft:basalt
fill 99 241 492 102 241 492 minecraft:basalt
fill 100 241 471 104 241 471 minecraft:basalt
fill 100 241 495 104 241 495 minecraft:basalt
setblock 100 241 496 minecraft:magma_block
setblock 101 241 469 minecraft:basalt
fill 101 241 482 102 248 482 minecraft:basalt
fill 101 241 485 102 247 485 minecraft:basalt
fill 101 241 496 101 241 497 minecraft:basalt
fill 102 241 481 102 249 481 minecraft:basalt
fill 102 241 483 102 249 484 minecraft:basalt
fill 102 241 497 107 241 497 minecraft:basalt
setblock 103 241 468 minecraft:magma_block
fill 103 241 478 103 249 479 minecraft:basalt
fill 103 241 487 103 249 488 minecraft:basalt
setblock 103 241 498 minecraft:magma_block
fill 104 241 467 104 241 468 minecraft:basalt
fill 104 241 475 105 248 475 minecraft:basalt
fill 104 241 477 104 249 477 minecraft:basalt
fill 104 241 489 104 248 490 minecraft:basalt
fill 104 241 498 104 241 499 minecraft:basalt
fill 105 241 467 107 241 467 minecraft:basalt
fill 105 241 491 105 249 491 minecraft:basalt
fill 105 241 499 110 241 499 minecraft:basalt
fill 106 241 465 107 245 465 minecraft:deepslate_bricks
fill 106 241 466 110 241 466 minecraft:basalt
fill 106 241 474 106 249 474 minecraft:basalt
fill 106 241 492 106 249 492 minecraft:basalt
setblock 106 241 500 minecraft:magma_block
setblock 107 241 500 minecraft:basalt
fill 108 241 464 109 273 464 minecraft:deepslate_bricks
fill 108 241 465 109 241 465 minecraft:basalt
fill 108 241 473 108 249 473 minecraft:basalt
fill 108 241 493 108 249 493 minecraft:basalt
fill 108 241 501 110 241 501 minecraft:basalt
setblock 109 241 472 minecraft:magma_block
fill 109 241 494 110 248 494 minecraft:basalt
fill 110 241 472 110 249 472 minecraft:basalt
fill 112 241 464 114 241 464 minecraft:basalt
setblock 112 241 471 minecraft:magma_block
setblock 112 241 495 minecraft:magma_block
fill 112 241 502 116 241 502 minecraft:basalt
fill 113 241 471 116 248 471 minecraft:basalt
fill 113 241 495 113 248 496 minecraft:basalt
fill 114 241 495 116 248 495 minecraft:basalt
fill 114 241 503 115 245 503 minecraft:deepslate_bricks
setblock 115 241 464 minecraft:magma_block
fill 115 241 465 120 241 465 minecraft:basalt
fill 115 241 501 120 241 501 minecraft:basalt
setblock 116 241 464 minecraft:basalt
fill 118 241 467 123 241 467 minecraft:basalt
setblock 118 241 472 minecraft:magma_block
fill 118 241 494 119 248 494 minecraft:basalt
fill 118 241 500 122 241 500 minecraft:basalt
fill 119 241 464 120 273 464 minecraft:deepslate_bricks
fill 119 241 472 119 249 472 minecraft:basalt
setblock 120 241 473 minecraft:basalt
fill 120 241 493 120 249 493 minecraft:basalt
fill 121 241 466 122 241 466 minecraft:basalt
fill 121 241 496 126 242 496 minecraft:basalt
fill 121 241 499 124 241 499 minecraft:basalt
fill 122 241 474 122 249 474 minecraft:basalt
fill 122 241 492 122 248 493 minecraft:basalt
fill 123 241 475 124 248 475 minecraft:basalt
fill 123 241 491 123 249 491 minecraft:basalt
setblock 124 241 467 minecraft:magma_block
fill 124 241 468 125 241 468 minecraft:basalt
setblock 124 241 476 minecraft:magma_block
fill 124 241 477 125 248 477 minecraft:basalt
fill 124 241 489 125 248 489 minecraft:basalt
fill 124 241 498 125 241 498 minecraft:basalt
fill 125 241 478 125 249 479 minecraft:basalt
fill 125 241 487 125 249 488 minecraft:basalt
fill 126 241 469 126 241 470 minecraft:basalt
fill 126 241 474 129 242 474 minecraft:basalt
fill 126 241 481 126 247 485 minecraft:basalt
fill 126 241 492 129 242 492 minecraft:basalt
fill 126 241 494 128 241 495 minecraft:basalt
setblock 127 241 469 minecraft:magma_block
fill 127 241 470 128 241 470 minecraft:basalt
fill 127 241 473 130 241 473 minecraft:basalt
setblock 127 241 496 minecraft:magma_block
setblock 128 241 496 minecraft:basalt
setblock 129 241 472 minecraft:basalt
fill 129 241 491 131 241 491 minecraft:basalt
setblock 129 241 494 minecraft:basalt
setblock 130 241 474 minecraft:magma_block
fill 130 241 475 131 241 475 minecraft:basalt
fill 130 241 478 132 241 478 minecraft:basalt
fill 130 241 484 133 241 484 minecraft:basalt
fill 130 241 487 132 241 487 minecraft:basalt
fill 130 241 490 131 241 490 minecraft:basalt
setblock 130 241 492 minecraft:magma_block
setblock 132 241 479 minecraft:basalt
fill 132 241 482 132 242 482 minecraft:basalt
fill 132 241 485 132 242 485 minecraft:basalt
setblock 132 241 488 minecraft:basalt
fill 133 241 480 135 242 480 minecraft:cyan_stained_glass
setblock 133 241 482 minecraft:magma_block
setblock 133 241 485 minecraft:magma_block
fill 134 241 482 135 242 482 minecraft:cyan_stained_glass
fill 135 241 481 135 242 481 minecraft:cyan_stained_glass
setblock 96 242 481 minecraft:magma_block
fill 96 242 482 98 242 482 minecraft:basalt
setblock 96 242 484 minecraft:magma_block
fill 96 242 485 98 242 485 minecraft:basalt
fill 96 242 487 96 245 487 minecraft:deepslate_bricks
fill 97 242 478 98 242 479 minecraft:basalt
fill 97 242 481 98 243 481 minecraft:basalt
fill 97 242 484 98 243 484 minecraft:basalt
fill 97 242 487 98 242 488 minecraft:basalt
setblock 98 242 475 minecraft:basalt
fill 98 242 490 98 242 491 minecraft:basalt
setblock 99 242 474 minecraft:magma_block
setblock 99 242 492 minecraft:magma_block
fill 100 242 472 101 242 472 minecraft:basalt
fill 100 242 474 102 243 474 minecraft:basalt
fill 100 242 492 102 243 492 minecraft:basalt
fill 101 242 471 104 242 471 minecraft:basalt
fill 101 242 495 104 242 495 minecraft:basalt
setblock 102 242 470 minecraft:magma_block
fill 103 242 470 107 243 470 minecraft:basalt
fill 103 242 480 103 249 486 minecraft:basalt
fill 103 242 497 107 242 497 minecraft:basalt
setblock 104 242 468 minecraft:basalt
fill 104 242 478 104 250 478 minecraft:basalt
fill 104 242 488 104 250 488 minecraft:basalt
setblock 104 242 498 minecraft:basalt
fill 105 242 476 105 249 476 minecraft:basalt
setblock 105 242 490 minecraft:magma_block
fill 106 242 467 107 242 467 minecraft:basalt
fill 106 242 475 106 249 475 minecraft:basalt
fill 106 242 491 106 249 491 minecraft:basalt
fill 106 242 499 110 242 499 minecraft:basalt
fill 107 242 474 107 248 474 minecraft:basalt
fill 107 242 492 107 248 492 minecraft:basalt
fill 108 242 465 108 245 465 minecraft:deepslate_bricks
fill 108 242 466 110 242 466 minecraft:basalt
fill 109 242 472 109 249 473 minecraft:basalt
fill 109 242 493 109 249 493 minecraft:basalt
fill 111 242 465 113 242 465 minecraft:basalt
fill 111 242 472 113 249 472 minecraft:basalt
setblock 111 242 494 minecraft:magma_block
fill 112 242 471 112 249 471 minecraft:basalt
fill 112 242 494 112 249 495 minecraft:basalt
fill 113 242 494 117 242 494 minecraft:basalt
setblock 114 242 472 minecraft:magma_block
fill 115 242 465 116 242 465 minecraft:basalt
fill 115 242 472 118 249 472 minecraft:basalt
fill 115 242 501 116 242 501 minecraft:basalt
setblock 117 242 465 minecraft:magma_block
setblock 117 242 501 minecraft:magma_block
fill 118 242 465 120 245 465 minecraft:deepslate_bricks
fill 118 242 467 122 242 467 minecraft:basalt
fill 118 242 500 119 242 500 minecraft:basalt
fill 119 242 473 119 250 473 minecraft:basalt
setblock 119 242 493 minecraft:basalt
setblock 120 242 473 minecraft:magma_block
setblock 120 242 500 minecraft:magma_block
fill 121 242 474 121 249 474 minecraft:basalt
fill 121 242 492 121 249 492 minecraft:basalt
fill 121 242 499 122 242 499 minecraft:basalt
fill 122 242 475 122 248 475 minecraft:basalt
fill 122 242 491 122 249 491 minecraft:basalt
fill 123 242 476 124 248 476 minecraft:basalt
setblock 123 242 490 minecraft:magma_block
setblock 124 242 468 minecraft:basalt
fill 124 242 471 127 242 472 minecraft:basalt
fill 124 242 478 124 250 478 minecraft:basalt
fill 124 242 488 124 249 488 minecraft:basalt
setblock 124 242 498 minecraft:basalt
fill 125 242 480 125 242 486 minecraft:basalt
setblock 126 242 470 minecraft:basalt
fill 126 242 494 127 242 495 minecraft:basalt
fill 127 242 473 128 243 473 minecraft:basalt
setblock 128 242 472 minecraft:basalt
setblock 128 242 494 minecraft:basalt
setblock 129 242 473 minecraft:magma_block
fill 129 242 476 130 242 477 minecraft:basalt
fill 129 242 491 130 242 491 minecraft:basalt
setblock 129 242 493 minecraft:basalt
setblock 130 242 475 minecraft:basalt
fill 130 242 478 131 242 478 minecraft:basalt
fill 130 242 481 131 243 481 minecraft:basalt
fill 130 242 484 131 243 484 minecraft:basalt
fill 130 242 487 131 242 487 minecraft:basalt
setblock 130 242 490 minecraft:basalt
setblock 131 242 477 minecraft:basalt
setblock 132 242 481 minecraft:magma_block
setblock 132 242 484 minecraft:magma_block
fill 133 242 481 133 242 482 minecraft:cyan_stained_glass
fill 96 243 485 96 245 486 minecraft:deepslate_bricks
fill 97 243 482 98 243 482 minecraft:basalt
fill 97 243 485 98 243 485 minecraft:basalt
fill 98 243 476 98 244 476 minecraft:reinforced_deepslate
fill 98 243 477 98 243 478 minecraft:basalt
setblock 98 243 479 minecraft:magma_block
fill 98 243 487 98 244 487 minecraft:basalt
setblock 98 243 488 minecraft:magma_block
fill 98 243 489 100 243 489 minecraft:basalt
fill 99 243 477 100 244 477 minecraft:basalt
fill 100 243 493 101 243 493 minecraft:basalt
setblock 101 243 472 minecraft:magma_block
fill 101 243 494 104 243 494 minecraft:basalt
fill 102 243 471 104 243 471 minecraft:basalt
fill 102 243 495 104 243 495 minecraft:basalt
fill 103 243 496 106 243 496 minecraft:basalt
fill 104 243 469 109 243 469 minecraft:basalt
fill 104 243 479 104 250 479 minecraft:basalt
setblock 104 243 480 minecraft:magma_block
setblock 104 243 486 minecraft:magma_block
fill 104 243 487 104 250 487 minecraft:basalt
fill 104 243 497 107 243 497 minecraft:basalt
fill 105 243 477 105 250 477 minecraft:basalt
fill 105 243 489 105 249 490 minecraft:basalt
fill 106 243 476 106 249 476 minecraft:basalt
fill 106 243 490 106 250 490 minecraft:basalt
fill 107 243 475 107 250 475 minecraft:basalt
setblock 107 243 491 minecraft:magma_block
fill 108 243 474 108 250 474 minecraft:basalt
fill 108 243 492 108 250 492 minecraft:basalt
fill 108 243 499 109 243 499 minecraft:basalt
fill 110 243 473 111 250 473 minecraft:basalt
setblock 110 243 493 minecraft:magma_block
setblock 110 243 499 minecraft:magma_block
fill 111 243 493 111 249 494 minecraft:basalt
fill 111 243 500 115 243 500 minecraft:basalt
fill 112 243 466 117 243 466 minecraft:basalt
fill 112 243 499 118 243 499 minecraft:basalt
fill 113 243 494 115 249 494 minecraft:basalt
fill 114 243 472 114 250 472 minecraft:basalt
fill 115 243 468 121 244 468 minecraft:basalt
fill 115 243 498 121 244 498 minecraft:basalt
setblock 116 243 494 minecraft:magma_block
setblock 116 243 500 minecraft:magma_block
fill 117 243 473 118 250 473 minecraft:basalt
fill 117 243 493 117 249 494 minecraft:basalt
fill 118 243 467 120 243 467 minecraft:basalt
fill 118 243 493 118 249 493 minecraft:basalt
setblock 119 243 493 minecraft:magma_block
fill 119 243 497 124 243 497 minecraft:basalt
setblock 119 243 499 minecraft:magma_block
fill 120 243 473 120 249 474 minecraft:basalt
fill 120 243 492 120 250 492 minecraft:basalt
fill 121 243 469 124 243 470 minecraft:basalt
fill 121 243 475 121 250 475 minecraft:basalt
fill 121 243 491 121 250 491 minecraft:basalt
fill 121 243 496 125 243 496 minecraft:basalt
setblock 122 243 468 minecraft:magma_block
fill 122 243 476 122 250 476 minecraft:basalt
fill 122 243 490 123 249 490 minecraft:basalt
setblock 122 243 498 minecraft:magma_block
fill 123 243 477 123 250 477 minecraft:basalt
fill 123 243 489 123 250 489 minecraft:basalt
fill 124 243 471 126 243 472 minecraft:basalt
fill 124 243 479 124 249 480 minecraft:basalt
fill 124 243 486 124 250 487 minecraft:basalt
setblock 125 243 470 minecraft:magma_block
fill 125 243 480 125 248 481 minecraft:basalt
setblock 125 243 482 minecraft:magma_block
fill 125 243 483 125 250 484 minecraft:basalt
setblock 125 243 485 minecraft:magma_block
fill 125 243 486 125 248 486 minecraft:basalt
fill 125 243 493 127 244 493 minecraft:basalt
fill 126 243 474 128 243 474 minecraft:basalt
fill 126 243 492 128 243 492 minecraft:basalt
fill 126 243 494 126 243 495 minecraft:basalt
setblock 127 243 472 minecraft:basalt
setblock 127 243 494 minecraft:basalt
fill 128 243 488 130 243 489 minecraft:basalt
setblock 128 243 493 minecraft:magma_block
fill 129 243 476 129 244 477 minecraft:basalt
fill 129 243 479 130 243 480 minecraft:basalt
fill 129 243 482 130 243 483 minecraft:basalt
fill 129 243 485 130 243 486 minecraft:basalt
setblock 129 243 491 minecraft:basalt
fill 130 243 477 130 243 478 minecraft:basalt
fill 130 243 487 130 244 487 minecraft:basalt
setblock 131 243 480 minecraft:magma_block
setblock 131 243 482 minecraft:basalt
setblock 131 243 483 minecraft:magma_block
setblock 131 243 485 minecraft:basalt
setblock 131 243 486 minecraft:magma_block
fill 98 244 479 98 244 486 minecraft:basalt
fill 99 244 480 99 245 480 minecraft:basalt
fill 99 244 483 99 245 483 minecraft:basalt
fill 99 244 486 99 245 486 minecraft:basalt
fill 99 244 489 100 244 489 minecraft:basalt
fill 100 244 475 101 244 475 minecraft:basalt
fill 101 244 473 102 244 474 minecraft:basalt
fill 101 244 492 101 244 493 minecraft:basalt
fill 102 244 492 102 245 492 minecraft:basalt
fill 102 244 494 104 244 494 minecraft:basalt
fill 103 244 471 104 244 471 minecraft:basalt
fill 103 244 473 103 245 473 minecraft:basalt
fill 103 244 495 104 244 495 minecraft:basalt
fill 104 244 470 107 244 470 minecraft:basalt
fill 104 244 480 104 250 486 minecraft:basalt
fill 104 244 496 106 244 496 minecraft:basalt
fill 105 244 478 105 250 479 minecraft:basalt
fill 105 244 487 105 250 488 minecraft:basalt
setblock 106 244 469 minecraft:magma_block
fill 106 244 477 106 251 477 minecraft:basalt
fill 106 244 489 106 251 489 minecraft:basalt
fill 106 244 497 107 244 497 minecraft:basalt
fill 107 244 468 108 244 469 minecraft:basalt
fill 107 244 476 107 251 476 minecraft:basalt
fill 107 244 490 107 250 491 minecraft:basalt
fill 107 244 498 108 244 498 minecraft:basalt
fill 108 244 475 108 251 475 minecraft:basalt
fill 108 244 491 108 251 491 minecraft:basalt
setblock 109 244 468 minecraft:magma_block
fill 109 244 469 109 245 469 minecraft:basalt
setblock 109 244 474 minecraft:magma_block
setblock 109 244 492 minecraft:magma_block
setblock 109 244 498 minecraft:magma_block
fill 110 244 467 111 244 468 minecraft:basalt
fill 110 244 474 110 251 474 minecraft:basalt
fill 110 244 492 110 250 493 minecraft:basalt
fill 110 244 498 110 244 499 minecraft:basalt
fill 111 244 498 113 245 498 minecraft:basalt
setblock 112 244 467 minecraft:magma_block
fill 112 244 468 113 245 468 minecraft:basalt
setblock 112 244 473 minecraft:magma_block
fill 112 244 493 114 250 493 minecraft:basalt
fill 112 244 499 114 244 499 minecraft:basalt
fill 113 244 467 116 244 467 minecraft:basalt
fill 113 244 473 116 251 473 minecraft:basalt
setblock 115 244 493 minecraft:magma_block
setblock 115 244 499 minecraft:magma_block
fill 116 244 493 116 250 494 minecraft:basalt
fill 116 244 499 118 244 499 minecraft:basalt
setblock 118 244 467 minecraft:basalt
setblock 118 244 474 minecraft:magma_block
setblock 118 244 492 minecraft:magma_block
fill 119 244 474 119 251 474 minecraft:basalt
fill 119 244 492 119 250 493 minecraft:basalt
fill 119 244 497 122 244 497 minecraft:basalt
fill 120 244 475 120 251 475 minecraft:basalt
fill 120 244 491 120 250 491 minecraft:basalt
fill 121 244 469 122 244 470 minecraft:basalt
setblock 121 244 476 minecraft:magma_block
fill 121 244 490 121 251 490 minecraft:basalt
fill 121 244 496 123 244 496 minecraft:basalt
fill 122 244 477 122 251 477 minecraft:basalt
fill 122 244 489 122 251 489 minecraft:basalt
fill 123 244 470 124 244 470 minecraft:basalt
fill 123 244 478 123 250 479 minecraft:basalt
fill 123 244 487 123 250 488 minecraft:basalt
fill 124 244 471 125 244 472 minecraft:basalt
setblock 124 244 481 minecraft:magma_block
fill 124 244 482 124 251 483 minecraft:basalt
setblock 124 244 484 minecraft:magma_block
fill 124 244 485 125 250 485 minecraft:basalt
setblock 124 244 496 minecraft:magma_block
fill 125 244 482 125 250 482 minecraft:basalt
setblock 126 244 472 minecraft:basalt
fill 126 244 474 126 245 474 minecraft:basalt
fill 126 244 492 126 245 492 minecraft:basalt
setblock 126 244 494 minecraft:basalt
setblock 127 244 473 minecraft:basalt
setblock 127 244 474 minecraft:magma_block
setblock 127 244 492 minecraft:magma_block
fill 128 244 488 129 244 489 minecraft:basalt
fill 129 244 479 129 245 480 minecraft:basalt
fill 129 244 482 129 245 483 minecraft:basalt
fill 129 244 485 129 245 486 minecraft:basalt
setblock 130 244 479 minecraft:magma_block
fill 130 244 480 130 244 481 minecraft:basalt
setblock 130 244 482 minecraft:magma_block
fill 130 244 483 130 244 484 minecraft:basalt
setblock 130 244 485 minecraft:magma_block
setblock 130 244 486 minecraft:basalt
fill 95 245 467 95 245 472 minecraft:sculk
fill 95 245 479 95 245 484 minecraft:sculk
fill 95 245 491 95 245 496 minecraft:sculk
fill 95 245 503 95 245 504 minecraft:sculk
fill 96 245 504 99 245 504 minecraft:sculk
fill 99 245 464 104 245 464 minecraft:sculk
setblock 99 245 479 minecraft:magma_block
setblock 99 245 482 minecraft:magma_block
setblock 99 245 485 minecraft:magma_block
fill 100 245 477 100 245 479 minecraft:basalt
fill 100 245 489 100 245 490 minecraft:basalt
setblock 101 245 475 minecraft:basalt
fill 101 245 490 101 245 491 minecraft:basalt
fill 102 245 473 102 245 474 minecraft:basalt
setblock 102 245 493 minecraft:magma_block
fill 103 245 494 105 245 494 minecraft:basalt
setblock 104 245 471 minecraft:basalt
setblock 104 245 495 minecraft:basalt
setblock 105 245 471 minecraft:magma_block
fill 105 245 472 105 246 472 minecraft:basalt
setblock 105 245 480 minecraft:magma_block
fill 105 245 481 105 250 481 minecraft:basalt
fill 105 245 485 105 251 485 minecraft:basalt
setblock 105 245 486 minecraft:magma_block
setblock 105 245 495 minecraft:magma_block
fill 106 245 470 107 245 470 minecraft:basalt
fill 106 245 478 106 251 478 minecraft:basalt
fill 106 245 488 106 251 488 minecraft:basalt
setblock 106 245 496 minecraft:basalt
fill 106 245 504 111 245 504 minecraft:sculk
fill 107 245 469 108 245 469 minecraft:basalt
fill 107 245 477 107 251 477 minecraft:basalt
fill 107 245 489 107 251 489 minecraft:basalt
setblock 107 245 497 minecraft:basalt
setblock 108 245 476 minecraft:magma_block
fill 108 245 490 108 251 490 minecraft:basalt
fill 108 245 496 108 246 496 minecraft:basalt
setblock 108 245 497 minecraft:magma_block
fill 109 245 474 109 251 475 minecraft:basalt
fill 109 245 491 109 251 492 minecraft:basalt
fill 110 245 468 111 245 468 minecraft:basalt
setblock 110 245 498 minecraft:basalt
fill 111 245 464 116 245 464 minecraft:sculk
fill 111 245 474 112 251 474 minecraft:basalt
fill 111 245 492 112 251 492 minecraft:basalt
fill 112 245 473 112 251 473 minecraft:basalt
setblock 114 245 468 minecraft:magma_block
setblock 114 245 498 minecraft:magma_block
fill 115 245 468 118 245 468 minecraft:basalt
fill 115 245 493 115 251 493 minecraft:basalt
fill 115 245 498 118 245 498 minecraft:basalt
fill 116 245 474 118 250 474 minecraft:basalt
fill 116 245 492 118 250 492 minecraft:basalt
fill 118 245 504 123 245 504 minecraft:sculk
fill 119 245 475 119 251 475 minecraft:basalt
fill 119 245 491 119 251 491 minecraft:basalt
fill 119 245 497 121 245 497 minecraft:basalt
setblock 120 245 469 minecraft:magma_block
fill 120 245 470 122 245 470 minecraft:basalt
fill 120 245 476 121 250 476 minecraft:basalt
setblock 120 245 490 minecraft:magma_block
setblock 121 245 469 minecraft:basalt
fill 121 245 477 121 251 477 minecraft:basalt
fill 121 245 489 121 251 489 minecraft:basalt
fill 121 245 496 122 245 496 minecraft:basalt
fill 122 245 471 122 246 471 minecraft:basalt
fill 122 245 478 122 251 478 minecraft:basalt
fill 122 245 488 122 251 488 minecraft:basalt
fill 122 245 495 122 246 495 minecraft:basalt
fill 123 245 464 128 245 464 minecraft:sculk
setblock 123 245 471 minecraft:magma_block
setblock 123 245 480 minecraft:magma_block
fill 123 245 481 124 250 481 minecraft:basalt
fill 123 245 485 123 251 485 minecraft:basalt
setblock 123 245 486 minecraft:magma_block
setblock 123 245 495 minecraft:magma_block
fill 124 245 471 124 245 472 minecraft:basalt
fill 124 245 484 124 251 484 minecraft:basalt
fill 124 245 494 124 245 495 minecraft:basalt
setblock 125 245 472 minecraft:basalt
fill 125 245 493 125 245 494 minecraft:basalt
setblock 126 245 473 minecraft:magma_block
setblock 126 245 493 minecraft:basalt
fill 127 245 475 127 245 476 minecraft:basalt
fill 127 245 490 127 245 491 minecraft:basalt
setblock 128 245 476 minecraft:basalt
fill 128 245 481 128 246 481 minecraft:basalt
fill 128 245 487 128 245 490 minecraft:basalt
setblock 129 245 481 minecraft:magma_block
setblock 129 245 484 minecraft:magma_block
setblock 129 245 487 minecraft:magma_block
fill 130 245 504 135 245 504 minecraft:sculk
fill 135 245 464 135 245 469 minecraft:sculk
fill 135 245 476 135 245 481 minecraft:sculk
fill 135 245 488 135 245 493 minecraft:sculk
fill 135 245 500 135 245 503 minecraft:sculk
fill 94 246 469 94 251 472 minecraft:sea_lantern
fill 94 246 481 94 251 484 minecraft:sea_lantern
fill 94 246 493 94 251 496 minecraft:sea_lantern
fill 94 246 505 97 251 505 minecraft:sea_lantern
fill 100 246 479 101 246 479 minecraft:basalt
fill 101 246 463 104 251 463 minecraft:sea_lantern
setblock 101 246 476 minecraft:basalt
setblock 101 246 477 minecraft:magma_block
fill 101 246 478 101 247 478 minecraft:basalt
fill 101 246 487 101 247 488 minecraft:basalt
setblock 101 246 489 minecraft:magma_block
setblock 101 246 490 minecraft:basalt
setblock 104 246 473 minecraft:magma_block
fill 104 246 474 104 247 474 minecraft:basalt
fill 105 246 480 106 246 480 minecraft:basalt
fill 105 246 482 105 250 484 minecraft:basalt
fill 105 246 486 106 246 486 minecraft:basalt
setblock 105 246 494 minecraft:basalt
fill 106 246 479 106 251 479 minecraft:basalt
fill 106 246 487 106 251 487 minecraft:basalt
fill 106 246 505 109 251 505 minecraft:sea_lantern
setblock 107 246 470 minecraft:basalt
setblock 107 246 478 minecraft:magma_block
fill 107 246 488 107 251 488 minecraft:basalt
fill 107 246 495 107 247 495 minecraft:basalt
setblock 107 246 496 minecraft:magma_block
fill 108 246 476 108 250 477 minecraft:basalt
fill 108 246 489 108 250 489 minecraft:basalt
setblock 109 246 476 minecraft:basalt
fill 109 246 490 109 251 490 minecraft:basalt
fill 110 246 475 111 251 475 minecraft:basalt
fill 110 246 491 111 250 491 minecraft:basalt
fill 113 246 463 116 251 463 minecraft:sea_lantern
fill 113 246 469 115 246 469 minecraft:basalt
fill 113 246 474 115 251 474 minecraft:basalt
fill 113 246 492 115 251 492 minecraft:basalt
setblock 113 246 497 minecraft:magma_block
fill 114 246 497 115 246 497 minecraft:basalt
setblock 116 246 469 minecraft:magma_block
fill 117 246 475 118 251 475 minecraft:basalt
fill 117 246 491 118 251 491 minecraft:basalt
fill 118 246 505 121 251 505 minecraft:sea_lantern
fill 119 246 476 119 251 476 minecraft:basalt
fill 119 246 490 120 251 490 minecraft:basalt
fill 120 246 470 121 246 470 minecraft:basalt
fill 120 246 477 120 251 477 minecraft:basalt
fill 120 246 489 120 251 489 minecraft:basalt
setblock 121 246 478 minecraft:basalt
fill 121 246 488 121 251 488 minecraft:basalt
setblock 121 246 496 minecraft:basalt
setblock 122 246 479 minecraft:magma_block
fill 122 246 480 123 251 480 minecraft:basalt
fill 122 246 486 122 251 487 minecraft:basalt
fill 123 246 482 123 250 484 minecraft:basalt
fill 123 246 486 123 251 486 minecraft:basalt
fill 125 246 463 128 251 463 minecraft:sea_lantern
setblock 127 246 476 minecraft:basalt
setblock 127 246 490 minecraft:basalt
setblock 128 246 480 minecraft:magma_block
setblock 128 246 482 minecraft:basalt
setblock 128 246 483 minecraft:magma_block
setblock 128 246 484 minecraft:basalt
setblock 128 246 486 minecraft:magma_block
setblock 128 246 487 minecraft:basalt
fill 130 246 505 133 251 505 minecraft:sea_lantern
fill 136 246 464 136 251 467 minecraft:sea_lantern
fill 136 246 476 136 251 479 minecraft:sea_lantern
fill 136 246 488 136 251 491 minecraft:sea_lantern
fill 136 246 500 136 251 503 minecraft:sea_lantern
setblock 97 247 466 minecraft:light[level=11]
setblock 97 247 474 minecraft:light[level=11]
setblock 97 247 482 minecraft:light[level=11]
setblock 97 247 490 minecraft:light[level=11]
setblock 97 247 498 minecraft:light[level=11]
setblock 101 247 479 minecraft:basalt
setblock 103 247 475 minecraft:magma_block
fill 103 247 476 103 248 476 minecraft:basalt
setblock 105 247 466 minecraft:light[level=11]
fill 105 247 480 105 251 480 minecraft:basalt
fill 105 247 486 105 251 486 minecraft:basalt
setblock 105 247 498 minecraft:light[level=11]
setblock 106 247 480 minecraft:magma_block
fill 106 247 481 106 251 482 minecraft:basalt
setblock 106 247 483 minecraft:magma_block
fill 106 247 484 106 251 485 minecraft:basalt
setblock 106 247 486 minecraft:magma_block
fill 107 247 478 107 251 479 minecraft:basalt
fill 107 247 487 107 251 487 minecraft:basalt
setblock 109 247 470 minecraft:magma_block
setblock 109 247 476 minecraft:magma_block
setblock 110 247 470 minecraft:basalt
fill 110 247 476 110 251 476 minecraft:basalt
fill 110 247 490 110 251 490 minecraft:basalt
setblock 111 247 496 minecraft:basalt
setblock 112 247 475 minecraft:magma_block
fill 112 247 491 116 247 491 minecraft:basalt
setblock 112 247 496 minecraft:magma_block
setblock 113 247 466 minecraft:light[level=11]
fill 113 247 475 116 250 475 minecraft:basalt
setblock 113 247 482 minecraft:light[level=11]
setblock 113 247 490 minecraft:light[level=11]
setblock 113 247 498 minecraft:light[level=11]
fill 115 247 470 117 247 470 minecraft:basalt
setblock 118 247 470 minecraft:magma_block
setblock 118 247 476 minecraft:magma_block
fill 118 247 490 118 251 490 minecraft:basalt
setblock 121 247 466 minecraft:light[level=11]
setblock 121 247 478 minecraft:magma_block
fill 121 247 479 122 251 479 minecraft:basalt
setblock 121 247 482 minecraft:light[level=11]
setblock 121 247 487 minecraft:magma_block
setblock 121 247 498 minecraft:light[level=11]
fill 122 247 481 122 251 485 minecraft:basalt
setblock 124 247 474 minecraft:magma_block
setblock 124 247 492 minecraft:magma_block
setblock 127 247 479 minecraft:magma_block
fill 127 247 480 127 247 481 minecraft:basalt
setblock 127 247 482 minecraft:magma_block
fill 127 247 483 127 248 484 minecraft:basalt
setblock 127 247 485 minecraft:magma_block
setblock 127 247 486 minecraft:basalt
setblock 127 247 488 minecraft:magma_block
setblock 129 247 466 minecraft:light[level=11]
setblock 129 247 474 minecraft:light[level=11]
setblock 129 247 482 minecraft:light[level=11]
setblock 129 247 490 minecraft:light[level=11]
setblock 129 247 498 minecraft:light[level=11]
setblock 102 248 479 minecraft:basalt
setblock 102 248 480 minecraft:magma_block
fill 102 248 485 102 249 485 minecraft:basalt
setblock 102 248 486 minecraft:magma_block
setblock 102 248 487 minecraft:basalt
setblock 103 248 477 minecraft:basalt
setblock 103 248 489 minecraft:basalt
setblock 105 248 474 minecraft:basalt
fill 106 248 480 107 251 480 minecraft:basalt
fill 106 248 483 106 251 483 minecraft:basalt
fill 106 248 486 107 251 486 minecraft:basalt
fill 107 248 481 107 251 481 minecraft:basalt
fill 107 248 485 107 251 485 minecraft:basalt
setblock 108 248 472 minecraft:magma_block
setblock 108 248 478 minecraft:magma_block
fill 108 248 479 108 251 479 minecraft:basalt
setblock 108 248 487 minecraft:magma_block
fill 108 248 488 108 251 488 minecraft:basalt
fill 109 248 471 110 248 471 minecraft:basalt
fill 109 248 476 109 251 477 minecraft:basalt
fill 109 248 489 110 251 489 minecraft:basalt
fill 109 248 495 110 248 495 minecraft:basalt
fill 110 248 477 110 251 477 minecraft:basalt
setblock 111 248 471 minecraft:magma_block
fill 111 248 476 112 250 476 minecraft:basalt
fill 111 248 490 112 251 490 minecraft:basalt
setblock 111 248 495 minecraft:magma_block
fill 112 248 475 112 251 475 minecraft:basalt
fill 112 248 491 113 251 491 minecraft:basalt
setblock 113 248 470 minecraft:basalt
setblock 114 248 470 minecraft:magma_block
setblock 114 248 491 minecraft:magma_block
fill 114 248 496 115 248 496 minecraft:basalt
setblock 115 248 470 minecraft:basalt
fill 115 248 491 116 251 491 minecraft:basalt
fill 116 248 476 118 251 476 minecraft:basalt
fill 116 248 490 116 251 490 minecraft:basalt
setblock 117 248 490 minecraft:magma_block
fill 118 248 477 119 251 477 minecraft:basalt
fill 118 248 489 119 251 489 minecraft:basalt
setblock 120 248 472 minecraft:basalt
fill 120 248 478 120 250 479 minecraft:basalt
fill 120 248 487 120 250 488 minecraft:basalt
setblock 120 248 494 minecraft:basalt
fill 121 248 473 122 248 473 minecraft:basalt
fill 121 248 478 121 251 478 minecraft:basalt
fill 121 248 480 121 251 481 minecraft:basalt
fill 121 248 485 121 251 487 minecraft:basalt
fill 125 248 471 126 273 472 minecraft:deepslate_bricks
setblock 126 248 478 minecraft:magma_block
fill 126 248 479 126 248 480 minecraft:basalt
setblock 126 248 481 minecraft:magma_block
fill 126 248 482 126 248 486 minecraft:basalt
setblock 126 248 487 minecraft:magma_block
setblock 126 248 488 minecraft:basalt
setblock 127 248 482 minecraft:basalt
setblock 102 249 482 minecraft:basalt
setblock 104 249 489 minecraft:basalt
setblock 105 249 475 minecraft:basalt
setblock 107 249 474 minecraft:magma_block
fill 107 249 482 107 251 482 minecraft:basalt
setblock 107 249 483 minecraft:magma_block
fill 107 249 484 107 251 484 minecraft:basalt
setblock 107 249 492 minecraft:magma_block
fill 108 249 478 109 251 478 minecraft:basalt
fill 108 249 480 108 250 480 minecraft:basalt
fill 108 249 486 108 250 487 minecraft:basalt
fill 109 249 488 109 251 488 minecraft:basalt
setblock 109 249 494 minecraft:basalt
setblock 110 249 494 minecraft:magma_block
fill 111 249 477 111 251 477 minecraft:basalt
fill 111 249 489 111 251 489 minecraft:basalt
fill 113 249 471 115 249 471 minecraft:basalt
fill 113 249 476 115 251 476 minecraft:basalt
setblock 113 249 490 minecraft:magma_block
fill 113 249 495 115 249 495 minecraft:basalt
fill 114 249 490 114 250 491 minecraft:basalt
fill 115 249 490 115 251 490 minecraft:basalt
setblock 116 249 471 minecraft:magma_block
setblock 116 249 495 minecraft:magma_block
fill 117 249 477 117 250 477 minecraft:basalt
fill 117 249 489 117 250 490 minecraft:basalt
setblock 118 249 494 minecraft:basalt
fill 119 249 478 119 251 478 minecraft:basalt
setblock 119 249 488 minecraft:magma_block
setblock 119 249 494 minecraft:magma_block
fill 120 249 480 120 251 480 minecraft:basalt
fill 120 249 486 120 251 486 minecraft:basalt
fill 121 249 482 121 251 484 minecraft:basalt
setblock 122 249 475 minecraft:magma_block
setblock 122 249 492 minecraft:basalt
fill 123 249 475 123 249 476 minecraft:basalt
fill 124 249 471 124 250 472 minecraft:sculk
setblock 124 249 477 minecraft:basalt
setblock 124 249 489 minecraft:basalt
fill 125 249 470 126 250 470 minecraft:sculk
fill 125 249 473 126 250 473 minecraft:sculk
setblock 125 249 480 minecraft:magma_block
fill 125 249 481 126 249 481 minecraft:basalt
setblock 125 249 486 minecraft:magma_block
fill 126 249 482 126 249 485 minecraft:basalt
fill 127 249 471 127 250 472 minecraft:sculk
fill 103 250 481 103 250 482 minecraft:basalt
setblock 103 250 483 minecraft:magma_block
fill 103 250 484 103 250 485 minecraft:basalt
setblock 105 250 489 minecraft:basalt
setblock 106 250 476 minecraft:magma_block
fill 107 250 483 108 250 483 minecraft:basalt
fill 108 250 481 108 250 482 minecraft:basalt
fill 108 250 484 108 250 485 minecraft:basalt
setblock 109 250 473 minecraft:basalt
fill 109 250 479 109 251 479 minecraft:basalt
setblock 109 250 487 minecraft:magma_block
setblock 109 250 493 minecraft:magma_block
fill 110 250 478 110 251 478 minecraft:basalt
fill 110 250 488 110 251 488 minecraft:basalt
setblock 111 250 493 minecraft:basalt
fill 112 250 472 113 250 472 minecraft:basalt
setblock 112 250 477 minecraft:magma_block
setblock 112 250 489 minecraft:magma_block
fill 112 250 494 114 250 494 minecraft:basalt
fill 113 250 477 116 250 477 minecraft:basalt
fill 113 250 489 113 250 490 minecraft:basalt
fill 114 250 489 116 250 489 minecraft:basalt
fill 115 250 472 116 250 472 minecraft:basalt
setblock 115 250 494 minecraft:magma_block
setblock 117 250 493 minecraft:basalt
setblock 118 250 478 minecraft:magma_block
fill 118 250 488 119 251 488 minecraft:basalt
setblock 118 250 493 minecraft:magma_block
fill 119 250 479 119 251 479 minecraft:basalt
fill 119 250 487 119 251 487 minecraft:basalt
setblock 120 250 474 minecraft:basalt
fill 120 250 481 120 250 485 minecraft:basalt
setblock 122 250 490 minecraft:basalt
setblock 124 250 470 minecraft:sculk
setblock 124 250 473 minecraft:sculk
setblock 124 250 479 minecraft:magma_block
setblock 124 250 480 minecraft:basalt
setblock 124 250 488 minecraft:magma_block
setblock 125 250 481 minecraft:basalt
setblock 127 250 470 minecraft:sculk
setblock 127 250 473 minecraft:sculk
fill 104 251 481 104 251 485 minecraft:basalt
setblock 105 251 478 minecraft:magma_block
setblock 105 251 479 minecraft:basalt
setblock 105 251 481 minecraft:magma_block
fill 105 251 482 105 251 483 minecraft:basalt
setblock 105 251 484 minecraft:magma_block
setblock 105 251 487 minecraft:magma_block
setblock 105 251 488 minecraft:basalt
setblock 107 251 483 minecraft:basalt
setblock 107 251 490 minecraft:basalt
setblock 108 251 476 minecraft:basalt
setblock 108 251 477 minecraft:magma_block
fill 108 251 480 109 251 480 minecraft:magma_block
setblock 108 251 481 minecraft:basalt
fill 108 251 482 108 251 484 minecraft:magma_block
setblock 108 251 485 minecraft:basalt
fill 108 251 486 109 251 486 minecraft:magma_block
fill 108 251 487 109 251 487 minecraft:basalt
setblock 108 251 489 minecraft:magma_block
fill 109 251 481 109 251 482 minecraft:magma_block
fill 109 251 484 109 251 485 minecraft:magma_block
setblock 110 251 479 minecraft:magma_block
setblock 110 251 487 minecraft:magma_block
fill 110 251 491 110 251 492 minecraft:basalt
setblock 111 251 476 minecraft:magma_block
fill 111 251 478 113 251 478 minecraft:magma_block
fill 111 251 488 113 251 488 minecraft:magma_block
setblock 111 251 491 minecraft:magma_block
fill 112 251 476 112 251 477 minecraft:basalt
setblock 112 251 489 minecraft:basalt
fill 112 251 493 113 251 493 minecraft:basalt
setblock 113 251 475 minecraft:basalt
fill 113 251 477 115 251 477 minecraft:magma_block
fill 113 251 489 115 251 489 minecraft:magma_block
setblock 113 251 490 minecraft:basalt
setblock 114 251 475 minecraft:magma_block
setblock 114 251 490 minecraft:magma_block
setblock 114 251 491 minecraft:basalt
setblock 114 251 493 minecraft:magma_block
fill 115 251 475 116 251 475 minecraft:basalt
fill 115 251 478 117 251 478 minecraft:magma_block
fill 115 251 488 117 251 488 minecraft:magma_block
setblock 116 251 474 minecraft:basalt
setblock 116 251 477 minecraft:basalt
setblock 116 251 489 minecraft:basalt
fill 116 251 492 116 251 493 minecraft:basalt
setblock 117 251 474 minecraft:magma_block
setblock 117 251 477 minecraft:magma_block
setblock 117 251 489 minecraft:magma_block
setblock 117 251 490 minecraft:basalt
setblock 117 251 492 minecraft:magma_block
setblock 118 251 474 minecraft:basalt
setblock 118 251 478 minecraft:basalt
setblock 118 251 479 minecraft:magma_block
setblock 118 251 487 minecraft:magma_block
fill 118 251 492 119 251 492 minecraft:basalt
fill 119 251 480 119 251 482 minecraft:magma_block
fill 119 251 484 119 251 486 minecraft:magma_block
setblock 120 251 476 minecraft:magma_block
setblock 120 251 478 minecraft:basalt
setblock 120 251 479 minecraft:magma_block
setblock 120 251 481 minecraft:basalt
fill 120 251 482 120 251 485 minecraft:magma_block
setblock 120 251 487 minecraft:basalt
setblock 120 251 488 minecraft:magma_block
setblock 120 251 491 minecraft:magma_block
setblock 121 251 476 minecraft:basalt
setblock 123 251 478 minecraft:magma_block
setblock 123 251 479 minecraft:basalt
setblock 123 251 481 minecraft:magma_block
fill 123 251 482 123 251 483 minecraft:basalt
setblock 123 251 484 minecraft:magma_block
setblock 123 251 487 minecraft:magma_block
setblock 123 251 488 minecraft:basalt
setblock 124 251 481 minecraft:basalt
setblock 124 251 485 minecraft:basalt
fill 94 252 469 94 265 469 minecraft:deepslate_tiles
fill 94 252 470 94 252 471 minecraft:sea_lantern
fill 94 252 472 94 265 472 minecraft:deepslate_tiles
fill 94 252 481 94 265 481 minecraft:deepslate_tiles
fill 94 252 482 94 252 483 minecraft:sea_lantern
fill 94 252 484 94 265 484 minecraft:deepslate_tiles
fill 94 252 493 94 265 493 minecraft:deepslate_tiles
fill 94 252 494 94 252 495 minecraft:sea_lantern
fill 94 252 496 94 265 496 minecraft:deepslate_tiles
fill 94 252 505 94 265 505 minecraft:deepslate_tiles
fill 95 252 505 96 252 505 minecraft:sea_lantern
fill 97 252 505 97 265 505 minecraft:deepslate_tiles
fill 101 252 463 101 265 463 minecraft:deepslate_tiles
fill 102 252 463 103 252 463 minecraft:sea_lantern
fill 104 252 463 104 265 463 minecraft:deepslate_tiles
fill 106 252 505 106 265 505 minecraft:deepslate_tiles
fill 107 252 505 108 252 505 minecraft:sea_lantern
fill 109 252 505 109 265 505 minecraft:deepslate_tiles
fill 113 252 463 113 265 463 minecraft:deepslate_tiles
fill 114 252 463 115 252 463 minecraft:sea_lantern
fill 116 252 463 116 265 463 minecraft:deepslate_tiles
fill 118 252 505 118 265 505 minecraft:deepslate_tiles
fill 119 252 505 120 252 505 minecraft:sea_lantern
fill 121 252 505 121 265 505 minecraft:deepslate_tiles
fill 125 252 463 125 265 463 minecraft:deepslate_tiles
fill 126 252 463 127 252 463 minecraft:sea_lantern
fill 128 252 463 128 265 463 minecraft:deepslate_tiles
fill 130 252 505 130 265 505 minecraft:deepslate_tiles
fill 131 252 505 132 252 505 minecraft:sea_lantern
fill 133 252 505 133 265 505 minecraft:deepslate_tiles
fill 136 252 464 136 265 464 minecraft:deepslate_tiles
fill 136 252 465 136 252 466 minecraft:sea_lantern
fill 136 252 467 136 265 467 minecraft:deepslate_tiles
fill 136 252 476 136 265 476 minecraft:deepslate_tiles
fill 136 252 477 136 252 478 minecraft:sea_lantern
fill 136 252 479 136 265 479 minecraft:deepslate_tiles
fill 136 252 488 136 265 488 minecraft:deepslate_tiles
fill 136 252 489 136 252 490 minecraft:sea_lantern
fill 136 252 491 136 265 491 minecraft:deepslate_tiles
fill 136 252 500 136 265 500 minecraft:deepslate_tiles
fill 136 252 501 136 252 502 minecraft:sea_lantern
fill 136 252 503 136 265 503 minecraft:deepslate_tiles
fill 94 253 470 94 265 471 minecraft:deepslate_tiles
fill 94 253 482 94 265 483 minecraft:deepslate_tiles
fill 94 253 494 94 265 495 minecraft:deepslate_tiles
fill 95 253 505 96 265 505 minecraft:deepslate_tiles
fill 102 253 463 103 265 463 minecraft:deepslate_tiles
fill 107 253 505 108 265 505 minecraft:deepslate_tiles
fill 114 253 463 115 265 463 minecraft:deepslate_tiles
fill 119 253 505 120 265 505 minecraft:deepslate_tiles
fill 126 253 463 127 265 463 minecraft:deepslate_tiles
fill 131 253 505 132 265 505 minecraft:deepslate_tiles
fill 136 253 465 136 265 466 minecraft:deepslate_tiles
fill 136 253 477 136 265 478 minecraft:deepslate_tiles
fill 136 253 489 136 265 490 minecraft:deepslate_tiles
fill 136 253 501 136 265 502 minecraft:deepslate_tiles
setblock 97 255 466 minecraft:light[level=11]
setblock 97 255 474 minecraft:light[level=11]
setblock 97 255 482 minecraft:light[level=11]
setblock 97 255 490 minecraft:light[level=11]
setblock 97 255 498 minecraft:light[level=11]
setblock 105 255 466 minecraft:light[level=11]
setblock 105 255 474 minecraft:light[level=11]
setblock 105 255 482 minecraft:light[level=11]
setblock 105 255 490 minecraft:light[level=11]
setblock 105 255 498 minecraft:light[level=11]
setblock 113 255 466 minecraft:light[level=11]
setblock 113 255 474 minecraft:light[level=11]
setblock 113 255 482 minecraft:light[level=11]
setblock 113 255 490 minecraft:light[level=11]
setblock 113 255 498 minecraft:light[level=11]
setblock 121 255 466 minecraft:light[level=11]
setblock 121 255 474 minecraft:light[level=11]
setblock 121 255 482 minecraft:light[level=11]
setblock 121 255 490 minecraft:light[level=11]
setblock 121 255 498 minecraft:light[level=11]
setblock 129 255 466 minecraft:light[level=11]
setblock 129 255 474 minecraft:light[level=11]
setblock 129 255 482 minecraft:light[level=11]
setblock 129 255 490 minecraft:light[level=11]
setblock 129 255 498 minecraft:light[level=11]
fill 96 260 473 96 265 475 minecraft:deepslate_bricks
fill 96 260 485 96 265 487 minecraft:deepslate_bricks
fill 96 260 497 96 265 499 minecraft:deepslate_bricks
fill 102 260 503 104 265 503 minecraft:deepslate_bricks
fill 106 260 465 108 265 465 minecraft:deepslate_bricks
fill 114 260 503 116 265 503 minecraft:deepslate_bricks
fill 118 260 465 120 265 465 minecraft:deepslate_bricks
fill 126 260 503 128 265 503 minecraft:deepslate_bricks
fill 130 260 465 132 265 465 minecraft:deepslate_bricks
fill 134 260 473 134 265 475 minecraft:deepslate_bricks
fill 134 260 485 134 265 487 minecraft:deepslate_bricks
fill 134 260 497 134 265 499 minecraft:deepslate_bricks
fill 103 261 464 105 262 467 minecraft:cyan_stained_glass
setblock 104 261 468 minecraft:cyan_stained_glass
fill 102 262 464 102 263 464 minecraft:cyan_stained_glass
fill 106 262 464 106 263 464 minecraft:cyan_stained_glass
setblock 97 263 466 minecraft:light[level=11]
setblock 97 263 474 minecraft:light[level=11]
setblock 97 263 482 minecraft:light[level=11]
setblock 97 263 490 minecraft:light[level=11]
setblock 97 263 498 minecraft:light[level=11]
fill 103 263 464 105 263 466 minecraft:cyan_stained_glass
setblock 105 263 474 minecraft:light[level=11]
setblock 105 263 482 minecraft:light[level=11]
setblock 105 263 490 minecraft:light[level=11]
setblock 105 263 498 minecraft:light[level=11]
setblock 113 263 466 minecraft:light[level=11]
setblock 113 263 474 minecraft:light[level=11]
setblock 113 263 482 minecraft:light[level=11]
setblock 113 263 490 minecraft:light[level=11]
setblock 113 263 498 minecraft:light[level=11]
setblock 121 263 466 minecraft:light[level=11]
setblock 121 263 474 minecraft:light[level=11]
setblock 121 263 482 minecraft:light[level=11]
setblock 121 263 490 minecraft:light[level=11]
setblock 121 263 498 minecraft:light[level=11]
setblock 129 263 466 minecraft:light[level=11]
setblock 129 263 474 minecraft:light[level=11]
setblock 129 263 482 minecraft:light[level=11]
setblock 129 263 490 minecraft:light[level=11]
setblock 129 263 498 minecraft:light[level=11]
fill 103 264 464 105 264 465 minecraft:cyan_stained_glass
fill 134 264 494 134 265 494 minecraft:cyan_concrete
fill 95 265 467 95 265 472 minecraft:sculk
fill 95 265 479 95 265 484 minecraft:sculk
fill 95 265 491 95 265 496 minecraft:sculk
fill 95 265 503 95 265 504 minecraft:sculk
fill 96 265 504 99 265 504 minecraft:sculk
fill 99 265 464 104 265 464 minecraft:sculk
fill 106 265 504 111 265 504 minecraft:sculk
fill 111 265 464 116 265 464 minecraft:sculk
fill 118 265 504 123 265 504 minecraft:sculk
fill 123 265 464 128 265 464 minecraft:sculk
fill 130 265 504 135 265 504 minecraft:sculk
fill 132 265 494 133 266 494 minecraft:cyan_concrete
fill 135 265 464 135 265 469 minecraft:sculk
fill 135 265 476 135 265 481 minecraft:sculk
fill 135 265 488 135 265 493 minecraft:sculk
fill 135 265 500 135 265 503 minecraft:sculk
fill 94 266 469 94 271 472 minecraft:sea_lantern
fill 94 266 481 94 271 484 minecraft:sea_lantern
fill 94 266 493 94 271 496 minecraft:sea_lantern
fill 94 266 505 97 271 505 minecraft:sea_lantern
fill 101 266 463 104 271 463 minecraft:sea_lantern
fill 106 266 505 109 271 505 minecraft:sea_lantern
fill 113 266 463 116 271 463 minecraft:sea_lantern
fill 118 266 505 121 271 505 minecraft:sea_lantern
fill 125 266 463 128 271 463 minecraft:sea_lantern
fill 130 266 496 134 267 496 minecraft:cyan_concrete
fill 130 266 505 133 271 505 minecraft:sea_lantern
fill 131 266 494 131 267 494 minecraft:cyan_concrete
fill 136 266 464 136 271 467 minecraft:sea_lantern
fill 136 266 476 136 271 479 minecraft:sea_lantern
fill 136 266 488 136 271 491 minecraft:sea_lantern
fill 136 266 500 136 271 503 minecraft:sea_lantern
fill 129 267 494 130 267 494 minecraft:cyan_concrete
setblock 129 267 496 minecraft:cyan_concrete
setblock 129 268 494 minecraft:cyan_concrete
fill 96 270 484 96 273 484 minecraft:reinforced_deepslate
fill 105 270 502 105 273 502 minecraft:reinforced_deepslate
fill 124 270 470 124 270 473 minecraft:cyan_concrete
fill 125 270 469 126 270 470 minecraft:cyan_concrete
fill 125 270 473 127 270 473 minecraft:cyan_concrete
fill 127 270 470 127 270 472 minecraft:cyan_concrete
setblock 97 271 466 minecraft:light[level=11]
setblock 97 271 474 minecraft:light[level=11]
setblock 97 271 482 minecraft:light[level=11]
setblock 97 271 490 minecraft:light[level=11]
schedule function dropper:buildpart/110_3 1t
