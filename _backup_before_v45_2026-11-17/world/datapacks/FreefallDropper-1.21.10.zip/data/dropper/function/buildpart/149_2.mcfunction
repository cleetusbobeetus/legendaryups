fill 240 235 639 272 235 639 minecraft:light_gray_concrete
fill 241 235 610 250 235 610 minecraft:light_gray_concrete
fill 241 235 614 242 249 615 minecraft:light_blue_concrete
fill 241 235 616 246 235 622 minecraft:light_gray_concrete
fill 241 235 626 247 235 632 minecraft:light_gray_concrete
fill 241 235 633 242 249 634 minecraft:light_blue_concrete
fill 241 235 635 250 239 636 minecraft:light_gray_concrete
fill 241 235 640 271 235 640 minecraft:light_gray_concrete
fill 242 235 609 270 235 609 minecraft:light_gray_concrete
fill 242 235 641 270 235 641 minecraft:light_gray_concrete
fill 243 235 608 269 235 608 minecraft:light_gray_concrete
fill 243 235 614 259 239 615 minecraft:light_gray_concrete
fill 243 235 633 259 238 634 minecraft:light_gray_concrete
fill 243 235 642 269 235 642 minecraft:light_gray_concrete
fill 245 235 607 267 235 607 minecraft:light_gray_concrete
fill 245 235 643 267 235 643 minecraft:light_gray_concrete
fill 246 235 606 266 235 606 minecraft:light_gray_concrete
fill 246 235 644 266 235 644 minecraft:light_gray_concrete
fill 247 235 616 275 235 618 minecraft:light_gray_concrete
fill 247 235 622 248 235 622 minecraft:light_gray_concrete
fill 248 235 605 264 235 605 minecraft:light_gray_concrete
fill 248 235 623 248 235 626 minecraft:gray_concrete
fill 248 235 627 248 235 632 minecraft:light_gray_concrete
fill 248 235 645 264 235 645 minecraft:light_gray_concrete
setblock 249 235 622 minecraft:gray_concrete
setblock 249 235 627 minecraft:gray_concrete
fill 249 235 628 249 235 632 minecraft:light_gray_concrete
fill 250 235 611 252 249 611 minecraft:pink_concrete
fill 250 235 619 250 235 620 minecraft:light_gray_concrete
setblock 250 235 621 minecraft:gray_concrete
fill 250 235 628 255 235 628 minecraft:gray_concrete
fill 250 235 629 276 235 632 minecraft:light_gray_concrete
fill 250 235 637 252 249 637 minecraft:pink_concrete
fill 250 235 638 250 242 638 minecraft:light_gray_concrete
fill 251 235 610 251 249 610 minecraft:pink_concrete
fill 251 235 612 251 249 612 minecraft:pink_concrete
fill 251 235 613 273 236 613 minecraft:light_gray_concrete
fill 251 235 619 276 235 619 minecraft:light_gray_concrete
fill 251 235 620 253 235 620 minecraft:gray_concrete
fill 251 235 635 275 235 635 minecraft:light_gray_concrete
fill 251 235 636 251 249 636 minecraft:pink_concrete
fill 251 235 638 251 249 638 minecraft:pink_concrete
fill 252 235 610 271 235 610 minecraft:light_gray_concrete
fill 252 235 612 273 235 612 minecraft:light_gray_concrete
fill 252 235 636 274 235 636 minecraft:light_gray_concrete
fill 252 235 638 273 235 638 minecraft:light_gray_concrete
fill 253 235 611 272 235 611 minecraft:light_gray_concrete
fill 253 235 637 273 236 637 minecraft:light_gray_concrete
fill 254 235 620 276 235 620 minecraft:light_gray_concrete
fill 254 235 621 255 235 621 minecraft:gray_concrete
setblock 254 235 623 minecraft:light[level=14]
fill 254 235 627 256 235 627 minecraft:gray_concrete
fill 255 235 622 256 235 622 minecraft:gray_concrete
fill 255 235 626 256 235 626 minecraft:gray_concrete
fill 256 235 621 276 235 621 minecraft:light_gray_concrete
fill 256 235 623 256 235 625 minecraft:gray_concrete
fill 256 235 628 276 235 628 minecraft:light_gray_concrete
fill 257 235 622 262 235 627 minecraft:light_gray_concrete
fill 260 235 614 261 249 615 minecraft:light_blue_concrete
fill 260 235 633 261 249 634 minecraft:light_blue_concrete
fill 262 235 614 274 235 615 minecraft:light_gray_concrete
fill 262 235 633 275 235 634 minecraft:light_gray_concrete
fill 263 235 622 263 238 623 minecraft:light_gray_concrete
fill 263 235 624 265 249 624 minecraft:pink_concrete
fill 263 235 625 263 238 627 minecraft:light_gray_concrete
fill 264 235 622 276 237 622 minecraft:light_gray_concrete
fill 264 235 623 264 249 623 minecraft:pink_concrete
fill 264 235 625 264 249 625 minecraft:pink_concrete
fill 264 235 626 276 237 627 minecraft:light_gray_concrete
fill 265 235 623 276 237 623 minecraft:light_gray_concrete
fill 265 235 625 276 237 625 minecraft:light_gray_concrete
fill 266 235 624 276 237 624 minecraft:light_gray_concrete
setblock 270 235 607 minecraft:light[level=14]
setblock 275 235 615 minecraft:light_gray_concrete
fill 276 235 617 276 235 618 minecraft:light_gray_concrete
setblock 276 235 633 minecraft:light_gray_concrete
fill 236 236 619 236 236 631 minecraft:light_gray_concrete
fill 237 236 617 237 236 623 minecraft:light_gray_concrete
fill 237 236 625 237 236 633 minecraft:light_gray_concrete
fill 238 236 615 240 236 622 minecraft:light_gray_concrete
fill 238 236 626 240 236 635 minecraft:light_gray_concrete
fill 239 236 613 240 236 614 minecraft:light_gray_concrete
fill 239 236 623 244 239 623 minecraft:light_gray_concrete
fill 239 236 625 244 239 625 minecraft:light_gray_concrete
fill 239 236 636 240 236 637 minecraft:light_gray_concrete
fill 240 236 612 250 236 612 minecraft:light_gray_concrete
fill 240 236 624 244 239 624 minecraft:light_gray_concrete
fill 240 236 638 249 236 638 minecraft:light_gray_concrete
fill 241 236 611 249 236 611 minecraft:light_gray_concrete
fill 241 236 613 250 238 613 minecraft:light_gray_concrete
fill 241 236 616 245 239 622 minecraft:light_gray_concrete
fill 241 236 626 245 239 632 minecraft:light_gray_concrete
fill 241 236 637 249 238 637 minecraft:light_gray_concrete
fill 241 236 639 271 236 639 minecraft:light_gray_concrete
fill 242 236 610 250 236 610 minecraft:light_gray_concrete
fill 242 236 640 270 236 640 minecraft:light_gray_concrete
fill 243 236 609 269 236 609 minecraft:light_gray_concrete
fill 243 236 641 269 236 641 minecraft:light_gray_concrete
fill 244 236 608 268 236 608 minecraft:light_gray_concrete
fill 244 236 642 268 236 642 minecraft:light_gray_concrete
fill 245 236 623 246 237 625 minecraft:magenta_concrete
fill 246 236 607 266 236 607 minecraft:light_gray_concrete
fill 246 236 616 246 239 620 minecraft:light_gray_concrete
fill 246 236 621 246 237 622 minecraft:magenta_concrete
fill 246 236 626 246 237 627 minecraft:magenta_concrete
fill 246 236 628 246 238 632 minecraft:light_gray_concrete
fill 246 236 643 266 236 643 minecraft:light_gray_concrete
fill 247 236 616 247 239 619 minecraft:light_gray_concrete
fill 247 236 620 247 237 621 minecraft:magenta_concrete
fill 247 236 622 247 236 623 minecraft:light_gray_concrete
fill 247 236 624 247 236 625 minecraft:gray_concrete
setblock 247 236 626 minecraft:light_gray_concrete
fill 247 236 627 247 237 628 minecraft:magenta_concrete
fill 247 236 629 247 238 632 minecraft:light_gray_concrete
fill 248 236 606 264 236 606 minecraft:light_gray_concrete
fill 248 236 616 249 238 618 minecraft:light_gray_concrete
fill 248 236 619 248 237 620 minecraft:magenta_concrete
setblock 248 236 621 minecraft:light_gray_concrete
fill 248 236 622 248 236 623 minecraft:gray_concrete
fill 248 236 626 248 236 627 minecraft:gray_concrete
fill 248 236 628 248 237 629 minecraft:magenta_concrete
fill 248 236 630 249 237 632 minecraft:light_gray_concrete
fill 248 236 644 264 236 644 minecraft:light_gray_concrete
fill 249 236 619 254 237 619 minecraft:magenta_concrete
setblock 249 236 620 minecraft:light_gray_concrete
setblock 249 236 621 minecraft:gray_concrete
setblock 249 236 628 minecraft:gray_concrete
fill 249 236 629 254 237 629 minecraft:magenta_concrete
fill 250 236 605 262 236 605 minecraft:light_gray_concrete
fill 250 236 616 274 237 617 minecraft:light_gray_concrete
fill 250 236 618 252 237 618 minecraft:magenta_concrete
setblock 250 236 620 minecraft:gray_concrete
fill 250 236 630 252 237 630 minecraft:magenta_concrete
fill 250 236 631 275 236 632 minecraft:light_gray_concrete
fill 250 236 645 262 236 645 minecraft:light_gray_concrete
fill 251 236 635 274 236 635 minecraft:light_gray_concrete
fill 252 236 610 270 236 610 minecraft:light_gray_concrete
fill 252 236 612 272 236 612 minecraft:light_gray_concrete
fill 252 236 636 273 237 636 minecraft:light_gray_concrete
fill 252 236 638 272 236 638 minecraft:light_gray_concrete
fill 253 236 611 271 236 611 minecraft:light_gray_concrete
fill 253 236 618 275 236 618 minecraft:light_gray_concrete
setblock 253 236 630 minecraft:gray_concrete
fill 254 236 620 255 237 620 minecraft:magenta_concrete
fill 254 236 628 255 237 628 minecraft:magenta_concrete
fill 254 236 630 276 236 630 minecraft:light_gray_concrete
fill 255 236 619 276 236 619 minecraft:light_gray_concrete
fill 255 236 621 256 237 621 minecraft:magenta_concrete
fill 255 236 627 256 237 627 minecraft:magenta_concrete
fill 255 236 629 256 236 629 minecraft:gray_concrete
setblock 256 236 620 minecraft:gray_concrete
fill 256 236 622 256 237 626 minecraft:magenta_concrete
fill 256 236 628 257 236 628 minecraft:gray_concrete
fill 257 236 620 276 236 620 minecraft:light_gray_concrete
fill 257 236 621 257 236 622 minecraft:gray_concrete
fill 257 236 623 257 237 625 minecraft:magenta_concrete
fill 257 236 626 258 236 627 minecraft:gray_concrete
fill 257 236 629 276 236 629 minecraft:light_gray_concrete
fill 258 236 621 276 236 621 minecraft:light_gray_concrete
fill 258 236 622 258 236 625 minecraft:gray_concrete
fill 258 236 628 276 236 628 minecraft:light_gray_concrete
fill 259 236 622 262 236 627 minecraft:light_gray_concrete
fill 262 236 614 273 237 615 minecraft:light_gray_concrete
fill 262 236 633 274 237 634 minecraft:light_gray_concrete
setblock 274 236 615 minecraft:light_gray_concrete
setblock 275 236 617 minecraft:light_gray_concrete
setblock 275 236 633 minecraft:light_gray_concrete
setblock 276 236 631 minecraft:light_gray_concrete
fill 236 237 622 236 237 628 minecraft:light_gray_concrete
fill 237 237 618 237 237 623 minecraft:light_gray_concrete
fill 237 237 625 237 237 632 minecraft:light_gray_concrete
fill 238 237 616 240 237 622 minecraft:light_gray_concrete
fill 238 237 626 240 237 634 minecraft:light_gray_concrete
fill 239 237 614 240 237 615 minecraft:light_gray_concrete
fill 239 237 635 240 237 636 minecraft:light_gray_concrete
setblock 240 237 613 minecraft:light_gray_concrete
setblock 240 237 637 minecraft:light_gray_concrete
fill 241 237 612 250 237 612 minecraft:light_gray_concrete
fill 241 237 638 249 237 638 minecraft:light_gray_concrete
fill 242 237 611 249 237 611 minecraft:light_gray_concrete
fill 242 237 639 270 237 639 minecraft:light_gray_concrete
fill 243 237 610 250 237 610 minecraft:light_gray_concrete
fill 243 237 640 269 237 640 minecraft:light_gray_concrete
fill 244 237 609 268 237 609 minecraft:light_gray_concrete
fill 244 237 641 268 237 641 minecraft:light_gray_concrete
fill 245 237 608 267 237 608 minecraft:light_gray_concrete
fill 245 237 642 267 237 642 minecraft:light_gray_concrete
fill 247 237 607 265 237 607 minecraft:light_gray_concrete
fill 247 237 622 247 237 626 minecraft:gold_block
fill 247 237 643 265 237 643 minecraft:light_gray_concrete
setblock 248 237 621 minecraft:gold_block
fill 249 237 606 263 237 606 minecraft:light_gray_concrete
setblock 249 237 620 minecraft:gold_block
fill 249 237 644 263 237 644 minecraft:light_gray_concrete
fill 250 237 631 251 237 632 minecraft:light_gray_concrete
fill 251 237 613 272 237 613 minecraft:light_gray_concrete
fill 251 237 635 273 237 635 minecraft:light_gray_concrete
fill 252 237 610 269 237 610 minecraft:light_gray_concrete
fill 252 237 612 271 237 612 minecraft:light_gray_concrete
fill 252 237 631 255 237 631 minecraft:gold_block
fill 252 237 632 275 237 632 minecraft:light_gray_concrete
fill 252 237 638 271 237 638 minecraft:light_gray_concrete
fill 253 237 605 259 237 605 minecraft:light_gray_concrete
fill 253 237 611 270 237 611 minecraft:light_gray_concrete
fill 253 237 618 255 237 618 minecraft:gold_block
fill 253 237 637 272 237 637 minecraft:light_gray_concrete
fill 253 237 645 259 237 645 minecraft:light_gray_concrete
fill 254 237 630 257 237 630 minecraft:gold_block
fill 255 237 619 257 237 619 minecraft:gold_block
fill 256 237 618 275 237 618 minecraft:light_gray_concrete
fill 256 237 631 275 237 631 minecraft:light_gray_concrete
fill 257 237 620 258 237 620 minecraft:gold_block
fill 257 237 629 258 237 629 minecraft:gold_block
fill 258 237 619 275 237 619 minecraft:light_gray_concrete
fill 258 237 621 259 237 621 minecraft:gold_block
fill 258 237 628 259 237 628 minecraft:gold_block
fill 258 237 630 275 237 630 minecraft:light_gray_concrete
fill 259 237 620 275 237 620 minecraft:light_gray_concrete
fill 259 237 622 259 237 627 minecraft:gold_block
fill 259 237 629 275 237 629 minecraft:light_gray_concrete
fill 260 237 621 262 237 622 minecraft:light_gray_concrete
fill 260 237 623 260 237 626 minecraft:gold_block
fill 260 237 627 262 237 628 minecraft:light_gray_concrete
fill 261 237 623 262 237 626 minecraft:light_gray_concrete
fill 263 237 621 275 238 621 minecraft:light_gray_concrete
fill 263 237 628 276 237 628 minecraft:light_gray_concrete
fill 236 238 605 236 239 645 minecraft:gray_concrete
fill 237 238 605 237 238 620 minecraft:gray_concrete
fill 237 238 621 237 238 623 minecraft:light_gray_concrete
fill 237 238 625 237 238 629 minecraft:light_gray_concrete
fill 237 238 630 237 238 645 minecraft:gray_concrete
fill 238 238 605 251 238 606 minecraft:gray_concrete
fill 238 238 618 240 238 622 minecraft:light_gray_concrete
fill 238 238 626 240 238 632 minecraft:light_gray_concrete
fill 238 238 644 251 238 645 minecraft:gray_concrete
fill 239 238 616 240 238 617 minecraft:light_gray_concrete
fill 239 238 633 240 238 634 minecraft:light_gray_concrete
fill 239 238 639 239 238 642 minecraft:black_concrete
fill 240 238 614 240 238 615 minecraft:light_gray_concrete
fill 240 238 635 240 238 636 minecraft:light_gray_concrete
fill 240 238 639 242 238 639 minecraft:black_concrete
fill 240 238 640 242 245 642 minecraft:gray_concrete
fill 240 238 643 242 238 643 minecraft:black_concrete
fill 242 238 612 250 238 612 minecraft:light_gray_concrete
fill 242 238 638 249 238 638 minecraft:light_gray_concrete
fill 243 238 611 249 238 611 minecraft:light_gray_concrete
fill 243 238 639 269 238 639 minecraft:light_gray_concrete
fill 243 238 640 243 238 642 minecraft:black_concrete
fill 244 238 610 250 238 610 minecraft:light_gray_concrete
fill 244 238 640 268 238 640 minecraft:light_gray_concrete
fill 245 238 609 267 238 609 minecraft:light_gray_concrete
fill 245 238 623 245 239 625 minecraft:light_gray_concrete
fill 245 238 641 267 238 641 minecraft:light_gray_concrete
fill 246 238 621 246 238 622 minecraft:light_gray_concrete
fill 246 238 623 246 239 626 minecraft:gray_concrete
setblock 246 238 627 minecraft:light_gray_concrete
fill 247 238 608 265 238 608 minecraft:light_gray_concrete
setblock 247 238 620 minecraft:light_gray_concrete
fill 247 238 621 247 238 622 minecraft:gray_concrete
fill 247 238 627 247 238 628 minecraft:gray_concrete
fill 247 238 642 265 238 642 minecraft:light_gray_concrete
setblock 248 238 619 minecraft:light_gray_concrete
setblock 248 238 620 minecraft:gray_concrete
setblock 248 238 629 minecraft:gray_concrete
fill 248 238 630 248 238 632 minecraft:light_gray_concrete
fill 249 238 607 263 238 607 minecraft:light_gray_concrete
setblock 249 238 619 minecraft:gray_concrete
setblock 249 238 630 minecraft:gray_concrete
fill 249 238 631 249 238 632 minecraft:light_gray_concrete
fill 249 238 643 263 238 643 minecraft:light_gray_concrete
fill 250 238 616 251 238 617 minecraft:light_gray_concrete
fill 250 238 618 251 238 618 minecraft:gray_concrete
fill 250 238 631 251 238 631 minecraft:gray_concrete
fill 250 238 632 251 238 632 minecraft:light_gray_concrete
fill 251 238 613 271 238 613 minecraft:light_gray_concrete
fill 251 238 635 272 238 635 minecraft:light_gray_concrete
fill 252 238 605 276 239 605 minecraft:gray_concrete
fill 252 238 606 260 238 606 minecraft:light_gray_concrete
fill 252 238 610 268 238 610 minecraft:light_gray_concrete
fill 252 238 612 270 238 612 minecraft:light_gray_concrete
fill 252 238 616 273 238 616 minecraft:light_gray_concrete
fill 252 238 617 256 238 617 minecraft:gray_concrete
fill 252 238 632 257 238 632 minecraft:gray_concrete
fill 252 238 636 272 238 636 minecraft:light_gray_concrete
fill 252 238 638 270 238 638 minecraft:light_gray_concrete
fill 252 238 644 260 238 644 minecraft:light_gray_concrete
fill 252 238 645 276 239 645 minecraft:gray_concrete
fill 253 238 611 269 238 611 minecraft:light_gray_concrete
fill 253 238 637 271 238 637 minecraft:light_gray_concrete
fill 256 238 618 258 238 618 minecraft:gray_concrete
fill 256 238 631 258 238 631 minecraft:gray_concrete
fill 257 238 617 273 238 617 minecraft:light_gray_concrete
fill 258 238 619 259 238 619 minecraft:gray_concrete
fill 258 238 630 259 238 630 minecraft:gray_concrete
fill 258 238 632 274 238 632 minecraft:light_gray_concrete
fill 259 238 618 274 238 618 minecraft:light_gray_concrete
fill 259 238 620 260 238 620 minecraft:gray_concrete
fill 259 238 629 260 238 629 minecraft:gray_concrete
fill 259 238 631 274 238 631 minecraft:light_gray_concrete
fill 260 238 619 274 238 619 minecraft:light_gray_concrete
fill 260 238 621 261 238 622 minecraft:gray_concrete
fill 260 238 627 261 238 628 minecraft:gray_concrete
fill 260 238 630 274 238 630 minecraft:light_gray_concrete
fill 261 238 606 276 238 606 minecraft:gray_concrete
fill 261 238 620 274 238 620 minecraft:light_gray_concrete
fill 261 238 623 261 238 626 minecraft:gray_concrete
fill 261 238 629 275 238 629 minecraft:light_gray_concrete
fill 261 238 644 276 238 644 minecraft:gray_concrete
fill 262 238 614 272 238 615 minecraft:light_gray_concrete
fill 262 238 621 262 238 623 minecraft:light_gray_concrete
fill 262 238 624 262 238 625 minecraft:gray_concrete
fill 262 238 626 262 238 628 minecraft:light_gray_concrete
fill 262 238 633 273 238 634 minecraft:light_gray_concrete
fill 263 238 628 275 238 628 minecraft:light_gray_concrete
fill 264 238 622 275 238 622 minecraft:light_gray_concrete
fill 264 238 626 275 238 627 minecraft:light_gray_concrete
fill 265 238 623 275 238 623 minecraft:light_gray_concrete
fill 265 238 625 275 238 625 minecraft:light_gray_concrete
fill 266 238 624 275 238 624 minecraft:light_gray_concrete
fill 275 238 607 276 238 620 minecraft:gray_concrete
fill 275 238 630 276 238 643 minecraft:gray_concrete
fill 276 238 621 276 239 629 minecraft:gray_concrete
fill 237 239 605 251 239 605 minecraft:gray_concrete
fill 237 239 645 251 239 645 minecraft:gray_concrete
fill 238 239 620 240 239 622 minecraft:light_gray_concrete
fill 238 239 626 240 239 630 minecraft:light_gray_concrete
fill 239 239 617 240 239 619 minecraft:light_gray_concrete
fill 239 239 631 240 239 633 minecraft:light_gray_concrete
setblock 240 239 616 minecraft:light_gray_concrete
setblock 240 239 634 minecraft:light_gray_concrete
fill 242 239 613 270 239 613 minecraft:light_gray_concrete
fill 242 239 637 249 239 637 minecraft:light_gray_concrete
fill 243 239 612 250 239 612 minecraft:light_gray_concrete
fill 243 239 633 250 239 634 minecraft:light_gray_concrete
fill 243 239 638 249 239 638 minecraft:light_gray_concrete
fill 244 239 611 249 239 611 minecraft:light_gray_concrete
fill 244 239 639 268 239 639 minecraft:light_gray_concrete
fill 245 239 610 250 239 610 minecraft:light_gray_concrete
fill 245 239 640 267 239 640 minecraft:light_gray_concrete
fill 246 239 621 246 239 622 minecraft:gray_concrete
fill 246 239 627 246 239 628 minecraft:gray_concrete
fill 246 239 629 246 239 632 minecraft:light_gray_concrete
fill 247 239 609 265 239 609 minecraft:light_gray_concrete
setblock 247 239 620 minecraft:gray_concrete
setblock 247 239 629 minecraft:gray_concrete
fill 247 239 630 247 239 632 minecraft:light_gray_concrete
fill 247 239 641 265 239 641 minecraft:light_gray_concrete
fill 248 239 608 264 239 608 minecraft:light_gray_concrete
fill 248 239 616 248 239 618 minecraft:light_gray_concrete
setblock 248 239 619 minecraft:gray_concrete
fill 248 239 630 248 239 631 minecraft:gray_concrete
fill 248 239 632 249 239 632 minecraft:light_gray_concrete
fill 248 239 642 264 239 642 minecraft:light_gray_concrete
fill 249 239 616 249 239 617 minecraft:light_gray_concrete
setblock 249 239 618 minecraft:gray_concrete
setblock 249 239 631 minecraft:gray_concrete
fill 250 239 616 251 239 616 minecraft:light_gray_concrete
fill 250 239 617 251 239 617 minecraft:gray_concrete
fill 250 239 632 251 239 632 minecraft:gray_concrete
fill 251 239 607 261 239 607 minecraft:light_gray_concrete
fill 251 239 633 258 239 633 minecraft:gray_concrete
fill 251 239 634 259 239 635 minecraft:light_gray_concrete
fill 251 239 643 261 239 643 minecraft:light_gray_concrete
fill 252 239 610 267 239 610 minecraft:light_gray_concrete
fill 252 239 612 269 239 612 minecraft:light_gray_concrete
fill 252 239 616 257 239 616 minecraft:gray_concrete
fill 252 239 636 271 239 636 minecraft:light_gray_concrete
fill 252 239 638 269 239 638 minecraft:light_gray_concrete
fill 253 239 611 268 239 611 minecraft:light_gray_concrete
fill 253 239 637 270 239 637 minecraft:light_gray_concrete
fill 257 239 617 259 239 617 minecraft:gray_concrete
fill 258 239 616 272 239 616 minecraft:light_gray_concrete
fill 258 239 632 260 239 632 minecraft:gray_concrete
fill 259 239 618 260 239 618 minecraft:gray_concrete
fill 259 239 631 261 239 631 minecraft:gray_concrete
setblock 259 239 633 minecraft:light_gray_concrete
fill 260 239 617 273 239 617 minecraft:light_gray_concrete
fill 260 239 619 261 239 619 minecraft:gray_concrete
fill 260 239 630 262 239 630 minecraft:gray_concrete
fill 260 239 635 271 239 635 minecraft:light_gray_concrete
fill 261 239 618 273 239 618 minecraft:light_gray_concrete
fill 261 239 620 262 239 620 minecraft:gray_concrete
fill 261 239 629 262 239 629 minecraft:gray_concrete
fill 261 239 632 273 239 632 minecraft:light_gray_concrete
fill 262 239 614 271 239 615 minecraft:light_gray_concrete
fill 262 239 619 273 239 619 minecraft:light_gray_concrete
fill 262 239 621 262 239 623 minecraft:gray_concrete
fill 262 239 626 263 239 628 minecraft:gray_concrete
fill 262 239 631 273 239 631 minecraft:light_gray_concrete
fill 262 239 633 272 239 634 minecraft:light_gray_concrete
fill 263 239 620 274 239 621 minecraft:light_gray_concrete
fill 263 239 622 263 239 623 minecraft:gray_concrete
setblock 263 239 625 minecraft:gray_concrete
fill 263 239 629 274 239 630 minecraft:light_gray_concrete
fill 264 239 622 274 239 622 minecraft:light_gray_concrete
fill 264 239 626 274 239 628 minecraft:light_gray_concrete
fill 265 239 623 274 239 623 minecraft:light_gray_concrete
fill 265 239 625 274 239 625 minecraft:light_gray_concrete
fill 266 239 624 274 239 624 minecraft:light_gray_concrete
setblock 273 239 633 minecraft:light_gray_concrete
fill 276 239 606 276 239 620 minecraft:gray_concrete
fill 276 239 630 276 239 644 minecraft:gray_concrete
fill 236 240 611 236 273 612 minecraft:gray_concrete
fill 236 240 619 236 273 620 minecraft:gray_concrete
fill 236 240 627 236 273 628 minecraft:gray_concrete
fill 236 240 635 236 273 636 minecraft:gray_concrete
fill 236 240 643 236 273 644 minecraft:gray_concrete
fill 237 240 605 238 273 605 minecraft:gray_concrete
fill 239 240 620 242 240 623 minecraft:light_gray_concrete
fill 239 240 625 242 240 630 minecraft:light_gray_concrete
fill 240 240 617 244 240 619 minecraft:light_gray_concrete
fill 240 240 624 242 241 624 minecraft:light_gray_concrete
fill 240 240 631 240 240 633 minecraft:light_gray_concrete
fill 241 240 616 249 240 616 minecraft:light_gray_concrete
fill 241 240 631 246 240 632 minecraft:light_gray_concrete
fill 242 240 635 250 240 636 minecraft:light_gray_concrete
fill 242 240 645 243 273 645 minecraft:gray_concrete
fill 243 240 613 251 240 615 minecraft:light_gray_concrete
fill 243 240 620 243 242 622 minecraft:light_gray_concrete
fill 243 240 623 244 241 625 minecraft:cyan_concrete
fill 243 240 626 243 242 630 minecraft:light_gray_concrete
fill 243 240 633 248 240 634 minecraft:light_gray_concrete
fill 243 240 637 249 240 637 minecraft:light_gray_concrete
fill 244 240 612 250 240 612 minecraft:light_gray_concrete
fill 244 240 620 244 241 622 minecraft:cyan_concrete
fill 244 240 626 244 241 628 minecraft:cyan_concrete
fill 244 240 629 244 242 630 minecraft:light_gray_concrete
fill 244 240 638 249 240 638 minecraft:light_gray_concrete
fill 245 240 605 246 273 605 minecraft:gray_concrete
fill 245 240 611 249 240 611 minecraft:light_gray_concrete
fill 245 240 617 245 242 618 minecraft:light_gray_concrete
fill 245 240 619 245 241 620 minecraft:cyan_concrete
setblock 245 240 621 minecraft:light_gray_concrete
fill 245 240 622 245 240 627 minecraft:gold_block
fill 245 240 628 245 241 629 minecraft:cyan_concrete
fill 245 240 630 245 241 630 minecraft:light_gray_concrete
fill 245 240 639 267 240 639 minecraft:light_gray_concrete
fill 246 240 617 246 242 617 minecraft:light_gray_concrete
fill 246 240 618 246 241 619 minecraft:cyan_concrete
fill 246 240 620 246 240 621 minecraft:gold_block
setblock 246 240 628 minecraft:gold_block
fill 246 240 629 246 241 630 minecraft:cyan_concrete
fill 247 240 610 250 240 610 minecraft:light_gray_concrete
fill 247 240 617 247 241 618 minecraft:cyan_concrete
setblock 247 240 619 minecraft:gold_block
fill 247 240 630 247 241 631 minecraft:cyan_concrete
setblock 247 240 632 minecraft:light_gray_concrete
fill 247 240 640 265 240 640 minecraft:light_gray_concrete
fill 248 240 609 264 240 609 minecraft:light_gray_concrete
fill 248 240 617 255 241 617 minecraft:cyan_concrete
setblock 248 240 618 minecraft:gold_block
fill 248 240 631 255 241 631 minecraft:cyan_concrete
fill 248 240 632 249 240 632 minecraft:gold_block
fill 248 240 641 264 240 641 minecraft:light_gray_concrete
fill 249 240 633 250 240 633 minecraft:gold_block
fill 249 240 634 250 240 634 minecraft:light_gray_concrete
fill 250 240 616 252 241 616 minecraft:cyan_concrete
fill 250 240 632 252 241 632 minecraft:cyan_concrete
fill 250 240 645 251 273 645 minecraft:gray_concrete
fill 251 240 608 261 240 608 minecraft:light_gray_concrete
fill 251 240 634 259 240 634 minecraft:gold_block
fill 251 240 635 253 240 635 minecraft:light_gray_concrete
fill 251 240 642 261 240 642 minecraft:light_gray_concrete
fill 252 240 610 265 240 610 minecraft:light_gray_concrete
fill 252 240 612 259 240 614 minecraft:light_gray_concrete
fill 252 240 615 258 240 615 minecraft:gold_block
fill 252 240 636 270 240 636 minecraft:light_gray_concrete
fill 252 240 638 268 240 638 minecraft:light_gray_concrete
fill 253 240 605 254 273 605 minecraft:gray_concrete
fill 253 240 611 267 240 611 minecraft:light_gray_concrete
fill 253 240 637 269 240 637 minecraft:light_gray_concrete
fill 254 240 635 256 240 635 minecraft:gold_block
fill 255 240 618 256 241 618 minecraft:cyan_concrete
fill 255 240 630 256 241 630 minecraft:cyan_concrete
fill 256 240 619 257 241 619 minecraft:cyan_concrete
fill 256 240 629 257 241 629 minecraft:cyan_concrete
fill 257 240 620 258 241 620 minecraft:cyan_concrete
fill 257 240 628 258 241 628 minecraft:cyan_concrete
fill 257 240 635 270 240 635 minecraft:light_gray_concrete
fill 258 240 616 260 240 616 minecraft:gold_block
fill 258 240 621 258 241 627 minecraft:cyan_concrete
fill 258 240 645 259 273 645 minecraft:gray_concrete
setblock 259 240 615 minecraft:light_gray_concrete
fill 259 240 623 259 241 625 minecraft:cyan_concrete
setblock 259 240 633 minecraft:gold_block
fill 260 240 612 268 240 613 minecraft:light_gray_concrete
fill 260 240 617 261 240 617 minecraft:gold_block
fill 261 240 605 262 273 605 minecraft:gray_concrete
fill 261 240 616 271 240 616 minecraft:light_gray_concrete
fill 261 240 618 262 240 618 minecraft:gold_block
fill 261 240 632 262 240 632 minecraft:gold_block
fill 262 240 614 270 240 615 minecraft:light_gray_concrete
fill 262 240 617 272 240 617 minecraft:light_gray_concrete
fill 262 240 619 263 240 619 minecraft:gold_block
fill 262 240 631 263 240 631 minecraft:gold_block
fill 262 240 633 271 240 634 minecraft:light_gray_concrete
fill 263 240 618 272 240 618 minecraft:light_gray_concrete
fill 263 240 620 264 240 621 minecraft:gold_block
fill 263 240 629 264 240 630 minecraft:gold_block
fill 263 240 632 272 240 632 minecraft:light_gray_concrete
fill 264 240 619 272 240 619 minecraft:light_gray_concrete
fill 264 240 622 265 240 622 minecraft:gold_block
fill 264 240 626 264 240 628 minecraft:gold_block
fill 264 240 631 272 240 631 minecraft:light_gray_concrete
fill 265 240 620 273 240 621 minecraft:light_gray_concrete
setblock 265 240 623 minecraft:gold_block
fill 265 240 625 265 240 627 minecraft:gold_block
fill 265 240 628 273 240 630 minecraft:light_gray_concrete
fill 266 240 622 273 240 627 minecraft:light_gray_concrete
fill 266 240 645 267 273 645 minecraft:gray_concrete
fill 269 240 605 270 273 605 minecraft:gray_concrete
setblock 269 240 613 minecraft:light_gray_concrete
setblock 272 240 633 minecraft:light_gray_concrete
fill 274 240 645 275 273 645 minecraft:gray_concrete
fill 276 240 606 276 273 607 minecraft:gray_concrete
fill 276 240 614 276 273 615 minecraft:gray_concrete
fill 276 240 622 276 273 623 minecraft:gray_concrete
fill 276 240 630 276 273 631 minecraft:gray_concrete
fill 276 240 638 276 273 639 minecraft:gray_concrete
fill 240 241 620 242 241 623 minecraft:light_gray_concrete
fill 240 241 625 242 241 630 minecraft:light_gray_concrete
fill 241 241 618 244 241 619 minecraft:light_gray_concrete
fill 241 241 631 245 241 632 minecraft:light_gray_concrete
fill 242 241 616 244 241 617 minecraft:light_gray_concrete
fill 243 241 615 249 241 615 minecraft:light_gray_concrete
fill 243 241 633 247 241 635 minecraft:light_gray_concrete
fill 244 241 614 252 241 614 minecraft:light_gray_concrete
fill 244 241 636 250 241 636 minecraft:light_gray_concrete
fill 245 241 613 267 241 613 minecraft:light_gray_concrete
fill 245 241 616 248 241 616 minecraft:light_gray_concrete
fill 245 241 621 245 241 623 minecraft:gray_concrete
setblock 245 241 627 minecraft:gray_concrete
fill 245 241 637 249 241 637 minecraft:light_gray_concrete
fill 246 241 612 250 241 612 minecraft:light_gray_concrete
setblock 246 241 620 minecraft:gray_concrete
fill 246 241 631 246 242 631 minecraft:gray_concrete
setblock 246 241 632 minecraft:light_gray_concrete
fill 246 241 638 249 241 638 minecraft:light_gray_concrete
fill 247 241 611 249 241 611 minecraft:light_gray_concrete
setblock 247 241 632 minecraft:gray_concrete
fill 247 241 639 265 241 639 minecraft:light_gray_concrete
fill 247 241 640 247 242 640 minecraft:black_concrete
setblock 248 241 633 minecraft:gray_concrete
fill 248 241 634 248 241 635 minecraft:light_gray_concrete
fill 249 241 610 250 241 610 minecraft:light_gray_concrete
setblock 249 241 616 minecraft:gray_concrete
fill 249 241 634 250 241 634 minecraft:gray_concrete
fill 249 241 635 250 241 635 minecraft:light_gray_concrete
fill 249 241 640 263 241 640 minecraft:light_gray_concrete
fill 250 241 615 252 241 615 minecraft:gray_concrete
fill 251 241 609 261 241 609 minecraft:light_gray_concrete
fill 251 241 635 253 241 635 minecraft:gray_concrete
fill 251 241 641 261 241 641 minecraft:light_gray_concrete
fill 252 241 610 263 241 610 minecraft:light_gray_concrete
fill 252 241 612 266 241 612 minecraft:light_gray_concrete
setblock 252 241 636 minecraft:light_gray_concrete
fill 252 241 638 266 241 638 minecraft:light_gray_concrete
fill 253 241 611 265 241 611 minecraft:light_gray_concrete
fill 253 241 614 259 241 614 minecraft:gray_concrete
fill 253 241 636 258 241 636 minecraft:gray_concrete
fill 253 241 637 267 241 637 minecraft:light_gray_concrete
fill 257 241 635 261 241 635 minecraft:gray_concrete
setblock 259 241 615 minecraft:gray_concrete
fill 259 241 636 268 241 636 minecraft:light_gray_concrete
fill 261 241 616 262 241 616 minecraft:gray_concrete
fill 262 241 614 268 241 615 minecraft:light_gray_concrete
fill 262 241 617 263 241 617 minecraft:gray_concrete
fill 262 241 633 262 241 634 minecraft:gray_concrete
fill 262 241 635 269 241 635 minecraft:light_gray_concrete
fill 263 241 616 270 241 616 minecraft:light_gray_concrete
fill 263 241 618 264 241 618 minecraft:gray_concrete
fill 263 241 632 263 241 633 minecraft:gray_concrete
fill 263 241 634 270 241 634 minecraft:light_gray_concrete
fill 264 241 617 270 241 617 minecraft:light_gray_concrete
fill 264 241 619 265 241 619 minecraft:gray_concrete
fill 264 241 631 264 241 632 minecraft:gray_concrete
fill 264 241 633 270 241 633 minecraft:light_gray_concrete
fill 265 241 618 271 241 618 minecraft:light_gray_concrete
fill 265 241 620 266 241 621 minecraft:gray_concrete
fill 265 241 628 265 241 631 minecraft:gray_concrete
fill 265 241 632 271 241 632 minecraft:light_gray_concrete
fill 266 241 619 271 241 619 minecraft:light_gray_concrete
fill 266 241 622 266 241 629 minecraft:gray_concrete
fill 266 241 630 271 241 631 minecraft:light_gray_concrete
fill 267 241 620 272 241 623 minecraft:light_gray_concrete
fill 267 241 624 267 241 626 minecraft:gray_concrete
fill 267 241 627 272 241 629 minecraft:light_gray_concrete
fill 268 241 624 272 241 626 minecraft:light_gray_concrete
setblock 269 241 615 minecraft:light_gray_concrete
setblock 272 241 630 minecraft:light_gray_concrete
fill 235 242 604 241 307 604 minecraft:white_concrete
fill 235 242 609 235 247 609 minecraft:sea_lantern
fill 235 242 615 235 307 616 minecraft:white_concrete
fill 235 242 617 235 247 617 minecraft:sea_lantern
fill 235 242 625 235 247 625 minecraft:sea_lantern
fill 235 242 626 235 307 626 minecraft:white_concrete
fill 235 242 633 235 247 633 minecraft:sea_lantern
fill 235 242 634 235 307 635 minecraft:white_concrete
fill 235 242 638 235 307 640 minecraft:white_concrete
fill 235 242 641 235 247 641 minecraft:sea_lantern
fill 235 242 642 235 307 646 minecraft:white_concrete
fill 236 242 646 237 307 646 minecraft:white_concrete
fill 238 242 646 238 247 646 minecraft:sea_lantern
fill 241 242 623 242 242 627 minecraft:light_gray_concrete
fill 242 242 604 242 247 604 minecraft:sea_lantern
fill 242 242 620 242 242 622 minecraft:light_gray_concrete
fill 242 242 628 242 242 630 minecraft:light_gray_concrete
fill 243 242 604 247 307 604 minecraft:white_concrete
fill 243 242 618 244 242 619 minecraft:light_gray_concrete
fill 243 242 623 243 242 625 minecraft:light_gray_concrete
fill 243 242 631 245 242 632 minecraft:light_gray_concrete
fill 244 242 616 244 242 617 minecraft:light_gray_concrete
setblock 244 242 620 minecraft:light_gray_concrete
fill 244 242 621 244 242 628 minecraft:gray_concrete
fill 244 242 633 246 242 634 minecraft:light_gray_concrete
fill 244 242 646 245 307 646 minecraft:white_concrete
fill 245 242 615 247 242 616 minecraft:light_gray_concrete
fill 245 242 619 245 242 620 minecraft:gray_concrete
fill 245 242 629 245 242 630 minecraft:gray_concrete
fill 245 242 635 248 242 635 minecraft:light_gray_concrete
fill 246 242 614 250 242 614 minecraft:light_gray_concrete
setblock 246 242 618 minecraft:gray_concrete
setblock 246 242 632 minecraft:gray_concrete
fill 246 242 636 250 242 636 minecraft:light_gray_concrete
fill 246 242 646 246 247 646 minecraft:sea_lantern
fill 247 242 613 252 242 613 minecraft:light_gray_concrete
setblock 247 242 617 minecraft:gray_concrete
setblock 247 242 633 minecraft:gray_concrete
setblock 247 242 634 minecraft:light_gray_concrete
fill 247 242 637 249 242 637 minecraft:light_gray_concrete
fill 247 242 641 247 243 641 minecraft:black_concrete
fill 247 242 646 247 307 646 minecraft:white_concrete
setblock 248 242 615 minecraft:light_gray_concrete
setblock 248 242 616 minecraft:gray_concrete
setblock 248 242 634 minecraft:gray_concrete
fill 249 242 604 249 307 604 minecraft:white_concrete
fill 249 242 612 250 242 612 minecraft:light_gray_concrete
fill 249 242 615 250 242 615 minecraft:gray_concrete
fill 249 242 635 250 242 635 minecraft:gray_concrete
setblock 249 242 638 minecraft:light_gray_concrete
fill 249 242 646 253 307 646 minecraft:white_concrete
fill 250 242 604 250 247 604 minecraft:sea_lantern
fill 251 242 604 256 307 604 minecraft:white_concrete
fill 251 242 614 252 242 614 minecraft:gray_concrete
fill 251 242 639 261 242 639 minecraft:light_gray_concrete
fill 252 242 612 263 242 612 minecraft:light_gray_concrete
setblock 252 242 636 minecraft:gray_concrete
fill 252 242 638 263 242 638 minecraft:light_gray_concrete
fill 253 242 611 261 242 611 minecraft:light_gray_concrete
fill 253 242 613 259 242 613 minecraft:gray_concrete
fill 253 242 637 258 242 637 minecraft:gray_concrete
fill 254 242 610 258 242 610 minecraft:light_gray_concrete
fill 254 242 640 258 242 640 minecraft:light_gray_concrete
fill 254 242 646 254 247 646 minecraft:sea_lantern
fill 255 242 646 256 307 646 minecraft:white_concrete
fill 258 242 604 258 247 604 minecraft:sea_lantern
fill 258 242 641 258 243 641 minecraft:black_concrete
fill 259 242 604 261 307 604 minecraft:white_concrete
fill 259 242 636 261 242 636 minecraft:gray_concrete
fill 259 242 637 265 242 637 minecraft:light_gray_concrete
fill 260 242 608 260 242 609 minecraft:black_concrete
fill 260 242 613 265 242 613 minecraft:light_gray_concrete
fill 260 242 646 261 307 646 minecraft:white_concrete
fill 262 242 614 266 242 614 minecraft:light_gray_concrete
setblock 262 242 615 minecraft:gray_concrete
setblock 262 242 635 minecraft:gray_concrete
fill 262 242 636 266 242 636 minecraft:light_gray_concrete
fill 262 242 646 262 247 646 minecraft:sea_lantern
fill 263 242 615 267 242 615 minecraft:light_gray_concrete
setblock 263 242 616 minecraft:gray_concrete
setblock 263 242 634 minecraft:gray_concrete
fill 263 242 635 267 242 635 minecraft:light_gray_concrete
fill 263 242 646 263 307 646 minecraft:white_concrete
fill 264 242 616 268 242 616 minecraft:light_gray_concrete
setblock 264 242 617 minecraft:gray_concrete
setblock 264 242 633 minecraft:gray_concrete
fill 264 242 634 268 242 634 minecraft:light_gray_concrete
fill 265 242 617 268 242 617 minecraft:light_gray_concrete
setblock 265 242 618 minecraft:gray_concrete
setblock 265 242 632 minecraft:gray_concrete
fill 265 242 633 268 242 633 minecraft:light_gray_concrete
fill 266 242 604 266 247 604 minecraft:sea_lantern
fill 266 242 618 269 242 618 minecraft:light_gray_concrete
setblock 266 242 619 minecraft:gray_concrete
fill 266 242 630 266 242 631 minecraft:gray_concrete
fill 266 242 632 269 242 632 minecraft:light_gray_concrete
fill 267 242 619 269 242 619 minecraft:light_gray_concrete
fill 267 242 620 267 242 623 minecraft:gray_concrete
fill 267 242 627 267 242 629 minecraft:gray_concrete
fill 267 242 630 269 242 631 minecraft:light_gray_concrete
fill 268 242 620 270 242 623 minecraft:light_gray_concrete
fill 268 242 624 268 242 626 minecraft:gray_concrete
fill 268 242 627 270 242 629 minecraft:light_gray_concrete
fill 269 242 624 271 242 626 minecraft:light_gray_concrete
fill 269 242 646 269 307 646 minecraft:white_concrete
setblock 270 242 630 minecraft:light_gray_concrete
fill 270 242 646 270 247 646 minecraft:sea_lantern
fill 271 242 620 272 242 620 minecraft:black_concrete
setblock 271 242 623 minecraft:light_gray_concrete
setblock 271 242 627 minecraft:light_gray_concrete
fill 274 242 604 274 247 604 minecraft:sea_lantern
fill 275 242 604 277 307 604 minecraft:white_concrete
fill 277 242 607 277 307 608 minecraft:white_concrete
fill 277 242 609 277 247 609 minecraft:sea_lantern
fill 277 242 610 277 307 610 minecraft:white_concrete
fill 277 242 617 277 247 617 minecraft:sea_lantern
fill 277 242 618 277 307 621 minecraft:white_concrete
fill 277 242 625 277 247 625 minecraft:sea_lantern
fill 277 242 633 277 247 633 minecraft:sea_lantern
fill 277 242 634 277 307 640 minecraft:white_concrete
fill 277 242 641 277 247 641 minecraft:sea_lantern
setblock 238 243 607 minecraft:light[level=14]
setblock 238 243 615 minecraft:light[level=14]
setblock 238 243 631 minecraft:light[level=14]
setblock 238 243 639 minecraft:light[level=14]
setblock 246 243 607 minecraft:light[level=14]
setblock 246 243 615 minecraft:light[level=14]
setblock 246 243 623 minecraft:light[level=14]
setblock 246 243 631 minecraft:light[level=14]
setblock 246 243 639 minecraft:light[level=14]
fill 247 243 642 247 244 642 minecraft:black_concrete
setblock 254 243 607 minecraft:light[level=14]
setblock 254 243 615 minecraft:light[level=14]
setblock 254 243 623 minecraft:light[level=14]
setblock 254 243 631 minecraft:light[level=14]
setblock 254 243 639 minecraft:light[level=14]
fill 258 243 642 258 244 642 minecraft:black_concrete
fill 260 243 607 260 243 608 minecraft:black_concrete
setblock 262 243 607 minecraft:light[level=14]
setblock 262 243 615 minecraft:light[level=14]
setblock 262 243 623 minecraft:light[level=14]
setblock 262 243 631 minecraft:light[level=14]
setblock 262 243 639 minecraft:light[level=14]
fill 267 243 631 268 243 632 minecraft:white_concrete
setblock 270 243 607 minecraft:light[level=14]
setblock 270 243 615 minecraft:light[level=14]
setblock 270 243 623 minecraft:light[level=14]
setblock 270 243 631 minecraft:light[level=14]
setblock 270 243 639 minecraft:light[level=14]
fill 272 243 620 273 243 620 minecraft:black_concrete
fill 241 244 623 242 245 625 minecraft:lime_concrete
fill 242 244 620 242 245 622 minecraft:lime_concrete
fill 242 244 626 242 245 628 minecraft:lime_concrete
fill 243 244 618 243 245 620 minecraft:lime_concrete
fill 243 244 628 243 245 630 minecraft:lime_concrete
fill 244 244 617 244 245 618 minecraft:lime_concrete
fill 244 244 630 244 245 631 minecraft:lime_concrete
fill 245 244 616 245 245 617 minecraft:lime_concrete
fill 245 244 631 245 245 632 minecraft:lime_concrete
fill 246 244 616 247 245 616 minecraft:lime_concrete
fill 246 244 632 247 245 632 minecraft:lime_concrete
fill 247 244 615 255 245 615 minecraft:lime_concrete
fill 247 244 633 255 245 633 minecraft:lime_concrete
fill 247 244 643 247 245 643 minecraft:black_concrete
fill 250 244 614 252 245 614 minecraft:lime_concrete
fill 250 244 634 252 245 634 minecraft:lime_concrete
fill 255 244 616 257 245 616 minecraft:lime_concrete
fill 255 244 632 257 245 632 minecraft:lime_concrete
fill 257 244 617 258 245 617 minecraft:lime_concrete
fill 257 244 631 258 245 631 minecraft:lime_concrete
fill 258 244 618 259 245 618 minecraft:lime_concrete
fill 258 244 630 259 245 630 minecraft:lime_concrete
fill 258 244 643 258 245 643 minecraft:black_concrete
fill 259 244 619 259 245 620 minecraft:lime_concrete
fill 259 244 628 259 245 629 minecraft:lime_concrete
fill 260 244 606 260 244 607 minecraft:black_concrete
fill 260 244 620 260 245 628 minecraft:lime_concrete
fill 261 244 623 261 245 625 minecraft:lime_concrete
fill 273 244 620 274 244 620 minecraft:black_concrete
fill 247 245 605 247 246 607 minecraft:iron_block
fill 247 245 644 247 246 644 minecraft:black_concrete
fill 258 245 644 258 246 644 minecraft:black_concrete
fill 260 245 605 260 245 606 minecraft:black_concrete
fill 274 245 620 275 245 620 minecraft:black_concrete
fill 239 246 639 239 246 642 minecraft:black_concrete
setblock 240 246 611 minecraft:sea_lantern
setblock 240 246 617 minecraft:sea_lantern
setblock 240 246 623 minecraft:sea_lantern
setblock 240 246 629 minecraft:sea_lantern
setblock 240 246 635 minecraft:sea_lantern
fill 240 246 639 242 246 639 minecraft:black_concrete
fill 240 246 640 242 247 640 minecraft:gray_concrete
setblock 240 246 641 minecraft:sea_lantern
fill 240 246 642 242 273 642 minecraft:gray_concrete
fill 240 246 643 242 246 643 minecraft:black_concrete
fill 241 246 641 242 247 641 minecraft:gray_concrete
setblock 242 246 609 minecraft:sea_lantern
fill 243 246 640 243 246 642 minecraft:black_concrete
setblock 246 246 641 minecraft:sea_lantern
setblock 248 246 609 minecraft:sea_lantern
setblock 252 246 641 minecraft:sea_lantern
setblock 254 246 609 minecraft:sea_lantern
setblock 258 246 641 minecraft:sea_lantern
setblock 260 246 605 minecraft:black_concrete
setblock 260 246 609 minecraft:sea_lantern
setblock 264 246 641 minecraft:sea_lantern
setblock 266 246 609 minecraft:sea_lantern
setblock 270 246 641 minecraft:sea_lantern
setblock 272 246 609 minecraft:sea_lantern
setblock 272 246 615 minecraft:sea_lantern
setblock 272 246 621 minecraft:sea_lantern
setblock 272 246 627 minecraft:sea_lantern
setblock 272 246 633 minecraft:sea_lantern
setblock 272 246 639 minecraft:sea_lantern
setblock 275 246 620 minecraft:black_concrete
fill 236 247 605 236 247 610 minecraft:gray_concrete
fill 236 247 613 240 247 618 minecraft:gray_concrete
fill 236 247 621 236 247 626 minecraft:gray_concrete
fill 236 247 629 240 247 634 minecraft:gray_concrete
fill 236 247 637 239 247 642 minecraft:gray_concrete
fill 236 247 645 241 247 645 minecraft:gray_concrete
fill 237 247 606 240 247 612 minecraft:gray_concrete
fill 237 247 619 237 247 623 minecraft:gray_concrete
fill 237 247 625 237 247 628 minecraft:gray_concrete
fill 237 247 635 240 247 636 minecraft:gray_concrete
fill 237 247 643 276 247 644 minecraft:gray_concrete
fill 238 247 619 240 247 622 minecraft:gray_concrete
fill 238 247 626 240 247 628 minecraft:gray_concrete
fill 239 247 605 244 247 605 minecraft:gray_concrete
fill 239 247 623 240 247 623 minecraft:gray_concrete
fill 239 247 625 240 247 625 minecraft:gray_concrete
setblock 240 247 624 minecraft:gray_concrete
fill 240 247 637 240 247 639 minecraft:gray_concrete
setblock 240 247 641 minecraft:gray_concrete
fill 241 247 606 275 247 609 minecraft:gray_concrete
fill 243 247 641 276 247 642 minecraft:gray_concrete
fill 244 247 645 249 247 645 minecraft:gray_concrete
fill 247 247 605 252 247 605 minecraft:gray_concrete
fill 252 247 645 257 247 645 minecraft:gray_concrete
fill 255 247 605 260 247 605 minecraft:gray_concrete
fill 260 247 645 265 247 645 minecraft:gray_concrete
fill 263 247 605 268 247 605 minecraft:gray_concrete
fill 268 247 645 273 247 645 minecraft:gray_concrete
fill 271 247 605 276 247 605 minecraft:gray_concrete
fill 272 247 610 275 247 640 minecraft:gray_concrete
fill 276 247 608 276 247 613 minecraft:gray_concrete
fill 276 247 616 276 247 621 minecraft:gray_concrete
fill 276 247 624 276 247 629 minecraft:gray_concrete
fill 276 247 632 276 247 637 minecraft:gray_concrete
setblock 276 247 640 minecraft:gray_concrete
setblock 276 247 645 minecraft:gray_concrete
fill 235 248 609 235 255 609 minecraft:white_concrete
fill 235 248 617 235 255 617 minecraft:white_concrete
fill 235 248 625 235 255 625 minecraft:white_concrete
fill 235 248 633 235 255 633 minecraft:white_concrete
fill 235 248 641 235 255 641 minecraft:white_concrete
fill 238 248 646 238 255 646 minecraft:white_concrete
fill 240 248 609 240 248 641 minecraft:gold_block
fill 241 248 609 272 248 609 minecraft:gold_block
fill 241 248 640 242 273 640 minecraft:gray_concrete
fill 241 248 641 272 248 641 minecraft:gold_block
fill 242 248 604 242 255 604 minecraft:white_concrete
fill 246 248 646 246 255 646 minecraft:white_concrete
fill 250 248 604 250 255 604 minecraft:white_concrete
fill 254 248 646 254 255 646 minecraft:white_concrete
fill 258 248 604 258 255 604 minecraft:white_concrete
fill 262 248 646 262 255 646 minecraft:white_concrete
fill 266 248 604 266 255 604 minecraft:white_concrete
fill 270 248 646 270 255 646 minecraft:white_concrete
fill 272 248 610 272 248 640 minecraft:gold_block
fill 274 248 604 274 255 604 minecraft:white_concrete
fill 277 248 609 277 255 609 minecraft:white_concrete
fill 277 248 617 277 255 617 minecraft:white_concrete
fill 277 248 625 277 255 625 minecraft:white_concrete
fill 277 248 633 277 255 633 minecraft:white_concrete
fill 277 248 641 277 255 641 minecraft:white_concrete
fill 240 249 640 240 273 641 minecraft:gray_concrete
fill 241 249 641 242 273 641 minecraft:gray_concrete
fill 237 250 624 239 250 624 minecraft:glowstone
setblock 238 250 623 minecraft:glowstone
setblock 238 250 625 minecraft:glowstone
fill 241 250 614 242 250 615 minecraft:glowstone
fill 241 250 633 242 250 634 minecraft:glowstone
setblock 242 250 616 minecraft:glowstone
setblock 242 250 632 minecraft:glowstone
setblock 243 250 615 minecraft:glowstone
setblock 243 250 633 minecraft:glowstone
fill 250 250 611 252 250 611 minecraft:glowstone
fill 250 250 637 252 250 637 minecraft:glowstone
setblock 251 250 610 minecraft:glowstone
setblock 251 250 612 minecraft:glowstone
setblock 251 250 636 minecraft:glowstone
setblock 251 250 638 minecraft:glowstone
fill 259 250 615 261 250 615 minecraft:glowstone
fill 259 250 633 261 250 633 minecraft:glowstone
fill 260 250 614 261 250 614 minecraft:glowstone
setblock 260 250 616 minecraft:glowstone
setblock 260 250 632 minecraft:glowstone
fill 260 250 634 261 250 634 minecraft:glowstone
fill 263 250 624 265 250 624 minecraft:glowstone
setblock 264 250 623 minecraft:glowstone
setblock 264 250 625 minecraft:glowstone
setblock 238 251 607 minecraft:light[level=14]
setblock 238 251 615 minecraft:light[level=14]
setblock 238 251 623 minecraft:light[level=14]
setblock 238 251 631 minecraft:light[level=14]
setblock 238 251 639 minecraft:light[level=14]
setblock 246 251 607 minecraft:light[level=14]
setblock 246 251 615 minecraft:light[level=14]
setblock 246 251 623 minecraft:light[level=14]
setblock 246 251 631 minecraft:light[level=14]
setblock 246 251 639 minecraft:light[level=14]
fill 251 251 613 251 252 614 minecraft:white_concrete
setblock 254 251 607 minecraft:light[level=14]
setblock 254 251 615 minecraft:light[level=14]
setblock 254 251 623 minecraft:light[level=14]
setblock 254 251 631 minecraft:light[level=14]
setblock 254 251 639 minecraft:light[level=14]
setblock 262 251 607 minecraft:light[level=14]
setblock 262 251 615 minecraft:light[level=14]
setblock 262 251 623 minecraft:light[level=14]
setblock 262 251 631 minecraft:light[level=14]
setblock 262 251 639 minecraft:light[level=14]
setblock 270 251 607 minecraft:light[level=14]
setblock 270 251 615 minecraft:light[level=14]
setblock 270 251 623 minecraft:light[level=14]
setblock 270 251 631 minecraft:light[level=14]
setblock 270 251 639 minecraft:light[level=14]
fill 236 252 605 236 253 610 minecraft:gray_concrete
fill 236 252 613 237 252 618 minecraft:gray_concrete
fill 236 252 621 237 252 626 minecraft:gray_concrete
fill 236 252 629 237 252 634 minecraft:gray_concrete
fill 236 252 637 237 252 642 minecraft:gray_concrete
fill 236 252 645 241 253 645 minecraft:gray_concrete
fill 237 252 606 237 252 612 minecraft:gray_concrete
fill 237 252 619 237 252 620 minecraft:gray_concrete
fill 237 252 627 237 252 628 minecraft:gray_concrete
fill 237 252 635 237 252 636 minecraft:gray_concrete
fill 237 252 643 237 252 644 minecraft:gray_concrete
fill 238 252 606 275 252 606 minecraft:gray_concrete
fill 238 252 644 276 252 644 minecraft:gray_concrete
fill 239 252 605 244 253 605 minecraft:gray_concrete
fill 244 252 645 249 253 645 minecraft:gray_concrete
fill 247 252 605 252 253 605 minecraft:gray_concrete
fill 252 252 645 257 253 645 minecraft:gray_concrete
fill 255 252 605 260 253 605 minecraft:gray_concrete
fill 260 252 645 265 253 645 minecraft:gray_concrete
fill 263 252 605 268 253 605 minecraft:gray_concrete
fill 268 252 645 273 253 645 minecraft:gray_concrete
fill 271 252 605 276 253 605 minecraft:gray_concrete
fill 275 252 607 275 252 643 minecraft:gray_concrete
fill 276 252 608 276 253 613 minecraft:gray_concrete
fill 276 252 616 276 253 621 minecraft:gray_concrete
fill 276 252 624 276 253 629 minecraft:gray_concrete
fill 276 252 632 276 253 637 minecraft:gray_concrete
fill 276 252 640 276 253 643 minecraft:gray_concrete
fill 276 252 645 276 253 645 minecraft:gray_concrete
fill 236 253 613 236 253 618 minecraft:gray_concrete
fill 236 253 621 236 253 626 minecraft:gray_concrete
fill 236 253 629 236 253 634 minecraft:gray_concrete
fill 236 253 637 236 253 642 minecraft:gray_concrete
setblock 276 253 644 minecraft:gray_concrete
fill 239 254 639 239 254 642 minecraft:black_concrete
fill 240 254 639 242 254 639 minecraft:black_concrete
fill 240 254 643 242 254 643 minecraft:black_concrete
fill 243 254 640 243 254 642 minecraft:black_concrete
fill 235 256 609 235 261 609 minecraft:sea_lantern
fill 235 256 617 235 261 617 minecraft:sea_lantern
fill 235 256 625 235 261 625 minecraft:sea_lantern
fill 235 256 633 235 261 633 minecraft:sea_lantern
fill 235 256 641 235 261 641 minecraft:sea_lantern
fill 238 256 646 238 261 646 minecraft:sea_lantern
fill 242 256 604 242 261 604 minecraft:sea_lantern
fill 246 256 646 246 261 646 minecraft:sea_lantern
fill 250 256 604 250 261 604 minecraft:sea_lantern
fill 254 256 646 254 261 646 minecraft:sea_lantern
fill 258 256 604 258 261 604 minecraft:sea_lantern
fill 262 256 646 262 261 646 minecraft:sea_lantern
fill 266 256 604 266 261 604 minecraft:sea_lantern
fill 270 256 646 270 261 646 minecraft:sea_lantern
fill 274 256 604 274 261 604 minecraft:sea_lantern
fill 277 256 609 277 261 609 minecraft:sea_lantern
fill 277 256 617 277 261 617 minecraft:sea_lantern
fill 277 256 625 277 261 625 minecraft:sea_lantern
fill 277 256 633 277 261 633 minecraft:sea_lantern
fill 277 256 641 277 261 641 minecraft:sea_lantern
fill 262 257 606 262 258 607 minecraft:iron_block
setblock 238 259 607 minecraft:light[level=14]
setblock 238 259 615 minecraft:light[level=14]
setblock 238 259 623 minecraft:light[level=14]
setblock 238 259 631 minecraft:light[level=14]
setblock 238 259 639 minecraft:light[level=14]
setblock 246 259 607 minecraft:light[level=14]
setblock 246 259 615 minecraft:light[level=14]
setblock 246 259 623 minecraft:light[level=14]
setblock 246 259 631 minecraft:light[level=14]
setblock 246 259 639 minecraft:light[level=14]
setblock 254 259 607 minecraft:light[level=14]
setblock 254 259 615 minecraft:light[level=14]
setblock 254 259 623 minecraft:light[level=14]
setblock 254 259 631 minecraft:light[level=14]
setblock 254 259 639 minecraft:light[level=14]
setblock 262 259 607 minecraft:light[level=14]
setblock 262 259 615 minecraft:light[level=14]
setblock 262 259 623 minecraft:light[level=14]
setblock 262 259 631 minecraft:light[level=14]
setblock 262 259 639 minecraft:light[level=14]
setblock 270 259 607 minecraft:light[level=14]
setblock 270 259 615 minecraft:light[level=14]
setblock 270 259 623 minecraft:light[level=14]
setblock 270 259 631 minecraft:light[level=14]
setblock 270 259 639 minecraft:light[level=14]
fill 235 262 609 235 269 609 minecraft:white_concrete
fill 235 262 617 235 269 617 minecraft:white_concrete
fill 235 262 625 235 269 625 minecraft:white_concrete
fill 235 262 633 235 269 633 minecraft:white_concrete
fill 235 262 641 235 269 641 minecraft:white_concrete
fill 238 262 646 238 269 646 minecraft:white_concrete
fill 239 262 639 239 262 642 minecraft:black_concrete
fill 240 262 639 242 262 639 minecraft:black_concrete
fill 240 262 643 242 262 643 minecraft:black_concrete
fill 242 262 604 242 269 604 minecraft:white_concrete
fill 243 262 640 243 262 642 minecraft:black_concrete
fill 246 262 646 246 269 646 minecraft:white_concrete
fill 250 262 604 250 269 604 minecraft:white_concrete
fill 254 262 646 254 269 646 minecraft:white_concrete
fill 258 262 604 258 269 604 minecraft:white_concrete
fill 262 262 646 262 269 646 minecraft:white_concrete
fill 266 262 604 266 269 604 minecraft:white_concrete
fill 270 262 646 270 269 646 minecraft:white_concrete
fill 274 262 604 274 269 604 minecraft:white_concrete
fill 277 262 609 277 269 609 minecraft:white_concrete
fill 277 262 617 277 269 617 minecraft:white_concrete
fill 277 262 625 277 269 625 minecraft:white_concrete
fill 277 262 633 277 269 633 minecraft:white_concrete
fill 277 262 641 277 269 641 minecraft:white_concrete
fill 236 266 605 236 267 610 minecraft:gray_concrete
fill 236 266 613 237 266 618 minecraft:gray_concrete
fill 236 266 621 237 266 626 minecraft:gray_concrete
fill 236 266 629 237 266 634 minecraft:gray_concrete
fill 236 266 637 237 266 642 minecraft:gray_concrete
fill 236 266 645 241 267 645 minecraft:gray_concrete
fill 237 266 606 237 266 612 minecraft:gray_concrete
fill 237 266 619 237 266 620 minecraft:gray_concrete
fill 237 266 627 237 266 628 minecraft:gray_concrete
fill 237 266 635 237 266 636 minecraft:gray_concrete
fill 237 266 643 237 266 644 minecraft:gray_concrete
fill 238 266 606 275 266 606 minecraft:gray_concrete
fill 238 266 644 276 266 644 minecraft:gray_concrete
fill 239 266 605 244 267 605 minecraft:gray_concrete
fill 244 266 645 249 267 645 minecraft:gray_concrete
fill 247 266 605 252 267 605 minecraft:gray_concrete
fill 252 266 645 257 267 645 minecraft:gray_concrete
fill 255 266 605 260 267 605 minecraft:gray_concrete
fill 260 266 645 265 267 645 minecraft:gray_concrete
fill 263 266 605 268 267 605 minecraft:gray_concrete
fill 268 266 645 273 267 645 minecraft:gray_concrete
fill 271 266 605 276 267 605 minecraft:gray_concrete
fill 275 266 607 275 266 643 minecraft:gray_concrete
fill 276 266 608 276 267 613 minecraft:gray_concrete
fill 276 266 616 276 267 621 minecraft:gray_concrete
fill 276 266 624 276 267 629 minecraft:gray_concrete
fill 276 266 632 276 267 637 minecraft:gray_concrete
fill 276 266 640 276 267 643 minecraft:gray_concrete
fill 276 266 645 276 267 645 minecraft:gray_concrete
fill 236 267 613 236 267 618 minecraft:gray_concrete
fill 236 267 621 236 267 626 minecraft:gray_concrete
fill 236 267 629 236 267 634 minecraft:gray_concrete
fill 236 267 637 236 267 642 minecraft:gray_concrete
setblock 238 267 607 minecraft:light[level=14]
setblock 238 267 615 minecraft:light[level=14]
setblock 238 267 623 minecraft:light[level=14]
setblock 238 267 631 minecraft:light[level=14]
setblock 238 267 639 minecraft:light[level=14]
setblock 246 267 607 minecraft:light[level=14]
setblock 246 267 615 minecraft:light[level=14]
setblock 246 267 623 minecraft:light[level=14]
setblock 246 267 631 minecraft:light[level=14]
setblock 246 267 639 minecraft:light[level=14]
setblock 254 267 607 minecraft:light[level=14]
setblock 254 267 615 minecraft:light[level=14]
setblock 254 267 623 minecraft:light[level=14]
setblock 254 267 631 minecraft:light[level=14]
setblock 254 267 639 minecraft:light[level=14]
setblock 262 267 607 minecraft:light[level=14]
setblock 262 267 615 minecraft:light[level=14]
setblock 262 267 623 minecraft:light[level=14]
setblock 262 267 631 minecraft:light[level=14]
setblock 262 267 639 minecraft:light[level=14]
setblock 270 267 607 minecraft:light[level=14]
setblock 270 267 615 minecraft:light[level=14]
setblock 270 267 623 minecraft:light[level=14]
setblock 270 267 631 minecraft:light[level=14]
setblock 270 267 639 minecraft:light[level=14]
setblock 276 267 644 minecraft:gray_concrete
fill 235 270 609 235 273 609 minecraft:sea_lantern
fill 235 270 617 235 273 617 minecraft:sea_lantern
fill 235 270 625 235 273 625 minecraft:sea_lantern
fill 235 270 633 235 273 633 minecraft:sea_lantern
fill 235 270 641 235 273 641 minecraft:sea_lantern
fill 238 270 646 238 273 646 minecraft:sea_lantern
fill 239 270 639 239 270 642 minecraft:black_concrete
fill 240 270 639 242 270 639 minecraft:black_concrete
fill 240 270 643 242 270 643 minecraft:black_concrete
fill 242 270 604 242 273 604 minecraft:sea_lantern
fill 243 270 640 243 270 642 minecraft:black_concrete
fill 246 270 646 246 273 646 minecraft:sea_lantern
fill 250 270 604 250 273 604 minecraft:sea_lantern
fill 254 270 646 254 273 646 minecraft:sea_lantern
fill 258 270 604 258 273 604 minecraft:sea_lantern
fill 262 270 646 262 273 646 minecraft:sea_lantern
fill 266 270 604 266 273 604 minecraft:sea_lantern
fill 270 270 646 270 273 646 minecraft:sea_lantern
fill 274 270 604 274 273 604 minecraft:sea_lantern
fill 277 270 609 277 273 609 minecraft:sea_lantern
fill 277 270 617 277 273 617 minecraft:sea_lantern
fill 277 270 625 277 273 625 minecraft:sea_lantern
fill 277 270 633 277 273 633 minecraft:sea_lantern
fill 277 270 641 277 273 641 minecraft:sea_lantern
fill 239 272 640 239 273 642 minecraft:gold_block
fill 240 272 639 242 273 639 minecraft:gold_block
fill 240 272 643 241 273 643 minecraft:gold_block
fill 243 272 640 243 273 641 minecraft:gold_block
fill 265 272 629 267 273 630 minecraft:gold_block
fill 235 274 609 235 283 609 minecraft:white_concrete
fill 235 274 617 235 283 617 minecraft:white_concrete
fill 235 274 625 235 283 625 minecraft:white_concrete
fill 235 274 633 235 283 633 minecraft:white_concrete
fill 235 274 641 235 283 641 minecraft:white_concrete
fill 238 274 646 238 283 646 minecraft:white_concrete
fill 242 274 604 242 283 604 minecraft:white_concrete
fill 246 274 646 246 283 646 minecraft:white_concrete
fill 250 274 604 250 283 604 minecraft:white_concrete
fill 254 274 646 254 283 646 minecraft:white_concrete
fill 258 274 604 258 283 604 minecraft:white_concrete
fill 262 274 646 262 283 646 minecraft:white_concrete
fill 266 274 604 266 283 604 minecraft:white_concrete
fill 270 274 646 270 283 646 minecraft:white_concrete
fill 274 274 604 274 283 604 minecraft:white_concrete
fill 277 274 609 277 283 609 minecraft:white_concrete
fill 277 274 617 277 283 617 minecraft:white_concrete
fill 277 274 625 277 283 625 minecraft:white_concrete
fill 277 274 633 277 283 633 minecraft:white_concrete
fill 277 274 641 277 283 641 minecraft:white_concrete
setblock 238 275 607 minecraft:light[level=14]
setblock 238 275 615 minecraft:light[level=14]
setblock 238 275 623 minecraft:light[level=14]
setblock 238 275 631 minecraft:light[level=14]
setblock 238 275 639 minecraft:light[level=14]
setblock 246 275 607 minecraft:light[level=14]
setblock 246 275 615 minecraft:light[level=14]
setblock 246 275 623 minecraft:light[level=14]
setblock 246 275 631 minecraft:light[level=14]
setblock 246 275 639 minecraft:light[level=14]
setblock 254 275 607 minecraft:light[level=14]
setblock 254 275 615 minecraft:light[level=14]
setblock 254 275 623 minecraft:light[level=14]
setblock 254 275 631 minecraft:light[level=14]
setblock 254 275 639 minecraft:light[level=14]
setblock 262 275 607 minecraft:light[level=14]
setblock 262 275 615 minecraft:light[level=14]
setblock 262 275 623 minecraft:light[level=14]
setblock 262 275 631 minecraft:light[level=14]
setblock 262 275 639 minecraft:light[level=14]
setblock 270 275 607 minecraft:light[level=14]
setblock 270 275 615 minecraft:light[level=14]
setblock 270 275 623 minecraft:light[level=14]
setblock 270 275 631 minecraft:light[level=14]
setblock 270 275 639 minecraft:light[level=14]
fill 247 278 623 249 278 625 minecraft:redstone_block
fill 255 278 627 257 278 629 minecraft:redstone_block
fill 256 278 620 258 278 622 minecraft:redstone_block
fill 236 279 609 246 279 641 minecraft:white_concrete
fill 237 279 608 275 280 608 minecraft:white_concrete
fill 237 279 642 275 280 642 minecraft:white_concrete
fill 238 279 607 274 280 607 minecraft:white_concrete
fill 238 279 643 274 280 643 minecraft:white_concrete
fill 239 279 606 273 280 606 minecraft:white_concrete
fill 239 279 644 273 280 644 minecraft:white_concrete
fill 240 279 605 272 280 605 minecraft:white_concrete
fill 240 279 645 272 280 645 minecraft:white_concrete
fill 247 279 609 251 279 622 minecraft:white_concrete
fill 247 279 626 251 279 641 minecraft:white_concrete
fill 250 279 623 250 279 625 minecraft:white_concrete
fill 251 279 623 251 279 625 minecraft:gold_block
fill 252 279 609 255 279 621 minecraft:white_concrete
fill 252 279 622 254 279 622 minecraft:gold_block
fill 252 279 626 254 279 626 minecraft:gold_block
fill 252 279 627 254 279 641 minecraft:white_concrete
setblock 255 279 622 minecraft:white_concrete
fill 255 279 623 255 279 625 minecraft:gold_block
fill 255 279 626 276 279 626 minecraft:white_concrete
fill 255 279 630 276 279 641 minecraft:white_concrete
fill 256 279 609 276 279 619 minecraft:white_concrete
fill 256 279 623 276 279 625 minecraft:white_concrete
fill 258 279 627 276 279 629 minecraft:white_concrete
fill 259 279 620 276 279 622 minecraft:white_concrete
fill 236 280 605 236 280 645 minecraft:white_concrete
fill 237 280 605 237 280 607 minecraft:white_concrete
fill 237 280 609 245 280 641 minecraft:white_concrete
fill 237 280 643 237 280 645 minecraft:white_concrete
fill 238 280 605 238 280 606 minecraft:white_concrete
fill 238 280 644 238 280 645 minecraft:white_concrete
setblock 239 280 605 minecraft:white_concrete
setblock 239 280 645 minecraft:white_concrete
fill 246 280 609 251 280 621 minecraft:white_concrete
fill 246 280 622 246 280 626 minecraft:sea_lantern
fill 246 280 627 250 280 641 minecraft:white_concrete
fill 247 280 622 255 280 622 minecraft:sea_lantern
fill 247 280 623 249 280 625 minecraft:white_concrete
fill 247 280 626 258 280 626 minecraft:sea_lantern
fill 250 280 623 251 280 625 minecraft:sea_lantern
fill 251 280 627 253 280 627 minecraft:light_gray_concrete
fill 251 280 628 252 280 641 minecraft:white_concrete
fill 252 280 609 254 280 620 minecraft:white_concrete
fill 252 280 621 254 280 621 minecraft:light_gray_concrete
setblock 253 280 628 minecraft:light_gray_concrete
fill 253 280 629 253 280 641 minecraft:white_concrete
fill 254 280 627 254 280 630 minecraft:sea_lantern
fill 254 280 631 276 280 641 minecraft:white_concrete
fill 255 280 609 276 280 618 minecraft:white_concrete
fill 255 280 619 255 280 621 minecraft:sea_lantern
fill 255 280 623 255 280 625 minecraft:sea_lantern
fill 255 280 627 257 280 629 minecraft:white_concrete
fill 255 280 630 258 280 630 minecraft:sea_lantern
fill 256 280 619 259 280 619 minecraft:sea_lantern
fill 256 280 620 258 280 622 minecraft:white_concrete
fill 256 280 623 259 280 623 minecraft:sea_lantern
fill 256 280 624 257 280 625 minecraft:light_gray_concrete
fill 258 280 624 276 280 625 minecraft:white_concrete
fill 258 280 627 258 280 629 minecraft:sea_lantern
fill 259 280 620 259 280 622 minecraft:sea_lantern
fill 259 280 626 276 281 630 minecraft:white_concrete
fill 260 280 619 276 281 623 minecraft:white_concrete
fill 273 280 605 276 280 605 minecraft:white_concrete
fill 273 280 645 276 280 645 minecraft:white_concrete
fill 274 280 606 276 280 606 minecraft:white_concrete
fill 274 280 644 276 280 644 minecraft:white_concrete
fill 275 280 607 276 280 607 minecraft:white_concrete
fill 275 280 643 276 280 643 minecraft:white_concrete
setblock 276 280 608 minecraft:white_concrete
setblock 276 280 642 minecraft:white_concrete
fill 236 281 611 248 281 639 minecraft:white_concrete
fill 237 281 610 275 281 610 minecraft:white_concrete
fill 237 281 640 275 281 640 minecraft:white_concrete
fill 238 281 609 274 281 609 minecraft:white_concrete
fill 238 281 641 274 281 641 minecraft:white_concrete
fill 239 281 608 273 281 608 minecraft:white_concrete
fill 239 281 642 273 281 642 minecraft:white_concrete
fill 240 281 607 272 281 607 minecraft:white_concrete
fill 240 281 643 272 281 643 minecraft:white_concrete
fill 241 281 606 271 281 606 minecraft:white_concrete
fill 241 281 644 271 281 644 minecraft:white_concrete
fill 242 281 605 270 281 605 minecraft:white_concrete
fill 242 281 645 270 281 645 minecraft:white_concrete
fill 249 281 611 249 281 621 minecraft:white_concrete
fill 249 281 622 249 281 626 minecraft:light_gray_concrete
fill 249 281 627 249 281 639 minecraft:white_concrete
fill 250 281 611 250 281 620 minecraft:white_concrete
fill 250 281 621 250 281 622 minecraft:light_gray_concrete
fill 250 281 626 250 281 628 minecraft:light_gray_concrete
fill 250 281 629 251 281 639 minecraft:white_concrete
fill 251 281 611 252 281 619 minecraft:white_concrete
fill 251 281 620 251 281 621 minecraft:light_gray_concrete
fill 251 281 628 252 281 628 minecraft:light_gray_concrete
fill 252 281 620 257 281 620 minecraft:light_gray_concrete
fill 252 281 629 256 281 629 minecraft:light_gray_concrete
fill 252 281 630 258 281 639 minecraft:white_concrete
fill 253 281 611 276 281 618 minecraft:white_concrete
fill 253 281 619 254 281 619 minecraft:light_gray_concrete
fill 255 281 619 259 281 619 minecraft:white_concrete
fill 255 281 628 257 281 628 minecraft:light_gray_concrete
fill 256 281 621 258 281 621 minecraft:light_gray_concrete
fill 257 281 622 258 281 622 minecraft:light_gray_concrete
fill 257 281 626 258 281 627 minecraft:light_gray_concrete
fill 257 281 629 258 281 629 minecraft:white_concrete
fill 258 281 620 259 281 620 minecraft:white_concrete
fill 258 281 623 259 281 625 minecraft:light_gray_concrete
setblock 258 281 628 minecraft:white_concrete
fill 259 281 621 259 281 622 minecraft:white_concrete
fill 259 281 631 276 281 639 minecraft:white_concrete
fill 260 281 624 276 281 625 minecraft:white_concrete
fill 236 282 612 247 282 638 minecraft:white_concrete
fill 237 282 611 275 282 611 minecraft:white_concrete
fill 237 282 639 275 282 639 minecraft:white_concrete
fill 238 282 610 274 282 610 minecraft:white_concrete
fill 238 282 640 274 282 640 minecraft:white_concrete
fill 239 282 609 273 282 609 minecraft:white_concrete
fill 239 282 641 273 282 641 minecraft:white_concrete
fill 240 282 608 272 282 608 minecraft:white_concrete
fill 240 282 642 272 282 642 minecraft:white_concrete
fill 241 282 607 271 282 607 minecraft:white_concrete
fill 241 282 643 271 282 643 minecraft:white_concrete
fill 242 282 606 270 282 606 minecraft:white_concrete
fill 242 282 644 270 282 644 minecraft:white_concrete
fill 243 282 605 269 282 605 minecraft:white_concrete
fill 243 282 645 269 282 645 minecraft:white_concrete
fill 248 282 612 248 282 621 minecraft:white_concrete
fill 248 282 622 248 282 627 minecraft:gold_block
fill 248 282 628 248 282 638 minecraft:white_concrete
fill 249 282 612 249 282 619 minecraft:white_concrete
fill 249 282 620 249 282 621 minecraft:gold_block
fill 249 282 627 249 282 628 minecraft:gold_block
fill 249 282 629 249 282 638 minecraft:white_concrete
fill 250 282 612 251 282 618 minecraft:white_concrete
fill 250 282 619 250 282 620 minecraft:gold_block
fill 250 282 629 251 282 629 minecraft:gold_block
fill 250 282 630 250 282 638 minecraft:white_concrete
fill 251 282 619 252 282 619 minecraft:gold_block
fill 251 282 630 258 282 630 minecraft:gold_block
fill 251 282 631 252 282 638 minecraft:white_concrete
fill 252 282 612 276 282 617 minecraft:white_concrete
fill 252 282 618 256 282 618 minecraft:gold_block
fill 253 282 631 256 282 631 minecraft:gold_block
fill 253 282 632 276 282 638 minecraft:white_concrete
fill 255 282 619 258 282 619 minecraft:gold_block
fill 257 282 618 276 282 618 minecraft:white_concrete
fill 257 282 629 259 282 629 minecraft:gold_block
fill 257 282 631 276 282 631 minecraft:white_concrete
fill 258 282 620 259 282 620 minecraft:gold_block
fill 258 282 628 260 282 628 minecraft:gold_block
fill 259 282 619 276 282 619 minecraft:white_concrete
fill 259 282 621 260 282 622 minecraft:gold_block
fill 259 282 626 260 282 627 minecraft:gold_block
fill 259 282 630 276 282 630 minecraft:white_concrete
fill 260 282 620 276 282 620 minecraft:white_concrete
fill 260 282 623 260 282 625 minecraft:gold_block
fill 260 282 629 276 282 629 minecraft:white_concrete
fill 261 282 621 276 282 623 minecraft:white_concrete
fill 261 282 624 261 282 625 minecraft:gold_block
fill 261 282 626 276 282 628 minecraft:white_concrete
fill 262 282 624 276 282 625 minecraft:white_concrete
fill 236 283 613 246 283 637 minecraft:white_concrete
fill 237 283 612 275 283 612 minecraft:white_concrete
fill 237 283 638 275 283 638 minecraft:white_concrete
setblock 238 283 607 minecraft:light[level=14]
fill 238 283 611 274 283 611 minecraft:white_concrete
fill 238 283 639 274 283 639 minecraft:white_concrete
fill 239 283 610 273 283 610 minecraft:white_concrete
fill 239 283 640 273 283 640 minecraft:white_concrete
fill 240 283 609 272 284 609 minecraft:white_concrete
fill 240 283 641 272 284 641 minecraft:white_concrete
fill 241 283 608 271 283 608 minecraft:white_concrete
fill 241 283 642 271 283 642 minecraft:white_concrete
fill 242 283 607 270 283 607 minecraft:white_concrete
fill 242 283 643 270 283 643 minecraft:white_concrete
fill 243 283 606 269 283 606 minecraft:white_concrete
fill 243 283 644 269 283 644 minecraft:white_concrete
fill 244 283 605 268 283 605 minecraft:white_concrete
fill 244 283 645 268 283 645 minecraft:white_concrete
fill 247 283 613 247 283 620 minecraft:white_concrete
fill 247 283 621 247 283 628 minecraft:light_gray_concrete
fill 247 283 629 247 283 637 minecraft:white_concrete
fill 248 283 613 248 283 619 minecraft:white_concrete
fill 248 283 620 248 283 621 minecraft:light_gray_concrete
fill 248 283 628 248 283 629 minecraft:light_gray_concrete
fill 248 283 630 248 283 637 minecraft:white_concrete
fill 249 283 613 249 283 618 minecraft:white_concrete
setblock 249 283 619 minecraft:light_gray_concrete
fill 249 283 629 249 283 630 minecraft:light_gray_concrete
fill 249 283 631 249 283 637 minecraft:white_concrete
fill 250 283 613 250 283 617 minecraft:white_concrete
fill 250 283 618 251 283 618 minecraft:light_gray_concrete
fill 250 283 630 250 283 631 minecraft:light_gray_concrete
fill 250 283 632 250 283 637 minecraft:white_concrete
fill 251 283 613 276 283 616 minecraft:white_concrete
fill 251 283 617 258 283 617 minecraft:light_gray_concrete
fill 251 283 631 252 283 632 minecraft:light_gray_concrete
fill 251 283 633 276 283 637 minecraft:white_concrete
fill 253 283 632 258 283 632 minecraft:light_gray_concrete
setblock 254 283 623 minecraft:light[level=14]
setblock 254 283 631 minecraft:light[level=14]
fill 257 283 618 259 283 618 minecraft:light_gray_concrete
fill 257 283 631 259 283 631 minecraft:light_gray_concrete
fill 259 283 617 276 283 617 minecraft:white_concrete
fill 259 283 619 260 283 619 minecraft:light_gray_concrete
fill 259 283 630 260 283 630 minecraft:light_gray_concrete
fill 259 283 632 276 283 632 minecraft:white_concrete
fill 260 283 618 276 283 618 minecraft:white_concrete
fill 260 283 620 261 283 620 minecraft:light_gray_concrete
fill 260 283 629 261 283 629 minecraft:light_gray_concrete
fill 260 283 631 276 283 631 minecraft:white_concrete
fill 261 283 619 276 283 619 minecraft:white_concrete
fill 261 283 621 262 283 623 minecraft:light_gray_concrete
fill 261 283 626 262 283 628 minecraft:light_gray_concrete
fill 261 283 630 276 283 630 minecraft:white_concrete
fill 262 283 620 276 283 620 minecraft:white_concrete
fill 262 283 624 262 283 625 minecraft:light_gray_concrete
fill 262 283 629 276 283 629 minecraft:white_concrete
fill 263 283 621 276 283 628 minecraft:white_concrete
fill 235 284 609 235 289 609 minecraft:sea_lantern
fill 235 284 617 235 289 617 minecraft:sea_lantern
fill 235 284 625 235 289 625 minecraft:sea_lantern
fill 235 284 633 235 289 633 minecraft:sea_lantern
fill 235 284 641 235 289 641 minecraft:sea_lantern
fill 236 284 611 236 300 612 minecraft:gray_concrete
fill 236 284 615 245 284 635 minecraft:white_concrete
fill 236 284 636 236 300 636 minecraft:gray_concrete
fill 236 284 643 236 300 644 minecraft:gray_concrete
fill 237 284 605 238 300 605 minecraft:gray_concrete
fill 237 284 613 275 284 614 minecraft:white_concrete
fill 237 284 636 275 284 637 minecraft:white_concrete
fill 238 284 612 274 284 612 minecraft:white_concrete
fill 238 284 638 274 284 638 minecraft:white_concrete
fill 238 284 646 238 289 646 minecraft:sea_lantern
fill 239 284 611 273 284 611 minecraft:white_concrete
fill 239 284 639 273 284 639 minecraft:white_concrete
fill 240 284 610 272 284 610 minecraft:white_concrete
fill 240 284 640 272 284 640 minecraft:white_concrete
fill 242 284 604 242 289 604 minecraft:sea_lantern
fill 242 284 608 270 284 608 minecraft:white_concrete
fill 242 284 642 270 284 642 minecraft:white_concrete
fill 242 284 645 243 300 645 minecraft:gray_concrete
fill 243 284 607 269 284 607 minecraft:white_concrete
fill 243 284 643 269 284 643 minecraft:white_concrete
fill 244 284 606 268 284 606 minecraft:white_concrete
fill 244 284 644 268 284 644 minecraft:white_concrete
fill 245 284 605 245 300 605 minecraft:gray_concrete
fill 246 284 605 266 284 605 minecraft:white_concrete
fill 246 284 615 246 284 620 minecraft:white_concrete
fill 246 284 621 246 284 628 minecraft:light_gray_concrete
fill 246 284 629 246 284 635 minecraft:white_concrete
fill 246 284 645 266 284 645 minecraft:white_concrete
fill 246 284 646 246 289 646 minecraft:sea_lantern
fill 247 284 615 247 284 618 minecraft:white_concrete
fill 247 284 619 247 284 620 minecraft:light_gray_concrete
fill 247 284 629 247 284 630 minecraft:light_gray_concrete
fill 247 284 631 247 284 635 minecraft:white_concrete
fill 248 284 615 248 284 617 minecraft:white_concrete
fill 248 284 618 248 284 619 minecraft:light_gray_concrete
fill 248 284 630 248 284 631 minecraft:light_gray_concrete
fill 248 284 632 248 284 635 minecraft:white_concrete
fill 249 284 615 250 284 616 minecraft:white_concrete
fill 249 284 617 249 284 618 minecraft:light_gray_concrete
fill 249 284 631 249 284 632 minecraft:light_gray_concrete
fill 249 284 633 249 284 635 minecraft:white_concrete
fill 250 284 604 250 289 604 minecraft:sea_lantern
setblock 250 284 617 minecraft:light_gray_concrete
fill 250 284 632 250 284 633 minecraft:light_gray_concrete
fill 250 284 634 251 284 635 minecraft:white_concrete
fill 251 284 615 252 284 615 minecraft:white_concrete
fill 251 284 616 259 284 616 minecraft:light_gray_concrete
fill 251 284 633 259 284 633 minecraft:light_gray_concrete
fill 252 284 634 257 284 634 minecraft:light_gray_concrete
fill 252 284 635 276 284 635 minecraft:white_concrete
fill 253 284 615 256 284 615 minecraft:light_gray_concrete
fill 254 284 646 254 289 646 minecraft:sea_lantern
fill 257 284 615 276 284 615 minecraft:white_concrete
fill 258 284 604 258 289 604 minecraft:sea_lantern
fill 258 284 634 276 284 634 minecraft:white_concrete
fill 259 284 617 261 284 617 minecraft:light_gray_concrete
fill 259 284 632 261 284 632 minecraft:light_gray_concrete
fill 260 284 616 276 284 616 minecraft:white_concrete
fill 260 284 618 262 284 618 minecraft:light_gray_concrete
fill 260 284 631 262 284 631 minecraft:light_gray_concrete
fill 260 284 633 276 284 633 minecraft:white_concrete
fill 261 284 619 262 284 619 minecraft:light_gray_concrete
fill 261 284 630 263 284 630 minecraft:light_gray_concrete
fill 262 284 617 276 284 617 minecraft:white_concrete
fill 262 284 620 263 284 620 minecraft:light_gray_concrete
fill 262 284 629 263 284 629 minecraft:light_gray_concrete
fill 262 284 632 276 284 632 minecraft:white_concrete
fill 262 284 646 262 289 646 minecraft:sea_lantern
fill 263 284 618 276 284 619 minecraft:white_concrete
fill 263 284 621 263 284 628 minecraft:light_gray_concrete
fill 263 284 631 276 284 631 minecraft:white_concrete
fill 264 284 620 276 284 621 minecraft:white_concrete
fill 264 284 622 264 284 628 minecraft:light_gray_concrete
fill 264 284 629 276 284 630 minecraft:white_concrete
fill 265 284 622 276 284 628 minecraft:white_concrete
fill 266 284 604 266 289 604 minecraft:sea_lantern
fill 267 284 645 267 300 645 minecraft:gray_concrete
fill 269 284 605 270 300 605 minecraft:gray_concrete
fill 270 284 646 270 289 646 minecraft:sea_lantern
fill 274 284 604 274 289 604 minecraft:sea_lantern
fill 274 284 645 275 300 645 minecraft:gray_concrete
fill 276 284 606 276 300 607 minecraft:gray_concrete
fill 276 284 614 276 300 614 minecraft:gray_concrete
fill 276 284 638 276 300 639 minecraft:gray_concrete
fill 277 284 609 277 289 609 minecraft:sea_lantern
fill 277 284 617 277 289 617 minecraft:sea_lantern
fill 277 284 625 277 289 625 minecraft:sea_lantern
fill 277 284 633 277 289 633 minecraft:sea_lantern
fill 277 284 641 277 289 641 minecraft:sea_lantern
fill 236 285 617 243 285 633 minecraft:white_concrete
fill 236 285 635 236 300 635 minecraft:gray_concrete
fill 237 285 615 247 285 616 minecraft:white_concrete
fill 237 285 634 248 285 635 minecraft:white_concrete
fill 238 285 613 251 285 614 minecraft:white_concrete
fill 238 285 636 254 285 637 minecraft:white_concrete
fill 239 285 612 273 285 612 minecraft:white_concrete
fill 239 285 638 273 285 638 minecraft:white_concrete
fill 240 285 611 272 285 611 minecraft:white_concrete
fill 240 285 639 272 285 639 minecraft:white_concrete
fill 241 285 610 271 285 610 minecraft:white_concrete
fill 241 285 640 271 285 640 minecraft:white_concrete
fill 242 285 609 270 285 609 minecraft:white_concrete
fill 242 285 641 270 285 641 minecraft:white_concrete
fill 243 285 608 269 285 608 minecraft:white_concrete
fill 243 285 642 269 285 642 minecraft:white_concrete
fill 244 285 607 268 285 607 minecraft:white_concrete
fill 244 285 617 244 285 622 minecraft:white_concrete
fill 244 285 623 245 285 626 minecraft:gold_block
fill 244 285 627 244 285 633 minecraft:white_concrete
fill 244 285 643 268 285 643 minecraft:white_concrete
fill 245 285 617 245 285 619 minecraft:white_concrete
fill 245 285 620 245 285 622 minecraft:gold_block
fill 245 285 627 245 285 629 minecraft:gold_block
fill 245 285 630 245 285 633 minecraft:white_concrete
fill 246 285 605 246 300 605 minecraft:gray_concrete
fill 246 285 606 266 285 606 minecraft:white_concrete
fill 246 285 617 246 285 618 minecraft:white_concrete
fill 246 285 619 246 285 620 minecraft:gold_block
fill 246 285 629 246 285 631 minecraft:gold_block
fill 246 285 632 246 285 633 minecraft:white_concrete
fill 246 285 644 266 285 644 minecraft:white_concrete
fill 247 285 617 247 285 618 minecraft:gold_block
fill 247 285 631 247 285 632 minecraft:gold_block
setblock 247 285 633 minecraft:white_concrete
fill 248 285 605 264 285 605 minecraft:white_concrete
fill 248 285 615 249 285 615 minecraft:white_concrete
fill 248 285 616 248 285 617 minecraft:gold_block
fill 248 285 632 248 285 633 minecraft:gold_block
fill 248 285 645 264 285 645 minecraft:white_concrete
fill 249 285 616 250 285 616 minecraft:gold_block
fill 249 285 633 249 285 634 minecraft:gold_block
fill 249 285 635 250 285 635 minecraft:white_concrete
fill 250 285 615 252 285 615 minecraft:gold_block
fill 250 285 634 251 285 634 minecraft:gold_block
fill 251 285 635 259 285 635 minecraft:gold_block
fill 252 285 613 274 285 613 minecraft:white_concrete
fill 252 285 614 258 285 614 minecraft:gold_block
fill 252 285 617 253 286 617 minecraft:gold_block
setblock 255 285 636 minecraft:gold_block
fill 255 285 637 274 285 637 minecraft:white_concrete
fill 256 285 636 274 285 636 minecraft:white_concrete
fill 257 285 615 260 285 615 minecraft:gold_block
fill 258 285 634 261 285 634 minecraft:gold_block
fill 259 285 614 274 285 614 minecraft:white_concrete
fill 260 285 616 262 285 616 minecraft:gold_block
fill 260 285 633 262 285 633 minecraft:gold_block
fill 260 285 635 275 285 635 minecraft:white_concrete
fill 261 285 615 275 285 615 minecraft:white_concrete
fill 262 285 617 263 285 617 minecraft:gold_block
fill 262 285 632 263 285 632 minecraft:gold_block
fill 262 285 634 275 285 634 minecraft:white_concrete
fill 263 285 616 275 285 616 minecraft:white_concrete
fill 263 285 618 264 285 619 minecraft:gold_block
fill 263 285 631 264 285 631 minecraft:gold_block
fill 263 285 633 276 285 633 minecraft:white_concrete
fill 264 285 617 276 285 617 minecraft:white_concrete
fill 264 285 620 265 285 621 minecraft:gold_block
fill 264 285 629 265 285 630 minecraft:gold_block
fill 264 285 632 276 285 632 minecraft:white_concrete
fill 265 285 618 276 285 619 minecraft:white_concrete
fill 265 285 622 265 285 628 minecraft:gold_block
fill 265 285 631 276 285 631 minecraft:white_concrete
fill 266 285 620 276 285 621 minecraft:white_concrete
fill 266 285 622 266 285 627 minecraft:gold_block
fill 266 285 628 276 285 630 minecraft:white_concrete
fill 266 285 645 266 300 645 minecraft:gray_concrete
fill 267 285 622 276 285 627 minecraft:white_concrete
fill 276 285 615 276 300 615 minecraft:gray_concrete
fill 236 286 619 242 286 631 minecraft:white_concrete
fill 237 286 617 244 286 618 minecraft:white_concrete
fill 237 286 632 244 286 633 minecraft:white_concrete
fill 238 286 615 246 286 616 minecraft:white_concrete
fill 238 286 634 246 286 635 minecraft:white_concrete
fill 239 286 613 248 286 614 minecraft:white_concrete
fill 239 286 636 249 286 637 minecraft:white_concrete
fill 240 286 612 272 286 612 minecraft:white_concrete
fill 240 286 638 272 286 638 minecraft:white_concrete
fill 241 286 611 271 286 611 minecraft:white_concrete
fill 241 286 639 271 286 639 minecraft:white_concrete
fill 242 286 610 270 286 610 minecraft:white_concrete
fill 242 286 640 270 286 640 minecraft:white_concrete
fill 243 286 609 269 286 609 minecraft:white_concrete
fill 243 286 619 243 286 622 minecraft:white_concrete
fill 243 286 623 243 286 627 minecraft:light_gray_concrete
fill 243 286 628 243 286 631 minecraft:white_concrete
fill 243 286 641 269 286 641 minecraft:white_concrete
fill 244 286 608 268 286 608 minecraft:white_concrete
setblock 244 286 619 minecraft:white_concrete
fill 244 286 620 244 286 622 minecraft:light_gray_concrete
fill 244 286 627 244 286 630 minecraft:light_gray_concrete
setblock 244 286 631 minecraft:white_concrete
fill 244 286 642 268 286 642 minecraft:white_concrete
setblock 245 286 617 minecraft:white_concrete
fill 245 286 618 245 286 619 minecraft:light_gray_concrete
fill 245 286 630 245 286 632 minecraft:light_gray_concrete
setblock 245 286 633 minecraft:white_concrete
fill 246 286 607 266 286 607 minecraft:white_concrete
fill 246 286 617 246 286 618 minecraft:light_gray_concrete
fill 246 286 632 246 286 633 minecraft:light_gray_concrete
fill 246 286 643 266 286 643 minecraft:white_concrete
setblock 247 286 615 minecraft:white_concrete
setblock 247 286 616 minecraft:light_gray_concrete
fill 247 286 633 247 286 634 minecraft:light_gray_concrete
setblock 247 286 635 minecraft:white_concrete
fill 248 286 606 264 286 606 minecraft:white_concrete
fill 248 286 615 249 286 615 minecraft:light_gray_concrete
fill 248 286 634 248 286 635 minecraft:light_gray_concrete
fill 248 286 644 264 286 644 minecraft:white_concrete
fill 249 286 613 250 286 613 minecraft:white_concrete
fill 249 286 614 251 286 614 minecraft:light_gray_concrete
fill 249 286 635 250 286 635 minecraft:light_gray_concrete
fill 250 286 605 262 286 605 minecraft:white_concrete
fill 250 286 636 254 286 636 minecraft:light_gray_concrete
fill 250 286 637 251 286 637 minecraft:white_concrete
fill 250 286 645 262 286 645 minecraft:white_concrete
fill 251 286 613 260 286 613 minecraft:light_gray_concrete
fill 252 286 637 259 286 637 minecraft:light_gray_concrete
fill 256 286 636 261 286 636 minecraft:light_gray_concrete
fill 259 286 614 262 286 614 minecraft:light_gray_concrete
fill 260 286 635 263 286 635 minecraft:light_gray_concrete
fill 260 286 637 273 286 637 minecraft:white_concrete
fill 261 286 613 273 286 613 minecraft:white_concrete
fill 261 286 615 263 286 615 minecraft:light_gray_concrete
fill 262 286 634 264 286 634 minecraft:light_gray_concrete
fill 262 286 636 273 286 636 minecraft:white_concrete
fill 263 286 614 273 286 614 minecraft:white_concrete
fill 263 286 616 264 286 616 minecraft:light_gray_concrete
fill 263 286 633 265 286 633 minecraft:light_gray_concrete
fill 264 286 615 274 286 615 minecraft:white_concrete
fill 264 286 617 265 286 617 minecraft:light_gray_concrete
fill 264 286 632 266 286 632 minecraft:light_gray_concrete
fill 264 286 635 274 286 635 minecraft:white_concrete
fill 265 286 616 274 286 616 minecraft:white_concrete
fill 265 286 618 266 286 619 minecraft:light_gray_concrete
fill 265 286 631 266 286 631 minecraft:light_gray_concrete
fill 265 286 634 274 286 634 minecraft:white_concrete
fill 266 286 617 275 286 617 minecraft:white_concrete
fill 266 286 620 267 286 621 minecraft:light_gray_concrete
fill 266 286 628 267 286 630 minecraft:light_gray_concrete
fill 266 286 633 275 286 633 minecraft:white_concrete
fill 267 286 618 275 286 619 minecraft:white_concrete
fill 267 286 622 267 286 627 minecraft:light_gray_concrete
fill 267 286 631 275 286 632 minecraft:white_concrete
fill 268 286 620 276 286 622 minecraft:white_concrete
fill 268 286 623 268 286 627 minecraft:light_gray_concrete
fill 268 286 628 276 286 630 minecraft:white_concrete
fill 269 286 623 276 286 627 minecraft:white_concrete
setblock 276 286 619 minecraft:white_concrete
setblock 276 286 631 minecraft:white_concrete
fill 236 287 619 236 300 620 minecraft:gray_concrete
fill 236 287 627 236 300 628 minecraft:gray_concrete
fill 237 287 620 241 287 630 minecraft:white_concrete
fill 238 287 617 242 287 619 minecraft:white_concrete
fill 238 287 631 242 287 633 minecraft:white_concrete
fill 239 287 615 244 287 616 minecraft:white_concrete
fill 239 287 634 244 287 635 minecraft:white_concrete
fill 240 287 614 246 287 614 minecraft:white_concrete
fill 240 287 636 246 287 636 minecraft:white_concrete
fill 241 287 613 248 287 613 minecraft:white_concrete
fill 241 287 637 248 287 637 minecraft:white_concrete
fill 242 287 611 249 287 612 minecraft:white_concrete
fill 242 287 620 242 287 621 minecraft:white_concrete
fill 242 287 622 242 287 628 minecraft:light_gray_concrete
fill 242 287 629 242 287 630 minecraft:white_concrete
fill 242 287 638 250 287 639 minecraft:white_concrete
fill 243 287 617 243 287 618 minecraft:white_concrete
fill 243 287 619 243 287 622 minecraft:light_gray_concrete
fill 243 287 628 243 287 631 minecraft:light_gray_concrete
fill 243 287 632 243 287 633 minecraft:white_concrete
fill 244 287 610 268 287 610 minecraft:white_concrete
fill 244 287 617 244 287 619 minecraft:light_gray_concrete
fill 244 287 631 244 287 632 minecraft:light_gray_concrete
setblock 244 287 633 minecraft:white_concrete
fill 244 287 640 268 287 640 minecraft:white_concrete
fill 245 287 609 267 287 609 minecraft:white_concrete
setblock 245 287 615 minecraft:white_concrete
fill 245 287 616 245 287 617 minecraft:light_gray_concrete
fill 245 287 633 245 287 634 minecraft:light_gray_concrete
setblock 245 287 635 minecraft:white_concrete
fill 245 287 641 267 287 641 minecraft:white_concrete
fill 246 287 608 266 287 608 minecraft:white_concrete
fill 246 287 615 246 287 616 minecraft:light_gray_concrete
fill 246 287 634 246 287 635 minecraft:light_gray_concrete
fill 246 287 642 266 287 642 minecraft:white_concrete
fill 247 287 614 247 287 615 minecraft:light_gray_concrete
fill 247 287 635 247 287 636 minecraft:light_gray_concrete
fill 248 287 607 264 287 607 minecraft:white_concrete
setblock 248 287 614 minecraft:light_gray_concrete
fill 248 287 636 249 287 636 minecraft:light_gray_concrete
fill 248 287 643 264 287 643 minecraft:white_concrete
fill 249 287 613 250 287 613 minecraft:light_gray_concrete
fill 249 287 637 251 287 637 minecraft:light_gray_concrete
fill 250 287 611 252 287 611 minecraft:white_concrete
fill 250 287 612 261 287 612 minecraft:light_gray_concrete
fill 250 287 645 251 300 645 minecraft:gray_concrete
fill 251 287 606 261 287 606 minecraft:white_concrete
fill 251 287 638 261 287 638 minecraft:light_gray_concrete
fill 251 287 639 253 287 639 minecraft:white_concrete
fill 251 287 644 261 287 644 minecraft:white_concrete
fill 253 287 605 254 300 605 minecraft:gray_concrete
fill 253 287 611 258 287 611 minecraft:light_gray_concrete
fill 254 287 639 258 287 639 minecraft:light_gray_concrete
fill 258 287 645 259 300 645 minecraft:gray_concrete
fill 259 287 611 270 287 611 minecraft:white_concrete
fill 259 287 639 270 287 639 minecraft:white_concrete
fill 260 287 637 263 287 637 minecraft:light_gray_concrete
fill 261 287 605 262 300 605 minecraft:gray_concrete
fill 261 287 613 263 287 613 minecraft:light_gray_concrete
fill 262 287 612 270 287 612 minecraft:white_concrete
fill 262 287 636 264 287 636 minecraft:light_gray_concrete
fill 262 287 638 270 287 638 minecraft:white_concrete
fill 263 287 614 264 287 614 minecraft:light_gray_concrete
fill 264 287 613 271 287 613 minecraft:white_concrete
fill 264 287 615 266 287 615 minecraft:light_gray_concrete
fill 264 287 635 265 287 635 minecraft:light_gray_concrete
fill 264 287 637 271 287 637 minecraft:white_concrete
fill 265 287 614 272 287 614 minecraft:white_concrete
fill 265 287 616 266 287 616 minecraft:light_gray_concrete
fill 265 287 634 266 287 634 minecraft:light_gray_concrete
fill 265 287 636 272 287 636 minecraft:white_concrete
fill 266 287 617 267 287 617 minecraft:light_gray_concrete
fill 266 287 633 267 287 633 minecraft:light_gray_concrete
fill 266 287 635 273 287 635 minecraft:white_concrete
fill 267 287 615 273 287 616 minecraft:white_concrete
fill 267 287 618 268 287 619 minecraft:light_gray_concrete
fill 267 287 631 268 287 632 minecraft:light_gray_concrete
fill 267 287 634 273 287 634 minecraft:white_concrete
fill 268 287 617 274 287 617 minecraft:white_concrete
fill 268 287 620 269 287 622 minecraft:light_gray_concrete
fill 268 287 628 269 287 630 minecraft:light_gray_concrete
fill 268 287 633 274 287 633 minecraft:white_concrete
fill 269 287 618 274 287 619 minecraft:white_concrete
fill 269 287 623 269 287 627 minecraft:light_gray_concrete
fill 269 287 631 274 287 632 minecraft:white_concrete
fill 270 287 620 275 287 623 minecraft:white_concrete
fill 270 287 624 270 287 626 minecraft:light_gray_concrete
fill 270 287 627 275 287 630 minecraft:white_concrete
fill 271 287 624 275 287 626 minecraft:white_concrete
fill 276 287 622 276 300 623 minecraft:gray_concrete
fill 276 287 630 276 300 631 minecraft:gray_concrete
fill 238 288 623 240 288 627 minecraft:white_concrete
fill 239 288 619 240 288 622 minecraft:white_concrete
fill 239 288 628 240 288 631 minecraft:white_concrete
fill 240 288 617 242 288 618 minecraft:white_concrete
fill 240 288 632 242 288 633 minecraft:white_concrete
fill 241 288 615 243 288 616 minecraft:white_concrete
fill 241 288 619 241 288 621 minecraft:white_concrete
fill 241 288 622 241 288 628 minecraft:gold_block
fill 241 288 629 241 288 631 minecraft:white_concrete
fill 241 288 634 243 288 635 minecraft:white_concrete
fill 242 288 614 245 288 614 minecraft:white_concrete
fill 242 288 619 242 288 621 minecraft:gold_block
fill 242 288 629 242 288 631 minecraft:gold_block
fill 242 288 636 245 288 636 minecraft:white_concrete
fill 243 288 613 246 288 613 minecraft:white_concrete
fill 243 288 617 243 288 618 minecraft:gold_block
setblock 243 288 632 minecraft:gold_block
setblock 243 288 633 minecraft:white_concrete
fill 243 288 637 246 288 637 minecraft:white_concrete
fill 244 288 612 248 288 612 minecraft:white_concrete
setblock 244 288 615 minecraft:white_concrete
setblock 244 288 616 minecraft:gold_block
fill 244 288 633 244 288 634 minecraft:gold_block
setblock 244 288 635 minecraft:white_concrete
fill 244 288 638 248 288 638 minecraft:white_concrete
fill 245 288 611 249 288 611 minecraft:white_concrete
setblock 245 288 615 minecraft:gold_block
setblock 245 288 635 minecraft:gold_block
fill 245 288 639 250 288 639 minecraft:white_concrete
fill 246 288 610 252 288 610 minecraft:white_concrete
setblock 246 288 614 minecraft:gold_block
setblock 246 288 636 minecraft:gold_block
fill 246 288 640 253 288 640 minecraft:white_concrete
fill 247 288 613 248 288 613 minecraft:gold_block
fill 247 288 637 248 288 637 minecraft:gold_block
fill 248 288 609 264 288 609 minecraft:white_concrete
fill 248 288 641 264 288 641 minecraft:white_concrete
setblock 249 288 612 minecraft:gold_block
fill 249 288 638 250 288 638 minecraft:gold_block
fill 250 288 608 262 288 608 minecraft:white_concrete
fill 250 288 611 252 288 611 minecraft:gold_block
fill 250 288 642 262 288 642 minecraft:white_concrete
fill 251 288 639 253 288 639 minecraft:gold_block
fill 253 288 610 258 288 610 minecraft:gold_block
fill 254 288 607 258 288 607 minecraft:white_concrete
fill 254 288 640 258 288 640 minecraft:gold_block
fill 254 288 643 258 288 643 minecraft:white_concrete
fill 259 288 610 266 288 610 minecraft:white_concrete
fill 259 288 611 261 288 611 minecraft:gold_block
fill 259 288 639 261 288 639 minecraft:gold_block
fill 259 288 640 266 288 640 minecraft:white_concrete
fill 262 288 611 267 288 611 minecraft:white_concrete
fill 262 288 612 263 288 612 minecraft:gold_block
fill 262 288 638 263 288 638 minecraft:gold_block
fill 262 288 639 267 288 639 minecraft:white_concrete
fill 264 288 612 268 288 612 minecraft:white_concrete
fill 264 288 613 265 288 613 minecraft:gold_block
fill 264 288 637 265 288 637 minecraft:gold_block
fill 264 288 638 268 288 638 minecraft:white_concrete
fill 265 288 614 266 288 614 minecraft:gold_block
fill 265 288 636 266 288 636 minecraft:gold_block
fill 266 288 613 269 288 613 minecraft:white_concrete
fill 266 288 635 267 288 635 minecraft:gold_block
fill 266 288 637 269 288 637 minecraft:white_concrete
fill 267 288 614 270 288 614 minecraft:white_concrete
fill 267 288 615 267 288 616 minecraft:gold_block
fill 267 288 634 268 288 634 minecraft:gold_block
fill 267 288 636 270 288 636 minecraft:white_concrete
fill 268 288 615 271 288 615 minecraft:white_concrete
fill 268 288 616 268 288 617 minecraft:gold_block
setblock 268 288 633 minecraft:gold_block
fill 268 288 635 271 288 635 minecraft:white_concrete
fill 269 288 616 271 288 617 minecraft:white_concrete
fill 269 288 618 269 288 619 minecraft:gold_block
fill 269 288 631 269 288 632 minecraft:gold_block
fill 269 288 633 271 288 634 minecraft:white_concrete
fill 270 288 618 272 288 619 minecraft:white_concrete
fill 270 288 620 270 288 623 minecraft:gold_block
fill 270 288 627 270 288 630 minecraft:gold_block
fill 270 288 631 272 288 632 minecraft:white_concrete
fill 271 288 620 273 288 623 minecraft:white_concrete
fill 271 288 624 271 288 626 minecraft:gold_block
fill 271 288 627 273 288 630 minecraft:white_concrete
setblock 272 288 617 minecraft:white_concrete
fill 272 288 624 274 288 626 minecraft:white_concrete
setblock 272 288 633 minecraft:white_concrete
setblock 273 288 619 minecraft:white_concrete
setblock 273 288 631 minecraft:white_concrete
setblock 274 288 623 minecraft:white_concrete
setblock 274 288 627 minecraft:white_concrete
fill 248 289 605 248 290 607 minecraft:iron_block
fill 235 290 609 235 297 609 minecraft:white_concrete
fill 235 290 617 235 297 617 minecraft:white_concrete
fill 235 290 625 235 297 625 minecraft:white_concrete
fill 235 290 633 235 297 633 minecraft:white_concrete
fill 235 290 641 235 297 641 minecraft:white_concrete
fill 238 290 646 238 297 646 minecraft:white_concrete
fill 242 290 604 242 297 604 minecraft:white_concrete
fill 246 290 646 246 297 646 minecraft:white_concrete
fill 250 290 604 250 297 604 minecraft:white_concrete
fill 254 290 646 254 297 646 minecraft:white_concrete
fill 258 290 604 258 297 604 minecraft:white_concrete
fill 262 290 646 262 297 646 minecraft:white_concrete
fill 266 290 604 266 297 604 minecraft:white_concrete
fill 270 290 646 270 297 646 minecraft:white_concrete
fill 274 290 604 274 297 604 minecraft:white_concrete
fill 277 290 609 277 297 609 minecraft:white_concrete
fill 277 290 617 277 297 617 minecraft:white_concrete
fill 277 290 625 277 297 625 minecraft:white_concrete
fill 277 290 633 277 297 633 minecraft:white_concrete
fill 277 290 641 277 297 641 minecraft:white_concrete
setblock 238 291 607 minecraft:light[level=14]
setblock 238 291 615 minecraft:light[level=14]
setblock 238 291 623 minecraft:light[level=14]
setblock 238 291 631 minecraft:light[level=14]
setblock 238 291 639 minecraft:light[level=14]
setblock 246 291 607 minecraft:light[level=14]
setblock 246 291 615 minecraft:light[level=14]
setblock 246 291 623 minecraft:light[level=14]
setblock 246 291 631 minecraft:light[level=14]
setblock 246 291 639 minecraft:light[level=14]
setblock 254 291 607 minecraft:light[level=14]
setblock 254 291 615 minecraft:light[level=14]
setblock 254 291 623 minecraft:light[level=14]
setblock 254 291 631 minecraft:light[level=14]
setblock 254 291 639 minecraft:light[level=14]
setblock 262 291 607 minecraft:light[level=14]
setblock 262 291 615 minecraft:light[level=14]
setblock 262 291 623 minecraft:light[level=14]
setblock 262 291 631 minecraft:light[level=14]
setblock 262 291 639 minecraft:light[level=14]
setblock 270 291 607 minecraft:light[level=14]
setblock 270 291 615 minecraft:light[level=14]
setblock 270 291 623 minecraft:light[level=14]
setblock 270 291 631 minecraft:light[level=14]
setblock 270 291 639 minecraft:light[level=14]
fill 236 294 605 236 295 610 minecraft:gray_concrete
fill 236 294 613 237 294 618 minecraft:gray_concrete
fill 236 294 621 237 294 626 minecraft:gray_concrete
fill 236 294 629 237 294 634 minecraft:gray_concrete
fill 236 294 637 237 294 642 minecraft:gray_concrete
fill 236 294 645 241 295 645 minecraft:gray_concrete
fill 237 294 606 237 294 612 minecraft:gray_concrete
fill 237 294 619 237 294 620 minecraft:gray_concrete
fill 237 294 627 237 294 628 minecraft:gray_concrete
fill 237 294 635 237 294 636 minecraft:gray_concrete
fill 237 294 643 237 294 644 minecraft:gray_concrete
fill 238 294 606 275 294 606 minecraft:gray_concrete
fill 238 294 644 276 294 644 minecraft:gray_concrete
fill 239 294 605 244 295 605 minecraft:gray_concrete
fill 244 294 645 249 295 645 minecraft:gray_concrete
fill 247 294 605 252 295 605 minecraft:gray_concrete
fill 252 294 645 257 295 645 minecraft:gray_concrete
fill 255 294 605 260 295 605 minecraft:gray_concrete
fill 260 294 645 265 295 645 minecraft:gray_concrete
fill 263 294 605 268 295 605 minecraft:gray_concrete
fill 268 294 645 273 295 645 minecraft:gray_concrete
fill 271 294 605 276 295 605 minecraft:gray_concrete
fill 275 294 607 275 294 643 minecraft:gray_concrete
fill 276 294 608 276 295 613 minecraft:gray_concrete
fill 276 294 616 276 295 621 minecraft:gray_concrete
fill 276 294 624 276 295 629 minecraft:gray_concrete
fill 276 294 632 276 295 637 minecraft:gray_concrete
fill 276 294 640 276 295 643 minecraft:gray_concrete
fill 276 294 645 276 295 645 minecraft:gray_concrete
fill 236 295 613 236 295 618 minecraft:gray_concrete
fill 236 295 621 236 295 626 minecraft:gray_concrete
fill 236 295 629 236 295 634 minecraft:gray_concrete
fill 236 295 637 236 295 642 minecraft:gray_concrete
fill 273 295 638 275 296 638 minecraft:iron_block
setblock 276 295 644 minecraft:gray_concrete
fill 273 297 620 275 298 620 minecraft:iron_block
fill 235 298 609 235 300 609 minecraft:sea_lantern
fill 235 298 617 235 300 617 minecraft:sea_lantern
fill 235 298 625 235 300 625 minecraft:sea_lantern
fill 235 298 633 235 300 633 minecraft:sea_lantern
fill 235 298 641 235 300 641 minecraft:sea_lantern
fill 238 298 646 238 300 646 minecraft:sea_lantern
fill 242 298 604 242 300 604 minecraft:sea_lantern
fill 246 298 646 246 300 646 minecraft:sea_lantern
fill 250 298 604 250 300 604 minecraft:sea_lantern
fill 254 298 646 254 300 646 minecraft:sea_lantern
fill 258 298 604 258 300 604 minecraft:sea_lantern
fill 262 298 646 262 300 646 minecraft:sea_lantern
fill 266 298 604 266 300 604 minecraft:sea_lantern
fill 270 298 646 270 300 646 minecraft:sea_lantern
fill 274 298 604 274 300 604 minecraft:sea_lantern
fill 277 298 609 277 300 609 minecraft:sea_lantern
fill 277 298 617 277 300 617 minecraft:sea_lantern
fill 277 298 625 277 300 625 minecraft:sea_lantern
fill 277 298 633 277 300 633 minecraft:sea_lantern
fill 277 298 641 277 300 641 minecraft:sea_lantern
setblock 238 299 607 minecraft:light[level=14]
setblock 238 299 615 minecraft:light[level=14]
setblock 238 299 623 minecraft:light[level=14]
setblock 238 299 631 minecraft:light[level=14]
setblock 238 299 639 minecraft:light[level=14]
setblock 246 299 607 minecraft:light[level=14]
setblock 246 299 615 minecraft:light[level=14]
setblock 246 299 623 minecraft:light[level=14]
setblock 246 299 631 minecraft:light[level=14]
setblock 246 299 639 minecraft:light[level=14]
setblock 254 299 607 minecraft:light[level=14]
setblock 254 299 615 minecraft:light[level=14]
setblock 254 299 623 minecraft:light[level=14]
setblock 254 299 631 minecraft:light[level=14]
setblock 254 299 639 minecraft:light[level=14]
setblock 262 299 607 minecraft:light[level=14]
setblock 262 299 615 minecraft:light[level=14]
setblock 262 299 623 minecraft:light[level=14]
setblock 262 299 631 minecraft:light[level=14]
setblock 262 299 639 minecraft:light[level=14]
setblock 270 299 607 minecraft:light[level=14]
setblock 270 299 615 minecraft:light[level=14]
setblock 270 299 623 minecraft:light[level=14]
setblock 270 299 631 minecraft:light[level=14]
setblock 270 299 639 minecraft:light[level=14]
fill 235 301 609 235 307 609 minecraft:white_concrete
fill 235 301 617 235 307 617 minecraft:white_concrete
fill 235 301 625 235 307 625 minecraft:white_concrete
fill 235 301 633 235 307 633 minecraft:white_concrete
fill 235 301 641 235 307 641 minecraft:white_concrete
fill 238 301 646 238 307 646 minecraft:white_concrete
fill 242 301 604 242 307 604 minecraft:white_concrete
fill 246 301 646 246 307 646 minecraft:white_concrete
fill 250 301 604 250 307 604 minecraft:white_concrete
fill 254 301 646 254 307 646 minecraft:white_concrete
fill 258 301 604 258 307 604 minecraft:white_concrete
fill 262 301 646 262 307 646 minecraft:white_concrete
fill 266 301 604 266 307 604 minecraft:white_concrete
fill 270 301 646 270 307 646 minecraft:white_concrete
fill 274 301 604 274 307 604 minecraft:white_concrete
fill 277 301 609 277 307 609 minecraft:white_concrete
fill 277 301 617 277 307 617 minecraft:white_concrete
fill 277 301 625 277 307 625 minecraft:white_concrete
fill 277 301 633 277 307 633 minecraft:white_concrete
fill 277 301 641 277 307 641 minecraft:white_concrete
