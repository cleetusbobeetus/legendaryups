setblock 262 156 267 minecraft:gray_concrete
fill 268 156 230 268 157 230 minecraft:blue_terracotta
fill 268 156 232 268 157 232 minecraft:blue_terracotta
fill 268 156 234 268 157 234 minecraft:blue_terracotta
fill 268 156 236 268 157 236 minecraft:blue_terracotta
fill 268 156 262 268 157 262 minecraft:gray_concrete
fill 268 156 264 268 157 264 minecraft:gray_concrete
fill 268 156 266 268 157 266 minecraft:gray_concrete
fill 268 156 268 268 157 268 minecraft:gray_concrete
fill 269 156 229 269 157 229 minecraft:blue_terracotta
fill 269 156 237 269 157 237 minecraft:blue_terracotta
fill 269 156 261 269 157 261 minecraft:gray_concrete
fill 269 156 269 269 157 269 minecraft:gray_concrete
fill 271 156 229 271 157 229 minecraft:blue_terracotta
fill 271 156 237 271 157 237 minecraft:blue_terracotta
fill 271 156 243 271 157 243 minecraft:gray_concrete
fill 271 156 245 271 157 245 minecraft:gray_concrete
fill 271 156 247 271 157 247 minecraft:gray_concrete
fill 271 156 249 271 157 249 minecraft:gray_concrete
fill 271 156 251 271 157 251 minecraft:gray_concrete
fill 271 156 253 271 157 253 minecraft:gray_concrete
fill 271 156 261 271 157 261 minecraft:gray_concrete
fill 271 156 269 271 157 269 minecraft:gray_concrete
fill 272 156 242 272 157 242 minecraft:gray_concrete
fill 272 156 255 272 157 255 minecraft:gray_concrete
fill 273 156 229 273 157 229 minecraft:blue_terracotta
fill 273 156 237 273 157 237 minecraft:blue_terracotta
fill 273 156 261 273 157 261 minecraft:gray_concrete
fill 273 156 269 273 157 269 minecraft:gray_concrete
fill 274 156 242 274 157 242 minecraft:gray_concrete
fill 274 156 255 274 157 255 minecraft:gray_concrete
fill 275 156 229 275 157 229 minecraft:blue_terracotta
fill 275 156 237 275 157 237 minecraft:blue_terracotta
fill 275 156 261 275 157 261 minecraft:gray_concrete
fill 275 156 269 275 157 269 minecraft:gray_concrete
fill 276 156 230 276 157 230 minecraft:blue_terracotta
fill 276 156 232 276 157 232 minecraft:blue_terracotta
fill 276 156 234 276 157 234 minecraft:blue_terracotta
fill 276 156 236 276 157 236 minecraft:blue_terracotta
fill 276 156 243 276 157 243 minecraft:gray_concrete
fill 276 156 245 276 157 245 minecraft:gray_concrete
fill 276 156 247 276 157 247 minecraft:gray_concrete
fill 276 156 249 276 157 249 minecraft:gray_concrete
fill 276 156 251 276 157 251 minecraft:gray_concrete
fill 276 156 253 276 157 253 minecraft:gray_concrete
fill 276 156 262 276 157 262 minecraft:gray_concrete
fill 276 156 264 276 157 264 minecraft:gray_concrete
fill 276 156 266 276 157 266 minecraft:gray_concrete
fill 276 156 268 276 157 268 minecraft:gray_concrete
fill 277 156 254 277 173 254 minecraft:black_concrete
fill 236 157 270 236 168 270 minecraft:black_concrete
setblock 237 157 270 minecraft:pearlescent_froglight
setblock 238 157 238 minecraft:light[level=12]
setblock 238 157 239 minecraft:light[level=15]
setblock 238 157 259 minecraft:light[level=12]
setblock 245 157 231 minecraft:light[level=12]
setblock 245 157 238 minecraft:light[level=12]
setblock 245 157 245 minecraft:light[level=12]
setblock 245 157 252 minecraft:light[level=12]
setblock 245 157 259 minecraft:light[level=12]
setblock 245 157 266 minecraft:light[level=12]
setblock 246 157 231 minecraft:light[level=15]
setblock 246 157 239 minecraft:light[level=15]
setblock 246 157 247 minecraft:light[level=15]
setblock 246 157 255 minecraft:light[level=15]
setblock 252 157 238 minecraft:light[level=12]
setblock 252 157 245 minecraft:light[level=12]
setblock 252 157 252 minecraft:light[level=12]
setblock 252 157 259 minecraft:light[level=12]
setblock 254 157 239 minecraft:light[level=15]
setblock 254 157 247 minecraft:light[level=15]
setblock 254 157 255 minecraft:light[level=15]
fill 255 157 228 255 236 228 minecraft:black_concrete
fill 258 157 266 260 176 266 minecraft:gray_concrete
setblock 259 157 238 minecraft:light[level=12]
setblock 259 157 245 minecraft:light[level=12]
setblock 259 157 252 minecraft:light[level=12]
setblock 259 157 259 minecraft:light[level=12]
setblock 261 157 264 minecraft:sea_lantern
setblock 261 157 266 minecraft:sea_lantern
setblock 261 157 268 minecraft:sea_lantern
fill 261 157 269 261 282 269 minecraft:gray_concrete
setblock 262 157 239 minecraft:light[level=15]
setblock 262 157 247 minecraft:light[level=15]
setblock 262 157 255 minecraft:light[level=15]
setblock 262 157 263 minecraft:light[level=15]
fill 262 157 264 262 282 264 minecraft:gray_concrete
setblock 262 157 265 minecraft:sea_lantern
setblock 262 157 267 minecraft:sea_lantern
fill 262 157 268 262 282 268 minecraft:gray_concrete
setblock 262 157 269 minecraft:sea_lantern
setblock 263 157 264 minecraft:sea_lantern
fill 263 157 265 263 174 265 minecraft:gray_concrete
setblock 263 157 266 minecraft:sea_lantern
fill 263 157 267 263 174 267 minecraft:gray_concrete
setblock 263 157 268 minecraft:sea_lantern
fill 263 157 269 263 174 269 minecraft:gray_concrete
fill 264 157 264 264 174 264 minecraft:gray_concrete
setblock 264 157 265 minecraft:sea_lantern
fill 264 157 266 264 174 266 minecraft:gray_concrete
setblock 264 157 267 minecraft:sea_lantern
fill 264 157 268 264 174 268 minecraft:gray_concrete
setblock 264 157 269 minecraft:sea_lantern
setblock 265 157 264 minecraft:sea_lantern
fill 265 157 265 265 174 265 minecraft:gray_concrete
setblock 265 157 266 minecraft:sea_lantern
fill 265 157 267 265 174 267 minecraft:gray_concrete
setblock 265 157 268 minecraft:sea_lantern
fill 265 157 269 265 174 269 minecraft:gray_concrete
setblock 266 157 231 minecraft:light[level=12]
setblock 266 157 238 minecraft:light[level=12]
setblock 266 157 245 minecraft:light[level=12]
setblock 266 157 252 minecraft:light[level=12]
setblock 266 157 259 minecraft:light[level=12]
fill 266 157 264 266 174 264 minecraft:gray_concrete
setblock 266 157 265 minecraft:sea_lantern
fill 266 157 266 266 174 266 minecraft:gray_concrete
setblock 266 157 267 minecraft:sea_lantern
fill 266 157 268 266 174 268 minecraft:gray_concrete
setblock 266 157 269 minecraft:sea_lantern
setblock 267 157 264 minecraft:sea_lantern
fill 267 157 265 267 174 265 minecraft:gray_concrete
setblock 267 157 266 minecraft:sea_lantern
fill 267 157 267 267 174 267 minecraft:gray_concrete
setblock 267 157 268 minecraft:sea_lantern
fill 267 157 269 267 174 269 minecraft:gray_concrete
setblock 270 157 239 minecraft:light[level=15]
setblock 270 157 247 minecraft:light[level=15]
setblock 270 157 255 minecraft:light[level=15]
setblock 273 157 238 minecraft:light[level=12]
setblock 273 157 259 minecraft:light[level=12]
setblock 235 158 237 minecraft:cyan_concrete
setblock 236 158 230 minecraft:black_stained_glass
setblock 236 158 232 minecraft:black_stained_glass
setblock 236 158 234 minecraft:pearlescent_froglight
setblock 236 158 236 minecraft:black_stained_glass
setblock 236 158 243 minecraft:black_stained_glass
setblock 236 158 245 minecraft:black_stained_glass
setblock 236 158 247 minecraft:black_stained_glass
setblock 236 158 249 minecraft:pearlescent_froglight
setblock 236 158 251 minecraft:ochre_froglight
setblock 236 158 253 minecraft:black_stained_glass
setblock 236 158 262 minecraft:black_stained_glass
setblock 236 158 264 minecraft:cyan_stained_glass
setblock 236 158 266 minecraft:ochre_froglight
setblock 236 158 268 minecraft:cyan_stained_glass
setblock 237 158 229 minecraft:black_stained_glass
setblock 237 158 237 minecraft:black_stained_glass
setblock 237 158 242 minecraft:magenta_stained_glass
setblock 237 158 255 minecraft:black_stained_glass
setblock 237 158 261 minecraft:black_stained_glass
setblock 237 158 269 minecraft:pearlescent_froglight
fill 237 158 270 237 193 270 minecraft:black_concrete
setblock 239 158 229 minecraft:black_stained_glass
setblock 239 158 237 minecraft:black_stained_glass
setblock 239 158 242 minecraft:black_stained_glass
setblock 239 158 255 minecraft:black_stained_glass
setblock 239 158 261 minecraft:black_stained_glass
setblock 239 158 269 minecraft:sea_lantern
fill 240 158 233 243 159 233 minecraft:sea_lantern
setblock 241 158 228 minecraft:pearlescent_froglight
setblock 241 158 229 minecraft:black_stained_glass
setblock 241 158 237 minecraft:black_stained_glass
setblock 241 158 243 minecraft:pearlescent_froglight
setblock 241 158 245 minecraft:sea_lantern
setblock 241 158 247 minecraft:magenta_stained_glass
setblock 241 158 249 minecraft:black_stained_glass
setblock 241 158 251 minecraft:cyan_stained_glass
setblock 241 158 253 minecraft:black_stained_glass
setblock 241 158 261 minecraft:cyan_stained_glass
setblock 241 158 269 minecraft:black_stained_glass
setblock 243 158 229 minecraft:black_stained_glass
setblock 243 158 237 minecraft:light_blue_stained_glass
setblock 243 158 261 minecraft:light_blue_stained_glass
setblock 243 158 269 minecraft:black_stained_glass
setblock 244 158 230 minecraft:ochre_froglight
setblock 244 158 232 minecraft:ochre_froglight
setblock 244 158 233 minecraft:gray_concrete
setblock 244 158 234 minecraft:light_blue_stained_glass
setblock 244 158 236 minecraft:light_blue_stained_glass
setblock 244 158 262 minecraft:pearlescent_froglight
setblock 244 158 264 minecraft:pearlescent_froglight
setblock 244 158 266 minecraft:ochre_froglight
setblock 244 158 268 minecraft:black_stained_glass
fill 247 158 232 253 159 232 minecraft:sea_lantern
setblock 249 158 230 minecraft:light_blue_stained_glass
setblock 249 158 265 minecraft:black_stained_glass
setblock 249 158 267 minecraft:black_stained_glass
setblock 250 158 229 minecraft:ochre_froglight
setblock 250 158 234 minecraft:black_stained_glass
setblock 250 158 269 minecraft:black_stained_glass
setblock 252 158 229 minecraft:cyan_stained_glass
setblock 252 158 234 minecraft:sea_lantern
setblock 252 158 264 minecraft:ochre_froglight
setblock 252 158 269 minecraft:ochre_froglight
setblock 253 158 228 minecraft:sea_lantern
setblock 254 158 229 minecraft:black_stained_glass
fill 254 158 232 255 158 232 minecraft:gray_concrete
setblock 254 158 234 minecraft:pearlescent_froglight
setblock 254 158 264 minecraft:cyan_stained_glass
setblock 254 158 269 minecraft:black_stained_glass
setblock 256 158 229 minecraft:magenta_stained_glass
setblock 256 158 234 minecraft:black_stained_glass
setblock 256 158 264 minecraft:pearlescent_froglight
setblock 256 158 269 minecraft:black_stained_glass
setblock 257 158 232 minecraft:gray_concrete
setblock 258 158 229 minecraft:light_blue_stained_glass
fill 258 158 232 264 159 232 minecraft:sea_lantern
setblock 258 158 234 minecraft:pearlescent_froglight
setblock 258 158 264 minecraft:black_stained_glass
setblock 258 158 269 minecraft:black_stained_glass
setblock 260 158 229 minecraft:black_stained_glass
setblock 260 158 234 minecraft:black_stained_glass
setblock 260 158 264 minecraft:sea_lantern
setblock 260 158 269 minecraft:black_stained_glass
fill 261 158 264 261 159 264 minecraft:gray_concrete
fill 261 158 266 261 159 266 minecraft:gray_concrete
fill 261 158 268 261 159 268 minecraft:gray_concrete
setblock 262 158 230 minecraft:black_stained_glass
setblock 262 158 265 minecraft:cyan_stained_glass
setblock 262 158 267 minecraft:black_stained_glass
fill 262 158 269 262 159 269 minecraft:gray_concrete
fill 263 158 264 263 159 264 minecraft:gray_concrete
fill 263 158 266 263 159 266 minecraft:gray_concrete
fill 263 158 268 263 159 268 minecraft:gray_concrete
fill 264 158 265 264 159 265 minecraft:gray_concrete
fill 264 158 267 264 159 267 minecraft:gray_concrete
fill 264 158 269 264 159 269 minecraft:gray_concrete
fill 265 158 264 265 159 264 minecraft:gray_concrete
fill 265 158 266 265 159 266 minecraft:gray_concrete
fill 265 158 268 265 159 268 minecraft:gray_concrete
fill 266 158 265 266 159 265 minecraft:gray_concrete
fill 266 158 267 266 159 267 minecraft:gray_concrete
fill 266 158 269 266 159 269 minecraft:gray_concrete
fill 267 158 264 267 159 264 minecraft:gray_concrete
fill 267 158 266 267 159 266 minecraft:gray_concrete
fill 267 158 268 267 159 268 minecraft:gray_concrete
setblock 268 158 230 minecraft:ochre_froglight
setblock 268 158 232 minecraft:magenta_stained_glass
setblock 268 158 233 minecraft:blue_terracotta
setblock 268 158 234 minecraft:light_blue_stained_glass
setblock 268 158 236 minecraft:black_stained_glass
setblock 268 158 262 minecraft:black_stained_glass
setblock 268 158 264 minecraft:black_stained_glass
setblock 268 158 266 minecraft:black_stained_glass
setblock 268 158 268 minecraft:cyan_stained_glass
setblock 269 158 229 minecraft:black_stained_glass
fill 269 158 233 272 159 233 minecraft:sea_lantern
setblock 269 158 237 minecraft:ochre_froglight
setblock 269 158 261 minecraft:black_stained_glass
setblock 269 158 269 minecraft:ochre_froglight
setblock 271 158 229 minecraft:black_stained_glass
setblock 271 158 237 minecraft:black_stained_glass
setblock 271 158 243 minecraft:magenta_stained_glass
setblock 271 158 245 minecraft:magenta_stained_glass
setblock 271 158 247 minecraft:magenta_stained_glass
setblock 271 158 249 minecraft:black_stained_glass
setblock 271 158 251 minecraft:light_blue_stained_glass
setblock 271 158 253 minecraft:cyan_stained_glass
setblock 271 158 261 minecraft:sea_lantern
setblock 271 158 269 minecraft:light_blue_stained_glass
setblock 272 158 242 minecraft:black_stained_glass
setblock 272 158 255 minecraft:pearlescent_froglight
setblock 273 158 229 minecraft:black_stained_glass
fill 273 158 233 276 158 233 minecraft:blue_terracotta
setblock 273 158 237 minecraft:black_stained_glass
setblock 273 158 261 minecraft:ochre_froglight
setblock 273 158 269 minecraft:sea_lantern
setblock 274 158 242 minecraft:black_stained_glass
setblock 274 158 255 minecraft:light_blue_stained_glass
setblock 275 158 229 minecraft:black_stained_glass
setblock 275 158 237 minecraft:black_stained_glass
setblock 275 158 261 minecraft:black_stained_glass
fill 275 158 269 275 158 270 minecraft:sea_lantern
setblock 276 158 230 minecraft:ochre_froglight
setblock 276 158 232 minecraft:sea_lantern
setblock 276 158 234 minecraft:sea_lantern
setblock 276 158 236 minecraft:pearlescent_froglight
setblock 276 158 243 minecraft:light_blue_stained_glass
setblock 276 158 245 minecraft:pearlescent_froglight
setblock 276 158 247 minecraft:black_stained_glass
setblock 276 158 249 minecraft:pearlescent_froglight
setblock 276 158 251 minecraft:sea_lantern
setblock 276 158 253 minecraft:light_blue_stained_glass
setblock 276 158 262 minecraft:cyan_stained_glass
setblock 276 158 264 minecraft:cyan_stained_glass
setblock 276 158 266 minecraft:light_blue_stained_glass
setblock 276 158 268 minecraft:black_stained_glass
setblock 277 158 241 minecraft:blue_concrete
fill 235 159 237 235 220 237 minecraft:black_concrete
setblock 235 159 257 minecraft:cyan_concrete
fill 236 159 230 236 160 230 minecraft:gray_concrete
fill 236 159 232 236 160 232 minecraft:gray_concrete
fill 236 159 234 236 160 234 minecraft:gray_concrete
fill 236 159 236 236 160 236 minecraft:gray_concrete
fill 236 159 243 236 160 243 minecraft:black_concrete
fill 236 159 245 236 160 245 minecraft:black_concrete
fill 236 159 247 236 160 247 minecraft:black_concrete
fill 236 159 249 236 160 249 minecraft:black_concrete
fill 236 159 251 236 160 251 minecraft:black_concrete
fill 236 159 253 236 160 253 minecraft:black_concrete
setblock 236 159 262 minecraft:blue_terracotta
setblock 236 159 264 minecraft:blue_terracotta
setblock 236 159 266 minecraft:blue_terracotta
setblock 236 159 268 minecraft:blue_terracotta
fill 237 159 229 237 160 229 minecraft:gray_concrete
fill 237 159 237 237 160 237 minecraft:gray_concrete
fill 237 159 242 237 160 242 minecraft:black_concrete
fill 237 159 255 237 160 255 minecraft:black_concrete
setblock 237 159 261 minecraft:blue_terracotta
setblock 237 159 269 minecraft:blue_terracotta
fill 238 159 231 238 211 234 minecraft:gray_concrete
fill 239 159 229 239 160 229 minecraft:gray_concrete
fill 239 159 231 239 211 232 minecraft:gray_concrete
fill 239 159 233 239 160 233 minecraft:light_blue_stained_glass
fill 239 159 234 239 202 234 minecraft:gray_concrete
fill 239 159 237 239 160 237 minecraft:gray_concrete
fill 239 159 242 239 160 242 minecraft:black_concrete
fill 239 159 255 239 160 255 minecraft:black_concrete
setblock 239 159 261 minecraft:blue_terracotta
setblock 239 159 269 minecraft:blue_terracotta
fill 240 159 231 240 211 231 minecraft:gray_concrete
fill 240 159 232 246 160 232 minecraft:light_blue_stained_glass
fill 240 159 234 242 160 234 minecraft:light_blue_stained_glass
fill 241 159 228 241 308 228 minecraft:black_concrete
fill 241 159 229 241 160 229 minecraft:gray_concrete
fill 241 159 237 241 160 237 minecraft:gray_concrete
fill 241 159 243 241 160 243 minecraft:black_concrete
fill 241 159 245 241 160 245 minecraft:black_concrete
fill 241 159 247 241 160 247 minecraft:black_concrete
fill 241 159 249 241 160 249 minecraft:black_concrete
fill 241 159 251 241 160 251 minecraft:black_concrete
fill 241 159 253 241 160 253 minecraft:black_concrete
setblock 241 159 261 minecraft:blue_terracotta
setblock 241 159 269 minecraft:blue_terracotta
fill 243 159 229 243 160 229 minecraft:gray_concrete
fill 243 159 234 244 160 234 minecraft:gray_concrete
fill 243 159 237 243 160 237 minecraft:gray_concrete
setblock 243 159 261 minecraft:blue_terracotta
setblock 243 159 269 minecraft:blue_terracotta
fill 244 159 230 244 160 230 minecraft:gray_concrete
fill 244 159 233 252 160 233 minecraft:light_blue_stained_glass
fill 244 159 236 244 160 236 minecraft:gray_concrete
setblock 244 159 262 minecraft:blue_terracotta
setblock 244 159 264 minecraft:blue_terracotta
setblock 244 159 266 minecraft:blue_terracotta
setblock 244 159 268 minecraft:blue_terracotta
fill 249 159 230 249 160 230 minecraft:gray_concrete
fill 249 159 231 263 160 231 minecraft:light_blue_stained_glass
fill 249 159 265 249 160 265 minecraft:gray_concrete
fill 249 159 267 249 163 267 minecraft:gray_concrete
fill 250 159 229 252 160 229 minecraft:gray_concrete
fill 250 159 234 250 160 234 minecraft:gray_concrete
fill 250 159 269 250 163 269 minecraft:gray_concrete
fill 251 159 230 251 166 230 minecraft:gray_concrete
fill 252 159 234 252 160 234 minecraft:gray_concrete
fill 252 159 264 252 160 264 minecraft:gray_concrete
fill 252 159 269 252 160 269 minecraft:gray_concrete
fill 253 159 228 253 308 228 minecraft:black_concrete
fill 253 159 233 254 166 233 minecraft:gray_concrete
fill 254 159 229 254 160 229 minecraft:gray_concrete
fill 254 159 232 257 160 232 minecraft:light_blue_stained_glass
fill 254 159 234 254 160 234 minecraft:gray_concrete
fill 254 159 264 254 160 264 minecraft:gray_concrete
fill 254 159 269 254 160 269 minecraft:gray_concrete
fill 256 159 229 256 160 229 minecraft:gray_concrete
fill 256 159 233 256 160 234 minecraft:gray_concrete
fill 256 159 264 256 160 264 minecraft:gray_concrete
fill 256 159 269 256 160 269 minecraft:gray_concrete
fill 257 159 233 258 166 233 minecraft:gray_concrete
fill 258 159 229 258 160 229 minecraft:gray_concrete
fill 258 159 234 258 160 234 minecraft:gray_concrete
fill 258 159 264 258 160 264 minecraft:gray_concrete
fill 258 159 269 258 160 269 minecraft:gray_concrete
fill 259 159 233 268 160 233 minecraft:light_blue_stained_glass
fill 260 159 229 260 160 229 minecraft:gray_concrete
fill 260 159 234 260 160 234 minecraft:gray_concrete
fill 260 159 264 260 160 264 minecraft:gray_concrete
fill 260 159 269 260 160 269 minecraft:gray_concrete
fill 262 159 230 262 160 230 minecraft:gray_concrete
setblock 262 159 265 minecraft:gray_concrete
setblock 262 159 267 minecraft:gray_concrete
fill 265 159 232 272 160 232 minecraft:light_blue_stained_glass
setblock 266 159 270 minecraft:magenta_concrete
fill 268 159 230 268 160 230 minecraft:blue_terracotta
fill 268 159 234 269 160 234 minecraft:blue_terracotta
fill 268 159 236 268 160 236 minecraft:blue_terracotta
fill 268 159 262 268 160 262 minecraft:gray_concrete
fill 268 159 264 268 160 264 minecraft:gray_concrete
fill 268 159 266 268 160 266 minecraft:gray_concrete
fill 268 159 268 268 160 268 minecraft:gray_concrete
fill 269 159 229 269 160 229 minecraft:blue_terracotta
fill 269 159 237 269 160 237 minecraft:blue_terracotta
fill 269 159 261 269 160 261 minecraft:gray_concrete
fill 269 159 269 269 160 269 minecraft:gray_concrete
fill 270 159 234 272 160 234 minecraft:light_blue_stained_glass
fill 271 159 229 271 160 229 minecraft:blue_terracotta
fill 271 159 237 271 160 237 minecraft:blue_terracotta
fill 271 159 243 271 160 243 minecraft:gray_concrete
fill 271 159 245 271 160 245 minecraft:gray_concrete
fill 271 159 247 271 160 247 minecraft:gray_concrete
fill 271 159 249 271 160 249 minecraft:gray_concrete
fill 271 159 251 271 160 251 minecraft:gray_concrete
fill 271 159 253 271 160 253 minecraft:gray_concrete
fill 271 159 261 271 160 261 minecraft:gray_concrete
fill 271 159 269 271 160 269 minecraft:gray_concrete
fill 272 159 242 272 160 242 minecraft:gray_concrete
fill 272 159 255 272 160 255 minecraft:gray_concrete
fill 273 159 229 273 160 229 minecraft:blue_terracotta
fill 273 159 232 276 160 232 minecraft:blue_terracotta
fill 273 159 233 273 160 233 minecraft:light_blue_stained_glass
fill 273 159 234 276 160 234 minecraft:blue_terracotta
fill 273 159 237 273 160 237 minecraft:blue_terracotta
fill 273 159 261 273 160 261 minecraft:gray_concrete
fill 273 159 269 273 160 269 minecraft:gray_concrete
fill 274 159 233 276 180 233 minecraft:blue_terracotta
fill 274 159 242 274 160 242 minecraft:gray_concrete
fill 274 159 255 274 160 255 minecraft:gray_concrete
fill 275 159 229 275 160 229 minecraft:blue_terracotta
fill 275 159 237 275 160 237 minecraft:blue_terracotta
fill 275 159 261 275 160 261 minecraft:gray_concrete
fill 275 159 269 275 160 269 minecraft:gray_concrete
fill 275 159 270 275 219 270 minecraft:black_concrete
fill 276 159 230 276 160 230 minecraft:blue_terracotta
fill 276 159 236 276 160 236 minecraft:blue_terracotta
fill 276 159 243 276 160 243 minecraft:gray_concrete
fill 276 159 245 276 160 245 minecraft:gray_concrete
fill 276 159 247 276 160 247 minecraft:gray_concrete
fill 276 159 249 276 160 249 minecraft:gray_concrete
fill 276 159 251 276 160 251 minecraft:gray_concrete
fill 276 159 253 276 160 253 minecraft:gray_concrete
fill 276 159 262 276 160 262 minecraft:gray_concrete
fill 276 159 264 276 160 264 minecraft:gray_concrete
fill 276 159 266 276 160 266 minecraft:gray_concrete
fill 276 159 268 276 160 268 minecraft:gray_concrete
fill 277 159 241 277 231 241 minecraft:black_concrete
fill 235 160 257 235 305 257 minecraft:black_concrete
setblock 235 160 268 minecraft:purple_concrete
fill 236 160 261 244 160 269 minecraft:black_concrete
fill 240 160 233 243 160 233 minecraft:light_blue_stained_glass
fill 247 160 232 253 160 232 minecraft:light_blue_stained_glass
fill 258 160 232 264 160 232 minecraft:light_blue_stained_glass
setblock 261 160 264 minecraft:sea_lantern
setblock 261 160 266 minecraft:sea_lantern
setblock 261 160 268 minecraft:sea_lantern
setblock 261 160 270 minecraft:sea_lantern
fill 262 160 265 262 161 265 minecraft:sea_lantern
setblock 262 160 267 minecraft:sea_lantern
setblock 262 160 269 minecraft:sea_lantern
setblock 263 160 264 minecraft:sea_lantern
setblock 263 160 266 minecraft:sea_lantern
setblock 263 160 268 minecraft:sea_lantern
setblock 264 160 265 minecraft:sea_lantern
setblock 264 160 267 minecraft:sea_lantern
setblock 264 160 269 minecraft:sea_lantern
setblock 265 160 264 minecraft:sea_lantern
setblock 265 160 266 minecraft:sea_lantern
setblock 265 160 268 minecraft:sea_lantern
setblock 266 160 265 minecraft:sea_lantern
setblock 266 160 267 minecraft:sea_lantern
setblock 266 160 269 minecraft:sea_lantern
fill 266 160 270 266 298 270 minecraft:black_concrete
setblock 267 160 264 minecraft:sea_lantern
setblock 267 160 266 minecraft:sea_lantern
setblock 267 160 268 minecraft:sea_lantern
fill 269 160 233 272 160 233 minecraft:light_blue_stained_glass
setblock 277 160 230 minecraft:verdant_froglight
fill 235 161 268 235 228 268 minecraft:black_concrete
setblock 236 161 230 minecraft:black_stained_glass
setblock 236 161 232 minecraft:black_stained_glass
setblock 236 161 234 minecraft:pearlescent_froglight
setblock 236 161 236 minecraft:cyan_stained_glass
setblock 236 161 243 minecraft:magenta_stained_glass
setblock 236 161 245 minecraft:black_stained_glass
setblock 236 161 247 minecraft:black_stained_glass
setblock 236 161 249 minecraft:cyan_stained_glass
setblock 236 161 251 minecraft:magenta_stained_glass
setblock 236 161 253 minecraft:black_stained_glass
fill 236 161 261 236 161 269 minecraft:verdant_froglight
setblock 237 161 229 minecraft:magenta_stained_glass
setblock 237 161 237 minecraft:pearlescent_froglight
setblock 237 161 242 minecraft:light_blue_stained_glass
setblock 237 161 255 minecraft:sea_lantern
fill 237 161 261 244 161 261 minecraft:verdant_froglight
fill 237 161 269 244 161 269 minecraft:verdant_froglight
setblock 239 161 229 minecraft:black_stained_glass
fill 239 161 233 244 201 233 minecraft:gray_concrete
setblock 239 161 237 minecraft:black_stained_glass
setblock 239 161 242 minecraft:black_stained_glass
setblock 239 161 255 minecraft:pearlescent_froglight
fill 240 161 232 243 202 232 minecraft:gray_concrete
fill 240 161 234 243 188 234 minecraft:gray_concrete
fill 240 161 265 240 171 265 minecraft:iron_bars
setblock 241 161 229 minecraft:pearlescent_froglight
setblock 241 161 237 minecraft:black_stained_glass
setblock 241 161 243 minecraft:pearlescent_froglight
setblock 241 161 245 minecraft:magenta_stained_glass
setblock 241 161 247 minecraft:black_stained_glass
setblock 241 161 249 minecraft:magenta_stained_glass
setblock 241 161 251 minecraft:black_stained_glass
setblock 241 161 253 minecraft:light_blue_stained_glass
setblock 243 161 229 minecraft:black_stained_glass
setblock 243 161 237 minecraft:black_stained_glass
setblock 244 161 230 minecraft:ochre_froglight
setblock 244 161 232 minecraft:black_stained_glass
setblock 244 161 234 minecraft:black_stained_glass
setblock 244 161 236 minecraft:magenta_stained_glass
fill 244 161 262 244 161 268 minecraft:verdant_froglight
setblock 249 161 230 minecraft:ochre_froglight
fill 249 161 231 262 166 231 minecraft:gray_concrete
setblock 249 161 232 minecraft:sea_lantern
fill 249 161 233 252 166 233 minecraft:gray_concrete
setblock 249 161 265 minecraft:black_stained_glass
setblock 250 161 228 minecraft:pearlescent_froglight
setblock 250 161 229 minecraft:black_stained_glass
fill 250 161 232 261 166 232 minecraft:gray_concrete
setblock 250 161 234 minecraft:light_blue_stained_glass
setblock 250 161 264 minecraft:cyan_stained_glass
fill 251 161 229 251 166 229 minecraft:gray_concrete
setblock 252 161 229 minecraft:sea_lantern
setblock 252 161 234 minecraft:black_stained_glass
setblock 252 161 264 minecraft:black_stained_glass
setblock 252 161 269 minecraft:ochre_froglight
setblock 254 161 229 minecraft:black_stained_glass
setblock 254 161 234 minecraft:pearlescent_froglight
setblock 254 161 264 minecraft:black_stained_glass
setblock 254 161 269 minecraft:black_stained_glass
setblock 256 161 229 minecraft:black_stained_glass
fill 256 161 233 256 166 233 minecraft:gray_concrete
setblock 256 161 234 minecraft:black_stained_glass
setblock 256 161 264 minecraft:sea_lantern
setblock 256 161 269 minecraft:pearlescent_froglight
setblock 258 161 229 minecraft:pearlescent_froglight
setblock 258 161 234 minecraft:black_stained_glass
setblock 258 161 264 minecraft:black_stained_glass
setblock 258 161 269 minecraft:black_stained_glass
fill 259 161 233 262 166 233 minecraft:gray_concrete
setblock 260 161 229 minecraft:black_stained_glass
setblock 260 161 234 minecraft:cyan_stained_glass
setblock 260 161 264 minecraft:ochre_froglight
setblock 260 161 269 minecraft:black_stained_glass
fill 261 161 264 261 162 264 minecraft:gray_concrete
fill 261 161 266 261 162 266 minecraft:gray_concrete
fill 261 161 268 261 162 268 minecraft:gray_concrete
fill 261 161 270 261 209 270 minecraft:black_concrete
setblock 262 161 230 minecraft:sea_lantern
setblock 262 161 232 minecraft:black_stained_glass
setblock 262 161 267 minecraft:black_stained_glass
fill 262 161 269 262 162 269 minecraft:gray_concrete
fill 263 161 264 263 162 264 minecraft:gray_concrete
fill 263 161 266 263 162 266 minecraft:gray_concrete
fill 263 161 268 263 162 268 minecraft:gray_concrete
fill 264 161 265 264 162 265 minecraft:gray_concrete
fill 264 161 267 264 162 267 minecraft:gray_concrete
fill 264 161 269 264 162 269 minecraft:gray_concrete
fill 265 161 264 265 162 264 minecraft:gray_concrete
fill 265 161 266 265 162 266 minecraft:gray_concrete
fill 265 161 268 265 162 268 minecraft:gray_concrete
fill 266 161 265 266 162 265 minecraft:gray_concrete
fill 266 161 267 266 162 267 minecraft:gray_concrete
fill 266 161 269 266 162 269 minecraft:gray_concrete
fill 267 161 264 267 162 264 minecraft:gray_concrete
fill 267 161 266 267 162 266 minecraft:gray_concrete
fill 267 161 268 267 162 268 minecraft:gray_concrete
setblock 268 161 230 minecraft:black_stained_glass
setblock 268 161 232 minecraft:light_blue_stained_glass
fill 268 161 233 273 169 233 minecraft:blue_terracotta
setblock 268 161 234 minecraft:ochre_froglight
setblock 268 161 236 minecraft:cyan_stained_glass
setblock 268 161 262 minecraft:black_stained_glass
setblock 268 161 264 minecraft:black_stained_glass
setblock 268 161 266 minecraft:black_stained_glass
setblock 268 161 268 minecraft:light_blue_stained_glass
setblock 269 161 229 minecraft:sea_lantern
fill 269 161 232 275 170 232 minecraft:blue_terracotta
fill 269 161 234 275 169 234 minecraft:blue_terracotta
setblock 269 161 237 minecraft:magenta_stained_glass
setblock 269 161 261 minecraft:black_stained_glass
setblock 269 161 269 minecraft:light_blue_stained_glass
setblock 271 161 229 minecraft:light_blue_stained_glass
setblock 271 161 237 minecraft:sea_lantern
setblock 271 161 243 minecraft:sea_lantern
setblock 271 161 245 minecraft:pearlescent_froglight
setblock 271 161 247 minecraft:black_stained_glass
setblock 271 161 249 minecraft:magenta_stained_glass
setblock 271 161 251 minecraft:sea_lantern
setblock 271 161 253 minecraft:magenta_stained_glass
setblock 271 161 261 minecraft:ochre_froglight
setblock 271 161 269 minecraft:ochre_froglight
setblock 272 161 242 minecraft:black_stained_glass
setblock 272 161 255 minecraft:black_stained_glass
setblock 273 161 229 minecraft:magenta_stained_glass
setblock 273 161 237 minecraft:ochre_froglight
setblock 273 161 261 minecraft:magenta_stained_glass
setblock 273 161 269 minecraft:black_stained_glass
setblock 274 161 242 minecraft:black_stained_glass
setblock 274 161 255 minecraft:sea_lantern
setblock 275 161 229 minecraft:cyan_stained_glass
setblock 275 161 237 minecraft:magenta_stained_glass
setblock 275 161 261 minecraft:light_blue_stained_glass
setblock 275 161 269 minecraft:sea_lantern
setblock 276 161 230 minecraft:black_stained_glass
setblock 276 161 232 minecraft:ochre_froglight
setblock 276 161 234 minecraft:black_stained_glass
setblock 276 161 236 minecraft:magenta_stained_glass
setblock 276 161 243 minecraft:magenta_stained_glass
setblock 276 161 245 minecraft:black_stained_glass
setblock 276 161 247 minecraft:black_stained_glass
setblock 276 161 249 minecraft:black_stained_glass
setblock 276 161 251 minecraft:black_stained_glass
setblock 276 161 253 minecraft:black_stained_glass
setblock 276 161 262 minecraft:ochre_froglight
setblock 276 161 264 minecraft:black_stained_glass
setblock 276 161 266 minecraft:light_blue_stained_glass
setblock 276 161 268 minecraft:light_blue_stained_glass
setblock 277 161 230 minecraft:purple_concrete
setblock 235 162 249 minecraft:pearlescent_froglight
fill 236 162 230 236 163 230 minecraft:gray_concrete
fill 236 162 232 236 163 232 minecraft:gray_concrete
fill 236 162 234 236 163 234 minecraft:gray_concrete
fill 236 162 236 236 163 236 minecraft:gray_concrete
fill 236 162 243 236 163 243 minecraft:black_concrete
fill 236 162 245 236 163 245 minecraft:black_concrete
fill 236 162 247 236 163 247 minecraft:black_concrete
fill 236 162 249 236 163 249 minecraft:black_concrete
fill 236 162 251 236 163 251 minecraft:black_concrete
fill 236 162 253 236 163 253 minecraft:black_concrete
fill 237 162 229 237 163 229 minecraft:gray_concrete
fill 237 162 237 237 163 237 minecraft:gray_concrete
fill 237 162 242 237 163 242 minecraft:black_concrete
fill 237 162 255 237 163 255 minecraft:black_concrete
fill 239 162 229 239 163 229 minecraft:gray_concrete
fill 239 162 237 239 163 237 minecraft:gray_concrete
fill 239 162 242 239 163 242 minecraft:black_concrete
fill 239 162 255 239 163 255 minecraft:black_concrete
fill 241 162 229 241 163 229 minecraft:gray_concrete
fill 241 162 237 241 163 237 minecraft:gray_concrete
fill 241 162 243 241 163 243 minecraft:black_concrete
fill 241 162 245 241 163 245 minecraft:black_concrete
fill 241 162 247 241 163 247 minecraft:black_concrete
fill 241 162 249 241 163 249 minecraft:black_concrete
fill 241 162 251 241 163 251 minecraft:black_concrete
fill 241 162 253 241 163 253 minecraft:black_concrete
fill 243 162 229 243 163 229 minecraft:gray_concrete
fill 243 162 237 243 163 237 minecraft:gray_concrete
fill 244 162 230 244 163 230 minecraft:gray_concrete
fill 244 162 232 244 163 232 minecraft:gray_concrete
fill 244 162 234 244 163 234 minecraft:gray_concrete
fill 244 162 236 244 163 236 minecraft:gray_concrete
setblock 248 162 228 minecraft:magenta_concrete
fill 249 162 230 249 163 230 minecraft:gray_concrete
fill 249 162 232 249 163 232 minecraft:gray_concrete
fill 249 162 265 249 163 265 minecraft:gray_concrete
fill 250 162 228 250 228 228 minecraft:black_concrete
fill 250 162 229 250 163 229 minecraft:gray_concrete
fill 250 162 234 250 163 234 minecraft:gray_concrete
fill 250 162 264 250 166 264 minecraft:gray_concrete
fill 252 162 229 252 163 229 minecraft:gray_concrete
fill 252 162 234 252 163 234 minecraft:gray_concrete
fill 252 162 264 252 163 264 minecraft:gray_concrete
fill 252 162 269 252 163 269 minecraft:gray_concrete
fill 254 162 229 254 163 229 minecraft:gray_concrete
fill 254 162 234 254 163 234 minecraft:gray_concrete
fill 254 162 264 254 163 264 minecraft:gray_concrete
fill 254 162 269 254 163 269 minecraft:gray_concrete
fill 256 162 229 256 163 229 minecraft:gray_concrete
fill 256 162 234 256 163 234 minecraft:gray_concrete
fill 256 162 264 256 163 264 minecraft:gray_concrete
fill 256 162 269 256 163 269 minecraft:gray_concrete
fill 258 162 229 258 163 229 minecraft:gray_concrete
fill 258 162 234 258 163 234 minecraft:gray_concrete
fill 258 162 264 258 163 264 minecraft:gray_concrete
fill 258 162 269 258 163 269 minecraft:gray_concrete
fill 260 162 229 260 163 229 minecraft:gray_concrete
fill 260 162 234 260 163 234 minecraft:gray_concrete
fill 260 162 264 260 163 264 minecraft:gray_concrete
fill 260 162 269 260 163 269 minecraft:gray_concrete
fill 262 162 230 262 163 230 minecraft:gray_concrete
fill 262 162 232 262 163 232 minecraft:gray_concrete
setblock 262 162 265 minecraft:gray_concrete
setblock 262 162 267 minecraft:gray_concrete
fill 268 162 230 268 163 230 minecraft:blue_terracotta
fill 268 162 232 268 163 232 minecraft:blue_terracotta
fill 268 162 234 268 163 234 minecraft:blue_terracotta
fill 268 162 236 268 163 236 minecraft:blue_terracotta
fill 268 162 262 268 163 262 minecraft:gray_concrete
fill 268 162 264 268 163 264 minecraft:gray_concrete
fill 268 162 266 268 163 266 minecraft:gray_concrete
fill 268 162 268 268 163 268 minecraft:gray_concrete
fill 269 162 229 269 163 229 minecraft:blue_terracotta
fill 269 162 237 269 163 237 minecraft:blue_terracotta
fill 269 162 261 269 163 261 minecraft:gray_concrete
fill 269 162 269 269 163 269 minecraft:gray_concrete
fill 271 162 229 271 163 229 minecraft:blue_terracotta
fill 271 162 237 271 163 237 minecraft:blue_terracotta
fill 271 162 243 271 163 243 minecraft:gray_concrete
fill 271 162 245 271 163 245 minecraft:gray_concrete
fill 271 162 247 271 163 247 minecraft:gray_concrete
fill 271 162 249 271 163 249 minecraft:gray_concrete
fill 271 162 251 271 163 251 minecraft:gray_concrete
fill 271 162 253 271 163 253 minecraft:gray_concrete
fill 271 162 261 271 163 261 minecraft:gray_concrete
fill 271 162 269 271 163 269 minecraft:gray_concrete
fill 272 162 242 272 163 242 minecraft:gray_concrete
fill 272 162 255 272 163 255 minecraft:gray_concrete
setblock 272 162 270 minecraft:verdant_froglight
fill 273 162 229 273 163 229 minecraft:blue_terracotta
fill 273 162 237 273 163 237 minecraft:blue_terracotta
fill 273 162 261 273 163 261 minecraft:gray_concrete
fill 273 162 269 273 163 269 minecraft:gray_concrete
fill 274 162 242 274 163 242 minecraft:gray_concrete
fill 274 162 255 274 163 255 minecraft:gray_concrete
fill 275 162 229 275 163 229 minecraft:blue_terracotta
fill 275 162 237 275 163 237 minecraft:blue_terracotta
fill 275 162 261 275 163 261 minecraft:gray_concrete
fill 275 162 269 275 163 269 minecraft:gray_concrete
fill 276 162 230 276 163 230 minecraft:blue_terracotta
fill 276 162 232 276 163 232 minecraft:blue_terracotta
fill 276 162 234 276 163 234 minecraft:blue_terracotta
fill 276 162 236 276 163 236 minecraft:blue_terracotta
fill 276 162 243 276 163 243 minecraft:gray_concrete
fill 276 162 245 276 163 245 minecraft:gray_concrete
fill 276 162 247 276 163 247 minecraft:gray_concrete
fill 276 162 249 276 163 249 minecraft:gray_concrete
fill 276 162 251 276 163 251 minecraft:gray_concrete
fill 276 162 253 276 163 253 minecraft:gray_concrete
fill 276 162 262 276 163 262 minecraft:gray_concrete
fill 276 162 264 276 163 264 minecraft:gray_concrete
fill 276 162 266 276 163 266 minecraft:gray_concrete
fill 276 162 268 276 163 268 minecraft:gray_concrete
fill 277 162 230 277 205 230 minecraft:black_concrete
setblock 235 163 230 minecraft:sea_lantern
fill 235 163 249 235 187 249 minecraft:black_concrete
setblock 238 163 238 minecraft:light[level=12]
setblock 238 163 259 minecraft:light[level=12]
setblock 238 163 266 minecraft:light[level=12]
setblock 240 163 228 minecraft:blue_concrete
setblock 245 163 231 minecraft:light[level=12]
setblock 245 163 238 minecraft:light[level=12]
setblock 245 163 245 minecraft:light[level=12]
setblock 245 163 252 minecraft:light[level=12]
setblock 245 163 259 minecraft:light[level=12]
setblock 245 163 266 minecraft:light[level=12]
setblock 246 163 270 minecraft:ochre_froglight
fill 248 163 228 248 308 228 minecraft:black_concrete
setblock 252 163 238 minecraft:light[level=12]
setblock 252 163 245 minecraft:light[level=12]
setblock 252 163 252 minecraft:light[level=12]
setblock 252 163 259 minecraft:light[level=12]
setblock 259 163 238 minecraft:light[level=12]
setblock 259 163 245 minecraft:light[level=12]
setblock 259 163 252 minecraft:light[level=12]
setblock 259 163 259 minecraft:light[level=12]
setblock 261 163 264 minecraft:sea_lantern
setblock 261 163 266 minecraft:sea_lantern
setblock 261 163 268 minecraft:sea_lantern
setblock 262 163 265 minecraft:sea_lantern
setblock 262 163 267 minecraft:sea_lantern
setblock 262 163 269 minecraft:sea_lantern
setblock 263 163 264 minecraft:sea_lantern
setblock 263 163 266 minecraft:sea_lantern
setblock 263 163 268 minecraft:sea_lantern
setblock 264 163 265 minecraft:sea_lantern
setblock 264 163 267 minecraft:sea_lantern
setblock 264 163 269 minecraft:sea_lantern
setblock 265 163 264 minecraft:sea_lantern
setblock 265 163 266 minecraft:sea_lantern
setblock 265 163 268 minecraft:sea_lantern
setblock 266 163 231 minecraft:light[level=12]
setblock 266 163 238 minecraft:light[level=12]
setblock 266 163 245 minecraft:light[level=12]
setblock 266 163 252 minecraft:light[level=12]
setblock 266 163 259 minecraft:light[level=12]
setblock 266 163 265 minecraft:sea_lantern
setblock 266 163 267 minecraft:sea_lantern
setblock 266 163 269 minecraft:sea_lantern
setblock 267 163 264 minecraft:sea_lantern
setblock 267 163 266 minecraft:sea_lantern
setblock 267 163 268 minecraft:sea_lantern
fill 272 163 270 272 296 270 minecraft:black_concrete
setblock 273 163 238 minecraft:light[level=12]
setblock 273 163 259 minecraft:light[level=12]
setblock 277 163 240 minecraft:magenta_concrete
setblock 277 163 262 minecraft:magenta_concrete
fill 235 164 230 235 181 230 minecraft:black_concrete
setblock 236 164 230 minecraft:black_stained_glass
setblock 236 164 232 minecraft:black_stained_glass
setblock 236 164 234 minecraft:pearlescent_froglight
setblock 236 164 236 minecraft:black_stained_glass
setblock 236 164 243 minecraft:sea_lantern
setblock 236 164 245 minecraft:black_stained_glass
setblock 236 164 247 minecraft:black_stained_glass
setblock 236 164 249 minecraft:black_stained_glass
setblock 236 164 251 minecraft:black_stained_glass
setblock 236 164 253 minecraft:sea_lantern
setblock 237 164 229 minecraft:black_stained_glass
setblock 237 164 237 minecraft:black_stained_glass
setblock 237 164 242 minecraft:magenta_stained_glass
setblock 237 164 255 minecraft:black_stained_glass
setblock 238 164 239 minecraft:light[level=15]
setblock 238 164 263 minecraft:light[level=15]
setblock 239 164 229 minecraft:light_blue_stained_glass
setblock 239 164 237 minecraft:cyan_stained_glass
setblock 239 164 242 minecraft:black_stained_glass
setblock 239 164 255 minecraft:black_stained_glass
fill 240 164 228 240 244 228 minecraft:black_concrete
setblock 241 164 229 minecraft:black_stained_glass
setblock 241 164 237 minecraft:magenta_stained_glass
setblock 241 164 243 minecraft:black_stained_glass
setblock 241 164 245 minecraft:black_stained_glass
setblock 241 164 247 minecraft:cyan_stained_glass
setblock 241 164 249 minecraft:black_stained_glass
setblock 241 164 251 minecraft:black_stained_glass
setblock 241 164 253 minecraft:black_stained_glass
setblock 243 164 229 minecraft:sea_lantern
setblock 243 164 237 minecraft:black_stained_glass
setblock 244 164 230 minecraft:pearlescent_froglight
setblock 244 164 232 minecraft:black_stained_glass
setblock 244 164 234 minecraft:pearlescent_froglight
setblock 244 164 236 minecraft:black_stained_glass
setblock 245 164 228 minecraft:blue_concrete
setblock 246 164 231 minecraft:light[level=15]
setblock 246 164 239 minecraft:light[level=15]
setblock 246 164 247 minecraft:light[level=15]
setblock 246 164 255 minecraft:light[level=15]
fill 246 164 270 246 222 270 minecraft:black_concrete
setblock 249 164 230 minecraft:black_stained_glass
setblock 249 164 232 minecraft:ochre_froglight
setblock 249 164 265 minecraft:black_stained_glass
setblock 249 164 267 minecraft:pearlescent_froglight
setblock 250 164 229 minecraft:magenta_stained_glass
setblock 250 164 234 minecraft:cyan_stained_glass
setblock 250 164 269 minecraft:black_stained_glass
setblock 252 164 229 minecraft:magenta_stained_glass
setblock 252 164 234 minecraft:cyan_stained_glass
setblock 252 164 264 minecraft:black_stained_glass
setblock 252 164 269 minecraft:magenta_stained_glass
setblock 254 164 229 minecraft:pearlescent_froglight
setblock 254 164 234 minecraft:sea_lantern
setblock 254 164 239 minecraft:light[level=15]
setblock 254 164 247 minecraft:light[level=15]
setblock 254 164 255 minecraft:light[level=15]
setblock 254 164 264 minecraft:magenta_stained_glass
setblock 254 164 269 minecraft:sea_lantern
setblock 256 164 229 minecraft:light_blue_stained_glass
setblock 256 164 234 minecraft:sea_lantern
setblock 256 164 264 minecraft:black_stained_glass
setblock 256 164 269 minecraft:black_stained_glass
setblock 258 164 229 minecraft:ochre_froglight
setblock 258 164 234 minecraft:magenta_stained_glass
setblock 258 164 264 minecraft:black_stained_glass
setblock 258 164 269 minecraft:black_stained_glass
setblock 260 164 229 minecraft:black_stained_glass
setblock 260 164 234 minecraft:magenta_stained_glass
setblock 260 164 264 minecraft:light_blue_stained_glass
setblock 260 164 269 minecraft:black_stained_glass
fill 261 164 264 261 165 264 minecraft:gray_concrete
fill 261 164 266 261 165 266 minecraft:gray_concrete
fill 261 164 268 261 165 268 minecraft:gray_concrete
setblock 262 164 230 minecraft:sea_lantern
setblock 262 164 232 minecraft:pearlescent_froglight
setblock 262 164 239 minecraft:light[level=15]
setblock 262 164 247 minecraft:light[level=15]
setblock 262 164 255 minecraft:light[level=15]
setblock 262 164 263 minecraft:light[level=15]
setblock 262 164 265 minecraft:black_stained_glass
setblock 262 164 267 minecraft:ochre_froglight
fill 262 164 269 262 165 269 minecraft:gray_concrete
fill 263 164 264 263 165 264 minecraft:gray_concrete
fill 263 164 266 263 165 266 minecraft:gray_concrete
fill 263 164 268 263 165 268 minecraft:gray_concrete
fill 264 164 265 264 165 265 minecraft:gray_concrete
fill 264 164 267 264 165 267 minecraft:gray_concrete
fill 264 164 269 264 165 269 minecraft:gray_concrete
fill 265 164 264 265 165 264 minecraft:gray_concrete
fill 265 164 266 265 165 266 minecraft:gray_concrete
fill 265 164 268 265 165 268 minecraft:gray_concrete
fill 266 164 265 266 165 265 minecraft:gray_concrete
fill 266 164 267 266 165 267 minecraft:gray_concrete
fill 266 164 269 266 165 269 minecraft:gray_concrete
fill 267 164 264 267 165 264 minecraft:gray_concrete
fill 267 164 266 267 165 266 minecraft:gray_concrete
fill 267 164 268 267 165 268 minecraft:gray_concrete
setblock 268 164 230 minecraft:ochre_froglight
setblock 268 164 232 minecraft:light_blue_stained_glass
setblock 268 164 234 minecraft:cyan_stained_glass
setblock 268 164 236 minecraft:pearlescent_froglight
setblock 268 164 262 minecraft:sea_lantern
setblock 268 164 264 minecraft:black_stained_glass
setblock 268 164 266 minecraft:sea_lantern
setblock 268 164 268 minecraft:black_stained_glass
setblock 269 164 229 minecraft:cyan_stained_glass
setblock 269 164 237 minecraft:pearlescent_froglight
setblock 269 164 261 minecraft:sea_lantern
setblock 269 164 269 minecraft:pearlescent_froglight
setblock 270 164 239 minecraft:light[level=15]
setblock 270 164 247 minecraft:light[level=15]
setblock 270 164 255 minecraft:light[level=15]
setblock 271 164 229 minecraft:magenta_stained_glass
setblock 271 164 237 minecraft:black_stained_glass
setblock 271 164 243 minecraft:ochre_froglight
setblock 271 164 245 minecraft:magenta_stained_glass
setblock 271 164 247 minecraft:pearlescent_froglight
setblock 271 164 249 minecraft:black_stained_glass
setblock 271 164 251 minecraft:ochre_froglight
setblock 271 164 253 minecraft:black_stained_glass
setblock 271 164 261 minecraft:magenta_stained_glass
setblock 271 164 269 minecraft:ochre_froglight
setblock 272 164 242 minecraft:light_blue_stained_glass
setblock 272 164 255 minecraft:black_stained_glass
setblock 273 164 229 minecraft:cyan_stained_glass
setblock 273 164 237 minecraft:cyan_stained_glass
setblock 273 164 261 minecraft:light_blue_stained_glass
setblock 273 164 269 minecraft:light_blue_stained_glass
setblock 274 164 242 minecraft:cyan_stained_glass
setblock 274 164 255 minecraft:sea_lantern
setblock 275 164 229 minecraft:cyan_stained_glass
setblock 275 164 237 minecraft:light_blue_stained_glass
setblock 275 164 261 minecraft:pearlescent_froglight
setblock 275 164 269 minecraft:magenta_stained_glass
setblock 276 164 230 minecraft:black_stained_glass
setblock 276 164 232 minecraft:black_stained_glass
setblock 276 164 234 minecraft:black_stained_glass
setblock 276 164 236 minecraft:black_stained_glass
setblock 276 164 243 minecraft:black_stained_glass
setblock 276 164 245 minecraft:black_stained_glass
setblock 276 164 247 minecraft:cyan_stained_glass
setblock 276 164 249 minecraft:magenta_stained_glass
setblock 276 164 251 minecraft:sea_lantern
setblock 276 164 253 minecraft:black_stained_glass
setblock 276 164 262 minecraft:magenta_stained_glass
setblock 276 164 264 minecraft:sea_lantern
setblock 276 164 266 minecraft:black_stained_glass
setblock 276 164 268 minecraft:black_stained_glass
setblock 276 164 270 minecraft:cyan_concrete
fill 277 164 240 277 199 240 minecraft:black_concrete
fill 277 164 262 277 167 262 minecraft:black_concrete
fill 277 164 270 277 308 270 minecraft:black_concrete
setblock 235 165 245 minecraft:sea_lantern
fill 236 165 230 236 166 230 minecraft:gray_concrete
fill 236 165 232 236 166 232 minecraft:gray_concrete
fill 236 165 234 236 166 234 minecraft:gray_concrete
fill 236 165 236 236 166 236 minecraft:gray_concrete
fill 236 165 243 236 166 243 minecraft:black_concrete
fill 236 165 245 236 166 245 minecraft:black_concrete
fill 236 165 247 236 166 247 minecraft:black_concrete
fill 236 165 249 236 166 249 minecraft:black_concrete
fill 236 165 251 236 166 251 minecraft:black_concrete
fill 236 165 253 236 166 253 minecraft:black_concrete
fill 237 165 229 237 166 229 minecraft:gray_concrete
fill 237 165 237 237 166 237 minecraft:gray_concrete
fill 237 165 242 237 166 242 minecraft:black_concrete
fill 237 165 255 237 166 255 minecraft:black_concrete
fill 239 165 229 239 166 229 minecraft:gray_concrete
fill 239 165 237 239 166 237 minecraft:gray_concrete
fill 239 165 242 239 166 242 minecraft:black_concrete
fill 239 165 255 239 166 255 minecraft:black_concrete
fill 241 165 229 241 166 229 minecraft:gray_concrete
fill 241 165 237 241 166 237 minecraft:gray_concrete
fill 241 165 243 241 166 243 minecraft:black_concrete
fill 241 165 245 241 166 245 minecraft:black_concrete
fill 241 165 247 241 166 247 minecraft:black_concrete
fill 241 165 249 241 166 249 minecraft:black_concrete
fill 241 165 251 241 166 251 minecraft:black_concrete
fill 241 165 253 241 166 253 minecraft:black_concrete
fill 243 165 229 243 166 229 minecraft:gray_concrete
fill 243 165 237 243 166 237 minecraft:gray_concrete
fill 244 165 230 244 166 230 minecraft:gray_concrete
fill 244 165 232 244 166 232 minecraft:gray_concrete
fill 244 165 234 244 166 234 minecraft:gray_concrete
fill 244 165 236 244 166 236 minecraft:gray_concrete
setblock 245 165 228 minecraft:black_concrete
fill 249 165 230 249 166 230 minecraft:gray_concrete
fill 249 165 232 249 166 232 minecraft:gray_concrete
fill 249 165 265 249 166 265 minecraft:gray_concrete
fill 249 165 267 249 166 267 minecraft:gray_concrete
fill 250 165 229 250 166 229 minecraft:gray_concrete
fill 250 165 234 250 166 234 minecraft:gray_concrete
fill 250 165 269 250 166 269 minecraft:gray_concrete
fill 252 165 229 252 166 229 minecraft:gray_concrete
fill 252 165 234 252 166 234 minecraft:gray_concrete
fill 252 165 264 252 166 264 minecraft:gray_concrete
fill 252 165 269 252 166 269 minecraft:gray_concrete
fill 254 165 229 254 166 229 minecraft:gray_concrete
fill 254 165 234 254 166 234 minecraft:gray_concrete
fill 254 165 264 254 166 264 minecraft:gray_concrete
fill 254 165 269 254 166 269 minecraft:gray_concrete
fill 256 165 229 256 166 229 minecraft:gray_concrete
fill 256 165 234 256 166 234 minecraft:gray_concrete
fill 256 165 264 256 166 264 minecraft:gray_concrete
fill 256 165 269 256 169 269 minecraft:gray_concrete
fill 258 165 229 258 166 229 minecraft:gray_concrete
fill 258 165 234 258 166 234 minecraft:gray_concrete
fill 258 165 264 258 166 264 minecraft:gray_concrete
fill 258 165 269 258 166 269 minecraft:gray_concrete
fill 260 165 229 260 166 229 minecraft:gray_concrete
fill 260 165 234 260 166 234 minecraft:gray_concrete
fill 260 165 264 260 166 264 minecraft:gray_concrete
fill 260 165 269 260 166 269 minecraft:gray_concrete
fill 262 165 230 262 166 230 minecraft:gray_concrete
fill 262 165 232 262 166 232 minecraft:gray_concrete
setblock 262 165 265 minecraft:gray_concrete
setblock 262 165 267 minecraft:gray_concrete
setblock 268 165 228 minecraft:verdant_froglight
fill 268 165 230 268 166 230 minecraft:blue_terracotta
fill 268 165 232 268 166 232 minecraft:blue_terracotta
fill 268 165 234 268 166 234 minecraft:blue_terracotta
fill 268 165 236 268 166 236 minecraft:blue_terracotta
fill 268 165 262 268 166 262 minecraft:gray_concrete
fill 268 165 264 268 166 264 minecraft:gray_concrete
fill 268 165 266 268 166 266 minecraft:gray_concrete
fill 268 165 268 268 166 268 minecraft:gray_concrete
fill 269 165 229 269 166 229 minecraft:blue_terracotta
fill 269 165 237 269 166 237 minecraft:blue_terracotta
fill 269 165 261 269 166 261 minecraft:gray_concrete
fill 269 165 269 269 166 269 minecraft:gray_concrete
fill 271 165 229 271 166 229 minecraft:blue_terracotta
fill 271 165 237 271 166 237 minecraft:blue_terracotta
fill 271 165 243 271 166 243 minecraft:gray_concrete
fill 271 165 245 271 166 245 minecraft:gray_concrete
fill 271 165 247 271 166 247 minecraft:gray_concrete
fill 271 165 249 271 166 249 minecraft:gray_concrete
fill 271 165 251 271 166 251 minecraft:gray_concrete
fill 271 165 253 271 166 253 minecraft:gray_concrete
fill 271 165 261 271 166 261 minecraft:gray_concrete
fill 271 165 269 271 166 269 minecraft:gray_concrete
fill 272 165 242 272 166 242 minecraft:gray_concrete
fill 272 165 255 272 166 255 minecraft:gray_concrete
fill 273 165 229 273 166 229 minecraft:blue_terracotta
fill 273 165 237 273 166 237 minecraft:blue_terracotta
fill 273 165 261 273 166 261 minecraft:gray_concrete
fill 273 165 269 273 166 269 minecraft:gray_concrete
fill 274 165 242 274 166 242 minecraft:gray_concrete
fill 274 165 255 274 166 255 minecraft:gray_concrete
fill 275 165 229 275 166 229 minecraft:blue_terracotta
fill 275 165 237 275 166 237 minecraft:blue_terracotta
fill 275 165 261 275 166 261 minecraft:gray_concrete
fill 275 165 269 275 166 269 minecraft:gray_concrete
fill 276 165 230 276 166 230 minecraft:blue_terracotta
fill 276 165 232 276 166 232 minecraft:blue_terracotta
fill 276 165 234 276 166 234 minecraft:blue_terracotta
fill 276 165 236 276 166 236 minecraft:blue_terracotta
fill 276 165 243 276 166 243 minecraft:gray_concrete
fill 276 165 245 276 166 245 minecraft:gray_concrete
fill 276 165 247 276 166 247 minecraft:gray_concrete
fill 276 165 249 276 166 249 minecraft:gray_concrete
fill 276 165 251 276 166 251 minecraft:gray_concrete
fill 276 165 253 276 166 253 minecraft:gray_concrete
fill 276 165 262 276 166 262 minecraft:gray_concrete
fill 276 165 264 276 166 264 minecraft:gray_concrete
fill 276 165 266 276 166 266 minecraft:gray_concrete
fill 276 165 268 276 166 268 minecraft:gray_concrete
fill 276 165 270 276 228 270 minecraft:black_concrete
fill 235 166 245 235 237 245 minecraft:black_concrete
setblock 244 166 228 minecraft:magenta_concrete
setblock 245 166 228 minecraft:purple_concrete
setblock 261 166 264 minecraft:sea_lantern
setblock 261 166 266 minecraft:sea_lantern
setblock 261 166 268 minecraft:sea_lantern
setblock 262 166 265 minecraft:sea_lantern
setblock 262 166 267 minecraft:sea_lantern
setblock 262 166 269 minecraft:sea_lantern
setblock 263 166 264 minecraft:sea_lantern
setblock 263 166 266 minecraft:sea_lantern
setblock 263 166 268 minecraft:sea_lantern
setblock 264 166 265 minecraft:sea_lantern
setblock 264 166 267 minecraft:sea_lantern
setblock 264 166 269 minecraft:sea_lantern
setblock 265 166 264 minecraft:sea_lantern
setblock 265 166 266 minecraft:sea_lantern
setblock 265 166 268 minecraft:sea_lantern
setblock 266 166 265 minecraft:sea_lantern
setblock 266 166 267 minecraft:sea_lantern
setblock 266 166 269 minecraft:sea_lantern
setblock 267 166 264 minecraft:sea_lantern
setblock 267 166 266 minecraft:sea_lantern
setblock 267 166 268 minecraft:sea_lantern
fill 268 166 228 268 266 228 minecraft:black_concrete
setblock 235 167 258 minecraft:purple_concrete
setblock 236 167 230 minecraft:black_stained_glass
setblock 236 167 232 minecraft:ochre_froglight
setblock 236 167 234 minecraft:black_stained_glass
setblock 236 167 236 minecraft:pearlescent_froglight
setblock 236 167 243 minecraft:black_stained_glass
setblock 236 167 245 minecraft:ochre_froglight
setblock 236 167 247 minecraft:ochre_froglight
setblock 236 167 249 minecraft:pearlescent_froglight
setblock 236 167 251 minecraft:black_stained_glass
setblock 236 167 253 minecraft:black_stained_glass
setblock 237 167 229 minecraft:magenta_stained_glass
setblock 237 167 237 minecraft:pearlescent_froglight
setblock 237 167 242 minecraft:black_stained_glass
setblock 237 167 255 minecraft:black_stained_glass
setblock 239 167 229 minecraft:cyan_stained_glass
setblock 239 167 237 minecraft:black_stained_glass
setblock 239 167 242 minecraft:black_stained_glass
setblock 239 167 255 minecraft:black_stained_glass
setblock 241 167 229 minecraft:magenta_stained_glass
setblock 241 167 237 minecraft:ochre_froglight
setblock 241 167 243 minecraft:ochre_froglight
setblock 241 167 245 minecraft:black_stained_glass
setblock 241 167 247 minecraft:pearlescent_froglight
setblock 241 167 249 minecraft:pearlescent_froglight
setblock 241 167 251 minecraft:black_stained_glass
setblock 241 167 253 minecraft:black_stained_glass
fill 242 167 251 245 168 251 minecraft:gray_concrete
setblock 243 167 229 minecraft:light_blue_stained_glass
setblock 243 167 237 minecraft:light_blue_stained_glass
setblock 244 167 228 minecraft:pearlescent_froglight
setblock 244 167 230 minecraft:black_stained_glass
setblock 244 167 232 minecraft:pearlescent_froglight
setblock 244 167 234 minecraft:pearlescent_froglight
setblock 244 167 236 minecraft:black_stained_glass
setblock 245 167 228 minecraft:black_concrete
fill 249 167 229 262 167 234 minecraft:black_concrete
setblock 249 167 265 minecraft:magenta_stained_glass
setblock 249 167 267 minecraft:black_stained_glass
setblock 250 167 264 minecraft:black_stained_glass
setblock 250 167 269 minecraft:cyan_stained_glass
setblock 252 167 264 minecraft:black_stained_glass
setblock 252 167 269 minecraft:ochre_froglight
setblock 254 167 264 minecraft:sea_lantern
setblock 254 167 269 minecraft:sea_lantern
setblock 256 167 264 minecraft:cyan_stained_glass
setblock 258 167 264 minecraft:magenta_stained_glass
setblock 258 167 269 minecraft:black_stained_glass
setblock 260 167 264 minecraft:pearlescent_froglight
setblock 260 167 269 minecraft:black_stained_glass
fill 261 167 264 261 168 264 minecraft:gray_concrete
fill 261 167 266 261 168 266 minecraft:gray_concrete
fill 261 167 268 261 168 268 minecraft:gray_concrete
setblock 262 167 265 minecraft:pearlescent_froglight
setblock 262 167 267 minecraft:black_stained_glass
fill 262 167 269 262 168 269 minecraft:gray_concrete
setblock 262 167 270 minecraft:cyan_concrete
fill 263 167 264 263 168 264 minecraft:gray_concrete
fill 263 167 266 263 168 266 minecraft:gray_concrete
fill 263 167 268 263 168 268 minecraft:gray_concrete
fill 264 167 265 264 168 265 minecraft:gray_concrete
fill 264 167 267 264 168 267 minecraft:gray_concrete
fill 264 167 269 264 168 269 minecraft:gray_concrete
fill 265 167 264 265 168 264 minecraft:gray_concrete
fill 265 167 266 265 168 266 minecraft:gray_concrete
fill 265 167 268 265 168 268 minecraft:gray_concrete
fill 266 167 265 266 168 265 minecraft:gray_concrete
fill 266 167 267 266 168 267 minecraft:gray_concrete
fill 266 167 269 266 168 269 minecraft:gray_concrete
fill 267 167 264 267 168 264 minecraft:gray_concrete
fill 267 167 266 267 168 266 minecraft:gray_concrete
fill 267 167 268 267 168 268 minecraft:gray_concrete
setblock 268 167 230 minecraft:black_stained_glass
setblock 268 167 232 minecraft:ochre_froglight
setblock 268 167 234 minecraft:light_blue_stained_glass
setblock 268 167 236 minecraft:cyan_stained_glass
setblock 268 167 262 minecraft:black_stained_glass
setblock 268 167 264 minecraft:ochre_froglight
setblock 268 167 266 minecraft:ochre_froglight
setblock 268 167 268 minecraft:sea_lantern
setblock 269 167 229 minecraft:ochre_froglight
setblock 269 167 237 minecraft:ochre_froglight
setblock 269 167 261 minecraft:cyan_stained_glass
setblock 269 167 269 minecraft:magenta_stained_glass
setblock 271 167 229 minecraft:magenta_stained_glass
setblock 271 167 237 minecraft:light_blue_stained_glass
setblock 271 167 243 minecraft:pearlescent_froglight
setblock 271 167 245 minecraft:ochre_froglight
setblock 271 167 247 minecraft:cyan_stained_glass
setblock 271 167 249 minecraft:black_stained_glass
setblock 271 167 251 minecraft:magenta_stained_glass
setblock 271 167 253 minecraft:magenta_stained_glass
setblock 271 167 261 minecraft:pearlescent_froglight
setblock 271 167 269 minecraft:sea_lantern
setblock 272 167 242 minecraft:black_stained_glass
setblock 272 167 255 minecraft:black_stained_glass
setblock 273 167 229 minecraft:cyan_stained_glass
setblock 273 167 237 minecraft:black_stained_glass
setblock 273 167 261 minecraft:black_stained_glass
setblock 273 167 269 minecraft:sea_lantern
setblock 274 167 242 minecraft:black_stained_glass
setblock 274 167 255 minecraft:cyan_stained_glass
setblock 275 167 229 minecraft:black_stained_glass
setblock 275 167 237 minecraft:ochre_froglight
setblock 275 167 261 minecraft:magenta_stained_glass
setblock 275 167 269 minecraft:light_blue_stained_glass
setblock 276 167 230 minecraft:black_stained_glass
setblock 276 167 232 minecraft:black_stained_glass
setblock 276 167 234 minecraft:ochre_froglight
setblock 276 167 236 minecraft:black_stained_glass
setblock 276 167 243 minecraft:black_stained_glass
setblock 276 167 245 minecraft:sea_lantern
setblock 276 167 247 minecraft:light_blue_stained_glass
setblock 276 167 249 minecraft:pearlescent_froglight
setblock 276 167 251 minecraft:cyan_stained_glass
setblock 276 167 253 minecraft:black_stained_glass
setblock 276 167 262 minecraft:pearlescent_froglight
setblock 276 167 264 minecraft:black_stained_glass
setblock 276 167 266 minecraft:black_stained_glass
setblock 276 167 268 minecraft:pearlescent_froglight
setblock 277 167 265 minecraft:cyan_concrete
setblock 235 168 231 minecraft:ochre_froglight
fill 235 168 258 235 176 258 minecraft:black_concrete
fill 236 168 230 236 169 230 minecraft:gray_concrete
fill 236 168 232 236 169 232 minecraft:gray_concrete
fill 236 168 234 236 169 234 minecraft:gray_concrete
fill 236 168 236 236 169 236 minecraft:gray_concrete
fill 236 168 243 236 169 243 minecraft:black_concrete
fill 236 168 245 236 169 245 minecraft:black_concrete
fill 236 168 247 236 169 247 minecraft:black_concrete
fill 236 168 249 236 169 249 minecraft:black_concrete
fill 236 168 251 236 169 251 minecraft:black_concrete
fill 236 168 253 236 169 253 minecraft:black_concrete
fill 237 168 229 237 169 229 minecraft:gray_concrete
fill 237 168 237 237 169 237 minecraft:gray_concrete
fill 237 168 242 237 169 242 minecraft:black_concrete
fill 237 168 255 237 169 255 minecraft:black_concrete
fill 239 168 229 239 169 229 minecraft:gray_concrete
fill 239 168 237 239 169 237 minecraft:gray_concrete
fill 239 168 242 239 169 242 minecraft:black_concrete
fill 239 168 255 239 169 255 minecraft:black_concrete
fill 241 168 229 241 169 229 minecraft:gray_concrete
fill 241 168 237 241 169 237 minecraft:gray_concrete
fill 241 168 243 241 169 243 minecraft:black_concrete
fill 241 168 245 241 169 245 minecraft:black_concrete
fill 241 168 247 241 169 247 minecraft:black_concrete
fill 241 168 249 241 169 249 minecraft:black_concrete
fill 241 168 251 241 169 251 minecraft:black_concrete
fill 241 168 253 241 169 253 minecraft:black_concrete
fill 242 168 252 243 168 252 minecraft:gray_concrete
fill 243 168 229 243 169 229 minecraft:gray_concrete
fill 243 168 237 243 169 237 minecraft:gray_concrete
fill 244 168 228 244 308 228 minecraft:black_concrete
fill 244 168 230 244 169 230 minecraft:gray_concrete
fill 244 168 232 244 169 232 minecraft:gray_concrete
fill 244 168 234 244 169 234 minecraft:gray_concrete
fill 244 168 236 244 169 236 minecraft:gray_concrete
fill 244 168 250 252 168 250 minecraft:gray_concrete
setblock 245 168 228 minecraft:sea_lantern
fill 246 168 251 251 168 251 minecraft:gray_concrete
fill 249 168 229 249 168 234 minecraft:sea_lantern
fill 249 168 265 249 175 265 minecraft:gray_concrete
fill 249 168 267 249 169 267 minecraft:gray_concrete
fill 250 168 229 262 168 229 minecraft:sea_lantern
fill 250 168 234 262 168 234 minecraft:sea_lantern
fill 250 168 264 250 169 264 minecraft:gray_concrete
fill 250 168 269 250 169 269 minecraft:gray_concrete
fill 251 168 231 260 169 232 minecraft:gray_concrete
fill 252 168 264 252 169 264 minecraft:gray_concrete
fill 252 168 269 252 169 269 minecraft:gray_concrete
fill 254 168 249 264 168 249 minecraft:gray_concrete
fill 254 168 264 254 169 264 minecraft:gray_concrete
fill 254 168 269 254 169 269 minecraft:gray_concrete
fill 256 168 264 256 169 264 minecraft:gray_concrete
fill 257 168 250 259 169 250 minecraft:gray_concrete
setblock 258 168 228 minecraft:sea_lantern
fill 258 168 264 258 169 264 minecraft:gray_concrete
fill 258 168 269 258 169 269 minecraft:gray_concrete
setblock 259 168 228 minecraft:cyan_concrete
fill 260 168 264 260 169 264 minecraft:gray_concrete
fill 260 168 269 260 169 269 minecraft:gray_concrete
fill 262 168 230 262 168 233 minecraft:sea_lantern
setblock 262 168 265 minecraft:gray_concrete
setblock 262 168 267 minecraft:gray_concrete
fill 262 168 270 262 308 270 minecraft:black_concrete
fill 268 168 230 268 169 230 minecraft:blue_terracotta
fill 268 168 232 268 169 232 minecraft:blue_terracotta
fill 268 168 234 268 169 234 minecraft:blue_terracotta
fill 268 168 236 268 169 236 minecraft:blue_terracotta
fill 268 168 262 268 169 262 minecraft:gray_concrete
fill 268 168 264 268 169 264 minecraft:gray_concrete
fill 268 168 266 268 169 266 minecraft:gray_concrete
fill 268 168 268 268 169 268 minecraft:gray_concrete
fill 269 168 229 269 169 229 minecraft:blue_terracotta
fill 269 168 237 269 169 237 minecraft:blue_terracotta
fill 269 168 261 269 169 261 minecraft:gray_concrete
fill 269 168 269 269 169 269 minecraft:gray_concrete
fill 271 168 229 271 169 229 minecraft:blue_terracotta
fill 271 168 237 271 169 237 minecraft:blue_terracotta
fill 271 168 243 271 169 243 minecraft:gray_concrete
fill 271 168 245 271 169 245 minecraft:gray_concrete
fill 271 168 247 271 169 247 minecraft:gray_concrete
fill 271 168 249 271 169 249 minecraft:gray_concrete
fill 271 168 251 271 169 251 minecraft:gray_concrete
fill 271 168 253 271 169 253 minecraft:gray_concrete
fill 271 168 261 271 169 261 minecraft:gray_concrete
fill 271 168 269 271 169 269 minecraft:gray_concrete
fill 272 168 242 272 169 242 minecraft:gray_concrete
fill 272 168 255 272 169 255 minecraft:gray_concrete
fill 273 168 229 273 169 229 minecraft:blue_terracotta
fill 273 168 237 273 169 237 minecraft:blue_terracotta
fill 273 168 261 273 169 261 minecraft:gray_concrete
fill 273 168 269 273 169 269 minecraft:gray_concrete
fill 274 168 242 274 169 242 minecraft:gray_concrete
fill 274 168 255 274 169 255 minecraft:gray_concrete
fill 275 168 229 275 169 229 minecraft:blue_terracotta
fill 275 168 237 275 169 237 minecraft:blue_terracotta
fill 275 168 261 275 169 261 minecraft:gray_concrete
fill 275 168 269 275 169 269 minecraft:gray_concrete
fill 276 168 230 276 169 230 minecraft:blue_terracotta
fill 276 168 232 276 169 232 minecraft:blue_terracotta
fill 276 168 234 276 169 234 minecraft:blue_terracotta
fill 276 168 236 276 169 236 minecraft:blue_terracotta
fill 276 168 243 276 169 243 minecraft:gray_concrete
fill 276 168 245 276 169 245 minecraft:gray_concrete
fill 276 168 247 276 169 247 minecraft:gray_concrete
fill 276 168 249 276 169 249 minecraft:gray_concrete
fill 276 168 251 276 169 251 minecraft:gray_concrete
fill 276 168 253 276 169 253 minecraft:gray_concrete
fill 276 168 262 276 169 262 minecraft:gray_concrete
fill 276 168 264 276 169 264 minecraft:gray_concrete
fill 276 168 266 276 169 266 minecraft:gray_concrete
fill 276 168 268 276 169 268 minecraft:gray_concrete
setblock 277 168 262 minecraft:verdant_froglight
fill 277 168 265 277 212 265 minecraft:black_concrete
fill 235 169 231 235 271 231 minecraft:black_concrete
setblock 236 169 270 minecraft:ochre_froglight
setblock 238 169 238 minecraft:light[level=12]
setblock 238 169 259 minecraft:light[level=12]
setblock 238 169 266 minecraft:light[level=12]
fill 242 169 251 246 169 251 minecraft:magenta_concrete
fill 245 169 228 245 182 228 minecraft:black_concrete
setblock 245 169 231 minecraft:light[level=12]
setblock 245 169 238 minecraft:light[level=12]
setblock 245 169 245 minecraft:light[level=12]
setblock 245 169 252 minecraft:light[level=12]
setblock 245 169 259 minecraft:light[level=12]
setblock 245 169 266 minecraft:light[level=12]
fill 247 169 251 248 169 251 minecraft:gray_concrete
fill 249 169 250 252 169 250 minecraft:gray_concrete
setblock 252 169 238 minecraft:light[level=12]
setblock 252 169 245 minecraft:light[level=12]
setblock 252 169 252 minecraft:light[level=12]
setblock 252 169 259 minecraft:light[level=12]
fill 255 169 249 270 169 249 minecraft:gray_concrete
fill 258 169 228 259 176 228 minecraft:black_concrete
setblock 259 169 238 minecraft:light[level=12]
setblock 259 169 245 minecraft:light[level=12]
setblock 259 169 252 minecraft:light[level=12]
setblock 259 169 259 minecraft:light[level=12]
fill 260 169 250 262 169 250 minecraft:gray_concrete
setblock 261 169 264 minecraft:sea_lantern
setblock 261 169 266 minecraft:sea_lantern
setblock 261 169 268 minecraft:sea_lantern
setblock 262 169 265 minecraft:sea_lantern
fill 262 169 267 262 170 267 minecraft:sea_lantern
setblock 262 169 269 minecraft:sea_lantern
fill 263 169 248 270 169 248 minecraft:gray_concrete
setblock 263 169 264 minecraft:sea_lantern
setblock 263 169 266 minecraft:sea_lantern
setblock 263 169 268 minecraft:sea_lantern
setblock 264 169 265 minecraft:sea_lantern
setblock 264 169 267 minecraft:sea_lantern
setblock 264 169 269 minecraft:sea_lantern
setblock 265 169 264 minecraft:sea_lantern
setblock 265 169 266 minecraft:sea_lantern
setblock 265 169 268 minecraft:sea_lantern
setblock 266 169 231 minecraft:light[level=12]
setblock 266 169 238 minecraft:light[level=12]
setblock 266 169 245 minecraft:light[level=12]
setblock 266 169 252 minecraft:light[level=12]
setblock 266 169 259 minecraft:light[level=12]
setblock 266 169 265 minecraft:sea_lantern
setblock 266 169 267 minecraft:sea_lantern
setblock 266 169 269 minecraft:sea_lantern
setblock 267 169 264 minecraft:sea_lantern
setblock 267 169 266 minecraft:sea_lantern
setblock 267 169 268 minecraft:sea_lantern
setblock 273 169 228 minecraft:ochre_froglight
setblock 273 169 238 minecraft:light[level=12]
setblock 273 169 259 minecraft:light[level=12]
fill 274 169 228 274 220 228 minecraft:black_concrete
fill 277 169 262 277 308 262 minecraft:black_concrete
setblock 236 170 230 minecraft:sea_lantern
setblock 236 170 232 minecraft:black_stained_glass
setblock 236 170 234 minecraft:ochre_froglight
setblock 236 170 236 minecraft:black_stained_glass
setblock 236 170 243 minecraft:sea_lantern
setblock 236 170 245 minecraft:black_stained_glass
setblock 236 170 247 minecraft:ochre_froglight
setblock 236 170 249 minecraft:black_stained_glass
setblock 236 170 251 minecraft:black_stained_glass
setblock 236 170 253 minecraft:light_blue_stained_glass
fill 236 170 270 236 212 270 minecraft:black_concrete
setblock 237 170 229 minecraft:pearlescent_froglight
setblock 237 170 237 minecraft:black_stained_glass
setblock 237 170 242 minecraft:black_stained_glass
setblock 237 170 255 minecraft:sea_lantern
setblock 239 170 229 minecraft:pearlescent_froglight
setblock 239 170 237 minecraft:ochre_froglight
setblock 239 170 242 minecraft:sea_lantern
setblock 239 170 255 minecraft:black_stained_glass
setblock 241 170 229 minecraft:magenta_stained_glass
setblock 241 170 237 minecraft:black_stained_glass
setblock 241 170 243 minecraft:black_stained_glass
setblock 241 170 245 minecraft:pearlescent_froglight
setblock 241 170 247 minecraft:pearlescent_froglight
setblock 241 170 249 minecraft:black_stained_glass
setblock 241 170 251 minecraft:pearlescent_froglight
setblock 241 170 253 minecraft:black_stained_glass
setblock 243 170 229 minecraft:black_stained_glass
setblock 243 170 237 minecraft:black_stained_glass
setblock 244 170 230 minecraft:cyan_stained_glass
setblock 244 170 232 minecraft:black_stained_glass
setblock 244 170 234 minecraft:sea_lantern
setblock 244 170 236 minecraft:pearlescent_froglight
setblock 249 170 267 minecraft:black_stained_glass
fill 250 170 250 252 170 250 minecraft:magenta_concrete
setblock 250 170 264 minecraft:ochre_froglight
setblock 250 170 269 minecraft:black_stained_glass
fill 251 170 231 251 181 232 minecraft:gray_concrete
fill 252 170 231 252 170 232 minecraft:black_stained_glass
setblock 252 170 264 minecraft:sea_lantern
setblock 252 170 269 minecraft:sea_lantern
fill 253 170 231 253 181 232 minecraft:gray_concrete
setblock 254 170 231 minecraft:ochre_froglight
setblock 254 170 232 minecraft:black_stained_glass
setblock 254 170 264 minecraft:black_stained_glass
setblock 254 170 269 minecraft:pearlescent_froglight
fill 255 170 231 255 181 232 minecraft:gray_concrete
fill 256 170 231 256 170 232 minecraft:cyan_stained_glass
setblock 256 170 264 minecraft:magenta_stained_glass
setblock 256 170 269 minecraft:sea_lantern
fill 257 170 231 257 181 232 minecraft:gray_concrete
fill 257 170 250 258 170 250 minecraft:magenta_concrete
setblock 258 170 231 minecraft:magenta_stained_glass
setblock 258 170 232 minecraft:pearlescent_froglight
fill 258 170 249 265 170 249 minecraft:magenta_concrete
setblock 258 170 264 minecraft:pearlescent_froglight
setblock 258 170 269 minecraft:black_stained_glass
fill 259 170 231 260 181 232 minecraft:gray_concrete
setblock 260 170 264 minecraft:black_stained_glass
setblock 260 170 269 minecraft:black_stained_glass
fill 261 170 264 261 171 264 minecraft:gray_concrete
fill 261 170 266 261 171 266 minecraft:gray_concrete
fill 261 170 268 261 171 268 minecraft:gray_concrete
setblock 262 170 265 minecraft:ochre_froglight
fill 262 170 269 262 171 269 minecraft:gray_concrete
fill 263 170 264 263 171 264 minecraft:gray_concrete
fill 263 170 266 263 171 266 minecraft:gray_concrete
fill 263 170 268 263 171 268 minecraft:gray_concrete
fill 264 170 265 264 171 265 minecraft:gray_concrete
fill 264 170 267 264 171 267 minecraft:gray_concrete
fill 264 170 269 264 171 269 minecraft:gray_concrete
fill 265 170 264 265 171 264 minecraft:gray_concrete
fill 265 170 266 265 171 266 minecraft:gray_concrete
fill 265 170 268 265 171 268 minecraft:gray_concrete
fill 266 170 265 266 171 265 minecraft:gray_concrete
fill 266 170 267 266 171 267 minecraft:gray_concrete
fill 266 170 269 266 171 269 minecraft:gray_concrete
fill 267 170 264 267 171 264 minecraft:gray_concrete
fill 267 170 266 267 171 266 minecraft:gray_concrete
fill 267 170 268 267 171 268 minecraft:gray_concrete
setblock 268 170 230 minecraft:black_stained_glass
setblock 268 170 232 minecraft:pearlescent_froglight
fill 268 170 233 271 170 233 minecraft:blue_terracotta
setblock 268 170 234 minecraft:black_stained_glass
fill 268 170 235 271 170 235 minecraft:blue_terracotta
setblock 268 170 236 minecraft:black_stained_glass
fill 268 170 248 270 170 248 minecraft:gray_concrete
setblock 268 170 262 minecraft:sea_lantern
setblock 268 170 264 minecraft:ochre_froglight
setblock 268 170 266 minecraft:black_stained_glass
setblock 268 170 268 minecraft:cyan_stained_glass
setblock 269 170 229 minecraft:ochre_froglight
fill 269 170 234 271 170 234 minecraft:blue_terracotta
fill 269 170 236 271 180 236 minecraft:blue_terracotta
setblock 269 170 237 minecraft:pearlescent_froglight
setblock 269 170 261 minecraft:ochre_froglight
setblock 269 170 269 minecraft:black_stained_glass
setblock 271 170 229 minecraft:black_stained_glass
setblock 271 170 237 minecraft:pearlescent_froglight
setblock 271 170 243 minecraft:ochre_froglight
setblock 271 170 245 minecraft:black_stained_glass
setblock 271 170 247 minecraft:sea_lantern
setblock 271 170 249 minecraft:pearlescent_froglight
setblock 271 170 251 minecraft:ochre_froglight
setblock 271 170 253 minecraft:black_stained_glass
setblock 271 170 261 minecraft:light_blue_stained_glass
setblock 271 170 269 minecraft:magenta_stained_glass
fill 272 170 233 272 171 236 minecraft:sea_lantern
setblock 272 170 242 minecraft:black_stained_glass
setblock 272 170 255 minecraft:black_stained_glass
fill 273 170 228 273 232 228 minecraft:black_concrete
setblock 273 170 229 minecraft:sea_lantern
fill 273 170 233 273 170 236 minecraft:blue_terracotta
setblock 273 170 237 minecraft:cyan_stained_glass
fill 273 170 240 273 171 246 minecraft:sea_lantern
fill 273 170 247 273 170 249 minecraft:gray_concrete
setblock 273 170 261 minecraft:pearlescent_froglight
setblock 273 170 269 minecraft:black_stained_glass
fill 274 170 234 275 180 236 minecraft:blue_terracotta
setblock 274 170 242 minecraft:magenta_stained_glass
setblock 274 170 255 minecraft:light_blue_stained_glass
setblock 275 170 228 minecraft:ochre_froglight
setblock 275 170 229 minecraft:magenta_stained_glass
setblock 275 170 237 minecraft:black_stained_glass
setblock 275 170 261 minecraft:magenta_stained_glass
setblock 275 170 269 minecraft:ochre_froglight
setblock 276 170 230 minecraft:cyan_stained_glass
setblock 276 170 232 minecraft:black_stained_glass
setblock 276 170 234 minecraft:black_stained_glass
fill 276 170 235 276 180 235 minecraft:blue_terracotta
setblock 276 170 236 minecraft:sea_lantern
setblock 276 170 243 minecraft:sea_lantern
setblock 276 170 245 minecraft:black_stained_glass
setblock 276 170 247 minecraft:pearlescent_froglight
setblock 276 170 249 minecraft:magenta_stained_glass
setblock 276 170 251 minecraft:magenta_stained_glass
setblock 276 170 253 minecraft:cyan_stained_glass
setblock 276 170 262 minecraft:pearlescent_froglight
setblock 276 170 264 minecraft:magenta_stained_glass
setblock 276 170 266 minecraft:black_stained_glass
setblock 276 170 268 minecraft:ochre_froglight
fill 236 171 230 236 172 230 minecraft:gray_concrete
fill 236 171 232 236 172 232 minecraft:gray_concrete
fill 236 171 234 236 172 234 minecraft:gray_concrete
fill 236 171 236 236 172 236 minecraft:gray_concrete
fill 236 171 243 236 172 243 minecraft:black_concrete
fill 236 171 245 236 172 245 minecraft:black_concrete
fill 236 171 247 236 172 247 minecraft:black_concrete
fill 236 171 249 236 172 249 minecraft:black_concrete
fill 236 171 251 236 172 251 minecraft:black_concrete
fill 236 171 253 236 172 253 minecraft:black_concrete
fill 237 171 229 237 172 229 minecraft:gray_concrete
fill 237 171 237 237 172 237 minecraft:gray_concrete
fill 237 171 242 237 172 242 minecraft:black_concrete
fill 237 171 255 237 172 255 minecraft:black_concrete
setblock 238 171 239 minecraft:light[level=15]
setblock 238 171 263 minecraft:light[level=15]
fill 239 171 229 239 172 229 minecraft:gray_concrete
fill 239 171 237 239 172 237 minecraft:gray_concrete
fill 239 171 242 239 172 242 minecraft:black_concrete
fill 239 171 255 239 172 255 minecraft:black_concrete
fill 241 171 229 241 172 229 minecraft:gray_concrete
fill 241 171 237 241 172 237 minecraft:gray_concrete
fill 241 171 243 241 172 243 minecraft:black_concrete
fill 241 171 245 241 172 245 minecraft:black_concrete
fill 241 171 247 241 172 247 minecraft:black_concrete
fill 241 171 249 241 172 249 minecraft:black_concrete
fill 241 171 251 241 172 251 minecraft:black_concrete
fill 241 171 253 241 172 253 minecraft:black_concrete
fill 243 171 229 243 172 229 minecraft:gray_concrete
fill 243 171 237 243 172 237 minecraft:gray_concrete
fill 244 171 230 244 172 230 minecraft:gray_concrete
fill 244 171 232 244 172 232 minecraft:gray_concrete
fill 244 171 234 244 172 234 minecraft:gray_concrete
fill 244 171 236 244 172 236 minecraft:gray_concrete
setblock 246 171 231 minecraft:light[level=15]
setblock 246 171 239 minecraft:light[level=15]
setblock 246 171 247 minecraft:light[level=15]
setblock 246 171 255 minecraft:light[level=15]
fill 249 171 267 249 172 267 minecraft:gray_concrete
fill 250 171 264 250 175 264 minecraft:gray_concrete
fill 250 171 269 250 172 269 minecraft:gray_concrete
fill 252 171 231 252 172 232 minecraft:gray_concrete
fill 252 171 264 252 172 264 minecraft:gray_concrete
fill 252 171 269 252 172 269 minecraft:gray_concrete
fill 254 171 231 254 172 232 minecraft:gray_concrete
setblock 254 171 239 minecraft:light[level=15]
setblock 254 171 247 minecraft:light[level=15]
setblock 254 171 255 minecraft:light[level=15]
fill 254 171 264 254 172 264 minecraft:gray_concrete
fill 254 171 269 254 172 269 minecraft:gray_concrete
fill 256 171 231 256 172 232 minecraft:gray_concrete
fill 256 171 264 256 172 264 minecraft:gray_concrete
fill 256 171 269 256 172 269 minecraft:gray_concrete
fill 258 171 231 258 172 232 minecraft:gray_concrete
fill 258 171 264 258 175 264 minecraft:gray_concrete
fill 258 171 269 258 172 269 minecraft:gray_concrete
fill 260 171 264 260 172 264 minecraft:gray_concrete
fill 260 171 269 260 172 269 minecraft:gray_concrete
setblock 262 171 231 minecraft:light[level=15]
setblock 262 171 239 minecraft:light[level=15]
setblock 262 171 247 minecraft:light[level=15]
setblock 262 171 255 minecraft:light[level=15]
setblock 262 171 263 minecraft:light[level=15]
setblock 262 171 265 minecraft:gray_concrete
setblock 262 171 267 minecraft:gray_concrete
fill 268 171 230 268 172 230 minecraft:blue_terracotta
fill 268 171 232 268 172 236 minecraft:blue_terracotta
fill 268 171 262 268 172 262 minecraft:gray_concrete
fill 268 171 264 268 172 264 minecraft:gray_concrete
fill 268 171 266 268 172 266 minecraft:gray_concrete
fill 268 171 268 268 172 268 minecraft:gray_concrete
fill 269 171 229 269 172 229 minecraft:blue_terracotta
fill 269 171 232 270 180 235 minecraft:blue_terracotta
fill 269 171 237 269 172 237 minecraft:blue_terracotta
fill 269 171 248 270 171 248 minecraft:magenta_concrete
fill 269 171 261 269 172 261 minecraft:gray_concrete
fill 269 171 269 269 172 269 minecraft:gray_concrete
setblock 270 171 239 minecraft:light[level=15]
setblock 270 171 247 minecraft:light[level=15]
setblock 270 171 255 minecraft:light[level=15]
fill 271 171 229 271 172 229 minecraft:blue_terracotta
fill 271 171 232 271 180 232 minecraft:blue_terracotta
fill 271 171 233 271 172 235 minecraft:light_blue_stained_glass
fill 271 171 237 271 172 237 minecraft:blue_terracotta
fill 271 171 243 271 172 245 minecraft:gray_concrete
fill 271 171 247 271 172 247 minecraft:gray_concrete
fill 271 171 249 271 172 249 minecraft:gray_concrete
fill 271 171 251 271 172 251 minecraft:gray_concrete
fill 271 171 253 271 172 253 minecraft:gray_concrete
fill 271 171 261 271 172 261 minecraft:gray_concrete
fill 271 171 269 271 172 269 minecraft:gray_concrete
fill 272 171 232 272 172 232 minecraft:light_blue_stained_glass
fill 272 171 237 272 172 245 minecraft:light_blue_stained_glass
fill 272 171 255 272 172 255 minecraft:gray_concrete
fill 273 171 229 273 172 229 minecraft:blue_terracotta
fill 273 171 232 276 172 232 minecraft:blue_terracotta
setblock 273 171 233 minecraft:iron_block
fill 273 171 234 273 172 239 minecraft:light_blue_stained_glass
fill 273 171 247 274 172 247 minecraft:light_blue_stained_glass
fill 273 171 248 274 171 248 minecraft:magenta_concrete
fill 273 171 249 274 172 249 minecraft:light_blue_stained_glass
fill 273 171 261 273 172 261 minecraft:gray_concrete
fill 273 171 269 273 172 269 minecraft:gray_concrete
fill 274 171 242 274 172 246 minecraft:light_blue_stained_glass
fill 274 171 255 274 172 255 minecraft:gray_concrete
fill 275 171 228 275 189 228 minecraft:black_concrete
fill 275 171 229 275 172 229 minecraft:blue_terracotta
fill 275 171 237 275 172 237 minecraft:blue_terracotta
fill 275 171 261 275 172 261 minecraft:gray_concrete
fill 275 171 269 275 172 269 minecraft:gray_concrete
fill 276 171 230 276 172 230 minecraft:blue_terracotta
fill 276 171 234 276 172 234 minecraft:blue_terracotta
fill 276 171 236 276 172 236 minecraft:blue_terracotta
fill 276 171 243 276 172 243 minecraft:gray_concrete
fill 276 171 245 276 172 245 minecraft:gray_concrete
fill 276 171 247 276 172 247 minecraft:gray_concrete
fill 276 171 249 276 172 249 minecraft:gray_concrete
fill 276 171 251 276 172 251 minecraft:gray_concrete
fill 276 171 253 276 172 253 minecraft:gray_concrete
fill 276 171 262 276 172 262 minecraft:gray_concrete
fill 276 171 264 276 172 264 minecraft:gray_concrete
fill 276 171 266 276 172 266 minecraft:gray_concrete
fill 276 171 268 276 172 268 minecraft:gray_concrete
setblock 240 172 265 minecraft:redstone_block
setblock 240 172 270 minecraft:blue_concrete
setblock 261 172 264 minecraft:sea_lantern
setblock 261 172 266 minecraft:sea_lantern
setblock 261 172 268 minecraft:sea_lantern
setblock 262 172 228 minecraft:pearlescent_froglight
fill 262 172 265 262 173 265 minecraft:sea_lantern
setblock 262 172 267 minecraft:sea_lantern
setblock 262 172 269 minecraft:sea_lantern
setblock 263 172 264 minecraft:sea_lantern
setblock 263 172 266 minecraft:sea_lantern
setblock 263 172 268 minecraft:sea_lantern
setblock 264 172 265 minecraft:sea_lantern
setblock 264 172 267 minecraft:sea_lantern
setblock 264 172 269 minecraft:sea_lantern
fill 265 172 228 265 218 228 minecraft:black_concrete
setblock 265 172 264 minecraft:sea_lantern
setblock 265 172 266 minecraft:sea_lantern
setblock 265 172 268 minecraft:sea_lantern
setblock 265 172 270 minecraft:verdant_froglight
setblock 266 172 228 minecraft:ochre_froglight
setblock 266 172 265 minecraft:sea_lantern
setblock 266 172 267 minecraft:sea_lantern
setblock 266 172 269 minecraft:sea_lantern
fill 267 172 228 267 234 228 minecraft:black_concrete
setblock 267 172 264 minecraft:sea_lantern
setblock 267 172 266 minecraft:sea_lantern
setblock 267 172 268 minecraft:sea_lantern
setblock 267 172 270 minecraft:blue_concrete
fill 272 172 233 272 172 236 minecraft:light_blue_stained_glass
setblock 273 172 233 minecraft:light_blue_stained_glass
fill 273 172 240 273 172 246 minecraft:light_blue_stained_glass
fill 273 172 248 274 172 248 minecraft:light_blue_stained_glass
setblock 277 172 231 minecraft:pearlescent_froglight
setblock 236 173 230 minecraft:black_stained_glass
setblock 236 173 232 minecraft:black_stained_glass
setblock 236 173 234 minecraft:black_stained_glass
setblock 236 173 236 minecraft:magenta_stained_glass
setblock 236 173 243 minecraft:pearlescent_froglight
setblock 236 173 245 minecraft:magenta_stained_glass
setblock 236 173 247 minecraft:black_stained_glass
setblock 236 173 249 minecraft:black_stained_glass
setblock 236 173 251 minecraft:sea_lantern
setblock 236 173 253 minecraft:black_stained_glass
setblock 237 173 229 minecraft:cyan_stained_glass
setblock 237 173 237 minecraft:pearlescent_froglight
setblock 237 173 242 minecraft:magenta_stained_glass
setblock 237 173 255 minecraft:magenta_stained_glass
setblock 239 173 229 minecraft:black_stained_glass
setblock 239 173 237 minecraft:cyan_stained_glass
setblock 239 173 242 minecraft:black_stained_glass
setblock 239 173 255 minecraft:pearlescent_froglight
fill 240 173 270 240 189 270 minecraft:black_concrete
setblock 241 173 229 minecraft:black_stained_glass
setblock 241 173 237 minecraft:sea_lantern
setblock 241 173 243 minecraft:pearlescent_froglight
setblock 241 173 245 minecraft:ochre_froglight
setblock 241 173 247 minecraft:black_stained_glass
setblock 241 173 249 minecraft:pearlescent_froglight
setblock 241 173 251 minecraft:pearlescent_froglight
setblock 241 173 253 minecraft:cyan_stained_glass
setblock 243 173 229 minecraft:black_stained_glass
setblock 243 173 237 minecraft:pearlescent_froglight
setblock 244 173 230 minecraft:magenta_stained_glass
setblock 244 173 232 minecraft:light_blue_stained_glass
setblock 244 173 234 minecraft:sea_lantern
setblock 244 173 236 minecraft:sea_lantern
setblock 249 173 267 minecraft:pearlescent_froglight
setblock 250 173 269 minecraft:black_stained_glass
setblock 252 173 231 minecraft:black_stained_glass
setblock 252 173 232 minecraft:pearlescent_froglight
setblock 252 173 264 minecraft:sea_lantern
setblock 252 173 269 minecraft:ochre_froglight
setblock 254 173 231 minecraft:sea_lantern
setblock 254 173 232 minecraft:black_stained_glass
setblock 254 173 264 minecraft:black_stained_glass
setblock 254 173 269 minecraft:black_stained_glass
fill 256 173 231 256 173 232 minecraft:sea_lantern
setblock 256 173 264 minecraft:cyan_stained_glass
setblock 256 173 269 minecraft:black_stained_glass
setblock 258 173 231 minecraft:pearlescent_froglight
setblock 258 173 232 minecraft:black_stained_glass
setblock 258 173 269 minecraft:sea_lantern
setblock 260 173 264 minecraft:black_stained_glass
setblock 260 173 269 minecraft:magenta_stained_glass
fill 261 173 264 261 282 264 minecraft:gray_concrete
fill 261 173 266 261 176 266 minecraft:gray_concrete
fill 261 173 268 261 282 268 minecraft:gray_concrete
fill 262 173 228 262 253 228 minecraft:black_concrete
setblock 262 173 267 minecraft:black_stained_glass
fill 262 173 269 262 282 269 minecraft:gray_concrete
fill 263 173 264 263 174 264 minecraft:gray_concrete
fill 263 173 266 263 174 266 minecraft:gray_concrete
fill 263 173 268 263 174 268 minecraft:gray_concrete
fill 264 173 265 264 174 265 minecraft:gray_concrete
fill 264 173 267 264 174 267 minecraft:gray_concrete
fill 264 173 269 264 174 269 minecraft:gray_concrete
fill 265 173 264 265 174 264 minecraft:gray_concrete
fill 265 173 266 265 174 266 minecraft:gray_concrete
fill 265 173 268 265 174 268 minecraft:gray_concrete
fill 265 173 270 265 249 270 minecraft:black_concrete
fill 266 173 228 266 205 228 minecraft:black_concrete
fill 266 173 265 266 174 265 minecraft:gray_concrete
fill 266 173 267 266 174 267 minecraft:gray_concrete
fill 266 173 269 266 174 269 minecraft:gray_concrete
fill 267 173 264 267 174 264 minecraft:gray_concrete
fill 267 173 266 267 174 266 minecraft:gray_concrete
fill 267 173 268 267 174 268 minecraft:gray_concrete
fill 267 173 270 267 256 270 minecraft:black_concrete
setblock 268 173 230 minecraft:cyan_stained_glass
setblock 268 173 232 minecraft:magenta_stained_glass
fill 268 173 233 268 180 233 minecraft:blue_terracotta
setblock 268 173 234 minecraft:black_stained_glass
fill 268 173 235 268 180 235 minecraft:blue_terracotta
setblock 268 173 236 minecraft:black_stained_glass
setblock 268 173 262 minecraft:black_stained_glass
setblock 268 173 264 minecraft:black_stained_glass
setblock 268 173 266 minecraft:pearlescent_froglight
setblock 268 173 268 minecraft:ochre_froglight
setblock 269 173 229 minecraft:black_stained_glass
setblock 269 173 237 minecraft:black_stained_glass
setblock 269 173 261 minecraft:cyan_stained_glass
setblock 269 173 269 minecraft:ochre_froglight
setblock 271 173 229 minecraft:black_stained_glass
fill 271 173 233 273 180 235 minecraft:blue_terracotta
setblock 271 173 237 minecraft:ochre_froglight
setblock 271 173 243 minecraft:magenta_stained_glass
fill 271 173 244 274 186 244 minecraft:gray_concrete
setblock 271 173 245 minecraft:ochre_froglight
setblock 271 173 247 minecraft:black_stained_glass
setblock 271 173 249 minecraft:magenta_stained_glass
setblock 271 173 251 minecraft:black_stained_glass
setblock 271 173 253 minecraft:black_stained_glass
setblock 271 173 261 minecraft:cyan_stained_glass
setblock 271 173 263 minecraft:gray_concrete
fill 271 173 269 271 173 270 minecraft:ochre_froglight
fill 272 173 232 275 180 232 minecraft:blue_terracotta
fill 272 173 236 272 180 237 minecraft:blue_terracotta
setblock 272 173 242 minecraft:light_blue_stained_glass
fill 272 173 243 274 186 243 minecraft:gray_concrete
fill 272 173 245 274 186 245 minecraft:gray_concrete
setblock 272 173 255 minecraft:black_stained_glass
fill 272 173 262 272 174 265 minecraft:sea_lantern
setblock 273 173 229 minecraft:magenta_stained_glass
fill 273 173 236 273 180 236 minecraft:blue_terracotta
setblock 273 173 237 minecraft:black_stained_glass
fill 273 173 242 273 186 242 minecraft:gray_concrete
fill 273 173 246 274 173 249 minecraft:gray_concrete
fill 273 173 251 273 174 257 minecraft:sea_lantern
setblock 273 173 261 minecraft:black_stained_glass
fill 273 173 262 273 173 263 minecraft:gray_concrete
setblock 273 173 269 minecraft:black_stained_glass
setblock 274 173 242 minecraft:black_stained_glass
setblock 274 173 255 minecraft:sea_lantern
setblock 275 173 229 minecraft:magenta_stained_glass
setblock 275 173 237 minecraft:magenta_stained_glass
setblock 275 173 261 minecraft:pearlescent_froglight
setblock 275 173 269 minecraft:pearlescent_froglight
setblock 276 173 230 minecraft:black_stained_glass
setblock 276 173 232 minecraft:magenta_stained_glass
setblock 276 173 234 minecraft:cyan_stained_glass
setblock 276 173 236 minecraft:black_stained_glass
setblock 276 173 243 minecraft:magenta_stained_glass
setblock 276 173 245 minecraft:black_stained_glass
setblock 276 173 247 minecraft:magenta_stained_glass
setblock 276 173 249 minecraft:light_blue_stained_glass
setblock 276 173 251 minecraft:black_stained_glass
setblock 276 173 253 minecraft:light_blue_stained_glass
setblock 276 173 262 minecraft:black_stained_glass
setblock 276 173 264 minecraft:light_blue_stained_glass
setblock 276 173 266 minecraft:ochre_froglight
setblock 276 173 268 minecraft:black_stained_glass
fill 277 173 231 277 243 231 minecraft:black_concrete
setblock 277 173 234 minecraft:cyan_concrete
fill 236 174 230 236 175 230 minecraft:gray_concrete
fill 236 174 232 236 175 232 minecraft:gray_concrete
fill 236 174 234 236 175 234 minecraft:gray_concrete
fill 236 174 236 236 175 236 minecraft:gray_concrete
fill 236 174 243 236 175 243 minecraft:black_concrete
fill 236 174 245 236 175 245 minecraft:black_concrete
fill 236 174 247 236 175 247 minecraft:black_concrete
fill 236 174 249 236 175 249 minecraft:black_concrete
fill 236 174 251 236 175 251 minecraft:black_concrete
fill 236 174 253 236 175 253 minecraft:black_concrete
fill 237 174 229 237 175 229 minecraft:gray_concrete
fill 237 174 237 237 175 237 minecraft:gray_concrete
fill 237 174 242 237 175 242 minecraft:black_concrete
fill 237 174 255 237 175 255 minecraft:black_concrete
fill 239 174 229 239 175 229 minecraft:gray_concrete
fill 239 174 237 239 175 237 minecraft:gray_concrete
fill 239 174 242 239 175 242 minecraft:black_concrete
fill 239 174 255 239 175 255 minecraft:black_concrete
fill 241 174 229 241 175 229 minecraft:gray_concrete
fill 241 174 237 241 175 237 minecraft:gray_concrete
fill 241 174 243 241 175 243 minecraft:black_concrete
fill 241 174 245 241 175 245 minecraft:black_concrete
fill 241 174 247 241 175 247 minecraft:black_concrete
fill 241 174 249 241 175 249 minecraft:black_concrete
fill 241 174 251 241 175 251 minecraft:black_concrete
fill 241 174 253 241 175 253 minecraft:black_concrete
fill 243 174 229 243 175 229 minecraft:gray_concrete
fill 243 174 237 243 175 237 minecraft:gray_concrete
fill 244 174 230 244 175 230 minecraft:gray_concrete
fill 244 174 232 244 175 232 minecraft:gray_concrete
fill 244 174 234 244 175 234 minecraft:gray_concrete
fill 244 174 236 244 175 236 minecraft:gray_concrete
fill 249 174 267 249 178 267 minecraft:gray_concrete
fill 250 174 269 250 175 269 minecraft:gray_concrete
fill 252 174 231 252 175 232 minecraft:gray_concrete
fill 252 174 264 252 178 264 minecraft:gray_concrete
fill 252 174 269 252 175 269 minecraft:gray_concrete
fill 254 174 231 254 175 232 minecraft:gray_concrete
fill 254 174 264 254 175 264 minecraft:gray_concrete
fill 254 174 269 254 175 269 minecraft:gray_concrete
fill 256 174 231 256 175 232 minecraft:gray_concrete
fill 256 174 264 256 175 264 minecraft:gray_concrete
fill 256 174 269 256 175 269 minecraft:gray_concrete
fill 258 174 231 258 175 232 minecraft:gray_concrete
fill 258 174 269 258 175 269 minecraft:gray_concrete
fill 260 174 264 260 175 264 minecraft:gray_concrete
fill 260 174 269 260 175 269 minecraft:gray_concrete
fill 262 174 265 262 175 265 minecraft:gray_concrete
fill 262 174 267 262 175 267 minecraft:gray_concrete
fill 268 174 230 268 175 230 minecraft:blue_terracotta
fill 268 174 232 268 175 232 minecraft:blue_terracotta
fill 268 174 234 268 175 234 minecraft:blue_terracotta
fill 268 174 236 268 175 236 minecraft:blue_terracotta
fill 268 174 262 268 175 262 minecraft:gray_concrete
fill 268 174 264 268 175 264 minecraft:gray_concrete
fill 268 174 266 268 175 266 minecraft:gray_concrete
fill 268 174 268 268 175 268 minecraft:gray_concrete
fill 269 174 229 269 175 229 minecraft:blue_terracotta
fill 269 174 237 269 175 237 minecraft:blue_terracotta
fill 269 174 261 269 175 261 minecraft:gray_concrete
fill 269 174 269 269 175 269 minecraft:gray_concrete
fill 271 174 229 271 175 229 minecraft:blue_terracotta
fill 271 174 237 271 175 237 minecraft:blue_terracotta
fill 271 174 243 271 175 243 minecraft:gray_concrete
fill 271 174 245 271 175 245 minecraft:gray_concrete
fill 271 174 247 271 175 247 minecraft:gray_concrete
fill 271 174 249 271 175 249 minecraft:gray_concrete
fill 271 174 251 271 175 251 minecraft:gray_concrete
fill 271 174 253 271 175 253 minecraft:gray_concrete
fill 271 174 261 271 175 261 minecraft:gray_concrete
fill 271 174 263 271 175 265 minecraft:light_blue_stained_glass
fill 271 174 269 271 175 269 minecraft:gray_concrete
fill 271 174 270 271 186 270 minecraft:black_concrete
fill 272 174 242 272 175 242 minecraft:gray_concrete
fill 272 174 252 272 175 261 minecraft:light_blue_stained_glass
fill 272 174 266 272 175 266 minecraft:light_blue_stained_glass
fill 273 174 229 273 175 229 minecraft:blue_terracotta
fill 273 174 237 273 175 237 minecraft:blue_terracotta
fill 273 174 246 274 186 247 minecraft:gray_concrete
fill 273 174 248 274 175 250 minecraft:light_blue_stained_glass
fill 273 174 258 273 175 265 minecraft:light_blue_stained_glass
fill 273 174 269 273 175 269 minecraft:gray_concrete
fill 274 174 242 274 175 242 minecraft:gray_concrete
fill 274 174 251 274 175 256 minecraft:light_blue_stained_glass
fill 275 174 229 275 175 229 minecraft:blue_terracotta
fill 275 174 237 275 175 237 minecraft:blue_terracotta
fill 275 174 261 275 175 261 minecraft:gray_concrete
fill 275 174 269 275 175 269 minecraft:gray_concrete
fill 276 174 230 276 175 230 minecraft:blue_terracotta
fill 276 174 232 276 175 232 minecraft:blue_terracotta
fill 276 174 234 276 175 234 minecraft:blue_terracotta
fill 276 174 236 276 175 236 minecraft:blue_terracotta
fill 276 174 243 276 175 243 minecraft:gray_concrete
fill 276 174 245 276 175 245 minecraft:gray_concrete
fill 276 174 247 276 175 247 minecraft:gray_concrete
fill 276 174 249 276 175 249 minecraft:gray_concrete
fill 276 174 251 276 175 251 minecraft:gray_concrete
fill 276 174 253 276 175 253 minecraft:gray_concrete
fill 276 174 262 276 175 262 minecraft:gray_concrete
fill 276 174 264 276 175 264 minecraft:gray_concrete
fill 276 174 266 276 175 266 minecraft:gray_concrete
fill 276 174 268 276 175 268 minecraft:gray_concrete
fill 277 174 234 277 308 234 minecraft:black_concrete
setblock 277 174 254 minecraft:blue_concrete
setblock 235 175 248 minecraft:sea_lantern
setblock 235 175 261 minecraft:purple_concrete
setblock 238 175 238 minecraft:light[level=12]
setblock 238 175 259 minecraft:light[level=12]
setblock 238 175 266 minecraft:light[level=12]
setblock 238 175 270 minecraft:verdant_froglight
setblock 245 175 231 minecraft:light[level=12]
setblock 245 175 238 minecraft:light[level=12]
setblock 245 175 245 minecraft:light[level=12]
setblock 245 175 252 minecraft:light[level=12]
setblock 245 175 259 minecraft:light[level=12]
setblock 245 175 266 minecraft:light[level=12]
setblock 252 175 238 minecraft:light[level=12]
setblock 252 175 245 minecraft:light[level=12]
setblock 252 175 252 minecraft:light[level=12]
setblock 252 175 259 minecraft:light[level=12]
setblock 259 175 238 minecraft:light[level=12]
setblock 259 175 245 minecraft:light[level=12]
setblock 259 175 252 minecraft:light[level=12]
setblock 259 175 259 minecraft:light[level=12]
setblock 266 175 231 minecraft:light[level=12]
setblock 266 175 238 minecraft:light[level=12]
setblock 266 175 245 minecraft:light[level=12]
setblock 266 175 252 minecraft:light[level=12]
setblock 266 175 259 minecraft:light[level=12]
setblock 266 175 266 minecraft:light[level=12]
fill 272 175 262 272 175 265 minecraft:light_blue_stained_glass
setblock 273 175 238 minecraft:light[level=12]
fill 273 175 251 273 175 257 minecraft:light_blue_stained_glass
fill 277 175 254 277 279 254 minecraft:black_concrete
setblock 277 175 261 minecraft:cyan_concrete
setblock 277 175 266 minecraft:purple_concrete
fill 235 176 248 235 212 248 minecraft:black_concrete
fill 235 176 261 235 225 261 minecraft:black_concrete
setblock 236 176 230 minecraft:light_blue_stained_glass
setblock 236 176 232 minecraft:cyan_stained_glass
setblock 236 176 234 minecraft:sea_lantern
setblock 236 176 236 minecraft:black_stained_glass
setblock 236 176 243 minecraft:black_stained_glass
setblock 236 176 245 minecraft:black_stained_glass
setblock 236 176 247 minecraft:black_stained_glass
setblock 236 176 249 minecraft:light_blue_stained_glass
setblock 236 176 251 minecraft:cyan_stained_glass
setblock 236 176 253 minecraft:black_stained_glass
setblock 237 176 229 minecraft:magenta_stained_glass
setblock 237 176 237 minecraft:light_blue_stained_glass
setblock 237 176 242 minecraft:magenta_stained_glass
setblock 237 176 255 minecraft:magenta_stained_glass
fill 238 176 270 238 246 270 minecraft:black_concrete
setblock 239 176 229 minecraft:sea_lantern
setblock 239 176 237 minecraft:pearlescent_froglight
setblock 239 176 242 minecraft:cyan_stained_glass
setblock 239 176 255 minecraft:light_blue_stained_glass
setblock 241 176 229 minecraft:black_stained_glass
setblock 241 176 237 minecraft:black_stained_glass
setblock 241 176 243 minecraft:black_stained_glass
setblock 241 176 245 minecraft:black_stained_glass
setblock 241 176 247 minecraft:black_stained_glass
setblock 241 176 249 minecraft:black_stained_glass
setblock 241 176 251 minecraft:ochre_froglight
setblock 241 176 253 minecraft:black_stained_glass
setblock 243 176 229 minecraft:cyan_stained_glass
setblock 243 176 237 minecraft:light_blue_stained_glass
setblock 244 176 230 minecraft:pearlescent_froglight
setblock 244 176 232 minecraft:ochre_froglight
setblock 244 176 234 minecraft:pearlescent_froglight
setblock 244 176 236 minecraft:magenta_stained_glass
setblock 249 176 265 minecraft:cyan_stained_glass
setblock 250 176 264 minecraft:black_stained_glass
setblock 250 176 269 minecraft:black_stained_glass
setblock 252 176 231 minecraft:black_stained_glass
setblock 252 176 232 minecraft:magenta_stained_glass
setblock 252 176 269 minecraft:black_stained_glass
fill 254 176 231 254 176 232 minecraft:black_stained_glass
setblock 254 176 264 minecraft:black_stained_glass
setblock 254 176 269 minecraft:pearlescent_froglight
setblock 256 176 231 minecraft:pearlescent_froglight
setblock 256 176 232 minecraft:black_stained_glass
setblock 256 176 264 minecraft:pearlescent_froglight
setblock 256 176 269 minecraft:ochre_froglight
setblock 258 176 231 minecraft:pearlescent_froglight
setblock 258 176 232 minecraft:black_stained_glass
setblock 258 176 264 minecraft:black_stained_glass
setblock 258 176 269 minecraft:black_stained_glass
setblock 260 176 264 minecraft:black_stained_glass
setblock 260 176 269 minecraft:black_stained_glass
setblock 262 176 265 minecraft:cyan_stained_glass
setblock 262 176 267 minecraft:black_stained_glass
setblock 268 176 230 minecraft:magenta_stained_glass
setblock 268 176 232 minecraft:magenta_stained_glass
setblock 268 176 234 minecraft:black_stained_glass
setblock 268 176 236 minecraft:sea_lantern
setblock 268 176 262 minecraft:ochre_froglight
setblock 268 176 264 minecraft:black_stained_glass
setblock 268 176 266 minecraft:ochre_froglight
setblock 268 176 268 minecraft:ochre_froglight
setblock 269 176 229 minecraft:black_stained_glass
setblock 269 176 237 minecraft:black_stained_glass
setblock 269 176 261 minecraft:magenta_stained_glass
setblock 269 176 269 minecraft:black_stained_glass
setblock 271 176 229 minecraft:pearlescent_froglight
setblock 271 176 237 minecraft:light_blue_stained_glass
setblock 271 176 243 minecraft:sea_lantern
setblock 271 176 245 minecraft:black_stained_glass
setblock 271 176 247 minecraft:black_stained_glass
setblock 271 176 249 minecraft:cyan_stained_glass
setblock 271 176 251 minecraft:black_stained_glass
setblock 271 176 253 minecraft:black_stained_glass
setblock 271 176 261 minecraft:black_stained_glass
fill 271 176 263 273 176 265 minecraft:gray_concrete
setblock 271 176 269 minecraft:black_stained_glass
setblock 272 176 242 minecraft:black_stained_glass
fill 272 176 252 274 186 254 minecraft:gray_concrete
setblock 272 176 255 minecraft:ochre_froglight
fill 272 176 261 272 185 262 minecraft:gray_concrete
fill 272 176 266 272 177 266 minecraft:gray_concrete
setblock 273 176 229 minecraft:cyan_stained_glass
setblock 273 176 237 minecraft:sea_lantern
fill 273 176 248 274 186 251 minecraft:gray_concrete
fill 273 176 255 273 186 255 minecraft:gray_concrete
setblock 273 176 261 minecraft:sea_lantern
fill 273 176 262 273 185 262 minecraft:gray_concrete
setblock 273 176 269 minecraft:black_stained_glass
setblock 274 176 242 minecraft:sea_lantern
setblock 274 176 255 minecraft:black_stained_glass
setblock 275 176 229 minecraft:ochre_froglight
setblock 275 176 237 minecraft:cyan_stained_glass
setblock 275 176 261 minecraft:black_stained_glass
setblock 275 176 269 minecraft:black_stained_glass
setblock 276 176 230 minecraft:ochre_froglight
setblock 276 176 232 minecraft:black_stained_glass
setblock 276 176 234 minecraft:black_stained_glass
setblock 276 176 236 minecraft:cyan_stained_glass
setblock 276 176 243 minecraft:cyan_stained_glass
setblock 276 176 245 minecraft:ochre_froglight
setblock 276 176 247 minecraft:black_stained_glass
setblock 276 176 249 minecraft:light_blue_stained_glass
setblock 276 176 251 minecraft:black_stained_glass
setblock 276 176 253 minecraft:black_stained_glass
setblock 276 176 262 minecraft:sea_lantern
setblock 276 176 264 minecraft:black_stained_glass
setblock 276 176 266 minecraft:black_stained_glass
setblock 276 176 268 minecraft:ochre_froglight
fill 277 176 261 277 189 261 minecraft:black_concrete
fill 277 176 266 277 266 266 minecraft:black_concrete
setblock 235 177 244 minecraft:blue_concrete
setblock 235 177 258 minecraft:pearlescent_froglight
fill 236 177 230 236 178 230 minecraft:gray_concrete
fill 236 177 232 236 178 232 minecraft:gray_concrete
fill 236 177 234 236 178 234 minecraft:gray_concrete
fill 236 177 236 236 178 236 minecraft:gray_concrete
fill 236 177 243 236 178 243 minecraft:black_concrete
fill 236 177 245 236 178 245 minecraft:black_concrete
fill 236 177 247 236 178 247 minecraft:black_concrete
fill 236 177 249 236 178 249 minecraft:black_concrete
fill 236 177 251 236 178 251 minecraft:black_concrete
fill 236 177 253 236 178 253 minecraft:black_concrete
fill 237 177 229 237 178 229 minecraft:gray_concrete
fill 237 177 237 237 178 237 minecraft:gray_concrete
fill 237 177 242 237 178 242 minecraft:black_concrete
fill 237 177 255 237 178 255 minecraft:black_concrete
fill 239 177 229 239 178 229 minecraft:gray_concrete
fill 239 177 237 239 178 237 minecraft:gray_concrete
fill 239 177 242 239 178 242 minecraft:black_concrete
fill 239 177 255 239 178 255 minecraft:black_concrete
setblock 239 177 270 minecraft:purple_concrete
fill 241 177 229 241 178 229 minecraft:gray_concrete
fill 241 177 237 241 178 237 minecraft:gray_concrete
fill 241 177 243 241 178 243 minecraft:black_concrete
fill 241 177 245 241 178 245 minecraft:black_concrete
fill 241 177 247 241 178 247 minecraft:black_concrete
fill 241 177 249 241 178 249 minecraft:black_concrete
fill 241 177 251 241 178 251 minecraft:black_concrete
fill 241 177 253 241 178 253 minecraft:black_concrete
fill 243 177 229 243 178 229 minecraft:gray_concrete
fill 243 177 237 243 178 237 minecraft:gray_concrete
fill 244 177 230 244 178 230 minecraft:gray_concrete
fill 244 177 232 244 178 232 minecraft:gray_concrete
fill 244 177 234 244 178 234 minecraft:gray_concrete
fill 244 177 236 244 178 236 minecraft:gray_concrete
fill 249 177 265 249 178 265 minecraft:gray_concrete
fill 250 177 264 250 178 264 minecraft:gray_concrete
fill 250 177 269 250 178 269 minecraft:gray_concrete
fill 252 177 231 252 178 232 minecraft:gray_concrete
fill 252 177 269 252 178 269 minecraft:gray_concrete
fill 254 177 231 254 178 232 minecraft:gray_concrete
fill 254 177 264 254 178 264 minecraft:gray_concrete
fill 254 177 269 254 178 269 minecraft:gray_concrete
setblock 255 177 270 minecraft:magenta_concrete
fill 256 177 231 256 178 232 minecraft:gray_concrete
fill 256 177 264 256 178 264 minecraft:gray_concrete
fill 256 177 269 256 178 269 minecraft:gray_concrete
setblock 258 177 228 minecraft:purple_concrete
fill 258 177 231 258 178 232 minecraft:gray_concrete
fill 258 177 264 258 178 264 minecraft:gray_concrete
fill 258 177 266 264 178 266 minecraft:sea_lantern
fill 258 177 269 258 178 269 minecraft:gray_concrete
fill 259 177 228 259 181 228 minecraft:black_concrete
fill 260 177 264 260 178 264 minecraft:gray_concrete
fill 260 177 269 260 178 269 minecraft:gray_concrete
setblock 262 177 265 minecraft:gray_concrete
setblock 262 177 267 minecraft:gray_concrete
fill 268 177 230 268 178 230 minecraft:blue_terracotta
fill 268 177 232 268 178 232 minecraft:blue_terracotta
fill 268 177 234 268 178 234 minecraft:blue_terracotta
fill 268 177 236 268 178 236 minecraft:blue_terracotta
fill 268 177 262 268 178 262 minecraft:gray_concrete
fill 268 177 264 268 178 264 minecraft:gray_concrete
setblock 268 177 266 minecraft:gray_concrete
fill 268 177 268 268 178 268 minecraft:gray_concrete
fill 269 177 229 269 178 229 minecraft:blue_terracotta
fill 269 177 237 269 178 237 minecraft:blue_terracotta
fill 269 177 261 269 178 261 minecraft:gray_concrete
fill 269 177 265 272 178 265 minecraft:sea_lantern
fill 269 177 269 269 178 269 minecraft:gray_concrete
fill 271 177 229 271 178 229 minecraft:blue_terracotta
fill 271 177 237 271 178 237 minecraft:blue_terracotta
fill 271 177 243 271 178 243 minecraft:gray_concrete
fill 271 177 245 271 178 245 minecraft:gray_concrete
fill 271 177 247 271 178 247 minecraft:gray_concrete
fill 271 177 249 271 178 249 minecraft:gray_concrete
fill 271 177 251 271 178 251 minecraft:gray_concrete
fill 271 177 253 271 178 253 minecraft:gray_concrete
fill 271 177 261 271 178 261 minecraft:gray_concrete
fill 271 177 263 273 177 264 minecraft:gray_concrete
fill 271 177 269 271 178 269 minecraft:gray_concrete
fill 272 177 242 272 178 242 minecraft:gray_concrete
fill 272 177 255 272 178 255 minecraft:gray_concrete
fill 273 177 229 273 178 229 minecraft:blue_terracotta
fill 273 177 237 273 178 237 minecraft:blue_terracotta
fill 273 177 261 273 178 261 minecraft:gray_concrete
setblock 273 177 265 minecraft:gray_concrete
fill 273 177 269 273 178 269 minecraft:gray_concrete
fill 274 177 242 274 178 242 minecraft:gray_concrete
fill 274 177 255 274 178 255 minecraft:gray_concrete
fill 275 177 229 275 178 229 minecraft:blue_terracotta
fill 275 177 237 275 178 237 minecraft:blue_terracotta
fill 275 177 261 275 178 261 minecraft:gray_concrete
fill 275 177 269 275 178 269 minecraft:gray_concrete
fill 276 177 230 276 178 230 minecraft:blue_terracotta
fill 276 177 232 276 178 232 minecraft:blue_terracotta
fill 276 177 234 276 178 234 minecraft:blue_terracotta
fill 276 177 236 276 178 236 minecraft:blue_terracotta
fill 276 177 243 276 178 243 minecraft:gray_concrete
fill 276 177 245 276 178 245 minecraft:gray_concrete
fill 276 177 247 276 178 247 minecraft:gray_concrete
fill 276 177 249 276 178 249 minecraft:gray_concrete
fill 276 177 251 276 178 251 minecraft:gray_concrete
fill 276 177 253 276 178 253 minecraft:gray_concrete
fill 276 177 262 276 178 262 minecraft:gray_concrete
fill 276 177 264 276 178 264 minecraft:gray_concrete
fill 276 177 266 276 178 266 minecraft:gray_concrete
fill 276 177 268 276 178 268 minecraft:gray_concrete
fill 235 178 244 235 308 244 minecraft:black_concrete
fill 235 178 258 235 194 258 minecraft:black_concrete
setblock 235 178 264 minecraft:blue_concrete
setblock 238 178 239 minecraft:light[level=15]
setblock 238 178 263 minecraft:light[level=15]
fill 239 178 270 239 181 270 minecraft:black_concrete
setblock 246 178 231 minecraft:light[level=15]
setblock 246 178 239 minecraft:light[level=15]
setblock 246 178 247 minecraft:light[level=15]
setblock 246 178 255 minecraft:light[level=15]
setblock 251 178 228 minecraft:sea_lantern
setblock 254 178 239 minecraft:light[level=15]
setblock 254 178 247 minecraft:light[level=15]
setblock 254 178 255 minecraft:light[level=15]
fill 255 178 270 255 188 270 minecraft:black_concrete
fill 257 178 267 258 282 267 minecraft:gray_concrete
fill 258 178 228 258 191 228 minecraft:black_concrete
fill 259 178 264 259 282 264 minecraft:gray_concrete
fill 259 178 265 268 179 265 minecraft:light_blue_stained_glass
fill 259 178 267 263 179 267 minecraft:light_blue_stained_glass
setblock 262 178 231 minecraft:light[level=15]
setblock 262 178 239 minecraft:light[level=15]
setblock 262 178 247 minecraft:light[level=15]
setblock 262 178 255 minecraft:light[level=15]
setblock 262 178 263 minecraft:light[level=15]
fill 265 178 266 272 179 266 minecraft:light_blue_stained_glass
setblock 270 178 239 minecraft:light[level=15]
setblock 270 178 247 minecraft:light[level=15]
setblock 270 178 255 minecraft:light[level=15]
fill 270 178 264 272 179 264 minecraft:light_blue_stained_glass
fill 271 178 263 273 185 263 minecraft:gray_concrete
fill 273 178 264 273 185 264 minecraft:gray_concrete
fill 273 178 265 273 179 265 minecraft:light_blue_stained_glass
fill 235 179 264 235 192 264 minecraft:black_concrete
setblock 236 179 230 minecraft:black_stained_glass
setblock 236 179 232 minecraft:black_stained_glass
setblock 236 179 234 minecraft:black_stained_glass
setblock 236 179 236 minecraft:black_stained_glass
setblock 236 179 243 minecraft:black_stained_glass
setblock 236 179 245 minecraft:black_stained_glass
setblock 236 179 247 minecraft:ochre_froglight
setblock 236 179 249 minecraft:pearlescent_froglight
setblock 236 179 251 minecraft:ochre_froglight
setblock 236 179 253 minecraft:sea_lantern
setblock 237 179 229 minecraft:ochre_froglight
setblock 237 179 237 minecraft:cyan_stained_glass
setblock 237 179 242 minecraft:black_stained_glass
setblock 237 179 255 minecraft:magenta_stained_glass
setblock 239 179 229 minecraft:pearlescent_froglight
setblock 239 179 237 minecraft:black_stained_glass
setblock 239 179 242 minecraft:magenta_stained_glass
setblock 239 179 255 minecraft:pearlescent_froglight
setblock 241 179 229 minecraft:black_stained_glass
setblock 241 179 237 minecraft:sea_lantern
setblock 241 179 243 minecraft:black_stained_glass
setblock 241 179 245 minecraft:light_blue_stained_glass
setblock 241 179 247 minecraft:light_blue_stained_glass
setblock 241 179 249 minecraft:black_stained_glass
setblock 241 179 251 minecraft:light_blue_stained_glass
setblock 241 179 253 minecraft:black_stained_glass
setblock 243 179 229 minecraft:black_stained_glass
setblock 243 179 237 minecraft:black_stained_glass
setblock 244 179 230 minecraft:black_stained_glass
setblock 244 179 232 minecraft:sea_lantern
setblock 244 179 234 minecraft:ochre_froglight
setblock 244 179 236 minecraft:cyan_stained_glass
setblock 249 179 265 minecraft:black_stained_glass
setblock 249 179 267 minecraft:pearlescent_froglight
setblock 250 179 264 minecraft:black_stained_glass
setblock 250 179 269 minecraft:magenta_stained_glass
setblock 251 179 228 minecraft:ochre_froglight
setblock 252 179 231 minecraft:black_stained_glass
setblock 252 179 232 minecraft:sea_lantern
setblock 252 179 264 minecraft:magenta_stained_glass
setblock 252 179 269 minecraft:ochre_froglight
setblock 254 179 231 minecraft:black_stained_glass
setblock 254 179 232 minecraft:magenta_stained_glass
setblock 254 179 264 minecraft:ochre_froglight
setblock 254 179 269 minecraft:black_stained_glass
setblock 256 179 231 minecraft:black_stained_glass
setblock 256 179 232 minecraft:magenta_stained_glass
setblock 256 179 264 minecraft:black_stained_glass
setblock 256 179 269 minecraft:pearlescent_froglight
setblock 258 179 231 minecraft:black_stained_glass
setblock 258 179 232 minecraft:magenta_stained_glass
setblock 258 179 264 minecraft:cyan_stained_glass
fill 258 179 266 258 282 266 minecraft:gray_concrete
setblock 258 179 269 minecraft:magenta_stained_glass
fill 259 179 266 264 179 266 minecraft:light_blue_stained_glass
setblock 260 179 264 minecraft:pearlescent_froglight
setblock 260 179 269 minecraft:sea_lantern
setblock 268 179 230 minecraft:black_stained_glass
setblock 268 179 232 minecraft:light_blue_stained_glass
setblock 268 179 234 minecraft:black_stained_glass
setblock 268 179 236 minecraft:pearlescent_froglight
setblock 268 179 262 minecraft:pearlescent_froglight
setblock 268 179 264 minecraft:black_stained_glass
setblock 268 179 268 minecraft:black_stained_glass
setblock 269 179 229 minecraft:black_stained_glass
setblock 269 179 237 minecraft:pearlescent_froglight
setblock 269 179 261 minecraft:light_blue_stained_glass
fill 269 179 265 272 179 265 minecraft:light_blue_stained_glass
setblock 269 179 269 minecraft:black_stained_glass
setblock 271 179 229 minecraft:pearlescent_froglight
setblock 271 179 237 minecraft:magenta_stained_glass
setblock 271 179 243 minecraft:pearlescent_froglight
setblock 271 179 245 minecraft:light_blue_stained_glass
setblock 271 179 247 minecraft:black_stained_glass
setblock 271 179 249 minecraft:black_stained_glass
setblock 271 179 251 minecraft:black_stained_glass
setblock 271 179 253 minecraft:black_stained_glass
setblock 271 179 261 minecraft:magenta_stained_glass
setblock 271 179 269 minecraft:cyan_stained_glass
setblock 272 179 242 minecraft:sea_lantern
setblock 272 179 255 minecraft:ochre_froglight
setblock 273 179 229 minecraft:black_stained_glass
setblock 273 179 237 minecraft:cyan_stained_glass
setblock 273 179 261 minecraft:black_stained_glass
setblock 273 179 269 minecraft:black_stained_glass
setblock 274 179 242 minecraft:sea_lantern
setblock 274 179 255 minecraft:sea_lantern
setblock 275 179 229 minecraft:sea_lantern
setblock 275 179 237 minecraft:sea_lantern
setblock 275 179 261 minecraft:pearlescent_froglight
setblock 275 179 269 minecraft:black_stained_glass
setblock 276 179 230 minecraft:ochre_froglight
setblock 276 179 232 minecraft:black_stained_glass
setblock 276 179 234 minecraft:black_stained_glass
setblock 276 179 236 minecraft:sea_lantern
setblock 276 179 243 minecraft:sea_lantern
setblock 276 179 245 minecraft:black_stained_glass
setblock 276 179 247 minecraft:black_stained_glass
setblock 276 179 249 minecraft:sea_lantern
setblock 276 179 251 minecraft:pearlescent_froglight
setblock 276 179 253 minecraft:black_stained_glass
setblock 276 179 262 minecraft:sea_lantern
setblock 276 179 264 minecraft:magenta_stained_glass
setblock 276 179 266 minecraft:cyan_stained_glass
setblock 276 179 268 minecraft:cyan_stained_glass
setblock 235 180 240 minecraft:magenta_concrete
fill 236 180 230 236 181 230 minecraft:gray_concrete
fill 236 180 232 236 181 232 minecraft:gray_concrete
fill 236 180 234 236 181 234 minecraft:gray_concrete
fill 236 180 236 236 181 236 minecraft:gray_concrete
fill 236 180 243 236 181 243 minecraft:black_concrete
fill 236 180 245 236 181 245 minecraft:black_concrete
fill 236 180 247 236 181 247 minecraft:black_concrete
fill 236 180 249 236 181 249 minecraft:black_concrete
fill 236 180 251 236 181 251 minecraft:black_concrete
fill 236 180 253 236 181 253 minecraft:black_concrete
fill 237 180 229 237 181 229 minecraft:gray_concrete
fill 237 180 237 237 181 237 minecraft:gray_concrete
fill 237 180 242 237 181 242 minecraft:black_concrete
fill 237 180 255 237 181 255 minecraft:black_concrete
fill 239 180 229 239 181 229 minecraft:gray_concrete
fill 239 180 237 239 181 237 minecraft:gray_concrete
fill 239 180 242 239 181 242 minecraft:black_concrete
fill 239 180 255 239 181 255 minecraft:black_concrete
fill 241 180 229 241 181 229 minecraft:gray_concrete
fill 241 180 237 241 181 237 minecraft:gray_concrete
fill 241 180 243 241 181 243 minecraft:black_concrete
fill 241 180 245 241 181 245 minecraft:black_concrete
fill 241 180 247 241 181 247 minecraft:black_concrete
fill 241 180 249 241 181 249 minecraft:black_concrete
fill 241 180 251 241 181 251 minecraft:black_concrete
fill 241 180 253 241 181 253 minecraft:black_concrete
fill 243 180 229 243 181 229 minecraft:gray_concrete
fill 243 180 237 243 181 237 minecraft:gray_concrete
fill 244 180 230 244 181 230 minecraft:gray_concrete
fill 244 180 232 244 181 232 minecraft:gray_concrete
fill 244 180 234 244 181 234 minecraft:gray_concrete
fill 244 180 236 244 181 236 minecraft:gray_concrete
fill 249 180 265 249 181 265 minecraft:gray_concrete
fill 249 180 267 249 181 267 minecraft:gray_concrete
fill 250 180 264 250 181 264 minecraft:gray_concrete
fill 250 180 269 250 181 269 minecraft:gray_concrete
fill 251 180 228 251 191 228 minecraft:black_concrete
fill 252 180 231 252 181 232 minecraft:gray_concrete
fill 252 180 264 252 181 264 minecraft:gray_concrete
fill 252 180 269 252 181 269 minecraft:gray_concrete
fill 254 180 231 254 181 232 minecraft:gray_concrete
fill 254 180 264 254 181 264 minecraft:gray_concrete
fill 254 180 269 254 181 269 minecraft:gray_concrete
fill 256 180 231 256 181 232 minecraft:gray_concrete
fill 256 180 264 256 181 264 minecraft:gray_concrete
fill 256 180 269 256 181 269 minecraft:gray_concrete
fill 258 180 231 258 181 232 minecraft:gray_concrete
fill 258 180 264 258 181 264 minecraft:gray_concrete
fill 258 180 269 258 181 269 minecraft:gray_concrete
fill 259 180 265 262 181 267 minecraft:gray_concrete
fill 260 180 264 260 181 264 minecraft:gray_concrete
fill 260 180 269 260 181 269 minecraft:gray_concrete
setblock 268 180 230 minecraft:blue_terracotta
setblock 268 180 232 minecraft:blue_terracotta
setblock 268 180 234 minecraft:blue_terracotta
setblock 268 180 236 minecraft:blue_terracotta
fill 268 180 262 268 181 262 minecraft:gray_concrete
fill 268 180 264 268 181 266 minecraft:gray_concrete
fill 268 180 268 268 181 268 minecraft:gray_concrete
setblock 269 180 229 minecraft:blue_terracotta
setblock 269 180 237 minecraft:blue_terracotta
fill 269 180 261 269 181 261 minecraft:gray_concrete
fill 269 180 265 272 185 266 minecraft:gray_concrete
fill 269 180 269 269 181 269 minecraft:gray_concrete
fill 270 180 264 272 185 264 minecraft:gray_concrete
setblock 271 180 229 minecraft:blue_terracotta
setblock 271 180 237 minecraft:blue_terracotta
fill 271 180 243 271 181 243 minecraft:gray_concrete
fill 271 180 245 271 181 245 minecraft:gray_concrete
fill 271 180 247 271 181 247 minecraft:gray_concrete
fill 271 180 249 271 181 249 minecraft:gray_concrete
fill 271 180 251 271 181 251 minecraft:gray_concrete
fill 271 180 253 271 181 253 minecraft:gray_concrete
fill 271 180 261 271 181 261 minecraft:gray_concrete
fill 271 180 269 271 181 269 minecraft:gray_concrete
fill 272 180 242 272 181 242 minecraft:gray_concrete
fill 272 180 255 272 181 255 minecraft:gray_concrete
setblock 273 180 229 minecraft:blue_terracotta
setblock 273 180 237 minecraft:blue_terracotta
fill 273 180 261 273 181 261 minecraft:gray_concrete
fill 273 180 265 273 185 265 minecraft:gray_concrete
fill 273 180 269 273 181 269 minecraft:gray_concrete
fill 274 180 242 274 181 242 minecraft:gray_concrete
fill 274 180 255 274 181 255 minecraft:gray_concrete
setblock 275 180 229 minecraft:blue_terracotta
setblock 275 180 237 minecraft:blue_terracotta
fill 275 180 261 275 181 261 minecraft:gray_concrete
fill 275 180 269 275 181 269 minecraft:gray_concrete
setblock 276 180 230 minecraft:blue_terracotta
setblock 276 180 232 minecraft:blue_terracotta
setblock 276 180 234 minecraft:blue_terracotta
setblock 276 180 236 minecraft:blue_terracotta
fill 276 180 243 276 181 243 minecraft:gray_concrete
fill 276 180 245 276 181 245 minecraft:gray_concrete
fill 276 180 247 276 181 247 minecraft:gray_concrete
fill 276 180 249 276 181 249 minecraft:gray_concrete
fill 276 180 251 276 181 251 minecraft:gray_concrete
fill 276 180 253 276 181 253 minecraft:gray_concrete
fill 276 180 262 276 181 262 minecraft:gray_concrete
fill 276 180 264 276 181 264 minecraft:gray_concrete
fill 276 180 266 276 181 266 minecraft:gray_concrete
fill 276 180 268 276 181 268 minecraft:gray_concrete
setblock 277 180 237 minecraft:magenta_concrete
fill 235 181 240 235 263 240 minecraft:black_concrete
setblock 238 181 238 minecraft:light[level=12]
setblock 238 181 259 minecraft:light[level=12]
setblock 238 181 266 minecraft:light[level=12]
setblock 245 181 231 minecraft:light[level=12]
setblock 245 181 238 minecraft:light[level=12]
setblock 245 181 245 minecraft:light[level=12]
setblock 245 181 252 minecraft:light[level=12]
setblock 245 181 259 minecraft:light[level=12]
setblock 245 181 266 minecraft:light[level=12]
setblock 252 181 238 minecraft:light[level=12]
setblock 252 181 245 minecraft:light[level=12]
setblock 252 181 252 minecraft:light[level=12]
setblock 252 181 259 minecraft:light[level=12]
setblock 259 181 238 minecraft:light[level=12]
setblock 259 181 245 minecraft:light[level=12]
setblock 259 181 252 minecraft:light[level=12]
setblock 259 181 259 minecraft:light[level=12]
setblock 260 181 228 minecraft:magenta_concrete
fill 261 181 228 261 196 228 minecraft:black_concrete
setblock 266 181 231 minecraft:light[level=12]
setblock 266 181 238 minecraft:light[level=12]
setblock 266 181 245 minecraft:light[level=12]
setblock 266 181 252 minecraft:light[level=12]
setblock 266 181 259 minecraft:light[level=12]
setblock 266 181 266 minecraft:light[level=12]
fill 268 181 229 276 181 237 minecraft:black_concrete
setblock 273 181 238 minecraft:light[level=12]
setblock 273 181 259 minecraft:light[level=12]
fill 277 181 237 277 221 237 minecraft:black_concrete
fill 235 182 230 236 182 230 minecraft:ochre_froglight
setblock 236 182 232 minecraft:black_stained_glass
setblock 236 182 234 minecraft:light_blue_stained_glass
setblock 236 182 236 minecraft:black_stained_glass
setblock 236 182 243 minecraft:black_stained_glass
setblock 236 182 245 minecraft:black_stained_glass
setblock 236 182 247 minecraft:magenta_stained_glass
setblock 236 182 249 minecraft:black_stained_glass
setblock 236 182 251 minecraft:ochre_froglight
setblock 236 182 253 minecraft:sea_lantern
setblock 237 182 229 minecraft:ochre_froglight
setblock 237 182 237 minecraft:ochre_froglight
setblock 237 182 242 minecraft:magenta_stained_glass
setblock 237 182 255 minecraft:sea_lantern
setblock 239 182 229 minecraft:cyan_stained_glass
setblock 239 182 237 minecraft:pearlescent_froglight
setblock 239 182 242 minecraft:black_stained_glass
setblock 239 182 255 minecraft:pearlescent_froglight
setblock 239 182 270 minecraft:ochre_froglight
setblock 241 182 229 minecraft:pearlescent_froglight
setblock 241 182 237 minecraft:pearlescent_froglight
setblock 241 182 243 minecraft:pearlescent_froglight
setblock 241 182 245 minecraft:black_stained_glass
setblock 241 182 247 minecraft:pearlescent_froglight
setblock 241 182 249 minecraft:black_stained_glass
setblock 241 182 251 minecraft:black_stained_glass
setblock 241 182 253 minecraft:black_stained_glass
setblock 243 182 229 minecraft:black_stained_glass
setblock 243 182 237 minecraft:light_blue_stained_glass
setblock 244 182 230 minecraft:black_stained_glass
setblock 244 182 232 minecraft:ochre_froglight
setblock 244 182 234 minecraft:cyan_stained_glass
setblock 244 182 236 minecraft:cyan_stained_glass
setblock 249 182 265 minecraft:black_stained_glass
setblock 249 182 267 minecraft:ochre_froglight
setblock 250 182 264 minecraft:black_stained_glass
setblock 250 182 269 minecraft:black_stained_glass
setblock 252 182 264 minecraft:black_stained_glass
setblock 252 182 269 minecraft:ochre_froglight
setblock 254 182 228 minecraft:cyan_concrete
setblock 254 182 264 minecraft:black_stained_glass
setblock 254 182 269 minecraft:ochre_froglight
setblock 256 182 264 minecraft:cyan_stained_glass
setblock 256 182 269 minecraft:sea_lantern
setblock 258 182 264 minecraft:pearlescent_froglight
setblock 258 182 269 minecraft:ochre_froglight
setblock 259 182 228 minecraft:pearlescent_froglight
fill 259 182 265 261 282 267 minecraft:gray_concrete
fill 260 182 228 260 188 228 minecraft:black_concrete
setblock 260 182 264 minecraft:light_blue_stained_glass
setblock 260 182 269 minecraft:black_stained_glass
setblock 262 182 265 minecraft:ochre_froglight
fill 262 182 266 262 282 266 minecraft:gray_concrete
setblock 262 182 267 minecraft:sea_lantern
fill 268 182 229 268 182 237 minecraft:sea_lantern
setblock 268 182 262 minecraft:black_stained_glass
setblock 268 182 264 minecraft:black_stained_glass
fill 268 182 265 268 185 265 minecraft:gray_concrete
setblock 268 182 266 minecraft:cyan_stained_glass
setblock 268 182 268 minecraft:cyan_stained_glass
fill 269 182 229 276 182 229 minecraft:sea_lantern
schedule function dropper:buildpart/53_5 1t
