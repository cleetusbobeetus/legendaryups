setblock 212 207 292 minecraft:light[level=12]
setblock 212 207 299 minecraft:light[level=12]
setblock 212 207 306 minecraft:light[level=12]
setblock 212 207 313 minecraft:light[level=12]
setblock 215 207 278 minecraft:light[level=15]
setblock 215 207 286 minecraft:light[level=15]
setblock 215 207 294 minecraft:light[level=15]
setblock 215 207 302 minecraft:light[level=15]
setblock 215 207 310 minecraft:light[level=15]
setblock 219 207 278 minecraft:light[level=12]
setblock 219 207 285 minecraft:light[level=12]
setblock 219 207 292 minecraft:light[level=12]
setblock 219 207 299 minecraft:light[level=12]
setblock 219 207 306 minecraft:light[level=12]
setblock 219 207 313 minecraft:light[level=12]
fill 222 207 313 222 207 314 minecraft:dark_prismarine
setblock 223 207 278 minecraft:light[level=15]
setblock 223 207 286 minecraft:light[level=15]
setblock 223 207 294 minecraft:light[level=15]
setblock 223 207 302 minecraft:light[level=15]
setblock 223 207 310 minecraft:light[level=15]
setblock 223 207 311 minecraft:dark_prismarine
fill 223 207 315 225 207 315 minecraft:dark_prismarine
fill 225 207 281 225 207 311 minecraft:gold_block
setblock 226 207 285 minecraft:light[level=12]
setblock 226 207 292 minecraft:light[level=12]
setblock 226 207 299 minecraft:light[level=12]
setblock 226 207 306 minecraft:light[level=12]
setblock 226 207 311 minecraft:dark_prismarine
fill 223 208 312 224 216 312 minecraft:prismarine_bricks
setblock 230 208 281 minecraft:sea_lantern
setblock 188 209 276 minecraft:sea_lantern
fill 188 209 277 188 223 277 minecraft:prismarine_bricks
fill 230 209 281 230 226 281 minecraft:prismarine_bricks
fill 188 210 276 188 223 276 minecraft:prismarine_bricks
setblock 188 212 280 minecraft:sea_lantern
fill 188 212 281 188 226 281 minecraft:prismarine_bricks
fill 188 212 282 188 212 283 minecraft:sea_lantern
fill 188 212 284 188 213 284 minecraft:prismarine_bricks
fill 188 212 293 188 226 293 minecraft:prismarine_bricks
fill 188 212 294 188 212 295 minecraft:sea_lantern
fill 188 212 296 188 226 296 minecraft:prismarine_bricks
fill 188 212 305 188 224 305 minecraft:prismarine_bricks
fill 188 212 306 188 212 307 minecraft:sea_lantern
fill 188 212 308 188 222 308 minecraft:prismarine_bricks
fill 188 212 317 188 222 317 minecraft:prismarine_bricks
fill 189 212 317 190 212 317 minecraft:sea_lantern
fill 191 212 317 191 226 317 minecraft:prismarine_bricks
fill 195 212 275 195 226 275 minecraft:prismarine_bricks
fill 196 212 275 197 212 275 minecraft:sea_lantern
fill 198 212 275 198 226 275 minecraft:prismarine_bricks
fill 200 212 317 200 226 317 minecraft:prismarine_bricks
fill 201 212 317 202 212 317 minecraft:sea_lantern
fill 203 212 314 204 213 314 minecraft:white_stained_glass
fill 203 212 317 203 226 317 minecraft:prismarine_bricks
fill 207 212 275 207 222 275 minecraft:prismarine_bricks
fill 208 212 275 209 212 275 minecraft:sea_lantern
fill 210 212 275 210 226 275 minecraft:prismarine_bricks
fill 212 212 317 212 223 317 minecraft:prismarine_bricks
fill 213 212 317 214 212 317 minecraft:sea_lantern
fill 215 212 317 215 223 317 minecraft:prismarine_bricks
fill 219 212 275 219 226 275 minecraft:prismarine_bricks
fill 220 212 275 221 212 275 minecraft:sea_lantern
fill 222 212 275 222 226 275 minecraft:prismarine_bricks
fill 224 212 317 224 226 317 minecraft:prismarine_bricks
fill 225 212 317 226 212 317 minecraft:sea_lantern
fill 227 212 317 227 226 317 minecraft:prismarine_bricks
fill 230 212 276 230 226 276 minecraft:prismarine_bricks
fill 230 212 277 230 212 278 minecraft:sea_lantern
fill 230 212 279 230 226 279 minecraft:prismarine_bricks
fill 230 212 288 230 223 288 minecraft:prismarine_bricks
fill 230 212 289 230 212 290 minecraft:sea_lantern
fill 230 212 291 230 226 291 minecraft:prismarine_bricks
fill 230 212 300 230 226 300 minecraft:prismarine_bricks
fill 230 212 301 230 212 302 minecraft:sea_lantern
fill 230 212 303 230 226 303 minecraft:prismarine_bricks
fill 230 212 312 230 226 312 minecraft:prismarine_bricks
fill 230 212 313 230 212 314 minecraft:sea_lantern
fill 230 212 315 230 226 315 minecraft:prismarine_bricks
fill 188 213 280 188 226 280 minecraft:prismarine_bricks
fill 188 213 282 188 223 283 minecraft:prismarine_bricks
fill 188 213 294 188 226 295 minecraft:prismarine_bricks
fill 188 213 306 188 221 307 minecraft:prismarine_bricks
fill 189 213 317 190 224 317 minecraft:prismarine_bricks
setblock 191 213 285 minecraft:light[level=12]
setblock 191 213 292 minecraft:light[level=12]
setblock 191 213 299 minecraft:light[level=12]
setblock 191 213 306 minecraft:light[level=12]
fill 193 213 317 193 226 317 minecraft:prismarine_bricks
setblock 194 213 317 minecraft:sea_lantern
fill 196 213 275 197 219 275 minecraft:prismarine_bricks
setblock 198 213 278 minecraft:light[level=12]
setblock 198 213 285 minecraft:light[level=12]
setblock 198 213 292 minecraft:light[level=12]
setblock 198 213 299 minecraft:light[level=12]
setblock 198 213 306 minecraft:light[level=12]
setblock 198 213 313 minecraft:light[level=12]
fill 201 213 317 202 226 317 minecraft:prismarine_bricks
setblock 205 213 278 minecraft:light[level=12]
setblock 205 213 285 minecraft:light[level=12]
setblock 205 213 292 minecraft:light[level=12]
setblock 205 213 299 minecraft:light[level=12]
setblock 205 213 306 minecraft:light[level=12]
setblock 205 213 313 minecraft:light[level=12]
fill 208 213 275 209 226 275 minecraft:prismarine_bricks
setblock 212 213 278 minecraft:light[level=12]
setblock 212 213 285 minecraft:light[level=12]
setblock 212 213 292 minecraft:light[level=12]
setblock 212 213 299 minecraft:light[level=12]
setblock 212 213 306 minecraft:light[level=12]
setblock 212 213 313 minecraft:light[level=12]
fill 213 213 317 214 222 317 minecraft:prismarine_bricks
setblock 219 213 278 minecraft:light[level=12]
setblock 219 213 285 minecraft:light[level=12]
setblock 219 213 292 minecraft:light[level=12]
setblock 219 213 299 minecraft:light[level=12]
setblock 219 213 306 minecraft:light[level=12]
setblock 219 213 313 minecraft:light[level=12]
fill 220 213 275 221 224 275 minecraft:prismarine_bricks
fill 225 213 317 226 226 317 minecraft:prismarine_bricks
setblock 226 213 285 minecraft:light[level=12]
setblock 226 213 292 minecraft:light[level=12]
setblock 226 213 299 minecraft:light[level=12]
setblock 226 213 306 minecraft:light[level=12]
fill 230 213 277 230 224 278 minecraft:prismarine_bricks
fill 230 213 289 230 223 290 minecraft:prismarine_bricks
fill 230 213 301 230 226 302 minecraft:prismarine_bricks
fill 230 213 313 230 222 314 minecraft:prismarine_bricks
setblock 188 214 284 minecraft:sea_lantern
fill 194 214 317 194 226 317 minecraft:prismarine_bricks
fill 207 214 316 207 216 316 minecraft:prismarine_bricks
setblock 207 214 317 minecraft:sea_lantern
fill 188 215 284 188 226 284 minecraft:prismarine_bricks
setblock 191 215 286 minecraft:light[level=15]
setblock 191 215 294 minecraft:light[level=15]
setblock 191 215 302 minecraft:light[level=15]
setblock 191 215 310 minecraft:light[level=15]
setblock 199 215 278 minecraft:light[level=15]
setblock 199 215 286 minecraft:light[level=15]
setblock 199 215 294 minecraft:light[level=15]
setblock 199 215 302 minecraft:light[level=15]
setblock 199 215 310 minecraft:light[level=15]
setblock 207 215 278 minecraft:light[level=15]
setblock 207 215 286 minecraft:light[level=15]
setblock 207 215 294 minecraft:light[level=15]
setblock 207 215 302 minecraft:light[level=15]
setblock 207 215 310 minecraft:light[level=15]
fill 207 215 317 207 222 317 minecraft:prismarine_bricks
setblock 215 215 278 minecraft:light[level=15]
setblock 215 215 286 minecraft:light[level=15]
setblock 215 215 294 minecraft:light[level=15]
setblock 215 215 302 minecraft:light[level=15]
setblock 215 215 310 minecraft:light[level=15]
fill 222 215 312 222 215 314 minecraft:dark_prismarine
setblock 223 215 278 minecraft:light[level=15]
setblock 223 215 286 minecraft:light[level=15]
setblock 223 215 294 minecraft:light[level=15]
setblock 223 215 302 minecraft:light[level=15]
setblock 223 215 310 minecraft:light[level=15]
setblock 223 215 311 minecraft:dark_prismarine
fill 223 215 315 225 215 315 minecraft:dark_prismarine
fill 225 215 311 226 215 311 minecraft:dark_prismarine
setblock 192 216 317 minecraft:sea_lantern
fill 222 216 312 222 216 313 minecraft:gold_block
setblock 223 216 311 minecraft:gold_block
fill 224 216 315 225 216 315 minecraft:gold_block
setblock 225 216 311 minecraft:gold_block
fill 192 217 317 192 226 317 minecraft:prismarine_bricks
setblock 211 217 275 minecraft:sea_lantern
fill 230 217 285 230 223 285 minecraft:prismarine_bricks
fill 211 218 275 211 222 275 minecraft:prismarine_bricks
setblock 191 219 285 minecraft:light[level=12]
setblock 191 219 292 minecraft:light[level=12]
setblock 191 219 299 minecraft:light[level=12]
setblock 191 219 306 minecraft:light[level=12]
setblock 198 219 278 minecraft:light[level=12]
setblock 198 219 285 minecraft:light[level=12]
setblock 198 219 292 minecraft:light[level=12]
setblock 198 219 299 minecraft:light[level=12]
setblock 198 219 306 minecraft:light[level=12]
setblock 198 219 313 minecraft:light[level=12]
setblock 205 219 278 minecraft:light[level=12]
setblock 205 219 285 minecraft:light[level=12]
setblock 205 219 292 minecraft:light[level=12]
setblock 205 219 299 minecraft:light[level=12]
setblock 205 219 306 minecraft:light[level=12]
setblock 205 219 313 minecraft:light[level=12]
setblock 212 219 278 minecraft:light[level=12]
setblock 212 219 285 minecraft:light[level=12]
setblock 212 219 292 minecraft:light[level=12]
setblock 212 219 299 minecraft:light[level=12]
setblock 212 219 306 minecraft:light[level=12]
setblock 212 219 313 minecraft:light[level=12]
setblock 219 219 278 minecraft:light[level=12]
setblock 219 219 285 minecraft:light[level=12]
setblock 219 219 292 minecraft:light[level=12]
setblock 219 219 299 minecraft:light[level=12]
setblock 219 219 306 minecraft:light[level=12]
setblock 219 219 313 minecraft:light[level=12]
setblock 226 219 285 minecraft:light[level=12]
setblock 226 219 292 minecraft:light[level=12]
setblock 226 219 299 minecraft:light[level=12]
setblock 226 219 306 minecraft:light[level=12]
fill 196 220 275 196 222 275 minecraft:prismarine_bricks
setblock 197 220 275 minecraft:sea_lantern
fill 197 221 275 197 226 275 minecraft:prismarine_bricks
fill 188 222 306 188 226 306 minecraft:prismarine_bricks
setblock 188 222 307 minecraft:sea_lantern
fill 206 222 296 206 223 300 minecraft:gold_block
fill 207 222 294 207 223 295 minecraft:gold_block
fill 207 222 296 207 223 297 minecraft:prismarine
fill 207 222 298 207 223 298 minecraft:dark_prismarine
fill 207 222 299 207 223 300 minecraft:prismarine
fill 207 222 301 207 223 302 minecraft:gold_block
fill 208 222 293 208 223 293 minecraft:gold_block
fill 208 222 294 208 223 294 minecraft:dark_prismarine
fill 208 222 295 208 223 296 minecraft:prismarine
fill 208 222 297 208 223 297 minecraft:dark_prismarine
fill 208 222 298 208 223 299 minecraft:prismarine
fill 208 222 300 208 223 300 minecraft:dark_prismarine
fill 208 222 301 208 223 302 minecraft:prismarine
fill 208 222 303 208 223 303 minecraft:gold_block
fill 209 222 292 209 223 292 minecraft:gold_block
fill 209 222 293 209 223 293 minecraft:dark_prismarine
fill 209 222 294 209 223 295 minecraft:prismarine
fill 209 222 296 209 223 296 minecraft:dark_prismarine
fill 209 222 297 209 223 298 minecraft:prismarine
fill 209 222 299 209 223 299 minecraft:dark_prismarine
fill 209 222 300 209 223 301 minecraft:prismarine
fill 209 222 302 209 223 302 minecraft:dark_prismarine
fill 209 222 303 210 223 303 minecraft:prismarine
fill 209 222 304 209 223 304 minecraft:gold_block
fill 210 222 291 211 223 291 minecraft:gold_block
fill 210 222 292 210 223 292 minecraft:dark_prismarine
fill 210 222 293 210 223 294 minecraft:prismarine
fill 210 222 295 210 223 295 minecraft:dark_prismarine
fill 210 222 296 210 222 297 minecraft:prismarine
setblock 210 222 298 minecraft:dark_prismarine
fill 210 222 299 210 222 300 minecraft:prismarine
fill 210 222 301 210 223 301 minecraft:dark_prismarine
fill 210 222 302 211 223 302 minecraft:prismarine
fill 210 222 304 210 223 304 minecraft:dark_prismarine
fill 210 222 305 211 223 305 minecraft:gold_block
fill 211 222 292 211 223 293 minecraft:prismarine
fill 211 222 294 211 223 294 minecraft:dark_prismarine
fill 211 222 295 211 222 296 minecraft:prismarine
setblock 211 222 297 minecraft:dark_prismarine
setblock 211 222 299 minecraft:prismarine
setblock 211 222 300 minecraft:dark_prismarine
fill 211 222 301 212 222 301 minecraft:prismarine
fill 211 222 303 211 223 303 minecraft:dark_prismarine
fill 211 222 304 212 223 304 minecraft:prismarine
fill 212 222 290 216 223 290 minecraft:gold_block
fill 212 222 291 212 223 292 minecraft:prismarine
fill 212 222 293 212 223 293 minecraft:dark_prismarine
fill 212 222 294 212 222 295 minecraft:prismarine
fill 212 222 302 212 223 302 minecraft:dark_prismarine
fill 212 222 303 213 223 303 minecraft:prismarine
fill 212 222 305 212 223 305 minecraft:dark_prismarine
fill 212 222 306 216 223 306 minecraft:gold_block
fill 213 222 291 213 223 291 minecraft:prismarine
fill 213 222 292 213 223 292 minecraft:dark_prismarine
fill 213 222 293 213 222 294 minecraft:prismarine
setblock 213 222 295 minecraft:dark_prismarine
setblock 213 222 301 minecraft:dark_prismarine
fill 213 222 302 214 222 302 minecraft:prismarine
fill 213 222 304 213 223 304 minecraft:dark_prismarine
fill 213 222 305 214 223 305 minecraft:prismarine
fill 214 222 291 214 223 291 minecraft:dark_prismarine
fill 214 222 292 214 223 293 minecraft:prismarine
setblock 214 222 294 minecraft:dark_prismarine
fill 214 222 303 214 223 303 minecraft:dark_prismarine
fill 214 222 304 215 223 304 minecraft:prismarine
fill 215 222 291 215 223 292 minecraft:prismarine
fill 215 222 293 215 223 293 minecraft:dark_prismarine
fill 215 222 294 215 222 295 minecraft:prismarine
setblock 215 222 301 minecraft:prismarine
setblock 215 222 302 minecraft:dark_prismarine
fill 215 222 303 216 223 303 minecraft:prismarine
fill 215 222 305 215 223 305 minecraft:dark_prismarine
fill 216 222 291 216 223 291 minecraft:prismarine
fill 216 222 292 216 223 292 minecraft:dark_prismarine
fill 216 222 293 216 223 294 minecraft:prismarine
setblock 216 222 295 minecraft:dark_prismarine
setblock 216 222 301 minecraft:dark_prismarine
fill 216 222 302 217 223 302 minecraft:prismarine
fill 216 222 304 216 223 304 minecraft:dark_prismarine
fill 216 222 305 216 223 305 minecraft:prismarine
fill 217 222 291 218 223 291 minecraft:gold_block
fill 217 222 292 217 223 293 minecraft:prismarine
fill 217 222 294 217 223 294 minecraft:dark_prismarine
fill 217 222 295 217 222 296 minecraft:prismarine
setblock 217 222 297 minecraft:dark_prismarine
setblock 217 222 299 minecraft:prismarine
setblock 217 222 300 minecraft:dark_prismarine
fill 217 222 301 218 222 301 minecraft:prismarine
fill 217 222 303 217 223 303 minecraft:dark_prismarine
fill 217 222 304 218 223 304 minecraft:prismarine
fill 217 222 305 218 223 305 minecraft:gold_block
fill 218 222 292 218 223 292 minecraft:prismarine
fill 218 222 293 218 223 293 minecraft:dark_prismarine
fill 218 222 294 218 223 295 minecraft:prismarine
fill 218 222 296 218 223 296 minecraft:dark_prismarine
fill 218 222 297 218 222 298 minecraft:prismarine
setblock 218 222 299 minecraft:dark_prismarine
fill 218 222 300 219 223 300 minecraft:prismarine
fill 218 222 302 218 223 302 minecraft:dark_prismarine
fill 218 222 303 219 223 303 minecraft:prismarine
fill 219 222 292 219 223 292 minecraft:gold_block
fill 219 222 293 219 223 294 minecraft:prismarine
fill 219 222 295 219 223 295 minecraft:dark_prismarine
fill 219 222 296 219 223 297 minecraft:prismarine
fill 219 222 298 219 223 298 minecraft:dark_prismarine
fill 219 222 299 220 223 299 minecraft:prismarine
fill 219 222 301 219 223 301 minecraft:dark_prismarine
fill 219 222 302 220 223 302 minecraft:prismarine
fill 219 222 304 219 223 304 minecraft:gold_block
fill 220 222 293 220 223 293 minecraft:gold_block
fill 220 222 294 220 223 294 minecraft:dark_prismarine
fill 220 222 295 220 223 296 minecraft:prismarine
fill 220 222 297 220 223 297 minecraft:dark_prismarine
fill 220 222 298 221 223 298 minecraft:prismarine
fill 220 222 300 220 223 300 minecraft:dark_prismarine
fill 220 222 301 220 223 301 minecraft:prismarine
fill 220 222 303 220 223 303 minecraft:gold_block
fill 221 222 294 221 223 295 minecraft:gold_block
fill 221 222 296 221 223 296 minecraft:dark_prismarine
fill 221 222 297 221 223 297 minecraft:prismarine
fill 221 222 299 221 223 299 minecraft:dark_prismarine
fill 221 222 300 221 223 300 minecraft:prismarine
fill 221 222 301 221 223 302 minecraft:gold_block
fill 222 222 296 222 223 300 minecraft:gold_block
fill 188 223 286 189 223 286 minecraft:prismarine
fill 188 223 287 188 226 287 minecraft:prismarine_bricks
fill 188 223 289 188 223 291 minecraft:prismarine
fill 188 223 302 189 223 302 minecraft:prismarine
fill 188 223 307 188 226 307 minecraft:prismarine_bricks
setblock 188 223 308 minecraft:prismarine
setblock 188 223 317 minecraft:prismarine
fill 189 223 276 189 223 277 minecraft:dark_prismarine
setblock 189 223 278 minecraft:prismarine
fill 189 223 279 189 223 281 minecraft:dark_prismarine
setblock 189 223 282 minecraft:prismarine
fill 189 223 283 189 223 285 minecraft:dark_prismarine
fill 189 223 287 189 223 289 minecraft:dark_prismarine
setblock 189 223 290 minecraft:prismarine
fill 189 223 291 189 223 293 minecraft:dark_prismarine
setblock 189 223 294 minecraft:prismarine
fill 189 223 295 189 223 297 minecraft:dark_prismarine
setblock 189 223 298 minecraft:prismarine
fill 189 223 299 189 223 301 minecraft:dark_prismarine
fill 189 223 303 189 223 305 minecraft:dark_prismarine
setblock 189 223 306 minecraft:prismarine
fill 189 223 307 189 223 309 minecraft:dark_prismarine
setblock 189 223 310 minecraft:prismarine
fill 189 223 311 189 223 313 minecraft:dark_prismarine
setblock 189 223 314 minecraft:prismarine
fill 189 223 315 190 223 316 minecraft:dark_prismarine
setblock 190 223 276 minecraft:dark_prismarine
setblock 190 223 277 minecraft:prismarine
fill 190 223 278 190 223 280 minecraft:dark_prismarine
setblock 190 223 281 minecraft:prismarine
fill 190 223 282 190 223 284 minecraft:dark_prismarine
setblock 190 223 285 minecraft:prismarine
fill 190 223 286 190 223 288 minecraft:dark_prismarine
setblock 190 223 289 minecraft:prismarine
fill 190 223 290 190 223 292 minecraft:dark_prismarine
setblock 190 223 293 minecraft:prismarine
fill 190 223 294 192 223 294 minecraft:dark_prismarine
fill 190 223 298 190 223 300 minecraft:dark_prismarine
setblock 190 223 301 minecraft:prismarine
fill 190 223 302 190 223 304 minecraft:dark_prismarine
setblock 190 223 305 minecraft:prismarine
fill 190 223 306 190 223 308 minecraft:dark_prismarine
setblock 190 223 309 minecraft:prismarine
fill 190 223 310 190 223 312 minecraft:dark_prismarine
setblock 190 223 313 minecraft:prismarine
setblock 190 223 314 minecraft:dark_prismarine
setblock 191 223 276 minecraft:prismarine
fill 191 223 277 193 223 277 minecraft:dark_prismarine
fill 191 223 281 191 223 283 minecraft:dark_prismarine
setblock 191 223 284 minecraft:prismarine
fill 191 223 285 191 223 287 minecraft:dark_prismarine
setblock 191 223 288 minecraft:prismarine
fill 191 223 289 191 223 291 minecraft:dark_prismarine
setblock 191 223 292 minecraft:prismarine
fill 191 223 293 193 223 293 minecraft:dark_prismarine
fill 191 223 298 191 223 299 minecraft:dark_prismarine
setblock 191 223 300 minecraft:prismarine
fill 191 223 301 191 223 303 minecraft:dark_prismarine
setblock 191 223 304 minecraft:prismarine
fill 191 223 305 191 223 307 minecraft:dark_prismarine
setblock 191 223 308 minecraft:prismarine
fill 191 223 309 191 223 311 minecraft:dark_prismarine
setblock 191 223 315 minecraft:dark_prismarine
setblock 191 223 316 minecraft:prismarine
fill 192 223 276 194 223 276 minecraft:dark_prismarine
fill 192 223 281 192 223 282 minecraft:dark_prismarine
setblock 192 223 283 minecraft:prismarine
fill 192 223 284 192 223 286 minecraft:dark_prismarine
setblock 192 223 287 minecraft:prismarine
fill 192 223 288 192 223 290 minecraft:dark_prismarine
setblock 192 223 291 minecraft:prismarine
fill 192 223 292 194 223 292 minecraft:dark_prismarine
setblock 192 223 298 minecraft:dark_prismarine
setblock 192 223 299 minecraft:prismarine
fill 192 223 300 192 223 302 minecraft:dark_prismarine
setblock 192 223 303 minecraft:prismarine
fill 192 223 304 192 223 306 minecraft:dark_prismarine
setblock 192 223 307 minecraft:prismarine
fill 192 223 308 192 223 310 minecraft:dark_prismarine
setblock 192 223 311 minecraft:prismarine
setblock 192 223 315 minecraft:prismarine
fill 192 223 316 194 223 316 minecraft:dark_prismarine
setblock 193 223 281 minecraft:dark_prismarine
setblock 193 223 282 minecraft:prismarine
fill 193 223 283 193 223 285 minecraft:dark_prismarine
setblock 193 223 286 minecraft:prismarine
fill 193 223 287 193 223 289 minecraft:dark_prismarine
setblock 193 223 290 minecraft:prismarine
fill 193 223 291 195 223 291 minecraft:dark_prismarine
setblock 193 223 294 minecraft:prismarine
fill 193 223 295 193 223 297 minecraft:dark_prismarine
setblock 193 223 298 minecraft:prismarine
fill 193 223 299 193 223 301 minecraft:dark_prismarine
setblock 193 223 302 minecraft:prismarine
fill 193 223 303 193 223 305 minecraft:dark_prismarine
setblock 193 223 306 minecraft:prismarine
fill 193 223 307 193 223 309 minecraft:dark_prismarine
setblock 193 223 310 minecraft:prismarine
fill 193 223 311 195 223 311 minecraft:dark_prismarine
fill 193 223 315 195 223 315 minecraft:dark_prismarine
setblock 194 223 277 minecraft:prismarine
fill 194 223 278 194 223 280 minecraft:dark_prismarine
setblock 194 223 281 minecraft:prismarine
fill 194 223 282 194 223 284 minecraft:dark_prismarine
setblock 194 223 285 minecraft:prismarine
fill 194 223 286 194 223 288 minecraft:dark_prismarine
setblock 194 223 289 minecraft:prismarine
fill 194 223 290 196 223 290 minecraft:dark_prismarine
setblock 194 223 293 minecraft:prismarine
fill 194 223 294 194 223 296 minecraft:dark_prismarine
setblock 194 223 297 minecraft:prismarine
fill 194 223 298 194 223 300 minecraft:dark_prismarine
setblock 194 223 301 minecraft:prismarine
fill 194 223 302 194 223 304 minecraft:dark_prismarine
setblock 194 223 305 minecraft:prismarine
fill 194 223 306 194 223 308 minecraft:dark_prismarine
setblock 194 223 309 minecraft:prismarine
fill 194 223 310 196 223 310 minecraft:dark_prismarine
setblock 194 223 312 minecraft:dark_prismarine
setblock 194 223 313 minecraft:prismarine
fill 194 223 314 196 223 314 minecraft:dark_prismarine
setblock 195 223 276 minecraft:prismarine
fill 195 223 277 195 223 279 minecraft:dark_prismarine
setblock 195 223 280 minecraft:prismarine
fill 195 223 281 195 223 283 minecraft:dark_prismarine
setblock 195 223 284 minecraft:prismarine
fill 195 223 285 195 223 287 minecraft:dark_prismarine
setblock 195 223 288 minecraft:prismarine
fill 195 223 289 197 223 289 minecraft:dark_prismarine
setblock 195 223 292 minecraft:prismarine
fill 195 223 293 195 223 295 minecraft:dark_prismarine
setblock 195 223 296 minecraft:prismarine
fill 195 223 297 195 223 299 minecraft:dark_prismarine
setblock 195 223 300 minecraft:prismarine
fill 195 223 301 195 223 303 minecraft:dark_prismarine
setblock 195 223 304 minecraft:prismarine
fill 195 223 305 195 223 307 minecraft:dark_prismarine
setblock 195 223 308 minecraft:prismarine
fill 195 223 309 197 223 309 minecraft:dark_prismarine
setblock 195 223 312 minecraft:prismarine
fill 195 223 313 197 223 313 minecraft:dark_prismarine
setblock 195 223 316 minecraft:prismarine
setblock 196 223 275 minecraft:prismarine
fill 196 223 276 196 223 278 minecraft:dark_prismarine
setblock 196 223 279 minecraft:prismarine
fill 196 223 280 196 223 282 minecraft:dark_prismarine
setblock 196 223 283 minecraft:prismarine
fill 196 223 284 196 223 286 minecraft:dark_prismarine
setblock 196 223 287 minecraft:prismarine
fill 196 223 288 198 223 288 minecraft:dark_prismarine
setblock 196 223 291 minecraft:prismarine
fill 196 223 292 196 223 294 minecraft:dark_prismarine
setblock 196 223 295 minecraft:prismarine
fill 196 223 296 196 223 298 minecraft:dark_prismarine
setblock 196 223 299 minecraft:prismarine
fill 196 223 300 196 223 302 minecraft:dark_prismarine
setblock 196 223 303 minecraft:prismarine
fill 196 223 304 196 223 306 minecraft:dark_prismarine
setblock 196 223 307 minecraft:prismarine
fill 196 223 308 198 223 308 minecraft:dark_prismarine
setblock 196 223 311 minecraft:prismarine
fill 196 223 312 198 223 312 minecraft:dark_prismarine
setblock 196 223 315 minecraft:prismarine
fill 196 223 316 198 223 316 minecraft:dark_prismarine
fill 197 223 276 197 223 277 minecraft:dark_prismarine
setblock 197 223 278 minecraft:prismarine
fill 197 223 279 197 223 281 minecraft:dark_prismarine
setblock 197 223 282 minecraft:prismarine
fill 197 223 283 197 223 285 minecraft:dark_prismarine
setblock 197 223 286 minecraft:prismarine
fill 197 223 287 199 223 287 minecraft:dark_prismarine
setblock 197 223 290 minecraft:prismarine
fill 197 223 291 197 223 293 minecraft:dark_prismarine
setblock 197 223 294 minecraft:prismarine
fill 197 223 295 197 223 297 minecraft:dark_prismarine
setblock 197 223 298 minecraft:prismarine
fill 197 223 299 197 223 301 minecraft:dark_prismarine
setblock 197 223 302 minecraft:prismarine
fill 197 223 303 197 223 305 minecraft:dark_prismarine
setblock 197 223 306 minecraft:prismarine
fill 197 223 307 199 223 307 minecraft:dark_prismarine
setblock 197 223 310 minecraft:prismarine
fill 197 223 311 199 223 311 minecraft:dark_prismarine
setblock 197 223 314 minecraft:prismarine
fill 197 223 315 199 223 315 minecraft:dark_prismarine
setblock 198 223 276 minecraft:dark_prismarine
setblock 198 223 277 minecraft:prismarine
fill 198 223 278 198 223 280 minecraft:dark_prismarine
setblock 198 223 281 minecraft:prismarine
fill 198 223 282 198 223 284 minecraft:dark_prismarine
setblock 198 223 285 minecraft:prismarine
fill 198 223 286 200 223 286 minecraft:dark_prismarine
setblock 198 223 289 minecraft:prismarine
fill 198 223 290 198 223 292 minecraft:dark_prismarine
setblock 198 223 293 minecraft:prismarine
fill 198 223 294 198 223 296 minecraft:dark_prismarine
setblock 198 223 297 minecraft:prismarine
fill 198 223 298 198 223 300 minecraft:dark_prismarine
setblock 198 223 301 minecraft:prismarine
fill 198 223 302 198 223 304 minecraft:dark_prismarine
setblock 198 223 305 minecraft:prismarine
fill 198 223 306 200 223 306 minecraft:dark_prismarine
setblock 198 223 309 minecraft:prismarine
fill 198 223 310 200 223 310 minecraft:dark_prismarine
setblock 198 223 313 minecraft:prismarine
fill 198 223 314 200 223 314 minecraft:dark_prismarine
setblock 199 223 276 minecraft:prismarine
fill 199 223 277 199 223 279 minecraft:dark_prismarine
setblock 199 223 280 minecraft:prismarine
fill 199 223 281 199 223 283 minecraft:dark_prismarine
setblock 199 223 284 minecraft:prismarine
fill 199 223 285 201 223 285 minecraft:dark_prismarine
setblock 199 223 288 minecraft:prismarine
fill 199 223 289 199 223 291 minecraft:dark_prismarine
setblock 199 223 292 minecraft:prismarine
fill 199 223 293 199 223 295 minecraft:dark_prismarine
setblock 199 223 296 minecraft:prismarine
fill 199 223 297 199 223 299 minecraft:dark_prismarine
setblock 199 223 300 minecraft:prismarine
fill 199 223 301 199 223 303 minecraft:dark_prismarine
setblock 199 223 304 minecraft:prismarine
fill 199 223 305 201 223 305 minecraft:dark_prismarine
setblock 199 223 308 minecraft:prismarine
fill 199 223 309 201 223 309 minecraft:dark_prismarine
setblock 199 223 312 minecraft:prismarine
fill 199 223 313 201 223 313 minecraft:dark_prismarine
setblock 199 223 316 minecraft:prismarine
fill 200 223 276 200 223 278 minecraft:dark_prismarine
setblock 200 223 279 minecraft:prismarine
fill 200 223 280 200 223 282 minecraft:dark_prismarine
setblock 200 223 283 minecraft:prismarine
fill 200 223 284 202 223 284 minecraft:dark_prismarine
setblock 200 223 287 minecraft:prismarine
fill 200 223 288 200 223 290 minecraft:dark_prismarine
setblock 200 223 291 minecraft:prismarine
fill 200 223 292 200 223 294 minecraft:dark_prismarine
setblock 200 223 295 minecraft:prismarine
fill 200 223 296 200 223 298 minecraft:dark_prismarine
setblock 200 223 299 minecraft:prismarine
fill 200 223 300 200 223 302 minecraft:dark_prismarine
setblock 200 223 303 minecraft:prismarine
fill 200 223 304 202 223 304 minecraft:dark_prismarine
setblock 200 223 307 minecraft:prismarine
fill 200 223 308 202 223 308 minecraft:dark_prismarine
setblock 200 223 311 minecraft:prismarine
fill 200 223 312 202 223 312 minecraft:dark_prismarine
setblock 200 223 315 minecraft:prismarine
fill 200 223 316 202 223 316 minecraft:dark_prismarine
fill 201 223 276 201 223 277 minecraft:dark_prismarine
setblock 201 223 278 minecraft:prismarine
fill 201 223 279 201 223 281 minecraft:dark_prismarine
setblock 201 223 282 minecraft:prismarine
fill 201 223 283 203 223 283 minecraft:dark_prismarine
setblock 201 223 286 minecraft:prismarine
fill 201 223 287 201 223 289 minecraft:dark_prismarine
setblock 201 223 290 minecraft:prismarine
fill 201 223 291 201 223 293 minecraft:dark_prismarine
setblock 201 223 294 minecraft:prismarine
fill 201 223 295 201 223 297 minecraft:dark_prismarine
setblock 201 223 298 minecraft:prismarine
fill 201 223 299 201 223 301 minecraft:dark_prismarine
setblock 201 223 302 minecraft:prismarine
fill 201 223 303 203 223 303 minecraft:dark_prismarine
setblock 201 223 306 minecraft:prismarine
fill 201 223 307 203 223 307 minecraft:dark_prismarine
setblock 201 223 310 minecraft:prismarine
fill 201 223 311 203 223 311 minecraft:dark_prismarine
setblock 201 223 314 minecraft:prismarine
fill 201 223 315 203 223 315 minecraft:dark_prismarine
setblock 202 223 276 minecraft:dark_prismarine
setblock 202 223 277 minecraft:prismarine
fill 202 223 278 202 223 280 minecraft:dark_prismarine
setblock 202 223 281 minecraft:prismarine
fill 202 223 282 204 223 282 minecraft:dark_prismarine
setblock 202 223 285 minecraft:prismarine
fill 202 223 286 202 223 288 minecraft:dark_prismarine
setblock 202 223 289 minecraft:prismarine
fill 202 223 290 202 223 292 minecraft:dark_prismarine
setblock 202 223 293 minecraft:prismarine
fill 202 223 294 202 223 296 minecraft:dark_prismarine
setblock 202 223 297 minecraft:prismarine
fill 202 223 298 202 223 300 minecraft:dark_prismarine
setblock 202 223 301 minecraft:prismarine
fill 202 223 302 204 223 302 minecraft:dark_prismarine
setblock 202 223 305 minecraft:prismarine
fill 202 223 306 204 223 306 minecraft:dark_prismarine
setblock 202 223 309 minecraft:prismarine
fill 202 223 310 204 223 310 minecraft:dark_prismarine
setblock 202 223 313 minecraft:prismarine
fill 202 223 314 204 223 314 minecraft:dark_prismarine
setblock 203 223 276 minecraft:prismarine
fill 203 223 277 203 223 279 minecraft:dark_prismarine
setblock 203 223 280 minecraft:prismarine
fill 203 223 281 205 223 281 minecraft:dark_prismarine
setblock 203 223 284 minecraft:prismarine
fill 203 223 285 203 223 287 minecraft:dark_prismarine
setblock 203 223 288 minecraft:prismarine
fill 203 223 289 203 223 291 minecraft:dark_prismarine
setblock 203 223 292 minecraft:prismarine
fill 203 223 293 203 223 295 minecraft:dark_prismarine
setblock 203 223 296 minecraft:prismarine
fill 203 223 297 203 223 299 minecraft:dark_prismarine
setblock 203 223 300 minecraft:prismarine
fill 203 223 301 205 223 301 minecraft:dark_prismarine
setblock 203 223 304 minecraft:prismarine
fill 203 223 305 205 223 305 minecraft:dark_prismarine
setblock 203 223 308 minecraft:prismarine
fill 203 223 309 205 223 309 minecraft:dark_prismarine
setblock 203 223 312 minecraft:prismarine
fill 203 223 313 205 223 313 minecraft:dark_prismarine
setblock 203 223 316 minecraft:prismarine
fill 204 223 276 204 223 278 minecraft:dark_prismarine
setblock 204 223 279 minecraft:prismarine
fill 204 223 280 206 223 280 minecraft:dark_prismarine
setblock 204 223 283 minecraft:prismarine
fill 204 223 284 204 223 286 minecraft:dark_prismarine
setblock 204 223 287 minecraft:prismarine
fill 204 223 288 204 223 290 minecraft:dark_prismarine
setblock 204 223 291 minecraft:prismarine
fill 204 223 292 204 223 294 minecraft:dark_prismarine
setblock 204 223 295 minecraft:prismarine
fill 204 223 296 204 223 298 minecraft:dark_prismarine
setblock 204 223 299 minecraft:prismarine
fill 204 223 300 205 223 300 minecraft:dark_prismarine
setblock 204 223 303 minecraft:prismarine
fill 204 223 304 206 223 304 minecraft:dark_prismarine
setblock 204 223 307 minecraft:prismarine
fill 204 223 308 206 223 308 minecraft:dark_prismarine
setblock 204 223 311 minecraft:prismarine
fill 204 223 312 206 223 312 minecraft:dark_prismarine
setblock 204 223 315 minecraft:prismarine
fill 204 223 316 206 223 316 minecraft:dark_prismarine
fill 205 223 276 205 223 277 minecraft:dark_prismarine
setblock 205 223 278 minecraft:prismarine
fill 205 223 279 207 223 279 minecraft:dark_prismarine
setblock 205 223 282 minecraft:prismarine
fill 205 223 283 205 223 285 minecraft:dark_prismarine
setblock 205 223 286 minecraft:prismarine
fill 205 223 287 205 223 289 minecraft:dark_prismarine
setblock 205 223 290 minecraft:prismarine
fill 205 223 291 205 223 293 minecraft:dark_prismarine
setblock 205 223 294 minecraft:prismarine
fill 205 223 295 205 223 297 minecraft:dark_prismarine
setblock 205 223 298 minecraft:prismarine
setblock 205 223 299 minecraft:dark_prismarine
setblock 205 223 302 minecraft:prismarine
fill 205 223 303 206 223 303 minecraft:dark_prismarine
setblock 205 223 306 minecraft:prismarine
fill 205 223 307 207 223 307 minecraft:dark_prismarine
setblock 205 223 310 minecraft:prismarine
fill 205 223 311 207 223 311 minecraft:dark_prismarine
setblock 205 223 314 minecraft:prismarine
fill 205 223 315 207 223 315 minecraft:dark_prismarine
setblock 206 223 276 minecraft:dark_prismarine
setblock 206 223 277 minecraft:prismarine
fill 206 223 278 207 223 278 minecraft:dark_prismarine
setblock 206 223 281 minecraft:prismarine
fill 206 223 282 206 223 284 minecraft:dark_prismarine
setblock 206 223 285 minecraft:prismarine
fill 206 223 286 206 223 288 minecraft:dark_prismarine
setblock 206 223 289 minecraft:prismarine
fill 206 223 290 206 223 292 minecraft:dark_prismarine
setblock 206 223 293 minecraft:prismarine
setblock 206 223 294 minecraft:dark_prismarine
setblock 206 223 295 minecraft:gold_block
setblock 206 223 301 minecraft:gold_block
setblock 206 223 302 minecraft:dark_prismarine
setblock 206 223 305 minecraft:prismarine
fill 206 223 306 208 223 306 minecraft:dark_prismarine
setblock 206 223 309 minecraft:prismarine
fill 206 223 310 208 223 310 minecraft:dark_prismarine
setblock 206 223 313 minecraft:prismarine
fill 206 223 314 207 223 314 minecraft:dark_prismarine
fill 206 223 317 207 223 317 minecraft:prismarine
fill 207 223 275 207 223 276 minecraft:prismarine
setblock 207 223 277 minecraft:dark_prismarine
setblock 207 223 280 minecraft:prismarine
fill 207 223 281 207 223 283 minecraft:dark_prismarine
setblock 207 223 284 minecraft:prismarine
fill 207 223 285 207 223 287 minecraft:dark_prismarine
setblock 207 223 288 minecraft:prismarine
fill 207 223 289 207 223 291 minecraft:dark_prismarine
setblock 207 223 292 minecraft:prismarine
setblock 207 223 293 minecraft:gold_block
setblock 207 223 303 minecraft:gold_block
setblock 207 223 304 minecraft:prismarine
fill 207 223 305 208 223 305 minecraft:dark_prismarine
setblock 207 223 308 minecraft:prismarine
fill 207 223 309 209 223 309 minecraft:dark_prismarine
setblock 207 223 312 minecraft:prismarine
setblock 207 223 313 minecraft:dark_prismarine
setblock 207 223 316 minecraft:prismarine
fill 208 223 276 210 223 276 minecraft:dark_prismarine
fill 208 223 280 208 223 282 minecraft:dark_prismarine
setblock 208 223 283 minecraft:prismarine
fill 208 223 284 208 223 286 minecraft:dark_prismarine
setblock 208 223 287 minecraft:prismarine
fill 208 223 288 208 223 290 minecraft:dark_prismarine
setblock 208 223 291 minecraft:prismarine
setblock 208 223 292 minecraft:gold_block
setblock 208 223 304 minecraft:gold_block
setblock 208 223 307 minecraft:prismarine
fill 208 223 308 210 223 308 minecraft:dark_prismarine
setblock 208 223 311 minecraft:prismarine
fill 208 223 312 210 223 312 minecraft:dark_prismarine
fill 208 223 316 210 223 316 minecraft:dark_prismarine
fill 209 223 280 209 223 281 minecraft:dark_prismarine
setblock 209 223 282 minecraft:prismarine
fill 209 223 283 209 223 285 minecraft:dark_prismarine
setblock 209 223 286 minecraft:prismarine
fill 209 223 287 209 223 289 minecraft:dark_prismarine
setblock 209 223 290 minecraft:prismarine
setblock 209 223 291 minecraft:gold_block
setblock 209 223 305 minecraft:gold_block
setblock 209 223 306 minecraft:prismarine
fill 209 223 307 211 223 307 minecraft:dark_prismarine
setblock 209 223 310 minecraft:prismarine
fill 209 223 311 211 223 311 minecraft:dark_prismarine
setblock 210 223 280 minecraft:dark_prismarine
setblock 210 223 281 minecraft:prismarine
fill 210 223 282 210 223 284 minecraft:dark_prismarine
setblock 210 223 285 minecraft:prismarine
fill 210 223 286 210 223 288 minecraft:dark_prismarine
setblock 210 223 289 minecraft:prismarine
setblock 210 223 290 minecraft:dark_prismarine
setblock 210 223 296 minecraft:prismarine
fill 210 223 297 210 223 299 minecraft:sea_lantern
setblock 210 223 300 minecraft:prismarine
setblock 210 223 306 minecraft:dark_prismarine
setblock 210 223 309 minecraft:prismarine
fill 210 223 310 212 223 310 minecraft:dark_prismarine
fill 211 223 275 211 223 276 minecraft:prismarine
fill 211 223 277 211 223 279 minecraft:dark_prismarine
setblock 211 223 280 minecraft:prismarine
fill 211 223 281 211 223 283 minecraft:dark_prismarine
setblock 211 223 284 minecraft:prismarine
fill 211 223 285 211 223 287 minecraft:dark_prismarine
setblock 211 223 288 minecraft:prismarine
fill 211 223 289 213 223 289 minecraft:dark_prismarine
setblock 211 223 290 minecraft:gold_block
fill 211 223 295 211 223 297 minecraft:sea_lantern
fill 211 223 299 211 223 301 minecraft:sea_lantern
setblock 211 223 306 minecraft:gold_block
setblock 211 223 308 minecraft:prismarine
fill 211 223 309 213 223 309 minecraft:dark_prismarine
setblock 211 223 312 minecraft:prismarine
fill 211 223 313 211 223 315 minecraft:dark_prismarine
setblock 211 223 316 minecraft:prismarine
fill 212 223 276 212 223 278 minecraft:dark_prismarine
setblock 212 223 279 minecraft:prismarine
fill 212 223 280 212 223 282 minecraft:dark_prismarine
setblock 212 223 283 minecraft:prismarine
fill 212 223 284 212 223 286 minecraft:dark_prismarine
setblock 212 223 287 minecraft:prismarine
fill 212 223 288 214 223 288 minecraft:dark_prismarine
setblock 212 223 294 minecraft:prismarine
fill 212 223 295 213 223 295 minecraft:sea_lantern
fill 212 223 301 213 223 301 minecraft:sea_lantern
setblock 212 223 307 minecraft:prismarine
fill 212 223 308 213 223 308 minecraft:dark_prismarine
setblock 212 223 311 minecraft:prismarine
fill 212 223 312 212 223 314 minecraft:dark_prismarine
setblock 212 223 315 minecraft:prismarine
fill 212 223 316 214 223 316 minecraft:dark_prismarine
fill 213 223 276 213 223 277 minecraft:dark_prismarine
setblock 213 223 278 minecraft:prismarine
fill 213 223 279 213 223 281 minecraft:dark_prismarine
setblock 213 223 282 minecraft:prismarine
fill 213 223 283 213 223 285 minecraft:dark_prismarine
setblock 213 223 286 minecraft:prismarine
fill 213 223 287 215 223 287 minecraft:dark_prismarine
setblock 213 223 293 minecraft:prismarine
fill 213 223 294 215 223 294 minecraft:sea_lantern
fill 213 223 302 215 223 302 minecraft:sea_lantern
setblock 213 223 307 minecraft:dark_prismarine
setblock 213 223 310 minecraft:prismarine
fill 213 223 311 213 223 313 minecraft:dark_prismarine
setblock 213 223 314 minecraft:prismarine
fill 213 223 315 215 223 315 minecraft:dark_prismarine
fill 213 223 317 214 223 317 minecraft:prismarine
setblock 214 223 276 minecraft:dark_prismarine
setblock 214 223 277 minecraft:prismarine
fill 214 223 278 214 223 280 minecraft:dark_prismarine
setblock 214 223 281 minecraft:prismarine
fill 214 223 282 214 223 284 minecraft:dark_prismarine
setblock 214 223 285 minecraft:prismarine
fill 214 223 286 216 223 286 minecraft:dark_prismarine
setblock 214 223 289 minecraft:prismarine
fill 214 223 307 214 223 311 minecraft:gold_block
setblock 214 223 312 minecraft:dark_prismarine
setblock 214 223 313 minecraft:prismarine
fill 214 223 314 216 223 314 minecraft:dark_prismarine
setblock 215 223 276 minecraft:prismarine
fill 215 223 277 215 223 279 minecraft:dark_prismarine
setblock 215 223 280 minecraft:prismarine
fill 215 223 281 215 223 283 minecraft:dark_prismarine
setblock 215 223 284 minecraft:prismarine
fill 215 223 285 217 223 285 minecraft:dark_prismarine
setblock 215 223 288 minecraft:prismarine
fill 215 223 289 217 223 289 minecraft:dark_prismarine
fill 215 223 295 217 223 295 minecraft:sea_lantern
fill 215 223 301 217 223 301 minecraft:sea_lantern
setblock 215 223 307 minecraft:dark_prismarine
setblock 215 223 308 minecraft:prismarine
fill 215 223 309 215 223 311 minecraft:dark_prismarine
setblock 215 223 312 minecraft:prismarine
fill 215 223 313 217 223 313 minecraft:dark_prismarine
setblock 215 223 316 minecraft:prismarine
fill 216 223 276 216 223 278 minecraft:dark_prismarine
setblock 216 223 279 minecraft:prismarine
fill 216 223 280 216 223 282 minecraft:dark_prismarine
setblock 216 223 283 minecraft:prismarine
fill 216 223 284 218 223 284 minecraft:dark_prismarine
setblock 216 223 287 minecraft:prismarine
fill 216 223 288 218 223 288 minecraft:dark_prismarine
setblock 216 223 307 minecraft:prismarine
fill 216 223 308 216 223 310 minecraft:dark_prismarine
setblock 216 223 311 minecraft:prismarine
fill 216 223 312 218 223 312 minecraft:dark_prismarine
setblock 216 223 315 minecraft:prismarine
fill 216 223 316 218 223 316 minecraft:dark_prismarine
fill 217 223 276 217 223 277 minecraft:dark_prismarine
setblock 217 223 278 minecraft:prismarine
fill 217 223 279 217 223 281 minecraft:dark_prismarine
setblock 217 223 282 minecraft:prismarine
fill 217 223 283 219 223 283 minecraft:dark_prismarine
setblock 217 223 286 minecraft:prismarine
fill 217 223 287 219 223 287 minecraft:dark_prismarine
setblock 217 223 290 minecraft:gold_block
fill 217 223 296 217 223 297 minecraft:sea_lantern
fill 217 223 299 217 223 300 minecraft:sea_lantern
setblock 217 223 306 minecraft:gold_block
fill 217 223 307 217 223 309 minecraft:dark_prismarine
setblock 217 223 310 minecraft:prismarine
fill 217 223 311 219 223 311 minecraft:dark_prismarine
setblock 217 223 314 minecraft:prismarine
fill 217 223 315 219 223 315 minecraft:dark_prismarine
setblock 218 223 276 minecraft:dark_prismarine
setblock 218 223 277 minecraft:prismarine
fill 218 223 278 218 223 280 minecraft:dark_prismarine
setblock 218 223 281 minecraft:prismarine
fill 218 223 282 220 223 282 minecraft:dark_prismarine
setblock 218 223 285 minecraft:prismarine
fill 218 223 286 220 223 286 minecraft:dark_prismarine
setblock 218 223 289 minecraft:prismarine
fill 218 223 290 220 223 290 minecraft:dark_prismarine
fill 218 223 297 218 223 299 minecraft:sea_lantern
setblock 218 223 301 minecraft:prismarine
fill 218 223 306 218 223 308 minecraft:dark_prismarine
setblock 218 223 309 minecraft:prismarine
fill 218 223 310 220 223 310 minecraft:dark_prismarine
setblock 218 223 313 minecraft:prismarine
fill 218 223 314 220 223 314 minecraft:dark_prismarine
setblock 219 223 276 minecraft:prismarine
fill 219 223 277 219 223 279 minecraft:dark_prismarine
setblock 219 223 280 minecraft:prismarine
fill 219 223 281 221 223 281 minecraft:dark_prismarine
setblock 219 223 284 minecraft:prismarine
fill 219 223 285 221 223 285 minecraft:dark_prismarine
setblock 219 223 288 minecraft:prismarine
fill 219 223 289 221 223 289 minecraft:dark_prismarine
setblock 219 223 291 minecraft:gold_block
setblock 219 223 305 minecraft:gold_block
fill 219 223 306 219 223 307 minecraft:dark_prismarine
setblock 219 223 308 minecraft:prismarine
fill 219 223 309 221 223 309 minecraft:dark_prismarine
setblock 219 223 312 minecraft:prismarine
fill 219 223 313 221 223 313 minecraft:dark_prismarine
setblock 219 223 316 minecraft:prismarine
fill 220 223 276 220 223 278 minecraft:dark_prismarine
setblock 220 223 279 minecraft:prismarine
fill 220 223 280 222 223 280 minecraft:dark_prismarine
setblock 220 223 283 minecraft:prismarine
fill 220 223 284 222 223 284 minecraft:dark_prismarine
setblock 220 223 287 minecraft:prismarine
fill 220 223 288 222 223 288 minecraft:dark_prismarine
setblock 220 223 291 minecraft:prismarine
setblock 220 223 292 minecraft:gold_block
setblock 220 223 304 minecraft:gold_block
fill 220 223 305 220 223 306 minecraft:dark_prismarine
setblock 220 223 307 minecraft:prismarine
fill 220 223 308 222 223 308 minecraft:dark_prismarine
setblock 220 223 311 minecraft:prismarine
fill 220 223 312 222 223 312 minecraft:dark_prismarine
setblock 220 223 315 minecraft:prismarine
fill 220 223 316 222 223 316 minecraft:dark_prismarine
fill 221 223 276 221 223 277 minecraft:dark_prismarine
setblock 221 223 278 minecraft:prismarine
fill 221 223 279 223 223 279 minecraft:dark_prismarine
setblock 221 223 282 minecraft:prismarine
fill 221 223 283 223 223 283 minecraft:dark_prismarine
setblock 221 223 286 minecraft:prismarine
fill 221 223 287 223 223 287 minecraft:dark_prismarine
setblock 221 223 290 minecraft:prismarine
fill 221 223 291 222 223 292 minecraft:dark_prismarine
setblock 221 223 293 minecraft:gold_block
setblock 221 223 303 minecraft:gold_block
fill 221 223 304 221 223 305 minecraft:dark_prismarine
setblock 221 223 306 minecraft:prismarine
fill 221 223 307 223 223 307 minecraft:dark_prismarine
setblock 221 223 310 minecraft:prismarine
fill 221 223 311 223 223 311 minecraft:dark_prismarine
setblock 221 223 314 minecraft:prismarine
fill 221 223 315 223 223 315 minecraft:dark_prismarine
setblock 222 223 276 minecraft:dark_prismarine
setblock 222 223 277 minecraft:prismarine
fill 222 223 278 224 223 278 minecraft:dark_prismarine
setblock 222 223 281 minecraft:prismarine
fill 222 223 282 224 223 282 minecraft:dark_prismarine
setblock 222 223 285 minecraft:prismarine
fill 222 223 286 224 223 286 minecraft:dark_prismarine
setblock 222 223 289 minecraft:prismarine
fill 222 223 290 224 223 290 minecraft:dark_prismarine
setblock 222 223 293 minecraft:prismarine
fill 222 223 294 224 223 294 minecraft:dark_prismarine
setblock 222 223 295 minecraft:gold_block
setblock 222 223 301 minecraft:gold_block
fill 222 223 302 222 223 304 minecraft:dark_prismarine
setblock 222 223 305 minecraft:prismarine
fill 222 223 306 224 223 306 minecraft:dark_prismarine
setblock 222 223 309 minecraft:prismarine
fill 222 223 310 224 223 310 minecraft:dark_prismarine
setblock 222 223 313 minecraft:prismarine
fill 222 223 314 224 223 314 minecraft:dark_prismarine
setblock 223 223 276 minecraft:prismarine
fill 223 223 277 225 223 277 minecraft:dark_prismarine
setblock 223 223 280 minecraft:prismarine
fill 223 223 281 225 223 281 minecraft:dark_prismarine
setblock 223 223 284 minecraft:prismarine
fill 223 223 285 225 223 285 minecraft:dark_prismarine
setblock 223 223 288 minecraft:prismarine
fill 223 223 289 225 223 289 minecraft:dark_prismarine
setblock 223 223 291 minecraft:dark_prismarine
setblock 223 223 292 minecraft:prismarine
fill 223 223 293 225 223 293 minecraft:dark_prismarine
setblock 223 223 295 minecraft:dark_prismarine
setblock 223 223 296 minecraft:prismarine
fill 223 223 297 223 223 299 minecraft:dark_prismarine
setblock 223 223 300 minecraft:prismarine
fill 223 223 301 223 223 303 minecraft:dark_prismarine
setblock 223 223 304 minecraft:prismarine
fill 223 223 305 225 223 305 minecraft:dark_prismarine
setblock 223 223 308 minecraft:prismarine
fill 223 223 309 225 223 309 minecraft:dark_prismarine
setblock 223 223 312 minecraft:prismarine
fill 223 223 313 224 223 313 minecraft:dark_prismarine
setblock 223 223 316 minecraft:prismarine
fill 224 223 276 226 223 276 minecraft:dark_prismarine
setblock 224 223 279 minecraft:prismarine
setblock 224 223 280 minecraft:dark_prismarine
setblock 224 223 283 minecraft:prismarine
fill 224 223 284 226 223 284 minecraft:dark_prismarine
setblock 224 223 287 minecraft:prismarine
fill 224 223 288 226 223 288 minecraft:dark_prismarine
setblock 224 223 291 minecraft:prismarine
fill 224 223 292 226 223 292 minecraft:dark_prismarine
setblock 224 223 295 minecraft:prismarine
fill 224 223 296 224 223 298 minecraft:dark_prismarine
setblock 224 223 299 minecraft:prismarine
fill 224 223 300 224 223 302 minecraft:dark_prismarine
setblock 224 223 303 minecraft:prismarine
fill 224 223 304 226 223 304 minecraft:dark_prismarine
setblock 224 223 307 minecraft:prismarine
fill 224 223 308 226 223 308 minecraft:dark_prismarine
setblock 224 223 311 minecraft:prismarine
setblock 224 223 312 minecraft:dark_prismarine
setblock 224 223 315 minecraft:prismarine
fill 224 223 316 226 223 316 minecraft:dark_prismarine
setblock 225 223 282 minecraft:prismarine
fill 225 223 283 227 223 283 minecraft:dark_prismarine
setblock 225 223 286 minecraft:prismarine
fill 225 223 287 227 223 287 minecraft:dark_prismarine
setblock 225 223 290 minecraft:prismarine
fill 225 223 291 227 223 291 minecraft:dark_prismarine
setblock 225 223 294 minecraft:prismarine
fill 225 223 295 225 223 297 minecraft:dark_prismarine
setblock 225 223 298 minecraft:prismarine
fill 225 223 299 225 223 301 minecraft:dark_prismarine
setblock 225 223 302 minecraft:prismarine
fill 225 223 303 227 223 303 minecraft:dark_prismarine
setblock 225 223 306 minecraft:prismarine
fill 225 223 307 227 223 307 minecraft:dark_prismarine
setblock 225 223 310 minecraft:prismarine
fill 225 223 311 227 223 311 minecraft:dark_prismarine
fill 225 223 315 227 223 315 minecraft:dark_prismarine
setblock 226 223 277 minecraft:prismarine
setblock 226 223 281 minecraft:prismarine
fill 226 223 282 228 223 282 minecraft:dark_prismarine
setblock 226 223 285 minecraft:prismarine
fill 226 223 286 228 223 286 minecraft:dark_prismarine
setblock 226 223 289 minecraft:prismarine
fill 226 223 290 228 223 290 minecraft:dark_prismarine
setblock 226 223 293 minecraft:prismarine
fill 226 223 294 228 223 294 minecraft:dark_prismarine
fill 226 223 298 226 223 300 minecraft:dark_prismarine
setblock 226 223 301 minecraft:prismarine
fill 226 223 302 228 223 302 minecraft:dark_prismarine
setblock 226 223 305 minecraft:prismarine
fill 226 223 306 228 223 306 minecraft:dark_prismarine
setblock 226 223 309 minecraft:prismarine
fill 226 223 310 228 223 310 minecraft:dark_prismarine
setblock 227 223 276 minecraft:prismarine
fill 227 223 277 229 223 277 minecraft:dark_prismarine
fill 227 223 281 229 223 281 minecraft:dark_prismarine
setblock 227 223 284 minecraft:prismarine
fill 227 223 285 229 223 285 minecraft:dark_prismarine
setblock 227 223 288 minecraft:prismarine
fill 227 223 289 229 223 289 minecraft:dark_prismarine
setblock 227 223 292 minecraft:prismarine
fill 227 223 293 229 223 293 minecraft:dark_prismarine
fill 227 223 298 227 223 299 minecraft:dark_prismarine
setblock 227 223 300 minecraft:prismarine
fill 227 223 301 229 223 301 minecraft:dark_prismarine
setblock 227 223 304 minecraft:prismarine
fill 227 223 305 229 223 305 minecraft:dark_prismarine
setblock 227 223 308 minecraft:prismarine
fill 227 223 309 229 223 309 minecraft:dark_prismarine
setblock 227 223 316 minecraft:prismarine
fill 228 223 276 229 223 276 minecraft:dark_prismarine
setblock 228 223 278 minecraft:dark_prismarine
setblock 228 223 279 minecraft:prismarine
fill 228 223 280 229 223 280 minecraft:dark_prismarine
setblock 228 223 283 minecraft:prismarine
fill 228 223 284 229 223 284 minecraft:dark_prismarine
setblock 228 223 287 minecraft:prismarine
fill 228 223 288 229 223 288 minecraft:dark_prismarine
setblock 228 223 291 minecraft:prismarine
fill 228 223 292 229 223 292 minecraft:dark_prismarine
setblock 228 223 298 minecraft:dark_prismarine
setblock 228 223 299 minecraft:prismarine
fill 228 223 300 229 223 300 minecraft:dark_prismarine
setblock 228 223 303 minecraft:prismarine
fill 228 223 304 229 223 304 minecraft:dark_prismarine
setblock 228 223 307 minecraft:prismarine
fill 228 223 308 229 223 308 minecraft:dark_prismarine
setblock 228 223 311 minecraft:prismarine
fill 228 223 312 228 223 314 minecraft:dark_prismarine
setblock 228 223 315 minecraft:prismarine
fill 228 223 316 229 223 316 minecraft:dark_prismarine
setblock 229 223 278 minecraft:prismarine
setblock 229 223 279 minecraft:dark_prismarine
setblock 229 223 282 minecraft:prismarine
setblock 229 223 283 minecraft:dark_prismarine
setblock 229 223 286 minecraft:prismarine
setblock 229 223 287 minecraft:dark_prismarine
setblock 229 223 290 minecraft:prismarine
setblock 229 223 291 minecraft:dark_prismarine
setblock 229 223 294 minecraft:prismarine
fill 229 223 295 229 223 297 minecraft:dark_prismarine
fill 229 223 298 230 223 298 minecraft:prismarine
setblock 229 223 299 minecraft:dark_prismarine
setblock 229 223 302 minecraft:prismarine
setblock 229 223 303 minecraft:dark_prismarine
setblock 229 223 306 minecraft:prismarine
setblock 229 223 307 minecraft:dark_prismarine
setblock 229 223 310 minecraft:prismarine
fill 229 223 311 229 223 313 minecraft:dark_prismarine
setblock 229 223 314 minecraft:prismarine
setblock 229 223 315 minecraft:dark_prismarine
setblock 230 223 280 minecraft:sea_lantern
setblock 230 223 313 minecraft:prismarine
fill 230 223 314 230 226 314 minecraft:prismarine_bricks
fill 188 224 276 188 224 277 minecraft:prismarine
setblock 188 224 282 minecraft:prismarine
setblock 188 224 283 minecraft:prismarine_bricks
fill 188 224 286 188 226 286 minecraft:prismarine_bricks
fill 188 224 289 188 226 291 minecraft:prismarine_bricks
fill 188 224 302 188 227 302 minecraft:prismarine_bricks
fill 188 224 308 188 226 308 minecraft:prismarine_bricks
setblock 188 224 312 minecraft:prismarine
fill 188 224 317 188 226 317 minecraft:prismarine_bricks
setblock 194 224 275 minecraft:prismarine
fill 196 224 275 196 226 275 minecraft:prismarine_bricks
setblock 199 224 275 minecraft:prismarine
setblock 199 224 317 minecraft:prismarine
fill 200 224 275 200 226 275 minecraft:prismarine_bricks
fill 202 224 286 210 225 310 minecraft:prismarine_bricks
fill 206 224 317 207 226 317 minecraft:prismarine_bricks
fill 207 224 275 207 226 275 minecraft:prismarine_bricks
fill 211 224 275 211 226 275 minecraft:prismarine_bricks
fill 211 224 286 211 224 296 minecraft:prismarine_bricks
fill 211 224 300 211 224 310 minecraft:prismarine_bricks
fill 211 224 317 212 224 317 minecraft:prismarine
fill 212 224 286 212 224 295 minecraft:prismarine_bricks
fill 212 224 301 212 224 310 minecraft:prismarine_bricks
fill 213 224 286 226 225 294 minecraft:prismarine_bricks
fill 213 224 302 226 225 310 minecraft:prismarine_bricks
fill 213 224 317 214 226 317 minecraft:prismarine_bricks
setblock 214 224 311 minecraft:gold_block
fill 215 224 317 215 225 317 minecraft:prismarine
fill 216 224 295 226 224 295 minecraft:prismarine_bricks
fill 216 224 301 226 224 301 minecraft:prismarine_bricks
fill 217 224 296 226 224 296 minecraft:prismarine_bricks
fill 217 224 300 226 224 300 minecraft:prismarine_bricks
fill 218 224 297 226 225 299 minecraft:prismarine_bricks
fill 225 224 275 226 226 275 minecraft:prismarine_bricks
setblock 227 224 275 minecraft:prismarine
fill 227 224 295 228 225 297 minecraft:quartz_pillar
fill 230 224 280 230 226 280 minecraft:prismarine_bricks
fill 230 224 285 230 224 286 minecraft:prismarine
setblock 230 224 288 minecraft:sea_lantern
fill 230 224 289 230 226 289 minecraft:prismarine_bricks
setblock 230 224 290 minecraft:prismarine
setblock 230 224 294 minecraft:prismarine
fill 230 224 298 230 226 298 minecraft:prismarine_bricks
setblock 230 224 306 minecraft:prismarine
setblock 230 224 308 minecraft:prismarine
fill 230 224 313 230 226 313 minecraft:prismarine_bricks
setblock 230 224 317 minecraft:prismarine
fill 188 225 276 188 226 277 minecraft:prismarine_bricks
fill 188 225 282 188 226 282 minecraft:prismarine_bricks
setblock 188 225 283 minecraft:prismarine
setblock 188 225 298 minecraft:prismarine
setblock 188 225 305 minecraft:prismarine
fill 188 225 312 188 226 312 minecraft:prismarine_bricks
setblock 188 225 314 minecraft:sea_lantern
fill 188 225 315 188 226 316 minecraft:prismarine_bricks
setblock 189 225 275 minecraft:prismarine
fill 189 225 317 190 225 317 minecraft:prismarine
fill 190 225 275 190 226 275 minecraft:prismarine_bricks
setblock 191 225 275 minecraft:sea_lantern
setblock 191 225 285 minecraft:light[level=12]
setblock 191 225 292 minecraft:light[level=12]
setblock 191 225 299 minecraft:light[level=12]
setblock 191 225 306 minecraft:light[level=12]
fill 192 225 275 192 226 275 minecraft:prismarine_bricks
fill 194 225 275 194 226 275 minecraft:prismarine_bricks
setblock 198 225 278 minecraft:light[level=12]
setblock 198 225 285 minecraft:light[level=12]
setblock 198 225 292 minecraft:light[level=12]
setblock 198 225 299 minecraft:light[level=12]
setblock 198 225 306 minecraft:light[level=12]
setblock 198 225 313 minecraft:light[level=12]
setblock 199 225 275 minecraft:prismarine_bricks
fill 199 225 317 199 226 317 minecraft:prismarine_bricks
setblock 204 225 317 minecraft:prismarine
setblock 205 225 278 minecraft:light[level=12]
setblock 205 225 285 minecraft:light[level=12]
setblock 205 225 313 minecraft:light[level=12]
setblock 208 225 317 minecraft:prismarine
fill 209 225 317 209 226 317 minecraft:prismarine_bricks
fill 211 225 286 211 225 295 minecraft:prismarine_bricks
fill 211 225 301 211 225 310 minecraft:prismarine_bricks
fill 211 225 317 212 226 317 minecraft:prismarine_bricks
setblock 212 225 275 minecraft:prismarine
setblock 212 225 278 minecraft:light[level=12]
setblock 212 225 285 minecraft:light[level=12]
fill 212 225 286 212 225 294 minecraft:prismarine_bricks
fill 212 225 302 212 225 310 minecraft:prismarine_bricks
setblock 212 225 313 minecraft:light[level=12]
setblock 216 225 317 minecraft:prismarine
fill 217 225 295 226 225 295 minecraft:prismarine_bricks
fill 217 225 301 226 225 301 minecraft:prismarine_bricks
fill 217 225 317 217 226 317 minecraft:prismarine_bricks
fill 218 225 296 226 225 296 minecraft:prismarine_bricks
fill 218 225 300 226 225 300 minecraft:prismarine_bricks
setblock 219 225 278 minecraft:light[level=12]
setblock 219 225 285 minecraft:light[level=12]
setblock 219 225 313 minecraft:light[level=12]
fill 220 225 275 220 226 275 minecraft:prismarine_bricks
setblock 221 225 275 minecraft:prismarine
setblock 224 225 275 minecraft:prismarine
setblock 226 225 285 minecraft:light[level=12]
fill 227 225 275 229 226 275 minecraft:prismarine_bricks
setblock 230 225 275 minecraft:prismarine
fill 230 225 277 230 226 277 minecraft:prismarine_bricks
setblock 230 225 278 minecraft:prismarine
setblock 230 225 282 minecraft:prismarine
fill 230 225 285 230 226 286 minecraft:prismarine_bricks
fill 230 225 288 230 226 288 minecraft:prismarine_bricks
fill 230 225 290 230 226 290 minecraft:prismarine_bricks
setblock 230 225 293 minecraft:prismarine
fill 230 225 294 230 226 294 minecraft:prismarine_bricks
fill 230 225 306 230 226 306 minecraft:prismarine_bricks
setblock 230 225 308 minecraft:sea_lantern
setblock 230 225 309 minecraft:prismarine
fill 230 225 310 230 226 310 minecraft:prismarine_bricks
setblock 230 225 311 minecraft:prismarine
fill 230 225 317 230 226 317 minecraft:prismarine_bricks
setblock 188 226 283 minecraft:prismarine_bricks
setblock 188 226 298 minecraft:prismarine_bricks
setblock 188 226 305 minecraft:prismarine_bricks
setblock 188 226 314 minecraft:prismarine_bricks
fill 189 226 275 189 227 275 minecraft:prismarine_bricks
fill 189 226 296 193 227 296 minecraft:prismarine_bricks
fill 189 226 317 190 226 317 minecraft:prismarine_bricks
fill 190 226 279 194 227 279 minecraft:prismarine_bricks
fill 190 226 295 192 227 295 minecraft:prismarine_bricks
fill 190 226 297 192 227 297 minecraft:prismarine_bricks
fill 190 226 313 194 227 313 minecraft:prismarine_bricks
setblock 191 226 275 minecraft:prismarine_bricks
fill 191 226 278 193 227 278 minecraft:prismarine_bricks
fill 191 226 280 193 227 280 minecraft:prismarine_bricks
fill 191 226 294 191 228 294 minecraft:prismarine_bricks
fill 191 226 298 191 228 298 minecraft:prismarine_bricks
fill 191 226 312 193 227 312 minecraft:prismarine_bricks
fill 191 226 314 193 227 314 minecraft:prismarine_bricks
fill 192 226 277 192 227 277 minecraft:prismarine_bricks
fill 192 226 281 192 227 281 minecraft:prismarine_bricks
fill 192 226 311 192 227 311 minecraft:prismarine_bricks
fill 192 226 315 192 227 315 minecraft:prismarine_bricks
setblock 199 226 275 minecraft:sea_lantern
fill 203 226 287 203 227 287 minecraft:sea_lantern
fill 203 226 309 203 227 309 minecraft:sea_lantern
fill 204 226 288 210 227 308 minecraft:dark_prismarine
setblock 204 226 317 minecraft:prismarine_bricks
fill 207 226 278 211 227 278 minecraft:prismarine_bricks
fill 207 226 314 211 227 314 minecraft:prismarine_bricks
fill 208 226 277 210 227 277 minecraft:prismarine_bricks
fill 208 226 279 210 227 279 minecraft:prismarine_bricks
fill 208 226 313 210 227 313 minecraft:prismarine_bricks
fill 208 226 315 210 227 315 minecraft:prismarine_bricks
setblock 208 226 317 minecraft:prismarine_bricks
fill 209 226 276 209 227 276 minecraft:prismarine_bricks
fill 209 226 280 209 227 280 minecraft:prismarine_bricks
fill 209 226 312 209 228 312 minecraft:prismarine_bricks
fill 209 226 316 209 228 316 minecraft:prismarine_bricks
fill 211 226 288 211 227 295 minecraft:dark_prismarine
fill 211 226 301 211 227 308 minecraft:dark_prismarine
setblock 212 226 275 minecraft:prismarine_bricks
fill 212 226 288 224 227 294 minecraft:dark_prismarine
fill 212 226 302 224 227 308 minecraft:dark_prismarine
fill 215 226 317 216 226 317 minecraft:prismarine_bricks
fill 217 226 295 224 227 295 minecraft:dark_prismarine
fill 217 226 301 224 227 301 minecraft:dark_prismarine
fill 218 226 296 224 227 300 minecraft:dark_prismarine
setblock 221 226 275 minecraft:prismarine_bricks
setblock 224 226 275 minecraft:prismarine_bricks
fill 224 226 279 228 227 279 minecraft:prismarine_bricks
fill 224 226 313 228 227 313 minecraft:prismarine_bricks
fill 225 226 278 227 227 278 minecraft:prismarine_bricks
fill 225 226 280 227 227 280 minecraft:prismarine_bricks
fill 225 226 287 225 227 287 minecraft:sea_lantern
fill 225 226 296 229 227 296 minecraft:prismarine_bricks
fill 225 226 309 225 227 309 minecraft:sea_lantern
fill 225 226 312 227 227 312 minecraft:prismarine_bricks
fill 225 226 314 227 227 314 minecraft:prismarine_bricks
fill 226 226 277 226 228 277 minecraft:prismarine_bricks
fill 226 226 281 226 228 281 minecraft:prismarine_bricks
fill 226 226 295 228 227 295 minecraft:prismarine_bricks
fill 226 226 297 228 227 297 minecraft:prismarine_bricks
fill 226 226 311 226 238 311 minecraft:prismarine_bricks
fill 226 226 315 226 227 315 minecraft:prismarine_bricks
fill 227 226 294 227 227 294 minecraft:prismarine_bricks
fill 227 226 298 227 227 298 minecraft:prismarine_bricks
setblock 230 226 275 minecraft:prismarine_bricks
setblock 230 226 278 minecraft:prismarine_bricks
setblock 230 226 282 minecraft:prismarine_bricks
setblock 230 226 293 minecraft:prismarine_bricks
fill 230 226 308 230 226 309 minecraft:prismarine_bricks
setblock 230 226 311 minecraft:prismarine_bricks
fill 188 227 275 188 227 280 minecraft:prismarine
fill 188 227 281 188 231 284 minecraft:sea_lantern
fill 188 227 285 188 228 288 minecraft:prismarine
fill 188 227 289 188 227 290 minecraft:prismarine_bricks
fill 188 227 291 188 227 292 minecraft:prismarine
fill 188 227 293 188 231 296 minecraft:sea_lantern
fill 188 227 297 188 237 301 minecraft:prismarine
fill 188 227 303 188 245 304 minecraft:prismarine
fill 188 227 305 188 231 308 minecraft:sea_lantern
fill 188 227 309 188 227 312 minecraft:prismarine
fill 188 227 314 188 297 316 minecraft:prismarine
fill 188 227 317 191 231 317 minecraft:sea_lantern
fill 189 227 276 191 272 276 minecraft:prismarine_bricks
fill 189 227 286 189 272 288 minecraft:prismarine_bricks
fill 189 227 294 189 228 295 minecraft:prismarine_bricks
fill 189 227 297 189 228 304 minecraft:prismarine_bricks
fill 189 227 310 189 272 312 minecraft:prismarine_bricks
fill 190 227 275 194 227 275 minecraft:prismarine
fill 190 227 294 190 252 294 minecraft:prismarine_bricks
fill 190 227 298 190 228 304 minecraft:prismarine_bricks
fill 191 227 299 193 228 304 minecraft:prismarine_bricks
fill 192 227 294 193 228 294 minecraft:prismarine_bricks
fill 192 227 298 193 228 298 minecraft:prismarine_bricks
fill 192 227 317 199 227 317 minecraft:prismarine
fill 193 227 295 193 252 295 minecraft:prismarine_bricks
fill 193 227 297 193 252 297 minecraft:prismarine_bricks
fill 195 227 275 198 231 275 minecraft:sea_lantern
fill 195 227 316 197 272 316 minecraft:prismarine_bricks
fill 199 227 275 200 252 275 minecraft:prismarine
fill 200 227 317 203 231 317 minecraft:sea_lantern
fill 201 227 276 203 272 276 minecraft:prismarine_bricks
fill 202 227 275 206 228 275 minecraft:prismarine
fill 202 227 310 206 228 316 minecraft:prismarine_bricks
fill 204 227 317 211 235 317 minecraft:prismarine
fill 207 227 275 210 231 275 minecraft:sea_lantern
fill 207 227 310 207 228 313 minecraft:prismarine_bricks
fill 207 227 315 207 228 316 minecraft:prismarine_bricks
fill 208 227 310 208 228 312 minecraft:prismarine_bricks
fill 208 227 316 208 272 316 minecraft:prismarine_bricks
fill 209 227 310 210 228 311 minecraft:prismarine_bricks
fill 210 227 312 210 243 312 minecraft:prismarine_bricks
fill 210 227 316 210 243 316 minecraft:prismarine_bricks
fill 211 227 275 218 227 275 minecraft:prismarine
fill 212 227 317 215 231 317 minecraft:sea_lantern
fill 213 227 276 215 272 276 minecraft:prismarine_bricks
fill 216 227 317 223 227 317 minecraft:prismarine
fill 219 227 275 222 231 275 minecraft:sea_lantern
fill 219 227 316 221 272 316 minecraft:prismarine_bricks
fill 221 227 276 223 228 286 minecraft:prismarine_bricks
fill 222 227 309 224 228 309 minecraft:prismarine_bricks
fill 223 227 275 230 227 275 minecraft:prismarine
fill 223 227 310 225 238 311 minecraft:prismarine_bricks
fill 224 227 276 224 228 278 minecraft:prismarine_bricks
fill 224 227 280 224 228 286 minecraft:prismarine_bricks
fill 224 227 317 227 231 317 minecraft:sea_lantern
fill 225 227 276 225 228 277 minecraft:prismarine_bricks
fill 225 227 281 225 228 286 minecraft:prismarine_bricks
fill 225 227 301 229 228 308 minecraft:prismarine_bricks
fill 226 227 276 229 228 276 minecraft:prismarine_bricks
fill 226 227 282 229 228 286 minecraft:prismarine_bricks
fill 226 227 309 229 228 310 minecraft:prismarine_bricks
fill 227 227 277 229 228 277 minecraft:prismarine_bricks
fill 227 227 281 229 228 281 minecraft:prismarine_bricks
fill 227 227 311 229 238 311 minecraft:prismarine_bricks
fill 228 227 278 229 228 278 minecraft:prismarine_bricks
fill 228 227 280 229 228 280 minecraft:prismarine_bricks
fill 228 227 317 230 227 317 minecraft:prismarine
fill 229 227 279 229 242 279 minecraft:prismarine_bricks
fill 229 227 297 229 272 298 minecraft:prismarine_bricks
fill 230 227 276 230 231 279 minecraft:sea_lantern
fill 230 227 280 230 227 287 minecraft:prismarine
fill 230 227 288 230 231 291 minecraft:sea_lantern
fill 230 227 292 230 228 299 minecraft:prismarine
fill 230 227 300 230 231 303 minecraft:sea_lantern
fill 230 227 304 230 230 308 minecraft:prismarine
setblock 230 227 309 minecraft:prismarine_bricks
fill 230 227 310 230 227 311 minecraft:prismarine
fill 230 227 312 230 231 315 minecraft:sea_lantern
fill 230 227 316 230 265 316 minecraft:prismarine
fill 188 228 275 193 234 275 minecraft:prismarine
setblock 188 228 276 minecraft:prismarine_bricks
fill 188 228 277 188 255 280 minecraft:prismarine
fill 188 228 289 188 228 291 minecraft:prismarine
setblock 188 228 292 minecraft:prismarine_bricks
fill 188 228 302 188 254 302 minecraft:prismarine
fill 188 228 309 188 228 311 minecraft:prismarine
setblock 188 228 312 minecraft:prismarine_bricks
fill 188 228 313 188 236 313 minecraft:prismarine
setblock 189 228 296 minecraft:prismarine_bricks
fill 190 228 295 192 228 297 minecraft:quartz_pillar
fill 191 228 278 193 255 280 minecraft:quartz_pillar
fill 191 228 312 193 255 314 minecraft:quartz_pillar
fill 192 228 317 197 231 317 minecraft:prismarine
setblock 193 228 296 minecraft:prismarine_bricks
setblock 194 228 275 minecraft:prismarine_bricks
fill 198 228 317 198 229 317 minecraft:prismarine_bricks
fill 199 228 317 199 290 317 minecraft:prismarine
fill 201 228 275 201 308 275 minecraft:prismarine
fill 203 228 308 204 229 308 minecraft:white_stained_glass
fill 204 228 309 204 229 309 minecraft:white_stained_glass
fill 206 228 290 209 229 306 minecraft:prismarine_bricks
setblock 207 228 314 minecraft:prismarine_bricks
fill 208 228 277 210 255 279 minecraft:quartz_pillar
fill 208 228 313 210 228 315 minecraft:quartz_pillar
fill 210 228 290 210 229 296 minecraft:prismarine_bricks
fill 210 228 300 210 229 306 minecraft:prismarine_bricks
setblock 211 228 275 minecraft:sea_lantern
fill 211 228 290 211 228 295 minecraft:prismarine_bricks
fill 211 228 301 211 228 306 minecraft:prismarine_bricks
fill 212 228 275 214 253 275 minecraft:prismarine
fill 212 228 290 212 229 294 minecraft:prismarine_bricks
fill 212 228 302 212 229 306 minecraft:prismarine_bricks
fill 213 228 290 222 229 293 minecraft:prismarine_bricks
fill 213 228 303 224 228 306 minecraft:prismarine_bricks
setblock 215 228 275 minecraft:prismarine_bricks
fill 216 228 275 218 228 275 minecraft:prismarine
fill 216 228 294 222 229 294 minecraft:prismarine_bricks
fill 216 228 302 224 228 302 minecraft:prismarine_bricks
fill 216 228 317 217 292 317 minecraft:prismarine
fill 217 228 295 222 228 295 minecraft:prismarine_bricks
fill 217 228 301 224 228 301 minecraft:prismarine_bricks
fill 218 228 296 222 229 296 minecraft:prismarine_bricks
fill 218 228 300 222 229 300 minecraft:prismarine_bricks
setblock 218 228 317 minecraft:prismarine_bricks
fill 219 228 297 222 229 299 minecraft:prismarine_bricks
fill 219 228 317 223 228 317 minecraft:prismarine
fill 222 228 307 224 228 308 minecraft:prismarine_bricks
fill 223 228 275 224 228 275 minecraft:prismarine
setblock 224 228 279 minecraft:prismarine_bricks
setblock 225 228 275 minecraft:prismarine_bricks
fill 225 228 278 227 228 280 minecraft:quartz_pillar
fill 225 228 309 225 238 309 minecraft:prismarine_bricks
fill 225 228 312 227 255 314 minecraft:quartz_pillar
fill 226 228 275 229 228 275 minecraft:prismarine
fill 226 228 295 228 255 297 minecraft:quartz_pillar
setblock 228 228 279 minecraft:prismarine_bricks
fill 228 228 317 229 269 317 minecraft:prismarine
fill 229 228 296 229 272 296 minecraft:prismarine_bricks
setblock 230 228 275 minecraft:prismarine_bricks
setblock 230 228 280 minecraft:prismarine_bricks
fill 230 228 281 230 256 286 minecraft:prismarine
setblock 230 228 287 minecraft:prismarine_bricks
fill 230 228 309 230 308 310 minecraft:prismarine
setblock 230 228 311 minecraft:prismarine_bricks
fill 230 228 317 230 229 317 minecraft:prismarine_bricks
fill 188 229 276 188 308 276 minecraft:prismarine
fill 188 229 285 188 260 287 minecraft:prismarine
setblock 188 229 288 minecraft:prismarine_bricks
fill 188 229 289 188 290 290 minecraft:prismarine
setblock 188 229 291 minecraft:prismarine_bricks
fill 188 229 292 188 308 292 minecraft:prismarine
fill 188 229 309 188 255 310 minecraft:prismarine
setblock 188 229 311 minecraft:prismarine_bricks
fill 188 229 312 188 238 312 minecraft:prismarine
setblock 189 229 294 minecraft:sea_lantern
fill 189 229 295 189 244 295 minecraft:prismarine_bricks
setblock 189 229 296 minecraft:sea_lantern
fill 189 229 297 189 252 297 minecraft:prismarine_bricks
setblock 189 229 298 minecraft:sea_lantern
fill 189 229 299 189 272 299 minecraft:prismarine_bricks
setblock 189 229 300 minecraft:sea_lantern
fill 189 229 301 189 252 301 minecraft:prismarine_bricks
setblock 189 229 302 minecraft:sea_lantern
fill 189 229 303 189 244 303 minecraft:prismarine_bricks
setblock 189 229 304 minecraft:sea_lantern
setblock 190 229 295 minecraft:sea_lantern
fill 190 229 296 190 255 296 minecraft:quartz_pillar
setblock 190 229 297 minecraft:sea_lantern
fill 190 229 298 190 252 298 minecraft:prismarine_bricks
setblock 190 229 299 minecraft:sea_lantern
fill 190 229 300 190 252 300 minecraft:prismarine_bricks
setblock 190 229 301 minecraft:sea_lantern
fill 190 229 302 190 252 302 minecraft:prismarine_bricks
setblock 190 229 303 minecraft:sea_lantern
fill 190 229 304 190 252 304 minecraft:prismarine_bricks
setblock 191 229 294 minecraft:sea_lantern
fill 191 229 295 191 255 295 minecraft:quartz_pillar
setblock 191 229 296 minecraft:sea_lantern
fill 191 229 297 191 255 297 minecraft:quartz_pillar
setblock 191 229 298 minecraft:sea_lantern
fill 191 229 299 191 252 299 minecraft:prismarine_bricks
setblock 191 229 300 minecraft:sea_lantern
fill 191 229 301 191 252 301 minecraft:prismarine_bricks
setblock 191 229 302 minecraft:sea_lantern
fill 191 229 303 191 252 303 minecraft:prismarine_bricks
setblock 191 229 304 minecraft:sea_lantern
fill 192 229 294 192 252 294 minecraft:prismarine_bricks
setblock 192 229 295 minecraft:sea_lantern
fill 192 229 296 192 255 296 minecraft:quartz_pillar
setblock 192 229 297 minecraft:sea_lantern
fill 192 229 298 192 252 298 minecraft:prismarine_bricks
setblock 192 229 299 minecraft:sea_lantern
fill 192 229 300 192 252 300 minecraft:prismarine_bricks
setblock 192 229 301 minecraft:sea_lantern
fill 192 229 302 192 252 302 minecraft:prismarine_bricks
setblock 192 229 303 minecraft:sea_lantern
fill 192 229 304 192 252 304 minecraft:prismarine_bricks
setblock 193 229 294 minecraft:sea_lantern
setblock 193 229 296 minecraft:sea_lantern
setblock 193 229 298 minecraft:sea_lantern
fill 193 229 299 193 252 299 minecraft:prismarine_bricks
setblock 193 229 300 minecraft:sea_lantern
fill 193 229 301 193 252 301 minecraft:prismarine_bricks
setblock 193 229 302 minecraft:sea_lantern
fill 193 229 303 193 252 303 minecraft:prismarine_bricks
setblock 193 229 304 minecraft:sea_lantern
fill 194 229 275 194 266 275 minecraft:prismarine
setblock 202 229 275 minecraft:prismarine_bricks
fill 202 229 310 202 243 310 minecraft:prismarine_bricks
setblock 202 229 311 minecraft:sea_lantern
fill 202 229 312 202 243 312 minecraft:prismarine_bricks
setblock 202 229 313 minecraft:sea_lantern
fill 202 229 314 202 243 314 minecraft:prismarine_bricks
setblock 202 229 315 minecraft:sea_lantern
fill 202 229 316 202 243 316 minecraft:prismarine_bricks
fill 203 229 275 204 242 275 minecraft:prismarine
setblock 203 229 310 minecraft:sea_lantern
fill 203 229 311 203 243 311 minecraft:prismarine_bricks
setblock 203 229 312 minecraft:sea_lantern
fill 203 229 313 203 243 313 minecraft:prismarine_bricks
setblock 203 229 314 minecraft:sea_lantern
fill 203 229 315 203 243 315 minecraft:prismarine_bricks
setblock 203 229 316 minecraft:sea_lantern
fill 204 229 310 204 243 310 minecraft:prismarine_bricks
setblock 204 229 311 minecraft:sea_lantern
fill 204 229 312 204 243 312 minecraft:prismarine_bricks
setblock 204 229 313 minecraft:sea_lantern
fill 204 229 314 204 243 314 minecraft:prismarine_bricks
setblock 204 229 315 minecraft:sea_lantern
fill 204 229 316 204 243 316 minecraft:prismarine_bricks
setblock 205 229 275 minecraft:prismarine_bricks
setblock 205 229 310 minecraft:sea_lantern
fill 205 229 311 205 243 311 minecraft:prismarine_bricks
setblock 205 229 312 minecraft:sea_lantern
fill 205 229 313 205 243 313 minecraft:prismarine_bricks
setblock 205 229 314 minecraft:sea_lantern
fill 205 229 315 205 243 315 minecraft:prismarine_bricks
setblock 205 229 316 minecraft:sea_lantern
fill 206 229 275 206 258 275 minecraft:prismarine
fill 206 229 310 206 243 310 minecraft:prismarine_bricks
setblock 206 229 311 minecraft:sea_lantern
fill 206 229 312 206 243 312 minecraft:prismarine_bricks
setblock 206 229 313 minecraft:sea_lantern
fill 206 229 314 206 243 314 minecraft:prismarine_bricks
setblock 206 229 315 minecraft:sea_lantern
fill 206 229 316 206 243 316 minecraft:prismarine_bricks
setblock 207 229 310 minecraft:sea_lantern
fill 207 229 311 207 243 311 minecraft:prismarine_bricks
setblock 207 229 312 minecraft:sea_lantern
fill 207 229 313 207 243 313 minecraft:prismarine_bricks
setblock 207 229 314 minecraft:sea_lantern
fill 207 229 315 207 243 315 minecraft:prismarine_bricks
setblock 207 229 316 minecraft:sea_lantern
fill 208 229 310 208 243 310 minecraft:prismarine_bricks
setblock 208 229 311 minecraft:sea_lantern
fill 208 229 312 208 243 312 minecraft:prismarine_bricks
setblock 208 229 313 minecraft:sea_lantern
fill 208 229 314 208 255 314 minecraft:quartz_pillar
setblock 208 229 315 minecraft:sea_lantern
setblock 209 229 310 minecraft:sea_lantern
fill 209 229 311 209 243 311 minecraft:prismarine_bricks
setblock 209 229 312 minecraft:sea_lantern
fill 209 229 313 209 255 313 minecraft:quartz_pillar
setblock 209 229 314 minecraft:sea_lantern
fill 209 229 315 209 255 315 minecraft:quartz_pillar
setblock 209 229 316 minecraft:sea_lantern
fill 210 229 310 210 243 310 minecraft:prismarine_bricks
setblock 210 229 311 minecraft:sea_lantern
setblock 210 229 313 minecraft:sea_lantern
fill 210 229 314 210 255 314 minecraft:quartz_pillar
setblock 210 229 315 minecraft:sea_lantern
fill 211 229 275 211 233 275 minecraft:prismarine
fill 211 229 290 211 229 294 minecraft:prismarine_bricks
fill 211 229 302 211 229 306 minecraft:prismarine_bricks
fill 213 229 303 222 229 306 minecraft:prismarine_bricks
setblock 215 229 275 minecraft:sea_lantern
fill 216 229 275 217 261 275 minecraft:prismarine
fill 216 229 302 222 229 302 minecraft:prismarine_bricks
setblock 218 229 275 minecraft:prismarine_bricks
fill 218 229 295 222 229 295 minecraft:prismarine_bricks
fill 218 229 301 223 229 301 minecraft:prismarine_bricks
fill 218 229 317 219 239 317 minecraft:prismarine
setblock 220 229 317 minecraft:prismarine_bricks
setblock 221 229 276 minecraft:sea_lantern
fill 221 229 277 221 242 277 minecraft:prismarine_bricks
setblock 221 229 278 minecraft:sea_lantern
fill 221 229 279 221 242 279 minecraft:prismarine_bricks
setblock 221 229 280 minecraft:sea_lantern
fill 221 229 281 221 242 281 minecraft:prismarine_bricks
setblock 221 229 282 minecraft:sea_lantern
fill 221 229 283 221 242 283 minecraft:prismarine_bricks
setblock 221 229 284 minecraft:sea_lantern
fill 221 229 285 221 242 285 minecraft:prismarine_bricks
setblock 221 229 286 minecraft:sea_lantern
fill 221 229 317 223 308 317 minecraft:prismarine
fill 222 229 276 222 242 276 minecraft:prismarine_bricks
setblock 222 229 277 minecraft:sea_lantern
fill 222 229 278 222 242 278 minecraft:prismarine_bricks
setblock 222 229 279 minecraft:sea_lantern
fill 222 229 280 222 242 280 minecraft:prismarine_bricks
setblock 222 229 281 minecraft:sea_lantern
fill 222 229 282 222 242 282 minecraft:prismarine_bricks
setblock 222 229 283 minecraft:sea_lantern
fill 222 229 284 222 242 284 minecraft:prismarine_bricks
setblock 222 229 285 minecraft:sea_lantern
fill 222 229 286 222 242 286 minecraft:prismarine_bricks
setblock 222 229 307 minecraft:sea_lantern
fill 222 229 308 222 239 308 minecraft:prismarine_bricks
setblock 222 229 309 minecraft:sea_lantern
setblock 223 229 275 minecraft:prismarine_bricks
setblock 223 229 276 minecraft:sea_lantern
fill 223 229 277 223 242 277 minecraft:prismarine_bricks
setblock 223 229 278 minecraft:sea_lantern
fill 223 229 279 223 242 279 minecraft:prismarine_bricks
setblock 223 229 280 minecraft:sea_lantern
fill 223 229 281 223 242 281 minecraft:prismarine_bricks
setblock 223 229 282 minecraft:sea_lantern
fill 223 229 283 223 242 283 minecraft:prismarine_bricks
setblock 223 229 284 minecraft:sea_lantern
fill 223 229 285 223 242 285 minecraft:prismarine_bricks
setblock 223 229 286 minecraft:sea_lantern
setblock 223 229 302 minecraft:sea_lantern
fill 223 229 303 223 239 303 minecraft:prismarine_bricks
setblock 223 229 304 minecraft:sea_lantern
fill 223 229 305 223 239 305 minecraft:prismarine_bricks
setblock 223 229 306 minecraft:sea_lantern
fill 223 229 307 223 239 307 minecraft:prismarine_bricks
setblock 223 229 308 minecraft:sea_lantern
fill 223 229 309 223 239 309 minecraft:prismarine_bricks
fill 224 229 275 225 308 275 minecraft:prismarine
fill 224 229 276 224 242 276 minecraft:prismarine_bricks
setblock 224 229 277 minecraft:sea_lantern
fill 224 229 278 224 242 278 minecraft:prismarine_bricks
setblock 224 229 279 minecraft:sea_lantern
fill 224 229 280 224 242 280 minecraft:prismarine_bricks
setblock 224 229 281 minecraft:sea_lantern
fill 224 229 282 224 242 282 minecraft:prismarine_bricks
setblock 224 229 283 minecraft:sea_lantern
fill 224 229 284 224 242 284 minecraft:prismarine_bricks
setblock 224 229 285 minecraft:sea_lantern
fill 224 229 286 224 242 286 minecraft:prismarine_bricks
setblock 224 229 301 minecraft:sea_lantern
fill 224 229 302 224 238 302 minecraft:prismarine_bricks
setblock 224 229 303 minecraft:sea_lantern
fill 224 229 304 224 238 304 minecraft:prismarine_bricks
setblock 224 229 305 minecraft:sea_lantern
fill 224 229 306 224 238 306 minecraft:prismarine_bricks
setblock 224 229 307 minecraft:sea_lantern
fill 224 229 308 224 238 308 minecraft:prismarine_bricks
setblock 224 229 309 minecraft:sea_lantern
setblock 225 229 276 minecraft:sea_lantern
fill 225 229 277 225 245 277 minecraft:prismarine_bricks
setblock 225 229 278 minecraft:sea_lantern
fill 225 229 279 225 255 279 minecraft:quartz_pillar
setblock 225 229 280 minecraft:sea_lantern
fill 225 229 281 225 242 281 minecraft:prismarine_bricks
setblock 225 229 282 minecraft:sea_lantern
fill 225 229 283 225 242 283 minecraft:prismarine_bricks
setblock 225 229 284 minecraft:sea_lantern
fill 225 229 285 225 242 285 minecraft:prismarine_bricks
setblock 225 229 286 minecraft:sea_lantern
fill 225 229 301 225 239 301 minecraft:prismarine_bricks
setblock 225 229 302 minecraft:sea_lantern
fill 225 229 303 225 238 303 minecraft:prismarine_bricks
setblock 225 229 304 minecraft:sea_lantern
fill 225 229 305 225 238 305 minecraft:prismarine_bricks
setblock 225 229 306 minecraft:sea_lantern
fill 225 229 307 225 238 307 minecraft:prismarine_bricks
setblock 225 229 308 minecraft:sea_lantern
fill 226 229 275 226 230 276 minecraft:prismarine_bricks
setblock 226 229 277 minecraft:sea_lantern
fill 226 229 278 226 255 278 minecraft:quartz_pillar
setblock 226 229 279 minecraft:sea_lantern
fill 226 229 280 226 255 280 minecraft:quartz_pillar
setblock 226 229 281 minecraft:sea_lantern
fill 226 229 282 226 242 282 minecraft:prismarine_bricks
setblock 226 229 283 minecraft:sea_lantern
fill 226 229 284 226 242 284 minecraft:prismarine_bricks
setblock 226 229 285 minecraft:sea_lantern
fill 226 229 286 226 242 286 minecraft:prismarine_bricks
setblock 226 229 301 minecraft:sea_lantern
fill 226 229 302 226 238 302 minecraft:prismarine_bricks
setblock 226 229 303 minecraft:sea_lantern
fill 226 229 304 226 238 304 minecraft:prismarine_bricks
setblock 226 229 305 minecraft:sea_lantern
fill 226 229 306 226 238 306 minecraft:prismarine_bricks
setblock 226 229 307 minecraft:sea_lantern
fill 226 229 308 226 238 308 minecraft:prismarine_bricks
setblock 226 229 309 minecraft:sea_lantern
fill 226 229 310 229 238 310 minecraft:prismarine_bricks
setblock 227 229 275 minecraft:prismarine_bricks
setblock 227 229 276 minecraft:sea_lantern
fill 227 229 277 227 242 277 minecraft:prismarine_bricks
setblock 227 229 278 minecraft:sea_lantern
fill 227 229 279 227 255 279 minecraft:quartz_pillar
setblock 227 229 280 minecraft:sea_lantern
fill 227 229 281 227 242 281 minecraft:prismarine_bricks
setblock 227 229 282 minecraft:sea_lantern
fill 227 229 283 227 242 283 minecraft:prismarine_bricks
setblock 227 229 284 minecraft:sea_lantern
fill 227 229 285 227 242 285 minecraft:prismarine_bricks
setblock 227 229 286 minecraft:sea_lantern
fill 227 229 301 227 239 301 minecraft:prismarine_bricks
setblock 227 229 302 minecraft:sea_lantern
fill 227 229 303 227 238 303 minecraft:prismarine_bricks
setblock 227 229 304 minecraft:sea_lantern
fill 227 229 305 227 238 305 minecraft:prismarine_bricks
setblock 227 229 306 minecraft:sea_lantern
fill 227 229 307 227 238 307 minecraft:prismarine_bricks
setblock 227 229 308 minecraft:sea_lantern
fill 227 229 309 227 238 309 minecraft:prismarine_bricks
fill 228 229 275 230 232 275 minecraft:prismarine
fill 228 229 276 228 242 276 minecraft:prismarine_bricks
setblock 228 229 277 minecraft:sea_lantern
fill 228 229 278 228 242 278 minecraft:prismarine_bricks
setblock 228 229 279 minecraft:sea_lantern
fill 228 229 280 228 242 280 minecraft:prismarine_bricks
setblock 228 229 281 minecraft:sea_lantern
fill 228 229 282 228 242 282 minecraft:prismarine_bricks
setblock 228 229 283 minecraft:sea_lantern
fill 228 229 284 228 242 284 minecraft:prismarine_bricks
setblock 228 229 285 minecraft:sea_lantern
fill 228 229 286 228 245 286 minecraft:prismarine_bricks
setblock 228 229 301 minecraft:sea_lantern
fill 228 229 302 228 238 302 minecraft:prismarine_bricks
setblock 228 229 303 minecraft:sea_lantern
fill 228 229 304 228 238 304 minecraft:prismarine_bricks
setblock 228 229 305 minecraft:sea_lantern
fill 228 229 306 228 238 306 minecraft:prismarine_bricks
setblock 228 229 307 minecraft:sea_lantern
fill 228 229 308 228 238 308 minecraft:prismarine_bricks
setblock 228 229 309 minecraft:sea_lantern
setblock 229 229 276 minecraft:sea_lantern
fill 229 229 277 229 242 277 minecraft:prismarine_bricks
setblock 229 229 278 minecraft:sea_lantern
setblock 229 229 280 minecraft:sea_lantern
fill 229 229 281 229 242 281 minecraft:prismarine_bricks
setblock 229 229 282 minecraft:sea_lantern
fill 229 229 283 229 242 283 minecraft:prismarine_bricks
setblock 229 229 284 minecraft:sea_lantern
fill 229 229 285 229 272 285 minecraft:prismarine_bricks
setblock 229 229 286 minecraft:sea_lantern
fill 229 229 301 229 239 301 minecraft:prismarine_bricks
setblock 229 229 302 minecraft:sea_lantern
fill 229 229 303 229 239 303 minecraft:prismarine_bricks
setblock 229 229 304 minecraft:sea_lantern
fill 229 229 305 229 239 305 minecraft:prismarine_bricks
setblock 229 229 306 minecraft:sea_lantern
fill 229 229 307 229 239 307 minecraft:prismarine_bricks
setblock 229 229 308 minecraft:sea_lantern
fill 229 229 309 229 272 309 minecraft:prismarine_bricks
fill 230 229 280 230 308 280 minecraft:prismarine
fill 230 229 287 230 260 287 minecraft:prismarine
setblock 230 229 292 minecraft:prismarine_bricks
fill 230 229 293 230 247 293 minecraft:prismarine
setblock 230 229 294 minecraft:prismarine_bricks
fill 230 229 295 230 230 296 minecraft:prismarine
setblock 230 229 297 minecraft:prismarine_bricks
fill 230 229 298 230 301 299 minecraft:prismarine
fill 230 229 311 230 293 311 minecraft:prismarine
fill 188 230 288 188 308 288 minecraft:prismarine
fill 188 230 291 188 308 291 minecraft:prismarine
fill 188 230 311 188 251 311 minecraft:prismarine
fill 189 230 294 189 231 294 minecraft:prismarine_bricks
fill 189 230 296 189 231 296 minecraft:prismarine_bricks
fill 189 230 298 189 231 298 minecraft:prismarine_bricks
fill 189 230 300 189 231 300 minecraft:prismarine_bricks
fill 189 230 302 189 231 302 minecraft:prismarine_bricks
fill 189 230 304 189 231 304 minecraft:prismarine_bricks
fill 190 230 295 190 231 295 minecraft:quartz_pillar
fill 190 230 297 190 231 297 minecraft:quartz_pillar
fill 190 230 299 190 231 299 minecraft:prismarine_bricks
fill 190 230 301 190 231 301 minecraft:prismarine_bricks
fill 190 230 303 190 231 303 minecraft:prismarine_bricks
fill 191 230 294 191 231 294 minecraft:prismarine_bricks
fill 191 230 296 191 231 296 minecraft:quartz_pillar
fill 191 230 298 191 231 298 minecraft:prismarine_bricks
fill 191 230 300 191 231 300 minecraft:prismarine_bricks
fill 191 230 302 191 231 302 minecraft:prismarine_bricks
fill 191 230 304 191 231 304 minecraft:prismarine_bricks
fill 192 230 295 192 231 295 minecraft:quartz_pillar
fill 192 230 297 192 231 297 minecraft:quartz_pillar
fill 192 230 299 192 231 299 minecraft:prismarine_bricks
fill 192 230 301 192 231 301 minecraft:prismarine_bricks
fill 192 230 303 192 231 303 minecraft:prismarine_bricks
fill 193 230 294 193 231 294 minecraft:prismarine_bricks
fill 193 230 296 193 231 296 minecraft:prismarine_bricks
fill 193 230 298 193 231 298 minecraft:prismarine_bricks
fill 193 230 300 193 231 300 minecraft:prismarine_bricks
fill 193 230 302 193 231 302 minecraft:prismarine_bricks
fill 193 230 304 193 231 304 minecraft:prismarine_bricks
fill 197 230 278 197 242 278 minecraft:iron_block
fill 198 230 317 198 308 317 minecraft:prismarine
fill 202 230 275 202 308 275 minecraft:prismarine
fill 202 230 311 202 231 311 minecraft:prismarine_bricks
fill 202 230 313 202 231 313 minecraft:prismarine_bricks
fill 202 230 315 202 231 315 minecraft:prismarine_bricks
fill 203 230 310 203 231 310 minecraft:prismarine_bricks
fill 203 230 312 203 231 312 minecraft:prismarine_bricks
fill 203 230 314 203 231 314 minecraft:prismarine_bricks
fill 203 230 316 203 231 316 minecraft:prismarine_bricks
fill 204 230 311 204 231 311 minecraft:prismarine_bricks
fill 204 230 313 204 231 313 minecraft:prismarine_bricks
fill 204 230 315 204 231 315 minecraft:prismarine_bricks
fill 205 230 275 205 258 275 minecraft:prismarine
fill 205 230 310 205 231 310 minecraft:prismarine_bricks
fill 205 230 312 205 231 312 minecraft:prismarine_bricks
fill 205 230 314 205 231 314 minecraft:prismarine_bricks
fill 205 230 316 205 231 316 minecraft:prismarine_bricks
fill 206 230 311 206 231 311 minecraft:prismarine_bricks
fill 206 230 313 206 231 313 minecraft:prismarine_bricks
fill 206 230 315 206 231 315 minecraft:prismarine_bricks
fill 207 230 310 207 231 310 minecraft:prismarine_bricks
fill 207 230 312 207 231 312 minecraft:prismarine_bricks
fill 207 230 314 207 231 314 minecraft:prismarine_bricks
fill 207 230 316 207 231 316 minecraft:prismarine_bricks
fill 208 230 292 209 231 304 minecraft:dark_prismarine
fill 208 230 311 208 231 311 minecraft:prismarine_bricks
fill 208 230 313 208 231 313 minecraft:quartz_pillar
fill 208 230 315 208 231 315 minecraft:quartz_pillar
fill 209 230 310 209 231 310 minecraft:prismarine_bricks
fill 209 230 312 209 231 312 minecraft:prismarine_bricks
fill 209 230 314 209 231 314 minecraft:quartz_pillar
fill 209 230 316 209 231 316 minecraft:prismarine_bricks
fill 210 230 292 210 230 296 minecraft:dark_prismarine
fill 210 230 300 210 230 304 minecraft:dark_prismarine
fill 210 230 311 210 231 311 minecraft:prismarine_bricks
fill 210 230 313 210 231 313 minecraft:quartz_pillar
fill 210 230 315 210 231 315 minecraft:quartz_pillar
fill 211 230 292 212 230 294 minecraft:dark_prismarine
fill 211 230 302 212 230 304 minecraft:dark_prismarine
fill 213 230 292 220 231 293 minecraft:dark_prismarine
fill 213 230 303 220 231 304 minecraft:dark_prismarine
fill 215 230 275 215 308 275 minecraft:prismarine
fill 216 230 294 220 230 294 minecraft:dark_prismarine
fill 216 230 302 220 230 302 minecraft:dark_prismarine
fill 218 230 275 218 271 275 minecraft:prismarine
fill 218 230 295 220 230 296 minecraft:dark_prismarine
fill 218 230 300 220 230 301 minecraft:dark_prismarine
fill 219 230 297 220 231 299 minecraft:dark_prismarine
fill 220 230 317 220 308 317 minecraft:prismarine
fill 221 230 276 221 231 276 minecraft:prismarine_bricks
fill 221 230 278 221 231 278 minecraft:prismarine_bricks
fill 221 230 280 221 231 280 minecraft:prismarine_bricks
fill 221 230 282 221 231 282 minecraft:prismarine_bricks
fill 221 230 284 221 231 284 minecraft:prismarine_bricks
fill 221 230 286 221 231 286 minecraft:prismarine_bricks
fill 222 230 277 222 231 277 minecraft:prismarine_bricks
fill 222 230 279 222 231 279 minecraft:prismarine_bricks
fill 222 230 281 222 231 281 minecraft:prismarine_bricks
fill 222 230 283 222 231 283 minecraft:prismarine_bricks
fill 222 230 285 222 231 285 minecraft:prismarine_bricks
fill 222 230 301 222 231 307 minecraft:prismarine_bricks
fill 222 230 309 222 231 309 minecraft:prismarine_bricks
fill 223 230 275 223 231 275 minecraft:prismarine
fill 223 230 276 223 231 276 minecraft:prismarine_bricks
fill 223 230 278 223 231 278 minecraft:prismarine_bricks
fill 223 230 280 223 231 280 minecraft:prismarine_bricks
fill 223 230 282 223 231 282 minecraft:prismarine_bricks
fill 223 230 284 223 231 284 minecraft:prismarine_bricks
fill 223 230 286 223 231 286 minecraft:prismarine_bricks
fill 223 230 301 223 231 302 minecraft:prismarine_bricks
fill 223 230 304 223 231 304 minecraft:prismarine_bricks
fill 223 230 306 223 231 306 minecraft:prismarine_bricks
fill 223 230 308 223 231 308 minecraft:prismarine_bricks
fill 224 230 277 224 231 277 minecraft:prismarine_bricks
fill 224 230 279 224 231 279 minecraft:prismarine_bricks
fill 224 230 281 224 231 281 minecraft:prismarine_bricks
fill 224 230 283 224 231 283 minecraft:prismarine_bricks
fill 224 230 285 224 231 285 minecraft:prismarine_bricks
fill 224 230 301 224 231 301 minecraft:prismarine_bricks
fill 224 230 303 224 231 303 minecraft:prismarine_bricks
fill 224 230 305 224 231 305 minecraft:prismarine_bricks
fill 224 230 307 224 231 307 minecraft:prismarine_bricks
fill 224 230 309 224 231 309 minecraft:prismarine_bricks
fill 225 230 276 225 231 276 minecraft:prismarine_bricks
fill 225 230 278 225 231 278 minecraft:quartz_pillar
fill 225 230 280 225 231 280 minecraft:quartz_pillar
fill 225 230 282 225 231 282 minecraft:prismarine_bricks
fill 225 230 284 225 231 284 minecraft:prismarine_bricks
fill 225 230 286 225 231 286 minecraft:prismarine_bricks
fill 225 230 302 225 231 302 minecraft:prismarine_bricks
fill 225 230 304 225 231 304 minecraft:prismarine_bricks
fill 225 230 306 225 231 306 minecraft:prismarine_bricks
fill 225 230 308 225 231 308 minecraft:prismarine_bricks
fill 226 230 277 226 231 277 minecraft:prismarine_bricks
fill 226 230 279 226 231 279 minecraft:quartz_pillar
fill 226 230 281 226 231 281 minecraft:prismarine_bricks
fill 226 230 283 226 231 283 minecraft:prismarine_bricks
fill 226 230 285 226 231 285 minecraft:prismarine_bricks
fill 226 230 301 226 231 301 minecraft:prismarine_bricks
fill 226 230 303 226 231 303 minecraft:prismarine_bricks
fill 226 230 305 226 231 305 minecraft:prismarine_bricks
fill 226 230 307 226 231 307 minecraft:prismarine_bricks
fill 226 230 309 226 231 309 minecraft:prismarine_bricks
fill 227 230 275 227 288 275 minecraft:prismarine
fill 227 230 276 227 231 276 minecraft:prismarine_bricks
fill 227 230 278 227 231 278 minecraft:quartz_pillar
fill 227 230 280 227 231 280 minecraft:quartz_pillar
fill 227 230 282 227 231 282 minecraft:prismarine_bricks
fill 227 230 284 227 231 284 minecraft:prismarine_bricks
fill 227 230 286 227 231 286 minecraft:prismarine_bricks
fill 227 230 302 227 231 302 minecraft:prismarine_bricks
fill 227 230 304 227 231 304 minecraft:prismarine_bricks
fill 227 230 306 227 231 306 minecraft:prismarine_bricks
fill 227 230 308 227 231 308 minecraft:prismarine_bricks
fill 228 230 277 228 231 277 minecraft:prismarine_bricks
fill 228 230 279 228 231 279 minecraft:prismarine_bricks
fill 228 230 281 228 231 281 minecraft:prismarine_bricks
fill 228 230 283 228 231 283 minecraft:prismarine_bricks
fill 228 230 285 228 231 285 minecraft:prismarine_bricks
fill 228 230 301 228 231 301 minecraft:prismarine_bricks
fill 228 230 303 228 231 303 minecraft:prismarine_bricks
fill 228 230 305 228 231 305 minecraft:prismarine_bricks
fill 228 230 307 228 231 307 minecraft:prismarine_bricks
fill 228 230 309 228 231 309 minecraft:prismarine_bricks
fill 229 230 276 229 231 276 minecraft:prismarine_bricks
fill 229 230 278 229 231 278 minecraft:prismarine_bricks
fill 229 230 280 229 231 280 minecraft:prismarine_bricks
fill 229 230 282 229 231 282 minecraft:prismarine_bricks
fill 229 230 284 229 231 284 minecraft:prismarine_bricks
fill 229 230 286 229 231 286 minecraft:prismarine_bricks
fill 229 230 302 229 231 302 minecraft:prismarine_bricks
fill 229 230 304 229 231 304 minecraft:prismarine_bricks
fill 229 230 306 229 231 306 minecraft:prismarine_bricks
fill 229 230 308 229 231 308 minecraft:prismarine_bricks
fill 230 230 292 230 301 292 minecraft:prismarine
fill 230 230 294 230 270 294 minecraft:prismarine
fill 230 230 297 230 285 297 minecraft:prismarine
fill 230 230 317 230 308 317 minecraft:prismarine
setblock 191 231 285 minecraft:light[level=12]
setblock 191 231 286 minecraft:light[level=15]
setblock 191 231 292 minecraft:light[level=12]
setblock 191 231 306 minecraft:light[level=12]
setblock 191 231 310 minecraft:light[level=15]
setblock 198 231 278 minecraft:light[level=12]
setblock 198 231 285 minecraft:light[level=12]
setblock 198 231 292 minecraft:light[level=12]
setblock 198 231 299 minecraft:light[level=12]
setblock 198 231 306 minecraft:light[level=12]
setblock 198 231 313 minecraft:light[level=12]
setblock 199 231 278 minecraft:light[level=15]
setblock 199 231 286 minecraft:light[level=15]
setblock 199 231 294 minecraft:light[level=15]
setblock 199 231 302 minecraft:light[level=15]
setblock 199 231 310 minecraft:light[level=15]
setblock 205 231 278 minecraft:light[level=12]
setblock 205 231 285 minecraft:light[level=12]
setblock 205 231 292 minecraft:light[level=12]
setblock 205 231 299 minecraft:light[level=12]
setblock 205 231 306 minecraft:light[level=12]
setblock 207 231 278 minecraft:light[level=15]
setblock 207 231 286 minecraft:light[level=15]
setblock 207 231 294 minecraft:light[level=15]
setblock 207 231 302 minecraft:light[level=15]
fill 210 231 292 210 231 295 minecraft:dark_prismarine
fill 210 231 301 210 231 304 minecraft:dark_prismarine
fill 211 231 292 211 231 294 minecraft:dark_prismarine
fill 211 231 302 211 231 304 minecraft:dark_prismarine
setblock 212 231 278 minecraft:light[level=12]
setblock 212 231 285 minecraft:light[level=12]
fill 212 231 292 212 231 293 minecraft:dark_prismarine
fill 212 231 303 212 231 304 minecraft:dark_prismarine
setblock 212 231 306 minecraft:light[level=12]
setblock 212 231 313 minecraft:light[level=12]
setblock 215 231 278 minecraft:light[level=15]
setblock 215 231 286 minecraft:light[level=15]
setblock 215 231 310 minecraft:light[level=15]
fill 217 231 294 220 231 294 minecraft:dark_prismarine
fill 217 231 302 220 231 302 minecraft:dark_prismarine
fill 218 231 295 220 231 295 minecraft:dark_prismarine
fill 218 231 301 220 231 301 minecraft:dark_prismarine
setblock 219 231 278 minecraft:light[level=12]
setblock 219 231 285 minecraft:light[level=12]
fill 219 231 296 220 231 296 minecraft:dark_prismarine
fill 219 231 300 220 231 300 minecraft:dark_prismarine
setblock 219 231 306 minecraft:light[level=12]
setblock 219 231 313 minecraft:light[level=12]
setblock 223 231 294 minecraft:light[level=15]
fill 226 231 275 226 308 275 minecraft:prismarine
fill 226 231 276 226 272 276 minecraft:prismarine_bricks
setblock 226 231 292 minecraft:light[level=12]
setblock 226 231 299 minecraft:light[level=12]
setblock 230 231 295 minecraft:prismarine_bricks
fill 230 231 296 230 240 296 minecraft:prismarine
fill 230 231 304 230 278 304 minecraft:prismarine
setblock 230 231 305 minecraft:sea_lantern
fill 230 231 306 230 240 308 minecraft:prismarine
fill 188 232 281 188 245 281 minecraft:prismarine
fill 188 232 282 188 232 283 minecraft:sea_lantern
fill 188 232 284 188 244 284 minecraft:prismarine
fill 188 232 293 188 245 293 minecraft:prismarine
fill 188 232 294 188 232 295 minecraft:sea_lantern
fill 188 232 296 188 245 296 minecraft:prismarine
fill 188 232 305 188 245 305 minecraft:prismarine
fill 188 232 306 188 232 307 minecraft:sea_lantern
fill 188 232 308 188 245 308 minecraft:prismarine
fill 188 232 317 188 245 317 minecraft:prismarine
setblock 189 232 294 minecraft:sea_lantern
setblock 189 232 296 minecraft:sea_lantern
setblock 189 232 298 minecraft:sea_lantern
setblock 189 232 300 minecraft:sea_lantern
setblock 189 232 302 minecraft:sea_lantern
setblock 189 232 304 minecraft:sea_lantern
fill 189 232 317 190 232 317 minecraft:sea_lantern
setblock 190 232 295 minecraft:sea_lantern
setblock 190 232 297 minecraft:sea_lantern
setblock 190 232 299 minecraft:sea_lantern
setblock 190 232 301 minecraft:sea_lantern
setblock 190 232 303 minecraft:sea_lantern
setblock 191 232 294 minecraft:sea_lantern
setblock 191 232 296 minecraft:sea_lantern
setblock 191 232 298 minecraft:sea_lantern
setblock 191 232 300 minecraft:sea_lantern
setblock 191 232 302 minecraft:sea_lantern
setblock 191 232 304 minecraft:sea_lantern
fill 191 232 317 196 235 317 minecraft:prismarine
setblock 192 232 295 minecraft:sea_lantern
setblock 192 232 297 minecraft:sea_lantern
setblock 192 232 299 minecraft:sea_lantern
setblock 192 232 301 minecraft:sea_lantern
setblock 192 232 303 minecraft:sea_lantern
setblock 193 232 294 minecraft:sea_lantern
setblock 193 232 296 minecraft:sea_lantern
setblock 193 232 298 minecraft:sea_lantern
setblock 193 232 300 minecraft:sea_lantern
setblock 193 232 302 minecraft:sea_lantern
setblock 193 232 304 minecraft:sea_lantern
fill 195 232 275 195 245 275 minecraft:prismarine
fill 196 232 275 197 232 275 minecraft:sea_lantern
setblock 197 232 317 minecraft:sea_lantern
fill 198 232 275 198 245 275 minecraft:prismarine
fill 200 232 317 200 242 317 minecraft:prismarine
fill 201 232 317 202 232 317 minecraft:sea_lantern
setblock 202 232 311 minecraft:sea_lantern
setblock 202 232 313 minecraft:sea_lantern
setblock 202 232 315 minecraft:sea_lantern
setblock 203 232 310 minecraft:sea_lantern
setblock 203 232 312 minecraft:sea_lantern
setblock 203 232 314 minecraft:sea_lantern
setblock 203 232 316 minecraft:sea_lantern
fill 203 232 317 203 245 317 minecraft:prismarine
setblock 204 232 311 minecraft:sea_lantern
setblock 204 232 313 minecraft:sea_lantern
setblock 204 232 315 minecraft:sea_lantern
setblock 205 232 310 minecraft:sea_lantern
setblock 205 232 312 minecraft:sea_lantern
setblock 205 232 314 minecraft:sea_lantern
setblock 205 232 316 minecraft:sea_lantern
setblock 206 232 311 minecraft:sea_lantern
setblock 206 232 313 minecraft:sea_lantern
setblock 206 232 315 minecraft:sea_lantern
fill 207 232 275 207 245 275 minecraft:prismarine
setblock 207 232 310 minecraft:sea_lantern
setblock 207 232 312 minecraft:sea_lantern
setblock 207 232 314 minecraft:sea_lantern
setblock 207 232 316 minecraft:sea_lantern
fill 208 232 275 209 232 275 minecraft:sea_lantern
setblock 208 232 311 minecraft:sea_lantern
setblock 208 232 313 minecraft:sea_lantern
setblock 208 232 315 minecraft:sea_lantern
setblock 209 232 310 minecraft:sea_lantern
setblock 209 232 312 minecraft:sea_lantern
setblock 209 232 314 minecraft:sea_lantern
setblock 209 232 316 minecraft:sea_lantern
fill 210 232 275 210 245 275 minecraft:prismarine
fill 210 232 294 210 233 295 minecraft:prismarine_bricks
fill 210 232 301 210 233 302 minecraft:prismarine_bricks
setblock 210 232 311 minecraft:sea_lantern
setblock 210 232 313 minecraft:sea_lantern
setblock 210 232 315 minecraft:sea_lantern
fill 211 232 294 211 233 294 minecraft:prismarine_bricks
fill 211 232 302 211 233 302 minecraft:prismarine_bricks
fill 212 232 317 212 245 317 minecraft:prismarine
fill 213 232 317 214 232 317 minecraft:sea_lantern
fill 215 232 317 215 245 317 minecraft:prismarine
fill 217 232 294 218 233 294 minecraft:prismarine_bricks
fill 217 232 302 218 233 302 minecraft:prismarine_bricks
fill 218 232 295 218 233 295 minecraft:prismarine_bricks
fill 218 232 301 218 233 301 minecraft:prismarine_bricks
fill 219 232 275 219 238 275 minecraft:prismarine
fill 220 232 275 221 232 275 minecraft:sea_lantern
setblock 221 232 276 minecraft:sea_lantern
setblock 221 232 278 minecraft:sea_lantern
setblock 221 232 280 minecraft:sea_lantern
setblock 221 232 282 minecraft:sea_lantern
setblock 221 232 284 minecraft:sea_lantern
setblock 221 232 286 minecraft:sea_lantern
fill 222 232 275 222 245 275 minecraft:prismarine
setblock 222 232 277 minecraft:sea_lantern
setblock 222 232 279 minecraft:sea_lantern
setblock 222 232 281 minecraft:sea_lantern
setblock 222 232 283 minecraft:sea_lantern
setblock 222 232 285 minecraft:sea_lantern
setblock 222 232 301 minecraft:sea_lantern
fill 222 232 302 222 239 302 minecraft:prismarine_bricks
setblock 222 232 303 minecraft:sea_lantern
fill 222 232 304 222 239 304 minecraft:prismarine_bricks
setblock 222 232 305 minecraft:sea_lantern
fill 222 232 306 222 239 306 minecraft:prismarine_bricks
setblock 222 232 307 minecraft:sea_lantern
setblock 222 232 309 minecraft:sea_lantern
fill 223 232 275 223 232 276 minecraft:sea_lantern
setblock 223 232 278 minecraft:sea_lantern
setblock 223 232 280 minecraft:sea_lantern
setblock 223 232 282 minecraft:sea_lantern
setblock 223 232 284 minecraft:sea_lantern
setblock 223 232 286 minecraft:sea_lantern
fill 223 232 301 223 239 301 minecraft:prismarine_bricks
setblock 223 232 302 minecraft:sea_lantern
setblock 223 232 304 minecraft:sea_lantern
setblock 223 232 306 minecraft:sea_lantern
setblock 223 232 308 minecraft:sea_lantern
setblock 224 232 277 minecraft:sea_lantern
setblock 224 232 279 minecraft:sea_lantern
setblock 224 232 281 minecraft:sea_lantern
setblock 224 232 283 minecraft:sea_lantern
setblock 224 232 285 minecraft:sea_lantern
setblock 224 232 301 minecraft:sea_lantern
setblock 224 232 303 minecraft:sea_lantern
setblock 224 232 305 minecraft:sea_lantern
setblock 224 232 307 minecraft:sea_lantern
setblock 224 232 309 minecraft:sea_lantern
fill 224 232 317 224 245 317 minecraft:prismarine
setblock 225 232 276 minecraft:sea_lantern
setblock 225 232 278 minecraft:sea_lantern
setblock 225 232 280 minecraft:sea_lantern
setblock 225 232 282 minecraft:sea_lantern
setblock 225 232 284 minecraft:sea_lantern
setblock 225 232 286 minecraft:sea_lantern
setblock 225 232 302 minecraft:sea_lantern
setblock 225 232 304 minecraft:sea_lantern
setblock 225 232 306 minecraft:sea_lantern
setblock 225 232 308 minecraft:sea_lantern
fill 225 232 317 226 232 317 minecraft:sea_lantern
setblock 226 232 277 minecraft:sea_lantern
setblock 226 232 279 minecraft:sea_lantern
setblock 226 232 281 minecraft:sea_lantern
setblock 226 232 283 minecraft:sea_lantern
setblock 226 232 285 minecraft:sea_lantern
setblock 226 232 301 minecraft:sea_lantern
setblock 226 232 303 minecraft:sea_lantern
setblock 226 232 305 minecraft:sea_lantern
setblock 226 232 307 minecraft:sea_lantern
setblock 226 232 309 minecraft:sea_lantern
setblock 227 232 276 minecraft:sea_lantern
setblock 227 232 278 minecraft:sea_lantern
setblock 227 232 280 minecraft:sea_lantern
setblock 227 232 282 minecraft:sea_lantern
setblock 227 232 284 minecraft:sea_lantern
setblock 227 232 286 minecraft:sea_lantern
setblock 227 232 302 minecraft:sea_lantern
setblock 227 232 304 minecraft:sea_lantern
setblock 227 232 306 minecraft:sea_lantern
setblock 227 232 308 minecraft:sea_lantern
fill 227 232 317 227 245 317 minecraft:prismarine
setblock 228 232 277 minecraft:sea_lantern
setblock 228 232 279 minecraft:sea_lantern
setblock 228 232 281 minecraft:sea_lantern
setblock 228 232 283 minecraft:sea_lantern
setblock 228 232 285 minecraft:sea_lantern
setblock 228 232 301 minecraft:sea_lantern
setblock 228 232 303 minecraft:sea_lantern
setblock 228 232 305 minecraft:sea_lantern
setblock 228 232 307 minecraft:sea_lantern
setblock 228 232 309 minecraft:sea_lantern
setblock 229 232 276 minecraft:sea_lantern
fill 229 232 278 230 232 278 minecraft:sea_lantern
setblock 229 232 280 minecraft:sea_lantern
setblock 229 232 282 minecraft:sea_lantern
setblock 229 232 284 minecraft:sea_lantern
setblock 229 232 286 minecraft:sea_lantern
fill 229 232 302 230 232 302 minecraft:sea_lantern
setblock 229 232 304 minecraft:sea_lantern
setblock 229 232 306 minecraft:sea_lantern
setblock 229 232 308 minecraft:sea_lantern
fill 230 232 276 230 245 276 minecraft:prismarine
setblock 230 232 277 minecraft:sea_lantern
fill 230 232 279 230 245 279 minecraft:prismarine
fill 230 232 288 230 245 288 minecraft:prismarine
fill 230 232 289 230 232 290 minecraft:sea_lantern
fill 230 232 291 230 245 291 minecraft:prismarine
fill 230 232 295 230 308 295 minecraft:prismarine
fill 230 232 300 230 235 300 minecraft:prismarine
setblock 230 232 301 minecraft:sea_lantern
fill 230 232 303 230 245 303 minecraft:prismarine
fill 230 232 305 230 300 305 minecraft:prismarine
fill 230 232 312 230 245 312 minecraft:prismarine
fill 230 232 313 230 232 314 minecraft:sea_lantern
fill 230 232 315 230 245 315 minecraft:prismarine
fill 188 233 282 188 233 283 minecraft:prismarine
fill 188 233 294 188 241 295 minecraft:prismarine
fill 188 233 306 188 245 307 minecraft:prismarine
fill 189 233 294 189 234 294 minecraft:prismarine_bricks
fill 189 233 296 189 234 296 minecraft:prismarine_bricks
fill 189 233 298 189 234 298 minecraft:prismarine_bricks
fill 189 233 300 189 234 300 minecraft:prismarine_bricks
fill 189 233 302 189 234 302 minecraft:prismarine_bricks
fill 189 233 304 189 234 304 minecraft:prismarine_bricks
fill 189 233 317 190 245 317 minecraft:prismarine
fill 190 233 295 190 234 295 minecraft:quartz_pillar
fill 190 233 297 190 234 297 minecraft:quartz_pillar
fill 190 233 299 190 234 299 minecraft:prismarine_bricks
fill 190 233 301 190 234 301 minecraft:prismarine_bricks
fill 190 233 303 190 234 303 minecraft:prismarine_bricks
fill 191 233 294 191 234 294 minecraft:prismarine_bricks
fill 191 233 296 191 234 296 minecraft:quartz_pillar
fill 191 233 298 191 234 298 minecraft:prismarine_bricks
fill 191 233 300 191 234 300 minecraft:prismarine_bricks
fill 191 233 302 191 234 302 minecraft:prismarine_bricks
fill 191 233 304 191 234 304 minecraft:prismarine_bricks
fill 192 233 295 192 234 295 minecraft:quartz_pillar
fill 192 233 297 192 234 297 minecraft:quartz_pillar
fill 192 233 299 192 234 299 minecraft:prismarine_bricks
fill 192 233 301 192 234 301 minecraft:prismarine_bricks
fill 192 233 303 192 234 303 minecraft:prismarine_bricks
fill 193 233 294 193 234 294 minecraft:prismarine_bricks
fill 193 233 296 193 234 296 minecraft:prismarine_bricks
fill 193 233 298 193 234 298 minecraft:prismarine_bricks
fill 193 233 300 193 234 300 minecraft:prismarine_bricks
fill 193 233 302 193 234 302 minecraft:prismarine_bricks
fill 193 233 304 193 234 304 minecraft:prismarine_bricks
fill 196 233 275 197 245 275 minecraft:prismarine
fill 197 233 317 197 262 317 minecraft:prismarine
fill 201 233 317 202 245 317 minecraft:prismarine
fill 202 233 311 202 234 311 minecraft:prismarine_bricks
fill 202 233 313 202 234 313 minecraft:prismarine_bricks
fill 202 233 315 202 234 315 minecraft:prismarine_bricks
fill 203 233 310 203 234 310 minecraft:prismarine_bricks
fill 203 233 312 203 234 312 minecraft:prismarine_bricks
fill 203 233 314 203 234 314 minecraft:prismarine_bricks
fill 203 233 316 203 234 316 minecraft:prismarine_bricks
fill 204 233 311 204 234 311 minecraft:prismarine_bricks
fill 204 233 313 204 234 313 minecraft:prismarine_bricks
fill 204 233 315 204 234 315 minecraft:prismarine_bricks
fill 205 233 310 205 234 310 minecraft:prismarine_bricks
fill 205 233 312 205 234 312 minecraft:prismarine_bricks
fill 205 233 314 205 234 314 minecraft:prismarine_bricks
fill 205 233 316 205 234 316 minecraft:prismarine_bricks
fill 206 233 311 206 234 311 minecraft:prismarine_bricks
fill 206 233 313 206 234 313 minecraft:prismarine_bricks
fill 206 233 315 206 234 315 minecraft:prismarine_bricks
fill 207 233 310 207 234 310 minecraft:prismarine_bricks
fill 207 233 312 207 234 312 minecraft:prismarine_bricks
fill 207 233 314 207 234 314 minecraft:prismarine_bricks
fill 207 233 316 207 234 316 minecraft:prismarine_bricks
fill 208 233 275 209 245 275 minecraft:prismarine
fill 208 233 311 208 234 311 minecraft:prismarine_bricks
fill 208 233 313 208 234 313 minecraft:quartz_pillar
fill 208 233 315 208 234 315 minecraft:quartz_pillar
fill 209 233 310 209 234 310 minecraft:prismarine_bricks
fill 209 233 312 209 234 312 minecraft:prismarine_bricks
fill 209 233 314 209 234 314 minecraft:quartz_pillar
fill 209 233 316 209 234 316 minecraft:prismarine_bricks
fill 210 233 311 210 234 311 minecraft:prismarine_bricks
fill 210 233 313 210 234 313 minecraft:quartz_pillar
fill 210 233 315 210 234 315 minecraft:quartz_pillar
fill 213 233 317 214 237 317 minecraft:prismarine
fill 220 233 275 221 235 275 minecraft:prismarine
fill 220 233 278 220 234 282 minecraft:dark_prismarine
fill 221 233 276 221 234 276 minecraft:prismarine_bricks
fill 221 233 278 221 234 278 minecraft:prismarine_bricks
fill 221 233 280 221 234 280 minecraft:prismarine_bricks
fill 221 233 282 221 234 282 minecraft:prismarine_bricks
fill 221 233 284 221 234 284 minecraft:prismarine_bricks
fill 221 233 286 221 234 286 minecraft:prismarine_bricks
fill 222 233 277 222 234 277 minecraft:prismarine_bricks
fill 222 233 279 222 234 279 minecraft:prismarine_bricks
fill 222 233 281 222 234 281 minecraft:prismarine_bricks
fill 222 233 283 222 234 283 minecraft:prismarine_bricks
fill 222 233 285 222 234 285 minecraft:prismarine_bricks
fill 222 233 301 222 234 301 minecraft:prismarine_bricks
fill 222 233 303 222 234 303 minecraft:prismarine_bricks
fill 222 233 305 222 234 305 minecraft:prismarine_bricks
fill 222 233 307 222 234 307 minecraft:prismarine_bricks
fill 222 233 309 222 234 309 minecraft:prismarine_bricks
fill 223 233 275 223 308 275 minecraft:prismarine
fill 223 233 276 223 234 276 minecraft:prismarine_bricks
fill 223 233 278 223 234 278 minecraft:prismarine_bricks
fill 223 233 280 223 234 280 minecraft:prismarine_bricks
fill 223 233 282 223 234 282 minecraft:prismarine_bricks
fill 223 233 284 223 234 284 minecraft:prismarine_bricks
fill 223 233 286 223 234 286 minecraft:prismarine_bricks
fill 223 233 302 223 234 302 minecraft:prismarine_bricks
fill 223 233 304 223 234 304 minecraft:prismarine_bricks
fill 223 233 306 223 234 306 minecraft:prismarine_bricks
fill 223 233 308 223 234 308 minecraft:prismarine_bricks
fill 224 233 277 224 234 277 minecraft:prismarine_bricks
fill 224 233 279 224 234 279 minecraft:prismarine_bricks
fill 224 233 281 224 234 281 minecraft:prismarine_bricks
fill 224 233 283 224 234 283 minecraft:prismarine_bricks
fill 224 233 285 224 234 285 minecraft:prismarine_bricks
fill 224 233 301 224 234 301 minecraft:prismarine_bricks
fill 224 233 303 224 234 303 minecraft:prismarine_bricks
fill 224 233 305 224 234 305 minecraft:prismarine_bricks
fill 224 233 307 224 234 307 minecraft:prismarine_bricks
fill 224 233 309 224 234 309 minecraft:prismarine_bricks
fill 225 233 276 225 234 276 minecraft:prismarine_bricks
fill 225 233 278 225 234 278 minecraft:quartz_pillar
fill 225 233 280 225 234 280 minecraft:quartz_pillar
fill 225 233 282 225 234 282 minecraft:prismarine_bricks
fill 225 233 284 225 234 284 minecraft:prismarine_bricks
fill 225 233 286 225 234 286 minecraft:prismarine_bricks
fill 225 233 302 225 234 302 minecraft:prismarine_bricks
fill 225 233 304 225 234 304 minecraft:prismarine_bricks
fill 225 233 306 225 234 306 minecraft:prismarine_bricks
fill 225 233 308 225 234 308 minecraft:prismarine_bricks
fill 225 233 317 226 245 317 minecraft:prismarine
fill 226 233 277 226 234 277 minecraft:prismarine_bricks
fill 226 233 279 226 234 279 minecraft:quartz_pillar
fill 226 233 281 226 234 281 minecraft:prismarine_bricks
fill 226 233 283 226 234 283 minecraft:prismarine_bricks
fill 226 233 285 226 234 285 minecraft:prismarine_bricks
fill 226 233 301 226 234 301 minecraft:prismarine_bricks
fill 226 233 303 226 234 303 minecraft:prismarine_bricks
fill 226 233 305 226 234 305 minecraft:prismarine_bricks
fill 226 233 307 226 234 307 minecraft:prismarine_bricks
fill 226 233 309 226 234 309 minecraft:prismarine_bricks
fill 227 233 276 227 234 276 minecraft:prismarine_bricks
fill 227 233 278 227 234 278 minecraft:quartz_pillar
fill 227 233 280 227 234 280 minecraft:quartz_pillar
fill 227 233 282 227 234 282 minecraft:prismarine_bricks
fill 227 233 284 227 234 284 minecraft:prismarine_bricks
fill 227 233 286 227 234 286 minecraft:prismarine_bricks
fill 227 233 302 227 234 302 minecraft:prismarine_bricks
fill 227 233 304 227 234 304 minecraft:prismarine_bricks
fill 227 233 306 227 234 306 minecraft:prismarine_bricks
fill 227 233 308 227 234 308 minecraft:prismarine_bricks
fill 228 233 275 228 308 275 minecraft:prismarine
fill 228 233 277 228 234 277 minecraft:prismarine_bricks
fill 228 233 279 228 234 279 minecraft:prismarine_bricks
fill 228 233 281 228 234 281 minecraft:prismarine_bricks
fill 228 233 283 228 234 283 minecraft:prismarine_bricks
fill 228 233 285 228 234 285 minecraft:prismarine_bricks
fill 228 233 301 228 234 301 minecraft:prismarine_bricks
fill 228 233 303 228 234 303 minecraft:prismarine_bricks
fill 228 233 305 228 234 305 minecraft:prismarine_bricks
fill 228 233 307 228 234 307 minecraft:prismarine_bricks
fill 228 233 309 228 234 309 minecraft:prismarine_bricks
fill 229 233 275 229 233 276 minecraft:prismarine_bricks
fill 229 233 278 229 234 278 minecraft:prismarine_bricks
fill 229 233 280 229 234 280 minecraft:prismarine_bricks
fill 229 233 282 229 234 282 minecraft:prismarine_bricks
fill 229 233 284 229 234 284 minecraft:prismarine_bricks
fill 229 233 286 229 234 286 minecraft:prismarine_bricks
fill 229 233 302 229 234 302 minecraft:prismarine_bricks
fill 229 233 304 229 234 304 minecraft:prismarine_bricks
fill 229 233 306 229 234 306 minecraft:prismarine_bricks
fill 229 233 308 229 234 308 minecraft:prismarine_bricks
fill 230 233 275 230 308 275 minecraft:prismarine
fill 230 233 277 230 245 278 minecraft:prismarine
fill 230 233 289 230 245 290 minecraft:prismarine
fill 230 233 301 230 245 302 minecraft:prismarine
fill 230 233 313 230 245 314 minecraft:prismarine
setblock 188 234 282 minecraft:sea_lantern
fill 188 234 283 188 245 283 minecraft:prismarine
setblock 211 234 275 minecraft:prismarine_bricks
fill 229 234 275 229 284 275 minecraft:prismarine
setblock 229 234 276 minecraft:prismarine_bricks
fill 188 235 275 192 264 275 minecraft:prismarine
fill 188 235 282 188 239 282 minecraft:prismarine
setblock 189 235 294 minecraft:sea_lantern
setblock 189 235 296 minecraft:sea_lantern
setblock 189 235 298 minecraft:sea_lantern
setblock 189 235 300 minecraft:sea_lantern
setblock 189 235 302 minecraft:sea_lantern
setblock 189 235 304 minecraft:sea_lantern
setblock 190 235 295 minecraft:sea_lantern
setblock 190 235 297 minecraft:sea_lantern
setblock 190 235 299 minecraft:sea_lantern
setblock 190 235 301 minecraft:sea_lantern
setblock 190 235 303 minecraft:sea_lantern
setblock 191 235 294 minecraft:sea_lantern
setblock 191 235 296 minecraft:sea_lantern
setblock 191 235 298 minecraft:sea_lantern
setblock 191 235 300 minecraft:sea_lantern
setblock 191 235 302 minecraft:sea_lantern
setblock 191 235 304 minecraft:sea_lantern
setblock 192 235 295 minecraft:sea_lantern
setblock 192 235 297 minecraft:sea_lantern
setblock 192 235 299 minecraft:sea_lantern
setblock 192 235 301 minecraft:sea_lantern
setblock 192 235 303 minecraft:sea_lantern
setblock 193 235 275 minecraft:prismarine_bricks
setblock 193 235 294 minecraft:sea_lantern
setblock 193 235 296 minecraft:sea_lantern
setblock 193 235 298 minecraft:sea_lantern
setblock 193 235 300 minecraft:sea_lantern
setblock 193 235 302 minecraft:sea_lantern
setblock 193 235 304 minecraft:sea_lantern
setblock 202 235 311 minecraft:sea_lantern
setblock 202 235 313 minecraft:sea_lantern
setblock 202 235 315 minecraft:sea_lantern
setblock 203 235 310 minecraft:sea_lantern
setblock 203 235 312 minecraft:sea_lantern
setblock 203 235 314 minecraft:sea_lantern
setblock 203 235 316 minecraft:sea_lantern
setblock 204 235 311 minecraft:sea_lantern
setblock 204 235 313 minecraft:sea_lantern
setblock 204 235 315 minecraft:sea_lantern
setblock 205 235 310 minecraft:sea_lantern
setblock 205 235 312 minecraft:sea_lantern
setblock 205 235 314 minecraft:sea_lantern
setblock 205 235 316 minecraft:sea_lantern
setblock 206 235 311 minecraft:sea_lantern
setblock 206 235 313 minecraft:sea_lantern
setblock 206 235 315 minecraft:sea_lantern
setblock 207 235 310 minecraft:sea_lantern
setblock 207 235 312 minecraft:sea_lantern
setblock 207 235 314 minecraft:sea_lantern
setblock 207 235 316 minecraft:sea_lantern
setblock 208 235 311 minecraft:sea_lantern
setblock 208 235 313 minecraft:sea_lantern
setblock 208 235 315 minecraft:sea_lantern
setblock 209 235 310 minecraft:sea_lantern
setblock 209 235 312 minecraft:sea_lantern
setblock 209 235 314 minecraft:sea_lantern
setblock 209 235 316 minecraft:sea_lantern
setblock 210 235 311 minecraft:sea_lantern
setblock 210 235 313 minecraft:sea_lantern
setblock 210 235 315 minecraft:sea_lantern
fill 211 235 275 211 308 275 minecraft:prismarine
setblock 221 235 276 minecraft:sea_lantern
setblock 221 235 278 minecraft:sea_lantern
setblock 221 235 280 minecraft:sea_lantern
setblock 221 235 282 minecraft:sea_lantern
setblock 221 235 284 minecraft:sea_lantern
setblock 221 235 286 minecraft:sea_lantern
setblock 222 235 277 minecraft:sea_lantern
setblock 222 235 279 minecraft:sea_lantern
setblock 222 235 281 minecraft:sea_lantern
setblock 222 235 283 minecraft:sea_lantern
setblock 222 235 285 minecraft:sea_lantern
setblock 222 235 301 minecraft:sea_lantern
setblock 222 235 303 minecraft:sea_lantern
setblock 222 235 305 minecraft:sea_lantern
setblock 222 235 307 minecraft:sea_lantern
setblock 222 235 309 minecraft:sea_lantern
setblock 223 235 276 minecraft:sea_lantern
setblock 223 235 278 minecraft:sea_lantern
setblock 223 235 280 minecraft:sea_lantern
setblock 223 235 282 minecraft:sea_lantern
setblock 223 235 284 minecraft:sea_lantern
setblock 223 235 286 minecraft:sea_lantern
setblock 223 235 302 minecraft:sea_lantern
setblock 223 235 304 minecraft:sea_lantern
setblock 223 235 306 minecraft:sea_lantern
setblock 223 235 308 minecraft:sea_lantern
setblock 224 235 277 minecraft:sea_lantern
setblock 224 235 279 minecraft:sea_lantern
setblock 224 235 281 minecraft:sea_lantern
setblock 224 235 283 minecraft:sea_lantern
setblock 224 235 285 minecraft:sea_lantern
setblock 224 235 301 minecraft:sea_lantern
setblock 224 235 303 minecraft:sea_lantern
setblock 224 235 305 minecraft:sea_lantern
setblock 224 235 307 minecraft:sea_lantern
setblock 224 235 309 minecraft:sea_lantern
setblock 225 235 276 minecraft:sea_lantern
setblock 225 235 278 minecraft:sea_lantern
setblock 225 235 280 minecraft:sea_lantern
setblock 225 235 282 minecraft:sea_lantern
setblock 225 235 284 minecraft:sea_lantern
setblock 225 235 286 minecraft:sea_lantern
setblock 225 235 302 minecraft:sea_lantern
setblock 225 235 304 minecraft:sea_lantern
setblock 225 235 306 minecraft:sea_lantern
setblock 225 235 308 minecraft:sea_lantern
setblock 226 235 277 minecraft:sea_lantern
setblock 226 235 279 minecraft:sea_lantern
setblock 226 235 281 minecraft:sea_lantern
setblock 226 235 283 minecraft:sea_lantern
setblock 226 235 285 minecraft:sea_lantern
setblock 226 235 301 minecraft:sea_lantern
setblock 226 235 303 minecraft:sea_lantern
setblock 226 235 305 minecraft:sea_lantern
setblock 226 235 307 minecraft:sea_lantern
setblock 226 235 309 minecraft:sea_lantern
setblock 227 235 276 minecraft:sea_lantern
setblock 227 235 278 minecraft:sea_lantern
setblock 227 235 280 minecraft:sea_lantern
setblock 227 235 282 minecraft:sea_lantern
setblock 227 235 284 minecraft:sea_lantern
setblock 227 235 286 minecraft:sea_lantern
setblock 227 235 302 minecraft:sea_lantern
setblock 227 235 304 minecraft:sea_lantern
setblock 227 235 306 minecraft:sea_lantern
setblock 227 235 308 minecraft:sea_lantern
setblock 228 235 277 minecraft:sea_lantern
setblock 228 235 279 minecraft:sea_lantern
setblock 228 235 281 minecraft:sea_lantern
setblock 228 235 283 minecraft:sea_lantern
setblock 228 235 285 minecraft:sea_lantern
setblock 228 235 301 minecraft:sea_lantern
setblock 228 235 303 minecraft:sea_lantern
setblock 228 235 305 minecraft:sea_lantern
setblock 228 235 307 minecraft:sea_lantern
setblock 228 235 309 minecraft:sea_lantern
setblock 229 235 276 minecraft:sea_lantern
setblock 229 235 278 minecraft:sea_lantern
setblock 229 235 280 minecraft:sea_lantern
setblock 229 235 282 minecraft:sea_lantern
setblock 229 235 284 minecraft:sea_lantern
setblock 229 235 286 minecraft:sea_lantern
setblock 229 235 302 minecraft:sea_lantern
setblock 229 235 304 minecraft:sea_lantern
setblock 229 235 306 minecraft:sea_lantern
setblock 229 235 308 minecraft:sea_lantern
fill 189 236 294 189 237 294 minecraft:prismarine_bricks
fill 189 236 296 189 237 296 minecraft:prismarine_bricks
fill 189 236 298 189 237 298 minecraft:prismarine_bricks
fill 189 236 300 189 237 300 minecraft:prismarine_bricks
fill 189 236 302 189 237 302 minecraft:prismarine_bricks
fill 189 236 304 189 237 304 minecraft:prismarine_bricks
fill 190 236 295 190 237 295 minecraft:quartz_pillar
fill 190 236 297 190 237 297 minecraft:quartz_pillar
fill 190 236 299 190 237 299 minecraft:prismarine_bricks
schedule function dropper:buildpart/64_3 1t
