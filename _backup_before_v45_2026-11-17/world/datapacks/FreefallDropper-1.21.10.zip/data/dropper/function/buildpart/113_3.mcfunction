setblock 269 91 502 minecraft:bone_block
fill 269 91 503 269 93 503 minecraft:brown_terracotta
setblock 270 91 466 minecraft:light[level=12]
setblock 270 91 474 minecraft:light[level=12]
setblock 270 91 482 minecraft:light[level=12]
setblock 270 91 498 minecraft:light[level=12]
fill 270 91 502 273 91 502 minecraft:brown_terracotta
setblock 272 91 464 minecraft:bone_block
setblock 272 91 504 minecraft:bone_block
fill 273 91 464 273 93 464 minecraft:brown_terracotta
setblock 273 91 492 minecraft:brown_terracotta
setblock 273 91 493 minecraft:bone_block
fill 273 91 494 273 93 494 minecraft:brown_terracotta
setblock 273 91 497 minecraft:brown_terracotta
setblock 273 91 498 minecraft:bone_block
fill 273 91 499 273 93 499 minecraft:brown_terracotta
setblock 273 91 503 minecraft:bone_block
fill 273 91 504 273 93 504 minecraft:brown_terracotta
setblock 274 91 488 minecraft:soul_soil
setblock 274 91 492 minecraft:bone_block
fill 274 91 493 274 93 493 minecraft:brown_terracotta
setblock 274 91 497 minecraft:bone_block
fill 274 91 498 274 93 498 minecraft:brown_terracotta
setblock 274 91 501 minecraft:brown_terracotta
fill 274 91 503 275 93 503 minecraft:brown_terracotta
setblock 275 91 471 minecraft:bone_block
fill 275 91 472 275 92 472 minecraft:brown_terracotta
setblock 275 91 475 minecraft:brown_terracotta
setblock 275 91 476 minecraft:bone_block
setblock 275 91 491 minecraft:bone_block
fill 275 91 492 275 93 492 minecraft:brown_terracotta
setblock 275 91 496 minecraft:bone_block
fill 275 91 497 275 93 497 minecraft:brown_terracotta
setblock 275 91 501 minecraft:bone_block
fill 275 91 502 275 93 502 minecraft:brown_terracotta
setblock 276 91 470 minecraft:bone_block
fill 276 91 471 276 93 471 minecraft:brown_terracotta
setblock 276 91 475 minecraft:bone_block
fill 276 91 476 276 93 476 minecraft:brown_terracotta
setblock 276 91 479 minecraft:brown_terracotta
setblock 276 91 480 minecraft:bone_block
setblock 276 91 485 minecraft:bone_block
fill 276 91 486 276 93 486 minecraft:brown_terracotta
setblock 276 91 490 minecraft:bone_block
fill 276 91 491 276 93 491 minecraft:brown_terracotta
setblock 276 91 495 minecraft:bone_block
fill 276 91 496 276 93 496 minecraft:brown_terracotta
setblock 276 91 500 minecraft:bone_block
fill 276 91 501 276 93 501 minecraft:brown_terracotta
setblock 236 92 469 minecraft:bone_block
fill 236 92 470 236 92 473 minecraft:brown_terracotta
setblock 236 92 474 minecraft:bone_block
fill 236 92 475 236 93 475 minecraft:brown_terracotta
setblock 236 92 479 minecraft:bone_block
fill 236 92 480 237 93 480 minecraft:brown_terracotta
setblock 236 92 484 minecraft:bone_block
fill 236 92 485 236 93 485 minecraft:brown_terracotta
setblock 236 92 489 minecraft:bone_block
fill 236 92 490 236 93 490 minecraft:brown_terracotta
setblock 236 92 494 minecraft:bone_block
fill 236 92 495 236 93 495 minecraft:brown_terracotta
setblock 236 92 499 minecraft:bone_block
fill 236 92 500 236 93 500 minecraft:brown_terracotta
setblock 237 92 473 minecraft:bone_block
fill 237 92 474 237 93 474 minecraft:brown_terracotta
setblock 237 92 478 minecraft:bone_block
fill 237 92 479 237 93 479 minecraft:brown_terracotta
setblock 237 92 489 minecraft:brown_terracotta
setblock 237 92 493 minecraft:bone_block
fill 237 92 494 237 93 494 minecraft:brown_terracotta
setblock 237 92 498 minecraft:bone_block
fill 246 92 482 247 93 483 minecraft:soul_soil
fill 247 92 464 247 93 464 minecraft:brown_terracotta
fill 248 92 465 248 93 465 minecraft:brown_terracotta
fill 249 92 504 250 92 504 minecraft:brown_terracotta
setblock 250 92 464 minecraft:brown_terracotta
setblock 250 92 465 minecraft:bone_block
setblock 251 92 464 minecraft:bone_block
fill 251 92 465 251 93 465 minecraft:brown_terracotta
setblock 251 92 504 minecraft:bone_block
fill 252 92 464 252 93 464 minecraft:brown_terracotta
fill 252 92 504 252 93 504 minecraft:brown_terracotta
setblock 255 92 465 minecraft:bone_block
setblock 256 92 464 minecraft:bone_block
setblock 256 92 465 minecraft:brown_terracotta
setblock 256 92 504 minecraft:bone_block
fill 257 92 464 257 93 464 minecraft:brown_terracotta
fill 257 92 504 257 93 504 minecraft:brown_terracotta
fill 263 92 504 265 92 504 minecraft:brown_terracotta
setblock 265 92 464 minecraft:brown_terracotta
fill 265 92 503 266 92 503 minecraft:brown_terracotta
setblock 266 92 464 minecraft:bone_block
setblock 266 92 504 minecraft:bone_block
fill 267 92 464 267 93 464 minecraft:brown_terracotta
setblock 267 92 502 minecraft:brown_terracotta
setblock 267 92 503 minecraft:bone_block
fill 267 92 504 267 93 504 minecraft:brown_terracotta
setblock 268 92 502 minecraft:bone_block
fill 268 92 503 268 93 503 minecraft:brown_terracotta
fill 269 92 502 272 92 502 minecraft:brown_terracotta
fill 270 92 501 272 93 501 minecraft:brown_terracotta
setblock 271 92 464 minecraft:bone_block
setblock 271 92 504 minecraft:bone_block
fill 272 92 464 272 93 464 minecraft:brown_terracotta
fill 272 92 495 272 92 497 minecraft:brown_terracotta
setblock 272 92 503 minecraft:bone_block
fill 272 92 504 272 93 504 minecraft:brown_terracotta
setblock 273 92 492 minecraft:bone_block
fill 273 92 493 273 93 493 minecraft:brown_terracotta
setblock 273 92 497 minecraft:bone_block
fill 273 92 498 273 93 498 minecraft:brown_terracotta
fill 273 92 500 273 93 500 minecraft:brown_terracotta
setblock 273 92 502 minecraft:bone_block
fill 273 92 503 273 93 503 minecraft:brown_terracotta
setblock 274 92 491 minecraft:bone_block
fill 274 92 492 274 93 492 minecraft:brown_terracotta
setblock 274 92 496 minecraft:bone_block
fill 274 92 497 274 93 497 minecraft:brown_terracotta
setblock 274 92 501 minecraft:bone_block
fill 274 92 502 274 93 502 minecraft:brown_terracotta
setblock 275 92 475 minecraft:bone_block
fill 275 92 476 275 93 478 minecraft:brown_terracotta
setblock 275 92 490 minecraft:bone_block
fill 275 92 491 275 93 491 minecraft:brown_terracotta
setblock 275 92 495 minecraft:bone_block
fill 275 92 496 275 93 496 minecraft:brown_terracotta
setblock 275 92 500 minecraft:bone_block
fill 275 92 501 275 93 501 minecraft:brown_terracotta
setblock 276 92 469 minecraft:bone_block
fill 276 92 470 276 93 470 minecraft:brown_terracotta
setblock 276 92 474 minecraft:bone_block
fill 276 92 475 276 93 475 minecraft:brown_terracotta
setblock 276 92 479 minecraft:bone_block
fill 276 92 480 276 92 483 minecraft:brown_terracotta
setblock 276 92 484 minecraft:bone_block
fill 276 92 485 276 93 485 minecraft:brown_terracotta
setblock 276 92 489 minecraft:bone_block
fill 276 92 490 276 93 490 minecraft:brown_terracotta
setblock 276 92 494 minecraft:bone_block
fill 276 92 495 276 93 495 minecraft:brown_terracotta
setblock 276 92 499 minecraft:bone_block
fill 276 92 500 276 93 500 minecraft:brown_terracotta
setblock 276 92 504 minecraft:bone_block
fill 236 93 469 236 93 472 minecraft:brown_terracotta
setblock 236 93 473 minecraft:bone_block
setblock 236 93 474 minecraft:brown_terracotta
setblock 236 93 477 minecraft:brown_terracotta
setblock 236 93 478 minecraft:bone_block
setblock 236 93 479 minecraft:brown_terracotta
setblock 236 93 483 minecraft:bone_block
setblock 236 93 484 minecraft:brown_terracotta
setblock 236 93 488 minecraft:bone_block
setblock 236 93 489 minecraft:brown_terracotta
setblock 236 93 493 minecraft:bone_block
setblock 236 93 494 minecraft:brown_terracotta
setblock 236 93 498 minecraft:bone_block
setblock 236 93 499 minecraft:brown_terracotta
setblock 236 93 502 minecraft:brown_terracotta
setblock 237 93 472 minecraft:bone_block
setblock 237 93 473 minecraft:brown_terracotta
setblock 237 93 477 minecraft:bone_block
setblock 237 93 478 minecraft:brown_terracotta
setblock 237 93 481 minecraft:brown_terracotta
setblock 237 93 492 minecraft:bone_block
setblock 237 93 493 minecraft:brown_terracotta
setblock 237 93 497 minecraft:bone_block
setblock 237 93 498 minecraft:brown_terracotta
setblock 246 93 464 minecraft:brown_terracotta
fill 247 93 504 249 93 504 minecraft:brown_terracotta
setblock 249 93 465 minecraft:bone_block
setblock 250 93 464 minecraft:bone_block
fill 250 93 465 250 93 466 minecraft:brown_terracotta
setblock 250 93 503 minecraft:brown_terracotta
setblock 250 93 504 minecraft:bone_block
setblock 251 93 464 minecraft:brown_terracotta
setblock 251 93 503 minecraft:bone_block
setblock 251 93 504 minecraft:brown_terracotta
fill 252 93 503 254 93 503 minecraft:brown_terracotta
setblock 254 93 465 minecraft:bone_block
setblock 255 93 464 minecraft:bone_block
setblock 255 93 465 minecraft:brown_terracotta
setblock 255 93 504 minecraft:bone_block
setblock 256 93 464 minecraft:brown_terracotta
setblock 256 93 504 minecraft:brown_terracotta
fill 258 93 504 259 93 504 minecraft:brown_terracotta
setblock 260 93 504 minecraft:bone_block
fill 261 93 504 264 93 504 minecraft:brown_terracotta
fill 263 93 464 264 93 464 minecraft:brown_terracotta
fill 264 93 503 265 93 503 minecraft:brown_terracotta
setblock 265 93 464 minecraft:bone_block
setblock 265 93 504 minecraft:bone_block
setblock 266 93 464 minecraft:brown_terracotta
setblock 266 93 502 minecraft:brown_terracotta
setblock 266 93 503 minecraft:bone_block
setblock 266 93 504 minecraft:brown_terracotta
fill 267 93 487 269 93 487 minecraft:bone_block
fill 267 93 489 269 93 489 minecraft:bone_block
setblock 267 93 502 minecraft:bone_block
setblock 267 93 503 minecraft:brown_terracotta
setblock 268 93 488 minecraft:bone_block
setblock 268 93 501 minecraft:bone_block
fill 268 93 502 271 93 502 minecraft:brown_terracotta
setblock 269 93 501 minecraft:brown_terracotta
setblock 270 93 464 minecraft:bone_block
setblock 270 93 504 minecraft:bone_block
setblock 271 93 464 minecraft:brown_terracotta
setblock 271 93 503 minecraft:bone_block
setblock 271 93 504 minecraft:brown_terracotta
fill 272 93 495 272 93 496 minecraft:brown_terracotta
setblock 272 93 497 minecraft:bone_block
setblock 272 93 498 minecraft:brown_terracotta
setblock 272 93 502 minecraft:bone_block
setblock 272 93 503 minecraft:brown_terracotta
setblock 273 93 492 minecraft:brown_terracotta
setblock 273 93 496 minecraft:bone_block
setblock 273 93 497 minecraft:brown_terracotta
setblock 273 93 501 minecraft:bone_block
setblock 273 93 502 minecraft:brown_terracotta
setblock 274 93 490 minecraft:bone_block
setblock 274 93 491 minecraft:brown_terracotta
setblock 274 93 495 minecraft:bone_block
setblock 274 93 496 minecraft:brown_terracotta
setblock 274 93 499 minecraft:brown_terracotta
setblock 274 93 500 minecraft:bone_block
setblock 274 93 501 minecraft:brown_terracotta
setblock 275 93 473 minecraft:brown_terracotta
setblock 275 93 474 minecraft:bone_block
setblock 275 93 475 minecraft:brown_terracotta
setblock 275 93 479 minecraft:bone_block
setblock 275 93 489 minecraft:bone_block
setblock 275 93 490 minecraft:brown_terracotta
setblock 275 93 494 minecraft:bone_block
setblock 275 93 495 minecraft:brown_terracotta
setblock 275 93 499 minecraft:bone_block
setblock 275 93 500 minecraft:brown_terracotta
setblock 275 93 504 minecraft:bone_block
setblock 276 93 473 minecraft:bone_block
setblock 276 93 474 minecraft:brown_terracotta
setblock 276 93 477 minecraft:brown_terracotta
setblock 276 93 478 minecraft:bone_block
fill 276 93 479 276 93 482 minecraft:brown_terracotta
setblock 276 93 483 minecraft:bone_block
setblock 276 93 484 minecraft:brown_terracotta
setblock 276 93 488 minecraft:bone_block
setblock 276 93 489 minecraft:brown_terracotta
setblock 276 93 493 minecraft:bone_block
setblock 276 93 494 minecraft:brown_terracotta
setblock 276 93 498 minecraft:bone_block
setblock 276 93 499 minecraft:brown_terracotta
setblock 276 93 503 minecraft:bone_block
setblock 276 93 504 minecraft:brown_terracotta
fill 249 98 479 251 98 481 minecraft:redstone_block
fill 249 98 485 251 98 487 minecraft:redstone_block
fill 256 98 486 258 98 488 minecraft:redstone_block
fill 257 98 479 259 98 481 minecraft:redstone_block
fill 235 99 463 235 104 482 minecraft:black_concrete
fill 235 99 483 252 99 483 minecraft:bone_block
fill 235 99 484 235 104 505 minecraft:black_concrete
fill 236 99 477 248 99 482 minecraft:bone_block
fill 236 99 484 248 99 489 minecraft:bone_block
fill 237 99 475 271 99 476 minecraft:bone_block
fill 237 99 490 271 99 491 minecraft:bone_block
setblock 238 99 466 minecraft:light[level=12]
fill 238 99 473 270 99 474 minecraft:bone_block
fill 238 99 492 270 99 493 minecraft:bone_block
setblock 238 99 498 minecraft:light[level=12]
fill 239 99 472 269 99 472 minecraft:bone_block
fill 239 99 494 269 99 494 minecraft:bone_block
fill 240 99 471 268 99 471 minecraft:bone_block
fill 240 99 495 268 99 495 minecraft:bone_block
fill 241 99 470 267 99 470 minecraft:bone_block
fill 241 99 496 267 99 496 minecraft:bone_block
fill 242 99 469 266 99 469 minecraft:bone_block
fill 242 99 497 266 99 497 minecraft:bone_block
fill 243 99 468 265 99 468 minecraft:bone_block
fill 243 99 498 265 99 498 minecraft:bone_block
fill 244 99 467 264 99 467 minecraft:bone_block
fill 244 99 499 264 99 499 minecraft:bone_block
fill 246 99 466 262 99 466 minecraft:bone_block
fill 246 99 500 262 99 500 minecraft:bone_block
fill 248 99 465 260 99 465 minecraft:bone_block
fill 248 99 501 260 99 501 minecraft:bone_block
fill 249 99 477 272 99 478 minecraft:bone_block
fill 249 99 482 252 99 482 minecraft:bone_block
fill 249 99 484 252 99 484 minecraft:bone_block
fill 249 99 488 255 99 489 minecraft:bone_block
fill 252 99 479 256 99 481 minecraft:bone_block
fill 252 99 485 255 99 487 minecraft:bone_block
fill 254 99 464 254 106 464 minecraft:bone_block
fill 254 99 502 254 106 502 minecraft:bone_block
fill 256 99 482 272 99 485 minecraft:bone_block
fill 256 99 489 272 99 489 minecraft:bone_block
fill 259 99 486 272 99 488 minecraft:bone_block
fill 260 99 479 272 99 481 minecraft:bone_block
setblock 270 99 466 minecraft:light[level=12]
setblock 270 99 498 minecraft:light[level=12]
fill 273 99 483 273 106 483 minecraft:bone_block
fill 235 100 483 249 101 483 minecraft:bone_block
fill 236 100 464 236 100 476 minecraft:black_concrete
fill 236 100 477 236 106 480 minecraft:bone_block
fill 236 100 481 236 106 481 minecraft:soul_soil
fill 236 100 482 246 103 482 minecraft:bone_block
fill 236 100 484 236 106 489 minecraft:bone_block
fill 236 100 490 236 100 504 minecraft:black_concrete
fill 237 100 464 237 100 474 minecraft:black_concrete
fill 237 100 475 239 106 479 minecraft:bone_block
fill 237 100 480 238 106 480 minecraft:soul_soil
fill 237 100 481 247 102 481 minecraft:bone_block
fill 237 100 484 237 106 488 minecraft:bone_block
fill 237 100 489 237 106 489 minecraft:soul_soil
fill 237 100 490 242 105 491 minecraft:bone_block
fill 237 100 492 237 100 504 minecraft:black_concrete
fill 238 100 464 238 100 472 minecraft:black_concrete
fill 238 100 473 238 106 474 minecraft:bone_block
fill 238 100 484 238 106 486 minecraft:bone_block
fill 238 100 487 238 106 487 minecraft:soul_soil
fill 238 100 488 243 105 489 minecraft:bone_block
fill 238 100 492 241 106 493 minecraft:bone_block
fill 238 100 494 238 100 504 minecraft:black_concrete
fill 239 100 464 239 100 471 minecraft:black_concrete
fill 239 100 472 250 104 472 minecraft:bone_block
fill 239 100 473 241 106 473 minecraft:soul_soil
fill 239 100 474 244 105 474 minecraft:bone_block
fill 239 100 480 247 103 480 minecraft:bone_block
fill 239 100 484 239 106 485 minecraft:bone_block
fill 239 100 486 239 106 486 minecraft:soul_soil
fill 239 100 487 244 104 487 minecraft:bone_block
fill 239 100 494 246 105 494 minecraft:bone_block
fill 239 100 495 239 100 504 minecraft:black_concrete
fill 240 100 464 240 100 470 minecraft:black_concrete
fill 240 100 471 249 105 471 minecraft:bone_block
fill 240 100 475 247 103 478 minecraft:bone_block
fill 240 100 479 241 105 479 minecraft:soul_soil
fill 240 100 484 241 105 484 minecraft:bone_block
fill 240 100 485 240 105 485 minecraft:soul_soil
fill 240 100 486 245 103 486 minecraft:bone_block
fill 240 100 495 240 106 495 minecraft:bone_block
fill 240 100 496 240 100 504 minecraft:black_concrete
fill 241 100 464 241 100 469 minecraft:black_concrete
fill 241 100 470 248 105 470 minecraft:bone_block
fill 241 100 485 247 102 485 minecraft:bone_block
fill 241 100 495 241 106 496 minecraft:soul_soil
fill 241 100 497 241 100 504 minecraft:black_concrete
fill 242 100 464 242 100 468 minecraft:black_concrete
fill 242 100 469 254 105 469 minecraft:bone_block
fill 242 100 473 251 104 473 minecraft:bone_block
fill 242 100 479 247 103 479 minecraft:bone_block
fill 242 100 484 242 105 484 minecraft:soul_soil
fill 242 100 492 242 106 492 minecraft:soul_soil
fill 242 100 493 246 105 493 minecraft:bone_block
fill 242 100 495 246 106 497 minecraft:bone_block
fill 242 100 498 242 100 504 minecraft:black_concrete
fill 243 100 464 243 100 467 minecraft:black_concrete
fill 243 100 468 244 106 468 minecraft:bone_block
fill 243 100 484 247 102 484 minecraft:bone_block
fill 243 100 490 243 105 490 minecraft:soul_soil
fill 243 100 491 254 103 492 minecraft:bone_block
fill 243 100 498 261 106 498 minecraft:bone_block
fill 243 100 499 243 100 504 minecraft:black_concrete
fill 244 100 464 245 100 466 minecraft:black_concrete
fill 244 100 467 253 106 467 minecraft:bone_block
fill 244 100 488 244 104 488 minecraft:soul_soil
fill 244 100 489 254 102 490 minecraft:bone_block
fill 244 100 499 253 106 499 minecraft:bone_block
fill 244 100 500 245 100 504 minecraft:black_concrete
fill 245 100 468 246 106 468 minecraft:soul_soil
fill 245 100 474 246 105 474 minecraft:soul_soil
fill 245 100 487 245 104 487 minecraft:soul_soil
fill 245 100 488 247 103 488 minecraft:bone_block
fill 246 100 464 247 100 465 minecraft:black_concrete
fill 246 100 466 252 106 466 minecraft:bone_block
fill 246 100 486 246 103 486 minecraft:soul_soil
fill 246 100 487 247 103 487 minecraft:bone_block
fill 246 100 500 247 106 500 minecraft:bone_block
fill 246 100 501 247 100 504 minecraft:black_concrete
fill 247 100 468 265 106 468 minecraft:bone_block
fill 247 100 474 265 103 474 minecraft:bone_block
fill 247 100 482 247 102 482 minecraft:soul_soil
fill 247 100 486 247 103 486 minecraft:bone_block
fill 247 100 493 247 105 497 minecraft:soul_soil
fill 248 100 464 253 100 464 minecraft:black_concrete
fill 248 100 465 251 106 465 minecraft:bone_block
fill 248 100 475 248 104 475 minecraft:soul_soil
fill 248 100 476 264 102 477 minecraft:bone_block
fill 248 100 478 248 100 482 minecraft:shroomlight
fill 248 100 484 248 100 488 minecraft:shroomlight
fill 248 100 493 251 104 497 minecraft:bone_block
fill 248 100 500 248 106 501 minecraft:soul_soil
fill 248 100 502 253 100 504 minecraft:black_concrete
fill 249 100 470 249 105 470 minecraft:soul_soil
fill 249 100 475 252 103 475 minecraft:bone_block
fill 249 100 478 252 100 478 minecraft:shroomlight
fill 249 100 479 251 100 481 minecraft:black_concrete
fill 249 100 482 252 100 482 minecraft:shroomlight
fill 249 100 484 252 100 484 minecraft:shroomlight
fill 249 100 485 251 100 487 minecraft:black_concrete
fill 249 100 488 252 100 488 minecraft:shroomlight
fill 249 100 500 254 106 501 minecraft:bone_block
fill 250 100 470 260 105 470 minecraft:bone_block
fill 250 100 471 250 105 471 minecraft:soul_soil
fill 250 100 483 252 100 483 minecraft:shroomlight
fill 251 100 471 255 104 471 minecraft:bone_block
fill 251 100 472 251 104 472 minecraft:soul_soil
fill 252 100 465 252 106 465 minecraft:soul_soil
fill 252 100 472 255 104 472 minecraft:bone_block
fill 252 100 473 252 104 473 minecraft:soul_soil
fill 252 100 479 256 100 481 minecraft:shroomlight
fill 252 100 485 255 100 487 minecraft:shroomlight
fill 252 100 493 255 104 493 minecraft:bone_block
fill 252 100 494 252 104 495 minecraft:soul_soil
fill 252 100 496 252 105 497 minecraft:bone_block
fill 253 100 465 259 106 465 minecraft:bone_block
fill 253 100 466 253 106 466 minecraft:soul_soil
fill 253 100 473 260 104 473 minecraft:bone_block
fill 253 100 475 253 103 475 minecraft:soul_soil
fill 253 100 478 253 102 478 minecraft:bone_block
fill 253 100 488 253 102 488 minecraft:bone_block
fill 253 100 494 256 104 496 minecraft:bone_block
fill 253 100 497 253 105 497 minecraft:soul_soil
fill 254 100 466 259 106 466 minecraft:bone_block
fill 254 100 467 254 106 467 minecraft:soul_soil
fill 254 100 475 271 103 475 minecraft:bone_block
fill 254 100 478 254 101 478 minecraft:soul_soil
fill 254 100 488 254 101 488 minecraft:soul_soil
fill 254 100 497 266 105 497 minecraft:bone_block
fill 254 100 499 254 106 499 minecraft:soul_soil
fill 254 100 503 276 100 504 minecraft:black_concrete
fill 255 100 464 276 100 464 minecraft:black_concrete
fill 255 100 467 264 106 467 minecraft:bone_block
fill 255 100 469 255 105 469 minecraft:soul_soil
fill 255 100 478 255 102 478 minecraft:bone_block
fill 255 100 488 255 100 489 minecraft:shroomlight
fill 255 100 490 271 102 490 minecraft:bone_block
fill 255 100 491 255 103 491 minecraft:soul_soil
fill 255 100 492 261 103 492 minecraft:bone_block
fill 255 100 499 264 106 499 minecraft:bone_block
fill 255 100 500 255 106 500 minecraft:soul_soil
fill 255 100 501 255 106 501 minecraft:bone_block
fill 255 100 502 276 100 502 minecraft:black_concrete
fill 256 100 469 260 105 469 minecraft:bone_block
fill 256 100 471 256 104 472 minecraft:soul_soil
fill 256 100 478 260 100 478 minecraft:shroomlight
fill 256 100 482 258 100 485 minecraft:shroomlight
fill 256 100 486 258 100 488 minecraft:black_concrete
fill 256 100 489 259 100 489 minecraft:shroomlight
fill 256 100 491 259 103 491 minecraft:bone_block
fill 256 100 493 256 104 493 minecraft:soul_soil
fill 256 100 500 262 106 500 minecraft:bone_block
fill 256 100 501 256 106 501 minecraft:soul_soil
fill 257 100 471 260 104 472 minecraft:bone_block
fill 257 100 479 259 100 481 minecraft:black_concrete
fill 257 100 493 266 104 493 minecraft:bone_block
fill 257 100 494 257 104 494 minecraft:soul_soil
fill 257 100 495 257 105 496 minecraft:bone_block
fill 257 100 501 260 106 501 minecraft:bone_block
fill 258 100 494 269 104 494 minecraft:bone_block
fill 258 100 495 258 105 495 minecraft:soul_soil
fill 258 100 496 258 105 496 minecraft:bone_block
fill 259 100 482 260 100 482 minecraft:shroomlight
fill 259 100 483 260 101 484 minecraft:bone_block
fill 259 100 485 259 100 488 minecraft:shroomlight
fill 259 100 495 268 105 495 minecraft:bone_block
fill 259 100 496 259 105 496 minecraft:soul_soil
fill 260 100 465 260 106 466 minecraft:soul_soil
fill 260 100 479 260 100 481 minecraft:shroomlight
fill 260 100 485 269 102 486 minecraft:bone_block
fill 260 100 487 260 102 487 minecraft:soul_soil
fill 260 100 488 272 103 489 minecraft:bone_block
fill 260 100 491 260 104 491 minecraft:soul_soil
fill 260 100 496 267 105 496 minecraft:bone_block
fill 261 100 465 276 100 465 minecraft:black_concrete
fill 261 100 466 262 106 466 minecraft:bone_block
fill 261 100 469 261 105 473 minecraft:soul_soil
fill 261 100 478 261 102 483 minecraft:bone_block
fill 261 100 484 261 102 484 minecraft:soul_soil
fill 261 100 487 266 103 487 minecraft:bone_block
fill 261 100 491 271 104 491 minecraft:bone_block
fill 261 100 501 276 100 501 minecraft:black_concrete
fill 262 100 469 266 105 473 minecraft:bone_block
fill 262 100 478 262 103 479 minecraft:bone_block
fill 262 100 480 262 103 480 minecraft:soul_soil
fill 262 100 481 265 103 484 minecraft:bone_block
fill 262 100 492 263 105 492 minecraft:soul_soil
fill 262 100 498 263 106 498 minecraft:soul_soil
fill 263 100 466 276 100 466 minecraft:black_concrete
fill 263 100 478 263 104 478 minecraft:bone_block
fill 263 100 479 263 104 479 minecraft:soul_soil
fill 263 100 480 268 103 480 minecraft:bone_block
fill 263 100 500 276 100 500 minecraft:black_concrete
fill 264 100 478 264 104 478 minecraft:soul_soil
fill 264 100 479 269 104 479 minecraft:bone_block
fill 264 100 492 270 105 492 minecraft:bone_block
fill 264 100 498 265 106 498 minecraft:bone_block
fill 265 100 467 276 100 467 minecraft:black_concrete
fill 265 100 476 265 105 476 minecraft:soul_soil
fill 265 100 477 270 105 478 minecraft:bone_block
fill 265 100 499 276 100 499 minecraft:black_concrete
fill 266 100 468 276 100 468 minecraft:black_concrete
fill 266 100 474 266 106 474 minecraft:soul_soil
fill 266 100 476 271 105 476 minecraft:bone_block
fill 266 100 481 267 105 481 minecraft:bone_block
fill 266 100 482 266 105 482 minecraft:soul_soil
fill 266 100 483 272 104 484 minecraft:bone_block
fill 266 100 498 276 100 498 minecraft:black_concrete
fill 267 100 469 276 100 469 minecraft:black_concrete
fill 267 100 470 267 106 471 minecraft:soul_soil
fill 267 100 472 269 106 474 minecraft:bone_block
fill 267 100 482 272 105 482 minecraft:bone_block
fill 267 100 487 268 105 487 minecraft:soul_soil
fill 267 100 493 269 106 493 minecraft:soul_soil
fill 267 100 497 276 100 497 minecraft:black_concrete
fill 268 100 470 276 100 470 minecraft:black_concrete
fill 268 100 471 268 106 471 minecraft:bone_block
fill 268 100 481 268 105 481 minecraft:soul_soil
fill 268 100 496 276 100 496 minecraft:black_concrete
fill 269 100 471 276 100 471 minecraft:black_concrete
fill 269 100 480 269 106 480 minecraft:soul_soil
fill 269 100 481 272 106 481 minecraft:bone_block
fill 269 100 487 272 106 487 minecraft:bone_block
fill 269 100 495 276 100 495 minecraft:black_concrete
fill 270 100 472 276 100 472 minecraft:black_concrete
fill 270 100 473 270 106 474 minecraft:bone_block
fill 270 100 479 270 106 479 minecraft:soul_soil
fill 270 100 480 272 106 480 minecraft:bone_block
fill 270 100 485 271 106 485 minecraft:bone_block
fill 270 100 486 271 106 486 minecraft:soul_soil
fill 270 100 493 270 106 493 minecraft:bone_block
fill 270 100 494 276 100 494 minecraft:black_concrete
fill 271 100 473 276 100 474 minecraft:black_concrete
fill 271 100 477 271 106 477 minecraft:soul_soil
fill 271 100 478 272 106 479 minecraft:bone_block
fill 271 100 492 276 100 493 minecraft:black_concrete
fill 272 100 475 276 100 476 minecraft:black_concrete
fill 272 100 477 272 106 477 minecraft:bone_block
fill 272 100 485 272 106 485 minecraft:soul_soil
fill 272 100 486 272 106 486 minecraft:bone_block
fill 272 100 490 276 100 491 minecraft:black_concrete
fill 273 100 477 276 100 482 minecraft:black_concrete
fill 273 100 484 276 100 489 minecraft:black_concrete
fill 274 100 483 276 100 483 minecraft:black_concrete
fill 248 101 478 252 102 478 minecraft:bone_block
fill 248 101 479 248 102 479 minecraft:soul_soil
fill 248 101 480 249 102 482 minecraft:bone_block
fill 248 101 484 249 102 488 minecraft:bone_block
fill 249 101 479 251 101 479 minecraft:bone_block
setblock 250 101 480 minecraft:bone_block
fill 250 101 481 251 101 485 minecraft:shroomlight
fill 250 101 486 250 101 488 minecraft:bone_block
fill 251 101 480 257 101 480 minecraft:shroomlight
fill 251 101 486 257 101 486 minecraft:shroomlight
fill 251 101 487 251 101 488 minecraft:bone_block
fill 252 101 479 256 101 479 minecraft:shroomlight
setblock 252 101 481 minecraft:shroomlight
setblock 252 101 485 minecraft:shroomlight
fill 252 101 487 256 101 487 minecraft:shroomlight
fill 252 101 488 252 102 488 minecraft:bone_block
fill 255 101 488 259 102 489 minecraft:bone_block
fill 256 101 478 260 102 478 minecraft:bone_block
fill 256 101 481 258 101 481 minecraft:shroomlight
fill 256 101 485 258 101 485 minecraft:shroomlight
fill 257 101 479 260 101 479 minecraft:bone_block
fill 257 101 482 258 101 484 minecraft:shroomlight
fill 257 101 487 259 101 487 minecraft:bone_block
fill 258 101 480 260 101 480 minecraft:bone_block
fill 258 101 486 259 101 486 minecraft:bone_block
fill 259 101 481 260 102 482 minecraft:bone_block
fill 259 101 485 259 102 485 minecraft:bone_block
fill 235 102 483 248 102 483 minecraft:bone_block
fill 249 102 479 250 102 479 minecraft:bone_block
fill 250 102 487 250 102 488 minecraft:bone_block
setblock 251 102 488 minecraft:bone_block
fill 258 102 479 260 102 479 minecraft:bone_block
fill 258 102 487 259 102 487 minecraft:bone_block
fill 259 102 480 260 102 480 minecraft:bone_block
fill 259 102 484 260 102 484 minecraft:bone_block
setblock 259 102 486 minecraft:bone_block
setblock 260 102 483 minecraft:bone_block
fill 235 103 483 246 103 483 minecraft:bone_block
fill 237 103 481 246 103 481 minecraft:bone_block
fill 241 103 485 246 103 485 minecraft:bone_block
fill 243 103 484 246 103 484 minecraft:bone_block
fill 244 103 489 249 103 490 minecraft:bone_block
fill 248 103 476 248 103 478 minecraft:bone_block
setblock 248 103 488 minecraft:bone_block
fill 249 103 476 249 103 477 minecraft:bone_block
fill 250 103 476 251 103 476 minecraft:bone_block
fill 250 103 490 251 103 490 minecraft:bone_block
fill 257 103 476 264 103 476 minecraft:bone_block
fill 257 103 490 271 103 490 minecraft:bone_block
fill 259 103 477 264 103 477 minecraft:bone_block
setblock 259 103 489 minecraft:bone_block
fill 260 103 478 261 103 478 minecraft:bone_block
fill 261 103 479 261 103 480 minecraft:bone_block
fill 261 103 486 269 103 486 minecraft:bone_block
fill 262 103 485 269 103 485 minecraft:bone_block
fill 235 104 483 244 104 483 minecraft:bone_block
setblock 236 104 476 minecraft:brown_terracotta
fill 236 104 482 244 104 482 minecraft:bone_block
fill 237 104 464 238 104 464 minecraft:brown_terracotta
fill 237 104 481 244 104 481 minecraft:bone_block
setblock 238 104 504 minecraft:brown_terracotta
setblock 239 104 464 minecraft:bone_block
fill 239 104 465 242 104 465 minecraft:brown_terracotta
fill 239 104 480 244 104 480 minecraft:bone_block
setblock 239 104 504 minecraft:bone_block
fill 240 104 464 243 104 464 minecraft:brown_terracotta
fill 240 104 475 245 104 478 minecraft:bone_block
fill 240 104 486 244 104 486 minecraft:bone_block
fill 240 104 504 243 104 504 minecraft:brown_terracotta
fill 241 104 485 244 104 485 minecraft:bone_block
fill 241 104 503 244 104 503 minecraft:brown_terracotta
setblock 242 104 466 minecraft:bone_block
fill 242 104 479 245 104 479 minecraft:bone_block
setblock 243 104 465 minecraft:bone_block
fill 243 104 466 245 105 466 minecraft:brown_terracotta
fill 243 104 484 244 104 484 minecraft:bone_block
fill 243 104 491 248 104 492 minecraft:bone_block
setblock 244 104 464 minecraft:bone_block
fill 244 104 465 247 104 465 minecraft:brown_terracotta
fill 244 104 489 246 104 490 minecraft:bone_block
setblock 244 104 504 minecraft:bone_block
fill 245 104 464 248 104 464 minecraft:brown_terracotta
setblock 245 104 488 minecraft:bone_block
setblock 245 104 503 minecraft:bone_block
fill 245 104 504 248 104 504 minecraft:brown_terracotta
fill 246 104 475 246 104 477 minecraft:bone_block
fill 246 104 503 249 104 503 minecraft:brown_terracotta
fill 247 104 474 247 104 476 minecraft:bone_block
setblock 247 104 490 minecraft:bone_block
fill 248 104 474 250 104 474 minecraft:bone_block
setblock 249 104 464 minecraft:bone_block
fill 249 104 492 250 104 492 minecraft:bone_block
setblock 249 104 504 minecraft:bone_block
fill 250 104 464 253 104 464 minecraft:brown_terracotta
setblock 250 104 503 minecraft:bone_block
fill 250 104 504 253 104 504 minecraft:brown_terracotta
fill 251 104 503 254 104 503 minecraft:brown_terracotta
setblock 254 104 504 minecraft:bone_block
fill 255 104 464 258 104 464 minecraft:brown_terracotta
setblock 255 104 503 minecraft:bone_block
fill 255 104 504 258 104 504 minecraft:brown_terracotta
fill 256 104 503 259 104 503 minecraft:brown_terracotta
fill 258 104 474 265 104 474 minecraft:bone_block
fill 258 104 492 261 104 492 minecraft:bone_block
setblock 259 104 464 minecraft:bone_block
fill 259 104 502 260 104 502 minecraft:brown_terracotta
setblock 259 104 504 minecraft:bone_block
fill 260 104 464 263 104 464 minecraft:brown_terracotta
fill 260 104 475 271 104 475 minecraft:bone_block
setblock 260 104 503 minecraft:bone_block
fill 260 104 504 263 104 504 minecraft:brown_terracotta
fill 261 104 465 262 104 465 minecraft:brown_terracotta
fill 261 104 476 264 104 476 minecraft:bone_block
fill 261 104 490 271 104 490 minecraft:bone_block
setblock 261 104 502 minecraft:bone_block
fill 261 104 503 264 104 503 minecraft:brown_terracotta
fill 262 104 477 264 104 477 minecraft:bone_block
fill 262 104 489 272 104 489 minecraft:bone_block
fill 262 104 502 265 104 502 minecraft:brown_terracotta
setblock 263 104 465 minecraft:bone_block
fill 263 104 487 266 104 488 minecraft:bone_block
setblock 264 104 464 minecraft:bone_block
fill 264 104 465 266 105 465 minecraft:brown_terracotta
fill 264 104 480 265 104 486 minecraft:bone_block
fill 264 104 501 264 105 501 minecraft:brown_terracotta
setblock 264 104 504 minecraft:bone_block
fill 265 104 464 268 104 464 minecraft:brown_terracotta
setblock 265 104 503 minecraft:bone_block
fill 265 104 504 268 104 504 minecraft:brown_terracotta
fill 266 104 480 268 105 480 minecraft:bone_block
fill 266 104 485 269 105 486 minecraft:bone_block
setblock 266 104 502 minecraft:bone_block
fill 266 104 503 269 104 503 minecraft:brown_terracotta
fill 267 104 488 272 105 488 minecraft:bone_block
fill 267 104 502 268 105 502 minecraft:brown_terracotta
setblock 269 104 464 minecraft:bone_block
setblock 269 104 504 minecraft:bone_block
setblock 270 104 503 minecraft:bone_block
fill 270 104 504 273 104 504 minecraft:brown_terracotta
setblock 275 104 482 minecraft:brown_terracotta
setblock 275 104 483 minecraft:bone_block
fill 275 104 484 276 105 485 minecraft:brown_terracotta
fill 276 104 478 276 104 481 minecraft:brown_terracotta
setblock 276 104 482 minecraft:bone_block
fill 276 104 483 276 107 483 minecraft:brown_terracotta
setblock 276 104 486 minecraft:brown_terracotta
setblock 276 104 487 minecraft:bone_block
fill 276 104 488 276 106 489 minecraft:brown_terracotta
fill 235 105 463 236 105 463 minecraft:black_concrete
fill 235 105 464 237 105 464 minecraft:brown_terracotta
fill 235 105 465 235 106 474 minecraft:black_concrete
setblock 235 105 475 minecraft:brown_terracotta
fill 235 105 476 235 105 482 minecraft:black_concrete
fill 235 105 483 241 105 483 minecraft:bone_block
fill 235 105 484 235 108 486 minecraft:black_concrete
setblock 235 105 487 minecraft:brown_terracotta
fill 235 105 488 235 106 504 minecraft:black_concrete
setblock 235 105 505 minecraft:brown_terracotta
setblock 236 105 465 minecraft:brown_terracotta
setblock 236 105 466 minecraft:bone_block
fill 236 105 467 236 108 467 minecraft:brown_terracotta
setblock 236 105 476 minecraft:bone_block
fill 236 105 482 242 105 482 minecraft:bone_block
fill 236 105 505 239 105 505 minecraft:black_concrete
fill 237 105 463 238 105 463 minecraft:brown_terracotta
fill 237 105 481 242 105 481 minecraft:bone_block
setblock 237 105 504 minecraft:brown_terracotta
setblock 238 105 464 minecraft:bone_block
fill 238 105 465 241 105 465 minecraft:brown_terracotta
setblock 238 105 504 minecraft:bone_block
fill 239 105 463 242 105 463 minecraft:black_concrete
fill 239 105 464 242 105 464 minecraft:brown_terracotta
fill 239 105 472 249 105 472 minecraft:bone_block
fill 239 105 480 242 105 480 minecraft:bone_block
fill 239 105 487 242 105 487 minecraft:bone_block
fill 239 105 504 242 105 504 minecraft:brown_terracotta
setblock 240 105 466 minecraft:brown_terracotta
fill 240 105 475 243 105 478 minecraft:bone_block
fill 240 105 486 242 105 486 minecraft:bone_block
fill 240 105 503 243 105 503 minecraft:brown_terracotta
setblock 240 105 505 minecraft:brown_terracotta
setblock 241 105 466 minecraft:bone_block
fill 241 105 485 242 105 485 minecraft:bone_block
fill 241 105 505 241 108 505 minecraft:black_concrete
setblock 242 105 465 minecraft:bone_block
fill 242 105 466 242 108 466 minecraft:brown_terracotta
fill 242 105 473 247 105 473 minecraft:bone_block
setblock 242 105 479 minecraft:bone_block
setblock 242 105 505 minecraft:brown_terracotta
setblock 243 105 463 minecraft:brown_terracotta
setblock 243 105 464 minecraft:bone_block
fill 243 105 465 246 105 465 minecraft:brown_terracotta
fill 243 105 491 245 105 492 minecraft:bone_block
setblock 243 105 504 minecraft:bone_block
fill 243 105 505 250 105 505 minecraft:black_concrete
fill 244 105 463 254 106 463 minecraft:black_concrete
fill 244 105 464 247 105 464 minecraft:brown_terracotta
fill 244 105 475 244 105 476 minecraft:bone_block
setblock 244 105 490 minecraft:bone_block
setblock 244 105 503 minecraft:bone_block
fill 244 105 504 247 105 504 minecraft:brown_terracotta
setblock 245 105 475 minecraft:bone_block
fill 245 105 503 248 105 503 minecraft:brown_terracotta
setblock 246 105 492 minecraft:bone_block
setblock 247 105 465 minecraft:bone_block
setblock 248 105 464 minecraft:bone_block
fill 248 105 494 249 105 497 minecraft:bone_block
setblock 248 105 504 minecraft:bone_block
fill 249 105 464 252 105 464 minecraft:brown_terracotta
setblock 249 105 503 minecraft:bone_block
fill 249 105 504 252 105 504 minecraft:brown_terracotta
fill 250 105 495 251 105 497 minecraft:bone_block
fill 250 105 503 253 105 503 minecraft:brown_terracotta
fill 251 105 471 253 105 471 minecraft:bone_block
setblock 251 105 505 minecraft:brown_terracotta
setblock 252 105 495 minecraft:soul_soil
fill 252 105 505 262 105 505 minecraft:black_concrete
setblock 253 105 464 minecraft:bone_block
fill 253 105 495 253 105 496 minecraft:bone_block
setblock 253 105 504 minecraft:bone_block
fill 254 105 496 256 105 496 minecraft:bone_block
setblock 254 105 503 minecraft:bone_block
fill 254 105 504 257 105 504 minecraft:brown_terracotta
fill 255 105 463 255 105 464 minecraft:brown_terracotta
setblock 255 105 471 minecraft:bone_block
fill 255 105 495 256 105 495 minecraft:bone_block
fill 255 105 503 258 105 503 minecraft:brown_terracotta
fill 256 105 463 269 105 463 minecraft:black_concrete
fill 256 105 464 257 105 464 minecraft:brown_terracotta
setblock 256 105 471 minecraft:soul_soil
fill 257 105 471 260 105 471 minecraft:bone_block
setblock 258 105 464 minecraft:bone_block
fill 258 105 502 259 105 502 minecraft:brown_terracotta
setblock 258 105 504 minecraft:bone_block
fill 259 105 464 262 105 464 minecraft:brown_terracotta
fill 259 105 472 260 105 472 minecraft:bone_block
fill 259 105 494 269 105 494 minecraft:bone_block
setblock 259 105 503 minecraft:bone_block
fill 259 105 504 262 105 504 minecraft:brown_terracotta
setblock 260 105 502 minecraft:bone_block
fill 260 105 503 263 105 503 minecraft:brown_terracotta
setblock 261 105 465 minecraft:brown_terracotta
fill 261 105 493 266 105 493 minecraft:bone_block
fill 261 105 502 264 105 502 minecraft:brown_terracotta
setblock 262 105 465 minecraft:bone_block
fill 262 105 474 265 105 474 minecraft:bone_block
setblock 263 105 464 minecraft:bone_block
fill 263 105 465 263 108 465 minecraft:brown_terracotta
fill 263 105 475 271 105 475 minecraft:bone_block
fill 263 105 491 271 105 491 minecraft:bone_block
fill 263 105 501 263 106 501 minecraft:brown_terracotta
setblock 263 105 504 minecraft:bone_block
fill 263 105 505 263 106 505 minecraft:brown_terracotta
fill 264 105 464 267 105 464 minecraft:brown_terracotta
setblock 264 105 476 minecraft:bone_block
fill 264 105 490 271 105 490 minecraft:bone_block
setblock 264 105 503 minecraft:bone_block
fill 264 105 504 267 105 504 minecraft:brown_terracotta
fill 264 105 505 273 105 505 minecraft:black_concrete
fill 265 105 488 266 105 489 minecraft:bone_block
setblock 265 105 502 minecraft:bone_block
fill 265 105 503 268 105 503 minecraft:brown_terracotta
fill 266 105 479 269 105 479 minecraft:bone_block
fill 266 105 484 272 105 484 minecraft:bone_block
setblock 266 105 487 minecraft:bone_block
fill 266 105 502 266 108 502 minecraft:brown_terracotta
fill 267 105 483 272 105 483 minecraft:bone_block
fill 267 105 489 272 105 489 minecraft:bone_block
setblock 268 105 464 minecraft:bone_block
setblock 268 105 504 minecraft:bone_block
fill 269 105 464 270 107 464 minecraft:brown_terracotta
setblock 269 105 503 minecraft:bone_block
fill 269 105 504 272 105 504 minecraft:brown_terracotta
setblock 270 105 463 minecraft:brown_terracotta
setblock 270 105 503 minecraft:brown_terracotta
fill 271 105 463 277 105 463 minecraft:black_concrete
setblock 273 105 504 minecraft:bone_block
setblock 274 105 505 minecraft:brown_terracotta
setblock 275 105 481 minecraft:brown_terracotta
setblock 275 105 482 minecraft:bone_block
fill 275 105 483 275 108 483 minecraft:brown_terracotta
setblock 275 105 486 minecraft:brown_terracotta
setblock 275 105 487 minecraft:bone_block
fill 275 105 505 277 108 505 minecraft:black_concrete
fill 276 105 478 276 105 480 minecraft:brown_terracotta
setblock 276 105 481 minecraft:bone_block
fill 276 105 482 276 108 482 minecraft:brown_terracotta
setblock 276 105 486 minecraft:bone_block
fill 276 105 487 276 108 487 minecraft:brown_terracotta
setblock 276 105 490 minecraft:brown_terracotta
fill 277 105 464 277 105 465 minecraft:black_concrete
setblock 277 105 466 minecraft:brown_terracotta
fill 277 105 467 277 105 472 minecraft:black_concrete
setblock 277 105 473 minecraft:brown_terracotta
fill 277 105 474 277 106 504 minecraft:black_concrete
fill 235 106 463 235 107 463 minecraft:brown_terracotta
fill 235 106 464 235 108 464 minecraft:black_concrete
fill 235 106 475 235 109 475 minecraft:black_concrete
fill 235 106 476 236 106 476 minecraft:brown_terracotta
fill 235 106 477 235 108 482 minecraft:black_concrete
fill 235 106 483 239 106 483 minecraft:bone_block
fill 235 106 487 235 108 487 minecraft:black_concrete
fill 235 106 505 237 106 505 minecraft:black_concrete
fill 236 106 463 237 106 463 minecraft:black_concrete
setblock 236 106 464 minecraft:brown_terracotta
setblock 236 106 465 minecraft:bone_block
fill 236 106 466 237 108 466 minecraft:brown_terracotta
fill 236 106 468 236 106 469 minecraft:brown_terracotta
setblock 236 106 470 minecraft:bone_block
fill 236 106 471 236 108 472 minecraft:brown_terracotta
setblock 236 106 474 minecraft:brown_terracotta
setblock 236 106 475 minecraft:bone_block
fill 236 106 482 239 106 482 minecraft:bone_block
setblock 236 106 504 minecraft:brown_terracotta
setblock 237 106 464 minecraft:bone_block
fill 237 106 465 240 106 465 minecraft:brown_terracotta
fill 237 106 467 237 107 467 minecraft:brown_terracotta
fill 237 106 481 239 106 481 minecraft:bone_block
fill 237 106 490 241 106 491 minecraft:bone_block
setblock 237 106 504 minecraft:bone_block
fill 238 106 463 238 106 464 minecraft:brown_terracotta
fill 238 106 488 240 106 489 minecraft:bone_block
fill 238 106 504 238 106 505 minecraft:brown_terracotta
fill 239 106 463 241 108 463 minecraft:black_concrete
fill 239 106 464 241 106 464 minecraft:brown_terracotta
setblock 239 106 466 minecraft:brown_terracotta
fill 239 106 472 244 106 472 minecraft:bone_block
fill 239 106 474 242 106 474 minecraft:bone_block
setblock 239 106 480 minecraft:bone_block
fill 239 106 487 240 106 487 minecraft:bone_block
fill 239 106 494 244 106 494 minecraft:bone_block
fill 239 106 504 241 106 504 minecraft:brown_terracotta
fill 239 106 505 240 108 505 minecraft:black_concrete
setblock 240 106 466 minecraft:bone_block
fill 240 106 471 246 106 471 minecraft:bone_block
fill 240 106 475 240 106 478 minecraft:bone_block
setblock 240 106 479 minecraft:soul_soil
fill 240 106 503 242 106 503 minecraft:brown_terracotta
setblock 241 106 465 minecraft:bone_block
fill 241 106 466 241 109 466 minecraft:brown_terracotta
fill 241 106 470 247 106 470 minecraft:bone_block
fill 241 106 475 241 106 476 minecraft:bone_block
setblock 242 106 463 minecraft:brown_terracotta
setblock 242 106 464 minecraft:bone_block
fill 242 106 465 245 106 465 minecraft:brown_terracotta
fill 242 106 467 243 106 467 minecraft:brown_terracotta
fill 242 106 469 250 106 469 minecraft:bone_block
fill 242 106 473 243 106 473 minecraft:bone_block
setblock 242 106 475 minecraft:bone_block
setblock 242 106 491 minecraft:bone_block
fill 242 106 493 243 106 493 minecraft:bone_block
setblock 242 106 504 minecraft:bone_block
fill 242 106 505 242 108 505 minecraft:black_concrete
fill 243 106 463 243 108 463 minecraft:black_concrete
fill 243 106 464 246 106 464 minecraft:brown_terracotta
fill 243 106 466 244 106 466 minecraft:brown_terracotta
setblock 243 106 503 minecraft:bone_block
fill 243 106 504 243 106 505 minecraft:brown_terracotta
fill 244 106 503 246 106 504 minecraft:brown_terracotta
fill 244 106 505 257 108 505 minecraft:black_concrete
setblock 245 106 466 minecraft:bone_block
setblock 246 106 465 minecraft:bone_block
setblock 247 106 464 minecraft:bone_block
fill 247 106 465 247 109 465 minecraft:brown_terracotta
fill 247 106 496 247 106 497 minecraft:soul_soil
setblock 247 106 503 minecraft:brown_terracotta
setblock 247 106 504 minecraft:bone_block
fill 248 106 464 251 106 464 minecraft:brown_terracotta
fill 248 106 497 250 106 497 minecraft:bone_block
setblock 248 106 503 minecraft:bone_block
fill 248 106 504 251 106 504 minecraft:brown_terracotta
fill 249 106 503 252 106 503 minecraft:brown_terracotta
setblock 252 106 464 minecraft:bone_block
setblock 252 106 504 minecraft:bone_block
fill 253 106 464 253 109 464 minecraft:brown_terracotta
setblock 253 106 503 minecraft:bone_block
fill 253 106 504 256 106 504 minecraft:brown_terracotta
fill 254 106 503 257 106 503 minecraft:brown_terracotta
fill 255 106 463 257 108 463 minecraft:black_concrete
fill 255 106 464 256 106 464 minecraft:brown_terracotta
setblock 257 106 464 minecraft:bone_block
setblock 257 106 504 minecraft:bone_block
fill 258 106 463 259 106 464 minecraft:brown_terracotta
fill 258 106 469 260 106 469 minecraft:bone_block
fill 258 106 497 266 106 497 minecraft:bone_block
setblock 258 106 502 minecraft:brown_terracotta
setblock 258 106 503 minecraft:bone_block
fill 258 106 504 258 106 505 minecraft:brown_terracotta
setblock 259 106 502 minecraft:bone_block
fill 259 106 503 261 106 504 minecraft:brown_terracotta
fill 259 106 505 262 108 505 minecraft:black_concrete
fill 260 106 463 264 106 463 minecraft:black_concrete
fill 260 106 464 261 106 464 minecraft:brown_terracotta
fill 260 106 502 263 106 502 minecraft:brown_terracotta
setblock 261 106 465 minecraft:bone_block
fill 261 106 469 261 106 470 minecraft:soul_soil
fill 261 106 496 267 106 496 minecraft:bone_block
setblock 262 106 464 minecraft:bone_block
fill 262 106 465 262 109 465 minecraft:brown_terracotta
fill 262 106 469 266 106 471 minecraft:bone_block
fill 262 106 495 268 106 495 minecraft:bone_block
fill 262 106 501 262 107 501 minecraft:brown_terracotta
setblock 262 106 503 minecraft:brown_terracotta
setblock 262 106 504 minecraft:bone_block
fill 263 106 464 266 106 464 minecraft:brown_terracotta
setblock 263 106 503 minecraft:bone_block
fill 263 106 504 266 106 504 minecraft:brown_terracotta
fill 264 106 465 265 106 465 minecraft:brown_terracotta
fill 264 106 472 266 106 472 minecraft:bone_block
fill 264 106 494 269 106 494 minecraft:bone_block
setblock 264 106 502 minecraft:bone_block
fill 264 106 503 267 106 503 minecraft:brown_terracotta
setblock 264 106 505 minecraft:black_concrete
setblock 265 106 463 minecraft:brown_terracotta
fill 265 106 473 266 106 473 minecraft:bone_block
fill 265 106 493 266 106 493 minecraft:bone_block
fill 265 106 502 265 109 502 minecraft:brown_terracotta
setblock 265 106 505 minecraft:brown_terracotta
fill 266 106 463 272 106 463 minecraft:black_concrete
setblock 266 106 465 minecraft:bone_block
fill 266 106 475 271 106 475 minecraft:bone_block
fill 266 106 491 270 106 492 minecraft:bone_block
fill 266 106 505 271 108 505 minecraft:black_concrete
setblock 267 106 464 minecraft:bone_block
fill 267 106 465 267 109 465 minecraft:brown_terracotta
fill 267 106 476 271 106 476 minecraft:bone_block
fill 267 106 490 271 106 490 minecraft:bone_block
fill 267 106 502 267 107 502 minecraft:brown_terracotta
setblock 267 106 504 minecraft:bone_block
fill 268 106 464 268 109 464 minecraft:brown_terracotta
fill 268 106 477 269 106 479 minecraft:bone_block
setblock 268 106 487 minecraft:soul_soil
fill 268 106 488 272 106 489 minecraft:bone_block
setblock 268 106 503 minecraft:bone_block
fill 268 106 504 271 106 504 minecraft:brown_terracotta
fill 269 106 482 269 106 486 minecraft:bone_block
fill 269 106 503 269 107 503 minecraft:brown_terracotta
fill 270 106 477 270 106 478 minecraft:bone_block
fill 270 106 482 272 106 484 minecraft:bone_block
setblock 271 106 491 minecraft:bone_block
setblock 272 106 504 minecraft:bone_block
setblock 272 106 505 minecraft:brown_terracotta
fill 273 106 463 273 107 463 minecraft:brown_terracotta
fill 273 106 504 273 107 504 minecraft:brown_terracotta
fill 273 106 505 274 108 505 minecraft:black_concrete
fill 274 106 463 274 108 463 minecraft:black_concrete
setblock 275 106 463 minecraft:brown_terracotta
setblock 275 106 481 minecraft:bone_block
fill 275 106 482 275 109 482 minecraft:brown_terracotta
fill 275 106 484 275 106 485 minecraft:brown_terracotta
setblock 275 106 486 minecraft:bone_block
fill 275 106 487 275 108 488 minecraft:brown_terracotta
fill 276 106 463 277 106 463 minecraft:black_concrete
fill 276 106 477 276 106 479 minecraft:brown_terracotta
setblock 276 106 480 minecraft:bone_block
fill 276 106 481 276 109 481 minecraft:brown_terracotta
setblock 276 106 484 minecraft:brown_terracotta
setblock 276 106 485 minecraft:bone_block
fill 276 106 486 276 109 486 minecraft:brown_terracotta
setblock 276 106 490 minecraft:bone_block
fill 276 106 491 276 109 491 minecraft:brown_terracotta
setblock 276 106 504 minecraft:brown_terracotta
fill 277 106 464 277 108 464 minecraft:black_concrete
setblock 277 106 465 minecraft:brown_terracotta
fill 277 106 466 277 106 471 minecraft:black_concrete
setblock 277 106 472 minecraft:brown_terracotta
fill 277 106 473 277 108 473 minecraft:black_concrete
fill 235 107 465 239 107 465 minecraft:brown_terracotta
fill 235 107 466 235 108 467 minecraft:black_concrete
fill 235 107 468 236 107 468 minecraft:brown_terracotta
fill 235 107 469 235 108 470 minecraft:black_concrete
setblock 235 107 471 minecraft:brown_terracotta
fill 235 107 472 235 108 472 minecraft:black_concrete
fill 235 107 473 236 107 473 minecraft:brown_terracotta
fill 235 107 474 235 109 474 minecraft:black_concrete
fill 235 107 476 235 108 476 minecraft:black_concrete
fill 235 107 483 235 108 483 minecraft:black_concrete
fill 235 107 488 235 108 493 minecraft:black_concrete
fill 235 107 494 235 107 495 minecraft:brown_terracotta
fill 235 107 496 235 108 499 minecraft:black_concrete
setblock 235 107 500 minecraft:brown_terracotta
fill 235 107 501 235 108 504 minecraft:black_concrete
setblock 235 107 505 minecraft:brown_terracotta
setblock 236 107 463 minecraft:brown_terracotta
setblock 236 107 464 minecraft:bone_block
setblock 236 107 469 minecraft:bone_block
fill 236 107 470 237 109 470 minecraft:brown_terracotta
setblock 236 107 474 minecraft:bone_block
fill 236 107 475 236 107 478 minecraft:brown_terracotta
setblock 236 107 479 minecraft:bone_block
fill 236 107 480 236 107 483 minecraft:brown_terracotta
setblock 236 107 484 minecraft:bone_block
fill 236 107 485 236 107 488 minecraft:brown_terracotta
setblock 236 107 489 minecraft:bone_block
fill 236 107 490 236 110 490 minecraft:brown_terracotta
setblock 236 107 503 minecraft:brown_terracotta
setblock 236 107 504 minecraft:bone_block
fill 236 107 505 238 108 505 minecraft:black_concrete
fill 237 107 463 238 108 463 minecraft:black_concrete
fill 237 107 464 240 107 464 minecraft:brown_terracotta
setblock 237 107 468 minecraft:bone_block
fill 237 107 469 237 110 469 minecraft:brown_terracotta
fill 237 107 471 237 108 471 minecraft:brown_terracotta
setblock 237 107 477 minecraft:brown_terracotta
setblock 237 107 478 minecraft:bone_block
fill 237 107 479 237 107 482 minecraft:brown_terracotta
setblock 237 107 483 minecraft:bone_block
fill 237 107 484 237 107 487 minecraft:brown_terracotta
setblock 237 107 488 minecraft:bone_block
fill 237 107 504 240 107 504 minecraft:brown_terracotta
setblock 238 107 466 minecraft:brown_terracotta
setblock 238 107 467 minecraft:bone_block
fill 238 107 468 238 110 468 minecraft:brown_terracotta
setblock 238 107 474 minecraft:light[level=12]
fill 238 107 480 238 107 481 minecraft:brown_terracotta
setblock 238 107 482 minecraft:bone_block
fill 238 107 483 238 107 486 minecraft:brown_terracotta
setblock 238 107 490 minecraft:light[level=12]
setblock 238 107 498 minecraft:light[level=12]
setblock 239 107 466 minecraft:bone_block
fill 239 107 503 241 107 503 minecraft:brown_terracotta
setblock 240 107 465 minecraft:bone_block
fill 240 107 466 240 109 467 minecraft:brown_terracotta
setblock 241 107 464 minecraft:bone_block
fill 241 107 465 244 107 465 minecraft:brown_terracotta
fill 241 107 467 242 107 467 minecraft:brown_terracotta
setblock 241 107 504 minecraft:bone_block
fill 242 107 463 242 108 463 minecraft:black_concrete
fill 242 107 464 245 107 464 minecraft:brown_terracotta
setblock 242 107 503 minecraft:bone_block
fill 242 107 504 245 107 504 minecraft:brown_terracotta
setblock 243 107 466 minecraft:brown_terracotta
setblock 243 107 467 minecraft:bone_block
fill 243 107 503 246 107 503 minecraft:brown_terracotta
fill 243 107 505 243 109 505 minecraft:black_concrete
fill 244 107 463 250 108 463 minecraft:black_concrete
setblock 244 107 466 minecraft:bone_block
fill 244 107 467 246 108 467 minecraft:brown_terracotta
setblock 245 107 465 minecraft:bone_block
fill 245 107 466 248 107 466 minecraft:brown_terracotta
setblock 246 107 464 minecraft:bone_block
fill 246 107 465 246 110 465 minecraft:brown_terracotta
setblock 246 107 474 minecraft:light[level=12]
setblock 246 107 482 minecraft:light[level=12]
setblock 246 107 490 minecraft:light[level=12]
setblock 246 107 498 minecraft:light[level=12]
setblock 246 107 504 minecraft:bone_block
fill 247 107 464 250 107 464 minecraft:brown_terracotta
setblock 247 107 503 minecraft:bone_block
fill 247 107 504 250 107 504 minecraft:brown_terracotta
fill 248 107 465 249 107 465 minecraft:brown_terracotta
fill 248 107 503 251 107 503 minecraft:brown_terracotta
setblock 249 107 466 minecraft:bone_block
setblock 250 107 465 minecraft:bone_block
setblock 251 107 463 minecraft:brown_terracotta
setblock 251 107 464 minecraft:bone_block
fill 251 107 465 254 107 465 minecraft:brown_terracotta
setblock 251 107 504 minecraft:bone_block
fill 252 107 463 254 108 463 minecraft:black_concrete
fill 252 107 464 252 110 464 minecraft:brown_terracotta
setblock 252 107 503 minecraft:bone_block
fill 252 107 504 255 107 504 minecraft:brown_terracotta
fill 253 107 503 256 107 503 minecraft:brown_terracotta
fill 254 107 464 255 107 464 minecraft:brown_terracotta
setblock 254 107 466 minecraft:light[level=12]
setblock 254 107 474 minecraft:light[level=12]
setblock 254 107 490 minecraft:light[level=12]
setblock 254 107 498 minecraft:light[level=12]
setblock 255 107 465 minecraft:bone_block
setblock 256 107 464 minecraft:bone_block
fill 256 107 465 259 107 465 minecraft:brown_terracotta
setblock 256 107 504 minecraft:bone_block
fill 257 107 464 260 107 464 minecraft:brown_terracotta
setblock 257 107 502 minecraft:brown_terracotta
setblock 257 107 503 minecraft:bone_block
fill 257 107 504 260 107 504 minecraft:brown_terracotta
fill 258 107 463 260 108 463 minecraft:black_concrete
setblock 258 107 502 minecraft:bone_block
fill 258 107 503 261 107 503 minecraft:brown_terracotta
fill 258 107 505 258 108 505 minecraft:black_concrete
fill 259 107 502 262 107 502 minecraft:brown_terracotta
setblock 260 107 465 minecraft:bone_block
fill 260 107 466 263 107 466 minecraft:brown_terracotta
setblock 261 107 463 minecraft:brown_terracotta
setblock 261 107 464 minecraft:bone_block
fill 261 107 465 261 110 465 minecraft:brown_terracotta
setblock 261 107 504 minecraft:bone_block
fill 262 107 463 271 108 463 minecraft:black_concrete
fill 262 107 464 265 107 464 minecraft:brown_terracotta
setblock 262 107 474 minecraft:light[level=12]
setblock 262 107 482 minecraft:light[level=12]
setblock 262 107 490 minecraft:light[level=12]
setblock 262 107 498 minecraft:light[level=12]
setblock 262 107 503 minecraft:bone_block
fill 262 107 504 265 107 504 minecraft:brown_terracotta
setblock 263 107 502 minecraft:bone_block
fill 263 107 503 266 107 503 minecraft:brown_terracotta
fill 263 107 505 263 108 505 minecraft:black_concrete
setblock 264 107 465 minecraft:brown_terracotta
fill 264 107 502 264 109 502 minecraft:brown_terracotta
setblock 264 107 505 minecraft:brown_terracotta
setblock 265 107 465 minecraft:bone_block
fill 265 107 505 265 108 505 minecraft:black_concrete
setblock 266 107 464 minecraft:bone_block
fill 266 107 465 266 110 465 minecraft:brown_terracotta
setblock 266 107 504 minecraft:bone_block
fill 267 107 464 267 110 464 minecraft:brown_terracotta
fill 267 107 469 267 108 469 minecraft:soul_soil
setblock 267 107 503 minecraft:bone_block
fill 267 107 504 270 107 504 minecraft:brown_terracotta
fill 268 107 503 268 108 503 minecraft:brown_terracotta
setblock 270 107 466 minecraft:light[level=12]
setblock 270 107 474 minecraft:light[level=12]
setblock 270 107 482 minecraft:light[level=12]
setblock 270 107 490 minecraft:light[level=12]
setblock 270 107 498 minecraft:light[level=12]
setblock 271 107 464 minecraft:bone_block
setblock 271 107 504 minecraft:bone_block
setblock 272 107 463 minecraft:brown_terracotta
fill 272 107 504 272 108 504 minecraft:brown_terracotta
fill 272 107 505 272 108 505 minecraft:black_concrete
fill 274 107 484 274 107 485 minecraft:brown_terracotta
setblock 274 107 486 minecraft:bone_block
fill 275 107 463 275 108 463 minecraft:black_concrete
setblock 275 107 464 minecraft:brown_terracotta
setblock 275 107 480 minecraft:bone_block
fill 275 107 481 275 110 481 minecraft:brown_terracotta
setblock 275 107 484 minecraft:brown_terracotta
setblock 275 107 485 minecraft:bone_block
fill 275 107 486 275 110 486 minecraft:brown_terracotta
setblock 275 107 489 minecraft:brown_terracotta
setblock 275 107 490 minecraft:bone_block
setblock 275 107 504 minecraft:brown_terracotta
fill 276 107 463 277 107 463 minecraft:brown_terracotta
setblock 276 107 464 minecraft:bone_block
fill 276 107 465 276 108 467 minecraft:brown_terracotta
fill 276 107 477 276 107 478 minecraft:brown_terracotta
setblock 276 107 479 minecraft:bone_block
fill 276 107 480 276 110 480 minecraft:brown_terracotta
setblock 276 107 484 minecraft:bone_block
fill 276 107 485 276 110 485 minecraft:brown_terracotta
setblock 276 107 488 minecraft:brown_terracotta
setblock 276 107 489 minecraft:bone_block
fill 276 107 490 276 110 490 minecraft:brown_terracotta
fill 276 107 492 277 107 492 minecraft:brown_terracotta
setblock 276 107 503 minecraft:brown_terracotta
setblock 276 107 504 minecraft:bone_block
fill 277 107 465 277 108 468 minecraft:black_concrete
fill 277 107 469 277 107 470 minecraft:brown_terracotta
fill 277 107 471 277 108 472 minecraft:black_concrete
fill 277 107 474 277 108 474 minecraft:black_concrete
setblock 277 107 475 minecraft:brown_terracotta
fill 277 107 476 277 108 491 minecraft:black_concrete
setblock 277 107 493 minecraft:brown_terracotta
fill 277 107 494 277 108 495 minecraft:black_concrete
setblock 277 107 496 minecraft:brown_terracotta
fill 277 107 497 277 108 504 minecraft:black_concrete
fill 235 108 463 236 108 463 minecraft:black_concrete
setblock 235 108 465 minecraft:black_concrete
setblock 235 108 468 minecraft:black_concrete
setblock 235 108 471 minecraft:black_concrete
setblock 235 108 473 minecraft:black_concrete
fill 235 108 494 235 108 495 minecraft:black_concrete
setblock 235 108 500 minecraft:black_concrete
setblock 235 108 505 minecraft:black_concrete
fill 236 108 464 238 108 465 minecraft:brown_terracotta
setblock 236 108 468 minecraft:bone_block
fill 236 108 469 236 111 469 minecraft:brown_terracotta
setblock 236 108 473 minecraft:bone_block
fill 236 108 474 236 108 477 minecraft:brown_terracotta
setblock 236 108 478 minecraft:bone_block
fill 236 108 479 236 108 482 minecraft:brown_terracotta
setblock 236 108 483 minecraft:bone_block
fill 236 108 484 236 108 487 minecraft:brown_terracotta
setblock 236 108 488 minecraft:bone_block
fill 236 108 489 237 110 489 minecraft:brown_terracotta
fill 236 108 491 236 109 491 minecraft:brown_terracotta
setblock 236 108 503 minecraft:bone_block
fill 236 108 504 239 108 504 minecraft:brown_terracotta
setblock 237 108 467 minecraft:bone_block
fill 237 108 468 237 111 468 minecraft:brown_terracotta
setblock 237 108 472 minecraft:bone_block
fill 237 108 473 237 108 476 minecraft:brown_terracotta
setblock 237 108 477 minecraft:bone_block
fill 237 108 478 237 108 481 minecraft:brown_terracotta
setblock 237 108 482 minecraft:bone_block
fill 237 108 483 237 108 486 minecraft:brown_terracotta
setblock 237 108 487 minecraft:bone_block
fill 237 108 488 237 111 488 minecraft:brown_terracotta
setblock 238 108 466 minecraft:bone_block
fill 238 108 467 239 110 467 minecraft:brown_terracotta
fill 238 108 469 238 108 470 minecraft:brown_terracotta
setblock 238 108 480 minecraft:brown_terracotta
setblock 238 108 481 minecraft:bone_block
fill 238 108 482 238 108 485 minecraft:brown_terracotta
setblock 238 108 486 minecraft:bone_block
fill 238 108 487 238 111 487 minecraft:brown_terracotta
fill 238 108 503 240 108 503 minecraft:brown_terracotta
setblock 239 108 464 minecraft:brown_terracotta
setblock 239 108 465 minecraft:bone_block
fill 239 108 466 239 111 466 minecraft:brown_terracotta
fill 239 108 468 239 109 468 minecraft:brown_terracotta
setblock 240 108 464 minecraft:bone_block
fill 240 108 465 243 108 465 minecraft:brown_terracotta
setblock 240 108 504 minecraft:bone_block
fill 241 108 464 244 108 464 minecraft:brown_terracotta
setblock 241 108 467 minecraft:brown_terracotta
setblock 241 108 503 minecraft:bone_block
fill 241 108 504 244 108 504 minecraft:brown_terracotta
setblock 242 108 467 minecraft:bone_block
fill 242 108 503 245 108 503 minecraft:brown_terracotta
setblock 243 108 466 minecraft:bone_block
fill 243 108 467 243 111 467 minecraft:brown_terracotta
setblock 244 108 465 minecraft:bone_block
fill 244 108 466 247 108 466 minecraft:brown_terracotta
setblock 245 108 464 minecraft:bone_block
fill 245 108 465 245 111 465 minecraft:brown_terracotta
setblock 245 108 504 minecraft:bone_block
fill 246 108 464 249 108 464 minecraft:brown_terracotta
setblock 246 108 503 minecraft:bone_block
fill 246 108 504 249 108 504 minecraft:brown_terracotta
fill 247 108 503 250 108 503 minecraft:brown_terracotta
setblock 248 108 465 minecraft:brown_terracotta
setblock 248 108 466 minecraft:bone_block
setblock 249 108 465 minecraft:bone_block
fill 249 108 466 250 109 466 minecraft:brown_terracotta
setblock 250 108 464 minecraft:bone_block
fill 250 108 465 253 108 465 minecraft:brown_terracotta
setblock 250 108 504 minecraft:bone_block
setblock 251 108 463 minecraft:black_concrete
fill 251 108 464 251 111 464 minecraft:brown_terracotta
setblock 251 108 503 minecraft:bone_block
fill 251 108 504 254 108 504 minecraft:brown_terracotta
fill 252 108 503 255 108 503 minecraft:brown_terracotta
setblock 254 108 464 minecraft:brown_terracotta
setblock 254 108 465 minecraft:bone_block
setblock 255 108 464 minecraft:bone_block
fill 255 108 465 258 108 465 minecraft:brown_terracotta
setblock 255 108 504 minecraft:bone_block
fill 256 108 464 259 108 464 minecraft:brown_terracotta
setblock 256 108 503 minecraft:bone_block
fill 256 108 504 259 108 504 minecraft:brown_terracotta
setblock 257 108 502 minecraft:bone_block
fill 257 108 503 260 108 503 minecraft:brown_terracotta
setblock 258 108 466 minecraft:bone_block
fill 258 108 502 261 108 502 minecraft:brown_terracotta
setblock 259 108 465 minecraft:bone_block
fill 259 108 466 262 108 466 minecraft:brown_terracotta
setblock 260 108 464 minecraft:bone_block
fill 260 108 465 260 111 465 minecraft:brown_terracotta
setblock 260 108 504 minecraft:bone_block
fill 261 108 463 261 109 463 minecraft:black_concrete
fill 261 108 464 264 108 464 minecraft:brown_terracotta
setblock 261 108 503 minecraft:bone_block
fill 261 108 504 264 108 504 minecraft:brown_terracotta
setblock 262 108 502 minecraft:bone_block
fill 262 108 503 265 108 503 minecraft:brown_terracotta
setblock 263 108 466 minecraft:bone_block
fill 263 108 502 263 110 502 minecraft:brown_terracotta
setblock 264 108 465 minecraft:bone_block
fill 264 108 466 264 109 466 minecraft:brown_terracotta
setblock 264 108 505 minecraft:black_concrete
setblock 265 108 464 minecraft:bone_block
fill 265 108 465 265 111 465 minecraft:brown_terracotta
setblock 265 108 504 minecraft:bone_block
fill 266 108 464 266 111 464 minecraft:brown_terracotta
setblock 266 108 503 minecraft:bone_block
fill 266 108 504 269 108 504 minecraft:brown_terracotta
fill 267 108 503 267 109 503 minecraft:brown_terracotta
setblock 269 108 464 minecraft:brown_terracotta
setblock 270 108 464 minecraft:bone_block
setblock 270 108 504 minecraft:bone_block
fill 271 108 464 274 108 464 minecraft:brown_terracotta
setblock 271 108 504 minecraft:brown_terracotta
fill 272 108 463 273 108 463 minecraft:black_concrete
setblock 274 108 484 minecraft:brown_terracotta
setblock 274 108 485 minecraft:bone_block
fill 274 108 486 274 110 487 minecraft:brown_terracotta
setblock 275 108 464 minecraft:bone_block
fill 275 108 480 275 111 480 minecraft:brown_terracotta
setblock 275 108 484 minecraft:bone_block
fill 275 108 485 275 111 485 minecraft:brown_terracotta
setblock 275 108 489 minecraft:bone_block
fill 275 108 490 275 110 491 minecraft:brown_terracotta
setblock 275 108 504 minecraft:bone_block
fill 276 108 463 277 108 463 minecraft:black_concrete
fill 276 108 464 276 111 464 minecraft:brown_terracotta
setblock 276 108 468 minecraft:bone_block
fill 276 108 469 276 109 471 minecraft:brown_terracotta
fill 276 108 475 276 108 477 minecraft:brown_terracotta
setblock 276 108 478 minecraft:bone_block
fill 276 108 479 276 111 479 minecraft:brown_terracotta
setblock 276 108 483 minecraft:bone_block
fill 276 108 484 276 111 484 minecraft:brown_terracotta
setblock 276 108 488 minecraft:bone_block
fill 276 108 489 276 111 489 minecraft:brown_terracotta
setblock 276 108 492 minecraft:brown_terracotta
setblock 276 108 493 minecraft:bone_block
setblock 276 108 503 minecraft:bone_block
fill 276 108 504 276 110 504 minecraft:brown_terracotta
fill 277 108 469 277 109 470 minecraft:black_concrete
setblock 277 108 475 minecraft:black_concrete
fill 277 108 492 277 108 493 minecraft:black_concrete
setblock 277 108 496 minecraft:black_concrete
fill 235 109 463 235 109 473 minecraft:brown_terracotta
fill 235 109 476 235 109 498 minecraft:brown_terracotta
setblock 235 109 499 minecraft:black_concrete
fill 235 109 500 235 110 505 minecraft:brown_terracotta
setblock 236 109 463 minecraft:black_concrete
fill 236 109 464 236 109 466 minecraft:brown_terracotta
setblock 236 109 467 minecraft:bone_block
fill 236 109 468 236 112 468 minecraft:brown_terracotta
setblock 236 109 471 minecraft:brown_terracotta
setblock 236 109 472 minecraft:bone_block
fill 236 109 473 236 109 476 minecraft:brown_terracotta
setblock 236 109 477 minecraft:bone_block
fill 236 109 478 236 109 481 minecraft:brown_terracotta
setblock 236 109 482 minecraft:bone_block
fill 236 109 483 236 109 486 minecraft:brown_terracotta
setblock 236 109 487 minecraft:bone_block
fill 236 109 488 236 112 488 minecraft:brown_terracotta
setblock 236 109 492 minecraft:bone_block
fill 236 109 503 236 111 505 minecraft:brown_terracotta
fill 237 109 463 237 109 465 minecraft:brown_terracotta
setblock 237 109 466 minecraft:bone_block
fill 237 109 467 237 112 467 minecraft:brown_terracotta
setblock 237 109 471 minecraft:bone_block
fill 237 109 472 237 109 475 minecraft:brown_terracotta
setblock 237 109 476 minecraft:bone_block
fill 237 109 477 237 109 480 minecraft:brown_terracotta
setblock 237 109 481 minecraft:bone_block
fill 237 109 482 237 109 485 minecraft:brown_terracotta
setblock 237 109 486 minecraft:bone_block
fill 237 109 487 237 112 487 minecraft:brown_terracotta
setblock 237 109 490 minecraft:brown_terracotta
fill 237 109 504 238 109 505 minecraft:brown_terracotta
fill 238 109 463 238 109 464 minecraft:brown_terracotta
setblock 238 109 465 minecraft:bone_block
fill 238 109 466 238 112 466 minecraft:brown_terracotta
setblock 238 109 469 minecraft:brown_terracotta
setblock 238 109 470 minecraft:bone_block
fill 238 109 471 238 111 472 minecraft:brown_terracotta
fill 238 109 481 238 109 484 minecraft:brown_terracotta
setblock 238 109 485 minecraft:bone_block
fill 238 109 486 238 111 486 minecraft:brown_terracotta
fill 238 109 488 238 110 488 minecraft:brown_terracotta
fill 238 109 503 239 109 503 minecraft:brown_terracotta
fill 239 109 463 251 109 463 minecraft:brown_terracotta
setblock 239 109 464 minecraft:bone_block
fill 239 109 465 242 109 465 minecraft:brown_terracotta
setblock 239 109 469 minecraft:bone_block
fill 239 109 470 239 112 470 minecraft:brown_terracotta
setblock 239 109 504 minecraft:bone_block
fill 239 109 505 242 205 505 minecraft:brown_terracotta
fill 240 109 464 243 109 464 minecraft:brown_terracotta
setblock 240 109 503 minecraft:bone_block
fill 240 109 504 243 109 504 minecraft:brown_terracotta
setblock 241 109 467 minecraft:bone_block
fill 241 109 503 244 109 503 minecraft:brown_terracotta
setblock 242 109 466 minecraft:bone_block
fill 242 109 467 242 112 467 minecraft:brown_terracotta
setblock 243 109 465 minecraft:bone_block
fill 243 109 466 246 109 466 minecraft:brown_terracotta
setblock 244 109 464 minecraft:bone_block
fill 244 109 465 244 112 465 minecraft:brown_terracotta
fill 244 109 467 245 109 467 minecraft:brown_terracotta
setblock 244 109 504 minecraft:bone_block
fill 244 109 505 246 110 505 minecraft:brown_terracotta
fill 245 109 464 248 109 464 minecraft:brown_terracotta
setblock 245 109 503 minecraft:bone_block
fill 245 109 504 248 109 504 minecraft:brown_terracotta
setblock 246 109 467 minecraft:bone_block
fill 246 109 503 249 109 503 minecraft:brown_terracotta
setblock 247 109 466 minecraft:bone_block
setblock 247 109 505 minecraft:black_concrete
setblock 248 109 465 minecraft:bone_block
fill 248 109 466 248 111 466 minecraft:brown_terracotta
fill 248 109 505 273 109 505 minecraft:brown_terracotta
setblock 249 109 464 minecraft:bone_block
fill 249 109 465 252 109 465 minecraft:brown_terracotta
setblock 249 109 504 minecraft:bone_block
fill 250 109 464 250 112 464 minecraft:brown_terracotta
setblock 250 109 503 minecraft:bone_block
fill 250 109 504 253 109 504 minecraft:brown_terracotta
fill 251 109 503 254 109 503 minecraft:brown_terracotta
setblock 252 109 463 minecraft:black_concrete
fill 253 109 463 260 109 463 minecraft:brown_terracotta
setblock 253 109 465 minecraft:bone_block
setblock 254 109 464 minecraft:bone_block
fill 254 109 465 257 109 465 minecraft:brown_terracotta
setblock 254 109 504 minecraft:bone_block
fill 255 109 464 258 109 464 minecraft:brown_terracotta
setblock 255 109 503 minecraft:bone_block
fill 255 109 504 258 109 504 minecraft:brown_terracotta
fill 256 109 503 259 109 503 minecraft:brown_terracotta
setblock 257 109 466 minecraft:bone_block
fill 257 109 502 260 109 502 minecraft:brown_terracotta
setblock 258 109 465 minecraft:bone_block
fill 258 109 466 261 109 466 minecraft:brown_terracotta
setblock 259 109 464 minecraft:bone_block
fill 259 109 465 259 112 465 minecraft:brown_terracotta
setblock 259 109 504 minecraft:bone_block
fill 260 109 464 263 109 464 minecraft:brown_terracotta
setblock 260 109 503 minecraft:bone_block
fill 260 109 504 263 109 504 minecraft:brown_terracotta
setblock 261 109 502 minecraft:bone_block
fill 261 109 503 264 109 503 minecraft:brown_terracotta
fill 262 109 463 270 109 463 minecraft:brown_terracotta
setblock 262 109 466 minecraft:bone_block
fill 262 109 502 262 111 502 minecraft:brown_terracotta
setblock 263 109 465 minecraft:bone_block
fill 263 109 466 263 110 466 minecraft:brown_terracotta
setblock 264 109 464 minecraft:bone_block
fill 264 109 465 264 112 465 minecraft:brown_terracotta
setblock 264 109 504 minecraft:bone_block
fill 265 109 464 265 112 464 minecraft:brown_terracotta
setblock 265 109 503 minecraft:bone_block
fill 265 109 504 268 109 504 minecraft:brown_terracotta
fill 266 109 503 266 110 503 minecraft:brown_terracotta
setblock 269 109 464 minecraft:bone_block
setblock 269 109 504 minecraft:bone_block
fill 270 109 464 273 109 464 minecraft:brown_terracotta
setblock 270 109 504 minecraft:brown_terracotta
setblock 271 109 463 minecraft:black_concrete
fill 272 109 463 277 109 463 minecraft:brown_terracotta
setblock 274 109 464 minecraft:bone_block
setblock 274 109 484 minecraft:bone_block
fill 274 109 485 274 111 485 minecraft:brown_terracotta
setblock 274 109 488 minecraft:brown_terracotta
setblock 274 109 505 minecraft:black_concrete
fill 275 109 464 275 112 464 minecraft:brown_terracotta
setblock 275 109 483 minecraft:bone_block
fill 275 109 484 275 112 484 minecraft:brown_terracotta
setblock 275 109 487 minecraft:brown_terracotta
setblock 275 109 488 minecraft:bone_block
fill 275 109 489 275 112 489 minecraft:brown_terracotta
fill 275 109 504 275 109 505 minecraft:brown_terracotta
fill 276 109 465 277 109 466 minecraft:brown_terracotta
setblock 276 109 467 minecraft:bone_block
fill 276 109 468 277 109 468 minecraft:brown_terracotta
setblock 276 109 472 minecraft:bone_block
fill 276 109 473 277 109 476 minecraft:brown_terracotta
setblock 276 109 477 minecraft:bone_block
fill 276 109 478 277 112 478 minecraft:brown_terracotta
setblock 276 109 482 minecraft:bone_block
fill 276 109 483 277 110 483 minecraft:brown_terracotta
setblock 276 109 487 minecraft:bone_block
fill 276 109 488 277 112 488 minecraft:brown_terracotta
setblock 276 109 492 minecraft:bone_block
fill 276 109 493 277 110 494 minecraft:brown_terracotta
fill 276 109 503 277 109 503 minecraft:brown_terracotta
fill 276 109 505 277 109 505 minecraft:brown_terracotta
fill 277 109 464 277 204 464 minecraft:brown_terracotta
fill 277 109 467 277 208 467 minecraft:brown_terracotta
fill 277 109 471 277 205 472 minecraft:brown_terracotta
fill 277 109 477 277 208 477 minecraft:brown_terracotta
fill 277 109 479 277 109 482 minecraft:brown_terracotta
fill 277 109 484 277 205 485 minecraft:brown_terracotta
setblock 277 109 486 minecraft:black_concrete
fill 277 109 487 277 110 487 minecraft:brown_terracotta
fill 277 109 489 277 208 490 minecraft:brown_terracotta
setblock 277 109 491 minecraft:black_concrete
fill 277 109 492 277 208 492 minecraft:brown_terracotta
fill 277 109 495 277 109 502 minecraft:brown_terracotta
fill 277 109 504 277 208 504 minecraft:brown_terracotta
fill 235 110 463 235 110 469 minecraft:brown_terracotta
setblock 235 110 470 minecraft:black_concrete
fill 235 110 471 235 206 476 minecraft:brown_terracotta
setblock 235 110 477 minecraft:black_concrete
fill 235 110 478 235 110 486 minecraft:brown_terracotta
setblock 235 110 487 minecraft:black_concrete
fill 235 110 488 235 204 490 minecraft:brown_terracotta
setblock 235 110 491 minecraft:black_concrete
fill 235 110 492 235 205 499 minecraft:brown_terracotta
fill 236 110 463 236 110 465 minecraft:brown_terracotta
setblock 236 110 466 minecraft:bone_block
fill 236 110 467 236 113 467 minecraft:brown_terracotta
setblock 236 110 470 minecraft:brown_terracotta
setblock 236 110 471 minecraft:bone_block
fill 236 110 472 236 110 475 minecraft:brown_terracotta
setblock 236 110 476 minecraft:bone_block
fill 236 110 477 236 110 480 minecraft:brown_terracotta
setblock 236 110 481 minecraft:bone_block
fill 236 110 482 236 110 485 minecraft:brown_terracotta
setblock 236 110 486 minecraft:bone_block
fill 236 110 487 236 113 487 minecraft:brown_terracotta
setblock 236 110 491 minecraft:bone_block
fill 236 110 492 236 112 493 minecraft:brown_terracotta
fill 237 110 463 237 110 464 minecraft:brown_terracotta
setblock 237 110 465 minecraft:bone_block
fill 237 110 466 237 113 466 minecraft:brown_terracotta
setblock 237 110 470 minecraft:bone_block
fill 237 110 471 237 110 474 minecraft:brown_terracotta
setblock 237 110 475 minecraft:bone_block
fill 237 110 476 237 110 479 minecraft:brown_terracotta
setblock 237 110 480 minecraft:bone_block
fill 237 110 481 237 110 484 minecraft:brown_terracotta
setblock 237 110 485 minecraft:bone_block
fill 237 110 486 237 113 486 minecraft:brown_terracotta
setblock 237 110 490 minecraft:bone_block
fill 237 110 491 237 113 491 minecraft:brown_terracotta
fill 237 110 504 237 110 505 minecraft:brown_terracotta
fill 238 110 463 241 110 463 minecraft:brown_terracotta
setblock 238 110 464 minecraft:bone_block
fill 238 110 465 241 110 465 minecraft:brown_terracotta
setblock 238 110 469 minecraft:bone_block
fill 238 110 470 238 113 470 minecraft:brown_terracotta
setblock 238 110 473 minecraft:brown_terracotta
fill 238 110 482 238 110 483 minecraft:brown_terracotta
setblock 238 110 484 minecraft:bone_block
fill 238 110 485 238 111 485 minecraft:brown_terracotta
setblock 238 110 503 minecraft:brown_terracotta
setblock 238 110 504 minecraft:bone_block
setblock 238 110 505 minecraft:black_concrete
fill 239 110 464 242 110 464 minecraft:brown_terracotta
setblock 239 110 468 minecraft:bone_block
fill 239 110 469 239 113 469 minecraft:brown_terracotta
fill 239 110 471 239 111 471 minecraft:brown_terracotta
setblock 239 110 503 minecraft:bone_block
fill 239 110 504 242 110 504 minecraft:brown_terracotta
setblock 240 110 466 minecraft:brown_terracotta
setblock 240 110 467 minecraft:bone_block
fill 240 110 468 242 110 468 minecraft:brown_terracotta
fill 240 110 503 243 110 503 minecraft:brown_terracotta
setblock 241 110 466 minecraft:bone_block
fill 241 110 467 241 113 467 minecraft:brown_terracotta
setblock 242 110 463 minecraft:black_concrete
setblock 242 110 465 minecraft:bone_block
fill 242 110 466 245 110 466 minecraft:brown_terracotta
fill 243 110 463 255 110 463 minecraft:brown_terracotta
setblock 243 110 464 minecraft:bone_block
fill 243 110 465 243 113 465 minecraft:brown_terracotta
setblock 243 110 504 minecraft:bone_block
fill 243 110 505 243 205 505 minecraft:brown_terracotta
fill 244 110 464 247 110 464 minecraft:brown_terracotta
setblock 244 110 467 minecraft:brown_terracotta
setblock 244 110 503 minecraft:bone_block
fill 244 110 504 247 110 504 minecraft:brown_terracotta
setblock 245 110 467 minecraft:bone_block
fill 245 110 503 248 110 503 minecraft:brown_terracotta
setblock 246 110 466 minecraft:bone_block
setblock 246 110 467 minecraft:brown_terracotta
setblock 247 110 465 minecraft:bone_block
fill 247 110 466 247 112 466 minecraft:brown_terracotta
fill 247 110 505 253 204 505 minecraft:brown_terracotta
setblock 248 110 464 minecraft:bone_block
fill 248 110 465 251 110 465 minecraft:brown_terracotta
setblock 248 110 504 minecraft:bone_block
fill 249 110 464 249 113 464 minecraft:brown_terracotta
setblock 249 110 466 minecraft:brown_terracotta
fill 249 110 504 252 110 504 minecraft:brown_terracotta
setblock 252 110 465 minecraft:bone_block
setblock 253 110 464 minecraft:bone_block
fill 253 110 465 256 110 465 minecraft:brown_terracotta
setblock 253 110 503 minecraft:brown_terracotta
setblock 253 110 504 minecraft:bone_block
fill 254 110 464 257 110 464 minecraft:brown_terracotta
setblock 254 110 503 minecraft:bone_block
fill 254 110 504 257 110 504 minecraft:brown_terracotta
setblock 254 110 505 minecraft:black_concrete
fill 255 110 503 258 110 503 minecraft:brown_terracotta
fill 255 110 505 261 110 505 minecraft:brown_terracotta
setblock 256 110 463 minecraft:black_concrete
setblock 256 110 466 minecraft:bone_block
fill 257 110 463 262 110 463 minecraft:brown_terracotta
setblock 257 110 465 minecraft:bone_block
fill 257 110 466 260 110 466 minecraft:brown_terracotta
fill 257 110 502 259 110 502 minecraft:brown_terracotta
setblock 258 110 464 minecraft:bone_block
fill 258 110 465 258 113 465 minecraft:brown_terracotta
setblock 258 110 504 minecraft:bone_block
fill 259 110 464 262 110 464 minecraft:brown_terracotta
setblock 259 110 503 minecraft:bone_block
fill 259 110 504 262 110 504 minecraft:brown_terracotta
setblock 260 110 502 minecraft:bone_block
fill 260 110 503 263 110 503 minecraft:brown_terracotta
setblock 261 110 466 minecraft:bone_block
fill 261 110 502 261 111 502 minecraft:brown_terracotta
setblock 262 110 465 minecraft:bone_block
fill 262 110 466 262 111 466 minecraft:brown_terracotta
setblock 262 110 505 minecraft:black_concrete
setblock 263 110 463 minecraft:black_concrete
setblock 263 110 464 minecraft:bone_block
fill 263 110 465 263 112 465 minecraft:brown_terracotta
setblock 263 110 504 minecraft:bone_block
fill 263 110 505 267 110 505 minecraft:brown_terracotta
fill 264 110 463 264 113 464 minecraft:brown_terracotta
setblock 264 110 503 minecraft:bone_block
fill 264 110 504 267 110 504 minecraft:brown_terracotta
fill 265 110 463 265 111 463 minecraft:black_concrete
fill 265 110 503 265 111 503 minecraft:brown_terracotta
fill 266 110 463 272 110 463 minecraft:brown_terracotta
setblock 268 110 464 minecraft:bone_block
setblock 268 110 504 minecraft:bone_block
setblock 268 110 505 minecraft:black_concrete
fill 269 110 464 270 110 464 minecraft:brown_terracotta
fill 269 110 504 269 110 505 minecraft:brown_terracotta
fill 270 110 505 275 206 505 minecraft:brown_terracotta
setblock 273 110 463 minecraft:black_concrete
setblock 273 110 464 minecraft:bone_block
fill 274 110 463 274 113 464 minecraft:brown_terracotta
setblock 274 110 484 minecraft:brown_terracotta
setblock 274 110 488 minecraft:bone_block
fill 274 110 489 274 113 489 minecraft:brown_terracotta
fill 275 110 463 276 208 463 minecraft:brown_terracotta
setblock 275 110 466 minecraft:brown_terracotta
setblock 275 110 467 minecraft:bone_block
fill 275 110 468 276 112 468 minecraft:brown_terracotta
setblock 275 110 482 minecraft:bone_block
fill 275 110 483 275 113 483 minecraft:brown_terracotta
setblock 275 110 487 minecraft:bone_block
fill 275 110 488 275 113 488 minecraft:brown_terracotta
setblock 275 110 492 minecraft:bone_block
fill 276 110 465 277 110 465 minecraft:brown_terracotta
setblock 276 110 466 minecraft:bone_block
fill 276 110 467 276 113 467 minecraft:brown_terracotta
fill 276 110 469 277 110 470 minecraft:brown_terracotta
setblock 276 110 471 minecraft:bone_block
fill 276 110 472 276 110 475 minecraft:brown_terracotta
setblock 276 110 476 minecraft:bone_block
fill 276 110 477 276 113 477 minecraft:brown_terracotta
setblock 276 110 481 minecraft:bone_block
fill 276 110 482 276 113 482 minecraft:brown_terracotta
setblock 276 110 486 minecraft:bone_block
fill 276 110 487 276 113 487 minecraft:brown_terracotta
setblock 276 110 491 minecraft:bone_block
fill 276 110 492 276 113 492 minecraft:brown_terracotta
fill 276 110 495 277 110 495 minecraft:brown_terracotta
setblock 276 110 505 minecraft:black_concrete
setblock 277 110 463 minecraft:black_concrete
fill 277 110 466 277 208 466 minecraft:brown_terracotta
setblock 277 110 468 minecraft:black_concrete
fill 277 110 473 277 204 476 minecraft:brown_terracotta
fill 277 110 479 277 205 481 minecraft:brown_terracotta
setblock 277 110 482 minecraft:black_concrete
fill 277 110 486 277 206 486 minecraft:brown_terracotta
fill 277 110 491 277 206 491 minecraft:brown_terracotta
fill 277 110 496 277 204 501 minecraft:brown_terracotta
fill 277 110 502 277 111 502 minecraft:black_concrete
fill 277 110 503 277 208 503 minecraft:brown_terracotta
fill 277 110 505 277 208 505 minecraft:brown_terracotta
fill 235 111 463 240 204 463 minecraft:brown_terracotta
setblock 235 111 464 minecraft:black_concrete
fill 235 111 465 235 204 470 minecraft:brown_terracotta
fill 235 111 477 235 169 482 minecraft:brown_terracotta
setblock 235 111 483 minecraft:black_concrete
fill 235 111 484 235 169 487 minecraft:brown_terracotta
fill 235 111 491 236 114 491 minecraft:brown_terracotta
setblock 235 111 500 minecraft:black_concrete
fill 235 111 501 235 204 502 minecraft:brown_terracotta
fill 235 111 503 235 111 504 minecraft:black_concrete
fill 235 111 505 235 208 505 minecraft:brown_terracotta
setblock 236 111 464 minecraft:brown_terracotta
setblock 236 111 465 minecraft:bone_block
fill 236 111 466 236 114 466 minecraft:brown_terracotta
setblock 236 111 470 minecraft:bone_block
fill 236 111 471 236 111 474 minecraft:brown_terracotta
setblock 236 111 475 minecraft:bone_block
fill 236 111 476 236 111 479 minecraft:brown_terracotta
setblock 236 111 480 minecraft:bone_block
fill 236 111 481 236 111 484 minecraft:brown_terracotta
setblock 236 111 485 minecraft:bone_block
fill 236 111 486 236 114 486 minecraft:brown_terracotta
setblock 236 111 489 minecraft:brown_terracotta
setblock 236 111 490 minecraft:bone_block
setblock 237 111 464 minecraft:bone_block
fill 237 111 465 240 111 465 minecraft:brown_terracotta
setblock 237 111 469 minecraft:bone_block
fill 237 111 470 237 111 473 minecraft:brown_terracotta
setblock 237 111 474 minecraft:bone_block
fill 237 111 475 237 111 478 minecraft:brown_terracotta
setblock 237 111 479 minecraft:bone_block
fill 237 111 480 237 111 483 minecraft:brown_terracotta
setblock 237 111 484 minecraft:bone_block
fill 237 111 485 237 113 485 minecraft:brown_terracotta
setblock 237 111 489 minecraft:bone_block
fill 237 111 490 237 114 490 minecraft:brown_terracotta
setblock 237 111 504 minecraft:bone_block
fill 237 111 505 238 204 505 minecraft:brown_terracotta
fill 238 111 464 241 111 464 minecraft:brown_terracotta
setblock 238 111 467 minecraft:brown_terracotta
setblock 238 111 468 minecraft:bone_block
fill 238 111 469 238 114 469 minecraft:brown_terracotta
setblock 238 111 473 minecraft:bone_block
fill 238 111 474 238 114 474 minecraft:brown_terracotta
setblock 238 111 484 minecraft:brown_terracotta
setblock 238 111 488 minecraft:bone_block
setblock 238 111 489 minecraft:brown_terracotta
fill 238 111 504 241 111 504 minecraft:brown_terracotta
setblock 239 111 467 minecraft:bone_block
fill 239 111 468 241 111 468 minecraft:brown_terracotta
fill 239 111 503 242 111 503 minecraft:brown_terracotta
setblock 240 111 466 minecraft:bone_block
fill 240 111 467 240 114 467 minecraft:brown_terracotta
setblock 241 111 463 minecraft:black_concrete
setblock 241 111 465 minecraft:bone_block
fill 241 111 466 244 111 466 minecraft:brown_terracotta
fill 242 111 463 244 208 463 minecraft:brown_terracotta
setblock 242 111 464 minecraft:bone_block
fill 242 111 465 242 114 465 minecraft:brown_terracotta
setblock 242 111 504 minecraft:bone_block
fill 243 111 464 246 111 464 minecraft:brown_terracotta
setblock 243 111 503 minecraft:bone_block
fill 243 111 504 246 111 504 minecraft:brown_terracotta
setblock 244 111 467 minecraft:bone_block
fill 244 111 503 245 111 503 minecraft:brown_terracotta
fill 244 111 505 244 208 505 minecraft:brown_terracotta
setblock 245 111 463 minecraft:black_concrete
setblock 245 111 466 minecraft:bone_block
setblock 245 111 467 minecraft:brown_terracotta
setblock 245 111 505 minecraft:black_concrete
fill 246 111 463 250 205 463 minecraft:brown_terracotta
setblock 246 111 465 minecraft:bone_block
fill 246 111 466 246 112 466 minecraft:brown_terracotta
fill 246 111 505 246 209 505 minecraft:brown_terracotta
setblock 247 111 464 minecraft:bone_block
fill 247 111 465 250 111 465 minecraft:brown_terracotta
setblock 247 111 504 minecraft:bone_block
fill 248 111 464 248 114 464 minecraft:brown_terracotta
fill 248 111 504 251 111 504 minecraft:brown_terracotta
setblock 251 111 463 minecraft:black_concrete
setblock 251 111 465 minecraft:bone_block
fill 252 111 463 261 206 463 minecraft:brown_terracotta
setblock 252 111 464 minecraft:bone_block
fill 252 111 465 255 111 465 minecraft:brown_terracotta
setblock 252 111 504 minecraft:bone_block
fill 253 111 464 256 111 464 minecraft:brown_terracotta
fill 253 111 504 256 111 504 minecraft:brown_terracotta
fill 254 111 503 257 111 503 minecraft:brown_terracotta
fill 254 111 505 256 204 505 minecraft:brown_terracotta
setblock 256 111 465 minecraft:bone_block
fill 256 111 466 259 111 466 minecraft:brown_terracotta
setblock 257 111 464 minecraft:bone_block
fill 257 111 465 257 114 465 minecraft:brown_terracotta
setblock 257 111 504 minecraft:bone_block
setblock 257 111 505 minecraft:black_concrete
fill 258 111 464 261 111 464 minecraft:brown_terracotta
setblock 258 111 502 minecraft:brown_terracotta
setblock 258 111 503 minecraft:bone_block
fill 258 111 504 259 113 505 minecraft:brown_terracotta
setblock 259 111 502 minecraft:bone_block
fill 259 111 503 262 111 503 minecraft:brown_terracotta
setblock 260 111 466 minecraft:bone_block
setblock 260 111 502 minecraft:brown_terracotta
fill 260 111 504 261 111 504 minecraft:brown_terracotta
setblock 260 111 505 minecraft:black_concrete
setblock 261 111 465 minecraft:bone_block
fill 261 111 466 261 112 466 minecraft:brown_terracotta
fill 261 111 505 265 204 505 minecraft:brown_terracotta
setblock 262 111 463 minecraft:black_concrete
setblock 262 111 464 minecraft:bone_block
fill 262 111 465 262 113 465 minecraft:brown_terracotta
setblock 262 111 504 minecraft:bone_block
fill 263 111 463 263 114 464 minecraft:brown_terracotta
setblock 263 111 503 minecraft:bone_block
fill 263 111 504 266 111 504 minecraft:brown_terracotta
setblock 264 111 503 minecraft:brown_terracotta
fill 266 111 463 266 208 463 minecraft:brown_terracotta
setblock 266 111 505 minecraft:black_concrete
setblock 267 111 463 minecraft:black_concrete
setblock 267 111 464 minecraft:bone_block
setblock 267 111 504 minecraft:bone_block
fill 267 111 505 269 204 505 minecraft:brown_terracotta
fill 268 111 463 268 111 464 minecraft:brown_terracotta
fill 269 111 463 269 206 463 minecraft:brown_terracotta
setblock 270 111 463 minecraft:black_concrete
fill 271 111 463 273 204 463 minecraft:brown_terracotta
setblock 273 111 464 minecraft:brown_terracotta
setblock 274 111 486 minecraft:brown_terracotta
setblock 274 111 487 minecraft:bone_block
fill 274 111 488 274 113 488 minecraft:brown_terracotta
setblock 275 111 465 minecraft:brown_terracotta
setblock 275 111 466 minecraft:bone_block
fill 275 111 467 275 114 467 minecraft:brown_terracotta
fill 275 111 469 275 111 470 minecraft:brown_terracotta
setblock 275 111 481 minecraft:bone_block
fill 275 111 482 275 113 482 minecraft:brown_terracotta
setblock 275 111 486 minecraft:bone_block
fill 275 111 487 275 114 487 minecraft:brown_terracotta
setblock 275 111 490 minecraft:brown_terracotta
setblock 275 111 491 minecraft:bone_block
fill 275 111 492 275 114 492 minecraft:brown_terracotta
setblock 276 111 465 minecraft:bone_block
fill 276 111 466 276 114 466 minecraft:brown_terracotta
fill 276 111 469 277 111 469 minecraft:brown_terracotta
setblock 276 111 470 minecraft:bone_block
fill 276 111 471 276 111 474 minecraft:brown_terracotta
setblock 276 111 475 minecraft:bone_block
fill 276 111 476 276 114 476 minecraft:brown_terracotta
setblock 276 111 480 minecraft:bone_block
fill 276 111 481 276 114 481 minecraft:brown_terracotta
fill 276 111 483 276 112 483 minecraft:brown_terracotta
setblock 276 111 485 minecraft:bone_block
fill 276 111 486 276 114 486 minecraft:brown_terracotta
setblock 276 111 490 minecraft:bone_block
fill 276 111 491 276 114 491 minecraft:brown_terracotta
fill 276 111 493 276 111 494 minecraft:brown_terracotta
setblock 276 111 495 minecraft:bone_block
fill 276 111 505 276 208 505 minecraft:brown_terracotta
fill 277 111 463 277 204 463 minecraft:brown_terracotta
fill 277 111 465 277 208 465 minecraft:brown_terracotta
fill 277 111 468 277 208 468 minecraft:brown_terracotta
fill 277 111 470 277 204 470 minecraft:brown_terracotta
fill 277 111 482 277 208 482 minecraft:brown_terracotta
setblock 277 111 483 minecraft:black_concrete
setblock 277 111 487 minecraft:black_concrete
fill 277 111 493 277 208 493 minecraft:brown_terracotta
setblock 277 111 494 minecraft:black_concrete
fill 277 111 495 277 208 495 minecraft:brown_terracotta
fill 235 112 464 235 204 464 minecraft:brown_terracotta
fill 235 112 483 236 112 483 minecraft:brown_terracotta
fill 235 112 500 235 208 500 minecraft:brown_terracotta
fill 235 112 503 235 205 504 minecraft:brown_terracotta
setblock 236 112 464 minecraft:bone_block
fill 236 112 465 239 112 465 minecraft:brown_terracotta
setblock 236 112 469 minecraft:bone_block
fill 236 112 470 236 112 473 minecraft:brown_terracotta
setblock 236 112 474 minecraft:bone_block
fill 236 112 475 236 112 478 minecraft:brown_terracotta
setblock 236 112 479 minecraft:bone_block
fill 236 112 480 237 112 482 minecraft:brown_terracotta
setblock 236 112 484 minecraft:bone_block
fill 236 112 485 236 115 485 minecraft:brown_terracotta
setblock 236 112 489 minecraft:bone_block
fill 236 112 490 236 115 490 minecraft:brown_terracotta
setblock 236 112 494 minecraft:bone_block
setblock 236 112 504 minecraft:bone_block
fill 236 112 505 236 208 505 minecraft:brown_terracotta
fill 237 112 464 240 112 464 minecraft:brown_terracotta
setblock 237 112 468 minecraft:bone_block
fill 237 112 469 237 112 472 minecraft:brown_terracotta
setblock 237 112 473 minecraft:bone_block
fill 237 112 474 237 112 477 minecraft:brown_terracotta
setblock 237 112 478 minecraft:bone_block
setblock 237 112 479 minecraft:brown_terracotta
setblock 237 112 483 minecraft:bone_block
fill 237 112 484 237 113 484 minecraft:brown_terracotta
setblock 237 112 488 minecraft:bone_block
fill 237 112 489 237 115 489 minecraft:brown_terracotta
setblock 237 112 492 minecraft:brown_terracotta
fill 237 112 504 240 112 504 minecraft:brown_terracotta
setblock 238 112 467 minecraft:bone_block
fill 238 112 468 239 114 468 minecraft:brown_terracotta
setblock 238 112 471 minecraft:brown_terracotta
setblock 238 112 472 minecraft:bone_block
fill 238 112 473 238 115 473 minecraft:brown_terracotta
setblock 238 112 487 minecraft:bone_block
setblock 238 112 488 minecraft:brown_terracotta
setblock 239 112 466 minecraft:bone_block
fill 239 112 467 239 115 467 minecraft:brown_terracotta
setblock 239 112 471 minecraft:bone_block
setblock 240 112 465 minecraft:bone_block
fill 240 112 466 243 112 466 minecraft:brown_terracotta
fill 240 112 503 241 112 503 minecraft:brown_terracotta
fill 241 112 463 241 206 463 minecraft:brown_terracotta
setblock 241 112 464 minecraft:bone_block
fill 241 112 465 241 115 465 minecraft:brown_terracotta
setblock 241 112 504 minecraft:bone_block
fill 242 112 464 245 112 464 minecraft:brown_terracotta
setblock 242 112 503 minecraft:bone_block
fill 242 112 504 245 112 504 minecraft:brown_terracotta
setblock 243 112 467 minecraft:bone_block
setblock 243 112 503 minecraft:brown_terracotta
setblock 244 112 466 minecraft:bone_block
setblock 244 112 467 minecraft:brown_terracotta
fill 245 112 463 245 208 463 minecraft:brown_terracotta
setblock 245 112 465 minecraft:bone_block
fill 245 112 466 245 113 466 minecraft:brown_terracotta
fill 245 112 505 245 208 505 minecraft:brown_terracotta
setblock 246 112 464 minecraft:bone_block
fill 246 112 465 249 112 465 minecraft:brown_terracotta
setblock 246 112 504 minecraft:bone_block
fill 247 112 464 247 115 464 minecraft:brown_terracotta
fill 247 112 504 250 112 504 minecraft:brown_terracotta
setblock 250 112 465 minecraft:bone_block
fill 251 112 463 251 208 463 minecraft:brown_terracotta
setblock 251 112 464 minecraft:bone_block
fill 251 112 465 254 112 465 minecraft:brown_terracotta
setblock 251 112 504 minecraft:bone_block
fill 252 112 464 255 112 464 minecraft:brown_terracotta
fill 252 112 504 255 112 504 minecraft:brown_terracotta
setblock 255 112 465 minecraft:bone_block
fill 255 112 503 256 112 503 minecraft:brown_terracotta
setblock 256 112 464 minecraft:bone_block
fill 256 112 465 256 114 465 minecraft:brown_terracotta
setblock 256 112 504 minecraft:bone_block
fill 257 112 464 260 112 464 minecraft:brown_terracotta
fill 257 112 466 258 112 466 minecraft:brown_terracotta
setblock 257 112 503 minecraft:bone_block
fill 257 112 504 257 115 505 minecraft:brown_terracotta
fill 258 112 503 261 112 503 minecraft:brown_terracotta
setblock 259 112 466 minecraft:bone_block
setblock 260 112 465 minecraft:bone_block
setblock 260 112 466 minecraft:brown_terracotta
fill 260 112 504 260 112 505 minecraft:brown_terracotta
setblock 261 112 464 minecraft:bone_block
fill 261 112 465 261 113 465 minecraft:brown_terracotta
setblock 261 112 504 minecraft:bone_block
fill 262 112 463 262 114 464 minecraft:brown_terracotta
setblock 262 112 503 minecraft:bone_block
fill 262 112 504 265 112 504 minecraft:brown_terracotta
setblock 263 112 503 minecraft:brown_terracotta
fill 265 112 463 265 208 463 minecraft:brown_terracotta
setblock 266 112 464 minecraft:bone_block
setblock 266 112 504 minecraft:bone_block
fill 266 112 505 266 204 505 minecraft:brown_terracotta
fill 267 112 463 268 208 463 minecraft:brown_terracotta
fill 270 112 463 270 209 463 minecraft:brown_terracotta
setblock 274 112 486 minecraft:bone_block
setblock 274 112 487 minecraft:brown_terracotta
fill 275 112 466 275 115 466 minecraft:brown_terracotta
setblock 275 112 469 minecraft:brown_terracotta
setblock 275 112 470 minecraft:bone_block
fill 275 112 471 276 113 472 minecraft:brown_terracotta
setblock 275 112 481 minecraft:brown_terracotta
setblock 275 112 485 minecraft:bone_block
fill 275 112 486 275 115 486 minecraft:brown_terracotta
setblock 275 112 490 minecraft:bone_block
fill 275 112 491 275 115 491 minecraft:brown_terracotta
fill 275 112 493 276 112 493 minecraft:brown_terracotta
setblock 276 112 464 minecraft:bone_block
fill 276 112 465 276 115 465 minecraft:brown_terracotta
setblock 276 112 469 minecraft:bone_block
fill 276 112 470 276 115 470 minecraft:brown_terracotta
setblock 276 112 473 minecraft:brown_terracotta
setblock 276 112 474 minecraft:bone_block
fill 276 112 475 276 115 475 minecraft:brown_terracotta
setblock 276 112 479 minecraft:bone_block
fill 276 112 480 276 115 480 minecraft:brown_terracotta
setblock 276 112 484 minecraft:bone_block
fill 276 112 485 276 115 485 minecraft:brown_terracotta
setblock 276 112 489 minecraft:bone_block
fill 276 112 490 276 115 490 minecraft:brown_terracotta
setblock 276 112 494 minecraft:bone_block
fill 276 112 495 276 115 495 minecraft:brown_terracotta
fill 277 112 469 277 208 469 minecraft:brown_terracotta
fill 277 112 483 277 208 483 minecraft:brown_terracotta
fill 277 112 487 277 206 487 minecraft:brown_terracotta
fill 277 112 494 277 208 494 minecraft:brown_terracotta
fill 277 112 502 277 205 502 minecraft:brown_terracotta
fill 235 113 483 235 169 483 minecraft:brown_terracotta
fill 236 113 464 238 113 465 minecraft:brown_terracotta
setblock 236 113 468 minecraft:bone_block
fill 236 113 469 236 113 472 minecraft:brown_terracotta
setblock 236 113 473 minecraft:bone_block
fill 236 113 474 236 113 477 minecraft:brown_terracotta
setblock 236 113 478 minecraft:bone_block
fill 236 113 479 236 113 482 minecraft:brown_terracotta
setblock 236 113 483 minecraft:bone_block
fill 236 113 484 236 116 484 minecraft:brown_terracotta
setblock 236 113 488 minecraft:bone_block
fill 236 113 489 236 116 489 minecraft:brown_terracotta
setblock 236 113 492 minecraft:brown_terracotta
setblock 236 113 493 minecraft:bone_block
fill 236 113 494 236 116 494 minecraft:brown_terracotta
fill 236 113 504 239 113 504 minecraft:brown_terracotta
setblock 237 113 467 minecraft:bone_block
fill 237 113 468 237 113 471 minecraft:brown_terracotta
setblock 237 113 472 minecraft:bone_block
fill 237 113 473 237 113 476 minecraft:brown_terracotta
setblock 237 113 477 minecraft:bone_block
setblock 237 113 483 minecraft:brown_terracotta
setblock 237 113 487 minecraft:bone_block
fill 237 113 488 237 115 488 minecraft:brown_terracotta
setblock 237 113 492 minecraft:bone_block
setblock 238 113 466 minecraft:bone_block
fill 238 113 467 238 116 467 minecraft:brown_terracotta
setblock 238 113 471 minecraft:bone_block
fill 238 113 472 238 116 472 minecraft:brown_terracotta
setblock 239 113 464 minecraft:brown_terracotta
setblock 239 113 465 minecraft:bone_block
fill 239 113 466 242 113 466 minecraft:brown_terracotta
setblock 239 113 470 minecraft:bone_block
fill 239 113 471 239 115 471 minecraft:brown_terracotta
setblock 240 113 464 minecraft:bone_block
fill 240 113 465 240 116 465 minecraft:brown_terracotta
setblock 240 113 504 minecraft:bone_block
fill 241 113 464 244 113 464 minecraft:brown_terracotta
fill 241 113 504 244 113 504 minecraft:brown_terracotta
setblock 242 113 467 minecraft:bone_block
setblock 243 113 466 minecraft:bone_block
setblock 243 113 467 minecraft:brown_terracotta
setblock 244 113 465 minecraft:bone_block
fill 244 113 466 244 114 466 minecraft:brown_terracotta
setblock 245 113 464 minecraft:bone_block
fill 245 113 465 248 113 465 minecraft:brown_terracotta
setblock 245 113 504 minecraft:bone_block
fill 246 113 464 246 115 464 minecraft:brown_terracotta
fill 246 113 504 248 113 504 minecraft:brown_terracotta
setblock 250 113 464 minecraft:bone_block
setblock 250 113 504 minecraft:bone_block
fill 251 113 464 254 113 464 minecraft:brown_terracotta
fill 251 113 504 254 113 504 minecraft:brown_terracotta
setblock 253 113 465 minecraft:brown_terracotta
setblock 254 113 465 minecraft:bone_block
setblock 255 113 464 minecraft:bone_block
fill 255 113 465 255 114 465 minecraft:brown_terracotta
setblock 255 113 503 minecraft:brown_terracotta
setblock 255 113 504 minecraft:bone_block
fill 256 113 464 259 113 464 minecraft:brown_terracotta
setblock 256 113 503 minecraft:bone_block
fill 256 113 504 256 116 504 minecraft:brown_terracotta
fill 257 113 503 260 113 503 minecraft:brown_terracotta
setblock 259 113 465 minecraft:bone_block
setblock 260 113 464 minecraft:bone_block
fill 260 113 465 260 114 465 minecraft:brown_terracotta
setblock 260 113 504 minecraft:bone_block
fill 260 113 505 260 208 505 minecraft:brown_terracotta
fill 261 113 464 261 115 464 minecraft:brown_terracotta
setblock 261 113 503 minecraft:bone_block
fill 261 113 504 264 113 504 minecraft:brown_terracotta
setblock 262 113 503 minecraft:brown_terracotta
setblock 275 113 464 minecraft:bone_block
setblock 275 113 468 minecraft:brown_terracotta
setblock 275 113 469 minecraft:bone_block
fill 275 113 470 275 116 470 minecraft:brown_terracotta
setblock 275 113 473 minecraft:brown_terracotta
setblock 275 113 484 minecraft:bone_block
fill 275 113 485 275 116 485 minecraft:brown_terracotta
setblock 275 113 489 minecraft:bone_block
fill 275 113 490 275 116 490 minecraft:brown_terracotta
setblock 275 113 493 minecraft:brown_terracotta
fill 276 113 464 276 116 464 minecraft:brown_terracotta
setblock 276 113 468 minecraft:bone_block
fill 276 113 469 276 116 469 minecraft:brown_terracotta
setblock 276 113 473 minecraft:bone_block
fill 276 113 474 276 116 474 minecraft:brown_terracotta
setblock 276 113 478 minecraft:bone_block
fill 276 113 479 276 116 479 minecraft:brown_terracotta
setblock 276 113 483 minecraft:bone_block
fill 276 113 484 276 116 484 minecraft:brown_terracotta
setblock 276 113 488 minecraft:bone_block
fill 276 113 489 276 116 489 minecraft:brown_terracotta
setblock 276 113 493 minecraft:bone_block
fill 276 113 494 276 116 494 minecraft:brown_terracotta
fill 277 113 478 277 208 478 minecraft:brown_terracotta
fill 277 113 488 277 208 488 minecraft:brown_terracotta
fill 236 114 464 237 114 465 minecraft:brown_terracotta
setblock 236 114 467 minecraft:bone_block
fill 236 114 468 236 114 471 minecraft:brown_terracotta
setblock 236 114 472 minecraft:bone_block
fill 236 114 473 236 114 476 minecraft:brown_terracotta
setblock 236 114 477 minecraft:bone_block
fill 236 114 478 236 114 481 minecraft:brown_terracotta
setblock 236 114 482 minecraft:bone_block
fill 236 114 483 236 115 483 minecraft:brown_terracotta
setblock 236 114 487 minecraft:bone_block
fill 236 114 488 236 117 488 minecraft:brown_terracotta
setblock 236 114 492 minecraft:bone_block
fill 236 114 493 236 117 493 minecraft:brown_terracotta
fill 236 114 495 236 115 495 minecraft:brown_terracotta
setblock 237 114 466 minecraft:bone_block
fill 237 114 467 237 114 470 minecraft:brown_terracotta
setblock 237 114 471 minecraft:bone_block
fill 237 114 472 237 114 475 minecraft:brown_terracotta
setblock 237 114 476 minecraft:bone_block
setblock 237 114 486 minecraft:bone_block
setblock 237 114 487 minecraft:brown_terracotta
setblock 237 114 491 minecraft:bone_block
fill 237 114 492 237 117 492 minecraft:brown_terracotta
fill 237 114 504 238 114 504 minecraft:brown_terracotta
setblock 238 114 464 minecraft:brown_terracotta
setblock 238 114 465 minecraft:bone_block
fill 238 114 466 241 114 466 minecraft:brown_terracotta
setblock 238 114 470 minecraft:bone_block
fill 238 114 471 238 117 471 minecraft:brown_terracotta
setblock 239 114 464 minecraft:bone_block
fill 239 114 465 239 117 465 minecraft:brown_terracotta
setblock 239 114 469 minecraft:bone_block
fill 239 114 470 239 117 470 minecraft:brown_terracotta
setblock 239 114 504 minecraft:bone_block
fill 240 114 464 243 114 464 minecraft:brown_terracotta
fill 240 114 504 243 114 504 minecraft:brown_terracotta
setblock 241 114 467 minecraft:bone_block
setblock 242 114 466 minecraft:bone_block
setblock 243 114 465 minecraft:bone_block
setblock 243 114 466 minecraft:brown_terracotta
setblock 244 114 464 minecraft:bone_block
fill 244 114 465 246 114 465 minecraft:brown_terracotta
setblock 244 114 504 minecraft:bone_block
fill 245 114 464 245 116 464 minecraft:brown_terracotta
setblock 245 114 504 minecraft:brown_terracotta
setblock 249 114 464 minecraft:bone_block
fill 250 114 464 253 114 464 minecraft:brown_terracotta
fill 252 114 504 253 114 504 minecraft:brown_terracotta
setblock 254 114 464 minecraft:bone_block
setblock 254 114 504 minecraft:bone_block
fill 255 114 464 258 114 464 minecraft:brown_terracotta
fill 255 114 504 255 117 504 minecraft:brown_terracotta
fill 256 114 503 259 114 503 minecraft:brown_terracotta
setblock 258 114 465 minecraft:bone_block
fill 258 114 504 258 114 505 minecraft:brown_terracotta
setblock 259 114 464 minecraft:bone_block
setblock 259 114 465 minecraft:brown_terracotta
setblock 259 114 504 minecraft:bone_block
fill 259 114 505 259 208 505 minecraft:brown_terracotta
fill 260 114 464 260 116 464 minecraft:brown_terracotta
setblock 260 114 503 minecraft:bone_block
fill 260 114 504 263 114 504 minecraft:brown_terracotta
fill 264 114 463 264 206 463 minecraft:brown_terracotta
fill 274 114 463 274 208 463 minecraft:brown_terracotta
fill 275 114 464 275 117 464 minecraft:brown_terracotta
setblock 275 114 468 minecraft:bone_block
fill 275 114 469 275 117 469 minecraft:brown_terracotta
fill 275 114 471 275 114 472 minecraft:brown_terracotta
setblock 275 114 473 minecraft:bone_block
fill 275 114 474 275 117 474 minecraft:brown_terracotta
setblock 275 114 483 minecraft:bone_block
fill 275 114 484 275 115 484 minecraft:brown_terracotta
setblock 275 114 488 minecraft:bone_block
fill 275 114 489 275 117 489 minecraft:brown_terracotta
setblock 275 114 493 minecraft:bone_block
setblock 276 114 467 minecraft:bone_block
fill 276 114 468 276 117 468 minecraft:brown_terracotta
setblock 276 114 471 minecraft:brown_terracotta
setblock 276 114 472 minecraft:bone_block
fill 276 114 473 276 117 473 minecraft:brown_terracotta
setblock 276 114 477 minecraft:bone_block
fill 276 114 478 276 117 478 minecraft:brown_terracotta
setblock 276 114 482 minecraft:bone_block
fill 276 114 483 276 117 483 minecraft:brown_terracotta
setblock 276 114 487 minecraft:bone_block
fill 276 114 488 276 117 488 minecraft:brown_terracotta
setblock 276 114 492 minecraft:bone_block
fill 276 114 493 276 117 493 minecraft:brown_terracotta
setblock 276 114 496 minecraft:brown_terracotta
fill 235 115 491 235 208 491 minecraft:brown_terracotta
fill 236 115 464 236 115 465 minecraft:brown_terracotta
setblock 236 115 466 minecraft:bone_block
fill 236 115 467 236 115 470 minecraft:brown_terracotta
setblock 236 115 471 minecraft:bone_block
fill 236 115 472 236 115 475 minecraft:brown_terracotta
setblock 236 115 476 minecraft:bone_block
fill 236 115 477 236 115 480 minecraft:brown_terracotta
setblock 236 115 481 minecraft:bone_block
setblock 236 115 482 minecraft:brown_terracotta
setblock 236 115 486 minecraft:bone_block
fill 236 115 487 236 118 487 minecraft:brown_terracotta
setblock 236 115 491 minecraft:bone_block
fill 236 115 492 236 118 492 minecraft:brown_terracotta
setblock 237 115 464 minecraft:brown_terracotta
setblock 237 115 465 minecraft:bone_block
fill 237 115 466 237 115 469 minecraft:brown_terracotta
setblock 237 115 470 minecraft:bone_block
fill 237 115 471 237 115 474 minecraft:brown_terracotta
setblock 237 115 475 minecraft:bone_block
fill 237 115 476 237 118 476 minecraft:brown_terracotta
setblock 237 115 490 minecraft:bone_block
fill 237 115 491 237 118 491 minecraft:brown_terracotta
setblock 237 115 504 minecraft:brown_terracotta
setblock 238 115 464 minecraft:bone_block
fill 238 115 465 238 117 466 minecraft:brown_terracotta
setblock 238 115 468 minecraft:brown_terracotta
setblock 238 115 469 minecraft:bone_block
fill 238 115 470 238 118 470 minecraft:brown_terracotta
setblock 238 115 474 minecraft:bone_block
setblock 238 115 482 minecraft:light[level=12]
setblock 238 115 490 minecraft:light[level=12]
setblock 238 115 498 minecraft:light[level=12]
setblock 238 115 504 minecraft:bone_block
fill 239 115 464 242 115 464 minecraft:brown_terracotta
fill 239 115 466 240 115 466 minecraft:brown_terracotta
setblock 239 115 468 minecraft:bone_block
fill 239 115 469 239 117 469 minecraft:brown_terracotta
fill 239 115 504 242 115 504 minecraft:brown_terracotta
setblock 240 115 467 minecraft:bone_block
setblock 241 115 466 minecraft:bone_block
setblock 242 115 465 minecraft:bone_block
setblock 242 115 466 minecraft:brown_terracotta
setblock 243 115 464 minecraft:bone_block
fill 243 115 465 244 115 465 minecraft:brown_terracotta
setblock 243 115 504 minecraft:bone_block
fill 244 115 464 244 117 464 minecraft:brown_terracotta
setblock 246 115 466 minecraft:light[level=12]
setblock 246 115 474 minecraft:light[level=12]
setblock 246 115 482 minecraft:light[level=12]
setblock 246 115 490 minecraft:light[level=12]
setblock 246 115 498 minecraft:light[level=12]
setblock 252 115 464 minecraft:brown_terracotta
setblock 253 115 464 minecraft:bone_block
setblock 253 115 504 minecraft:bone_block
fill 254 115 464 257 115 464 minecraft:brown_terracotta
setblock 254 115 466 minecraft:light[level=12]
setblock 254 115 474 minecraft:light[level=12]
setblock 254 115 490 minecraft:light[level=12]
setblock 254 115 498 minecraft:light[level=12]
fill 254 115 504 254 118 504 minecraft:brown_terracotta
setblock 257 115 465 minecraft:bone_block
setblock 258 115 464 minecraft:bone_block
setblock 258 115 465 minecraft:brown_terracotta
setblock 258 115 504 minecraft:bone_block
fill 258 115 505 258 205 505 minecraft:brown_terracotta
fill 259 115 464 259 116 464 minecraft:brown_terracotta
fill 259 115 504 261 115 504 minecraft:brown_terracotta
fill 262 115 463 263 204 463 minecraft:brown_terracotta
setblock 262 115 466 minecraft:light[level=12]
setblock 262 115 474 minecraft:light[level=12]
setblock 262 115 482 minecraft:light[level=12]
setblock 262 115 490 minecraft:light[level=12]
setblock 262 115 498 minecraft:light[level=12]
setblock 270 115 466 minecraft:light[level=12]
setblock 270 115 474 minecraft:light[level=12]
setblock 270 115 482 minecraft:light[level=12]
setblock 270 115 490 minecraft:light[level=12]
setblock 270 115 498 minecraft:light[level=12]
setblock 275 115 467 minecraft:bone_block
fill 275 115 468 275 118 468 minecraft:brown_terracotta
setblock 275 115 471 minecraft:brown_terracotta
setblock 275 115 472 minecraft:bone_block
fill 275 115 473 275 118 473 minecraft:brown_terracotta
fill 275 115 475 275 115 476 minecraft:brown_terracotta
setblock 275 115 487 minecraft:bone_block
fill 275 115 488 275 118 488 minecraft:brown_terracotta
setblock 275 115 492 minecraft:bone_block
fill 275 115 493 275 118 493 minecraft:brown_terracotta
setblock 276 115 466 minecraft:bone_block
fill 276 115 467 276 118 467 minecraft:brown_terracotta
setblock 276 115 471 minecraft:bone_block
fill 276 115 472 276 118 472 minecraft:brown_terracotta
setblock 276 115 476 minecraft:bone_block
fill 276 115 477 276 118 477 minecraft:brown_terracotta
setblock 276 115 481 minecraft:bone_block
fill 276 115 482 276 118 482 minecraft:brown_terracotta
setblock 276 115 486 minecraft:bone_block
fill 276 115 487 276 118 487 minecraft:brown_terracotta
setblock 276 115 491 minecraft:bone_block
fill 276 115 492 276 118 492 minecraft:brown_terracotta
setblock 276 115 496 minecraft:bone_block
setblock 236 116 464 minecraft:brown_terracotta
setblock 236 116 465 minecraft:bone_block
fill 236 116 466 236 116 469 minecraft:brown_terracotta
setblock 236 116 470 minecraft:bone_block
fill 236 116 471 236 116 474 minecraft:brown_terracotta
setblock 236 116 475 minecraft:bone_block
fill 236 116 476 236 116 479 minecraft:brown_terracotta
setblock 236 116 480 minecraft:bone_block
setblock 236 116 481 minecraft:brown_terracotta
setblock 236 116 485 minecraft:bone_block
fill 236 116 486 236 119 486 minecraft:brown_terracotta
setblock 236 116 490 minecraft:bone_block
fill 236 116 491 236 119 491 minecraft:brown_terracotta
setblock 236 116 495 minecraft:bone_block
fill 236 116 496 236 119 496 minecraft:brown_terracotta
setblock 237 116 464 minecraft:bone_block
fill 237 116 465 237 116 468 minecraft:brown_terracotta
setblock 237 116 469 minecraft:bone_block
fill 237 116 470 237 116 473 minecraft:brown_terracotta
setblock 237 116 474 minecraft:bone_block
fill 237 116 475 237 119 475 minecraft:brown_terracotta
fill 237 116 477 237 117 477 minecraft:brown_terracotta
setblock 237 116 489 minecraft:bone_block
fill 237 116 490 237 117 490 minecraft:brown_terracotta
setblock 237 116 493 minecraft:brown_terracotta
setblock 237 116 504 minecraft:bone_block
fill 238 116 464 241 116 464 minecraft:brown_terracotta
setblock 238 116 468 minecraft:bone_block
fill 238 116 469 238 119 469 minecraft:brown_terracotta
setblock 238 116 473 minecraft:bone_block
fill 238 116 474 238 119 474 minecraft:brown_terracotta
fill 238 116 504 241 116 504 minecraft:brown_terracotta
setblock 239 116 466 minecraft:brown_terracotta
setblock 239 116 468 minecraft:brown_terracotta
setblock 240 116 466 minecraft:bone_block
setblock 241 116 465 minecraft:bone_block
setblock 241 116 466 minecraft:brown_terracotta
setblock 242 116 464 minecraft:bone_block
fill 242 116 465 243 116 465 minecraft:brown_terracotta
fill 243 116 464 243 119 464 minecraft:brown_terracotta
fill 253 116 464 256 116 464 minecraft:brown_terracotta
fill 253 116 504 253 119 504 minecraft:brown_terracotta
setblock 257 116 464 minecraft:bone_block
setblock 257 116 504 minecraft:bone_block
fill 257 116 505 257 205 505 minecraft:brown_terracotta
fill 258 116 464 258 117 464 minecraft:brown_terracotta
fill 258 116 504 260 116 504 minecraft:brown_terracotta
setblock 275 116 466 minecraft:bone_block
fill 275 116 467 275 119 467 minecraft:brown_terracotta
setblock 275 116 471 minecraft:bone_block
fill 275 116 472 275 119 472 minecraft:brown_terracotta
setblock 275 116 475 minecraft:brown_terracotta
setblock 275 116 476 minecraft:bone_block
fill 275 116 477 275 119 477 minecraft:brown_terracotta
setblock 275 116 486 minecraft:bone_block
fill 275 116 487 275 119 487 minecraft:brown_terracotta
setblock 275 116 491 minecraft:bone_block
fill 275 116 492 275 119 492 minecraft:brown_terracotta
fill 275 116 494 275 117 494 minecraft:brown_terracotta
setblock 276 116 465 minecraft:bone_block
fill 276 116 466 276 119 466 minecraft:brown_terracotta
setblock 276 116 470 minecraft:bone_block
fill 276 116 471 276 119 471 minecraft:brown_terracotta
setblock 276 116 475 minecraft:bone_block
fill 276 116 476 276 119 476 minecraft:brown_terracotta
setblock 276 116 480 minecraft:bone_block
fill 276 116 481 276 119 481 minecraft:brown_terracotta
setblock 276 116 485 minecraft:bone_block
fill 276 116 486 276 119 486 minecraft:brown_terracotta
setblock 276 116 490 minecraft:bone_block
fill 276 116 491 276 119 491 minecraft:brown_terracotta
setblock 276 116 495 minecraft:bone_block
fill 276 116 496 276 119 496 minecraft:brown_terracotta
setblock 236 117 464 minecraft:bone_block
fill 236 117 465 236 117 468 minecraft:brown_terracotta
setblock 236 117 469 minecraft:bone_block
fill 236 117 470 236 117 473 minecraft:brown_terracotta
setblock 236 117 474 minecraft:bone_block
fill 236 117 475 236 117 478 minecraft:brown_terracotta
setblock 236 117 479 minecraft:bone_block
fill 236 117 480 236 120 480 minecraft:brown_terracotta
setblock 236 117 485 minecraft:brown_terracotta
setblock 236 117 489 minecraft:bone_block
fill 236 117 490 236 120 490 minecraft:brown_terracotta
setblock 236 117 494 minecraft:bone_block
fill 236 117 495 236 120 495 minecraft:brown_terracotta
fill 236 117 497 236 117 498 minecraft:brown_terracotta
fill 237 117 464 237 117 467 minecraft:brown_terracotta
setblock 237 117 468 minecraft:bone_block
fill 237 117 469 237 117 472 minecraft:brown_terracotta
setblock 237 117 473 minecraft:bone_block
fill 237 117 474 237 120 474 minecraft:brown_terracotta
setblock 237 117 493 minecraft:bone_block
fill 237 117 494 237 120 494 minecraft:brown_terracotta
fill 237 117 504 240 117 504 minecraft:brown_terracotta
fill 238 117 464 240 117 464 minecraft:brown_terracotta
setblock 238 117 467 minecraft:bone_block
fill 238 117 468 238 120 468 minecraft:brown_terracotta
setblock 238 117 472 minecraft:bone_block
fill 238 117 473 238 120 473 minecraft:brown_terracotta
setblock 239 117 466 minecraft:bone_block
setblock 240 117 465 minecraft:bone_block
setblock 240 117 466 minecraft:brown_terracotta
setblock 241 117 464 minecraft:bone_block
fill 241 117 465 242 117 465 minecraft:brown_terracotta
fill 242 117 464 242 120 464 minecraft:brown_terracotta
fill 254 117 464 255 117 464 minecraft:brown_terracotta
setblock 256 117 464 minecraft:bone_block
setblock 256 117 504 minecraft:bone_block
fill 257 117 464 257 119 464 minecraft:brown_terracotta
fill 257 117 504 259 118 504 minecraft:brown_terracotta
setblock 274 117 470 minecraft:brown_terracotta
setblock 274 117 471 minecraft:bone_block
fill 274 117 472 274 119 473 minecraft:brown_terracotta
fill 275 117 466 275 120 466 minecraft:brown_terracotta
setblock 275 117 470 minecraft:bone_block
fill 275 117 471 275 120 471 minecraft:brown_terracotta
setblock 275 117 475 minecraft:bone_block
fill 275 117 476 275 120 476 minecraft:brown_terracotta
fill 275 117 478 275 117 479 minecraft:brown_terracotta
setblock 275 117 485 minecraft:bone_block
fill 275 117 486 275 120 486 minecraft:brown_terracotta
setblock 275 117 490 minecraft:bone_block
fill 275 117 491 275 120 491 minecraft:brown_terracotta
setblock 276 117 464 minecraft:bone_block
fill 276 117 465 276 120 465 minecraft:brown_terracotta
setblock 276 117 469 minecraft:bone_block
fill 276 117 470 276 120 470 minecraft:brown_terracotta
setblock 276 117 474 minecraft:bone_block
fill 276 117 475 276 120 475 minecraft:brown_terracotta
setblock 276 117 479 minecraft:bone_block
fill 276 117 480 276 120 480 minecraft:brown_terracotta
setblock 276 117 484 minecraft:bone_block
fill 276 117 485 276 120 485 minecraft:brown_terracotta
setblock 276 117 489 minecraft:bone_block
fill 276 117 490 276 120 490 minecraft:brown_terracotta
setblock 276 117 494 minecraft:bone_block
fill 276 117 495 276 120 495 minecraft:brown_terracotta
fill 276 117 497 276 118 497 minecraft:brown_terracotta
fill 236 118 464 236 118 467 minecraft:brown_terracotta
setblock 236 118 468 minecraft:bone_block
fill 236 118 469 236 118 472 minecraft:brown_terracotta
setblock 236 118 473 minecraft:bone_block
fill 236 118 474 236 118 477 minecraft:brown_terracotta
setblock 236 118 478 minecraft:bone_block
fill 236 118 479 236 121 479 minecraft:brown_terracotta
fill 236 118 481 236 119 481 minecraft:brown_terracotta
setblock 236 118 488 minecraft:bone_block
fill 236 118 489 236 121 489 minecraft:brown_terracotta
setblock 236 118 493 minecraft:bone_block
fill 236 118 494 236 121 494 minecraft:brown_terracotta
setblock 236 118 497 minecraft:brown_terracotta
setblock 236 118 498 minecraft:bone_block
fill 236 118 499 236 119 501 minecraft:brown_terracotta
setblock 236 118 503 minecraft:bone_block
fill 236 118 504 239 118 504 minecraft:brown_terracotta
fill 237 118 464 237 118 466 minecraft:brown_terracotta
setblock 237 118 467 minecraft:bone_block
fill 237 118 468 237 118 471 minecraft:brown_terracotta
setblock 237 118 472 minecraft:bone_block
fill 237 118 473 237 121 473 minecraft:brown_terracotta
setblock 237 118 477 minecraft:bone_block
fill 237 118 478 237 121 478 minecraft:brown_terracotta
setblock 237 118 492 minecraft:bone_block
fill 237 118 493 237 121 493 minecraft:brown_terracotta
fill 237 118 495 237 118 496 minecraft:brown_terracotta
fill 238 118 464 238 118 465 minecraft:brown_terracotta
setblock 238 118 466 minecraft:bone_block
fill 238 118 467 238 121 467 minecraft:brown_terracotta
setblock 238 118 471 minecraft:bone_block
fill 238 118 472 238 121 472 minecraft:brown_terracotta
setblock 238 118 475 minecraft:brown_terracotta
setblock 239 118 464 minecraft:brown_terracotta
setblock 239 118 465 minecraft:bone_block
setblock 239 118 466 minecraft:brown_terracotta
setblock 240 118 464 minecraft:bone_block
fill 240 118 465 241 119 465 minecraft:brown_terracotta
setblock 240 118 504 minecraft:bone_block
fill 241 118 464 241 121 464 minecraft:brown_terracotta
fill 252 118 504 252 120 504 minecraft:brown_terracotta
setblock 254 118 464 minecraft:brown_terracotta
setblock 255 118 464 minecraft:bone_block
setblock 255 118 504 minecraft:bone_block
fill 256 118 464 256 121 464 minecraft:brown_terracotta
fill 256 118 504 256 121 504 minecraft:brown_terracotta
setblock 274 118 469 minecraft:brown_terracotta
setblock 274 118 470 minecraft:bone_block
fill 274 118 471 274 121 471 minecraft:brown_terracotta
setblock 274 118 474 minecraft:brown_terracotta
setblock 274 118 475 minecraft:bone_block
fill 274 118 476 274 121 476 minecraft:brown_terracotta
setblock 275 118 464 minecraft:bone_block
setblock 275 118 469 minecraft:bone_block
fill 275 118 470 275 121 470 minecraft:brown_terracotta
setblock 275 118 474 minecraft:bone_block
fill 275 118 475 275 121 475 minecraft:brown_terracotta
setblock 275 118 478 minecraft:brown_terracotta
setblock 275 118 479 minecraft:bone_block
fill 275 118 480 275 121 480 minecraft:brown_terracotta
setblock 275 118 489 minecraft:bone_block
fill 275 118 490 275 121 490 minecraft:brown_terracotta
setblock 275 118 494 minecraft:bone_block
fill 275 118 495 275 121 495 minecraft:brown_terracotta
fill 276 118 464 276 121 464 minecraft:brown_terracotta
setblock 276 118 468 minecraft:bone_block
fill 276 118 469 276 121 469 minecraft:brown_terracotta
setblock 276 118 473 minecraft:bone_block
fill 276 118 474 276 121 474 minecraft:brown_terracotta
setblock 276 118 478 minecraft:bone_block
fill 276 118 479 276 121 479 minecraft:brown_terracotta
setblock 276 118 483 minecraft:bone_block
fill 276 118 484 276 121 484 minecraft:brown_terracotta
setblock 276 118 488 minecraft:bone_block
fill 276 118 489 276 121 489 minecraft:brown_terracotta
setblock 276 118 493 minecraft:bone_block
fill 276 118 494 276 121 494 minecraft:brown_terracotta
setblock 276 118 498 minecraft:bone_block
fill 236 119 464 236 119 466 minecraft:brown_terracotta
setblock 236 119 467 minecraft:bone_block
fill 236 119 468 236 119 471 minecraft:brown_terracotta
setblock 236 119 472 minecraft:bone_block
fill 236 119 473 236 119 476 minecraft:brown_terracotta
setblock 236 119 477 minecraft:bone_block
fill 236 119 478 236 122 478 minecraft:brown_terracotta
setblock 236 119 482 minecraft:bone_block
setblock 236 119 487 minecraft:bone_block
fill 236 119 488 236 122 488 minecraft:brown_terracotta
setblock 236 119 492 minecraft:bone_block
fill 236 119 493 236 122 493 minecraft:brown_terracotta
setblock 236 119 497 minecraft:bone_block
fill 236 119 498 237 121 498 minecraft:brown_terracotta
setblock 236 119 502 minecraft:bone_block
schedule function dropper:buildpart/113_4 1t
