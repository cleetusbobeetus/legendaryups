fill 141 244 582 141 307 583 minecraft:black_concrete
fill 141 244 586 141 269 586 minecraft:black_concrete
setblock 141 244 587 minecraft:shroomlight
fill 141 244 593 141 254 596 minecraft:black_concrete
fill 141 244 597 141 245 597 minecraft:gold_block
fill 141 244 598 141 257 598 minecraft:black_concrete
fill 145 244 557 145 245 557 minecraft:gold_block
fill 148 244 599 154 248 599 minecraft:black_concrete
fill 152 244 557 152 246 557 minecraft:black_concrete
fill 154 244 557 160 259 557 minecraft:black_concrete
fill 155 244 599 155 245 599 minecraft:gold_block
fill 156 244 599 159 264 599 minecraft:black_concrete
fill 161 244 557 161 245 557 minecraft:gold_block
fill 162 244 557 162 307 557 minecraft:black_concrete
fill 166 244 557 166 259 557 minecraft:black_concrete
fill 171 244 599 171 245 599 minecraft:gold_block
fill 172 244 599 174 295 599 minecraft:black_concrete
fill 177 244 557 177 245 557 minecraft:gold_block
fill 178 244 557 178 249 557 minecraft:black_concrete
fill 181 244 599 181 246 599 minecraft:black_concrete
fill 182 244 557 182 306 557 minecraft:black_concrete
fill 183 244 563 183 307 563 minecraft:black_concrete
fill 183 244 567 183 245 567 minecraft:gold_block
fill 183 244 576 183 293 576 minecraft:black_concrete
fill 183 244 579 183 306 579 minecraft:black_concrete
fill 183 244 581 183 285 582 minecraft:black_concrete
fill 183 244 583 183 245 583 minecraft:gold_block
fill 183 244 584 183 244 586 minecraft:black_concrete
fill 183 244 590 183 251 590 minecraft:black_concrete
fill 183 244 595 183 267 595 minecraft:black_concrete
fill 141 245 587 141 249 587 minecraft:black_concrete
setblock 183 245 584 minecraft:shroomlight
fill 183 245 585 183 259 586 minecraft:black_concrete
fill 141 246 565 141 251 565 minecraft:black_concrete
fill 141 246 581 141 251 581 minecraft:black_concrete
fill 141 246 597 141 251 597 minecraft:black_concrete
fill 145 246 557 145 251 557 minecraft:black_concrete
fill 155 246 599 155 251 599 minecraft:black_concrete
fill 161 246 557 161 251 557 minecraft:black_concrete
fill 163 246 599 164 263 599 minecraft:black_concrete
setblock 165 246 599 minecraft:shroomlight
fill 171 246 599 171 251 599 minecraft:black_concrete
fill 177 246 557 177 251 557 minecraft:black_concrete
fill 183 246 557 183 307 558 minecraft:black_concrete
fill 183 246 559 183 246 560 minecraft:shroomlight
fill 183 246 561 183 251 562 minecraft:black_concrete
fill 183 246 567 183 251 567 minecraft:black_concrete
setblock 183 246 577 minecraft:white_concrete
fill 183 246 578 183 293 578 minecraft:black_concrete
fill 183 246 583 183 251 584 minecraft:black_concrete
setblock 152 247 557 minecraft:shroomlight
fill 165 247 599 165 293 599 minecraft:black_concrete
setblock 181 247 599 minecraft:shroomlight
fill 183 247 559 183 253 560 minecraft:black_concrete
fill 183 247 577 183 307 577 minecraft:black_concrete
fill 152 248 557 152 249 557 minecraft:black_concrete
fill 181 248 599 181 251 599 minecraft:black_concrete
fill 148 249 599 152 264 599 minecraft:black_concrete
setblock 153 249 599 minecraft:white_concrete
fill 154 249 599 154 307 599 minecraft:black_concrete
fill 141 250 587 141 251 587 minecraft:white_concrete
setblock 144 250 560 minecraft:light[level=14]
setblock 144 250 568 minecraft:light[level=14]
setblock 144 250 576 minecraft:light[level=14]
setblock 144 250 584 minecraft:light[level=14]
setblock 144 250 592 minecraft:light[level=14]
fill 152 250 557 152 251 557 minecraft:shroomlight
setblock 152 250 560 minecraft:light[level=14]
setblock 152 250 568 minecraft:light[level=14]
setblock 152 250 576 minecraft:light[level=14]
setblock 152 250 584 minecraft:light[level=14]
setblock 152 250 592 minecraft:light[level=14]
fill 153 250 599 153 262 599 minecraft:black_concrete
setblock 160 250 560 minecraft:light[level=14]
setblock 160 250 568 minecraft:light[level=14]
setblock 160 250 576 minecraft:light[level=14]
setblock 160 250 584 minecraft:light[level=14]
setblock 160 250 592 minecraft:light[level=14]
setblock 168 250 560 minecraft:light[level=14]
setblock 168 250 568 minecraft:light[level=14]
setblock 168 250 576 minecraft:light[level=14]
setblock 168 250 584 minecraft:light[level=14]
setblock 168 250 592 minecraft:light[level=14]
setblock 176 250 560 minecraft:light[level=14]
setblock 176 250 568 minecraft:light[level=14]
setblock 176 250 576 minecraft:light[level=14]
setblock 176 250 584 minecraft:light[level=14]
setblock 176 250 592 minecraft:light[level=14]
setblock 178 250 557 minecraft:white_concrete
fill 183 250 569 183 285 569 minecraft:black_concrete
setblock 183 250 570 minecraft:white_concrete
fill 183 250 571 183 265 572 minecraft:black_concrete
setblock 183 250 573 minecraft:white_concrete
setblock 141 251 566 minecraft:shroomlight
fill 141 251 567 141 275 567 minecraft:black_concrete
fill 141 251 576 141 263 578 minecraft:black_concrete
setblock 141 251 579 minecraft:white_concrete
fill 141 251 580 141 264 580 minecraft:black_concrete
setblock 168 251 599 minecraft:shroomlight
fill 169 251 599 170 259 599 minecraft:black_concrete
fill 176 251 599 177 269 599 minecraft:black_concrete
fill 178 251 557 178 269 557 minecraft:black_concrete
setblock 178 251 599 minecraft:white_concrete
fill 179 251 599 180 267 599 minecraft:black_concrete
fill 183 251 570 183 307 570 minecraft:black_concrete
setblock 183 251 573 minecraft:black_concrete
fill 141 252 565 141 254 565 minecraft:gold_block
fill 141 252 566 141 275 566 minecraft:black_concrete
fill 141 252 579 141 260 579 minecraft:black_concrete
fill 141 252 581 141 254 581 minecraft:gold_block
fill 141 252 587 141 307 587 minecraft:black_concrete
fill 141 252 597 141 254 597 minecraft:gold_block
fill 145 252 557 145 254 557 minecraft:gold_block
fill 152 252 557 152 268 557 minecraft:black_concrete
fill 155 252 599 155 254 599 minecraft:gold_block
fill 161 252 557 161 254 557 minecraft:gold_block
fill 168 252 599 168 271 599 minecraft:black_concrete
fill 171 252 599 171 254 599 minecraft:gold_block
fill 177 252 557 177 254 557 minecraft:gold_block
fill 178 252 599 178 307 599 minecraft:black_concrete
setblock 181 252 599 minecraft:shroomlight
setblock 183 252 561 minecraft:white_concrete
fill 183 252 562 183 263 562 minecraft:black_concrete
fill 183 252 567 183 254 567 minecraft:gold_block
setblock 183 252 573 minecraft:shroomlight
fill 183 252 583 183 254 583 minecraft:gold_block
fill 183 252 584 183 300 584 minecraft:black_concrete
setblock 183 252 590 minecraft:shroomlight
fill 141 253 584 141 275 584 minecraft:black_concrete
setblock 141 253 585 minecraft:white_concrete
fill 167 253 557 168 270 557 minecraft:black_concrete
setblock 169 253 557 minecraft:shroomlight
fill 170 253 557 172 280 557 minecraft:black_concrete
fill 181 253 599 181 302 599 minecraft:black_concrete
fill 183 253 561 183 307 561 minecraft:black_concrete
setblock 183 253 568 minecraft:shroomlight
fill 183 253 573 183 254 573 minecraft:black_concrete
fill 183 253 590 183 307 590 minecraft:black_concrete
setblock 183 253 596 minecraft:shroomlight
setblock 141 254 563 minecraft:shroomlight
fill 141 254 564 141 292 564 minecraft:black_concrete
fill 141 254 585 141 264 585 minecraft:black_concrete
fill 169 254 557 169 303 557 minecraft:black_concrete
fill 183 254 559 183 307 559 minecraft:black_concrete
setblock 183 254 560 minecraft:white_concrete
fill 183 254 568 183 270 568 minecraft:black_concrete
fill 183 254 596 183 257 596 minecraft:black_concrete
fill 141 255 563 141 307 563 minecraft:black_concrete
fill 141 255 565 141 257 565 minecraft:black_concrete
fill 141 255 581 141 260 581 minecraft:black_concrete
fill 141 255 593 141 273 595 minecraft:black_concrete
setblock 141 255 596 minecraft:white_concrete
fill 141 255 597 141 260 597 minecraft:black_concrete
fill 145 255 557 145 260 557 minecraft:black_concrete
fill 155 255 599 155 260 599 minecraft:black_concrete
fill 161 255 557 161 260 557 minecraft:black_concrete
fill 171 255 599 171 260 599 minecraft:black_concrete
fill 177 255 557 177 256 557 minecraft:black_concrete
setblock 182 255 599 minecraft:white_concrete
fill 183 255 560 183 279 560 minecraft:black_concrete
fill 183 255 567 183 260 567 minecraft:black_concrete
setblock 183 255 573 minecraft:shroomlight
fill 183 255 583 183 260 583 minecraft:black_concrete
fill 183 255 599 183 307 599 minecraft:black_concrete
fill 141 256 568 141 271 571 minecraft:black_concrete
setblock 141 256 572 minecraft:white_concrete
fill 141 256 596 141 262 596 minecraft:black_concrete
fill 182 256 599 182 307 599 minecraft:black_concrete
fill 183 256 573 183 276 573 minecraft:black_concrete
setblock 183 256 580 minecraft:shroomlight
fill 141 257 559 141 263 560 minecraft:black_concrete
setblock 141 257 561 minecraft:shroomlight
fill 141 257 562 141 292 562 minecraft:black_concrete
fill 141 257 572 141 272 572 minecraft:black_concrete
setblock 143 257 557 minecraft:white_concrete
fill 144 257 557 144 307 557 minecraft:black_concrete
setblock 177 257 557 minecraft:shroomlight
fill 183 257 580 183 307 580 minecraft:black_concrete
fill 141 258 561 141 307 561 minecraft:black_concrete
setblock 141 258 565 minecraft:shroomlight
setblock 141 258 575 minecraft:shroomlight
setblock 141 258 598 minecraft:shroomlight
fill 143 258 557 143 307 557 minecraft:black_concrete
setblock 144 258 560 minecraft:light[level=14]
setblock 144 258 568 minecraft:light[level=14]
setblock 144 258 576 minecraft:light[level=14]
setblock 144 258 584 minecraft:light[level=14]
setblock 144 258 592 minecraft:light[level=14]
setblock 152 258 560 minecraft:light[level=14]
setblock 152 258 568 minecraft:light[level=14]
setblock 152 258 576 minecraft:light[level=14]
setblock 152 258 584 minecraft:light[level=14]
setblock 152 258 592 minecraft:light[level=14]
setblock 160 258 560 minecraft:light[level=14]
setblock 160 258 568 minecraft:light[level=14]
setblock 160 258 576 minecraft:light[level=14]
setblock 160 258 584 minecraft:light[level=14]
setblock 160 258 592 minecraft:light[level=14]
setblock 168 258 560 minecraft:light[level=14]
setblock 168 258 568 minecraft:light[level=14]
setblock 168 258 576 minecraft:light[level=14]
setblock 168 258 584 minecraft:light[level=14]
setblock 168 258 592 minecraft:light[level=14]
setblock 173 258 557 minecraft:white_concrete
fill 174 258 557 175 276 557 minecraft:black_concrete
setblock 176 258 560 minecraft:light[level=14]
setblock 176 258 568 minecraft:light[level=14]
setblock 176 258 576 minecraft:light[level=14]
setblock 176 258 584 minecraft:light[level=14]
setblock 176 258 592 minecraft:light[level=14]
fill 177 258 557 177 260 557 minecraft:black_concrete
setblock 183 258 596 minecraft:shroomlight
fill 141 259 565 141 260 565 minecraft:black_concrete
fill 141 259 575 141 307 575 minecraft:black_concrete
fill 141 259 598 141 283 598 minecraft:black_concrete
fill 173 259 557 173 307 557 minecraft:black_concrete
fill 183 259 596 183 278 596 minecraft:black_concrete
fill 154 260 557 154 283 557 minecraft:black_concrete
setblock 155 260 557 minecraft:shroomlight
fill 156 260 557 158 263 557 minecraft:black_concrete
setblock 159 260 557 minecraft:white_concrete
fill 160 260 557 160 307 557 minecraft:black_concrete
setblock 166 260 557 minecraft:shroomlight
fill 169 260 599 169 307 599 minecraft:black_concrete
setblock 170 260 599 minecraft:shroomlight
fill 183 260 585 183 273 585 minecraft:black_concrete
setblock 183 260 586 minecraft:shroomlight
fill 183 260 587 183 279 587 minecraft:black_concrete
setblock 183 260 588 minecraft:shroomlight
fill 183 260 589 183 307 589 minecraft:black_concrete
fill 141 261 565 141 263 565 minecraft:gold_block
setblock 141 261 579 minecraft:white_concrete
fill 141 261 581 141 263 581 minecraft:gold_block
fill 141 261 597 141 263 597 minecraft:gold_block
fill 145 261 557 145 263 557 minecraft:gold_block
fill 155 261 557 155 307 557 minecraft:black_concrete
fill 155 261 599 155 263 599 minecraft:gold_block
fill 159 261 557 159 307 557 minecraft:black_concrete
fill 161 261 557 161 263 557 minecraft:gold_block
fill 166 261 557 166 307 557 minecraft:black_concrete
fill 170 261 599 170 291 599 minecraft:black_concrete
fill 171 261 599 171 263 599 minecraft:gold_block
fill 177 261 557 177 263 557 minecraft:gold_block
fill 183 261 567 183 263 567 minecraft:gold_block
fill 183 261 583 183 263 583 minecraft:gold_block
fill 183 261 586 183 298 586 minecraft:black_concrete
fill 183 261 588 183 280 588 minecraft:black_concrete
fill 141 262 579 141 275 579 minecraft:black_concrete
fill 141 262 599 141 307 599 minecraft:black_concrete
setblock 142 262 599 minecraft:shroomlight
fill 143 262 599 147 264 599 minecraft:black_concrete
fill 183 262 564 183 297 564 minecraft:black_concrete
setblock 183 262 565 minecraft:shroomlight
fill 141 263 589 141 307 590 minecraft:black_concrete
setblock 141 263 591 minecraft:shroomlight
fill 141 263 592 141 272 592 minecraft:black_concrete
setblock 141 263 596 minecraft:white_concrete
fill 142 263 599 142 307 599 minecraft:black_concrete
setblock 153 263 599 minecraft:shroomlight
fill 183 263 565 183 307 565 minecraft:black_concrete
setblock 141 264 559 minecraft:white_concrete
fill 141 264 560 141 268 560 minecraft:black_concrete
fill 141 264 565 141 266 565 minecraft:black_concrete
setblock 141 264 576 minecraft:shroomlight
fill 141 264 577 141 270 578 minecraft:black_concrete
fill 141 264 581 141 269 581 minecraft:black_concrete
fill 141 264 591 141 307 591 minecraft:black_concrete
fill 141 264 596 141 269 597 minecraft:black_concrete
setblock 142 264 557 minecraft:shroomlight
setblock 145 264 557 minecraft:white_concrete
fill 153 264 599 153 306 599 minecraft:black_concrete
fill 155 264 599 155 269 599 minecraft:black_concrete
setblock 156 264 557 minecraft:white_concrete
fill 157 264 557 158 299 557 minecraft:black_concrete
fill 161 264 557 161 269 557 minecraft:black_concrete
fill 163 264 599 163 282 599 minecraft:black_concrete
setblock 164 264 599 minecraft:shroomlight
fill 171 264 599 171 269 599 minecraft:black_concrete
fill 177 264 557 177 269 557 minecraft:black_concrete
setblock 183 264 562 minecraft:shroomlight
fill 183 264 567 183 269 567 minecraft:black_concrete
fill 183 264 583 183 269 583 minecraft:black_concrete
fill 141 265 559 141 294 559 minecraft:black_concrete
fill 141 265 576 141 278 576 minecraft:black_concrete
setblock 141 265 580 minecraft:shroomlight
setblock 141 265 585 minecraft:shroomlight
fill 142 265 557 142 307 557 minecraft:black_concrete
fill 143 265 599 146 267 599 minecraft:black_concrete
fill 145 265 557 145 267 557 minecraft:black_concrete
setblock 147 265 599 minecraft:shroomlight
fill 148 265 599 148 270 599 minecraft:black_concrete
setblock 149 265 599 minecraft:shroomlight
fill 150 265 599 151 300 599 minecraft:black_concrete
setblock 152 265 599 minecraft:white_concrete
fill 156 265 557 156 296 557 minecraft:black_concrete
fill 156 265 599 158 299 599 minecraft:black_concrete
setblock 159 265 599 minecraft:shroomlight
fill 164 265 599 164 295 599 minecraft:black_concrete
fill 183 265 562 183 272 562 minecraft:black_concrete
setblock 141 266 580 minecraft:black_concrete
fill 141 266 585 141 307 585 minecraft:black_concrete
setblock 144 266 560 minecraft:light[level=14]
setblock 144 266 568 minecraft:light[level=14]
setblock 144 266 576 minecraft:light[level=14]
setblock 144 266 584 minecraft:light[level=14]
setblock 144 266 592 minecraft:light[level=14]
fill 147 266 599 147 278 599 minecraft:black_concrete
fill 149 266 599 149 307 599 minecraft:black_concrete
setblock 152 266 560 minecraft:light[level=14]
setblock 152 266 568 minecraft:light[level=14]
setblock 152 266 576 minecraft:light[level=14]
setblock 152 266 584 minecraft:light[level=14]
setblock 152 266 592 minecraft:light[level=14]
fill 152 266 599 152 307 599 minecraft:black_concrete
fill 159 266 599 159 295 599 minecraft:black_concrete
setblock 160 266 560 minecraft:light[level=14]
setblock 160 266 568 minecraft:light[level=14]
setblock 160 266 576 minecraft:light[level=14]
setblock 160 266 584 minecraft:light[level=14]
setblock 160 266 592 minecraft:light[level=14]
setblock 168 266 560 minecraft:light[level=14]
setblock 168 266 568 minecraft:light[level=14]
setblock 168 266 576 minecraft:light[level=14]
setblock 168 266 584 minecraft:light[level=14]
setblock 168 266 592 minecraft:light[level=14]
setblock 176 266 560 minecraft:light[level=14]
setblock 176 266 568 minecraft:light[level=14]
setblock 176 266 576 minecraft:light[level=14]
setblock 176 266 584 minecraft:light[level=14]
setblock 176 266 592 minecraft:light[level=14]
setblock 183 266 571 minecraft:white_concrete
fill 183 266 572 183 301 572 minecraft:black_concrete
setblock 141 267 565 minecraft:white_concrete
setblock 141 267 580 minecraft:shroomlight
fill 183 267 571 183 307 571 minecraft:black_concrete
fill 183 267 597 183 286 597 minecraft:black_concrete
setblock 183 267 598 minecraft:shroomlight
fill 141 268 565 141 269 565 minecraft:black_concrete
fill 141 268 580 141 307 580 minecraft:black_concrete
fill 143 268 599 144 283 599 minecraft:black_concrete
setblock 145 268 557 minecraft:shroomlight
fill 145 268 599 145 269 599 minecraft:white_concrete
fill 146 268 599 146 307 599 minecraft:black_concrete
fill 149 268 557 149 307 557 minecraft:black_concrete
setblock 150 268 557 minecraft:shroomlight
fill 151 268 557 151 279 557 minecraft:black_concrete
setblock 160 268 599 minecraft:shroomlight
setblock 179 268 599 minecraft:black_concrete
setblock 180 268 599 minecraft:shroomlight
setblock 183 268 595 minecraft:white_concrete
fill 183 268 598 183 307 598 minecraft:black_concrete
setblock 141 269 560 minecraft:shroomlight
setblock 145 269 557 minecraft:black_concrete
fill 150 269 557 150 284 557 minecraft:black_concrete
setblock 152 269 557 minecraft:shroomlight
fill 160 269 599 160 278 599 minecraft:black_concrete
setblock 179 269 599 minecraft:white_concrete
fill 180 269 599 180 296 599 minecraft:black_concrete
fill 183 269 595 183 270 595 minecraft:black_concrete
fill 141 270 560 141 307 560 minecraft:black_concrete
fill 141 270 565 141 272 565 minecraft:gold_block
setblock 141 270 574 minecraft:shroomlight
fill 141 270 581 141 272 581 minecraft:gold_block
setblock 141 270 586 minecraft:white_concrete
fill 141 270 596 141 276 596 minecraft:black_concrete
fill 141 270 597 141 272 597 minecraft:gold_block
fill 145 270 557 145 272 557 minecraft:gold_block
fill 145 270 599 145 307 599 minecraft:black_concrete
fill 146 270 557 147 275 557 minecraft:black_concrete
setblock 148 270 557 minecraft:shroomlight
fill 152 270 557 152 307 557 minecraft:black_concrete
fill 155 270 599 155 272 599 minecraft:gold_block
fill 161 270 557 161 272 557 minecraft:gold_block
fill 171 270 599 171 272 599 minecraft:gold_block
setblock 176 270 599 minecraft:shroomlight
fill 177 270 557 177 272 557 minecraft:gold_block
fill 177 270 599 177 307 599 minecraft:black_concrete
setblock 178 270 557 minecraft:shroomlight
fill 179 270 599 179 307 599 minecraft:black_concrete
fill 183 270 567 183 272 567 minecraft:gold_block
fill 183 270 583 183 272 583 minecraft:gold_block
fill 141 271 574 141 286 574 minecraft:black_concrete
setblock 141 271 577 minecraft:shroomlight
fill 141 271 578 141 307 578 minecraft:black_concrete
fill 141 271 586 141 292 586 minecraft:black_concrete
fill 148 271 557 148 307 557 minecraft:black_concrete
setblock 148 271 599 minecraft:white_concrete
fill 167 271 557 167 307 557 minecraft:black_concrete
setblock 168 271 557 minecraft:white_concrete
fill 176 271 599 176 272 599 minecraft:black_concrete
fill 178 271 557 178 284 557 minecraft:black_concrete
setblock 183 271 568 minecraft:white_concrete
setblock 183 271 595 minecraft:shroomlight
setblock 141 272 568 minecraft:shroomlight
fill 141 272 569 141 290 571 minecraft:black_concrete
fill 141 272 577 141 307 577 minecraft:black_concrete
setblock 148 272 599 minecraft:shroomlight
fill 168 272 557 168 307 557 minecraft:black_concrete
setblock 168 272 599 minecraft:shroomlight
fill 183 272 568 183 307 568 minecraft:black_concrete
fill 183 272 595 183 307 595 minecraft:black_concrete
fill 141 273 565 141 287 565 minecraft:black_concrete
fill 141 273 568 141 281 568 minecraft:black_concrete
setblock 141 273 572 minecraft:shroomlight
fill 141 273 581 141 287 581 minecraft:black_concrete
setblock 141 273 592 minecraft:white_concrete
fill 141 273 597 141 285 597 minecraft:black_concrete
fill 145 273 557 145 287 557 minecraft:black_concrete
fill 148 273 599 148 280 599 minecraft:black_concrete
fill 155 273 599 155 287 599 minecraft:black_concrete
fill 161 273 557 161 287 557 minecraft:black_concrete
fill 168 273 599 168 307 599 minecraft:black_concrete
fill 171 273 599 171 287 599 minecraft:black_concrete
setblock 176 273 599 minecraft:shroomlight
fill 177 273 557 177 278 557 minecraft:black_concrete
setblock 183 273 562 minecraft:shroomlight
fill 183 273 567 183 283 567 minecraft:black_concrete
fill 183 273 583 183 287 583 minecraft:black_concrete
fill 141 274 572 141 298 572 minecraft:black_concrete
setblock 141 274 588 minecraft:shroomlight
fill 141 274 592 141 307 593 minecraft:black_concrete
setblock 141 274 594 minecraft:shroomlight
fill 141 274 595 141 282 595 minecraft:black_concrete
setblock 144 274 560 minecraft:light[level=14]
setblock 144 274 568 minecraft:light[level=14]
setblock 144 274 576 minecraft:light[level=14]
setblock 144 274 584 minecraft:light[level=14]
setblock 144 274 592 minecraft:light[level=14]
setblock 152 274 560 minecraft:light[level=14]
setblock 152 274 568 minecraft:light[level=14]
setblock 152 274 576 minecraft:light[level=14]
setblock 152 274 584 minecraft:light[level=14]
setblock 152 274 592 minecraft:light[level=14]
setblock 160 274 560 minecraft:light[level=14]
setblock 160 274 568 minecraft:light[level=14]
setblock 160 274 576 minecraft:light[level=14]
setblock 160 274 584 minecraft:light[level=14]
setblock 160 274 592 minecraft:light[level=14]
setblock 168 274 560 minecraft:light[level=14]
setblock 168 274 568 minecraft:light[level=14]
setblock 168 274 576 minecraft:light[level=14]
setblock 168 274 584 minecraft:light[level=14]
setblock 168 274 592 minecraft:light[level=14]
setblock 176 274 560 minecraft:light[level=14]
setblock 176 274 568 minecraft:light[level=14]
setblock 176 274 576 minecraft:light[level=14]
setblock 176 274 584 minecraft:light[level=14]
setblock 176 274 592 minecraft:light[level=14]
fill 176 274 599 176 283 599 minecraft:black_concrete
fill 183 274 562 183 307 562 minecraft:black_concrete
setblock 183 274 585 minecraft:white_concrete
fill 141 275 588 141 276 588 minecraft:black_concrete
fill 141 275 594 141 307 594 minecraft:black_concrete
fill 183 275 585 183 307 585 minecraft:black_concrete
setblock 141 276 566 minecraft:shroomlight
setblock 141 276 567 minecraft:white_concrete
setblock 141 276 579 minecraft:white_concrete
setblock 141 276 584 minecraft:shroomlight
setblock 146 276 557 minecraft:white_concrete
fill 147 276 557 147 307 557 minecraft:black_concrete
fill 141 277 566 141 303 567 minecraft:black_concrete
fill 141 277 579 141 304 579 minecraft:black_concrete
fill 141 277 584 141 307 584 minecraft:black_concrete
setblock 141 277 588 minecraft:shroomlight
setblock 141 277 596 minecraft:shroomlight
fill 146 277 557 146 291 557 minecraft:black_concrete
fill 174 277 557 174 307 557 minecraft:black_concrete
setblock 175 277 557 minecraft:white_concrete
fill 183 277 573 183 278 573 minecraft:shroomlight
setblock 183 277 574 minecraft:white_concrete
fill 183 277 575 183 287 575 minecraft:black_concrete
fill 141 278 588 141 297 588 minecraft:black_concrete
fill 141 278 596 141 290 596 minecraft:black_concrete
setblock 166 278 599 minecraft:white_concrete
fill 175 278 557 175 307 557 minecraft:black_concrete
fill 183 278 574 183 301 574 minecraft:black_concrete
setblock 141 279 576 minecraft:shroomlight
setblock 147 279 599 minecraft:white_concrete
fill 151 279 577 162 279 577 minecraft:gold_block
fill 152 279 572 152 280 573 minecraft:gold_block
fill 152 279 576 163 279 576 minecraft:gold_block
fill 152 279 579 164 279 580 minecraft:gold_block
setblock 153 279 557 minecraft:white_concrete
fill 153 279 570 174 279 570 minecraft:gold_block
fill 153 279 573 176 279 573 minecraft:gold_block
fill 153 279 582 175 279 583 minecraft:gold_block
fill 154 279 569 154 280 569 minecraft:gold_block
fill 154 279 574 164 279 575 minecraft:gold_block
fill 154 279 578 163 279 578 minecraft:gold_block
fill 154 279 581 178 279 581 minecraft:gold_block
fill 155 279 571 177 279 572 minecraft:gold_block
fill 155 279 585 156 280 586 minecraft:gold_block
fill 156 279 567 157 280 568 minecraft:gold_block
fill 156 279 584 177 279 584 minecraft:gold_block
fill 157 279 569 175 279 569 minecraft:gold_block
fill 157 279 585 173 279 585 minecraft:gold_block
fill 157 279 588 158 280 588 minecraft:gold_block
fill 158 279 568 172 279 568 minecraft:gold_block
fill 158 279 586 171 280 587 minecraft:gold_block
fill 158 279 589 158 280 589 minecraft:gold_block
fill 159 279 565 160 280 567 minecraft:gold_block
fill 160 279 590 161 280 590 minecraft:gold_block
setblock 160 279 599 minecraft:white_concrete
fill 161 279 566 169 280 567 minecraft:gold_block
fill 161 279 588 161 280 589 minecraft:gold_block
fill 162 279 564 163 280 565 minecraft:gold_block
fill 162 279 588 171 280 588 minecraft:gold_block
fill 164 279 589 165 280 590 minecraft:gold_block
fill 165 279 563 165 280 565 minecraft:gold_block
fill 165 279 574 178 279 574 minecraft:gold_block
fill 165 279 580 176 279 580 minecraft:gold_block
fill 165 279 591 165 280 591 minecraft:gold_block
fill 166 279 564 166 280 565 minecraft:gold_block
fill 166 279 575 178 279 575 minecraft:gold_block
fill 166 279 579 176 279 579 minecraft:gold_block
fill 166 279 599 166 307 599 minecraft:black_concrete
fill 167 279 576 176 279 576 minecraft:gold_block
fill 167 279 578 178 279 578 minecraft:gold_block
fill 167 279 589 168 280 590 minecraft:gold_block
fill 168 279 577 179 279 577 minecraft:gold_block
fill 169 279 564 169 280 565 minecraft:gold_block
fill 170 279 564 170 280 564 minecraft:gold_block
fill 170 279 567 172 280 567 minecraft:gold_block
fill 170 279 589 171 280 589 minecraft:gold_block
fill 172 279 565 172 280 566 minecraft:gold_block
fill 172 279 586 174 280 586 minecraft:gold_block
fill 173 279 566 173 280 566 minecraft:gold_block
fill 173 279 587 174 280 587 minecraft:gold_block
fill 174 279 568 175 280 568 minecraft:gold_block
fill 176 279 585 176 280 585 minecraft:gold_block
setblock 177 279 557 minecraft:shroomlight
fill 178 279 582 178 280 582 minecraft:gold_block
fill 183 279 573 183 307 573 minecraft:black_concrete
setblock 183 279 596 minecraft:white_concrete
fill 141 280 576 151 280 576 minecraft:black_concrete
fill 142 280 558 151 280 575 minecraft:black_concrete
fill 142 280 577 150 280 598 minecraft:black_concrete
fill 147 280 599 147 294 599 minecraft:black_concrete
setblock 151 280 557 minecraft:shroomlight
fill 151 280 577 161 280 577 minecraft:gold_block
fill 151 280 578 151 280 598 minecraft:black_concrete
fill 152 280 558 152 280 571 minecraft:black_concrete
fill 152 280 574 153 280 575 minecraft:black_concrete
fill 152 280 576 161 280 576 minecraft:gold_block
fill 152 280 578 153 280 578 minecraft:black_concrete
fill 152 280 579 155 280 580 minecraft:gold_block
fill 152 280 581 152 280 598 minecraft:black_concrete
fill 153 280 557 153 280 569 minecraft:black_concrete
fill 153 280 570 160 280 570 minecraft:gold_block
fill 153 280 571 154 280 572 minecraft:black_concrete
fill 153 280 573 162 280 573 minecraft:gold_block
setblock 153 280 581 minecraft:black_concrete
fill 153 280 582 156 280 583 minecraft:gold_block
fill 153 280 584 154 280 598 minecraft:black_concrete
fill 154 280 558 155 280 568 minecraft:black_concrete
fill 154 280 574 162 280 575 minecraft:gold_block
fill 154 280 578 155 280 578 minecraft:gold_block
fill 154 280 581 156 280 581 minecraft:gold_block
fill 155 280 569 156 280 569 minecraft:black_concrete
fill 155 280 571 161 280 572 minecraft:gold_block
setblock 155 280 584 minecraft:black_concrete
fill 155 280 587 156 280 598 minecraft:black_concrete
fill 156 280 558 158 280 566 minecraft:black_concrete
fill 156 280 578 161 280 580 minecraft:waxed_cut_copper
fill 156 280 584 158 280 584 minecraft:gold_block
fill 157 280 569 160 280 569 minecraft:gold_block
fill 157 280 581 162 280 582 minecraft:waxed_cut_copper
setblock 157 280 583 minecraft:gold_block
fill 157 280 585 159 280 585 minecraft:gold_block
fill 157 280 586 157 280 587 minecraft:black_concrete
fill 157 280 589 157 280 598 minecraft:black_concrete
setblock 158 280 567 minecraft:black_concrete
fill 158 280 568 161 280 568 minecraft:gold_block
fill 158 280 583 161 280 583 minecraft:waxed_cut_copper
fill 158 280 590 159 280 598 minecraft:black_concrete
fill 159 280 558 161 280 564 minecraft:black_concrete
fill 159 280 584 160 280 584 minecraft:waxed_cut_copper
fill 159 280 588 160 280 589 minecraft:black_concrete
setblock 160 280 585 minecraft:waxed_cut_copper
fill 160 280 591 160 280 599 minecraft:black_concrete
setblock 161 280 565 minecraft:black_concrete
fill 161 280 569 169 280 570 minecraft:waxed_cut_copper
fill 161 280 584 169 280 585 minecraft:gold_block
fill 161 280 591 164 280 598 minecraft:black_concrete
fill 162 280 558 164 280 563 minecraft:black_concrete
fill 162 280 568 168 280 568 minecraft:waxed_cut_copper
fill 162 280 571 168 280 571 minecraft:waxed_cut_copper
setblock 162 280 572 minecraft:gold_block
fill 162 280 576 162 280 578 minecraft:shroomlight
fill 162 280 579 162 280 580 minecraft:waxed_cut_copper
fill 162 280 583 168 280 583 minecraft:gold_block
fill 162 280 589 163 280 590 minecraft:black_concrete
fill 163 280 572 167 280 573 minecraft:waxed_cut_copper
setblock 163 280 574 minecraft:gold_block
fill 163 280 575 163 280 576 minecraft:shroomlight
fill 163 280 578 163 280 579 minecraft:shroomlight
setblock 163 280 580 minecraft:waxed_cut_copper
fill 163 280 581 167 280 582 minecraft:gold_block
fill 164 280 564 164 280 565 minecraft:black_concrete
fill 164 280 574 164 280 575 minecraft:shroomlight
fill 164 280 579 164 280 580 minecraft:shroomlight
fill 165 280 558 182 280 562 minecraft:black_concrete
fill 165 280 574 166 280 574 minecraft:shroomlight
fill 165 280 580 166 280 580 minecraft:shroomlight
fill 165 280 592 182 280 598 minecraft:black_concrete
fill 166 280 563 182 280 563 minecraft:black_concrete
fill 166 280 575 167 280 575 minecraft:shroomlight
fill 166 280 579 167 280 579 minecraft:shroomlight
fill 166 280 589 166 280 591 minecraft:black_concrete
fill 167 280 564 168 280 565 minecraft:black_concrete
fill 167 280 574 178 280 574 minecraft:gold_block
fill 167 280 576 168 280 576 minecraft:shroomlight
fill 167 280 578 168 280 578 minecraft:shroomlight
fill 167 280 580 174 280 580 minecraft:waxed_cut_copper
fill 167 280 591 182 280 591 minecraft:black_concrete
fill 168 280 572 176 280 573 minecraft:gold_block
fill 168 280 575 178 280 575 minecraft:gold_block
setblock 168 280 577 minecraft:shroomlight
fill 168 280 579 174 280 579 minecraft:waxed_cut_copper
fill 168 280 581 173 280 582 minecraft:waxed_cut_copper
fill 169 280 568 172 280 568 minecraft:gold_block
fill 169 280 571 177 280 571 minecraft:gold_block
fill 169 280 576 176 280 576 minecraft:gold_block
fill 169 280 577 174 280 578 minecraft:waxed_cut_copper
fill 169 280 583 172 280 583 minecraft:waxed_cut_copper
fill 169 280 589 169 280 590 minecraft:black_concrete
fill 170 280 565 171 280 566 minecraft:black_concrete
fill 170 280 569 174 280 570 minecraft:gold_block
fill 170 280 584 170 280 585 minecraft:waxed_cut_copper
fill 170 280 590 182 280 590 minecraft:black_concrete
fill 171 280 564 182 280 564 minecraft:black_concrete
setblock 171 280 584 minecraft:waxed_cut_copper
fill 171 280 585 173 280 585 minecraft:gold_block
fill 172 280 584 177 280 584 minecraft:gold_block
fill 172 280 587 172 280 589 minecraft:black_concrete
fill 173 280 565 182 280 565 minecraft:black_concrete
fill 173 280 567 173 280 568 minecraft:black_concrete
fill 173 280 583 175 280 583 minecraft:gold_block
fill 173 280 588 182 280 589 minecraft:black_concrete
fill 174 280 566 182 280 567 minecraft:black_concrete
fill 174 280 581 175 280 582 minecraft:gold_block
fill 174 280 585 175 280 585 minecraft:black_concrete
setblock 175 280 569 minecraft:gold_block
fill 175 280 570 182 280 570 minecraft:black_concrete
fill 175 280 577 176 280 580 minecraft:gold_block
fill 175 280 586 182 280 587 minecraft:black_concrete
fill 176 280 568 182 280 569 minecraft:black_concrete
fill 176 280 581 178 280 581 minecraft:gold_block
fill 176 280 582 177 280 583 minecraft:black_concrete
fill 177 280 557 177 287 557 minecraft:black_concrete
setblock 177 280 572 minecraft:gold_block
fill 177 280 573 182 280 573 minecraft:black_concrete
fill 177 280 576 182 280 576 minecraft:black_concrete
fill 177 280 577 178 280 578 minecraft:gold_block
fill 177 280 579 182 280 580 minecraft:black_concrete
fill 177 280 585 182 280 585 minecraft:black_concrete
fill 178 280 571 182 280 572 minecraft:black_concrete
fill 178 280 583 182 280 584 minecraft:black_concrete
fill 179 280 574 182 280 575 minecraft:black_concrete
setblock 179 280 577 minecraft:gold_block
fill 179 280 578 182 280 578 minecraft:black_concrete
fill 179 280 581 182 280 582 minecraft:black_concrete
fill 180 280 577 182 280 577 minecraft:black_concrete
setblock 183 280 560 minecraft:shroomlight
setblock 183 280 566 minecraft:shroomlight
setblock 183 280 587 minecraft:white_concrete
fill 183 280 596 183 307 596 minecraft:black_concrete
fill 141 281 576 141 307 576 minecraft:black_concrete
setblock 148 281 599 minecraft:white_concrete
fill 151 281 557 151 296 557 minecraft:black_concrete
fill 153 281 557 153 307 557 minecraft:black_concrete
fill 160 281 599 160 307 599 minecraft:black_concrete
fill 170 281 557 170 307 557 minecraft:black_concrete
setblock 171 281 557 minecraft:white_concrete
fill 172 281 557 172 307 557 minecraft:black_concrete
fill 183 281 560 183 307 560 minecraft:black_concrete
fill 183 281 566 183 299 566 minecraft:black_concrete
fill 183 281 587 183 290 587 minecraft:black_concrete
setblock 183 281 588 minecraft:shroomlight
setblock 141 282 568 minecraft:shroomlight
setblock 144 282 560 minecraft:light[level=14]
setblock 144 282 568 minecraft:light[level=14]
setblock 144 282 576 minecraft:light[level=14]
setblock 144 282 584 minecraft:light[level=14]
setblock 144 282 592 minecraft:light[level=14]
fill 148 282 599 148 307 599 minecraft:black_concrete
setblock 152 282 560 minecraft:light[level=14]
setblock 152 282 568 minecraft:light[level=14]
setblock 152 282 576 minecraft:light[level=14]
setblock 152 282 584 minecraft:light[level=14]
setblock 152 282 592 minecraft:light[level=14]
setblock 160 282 560 minecraft:light[level=14]
setblock 160 282 568 minecraft:light[level=14]
setblock 160 282 576 minecraft:light[level=14]
setblock 160 282 584 minecraft:light[level=14]
setblock 160 282 592 minecraft:light[level=14]
setblock 168 282 560 minecraft:light[level=14]
setblock 168 282 568 minecraft:light[level=14]
setblock 168 282 576 minecraft:light[level=14]
setblock 168 282 584 minecraft:light[level=14]
setblock 168 282 592 minecraft:light[level=14]
fill 171 282 557 171 306 557 minecraft:black_concrete
setblock 176 282 560 minecraft:light[level=14]
setblock 176 282 568 minecraft:light[level=14]
setblock 176 282 576 minecraft:light[level=14]
setblock 176 282 584 minecraft:light[level=14]
setblock 176 282 592 minecraft:light[level=14]
fill 183 282 588 183 307 588 minecraft:black_concrete
setblock 141 283 568 minecraft:black_concrete
setblock 141 283 595 minecraft:shroomlight
setblock 163 283 599 minecraft:shroomlight
setblock 141 284 568 minecraft:white_concrete
fill 141 284 595 141 307 595 minecraft:black_concrete
setblock 141 284 598 minecraft:shroomlight
fill 142 284 562 182 284 562 minecraft:waxed_cut_copper
fill 142 284 570 181 284 570 minecraft:waxed_cut_copper
fill 142 284 578 162 284 578 minecraft:waxed_cut_copper
fill 142 284 586 144 284 586 minecraft:waxed_cut_copper
fill 142 284 594 177 284 594 minecraft:waxed_cut_copper
fill 143 284 599 143 307 599 minecraft:black_concrete
setblock 144 284 599 minecraft:shroomlight
setblock 154 284 557 minecraft:shroomlight
fill 163 284 599 163 307 599 minecraft:black_concrete
fill 168 284 578 181 284 578 minecraft:waxed_cut_copper
setblock 176 284 599 minecraft:white_concrete
fill 178 284 586 178 284 598 minecraft:waxed_copper_block
fill 179 284 594 182 284 594 minecraft:waxed_cut_copper
setblock 183 284 567 minecraft:shroomlight
fill 141 285 568 141 307 568 minecraft:black_concrete
fill 141 285 598 141 307 598 minecraft:black_concrete
fill 144 285 599 144 307 599 minecraft:black_concrete
fill 146 285 558 146 286 561 minecraft:waxed_copper_block
setblock 150 285 557 minecraft:shroomlight
fill 154 285 557 154 301 557 minecraft:black_concrete
fill 154 285 558 154 285 598 minecraft:waxed_copper_block
fill 162 285 558 162 285 597 minecraft:waxed_copper_block
fill 170 285 558 170 285 598 minecraft:waxed_copper_block
fill 176 285 578 181 285 578 minecraft:waxed_cut_copper
fill 176 285 599 176 307 599 minecraft:black_concrete
setblock 178 285 557 minecraft:white_concrete
fill 178 285 558 178 285 577 minecraft:waxed_copper_block
fill 178 285 579 178 285 591 minecraft:waxed_copper_block
fill 180 285 557 180 307 557 minecraft:black_concrete
setblock 181 285 557 minecraft:shroomlight
fill 183 285 567 183 287 567 minecraft:black_concrete
setblock 141 286 597 minecraft:shroomlight
fill 146 286 562 146 286 597 minecraft:waxed_copper_block
fill 150 286 557 150 307 557 minecraft:black_concrete
fill 154 286 558 154 286 564 minecraft:waxed_copper_block
fill 162 286 558 162 286 562 minecraft:waxed_copper_block
fill 170 286 558 170 286 565 minecraft:waxed_copper_block
fill 178 286 557 178 307 557 minecraft:black_concrete
fill 178 286 558 178 286 560 minecraft:waxed_copper_block
fill 181 286 557 181 299 557 minecraft:black_concrete
setblock 183 286 569 minecraft:shroomlight
fill 183 286 581 183 307 581 minecraft:black_concrete
setblock 183 286 582 minecraft:shroomlight
setblock 141 287 574 minecraft:white_concrete
setblock 141 287 597 minecraft:black_concrete
fill 146 287 596 146 287 597 minecraft:waxed_copper_block
fill 153 287 564 154 294 566 minecraft:red_terracotta
fill 183 287 569 183 289 569 minecraft:black_concrete
fill 183 287 582 183 307 582 minecraft:black_concrete
setblock 183 287 597 minecraft:shroomlight
fill 141 288 565 141 290 565 minecraft:gold_block
fill 141 288 574 141 307 574 minecraft:black_concrete
fill 141 288 581 141 290 581 minecraft:gold_block
fill 141 288 597 141 290 597 minecraft:gold_block
fill 145 288 557 145 290 557 minecraft:gold_block
fill 151 288 564 152 293 566 minecraft:red_terracotta
fill 152 288 563 155 293 563 minecraft:red_terracotta
fill 152 288 567 155 293 567 minecraft:red_terracotta
fill 155 288 564 155 293 566 minecraft:red_terracotta
fill 155 288 599 155 290 599 minecraft:gold_block
fill 156 288 565 156 293 565 minecraft:red_terracotta
fill 161 288 557 161 290 557 minecraft:gold_block
fill 171 288 599 171 290 599 minecraft:gold_block
fill 177 288 557 177 290 557 minecraft:gold_block
fill 183 288 567 183 290 567 minecraft:gold_block
fill 183 288 575 183 289 575 minecraft:shroomlight
fill 183 288 583 183 290 583 minecraft:gold_block
fill 183 288 597 183 307 597 minecraft:black_concrete
fill 150 289 565 150 292 565 minecraft:red_terracotta
fill 151 289 563 151 292 563 minecraft:red_terracotta
fill 151 289 567 151 292 567 minecraft:red_terracotta
fill 152 289 562 154 292 562 minecraft:red_terracotta
fill 152 289 568 154 292 568 minecraft:red_terracotta
fill 156 289 563 156 292 564 minecraft:red_terracotta
fill 156 289 566 156 292 567 minecraft:red_terracotta
setblock 144 290 560 minecraft:light[level=14]
setblock 144 290 568 minecraft:light[level=14]
setblock 144 290 576 minecraft:light[level=14]
setblock 144 290 584 minecraft:light[level=14]
setblock 144 290 592 minecraft:light[level=14]
fill 150 290 564 150 291 564 minecraft:red_terracotta
fill 150 290 566 150 291 566 minecraft:red_terracotta
setblock 152 290 560 minecraft:light[level=14]
setblock 152 290 576 minecraft:light[level=14]
setblock 152 290 584 minecraft:light[level=14]
setblock 152 290 592 minecraft:light[level=14]
fill 155 290 562 155 291 562 minecraft:red_terracotta
fill 155 290 568 155 291 568 minecraft:red_terracotta
fill 157 290 565 157 291 565 minecraft:red_terracotta
setblock 160 290 560 minecraft:light[level=14]
setblock 160 290 568 minecraft:light[level=14]
setblock 160 290 576 minecraft:light[level=14]
setblock 160 290 584 minecraft:light[level=14]
setblock 160 290 592 minecraft:light[level=14]
setblock 168 290 560 minecraft:light[level=14]
setblock 168 290 568 minecraft:light[level=14]
setblock 168 290 576 minecraft:light[level=14]
setblock 168 290 584 minecraft:light[level=14]
setblock 168 290 592 minecraft:light[level=14]
setblock 176 290 560 minecraft:light[level=14]
setblock 176 290 568 minecraft:light[level=14]
setblock 176 290 576 minecraft:light[level=14]
setblock 176 290 584 minecraft:light[level=14]
setblock 176 290 592 minecraft:light[level=14]
setblock 183 290 569 minecraft:white_concrete
fill 183 290 575 183 299 575 minecraft:black_concrete
fill 141 291 565 141 296 565 minecraft:black_concrete
setblock 141 291 569 minecraft:white_concrete
fill 141 291 570 141 292 571 minecraft:black_concrete
fill 141 291 581 141 296 581 minecraft:black_concrete
setblock 141 291 596 minecraft:shroomlight
fill 141 291 597 141 296 597 minecraft:black_concrete
fill 145 291 557 145 296 557 minecraft:black_concrete
fill 155 291 599 155 296 599 minecraft:black_concrete
fill 161 291 557 161 296 557 minecraft:black_concrete
fill 171 291 599 171 296 599 minecraft:black_concrete
fill 177 291 557 177 296 557 minecraft:black_concrete
fill 183 291 567 183 296 567 minecraft:black_concrete
fill 183 291 569 183 307 569 minecraft:black_concrete
fill 183 291 583 183 296 583 minecraft:black_concrete
setblock 183 291 587 minecraft:shroomlight
fill 141 292 569 141 307 569 minecraft:black_concrete
fill 141 292 596 141 307 596 minecraft:black_concrete
setblock 146 292 557 minecraft:shroomlight
setblock 170 292 599 minecraft:shroomlight
fill 183 292 587 183 293 587 minecraft:black_concrete
setblock 141 293 562 minecraft:shroomlight
setblock 141 293 564 minecraft:shroomlight
fill 141 293 570 141 307 570 minecraft:black_concrete
setblock 141 293 571 minecraft:white_concrete
setblock 141 293 586 minecraft:shroomlight
fill 146 293 557 146 307 557 minecraft:black_concrete
fill 170 293 599 170 307 599 minecraft:black_concrete
setblock 183 293 591 minecraft:shroomlight
fill 183 293 592 183 295 594 minecraft:black_concrete
fill 141 294 562 141 307 562 minecraft:black_concrete
fill 141 294 564 141 307 564 minecraft:black_concrete
setblock 141 294 571 minecraft:shroomlight
fill 141 294 586 141 307 586 minecraft:black_concrete
fill 165 294 562 165 300 562 minecraft:red_terracotta
setblock 165 294 599 minecraft:white_concrete
setblock 183 294 576 minecraft:shroomlight
setblock 183 294 578 minecraft:white_concrete
setblock 183 294 587 minecraft:shroomlight
fill 183 294 591 183 307 591 minecraft:black_concrete
setblock 141 295 559 minecraft:white_concrete
fill 141 295 571 141 307 571 minecraft:black_concrete
setblock 147 295 599 minecraft:shroomlight
fill 163 295 557 163 302 557 minecraft:black_concrete
fill 163 295 561 164 300 563 minecraft:red_terracotta
setblock 164 295 557 minecraft:white_concrete
fill 164 295 560 166 300 560 minecraft:red_terracotta
fill 164 295 564 165 300 564 minecraft:red_terracotta
fill 165 295 557 165 300 557 minecraft:black_concrete
fill 165 295 561 167 300 561 minecraft:red_terracotta
fill 165 295 563 167 300 563 minecraft:red_terracotta
fill 165 295 599 165 307 599 minecraft:black_concrete
fill 166 295 562 167 300 562 minecraft:red_terracotta
fill 183 295 576 183 301 576 minecraft:black_concrete
fill 183 295 578 183 296 578 minecraft:black_concrete
fill 183 295 587 183 298 587 minecraft:black_concrete
fill 141 296 559 141 302 559 minecraft:black_concrete
fill 147 296 599 147 307 599 minecraft:black_concrete
setblock 159 296 599 minecraft:white_concrete
fill 162 296 561 162 299 563 minecraft:red_terracotta
fill 163 296 560 163 299 560 minecraft:red_terracotta
fill 163 296 564 163 299 564 minecraft:red_terracotta
fill 164 296 557 164 306 557 minecraft:black_concrete
fill 164 296 559 166 299 559 minecraft:red_terracotta
setblock 164 296 599 minecraft:white_concrete
fill 166 296 564 167 299 564 minecraft:red_terracotta
fill 166 296 591 170 297 595 minecraft:polished_blackstone
fill 167 296 560 167 299 560 minecraft:red_terracotta
fill 168 296 561 168 299 562 minecraft:red_terracotta
fill 168 296 596 168 296 597 minecraft:polished_blackstone
setblock 172 296 599 minecraft:shroomlight
fill 173 296 599 174 305 599 minecraft:black_concrete
setblock 183 296 592 minecraft:shroomlight
fill 183 296 593 183 307 594 minecraft:black_concrete
fill 141 297 565 141 299 565 minecraft:gold_block
fill 141 297 581 141 299 581 minecraft:gold_block
fill 141 297 597 141 299 597 minecraft:gold_block
fill 145 297 557 145 299 557 minecraft:gold_block
setblock 151 297 557 minecraft:white_concrete
fill 155 297 599 155 299 599 minecraft:gold_block
setblock 156 297 557 minecraft:shroomlight
fill 159 297 599 159 307 599 minecraft:black_concrete
fill 161 297 557 161 299 557 minecraft:gold_block
fill 162 297 560 162 298 560 minecraft:red_terracotta
fill 163 297 559 163 298 559 minecraft:red_terracotta
fill 164 297 565 166 298 565 minecraft:red_terracotta
fill 164 297 599 164 302 599 minecraft:black_concrete
fill 167 297 559 167 298 559 minecraft:red_terracotta
fill 168 297 563 168 298 563 minecraft:red_terracotta
fill 171 297 599 171 299 599 minecraft:gold_block
fill 172 297 599 172 307 599 minecraft:black_concrete
fill 177 297 557 177 299 557 minecraft:gold_block
setblock 180 297 599 minecraft:white_concrete
fill 183 297 567 183 299 567 minecraft:gold_block
setblock 183 297 578 minecraft:white_concrete
fill 183 297 583 183 299 583 minecraft:gold_block
fill 183 297 592 183 307 592 minecraft:black_concrete
setblock 141 298 588 minecraft:shroomlight
setblock 144 298 560 minecraft:light[level=14]
setblock 144 298 568 minecraft:light[level=14]
setblock 144 298 576 minecraft:light[level=14]
setblock 144 298 584 minecraft:light[level=14]
setblock 144 298 592 minecraft:light[level=14]
fill 151 298 557 151 307 557 minecraft:black_concrete
setblock 152 298 560 minecraft:light[level=14]
setblock 152 298 568 minecraft:light[level=14]
setblock 152 298 576 minecraft:light[level=14]
setblock 152 298 584 minecraft:light[level=14]
setblock 152 298 592 minecraft:light[level=14]
fill 156 298 557 156 307 557 minecraft:black_concrete
setblock 160 298 560 minecraft:light[level=14]
setblock 160 298 568 minecraft:light[level=14]
setblock 160 298 576 minecraft:light[level=14]
setblock 160 298 584 minecraft:light[level=14]
setblock 160 298 592 minecraft:light[level=14]
setblock 168 298 560 minecraft:light[level=14]
setblock 168 298 568 minecraft:light[level=14]
setblock 168 298 576 minecraft:light[level=14]
setblock 168 298 584 minecraft:light[level=14]
setblock 168 298 592 minecraft:light[level=14]
setblock 176 298 560 minecraft:light[level=14]
setblock 176 298 568 minecraft:light[level=14]
setblock 176 298 576 minecraft:light[level=14]
setblock 176 298 584 minecraft:light[level=14]
setblock 176 298 592 minecraft:light[level=14]
fill 180 298 599 180 307 599 minecraft:black_concrete
setblock 183 298 564 minecraft:shroomlight
fill 183 298 578 183 307 578 minecraft:black_concrete
setblock 141 299 572 minecraft:white_concrete
fill 141 299 588 141 307 588 minecraft:black_concrete
setblock 183 299 564 minecraft:white_concrete
setblock 183 299 586 minecraft:shroomlight
setblock 183 299 587 minecraft:white_concrete
fill 141 300 565 141 307 565 minecraft:black_concrete
fill 141 300 572 141 307 572 minecraft:black_concrete
fill 141 300 581 141 307 581 minecraft:black_concrete
fill 141 300 597 141 307 597 minecraft:black_concrete
fill 145 300 557 145 306 557 minecraft:black_concrete
fill 155 300 599 155 307 599 minecraft:black_concrete
setblock 156 300 599 minecraft:shroomlight
setblock 157 300 557 minecraft:shroomlight
fill 157 300 599 158 307 599 minecraft:black_concrete
fill 158 300 557 158 307 557 minecraft:black_concrete
fill 161 300 557 161 307 557 minecraft:black_concrete
fill 171 300 599 171 307 599 minecraft:black_concrete
fill 177 300 557 177 307 557 minecraft:black_concrete
fill 181 300 557 181 301 557 minecraft:shroomlight
fill 183 300 564 183 301 564 minecraft:black_concrete
setblock 183 300 566 minecraft:white_concrete
fill 183 300 567 183 307 567 minecraft:black_concrete
setblock 183 300 575 minecraft:shroomlight
fill 183 300 583 183 307 583 minecraft:black_concrete
fill 183 300 586 183 307 587 minecraft:black_concrete
setblock 150 301 599 minecraft:shroomlight
fill 151 301 599 151 303 599 minecraft:black_concrete
fill 156 301 599 156 307 599 minecraft:black_concrete
fill 157 301 557 157 307 557 minecraft:black_concrete
setblock 165 301 557 minecraft:shroomlight
setblock 183 301 566 minecraft:black_concrete
fill 183 301 575 183 307 575 minecraft:black_concrete
setblock 183 301 584 minecraft:shroomlight
fill 150 302 599 150 307 599 minecraft:black_concrete
setblock 154 302 557 minecraft:white_concrete
fill 165 302 557 165 307 557 minecraft:black_concrete
fill 181 302 557 181 307 557 minecraft:black_concrete
setblock 183 302 564 minecraft:shroomlight
setblock 183 302 566 minecraft:white_concrete
setblock 183 302 572 minecraft:shroomlight
setblock 183 302 574 minecraft:shroomlight
setblock 183 302 576 minecraft:white_concrete
fill 183 302 584 183 307 584 minecraft:black_concrete
setblock 141 303 559 minecraft:shroomlight
fill 154 303 557 154 307 557 minecraft:black_concrete
setblock 163 303 557 minecraft:shroomlight
setblock 164 303 599 minecraft:shroomlight
setblock 167 303 599 minecraft:shroomlight
setblock 181 303 599 minecraft:shroomlight
fill 183 303 564 183 307 564 minecraft:black_concrete
fill 183 303 566 183 307 566 minecraft:black_concrete
fill 183 303 572 183 307 572 minecraft:black_concrete
fill 183 303 574 183 307 574 minecraft:black_concrete
fill 183 303 576 183 307 576 minecraft:black_concrete
fill 141 304 559 141 307 559 minecraft:black_concrete
fill 141 304 566 141 307 566 minecraft:black_concrete
setblock 141 304 567 minecraft:white_concrete
setblock 151 304 599 minecraft:shroomlight
fill 163 304 557 163 307 557 minecraft:black_concrete
fill 164 304 599 164 307 599 minecraft:black_concrete
fill 167 304 599 167 307 599 minecraft:black_concrete
setblock 169 304 557 minecraft:white_concrete
fill 181 304 599 181 307 599 minecraft:black_concrete
fill 141 305 567 141 307 567 minecraft:black_concrete
setblock 141 305 579 minecraft:shroomlight
fill 151 305 599 151 307 599 minecraft:black_concrete
fill 169 305 557 169 307 557 minecraft:black_concrete
fill 141 306 579 141 307 579 minecraft:black_concrete
setblock 173 306 599 minecraft:shroomlight
fill 174 306 599 174 307 599 minecraft:black_concrete
setblock 145 307 557 minecraft:shroomlight
setblock 153 307 599 minecraft:shroomlight
setblock 164 307 557 minecraft:shroomlight
setblock 171 307 557 minecraft:shroomlight
setblock 173 307 599 minecraft:black_concrete
setblock 182 307 557 minecraft:shroomlight
setblock 183 307 579 minecraft:white_concrete
