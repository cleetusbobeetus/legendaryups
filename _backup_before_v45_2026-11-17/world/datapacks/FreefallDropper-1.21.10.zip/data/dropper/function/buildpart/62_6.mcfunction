fill 136 212 295 136 213 296 minecraft:red_concrete
fill 136 212 297 136 213 298 minecraft:white_concrete
fill 136 212 299 136 213 300 minecraft:red_concrete
fill 136 212 301 136 213 302 minecraft:white_concrete
fill 136 212 303 136 213 304 minecraft:red_concrete
fill 136 212 305 136 213 306 minecraft:white_concrete
fill 136 212 307 136 213 308 minecraft:red_concrete
fill 136 212 309 136 213 310 minecraft:white_concrete
fill 136 212 311 136 213 312 minecraft:red_concrete
fill 136 212 313 136 213 314 minecraft:white_concrete
fill 136 212 315 136 213 316 minecraft:red_concrete
fill 136 212 317 136 213 317 minecraft:white_concrete
setblock 97 213 278 minecraft:light[level=15]
setblock 97 213 285 minecraft:light[level=12]
setblock 97 213 286 minecraft:light[level=15]
setblock 97 213 292 minecraft:light[level=12]
setblock 97 213 294 minecraft:light[level=15]
fill 97 213 300 99 213 300 minecraft:basalt
fill 97 213 301 97 272 301 minecraft:iron_block
setblock 97 213 302 minecraft:red_terracotta
setblock 97 213 306 minecraft:light[level=12]
setblock 97 213 310 minecraft:light[level=15]
setblock 97 213 313 minecraft:light[level=12]
setblock 98 213 292 minecraft:magma_block
fill 98 213 293 99 213 294 minecraft:basalt
setblock 98 213 295 minecraft:magma_block
setblock 98 213 301 minecraft:magma_block
fill 98 213 303 99 213 303 minecraft:basalt
setblock 98 213 304 minecraft:magma_block
fill 99 213 289 99 213 292 minecraft:basalt
fill 99 213 295 99 214 295 minecraft:basalt
fill 99 213 301 99 214 301 minecraft:basalt
fill 99 213 304 99 213 307 minecraft:basalt
fill 100 213 290 103 213 290 minecraft:basalt
fill 100 213 293 101 215 293 minecraft:basalt
fill 100 213 305 102 213 305 minecraft:basalt
fill 101 213 287 105 213 287 minecraft:basalt
setblock 101 213 309 minecraft:magma_block
setblock 102 213 285 minecraft:basalt
fill 102 213 309 102 214 309 minecraft:basalt
fill 102 213 311 103 213 311 minecraft:basalt
setblock 103 213 312 minecraft:basalt
setblock 104 213 278 minecraft:light[level=12]
fill 104 213 283 108 213 283 minecraft:basalt
setblock 104 213 296 minecraft:magma_block
fill 104 213 297 104 221 298 minecraft:basalt
setblock 104 213 299 minecraft:magma_block
fill 104 213 300 104 221 300 minecraft:basalt
fill 104 213 313 108 213 313 minecraft:basalt
setblock 105 213 278 minecraft:light[level=15]
fill 105 213 282 111 213 282 minecraft:basalt
fill 105 213 291 106 220 291 minecraft:basalt
fill 105 213 293 105 220 294 minecraft:basalt
fill 105 213 302 105 220 303 minecraft:basalt
fill 105 213 314 106 213 314 minecraft:basalt
fill 106 213 305 106 221 305 minecraft:basalt
fill 107 213 290 107 221 290 minecraft:basalt
fill 107 213 306 107 221 306 minecraft:basalt
fill 107 213 315 111 213 315 minecraft:basalt
fill 108 213 280 109 213 280 minecraft:basalt
fill 108 213 289 108 221 289 minecraft:basalt
fill 108 213 307 108 220 308 minecraft:basalt
fill 108 213 316 109 213 316 minecraft:basalt
fill 109 213 288 109 221 288 minecraft:basalt
fill 109 213 308 109 221 308 minecraft:basalt
fill 110 213 287 110 221 287 minecraft:basalt
setblock 110 213 309 minecraft:magma_block
setblock 111 213 278 minecraft:light[level=12]
setblock 111 213 279 minecraft:basalt
fill 111 213 286 113 220 286 minecraft:basalt
setblock 111 213 292 minecraft:light[level=12]
setblock 111 213 299 minecraft:light[level=12]
setblock 111 213 306 minecraft:light[level=12]
fill 111 213 310 113 220 310 minecraft:basalt
setblock 113 213 278 minecraft:light[level=15]
setblock 113 213 294 minecraft:light[level=15]
setblock 113 213 302 minecraft:light[level=15]
fill 114 213 277 114 213 278 minecraft:red_terracotta
fill 114 213 285 118 220 285 minecraft:basalt
fill 115 213 277 116 213 277 minecraft:red_terracotta
fill 115 213 311 119 220 311 minecraft:basalt
fill 116 213 278 119 213 278 minecraft:basalt
fill 117 213 284 117 220 284 minecraft:basalt
setblock 118 213 292 minecraft:light[level=12]
setblock 118 213 299 minecraft:light[level=12]
setblock 118 213 306 minecraft:light[level=12]
fill 119 213 280 124 213 280 minecraft:basalt
setblock 119 213 285 minecraft:magma_block
fill 119 213 316 124 213 316 minecraft:basalt
setblock 121 213 278 minecraft:light[level=15]
fill 121 213 286 122 213 286 minecraft:basalt
setblock 121 213 294 minecraft:light[level=15]
setblock 121 213 302 minecraft:light[level=15]
fill 121 213 310 122 213 310 minecraft:basalt
fill 122 213 279 123 213 279 minecraft:basalt
fill 122 213 315 127 213 315 minecraft:basalt
fill 124 213 287 124 221 287 minecraft:basalt
fill 124 213 309 124 221 309 minecraft:basalt
setblock 125 213 278 minecraft:light[level=12]
setblock 125 213 280 minecraft:magma_block
fill 125 213 281 127 213 281 minecraft:basalt
fill 125 213 284 130 214 284 minecraft:basalt
fill 125 213 288 125 221 288 minecraft:basalt
setblock 125 213 292 minecraft:light[level=12]
setblock 125 213 299 minecraft:light[level=12]
setblock 125 213 306 minecraft:light[level=12]
fill 125 213 308 126 220 308 minecraft:basalt
fill 125 213 314 129 213 314 minecraft:basalt
setblock 125 213 316 minecraft:magma_block
setblock 126 213 280 minecraft:basalt
fill 126 213 289 126 221 289 minecraft:basalt
fill 126 213 307 126 221 307 minecraft:basalt
setblock 126 213 316 minecraft:basalt
fill 127 213 282 127 214 282 minecraft:basalt
fill 127 213 290 127 221 290 minecraft:basalt
fill 127 213 306 127 221 306 minecraft:basalt
setblock 128 213 282 minecraft:magma_block
fill 128 213 283 130 213 283 minecraft:basalt
fill 128 213 286 133 213 286 minecraft:basalt
setblock 128 213 291 minecraft:magma_block
fill 128 213 305 128 221 305 minecraft:basalt
fill 128 213 310 133 213 310 minecraft:basalt
fill 128 213 313 130 213 313 minecraft:basalt
setblock 129 213 278 minecraft:light[level=15]
setblock 129 213 282 minecraft:basalt
fill 129 213 292 129 220 294 minecraft:basalt
fill 129 213 302 129 220 304 minecraft:basalt
fill 130 213 296 130 219 300 minecraft:basalt
setblock 131 213 284 minecraft:magma_block
fill 131 213 285 132 213 285 minecraft:basalt
fill 131 213 288 134 213 288 minecraft:basalt
fill 131 213 309 133 213 309 minecraft:basalt
setblock 132 213 278 minecraft:light[level=12]
setblock 132 213 313 minecraft:light[level=12]
fill 94 214 275 94 215 276 minecraft:white_concrete
fill 94 214 277 94 215 278 minecraft:red_concrete
fill 94 214 279 94 215 279 minecraft:white_concrete
fill 94 214 280 94 219 280 minecraft:shroomlight
fill 94 214 281 94 215 282 minecraft:red_concrete
fill 94 214 283 94 215 284 minecraft:white_concrete
fill 94 214 285 94 215 286 minecraft:red_concrete
fill 94 214 287 94 215 287 minecraft:white_concrete
fill 94 214 288 94 219 288 minecraft:shroomlight
fill 94 214 289 94 215 290 minecraft:red_concrete
fill 94 214 291 94 215 292 minecraft:white_concrete
fill 94 214 293 94 215 294 minecraft:red_concrete
fill 94 214 295 94 215 295 minecraft:white_concrete
fill 94 214 296 94 219 296 minecraft:shroomlight
fill 94 214 297 94 215 298 minecraft:red_concrete
fill 94 214 299 94 215 300 minecraft:white_concrete
fill 94 214 301 94 215 302 minecraft:red_concrete
fill 94 214 303 94 215 303 minecraft:white_concrete
fill 94 214 304 94 219 304 minecraft:shroomlight
fill 94 214 305 94 215 306 minecraft:red_concrete
fill 94 214 307 94 215 308 minecraft:white_concrete
fill 94 214 309 94 215 310 minecraft:red_concrete
fill 94 214 311 94 215 311 minecraft:white_concrete
fill 94 214 312 94 219 312 minecraft:shroomlight
fill 94 214 313 94 215 314 minecraft:red_concrete
fill 94 214 315 94 215 316 minecraft:white_concrete
fill 95 214 275 95 215 275 minecraft:white_concrete
fill 95 214 317 95 215 317 minecraft:white_concrete
fill 96 214 275 97 215 275 minecraft:red_concrete
fill 96 214 317 96 215 317 minecraft:red_concrete
fill 97 214 317 97 219 317 minecraft:shroomlight
fill 98 214 275 99 215 275 minecraft:white_concrete
setblock 98 214 295 minecraft:basalt
fill 98 214 297 99 214 298 minecraft:basalt
fill 98 214 300 98 214 301 minecraft:basalt
fill 98 214 302 98 272 302 minecraft:iron_block
fill 98 214 317 99 215 317 minecraft:white_concrete
fill 99 214 292 99 214 294 minecraft:basalt
fill 99 214 300 99 215 300 minecraft:basalt
fill 99 214 302 99 214 304 minecraft:basalt
fill 100 214 275 100 215 275 minecraft:red_concrete
setblock 100 214 290 minecraft:magma_block
fill 100 214 302 101 216 302 minecraft:basalt
setblock 100 214 305 minecraft:magma_block
fill 100 214 317 101 215 317 minecraft:red_concrete
fill 101 214 275 101 219 275 minecraft:shroomlight
fill 101 214 288 102 214 288 minecraft:basalt
fill 101 214 290 103 215 290 minecraft:basalt
fill 101 214 305 102 215 305 minecraft:basalt
fill 101 214 308 104 214 308 minecraft:basalt
fill 102 214 275 103 215 275 minecraft:white_concrete
fill 102 214 286 102 214 287 minecraft:basalt
setblock 102 214 310 minecraft:basalt
fill 102 214 317 103 215 317 minecraft:white_concrete
setblock 103 214 286 minecraft:magma_block
fill 103 214 287 105 215 287 minecraft:basalt
setblock 103 214 310 minecraft:magma_block
setblock 103 214 311 minecraft:basalt
fill 104 214 275 105 215 275 minecraft:red_concrete
fill 104 214 284 105 214 284 minecraft:basalt
fill 104 214 286 106 215 286 minecraft:basalt
fill 104 214 296 105 214 296 minecraft:basalt
fill 104 214 299 105 214 299 minecraft:basalt
fill 104 214 310 106 215 310 minecraft:basalt
fill 104 214 317 104 215 317 minecraft:red_concrete
fill 105 214 283 108 214 283 minecraft:basalt
fill 105 214 295 105 221 295 minecraft:basalt
fill 105 214 297 105 222 298 minecraft:basalt
fill 105 214 300 105 221 301 minecraft:basalt
fill 105 214 313 108 214 313 minecraft:basalt
fill 105 214 317 105 219 317 minecraft:shroomlight
fill 106 214 275 107 215 275 minecraft:white_concrete
fill 106 214 292 106 221 293 minecraft:basalt
setblock 106 214 303 minecraft:magma_block
fill 106 214 304 106 221 304 minecraft:basalt
fill 106 214 317 107 215 317 minecraft:white_concrete
fill 107 214 282 111 214 282 minecraft:basalt
fill 107 214 291 107 222 291 minecraft:basalt
fill 107 214 305 107 222 305 minecraft:basalt
fill 108 214 275 108 215 275 minecraft:red_concrete
setblock 108 214 281 minecraft:basalt
fill 108 214 290 108 222 290 minecraft:basalt
fill 108 214 306 108 222 306 minecraft:basalt
fill 108 214 315 111 214 315 minecraft:basalt
fill 108 214 317 109 215 317 minecraft:red_concrete
fill 109 214 275 109 219 275 minecraft:shroomlight
setblock 109 214 281 minecraft:magma_block
fill 109 214 289 109 222 289 minecraft:basalt
fill 109 214 307 109 222 307 minecraft:basalt
fill 109 214 316 110 272 316 minecraft:red_terracotta
fill 110 214 275 111 215 275 minecraft:white_concrete
fill 110 214 281 114 215 281 minecraft:basalt
fill 110 214 288 110 221 288 minecraft:basalt
fill 110 214 308 110 221 309 minecraft:basalt
fill 110 214 317 111 215 317 minecraft:white_concrete
setblock 111 214 280 minecraft:basalt
fill 111 214 287 112 221 287 minecraft:basalt
fill 111 214 309 112 221 309 minecraft:basalt
setblock 111 214 316 minecraft:basalt
fill 112 214 275 113 215 275 minecraft:red_concrete
setblock 112 214 280 minecraft:magma_block
setblock 112 214 316 minecraft:magma_block
fill 112 214 317 112 215 317 minecraft:red_concrete
fill 113 214 280 117 214 280 minecraft:basalt
fill 113 214 316 117 214 316 minecraft:basalt
fill 113 214 317 113 219 317 minecraft:shroomlight
fill 114 214 275 115 215 275 minecraft:white_concrete
setblock 114 214 279 minecraft:basalt
fill 114 214 286 120 214 286 minecraft:basalt
fill 114 214 310 120 214 310 minecraft:basalt
fill 114 214 317 115 215 317 minecraft:white_concrete
fill 115 214 278 115 272 278 minecraft:iron_block
setblock 115 214 279 minecraft:magma_block
fill 116 214 275 116 215 275 minecraft:red_concrete
fill 116 214 279 120 214 279 minecraft:basalt
fill 116 214 317 117 215 317 minecraft:red_concrete
fill 117 214 275 117 219 275 minecraft:shroomlight
fill 118 214 275 119 215 275 minecraft:white_concrete
fill 118 214 317 119 215 317 minecraft:white_concrete
fill 119 214 280 120 215 280 minecraft:basalt
fill 119 214 285 119 221 285 minecraft:basalt
fill 119 214 316 120 215 316 minecraft:basalt
fill 120 214 275 121 215 275 minecraft:red_concrete
fill 120 214 317 120 215 317 minecraft:red_concrete
setblock 121 214 280 minecraft:magma_block
setblock 121 214 286 minecraft:magma_block
setblock 121 214 310 minecraft:magma_block
setblock 121 214 316 minecraft:magma_block
fill 121 214 317 121 219 317 minecraft:shroomlight
fill 122 214 275 123 215 275 minecraft:white_concrete
fill 122 214 280 123 214 280 minecraft:basalt
fill 122 214 286 122 221 287 minecraft:basalt
fill 122 214 309 122 221 310 minecraft:basalt
fill 122 214 315 123 214 316 minecraft:basalt
fill 122 214 317 123 215 317 minecraft:white_concrete
fill 123 214 287 123 221 287 minecraft:basalt
fill 123 214 309 123 220 309 minecraft:basalt
fill 124 214 275 124 215 275 minecraft:red_concrete
setblock 124 214 288 minecraft:magma_block
fill 124 214 308 124 222 308 minecraft:basalt
setblock 124 214 315 minecraft:magma_block
fill 124 214 317 125 215 317 minecraft:red_concrete
fill 125 214 275 125 219 275 minecraft:shroomlight
fill 125 214 281 126 214 281 minecraft:basalt
fill 125 214 289 125 221 289 minecraft:basalt
fill 125 214 307 125 221 307 minecraft:basalt
fill 125 214 314 126 214 315 minecraft:basalt
fill 125 214 316 126 272 316 minecraft:red_terracotta
fill 126 214 275 127 215 275 minecraft:white_concrete
fill 126 214 290 126 222 290 minecraft:basalt
fill 126 214 306 126 222 306 minecraft:basalt
fill 126 214 311 131 214 311 minecraft:basalt
fill 126 214 317 127 215 317 minecraft:white_concrete
fill 127 214 291 128 221 291 minecraft:basalt
setblock 127 214 305 minecraft:magma_block
setblock 127 214 314 minecraft:magma_block
fill 128 214 275 129 215 275 minecraft:red_concrete
fill 128 214 283 129 214 283 minecraft:basalt
fill 128 214 286 132 214 286 minecraft:basalt
fill 128 214 292 128 221 293 minecraft:basalt
fill 128 214 303 128 221 304 minecraft:basalt
fill 128 214 310 132 214 310 minecraft:basalt
fill 128 214 313 129 214 313 minecraft:basalt
fill 128 214 317 128 215 317 minecraft:red_concrete
fill 129 214 295 129 214 301 minecraft:basalt
fill 129 214 317 129 219 317 minecraft:shroomlight
fill 130 214 275 131 215 275 minecraft:white_concrete
fill 130 214 289 134 214 289 minecraft:basalt
fill 130 214 317 131 215 317 minecraft:white_concrete
setblock 131 214 285 minecraft:basalt
fill 131 214 288 132 215 288 minecraft:basalt
fill 131 214 306 134 214 306 minecraft:basalt
fill 131 214 309 132 214 309 minecraft:basalt
fill 132 214 275 132 215 275 minecraft:red_concrete
fill 132 214 317 133 215 317 minecraft:red_concrete
fill 133 214 275 133 219 275 minecraft:shroomlight
setblock 133 214 288 minecraft:magma_block
fill 133 214 291 134 215 292 minecraft:basalt
fill 133 214 307 134 214 307 minecraft:basalt
fill 134 214 275 135 215 275 minecraft:white_concrete
setblock 134 214 290 minecraft:basalt
fill 134 214 305 134 215 305 minecraft:basalt
fill 134 214 317 135 215 317 minecraft:white_concrete
setblock 135 214 292 minecraft:basalt
fill 136 214 276 136 215 276 minecraft:white_concrete
fill 136 214 277 136 215 278 minecraft:red_concrete
fill 136 214 279 136 215 279 minecraft:white_concrete
fill 136 214 280 136 219 280 minecraft:shroomlight
fill 136 214 281 136 215 282 minecraft:red_concrete
fill 136 214 283 136 215 284 minecraft:white_concrete
fill 136 214 285 136 215 286 minecraft:red_concrete
fill 136 214 287 136 215 287 minecraft:white_concrete
fill 136 214 288 136 219 288 minecraft:shroomlight
fill 136 214 289 136 215 290 minecraft:red_concrete
fill 136 214 291 136 215 292 minecraft:white_concrete
fill 136 214 293 136 215 294 minecraft:red_concrete
fill 136 214 295 136 215 295 minecraft:white_concrete
fill 136 214 296 136 219 296 minecraft:shroomlight
fill 136 214 297 136 215 298 minecraft:red_concrete
fill 136 214 299 136 215 300 minecraft:white_concrete
fill 136 214 301 136 215 302 minecraft:red_concrete
fill 136 214 303 136 215 303 minecraft:white_concrete
fill 136 214 304 136 219 304 minecraft:shroomlight
fill 136 214 305 136 215 306 minecraft:red_concrete
fill 136 214 307 136 215 308 minecraft:white_concrete
fill 136 214 309 136 215 310 minecraft:red_concrete
fill 136 214 311 136 215 311 minecraft:white_concrete
fill 136 214 312 136 219 312 minecraft:shroomlight
fill 136 214 313 136 215 314 minecraft:red_concrete
fill 136 214 315 136 215 316 minecraft:white_concrete
fill 136 214 317 136 215 317 minecraft:red_concrete
fill 95 215 285 98 272 287 minecraft:red_terracotta
fill 96 215 288 98 272 288 minecraft:red_terracotta
fill 97 215 284 97 272 284 minecraft:red_terracotta
fill 98 215 300 98 272 301 minecraft:iron_block
fill 99 215 286 99 272 287 minecraft:red_terracotta
setblock 99 215 295 minecraft:magma_block
fill 99 215 296 99 215 297 minecraft:basalt
setblock 99 215 298 minecraft:magma_block
fill 99 215 299 101 215 299 minecraft:basalt
setblock 99 215 301 minecraft:magma_block
fill 100 215 296 101 216 296 minecraft:basalt
setblock 100 215 305 minecraft:basalt
fill 101 215 306 102 215 306 minecraft:basalt
setblock 102 215 288 minecraft:magma_block
fill 102 215 308 104 215 308 minecraft:basalt
fill 104 215 285 107 215 285 minecraft:basalt
fill 104 215 296 104 221 296 minecraft:basalt
fill 104 215 299 104 221 299 minecraft:basalt
setblock 104 215 311 minecraft:basalt
setblock 105 215 296 minecraft:magma_block
setblock 105 215 299 minecraft:magma_block
setblock 105 215 311 minecraft:magma_block
fill 106 215 294 106 222 295 minecraft:basalt
fill 106 215 301 106 222 303 minecraft:basalt
fill 106 215 312 109 215 312 minecraft:basalt
fill 107 215 283 108 215 283 minecraft:basalt
fill 107 215 292 107 221 292 minecraft:basalt
fill 107 215 304 107 221 304 minecraft:basalt
fill 107 215 313 108 215 313 minecraft:basalt
fill 108 215 282 111 215 282 minecraft:basalt
fill 108 215 291 108 223 291 minecraft:basalt
fill 108 215 305 108 223 305 minecraft:basalt
fill 108 215 314 114 215 314 minecraft:basalt
fill 109 215 290 109 222 290 minecraft:basalt
fill 109 215 306 109 223 306 minecraft:basalt
fill 110 215 289 110 223 289 minecraft:basalt
fill 110 215 307 110 223 307 minecraft:basalt
setblock 110 215 315 minecraft:basalt
setblock 111 215 288 minecraft:magma_block
fill 111 215 308 111 222 308 minecraft:basalt
setblock 111 215 315 minecraft:magma_block
fill 113 215 287 113 221 287 minecraft:basalt
fill 113 215 309 114 222 309 minecraft:basalt
fill 114 215 280 116 215 280 minecraft:basalt
fill 114 215 286 116 221 286 minecraft:basalt
setblock 114 215 287 minecraft:magma_block
fill 114 215 310 116 221 310 minecraft:basalt
fill 114 215 316 116 215 316 minecraft:basalt
fill 116 215 281 122 215 281 minecraft:basalt
setblock 117 215 280 minecraft:magma_block
setblock 117 215 286 minecraft:magma_block
setblock 117 215 310 minecraft:magma_block
setblock 117 215 316 minecraft:magma_block
fill 118 215 286 121 220 286 minecraft:basalt
fill 118 215 310 121 220 310 minecraft:basalt
fill 120 215 287 121 222 287 minecraft:basalt
setblock 120 215 309 minecraft:magma_block
fill 121 215 309 121 222 309 minecraft:basalt
fill 122 215 315 124 215 315 minecraft:basalt
setblock 123 215 281 minecraft:magma_block
fill 123 215 288 124 222 288 minecraft:basalt
setblock 123 215 308 minecraft:magma_block
fill 124 215 289 124 223 289 minecraft:basalt
fill 124 215 307 124 223 307 minecraft:basalt
fill 125 215 284 128 215 284 minecraft:basalt
fill 125 215 290 125 223 290 minecraft:basalt
setblock 125 215 306 minecraft:basalt
fill 125 215 312 128 215 312 minecraft:basalt
fill 125 215 314 126 215 314 minecraft:basalt
fill 126 215 291 126 223 291 minecraft:basalt
fill 126 215 305 127 222 305 minecraft:basalt
fill 126 215 311 130 215 311 minecraft:basalt
fill 127 215 292 127 222 292 minecraft:basalt
fill 127 215 304 127 222 304 minecraft:basalt
fill 128 215 285 128 216 286 minecraft:basalt
fill 128 215 294 128 221 295 minecraft:basalt
fill 128 215 301 128 222 302 minecraft:basalt
fill 128 215 310 130 215 310 minecraft:basalt
setblock 129 215 285 minecraft:magma_block
fill 129 215 286 130 215 287 minecraft:basalt
fill 129 215 295 129 220 296 minecraft:basalt
setblock 129 215 297 minecraft:magma_block
fill 129 215 298 129 222 299 minecraft:basalt
setblock 129 215 300 minecraft:magma_block
fill 129 215 301 129 220 301 minecraft:basalt
setblock 130 215 285 minecraft:basalt
fill 130 215 289 133 215 289 minecraft:basalt
fill 130 215 307 131 216 308 minecraft:basalt
setblock 131 215 287 minecraft:basalt
fill 131 215 306 133 215 306 minecraft:basalt
setblock 131 215 309 minecraft:basalt
fill 132 215 307 133 215 307 minecraft:basalt
setblock 132 215 308 minecraft:magma_block
fill 133 215 294 134 215 295 minecraft:basalt
fill 133 215 297 134 215 298 minecraft:basalt
fill 133 215 300 134 215 301 minecraft:basalt
fill 133 215 303 134 215 304 minecraft:basalt
setblock 134 215 293 minecraft:basalt
fill 134 215 302 134 216 302 minecraft:basalt
fill 135 215 293 135 272 294 minecraft:red_terracotta
setblock 135 215 295 minecraft:magma_block
setblock 135 215 297 minecraft:basalt
setblock 135 215 298 minecraft:magma_block
setblock 135 215 300 minecraft:basalt
setblock 135 215 301 minecraft:magma_block
fill 135 215 302 135 268 302 minecraft:red_terracotta
fill 94 216 275 94 217 276 minecraft:red_concrete
fill 94 216 277 94 217 278 minecraft:white_concrete
fill 94 216 279 94 217 279 minecraft:red_concrete
fill 94 216 281 94 217 282 minecraft:white_concrete
fill 94 216 283 94 217 284 minecraft:red_concrete
fill 94 216 285 94 217 286 minecraft:white_concrete
fill 94 216 287 94 217 287 minecraft:red_concrete
fill 94 216 289 94 217 290 minecraft:white_concrete
fill 94 216 291 94 217 292 minecraft:red_concrete
fill 94 216 293 94 217 294 minecraft:white_concrete
fill 94 216 295 94 217 295 minecraft:red_concrete
fill 94 216 297 94 217 298 minecraft:white_concrete
fill 94 216 299 94 217 300 minecraft:red_concrete
fill 94 216 301 94 217 302 minecraft:white_concrete
fill 94 216 303 94 217 303 minecraft:red_concrete
fill 94 216 305 94 217 306 minecraft:white_concrete
fill 94 216 307 94 217 308 minecraft:red_concrete
fill 94 216 309 94 217 310 minecraft:white_concrete
fill 94 216 311 94 217 311 minecraft:red_concrete
fill 94 216 313 94 217 314 minecraft:white_concrete
fill 94 216 315 94 217 316 minecraft:red_concrete
fill 95 216 275 95 217 275 minecraft:red_concrete
fill 95 216 284 96 217 284 minecraft:brown_terracotta
fill 95 216 288 95 217 288 minecraft:brown_terracotta
fill 95 216 317 95 217 317 minecraft:red_concrete
fill 96 216 275 97 217 275 minecraft:white_concrete
fill 96 216 289 98 217 289 minecraft:brown_terracotta
fill 96 216 317 96 217 317 minecraft:white_concrete
fill 98 216 275 99 217 275 minecraft:red_concrete
fill 98 216 284 99 217 284 minecraft:brown_terracotta
fill 98 216 317 99 217 317 minecraft:red_concrete
fill 99 216 285 99 217 285 minecraft:brown_terracotta
fill 99 216 288 99 217 288 minecraft:brown_terracotta
fill 99 216 301 99 272 301 minecraft:iron_block
fill 100 216 275 100 217 275 minecraft:white_concrete
fill 100 216 286 100 217 286 minecraft:brown_terracotta
fill 100 216 299 101 216 299 minecraft:basalt
fill 100 216 317 101 217 317 minecraft:white_concrete
fill 101 216 291 102 216 291 minecraft:basalt
setblock 101 216 293 minecraft:magma_block
fill 101 216 303 102 216 303 minecraft:basalt
setblock 101 216 305 minecraft:magma_block
fill 102 216 275 103 217 275 minecraft:red_concrete
fill 102 216 289 103 216 290 minecraft:basalt
fill 102 216 305 102 216 307 minecraft:basalt
fill 102 216 317 103 217 317 minecraft:red_concrete
fill 103 216 307 104 216 308 minecraft:basalt
fill 104 216 275 105 217 275 minecraft:white_concrete
fill 104 216 287 105 216 287 minecraft:basalt
fill 104 216 289 104 218 289 minecraft:basalt
fill 104 216 317 104 217 317 minecraft:white_concrete
fill 105 216 286 106 216 286 minecraft:basalt
fill 105 216 296 106 222 296 minecraft:basalt
fill 105 216 299 106 216 299 minecraft:basalt
fill 105 216 310 106 216 310 minecraft:basalt
fill 106 216 275 107 217 275 minecraft:red_concrete
fill 106 216 285 107 216 285 minecraft:basalt
fill 106 216 297 106 222 298 minecraft:basalt
fill 106 216 300 106 222 300 minecraft:basalt
fill 106 216 317 107 217 317 minecraft:red_concrete
fill 107 216 293 107 223 293 minecraft:basalt
setblock 107 216 294 minecraft:magma_block
fill 107 216 302 107 223 302 minecraft:basalt
setblock 107 216 303 minecraft:magma_block
setblock 107 216 312 minecraft:magma_block
fill 108 216 275 108 217 275 minecraft:white_concrete
setblock 108 216 283 minecraft:basalt
fill 108 216 292 108 223 292 minecraft:basalt
fill 108 216 304 108 223 304 minecraft:basalt
fill 108 216 312 108 216 313 minecraft:basalt
fill 108 216 317 109 217 317 minecraft:white_concrete
fill 109 216 312 109 217 312 minecraft:basalt
fill 110 216 275 111 217 275 minecraft:red_concrete
fill 110 216 282 111 216 282 minecraft:basalt
setblock 110 216 314 minecraft:magma_block
fill 110 216 317 111 217 317 minecraft:red_concrete
fill 111 216 280 112 217 281 minecraft:yellow_wool
fill 111 216 288 111 222 289 minecraft:basalt
fill 111 216 307 111 223 307 minecraft:basalt
fill 111 216 314 114 216 314 minecraft:basalt
fill 112 216 275 113 217 275 minecraft:white_concrete
fill 112 216 288 113 223 288 minecraft:basalt
fill 112 216 308 113 223 308 minecraft:basalt
fill 112 216 317 112 217 317 minecraft:white_concrete
fill 113 216 281 114 216 281 minecraft:basalt
fill 113 216 315 115 216 315 minecraft:basalt
fill 114 216 275 115 217 275 minecraft:red_concrete
fill 114 216 287 118 222 287 minecraft:basalt
fill 114 216 317 115 217 317 minecraft:red_concrete
fill 115 216 309 115 222 309 minecraft:basalt
fill 116 216 275 116 217 275 minecraft:white_concrete
fill 116 216 281 118 216 281 minecraft:basalt
setblock 116 216 309 minecraft:magma_block
setblock 116 216 315 minecraft:magma_block
fill 116 216 317 117 217 317 minecraft:white_concrete
fill 117 216 286 117 222 286 minecraft:basalt
fill 117 216 309 117 222 310 minecraft:basalt
fill 117 216 315 120 216 315 minecraft:basalt
fill 117 216 316 118 272 316 minecraft:red_terracotta
fill 118 216 275 119 217 275 minecraft:red_concrete
fill 118 216 309 120 223 309 minecraft:basalt
fill 118 216 317 119 217 317 minecraft:red_concrete
setblock 119 216 281 minecraft:magma_block
setblock 119 216 287 minecraft:magma_block
fill 120 216 275 121 217 275 minecraft:white_concrete
fill 120 216 281 121 216 281 minecraft:basalt
fill 120 216 317 120 217 317 minecraft:white_concrete
fill 121 216 288 122 216 288 minecraft:basalt
fill 121 216 308 123 222 308 minecraft:basalt
fill 122 216 275 123 217 275 minecraft:red_concrete
fill 122 216 282 124 216 283 minecraft:basalt
fill 122 216 317 123 217 317 minecraft:red_concrete
fill 123 216 289 123 223 289 minecraft:basalt
fill 123 216 307 123 223 307 minecraft:basalt
fill 124 216 275 124 217 275 minecraft:white_concrete
fill 124 216 317 125 217 317 minecraft:white_concrete
fill 125 216 283 126 216 284 minecraft:basalt
setblock 125 216 306 minecraft:magma_block
fill 125 216 312 127 216 312 minecraft:basalt
fill 126 216 275 127 217 275 minecraft:red_concrete
fill 126 216 292 126 223 292 minecraft:basalt
fill 126 216 304 126 223 304 minecraft:basalt
fill 126 216 311 127 217 311 minecraft:basalt
fill 126 216 317 127 217 317 minecraft:red_concrete
setblock 127 216 284 minecraft:basalt
fill 127 216 293 127 222 294 minecraft:basalt
fill 127 216 302 127 222 303 minecraft:basalt
fill 128 216 275 129 217 275 minecraft:white_concrete
setblock 128 216 296 minecraft:magma_block
fill 128 216 297 128 223 298 minecraft:basalt
setblock 128 216 299 minecraft:magma_block
fill 128 216 300 129 222 300 minecraft:basalt
fill 128 216 310 129 216 310 minecraft:basalt
setblock 128 216 311 minecraft:magma_block
fill 128 216 317 128 217 317 minecraft:white_concrete
fill 129 216 286 129 216 287 minecraft:basalt
fill 129 216 297 129 222 297 minecraft:basalt
fill 130 216 275 131 217 275 minecraft:red_concrete
setblock 130 216 287 minecraft:basalt
fill 130 216 289 132 216 289 minecraft:basalt
fill 130 216 317 131 217 317 minecraft:red_concrete
setblock 131 216 288 minecraft:basalt
fill 131 216 306 132 216 306 minecraft:basalt
fill 132 216 275 132 217 275 minecraft:white_concrete
setblock 132 216 307 minecraft:basalt
fill 132 216 317 133 217 317 minecraft:white_concrete
fill 133 216 291 133 216 292 minecraft:basalt
fill 133 216 294 133 217 295 minecraft:basalt
fill 133 216 297 133 217 298 minecraft:basalt
fill 133 216 300 133 217 301 minecraft:basalt
fill 133 216 303 133 216 304 minecraft:basalt
fill 134 216 275 135 217 275 minecraft:red_concrete
setblock 134 216 294 minecraft:magma_block
fill 134 216 295 134 216 296 minecraft:basalt
setblock 134 216 297 minecraft:magma_block
fill 134 216 298 134 216 299 minecraft:basalt
setblock 134 216 300 minecraft:magma_block
setblock 134 216 301 minecraft:basalt
fill 134 216 317 135 217 317 minecraft:red_concrete
fill 135 216 301 135 268 301 minecraft:red_terracotta
fill 136 216 276 136 217 276 minecraft:red_concrete
fill 136 216 277 136 217 278 minecraft:white_concrete
fill 136 216 279 136 217 279 minecraft:red_concrete
fill 136 216 281 136 217 282 minecraft:white_concrete
fill 136 216 283 136 217 284 minecraft:red_concrete
fill 136 216 285 136 217 286 minecraft:white_concrete
fill 136 216 287 136 217 287 minecraft:red_concrete
fill 136 216 289 136 217 290 minecraft:white_concrete
fill 136 216 291 136 217 292 minecraft:red_concrete
fill 136 216 293 136 217 294 minecraft:white_concrete
fill 136 216 295 136 217 295 minecraft:red_concrete
fill 136 216 297 136 217 298 minecraft:white_concrete
fill 136 216 299 136 217 300 minecraft:red_concrete
fill 136 216 301 136 217 302 minecraft:white_concrete
fill 136 216 303 136 217 303 minecraft:red_concrete
fill 136 216 305 136 217 306 minecraft:white_concrete
fill 136 216 307 136 217 308 minecraft:red_concrete
fill 136 216 309 136 217 310 minecraft:white_concrete
fill 136 216 311 136 217 311 minecraft:red_concrete
fill 136 216 313 136 217 314 minecraft:white_concrete
fill 136 216 315 136 217 316 minecraft:red_concrete
fill 136 216 317 136 217 317 minecraft:white_concrete
setblock 95 217 289 minecraft:brown_terracotta
fill 96 217 283 99 217 283 minecraft:brown_terracotta
fill 96 217 290 98 217 290 minecraft:brown_terracotta
setblock 99 217 289 minecraft:brown_terracotta
fill 100 217 284 100 217 285 minecraft:brown_terracotta
fill 100 217 287 100 217 288 minecraft:brown_terracotta
setblock 101 217 294 minecraft:basalt
fill 101 217 296 101 217 297 minecraft:basalt
fill 101 217 299 101 217 300 minecraft:basalt
setblock 101 217 302 minecraft:basalt
fill 102 217 291 102 217 292 minecraft:basalt
fill 102 217 303 102 217 305 minecraft:basalt
fill 103 217 289 103 217 290 minecraft:basalt
fill 103 217 304 103 218 305 minecraft:basalt
setblock 103 217 306 minecraft:magma_block
fill 103 217 307 104 217 307 minecraft:basalt
setblock 104 217 308 minecraft:basalt
setblock 105 217 287 minecraft:basalt
fill 105 217 299 105 222 299 minecraft:basalt
setblock 105 217 309 minecraft:basalt
setblock 106 217 286 minecraft:basalt
setblock 106 217 299 minecraft:magma_block
setblock 106 217 310 minecraft:basalt
setblock 107 217 285 minecraft:basalt
fill 107 217 294 107 223 296 minecraft:basalt
fill 107 217 300 107 223 301 minecraft:basalt
fill 107 217 303 108 217 303 minecraft:basalt
fill 108 217 284 109 217 284 minecraft:basalt
fill 108 217 293 108 223 293 minecraft:basalt
setblock 108 217 312 minecraft:basalt
fill 109 217 291 109 223 291 minecraft:basalt
fill 109 217 305 109 222 305 minecraft:basalt
fill 110 217 290 110 223 290 minecraft:basalt
fill 110 217 306 110 223 306 minecraft:basalt
fill 112 217 289 112 222 289 minecraft:basalt
fill 112 217 307 112 222 307 minecraft:basalt
setblock 113 217 281 minecraft:yellow_wool
fill 113 217 282 116 217 282 minecraft:basalt
fill 113 217 314 114 217 314 minecraft:basalt
fill 114 217 288 115 222 288 minecraft:basalt
fill 114 217 308 114 223 308 minecraft:basalt
setblock 115 217 308 minecraft:magma_block
fill 115 217 313 115 218 313 minecraft:basalt
setblock 115 217 314 minecraft:magma_block
fill 116 217 309 116 223 309 minecraft:basalt
fill 116 217 314 121 217 314 minecraft:basalt
fill 118 217 282 120 217 282 minecraft:basalt
fill 119 217 287 119 223 288 minecraft:basalt
fill 119 217 308 120 223 308 minecraft:basalt
fill 120 217 288 120 223 288 minecraft:basalt
setblock 121 217 282 minecraft:magma_block
setblock 121 217 288 minecraft:magma_block
fill 122 217 283 124 217 283 minecraft:basalt
fill 122 217 288 122 223 289 minecraft:basalt
fill 122 217 307 122 223 307 minecraft:basalt
fill 122 217 313 124 217 313 minecraft:basalt
setblock 124 217 290 minecraft:magma_block
fill 124 217 306 125 222 306 minecraft:basalt
fill 125 217 284 126 217 284 minecraft:basalt
fill 125 217 291 125 223 291 minecraft:basalt
fill 125 217 305 125 223 305 minecraft:basalt
fill 125 217 312 126 217 312 minecraft:basalt
fill 126 217 293 126 223 293 minecraft:basalt
setblock 126 217 303 minecraft:basalt
setblock 127 217 295 minecraft:magma_block
fill 127 217 296 128 222 296 minecraft:basalt
fill 127 217 300 127 223 300 minecraft:basalt
setblock 127 217 301 minecraft:magma_block
setblock 128 217 286 minecraft:basalt
fill 128 217 299 128 223 299 minecraft:basalt
setblock 128 217 310 minecraft:basalt
fill 129 217 287 129 217 288 minecraft:basalt
setblock 130 217 288 minecraft:magma_block
fill 130 217 289 131 217 289 minecraft:basalt
fill 130 217 307 130 217 308 minecraft:basalt
setblock 131 217 290 minecraft:basalt
fill 131 217 306 131 217 307 minecraft:basalt
fill 132 217 296 132 218 296 minecraft:basalt
fill 132 217 302 132 218 302 minecraft:basalt
setblock 133 217 296 minecraft:magma_block
setblock 133 217 299 minecraft:magma_block
setblock 133 217 302 minecraft:magma_block
fill 94 218 275 94 219 276 minecraft:white_concrete
fill 94 218 277 94 219 278 minecraft:red_concrete
fill 94 218 279 94 219 279 minecraft:white_concrete
fill 94 218 281 94 219 282 minecraft:red_concrete
fill 94 218 283 94 219 284 minecraft:white_concrete
fill 94 218 285 94 219 286 minecraft:red_concrete
fill 94 218 287 94 219 287 minecraft:white_concrete
fill 94 218 289 94 219 290 minecraft:red_concrete
fill 94 218 291 94 219 292 minecraft:white_concrete
fill 94 218 293 94 219 294 minecraft:red_concrete
fill 94 218 295 94 219 295 minecraft:white_concrete
fill 94 218 297 94 219 298 minecraft:red_concrete
fill 94 218 299 94 219 300 minecraft:white_concrete
fill 94 218 301 94 219 302 minecraft:red_concrete
fill 94 218 303 94 219 303 minecraft:white_concrete
fill 94 218 305 94 219 306 minecraft:red_concrete
fill 94 218 307 94 219 308 minecraft:white_concrete
fill 94 218 309 94 219 310 minecraft:red_concrete
fill 94 218 311 94 219 311 minecraft:white_concrete
fill 94 218 313 94 219 314 minecraft:red_concrete
fill 94 218 315 94 219 316 minecraft:white_concrete
fill 95 218 275 95 219 275 minecraft:white_concrete
fill 95 218 317 95 219 317 minecraft:white_concrete
fill 96 218 275 97 219 275 minecraft:red_concrete
setblock 96 218 281 minecraft:iron_block
fill 96 218 317 96 219 317 minecraft:red_concrete
setblock 97 218 280 minecraft:iron_block
fill 97 218 281 99 218 281 minecraft:black_concrete
setblock 97 218 282 minecraft:iron_block
fill 98 218 275 99 219 275 minecraft:white_concrete
setblock 98 218 279 minecraft:iron_block
setblock 98 218 280 minecraft:black_concrete
setblock 98 218 282 minecraft:black_concrete
setblock 98 218 283 minecraft:iron_block
fill 98 218 317 99 219 317 minecraft:white_concrete
fill 99 218 279 100 272 279 minecraft:red_terracotta
setblock 99 218 280 minecraft:iron_block
setblock 99 218 282 minecraft:iron_block
fill 100 218 275 100 219 275 minecraft:red_concrete
fill 100 218 280 100 272 280 minecraft:red_terracotta
setblock 100 218 281 minecraft:iron_block
fill 100 218 317 101 219 317 minecraft:red_concrete
fill 102 218 275 103 219 275 minecraft:white_concrete
setblock 102 218 293 minecraft:magma_block
setblock 102 218 296 minecraft:magma_block
fill 102 218 297 102 218 298 minecraft:basalt
setblock 102 218 299 minecraft:magma_block
setblock 102 218 302 minecraft:magma_block
setblock 102 218 303 minecraft:basalt
fill 102 218 317 103 219 317 minecraft:white_concrete
fill 103 218 293 103 219 293 minecraft:basalt
fill 104 218 275 105 219 275 minecraft:red_concrete
setblock 104 218 307 minecraft:basalt
fill 104 218 317 104 219 317 minecraft:red_concrete
setblock 105 218 289 minecraft:magma_block
setblock 105 218 307 minecraft:magma_block
fill 106 218 275 107 219 275 minecraft:white_concrete
fill 106 218 299 107 223 299 minecraft:basalt
fill 106 218 317 107 219 317 minecraft:white_concrete
fill 107 218 297 107 223 298 minecraft:basalt
fill 107 218 303 107 223 303 minecraft:basalt
fill 108 218 275 108 219 275 minecraft:red_concrete
setblock 108 218 285 minecraft:magma_block
setblock 108 218 286 minecraft:basalt
setblock 108 218 294 minecraft:magma_block
fill 108 218 295 108 223 295 minecraft:basalt
fill 108 218 301 108 223 302 minecraft:basalt
setblock 108 218 303 minecraft:magma_block
setblock 108 218 311 minecraft:basalt
fill 108 218 317 109 219 317 minecraft:red_concrete
fill 109 218 292 109 223 292 minecraft:basalt
fill 109 218 304 109 223 304 minecraft:basalt
fill 110 218 275 111 219 275 minecraft:white_concrete
fill 110 218 291 110 223 291 minecraft:basalt
fill 110 218 305 110 223 305 minecraft:basalt
fill 110 218 317 111 219 317 minecraft:white_concrete
setblock 111 218 284 minecraft:magma_block
setblock 111 218 290 minecraft:magma_block
fill 111 218 306 111 223 306 minecraft:basalt
fill 112 218 275 113 219 275 minecraft:red_concrete
fill 112 218 283 112 218 284 minecraft:basalt
setblock 112 218 313 minecraft:basalt
fill 112 218 317 112 219 317 minecraft:red_concrete
fill 113 218 284 113 219 284 minecraft:basalt
fill 113 218 289 113 223 289 minecraft:basalt
fill 113 218 307 113 223 307 minecraft:basalt
fill 114 218 275 115 219 275 minecraft:white_concrete
setblock 114 218 283 minecraft:magma_block
setblock 114 218 289 minecraft:magma_block
setblock 114 218 307 minecraft:magma_block
setblock 114 218 313 minecraft:magma_block
fill 114 218 317 115 219 317 minecraft:white_concrete
fill 115 218 308 118 222 308 minecraft:basalt
fill 116 218 275 116 219 275 minecraft:red_concrete
fill 116 218 288 116 223 288 minecraft:basalt
fill 116 218 317 117 219 317 minecraft:red_concrete
setblock 117 218 288 minecraft:magma_block
fill 118 218 275 119 219 275 minecraft:white_concrete
fill 118 218 288 118 223 288 minecraft:basalt
fill 118 218 317 119 219 317 minecraft:white_concrete
fill 120 218 275 121 219 275 minecraft:red_concrete
fill 120 218 289 121 222 289 minecraft:basalt
fill 120 218 307 121 222 307 minecraft:basalt
fill 120 218 317 120 219 317 minecraft:red_concrete
fill 121 218 288 121 223 288 minecraft:basalt
fill 122 218 275 123 219 275 minecraft:white_concrete
setblock 122 218 283 minecraft:basalt
setblock 122 218 313 minecraft:basalt
fill 122 218 317 123 219 317 minecraft:white_concrete
fill 123 218 290 124 223 290 minecraft:basalt
fill 123 218 306 123 223 306 minecraft:basalt
fill 124 218 275 124 219 275 minecraft:red_concrete
fill 124 218 291 124 222 291 minecraft:basalt
fill 124 218 305 124 223 305 minecraft:basalt
fill 124 218 317 125 219 317 minecraft:red_concrete
fill 125 218 292 125 223 292 minecraft:basalt
fill 125 218 304 125 223 304 minecraft:basalt
fill 126 218 275 127 219 275 minecraft:white_concrete
setblock 126 218 285 minecraft:magma_block
fill 126 218 286 127 218 286 minecraft:basalt
setblock 126 218 294 minecraft:magma_block
fill 126 218 295 127 223 295 minecraft:basalt
fill 126 218 301 126 223 302 minecraft:basalt
setblock 126 218 303 minecraft:magma_block
setblock 126 218 311 minecraft:basalt
fill 126 218 317 127 219 317 minecraft:white_concrete
fill 127 218 297 127 222 299 minecraft:basalt
fill 127 218 301 127 223 301 minecraft:basalt
fill 128 218 275 129 219 275 minecraft:red_concrete
fill 128 218 308 128 219 308 minecraft:basalt
fill 128 218 317 128 219 317 minecraft:red_concrete
setblock 129 218 288 minecraft:basalt
setblock 129 218 308 minecraft:magma_block
fill 130 218 275 131 219 275 minecraft:white_concrete
setblock 130 218 289 minecraft:basalt
setblock 130 218 307 minecraft:basalt
fill 130 218 317 131 219 317 minecraft:white_concrete
fill 132 218 275 132 219 275 minecraft:red_concrete
setblock 132 218 293 minecraft:basalt
setblock 132 218 295 minecraft:magma_block
setblock 132 218 297 minecraft:basalt
setblock 132 218 298 minecraft:magma_block
setblock 132 218 299 minecraft:basalt
setblock 132 218 301 minecraft:magma_block
setblock 132 218 303 minecraft:basalt
fill 132 218 317 133 219 317 minecraft:red_concrete
fill 134 218 275 135 219 275 minecraft:white_concrete
fill 134 218 317 135 219 317 minecraft:white_concrete
fill 136 218 276 136 219 276 minecraft:white_concrete
fill 136 218 277 136 219 278 minecraft:red_concrete
fill 136 218 279 136 219 279 minecraft:white_concrete
fill 136 218 281 136 219 282 minecraft:red_concrete
fill 136 218 283 136 219 284 minecraft:white_concrete
fill 136 218 285 136 219 286 minecraft:red_concrete
fill 136 218 287 136 219 287 minecraft:white_concrete
fill 136 218 289 136 219 290 minecraft:red_concrete
fill 136 218 291 136 219 292 minecraft:white_concrete
fill 136 218 293 136 219 294 minecraft:red_concrete
fill 136 218 295 136 219 295 minecraft:white_concrete
fill 136 218 297 136 219 298 minecraft:red_concrete
fill 136 218 299 136 219 300 minecraft:white_concrete
fill 136 218 301 136 219 302 minecraft:red_concrete
fill 136 218 303 136 219 303 minecraft:white_concrete
fill 136 218 305 136 219 306 minecraft:red_concrete
fill 136 218 307 136 219 308 minecraft:white_concrete
fill 136 218 309 136 219 310 minecraft:red_concrete
fill 136 218 311 136 219 311 minecraft:white_concrete
fill 136 218 313 136 219 314 minecraft:red_concrete
fill 136 218 315 136 219 316 minecraft:white_concrete
fill 136 218 317 136 219 317 minecraft:red_concrete
setblock 97 219 278 minecraft:light[level=12]
fill 97 219 279 97 219 281 minecraft:brown_terracotta
setblock 97 219 292 minecraft:light[level=12]
setblock 97 219 299 minecraft:light[level=12]
setblock 97 219 306 minecraft:light[level=12]
setblock 97 219 313 minecraft:light[level=12]
fill 98 219 278 100 219 278 minecraft:brown_terracotta
fill 98 219 279 98 272 281 minecraft:red_terracotta
fill 98 219 282 100 219 282 minecraft:brown_terracotta
fill 99 219 280 99 272 281 minecraft:red_terracotta
fill 100 219 281 100 272 281 minecraft:red_terracotta
fill 101 219 279 101 219 281 minecraft:brown_terracotta
setblock 104 219 278 minecraft:light[level=12]
setblock 104 219 285 minecraft:light[level=12]
setblock 104 219 291 minecraft:magma_block
fill 104 219 292 104 219 293 minecraft:basalt
setblock 104 219 306 minecraft:light[level=12]
setblock 104 219 313 minecraft:light[level=12]
setblock 105 219 306 minecraft:basalt
setblock 107 219 287 minecraft:magma_block
setblock 107 219 288 minecraft:basalt
setblock 107 219 308 minecraft:magma_block
fill 108 219 285 108 219 286 minecraft:green_concrete
fill 108 219 294 109 219 294 minecraft:basalt
fill 108 219 296 108 223 300 minecraft:basalt
fill 108 219 303 109 223 303 minecraft:basalt
setblock 109 219 285 minecraft:green_concrete
fill 109 219 293 109 222 293 minecraft:basalt
fill 109 219 302 109 222 302 minecraft:basalt
setblock 110 219 292 minecraft:magma_block
setblock 110 219 304 minecraft:magma_block
setblock 111 219 278 minecraft:light[level=12]
fill 111 219 290 111 223 291 minecraft:basalt
setblock 111 219 292 minecraft:light[level=12]
setblock 111 219 299 minecraft:light[level=12]
fill 111 219 305 111 223 305 minecraft:basalt
setblock 111 219 313 minecraft:light[level=12]
setblock 112 219 284 minecraft:basalt
fill 112 219 290 113 223 290 minecraft:basalt
fill 112 219 306 112 223 306 minecraft:basalt
setblock 113 219 306 minecraft:magma_block
setblock 113 219 312 minecraft:magma_block
fill 114 219 284 115 219 284 minecraft:basalt
fill 114 219 289 118 223 289 minecraft:basalt
fill 114 219 307 118 223 307 minecraft:basalt
fill 114 219 312 117 219 312 minecraft:basalt
setblock 116 219 284 minecraft:magma_block
fill 117 219 288 117 223 288 minecraft:basalt
setblock 118 219 278 minecraft:light[level=12]
setblock 118 219 292 minecraft:light[level=12]
setblock 118 219 299 minecraft:light[level=12]
setblock 118 219 306 minecraft:light[level=12]
setblock 118 219 313 minecraft:light[level=12]
setblock 119 219 289 minecraft:magma_block
setblock 119 219 307 minecraft:magma_block
setblock 119 219 312 minecraft:basalt
fill 121 219 290 122 219 290 minecraft:basalt
fill 121 219 306 121 223 306 minecraft:basalt
setblock 122 219 306 minecraft:magma_block
fill 122 219 311 122 220 311 minecraft:basalt
setblock 122 219 312 minecraft:magma_block
fill 123 219 291 123 223 291 minecraft:basalt
fill 123 219 305 123 223 305 minecraft:basalt
fill 124 219 292 124 223 292 minecraft:basalt
fill 124 219 304 124 223 304 minecraft:basalt
setblock 125 219 278 minecraft:light[level=12]
setblock 125 219 285 minecraft:light[level=12]
setblock 125 219 293 minecraft:magma_block
fill 125 219 294 126 223 294 minecraft:basalt
setblock 125 219 299 minecraft:light[level=12]
setblock 125 219 302 minecraft:magma_block
fill 125 219 303 126 223 303 minecraft:basalt
setblock 125 219 310 minecraft:basalt
setblock 125 219 313 minecraft:light[level=12]
fill 126 219 296 126 223 300 minecraft:basalt
setblock 128 219 289 minecraft:magma_block
setblock 128 219 307 minecraft:magma_block
setblock 131 219 294 minecraft:magma_block
fill 131 219 295 131 219 296 minecraft:basalt
setblock 131 219 297 minecraft:magma_block
fill 131 219 298 131 220 299 minecraft:basalt
setblock 131 219 300 minecraft:magma_block
setblock 131 219 301 minecraft:basalt
setblock 131 219 303 minecraft:magma_block
setblock 132 219 278 minecraft:light[level=12]
setblock 132 219 285 minecraft:light[level=12]
setblock 132 219 292 minecraft:light[level=12]
setblock 132 219 299 minecraft:light[level=12]
setblock 132 219 306 minecraft:light[level=12]
setblock 132 219 313 minecraft:light[level=12]
fill 94 220 275 94 221 276 minecraft:red_concrete
fill 94 220 277 94 221 278 minecraft:white_concrete
fill 94 220 279 94 221 280 minecraft:red_concrete
fill 94 220 281 94 221 282 minecraft:white_concrete
fill 94 220 283 94 221 284 minecraft:red_concrete
fill 94 220 285 94 221 286 minecraft:white_concrete
fill 94 220 287 94 221 288 minecraft:red_concrete
fill 94 220 289 94 221 290 minecraft:white_concrete
fill 94 220 291 94 221 292 minecraft:red_concrete
fill 94 220 293 94 221 294 minecraft:white_concrete
fill 94 220 295 94 221 296 minecraft:red_concrete
fill 94 220 297 94 221 298 minecraft:white_concrete
fill 94 220 299 94 221 300 minecraft:red_concrete
fill 94 220 301 94 221 302 minecraft:white_concrete
fill 94 220 303 94 221 304 minecraft:red_concrete
fill 94 220 305 94 221 306 minecraft:white_concrete
fill 94 220 307 94 221 308 minecraft:red_concrete
fill 94 220 309 94 221 310 minecraft:white_concrete
fill 94 220 311 94 221 312 minecraft:red_concrete
fill 94 220 313 94 221 314 minecraft:white_concrete
fill 94 220 315 94 221 316 minecraft:red_concrete
fill 95 220 275 95 221 275 minecraft:red_concrete
fill 95 220 317 95 221 317 minecraft:red_concrete
fill 96 220 275 97 221 275 minecraft:white_concrete
fill 96 220 307 101 220 307 minecraft:brown_terracotta
fill 96 220 317 97 221 317 minecraft:white_concrete
fill 97 220 305 101 221 306 minecraft:brown_terracotta
fill 97 220 308 101 221 309 minecraft:brown_terracotta
fill 98 220 275 99 221 275 minecraft:red_concrete
fill 98 220 317 99 221 317 minecraft:red_concrete
fill 100 220 275 101 221 275 minecraft:white_concrete
fill 100 220 317 101 221 317 minecraft:white_concrete
fill 102 220 275 103 221 275 minecraft:red_concrete
fill 102 220 317 103 221 317 minecraft:red_concrete
setblock 103 220 299 minecraft:magma_block
fill 104 220 275 105 221 275 minecraft:white_concrete
setblock 104 220 293 minecraft:basalt
fill 104 220 302 104 220 303 minecraft:basalt
fill 104 220 317 105 221 317 minecraft:white_concrete
fill 106 220 275 107 221 275 minecraft:red_concrete
setblock 106 220 290 minecraft:basalt
setblock 106 220 306 minecraft:basalt
fill 106 220 317 107 221 317 minecraft:red_concrete
setblock 107 220 289 minecraft:basalt
fill 108 220 275 109 221 275 minecraft:white_concrete
fill 108 220 294 108 223 294 minecraft:basalt
fill 108 220 317 109 221 317 minecraft:white_concrete
setblock 109 220 294 minecraft:magma_block
fill 109 220 295 109 222 296 minecraft:basalt
setblock 109 220 300 minecraft:magma_block
fill 109 220 301 109 223 301 minecraft:basalt
setblock 109 220 309 minecraft:magma_block
fill 110 220 275 111 221 275 minecraft:red_concrete
setblock 110 220 286 minecraft:basalt
fill 110 220 292 110 223 293 minecraft:basalt
fill 110 220 303 110 223 304 minecraft:basalt
setblock 110 220 310 minecraft:basalt
fill 110 220 317 111 221 317 minecraft:red_concrete
fill 111 220 292 111 223 292 minecraft:basalt
fill 111 220 304 111 223 304 minecraft:basalt
fill 112 220 275 113 221 275 minecraft:white_concrete
setblock 112 220 285 minecraft:basalt
fill 112 220 291 112 223 291 minecraft:basalt
setblock 112 220 305 minecraft:magma_block
setblock 112 220 311 minecraft:magma_block
fill 112 220 317 113 221 317 minecraft:white_concrete
fill 113 220 306 115 222 306 minecraft:basalt
fill 113 220 311 114 220 311 minecraft:basalt
fill 114 220 275 115 221 275 minecraft:red_concrete
fill 114 220 277 114 220 279 minecraft:red_terracotta
fill 114 220 290 115 223 290 minecraft:basalt
fill 114 220 317 115 221 317 minecraft:red_concrete
fill 115 220 277 116 220 277 minecraft:red_terracotta
fill 115 220 279 116 220 279 minecraft:red_terracotta
fill 116 220 275 117 221 275 minecraft:white_concrete
setblock 116 220 278 minecraft:red_terracotta
setblock 116 220 284 minecraft:basalt
fill 116 220 312 117 220 312 minecraft:basalt
fill 116 220 317 117 221 317 minecraft:white_concrete
fill 118 220 275 119 221 275 minecraft:red_concrete
setblock 118 220 284 minecraft:basalt
setblock 118 220 312 minecraft:magma_block
fill 118 220 317 119 221 317 minecraft:red_concrete
fill 119 220 289 119 223 290 minecraft:basalt
fill 119 220 306 119 223 307 minecraft:basalt
fill 120 220 275 121 221 275 minecraft:white_concrete
fill 120 220 290 120 223 290 minecraft:basalt
fill 120 220 306 120 223 306 minecraft:basalt
setblock 120 220 311 minecraft:basalt
fill 120 220 317 121 221 317 minecraft:white_concrete
setblock 121 220 290 minecraft:magma_block
setblock 121 220 311 minecraft:magma_block
fill 122 220 275 123 221 275 minecraft:red_concrete
setblock 122 220 285 minecraft:basalt
fill 122 220 290 122 223 291 minecraft:basalt
fill 122 220 305 122 223 306 minecraft:basalt
fill 122 220 317 123 221 317 minecraft:red_concrete
setblock 123 220 286 minecraft:basalt
fill 123 220 292 123 223 292 minecraft:basalt
fill 123 220 304 123 223 304 minecraft:basalt
setblock 123 220 310 minecraft:basalt
fill 124 220 275 125 221 275 minecraft:white_concrete
setblock 124 220 286 minecraft:magma_block
fill 124 220 293 125 223 293 minecraft:basalt
fill 124 220 303 124 222 303 minecraft:basalt
setblock 124 220 310 minecraft:magma_block
fill 124 220 317 125 221 317 minecraft:white_concrete
fill 125 220 295 125 223 296 minecraft:basalt
fill 125 220 300 125 223 302 minecraft:basalt
fill 126 220 275 127 221 275 minecraft:red_concrete
setblock 126 220 288 minecraft:basalt
fill 126 220 317 127 221 317 minecraft:red_concrete
fill 128 220 275 129 221 275 minecraft:white_concrete
fill 128 220 283 132 221 287 minecraft:brown_terracotta
fill 128 220 317 129 221 317 minecraft:white_concrete
setblock 129 220 291 minecraft:basalt
setblock 129 220 305 minecraft:basalt
fill 130 220 275 131 221 275 minecraft:red_concrete
setblock 130 220 293 minecraft:magma_block
fill 130 220 294 130 220 295 minecraft:basalt
setblock 130 220 296 minecraft:magma_block
fill 130 220 297 130 220 301 minecraft:basalt
setblock 130 220 302 minecraft:magma_block
setblock 130 220 303 minecraft:basalt
fill 130 220 317 131 221 317 minecraft:red_concrete
setblock 131 220 297 minecraft:basalt
fill 132 220 275 133 221 275 minecraft:white_concrete
fill 132 220 317 133 221 317 minecraft:white_concrete
fill 133 220 285 134 220 285 minecraft:brown_terracotta
fill 134 220 275 135 221 275 minecraft:red_concrete
fill 134 220 317 135 221 317 minecraft:red_concrete
fill 136 220 276 136 221 276 minecraft:red_concrete
fill 136 220 277 136 221 278 minecraft:white_concrete
fill 136 220 279 136 221 280 minecraft:red_concrete
fill 136 220 281 136 221 282 minecraft:white_concrete
fill 136 220 283 136 221 284 minecraft:red_concrete
fill 136 220 285 136 221 286 minecraft:white_concrete
fill 136 220 287 136 221 288 minecraft:red_concrete
fill 136 220 289 136 221 290 minecraft:white_concrete
fill 136 220 291 136 221 292 minecraft:red_concrete
fill 136 220 293 136 221 294 minecraft:white_concrete
fill 136 220 295 136 221 296 minecraft:red_concrete
fill 136 220 297 136 221 298 minecraft:white_concrete
fill 136 220 299 136 221 300 minecraft:red_concrete
fill 136 220 301 136 221 302 minecraft:white_concrete
fill 136 220 303 136 221 304 minecraft:red_concrete
fill 136 220 305 136 221 306 minecraft:white_concrete
fill 136 220 307 136 221 308 minecraft:red_concrete
fill 136 220 309 136 221 310 minecraft:white_concrete
fill 136 220 311 136 221 312 minecraft:red_concrete
fill 136 220 313 136 221 314 minecraft:white_concrete
fill 136 220 315 136 221 316 minecraft:red_concrete
fill 136 220 317 136 221 317 minecraft:white_concrete
setblock 97 221 278 minecraft:light[level=15]
setblock 97 221 294 minecraft:light[level=15]
setblock 97 221 300 minecraft:red_terracotta
setblock 97 221 302 minecraft:red_terracotta
fill 97 221 307 101 221 307 minecraft:brown_terracotta
setblock 97 221 310 minecraft:light[level=15]
setblock 99 221 300 minecraft:red_terracotta
setblock 99 221 302 minecraft:red_terracotta
setblock 105 221 278 minecraft:light[level=15]
setblock 105 221 286 minecraft:light[level=15]
setblock 105 221 293 minecraft:basalt
setblock 105 221 294 minecraft:magma_block
setblock 105 221 302 minecraft:basalt
setblock 105 221 303 minecraft:magma_block
setblock 105 221 310 minecraft:light[level=15]
setblock 106 221 291 minecraft:basalt
setblock 108 221 307 minecraft:basalt
fill 109 221 294 110 223 294 minecraft:basalt
fill 109 221 297 109 222 300 minecraft:basalt
fill 110 221 295 110 223 295 minecraft:basalt
fill 110 221 301 110 223 302 minecraft:basalt
fill 111 221 293 111 223 293 minecraft:basalt
fill 111 221 303 111 223 303 minecraft:basalt
fill 112 221 286 113 221 286 minecraft:basalt
fill 112 221 292 112 222 292 minecraft:basalt
fill 112 221 304 112 222 305 minecraft:basalt
fill 112 221 310 113 221 310 minecraft:basalt
setblock 113 221 278 minecraft:light[level=15]
fill 113 221 291 113 223 291 minecraft:basalt
setblock 113 221 294 minecraft:light[level=15]
setblock 113 221 302 minecraft:light[level=15]
fill 113 221 305 114 223 305 minecraft:basalt
setblock 114 221 291 minecraft:magma_block
fill 115 221 285 118 221 285 minecraft:basalt
fill 115 221 311 116 221 311 minecraft:basalt
fill 116 221 290 116 223 290 minecraft:basalt
fill 116 221 306 118 223 306 minecraft:basalt
setblock 117 221 290 minecraft:magma_block
setblock 117 221 311 minecraft:magma_block
fill 118 221 286 119 222 286 minecraft:basalt
fill 118 221 290 118 222 290 minecraft:basalt
fill 118 221 310 119 221 311 minecraft:basalt
setblock 120 221 286 minecraft:magma_block
fill 120 221 291 121 223 291 minecraft:basalt
fill 120 221 305 121 223 305 minecraft:basalt
setblock 120 221 310 minecraft:magma_block
setblock 121 221 278 minecraft:light[level=15]
setblock 121 221 286 minecraft:basalt
fill 121 221 290 121 223 290 minecraft:basalt
setblock 121 221 294 minecraft:light[level=15]
setblock 121 221 302 minecraft:light[level=15]
setblock 121 221 310 minecraft:basalt
fill 122 221 292 122 223 292 minecraft:basalt
fill 122 221 304 122 223 304 minecraft:basalt
fill 123 221 293 123 223 293 minecraft:basalt
setblock 123 221 303 minecraft:magma_block
setblock 123 221 309 minecraft:magma_block
fill 124 221 294 124 222 295 minecraft:basalt
fill 124 221 301 124 223 302 minecraft:basalt
fill 125 221 297 125 223 299 minecraft:basalt
setblock 125 221 308 minecraft:basalt
fill 128 221 290 128 222 290 minecraft:brown_terracotta
setblock 129 221 278 minecraft:light[level=15]
fill 129 221 293 129 221 294 minecraft:basalt
setblock 129 221 295 minecraft:magma_block
fill 129 221 296 130 221 296 minecraft:basalt
setblock 129 221 301 minecraft:magma_block
fill 129 221 302 129 221 303 minecraft:basalt
setblock 129 221 310 minecraft:light[level=15]
fill 130 221 297 130 221 300 minecraft:basalt
fill 94 222 275 94 223 276 minecraft:white_concrete
fill 94 222 277 94 223 278 minecraft:red_concrete
fill 94 222 279 94 223 280 minecraft:white_concrete
fill 94 222 281 94 223 282 minecraft:red_concrete
fill 94 222 283 94 223 284 minecraft:white_concrete
fill 94 222 285 94 223 286 minecraft:red_concrete
fill 94 222 287 94 223 288 minecraft:white_concrete
fill 94 222 289 94 223 290 minecraft:red_concrete
fill 94 222 291 94 223 292 minecraft:white_concrete
fill 94 222 293 94 223 294 minecraft:red_concrete
fill 94 222 295 94 223 296 minecraft:white_concrete
fill 94 222 297 94 223 298 minecraft:red_concrete
fill 94 222 299 94 223 300 minecraft:white_concrete
fill 94 222 301 94 223 302 minecraft:red_concrete
fill 94 222 303 94 223 304 minecraft:white_concrete
fill 94 222 305 94 223 306 minecraft:red_concrete
fill 94 222 307 94 223 308 minecraft:white_concrete
fill 94 222 309 94 223 310 minecraft:red_concrete
fill 94 222 311 94 223 312 minecraft:white_concrete
fill 94 222 313 94 223 314 minecraft:red_concrete
fill 94 222 315 94 223 316 minecraft:white_concrete
fill 95 222 275 95 223 275 minecraft:white_concrete
fill 95 222 317 95 223 317 minecraft:white_concrete
fill 96 222 275 97 223 275 minecraft:red_concrete
fill 96 222 317 97 223 317 minecraft:red_concrete
fill 98 222 275 99 223 275 minecraft:white_concrete
fill 98 222 317 99 223 317 minecraft:white_concrete
fill 99 222 307 99 225 307 minecraft:red_terracotta
fill 100 222 275 101 223 275 minecraft:red_concrete
fill 100 222 317 101 223 317 minecraft:red_concrete
fill 102 222 275 103 223 275 minecraft:white_concrete
fill 102 222 317 103 223 317 minecraft:white_concrete
fill 104 222 275 105 223 275 minecraft:red_concrete
fill 104 222 317 105 223 317 minecraft:red_concrete
setblock 105 222 300 minecraft:basalt
fill 106 222 275 107 223 275 minecraft:white_concrete
setblock 106 222 293 minecraft:basalt
fill 106 222 317 107 223 317 minecraft:white_concrete
setblock 107 222 292 minecraft:magma_block
setblock 107 222 304 minecraft:magma_block
fill 108 222 275 109 223 275 minecraft:red_concrete
fill 108 222 317 109 223 317 minecraft:red_concrete
fill 110 222 275 111 223 275 minecraft:white_concrete
setblock 110 222 288 minecraft:magma_block
fill 110 222 296 110 223 296 minecraft:basalt
fill 110 222 297 110 223 297 minecraft:magma_block
fill 110 222 298 110 222 299 minecraft:basalt
setblock 110 222 300 minecraft:magma_block
setblock 110 222 308 minecraft:basalt
fill 110 222 317 111 223 317 minecraft:white_concrete
fill 111 222 294 111 223 294 minecraft:basalt
fill 111 222 302 111 223 302 minecraft:basalt
fill 112 222 275 113 223 275 minecraft:red_concrete
setblock 112 222 287 minecraft:basalt
setblock 112 222 293 minecraft:basalt
setblock 112 222 303 minecraft:basalt
setblock 112 222 309 minecraft:basalt
fill 112 222 317 113 223 317 minecraft:red_concrete
setblock 113 222 287 minecraft:magma_block
fill 113 222 292 113 223 292 minecraft:basalt
fill 113 222 304 113 223 304 minecraft:basalt
fill 114 222 275 115 223 275 minecraft:white_concrete
fill 114 222 291 118 222 291 minecraft:basalt
fill 114 222 317 115 223 317 minecraft:white_concrete
setblock 115 222 286 minecraft:basalt
fill 115 222 305 119 222 305 minecraft:basalt
setblock 115 222 310 minecraft:basalt
fill 116 222 275 117 223 275 minecraft:red_concrete
setblock 116 222 286 minecraft:magma_block
setblock 116 222 310 minecraft:magma_block
fill 116 222 317 117 223 317 minecraft:red_concrete
fill 117 222 290 117 223 290 minecraft:basalt
fill 118 222 275 119 223 275 minecraft:white_concrete
fill 118 222 310 119 222 310 minecraft:basalt
fill 118 222 317 119 223 317 minecraft:white_concrete
setblock 119 222 291 minecraft:magma_block
fill 120 222 275 121 223 275 minecraft:red_concrete
fill 120 222 317 121 223 317 minecraft:red_concrete
setblock 121 222 292 minecraft:basalt
setblock 121 222 304 minecraft:basalt
fill 122 222 275 123 223 275 minecraft:white_concrete
setblock 122 222 287 minecraft:magma_block
fill 122 222 293 122 223 293 minecraft:magma_block
fill 122 222 303 123 222 303 minecraft:basalt
setblock 122 222 309 minecraft:basalt
fill 122 222 317 123 223 317 minecraft:white_concrete
fill 123 222 294 123 223 294 minecraft:basalt
fill 123 222 302 123 223 302 minecraft:basalt
fill 124 222 275 125 223 275 minecraft:red_concrete
fill 124 222 296 124 222 300 minecraft:basalt
fill 124 222 317 125 223 317 minecraft:red_concrete
setblock 125 222 289 minecraft:magma_block
setblock 125 222 307 minecraft:magma_block
fill 126 222 275 127 223 275 minecraft:white_concrete
fill 126 222 289 128 222 289 minecraft:brown_terracotta
fill 126 222 317 127 223 317 minecraft:white_concrete
fill 127 222 290 127 272 290 minecraft:red_terracotta
setblock 127 222 291 minecraft:basalt
fill 128 222 275 129 223 275 minecraft:red_concrete
fill 128 222 291 128 272 292 minecraft:red_terracotta
setblock 128 222 293 minecraft:basalt
setblock 128 222 294 minecraft:magma_block
fill 128 222 295 128 223 295 minecraft:basalt
setblock 128 222 303 minecraft:magma_block
fill 128 222 317 129 223 317 minecraft:red_concrete
fill 129 222 290 129 222 292 minecraft:brown_terracotta
setblock 129 222 296 minecraft:basalt
fill 130 222 275 131 223 275 minecraft:white_concrete
fill 130 222 285 130 225 285 minecraft:red_terracotta
fill 130 222 317 131 223 317 minecraft:white_concrete
fill 132 222 275 133 223 275 minecraft:red_concrete
fill 132 222 317 133 223 317 minecraft:red_concrete
fill 134 222 275 135 223 275 minecraft:white_concrete
fill 134 222 317 135 223 317 minecraft:white_concrete
fill 136 222 276 136 223 276 minecraft:white_concrete
fill 136 222 277 136 223 278 minecraft:red_concrete
fill 136 222 279 136 223 280 minecraft:white_concrete
fill 136 222 281 136 223 282 minecraft:red_concrete
fill 136 222 283 136 223 284 minecraft:white_concrete
fill 136 222 285 136 223 286 minecraft:red_concrete
fill 136 222 287 136 223 288 minecraft:white_concrete
fill 136 222 289 136 223 290 minecraft:red_concrete
fill 136 222 291 136 223 292 minecraft:white_concrete
fill 136 222 293 136 223 294 minecraft:red_concrete
fill 136 222 295 136 223 296 minecraft:white_concrete
fill 136 222 297 136 223 298 minecraft:red_concrete
fill 136 222 299 136 223 300 minecraft:white_concrete
fill 136 222 301 136 223 302 minecraft:red_concrete
fill 136 222 303 136 223 304 minecraft:white_concrete
fill 136 222 305 136 223 306 minecraft:red_concrete
fill 136 222 307 136 223 308 minecraft:white_concrete
fill 136 222 309 136 223 310 minecraft:red_concrete
fill 136 222 311 136 223 312 minecraft:white_concrete
fill 136 222 313 136 223 314 minecraft:red_concrete
fill 136 222 315 136 223 316 minecraft:white_concrete
fill 136 222 317 136 223 317 minecraft:red_concrete
fill 106 223 295 106 223 296 minecraft:basalt
setblock 106 223 297 minecraft:magma_block
setblock 106 223 298 minecraft:basalt
setblock 106 223 300 minecraft:magma_block
setblock 106 223 301 minecraft:basalt
setblock 109 223 290 minecraft:magma_block
setblock 109 223 293 minecraft:magma_block
setblock 109 223 295 minecraft:basalt
setblock 109 223 296 minecraft:magma_block
fill 109 223 297 109 223 298 minecraft:basalt
fill 109 223 299 111 223 299 minecraft:magma_block
fill 109 223 300 110 223 300 minecraft:basalt
setblock 109 223 302 minecraft:magma_block
setblock 109 223 305 minecraft:magma_block
setblock 110 223 298 minecraft:magma_block
setblock 111 223 289 minecraft:basalt
fill 111 223 295 111 223 297 minecraft:magma_block
fill 111 223 300 111 223 301 minecraft:magma_block
setblock 112 223 289 minecraft:magma_block
fill 112 223 292 112 223 294 minecraft:magma_block
fill 112 223 302 112 223 304 minecraft:magma_block
setblock 112 223 305 minecraft:basalt
setblock 112 223 307 minecraft:magma_block
setblock 113 223 293 minecraft:magma_block
setblock 113 223 303 minecraft:magma_block
fill 113 223 306 114 223 306 minecraft:basalt
fill 114 223 287 114 223 288 minecraft:basalt
setblock 114 223 291 minecraft:basalt
fill 114 223 292 116 223 292 minecraft:magma_block
fill 114 223 304 116 223 304 minecraft:magma_block
setblock 114 223 309 minecraft:basalt
fill 115 223 287 117 223 287 minecraft:basalt
setblock 115 223 288 minecraft:magma_block
fill 115 223 291 118 223 291 minecraft:magma_block
setblock 115 223 305 minecraft:basalt
setblock 115 223 306 minecraft:magma_block
fill 115 223 308 117 223 308 minecraft:basalt
setblock 115 223 309 minecraft:magma_block
fill 116 223 305 118 223 305 minecraft:magma_block
setblock 117 223 309 minecraft:basalt
setblock 118 223 287 minecraft:magma_block
setblock 118 223 290 minecraft:magma_block
fill 118 223 292 121 223 292 minecraft:magma_block
fill 118 223 304 121 223 304 minecraft:magma_block
setblock 118 223 308 minecraft:magma_block
setblock 119 223 291 minecraft:basalt
setblock 119 223 305 minecraft:basalt
setblock 120 223 287 minecraft:basalt
setblock 120 223 289 minecraft:basalt
setblock 120 223 307 minecraft:basalt
setblock 121 223 289 minecraft:magma_block
setblock 121 223 293 minecraft:magma_block
fill 121 223 303 122 223 303 minecraft:magma_block
setblock 121 223 307 minecraft:magma_block
fill 121 223 308 122 223 308 minecraft:basalt
setblock 122 223 294 minecraft:magma_block
setblock 122 223 302 minecraft:magma_block
fill 123 223 295 123 223 297 minecraft:magma_block
fill 123 223 299 123 223 301 minecraft:magma_block
setblock 123 223 303 minecraft:basalt
setblock 124 223 291 minecraft:magma_block
setblock 124 223 294 minecraft:magma_block
fill 124 223 295 124 223 296 minecraft:basalt
fill 124 223 297 124 223 300 minecraft:magma_block
setblock 124 223 303 minecraft:magma_block
setblock 124 223 306 minecraft:magma_block
setblock 125 223 306 minecraft:basalt
fill 126 223 290 126 272 290 minecraft:red_terracotta
setblock 126 223 305 minecraft:basalt
fill 127 223 291 127 272 292 minecraft:red_terracotta
setblock 127 223 293 minecraft:magma_block
setblock 127 223 294 minecraft:basalt
setblock 127 223 296 minecraft:magma_block
fill 127 223 297 127 223 298 minecraft:basalt
setblock 127 223 299 minecraft:magma_block
setblock 127 223 302 minecraft:magma_block
setblock 127 223 303 minecraft:basalt
setblock 127 223 312 minecraft:iron_block
setblock 128 223 296 minecraft:basalt
fill 128 223 300 128 223 301 minecraft:basalt
setblock 128 223 311 minecraft:iron_block
fill 128 223 312 130 223 312 minecraft:black_concrete
setblock 128 223 313 minecraft:iron_block
setblock 129 223 310 minecraft:iron_block
setblock 129 223 311 minecraft:black_concrete
setblock 129 223 313 minecraft:black_concrete
setblock 129 223 314 minecraft:iron_block
setblock 130 223 311 minecraft:iron_block
setblock 130 223 313 minecraft:iron_block
setblock 131 223 312 minecraft:iron_block
fill 94 224 275 94 225 276 minecraft:red_concrete
fill 94 224 277 94 225 278 minecraft:white_concrete
fill 94 224 279 94 225 280 minecraft:red_concrete
fill 94 224 281 94 225 282 minecraft:white_concrete
fill 94 224 283 94 225 284 minecraft:red_concrete
fill 94 224 285 94 225 286 minecraft:white_concrete
fill 94 224 287 94 225 288 minecraft:red_concrete
fill 94 224 289 94 225 290 minecraft:white_concrete
fill 94 224 291 94 225 292 minecraft:red_concrete
fill 94 224 293 94 225 294 minecraft:white_concrete
fill 94 224 295 94 225 296 minecraft:red_concrete
fill 94 224 297 94 225 298 minecraft:white_concrete
fill 94 224 299 94 225 300 minecraft:red_concrete
fill 94 224 301 94 225 302 minecraft:white_concrete
fill 94 224 303 94 225 304 minecraft:red_concrete
fill 94 224 305 94 225 306 minecraft:white_concrete
fill 94 224 307 94 225 308 minecraft:red_concrete
fill 94 224 309 94 225 310 minecraft:white_concrete
fill 94 224 311 94 225 312 minecraft:red_concrete
fill 94 224 313 94 225 314 minecraft:white_concrete
fill 94 224 315 94 225 316 minecraft:red_concrete
fill 95 224 275 95 225 275 minecraft:red_concrete
fill 95 224 276 95 225 281 minecraft:red_terracotta
fill 95 224 284 96 224 284 minecraft:red_terracotta
fill 95 224 288 95 225 289 minecraft:red_terracotta
fill 95 224 292 96 224 297 minecraft:red_terracotta
fill 95 224 300 96 224 305 minecraft:red_terracotta
fill 95 224 308 96 224 313 minecraft:red_terracotta
fill 95 224 316 100 225 316 minecraft:red_terracotta
fill 95 224 317 95 225 317 minecraft:red_concrete
fill 96 224 275 97 225 275 minecraft:white_concrete
fill 96 224 277 96 224 283 minecraft:red_terracotta
fill 96 224 289 96 224 291 minecraft:red_terracotta
fill 96 224 298 96 224 299 minecraft:red_terracotta
fill 96 224 306 96 224 307 minecraft:red_terracotta
fill 96 224 314 96 224 315 minecraft:red_terracotta
fill 96 224 317 97 225 317 minecraft:white_concrete
fill 97 224 277 134 224 277 minecraft:red_terracotta
fill 97 224 315 135 224 315 minecraft:red_terracotta
fill 98 224 275 99 225 275 minecraft:red_concrete
fill 98 224 276 103 225 276 minecraft:red_terracotta
fill 98 224 317 99 225 317 minecraft:red_concrete
fill 100 224 275 101 225 275 minecraft:white_concrete
fill 100 224 317 101 225 317 minecraft:white_concrete
fill 102 224 275 103 225 275 minecraft:red_concrete
fill 102 224 317 103 225 317 minecraft:red_concrete
fill 103 224 316 108 225 316 minecraft:red_terracotta
fill 104 224 275 105 225 275 minecraft:white_concrete
fill 104 224 317 105 225 317 minecraft:white_concrete
fill 106 224 275 107 225 275 minecraft:red_concrete
fill 106 224 276 111 225 276 minecraft:red_terracotta
fill 106 224 317 107 225 317 minecraft:red_concrete
fill 108 224 275 109 225 275 minecraft:white_concrete
fill 108 224 317 109 225 317 minecraft:white_concrete
fill 110 224 275 111 225 275 minecraft:red_concrete
fill 110 224 317 111 225 317 minecraft:red_concrete
fill 111 224 316 116 225 316 minecraft:red_terracotta
fill 112 224 275 113 225 275 minecraft:white_concrete
fill 112 224 317 113 225 317 minecraft:white_concrete
fill 114 224 275 115 225 275 minecraft:red_concrete
fill 114 224 276 119 225 276 minecraft:red_terracotta
fill 114 224 317 115 225 317 minecraft:red_concrete
fill 116 224 275 117 225 275 minecraft:white_concrete
fill 116 224 317 117 225 317 minecraft:white_concrete
fill 118 224 275 119 225 275 minecraft:red_concrete
fill 118 224 317 119 225 317 minecraft:red_concrete
fill 119 224 316 124 225 316 minecraft:red_terracotta
fill 120 224 275 121 225 275 minecraft:white_concrete
fill 120 224 317 121 225 317 minecraft:white_concrete
fill 122 224 275 123 225 275 minecraft:red_concrete
fill 122 224 276 127 225 276 minecraft:red_terracotta
fill 122 224 317 123 225 317 minecraft:red_concrete
fill 124 224 275 125 225 275 minecraft:white_concrete
fill 124 224 317 125 225 317 minecraft:white_concrete
fill 126 224 275 127 225 275 minecraft:red_concrete
fill 126 224 291 126 272 292 minecraft:red_terracotta
fill 126 224 317 127 225 317 minecraft:red_concrete
fill 127 224 316 132 225 316 minecraft:red_terracotta
fill 128 224 275 129 225 275 minecraft:white_concrete
fill 128 224 317 129 225 317 minecraft:white_concrete
fill 129 224 287 129 225 288 minecraft:green_concrete
fill 130 224 275 131 225 275 minecraft:red_concrete
fill 130 224 276 135 225 276 minecraft:red_terracotta
fill 130 224 317 131 225 317 minecraft:red_concrete
fill 132 224 275 133 225 275 minecraft:white_concrete
fill 132 224 317 133 225 317 minecraft:white_concrete
fill 134 224 275 135 225 275 minecraft:red_concrete
fill 134 224 278 134 224 314 minecraft:red_terracotta
fill 134 224 317 135 225 317 minecraft:red_concrete
fill 135 224 279 135 225 284 minecraft:red_terracotta
fill 135 224 287 135 225 292 minecraft:red_terracotta
fill 135 224 295 135 225 300 minecraft:red_terracotta
fill 135 224 303 135 225 308 minecraft:red_terracotta
fill 135 224 311 135 225 314 minecraft:red_terracotta
fill 135 224 316 135 225 316 minecraft:red_terracotta
fill 136 224 276 136 225 276 minecraft:red_concrete
fill 136 224 277 136 225 278 minecraft:white_concrete
fill 136 224 279 136 225 280 minecraft:red_concrete
fill 136 224 281 136 225 282 minecraft:white_concrete
fill 136 224 283 136 225 284 minecraft:red_concrete
fill 136 224 285 136 225 286 minecraft:white_concrete
fill 136 224 287 136 225 288 minecraft:red_concrete
fill 136 224 289 136 225 290 minecraft:white_concrete
fill 136 224 291 136 225 292 minecraft:red_concrete
fill 136 224 293 136 225 294 minecraft:white_concrete
fill 136 224 295 136 225 296 minecraft:red_concrete
fill 136 224 297 136 225 298 minecraft:white_concrete
fill 136 224 299 136 225 300 minecraft:red_concrete
fill 136 224 301 136 225 302 minecraft:white_concrete
fill 136 224 303 136 225 304 minecraft:red_concrete
fill 136 224 305 136 225 306 minecraft:white_concrete
fill 136 224 307 136 225 308 minecraft:red_concrete
fill 136 224 309 136 225 310 minecraft:white_concrete
fill 136 224 311 136 225 312 minecraft:red_concrete
fill 136 224 313 136 225 314 minecraft:white_concrete
fill 136 224 315 136 225 316 minecraft:red_concrete
fill 136 224 317 136 225 317 minecraft:white_concrete
setblock 95 225 284 minecraft:red_terracotta
fill 95 225 292 95 225 297 minecraft:red_terracotta
fill 95 225 300 95 225 305 minecraft:red_terracotta
fill 95 225 308 95 225 313 minecraft:red_terracotta
setblock 97 225 278 minecraft:light[level=12]
setblock 97 225 292 minecraft:light[level=12]
setblock 97 225 299 minecraft:light[level=12]
setblock 97 225 306 minecraft:light[level=12]
setblock 97 225 313 minecraft:light[level=12]
setblock 104 225 278 minecraft:light[level=12]
setblock 104 225 285 minecraft:light[level=12]
setblock 104 225 292 minecraft:light[level=12]
setblock 104 225 299 minecraft:light[level=12]
setblock 104 225 306 minecraft:light[level=12]
setblock 104 225 313 minecraft:light[level=12]
setblock 111 225 278 minecraft:light[level=12]
setblock 111 225 285 minecraft:light[level=12]
setblock 111 225 292 minecraft:light[level=12]
setblock 111 225 299 minecraft:light[level=12]
setblock 111 225 306 minecraft:light[level=12]
setblock 111 225 313 minecraft:light[level=12]
setblock 118 225 278 minecraft:light[level=12]
setblock 118 225 285 minecraft:light[level=12]
setblock 118 225 292 minecraft:light[level=12]
setblock 118 225 299 minecraft:light[level=12]
setblock 118 225 306 minecraft:light[level=12]
setblock 118 225 313 minecraft:light[level=12]
setblock 125 225 278 minecraft:light[level=12]
setblock 125 225 285 minecraft:light[level=12]
setblock 125 225 292 minecraft:light[level=12]
setblock 125 225 299 minecraft:light[level=12]
setblock 125 225 306 minecraft:light[level=12]
setblock 125 225 313 minecraft:light[level=12]
setblock 132 225 278 minecraft:light[level=12]
setblock 132 225 285 minecraft:light[level=12]
setblock 132 225 292 minecraft:light[level=12]
setblock 132 225 299 minecraft:light[level=12]
setblock 132 225 306 minecraft:light[level=12]
setblock 132 225 313 minecraft:light[level=12]
setblock 135 225 315 minecraft:red_terracotta
fill 94 226 275 94 227 276 minecraft:white_concrete
fill 94 226 277 94 227 278 minecraft:red_concrete
fill 94 226 279 94 227 280 minecraft:white_concrete
fill 94 226 281 94 227 282 minecraft:red_concrete
fill 94 226 283 94 227 284 minecraft:white_concrete
fill 94 226 285 94 227 286 minecraft:red_concrete
fill 94 226 287 94 227 288 minecraft:white_concrete
fill 94 226 289 94 227 290 minecraft:red_concrete
fill 94 226 291 94 227 292 minecraft:white_concrete
fill 94 226 293 94 227 294 minecraft:red_concrete
fill 94 226 295 94 227 296 minecraft:white_concrete
fill 94 226 297 94 227 298 minecraft:red_concrete
fill 94 226 299 94 227 300 minecraft:white_concrete
fill 94 226 301 94 227 302 minecraft:red_concrete
fill 94 226 303 94 227 304 minecraft:white_concrete
fill 94 226 305 94 227 306 minecraft:red_concrete
fill 94 226 307 94 227 308 minecraft:white_concrete
fill 94 226 309 94 227 310 minecraft:red_concrete
fill 94 226 311 94 227 312 minecraft:white_concrete
fill 94 226 313 94 227 314 minecraft:red_concrete
fill 94 226 315 94 227 316 minecraft:white_concrete
fill 95 226 275 95 227 275 minecraft:white_concrete
fill 95 226 317 95 227 317 minecraft:white_concrete
fill 96 226 275 97 227 275 minecraft:red_concrete
fill 96 226 317 97 227 317 minecraft:red_concrete
fill 97 226 307 101 229 307 minecraft:yellow_concrete
fill 98 226 275 99 227 275 minecraft:white_concrete
fill 98 226 306 100 229 306 minecraft:yellow_concrete
fill 98 226 308 100 229 308 minecraft:yellow_concrete
fill 98 226 317 99 227 317 minecraft:white_concrete
fill 99 226 305 99 229 305 minecraft:yellow_concrete
fill 99 226 309 99 229 309 minecraft:yellow_concrete
fill 100 226 275 101 227 275 minecraft:red_concrete
fill 100 226 317 101 227 317 minecraft:red_concrete
fill 102 226 275 103 227 275 minecraft:white_concrete
fill 102 226 317 103 227 317 minecraft:white_concrete
fill 104 226 275 105 227 275 minecraft:red_concrete
fill 104 226 317 105 227 317 minecraft:red_concrete
fill 106 226 275 107 227 275 minecraft:white_concrete
fill 106 226 317 107 227 317 minecraft:white_concrete
fill 108 226 275 109 227 275 minecraft:red_concrete
fill 108 226 317 109 227 317 minecraft:red_concrete
fill 110 226 275 111 227 275 minecraft:white_concrete
fill 110 226 317 111 227 317 minecraft:white_concrete
fill 112 226 275 113 227 275 minecraft:red_concrete
fill 112 226 317 113 227 317 minecraft:red_concrete
fill 114 226 275 115 227 275 minecraft:white_concrete
fill 114 226 317 115 227 317 minecraft:white_concrete
fill 116 226 275 117 227 275 minecraft:red_concrete
fill 116 226 317 117 227 317 minecraft:red_concrete
fill 118 226 275 119 227 275 minecraft:white_concrete
fill 118 226 317 119 227 317 minecraft:white_concrete
fill 120 226 275 121 227 275 minecraft:red_concrete
fill 120 226 317 121 227 317 minecraft:red_concrete
fill 122 226 275 123 227 275 minecraft:white_concrete
fill 122 226 317 123 227 317 minecraft:white_concrete
fill 124 226 275 125 227 275 minecraft:red_concrete
fill 124 226 317 125 227 317 minecraft:red_concrete
fill 126 226 275 127 227 275 minecraft:white_concrete
fill 126 226 317 127 227 317 minecraft:white_concrete
fill 128 226 275 129 227 275 minecraft:red_concrete
fill 128 226 285 132 229 285 minecraft:yellow_concrete
fill 128 226 317 129 227 317 minecraft:red_concrete
fill 129 226 284 131 229 284 minecraft:yellow_concrete
fill 129 226 286 131 229 286 minecraft:yellow_concrete
fill 130 226 275 131 227 275 minecraft:white_concrete
fill 130 226 283 130 229 283 minecraft:yellow_concrete
fill 130 226 287 130 229 287 minecraft:yellow_concrete
fill 130 226 317 131 227 317 minecraft:white_concrete
fill 132 226 275 133 227 275 minecraft:red_concrete
setblock 132 226 299 minecraft:iron_block
fill 132 226 317 133 227 317 minecraft:red_concrete
setblock 133 226 298 minecraft:iron_block
fill 133 226 299 135 226 299 minecraft:black_concrete
setblock 133 226 300 minecraft:iron_block
fill 134 226 275 135 227 275 minecraft:white_concrete
setblock 134 226 297 minecraft:iron_block
setblock 134 226 298 minecraft:black_concrete
setblock 134 226 300 minecraft:black_concrete
setblock 134 226 301 minecraft:iron_block
fill 134 226 317 135 227 317 minecraft:white_concrete
setblock 135 226 298 minecraft:iron_block
setblock 135 226 300 minecraft:iron_block
fill 136 226 276 136 227 276 minecraft:white_concrete
fill 136 226 277 136 227 278 minecraft:red_concrete
fill 136 226 279 136 227 280 minecraft:white_concrete
fill 136 226 281 136 227 282 minecraft:red_concrete
fill 136 226 283 136 227 284 minecraft:white_concrete
fill 136 226 285 136 227 286 minecraft:red_concrete
fill 136 226 287 136 227 288 minecraft:white_concrete
fill 136 226 289 136 227 290 minecraft:red_concrete
fill 136 226 291 136 227 292 minecraft:white_concrete
fill 136 226 293 136 227 294 minecraft:red_concrete
fill 136 226 295 136 227 296 minecraft:white_concrete
fill 136 226 297 136 227 298 minecraft:red_concrete
setblock 136 226 299 minecraft:iron_block
fill 136 226 300 136 227 300 minecraft:white_concrete
fill 136 226 301 136 227 302 minecraft:red_concrete
fill 136 226 303 136 227 304 minecraft:white_concrete
fill 136 226 305 136 227 306 minecraft:red_concrete
fill 136 226 307 136 227 308 minecraft:white_concrete
fill 136 226 309 136 227 310 minecraft:red_concrete
fill 136 226 311 136 227 312 minecraft:white_concrete
fill 136 226 313 136 227 314 minecraft:red_concrete
fill 136 226 315 136 227 316 minecraft:white_concrete
fill 136 226 317 136 227 317 minecraft:red_concrete
fill 97 227 279 97 227 281 minecraft:brown_terracotta
fill 97 227 306 97 228 306 minecraft:yellow_concrete
fill 97 227 308 97 228 308 minecraft:yellow_concrete
fill 98 227 278 100 227 278 minecraft:brown_terracotta
fill 98 227 282 100 227 282 minecraft:brown_terracotta
fill 98 227 305 98 228 305 minecraft:yellow_concrete
fill 98 227 309 98 228 309 minecraft:yellow_concrete
fill 100 227 305 100 228 305 minecraft:yellow_concrete
fill 100 227 309 100 228 309 minecraft:yellow_concrete
fill 101 227 279 101 227 281 minecraft:brown_terracotta
fill 101 227 306 101 228 306 minecraft:yellow_concrete
fill 101 227 308 101 228 308 minecraft:yellow_concrete
fill 114 227 277 114 227 279 minecraft:red_terracotta
fill 115 227 276 115 228 276 minecraft:iron_block
fill 115 227 277 116 227 277 minecraft:red_terracotta
fill 115 227 279 116 227 279 minecraft:red_terracotta
setblock 116 227 278 minecraft:red_terracotta
fill 128 227 284 128 228 284 minecraft:yellow_concrete
fill 128 227 286 128 228 286 minecraft:yellow_concrete
fill 129 227 283 129 228 283 minecraft:yellow_concrete
fill 129 227 287 129 228 287 minecraft:yellow_concrete
fill 131 227 283 131 228 283 minecraft:yellow_concrete
fill 131 227 287 131 228 287 minecraft:yellow_concrete
fill 132 227 284 132 228 284 minecraft:yellow_concrete
fill 132 227 286 132 228 286 minecraft:yellow_concrete
setblock 136 227 299 minecraft:white_concrete
fill 94 228 275 94 229 276 minecraft:red_concrete
fill 94 228 277 94 229 278 minecraft:white_concrete
fill 94 228 279 94 229 279 minecraft:red_concrete
fill 94 228 280 94 233 280 minecraft:shroomlight
fill 94 228 281 94 229 282 minecraft:white_concrete
fill 94 228 283 94 229 284 minecraft:red_concrete
fill 94 228 285 94 229 286 minecraft:white_concrete
fill 94 228 287 94 229 287 minecraft:red_concrete
fill 94 228 288 94 233 288 minecraft:shroomlight
fill 94 228 289 94 229 290 minecraft:white_concrete
fill 94 228 291 94 229 292 minecraft:red_concrete
fill 94 228 293 94 229 294 minecraft:white_concrete
fill 94 228 295 94 229 295 minecraft:red_concrete
fill 94 228 296 94 233 296 minecraft:shroomlight
fill 94 228 297 94 229 298 minecraft:white_concrete
fill 94 228 299 94 229 300 minecraft:red_concrete
fill 94 228 301 94 229 302 minecraft:white_concrete
fill 94 228 303 94 229 303 minecraft:red_concrete
fill 94 228 304 94 233 304 minecraft:shroomlight
fill 94 228 305 94 229 306 minecraft:white_concrete
fill 94 228 307 94 229 308 minecraft:red_concrete
fill 94 228 309 94 229 310 minecraft:white_concrete
fill 94 228 311 94 229 311 minecraft:red_concrete
fill 94 228 312 94 233 312 minecraft:shroomlight
fill 94 228 313 94 229 314 minecraft:white_concrete
fill 94 228 315 94 229 316 minecraft:red_concrete
fill 95 228 275 95 229 275 minecraft:red_concrete
fill 95 228 317 95 229 317 minecraft:red_concrete
fill 96 228 275 97 229 275 minecraft:white_concrete
fill 96 228 317 96 229 317 minecraft:white_concrete
fill 97 228 317 97 233 317 minecraft:shroomlight
fill 98 228 275 99 229 275 minecraft:red_concrete
fill 98 228 317 99 229 317 minecraft:red_concrete
fill 100 228 275 100 229 275 minecraft:white_concrete
fill 100 228 317 101 229 317 minecraft:white_concrete
fill 101 228 275 101 233 275 minecraft:shroomlight
fill 102 228 275 103 229 275 minecraft:red_concrete
fill 102 228 317 103 229 317 minecraft:red_concrete
fill 104 228 275 105 229 275 minecraft:white_concrete
fill 104 228 317 104 229 317 minecraft:white_concrete
fill 105 228 317 105 233 317 minecraft:shroomlight
fill 106 228 275 107 229 275 minecraft:red_concrete
fill 106 228 317 107 229 317 minecraft:red_concrete
fill 108 228 275 108 229 275 minecraft:white_concrete
fill 108 228 317 109 229 317 minecraft:white_concrete
fill 109 228 275 109 233 275 minecraft:shroomlight
fill 110 228 275 111 229 275 minecraft:red_concrete
fill 110 228 317 111 229 317 minecraft:red_concrete
fill 112 228 275 113 229 275 minecraft:white_concrete
fill 112 228 317 112 229 317 minecraft:white_concrete
fill 113 228 317 113 233 317 minecraft:shroomlight
fill 114 228 275 115 229 275 minecraft:red_concrete
fill 114 228 317 115 229 317 minecraft:red_concrete
setblock 115 228 277 minecraft:iron_block
setblock 115 228 279 minecraft:shroomlight
fill 116 228 275 116 229 275 minecraft:white_concrete
fill 116 228 317 117 229 317 minecraft:white_concrete
fill 117 228 275 117 233 275 minecraft:shroomlight
fill 118 228 275 119 229 275 minecraft:red_concrete
fill 118 228 317 119 229 317 minecraft:red_concrete
fill 120 228 275 121 229 275 minecraft:white_concrete
fill 120 228 317 120 229 317 minecraft:white_concrete
fill 121 228 317 121 233 317 minecraft:shroomlight
fill 122 228 275 123 229 275 minecraft:red_concrete
fill 122 228 317 123 229 317 minecraft:red_concrete
fill 124 228 275 124 229 275 minecraft:white_concrete
fill 124 228 317 125 229 317 minecraft:white_concrete
fill 125 228 275 125 233 275 minecraft:shroomlight
fill 126 228 275 127 229 275 minecraft:red_concrete
fill 126 228 317 127 229 317 minecraft:red_concrete
fill 128 228 275 129 229 275 minecraft:white_concrete
fill 128 228 317 128 229 317 minecraft:white_concrete
fill 129 228 317 129 233 317 minecraft:shroomlight
fill 130 228 275 131 229 275 minecraft:red_concrete
fill 130 228 317 131 229 317 minecraft:red_concrete
fill 132 228 275 132 229 275 minecraft:white_concrete
fill 132 228 317 133 229 317 minecraft:white_concrete
fill 133 228 275 133 233 275 minecraft:shroomlight
fill 134 228 275 135 229 275 minecraft:red_concrete
fill 134 228 317 135 229 317 minecraft:red_concrete
fill 136 228 276 136 229 276 minecraft:red_concrete
fill 136 228 277 136 229 278 minecraft:white_concrete
fill 136 228 279 136 229 279 minecraft:red_concrete
fill 136 228 280 136 233 280 minecraft:shroomlight
fill 136 228 281 136 229 282 minecraft:white_concrete
fill 136 228 283 136 229 284 minecraft:red_concrete
fill 136 228 285 136 229 286 minecraft:white_concrete
fill 136 228 287 136 229 287 minecraft:red_concrete
fill 136 228 288 136 233 288 minecraft:shroomlight
fill 136 228 289 136 229 290 minecraft:white_concrete
fill 136 228 291 136 229 292 minecraft:red_concrete
fill 136 228 293 136 229 294 minecraft:white_concrete
fill 136 228 295 136 229 295 minecraft:red_concrete
fill 136 228 296 136 233 296 minecraft:shroomlight
fill 136 228 297 136 229 298 minecraft:white_concrete
fill 136 228 299 136 229 300 minecraft:red_concrete
fill 136 228 301 136 229 302 minecraft:white_concrete
fill 136 228 303 136 229 303 minecraft:red_concrete
fill 136 228 304 136 233 304 minecraft:shroomlight
fill 136 228 305 136 229 306 minecraft:white_concrete
fill 136 228 307 136 229 308 minecraft:red_concrete
fill 136 228 309 136 229 310 minecraft:white_concrete
fill 136 228 311 136 229 311 minecraft:red_concrete
fill 136 228 312 136 233 312 minecraft:shroomlight
fill 136 228 313 136 229 314 minecraft:white_concrete
fill 136 228 315 136 229 316 minecraft:red_concrete
fill 136 228 317 136 229 317 minecraft:white_concrete
setblock 97 229 278 minecraft:light[level=15]
setblock 97 229 294 minecraft:light[level=15]
setblock 97 229 300 minecraft:red_terracotta
setblock 97 229 302 minecraft:red_terracotta
setblock 97 229 310 minecraft:light[level=15]
setblock 99 229 300 minecraft:red_terracotta
setblock 99 229 302 minecraft:red_terracotta
fill 102 229 284 102 230 284 minecraft:yellow_wool
setblock 105 229 278 minecraft:light[level=15]
setblock 105 229 286 minecraft:light[level=15]
setblock 105 229 294 minecraft:light[level=15]
setblock 105 229 302 minecraft:light[level=15]
setblock 105 229 310 minecraft:light[level=15]
setblock 113 229 278 minecraft:light[level=15]
setblock 113 229 286 minecraft:light[level=15]
setblock 113 229 294 minecraft:light[level=15]
setblock 113 229 302 minecraft:light[level=15]
setblock 113 229 310 minecraft:light[level=15]
setblock 121 229 278 minecraft:light[level=15]
setblock 121 229 286 minecraft:light[level=15]
setblock 121 229 294 minecraft:light[level=15]
setblock 121 229 302 minecraft:light[level=15]
setblock 121 229 310 minecraft:light[level=15]
setblock 129 229 278 minecraft:light[level=15]
setblock 129 229 294 minecraft:light[level=15]
setblock 129 229 302 minecraft:light[level=15]
setblock 129 229 310 minecraft:light[level=15]
fill 94 230 275 94 231 276 minecraft:white_concrete
fill 94 230 277 94 231 278 minecraft:red_concrete
fill 94 230 279 94 231 279 minecraft:white_concrete
fill 94 230 281 94 231 282 minecraft:red_concrete
fill 94 230 283 94 231 284 minecraft:white_concrete
fill 94 230 285 94 231 286 minecraft:red_concrete
fill 94 230 287 94 231 287 minecraft:white_concrete
fill 94 230 289 94 231 290 minecraft:red_concrete
fill 94 230 291 94 231 292 minecraft:white_concrete
fill 94 230 293 94 231 294 minecraft:red_concrete
fill 94 230 295 94 231 295 minecraft:white_concrete
fill 94 230 297 94 231 298 minecraft:red_concrete
fill 94 230 299 94 231 300 minecraft:white_concrete
fill 94 230 301 94 231 302 minecraft:red_concrete
fill 94 230 303 94 231 303 minecraft:white_concrete
fill 94 230 305 94 231 306 minecraft:red_concrete
fill 94 230 307 94 231 308 minecraft:white_concrete
fill 94 230 309 94 231 310 minecraft:red_concrete
fill 94 230 311 94 231 311 minecraft:white_concrete
fill 94 230 313 94 231 314 minecraft:red_concrete
fill 94 230 315 94 231 316 minecraft:white_concrete
fill 95 230 275 95 231 275 minecraft:white_concrete
fill 95 230 317 95 231 317 minecraft:white_concrete
fill 96 230 275 97 231 275 minecraft:red_concrete
fill 96 230 317 96 231 317 minecraft:red_concrete
fill 98 230 275 99 231 275 minecraft:white_concrete
fill 98 230 317 99 231 317 minecraft:white_concrete
setblock 99 230 307 minecraft:yellow_concrete
fill 100 230 275 100 231 275 minecraft:red_concrete
fill 100 230 317 101 231 317 minecraft:red_concrete
fill 102 230 275 103 231 275 minecraft:white_concrete
fill 102 230 317 103 231 317 minecraft:white_concrete
fill 104 230 275 105 231 275 minecraft:red_concrete
fill 104 230 317 104 231 317 minecraft:red_concrete
fill 106 230 275 107 231 275 minecraft:white_concrete
fill 106 230 306 107 231 307 minecraft:red_concrete
fill 106 230 317 107 231 317 minecraft:white_concrete
fill 108 230 275 108 231 275 minecraft:red_concrete
fill 108 230 317 109 231 317 minecraft:red_concrete
fill 110 230 275 111 231 275 minecraft:white_concrete
fill 110 230 317 111 231 317 minecraft:white_concrete
fill 112 230 275 113 231 275 minecraft:red_concrete
fill 112 230 317 112 231 317 minecraft:red_concrete
fill 114 230 275 115 231 275 minecraft:white_concrete
fill 114 230 317 115 231 317 minecraft:white_concrete
fill 116 230 275 116 231 275 minecraft:red_concrete
fill 116 230 317 117 231 317 minecraft:red_concrete
fill 118 230 275 119 231 275 minecraft:white_concrete
fill 118 230 317 119 231 317 minecraft:white_concrete
fill 120 230 275 121 231 275 minecraft:red_concrete
fill 120 230 317 120 231 317 minecraft:red_concrete
fill 122 230 275 123 231 275 minecraft:white_concrete
fill 122 230 317 123 231 317 minecraft:white_concrete
fill 124 230 275 124 231 275 minecraft:red_concrete
fill 124 230 317 125 231 317 minecraft:red_concrete
fill 126 230 275 127 231 275 minecraft:white_concrete
fill 126 230 317 127 231 317 minecraft:white_concrete
fill 128 230 275 129 231 275 minecraft:red_concrete
fill 128 230 317 128 231 317 minecraft:red_concrete
fill 130 230 275 131 231 275 minecraft:white_concrete
setblock 130 230 285 minecraft:yellow_concrete
fill 130 230 317 131 231 317 minecraft:white_concrete
fill 132 230 275 132 231 275 minecraft:red_concrete
fill 132 230 317 133 231 317 minecraft:red_concrete
fill 134 230 275 135 231 275 minecraft:white_concrete
fill 134 230 317 135 231 317 minecraft:white_concrete
fill 136 230 276 136 231 276 minecraft:white_concrete
fill 136 230 277 136 231 278 minecraft:red_concrete
fill 136 230 279 136 231 279 minecraft:white_concrete
fill 136 230 281 136 231 282 minecraft:red_concrete
fill 136 230 283 136 231 284 minecraft:white_concrete
fill 136 230 285 136 231 286 minecraft:red_concrete
fill 136 230 287 136 231 287 minecraft:white_concrete
fill 136 230 289 136 231 290 minecraft:red_concrete
fill 136 230 291 136 231 292 minecraft:white_concrete
fill 136 230 293 136 231 294 minecraft:red_concrete
fill 136 230 295 136 231 295 minecraft:white_concrete
fill 136 230 297 136 231 298 minecraft:red_concrete
fill 136 230 299 136 231 300 minecraft:white_concrete
fill 136 230 301 136 231 302 minecraft:red_concrete
fill 136 230 303 136 231 303 minecraft:white_concrete
fill 136 230 305 136 231 306 minecraft:red_concrete
fill 136 230 307 136 231 308 minecraft:white_concrete
fill 136 230 309 136 231 310 minecraft:red_concrete
fill 136 230 311 136 231 311 minecraft:white_concrete
fill 136 230 313 136 231 314 minecraft:red_concrete
fill 136 230 315 136 231 316 minecraft:white_concrete
fill 136 230 317 136 231 317 minecraft:red_concrete
setblock 97 231 278 minecraft:light[level=12]
setblock 97 231 292 minecraft:light[level=12]
setblock 97 231 299 minecraft:light[level=12]
setblock 97 231 306 minecraft:light[level=12]
setblock 97 231 313 minecraft:light[level=12]
setblock 104 231 278 minecraft:light[level=12]
setblock 104 231 285 minecraft:light[level=12]
setblock 104 231 292 minecraft:light[level=12]
setblock 104 231 299 minecraft:light[level=12]
setblock 104 231 306 minecraft:light[level=12]
setblock 104 231 313 minecraft:light[level=12]
setblock 111 231 278 minecraft:light[level=12]
setblock 111 231 285 minecraft:light[level=12]
setblock 111 231 292 minecraft:light[level=12]
setblock 111 231 299 minecraft:light[level=12]
setblock 111 231 306 minecraft:light[level=12]
setblock 111 231 313 minecraft:light[level=12]
setblock 118 231 278 minecraft:light[level=12]
setblock 118 231 285 minecraft:light[level=12]
setblock 118 231 292 minecraft:light[level=12]
setblock 118 231 299 minecraft:light[level=12]
setblock 118 231 306 minecraft:light[level=12]
setblock 118 231 313 minecraft:light[level=12]
setblock 125 231 278 minecraft:light[level=12]
setblock 125 231 285 minecraft:light[level=12]
setblock 125 231 292 minecraft:light[level=12]
setblock 125 231 299 minecraft:light[level=12]
setblock 125 231 306 minecraft:light[level=12]
setblock 125 231 313 minecraft:light[level=12]
setblock 132 231 278 minecraft:light[level=12]
setblock 132 231 285 minecraft:light[level=12]
setblock 132 231 292 minecraft:light[level=12]
setblock 132 231 299 minecraft:light[level=12]
setblock 132 231 306 minecraft:light[level=12]
setblock 132 231 313 minecraft:light[level=12]
fill 94 232 275 94 233 276 minecraft:red_concrete
fill 94 232 277 94 233 278 minecraft:white_concrete
fill 94 232 279 94 233 279 minecraft:red_concrete
fill 94 232 281 94 233 282 minecraft:white_concrete
fill 94 232 283 94 233 284 minecraft:red_concrete
fill 94 232 285 94 233 286 minecraft:white_concrete
fill 94 232 287 94 233 287 minecraft:red_concrete
fill 94 232 289 94 233 290 minecraft:white_concrete
fill 94 232 291 94 233 292 minecraft:red_concrete
fill 94 232 293 94 233 294 minecraft:white_concrete
fill 94 232 295 94 233 295 minecraft:red_concrete
fill 94 232 297 94 233 298 minecraft:white_concrete
fill 94 232 299 94 233 300 minecraft:red_concrete
fill 94 232 301 94 233 302 minecraft:white_concrete
fill 94 232 303 94 233 303 minecraft:red_concrete
fill 94 232 305 94 233 306 minecraft:white_concrete
fill 94 232 307 94 233 308 minecraft:red_concrete
fill 94 232 309 94 233 310 minecraft:white_concrete
fill 94 232 311 94 233 311 minecraft:red_concrete
fill 94 232 313 94 233 314 minecraft:white_concrete
fill 94 232 315 94 233 316 minecraft:red_concrete
fill 95 232 275 95 233 275 minecraft:red_concrete
fill 95 232 317 95 233 317 minecraft:red_concrete
fill 96 232 275 97 233 275 minecraft:white_concrete
fill 96 232 317 96 233 317 minecraft:white_concrete
fill 98 232 275 99 233 275 minecraft:red_concrete
fill 98 232 317 99 233 317 minecraft:red_concrete
fill 100 232 275 100 233 275 minecraft:white_concrete
fill 100 232 317 101 233 317 minecraft:white_concrete
fill 102 232 275 103 233 275 minecraft:red_concrete
fill 102 232 317 103 233 317 minecraft:red_concrete
fill 104 232 275 105 233 275 minecraft:white_concrete
fill 104 232 317 104 233 317 minecraft:white_concrete
fill 106 232 275 107 233 275 minecraft:red_concrete
fill 106 232 317 107 233 317 minecraft:red_concrete
fill 108 232 275 108 233 275 minecraft:white_concrete
fill 108 232 317 109 233 317 minecraft:white_concrete
fill 110 232 275 111 233 275 minecraft:red_concrete
fill 110 232 317 111 233 317 minecraft:red_concrete
fill 112 232 275 113 233 275 minecraft:white_concrete
fill 112 232 317 112 233 317 minecraft:white_concrete
fill 114 232 275 115 233 275 minecraft:red_concrete
fill 114 232 317 115 233 317 minecraft:red_concrete
fill 116 232 275 116 233 275 minecraft:white_concrete
fill 116 232 317 117 233 317 minecraft:white_concrete
fill 118 232 275 119 233 275 minecraft:red_concrete
fill 118 232 317 119 233 317 minecraft:red_concrete
fill 120 232 275 121 233 275 minecraft:white_concrete
fill 120 232 317 120 233 317 minecraft:white_concrete
fill 122 232 275 123 233 275 minecraft:red_concrete
fill 122 232 317 123 233 317 minecraft:red_concrete
fill 124 232 275 124 233 275 minecraft:white_concrete
fill 124 232 317 125 233 317 minecraft:white_concrete
fill 126 232 275 127 233 275 minecraft:red_concrete
fill 126 232 317 127 233 317 minecraft:red_concrete
fill 128 232 275 129 233 275 minecraft:white_concrete
fill 128 232 317 128 233 317 minecraft:white_concrete
fill 130 232 275 131 233 275 minecraft:red_concrete
fill 130 232 317 131 233 317 minecraft:red_concrete
fill 132 232 275 132 233 275 minecraft:white_concrete
fill 132 232 317 133 233 317 minecraft:white_concrete
fill 134 232 275 135 233 275 minecraft:red_concrete
fill 134 232 317 135 233 317 minecraft:red_concrete
fill 136 232 276 136 233 276 minecraft:red_concrete
fill 136 232 277 136 233 278 minecraft:white_concrete
fill 136 232 279 136 233 279 minecraft:red_concrete
fill 136 232 281 136 233 282 minecraft:white_concrete
fill 136 232 283 136 233 284 minecraft:red_concrete
fill 136 232 285 136 233 286 minecraft:white_concrete
fill 136 232 287 136 233 287 minecraft:red_concrete
fill 136 232 289 136 233 290 minecraft:white_concrete
fill 136 232 291 136 233 292 minecraft:red_concrete
fill 136 232 293 136 233 294 minecraft:white_concrete
fill 136 232 295 136 233 295 minecraft:red_concrete
fill 136 232 297 136 233 298 minecraft:white_concrete
fill 136 232 299 136 233 300 minecraft:red_concrete
fill 136 232 301 136 233 302 minecraft:white_concrete
fill 136 232 303 136 233 303 minecraft:red_concrete
fill 136 232 305 136 233 306 minecraft:white_concrete
fill 136 232 307 136 233 308 minecraft:red_concrete
fill 136 232 309 136 233 310 minecraft:white_concrete
fill 136 232 311 136 233 311 minecraft:red_concrete
fill 136 232 313 136 233 314 minecraft:white_concrete
fill 136 232 315 136 233 316 minecraft:red_concrete
fill 136 232 317 136 233 317 minecraft:white_concrete
fill 94 234 275 94 235 276 minecraft:white_concrete
fill 94 234 277 94 235 278 minecraft:red_concrete
fill 94 234 279 94 235 280 minecraft:white_concrete
fill 94 234 281 94 235 282 minecraft:red_concrete
fill 94 234 283 94 235 284 minecraft:white_concrete
fill 94 234 285 94 235 286 minecraft:red_concrete
fill 94 234 287 94 235 288 minecraft:white_concrete
fill 94 234 289 94 235 290 minecraft:red_concrete
fill 94 234 291 94 235 292 minecraft:white_concrete
fill 94 234 293 94 235 294 minecraft:red_concrete
fill 94 234 295 94 235 296 minecraft:white_concrete
fill 94 234 297 94 235 298 minecraft:red_concrete
fill 94 234 299 94 235 300 minecraft:white_concrete
fill 94 234 301 94 235 302 minecraft:red_concrete
fill 94 234 303 94 235 304 minecraft:white_concrete
fill 94 234 305 94 235 306 minecraft:red_concrete
fill 94 234 307 94 235 308 minecraft:white_concrete
fill 94 234 309 94 235 310 minecraft:red_concrete
fill 94 234 311 94 235 312 minecraft:white_concrete
fill 94 234 313 94 235 314 minecraft:red_concrete
fill 94 234 315 94 235 316 minecraft:white_concrete
fill 95 234 275 95 235 275 minecraft:white_concrete
fill 95 234 317 95 235 317 minecraft:white_concrete
fill 96 234 275 97 235 275 minecraft:red_concrete
fill 96 234 317 97 235 317 minecraft:red_concrete
fill 98 234 275 99 235 275 minecraft:white_concrete
fill 98 234 317 99 235 317 minecraft:white_concrete
fill 100 234 275 101 235 275 minecraft:red_concrete
fill 100 234 317 101 235 317 minecraft:red_concrete
fill 102 234 275 103 235 275 minecraft:white_concrete
fill 102 234 317 103 235 317 minecraft:white_concrete
fill 104 234 275 105 235 275 minecraft:red_concrete
fill 104 234 317 105 235 317 minecraft:red_concrete
fill 106 234 275 107 235 275 minecraft:white_concrete
fill 106 234 317 107 235 317 minecraft:white_concrete
fill 108 234 275 109 235 275 minecraft:red_concrete
fill 108 234 317 109 235 317 minecraft:red_concrete
fill 110 234 275 111 235 275 minecraft:white_concrete
fill 110 234 317 111 235 317 minecraft:white_concrete
fill 112 234 275 113 235 275 minecraft:red_concrete
fill 112 234 317 113 235 317 minecraft:red_concrete
fill 114 234 275 115 235 275 minecraft:white_concrete
fill 114 234 277 114 234 279 minecraft:red_terracotta
fill 114 234 317 115 235 317 minecraft:white_concrete
fill 115 234 277 116 234 277 minecraft:red_terracotta
fill 115 234 279 116 234 279 minecraft:red_terracotta
fill 116 234 275 117 235 275 minecraft:red_concrete
setblock 116 234 278 minecraft:red_terracotta
fill 116 234 317 117 235 317 minecraft:red_concrete
fill 118 234 275 119 235 275 minecraft:white_concrete
fill 118 234 317 119 235 317 minecraft:white_concrete
fill 120 234 275 121 235 275 minecraft:red_concrete
fill 120 234 317 121 235 317 minecraft:red_concrete
fill 122 234 275 123 235 275 minecraft:white_concrete
fill 122 234 317 123 235 317 minecraft:white_concrete
fill 124 234 275 125 235 275 minecraft:red_concrete
fill 124 234 317 125 235 317 minecraft:red_concrete
fill 126 234 275 127 235 275 minecraft:white_concrete
fill 126 234 317 127 235 317 minecraft:white_concrete
fill 128 234 275 129 235 275 minecraft:red_concrete
fill 128 234 317 129 235 317 minecraft:red_concrete
fill 130 234 275 131 235 275 minecraft:white_concrete
fill 130 234 317 131 235 317 minecraft:white_concrete
fill 132 234 275 133 235 275 minecraft:red_concrete
fill 132 234 317 133 235 317 minecraft:red_concrete
fill 134 234 275 135 235 275 minecraft:white_concrete
fill 134 234 317 135 235 317 minecraft:white_concrete
fill 136 234 276 136 235 276 minecraft:white_concrete
fill 136 234 277 136 235 278 minecraft:red_concrete
fill 136 234 279 136 235 280 minecraft:white_concrete
fill 136 234 281 136 235 282 minecraft:red_concrete
fill 136 234 283 136 235 284 minecraft:white_concrete
fill 136 234 285 136 235 286 minecraft:red_concrete
fill 136 234 287 136 235 288 minecraft:white_concrete
fill 136 234 289 136 235 290 minecraft:red_concrete
fill 136 234 291 136 235 292 minecraft:white_concrete
fill 136 234 293 136 235 294 minecraft:red_concrete
fill 136 234 295 136 235 296 minecraft:white_concrete
fill 136 234 297 136 235 298 minecraft:red_concrete
fill 136 234 299 136 235 300 minecraft:white_concrete
fill 136 234 301 136 235 302 minecraft:red_concrete
fill 136 234 303 136 235 304 minecraft:white_concrete
fill 136 234 305 136 235 306 minecraft:red_concrete
fill 136 234 307 136 235 308 minecraft:white_concrete
fill 136 234 309 136 235 310 minecraft:red_concrete
fill 136 234 311 136 235 312 minecraft:white_concrete
fill 136 234 313 136 235 314 minecraft:red_concrete
fill 136 234 315 136 235 316 minecraft:white_concrete
fill 136 234 317 136 235 317 minecraft:red_concrete
fill 97 235 279 97 235 281 minecraft:brown_terracotta
fill 98 235 278 100 235 278 minecraft:brown_terracotta
fill 98 235 282 100 235 282 minecraft:brown_terracotta
fill 101 235 279 101 235 281 minecraft:brown_terracotta
fill 94 236 275 94 237 276 minecraft:red_concrete
fill 94 236 277 94 237 278 minecraft:white_concrete
fill 94 236 279 94 237 280 minecraft:red_concrete
fill 94 236 281 94 237 282 minecraft:white_concrete
fill 94 236 283 94 237 284 minecraft:red_concrete
fill 94 236 285 94 237 286 minecraft:white_concrete
fill 94 236 287 94 237 288 minecraft:red_concrete
fill 94 236 289 94 237 290 minecraft:white_concrete
fill 94 236 291 94 237 292 minecraft:red_concrete
fill 94 236 293 94 237 294 minecraft:white_concrete
fill 94 236 295 94 237 296 minecraft:red_concrete
fill 94 236 297 94 237 298 minecraft:white_concrete
fill 94 236 299 94 237 300 minecraft:red_concrete
fill 94 236 301 94 237 302 minecraft:white_concrete
fill 94 236 303 94 237 304 minecraft:red_concrete
fill 94 236 305 94 237 306 minecraft:white_concrete
fill 94 236 307 94 237 308 minecraft:red_concrete
fill 94 236 309 94 237 310 minecraft:white_concrete
fill 94 236 311 94 237 312 minecraft:red_concrete
fill 94 236 313 94 237 314 minecraft:white_concrete
fill 94 236 315 94 237 316 minecraft:red_concrete
fill 95 236 275 95 237 275 minecraft:red_concrete
fill 95 236 317 95 237 317 minecraft:red_concrete
fill 96 236 275 97 237 275 minecraft:white_concrete
fill 96 236 317 97 237 317 minecraft:white_concrete
fill 98 236 275 99 237 275 minecraft:red_concrete
fill 98 236 317 99 237 317 minecraft:red_concrete
fill 100 236 275 101 237 275 minecraft:white_concrete
fill 100 236 317 101 237 317 minecraft:white_concrete
fill 102 236 275 103 237 275 minecraft:red_concrete
fill 102 236 317 103 237 317 minecraft:red_concrete
fill 104 236 275 105 237 275 minecraft:white_concrete
fill 104 236 317 105 237 317 minecraft:white_concrete
fill 106 236 275 107 237 275 minecraft:red_concrete
fill 106 236 317 107 237 317 minecraft:red_concrete
fill 108 236 275 109 237 275 minecraft:white_concrete
fill 108 236 317 109 237 317 minecraft:white_concrete
fill 110 236 275 111 237 275 minecraft:red_concrete
fill 110 236 317 111 237 317 minecraft:red_concrete
fill 112 236 275 113 237 275 minecraft:white_concrete
fill 112 236 317 113 237 317 minecraft:white_concrete
fill 114 236 275 115 237 275 minecraft:red_concrete
fill 114 236 317 115 237 317 minecraft:red_concrete
fill 116 236 275 117 237 275 minecraft:white_concrete
fill 116 236 317 117 237 317 minecraft:white_concrete
fill 118 236 275 119 237 275 minecraft:red_concrete
fill 118 236 317 119 237 317 minecraft:red_concrete
fill 120 236 275 121 237 275 minecraft:white_concrete
fill 120 236 317 121 237 317 minecraft:white_concrete
fill 122 236 275 123 237 275 minecraft:red_concrete
fill 122 236 317 123 237 317 minecraft:red_concrete
fill 124 236 275 125 237 275 minecraft:white_concrete
fill 124 236 317 125 237 317 minecraft:white_concrete
fill 126 236 275 127 237 275 minecraft:red_concrete
fill 126 236 317 127 237 317 minecraft:red_concrete
fill 128 236 275 129 237 275 minecraft:white_concrete
fill 128 236 317 129 237 317 minecraft:white_concrete
fill 130 236 275 131 237 275 minecraft:red_concrete
fill 130 236 317 131 237 317 minecraft:red_concrete
fill 132 236 275 133 237 275 minecraft:white_concrete
fill 132 236 317 133 237 317 minecraft:white_concrete
fill 134 236 275 135 237 275 minecraft:red_concrete
fill 134 236 317 135 237 317 minecraft:red_concrete
fill 136 236 276 136 237 276 minecraft:red_concrete
fill 136 236 277 136 237 278 minecraft:white_concrete
fill 136 236 279 136 237 280 minecraft:red_concrete
fill 136 236 281 136 237 282 minecraft:white_concrete
fill 136 236 283 136 237 284 minecraft:red_concrete
fill 136 236 285 136 237 286 minecraft:white_concrete
fill 136 236 287 136 237 288 minecraft:red_concrete
fill 136 236 289 136 237 290 minecraft:white_concrete
fill 136 236 291 136 237 292 minecraft:red_concrete
fill 136 236 293 136 237 294 minecraft:white_concrete
fill 136 236 295 136 237 296 minecraft:red_concrete
fill 136 236 297 136 237 298 minecraft:white_concrete
fill 136 236 299 136 237 300 minecraft:red_concrete
fill 136 236 301 136 237 302 minecraft:white_concrete
fill 136 236 303 136 237 304 minecraft:red_concrete
fill 136 236 305 136 237 306 minecraft:white_concrete
fill 136 236 307 136 237 308 minecraft:red_concrete
fill 136 236 309 136 237 310 minecraft:white_concrete
fill 136 236 311 136 237 312 minecraft:red_concrete
fill 136 236 313 136 237 314 minecraft:white_concrete
fill 136 236 315 136 237 316 minecraft:red_concrete
fill 136 236 317 136 237 317 minecraft:white_concrete
setblock 97 237 278 minecraft:light[level=15]
setblock 97 237 292 minecraft:light[level=12]
setblock 97 237 294 minecraft:light[level=15]
setblock 97 237 299 minecraft:light[level=12]
setblock 97 237 300 minecraft:red_terracotta
setblock 97 237 302 minecraft:red_terracotta
setblock 97 237 306 minecraft:light[level=12]
setblock 97 237 310 minecraft:light[level=15]
setblock 97 237 313 minecraft:light[level=12]
setblock 99 237 300 minecraft:red_terracotta
setblock 99 237 302 minecraft:red_terracotta
setblock 104 237 278 minecraft:light[level=12]
setblock 104 237 285 minecraft:light[level=12]
setblock 104 237 292 minecraft:light[level=12]
setblock 104 237 299 minecraft:light[level=12]
setblock 104 237 306 minecraft:light[level=12]
setblock 104 237 313 minecraft:light[level=12]
setblock 105 237 278 minecraft:light[level=15]
setblock 105 237 286 minecraft:light[level=15]
setblock 105 237 294 minecraft:light[level=15]
setblock 105 237 302 minecraft:light[level=15]
setblock 105 237 310 minecraft:light[level=15]
setblock 111 237 278 minecraft:light[level=12]
setblock 111 237 285 minecraft:light[level=12]
setblock 111 237 292 minecraft:light[level=12]
setblock 111 237 299 minecraft:light[level=12]
setblock 111 237 306 minecraft:light[level=12]
setblock 111 237 313 minecraft:light[level=12]
setblock 113 237 278 minecraft:light[level=15]
setblock 113 237 286 minecraft:light[level=15]
setblock 113 237 294 minecraft:light[level=15]
setblock 113 237 302 minecraft:light[level=15]
setblock 113 237 310 minecraft:light[level=15]
setblock 118 237 278 minecraft:light[level=12]
setblock 118 237 285 minecraft:light[level=12]
setblock 118 237 292 minecraft:light[level=12]
setblock 118 237 299 minecraft:light[level=12]
setblock 118 237 306 minecraft:light[level=12]
setblock 118 237 313 minecraft:light[level=12]
setblock 121 237 278 minecraft:light[level=15]
setblock 121 237 286 minecraft:light[level=15]
setblock 121 237 294 minecraft:light[level=15]
setblock 121 237 302 minecraft:light[level=15]
setblock 121 237 310 minecraft:light[level=15]
setblock 125 237 278 minecraft:light[level=12]
setblock 125 237 285 minecraft:light[level=12]
setblock 125 237 292 minecraft:light[level=12]
setblock 125 237 299 minecraft:light[level=12]
setblock 125 237 306 minecraft:light[level=12]
setblock 125 237 313 minecraft:light[level=12]
setblock 129 237 278 minecraft:light[level=15]
setblock 129 237 286 minecraft:light[level=15]
setblock 129 237 294 minecraft:light[level=15]
setblock 129 237 302 minecraft:light[level=15]
setblock 129 237 310 minecraft:light[level=15]
setblock 132 237 278 minecraft:light[level=12]
setblock 132 237 285 minecraft:light[level=12]
setblock 132 237 292 minecraft:light[level=12]
setblock 132 237 299 minecraft:light[level=12]
setblock 132 237 306 minecraft:light[level=12]
setblock 132 237 313 minecraft:light[level=12]
fill 94 238 275 94 239 276 minecraft:white_concrete
fill 94 238 277 94 239 278 minecraft:red_concrete
fill 94 238 279 94 239 280 minecraft:white_concrete
fill 94 238 281 94 239 282 minecraft:red_concrete
fill 94 238 283 94 239 284 minecraft:white_concrete
fill 94 238 285 94 239 286 minecraft:red_concrete
fill 94 238 287 94 239 288 minecraft:white_concrete
fill 94 238 289 94 239 290 minecraft:red_concrete
fill 94 238 291 94 239 292 minecraft:white_concrete
fill 94 238 293 94 239 294 minecraft:red_concrete
fill 94 238 295 94 239 296 minecraft:white_concrete
fill 94 238 297 94 239 298 minecraft:red_concrete
fill 94 238 299 94 239 300 minecraft:white_concrete
fill 94 238 301 94 239 302 minecraft:red_concrete
fill 94 238 303 94 239 304 minecraft:white_concrete
fill 94 238 305 94 239 306 minecraft:red_concrete
fill 94 238 307 94 239 308 minecraft:white_concrete
fill 94 238 309 94 239 310 minecraft:red_concrete
fill 94 238 311 94 239 312 minecraft:white_concrete
fill 94 238 313 94 239 314 minecraft:red_concrete
fill 94 238 315 94 239 316 minecraft:white_concrete
fill 95 238 275 95 239 275 minecraft:white_concrete
fill 95 238 276 95 239 281 minecraft:red_terracotta
fill 95 238 284 96 238 284 minecraft:red_terracotta
fill 95 238 288 95 239 289 minecraft:red_terracotta
fill 95 238 292 96 238 297 minecraft:red_terracotta
fill 95 238 300 96 238 305 minecraft:red_terracotta
fill 95 238 308 96 238 313 minecraft:red_terracotta
fill 95 238 316 100 239 316 minecraft:red_terracotta
fill 95 238 317 95 239 317 minecraft:white_concrete
fill 96 238 275 97 239 275 minecraft:red_concrete
fill 96 238 277 96 238 283 minecraft:red_terracotta
fill 96 238 289 96 238 291 minecraft:red_terracotta
fill 96 238 298 96 238 299 minecraft:red_terracotta
fill 96 238 306 96 238 307 minecraft:red_terracotta
fill 96 238 314 96 238 315 minecraft:red_terracotta
fill 96 238 317 97 239 317 minecraft:red_concrete
fill 97 238 277 134 238 277 minecraft:red_terracotta
fill 97 238 315 135 238 315 minecraft:red_terracotta
fill 98 238 275 99 239 275 minecraft:white_concrete
fill 98 238 276 103 239 276 minecraft:red_terracotta
fill 98 238 317 99 239 317 minecraft:white_concrete
fill 100 238 275 101 239 275 minecraft:red_concrete
fill 100 238 317 101 239 317 minecraft:red_concrete
fill 102 238 275 103 239 275 minecraft:white_concrete
fill 102 238 317 103 239 317 minecraft:white_concrete
fill 103 238 316 108 239 316 minecraft:red_terracotta
fill 104 238 275 105 239 275 minecraft:red_concrete
fill 104 238 317 105 239 317 minecraft:red_concrete
fill 106 238 275 107 239 275 minecraft:white_concrete
fill 106 238 276 111 239 276 minecraft:red_terracotta
fill 106 238 317 107 239 317 minecraft:white_concrete
fill 108 238 275 109 239 275 minecraft:red_concrete
fill 108 238 317 109 239 317 minecraft:red_concrete
fill 110 238 275 111 239 275 minecraft:white_concrete
fill 110 238 317 111 239 317 minecraft:white_concrete
fill 111 238 316 116 239 316 minecraft:red_terracotta
fill 112 238 275 113 239 275 minecraft:red_concrete
fill 112 238 317 113 239 317 minecraft:red_concrete
fill 114 238 275 115 239 275 minecraft:white_concrete
fill 114 238 276 119 239 276 minecraft:red_terracotta
fill 114 238 317 115 239 317 minecraft:white_concrete
fill 116 238 275 117 239 275 minecraft:red_concrete
fill 116 238 317 117 239 317 minecraft:red_concrete
fill 118 238 275 119 239 275 minecraft:white_concrete
fill 118 238 317 119 239 317 minecraft:white_concrete
fill 119 238 316 124 239 316 minecraft:red_terracotta
fill 120 238 275 121 239 275 minecraft:red_concrete
fill 120 238 317 121 239 317 minecraft:red_concrete
fill 122 238 275 123 239 275 minecraft:white_concrete
fill 122 238 276 127 239 276 minecraft:red_terracotta
fill 122 238 317 123 239 317 minecraft:white_concrete
fill 124 238 275 125 239 275 minecraft:red_concrete
fill 124 238 317 125 239 317 minecraft:red_concrete
fill 126 238 275 127 239 275 minecraft:white_concrete
fill 126 238 317 127 239 317 minecraft:white_concrete
fill 127 238 316 132 239 316 minecraft:red_terracotta
fill 128 238 275 129 239 275 minecraft:red_concrete
fill 128 238 317 129 239 317 minecraft:red_concrete
fill 130 238 275 131 239 275 minecraft:white_concrete
fill 130 238 276 135 239 276 minecraft:red_terracotta
fill 130 238 317 131 239 317 minecraft:white_concrete
fill 132 238 275 133 239 275 minecraft:red_concrete
fill 132 238 317 133 239 317 minecraft:red_concrete
fill 134 238 275 135 239 275 minecraft:white_concrete
fill 134 238 278 134 238 314 minecraft:red_terracotta
fill 134 238 317 135 239 317 minecraft:white_concrete
fill 135 238 279 135 239 284 minecraft:red_terracotta
fill 135 238 287 135 239 292 minecraft:red_terracotta
fill 135 238 295 135 239 300 minecraft:red_terracotta
fill 135 238 303 135 239 308 minecraft:red_terracotta
fill 135 238 311 135 239 314 minecraft:red_terracotta
fill 135 238 316 135 239 316 minecraft:red_terracotta
fill 136 238 276 136 239 276 minecraft:white_concrete
fill 136 238 277 136 239 278 minecraft:red_concrete
fill 136 238 279 136 239 280 minecraft:white_concrete
fill 136 238 281 136 239 282 minecraft:red_concrete
fill 136 238 283 136 239 284 minecraft:white_concrete
fill 136 238 285 136 239 286 minecraft:red_concrete
fill 136 238 287 136 239 288 minecraft:white_concrete
fill 136 238 289 136 239 290 minecraft:red_concrete
fill 136 238 291 136 239 292 minecraft:white_concrete
fill 136 238 293 136 239 294 minecraft:red_concrete
fill 136 238 295 136 239 296 minecraft:white_concrete
fill 136 238 297 136 239 298 minecraft:red_concrete
fill 136 238 299 136 239 300 minecraft:white_concrete
fill 136 238 301 136 239 302 minecraft:red_concrete
fill 136 238 303 136 239 304 minecraft:white_concrete
fill 136 238 305 136 239 306 minecraft:red_concrete
fill 136 238 307 136 239 308 minecraft:white_concrete
fill 136 238 309 136 239 310 minecraft:red_concrete
fill 136 238 311 136 239 312 minecraft:white_concrete
fill 136 238 313 136 239 314 minecraft:red_concrete
fill 136 238 315 136 239 316 minecraft:white_concrete
fill 136 238 317 136 239 317 minecraft:red_concrete
setblock 95 239 284 minecraft:red_terracotta
fill 95 239 292 95 239 297 minecraft:red_terracotta
fill 95 239 300 95 239 305 minecraft:red_terracotta
fill 95 239 308 95 239 313 minecraft:red_terracotta
setblock 135 239 315 minecraft:red_terracotta
fill 94 240 275 94 241 276 minecraft:red_concrete
fill 94 240 277 94 241 278 minecraft:white_concrete
fill 94 240 279 94 241 280 minecraft:red_concrete
fill 94 240 281 94 241 282 minecraft:white_concrete
fill 94 240 283 94 241 284 minecraft:red_concrete
fill 94 240 285 94 241 286 minecraft:white_concrete
fill 94 240 287 94 241 288 minecraft:red_concrete
fill 94 240 289 94 241 290 minecraft:white_concrete
fill 94 240 291 94 241 292 minecraft:red_concrete
fill 94 240 293 94 241 294 minecraft:white_concrete
fill 94 240 295 94 241 296 minecraft:red_concrete
fill 94 240 297 94 241 298 minecraft:white_concrete
fill 94 240 299 94 241 300 minecraft:red_concrete
fill 94 240 301 94 241 302 minecraft:white_concrete
fill 94 240 303 94 241 304 minecraft:red_concrete
fill 94 240 305 94 241 306 minecraft:white_concrete
fill 94 240 307 94 241 308 minecraft:red_concrete
fill 94 240 309 94 241 310 minecraft:white_concrete
fill 94 240 311 94 241 312 minecraft:red_concrete
fill 94 240 313 94 241 314 minecraft:white_concrete
fill 94 240 315 94 241 316 minecraft:red_concrete
fill 95 240 275 95 241 275 minecraft:red_concrete
fill 95 240 317 95 241 317 minecraft:red_concrete
fill 96 240 275 97 241 275 minecraft:white_concrete
fill 96 240 317 97 241 317 minecraft:white_concrete
fill 98 240 275 99 241 275 minecraft:red_concrete
fill 98 240 317 99 241 317 minecraft:red_concrete
fill 100 240 275 101 241 275 minecraft:white_concrete
fill 100 240 317 101 241 317 minecraft:white_concrete
fill 102 240 275 103 241 275 minecraft:red_concrete
fill 102 240 317 103 241 317 minecraft:red_concrete
fill 104 240 275 105 241 275 minecraft:white_concrete
fill 104 240 317 105 241 317 minecraft:white_concrete
fill 106 240 275 107 241 275 minecraft:red_concrete
fill 106 240 317 107 241 317 minecraft:red_concrete
fill 108 240 275 109 241 275 minecraft:white_concrete
fill 108 240 317 109 241 317 minecraft:white_concrete
fill 110 240 275 111 241 275 minecraft:red_concrete
fill 110 240 317 111 241 317 minecraft:red_concrete
fill 112 240 275 113 241 275 minecraft:white_concrete
fill 112 240 317 113 241 317 minecraft:white_concrete
fill 114 240 275 115 241 275 minecraft:red_concrete
fill 114 240 317 115 241 317 minecraft:red_concrete
fill 116 240 275 117 241 275 minecraft:white_concrete
fill 116 240 317 117 241 317 minecraft:white_concrete
fill 118 240 275 119 241 275 minecraft:red_concrete
fill 118 240 317 119 241 317 minecraft:red_concrete
fill 120 240 275 121 241 275 minecraft:white_concrete
fill 120 240 317 121 241 317 minecraft:white_concrete
fill 122 240 275 123 241 275 minecraft:red_concrete
fill 122 240 317 123 241 317 minecraft:red_concrete
fill 124 240 275 125 241 275 minecraft:white_concrete
fill 124 240 317 125 241 317 minecraft:white_concrete
fill 126 240 275 127 241 275 minecraft:red_concrete
fill 126 240 317 127 241 317 minecraft:red_concrete
fill 128 240 275 129 241 275 minecraft:white_concrete
fill 128 240 317 129 241 317 minecraft:white_concrete
fill 130 240 275 131 241 275 minecraft:red_concrete
fill 130 240 317 131 241 317 minecraft:red_concrete
fill 132 240 275 133 241 275 minecraft:white_concrete
fill 132 240 317 133 241 317 minecraft:white_concrete
fill 134 240 275 135 241 275 minecraft:red_concrete
fill 134 240 317 135 241 317 minecraft:red_concrete
fill 136 240 276 136 241 276 minecraft:red_concrete
fill 136 240 277 136 241 278 minecraft:white_concrete
fill 136 240 279 136 241 280 minecraft:red_concrete
fill 136 240 281 136 241 282 minecraft:white_concrete
fill 136 240 283 136 241 284 minecraft:red_concrete
fill 136 240 285 136 241 286 minecraft:white_concrete
fill 136 240 287 136 241 288 minecraft:red_concrete
fill 136 240 289 136 241 290 minecraft:white_concrete
fill 136 240 291 136 241 292 minecraft:red_concrete
fill 136 240 293 136 241 294 minecraft:white_concrete
fill 136 240 295 136 241 296 minecraft:red_concrete
fill 136 240 297 136 241 298 minecraft:white_concrete
fill 136 240 299 136 241 300 minecraft:red_concrete
fill 136 240 301 136 241 302 minecraft:white_concrete
fill 136 240 303 136 241 304 minecraft:red_concrete
fill 136 240 305 136 241 306 minecraft:white_concrete
fill 136 240 307 136 241 308 minecraft:red_concrete
fill 136 240 309 136 241 310 minecraft:white_concrete
fill 136 240 311 136 241 312 minecraft:red_concrete
fill 136 240 313 136 241 314 minecraft:white_concrete
fill 136 240 315 136 241 316 minecraft:red_concrete
fill 136 240 317 136 241 317 minecraft:white_concrete
fill 114 241 277 114 241 279 minecraft:red_terracotta
schedule function dropper:buildpart/62_7 1t
