fill 3 238 351 3 241 351 minecraft:honeycomb_block
setblock 5 238 323 minecraft:yellow_terracotta
fill 5 238 324 5 241 324 minecraft:honeycomb_block
fill 6 238 323 6 241 323 minecraft:honeycomb_block
setblock 8 238 325 minecraft:yellow_terracotta
setblock 9 238 324 minecraft:yellow_terracotta
fill 9 238 325 9 241 325 minecraft:honeycomb_block
setblock 10 238 323 minecraft:yellow_terracotta
fill 10 238 324 13 238 324 minecraft:honeycomb_block
fill 11 238 323 11 241 323 minecraft:honeycomb_block
setblock 13 238 325 minecraft:yellow_terracotta
setblock 13 238 363 minecraft:honey_block
setblock 14 238 324 minecraft:yellow_terracotta
setblock 15 238 323 minecraft:yellow_terracotta
fill 15 238 324 15 240 324 minecraft:honeycomb_block
fill 16 238 323 16 241 323 minecraft:honeycomb_block
fill 16 238 359 16 242 359 minecraft:brown_terracotta
setblock 18 238 324 minecraft:honeycomb_block
setblock 19 238 324 minecraft:yellow_terracotta
setblock 20 238 323 minecraft:yellow_terracotta
fill 20 238 324 20 241 324 minecraft:honeycomb_block
fill 21 238 323 21 241 323 minecraft:honeycomb_block
setblock 22 238 325 minecraft:honeycomb_block
setblock 23 238 325 minecraft:yellow_terracotta
setblock 24 238 324 minecraft:yellow_terracotta
fill 24 238 325 24 241 325 minecraft:honeycomb_block
setblock 25 238 323 minecraft:yellow_terracotta
fill 25 238 324 25 241 324 minecraft:honeycomb_block
fill 25 238 326 26 238 326 minecraft:honeycomb_block
setblock 25 238 363 minecraft:yellow_terracotta
fill 26 238 323 26 241 323 minecraft:honeycomb_block
setblock 26 238 362 minecraft:yellow_terracotta
fill 26 238 363 26 241 363 minecraft:honeycomb_block
setblock 27 238 326 minecraft:yellow_terracotta
fill 27 238 362 27 241 362 minecraft:honeycomb_block
setblock 28 238 325 minecraft:yellow_terracotta
fill 28 238 326 28 240 326 minecraft:honeycomb_block
setblock 29 238 324 minecraft:yellow_terracotta
fill 29 238 325 29 241 325 minecraft:honeycomb_block
fill 30 238 322 30 238 323 minecraft:yellow_terracotta
fill 30 238 324 30 241 324 minecraft:honeycomb_block
setblock 30 238 363 minecraft:yellow_terracotta
fill 30 238 364 30 245 364 minecraft:honeycomb_block
fill 31 238 323 31 241 323 minecraft:honeycomb_block
setblock 31 238 362 minecraft:yellow_terracotta
fill 31 238 363 31 241 363 minecraft:honeycomb_block
fill 32 238 362 32 241 362 minecraft:honeycomb_block
setblock 35 238 323 minecraft:yellow_terracotta
setblock 35 238 363 minecraft:yellow_terracotta
setblock 40 238 347 minecraft:honeycomb_block
setblock 40 238 348 minecraft:yellow_terracotta
fill 40 238 349 40 241 349 minecraft:honeycomb_block
setblock 40 238 353 minecraft:yellow_terracotta
fill 40 238 354 40 241 354 minecraft:honeycomb_block
setblock 41 238 336 minecraft:honey_block
setblock 41 238 347 minecraft:yellow_terracotta
fill 41 238 348 41 241 348 minecraft:honeycomb_block
setblock 41 238 352 minecraft:yellow_terracotta
fill 41 238 353 41 241 353 minecraft:honeycomb_block
setblock 41 238 357 minecraft:yellow_terracotta
fill 41 238 358 41 241 358 minecraft:honeycomb_block
setblock 42 238 344 minecraft:yellow_concrete
setblock 42 238 358 minecraft:orange_terracotta
setblock 0 239 325 minecraft:yellow_terracotta
setblock 1 239 325 minecraft:honeycomb_block
setblock 1 239 326 minecraft:yellow_terracotta
fill 1 239 327 2 241 327 minecraft:honeycomb_block
setblock 1 239 331 minecraft:yellow_terracotta
fill 1 239 332 3 240 332 minecraft:honeycomb_block
setblock 1 239 335 minecraft:honeycomb_block
setblock 1 239 336 minecraft:yellow_terracotta
fill 1 239 337 1 239 340 minecraft:honeycomb_block
setblock 1 239 341 minecraft:yellow_terracotta
fill 1 239 342 2 241 342 minecraft:honeycomb_block
setblock 1 239 346 minecraft:yellow_terracotta
fill 1 239 347 1 242 347 minecraft:honeycomb_block
setblock 1 239 351 minecraft:yellow_terracotta
fill 1 239 352 1 242 352 minecraft:honeycomb_block
setblock 1 239 356 minecraft:yellow_terracotta
setblock 2 239 329 minecraft:honeycomb_block
setblock 2 239 330 minecraft:yellow_terracotta
fill 2 239 331 3 241 331 minecraft:honeycomb_block
fill 2 239 333 2 239 334 minecraft:honeycomb_block
setblock 2 239 335 minecraft:yellow_terracotta
setblock 2 239 345 minecraft:yellow_terracotta
fill 2 239 346 2 242 346 minecraft:honeycomb_block
setblock 2 239 350 minecraft:yellow_terracotta
fill 2 239 351 2 242 351 minecraft:honeycomb_block
setblock 2 239 354 minecraft:honeycomb_block
setblock 2 239 355 minecraft:yellow_terracotta
setblock 3 239 323 minecraft:honeycomb_block
setblock 3 239 329 minecraft:yellow_terracotta
fill 3 239 330 3 242 330 minecraft:honeycomb_block
fill 3 239 345 3 241 345 minecraft:honeycomb_block
setblock 3 239 349 minecraft:yellow_terracotta
fill 3 239 350 3 242 350 minecraft:honeycomb_block
fill 3 239 352 3 239 353 minecraft:honeycomb_block
setblock 4 239 323 minecraft:yellow_terracotta
fill 5 239 323 5 242 323 minecraft:honeycomb_block
setblock 6 239 325 minecraft:honeycomb_block
setblock 7 239 325 minecraft:yellow_terracotta
setblock 8 239 324 minecraft:yellow_terracotta
fill 8 239 325 8 242 325 minecraft:honeycomb_block
setblock 9 239 323 minecraft:yellow_terracotta
fill 9 239 324 12 239 324 minecraft:honeycomb_block
setblock 9 239 326 minecraft:honeycomb_block
fill 10 239 323 10 242 323 minecraft:honeycomb_block
setblock 12 239 325 minecraft:yellow_terracotta
setblock 13 239 324 minecraft:yellow_terracotta
setblock 13 239 325 minecraft:honeycomb_block
setblock 14 239 323 minecraft:yellow_terracotta
fill 14 239 324 14 240 324 minecraft:honeycomb_block
fill 15 239 323 15 242 323 minecraft:honeycomb_block
setblock 17 239 364 minecraft:yellow_terracotta
setblock 18 239 324 minecraft:yellow_terracotta
setblock 19 239 323 minecraft:yellow_terracotta
fill 19 239 324 19 242 324 minecraft:honeycomb_block
setblock 19 239 363 minecraft:honey_block
fill 20 239 323 20 242 323 minecraft:honeycomb_block
setblock 22 239 325 minecraft:yellow_terracotta
fill 22 239 363 22 240 363 minecraft:honeycomb_block
setblock 23 239 324 minecraft:yellow_terracotta
fill 23 239 325 23 242 325 minecraft:honeycomb_block
setblock 24 239 323 minecraft:yellow_terracotta
fill 24 239 324 24 242 324 minecraft:honeycomb_block
setblock 24 239 363 minecraft:yellow_terracotta
fill 25 239 323 25 242 323 minecraft:honeycomb_block
setblock 25 239 326 minecraft:honeycomb_block
setblock 25 239 362 minecraft:yellow_terracotta
fill 25 239 363 25 242 363 minecraft:honeycomb_block
setblock 26 239 326 minecraft:yellow_terracotta
fill 26 239 362 26 242 362 minecraft:honeycomb_block
setblock 27 239 325 minecraft:yellow_terracotta
fill 27 239 326 27 240 326 minecraft:honeycomb_block
setblock 28 239 324 minecraft:yellow_terracotta
fill 28 239 325 28 242 325 minecraft:honeycomb_block
setblock 29 239 323 minecraft:yellow_terracotta
fill 29 239 324 29 242 324 minecraft:honeycomb_block
setblock 29 239 363 minecraft:yellow_terracotta
setblock 30 239 322 minecraft:yellow_concrete
fill 30 239 323 30 242 323 minecraft:honeycomb_block
setblock 30 239 362 minecraft:yellow_terracotta
fill 30 239 363 30 242 363 minecraft:honeycomb_block
fill 31 239 362 31 242 362 minecraft:honeycomb_block
setblock 33 239 324 minecraft:yellow_terracotta
setblock 34 239 323 minecraft:yellow_terracotta
setblock 34 239 363 minecraft:yellow_terracotta
fill 35 239 363 35 240 363 minecraft:honeycomb_block
setblock 38 239 363 minecraft:honey_block
setblock 40 239 346 minecraft:honeycomb_block
setblock 40 239 347 minecraft:yellow_terracotta
fill 40 239 348 40 242 348 minecraft:honeycomb_block
fill 40 239 350 40 239 351 minecraft:honeycomb_block
setblock 40 239 352 minecraft:yellow_terracotta
fill 40 239 353 40 242 353 minecraft:honeycomb_block
fill 40 239 355 40 239 356 minecraft:honeycomb_block
fill 41 239 327 41 239 330 minecraft:honeycomb_block
setblock 41 239 331 minecraft:yellow_terracotta
fill 41 239 343 41 241 343 minecraft:honeycomb_block
setblock 41 239 346 minecraft:yellow_terracotta
fill 41 239 347 41 242 347 minecraft:honeycomb_block
setblock 41 239 351 minecraft:yellow_terracotta
fill 41 239 352 41 242 352 minecraft:honeycomb_block
fill 41 239 354 41 239 355 minecraft:honeycomb_block
setblock 41 239 356 minecraft:yellow_terracotta
fill 41 239 357 41 242 357 minecraft:honeycomb_block
fill 41 239 359 41 240 359 minecraft:honeycomb_block
fill 42 239 344 42 249 344 minecraft:honeycomb_block
setblock 42 239 358 minecraft:honeycomb_block
fill 0 240 325 0 291 325 minecraft:honeycomb_block
setblock 0 240 327 minecraft:yellow_terracotta
setblock 0 240 338 minecraft:yellow_terracotta
setblock 1 240 325 minecraft:yellow_terracotta
fill 1 240 326 2 242 326 minecraft:honeycomb_block
setblock 1 240 329 minecraft:honeycomb_block
setblock 1 240 330 minecraft:yellow_terracotta
fill 1 240 331 1 243 331 minecraft:honeycomb_block
setblock 1 240 335 minecraft:yellow_terracotta
fill 1 240 336 1 240 339 minecraft:honeycomb_block
setblock 1 240 340 minecraft:yellow_terracotta
fill 1 240 341 2 242 341 minecraft:honeycomb_block
setblock 1 240 345 minecraft:yellow_terracotta
fill 1 240 346 1 243 346 minecraft:honeycomb_block
setblock 1 240 350 minecraft:yellow_terracotta
fill 1 240 351 1 243 351 minecraft:honeycomb_block
setblock 1 240 355 minecraft:yellow_terracotta
fill 1 240 356 1 242 357 minecraft:honeycomb_block
setblock 1 240 362 minecraft:honey_block
setblock 2 240 329 minecraft:yellow_terracotta
fill 2 240 330 2 243 330 minecraft:honeycomb_block
setblock 2 240 333 minecraft:honeycomb_block
setblock 2 240 334 minecraft:yellow_terracotta
fill 2 240 335 2 240 338 minecraft:honeycomb_block
setblock 2 240 339 minecraft:yellow_terracotta
fill 2 240 340 2 243 340 minecraft:honeycomb_block
setblock 2 240 344 minecraft:yellow_terracotta
fill 2 240 345 2 243 345 minecraft:honeycomb_block
setblock 2 240 348 minecraft:honeycomb_block
setblock 2 240 349 minecraft:yellow_terracotta
fill 2 240 350 2 243 350 minecraft:honeycomb_block
setblock 2 240 354 minecraft:yellow_terracotta
fill 2 240 355 2 242 356 minecraft:honeycomb_block
setblock 3 240 323 minecraft:yellow_terracotta
setblock 3 240 325 minecraft:light[level=15]
setblock 3 240 328 minecraft:yellow_terracotta
fill 3 240 329 3 243 329 minecraft:honeycomb_block
setblock 3 240 333 minecraft:yellow_terracotta
fill 3 240 334 3 242 335 minecraft:honeycomb_block
setblock 3 240 341 minecraft:light[level=15]
setblock 3 240 348 minecraft:yellow_terracotta
fill 3 240 349 4 241 349 minecraft:honeycomb_block
setblock 3 240 352 minecraft:honeycomb_block
setblock 3 240 353 minecraft:yellow_terracotta
fill 3 240 354 3 243 354 minecraft:honeycomb_block
setblock 3 240 357 minecraft:light[level=15]
fill 4 240 323 4 242 324 minecraft:honeycomb_block
fill 4 240 330 4 240 331 minecraft:honeycomb_block
setblock 4 240 332 minecraft:yellow_terracotta
fill 4 240 350 4 240 351 minecraft:honeycomb_block
setblock 5 240 364 minecraft:yellow_terracotta
setblock 6 240 325 minecraft:yellow_terracotta
setblock 7 240 324 minecraft:yellow_terracotta
fill 7 240 325 7 242 325 minecraft:honeycomb_block
setblock 7 240 363 minecraft:honeycomb_block
setblock 8 240 323 minecraft:yellow_terracotta
fill 8 240 324 11 240 324 minecraft:honeycomb_block
setblock 8 240 363 minecraft:yellow_terracotta
fill 9 240 323 9 243 323 minecraft:honeycomb_block
setblock 11 240 325 minecraft:yellow_terracotta
setblock 11 240 333 minecraft:light[level=15]
setblock 11 240 341 minecraft:light[level=15]
setblock 11 240 349 minecraft:light[level=15]
setblock 11 240 357 minecraft:light[level=15]
setblock 12 240 324 minecraft:yellow_terracotta
setblock 12 240 325 minecraft:honeycomb_block
setblock 13 240 323 minecraft:yellow_terracotta
fill 13 240 324 13 241 324 minecraft:honeycomb_block
fill 14 240 323 14 242 323 minecraft:honeycomb_block
fill 15 240 359 15 242 359 minecraft:brown_terracotta
fill 16 240 358 16 242 358 minecraft:brown_terracotta
fill 16 240 360 16 242 360 minecraft:brown_terracotta
fill 17 240 359 17 242 359 minecraft:brown_terracotta
fill 17 240 364 17 308 364 minecraft:honeycomb_block
setblock 18 240 323 minecraft:yellow_terracotta
setblock 18 240 324 minecraft:honeycomb_block
fill 19 240 323 19 243 323 minecraft:honeycomb_block
setblock 19 240 325 minecraft:light[level=15]
setblock 19 240 333 minecraft:light[level=15]
setblock 19 240 341 minecraft:light[level=15]
setblock 19 240 349 minecraft:light[level=15]
setblock 19 240 357 minecraft:light[level=15]
setblock 21 240 325 minecraft:yellow_terracotta
fill 21 240 363 21 241 363 minecraft:honeycomb_block
setblock 22 240 324 minecraft:yellow_terracotta
fill 22 240 325 22 242 325 minecraft:honeycomb_block
setblock 23 240 323 minecraft:yellow_terracotta
fill 23 240 324 23 243 324 minecraft:honeycomb_block
setblock 23 240 363 minecraft:yellow_terracotta
fill 24 240 323 24 243 323 minecraft:honeycomb_block
setblock 24 240 326 minecraft:honeycomb_block
setblock 24 240 362 minecraft:yellow_terracotta
fill 24 240 363 24 243 363 minecraft:honeycomb_block
setblock 25 240 326 minecraft:yellow_terracotta
fill 25 240 362 25 243 362 minecraft:honeycomb_block
setblock 26 240 325 minecraft:yellow_terracotta
fill 26 240 326 26 241 326 minecraft:honeycomb_block
setblock 27 240 324 minecraft:yellow_terracotta
fill 27 240 325 27 242 325 minecraft:honeycomb_block
setblock 27 240 333 minecraft:light[level=15]
setblock 27 240 349 minecraft:light[level=15]
setblock 27 240 357 minecraft:light[level=15]
fill 27 240 361 29 240 361 minecraft:honeycomb_block
setblock 28 240 323 minecraft:yellow_terracotta
fill 28 240 324 28 243 324 minecraft:honeycomb_block
setblock 28 240 363 minecraft:yellow_terracotta
fill 29 240 323 29 243 323 minecraft:honeycomb_block
setblock 29 240 362 minecraft:yellow_terracotta
fill 29 240 363 29 243 363 minecraft:honeycomb_block
fill 30 240 322 30 308 322 minecraft:honeycomb_block
fill 30 240 362 30 243 362 minecraft:honeycomb_block
setblock 32 240 324 minecraft:yellow_terracotta
setblock 33 240 323 minecraft:yellow_terracotta
setblock 33 240 363 minecraft:yellow_terracotta
setblock 34 240 323 minecraft:honeycomb_block
fill 34 240 363 34 241 363 minecraft:honeycomb_block
setblock 35 240 325 minecraft:light[level=15]
setblock 35 240 333 minecraft:light[level=15]
setblock 35 240 341 minecraft:light[level=15]
setblock 35 240 349 minecraft:light[level=15]
setblock 35 240 357 minecraft:light[level=15]
fill 36 240 327 36 247 327 minecraft:brown_terracotta
fill 39 240 350 39 240 351 minecraft:honeycomb_block
setblock 39 240 352 minecraft:yellow_terracotta
fill 39 240 353 39 243 353 minecraft:honeycomb_block
setblock 40 240 346 minecraft:yellow_terracotta
fill 40 240 347 40 243 347 minecraft:honeycomb_block
setblock 40 240 350 minecraft:honeycomb_block
setblock 40 240 351 minecraft:yellow_terracotta
fill 40 240 352 40 243 352 minecraft:honeycomb_block
setblock 40 240 355 minecraft:honeycomb_block
setblock 40 240 356 minecraft:yellow_terracotta
fill 40 240 357 40 243 357 minecraft:honeycomb_block
setblock 41 240 324 minecraft:honey_block
fill 41 240 326 41 240 329 minecraft:honeycomb_block
setblock 41 240 330 minecraft:yellow_terracotta
fill 41 240 331 41 240 334 minecraft:honeycomb_block
setblock 41 240 345 minecraft:yellow_terracotta
fill 41 240 346 41 243 346 minecraft:honeycomb_block
setblock 41 240 350 minecraft:yellow_terracotta
fill 41 240 351 41 243 351 minecraft:honeycomb_block
setblock 41 240 354 minecraft:honeycomb_block
setblock 41 240 355 minecraft:yellow_terracotta
fill 41 240 356 41 243 356 minecraft:honeycomb_block
setblock 41 240 360 minecraft:yellow_terracotta
setblock 42 240 358 minecraft:orange_terracotta
fill 0 241 327 0 287 327 minecraft:honeycomb_block
fill 0 241 338 1 241 338 minecraft:honeycomb_block
setblock 0 241 343 minecraft:yellow_terracotta
setblock 1 241 324 minecraft:honey_block
fill 1 241 325 1 244 325 minecraft:honeycomb_block
setblock 1 241 328 minecraft:honeycomb_block
setblock 1 241 329 minecraft:yellow_terracotta
fill 1 241 330 1 244 330 minecraft:honeycomb_block
fill 1 241 332 1 241 333 minecraft:honeycomb_block
setblock 1 241 334 minecraft:yellow_terracotta
fill 1 241 335 2 241 337 minecraft:honeycomb_block
setblock 1 241 339 minecraft:yellow_terracotta
fill 1 241 340 1 244 340 minecraft:honeycomb_block
setblock 1 241 343 minecraft:honeycomb_block
setblock 1 241 344 minecraft:yellow_terracotta
fill 1 241 345 1 244 345 minecraft:honeycomb_block
setblock 1 241 349 minecraft:yellow_terracotta
fill 1 241 350 1 244 350 minecraft:honeycomb_block
setblock 1 241 353 minecraft:honeycomb_block
setblock 1 241 354 minecraft:yellow_terracotta
fill 1 241 355 1 244 355 minecraft:honeycomb_block
setblock 1 241 358 minecraft:honeycomb_block
setblock 2 241 328 minecraft:yellow_terracotta
fill 2 241 329 2 244 329 minecraft:honeycomb_block
setblock 2 241 332 minecraft:honeycomb_block
setblock 2 241 333 minecraft:yellow_terracotta
fill 2 241 334 2 244 334 minecraft:honeycomb_block
setblock 2 241 338 minecraft:yellow_terracotta
fill 2 241 339 2 244 339 minecraft:honeycomb_block
setblock 2 241 343 minecraft:yellow_terracotta
fill 2 241 344 2 244 344 minecraft:honeycomb_block
setblock 2 241 348 minecraft:yellow_terracotta
fill 2 241 349 2 244 349 minecraft:honeycomb_block
setblock 2 241 353 minecraft:yellow_terracotta
fill 2 241 354 2 244 354 minecraft:honeycomb_block
fill 3 241 323 3 244 323 minecraft:honeycomb_block
setblock 3 241 327 minecraft:yellow_terracotta
fill 3 241 328 3 244 328 minecraft:honeycomb_block
setblock 3 241 332 minecraft:yellow_terracotta
fill 3 241 333 4 243 333 minecraft:honeycomb_block
setblock 3 241 336 minecraft:honeycomb_block
setblock 3 241 337 minecraft:yellow_terracotta
fill 3 241 338 3 244 338 minecraft:honeycomb_block
setblock 3 241 347 minecraft:yellow_terracotta
fill 3 241 348 3 243 348 minecraft:honeycomb_block
setblock 3 241 352 minecraft:yellow_terracotta
fill 3 241 353 3 244 353 minecraft:honeycomb_block
fill 3 241 355 3 242 355 minecraft:honeycomb_block
fill 4 241 329 4 241 330 minecraft:honeycomb_block
setblock 4 241 331 minecraft:yellow_terracotta
fill 4 241 332 4 244 332 minecraft:honeycomb_block
fill 4 241 334 4 241 335 minecraft:honeycomb_block
setblock 4 241 350 minecraft:honeycomb_block
setblock 4 241 351 minecraft:yellow_terracotta
fill 5 241 364 5 308 364 minecraft:honeycomb_block
setblock 6 241 324 minecraft:yellow_terracotta
fill 6 241 325 6 242 325 minecraft:honeycomb_block
setblock 6 241 363 minecraft:honeycomb_block
setblock 7 241 323 minecraft:yellow_terracotta
fill 7 241 324 10 241 324 minecraft:honeycomb_block
setblock 7 241 363 minecraft:yellow_terracotta
fill 8 241 323 8 244 323 minecraft:honeycomb_block
setblock 8 241 363 minecraft:honeycomb_block
setblock 10 241 325 minecraft:yellow_terracotta
setblock 11 241 324 minecraft:yellow_terracotta
setblock 11 241 325 minecraft:honeycomb_block
setblock 12 241 323 minecraft:yellow_terracotta
setblock 12 241 324 minecraft:honeycomb_block
fill 13 241 323 13 243 323 minecraft:honeycomb_block
fill 15 241 358 15 242 358 minecraft:brown_terracotta
fill 15 241 360 15 242 360 minecraft:brown_terracotta
setblock 17 241 323 minecraft:yellow_terracotta
fill 17 241 358 17 242 358 minecraft:brown_terracotta
fill 17 241 360 17 242 360 minecraft:brown_terracotta
fill 18 241 323 18 244 323 minecraft:honeycomb_block
setblock 21 241 324 minecraft:yellow_terracotta
setblock 21 241 325 minecraft:honeycomb_block
setblock 22 241 323 minecraft:yellow_terracotta
fill 22 241 324 22 244 324 minecraft:honeycomb_block
setblock 22 241 363 minecraft:yellow_terracotta
fill 23 241 323 23 244 323 minecraft:honeycomb_block
setblock 23 241 362 minecraft:yellow_terracotta
fill 23 241 363 23 244 363 minecraft:honeycomb_block
fill 24 241 362 24 244 362 minecraft:honeycomb_block
setblock 25 241 325 minecraft:yellow_terracotta
setblock 25 241 326 minecraft:honeycomb_block
setblock 26 241 324 minecraft:yellow_terracotta
fill 26 241 325 26 243 325 minecraft:honeycomb_block
fill 26 241 361 28 241 361 minecraft:honeycomb_block
setblock 27 241 323 minecraft:yellow_terracotta
fill 27 241 324 27 244 324 minecraft:honeycomb_block
setblock 27 241 363 minecraft:yellow_terracotta
fill 28 241 323 28 244 323 minecraft:honeycomb_block
setblock 28 241 362 minecraft:yellow_terracotta
fill 28 241 363 28 244 363 minecraft:honeycomb_block
setblock 29 241 361 minecraft:yellow_terracotta
fill 29 241 362 29 244 362 minecraft:honeycomb_block
setblock 31 241 324 minecraft:yellow_terracotta
setblock 32 241 323 minecraft:yellow_terracotta
setblock 32 241 363 minecraft:yellow_terracotta
setblock 33 241 323 minecraft:honeycomb_block
fill 33 241 363 33 243 363 minecraft:honeycomb_block
setblock 36 241 323 minecraft:honey_block
setblock 39 241 350 minecraft:honeycomb_block
setblock 39 241 351 minecraft:yellow_terracotta
fill 39 241 352 39 244 352 minecraft:honeycomb_block
fill 39 241 354 39 241 355 minecraft:honeycomb_block
fill 40 241 346 40 243 346 minecraft:honeycomb_block
setblock 40 241 350 minecraft:yellow_terracotta
fill 40 241 351 40 244 351 minecraft:honeycomb_block
setblock 40 241 355 minecraft:yellow_terracotta
fill 40 241 356 40 244 356 minecraft:honeycomb_block
fill 40 241 358 40 242 358 minecraft:honeycomb_block
fill 41 241 326 41 241 328 minecraft:honeycomb_block
setblock 41 241 329 minecraft:yellow_terracotta
fill 41 241 330 41 241 333 minecraft:honeycomb_block
setblock 41 241 334 minecraft:yellow_terracotta
fill 41 241 335 41 241 338 minecraft:honeycomb_block
fill 41 241 341 41 242 342 minecraft:honeycomb_block
setblock 41 241 344 minecraft:yellow_terracotta
fill 41 241 345 41 244 345 minecraft:honeycomb_block
setblock 41 241 349 minecraft:yellow_terracotta
fill 41 241 350 41 244 350 minecraft:honeycomb_block
setblock 41 241 354 minecraft:yellow_terracotta
fill 41 241 355 41 244 355 minecraft:honeycomb_block
setblock 41 241 359 minecraft:yellow_terracotta
fill 41 241 360 41 243 361 minecraft:honeycomb_block
setblock 41 241 362 minecraft:honey_block
fill 42 241 358 42 308 358 minecraft:honeycomb_block
fill 0 242 338 0 249 338 minecraft:honeycomb_block
fill 0 242 343 0 298 343 minecraft:honeycomb_block
setblock 1 242 327 minecraft:honeycomb_block
setblock 1 242 328 minecraft:yellow_terracotta
fill 1 242 329 1 245 329 minecraft:honeycomb_block
setblock 1 242 332 minecraft:honeycomb_block
setblock 1 242 333 minecraft:yellow_terracotta
fill 1 242 334 1 242 337 minecraft:honeycomb_block
setblock 1 242 338 minecraft:yellow_terracotta
fill 1 242 339 1 245 339 minecraft:honeycomb_block
setblock 1 242 342 minecraft:honeycomb_block
setblock 1 242 343 minecraft:yellow_terracotta
fill 1 242 344 1 245 344 minecraft:honeycomb_block
setblock 1 242 348 minecraft:yellow_terracotta
fill 1 242 349 1 245 349 minecraft:honeycomb_block
setblock 1 242 353 minecraft:yellow_terracotta
fill 1 242 354 1 245 354 minecraft:honeycomb_block
setblock 1 242 358 minecraft:yellow_terracotta
fill 1 242 359 1 245 359 minecraft:honeycomb_block
setblock 2 242 323 minecraft:honeycomb_block
setblock 2 242 327 minecraft:yellow_terracotta
fill 2 242 328 2 245 328 minecraft:honeycomb_block
setblock 2 242 331 minecraft:honeycomb_block
setblock 2 242 332 minecraft:yellow_terracotta
fill 2 242 333 2 245 333 minecraft:honeycomb_block
fill 2 242 335 2 242 336 minecraft:honeycomb_block
setblock 2 242 337 minecraft:yellow_terracotta
fill 2 242 338 2 245 338 minecraft:honeycomb_block
setblock 2 242 342 minecraft:yellow_terracotta
fill 2 242 343 2 245 343 minecraft:honeycomb_block
setblock 2 242 347 minecraft:yellow_terracotta
fill 2 242 348 2 245 348 minecraft:honeycomb_block
setblock 2 242 352 minecraft:yellow_terracotta
fill 2 242 353 2 245 353 minecraft:honeycomb_block
setblock 2 242 357 minecraft:yellow_terracotta
setblock 3 242 325 minecraft:light[level=12]
fill 3 242 327 3 243 327 minecraft:honeycomb_block
setblock 3 242 331 minecraft:yellow_terracotta
fill 3 242 332 3 245 332 minecraft:honeycomb_block
setblock 3 242 336 minecraft:yellow_terracotta
fill 3 242 337 3 245 337 minecraft:honeycomb_block
fill 3 242 339 3 243 339 minecraft:honeycomb_block
setblock 3 242 346 minecraft:yellow_terracotta
fill 3 242 347 3 243 347 minecraft:honeycomb_block
fill 3 242 349 3 243 349 minecraft:honeycomb_block
setblock 3 242 351 minecraft:yellow_terracotta
fill 3 242 352 3 244 352 minecraft:honeycomb_block
setblock 3 242 360 minecraft:light[level=12]
setblock 4 242 329 minecraft:honeycomb_block
setblock 4 242 330 minecraft:yellow_terracotta
fill 4 242 331 4 245 331 minecraft:honeycomb_block
setblock 4 242 334 minecraft:honeycomb_block
setblock 4 242 335 minecraft:yellow_terracotta
fill 4 242 336 4 245 336 minecraft:honeycomb_block
setblock 5 242 324 minecraft:yellow_terracotta
fill 5 242 332 5 243 332 minecraft:honeycomb_block
setblock 6 242 323 minecraft:yellow_terracotta
fill 6 242 324 9 242 324 minecraft:honeycomb_block
setblock 6 242 363 minecraft:yellow_terracotta
fill 7 242 323 7 245 323 minecraft:honeycomb_block
setblock 7 242 363 minecraft:honeycomb_block
setblock 9 242 325 minecraft:yellow_terracotta
setblock 10 242 324 minecraft:yellow_terracotta
setblock 10 242 325 minecraft:light[level=12]
setblock 10 242 332 minecraft:light[level=12]
setblock 10 242 346 minecraft:light[level=12]
setblock 10 242 353 minecraft:light[level=12]
setblock 10 242 360 minecraft:light[level=12]
setblock 11 242 323 minecraft:yellow_terracotta
setblock 11 242 324 minecraft:honeycomb_block
fill 12 242 323 12 243 323 minecraft:honeycomb_block
setblock 12 242 363 minecraft:honey_block
setblock 14 242 359 minecraft:brown_terracotta
setblock 16 242 323 minecraft:yellow_terracotta
setblock 16 242 357 minecraft:brown_terracotta
setblock 16 242 361 minecraft:brown_terracotta
fill 17 242 323 17 243 323 minecraft:honeycomb_block
setblock 17 242 325 minecraft:light[level=12]
setblock 17 242 332 minecraft:light[level=12]
setblock 17 242 339 minecraft:light[level=12]
setblock 17 242 346 minecraft:light[level=12]
setblock 17 242 353 minecraft:light[level=12]
setblock 18 242 359 minecraft:brown_terracotta
setblock 20 242 324 minecraft:yellow_terracotta
setblock 20 242 363 minecraft:honeycomb_block
setblock 21 242 323 minecraft:yellow_terracotta
fill 21 242 324 21 245 324 minecraft:honeycomb_block
setblock 21 242 363 minecraft:yellow_terracotta
fill 22 242 323 22 245 323 minecraft:honeycomb_block
setblock 22 242 362 minecraft:yellow_terracotta
fill 22 242 363 22 245 363 minecraft:honeycomb_block
fill 23 242 362 23 245 362 minecraft:honeycomb_block
setblock 24 242 325 minecraft:yellow_terracotta
setblock 24 242 332 minecraft:light[level=12]
setblock 24 242 339 minecraft:light[level=12]
setblock 24 242 346 minecraft:light[level=12]
setblock 24 242 353 minecraft:light[level=12]
setblock 24 242 360 minecraft:light[level=12]
setblock 25 242 324 minecraft:yellow_terracotta
fill 25 242 325 25 243 325 minecraft:honeycomb_block
fill 25 242 361 27 242 361 minecraft:honeycomb_block
setblock 26 242 323 minecraft:yellow_terracotta
fill 26 242 324 26 244 324 minecraft:honeycomb_block
setblock 26 242 363 minecraft:yellow_terracotta
fill 27 242 323 27 245 323 minecraft:honeycomb_block
setblock 27 242 362 minecraft:yellow_terracotta
fill 27 242 363 27 245 363 minecraft:honeycomb_block
setblock 28 242 361 minecraft:yellow_terracotta
fill 28 242 362 28 245 362 minecraft:honeycomb_block
setblock 29 242 361 minecraft:honeycomb_block
setblock 30 242 324 minecraft:yellow_terracotta
setblock 31 242 323 minecraft:yellow_terracotta
setblock 31 242 325 minecraft:light[level=12]
setblock 31 242 332 minecraft:light[level=12]
setblock 31 242 339 minecraft:light[level=12]
setblock 31 242 346 minecraft:light[level=12]
setblock 31 242 353 minecraft:light[level=12]
setblock 31 242 360 minecraft:light[level=12]
setblock 31 242 363 minecraft:yellow_terracotta
setblock 32 242 323 minecraft:honeycomb_block
fill 32 242 363 32 244 363 minecraft:honeycomb_block
setblock 37 242 363 minecraft:honey_block
setblock 38 242 325 minecraft:light[level=12]
setblock 38 242 332 minecraft:light[level=12]
setblock 38 242 339 minecraft:light[level=12]
setblock 38 242 346 minecraft:light[level=12]
setblock 38 242 353 minecraft:light[level=12]
setblock 38 242 360 minecraft:light[level=12]
setblock 39 242 350 minecraft:yellow_terracotta
fill 39 242 351 39 244 351 minecraft:honeycomb_block
setblock 39 242 354 minecraft:honeycomb_block
setblock 39 242 355 minecraft:yellow_terracotta
setblock 40 242 349 minecraft:yellow_terracotta
fill 40 242 350 40 245 350 minecraft:honeycomb_block
setblock 40 242 354 minecraft:yellow_terracotta
fill 40 242 355 40 245 355 minecraft:honeycomb_block
fill 41 242 326 41 242 327 minecraft:honeycomb_block
setblock 41 242 328 minecraft:yellow_terracotta
fill 41 242 329 41 242 332 minecraft:honeycomb_block
setblock 41 242 333 minecraft:yellow_terracotta
fill 41 242 334 41 242 337 minecraft:honeycomb_block
setblock 41 242 338 minecraft:yellow_terracotta
fill 41 242 339 41 244 340 minecraft:honeycomb_block
setblock 41 242 343 minecraft:yellow_terracotta
fill 41 242 344 41 245 344 minecraft:honeycomb_block
setblock 41 242 348 minecraft:yellow_terracotta
fill 41 242 349 41 245 349 minecraft:honeycomb_block
setblock 41 242 353 minecraft:yellow_terracotta
fill 41 242 354 41 245 354 minecraft:honeycomb_block
setblock 41 242 358 minecraft:yellow_terracotta
fill 41 242 359 41 245 359 minecraft:honeycomb_block
setblock 41 242 362 minecraft:honeycomb_block
setblock 0 243 333 minecraft:yellow_terracotta
setblock 1 243 326 minecraft:honeycomb_block
setblock 1 243 327 minecraft:yellow_terracotta
fill 1 243 328 1 246 328 minecraft:honeycomb_block
setblock 1 243 332 minecraft:yellow_terracotta
fill 1 243 333 1 243 336 minecraft:honeycomb_block
setblock 1 243 337 minecraft:yellow_terracotta
fill 1 243 338 1 246 338 minecraft:honeycomb_block
setblock 1 243 341 minecraft:honeycomb_block
setblock 1 243 342 minecraft:yellow_terracotta
fill 1 243 343 1 246 343 minecraft:honeycomb_block
setblock 1 243 347 minecraft:yellow_terracotta
fill 1 243 348 1 246 348 minecraft:honeycomb_block
setblock 1 243 352 minecraft:yellow_terracotta
fill 1 243 353 1 246 353 minecraft:honeycomb_block
setblock 1 243 356 minecraft:honeycomb_block
setblock 1 243 357 minecraft:yellow_terracotta
fill 1 243 358 2 245 358 minecraft:honeycomb_block
setblock 1 243 361 minecraft:honey_block
setblock 2 243 326 minecraft:yellow_terracotta
fill 2 243 327 2 245 327 minecraft:honeycomb_block
setblock 2 243 331 minecraft:yellow_terracotta
fill 2 243 332 2 246 332 minecraft:honeycomb_block
setblock 2 243 335 minecraft:honeycomb_block
setblock 2 243 336 minecraft:yellow_terracotta
fill 2 243 337 2 246 337 minecraft:honeycomb_block
setblock 2 243 341 minecraft:yellow_terracotta
fill 2 243 342 2 246 342 minecraft:honeycomb_block
setblock 2 243 346 minecraft:yellow_terracotta
fill 2 243 347 2 245 347 minecraft:honeycomb_block
setblock 2 243 351 minecraft:yellow_terracotta
fill 2 243 352 2 246 352 minecraft:honeycomb_block
setblock 2 243 355 minecraft:honeycomb_block
setblock 2 243 356 minecraft:yellow_terracotta
fill 2 243 357 2 246 357 minecraft:honeycomb_block
setblock 3 243 330 minecraft:yellow_terracotta
fill 3 243 331 3 246 331 minecraft:honeycomb_block
setblock 3 243 334 minecraft:honeycomb_block
setblock 3 243 335 minecraft:yellow_terracotta
fill 3 243 336 3 246 336 minecraft:honeycomb_block
setblock 3 243 340 minecraft:yellow_terracotta
setblock 3 243 350 minecraft:yellow_terracotta
fill 3 243 351 3 244 351 minecraft:honeycomb_block
setblock 3 243 355 minecraft:yellow_terracotta
setblock 4 243 323 minecraft:honeycomb_block
setblock 4 243 324 minecraft:yellow_terracotta
setblock 4 243 329 minecraft:yellow_terracotta
fill 4 243 330 4 245 330 minecraft:honeycomb_block
setblock 4 243 334 minecraft:yellow_terracotta
fill 4 243 335 4 246 335 minecraft:honeycomb_block
fill 4 243 337 4 244 337 minecraft:honeycomb_block
setblock 5 243 323 minecraft:yellow_terracotta
fill 5 243 324 8 243 324 minecraft:honeycomb_block
setblock 5 243 333 minecraft:yellow_terracotta
fill 6 243 323 6 246 323 minecraft:honeycomb_block
setblock 9 243 324 minecraft:yellow_terracotta
setblock 10 243 323 minecraft:yellow_terracotta
fill 11 243 323 11 244 323 minecraft:honeycomb_block
setblock 16 243 323 minecraft:honeycomb_block
setblock 18 243 363 minecraft:honey_block
setblock 20 243 323 minecraft:yellow_terracotta
setblock 20 243 324 minecraft:honeycomb_block
setblock 20 243 363 minecraft:yellow_terracotta
fill 21 243 323 21 246 323 minecraft:honeycomb_block
fill 21 243 363 21 246 363 minecraft:honeycomb_block
fill 22 243 362 22 246 362 minecraft:honeycomb_block
setblock 23 243 325 minecraft:yellow_terracotta
setblock 24 243 324 minecraft:yellow_terracotta
setblock 24 243 325 minecraft:honeycomb_block
fill 24 243 361 26 243 361 minecraft:honeycomb_block
setblock 25 243 323 minecraft:yellow_terracotta
fill 25 243 324 25 245 324 minecraft:honeycomb_block
setblock 25 243 363 minecraft:yellow_terracotta
fill 26 243 323 26 246 323 minecraft:honeycomb_block
setblock 26 243 362 minecraft:yellow_terracotta
fill 26 243 363 26 246 363 minecraft:honeycomb_block
setblock 27 243 361 minecraft:yellow_terracotta
fill 27 243 362 27 246 362 minecraft:honeycomb_block
fill 28 243 361 28 244 361 minecraft:honeycomb_block
setblock 29 243 324 minecraft:yellow_terracotta
fill 29 243 352 29 244 352 minecraft:ochre_froglight
setblock 30 243 323 minecraft:yellow_terracotta
setblock 30 243 363 minecraft:yellow_terracotta
setblock 31 243 323 minecraft:honeycomb_block
setblock 31 243 362 minecraft:yellow_terracotta
fill 31 243 363 31 245 363 minecraft:honeycomb_block
setblock 39 243 350 minecraft:honeycomb_block
setblock 39 243 354 minecraft:yellow_terracotta
fill 39 243 355 39 245 356 minecraft:honeycomb_block
setblock 40 243 333 minecraft:yellow_terracotta
setblock 40 243 348 minecraft:yellow_terracotta
fill 40 243 349 40 246 349 minecraft:honeycomb_block
setblock 40 243 353 minecraft:yellow_terracotta
fill 40 243 354 40 246 354 minecraft:honeycomb_block
setblock 40 243 358 minecraft:yellow_terracotta
fill 40 243 359 40 246 359 minecraft:honeycomb_block
setblock 41 243 325 minecraft:honey_block
setblock 41 243 327 minecraft:yellow_terracotta
fill 41 243 328 41 243 331 minecraft:honeycomb_block
setblock 41 243 332 minecraft:yellow_terracotta
fill 41 243 333 41 243 336 minecraft:honeycomb_block
setblock 41 243 337 minecraft:yellow_terracotta
fill 41 243 338 41 246 338 minecraft:honeycomb_block
setblock 41 243 341 minecraft:honeycomb_block
setblock 41 243 342 minecraft:yellow_terracotta
fill 41 243 343 41 246 343 minecraft:honeycomb_block
setblock 41 243 347 minecraft:yellow_terracotta
fill 41 243 348 41 246 348 minecraft:honeycomb_block
setblock 41 243 352 minecraft:yellow_terracotta
fill 41 243 353 41 246 353 minecraft:honeycomb_block
setblock 41 243 357 minecraft:yellow_terracotta
fill 41 243 358 41 246 358 minecraft:honeycomb_block
setblock 41 243 362 minecraft:yellow_terracotta
fill 0 244 333 1 246 333 minecraft:honeycomb_block
setblock 1 244 323 minecraft:honey_block
setblock 1 244 326 minecraft:yellow_terracotta
fill 1 244 327 1 247 327 minecraft:honeycomb_block
setblock 1 244 331 minecraft:yellow_terracotta
fill 1 244 332 1 247 332 minecraft:honeycomb_block
fill 1 244 334 1 244 335 minecraft:honeycomb_block
setblock 1 244 336 minecraft:yellow_terracotta
fill 1 244 337 1 247 337 minecraft:honeycomb_block
setblock 1 244 341 minecraft:yellow_terracotta
fill 1 244 342 1 247 342 minecraft:honeycomb_block
setblock 1 244 346 minecraft:yellow_terracotta
fill 1 244 347 1 247 347 minecraft:honeycomb_block
setblock 1 244 351 minecraft:yellow_terracotta
fill 1 244 352 1 247 352 minecraft:honeycomb_block
setblock 1 244 356 minecraft:yellow_terracotta
fill 1 244 357 1 247 357 minecraft:honeycomb_block
setblock 1 244 360 minecraft:honeycomb_block
setblock 2 244 330 minecraft:yellow_terracotta
fill 2 244 331 2 247 331 minecraft:honeycomb_block
setblock 2 244 335 minecraft:yellow_terracotta
fill 2 244 336 2 247 336 minecraft:honeycomb_block
setblock 2 244 340 minecraft:yellow_terracotta
fill 2 244 341 2 247 341 minecraft:honeycomb_block
setblock 2 244 345 minecraft:yellow_terracotta
fill 2 244 346 2 245 346 minecraft:honeycomb_block
setblock 2 244 350 minecraft:yellow_terracotta
fill 2 244 351 2 246 351 minecraft:honeycomb_block
setblock 2 244 355 minecraft:yellow_terracotta
fill 2 244 356 2 247 356 minecraft:honeycomb_block
setblock 3 244 329 minecraft:yellow_terracotta
fill 3 244 330 3 247 330 minecraft:honeycomb_block
setblock 3 244 333 minecraft:honeycomb_block
setblock 3 244 334 minecraft:yellow_terracotta
fill 3 244 335 3 247 335 minecraft:honeycomb_block
setblock 3 244 339 minecraft:yellow_terracotta
fill 3 244 340 3 247 340 minecraft:honeycomb_block
setblock 3 244 349 minecraft:yellow_terracotta
setblock 3 244 350 minecraft:honeycomb_block
setblock 3 244 354 minecraft:yellow_terracotta
setblock 3 244 355 minecraft:honeycomb_block
setblock 4 244 323 minecraft:yellow_terracotta
setblock 4 244 333 minecraft:yellow_terracotta
fill 4 244 334 4 247 334 minecraft:honeycomb_block
fill 5 244 323 5 247 323 minecraft:honeycomb_block
setblock 5 244 363 minecraft:honey_block
fill 6 244 324 7 244 324 minecraft:honeycomb_block
setblock 9 244 323 minecraft:yellow_terracotta
setblock 10 244 323 minecraft:honeycomb_block
setblock 12 244 323 minecraft:honey_block
setblock 19 244 323 minecraft:yellow_terracotta
setblock 19 244 363 minecraft:yellow_terracotta
fill 20 244 323 20 247 323 minecraft:honeycomb_block
fill 20 244 363 20 247 363 minecraft:honeycomb_block
fill 21 244 362 21 247 362 minecraft:honeycomb_block
setblock 23 244 324 minecraft:yellow_terracotta
setblock 24 244 323 minecraft:yellow_terracotta
fill 24 244 324 24 245 324 minecraft:honeycomb_block
fill 24 244 361 25 244 361 minecraft:honeycomb_block
setblock 24 244 363 minecraft:yellow_terracotta
fill 25 244 323 25 247 323 minecraft:honeycomb_block
setblock 25 244 362 minecraft:yellow_terracotta
fill 25 244 363 25 247 363 minecraft:honeycomb_block
setblock 26 244 361 minecraft:yellow_terracotta
fill 26 244 362 26 247 362 minecraft:honeycomb_block
fill 27 244 361 27 246 361 minecraft:honeycomb_block
setblock 29 244 323 minecraft:yellow_terracotta
setblock 29 244 363 minecraft:yellow_terracotta
setblock 30 244 362 minecraft:yellow_terracotta
fill 30 244 363 30 247 363 minecraft:honeycomb_block
fill 35 244 327 35 247 327 minecraft:brown_terracotta
fill 36 244 326 36 247 326 minecraft:brown_terracotta
fill 36 244 328 36 247 328 minecraft:brown_terracotta
setblock 37 244 323 minecraft:honey_block
fill 37 244 327 37 247 327 minecraft:brown_terracotta
setblock 39 244 353 minecraft:yellow_terracotta
fill 39 244 354 39 246 354 minecraft:honeycomb_block
setblock 40 244 332 minecraft:yellow_terracotta
fill 40 244 333 40 244 336 minecraft:honeycomb_block
setblock 40 244 347 minecraft:yellow_terracotta
fill 40 244 348 40 246 348 minecraft:honeycomb_block
setblock 40 244 352 minecraft:yellow_terracotta
fill 40 244 353 40 247 353 minecraft:honeycomb_block
setblock 40 244 357 minecraft:yellow_terracotta
fill 40 244 358 40 247 358 minecraft:honeycomb_block
fill 41 244 328 41 244 330 minecraft:honeycomb_block
setblock 41 244 331 minecraft:yellow_terracotta
fill 41 244 332 41 244 335 minecraft:honeycomb_block
setblock 41 244 336 minecraft:yellow_terracotta
fill 41 244 337 41 247 337 minecraft:honeycomb_block
setblock 41 244 341 minecraft:yellow_terracotta
fill 41 244 342 41 247 342 minecraft:honeycomb_block
setblock 41 244 346 minecraft:yellow_terracotta
fill 41 244 347 41 247 347 minecraft:honeycomb_block
setblock 41 244 351 minecraft:yellow_terracotta
fill 41 244 352 41 247 352 minecraft:honeycomb_block
setblock 41 244 356 minecraft:yellow_terracotta
fill 41 244 357 41 247 357 minecraft:honeycomb_block
setblock 41 244 360 minecraft:honeycomb_block
setblock 41 244 361 minecraft:yellow_terracotta
fill 41 244 362 41 247 362 minecraft:honeycomb_block
setblock 42 244 333 minecraft:yellow_concrete
setblock 42 244 355 minecraft:yellow_terracotta
fill 1 245 326 1 248 326 minecraft:honeycomb_block
setblock 1 245 330 minecraft:yellow_terracotta
fill 1 245 331 1 248 331 minecraft:honeycomb_block
setblock 1 245 334 minecraft:honeycomb_block
setblock 1 245 335 minecraft:yellow_terracotta
fill 1 245 336 1 248 336 minecraft:honeycomb_block
setblock 1 245 340 minecraft:yellow_terracotta
fill 1 245 341 1 248 341 minecraft:honeycomb_block
setblock 1 245 345 minecraft:yellow_terracotta
fill 1 245 346 1 248 346 minecraft:honeycomb_block
setblock 1 245 350 minecraft:yellow_terracotta
fill 1 245 351 1 248 351 minecraft:honeycomb_block
setblock 1 245 355 minecraft:yellow_terracotta
fill 1 245 356 1 248 356 minecraft:honeycomb_block
setblock 1 245 360 minecraft:yellow_terracotta
setblock 1 245 364 minecraft:orange_terracotta
setblock 2 245 329 minecraft:yellow_terracotta
fill 2 245 330 2 248 330 minecraft:honeycomb_block
setblock 2 245 334 minecraft:yellow_terracotta
fill 2 245 335 2 248 335 minecraft:honeycomb_block
setblock 2 245 339 minecraft:yellow_terracotta
fill 2 245 340 2 248 340 minecraft:honeycomb_block
setblock 2 245 344 minecraft:yellow_terracotta
setblock 2 245 345 minecraft:honeycomb_block
setblock 2 245 349 minecraft:yellow_terracotta
fill 2 245 350 2 246 350 minecraft:honeycomb_block
setblock 2 245 354 minecraft:yellow_terracotta
fill 2 245 355 2 248 355 minecraft:honeycomb_block
setblock 3 245 323 minecraft:yellow_terracotta
fill 3 245 329 3 246 329 minecraft:honeycomb_block
setblock 3 245 333 minecraft:yellow_terracotta
fill 3 245 334 3 248 334 minecraft:honeycomb_block
setblock 3 245 338 minecraft:yellow_terracotta
fill 3 245 339 3 248 339 minecraft:honeycomb_block
setblock 3 245 353 minecraft:yellow_terracotta
setblock 3 245 354 minecraft:honeycomb_block
fill 4 245 323 4 248 323 minecraft:honeycomb_block
setblock 4 245 332 minecraft:yellow_terracotta
fill 4 245 333 4 247 333 minecraft:honeycomb_block
setblock 4 245 337 minecraft:yellow_terracotta
setblock 8 245 323 minecraft:yellow_terracotta
setblock 9 245 323 minecraft:honeycomb_block
setblock 11 245 363 minecraft:honey_block
setblock 18 245 323 minecraft:yellow_terracotta
fill 19 245 323 19 248 323 minecraft:honeycomb_block
fill 19 245 363 19 248 363 minecraft:honeycomb_block
setblock 22 245 324 minecraft:yellow_terracotta
setblock 23 245 323 minecraft:yellow_terracotta
setblock 23 245 324 minecraft:honeycomb_block
fill 23 245 361 24 245 361 minecraft:honeycomb_block
setblock 23 245 363 minecraft:yellow_terracotta
fill 24 245 323 24 248 323 minecraft:honeycomb_block
fill 24 245 356 25 246 356 minecraft:yellow_concrete
setblock 24 245 362 minecraft:yellow_terracotta
fill 24 245 363 24 248 363 minecraft:honeycomb_block
setblock 25 245 361 minecraft:yellow_terracotta
fill 25 245 362 25 248 362 minecraft:honeycomb_block
fill 26 245 361 26 248 361 minecraft:honeycomb_block
setblock 28 245 323 minecraft:yellow_terracotta
setblock 28 245 363 minecraft:yellow_terracotta
fill 29 245 352 29 253 352 minecraft:brown_terracotta
setblock 29 245 362 minecraft:yellow_terracotta
fill 29 245 363 29 248 363 minecraft:honeycomb_block
setblock 31 245 323 minecraft:honey_block
fill 36 245 363 36 246 363 minecraft:honey_block
setblock 39 245 352 minecraft:yellow_terracotta
fill 39 245 353 39 246 353 minecraft:honeycomb_block
fill 40 245 332 40 245 335 minecraft:honeycomb_block
setblock 40 245 336 minecraft:yellow_terracotta
fill 40 245 337 40 248 337 minecraft:honeycomb_block
setblock 40 245 351 minecraft:yellow_terracotta
fill 40 245 352 40 248 352 minecraft:honeycomb_block
setblock 40 245 356 minecraft:yellow_terracotta
fill 40 245 357 40 248 357 minecraft:honeycomb_block
fill 41 245 328 41 245 329 minecraft:honeycomb_block
fill 41 245 330 42 245 330 minecraft:yellow_terracotta
fill 41 245 331 41 245 334 minecraft:honeycomb_block
setblock 41 245 335 minecraft:yellow_terracotta
fill 41 245 336 41 248 336 minecraft:honeycomb_block
setblock 41 245 339 minecraft:honeycomb_block
setblock 41 245 340 minecraft:yellow_terracotta
fill 41 245 341 41 248 341 minecraft:honeycomb_block
setblock 41 245 345 minecraft:yellow_terracotta
fill 41 245 346 41 248 346 minecraft:honeycomb_block
setblock 41 245 350 minecraft:yellow_terracotta
fill 41 245 351 41 248 351 minecraft:honeycomb_block
setblock 41 245 355 minecraft:yellow_terracotta
fill 41 245 356 41 248 356 minecraft:honeycomb_block
setblock 41 245 360 minecraft:yellow_terracotta
fill 41 245 361 41 248 361 minecraft:honeycomb_block
fill 42 245 333 42 267 333 minecraft:honeycomb_block
fill 42 245 355 42 308 355 minecraft:honeycomb_block
setblock 1 246 329 minecraft:yellow_terracotta
fill 1 246 330 1 249 330 minecraft:honeycomb_block
setblock 1 246 334 minecraft:yellow_terracotta
fill 1 246 335 1 249 335 minecraft:honeycomb_block
setblock 1 246 339 minecraft:yellow_terracotta
fill 1 246 340 1 249 340 minecraft:honeycomb_block
setblock 1 246 344 minecraft:yellow_terracotta
fill 1 246 345 1 249 345 minecraft:honeycomb_block
setblock 1 246 349 minecraft:yellow_terracotta
fill 1 246 350 1 249 350 minecraft:honeycomb_block
setblock 1 246 354 minecraft:yellow_terracotta
fill 1 246 355 1 249 355 minecraft:honeycomb_block
setblock 1 246 358 minecraft:honeycomb_block
setblock 1 246 359 minecraft:yellow_terracotta
fill 1 246 360 1 249 360 minecraft:honeycomb_block
fill 1 246 364 1 296 364 minecraft:honeycomb_block
setblock 2 246 328 minecraft:yellow_terracotta
fill 2 246 329 2 249 329 minecraft:honeycomb_block
setblock 2 246 333 minecraft:yellow_terracotta
fill 2 246 334 2 249 334 minecraft:honeycomb_block
setblock 2 246 338 minecraft:yellow_terracotta
fill 2 246 339 2 249 339 minecraft:honeycomb_block
setblock 2 246 343 minecraft:yellow_terracotta
setblock 2 246 349 minecraft:honeycomb_block
setblock 2 246 353 minecraft:yellow_terracotta
fill 2 246 354 2 248 354 minecraft:honeycomb_block
setblock 2 246 358 minecraft:yellow_terracotta
setblock 3 246 323 minecraft:honeycomb_block
setblock 3 246 332 minecraft:yellow_terracotta
fill 3 246 333 3 249 333 minecraft:honeycomb_block
setblock 3 246 337 minecraft:yellow_terracotta
fill 3 246 338 3 249 338 minecraft:honeycomb_block
setblock 4 246 331 minecraft:yellow_terracotta
fill 4 246 332 4 247 332 minecraft:honeycomb_block
setblock 4 246 336 minecraft:yellow_terracotta
fill 4 246 337 4 249 337 minecraft:honeycomb_block
setblock 7 246 323 minecraft:yellow_terracotta
setblock 17 246 363 minecraft:honey_block
fill 18 246 363 18 249 363 minecraft:honeycomb_block
setblock 18 246 364 minecraft:yellow_terracotta
fill 20 246 362 20 248 362 minecraft:honeycomb_block
setblock 22 246 323 minecraft:yellow_terracotta
fill 22 246 330 22 247 331 minecraft:black_concrete
fill 22 246 361 23 246 361 minecraft:honeycomb_block
fill 22 246 363 22 246 364 minecraft:yellow_terracotta
fill 23 246 323 23 249 323 minecraft:honeycomb_block
setblock 23 246 362 minecraft:yellow_terracotta
fill 23 246 363 23 249 363 minecraft:honeycomb_block
setblock 24 246 361 minecraft:yellow_terracotta
fill 24 246 362 24 249 362 minecraft:honeycomb_block
fill 25 246 361 25 249 361 minecraft:honeycomb_block
setblock 27 246 323 minecraft:yellow_terracotta
setblock 27 246 363 minecraft:yellow_terracotta
fill 28 246 352 28 253 352 minecraft:brown_terracotta
setblock 28 246 362 minecraft:yellow_terracotta
fill 28 246 363 28 249 363 minecraft:honeycomb_block
fill 29 246 353 29 253 353 minecraft:brown_terracotta
setblock 29 246 362 minecraft:honeycomb_block
setblock 30 246 364 minecraft:yellow_terracotta
fill 35 246 326 35 247 326 minecraft:brown_terracotta
fill 35 246 328 35 247 328 minecraft:brown_terracotta
fill 37 246 326 37 247 326 minecraft:brown_terracotta
fill 37 246 328 37 247 328 minecraft:brown_terracotta
setblock 39 246 355 minecraft:honeycomb_block
setblock 39 246 356 minecraft:yellow_terracotta
fill 40 246 333 40 246 334 minecraft:honeycomb_block
setblock 40 246 335 minecraft:yellow_terracotta
fill 40 246 336 40 249 336 minecraft:honeycomb_block
fill 40 246 338 40 246 339 minecraft:honeycomb_block
setblock 40 246 350 minecraft:yellow_terracotta
fill 40 246 351 40 249 351 minecraft:honeycomb_block
setblock 40 246 355 minecraft:yellow_terracotta
fill 40 246 356 40 249 356 minecraft:honeycomb_block
setblock 41 246 326 minecraft:honey_block
setblock 41 246 329 minecraft:yellow_terracotta
fill 41 246 330 41 246 333 minecraft:honeycomb_block
setblock 41 246 334 minecraft:yellow_terracotta
fill 41 246 335 41 249 335 minecraft:honeycomb_block
setblock 41 246 339 minecraft:yellow_terracotta
fill 41 246 340 41 249 340 minecraft:honeycomb_block
setblock 41 246 344 minecraft:yellow_terracotta
fill 41 246 345 41 249 345 minecraft:honeycomb_block
setblock 41 246 349 minecraft:yellow_terracotta
fill 41 246 350 41 249 350 minecraft:honeycomb_block
setblock 41 246 354 minecraft:yellow_terracotta
fill 41 246 355 41 249 355 minecraft:honeycomb_block
setblock 41 246 359 minecraft:yellow_terracotta
fill 41 246 360 41 249 360 minecraft:honeycomb_block
fill 42 246 330 42 308 330 minecraft:honeycomb_block
fill 0 247 333 0 255 333 minecraft:honeycomb_block
setblock 0 247 347 minecraft:orange_terracotta
setblock 1 247 328 minecraft:yellow_terracotta
fill 1 247 329 1 250 329 minecraft:honeycomb_block
setblock 1 247 333 minecraft:yellow_terracotta
fill 1 247 334 1 250 334 minecraft:honeycomb_block
setblock 1 247 338 minecraft:yellow_terracotta
fill 1 247 339 1 250 339 minecraft:honeycomb_block
setblock 1 247 343 minecraft:yellow_terracotta
fill 1 247 344 1 250 344 minecraft:honeycomb_block
setblock 1 247 348 minecraft:yellow_terracotta
fill 1 247 349 1 250 349 minecraft:honeycomb_block
setblock 1 247 353 minecraft:yellow_terracotta
fill 1 247 354 1 250 354 minecraft:honeycomb_block
setblock 1 247 358 minecraft:yellow_terracotta
fill 1 247 359 1 250 359 minecraft:honeycomb_block
fill 1 247 361 1 248 361 minecraft:honeycomb_block
fill 2 247 328 2 248 328 minecraft:honeycomb_block
setblock 2 247 332 minecraft:yellow_terracotta
fill 2 247 333 2 250 333 minecraft:honeycomb_block
setblock 2 247 337 minecraft:yellow_terracotta
fill 2 247 338 2 250 338 minecraft:honeycomb_block
setblock 2 247 342 minecraft:yellow_terracotta
fill 2 247 343 2 250 343 minecraft:honeycomb_block
setblock 2 247 352 minecraft:yellow_terracotta
setblock 2 247 353 minecraft:honeycomb_block
setblock 2 247 357 minecraft:yellow_terracotta
fill 2 247 358 2 250 358 minecraft:honeycomb_block
setblock 3 247 331 minecraft:yellow_terracotta
fill 3 247 332 3 250 332 minecraft:honeycomb_block
setblock 3 247 336 minecraft:yellow_terracotta
fill 3 247 337 3 250 337 minecraft:honeycomb_block
setblock 4 247 335 minecraft:yellow_terracotta
fill 4 247 336 4 250 336 minecraft:honeycomb_block
setblock 4 247 363 minecraft:honey_block
setblock 6 247 323 minecraft:yellow_terracotta
setblock 16 247 322 minecraft:yellow_terracotta
fill 18 247 323 18 249 323 minecraft:honeycomb_block
fill 18 247 364 18 308 364 minecraft:honeycomb_block
setblock 21 247 323 minecraft:yellow_terracotta
setblock 21 247 363 minecraft:yellow_terracotta
fill 22 247 323 22 250 323 minecraft:honeycomb_block
setblock 22 247 361 minecraft:honeycomb_block
setblock 22 247 362 minecraft:yellow_terracotta
fill 22 247 363 22 250 364 minecraft:honeycomb_block
setblock 23 247 361 minecraft:yellow_terracotta
fill 23 247 362 23 250 362 minecraft:honeycomb_block
fill 24 247 361 24 250 361 minecraft:honeycomb_block
setblock 26 247 323 minecraft:yellow_terracotta
setblock 26 247 363 minecraft:yellow_terracotta
setblock 27 247 362 minecraft:yellow_terracotta
fill 27 247 363 27 250 363 minecraft:honeycomb_block
fill 28 247 353 28 253 353 minecraft:brown_terracotta
fill 28 247 362 28 250 362 minecraft:honeycomb_block
fill 30 247 364 30 308 364 minecraft:honeycomb_block
setblock 38 247 323 minecraft:honey_block
setblock 39 247 355 minecraft:yellow_terracotta
setblock 40 247 333 minecraft:honeycomb_block
setblock 40 247 334 minecraft:yellow_terracotta
fill 40 247 335 40 250 335 minecraft:honeycomb_block
setblock 40 247 338 minecraft:honeycomb_block
setblock 40 247 339 minecraft:yellow_terracotta
fill 40 247 340 40 250 340 minecraft:honeycomb_block
setblock 40 247 349 minecraft:yellow_terracotta
fill 40 247 350 40 250 350 minecraft:honeycomb_block
setblock 40 247 354 minecraft:yellow_terracotta
fill 40 247 355 40 250 355 minecraft:honeycomb_block
setblock 40 247 359 minecraft:yellow_terracotta
fill 40 247 360 40 250 360 minecraft:honeycomb_block
fill 41 247 329 41 247 332 minecraft:honeycomb_block
setblock 41 247 333 minecraft:yellow_terracotta
fill 41 247 334 41 250 334 minecraft:honeycomb_block
setblock 41 247 338 minecraft:yellow_terracotta
fill 41 247 339 41 250 339 minecraft:honeycomb_block
setblock 41 247 343 minecraft:yellow_terracotta
fill 41 247 344 41 250 344 minecraft:honeycomb_block
setblock 41 247 348 minecraft:yellow_terracotta
fill 41 247 349 41 250 349 minecraft:honeycomb_block
setblock 41 247 353 minecraft:yellow_terracotta
fill 41 247 354 41 250 354 minecraft:honeycomb_block
setblock 41 247 358 minecraft:yellow_terracotta
fill 41 247 359 41 250 359 minecraft:honeycomb_block
fill 0 248 347 0 305 347 minecraft:honeycomb_block
setblock 1 248 327 minecraft:yellow_terracotta
fill 1 248 328 1 251 328 minecraft:honeycomb_block
setblock 1 248 332 minecraft:yellow_terracotta
fill 1 248 333 1 251 333 minecraft:honeycomb_block
setblock 1 248 337 minecraft:yellow_terracotta
fill 1 248 338 1 251 338 minecraft:honeycomb_block
setblock 1 248 342 minecraft:yellow_terracotta
fill 1 248 343 1 251 343 minecraft:honeycomb_block
setblock 1 248 347 minecraft:yellow_terracotta
fill 1 248 348 1 251 348 minecraft:honeycomb_block
setblock 1 248 352 minecraft:yellow_terracotta
fill 1 248 353 1 251 353 minecraft:honeycomb_block
setblock 1 248 357 minecraft:yellow_terracotta
fill 1 248 358 1 251 358 minecraft:honeycomb_block
setblock 1 248 362 minecraft:yellow_terracotta
setblock 2 248 331 minecraft:yellow_terracotta
fill 2 248 332 2 251 332 minecraft:honeycomb_block
setblock 2 248 336 minecraft:yellow_terracotta
fill 2 248 337 2 251 337 minecraft:honeycomb_block
setblock 2 248 341 minecraft:yellow_terracotta
fill 2 248 342 2 251 342 minecraft:honeycomb_block
setblock 2 248 356 minecraft:yellow_terracotta
fill 2 248 357 2 251 357 minecraft:honeycomb_block
fill 3 248 323 3 249 323 minecraft:honeycomb_block
setblock 3 248 325 minecraft:light[level=15]
fill 3 248 331 3 250 331 minecraft:honeycomb_block
setblock 3 248 335 minecraft:yellow_terracotta
fill 3 248 336 3 251 336 minecraft:honeycomb_block
setblock 3 248 340 minecraft:yellow_terracotta
setblock 3 248 341 minecraft:light[level=15]
setblock 3 248 346 minecraft:light[level=12]
setblock 3 248 349 minecraft:light[level=15]
setblock 3 248 353 minecraft:light[level=12]
setblock 3 248 357 minecraft:light[level=15]
setblock 3 248 360 minecraft:light[level=12]
setblock 4 248 334 minecraft:yellow_terracotta
fill 4 248 335 4 249 335 minecraft:honeycomb_block
setblock 5 248 323 minecraft:yellow_terracotta
setblock 10 248 325 minecraft:light[level=12]
setblock 10 248 332 minecraft:light[level=12]
setblock 10 248 346 minecraft:light[level=12]
setblock 10 248 353 minecraft:light[level=12]
setblock 10 248 360 minecraft:light[level=12]
setblock 10 248 363 minecraft:honey_block
setblock 11 248 325 minecraft:light[level=15]
setblock 11 248 333 minecraft:light[level=15]
setblock 11 248 341 minecraft:light[level=15]
setblock 11 248 349 minecraft:light[level=15]
setblock 11 248 357 minecraft:light[level=15]
setblock 13 248 323 minecraft:honey_block
fill 16 248 322 16 255 322 minecraft:honeycomb_block
setblock 17 248 325 minecraft:light[level=12]
setblock 17 248 332 minecraft:light[level=12]
setblock 17 248 339 minecraft:light[level=12]
setblock 17 248 346 minecraft:light[level=12]
setblock 17 248 353 minecraft:light[level=12]
setblock 17 248 360 minecraft:light[level=12]
fill 17 248 363 17 250 363 minecraft:honeycomb_block
setblock 19 248 325 minecraft:light[level=15]
setblock 19 248 333 minecraft:light[level=15]
setblock 19 248 341 minecraft:light[level=15]
setblock 19 248 349 minecraft:light[level=15]
setblock 19 248 357 minecraft:light[level=15]
fill 19 248 362 19 249 362 minecraft:honeycomb_block
setblock 20 248 323 minecraft:yellow_terracotta
setblock 20 248 363 minecraft:yellow_terracotta
fill 21 248 323 21 251 323 minecraft:honeycomb_block
setblock 21 248 361 minecraft:honeycomb_block
setblock 21 248 362 minecraft:yellow_terracotta
fill 21 248 363 21 251 363 minecraft:honeycomb_block
setblock 22 248 361 minecraft:yellow_terracotta
fill 22 248 362 22 251 362 minecraft:honeycomb_block
fill 23 248 361 23 251 361 minecraft:honeycomb_block
setblock 24 248 325 minecraft:light[level=12]
setblock 24 248 332 minecraft:light[level=12]
setblock 24 248 339 minecraft:light[level=12]
setblock 24 248 346 minecraft:light[level=12]
setblock 24 248 353 minecraft:light[level=12]
setblock 24 248 360 minecraft:light[level=12]
setblock 25 248 323 minecraft:yellow_terracotta
setblock 25 248 363 minecraft:yellow_terracotta
setblock 26 248 362 minecraft:yellow_terracotta
fill 26 248 363 26 251 363 minecraft:honeycomb_block
setblock 27 248 325 minecraft:light[level=15]
setblock 27 248 333 minecraft:light[level=15]
setblock 27 248 349 minecraft:light[level=15]
fill 27 248 352 27 253 353 minecraft:brown_terracotta
setblock 27 248 357 minecraft:light[level=15]
fill 27 248 362 27 251 362 minecraft:honeycomb_block
fill 28 248 351 29 253 351 minecraft:brown_terracotta
fill 28 248 354 29 253 354 minecraft:brown_terracotta
fill 30 248 352 30 253 353 minecraft:brown_terracotta
setblock 31 248 325 minecraft:light[level=12]
setblock 31 248 332 minecraft:light[level=12]
setblock 31 248 339 minecraft:light[level=12]
setblock 31 248 346 minecraft:light[level=12]
setblock 31 248 353 minecraft:light[level=12]
setblock 31 248 360 minecraft:light[level=12]
setblock 32 248 323 minecraft:honey_block
setblock 35 248 325 minecraft:light[level=15]
setblock 35 248 333 minecraft:light[level=15]
setblock 35 248 341 minecraft:light[level=15]
setblock 35 248 349 minecraft:light[level=15]
setblock 35 248 357 minecraft:light[level=15]
fill 37 248 337 37 252 337 minecraft:yellow_terracotta
setblock 38 248 325 minecraft:light[level=12]
setblock 38 248 332 minecraft:light[level=12]
setblock 38 248 339 minecraft:light[level=12]
setblock 38 248 346 minecraft:light[level=12]
setblock 38 248 353 minecraft:light[level=12]
setblock 38 248 360 minecraft:light[level=12]
setblock 40 248 333 minecraft:yellow_terracotta
fill 40 248 334 40 251 334 minecraft:honeycomb_block
setblock 40 248 338 minecraft:yellow_terracotta
fill 40 248 339 40 251 339 minecraft:honeycomb_block
fill 40 248 341 40 248 342 minecraft:honeycomb_block
setblock 40 248 353 minecraft:yellow_terracotta
fill 40 248 354 40 251 354 minecraft:honeycomb_block
setblock 40 248 358 minecraft:yellow_terracotta
fill 40 248 359 40 251 359 minecraft:honeycomb_block
fill 41 248 330 41 248 331 minecraft:honeycomb_block
setblock 41 248 332 minecraft:yellow_terracotta
fill 41 248 333 41 251 333 minecraft:honeycomb_block
setblock 41 248 337 minecraft:yellow_terracotta
fill 41 248 338 41 251 338 minecraft:honeycomb_block
setblock 41 248 342 minecraft:yellow_terracotta
fill 41 248 343 41 251 343 minecraft:honeycomb_block
setblock 41 248 347 minecraft:yellow_terracotta
fill 41 248 348 41 251 348 minecraft:honeycomb_block
setblock 41 248 352 minecraft:yellow_terracotta
fill 41 248 353 41 251 353 minecraft:honeycomb_block
setblock 41 248 357 minecraft:yellow_terracotta
fill 41 248 358 41 251 358 minecraft:honeycomb_block
setblock 41 248 362 minecraft:yellow_terracotta
fill 41 248 363 41 251 363 minecraft:honeycomb_block
setblock 0 249 354 minecraft:orange_terracotta
setblock 1 249 325 minecraft:honeycomb_block
setblock 1 249 326 minecraft:yellow_terracotta
fill 1 249 327 1 252 327 minecraft:honeycomb_block
setblock 1 249 331 minecraft:yellow_terracotta
fill 1 249 332 1 252 332 minecraft:honeycomb_block
setblock 1 249 336 minecraft:yellow_terracotta
fill 1 249 337 1 252 337 minecraft:honeycomb_block
setblock 1 249 341 minecraft:yellow_terracotta
fill 1 249 342 1 252 342 minecraft:honeycomb_block
setblock 1 249 346 minecraft:yellow_terracotta
fill 1 249 347 1 252 347 minecraft:honeycomb_block
setblock 1 249 351 minecraft:yellow_terracotta
fill 1 249 352 1 252 352 minecraft:honeycomb_block
setblock 1 249 356 minecraft:yellow_terracotta
fill 1 249 357 1 252 357 minecraft:honeycomb_block
setblock 1 249 361 minecraft:yellow_terracotta
fill 1 249 362 1 251 363 minecraft:honeycomb_block
fill 2 249 323 2 250 323 minecraft:honeycomb_block
setblock 2 249 330 minecraft:yellow_terracotta
fill 2 249 331 2 252 331 minecraft:honeycomb_block
setblock 2 249 335 minecraft:yellow_terracotta
fill 2 249 336 2 252 336 minecraft:honeycomb_block
setblock 2 249 340 minecraft:yellow_terracotta
fill 2 249 341 3 251 341 minecraft:honeycomb_block
setblock 2 249 355 minecraft:yellow_terracotta
fill 2 249 356 2 251 356 minecraft:honeycomb_block
setblock 2 249 359 minecraft:honeycomb_block
fill 2 249 363 3 249 363 minecraft:honeycomb_block
setblock 3 249 334 minecraft:yellow_terracotta
fill 3 249 335 3 252 335 minecraft:honeycomb_block
setblock 3 249 339 minecraft:yellow_terracotta
fill 3 249 340 3 252 340 minecraft:honeycomb_block
setblock 4 249 323 minecraft:yellow_terracotta
setblock 4 249 363 minecraft:yellow_terracotta
fill 5 249 323 6 251 323 minecraft:honeycomb_block
setblock 7 249 323 minecraft:honey_block
fill 16 249 363 16 251 363 minecraft:honeycomb_block
fill 17 249 323 17 250 323 minecraft:honeycomb_block
fill 18 249 362 18 250 362 minecraft:honeycomb_block
setblock 19 249 323 minecraft:yellow_terracotta
fill 19 249 361 20 249 361 minecraft:honeycomb_block
setblock 19 249 363 minecraft:yellow_terracotta
fill 20 249 323 20 252 323 minecraft:honeycomb_block
setblock 20 249 362 minecraft:yellow_terracotta
fill 20 249 363 20 252 363 minecraft:honeycomb_block
setblock 21 249 361 minecraft:yellow_terracotta
fill 21 249 362 21 252 362 minecraft:honeycomb_block
fill 22 249 361 22 252 361 minecraft:honeycomb_block
fill 23 249 360 23 252 360 minecraft:honeycomb_block
setblock 24 249 323 minecraft:yellow_terracotta
setblock 24 249 363 minecraft:yellow_terracotta
fill 25 249 323 25 252 323 minecraft:honeycomb_block
setblock 25 249 362 minecraft:yellow_terracotta
fill 25 249 363 25 252 363 minecraft:honeycomb_block
setblock 26 249 323 minecraft:honey_block
setblock 26 249 361 minecraft:yellow_terracotta
fill 26 249 362 26 252 362 minecraft:honeycomb_block
fill 27 249 351 27 253 351 minecraft:brown_terracotta
setblock 29 249 363 minecraft:yellow_terracotta
fill 30 249 351 30 253 351 minecraft:brown_terracotta
fill 30 249 354 30 253 354 minecraft:brown_terracotta
fill 30 249 363 30 252 363 minecraft:honeycomb_block
setblock 35 249 363 minecraft:honey_block
setblock 36 249 364 minecraft:yellow_terracotta
setblock 39 249 363 minecraft:yellow_terracotta
fill 40 249 333 40 252 333 minecraft:honeycomb_block
setblock 40 249 337 minecraft:yellow_terracotta
fill 40 249 338 40 252 338 minecraft:honeycomb_block
setblock 40 249 341 minecraft:honeycomb_block
setblock 40 249 342 minecraft:yellow_terracotta
fill 40 249 343 40 251 344 minecraft:honeycomb_block
setblock 40 249 352 minecraft:yellow_terracotta
fill 40 249 353 40 252 353 minecraft:honeycomb_block
setblock 40 249 357 minecraft:yellow_terracotta
fill 40 249 358 40 252 358 minecraft:honeycomb_block
setblock 40 249 361 minecraft:honeycomb_block
fill 40 249 363 40 252 363 minecraft:honeycomb_block
setblock 41 249 330 minecraft:honeycomb_block
setblock 41 249 331 minecraft:yellow_terracotta
fill 41 249 332 41 252 332 minecraft:honeycomb_block
setblock 41 249 336 minecraft:yellow_terracotta
fill 41 249 337 41 252 337 minecraft:honeycomb_block
setblock 41 249 341 minecraft:yellow_terracotta
fill 41 249 342 41 252 342 minecraft:honeycomb_block
setblock 41 249 346 minecraft:yellow_terracotta
fill 41 249 347 41 252 347 minecraft:honeycomb_block
setblock 41 249 351 minecraft:yellow_terracotta
fill 41 249 352 41 252 352 minecraft:honeycomb_block
setblock 41 249 356 minecraft:yellow_terracotta
fill 41 249 357 41 252 357 minecraft:honeycomb_block
setblock 41 249 361 minecraft:yellow_terracotta
fill 41 249 362 41 252 362 minecraft:honeycomb_block
setblock 0 250 338 minecraft:yellow_concrete
fill 0 250 354 0 289 354 minecraft:honeycomb_block
fill 1 250 323 1 250 324 minecraft:honeycomb_block
setblock 1 250 325 minecraft:yellow_terracotta
fill 1 250 326 1 253 326 minecraft:honeycomb_block
setblock 1 250 330 minecraft:yellow_terracotta
fill 1 250 331 1 253 331 minecraft:honeycomb_block
setblock 1 250 335 minecraft:yellow_terracotta
fill 1 250 336 1 253 336 minecraft:honeycomb_block
setblock 1 250 340 minecraft:yellow_terracotta
fill 1 250 341 1 253 341 minecraft:honeycomb_block
setblock 1 250 345 minecraft:yellow_terracotta
fill 1 250 346 1 253 346 minecraft:honeycomb_block
setblock 1 250 350 minecraft:yellow_terracotta
fill 1 250 351 1 253 351 minecraft:honeycomb_block
setblock 1 250 355 minecraft:yellow_terracotta
fill 1 250 356 1 253 356 minecraft:honeycomb_block
setblock 1 250 360 minecraft:yellow_terracotta
fill 1 250 361 1 253 361 minecraft:honeycomb_block
setblock 2 250 328 minecraft:honeycomb_block
setblock 2 250 329 minecraft:yellow_terracotta
fill 2 250 330 2 253 330 minecraft:honeycomb_block
setblock 2 250 334 minecraft:yellow_terracotta
fill 2 250 335 2 253 335 minecraft:honeycomb_block
setblock 2 250 339 minecraft:yellow_terracotta
fill 2 250 340 2 253 340 minecraft:honeycomb_block
setblock 2 250 344 minecraft:yellow_terracotta
setblock 2 250 359 minecraft:yellow_terracotta
fill 2 250 360 2 253 360 minecraft:honeycomb_block
setblock 2 250 363 minecraft:honeycomb_block
setblock 3 250 323 minecraft:yellow_terracotta
setblock 3 250 333 minecraft:yellow_terracotta
fill 3 250 334 3 253 334 minecraft:honeycomb_block
setblock 3 250 338 minecraft:yellow_terracotta
fill 3 250 339 3 253 339 minecraft:honeycomb_block
setblock 3 250 363 minecraft:yellow_terracotta
fill 4 250 323 4 253 323 minecraft:honeycomb_block
setblock 4 250 337 minecraft:yellow_terracotta
fill 4 250 363 6 251 363 minecraft:honeycomb_block
fill 14 250 363 15 252 363 minecraft:honeycomb_block
fill 16 250 323 16 251 323 minecraft:honeycomb_block
fill 16 250 362 17 251 362 minecraft:honeycomb_block
setblock 18 250 323 minecraft:yellow_terracotta
fill 18 250 361 19 250 361 minecraft:honeycomb_block
setblock 18 250 363 minecraft:yellow_terracotta
fill 19 250 323 19 253 323 minecraft:honeycomb_block
setblock 19 250 362 minecraft:yellow_terracotta
fill 19 250 363 19 253 363 minecraft:honeycomb_block
setblock 20 250 361 minecraft:yellow_terracotta
fill 20 250 362 20 253 362 minecraft:honeycomb_block
setblock 21 250 360 minecraft:yellow_terracotta
fill 21 250 361 21 253 361 minecraft:honeycomb_block
fill 22 250 360 22 253 360 minecraft:honeycomb_block
setblock 23 250 323 minecraft:yellow_terracotta
setblock 23 250 363 minecraft:yellow_terracotta
fill 24 250 323 24 253 323 minecraft:honeycomb_block
fill 24 250 360 24 251 360 minecraft:honeycomb_block
setblock 24 250 362 minecraft:yellow_terracotta
fill 24 250 363 24 253 363 minecraft:honeycomb_block
setblock 25 250 361 minecraft:yellow_terracotta
fill 25 250 362 25 253 362 minecraft:honeycomb_block
fill 26 250 352 26 253 353 minecraft:brown_terracotta
fill 26 250 361 26 253 361 minecraft:honeycomb_block
setblock 26 250 364 minecraft:yellow_concrete
fill 27 250 354 27 253 354 minecraft:brown_terracotta
fill 28 250 350 30 253 350 minecraft:brown_terracotta
fill 28 250 355 29 253 355 minecraft:brown_terracotta
setblock 28 250 363 minecraft:yellow_terracotta
fill 29 250 363 29 253 363 minecraft:honeycomb_block
fill 31 250 351 31 253 353 minecraft:brown_terracotta
fill 36 250 364 36 254 364 minecraft:honeycomb_block
setblock 37 250 363 minecraft:honeycomb_block
setblock 38 250 363 minecraft:yellow_terracotta
setblock 39 250 336 minecraft:honeycomb_block
setblock 39 250 337 minecraft:yellow_terracotta
fill 39 250 338 39 250 341 minecraft:honeycomb_block
setblock 39 250 356 minecraft:honeycomb_block
setblock 39 250 357 minecraft:yellow_terracotta
fill 39 250 363 39 253 363 minecraft:honeycomb_block
fill 40 250 332 40 253 332 minecraft:honeycomb_block
setblock 40 250 336 minecraft:yellow_terracotta
fill 40 250 337 40 253 337 minecraft:honeycomb_block
setblock 40 250 341 minecraft:yellow_terracotta
fill 40 250 342 40 253 342 minecraft:honeycomb_block
setblock 40 250 345 minecraft:honeycomb_block
setblock 40 250 346 minecraft:yellow_terracotta
fill 40 250 347 40 251 349 minecraft:honeycomb_block
setblock 40 250 351 minecraft:yellow_terracotta
fill 40 250 352 40 253 352 minecraft:honeycomb_block
setblock 40 250 356 minecraft:yellow_terracotta
fill 40 250 357 40 253 357 minecraft:honeycomb_block
setblock 40 250 361 minecraft:yellow_terracotta
fill 40 250 362 40 253 362 minecraft:honeycomb_block
setblock 41 250 327 minecraft:honey_block
setblock 41 250 329 minecraft:honeycomb_block
setblock 41 250 330 minecraft:yellow_terracotta
fill 41 250 331 41 253 331 minecraft:honeycomb_block
setblock 41 250 335 minecraft:yellow_terracotta
fill 41 250 336 41 253 336 minecraft:honeycomb_block
setblock 41 250 340 minecraft:yellow_terracotta
fill 41 250 341 41 253 341 minecraft:honeycomb_block
setblock 41 250 345 minecraft:yellow_terracotta
fill 41 250 346 41 253 346 minecraft:honeycomb_block
setblock 41 250 350 minecraft:yellow_terracotta
fill 41 250 351 41 253 351 minecraft:honeycomb_block
setblock 41 250 355 minecraft:yellow_terracotta
fill 41 250 356 41 253 356 minecraft:honeycomb_block
setblock 41 250 360 minecraft:yellow_terracotta
fill 41 250 361 41 253 361 minecraft:honeycomb_block
setblock 42 250 344 minecraft:yellow_concrete
fill 0 251 338 0 294 338 minecraft:honeycomb_block
setblock 1 251 323 minecraft:honeycomb_block
setblock 1 251 324 minecraft:yellow_terracotta
fill 1 251 325 1 254 325 minecraft:honeycomb_block
setblock 1 251 329 minecraft:yellow_terracotta
fill 1 251 330 1 254 330 minecraft:honeycomb_block
setblock 1 251 334 minecraft:yellow_terracotta
fill 1 251 335 1 254 335 minecraft:honeycomb_block
setblock 1 251 339 minecraft:yellow_terracotta
fill 1 251 340 1 254 340 minecraft:honeycomb_block
setblock 1 251 344 minecraft:yellow_terracotta
fill 1 251 345 2 253 345 minecraft:honeycomb_block
setblock 1 251 349 minecraft:yellow_terracotta
fill 1 251 350 1 254 350 minecraft:honeycomb_block
setblock 1 251 354 minecraft:yellow_terracotta
fill 1 251 355 1 254 355 minecraft:honeycomb_block
setblock 1 251 359 minecraft:yellow_terracotta
fill 1 251 360 1 254 360 minecraft:honeycomb_block
setblock 2 251 323 minecraft:yellow_terracotta
setblock 2 251 328 minecraft:yellow_terracotta
fill 2 251 329 2 254 329 minecraft:honeycomb_block
setblock 2 251 333 minecraft:yellow_terracotta
fill 2 251 334 2 254 334 minecraft:honeycomb_block
setblock 2 251 338 minecraft:yellow_terracotta
fill 2 251 339 2 254 339 minecraft:honeycomb_block
setblock 2 251 343 minecraft:yellow_terracotta
fill 2 251 344 2 254 344 minecraft:honeycomb_block
setblock 2 251 358 minecraft:yellow_terracotta
fill 2 251 359 2 254 359 minecraft:honeycomb_block
fill 2 251 361 2 251 362 minecraft:honeycomb_block
setblock 2 251 363 minecraft:yellow_terracotta
fill 3 251 323 3 254 323 minecraft:honeycomb_block
setblock 3 251 332 minecraft:yellow_terracotta
fill 3 251 333 3 254 333 minecraft:honeycomb_block
setblock 3 251 337 minecraft:yellow_terracotta
fill 3 251 338 3 254 338 minecraft:honeycomb_block
setblock 3 251 342 minecraft:yellow_terracotta
setblock 3 251 362 minecraft:yellow_terracotta
fill 3 251 363 3 254 363 minecraft:honeycomb_block
setblock 4 251 336 minecraft:yellow_terracotta
setblock 4 251 337 minecraft:honeycomb_block
fill 6 251 335 8 252 335 minecraft:yellow_concrete
setblock 7 251 323 minecraft:yellow_terracotta
fill 7 251 336 7 252 336 minecraft:yellow_concrete
setblock 7 251 363 minecraft:yellow_terracotta
fill 8 251 323 8 254 323 minecraft:honeycomb_block
setblock 12 251 363 minecraft:yellow_terracotta
fill 13 251 323 15 252 323 minecraft:honeycomb_block
fill 13 251 363 13 254 363 minecraft:honeycomb_block
fill 15 251 362 15 253 362 minecraft:honeycomb_block
setblock 17 251 323 minecraft:yellow_terracotta
fill 17 251 361 18 251 361 minecraft:honeycomb_block
setblock 17 251 363 minecraft:yellow_terracotta
fill 18 251 323 18 254 323 minecraft:honeycomb_block
setblock 18 251 362 minecraft:yellow_terracotta
fill 18 251 363 18 254 363 minecraft:honeycomb_block
fill 19 251 324 20 251 324 minecraft:honeycomb_block
setblock 19 251 360 minecraft:honeycomb_block
setblock 19 251 361 minecraft:yellow_terracotta
fill 19 251 362 19 254 362 minecraft:honeycomb_block
setblock 20 251 360 minecraft:yellow_terracotta
fill 20 251 361 20 254 361 minecraft:honeycomb_block
setblock 21 251 324 minecraft:yellow_terracotta
fill 21 251 360 21 254 360 minecraft:honeycomb_block
setblock 22 251 323 minecraft:yellow_terracotta
fill 22 251 324 22 254 324 minecraft:honeycomb_block
setblock 22 251 363 minecraft:yellow_terracotta
fill 22 251 364 22 308 364 minecraft:honeycomb_block
fill 23 251 323 23 254 323 minecraft:honeycomb_block
setblock 23 251 362 minecraft:yellow_terracotta
fill 23 251 363 23 254 363 minecraft:honeycomb_block
setblock 24 251 361 minecraft:yellow_terracotta
fill 24 251 362 24 254 362 minecraft:honeycomb_block
fill 25 251 361 25 254 361 minecraft:honeycomb_block
fill 26 251 351 26 253 351 minecraft:brown_terracotta
fill 26 251 354 26 253 354 minecraft:brown_terracotta
fill 26 251 364 26 270 364 minecraft:honeycomb_block
fill 27 251 350 27 253 350 minecraft:brown_terracotta
fill 27 251 355 27 253 355 minecraft:brown_terracotta
fill 27 251 361 27 252 361 minecraft:honeycomb_block
setblock 27 251 363 minecraft:yellow_terracotta
setblock 28 251 362 minecraft:yellow_terracotta
fill 28 251 363 28 254 363 minecraft:honeycomb_block
fill 29 251 362 29 254 362 minecraft:honeycomb_block
fill 30 251 355 30 253 355 minecraft:brown_terracotta
fill 31 251 354 31 253 354 minecraft:brown_terracotta
setblock 31 251 363 minecraft:honeycomb_block
setblock 32 251 363 minecraft:yellow_terracotta
fill 33 251 363 36 251 363 minecraft:honeycomb_block
fill 36 251 337 36 252 337 minecraft:yellow_terracotta
fill 37 251 336 37 252 336 minecraft:yellow_terracotta
fill 37 251 338 37 252 338 minecraft:yellow_terracotta
setblock 37 251 362 minecraft:honeycomb_block
setblock 37 251 363 minecraft:yellow_terracotta
fill 38 251 337 38 252 337 minecraft:yellow_terracotta
setblock 38 251 362 minecraft:yellow_terracotta
fill 38 251 363 38 254 363 minecraft:honeycomb_block
setblock 39 251 323 minecraft:honey_block
setblock 39 251 335 minecraft:honeycomb_block
setblock 39 251 336 minecraft:yellow_terracotta
fill 39 251 337 39 251 340 minecraft:honeycomb_block
setblock 39 251 341 minecraft:yellow_terracotta
fill 39 251 342 39 253 343 minecraft:honeycomb_block
setblock 39 251 356 minecraft:yellow_terracotta
fill 39 251 357 39 252 359 minecraft:honeycomb_block
fill 39 251 362 39 254 362 minecraft:honeycomb_block
setblock 40 251 335 minecraft:yellow_terracotta
fill 40 251 336 40 254 336 minecraft:honeycomb_block
setblock 40 251 340 minecraft:yellow_terracotta
fill 40 251 341 40 254 341 minecraft:honeycomb_block
setblock 40 251 345 minecraft:yellow_terracotta
fill 40 251 346 40 254 346 minecraft:honeycomb_block
setblock 40 251 350 minecraft:yellow_terracotta
fill 40 251 351 40 254 351 minecraft:honeycomb_block
setblock 40 251 355 minecraft:yellow_terracotta
fill 40 251 356 40 254 356 minecraft:honeycomb_block
setblock 40 251 360 minecraft:yellow_terracotta
fill 40 251 361 40 254 361 minecraft:honeycomb_block
setblock 41 251 329 minecraft:yellow_terracotta
fill 41 251 330 41 254 330 minecraft:honeycomb_block
setblock 41 251 334 minecraft:yellow_terracotta
fill 41 251 335 41 254 335 minecraft:honeycomb_block
setblock 41 251 339 minecraft:yellow_terracotta
fill 41 251 340 41 254 340 minecraft:honeycomb_block
setblock 41 251 344 minecraft:yellow_terracotta
fill 41 251 345 41 254 345 minecraft:honeycomb_block
setblock 41 251 349 minecraft:yellow_terracotta
fill 41 251 350 41 254 350 minecraft:honeycomb_block
setblock 41 251 354 minecraft:yellow_terracotta
fill 41 251 355 41 254 355 minecraft:honeycomb_block
setblock 41 251 359 minecraft:yellow_terracotta
fill 41 251 360 41 254 360 minecraft:honeycomb_block
fill 42 251 344 42 272 344 minecraft:honeycomb_block
setblock 1 252 323 minecraft:yellow_terracotta
fill 1 252 324 4 252 324 minecraft:honeycomb_block
setblock 1 252 328 minecraft:yellow_terracotta
fill 1 252 329 1 255 329 minecraft:honeycomb_block
setblock 1 252 333 minecraft:yellow_terracotta
fill 1 252 334 1 255 334 minecraft:honeycomb_block
setblock 1 252 338 minecraft:yellow_terracotta
fill 1 252 339 1 255 339 minecraft:honeycomb_block
setblock 1 252 343 minecraft:yellow_terracotta
fill 1 252 344 1 255 344 minecraft:honeycomb_block
setblock 1 252 348 minecraft:yellow_terracotta
fill 1 252 349 1 255 349 minecraft:honeycomb_block
setblock 1 252 353 minecraft:yellow_terracotta
fill 1 252 354 1 255 354 minecraft:honeycomb_block
setblock 1 252 358 minecraft:yellow_terracotta
fill 1 252 359 1 255 359 minecraft:honeycomb_block
setblock 1 252 362 minecraft:honeycomb_block
setblock 1 252 363 minecraft:yellow_terracotta
fill 2 252 323 2 255 323 minecraft:honeycomb_block
fill 2 252 325 2 252 326 minecraft:honeycomb_block
setblock 2 252 327 minecraft:yellow_terracotta
fill 2 252 328 2 255 328 minecraft:honeycomb_block
setblock 2 252 332 minecraft:yellow_terracotta
fill 2 252 333 2 255 333 minecraft:honeycomb_block
setblock 2 252 337 minecraft:yellow_terracotta
fill 2 252 338 2 255 338 minecraft:honeycomb_block
setblock 2 252 341 minecraft:honeycomb_block
setblock 2 252 342 minecraft:yellow_terracotta
fill 2 252 343 2 255 343 minecraft:honeycomb_block
setblock 2 252 357 minecraft:yellow_terracotta
fill 2 252 358 2 255 358 minecraft:honeycomb_block
setblock 2 252 361 minecraft:honeycomb_block
setblock 2 252 362 minecraft:yellow_terracotta
fill 2 252 363 2 255 363 minecraft:honeycomb_block
fill 3 252 332 3 253 332 minecraft:honeycomb_block
setblock 3 252 336 minecraft:yellow_terracotta
fill 3 252 337 3 255 337 minecraft:honeycomb_block
setblock 3 252 341 minecraft:yellow_terracotta
fill 3 252 342 3 255 342 minecraft:honeycomb_block
fill 3 252 362 4 254 362 minecraft:honeycomb_block
fill 4 252 363 5 252 363 minecraft:honeycomb_block
setblock 5 252 323 minecraft:honeycomb_block
setblock 6 252 323 minecraft:yellow_terracotta
fill 6 252 356 6 253 357 minecraft:brown_terracotta
setblock 6 252 363 minecraft:yellow_terracotta
fill 7 252 323 7 255 323 minecraft:honeycomb_block
fill 7 252 363 10 252 363 minecraft:honeycomb_block
fill 9 252 323 10 252 323 minecraft:honeycomb_block
setblock 11 252 323 minecraft:yellow_terracotta
setblock 11 252 363 minecraft:yellow_terracotta
fill 12 252 323 12 255 323 minecraft:honeycomb_block
fill 12 252 363 12 255 363 minecraft:honeycomb_block
fill 13 252 362 14 254 362 minecraft:honeycomb_block
setblock 16 252 323 minecraft:yellow_terracotta
fill 16 252 324 19 252 324 minecraft:honeycomb_block
fill 16 252 361 16 252 362 minecraft:honeycomb_block
setblock 16 252 363 minecraft:yellow_terracotta
fill 17 252 323 17 255 323 minecraft:honeycomb_block
setblock 17 252 361 minecraft:honeycomb_block
setblock 17 252 362 minecraft:yellow_terracotta
fill 17 252 363 17 255 363 minecraft:honeycomb_block
setblock 18 252 360 minecraft:honeycomb_block
setblock 18 252 361 minecraft:yellow_terracotta
fill 18 252 362 18 255 362 minecraft:honeycomb_block
setblock 19 252 360 minecraft:yellow_terracotta
fill 19 252 361 19 255 361 minecraft:honeycomb_block
setblock 20 252 324 minecraft:yellow_terracotta
fill 20 252 360 20 255 360 minecraft:honeycomb_block
setblock 21 252 323 minecraft:yellow_terracotta
fill 21 252 324 21 255 324 minecraft:honeycomb_block
fill 21 252 357 21 253 357 minecraft:brown_terracotta
setblock 21 252 363 minecraft:yellow_terracotta
fill 22 252 323 22 255 323 minecraft:honeycomb_block
setblock 22 252 362 minecraft:yellow_terracotta
fill 22 252 363 22 255 363 minecraft:honeycomb_block
setblock 23 252 361 minecraft:yellow_terracotta
fill 23 252 362 23 255 362 minecraft:honeycomb_block
setblock 24 252 360 minecraft:yellow_terracotta
fill 24 252 361 24 255 361 minecraft:honeycomb_block
fill 25 252 352 25 253 352 minecraft:brown_terracotta
fill 25 252 360 25 253 360 minecraft:honeycomb_block
setblock 26 252 323 minecraft:yellow_terracotta
fill 26 252 350 26 253 350 minecraft:brown_terracotta
fill 26 252 357 26 253 357 minecraft:brown_terracotta
setblock 26 252 363 minecraft:yellow_terracotta
setblock 27 252 362 minecraft:yellow_terracotta
fill 27 252 363 27 255 363 minecraft:honeycomb_block
fill 28 252 349 30 253 349 minecraft:brown_terracotta
fill 28 252 362 28 255 362 minecraft:honeycomb_block
fill 29 252 328 29 253 328 minecraft:brown_terracotta
fill 29 252 356 29 253 356 minecraft:brown_terracotta
fill 30 252 362 30 253 362 minecraft:honeycomb_block
fill 31 252 350 31 253 350 minecraft:brown_terracotta
fill 31 252 355 31 253 355 minecraft:brown_terracotta
setblock 31 252 363 minecraft:yellow_terracotta
fill 32 252 351 32 253 353 minecraft:brown_terracotta
fill 32 252 363 35 252 363 minecraft:honeycomb_block
setblock 33 252 323 minecraft:honey_block
fill 35 252 331 35 253 331 minecraft:brown_terracotta
fill 35 252 333 35 253 333 minecraft:brown_terracotta
fill 35 252 357 35 253 357 minecraft:brown_terracotta
fill 35 252 362 36 252 362 minecraft:honeycomb_block
setblock 36 252 336 minecraft:yellow_terracotta
setblock 36 252 338 minecraft:yellow_terracotta
setblock 36 252 363 minecraft:yellow_terracotta
setblock 37 252 362 minecraft:yellow_terracotta
fill 37 252 363 37 255 363 minecraft:honeycomb_block
setblock 38 252 336 minecraft:yellow_terracotta
setblock 38 252 338 minecraft:yellow_terracotta
fill 38 252 362 38 255 362 minecraft:honeycomb_block
fill 39 252 323 40 252 323 minecraft:honeycomb_block
setblock 39 252 335 minecraft:yellow_terracotta
fill 39 252 336 39 252 339 minecraft:honeycomb_block
setblock 39 252 340 minecraft:yellow_terracotta
fill 39 252 341 39 255 341 minecraft:honeycomb_block
setblock 39 252 344 minecraft:honeycomb_block
setblock 39 252 345 minecraft:yellow_terracotta
fill 39 252 356 39 254 356 minecraft:honeycomb_block
setblock 39 252 360 minecraft:yellow_terracotta
fill 39 252 361 39 255 361 minecraft:honeycomb_block
setblock 40 252 334 minecraft:yellow_terracotta
fill 40 252 335 40 255 335 minecraft:honeycomb_block
setblock 40 252 339 minecraft:yellow_terracotta
fill 40 252 340 40 255 340 minecraft:honeycomb_block
setblock 40 252 343 minecraft:honeycomb_block
setblock 40 252 344 minecraft:yellow_terracotta
fill 40 252 345 40 255 345 minecraft:honeycomb_block
fill 40 252 347 40 252 348 minecraft:honeycomb_block
setblock 40 252 349 minecraft:yellow_terracotta
fill 40 252 350 40 255 350 minecraft:honeycomb_block
setblock 40 252 354 minecraft:yellow_terracotta
fill 40 252 355 40 255 355 minecraft:honeycomb_block
setblock 40 252 359 minecraft:yellow_terracotta
fill 40 252 360 40 255 360 minecraft:honeycomb_block
setblock 41 252 323 minecraft:yellow_terracotta
fill 41 252 324 41 254 325 minecraft:honeycomb_block
setblock 41 252 327 minecraft:honeycomb_block
setblock 41 252 328 minecraft:yellow_terracotta
fill 41 252 329 41 255 329 minecraft:honeycomb_block
setblock 41 252 333 minecraft:yellow_terracotta
fill 41 252 334 41 255 334 minecraft:honeycomb_block
setblock 41 252 338 minecraft:yellow_terracotta
fill 41 252 339 41 255 339 minecraft:honeycomb_block
setblock 41 252 343 minecraft:yellow_terracotta
fill 41 252 344 41 255 344 minecraft:honeycomb_block
setblock 41 252 348 minecraft:yellow_terracotta
fill 41 252 349 41 255 349 minecraft:honeycomb_block
setblock 41 252 353 minecraft:yellow_terracotta
fill 41 252 354 41 255 354 minecraft:honeycomb_block
setblock 41 252 358 minecraft:yellow_terracotta
fill 41 252 359 41 255 359 minecraft:honeycomb_block
setblock 41 252 363 minecraft:yellow_terracotta
setblock 42 252 356 minecraft:yellow_concrete
fill 1 253 323 1 255 324 minecraft:honeycomb_block
setblock 1 253 327 minecraft:yellow_terracotta
fill 1 253 328 1 256 328 minecraft:honeycomb_block
setblock 1 253 332 minecraft:yellow_terracotta
fill 1 253 333 1 256 333 minecraft:honeycomb_block
setblock 1 253 337 minecraft:yellow_terracotta
fill 1 253 338 1 256 338 minecraft:honeycomb_block
setblock 1 253 342 minecraft:yellow_terracotta
fill 1 253 343 1 256 343 minecraft:honeycomb_block
setblock 1 253 347 minecraft:yellow_terracotta
fill 1 253 348 1 256 348 minecraft:honeycomb_block
setblock 1 253 352 minecraft:yellow_terracotta
fill 1 253 353 1 255 353 minecraft:honeycomb_block
setblock 1 253 357 minecraft:yellow_terracotta
fill 1 253 358 1 256 358 minecraft:honeycomb_block
setblock 1 253 362 minecraft:yellow_terracotta
fill 1 253 363 1 256 363 minecraft:honeycomb_block
fill 2 253 324 2 253 325 minecraft:honeycomb_block
setblock 2 253 326 minecraft:yellow_terracotta
fill 2 253 327 2 256 327 minecraft:honeycomb_block
setblock 2 253 331 minecraft:yellow_terracotta
fill 2 253 332 2 256 332 minecraft:honeycomb_block
setblock 2 253 336 minecraft:yellow_terracotta
fill 2 253 337 2 256 337 minecraft:honeycomb_block
setblock 2 253 341 minecraft:yellow_terracotta
fill 2 253 342 2 256 342 minecraft:honeycomb_block
setblock 2 253 346 minecraft:yellow_terracotta
setblock 2 253 357 minecraft:honeycomb_block
setblock 2 253 361 minecraft:yellow_terracotta
fill 2 253 362 2 256 362 minecraft:honeycomb_block
setblock 3 253 324 minecraft:honeycomb_block
setblock 3 253 335 minecraft:yellow_terracotta
fill 3 253 336 3 256 336 minecraft:honeycomb_block
setblock 3 253 340 minecraft:yellow_terracotta
fill 3 253 341 3 256 341 minecraft:honeycomb_block
fill 3 253 343 3 254 343 minecraft:honeycomb_block
setblock 4 253 324 minecraft:yellow_terracotta
setblock 4 253 363 minecraft:honeycomb_block
setblock 5 253 323 minecraft:yellow_terracotta
fill 5 253 324 5 256 324 minecraft:honeycomb_block
fill 5 253 356 5 254 357 minecraft:brown_terracotta
setblock 5 253 362 minecraft:honeycomb_block
setblock 5 253 363 minecraft:yellow_terracotta
fill 6 253 323 6 256 323 minecraft:honeycomb_block
setblock 6 253 362 minecraft:yellow_terracotta
fill 6 253 363 9 253 363 minecraft:honeycomb_block
setblock 9 253 323 minecraft:honeycomb_block
setblock 10 253 323 minecraft:yellow_terracotta
setblock 10 253 363 minecraft:yellow_terracotta
fill 11 253 323 11 256 323 minecraft:honeycomb_block
setblock 11 253 362 minecraft:yellow_terracotta
fill 11 253 363 11 256 363 minecraft:honeycomb_block
fill 12 253 362 12 256 362 minecraft:honeycomb_block
fill 13 253 323 14 253 323 minecraft:honeycomb_block
setblock 14 253 324 minecraft:yellow_terracotta
fill 14 253 361 16 253 361 minecraft:honeycomb_block
setblock 14 253 363 minecraft:honeycomb_block
setblock 15 253 323 minecraft:yellow_terracotta
fill 15 253 324 18 253 324 minecraft:honeycomb_block
setblock 15 253 363 minecraft:yellow_terracotta
fill 16 253 323 16 256 323 minecraft:honeycomb_block
setblock 16 253 362 minecraft:yellow_terracotta
fill 16 253 363 16 256 363 minecraft:honeycomb_block
setblock 17 253 360 minecraft:honeycomb_block
setblock 17 253 361 minecraft:yellow_terracotta
fill 17 253 362 17 256 362 minecraft:honeycomb_block
setblock 18 253 360 minecraft:yellow_terracotta
fill 18 253 361 18 256 361 minecraft:honeycomb_block
setblock 19 253 324 minecraft:yellow_terracotta
fill 19 253 360 19 256 360 minecraft:honeycomb_block
setblock 20 253 323 minecraft:yellow_terracotta
fill 20 253 324 20 256 324 minecraft:honeycomb_block
setblock 20 253 363 minecraft:yellow_terracotta
fill 21 253 323 21 256 323 minecraft:honeycomb_block
fill 21 253 358 21 254 358 minecraft:brown_terracotta
setblock 21 253 362 minecraft:yellow_terracotta
fill 21 253 363 21 256 363 minecraft:honeycomb_block
setblock 22 253 361 minecraft:yellow_terracotta
fill 22 253 362 22 256 362 minecraft:honeycomb_block
setblock 23 253 324 minecraft:honeycomb_block
setblock 23 253 360 minecraft:yellow_terracotta
fill 23 253 361 23 256 361 minecraft:honeycomb_block
fill 24 253 360 24 255 360 minecraft:honeycomb_block
setblock 25 253 323 minecraft:yellow_terracotta
setblock 25 253 351 minecraft:brown_terracotta
fill 25 253 353 25 253 354 minecraft:brown_terracotta
setblock 25 253 363 minecraft:yellow_terracotta
fill 26 253 323 26 256 323 minecraft:honeycomb_block
setblock 26 253 355 minecraft:brown_terracotta
fill 26 253 358 26 254 358 minecraft:brown_terracotta
setblock 26 253 362 minecraft:yellow_terracotta
fill 26 253 363 26 256 363 minecraft:honeycomb_block
setblock 27 253 323 minecraft:honey_block
setblock 27 253 349 minecraft:brown_terracotta
fill 27 253 356 28 253 356 minecraft:brown_terracotta
setblock 27 253 361 minecraft:yellow_terracotta
fill 27 253 362 27 256 362 minecraft:honeycomb_block
fill 29 253 327 29 254 327 minecraft:brown_terracotta
setblock 30 253 356 minecraft:brown_terracotta
setblock 30 253 363 minecraft:yellow_terracotta
setblock 31 253 349 minecraft:brown_terracotta
setblock 31 253 362 minecraft:yellow_terracotta
fill 31 253 363 34 253 363 minecraft:honeycomb_block
setblock 32 253 350 minecraft:brown_terracotta
setblock 32 253 354 minecraft:brown_terracotta
fill 32 253 362 35 253 362 minecraft:honeycomb_block
setblock 35 253 363 minecraft:yellow_terracotta
fill 36 253 331 36 254 331 minecraft:brown_terracotta
fill 36 253 333 36 254 333 minecraft:brown_terracotta
fill 36 253 357 36 254 357 minecraft:brown_terracotta
setblock 36 253 362 minecraft:yellow_terracotta
fill 36 253 363 36 256 363 minecraft:honeycomb_block
fill 37 253 323 39 253 323 minecraft:honeycomb_block
setblock 37 253 361 minecraft:yellow_terracotta
fill 37 253 362 37 256 362 minecraft:honeycomb_block
fill 38 253 337 38 253 339 minecraft:honeycomb_block
setblock 38 253 340 minecraft:yellow_terracotta
fill 38 253 341 38 254 343 minecraft:honeycomb_block
fill 38 253 361 38 256 361 minecraft:honeycomb_block
setblock 39 253 334 minecraft:yellow_terracotta
fill 39 253 335 39 253 338 minecraft:honeycomb_block
setblock 39 253 339 minecraft:yellow_terracotta
fill 39 253 340 39 256 340 minecraft:honeycomb_block
setblock 39 253 344 minecraft:yellow_terracotta
fill 39 253 345 39 254 347 minecraft:honeycomb_block
fill 39 253 357 39 253 358 minecraft:honeycomb_block
setblock 39 253 359 minecraft:yellow_terracotta
fill 39 253 360 39 256 360 minecraft:honeycomb_block
setblock 40 253 323 minecraft:yellow_terracotta
fill 40 253 331 40 254 331 minecraft:honeycomb_block
setblock 40 253 333 minecraft:yellow_terracotta
fill 40 253 334 40 256 334 minecraft:honeycomb_block
setblock 40 253 338 minecraft:yellow_terracotta
fill 40 253 339 40 256 339 minecraft:honeycomb_block
setblock 40 253 343 minecraft:yellow_terracotta
fill 40 253 344 40 256 344 minecraft:honeycomb_block
setblock 40 253 347 minecraft:honeycomb_block
setblock 40 253 348 minecraft:yellow_terracotta
fill 40 253 349 40 256 349 minecraft:honeycomb_block
setblock 40 253 353 minecraft:yellow_terracotta
fill 40 253 354 40 256 354 minecraft:honeycomb_block
setblock 40 253 358 minecraft:yellow_terracotta
fill 40 253 359 40 256 359 minecraft:honeycomb_block
fill 40 253 363 40 253 364 minecraft:yellow_terracotta
fill 41 253 323 41 256 323 minecraft:honeycomb_block
setblock 41 253 326 minecraft:honeycomb_block
setblock 41 253 327 minecraft:yellow_terracotta
fill 41 253 328 41 256 328 minecraft:honeycomb_block
setblock 41 253 332 minecraft:yellow_terracotta
fill 41 253 333 41 256 333 minecraft:honeycomb_block
setblock 41 253 337 minecraft:yellow_terracotta
fill 41 253 338 41 256 338 minecraft:honeycomb_block
setblock 41 253 342 minecraft:yellow_terracotta
fill 41 253 343 41 256 343 minecraft:honeycomb_block
setblock 41 253 347 minecraft:yellow_terracotta
fill 41 253 348 41 256 348 minecraft:honeycomb_block
setblock 41 253 352 minecraft:yellow_terracotta
fill 41 253 353 41 256 353 minecraft:honeycomb_block
setblock 41 253 357 minecraft:yellow_terracotta
fill 41 253 358 41 256 358 minecraft:honeycomb_block
setblock 41 253 362 minecraft:yellow_terracotta
fill 41 253 363 41 256 363 minecraft:honeycomb_block
setblock 42 253 352 minecraft:orange_terracotta
fill 42 253 356 42 259 356 minecraft:honeycomb_block
setblock 1 254 326 minecraft:yellow_terracotta
fill 1 254 327 1 257 327 minecraft:honeycomb_block
setblock 1 254 331 minecraft:yellow_terracotta
fill 1 254 332 1 257 332 minecraft:honeycomb_block
setblock 1 254 336 minecraft:yellow_terracotta
fill 1 254 337 1 257 337 minecraft:honeycomb_block
setblock 1 254 341 minecraft:yellow_terracotta
fill 1 254 342 1 257 342 minecraft:honeycomb_block
setblock 1 254 345 minecraft:honeycomb_block
setblock 1 254 346 minecraft:yellow_terracotta
fill 1 254 347 1 257 347 minecraft:honeycomb_block
setblock 1 254 351 minecraft:yellow_terracotta
fill 1 254 352 1 255 352 minecraft:honeycomb_block
setblock 1 254 356 minecraft:yellow_terracotta
fill 1 254 357 1 257 357 minecraft:honeycomb_block
setblock 1 254 361 minecraft:yellow_terracotta
fill 1 254 362 1 257 362 minecraft:honeycomb_block
setblock 2 254 324 minecraft:honeycomb_block
setblock 2 254 325 minecraft:yellow_terracotta
fill 2 254 326 2 257 326 minecraft:honeycomb_block
setblock 2 254 330 minecraft:yellow_terracotta
fill 2 254 331 2 257 331 minecraft:honeycomb_block
setblock 2 254 335 minecraft:yellow_terracotta
fill 2 254 336 2 257 336 minecraft:honeycomb_block
setblock 2 254 340 minecraft:yellow_terracotta
fill 2 254 341 2 257 341 minecraft:honeycomb_block
setblock 2 254 345 minecraft:yellow_terracotta
fill 2 254 346 2 257 346 minecraft:honeycomb_block
setblock 2 254 360 minecraft:yellow_terracotta
fill 2 254 361 2 257 361 minecraft:honeycomb_block
setblock 3 254 324 minecraft:yellow_terracotta
setblock 3 254 325 minecraft:light[level=12]
setblock 3 254 332 minecraft:light[level=12]
setblock 3 254 334 minecraft:yellow_terracotta
fill 3 254 335 3 255 335 minecraft:honeycomb_block
setblock 3 254 339 minecraft:yellow_terracotta
fill 3 254 340 3 257 340 minecraft:honeycomb_block
setblock 3 254 346 minecraft:light[level=12]
setblock 3 254 353 minecraft:light[level=12]
setblock 3 254 360 minecraft:light[level=12]
setblock 4 254 323 minecraft:yellow_terracotta
fill 4 254 324 4 257 324 minecraft:honeycomb_block
fill 4 254 356 4 255 357 minecraft:brown_terracotta
setblock 4 254 363 minecraft:yellow_terracotta
fill 5 254 323 5 257 323 minecraft:honeycomb_block
setblock 5 254 362 minecraft:yellow_terracotta
fill 5 254 363 8 254 363 minecraft:honeycomb_block
fill 6 254 324 7 254 324 minecraft:honeycomb_block
fill 6 254 362 7 256 362 minecraft:honeycomb_block
setblock 9 254 323 minecraft:yellow_terracotta
setblock 9 254 362 minecraft:honeycomb_block
setblock 9 254 363 minecraft:yellow_terracotta
fill 10 254 323 10 257 323 minecraft:honeycomb_block
setblock 10 254 325 minecraft:light[level=12]
setblock 10 254 332 minecraft:light[level=12]
setblock 10 254 346 minecraft:light[level=12]
setblock 10 254 353 minecraft:light[level=12]
setblock 10 254 360 minecraft:light[level=12]
setblock 10 254 362 minecraft:yellow_terracotta
fill 10 254 363 10 257 363 minecraft:honeycomb_block
fill 11 254 362 11 257 362 minecraft:honeycomb_block
setblock 12 254 324 minecraft:honeycomb_block
setblock 13 254 323 minecraft:honeycomb_block
setblock 13 254 324 minecraft:yellow_terracotta
fill 13 254 361 15 254 361 minecraft:honeycomb_block
setblock 14 254 323 minecraft:yellow_terracotta
fill 14 254 324 17 254 324 minecraft:honeycomb_block
setblock 14 254 363 minecraft:yellow_terracotta
fill 15 254 323 15 257 323 minecraft:honeycomb_block
fill 15 254 355 16 255 355 minecraft:honey_block
setblock 15 254 362 minecraft:yellow_terracotta
fill 15 254 363 15 257 363 minecraft:honeycomb_block
fill 16 254 354 16 255 354 minecraft:honey_block
setblock 16 254 360 minecraft:honeycomb_block
setblock 16 254 361 minecraft:yellow_terracotta
fill 16 254 362 16 257 362 minecraft:honeycomb_block
setblock 17 254 325 minecraft:light[level=12]
setblock 17 254 332 minecraft:light[level=12]
setblock 17 254 339 minecraft:light[level=12]
setblock 17 254 346 minecraft:light[level=12]
setblock 17 254 353 minecraft:light[level=12]
setblock 17 254 360 minecraft:yellow_terracotta
fill 17 254 361 17 257 361 minecraft:honeycomb_block
setblock 18 254 324 minecraft:yellow_terracotta
fill 18 254 360 18 257 360 minecraft:honeycomb_block
setblock 19 254 323 minecraft:yellow_terracotta
fill 19 254 324 19 257 324 minecraft:honeycomb_block
setblock 19 254 363 minecraft:yellow_terracotta
fill 20 254 323 20 257 323 minecraft:honeycomb_block
setblock 20 254 362 minecraft:yellow_terracotta
fill 20 254 363 20 257 363 minecraft:honeycomb_block
fill 21 254 359 21 255 359 minecraft:brown_terracotta
setblock 21 254 361 minecraft:yellow_terracotta
fill 21 254 362 21 257 362 minecraft:honeycomb_block
setblock 22 254 360 minecraft:yellow_terracotta
fill 22 254 361 22 257 361 minecraft:honeycomb_block
setblock 23 254 324 minecraft:yellow_terracotta
fill 23 254 360 23 256 360 minecraft:honeycomb_block
setblock 24 254 323 minecraft:yellow_terracotta
setblock 24 254 325 minecraft:light[level=12]
setblock 24 254 332 minecraft:light[level=12]
setblock 24 254 339 minecraft:light[level=12]
setblock 24 254 346 minecraft:light[level=12]
setblock 24 254 353 minecraft:light[level=12]
setblock 24 254 363 minecraft:yellow_terracotta
fill 25 254 323 25 257 323 minecraft:honeycomb_block
setblock 25 254 362 minecraft:yellow_terracotta
fill 25 254 363 25 257 363 minecraft:honeycomb_block
fill 26 254 359 26 255 359 minecraft:brown_terracotta
setblock 26 254 361 minecraft:yellow_terracotta
fill 26 254 362 26 257 362 minecraft:honeycomb_block
fill 27 254 361 27 255 361 minecraft:honeycomb_block
fill 29 254 326 29 255 326 minecraft:brown_terracotta
fill 29 254 352 29 256 352 minecraft:yellow_terracotta
setblock 29 254 363 minecraft:yellow_terracotta
setblock 30 254 362 minecraft:yellow_terracotta
fill 30 254 363 33 254 363 minecraft:honeycomb_block
setblock 31 254 325 minecraft:light[level=12]
setblock 31 254 332 minecraft:light[level=12]
setblock 31 254 339 minecraft:light[level=12]
setblock 31 254 346 minecraft:light[level=12]
setblock 31 254 353 minecraft:light[level=12]
setblock 31 254 360 minecraft:light[level=12]
fill 31 254 362 34 254 362 minecraft:honeycomb_block
setblock 34 254 363 minecraft:yellow_terracotta
fill 35 254 323 38 254 323 minecraft:honeycomb_block
fill 35 254 340 37 255 340 minecraft:yellow_concrete
setblock 35 254 361 minecraft:honeycomb_block
setblock 35 254 362 minecraft:yellow_terracotta
fill 35 254 363 35 257 363 minecraft:honeycomb_block
fill 36 254 339 36 255 339 minecraft:yellow_concrete
fill 36 254 341 36 255 341 minecraft:yellow_concrete
setblock 36 254 361 minecraft:yellow_terracotta
fill 36 254 362 36 257 362 minecraft:honeycomb_block
fill 37 254 331 37 255 331 minecraft:brown_terracotta
fill 37 254 333 37 255 333 minecraft:brown_terracotta
fill 37 254 357 37 255 357 minecraft:brown_terracotta
fill 37 254 361 37 257 361 minecraft:honeycomb_block
setblock 38 254 325 minecraft:light[level=12]
setblock 38 254 332 minecraft:light[level=12]
fill 38 254 337 38 254 338 minecraft:honeycomb_block
setblock 38 254 339 minecraft:yellow_terracotta
fill 38 254 340 38 257 340 minecraft:honeycomb_block
setblock 38 254 344 minecraft:yellow_terracotta
fill 38 254 345 38 257 345 minecraft:honeycomb_block
setblock 38 254 346 minecraft:light[level=12]
setblock 38 254 353 minecraft:light[level=12]
setblock 38 254 360 minecraft:light[level=12]
setblock 39 254 323 minecraft:yellow_terracotta
fill 39 254 334 39 254 337 minecraft:honeycomb_block
setblock 39 254 338 minecraft:yellow_terracotta
fill 39 254 339 39 257 339 minecraft:honeycomb_block
setblock 39 254 342 minecraft:honeycomb_block
setblock 39 254 343 minecraft:yellow_terracotta
fill 39 254 344 39 257 344 minecraft:honeycomb_block
setblock 39 254 348 minecraft:yellow_terracotta
setblock 39 254 357 minecraft:honeycomb_block
setblock 39 254 358 minecraft:yellow_terracotta
fill 39 254 359 39 256 359 minecraft:honeycomb_block
setblock 39 254 363 minecraft:yellow_terracotta
fill 40 254 323 40 256 324 minecraft:honeycomb_block
setblock 40 254 332 minecraft:yellow_terracotta
fill 40 254 333 40 257 333 minecraft:honeycomb_block
setblock 40 254 337 minecraft:yellow_terracotta
fill 40 254 338 40 257 338 minecraft:honeycomb_block
setblock 40 254 342 minecraft:yellow_terracotta
fill 40 254 343 40 257 343 minecraft:honeycomb_block
setblock 40 254 347 minecraft:yellow_terracotta
fill 40 254 348 40 257 348 minecraft:honeycomb_block
setblock 40 254 352 minecraft:yellow_terracotta
fill 40 254 353 40 256 353 minecraft:honeycomb_block
setblock 40 254 357 minecraft:yellow_terracotta
fill 40 254 358 40 257 358 minecraft:honeycomb_block
setblock 40 254 362 minecraft:yellow_terracotta
fill 40 254 363 40 257 364 minecraft:honeycomb_block
setblock 41 254 326 minecraft:yellow_terracotta
fill 41 254 327 41 257 327 minecraft:honeycomb_block
setblock 41 254 331 minecraft:yellow_terracotta
fill 41 254 332 41 257 332 minecraft:honeycomb_block
setblock 41 254 336 minecraft:yellow_terracotta
fill 41 254 337 41 257 337 minecraft:honeycomb_block
setblock 41 254 341 minecraft:yellow_terracotta
fill 41 254 342 41 257 342 minecraft:honeycomb_block
setblock 41 254 346 minecraft:yellow_terracotta
fill 41 254 347 41 257 347 minecraft:honeycomb_block
setblock 41 254 351 minecraft:yellow_terracotta
fill 41 254 352 42 257 352 minecraft:honeycomb_block
setblock 41 254 356 minecraft:yellow_terracotta
fill 41 254 357 41 257 357 minecraft:honeycomb_block
setblock 41 254 361 minecraft:yellow_terracotta
fill 41 254 362 41 257 362 minecraft:honeycomb_block
setblock 1 255 325 minecraft:yellow_terracotta
fill 1 255 326 1 258 326 minecraft:honeycomb_block
setblock 1 255 330 minecraft:yellow_terracotta
fill 1 255 331 1 258 331 minecraft:honeycomb_block
setblock 1 255 335 minecraft:yellow_terracotta
fill 1 255 336 1 258 336 minecraft:honeycomb_block
setblock 1 255 340 minecraft:yellow_terracotta
fill 1 255 341 1 258 341 minecraft:honeycomb_block
setblock 1 255 345 minecraft:yellow_terracotta
fill 1 255 346 1 258 346 minecraft:honeycomb_block
setblock 1 255 350 minecraft:yellow_terracotta
setblock 1 255 351 minecraft:honeycomb_block
setblock 1 255 355 minecraft:yellow_terracotta
fill 1 255 356 1 256 356 minecraft:honeycomb_block
setblock 1 255 360 minecraft:yellow_terracotta
fill 1 255 361 1 258 361 minecraft:honeycomb_block
setblock 2 255 324 minecraft:yellow_terracotta
fill 2 255 325 2 258 325 minecraft:honeycomb_block
setblock 2 255 329 minecraft:yellow_terracotta
fill 2 255 330 2 258 330 minecraft:honeycomb_block
setblock 2 255 334 minecraft:yellow_terracotta
fill 2 255 335 2 258 335 minecraft:honeycomb_block
setblock 2 255 339 minecraft:yellow_terracotta
fill 2 255 340 2 258 340 minecraft:honeycomb_block
setblock 2 255 344 minecraft:yellow_terracotta
fill 2 255 345 2 258 345 minecraft:honeycomb_block
setblock 2 255 359 minecraft:yellow_terracotta
fill 2 255 360 2 257 360 minecraft:honeycomb_block
setblock 3 255 323 minecraft:yellow_terracotta
fill 3 255 324 3 258 324 minecraft:honeycomb_block
setblock 3 255 334 minecraft:honeycomb_block
setblock 3 255 338 minecraft:yellow_terracotta
fill 3 255 339 3 257 339 minecraft:honeycomb_block
setblock 3 255 343 minecraft:yellow_terracotta
fill 3 255 356 3 256 357 minecraft:brown_terracotta
setblock 3 255 362 minecraft:honeycomb_block
fill 3 255 363 3 255 364 minecraft:yellow_terracotta
fill 4 255 323 4 258 323 minecraft:honeycomb_block
setblock 4 255 362 minecraft:yellow_terracotta
fill 4 255 363 7 255 363 minecraft:honeycomb_block
fill 5 255 362 5 257 362 minecraft:honeycomb_block
setblock 6 255 324 minecraft:honeycomb_block
setblock 7 255 324 minecraft:yellow_terracotta
setblock 8 255 323 minecraft:yellow_terracotta
fill 8 255 324 11 255 324 minecraft:honeycomb_block
setblock 8 255 362 minecraft:honeycomb_block
setblock 8 255 363 minecraft:yellow_terracotta
fill 9 255 323 9 258 323 minecraft:honeycomb_block
setblock 9 255 362 minecraft:yellow_terracotta
fill 9 255 363 9 258 363 minecraft:honeycomb_block
fill 10 255 362 10 258 362 minecraft:honeycomb_block
setblock 12 255 324 minecraft:yellow_terracotta
setblock 13 255 323 minecraft:yellow_terracotta
fill 13 255 324 16 255 324 minecraft:honeycomb_block
fill 13 255 361 13 255 362 minecraft:honeycomb_block
setblock 13 255 363 minecraft:yellow_terracotta
fill 14 255 323 14 258 323 minecraft:honeycomb_block
setblock 14 255 361 minecraft:honeycomb_block
setblock 14 255 362 minecraft:yellow_terracotta
fill 14 255 363 14 258 363 minecraft:honeycomb_block
setblock 15 255 360 minecraft:honeycomb_block
setblock 15 255 361 minecraft:yellow_terracotta
fill 15 255 362 15 258 362 minecraft:honeycomb_block
setblock 16 255 325 minecraft:yellow_terracotta
setblock 16 255 360 minecraft:yellow_terracotta
fill 16 255 361 16 258 361 minecraft:honeycomb_block
setblock 17 255 324 minecraft:yellow_terracotta
fill 17 255 325 20 255 325 minecraft:honeycomb_block
fill 17 255 360 17 258 360 minecraft:honeycomb_block
setblock 18 255 323 minecraft:yellow_terracotta
fill 18 255 324 18 258 324 minecraft:honeycomb_block
setblock 18 255 363 minecraft:yellow_terracotta
fill 19 255 323 19 258 323 minecraft:honeycomb_block
setblock 19 255 362 minecraft:yellow_terracotta
fill 19 255 363 19 258 363 minecraft:honeycomb_block
setblock 20 255 361 minecraft:yellow_terracotta
fill 20 255 362 20 258 362 minecraft:honeycomb_block
setblock 21 255 360 minecraft:yellow_terracotta
fill 21 255 361 21 258 361 minecraft:honeycomb_block
setblock 22 255 324 minecraft:yellow_terracotta
fill 22 255 360 22 257 360 minecraft:honeycomb_block
setblock 23 255 323 minecraft:yellow_terracotta
fill 23 255 324 23 257 324 minecraft:honeycomb_block
setblock 23 255 363 minecraft:yellow_terracotta
fill 24 255 323 24 258 323 minecraft:honeycomb_block
setblock 24 255 362 minecraft:yellow_terracotta
fill 24 255 363 24 258 363 minecraft:honeycomb_block
setblock 25 255 361 minecraft:yellow_terracotta
fill 25 255 362 25 258 362 minecraft:honeycomb_block
fill 26 255 360 26 256 360 minecraft:brown_terracotta
fill 26 255 361 26 256 361 minecraft:honeycomb_block
setblock 27 255 323 minecraft:honeycomb_block
setblock 28 255 363 minecraft:yellow_terracotta
fill 29 255 325 29 256 325 minecraft:brown_terracotta
setblock 29 255 362 minecraft:yellow_terracotta
fill 29 255 363 32 255 363 minecraft:honeycomb_block
fill 30 255 362 33 255 362 minecraft:honeycomb_block
setblock 33 255 363 minecraft:yellow_terracotta
fill 34 255 323 37 255 323 minecraft:honeycomb_block
setblock 34 255 362 minecraft:yellow_terracotta
fill 34 255 363 34 258 363 minecraft:honeycomb_block
setblock 35 255 361 minecraft:yellow_terracotta
fill 35 255 362 35 258 362 minecraft:honeycomb_block
fill 36 255 361 36 257 361 minecraft:honeycomb_block
setblock 36 255 364 minecraft:yellow_terracotta
setblock 38 255 323 minecraft:yellow_terracotta
fill 38 255 324 39 257 324 minecraft:honeycomb_block
fill 38 255 331 38 256 331 minecraft:brown_terracotta
fill 38 255 333 38 256 333 minecraft:brown_terracotta
setblock 38 255 337 minecraft:honeycomb_block
setblock 38 255 338 minecraft:yellow_terracotta
fill 38 255 339 38 258 339 minecraft:honeycomb_block
fill 38 255 341 38 255 342 minecraft:honeycomb_block
setblock 38 255 343 minecraft:yellow_terracotta
fill 38 255 344 38 258 344 minecraft:honeycomb_block
fill 38 255 346 39 255 346 minecraft:honeycomb_block
fill 38 255 357 38 256 357 minecraft:brown_terracotta
setblock 38 255 363 minecraft:yellow_terracotta
fill 39 255 323 39 258 323 minecraft:honeycomb_block
fill 39 255 334 39 255 336 minecraft:honeycomb_block
setblock 39 255 337 minecraft:yellow_terracotta
fill 39 255 338 39 258 338 minecraft:honeycomb_block
setblock 39 255 342 minecraft:yellow_terracotta
fill 39 255 343 39 258 343 minecraft:honeycomb_block
fill 39 255 345 39 256 345 minecraft:honeycomb_block
setblock 39 255 347 minecraft:yellow_terracotta
fill 39 255 348 39 257 349 minecraft:honeycomb_block
setblock 39 255 357 minecraft:yellow_terracotta
setblock 39 255 358 minecraft:honeycomb_block
setblock 39 255 362 minecraft:yellow_terracotta
fill 39 255 363 39 258 363 minecraft:honeycomb_block
setblock 40 255 325 minecraft:honeycomb_block
setblock 40 255 326 minecraft:yellow_terracotta
setblock 40 255 330 minecraft:honeycomb_block
setblock 40 255 331 minecraft:yellow_terracotta
fill 40 255 332 40 258 332 minecraft:honeycomb_block
setblock 40 255 336 minecraft:yellow_terracotta
fill 40 255 337 40 258 337 minecraft:honeycomb_block
setblock 40 255 341 minecraft:yellow_terracotta
fill 40 255 342 40 258 342 minecraft:honeycomb_block
setblock 40 255 346 minecraft:yellow_terracotta
fill 40 255 347 40 258 347 minecraft:honeycomb_block
setblock 40 255 351 minecraft:yellow_terracotta
fill 40 255 352 40 257 352 minecraft:honeycomb_block
setblock 40 255 356 minecraft:yellow_terracotta
fill 40 255 357 40 257 357 minecraft:honeycomb_block
setblock 40 255 361 minecraft:yellow_terracotta
fill 40 255 362 40 258 362 minecraft:honeycomb_block
setblock 41 255 324 minecraft:honeycomb_block
setblock 41 255 325 minecraft:yellow_terracotta
fill 41 255 326 41 258 326 minecraft:honeycomb_block
setblock 41 255 330 minecraft:yellow_terracotta
fill 41 255 331 41 258 331 minecraft:honeycomb_block
setblock 41 255 335 minecraft:yellow_terracotta
fill 41 255 336 41 258 336 minecraft:honeycomb_block
setblock 41 255 340 minecraft:yellow_terracotta
fill 41 255 341 41 258 341 minecraft:honeycomb_block
setblock 41 255 345 minecraft:yellow_terracotta
fill 41 255 346 41 258 346 minecraft:honeycomb_block
setblock 41 255 350 minecraft:yellow_terracotta
fill 41 255 351 41 258 351 minecraft:honeycomb_block
setblock 41 255 355 minecraft:yellow_terracotta
fill 41 255 356 41 258 356 minecraft:honeycomb_block
setblock 41 255 360 minecraft:yellow_terracotta
fill 41 255 361 41 258 361 minecraft:honeycomb_block
setblock 42 255 334 minecraft:yellow_concrete
setblock 0 256 333 minecraft:yellow_terracotta
setblock 1 256 323 minecraft:honeycomb_block
setblock 1 256 324 minecraft:yellow_terracotta
fill 1 256 325 1 259 325 minecraft:honeycomb_block
setblock 1 256 329 minecraft:yellow_terracotta
fill 1 256 330 1 259 330 minecraft:honeycomb_block
setblock 1 256 334 minecraft:yellow_terracotta
fill 1 256 335 1 259 335 minecraft:honeycomb_block
setblock 1 256 339 minecraft:yellow_terracotta
fill 1 256 340 1 259 340 minecraft:honeycomb_block
setblock 1 256 344 minecraft:yellow_terracotta
fill 1 256 345 1 259 345 minecraft:honeycomb_block
setblock 1 256 349 minecraft:yellow_terracotta
fill 1 256 350 1 257 350 minecraft:honeycomb_block
setblock 1 256 351 minecraft:honey_block
setblock 1 256 355 minecraft:honeycomb_block
setblock 1 256 359 minecraft:yellow_terracotta
fill 1 256 360 1 259 360 minecraft:honeycomb_block
setblock 2 256 323 minecraft:yellow_terracotta
fill 2 256 324 2 259 324 minecraft:honeycomb_block
setblock 2 256 328 minecraft:yellow_terracotta
fill 2 256 329 2 259 329 minecraft:honeycomb_block
setblock 2 256 333 minecraft:yellow_terracotta
fill 2 256 334 2 258 334 minecraft:honeycomb_block
setblock 2 256 338 minecraft:yellow_terracotta
fill 2 256 339 2 259 339 minecraft:honeycomb_block
setblock 2 256 343 minecraft:yellow_terracotta
fill 2 256 344 2 259 344 minecraft:honeycomb_block
fill 2 256 356 2 257 357 minecraft:brown_terracotta
setblock 2 256 359 minecraft:honeycomb_block
setblock 2 256 363 minecraft:yellow_terracotta
fill 3 256 323 3 259 323 minecraft:honeycomb_block
fill 3 256 325 3 257 325 minecraft:honeycomb_block
setblock 3 256 333 minecraft:light[level=15]
setblock 3 256 337 minecraft:yellow_terracotta
setblock 3 256 338 minecraft:honeycomb_block
setblock 3 256 342 minecraft:yellow_terracotta
setblock 3 256 343 minecraft:honeycomb_block
setblock 3 256 349 minecraft:light[level=15]
setblock 3 256 362 minecraft:yellow_terracotta
fill 3 256 363 3 259 364 minecraft:honeycomb_block
fill 4 256 362 4 257 363 minecraft:honeycomb_block
fill 5 256 363 6 256 363 minecraft:honeycomb_block
setblock 6 256 324 minecraft:yellow_terracotta
setblock 7 256 323 minecraft:yellow_terracotta
fill 7 256 324 10 256 324 minecraft:honeycomb_block
setblock 7 256 363 minecraft:yellow_terracotta
fill 8 256 323 8 259 323 minecraft:honeycomb_block
setblock 8 256 362 minecraft:yellow_terracotta
fill 8 256 363 8 259 363 minecraft:honeycomb_block
fill 9 256 362 9 259 362 minecraft:honeycomb_block
setblock 11 256 324 minecraft:yellow_terracotta
setblock 11 256 325 minecraft:light[level=15]
setblock 11 256 333 minecraft:light[level=15]
setblock 11 256 341 minecraft:light[level=15]
setblock 11 256 349 minecraft:light[level=15]
setblock 11 256 357 minecraft:light[level=15]
setblock 12 256 323 minecraft:yellow_terracotta
fill 12 256 324 15 256 324 minecraft:honeycomb_block
fill 12 256 361 13 256 361 minecraft:honeycomb_block
setblock 12 256 363 minecraft:yellow_terracotta
fill 13 256 323 13 259 323 minecraft:honeycomb_block
setblock 13 256 362 minecraft:yellow_terracotta
fill 13 256 363 13 259 363 minecraft:honeycomb_block
setblock 14 256 325 minecraft:honeycomb_block
setblock 14 256 361 minecraft:yellow_terracotta
fill 14 256 362 14 259 362 minecraft:honeycomb_block
setblock 15 256 325 minecraft:yellow_terracotta
setblock 15 256 360 minecraft:yellow_terracotta
fill 15 256 361 15 259 361 minecraft:honeycomb_block
setblock 16 256 322 minecraft:yellow_concrete
setblock 16 256 324 minecraft:yellow_terracotta
fill 16 256 325 19 256 325 minecraft:honeycomb_block
fill 16 256 360 16 258 360 minecraft:honeycomb_block
setblock 17 256 323 minecraft:yellow_terracotta
fill 17 256 324 17 259 324 minecraft:honeycomb_block
setblock 17 256 363 minecraft:yellow_terracotta
fill 18 256 323 18 259 323 minecraft:honeycomb_block
setblock 18 256 362 minecraft:yellow_terracotta
fill 18 256 363 18 259 363 minecraft:honeycomb_block
setblock 19 256 333 minecraft:light[level=15]
setblock 19 256 341 minecraft:light[level=15]
setblock 19 256 349 minecraft:light[level=15]
setblock 19 256 357 minecraft:light[level=15]
setblock 19 256 361 minecraft:yellow_terracotta
fill 19 256 362 19 259 362 minecraft:honeycomb_block
setblock 20 256 325 minecraft:yellow_terracotta
setblock 20 256 360 minecraft:yellow_terracotta
fill 20 256 361 20 259 361 minecraft:honeycomb_block
setblock 21 256 324 minecraft:yellow_terracotta
fill 21 256 360 21 257 360 minecraft:honeycomb_block
setblock 22 256 323 minecraft:yellow_terracotta
fill 22 256 324 22 259 324 minecraft:honeycomb_block
setblock 22 256 363 minecraft:yellow_terracotta
fill 23 256 323 23 259 323 minecraft:honeycomb_block
setblock 23 256 362 minecraft:yellow_terracotta
fill 23 256 363 23 259 363 minecraft:honeycomb_block
setblock 24 256 361 minecraft:yellow_terracotta
fill 24 256 362 24 259 362 minecraft:honeycomb_block
fill 25 256 361 25 257 361 minecraft:honeycomb_block
setblock 27 256 323 minecraft:yellow_terracotta
setblock 27 256 325 minecraft:light[level=15]
setblock 27 256 333 minecraft:light[level=15]
setblock 27 256 349 minecraft:light[level=15]
setblock 27 256 357 minecraft:light[level=15]
setblock 27 256 363 minecraft:yellow_terracotta
setblock 28 256 323 minecraft:honey_block
setblock 28 256 362 minecraft:yellow_terracotta
fill 28 256 363 31 256 363 minecraft:honeycomb_block
fill 29 256 324 29 257 324 minecraft:brown_terracotta
fill 29 256 362 32 256 362 minecraft:honeycomb_block
setblock 32 256 323 minecraft:yellow_terracotta
setblock 32 256 363 minecraft:yellow_terracotta
fill 33 256 323 36 256 323 minecraft:honeycomb_block
setblock 33 256 362 minecraft:yellow_terracotta
fill 33 256 363 33 259 363 minecraft:honeycomb_block
fill 34 256 362 34 259 362 minecraft:honeycomb_block
setblock 35 256 325 minecraft:light[level=15]
setblock 35 256 333 minecraft:light[level=15]
setblock 35 256 341 minecraft:light[level=15]
setblock 35 256 349 minecraft:light[level=15]
setblock 35 256 357 minecraft:light[level=15]
fill 35 256 361 35 257 361 minecraft:honeycomb_block
setblock 36 256 324 minecraft:yellow_terracotta
fill 36 256 364 36 308 364 minecraft:honeycomb_block
setblock 37 256 323 minecraft:yellow_terracotta
fill 37 256 324 37 259 324 minecraft:honeycomb_block
fill 37 256 340 37 256 342 minecraft:honeycomb_block
setblock 37 256 343 minecraft:yellow_terracotta
setblock 37 256 363 minecraft:yellow_terracotta
fill 38 256 323 38 259 323 minecraft:honeycomb_block
setblock 38 256 337 minecraft:yellow_terracotta
fill 38 256 338 38 258 338 minecraft:honeycomb_block
setblock 38 256 341 minecraft:honeycomb_block
setblock 38 256 342 minecraft:yellow_terracotta
fill 38 256 343 38 259 343 minecraft:honeycomb_block
setblock 38 256 346 minecraft:honeycomb_block
setblock 38 256 347 minecraft:yellow_terracotta
setblock 38 256 362 minecraft:yellow_terracotta
fill 38 256 363 38 259 363 minecraft:honeycomb_block
fill 39 256 331 39 257 331 minecraft:brown_terracotta
fill 39 256 333 39 257 333 minecraft:brown_terracotta
fill 39 256 334 39 256 335 minecraft:honeycomb_block
setblock 39 256 336 minecraft:yellow_terracotta
fill 39 256 337 39 259 337 minecraft:honeycomb_block
setblock 39 256 341 minecraft:yellow_terracotta
fill 39 256 342 39 259 342 minecraft:honeycomb_block
setblock 39 256 346 minecraft:yellow_terracotta
fill 39 256 347 39 259 347 minecraft:honeycomb_block
fill 39 256 357 39 257 357 minecraft:brown_terracotta
setblock 39 256 361 minecraft:yellow_terracotta
fill 39 256 362 39 259 362 minecraft:honeycomb_block
setblock 40 256 325 minecraft:yellow_terracotta
fill 40 256 326 40 256 329 minecraft:honeycomb_block
setblock 40 256 330 minecraft:yellow_terracotta
fill 40 256 331 40 258 331 minecraft:honeycomb_block
setblock 40 256 335 minecraft:yellow_terracotta
fill 40 256 336 40 259 336 minecraft:honeycomb_block
setblock 40 256 340 minecraft:yellow_terracotta
fill 40 256 341 40 259 341 minecraft:honeycomb_block
setblock 40 256 345 minecraft:yellow_terracotta
fill 40 256 346 40 259 346 minecraft:honeycomb_block
setblock 40 256 350 minecraft:yellow_terracotta
fill 40 256 351 40 258 351 minecraft:honeycomb_block
setblock 40 256 355 minecraft:yellow_terracotta
setblock 40 256 356 minecraft:honeycomb_block
setblock 40 256 360 minecraft:yellow_terracotta
fill 40 256 361 40 258 361 minecraft:honeycomb_block
setblock 41 256 324 minecraft:yellow_terracotta
fill 41 256 325 41 259 325 minecraft:honeycomb_block
setblock 41 256 329 minecraft:yellow_terracotta
fill 41 256 330 41 259 330 minecraft:honeycomb_block
setblock 41 256 334 minecraft:yellow_terracotta
fill 41 256 335 41 259 335 minecraft:honeycomb_block
setblock 41 256 339 minecraft:yellow_terracotta
fill 41 256 340 41 259 340 minecraft:honeycomb_block
setblock 41 256 344 minecraft:yellow_terracotta
fill 41 256 345 41 259 345 minecraft:honeycomb_block
setblock 41 256 349 minecraft:yellow_terracotta
fill 41 256 350 41 259 350 minecraft:honeycomb_block
setblock 41 256 354 minecraft:yellow_terracotta
fill 41 256 355 41 257 355 minecraft:honeycomb_block
setblock 41 256 359 minecraft:yellow_terracotta
fill 41 256 360 41 259 360 minecraft:honeycomb_block
fill 42 256 334 42 282 334 minecraft:honeycomb_block
fill 0 257 333 0 308 333 minecraft:honeycomb_block
setblock 1 257 323 minecraft:yellow_terracotta
fill 1 257 324 1 260 324 minecraft:honeycomb_block
setblock 1 257 328 minecraft:yellow_terracotta
fill 1 257 329 1 260 329 minecraft:honeycomb_block
setblock 1 257 333 minecraft:yellow_terracotta
fill 1 257 334 1 260 334 minecraft:honeycomb_block
setblock 1 257 338 minecraft:yellow_terracotta
fill 1 257 339 1 260 339 minecraft:honeycomb_block
setblock 1 257 343 minecraft:yellow_terracotta
fill 1 257 344 1 260 344 minecraft:honeycomb_block
setblock 1 257 348 minecraft:yellow_terracotta
fill 1 257 349 1 258 349 minecraft:honeycomb_block
fill 1 257 356 1 258 356 minecraft:brown_terracotta
setblock 1 257 358 minecraft:yellow_terracotta
fill 1 257 359 1 258 359 minecraft:honeycomb_block
setblock 1 257 363 minecraft:yellow_terracotta
fill 2 257 323 2 260 323 minecraft:honeycomb_block
setblock 2 257 327 minecraft:yellow_terracotta
fill 2 257 328 2 260 328 minecraft:honeycomb_block
setblock 2 257 332 minecraft:yellow_terracotta
setblock 2 257 333 minecraft:honeycomb_block
setblock 2 257 337 minecraft:yellow_terracotta
fill 2 257 338 2 259 338 minecraft:honeycomb_block
setblock 2 257 342 minecraft:yellow_terracotta
fill 2 257 343 2 259 343 minecraft:honeycomb_block
setblock 2 257 362 minecraft:yellow_terracotta
fill 2 257 363 2 260 363 minecraft:honeycomb_block
setblock 3 257 341 minecraft:yellow_terracotta
setblock 3 257 342 minecraft:honeycomb_block
fill 3 257 362 3 258 362 minecraft:honeycomb_block
setblock 5 257 324 minecraft:yellow_terracotta
setblock 5 257 363 minecraft:honeycomb_block
setblock 6 257 323 minecraft:yellow_terracotta
fill 6 257 324 9 257 324 minecraft:honeycomb_block
setblock 6 257 362 minecraft:honeycomb_block
setblock 6 257 363 minecraft:yellow_terracotta
fill 7 257 323 7 260 323 minecraft:honeycomb_block
setblock 7 257 362 minecraft:yellow_terracotta
fill 7 257 363 7 260 363 minecraft:honeycomb_block
setblock 8 257 362 minecraft:honeycomb_block
setblock 10 257 324 minecraft:yellow_terracotta
setblock 11 257 323 minecraft:yellow_terracotta
fill 11 257 324 14 257 324 minecraft:honeycomb_block
setblock 11 257 363 minecraft:yellow_terracotta
fill 12 257 323 12 260 323 minecraft:honeycomb_block
setblock 12 257 361 minecraft:honeycomb_block
setblock 12 257 362 minecraft:yellow_terracotta
fill 12 257 363 12 260 363 minecraft:honeycomb_block
setblock 13 257 325 minecraft:honeycomb_block
setblock 13 257 361 minecraft:yellow_terracotta
fill 13 257 362 13 260 362 minecraft:honeycomb_block
setblock 14 257 325 minecraft:yellow_terracotta
fill 14 257 361 14 260 361 minecraft:honeycomb_block
setblock 15 257 324 minecraft:yellow_terracotta
fill 15 257 325 18 257 325 minecraft:honeycomb_block
setblock 15 257 360 minecraft:honeycomb_block
fill 16 257 322 16 308 322 minecraft:honeycomb_block
setblock 16 257 323 minecraft:yellow_terracotta
fill 16 257 324 16 260 324 minecraft:honeycomb_block
setblock 16 257 363 minecraft:yellow_terracotta
fill 17 257 323 17 260 323 minecraft:honeycomb_block
setblock 17 257 362 minecraft:yellow_terracotta
fill 17 257 363 17 260 363 minecraft:honeycomb_block
setblock 18 257 361 minecraft:yellow_terracotta
fill 18 257 362 18 260 362 minecraft:honeycomb_block
setblock 19 257 325 minecraft:yellow_terracotta
setblock 19 257 360 minecraft:yellow_terracotta
fill 19 257 361 19 260 361 minecraft:honeycomb_block
setblock 20 257 324 minecraft:yellow_terracotta
setblock 20 257 325 minecraft:honeycomb_block
fill 20 257 360 20 258 360 minecraft:honeycomb_block
setblock 21 257 323 minecraft:yellow_terracotta
fill 21 257 324 21 260 324 minecraft:honeycomb_block
setblock 21 257 363 minecraft:yellow_terracotta
fill 22 257 323 22 260 323 minecraft:honeycomb_block
setblock 22 257 362 minecraft:yellow_terracotta
fill 22 257 363 22 260 363 minecraft:honeycomb_block
setblock 23 257 361 minecraft:yellow_terracotta
fill 23 257 362 23 260 362 minecraft:honeycomb_block
setblock 24 257 361 minecraft:honeycomb_block
setblock 24 257 364 minecraft:yellow_terracotta
setblock 26 257 323 minecraft:yellow_terracotta
setblock 26 257 361 minecraft:brown_terracotta
setblock 26 257 363 minecraft:yellow_terracotta
setblock 27 257 323 minecraft:honeycomb_block
fill 27 257 352 30 259 353 minecraft:flowering_azalea_leaves[persistent=true]
setblock 27 257 362 minecraft:yellow_terracotta
fill 27 257 363 30 257 363 minecraft:honeycomb_block
fill 28 257 351 30 259 351 minecraft:flowering_azalea_leaves[persistent=true]
fill 28 257 354 29 259 354 minecraft:flowering_azalea_leaves[persistent=true]
fill 28 257 362 31 257 362 minecraft:honeycomb_block
fill 29 257 323 29 258 323 minecraft:brown_terracotta
setblock 31 257 323 minecraft:yellow_terracotta
schedule function dropper:buildpart/72_10 1t
