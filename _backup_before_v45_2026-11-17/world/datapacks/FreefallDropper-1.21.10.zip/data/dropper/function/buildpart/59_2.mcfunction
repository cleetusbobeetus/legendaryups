setblock 527 162 228 minecraft:magenta_terracotta
setblock 527 162 270 minecraft:magenta_terracotta
setblock 531 162 228 minecraft:magenta_terracotta
setblock 531 162 270 minecraft:magenta_terracotta
setblock 535 162 228 minecraft:magenta_terracotta
setblock 535 162 270 minecraft:magenta_terracotta
setblock 539 162 228 minecraft:magenta_terracotta
setblock 539 162 270 minecraft:magenta_terracotta
setblock 543 162 228 minecraft:magenta_terracotta
setblock 543 162 270 minecraft:magenta_terracotta
setblock 547 162 228 minecraft:magenta_terracotta
setblock 547 162 270 minecraft:magenta_terracotta
setblock 551 162 228 minecraft:magenta_terracotta
setblock 551 162 270 minecraft:magenta_terracotta
setblock 555 162 228 minecraft:magenta_terracotta
setblock 555 162 270 minecraft:magenta_terracotta
fill 557 162 263 557 162 264 minecraft:spruce_planks
fill 557 162 265 558 162 266 minecraft:dark_oak_planks
setblock 557 162 270 minecraft:light_gray_terracotta
setblock 559 162 228 minecraft:magenta_terracotta
setblock 559 162 230 minecraft:magenta_terracotta
setblock 559 162 234 minecraft:magenta_terracotta
setblock 559 162 238 minecraft:magenta_terracotta
setblock 559 162 242 minecraft:magenta_terracotta
setblock 559 162 246 minecraft:magenta_terracotta
setblock 559 162 250 minecraft:magenta_terracotta
setblock 559 162 254 minecraft:magenta_terracotta
fill 559 162 257 559 212 257 minecraft:purple_terracotta
setblock 559 162 258 minecraft:magenta_terracotta
setblock 559 162 262 minecraft:magenta_terracotta
setblock 559 162 266 minecraft:magenta_terracotta
setblock 559 162 270 minecraft:magenta_terracotta
fill 517 163 230 517 165 230 minecraft:purple_terracotta
fill 517 163 234 517 165 234 minecraft:purple_terracotta
fill 517 163 238 517 165 238 minecraft:purple_terracotta
fill 517 163 242 517 165 242 minecraft:purple_terracotta
fill 517 163 246 517 165 246 minecraft:purple_terracotta
fill 517 163 250 517 165 250 minecraft:purple_terracotta
fill 517 163 254 517 165 254 minecraft:purple_terracotta
fill 517 163 258 517 165 258 minecraft:purple_terracotta
fill 517 163 262 517 165 262 minecraft:purple_terracotta
fill 517 163 266 517 165 266 minecraft:purple_terracotta
setblock 517 163 270 minecraft:purple_terracotta
fill 519 163 228 519 165 228 minecraft:purple_terracotta
fill 519 163 270 519 165 270 minecraft:purple_terracotta
fill 523 163 228 523 165 228 minecraft:purple_terracotta
fill 523 163 270 523 165 270 minecraft:purple_terracotta
fill 527 163 228 527 165 228 minecraft:purple_terracotta
fill 527 163 270 527 165 270 minecraft:purple_terracotta
fill 531 163 228 531 165 228 minecraft:purple_terracotta
fill 531 163 270 531 165 270 minecraft:purple_terracotta
fill 535 163 228 535 165 228 minecraft:purple_terracotta
fill 535 163 270 535 165 270 minecraft:purple_terracotta
fill 539 163 228 539 165 228 minecraft:purple_terracotta
fill 539 163 270 539 165 270 minecraft:purple_terracotta
fill 543 163 228 543 165 228 minecraft:purple_terracotta
fill 543 163 270 543 165 270 minecraft:purple_terracotta
fill 547 163 228 547 165 228 minecraft:purple_terracotta
fill 547 163 270 547 165 270 minecraft:purple_terracotta
fill 551 163 228 551 165 228 minecraft:purple_terracotta
fill 551 163 270 551 165 270 minecraft:purple_terracotta
fill 555 163 228 555 165 228 minecraft:purple_terracotta
fill 555 163 270 555 165 270 minecraft:purple_terracotta
fill 557 163 261 557 163 262 minecraft:spruce_planks
fill 557 163 263 558 163 264 minecraft:dark_oak_planks
setblock 557 163 270 minecraft:purple_terracotta
setblock 559 163 228 minecraft:purple_terracotta
fill 559 163 230 559 165 230 minecraft:purple_terracotta
fill 559 163 234 559 165 234 minecraft:purple_terracotta
fill 559 163 238 559 165 238 minecraft:purple_terracotta
fill 559 163 242 559 165 242 minecraft:purple_terracotta
fill 559 163 246 559 165 246 minecraft:purple_terracotta
fill 559 163 250 559 165 250 minecraft:purple_terracotta
fill 559 163 254 559 165 254 minecraft:purple_terracotta
fill 559 163 258 559 165 258 minecraft:purple_terracotta
fill 559 163 262 559 165 262 minecraft:purple_terracotta
fill 559 163 266 559 165 266 minecraft:purple_terracotta
fill 559 163 270 559 165 270 minecraft:purple_terracotta
setblock 517 164 228 minecraft:magenta_terracotta
setblock 517 164 232 minecraft:magenta_terracotta
setblock 517 164 236 minecraft:magenta_terracotta
setblock 517 164 240 minecraft:magenta_terracotta
setblock 517 164 244 minecraft:magenta_terracotta
setblock 517 164 248 minecraft:magenta_terracotta
setblock 517 164 252 minecraft:magenta_terracotta
setblock 517 164 256 minecraft:magenta_terracotta
setblock 517 164 260 minecraft:magenta_terracotta
setblock 517 164 264 minecraft:magenta_terracotta
setblock 517 164 268 minecraft:magenta_terracotta
setblock 517 164 270 minecraft:magenta_terracotta
fill 519 164 233 519 175 233 minecraft:iron_bars
setblock 521 164 228 minecraft:magenta_terracotta
setblock 521 164 270 minecraft:magenta_terracotta
setblock 525 164 228 minecraft:magenta_terracotta
setblock 525 164 270 minecraft:magenta_terracotta
setblock 529 164 228 minecraft:magenta_terracotta
setblock 529 164 270 minecraft:magenta_terracotta
setblock 533 164 228 minecraft:magenta_terracotta
setblock 533 164 270 minecraft:magenta_terracotta
setblock 537 164 228 minecraft:magenta_terracotta
setblock 537 164 270 minecraft:magenta_terracotta
setblock 541 164 228 minecraft:magenta_terracotta
setblock 541 164 270 minecraft:magenta_terracotta
setblock 545 164 228 minecraft:magenta_terracotta
setblock 545 164 270 minecraft:magenta_terracotta
setblock 549 164 228 minecraft:magenta_terracotta
setblock 549 164 270 minecraft:magenta_terracotta
fill 550 164 228 550 212 228 minecraft:purple_terracotta
setblock 553 164 228 minecraft:magenta_terracotta
setblock 553 164 270 minecraft:magenta_terracotta
setblock 557 164 228 minecraft:magenta_terracotta
fill 557 164 259 557 164 260 minecraft:spruce_planks
fill 557 164 261 558 164 262 minecraft:dark_oak_planks
setblock 557 164 270 minecraft:magenta_terracotta
setblock 559 164 228 minecraft:magenta_terracotta
setblock 559 164 232 minecraft:magenta_terracotta
setblock 559 164 236 minecraft:magenta_terracotta
setblock 559 164 240 minecraft:magenta_terracotta
setblock 559 164 244 minecraft:magenta_terracotta
setblock 559 164 248 minecraft:magenta_terracotta
setblock 559 164 252 minecraft:light_gray_terracotta
setblock 559 164 256 minecraft:magenta_terracotta
setblock 559 164 260 minecraft:magenta_terracotta
setblock 559 164 264 minecraft:magenta_terracotta
setblock 559 164 268 minecraft:magenta_terracotta
fill 517 165 228 517 167 228 minecraft:purple_terracotta
fill 517 165 232 517 167 232 minecraft:purple_terracotta
fill 517 165 236 517 167 236 minecraft:purple_terracotta
fill 517 165 240 517 167 240 minecraft:purple_terracotta
fill 517 165 244 517 167 244 minecraft:purple_terracotta
fill 517 165 248 517 167 248 minecraft:purple_terracotta
fill 517 165 252 517 167 252 minecraft:purple_terracotta
fill 517 165 256 517 167 256 minecraft:purple_terracotta
fill 517 165 260 517 167 260 minecraft:purple_terracotta
fill 517 165 264 517 167 264 minecraft:purple_terracotta
fill 517 165 268 517 167 268 minecraft:purple_terracotta
setblock 517 165 270 minecraft:purple_terracotta
fill 521 165 228 521 167 228 minecraft:purple_terracotta
fill 521 165 270 521 167 270 minecraft:purple_terracotta
fill 525 165 228 525 167 228 minecraft:purple_terracotta
fill 525 165 270 525 167 270 minecraft:purple_terracotta
fill 529 165 228 529 167 228 minecraft:purple_terracotta
fill 529 165 270 529 167 270 minecraft:purple_terracotta
fill 533 165 228 533 167 228 minecraft:purple_terracotta
fill 533 165 270 533 167 270 minecraft:purple_terracotta
fill 537 165 228 537 167 228 minecraft:purple_terracotta
fill 537 165 270 537 167 270 minecraft:purple_terracotta
fill 541 165 228 541 167 228 minecraft:purple_terracotta
fill 541 165 270 541 167 270 minecraft:purple_terracotta
fill 545 165 228 545 167 228 minecraft:purple_terracotta
fill 545 165 270 545 167 270 minecraft:purple_terracotta
fill 549 165 228 549 167 228 minecraft:purple_terracotta
fill 549 165 270 549 167 270 minecraft:purple_terracotta
fill 553 165 228 553 167 228 minecraft:purple_terracotta
fill 553 165 270 553 167 270 minecraft:purple_terracotta
fill 557 165 228 557 167 228 minecraft:purple_terracotta
fill 557 165 257 557 165 258 minecraft:spruce_planks
fill 557 165 259 558 165 260 minecraft:dark_oak_planks
fill 557 165 270 557 167 270 minecraft:purple_terracotta
setblock 559 165 228 minecraft:purple_terracotta
fill 559 165 232 559 167 232 minecraft:purple_terracotta
fill 559 165 236 559 167 236 minecraft:purple_terracotta
fill 559 165 240 559 167 240 minecraft:purple_terracotta
fill 559 165 244 559 167 244 minecraft:purple_terracotta
fill 559 165 248 559 167 248 minecraft:purple_terracotta
fill 559 165 252 559 167 252 minecraft:purple_terracotta
fill 559 165 256 559 167 256 minecraft:purple_terracotta
fill 559 165 260 559 167 260 minecraft:purple_terracotta
fill 559 165 264 559 167 264 minecraft:purple_terracotta
fill 559 165 268 559 167 268 minecraft:purple_terracotta
setblock 517 166 230 minecraft:magenta_terracotta
setblock 517 166 234 minecraft:magenta_terracotta
setblock 517 166 238 minecraft:magenta_terracotta
setblock 517 166 242 minecraft:magenta_terracotta
setblock 517 166 246 minecraft:magenta_terracotta
setblock 517 166 250 minecraft:magenta_terracotta
setblock 517 166 254 minecraft:magenta_terracotta
setblock 517 166 258 minecraft:magenta_terracotta
setblock 517 166 262 minecraft:magenta_terracotta
setblock 517 166 266 minecraft:magenta_terracotta
setblock 517 166 270 minecraft:magenta_terracotta
setblock 519 166 228 minecraft:magenta_terracotta
setblock 519 166 270 minecraft:magenta_terracotta
setblock 520 166 231 minecraft:light[level=12]
setblock 520 166 238 minecraft:light[level=12]
setblock 520 166 245 minecraft:light[level=12]
setblock 520 166 252 minecraft:light[level=12]
setblock 520 166 259 minecraft:light[level=12]
setblock 520 166 266 minecraft:light[level=12]
setblock 523 166 228 minecraft:magenta_terracotta
setblock 523 166 270 minecraft:magenta_terracotta
setblock 527 166 228 minecraft:magenta_terracotta
setblock 527 166 231 minecraft:light[level=12]
setblock 527 166 238 minecraft:light[level=12]
setblock 527 166 245 minecraft:light[level=12]
setblock 527 166 252 minecraft:light[level=12]
setblock 527 166 259 minecraft:light[level=12]
setblock 527 166 266 minecraft:light[level=12]
setblock 527 166 270 minecraft:magenta_terracotta
setblock 531 166 228 minecraft:magenta_terracotta
setblock 531 166 270 minecraft:magenta_terracotta
setblock 534 166 231 minecraft:light[level=12]
setblock 534 166 238 minecraft:light[level=12]
setblock 534 166 245 minecraft:light[level=12]
setblock 534 166 252 minecraft:light[level=12]
setblock 534 166 259 minecraft:light[level=12]
setblock 534 166 266 minecraft:light[level=12]
setblock 535 166 228 minecraft:magenta_terracotta
setblock 535 166 270 minecraft:magenta_terracotta
setblock 539 166 228 minecraft:magenta_terracotta
setblock 539 166 270 minecraft:magenta_terracotta
setblock 541 166 231 minecraft:light[level=12]
setblock 541 166 238 minecraft:light[level=12]
setblock 541 166 245 minecraft:light[level=12]
setblock 541 166 252 minecraft:light[level=12]
setblock 541 166 259 minecraft:light[level=12]
setblock 541 166 266 minecraft:light[level=12]
setblock 543 166 228 minecraft:magenta_terracotta
setblock 543 166 270 minecraft:magenta_terracotta
setblock 547 166 228 minecraft:magenta_terracotta
setblock 547 166 270 minecraft:magenta_terracotta
setblock 548 166 231 minecraft:light[level=12]
setblock 548 166 238 minecraft:light[level=12]
setblock 548 166 245 minecraft:light[level=12]
setblock 548 166 252 minecraft:light[level=12]
setblock 548 166 259 minecraft:light[level=12]
setblock 548 166 266 minecraft:light[level=12]
setblock 551 166 228 minecraft:magenta_terracotta
setblock 551 166 270 minecraft:magenta_terracotta
setblock 555 166 228 minecraft:magenta_terracotta
setblock 555 166 231 minecraft:light[level=12]
setblock 555 166 238 minecraft:light[level=12]
setblock 555 166 245 minecraft:light[level=12]
setblock 555 166 252 minecraft:light[level=12]
setblock 555 166 259 minecraft:light[level=12]
setblock 555 166 266 minecraft:light[level=12]
setblock 555 166 270 minecraft:magenta_terracotta
fill 557 166 255 557 166 256 minecraft:spruce_planks
fill 557 166 257 558 166 258 minecraft:dark_oak_planks
setblock 559 166 228 minecraft:magenta_terracotta
setblock 559 166 230 minecraft:magenta_terracotta
setblock 559 166 234 minecraft:magenta_terracotta
setblock 559 166 238 minecraft:magenta_terracotta
setblock 559 166 242 minecraft:magenta_terracotta
setblock 559 166 246 minecraft:magenta_terracotta
setblock 559 166 250 minecraft:magenta_terracotta
setblock 559 166 254 minecraft:magenta_terracotta
setblock 559 166 258 minecraft:magenta_terracotta
setblock 559 166 262 minecraft:magenta_terracotta
setblock 559 166 266 minecraft:magenta_terracotta
setblock 559 166 270 minecraft:magenta_terracotta
fill 517 167 230 517 169 230 minecraft:purple_terracotta
fill 517 167 234 517 169 234 minecraft:purple_terracotta
fill 517 167 238 517 169 238 minecraft:purple_terracotta
fill 517 167 242 517 169 242 minecraft:purple_terracotta
fill 517 167 246 517 169 246 minecraft:purple_terracotta
fill 517 167 250 517 169 250 minecraft:purple_terracotta
fill 517 167 254 517 169 254 minecraft:purple_terracotta
fill 517 167 258 517 169 258 minecraft:purple_terracotta
fill 517 167 262 517 169 262 minecraft:purple_terracotta
fill 517 167 266 517 169 266 minecraft:purple_terracotta
setblock 517 167 270 minecraft:purple_terracotta
fill 519 167 228 519 169 228 minecraft:purple_terracotta
fill 519 167 270 519 169 270 minecraft:purple_terracotta
fill 523 167 228 523 169 228 minecraft:purple_terracotta
fill 523 167 270 523 169 270 minecraft:purple_terracotta
fill 527 167 228 527 169 228 minecraft:purple_terracotta
fill 527 167 270 527 169 270 minecraft:purple_terracotta
fill 531 167 228 531 169 228 minecraft:purple_terracotta
fill 531 167 270 531 169 270 minecraft:purple_terracotta
fill 535 167 228 535 169 228 minecraft:purple_terracotta
fill 535 167 270 535 169 270 minecraft:purple_terracotta
fill 539 167 228 539 169 228 minecraft:purple_terracotta
fill 539 167 270 539 169 270 minecraft:purple_terracotta
fill 543 167 228 543 169 228 minecraft:purple_terracotta
fill 543 167 270 543 169 270 minecraft:purple_terracotta
fill 547 167 228 547 169 228 minecraft:purple_terracotta
fill 547 167 270 547 169 270 minecraft:purple_terracotta
fill 551 167 228 551 169 228 minecraft:purple_terracotta
fill 551 167 270 551 169 270 minecraft:purple_terracotta
fill 555 167 228 555 169 228 minecraft:purple_terracotta
fill 555 167 270 555 169 270 minecraft:purple_terracotta
fill 557 167 253 557 167 254 minecraft:spruce_planks
fill 557 167 255 558 167 256 minecraft:dark_oak_planks
setblock 559 167 228 minecraft:purple_terracotta
fill 559 167 230 559 169 230 minecraft:purple_terracotta
fill 559 167 234 559 169 234 minecraft:purple_terracotta
fill 559 167 238 559 169 238 minecraft:purple_terracotta
fill 559 167 242 559 169 242 minecraft:purple_terracotta
fill 559 167 246 559 169 246 minecraft:purple_terracotta
fill 559 167 250 559 169 250 minecraft:purple_terracotta
fill 559 167 254 559 169 254 minecraft:purple_terracotta
fill 559 167 258 559 169 258 minecraft:purple_terracotta
fill 559 167 262 559 169 262 minecraft:purple_terracotta
fill 559 167 266 559 169 266 minecraft:purple_terracotta
fill 559 167 270 559 169 270 minecraft:purple_terracotta
setblock 517 168 228 minecraft:magenta_terracotta
setblock 517 168 232 minecraft:magenta_terracotta
setblock 517 168 236 minecraft:magenta_terracotta
setblock 517 168 240 minecraft:magenta_terracotta
setblock 517 168 244 minecraft:magenta_terracotta
setblock 517 168 248 minecraft:magenta_terracotta
setblock 517 168 252 minecraft:magenta_terracotta
setblock 517 168 256 minecraft:magenta_terracotta
setblock 517 168 260 minecraft:magenta_terracotta
setblock 517 168 264 minecraft:magenta_terracotta
setblock 517 168 268 minecraft:magenta_terracotta
setblock 517 168 270 minecraft:magenta_terracotta
setblock 520 168 231 minecraft:light[level=11]
setblock 520 168 239 minecraft:light[level=11]
setblock 520 168 247 minecraft:light[level=11]
setblock 520 168 255 minecraft:light[level=11]
setblock 520 168 263 minecraft:light[level=11]
setblock 521 168 228 minecraft:magenta_terracotta
setblock 521 168 270 minecraft:magenta_terracotta
setblock 525 168 228 minecraft:magenta_terracotta
setblock 525 168 270 minecraft:magenta_terracotta
setblock 528 168 231 minecraft:light[level=11]
setblock 528 168 239 minecraft:light[level=11]
setblock 528 168 247 minecraft:light[level=11]
setblock 528 168 255 minecraft:light[level=11]
setblock 528 168 263 minecraft:light[level=11]
setblock 529 168 228 minecraft:magenta_terracotta
setblock 529 168 270 minecraft:magenta_terracotta
setblock 533 168 228 minecraft:magenta_terracotta
setblock 533 168 270 minecraft:magenta_terracotta
setblock 536 168 231 minecraft:light[level=11]
setblock 536 168 239 minecraft:light[level=11]
setblock 536 168 247 minecraft:light[level=11]
setblock 536 168 255 minecraft:light[level=11]
setblock 536 168 263 minecraft:light[level=11]
setblock 537 168 228 minecraft:magenta_terracotta
setblock 537 168 270 minecraft:magenta_terracotta
setblock 541 168 228 minecraft:magenta_terracotta
setblock 541 168 270 minecraft:magenta_terracotta
setblock 544 168 231 minecraft:light[level=11]
setblock 544 168 239 minecraft:light[level=11]
setblock 544 168 247 minecraft:light[level=11]
setblock 544 168 255 minecraft:light[level=11]
setblock 544 168 263 minecraft:light[level=11]
setblock 545 168 228 minecraft:magenta_terracotta
setblock 545 168 270 minecraft:magenta_terracotta
setblock 549 168 228 minecraft:magenta_terracotta
setblock 549 168 270 minecraft:magenta_terracotta
setblock 552 168 231 minecraft:light[level=11]
setblock 552 168 239 minecraft:light[level=11]
setblock 552 168 247 minecraft:light[level=11]
setblock 552 168 255 minecraft:light[level=11]
setblock 552 168 263 minecraft:light[level=11]
setblock 553 168 228 minecraft:magenta_terracotta
setblock 553 168 270 minecraft:magenta_terracotta
setblock 557 168 228 minecraft:magenta_terracotta
fill 557 168 251 557 168 252 minecraft:spruce_planks
fill 557 168 253 558 168 254 minecraft:dark_oak_planks
setblock 557 168 270 minecraft:magenta_terracotta
setblock 559 168 228 minecraft:magenta_terracotta
setblock 559 168 232 minecraft:magenta_terracotta
setblock 559 168 236 minecraft:magenta_terracotta
setblock 559 168 240 minecraft:magenta_terracotta
setblock 559 168 244 minecraft:magenta_terracotta
setblock 559 168 248 minecraft:magenta_terracotta
setblock 559 168 252 minecraft:magenta_terracotta
setblock 559 168 256 minecraft:magenta_terracotta
setblock 559 168 260 minecraft:magenta_terracotta
setblock 559 168 264 minecraft:magenta_terracotta
setblock 559 168 268 minecraft:magenta_terracotta
fill 517 169 228 517 171 228 minecraft:purple_terracotta
fill 517 169 232 517 171 232 minecraft:purple_terracotta
fill 517 169 236 517 171 236 minecraft:purple_terracotta
fill 517 169 240 517 171 240 minecraft:purple_terracotta
fill 517 169 244 517 171 244 minecraft:purple_terracotta
fill 517 169 248 517 171 248 minecraft:purple_terracotta
fill 517 169 252 517 171 252 minecraft:purple_terracotta
fill 517 169 256 517 171 256 minecraft:purple_terracotta
fill 517 169 260 517 171 260 minecraft:purple_terracotta
fill 517 169 264 517 171 264 minecraft:purple_terracotta
fill 517 169 268 517 171 268 minecraft:purple_terracotta
setblock 517 169 270 minecraft:purple_terracotta
fill 521 169 228 521 171 228 minecraft:purple_terracotta
fill 521 169 270 521 171 270 minecraft:purple_terracotta
fill 525 169 228 525 171 228 minecraft:purple_terracotta
fill 525 169 270 525 171 270 minecraft:purple_terracotta
fill 529 169 228 529 171 228 minecraft:purple_terracotta
fill 529 169 270 529 171 270 minecraft:purple_terracotta
fill 533 169 228 533 171 228 minecraft:purple_terracotta
fill 533 169 270 533 171 270 minecraft:purple_terracotta
fill 537 169 228 537 171 228 minecraft:purple_terracotta
fill 537 169 270 537 171 270 minecraft:purple_terracotta
fill 541 169 228 541 171 228 minecraft:purple_terracotta
fill 541 169 270 541 171 270 minecraft:purple_terracotta
fill 545 169 228 545 171 228 minecraft:purple_terracotta
fill 545 169 270 545 171 270 minecraft:purple_terracotta
fill 549 169 228 549 171 228 minecraft:purple_terracotta
fill 549 169 270 549 171 270 minecraft:purple_terracotta
setblock 553 169 228 minecraft:purple_terracotta
fill 553 169 270 553 171 270 minecraft:purple_terracotta
fill 557 169 228 557 171 228 minecraft:purple_terracotta
fill 557 169 249 557 169 250 minecraft:spruce_planks
fill 557 169 251 558 169 252 minecraft:dark_oak_planks
fill 557 169 270 557 171 270 minecraft:purple_terracotta
setblock 559 169 228 minecraft:purple_terracotta
fill 559 169 232 559 171 232 minecraft:purple_terracotta
fill 559 169 236 559 171 236 minecraft:purple_terracotta
fill 559 169 240 559 171 240 minecraft:purple_terracotta
fill 559 169 244 559 171 244 minecraft:purple_terracotta
fill 559 169 248 559 171 248 minecraft:purple_terracotta
fill 559 169 252 559 171 252 minecraft:purple_terracotta
fill 559 169 256 559 171 256 minecraft:purple_terracotta
fill 559 169 260 559 171 260 minecraft:purple_terracotta
fill 559 169 264 559 171 264 minecraft:purple_terracotta
fill 559 169 268 559 171 268 minecraft:purple_terracotta
setblock 517 170 230 minecraft:magenta_terracotta
setblock 517 170 234 minecraft:magenta_terracotta
setblock 517 170 238 minecraft:magenta_terracotta
setblock 517 170 242 minecraft:magenta_terracotta
setblock 517 170 246 minecraft:magenta_terracotta
setblock 517 170 250 minecraft:magenta_terracotta
setblock 517 170 254 minecraft:magenta_terracotta
setblock 517 170 258 minecraft:magenta_terracotta
setblock 517 170 262 minecraft:magenta_terracotta
setblock 517 170 266 minecraft:magenta_terracotta
setblock 517 170 270 minecraft:magenta_terracotta
setblock 519 170 228 minecraft:magenta_terracotta
setblock 519 170 270 minecraft:magenta_terracotta
setblock 523 170 228 minecraft:magenta_terracotta
setblock 523 170 270 minecraft:magenta_terracotta
setblock 527 170 228 minecraft:magenta_terracotta
setblock 527 170 270 minecraft:magenta_terracotta
setblock 531 170 228 minecraft:magenta_terracotta
setblock 531 170 270 minecraft:magenta_terracotta
setblock 535 170 228 minecraft:magenta_terracotta
setblock 535 170 270 minecraft:magenta_terracotta
setblock 539 170 228 minecraft:magenta_terracotta
setblock 539 170 270 minecraft:magenta_terracotta
setblock 543 170 228 minecraft:magenta_terracotta
setblock 543 170 270 minecraft:magenta_terracotta
setblock 547 170 228 minecraft:magenta_terracotta
setblock 547 170 270 minecraft:magenta_terracotta
setblock 551 170 228 minecraft:magenta_terracotta
setblock 551 170 270 minecraft:magenta_terracotta
setblock 553 170 228 minecraft:black_terracotta
setblock 555 170 228 minecraft:magenta_terracotta
setblock 555 170 270 minecraft:magenta_terracotta
fill 557 170 247 557 170 248 minecraft:spruce_planks
fill 557 170 249 558 170 250 minecraft:dark_oak_planks
setblock 559 170 228 minecraft:magenta_terracotta
setblock 559 170 230 minecraft:magenta_terracotta
setblock 559 170 234 minecraft:magenta_terracotta
setblock 559 170 238 minecraft:magenta_terracotta
setblock 559 170 242 minecraft:magenta_terracotta
setblock 559 170 246 minecraft:magenta_terracotta
setblock 559 170 250 minecraft:magenta_terracotta
setblock 559 170 254 minecraft:magenta_terracotta
setblock 559 170 258 minecraft:magenta_terracotta
setblock 559 170 262 minecraft:magenta_terracotta
setblock 559 170 266 minecraft:magenta_terracotta
setblock 559 170 270 minecraft:magenta_terracotta
fill 517 171 230 517 173 230 minecraft:purple_terracotta
fill 517 171 234 517 173 234 minecraft:purple_terracotta
fill 517 171 238 517 173 238 minecraft:purple_terracotta
setblock 517 171 239 minecraft:gray_terracotta
fill 517 171 242 517 173 242 minecraft:purple_terracotta
fill 517 171 246 517 173 246 minecraft:purple_terracotta
fill 517 171 250 517 173 250 minecraft:purple_terracotta
fill 517 171 254 517 173 254 minecraft:purple_terracotta
fill 517 171 258 517 173 258 minecraft:purple_terracotta
fill 517 171 262 517 173 262 minecraft:purple_terracotta
fill 517 171 266 517 173 266 minecraft:purple_terracotta
setblock 517 171 270 minecraft:purple_terracotta
fill 519 171 228 519 173 228 minecraft:purple_terracotta
fill 519 171 270 519 173 270 minecraft:purple_terracotta
fill 523 171 228 523 173 228 minecraft:purple_terracotta
fill 523 171 270 523 173 270 minecraft:purple_terracotta
fill 527 171 228 527 173 228 minecraft:purple_terracotta
fill 527 171 270 527 173 270 minecraft:purple_terracotta
fill 531 171 228 531 173 228 minecraft:purple_terracotta
fill 531 171 270 531 173 270 minecraft:purple_terracotta
fill 535 171 228 535 173 228 minecraft:purple_terracotta
fill 535 171 270 535 173 270 minecraft:purple_terracotta
fill 539 171 228 539 173 228 minecraft:purple_terracotta
fill 539 171 270 539 173 270 minecraft:purple_terracotta
fill 543 171 228 543 173 228 minecraft:purple_terracotta
fill 543 171 270 543 173 270 minecraft:purple_terracotta
fill 547 171 228 547 173 228 minecraft:purple_terracotta
fill 547 171 270 547 173 270 minecraft:purple_terracotta
fill 551 171 228 551 173 228 minecraft:purple_terracotta
fill 551 171 270 551 173 270 minecraft:purple_terracotta
setblock 553 171 228 minecraft:purple_terracotta
fill 555 171 228 555 173 228 minecraft:purple_terracotta
fill 555 171 270 555 173 270 minecraft:purple_terracotta
fill 557 171 245 557 171 246 minecraft:spruce_planks
fill 557 171 247 558 171 248 minecraft:dark_oak_planks
setblock 559 171 228 minecraft:purple_terracotta
setblock 559 171 230 minecraft:light_gray_terracotta
fill 559 171 234 559 173 234 minecraft:purple_terracotta
fill 559 171 238 559 173 238 minecraft:purple_terracotta
fill 559 171 242 559 173 242 minecraft:purple_terracotta
fill 559 171 246 559 173 246 minecraft:purple_terracotta
fill 559 171 250 559 173 250 minecraft:purple_terracotta
fill 559 171 254 559 173 254 minecraft:purple_terracotta
fill 559 171 258 559 173 258 minecraft:purple_terracotta
fill 559 171 262 559 173 262 minecraft:purple_terracotta
fill 559 171 266 559 173 266 minecraft:purple_terracotta
fill 559 171 270 559 173 270 minecraft:purple_terracotta
setblock 517 172 228 minecraft:magenta_terracotta
setblock 517 172 232 minecraft:magenta_terracotta
setblock 517 172 236 minecraft:magenta_terracotta
fill 517 172 239 517 212 239 minecraft:purple_terracotta
setblock 517 172 240 minecraft:magenta_terracotta
setblock 517 172 244 minecraft:magenta_terracotta
setblock 517 172 248 minecraft:magenta_terracotta
setblock 517 172 252 minecraft:magenta_terracotta
setblock 517 172 256 minecraft:magenta_terracotta
setblock 517 172 260 minecraft:magenta_terracotta
setblock 517 172 264 minecraft:magenta_terracotta
setblock 517 172 268 minecraft:magenta_terracotta
setblock 517 172 270 minecraft:magenta_terracotta
setblock 520 172 231 minecraft:light[level=12]
setblock 520 172 238 minecraft:light[level=12]
setblock 520 172 245 minecraft:light[level=12]
setblock 520 172 252 minecraft:light[level=12]
setblock 520 172 259 minecraft:light[level=12]
setblock 520 172 266 minecraft:light[level=12]
setblock 521 172 228 minecraft:magenta_terracotta
setblock 521 172 270 minecraft:magenta_terracotta
setblock 525 172 228 minecraft:magenta_terracotta
setblock 525 172 270 minecraft:magenta_terracotta
setblock 527 172 231 minecraft:light[level=12]
setblock 527 172 238 minecraft:light[level=12]
setblock 527 172 245 minecraft:light[level=12]
setblock 527 172 252 minecraft:light[level=12]
setblock 527 172 259 minecraft:light[level=12]
setblock 527 172 266 minecraft:light[level=12]
setblock 529 172 228 minecraft:gray_terracotta
setblock 529 172 270 minecraft:magenta_terracotta
setblock 533 172 228 minecraft:magenta_terracotta
setblock 533 172 270 minecraft:magenta_terracotta
setblock 534 172 231 minecraft:light[level=12]
setblock 534 172 238 minecraft:light[level=12]
setblock 534 172 245 minecraft:light[level=12]
setblock 534 172 252 minecraft:light[level=12]
setblock 534 172 259 minecraft:light[level=12]
setblock 534 172 266 minecraft:light[level=12]
setblock 537 172 228 minecraft:magenta_terracotta
setblock 537 172 270 minecraft:magenta_terracotta
setblock 541 172 228 minecraft:magenta_terracotta
setblock 541 172 231 minecraft:light[level=12]
setblock 541 172 238 minecraft:light[level=12]
setblock 541 172 245 minecraft:light[level=12]
setblock 541 172 252 minecraft:light[level=12]
setblock 541 172 259 minecraft:light[level=12]
setblock 541 172 266 minecraft:light[level=12]
setblock 541 172 270 minecraft:magenta_terracotta
setblock 545 172 228 minecraft:magenta_terracotta
setblock 545 172 270 minecraft:magenta_terracotta
setblock 548 172 231 minecraft:light[level=12]
setblock 548 172 238 minecraft:light[level=12]
setblock 548 172 245 minecraft:light[level=12]
setblock 548 172 252 minecraft:light[level=12]
setblock 548 172 259 minecraft:light[level=12]
setblock 548 172 266 minecraft:light[level=12]
setblock 549 172 228 minecraft:magenta_terracotta
setblock 549 172 270 minecraft:magenta_terracotta
setblock 553 172 228 minecraft:magenta_terracotta
setblock 553 172 270 minecraft:magenta_terracotta
setblock 555 172 231 minecraft:light[level=12]
setblock 555 172 238 minecraft:light[level=12]
setblock 555 172 245 minecraft:light[level=12]
setblock 555 172 252 minecraft:light[level=12]
setblock 555 172 259 minecraft:light[level=12]
setblock 555 172 266 minecraft:light[level=12]
setblock 557 172 228 minecraft:magenta_terracotta
fill 557 172 243 557 172 244 minecraft:spruce_planks
fill 557 172 245 558 172 246 minecraft:dark_oak_planks
setblock 557 172 270 minecraft:magenta_terracotta
setblock 559 172 228 minecraft:magenta_terracotta
fill 559 172 230 559 173 230 minecraft:purple_terracotta
setblock 559 172 232 minecraft:magenta_terracotta
setblock 559 172 236 minecraft:magenta_terracotta
setblock 559 172 240 minecraft:magenta_terracotta
setblock 559 172 244 minecraft:magenta_terracotta
setblock 559 172 248 minecraft:magenta_terracotta
setblock 559 172 252 minecraft:magenta_terracotta
setblock 559 172 256 minecraft:magenta_terracotta
setblock 559 172 260 minecraft:magenta_terracotta
setblock 559 172 264 minecraft:magenta_terracotta
setblock 559 172 268 minecraft:magenta_terracotta
fill 517 173 228 517 175 228 minecraft:purple_terracotta
fill 517 173 232 517 175 232 minecraft:purple_terracotta
setblock 517 173 236 minecraft:purple_terracotta
fill 517 173 240 517 175 240 minecraft:purple_terracotta
fill 517 173 244 517 175 244 minecraft:purple_terracotta
fill 517 173 248 517 175 248 minecraft:purple_terracotta
fill 517 173 252 517 175 252 minecraft:purple_terracotta
fill 517 173 256 517 175 256 minecraft:purple_terracotta
setblock 517 173 259 minecraft:gray_terracotta
fill 517 173 260 517 175 260 minecraft:purple_terracotta
fill 517 173 264 517 175 264 minecraft:purple_terracotta
fill 517 173 268 517 175 268 minecraft:purple_terracotta
setblock 517 173 270 minecraft:purple_terracotta
fill 521 173 228 521 175 228 minecraft:purple_terracotta
fill 521 173 270 521 175 270 minecraft:purple_terracotta
fill 525 173 228 525 175 228 minecraft:purple_terracotta
fill 525 173 270 525 175 270 minecraft:purple_terracotta
fill 529 173 228 529 175 228 minecraft:purple_terracotta
fill 529 173 270 529 175 270 minecraft:purple_terracotta
fill 533 173 228 533 175 228 minecraft:purple_terracotta
fill 533 173 270 533 175 270 minecraft:purple_terracotta
fill 537 173 228 537 175 228 minecraft:purple_terracotta
fill 537 173 270 537 175 270 minecraft:purple_terracotta
fill 541 173 228 541 175 228 minecraft:purple_terracotta
fill 541 173 270 541 175 270 minecraft:purple_terracotta
fill 545 173 228 545 175 228 minecraft:purple_terracotta
fill 545 173 270 545 175 270 minecraft:purple_terracotta
fill 549 173 228 549 175 228 minecraft:purple_terracotta
fill 549 173 270 549 175 270 minecraft:purple_terracotta
fill 553 173 228 553 175 228 minecraft:purple_terracotta
fill 553 173 270 553 175 270 minecraft:purple_terracotta
fill 557 173 228 557 175 228 minecraft:purple_terracotta
fill 557 173 241 557 173 242 minecraft:spruce_planks
fill 557 173 243 558 173 244 minecraft:dark_oak_planks
fill 557 173 270 557 175 270 minecraft:purple_terracotta
setblock 559 173 228 minecraft:purple_terracotta
fill 559 173 232 559 175 232 minecraft:purple_terracotta
setblock 559 173 236 minecraft:light_gray_terracotta
fill 559 173 240 559 175 240 minecraft:purple_terracotta
fill 559 173 244 559 175 244 minecraft:purple_terracotta
fill 559 173 248 559 175 248 minecraft:purple_terracotta
fill 559 173 252 559 175 252 minecraft:purple_terracotta
fill 559 173 256 559 175 256 minecraft:purple_terracotta
fill 559 173 260 559 175 260 minecraft:purple_terracotta
fill 559 173 264 559 175 264 minecraft:purple_terracotta
fill 559 173 268 559 175 268 minecraft:purple_terracotta
setblock 517 174 230 minecraft:magenta_terracotta
setblock 517 174 234 minecraft:magenta_terracotta
setblock 517 174 236 minecraft:gray_terracotta
setblock 517 174 238 minecraft:magenta_terracotta
setblock 517 174 242 minecraft:magenta_terracotta
setblock 517 174 246 minecraft:magenta_terracotta
setblock 517 174 250 minecraft:magenta_terracotta
setblock 517 174 254 minecraft:magenta_terracotta
setblock 517 174 258 minecraft:magenta_terracotta
fill 517 174 259 517 212 259 minecraft:purple_terracotta
setblock 517 174 262 minecraft:magenta_terracotta
setblock 517 174 266 minecraft:magenta_terracotta
setblock 517 174 270 minecraft:magenta_terracotta
setblock 519 174 228 minecraft:magenta_terracotta
setblock 519 174 270 minecraft:magenta_terracotta
setblock 523 174 228 minecraft:magenta_terracotta
setblock 523 174 270 minecraft:magenta_terracotta
setblock 527 174 228 minecraft:magenta_terracotta
setblock 527 174 270 minecraft:magenta_terracotta
setblock 531 174 228 minecraft:magenta_terracotta
setblock 531 174 270 minecraft:magenta_terracotta
setblock 535 174 228 minecraft:magenta_terracotta
setblock 535 174 270 minecraft:magenta_terracotta
setblock 539 174 228 minecraft:magenta_terracotta
setblock 539 174 270 minecraft:magenta_terracotta
setblock 543 174 228 minecraft:magenta_terracotta
setblock 543 174 270 minecraft:magenta_terracotta
setblock 547 174 228 minecraft:magenta_terracotta
setblock 547 174 270 minecraft:magenta_terracotta
setblock 551 174 228 minecraft:magenta_terracotta
setblock 551 174 270 minecraft:magenta_terracotta
setblock 555 174 228 minecraft:magenta_terracotta
setblock 555 174 270 minecraft:magenta_terracotta
fill 557 174 239 557 174 240 minecraft:spruce_planks
fill 557 174 241 558 174 242 minecraft:dark_oak_planks
setblock 559 174 228 minecraft:magenta_terracotta
setblock 559 174 230 minecraft:magenta_terracotta
setblock 559 174 234 minecraft:magenta_terracotta
fill 559 174 236 559 175 236 minecraft:purple_terracotta
setblock 559 174 238 minecraft:magenta_terracotta
setblock 559 174 242 minecraft:magenta_terracotta
setblock 559 174 246 minecraft:magenta_terracotta
setblock 559 174 250 minecraft:magenta_terracotta
setblock 559 174 254 minecraft:magenta_terracotta
setblock 559 174 258 minecraft:magenta_terracotta
setblock 559 174 262 minecraft:magenta_terracotta
setblock 559 174 266 minecraft:magenta_terracotta
setblock 559 174 270 minecraft:magenta_terracotta
fill 517 175 230 517 177 230 minecraft:purple_terracotta
fill 517 175 234 517 177 234 minecraft:purple_terracotta
setblock 517 175 236 minecraft:purple_terracotta
fill 517 175 238 517 177 238 minecraft:purple_terracotta
fill 517 175 242 517 177 242 minecraft:purple_terracotta
fill 517 175 246 517 177 246 minecraft:purple_terracotta
fill 517 175 250 517 177 250 minecraft:purple_terracotta
fill 517 175 254 517 177 254 minecraft:purple_terracotta
fill 517 175 258 517 177 258 minecraft:purple_terracotta
fill 517 175 262 517 177 262 minecraft:purple_terracotta
fill 517 175 266 517 177 266 minecraft:purple_terracotta
setblock 517 175 270 minecraft:purple_terracotta
fill 519 175 228 519 177 228 minecraft:purple_terracotta
fill 519 175 270 519 177 270 minecraft:purple_terracotta
fill 523 175 228 523 177 228 minecraft:purple_terracotta
fill 523 175 270 523 177 270 minecraft:purple_terracotta
fill 527 175 228 527 177 228 minecraft:purple_terracotta
fill 527 175 270 527 177 270 minecraft:purple_terracotta
fill 531 175 228 531 177 228 minecraft:purple_terracotta
fill 531 175 270 531 177 270 minecraft:purple_terracotta
fill 535 175 228 535 177 228 minecraft:purple_terracotta
fill 535 175 270 535 177 270 minecraft:purple_terracotta
fill 539 175 228 539 177 228 minecraft:purple_terracotta
fill 539 175 270 539 177 270 minecraft:purple_terracotta
fill 543 175 228 543 177 228 minecraft:purple_terracotta
fill 543 175 270 543 177 270 minecraft:purple_terracotta
fill 547 175 228 547 177 228 minecraft:purple_terracotta
fill 547 175 270 547 177 270 minecraft:purple_terracotta
fill 551 175 228 551 177 228 minecraft:purple_terracotta
fill 551 175 270 551 177 270 minecraft:purple_terracotta
fill 552 175 245 552 178 245 minecraft:iron_bars
fill 555 175 228 555 177 228 minecraft:purple_terracotta
fill 555 175 270 555 177 270 minecraft:purple_terracotta
fill 557 175 237 557 175 238 minecraft:spruce_planks
fill 557 175 239 558 175 240 minecraft:dark_oak_planks
setblock 559 175 228 minecraft:purple_terracotta
fill 559 175 230 559 177 230 minecraft:purple_terracotta
fill 559 175 234 559 177 234 minecraft:purple_terracotta
fill 559 175 238 559 177 238 minecraft:purple_terracotta
fill 559 175 242 559 177 242 minecraft:purple_terracotta
fill 559 175 246 559 177 246 minecraft:purple_terracotta
fill 559 175 250 559 177 250 minecraft:purple_terracotta
fill 559 175 254 559 177 254 minecraft:purple_terracotta
fill 559 175 258 559 177 258 minecraft:purple_terracotta
fill 559 175 262 559 177 262 minecraft:purple_terracotta
fill 559 175 266 559 177 266 minecraft:purple_terracotta
fill 559 175 270 559 177 270 minecraft:purple_terracotta
setblock 517 176 228 minecraft:magenta_terracotta
setblock 517 176 232 minecraft:magenta_terracotta
setblock 517 176 236 minecraft:magenta_terracotta
setblock 517 176 240 minecraft:magenta_terracotta
setblock 517 176 243 minecraft:light_gray_terracotta
setblock 517 176 244 minecraft:magenta_terracotta
setblock 517 176 248 minecraft:magenta_terracotta
setblock 517 176 252 minecraft:magenta_terracotta
setblock 517 176 256 minecraft:magenta_terracotta
setblock 517 176 260 minecraft:magenta_terracotta
setblock 517 176 264 minecraft:magenta_terracotta
setblock 517 176 268 minecraft:magenta_terracotta
setblock 517 176 270 minecraft:magenta_terracotta
setblock 520 176 231 minecraft:light[level=11]
setblock 520 176 239 minecraft:light[level=11]
setblock 520 176 247 minecraft:light[level=11]
setblock 520 176 255 minecraft:light[level=11]
setblock 520 176 263 minecraft:light[level=11]
setblock 521 176 228 minecraft:magenta_terracotta
setblock 521 176 270 minecraft:magenta_terracotta
setblock 525 176 228 minecraft:magenta_terracotta
setblock 525 176 270 minecraft:magenta_terracotta
setblock 528 176 231 minecraft:light[level=11]
setblock 528 176 239 minecraft:light[level=11]
setblock 528 176 247 minecraft:light[level=11]
setblock 528 176 255 minecraft:light[level=11]
setblock 528 176 263 minecraft:light[level=11]
setblock 529 176 228 minecraft:magenta_terracotta
setblock 529 176 270 minecraft:magenta_terracotta
setblock 533 176 228 minecraft:magenta_terracotta
setblock 533 176 270 minecraft:magenta_terracotta
setblock 536 176 231 minecraft:light[level=11]
setblock 536 176 239 minecraft:light[level=11]
setblock 536 176 247 minecraft:light[level=11]
setblock 536 176 255 minecraft:light[level=11]
setblock 536 176 263 minecraft:light[level=11]
setblock 537 176 228 minecraft:magenta_terracotta
setblock 537 176 270 minecraft:magenta_terracotta
setblock 541 176 228 minecraft:magenta_terracotta
setblock 541 176 270 minecraft:magenta_terracotta
setblock 544 176 231 minecraft:light[level=11]
setblock 544 176 239 minecraft:light[level=11]
setblock 544 176 247 minecraft:light[level=11]
setblock 544 176 255 minecraft:light[level=11]
setblock 544 176 263 minecraft:light[level=11]
setblock 545 176 228 minecraft:magenta_terracotta
setblock 545 176 270 minecraft:magenta_terracotta
setblock 549 176 228 minecraft:magenta_terracotta
setblock 549 176 270 minecraft:magenta_terracotta
setblock 552 176 231 minecraft:light[level=11]
setblock 552 176 239 minecraft:light[level=11]
setblock 552 176 247 minecraft:light[level=11]
setblock 552 176 255 minecraft:light[level=11]
setblock 552 176 263 minecraft:light[level=11]
setblock 553 176 228 minecraft:magenta_terracotta
setblock 553 176 270 minecraft:magenta_terracotta
setblock 557 176 228 minecraft:magenta_terracotta
fill 557 176 235 557 176 236 minecraft:spruce_planks
fill 557 176 237 558 176 238 minecraft:dark_oak_planks
setblock 557 176 270 minecraft:magenta_terracotta
setblock 559 176 228 minecraft:magenta_terracotta
setblock 559 176 232 minecraft:magenta_terracotta
setblock 559 176 236 minecraft:magenta_terracotta
setblock 559 176 240 minecraft:magenta_terracotta
setblock 559 176 244 minecraft:magenta_terracotta
setblock 559 176 248 minecraft:magenta_terracotta
setblock 559 176 252 minecraft:magenta_terracotta
setblock 559 176 256 minecraft:magenta_terracotta
setblock 559 176 260 minecraft:magenta_terracotta
setblock 559 176 264 minecraft:magenta_terracotta
setblock 559 176 265 minecraft:gray_terracotta
setblock 559 176 268 minecraft:magenta_terracotta
fill 517 177 228 517 179 228 minecraft:purple_terracotta
fill 517 177 232 517 179 232 minecraft:purple_terracotta
fill 517 177 236 517 179 236 minecraft:purple_terracotta
fill 517 177 240 517 179 240 minecraft:purple_terracotta
fill 517 177 243 517 179 244 minecraft:purple_terracotta
fill 517 177 248 517 179 248 minecraft:purple_terracotta
fill 517 177 252 517 179 252 minecraft:purple_terracotta
fill 517 177 256 517 179 256 minecraft:purple_terracotta
fill 517 177 260 517 179 260 minecraft:purple_terracotta
fill 517 177 264 517 179 264 minecraft:purple_terracotta
fill 517 177 268 517 179 268 minecraft:purple_terracotta
setblock 517 177 270 minecraft:purple_terracotta
fill 521 177 228 521 179 228 minecraft:purple_terracotta
fill 521 177 270 521 179 270 minecraft:purple_terracotta
fill 525 177 228 525 179 228 minecraft:purple_terracotta
fill 525 177 270 525 179 270 minecraft:purple_terracotta
fill 529 177 228 529 179 228 minecraft:purple_terracotta
fill 529 177 270 529 179 270 minecraft:purple_terracotta
fill 533 177 228 533 179 228 minecraft:purple_terracotta
fill 533 177 270 533 179 270 minecraft:purple_terracotta
fill 537 177 228 537 179 228 minecraft:purple_terracotta
fill 537 177 270 537 179 270 minecraft:purple_terracotta
fill 541 177 228 541 178 228 minecraft:purple_terracotta
fill 541 177 270 541 179 270 minecraft:purple_terracotta
fill 545 177 228 545 179 228 minecraft:purple_terracotta
fill 545 177 270 545 179 270 minecraft:purple_terracotta
fill 549 177 228 549 179 228 minecraft:purple_terracotta
fill 549 177 270 549 179 270 minecraft:purple_terracotta
fill 553 177 228 553 179 228 minecraft:purple_terracotta
fill 553 177 270 553 179 270 minecraft:purple_terracotta
fill 557 177 228 557 179 228 minecraft:purple_terracotta
fill 557 177 233 557 177 234 minecraft:spruce_planks
fill 557 177 235 558 177 236 minecraft:dark_oak_planks
fill 557 177 270 557 179 270 minecraft:purple_terracotta
setblock 559 177 228 minecraft:purple_terracotta
fill 559 177 232 559 179 232 minecraft:purple_terracotta
fill 559 177 236 559 179 236 minecraft:purple_terracotta
fill 559 177 240 559 179 240 minecraft:purple_terracotta
fill 559 177 244 559 179 244 minecraft:purple_terracotta
fill 559 177 248 559 179 248 minecraft:purple_terracotta
fill 559 177 252 559 179 252 minecraft:purple_terracotta
fill 559 177 256 559 179 256 minecraft:purple_terracotta
fill 559 177 260 559 179 260 minecraft:purple_terracotta
fill 559 177 264 559 179 265 minecraft:purple_terracotta
fill 559 177 268 559 179 268 minecraft:purple_terracotta
setblock 517 178 230 minecraft:magenta_terracotta
setblock 517 178 234 minecraft:magenta_terracotta
setblock 517 178 238 minecraft:magenta_terracotta
setblock 517 178 242 minecraft:magenta_terracotta
setblock 517 178 246 minecraft:magenta_terracotta
setblock 517 178 250 minecraft:magenta_terracotta
setblock 517 178 254 minecraft:magenta_terracotta
setblock 517 178 258 minecraft:magenta_terracotta
setblock 517 178 262 minecraft:magenta_terracotta
setblock 517 178 266 minecraft:magenta_terracotta
setblock 517 178 270 minecraft:magenta_terracotta
setblock 519 178 228 minecraft:magenta_terracotta
setblock 519 178 270 minecraft:magenta_terracotta
setblock 520 178 231 minecraft:light[level=12]
setblock 520 178 238 minecraft:light[level=12]
setblock 520 178 245 minecraft:light[level=12]
setblock 520 178 252 minecraft:light[level=12]
setblock 520 178 259 minecraft:light[level=12]
setblock 520 178 266 minecraft:light[level=12]
setblock 523 178 228 minecraft:magenta_terracotta
setblock 523 178 270 minecraft:magenta_terracotta
setblock 527 178 228 minecraft:magenta_terracotta
setblock 527 178 231 minecraft:light[level=12]
setblock 527 178 238 minecraft:light[level=12]
setblock 527 178 245 minecraft:light[level=12]
setblock 527 178 252 minecraft:light[level=12]
setblock 527 178 259 minecraft:light[level=12]
setblock 527 178 266 minecraft:light[level=12]
setblock 527 178 270 minecraft:magenta_terracotta
setblock 531 178 228 minecraft:magenta_terracotta
setblock 531 178 270 minecraft:magenta_terracotta
setblock 534 178 231 minecraft:light[level=12]
setblock 534 178 238 minecraft:light[level=12]
setblock 534 178 245 minecraft:light[level=12]
setblock 534 178 252 minecraft:light[level=12]
setblock 534 178 259 minecraft:light[level=12]
setblock 534 178 266 minecraft:light[level=12]
setblock 535 178 228 minecraft:magenta_terracotta
setblock 535 178 270 minecraft:magenta_terracotta
setblock 539 178 228 minecraft:magenta_terracotta
setblock 539 178 270 minecraft:magenta_terracotta
setblock 541 178 231 minecraft:light[level=12]
setblock 541 178 238 minecraft:light[level=12]
setblock 541 178 245 minecraft:light[level=12]
setblock 541 178 252 minecraft:light[level=12]
setblock 541 178 259 minecraft:light[level=12]
setblock 541 178 266 minecraft:light[level=12]
setblock 543 178 228 minecraft:magenta_terracotta
setblock 543 178 270 minecraft:magenta_terracotta
setblock 546 178 228 minecraft:black_terracotta
setblock 547 178 228 minecraft:magenta_terracotta
setblock 547 178 270 minecraft:magenta_terracotta
setblock 548 178 231 minecraft:light[level=12]
setblock 548 178 238 minecraft:light[level=12]
setblock 548 178 245 minecraft:light[level=12]
setblock 548 178 252 minecraft:light[level=12]
setblock 548 178 259 minecraft:light[level=12]
setblock 548 178 266 minecraft:light[level=12]
setblock 551 178 228 minecraft:magenta_terracotta
setblock 551 178 270 minecraft:magenta_terracotta
setblock 555 178 228 minecraft:magenta_terracotta
setblock 555 178 231 minecraft:light[level=12]
setblock 555 178 238 minecraft:light[level=12]
setblock 555 178 245 minecraft:light[level=12]
setblock 555 178 252 minecraft:light[level=12]
setblock 555 178 259 minecraft:light[level=12]
setblock 555 178 266 minecraft:light[level=12]
setblock 555 178 270 minecraft:magenta_terracotta
fill 557 178 231 557 178 232 minecraft:spruce_planks
fill 557 178 233 558 178 234 minecraft:dark_oak_planks
setblock 559 178 228 minecraft:magenta_terracotta
setblock 559 178 230 minecraft:magenta_terracotta
setblock 559 178 234 minecraft:magenta_terracotta
setblock 559 178 238 minecraft:magenta_terracotta
setblock 559 178 242 minecraft:magenta_terracotta
setblock 559 178 246 minecraft:magenta_terracotta
setblock 559 178 250 minecraft:magenta_terracotta
setblock 559 178 254 minecraft:magenta_terracotta
setblock 559 178 258 minecraft:magenta_terracotta
setblock 559 178 262 minecraft:magenta_terracotta
setblock 559 178 266 minecraft:magenta_terracotta
setblock 559 178 270 minecraft:magenta_terracotta
fill 517 179 230 517 181 230 minecraft:purple_terracotta
fill 517 179 234 517 181 234 minecraft:purple_terracotta
fill 517 179 238 517 181 238 minecraft:purple_terracotta
fill 517 179 242 517 181 242 minecraft:purple_terracotta
fill 517 179 246 517 181 246 minecraft:purple_terracotta
fill 517 179 250 517 181 250 minecraft:purple_terracotta
fill 517 179 254 517 181 254 minecraft:purple_terracotta
fill 517 179 258 517 181 258 minecraft:purple_terracotta
fill 517 179 262 517 181 262 minecraft:purple_terracotta
fill 517 179 266 517 181 266 minecraft:purple_terracotta
setblock 517 179 270 minecraft:purple_terracotta
fill 519 179 228 519 181 228 minecraft:purple_terracotta
fill 519 179 270 519 181 270 minecraft:purple_terracotta
fill 523 179 228 523 181 228 minecraft:purple_terracotta
fill 523 179 270 523 181 270 minecraft:purple_terracotta
fill 527 179 228 527 181 228 minecraft:purple_terracotta
fill 527 179 270 527 181 270 minecraft:purple_terracotta
fill 531 179 228 531 181 228 minecraft:purple_terracotta
fill 531 179 270 531 181 270 minecraft:purple_terracotta
fill 535 179 228 535 181 228 minecraft:purple_terracotta
fill 535 179 270 535 181 270 minecraft:purple_terracotta
fill 539 179 228 539 181 228 minecraft:purple_terracotta
fill 539 179 270 539 181 270 minecraft:purple_terracotta
setblock 541 179 228 minecraft:gray_terracotta
fill 543 179 228 543 181 228 minecraft:purple_terracotta
fill 543 179 270 543 181 270 minecraft:purple_terracotta
fill 546 179 228 547 181 228 minecraft:purple_terracotta
fill 547 179 270 547 181 270 minecraft:purple_terracotta
fill 551 179 228 551 181 228 minecraft:purple_terracotta
fill 551 179 270 551 181 270 minecraft:purple_terracotta
fill 552 179 241 557 179 249 minecraft:dark_oak_planks
fill 555 179 228 555 181 228 minecraft:purple_terracotta
fill 555 179 270 555 181 270 minecraft:purple_terracotta
setblock 557 179 230 minecraft:spruce_planks
fill 557 179 231 558 179 232 minecraft:dark_oak_planks
setblock 559 179 228 minecraft:purple_terracotta
fill 559 179 230 559 181 230 minecraft:purple_terracotta
fill 559 179 234 559 181 234 minecraft:purple_terracotta
fill 559 179 238 559 181 238 minecraft:purple_terracotta
fill 559 179 242 559 181 242 minecraft:purple_terracotta
fill 559 179 246 559 181 246 minecraft:purple_terracotta
setblock 559 179 247 minecraft:gray_terracotta
fill 559 179 250 559 181 250 minecraft:purple_terracotta
fill 559 179 254 559 181 254 minecraft:purple_terracotta
fill 559 179 258 559 181 258 minecraft:purple_terracotta
fill 559 179 262 559 181 262 minecraft:purple_terracotta
fill 559 179 266 559 181 266 minecraft:purple_terracotta
fill 559 179 270 559 181 270 minecraft:purple_terracotta
setblock 517 180 228 minecraft:magenta_terracotta
setblock 517 180 232 minecraft:magenta_terracotta
setblock 517 180 236 minecraft:magenta_terracotta
setblock 517 180 240 minecraft:magenta_terracotta
fill 517 180 243 517 199 243 minecraft:purple_terracotta
setblock 517 180 244 minecraft:magenta_terracotta
setblock 517 180 248 minecraft:magenta_terracotta
setblock 517 180 252 minecraft:magenta_terracotta
setblock 517 180 256 minecraft:magenta_terracotta
setblock 517 180 260 minecraft:magenta_terracotta
setblock 517 180 264 minecraft:magenta_terracotta
setblock 517 180 268 minecraft:magenta_terracotta
setblock 517 180 270 minecraft:magenta_terracotta
setblock 521 180 228 minecraft:magenta_terracotta
setblock 521 180 270 minecraft:magenta_terracotta
setblock 525 180 228 minecraft:magenta_terracotta
fill 525 180 253 525 182 253 minecraft:white_stained_glass
setblock 525 180 270 minecraft:magenta_terracotta
fill 526 180 252 526 182 252 minecraft:white_stained_glass
fill 526 180 254 527 182 254 minecraft:white_stained_glass
fill 527 180 253 527 182 253 minecraft:white_stained_glass
setblock 529 180 228 minecraft:magenta_terracotta
setblock 529 180 270 minecraft:magenta_terracotta
setblock 533 180 228 minecraft:magenta_terracotta
setblock 533 180 270 minecraft:magenta_terracotta
setblock 537 180 228 minecraft:magenta_terracotta
setblock 537 180 270 minecraft:magenta_terracotta
setblock 541 180 228 minecraft:magenta_terracotta
setblock 541 180 270 minecraft:magenta_terracotta
setblock 545 180 228 minecraft:magenta_terracotta
setblock 545 180 270 minecraft:magenta_terracotta
setblock 549 180 228 minecraft:magenta_terracotta
setblock 549 180 270 minecraft:magenta_terracotta
fill 552 180 241 557 180 249 minecraft:stripped_dark_oak_log
setblock 553 180 228 minecraft:magenta_terracotta
setblock 553 180 270 minecraft:magenta_terracotta
fill 555 180 230 556 180 230 minecraft:spruce_planks
setblock 557 180 228 minecraft:magenta_terracotta
fill 557 180 229 558 180 230 minecraft:dark_oak_planks
setblock 557 180 270 minecraft:magenta_terracotta
setblock 559 180 228 minecraft:magenta_terracotta
setblock 559 180 232 minecraft:magenta_terracotta
setblock 559 180 236 minecraft:magenta_terracotta
setblock 559 180 240 minecraft:magenta_terracotta
setblock 559 180 241 minecraft:gray_terracotta
setblock 559 180 244 minecraft:magenta_terracotta
fill 559 180 247 559 212 247 minecraft:purple_terracotta
setblock 559 180 248 minecraft:magenta_terracotta
setblock 559 180 252 minecraft:magenta_terracotta
setblock 559 180 256 minecraft:magenta_terracotta
setblock 559 180 260 minecraft:magenta_terracotta
setblock 559 180 264 minecraft:magenta_terracotta
fill 559 180 265 559 212 265 minecraft:purple_terracotta
setblock 559 180 268 minecraft:magenta_terracotta
fill 517 181 228 517 183 228 minecraft:purple_terracotta
fill 517 181 232 517 183 232 minecraft:purple_terracotta
fill 517 181 236 517 183 236 minecraft:purple_terracotta
fill 517 181 240 517 183 240 minecraft:purple_terracotta
fill 517 181 244 517 183 244 minecraft:purple_terracotta
fill 517 181 248 517 183 248 minecraft:purple_terracotta
fill 517 181 252 517 183 252 minecraft:purple_terracotta
fill 517 181 256 517 183 256 minecraft:purple_terracotta
fill 517 181 260 517 183 260 minecraft:purple_terracotta
fill 517 181 264 517 183 264 minecraft:purple_terracotta
fill 517 181 268 517 183 268 minecraft:purple_terracotta
setblock 517 181 270 minecraft:purple_terracotta
fill 521 181 228 521 183 228 minecraft:purple_terracotta
fill 521 181 270 521 183 270 minecraft:purple_terracotta
fill 525 181 228 525 183 228 minecraft:purple_terracotta
fill 525 181 252 525 183 252 minecraft:white_stained_glass
fill 525 181 254 525 182 255 minecraft:white_stained_glass
fill 525 181 270 525 183 270 minecraft:purple_terracotta
fill 526 181 253 526 182 253 minecraft:white_stained_glass
fill 526 181 255 527 183 255 minecraft:white_stained_glass
fill 527 181 252 527 183 252 minecraft:white_stained_glass
fill 528 181 253 528 184 254 minecraft:white_stained_glass
fill 529 181 228 529 183 228 minecraft:purple_terracotta
fill 529 181 270 529 183 270 minecraft:purple_terracotta
fill 533 181 228 533 183 228 minecraft:purple_terracotta
fill 533 181 270 533 183 270 minecraft:purple_terracotta
fill 537 181 228 537 183 228 minecraft:purple_terracotta
fill 537 181 270 537 183 270 minecraft:purple_terracotta
fill 541 181 228 541 183 228 minecraft:purple_terracotta
fill 541 181 270 541 183 270 minecraft:purple_terracotta
fill 545 181 228 545 183 228 minecraft:purple_terracotta
fill 545 181 270 545 183 270 minecraft:purple_terracotta
fill 549 181 228 549 183 228 minecraft:purple_terracotta
fill 549 181 270 549 183 270 minecraft:purple_terracotta
fill 552 181 241 552 181 249 minecraft:purple_concrete
fill 553 181 228 553 183 228 minecraft:purple_terracotta
fill 553 181 230 554 181 230 minecraft:spruce_planks
fill 553 181 270 553 183 270 minecraft:purple_terracotta
fill 555 181 229 556 181 230 minecraft:dark_oak_planks
fill 557 181 228 557 183 228 minecraft:purple_terracotta
fill 557 181 270 557 183 270 minecraft:purple_terracotta
fill 558 181 244 558 184 246 minecraft:jack_o_lantern
setblock 559 181 228 minecraft:purple_terracotta
fill 559 181 232 559 183 232 minecraft:purple_terracotta
fill 559 181 236 559 183 236 minecraft:purple_terracotta
fill 559 181 240 559 183 241 minecraft:purple_terracotta
fill 559 181 244 559 183 244 minecraft:purple_terracotta
fill 559 181 248 559 183 248 minecraft:purple_terracotta
fill 559 181 252 559 183 252 minecraft:purple_terracotta
fill 559 181 256 559 183 256 minecraft:purple_terracotta
fill 559 181 260 559 183 260 minecraft:purple_terracotta
fill 559 181 264 559 183 264 minecraft:purple_terracotta
fill 559 181 268 559 183 268 minecraft:purple_terracotta
setblock 517 182 230 minecraft:magenta_terracotta
setblock 517 182 234 minecraft:magenta_terracotta
setblock 517 182 238 minecraft:magenta_terracotta
setblock 517 182 242 minecraft:magenta_terracotta
setblock 517 182 246 minecraft:magenta_terracotta
setblock 517 182 250 minecraft:magenta_terracotta
setblock 517 182 254 minecraft:magenta_terracotta
setblock 517 182 258 minecraft:magenta_terracotta
setblock 517 182 262 minecraft:magenta_terracotta
setblock 517 182 266 minecraft:magenta_terracotta
setblock 517 182 270 minecraft:magenta_terracotta
setblock 519 182 228 minecraft:magenta_terracotta
setblock 519 182 270 minecraft:magenta_terracotta
setblock 523 182 228 minecraft:magenta_terracotta
setblock 523 182 270 minecraft:magenta_terracotta
fill 524 182 253 524 183 253 minecraft:white_stained_glass
setblock 527 182 228 minecraft:magenta_terracotta
setblock 527 182 270 minecraft:magenta_terracotta
setblock 531 182 228 minecraft:magenta_terracotta
setblock 531 182 270 minecraft:magenta_terracotta
setblock 535 182 228 minecraft:magenta_terracotta
setblock 535 182 270 minecraft:magenta_terracotta
setblock 539 182 228 minecraft:magenta_terracotta
setblock 539 182 270 minecraft:magenta_terracotta
setblock 543 182 228 minecraft:magenta_terracotta
setblock 543 182 270 minecraft:magenta_terracotta
fill 546 182 228 546 191 228 minecraft:purple_terracotta
setblock 547 182 228 minecraft:magenta_terracotta
setblock 547 182 270 minecraft:magenta_terracotta
setblock 551 182 228 minecraft:magenta_terracotta
fill 551 182 230 552 182 230 minecraft:spruce_planks
setblock 551 182 270 minecraft:magenta_terracotta
setblock 552 182 241 minecraft:stripped_dark_oak_log
setblock 552 182 245 minecraft:stripped_dark_oak_log
setblock 552 182 249 minecraft:stripped_dark_oak_log
fill 553 182 229 554 182 230 minecraft:dark_oak_planks
setblock 555 182 228 minecraft:magenta_terracotta
setblock 555 182 270 minecraft:magenta_terracotta
setblock 559 182 228 minecraft:magenta_terracotta
setblock 559 182 230 minecraft:magenta_terracotta
setblock 559 182 234 minecraft:magenta_terracotta
setblock 559 182 238 minecraft:magenta_terracotta
setblock 559 182 242 minecraft:magenta_terracotta
setblock 559 182 246 minecraft:magenta_terracotta
setblock 559 182 250 minecraft:magenta_terracotta
setblock 559 182 254 minecraft:magenta_terracotta
setblock 559 182 258 minecraft:magenta_terracotta
setblock 559 182 262 minecraft:magenta_terracotta
setblock 559 182 266 minecraft:magenta_terracotta
setblock 559 182 270 minecraft:magenta_terracotta
fill 517 183 230 517 185 230 minecraft:purple_terracotta
fill 517 183 234 517 185 234 minecraft:purple_terracotta
fill 517 183 238 517 185 238 minecraft:purple_terracotta
fill 517 183 242 517 185 242 minecraft:purple_terracotta
fill 517 183 246 517 185 246 minecraft:purple_terracotta
fill 517 183 250 517 185 250 minecraft:purple_terracotta
fill 517 183 254 517 185 254 minecraft:purple_terracotta
fill 517 183 258 517 185 258 minecraft:purple_terracotta
fill 517 183 262 517 185 262 minecraft:purple_terracotta
fill 517 183 266 517 185 266 minecraft:purple_terracotta
setblock 517 183 270 minecraft:purple_terracotta
fill 519 183 228 519 185 228 minecraft:purple_terracotta
fill 519 183 270 519 185 270 minecraft:purple_terracotta
fill 523 183 228 523 185 228 minecraft:purple_terracotta
fill 523 183 270 523 185 270 minecraft:purple_terracotta
fill 525 183 253 527 185 254 minecraft:white_concrete
fill 525 183 255 525 184 255 minecraft:white_stained_glass
setblock 526 183 252 minecraft:black_concrete
fill 527 183 228 527 185 228 minecraft:purple_terracotta
fill 527 183 270 527 185 270 minecraft:purple_terracotta
fill 531 183 228 531 185 228 minecraft:purple_terracotta
fill 531 183 270 531 185 270 minecraft:purple_terracotta
fill 535 183 228 535 185 228 minecraft:purple_terracotta
fill 535 183 270 535 185 270 minecraft:purple_terracotta
fill 539 183 228 539 185 228 minecraft:purple_terracotta
fill 539 183 270 539 185 270 minecraft:purple_terracotta
fill 543 183 228 543 185 228 minecraft:purple_terracotta
fill 543 183 270 543 185 270 minecraft:purple_terracotta
fill 547 183 228 547 185 228 minecraft:purple_terracotta
fill 547 183 270 547 185 270 minecraft:purple_terracotta
fill 549 183 230 550 183 230 minecraft:spruce_planks
fill 551 183 228 551 185 228 minecraft:purple_terracotta
fill 551 183 229 552 183 230 minecraft:dark_oak_planks
fill 551 183 270 551 185 270 minecraft:purple_terracotta
fill 555 183 228 555 185 228 minecraft:purple_terracotta
fill 555 183 270 555 185 270 minecraft:purple_terracotta
setblock 559 183 228 minecraft:purple_terracotta
fill 559 183 230 559 185 230 minecraft:purple_terracotta
fill 559 183 234 559 185 234 minecraft:purple_terracotta
fill 559 183 238 559 185 238 minecraft:purple_terracotta
fill 559 183 242 559 185 242 minecraft:purple_terracotta
fill 559 183 246 559 185 246 minecraft:purple_terracotta
fill 559 183 250 559 185 250 minecraft:purple_terracotta
fill 559 183 254 559 185 254 minecraft:purple_terracotta
fill 559 183 258 559 185 258 minecraft:purple_terracotta
fill 559 183 262 559 185 262 minecraft:purple_terracotta
fill 559 183 266 559 185 266 minecraft:purple_terracotta
fill 559 183 270 559 185 270 minecraft:purple_terracotta
setblock 517 184 228 minecraft:magenta_terracotta
setblock 517 184 232 minecraft:magenta_terracotta
setblock 517 184 236 minecraft:magenta_terracotta
setblock 517 184 240 minecraft:magenta_terracotta
setblock 517 184 244 minecraft:magenta_terracotta
setblock 517 184 248 minecraft:magenta_terracotta
setblock 517 184 252 minecraft:magenta_terracotta
setblock 517 184 256 minecraft:magenta_terracotta
setblock 517 184 260 minecraft:magenta_terracotta
setblock 517 184 264 minecraft:magenta_terracotta
setblock 517 184 268 minecraft:magenta_terracotta
setblock 517 184 270 minecraft:magenta_terracotta
setblock 520 184 231 minecraft:light[level=11]
setblock 520 184 238 minecraft:light[level=12]
setblock 520 184 239 minecraft:light[level=11]
setblock 520 184 245 minecraft:light[level=12]
setblock 520 184 247 minecraft:light[level=11]
setblock 520 184 252 minecraft:light[level=12]
setblock 520 184 255 minecraft:light[level=11]
setblock 520 184 259 minecraft:light[level=12]
setblock 520 184 263 minecraft:light[level=11]
setblock 520 184 266 minecraft:light[level=12]
setblock 521 184 228 minecraft:magenta_terracotta
setblock 521 184 270 minecraft:magenta_terracotta
setblock 525 184 228 minecraft:magenta_terracotta
setblock 525 184 252 minecraft:black_concrete
setblock 525 184 270 minecraft:magenta_terracotta
fill 526 184 252 526 185 252 minecraft:white_concrete
setblock 526 184 255 minecraft:white_concrete
setblock 527 184 231 minecraft:light[level=12]
setblock 527 184 238 minecraft:light[level=12]
setblock 527 184 245 minecraft:light[level=12]
setblock 527 184 252 minecraft:black_concrete
setblock 527 184 255 minecraft:white_stained_glass
setblock 527 184 259 minecraft:light[level=12]
setblock 527 184 266 minecraft:light[level=12]
setblock 528 184 231 minecraft:light[level=11]
setblock 528 184 239 minecraft:light[level=11]
setblock 528 184 247 minecraft:light[level=11]
setblock 528 184 255 minecraft:light[level=11]
setblock 528 184 263 minecraft:light[level=11]
setblock 529 184 228 minecraft:magenta_terracotta
setblock 529 184 270 minecraft:magenta_terracotta
setblock 533 184 228 minecraft:magenta_terracotta
setblock 533 184 270 minecraft:magenta_terracotta
setblock 534 184 231 minecraft:light[level=12]
setblock 534 184 238 minecraft:light[level=12]
setblock 534 184 245 minecraft:light[level=12]
setblock 534 184 252 minecraft:light[level=12]
setblock 534 184 259 minecraft:light[level=12]
setblock 534 184 266 minecraft:light[level=12]
setblock 536 184 231 minecraft:light[level=11]
setblock 536 184 239 minecraft:light[level=11]
setblock 536 184 247 minecraft:light[level=11]
setblock 536 184 255 minecraft:light[level=11]
setblock 536 184 263 minecraft:light[level=11]
setblock 537 184 228 minecraft:magenta_terracotta
setblock 537 184 270 minecraft:magenta_terracotta
setblock 541 184 228 minecraft:magenta_terracotta
setblock 541 184 231 minecraft:light[level=12]
setblock 541 184 238 minecraft:light[level=12]
setblock 541 184 245 minecraft:light[level=12]
setblock 541 184 252 minecraft:light[level=12]
setblock 541 184 259 minecraft:light[level=12]
setblock 541 184 266 minecraft:light[level=12]
setblock 541 184 270 minecraft:magenta_terracotta
setblock 544 184 231 minecraft:light[level=11]
setblock 544 184 239 minecraft:light[level=11]
setblock 544 184 247 minecraft:light[level=11]
setblock 544 184 255 minecraft:light[level=11]
setblock 544 184 263 minecraft:light[level=11]
setblock 545 184 228 minecraft:magenta_terracotta
setblock 545 184 270 minecraft:magenta_terracotta
fill 547 184 230 548 184 230 minecraft:spruce_planks
setblock 548 184 231 minecraft:light[level=12]
setblock 548 184 238 minecraft:light[level=12]
setblock 548 184 245 minecraft:light[level=12]
setblock 548 184 252 minecraft:light[level=12]
setblock 548 184 259 minecraft:light[level=12]
setblock 548 184 266 minecraft:light[level=12]
setblock 549 184 228 minecraft:magenta_terracotta
fill 549 184 229 550 184 230 minecraft:dark_oak_planks
setblock 549 184 270 minecraft:magenta_terracotta
setblock 552 184 231 minecraft:light[level=11]
setblock 552 184 239 minecraft:light[level=11]
setblock 552 184 247 minecraft:light[level=11]
setblock 552 184 255 minecraft:light[level=11]
setblock 552 184 263 minecraft:light[level=11]
setblock 553 184 228 minecraft:magenta_terracotta
setblock 553 184 270 minecraft:magenta_terracotta
setblock 555 184 231 minecraft:light[level=12]
setblock 555 184 238 minecraft:light[level=12]
setblock 555 184 245 minecraft:light[level=12]
setblock 555 184 252 minecraft:light[level=12]
setblock 555 184 259 minecraft:light[level=12]
setblock 555 184 266 minecraft:light[level=12]
setblock 557 184 228 minecraft:magenta_terracotta
setblock 557 184 270 minecraft:magenta_terracotta
setblock 559 184 228 minecraft:magenta_terracotta
setblock 559 184 232 minecraft:magenta_terracotta
setblock 559 184 236 minecraft:magenta_terracotta
setblock 559 184 240 minecraft:magenta_terracotta
fill 559 184 241 559 212 241 minecraft:purple_terracotta
setblock 559 184 244 minecraft:magenta_terracotta
setblock 559 184 248 minecraft:magenta_terracotta
setblock 559 184 252 minecraft:magenta_terracotta
setblock 559 184 256 minecraft:magenta_terracotta
setblock 559 184 260 minecraft:magenta_terracotta
setblock 559 184 263 minecraft:black_terracotta
setblock 559 184 264 minecraft:magenta_terracotta
setblock 559 184 268 minecraft:magenta_terracotta
fill 517 185 228 517 187 228 minecraft:purple_terracotta
fill 517 185 232 517 187 232 minecraft:purple_terracotta
fill 517 185 236 517 187 236 minecraft:purple_terracotta
fill 517 185 240 517 187 240 minecraft:purple_terracotta
fill 517 185 244 517 187 244 minecraft:purple_terracotta
fill 517 185 248 517 187 248 minecraft:purple_terracotta
fill 517 185 252 517 187 252 minecraft:purple_terracotta
fill 517 185 256 517 187 256 minecraft:purple_terracotta
fill 517 185 260 517 187 260 minecraft:purple_terracotta
fill 517 185 264 517 187 264 minecraft:purple_terracotta
fill 517 185 268 517 187 268 minecraft:purple_terracotta
setblock 517 185 270 minecraft:purple_terracotta
fill 521 185 228 521 187 228 minecraft:purple_terracotta
fill 521 185 270 521 187 270 minecraft:purple_terracotta
fill 525 185 228 525 187 228 minecraft:purple_terracotta
fill 525 185 270 525 187 270 minecraft:purple_terracotta
fill 529 185 228 529 187 228 minecraft:purple_terracotta
fill 529 185 270 529 187 270 minecraft:purple_terracotta
fill 533 185 228 533 187 228 minecraft:purple_terracotta
fill 533 185 270 533 187 270 minecraft:purple_terracotta
fill 537 185 228 537 187 228 minecraft:purple_terracotta
fill 537 185 270 537 187 270 minecraft:purple_terracotta
fill 541 185 228 541 187 228 minecraft:purple_terracotta
fill 541 185 270 541 187 270 minecraft:purple_terracotta
fill 545 185 228 545 187 228 minecraft:purple_terracotta
fill 545 185 230 546 185 230 minecraft:spruce_planks
fill 545 185 270 545 187 270 minecraft:purple_terracotta
fill 547 185 229 548 185 230 minecraft:dark_oak_planks
fill 549 185 228 549 187 228 minecraft:purple_terracotta
fill 549 185 270 549 187 270 minecraft:purple_terracotta
fill 553 185 228 553 187 228 minecraft:purple_terracotta
fill 553 185 270 553 187 270 minecraft:purple_terracotta
fill 557 185 228 557 187 228 minecraft:purple_terracotta
fill 557 185 270 557 187 270 minecraft:purple_terracotta
setblock 559 185 228 minecraft:purple_terracotta
fill 559 185 232 559 187 232 minecraft:purple_terracotta
fill 559 185 236 559 187 236 minecraft:purple_terracotta
fill 559 185 240 559 187 240 minecraft:purple_terracotta
fill 559 185 244 559 187 244 minecraft:purple_terracotta
fill 559 185 248 559 187 248 minecraft:purple_terracotta
fill 559 185 252 559 187 252 minecraft:purple_terracotta
fill 559 185 256 559 187 256 minecraft:purple_terracotta
fill 559 185 260 559 187 260 minecraft:purple_terracotta
fill 559 185 263 559 187 264 minecraft:purple_terracotta
fill 559 185 268 559 187 268 minecraft:purple_terracotta
setblock 517 186 230 minecraft:magenta_terracotta
setblock 517 186 234 minecraft:magenta_terracotta
setblock 517 186 238 minecraft:magenta_terracotta
setblock 517 186 242 minecraft:magenta_terracotta
setblock 517 186 246 minecraft:magenta_terracotta
setblock 517 186 250 minecraft:magenta_terracotta
setblock 517 186 254 minecraft:magenta_terracotta
setblock 517 186 258 minecraft:magenta_terracotta
setblock 517 186 262 minecraft:magenta_terracotta
setblock 517 186 266 minecraft:magenta_terracotta
setblock 517 186 270 minecraft:magenta_terracotta
setblock 519 186 228 minecraft:magenta_terracotta
setblock 519 186 270 minecraft:magenta_terracotta
setblock 523 186 228 minecraft:magenta_terracotta
setblock 523 186 270 minecraft:magenta_terracotta
setblock 527 186 228 minecraft:magenta_terracotta
setblock 527 186 270 minecraft:magenta_terracotta
setblock 531 186 228 minecraft:magenta_terracotta
setblock 531 186 270 minecraft:magenta_terracotta
setblock 535 186 228 minecraft:magenta_terracotta
setblock 535 186 270 minecraft:magenta_terracotta
setblock 539 186 228 minecraft:magenta_terracotta
setblock 539 186 270 minecraft:magenta_terracotta
setblock 543 186 228 minecraft:magenta_terracotta
fill 543 186 230 544 186 230 minecraft:spruce_planks
setblock 543 186 270 minecraft:magenta_terracotta
fill 545 186 229 546 186 230 minecraft:dark_oak_planks
setblock 547 186 228 minecraft:magenta_terracotta
setblock 547 186 270 minecraft:magenta_terracotta
setblock 551 186 228 minecraft:magenta_terracotta
setblock 551 186 270 minecraft:magenta_terracotta
setblock 555 186 228 minecraft:black_terracotta
setblock 555 186 270 minecraft:magenta_terracotta
setblock 559 186 228 minecraft:magenta_terracotta
setblock 559 186 230 minecraft:magenta_terracotta
setblock 559 186 234 minecraft:magenta_terracotta
setblock 559 186 238 minecraft:magenta_terracotta
setblock 559 186 242 minecraft:magenta_terracotta
setblock 559 186 246 minecraft:magenta_terracotta
setblock 559 186 250 minecraft:magenta_terracotta
setblock 559 186 254 minecraft:magenta_terracotta
setblock 559 186 258 minecraft:magenta_terracotta
setblock 559 186 262 minecraft:magenta_terracotta
setblock 559 186 266 minecraft:magenta_terracotta
setblock 559 186 270 minecraft:magenta_terracotta
fill 517 187 230 517 189 230 minecraft:purple_terracotta
fill 517 187 234 517 189 234 minecraft:purple_terracotta
fill 517 187 238 517 189 238 minecraft:purple_terracotta
fill 517 187 242 517 189 242 minecraft:purple_terracotta
fill 517 187 246 517 189 246 minecraft:purple_terracotta
fill 517 187 250 517 189 250 minecraft:purple_terracotta
fill 517 187 254 517 189 254 minecraft:purple_terracotta
fill 517 187 258 517 189 258 minecraft:purple_terracotta
fill 517 187 262 517 189 262 minecraft:purple_terracotta
fill 517 187 266 517 189 266 minecraft:purple_terracotta
setblock 517 187 270 minecraft:purple_terracotta
fill 519 187 228 519 189 228 minecraft:purple_terracotta
fill 519 187 270 519 189 270 minecraft:purple_terracotta
fill 523 187 228 523 189 228 minecraft:purple_terracotta
fill 523 187 270 523 189 270 minecraft:purple_terracotta
fill 527 187 228 527 189 228 minecraft:purple_terracotta
fill 527 187 270 527 189 270 minecraft:purple_terracotta
fill 531 187 228 531 189 228 minecraft:purple_terracotta
fill 531 187 270 531 189 270 minecraft:purple_terracotta
fill 535 187 228 535 189 228 minecraft:purple_terracotta
fill 535 187 270 535 189 270 minecraft:purple_terracotta
fill 539 187 228 539 189 228 minecraft:purple_terracotta
fill 539 187 270 539 189 270 minecraft:purple_terracotta
fill 541 187 230 542 187 230 minecraft:spruce_planks
fill 543 187 228 543 189 228 minecraft:purple_terracotta
fill 543 187 229 544 187 230 minecraft:dark_oak_planks
fill 543 187 270 543 189 270 minecraft:purple_terracotta
fill 547 187 228 547 189 228 minecraft:purple_terracotta
fill 547 187 270 547 189 270 minecraft:purple_terracotta
fill 551 187 228 551 189 228 minecraft:purple_terracotta
fill 551 187 270 551 189 270 minecraft:purple_terracotta
fill 555 187 228 555 189 228 minecraft:purple_terracotta
fill 555 187 270 555 189 270 minecraft:purple_terracotta
setblock 559 187 228 minecraft:purple_terracotta
fill 559 187 230 559 189 230 minecraft:purple_terracotta
fill 559 187 234 559 189 234 minecraft:purple_terracotta
fill 559 187 238 559 189 238 minecraft:purple_terracotta
fill 559 187 242 559 189 242 minecraft:purple_terracotta
fill 559 187 246 559 189 246 minecraft:purple_terracotta
fill 559 187 250 559 189 250 minecraft:purple_terracotta
fill 559 187 254 559 189 254 minecraft:purple_terracotta
fill 559 187 258 559 189 258 minecraft:purple_terracotta
fill 559 187 262 559 189 262 minecraft:purple_terracotta
fill 559 187 266 559 189 266 minecraft:purple_terracotta
fill 559 187 270 559 189 270 minecraft:purple_terracotta
setblock 517 188 228 minecraft:magenta_terracotta
setblock 517 188 232 minecraft:magenta_terracotta
setblock 517 188 236 minecraft:magenta_terracotta
setblock 517 188 240 minecraft:magenta_terracotta
setblock 517 188 244 minecraft:magenta_terracotta
setblock 517 188 248 minecraft:magenta_terracotta
setblock 517 188 252 minecraft:black_terracotta
setblock 517 188 256 minecraft:magenta_terracotta
setblock 517 188 260 minecraft:magenta_terracotta
setblock 517 188 264 minecraft:magenta_terracotta
setblock 517 188 268 minecraft:magenta_terracotta
setblock 517 188 270 minecraft:magenta_terracotta
setblock 521 188 228 minecraft:magenta_terracotta
setblock 521 188 270 minecraft:magenta_terracotta
setblock 525 188 228 minecraft:magenta_terracotta
setblock 525 188 270 minecraft:magenta_terracotta
setblock 529 188 228 minecraft:magenta_terracotta
setblock 529 188 270 minecraft:magenta_terracotta
setblock 533 188 228 minecraft:magenta_terracotta
setblock 533 188 270 minecraft:magenta_terracotta
setblock 537 188 228 minecraft:magenta_terracotta
setblock 537 188 270 minecraft:magenta_terracotta
fill 539 188 230 540 188 230 minecraft:spruce_planks
setblock 541 188 228 minecraft:magenta_terracotta
fill 541 188 229 542 188 230 minecraft:dark_oak_planks
setblock 541 188 270 minecraft:magenta_terracotta
setblock 545 188 228 minecraft:magenta_terracotta
setblock 545 188 270 minecraft:magenta_terracotta
setblock 549 188 228 minecraft:magenta_terracotta
setblock 549 188 270 minecraft:magenta_terracotta
setblock 553 188 228 minecraft:magenta_terracotta
setblock 553 188 270 minecraft:magenta_terracotta
setblock 557 188 228 minecraft:magenta_terracotta
setblock 557 188 270 minecraft:magenta_terracotta
setblock 559 188 228 minecraft:magenta_terracotta
setblock 559 188 232 minecraft:magenta_terracotta
setblock 559 188 236 minecraft:magenta_terracotta
setblock 559 188 240 minecraft:magenta_terracotta
setblock 559 188 244 minecraft:magenta_terracotta
setblock 559 188 248 minecraft:magenta_terracotta
setblock 559 188 252 minecraft:magenta_terracotta
setblock 559 188 256 minecraft:magenta_terracotta
setblock 559 188 260 minecraft:magenta_terracotta
fill 559 188 263 559 212 263 minecraft:purple_terracotta
setblock 559 188 264 minecraft:magenta_terracotta
setblock 559 188 268 minecraft:magenta_terracotta
fill 517 189 228 517 191 228 minecraft:purple_terracotta
fill 517 189 232 517 191 232 minecraft:purple_terracotta
fill 517 189 236 517 191 236 minecraft:purple_terracotta
fill 517 189 240 517 191 240 minecraft:purple_terracotta
fill 517 189 244 517 191 244 minecraft:purple_terracotta
fill 517 189 248 517 191 248 minecraft:purple_terracotta
fill 517 189 252 517 191 252 minecraft:purple_terracotta
fill 517 189 256 517 191 256 minecraft:purple_terracotta
fill 517 189 260 517 191 260 minecraft:purple_terracotta
fill 517 189 264 517 191 264 minecraft:purple_terracotta
fill 517 189 268 517 191 268 minecraft:purple_terracotta
setblock 517 189 270 minecraft:purple_terracotta
fill 521 189 228 521 191 228 minecraft:purple_terracotta
fill 521 189 270 521 191 270 minecraft:purple_terracotta
fill 525 189 228 525 191 228 minecraft:purple_terracotta
fill 525 189 270 525 191 270 minecraft:purple_terracotta
fill 529 189 228 529 191 228 minecraft:purple_terracotta
fill 529 189 270 529 191 270 minecraft:purple_terracotta
fill 533 189 228 533 191 228 minecraft:purple_terracotta
fill 533 189 270 533 191 270 minecraft:purple_terracotta
fill 537 189 228 537 191 228 minecraft:purple_terracotta
fill 537 189 230 538 189 230 minecraft:spruce_planks
fill 537 189 270 537 191 270 minecraft:purple_terracotta
fill 539 189 229 540 189 230 minecraft:dark_oak_planks
fill 541 189 228 541 191 228 minecraft:purple_terracotta
fill 541 189 270 541 191 270 minecraft:purple_terracotta
fill 545 189 228 545 191 228 minecraft:purple_terracotta
fill 545 189 262 549 190 266 minecraft:dark_oak_planks
fill 545 189 270 545 191 270 minecraft:purple_terracotta
fill 547 189 267 547 189 268 minecraft:dark_oak_planks
fill 549 189 228 549 191 228 minecraft:purple_terracotta
fill 549 189 270 549 191 270 minecraft:purple_terracotta
fill 553 189 228 553 191 228 minecraft:purple_terracotta
fill 553 189 270 553 191 270 minecraft:purple_terracotta
fill 557 189 228 557 191 228 minecraft:purple_terracotta
fill 557 189 270 557 191 270 minecraft:purple_terracotta
setblock 559 189 228 minecraft:purple_terracotta
fill 559 189 232 559 191 232 minecraft:purple_terracotta
fill 559 189 236 559 191 236 minecraft:purple_terracotta
fill 559 189 240 559 191 240 minecraft:purple_terracotta
fill 559 189 244 559 191 244 minecraft:purple_terracotta
fill 559 189 248 559 191 248 minecraft:purple_terracotta
fill 559 189 252 559 191 252 minecraft:purple_terracotta
fill 559 189 256 559 191 256 minecraft:purple_terracotta
fill 559 189 260 559 191 260 minecraft:purple_terracotta
fill 559 189 264 559 191 264 minecraft:purple_terracotta
fill 559 189 268 559 191 268 minecraft:purple_terracotta
setblock 517 190 230 minecraft:magenta_terracotta
setblock 517 190 234 minecraft:magenta_terracotta
setblock 517 190 238 minecraft:magenta_terracotta
setblock 517 190 242 minecraft:magenta_terracotta
setblock 517 190 246 minecraft:magenta_terracotta
setblock 517 190 250 minecraft:magenta_terracotta
setblock 517 190 254 minecraft:magenta_terracotta
setblock 517 190 258 minecraft:magenta_terracotta
setblock 517 190 262 minecraft:magenta_terracotta
setblock 517 190 266 minecraft:magenta_terracotta
setblock 517 190 270 minecraft:magenta_terracotta
setblock 519 190 228 minecraft:magenta_terracotta
setblock 519 190 270 minecraft:magenta_terracotta
setblock 520 190 231 minecraft:light[level=12]
setblock 520 190 238 minecraft:light[level=12]
setblock 520 190 245 minecraft:light[level=12]
setblock 520 190 252 minecraft:light[level=12]
setblock 520 190 259 minecraft:light[level=12]
setblock 520 190 266 minecraft:light[level=12]
setblock 523 190 228 minecraft:magenta_terracotta
setblock 523 190 270 minecraft:magenta_terracotta
setblock 527 190 228 minecraft:magenta_terracotta
setblock 527 190 231 minecraft:light[level=12]
setblock 527 190 238 minecraft:light[level=12]
setblock 527 190 245 minecraft:light[level=12]
setblock 527 190 252 minecraft:light[level=12]
setblock 527 190 259 minecraft:light[level=12]
setblock 527 190 266 minecraft:light[level=12]
setblock 527 190 270 minecraft:magenta_terracotta
setblock 531 190 228 minecraft:magenta_terracotta
setblock 531 190 270 minecraft:magenta_terracotta
setblock 534 190 231 minecraft:light[level=12]
setblock 534 190 238 minecraft:light[level=12]
setblock 534 190 245 minecraft:light[level=12]
setblock 534 190 252 minecraft:light[level=12]
setblock 534 190 259 minecraft:light[level=12]
setblock 534 190 266 minecraft:light[level=12]
setblock 535 190 228 minecraft:magenta_terracotta
fill 535 190 230 536 190 230 minecraft:spruce_planks
setblock 535 190 270 minecraft:magenta_terracotta
fill 537 190 229 538 190 230 minecraft:dark_oak_planks
setblock 539 190 228 minecraft:magenta_terracotta
setblock 539 190 270 minecraft:magenta_terracotta
setblock 541 190 231 minecraft:light[level=12]
setblock 541 190 238 minecraft:light[level=12]
setblock 541 190 245 minecraft:light[level=12]
setblock 541 190 252 minecraft:light[level=12]
setblock 541 190 259 minecraft:light[level=12]
setblock 541 190 266 minecraft:light[level=12]
setblock 543 190 228 minecraft:magenta_terracotta
setblock 543 190 270 minecraft:magenta_terracotta
setblock 547 190 228 minecraft:magenta_terracotta
setblock 547 190 270 minecraft:magenta_terracotta
setblock 548 190 231 minecraft:light[level=12]
setblock 548 190 238 minecraft:light[level=12]
setblock 548 190 245 minecraft:light[level=12]
setblock 548 190 252 minecraft:light[level=12]
setblock 548 190 259 minecraft:light[level=12]
setblock 551 190 228 minecraft:magenta_terracotta
setblock 551 190 270 minecraft:magenta_terracotta
setblock 555 190 228 minecraft:magenta_terracotta
setblock 555 190 231 minecraft:light[level=12]
setblock 555 190 238 minecraft:light[level=12]
setblock 555 190 245 minecraft:light[level=12]
setblock 555 190 252 minecraft:light[level=12]
setblock 555 190 259 minecraft:light[level=12]
setblock 555 190 266 minecraft:light[level=12]
setblock 555 190 270 minecraft:magenta_terracotta
setblock 559 190 228 minecraft:magenta_terracotta
setblock 559 190 230 minecraft:magenta_terracotta
setblock 559 190 234 minecraft:magenta_terracotta
setblock 559 190 238 minecraft:magenta_terracotta
setblock 559 190 242 minecraft:magenta_terracotta
setblock 559 190 246 minecraft:magenta_terracotta
setblock 559 190 250 minecraft:magenta_terracotta
setblock 559 190 254 minecraft:magenta_terracotta
setblock 559 190 258 minecraft:magenta_terracotta
setblock 559 190 262 minecraft:magenta_terracotta
setblock 559 190 266 minecraft:magenta_terracotta
setblock 559 190 270 minecraft:magenta_terracotta
fill 517 191 230 517 193 230 minecraft:purple_terracotta
fill 517 191 234 517 193 234 minecraft:purple_terracotta
fill 517 191 238 517 193 238 minecraft:purple_terracotta
fill 517 191 242 517 193 242 minecraft:purple_terracotta
fill 517 191 246 517 193 246 minecraft:purple_terracotta
fill 517 191 250 517 193 250 minecraft:purple_terracotta
fill 517 191 254 517 193 254 minecraft:purple_terracotta
fill 517 191 258 517 193 258 minecraft:purple_terracotta
fill 517 191 262 517 193 262 minecraft:purple_terracotta
fill 517 191 266 517 193 266 minecraft:purple_terracotta
setblock 517 191 270 minecraft:purple_terracotta
fill 519 191 228 519 193 228 minecraft:purple_terracotta
fill 519 191 270 519 193 270 minecraft:purple_terracotta
fill 523 191 228 523 193 228 minecraft:purple_terracotta
fill 523 191 270 523 193 270 minecraft:purple_terracotta
fill 527 191 228 527 193 228 minecraft:purple_terracotta
fill 527 191 270 527 193 270 minecraft:purple_terracotta
fill 531 191 228 531 193 228 minecraft:purple_terracotta
fill 531 191 270 531 193 270 minecraft:purple_terracotta
fill 533 191 230 534 191 230 minecraft:spruce_planks
fill 535 191 228 535 193 228 minecraft:purple_terracotta
fill 535 191 229 536 191 230 minecraft:dark_oak_planks
fill 535 191 270 535 193 270 minecraft:purple_terracotta
fill 539 191 228 539 193 228 minecraft:purple_terracotta
fill 539 191 270 539 193 270 minecraft:purple_terracotta
fill 543 191 228 543 193 228 minecraft:purple_terracotta
fill 543 191 270 543 193 270 minecraft:purple_terracotta
fill 546 191 264 548 195 264 minecraft:stripped_dark_oak_log
fill 547 191 228 547 193 228 minecraft:purple_terracotta
fill 547 191 270 547 193 270 minecraft:purple_terracotta
fill 551 191 228 551 193 228 minecraft:purple_terracotta
fill 551 191 270 551 193 270 minecraft:purple_terracotta
fill 555 191 228 555 193 228 minecraft:purple_terracotta
fill 555 191 270 555 193 270 minecraft:purple_terracotta
setblock 559 191 228 minecraft:purple_terracotta
fill 559 191 230 559 193 230 minecraft:purple_terracotta
fill 559 191 234 559 193 234 minecraft:purple_terracotta
setblock 559 191 235 minecraft:black_terracotta
fill 559 191 238 559 193 238 minecraft:purple_terracotta
fill 559 191 242 559 193 242 minecraft:purple_terracotta
fill 559 191 246 559 193 246 minecraft:purple_terracotta
fill 559 191 250 559 193 250 minecraft:purple_terracotta
fill 559 191 254 559 193 254 minecraft:purple_terracotta
fill 559 191 258 559 193 258 minecraft:purple_terracotta
fill 559 191 262 559 193 262 minecraft:purple_terracotta
fill 559 191 266 559 193 266 minecraft:purple_terracotta
fill 559 191 270 559 193 270 minecraft:purple_terracotta
setblock 517 192 228 minecraft:magenta_terracotta
setblock 517 192 232 minecraft:magenta_terracotta
setblock 517 192 236 minecraft:magenta_terracotta
setblock 517 192 240 minecraft:magenta_terracotta
setblock 517 192 244 minecraft:magenta_terracotta
setblock 517 192 248 minecraft:magenta_terracotta
setblock 517 192 252 minecraft:magenta_terracotta
setblock 517 192 256 minecraft:magenta_terracotta
setblock 517 192 260 minecraft:magenta_terracotta
setblock 517 192 264 minecraft:magenta_terracotta
setblock 517 192 268 minecraft:magenta_terracotta
setblock 517 192 270 minecraft:magenta_terracotta
setblock 520 192 231 minecraft:light[level=11]
setblock 520 192 239 minecraft:light[level=11]
setblock 520 192 247 minecraft:light[level=11]
setblock 520 192 255 minecraft:light[level=11]
setblock 520 192 263 minecraft:light[level=11]
setblock 521 192 228 minecraft:magenta_terracotta
setblock 521 192 270 minecraft:magenta_terracotta
setblock 525 192 228 minecraft:magenta_terracotta
setblock 525 192 270 minecraft:magenta_terracotta
setblock 528 192 231 minecraft:light[level=11]
setblock 528 192 239 minecraft:light[level=11]
setblock 528 192 247 minecraft:light[level=11]
setblock 528 192 255 minecraft:light[level=11]
setblock 528 192 263 minecraft:light[level=11]
setblock 529 192 228 minecraft:magenta_terracotta
setblock 529 192 270 minecraft:magenta_terracotta
fill 531 192 230 532 192 230 minecraft:spruce_planks
setblock 533 192 228 minecraft:magenta_terracotta
fill 533 192 229 534 192 230 minecraft:dark_oak_planks
setblock 533 192 270 minecraft:magenta_terracotta
setblock 536 192 231 minecraft:light[level=11]
setblock 536 192 239 minecraft:light[level=11]
setblock 536 192 247 minecraft:light[level=11]
setblock 536 192 255 minecraft:light[level=11]
setblock 536 192 263 minecraft:light[level=11]
setblock 537 192 228 minecraft:magenta_terracotta
setblock 537 192 270 minecraft:magenta_terracotta
setblock 541 192 228 minecraft:magenta_terracotta
setblock 541 192 270 minecraft:magenta_terracotta
setblock 544 192 231 minecraft:light[level=11]
setblock 544 192 239 minecraft:light[level=11]
setblock 544 192 247 minecraft:light[level=11]
setblock 544 192 255 minecraft:light[level=11]
setblock 544 192 263 minecraft:light[level=11]
setblock 545 192 228 minecraft:magenta_terracotta
setblock 545 192 270 minecraft:magenta_terracotta
setblock 546 192 228 minecraft:black_terracotta
setblock 549 192 228 minecraft:magenta_terracotta
setblock 549 192 270 minecraft:magenta_terracotta
setblock 552 192 231 minecraft:light[level=11]
setblock 552 192 239 minecraft:light[level=11]
setblock 552 192 247 minecraft:light[level=11]
setblock 552 192 255 minecraft:light[level=11]
setblock 552 192 263 minecraft:light[level=11]
setblock 553 192 228 minecraft:magenta_terracotta
setblock 553 192 270 minecraft:magenta_terracotta
setblock 557 192 228 minecraft:magenta_terracotta
setblock 557 192 270 minecraft:magenta_terracotta
setblock 559 192 228 minecraft:magenta_terracotta
setblock 559 192 232 minecraft:magenta_terracotta
fill 559 192 235 559 212 235 minecraft:purple_terracotta
setblock 559 192 236 minecraft:magenta_terracotta
setblock 559 192 240 minecraft:magenta_terracotta
setblock 559 192 244 minecraft:magenta_terracotta
setblock 559 192 248 minecraft:magenta_terracotta
setblock 559 192 252 minecraft:magenta_terracotta
setblock 559 192 256 minecraft:magenta_terracotta
setblock 559 192 260 minecraft:magenta_terracotta
setblock 559 192 264 minecraft:magenta_terracotta
setblock 559 192 268 minecraft:magenta_terracotta
fill 517 193 228 517 195 228 minecraft:purple_terracotta
fill 517 193 232 517 195 232 minecraft:purple_terracotta
fill 517 193 236 517 195 236 minecraft:purple_terracotta
fill 517 193 240 517 195 240 minecraft:purple_terracotta
fill 517 193 244 517 195 244 minecraft:purple_terracotta
fill 517 193 248 517 195 248 minecraft:purple_terracotta
fill 517 193 252 517 195 252 minecraft:purple_terracotta
fill 517 193 256 517 195 256 minecraft:purple_terracotta
fill 517 193 260 517 195 260 minecraft:purple_terracotta
fill 517 193 264 517 195 264 minecraft:purple_terracotta
fill 517 193 268 517 195 268 minecraft:purple_terracotta
setblock 517 193 270 minecraft:purple_terracotta
fill 521 193 228 521 195 228 minecraft:purple_terracotta
fill 521 193 270 521 195 270 minecraft:purple_terracotta
fill 525 193 228 525 195 228 minecraft:purple_terracotta
fill 525 193 270 525 195 270 minecraft:purple_terracotta
fill 529 193 228 529 195 228 minecraft:purple_terracotta
fill 529 193 230 530 193 230 minecraft:spruce_planks
fill 529 193 270 529 195 270 minecraft:purple_terracotta
fill 531 193 229 532 193 230 minecraft:dark_oak_planks
setblock 533 193 228 minecraft:purple_terracotta
fill 533 193 270 533 195 270 minecraft:purple_terracotta
fill 537 193 228 537 195 228 minecraft:purple_terracotta
fill 537 193 270 537 195 270 minecraft:purple_terracotta
fill 541 193 228 541 195 228 minecraft:purple_terracotta
fill 541 193 270 541 195 270 minecraft:purple_terracotta
fill 545 193 228 546 195 228 minecraft:purple_terracotta
fill 545 193 270 545 195 270 minecraft:purple_terracotta
fill 549 193 228 549 195 228 minecraft:purple_terracotta
fill 549 193 270 549 195 270 minecraft:purple_terracotta
fill 553 193 228 553 195 228 minecraft:purple_terracotta
fill 553 193 270 553 195 270 minecraft:purple_terracotta
fill 557 193 228 557 195 228 minecraft:purple_terracotta
fill 557 193 270 557 195 270 minecraft:purple_terracotta
setblock 558 193 270 minecraft:light_gray_terracotta
setblock 559 193 228 minecraft:purple_terracotta
fill 559 193 232 559 195 232 minecraft:purple_terracotta
fill 559 193 236 559 195 236 minecraft:purple_terracotta
fill 559 193 240 559 195 240 minecraft:purple_terracotta
fill 559 193 244 559 195 244 minecraft:purple_terracotta
fill 559 193 248 559 195 248 minecraft:purple_terracotta
fill 559 193 252 559 195 252 minecraft:purple_terracotta
fill 559 193 256 559 195 256 minecraft:purple_terracotta
fill 559 193 260 559 195 260 minecraft:purple_terracotta
fill 559 193 264 559 194 264 minecraft:purple_terracotta
setblock 559 193 268 minecraft:purple_terracotta
setblock 517 194 230 minecraft:magenta_terracotta
setblock 517 194 234 minecraft:magenta_terracotta
setblock 517 194 238 minecraft:magenta_terracotta
setblock 517 194 242 minecraft:magenta_terracotta
setblock 517 194 246 minecraft:magenta_terracotta
setblock 517 194 250 minecraft:magenta_terracotta
setblock 517 194 254 minecraft:magenta_terracotta
setblock 517 194 258 minecraft:magenta_terracotta
setblock 517 194 262 minecraft:magenta_terracotta
setblock 517 194 266 minecraft:magenta_terracotta
setblock 517 194 270 minecraft:magenta_terracotta
setblock 519 194 228 minecraft:magenta_terracotta
setblock 519 194 270 minecraft:magenta_terracotta
setblock 523 194 228 minecraft:magenta_terracotta
setblock 523 194 270 minecraft:magenta_terracotta
setblock 527 194 228 minecraft:magenta_terracotta
fill 527 194 230 528 194 230 minecraft:spruce_planks
setblock 527 194 270 minecraft:magenta_terracotta
fill 529 194 229 530 194 230 minecraft:dark_oak_planks
setblock 531 194 228 minecraft:magenta_terracotta
setblock 531 194 270 minecraft:magenta_terracotta
setblock 533 194 228 minecraft:light_gray_terracotta
setblock 535 194 228 minecraft:magenta_terracotta
setblock 535 194 270 minecraft:magenta_terracotta
setblock 539 194 228 minecraft:magenta_terracotta
setblock 539 194 270 minecraft:magenta_terracotta
setblock 543 194 228 minecraft:magenta_terracotta
setblock 543 194 270 minecraft:magenta_terracotta
setblock 547 194 228 minecraft:magenta_terracotta
fill 547 194 263 547 195 263 minecraft:stripped_dark_oak_log
fill 547 194 265 547 195 265 minecraft:stripped_dark_oak_log
setblock 547 194 270 minecraft:magenta_terracotta
setblock 551 194 228 minecraft:magenta_terracotta
setblock 551 194 270 minecraft:magenta_terracotta
setblock 555 194 228 minecraft:magenta_terracotta
setblock 555 194 270 minecraft:magenta_terracotta
fill 558 194 270 558 212 270 minecraft:purple_terracotta
setblock 559 194 228 minecraft:magenta_terracotta
setblock 559 194 230 minecraft:magenta_terracotta
setblock 559 194 234 minecraft:magenta_terracotta
setblock 559 194 238 minecraft:magenta_terracotta
setblock 559 194 242 minecraft:magenta_terracotta
setblock 559 194 246 minecraft:magenta_terracotta
setblock 559 194 250 minecraft:magenta_terracotta
setblock 559 194 254 minecraft:magenta_terracotta
setblock 559 194 258 minecraft:magenta_terracotta
setblock 559 194 262 minecraft:magenta_terracotta
setblock 559 194 266 minecraft:magenta_terracotta
setblock 559 194 268 minecraft:gray_terracotta
setblock 559 194 270 minecraft:magenta_terracotta
fill 517 195 230 517 197 230 minecraft:purple_terracotta
fill 517 195 234 517 197 234 minecraft:purple_terracotta
fill 517 195 238 517 197 238 minecraft:purple_terracotta
fill 517 195 242 517 197 242 minecraft:purple_terracotta
fill 517 195 246 517 197 246 minecraft:purple_terracotta
fill 517 195 250 517 197 250 minecraft:purple_terracotta
fill 517 195 254 517 197 254 minecraft:purple_terracotta
fill 517 195 258 517 197 258 minecraft:purple_terracotta
fill 517 195 262 517 197 262 minecraft:purple_terracotta
fill 517 195 266 517 197 266 minecraft:purple_terracotta
setblock 517 195 270 minecraft:purple_terracotta
fill 519 195 228 519 197 228 minecraft:purple_terracotta
fill 519 195 270 519 197 270 minecraft:purple_terracotta
fill 523 195 228 523 197 228 minecraft:purple_terracotta
fill 523 195 270 523 197 270 minecraft:purple_terracotta
fill 525 195 230 526 195 230 minecraft:spruce_planks
fill 527 195 228 527 197 228 minecraft:purple_terracotta
fill 527 195 229 528 195 230 minecraft:dark_oak_planks
fill 527 195 270 527 197 270 minecraft:purple_terracotta
fill 531 195 228 531 197 228 minecraft:purple_terracotta
fill 531 195 270 531 197 270 minecraft:purple_terracotta
setblock 533 195 228 minecraft:purple_terracotta
fill 535 195 228 535 197 228 minecraft:purple_terracotta
fill 535 195 270 535 197 270 minecraft:purple_terracotta
setblock 538 195 228 minecraft:gray_terracotta
fill 539 195 228 539 197 228 minecraft:purple_terracotta
fill 539 195 270 539 197 270 minecraft:purple_terracotta
fill 543 195 228 543 197 228 minecraft:purple_terracotta
fill 543 195 270 543 197 270 minecraft:purple_terracotta
fill 547 195 228 547 197 228 minecraft:purple_terracotta
fill 547 195 270 547 197 270 minecraft:purple_terracotta
fill 551 195 228 551 197 228 minecraft:purple_terracotta
fill 551 195 270 551 197 270 minecraft:purple_terracotta
fill 555 195 228 555 197 228 minecraft:purple_terracotta
fill 555 195 270 555 197 270 minecraft:purple_terracotta
setblock 559 195 228 minecraft:purple_terracotta
fill 559 195 230 559 197 230 minecraft:purple_terracotta
fill 559 195 234 559 197 234 minecraft:purple_terracotta
fill 559 195 238 559 197 238 minecraft:purple_terracotta
fill 559 195 242 559 197 242 minecraft:purple_terracotta
fill 559 195 246 559 197 246 minecraft:purple_terracotta
fill 559 195 250 559 197 250 minecraft:purple_terracotta
fill 559 195 254 559 197 254 minecraft:purple_terracotta
fill 559 195 258 559 197 258 minecraft:purple_terracotta
fill 559 195 262 559 197 262 minecraft:purple_terracotta
setblock 559 195 264 minecraft:gray_terracotta
setblock 559 195 266 minecraft:gray_terracotta
setblock 559 195 268 minecraft:purple_terracotta
fill 559 195 270 559 197 270 minecraft:purple_terracotta
setblock 517 196 228 minecraft:magenta_terracotta
setblock 517 196 232 minecraft:magenta_terracotta
setblock 517 196 236 minecraft:magenta_terracotta
setblock 517 196 240 minecraft:magenta_terracotta
setblock 517 196 244 minecraft:magenta_terracotta
setblock 517 196 248 minecraft:light_gray_terracotta
setblock 517 196 252 minecraft:magenta_terracotta
setblock 517 196 256 minecraft:magenta_terracotta
setblock 517 196 260 minecraft:magenta_terracotta
setblock 517 196 264 minecraft:magenta_terracotta
setblock 517 196 268 minecraft:magenta_terracotta
setblock 517 196 270 minecraft:magenta_terracotta
setblock 520 196 231 minecraft:light[level=12]
setblock 520 196 238 minecraft:light[level=12]
setblock 520 196 245 minecraft:light[level=12]
setblock 520 196 252 minecraft:light[level=12]
setblock 520 196 259 minecraft:light[level=12]
setblock 520 196 266 minecraft:light[level=12]
setblock 521 196 228 minecraft:magenta_terracotta
setblock 521 196 270 minecraft:magenta_terracotta
fill 523 196 230 524 196 230 minecraft:spruce_planks
setblock 525 196 228 minecraft:magenta_terracotta
fill 525 196 229 526 196 230 minecraft:dark_oak_planks
setblock 525 196 270 minecraft:magenta_terracotta
setblock 527 196 231 minecraft:light[level=12]
setblock 527 196 238 minecraft:light[level=12]
setblock 527 196 245 minecraft:light[level=12]
setblock 527 196 252 minecraft:light[level=12]
setblock 527 196 259 minecraft:light[level=12]
setblock 527 196 266 minecraft:light[level=12]
setblock 529 196 228 minecraft:magenta_terracotta
setblock 529 196 270 minecraft:magenta_terracotta
setblock 533 196 228 minecraft:magenta_terracotta
setblock 533 196 270 minecraft:magenta_terracotta
setblock 534 196 231 minecraft:light[level=12]
setblock 534 196 238 minecraft:light[level=12]
setblock 534 196 245 minecraft:light[level=12]
setblock 534 196 252 minecraft:light[level=12]
setblock 534 196 259 minecraft:light[level=12]
setblock 534 196 266 minecraft:light[level=12]
setblock 537 196 228 minecraft:magenta_terracotta
setblock 537 196 270 minecraft:magenta_terracotta
fill 538 196 228 538 212 228 minecraft:purple_terracotta
setblock 541 196 228 minecraft:magenta_terracotta
setblock 541 196 231 minecraft:light[level=12]
setblock 541 196 238 minecraft:light[level=12]
setblock 541 196 245 minecraft:light[level=12]
setblock 541 196 252 minecraft:light[level=12]
setblock 541 196 259 minecraft:light[level=12]
setblock 541 196 266 minecraft:light[level=12]
setblock 541 196 270 minecraft:magenta_terracotta
setblock 545 196 228 minecraft:magenta_terracotta
setblock 545 196 270 minecraft:magenta_terracotta
fill 546 196 228 546 212 228 minecraft:purple_terracotta
setblock 548 196 231 minecraft:light[level=12]
setblock 548 196 238 minecraft:light[level=12]
setblock 548 196 245 minecraft:light[level=12]
setblock 548 196 252 minecraft:light[level=12]
setblock 548 196 259 minecraft:light[level=12]
setblock 548 196 266 minecraft:light[level=12]
setblock 549 196 228 minecraft:magenta_terracotta
setblock 549 196 270 minecraft:magenta_terracotta
setblock 553 196 228 minecraft:magenta_terracotta
setblock 553 196 270 minecraft:magenta_terracotta
setblock 555 196 231 minecraft:light[level=12]
setblock 555 196 238 minecraft:light[level=12]
setblock 555 196 245 minecraft:light[level=12]
setblock 555 196 252 minecraft:light[level=12]
setblock 555 196 259 minecraft:light[level=12]
setblock 555 196 266 minecraft:light[level=12]
setblock 557 196 228 minecraft:magenta_terracotta
setblock 557 196 270 minecraft:magenta_terracotta
setblock 559 196 228 minecraft:magenta_terracotta
setblock 559 196 232 minecraft:magenta_terracotta
setblock 559 196 236 minecraft:magenta_terracotta
setblock 559 196 240 minecraft:magenta_terracotta
setblock 559 196 244 minecraft:magenta_terracotta
setblock 559 196 248 minecraft:magenta_terracotta
setblock 559 196 252 minecraft:magenta_terracotta
setblock 559 196 256 minecraft:magenta_terracotta
setblock 559 196 260 minecraft:magenta_terracotta
setblock 559 196 264 minecraft:magenta_terracotta
fill 559 196 266 559 197 266 minecraft:purple_terracotta
setblock 559 196 268 minecraft:magenta_terracotta
fill 517 197 228 517 199 228 minecraft:purple_terracotta
fill 517 197 232 517 199 232 minecraft:purple_terracotta
fill 517 197 236 517 199 236 minecraft:purple_terracotta
setblock 517 197 240 minecraft:black_terracotta
fill 517 197 244 517 199 244 minecraft:purple_terracotta
fill 517 197 248 517 199 248 minecraft:purple_terracotta
fill 517 197 252 517 199 252 minecraft:purple_terracotta
fill 517 197 256 517 199 256 minecraft:purple_terracotta
fill 517 197 260 517 199 260 minecraft:purple_terracotta
fill 517 197 264 517 199 264 minecraft:purple_terracotta
fill 517 197 268 517 199 268 minecraft:purple_terracotta
setblock 517 197 270 minecraft:purple_terracotta
fill 521 197 228 521 199 228 minecraft:purple_terracotta
fill 521 197 230 522 197 230 minecraft:spruce_planks
fill 521 197 270 521 199 270 minecraft:purple_terracotta
fill 523 197 229 524 197 230 minecraft:dark_oak_planks
fill 525 197 228 525 199 228 minecraft:purple_terracotta
fill 525 197 270 525 199 270 minecraft:purple_terracotta
setblock 528 197 270 minecraft:black_terracotta
fill 529 197 228 529 199 228 minecraft:purple_terracotta
fill 529 197 270 529 199 270 minecraft:purple_terracotta
fill 533 197 228 533 199 228 minecraft:purple_terracotta
fill 533 197 270 533 199 270 minecraft:purple_terracotta
fill 537 197 228 537 199 228 minecraft:purple_terracotta
fill 537 197 270 537 199 270 minecraft:purple_terracotta
fill 541 197 228 541 199 228 minecraft:purple_terracotta
fill 541 197 270 541 199 270 minecraft:purple_terracotta
fill 545 197 228 545 199 228 minecraft:purple_terracotta
fill 545 197 270 545 199 270 minecraft:purple_terracotta
fill 549 197 228 549 199 228 minecraft:purple_terracotta
fill 549 197 270 549 199 270 minecraft:purple_terracotta
setblock 550 197 270 minecraft:gray_terracotta
fill 553 197 228 553 199 228 minecraft:purple_terracotta
fill 553 197 270 553 199 270 minecraft:purple_terracotta
fill 557 197 228 557 199 228 minecraft:purple_terracotta
fill 557 197 270 557 199 270 minecraft:purple_terracotta
setblock 559 197 228 minecraft:purple_terracotta
fill 559 197 232 559 199 232 minecraft:purple_terracotta
fill 559 197 236 559 199 236 minecraft:purple_terracotta
fill 559 197 240 559 199 240 minecraft:purple_terracotta
fill 559 197 244 559 199 244 minecraft:purple_terracotta
fill 559 197 248 559 199 248 minecraft:purple_terracotta
fill 559 197 252 559 199 252 minecraft:purple_terracotta
fill 559 197 256 559 199 256 minecraft:purple_terracotta
fill 559 197 260 559 199 260 minecraft:purple_terracotta
fill 559 197 264 559 199 264 minecraft:purple_terracotta
fill 559 197 268 559 199 268 minecraft:purple_terracotta
setblock 517 198 230 minecraft:magenta_terracotta
setblock 517 198 234 minecraft:magenta_terracotta
setblock 517 198 238 minecraft:magenta_terracotta
fill 517 198 240 517 199 240 minecraft:purple_terracotta
setblock 517 198 242 minecraft:magenta_terracotta
setblock 517 198 246 minecraft:magenta_terracotta
setblock 517 198 250 minecraft:magenta_terracotta
setblock 517 198 254 minecraft:magenta_terracotta
setblock 517 198 258 minecraft:magenta_terracotta
setblock 517 198 262 minecraft:magenta_terracotta
setblock 517 198 266 minecraft:magenta_terracotta
setblock 517 198 270 minecraft:magenta_terracotta
setblock 519 198 228 minecraft:magenta_terracotta
fill 519 198 230 520 198 230 minecraft:spruce_planks
setblock 519 198 270 minecraft:magenta_terracotta
fill 521 198 229 522 198 230 minecraft:dark_oak_planks
setblock 523 198 228 minecraft:magenta_terracotta
setblock 523 198 270 minecraft:magenta_terracotta
setblock 527 198 228 minecraft:magenta_terracotta
setblock 527 198 270 minecraft:magenta_terracotta
fill 528 198 270 528 212 270 minecraft:purple_terracotta
setblock 531 198 228 minecraft:magenta_terracotta
setblock 531 198 270 minecraft:magenta_terracotta
setblock 535 198 228 minecraft:magenta_terracotta
setblock 535 198 270 minecraft:magenta_terracotta
setblock 539 198 228 minecraft:magenta_terracotta
setblock 539 198 270 minecraft:magenta_terracotta
setblock 543 198 228 minecraft:magenta_terracotta
setblock 543 198 270 minecraft:magenta_terracotta
setblock 547 198 228 minecraft:magenta_terracotta
setblock 547 198 270 minecraft:magenta_terracotta
fill 550 198 270 550 212 270 minecraft:purple_terracotta
setblock 551 198 228 minecraft:magenta_terracotta
setblock 551 198 270 minecraft:magenta_terracotta
setblock 555 198 228 minecraft:magenta_terracotta
setblock 555 198 270 minecraft:magenta_terracotta
setblock 559 198 228 minecraft:magenta_terracotta
setblock 559 198 230 minecraft:magenta_terracotta
setblock 559 198 234 minecraft:magenta_terracotta
setblock 559 198 238 minecraft:magenta_terracotta
setblock 559 198 242 minecraft:magenta_terracotta
setblock 559 198 246 minecraft:gray_terracotta
setblock 559 198 250 minecraft:magenta_terracotta
setblock 559 198 254 minecraft:magenta_terracotta
setblock 559 198 258 minecraft:magenta_terracotta
setblock 559 198 262 minecraft:magenta_terracotta
setblock 559 198 266 minecraft:magenta_terracotta
setblock 559 198 270 minecraft:magenta_terracotta
fill 517 199 230 517 201 230 minecraft:purple_terracotta
fill 517 199 234 517 201 234 minecraft:purple_terracotta
fill 517 199 238 517 201 238 minecraft:purple_terracotta
fill 517 199 242 517 201 242 minecraft:purple_terracotta
fill 517 199 246 517 201 246 minecraft:purple_terracotta
fill 517 199 250 517 201 250 minecraft:purple_terracotta
fill 517 199 254 517 201 254 minecraft:purple_terracotta
fill 517 199 258 517 201 258 minecraft:purple_terracotta
fill 517 199 262 517 201 262 minecraft:purple_terracotta
fill 517 199 266 517 201 266 minecraft:purple_terracotta
setblock 517 199 270 minecraft:purple_terracotta
fill 518 199 229 520 199 230 minecraft:dark_oak_planks
fill 519 199 228 519 201 228 minecraft:purple_terracotta
setblock 519 199 231 minecraft:spruce_planks
fill 519 199 270 519 201 270 minecraft:purple_terracotta
fill 523 199 228 523 201 228 minecraft:purple_terracotta
fill 523 199 270 523 201 270 minecraft:purple_terracotta
fill 527 199 228 527 201 228 minecraft:purple_terracotta
fill 527 199 270 527 201 270 minecraft:purple_terracotta
setblock 531 199 228 minecraft:purple_terracotta
fill 531 199 270 531 201 270 minecraft:purple_terracotta
fill 535 199 228 535 201 228 minecraft:purple_terracotta
fill 535 199 270 535 201 270 minecraft:purple_terracotta
fill 539 199 228 539 201 228 minecraft:purple_terracotta
fill 539 199 270 539 201 270 minecraft:purple_terracotta
fill 543 199 228 543 201 228 minecraft:purple_terracotta
fill 543 199 270 543 201 270 minecraft:purple_terracotta
fill 547 199 228 547 201 228 minecraft:purple_terracotta
fill 547 199 270 547 201 270 minecraft:purple_terracotta
fill 551 199 228 551 201 228 minecraft:purple_terracotta
fill 551 199 270 551 201 270 minecraft:purple_terracotta
fill 555 199 228 555 201 228 minecraft:purple_terracotta
fill 555 199 270 555 201 270 minecraft:purple_terracotta
setblock 559 199 228 minecraft:purple_terracotta
fill 559 199 230 559 201 230 minecraft:purple_terracotta
fill 559 199 234 559 201 234 minecraft:purple_terracotta
fill 559 199 238 559 201 238 minecraft:purple_terracotta
fill 559 199 242 559 201 242 minecraft:purple_terracotta
fill 559 199 246 559 201 246 minecraft:purple_terracotta
fill 559 199 250 559 201 250 minecraft:purple_terracotta
fill 559 199 254 559 201 254 minecraft:purple_terracotta
fill 559 199 258 559 201 258 minecraft:purple_terracotta
fill 559 199 262 559 201 262 minecraft:purple_terracotta
fill 559 199 266 559 201 266 minecraft:purple_terracotta
fill 559 199 270 559 201 270 minecraft:purple_terracotta
setblock 517 200 228 minecraft:magenta_terracotta
setblock 517 200 232 minecraft:magenta_terracotta
setblock 517 200 236 minecraft:magenta_terracotta
setblock 517 200 240 minecraft:magenta_terracotta
setblock 517 200 243 minecraft:light_gray_terracotta
setblock 517 200 244 minecraft:magenta_terracotta
setblock 517 200 248 minecraft:magenta_terracotta
setblock 517 200 252 minecraft:magenta_terracotta
setblock 517 200 256 minecraft:magenta_terracotta
setblock 517 200 260 minecraft:magenta_terracotta
setblock 517 200 264 minecraft:magenta_terracotta
setblock 517 200 268 minecraft:magenta_terracotta
setblock 517 200 270 minecraft:magenta_terracotta
fill 518 200 229 519 200 231 minecraft:dark_oak_planks
fill 519 200 232 519 200 233 minecraft:spruce_planks
setblock 520 200 231 minecraft:light[level=11]
setblock 520 200 239 minecraft:light[level=11]
setblock 520 200 247 minecraft:light[level=11]
setblock 520 200 255 minecraft:light[level=11]
setblock 520 200 263 minecraft:light[level=11]
setblock 521 200 228 minecraft:magenta_terracotta
setblock 521 200 270 minecraft:magenta_terracotta
setblock 525 200 228 minecraft:magenta_terracotta
setblock 525 200 270 minecraft:magenta_terracotta
setblock 528 200 231 minecraft:light[level=11]
setblock 528 200 239 minecraft:light[level=11]
setblock 528 200 247 minecraft:light[level=11]
setblock 528 200 255 minecraft:light[level=11]
setblock 528 200 263 minecraft:light[level=11]
setblock 529 200 228 minecraft:magenta_terracotta
setblock 529 200 270 minecraft:magenta_terracotta
setblock 530 200 270 minecraft:black_terracotta
setblock 531 200 228 minecraft:black_terracotta
setblock 533 200 228 minecraft:magenta_terracotta
setblock 533 200 270 minecraft:magenta_terracotta
setblock 536 200 231 minecraft:light[level=11]
setblock 536 200 239 minecraft:light[level=11]
setblock 536 200 247 minecraft:light[level=11]
setblock 536 200 255 minecraft:light[level=11]
setblock 536 200 263 minecraft:light[level=11]
setblock 537 200 228 minecraft:magenta_terracotta
setblock 537 200 270 minecraft:magenta_terracotta
setblock 541 200 228 minecraft:magenta_terracotta
setblock 541 200 270 minecraft:magenta_terracotta
setblock 544 200 231 minecraft:light[level=11]
setblock 544 200 239 minecraft:light[level=11]
setblock 544 200 247 minecraft:light[level=11]
setblock 544 200 255 minecraft:light[level=11]
setblock 544 200 263 minecraft:light[level=11]
setblock 545 200 228 minecraft:magenta_terracotta
setblock 545 200 270 minecraft:magenta_terracotta
setblock 549 200 228 minecraft:magenta_terracotta
setblock 549 200 270 minecraft:magenta_terracotta
setblock 552 200 231 minecraft:light[level=11]
setblock 552 200 239 minecraft:light[level=11]
setblock 552 200 247 minecraft:light[level=11]
setblock 552 200 255 minecraft:light[level=11]
setblock 552 200 263 minecraft:light[level=11]
setblock 553 200 228 minecraft:magenta_terracotta
setblock 553 200 270 minecraft:magenta_terracotta
setblock 557 200 228 minecraft:magenta_terracotta
setblock 557 200 270 minecraft:magenta_terracotta
setblock 559 200 228 minecraft:magenta_terracotta
setblock 559 200 232 minecraft:magenta_terracotta
setblock 559 200 236 minecraft:magenta_terracotta
setblock 559 200 240 minecraft:magenta_terracotta
setblock 559 200 244 minecraft:magenta_terracotta
setblock 559 200 248 minecraft:magenta_terracotta
setblock 559 200 252 minecraft:magenta_terracotta
setblock 559 200 256 minecraft:magenta_terracotta
setblock 559 200 260 minecraft:magenta_terracotta
setblock 559 200 264 minecraft:magenta_terracotta
setblock 559 200 268 minecraft:magenta_terracotta
fill 517 201 228 517 203 228 minecraft:purple_terracotta
fill 517 201 232 517 203 232 minecraft:purple_terracotta
fill 517 201 236 517 203 236 minecraft:purple_terracotta
fill 517 201 240 517 203 240 minecraft:purple_terracotta
fill 517 201 243 517 203 244 minecraft:purple_terracotta
fill 517 201 248 517 203 248 minecraft:purple_terracotta
fill 517 201 252 517 203 252 minecraft:purple_terracotta
fill 517 201 256 517 203 256 minecraft:purple_terracotta
fill 517 201 260 517 203 260 minecraft:purple_terracotta
fill 517 201 264 517 203 264 minecraft:purple_terracotta
fill 517 201 268 517 203 268 minecraft:purple_terracotta
setblock 517 201 270 minecraft:purple_terracotta
fill 518 201 232 519 201 233 minecraft:dark_oak_planks
fill 519 201 234 519 201 235 minecraft:spruce_planks
fill 521 201 228 521 203 228 minecraft:purple_terracotta
fill 521 201 270 521 203 270 minecraft:purple_terracotta
fill 525 201 228 525 203 228 minecraft:purple_terracotta
fill 525 201 270 525 203 270 minecraft:purple_terracotta
fill 529 201 228 529 203 228 minecraft:purple_terracotta
fill 529 201 270 530 203 270 minecraft:purple_terracotta
setblock 530 201 228 minecraft:gray_terracotta
setblock 531 201 228 minecraft:purple_terracotta
fill 533 201 228 533 203 228 minecraft:purple_terracotta
fill 533 201 270 533 203 270 minecraft:purple_terracotta
fill 537 201 228 537 203 228 minecraft:purple_terracotta
fill 537 201 270 537 203 270 minecraft:purple_terracotta
fill 541 201 228 541 203 228 minecraft:purple_terracotta
fill 541 201 270 541 203 270 minecraft:purple_terracotta
fill 545 201 228 545 203 228 minecraft:purple_terracotta
fill 545 201 270 545 203 270 minecraft:purple_terracotta
fill 549 201 228 549 203 228 minecraft:purple_terracotta
fill 549 201 270 549 203 270 minecraft:purple_terracotta
fill 553 201 228 553 203 228 minecraft:purple_terracotta
fill 553 201 270 553 203 270 minecraft:purple_terracotta
fill 557 201 228 557 203 228 minecraft:purple_terracotta
fill 557 201 270 557 203 270 minecraft:purple_terracotta
setblock 559 201 228 minecraft:purple_terracotta
fill 559 201 232 559 203 232 minecraft:purple_terracotta
fill 559 201 236 559 203 236 minecraft:purple_terracotta
fill 559 201 240 559 203 240 minecraft:purple_terracotta
fill 559 201 244 559 203 244 minecraft:purple_terracotta
fill 559 201 248 559 203 248 minecraft:purple_terracotta
fill 559 201 252 559 203 252 minecraft:purple_terracotta
fill 559 201 256 559 203 256 minecraft:purple_terracotta
fill 559 201 260 559 203 260 minecraft:purple_terracotta
fill 559 201 264 559 203 264 minecraft:purple_terracotta
fill 559 201 268 559 203 268 minecraft:purple_terracotta
setblock 517 202 230 minecraft:magenta_terracotta
setblock 517 202 234 minecraft:magenta_terracotta
setblock 517 202 238 minecraft:magenta_terracotta
setblock 517 202 242 minecraft:magenta_terracotta
setblock 517 202 246 minecraft:magenta_terracotta
setblock 517 202 250 minecraft:magenta_terracotta
setblock 517 202 254 minecraft:magenta_terracotta
setblock 517 202 258 minecraft:magenta_terracotta
setblock 517 202 262 minecraft:magenta_terracotta
setblock 517 202 266 minecraft:magenta_terracotta
setblock 517 202 270 minecraft:magenta_terracotta
fill 518 202 234 519 202 235 minecraft:dark_oak_planks
setblock 519 202 228 minecraft:magenta_terracotta
fill 519 202 236 519 202 237 minecraft:spruce_planks
setblock 519 202 270 minecraft:magenta_terracotta
setblock 520 202 231 minecraft:light[level=12]
setblock 520 202 238 minecraft:light[level=12]
setblock 520 202 245 minecraft:light[level=12]
setblock 520 202 252 minecraft:light[level=12]
setblock 520 202 259 minecraft:light[level=12]
setblock 520 202 266 minecraft:light[level=12]
setblock 523 202 228 minecraft:magenta_terracotta
setblock 523 202 270 minecraft:magenta_terracotta
setblock 527 202 228 minecraft:magenta_terracotta
setblock 527 202 231 minecraft:light[level=12]
setblock 527 202 238 minecraft:light[level=12]
setblock 527 202 245 minecraft:light[level=12]
setblock 527 202 252 minecraft:light[level=12]
setblock 527 202 259 minecraft:light[level=12]
setblock 527 202 266 minecraft:light[level=12]
setblock 527 202 270 minecraft:magenta_terracotta
fill 530 202 228 530 204 228 minecraft:purple_terracotta
setblock 531 202 228 minecraft:magenta_terracotta
setblock 531 202 270 minecraft:light_gray_terracotta
setblock 534 202 231 minecraft:light[level=12]
setblock 534 202 238 minecraft:light[level=12]
setblock 534 202 245 minecraft:light[level=12]
setblock 534 202 252 minecraft:light[level=12]
setblock 534 202 259 minecraft:light[level=12]
setblock 534 202 266 minecraft:light[level=12]
setblock 535 202 228 minecraft:magenta_terracotta
setblock 535 202 270 minecraft:magenta_terracotta
setblock 539 202 228 minecraft:magenta_terracotta
setblock 539 202 270 minecraft:magenta_terracotta
setblock 541 202 231 minecraft:light[level=12]
setblock 541 202 238 minecraft:light[level=12]
setblock 541 202 245 minecraft:light[level=12]
setblock 541 202 252 minecraft:light[level=12]
setblock 541 202 259 minecraft:light[level=12]
setblock 541 202 266 minecraft:light[level=12]
setblock 543 202 228 minecraft:magenta_terracotta
setblock 543 202 270 minecraft:magenta_terracotta
setblock 547 202 228 minecraft:magenta_terracotta
setblock 547 202 270 minecraft:magenta_terracotta
setblock 548 202 231 minecraft:light[level=12]
setblock 548 202 238 minecraft:light[level=12]
setblock 548 202 245 minecraft:light[level=12]
setblock 548 202 252 minecraft:light[level=12]
setblock 548 202 259 minecraft:light[level=12]
setblock 548 202 266 minecraft:light[level=12]
setblock 551 202 228 minecraft:magenta_terracotta
setblock 551 202 270 minecraft:magenta_terracotta
setblock 555 202 228 minecraft:magenta_terracotta
setblock 555 202 231 minecraft:light[level=12]
setblock 555 202 238 minecraft:light[level=12]
setblock 555 202 245 minecraft:light[level=12]
setblock 555 202 252 minecraft:light[level=12]
setblock 555 202 259 minecraft:light[level=12]
setblock 555 202 266 minecraft:light[level=12]
setblock 555 202 270 minecraft:magenta_terracotta
setblock 559 202 228 minecraft:magenta_terracotta
setblock 559 202 230 minecraft:magenta_terracotta
setblock 559 202 234 minecraft:magenta_terracotta
setblock 559 202 238 minecraft:magenta_terracotta
setblock 559 202 242 minecraft:magenta_terracotta
setblock 559 202 246 minecraft:magenta_terracotta
setblock 559 202 250 minecraft:magenta_terracotta
setblock 559 202 254 minecraft:magenta_terracotta
setblock 559 202 258 minecraft:magenta_terracotta
setblock 559 202 262 minecraft:magenta_terracotta
setblock 559 202 266 minecraft:magenta_terracotta
setblock 559 202 270 minecraft:magenta_terracotta
fill 517 203 230 517 205 230 minecraft:purple_terracotta
fill 517 203 234 517 205 234 minecraft:purple_terracotta
fill 517 203 238 517 205 238 minecraft:purple_terracotta
fill 517 203 242 517 205 242 minecraft:purple_terracotta
fill 517 203 246 517 205 246 minecraft:purple_terracotta
fill 517 203 250 517 205 250 minecraft:purple_terracotta
fill 517 203 254 517 205 254 minecraft:purple_terracotta
fill 517 203 258 517 205 258 minecraft:purple_terracotta
fill 517 203 262 517 205 262 minecraft:purple_terracotta
fill 517 203 266 517 205 266 minecraft:purple_terracotta
setblock 517 203 270 minecraft:purple_terracotta
fill 518 203 236 519 203 237 minecraft:dark_oak_planks
fill 519 203 228 519 205 228 minecraft:purple_terracotta
fill 519 203 238 519 203 239 minecraft:spruce_planks
fill 519 203 270 519 205 270 minecraft:purple_terracotta
fill 523 203 228 523 205 228 minecraft:purple_terracotta
fill 523 203 270 523 205 270 minecraft:purple_terracotta
fill 527 203 228 527 205 228 minecraft:purple_terracotta
fill 527 203 270 527 205 270 minecraft:purple_terracotta
fill 531 203 228 531 205 228 minecraft:purple_terracotta
fill 531 203 270 531 205 270 minecraft:purple_terracotta
fill 535 203 228 535 205 228 minecraft:purple_terracotta
fill 535 203 270 535 205 270 minecraft:purple_terracotta
fill 539 203 228 539 205 228 minecraft:purple_terracotta
fill 539 203 270 539 205 270 minecraft:purple_terracotta
fill 543 203 228 543 205 228 minecraft:purple_terracotta
fill 543 203 270 543 205 270 minecraft:purple_terracotta
fill 547 203 228 547 205 228 minecraft:purple_terracotta
fill 547 203 270 547 205 270 minecraft:purple_terracotta
fill 551 203 228 551 205 228 minecraft:purple_terracotta
fill 551 203 270 551 205 270 minecraft:purple_terracotta
fill 555 203 228 555 205 228 minecraft:purple_terracotta
fill 555 203 270 555 205 270 minecraft:purple_terracotta
setblock 559 203 228 minecraft:purple_terracotta
setblock 559 203 229 minecraft:gray_terracotta
fill 559 203 230 559 205 230 minecraft:purple_terracotta
fill 559 203 234 559 205 234 minecraft:purple_terracotta
fill 559 203 238 559 205 238 minecraft:purple_terracotta
fill 559 203 242 559 205 242 minecraft:purple_terracotta
fill 559 203 246 559 205 246 minecraft:purple_terracotta
fill 559 203 250 559 205 250 minecraft:purple_terracotta
fill 559 203 254 559 205 254 minecraft:purple_terracotta
fill 559 203 258 559 205 258 minecraft:purple_terracotta
fill 559 203 262 559 205 262 minecraft:purple_terracotta
fill 559 203 266 559 205 266 minecraft:purple_terracotta
fill 559 203 270 559 205 270 minecraft:purple_terracotta
setblock 517 204 228 minecraft:magenta_terracotta
setblock 517 204 232 minecraft:magenta_terracotta
setblock 517 204 236 minecraft:magenta_terracotta
setblock 517 204 240 minecraft:magenta_terracotta
fill 517 204 243 517 212 243 minecraft:purple_terracotta
setblock 517 204 244 minecraft:magenta_terracotta
setblock 517 204 248 minecraft:magenta_terracotta
setblock 517 204 252 minecraft:magenta_terracotta
setblock 517 204 256 minecraft:magenta_terracotta
setblock 517 204 260 minecraft:magenta_terracotta
setblock 517 204 264 minecraft:magenta_terracotta
setblock 517 204 268 minecraft:magenta_terracotta
setblock 517 204 270 minecraft:magenta_terracotta
fill 518 204 238 519 204 239 minecraft:dark_oak_planks
fill 519 204 240 519 204 241 minecraft:spruce_planks
setblock 521 204 228 minecraft:magenta_terracotta
setblock 521 204 270 minecraft:magenta_terracotta
setblock 525 204 228 minecraft:magenta_terracotta
setblock 525 204 270 minecraft:magenta_terracotta
setblock 529 204 228 minecraft:magenta_terracotta
setblock 529 204 270 minecraft:magenta_terracotta
fill 530 204 270 530 212 270 minecraft:purple_terracotta
setblock 533 204 228 minecraft:magenta_terracotta
setblock 533 204 270 minecraft:magenta_terracotta
setblock 537 204 228 minecraft:magenta_terracotta
setblock 537 204 270 minecraft:magenta_terracotta
setblock 541 204 228 minecraft:magenta_terracotta
setblock 541 204 270 minecraft:magenta_terracotta
setblock 545 204 228 minecraft:magenta_terracotta
setblock 545 204 270 minecraft:magenta_terracotta
setblock 549 204 228 minecraft:magenta_terracotta
setblock 549 204 270 minecraft:magenta_terracotta
setblock 553 204 228 minecraft:magenta_terracotta
setblock 553 204 270 minecraft:magenta_terracotta
setblock 557 204 228 minecraft:magenta_terracotta
setblock 557 204 270 minecraft:magenta_terracotta
setblock 559 204 228 minecraft:magenta_terracotta
fill 559 204 229 559 212 229 minecraft:purple_terracotta
setblock 559 204 232 minecraft:magenta_terracotta
setblock 559 204 236 minecraft:magenta_terracotta
setblock 559 204 240 minecraft:magenta_terracotta
setblock 559 204 244 minecraft:magenta_terracotta
setblock 559 204 248 minecraft:magenta_terracotta
setblock 559 204 252 minecraft:magenta_terracotta
setblock 559 204 256 minecraft:magenta_terracotta
setblock 559 204 260 minecraft:magenta_terracotta
setblock 559 204 264 minecraft:magenta_terracotta
setblock 559 204 268 minecraft:magenta_terracotta
fill 517 205 228 517 207 228 minecraft:purple_terracotta
fill 517 205 232 517 207 232 minecraft:purple_terracotta
fill 517 205 236 517 207 236 minecraft:purple_terracotta
fill 517 205 240 517 207 240 minecraft:purple_terracotta
fill 517 205 244 517 207 244 minecraft:purple_terracotta
fill 517 205 248 517 207 248 minecraft:purple_terracotta
fill 517 205 252 517 207 252 minecraft:purple_terracotta
fill 517 205 256 517 207 256 minecraft:purple_terracotta
fill 517 205 260 517 207 260 minecraft:purple_terracotta
fill 517 205 264 517 207 264 minecraft:purple_terracotta
fill 517 205 268 517 207 268 minecraft:purple_terracotta
setblock 517 205 270 minecraft:purple_terracotta
fill 518 205 240 519 205 241 minecraft:dark_oak_planks
fill 519 205 242 519 205 243 minecraft:spruce_planks
fill 521 205 228 521 207 228 minecraft:purple_terracotta
fill 521 205 270 521 207 270 minecraft:purple_terracotta
fill 525 205 228 525 207 228 minecraft:purple_terracotta
fill 525 205 270 525 207 270 minecraft:purple_terracotta
fill 529 205 228 529 207 228 minecraft:purple_terracotta
fill 529 205 270 529 207 270 minecraft:purple_terracotta
setblock 530 205 228 minecraft:light_gray_terracotta
fill 533 205 228 533 207 228 minecraft:purple_terracotta
fill 533 205 270 533 207 270 minecraft:purple_terracotta
fill 537 205 228 537 207 228 minecraft:purple_terracotta
fill 537 205 270 537 207 270 minecraft:purple_terracotta
fill 541 205 228 541 207 228 minecraft:purple_terracotta
fill 541 205 270 541 207 270 minecraft:purple_terracotta
fill 545 205 228 545 207 228 minecraft:purple_terracotta
fill 545 205 270 545 207 270 minecraft:purple_terracotta
fill 549 205 228 549 207 228 minecraft:purple_terracotta
fill 549 205 270 549 207 270 minecraft:purple_terracotta
fill 553 205 228 553 207 228 minecraft:purple_terracotta
fill 553 205 270 553 207 270 minecraft:purple_terracotta
fill 557 205 228 557 207 228 minecraft:purple_terracotta
fill 557 205 270 557 207 270 minecraft:purple_terracotta
setblock 559 205 228 minecraft:purple_terracotta
fill 559 205 232 559 207 232 minecraft:purple_terracotta
fill 559 205 236 559 207 236 minecraft:purple_terracotta
fill 559 205 240 559 207 240 minecraft:purple_terracotta
fill 559 205 244 559 207 244 minecraft:purple_terracotta
fill 559 205 248 559 207 248 minecraft:purple_terracotta
fill 559 205 252 559 207 252 minecraft:purple_terracotta
setblock 559 205 256 minecraft:purple_terracotta
fill 559 205 260 559 207 260 minecraft:purple_terracotta
fill 559 205 264 559 207 264 minecraft:purple_terracotta
fill 559 205 268 559 207 268 minecraft:purple_terracotta
setblock 517 206 230 minecraft:magenta_terracotta
setblock 517 206 234 minecraft:magenta_terracotta
setblock 517 206 238 minecraft:magenta_terracotta
setblock 517 206 242 minecraft:magenta_terracotta
setblock 517 206 246 minecraft:magenta_terracotta
setblock 517 206 250 minecraft:magenta_terracotta
setblock 517 206 254 minecraft:magenta_terracotta
setblock 517 206 258 minecraft:magenta_terracotta
setblock 517 206 262 minecraft:magenta_terracotta
setblock 517 206 266 minecraft:magenta_terracotta
setblock 517 206 270 minecraft:magenta_terracotta
fill 518 206 242 519 206 243 minecraft:dark_oak_planks
setblock 519 206 228 minecraft:magenta_terracotta
fill 519 206 244 519 206 245 minecraft:spruce_planks
setblock 519 206 270 minecraft:magenta_terracotta
setblock 523 206 228 minecraft:magenta_terracotta
setblock 523 206 270 minecraft:magenta_terracotta
setblock 527 206 228 minecraft:magenta_terracotta
setblock 527 206 270 minecraft:magenta_terracotta
fill 530 206 228 530 212 228 minecraft:purple_terracotta
setblock 531 206 228 minecraft:magenta_terracotta
setblock 531 206 270 minecraft:magenta_terracotta
setblock 535 206 228 minecraft:magenta_terracotta
setblock 535 206 270 minecraft:magenta_terracotta
setblock 539 206 228 minecraft:magenta_terracotta
setblock 539 206 270 minecraft:magenta_terracotta
setblock 543 206 228 minecraft:magenta_terracotta
setblock 543 206 270 minecraft:magenta_terracotta
setblock 547 206 228 minecraft:magenta_terracotta
setblock 547 206 270 minecraft:magenta_terracotta
setblock 551 206 228 minecraft:magenta_terracotta
setblock 551 206 270 minecraft:magenta_terracotta
setblock 555 206 228 minecraft:magenta_terracotta
setblock 555 206 270 minecraft:magenta_terracotta
setblock 559 206 228 minecraft:magenta_terracotta
setblock 559 206 230 minecraft:magenta_terracotta
setblock 559 206 234 minecraft:magenta_terracotta
setblock 559 206 238 minecraft:magenta_terracotta
setblock 559 206 242 minecraft:magenta_terracotta
setblock 559 206 246 minecraft:magenta_terracotta
setblock 559 206 250 minecraft:magenta_terracotta
setblock 559 206 254 minecraft:magenta_terracotta
setblock 559 206 256 minecraft:black_terracotta
setblock 559 206 258 minecraft:magenta_terracotta
setblock 559 206 262 minecraft:magenta_terracotta
setblock 559 206 266 minecraft:magenta_terracotta
setblock 559 206 270 minecraft:magenta_terracotta
fill 517 207 230 517 209 230 minecraft:purple_terracotta
fill 517 207 234 517 209 234 minecraft:purple_terracotta
fill 517 207 238 517 209 238 minecraft:purple_terracotta
fill 517 207 242 517 209 242 minecraft:purple_terracotta
fill 517 207 246 517 209 246 minecraft:purple_terracotta
fill 517 207 250 517 209 250 minecraft:purple_terracotta
fill 517 207 254 517 209 254 minecraft:purple_terracotta
fill 517 207 258 517 209 258 minecraft:purple_terracotta
fill 517 207 262 517 209 262 minecraft:purple_terracotta
fill 517 207 266 517 209 266 minecraft:purple_terracotta
setblock 517 207 270 minecraft:purple_terracotta
fill 518 207 244 519 207 245 minecraft:dark_oak_planks
fill 519 207 228 519 209 228 minecraft:purple_terracotta
fill 519 207 246 519 207 247 minecraft:spruce_planks
fill 519 207 270 519 209 270 minecraft:purple_terracotta
fill 523 207 228 523 209 228 minecraft:purple_terracotta
fill 523 207 270 523 209 270 minecraft:purple_terracotta
fill 527 207 228 527 209 228 minecraft:purple_terracotta
fill 527 207 270 527 209 270 minecraft:purple_terracotta
fill 531 207 228 531 209 228 minecraft:purple_terracotta
fill 531 207 270 531 209 270 minecraft:purple_terracotta
fill 535 207 228 535 209 228 minecraft:purple_terracotta
fill 535 207 270 535 209 270 minecraft:purple_terracotta
fill 539 207 228 539 209 228 minecraft:purple_terracotta
schedule function dropper:buildpart/59_3 1t
