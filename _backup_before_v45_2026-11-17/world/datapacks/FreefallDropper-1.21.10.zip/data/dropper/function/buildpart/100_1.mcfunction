setblock 191 102 435 minecraft:light[level=13]
setblock 191 102 443 minecraft:light[level=13]
setblock 191 102 451 minecraft:light[level=13]
setblock 199 102 419 minecraft:light[level=13]
setblock 199 102 427 minecraft:light[level=13]
setblock 199 102 435 minecraft:light[level=13]
setblock 199 102 443 minecraft:light[level=13]
setblock 199 102 451 minecraft:light[level=13]
setblock 207 102 419 minecraft:light[level=13]
setblock 207 102 427 minecraft:light[level=13]
setblock 207 102 435 minecraft:light[level=13]
setblock 207 102 443 minecraft:light[level=13]
setblock 207 102 451 minecraft:light[level=13]
setblock 215 102 419 minecraft:light[level=13]
setblock 215 102 427 minecraft:light[level=13]
setblock 215 102 435 minecraft:light[level=13]
setblock 215 102 443 minecraft:light[level=13]
setblock 215 102 451 minecraft:light[level=13]
setblock 223 102 419 minecraft:light[level=13]
setblock 223 102 427 minecraft:light[level=13]
setblock 223 102 435 minecraft:light[level=13]
setblock 223 102 443 minecraft:light[level=13]
setblock 223 102 451 minecraft:light[level=13]
fill 189 106 417 189 107 421 minecraft:iron_block
fill 189 106 422 189 107 423 minecraft:polished_deepslate
fill 189 106 424 189 107 432 minecraft:iron_block
fill 189 106 433 189 107 433 minecraft:polished_deepslate
fill 189 106 434 189 107 442 minecraft:iron_block
fill 189 106 443 189 107 444 minecraft:polished_deepslate
fill 189 106 445 189 107 453 minecraft:iron_block
fill 189 106 454 189 107 454 minecraft:polished_deepslate
fill 189 106 455 191 107 457 minecraft:iron_block
fill 190 106 417 190 107 419 minecraft:iron_block
fill 190 106 420 190 107 420 minecraft:polished_deepslate
fill 190 106 421 190 107 429 minecraft:iron_block
fill 190 106 430 190 107 431 minecraft:polished_deepslate
fill 190 106 432 190 107 440 minecraft:iron_block
fill 190 106 441 190 107 441 minecraft:polished_deepslate
fill 190 106 442 190 107 450 minecraft:iron_block
fill 190 106 451 190 107 452 minecraft:polished_deepslate
fill 190 106 453 193 107 454 minecraft:iron_block
fill 191 106 417 195 107 417 minecraft:iron_block
fill 191 106 418 191 107 418 minecraft:polished_deepslate
fill 191 106 419 191 107 427 minecraft:iron_block
fill 191 106 428 191 107 428 minecraft:polished_deepslate
fill 191 106 429 191 107 438 minecraft:iron_block
fill 191 106 439 191 107 439 minecraft:polished_deepslate
fill 191 106 440 191 107 448 minecraft:iron_block
fill 191 106 449 191 107 449 minecraft:polished_deepslate
fill 191 106 450 194 107 452 minecraft:iron_block
fill 192 106 418 192 107 425 minecraft:iron_block
fill 192 106 426 192 107 426 minecraft:polished_deepslate
fill 192 106 427 192 107 435 minecraft:iron_block
fill 192 106 436 192 106 437 minecraft:polished_deepslate
fill 192 106 438 192 107 446 minecraft:iron_block
fill 192 106 447 192 107 447 minecraft:polished_deepslate
fill 192 106 448 195 107 449 minecraft:iron_block
fill 192 106 455 192 107 456 minecraft:iron_block
fill 192 106 457 192 107 457 minecraft:polished_deepslate
fill 193 106 418 193 107 422 minecraft:iron_block
fill 193 106 423 193 107 424 minecraft:polished_deepslate
fill 193 106 425 193 107 433 minecraft:iron_block
setblock 193 106 434 minecraft:polished_deepslate
fill 193 106 435 193 107 443 minecraft:iron_block
fill 193 106 444 193 106 445 minecraft:polished_deepslate
fill 193 106 446 196 107 447 minecraft:iron_block
fill 193 106 455 193 107 455 minecraft:polished_deepslate
fill 193 106 456 196 107 457 minecraft:iron_block
fill 194 106 418 194 107 420 minecraft:iron_block
fill 194 106 421 194 107 421 minecraft:polished_deepslate
fill 194 106 422 194 107 431 minecraft:iron_block
setblock 194 106 432 minecraft:polished_deepslate
fill 194 106 433 194 108 441 minecraft:iron_block
setblock 194 106 442 minecraft:polished_deepslate
fill 194 106 443 197 107 445 minecraft:iron_block
fill 194 106 453 194 107 453 minecraft:polished_deepslate
fill 194 106 454 197 107 455 minecraft:iron_block
fill 195 106 418 199 107 418 minecraft:iron_block
fill 195 106 419 195 107 419 minecraft:polished_deepslate
fill 195 106 420 195 107 428 minecraft:iron_block
fill 195 106 429 195 107 430 minecraft:polished_deepslate
fill 195 106 431 195 107 439 minecraft:iron_block
setblock 195 106 440 minecraft:polished_deepslate
fill 195 106 441 198 108 442 minecraft:iron_block
fill 195 106 450 195 107 451 minecraft:polished_deepslate
fill 195 106 452 198 107 453 minecraft:iron_block
fill 196 106 417 196 107 417 minecraft:polished_deepslate
fill 196 106 419 196 107 426 minecraft:iron_block
fill 196 106 427 196 107 427 minecraft:polished_deepslate
fill 196 106 428 196 107 436 minecraft:iron_block
fill 196 106 437 196 106 438 minecraft:polished_deepslate
fill 196 106 439 199 108 440 minecraft:iron_block
setblock 196 106 448 minecraft:polished_deepslate
fill 196 106 449 198 107 451 minecraft:iron_block
fill 197 106 417 204 107 417 minecraft:iron_block
fill 197 106 419 197 107 424 minecraft:iron_block
fill 197 106 425 197 107 425 minecraft:polished_deepslate
fill 197 106 426 197 107 434 minecraft:iron_block
setblock 197 106 435 minecraft:polished_deepslate
fill 197 106 436 200 106 438 minecraft:iron_block
setblock 197 106 446 minecraft:polished_deepslate
fill 197 106 447 200 107 448 minecraft:iron_block
fill 197 106 456 197 107 456 minecraft:polished_deepslate
fill 197 106 457 200 107 457 minecraft:iron_block
fill 198 106 419 198 107 421 minecraft:iron_block
fill 198 106 422 198 107 423 minecraft:polished_deepslate
fill 198 106 424 198 107 432 minecraft:iron_block
setblock 198 106 433 minecraft:polished_deepslate
fill 198 106 434 201 108 435 minecraft:iron_block
fill 198 106 443 198 106 444 minecraft:polished_deepslate
fill 198 106 445 201 108 446 minecraft:iron_block
fill 198 106 454 198 107 454 minecraft:polished_deepslate
fill 198 106 455 201 107 456 minecraft:iron_block
fill 199 106 419 203 107 419 minecraft:iron_block
fill 199 106 420 199 107 420 minecraft:polished_deepslate
fill 199 106 421 199 107 429 minecraft:iron_block
fill 199 106 430 199 106 431 minecraft:polished_deepslate
fill 199 106 432 202 108 433 minecraft:iron_block
setblock 199 106 441 minecraft:polished_deepslate
fill 199 106 442 201 108 444 minecraft:iron_block
fill 199 106 449 199 107 450 minecraft:iron_block
fill 199 106 451 199 107 452 minecraft:polished_deepslate
fill 199 106 453 202 107 454 minecraft:iron_block
fill 200 106 418 200 107 418 minecraft:polished_deepslate
fill 200 106 420 200 107 427 minecraft:iron_block
setblock 200 106 428 minecraft:polished_deepslate
fill 200 106 429 203 108 431 minecraft:iron_block
setblock 200 106 439 minecraft:polished_deepslate
fill 200 106 440 202 106 441 minecraft:iron_block
fill 200 106 449 200 107 449 minecraft:polished_deepslate
fill 200 106 450 202 107 452 minecraft:iron_block
fill 201 106 418 208 107 418 minecraft:iron_block
fill 201 106 420 201 107 425 minecraft:iron_block
setblock 201 106 426 minecraft:polished_deepslate
fill 201 106 427 204 107 428 minecraft:iron_block
fill 201 106 436 201 106 437 minecraft:polished_deepslate
fill 201 106 438 201 106 439 minecraft:iron_block
setblock 201 106 447 minecraft:polished_deepslate
fill 201 106 448 204 107 449 minecraft:iron_block
fill 201 106 457 201 107 457 minecraft:polished_deepslate
fill 202 106 420 202 107 422 minecraft:iron_block
fill 202 106 423 202 107 424 minecraft:polished_deepslate
fill 202 106 425 205 107 426 minecraft:iron_block
setblock 202 106 434 minecraft:polished_deepslate
fill 202 106 435 202 106 436 minecraft:iron_block
fill 202 106 442 202 108 443 minecraft:iron_block
fill 202 106 444 202 106 445 minecraft:polished_deepslate
fill 202 106 446 205 108 447 minecraft:iron_block
fill 202 106 455 202 107 455 minecraft:polished_deepslate
fill 202 106 456 205 107 457 minecraft:iron_block
fill 203 106 420 207 107 420 minecraft:iron_block
fill 203 106 421 203 107 421 minecraft:polished_deepslate
fill 203 106 422 206 107 424 minecraft:iron_block
setblock 203 106 432 minecraft:polished_deepslate
fill 203 106 433 205 106 435 minecraft:iron_block
fill 203 106 441 207 106 441 minecraft:iron_block
setblock 203 106 442 minecraft:polished_deepslate
fill 203 106 443 205 108 445 minecraft:iron_block
fill 203 106 450 203 107 451 minecraft:iron_block
fill 203 106 452 203 107 453 minecraft:polished_deepslate
fill 203 106 454 206 107 455 minecraft:iron_block
fill 204 106 419 204 107 419 minecraft:polished_deepslate
fill 204 106 421 211 107 421 minecraft:iron_block
fill 204 106 429 204 106 430 minecraft:polished_deepslate
fill 204 106 431 207 108 432 minecraft:iron_block
fill 204 106 442 211 106 442 minecraft:iron_block
fill 204 106 450 204 107 450 minecraft:polished_deepslate
fill 204 106 451 207 107 453 minecraft:iron_block
fill 205 106 417 205 107 417 minecraft:polished_deepslate
fill 205 106 419 212 107 419 minecraft:iron_block
fill 205 106 427 205 107 427 minecraft:polished_deepslate
fill 205 106 428 207 108 430 minecraft:iron_block
setblock 205 106 448 minecraft:polished_deepslate
fill 205 106 449 208 107 450 minecraft:iron_block
fill 206 106 417 213 107 417 minecraft:iron_block
fill 206 106 425 206 107 425 minecraft:polished_deepslate
fill 206 106 426 209 107 427 minecraft:iron_block
fill 206 106 433 206 108 434 minecraft:iron_block
setblock 206 106 435 minecraft:polished_deepslate
fill 206 106 436 209 106 436 minecraft:iron_block
fill 206 106 440 212 106 440 minecraft:iron_block
fill 206 106 443 206 108 444 minecraft:iron_block
fill 206 106 445 206 106 446 minecraft:polished_deepslate
fill 206 106 447 209 107 448 minecraft:iron_block
fill 206 106 456 206 107 456 minecraft:polished_deepslate
fill 206 106 457 209 107 457 minecraft:iron_block
fill 207 106 422 207 107 423 minecraft:polished_deepslate
fill 207 106 424 210 107 425 minecraft:iron_block
setblock 207 106 433 minecraft:polished_deepslate
fill 207 106 434 210 108 435 minecraft:iron_block
fill 207 106 437 208 106 439 minecraft:iron_block
setblock 207 106 443 minecraft:polished_deepslate
fill 207 106 444 210 108 446 minecraft:iron_block
fill 207 106 454 207 107 454 minecraft:polished_deepslate
fill 207 106 455 210 107 456 minecraft:iron_block
fill 208 106 420 208 107 420 minecraft:polished_deepslate
fill 208 106 422 210 107 423 minecraft:iron_block
fill 208 106 428 208 108 429 minecraft:iron_block
fill 208 106 430 208 106 431 minecraft:polished_deepslate
fill 208 106 432 211 108 433 minecraft:iron_block
setblock 208 106 441 minecraft:polished_deepslate
fill 208 106 443 215 108 443 minecraft:iron_block
fill 208 106 451 208 107 452 minecraft:polished_deepslate
fill 208 106 453 211 107 454 minecraft:iron_block
fill 209 106 418 209 107 418 minecraft:polished_deepslate
fill 209 106 420 216 107 420 minecraft:iron_block
fill 209 106 428 209 107 428 minecraft:polished_deepslate
fill 209 106 429 211 108 431 minecraft:iron_block
fill 209 106 437 213 108 437 minecraft:iron_block
fill 209 106 438 209 106 439 minecraft:polished_deepslate
fill 209 106 441 216 107 441 minecraft:iron_block
fill 209 106 449 209 107 449 minecraft:polished_deepslate
fill 209 106 450 211 107 452 minecraft:iron_block
fill 210 106 418 217 107 418 minecraft:iron_block
fill 210 106 426 210 107 426 minecraft:polished_deepslate
fill 210 106 427 213 107 428 minecraft:iron_block
setblock 210 106 436 minecraft:polished_deepslate
fill 210 106 438 213 108 439 minecraft:iron_block
setblock 210 106 447 minecraft:polished_deepslate
fill 210 106 448 213 107 449 minecraft:iron_block
fill 210 106 457 210 107 457 minecraft:polished_deepslate
fill 211 106 422 215 107 422 minecraft:iron_block
fill 211 106 423 211 107 424 minecraft:polished_deepslate
fill 211 106 425 214 107 426 minecraft:iron_block
setblock 211 106 434 minecraft:polished_deepslate
fill 211 106 435 214 108 436 minecraft:iron_block
fill 211 106 444 211 106 445 minecraft:polished_deepslate
fill 211 106 446 214 107 447 minecraft:iron_block
fill 211 106 455 211 107 455 minecraft:polished_deepslate
fill 211 106 456 214 107 457 minecraft:iron_block
fill 212 106 421 212 107 421 minecraft:polished_deepslate
fill 212 106 423 214 107 424 minecraft:iron_block
fill 212 106 429 212 107 430 minecraft:iron_block
fill 212 106 431 212 106 432 minecraft:polished_deepslate
fill 212 106 433 215 108 434 minecraft:iron_block
setblock 212 106 442 minecraft:polished_deepslate
fill 212 106 444 214 107 445 minecraft:iron_block
fill 212 106 450 212 107 451 minecraft:iron_block
fill 212 106 452 212 107 453 minecraft:polished_deepslate
fill 212 106 454 215 107 455 minecraft:iron_block
fill 213 106 419 213 107 419 minecraft:polished_deepslate
fill 213 106 421 220 107 421 minecraft:iron_block
fill 213 106 429 213 107 429 minecraft:polished_deepslate
fill 213 106 430 216 107 432 minecraft:iron_block
setblock 213 106 440 minecraft:polished_deepslate
fill 213 106 442 220 107 442 minecraft:iron_block
fill 213 106 450 213 107 450 minecraft:polished_deepslate
fill 213 106 451 216 107 453 minecraft:iron_block
fill 214 106 417 214 107 417 minecraft:polished_deepslate
fill 214 106 419 221 107 419 minecraft:iron_block
fill 214 106 427 214 107 427 minecraft:polished_deepslate
fill 214 106 428 217 107 429 minecraft:iron_block
fill 214 106 437 214 106 438 minecraft:polished_deepslate
fill 214 106 439 217 107 440 minecraft:iron_block
fill 214 106 448 214 107 448 minecraft:polished_deepslate
fill 214 106 449 217 107 450 minecraft:iron_block
fill 215 106 417 217 107 417 minecraft:iron_block
fill 215 106 423 219 107 423 minecraft:iron_block
fill 215 106 424 215 107 425 minecraft:polished_deepslate
fill 215 106 426 218 107 427 minecraft:iron_block
fill 215 106 435 215 107 435 minecraft:polished_deepslate
fill 215 106 436 217 107 438 minecraft:iron_block
fill 215 106 444 219 107 444 minecraft:iron_block
fill 215 106 445 215 107 446 minecraft:polished_deepslate
fill 215 106 447 218 107 448 minecraft:iron_block
fill 215 106 456 215 107 456 minecraft:polished_deepslate
fill 215 106 457 218 107 457 minecraft:iron_block
fill 216 106 422 216 107 422 minecraft:polished_deepslate
fill 216 106 424 219 107 425 minecraft:iron_block
setblock 216 106 433 minecraft:polished_deepslate
fill 216 106 434 219 107 435 minecraft:iron_block
setblock 216 106 443 minecraft:polished_deepslate
fill 216 106 445 219 107 446 minecraft:iron_block
fill 216 106 454 216 107 454 minecraft:polished_deepslate
fill 216 106 455 219 107 456 minecraft:iron_block
fill 217 106 420 217 107 420 minecraft:polished_deepslate
fill 217 106 422 224 107 422 minecraft:iron_block
fill 217 106 430 217 107 431 minecraft:polished_deepslate
fill 217 106 432 220 107 433 minecraft:iron_block
fill 217 106 441 217 107 441 minecraft:polished_deepslate
fill 217 106 443 224 107 443 minecraft:iron_block
fill 217 106 451 217 107 452 minecraft:polished_deepslate
fill 217 106 453 220 107 454 minecraft:iron_block
fill 218 106 417 218 107 418 minecraft:polished_deepslate
fill 218 106 420 225 107 420 minecraft:iron_block
fill 218 106 428 218 107 428 minecraft:polished_deepslate
fill 218 106 429 220 107 431 minecraft:iron_block
fill 218 106 436 218 107 437 minecraft:iron_block
fill 218 106 438 218 107 439 minecraft:polished_deepslate
fill 218 106 440 221 107 441 minecraft:iron_block
fill 218 106 449 218 107 449 minecraft:polished_deepslate
fill 218 106 450 220 107 452 minecraft:iron_block
fill 219 106 417 222 107 418 minecraft:iron_block
fill 219 106 426 219 107 426 minecraft:polished_deepslate
fill 219 106 427 222 107 428 minecraft:iron_block
fill 219 106 436 219 107 436 minecraft:polished_deepslate
fill 219 106 437 222 107 439 minecraft:iron_block
fill 219 106 447 219 107 447 minecraft:polished_deepslate
fill 219 106 448 222 107 449 minecraft:iron_block
fill 219 106 457 219 107 457 minecraft:polished_deepslate
fill 220 106 423 220 107 424 minecraft:polished_deepslate
fill 220 106 425 223 107 426 minecraft:iron_block
fill 220 106 434 220 107 434 minecraft:polished_deepslate
fill 220 106 435 223 107 436 minecraft:iron_block
fill 220 106 444 220 107 445 minecraft:polished_deepslate
fill 220 106 446 223 107 447 minecraft:iron_block
fill 220 106 455 220 107 455 minecraft:polished_deepslate
fill 220 106 456 223 107 457 minecraft:iron_block
fill 221 106 421 221 107 421 minecraft:polished_deepslate
fill 221 106 423 223 107 424 minecraft:iron_block
fill 221 106 429 221 107 430 minecraft:iron_block
fill 221 106 431 221 107 432 minecraft:polished_deepslate
fill 221 106 433 224 107 434 minecraft:iron_block
fill 221 106 442 221 107 442 minecraft:polished_deepslate
fill 221 106 444 223 107 445 minecraft:iron_block
fill 221 106 450 221 107 451 minecraft:iron_block
fill 221 106 452 221 107 453 minecraft:polished_deepslate
fill 221 106 454 224 107 455 minecraft:iron_block
fill 222 106 419 222 107 419 minecraft:polished_deepslate
fill 222 106 421 229 107 421 minecraft:iron_block
fill 222 106 429 222 107 429 minecraft:polished_deepslate
fill 222 106 430 225 107 432 minecraft:iron_block
fill 222 106 440 222 107 440 minecraft:polished_deepslate
fill 222 106 441 225 107 442 minecraft:iron_block
fill 222 106 450 222 107 450 minecraft:polished_deepslate
fill 222 106 451 224 107 453 minecraft:iron_block
fill 223 106 417 223 107 417 minecraft:polished_deepslate
fill 223 106 418 226 107 419 minecraft:iron_block
fill 223 106 427 223 107 427 minecraft:polished_deepslate
fill 223 106 428 226 107 429 minecraft:iron_block
fill 223 106 437 223 107 438 minecraft:polished_deepslate
fill 223 106 439 226 107 440 minecraft:iron_block
fill 223 106 448 223 107 448 minecraft:polished_deepslate
fill 223 106 449 226 107 450 minecraft:iron_block
fill 224 106 417 226 107 417 minecraft:iron_block
fill 224 106 423 228 107 423 minecraft:iron_block
fill 224 106 424 224 107 425 minecraft:polished_deepslate
fill 224 106 426 227 107 427 minecraft:iron_block
fill 224 106 435 224 107 435 minecraft:polished_deepslate
fill 224 106 436 226 107 438 minecraft:iron_block
fill 224 106 444 228 107 444 minecraft:iron_block
fill 224 106 445 224 107 446 minecraft:polished_deepslate
fill 224 106 447 227 107 448 minecraft:iron_block
fill 224 106 456 224 107 456 minecraft:polished_deepslate
fill 224 106 457 227 107 457 minecraft:iron_block
fill 225 106 422 225 107 422 minecraft:polished_deepslate
fill 225 106 424 228 107 425 minecraft:iron_block
fill 225 106 433 225 107 433 minecraft:polished_deepslate
fill 225 106 434 228 107 435 minecraft:iron_block
fill 225 106 443 225 107 443 minecraft:polished_deepslate
fill 225 106 445 227 107 446 minecraft:iron_block
fill 225 106 451 225 107 452 minecraft:iron_block
fill 225 106 453 225 107 454 minecraft:polished_deepslate
fill 225 106 455 228 107 456 minecraft:iron_block
fill 226 106 420 226 107 420 minecraft:polished_deepslate
fill 226 106 422 229 107 422 minecraft:iron_block
fill 226 106 430 226 107 431 minecraft:polished_deepslate
fill 226 106 432 229 107 433 minecraft:iron_block
fill 226 106 441 226 107 441 minecraft:polished_deepslate
fill 226 106 442 229 107 443 minecraft:iron_block
fill 226 106 451 226 107 452 minecraft:polished_deepslate
fill 226 106 453 229 107 454 minecraft:iron_block
fill 227 106 417 227 107 418 minecraft:polished_deepslate
fill 227 106 419 229 107 420 minecraft:iron_block
fill 227 106 428 227 107 428 minecraft:polished_deepslate
fill 227 106 429 229 107 431 minecraft:iron_block
fill 227 106 436 227 107 437 minecraft:iron_block
fill 227 106 438 227 107 439 minecraft:polished_deepslate
fill 227 106 440 229 107 441 minecraft:iron_block
fill 227 106 449 227 107 449 minecraft:polished_deepslate
fill 227 106 450 229 107 452 minecraft:iron_block
fill 228 106 417 229 107 418 minecraft:iron_block
fill 228 106 426 228 107 426 minecraft:polished_deepslate
fill 228 106 427 229 107 428 minecraft:iron_block
fill 228 106 436 228 107 436 minecraft:polished_deepslate
fill 228 106 437 229 107 439 minecraft:iron_block
fill 228 106 445 228 107 445 minecraft:iron_block
fill 228 106 446 228 107 447 minecraft:polished_deepslate
fill 228 106 448 229 107 449 minecraft:iron_block
fill 228 106 457 228 107 457 minecraft:polished_deepslate
fill 229 106 423 229 107 424 minecraft:polished_deepslate
fill 229 106 425 229 107 426 minecraft:iron_block
fill 229 106 434 229 107 434 minecraft:polished_deepslate
fill 229 106 435 229 107 436 minecraft:iron_block
fill 229 106 444 229 107 445 minecraft:polished_deepslate
fill 229 106 446 229 107 447 minecraft:iron_block
fill 229 106 455 229 107 455 minecraft:polished_deepslate
fill 229 106 456 229 107 457 minecraft:iron_block
setblock 192 107 436 minecraft:polished_deepslate
fill 192 107 437 192 108 437 minecraft:iron_block
fill 193 107 434 193 108 434 minecraft:iron_block
fill 193 107 444 193 108 444 minecraft:iron_block
setblock 193 107 445 minecraft:polished_deepslate
fill 194 107 432 194 108 432 minecraft:iron_block
fill 194 107 442 194 108 442 minecraft:iron_block
fill 195 107 440 195 108 440 minecraft:iron_block
fill 196 107 437 199 108 438 minecraft:iron_block
fill 196 107 448 196 108 448 minecraft:iron_block
fill 197 107 435 197 108 436 minecraft:iron_block
fill 197 107 446 197 108 446 minecraft:iron_block
fill 198 107 433 198 108 433 minecraft:iron_block
fill 198 107 436 200 108 436 minecraft:iron_block
fill 198 107 443 198 108 444 minecraft:iron_block
fill 199 107 430 199 108 431 minecraft:iron_block
fill 199 107 441 201 108 441 minecraft:iron_block
fill 200 107 428 200 108 428 minecraft:iron_block
fill 200 107 437 200 108 437 minecraft:iron_block
fill 200 107 438 201 107 438 minecraft:waxed_copper_block
fill 200 107 439 200 108 440 minecraft:iron_block
fill 201 107 426 201 108 426 minecraft:iron_block
fill 201 107 436 201 108 437 minecraft:waxed_copper_block
fill 201 107 439 201 108 440 minecraft:waxed_copper_block
fill 201 107 447 201 108 447 minecraft:iron_block
fill 202 107 434 203 108 434 minecraft:iron_block
fill 202 107 435 202 107 436 minecraft:waxed_copper_block
fill 202 107 440 202 107 441 minecraft:waxed_copper_block
fill 202 107 444 202 108 445 minecraft:iron_block
fill 203 107 432 203 108 433 minecraft:iron_block
fill 203 107 435 206 107 435 minecraft:waxed_copper_block
fill 203 107 441 206 107 441 minecraft:waxed_copper_block
fill 203 107 442 203 108 442 minecraft:iron_block
fill 204 107 429 204 108 430 minecraft:iron_block
fill 204 107 433 205 108 433 minecraft:iron_block
fill 204 107 434 204 109 434 minecraft:waxed_copper_block
fill 204 107 442 204 109 442 minecraft:waxed_copper_block
fill 205 107 434 205 108 434 minecraft:iron_block
fill 205 107 442 212 108 442 minecraft:iron_block
fill 205 107 448 205 108 448 minecraft:iron_block
fill 206 107 436 207 107 436 minecraft:waxed_copper_block
fill 206 107 440 207 107 440 minecraft:waxed_copper_block
fill 206 107 445 206 108 446 minecraft:iron_block
fill 207 107 433 207 108 433 minecraft:iron_block
fill 207 107 437 207 107 439 minecraft:waxed_copper_block
fill 207 107 441 208 108 441 minecraft:iron_block
fill 207 107 443 207 108 443 minecraft:iron_block
fill 208 107 430 208 108 431 minecraft:iron_block
fill 208 107 436 208 108 437 minecraft:iron_block
fill 208 107 438 208 109 438 minecraft:waxed_copper_block
fill 208 107 439 209 108 440 minecraft:iron_block
fill 209 107 436 210 108 436 minecraft:iron_block
fill 209 107 438 209 108 438 minecraft:iron_block
fill 210 107 440 213 108 440 minecraft:iron_block
fill 210 107 447 210 108 447 minecraft:iron_block
fill 211 107 434 211 108 434 minecraft:iron_block
fill 211 107 444 211 108 445 minecraft:iron_block
fill 212 107 431 212 108 432 minecraft:iron_block
fill 214 107 437 214 108 438 minecraft:iron_block
fill 216 107 433 216 108 433 minecraft:iron_block
fill 216 107 443 216 108 443 minecraft:iron_block
fill 191 108 438 193 108 438 minecraft:iron_block
fill 192 108 433 193 108 433 minecraft:iron_block
setblock 192 108 439 minecraft:iron_block
fill 192 108 443 197 108 443 minecraft:iron_block
setblock 193 108 432 minecraft:iron_block
setblock 193 108 442 minecraft:iron_block
fill 194 108 444 197 108 444 minecraft:iron_block
fill 195 108 432 195 108 439 minecraft:iron_block
fill 196 108 428 197 108 429 minecraft:iron_block
fill 196 108 431 196 108 436 minecraft:iron_block
fill 196 108 445 197 108 445 minecraft:iron_block
fill 196 108 447 200 108 447 minecraft:iron_block
fill 197 108 430 197 108 434 minecraft:iron_block
setblock 197 108 448 minecraft:iron_block
fill 198 108 429 198 108 432 minecraft:iron_block
setblock 199 108 429 minecraft:iron_block
fill 200 108 438 200 109 438 minecraft:waxed_copper_block
fill 200 108 448 204 108 448 minecraft:iron_block
fill 201 108 427 202 108 428 minecraft:iron_block
fill 201 108 449 202 108 450 minecraft:iron_block
setblock 202 108 426 minecraft:iron_block
fill 202 108 435 203 108 435 minecraft:waxed_copper_block
fill 202 108 441 203 108 441 minecraft:waxed_copper_block
fill 203 108 428 204 108 428 minecraft:iron_block
setblock 204 108 427 minecraft:iron_block
setblock 204 108 449 minecraft:iron_block
fill 205 108 435 206 108 435 minecraft:waxed_copper_block
fill 205 108 441 206 108 441 minecraft:waxed_copper_block
fill 206 108 426 207 108 427 minecraft:iron_block
fill 206 108 447 207 108 450 minecraft:iron_block
fill 207 108 436 207 108 437 minecraft:waxed_copper_block
fill 207 108 439 207 108 440 minecraft:waxed_copper_block
fill 208 108 447 208 108 448 minecraft:iron_block
fill 209 108 441 214 108 441 minecraft:iron_block
setblock 209 108 447 minecraft:iron_block
fill 211 108 428 212 108 428 minecraft:iron_block
fill 211 108 446 211 108 448 minecraft:iron_block
setblock 212 108 429 minecraft:iron_block
fill 212 108 444 212 108 445 minecraft:iron_block
fill 212 108 447 212 108 448 minecraft:iron_block
fill 213 108 432 215 108 432 minecraft:iron_block
fill 213 108 442 215 108 442 minecraft:iron_block
fill 213 108 444 215 108 444 minecraft:iron_block
fill 214 108 439 214 108 440 minecraft:iron_block
fill 215 108 438 217 108 438 minecraft:iron_block
setblock 216 108 437 minecraft:iron_block
setblock 216 108 439 minecraft:iron_block
fill 197 109 436 197 109 440 minecraft:waxed_oxidized_copper
fill 198 109 434 198 109 435 minecraft:waxed_oxidized_copper
fill 198 109 441 198 109 442 minecraft:waxed_oxidized_copper
setblock 199 109 433 minecraft:waxed_oxidized_copper
setblock 199 109 443 minecraft:waxed_oxidized_copper
fill 200 109 432 201 109 432 minecraft:waxed_oxidized_copper
fill 200 109 444 201 109 444 minecraft:waxed_oxidized_copper
setblock 201 109 436 minecraft:waxed_copper_block
setblock 201 109 440 minecraft:waxed_copper_block
fill 202 109 431 206 109 431 minecraft:waxed_oxidized_copper
setblock 202 109 435 minecraft:waxed_copper_block
setblock 202 109 441 minecraft:waxed_copper_block
fill 202 109 445 206 109 445 minecraft:waxed_oxidized_copper
setblock 206 109 435 minecraft:waxed_copper_block
setblock 206 109 441 minecraft:waxed_copper_block
fill 207 109 432 208 109 432 minecraft:waxed_oxidized_copper
setblock 207 109 436 minecraft:waxed_copper_block
setblock 207 109 440 minecraft:waxed_copper_block
fill 207 109 444 208 109 444 minecraft:waxed_oxidized_copper
setblock 209 109 433 minecraft:waxed_oxidized_copper
setblock 209 109 443 minecraft:waxed_oxidized_copper
fill 210 109 434 210 109 435 minecraft:waxed_oxidized_copper
fill 210 109 441 210 109 442 minecraft:waxed_oxidized_copper
fill 211 109 436 211 109 440 minecraft:waxed_oxidized_copper
setblock 191 110 419 minecraft:light[level=13]
setblock 191 110 427 minecraft:light[level=13]
setblock 191 110 435 minecraft:light[level=13]
setblock 191 110 443 minecraft:light[level=13]
setblock 191 110 451 minecraft:light[level=13]
setblock 199 110 419 minecraft:light[level=13]
setblock 199 110 427 minecraft:light[level=13]
setblock 199 110 435 minecraft:light[level=13]
setblock 199 110 443 minecraft:light[level=13]
setblock 199 110 451 minecraft:light[level=13]
setblock 207 110 419 minecraft:light[level=13]
setblock 207 110 427 minecraft:light[level=13]
setblock 207 110 435 minecraft:light[level=13]
setblock 207 110 443 minecraft:light[level=13]
setblock 207 110 451 minecraft:light[level=13]
setblock 215 110 419 minecraft:light[level=13]
setblock 215 110 427 minecraft:light[level=13]
setblock 215 110 435 minecraft:light[level=13]
setblock 215 110 443 minecraft:light[level=13]
setblock 215 110 451 minecraft:light[level=13]
setblock 223 110 419 minecraft:light[level=13]
setblock 223 110 427 minecraft:light[level=13]
setblock 223 110 435 minecraft:light[level=13]
setblock 223 110 443 minecraft:light[level=13]
setblock 223 110 451 minecraft:light[level=13]
fill 188 111 422 188 111 425 minecraft:shroomlight
fill 188 111 434 188 111 437 minecraft:shroomlight
fill 188 111 446 188 111 449 minecraft:shroomlight
fill 188 111 458 191 111 458 minecraft:shroomlight
fill 189 111 417 191 164 417 minecraft:polished_deepslate
fill 189 111 427 189 164 429 minecraft:polished_deepslate
fill 189 111 439 189 164 441 minecraft:polished_deepslate
fill 189 111 451 189 164 453 minecraft:polished_deepslate
fill 195 111 416 198 111 416 minecraft:shroomlight
fill 195 111 457 197 164 457 minecraft:polished_deepslate
fill 200 111 458 203 111 458 minecraft:shroomlight
fill 201 111 417 203 164 417 minecraft:polished_deepslate
fill 207 111 416 210 111 416 minecraft:shroomlight
fill 207 111 457 209 164 457 minecraft:polished_deepslate
fill 212 111 458 215 111 458 minecraft:shroomlight
fill 213 111 417 215 164 417 minecraft:polished_deepslate
fill 219 111 416 222 111 416 minecraft:shroomlight
fill 219 111 457 221 164 457 minecraft:polished_deepslate
fill 224 111 458 227 111 458 minecraft:shroomlight
fill 225 111 417 227 164 417 minecraft:polished_deepslate
fill 229 111 425 229 164 427 minecraft:polished_deepslate
fill 229 111 437 229 164 439 minecraft:polished_deepslate
fill 229 111 449 229 164 451 minecraft:polished_deepslate
fill 230 111 417 230 111 420 minecraft:shroomlight
fill 230 111 429 230 111 432 minecraft:shroomlight
fill 230 111 441 230 111 444 minecraft:shroomlight
fill 230 111 453 230 111 456 minecraft:shroomlight
fill 188 112 422 188 125 422 minecraft:deepslate
fill 188 112 423 188 112 424 minecraft:shroomlight
fill 188 112 425 188 125 425 minecraft:deepslate
fill 188 112 434 188 125 434 minecraft:deepslate
fill 188 112 435 188 112 436 minecraft:shroomlight
fill 188 112 437 188 125 437 minecraft:deepslate
fill 188 112 446 188 125 446 minecraft:deepslate
fill 188 112 447 188 112 448 minecraft:shroomlight
fill 188 112 449 188 125 449 minecraft:deepslate
fill 188 112 458 188 125 458 minecraft:deepslate
fill 189 112 458 190 112 458 minecraft:shroomlight
fill 191 112 458 191 125 458 minecraft:deepslate
fill 195 112 416 195 125 416 minecraft:deepslate
fill 196 112 416 197 112 416 minecraft:shroomlight
fill 198 112 416 198 125 416 minecraft:deepslate
fill 200 112 458 200 125 458 minecraft:deepslate
fill 201 112 458 202 112 458 minecraft:shroomlight
fill 203 112 458 203 125 458 minecraft:deepslate
fill 207 112 416 207 125 416 minecraft:deepslate
fill 208 112 416 209 112 416 minecraft:shroomlight
fill 210 112 416 210 125 416 minecraft:deepslate
fill 212 112 458 212 125 458 minecraft:deepslate
fill 213 112 458 214 112 458 minecraft:shroomlight
fill 215 112 458 215 125 458 minecraft:deepslate
fill 219 112 416 219 125 416 minecraft:deepslate
fill 220 112 416 221 112 416 minecraft:shroomlight
fill 222 112 416 222 125 416 minecraft:deepslate
fill 224 112 458 224 125 458 minecraft:deepslate
fill 225 112 458 226 112 458 minecraft:shroomlight
fill 227 112 458 227 125 458 minecraft:deepslate
fill 230 112 417 230 125 417 minecraft:deepslate
fill 230 112 418 230 112 419 minecraft:shroomlight
fill 230 112 420 230 125 420 minecraft:deepslate
fill 230 112 429 230 125 429 minecraft:deepslate
fill 230 112 430 230 112 431 minecraft:shroomlight
fill 230 112 432 230 125 432 minecraft:deepslate
fill 230 112 441 230 125 441 minecraft:deepslate
fill 230 112 442 230 112 443 minecraft:shroomlight
fill 230 112 444 230 125 444 minecraft:deepslate
fill 230 112 453 230 125 453 minecraft:deepslate
fill 230 112 454 230 112 455 minecraft:shroomlight
fill 230 112 456 230 125 456 minecraft:deepslate
fill 188 113 423 188 125 424 minecraft:deepslate
fill 188 113 435 188 125 436 minecraft:deepslate
fill 188 113 447 188 125 448 minecraft:deepslate
fill 189 113 438 191 114 438 minecraft:waxed_copper_block
fill 189 113 458 190 125 458 minecraft:deepslate
fill 190 113 435 192 114 437 minecraft:waxed_copper_block
fill 190 113 439 192 114 441 minecraft:waxed_copper_block
fill 191 113 434 199 114 434 minecraft:waxed_copper_block
fill 191 113 442 199 114 442 minecraft:waxed_copper_block
fill 192 113 433 198 114 433 minecraft:waxed_copper_block
fill 192 113 443 198 114 443 minecraft:waxed_copper_block
fill 193 113 435 194 114 435 minecraft:waxed_copper_block
fill 193 113 441 194 114 441 minecraft:waxed_copper_block
fill 195 113 432 195 114 432 minecraft:waxed_copper_block
fill 195 113 444 195 114 444 minecraft:waxed_copper_block
fill 196 113 416 197 125 416 minecraft:deepslate
fill 196 113 435 200 114 435 minecraft:waxed_copper_block
fill 196 113 441 200 114 441 minecraft:waxed_copper_block
fill 198 113 436 199 114 437 minecraft:waxed_copper_block
fill 198 113 439 199 114 440 minecraft:waxed_copper_block
fill 199 113 438 199 114 438 minecraft:waxed_copper_block
fill 201 113 458 202 125 458 minecraft:deepslate
fill 208 113 416 209 125 416 minecraft:deepslate
fill 213 113 458 214 125 458 minecraft:deepslate
fill 220 113 416 221 125 416 minecraft:deepslate
fill 225 113 458 226 125 458 minecraft:deepslate
fill 230 113 418 230 125 419 minecraft:deepslate
fill 230 113 430 230 125 431 minecraft:deepslate
fill 230 113 442 230 125 443 minecraft:deepslate
fill 230 113 454 230 125 455 minecraft:deepslate
setblock 191 118 419 minecraft:light[level=13]
setblock 191 118 427 minecraft:light[level=13]
setblock 191 118 435 minecraft:light[level=13]
setblock 191 118 443 minecraft:light[level=13]
setblock 191 118 451 minecraft:light[level=13]
setblock 199 118 419 minecraft:light[level=13]
setblock 199 118 427 minecraft:light[level=13]
setblock 199 118 435 minecraft:light[level=13]
setblock 199 118 443 minecraft:light[level=13]
setblock 199 118 451 minecraft:light[level=13]
setblock 207 118 419 minecraft:light[level=13]
setblock 207 118 427 minecraft:light[level=13]
setblock 207 118 435 minecraft:light[level=13]
setblock 207 118 443 minecraft:light[level=13]
setblock 207 118 451 minecraft:light[level=13]
setblock 215 118 419 minecraft:light[level=13]
setblock 215 118 427 minecraft:light[level=13]
setblock 215 118 435 minecraft:light[level=13]
setblock 215 118 443 minecraft:light[level=13]
setblock 215 118 451 minecraft:light[level=13]
setblock 223 118 419 minecraft:light[level=13]
setblock 223 118 427 minecraft:light[level=13]
setblock 223 118 435 minecraft:light[level=13]
setblock 223 118 443 minecraft:light[level=13]
setblock 223 118 451 minecraft:light[level=13]
fill 190 120 426 190 125 428 minecraft:polished_deepslate
fill 190 120 438 190 125 440 minecraft:polished_deepslate
fill 190 120 450 190 125 452 minecraft:polished_deepslate
fill 196 120 456 198 125 456 minecraft:polished_deepslate
fill 200 120 418 202 125 418 minecraft:polished_deepslate
fill 208 120 456 210 125 456 minecraft:polished_deepslate
fill 212 120 418 214 125 418 minecraft:polished_deepslate
fill 220 120 456 222 125 456 minecraft:polished_deepslate
fill 224 120 418 226 125 418 minecraft:polished_deepslate
fill 228 120 426 228 125 428 minecraft:polished_deepslate
fill 228 120 438 228 125 440 minecraft:polished_deepslate
fill 228 120 450 228 125 452 minecraft:polished_deepslate
fill 189 125 420 189 125 425 minecraft:deepslate
fill 189 125 432 189 125 437 minecraft:deepslate
fill 189 125 444 189 125 449 minecraft:deepslate
fill 189 125 456 189 125 457 minecraft:deepslate
fill 190 125 457 193 125 457 minecraft:deepslate
fill 192 125 451 192 132 451 minecraft:iron_block
fill 193 125 417 198 125 417 minecraft:deepslate
fill 200 125 457 205 125 457 minecraft:deepslate
fill 205 125 417 210 125 417 minecraft:deepslate
fill 209 125 441 211 164 442 minecraft:polished_deepslate
fill 210 125 440 210 164 440 minecraft:polished_deepslate
fill 210 125 443 211 164 443 minecraft:polished_deepslate
fill 212 125 457 217 125 457 minecraft:deepslate
fill 217 125 417 222 125 417 minecraft:deepslate
fill 224 125 457 229 125 457 minecraft:deepslate
fill 229 125 417 229 125 422 minecraft:deepslate
fill 229 125 429 229 125 434 minecraft:deepslate
fill 229 125 441 229 125 446 minecraft:deepslate
fill 229 125 453 229 125 456 minecraft:deepslate
fill 188 126 422 188 131 425 minecraft:shroomlight
fill 188 126 434 188 131 437 minecraft:shroomlight
fill 188 126 446 188 131 449 minecraft:shroomlight
fill 188 126 458 191 131 458 minecraft:shroomlight
setblock 191 126 419 minecraft:light[level=13]
setblock 191 126 427 minecraft:light[level=13]
setblock 191 126 435 minecraft:light[level=13]
setblock 191 126 443 minecraft:light[level=13]
setblock 191 126 451 minecraft:light[level=13]
fill 195 126 416 198 131 416 minecraft:shroomlight
setblock 199 126 419 minecraft:light[level=13]
setblock 199 126 427 minecraft:light[level=13]
setblock 199 126 435 minecraft:light[level=13]
setblock 199 126 443 minecraft:light[level=13]
setblock 199 126 451 minecraft:light[level=13]
fill 200 126 458 203 131 458 minecraft:shroomlight
fill 207 126 416 210 131 416 minecraft:shroomlight
setblock 207 126 419 minecraft:light[level=13]
setblock 207 126 427 minecraft:light[level=13]
setblock 207 126 435 minecraft:light[level=13]
setblock 207 126 443 minecraft:light[level=13]
setblock 207 126 451 minecraft:light[level=13]
fill 208 126 441 208 127 442 minecraft:deepslate
fill 209 126 440 209 127 440 minecraft:deepslate
fill 209 126 443 209 127 443 minecraft:deepslate
fill 210 126 444 211 127 444 minecraft:deepslate
fill 211 126 440 211 127 440 minecraft:deepslate
fill 212 126 441 212 127 443 minecraft:deepslate
fill 212 126 458 215 131 458 minecraft:shroomlight
setblock 215 126 419 minecraft:light[level=13]
setblock 215 126 427 minecraft:light[level=13]
setblock 215 126 435 minecraft:light[level=13]
setblock 215 126 443 minecraft:light[level=13]
setblock 215 126 451 minecraft:light[level=13]
fill 219 126 416 222 131 416 minecraft:shroomlight
setblock 223 126 419 minecraft:light[level=13]
setblock 223 126 427 minecraft:light[level=13]
setblock 223 126 435 minecraft:light[level=13]
setblock 223 126 443 minecraft:light[level=13]
setblock 223 126 451 minecraft:light[level=13]
fill 224 126 458 227 131 458 minecraft:shroomlight
fill 230 126 417 230 131 420 minecraft:shroomlight
fill 230 126 429 230 131 432 minecraft:shroomlight
fill 230 126 441 230 131 444 minecraft:shroomlight
fill 230 126 453 230 131 456 minecraft:shroomlight
setblock 208 127 440 minecraft:deepslate
setblock 208 127 443 minecraft:deepslate
fill 209 127 439 211 127 439 minecraft:deepslate
setblock 209 127 444 minecraft:deepslate
setblock 212 127 440 minecraft:deepslate
setblock 212 127 444 minecraft:deepslate
fill 213 127 441 213 127 443 minecraft:deepslate
fill 188 128 428 188 131 428 minecraft:deepslate
setblock 188 128 429 minecraft:polished_andesite
fill 188 128 433 188 129 433 minecraft:polished_andesite
setblock 189 128 416 minecraft:deepslate
setblock 190 128 416 minecraft:polished_andesite
setblock 192 128 458 minecraft:polished_andesite
fill 193 128 458 195 129 458 minecraft:deepslate
fill 206 128 458 208 128 458 minecraft:polished_andesite
fill 209 128 458 210 128 458 minecraft:deepslate
setblock 211 128 458 minecraft:polished_andesite
setblock 216 128 458 minecraft:polished_andesite
fill 217 128 458 223 128 458 minecraft:deepslate
fill 223 128 416 227 129 416 minecraft:deepslate
setblock 228 128 416 minecraft:polished_andesite
fill 229 128 416 229 131 416 minecraft:deepslate
fill 230 128 423 230 131 424 minecraft:deepslate
fill 230 128 425 230 129 425 minecraft:polished_andesite
fill 230 128 426 230 131 426 minecraft:deepslate
fill 230 128 435 230 128 436 minecraft:polished_andesite
setblock 230 128 452 minecraft:polished_andesite
setblock 188 129 420 minecraft:polished_andesite
fill 188 129 429 188 131 429 minecraft:deepslate
fill 188 129 439 188 131 439 minecraft:deepslate
setblock 188 129 440 minecraft:polished_andesite
fill 188 129 441 188 131 443 minecraft:deepslate
fill 188 129 444 188 129 445 minecraft:polished_andesite
setblock 189 129 416 minecraft:polished_andesite
fill 190 129 416 190 131 416 minecraft:deepslate
setblock 192 129 416 minecraft:polished_andesite
fill 192 129 458 192 131 458 minecraft:deepslate
fill 193 129 416 194 131 416 minecraft:deepslate
fill 200 129 416 201 129 416 minecraft:deepslate
setblock 202 129 416 minecraft:polished_andesite
fill 203 129 416 203 131 416 minecraft:deepslate
fill 204 129 416 204 130 416 minecraft:polished_andesite
fill 205 129 416 206 131 416 minecraft:deepslate
fill 206 129 458 208 131 458 minecraft:deepslate
setblock 209 129 458 minecraft:polished_andesite
fill 210 129 458 211 131 458 minecraft:deepslate
setblock 216 129 458 minecraft:deepslate
setblock 217 129 458 minecraft:polished_andesite
fill 218 129 458 223 129 458 minecraft:deepslate
fill 228 129 416 228 131 416 minecraft:deepslate
fill 230 129 416 230 130 416 minecraft:polished_andesite
fill 230 129 433 230 131 433 minecraft:deepslate
fill 230 129 434 230 129 435 minecraft:polished_andesite
fill 230 129 436 230 131 436 minecraft:deepslate
fill 230 129 445 230 129 447 minecraft:deepslate
setblock 230 129 448 minecraft:polished_andesite
fill 230 129 449 230 131 449 minecraft:deepslate
fill 230 129 450 230 130 450 minecraft:polished_andesite
fill 230 129 451 230 131 452 minecraft:deepslate
setblock 230 129 458 minecraft:polished_andesite
fill 188 130 420 188 131 420 minecraft:deepslate
setblock 188 130 430 minecraft:polished_andesite
fill 188 130 431 188 131 431 minecraft:deepslate
setblock 188 130 432 minecraft:polished_andesite
fill 188 130 433 188 131 433 minecraft:deepslate
fill 188 130 440 188 131 440 minecraft:deepslate
setblock 188 130 444 minecraft:polished_andesite
fill 188 130 445 188 131 445 minecraft:deepslate
setblock 188 130 455 minecraft:polished_andesite
fill 189 130 416 189 131 416 minecraft:deepslate
fill 192 130 416 192 132 416 minecraft:deepslate
fill 193 130 458 194 131 458 minecraft:deepslate
setblock 195 130 458 minecraft:polished_andesite
fill 197 130 458 198 131 458 minecraft:deepslate
setblock 199 130 458 minecraft:polished_andesite
setblock 200 130 416 minecraft:polished_andesite
fill 201 130 416 202 131 416 minecraft:deepslate
fill 209 130 458 209 132 458 minecraft:deepslate
setblock 211 130 416 minecraft:polished_andesite
fill 212 130 416 213 131 416 minecraft:deepslate
fill 216 130 416 218 130 416 minecraft:polished_andesite
setblock 216 130 458 minecraft:polished_andesite
fill 217 130 458 221 131 458 minecraft:deepslate
setblock 222 130 458 minecraft:polished_andesite
fill 223 130 416 226 131 416 minecraft:deepslate
fill 223 130 458 223 131 458 minecraft:deepslate
setblock 227 130 416 minecraft:polished_andesite
fill 230 130 425 230 131 425 minecraft:deepslate
fill 230 130 434 230 131 435 minecraft:deepslate
fill 230 130 445 230 131 446 minecraft:deepslate
setblock 230 130 447 minecraft:polished_andesite
fill 230 130 448 230 131 448 minecraft:deepslate
fill 230 130 458 230 131 458 minecraft:deepslate
fill 188 131 430 188 134 430 minecraft:deepslate
setblock 188 131 432 minecraft:deepslate
fill 188 131 444 188 132 444 minecraft:deepslate
setblock 188 131 455 minecraft:deepslate
setblock 195 131 458 minecraft:deepslate
fill 199 131 458 199 132 458 minecraft:deepslate
setblock 200 131 416 minecraft:deepslate
setblock 204 131 416 minecraft:deepslate
setblock 211 131 416 minecraft:deepslate
fill 216 131 416 218 131 416 minecraft:deepslate
setblock 216 131 458 minecraft:deepslate
setblock 222 131 458 minecraft:deepslate
setblock 227 131 416 minecraft:deepslate
fill 230 131 416 230 133 416 minecraft:deepslate
setblock 230 131 447 minecraft:deepslate
setblock 230 131 450 minecraft:deepslate
fill 188 132 416 191 133 416 minecraft:polished_andesite
setblock 188 132 417 minecraft:deepslate
fill 188 132 418 188 219 418 minecraft:polished_andesite
fill 188 132 420 188 133 422 minecraft:polished_andesite
fill 188 132 423 188 132 424 minecraft:shroomlight
fill 188 132 425 188 145 429 minecraft:polished_andesite
fill 188 132 431 188 145 434 minecraft:polished_andesite
fill 188 132 435 188 132 436 minecraft:shroomlight
fill 188 132 437 188 132 440 minecraft:polished_andesite
setblock 188 132 441 minecraft:deepslate
fill 188 132 442 188 215 443 minecraft:polished_andesite
fill 188 132 445 188 145 446 minecraft:polished_andesite
fill 188 132 447 188 132 448 minecraft:shroomlight
fill 188 132 449 188 132 458 minecraft:polished_andesite
fill 189 132 458 190 132 458 minecraft:shroomlight
fill 191 132 458 198 133 458 minecraft:polished_andesite
fill 193 132 416 195 132 416 minecraft:polished_andesite
fill 196 132 416 197 132 416 minecraft:shroomlight
fill 198 132 416 200 145 416 minecraft:polished_andesite
fill 200 132 458 200 145 458 minecraft:polished_andesite
setblock 201 132 416 minecraft:deepslate
fill 201 132 458 202 132 458 minecraft:shroomlight
fill 202 132 416 207 133 416 minecraft:polished_andesite
fill 203 132 458 208 145 458 minecraft:polished_andesite
fill 208 132 416 209 132 416 minecraft:shroomlight
fill 210 132 416 215 132 416 minecraft:polished_andesite
setblock 210 132 458 minecraft:deepslate
fill 211 132 458 212 145 458 minecraft:polished_andesite
fill 213 132 458 214 132 458 minecraft:shroomlight
fill 215 132 458 220 132 458 minecraft:polished_andesite
setblock 216 132 416 minecraft:deepslate
fill 217 132 416 219 145 416 minecraft:polished_andesite
fill 220 132 416 221 132 416 minecraft:shroomlight
setblock 221 132 458 minecraft:deepslate
fill 222 132 416 224 145 416 minecraft:polished_andesite
fill 222 132 458 224 145 458 minecraft:polished_andesite
fill 225 132 416 226 132 416 minecraft:deepslate
fill 225 132 458 226 132 458 minecraft:shroomlight
fill 227 132 416 229 219 416 minecraft:polished_andesite
fill 227 132 437 227 140 437 minecraft:red_wool
fill 227 132 458 230 133 458 minecraft:polished_andesite
setblock 230 132 417 minecraft:deepslate
fill 230 132 418 230 132 419 minecraft:shroomlight
setblock 230 132 420 minecraft:deepslate
fill 230 132 422 230 145 429 minecraft:polished_andesite
fill 230 132 430 230 132 431 minecraft:shroomlight
fill 230 132 432 230 132 434 minecraft:polished_andesite
setblock 230 132 435 minecraft:deepslate
fill 230 132 436 230 145 441 minecraft:polished_andesite
fill 230 132 442 230 132 443 minecraft:shroomlight
fill 230 132 444 230 132 453 minecraft:polished_andesite
fill 230 132 454 230 132 455 minecraft:shroomlight
fill 230 132 456 230 145 457 minecraft:polished_andesite
fill 188 133 417 188 219 417 minecraft:polished_andesite
fill 188 133 419 188 217 419 minecraft:polished_andesite
fill 188 133 423 188 145 424 minecraft:polished_andesite
fill 188 133 435 188 133 437 minecraft:polished_andesite
setblock 188 133 438 minecraft:deepslate
fill 188 133 439 188 216 441 minecraft:polished_andesite
fill 188 133 444 188 219 444 minecraft:polished_andesite
fill 188 133 447 188 145 449 minecraft:polished_andesite
setblock 188 133 450 minecraft:deepslate
fill 188 133 451 188 217 453 minecraft:polished_andesite
fill 188 133 454 188 134 454 minecraft:deepslate
fill 188 133 455 188 133 456 minecraft:polished_andesite
setblock 188 133 457 minecraft:deepslate
fill 188 133 458 190 145 458 minecraft:polished_andesite
fill 192 133 416 193 216 416 minecraft:polished_andesite
setblock 194 133 416 minecraft:deepslate
fill 195 133 416 197 133 416 minecraft:polished_andesite
fill 199 133 458 199 216 458 minecraft:polished_andesite
fill 201 133 416 201 219 416 minecraft:polished_andesite
fill 201 133 458 202 145 458 minecraft:polished_andesite
fill 208 133 416 208 145 416 minecraft:polished_andesite
setblock 209 133 416 minecraft:deepslate
fill 209 133 458 210 217 458 minecraft:polished_andesite
fill 210 133 416 213 145 416 minecraft:polished_andesite
fill 213 133 458 219 133 458 minecraft:polished_andesite
setblock 214 133 416 minecraft:deepslate
fill 215 133 416 216 219 416 minecraft:polished_andesite
fill 220 133 416 221 145 416 minecraft:polished_andesite
fill 220 133 458 220 134 458 minecraft:deepslate
fill 221 133 458 221 219 458 minecraft:polished_andesite
fill 225 133 416 226 217 416 minecraft:polished_andesite
fill 225 133 458 226 145 458 minecraft:polished_andesite
fill 227 133 435 227 140 436 minecraft:red_wool
fill 227 133 438 227 140 439 minecraft:red_wool
fill 230 133 417 230 145 421 minecraft:polished_andesite
fill 230 133 430 230 145 431 minecraft:polished_andesite
setblock 230 133 432 minecraft:deepslate
fill 230 133 433 230 215 435 minecraft:polished_andesite
setblock 230 133 442 minecraft:deepslate
fill 230 133 443 230 133 448 minecraft:polished_andesite
setblock 230 133 449 minecraft:deepslate
fill 230 133 450 230 133 455 minecraft:polished_andesite
fill 188 134 416 188 220 416 minecraft:polished_andesite
fill 188 134 420 188 216 421 minecraft:polished_andesite
setblock 188 134 422 minecraft:deepslate
fill 188 134 435 188 145 436 minecraft:polished_andesite
setblock 188 134 437 minecraft:deepslate
fill 188 134 438 188 219 438 minecraft:polished_andesite
fill 188 134 450 188 219 450 minecraft:polished_andesite
fill 188 134 455 188 219 455 minecraft:polished_andesite
setblock 188 134 456 minecraft:deepslate
fill 188 134 457 188 219 457 minecraft:polished_andesite
setblock 189 134 416 minecraft:deepslate
fill 190 134 416 190 219 416 minecraft:polished_andesite
setblock 191 134 416 minecraft:deepslate
setblock 191 134 419 minecraft:light[level=13]
setblock 191 134 427 minecraft:light[level=13]
setblock 191 134 435 minecraft:light[level=13]
setblock 191 134 443 minecraft:light[level=13]
setblock 191 134 451 minecraft:light[level=13]
fill 191 134 458 197 145 458 minecraft:polished_andesite
fill 194 134 416 195 145 416 minecraft:polished_andesite
setblock 196 134 416 minecraft:deepslate
fill 197 134 416 197 145 416 minecraft:polished_andesite
setblock 198 134 458 minecraft:deepslate
setblock 199 134 419 minecraft:light[level=13]
setblock 199 134 427 minecraft:light[level=13]
setblock 199 134 435 minecraft:light[level=13]
setblock 199 134 443 minecraft:light[level=13]
setblock 199 134 451 minecraft:light[level=13]
setblock 202 134 416 minecraft:deepslate
fill 203 134 416 207 145 416 minecraft:polished_andesite
setblock 207 134 419 minecraft:light[level=13]
setblock 207 134 427 minecraft:light[level=13]
setblock 207 134 435 minecraft:light[level=13]
setblock 207 134 443 minecraft:light[level=13]
setblock 207 134 451 minecraft:light[level=13]
fill 209 134 416 209 145 416 minecraft:polished_andesite
fill 213 134 458 214 145 458 minecraft:polished_andesite
fill 214 134 416 214 220 416 minecraft:polished_andesite
setblock 215 134 419 minecraft:light[level=13]
setblock 215 134 427 minecraft:light[level=13]
setblock 215 134 435 minecraft:light[level=13]
setblock 215 134 443 minecraft:light[level=13]
setblock 215 134 451 minecraft:light[level=13]
setblock 215 134 458 minecraft:deepslate
fill 216 134 458 219 219 458 minecraft:polished_andesite
setblock 223 134 419 minecraft:light[level=13]
setblock 223 134 427 minecraft:light[level=13]
setblock 223 134 435 minecraft:light[level=13]
setblock 223 134 443 minecraft:light[level=13]
setblock 223 134 451 minecraft:light[level=13]
fill 227 134 458 227 145 458 minecraft:polished_andesite
setblock 228 134 458 minecraft:deepslate
fill 229 134 458 229 220 458 minecraft:polished_andesite
fill 230 134 416 230 215 416 minecraft:polished_andesite
fill 230 134 432 230 145 432 minecraft:polished_andesite
fill 230 134 442 230 145 445 minecraft:polished_andesite
setblock 230 134 446 minecraft:deepslate
fill 230 134 447 230 215 447 minecraft:polished_andesite
setblock 230 134 448 minecraft:deepslate
fill 230 134 449 230 215 451 minecraft:polished_andesite
setblock 230 134 452 minecraft:deepslate
fill 230 134 453 230 145 455 minecraft:polished_andesite
setblock 230 134 458 minecraft:deepslate
fill 188 135 422 188 145 422 minecraft:polished_andesite
fill 188 135 430 188 219 430 minecraft:polished_andesite
fill 188 135 437 188 145 437 minecraft:polished_andesite
fill 188 135 454 188 219 454 minecraft:polished_andesite
fill 188 135 456 188 219 456 minecraft:polished_andesite
fill 189 135 416 189 219 416 minecraft:polished_andesite
fill 191 135 416 191 220 416 minecraft:polished_andesite
fill 196 135 416 196 145 416 minecraft:polished_andesite
fill 198 135 458 198 220 458 minecraft:polished_andesite
fill 202 135 416 202 219 416 minecraft:polished_andesite
fill 215 135 458 215 145 458 minecraft:polished_andesite
fill 220 135 458 220 219 458 minecraft:polished_andesite
fill 228 135 458 228 219 458 minecraft:polished_andesite
fill 230 135 446 230 215 446 minecraft:polished_andesite
fill 230 135 448 230 219 448 minecraft:polished_andesite
fill 230 135 452 230 217 452 minecraft:polished_andesite
fill 230 135 458 230 219 458 minecraft:polished_andesite
fill 190 140 426 190 145 428 minecraft:polished_deepslate
fill 190 140 438 190 145 440 minecraft:polished_deepslate
fill 190 140 450 190 145 452 minecraft:polished_deepslate
fill 196 140 456 198 145 456 minecraft:polished_deepslate
fill 200 140 418 202 145 418 minecraft:polished_deepslate
fill 208 140 456 210 145 456 minecraft:polished_deepslate
fill 212 140 418 214 145 418 minecraft:polished_deepslate
fill 220 140 456 222 145 456 minecraft:polished_deepslate
fill 224 140 418 226 145 418 minecraft:polished_deepslate
fill 228 140 426 228 145 428 minecraft:polished_deepslate
fill 228 140 438 228 145 440 minecraft:polished_deepslate
fill 228 140 450 228 145 452 minecraft:polished_deepslate
fill 217 141 456 219 144 456 minecraft:orange_stained_glass
fill 218 141 454 218 143 455 minecraft:orange_stained_glass
fill 218 141 457 218 144 457 minecraft:orange_stained_glass
fill 227 141 434 227 142 440 minecraft:iron_block
setblock 191 142 419 minecraft:light[level=13]
setblock 191 142 427 minecraft:light[level=13]
setblock 191 142 435 minecraft:light[level=13]
setblock 191 142 443 minecraft:light[level=13]
setblock 191 142 451 minecraft:light[level=13]
setblock 199 142 419 minecraft:light[level=13]
setblock 199 142 427 minecraft:light[level=13]
setblock 199 142 435 minecraft:light[level=13]
setblock 199 142 443 minecraft:light[level=13]
setblock 199 142 451 minecraft:light[level=13]
setblock 207 142 419 minecraft:light[level=13]
setblock 207 142 427 minecraft:light[level=13]
setblock 207 142 435 minecraft:light[level=13]
setblock 207 142 443 minecraft:light[level=13]
setblock 207 142 451 minecraft:light[level=13]
setblock 215 142 419 minecraft:light[level=13]
setblock 215 142 427 minecraft:light[level=13]
setblock 215 142 435 minecraft:light[level=13]
setblock 215 142 443 minecraft:light[level=13]
setblock 215 142 451 minecraft:light[level=13]
fill 217 142 453 217 142 455 minecraft:orange_stained_glass
fill 217 142 457 217 143 457 minecraft:orange_stained_glass
fill 218 142 451 218 142 453 minecraft:orange_stained_glass
fill 219 142 453 219 142 455 minecraft:orange_stained_glass
setblock 223 142 419 minecraft:light[level=13]
setblock 223 142 427 minecraft:light[level=13]
setblock 223 142 435 minecraft:light[level=13]
setblock 223 142 443 minecraft:light[level=13]
setblock 223 142 451 minecraft:light[level=13]
fill 193 143 417 193 144 419 minecraft:iron_block
fill 217 143 454 217 143 455 minecraft:orange_stained_glass
setblock 218 143 453 minecraft:orange_stained_glass
fill 219 143 454 219 143 455 minecraft:orange_stained_glass
setblock 218 144 455 minecraft:orange_stained_glass
fill 189 145 420 189 145 425 minecraft:deepslate
fill 189 145 432 189 145 437 minecraft:deepslate
fill 189 145 444 189 145 449 minecraft:deepslate
fill 189 145 456 189 145 457 minecraft:deepslate
fill 190 145 457 193 145 457 minecraft:deepslate
fill 193 145 417 198 145 417 minecraft:deepslate
fill 200 145 457 205 145 457 minecraft:deepslate
fill 205 145 417 210 145 417 minecraft:deepslate
fill 212 145 457 217 145 457 minecraft:deepslate
fill 217 145 417 222 145 417 minecraft:deepslate
fill 224 145 457 229 145 457 minecraft:deepslate
fill 229 145 417 229 145 422 minecraft:deepslate
fill 229 145 429 229 145 434 minecraft:deepslate
fill 229 145 441 229 145 446 minecraft:deepslate
fill 229 145 453 229 145 456 minecraft:deepslate
fill 188 146 422 188 151 425 minecraft:shroomlight
fill 188 146 426 188 215 429 minecraft:polished_andesite
fill 188 146 431 188 216 433 minecraft:polished_andesite
fill 188 146 434 188 151 437 minecraft:shroomlight
fill 188 146 445 188 219 445 minecraft:polished_andesite
fill 188 146 446 188 151 449 minecraft:shroomlight
fill 188 146 458 191 151 458 minecraft:shroomlight
fill 189 146 432 191 147 432 minecraft:iron_block
fill 192 146 458 197 217 458 minecraft:polished_andesite
fill 194 146 416 194 220 416 minecraft:polished_andesite
fill 195 146 416 198 151 416 minecraft:shroomlight
fill 199 146 416 200 216 416 minecraft:polished_andesite
fill 200 146 458 203 151 458 minecraft:shroomlight
fill 203 146 416 206 217 416 minecraft:polished_andesite
fill 204 146 458 208 217 458 minecraft:polished_andesite
fill 207 146 416 210 151 416 minecraft:shroomlight
fill 211 146 416 213 217 416 minecraft:polished_andesite
fill 211 146 458 211 219 458 minecraft:polished_andesite
fill 212 146 458 215 151 458 minecraft:shroomlight
fill 217 146 416 218 219 416 minecraft:polished_andesite
fill 219 146 416 222 151 416 minecraft:shroomlight
fill 222 146 458 223 219 458 minecraft:polished_andesite
fill 223 146 416 224 215 416 minecraft:polished_andesite
fill 224 146 458 227 151 458 minecraft:shroomlight
fill 230 146 417 230 151 420 minecraft:shroomlight
fill 230 146 421 230 215 428 minecraft:polished_andesite
fill 230 146 429 230 151 432 minecraft:shroomlight
fill 230 146 436 230 215 440 minecraft:polished_andesite
fill 230 146 441 230 151 444 minecraft:shroomlight
fill 230 146 445 230 215 445 minecraft:polished_andesite
fill 230 146 453 230 151 456 minecraft:shroomlight
fill 230 146 457 230 215 457 minecraft:polished_andesite
fill 194 147 454 194 148 456 minecraft:iron_block
setblock 191 150 419 minecraft:light[level=13]
setblock 191 150 427 minecraft:light[level=13]
setblock 191 150 435 minecraft:light[level=13]
setblock 191 150 443 minecraft:light[level=13]
setblock 191 150 451 minecraft:light[level=13]
setblock 199 150 419 minecraft:light[level=13]
setblock 199 150 427 minecraft:light[level=13]
setblock 199 150 435 minecraft:light[level=13]
setblock 199 150 443 minecraft:light[level=13]
setblock 199 150 451 minecraft:light[level=13]
setblock 207 150 419 minecraft:light[level=13]
setblock 207 150 427 minecraft:light[level=13]
setblock 207 150 435 minecraft:light[level=13]
setblock 207 150 443 minecraft:light[level=13]
setblock 207 150 451 minecraft:light[level=13]
setblock 215 150 419 minecraft:light[level=13]
setblock 215 150 427 minecraft:light[level=13]
setblock 215 150 435 minecraft:light[level=13]
setblock 215 150 443 minecraft:light[level=13]
setblock 215 150 451 minecraft:light[level=13]
setblock 223 150 419 minecraft:light[level=13]
setblock 223 150 427 minecraft:light[level=13]
setblock 223 150 435 minecraft:light[level=13]
setblock 223 150 443 minecraft:light[level=13]
setblock 223 150 451 minecraft:light[level=13]
fill 188 152 422 188 185 422 minecraft:polished_andesite
fill 188 152 423 188 152 424 minecraft:shroomlight
fill 188 152 425 188 185 425 minecraft:polished_andesite
fill 188 152 434 188 185 434 minecraft:polished_andesite
fill 188 152 435 188 152 436 minecraft:shroomlight
fill 188 152 437 188 185 437 minecraft:polished_andesite
fill 188 152 446 188 185 446 minecraft:polished_andesite
fill 188 152 447 188 152 448 minecraft:shroomlight
fill 188 152 449 188 185 449 minecraft:polished_andesite
fill 188 152 458 188 185 458 minecraft:polished_andesite
fill 189 152 458 190 152 458 minecraft:shroomlight
fill 191 152 458 191 185 458 minecraft:polished_andesite
fill 195 152 416 195 185 416 minecraft:polished_andesite
fill 196 152 416 197 152 416 minecraft:shroomlight
fill 198 152 416 198 185 416 minecraft:polished_andesite
fill 200 152 458 200 185 458 minecraft:polished_andesite
fill 201 152 458 202 152 458 minecraft:shroomlight
fill 203 152 458 203 185 458 minecraft:polished_andesite
fill 207 152 416 207 185 416 minecraft:polished_andesite
fill 208 152 416 209 152 416 minecraft:shroomlight
fill 210 152 416 210 185 416 minecraft:polished_andesite
fill 212 152 458 212 185 458 minecraft:polished_andesite
fill 213 152 458 214 152 458 minecraft:shroomlight
fill 215 152 458 215 185 458 minecraft:polished_andesite
fill 219 152 416 219 185 416 minecraft:polished_andesite
fill 220 152 416 221 152 416 minecraft:shroomlight
fill 222 152 416 222 185 416 minecraft:polished_andesite
fill 224 152 458 224 185 458 minecraft:polished_andesite
fill 225 152 458 226 152 458 minecraft:shroomlight
fill 227 152 458 227 185 458 minecraft:polished_andesite
fill 230 152 417 230 185 417 minecraft:polished_andesite
fill 230 152 418 230 152 419 minecraft:shroomlight
fill 230 152 420 230 185 420 minecraft:polished_andesite
fill 230 152 429 230 185 429 minecraft:polished_andesite
fill 230 152 430 230 152 431 minecraft:shroomlight
fill 230 152 432 230 185 432 minecraft:polished_andesite
fill 230 152 441 230 185 441 minecraft:polished_andesite
fill 230 152 442 230 152 443 minecraft:shroomlight
fill 230 152 444 230 185 444 minecraft:polished_andesite
fill 230 152 453 230 185 453 minecraft:polished_andesite
fill 230 152 454 230 152 455 minecraft:shroomlight
fill 230 152 456 230 185 456 minecraft:polished_andesite
fill 188 153 423 188 185 424 minecraft:polished_andesite
fill 188 153 435 188 185 436 minecraft:polished_andesite
fill 188 153 447 188 185 448 minecraft:polished_andesite
fill 189 153 458 190 185 458 minecraft:polished_andesite
fill 196 153 416 197 185 416 minecraft:polished_andesite
fill 201 153 458 202 185 458 minecraft:polished_andesite
fill 208 153 416 209 185 416 minecraft:polished_andesite
fill 213 153 458 214 185 458 minecraft:polished_andesite
fill 220 153 416 221 185 416 minecraft:polished_andesite
fill 225 153 458 226 185 458 minecraft:polished_andesite
fill 230 153 418 230 185 419 minecraft:polished_andesite
fill 230 153 430 230 185 431 minecraft:polished_andesite
fill 230 153 442 230 185 443 minecraft:polished_andesite
fill 230 153 454 230 185 455 minecraft:polished_andesite
fill 192 156 454 192 157 456 minecraft:iron_block
setblock 191 158 419 minecraft:light[level=13]
setblock 191 158 427 minecraft:light[level=13]
setblock 191 158 435 minecraft:light[level=13]
fill 191 158 440 191 160 440 minecraft:iron_block
setblock 191 158 443 minecraft:light[level=13]
setblock 191 158 451 minecraft:light[level=13]
setblock 199 158 419 minecraft:light[level=13]
setblock 199 158 427 minecraft:light[level=13]
setblock 199 158 435 minecraft:light[level=13]
setblock 199 158 443 minecraft:light[level=13]
setblock 199 158 451 minecraft:light[level=13]
setblock 207 158 419 minecraft:light[level=13]
setblock 207 158 427 minecraft:light[level=13]
setblock 207 158 435 minecraft:light[level=13]
setblock 207 158 443 minecraft:light[level=13]
setblock 207 158 451 minecraft:light[level=13]
setblock 215 158 419 minecraft:light[level=13]
setblock 215 158 427 minecraft:light[level=13]
setblock 215 158 435 minecraft:light[level=13]
setblock 215 158 443 minecraft:light[level=13]
setblock 215 158 451 minecraft:light[level=13]
setblock 223 158 419 minecraft:light[level=13]
setblock 223 158 427 minecraft:light[level=13]
setblock 223 158 435 minecraft:light[level=13]
setblock 223 158 443 minecraft:light[level=13]
setblock 223 158 451 minecraft:light[level=13]
fill 227 158 440 227 160 440 minecraft:iron_block
fill 189 159 438 193 159 438 minecraft:iron_block
fill 189 159 442 193 161 442 minecraft:iron_block
fill 190 159 439 190 159 441 minecraft:iron_block
fill 191 159 437 191 162 437 minecraft:iron_block
fill 191 159 439 193 160 439 minecraft:iron_block
fill 191 159 441 193 160 441 minecraft:iron_block
fill 191 159 443 191 162 443 minecraft:iron_block
fill 192 159 440 194 160 440 minecraft:iron_block
fill 224 159 440 226 160 440 minecraft:iron_block
fill 225 159 438 228 159 439 minecraft:iron_block
fill 225 159 441 229 160 442 minecraft:iron_block
fill 227 159 437 227 162 437 minecraft:iron_block
fill 227 159 443 227 162 443 minecraft:iron_block
fill 228 159 440 229 159 440 minecraft:iron_block
fill 189 160 437 189 161 438 minecraft:iron_block
fill 189 160 443 190 162 443 minecraft:iron_block
fill 190 160 426 190 164 428 minecraft:polished_deepslate
fill 190 160 437 190 162 437 minecraft:iron_block
fill 190 160 438 190 164 440 minecraft:polished_deepslate
fill 190 160 441 190 161 441 minecraft:iron_block
fill 190 160 450 190 164 452 minecraft:polished_deepslate
fill 191 160 436 191 163 436 minecraft:iron_block
fill 191 160 438 194 161 438 minecraft:iron_block
fill 191 160 444 191 163 444 minecraft:iron_block
fill 192 160 437 193 162 437 minecraft:iron_block
fill 192 160 443 193 162 443 minecraft:iron_block
fill 194 160 439 194 162 439 minecraft:iron_block
fill 194 160 441 194 162 442 minecraft:iron_block
fill 195 160 440 195 163 440 minecraft:iron_block
fill 196 160 456 198 164 456 minecraft:polished_deepslate
fill 200 160 418 202 164 418 minecraft:polished_deepslate
fill 208 160 456 210 164 456 minecraft:polished_deepslate
fill 212 160 418 214 164 418 minecraft:polished_deepslate
fill 220 160 456 222 164 456 minecraft:polished_deepslate
fill 223 160 440 223 163 440 minecraft:iron_block
fill 224 160 418 226 164 418 minecraft:polished_deepslate
fill 224 160 438 227 160 439 minecraft:iron_block
fill 224 160 441 224 162 442 minecraft:iron_block
fill 225 160 437 226 162 437 minecraft:iron_block
fill 225 160 443 226 162 443 minecraft:iron_block
fill 227 160 436 227 163 436 minecraft:iron_block
fill 227 160 444 227 163 444 minecraft:iron_block
fill 228 160 426 228 164 428 minecraft:polished_deepslate
fill 228 160 437 228 162 437 minecraft:iron_block
fill 228 160 438 228 164 440 minecraft:polished_deepslate
fill 228 160 443 229 162 443 minecraft:iron_block
fill 228 160 450 228 164 452 minecraft:polished_deepslate
fill 229 160 440 229 161 440 minecraft:iron_block
fill 189 161 436 190 164 436 minecraft:iron_block
fill 189 161 444 190 164 444 minecraft:iron_block
fill 191 161 439 191 164 441 minecraft:polished_deepslate
fill 192 161 436 193 164 436 minecraft:iron_block
fill 192 161 439 193 161 439 minecraft:iron_block
fill 192 161 440 192 164 440 minecraft:polished_deepslate
fill 192 161 441 193 161 441 minecraft:iron_block
fill 192 161 444 193 164 444 minecraft:iron_block
fill 193 161 440 194 161 440 minecraft:iron_block
fill 194 161 437 194 164 437 minecraft:iron_block
fill 194 161 443 194 164 443 minecraft:iron_block
fill 195 161 438 195 164 439 minecraft:iron_block
fill 195 161 441 195 164 442 minecraft:iron_block
fill 207 161 441 208 161 442 minecraft:gold_block
fill 208 161 440 209 162 440 minecraft:gold_block
fill 208 161 443 209 161 444 minecraft:gold_block
fill 209 161 439 212 161 439 minecraft:gold_block
fill 210 161 444 210 161 445 minecraft:gold_block
fill 211 161 440 213 161 440 minecraft:gold_block
fill 211 161 444 212 161 444 minecraft:gold_block
fill 212 161 441 213 161 443 minecraft:gold_block
fill 223 161 438 226 161 439 minecraft:iron_block
fill 223 161 441 223 164 442 minecraft:iron_block
fill 224 161 437 224 164 437 minecraft:iron_block
fill 224 161 440 225 161 440 minecraft:iron_block
fill 224 161 443 224 164 443 minecraft:iron_block
fill 225 161 436 226 164 436 minecraft:iron_block
fill 225 161 441 226 161 442 minecraft:iron_block
fill 225 161 444 226 164 444 minecraft:iron_block
fill 226 161 440 227 164 440 minecraft:polished_deepslate
setblock 227 161 438 minecraft:iron_block
fill 227 161 439 227 164 439 minecraft:polished_deepslate
fill 227 161 441 227 164 441 minecraft:polished_deepslate
fill 227 161 442 229 161 442 minecraft:iron_block
fill 228 161 436 229 164 436 minecraft:iron_block
fill 228 161 441 229 161 441 minecraft:iron_block
fill 228 161 444 229 164 444 minecraft:iron_block
setblock 189 162 437 minecraft:iron_block
fill 189 162 438 189 164 438 minecraft:polished_deepslate
fill 189 162 442 193 164 442 minecraft:polished_deepslate
fill 190 162 441 190 164 441 minecraft:polished_deepslate
fill 191 162 438 193 164 438 minecraft:polished_deepslate
fill 192 162 439 193 164 439 minecraft:polished_deepslate
fill 192 162 441 193 164 441 minecraft:polished_deepslate
fill 193 162 440 193 164 440 minecraft:polished_deepslate
setblock 194 162 438 minecraft:iron_block
setblock 194 162 440 minecraft:iron_block
fill 208 162 441 208 162 443 minecraft:gold_block
fill 209 162 443 209 162 444 minecraft:gold_block
setblock 210 162 439 minecraft:gold_block
fill 210 162 444 211 162 444 minecraft:gold_block
fill 211 162 440 212 162 440 minecraft:gold_block
fill 212 162 441 212 163 443 minecraft:gold_block
setblock 213 162 442 minecraft:gold_block
fill 223 162 438 224 162 439 minecraft:iron_block
setblock 224 162 440 minecraft:iron_block
fill 225 162 438 225 164 442 minecraft:polished_deepslate
fill 226 162 438 226 164 439 minecraft:polished_deepslate
fill 226 162 441 226 164 442 minecraft:polished_deepslate
fill 227 162 438 227 164 438 minecraft:polished_deepslate
fill 227 162 442 229 164 442 minecraft:polished_deepslate
fill 228 162 441 229 164 441 minecraft:polished_deepslate
fill 229 162 440 229 164 440 minecraft:polished_deepslate
fill 189 163 437 193 164 437 minecraft:polished_deepslate
fill 189 163 443 193 164 443 minecraft:polished_deepslate
setblock 191 163 435 minecraft:iron_block
setblock 191 163 445 minecraft:iron_block
setblock 194 163 436 minecraft:iron_block
fill 194 163 438 194 164 442 minecraft:polished_deepslate
setblock 194 163 444 minecraft:iron_block
setblock 195 163 437 minecraft:iron_block
setblock 195 163 443 minecraft:iron_block
setblock 196 163 440 minecraft:iron_block
setblock 208 163 442 minecraft:gold_block
setblock 209 163 440 minecraft:gold_block
setblock 209 163 443 minecraft:gold_block
setblock 211 163 440 minecraft:gold_block
setblock 222 163 440 minecraft:iron_block
fill 223 163 437 223 163 439 minecraft:iron_block
setblock 223 163 443 minecraft:iron_block
setblock 224 163 436 minecraft:iron_block
fill 224 163 438 224 164 442 minecraft:polished_deepslate
setblock 224 163 444 minecraft:iron_block
fill 225 163 437 228 164 437 minecraft:polished_deepslate
fill 225 163 443 229 164 443 minecraft:polished_deepslate
setblock 227 163 435 minecraft:iron_block
setblock 227 163 445 minecraft:iron_block
setblock 191 164 436 minecraft:polished_deepslate
setblock 191 164 444 minecraft:polished_deepslate
setblock 195 164 440 minecraft:polished_deepslate
fill 223 164 438 223 164 439 minecraft:iron_block
setblock 223 164 440 minecraft:polished_deepslate
setblock 227 164 436 minecraft:polished_deepslate
setblock 227 164 444 minecraft:polished_deepslate
setblock 191 166 419 minecraft:light[level=13]
setblock 191 166 427 minecraft:light[level=13]
setblock 191 166 435 minecraft:light[level=13]
setblock 191 166 443 minecraft:light[level=13]
setblock 191 166 451 minecraft:light[level=13]
setblock 199 166 419 minecraft:light[level=13]
setblock 199 166 427 minecraft:light[level=13]
setblock 199 166 435 minecraft:light[level=13]
setblock 199 166 443 minecraft:light[level=13]
setblock 199 166 451 minecraft:light[level=13]
setblock 207 166 419 minecraft:light[level=13]
setblock 207 166 427 minecraft:light[level=13]
setblock 207 166 435 minecraft:light[level=13]
setblock 207 166 443 minecraft:light[level=13]
setblock 207 166 451 minecraft:light[level=13]
setblock 215 166 419 minecraft:light[level=13]
setblock 215 166 427 minecraft:light[level=13]
setblock 215 166 435 minecraft:light[level=13]
setblock 215 166 443 minecraft:light[level=13]
setblock 215 166 451 minecraft:light[level=13]
setblock 223 166 419 minecraft:light[level=13]
setblock 223 166 427 minecraft:light[level=13]
setblock 223 166 435 minecraft:light[level=13]
setblock 223 166 443 minecraft:light[level=13]
setblock 223 166 451 minecraft:light[level=13]
fill 205 167 437 209 167 437 minecraft:redstone_block
fill 206 167 434 208 167 434 minecraft:redstone_block
fill 206 167 438 208 167 438 minecraft:redstone_block
fill 207 167 435 209 167 436 minecraft:redstone_block
fill 203 168 434 203 168 438 minecraft:redstone_block
fill 204 168 433 205 168 434 minecraft:redstone_block
fill 204 168 436 204 168 439 minecraft:redstone_block
fill 205 168 432 209 168 432 minecraft:redstone_block
fill 205 168 437 209 168 437 minecraft:red_concrete
fill 205 168 438 205 168 440 minecraft:redstone_block
fill 206 168 433 210 168 433 minecraft:redstone_block
fill 206 168 434 208 168 434 minecraft:red_concrete
fill 206 168 438 208 178 438 minecraft:red_concrete
fill 206 168 439 209 168 440 minecraft:redstone_block
fill 207 168 435 209 168 436 minecraft:red_concrete
fill 209 168 434 211 168 434 minecraft:redstone_block
fill 209 168 438 211 168 438 minecraft:redstone_block
fill 210 168 435 211 168 437 minecraft:redstone_block
setblock 210 168 439 minecraft:redstone_block
fill 202 169 434 202 169 438 minecraft:redstone_block
fill 203 169 432 203 169 433 minecraft:redstone_block
fill 203 169 437 203 178 438 minecraft:red_concrete
fill 203 169 439 203 169 440 minecraft:redstone_block
setblock 204 169 432 minecraft:redstone_block
fill 204 169 438 205 178 439 minecraft:red_concrete
setblock 204 169 440 minecraft:redstone_block
fill 205 169 431 209 169 431 minecraft:redstone_block
fill 205 169 432 209 178 432 minecraft:red_concrete
fill 205 169 440 209 180 440 minecraft:red_concrete
fill 205 169 441 209 169 441 minecraft:redstone_block
fill 206 169 439 210 180 439 minecraft:red_concrete
fill 207 169 433 210 178 433 minecraft:red_concrete
fill 207 169 437 211 178 437 minecraft:red_concrete
fill 208 169 434 211 178 436 minecraft:red_concrete
fill 209 169 438 211 180 438 minecraft:red_concrete
fill 210 169 432 211 169 432 minecraft:redstone_block
fill 210 169 440 211 169 440 minecraft:redstone_block
setblock 211 169 433 minecraft:redstone_block
setblock 211 169 439 minecraft:redstone_block
fill 212 169 434 212 169 438 minecraft:redstone_block
fill 201 170 434 201 170 438 minecraft:redstone_block
fill 202 170 432 202 170 433 minecraft:redstone_block
fill 202 170 434 202 178 438 minecraft:red_concrete
fill 202 170 439 202 170 440 minecraft:redstone_block
fill 203 170 431 204 170 431 minecraft:redstone_block
fill 203 170 432 203 178 433 minecraft:red_concrete
fill 203 170 439 203 179 440 minecraft:red_concrete
fill 203 170 441 204 170 441 minecraft:redstone_block
fill 204 170 432 204 178 432 minecraft:red_concrete
fill 204 170 440 204 179 440 minecraft:red_concrete
fill 205 170 430 209 170 430 minecraft:redstone_block
fill 205 170 431 209 179 431 minecraft:red_concrete
fill 205 170 441 209 179 441 minecraft:red_concrete
fill 205 170 442 209 170 442 minecraft:redstone_block
fill 210 170 431 211 170 431 minecraft:redstone_block
fill 210 170 432 211 179 432 minecraft:red_concrete
fill 210 170 440 211 179 440 minecraft:red_concrete
fill 210 170 441 211 170 441 minecraft:redstone_block
fill 211 170 433 211 179 433 minecraft:red_concrete
fill 211 170 439 211 179 439 minecraft:red_concrete
fill 212 170 432 212 170 433 minecraft:redstone_block
fill 212 170 434 212 179 438 minecraft:red_concrete
fill 212 170 439 212 170 440 minecraft:redstone_block
fill 213 170 434 213 170 438 minecraft:redstone_block
fill 200 171 435 200 178 437 minecraft:redstone_block
fill 201 171 433 201 171 434 minecraft:redstone_block
fill 201 171 435 201 178 437 minecraft:red_concrete
fill 201 171 438 201 171 439 minecraft:redstone_block
fill 202 171 431 202 171 432 minecraft:redstone_block
fill 202 171 433 202 178 433 minecraft:red_concrete
fill 202 171 439 202 178 439 minecraft:red_concrete
fill 202 171 440 202 171 441 minecraft:redstone_block
setblock 203 171 431 minecraft:redstone_block
setblock 203 171 441 minecraft:redstone_block
fill 204 171 430 205 171 430 minecraft:redstone_block
fill 204 171 431 204 178 431 minecraft:red_concrete
fill 204 171 441 204 178 441 minecraft:red_concrete
fill 204 171 442 205 171 442 minecraft:redstone_block
fill 206 171 429 208 178 429 minecraft:redstone_block
fill 206 171 430 208 178 430 minecraft:red_concrete
fill 206 171 442 208 178 442 minecraft:red_concrete
fill 206 171 443 208 178 443 minecraft:redstone_block
fill 209 171 430 210 171 430 minecraft:redstone_block
fill 209 171 442 210 171 442 minecraft:redstone_block
fill 210 171 431 210 178 431 minecraft:red_concrete
fill 210 171 441 210 178 441 minecraft:red_concrete
fill 211 171 431 212 171 431 minecraft:redstone_block
fill 211 171 441 212 171 441 minecraft:redstone_block
setblock 212 171 432 minecraft:redstone_block
fill 212 171 433 212 178 433 minecraft:red_concrete
fill 212 171 439 212 178 439 minecraft:red_concrete
setblock 212 171 440 minecraft:redstone_block
fill 213 171 433 213 171 434 minecraft:redstone_block
fill 213 171 435 213 178 437 minecraft:red_concrete
fill 213 171 438 213 171 439 minecraft:redstone_block
fill 214 171 435 214 178 437 minecraft:redstone_block
fill 200 172 434 200 177 434 minecraft:redstone_block
fill 200 172 438 200 177 438 minecraft:redstone_block
fill 201 172 432 201 172 433 minecraft:redstone_block
fill 201 172 434 201 177 434 minecraft:red_concrete
fill 201 172 438 201 177 438 minecraft:red_concrete
fill 201 172 439 201 172 440 minecraft:redstone_block
setblock 202 172 431 minecraft:redstone_block
fill 202 172 432 202 177 432 minecraft:red_concrete
fill 202 172 440 202 177 440 minecraft:red_concrete
setblock 202 172 441 minecraft:redstone_block
fill 203 172 430 204 172 430 minecraft:redstone_block
fill 203 172 431 203 177 431 minecraft:red_concrete
fill 203 172 441 203 177 441 minecraft:red_concrete
fill 203 172 442 204 172 442 minecraft:redstone_block
fill 205 172 429 205 177 429 minecraft:redstone_block
fill 205 172 430 205 177 430 minecraft:red_concrete
fill 205 172 442 205 177 442 minecraft:red_concrete
fill 205 172 443 205 177 443 minecraft:redstone_block
fill 209 172 429 209 177 429 minecraft:redstone_block
fill 209 172 430 209 177 430 minecraft:red_concrete
fill 209 172 442 209 177 442 minecraft:red_concrete
fill 209 172 443 209 177 443 minecraft:redstone_block
fill 210 172 430 211 172 430 minecraft:redstone_block
fill 210 172 442 211 172 442 minecraft:redstone_block
fill 211 172 431 211 177 431 minecraft:red_concrete
fill 211 172 441 211 177 441 minecraft:red_concrete
setblock 212 172 431 minecraft:redstone_block
fill 212 172 432 212 177 432 minecraft:red_concrete
fill 212 172 440 212 177 440 minecraft:red_concrete
setblock 212 172 441 minecraft:redstone_block
fill 213 172 432 213 172 433 minecraft:redstone_block
fill 213 172 434 213 177 434 minecraft:red_concrete
fill 213 172 438 213 177 438 minecraft:red_concrete
fill 213 172 439 213 172 440 minecraft:redstone_block
fill 214 172 434 214 177 434 minecraft:redstone_block
fill 214 172 438 214 177 438 minecraft:redstone_block
fill 200 173 433 200 176 433 minecraft:redstone_block
fill 200 173 439 200 176 439 minecraft:redstone_block
fill 201 173 431 201 176 432 minecraft:redstone_block
fill 201 173 433 201 176 433 minecraft:red_concrete
fill 201 173 439 201 176 439 minecraft:red_concrete
fill 201 173 440 201 176 441 minecraft:redstone_block
fill 202 173 430 203 176 430 minecraft:redstone_block
fill 202 173 431 202 176 431 minecraft:red_concrete
fill 202 173 441 202 176 441 minecraft:red_concrete
fill 202 173 442 203 176 442 minecraft:redstone_block
fill 204 173 429 204 176 429 minecraft:redstone_block
fill 204 173 430 204 176 430 minecraft:red_concrete
fill 204 173 442 204 176 442 minecraft:red_concrete
fill 204 173 443 204 176 443 minecraft:redstone_block
fill 210 173 429 210 176 429 minecraft:redstone_block
fill 210 173 430 210 176 430 minecraft:red_concrete
fill 210 173 442 210 176 442 minecraft:red_concrete
fill 210 173 443 210 176 443 minecraft:redstone_block
fill 211 173 430 212 176 430 minecraft:redstone_block
fill 211 173 442 212 176 442 minecraft:redstone_block
fill 212 173 431 212 176 431 minecraft:red_concrete
fill 212 173 441 212 176 441 minecraft:red_concrete
fill 213 173 431 213 176 432 minecraft:redstone_block
fill 213 173 433 213 176 433 minecraft:red_concrete
fill 213 173 439 213 176 439 minecraft:red_concrete
fill 213 173 440 213 176 441 minecraft:redstone_block
fill 214 173 433 214 176 433 minecraft:redstone_block
fill 214 173 439 214 176 439 minecraft:redstone_block
setblock 191 174 419 minecraft:light[level=13]
setblock 191 174 427 minecraft:light[level=13]
setblock 191 174 435 minecraft:light[level=13]
setblock 191 174 443 minecraft:light[level=13]
setblock 191 174 451 minecraft:light[level=13]
setblock 199 174 419 minecraft:light[level=13]
setblock 199 174 427 minecraft:light[level=13]
setblock 199 174 435 minecraft:light[level=13]
setblock 199 174 443 minecraft:light[level=13]
setblock 199 174 451 minecraft:light[level=13]
setblock 207 174 419 minecraft:light[level=13]
setblock 207 174 427 minecraft:light[level=13]
setblock 207 174 451 minecraft:light[level=13]
setblock 215 174 419 minecraft:light[level=13]
setblock 215 174 427 minecraft:light[level=13]
setblock 215 174 435 minecraft:light[level=13]
setblock 215 174 443 minecraft:light[level=13]
setblock 215 174 451 minecraft:light[level=13]
setblock 223 174 419 minecraft:light[level=13]
setblock 223 174 427 minecraft:light[level=13]
setblock 223 174 435 minecraft:light[level=13]
setblock 223 174 443 minecraft:light[level=13]
setblock 223 174 451 minecraft:light[level=13]
fill 201 177 432 201 177 433 minecraft:redstone_block
fill 201 177 439 201 177 440 minecraft:redstone_block
fill 202 177 431 202 178 431 minecraft:redstone_block
fill 202 177 441 202 178 441 minecraft:redstone_block
fill 203 177 430 204 177 430 minecraft:redstone_block
fill 203 177 442 204 177 442 minecraft:redstone_block
fill 210 177 430 211 177 430 minecraft:redstone_block
fill 210 177 442 211 177 442 minecraft:redstone_block
fill 212 177 431 212 178 431 minecraft:redstone_block
fill 212 177 441 212 178 441 minecraft:redstone_block
fill 213 177 432 213 177 433 minecraft:redstone_block
fill 213 177 439 213 177 440 minecraft:redstone_block
fill 201 178 433 201 178 434 minecraft:redstone_block
fill 201 178 438 201 178 439 minecraft:redstone_block
fill 202 178 432 202 179 432 minecraft:redstone_block
fill 202 178 440 202 179 440 minecraft:redstone_block
fill 203 178 431 203 179 431 minecraft:redstone_block
fill 203 178 441 203 179 441 minecraft:redstone_block
fill 204 178 430 205 178 430 minecraft:redstone_block
fill 204 178 442 205 178 442 minecraft:redstone_block
fill 209 178 430 210 178 430 minecraft:redstone_block
fill 209 178 442 210 178 442 minecraft:redstone_block
fill 211 178 431 211 179 431 minecraft:redstone_block
fill 211 178 441 211 179 441 minecraft:redstone_block
fill 212 178 432 212 179 432 minecraft:redstone_block
fill 212 178 440 212 179 440 minecraft:redstone_block
fill 213 178 433 213 178 434 minecraft:redstone_block
fill 213 178 438 213 178 439 minecraft:redstone_block
fill 189 179 417 189 179 418 minecraft:polished_deepslate
setblock 189 179 419 minecraft:red_concrete
fill 189 179 420 189 179 422 minecraft:polished_deepslate
setblock 189 179 423 minecraft:red_concrete
fill 189 179 424 189 179 426 minecraft:polished_deepslate
setblock 189 179 427 minecraft:red_concrete
fill 189 179 428 189 179 430 minecraft:polished_deepslate
setblock 189 179 431 minecraft:red_concrete
fill 189 179 432 189 179 434 minecraft:polished_deepslate
setblock 189 179 435 minecraft:red_concrete
fill 189 179 436 189 179 438 minecraft:polished_deepslate
setblock 189 179 439 minecraft:red_concrete
fill 189 179 440 189 179 442 minecraft:polished_deepslate
setblock 189 179 443 minecraft:red_concrete
fill 189 179 444 189 179 446 minecraft:polished_deepslate
setblock 189 179 447 minecraft:red_concrete
fill 189 179 448 189 179 450 minecraft:polished_deepslate
setblock 189 179 451 minecraft:red_concrete
fill 189 179 452 189 179 454 minecraft:polished_deepslate
setblock 189 179 455 minecraft:red_concrete
fill 189 179 456 190 179 457 minecraft:polished_deepslate
setblock 190 179 417 minecraft:polished_deepslate
setblock 190 179 418 minecraft:red_concrete
fill 190 179 419 190 179 421 minecraft:polished_deepslate
setblock 190 179 422 minecraft:red_concrete
fill 190 179 423 190 179 425 minecraft:polished_deepslate
setblock 190 179 426 minecraft:red_concrete
fill 190 179 427 190 179 429 minecraft:polished_deepslate
setblock 190 179 430 minecraft:red_concrete
fill 190 179 431 190 179 433 minecraft:polished_deepslate
setblock 190 179 434 minecraft:red_concrete
fill 190 179 435 190 179 437 minecraft:polished_deepslate
setblock 190 179 438 minecraft:red_concrete
fill 190 179 439 190 179 441 minecraft:polished_deepslate
setblock 190 179 442 minecraft:red_concrete
fill 190 179 443 190 179 445 minecraft:polished_deepslate
setblock 190 179 446 minecraft:red_concrete
fill 190 179 447 190 179 449 minecraft:polished_deepslate
setblock 190 179 450 minecraft:red_concrete
fill 190 179 451 190 179 453 minecraft:polished_deepslate
setblock 190 179 454 minecraft:red_concrete
fill 190 179 455 192 179 455 minecraft:polished_deepslate
setblock 191 179 417 minecraft:red_concrete
fill 191 179 418 191 179 420 minecraft:polished_deepslate
setblock 191 179 421 minecraft:red_concrete
fill 191 179 422 191 179 424 minecraft:polished_deepslate
setblock 191 179 425 minecraft:red_concrete
fill 191 179 426 191 179 428 minecraft:polished_deepslate
setblock 191 179 429 minecraft:red_concrete
fill 191 179 430 191 179 432 minecraft:polished_deepslate
setblock 191 179 433 minecraft:red_concrete
fill 191 179 434 191 179 436 minecraft:polished_deepslate
setblock 191 179 437 minecraft:red_concrete
fill 191 179 438 191 179 440 minecraft:polished_deepslate
setblock 191 179 441 minecraft:red_concrete
fill 191 179 442 191 179 444 minecraft:polished_deepslate
setblock 191 179 445 minecraft:red_concrete
fill 191 179 446 191 179 448 minecraft:polished_deepslate
setblock 191 179 449 minecraft:red_concrete
fill 191 179 450 191 179 452 minecraft:polished_deepslate
setblock 191 179 453 minecraft:red_concrete
fill 191 179 454 193 179 454 minecraft:polished_deepslate
setblock 191 179 456 minecraft:polished_deepslate
setblock 191 179 457 minecraft:red_concrete
fill 192 179 417 192 179 419 minecraft:polished_deepslate
setblock 192 179 420 minecraft:red_concrete
fill 192 179 421 192 179 423 minecraft:polished_deepslate
setblock 192 179 424 minecraft:red_concrete
fill 192 179 425 192 179 427 minecraft:polished_deepslate
setblock 192 179 428 minecraft:red_concrete
fill 192 179 429 192 179 431 minecraft:polished_deepslate
setblock 192 179 432 minecraft:red_concrete
fill 192 179 433 192 179 435 minecraft:polished_deepslate
setblock 192 179 436 minecraft:red_concrete
fill 192 179 437 192 179 439 minecraft:polished_deepslate
setblock 192 179 440 minecraft:red_concrete
fill 192 179 441 192 179 443 minecraft:polished_deepslate
setblock 192 179 444 minecraft:red_concrete
fill 192 179 445 192 179 447 minecraft:polished_deepslate
setblock 192 179 448 minecraft:red_concrete
fill 192 179 449 192 179 451 minecraft:polished_deepslate
setblock 192 179 452 minecraft:red_concrete
fill 192 179 453 194 179 453 minecraft:polished_deepslate
setblock 192 179 456 minecraft:red_concrete
fill 192 179 457 194 179 457 minecraft:polished_deepslate
fill 193 179 417 193 179 418 minecraft:polished_deepslate
setblock 193 179 419 minecraft:red_concrete
fill 193 179 420 193 179 422 minecraft:polished_deepslate
setblock 193 179 423 minecraft:red_concrete
fill 193 179 424 193 179 426 minecraft:polished_deepslate
setblock 193 179 427 minecraft:red_concrete
fill 193 179 428 193 179 430 minecraft:polished_deepslate
setblock 193 179 431 minecraft:red_concrete
fill 193 179 432 193 179 434 minecraft:polished_deepslate
setblock 193 179 435 minecraft:red_concrete
fill 193 179 436 193 179 438 minecraft:polished_deepslate
setblock 193 179 439 minecraft:red_concrete
fill 193 179 440 193 179 442 minecraft:polished_deepslate
setblock 193 179 443 minecraft:red_concrete
fill 193 179 444 193 179 446 minecraft:polished_deepslate
setblock 193 179 447 minecraft:red_concrete
fill 193 179 448 193 179 450 minecraft:polished_deepslate
setblock 193 179 451 minecraft:red_concrete
fill 193 179 452 195 179 452 minecraft:polished_deepslate
setblock 193 179 455 minecraft:red_concrete
fill 193 179 456 195 179 456 minecraft:polished_deepslate
setblock 194 179 417 minecraft:polished_deepslate
setblock 194 179 418 minecraft:red_concrete
fill 194 179 419 194 179 421 minecraft:polished_deepslate
setblock 194 179 422 minecraft:red_concrete
fill 194 179 423 194 179 425 minecraft:polished_deepslate
setblock 194 179 426 minecraft:red_concrete
fill 194 179 427 194 179 429 minecraft:polished_deepslate
setblock 194 179 430 minecraft:red_concrete
fill 194 179 431 194 179 433 minecraft:polished_deepslate
setblock 194 179 434 minecraft:red_concrete
fill 194 179 435 194 179 437 minecraft:polished_deepslate
setblock 194 179 438 minecraft:red_concrete
fill 194 179 439 194 179 441 minecraft:polished_deepslate
setblock 194 179 442 minecraft:red_concrete
fill 194 179 443 194 179 445 minecraft:polished_deepslate
setblock 194 179 446 minecraft:red_concrete
fill 194 179 447 194 179 449 minecraft:polished_deepslate
setblock 194 179 450 minecraft:red_concrete
fill 194 179 451 196 179 451 minecraft:polished_deepslate
setblock 194 179 454 minecraft:red_concrete
fill 194 179 455 196 179 455 minecraft:polished_deepslate
setblock 195 179 417 minecraft:red_concrete
fill 195 179 418 195 179 420 minecraft:polished_deepslate
setblock 195 179 421 minecraft:red_concrete
fill 195 179 422 195 179 424 minecraft:polished_deepslate
setblock 195 179 425 minecraft:red_concrete
fill 195 179 426 195 179 428 minecraft:polished_deepslate
setblock 195 179 429 minecraft:red_concrete
fill 195 179 430 195 179 432 minecraft:polished_deepslate
setblock 195 179 433 minecraft:red_concrete
fill 195 179 434 195 179 436 minecraft:polished_deepslate
setblock 195 179 437 minecraft:red_concrete
fill 195 179 438 195 179 440 minecraft:polished_deepslate
setblock 195 179 441 minecraft:red_concrete
fill 195 179 442 195 179 444 minecraft:polished_deepslate
setblock 195 179 445 minecraft:red_concrete
fill 195 179 446 195 179 448 minecraft:polished_deepslate
setblock 195 179 449 minecraft:red_concrete
fill 195 179 450 197 179 450 minecraft:polished_deepslate
setblock 195 179 453 minecraft:red_concrete
fill 195 179 454 197 179 454 minecraft:polished_deepslate
setblock 195 179 457 minecraft:red_concrete
fill 196 179 417 196 179 419 minecraft:polished_deepslate
setblock 196 179 420 minecraft:red_concrete
fill 196 179 421 196 179 423 minecraft:polished_deepslate
setblock 196 179 424 minecraft:red_concrete
fill 196 179 425 196 179 427 minecraft:polished_deepslate
setblock 196 179 428 minecraft:red_concrete
fill 196 179 429 196 179 431 minecraft:polished_deepslate
setblock 196 179 432 minecraft:red_concrete
fill 196 179 433 196 179 435 minecraft:polished_deepslate
setblock 196 179 436 minecraft:red_concrete
fill 196 179 437 196 179 439 minecraft:polished_deepslate
setblock 196 179 440 minecraft:red_concrete
fill 196 179 441 196 179 443 minecraft:polished_deepslate
setblock 196 179 444 minecraft:red_concrete
fill 196 179 445 196 179 447 minecraft:polished_deepslate
setblock 196 179 448 minecraft:red_concrete
fill 196 179 449 198 179 449 minecraft:polished_deepslate
setblock 196 179 452 minecraft:red_concrete
fill 196 179 453 198 179 453 minecraft:polished_deepslate
setblock 196 179 456 minecraft:red_concrete
fill 196 179 457 198 179 457 minecraft:polished_deepslate
fill 197 179 417 197 179 418 minecraft:polished_deepslate
setblock 197 179 419 minecraft:red_concrete
fill 197 179 420 197 179 422 minecraft:polished_deepslate
setblock 197 179 423 minecraft:red_concrete
fill 197 179 424 197 179 426 minecraft:polished_deepslate
setblock 197 179 427 minecraft:red_concrete
fill 197 179 428 197 179 430 minecraft:polished_deepslate
setblock 197 179 431 minecraft:red_concrete
fill 197 179 432 197 179 434 minecraft:polished_deepslate
setblock 197 179 435 minecraft:red_concrete
fill 197 179 436 197 179 438 minecraft:polished_deepslate
setblock 197 179 439 minecraft:red_concrete
fill 197 179 440 197 179 442 minecraft:polished_deepslate
setblock 197 179 443 minecraft:red_concrete
fill 197 179 444 197 179 446 minecraft:polished_deepslate
setblock 197 179 447 minecraft:red_concrete
fill 197 179 448 199 179 448 minecraft:polished_deepslate
setblock 197 179 451 minecraft:red_concrete
fill 197 179 452 199 179 452 minecraft:polished_deepslate
setblock 197 179 455 minecraft:red_concrete
fill 197 179 456 199 179 456 minecraft:polished_deepslate
setblock 198 179 417 minecraft:polished_deepslate
setblock 198 179 418 minecraft:red_concrete
fill 198 179 419 198 179 421 minecraft:polished_deepslate
setblock 198 179 422 minecraft:red_concrete
fill 198 179 423 198 179 425 minecraft:polished_deepslate
setblock 198 179 426 minecraft:red_concrete
fill 198 179 427 198 179 429 minecraft:polished_deepslate
setblock 198 179 430 minecraft:red_concrete
fill 198 179 431 198 179 433 minecraft:polished_deepslate
setblock 198 179 434 minecraft:red_concrete
fill 198 179 435 198 179 437 minecraft:polished_deepslate
setblock 198 179 438 minecraft:red_concrete
fill 198 179 439 198 179 441 minecraft:polished_deepslate
setblock 198 179 442 minecraft:red_concrete
fill 198 179 443 198 179 445 minecraft:polished_deepslate
setblock 198 179 446 minecraft:red_concrete
fill 198 179 447 200 179 447 minecraft:polished_deepslate
setblock 198 179 450 minecraft:red_concrete
fill 198 179 451 200 179 451 minecraft:polished_deepslate
setblock 198 179 454 minecraft:red_concrete
fill 198 179 455 200 179 455 minecraft:polished_deepslate
setblock 199 179 417 minecraft:red_concrete
fill 199 179 418 199 179 420 minecraft:polished_deepslate
setblock 199 179 421 minecraft:red_concrete
fill 199 179 422 199 179 424 minecraft:polished_deepslate
setblock 199 179 425 minecraft:red_concrete
fill 199 179 426 199 179 428 minecraft:polished_deepslate
setblock 199 179 429 minecraft:red_concrete
fill 199 179 430 199 179 432 minecraft:polished_deepslate
setblock 199 179 433 minecraft:red_concrete
fill 199 179 434 199 179 436 minecraft:polished_deepslate
setblock 199 179 437 minecraft:red_concrete
fill 199 179 438 199 179 440 minecraft:polished_deepslate
setblock 199 179 441 minecraft:red_concrete
fill 199 179 442 199 179 444 minecraft:polished_deepslate
setblock 199 179 445 minecraft:red_concrete
fill 199 179 446 201 179 446 minecraft:polished_deepslate
setblock 199 179 449 minecraft:red_concrete
fill 199 179 450 201 179 450 minecraft:polished_deepslate
setblock 199 179 453 minecraft:red_concrete
fill 199 179 454 201 179 454 minecraft:polished_deepslate
setblock 199 179 457 minecraft:red_concrete
fill 200 179 417 200 179 419 minecraft:polished_deepslate
setblock 200 179 420 minecraft:red_concrete
fill 200 179 421 200 179 423 minecraft:polished_deepslate
setblock 200 179 424 minecraft:red_concrete
fill 200 179 425 200 179 427 minecraft:polished_deepslate
setblock 200 179 428 minecraft:red_concrete
fill 200 179 429 200 179 431 minecraft:polished_deepslate
setblock 200 179 432 minecraft:red_concrete
fill 200 179 433 200 179 435 minecraft:polished_deepslate
setblock 200 179 436 minecraft:red_concrete
fill 200 179 437 200 179 439 minecraft:polished_deepslate
setblock 200 179 440 minecraft:red_concrete
fill 200 179 441 200 179 443 minecraft:polished_deepslate
setblock 200 179 444 minecraft:red_concrete
fill 200 179 445 202 179 445 minecraft:polished_deepslate
setblock 200 179 448 minecraft:red_concrete
fill 200 179 449 202 179 449 minecraft:polished_deepslate
setblock 200 179 452 minecraft:red_concrete
fill 200 179 453 202 179 453 minecraft:polished_deepslate
setblock 200 179 456 minecraft:red_concrete
fill 200 179 457 202 179 457 minecraft:polished_deepslate
fill 201 179 417 201 179 418 minecraft:polished_deepslate
setblock 201 179 419 minecraft:red_concrete
fill 201 179 420 201 179 422 minecraft:polished_deepslate
setblock 201 179 423 minecraft:red_concrete
fill 201 179 424 201 179 426 minecraft:polished_deepslate
setblock 201 179 427 minecraft:red_concrete
fill 201 179 428 201 179 430 minecraft:polished_deepslate
setblock 201 179 431 minecraft:red_concrete
fill 201 179 432 201 179 433 minecraft:polished_deepslate
fill 201 179 434 201 179 438 minecraft:redstone_block
setblock 201 179 439 minecraft:red_concrete
fill 201 179 440 201 179 442 minecraft:polished_deepslate
setblock 201 179 443 minecraft:red_concrete
fill 201 179 444 203 179 444 minecraft:polished_deepslate
setblock 201 179 447 minecraft:red_concrete
fill 201 179 448 203 179 448 minecraft:polished_deepslate
setblock 201 179 451 minecraft:red_concrete
fill 201 179 452 203 179 452 minecraft:polished_deepslate
setblock 201 179 455 minecraft:red_concrete
fill 201 179 456 203 179 456 minecraft:polished_deepslate
setblock 202 179 417 minecraft:polished_deepslate
setblock 202 179 418 minecraft:red_concrete
fill 202 179 419 202 179 421 minecraft:polished_deepslate
setblock 202 179 422 minecraft:red_concrete
fill 202 179 423 202 179 425 minecraft:polished_deepslate
setblock 202 179 426 minecraft:red_concrete
fill 202 179 427 202 179 429 minecraft:polished_deepslate
setblock 202 179 430 minecraft:red_concrete
setblock 202 179 431 minecraft:polished_deepslate
fill 202 179 433 202 179 437 minecraft:shroomlight
setblock 202 179 438 minecraft:red_concrete
setblock 202 179 439 minecraft:redstone_block
setblock 202 179 441 minecraft:polished_deepslate
setblock 202 179 442 minecraft:red_concrete
fill 202 179 443 204 179 443 minecraft:polished_deepslate
setblock 202 179 446 minecraft:red_concrete
fill 202 179 447 204 179 447 minecraft:polished_deepslate
setblock 202 179 450 minecraft:red_concrete
fill 202 179 451 204 179 451 minecraft:polished_deepslate
setblock 202 179 454 minecraft:red_concrete
fill 202 179 455 204 179 455 minecraft:polished_deepslate
setblock 203 179 417 minecraft:red_concrete
fill 203 179 418 203 179 420 minecraft:polished_deepslate
setblock 203 179 421 minecraft:red_concrete
fill 203 179 422 203 179 424 minecraft:polished_deepslate
setblock 203 179 425 minecraft:red_concrete
fill 203 179 426 203 179 428 minecraft:polished_deepslate
setblock 203 179 429 minecraft:red_concrete
fill 203 179 430 204 179 430 minecraft:polished_deepslate
fill 203 179 432 203 179 433 minecraft:shroomlight
fill 203 179 437 203 179 438 minecraft:shroomlight
fill 203 179 442 204 179 442 minecraft:polished_deepslate
setblock 203 179 445 minecraft:red_concrete
fill 203 179 446 205 179 446 minecraft:polished_deepslate
setblock 203 179 449 minecraft:red_concrete
fill 203 179 450 205 179 450 minecraft:polished_deepslate
setblock 203 179 453 minecraft:red_concrete
fill 203 179 454 205 179 454 minecraft:polished_deepslate
setblock 203 179 457 minecraft:red_concrete
fill 204 179 417 204 179 419 minecraft:polished_deepslate
setblock 204 179 420 minecraft:red_concrete
fill 204 179 421 204 179 423 minecraft:polished_deepslate
setblock 204 179 424 minecraft:red_concrete
fill 204 179 425 204 179 427 minecraft:polished_deepslate
setblock 204 179 428 minecraft:red_concrete
fill 204 179 429 206 179 429 minecraft:polished_deepslate
setblock 204 179 431 minecraft:redstone_block
fill 204 179 432 207 179 432 minecraft:shroomlight
fill 204 179 438 207 179 438 minecraft:shroomlight
fill 204 179 439 205 180 439 minecraft:red_concrete
setblock 204 179 441 minecraft:redstone_block
setblock 204 179 444 minecraft:red_concrete
fill 204 179 445 206 179 445 minecraft:polished_deepslate
setblock 204 179 448 minecraft:red_concrete
fill 204 179 449 206 179 449 minecraft:polished_deepslate
setblock 204 179 452 minecraft:red_concrete
fill 204 179 453 206 179 453 minecraft:polished_deepslate
setblock 204 179 456 minecraft:red_concrete
fill 204 179 457 206 179 457 minecraft:polished_deepslate
fill 205 179 417 205 179 418 minecraft:polished_deepslate
setblock 205 179 419 minecraft:red_concrete
fill 205 179 420 205 179 422 minecraft:polished_deepslate
setblock 205 179 423 minecraft:red_concrete
fill 205 179 424 205 179 426 minecraft:polished_deepslate
setblock 205 179 427 minecraft:red_concrete
fill 205 179 428 207 179 428 minecraft:polished_deepslate
fill 205 179 430 209 179 430 minecraft:redstone_block
fill 205 179 442 209 179 442 minecraft:redstone_block
setblock 205 179 443 minecraft:red_concrete
fill 205 179 444 207 179 444 minecraft:polished_deepslate
setblock 205 179 447 minecraft:red_concrete
fill 205 179 448 207 179 448 minecraft:polished_deepslate
setblock 205 179 451 minecraft:red_concrete
fill 205 179 452 207 179 452 minecraft:polished_deepslate
setblock 205 179 455 minecraft:red_concrete
fill 205 179 456 207 179 456 minecraft:polished_deepslate
setblock 206 179 417 minecraft:polished_deepslate
setblock 206 179 418 minecraft:red_concrete
fill 206 179 419 206 179 421 minecraft:polished_deepslate
setblock 206 179 422 minecraft:red_concrete
fill 206 179 423 206 179 425 minecraft:polished_deepslate
setblock 206 179 426 minecraft:red_concrete
fill 206 179 427 208 179 427 minecraft:polished_deepslate
fill 206 179 443 208 179 443 minecraft:polished_deepslate
setblock 206 179 446 minecraft:red_concrete
fill 206 179 447 208 179 447 minecraft:polished_deepslate
setblock 206 179 450 minecraft:red_concrete
fill 206 179 451 208 179 451 minecraft:polished_deepslate
setblock 206 179 454 minecraft:red_concrete
fill 206 179 455 208 179 455 minecraft:polished_deepslate
setblock 207 179 417 minecraft:red_concrete
fill 207 179 418 207 179 420 minecraft:polished_deepslate
setblock 207 179 421 minecraft:red_concrete
fill 207 179 422 207 179 424 minecraft:polished_deepslate
setblock 207 179 425 minecraft:red_concrete
fill 207 179 426 209 179 426 minecraft:polished_deepslate
setblock 207 179 429 minecraft:red_concrete
fill 207 179 433 208 179 433 minecraft:shroomlight
fill 207 179 437 208 179 437 minecraft:shroomlight
setblock 207 179 445 minecraft:red_concrete
fill 207 179 446 209 179 446 minecraft:polished_deepslate
setblock 207 179 449 minecraft:red_concrete
fill 207 179 450 209 179 450 minecraft:polished_deepslate
setblock 207 179 453 minecraft:red_concrete
fill 207 179 454 209 179 454 minecraft:polished_deepslate
setblock 207 179 457 minecraft:red_concrete
fill 208 179 417 208 179 419 minecraft:polished_deepslate
setblock 208 179 420 minecraft:red_concrete
fill 208 179 421 208 179 423 minecraft:polished_deepslate
setblock 208 179 424 minecraft:red_concrete
fill 208 179 425 210 179 425 minecraft:polished_deepslate
setblock 208 179 428 minecraft:red_concrete
fill 208 179 429 210 179 429 minecraft:polished_deepslate
fill 208 179 432 209 180 432 minecraft:red_concrete
fill 208 179 434 208 179 436 minecraft:shroomlight
fill 208 179 438 208 181 438 minecraft:red_concrete
setblock 208 179 444 minecraft:red_concrete
fill 208 179 445 210 179 445 minecraft:polished_deepslate
setblock 208 179 448 minecraft:red_concrete
fill 208 179 449 210 179 449 minecraft:polished_deepslate
setblock 208 179 452 minecraft:red_concrete
fill 208 179 453 210 179 453 minecraft:polished_deepslate
setblock 208 179 456 minecraft:red_concrete
fill 208 179 457 210 179 457 minecraft:polished_deepslate
fill 209 179 417 209 179 418 minecraft:polished_deepslate
setblock 209 179 419 minecraft:red_concrete
fill 209 179 420 209 179 422 minecraft:polished_deepslate
setblock 209 179 423 minecraft:red_concrete
fill 209 179 424 211 179 424 minecraft:polished_deepslate
setblock 209 179 427 minecraft:red_concrete
fill 209 179 428 211 179 428 minecraft:polished_deepslate
fill 209 179 433 210 180 437 minecraft:red_concrete
setblock 209 179 443 minecraft:red_concrete
fill 209 179 444 211 179 444 minecraft:polished_deepslate
setblock 209 179 447 minecraft:red_concrete
fill 209 179 448 211 179 448 minecraft:polished_deepslate
setblock 209 179 451 minecraft:red_concrete
fill 209 179 452 211 179 452 minecraft:polished_deepslate
setblock 209 179 455 minecraft:red_concrete
fill 209 179 456 211 179 456 minecraft:polished_deepslate
setblock 210 179 417 minecraft:polished_deepslate
setblock 210 179 418 minecraft:red_concrete
fill 210 179 419 210 179 421 minecraft:polished_deepslate
setblock 210 179 422 minecraft:red_concrete
fill 210 179 423 212 179 423 minecraft:polished_deepslate
setblock 210 179 426 minecraft:red_concrete
fill 210 179 427 212 179 427 minecraft:polished_deepslate
setblock 210 179 430 minecraft:red_concrete
setblock 210 179 431 minecraft:redstone_block
setblock 210 179 441 minecraft:redstone_block
setblock 210 179 442 minecraft:red_concrete
fill 210 179 443 212 179 443 minecraft:polished_deepslate
setblock 210 179 446 minecraft:red_concrete
fill 210 179 447 212 179 447 minecraft:polished_deepslate
setblock 210 179 450 minecraft:red_concrete
fill 210 179 451 212 179 451 minecraft:polished_deepslate
setblock 210 179 454 minecraft:red_concrete
fill 210 179 455 212 179 455 minecraft:polished_deepslate
setblock 211 179 417 minecraft:red_concrete
fill 211 179 418 211 179 420 minecraft:polished_deepslate
setblock 211 179 421 minecraft:red_concrete
fill 211 179 422 213 179 422 minecraft:polished_deepslate
setblock 211 179 425 minecraft:red_concrete
fill 211 179 426 213 179 426 minecraft:polished_deepslate
setblock 211 179 429 minecraft:red_concrete
fill 211 179 430 213 179 430 minecraft:polished_deepslate
fill 211 179 434 211 180 437 minecraft:red_concrete
fill 211 179 442 213 179 442 minecraft:polished_deepslate
setblock 211 179 445 minecraft:red_concrete
fill 211 179 446 213 179 446 minecraft:polished_deepslate
setblock 211 179 449 minecraft:red_concrete
fill 211 179 450 213 179 450 minecraft:polished_deepslate
setblock 211 179 453 minecraft:red_concrete
fill 211 179 454 213 179 454 minecraft:polished_deepslate
setblock 211 179 457 minecraft:red_concrete
fill 212 179 417 212 179 419 minecraft:polished_deepslate
setblock 212 179 420 minecraft:red_concrete
fill 212 179 421 214 179 421 minecraft:polished_deepslate
setblock 212 179 424 minecraft:red_concrete
fill 212 179 425 214 179 425 minecraft:polished_deepslate
setblock 212 179 428 minecraft:red_concrete
fill 212 179 429 214 179 429 minecraft:polished_deepslate
setblock 212 179 431 minecraft:polished_deepslate
setblock 212 179 433 minecraft:redstone_block
setblock 212 179 439 minecraft:redstone_block
fill 212 179 441 214 179 441 minecraft:polished_deepslate
setblock 212 179 444 minecraft:red_concrete
fill 212 179 445 214 179 445 minecraft:polished_deepslate
setblock 212 179 448 minecraft:red_concrete
fill 212 179 449 214 179 449 minecraft:polished_deepslate
setblock 212 179 452 minecraft:red_concrete
fill 212 179 453 214 179 453 minecraft:polished_deepslate
setblock 212 179 456 minecraft:red_concrete
fill 212 179 457 214 179 457 minecraft:polished_deepslate
fill 213 179 417 213 179 418 minecraft:polished_deepslate
setblock 213 179 419 minecraft:red_concrete
fill 213 179 420 215 179 420 minecraft:polished_deepslate
setblock 213 179 423 minecraft:red_concrete
fill 213 179 424 215 179 424 minecraft:polished_deepslate
setblock 213 179 427 minecraft:red_concrete
fill 213 179 428 215 179 428 minecraft:polished_deepslate
setblock 213 179 431 minecraft:red_concrete
fill 213 179 432 214 179 433 minecraft:polished_deepslate
fill 213 179 434 213 179 438 minecraft:redstone_block
setblock 213 179 439 minecraft:red_concrete
fill 213 179 440 215 179 440 minecraft:polished_deepslate
setblock 213 179 443 minecraft:red_concrete
fill 213 179 444 215 179 444 minecraft:polished_deepslate
setblock 213 179 447 minecraft:red_concrete
fill 213 179 448 215 179 448 minecraft:polished_deepslate
setblock 213 179 451 minecraft:red_concrete
fill 213 179 452 215 179 452 minecraft:polished_deepslate
setblock 213 179 455 minecraft:red_concrete
fill 213 179 456 215 179 456 minecraft:polished_deepslate
setblock 214 179 417 minecraft:polished_deepslate
setblock 214 179 418 minecraft:red_concrete
fill 214 179 419 216 179 419 minecraft:polished_deepslate
setblock 214 179 422 minecraft:red_concrete
fill 214 179 423 216 179 423 minecraft:polished_deepslate
setblock 214 179 426 minecraft:red_concrete
fill 214 179 427 216 179 427 minecraft:polished_deepslate
setblock 214 179 430 minecraft:red_concrete
fill 214 179 431 216 179 431 minecraft:polished_deepslate
setblock 214 179 434 minecraft:red_concrete
fill 214 179 435 214 179 437 minecraft:polished_deepslate
setblock 214 179 438 minecraft:red_concrete
fill 214 179 439 216 179 439 minecraft:polished_deepslate
setblock 214 179 442 minecraft:red_concrete
fill 214 179 443 216 179 443 minecraft:polished_deepslate
setblock 214 179 446 minecraft:red_concrete
fill 214 179 447 216 179 447 minecraft:polished_deepslate
setblock 214 179 450 minecraft:red_concrete
fill 214 179 451 216 179 451 minecraft:polished_deepslate
setblock 214 179 454 minecraft:red_concrete
fill 214 179 455 216 179 455 minecraft:polished_deepslate
setblock 215 179 417 minecraft:red_concrete
fill 215 179 418 217 179 418 minecraft:polished_deepslate
setblock 215 179 421 minecraft:red_concrete
fill 215 179 422 217 179 422 minecraft:polished_deepslate
setblock 215 179 425 minecraft:red_concrete
fill 215 179 426 217 179 426 minecraft:polished_deepslate
setblock 215 179 429 minecraft:red_concrete
fill 215 179 430 217 179 430 minecraft:polished_deepslate
setblock 215 179 432 minecraft:polished_deepslate
setblock 215 179 433 minecraft:red_concrete
fill 215 179 434 215 179 436 minecraft:polished_deepslate
setblock 215 179 437 minecraft:red_concrete
fill 215 179 438 217 179 438 minecraft:polished_deepslate
setblock 215 179 441 minecraft:red_concrete
fill 215 179 442 217 179 442 minecraft:polished_deepslate
setblock 215 179 445 minecraft:red_concrete
fill 215 179 446 217 179 446 minecraft:polished_deepslate
setblock 215 179 449 minecraft:red_concrete
fill 215 179 450 217 179 450 minecraft:polished_deepslate
setblock 215 179 453 minecraft:red_concrete
fill 215 179 454 217 179 454 minecraft:polished_deepslate
setblock 215 179 457 minecraft:red_concrete
fill 216 179 417 218 179 417 minecraft:polished_deepslate
setblock 216 179 420 minecraft:red_concrete
fill 216 179 421 218 179 421 minecraft:polished_deepslate
setblock 216 179 424 minecraft:red_concrete
fill 216 179 425 218 179 425 minecraft:polished_deepslate
setblock 216 179 428 minecraft:red_concrete
fill 216 179 429 218 179 429 minecraft:polished_deepslate
setblock 216 179 432 minecraft:red_concrete
fill 216 179 433 216 179 435 minecraft:polished_deepslate
setblock 216 179 436 minecraft:red_concrete
fill 216 179 437 218 179 437 minecraft:polished_deepslate
setblock 216 179 440 minecraft:red_concrete
fill 216 179 441 218 179 441 minecraft:polished_deepslate
setblock 216 179 444 minecraft:red_concrete
fill 216 179 445 218 179 445 minecraft:polished_deepslate
setblock 216 179 448 minecraft:red_concrete
fill 216 179 449 218 179 449 minecraft:polished_deepslate
setblock 216 179 452 minecraft:red_concrete
fill 216 179 453 218 179 453 minecraft:polished_deepslate
setblock 216 179 456 minecraft:red_concrete
fill 216 179 457 218 179 457 minecraft:polished_deepslate
setblock 217 179 419 minecraft:red_concrete
fill 217 179 420 219 179 420 minecraft:polished_deepslate
setblock 217 179 423 minecraft:red_concrete
fill 217 179 424 219 179 424 minecraft:polished_deepslate
setblock 217 179 427 minecraft:red_concrete
fill 217 179 428 219 179 428 minecraft:polished_deepslate
setblock 217 179 431 minecraft:red_concrete
fill 217 179 432 217 179 434 minecraft:polished_deepslate
setblock 217 179 435 minecraft:red_concrete
fill 217 179 436 219 179 436 minecraft:polished_deepslate
setblock 217 179 439 minecraft:red_concrete
fill 217 179 440 219 179 440 minecraft:polished_deepslate
setblock 217 179 443 minecraft:red_concrete
fill 217 179 444 219 179 444 minecraft:polished_deepslate
setblock 217 179 447 minecraft:red_concrete
fill 217 179 448 219 179 448 minecraft:polished_deepslate
setblock 217 179 451 minecraft:red_concrete
fill 217 179 452 219 179 452 minecraft:polished_deepslate
setblock 217 179 455 minecraft:red_concrete
fill 217 179 456 219 179 456 minecraft:polished_deepslate
setblock 218 179 418 minecraft:red_concrete
fill 218 179 419 220 179 419 minecraft:polished_deepslate
setblock 218 179 422 minecraft:red_concrete
fill 218 179 423 220 179 423 minecraft:polished_deepslate
setblock 218 179 426 minecraft:red_concrete
fill 218 179 427 220 179 427 minecraft:polished_deepslate
setblock 218 179 430 minecraft:red_concrete
fill 218 179 431 218 179 433 minecraft:polished_deepslate
setblock 218 179 434 minecraft:red_concrete
fill 218 179 435 220 179 435 minecraft:polished_deepslate
setblock 218 179 438 minecraft:red_concrete
fill 218 179 439 220 179 439 minecraft:polished_deepslate
setblock 218 179 442 minecraft:red_concrete
fill 218 179 443 220 179 443 minecraft:polished_deepslate
setblock 218 179 446 minecraft:red_concrete
fill 218 179 447 220 179 447 minecraft:polished_deepslate
setblock 218 179 450 minecraft:red_concrete
fill 218 179 451 220 179 451 minecraft:polished_deepslate
setblock 218 179 454 minecraft:red_concrete
fill 218 179 455 220 179 455 minecraft:polished_deepslate
setblock 219 179 417 minecraft:red_concrete
fill 219 179 418 221 179 418 minecraft:polished_deepslate
setblock 219 179 421 minecraft:red_concrete
fill 219 179 422 221 179 422 minecraft:polished_deepslate
setblock 219 179 425 minecraft:red_concrete
fill 219 179 426 221 179 426 minecraft:polished_deepslate
setblock 219 179 429 minecraft:red_concrete
fill 219 179 430 219 179 432 minecraft:polished_deepslate
setblock 219 179 433 minecraft:red_concrete
fill 219 179 434 221 179 434 minecraft:polished_deepslate
setblock 219 179 437 minecraft:red_concrete
fill 219 179 438 221 179 438 minecraft:polished_deepslate
setblock 219 179 441 minecraft:red_concrete
fill 219 179 442 221 179 442 minecraft:polished_deepslate
setblock 219 179 445 minecraft:red_concrete
fill 219 179 446 221 179 446 minecraft:polished_deepslate
setblock 219 179 449 minecraft:red_concrete
fill 219 179 450 221 179 450 minecraft:polished_deepslate
setblock 219 179 453 minecraft:red_concrete
fill 219 179 454 221 179 454 minecraft:polished_deepslate
setblock 219 179 457 minecraft:red_concrete
fill 220 179 417 222 179 417 minecraft:polished_deepslate
setblock 220 179 420 minecraft:red_concrete
fill 220 179 421 222 179 421 minecraft:polished_deepslate
setblock 220 179 424 minecraft:red_concrete
fill 220 179 425 222 179 425 minecraft:polished_deepslate
setblock 220 179 428 minecraft:red_concrete
fill 220 179 429 220 179 431 minecraft:polished_deepslate
setblock 220 179 432 minecraft:red_concrete
fill 220 179 433 222 179 433 minecraft:polished_deepslate
setblock 220 179 436 minecraft:red_concrete
fill 220 179 437 222 179 437 minecraft:polished_deepslate
setblock 220 179 440 minecraft:red_concrete
fill 220 179 441 222 179 441 minecraft:polished_deepslate
setblock 220 179 444 minecraft:red_concrete
fill 220 179 445 222 179 445 minecraft:polished_deepslate
setblock 220 179 448 minecraft:red_concrete
fill 220 179 449 222 179 449 minecraft:polished_deepslate
setblock 220 179 452 minecraft:red_concrete
fill 220 179 453 222 179 453 minecraft:polished_deepslate
setblock 220 179 456 minecraft:red_concrete
fill 220 179 457 222 179 457 minecraft:polished_deepslate
setblock 221 179 419 minecraft:red_concrete
fill 221 179 420 223 179 420 minecraft:polished_deepslate
setblock 221 179 423 minecraft:red_concrete
fill 221 179 424 223 179 424 minecraft:polished_deepslate
setblock 221 179 427 minecraft:red_concrete
fill 221 179 428 221 179 430 minecraft:polished_deepslate
setblock 221 179 431 minecraft:red_concrete
fill 221 179 432 223 179 432 minecraft:polished_deepslate
setblock 221 179 435 minecraft:red_concrete
fill 221 179 436 223 179 436 minecraft:polished_deepslate
setblock 221 179 439 minecraft:red_concrete
fill 221 179 440 223 179 440 minecraft:polished_deepslate
setblock 221 179 443 minecraft:red_concrete
fill 221 179 444 223 179 444 minecraft:polished_deepslate
setblock 221 179 447 minecraft:red_concrete
fill 221 179 448 223 179 448 minecraft:polished_deepslate
setblock 221 179 451 minecraft:red_concrete
fill 221 179 452 223 179 452 minecraft:polished_deepslate
setblock 221 179 455 minecraft:red_concrete
fill 221 179 456 223 179 456 minecraft:polished_deepslate
setblock 222 179 418 minecraft:red_concrete
fill 222 179 419 224 179 419 minecraft:polished_deepslate
setblock 222 179 422 minecraft:red_concrete
fill 222 179 423 224 179 423 minecraft:polished_deepslate
setblock 222 179 426 minecraft:red_concrete
fill 222 179 427 222 179 429 minecraft:polished_deepslate
setblock 222 179 430 minecraft:red_concrete
fill 222 179 431 224 179 431 minecraft:polished_deepslate
setblock 222 179 434 minecraft:red_concrete
fill 222 179 435 224 179 435 minecraft:polished_deepslate
setblock 222 179 438 minecraft:red_concrete
fill 222 179 439 224 179 439 minecraft:polished_deepslate
setblock 222 179 442 minecraft:red_concrete
fill 222 179 443 224 179 443 minecraft:polished_deepslate
setblock 222 179 446 minecraft:red_concrete
fill 222 179 447 224 179 447 minecraft:polished_deepslate
setblock 222 179 450 minecraft:red_concrete
fill 222 179 451 224 179 451 minecraft:polished_deepslate
setblock 222 179 454 minecraft:red_concrete
fill 222 179 455 224 179 455 minecraft:polished_deepslate
setblock 223 179 417 minecraft:red_concrete
fill 223 179 418 225 179 418 minecraft:polished_deepslate
setblock 223 179 421 minecraft:red_concrete
fill 223 179 422 225 179 422 minecraft:polished_deepslate
setblock 223 179 425 minecraft:red_concrete
fill 223 179 426 223 179 428 minecraft:polished_deepslate
setblock 223 179 429 minecraft:red_concrete
fill 223 179 430 225 179 430 minecraft:polished_deepslate
setblock 223 179 433 minecraft:red_concrete
fill 223 179 434 225 179 434 minecraft:polished_deepslate
setblock 223 179 437 minecraft:red_concrete
fill 223 179 438 225 179 438 minecraft:polished_deepslate
setblock 223 179 441 minecraft:red_concrete
fill 223 179 442 225 179 442 minecraft:polished_deepslate
setblock 223 179 445 minecraft:red_concrete
fill 223 179 446 225 179 446 minecraft:polished_deepslate
setblock 223 179 449 minecraft:red_concrete
fill 223 179 450 225 179 450 minecraft:polished_deepslate
setblock 223 179 453 minecraft:red_concrete
fill 223 179 454 225 179 454 minecraft:polished_deepslate
setblock 223 179 457 minecraft:red_concrete
fill 224 179 417 226 179 417 minecraft:polished_deepslate
setblock 224 179 420 minecraft:red_concrete
fill 224 179 421 226 179 421 minecraft:polished_deepslate
setblock 224 179 424 minecraft:red_concrete
fill 224 179 425 224 179 427 minecraft:polished_deepslate
setblock 224 179 428 minecraft:red_concrete
fill 224 179 429 226 179 429 minecraft:polished_deepslate
setblock 224 179 432 minecraft:red_concrete
fill 224 179 433 226 179 433 minecraft:polished_deepslate
setblock 224 179 436 minecraft:red_concrete
fill 224 179 437 226 179 437 minecraft:polished_deepslate
setblock 224 179 440 minecraft:red_concrete
fill 224 179 441 226 179 441 minecraft:polished_deepslate
setblock 224 179 444 minecraft:red_concrete
fill 224 179 445 226 179 445 minecraft:polished_deepslate
setblock 224 179 448 minecraft:red_concrete
fill 224 179 449 226 179 449 minecraft:polished_deepslate
setblock 224 179 452 minecraft:red_concrete
fill 224 179 453 226 179 453 minecraft:polished_deepslate
setblock 224 179 456 minecraft:red_concrete
fill 224 179 457 226 179 457 minecraft:polished_deepslate
setblock 225 179 419 minecraft:red_concrete
fill 225 179 420 227 179 420 minecraft:polished_deepslate
setblock 225 179 423 minecraft:red_concrete
fill 225 179 424 225 179 426 minecraft:polished_deepslate
setblock 225 179 427 minecraft:red_concrete
fill 225 179 428 227 179 428 minecraft:polished_deepslate
setblock 225 179 431 minecraft:red_concrete
fill 225 179 432 227 179 432 minecraft:polished_deepslate
setblock 225 179 435 minecraft:red_concrete
fill 225 179 436 227 179 436 minecraft:polished_deepslate
setblock 225 179 439 minecraft:red_concrete
fill 225 179 440 227 179 440 minecraft:polished_deepslate
setblock 225 179 443 minecraft:red_concrete
fill 225 179 444 227 179 444 minecraft:polished_deepslate
setblock 225 179 447 minecraft:red_concrete
fill 225 179 448 227 179 448 minecraft:polished_deepslate
setblock 225 179 451 minecraft:red_concrete
fill 225 179 452 227 179 452 minecraft:polished_deepslate
setblock 225 179 455 minecraft:red_concrete
fill 225 179 456 227 179 456 minecraft:polished_deepslate
setblock 226 179 418 minecraft:red_concrete
fill 226 179 419 228 179 419 minecraft:polished_deepslate
setblock 226 179 422 minecraft:red_concrete
fill 226 179 423 226 179 425 minecraft:polished_deepslate
setblock 226 179 426 minecraft:red_concrete
fill 226 179 427 228 179 427 minecraft:polished_deepslate
setblock 226 179 430 minecraft:red_concrete
fill 226 179 431 228 179 431 minecraft:polished_deepslate
setblock 226 179 434 minecraft:red_concrete
fill 226 179 435 228 179 435 minecraft:polished_deepslate
setblock 226 179 438 minecraft:red_concrete
fill 226 179 439 228 179 439 minecraft:polished_deepslate
setblock 226 179 442 minecraft:red_concrete
fill 226 179 443 228 179 443 minecraft:polished_deepslate
setblock 226 179 446 minecraft:red_concrete
fill 226 179 447 228 179 447 minecraft:polished_deepslate
setblock 226 179 450 minecraft:red_concrete
fill 226 179 451 228 179 451 minecraft:polished_deepslate
setblock 226 179 454 minecraft:red_concrete
fill 226 179 455 228 179 455 minecraft:polished_deepslate
setblock 227 179 417 minecraft:red_concrete
fill 227 179 418 229 179 418 minecraft:polished_deepslate
setblock 227 179 421 minecraft:red_concrete
fill 227 179 422 227 179 424 minecraft:polished_deepslate
setblock 227 179 425 minecraft:red_concrete
fill 227 179 426 229 179 426 minecraft:polished_deepslate
setblock 227 179 429 minecraft:red_concrete
fill 227 179 430 229 179 430 minecraft:polished_deepslate
setblock 227 179 433 minecraft:red_concrete
fill 227 179 434 229 179 434 minecraft:polished_deepslate
setblock 227 179 437 minecraft:red_concrete
fill 227 179 438 229 179 438 minecraft:polished_deepslate
setblock 227 179 441 minecraft:red_concrete
fill 227 179 442 229 179 442 minecraft:polished_deepslate
setblock 227 179 445 minecraft:red_concrete
fill 227 179 446 229 179 446 minecraft:polished_deepslate
setblock 227 179 449 minecraft:red_concrete
fill 227 179 450 229 179 450 minecraft:polished_deepslate
setblock 227 179 453 minecraft:red_concrete
fill 227 179 454 229 179 454 minecraft:polished_deepslate
setblock 227 179 457 minecraft:red_concrete
fill 228 179 417 229 179 417 minecraft:polished_deepslate
setblock 228 179 420 minecraft:red_concrete
fill 228 179 421 228 179 423 minecraft:polished_deepslate
setblock 228 179 424 minecraft:red_concrete
fill 228 179 425 229 179 425 minecraft:polished_deepslate
setblock 228 179 428 minecraft:red_concrete
fill 228 179 429 229 179 429 minecraft:polished_deepslate
setblock 228 179 432 minecraft:red_concrete
fill 228 179 433 229 179 433 minecraft:polished_deepslate
setblock 228 179 436 minecraft:red_concrete
fill 228 179 437 229 179 437 minecraft:polished_deepslate
setblock 228 179 440 minecraft:red_concrete
fill 228 179 441 229 179 441 minecraft:polished_deepslate
setblock 228 179 444 minecraft:red_concrete
fill 228 179 445 229 179 445 minecraft:polished_deepslate
setblock 228 179 448 minecraft:red_concrete
fill 228 179 449 229 179 449 minecraft:polished_deepslate
setblock 228 179 452 minecraft:red_concrete
fill 228 179 453 229 179 453 minecraft:polished_deepslate
setblock 228 179 456 minecraft:red_concrete
fill 228 179 457 229 179 457 minecraft:polished_deepslate
setblock 229 179 419 minecraft:red_concrete
fill 229 179 420 229 179 422 minecraft:polished_deepslate
setblock 229 179 423 minecraft:red_concrete
setblock 229 179 424 minecraft:polished_deepslate
setblock 229 179 427 minecraft:red_concrete
setblock 229 179 428 minecraft:polished_deepslate
setblock 229 179 431 minecraft:red_concrete
setblock 229 179 432 minecraft:polished_deepslate
setblock 229 179 435 minecraft:red_concrete
setblock 229 179 436 minecraft:polished_deepslate
setblock 229 179 439 minecraft:red_concrete
setblock 229 179 440 minecraft:polished_deepslate
setblock 229 179 443 minecraft:red_concrete
setblock 229 179 444 minecraft:polished_deepslate
setblock 229 179 447 minecraft:red_concrete
setblock 229 179 448 minecraft:polished_deepslate
setblock 229 179 451 minecraft:red_concrete
setblock 229 179 452 minecraft:polished_deepslate
setblock 229 179 455 minecraft:red_concrete
setblock 229 179 456 minecraft:polished_deepslate
fill 202 180 434 202 180 438 minecraft:redstone_block
fill 203 180 432 203 180 433 minecraft:redstone_block
fill 203 180 437 203 180 438 minecraft:red_concrete
fill 203 180 439 203 180 440 minecraft:redstone_block
setblock 204 180 432 minecraft:redstone_block
fill 204 180 438 207 180 438 minecraft:red_concrete
setblock 204 180 440 minecraft:redstone_block
fill 205 180 431 209 180 431 minecraft:redstone_block
fill 205 180 432 207 180 432 minecraft:red_concrete
fill 205 180 441 209 180 441 minecraft:redstone_block
fill 207 180 433 208 180 433 minecraft:red_concrete
fill 207 180 437 208 181 437 minecraft:red_concrete
fill 208 180 434 208 181 436 minecraft:red_concrete
fill 210 180 432 211 180 432 minecraft:redstone_block
fill 210 180 440 211 180 440 minecraft:redstone_block
setblock 211 180 433 minecraft:redstone_block
setblock 211 180 439 minecraft:redstone_block
fill 212 180 434 212 180 438 minecraft:redstone_block
fill 203 181 437 203 181 438 minecraft:redstone_block
fill 204 181 438 205 181 439 minecraft:redstone_block
fill 205 181 432 209 181 432 minecraft:redstone_block
fill 205 181 440 209 181 440 minecraft:redstone_block
fill 206 181 438 207 181 438 minecraft:red_concrete
fill 206 181 439 210 181 439 minecraft:redstone_block
fill 207 181 433 210 181 433 minecraft:redstone_block
fill 209 181 434 211 181 434 minecraft:redstone_block
fill 209 181 435 209 181 437 minecraft:red_concrete
fill 209 181 438 211 181 438 minecraft:redstone_block
fill 210 181 435 211 181 437 minecraft:redstone_block
setblock 191 182 419 minecraft:light[level=13]
setblock 191 182 427 minecraft:light[level=13]
setblock 191 182 435 minecraft:light[level=13]
setblock 191 182 443 minecraft:light[level=13]
setblock 191 182 451 minecraft:light[level=13]
setblock 199 182 419 minecraft:light[level=13]
setblock 199 182 427 minecraft:light[level=13]
setblock 199 182 435 minecraft:light[level=13]
setblock 199 182 443 minecraft:light[level=13]
setblock 199 182 451 minecraft:light[level=13]
fill 205 182 437 209 182 437 minecraft:redstone_block
fill 206 182 434 208 182 434 minecraft:redstone_block
fill 206 182 438 208 182 438 minecraft:redstone_block
setblock 207 182 419 minecraft:light[level=13]
setblock 207 182 427 minecraft:light[level=13]
setblock 207 182 443 minecraft:light[level=13]
setblock 207 182 451 minecraft:light[level=13]
fill 208 182 435 209 182 436 minecraft:redstone_block
setblock 215 182 419 minecraft:light[level=13]
setblock 215 182 427 minecraft:light[level=13]
setblock 215 182 435 minecraft:light[level=13]
setblock 215 182 443 minecraft:light[level=13]
setblock 215 182 451 minecraft:light[level=13]
setblock 223 182 419 minecraft:light[level=13]
setblock 223 182 427 minecraft:light[level=13]
setblock 223 182 435 minecraft:light[level=13]
setblock 223 182 443 minecraft:light[level=13]
setblock 223 182 451 minecraft:light[level=13]
fill 189 183 417 191 226 417 minecraft:polished_deepslate
fill 189 183 427 189 226 429 minecraft:polished_deepslate
fill 189 183 436 194 184 441 minecraft:polished_deepslate
fill 189 183 451 189 226 453 minecraft:polished_deepslate
fill 190 183 426 190 185 428 minecraft:polished_deepslate
fill 190 183 435 193 214 435 minecraft:polished_deepslate
fill 190 183 442 193 188 442 minecraft:polished_deepslate
fill 190 183 450 190 185 452 minecraft:polished_deepslate
fill 192 183 450 192 205 450 minecraft:iron_block
fill 195 183 437 195 201 440 minecraft:polished_deepslate
fill 195 183 457 197 226 457 minecraft:polished_deepslate
fill 196 183 456 198 185 456 minecraft:polished_deepslate
schedule function dropper:buildpart/100_2 1t
