setblock 416 138 316 minecraft:stripped_oak_log
fill 417 138 276 417 141 276 minecraft:red_terracotta
setblock 417 138 280 minecraft:stripped_oak_log
fill 417 138 281 417 141 281 minecraft:red_terracotta
setblock 417 138 285 minecraft:stripped_oak_log
fill 417 138 286 417 141 286 minecraft:red_terracotta
setblock 417 138 290 minecraft:stripped_oak_log
fill 417 138 291 417 141 291 minecraft:red_terracotta
setblock 417 138 295 minecraft:stripped_oak_log
fill 417 138 296 417 141 296 minecraft:red_terracotta
setblock 417 138 299 minecraft:red_terracotta
setblock 417 138 310 minecraft:stripped_oak_log
fill 417 138 311 417 141 311 minecraft:red_terracotta
setblock 417 138 315 minecraft:stripped_oak_log
fill 417 138 316 417 141 316 minecraft:red_terracotta
setblock 377 139 279 minecraft:stripped_oak_log
fill 377 139 280 377 142 280 minecraft:red_terracotta
setblock 377 139 284 minecraft:stripped_oak_log
setblock 377 139 285 minecraft:red_terracotta
setblock 377 139 289 minecraft:stripped_oak_log
fill 377 139 290 377 141 290 minecraft:red_terracotta
setblock 377 139 294 minecraft:stripped_oak_log
fill 377 139 295 377 142 295 minecraft:red_terracotta
setblock 377 139 299 minecraft:stripped_oak_log
fill 377 139 300 377 142 300 minecraft:red_terracotta
setblock 377 139 304 minecraft:stripped_oak_log
fill 377 139 305 377 141 305 minecraft:red_terracotta
setblock 377 139 309 minecraft:stripped_oak_log
fill 377 139 310 377 142 310 minecraft:red_terracotta
setblock 377 139 314 minecraft:stripped_oak_log
fill 377 139 315 377 142 315 minecraft:red_terracotta
setblock 378 139 293 minecraft:stripped_oak_log
setblock 378 139 308 minecraft:stripped_oak_log
fill 378 139 309 378 141 309 minecraft:red_terracotta
setblock 378 139 313 minecraft:stripped_oak_log
fill 378 139 314 378 142 314 minecraft:red_terracotta
setblock 379 139 312 minecraft:stripped_oak_log
fill 379 139 313 379 141 313 minecraft:red_terracotta
setblock 380 139 276 minecraft:stripped_oak_log
setblock 380 139 316 minecraft:stripped_oak_log
fill 381 139 276 383 140 276 minecraft:red_terracotta
setblock 381 139 315 minecraft:stripped_oak_log
fill 381 139 316 384 139 316 minecraft:red_terracotta
setblock 382 139 314 minecraft:stripped_oak_log
fill 382 139 315 385 139 315 minecraft:red_terracotta
fill 383 139 314 386 139 314 minecraft:red_terracotta
setblock 385 139 316 minecraft:stripped_oak_log
fill 386 139 276 389 139 276 minecraft:red_terracotta
setblock 386 139 315 minecraft:stripped_oak_log
fill 386 139 316 386 142 316 minecraft:red_terracotta
setblock 387 139 314 minecraft:stripped_oak_log
fill 387 139 315 387 142 315 minecraft:red_terracotta
fill 388 139 314 391 139 314 minecraft:red_terracotta
fill 389 139 313 392 139 313 minecraft:red_terracotta
setblock 390 139 276 minecraft:stripped_oak_log
setblock 390 139 316 minecraft:stripped_oak_log
fill 391 139 276 394 139 276 minecraft:red_terracotta
setblock 391 139 315 minecraft:stripped_oak_log
fill 391 139 316 391 142 316 minecraft:red_terracotta
setblock 392 139 314 minecraft:stripped_oak_log
fill 392 139 315 392 142 315 minecraft:red_terracotta
setblock 393 139 313 minecraft:stripped_oak_log
fill 393 139 314 393 142 314 minecraft:red_terracotta
setblock 394 139 313 minecraft:red_terracotta
setblock 395 139 276 minecraft:stripped_oak_log
setblock 395 139 316 minecraft:stripped_oak_log
fill 396 139 276 396 142 276 minecraft:red_terracotta
setblock 396 139 315 minecraft:stripped_oak_log
fill 396 139 316 396 142 316 minecraft:red_terracotta
fill 397 139 315 397 142 315 minecraft:red_terracotta
fill 398 139 276 398 140 276 minecraft:red_terracotta
setblock 400 139 316 minecraft:stripped_oak_log
fill 401 139 316 401 141 316 minecraft:red_terracotta
fill 406 139 276 406 142 276 minecraft:red_terracotta
fill 406 139 316 409 139 316 minecraft:red_terracotta
setblock 408 139 277 minecraft:red_terracotta
fill 408 139 315 410 139 315 minecraft:red_terracotta
setblock 409 139 276 minecraft:red_terracotta
setblock 409 139 277 minecraft:stripped_oak_log
setblock 410 139 276 minecraft:stripped_oak_log
fill 410 139 277 410 142 277 minecraft:red_terracotta
setblock 410 139 316 minecraft:stripped_oak_log
fill 411 139 276 411 142 276 minecraft:red_terracotta
fill 411 139 278 412 139 278 minecraft:red_terracotta
setblock 411 139 314 minecraft:red_terracotta
setblock 411 139 315 minecraft:stripped_oak_log
fill 411 139 316 411 142 316 minecraft:red_terracotta
setblock 412 139 314 minecraft:stripped_oak_log
fill 412 139 315 412 142 315 minecraft:red_terracotta
setblock 413 139 277 minecraft:red_terracotta
setblock 413 139 278 minecraft:stripped_oak_log
fill 413 139 314 413 142 314 minecraft:red_terracotta
setblock 414 139 277 minecraft:stripped_oak_log
fill 414 139 278 414 142 278 minecraft:red_terracotta
setblock 414 139 288 minecraft:red_terracotta
setblock 414 139 292 minecraft:stripped_oak_log
fill 414 139 293 414 140 293 minecraft:red_terracotta
setblock 415 139 276 minecraft:stripped_oak_log
fill 415 139 277 415 142 277 minecraft:red_terracotta
setblock 415 139 280 minecraft:red_terracotta
setblock 415 139 281 minecraft:stripped_oak_log
setblock 415 139 286 minecraft:stripped_oak_log
fill 415 139 287 415 140 287 minecraft:red_terracotta
setblock 415 139 291 minecraft:stripped_oak_log
fill 415 139 292 415 142 292 minecraft:red_terracotta
setblock 415 139 296 minecraft:stripped_oak_log
fill 415 139 312 415 140 312 minecraft:red_terracotta
setblock 415 139 316 minecraft:stripped_oak_log
fill 416 139 276 416 142 276 minecraft:red_terracotta
setblock 416 139 280 minecraft:stripped_oak_log
fill 416 139 281 416 142 281 minecraft:red_terracotta
setblock 416 139 285 minecraft:stripped_oak_log
fill 416 139 286 416 141 286 minecraft:red_terracotta
setblock 416 139 290 minecraft:stripped_oak_log
fill 416 139 291 416 142 291 minecraft:red_terracotta
setblock 416 139 295 minecraft:stripped_oak_log
fill 416 139 296 416 142 296 minecraft:red_terracotta
setblock 416 139 310 minecraft:stripped_oak_log
fill 416 139 311 416 142 311 minecraft:red_terracotta
setblock 416 139 315 minecraft:stripped_oak_log
fill 416 139 316 416 142 316 minecraft:red_terracotta
setblock 417 139 279 minecraft:stripped_oak_log
fill 417 139 280 417 142 280 minecraft:red_terracotta
setblock 417 139 284 minecraft:stripped_oak_log
fill 417 139 285 417 142 285 minecraft:red_terracotta
setblock 417 139 289 minecraft:stripped_oak_log
fill 417 139 290 417 142 290 minecraft:red_terracotta
setblock 417 139 294 minecraft:stripped_oak_log
fill 417 139 295 417 142 295 minecraft:red_terracotta
setblock 417 139 299 minecraft:stripped_oak_log
setblock 417 139 309 minecraft:stripped_oak_log
fill 417 139 310 417 142 310 minecraft:red_terracotta
setblock 417 139 314 minecraft:stripped_oak_log
fill 417 139 315 417 142 315 minecraft:red_terracotta
fill 376 140 275 376 143 317 minecraft:orange_terracotta
fill 377 140 275 418 143 275 minecraft:orange_terracotta
setblock 377 140 277 minecraft:red_terracotta
setblock 377 140 278 minecraft:stripped_oak_log
fill 377 140 279 377 143 279 minecraft:red_terracotta
setblock 377 140 288 minecraft:stripped_oak_log
fill 377 140 289 377 141 289 minecraft:red_terracotta
setblock 377 140 293 minecraft:stripped_oak_log
fill 377 140 294 377 143 294 minecraft:red_terracotta
setblock 377 140 298 minecraft:stripped_oak_log
fill 377 140 299 377 143 299 minecraft:red_terracotta
fill 377 140 301 377 141 301 minecraft:red_terracotta
setblock 377 140 304 minecraft:red_terracotta
setblock 377 140 308 minecraft:stripped_oak_log
fill 377 140 309 377 143 309 minecraft:red_terracotta
setblock 377 140 313 minecraft:stripped_oak_log
fill 377 140 314 377 143 314 minecraft:red_terracotta
fill 377 140 317 418 143 317 minecraft:orange_terracotta
setblock 378 140 277 minecraft:stripped_oak_log
setblock 378 140 312 minecraft:stripped_oak_log
fill 378 140 313 378 143 313 minecraft:red_terracotta
setblock 379 140 276 minecraft:stripped_oak_log
fill 379 140 312 379 141 312 minecraft:red_terracotta
setblock 379 140 316 minecraft:stripped_oak_log
fill 380 140 276 380 143 276 minecraft:red_terracotta
setblock 380 140 314 minecraft:red_terracotta
setblock 380 140 315 minecraft:stripped_oak_log
fill 380 140 316 383 140 316 minecraft:red_terracotta
setblock 381 140 314 minecraft:stripped_oak_log
fill 381 140 315 384 140 315 minecraft:red_terracotta
fill 382 140 314 385 140 314 minecraft:red_terracotta
setblock 384 140 276 minecraft:stripped_oak_log
setblock 384 140 316 minecraft:stripped_oak_log
fill 385 140 276 388 140 276 minecraft:red_terracotta
setblock 385 140 315 minecraft:stripped_oak_log
fill 385 140 316 385 143 316 minecraft:red_terracotta
setblock 386 140 314 minecraft:stripped_oak_log
fill 386 140 315 386 143 315 minecraft:red_terracotta
fill 387 140 314 390 140 314 minecraft:red_terracotta
setblock 389 140 276 minecraft:stripped_oak_log
fill 389 140 313 391 140 313 minecraft:red_terracotta
setblock 389 140 316 minecraft:stripped_oak_log
fill 390 140 276 393 140 276 minecraft:red_terracotta
setblock 390 140 315 minecraft:stripped_oak_log
fill 390 140 316 390 143 316 minecraft:red_terracotta
fill 391 140 277 392 140 277 minecraft:red_terracotta
setblock 391 140 314 minecraft:stripped_oak_log
fill 391 140 315 391 143 315 minecraft:red_terracotta
setblock 392 140 313 minecraft:stripped_oak_log
fill 392 140 314 392 143 314 minecraft:red_terracotta
setblock 393 140 313 minecraft:red_terracotta
setblock 394 140 276 minecraft:stripped_oak_log
fill 394 140 277 394 143 277 minecraft:red_terracotta
setblock 394 140 316 minecraft:stripped_oak_log
fill 395 140 276 395 143 276 minecraft:red_terracotta
setblock 395 140 277 minecraft:stripped_oak_log
setblock 395 140 315 minecraft:stripped_oak_log
fill 395 140 316 395 143 316 minecraft:red_terracotta
setblock 396 140 314 minecraft:stripped_oak_log
fill 396 140 315 396 142 315 minecraft:red_terracotta
setblock 399 140 276 minecraft:stripped_oak_log
setblock 399 140 316 minecraft:stripped_oak_log
fill 400 140 316 400 142 316 minecraft:red_terracotta
fill 402 140 316 402 141 316 minecraft:red_terracotta
setblock 404 140 276 minecraft:stripped_oak_log
setblock 404 140 316 minecraft:stripped_oak_log
fill 405 140 276 405 143 276 minecraft:red_terracotta
fill 405 140 316 408 140 316 minecraft:red_terracotta
setblock 407 140 277 minecraft:red_terracotta
setblock 408 140 277 minecraft:stripped_oak_log
fill 408 140 315 409 140 315 minecraft:red_terracotta
setblock 409 140 276 minecraft:stripped_oak_log
fill 409 140 277 409 143 277 minecraft:red_terracotta
setblock 409 140 316 minecraft:stripped_oak_log
fill 410 140 276 410 143 276 minecraft:red_terracotta
fill 410 140 278 411 140 278 minecraft:red_terracotta
setblock 410 140 314 minecraft:red_terracotta
setblock 410 140 315 minecraft:stripped_oak_log
fill 410 140 316 410 143 316 minecraft:red_terracotta
setblock 411 140 314 minecraft:stripped_oak_log
fill 411 140 315 411 143 315 minecraft:red_terracotta
setblock 412 140 278 minecraft:stripped_oak_log
fill 412 140 314 412 143 314 minecraft:red_terracotta
setblock 413 140 277 minecraft:stripped_oak_log
fill 413 140 278 413 143 278 minecraft:red_terracotta
setblock 414 140 276 minecraft:stripped_oak_log
fill 414 140 277 414 143 277 minecraft:red_terracotta
setblock 414 140 291 minecraft:stripped_oak_log
setblock 414 140 292 minecraft:red_terracotta
setblock 414 140 294 minecraft:red_terracotta
setblock 414 140 316 minecraft:stripped_oak_log
fill 415 140 276 415 143 276 minecraft:red_terracotta
setblock 415 140 280 minecraft:stripped_oak_log
fill 415 140 281 415 141 281 minecraft:red_terracotta
setblock 415 140 286 minecraft:red_terracotta
setblock 415 140 290 minecraft:stripped_oak_log
fill 415 140 291 415 141 291 minecraft:red_terracotta
setblock 415 140 295 minecraft:stripped_oak_log
fill 415 140 296 415 141 296 minecraft:red_terracotta
setblock 415 140 315 minecraft:stripped_oak_log
fill 415 140 316 415 143 316 minecraft:red_terracotta
setblock 416 140 279 minecraft:stripped_oak_log
fill 416 140 280 416 143 280 minecraft:red_terracotta
setblock 416 140 284 minecraft:stripped_oak_log
fill 416 140 285 416 141 285 minecraft:red_terracotta
setblock 416 140 289 minecraft:stripped_oak_log
fill 416 140 290 416 142 290 minecraft:red_terracotta
setblock 416 140 294 minecraft:stripped_oak_log
fill 416 140 295 416 143 295 minecraft:red_terracotta
setblock 416 140 298 minecraft:red_terracotta
setblock 416 140 310 minecraft:red_terracotta
setblock 416 140 314 minecraft:stripped_oak_log
fill 416 140 315 416 143 315 minecraft:red_terracotta
setblock 417 140 278 minecraft:stripped_oak_log
fill 417 140 279 417 143 279 minecraft:red_terracotta
setblock 417 140 283 minecraft:stripped_oak_log
fill 417 140 284 417 143 284 minecraft:red_terracotta
setblock 417 140 288 minecraft:stripped_oak_log
fill 417 140 289 417 143 289 minecraft:red_terracotta
setblock 417 140 293 minecraft:stripped_oak_log
fill 417 140 294 417 143 294 minecraft:red_terracotta
setblock 417 140 297 minecraft:red_terracotta
setblock 417 140 298 minecraft:stripped_oak_log
fill 417 140 299 417 141 300 minecraft:red_terracotta
setblock 417 140 308 minecraft:stripped_oak_log
fill 417 140 309 417 141 309 minecraft:red_terracotta
setblock 417 140 313 minecraft:stripped_oak_log
fill 417 140 314 417 143 314 minecraft:red_terracotta
fill 418 140 276 418 143 316 minecraft:orange_terracotta
setblock 377 141 277 minecraft:stripped_oak_log
fill 377 141 278 377 144 278 minecraft:red_terracotta
setblock 377 141 292 minecraft:stripped_oak_log
fill 377 141 293 377 143 293 minecraft:red_terracotta
setblock 377 141 297 minecraft:stripped_oak_log
fill 377 141 298 377 144 298 minecraft:red_terracotta
setblock 377 141 302 minecraft:stripped_oak_log
setblock 377 141 307 minecraft:stripped_oak_log
fill 377 141 308 377 143 308 minecraft:red_terracotta
setblock 377 141 312 minecraft:stripped_oak_log
fill 377 141 313 377 144 313 minecraft:red_terracotta
setblock 378 141 276 minecraft:stripped_oak_log
fill 378 141 277 378 143 277 minecraft:red_terracotta
setblock 378 141 311 minecraft:stripped_oak_log
fill 378 141 312 378 143 312 minecraft:red_terracotta
setblock 378 141 316 minecraft:stripped_oak_log
fill 379 141 276 379 144 276 minecraft:red_terracotta
setblock 379 141 315 minecraft:stripped_oak_log
fill 379 141 316 382 141 316 minecraft:red_terracotta
setblock 380 141 314 minecraft:stripped_oak_log
fill 380 141 315 383 141 315 minecraft:red_terracotta
fill 381 141 276 382 141 276 minecraft:red_terracotta
fill 381 141 314 384 141 314 minecraft:red_terracotta
setblock 383 141 276 minecraft:stripped_oak_log
setblock 383 141 316 minecraft:stripped_oak_log
fill 384 141 276 387 141 276 minecraft:red_terracotta
setblock 384 141 315 minecraft:stripped_oak_log
fill 384 141 316 384 144 316 minecraft:red_terracotta
setblock 385 141 314 minecraft:stripped_oak_log
fill 385 141 315 385 144 315 minecraft:red_terracotta
fill 386 141 314 389 141 314 minecraft:red_terracotta
setblock 388 141 276 minecraft:stripped_oak_log
setblock 388 141 316 minecraft:stripped_oak_log
fill 389 141 276 391 141 277 minecraft:red_terracotta
fill 389 141 313 390 141 313 minecraft:red_terracotta
setblock 389 141 315 minecraft:stripped_oak_log
fill 389 141 316 389 144 316 minecraft:red_terracotta
setblock 390 141 314 minecraft:stripped_oak_log
fill 390 141 315 390 144 315 minecraft:red_terracotta
setblock 391 141 313 minecraft:stripped_oak_log
fill 391 141 314 391 143 314 minecraft:red_terracotta
setblock 392 141 276 minecraft:red_terracotta
setblock 392 141 277 minecraft:stripped_oak_log
setblock 392 141 313 minecraft:red_terracotta
setblock 393 141 276 minecraft:stripped_oak_log
fill 393 141 277 393 144 277 minecraft:red_terracotta
setblock 393 141 316 minecraft:stripped_oak_log
fill 394 141 276 394 144 276 minecraft:red_terracotta
setblock 394 141 315 minecraft:stripped_oak_log
fill 394 141 316 394 144 316 minecraft:red_terracotta
fill 395 141 277 395 142 277 minecraft:red_terracotta
setblock 395 141 314 minecraft:stripped_oak_log
fill 395 141 315 395 143 315 minecraft:red_terracotta
setblock 398 141 276 minecraft:stripped_oak_log
setblock 398 141 316 minecraft:stripped_oak_log
fill 399 141 276 402 141 276 minecraft:red_terracotta
fill 399 141 316 399 142 316 minecraft:red_terracotta
setblock 403 141 276 minecraft:stripped_oak_log
setblock 403 141 316 minecraft:stripped_oak_log
fill 404 141 276 404 144 276 minecraft:red_terracotta
fill 404 141 316 407 141 316 minecraft:red_terracotta
setblock 406 141 277 minecraft:red_terracotta
fill 406 141 278 406 143 278 minecraft:brown_terracotta
setblock 407 141 276 minecraft:red_terracotta
setblock 407 141 277 minecraft:stripped_oak_log
fill 407 141 279 407 143 279 minecraft:brown_terracotta
fill 407 141 315 408 141 315 minecraft:red_terracotta
setblock 408 141 276 minecraft:stripped_oak_log
fill 408 141 277 408 144 277 minecraft:red_terracotta
setblock 408 141 278 minecraft:brown_terracotta
setblock 408 141 316 minecraft:stripped_oak_log
fill 409 141 276 409 144 276 minecraft:red_terracotta
fill 409 141 278 410 141 278 minecraft:red_terracotta
setblock 409 141 315 minecraft:stripped_oak_log
fill 409 141 316 409 144 316 minecraft:red_terracotta
setblock 410 141 314 minecraft:stripped_oak_log
fill 410 141 315 410 144 315 minecraft:red_terracotta
setblock 411 141 278 minecraft:stripped_oak_log
fill 411 141 314 411 143 314 minecraft:red_terracotta
setblock 412 141 277 minecraft:stripped_oak_log
fill 412 141 278 412 144 278 minecraft:red_terracotta
setblock 413 141 276 minecraft:stripped_oak_log
fill 413 141 277 413 144 277 minecraft:red_terracotta
setblock 413 141 316 minecraft:stripped_oak_log
fill 414 141 276 414 144 276 minecraft:red_terracotta
setblock 414 141 315 minecraft:stripped_oak_log
fill 414 141 316 414 144 316 minecraft:red_terracotta
setblock 415 141 278 minecraft:red_terracotta
setblock 415 141 279 minecraft:stripped_oak_log
fill 415 141 280 415 143 280 minecraft:red_terracotta
setblock 415 141 289 minecraft:stripped_oak_log
setblock 415 141 290 minecraft:red_terracotta
setblock 415 141 294 minecraft:stripped_oak_log
fill 415 141 295 415 142 295 minecraft:red_terracotta
setblock 415 141 314 minecraft:stripped_oak_log
fill 415 141 315 415 144 315 minecraft:red_terracotta
setblock 416 141 278 minecraft:stripped_oak_log
fill 416 141 279 416 144 279 minecraft:red_terracotta
setblock 416 141 283 minecraft:stripped_oak_log
setblock 416 141 284 minecraft:red_terracotta
setblock 416 141 288 minecraft:stripped_oak_log
fill 416 141 289 416 142 289 minecraft:red_terracotta
setblock 416 141 293 minecraft:stripped_oak_log
fill 416 141 294 416 143 294 minecraft:red_terracotta
setblock 416 141 298 minecraft:stripped_oak_log
setblock 416 141 313 minecraft:stripped_oak_log
fill 416 141 314 416 144 314 minecraft:red_terracotta
setblock 417 141 277 minecraft:stripped_oak_log
fill 417 141 278 417 144 278 minecraft:red_terracotta
setblock 417 141 282 minecraft:stripped_oak_log
fill 417 141 283 417 143 283 minecraft:red_terracotta
setblock 417 141 287 minecraft:stripped_oak_log
fill 417 141 288 417 142 288 minecraft:red_terracotta
setblock 417 141 292 minecraft:stripped_oak_log
fill 417 141 293 417 144 293 minecraft:red_terracotta
setblock 417 141 297 minecraft:stripped_oak_log
fill 417 141 298 417 144 298 minecraft:red_terracotta
setblock 417 141 312 minecraft:stripped_oak_log
fill 417 141 313 417 144 313 minecraft:red_terracotta
setblock 377 142 276 minecraft:stripped_oak_log
fill 377 142 277 377 145 277 minecraft:red_terracotta
setblock 377 142 291 minecraft:stripped_oak_log
setblock 377 142 292 minecraft:red_terracotta
setblock 377 142 296 minecraft:stripped_oak_log
fill 377 142 297 377 145 297 minecraft:red_terracotta
setblock 377 142 301 minecraft:stripped_oak_log
fill 377 142 302 377 143 302 minecraft:red_terracotta
setblock 377 142 306 minecraft:stripped_oak_log
setblock 377 142 307 minecraft:red_terracotta
setblock 377 142 311 minecraft:stripped_oak_log
fill 377 142 312 377 145 312 minecraft:red_terracotta
setblock 377 142 316 minecraft:stripped_oak_log
fill 378 142 276 378 145 276 minecraft:red_terracotta
setblock 378 142 310 minecraft:stripped_oak_log
setblock 378 142 311 minecraft:red_terracotta
setblock 378 142 315 minecraft:stripped_oak_log
fill 378 142 316 381 142 316 minecraft:red_terracotta
setblock 379 142 314 minecraft:stripped_oak_log
fill 379 142 315 382 142 315 minecraft:red_terracotta
setblock 381 142 276 minecraft:red_terracotta
setblock 382 142 276 minecraft:stripped_oak_log
setblock 382 142 316 minecraft:stripped_oak_log
fill 383 142 276 386 142 276 minecraft:red_terracotta
setblock 383 142 315 minecraft:stripped_oak_log
fill 383 142 316 383 145 316 minecraft:red_terracotta
fill 384 142 315 384 145 315 minecraft:red_terracotta
fill 385 142 314 388 142 314 minecraft:red_terracotta
setblock 387 142 276 minecraft:stripped_oak_log
setblock 387 142 316 minecraft:stripped_oak_log
fill 388 142 276 390 142 277 minecraft:red_terracotta
setblock 388 142 315 minecraft:stripped_oak_log
fill 388 142 316 388 145 316 minecraft:red_terracotta
setblock 389 142 314 minecraft:stripped_oak_log
fill 389 142 315 389 145 315 minecraft:red_terracotta
fill 390 142 314 390 144 314 minecraft:red_terracotta
setblock 391 142 276 minecraft:red_terracotta
setblock 391 142 277 minecraft:stripped_oak_log
setblock 392 142 276 minecraft:stripped_oak_log
fill 392 142 277 392 145 277 minecraft:red_terracotta
setblock 392 142 316 minecraft:stripped_oak_log
fill 393 142 276 393 145 276 minecraft:red_terracotta
setblock 393 142 315 minecraft:stripped_oak_log
fill 393 142 316 393 145 316 minecraft:red_terracotta
setblock 394 142 314 minecraft:stripped_oak_log
fill 394 142 315 394 144 315 minecraft:red_terracotta
setblock 397 142 276 minecraft:stripped_oak_log
setblock 397 142 316 minecraft:stripped_oak_log
fill 398 142 276 401 142 276 minecraft:red_terracotta
fill 398 142 316 398 143 316 minecraft:red_terracotta
setblock 402 142 276 minecraft:stripped_oak_log
fill 403 142 276 403 145 276 minecraft:red_terracotta
fill 403 142 316 406 142 316 minecraft:red_terracotta
setblock 405 142 277 minecraft:red_terracotta
setblock 406 142 277 minecraft:stripped_oak_log
setblock 407 142 276 minecraft:stripped_oak_log
fill 407 142 277 407 145 277 minecraft:red_terracotta
setblock 407 142 315 minecraft:red_terracotta
setblock 407 142 316 minecraft:stripped_oak_log
fill 408 142 276 408 145 276 minecraft:red_terracotta
fill 408 142 278 409 142 278 minecraft:red_terracotta
setblock 408 142 315 minecraft:stripped_oak_log
fill 408 142 316 408 145 316 minecraft:red_terracotta
fill 409 142 315 409 145 315 minecraft:red_terracotta
setblock 410 142 278 minecraft:stripped_oak_log
setblock 410 142 314 minecraft:red_terracotta
setblock 411 142 277 minecraft:stripped_oak_log
fill 411 142 278 411 144 279 minecraft:red_terracotta
setblock 412 142 276 minecraft:stripped_oak_log
fill 412 142 277 412 145 277 minecraft:red_terracotta
fill 412 142 279 413 142 279 minecraft:red_terracotta
setblock 412 142 316 minecraft:stripped_oak_log
fill 413 142 276 413 145 276 minecraft:red_terracotta
setblock 413 142 315 minecraft:stripped_oak_log
fill 413 142 316 413 145 316 minecraft:red_terracotta
setblock 414 142 314 minecraft:stripped_oak_log
fill 414 142 315 414 145 315 minecraft:red_terracotta
setblock 415 142 278 minecraft:stripped_oak_log
fill 415 142 279 415 145 279 minecraft:red_terracotta
setblock 415 142 293 minecraft:stripped_oak_log
setblock 415 142 294 minecraft:red_terracotta
setblock 415 142 313 minecraft:stripped_oak_log
fill 415 142 314 415 143 314 minecraft:red_terracotta
setblock 416 142 277 minecraft:stripped_oak_log
fill 416 142 278 416 145 278 minecraft:red_terracotta
setblock 416 142 282 minecraft:stripped_oak_log
setblock 416 142 283 minecraft:red_terracotta
setblock 416 142 288 minecraft:red_terracotta
setblock 416 142 292 minecraft:stripped_oak_log
fill 416 142 293 416 143 293 minecraft:red_terracotta
setblock 416 142 297 minecraft:stripped_oak_log
setblock 416 142 298 minecraft:red_terracotta
setblock 416 142 312 minecraft:stripped_oak_log
fill 416 142 313 416 143 313 minecraft:red_terracotta
setblock 417 142 276 minecraft:stripped_oak_log
fill 417 142 277 417 145 277 minecraft:red_terracotta
setblock 417 142 281 minecraft:stripped_oak_log
fill 417 142 282 417 145 282 minecraft:red_terracotta
setblock 417 142 286 minecraft:stripped_oak_log
setblock 417 142 287 minecraft:red_terracotta
setblock 417 142 291 minecraft:stripped_oak_log
fill 417 142 292 417 143 292 minecraft:red_terracotta
setblock 417 142 296 minecraft:stripped_oak_log
fill 417 142 297 417 144 297 minecraft:red_terracotta
fill 417 142 299 417 143 299 minecraft:red_terracotta
setblock 417 142 311 minecraft:stripped_oak_log
fill 417 142 312 417 144 312 minecraft:red_terracotta
setblock 417 142 316 minecraft:stripped_oak_log
fill 377 143 276 377 146 276 minecraft:red_terracotta
setblock 377 143 280 minecraft:stripped_oak_log
setblock 377 143 295 minecraft:stripped_oak_log
fill 377 143 296 377 145 296 minecraft:red_terracotta
setblock 377 143 300 minecraft:stripped_oak_log
fill 377 143 301 377 146 301 minecraft:red_terracotta
setblock 377 143 310 minecraft:stripped_oak_log
fill 377 143 311 377 145 311 minecraft:red_terracotta
setblock 377 143 315 minecraft:stripped_oak_log
fill 377 143 316 380 143 316 minecraft:red_terracotta
setblock 378 143 314 minecraft:stripped_oak_log
fill 378 143 315 381 143 315 minecraft:red_terracotta
setblock 381 143 276 minecraft:stripped_oak_log
setblock 381 143 316 minecraft:stripped_oak_log
fill 382 143 276 385 143 276 minecraft:red_terracotta
setblock 382 143 315 minecraft:stripped_oak_log
fill 382 143 316 382 146 316 minecraft:red_terracotta
fill 383 143 315 383 145 315 minecraft:red_terracotta
setblock 386 143 276 minecraft:stripped_oak_log
fill 386 143 314 387 143 314 minecraft:red_terracotta
setblock 386 143 316 minecraft:stripped_oak_log
fill 387 143 276 390 143 276 minecraft:red_terracotta
setblock 387 143 315 minecraft:stripped_oak_log
fill 387 143 316 387 146 316 minecraft:red_terracotta
fill 388 143 277 389 143 277 minecraft:red_terracotta
setblock 388 143 314 minecraft:stripped_oak_log
fill 388 143 315 388 146 315 minecraft:red_terracotta
fill 389 143 314 389 144 314 minecraft:red_terracotta
setblock 390 143 277 minecraft:stripped_oak_log
setblock 391 143 276 minecraft:stripped_oak_log
fill 391 143 277 391 146 277 minecraft:red_terracotta
setblock 391 143 316 minecraft:stripped_oak_log
fill 392 143 276 392 146 276 minecraft:red_terracotta
setblock 392 143 315 minecraft:stripped_oak_log
fill 392 143 316 392 146 316 minecraft:red_terracotta
setblock 393 143 314 minecraft:stripped_oak_log
fill 393 143 315 393 144 315 minecraft:red_terracotta
fill 395 143 277 395 149 277 minecraft:stripped_oak_log
setblock 396 143 276 minecraft:stripped_oak_log
setblock 396 143 316 minecraft:stripped_oak_log
fill 397 143 276 400 143 276 minecraft:red_terracotta
fill 397 143 316 397 144 316 minecraft:red_terracotta
setblock 401 143 276 minecraft:stripped_oak_log
fill 402 143 276 402 146 276 minecraft:red_terracotta
setblock 404 143 277 minecraft:red_terracotta
fill 404 143 316 405 143 316 minecraft:red_terracotta
setblock 405 143 277 minecraft:stripped_oak_log
setblock 406 143 276 minecraft:stripped_oak_log
fill 406 143 277 406 146 277 minecraft:red_terracotta
setblock 406 143 316 minecraft:stripped_oak_log
fill 407 143 276 407 146 276 minecraft:red_terracotta
fill 407 143 278 408 143 278 minecraft:red_terracotta
setblock 407 143 315 minecraft:stripped_oak_log
fill 407 143 316 407 146 316 minecraft:red_terracotta
fill 408 143 315 408 146 315 minecraft:red_terracotta
setblock 409 143 278 minecraft:stripped_oak_log
setblock 410 143 277 minecraft:stripped_oak_log
fill 410 143 278 410 145 279 minecraft:red_terracotta
setblock 411 143 276 minecraft:stripped_oak_log
fill 411 143 277 411 146 277 minecraft:red_terracotta
setblock 411 143 316 minecraft:stripped_oak_log
fill 412 143 276 412 146 276 minecraft:red_terracotta
setblock 412 143 279 minecraft:red_terracotta
setblock 412 143 315 minecraft:stripped_oak_log
fill 412 143 316 412 146 316 minecraft:red_terracotta
setblock 413 143 279 minecraft:stripped_oak_log
setblock 413 143 314 minecraft:stripped_oak_log
fill 413 143 315 413 146 315 minecraft:red_terracotta
setblock 414 143 278 minecraft:stripped_oak_log
setblock 414 143 314 minecraft:red_terracotta
setblock 415 143 277 minecraft:stripped_oak_log
fill 415 143 278 415 146 278 minecraft:red_terracotta
setblock 416 143 276 minecraft:stripped_oak_log
fill 416 143 277 416 146 277 minecraft:red_terracotta
setblock 416 143 281 minecraft:stripped_oak_log
setblock 416 143 282 minecraft:red_terracotta
setblock 416 143 292 minecraft:red_terracotta
setblock 416 143 296 minecraft:stripped_oak_log
setblock 416 143 297 minecraft:red_terracotta
setblock 416 143 316 minecraft:stripped_oak_log
fill 417 143 276 417 146 276 minecraft:red_terracotta
setblock 417 143 280 minecraft:stripped_oak_log
fill 417 143 281 417 146 281 minecraft:red_terracotta
setblock 417 143 290 minecraft:stripped_oak_log
setblock 417 143 291 minecraft:red_terracotta
setblock 417 143 295 minecraft:stripped_oak_log
fill 417 143 296 417 144 296 minecraft:red_terracotta
setblock 417 143 311 minecraft:red_terracotta
setblock 417 143 315 minecraft:stripped_oak_log
fill 417 143 316 417 146 316 minecraft:red_terracotta
fill 376 144 275 376 147 317 minecraft:red_terracotta
fill 377 144 275 418 147 275 minecraft:red_terracotta
setblock 377 144 279 minecraft:stripped_oak_log
setblock 377 144 295 minecraft:red_terracotta
setblock 377 144 299 minecraft:stripped_oak_log
fill 377 144 300 377 147 300 minecraft:red_terracotta
setblock 377 144 310 minecraft:red_terracotta
setblock 377 144 314 minecraft:stripped_oak_log
fill 377 144 315 379 144 317 minecraft:red_terracotta
setblock 378 144 313 minecraft:stripped_oak_log
setblock 378 144 314 minecraft:red_terracotta
setblock 379 144 278 minecraft:light[level=15]
setblock 379 144 285 minecraft:light[level=12]
setblock 379 144 286 minecraft:light[level=15]
setblock 379 144 292 minecraft:light[level=12]
setblock 379 144 294 minecraft:light[level=15]
setblock 379 144 299 minecraft:light[level=12]
setblock 379 144 302 minecraft:light[level=15]
setblock 379 144 306 minecraft:light[level=12]
setblock 379 144 310 minecraft:light[level=15]
setblock 379 144 313 minecraft:light[level=12]
setblock 380 144 276 minecraft:stripped_oak_log
setblock 380 144 315 minecraft:red_terracotta
setblock 380 144 316 minecraft:stripped_oak_log
fill 380 144 317 418 147 317 minecraft:red_terracotta
fill 381 144 276 384 144 276 minecraft:red_terracotta
setblock 381 144 315 minecraft:stripped_oak_log
fill 381 144 316 381 147 316 minecraft:red_terracotta
setblock 382 144 315 minecraft:red_terracotta
setblock 385 144 276 minecraft:stripped_oak_log
setblock 385 144 316 minecraft:stripped_oak_log
fill 386 144 276 389 144 276 minecraft:red_terracotta
setblock 386 144 278 minecraft:light[level=12]
setblock 386 144 285 minecraft:light[level=12]
setblock 386 144 292 minecraft:light[level=12]
setblock 386 144 299 minecraft:light[level=12]
setblock 386 144 306 minecraft:light[level=12]
setblock 386 144 313 minecraft:light[level=12]
setblock 386 144 315 minecraft:stripped_oak_log
fill 386 144 316 386 147 316 minecraft:red_terracotta
fill 387 144 277 388 144 277 minecraft:red_terracotta
setblock 387 144 278 minecraft:light[level=15]
setblock 387 144 286 minecraft:light[level=15]
setblock 387 144 294 minecraft:light[level=15]
setblock 387 144 302 minecraft:light[level=15]
setblock 387 144 310 minecraft:light[level=15]
fill 387 144 315 387 147 315 minecraft:red_terracotta
setblock 388 144 314 minecraft:red_terracotta
setblock 389 144 277 minecraft:stripped_oak_log
setblock 390 144 276 minecraft:stripped_oak_log
fill 390 144 277 390 147 277 minecraft:red_terracotta
setblock 390 144 316 minecraft:stripped_oak_log
fill 391 144 276 391 147 276 minecraft:red_terracotta
setblock 391 144 315 minecraft:stripped_oak_log
fill 391 144 316 391 147 316 minecraft:red_terracotta
fill 392 144 315 392 145 315 minecraft:red_terracotta
setblock 393 144 285 minecraft:light[level=12]
setblock 393 144 292 minecraft:light[level=12]
setblock 393 144 299 minecraft:light[level=12]
setblock 393 144 306 minecraft:light[level=12]
setblock 393 144 313 minecraft:light[level=12]
fill 394 144 277 394 149 277 minecraft:stripped_oak_log
setblock 395 144 276 minecraft:stripped_oak_log
setblock 395 144 286 minecraft:light[level=15]
setblock 395 144 294 minecraft:light[level=15]
setblock 395 144 302 minecraft:light[level=15]
setblock 395 144 310 minecraft:light[level=15]
setblock 395 144 316 minecraft:stripped_oak_log
fill 396 144 276 399 144 276 minecraft:red_terracotta
setblock 396 144 316 minecraft:red_terracotta
setblock 400 144 276 minecraft:stripped_oak_log
setblock 400 144 278 minecraft:light[level=12]
setblock 400 144 285 minecraft:light[level=12]
setblock 400 144 292 minecraft:light[level=12]
setblock 400 144 299 minecraft:light[level=12]
setblock 400 144 306 minecraft:light[level=12]
setblock 400 144 313 minecraft:light[level=12]
fill 401 144 276 401 147 276 minecraft:red_terracotta
setblock 403 144 278 minecraft:light[level=15]
setblock 403 144 286 minecraft:light[level=15]
setblock 403 144 294 minecraft:light[level=15]
setblock 403 144 302 minecraft:light[level=15]
setblock 403 144 310 minecraft:light[level=15]
setblock 404 144 277 minecraft:stripped_oak_log
setblock 404 144 316 minecraft:red_terracotta
setblock 405 144 276 minecraft:stripped_oak_log
fill 405 144 277 405 147 277 minecraft:red_terracotta
setblock 405 144 316 minecraft:stripped_oak_log
fill 406 144 276 406 147 276 minecraft:red_terracotta
fill 406 144 278 407 144 278 minecraft:red_terracotta
fill 406 144 316 406 147 316 minecraft:red_terracotta
setblock 407 144 285 minecraft:light[level=12]
setblock 407 144 292 minecraft:light[level=12]
setblock 407 144 299 minecraft:light[level=12]
setblock 407 144 306 minecraft:light[level=12]
setblock 407 144 313 minecraft:light[level=12]
setblock 407 144 315 minecraft:red_terracotta
setblock 408 144 278 minecraft:stripped_oak_log
setblock 409 144 277 minecraft:stripped_oak_log
fill 409 144 278 409 147 278 minecraft:red_terracotta
setblock 410 144 276 minecraft:stripped_oak_log
fill 410 144 277 410 147 277 minecraft:red_terracotta
setblock 410 144 316 minecraft:stripped_oak_log
fill 411 144 276 411 147 276 minecraft:red_terracotta
setblock 411 144 286 minecraft:light[level=15]
setblock 411 144 294 minecraft:light[level=15]
setblock 411 144 302 minecraft:light[level=15]
setblock 411 144 310 minecraft:light[level=15]
setblock 411 144 315 minecraft:stripped_oak_log
fill 411 144 316 411 147 316 minecraft:red_terracotta
setblock 412 144 279 minecraft:stripped_oak_log
fill 412 144 315 412 147 315 minecraft:red_terracotta
setblock 413 144 278 minecraft:stripped_oak_log
setblock 414 144 277 minecraft:stripped_oak_log
fill 414 144 278 414 147 278 minecraft:red_terracotta
setblock 414 144 285 minecraft:light[level=12]
setblock 414 144 292 minecraft:light[level=12]
setblock 414 144 299 minecraft:light[level=12]
setblock 414 144 306 minecraft:light[level=12]
setblock 414 144 313 minecraft:light[level=12]
setblock 415 144 276 minecraft:stripped_oak_log
fill 415 144 277 415 147 277 minecraft:red_terracotta
setblock 415 144 316 minecraft:stripped_oak_log
fill 416 144 276 416 147 276 minecraft:red_terracotta
setblock 416 144 280 minecraft:stripped_oak_log
setblock 416 144 281 minecraft:red_terracotta
setblock 416 144 315 minecraft:stripped_oak_log
fill 416 144 316 416 147 316 minecraft:red_terracotta
setblock 417 144 279 minecraft:stripped_oak_log
fill 417 144 280 418 147 280 minecraft:red_terracotta
setblock 417 144 294 minecraft:stripped_oak_log
fill 417 144 295 418 144 295 minecraft:red_terracotta
setblock 417 144 314 minecraft:stripped_oak_log
fill 417 144 315 418 147 315 minecraft:red_terracotta
fill 418 144 276 418 147 279 minecraft:red_terracotta
fill 418 144 281 418 147 294 minecraft:red_terracotta
fill 418 144 296 418 147 314 minecraft:red_terracotta
fill 418 144 316 418 147 316 minecraft:red_terracotta
setblock 377 145 278 minecraft:stripped_oak_log
setblock 377 145 279 minecraft:red_terracotta
setblock 377 145 298 minecraft:stripped_oak_log
fill 377 145 299 377 148 299 minecraft:red_terracotta
setblock 377 145 313 minecraft:stripped_oak_log
fill 377 145 314 377 146 317 minecraft:red_terracotta
fill 378 145 315 378 145 317 minecraft:red_terracotta
setblock 379 145 276 minecraft:stripped_oak_log
setblock 379 145 316 minecraft:stripped_oak_log
fill 379 145 317 379 147 317 minecraft:red_terracotta
fill 380 145 276 383 145 276 minecraft:red_terracotta
fill 380 145 316 380 147 316 minecraft:red_terracotta
setblock 384 145 276 minecraft:stripped_oak_log
setblock 384 145 316 minecraft:stripped_oak_log
fill 385 145 276 388 145 276 minecraft:red_terracotta
setblock 385 145 315 minecraft:stripped_oak_log
fill 385 145 316 385 148 316 minecraft:red_terracotta
fill 386 145 315 386 146 315 minecraft:red_terracotta
setblock 387 145 277 minecraft:red_terracotta
setblock 388 145 277 minecraft:stripped_oak_log
setblock 389 145 276 minecraft:stripped_oak_log
fill 389 145 277 389 148 277 minecraft:red_terracotta
setblock 389 145 316 minecraft:stripped_oak_log
fill 390 145 276 390 148 276 minecraft:red_terracotta
setblock 390 145 315 minecraft:stripped_oak_log
fill 390 145 316 390 148 316 minecraft:red_terracotta
setblock 391 145 315 minecraft:red_terracotta
fill 393 145 277 393 149 277 minecraft:stripped_oak_log
setblock 394 145 276 minecraft:stripped_oak_log
setblock 394 145 316 minecraft:stripped_oak_log
fill 395 145 276 397 145 276 minecraft:red_terracotta
setblock 395 145 316 minecraft:red_terracotta
setblock 400 145 276 minecraft:red_terracotta
setblock 404 145 276 minecraft:stripped_oak_log
fill 404 145 277 404 148 277 minecraft:red_terracotta
fill 405 145 276 405 148 276 minecraft:red_terracotta
fill 405 145 316 405 148 316 minecraft:red_terracotta
setblock 406 145 278 minecraft:red_terracotta
setblock 407 145 278 minecraft:stripped_oak_log
setblock 408 145 277 minecraft:stripped_oak_log
fill 408 145 278 408 148 278 minecraft:red_terracotta
setblock 409 145 276 minecraft:stripped_oak_log
fill 409 145 277 409 148 277 minecraft:red_terracotta
fill 409 145 279 409 146 279 minecraft:red_terracotta
setblock 409 145 316 minecraft:stripped_oak_log
fill 410 145 276 410 148 276 minecraft:red_terracotta
setblock 410 145 315 minecraft:stripped_oak_log
fill 410 145 316 410 148 316 minecraft:red_terracotta
setblock 411 145 278 minecraft:red_terracotta
setblock 411 145 279 minecraft:stripped_oak_log
fill 411 145 315 411 147 315 minecraft:red_terracotta
setblock 412 145 278 minecraft:stripped_oak_log
setblock 413 145 277 minecraft:stripped_oak_log
fill 413 145 278 413 148 278 minecraft:red_terracotta
setblock 414 145 276 minecraft:stripped_oak_log
fill 414 145 277 414 148 277 minecraft:red_terracotta
setblock 414 145 316 minecraft:stripped_oak_log
fill 415 145 276 415 148 276 minecraft:red_terracotta
setblock 415 145 315 minecraft:stripped_oak_log
fill 415 145 316 415 148 316 minecraft:red_terracotta
setblock 416 145 279 minecraft:stripped_oak_log
fill 416 145 280 416 146 280 minecraft:red_terracotta
setblock 416 145 315 minecraft:red_terracotta
setblock 417 145 278 minecraft:stripped_oak_log
fill 417 145 279 417 148 279 minecraft:red_terracotta
setblock 417 145 313 minecraft:stripped_oak_log
fill 417 145 314 417 146 314 minecraft:red_terracotta
fill 418 145 295 418 147 295 minecraft:red_terracotta
setblock 377 146 277 minecraft:stripped_oak_log
setblock 377 146 278 minecraft:red_terracotta
setblock 377 146 298 minecraft:red_terracotta
setblock 377 146 313 minecraft:red_terracotta
setblock 378 146 276 minecraft:stripped_oak_log
setblock 378 146 316 minecraft:stripped_oak_log
fill 378 146 317 378 147 317 minecraft:red_terracotta
setblock 379 146 276 minecraft:red_terracotta
fill 379 146 316 379 147 316 minecraft:red_terracotta
setblock 382 146 276 minecraft:red_terracotta
setblock 383 146 276 minecraft:stripped_oak_log
setblock 383 146 316 minecraft:stripped_oak_log
fill 384 146 276 387 146 276 minecraft:red_terracotta
fill 384 146 316 384 149 316 minecraft:red_terracotta
setblock 385 146 315 minecraft:red_terracotta
setblock 387 146 277 minecraft:stripped_oak_log
setblock 388 146 276 minecraft:stripped_oak_log
fill 388 146 277 388 149 277 minecraft:red_terracotta
setblock 388 146 316 minecraft:stripped_oak_log
fill 389 146 276 389 149 276 minecraft:red_terracotta
fill 389 146 278 391 146 281 minecraft:orange_terracotta
setblock 389 146 315 minecraft:stripped_oak_log
fill 389 146 316 389 149 316 minecraft:red_terracotta
fill 390 146 282 399 146 282 minecraft:orange_terracotta
setblock 390 146 315 minecraft:red_terracotta
fill 391 146 283 398 146 283 minecraft:orange_terracotta
fill 392 146 277 392 149 277 minecraft:stripped_oak_log
fill 392 146 281 392 148 281 minecraft:orange_terracotta
fill 392 146 284 396 146 284 minecraft:orange_terracotta
setblock 393 146 276 minecraft:stripped_oak_log
setblock 393 146 316 minecraft:stripped_oak_log
fill 394 146 276 396 146 276 minecraft:red_terracotta
setblock 394 146 316 minecraft:red_terracotta
fill 397 146 276 399 146 276 minecraft:orange_terracotta
fill 397 146 281 399 146 281 minecraft:orange_terracotta
fill 398 146 277 400 146 280 minecraft:orange_terracotta
setblock 403 146 276 minecraft:stripped_oak_log
fill 403 146 277 403 149 277 minecraft:red_terracotta
fill 404 146 276 404 149 276 minecraft:red_terracotta
setblock 406 146 278 minecraft:stripped_oak_log
setblock 407 146 277 minecraft:stripped_oak_log
fill 407 146 278 407 149 278 minecraft:red_terracotta
setblock 408 146 276 minecraft:stripped_oak_log
fill 408 146 277 408 149 277 minecraft:red_terracotta
setblock 408 146 316 minecraft:stripped_oak_log
fill 409 146 276 409 149 276 minecraft:red_terracotta
setblock 409 146 315 minecraft:stripped_oak_log
fill 409 146 316 409 149 316 minecraft:red_terracotta
setblock 410 146 278 minecraft:red_terracotta
setblock 410 146 279 minecraft:stripped_oak_log
fill 410 146 315 410 147 315 minecraft:red_terracotta
setblock 411 146 278 minecraft:stripped_oak_log
setblock 411 146 279 minecraft:red_terracotta
setblock 412 146 277 minecraft:stripped_oak_log
fill 412 146 278 412 149 278 minecraft:red_terracotta
setblock 413 146 276 minecraft:stripped_oak_log
fill 413 146 277 413 149 277 minecraft:red_terracotta
setblock 413 146 316 minecraft:stripped_oak_log
fill 414 146 276 414 149 276 minecraft:red_terracotta
setblock 414 146 315 minecraft:stripped_oak_log
fill 414 146 316 414 149 316 minecraft:red_terracotta
setblock 416 146 278 minecraft:stripped_oak_log
fill 416 146 279 416 148 279 minecraft:red_terracotta
setblock 417 146 277 minecraft:stripped_oak_log
fill 417 146 278 417 149 278 minecraft:red_terracotta
setblock 377 147 276 minecraft:stripped_oak_log
setblock 377 147 277 minecraft:red_terracotta
setblock 377 147 301 minecraft:stripped_oak_log
setblock 377 147 315 minecraft:red_terracotta
setblock 377 147 316 minecraft:stripped_oak_log
setblock 377 147 317 minecraft:red_terracotta
setblock 378 147 316 minecraft:red_terracotta
setblock 382 147 316 minecraft:stripped_oak_log
fill 383 147 276 386 147 276 minecraft:red_terracotta
fill 383 147 316 383 149 316 minecraft:red_terracotta
setblock 387 147 276 minecraft:stripped_oak_log
fill 387 147 277 387 149 277 minecraft:red_terracotta
setblock 387 147 316 minecraft:stripped_oak_log
fill 388 147 276 388 149 276 minecraft:red_terracotta
setblock 388 147 315 minecraft:stripped_oak_log
fill 388 147 316 388 149 316 minecraft:red_terracotta
fill 390 147 278 391 147 281 minecraft:orange_terracotta
setblock 391 147 277 minecraft:stripped_oak_log
fill 391 147 282 398 147 282 minecraft:orange_terracotta
setblock 392 147 276 minecraft:stripped_oak_log
fill 392 147 283 396 147 283 minecraft:orange_terracotta
setblock 392 147 316 minecraft:stripped_oak_log
fill 393 147 276 394 147 276 minecraft:red_terracotta
fill 395 147 276 396 149 276 minecraft:stripped_oak_log
fill 397 147 276 398 147 276 minecraft:orange_terracotta
fill 397 147 281 398 147 281 minecraft:orange_terracotta
fill 398 147 277 399 147 280 minecraft:orange_terracotta
setblock 402 147 276 minecraft:stripped_oak_log
fill 403 147 276 403 149 276 minecraft:red_terracotta
setblock 405 147 278 minecraft:stripped_oak_log
setblock 406 147 277 minecraft:stripped_oak_log
fill 406 147 278 406 149 278 minecraft:red_terracotta
setblock 407 147 276 minecraft:stripped_oak_log
fill 407 147 277 407 149 277 minecraft:red_terracotta
setblock 407 147 316 minecraft:stripped_oak_log
fill 408 147 276 408 149 276 minecraft:red_terracotta
setblock 408 147 279 minecraft:red_terracotta
fill 408 147 316 408 149 316 minecraft:red_terracotta
setblock 409 147 279 minecraft:stripped_oak_log
setblock 409 147 315 minecraft:red_terracotta
setblock 410 147 278 minecraft:stripped_oak_log
fill 410 147 279 410 149 279 minecraft:red_terracotta
setblock 411 147 277 minecraft:stripped_oak_log
fill 411 147 278 411 149 278 minecraft:red_terracotta
setblock 412 147 276 minecraft:stripped_oak_log
fill 412 147 277 412 149 277 minecraft:red_terracotta
setblock 412 147 316 minecraft:stripped_oak_log
fill 413 147 276 413 149 276 minecraft:red_terracotta
fill 413 147 316 413 149 316 minecraft:red_terracotta
setblock 416 147 277 minecraft:stripped_oak_log
fill 416 147 278 416 149 278 minecraft:red_terracotta
setblock 417 147 276 minecraft:stripped_oak_log
fill 417 147 277 417 149 277 minecraft:red_terracotta
setblock 417 147 281 minecraft:stripped_oak_log
setblock 417 147 316 minecraft:stripped_oak_log
fill 376 148 275 376 151 317 minecraft:yellow_terracotta
fill 377 148 275 418 151 275 minecraft:yellow_terracotta
setblock 377 148 300 minecraft:stripped_oak_log
fill 377 148 301 377 149 302 minecraft:red_terracotta
setblock 377 148 316 minecraft:red_terracotta
fill 377 148 317 418 151 317 minecraft:yellow_terracotta
setblock 381 148 316 minecraft:stripped_oak_log
fill 382 148 316 382 149 316 minecraft:red_terracotta
fill 383 148 276 385 148 276 minecraft:red_terracotta
setblock 386 148 276 minecraft:stripped_oak_log
setblock 386 148 316 minecraft:stripped_oak_log
fill 387 148 276 387 149 276 minecraft:red_terracotta
fill 387 148 316 387 149 316 minecraft:red_terracotta
setblock 390 148 277 minecraft:stripped_oak_log
setblock 391 148 276 minecraft:stripped_oak_log
fill 391 148 277 391 148 280 minecraft:orange_terracotta
setblock 391 148 316 minecraft:stripped_oak_log
fill 392 148 276 393 149 276 minecraft:red_terracotta
fill 393 148 282 396 148 282 minecraft:orange_terracotta
fill 394 148 276 394 149 276 minecraft:stripped_oak_log
setblock 397 148 276 minecraft:orange_terracotta
setblock 397 148 281 minecraft:orange_terracotta
fill 398 148 277 398 148 280 minecraft:orange_terracotta
setblock 401 148 276 minecraft:stripped_oak_log
fill 402 148 276 402 149 276 minecraft:red_terracotta
setblock 404 148 278 minecraft:stripped_oak_log
setblock 405 148 277 minecraft:stripped_oak_log
fill 405 148 278 405 149 278 minecraft:red_terracotta
setblock 406 148 276 minecraft:stripped_oak_log
fill 406 148 277 406 149 277 minecraft:red_terracotta
setblock 406 148 316 minecraft:stripped_oak_log
fill 407 148 276 407 149 276 minecraft:red_terracotta
setblock 407 148 279 minecraft:red_terracotta
fill 407 148 316 407 149 316 minecraft:red_terracotta
setblock 408 148 279 minecraft:stripped_oak_log
setblock 409 148 278 minecraft:stripped_oak_log
fill 409 148 279 409 149 279 minecraft:red_terracotta
setblock 410 148 277 minecraft:stripped_oak_log
fill 410 148 278 410 149 278 minecraft:red_terracotta
setblock 411 148 276 minecraft:stripped_oak_log
fill 411 148 277 411 149 277 minecraft:red_terracotta
setblock 411 148 316 minecraft:stripped_oak_log
fill 412 148 276 412 149 276 minecraft:red_terracotta
fill 412 148 316 412 149 316 minecraft:red_terracotta
setblock 414 148 278 minecraft:stripped_oak_log
setblock 415 148 277 minecraft:stripped_oak_log
setblock 416 148 276 minecraft:stripped_oak_log
fill 416 148 277 416 149 277 minecraft:red_terracotta
setblock 416 148 316 minecraft:stripped_oak_log
fill 417 148 276 417 149 276 minecraft:red_terracotta
setblock 417 148 280 minecraft:stripped_oak_log
fill 417 148 281 417 149 281 minecraft:red_terracotta
fill 417 148 316 417 149 316 minecraft:red_terracotta
fill 418 148 276 418 151 316 minecraft:yellow_terracotta
setblock 377 149 299 minecraft:stripped_oak_log
setblock 377 149 300 minecraft:red_terracotta
setblock 377 149 303 minecraft:red_terracotta
setblock 377 149 304 minecraft:stripped_oak_log
fill 383 149 276 384 149 276 minecraft:red_terracotta
setblock 385 149 276 minecraft:stripped_oak_log
setblock 385 149 316 minecraft:stripped_oak_log
setblock 386 149 276 minecraft:red_terracotta
setblock 386 149 316 minecraft:red_terracotta
setblock 389 149 277 minecraft:stripped_oak_log
setblock 390 149 276 minecraft:stripped_oak_log
setblock 390 149 316 minecraft:stripped_oak_log
setblock 391 149 276 minecraft:red_terracotta
setblock 400 149 276 minecraft:stripped_oak_log
setblock 401 149 276 minecraft:red_terracotta
setblock 402 149 277 minecraft:red_terracotta
setblock 404 149 277 minecraft:stripped_oak_log
setblock 404 149 278 minecraft:red_terracotta
setblock 405 149 276 minecraft:stripped_oak_log
setblock 405 149 277 minecraft:red_terracotta
setblock 405 149 316 minecraft:stripped_oak_log
setblock 406 149 276 minecraft:red_terracotta
setblock 406 149 279 minecraft:red_terracotta
setblock 406 149 316 minecraft:red_terracotta
setblock 407 149 279 minecraft:stripped_oak_log
setblock 408 149 278 minecraft:stripped_oak_log
setblock 408 149 279 minecraft:red_terracotta
setblock 409 149 277 minecraft:stripped_oak_log
setblock 409 149 278 minecraft:red_terracotta
setblock 410 149 276 minecraft:stripped_oak_log
setblock 410 149 277 minecraft:red_terracotta
setblock 410 149 316 minecraft:stripped_oak_log
setblock 411 149 276 minecraft:red_terracotta
setblock 411 149 316 minecraft:red_terracotta
setblock 413 149 278 minecraft:stripped_oak_log
setblock 414 149 277 minecraft:stripped_oak_log
setblock 415 149 276 minecraft:stripped_oak_log
setblock 415 149 277 minecraft:red_terracotta
setblock 415 149 316 minecraft:stripped_oak_log
setblock 416 149 276 minecraft:red_terracotta
setblock 416 149 316 minecraft:red_terracotta
setblock 417 149 279 minecraft:stripped_oak_log
setblock 417 149 280 minecraft:red_terracotta
setblock 379 150 278 minecraft:light[level=12]
setblock 379 150 285 minecraft:light[level=12]
setblock 379 150 292 minecraft:light[level=12]
setblock 379 150 299 minecraft:light[level=12]
setblock 379 150 306 minecraft:light[level=12]
setblock 379 150 313 minecraft:light[level=12]
setblock 386 150 278 minecraft:light[level=12]
setblock 386 150 285 minecraft:light[level=12]
setblock 386 150 292 minecraft:light[level=12]
setblock 386 150 299 minecraft:light[level=12]
setblock 386 150 306 minecraft:light[level=12]
setblock 386 150 313 minecraft:light[level=12]
setblock 393 150 278 minecraft:light[level=12]
setblock 393 150 285 minecraft:light[level=12]
setblock 393 150 292 minecraft:light[level=12]
setblock 393 150 299 minecraft:light[level=12]
setblock 393 150 306 minecraft:light[level=12]
setblock 393 150 313 minecraft:light[level=12]
setblock 400 150 278 minecraft:light[level=12]
setblock 400 150 285 minecraft:light[level=12]
setblock 400 150 292 minecraft:light[level=12]
setblock 400 150 299 minecraft:light[level=12]
setblock 400 150 306 minecraft:light[level=12]
setblock 400 150 313 minecraft:light[level=12]
setblock 407 150 278 minecraft:light[level=12]
setblock 407 150 285 minecraft:light[level=12]
setblock 407 150 292 minecraft:light[level=12]
setblock 407 150 299 minecraft:light[level=12]
setblock 407 150 306 minecraft:light[level=12]
setblock 407 150 313 minecraft:light[level=12]
setblock 414 150 278 minecraft:light[level=12]
setblock 414 150 285 minecraft:light[level=12]
setblock 414 150 292 minecraft:light[level=12]
setblock 414 150 299 minecraft:light[level=12]
setblock 414 150 306 minecraft:light[level=12]
setblock 414 150 313 minecraft:light[level=12]
fill 376 152 275 376 155 317 minecraft:white_terracotta
fill 377 152 275 418 155 275 minecraft:white_terracotta
fill 377 152 317 418 155 317 minecraft:white_terracotta
setblock 379 152 278 minecraft:light[level=15]
setblock 379 152 286 minecraft:light[level=15]
setblock 379 152 294 minecraft:light[level=15]
setblock 379 152 302 minecraft:light[level=15]
setblock 379 152 310 minecraft:light[level=15]
setblock 387 152 278 minecraft:light[level=15]
setblock 387 152 286 minecraft:light[level=15]
setblock 387 152 294 minecraft:light[level=15]
setblock 387 152 302 minecraft:light[level=15]
setblock 387 152 310 minecraft:light[level=15]
setblock 395 152 278 minecraft:light[level=15]
setblock 395 152 286 minecraft:light[level=15]
setblock 395 152 294 minecraft:light[level=15]
setblock 395 152 302 minecraft:light[level=15]
setblock 395 152 310 minecraft:light[level=15]
setblock 403 152 278 minecraft:light[level=15]
setblock 403 152 286 minecraft:light[level=15]
setblock 403 152 294 minecraft:light[level=15]
setblock 403 152 302 minecraft:light[level=15]
setblock 403 152 310 minecraft:light[level=15]
setblock 411 152 278 minecraft:light[level=15]
setblock 411 152 286 minecraft:light[level=15]
setblock 411 152 294 minecraft:light[level=15]
setblock 411 152 302 minecraft:light[level=15]
setblock 411 152 310 minecraft:light[level=15]
fill 418 152 276 418 155 316 minecraft:white_terracotta
fill 379 153 304 381 153 306 minecraft:terracotta
setblock 380 154 305 minecraft:green_concrete
fill 377 155 276 417 156 277 minecraft:spruce_planks
fill 377 155 278 417 156 278 minecraft:dark_oak_planks
fill 377 155 279 417 156 280 minecraft:spruce_planks
fill 377 155 281 417 156 281 minecraft:dark_oak_planks
fill 377 155 282 417 156 283 minecraft:spruce_planks
fill 377 155 284 417 156 284 minecraft:dark_oak_planks
fill 377 155 285 417 156 286 minecraft:spruce_planks
fill 377 155 287 417 156 287 minecraft:dark_oak_planks
fill 377 155 288 417 156 289 minecraft:spruce_planks
fill 377 155 290 417 156 290 minecraft:dark_oak_planks
fill 377 155 291 417 156 292 minecraft:spruce_planks
fill 377 155 293 417 155 293 minecraft:dark_oak_planks
fill 377 155 294 392 155 295 minecraft:spruce_planks
fill 377 155 296 392 155 296 minecraft:dark_oak_planks
fill 377 155 297 391 155 298 minecraft:spruce_planks
fill 377 155 299 392 155 299 minecraft:dark_oak_planks
fill 377 155 300 394 155 301 minecraft:spruce_planks
fill 377 155 302 417 156 302 minecraft:dark_oak_planks
fill 377 155 303 417 155 304 minecraft:spruce_planks
fill 377 155 305 417 155 305 minecraft:dark_oak_planks
fill 377 155 306 417 155 307 minecraft:spruce_planks
fill 377 155 308 417 155 308 minecraft:dark_oak_planks
fill 377 155 309 417 156 310 minecraft:spruce_planks
fill 377 155 311 417 156 311 minecraft:dark_oak_planks
fill 377 155 312 417 156 313 minecraft:spruce_planks
fill 377 155 314 417 156 314 minecraft:dark_oak_planks
fill 377 155 315 417 156 316 minecraft:spruce_planks
setblock 392 155 298 minecraft:spruce_planks
fill 393 155 294 394 155 294 minecraft:spruce_planks
fill 395 155 301 417 155 301 minecraft:spruce_planks
fill 396 155 294 417 155 294 minecraft:spruce_planks
fill 396 155 300 417 155 300 minecraft:spruce_planks
fill 398 155 295 417 155 295 minecraft:spruce_planks
fill 398 155 296 417 155 296 minecraft:dark_oak_planks
fill 398 155 298 417 155 298 minecraft:spruce_planks
fill 398 155 299 417 155 299 minecraft:dark_oak_planks
fill 399 155 297 417 155 297 minecraft:spruce_planks
fill 376 156 275 376 159 317 minecraft:terracotta
fill 377 156 275 418 159 275 minecraft:terracotta
fill 377 156 293 393 156 293 minecraft:dark_oak_planks
fill 377 156 294 391 156 295 minecraft:spruce_planks
fill 377 156 296 390 156 296 minecraft:dark_oak_planks
fill 377 156 297 390 156 298 minecraft:spruce_planks
fill 377 156 299 391 156 299 minecraft:dark_oak_planks
fill 377 156 300 391 156 301 minecraft:spruce_planks
fill 377 156 303 384 156 304 minecraft:spruce_planks
fill 377 156 305 384 156 305 minecraft:dark_oak_planks
fill 377 156 306 384 156 307 minecraft:spruce_planks
fill 377 156 308 385 156 308 minecraft:dark_oak_planks
fill 377 156 317 418 159 317 minecraft:terracotta
fill 385 156 303 417 156 303 minecraft:spruce_planks
fill 385 156 304 385 156 307 minecraft:ochre_froglight
setblock 386 156 304 minecraft:spruce_planks
setblock 386 156 305 minecraft:dark_oak_planks
fill 386 156 306 386 156 307 minecraft:spruce_planks
fill 386 156 308 387 156 308 minecraft:ochre_froglight
fill 387 156 304 387 156 307 minecraft:ochre_froglight
fill 388 156 304 389 156 304 minecraft:spruce_planks
setblock 388 156 305 minecraft:dark_oak_planks
fill 388 156 306 388 156 307 minecraft:spruce_planks
fill 388 156 308 389 156 308 minecraft:dark_oak_planks
fill 389 156 305 389 156 307 minecraft:ochre_froglight
setblock 390 156 304 minecraft:ochre_froglight
setblock 390 156 305 minecraft:dark_oak_planks
fill 390 156 306 390 156 307 minecraft:spruce_planks
setblock 390 156 308 minecraft:ochre_froglight
fill 391 156 296 391 156 298 minecraft:ochre_froglight
fill 391 156 304 393 156 304 minecraft:spruce_planks
fill 391 156 305 391 156 307 minecraft:ochre_froglight
fill 391 156 308 393 156 308 minecraft:dark_oak_planks
fill 392 156 294 392 156 296 minecraft:ochre_froglight
fill 392 156 298 392 156 300 minecraft:ochre_froglight
fill 392 156 301 393 156 301 minecraft:spruce_planks
setblock 392 156 305 minecraft:dark_oak_planks
fill 392 156 306 392 156 307 minecraft:spruce_planks
fill 393 156 294 394 156 294 minecraft:ochre_froglight
fill 393 156 300 394 156 300 minecraft:ochre_froglight
fill 393 156 305 393 156 307 minecraft:ochre_froglight
fill 394 156 293 396 156 293 minecraft:ochre_froglight
fill 394 156 301 396 156 301 minecraft:ochre_froglight
setblock 394 156 304 minecraft:ochre_froglight
setblock 394 156 305 minecraft:dark_oak_planks
fill 394 156 306 394 156 307 minecraft:spruce_planks
setblock 394 156 308 minecraft:ochre_froglight
fill 395 156 304 396 156 304 minecraft:spruce_planks
fill 395 156 305 395 156 307 minecraft:ochre_froglight
fill 395 156 308 398 156 308 minecraft:dark_oak_planks
fill 396 156 294 398 156 294 minecraft:ochre_froglight
fill 396 156 300 398 156 300 minecraft:ochre_froglight
fill 396 156 305 398 156 305 minecraft:dark_oak_planks
fill 396 156 306 398 156 307 minecraft:spruce_planks
fill 397 156 293 417 156 293 minecraft:dark_oak_planks
fill 397 156 301 417 156 301 minecraft:spruce_planks
fill 397 156 304 399 156 304 minecraft:ochre_froglight
fill 398 156 295 398 156 296 minecraft:ochre_froglight
fill 398 156 298 398 156 299 minecraft:ochre_froglight
fill 399 156 294 417 156 295 minecraft:spruce_planks
fill 399 156 296 399 156 298 minecraft:ochre_froglight
fill 399 156 299 417 156 299 minecraft:dark_oak_planks
fill 399 156 300 417 156 300 minecraft:spruce_planks
fill 399 156 305 399 156 308 minecraft:ochre_froglight
fill 400 156 296 417 156 296 minecraft:dark_oak_planks
fill 400 156 297 417 156 298 minecraft:spruce_planks
setblock 400 156 304 minecraft:spruce_planks
setblock 400 156 305 minecraft:dark_oak_planks
fill 400 156 306 400 156 307 minecraft:spruce_planks
fill 400 156 308 401 156 308 minecraft:dark_oak_planks
fill 401 156 304 401 156 307 minecraft:ochre_froglight
setblock 402 156 304 minecraft:spruce_planks
setblock 402 156 305 minecraft:dark_oak_planks
fill 402 156 306 403 156 306 minecraft:ochre_froglight
setblock 402 156 307 minecraft:spruce_planks
setblock 402 156 308 minecraft:ochre_froglight
fill 403 156 304 403 156 305 minecraft:ochre_froglight
setblock 403 156 307 minecraft:ochre_froglight
fill 403 156 308 404 156 308 minecraft:dark_oak_planks
fill 404 156 304 405 156 304 minecraft:spruce_planks
setblock 404 156 305 minecraft:dark_oak_planks
fill 404 156 306 405 156 307 minecraft:spruce_planks
setblock 405 156 305 minecraft:ochre_froglight
fill 405 156 308 406 156 308 minecraft:ochre_froglight
fill 406 156 304 407 156 304 minecraft:ochre_froglight
fill 406 156 305 417 156 305 minecraft:dark_oak_planks
setblock 406 156 306 minecraft:ochre_froglight
setblock 406 156 307 minecraft:spruce_planks
fill 407 156 306 417 156 306 minecraft:spruce_planks
setblock 407 156 307 minecraft:ochre_froglight
fill 407 156 308 417 156 308 minecraft:dark_oak_planks
fill 408 156 304 417 156 304 minecraft:spruce_planks
fill 408 156 307 417 156 307 minecraft:spruce_planks
fill 418 156 276 418 159 316 minecraft:terracotta
fill 380 157 305 380 159 306 minecraft:green_concrete
fill 376 160 275 376 163 317 minecraft:brown_terracotta
fill 377 160 275 418 163 275 minecraft:brown_terracotta
setblock 377 160 283 minecraft:stripped_oak_log
fill 377 160 284 377 160 287 minecraft:red_terracotta
setblock 377 160 288 minecraft:stripped_oak_log
fill 377 160 289 377 160 292 minecraft:red_terracotta
setblock 377 160 293 minecraft:stripped_oak_log
fill 377 160 294 377 160 297 minecraft:red_terracotta
setblock 377 160 298 minecraft:stripped_oak_log
fill 377 160 299 377 160 302 minecraft:red_terracotta
setblock 377 160 303 minecraft:stripped_oak_log
fill 377 160 304 377 160 307 minecraft:red_terracotta
setblock 377 160 308 minecraft:stripped_oak_log
fill 377 160 309 377 160 312 minecraft:red_terracotta
setblock 377 160 313 minecraft:stripped_oak_log
fill 377 160 314 377 162 315 minecraft:red_terracotta
fill 377 160 316 379 161 316 minecraft:stripped_oak_log
fill 377 160 317 418 163 317 minecraft:brown_terracotta
fill 378 160 285 378 160 286 minecraft:red_terracotta
setblock 378 160 287 minecraft:stripped_oak_log
fill 378 160 288 378 160 291 minecraft:red_terracotta
fill 378 160 300 378 160 301 minecraft:red_terracotta
setblock 378 160 302 minecraft:stripped_oak_log
fill 378 160 303 378 160 306 minecraft:red_terracotta
setblock 378 160 307 minecraft:stripped_oak_log
fill 378 160 308 378 160 311 minecraft:red_terracotta
fill 378 160 312 385 160 312 minecraft:stripped_oak_log
fill 378 160 313 378 162 313 minecraft:red_terracotta
fill 378 160 314 385 162 315 minecraft:stripped_oak_log
setblock 379 160 278 minecraft:light[level=15]
setblock 379 160 286 minecraft:light[level=15]
setblock 379 160 294 minecraft:light[level=15]
fill 379 160 302 379 160 305 minecraft:red_terracotta
setblock 379 160 306 minecraft:stripped_oak_log
fill 379 160 307 379 160 310 minecraft:red_terracotta
fill 379 160 311 385 160 311 minecraft:stripped_oak_log
fill 379 160 313 385 162 313 minecraft:stripped_oak_log
setblock 380 160 305 minecraft:green_concrete
fill 380 160 306 380 160 308 minecraft:red_terracotta
fill 380 160 309 385 162 310 minecraft:stripped_oak_log
fill 380 160 316 381 160 316 minecraft:red_terracotta
fill 381 160 308 385 162 308 minecraft:stripped_oak_log
fill 382 160 316 385 162 316 minecraft:stripped_oak_log
setblock 387 160 278 minecraft:light[level=15]
setblock 387 160 286 minecraft:light[level=15]
setblock 387 160 294 minecraft:light[level=15]
setblock 387 160 302 minecraft:light[level=15]
setblock 387 160 310 minecraft:light[level=15]
setblock 395 160 278 minecraft:light[level=15]
setblock 395 160 286 minecraft:light[level=15]
setblock 395 160 294 minecraft:light[level=15]
setblock 395 160 302 minecraft:light[level=15]
setblock 395 160 310 minecraft:light[level=15]
setblock 398 160 276 minecraft:red_terracotta
fill 399 160 276 399 160 282 minecraft:stripped_oak_log
setblock 399 160 316 minecraft:stripped_oak_log
fill 400 160 276 402 160 277 minecraft:red_terracotta
fill 400 160 278 409 162 282 minecraft:stripped_oak_log
fill 400 160 316 403 160 316 minecraft:red_terracotta
setblock 403 160 276 minecraft:red_terracotta
setblock 403 160 277 minecraft:stripped_oak_log
setblock 403 160 286 minecraft:light[level=15]
setblock 403 160 294 minecraft:light[level=15]
setblock 403 160 302 minecraft:light[level=15]
setblock 403 160 310 minecraft:light[level=15]
fill 403 160 315 404 160 315 minecraft:red_terracotta
setblock 404 160 276 minecraft:stripped_oak_log
fill 404 160 277 405 160 277 minecraft:red_terracotta
setblock 404 160 316 minecraft:stripped_oak_log
fill 405 160 276 407 160 276 minecraft:red_terracotta
fill 405 160 316 408 160 316 minecraft:red_terracotta
fill 406 160 277 409 162 277 minecraft:stripped_oak_log
fill 408 160 276 409 162 276 minecraft:stripped_oak_log
setblock 411 160 278 minecraft:light[level=15]
setblock 411 160 286 minecraft:light[level=15]
setblock 411 160 294 minecraft:light[level=15]
setblock 411 160 302 minecraft:light[level=15]
setblock 411 160 310 minecraft:light[level=15]
fill 416 160 305 416 160 308 minecraft:red_terracotta
setblock 416 160 309 minecraft:stripped_oak_log
fill 416 160 310 416 160 313 minecraft:red_terracotta
fill 416 160 316 417 161 316 minecraft:red_terracotta
setblock 417 160 283 minecraft:stripped_oak_log
fill 417 160 284 417 160 287 minecraft:red_terracotta
setblock 417 160 288 minecraft:stripped_oak_log
fill 417 160 301 417 160 302 minecraft:red_terracotta
setblock 417 160 303 minecraft:stripped_oak_log
fill 417 160 304 417 160 307 minecraft:red_terracotta
setblock 417 160 308 minecraft:stripped_oak_log
fill 417 160 309 417 160 312 minecraft:red_terracotta
setblock 417 160 313 minecraft:stripped_oak_log
fill 417 160 314 417 162 315 minecraft:red_terracotta
fill 418 160 276 418 163 316 minecraft:brown_terracotta
fill 377 161 283 377 161 286 minecraft:red_terracotta
setblock 377 161 287 minecraft:stripped_oak_log
fill 377 161 288 377 161 291 minecraft:red_terracotta
setblock 377 161 292 minecraft:stripped_oak_log
fill 377 161 293 377 161 296 minecraft:red_terracotta
setblock 377 161 297 minecraft:stripped_oak_log
fill 377 161 298 377 161 301 minecraft:red_terracotta
setblock 377 161 302 minecraft:stripped_oak_log
fill 377 161 303 377 161 306 minecraft:red_terracotta
setblock 377 161 307 minecraft:stripped_oak_log
fill 377 161 308 377 161 311 minecraft:red_terracotta
setblock 377 161 312 minecraft:stripped_oak_log
fill 377 161 313 377 164 313 minecraft:red_terracotta
setblock 378 161 285 minecraft:red_terracotta
setblock 378 161 286 minecraft:stripped_oak_log
fill 378 161 287 378 161 290 minecraft:red_terracotta
setblock 378 161 291 minecraft:stripped_oak_log
fill 378 161 292 378 163 293 minecraft:red_terracotta
setblock 378 161 301 minecraft:stripped_oak_log
fill 378 161 302 378 161 305 minecraft:red_terracotta
setblock 378 161 306 minecraft:stripped_oak_log
fill 378 161 307 378 161 310 minecraft:red_terracotta
setblock 378 161 311 minecraft:stripped_oak_log
fill 378 161 312 378 164 312 minecraft:red_terracotta
fill 379 161 303 379 161 304 minecraft:red_terracotta
setblock 379 161 305 minecraft:stripped_oak_log
fill 379 161 306 379 161 309 minecraft:red_terracotta
setblock 379 161 310 minecraft:stripped_oak_log
fill 379 161 311 379 164 311 minecraft:red_terracotta
fill 379 161 312 385 162 312 minecraft:stripped_oak_log
fill 380 161 308 380 177 308 minecraft:stripped_oak_log
fill 380 161 311 385 162 311 minecraft:stripped_oak_log
fill 380 161 316 380 163 316 minecraft:red_terracotta
setblock 381 161 316 minecraft:stripped_oak_log
setblock 398 161 276 minecraft:stripped_oak_log
fill 399 161 276 402 161 276 minecraft:red_terracotta
fill 399 161 277 399 162 282 minecraft:stripped_oak_log
fill 399 161 316 402 161 316 minecraft:red_terracotta
fill 400 161 277 401 161 277 minecraft:red_terracotta
setblock 402 161 277 minecraft:stripped_oak_log
fill 402 161 315 403 161 315 minecraft:red_terracotta
setblock 403 161 276 minecraft:stripped_oak_log
setblock 403 161 277 minecraft:red_terracotta
setblock 403 161 316 minecraft:stripped_oak_log
fill 404 161 276 406 161 276 minecraft:red_terracotta
fill 404 161 277 405 162 277 minecraft:stripped_oak_log
setblock 404 161 315 minecraft:stripped_oak_log
fill 404 161 316 407 161 316 minecraft:red_terracotta
fill 407 161 276 407 162 276 minecraft:stripped_oak_log
setblock 408 161 316 minecraft:stripped_oak_log
fill 411 161 309 415 162 309 minecraft:stripped_oak_log
fill 415 161 316 415 163 316 minecraft:red_terracotta
fill 416 161 305 416 161 307 minecraft:red_terracotta
setblock 416 161 308 minecraft:stripped_oak_log
fill 416 161 309 416 161 312 minecraft:red_terracotta
setblock 416 161 313 minecraft:stripped_oak_log
fill 416 161 314 416 164 314 minecraft:red_terracotta
fill 417 161 284 417 161 286 minecraft:red_terracotta
setblock 417 161 287 minecraft:stripped_oak_log
fill 417 161 288 417 163 289 minecraft:red_terracotta
setblock 417 161 302 minecraft:stripped_oak_log
fill 417 161 303 417 161 306 minecraft:red_terracotta
setblock 417 161 307 minecraft:stripped_oak_log
fill 417 161 308 417 161 311 minecraft:red_terracotta
setblock 417 161 312 minecraft:stripped_oak_log
fill 417 161 313 417 164 313 minecraft:red_terracotta
fill 377 162 284 377 162 285 minecraft:red_terracotta
setblock 377 162 286 minecraft:stripped_oak_log
fill 377 162 287 377 162 290 minecraft:red_terracotta
setblock 377 162 291 minecraft:stripped_oak_log
fill 377 162 292 377 162 295 minecraft:red_terracotta
setblock 377 162 296 minecraft:stripped_oak_log
fill 377 162 297 377 162 300 minecraft:red_terracotta
setblock 377 162 301 minecraft:stripped_oak_log
fill 377 162 302 377 162 305 minecraft:red_terracotta
setblock 377 162 306 minecraft:stripped_oak_log
fill 377 162 307 377 162 310 minecraft:red_terracotta
setblock 377 162 311 minecraft:stripped_oak_log
setblock 377 162 312 minecraft:red_terracotta
setblock 377 162 316 minecraft:stripped_oak_log
setblock 378 162 285 minecraft:stripped_oak_log
fill 378 162 286 378 162 289 minecraft:red_terracotta
setblock 378 162 290 minecraft:stripped_oak_log
fill 378 162 291 379 164 291 minecraft:red_terracotta
setblock 378 162 294 minecraft:red_terracotta
setblock 378 162 295 minecraft:stripped_oak_log
fill 378 162 301 378 162 304 minecraft:red_terracotta
setblock 378 162 305 minecraft:stripped_oak_log
fill 378 162 306 378 162 309 minecraft:red_terracotta
setblock 378 162 310 minecraft:stripped_oak_log
setblock 378 162 311 minecraft:red_terracotta
fill 378 162 316 379 162 316 minecraft:red_terracotta
setblock 379 162 278 minecraft:light[level=12]
setblock 379 162 285 minecraft:light[level=12]
setblock 379 162 288 minecraft:red_terracotta
setblock 379 162 289 minecraft:stripped_oak_log
fill 379 162 290 379 165 290 minecraft:red_terracotta
setblock 379 162 292 minecraft:light[level=12]
setblock 379 162 299 minecraft:light[level=12]
setblock 379 162 304 minecraft:stripped_oak_log
fill 379 162 305 379 162 308 minecraft:red_terracotta
setblock 379 162 309 minecraft:stripped_oak_log
setblock 379 162 310 minecraft:red_terracotta
setblock 381 162 316 minecraft:red_terracotta
fill 383 162 300 388 218 301 minecraft:stripped_oak_log
fill 384 162 298 387 218 299 minecraft:stripped_oak_log
fill 384 162 302 387 218 302 minecraft:stripped_oak_log
fill 385 162 303 386 218 303 minecraft:stripped_oak_log
setblock 386 162 278 minecraft:light[level=12]
setblock 386 162 285 minecraft:light[level=12]
setblock 386 162 292 minecraft:light[level=12]
setblock 386 162 306 minecraft:light[level=12]
setblock 386 162 313 minecraft:light[level=12]
fill 388 162 299 388 218 299 minecraft:stripped_oak_log
setblock 393 162 278 minecraft:light[level=12]
setblock 393 162 285 minecraft:light[level=12]
setblock 393 162 292 minecraft:light[level=12]
setblock 393 162 299 minecraft:light[level=12]
setblock 393 162 306 minecraft:light[level=12]
setblock 393 162 313 minecraft:light[level=12]
setblock 397 162 276 minecraft:stripped_oak_log
fill 397 162 310 415 162 310 minecraft:stripped_oak_log
fill 398 162 276 401 162 276 minecraft:red_terracotta
fill 398 162 316 401 162 316 minecraft:red_terracotta
setblock 400 162 277 minecraft:red_terracotta
setblock 400 162 285 minecraft:light[level=12]
setblock 400 162 292 minecraft:light[level=12]
setblock 400 162 299 minecraft:light[level=12]
setblock 400 162 306 minecraft:light[level=12]
setblock 400 162 313 minecraft:light[level=12]
fill 400 162 315 402 162 315 minecraft:red_terracotta
setblock 401 162 277 minecraft:stripped_oak_log
setblock 402 162 276 minecraft:stripped_oak_log
setblock 402 162 277 minecraft:red_terracotta
fill 402 162 309 410 162 309 minecraft:stripped_oak_log
setblock 402 162 316 minecraft:stripped_oak_log
fill 403 162 276 405 162 276 minecraft:red_terracotta
fill 403 162 277 403 165 277 minecraft:stripped_oak_log
setblock 403 162 315 minecraft:stripped_oak_log
fill 403 162 316 406 162 316 minecraft:red_terracotta
fill 404 162 315 404 165 315 minecraft:red_terracotta
fill 406 162 276 406 165 276 minecraft:stripped_oak_log
setblock 407 162 285 minecraft:light[level=12]
setblock 407 162 292 minecraft:light[level=12]
setblock 407 162 299 minecraft:light[level=12]
setblock 407 162 306 minecraft:light[level=12]
setblock 407 162 313 minecraft:light[level=12]
setblock 407 162 316 minecraft:stripped_oak_log
fill 408 162 316 408 165 316 minecraft:red_terracotta
setblock 414 162 278 minecraft:light[level=12]
setblock 414 162 285 minecraft:light[level=12]
setblock 414 162 292 minecraft:light[level=12]
setblock 414 162 299 minecraft:light[level=12]
setblock 414 162 306 minecraft:light[level=12]
setblock 414 162 313 minecraft:light[level=12]
fill 414 162 316 414 164 316 minecraft:red_terracotta
fill 416 162 305 416 162 306 minecraft:red_terracotta
setblock 416 162 307 minecraft:stripped_oak_log
fill 416 162 308 416 162 311 minecraft:red_terracotta
setblock 416 162 312 minecraft:stripped_oak_log
fill 416 162 313 416 165 313 minecraft:red_terracotta
setblock 416 162 316 minecraft:red_terracotta
setblock 417 162 285 minecraft:red_terracotta
setblock 417 162 286 minecraft:stripped_oak_log
fill 417 162 287 417 165 287 minecraft:red_terracotta
setblock 417 162 290 minecraft:red_terracotta
setblock 417 162 291 minecraft:stripped_oak_log
fill 417 162 302 417 162 305 minecraft:red_terracotta
setblock 417 162 306 minecraft:stripped_oak_log
fill 417 162 307 417 162 310 minecraft:red_terracotta
setblock 417 162 311 minecraft:stripped_oak_log
fill 417 162 312 417 165 312 minecraft:red_terracotta
setblock 417 162 316 minecraft:stripped_oak_log
setblock 377 163 284 minecraft:red_terracotta
setblock 377 163 285 minecraft:stripped_oak_log
fill 377 163 286 377 163 289 minecraft:red_terracotta
setblock 377 163 290 minecraft:stripped_oak_log
fill 377 163 291 377 163 294 minecraft:red_terracotta
setblock 377 163 295 minecraft:stripped_oak_log
fill 377 163 296 377 163 299 minecraft:red_terracotta
setblock 377 163 300 minecraft:stripped_oak_log
fill 377 163 301 377 163 304 minecraft:red_terracotta
setblock 377 163 305 minecraft:stripped_oak_log
fill 377 163 306 379 163 307 minecraft:red_terracotta
setblock 377 163 308 minecraft:shroomlight
setblock 377 163 309 minecraft:red_terracotta
setblock 377 163 310 minecraft:shroomlight
fill 377 163 311 377 166 311 minecraft:red_terracotta
setblock 377 163 312 minecraft:shroomlight
setblock 377 163 314 minecraft:shroomlight
setblock 377 163 315 minecraft:stripped_oak_log
setblock 377 163 316 minecraft:shroomlight
fill 378 163 285 378 163 288 minecraft:red_terracotta
setblock 378 163 289 minecraft:stripped_oak_log
fill 378 163 290 378 166 290 minecraft:red_terracotta
setblock 378 163 294 minecraft:stripped_oak_log
fill 378 163 295 378 164 297 minecraft:red_terracotta
fill 378 163 301 378 163 303 minecraft:red_terracotta
setblock 378 163 304 minecraft:stripped_oak_log
fill 378 163 305 379 163 305 minecraft:red_terracotta
setblock 378 163 308 minecraft:red_terracotta
setblock 378 163 309 minecraft:shroomlight
fill 378 163 310 378 166 310 minecraft:red_terracotta
setblock 378 163 311 minecraft:shroomlight
setblock 378 163 313 minecraft:shroomlight
setblock 378 163 314 minecraft:stripped_oak_log
setblock 378 163 315 minecraft:shroomlight
fill 378 163 316 378 165 316 minecraft:red_terracotta
setblock 379 163 287 minecraft:red_terracotta
setblock 379 163 288 minecraft:stripped_oak_log
fill 379 163 289 379 166 289 minecraft:red_terracotta
setblock 379 163 292 minecraft:red_terracotta
setblock 379 163 293 minecraft:stripped_oak_log
setblock 379 163 308 minecraft:shroomlight
fill 379 163 309 379 166 309 minecraft:red_terracotta
setblock 379 163 310 minecraft:shroomlight
setblock 379 163 312 minecraft:shroomlight
fill 379 163 313 379 164 313 minecraft:stripped_oak_log
setblock 379 163 314 minecraft:shroomlight
setblock 379 163 315 minecraft:stripped_oak_log
setblock 379 163 316 minecraft:shroomlight
setblock 380 163 309 minecraft:shroomlight
fill 380 163 310 380 177 310 minecraft:stripped_oak_log
setblock 380 163 311 minecraft:shroomlight
fill 380 163 312 380 177 312 minecraft:stripped_oak_log
setblock 380 163 313 minecraft:shroomlight
fill 380 163 314 380 177 314 minecraft:stripped_oak_log
setblock 380 163 315 minecraft:shroomlight
setblock 381 163 308 minecraft:shroomlight
fill 381 163 309 381 177 309 minecraft:stripped_oak_log
setblock 381 163 310 minecraft:shroomlight
fill 381 163 311 381 177 311 minecraft:stripped_oak_log
setblock 381 163 312 minecraft:shroomlight
fill 381 163 313 381 177 313 minecraft:stripped_oak_log
setblock 381 163 314 minecraft:shroomlight
fill 381 163 315 381 165 315 minecraft:stripped_oak_log
setblock 381 163 316 minecraft:shroomlight
fill 382 163 299 382 164 302 minecraft:brown_terracotta
fill 382 163 308 382 177 308 minecraft:stripped_oak_log
setblock 382 163 309 minecraft:shroomlight
fill 382 163 310 382 177 310 minecraft:stripped_oak_log
setblock 382 163 311 minecraft:shroomlight
fill 382 163 312 382 177 312 minecraft:stripped_oak_log
setblock 382 163 313 minecraft:shroomlight
fill 382 163 314 382 177 314 minecraft:stripped_oak_log
setblock 382 163 315 minecraft:shroomlight
setblock 382 163 316 minecraft:stripped_oak_log
fill 383 163 298 383 164 299 minecraft:brown_terracotta
fill 383 163 302 383 164 303 minecraft:brown_terracotta
setblock 383 163 308 minecraft:shroomlight
fill 383 163 309 383 177 309 minecraft:stripped_oak_log
setblock 383 163 310 minecraft:shroomlight
fill 383 163 311 383 177 311 minecraft:stripped_oak_log
setblock 383 163 312 minecraft:shroomlight
fill 383 163 313 383 177 313 minecraft:stripped_oak_log
setblock 383 163 314 minecraft:shroomlight
fill 383 163 315 383 177 315 minecraft:stripped_oak_log
setblock 383 163 316 minecraft:shroomlight
fill 384 163 297 387 164 297 minecraft:brown_terracotta
fill 384 163 303 384 164 304 minecraft:brown_terracotta
fill 384 163 308 384 177 308 minecraft:stripped_oak_log
setblock 384 163 309 minecraft:shroomlight
fill 384 163 310 384 177 310 minecraft:stripped_oak_log
setblock 384 163 311 minecraft:shroomlight
fill 384 163 312 384 177 312 minecraft:stripped_oak_log
setblock 384 163 313 minecraft:shroomlight
fill 384 163 314 384 177 314 minecraft:stripped_oak_log
setblock 384 163 315 minecraft:shroomlight
fill 384 163 316 384 166 316 minecraft:stripped_oak_log
fill 385 163 304 387 164 304 minecraft:brown_terracotta
setblock 385 163 308 minecraft:shroomlight
fill 385 163 309 385 177 309 minecraft:stripped_oak_log
setblock 385 163 310 minecraft:shroomlight
fill 385 163 311 396 163 311 minecraft:stripped_oak_log
setblock 385 163 312 minecraft:shroomlight
fill 385 163 313 385 177 313 minecraft:stripped_oak_log
setblock 385 163 314 minecraft:shroomlight
fill 385 163 315 385 177 315 minecraft:stripped_oak_log
setblock 385 163 316 minecraft:shroomlight
fill 386 163 310 407 163 310 minecraft:stripped_oak_log
fill 387 163 303 388 164 303 minecraft:brown_terracotta
fill 388 163 298 388 164 298 minecraft:brown_terracotta
fill 388 163 302 389 164 302 minecraft:brown_terracotta
fill 389 163 299 389 164 301 minecraft:brown_terracotta
setblock 396 163 276 minecraft:stripped_oak_log
fill 397 163 276 398 165 276 minecraft:red_terracotta
fill 397 163 309 408 163 309 minecraft:stripped_oak_log
fill 397 163 316 400 163 316 minecraft:red_terracotta
setblock 399 163 276 minecraft:shroomlight
setblock 399 163 277 minecraft:red_terracotta
setblock 399 163 278 minecraft:shroomlight
fill 399 163 279 399 183 279 minecraft:stripped_oak_log
setblock 399 163 280 minecraft:shroomlight
fill 399 163 281 399 183 281 minecraft:stripped_oak_log
setblock 399 163 282 minecraft:shroomlight
fill 399 163 315 401 163 315 minecraft:red_terracotta
setblock 400 163 276 minecraft:red_terracotta
setblock 400 163 277 minecraft:shroomlight
fill 400 163 278 400 167 278 minecraft:stripped_oak_log
setblock 400 163 279 minecraft:shroomlight
fill 400 163 280 400 183 280 minecraft:stripped_oak_log
setblock 400 163 281 minecraft:shroomlight
fill 400 163 282 400 183 282 minecraft:stripped_oak_log
setblock 401 163 276 minecraft:shroomlight
fill 401 163 277 401 166 277 minecraft:red_terracotta
setblock 401 163 278 minecraft:shroomlight
fill 401 163 279 401 183 279 minecraft:stripped_oak_log
setblock 401 163 280 minecraft:shroomlight
fill 401 163 281 401 183 281 minecraft:stripped_oak_log
setblock 401 163 282 minecraft:shroomlight
setblock 401 163 316 minecraft:stripped_oak_log
fill 402 163 276 402 166 276 minecraft:red_terracotta
setblock 402 163 277 minecraft:shroomlight
fill 402 163 278 402 183 278 minecraft:stripped_oak_log
setblock 402 163 279 minecraft:shroomlight
fill 402 163 280 402 183 280 minecraft:stripped_oak_log
setblock 402 163 281 minecraft:shroomlight
fill 402 163 282 402 183 282 minecraft:stripped_oak_log
setblock 402 163 315 minecraft:stripped_oak_log
fill 402 163 316 405 163 316 minecraft:red_terracotta
setblock 403 163 276 minecraft:shroomlight
setblock 403 163 278 minecraft:shroomlight
fill 403 163 279 403 183 279 minecraft:stripped_oak_log
setblock 403 163 280 minecraft:shroomlight
fill 403 163 281 403 183 281 minecraft:stripped_oak_log
setblock 403 163 282 minecraft:shroomlight
fill 403 163 315 403 166 315 minecraft:red_terracotta
fill 404 163 276 404 164 276 minecraft:red_terracotta
setblock 404 163 277 minecraft:shroomlight
fill 404 163 278 404 183 278 minecraft:stripped_oak_log
setblock 404 163 279 minecraft:shroomlight
fill 404 163 280 404 183 280 minecraft:stripped_oak_log
setblock 404 163 281 minecraft:shroomlight
fill 404 163 282 404 183 282 minecraft:stripped_oak_log
setblock 405 163 276 minecraft:shroomlight
fill 405 163 277 405 183 277 minecraft:stripped_oak_log
setblock 405 163 278 minecraft:shroomlight
fill 405 163 279 405 183 279 minecraft:stripped_oak_log
setblock 405 163 280 minecraft:shroomlight
fill 405 163 281 405 183 281 minecraft:stripped_oak_log
setblock 405 163 282 minecraft:shroomlight
fill 405 163 315 405 164 315 minecraft:red_terracotta
setblock 406 163 277 minecraft:shroomlight
fill 406 163 278 406 183 278 minecraft:stripped_oak_log
setblock 406 163 279 minecraft:shroomlight
fill 406 163 280 406 183 280 minecraft:stripped_oak_log
setblock 406 163 281 minecraft:shroomlight
fill 406 163 282 406 183 282 minecraft:stripped_oak_log
setblock 406 163 316 minecraft:stripped_oak_log
setblock 407 163 276 minecraft:shroomlight
fill 407 163 277 407 181 277 minecraft:stripped_oak_log
setblock 407 163 278 minecraft:shroomlight
fill 407 163 279 407 183 279 minecraft:stripped_oak_log
setblock 407 163 280 minecraft:shroomlight
fill 407 163 281 407 183 281 minecraft:stripped_oak_log
setblock 407 163 282 minecraft:shroomlight
fill 407 163 316 407 166 316 minecraft:red_terracotta
fill 408 163 276 408 167 276 minecraft:stripped_oak_log
setblock 408 163 277 minecraft:shroomlight
fill 408 163 278 408 183 278 minecraft:stripped_oak_log
setblock 408 163 279 minecraft:shroomlight
fill 408 163 280 408 183 280 minecraft:stripped_oak_log
setblock 408 163 281 minecraft:shroomlight
fill 408 163 282 408 183 282 minecraft:stripped_oak_log
setblock 409 163 276 minecraft:shroomlight
fill 409 163 277 409 179 277 minecraft:stripped_oak_log
setblock 409 163 278 minecraft:shroomlight
fill 409 163 279 409 183 279 minecraft:stripped_oak_log
setblock 409 163 280 minecraft:shroomlight
fill 409 163 281 409 183 281 minecraft:stripped_oak_log
setblock 409 163 282 minecraft:shroomlight
fill 410 163 309 415 163 309 minecraft:orange_terracotta
fill 412 163 316 413 165 316 minecraft:red_terracotta
fill 415 163 310 415 163 311 minecraft:red_terracotta
fill 415 163 315 416 163 315 minecraft:red_terracotta
setblock 416 163 305 minecraft:red_terracotta
setblock 416 163 306 minecraft:stripped_oak_log
fill 416 163 307 416 163 310 minecraft:red_terracotta
setblock 416 163 311 minecraft:stripped_oak_log
fill 416 163 312 416 166 312 minecraft:red_terracotta
setblock 416 163 316 minecraft:stripped_oak_log
setblock 417 163 285 minecraft:stripped_oak_log
fill 417 163 286 417 166 286 minecraft:red_terracotta
setblock 417 163 290 minecraft:stripped_oak_log
fill 417 163 291 417 163 294 minecraft:red_terracotta
fill 417 163 301 417 163 304 minecraft:red_terracotta
setblock 417 163 305 minecraft:stripped_oak_log
fill 417 163 306 417 163 309 minecraft:red_terracotta
setblock 417 163 310 minecraft:stripped_oak_log
fill 417 163 311 417 166 311 minecraft:red_terracotta
setblock 417 163 314 minecraft:red_terracotta
setblock 417 163 315 minecraft:stripped_oak_log
fill 417 163 316 417 166 316 minecraft:red_terracotta
fill 376 164 275 376 167 317 minecraft:light_gray_terracotta
fill 377 164 275 418 167 275 minecraft:light_gray_terracotta
setblock 377 164 284 minecraft:stripped_oak_log
fill 377 164 285 377 164 288 minecraft:red_terracotta
setblock 377 164 289 minecraft:stripped_oak_log
fill 377 164 290 377 164 293 minecraft:red_terracotta
setblock 377 164 294 minecraft:stripped_oak_log
fill 377 164 295 377 164 298 minecraft:red_terracotta
setblock 377 164 299 minecraft:stripped_oak_log
fill 377 164 300 377 164 303 minecraft:red_terracotta
setblock 377 164 304 minecraft:stripped_oak_log
fill 377 164 305 377 164 308 minecraft:red_terracotta
setblock 377 164 309 minecraft:stripped_oak_log
fill 377 164 310 377 165 310 minecraft:red_terracotta
fill 377 164 312 377 165 312 minecraft:red_terracotta
setblock 377 164 314 minecraft:stripped_oak_log
fill 377 164 315 377 165 316 minecraft:red_terracotta
fill 377 164 317 418 167 317 minecraft:light_gray_terracotta
fill 378 164 285 378 164 287 minecraft:red_terracotta
setblock 378 164 288 minecraft:stripped_oak_log
fill 378 164 289 378 167 289 minecraft:red_terracotta
setblock 378 164 292 minecraft:red_terracotta
setblock 378 164 293 minecraft:stripped_oak_log
fill 378 164 294 379 166 294 minecraft:red_terracotta
setblock 378 164 298 minecraft:stripped_oak_log
fill 378 164 299 378 164 302 minecraft:red_terracotta
setblock 378 164 303 minecraft:stripped_oak_log
fill 378 164 304 378 164 307 minecraft:red_terracotta
setblock 378 164 308 minecraft:stripped_oak_log
fill 378 164 309 378 165 309 minecraft:red_terracotta
fill 378 164 311 378 165 311 minecraft:red_terracotta
setblock 378 164 313 minecraft:stripped_oak_log
fill 378 164 314 378 165 315 minecraft:red_terracotta
setblock 379 164 287 minecraft:stripped_oak_log
fill 379 164 288 379 167 288 minecraft:red_terracotta
setblock 379 164 292 minecraft:stripped_oak_log
fill 379 164 293 379 167 293 minecraft:red_terracotta
fill 379 164 295 379 165 295 minecraft:red_terracotta
setblock 379 164 306 minecraft:red_terracotta
setblock 379 164 307 minecraft:stripped_oak_log
fill 379 164 308 379 165 308 minecraft:red_terracotta
fill 379 164 310 379 165 310 minecraft:red_terracotta
setblock 379 164 312 minecraft:stripped_oak_log
fill 379 164 314 379 165 314 minecraft:stripped_oak_log
fill 379 164 315 379 164 316 minecraft:red_terracotta
fill 380 164 309 380 165 309 minecraft:stripped_oak_log
fill 380 164 311 380 165 311 minecraft:stripped_oak_log
fill 380 164 313 380 165 313 minecraft:stripped_oak_log
fill 380 164 315 380 164 316 minecraft:stripped_oak_log
fill 381 164 298 381 164 302 minecraft:brown_terracotta
fill 381 164 308 381 165 308 minecraft:stripped_oak_log
fill 381 164 310 381 165 310 minecraft:stripped_oak_log
fill 381 164 312 381 165 312 minecraft:stripped_oak_log
fill 381 164 314 381 165 314 minecraft:stripped_oak_log
fill 381 164 316 382 165 316 minecraft:red_terracotta
fill 382 164 297 382 164 298 minecraft:brown_terracotta
fill 382 164 303 382 164 304 minecraft:brown_terracotta
fill 382 164 309 382 165 309 minecraft:stripped_oak_log
fill 382 164 311 382 165 311 minecraft:stripped_oak_log
fill 382 164 313 382 165 313 minecraft:stripped_oak_log
fill 382 164 315 382 165 315 minecraft:stripped_oak_log
fill 383 164 296 383 164 297 minecraft:brown_terracotta
setblock 383 164 304 minecraft:brown_terracotta
fill 383 164 308 383 165 308 minecraft:stripped_oak_log
fill 383 164 310 383 165 310 minecraft:stripped_oak_log
fill 383 164 312 383 165 312 minecraft:stripped_oak_log
fill 383 164 314 383 165 314 minecraft:stripped_oak_log
fill 383 164 316 383 165 316 minecraft:stripped_oak_log
fill 384 164 296 388 164 296 minecraft:brown_terracotta
fill 384 164 305 387 164 305 minecraft:brown_terracotta
fill 384 164 309 384 165 309 minecraft:stripped_oak_log
fill 384 164 311 391 164 311 minecraft:stripped_oak_log
fill 384 164 313 384 165 313 minecraft:stripped_oak_log
fill 384 164 315 384 165 315 minecraft:stripped_oak_log
fill 385 164 308 385 165 308 minecraft:stripped_oak_log
fill 385 164 310 396 164 310 minecraft:stripped_oak_log
fill 385 164 312 385 165 312 minecraft:stripped_oak_log
fill 385 164 314 385 165 314 minecraft:stripped_oak_log
fill 385 164 316 385 165 316 minecraft:stripped_oak_log
fill 388 164 297 389 164 297 minecraft:brown_terracotta
fill 388 164 304 389 164 304 minecraft:brown_terracotta
fill 389 164 298 390 164 298 minecraft:brown_terracotta
fill 389 164 303 390 164 303 minecraft:brown_terracotta
fill 390 164 299 390 164 302 minecraft:brown_terracotta
setblock 395 164 276 minecraft:stripped_oak_log
fill 396 164 276 396 167 276 minecraft:red_terracotta
fill 396 164 316 399 164 316 minecraft:red_terracotta
fill 397 164 310 405 164 310 minecraft:orange_terracotta
setblock 398 164 277 minecraft:red_terracotta
fill 398 164 315 400 164 315 minecraft:red_terracotta
setblock 399 164 276 minecraft:red_terracotta
fill 399 164 277 399 164 278 minecraft:stripped_oak_log
fill 399 164 280 399 165 280 minecraft:stripped_oak_log
fill 399 164 282 399 165 282 minecraft:stripped_oak_log
setblock 400 164 276 minecraft:stripped_oak_log
fill 400 164 277 400 165 277 minecraft:red_terracotta
fill 400 164 279 400 165 279 minecraft:stripped_oak_log
fill 400 164 281 400 165 281 minecraft:stripped_oak_log
setblock 400 164 316 minecraft:stripped_oak_log
fill 401 164 276 401 165 276 minecraft:red_terracotta
fill 401 164 278 401 165 278 minecraft:stripped_oak_log
fill 401 164 280 401 165 280 minecraft:stripped_oak_log
fill 401 164 282 401 165 282 minecraft:stripped_oak_log
setblock 401 164 315 minecraft:stripped_oak_log
fill 401 164 316 404 164 316 minecraft:red_terracotta
fill 402 164 277 402 165 277 minecraft:red_terracotta
fill 402 164 279 402 165 279 minecraft:stripped_oak_log
fill 402 164 281 402 165 281 minecraft:stripped_oak_log
fill 402 164 315 402 167 315 minecraft:red_terracotta
fill 403 164 276 403 165 276 minecraft:red_terracotta
fill 403 164 278 403 165 278 minecraft:stripped_oak_log
fill 403 164 280 403 165 280 minecraft:stripped_oak_log
fill 403 164 282 403 165 282 minecraft:stripped_oak_log
fill 404 164 277 404 165 277 minecraft:stripped_oak_log
fill 404 164 279 404 165 279 minecraft:stripped_oak_log
fill 404 164 281 404 165 281 minecraft:stripped_oak_log
setblock 405 164 276 minecraft:stripped_oak_log
fill 405 164 278 405 165 278 minecraft:stripped_oak_log
fill 405 164 280 405 165 280 minecraft:stripped_oak_log
fill 405 164 282 405 165 282 minecraft:stripped_oak_log
setblock 405 164 316 minecraft:stripped_oak_log
fill 406 164 277 406 165 277 minecraft:stripped_oak_log
fill 406 164 279 406 165 279 minecraft:stripped_oak_log
fill 406 164 281 406 165 281 minecraft:stripped_oak_log
setblock 406 164 315 minecraft:stripped_oak_log
fill 406 164 316 406 167 316 minecraft:red_terracotta
fill 407 164 276 407 165 276 minecraft:stripped_oak_log
fill 407 164 278 407 165 278 minecraft:stripped_oak_log
fill 407 164 280 407 165 280 minecraft:stripped_oak_log
fill 407 164 282 407 165 282 minecraft:stripped_oak_log
fill 408 164 277 408 165 277 minecraft:stripped_oak_log
fill 408 164 279 408 165 279 minecraft:stripped_oak_log
fill 408 164 281 408 165 281 minecraft:stripped_oak_log
fill 409 164 276 409 165 276 minecraft:stripped_oak_log
fill 409 164 278 409 165 278 minecraft:stripped_oak_log
fill 409 164 280 409 165 280 minecraft:stripped_oak_log
fill 409 164 282 409 165 282 minecraft:stripped_oak_log
setblock 409 164 316 minecraft:red_terracotta
setblock 410 164 316 minecraft:stripped_oak_log
fill 411 164 316 411 167 316 minecraft:red_terracotta
fill 414 164 312 414 166 312 minecraft:brown_terracotta
fill 414 164 315 415 164 315 minecraft:red_terracotta
fill 415 164 309 415 164 310 minecraft:red_terracotta
setblock 415 164 311 minecraft:stripped_oak_log
fill 415 164 312 415 166 313 minecraft:red_terracotta
setblock 415 164 316 minecraft:stripped_oak_log
setblock 416 164 305 minecraft:stripped_oak_log
fill 416 164 306 416 164 309 minecraft:red_terracotta
setblock 416 164 310 minecraft:stripped_oak_log
fill 416 164 311 416 167 311 minecraft:red_terracotta
setblock 416 164 315 minecraft:stripped_oak_log
fill 416 164 316 416 167 316 minecraft:red_terracotta
fill 417 164 285 417 167 285 minecraft:red_terracotta
setblock 417 164 288 minecraft:red_terracotta
setblock 417 164 289 minecraft:stripped_oak_log
fill 417 164 290 417 164 293 minecraft:red_terracotta
setblock 417 164 294 minecraft:stripped_oak_log
fill 417 164 295 417 164 298 minecraft:red_terracotta
setblock 417 164 299 minecraft:stripped_oak_log
fill 417 164 300 417 164 303 minecraft:red_terracotta
setblock 417 164 304 minecraft:stripped_oak_log
fill 417 164 305 417 164 308 minecraft:red_terracotta
setblock 417 164 309 minecraft:stripped_oak_log
fill 417 164 310 417 167 310 minecraft:red_terracotta
setblock 417 164 314 minecraft:stripped_oak_log
fill 417 164 315 417 167 315 minecraft:red_terracotta
fill 418 164 276 418 167 316 minecraft:light_gray_terracotta
setblock 377 165 283 minecraft:stripped_oak_log
fill 377 165 284 377 165 287 minecraft:red_terracotta
setblock 377 165 288 minecraft:stripped_oak_log
fill 377 165 289 377 165 292 minecraft:red_terracotta
setblock 377 165 293 minecraft:stripped_oak_log
fill 377 165 294 377 165 297 minecraft:red_terracotta
setblock 377 165 298 minecraft:stripped_oak_log
fill 377 165 299 377 165 302 minecraft:red_terracotta
setblock 377 165 303 minecraft:stripped_oak_log
fill 377 165 304 377 165 307 minecraft:red_terracotta
setblock 377 165 308 minecraft:stripped_oak_log
fill 377 165 309 377 168 309 minecraft:red_terracotta
setblock 377 165 313 minecraft:stripped_oak_log
setblock 377 165 314 minecraft:red_terracotta
fill 378 165 285 378 165 286 minecraft:red_terracotta
setblock 378 165 287 minecraft:stripped_oak_log
fill 378 165 288 378 168 288 minecraft:red_terracotta
setblock 378 165 291 minecraft:red_terracotta
setblock 378 165 292 minecraft:stripped_oak_log
fill 378 165 293 378 168 293 minecraft:red_terracotta
fill 378 165 295 378 165 296 minecraft:red_terracotta
setblock 378 165 297 minecraft:stripped_oak_log
fill 378 165 298 378 165 301 minecraft:red_terracotta
setblock 378 165 302 minecraft:stripped_oak_log
fill 378 165 303 378 165 306 minecraft:red_terracotta
setblock 378 165 307 minecraft:stripped_oak_log
fill 378 165 308 378 168 308 minecraft:red_terracotta
setblock 378 165 312 minecraft:stripped_oak_log
fill 378 165 313 379 165 313 minecraft:red_terracotta
fill 379 165 287 379 168 287 minecraft:red_terracotta
setblock 379 165 291 minecraft:stripped_oak_log
fill 379 165 292 380 167 292 minecraft:red_terracotta
setblock 379 165 296 minecraft:stripped_oak_log
fill 379 165 307 379 166 307 minecraft:red_terracotta
setblock 379 165 311 minecraft:stripped_oak_log
setblock 379 165 312 minecraft:red_terracotta
setblock 379 165 315 minecraft:red_terracotta
setblock 379 165 316 minecraft:stripped_oak_log
setblock 380 165 289 minecraft:red_terracotta
setblock 380 165 290 minecraft:stripped_oak_log
fill 380 165 291 380 168 291 minecraft:red_terracotta
fill 380 165 293 380 166 293 minecraft:red_terracotta
setblock 380 165 315 minecraft:stripped_oak_log
fill 380 165 316 380 168 316 minecraft:red_terracotta
fill 384 165 311 385 165 311 minecraft:stripped_oak_log
setblock 385 165 310 minecraft:stripped_oak_log
fill 386 165 310 386 165 311 minecraft:orange_terracotta
fill 387 165 310 395 165 310 minecraft:orange_terracotta
setblock 394 165 276 minecraft:stripped_oak_log
setblock 394 165 316 minecraft:stripped_oak_log
fill 395 165 276 395 168 276 minecraft:red_terracotta
fill 395 165 316 398 165 316 minecraft:red_terracotta
fill 396 165 315 399 165 315 minecraft:red_terracotta
setblock 397 165 277 minecraft:red_terracotta
setblock 398 165 277 minecraft:stripped_oak_log
fill 398 165 314 400 165 314 minecraft:red_terracotta
setblock 399 165 276 minecraft:stripped_oak_log
fill 399 165 277 399 168 277 minecraft:red_terracotta
setblock 399 165 278 minecraft:stripped_oak_log
setblock 399 165 316 minecraft:stripped_oak_log
fill 400 165 276 400 168 276 minecraft:red_terracotta
setblock 400 165 315 minecraft:stripped_oak_log
fill 400 165 316 403 165 316 minecraft:red_terracotta
setblock 401 165 314 minecraft:stripped_oak_log
fill 401 165 315 401 168 315 minecraft:red_terracotta
fill 402 165 314 403 167 314 minecraft:red_terracotta
setblock 404 165 276 minecraft:stripped_oak_log
setblock 404 165 316 minecraft:stripped_oak_log
setblock 405 165 276 minecraft:red_terracotta
setblock 405 165 315 minecraft:stripped_oak_log
fill 405 165 316 405 168 316 minecraft:red_terracotta
fill 406 165 315 407 167 315 minecraft:red_terracotta
setblock 409 165 316 minecraft:stripped_oak_log
fill 410 165 316 410 168 316 minecraft:red_terracotta
fill 411 165 315 414 165 315 minecraft:red_terracotta
fill 414 165 314 415 165 314 minecraft:red_terracotta
setblock 414 165 316 minecraft:stripped_oak_log
fill 415 165 308 415 165 309 minecraft:red_terracotta
setblock 415 165 310 minecraft:stripped_oak_log
fill 415 165 311 415 168 311 minecraft:red_terracotta
setblock 415 165 315 minecraft:stripped_oak_log
fill 415 165 316 415 168 316 minecraft:red_terracotta
fill 416 165 290 417 165 292 minecraft:red_terracotta
setblock 416 165 304 minecraft:stripped_oak_log
fill 416 165 305 416 165 308 minecraft:red_terracotta
setblock 416 165 309 minecraft:stripped_oak_log
fill 416 165 310 416 168 310 minecraft:red_terracotta
setblock 416 165 314 minecraft:stripped_oak_log
fill 416 165 315 416 168 315 minecraft:red_terracotta
setblock 417 165 288 minecraft:stripped_oak_log
fill 417 165 289 417 168 289 minecraft:red_terracotta
setblock 417 165 293 minecraft:stripped_oak_log
fill 417 165 294 417 165 297 minecraft:red_terracotta
setblock 417 165 298 minecraft:stripped_oak_log
fill 417 165 299 417 165 302 minecraft:red_terracotta
setblock 417 165 303 minecraft:stripped_oak_log
fill 417 165 304 417 165 307 minecraft:red_terracotta
setblock 417 165 308 minecraft:stripped_oak_log
fill 417 165 309 417 168 309 minecraft:red_terracotta
setblock 417 165 313 minecraft:stripped_oak_log
fill 417 165 314 417 168 314 minecraft:red_terracotta
setblock 377 166 282 minecraft:stripped_oak_log
fill 377 166 283 377 166 286 minecraft:red_terracotta
setblock 377 166 287 minecraft:stripped_oak_log
fill 377 166 288 377 166 291 minecraft:red_terracotta
setblock 377 166 292 minecraft:stripped_oak_log
fill 377 166 293 377 166 296 minecraft:red_terracotta
setblock 377 166 297 minecraft:stripped_oak_log
fill 377 166 298 377 166 301 minecraft:red_terracotta
setblock 377 166 302 minecraft:stripped_oak_log
fill 377 166 303 377 166 306 minecraft:red_terracotta
setblock 377 166 307 minecraft:stripped_oak_log
setblock 377 166 308 minecraft:shroomlight
setblock 377 166 310 minecraft:shroomlight
setblock 377 166 312 minecraft:shroomlight
fill 377 166 313 377 169 313 minecraft:red_terracotta
setblock 377 166 314 minecraft:shroomlight
fill 377 166 315 377 167 315 minecraft:red_terracotta
setblock 377 166 316 minecraft:shroomlight
setblock 378 166 276 minecraft:stripped_oak_log
setblock 378 166 285 minecraft:red_terracotta
setblock 378 166 286 minecraft:stripped_oak_log
fill 378 166 287 378 169 287 minecraft:red_terracotta
setblock 378 166 291 minecraft:stripped_oak_log
fill 378 166 292 378 169 292 minecraft:red_terracotta
setblock 378 166 295 minecraft:red_terracotta
setblock 378 166 296 minecraft:stripped_oak_log
fill 378 166 297 378 166 300 minecraft:red_terracotta
setblock 378 166 301 minecraft:stripped_oak_log
fill 378 166 302 378 166 305 minecraft:red_terracotta
setblock 378 166 306 minecraft:stripped_oak_log
fill 378 166 307 378 169 307 minecraft:red_terracotta
setblock 378 166 309 minecraft:shroomlight
setblock 378 166 311 minecraft:shroomlight
fill 378 166 312 378 169 312 minecraft:red_terracotta
setblock 378 166 313 minecraft:shroomlight
fill 378 166 314 378 167 314 minecraft:red_terracotta
setblock 378 166 315 minecraft:shroomlight
setblock 378 166 316 minecraft:stripped_oak_log
fill 379 166 276 380 168 276 minecraft:red_terracotta
fill 379 166 286 379 168 286 minecraft:red_terracotta
setblock 379 166 290 minecraft:stripped_oak_log
fill 379 166 291 379 169 291 minecraft:red_terracotta
setblock 379 166 295 minecraft:stripped_oak_log
fill 379 166 296 379 167 298 minecraft:red_terracotta
setblock 379 166 308 minecraft:shroomlight
setblock 379 166 310 minecraft:shroomlight
fill 379 166 311 379 169 311 minecraft:red_terracotta
setblock 379 166 312 minecraft:shroomlight
fill 379 166 313 379 167 313 minecraft:red_terracotta
setblock 379 166 314 minecraft:shroomlight
setblock 379 166 315 minecraft:stripped_oak_log
setblock 379 166 316 minecraft:shroomlight
setblock 380 166 289 minecraft:stripped_oak_log
fill 380 166 290 380 169 290 minecraft:red_terracotta
setblock 380 166 294 minecraft:stripped_oak_log
setblock 380 166 309 minecraft:shroomlight
setblock 380 166 311 minecraft:shroomlight
setblock 380 166 313 minecraft:shroomlight
setblock 380 166 315 minecraft:shroomlight
setblock 381 166 308 minecraft:shroomlight
setblock 381 166 310 minecraft:shroomlight
setblock 381 166 312 minecraft:shroomlight
setblock 381 166 314 minecraft:shroomlight
fill 381 166 315 381 168 315 minecraft:red_terracotta
setblock 381 166 316 minecraft:shroomlight
setblock 382 166 309 minecraft:shroomlight
setblock 382 166 311 minecraft:shroomlight
setblock 382 166 313 minecraft:shroomlight
setblock 382 166 315 minecraft:shroomlight
setblock 382 166 316 minecraft:red_terracotta
setblock 383 166 308 minecraft:shroomlight
setblock 383 166 310 minecraft:shroomlight
setblock 383 166 312 minecraft:shroomlight
setblock 383 166 314 minecraft:shroomlight
setblock 383 166 316 minecraft:shroomlight
setblock 384 166 309 minecraft:shroomlight
setblock 384 166 311 minecraft:shroomlight
setblock 384 166 313 minecraft:shroomlight
setblock 384 166 315 minecraft:shroomlight
setblock 385 166 308 minecraft:shroomlight
setblock 385 166 310 minecraft:shroomlight
fill 385 166 311 385 177 311 minecraft:stripped_oak_log
setblock 385 166 312 minecraft:shroomlight
setblock 385 166 314 minecraft:shroomlight
setblock 385 166 316 minecraft:shroomlight
setblock 392 166 276 minecraft:red_terracotta
setblock 393 166 276 minecraft:stripped_oak_log
setblock 393 166 316 minecraft:stripped_oak_log
fill 394 166 276 394 169 276 minecraft:red_terracotta
fill 394 166 316 397 166 316 minecraft:red_terracotta
fill 395 166 277 396 166 277 minecraft:red_terracotta
fill 395 166 315 398 166 315 minecraft:red_terracotta
setblock 397 166 276 minecraft:red_terracotta
setblock 397 166 277 minecraft:stripped_oak_log
fill 397 166 314 399 166 314 minecraft:red_terracotta
setblock 398 166 276 minecraft:stripped_oak_log
fill 398 166 277 398 169 277 minecraft:red_terracotta
setblock 398 166 316 minecraft:stripped_oak_log
setblock 399 166 276 minecraft:shroomlight
setblock 399 166 278 minecraft:shroomlight
setblock 399 166 280 minecraft:shroomlight
setblock 399 166 282 minecraft:shroomlight
setblock 399 166 315 minecraft:stripped_oak_log
fill 399 166 316 402 166 316 minecraft:red_terracotta
setblock 400 166 277 minecraft:shroomlight
setblock 400 166 279 minecraft:shroomlight
setblock 400 166 281 minecraft:shroomlight
setblock 400 166 314 minecraft:stripped_oak_log
fill 400 166 315 400 169 315 minecraft:red_terracotta
setblock 401 166 276 minecraft:shroomlight
setblock 401 166 278 minecraft:shroomlight
setblock 401 166 280 minecraft:shroomlight
setblock 401 166 282 minecraft:shroomlight
fill 401 166 314 401 169 314 minecraft:red_terracotta
setblock 402 166 277 minecraft:shroomlight
setblock 402 166 279 minecraft:shroomlight
setblock 402 166 281 minecraft:shroomlight
setblock 403 166 276 minecraft:shroomlight
fill 403 166 277 403 169 277 minecraft:red_terracotta
setblock 403 166 278 minecraft:shroomlight
setblock 403 166 280 minecraft:shroomlight
setblock 403 166 282 minecraft:shroomlight
setblock 403 166 316 minecraft:stripped_oak_log
fill 404 166 276 404 169 276 minecraft:red_terracotta
setblock 404 166 277 minecraft:shroomlight
setblock 404 166 279 minecraft:shroomlight
setblock 404 166 281 minecraft:shroomlight
setblock 404 166 314 minecraft:red_terracotta
setblock 404 166 315 minecraft:stripped_oak_log
fill 404 166 316 404 169 316 minecraft:red_terracotta
setblock 405 166 276 minecraft:shroomlight
setblock 405 166 278 minecraft:shroomlight
setblock 405 166 280 minecraft:shroomlight
setblock 405 166 282 minecraft:shroomlight
fill 405 166 315 405 169 315 minecraft:red_terracotta
fill 406 166 276 406 167 276 minecraft:red_terracotta
setblock 406 166 277 minecraft:shroomlight
setblock 406 166 279 minecraft:shroomlight
setblock 406 166 281 minecraft:shroomlight
setblock 407 166 276 minecraft:shroomlight
setblock 407 166 278 minecraft:shroomlight
setblock 407 166 280 minecraft:shroomlight
setblock 407 166 282 minecraft:shroomlight
setblock 408 166 277 minecraft:shroomlight
setblock 408 166 279 minecraft:shroomlight
setblock 408 166 281 minecraft:shroomlight
setblock 408 166 315 minecraft:red_terracotta
setblock 408 166 316 minecraft:stripped_oak_log
setblock 409 166 276 minecraft:shroomlight
setblock 409 166 278 minecraft:shroomlight
setblock 409 166 280 minecraft:shroomlight
setblock 409 166 282 minecraft:shroomlight
setblock 409 166 315 minecraft:stripped_oak_log
fill 409 166 316 409 169 316 minecraft:red_terracotta
fill 410 166 315 413 166 315 minecraft:red_terracotta
fill 412 166 314 414 166 314 minecraft:red_terracotta
setblock 412 166 316 minecraft:red_terracotta
setblock 413 166 316 minecraft:stripped_oak_log
fill 414 166 281 416 167 281 minecraft:iron_bars
setblock 414 166 315 minecraft:stripped_oak_log
fill 414 166 316 414 169 316 minecraft:red_terracotta
fill 415 166 276 417 166 276 minecraft:red_terracotta
fill 415 166 307 415 166 308 minecraft:red_terracotta
setblock 415 166 309 minecraft:stripped_oak_log
fill 415 166 310 415 169 310 minecraft:red_terracotta
setblock 415 166 314 minecraft:stripped_oak_log
fill 415 166 315 415 169 315 minecraft:red_terracotta
setblock 416 166 288 minecraft:stripped_oak_log
fill 416 166 289 416 166 292 minecraft:red_terracotta
setblock 416 166 293 minecraft:stripped_oak_log
fill 416 166 294 417 166 296 minecraft:red_terracotta
setblock 416 166 303 minecraft:stripped_oak_log
fill 416 166 304 416 166 307 minecraft:red_terracotta
setblock 416 166 308 minecraft:stripped_oak_log
fill 416 166 309 416 169 309 minecraft:red_terracotta
setblock 416 166 313 minecraft:stripped_oak_log
fill 416 166 314 416 169 314 minecraft:red_terracotta
fill 417 166 284 417 168 284 minecraft:red_terracotta
setblock 417 166 287 minecraft:stripped_oak_log
fill 417 166 288 417 169 288 minecraft:red_terracotta
fill 417 166 290 417 166 291 minecraft:red_terracotta
setblock 417 166 292 minecraft:stripped_oak_log
fill 417 166 293 417 169 293 minecraft:red_terracotta
setblock 417 166 297 minecraft:stripped_oak_log
fill 417 166 298 417 166 301 minecraft:red_terracotta
setblock 417 166 302 minecraft:stripped_oak_log
fill 417 166 303 417 166 306 minecraft:red_terracotta
setblock 417 166 307 minecraft:stripped_oak_log
fill 417 166 308 417 169 308 minecraft:red_terracotta
setblock 417 166 312 minecraft:stripped_oak_log
fill 417 166 313 417 169 313 minecraft:red_terracotta
setblock 377 167 276 minecraft:stripped_oak_log
fill 377 167 277 377 169 278 minecraft:red_terracotta
setblock 377 167 281 minecraft:stripped_oak_log
fill 377 167 282 377 167 285 minecraft:red_terracotta
setblock 377 167 286 minecraft:stripped_oak_log
fill 377 167 287 377 167 290 minecraft:red_terracotta
setblock 377 167 291 minecraft:stripped_oak_log
fill 377 167 292 377 167 295 minecraft:red_terracotta
setblock 377 167 296 minecraft:stripped_oak_log
fill 377 167 297 377 167 300 minecraft:red_terracotta
setblock 377 167 301 minecraft:stripped_oak_log
fill 377 167 302 377 167 305 minecraft:red_terracotta
setblock 377 167 306 minecraft:stripped_oak_log
fill 377 167 307 377 168 308 minecraft:red_terracotta
setblock 377 167 310 minecraft:red_terracotta
setblock 377 167 311 minecraft:stripped_oak_log
fill 377 167 312 377 168 312 minecraft:red_terracotta
fill 377 167 314 377 168 314 minecraft:red_terracotta
setblock 377 167 316 minecraft:stripped_oak_log
fill 378 167 276 378 170 276 minecraft:red_terracotta
setblock 378 167 284 minecraft:red_terracotta
setblock 378 167 285 minecraft:stripped_oak_log
fill 378 167 286 378 170 286 minecraft:red_terracotta
setblock 378 167 290 minecraft:stripped_oak_log
fill 378 167 291 378 170 291 minecraft:red_terracotta
setblock 378 167 294 minecraft:red_terracotta
setblock 378 167 295 minecraft:stripped_oak_log
fill 378 167 296 378 167 299 minecraft:red_terracotta
setblock 378 167 300 minecraft:stripped_oak_log
fill 378 167 301 378 167 304 minecraft:red_terracotta
setblock 378 167 305 minecraft:stripped_oak_log
fill 378 167 306 378 170 306 minecraft:red_terracotta
setblock 378 167 309 minecraft:red_terracotta
setblock 378 167 310 minecraft:stripped_oak_log
fill 378 167 311 378 168 311 minecraft:red_terracotta
fill 378 167 313 378 168 313 minecraft:red_terracotta
setblock 378 167 315 minecraft:stripped_oak_log
fill 378 167 316 379 168 316 minecraft:red_terracotta
setblock 379 167 289 minecraft:stripped_oak_log
fill 379 167 290 379 170 290 minecraft:red_terracotta
setblock 379 167 294 minecraft:stripped_oak_log
fill 379 167 295 380 169 295 minecraft:red_terracotta
setblock 379 167 299 minecraft:stripped_oak_log
setblock 379 167 308 minecraft:red_terracotta
fill 379 167 309 380 167 309 minecraft:stripped_oak_log
fill 379 167 310 379 168 310 minecraft:red_terracotta
fill 379 167 312 379 168 312 minecraft:red_terracotta
setblock 379 167 314 minecraft:stripped_oak_log
fill 379 167 315 380 168 315 minecraft:red_terracotta
fill 380 167 289 380 169 289 minecraft:red_terracotta
setblock 380 167 293 minecraft:stripped_oak_log
fill 380 167 294 380 170 294 minecraft:red_terracotta
fill 380 167 311 380 168 311 minecraft:stripped_oak_log
fill 380 167 313 380 168 313 minecraft:stripped_oak_log
setblock 381 167 276 minecraft:red_terracotta
fill 381 167 308 381 168 308 minecraft:stripped_oak_log
fill 381 167 310 381 168 310 minecraft:stripped_oak_log
fill 381 167 312 381 168 312 minecraft:stripped_oak_log
fill 381 167 314 381 168 314 minecraft:stripped_oak_log
setblock 381 167 316 minecraft:red_terracotta
setblock 382 167 276 minecraft:stripped_oak_log
fill 382 167 309 382 168 309 minecraft:stripped_oak_log
fill 382 167 311 382 168 311 minecraft:stripped_oak_log
fill 382 167 313 382 168 313 minecraft:stripped_oak_log
fill 382 167 315 382 167 316 minecraft:stripped_oak_log
fill 383 167 308 383 168 308 minecraft:stripped_oak_log
fill 383 167 310 383 168 310 minecraft:stripped_oak_log
fill 383 167 312 383 168 312 minecraft:stripped_oak_log
fill 383 167 314 383 168 314 minecraft:stripped_oak_log
fill 383 167 316 384 168 316 minecraft:red_terracotta
fill 384 167 309 384 168 309 minecraft:stripped_oak_log
fill 384 167 311 384 168 311 minecraft:stripped_oak_log
fill 384 167 313 384 168 313 minecraft:stripped_oak_log
fill 384 167 315 384 168 315 minecraft:stripped_oak_log
fill 385 167 308 385 168 308 minecraft:stripped_oak_log
fill 385 167 310 385 168 310 minecraft:stripped_oak_log
fill 385 167 312 385 168 312 minecraft:stripped_oak_log
fill 385 167 314 385 168 314 minecraft:stripped_oak_log
fill 385 167 316 385 168 316 minecraft:stripped_oak_log
setblock 391 167 276 minecraft:red_terracotta
setblock 391 167 316 minecraft:red_terracotta
setblock 392 167 276 minecraft:stripped_oak_log
setblock 392 167 316 minecraft:stripped_oak_log
fill 393 167 276 393 169 277 minecraft:red_terracotta
setblock 393 167 315 minecraft:stripped_oak_log
fill 393 167 316 396 167 316 minecraft:red_terracotta
fill 394 167 277 395 167 277 minecraft:red_terracotta
fill 394 167 315 397 167 315 minecraft:red_terracotta
fill 395 167 314 398 167 314 minecraft:red_terracotta
setblock 396 167 277 minecraft:stripped_oak_log
setblock 397 167 276 minecraft:stripped_oak_log
fill 397 167 277 397 169 278 minecraft:red_terracotta
setblock 397 167 316 minecraft:stripped_oak_log
fill 398 167 276 399 168 276 minecraft:red_terracotta
fill 398 167 278 399 167 278 minecraft:red_terracotta
setblock 398 167 315 minecraft:stripped_oak_log
fill 398 167 316 401 167 316 minecraft:red_terracotta
fill 399 167 280 399 168 280 minecraft:stripped_oak_log
fill 399 167 282 399 168 282 minecraft:stripped_oak_log
setblock 399 167 314 minecraft:stripped_oak_log
fill 399 167 315 399 170 315 minecraft:red_terracotta
setblock 400 167 277 minecraft:red_terracotta
fill 400 167 279 400 168 279 minecraft:stripped_oak_log
fill 400 167 281 400 168 281 minecraft:stripped_oak_log
fill 400 167 314 400 170 314 minecraft:red_terracotta
setblock 401 167 276 minecraft:red_terracotta
fill 401 167 277 401 167 278 minecraft:stripped_oak_log
fill 401 167 280 401 168 280 minecraft:stripped_oak_log
fill 401 167 282 401 168 282 minecraft:stripped_oak_log
setblock 402 167 276 minecraft:stripped_oak_log
fill 402 167 277 402 168 277 minecraft:red_terracotta
fill 402 167 279 402 168 279 minecraft:stripped_oak_log
fill 402 167 281 402 168 281 minecraft:stripped_oak_log
setblock 402 167 316 minecraft:stripped_oak_log
fill 403 167 276 403 168 276 minecraft:red_terracotta
fill 403 167 278 403 168 278 minecraft:stripped_oak_log
fill 403 167 280 403 168 280 minecraft:stripped_oak_log
fill 403 167 282 403 168 282 minecraft:stripped_oak_log
setblock 403 167 315 minecraft:stripped_oak_log
fill 403 167 316 403 170 316 minecraft:red_terracotta
fill 404 167 277 404 168 277 minecraft:stripped_oak_log
fill 404 167 279 404 168 279 minecraft:stripped_oak_log
fill 404 167 281 404 168 281 minecraft:stripped_oak_log
setblock 404 167 314 minecraft:stripped_oak_log
fill 404 167 315 404 170 315 minecraft:red_terracotta
fill 405 167 276 405 168 276 minecraft:red_terracotta
fill 405 167 278 405 168 278 minecraft:stripped_oak_log
fill 405 167 280 405 168 280 minecraft:stripped_oak_log
fill 405 167 282 405 168 282 minecraft:stripped_oak_log
fill 405 167 314 405 170 314 minecraft:red_terracotta
fill 406 167 277 406 168 277 minecraft:stripped_oak_log
fill 406 167 279 406 168 279 minecraft:stripped_oak_log
fill 406 167 281 406 168 281 minecraft:stripped_oak_log
setblock 407 167 276 minecraft:stripped_oak_log
fill 407 167 278 407 168 278 minecraft:stripped_oak_log
fill 407 167 280 407 168 280 minecraft:stripped_oak_log
fill 407 167 282 407 168 282 minecraft:stripped_oak_log
setblock 407 167 316 minecraft:stripped_oak_log
fill 408 167 277 408 168 277 minecraft:stripped_oak_log
fill 408 167 279 408 168 279 minecraft:stripped_oak_log
fill 408 167 281 408 168 281 minecraft:stripped_oak_log
setblock 408 167 315 minecraft:stripped_oak_log
fill 408 167 316 408 170 316 minecraft:red_terracotta
setblock 409 167 276 minecraft:stripped_oak_log
fill 409 167 278 409 168 278 minecraft:stripped_oak_log
fill 409 167 280 409 168 280 minecraft:stripped_oak_log
fill 409 167 282 409 168 282 minecraft:stripped_oak_log
fill 409 167 315 412 167 315 minecraft:red_terracotta
fill 410 167 314 413 167 314 minecraft:red_terracotta
setblock 412 167 276 minecraft:stripped_oak_log
setblock 412 167 316 minecraft:stripped_oak_log
fill 413 167 276 416 167 276 minecraft:red_terracotta
fill 413 167 312 413 168 312 minecraft:brown_terracotta
setblock 413 167 315 minecraft:stripped_oak_log
fill 413 167 316 413 170 316 minecraft:red_terracotta
fill 414 167 311 414 167 313 minecraft:red_terracotta
setblock 414 167 314 minecraft:stripped_oak_log
fill 414 167 315 414 170 315 minecraft:red_terracotta
setblock 415 167 307 minecraft:red_terracotta
setblock 415 167 308 minecraft:stripped_oak_log
fill 415 167 309 415 170 309 minecraft:red_terracotta
setblock 415 167 312 minecraft:red_terracotta
setblock 415 167 313 minecraft:stripped_oak_log
fill 415 167 314 415 170 314 minecraft:red_terracotta
fill 416 167 288 416 167 291 minecraft:red_terracotta
setblock 416 167 292 minecraft:stripped_oak_log
fill 416 167 293 416 167 296 minecraft:red_terracotta
setblock 416 167 297 minecraft:stripped_oak_log
fill 416 167 298 416 167 301 minecraft:red_terracotta
setblock 416 167 302 minecraft:stripped_oak_log
fill 416 167 303 416 167 306 minecraft:red_terracotta
setblock 416 167 307 minecraft:stripped_oak_log
fill 416 167 308 416 170 308 minecraft:red_terracotta
setblock 416 167 312 minecraft:stripped_oak_log
fill 416 167 313 416 170 313 minecraft:red_terracotta
setblock 417 167 276 minecraft:stripped_oak_log
fill 417 167 277 417 169 278 minecraft:red_terracotta
setblock 417 167 286 minecraft:stripped_oak_log
fill 417 167 287 417 170 287 minecraft:red_terracotta
setblock 417 167 290 minecraft:red_terracotta
setblock 417 167 291 minecraft:stripped_oak_log
fill 417 167 292 417 170 292 minecraft:red_terracotta
fill 417 167 294 417 167 295 minecraft:red_terracotta
setblock 417 167 296 minecraft:stripped_oak_log
fill 417 167 297 417 167 300 minecraft:red_terracotta
setblock 417 167 301 minecraft:stripped_oak_log
fill 417 167 302 417 167 305 minecraft:red_terracotta
setblock 417 167 306 minecraft:stripped_oak_log
fill 417 167 307 417 170 307 minecraft:red_terracotta
setblock 417 167 311 minecraft:stripped_oak_log
fill 417 167 312 417 170 312 minecraft:red_terracotta
setblock 417 167 316 minecraft:stripped_oak_log
fill 376 168 275 376 171 317 minecraft:orange_terracotta
fill 377 168 275 418 171 275 minecraft:orange_terracotta
fill 377 168 276 377 171 276 minecraft:red_terracotta
setblock 377 168 279 minecraft:red_terracotta
setblock 377 168 280 minecraft:stripped_oak_log
fill 377 168 281 377 168 284 minecraft:red_terracotta
setblock 377 168 285 minecraft:stripped_oak_log
fill 377 168 286 377 168 289 minecraft:red_terracotta
setblock 377 168 290 minecraft:stripped_oak_log
fill 377 168 291 377 168 294 minecraft:red_terracotta
setblock 377 168 295 minecraft:stripped_oak_log
fill 377 168 296 377 168 299 minecraft:red_terracotta
setblock 377 168 300 minecraft:stripped_oak_log
fill 377 168 301 377 168 304 minecraft:red_terracotta
setblock 377 168 305 minecraft:stripped_oak_log
fill 377 168 306 377 171 306 minecraft:red_terracotta
setblock 377 168 310 minecraft:stripped_oak_log
fill 377 168 311 377 171 311 minecraft:red_terracotta
setblock 377 168 315 minecraft:stripped_oak_log
setblock 377 168 316 minecraft:red_terracotta
fill 377 168 317 418 171 317 minecraft:orange_terracotta
setblock 378 168 284 minecraft:stripped_oak_log
fill 378 168 285 378 171 285 minecraft:red_terracotta
setblock 378 168 289 minecraft:stripped_oak_log
fill 378 168 290 378 171 290 minecraft:red_terracotta
setblock 378 168 294 minecraft:stripped_oak_log
fill 378 168 295 378 168 298 minecraft:red_terracotta
setblock 378 168 299 minecraft:stripped_oak_log
fill 378 168 300 378 168 303 minecraft:red_terracotta
setblock 378 168 304 minecraft:stripped_oak_log
fill 378 168 305 378 171 305 minecraft:red_terracotta
setblock 378 168 309 minecraft:stripped_oak_log
fill 378 168 310 378 171 310 minecraft:red_terracotta
setblock 378 168 314 minecraft:stripped_oak_log
setblock 378 168 315 minecraft:red_terracotta
setblock 379 168 278 minecraft:light[level=15]
setblock 379 168 285 minecraft:light[level=12]
setblock 379 168 288 minecraft:stripped_oak_log
fill 379 168 289 379 171 289 minecraft:red_terracotta
setblock 379 168 292 minecraft:red_terracotta
setblock 379 168 293 minecraft:stripped_oak_log
fill 379 168 294 379 171 294 minecraft:red_terracotta
fill 379 168 296 379 168 297 minecraft:red_terracotta
setblock 379 168 298 minecraft:stripped_oak_log
fill 379 168 299 379 170 300 minecraft:red_terracotta
setblock 379 168 302 minecraft:light[level=15]
setblock 379 168 306 minecraft:light[level=12]
setblock 379 168 308 minecraft:stripped_oak_log
setblock 379 168 309 minecraft:red_terracotta
setblock 379 168 313 minecraft:stripped_oak_log
setblock 379 168 314 minecraft:red_terracotta
setblock 380 168 292 minecraft:stripped_oak_log
fill 380 168 293 380 171 293 minecraft:red_terracotta
setblock 380 168 296 minecraft:red_terracotta
setblock 380 168 309 minecraft:stripped_oak_log
setblock 381 168 276 minecraft:stripped_oak_log
setblock 381 168 316 minecraft:stripped_oak_log
fill 382 168 276 383 170 276 minecraft:red_terracotta
setblock 382 168 315 minecraft:stripped_oak_log
fill 382 168 316 382 171 316 minecraft:red_terracotta
setblock 386 168 278 minecraft:light[level=12]
setblock 386 168 285 minecraft:light[level=12]
setblock 386 168 292 minecraft:light[level=12]
setblock 386 168 306 minecraft:light[level=12]
setblock 386 168 313 minecraft:light[level=12]
setblock 387 168 278 minecraft:light[level=15]
setblock 387 168 286 minecraft:light[level=15]
setblock 387 168 294 minecraft:light[level=15]
setblock 387 168 310 minecraft:light[level=15]
fill 388 168 276 390 168 276 minecraft:red_terracotta
fill 389 168 316 390 168 316 minecraft:red_terracotta
setblock 391 168 276 minecraft:stripped_oak_log
fill 391 168 313 393 168 315 minecraft:terracotta
setblock 391 168 316 minecraft:stripped_oak_log
fill 392 168 276 392 170 277 minecraft:red_terracotta
fill 392 168 316 395 168 316 minecraft:red_terracotta
setblock 393 168 278 minecraft:light[level=12]
setblock 393 168 285 minecraft:light[level=12]
setblock 393 168 292 minecraft:light[level=12]
setblock 393 168 299 minecraft:light[level=12]
setblock 393 168 306 minecraft:light[level=12]
setblock 394 168 277 minecraft:red_terracotta
fill 394 168 314 396 168 315 minecraft:red_terracotta
setblock 395 168 277 minecraft:stripped_oak_log
fill 395 168 278 396 170 278 minecraft:red_terracotta
setblock 395 168 286 minecraft:light[level=15]
setblock 395 168 294 minecraft:light[level=15]
setblock 395 168 302 minecraft:light[level=15]
setblock 395 168 310 minecraft:light[level=15]
setblock 396 168 276 minecraft:stripped_oak_log
fill 396 168 277 396 171 277 minecraft:red_terracotta
setblock 396 168 316 minecraft:stripped_oak_log
fill 397 168 276 397 171 276 minecraft:red_terracotta
setblock 397 168 314 minecraft:red_terracotta
setblock 397 168 315 minecraft:stripped_oak_log
fill 397 168 316 400 168 316 minecraft:red_terracotta
setblock 398 168 278 minecraft:red_terracotta
setblock 398 168 313 minecraft:red_terracotta
setblock 398 168 314 minecraft:stripped_oak_log
fill 398 168 315 398 171 315 minecraft:red_terracotta
setblock 399 168 278 minecraft:stripped_oak_log
setblock 399 168 313 minecraft:stripped_oak_log
fill 399 168 314 399 171 314 minecraft:red_terracotta
setblock 400 168 277 minecraft:stripped_oak_log
fill 400 168 278 400 171 278 minecraft:red_terracotta
setblock 400 168 285 minecraft:light[level=12]
setblock 400 168 292 minecraft:light[level=12]
setblock 400 168 299 minecraft:light[level=12]
setblock 400 168 306 minecraft:light[level=12]
fill 400 168 313 400 169 313 minecraft:red_terracotta
setblock 401 168 276 minecraft:stripped_oak_log
fill 401 168 277 401 171 277 minecraft:red_terracotta
setblock 401 168 278 minecraft:stripped_oak_log
setblock 401 168 316 minecraft:stripped_oak_log
fill 402 168 276 402 171 276 minecraft:red_terracotta
setblock 402 168 314 minecraft:red_terracotta
setblock 402 168 315 minecraft:stripped_oak_log
fill 402 168 316 402 171 316 minecraft:red_terracotta
setblock 403 168 286 minecraft:light[level=15]
setblock 403 168 294 minecraft:light[level=15]
setblock 403 168 302 minecraft:light[level=15]
setblock 403 168 310 minecraft:light[level=15]
setblock 403 168 314 minecraft:stripped_oak_log
fill 403 168 315 403 171 315 minecraft:red_terracotta
fill 404 168 314 404 171 314 minecraft:red_terracotta
setblock 406 168 276 minecraft:stripped_oak_log
fill 406 168 314 406 168 315 minecraft:red_terracotta
setblock 406 168 316 minecraft:stripped_oak_log
fill 407 168 276 410 168 276 minecraft:red_terracotta
setblock 407 168 285 minecraft:light[level=12]
setblock 407 168 292 minecraft:light[level=12]
setblock 407 168 299 minecraft:light[level=12]
setblock 407 168 306 minecraft:light[level=12]
setblock 407 168 313 minecraft:light[level=12]
setblock 407 168 314 minecraft:red_terracotta
setblock 407 168 315 minecraft:stripped_oak_log
fill 407 168 316 407 171 316 minecraft:red_terracotta
setblock 408 168 314 minecraft:stripped_oak_log
fill 408 168 315 411 168 315 minecraft:red_terracotta
fill 409 168 314 412 168 314 minecraft:red_terracotta
setblock 411 168 276 minecraft:stripped_oak_log
setblock 411 168 278 minecraft:light[level=15]
setblock 411 168 286 minecraft:light[level=15]
setblock 411 168 294 minecraft:light[level=15]
setblock 411 168 302 minecraft:light[level=15]
setblock 411 168 310 minecraft:light[level=15]
setblock 411 168 316 minecraft:stripped_oak_log
fill 412 168 276 415 168 276 minecraft:red_terracotta
setblock 412 168 315 minecraft:stripped_oak_log
fill 412 168 316 412 171 316 minecraft:red_terracotta
setblock 413 168 311 minecraft:brown_terracotta
setblock 413 168 313 minecraft:red_terracotta
setblock 413 168 314 minecraft:stripped_oak_log
fill 413 168 315 413 171 315 minecraft:red_terracotta
setblock 414 168 278 minecraft:light[level=12]
setblock 414 168 285 minecraft:light[level=12]
setblock 414 168 292 minecraft:light[level=12]
setblock 414 168 299 minecraft:light[level=12]
setblock 414 168 306 minecraft:light[level=12]
fill 414 168 310 414 168 312 minecraft:red_terracotta
setblock 414 168 313 minecraft:stripped_oak_log
schedule function dropper:buildpart/68_4 1t
