fill 109 279 522 112 280 522 minecraft:blue_concrete
fill 109 279 529 110 280 531 minecraft:light_blue_concrete
fill 109 279 533 111 280 535 minecraft:light_blue_concrete
fill 109 279 536 109 280 536 minecraft:blue_concrete
fill 109 279 544 119 280 544 minecraft:blue_concrete
fill 110 279 527 111 280 527 minecraft:blue_concrete
fill 110 279 528 110 280 528 minecraft:light_blue_concrete
fill 110 279 536 115 280 537 minecraft:light_blue_concrete
fill 110 279 538 110 280 538 minecraft:blue_concrete
fill 111 279 528 111 279 530 minecraft:black_concrete
fill 111 279 531 111 280 531 minecraft:light_blue_concrete
fill 111 279 538 124 280 538 minecraft:light_blue_concrete
fill 112 279 527 112 279 528 minecraft:black_concrete
fill 112 279 530 112 279 531 minecraft:black_concrete
fill 112 279 532 112 280 533 minecraft:blue_concrete
fill 112 279 534 112 280 535 minecraft:light_blue_concrete
fill 113 279 522 118 280 522 minecraft:light_blue_concrete
fill 113 279 526 113 279 527 minecraft:black_concrete
fill 113 279 531 113 279 532 minecraft:black_concrete
fill 113 279 533 122 280 534 minecraft:blue_concrete
fill 113 279 535 113 280 535 minecraft:light_blue_concrete
fill 113 279 539 122 280 539 minecraft:light_blue_concrete
fill 113 279 540 114 280 540 minecraft:blue_concrete
fill 114 279 513 114 280 513 minecraft:blue_concrete
fill 114 279 518 124 280 518 minecraft:blue_concrete
fill 114 279 526 115 279 526 minecraft:black_concrete
fill 114 279 532 115 279 532 minecraft:black_concrete
fill 114 279 535 121 280 535 minecraft:blue_concrete
fill 114 279 545 114 280 545 minecraft:blue_concrete
fill 115 279 523 119 280 523 minecraft:light_blue_concrete
fill 115 279 527 116 279 527 minecraft:black_concrete
fill 115 279 531 116 279 531 minecraft:black_concrete
fill 115 279 540 120 280 540 minecraft:light_blue_concrete
fill 116 279 519 124 280 519 minecraft:blue_concrete
fill 116 279 524 119 280 524 minecraft:light_blue_concrete
fill 116 279 526 116 280 526 minecraft:blue_concrete
fill 116 279 528 117 279 528 minecraft:black_concrete
fill 116 279 530 117 279 530 minecraft:black_concrete
fill 116 279 532 124 280 532 minecraft:blue_concrete
fill 116 279 536 119 280 536 minecraft:blue_concrete
fill 116 279 537 125 280 537 minecraft:light_blue_concrete
fill 117 279 525 119 280 527 minecraft:light_blue_concrete
setblock 117 279 529 minecraft:black_concrete
fill 117 279 531 125 280 531 minecraft:blue_concrete
fill 118 279 520 125 280 520 minecraft:blue_concrete
fill 118 279 528 118 280 530 minecraft:light_blue_concrete
fill 119 279 521 125 280 522 minecraft:blue_concrete
fill 119 279 528 119 280 529 minecraft:light_blue_concrete
fill 119 279 530 125 280 530 minecraft:blue_concrete
fill 120 279 523 126 280 525 minecraft:blue_concrete
fill 120 279 526 120 280 526 minecraft:light_blue_concrete
fill 120 279 527 126 280 529 minecraft:blue_concrete
fill 120 279 536 126 280 536 minecraft:light_blue_concrete
fill 121 279 526 126 280 526 minecraft:blue_concrete
fill 121 279 540 125 280 540 minecraft:blue_concrete
fill 122 279 535 127 280 535 minecraft:light_blue_concrete
fill 123 279 516 123 280 516 minecraft:light_blue_concrete
fill 123 279 533 123 280 533 minecraft:blue_concrete
fill 123 279 534 128 280 534 minecraft:light_blue_concrete
fill 123 279 539 126 280 539 minecraft:blue_concrete
fill 124 279 517 124 280 517 minecraft:light_blue_concrete
fill 124 279 533 129 280 533 minecraft:light_blue_concrete
fill 125 279 518 125 280 519 minecraft:light_blue_concrete
fill 125 279 532 129 280 532 minecraft:light_blue_concrete
fill 125 279 538 127 280 538 minecraft:blue_concrete
fill 126 279 519 126 280 521 minecraft:light_blue_concrete
fill 126 279 522 126 280 522 minecraft:blue_concrete
fill 126 279 530 129 280 531 minecraft:light_blue_concrete
fill 126 279 537 127 280 537 minecraft:blue_concrete
fill 127 279 520 127 280 529 minecraft:light_blue_concrete
fill 127 279 536 128 280 536 minecraft:blue_concrete
fill 128 279 522 128 280 529 minecraft:light_blue_concrete
fill 128 279 535 128 280 535 minecraft:blue_concrete
fill 129 279 524 129 280 529 minecraft:light_blue_concrete
fill 129 279 534 129 280 534 minecraft:blue_concrete
fill 130 279 529 130 280 529 minecraft:light_blue_concrete
fill 95 280 511 97 280 551 minecraft:basalt
fill 98 280 511 98 280 528 minecraft:basalt
fill 98 280 530 98 280 551 minecraft:basalt
fill 99 280 511 99 280 523 minecraft:basalt
fill 99 280 535 99 280 551 minecraft:basalt
fill 100 280 511 100 280 521 minecraft:basalt
fill 100 280 537 100 280 551 minecraft:basalt
fill 101 280 511 101 280 519 minecraft:basalt
fill 101 280 539 101 280 551 minecraft:basalt
fill 102 280 511 102 280 518 minecraft:basalt
fill 102 280 540 102 280 551 minecraft:basalt
fill 103 280 511 103 280 517 minecraft:basalt
fill 103 280 541 103 280 551 minecraft:basalt
fill 104 280 511 104 280 516 minecraft:basalt
fill 104 280 542 104 280 551 minecraft:basalt
fill 105 280 511 106 280 515 minecraft:basalt
fill 105 280 543 106 280 551 minecraft:basalt
fill 107 280 511 108 280 514 minecraft:basalt
fill 107 280 544 108 280 551 minecraft:basalt
fill 109 280 511 113 280 513 minecraft:basalt
fill 109 280 545 113 280 551 minecraft:basalt
fill 111 280 528 111 280 530 minecraft:shroomlight
fill 112 280 527 112 280 528 minecraft:shroomlight
fill 112 280 530 112 280 531 minecraft:shroomlight
fill 113 280 526 113 280 527 minecraft:shroomlight
fill 113 280 531 113 280 532 minecraft:shroomlight
fill 114 280 511 135 280 512 minecraft:basalt
fill 114 280 526 115 280 526 minecraft:shroomlight
fill 114 280 532 115 280 532 minecraft:shroomlight
fill 114 280 546 135 280 551 minecraft:basalt
fill 115 280 513 135 280 513 minecraft:basalt
fill 115 280 527 116 280 527 minecraft:shroomlight
fill 115 280 531 116 280 531 minecraft:shroomlight
fill 115 280 545 135 280 545 minecraft:basalt
fill 116 280 528 117 280 528 minecraft:shroomlight
fill 116 280 530 117 280 530 minecraft:shroomlight
setblock 117 280 529 minecraft:shroomlight
fill 120 280 514 135 280 514 minecraft:basalt
fill 120 280 544 135 280 544 minecraft:basalt
fill 122 280 515 135 280 515 minecraft:basalt
fill 122 280 543 135 280 543 minecraft:basalt
fill 124 280 516 135 280 516 minecraft:basalt
fill 124 280 542 135 280 542 minecraft:basalt
fill 125 280 517 135 280 517 minecraft:basalt
fill 125 280 541 135 280 541 minecraft:basalt
fill 126 280 518 135 280 518 minecraft:basalt
fill 126 280 540 135 280 540 minecraft:basalt
fill 127 280 519 135 280 519 minecraft:basalt
fill 127 280 539 135 280 539 minecraft:basalt
fill 128 280 520 135 280 521 minecraft:basalt
fill 128 280 537 135 280 538 minecraft:basalt
fill 129 280 522 135 280 523 minecraft:basalt
fill 129 280 535 135 280 536 minecraft:basalt
fill 130 280 524 135 280 528 minecraft:basalt
fill 130 280 530 135 280 534 minecraft:basalt
fill 131 280 529 135 280 529 minecraft:basalt
fill 95 284 511 95 284 513 minecraft:blackstone
setblock 95 284 514 minecraft:smooth_basalt
fill 95 284 515 95 284 518 minecraft:blackstone
setblock 95 284 519 minecraft:smooth_basalt
fill 95 284 520 95 284 523 minecraft:blackstone
setblock 95 284 524 minecraft:smooth_basalt
fill 95 284 525 95 284 528 minecraft:blackstone
setblock 95 284 529 minecraft:smooth_basalt
fill 95 284 530 95 284 533 minecraft:blackstone
setblock 95 284 534 minecraft:smooth_basalt
fill 95 284 535 95 286 536 minecraft:blackstone
setblock 95 284 544 minecraft:smooth_basalt
fill 95 284 545 95 284 548 minecraft:blackstone
setblock 95 284 549 minecraft:smooth_basalt
fill 95 284 550 97 284 551 minecraft:blackstone
fill 96 284 511 96 284 512 minecraft:blackstone
setblock 96 284 513 minecraft:smooth_basalt
fill 96 284 514 96 284 517 minecraft:blackstone
setblock 96 284 527 minecraft:blackstone
setblock 96 284 528 minecraft:smooth_basalt
fill 96 284 529 96 284 532 minecraft:blackstone
setblock 96 284 533 minecraft:smooth_basalt
fill 96 284 546 96 284 547 minecraft:blackstone
setblock 96 284 548 minecraft:smooth_basalt
fill 96 284 549 99 284 549 minecraft:blackstone
setblock 97 284 511 minecraft:blackstone
setblock 97 284 512 minecraft:smooth_basalt
fill 97 284 513 97 285 515 minecraft:blackstone
setblock 97 284 547 minecraft:smooth_basalt
fill 97 284 548 97 287 548 minecraft:blackstone
setblock 98 284 511 minecraft:smooth_basalt
fill 98 284 512 100 284 513 minecraft:blackstone
setblock 98 284 550 minecraft:blackstone
setblock 98 284 551 minecraft:smooth_basalt
fill 99 284 511 102 284 511 minecraft:blackstone
setblock 99 284 550 minecraft:smooth_basalt
fill 99 284 551 102 284 551 minecraft:blackstone
setblock 100 284 549 minecraft:smooth_basalt
fill 100 284 550 103 284 550 minecraft:blackstone
setblock 101 284 512 minecraft:blackstone
setblock 101 284 513 minecraft:smooth_basalt
fill 101 284 549 104 284 549 minecraft:blackstone
setblock 102 284 512 minecraft:smooth_basalt
setblock 103 284 511 minecraft:smooth_basalt
fill 103 284 512 104 286 512 minecraft:blackstone
setblock 103 284 551 minecraft:smooth_basalt
fill 104 284 511 107 284 511 minecraft:blackstone
setblock 104 284 550 minecraft:smooth_basalt
fill 104 284 551 107 284 551 minecraft:blackstone
fill 105 284 550 108 284 550 minecraft:blackstone
setblock 108 284 511 minecraft:smooth_basalt
setblock 108 284 551 minecraft:smooth_basalt
setblock 109 284 550 minecraft:smooth_basalt
fill 109 284 551 112 284 551 minecraft:blackstone
fill 110 284 550 113 284 550 minecraft:blackstone
fill 111 284 511 112 284 511 minecraft:blackstone
setblock 113 284 511 minecraft:smooth_basalt
setblock 113 284 551 minecraft:smooth_basalt
fill 114 284 511 117 284 511 minecraft:blackstone
setblock 114 284 550 minecraft:smooth_basalt
fill 114 284 551 117 284 551 minecraft:blackstone
fill 115 284 550 118 284 550 minecraft:blackstone
setblock 117 284 512 minecraft:smooth_basalt
fill 117 284 549 117 285 549 minecraft:blackstone
setblock 118 284 511 minecraft:smooth_basalt
fill 118 284 512 121 284 512 minecraft:blackstone
setblock 118 284 551 minecraft:smooth_basalt
fill 119 284 511 122 284 511 minecraft:blackstone
fill 119 284 527 123 296 528 minecraft:smooth_basalt
setblock 119 284 550 minecraft:smooth_basalt
fill 119 284 551 122 284 551 minecraft:blackstone
fill 120 284 526 122 286 526 minecraft:smooth_basalt
fill 120 284 529 122 300 529 minecraft:smooth_basalt
fill 120 284 550 122 284 550 minecraft:blackstone
setblock 123 284 511 minecraft:smooth_basalt
setblock 123 284 551 minecraft:smooth_basalt
fill 124 284 511 127 284 511 minecraft:blackstone
fill 124 284 551 124 286 551 minecraft:blackstone
setblock 128 284 511 minecraft:smooth_basalt
fill 129 284 511 132 284 511 minecraft:blackstone
setblock 132 284 512 minecraft:smooth_basalt
setblock 132 284 551 minecraft:blackstone
setblock 133 284 511 minecraft:smooth_basalt
fill 133 284 512 135 285 512 minecraft:blackstone
setblock 133 284 551 minecraft:smooth_basalt
fill 134 284 511 135 286 511 minecraft:blackstone
fill 134 284 513 134 284 514 minecraft:blackstone
setblock 134 284 515 minecraft:smooth_basalt
fill 134 284 516 135 286 516 minecraft:blackstone
setblock 134 284 524 minecraft:blackstone
setblock 134 284 525 minecraft:smooth_basalt
fill 134 284 526 134 284 529 minecraft:blackstone
setblock 134 284 530 minecraft:smooth_basalt
fill 134 284 531 135 284 533 minecraft:blackstone
fill 134 284 551 135 286 551 minecraft:blackstone
setblock 135 284 513 minecraft:blackstone
setblock 135 284 514 minecraft:smooth_basalt
fill 135 284 515 135 287 515 minecraft:blackstone
fill 135 284 517 135 284 518 minecraft:blackstone
setblock 135 284 519 minecraft:smooth_basalt
fill 135 284 520 135 284 523 minecraft:blackstone
setblock 135 284 524 minecraft:smooth_basalt
fill 135 284 525 135 284 528 minecraft:blackstone
setblock 135 284 529 minecraft:smooth_basalt
fill 135 284 530 135 287 530 minecraft:blackstone
setblock 135 284 534 minecraft:smooth_basalt
fill 135 284 535 135 286 536 minecraft:blackstone
fill 135 284 547 135 284 548 minecraft:blackstone
setblock 135 284 549 minecraft:smooth_basalt
fill 135 284 550 135 287 550 minecraft:blackstone
fill 95 285 511 95 285 512 minecraft:blackstone
setblock 95 285 513 minecraft:smooth_basalt
fill 95 285 514 95 285 517 minecraft:blackstone
setblock 95 285 518 minecraft:smooth_basalt
fill 95 285 519 95 285 522 minecraft:blackstone
setblock 95 285 523 minecraft:smooth_basalt
fill 95 285 524 95 285 527 minecraft:blackstone
setblock 95 285 528 minecraft:smooth_basalt
fill 95 285 529 95 285 532 minecraft:blackstone
setblock 95 285 533 minecraft:smooth_basalt
fill 95 285 534 96 287 534 minecraft:blackstone
setblock 95 285 537 minecraft:blackstone
setblock 95 285 538 minecraft:smooth_basalt
fill 95 285 539 95 288 539 minecraft:blackstone
setblock 95 285 543 minecraft:smooth_basalt
fill 95 285 544 95 285 547 minecraft:blackstone
setblock 95 285 548 minecraft:smooth_basalt
fill 95 285 549 96 285 551 minecraft:blackstone
setblock 96 285 511 minecraft:blackstone
setblock 96 285 512 minecraft:smooth_basalt
fill 96 285 513 96 285 516 minecraft:blackstone
setblock 96 285 517 minecraft:smooth_basalt
fill 96 285 518 96 288 518 minecraft:blackstone
setblock 96 285 527 minecraft:smooth_basalt
fill 96 285 528 96 285 531 minecraft:blackstone
setblock 96 285 532 minecraft:smooth_basalt
fill 96 285 533 96 288 533 minecraft:blackstone
fill 96 285 535 96 285 536 minecraft:blackstone
fill 96 285 545 96 285 546 minecraft:blackstone
setblock 96 285 547 minecraft:smooth_basalt
fill 96 285 548 96 288 548 minecraft:blackstone
setblock 97 285 511 minecraft:smooth_basalt
fill 97 285 512 100 285 512 minecraft:blackstone
setblock 97 285 516 minecraft:smooth_basalt
fill 97 285 547 97 288 547 minecraft:blackstone
fill 97 285 549 97 285 550 minecraft:blackstone
setblock 97 285 551 minecraft:smooth_basalt
fill 98 285 511 101 285 511 minecraft:blackstone
fill 98 285 513 99 285 513 minecraft:blackstone
setblock 98 285 549 minecraft:blackstone
setblock 98 285 550 minecraft:smooth_basalt
fill 98 285 551 101 285 551 minecraft:blackstone
setblock 99 285 549 minecraft:smooth_basalt
fill 99 285 550 102 285 550 minecraft:blackstone
setblock 100 285 513 minecraft:smooth_basalt
fill 100 285 549 103 285 549 minecraft:blackstone
setblock 101 285 512 minecraft:smooth_basalt
fill 101 285 513 101 288 513 minecraft:blackstone
setblock 102 285 511 minecraft:smooth_basalt
fill 102 285 512 102 288 512 minecraft:blackstone
setblock 102 285 551 minecraft:smooth_basalt
fill 103 285 511 106 285 511 minecraft:blackstone
setblock 103 285 550 minecraft:smooth_basalt
fill 103 285 551 106 285 551 minecraft:blackstone
fill 104 285 550 107 285 550 minecraft:blackstone
setblock 107 285 511 minecraft:smooth_basalt
setblock 107 285 551 minecraft:smooth_basalt
fill 108 285 511 111 285 511 minecraft:blackstone
setblock 108 285 550 minecraft:smooth_basalt
fill 108 285 551 111 285 551 minecraft:blackstone
fill 109 285 550 112 285 550 minecraft:blackstone
setblock 112 285 511 minecraft:smooth_basalt
setblock 112 285 551 minecraft:smooth_basalt
fill 113 285 511 116 285 511 minecraft:blackstone
setblock 113 285 550 minecraft:smooth_basalt
fill 113 285 551 116 285 551 minecraft:blackstone
fill 114 285 550 117 285 550 minecraft:blackstone
setblock 115 285 512 minecraft:blackstone
setblock 116 285 512 minecraft:smooth_basalt
setblock 116 285 549 minecraft:blackstone
setblock 117 285 511 minecraft:smooth_basalt
fill 117 285 512 120 285 512 minecraft:blackstone
setblock 117 285 551 minecraft:smooth_basalt
fill 118 285 511 121 285 511 minecraft:blackstone
setblock 118 285 550 minecraft:smooth_basalt
fill 118 285 551 121 285 551 minecraft:blackstone
fill 119 285 526 119 286 526 minecraft:blackstone
fill 119 285 529 119 286 529 minecraft:blackstone
fill 119 285 550 121 286 550 minecraft:blackstone
fill 120 285 525 122 287 525 minecraft:blackstone
fill 120 285 530 122 286 530 minecraft:blackstone
setblock 121 285 512 minecraft:smooth_basalt
setblock 122 285 511 minecraft:smooth_basalt
fill 122 285 512 122 288 512 minecraft:blackstone
fill 122 285 521 125 300 524 minecraft:smooth_basalt
fill 122 285 533 124 287 534 minecraft:smooth_basalt
setblock 122 285 551 minecraft:smooth_basalt
fill 123 285 511 126 285 511 minecraft:blackstone
fill 123 285 525 124 300 525 minecraft:smooth_basalt
fill 123 285 526 123 287 526 minecraft:blackstone
fill 123 285 529 123 286 529 minecraft:blackstone
fill 123 285 535 124 288 535 minecraft:smooth_basalt
fill 123 285 551 123 287 551 minecraft:blackstone
fill 125 285 534 125 287 534 minecraft:smooth_basalt
setblock 127 285 511 minecraft:smooth_basalt
fill 128 285 511 131 285 511 minecraft:blackstone
setblock 131 285 512 minecraft:smooth_basalt
setblock 131 285 551 minecraft:blackstone
setblock 132 285 511 minecraft:smooth_basalt
fill 132 285 512 132 288 512 minecraft:blackstone
setblock 132 285 551 minecraft:smooth_basalt
fill 133 285 511 133 288 511 minecraft:blackstone
fill 133 285 513 134 285 513 minecraft:blackstone
fill 133 285 551 133 288 551 minecraft:blackstone
setblock 134 285 514 minecraft:smooth_basalt
fill 134 285 515 134 288 515 minecraft:blackstone
fill 134 285 517 134 285 518 minecraft:blackstone
setblock 134 285 519 minecraft:smooth_basalt
fill 134 285 520 134 285 523 minecraft:blackstone
setblock 134 285 524 minecraft:smooth_basalt
fill 134 285 525 134 285 528 minecraft:blackstone
setblock 134 285 529 minecraft:smooth_basalt
fill 134 285 530 134 285 533 minecraft:blackstone
setblock 134 285 534 minecraft:smooth_basalt
fill 134 285 535 134 288 535 minecraft:blackstone
fill 134 285 550 134 288 550 minecraft:blackstone
setblock 135 285 513 minecraft:smooth_basalt
fill 135 285 514 135 288 514 minecraft:blackstone
setblock 135 285 517 minecraft:blackstone
setblock 135 285 518 minecraft:smooth_basalt
fill 135 285 519 135 285 522 minecraft:blackstone
setblock 135 285 523 minecraft:smooth_basalt
fill 135 285 524 135 285 527 minecraft:blackstone
setblock 135 285 528 minecraft:smooth_basalt
fill 135 285 529 135 288 529 minecraft:blackstone
fill 135 285 531 135 285 532 minecraft:blackstone
setblock 135 285 533 minecraft:smooth_basalt
fill 135 285 534 135 288 534 minecraft:blackstone
setblock 135 285 537 minecraft:blackstone
setblock 135 285 538 minecraft:smooth_basalt
setblock 135 285 547 minecraft:blackstone
setblock 135 285 548 minecraft:smooth_basalt
fill 135 285 549 135 288 549 minecraft:blackstone
setblock 95 286 511 minecraft:blackstone
setblock 95 286 512 minecraft:smooth_basalt
fill 95 286 513 95 286 516 minecraft:blackstone
setblock 95 286 517 minecraft:smooth_basalt
fill 95 286 518 95 286 521 minecraft:blackstone
setblock 95 286 522 minecraft:smooth_basalt
fill 95 286 523 95 286 526 minecraft:blackstone
setblock 95 286 527 minecraft:smooth_basalt
fill 95 286 528 95 286 531 minecraft:blackstone
setblock 95 286 532 minecraft:smooth_basalt
fill 95 286 533 95 289 533 minecraft:blackstone
setblock 95 286 537 minecraft:smooth_basalt
fill 95 286 538 96 288 538 minecraft:blackstone
fill 95 286 540 95 286 541 minecraft:blackstone
setblock 95 286 542 minecraft:smooth_basalt
fill 95 286 543 95 286 546 minecraft:blackstone
setblock 95 286 547 minecraft:smooth_basalt
fill 95 286 548 95 286 551 minecraft:blackstone
setblock 96 286 511 minecraft:smooth_basalt
fill 96 286 512 96 286 515 minecraft:blackstone
setblock 96 286 516 minecraft:smooth_basalt
fill 96 286 517 96 289 517 minecraft:blackstone
fill 96 286 519 96 287 519 minecraft:blackstone
fill 96 286 527 96 286 530 minecraft:blackstone
setblock 96 286 531 minecraft:smooth_basalt
fill 96 286 532 97 288 532 minecraft:blackstone
setblock 96 286 535 minecraft:blackstone
setblock 96 286 536 minecraft:smooth_basalt
fill 96 286 537 96 289 537 minecraft:blackstone
fill 96 286 544 96 286 545 minecraft:blackstone
setblock 96 286 546 minecraft:smooth_basalt
fill 96 286 547 96 289 547 minecraft:blackstone
fill 96 286 549 96 286 550 minecraft:blackstone
setblock 96 286 551 minecraft:smooth_basalt
fill 97 286 511 97 286 514 minecraft:blackstone
setblock 97 286 515 minecraft:smooth_basalt
fill 97 286 516 97 289 516 minecraft:blackstone
fill 97 286 531 97 287 531 minecraft:blackstone
fill 97 286 533 97 286 534 minecraft:blackstone
setblock 97 286 549 minecraft:blackstone
setblock 97 286 550 minecraft:smooth_basalt
fill 97 286 551 100 286 551 minecraft:blackstone
fill 98 286 511 98 286 513 minecraft:blackstone
setblock 98 286 514 minecraft:smooth_basalt
setblock 98 286 549 minecraft:smooth_basalt
fill 98 286 550 101 286 550 minecraft:blackstone
fill 99 286 511 99 286 512 minecraft:blackstone
setblock 99 286 513 minecraft:smooth_basalt
fill 99 286 549 102 286 549 minecraft:blackstone
setblock 100 286 511 minecraft:blackstone
setblock 100 286 512 minecraft:smooth_basalt
fill 100 286 513 100 289 513 minecraft:blackstone
setblock 101 286 511 minecraft:smooth_basalt
fill 101 286 512 101 289 512 minecraft:blackstone
setblock 101 286 551 minecraft:smooth_basalt
fill 102 286 511 105 286 511 minecraft:blackstone
setblock 102 286 550 minecraft:smooth_basalt
fill 102 286 551 105 286 551 minecraft:blackstone
fill 103 286 550 106 286 550 minecraft:blackstone
setblock 106 286 511 minecraft:smooth_basalt
setblock 106 286 551 minecraft:smooth_basalt
fill 107 286 511 110 286 511 minecraft:blackstone
fill 107 286 544 111 287 548 minecraft:blackstone
setblock 107 286 550 minecraft:smooth_basalt
fill 107 286 551 110 286 551 minecraft:blackstone
fill 108 286 550 111 286 550 minecraft:blackstone
setblock 109 286 549 minecraft:blackstone
setblock 111 286 511 minecraft:smooth_basalt
setblock 111 286 551 minecraft:smooth_basalt
fill 112 286 511 115 286 511 minecraft:blackstone
setblock 112 286 550 minecraft:smooth_basalt
fill 112 286 551 115 286 551 minecraft:blackstone
fill 113 286 512 114 286 512 minecraft:blackstone
fill 113 286 550 116 286 550 minecraft:blackstone
setblock 115 286 512 minecraft:smooth_basalt
setblock 116 286 511 minecraft:smooth_basalt
fill 116 286 512 119 286 512 minecraft:blackstone
setblock 116 286 551 minecraft:smooth_basalt
fill 117 286 511 120 286 511 minecraft:blackstone
setblock 117 286 550 minecraft:smooth_basalt
fill 117 286 551 120 286 551 minecraft:blackstone
fill 118 286 526 118 286 529 minecraft:blackstone
fill 118 286 550 118 288 550 minecraft:blackstone
setblock 119 286 525 minecraft:blackstone
setblock 119 286 530 minecraft:blackstone
setblock 120 286 512 minecraft:smooth_basalt
fill 120 286 524 121 287 524 minecraft:blackstone
fill 120 286 531 122 286 531 minecraft:blackstone
setblock 121 286 511 minecraft:smooth_basalt
fill 121 286 512 121 289 512 minecraft:blackstone
fill 121 286 521 121 287 523 minecraft:blackstone
fill 121 286 533 121 287 534 minecraft:blackstone
setblock 121 286 551 minecraft:smooth_basalt
fill 122 286 511 125 286 511 minecraft:blackstone
fill 122 286 520 125 287 520 minecraft:blackstone
fill 122 286 532 125 286 532 minecraft:blackstone
fill 122 286 535 122 287 535 minecraft:blackstone
fill 122 286 551 122 288 551 minecraft:blackstone
fill 123 286 512 123 287 512 minecraft:blackstone
setblock 123 286 530 minecraft:blackstone
fill 123 286 536 124 287 536 minecraft:blackstone
fill 124 286 526 124 286 529 minecraft:blackstone
fill 125 286 525 125 287 525 minecraft:blackstone
setblock 125 286 533 minecraft:blackstone
fill 125 286 535 125 287 535 minecraft:blackstone
setblock 126 286 511 minecraft:smooth_basalt
fill 126 286 521 126 287 524 minecraft:blackstone
fill 127 286 511 130 286 511 minecraft:blackstone
setblock 129 286 512 minecraft:blackstone
setblock 130 286 512 minecraft:smooth_basalt
setblock 130 286 551 minecraft:blackstone
setblock 131 286 511 minecraft:smooth_basalt
fill 131 286 512 131 289 512 minecraft:blackstone
setblock 131 286 551 minecraft:smooth_basalt
fill 132 286 511 132 289 511 minecraft:blackstone
fill 132 286 513 133 286 513 minecraft:blackstone
fill 132 286 551 132 289 551 minecraft:blackstone
fill 133 286 512 134 286 512 minecraft:blackstone
setblock 133 286 514 minecraft:smooth_basalt
fill 133 286 515 133 288 516 minecraft:blackstone
setblock 133 286 529 minecraft:smooth_basalt
fill 133 286 530 134 286 532 minecraft:blackstone
setblock 134 286 513 minecraft:smooth_basalt
fill 134 286 514 134 289 514 minecraft:blackstone
setblock 134 286 517 minecraft:blackstone
setblock 134 286 518 minecraft:smooth_basalt
fill 134 286 519 134 286 522 minecraft:blackstone
setblock 134 286 523 minecraft:smooth_basalt
fill 134 286 524 134 286 527 minecraft:blackstone
setblock 134 286 528 minecraft:smooth_basalt
fill 134 286 529 134 289 529 minecraft:blackstone
setblock 134 286 533 minecraft:smooth_basalt
fill 134 286 534 134 289 534 minecraft:blackstone
fill 134 286 536 134 287 536 minecraft:blackstone
fill 134 286 549 134 289 549 minecraft:blackstone
setblock 135 286 512 minecraft:smooth_basalt
fill 135 286 513 135 289 513 minecraft:blackstone
setblock 135 286 517 minecraft:smooth_basalt
fill 135 286 518 135 286 521 minecraft:blackstone
setblock 135 286 522 minecraft:smooth_basalt
fill 135 286 523 135 286 526 minecraft:blackstone
setblock 135 286 527 minecraft:smooth_basalt
fill 135 286 528 135 289 528 minecraft:blackstone
setblock 135 286 531 minecraft:blackstone
setblock 135 286 532 minecraft:smooth_basalt
fill 135 286 533 135 289 533 minecraft:blackstone
setblock 135 286 537 minecraft:smooth_basalt
fill 135 286 538 135 288 539 minecraft:blackstone
setblock 135 286 546 minecraft:blackstone
setblock 135 286 547 minecraft:smooth_basalt
fill 135 286 548 135 289 548 minecraft:blackstone
setblock 95 287 511 minecraft:smooth_basalt
fill 95 287 512 95 287 515 minecraft:blackstone
setblock 95 287 516 minecraft:smooth_basalt
fill 95 287 517 95 287 520 minecraft:blackstone
setblock 95 287 521 minecraft:smooth_basalt
fill 95 287 522 95 287 525 minecraft:blackstone
setblock 95 287 526 minecraft:smooth_basalt
fill 95 287 527 95 287 530 minecraft:blackstone
setblock 95 287 531 minecraft:smooth_basalt
fill 95 287 532 95 290 532 minecraft:blackstone
setblock 95 287 535 minecraft:blackstone
setblock 95 287 536 minecraft:smooth_basalt
fill 95 287 537 95 290 537 minecraft:blackstone
setblock 95 287 540 minecraft:blackstone
setblock 95 287 541 minecraft:smooth_basalt
fill 95 287 542 95 287 545 minecraft:blackstone
setblock 95 287 546 minecraft:smooth_basalt
fill 95 287 547 95 287 550 minecraft:blackstone
setblock 95 287 551 minecraft:smooth_basalt
fill 96 287 511 96 287 514 minecraft:blackstone
setblock 96 287 515 minecraft:smooth_basalt
fill 96 287 516 96 290 516 minecraft:blackstone
setblock 96 287 520 minecraft:smooth_basalt
fill 96 287 527 96 287 529 minecraft:blackstone
setblock 96 287 530 minecraft:smooth_basalt
fill 96 287 531 96 290 531 minecraft:blackstone
setblock 96 287 535 minecraft:smooth_basalt
fill 96 287 536 97 289 536 minecraft:blackstone
setblock 96 287 539 minecraft:blackstone
setblock 96 287 540 minecraft:smooth_basalt
fill 96 287 541 96 287 544 minecraft:blackstone
setblock 96 287 545 minecraft:smooth_basalt
fill 96 287 546 96 290 546 minecraft:blackstone
setblock 96 287 549 minecraft:blackstone
setblock 96 287 550 minecraft:smooth_basalt
fill 96 287 551 99 287 551 minecraft:blackstone
fill 97 287 511 97 287 513 minecraft:blackstone
setblock 97 287 514 minecraft:smooth_basalt
fill 97 287 515 97 290 515 minecraft:blackstone
fill 97 287 517 97 288 517 minecraft:blackstone
setblock 97 287 533 minecraft:blackstone
setblock 97 287 534 minecraft:smooth_basalt
fill 97 287 535 97 290 535 minecraft:blackstone
setblock 97 287 549 minecraft:smooth_basalt
fill 97 287 550 100 287 550 minecraft:blackstone
fill 98 287 511 98 287 512 minecraft:blackstone
setblock 98 287 513 minecraft:smooth_basalt
fill 98 287 514 98 289 514 minecraft:blackstone
fill 98 287 549 101 287 549 minecraft:blackstone
setblock 99 287 511 minecraft:blackstone
setblock 99 287 512 minecraft:smooth_basalt
fill 99 287 513 99 290 513 minecraft:blackstone
setblock 100 287 511 minecraft:smooth_basalt
fill 100 287 512 100 290 512 minecraft:blackstone
setblock 100 287 551 minecraft:smooth_basalt
fill 101 287 511 104 287 511 minecraft:blackstone
setblock 101 287 550 minecraft:smooth_basalt
fill 101 287 551 104 287 551 minecraft:blackstone
setblock 102 287 549 minecraft:smooth_basalt
fill 102 287 550 105 287 550 minecraft:blackstone
setblock 103 287 512 minecraft:blackstone
fill 103 287 525 106 300 528 minecraft:smooth_basalt
setblock 104 287 512 minecraft:smooth_basalt
fill 104 287 524 106 300 524 minecraft:smooth_basalt
setblock 105 287 511 minecraft:smooth_basalt
setblock 105 287 551 minecraft:smooth_basalt
fill 106 287 511 109 287 511 minecraft:blackstone
setblock 106 287 550 minecraft:smooth_basalt
fill 106 287 551 109 287 551 minecraft:blackstone
fill 107 287 525 107 300 527 minecraft:smooth_basalt
fill 107 287 550 110 287 550 minecraft:blackstone
setblock 110 287 511 minecraft:smooth_basalt
setblock 110 287 551 minecraft:smooth_basalt
fill 111 287 511 114 287 511 minecraft:blackstone
setblock 111 287 550 minecraft:smooth_basalt
fill 111 287 551 114 287 551 minecraft:blackstone
fill 112 287 512 113 287 512 minecraft:blackstone
fill 112 287 550 115 287 550 minecraft:blackstone
setblock 114 287 512 minecraft:smooth_basalt
setblock 115 287 511 minecraft:smooth_basalt
fill 115 287 512 118 287 512 minecraft:blackstone
setblock 115 287 551 minecraft:smooth_basalt
fill 116 287 511 119 287 511 minecraft:blackstone
fill 116 287 513 117 287 513 minecraft:blackstone
setblock 116 287 550 minecraft:smooth_basalt
fill 116 287 551 119 287 551 minecraft:blackstone
fill 117 287 550 117 289 550 minecraft:blackstone
setblock 118 287 513 minecraft:smooth_basalt
setblock 119 287 512 minecraft:smooth_basalt
fill 119 287 513 119 289 513 minecraft:blackstone
fill 119 287 550 120 287 550 minecraft:blackstone
setblock 120 287 511 minecraft:smooth_basalt
fill 120 287 512 120 290 512 minecraft:blackstone
fill 120 287 521 120 287 523 minecraft:blackstone
fill 120 287 526 120 300 526 minecraft:smooth_basalt
setblock 120 287 551 minecraft:smooth_basalt
fill 121 287 511 124 287 511 minecraft:blackstone
setblock 121 287 520 minecraft:blackstone
fill 121 287 526 122 287 526 minecraft:blackstone
fill 121 287 532 123 287 532 minecraft:blackstone
setblock 121 287 535 minecraft:blackstone
fill 121 287 551 121 289 551 minecraft:blackstone
fill 122 287 519 125 287 519 minecraft:blackstone
fill 122 287 531 124 287 531 minecraft:blackstone
setblock 122 287 536 minecraft:blackstone
setblock 124 287 512 minecraft:smooth_basalt
fill 124 287 526 126 287 526 minecraft:blackstone
fill 124 287 532 127 300 532 minecraft:smooth_basalt
setblock 125 287 511 minecraft:smooth_basalt
fill 125 287 512 128 287 512 minecraft:blackstone
fill 125 287 531 126 300 531 minecraft:smooth_basalt
fill 125 287 533 127 300 533 minecraft:smooth_basalt
setblock 125 287 536 minecraft:blackstone
fill 126 287 511 129 287 511 minecraft:blackstone
setblock 126 287 520 minecraft:blackstone
fill 126 287 525 127 287 525 minecraft:blackstone
fill 126 287 534 126 300 534 minecraft:smooth_basalt
setblock 126 287 535 minecraft:blackstone
fill 127 287 521 127 287 524 minecraft:blackstone
setblock 129 287 512 minecraft:smooth_basalt
setblock 130 287 511 minecraft:smooth_basalt
fill 130 287 512 130 290 512 minecraft:blackstone
setblock 130 287 551 minecraft:smooth_basalt
fill 131 287 511 131 290 511 minecraft:blackstone
fill 131 287 513 132 287 513 minecraft:blackstone
fill 131 287 551 131 290 551 minecraft:blackstone
setblock 133 287 512 minecraft:blackstone
setblock 133 287 513 minecraft:smooth_basalt
fill 133 287 514 133 290 514 minecraft:blackstone
setblock 133 287 517 minecraft:blackstone
setblock 133 287 518 minecraft:smooth_basalt
fill 133 287 529 133 287 532 minecraft:blackstone
setblock 133 287 533 minecraft:smooth_basalt
fill 133 287 550 133 289 550 minecraft:blackstone
setblock 134 287 511 minecraft:blackstone
setblock 134 287 512 minecraft:smooth_basalt
fill 134 287 513 134 290 513 minecraft:blackstone
setblock 134 287 516 minecraft:blackstone
setblock 134 287 517 minecraft:smooth_basalt
fill 134 287 518 134 287 521 minecraft:blackstone
setblock 134 287 522 minecraft:smooth_basalt
fill 134 287 523 134 287 526 minecraft:blackstone
setblock 134 287 527 minecraft:smooth_basalt
fill 134 287 528 134 290 528 minecraft:blackstone
fill 134 287 530 134 287 531 minecraft:blackstone
setblock 134 287 532 minecraft:smooth_basalt
fill 134 287 533 134 290 533 minecraft:blackstone
setblock 134 287 537 minecraft:smooth_basalt
setblock 134 287 551 minecraft:blackstone
setblock 135 287 511 minecraft:smooth_basalt
fill 135 287 512 135 290 512 minecraft:blackstone
setblock 135 287 516 minecraft:smooth_basalt
fill 135 287 517 135 287 520 minecraft:blackstone
setblock 135 287 521 minecraft:smooth_basalt
fill 135 287 522 135 287 525 minecraft:blackstone
setblock 135 287 526 minecraft:smooth_basalt
fill 135 287 527 135 290 527 minecraft:blackstone
setblock 135 287 531 minecraft:smooth_basalt
fill 135 287 532 135 290 532 minecraft:blackstone
setblock 135 287 535 minecraft:blackstone
setblock 135 287 536 minecraft:smooth_basalt
fill 135 287 537 135 290 537 minecraft:blackstone
setblock 135 287 540 minecraft:blackstone
setblock 135 287 541 minecraft:smooth_basalt
setblock 135 287 545 minecraft:blackstone
setblock 135 287 546 minecraft:smooth_basalt
fill 135 287 547 135 290 547 minecraft:blackstone
setblock 135 287 551 minecraft:smooth_basalt
fill 95 288 511 95 288 514 minecraft:blackstone
setblock 95 288 515 minecraft:smooth_basalt
fill 95 288 516 95 288 519 minecraft:blackstone
setblock 95 288 520 minecraft:smooth_basalt
fill 95 288 521 95 288 524 minecraft:blackstone
setblock 95 288 525 minecraft:smooth_basalt
fill 95 288 526 95 288 529 minecraft:blackstone
setblock 95 288 530 minecraft:smooth_basalt
fill 95 288 531 95 291 531 minecraft:blackstone
setblock 95 288 534 minecraft:blackstone
setblock 95 288 535 minecraft:smooth_basalt
fill 95 288 536 95 291 536 minecraft:blackstone
setblock 95 288 540 minecraft:smooth_basalt
fill 95 288 541 95 288 544 minecraft:blackstone
setblock 95 288 545 minecraft:smooth_basalt
fill 95 288 546 95 288 549 minecraft:blackstone
setblock 95 288 550 minecraft:smooth_basalt
fill 95 288 551 98 288 551 minecraft:blackstone
fill 96 288 511 96 288 513 minecraft:blackstone
setblock 96 288 514 minecraft:smooth_basalt
fill 96 288 515 96 291 515 minecraft:blackstone
setblock 96 288 519 minecraft:smooth_basalt
fill 96 288 520 96 290 520 minecraft:blackstone
setblock 96 288 528 minecraft:blackstone
setblock 96 288 529 minecraft:smooth_basalt
fill 96 288 530 96 290 530 minecraft:blackstone
setblock 96 288 534 minecraft:smooth_basalt
fill 96 288 535 96 291 535 minecraft:blackstone
setblock 96 288 539 minecraft:smooth_basalt
fill 96 288 540 96 288 543 minecraft:blackstone
setblock 96 288 544 minecraft:smooth_basalt
fill 96 288 545 96 291 545 minecraft:blackstone
setblock 96 288 549 minecraft:smooth_basalt
fill 96 288 550 99 288 550 minecraft:blackstone
fill 97 288 511 97 288 512 minecraft:blackstone
setblock 97 288 513 minecraft:smooth_basalt
fill 97 288 514 97 291 514 minecraft:blackstone
setblock 97 288 521 minecraft:light[level=12]
setblock 97 288 529 minecraft:light[level=12]
setblock 97 288 533 minecraft:smooth_basalt
fill 97 288 534 97 290 534 minecraft:blackstone
setblock 97 288 537 minecraft:blackstone
setblock 97 288 538 minecraft:smooth_basalt
setblock 97 288 545 minecraft:light[level=12]
setblock 97 288 548 minecraft:smooth_basalt
fill 97 288 549 100 288 549 minecraft:blackstone
setblock 98 288 511 minecraft:blackstone
setblock 98 288 512 minecraft:smooth_basalt
fill 98 288 513 98 291 513 minecraft:blackstone
setblock 99 288 511 minecraft:smooth_basalt
fill 99 288 512 99 291 512 minecraft:blackstone
setblock 99 288 551 minecraft:smooth_basalt
fill 100 288 511 103 288 511 minecraft:blackstone
setblock 100 288 550 minecraft:smooth_basalt
fill 100 288 551 103 288 551 minecraft:blackstone
setblock 101 288 549 minecraft:smooth_basalt
fill 101 288 550 104 288 550 minecraft:blackstone
fill 102 288 524 102 289 528 minecraft:blackstone
setblock 103 288 512 minecraft:smooth_basalt
fill 103 288 523 103 289 524 minecraft:blackstone
fill 103 288 529 107 289 529 minecraft:blackstone
setblock 104 288 511 minecraft:smooth_basalt
setblock 104 288 512 minecraft:blackstone
fill 104 288 523 106 289 523 minecraft:blackstone
setblock 104 288 551 minecraft:smooth_basalt
fill 105 288 511 108 288 511 minecraft:blackstone
setblock 105 288 513 minecraft:light[level=12]
setblock 105 288 521 minecraft:light[level=12]
setblock 105 288 537 minecraft:light[level=12]
setblock 105 288 545 minecraft:light[level=12]
setblock 105 288 550 minecraft:smooth_basalt
fill 105 288 551 108 288 551 minecraft:blackstone
fill 107 288 524 107 289 524 minecraft:blackstone
fill 107 288 528 108 289 528 minecraft:blackstone
fill 108 288 525 108 289 527 minecraft:blackstone
fill 108 288 545 110 289 547 minecraft:smooth_basalt
setblock 109 288 511 minecraft:smooth_basalt
setblock 109 288 551 minecraft:smooth_basalt
fill 110 288 511 113 288 511 minecraft:blackstone
setblock 110 288 550 minecraft:smooth_basalt
fill 110 288 551 113 288 551 minecraft:blackstone
fill 111 288 512 112 288 512 minecraft:blackstone
fill 111 288 550 114 288 550 minecraft:blackstone
setblock 113 288 512 minecraft:smooth_basalt
setblock 113 288 513 minecraft:light[level=12]
setblock 113 288 521 minecraft:light[level=12]
setblock 113 288 537 minecraft:light[level=12]
setblock 113 288 545 minecraft:light[level=12]
setblock 114 288 511 minecraft:smooth_basalt
fill 114 288 512 117 288 512 minecraft:blackstone
setblock 114 288 551 minecraft:smooth_basalt
fill 115 288 511 118 288 511 minecraft:blackstone
fill 115 288 513 116 288 513 minecraft:blackstone
setblock 115 288 550 minecraft:smooth_basalt
fill 115 288 551 118 288 551 minecraft:blackstone
fill 116 288 550 116 289 550 minecraft:blackstone
setblock 117 288 513 minecraft:smooth_basalt
fill 117 288 541 119 300 542 minecraft:smooth_basalt
setblock 118 288 512 minecraft:smooth_basalt
fill 118 288 513 118 289 513 minecraft:blackstone
fill 118 288 543 118 300 543 minecraft:smooth_basalt
setblock 119 288 511 minecraft:smooth_basalt
fill 119 288 512 119 291 512 minecraft:blackstone
setblock 119 288 550 minecraft:blackstone
setblock 119 288 551 minecraft:smooth_basalt
fill 120 288 511 123 288 511 minecraft:blackstone
fill 120 288 551 120 289 551 minecraft:blackstone
setblock 121 288 513 minecraft:light[level=12]
setblock 121 288 521 minecraft:light[level=12]
fill 121 288 526 122 296 526 minecraft:smooth_basalt
setblock 121 288 537 minecraft:light[level=12]
setblock 121 288 545 minecraft:light[level=12]
fill 122 288 533 123 288 534 minecraft:smooth_basalt
setblock 123 288 512 minecraft:smooth_basalt
setblock 124 288 511 minecraft:smooth_basalt
fill 124 288 512 127 288 512 minecraft:blackstone
fill 124 288 531 124 289 531 minecraft:blackstone
fill 124 288 533 124 300 533 minecraft:smooth_basalt
fill 124 288 534 125 289 534 minecraft:blackstone
fill 125 288 511 128 288 511 minecraft:blackstone
fill 127 288 531 127 289 531 minecraft:blackstone
fill 127 288 534 127 289 534 minecraft:blackstone
setblock 128 288 512 minecraft:smooth_basalt
setblock 129 288 511 minecraft:smooth_basalt
fill 129 288 512 129 291 512 minecraft:blackstone
setblock 129 288 513 minecraft:light[level=12]
setblock 129 288 521 minecraft:light[level=12]
setblock 129 288 529 minecraft:light[level=12]
setblock 129 288 537 minecraft:light[level=12]
setblock 129 288 545 minecraft:light[level=12]
fill 130 288 511 130 291 511 minecraft:blackstone
fill 130 288 513 131 288 513 minecraft:blackstone
fill 130 288 528 131 289 529 minecraft:gold_block
fill 130 288 551 130 291 551 minecraft:blackstone
fill 131 288 527 131 289 527 minecraft:gold_block
setblock 132 288 513 minecraft:smooth_basalt
fill 132 288 514 132 290 515 minecraft:blackstone
setblock 133 288 512 minecraft:smooth_basalt
fill 133 288 513 133 291 513 minecraft:blackstone
setblock 133 288 517 minecraft:smooth_basalt
fill 133 288 518 135 288 519 minecraft:blackstone
fill 133 288 530 133 288 531 minecraft:blackstone
setblock 133 288 532 minecraft:smooth_basalt
fill 133 288 533 133 289 534 minecraft:blackstone
setblock 134 288 511 minecraft:smooth_basalt
fill 134 288 512 134 291 512 minecraft:blackstone
setblock 134 288 516 minecraft:smooth_basalt
fill 134 288 517 135 290 517 minecraft:blackstone
setblock 134 288 520 minecraft:blackstone
setblock 134 288 521 minecraft:smooth_basalt
fill 134 288 522 134 288 525 minecraft:blackstone
setblock 134 288 526 minecraft:smooth_basalt
fill 134 288 527 134 290 527 minecraft:blackstone
setblock 134 288 530 minecraft:blackstone
setblock 134 288 531 minecraft:smooth_basalt
fill 134 288 532 134 291 532 minecraft:blackstone
setblock 134 288 536 minecraft:smooth_basalt
fill 134 288 537 134 290 538 minecraft:blackstone
setblock 134 288 551 minecraft:smooth_basalt
fill 135 288 511 135 291 511 minecraft:blackstone
setblock 135 288 515 minecraft:smooth_basalt
fill 135 288 516 135 291 516 minecraft:blackstone
setblock 135 288 520 minecraft:smooth_basalt
fill 135 288 521 135 288 524 minecraft:blackstone
setblock 135 288 525 minecraft:smooth_basalt
fill 135 288 526 135 291 526 minecraft:blackstone
setblock 135 288 530 minecraft:smooth_basalt
fill 135 288 531 135 291 531 minecraft:blackstone
setblock 135 288 535 minecraft:smooth_basalt
fill 135 288 536 135 291 536 minecraft:blackstone
setblock 135 288 540 minecraft:smooth_basalt
fill 135 288 541 135 288 544 minecraft:blackstone
setblock 135 288 545 minecraft:smooth_basalt
fill 135 288 546 135 291 546 minecraft:blackstone
setblock 135 288 550 minecraft:smooth_basalt
fill 135 288 551 135 291 551 minecraft:blackstone
fill 95 289 511 95 289 513 minecraft:blackstone
setblock 95 289 514 minecraft:smooth_basalt
fill 95 289 515 95 289 518 minecraft:blackstone
setblock 95 289 519 minecraft:smooth_basalt
fill 95 289 520 95 289 523 minecraft:blackstone
setblock 95 289 524 minecraft:smooth_basalt
fill 95 289 525 95 289 528 minecraft:blackstone
setblock 95 289 529 minecraft:smooth_basalt
fill 95 289 530 95 292 530 minecraft:blackstone
setblock 95 289 534 minecraft:smooth_basalt
fill 95 289 535 95 292 535 minecraft:blackstone
setblock 95 289 538 minecraft:blackstone
setblock 95 289 539 minecraft:smooth_basalt
fill 95 289 540 95 289 543 minecraft:blackstone
setblock 95 289 544 minecraft:smooth_basalt
fill 95 289 545 95 289 548 minecraft:blackstone
setblock 95 289 549 minecraft:smooth_basalt
fill 95 289 550 97 289 551 minecraft:blackstone
fill 96 289 511 96 289 512 minecraft:blackstone
setblock 96 289 513 minecraft:smooth_basalt
fill 96 289 514 96 292 514 minecraft:blackstone
setblock 96 289 518 minecraft:smooth_basalt
fill 96 289 519 96 292 519 minecraft:blackstone
setblock 96 289 529 minecraft:blackstone
setblock 96 289 532 minecraft:blackstone
setblock 96 289 533 minecraft:smooth_basalt
fill 96 289 534 96 292 534 minecraft:blackstone
setblock 96 289 538 minecraft:smooth_basalt
fill 96 289 539 96 289 542 minecraft:blackstone
setblock 96 289 543 minecraft:smooth_basalt
fill 96 289 544 96 292 544 minecraft:blackstone
setblock 96 289 548 minecraft:smooth_basalt
fill 96 289 549 99 289 549 minecraft:blackstone
setblock 97 289 511 minecraft:blackstone
setblock 97 289 512 minecraft:smooth_basalt
fill 97 289 513 97 292 513 minecraft:blackstone
setblock 97 289 517 minecraft:smooth_basalt
setblock 97 289 533 minecraft:blackstone
setblock 97 289 537 minecraft:smooth_basalt
fill 97 289 538 97 291 539 minecraft:blackstone
setblock 97 289 548 minecraft:blackstone
setblock 98 289 511 minecraft:smooth_basalt
fill 98 289 512 98 292 512 minecraft:blackstone
setblock 98 289 550 minecraft:blackstone
setblock 98 289 551 minecraft:smooth_basalt
fill 99 289 511 102 289 511 minecraft:blackstone
setblock 99 289 550 minecraft:smooth_basalt
fill 99 289 551 102 289 551 minecraft:blackstone
fill 100 289 526 101 289 526 minecraft:blackstone
fill 100 289 550 103 289 550 minecraft:blackstone
fill 101 289 524 101 289 525 minecraft:blackstone
fill 101 289 527 101 289 529 minecraft:blackstone
setblock 102 289 512 minecraft:smooth_basalt
setblock 102 289 523 minecraft:blackstone
fill 102 289 529 102 289 530 minecraft:blackstone
setblock 103 289 511 minecraft:smooth_basalt
setblock 103 289 512 minecraft:blackstone
fill 103 289 522 107 289 522 minecraft:blackstone
fill 103 289 530 107 289 530 minecraft:blackstone
setblock 103 289 551 minecraft:smooth_basalt
fill 104 289 511 107 289 511 minecraft:blackstone
fill 104 289 551 107 289 551 minecraft:blackstone
fill 107 289 523 108 289 523 minecraft:blackstone
setblock 108 289 511 minecraft:smooth_basalt
fill 108 289 524 109 289 524 minecraft:blackstone
setblock 108 289 529 minecraft:blackstone
setblock 108 289 551 minecraft:smooth_basalt
fill 109 289 511 112 289 511 minecraft:blackstone
fill 109 289 525 109 289 528 minecraft:blackstone
fill 109 289 551 112 289 551 minecraft:blackstone
setblock 111 289 512 minecraft:blackstone
fill 111 289 550 113 289 550 minecraft:blackstone
setblock 112 289 512 minecraft:smooth_basalt
setblock 113 289 511 minecraft:smooth_basalt
fill 113 289 512 116 289 512 minecraft:blackstone
setblock 113 289 551 minecraft:smooth_basalt
fill 114 289 511 117 289 511 minecraft:blackstone
fill 114 289 513 115 289 513 minecraft:blackstone
setblock 114 289 550 minecraft:smooth_basalt
fill 114 289 551 117 289 551 minecraft:blackstone
fill 115 289 550 115 290 550 minecraft:blackstone
setblock 116 289 513 minecraft:smooth_basalt
fill 116 289 541 116 290 542 minecraft:blackstone
setblock 117 289 512 minecraft:smooth_basalt
fill 117 289 513 117 290 513 minecraft:blackstone
fill 117 289 540 119 290 540 minecraft:blackstone
fill 117 289 543 117 290 543 minecraft:blackstone
setblock 118 289 511 minecraft:smooth_basalt
fill 118 289 512 118 291 512 minecraft:blackstone
setblock 118 289 551 minecraft:smooth_basalt
fill 119 289 511 122 289 511 minecraft:blackstone
fill 119 289 543 119 290 543 minecraft:blackstone
fill 119 289 551 119 290 551 minecraft:blackstone
fill 120 289 541 120 290 542 minecraft:blackstone
setblock 122 289 512 minecraft:smooth_basalt
fill 122 289 533 122 300 534 minecraft:smooth_basalt
setblock 123 289 511 minecraft:smooth_basalt
fill 123 289 512 126 289 512 minecraft:blackstone
fill 123 289 531 123 289 534 minecraft:blackstone
fill 123 289 535 123 300 535 minecraft:smooth_basalt
fill 124 289 511 127 289 511 minecraft:blackstone
fill 124 289 530 127 289 530 minecraft:blackstone
fill 124 289 535 127 289 535 minecraft:blackstone
setblock 127 289 512 minecraft:smooth_basalt
setblock 128 289 511 minecraft:smooth_basalt
fill 128 289 512 128 292 512 minecraft:blackstone
fill 128 289 531 128 289 534 minecraft:blackstone
fill 129 289 511 129 292 511 minecraft:blackstone
fill 129 289 513 130 289 513 minecraft:blackstone
setblock 131 289 513 minecraft:smooth_basalt
fill 131 289 514 131 292 514 minecraft:blackstone
setblock 132 289 512 minecraft:smooth_basalt
fill 132 289 513 132 292 513 minecraft:blackstone
setblock 132 289 516 minecraft:blackstone
setblock 133 289 511 minecraft:smooth_basalt
fill 133 289 512 133 292 512 minecraft:blackstone
setblock 133 289 515 minecraft:blackstone
setblock 133 289 516 minecraft:smooth_basalt
fill 133 289 517 133 289 520 minecraft:blackstone
setblock 133 289 531 minecraft:smooth_basalt
setblock 133 289 532 minecraft:blackstone
setblock 133 289 535 minecraft:blackstone
setblock 133 289 551 minecraft:smooth_basalt
fill 134 289 511 134 292 511 minecraft:blackstone
setblock 134 289 515 minecraft:smooth_basalt
fill 134 289 516 134 292 516 minecraft:blackstone
fill 134 289 518 134 289 519 minecraft:blackstone
setblock 134 289 520 minecraft:smooth_basalt
fill 134 289 521 134 289 524 minecraft:blackstone
setblock 134 289 525 minecraft:smooth_basalt
fill 134 289 526 134 290 526 minecraft:blackstone
setblock 134 289 530 minecraft:smooth_basalt
fill 134 289 531 134 291 531 minecraft:blackstone
setblock 134 289 535 minecraft:smooth_basalt
fill 134 289 536 134 292 536 minecraft:blackstone
setblock 134 289 539 minecraft:blackstone
setblock 134 289 550 minecraft:smooth_basalt
fill 134 289 551 134 292 551 minecraft:blackstone
setblock 135 289 514 minecraft:smooth_basalt
fill 135 289 515 135 292 515 minecraft:blackstone
setblock 135 289 518 minecraft:blackstone
setblock 135 289 519 minecraft:smooth_basalt
fill 135 289 520 135 289 523 minecraft:blackstone
setblock 135 289 524 minecraft:smooth_basalt
fill 135 289 525 135 292 525 minecraft:blackstone
setblock 135 289 529 minecraft:smooth_basalt
fill 135 289 530 135 292 530 minecraft:blackstone
setblock 135 289 534 minecraft:smooth_basalt
fill 135 289 535 135 292 535 minecraft:blackstone
setblock 135 289 538 minecraft:blackstone
setblock 135 289 539 minecraft:smooth_basalt
fill 135 289 540 135 289 543 minecraft:blackstone
setblock 135 289 544 minecraft:smooth_basalt
fill 135 289 545 135 292 545 minecraft:blackstone
setblock 135 289 549 minecraft:smooth_basalt
fill 135 289 550 135 292 550 minecraft:blackstone
fill 95 290 511 95 290 512 minecraft:blackstone
setblock 95 290 513 minecraft:smooth_basalt
fill 95 290 514 95 290 517 minecraft:blackstone
setblock 95 290 518 minecraft:smooth_basalt
fill 95 290 519 95 290 522 minecraft:blackstone
setblock 95 290 523 minecraft:smooth_basalt
fill 95 290 524 95 290 527 minecraft:blackstone
setblock 95 290 528 minecraft:smooth_basalt
fill 95 290 529 95 291 529 minecraft:blackstone
setblock 95 290 533 minecraft:smooth_basalt
fill 95 290 534 95 293 534 minecraft:blackstone
setblock 95 290 538 minecraft:smooth_basalt
fill 95 290 539 95 290 542 minecraft:blackstone
setblock 95 290 543 minecraft:smooth_basalt
fill 95 290 544 95 290 547 minecraft:blackstone
setblock 95 290 548 minecraft:smooth_basalt
fill 95 290 549 96 290 551 minecraft:blackstone
setblock 96 290 511 minecraft:blackstone
setblock 96 290 512 minecraft:smooth_basalt
fill 96 290 513 96 293 513 minecraft:blackstone
setblock 96 290 517 minecraft:smooth_basalt
fill 96 290 518 96 293 518 minecraft:blackstone
setblock 96 290 532 minecraft:smooth_basalt
fill 96 290 533 96 292 533 minecraft:blackstone
setblock 96 290 536 minecraft:blackstone
setblock 96 290 537 minecraft:smooth_basalt
fill 96 290 538 96 290 541 minecraft:blackstone
setblock 96 290 542 minecraft:smooth_basalt
fill 96 290 543 96 293 543 minecraft:blackstone
setblock 96 290 547 minecraft:smooth_basalt
fill 96 290 548 96 292 548 minecraft:blackstone
setblock 97 290 511 minecraft:smooth_basalt
fill 97 290 512 97 293 512 minecraft:blackstone
setblock 97 290 516 minecraft:smooth_basalt
setblock 97 290 517 minecraft:blackstone
setblock 97 290 536 minecraft:smooth_basalt
fill 97 290 537 97 291 537 minecraft:blackstone
fill 97 290 549 97 290 550 minecraft:blackstone
setblock 97 290 551 minecraft:smooth_basalt
fill 98 290 511 101 290 511 minecraft:blackstone
setblock 98 290 550 minecraft:smooth_basalt
fill 98 290 551 101 290 551 minecraft:blackstone
fill 99 290 550 101 290 550 minecraft:blackstone
setblock 101 290 512 minecraft:smooth_basalt
setblock 102 290 511 minecraft:smooth_basalt
setblock 102 290 512 minecraft:blackstone
setblock 102 290 551 minecraft:smooth_basalt
fill 103 290 511 106 290 511 minecraft:blackstone
fill 103 290 551 106 290 551 minecraft:blackstone
setblock 107 290 511 minecraft:smooth_basalt
setblock 107 290 551 minecraft:smooth_basalt
fill 108 290 511 111 290 511 minecraft:blackstone
fill 108 290 546 110 292 546 minecraft:smooth_basalt
fill 108 290 551 111 290 551 minecraft:blackstone
fill 109 290 545 109 292 545 minecraft:smooth_basalt
fill 109 290 547 109 292 547 minecraft:smooth_basalt
setblock 111 290 512 minecraft:smooth_basalt
setblock 112 290 511 minecraft:smooth_basalt
fill 112 290 512 115 290 512 minecraft:blackstone
setblock 112 290 550 minecraft:blackstone
setblock 112 290 551 minecraft:smooth_basalt
fill 113 290 511 116 290 511 minecraft:blackstone
setblock 113 290 550 minecraft:smooth_basalt
fill 113 290 551 116 290 551 minecraft:blackstone
setblock 114 290 513 minecraft:blackstone
setblock 114 290 550 minecraft:blackstone
setblock 115 290 513 minecraft:smooth_basalt
setblock 115 290 542 minecraft:blackstone
setblock 116 290 512 minecraft:smooth_basalt
setblock 116 290 513 minecraft:blackstone
setblock 116 290 540 minecraft:blackstone
setblock 116 290 543 minecraft:blackstone
setblock 117 290 511 minecraft:smooth_basalt
fill 117 290 512 117 292 512 minecraft:blackstone
fill 117 290 539 119 290 539 minecraft:blackstone
fill 117 290 544 119 290 544 minecraft:blackstone
setblock 117 290 551 minecraft:smooth_basalt
fill 118 290 511 121 290 511 minecraft:blackstone
setblock 118 290 551 minecraft:blackstone
setblock 120 290 540 minecraft:blackstone
setblock 120 290 543 minecraft:blackstone
setblock 121 290 512 minecraft:smooth_basalt
setblock 122 290 511 minecraft:smooth_basalt
fill 123 290 511 126 290 511 minecraft:blackstone
fill 123 290 533 123 296 534 minecraft:smooth_basalt
fill 124 290 534 124 296 535 minecraft:smooth_basalt
fill 125 290 534 125 296 534 minecraft:smooth_basalt
setblock 126 290 512 minecraft:smooth_basalt
setblock 127 290 511 minecraft:smooth_basalt
fill 127 290 512 127 292 512 minecraft:blackstone
fill 128 290 511 128 293 511 minecraft:blackstone
setblock 129 290 513 minecraft:blackstone
setblock 130 290 513 minecraft:smooth_basalt
setblock 131 290 512 minecraft:smooth_basalt
fill 131 290 513 131 293 513 minecraft:blackstone
setblock 132 290 511 minecraft:smooth_basalt
fill 132 290 512 132 293 512 minecraft:blackstone
setblock 132 290 516 minecraft:smooth_basalt
fill 132 290 517 133 292 517 minecraft:blackstone
setblock 132 290 551 minecraft:smooth_basalt
fill 133 290 511 133 293 511 minecraft:blackstone
setblock 133 290 515 minecraft:smooth_basalt
fill 133 290 516 133 293 516 minecraft:blackstone
fill 133 290 518 133 290 519 minecraft:blackstone
setblock 133 290 520 minecraft:smooth_basalt
setblock 133 290 534 minecraft:blackstone
setblock 133 290 550 minecraft:smooth_basalt
fill 133 290 551 133 293 551 minecraft:blackstone
setblock 134 290 514 minecraft:smooth_basalt
fill 134 290 515 134 293 515 minecraft:blackstone
setblock 134 290 518 minecraft:blackstone
setblock 134 290 519 minecraft:smooth_basalt
fill 134 290 520 134 290 523 minecraft:blackstone
setblock 134 290 524 minecraft:smooth_basalt
setblock 134 290 525 minecraft:blackstone
setblock 134 290 529 minecraft:smooth_basalt
fill 134 290 530 134 291 530 minecraft:blackstone
setblock 134 290 534 minecraft:smooth_basalt
fill 134 290 535 134 293 535 minecraft:blackstone
setblock 134 290 539 minecraft:smooth_basalt
fill 134 290 550 134 291 550 minecraft:blackstone
setblock 135 290 513 minecraft:smooth_basalt
fill 135 290 514 135 293 514 minecraft:blackstone
setblock 135 290 518 minecraft:smooth_basalt
fill 135 290 519 135 290 522 minecraft:blackstone
setblock 135 290 523 minecraft:smooth_basalt
fill 135 290 524 135 293 524 minecraft:blackstone
setblock 135 290 528 minecraft:smooth_basalt
fill 135 290 529 135 292 529 minecraft:blackstone
setblock 135 290 533 minecraft:smooth_basalt
fill 135 290 534 135 293 534 minecraft:blackstone
setblock 135 290 538 minecraft:smooth_basalt
fill 135 290 539 135 290 542 minecraft:blackstone
setblock 135 290 543 minecraft:smooth_basalt
fill 135 290 544 135 293 544 minecraft:blackstone
setblock 135 290 548 minecraft:smooth_basalt
fill 135 290 549 135 293 549 minecraft:blackstone
setblock 95 291 511 minecraft:blackstone
setblock 95 291 512 minecraft:smooth_basalt
fill 95 291 513 95 291 516 minecraft:blackstone
setblock 95 291 517 minecraft:smooth_basalt
fill 95 291 518 95 291 521 minecraft:blackstone
setblock 95 291 522 minecraft:smooth_basalt
setblock 95 291 523 minecraft:blackstone
setblock 95 291 528 minecraft:blackstone
setblock 95 291 532 minecraft:smooth_basalt
fill 95 291 533 95 294 533 minecraft:blackstone
setblock 95 291 537 minecraft:smooth_basalt
fill 95 291 538 95 291 541 minecraft:blackstone
setblock 95 291 542 minecraft:smooth_basalt
fill 95 291 543 95 291 546 minecraft:blackstone
setblock 95 291 547 minecraft:smooth_basalt
fill 95 291 548 95 291 551 minecraft:blackstone
setblock 96 291 511 minecraft:smooth_basalt
fill 96 291 512 96 294 512 minecraft:blackstone
setblock 96 291 516 minecraft:smooth_basalt
fill 96 291 517 96 294 517 minecraft:blackstone
setblock 96 291 532 minecraft:blackstone
setblock 96 291 536 minecraft:smooth_basalt
fill 96 291 537 96 291 540 minecraft:blackstone
setblock 96 291 541 minecraft:smooth_basalt
fill 96 291 542 96 294 542 minecraft:blackstone
setblock 96 291 546 minecraft:smooth_basalt
fill 96 291 547 96 292 547 minecraft:blackstone
fill 96 291 549 96 291 550 minecraft:blackstone
setblock 96 291 551 minecraft:smooth_basalt
fill 97 291 511 100 291 511 minecraft:blackstone
setblock 97 291 515 minecraft:smooth_basalt
setblock 97 291 516 minecraft:blackstone
setblock 97 291 536 minecraft:blackstone
setblock 97 291 550 minecraft:smooth_basalt
fill 97 291 551 100 291 551 minecraft:blackstone
fill 98 291 550 99 291 550 minecraft:blackstone
setblock 100 291 512 minecraft:smooth_basalt
setblock 101 291 511 minecraft:smooth_basalt
setblock 101 291 551 minecraft:smooth_basalt
fill 102 291 511 103 291 511 minecraft:blackstone
fill 102 291 551 104 291 551 minecraft:blackstone
fill 108 291 511 110 291 511 minecraft:blackstone
fill 108 291 551 110 291 551 minecraft:blackstone
setblock 111 291 511 minecraft:smooth_basalt
fill 111 291 512 114 291 512 minecraft:blackstone
setblock 111 291 551 minecraft:smooth_basalt
fill 112 291 511 115 291 511 minecraft:blackstone
fill 112 291 551 115 291 551 minecraft:blackstone
setblock 115 291 512 minecraft:smooth_basalt
setblock 116 291 511 minecraft:smooth_basalt
fill 116 291 512 116 292 512 minecraft:blackstone
setblock 116 291 551 minecraft:smooth_basalt
fill 117 291 511 120 291 511 minecraft:blackstone
setblock 117 291 551 minecraft:blackstone
setblock 121 291 511 minecraft:smooth_basalt
fill 122 291 511 125 291 511 minecraft:blackstone
setblock 126 291 511 minecraft:smooth_basalt
fill 127 291 511 127 294 511 minecraft:blackstone
setblock 129 291 513 minecraft:smooth_basalt
setblock 130 291 512 minecraft:smooth_basalt
fill 130 291 513 130 294 513 minecraft:blackstone
setblock 131 291 511 minecraft:smooth_basalt
fill 131 291 512 131 294 512 minecraft:blackstone
setblock 131 291 551 minecraft:smooth_basalt
fill 132 291 511 132 294 511 minecraft:blackstone
setblock 132 291 514 minecraft:blackstone
setblock 132 291 515 minecraft:smooth_basalt
fill 132 291 516 132 294 516 minecraft:blackstone
fill 132 291 551 132 294 551 minecraft:blackstone
setblock 133 291 514 minecraft:smooth_basalt
fill 133 291 515 133 294 515 minecraft:blackstone
setblock 133 291 518 minecraft:blackstone
setblock 133 291 519 minecraft:smooth_basalt
fill 133 291 520 135 292 520 minecraft:blackstone
setblock 134 291 513 minecraft:smooth_basalt
fill 134 291 514 134 294 514 minecraft:blackstone
setblock 134 291 517 minecraft:blackstone
setblock 134 291 518 minecraft:smooth_basalt
fill 134 291 519 135 293 519 minecraft:blackstone
fill 134 291 521 134 291 522 minecraft:blackstone
setblock 134 291 523 minecraft:smooth_basalt
setblock 134 291 524 minecraft:blackstone
setblock 134 291 533 minecraft:smooth_basalt
fill 134 291 534 134 293 534 minecraft:blackstone
setblock 134 291 537 minecraft:blackstone
setblock 134 291 538 minecraft:smooth_basalt
fill 134 291 539 135 292 540 minecraft:blackstone
setblock 135 291 512 minecraft:smooth_basalt
fill 135 291 513 135 294 513 minecraft:blackstone
setblock 135 291 517 minecraft:smooth_basalt
fill 135 291 518 135 294 518 minecraft:blackstone
setblock 135 291 521 minecraft:blackstone
setblock 135 291 522 minecraft:smooth_basalt
fill 135 291 523 135 294 523 minecraft:blackstone
setblock 135 291 527 minecraft:smooth_basalt
fill 135 291 528 135 292 528 minecraft:blackstone
setblock 135 291 532 minecraft:smooth_basalt
fill 135 291 533 135 294 533 minecraft:blackstone
setblock 135 291 537 minecraft:smooth_basalt
fill 135 291 538 135 294 538 minecraft:blackstone
setblock 135 291 541 minecraft:blackstone
setblock 135 291 542 minecraft:smooth_basalt
fill 135 291 543 135 294 543 minecraft:blackstone
setblock 135 291 547 minecraft:smooth_basalt
fill 135 291 548 135 294 548 minecraft:blackstone
setblock 95 292 511 minecraft:smooth_basalt
fill 95 292 512 95 292 515 minecraft:blackstone
setblock 95 292 516 minecraft:smooth_basalt
fill 95 292 517 95 292 520 minecraft:blackstone
setblock 95 292 521 minecraft:smooth_basalt
fill 95 292 522 95 293 522 minecraft:blackstone
setblock 95 292 531 minecraft:smooth_basalt
fill 95 292 532 95 293 532 minecraft:blackstone
setblock 95 292 536 minecraft:smooth_basalt
fill 95 292 537 95 292 540 minecraft:blackstone
setblock 95 292 541 minecraft:smooth_basalt
fill 95 292 542 95 292 545 minecraft:blackstone
setblock 95 292 546 minecraft:smooth_basalt
fill 95 292 547 95 292 550 minecraft:blackstone
setblock 95 292 551 minecraft:smooth_basalt
fill 96 292 511 99 292 511 minecraft:blackstone
setblock 96 292 515 minecraft:smooth_basalt
fill 96 292 516 96 295 516 minecraft:blackstone
setblock 96 292 535 minecraft:smooth_basalt
fill 96 292 536 96 292 539 minecraft:blackstone
setblock 96 292 540 minecraft:smooth_basalt
fill 96 292 541 96 295 541 minecraft:blackstone
setblock 96 292 545 minecraft:smooth_basalt
setblock 96 292 546 minecraft:blackstone
setblock 96 292 549 minecraft:blackstone
setblock 96 292 550 minecraft:smooth_basalt
fill 96 292 551 99 292 551 minecraft:blackstone
setblock 97 292 514 minecraft:smooth_basalt
setblock 97 292 515 minecraft:blackstone
setblock 97 292 538 minecraft:blackstone
setblock 97 292 539 minecraft:smooth_basalt
fill 97 292 550 98 292 550 minecraft:blackstone
setblock 99 292 512 minecraft:smooth_basalt
setblock 100 292 511 minecraft:smooth_basalt
setblock 100 292 551 minecraft:smooth_basalt
setblock 101 292 511 minecraft:blackstone
setblock 101 292 551 minecraft:blackstone
setblock 110 292 511 minecraft:smooth_basalt
setblock 110 292 551 minecraft:smooth_basalt
fill 111 292 511 114 292 511 minecraft:blackstone
fill 111 292 551 114 292 551 minecraft:blackstone
fill 112 292 512 113 292 512 minecraft:blackstone
setblock 114 292 512 minecraft:smooth_basalt
setblock 115 292 511 minecraft:smooth_basalt
setblock 115 292 512 minecraft:blackstone
setblock 115 292 551 minecraft:smooth_basalt
fill 116 292 511 119 292 511 minecraft:blackstone
setblock 120 292 511 minecraft:smooth_basalt
setblock 125 292 511 minecraft:smooth_basalt
fill 126 292 511 126 293 511 minecraft:blackstone
setblock 129 292 512 minecraft:smooth_basalt
fill 129 292 513 129 294 513 minecraft:blackstone
setblock 130 292 511 minecraft:smooth_basalt
fill 130 292 512 130 295 512 minecraft:blackstone
fill 131 292 511 131 295 511 minecraft:blackstone
fill 131 292 551 131 295 551 minecraft:blackstone
setblock 132 292 514 minecraft:smooth_basalt
fill 132 292 515 132 295 515 minecraft:blackstone
setblock 132 292 518 minecraft:blackstone
setblock 133 292 513 minecraft:smooth_basalt
fill 133 292 514 133 295 514 minecraft:blackstone
setblock 133 292 518 minecraft:smooth_basalt
fill 133 292 519 133 295 519 minecraft:blackstone
setblock 134 292 512 minecraft:smooth_basalt
fill 134 292 513 134 295 513 minecraft:blackstone
setblock 134 292 517 minecraft:smooth_basalt
fill 134 292 518 134 295 518 minecraft:blackstone
setblock 134 292 521 minecraft:blackstone
setblock 134 292 522 minecraft:smooth_basalt
fill 134 292 523 134 293 523 minecraft:blackstone
setblock 134 292 532 minecraft:smooth_basalt
setblock 134 292 533 minecraft:blackstone
setblock 134 292 537 minecraft:smooth_basalt
fill 134 292 538 134 295 538 minecraft:blackstone
setblock 135 292 511 minecraft:smooth_basalt
fill 135 292 512 135 295 512 minecraft:blackstone
setblock 135 292 516 minecraft:smooth_basalt
fill 135 292 517 135 295 517 minecraft:blackstone
setblock 135 292 521 minecraft:smooth_basalt
fill 135 292 522 135 295 522 minecraft:blackstone
setblock 135 292 526 minecraft:smooth_basalt
setblock 135 292 527 minecraft:blackstone
setblock 135 292 531 minecraft:smooth_basalt
fill 135 292 532 135 293 532 minecraft:blackstone
setblock 135 292 536 minecraft:smooth_basalt
fill 135 292 537 135 295 537 minecraft:blackstone
setblock 135 292 541 minecraft:smooth_basalt
fill 135 292 542 135 295 542 minecraft:blackstone
setblock 135 292 546 minecraft:smooth_basalt
fill 135 292 547 135 295 547 minecraft:blackstone
setblock 135 292 551 minecraft:smooth_basalt
fill 95 293 511 95 293 514 minecraft:blackstone
setblock 95 293 515 minecraft:smooth_basalt
fill 95 293 516 95 293 519 minecraft:blackstone
setblock 95 293 520 minecraft:smooth_basalt
fill 95 293 521 95 296 521 minecraft:blackstone
setblock 95 293 535 minecraft:smooth_basalt
fill 95 293 536 95 293 539 minecraft:blackstone
setblock 95 293 540 minecraft:smooth_basalt
fill 95 293 541 95 293 544 minecraft:blackstone
setblock 95 293 545 minecraft:smooth_basalt
fill 95 293 546 95 293 549 minecraft:blackstone
setblock 95 293 550 minecraft:smooth_basalt
fill 95 293 551 98 293 551 minecraft:blackstone
fill 96 293 511 98 293 511 minecraft:blackstone
setblock 96 293 514 minecraft:smooth_basalt
fill 96 293 515 96 295 515 minecraft:blackstone
setblock 96 293 534 minecraft:smooth_basalt
fill 96 293 535 96 293 538 minecraft:blackstone
setblock 96 293 539 minecraft:smooth_basalt
fill 96 293 540 96 296 540 minecraft:blackstone
setblock 96 293 544 minecraft:smooth_basalt
fill 96 293 545 96 296 545 minecraft:blackstone
setblock 96 293 549 minecraft:smooth_basalt
setblock 96 293 550 minecraft:blackstone
setblock 98 293 512 minecraft:smooth_basalt
setblock 99 293 511 minecraft:smooth_basalt
setblock 99 293 551 minecraft:smooth_basalt
fill 109 293 546 109 297 546 minecraft:smooth_basalt
fill 111 293 511 113 293 511 minecraft:blackstone
setblock 114 293 511 minecraft:smooth_basalt
fill 115 293 511 118 293 511 minecraft:blackstone
setblock 128 293 512 minecraft:smooth_basalt
setblock 129 293 511 minecraft:smooth_basalt
fill 129 293 512 129 296 512 minecraft:blackstone
fill 130 293 511 130 296 511 minecraft:blackstone
setblock 131 293 514 minecraft:smooth_basalt
setblock 132 293 513 minecraft:smooth_basalt
fill 132 293 514 132 294 514 minecraft:blackstone
setblock 132 293 517 minecraft:blackstone
setblock 132 293 518 minecraft:smooth_basalt
setblock 133 293 512 minecraft:smooth_basalt
fill 133 293 513 133 296 513 minecraft:blackstone
setblock 133 293 517 minecraft:smooth_basalt
fill 133 293 518 133 296 518 minecraft:blackstone
fill 133 293 520 134 293 520 minecraft:blackstone
setblock 134 293 511 minecraft:smooth_basalt
fill 134 293 512 134 296 512 minecraft:blackstone
setblock 134 293 516 minecraft:smooth_basalt
fill 134 293 517 134 296 517 minecraft:blackstone
setblock 134 293 521 minecraft:smooth_basalt
fill 134 293 522 134 296 522 minecraft:blackstone
setblock 134 293 536 minecraft:smooth_basalt
fill 134 293 537 134 294 537 minecraft:blackstone
fill 134 293 539 134 293 540 minecraft:blackstone
setblock 134 293 551 minecraft:smooth_basalt
fill 135 293 511 135 296 511 minecraft:blackstone
setblock 135 293 515 minecraft:smooth_basalt
fill 135 293 516 135 296 516 minecraft:blackstone
setblock 135 293 520 minecraft:smooth_basalt
fill 135 293 521 135 296 521 minecraft:blackstone
setblock 135 293 525 minecraft:smooth_basalt
setblock 135 293 531 minecraft:blackstone
setblock 135 293 535 minecraft:smooth_basalt
fill 135 293 536 135 296 536 minecraft:blackstone
setblock 135 293 539 minecraft:blackstone
setblock 135 293 540 minecraft:smooth_basalt
fill 135 293 541 135 296 541 minecraft:blackstone
setblock 135 293 545 minecraft:smooth_basalt
fill 135 293 546 135 296 546 minecraft:blackstone
setblock 135 293 550 minecraft:smooth_basalt
fill 135 293 551 135 296 551 minecraft:blackstone
fill 95 294 511 95 294 513 minecraft:blackstone
setblock 95 294 514 minecraft:smooth_basalt
fill 95 294 515 95 294 518 minecraft:blackstone
setblock 95 294 519 minecraft:smooth_basalt
fill 95 294 520 95 297 520 minecraft:blackstone
setblock 95 294 534 minecraft:smooth_basalt
fill 95 294 535 95 294 538 minecraft:blackstone
setblock 95 294 539 minecraft:smooth_basalt
fill 95 294 540 95 294 543 minecraft:blackstone
setblock 95 294 544 minecraft:smooth_basalt
fill 95 294 545 95 294 548 minecraft:blackstone
setblock 95 294 549 minecraft:smooth_basalt
fill 95 294 550 95 296 551 minecraft:blackstone
fill 96 294 511 97 294 511 minecraft:blackstone
setblock 96 294 513 minecraft:smooth_basalt
fill 96 294 514 96 295 514 minecraft:blackstone
setblock 96 294 518 minecraft:smooth_basalt
fill 96 294 535 96 294 537 minecraft:blackstone
setblock 96 294 538 minecraft:smooth_basalt
fill 96 294 539 96 297 539 minecraft:blackstone
setblock 96 294 543 minecraft:smooth_basalt
fill 96 294 544 96 297 544 minecraft:blackstone
fill 96 294 551 97 294 551 minecraft:blackstone
setblock 98 294 511 minecraft:smooth_basalt
setblock 98 294 551 minecraft:smooth_basalt
setblock 112 294 511 minecraft:blackstone
setblock 113 294 511 minecraft:smooth_basalt
fill 114 294 511 115 294 511 minecraft:blackstone
setblock 128 294 511 minecraft:smooth_basalt
fill 128 294 512 128 297 512 minecraft:blackstone
fill 129 294 511 129 297 511 minecraft:blackstone
setblock 131 294 513 minecraft:smooth_basalt
setblock 132 294 512 minecraft:smooth_basalt
fill 132 294 513 132 297 513 minecraft:blackstone
setblock 132 294 517 minecraft:smooth_basalt
fill 132 294 518 132 297 518 minecraft:blackstone
setblock 133 294 511 minecraft:smooth_basalt
fill 133 294 512 133 297 512 minecraft:blackstone
setblock 133 294 516 minecraft:smooth_basalt
fill 133 294 517 133 297 517 minecraft:blackstone
setblock 133 294 520 minecraft:blackstone
setblock 133 294 551 minecraft:smooth_basalt
fill 134 294 511 134 297 511 minecraft:blackstone
setblock 134 294 515 minecraft:smooth_basalt
fill 134 294 516 134 297 516 minecraft:blackstone
setblock 134 294 519 minecraft:blackstone
setblock 134 294 520 minecraft:smooth_basalt
fill 134 294 521 134 297 521 minecraft:blackstone
setblock 134 294 536 minecraft:blackstone
setblock 134 294 539 minecraft:blackstone
setblock 134 294 540 minecraft:smooth_basalt
fill 134 294 551 134 297 551 minecraft:blackstone
setblock 135 294 514 minecraft:smooth_basalt
fill 135 294 515 135 297 515 minecraft:blackstone
setblock 135 294 519 minecraft:smooth_basalt
fill 135 294 520 135 297 520 minecraft:blackstone
setblock 135 294 524 minecraft:smooth_basalt
setblock 135 294 534 minecraft:smooth_basalt
fill 135 294 535 135 296 535 minecraft:blackstone
setblock 135 294 539 minecraft:smooth_basalt
fill 135 294 540 135 297 540 minecraft:blackstone
setblock 135 294 544 minecraft:smooth_basalt
fill 135 294 545 135 297 545 minecraft:blackstone
setblock 135 294 549 minecraft:smooth_basalt
fill 135 294 550 135 297 550 minecraft:blackstone
fill 95 295 511 95 295 512 minecraft:blackstone
setblock 95 295 513 minecraft:smooth_basalt
fill 95 295 514 95 295 517 minecraft:blackstone
setblock 95 295 518 minecraft:smooth_basalt
fill 95 295 519 95 298 519 minecraft:blackstone
fill 95 295 534 95 295 537 minecraft:blackstone
setblock 95 295 538 minecraft:smooth_basalt
fill 95 295 539 95 295 542 minecraft:blackstone
setblock 95 295 543 minecraft:smooth_basalt
fill 95 295 544 95 295 547 minecraft:blackstone
setblock 95 295 548 minecraft:smooth_basalt
fill 95 295 549 95 298 549 minecraft:blackstone
setblock 96 295 511 minecraft:blackstone
setblock 96 295 517 minecraft:smooth_basalt
setblock 96 295 536 minecraft:blackstone
setblock 96 295 537 minecraft:smooth_basalt
fill 96 295 538 96 298 538 minecraft:blackstone
setblock 96 295 542 minecraft:smooth_basalt
fill 96 295 543 96 298 543 minecraft:blackstone
setblock 96 295 551 minecraft:blackstone
setblock 97 295 511 minecraft:smooth_basalt
setblock 97 295 551 minecraft:smooth_basalt
setblock 127 295 511 minecraft:smooth_basalt
fill 128 295 511 128 298 511 minecraft:blackstone
setblock 130 295 513 minecraft:smooth_basalt
setblock 131 295 512 minecraft:smooth_basalt
fill 131 295 513 131 298 513 minecraft:blackstone
setblock 132 295 511 minecraft:smooth_basalt
fill 132 295 512 132 298 512 minecraft:blackstone
setblock 132 295 516 minecraft:smooth_basalt
fill 132 295 517 132 298 517 minecraft:blackstone
setblock 132 295 551 minecraft:smooth_basalt
fill 133 295 511 133 298 511 minecraft:blackstone
setblock 133 295 515 minecraft:smooth_basalt
fill 133 295 516 133 298 516 minecraft:blackstone
setblock 133 295 520 minecraft:smooth_basalt
fill 133 295 521 133 298 521 minecraft:blackstone
fill 133 295 551 133 298 551 minecraft:blackstone
setblock 134 295 514 minecraft:smooth_basalt
fill 134 295 515 134 298 515 minecraft:blackstone
setblock 134 295 519 minecraft:smooth_basalt
fill 134 295 520 134 298 520 minecraft:blackstone
setblock 134 295 539 minecraft:smooth_basalt
fill 134 295 540 134 297 541 minecraft:blackstone
setblock 135 295 513 minecraft:smooth_basalt
fill 135 295 514 135 298 514 minecraft:blackstone
setblock 135 295 518 minecraft:smooth_basalt
fill 135 295 519 135 298 519 minecraft:blackstone
setblock 135 295 523 minecraft:smooth_basalt
fill 135 295 524 135 298 524 minecraft:blackstone
setblock 135 295 534 minecraft:blackstone
setblock 135 295 538 minecraft:smooth_basalt
fill 135 295 539 135 298 539 minecraft:blackstone
setblock 135 295 543 minecraft:smooth_basalt
fill 135 295 544 135 298 544 minecraft:blackstone
setblock 135 295 548 minecraft:smooth_basalt
fill 135 295 549 135 298 549 minecraft:blackstone
setblock 95 296 511 minecraft:blackstone
setblock 95 296 512 minecraft:smooth_basalt
fill 95 296 513 95 296 516 minecraft:blackstone
setblock 95 296 517 minecraft:smooth_basalt
fill 95 296 518 95 299 518 minecraft:blackstone
fill 95 296 534 95 296 536 minecraft:blackstone
setblock 95 296 537 minecraft:smooth_basalt
fill 95 296 538 95 296 541 minecraft:blackstone
setblock 95 296 542 minecraft:smooth_basalt
fill 95 296 543 95 296 546 minecraft:blackstone
setblock 95 296 547 minecraft:smooth_basalt
fill 95 296 548 95 299 548 minecraft:blackstone
setblock 96 296 511 minecraft:smooth_basalt
fill 96 296 537 96 298 537 minecraft:blackstone
setblock 96 296 541 minecraft:smooth_basalt
fill 96 296 542 96 299 542 minecraft:blackstone
setblock 96 296 551 minecraft:smooth_basalt
setblock 97 296 513 minecraft:light[level=12]
setblock 97 296 521 minecraft:light[level=12]
setblock 97 296 529 minecraft:light[level=12]
setblock 97 296 537 minecraft:light[level=12]
setblock 97 296 545 minecraft:light[level=12]
setblock 105 296 513 minecraft:light[level=12]
setblock 105 296 521 minecraft:light[level=12]
setblock 105 296 529 minecraft:light[level=12]
setblock 105 296 537 minecraft:light[level=12]
setblock 105 296 545 minecraft:light[level=12]
setblock 113 296 513 minecraft:light[level=12]
setblock 113 296 521 minecraft:light[level=12]
setblock 113 296 529 minecraft:light[level=12]
setblock 113 296 537 minecraft:light[level=12]
setblock 113 296 545 minecraft:light[level=12]
setblock 121 296 513 minecraft:light[level=12]
setblock 121 296 521 minecraft:light[level=12]
setblock 121 296 537 minecraft:light[level=12]
setblock 121 296 545 minecraft:light[level=12]
fill 127 296 511 127 299 511 minecraft:blackstone
setblock 129 296 513 minecraft:light[level=12]
setblock 129 296 521 minecraft:light[level=12]
setblock 129 296 529 minecraft:light[level=12]
setblock 129 296 537 minecraft:light[level=12]
setblock 129 296 545 minecraft:light[level=12]
setblock 130 296 512 minecraft:smooth_basalt
fill 130 296 513 130 299 513 minecraft:blackstone
setblock 131 296 511 minecraft:smooth_basalt
fill 131 296 512 131 299 512 minecraft:blackstone
setblock 131 296 551 minecraft:smooth_basalt
fill 132 296 511 132 299 511 minecraft:blackstone
setblock 132 296 515 minecraft:smooth_basalt
fill 132 296 516 132 298 516 minecraft:blackstone
fill 132 296 551 132 299 551 minecraft:blackstone
setblock 133 296 514 minecraft:smooth_basalt
fill 133 296 515 133 299 515 minecraft:blackstone
setblock 133 296 519 minecraft:smooth_basalt
fill 133 296 520 133 299 520 minecraft:blackstone
setblock 134 296 513 minecraft:smooth_basalt
fill 134 296 514 134 299 514 minecraft:blackstone
setblock 134 296 518 minecraft:smooth_basalt
fill 134 296 519 134 299 519 minecraft:blackstone
setblock 134 296 523 minecraft:smooth_basalt
setblock 134 296 538 minecraft:smooth_basalt
fill 134 296 539 134 299 539 minecraft:blackstone
setblock 134 296 542 minecraft:blackstone
setblock 134 296 543 minecraft:smooth_basalt
setblock 135 296 512 minecraft:smooth_basalt
fill 135 296 513 135 299 513 minecraft:blackstone
setblock 135 296 517 minecraft:smooth_basalt
fill 135 296 518 135 299 518 minecraft:blackstone
setblock 135 296 522 minecraft:smooth_basalt
fill 135 296 523 135 299 523 minecraft:blackstone
setblock 135 296 537 minecraft:smooth_basalt
fill 135 296 538 135 299 538 minecraft:blackstone
setblock 135 296 542 minecraft:smooth_basalt
fill 135 296 543 135 299 543 minecraft:blackstone
setblock 135 296 547 minecraft:smooth_basalt
fill 135 296 548 135 299 548 minecraft:blackstone
setblock 95 297 511 minecraft:smooth_basalt
fill 95 297 512 95 297 515 minecraft:blackstone
setblock 95 297 516 minecraft:smooth_basalt
fill 95 297 517 95 300 517 minecraft:blackstone
setblock 95 297 521 minecraft:smooth_basalt
fill 95 297 522 95 300 522 minecraft:blackstone
setblock 95 297 535 minecraft:blackstone
setblock 95 297 536 minecraft:smooth_basalt
fill 95 297 537 95 297 540 minecraft:blackstone
setblock 95 297 541 minecraft:smooth_basalt
fill 95 297 542 95 297 545 minecraft:blackstone
setblock 95 297 546 minecraft:smooth_basalt
fill 95 297 547 95 300 547 minecraft:blackstone
setblock 95 297 550 minecraft:blackstone
setblock 95 297 551 minecraft:smooth_basalt
setblock 96 297 540 minecraft:smooth_basalt
fill 96 297 541 96 300 541 minecraft:blackstone
setblock 96 297 545 minecraft:smooth_basalt
fill 96 297 546 96 300 546 minecraft:blackstone
fill 96 297 551 96 300 551 minecraft:blackstone
fill 100 297 525 102 297 527 minecraft:gold_block
fill 101 297 523 103 297 524 minecraft:gold_block
fill 101 297 528 102 297 529 minecraft:gold_block
fill 102 297 522 107 297 522 minecraft:gold_block
fill 102 297 530 108 297 530 minecraft:gold_block
fill 103 297 529 109 297 529 minecraft:gold_block
fill 104 297 523 108 297 523 minecraft:gold_block
fill 104 297 531 106 297 531 minecraft:gold_block
fill 107 297 524 109 297 524 minecraft:gold_block
fill 107 297 528 109 297 528 minecraft:gold_block
fill 108 297 525 109 297 527 minecraft:gold_block
fill 115 297 541 116 297 542 minecraft:gold_block
fill 116 297 540 120 297 540 minecraft:gold_block
fill 116 297 543 117 297 544 minecraft:gold_block
fill 117 297 539 119 297 539 minecraft:gold_block
fill 118 297 525 118 297 530 minecraft:gold_block
fill 118 297 544 119 297 544 minecraft:gold_block
fill 119 297 525 119 298 526 minecraft:gold_block
fill 119 297 527 122 300 528 minecraft:smooth_basalt
fill 119 297 529 119 298 530 minecraft:gold_block
fill 119 297 543 120 298 543 minecraft:gold_block
fill 120 297 520 121 297 525 minecraft:gold_block
fill 120 297 530 124 297 531 minecraft:gold_block
fill 120 297 534 121 297 534 minecraft:gold_block
fill 120 297 541 120 298 542 minecraft:gold_block
fill 121 297 526 126 297 526 minecraft:gold_block
fill 121 297 532 121 297 533 minecraft:gold_block
fill 121 297 535 122 297 536 minecraft:gold_block
fill 122 297 519 125 297 520 minecraft:gold_block
fill 122 297 525 122 299 525 minecraft:gold_block
fill 122 297 532 123 299 532 minecraft:gold_block
fill 123 297 527 124 297 527 minecraft:gold_block
fill 123 297 528 123 300 528 minecraft:smooth_basalt
fill 123 297 529 124 298 529 minecraft:gold_block
fill 123 297 533 123 297 534 minecraft:gold_block
fill 123 297 536 124 297 537 minecraft:gold_block
fill 124 297 528 124 298 528 minecraft:gold_block
fill 124 297 534 125 297 535 minecraft:gold_block
fill 125 297 525 127 297 525 minecraft:gold_block
fill 125 297 530 127 297 530 minecraft:gold_block
fill 125 297 536 125 298 536 minecraft:gold_block
fill 126 297 511 126 300 511 minecraft:blackstone
fill 126 297 520 127 297 524 minecraft:gold_block
fill 126 297 535 127 297 535 minecraft:gold_block
fill 127 297 531 128 297 531 minecraft:gold_block
fill 127 297 534 128 297 534 minecraft:gold_block
fill 128 297 532 128 298 533 minecraft:gold_block
setblock 129 297 512 minecraft:smooth_basalt
fill 129 297 513 129 300 513 minecraft:blackstone
setblock 130 297 511 minecraft:smooth_basalt
fill 130 297 512 130 300 512 minecraft:blackstone
setblock 130 297 551 minecraft:smooth_basalt
fill 131 297 511 131 300 511 minecraft:blackstone
fill 131 297 551 131 300 551 minecraft:blackstone
setblock 132 297 519 minecraft:smooth_basalt
setblock 133 297 513 minecraft:smooth_basalt
fill 133 297 514 133 299 514 minecraft:blackstone
setblock 133 297 518 minecraft:smooth_basalt
fill 133 297 519 133 300 519 minecraft:blackstone
setblock 134 297 512 minecraft:smooth_basalt
fill 134 297 513 134 300 513 minecraft:blackstone
setblock 134 297 517 minecraft:smooth_basalt
fill 134 297 518 134 300 518 minecraft:blackstone
setblock 134 297 522 minecraft:smooth_basalt
fill 134 297 523 134 300 523 minecraft:blackstone
setblock 134 297 542 minecraft:smooth_basalt
fill 134 297 543 134 299 544 minecraft:blackstone
setblock 135 297 511 minecraft:smooth_basalt
fill 135 297 512 135 300 512 minecraft:blackstone
setblock 135 297 516 minecraft:smooth_basalt
fill 135 297 517 135 300 517 minecraft:blackstone
setblock 135 297 521 minecraft:smooth_basalt
fill 135 297 522 135 300 522 minecraft:blackstone
setblock 135 297 536 minecraft:smooth_basalt
fill 135 297 537 135 300 537 minecraft:blackstone
setblock 135 297 541 minecraft:smooth_basalt
fill 135 297 542 135 300 542 minecraft:blackstone
setblock 135 297 546 minecraft:smooth_basalt
fill 135 297 547 135 300 547 minecraft:blackstone
setblock 135 297 551 minecraft:smooth_basalt
fill 95 298 512 95 298 514 minecraft:blackstone
setblock 95 298 515 minecraft:smooth_basalt
fill 95 298 516 95 300 516 minecraft:blackstone
setblock 95 298 520 minecraft:smooth_basalt
fill 95 298 521 95 300 521 minecraft:blackstone
setblock 95 298 535 minecraft:smooth_basalt
fill 95 298 536 95 298 539 minecraft:blackstone
setblock 95 298 540 minecraft:smooth_basalt
fill 95 298 541 95 298 544 minecraft:blackstone
setblock 95 298 545 minecraft:smooth_basalt
fill 95 298 546 95 300 546 minecraft:blackstone
setblock 95 298 550 minecraft:smooth_basalt
fill 95 298 551 95 300 551 minecraft:blackstone
setblock 96 298 539 minecraft:smooth_basalt
fill 96 298 540 96 300 540 minecraft:blackstone
setblock 96 298 544 minecraft:smooth_basalt
fill 96 298 545 96 300 545 minecraft:blackstone
fill 96 298 547 96 299 547 minecraft:blackstone
fill 101 298 525 102 298 528 minecraft:gold_block
fill 102 298 523 103 298 524 minecraft:gold_block
fill 102 298 529 108 298 529 minecraft:gold_block
fill 103 298 530 106 298 530 minecraft:gold_block
fill 104 298 522 106 298 523 minecraft:gold_block
fill 107 298 523 107 298 524 minecraft:gold_block
fill 107 298 528 108 298 528 minecraft:gold_block
fill 108 298 524 108 298 527 minecraft:gold_block
fill 109 298 526 109 298 527 minecraft:gold_block
setblock 109 298 546 minecraft:shroomlight
fill 116 298 540 116 298 543 minecraft:gold_block
fill 117 298 540 119 299 540 minecraft:gold_block
fill 117 298 543 117 298 544 minecraft:gold_block
fill 118 298 526 118 298 529 minecraft:gold_block
setblock 118 298 544 minecraft:gold_block
fill 120 298 522 121 298 525 minecraft:gold_block
fill 120 298 530 123 298 530 minecraft:gold_block
fill 121 298 520 121 298 521 minecraft:gold_block
fill 121 298 526 121 300 526 minecraft:smooth_basalt
fill 121 298 533 121 298 535 minecraft:gold_block
fill 122 298 520 126 298 520 minecraft:gold_block
fill 122 298 526 125 298 526 minecraft:gold_block
fill 122 298 535 122 298 536 minecraft:gold_block
fill 123 298 527 123 300 527 minecraft:smooth_basalt
fill 123 298 531 124 298 531 minecraft:gold_block
setblock 123 298 533 minecraft:gold_block
fill 123 298 534 123 300 534 minecraft:smooth_basalt
fill 123 298 536 124 299 536 minecraft:gold_block
setblock 124 298 527 minecraft:gold_block
fill 124 298 534 125 298 534 minecraft:gold_block
fill 124 298 535 124 300 535 minecraft:smooth_basalt
fill 125 298 525 126 298 525 minecraft:gold_block
fill 125 298 530 126 298 530 minecraft:gold_block
fill 125 298 535 126 298 535 minecraft:gold_block
fill 125 298 543 126 299 543 minecraft:gilded_blackstone
fill 126 298 521 126 298 524 minecraft:gold_block
setblock 127 298 512 minecraft:blackstone
fill 127 298 522 127 298 524 minecraft:gold_block
fill 127 298 531 127 299 531 minecraft:gold_block
fill 127 298 534 127 299 534 minecraft:gold_block
setblock 128 298 512 minecraft:smooth_basalt
setblock 129 298 511 minecraft:smooth_basalt
fill 129 298 512 129 300 512 minecraft:blackstone
setblock 129 298 551 minecraft:smooth_basalt
fill 130 298 511 130 300 511 minecraft:blackstone
fill 130 298 551 130 300 551 minecraft:blackstone
setblock 132 298 513 minecraft:smooth_basalt
setblock 132 298 518 minecraft:smooth_basalt
fill 132 298 519 132 300 519 minecraft:blackstone
setblock 133 298 512 minecraft:smooth_basalt
setblock 133 298 513 minecraft:blackstone
setblock 133 298 517 minecraft:smooth_basalt
fill 133 298 518 133 300 518 minecraft:blackstone
setblock 133 298 522 minecraft:smooth_basalt
setblock 134 298 511 minecraft:smooth_basalt
fill 134 298 512 134 300 512 minecraft:blackstone
setblock 134 298 516 minecraft:smooth_basalt
fill 134 298 517 134 300 517 minecraft:blackstone
setblock 134 298 521 minecraft:smooth_basalt
fill 134 298 522 134 300 522 minecraft:blackstone
setblock 134 298 540 minecraft:blackstone
setblock 134 298 541 minecraft:smooth_basalt
fill 134 298 542 134 300 542 minecraft:blackstone
setblock 134 298 545 minecraft:blackstone
setblock 134 298 546 minecraft:smooth_basalt
fill 134 298 547 134 300 547 minecraft:blackstone
setblock 134 298 551 minecraft:smooth_basalt
fill 135 298 511 135 300 511 minecraft:blackstone
setblock 135 298 515 minecraft:smooth_basalt
fill 135 298 516 135 300 516 minecraft:blackstone
setblock 135 298 520 minecraft:smooth_basalt
fill 135 298 521 135 300 521 minecraft:blackstone
setblock 135 298 525 minecraft:smooth_basalt
setblock 135 298 540 minecraft:smooth_basalt
fill 135 298 541 135 300 541 minecraft:blackstone
setblock 135 298 545 minecraft:smooth_basalt
fill 135 298 546 135 300 546 minecraft:blackstone
setblock 135 298 550 minecraft:smooth_basalt
fill 135 298 551 135 300 551 minecraft:blackstone
setblock 95 299 514 minecraft:smooth_basalt
fill 95 299 515 95 300 515 minecraft:blackstone
setblock 95 299 519 minecraft:smooth_basalt
fill 95 299 520 95 300 520 minecraft:blackstone
setblock 95 299 523 minecraft:blackstone
fill 95 299 535 95 299 538 minecraft:blackstone
setblock 95 299 539 minecraft:smooth_basalt
fill 95 299 540 95 299 543 minecraft:blackstone
setblock 95 299 544 minecraft:smooth_basalt
fill 95 299 545 95 300 545 minecraft:blackstone
setblock 95 299 549 minecraft:smooth_basalt
fill 95 299 550 95 300 550 minecraft:blackstone
setblock 96 299 538 minecraft:smooth_basalt
fill 96 299 539 96 300 539 minecraft:blackstone
setblock 96 299 543 minecraft:smooth_basalt
fill 96 299 544 96 300 544 minecraft:blackstone
setblock 96 299 548 minecraft:smooth_basalt
setblock 97 299 542 minecraft:smooth_basalt
fill 97 299 543 97 300 543 minecraft:blackstone
fill 102 299 525 102 299 528 minecraft:gold_block
setblock 103 299 524 minecraft:gold_block
fill 103 299 529 106 299 529 minecraft:gold_block
fill 104 299 523 106 299 523 minecraft:gold_block
setblock 107 299 524 minecraft:gold_block
setblock 107 299 528 minecraft:gold_block
fill 108 299 525 108 299 527 minecraft:gold_block
fill 116 299 541 116 299 542 minecraft:gold_block
setblock 117 299 543 minecraft:gold_block
setblock 119 299 526 minecraft:gold_block
setblock 119 299 529 minecraft:gold_block
setblock 119 299 543 minecraft:gold_block
fill 120 299 525 121 299 525 minecraft:gold_block
fill 120 299 530 122 299 530 minecraft:gold_block
fill 121 299 521 121 299 524 minecraft:gold_block
fill 122 299 526 122 300 526 minecraft:smooth_basalt
setblock 122 299 535 minecraft:gold_block
fill 123 299 520 124 299 520 minecraft:gold_block
setblock 123 299 526 minecraft:gold_block
setblock 123 299 529 minecraft:gold_block
fill 123 299 533 123 300 533 minecraft:smooth_basalt
setblock 124 299 531 minecraft:gold_block
fill 124 299 534 124 300 534 minecraft:smooth_basalt
fill 125 299 511 125 300 511 minecraft:blackstone
setblock 125 299 525 minecraft:gold_block
fill 125 299 534 125 299 535 minecraft:gold_block
setblock 126 299 512 minecraft:blackstone
fill 126 299 522 126 299 524 minecraft:gold_block
setblock 127 299 512 minecraft:smooth_basalt
setblock 127 299 551 minecraft:blackstone
setblock 128 299 511 minecraft:smooth_basalt
fill 128 299 512 128 300 513 minecraft:blackstone
setblock 128 299 551 minecraft:smooth_basalt
fill 129 299 511 129 300 511 minecraft:blackstone
fill 129 299 551 129 300 551 minecraft:blackstone
fill 130 299 550 133 299 550 minecraft:blackstone
setblock 131 299 513 minecraft:smooth_basalt
setblock 132 299 512 minecraft:smooth_basalt
fill 132 299 513 132 300 513 minecraft:blackstone
setblock 132 299 517 minecraft:smooth_basalt
fill 132 299 518 132 300 518 minecraft:blackstone
fill 132 299 520 132 300 520 minecraft:blackstone
setblock 133 299 511 minecraft:smooth_basalt
fill 133 299 512 133 300 512 minecraft:blackstone
setblock 133 299 516 minecraft:smooth_basalt
fill 133 299 517 133 300 517 minecraft:blackstone
setblock 133 299 521 minecraft:smooth_basalt
fill 133 299 522 133 300 522 minecraft:blackstone
fill 133 299 543 133 300 543 minecraft:blackstone
setblock 133 299 551 minecraft:smooth_basalt
fill 134 299 511 134 300 511 minecraft:blackstone
setblock 134 299 515 minecraft:smooth_basalt
fill 134 299 516 134 300 516 minecraft:blackstone
setblock 134 299 520 minecraft:smooth_basalt
fill 134 299 521 134 300 521 minecraft:blackstone
setblock 134 299 524 minecraft:blackstone
setblock 134 299 540 minecraft:smooth_basalt
fill 134 299 541 134 300 541 minecraft:blackstone
setblock 134 299 545 minecraft:smooth_basalt
fill 134 299 546 134 300 546 minecraft:blackstone
fill 134 299 548 134 299 549 minecraft:blackstone
fill 134 299 551 134 300 551 minecraft:blackstone
setblock 135 299 514 minecraft:smooth_basalt
fill 135 299 515 135 300 515 minecraft:blackstone
setblock 135 299 519 minecraft:smooth_basalt
fill 135 299 520 135 300 520 minecraft:blackstone
setblock 135 299 524 minecraft:smooth_basalt
fill 135 299 525 135 300 525 minecraft:blackstone
setblock 135 299 539 minecraft:smooth_basalt
fill 135 299 540 135 300 540 minecraft:blackstone
setblock 135 299 544 minecraft:smooth_basalt
fill 135 299 545 135 300 545 minecraft:blackstone
setblock 135 299 549 minecraft:smooth_basalt
fill 135 299 550 135 300 550 minecraft:blackstone
setblock 95 300 518 minecraft:smooth_basalt
setblock 95 300 519 minecraft:blackstone
setblock 95 300 523 minecraft:smooth_basalt
setblock 95 300 524 minecraft:blackstone
fill 95 300 535 95 300 537 minecraft:blackstone
setblock 95 300 538 minecraft:smooth_basalt
fill 95 300 539 95 300 542 minecraft:blackstone
setblock 95 300 543 minecraft:smooth_basalt
setblock 95 300 544 minecraft:blackstone
setblock 95 300 548 minecraft:smooth_basalt
setblock 95 300 549 minecraft:blackstone
setblock 96 300 538 minecraft:blackstone
setblock 96 300 542 minecraft:smooth_basalt
setblock 96 300 543 minecraft:blackstone
setblock 96 300 547 minecraft:smooth_basalt
setblock 96 300 548 minecraft:blackstone
setblock 97 300 541 minecraft:smooth_basalt
setblock 97 300 542 minecraft:blackstone
setblock 97 300 544 minecraft:blackstone
setblock 107 300 551 minecraft:smooth_basalt
fill 108 300 551 111 300 551 minecraft:blackstone
setblock 124 300 511 minecraft:blackstone
setblock 125 300 534 minecraft:smooth_basalt
setblock 126 300 512 minecraft:smooth_basalt
setblock 126 300 551 minecraft:blackstone
setblock 127 300 511 minecraft:smooth_basalt
setblock 127 300 512 minecraft:blackstone
setblock 127 300 551 minecraft:smooth_basalt
setblock 128 300 511 minecraft:blackstone
setblock 128 300 550 minecraft:smooth_basalt
setblock 128 300 551 minecraft:blackstone
fill 129 300 550 132 300 550 minecraft:blackstone
setblock 130 300 513 minecraft:smooth_basalt
setblock 131 300 512 minecraft:smooth_basalt
setblock 131 300 513 minecraft:blackstone
setblock 132 300 511 minecraft:smooth_basalt
setblock 132 300 512 minecraft:blackstone
setblock 132 300 551 minecraft:smooth_basalt
setblock 133 300 511 minecraft:blackstone
setblock 133 300 515 minecraft:smooth_basalt
setblock 133 300 516 minecraft:blackstone
setblock 133 300 520 minecraft:smooth_basalt
setblock 133 300 521 minecraft:blackstone
setblock 133 300 523 minecraft:blackstone
setblock 133 300 542 minecraft:blackstone
setblock 133 300 544 minecraft:blackstone
setblock 133 300 545 minecraft:smooth_basalt
setblock 133 300 546 minecraft:blackstone
setblock 133 300 550 minecraft:smooth_basalt
setblock 133 300 551 minecraft:blackstone
setblock 134 300 514 minecraft:smooth_basalt
setblock 134 300 515 minecraft:blackstone
setblock 134 300 519 minecraft:smooth_basalt
setblock 134 300 520 minecraft:blackstone
setblock 134 300 524 minecraft:smooth_basalt
setblock 134 300 539 minecraft:smooth_basalt
setblock 134 300 540 minecraft:blackstone
setblock 134 300 543 minecraft:blackstone
setblock 134 300 544 minecraft:smooth_basalt
setblock 134 300 545 minecraft:blackstone
setblock 134 300 548 minecraft:blackstone
setblock 134 300 549 minecraft:smooth_basalt
setblock 134 300 550 minecraft:blackstone
setblock 135 300 513 minecraft:smooth_basalt
setblock 135 300 514 minecraft:blackstone
setblock 135 300 518 minecraft:smooth_basalt
setblock 135 300 519 minecraft:blackstone
setblock 135 300 523 minecraft:smooth_basalt
setblock 135 300 524 minecraft:blackstone
setblock 135 300 538 minecraft:smooth_basalt
setblock 135 300 539 minecraft:blackstone
setblock 135 300 543 minecraft:smooth_basalt
setblock 135 300 544 minecraft:blackstone
setblock 135 300 548 minecraft:smooth_basalt
setblock 135 300 549 minecraft:blackstone
