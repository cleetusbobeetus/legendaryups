fill 418 58 643 418 59 643 minecraft:red_concrete
fill 418 58 646 418 63 646 minecraft:black_concrete
setblock 376 59 610 minecraft:red_concrete
fill 376 59 614 376 62 615 minecraft:black_concrete
setblock 376 59 631 minecraft:red_concrete
setblock 376 59 634 minecraft:red_concrete
fill 376 59 635 376 62 635 minecraft:black_concrete
setblock 376 59 642 minecraft:red_concrete
fill 376 59 646 376 62 646 minecraft:black_concrete
fill 381 59 604 381 62 604 minecraft:black_concrete
setblock 382 59 604 minecraft:red_concrete
setblock 385 59 604 minecraft:red_concrete
fill 390 59 604 390 61 604 minecraft:black_concrete
fill 392 59 646 393 59 646 minecraft:red_concrete
setblock 396 59 646 minecraft:red_concrete
fill 397 59 646 397 62 646 minecraft:black_concrete
fill 401 59 604 401 62 604 minecraft:black_concrete
setblock 402 59 604 minecraft:red_concrete
setblock 406 59 604 minecraft:red_concrete
fill 408 59 646 408 62 646 minecraft:black_concrete
setblock 413 59 646 minecraft:red_concrete
setblock 417 59 604 minecraft:red_concrete
fill 418 59 604 418 61 604 minecraft:black_concrete
fill 418 59 608 418 62 608 minecraft:black_concrete
setblock 418 59 612 minecraft:red_concrete
fill 418 59 619 418 62 619 minecraft:black_concrete
setblock 418 59 620 minecraft:red_concrete
setblock 418 59 623 minecraft:red_concrete
fill 418 59 639 418 62 640 minecraft:black_concrete
setblock 418 59 644 minecraft:red_concrete
fill 376 60 608 376 61 609 minecraft:red_concrete
fill 376 60 610 376 65 611 minecraft:black_concrete
setblock 376 60 612 minecraft:red_concrete
fill 376 60 620 376 61 621 minecraft:red_concrete
fill 376 60 622 376 65 623 minecraft:black_concrete
fill 376 60 629 376 61 629 minecraft:red_concrete
fill 376 60 631 376 65 631 minecraft:black_concrete
fill 376 60 632 376 60 633 minecraft:red_concrete
fill 376 60 634 376 65 634 minecraft:black_concrete
fill 376 60 640 376 61 641 minecraft:red_concrete
fill 376 60 642 376 65 643 minecraft:black_concrete
fill 377 60 605 379 60 605 minecraft:polished_blackstone
fill 377 60 607 377 60 609 minecraft:polished_blackstone
fill 377 60 611 377 60 613 minecraft:polished_blackstone
fill 377 60 615 377 60 617 minecraft:polished_blackstone
fill 377 60 619 377 60 621 minecraft:polished_blackstone
fill 377 60 623 377 60 625 minecraft:polished_blackstone
fill 377 60 627 377 60 629 minecraft:polished_blackstone
fill 377 60 631 377 60 633 minecraft:polished_blackstone
fill 377 60 635 377 60 637 minecraft:polished_blackstone
fill 377 60 639 377 60 641 minecraft:polished_blackstone
fill 377 60 643 377 60 645 minecraft:polished_blackstone
fill 379 60 645 381 60 645 minecraft:polished_blackstone
fill 381 60 605 383 60 605 minecraft:polished_blackstone
fill 382 60 604 382 65 604 minecraft:black_concrete
fill 382 60 646 383 60 646 minecraft:red_concrete
fill 383 60 604 384 60 604 minecraft:red_concrete
fill 383 60 645 385 60 645 minecraft:polished_blackstone
fill 384 60 646 385 65 646 minecraft:black_concrete
fill 385 60 604 385 65 604 minecraft:black_concrete
fill 385 60 605 387 60 605 minecraft:polished_blackstone
fill 387 60 604 387 61 604 minecraft:red_concrete
fill 387 60 645 389 60 645 minecraft:polished_blackstone
setblock 388 60 604 minecraft:black_concrete
fill 389 60 605 391 60 605 minecraft:polished_blackstone
fill 391 60 645 393 60 645 minecraft:polished_blackstone
fill 391 60 646 391 61 646 minecraft:red_concrete
fill 392 60 646 393 65 646 minecraft:black_concrete
fill 393 60 604 394 65 604 minecraft:black_concrete
fill 393 60 605 395 60 605 minecraft:polished_blackstone
setblock 394 60 646 minecraft:red_concrete
fill 395 60 604 396 61 604 minecraft:red_concrete
fill 395 60 645 397 60 645 minecraft:polished_blackstone
fill 396 60 646 396 65 646 minecraft:black_concrete
fill 397 60 605 399 60 605 minecraft:polished_blackstone
fill 399 60 645 401 60 645 minecraft:polished_blackstone
fill 401 60 605 403 60 605 minecraft:polished_blackstone
fill 402 60 604 402 62 604 minecraft:black_concrete
fill 402 60 646 403 61 646 minecraft:red_concrete
fill 403 60 645 405 60 645 minecraft:polished_blackstone
setblock 404 60 604 minecraft:red_concrete
fill 404 60 646 405 65 646 minecraft:black_concrete
fill 405 60 604 406 65 604 minecraft:black_concrete
fill 405 60 605 407 60 605 minecraft:polished_blackstone
fill 407 60 604 408 61 604 minecraft:red_concrete
fill 407 60 645 409 60 645 minecraft:polished_blackstone
fill 409 60 605 411 60 605 minecraft:polished_blackstone
fill 411 60 645 413 60 645 minecraft:polished_blackstone
fill 413 60 604 414 65 604 minecraft:black_concrete
fill 413 60 605 415 60 605 minecraft:polished_blackstone
fill 413 60 646 413 65 646 minecraft:black_concrete
fill 414 60 646 415 60 646 minecraft:red_concrete
fill 415 60 604 416 60 604 minecraft:red_concrete
fill 415 60 645 417 60 645 minecraft:polished_blackstone
fill 416 60 646 417 65 646 minecraft:black_concrete
fill 417 60 604 417 61 604 minecraft:black_concrete
fill 417 60 605 417 60 607 minecraft:polished_blackstone
fill 417 60 609 417 60 611 minecraft:polished_blackstone
fill 417 60 613 417 60 615 minecraft:polished_blackstone
fill 417 60 617 417 60 619 minecraft:polished_blackstone
fill 417 60 621 417 60 623 minecraft:polished_blackstone
fill 417 60 625 417 60 627 minecraft:polished_blackstone
fill 417 60 629 417 60 631 minecraft:polished_blackstone
fill 417 60 633 417 60 635 minecraft:polished_blackstone
fill 417 60 637 417 60 639 minecraft:polished_blackstone
fill 417 60 641 417 60 643 minecraft:polished_blackstone
fill 418 60 611 418 65 612 minecraft:black_concrete
fill 418 60 613 418 61 614 minecraft:red_concrete
fill 418 60 620 418 65 620 minecraft:black_concrete
fill 418 60 621 418 60 622 minecraft:red_concrete
fill 418 60 623 418 65 623 minecraft:black_concrete
fill 418 60 625 418 61 625 minecraft:red_concrete
fill 418 60 631 418 65 632 minecraft:black_concrete
fill 418 60 633 418 61 634 minecraft:red_concrete
setblock 418 60 642 minecraft:red_concrete
fill 418 60 643 418 65 644 minecraft:black_concrete
fill 418 60 645 418 61 645 minecraft:red_concrete
fill 376 61 612 376 64 612 minecraft:black_concrete
setblock 376 61 617 minecraft:red_concrete
setblock 376 61 628 minecraft:red_concrete
fill 376 61 632 376 64 633 minecraft:black_concrete
setblock 379 61 646 minecraft:red_concrete
setblock 382 61 646 minecraft:red_concrete
fill 383 61 604 384 64 604 minecraft:black_concrete
fill 383 61 646 383 64 646 minecraft:black_concrete
setblock 388 61 604 minecraft:red_concrete
setblock 390 61 646 minecraft:red_concrete
fill 394 61 646 394 64 646 minecraft:black_concrete
setblock 399 61 604 minecraft:red_concrete
fill 400 61 604 400 63 604 minecraft:black_concrete
fill 404 61 604 404 64 604 minecraft:black_concrete
fill 405 61 617 406 62 618 minecraft:red_concrete
fill 410 61 646 411 61 646 minecraft:red_concrete
setblock 414 61 646 minecraft:red_concrete
fill 415 61 604 415 64 604 minecraft:black_concrete
fill 415 61 646 415 64 646 minecraft:black_concrete
setblock 416 61 604 minecraft:red_concrete
fill 418 61 605 418 61 606 minecraft:red_concrete
fill 418 61 621 418 64 622 minecraft:black_concrete
setblock 418 61 626 minecraft:red_concrete
setblock 418 61 637 minecraft:red_concrete
fill 418 61 642 418 64 642 minecraft:black_concrete
fill 376 62 606 376 63 607 minecraft:red_concrete
fill 376 62 608 376 67 609 minecraft:black_concrete
fill 376 62 617 376 67 617 minecraft:black_concrete
fill 376 62 618 376 62 619 minecraft:red_concrete
fill 376 62 620 376 67 621 minecraft:black_concrete
fill 376 62 626 376 63 627 minecraft:red_concrete
fill 376 62 628 376 67 629 minecraft:black_concrete
setblock 376 62 630 minecraft:red_concrete
fill 376 62 638 376 63 639 minecraft:red_concrete
fill 376 62 640 376 67 641 minecraft:black_concrete
fill 377 62 604 378 63 604 minecraft:red_concrete
fill 377 62 646 377 63 646 minecraft:red_concrete
fill 379 62 646 379 67 646 minecraft:black_concrete
fill 380 62 646 381 62 646 minecraft:red_concrete
fill 382 62 646 382 67 646 minecraft:black_concrete
setblock 386 62 604 minecraft:red_concrete
fill 387 62 604 388 67 604 minecraft:black_concrete
fill 388 62 646 389 63 646 minecraft:red_concrete
fill 389 62 604 390 63 604 minecraft:red_concrete
fill 390 62 646 391 67 646 minecraft:black_concrete
fill 395 62 604 396 67 604 minecraft:black_concrete
fill 397 62 604 398 62 604 minecraft:red_concrete
fill 399 62 604 399 63 604 minecraft:black_concrete
fill 400 62 646 401 62 646 minecraft:red_concrete
fill 402 62 646 403 67 646 minecraft:black_concrete
fill 407 62 604 408 67 604 minecraft:black_concrete
fill 409 62 604 410 63 604 minecraft:red_concrete
fill 409 62 646 409 63 646 minecraft:red_concrete
fill 410 62 646 411 67 646 minecraft:black_concrete
setblock 412 62 646 minecraft:red_concrete
fill 414 62 646 414 67 646 minecraft:black_concrete
fill 416 62 604 416 67 604 minecraft:black_concrete
fill 417 62 604 418 62 604 minecraft:red_concrete
fill 418 62 605 418 63 606 minecraft:black_concrete
fill 418 62 607 418 63 607 minecraft:red_concrete
fill 418 62 613 418 67 614 minecraft:black_concrete
fill 418 62 615 418 63 616 minecraft:red_concrete
setblock 418 62 624 minecraft:red_concrete
fill 418 62 625 418 67 626 minecraft:black_concrete
fill 418 62 627 418 63 628 minecraft:red_concrete
fill 418 62 633 418 67 634 minecraft:black_concrete
fill 418 62 635 418 62 636 minecraft:red_concrete
fill 418 62 637 418 67 637 minecraft:black_concrete
fill 418 62 645 418 67 645 minecraft:black_concrete
fill 376 63 614 376 63 615 minecraft:red_concrete
setblock 376 63 618 minecraft:red_concrete
fill 376 63 619 376 66 619 minecraft:black_concrete
fill 376 63 630 376 66 630 minecraft:black_concrete
setblock 376 63 635 minecraft:red_concrete
setblock 376 63 646 minecraft:red_concrete
fill 380 63 646 381 66 646 minecraft:black_concrete
setblock 381 63 604 minecraft:red_concrete
fill 386 63 604 386 66 604 minecraft:black_concrete
fill 397 63 604 397 66 604 minecraft:black_concrete
setblock 397 63 646 minecraft:red_concrete
setblock 398 63 604 minecraft:red_concrete
setblock 400 63 646 minecraft:red_concrete
fill 401 63 604 402 63 604 minecraft:red_concrete
fill 401 63 646 401 66 646 minecraft:black_concrete
setblock 408 63 646 minecraft:red_concrete
fill 412 63 646 412 66 646 minecraft:black_concrete
fill 417 63 604 418 65 604 minecraft:black_concrete
setblock 418 63 608 minecraft:red_concrete
setblock 418 63 619 minecraft:red_concrete
fill 418 63 624 418 66 624 minecraft:black_concrete
fill 418 63 635 418 66 635 minecraft:black_concrete
setblock 418 63 636 minecraft:red_concrete
fill 418 63 639 418 63 640 minecraft:red_concrete
fill 376 64 604 376 64 605 minecraft:red_concrete
fill 376 64 606 376 69 607 minecraft:black_concrete
fill 376 64 613 376 65 613 minecraft:red_concrete
fill 376 64 614 376 69 615 minecraft:black_concrete
setblock 376 64 616 minecraft:red_concrete
fill 376 64 618 376 69 618 minecraft:black_concrete
fill 376 64 624 376 65 625 minecraft:red_concrete
fill 376 64 626 376 69 627 minecraft:black_concrete
fill 376 64 635 376 69 635 minecraft:black_concrete
fill 376 64 636 376 64 637 minecraft:red_concrete
fill 376 64 638 376 69 639 minecraft:black_concrete
fill 376 64 644 376 65 645 minecraft:red_concrete
fill 376 64 646 377 69 646 minecraft:black_concrete
fill 377 64 604 378 69 604 minecraft:black_concrete
setblock 378 64 646 minecraft:red_concrete
fill 379 64 604 380 64 604 minecraft:red_concrete
fill 381 64 604 381 69 604 minecraft:black_concrete
fill 386 64 646 387 65 646 minecraft:red_concrete
fill 388 64 646 389 69 646 minecraft:black_concrete
fill 389 64 604 390 69 604 minecraft:black_concrete
fill 391 64 604 392 65 604 minecraft:red_concrete
fill 395 64 646 395 65 646 minecraft:red_concrete
fill 397 64 646 397 69 646 minecraft:black_concrete
fill 398 64 604 398 69 604 minecraft:black_concrete
fill 398 64 646 399 64 646 minecraft:red_concrete
fill 399 64 604 400 64 604 minecraft:red_concrete
fill 400 64 646 400 69 646 minecraft:black_concrete
fill 401 64 604 402 65 604 minecraft:black_concrete
fill 403 64 604 403 65 604 minecraft:red_concrete
fill 406 64 646 407 65 646 minecraft:red_concrete
fill 408 64 646 409 69 646 minecraft:black_concrete
fill 409 64 604 410 69 604 minecraft:black_concrete
fill 411 64 604 412 65 604 minecraft:red_concrete
fill 418 64 605 418 67 605 minecraft:black_concrete
setblock 418 64 606 minecraft:red_concrete
fill 418 64 607 418 69 608 minecraft:black_concrete
fill 418 64 609 418 65 610 minecraft:red_concrete
fill 418 64 615 418 66 616 minecraft:black_concrete
fill 418 64 617 418 64 618 minecraft:red_concrete
fill 418 64 619 418 69 619 minecraft:black_concrete
fill 418 64 627 418 69 628 minecraft:black_concrete
fill 418 64 629 418 65 630 minecraft:red_concrete
fill 418 64 636 418 69 636 minecraft:black_concrete
setblock 418 64 638 minecraft:red_concrete
fill 418 64 639 418 69 640 minecraft:black_concrete
fill 418 64 641 418 65 641 minecraft:red_concrete
fill 418 64 646 418 65 646 minecraft:red_concrete
setblock 376 65 604 minecraft:red_concrete
fill 376 65 605 376 68 605 minecraft:black_concrete
setblock 376 65 612 minecraft:red_concrete
fill 376 65 616 376 68 616 minecraft:black_concrete
fill 376 65 632 376 65 633 minecraft:red_concrete
setblock 376 65 636 minecraft:red_concrete
fill 376 65 637 376 68 637 minecraft:black_concrete
fill 378 65 646 378 68 646 minecraft:black_concrete
fill 379 65 604 379 68 604 minecraft:black_concrete
setblock 380 65 604 minecraft:red_concrete
fill 383 65 604 384 65 604 minecraft:red_concrete
setblock 383 65 646 minecraft:red_concrete
setblock 394 65 646 minecraft:red_concrete
fill 398 65 646 399 68 646 minecraft:black_concrete
fill 399 65 604 400 67 604 minecraft:black_concrete
setblock 404 65 604 minecraft:red_concrete
setblock 415 65 604 minecraft:red_concrete
setblock 415 65 646 minecraft:red_concrete
fill 418 65 606 418 67 606 minecraft:black_concrete
fill 418 65 617 418 68 617 minecraft:black_concrete
setblock 418 65 618 minecraft:red_concrete
fill 418 65 621 418 65 622 minecraft:red_concrete
fill 418 65 638 418 68 638 minecraft:black_concrete
setblock 418 65 642 minecraft:red_concrete
fill 376 66 604 376 71 604 minecraft:black_concrete
fill 376 66 610 376 67 611 minecraft:red_concrete
fill 376 66 612 376 71 613 minecraft:black_concrete
fill 376 66 622 376 66 623 minecraft:red_concrete
fill 376 66 624 376 71 625 minecraft:black_concrete
fill 376 66 631 376 67 631 minecraft:red_concrete
fill 376 66 632 376 71 633 minecraft:black_concrete
setblock 376 66 634 minecraft:red_concrete
fill 376 66 636 376 71 636 minecraft:black_concrete
fill 376 66 642 376 67 643 minecraft:red_concrete
fill 376 66 644 376 71 645 minecraft:black_concrete
fill 377 66 605 379 66 605 minecraft:polished_blackstone
fill 377 66 607 377 66 609 minecraft:polished_blackstone
fill 377 66 611 377 66 613 minecraft:polished_blackstone
fill 377 66 615 377 66 617 minecraft:polished_blackstone
fill 377 66 619 377 66 621 minecraft:polished_blackstone
fill 377 66 623 377 66 625 minecraft:polished_blackstone
fill 377 66 627 377 66 629 minecraft:polished_blackstone
fill 377 66 631 377 66 633 minecraft:polished_blackstone
fill 377 66 635 377 66 637 minecraft:polished_blackstone
fill 377 66 639 377 66 641 minecraft:polished_blackstone
fill 377 66 643 377 66 645 minecraft:polished_blackstone
setblock 379 66 607 minecraft:light[level=12]
setblock 379 66 615 minecraft:light[level=12]
setblock 379 66 623 minecraft:light[level=12]
setblock 379 66 631 minecraft:light[level=12]
setblock 379 66 639 minecraft:light[level=12]
fill 379 66 645 381 66 645 minecraft:polished_blackstone
fill 380 66 604 380 71 604 minecraft:black_concrete
fill 381 66 605 383 66 605 minecraft:polished_blackstone
setblock 382 66 604 minecraft:red_concrete
fill 383 66 604 384 71 604 minecraft:black_concrete
fill 383 66 645 385 66 645 minecraft:polished_blackstone
fill 383 66 646 383 71 646 minecraft:black_concrete
fill 384 66 646 385 66 646 minecraft:red_concrete
fill 385 66 604 385 67 604 minecraft:red_concrete
fill 385 66 605 387 66 605 minecraft:polished_blackstone
fill 386 66 646 387 71 646 minecraft:black_concrete
setblock 387 66 607 minecraft:light[level=12]
setblock 387 66 615 minecraft:light[level=12]
setblock 387 66 623 minecraft:light[level=12]
setblock 387 66 631 minecraft:light[level=12]
setblock 387 66 639 minecraft:light[level=12]
fill 387 66 645 389 66 645 minecraft:polished_blackstone
fill 389 66 605 391 66 605 minecraft:polished_blackstone
fill 391 66 604 392 71 604 minecraft:black_concrete
fill 391 66 616 392 67 616 minecraft:blackstone
fill 391 66 645 393 66 645 minecraft:polished_blackstone
fill 392 66 646 393 67 646 minecraft:red_concrete
fill 393 66 604 394 66 604 minecraft:red_concrete
fill 393 66 605 395 66 605 minecraft:polished_blackstone
fill 394 66 646 395 71 646 minecraft:black_concrete
setblock 395 66 607 minecraft:light[level=12]
setblock 395 66 615 minecraft:light[level=12]
setblock 395 66 623 minecraft:light[level=12]
setblock 395 66 631 minecraft:light[level=12]
setblock 395 66 639 minecraft:light[level=12]
fill 395 66 645 397 66 645 minecraft:polished_blackstone
setblock 396 66 646 minecraft:red_concrete
fill 397 66 605 399 66 605 minecraft:polished_blackstone
fill 399 66 645 401 66 645 minecraft:polished_blackstone
fill 401 66 604 401 69 604 minecraft:black_concrete
fill 401 66 605 403 66 605 minecraft:polished_blackstone
setblock 402 66 604 minecraft:red_concrete
fill 403 66 604 404 71 604 minecraft:black_concrete
setblock 403 66 607 minecraft:light[level=12]
setblock 403 66 615 minecraft:light[level=12]
setblock 403 66 623 minecraft:light[level=12]
setblock 403 66 631 minecraft:light[level=12]
setblock 403 66 639 minecraft:light[level=12]
fill 403 66 645 405 66 645 minecraft:polished_blackstone
fill 404 66 646 405 67 646 minecraft:red_concrete
fill 405 66 604 406 67 604 minecraft:red_concrete
fill 405 66 605 407 66 605 minecraft:polished_blackstone
fill 406 66 646 407 71 646 minecraft:black_concrete
fill 407 66 645 409 66 645 minecraft:polished_blackstone
fill 409 66 605 411 66 605 minecraft:polished_blackstone
fill 411 66 604 412 68 604 minecraft:black_concrete
setblock 411 66 607 minecraft:light[level=12]
setblock 411 66 615 minecraft:light[level=12]
setblock 411 66 623 minecraft:light[level=12]
setblock 411 66 631 minecraft:light[level=12]
setblock 411 66 639 minecraft:light[level=12]
fill 411 66 645 413 66 645 minecraft:polished_blackstone
fill 413 66 604 414 66 604 minecraft:red_concrete
fill 413 66 605 415 66 605 minecraft:polished_blackstone
fill 413 66 646 413 67 646 minecraft:red_concrete
fill 415 66 604 415 71 604 minecraft:black_concrete
fill 415 66 645 417 66 645 minecraft:polished_blackstone
fill 415 66 646 415 71 646 minecraft:black_concrete
fill 416 66 646 417 66 646 minecraft:red_concrete
fill 417 66 604 417 67 604 minecraft:red_concrete
fill 417 66 605 417 66 607 minecraft:polished_blackstone
fill 417 66 609 417 66 611 minecraft:polished_blackstone
fill 417 66 613 417 66 615 minecraft:polished_blackstone
fill 417 66 617 417 66 619 minecraft:polished_blackstone
fill 417 66 621 417 66 623 minecraft:polished_blackstone
fill 417 66 625 417 66 627 minecraft:polished_blackstone
fill 417 66 629 417 66 631 minecraft:polished_blackstone
fill 417 66 633 417 66 635 minecraft:polished_blackstone
fill 417 66 637 417 66 639 minecraft:polished_blackstone
fill 417 66 641 417 66 643 minecraft:polished_blackstone
setblock 418 66 604 minecraft:black_concrete
fill 418 66 609 418 71 610 minecraft:black_concrete
fill 418 66 611 418 67 612 minecraft:red_concrete
fill 418 66 618 418 68 618 minecraft:black_concrete
setblock 418 66 620 minecraft:red_concrete
fill 418 66 621 418 71 622 minecraft:black_concrete
fill 418 66 623 418 67 623 minecraft:red_concrete
fill 418 66 629 418 71 630 minecraft:black_concrete
fill 418 66 631 418 66 632 minecraft:red_concrete
fill 418 66 641 418 71 642 minecraft:black_concrete
fill 418 66 643 418 67 644 minecraft:red_concrete
fill 418 66 646 418 71 646 minecraft:black_concrete
setblock 376 67 619 minecraft:red_concrete
setblock 376 67 622 minecraft:red_concrete
fill 376 67 623 376 70 623 minecraft:black_concrete
setblock 376 67 630 minecraft:red_concrete
fill 376 67 634 376 70 634 minecraft:black_concrete
fill 380 67 646 381 67 646 minecraft:red_concrete
fill 382 67 604 382 70 604 minecraft:black_concrete
setblock 384 67 646 minecraft:red_concrete
fill 385 67 646 385 70 646 minecraft:black_concrete
setblock 386 67 604 minecraft:red_concrete
fill 393 67 604 393 70 604 minecraft:black_concrete
setblock 394 67 604 minecraft:red_concrete
fill 396 67 646 396 70 646 minecraft:black_concrete
setblock 397 67 604 minecraft:red_concrete
setblock 401 67 646 minecraft:red_concrete
fill 402 67 604 402 69 604 minecraft:black_concrete
setblock 412 67 646 minecraft:red_concrete
fill 413 67 604 413 70 604 minecraft:black_concrete
setblock 414 67 604 minecraft:red_concrete
fill 416 67 646 417 70 646 minecraft:black_concrete
setblock 418 67 604 minecraft:red_concrete
setblock 418 67 615 minecraft:red_concrete
fill 418 67 616 418 69 616 minecraft:black_concrete
fill 418 67 620 418 70 620 minecraft:black_concrete
setblock 418 67 624 minecraft:red_concrete
fill 418 67 631 418 70 631 minecraft:black_concrete
setblock 418 67 632 minecraft:red_concrete
setblock 418 67 635 minecraft:red_concrete
fill 376 68 608 376 69 609 minecraft:red_concrete
fill 376 68 610 376 73 611 minecraft:black_concrete
fill 376 68 617 376 69 617 minecraft:red_concrete
fill 376 68 619 376 73 619 minecraft:black_concrete
fill 376 68 620 376 68 621 minecraft:red_concrete
fill 376 68 622 376 73 622 minecraft:black_concrete
fill 376 68 628 376 69 629 minecraft:red_concrete
fill 376 68 630 376 73 631 minecraft:black_concrete
fill 376 68 640 376 68 641 minecraft:red_concrete
fill 376 68 642 376 73 643 minecraft:black_concrete
fill 379 68 646 379 69 646 minecraft:red_concrete
fill 380 68 646 381 73 646 minecraft:black_concrete
setblock 382 68 646 minecraft:red_concrete
fill 384 68 646 384 73 646 minecraft:black_concrete
fill 385 68 604 386 73 604 minecraft:black_concrete
fill 387 68 604 388 69 604 minecraft:red_concrete
fill 390 68 646 391 69 646 minecraft:red_concrete
fill 392 68 646 393 73 646 minecraft:black_concrete
fill 394 68 604 394 73 604 minecraft:black_concrete
fill 395 68 604 396 68 604 minecraft:red_concrete
fill 397 68 604 397 73 604 minecraft:black_concrete
fill 399 68 604 399 69 604 minecraft:red_concrete
setblock 400 68 604 minecraft:black_concrete
fill 401 68 646 401 73 646 minecraft:black_concrete
fill 402 68 646 403 68 646 minecraft:red_concrete
fill 404 68 646 405 73 646 minecraft:black_concrete
fill 405 68 604 406 73 604 minecraft:black_concrete
fill 407 68 604 408 69 604 minecraft:red_concrete
fill 410 68 646 411 69 646 minecraft:red_concrete
fill 412 68 646 413 73 646 minecraft:black_concrete
fill 414 68 604 414 70 604 minecraft:black_concrete
setblock 414 68 646 minecraft:red_concrete
setblock 416 68 604 minecraft:red_concrete
fill 417 68 604 418 73 604 minecraft:black_concrete
fill 418 68 605 418 69 606 minecraft:red_concrete
fill 418 68 611 418 73 612 minecraft:black_concrete
fill 418 68 613 418 68 614 minecraft:red_concrete
fill 418 68 615 418 69 615 minecraft:black_concrete
fill 418 68 623 418 73 624 minecraft:black_concrete
fill 418 68 625 418 69 626 minecraft:red_concrete
fill 418 68 632 418 73 632 minecraft:black_concrete
fill 418 68 633 418 68 634 minecraft:red_concrete
fill 418 68 635 418 73 635 minecraft:black_concrete
fill 418 68 637 418 69 637 minecraft:red_concrete
fill 418 68 643 418 73 644 minecraft:black_concrete
fill 418 68 645 418 69 645 minecraft:red_concrete
setblock 376 69 605 minecraft:red_concrete
setblock 376 69 616 minecraft:red_concrete
fill 376 69 620 376 72 621 minecraft:black_concrete
setblock 376 69 637 minecraft:red_concrete
setblock 376 69 640 minecraft:red_concrete
fill 376 69 641 376 72 641 minecraft:black_concrete
setblock 378 69 646 minecraft:red_concrete
setblock 379 69 604 minecraft:red_concrete
fill 382 69 646 382 72 646 minecraft:black_concrete
fill 395 69 604 396 72 604 minecraft:black_concrete
fill 398 69 646 399 69 646 minecraft:red_concrete
setblock 400 69 604 minecraft:red_concrete
setblock 402 69 646 minecraft:red_concrete
fill 403 69 646 403 72 646 minecraft:black_concrete
setblock 411 69 604 minecraft:red_concrete
fill 412 69 604 412 71 604 minecraft:black_concrete
fill 414 69 646 414 72 646 minecraft:black_concrete
fill 416 69 604 416 72 604 minecraft:black_concrete
fill 418 69 613 418 72 613 minecraft:black_concrete
setblock 418 69 614 minecraft:red_concrete
fill 418 69 617 418 69 618 minecraft:red_concrete
fill 418 69 633 418 72 634 minecraft:black_concrete
setblock 418 69 638 minecraft:red_concrete
fill 376 70 605 376 75 605 minecraft:black_concrete
fill 376 70 606 376 70 607 minecraft:red_concrete
fill 376 70 608 376 75 609 minecraft:black_concrete
fill 376 70 614 376 71 615 minecraft:red_concrete
fill 376 70 616 376 75 617 minecraft:black_concrete
setblock 376 70 618 minecraft:red_concrete
fill 376 70 626 376 71 627 minecraft:red_concrete
fill 376 70 628 376 75 629 minecraft:black_concrete
fill 376 70 635 376 71 635 minecraft:red_concrete
fill 376 70 637 376 75 637 minecraft:black_concrete
fill 376 70 638 376 70 639 minecraft:red_concrete
fill 376 70 640 376 75 640 minecraft:black_concrete
fill 376 70 646 377 71 646 minecraft:red_concrete
fill 377 70 604 378 70 604 minecraft:red_concrete
fill 378 70 646 379 75 646 minecraft:black_concrete
fill 379 70 604 379 75 604 minecraft:black_concrete
fill 381 70 604 381 71 604 minecraft:red_concrete
fill 382 70 631 382 71 632 minecraft:magma_block
fill 387 70 604 388 75 604 minecraft:black_concrete
fill 388 70 646 389 70 646 minecraft:red_concrete
fill 389 70 604 390 71 604 minecraft:red_concrete
fill 390 70 646 391 75 646 minecraft:black_concrete
fill 397 70 646 397 71 646 minecraft:red_concrete
setblock 398 70 604 minecraft:red_concrete
fill 398 70 646 399 75 646 minecraft:black_concrete
fill 399 70 604 400 75 604 minecraft:black_concrete
fill 399 70 609 399 71 609 minecraft:blackstone
setblock 400 70 646 minecraft:red_concrete
fill 401 70 604 402 71 604 minecraft:red_concrete
fill 402 70 646 402 75 646 minecraft:black_concrete
fill 407 70 604 408 75 604 minecraft:black_concrete
fill 408 70 646 409 71 646 minecraft:red_concrete
fill 409 70 604 410 70 604 minecraft:red_concrete
fill 410 70 646 411 75 646 minecraft:black_concrete
fill 411 70 604 411 71 604 minecraft:black_concrete
fill 418 70 605 418 75 606 minecraft:black_concrete
fill 418 70 607 418 71 608 minecraft:red_concrete
fill 418 70 614 418 75 614 minecraft:black_concrete
fill 418 70 615 418 70 616 minecraft:red_concrete
fill 418 70 617 418 71 618 minecraft:black_concrete
fill 418 70 619 418 71 619 minecraft:red_concrete
fill 418 70 625 418 75 626 minecraft:black_concrete
fill 418 70 627 418 71 628 minecraft:red_concrete
setblock 418 70 636 minecraft:red_concrete
fill 418 70 637 418 75 638 minecraft:black_concrete
fill 418 70 639 418 71 640 minecraft:red_concrete
fill 418 70 645 418 75 645 minecraft:black_concrete
setblock 376 71 606 minecraft:red_concrete
fill 376 71 607 376 74 607 minecraft:black_concrete
fill 376 71 618 376 74 618 minecraft:black_concrete
setblock 376 71 623 minecraft:red_concrete
setblock 376 71 634 minecraft:red_concrete
fill 376 71 638 376 74 639 minecraft:black_concrete
fill 377 71 604 378 74 604 minecraft:black_concrete
setblock 382 71 604 minecraft:red_concrete
setblock 385 71 646 minecraft:red_concrete
setblock 388 71 646 minecraft:red_concrete
fill 389 71 646 389 74 646 minecraft:black_concrete
setblock 393 71 604 minecraft:red_concrete
setblock 396 71 646 minecraft:red_concrete
fill 398 71 604 398 74 604 minecraft:black_concrete
fill 400 71 646 400 74 646 minecraft:black_concrete
fill 409 71 604 409 74 604 minecraft:black_concrete
setblock 410 71 604 minecraft:red_concrete
fill 413 71 604 414 71 604 minecraft:red_concrete
fill 416 71 646 417 71 646 minecraft:red_concrete
fill 418 71 615 418 73 616 minecraft:black_concrete
setblock 418 71 620 minecraft:red_concrete
setblock 418 71 631 minecraft:red_concrete
fill 418 71 636 418 74 636 minecraft:black_concrete
setblock 376 72 604 minecraft:red_concrete
fill 376 72 606 376 77 606 minecraft:black_concrete
fill 376 72 612 376 73 613 minecraft:red_concrete
fill 376 72 614 376 77 615 minecraft:black_concrete
fill 376 72 623 376 77 623 minecraft:black_concrete
fill 376 72 624 376 72 625 minecraft:red_concrete
fill 376 72 626 376 77 627 minecraft:black_concrete
fill 376 72 632 376 73 633 minecraft:red_concrete
fill 376 72 634 376 77 635 minecraft:black_concrete
setblock 376 72 636 minecraft:red_concrete
fill 376 72 644 376 73 645 minecraft:red_concrete
fill 376 72 646 377 77 646 minecraft:black_concrete
fill 377 72 605 379 72 605 minecraft:polished_blackstone
fill 377 72 607 377 72 609 minecraft:polished_blackstone
fill 377 72 611 377 72 613 minecraft:polished_blackstone
fill 377 72 615 377 72 617 minecraft:polished_blackstone
fill 377 72 619 377 72 621 minecraft:polished_blackstone
fill 377 72 623 377 72 625 minecraft:polished_blackstone
fill 377 72 627 377 72 629 minecraft:polished_blackstone
fill 377 72 631 377 72 633 minecraft:polished_blackstone
fill 377 72 635 377 72 637 minecraft:polished_blackstone
fill 377 72 639 377 72 641 minecraft:polished_blackstone
fill 377 72 643 377 72 645 minecraft:polished_blackstone
fill 379 72 645 381 72 645 minecraft:polished_blackstone
setblock 380 72 604 minecraft:red_concrete
fill 381 72 604 382 77 604 minecraft:black_concrete
fill 381 72 605 383 72 605 minecraft:polished_blackstone
fill 383 72 604 384 73 604 minecraft:red_concrete
fill 383 72 645 385 72 645 minecraft:polished_blackstone
fill 383 72 646 383 73 646 minecraft:red_concrete
fill 385 72 605 387 72 605 minecraft:polished_blackstone
fill 385 72 646 385 77 646 minecraft:black_concrete
fill 386 72 646 387 72 646 minecraft:red_concrete
fill 387 72 645 389 72 645 minecraft:polished_blackstone
fill 388 72 646 388 77 646 minecraft:black_concrete
fill 389 72 604 390 77 604 minecraft:black_concrete
fill 389 72 605 391 72 605 minecraft:polished_blackstone
fill 391 72 604 392 72 604 minecraft:red_concrete
fill 391 72 645 393 72 645 minecraft:polished_blackstone
fill 393 72 604 393 77 604 minecraft:black_concrete
fill 393 72 605 395 72 605 minecraft:polished_blackstone
fill 394 72 646 395 73 646 minecraft:red_concrete
fill 395 72 645 397 72 645 minecraft:polished_blackstone
fill 396 72 646 397 77 646 minecraft:black_concrete
fill 397 72 605 399 72 605 minecraft:polished_blackstone
fill 399 72 645 401 72 645 minecraft:polished_blackstone
fill 401 72 604 402 77 604 minecraft:black_concrete
fill 401 72 605 403 72 605 minecraft:polished_blackstone
fill 403 72 604 404 73 604 minecraft:red_concrete
fill 403 72 645 405 72 645 minecraft:polished_blackstone
fill 405 72 605 407 72 605 minecraft:polished_blackstone
fill 406 72 646 407 72 646 minecraft:red_concrete
fill 407 72 645 409 72 645 minecraft:polished_blackstone
fill 408 72 646 409 77 646 minecraft:black_concrete
fill 409 72 605 411 72 605 minecraft:polished_blackstone
fill 410 72 604 410 77 604 minecraft:black_concrete
fill 411 72 604 412 72 604 minecraft:red_concrete
fill 411 72 645 413 72 645 minecraft:polished_blackstone
fill 413 72 604 414 73 604 minecraft:black_concrete
fill 413 72 605 415 72 605 minecraft:polished_blackstone
fill 415 72 604 415 73 604 minecraft:red_concrete
fill 415 72 645 417 72 645 minecraft:polished_blackstone
fill 415 72 646 415 73 646 minecraft:red_concrete
fill 416 72 646 417 77 646 minecraft:black_concrete
fill 417 72 605 417 72 607 minecraft:polished_blackstone
fill 417 72 609 417 72 611 minecraft:polished_blackstone
fill 417 72 613 417 72 615 minecraft:polished_blackstone
fill 417 72 617 417 72 619 minecraft:polished_blackstone
fill 417 72 621 417 72 623 minecraft:polished_blackstone
fill 417 72 625 417 72 627 minecraft:polished_blackstone
fill 417 72 629 417 72 631 minecraft:polished_blackstone
fill 417 72 633 417 72 635 minecraft:polished_blackstone
fill 417 72 637 417 72 639 minecraft:polished_blackstone
fill 417 72 641 417 72 643 minecraft:polished_blackstone
fill 418 72 607 418 77 608 minecraft:black_concrete
fill 418 72 609 418 73 610 minecraft:red_concrete
fill 418 72 617 418 75 617 minecraft:black_concrete
setblock 418 72 618 minecraft:red_concrete
fill 418 72 619 418 77 620 minecraft:black_concrete
fill 418 72 621 418 73 622 minecraft:red_concrete
fill 418 72 627 418 74 628 minecraft:black_concrete
fill 418 72 629 418 72 630 minecraft:red_concrete
fill 418 72 631 418 77 631 minecraft:black_concrete
fill 418 72 639 418 77 640 minecraft:black_concrete
fill 418 72 641 418 73 642 minecraft:red_concrete
setblock 418 72 646 minecraft:red_concrete
fill 376 73 604 376 76 604 minecraft:black_concrete
fill 376 73 620 376 73 621 minecraft:red_concrete
setblock 376 73 624 minecraft:red_concrete
fill 376 73 625 376 76 625 minecraft:black_concrete
fill 376 73 636 376 76 636 minecraft:black_concrete
setblock 376 73 641 minecraft:red_concrete
fill 380 73 604 380 76 604 minecraft:black_concrete
setblock 382 73 646 minecraft:red_concrete
fill 386 73 646 387 76 646 minecraft:black_concrete
fill 391 73 604 391 76 604 minecraft:black_concrete
setblock 392 73 604 minecraft:red_concrete
fill 395 73 604 396 73 604 minecraft:red_concrete
setblock 403 73 646 minecraft:red_concrete
setblock 406 73 646 minecraft:red_concrete
fill 407 73 646 407 76 646 minecraft:black_concrete
fill 411 73 604 412 75 604 minecraft:black_concrete
setblock 414 73 646 minecraft:red_concrete
setblock 416 73 604 minecraft:red_concrete
setblock 418 73 613 minecraft:red_concrete
fill 418 73 618 418 75 618 minecraft:black_concrete
fill 418 73 629 418 76 629 minecraft:black_concrete
setblock 418 73 630 minecraft:red_concrete
fill 418 73 633 418 73 634 minecraft:red_concrete
fill 418 73 646 418 76 646 minecraft:black_concrete
fill 376 74 610 376 74 611 minecraft:red_concrete
fill 376 74 612 376 79 613 minecraft:black_concrete
fill 376 74 619 376 75 619 minecraft:red_concrete
fill 376 74 620 376 79 621 minecraft:black_concrete
setblock 376 74 622 minecraft:red_concrete
fill 376 74 624 376 79 624 minecraft:black_concrete
fill 376 74 630 376 75 631 minecraft:red_concrete
fill 376 74 632 376 79 633 minecraft:black_concrete
fill 376 74 641 376 79 641 minecraft:black_concrete
fill 376 74 642 376 74 643 minecraft:red_concrete
fill 376 74 644 376 79 645 minecraft:black_concrete
setblock 379 74 607 minecraft:light[level=12]
setblock 379 74 615 minecraft:light[level=12]
setblock 379 74 623 minecraft:light[level=12]
setblock 379 74 631 minecraft:light[level=12]
setblock 379 74 639 minecraft:light[level=12]
fill 380 74 646 381 75 646 minecraft:red_concrete
fill 382 74 646 383 79 646 minecraft:black_concrete
fill 383 74 604 384 79 604 minecraft:black_concrete
setblock 384 74 646 minecraft:red_concrete
fill 385 74 604 386 75 604 minecraft:red_concrete
setblock 387 74 607 minecraft:light[level=12]
setblock 387 74 615 minecraft:light[level=12]
setblock 387 74 623 minecraft:light[level=12]
setblock 387 74 631 minecraft:light[level=12]
setblock 387 74 639 minecraft:light[level=12]
fill 392 74 604 392 79 604 minecraft:black_concrete
fill 392 74 646 393 75 646 minecraft:red_concrete
setblock 394 74 604 minecraft:red_concrete
fill 394 74 646 395 79 646 minecraft:black_concrete
fill 395 74 604 396 79 604 minecraft:black_concrete
setblock 395 74 607 minecraft:light[level=12]
setblock 395 74 615 minecraft:light[level=12]
setblock 395 74 623 minecraft:light[level=12]
setblock 395 74 631 minecraft:light[level=12]
setblock 395 74 639 minecraft:light[level=12]
fill 397 74 604 397 75 604 minecraft:red_concrete
fill 401 74 646 401 75 646 minecraft:red_concrete
fill 403 74 604 404 79 604 minecraft:black_concrete
setblock 403 74 607 minecraft:light[level=12]
setblock 403 74 615 minecraft:light[level=12]
setblock 403 74 623 minecraft:light[level=12]
setblock 403 74 631 minecraft:light[level=12]
setblock 403 74 639 minecraft:light[level=12]
fill 403 74 646 403 79 646 minecraft:black_concrete
fill 404 74 646 405 74 646 minecraft:red_concrete
fill 405 74 604 406 74 604 minecraft:red_concrete
fill 406 74 646 406 79 646 minecraft:black_concrete
setblock 411 74 607 minecraft:light[level=12]
setblock 411 74 615 minecraft:light[level=12]
setblock 411 74 623 minecraft:light[level=12]
setblock 411 74 631 minecraft:light[level=12]
setblock 411 74 639 minecraft:light[level=12]
fill 412 74 646 413 75 646 minecraft:red_concrete
fill 413 74 604 413 77 604 minecraft:black_concrete
setblock 414 74 604 minecraft:red_concrete
fill 414 74 646 415 79 646 minecraft:black_concrete
fill 415 74 604 416 79 604 minecraft:black_concrete
fill 417 74 604 418 75 604 minecraft:red_concrete
fill 418 74 609 418 76 610 minecraft:black_concrete
fill 418 74 611 418 74 612 minecraft:red_concrete
fill 418 74 613 418 79 613 minecraft:black_concrete
fill 418 74 615 418 75 615 minecraft:red_concrete
setblock 418 74 616 minecraft:black_concrete
fill 418 74 621 418 79 622 minecraft:black_concrete
fill 418 74 623 418 75 624 minecraft:red_concrete
fill 418 74 630 418 76 630 minecraft:black_concrete
setblock 418 74 632 minecraft:red_concrete
fill 418 74 633 418 79 634 minecraft:black_concrete
fill 418 74 635 418 75 635 minecraft:red_concrete
fill 418 74 641 418 79 642 minecraft:black_concrete
fill 418 74 643 418 74 644 minecraft:red_concrete
setblock 376 75 607 minecraft:red_concrete
setblock 376 75 610 minecraft:red_concrete
fill 376 75 611 376 78 611 minecraft:black_concrete
setblock 376 75 618 minecraft:red_concrete
fill 376 75 622 376 78 622 minecraft:black_concrete
fill 376 75 638 376 75 639 minecraft:red_concrete
setblock 376 75 642 minecraft:red_concrete
fill 376 75 643 376 78 643 minecraft:black_concrete
fill 377 75 604 378 75 604 minecraft:red_concrete
fill 384 75 646 384 78 646 minecraft:black_concrete
setblock 389 75 646 minecraft:red_concrete
fill 392 75 633 392 76 635 minecraft:red_concrete
fill 393 75 634 393 76 635 minecraft:red_concrete
fill 394 75 604 394 78 604 minecraft:black_concrete
setblock 398 75 604 minecraft:red_concrete
setblock 400 75 646 minecraft:red_concrete
fill 404 75 646 405 78 646 minecraft:black_concrete
fill 405 75 604 405 78 604 minecraft:black_concrete
fill 405 75 630 405 76 630 minecraft:red_concrete
setblock 406 75 604 minecraft:red_concrete
setblock 409 75 604 minecraft:red_concrete
fill 414 75 604 414 77 604 minecraft:black_concrete
fill 418 75 611 418 78 611 minecraft:black_concrete
setblock 418 75 612 minecraft:red_concrete
setblock 418 75 616 minecraft:red_concrete
setblock 418 75 627 minecraft:red_concrete
fill 418 75 628 418 77 628 minecraft:black_concrete
fill 418 75 632 418 78 632 minecraft:black_concrete
setblock 418 75 636 minecraft:red_concrete
fill 418 75 643 418 78 643 minecraft:black_concrete
setblock 418 75 644 minecraft:red_concrete
fill 376 76 605 376 77 605 minecraft:red_concrete
fill 376 76 607 376 81 607 minecraft:black_concrete
fill 376 76 608 376 76 609 minecraft:red_concrete
fill 376 76 610 376 81 610 minecraft:black_concrete
fill 376 76 616 376 77 617 minecraft:red_concrete
fill 376 76 618 376 81 619 minecraft:black_concrete
fill 376 76 628 376 76 629 minecraft:red_concrete
fill 376 76 630 376 81 631 minecraft:black_concrete
fill 376 76 637 376 77 637 minecraft:red_concrete
fill 376 76 638 376 81 639 minecraft:black_concrete
setblock 376 76 640 minecraft:red_concrete
fill 376 76 642 376 81 642 minecraft:black_concrete
fill 377 76 604 378 81 604 minecraft:black_concrete
fill 378 76 646 379 77 646 minecraft:red_concrete
fill 379 76 604 379 77 604 minecraft:red_concrete
fill 380 76 646 381 81 646 minecraft:black_concrete
fill 385 76 604 386 81 604 minecraft:black_concrete
fill 387 76 604 388 76 604 minecraft:red_concrete
fill 389 76 646 389 81 646 minecraft:black_concrete
fill 390 76 646 391 76 646 minecraft:red_concrete
fill 392 76 631 393 77 632 minecraft:magma_block
fill 392 76 646 393 81 646 minecraft:black_concrete
fill 396 76 642 397 77 643 minecraft:magma_block
fill 397 76 604 398 81 604 minecraft:black_concrete
fill 398 76 646 399 77 646 minecraft:red_concrete
fill 399 76 604 400 77 604 minecraft:red_concrete
fill 400 76 646 401 81 646 minecraft:black_concrete
setblock 402 76 646 minecraft:red_concrete
fill 406 76 604 406 81 604 minecraft:black_concrete
fill 407 76 604 408 76 604 minecraft:red_concrete
fill 409 76 604 409 81 604 minecraft:black_concrete
fill 410 76 646 411 77 646 minecraft:red_concrete
fill 411 76 604 411 77 604 minecraft:red_concrete
setblock 412 76 604 minecraft:black_concrete
fill 412 76 646 413 81 646 minecraft:black_concrete
fill 417 76 604 418 81 604 minecraft:black_concrete
fill 418 76 605 418 77 606 minecraft:red_concrete
fill 418 76 612 418 78 612 minecraft:black_concrete
setblock 418 76 614 minecraft:red_concrete
fill 418 76 615 418 81 616 minecraft:black_concrete
fill 418 76 617 418 77 618 minecraft:red_concrete
fill 418 76 623 418 81 624 minecraft:black_concrete
fill 418 76 625 418 76 626 minecraft:red_concrete
fill 418 76 627 418 77 627 minecraft:black_concrete
fill 418 76 635 418 81 636 minecraft:black_concrete
fill 418 76 637 418 77 638 minecraft:red_concrete
fill 418 76 644 418 81 644 minecraft:black_concrete
setblock 418 76 645 minecraft:red_concrete
setblock 376 77 604 minecraft:red_concrete
fill 376 77 608 376 80 609 minecraft:black_concrete
setblock 376 77 625 minecraft:red_concrete
setblock 376 77 628 minecraft:red_concrete
fill 376 77 629 376 80 629 minecraft:black_concrete
setblock 376 77 636 minecraft:red_concrete
fill 376 77 640 376 80 640 minecraft:black_concrete
setblock 380 77 604 minecraft:red_concrete
fill 386 77 646 387 77 646 minecraft:red_concrete
fill 387 77 604 387 80 604 minecraft:black_concrete
setblock 388 77 604 minecraft:red_concrete
setblock 390 77 646 minecraft:red_concrete
setblock 391 77 604 minecraft:red_concrete
fill 391 77 646 391 80 646 minecraft:black_concrete
fill 402 77 646 402 80 646 minecraft:black_concrete
fill 407 77 604 408 80 604 minecraft:black_concrete
setblock 407 77 646 minecraft:red_concrete
setblock 412 77 604 minecraft:red_concrete
setblock 418 77 609 minecraft:red_concrete
fill 418 77 610 418 79 610 minecraft:black_concrete
fill 418 77 614 418 80 614 minecraft:black_concrete
fill 418 77 625 418 80 625 minecraft:black_concrete
setblock 418 77 626 minecraft:red_concrete
fill 418 77 629 418 77 630 minecraft:red_concrete
fill 418 77 645 418 80 645 minecraft:black_concrete
setblock 418 77 646 minecraft:red_concrete
fill 376 78 604 376 83 605 minecraft:black_concrete
setblock 376 78 606 minecraft:red_concrete
fill 376 78 614 376 79 615 minecraft:red_concrete
fill 376 78 616 376 83 617 minecraft:black_concrete
fill 376 78 623 376 79 623 minecraft:red_concrete
fill 376 78 625 376 83 625 minecraft:black_concrete
fill 376 78 626 376 78 627 minecraft:red_concrete
fill 376 78 628 376 83 628 minecraft:black_concrete
fill 376 78 634 376 79 635 minecraft:red_concrete
fill 376 78 636 376 83 637 minecraft:black_concrete
fill 376 78 646 377 78 646 minecraft:red_concrete
fill 377 78 605 379 78 605 minecraft:polished_blackstone
fill 377 78 607 377 78 609 minecraft:polished_blackstone
fill 377 78 611 377 78 613 minecraft:polished_blackstone
fill 377 78 615 377 78 617 minecraft:polished_blackstone
fill 377 78 619 377 78 621 minecraft:polished_blackstone
fill 377 78 623 377 78 625 minecraft:polished_blackstone
fill 377 78 627 377 78 629 minecraft:polished_blackstone
fill 377 78 631 377 78 633 minecraft:polished_blackstone
fill 377 78 635 377 78 637 minecraft:polished_blackstone
fill 377 78 639 377 78 641 minecraft:polished_blackstone
fill 377 78 643 377 78 645 minecraft:polished_blackstone
fill 378 78 646 379 83 646 minecraft:black_concrete
fill 379 78 604 380 83 604 minecraft:black_concrete
fill 379 78 645 381 78 645 minecraft:polished_blackstone
fill 381 78 604 382 79 604 minecraft:red_concrete
fill 381 78 605 383 78 605 minecraft:polished_blackstone
fill 383 78 645 385 78 645 minecraft:polished_blackstone
fill 385 78 605 387 78 605 minecraft:polished_blackstone
fill 385 78 634 386 79 635 minecraft:blackstone
fill 385 78 646 385 79 646 minecraft:red_concrete
fill 386 78 646 387 83 646 minecraft:black_concrete
fill 387 78 645 389 78 645 minecraft:polished_blackstone
fill 388 78 604 388 83 604 minecraft:black_concrete
setblock 388 78 646 minecraft:red_concrete
fill 389 78 604 390 78 604 minecraft:red_concrete
fill 389 78 605 391 78 605 minecraft:polished_blackstone
fill 390 78 646 390 83 646 minecraft:black_concrete
fill 391 78 604 391 83 604 minecraft:black_concrete
fill 391 78 645 393 78 645 minecraft:polished_blackstone
fill 393 78 604 393 79 604 minecraft:red_concrete
fill 393 78 605 395 78 605 minecraft:polished_blackstone
fill 395 78 645 397 78 645 minecraft:polished_blackstone
fill 396 78 646 397 79 646 minecraft:red_concrete
fill 397 78 605 399 78 605 minecraft:polished_blackstone
fill 398 78 646 399 83 646 minecraft:black_concrete
fill 399 78 604 400 83 604 minecraft:black_concrete
fill 399 78 645 401 78 645 minecraft:polished_blackstone
fill 401 78 604 402 79 604 minecraft:red_concrete
fill 401 78 605 403 78 605 minecraft:polished_blackstone
fill 403 78 645 405 78 645 minecraft:polished_blackstone
fill 405 78 605 407 78 605 minecraft:polished_blackstone
fill 407 78 645 409 78 645 minecraft:polished_blackstone
fill 407 78 646 407 83 646 minecraft:black_concrete
fill 408 78 646 409 78 646 minecraft:red_concrete
fill 409 78 605 411 78 605 minecraft:polished_blackstone
setblock 410 78 604 minecraft:red_concrete
fill 410 78 646 411 83 646 minecraft:black_concrete
fill 411 78 604 412 83 604 minecraft:black_concrete
fill 411 78 645 413 78 645 minecraft:polished_blackstone
fill 413 78 604 414 79 604 minecraft:red_concrete
fill 413 78 605 415 78 605 minecraft:polished_blackstone
fill 415 78 645 417 78 645 minecraft:polished_blackstone
fill 416 78 646 417 79 646 minecraft:red_concrete
fill 417 78 605 417 78 607 minecraft:polished_blackstone
fill 417 78 609 417 78 611 minecraft:polished_blackstone
fill 417 78 613 417 78 615 minecraft:polished_blackstone
fill 417 78 617 417 78 619 minecraft:polished_blackstone
fill 417 78 621 417 78 623 minecraft:polished_blackstone
fill 417 78 625 417 78 627 minecraft:polished_blackstone
fill 417 78 629 417 78 631 minecraft:polished_blackstone
fill 417 78 633 417 78 635 minecraft:polished_blackstone
fill 417 78 637 417 78 639 minecraft:polished_blackstone
fill 417 78 641 417 78 643 minecraft:polished_blackstone
fill 418 78 605 418 83 606 minecraft:black_concrete
fill 418 78 607 418 78 608 minecraft:red_concrete
fill 418 78 609 418 79 609 minecraft:black_concrete
fill 418 78 617 418 83 618 minecraft:black_concrete
fill 418 78 619 418 79 620 minecraft:red_concrete
fill 418 78 626 418 83 626 minecraft:black_concrete
fill 418 78 627 418 78 628 minecraft:red_concrete
fill 418 78 629 418 79 630 minecraft:black_concrete
fill 418 78 631 418 79 631 minecraft:red_concrete
fill 418 78 637 418 83 638 minecraft:black_concrete
fill 418 78 639 418 79 640 minecraft:red_concrete
fill 418 78 646 418 83 646 minecraft:black_concrete
fill 376 79 606 376 82 606 minecraft:black_concrete
setblock 376 79 611 minecraft:red_concrete
setblock 376 79 622 minecraft:red_concrete
fill 376 79 626 376 82 627 minecraft:black_concrete
setblock 376 79 643 minecraft:red_concrete
setblock 376 79 646 minecraft:red_concrete
fill 377 79 646 377 82 646 minecraft:black_concrete
setblock 384 79 646 minecraft:red_concrete
fill 388 79 646 388 82 646 minecraft:black_concrete
fill 389 79 604 390 82 604 minecraft:black_concrete
setblock 394 79 604 minecraft:red_concrete
fill 404 79 646 405 79 646 minecraft:red_concrete
setblock 405 79 604 minecraft:red_concrete
setblock 408 79 646 minecraft:red_concrete
fill 409 79 646 409 82 646 minecraft:black_concrete
fill 410 79 604 410 82 604 minecraft:black_concrete
fill 418 79 607 418 82 607 minecraft:black_concrete
setblock 418 79 608 minecraft:red_concrete
fill 418 79 611 418 79 612 minecraft:red_concrete
fill 418 79 627 418 81 628 minecraft:black_concrete
setblock 418 79 632 minecraft:red_concrete
setblock 418 79 643 minecraft:red_concrete
fill 376 80 611 376 85 611 minecraft:black_concrete
fill 376 80 612 376 80 613 minecraft:red_concrete
fill 376 80 614 376 85 615 minecraft:black_concrete
fill 376 80 620 376 81 621 minecraft:red_concrete
fill 376 80 622 376 85 623 minecraft:black_concrete
setblock 376 80 624 minecraft:red_concrete
fill 376 80 632 376 81 633 minecraft:red_concrete
fill 376 80 634 376 85 635 minecraft:black_concrete
fill 376 80 641 376 81 641 minecraft:red_concrete
fill 376 80 643 376 85 643 minecraft:black_concrete
fill 376 80 644 376 80 645 minecraft:red_concrete
fill 376 80 646 376 85 646 minecraft:black_concrete
fill 381 80 604 382 85 604 minecraft:black_concrete
fill 382 80 646 383 81 646 minecraft:red_concrete
fill 383 80 604 384 81 604 minecraft:red_concrete
fill 384 80 646 385 85 646 minecraft:black_concrete
setblock 392 80 604 minecraft:red_concrete
fill 393 80 604 394 85 604 minecraft:black_concrete
fill 394 80 646 395 80 646 minecraft:red_concrete
fill 395 80 604 396 81 604 minecraft:red_concrete
fill 396 80 646 397 85 646 minecraft:black_concrete
fill 401 80 604 402 85 604 minecraft:black_concrete
fill 403 80 604 404 80 604 minecraft:red_concrete
fill 403 80 646 403 81 646 minecraft:red_concrete
fill 404 80 646 405 85 646 minecraft:black_concrete
fill 405 80 604 405 85 604 minecraft:black_concrete
setblock 406 80 646 minecraft:red_concrete
fill 408 80 646 408 85 646 minecraft:black_concrete
fill 413 80 604 414 85 604 minecraft:black_concrete
fill 414 80 646 415 81 646 minecraft:red_concrete
fill 415 80 604 416 81 604 minecraft:red_concrete
fill 416 80 646 417 85 646 minecraft:black_concrete
fill 418 80 608 418 85 608 minecraft:black_concrete
fill 418 80 609 418 80 610 minecraft:red_concrete
fill 418 80 611 418 81 612 minecraft:black_concrete
fill 418 80 613 418 81 613 minecraft:red_concrete
fill 418 80 619 418 85 620 minecraft:black_concrete
fill 418 80 621 418 81 622 minecraft:red_concrete
fill 418 80 629 418 83 629 minecraft:black_concrete
setblock 418 80 630 minecraft:red_concrete
fill 418 80 631 418 85 632 minecraft:black_concrete
fill 418 80 633 418 81 634 minecraft:red_concrete
fill 418 80 639 418 82 640 minecraft:black_concrete
fill 418 80 641 418 80 642 minecraft:red_concrete
fill 418 80 643 418 85 643 minecraft:black_concrete
fill 376 81 608 376 81 609 minecraft:red_concrete
setblock 376 81 612 minecraft:red_concrete
fill 376 81 613 376 84 613 minecraft:black_concrete
fill 376 81 624 376 84 624 minecraft:black_concrete
setblock 376 81 629 minecraft:red_concrete
setblock 376 81 640 minecraft:red_concrete
fill 376 81 644 376 84 645 minecraft:black_concrete
setblock 387 81 604 minecraft:red_concrete
setblock 391 81 646 minecraft:red_concrete
fill 392 81 604 392 84 604 minecraft:black_concrete
setblock 394 81 646 minecraft:red_concrete
fill 395 81 646 395 84 646 minecraft:black_concrete
setblock 402 81 646 minecraft:red_concrete
fill 403 81 604 403 84 604 minecraft:black_concrete
setblock 404 81 604 minecraft:red_concrete
fill 406 81 646 406 84 646 minecraft:black_concrete
fill 407 81 604 408 81 604 minecraft:red_concrete
fill 418 81 609 418 83 610 minecraft:black_concrete
setblock 418 81 614 minecraft:red_concrete
setblock 418 81 625 minecraft:red_concrete
fill 418 81 630 418 83 630 minecraft:black_concrete
fill 418 81 641 418 84 641 minecraft:black_concrete
setblock 418 81 642 minecraft:red_concrete
setblock 418 81 645 minecraft:red_concrete
fill 376 82 607 376 83 607 minecraft:red_concrete
fill 376 82 608 376 87 609 minecraft:black_concrete
setblock 376 82 610 minecraft:red_concrete
fill 376 82 612 376 87 612 minecraft:black_concrete
fill 376 82 618 376 83 619 minecraft:red_concrete
fill 376 82 620 376 87 621 minecraft:black_concrete
fill 376 82 629 376 87 629 minecraft:black_concrete
fill 376 82 630 376 82 631 minecraft:red_concrete
fill 376 82 632 376 87 633 minecraft:black_concrete
fill 376 82 638 376 83 639 minecraft:red_concrete
fill 376 82 640 376 87 641 minecraft:black_concrete
setblock 376 82 642 minecraft:red_concrete
fill 377 82 604 378 83 604 minecraft:red_concrete
setblock 379 82 607 minecraft:light[level=12]
setblock 379 82 615 minecraft:light[level=12]
setblock 379 82 623 minecraft:light[level=12]
setblock 379 82 631 minecraft:light[level=12]
setblock 379 82 639 minecraft:light[level=12]
fill 380 82 646 381 83 646 minecraft:red_concrete
fill 382 82 646 383 87 646 minecraft:black_concrete
fill 383 82 604 384 87 604 minecraft:black_concrete
fill 385 82 604 386 82 604 minecraft:red_concrete
fill 387 82 604 387 87 604 minecraft:black_concrete
setblock 387 82 607 minecraft:light[level=12]
setblock 387 82 615 minecraft:light[level=12]
setblock 387 82 623 minecraft:light[level=12]
setblock 387 82 631 minecraft:light[level=12]
setblock 387 82 639 minecraft:light[level=12]
fill 389 82 646 389 83 646 minecraft:red_concrete
fill 391 82 646 391 87 646 minecraft:black_concrete
fill 392 82 646 393 82 646 minecraft:red_concrete
fill 394 82 646 394 87 646 minecraft:black_concrete
fill 395 82 604 396 87 604 minecraft:black_concrete
setblock 395 82 607 minecraft:light[level=12]
setblock 395 82 615 minecraft:light[level=12]
setblock 395 82 623 minecraft:light[level=12]
setblock 395 82 631 minecraft:light[level=12]
setblock 395 82 639 minecraft:light[level=12]
fill 397 82 604 398 83 604 minecraft:red_concrete
fill 400 82 646 401 83 646 minecraft:red_concrete
fill 402 82 646 403 87 646 minecraft:black_concrete
setblock 403 82 607 minecraft:light[level=12]
setblock 403 82 615 minecraft:light[level=12]
setblock 403 82 623 minecraft:light[level=12]
setblock 403 82 631 minecraft:light[level=12]
setblock 403 82 639 minecraft:light[level=12]
fill 404 82 604 404 87 604 minecraft:black_concrete
setblock 406 82 604 minecraft:red_concrete
fill 407 82 604 408 87 604 minecraft:black_concrete
fill 409 82 604 409 83 604 minecraft:red_concrete
setblock 411 82 607 minecraft:light[level=12]
setblock 411 82 615 minecraft:light[level=12]
setblock 411 82 623 minecraft:light[level=12]
setblock 411 82 631 minecraft:light[level=12]
setblock 411 82 639 minecraft:light[level=12]
fill 412 82 646 413 82 646 minecraft:red_concrete
fill 414 82 646 415 87 646 minecraft:black_concrete
fill 415 82 604 416 87 604 minecraft:black_concrete
fill 417 82 604 418 82 604 minecraft:red_concrete
fill 418 82 611 418 85 611 minecraft:black_concrete
setblock 418 82 612 minecraft:red_concrete
fill 418 82 613 418 87 614 minecraft:black_concrete
fill 418 82 615 418 83 616 minecraft:red_concrete
fill 418 82 621 418 84 622 minecraft:black_concrete
fill 418 82 623 418 82 624 minecraft:red_concrete
fill 418 82 625 418 87 625 minecraft:black_concrete
fill 418 82 627 418 83 627 minecraft:red_concrete
setblock 418 82 628 minecraft:black_concrete
fill 418 82 633 418 87 634 minecraft:black_concrete
fill 418 82 635 418 83 636 minecraft:red_concrete
fill 418 82 642 418 84 642 minecraft:black_concrete
setblock 418 82 644 minecraft:red_concrete
fill 418 82 645 418 87 645 minecraft:black_concrete
setblock 376 83 606 minecraft:red_concrete
fill 376 83 610 376 86 610 minecraft:black_concrete
fill 376 83 626 376 83 627 minecraft:red_concrete
setblock 376 83 630 minecraft:red_concrete
fill 376 83 631 376 86 631 minecraft:black_concrete
fill 376 83 642 376 86 642 minecraft:black_concrete
setblock 377 83 646 minecraft:red_concrete
fill 385 83 604 385 86 604 minecraft:black_concrete
setblock 386 83 604 minecraft:red_concrete
setblock 388 83 646 minecraft:red_concrete
fill 389 83 604 390 83 604 minecraft:red_concrete
fill 392 83 646 393 86 646 minecraft:black_concrete
fill 399 83 636 399 84 636 minecraft:blackstone
fill 406 83 604 406 86 604 minecraft:black_concrete
setblock 409 83 646 minecraft:red_concrete
setblock 410 83 604 minecraft:red_concrete
setblock 412 83 646 minecraft:red_concrete
fill 413 83 646 413 86 646 minecraft:black_concrete
fill 417 83 604 417 86 604 minecraft:black_concrete
setblock 418 83 604 minecraft:red_concrete
setblock 418 83 607 minecraft:red_concrete
fill 418 83 612 418 85 612 minecraft:black_concrete
fill 418 83 623 418 86 623 minecraft:black_concrete
setblock 418 83 624 minecraft:red_concrete
setblock 418 83 628 minecraft:red_concrete
setblock 418 83 639 minecraft:red_concrete
fill 418 83 640 418 85 640 minecraft:black_concrete
fill 418 83 644 418 86 644 minecraft:black_concrete
fill 376 84 604 376 85 605 minecraft:red_concrete
fill 376 84 606 376 89 607 minecraft:black_concrete
fill 376 84 616 376 84 617 minecraft:red_concrete
fill 376 84 618 376 89 619 minecraft:black_concrete
fill 376 84 625 376 85 625 minecraft:red_concrete
fill 376 84 626 376 89 627 minecraft:black_concrete
setblock 376 84 628 minecraft:red_concrete
fill 376 84 630 376 89 630 minecraft:black_concrete
fill 376 84 636 376 85 637 minecraft:red_concrete
fill 376 84 638 376 89 639 minecraft:black_concrete
fill 377 84 604 378 89 604 minecraft:black_concrete
fill 377 84 605 379 84 605 minecraft:polished_blackstone
fill 377 84 607 377 84 609 minecraft:polished_blackstone
fill 377 84 611 377 84 613 minecraft:polished_blackstone
fill 377 84 615 377 84 617 minecraft:polished_blackstone
fill 377 84 619 377 84 621 minecraft:polished_blackstone
fill 377 84 623 377 84 625 minecraft:polished_blackstone
fill 377 84 627 377 84 629 minecraft:polished_blackstone
fill 377 84 631 377 84 633 minecraft:polished_blackstone
fill 377 84 635 377 84 637 minecraft:polished_blackstone
fill 377 84 639 377 84 641 minecraft:polished_blackstone
fill 377 84 643 377 84 645 minecraft:polished_blackstone
fill 377 84 646 377 89 646 minecraft:black_concrete
fill 378 84 646 379 84 646 minecraft:red_concrete
fill 379 84 604 380 85 604 minecraft:red_concrete
fill 379 84 645 381 84 645 minecraft:polished_blackstone
fill 380 84 646 381 89 646 minecraft:black_concrete
fill 381 84 605 383 84 605 minecraft:polished_blackstone
fill 383 84 645 385 84 645 minecraft:polished_blackstone
fill 385 84 605 387 84 605 minecraft:polished_blackstone
fill 386 84 604 386 89 604 minecraft:black_concrete
fill 386 84 646 387 85 646 minecraft:red_concrete
fill 387 84 645 389 84 645 minecraft:polished_blackstone
setblock 388 84 604 minecraft:red_concrete
fill 388 84 646 389 89 646 minecraft:black_concrete
fill 389 84 604 390 89 604 minecraft:black_concrete
fill 389 84 605 391 84 605 minecraft:polished_blackstone
setblock 390 84 646 minecraft:red_concrete
fill 391 84 604 391 85 604 minecraft:red_concrete
fill 391 84 645 393 84 645 minecraft:polished_blackstone
fill 393 84 605 395 84 605 minecraft:polished_blackstone
fill 395 84 645 397 84 645 minecraft:polished_blackstone
fill 397 84 604 398 89 604 minecraft:black_concrete
fill 397 84 605 399 84 605 minecraft:polished_blackstone
fill 398 84 646 399 85 646 minecraft:red_concrete
fill 399 84 604 400 84 604 minecraft:red_concrete
fill 399 84 645 401 84 645 minecraft:polished_blackstone
fill 400 84 646 401 89 646 minecraft:black_concrete
fill 401 84 605 403 84 605 minecraft:polished_blackstone
fill 403 84 645 405 84 645 minecraft:polished_blackstone
fill 405 84 605 407 84 605 minecraft:polished_blackstone
fill 407 84 645 409 84 645 minecraft:polished_blackstone
fill 407 84 646 407 85 646 minecraft:red_concrete
fill 409 84 604 410 89 604 minecraft:black_concrete
fill 409 84 605 411 84 605 minecraft:polished_blackstone
fill 409 84 646 409 89 646 minecraft:black_concrete
fill 410 84 646 411 84 646 minecraft:red_concrete
fill 411 84 604 412 85 604 minecraft:red_concrete
fill 411 84 645 413 84 645 minecraft:polished_blackstone
fill 412 84 646 412 89 646 minecraft:black_concrete
fill 413 84 605 415 84 605 minecraft:polished_blackstone
fill 415 84 645 417 84 645 minecraft:polished_blackstone
fill 417 84 605 417 84 607 minecraft:polished_blackstone
fill 417 84 609 417 84 611 minecraft:polished_blackstone
fill 417 84 613 417 84 615 minecraft:polished_blackstone
fill 417 84 617 417 84 619 minecraft:polished_blackstone
fill 417 84 621 417 84 623 minecraft:polished_blackstone
fill 417 84 625 417 84 627 minecraft:polished_blackstone
fill 417 84 629 417 84 631 minecraft:polished_blackstone
fill 417 84 633 417 84 635 minecraft:polished_blackstone
fill 417 84 637 417 84 639 minecraft:polished_blackstone
fill 417 84 641 417 84 643 minecraft:polished_blackstone
fill 418 84 604 418 89 604 minecraft:black_concrete
fill 418 84 605 418 84 606 minecraft:red_concrete
fill 418 84 607 418 89 607 minecraft:black_concrete
fill 418 84 609 418 85 609 minecraft:red_concrete
setblock 418 84 610 minecraft:black_concrete
fill 418 84 615 418 89 616 minecraft:black_concrete
fill 418 84 617 418 85 618 minecraft:red_concrete
fill 418 84 624 418 86 624 minecraft:black_concrete
setblock 418 84 626 minecraft:red_concrete
fill 418 84 627 418 89 628 minecraft:black_concrete
fill 418 84 629 418 85 630 minecraft:red_concrete
fill 418 84 635 418 89 636 minecraft:black_concrete
fill 418 84 637 418 84 638 minecraft:red_concrete
fill 418 84 639 418 85 639 minecraft:black_concrete
fill 418 84 646 418 85 646 minecraft:red_concrete
setblock 376 85 613 minecraft:red_concrete
setblock 376 85 616 minecraft:red_concrete
fill 376 85 617 376 88 617 minecraft:black_concrete
setblock 376 85 624 minecraft:red_concrete
fill 376 85 628 376 88 628 minecraft:black_concrete
fill 376 85 644 376 85 645 minecraft:red_concrete
setblock 378 85 646 minecraft:red_concrete
fill 379 85 646 379 88 646 minecraft:black_concrete
fill 388 85 604 388 88 604 minecraft:black_concrete
fill 390 85 646 390 88 646 minecraft:black_concrete
setblock 392 85 604 minecraft:red_concrete
setblock 395 85 646 minecraft:red_concrete
fill 399 85 604 399 88 604 minecraft:black_concrete
setblock 400 85 604 minecraft:red_concrete
setblock 403 85 604 minecraft:red_concrete
setblock 406 85 646 minecraft:red_concrete
fill 410 85 646 411 88 646 minecraft:black_concrete
fill 418 85 605 418 88 606 minecraft:black_concrete
setblock 418 85 610 minecraft:red_concrete
setblock 418 85 621 minecraft:red_concrete
fill 418 85 622 418 87 622 minecraft:black_concrete
fill 418 85 626 418 88 626 minecraft:black_concrete
fill 418 85 637 418 88 637 minecraft:black_concrete
setblock 418 85 638 minecraft:red_concrete
fill 418 85 641 418 85 642 minecraft:red_concrete
fill 376 86 604 376 91 605 minecraft:black_concrete
fill 376 86 611 376 87 611 minecraft:red_concrete
fill 376 86 613 376 91 613 minecraft:black_concrete
fill 376 86 614 376 86 615 minecraft:red_concrete
fill 376 86 616 376 91 616 minecraft:black_concrete
fill 376 86 622 376 87 623 minecraft:red_concrete
fill 376 86 624 376 91 625 minecraft:black_concrete
fill 376 86 634 376 86 635 minecraft:red_concrete
fill 376 86 636 376 91 637 minecraft:black_concrete
fill 376 86 643 376 87 643 minecraft:red_concrete
fill 376 86 644 376 91 645 minecraft:black_concrete
setblock 376 86 646 minecraft:red_concrete
fill 378 86 646 378 91 646 minecraft:black_concrete
fill 379 86 604 380 91 604 minecraft:black_concrete
fill 381 86 604 382 86 604 minecraft:red_concrete
fill 384 86 613 386 87 613 minecraft:blackstone
fill 384 86 646 385 87 646 minecraft:red_concrete
fill 385 86 612 385 87 612 minecraft:blackstone
fill 385 86 614 385 87 614 minecraft:blackstone
fill 386 86 646 387 91 646 minecraft:black_concrete
fill 391 86 604 392 91 604 minecraft:black_concrete
fill 393 86 604 394 87 604 minecraft:red_concrete
fill 395 86 646 395 91 646 minecraft:black_concrete
fill 396 86 646 397 86 646 minecraft:red_concrete
fill 398 86 646 399 91 646 minecraft:black_concrete
fill 400 86 604 400 91 604 minecraft:black_concrete
fill 401 86 604 402 86 604 minecraft:red_concrete
fill 403 86 604 403 91 604 minecraft:black_concrete
fill 404 86 646 405 87 646 minecraft:red_concrete
fill 405 86 604 405 87 604 minecraft:red_concrete
fill 406 86 646 407 91 646 minecraft:black_concrete
setblock 408 86 646 minecraft:red_concrete
fill 411 86 604 412 91 604 minecraft:black_concrete
fill 413 86 604 414 87 604 minecraft:red_concrete
fill 414 86 618 415 87 619 minecraft:red_concrete
fill 416 86 646 417 87 646 minecraft:red_concrete
setblock 418 86 608 minecraft:red_concrete
fill 418 86 609 418 91 610 minecraft:black_concrete
fill 418 86 611 418 87 612 minecraft:red_concrete
fill 418 86 617 418 91 618 minecraft:black_concrete
fill 418 86 619 418 86 620 minecraft:red_concrete
fill 418 86 621 418 87 621 minecraft:black_concrete
fill 418 86 629 418 91 630 minecraft:black_concrete
fill 418 86 631 418 87 632 minecraft:red_concrete
fill 418 86 638 418 91 638 minecraft:black_concrete
fill 418 86 639 418 86 640 minecraft:red_concrete
fill 418 86 641 418 87 642 minecraft:black_concrete
fill 418 86 643 418 87 643 minecraft:red_concrete
fill 418 86 646 418 91 646 minecraft:black_concrete
setblock 376 87 610 minecraft:red_concrete
fill 376 87 614 376 90 615 minecraft:black_concrete
setblock 376 87 631 minecraft:red_concrete
setblock 376 87 634 minecraft:red_concrete
fill 376 87 635 376 90 635 minecraft:black_concrete
setblock 376 87 642 minecraft:red_concrete
fill 376 87 646 376 90 646 minecraft:black_concrete
fill 381 87 604 381 90 604 minecraft:black_concrete
setblock 382 87 604 minecraft:red_concrete
setblock 385 87 604 minecraft:red_concrete
fill 392 87 646 393 87 646 minecraft:red_concrete
setblock 396 87 646 minecraft:red_concrete
fill 397 87 646 397 90 646 minecraft:black_concrete
fill 401 87 604 402 90 604 minecraft:black_concrete
setblock 406 87 604 minecraft:red_concrete
fill 408 87 646 408 90 646 minecraft:black_concrete
setblock 413 87 646 minecraft:red_concrete
setblock 417 87 604 minecraft:red_concrete
fill 418 87 608 418 90 608 minecraft:black_concrete
fill 418 87 619 418 90 619 minecraft:black_concrete
setblock 418 87 620 minecraft:red_concrete
fill 418 87 623 418 87 624 minecraft:red_concrete
fill 418 87 639 418 89 640 minecraft:black_concrete
setblock 418 87 644 minecraft:red_concrete
fill 376 88 608 376 89 609 minecraft:red_concrete
fill 376 88 610 376 93 611 minecraft:black_concrete
setblock 376 88 612 minecraft:red_concrete
fill 376 88 620 376 89 621 minecraft:red_concrete
fill 376 88 622 376 93 623 minecraft:black_concrete
fill 376 88 629 376 89 629 minecraft:red_concrete
fill 376 88 631 376 93 631 minecraft:black_concrete
fill 376 88 632 376 88 633 minecraft:red_concrete
fill 376 88 634 376 93 634 minecraft:black_concrete
fill 376 88 640 376 89 641 minecraft:red_concrete
fill 376 88 642 376 93 643 minecraft:black_concrete
fill 382 88 604 382 93 604 minecraft:black_concrete
fill 382 88 646 383 88 646 minecraft:red_concrete
fill 383 88 604 384 88 604 minecraft:red_concrete
fill 384 88 646 385 93 646 minecraft:black_concrete
fill 385 88 604 385 93 604 minecraft:black_concrete
fill 387 88 604 387 89 604 minecraft:red_concrete
fill 391 88 646 391 89 646 minecraft:red_concrete
fill 392 88 646 393 93 646 minecraft:black_concrete
fill 393 88 604 394 93 604 minecraft:black_concrete
setblock 394 88 646 minecraft:red_concrete
fill 395 88 604 396 89 604 minecraft:red_concrete
fill 396 88 646 396 93 646 minecraft:black_concrete
fill 402 88 646 403 89 646 minecraft:red_concrete
setblock 404 88 604 minecraft:red_concrete
fill 404 88 646 405 93 646 minecraft:black_concrete
fill 405 88 604 406 93 604 minecraft:black_concrete
fill 407 88 604 408 89 604 minecraft:red_concrete
fill 413 88 604 414 93 604 minecraft:black_concrete
fill 413 88 646 413 93 646 minecraft:black_concrete
fill 414 88 646 415 88 646 minecraft:red_concrete
fill 415 88 604 416 88 604 minecraft:red_concrete
fill 416 88 646 417 90 646 minecraft:black_concrete
fill 417 88 604 417 93 604 minecraft:black_concrete
fill 418 88 611 418 93 612 minecraft:black_concrete
fill 418 88 613 418 89 614 minecraft:red_concrete
fill 418 88 620 418 93 620 minecraft:black_concrete
fill 418 88 621 418 88 622 minecraft:red_concrete
fill 418 88 623 418 89 624 minecraft:black_concrete
fill 418 88 625 418 89 625 minecraft:red_concrete
fill 418 88 631 418 93 632 minecraft:black_concrete
fill 418 88 633 418 89 634 minecraft:red_concrete
fill 418 88 641 418 91 641 minecraft:black_concrete
setblock 418 88 642 minecraft:red_concrete
fill 418 88 643 418 93 644 minecraft:black_concrete
fill 418 88 645 418 89 645 minecraft:red_concrete
fill 376 89 612 376 92 612 minecraft:black_concrete
setblock 376 89 617 minecraft:red_concrete
setblock 376 89 628 minecraft:red_concrete
fill 376 89 632 376 92 633 minecraft:black_concrete
setblock 379 89 646 minecraft:red_concrete
setblock 382 89 646 minecraft:red_concrete
fill 383 89 604 384 92 604 minecraft:black_concrete
fill 383 89 646 383 92 646 minecraft:black_concrete
setblock 388 89 604 minecraft:red_concrete
setblock 390 89 646 minecraft:red_concrete
fill 394 89 646 394 92 646 minecraft:black_concrete
setblock 399 89 604 minecraft:red_concrete
fill 404 89 604 404 92 604 minecraft:black_concrete
fill 410 89 646 411 89 646 minecraft:red_concrete
setblock 414 89 646 minecraft:red_concrete
fill 415 89 604 415 92 604 minecraft:black_concrete
fill 415 89 646 415 92 646 minecraft:black_concrete
setblock 416 89 604 minecraft:red_concrete
fill 418 89 605 418 89 606 minecraft:red_concrete
fill 418 89 621 418 91 622 minecraft:black_concrete
setblock 418 89 626 minecraft:red_concrete
setblock 418 89 637 minecraft:red_concrete
fill 418 89 642 418 91 642 minecraft:black_concrete
fill 376 90 606 376 91 607 minecraft:red_concrete
fill 376 90 608 376 95 609 minecraft:black_concrete
fill 376 90 617 376 95 617 minecraft:black_concrete
fill 376 90 618 376 90 619 minecraft:red_concrete
fill 376 90 620 376 95 621 minecraft:black_concrete
fill 376 90 626 376 91 627 minecraft:red_concrete
fill 376 90 628 376 95 629 minecraft:black_concrete
setblock 376 90 630 minecraft:red_concrete
fill 376 90 638 376 91 639 minecraft:red_concrete
fill 376 90 640 376 95 641 minecraft:black_concrete
fill 377 90 604 378 91 604 minecraft:red_concrete
fill 377 90 605 379 90 605 minecraft:polished_blackstone
fill 377 90 607 377 90 609 minecraft:polished_blackstone
fill 377 90 611 377 90 613 minecraft:polished_blackstone
fill 377 90 615 377 90 617 minecraft:polished_blackstone
fill 377 90 619 377 90 621 minecraft:polished_blackstone
fill 377 90 623 377 90 625 minecraft:polished_blackstone
fill 377 90 627 377 90 629 minecraft:polished_blackstone
fill 377 90 631 377 90 633 minecraft:polished_blackstone
fill 377 90 635 377 90 637 minecraft:polished_blackstone
fill 377 90 639 377 90 641 minecraft:polished_blackstone
fill 377 90 643 377 90 645 minecraft:polished_blackstone
fill 377 90 646 377 91 646 minecraft:red_concrete
setblock 379 90 607 minecraft:light[level=12]
setblock 379 90 615 minecraft:light[level=12]
setblock 379 90 623 minecraft:light[level=12]
setblock 379 90 631 minecraft:light[level=12]
setblock 379 90 639 minecraft:light[level=12]
fill 379 90 645 381 90 645 minecraft:polished_blackstone
fill 379 90 646 379 95 646 minecraft:black_concrete
fill 380 90 646 381 90 646 minecraft:red_concrete
fill 381 90 605 383 90 605 minecraft:polished_blackstone
fill 382 90 646 382 95 646 minecraft:black_concrete
fill 383 90 645 385 90 645 minecraft:polished_blackstone
fill 385 90 605 387 90 605 minecraft:polished_blackstone
setblock 386 90 604 minecraft:red_concrete
fill 387 90 604 388 95 604 minecraft:black_concrete
setblock 387 90 607 minecraft:light[level=12]
setblock 387 90 615 minecraft:light[level=12]
setblock 387 90 623 minecraft:light[level=12]
setblock 387 90 631 minecraft:light[level=12]
setblock 387 90 639 minecraft:light[level=12]
fill 387 90 645 389 90 645 minecraft:polished_blackstone
fill 388 90 646 389 91 646 minecraft:red_concrete
fill 389 90 604 390 91 604 minecraft:red_concrete
fill 389 90 605 391 90 605 minecraft:polished_blackstone
fill 390 90 646 391 95 646 minecraft:black_concrete
fill 391 90 645 393 90 645 minecraft:polished_blackstone
fill 393 90 605 395 90 605 minecraft:polished_blackstone
fill 395 90 604 396 95 604 minecraft:black_concrete
setblock 395 90 607 minecraft:light[level=12]
setblock 395 90 615 minecraft:light[level=12]
setblock 395 90 623 minecraft:light[level=12]
setblock 395 90 631 minecraft:light[level=12]
setblock 395 90 639 minecraft:light[level=12]
fill 395 90 645 397 90 645 minecraft:polished_blackstone
fill 397 90 604 398 90 604 minecraft:red_concrete
fill 397 90 605 399 90 605 minecraft:polished_blackstone
fill 399 90 604 399 95 604 minecraft:black_concrete
fill 399 90 645 401 90 645 minecraft:polished_blackstone
fill 400 90 646 401 90 646 minecraft:red_concrete
fill 401 90 605 403 90 605 minecraft:polished_blackstone
fill 402 90 646 403 95 646 minecraft:black_concrete
setblock 403 90 607 minecraft:light[level=12]
setblock 403 90 615 minecraft:light[level=12]
setblock 403 90 623 minecraft:light[level=12]
setblock 403 90 631 minecraft:light[level=12]
setblock 403 90 639 minecraft:light[level=12]
fill 403 90 645 405 90 645 minecraft:polished_blackstone
fill 405 90 605 407 90 605 minecraft:polished_blackstone
fill 407 90 604 408 95 604 minecraft:black_concrete
fill 407 90 645 409 90 645 minecraft:polished_blackstone
fill 409 90 604 410 91 604 minecraft:red_concrete
fill 409 90 605 411 90 605 minecraft:polished_blackstone
fill 409 90 646 409 91 646 minecraft:red_concrete
fill 410 90 646 411 95 646 minecraft:black_concrete
setblock 411 90 607 minecraft:light[level=12]
setblock 411 90 615 minecraft:light[level=12]
setblock 411 90 623 minecraft:light[level=12]
setblock 411 90 631 minecraft:light[level=12]
setblock 411 90 639 minecraft:light[level=12]
fill 411 90 645 413 90 645 minecraft:polished_blackstone
setblock 412 90 646 minecraft:red_concrete
fill 413 90 605 415 90 605 minecraft:polished_blackstone
fill 414 90 646 414 92 646 minecraft:black_concrete
fill 415 90 645 417 90 645 minecraft:polished_blackstone
fill 416 90 604 416 95 604 minecraft:black_concrete
fill 417 90 605 417 90 607 minecraft:polished_blackstone
fill 417 90 609 417 90 611 minecraft:polished_blackstone
fill 417 90 613 417 90 615 minecraft:polished_blackstone
fill 417 90 617 417 90 619 minecraft:polished_blackstone
fill 417 90 621 417 90 623 minecraft:polished_blackstone
fill 417 90 625 417 90 627 minecraft:polished_blackstone
fill 417 90 629 417 90 631 minecraft:polished_blackstone
fill 417 90 633 417 90 635 minecraft:polished_blackstone
fill 417 90 637 417 90 639 minecraft:polished_blackstone
fill 417 90 641 417 90 643 minecraft:polished_blackstone
setblock 418 90 604 minecraft:red_concrete
fill 418 90 605 418 95 606 minecraft:black_concrete
fill 418 90 607 418 91 607 minecraft:red_concrete
fill 418 90 613 418 95 614 minecraft:black_concrete
fill 418 90 615 418 90 616 minecraft:red_concrete
fill 418 90 623 418 93 623 minecraft:black_concrete
setblock 418 90 624 minecraft:red_concrete
fill 418 90 625 418 95 626 minecraft:black_concrete
fill 418 90 627 418 91 628 minecraft:red_concrete
fill 418 90 633 418 92 634 minecraft:black_concrete
fill 418 90 635 418 90 636 minecraft:red_concrete
fill 418 90 637 418 95 637 minecraft:black_concrete
fill 418 90 639 418 91 639 minecraft:red_concrete
setblock 418 90 640 minecraft:black_concrete
fill 418 90 645 418 95 645 minecraft:black_concrete
fill 376 91 614 376 91 615 minecraft:red_concrete
setblock 376 91 618 minecraft:red_concrete
fill 376 91 619 376 94 619 minecraft:black_concrete
fill 376 91 630 376 94 630 minecraft:black_concrete
setblock 376 91 635 minecraft:red_concrete
setblock 376 91 646 minecraft:red_concrete
fill 380 91 646 381 94 646 minecraft:black_concrete
setblock 381 91 604 minecraft:red_concrete
fill 386 91 604 386 94 604 minecraft:black_concrete
fill 397 91 604 397 94 604 minecraft:black_concrete
setblock 397 91 646 minecraft:red_concrete
setblock 398 91 604 minecraft:red_concrete
setblock 400 91 646 minecraft:red_concrete
fill 401 91 604 402 91 604 minecraft:red_concrete
fill 401 91 646 401 94 646 minecraft:black_concrete
setblock 408 91 646 minecraft:red_concrete
fill 412 91 646 412 94 646 minecraft:black_concrete
fill 416 91 646 416 93 646 minecraft:black_concrete
setblock 417 91 646 minecraft:red_concrete
fill 418 91 604 418 94 604 minecraft:black_concrete
setblock 418 91 608 minecraft:red_concrete
fill 418 91 615 418 94 615 minecraft:black_concrete
setblock 418 91 616 minecraft:red_concrete
setblock 418 91 619 minecraft:red_concrete
fill 418 91 624 418 93 624 minecraft:black_concrete
fill 418 91 635 418 94 635 minecraft:black_concrete
setblock 418 91 636 minecraft:red_concrete
setblock 418 91 640 minecraft:red_concrete
fill 376 92 604 376 92 605 minecraft:red_concrete
fill 376 92 606 376 97 607 minecraft:black_concrete
fill 376 92 613 376 93 613 minecraft:red_concrete
fill 376 92 614 376 97 615 minecraft:black_concrete
setblock 376 92 616 minecraft:red_concrete
fill 376 92 618 376 97 618 minecraft:black_concrete
fill 376 92 624 376 93 625 minecraft:red_concrete
fill 376 92 626 376 97 627 minecraft:black_concrete
fill 376 92 635 376 97 635 minecraft:black_concrete
fill 376 92 636 376 92 637 minecraft:red_concrete
fill 376 92 638 376 97 639 minecraft:black_concrete
fill 376 92 644 376 93 645 minecraft:red_concrete
fill 376 92 646 377 97 646 minecraft:black_concrete
fill 377 92 604 378 97 604 minecraft:black_concrete
setblock 378 92 646 minecraft:red_concrete
fill 379 92 604 380 92 604 minecraft:red_concrete
fill 381 92 604 381 97 604 minecraft:black_concrete
fill 386 92 646 387 93 646 minecraft:red_concrete
fill 388 92 646 389 97 646 minecraft:black_concrete
fill 389 92 604 390 97 604 minecraft:black_concrete
fill 391 92 604 392 93 604 minecraft:red_concrete
fill 395 92 646 395 93 646 minecraft:red_concrete
fill 397 92 646 397 97 646 minecraft:black_concrete
fill 398 92 604 398 97 604 minecraft:black_concrete
fill 398 92 646 399 92 646 minecraft:red_concrete
setblock 400 92 604 minecraft:red_concrete
fill 400 92 646 400 97 646 minecraft:black_concrete
fill 401 92 604 402 97 604 minecraft:black_concrete
fill 403 92 604 403 93 604 minecraft:red_concrete
fill 406 92 646 407 93 646 minecraft:red_concrete
fill 408 92 646 409 97 646 minecraft:black_concrete
fill 409 92 604 410 97 604 minecraft:black_concrete
fill 411 92 604 412 92 604 minecraft:red_concrete
fill 417 92 646 417 93 646 minecraft:black_concrete
fill 418 92 607 418 97 608 minecraft:black_concrete
fill 418 92 609 418 93 610 minecraft:red_concrete
fill 418 92 616 418 97 616 minecraft:black_concrete
fill 418 92 617 418 92 618 minecraft:red_concrete
fill 418 92 619 418 97 619 minecraft:black_concrete
fill 418 92 621 418 93 621 minecraft:red_concrete
setblock 418 92 622 minecraft:black_concrete
fill 418 92 627 418 97 628 minecraft:black_concrete
fill 418 92 629 418 93 630 minecraft:red_concrete
fill 418 92 636 418 94 636 minecraft:black_concrete
setblock 418 92 638 minecraft:red_concrete
fill 418 92 639 418 97 640 minecraft:black_concrete
fill 418 92 641 418 93 642 minecraft:red_concrete
fill 418 92 646 418 93 646 minecraft:red_concrete
setblock 376 93 604 minecraft:red_concrete
fill 376 93 605 376 96 605 minecraft:black_concrete
setblock 376 93 612 minecraft:red_concrete
fill 376 93 616 376 96 616 minecraft:black_concrete
fill 376 93 632 376 93 633 minecraft:red_concrete
setblock 376 93 636 minecraft:red_concrete
fill 376 93 637 376 96 637 minecraft:black_concrete
fill 378 93 646 378 96 646 minecraft:black_concrete
fill 379 93 604 379 96 604 minecraft:black_concrete
setblock 380 93 604 minecraft:red_concrete
fill 383 93 604 384 93 604 minecraft:red_concrete
setblock 383 93 646 minecraft:red_concrete
setblock 394 93 646 minecraft:red_concrete
fill 398 93 646 399 96 646 minecraft:black_concrete
fill 400 93 604 400 96 604 minecraft:black_concrete
setblock 404 93 604 minecraft:red_concrete
fill 411 93 604 411 96 604 minecraft:black_concrete
setblock 412 93 604 minecraft:red_concrete
fill 414 93 646 415 93 646 minecraft:red_concrete
setblock 415 93 604 minecraft:red_concrete
fill 418 93 617 418 96 618 minecraft:black_concrete
setblock 418 93 622 minecraft:red_concrete
setblock 418 93 633 minecraft:red_concrete
fill 418 93 634 418 95 634 minecraft:black_concrete
fill 418 93 638 418 96 638 minecraft:black_concrete
fill 376 94 604 376 107 604 minecraft:black_concrete
fill 376 94 610 376 95 611 minecraft:red_concrete
fill 376 94 612 376 107 613 minecraft:black_concrete
fill 376 94 622 376 94 623 minecraft:red_concrete
fill 376 94 624 376 105 625 minecraft:black_concrete
fill 376 94 631 376 95 631 minecraft:red_concrete
fill 376 94 632 376 103 633 minecraft:black_concrete
setblock 376 94 634 minecraft:red_concrete
fill 376 94 636 376 104 636 minecraft:black_concrete
fill 376 94 642 376 95 643 minecraft:red_concrete
fill 376 94 644 376 103 645 minecraft:black_concrete
fill 380 94 604 380 108 604 minecraft:black_concrete
setblock 382 94 604 minecraft:red_concrete
fill 383 94 604 384 105 604 minecraft:black_concrete
fill 383 94 646 383 103 646 minecraft:black_concrete
fill 384 94 646 385 94 646 minecraft:red_concrete
fill 385 94 604 385 95 604 minecraft:red_concrete
fill 386 94 646 387 103 646 minecraft:black_concrete
fill 391 94 604 392 107 604 minecraft:black_concrete
fill 392 94 646 393 95 646 minecraft:red_concrete
fill 393 94 604 394 94 604 minecraft:red_concrete
fill 394 94 646 395 107 646 minecraft:black_concrete
setblock 396 94 646 minecraft:red_concrete
fill 403 94 604 404 103 604 minecraft:black_concrete
fill 404 94 646 405 95 646 minecraft:red_concrete
fill 405 94 604 406 95 604 minecraft:red_concrete
fill 406 94 646 407 104 646 minecraft:black_concrete
fill 412 94 604 412 107 604 minecraft:black_concrete
fill 413 94 604 414 94 604 minecraft:red_concrete
fill 413 94 646 413 95 646 minecraft:red_concrete
fill 414 94 646 415 95 646 minecraft:black_concrete
fill 415 94 604 415 107 604 minecraft:black_concrete
fill 416 94 646 417 94 646 minecraft:red_concrete
fill 417 94 604 417 95 604 minecraft:red_concrete
fill 418 94 609 418 105 610 minecraft:black_concrete
fill 418 94 611 418 95 612 minecraft:red_concrete
setblock 418 94 620 minecraft:red_concrete
fill 418 94 621 418 107 622 minecraft:black_concrete
fill 418 94 623 418 95 624 minecraft:red_concrete
fill 418 94 629 418 107 630 minecraft:black_concrete
fill 418 94 631 418 94 632 minecraft:red_concrete
fill 418 94 633 418 95 633 minecraft:black_concrete
fill 418 94 641 418 105 642 minecraft:black_concrete
fill 418 94 643 418 95 644 minecraft:red_concrete
fill 418 94 646 418 103 646 minecraft:black_concrete
setblock 376 95 619 minecraft:red_concrete
setblock 376 95 622 minecraft:red_concrete
fill 376 95 623 376 98 623 minecraft:black_concrete
setblock 376 95 630 minecraft:red_concrete
fill 376 95 634 376 98 634 minecraft:black_concrete
fill 380 95 646 381 95 646 minecraft:red_concrete
fill 382 95 604 382 98 604 minecraft:black_concrete
setblock 384 95 646 minecraft:red_concrete
fill 385 95 646 385 98 646 minecraft:black_concrete
setblock 386 95 604 minecraft:red_concrete
fill 393 95 604 393 98 604 minecraft:black_concrete
setblock 394 95 604 minecraft:red_concrete
fill 396 95 646 396 98 646 minecraft:black_concrete
setblock 397 95 604 minecraft:red_concrete
setblock 401 95 646 minecraft:red_concrete
setblock 412 95 646 minecraft:red_concrete
fill 413 95 604 414 98 604 minecraft:black_concrete
fill 416 95 646 417 97 646 minecraft:black_concrete
setblock 418 95 604 minecraft:red_concrete
setblock 418 95 615 minecraft:red_concrete
fill 418 95 620 418 98 620 minecraft:black_concrete
fill 418 95 631 418 98 631 minecraft:black_concrete
setblock 418 95 632 minecraft:red_concrete
fill 418 95 635 418 95 636 minecraft:red_concrete
fill 376 96 608 376 97 609 minecraft:red_concrete
fill 376 96 610 376 105 611 minecraft:black_concrete
fill 376 96 617 376 97 617 minecraft:red_concrete
fill 376 96 619 376 107 619 minecraft:black_concrete
fill 376 96 620 376 96 621 minecraft:red_concrete
fill 376 96 622 376 107 622 minecraft:black_concrete
fill 376 96 628 376 97 629 minecraft:red_concrete
fill 376 96 630 376 104 631 minecraft:black_concrete
fill 376 96 640 376 96 641 minecraft:red_concrete
fill 376 96 642 376 103 643 minecraft:black_concrete
fill 377 96 605 379 96 605 minecraft:polished_blackstone
fill 377 96 607 377 96 609 minecraft:polished_blackstone
fill 377 96 611 377 96 613 minecraft:polished_blackstone
fill 377 96 615 377 96 617 minecraft:polished_blackstone
fill 377 96 619 377 96 621 minecraft:polished_blackstone
fill 377 96 623 377 96 625 minecraft:polished_blackstone
fill 377 96 627 377 96 629 minecraft:polished_blackstone
fill 377 96 631 377 96 633 minecraft:polished_blackstone
fill 377 96 635 377 96 637 minecraft:polished_blackstone
fill 377 96 639 377 96 641 minecraft:polished_blackstone
fill 377 96 643 377 96 645 minecraft:polished_blackstone
fill 379 96 645 381 96 645 minecraft:polished_blackstone
fill 379 96 646 379 97 646 minecraft:red_concrete
fill 380 96 646 381 107 646 minecraft:black_concrete
fill 381 96 605 383 96 605 minecraft:polished_blackstone
setblock 382 96 646 minecraft:red_concrete
fill 383 96 645 385 96 645 minecraft:polished_blackstone
fill 384 96 646 384 105 646 minecraft:black_concrete
fill 385 96 604 386 104 604 minecraft:black_concrete
fill 385 96 605 387 96 605 minecraft:polished_blackstone
fill 387 96 604 388 97 604 minecraft:red_concrete
fill 387 96 623 387 96 626 minecraft:red_concrete
fill 387 96 645 389 96 645 minecraft:polished_blackstone
fill 388 96 623 389 97 623 minecraft:red_concrete
fill 388 96 626 390 96 626 minecraft:red_concrete
fill 389 96 605 391 96 605 minecraft:polished_blackstone
fill 390 96 624 390 97 625 minecraft:red_concrete
fill 390 96 646 391 97 646 minecraft:red_concrete
fill 391 96 645 393 96 645 minecraft:polished_blackstone
fill 392 96 646 393 107 646 minecraft:black_concrete
fill 393 96 605 395 96 605 minecraft:polished_blackstone
fill 394 96 604 394 105 604 minecraft:black_concrete
fill 395 96 604 396 96 604 minecraft:red_concrete
fill 395 96 645 397 96 645 minecraft:polished_blackstone
fill 397 96 604 397 105 604 minecraft:black_concrete
fill 397 96 605 399 96 605 minecraft:polished_blackstone
fill 399 96 604 399 97 604 minecraft:red_concrete
fill 399 96 645 401 96 645 minecraft:polished_blackstone
fill 401 96 605 403 96 605 minecraft:polished_blackstone
fill 401 96 646 401 107 646 minecraft:black_concrete
fill 402 96 646 403 96 646 minecraft:red_concrete
fill 403 96 645 405 96 645 minecraft:polished_blackstone
fill 404 96 646 405 98 646 minecraft:black_concrete
fill 405 96 604 406 107 604 minecraft:black_concrete
fill 405 96 605 407 96 605 minecraft:polished_blackstone
fill 407 96 604 408 97 604 minecraft:red_concrete
fill 407 96 645 409 96 645 minecraft:polished_blackstone
fill 409 96 605 411 96 605 minecraft:polished_blackstone
fill 410 96 646 411 97 646 minecraft:red_concrete
fill 411 96 645 413 96 645 minecraft:polished_blackstone
fill 412 96 646 413 107 646 minecraft:black_concrete
fill 413 96 605 415 96 605 minecraft:polished_blackstone
fill 413 96 625 413 96 627 minecraft:red_concrete
fill 414 96 625 415 97 625 minecraft:red_concrete
setblock 414 96 646 minecraft:red_concrete
fill 415 96 627 415 98 627 minecraft:red_concrete
fill 415 96 645 417 96 645 minecraft:polished_blackstone
fill 415 96 646 415 107 646 minecraft:black_concrete
setblock 416 96 604 minecraft:red_concrete
setblock 416 96 626 minecraft:red_concrete
fill 417 96 604 418 107 604 minecraft:black_concrete
fill 417 96 605 417 96 607 minecraft:polished_blackstone
fill 417 96 609 417 96 611 minecraft:polished_blackstone
fill 417 96 613 417 96 615 minecraft:polished_blackstone
fill 417 96 617 417 96 619 minecraft:polished_blackstone
fill 417 96 621 417 96 623 minecraft:polished_blackstone
fill 417 96 625 417 96 627 minecraft:polished_blackstone
fill 417 96 629 417 96 631 minecraft:polished_blackstone
fill 417 96 633 417 96 635 minecraft:polished_blackstone
fill 417 96 637 417 96 639 minecraft:polished_blackstone
fill 417 96 641 417 96 643 minecraft:polished_blackstone
fill 418 96 605 418 97 606 minecraft:red_concrete
fill 418 96 611 418 107 612 minecraft:black_concrete
fill 418 96 613 418 96 614 minecraft:red_concrete
fill 418 96 615 418 107 615 minecraft:black_concrete
fill 418 96 623 418 104 624 minecraft:black_concrete
fill 418 96 625 418 97 626 minecraft:red_concrete
fill 418 96 632 418 103 632 minecraft:black_concrete
fill 418 96 633 418 96 634 minecraft:red_concrete
fill 418 96 635 418 97 636 minecraft:black_concrete
fill 418 96 637 418 97 637 minecraft:red_concrete
fill 418 96 643 418 107 644 minecraft:black_concrete
fill 418 96 645 418 97 645 minecraft:red_concrete
setblock 376 97 605 minecraft:red_concrete
setblock 376 97 616 minecraft:red_concrete
fill 376 97 620 376 105 621 minecraft:black_concrete
setblock 376 97 637 minecraft:red_concrete
setblock 376 97 640 minecraft:red_concrete
fill 376 97 641 376 107 641 minecraft:black_concrete
setblock 378 97 646 minecraft:red_concrete
setblock 379 97 604 minecraft:red_concrete
fill 382 97 646 382 107 646 minecraft:black_concrete
fill 385 97 633 387 98 634 minecraft:magma_block
fill 387 97 624 387 97 626 minecraft:red_concrete
fill 388 97 626 389 99 626 minecraft:red_concrete
fill 395 97 604 396 105 604 minecraft:black_concrete
fill 398 97 646 399 97 646 minecraft:red_concrete
setblock 400 97 604 minecraft:red_concrete
setblock 402 97 646 minecraft:red_concrete
fill 403 97 646 403 107 646 minecraft:black_concrete
setblock 411 97 604 minecraft:red_concrete
fill 413 97 626 413 97 627 minecraft:red_concrete
fill 414 97 646 414 108 646 minecraft:black_concrete
fill 416 97 604 416 104 604 minecraft:black_concrete
fill 418 97 613 418 107 613 minecraft:black_concrete
setblock 418 97 614 minecraft:red_concrete
fill 418 97 617 418 97 618 minecraft:red_concrete
fill 418 97 633 418 107 634 minecraft:black_concrete
setblock 418 97 638 minecraft:red_concrete
fill 376 98 605 376 107 605 minecraft:black_concrete
fill 376 98 606 376 98 607 minecraft:red_concrete
fill 376 98 608 376 107 609 minecraft:black_concrete
fill 376 98 614 376 99 615 minecraft:red_concrete
fill 376 98 616 376 104 617 minecraft:black_concrete
setblock 376 98 618 minecraft:red_concrete
fill 376 98 626 376 99 627 minecraft:red_concrete
fill 376 98 628 376 105 629 minecraft:black_concrete
fill 376 98 635 376 99 635 minecraft:red_concrete
fill 376 98 637 376 107 637 minecraft:black_concrete
fill 376 98 638 376 98 639 minecraft:red_concrete
fill 376 98 640 376 107 640 minecraft:black_concrete
fill 376 98 646 377 99 646 minecraft:red_concrete
fill 377 98 604 378 98 604 minecraft:red_concrete
fill 378 98 646 379 104 646 minecraft:black_concrete
fill 379 98 604 379 107 604 minecraft:black_concrete
setblock 379 98 607 minecraft:light[level=12]
setblock 379 98 615 minecraft:light[level=12]
setblock 379 98 623 minecraft:light[level=12]
setblock 379 98 631 minecraft:light[level=12]
setblock 379 98 639 minecraft:light[level=12]
fill 381 98 604 381 99 604 minecraft:red_concrete
fill 387 98 604 388 104 604 minecraft:black_concrete
setblock 387 98 607 minecraft:light[level=12]
setblock 387 98 615 minecraft:light[level=12]
setblock 387 98 623 minecraft:light[level=12]
setblock 387 98 625 minecraft:red_concrete
setblock 387 98 631 minecraft:light[level=12]
setblock 387 98 639 minecraft:light[level=12]
fill 388 98 627 389 99 627 minecraft:red_concrete
fill 388 98 646 389 98 646 minecraft:red_concrete
fill 389 98 604 390 99 604 minecraft:red_concrete
fill 390 98 646 391 107 646 minecraft:black_concrete
setblock 395 98 607 minecraft:light[level=12]
setblock 395 98 615 minecraft:light[level=12]
setblock 395 98 623 minecraft:light[level=12]
setblock 395 98 631 minecraft:light[level=12]
setblock 395 98 639 minecraft:light[level=12]
fill 397 98 646 397 99 646 minecraft:red_concrete
setblock 398 98 604 minecraft:red_concrete
fill 398 98 646 399 107 646 minecraft:black_concrete
fill 399 98 604 400 107 604 minecraft:black_concrete
setblock 400 98 646 minecraft:red_concrete
fill 401 98 604 402 99 604 minecraft:red_concrete
fill 402 98 646 402 103 646 minecraft:black_concrete
setblock 403 98 607 minecraft:light[level=12]
setblock 403 98 615 minecraft:light[level=12]
setblock 403 98 623 minecraft:light[level=12]
setblock 403 98 631 minecraft:light[level=12]
setblock 403 98 639 minecraft:light[level=12]
fill 407 98 604 408 104 604 minecraft:black_concrete
fill 408 98 646 409 99 646 minecraft:red_concrete
fill 409 98 604 410 98 604 minecraft:red_concrete
fill 410 98 646 411 103 646 minecraft:black_concrete
fill 411 98 604 411 107 604 minecraft:black_concrete
setblock 411 98 607 minecraft:light[level=12]
setblock 411 98 615 minecraft:light[level=12]
setblock 411 98 623 minecraft:light[level=12]
setblock 411 98 631 minecraft:light[level=12]
setblock 411 98 639 minecraft:light[level=12]
setblock 413 98 626 minecraft:red_concrete
setblock 414 98 625 minecraft:red_concrete
setblock 416 98 646 minecraft:black_concrete
fill 417 98 646 417 99 646 minecraft:red_concrete
fill 418 98 605 418 107 606 minecraft:black_concrete
fill 418 98 607 418 99 608 minecraft:red_concrete
fill 418 98 614 418 105 614 minecraft:black_concrete
setblock 418 98 616 minecraft:red_concrete
fill 418 98 617 418 107 618 minecraft:black_concrete
fill 418 98 619 418 99 619 minecraft:red_concrete
fill 418 98 625 418 107 626 minecraft:black_concrete
fill 418 98 627 418 98 628 minecraft:red_concrete
fill 418 98 635 418 107 635 minecraft:black_concrete
setblock 418 98 636 minecraft:red_concrete
fill 418 98 637 418 105 638 minecraft:black_concrete
fill 418 98 639 418 99 640 minecraft:red_concrete
fill 418 98 645 418 107 645 minecraft:black_concrete
setblock 376 99 606 minecraft:red_concrete
fill 376 99 607 376 107 607 minecraft:black_concrete
fill 376 99 618 376 107 618 minecraft:black_concrete
setblock 376 99 623 minecraft:red_concrete
setblock 376 99 634 minecraft:red_concrete
fill 376 99 638 376 107 639 minecraft:black_concrete
fill 377 99 604 378 105 604 minecraft:black_concrete
setblock 382 99 604 minecraft:red_concrete
setblock 385 99 646 minecraft:red_concrete
setblock 388 99 646 minecraft:red_concrete
fill 389 99 646 389 107 646 minecraft:black_concrete
setblock 393 99 604 minecraft:red_concrete
setblock 396 99 646 minecraft:red_concrete
fill 398 99 604 398 107 604 minecraft:black_concrete
fill 400 99 646 400 108 646 minecraft:black_concrete
fill 404 99 646 404 103 646 minecraft:black_concrete
setblock 405 99 646 minecraft:red_concrete
fill 409 99 604 409 104 604 minecraft:black_concrete
setblock 410 99 604 minecraft:red_concrete
fill 413 99 604 414 99 604 minecraft:red_concrete
setblock 416 99 646 minecraft:red_concrete
fill 418 99 616 418 107 616 minecraft:black_concrete
setblock 418 99 620 minecraft:red_concrete
fill 418 99 627 418 107 627 minecraft:black_concrete
setblock 418 99 628 minecraft:red_concrete
setblock 418 99 631 minecraft:red_concrete
fill 418 99 636 418 107 636 minecraft:black_concrete
fill 376 100 606 376 107 606 minecraft:black_concrete
fill 376 100 614 376 107 615 minecraft:black_concrete
fill 376 100 623 376 107 623 minecraft:black_concrete
fill 376 100 626 376 105 627 minecraft:black_concrete
fill 376 100 634 376 107 635 minecraft:black_concrete
fill 376 100 646 377 103 646 minecraft:black_concrete
fill 381 100 604 382 103 604 minecraft:black_concrete
fill 385 100 646 385 107 646 minecraft:black_concrete
fill 388 100 646 388 103 646 minecraft:black_concrete
fill 389 100 604 390 104 604 minecraft:black_concrete
fill 393 100 604 393 107 604 minecraft:black_concrete
fill 396 100 646 397 107 646 minecraft:black_concrete
fill 401 100 604 402 107 604 minecraft:black_concrete
fill 405 100 646 405 103 646 minecraft:black_concrete
fill 408 100 646 409 107 646 minecraft:black_concrete
fill 410 100 604 410 105 604 minecraft:black_concrete
fill 413 100 604 414 104 604 minecraft:black_concrete
fill 416 100 646 417 107 646 minecraft:black_concrete
fill 418 100 607 418 105 608 minecraft:black_concrete
fill 418 100 619 418 104 620 minecraft:black_concrete
fill 418 100 628 418 107 628 minecraft:black_concrete
fill 418 100 631 418 107 631 minecraft:black_concrete
fill 418 100 639 418 107 640 minecraft:black_concrete
fill 376 104 632 376 107 632 minecraft:black_concrete
setblock 376 104 633 minecraft:purple_terracotta
setblock 376 104 642 minecraft:black_concrete
setblock 376 104 643 minecraft:purple_terracotta
fill 376 104 644 376 105 644 minecraft:black_concrete
fill 376 104 645 376 104 646 minecraft:purple_terracotta
fill 377 104 646 377 107 646 minecraft:black_concrete
fill 381 104 604 381 107 604 minecraft:black_concrete
setblock 382 104 604 minecraft:purple_terracotta
setblock 383 104 646 minecraft:purple_terracotta
setblock 386 104 646 minecraft:purple_terracotta
fill 387 104 646 387 108 646 minecraft:black_concrete
setblock 388 104 646 minecraft:purple_terracotta
fill 394 104 624 396 104 626 minecraft:redstone_block
fill 399 104 619 401 104 621 minecraft:redstone_block
fill 399 104 629 401 104 631 minecraft:redstone_block
setblock 402 104 646 minecraft:purple_terracotta
setblock 403 104 604 minecraft:purple_terracotta
fill 404 104 604 404 108 604 minecraft:black_concrete
fill 404 104 624 406 104 626 minecraft:redstone_block
fill 404 104 646 405 104 646 minecraft:purple_terracotta
fill 410 104 646 410 107 646 minecraft:black_concrete
setblock 411 104 646 minecraft:purple_terracotta
setblock 418 104 632 minecraft:purple_terracotta
setblock 418 104 646 minecraft:purple_terracotta
fill 376 105 616 376 107 616 minecraft:black_concrete
setblock 376 105 617 minecraft:purple_terracotta
setblock 376 105 630 minecraft:purple_terracotta
fill 376 105 631 376 107 631 minecraft:black_concrete
fill 376 105 633 376 107 633 minecraft:black_concrete
setblock 376 105 636 minecraft:purple_terracotta
setblock 376 105 642 minecraft:purple_terracotta
setblock 376 105 643 minecraft:black_concrete
fill 376 105 645 376 107 646 minecraft:black_concrete
fill 378 105 646 378 106 646 minecraft:purple_terracotta
fill 379 105 646 379 107 646 minecraft:black_concrete
fill 382 105 604 382 107 604 minecraft:black_concrete
fill 383 105 646 383 108 646 minecraft:black_concrete
fill 385 105 604 386 105 604 minecraft:purple_terracotta
fill 386 105 646 386 107 646 minecraft:black_concrete
fill 387 105 604 387 107 604 minecraft:black_concrete
fill 388 105 604 389 105 604 minecraft:purple_terracotta
fill 388 105 646 388 107 646 minecraft:black_concrete
fill 390 105 604 390 107 604 minecraft:black_concrete
fill 395 105 622 396 105 623 minecraft:netherite_block
fill 395 105 627 396 105 628 minecraft:netherite_block
fill 396 105 621 398 105 621 minecraft:netherite_block
fill 396 105 629 398 105 629 minecraft:netherite_block
fill 397 105 620 398 105 620 minecraft:netherite_block
fill 397 105 622 397 106 622 minecraft:netherite_block
fill 397 105 623 398 105 627 minecraft:black_concrete
fill 397 105 628 397 106 628 minecraft:netherite_block
fill 397 105 630 398 105 630 minecraft:netherite_block
fill 398 105 622 402 105 622 minecraft:black_concrete
fill 398 105 628 402 105 628 minecraft:black_concrete
fill 399 105 623 403 105 623 minecraft:black_concrete
fill 399 105 627 403 105 627 minecraft:black_concrete
fill 402 105 620 403 105 621 minecraft:netherite_block
fill 402 105 624 403 105 626 minecraft:black_concrete
fill 402 105 629 403 105 630 minecraft:netherite_block
fill 402 105 646 402 107 646 minecraft:black_concrete
fill 403 105 604 403 107 604 minecraft:black_concrete
fill 403 105 622 405 106 622 minecraft:netherite_block
fill 403 105 628 405 105 628 minecraft:netherite_block
fill 404 105 621 404 106 621 minecraft:netherite_block
fill 404 105 623 405 105 623 minecraft:netherite_block
fill 404 105 627 405 105 627 minecraft:netherite_block
fill 404 105 629 404 106 629 minecraft:netherite_block
fill 404 105 646 404 107 646 minecraft:black_concrete
setblock 405 105 646 minecraft:purple_terracotta
fill 406 105 646 406 107 646 minecraft:black_concrete
fill 407 105 604 407 107 604 minecraft:black_concrete
setblock 407 105 646 minecraft:purple_terracotta
fill 408 105 604 409 105 604 minecraft:purple_terracotta
setblock 411 105 646 minecraft:black_concrete
fill 413 105 604 413 107 604 minecraft:black_concrete
fill 414 105 604 414 106 604 minecraft:purple_terracotta
setblock 416 105 604 minecraft:purple_terracotta
fill 418 105 619 418 107 619 minecraft:black_concrete
fill 418 105 620 418 106 620 minecraft:purple_terracotta
fill 418 105 623 418 107 623 minecraft:black_concrete
setblock 418 105 624 minecraft:purple_terracotta
setblock 418 105 632 minecraft:black_concrete
setblock 418 105 646 minecraft:black_concrete
setblock 376 106 610 minecraft:purple_terracotta
fill 376 106 611 417 106 611 minecraft:black_concrete
fill 376 106 617 417 106 617 minecraft:black_concrete
setblock 376 106 620 minecraft:purple_terracotta
fill 376 106 621 395 106 621 minecraft:black_concrete
fill 376 106 624 392 106 624 minecraft:black_concrete
setblock 376 106 625 minecraft:purple_terracotta
fill 376 106 626 392 106 626 minecraft:black_concrete
fill 376 106 627 376 106 628 minecraft:purple_terracotta
fill 376 106 629 395 106 630 minecraft:black_concrete
fill 376 106 636 417 106 636 minecraft:black_concrete
fill 376 106 642 418 106 642 minecraft:black_concrete
fill 376 106 643 376 106 644 minecraft:purple_terracotta
fill 377 106 604 377 106 610 minecraft:black_concrete
fill 377 106 612 417 106 616 minecraft:black_concrete
fill 377 106 618 396 106 620 minecraft:black_concrete
fill 377 106 622 392 106 623 minecraft:black_concrete
fill 377 106 625 392 106 625 minecraft:black_concrete
fill 377 106 627 392 106 628 minecraft:black_concrete
fill 377 106 631 397 106 635 minecraft:black_concrete
fill 377 106 637 417 106 641 minecraft:black_concrete
fill 377 106 643 417 106 645 minecraft:black_concrete
setblock 378 106 604 minecraft:purple_terracotta
fill 378 106 605 417 106 610 minecraft:black_concrete
fill 383 106 604 384 106 604 minecraft:purple_terracotta
setblock 384 106 646 minecraft:purple_terracotta
fill 385 106 604 385 107 604 minecraft:black_concrete
setblock 386 106 604 minecraft:purple_terracotta
fill 388 106 604 389 107 604 minecraft:black_concrete
fill 393 106 622 394 106 622 minecraft:black_concrete
fill 393 106 623 393 106 627 minecraft:shroomlight
fill 393 106 628 394 106 628 minecraft:black_concrete
fill 394 106 604 395 106 604 minecraft:purple_terracotta
fill 394 106 623 407 106 623 minecraft:shroomlight
fill 394 106 624 396 106 626 minecraft:black_concrete
fill 394 106 627 407 106 627 minecraft:shroomlight
fill 395 106 622 396 106 622 minecraft:netherite_block
setblock 395 106 628 minecraft:netherite_block
fill 396 106 604 396 107 604 minecraft:black_concrete
fill 396 106 621 397 106 621 minecraft:netherite_block
setblock 396 106 628 minecraft:shroomlight
fill 396 106 629 397 106 629 minecraft:netherite_block
setblock 396 106 630 minecraft:black_concrete
setblock 397 106 604 minecraft:purple_terracotta
fill 397 106 618 397 106 619 minecraft:black_concrete
setblock 397 106 620 minecraft:netherite_block
fill 397 106 624 398 106 626 minecraft:shroomlight
setblock 397 106 630 minecraft:netherite_block
fill 398 106 618 398 106 622 minecraft:shroomlight
fill 398 106 628 398 106 632 minecraft:shroomlight
fill 398 106 633 417 106 635 minecraft:black_concrete
fill 399 106 618 402 106 618 minecraft:shroomlight
fill 399 106 619 401 106 621 minecraft:black_concrete
fill 399 106 622 402 106 622 minecraft:shroomlight
fill 399 106 628 402 106 628 minecraft:shroomlight
fill 399 106 629 401 106 631 minecraft:black_concrete
fill 399 106 632 402 106 632 minecraft:shroomlight
fill 402 106 619 402 106 621 minecraft:shroomlight
fill 402 106 624 403 106 626 minecraft:shroomlight
fill 402 106 629 402 106 631 minecraft:shroomlight
fill 403 106 618 417 106 619 minecraft:black_concrete
setblock 403 106 620 minecraft:netherite_block
setblock 403 106 621 minecraft:shroomlight
setblock 403 106 628 minecraft:netherite_block
setblock 403 106 629 minecraft:shroomlight
setblock 403 106 630 minecraft:netherite_block
fill 403 106 631 417 106 632 minecraft:black_concrete
fill 404 106 620 417 106 620 minecraft:black_concrete
fill 404 106 624 406 106 626 minecraft:black_concrete
setblock 404 106 628 minecraft:shroomlight
fill 404 106 630 417 106 630 minecraft:black_concrete
fill 405 106 621 417 106 621 minecraft:black_concrete
setblock 405 106 628 minecraft:netherite_block
fill 405 106 629 417 106 629 minecraft:black_concrete
fill 405 106 646 405 108 646 minecraft:black_concrete
fill 406 106 622 417 106 622 minecraft:black_concrete
fill 406 106 628 417 106 628 minecraft:black_concrete
fill 407 106 624 407 106 626 minecraft:shroomlight
fill 407 106 646 407 107 646 minecraft:black_concrete
fill 408 106 604 409 107 604 minecraft:black_concrete
fill 408 106 623 417 106 627 minecraft:black_concrete
setblock 410 106 604 minecraft:purple_terracotta
setblock 411 106 646 minecraft:purple_terracotta
fill 416 106 604 416 107 604 minecraft:black_concrete
fill 418 106 607 418 107 607 minecraft:black_concrete
fill 418 106 608 418 106 609 minecraft:purple_terracotta
fill 418 106 610 418 109 610 minecraft:black_concrete
setblock 418 106 614 minecraft:purple_terracotta
fill 418 106 624 418 107 624 minecraft:black_concrete
setblock 418 106 632 minecraft:purple_terracotta
fill 418 106 637 418 107 637 minecraft:black_concrete
setblock 418 106 638 minecraft:purple_terracotta
setblock 418 106 641 minecraft:purple_terracotta
setblock 418 106 646 minecraft:purple_terracotta
fill 376 107 610 376 107 611 minecraft:black_concrete
setblock 376 107 617 minecraft:black_concrete
fill 376 107 620 376 107 621 minecraft:black_concrete
fill 376 107 624 376 107 630 minecraft:black_concrete
setblock 376 107 636 minecraft:black_concrete
fill 376 107 642 376 107 644 minecraft:black_concrete
fill 377 107 604 378 107 604 minecraft:black_concrete
setblock 378 107 646 minecraft:black_concrete
fill 383 107 604 384 107 604 minecraft:black_concrete
setblock 384 107 646 minecraft:black_concrete
setblock 386 107 604 minecraft:black_concrete
fill 394 107 604 395 107 604 minecraft:black_concrete
fill 394 107 620 396 110 620 minecraft:netherite_block
fill 394 107 630 396 110 630 minecraft:netherite_block
fill 395 107 619 395 110 619 minecraft:netherite_block
fill 395 107 621 395 110 621 minecraft:netherite_block
fill 395 107 629 395 110 629 minecraft:netherite_block
fill 395 107 631 395 110 631 minecraft:netherite_block
setblock 397 107 604 minecraft:black_concrete
fill 404 107 620 406 110 620 minecraft:netherite_block
fill 404 107 630 406 110 630 minecraft:netherite_block
fill 405 107 619 405 110 619 minecraft:netherite_block
fill 405 107 621 405 110 621 minecraft:netherite_block
fill 405 107 629 405 110 629 minecraft:netherite_block
fill 405 107 631 405 110 631 minecraft:netherite_block
setblock 410 107 604 minecraft:black_concrete
setblock 411 107 646 minecraft:black_concrete
setblock 414 107 604 minecraft:black_concrete
fill 418 107 608 418 107 609 minecraft:black_concrete
setblock 418 107 614 minecraft:black_concrete
setblock 418 107 620 minecraft:black_concrete
setblock 418 107 632 minecraft:black_concrete
setblock 418 107 638 minecraft:black_concrete
fill 418 107 641 418 107 642 minecraft:black_concrete
fill 418 107 646 418 109 646 minecraft:black_concrete
fill 376 108 604 376 108 623 minecraft:purple_terracotta
setblock 376 108 624 minecraft:black_concrete
fill 376 108 625 376 111 625 minecraft:purple_terracotta
setblock 376 108 626 minecraft:black_concrete
fill 376 108 627 376 110 627 minecraft:purple_terracotta
fill 376 108 628 376 109 628 minecraft:black_concrete
fill 376 108 629 376 108 634 minecraft:purple_terracotta
setblock 376 108 635 minecraft:black_concrete
fill 376 108 636 376 108 646 minecraft:purple_terracotta
fill 377 108 604 379 109 604 minecraft:purple_terracotta
fill 377 108 646 382 108 646 minecraft:purple_terracotta
fill 381 108 604 391 108 604 minecraft:purple_terracotta
fill 384 108 646 386 109 646 minecraft:purple_terracotta
fill 388 108 646 399 109 646 minecraft:purple_terracotta
setblock 392 108 604 minecraft:black_concrete
fill 393 108 604 400 108 604 minecraft:purple_terracotta
setblock 401 108 604 minecraft:black_concrete
fill 401 108 646 404 109 646 minecraft:purple_terracotta
fill 402 108 604 403 112 604 minecraft:purple_terracotta
fill 405 108 604 418 108 604 minecraft:purple_terracotta
fill 406 108 646 413 108 646 minecraft:purple_terracotta
fill 415 108 646 416 113 646 minecraft:purple_terracotta
setblock 417 108 646 minecraft:black_concrete
fill 418 108 605 418 110 609 minecraft:purple_terracotta
fill 418 108 611 418 108 633 minecraft:purple_terracotta
setblock 418 108 634 minecraft:black_concrete
fill 418 108 635 418 108 645 minecraft:purple_terracotta
setblock 376 109 604 minecraft:purple_terracotta
setblock 376 109 605 minecraft:black_concrete
fill 376 109 606 376 109 613 minecraft:purple_terracotta
setblock 376 109 614 minecraft:black_concrete
fill 376 109 615 376 111 617 minecraft:purple_terracotta
setblock 376 109 618 minecraft:black_concrete
fill 376 109 619 376 109 622 minecraft:purple_terracotta
setblock 376 109 623 minecraft:black_concrete
fill 376 109 624 376 112 624 minecraft:purple_terracotta
fill 376 109 626 376 110 626 minecraft:purple_terracotta
fill 376 109 629 376 115 629 minecraft:purple_terracotta
setblock 376 109 630 minecraft:black_concrete
fill 376 109 631 376 109 638 minecraft:purple_terracotta
setblock 376 109 639 minecraft:black_concrete
fill 376 109 640 376 109 643 minecraft:purple_terracotta
fill 376 109 644 376 110 644 minecraft:black_concrete
fill 376 109 645 376 112 646 minecraft:purple_terracotta
fill 377 109 646 378 109 646 minecraft:purple_terracotta
setblock 379 109 646 minecraft:black_concrete
fill 380 109 604 383 111 604 minecraft:purple_terracotta
fill 380 109 646 383 109 646 minecraft:purple_terracotta
setblock 384 109 604 minecraft:black_concrete
fill 385 109 604 398 109 604 minecraft:purple_terracotta
fill 387 109 646 387 111 646 minecraft:purple_terracotta
setblock 399 109 604 minecraft:black_concrete
fill 400 109 604 401 111 604 minecraft:purple_terracotta
setblock 400 109 646 minecraft:purple_terracotta
fill 404 109 604 409 109 604 minecraft:purple_terracotta
fill 405 109 646 412 109 646 minecraft:purple_terracotta
fill 410 109 604 410 110 604 minecraft:black_concrete
fill 411 109 604 415 109 604 minecraft:purple_terracotta
setblock 413 109 646 minecraft:black_concrete
fill 414 109 646 414 115 646 minecraft:purple_terracotta
setblock 416 109 604 minecraft:black_concrete
fill 417 109 604 418 109 604 minecraft:purple_terracotta
setblock 417 109 646 minecraft:purple_terracotta
fill 418 109 611 418 113 611 minecraft:purple_terracotta
setblock 418 109 612 minecraft:black_concrete
fill 418 109 613 418 109 615 minecraft:purple_terracotta
setblock 418 109 616 minecraft:black_concrete
fill 418 109 617 418 111 620 minecraft:purple_terracotta
fill 418 109 621 418 110 621 minecraft:black_concrete
fill 418 109 622 418 109 640 minecraft:purple_terracotta
setblock 418 109 641 minecraft:black_concrete
fill 418 109 642 418 109 645 minecraft:purple_terracotta
setblock 376 110 604 minecraft:black_concrete
fill 376 110 605 376 111 605 minecraft:purple_terracotta
setblock 376 110 606 minecraft:black_concrete
fill 376 110 607 376 111 607 minecraft:red_concrete
fill 376 110 608 376 115 609 minecraft:purple_terracotta
setblock 376 110 610 minecraft:red_concrete
fill 376 110 611 376 112 614 minecraft:purple_terracotta
fill 376 110 618 376 111 619 minecraft:red_concrete
fill 376 110 620 376 113 623 minecraft:purple_terracotta
fill 376 110 628 376 111 628 minecraft:purple_terracotta
fill 376 110 630 376 110 631 minecraft:red_concrete
fill 376 110 632 376 111 637 minecraft:purple_terracotta
fill 376 110 638 376 111 639 minecraft:red_concrete
fill 376 110 640 376 115 641 minecraft:purple_terracotta
setblock 376 110 642 minecraft:red_concrete
fill 376 110 643 376 113 643 minecraft:purple_terracotta
fill 377 110 604 378 111 604 minecraft:red_concrete
setblock 377 110 646 minecraft:purple_terracotta
setblock 378 110 646 minecraft:black_concrete
fill 379 110 604 379 111 604 minecraft:purple_terracotta
fill 379 110 646 379 111 646 minecraft:purple_terracotta
fill 380 110 646 381 111 646 minecraft:red_concrete
fill 382 110 646 383 115 646 minecraft:purple_terracotta
fill 384 110 604 384 115 604 minecraft:purple_terracotta
setblock 384 110 646 minecraft:black_concrete
fill 385 110 604 386 110 604 minecraft:red_concrete
fill 385 110 646 386 111 646 minecraft:purple_terracotta
fill 387 110 604 396 110 604 minecraft:purple_terracotta
setblock 388 110 646 minecraft:purple_terracotta
fill 389 110 646 389 111 646 minecraft:red_concrete
fill 390 110 646 391 111 646 minecraft:purple_terracotta
fill 392 110 646 393 110 646 minecraft:red_concrete
fill 394 110 646 399 111 646 minecraft:purple_terracotta
fill 397 110 604 398 111 604 minecraft:red_concrete
fill 399 110 604 399 111 604 minecraft:purple_terracotta
fill 400 110 646 401 111 646 minecraft:red_concrete
fill 402 110 646 411 110 646 minecraft:purple_terracotta
fill 404 110 604 405 113 604 minecraft:purple_terracotta
setblock 406 110 604 minecraft:red_concrete
fill 407 110 604 407 115 604 minecraft:purple_terracotta
setblock 408 110 604 minecraft:black_concrete
fill 409 110 604 409 111 604 minecraft:red_concrete
fill 411 110 604 411 111 604 minecraft:purple_terracotta
setblock 412 110 604 minecraft:black_concrete
fill 412 110 646 413 110 646 minecraft:red_concrete
fill 413 110 604 416 113 604 minecraft:purple_terracotta
fill 417 110 604 418 110 604 minecraft:red_concrete
setblock 417 110 646 minecraft:black_concrete
fill 418 110 610 418 112 610 minecraft:purple_terracotta
fill 418 110 612 418 113 614 minecraft:purple_terracotta
fill 418 110 615 418 111 616 minecraft:red_concrete
fill 418 110 622 418 115 622 minecraft:purple_terracotta
fill 418 110 623 418 110 624 minecraft:red_concrete
fill 418 110 625 418 111 626 minecraft:purple_terracotta
fill 418 110 627 418 111 627 minecraft:red_concrete
fill 418 110 628 418 110 629 minecraft:purple_terracotta
setblock 418 110 630 minecraft:black_concrete
fill 418 110 631 418 113 634 minecraft:purple_terracotta
fill 418 110 635 418 111 636 minecraft:red_concrete
fill 418 110 637 418 110 643 minecraft:purple_terracotta
setblock 418 110 644 minecraft:red_concrete
fill 418 110 645 418 111 646 minecraft:purple_terracotta
setblock 376 111 604 minecraft:purple_terracotta
setblock 376 111 606 minecraft:red_concrete
fill 376 111 610 376 114 610 minecraft:purple_terracotta
fill 376 111 626 376 111 627 minecraft:red_concrete
setblock 376 111 630 minecraft:red_concrete
fill 376 111 631 376 114 631 minecraft:purple_terracotta
fill 376 111 642 376 114 642 minecraft:purple_terracotta
fill 376 111 644 376 112 644 minecraft:purple_terracotta
setblock 377 111 646 minecraft:red_concrete
setblock 378 111 646 minecraft:purple_terracotta
fill 384 111 646 384 113 646 minecraft:purple_terracotta
fill 385 111 604 385 114 604 minecraft:purple_terracotta
setblock 386 111 604 minecraft:red_concrete
fill 387 111 604 388 111 604 minecraft:purple_terracotta
setblock 388 111 646 minecraft:red_concrete
fill 389 111 604 390 111 604 minecraft:red_concrete
fill 391 111 604 396 111 604 minecraft:purple_terracotta
fill 392 111 646 393 113 646 minecraft:purple_terracotta
fill 402 111 646 407 111 646 minecraft:purple_terracotta
fill 406 111 604 406 114 604 minecraft:purple_terracotta
fill 408 111 604 408 115 604 minecraft:purple_terracotta
fill 408 111 646 409 111 646 minecraft:red_concrete
setblock 410 111 604 minecraft:red_concrete
fill 410 111 622 410 112 622 minecraft:crying_obsidian
fill 410 111 646 411 111 646 minecraft:purple_terracotta
setblock 412 111 604 minecraft:purple_terracotta
setblock 412 111 646 minecraft:red_concrete
fill 413 111 646 413 114 646 minecraft:purple_terracotta
fill 417 111 604 417 114 604 minecraft:purple_terracotta
fill 417 111 646 417 113 646 minecraft:purple_terracotta
setblock 418 111 604 minecraft:red_concrete
fill 418 111 605 418 111 606 minecraft:purple_terracotta
setblock 418 111 607 minecraft:red_concrete
fill 418 111 608 418 111 609 minecraft:purple_terracotta
fill 418 111 621 418 112 621 minecraft:purple_terracotta
fill 418 111 623 418 114 624 minecraft:purple_terracotta
setblock 418 111 628 minecraft:red_concrete
fill 418 111 629 418 111 630 minecraft:purple_terracotta
fill 418 111 637 418 111 638 minecraft:purple_terracotta
setblock 418 111 639 minecraft:red_concrete
fill 418 111 640 418 112 644 minecraft:purple_terracotta
fill 376 112 604 376 113 605 minecraft:red_concrete
fill 376 112 606 376 117 607 minecraft:purple_terracotta
fill 376 112 615 376 113 615 minecraft:purple_terracotta
fill 376 112 616 376 112 617 minecraft:red_concrete
fill 376 112 618 376 117 619 minecraft:purple_terracotta
fill 376 112 625 376 113 625 minecraft:red_concrete
fill 376 112 626 376 117 627 minecraft:purple_terracotta
setblock 376 112 628 minecraft:red_concrete
fill 376 112 630 376 117 630 minecraft:purple_terracotta
fill 376 112 632 376 113 635 minecraft:purple_terracotta
fill 376 112 636 376 113 637 minecraft:red_concrete
fill 376 112 638 376 117 639 minecraft:purple_terracotta
fill 377 112 604 378 117 604 minecraft:purple_terracotta
fill 377 112 646 377 117 646 minecraft:purple_terracotta
fill 378 112 646 379 112 646 minecraft:red_concrete
fill 379 112 604 380 113 604 minecraft:red_concrete
fill 380 112 646 381 114 646 minecraft:purple_terracotta
fill 381 112 604 383 113 604 minecraft:purple_terracotta
fill 385 112 646 385 113 646 minecraft:purple_terracotta
fill 386 112 604 387 115 604 minecraft:purple_terracotta
fill 386 112 646 387 113 646 minecraft:red_concrete
setblock 388 112 604 minecraft:red_concrete
fill 388 112 646 389 117 646 minecraft:purple_terracotta
fill 389 112 604 390 117 604 minecraft:purple_terracotta
setblock 390 112 646 minecraft:red_concrete
fill 391 112 604 391 113 604 minecraft:red_concrete
fill 391 112 646 391 115 646 minecraft:purple_terracotta
fill 392 112 604 398 112 604 minecraft:purple_terracotta
fill 394 112 646 397 112 646 minecraft:purple_terracotta
fill 398 112 646 399 113 646 minecraft:red_concrete
fill 399 112 604 400 112 604 minecraft:red_concrete
fill 400 112 646 406 112 646 minecraft:purple_terracotta
fill 401 112 604 401 113 604 minecraft:purple_terracotta
fill 407 112 646 407 113 646 minecraft:red_concrete
fill 408 112 646 409 113 646 minecraft:purple_terracotta
fill 409 112 604 410 117 604 minecraft:purple_terracotta
fill 410 112 620 410 112 621 minecraft:crying_obsidian
fill 410 112 646 411 112 646 minecraft:red_concrete
fill 411 112 604 412 113 604 minecraft:red_concrete
fill 412 112 646 412 117 646 minecraft:purple_terracotta
fill 418 112 604 418 117 604 minecraft:purple_terracotta
fill 418 112 605 418 112 606 minecraft:red_concrete
fill 418 112 607 418 113 608 minecraft:purple_terracotta
fill 418 112 609 418 113 609 minecraft:red_concrete
fill 418 112 615 418 117 616 minecraft:purple_terracotta
fill 418 112 617 418 113 618 minecraft:red_concrete
fill 418 112 619 418 113 620 minecraft:purple_terracotta
fill 418 112 625 418 115 625 minecraft:purple_terracotta
setblock 418 112 626 minecraft:red_concrete
fill 418 112 627 418 117 628 minecraft:purple_terracotta
fill 418 112 629 418 113 630 minecraft:red_concrete
fill 418 112 635 418 117 636 minecraft:purple_terracotta
fill 418 112 637 418 112 638 minecraft:red_concrete
fill 418 112 639 418 117 639 minecraft:purple_terracotta
fill 418 112 645 418 115 645 minecraft:purple_terracotta
fill 418 112 646 418 113 646 minecraft:red_concrete
fill 376 113 611 376 113 612 minecraft:purple_terracotta
setblock 376 113 613 minecraft:red_concrete
setblock 376 113 614 minecraft:purple_terracotta
setblock 376 113 616 minecraft:red_concrete
fill 376 113 617 376 116 617 minecraft:purple_terracotta
setblock 376 113 624 minecraft:red_concrete
fill 376 113 628 376 116 628 minecraft:purple_terracotta
fill 376 113 644 376 113 645 minecraft:red_concrete
setblock 376 113 646 minecraft:purple_terracotta
setblock 378 113 646 minecraft:red_concrete
fill 379 113 646 379 116 646 minecraft:purple_terracotta
fill 388 113 604 388 116 604 minecraft:purple_terracotta
fill 390 113 646 390 115 646 minecraft:purple_terracotta
setblock 392 113 604 minecraft:red_concrete
fill 393 113 604 399 113 604 minecraft:purple_terracotta
fill 394 113 646 394 115 646 minecraft:purple_terracotta
setblock 395 113 646 minecraft:red_concrete
fill 396 113 646 397 113 646 minecraft:purple_terracotta
setblock 400 113 604 minecraft:red_concrete
fill 400 113 646 405 113 646 minecraft:purple_terracotta
setblock 402 113 604 minecraft:purple_terracotta
setblock 403 113 604 minecraft:red_concrete
setblock 406 113 646 minecraft:red_concrete
fill 410 113 619 411 113 620 minecraft:crying_obsidian
fill 410 113 646 411 115 646 minecraft:purple_terracotta
fill 411 113 618 411 114 618 minecraft:crying_obsidian
fill 418 113 605 418 116 606 minecraft:purple_terracotta
setblock 418 113 610 minecraft:red_concrete
setblock 418 113 621 minecraft:red_concrete
fill 418 113 626 418 116 626 minecraft:purple_terracotta
fill 418 113 637 418 116 637 minecraft:purple_terracotta
setblock 418 113 638 minecraft:red_concrete
setblock 418 113 640 minecraft:purple_terracotta
fill 418 113 641 418 113 642 minecraft:red_concrete
fill 418 113 643 418 113 644 minecraft:purple_terracotta
fill 376 114 604 376 119 605 minecraft:purple_terracotta
fill 376 114 611 376 115 611 minecraft:red_concrete
fill 376 114 612 376 115 613 minecraft:purple_terracotta
fill 376 114 614 376 114 615 minecraft:red_concrete
fill 376 114 616 376 119 616 minecraft:purple_terracotta
fill 376 114 620 376 115 621 minecraft:purple_terracotta
fill 376 114 622 376 115 623 minecraft:red_concrete
fill 376 114 624 376 119 625 minecraft:purple_terracotta
fill 376 114 632 376 115 633 minecraft:purple_terracotta
fill 376 114 634 376 114 635 minecraft:red_concrete
fill 376 114 636 376 119 637 minecraft:purple_terracotta
fill 376 114 643 376 115 643 minecraft:red_concrete
fill 376 114 644 376 119 645 minecraft:purple_terracotta
setblock 376 114 646 minecraft:red_concrete
fill 377 114 605 379 114 605 minecraft:polished_blackstone
fill 377 114 607 377 114 609 minecraft:polished_blackstone
fill 377 114 611 377 114 613 minecraft:polished_blackstone
fill 377 114 615 377 114 617 minecraft:polished_blackstone
fill 377 114 619 377 114 621 minecraft:polished_blackstone
fill 377 114 623 377 114 625 minecraft:polished_blackstone
fill 377 114 627 377 114 629 minecraft:polished_blackstone
fill 377 114 631 377 114 633 minecraft:polished_blackstone
fill 377 114 635 377 114 637 minecraft:polished_blackstone
fill 377 114 639 377 114 641 minecraft:polished_blackstone
fill 377 114 643 377 114 645 minecraft:polished_blackstone
fill 378 114 646 378 116 646 minecraft:purple_terracotta
fill 379 114 604 380 119 604 minecraft:purple_terracotta
setblock 379 114 607 minecraft:light[level=12]
setblock 379 114 615 minecraft:light[level=12]
setblock 379 114 623 minecraft:light[level=12]
setblock 379 114 631 minecraft:light[level=12]
setblock 379 114 639 minecraft:light[level=12]
fill 379 114 645 381 114 645 minecraft:polished_blackstone
fill 381 114 604 382 114 604 minecraft:red_concrete
fill 381 114 605 383 114 605 minecraft:polished_blackstone
fill 383 114 604 383 115 604 minecraft:purple_terracotta
fill 383 114 645 385 114 645 minecraft:polished_blackstone
fill 384 114 646 385 115 646 minecraft:red_concrete
fill 385 114 605 387 114 605 minecraft:polished_blackstone
fill 386 114 646 387 119 646 minecraft:purple_terracotta
setblock 387 114 607 minecraft:light[level=12]
setblock 387 114 615 minecraft:light[level=12]
setblock 387 114 623 minecraft:light[level=12]
setblock 387 114 631 minecraft:light[level=12]
setblock 387 114 639 minecraft:light[level=12]
fill 387 114 645 389 114 645 minecraft:polished_blackstone
fill 389 114 605 391 114 605 minecraft:polished_blackstone
fill 391 114 604 392 119 604 minecraft:purple_terracotta
fill 391 114 645 393 114 645 minecraft:polished_blackstone
setblock 392 114 646 minecraft:purple_terracotta
fill 393 114 604 394 115 604 minecraft:red_concrete
fill 393 114 605 395 114 605 minecraft:polished_blackstone
fill 393 114 617 394 115 617 minecraft:magma_block
fill 393 114 646 393 115 646 minecraft:red_concrete
fill 395 114 604 400 115 604 minecraft:purple_terracotta
setblock 395 114 607 minecraft:light[level=12]
setblock 395 114 615 minecraft:light[level=12]
setblock 395 114 623 minecraft:light[level=12]
setblock 395 114 631 minecraft:light[level=12]
setblock 395 114 639 minecraft:light[level=12]
fill 395 114 645 397 114 645 minecraft:polished_blackstone
fill 395 114 646 395 119 646 minecraft:purple_terracotta
fill 396 114 646 397 114 646 minecraft:red_concrete
fill 397 114 605 399 114 605 minecraft:polished_blackstone
fill 398 114 646 403 115 646 minecraft:purple_terracotta
fill 399 114 645 401 114 645 minecraft:polished_blackstone
fill 401 114 604 402 114 604 minecraft:red_concrete
fill 401 114 605 403 114 605 minecraft:polished_blackstone
fill 403 114 604 404 115 604 minecraft:purple_terracotta
setblock 403 114 607 minecraft:light[level=12]
setblock 403 114 615 minecraft:light[level=12]
setblock 403 114 623 minecraft:light[level=12]
setblock 403 114 631 minecraft:light[level=12]
setblock 403 114 639 minecraft:light[level=12]
fill 403 114 645 405 114 645 minecraft:polished_blackstone
fill 404 114 646 405 115 646 minecraft:red_concrete
fill 405 114 604 405 115 604 minecraft:red_concrete
fill 405 114 605 407 114 605 minecraft:polished_blackstone
fill 406 114 646 407 119 646 minecraft:purple_terracotta
fill 407 114 645 409 114 645 minecraft:polished_blackstone
setblock 408 114 646 minecraft:red_concrete
fill 409 114 605 411 114 605 minecraft:polished_blackstone
fill 409 114 646 409 117 646 minecraft:purple_terracotta
fill 411 114 604 412 119 604 minecraft:purple_terracotta
setblock 411 114 607 minecraft:light[level=12]
setblock 411 114 615 minecraft:light[level=12]
fill 411 114 617 411 115 617 minecraft:crying_obsidian
setblock 411 114 619 minecraft:crying_obsidian
setblock 411 114 623 minecraft:light[level=12]
setblock 411 114 631 minecraft:light[level=12]
setblock 411 114 639 minecraft:light[level=12]
fill 411 114 645 413 114 645 minecraft:polished_blackstone
fill 413 114 604 414 115 604 minecraft:red_concrete
fill 413 114 605 415 114 605 minecraft:polished_blackstone
fill 415 114 604 416 115 604 minecraft:purple_terracotta
fill 415 114 645 417 114 645 minecraft:polished_blackstone
fill 415 114 646 415 115 646 minecraft:purple_terracotta
fill 416 114 646 417 114 646 minecraft:red_concrete
fill 417 114 605 417 114 607 minecraft:polished_blackstone
fill 417 114 609 417 114 611 minecraft:polished_blackstone
fill 417 114 613 417 114 615 minecraft:polished_blackstone
fill 417 114 617 417 114 619 minecraft:polished_blackstone
fill 417 114 621 417 114 623 minecraft:polished_blackstone
fill 417 114 625 417 114 627 minecraft:polished_blackstone
fill 417 114 629 417 114 631 minecraft:polished_blackstone
fill 417 114 633 417 114 635 minecraft:polished_blackstone
fill 417 114 637 417 114 639 minecraft:polished_blackstone
fill 417 114 641 417 114 643 minecraft:polished_blackstone
fill 418 114 607 418 117 607 minecraft:purple_terracotta
setblock 418 114 608 minecraft:red_concrete
fill 418 114 609 418 119 610 minecraft:purple_terracotta
fill 418 114 611 418 115 612 minecraft:red_concrete
schedule function dropper:buildpart/152_2 1t
