fill 150 280 526 150 280 528 minecraft:obsidian
setblock 150 280 529 minecraft:crying_obsidian
fill 150 280 530 150 280 532 minecraft:obsidian
setblock 150 280 533 minecraft:crying_obsidian
fill 150 280 534 151 280 534 minecraft:obsidian
setblock 150 280 536 minecraft:obsidian
setblock 150 280 537 minecraft:crying_obsidian
fill 150 280 538 151 280 539 minecraft:obsidian
setblock 150 280 541 minecraft:crying_obsidian
fill 150 280 542 182 280 546 minecraft:obsidian
fill 151 280 511 151 280 515 minecraft:obsidian
setblock 151 280 516 minecraft:crying_obsidian
fill 151 280 517 151 280 519 minecraft:obsidian
setblock 151 280 520 minecraft:crying_obsidian
setblock 151 280 521 minecraft:obsidian
setblock 151 280 524 minecraft:crying_obsidian
fill 151 280 525 151 280 527 minecraft:obsidian
setblock 151 280 528 minecraft:crying_obsidian
fill 151 280 529 151 280 531 minecraft:obsidian
setblock 151 280 532 minecraft:crying_obsidian
setblock 151 280 533 minecraft:obsidian
setblock 151 280 536 minecraft:crying_obsidian
setblock 151 280 537 minecraft:obsidian
setblock 151 280 540 minecraft:crying_obsidian
fill 151 280 541 153 280 541 minecraft:obsidian
fill 152 280 511 182 280 514 minecraft:obsidian
setblock 152 280 515 minecraft:crying_obsidian
fill 152 280 516 154 280 516 minecraft:obsidian
fill 152 280 517 159 280 539 minecraft:purple_stained_glass
fill 152 280 540 154 280 540 minecraft:obsidian
fill 153 280 515 155 280 515 minecraft:obsidian
setblock 154 280 541 minecraft:crying_obsidian
setblock 155 280 516 minecraft:crying_obsidian
setblock 155 280 540 minecraft:crying_obsidian
fill 155 280 541 157 280 541 minecraft:obsidian
setblock 156 280 515 minecraft:crying_obsidian
fill 156 280 516 158 280 516 minecraft:obsidian
fill 156 280 540 158 280 540 minecraft:obsidian
fill 157 280 515 159 280 515 minecraft:obsidian
setblock 158 280 541 minecraft:crying_obsidian
setblock 159 280 516 minecraft:crying_obsidian
setblock 159 280 540 minecraft:crying_obsidian
fill 159 280 541 161 280 541 minecraft:obsidian
setblock 160 280 515 minecraft:crying_obsidian
fill 160 280 516 162 280 516 minecraft:obsidian
fill 160 280 517 160 280 526 minecraft:purple_stained_glass
fill 160 280 527 160 280 529 minecraft:crying_obsidian
fill 160 280 530 160 280 539 minecraft:purple_stained_glass
fill 160 280 540 162 280 540 minecraft:obsidian
fill 161 280 515 163 280 515 minecraft:obsidian
fill 161 280 517 161 280 525 minecraft:purple_stained_glass
fill 161 280 526 161 280 527 minecraft:crying_obsidian
fill 161 280 529 161 280 530 minecraft:crying_obsidian
fill 161 280 531 161 280 539 minecraft:purple_stained_glass
fill 161 280 552 161 301 552 minecraft:obsidian
fill 162 280 517 174 280 524 minecraft:purple_stained_glass
fill 162 280 525 162 280 526 minecraft:crying_obsidian
fill 162 280 530 162 280 531 minecraft:crying_obsidian
fill 162 280 532 174 280 539 minecraft:purple_stained_glass
setblock 162 280 541 minecraft:crying_obsidian
setblock 163 280 516 minecraft:crying_obsidian
fill 163 280 525 164 280 525 minecraft:crying_obsidian
fill 163 280 531 164 280 531 minecraft:crying_obsidian
setblock 163 280 540 minecraft:crying_obsidian
fill 163 280 541 165 280 541 minecraft:obsidian
setblock 164 280 515 minecraft:crying_obsidian
fill 164 280 516 166 280 516 minecraft:obsidian
fill 164 280 526 165 280 526 minecraft:crying_obsidian
fill 164 280 530 165 280 530 minecraft:crying_obsidian
fill 164 280 540 166 280 540 minecraft:obsidian
fill 165 280 515 167 280 515 minecraft:obsidian
fill 165 280 525 174 280 525 minecraft:purple_stained_glass
fill 165 280 527 166 280 527 minecraft:crying_obsidian
fill 165 280 529 166 280 529 minecraft:crying_obsidian
fill 165 280 531 174 280 531 minecraft:purple_stained_glass
fill 166 280 526 174 280 526 minecraft:purple_stained_glass
setblock 166 280 528 minecraft:crying_obsidian
fill 166 280 530 174 280 530 minecraft:purple_stained_glass
setblock 166 280 541 minecraft:crying_obsidian
setblock 167 280 516 minecraft:crying_obsidian
fill 167 280 527 174 280 529 minecraft:purple_stained_glass
setblock 167 280 540 minecraft:crying_obsidian
fill 167 280 541 169 280 541 minecraft:obsidian
setblock 168 280 515 minecraft:crying_obsidian
fill 168 280 516 170 280 516 minecraft:obsidian
fill 168 280 540 170 280 540 minecraft:obsidian
fill 169 280 515 171 280 515 minecraft:obsidian
setblock 170 280 541 minecraft:crying_obsidian
setblock 171 280 516 minecraft:crying_obsidian
setblock 171 280 540 minecraft:crying_obsidian
fill 171 280 541 173 280 541 minecraft:obsidian
setblock 172 280 515 minecraft:crying_obsidian
fill 172 280 516 174 280 516 minecraft:obsidian
fill 172 280 540 174 280 540 minecraft:obsidian
fill 173 280 515 175 280 515 minecraft:obsidian
setblock 174 280 541 minecraft:crying_obsidian
setblock 175 280 516 minecraft:crying_obsidian
fill 175 280 517 175 280 519 minecraft:obsidian
setblock 175 280 520 minecraft:crying_obsidian
fill 175 280 521 175 280 523 minecraft:obsidian
setblock 175 280 524 minecraft:crying_obsidian
fill 175 280 525 175 280 527 minecraft:obsidian
setblock 175 280 528 minecraft:crying_obsidian
fill 175 280 529 175 280 531 minecraft:obsidian
setblock 175 280 532 minecraft:crying_obsidian
fill 175 280 533 175 280 535 minecraft:obsidian
setblock 175 280 536 minecraft:crying_obsidian
fill 175 280 537 175 280 539 minecraft:obsidian
setblock 175 280 540 minecraft:crying_obsidian
fill 175 280 541 182 280 541 minecraft:obsidian
setblock 176 280 515 minecraft:crying_obsidian
fill 176 280 516 182 280 518 minecraft:obsidian
setblock 176 280 519 minecraft:crying_obsidian
fill 176 280 520 182 280 522 minecraft:obsidian
setblock 176 280 523 minecraft:crying_obsidian
fill 176 280 524 182 280 526 minecraft:obsidian
setblock 176 280 527 minecraft:crying_obsidian
fill 176 280 528 182 280 530 minecraft:obsidian
setblock 176 280 531 minecraft:crying_obsidian
fill 176 280 532 182 280 534 minecraft:obsidian
setblock 176 280 535 minecraft:crying_obsidian
fill 176 280 536 182 280 538 minecraft:obsidian
setblock 176 280 539 minecraft:crying_obsidian
fill 176 280 540 182 280 540 minecraft:obsidian
fill 177 280 515 182 280 515 minecraft:obsidian
fill 177 280 519 182 280 519 minecraft:obsidian
fill 177 280 523 182 280 523 minecraft:obsidian
fill 177 280 527 182 280 527 minecraft:obsidian
fill 177 280 531 182 280 531 minecraft:obsidian
fill 177 280 535 182 280 535 minecraft:obsidian
fill 177 280 539 182 280 539 minecraft:obsidian
setblock 183 280 526 minecraft:crying_obsidian
fill 141 281 523 141 307 523 minecraft:obsidian
fill 141 281 527 141 304 527 minecraft:obsidian
setblock 141 281 530 minecraft:crying_obsidian
fill 141 281 535 141 307 535 minecraft:obsidian
fill 141 281 540 141 307 540 minecraft:obsidian
setblock 141 281 543 minecraft:amethyst_block
fill 141 281 547 141 307 547 minecraft:obsidian
setblock 142 281 552 minecraft:crying_obsidian
fill 150 281 516 152 284 516 minecraft:obsidian
fill 150 281 540 152 284 540 minecraft:obsidian
fill 151 281 515 151 284 515 minecraft:obsidian
fill 151 281 517 151 284 517 minecraft:obsidian
fill 151 281 539 151 284 539 minecraft:obsidian
fill 151 281 541 151 284 541 minecraft:obsidian
setblock 168 281 510 minecraft:crying_obsidian
setblock 170 281 510 minecraft:crying_obsidian
setblock 172 281 552 minecraft:crying_obsidian
fill 174 281 516 176 284 516 minecraft:obsidian
fill 174 281 540 176 284 540 minecraft:obsidian
fill 175 281 515 175 284 515 minecraft:obsidian
fill 175 281 517 175 284 517 minecraft:obsidian
fill 175 281 539 175 284 539 minecraft:obsidian
fill 175 281 541 175 284 541 minecraft:obsidian
fill 183 281 526 183 307 526 minecraft:obsidian
setblock 183 281 542 minecraft:amethyst_block
setblock 183 281 544 minecraft:crying_obsidian
setblock 141 282 516 minecraft:crying_obsidian
fill 141 282 530 141 307 530 minecraft:obsidian
fill 141 282 543 141 283 543 minecraft:obsidian
fill 142 282 552 142 295 552 minecraft:obsidian
setblock 144 282 513 minecraft:light[level=12]
setblock 144 282 521 minecraft:light[level=12]
setblock 144 282 529 minecraft:light[level=12]
setblock 144 282 537 minecraft:light[level=12]
setblock 144 282 545 minecraft:light[level=12]
setblock 152 282 513 minecraft:light[level=12]
setblock 152 282 521 minecraft:light[level=12]
setblock 152 282 529 minecraft:light[level=12]
setblock 152 282 537 minecraft:light[level=12]
setblock 152 282 545 minecraft:light[level=12]
setblock 160 282 513 minecraft:light[level=12]
setblock 160 282 521 minecraft:light[level=12]
setblock 160 282 529 minecraft:light[level=12]
setblock 160 282 537 minecraft:light[level=12]
setblock 160 282 545 minecraft:light[level=12]
fill 168 282 510 168 307 510 minecraft:obsidian
setblock 168 282 513 minecraft:light[level=12]
setblock 168 282 521 minecraft:light[level=12]
setblock 168 282 529 minecraft:light[level=12]
setblock 168 282 537 minecraft:light[level=12]
setblock 168 282 545 minecraft:light[level=12]
fill 170 282 510 170 307 510 minecraft:obsidian
fill 172 282 552 172 307 552 minecraft:obsidian
setblock 176 282 513 minecraft:light[level=12]
setblock 176 282 521 minecraft:light[level=12]
setblock 176 282 529 minecraft:light[level=12]
setblock 176 282 537 minecraft:light[level=12]
setblock 176 282 545 minecraft:light[level=12]
setblock 183 282 516 minecraft:white_concrete
fill 183 282 542 183 307 542 minecraft:obsidian
fill 183 282 544 183 287 544 minecraft:obsidian
fill 141 283 516 141 307 516 minecraft:obsidian
setblock 148 283 510 minecraft:white_concrete
setblock 149 283 510 minecraft:crying_obsidian
setblock 161 283 510 minecraft:white_concrete
fill 183 283 516 183 286 516 minecraft:obsidian
setblock 183 283 521 minecraft:amethyst_block
setblock 141 284 543 minecraft:crying_obsidian
fill 148 284 510 149 303 510 minecraft:obsidian
fill 161 284 510 161 287 510 minecraft:obsidian
setblock 172 284 543 minecraft:amethyst_block
fill 183 284 521 183 290 521 minecraft:obsidian
setblock 141 285 543 minecraft:white_concrete
setblock 162 285 552 minecraft:white_concrete
fill 172 285 543 172 291 543 minecraft:obsidian
setblock 141 286 517 minecraft:white_concrete
setblock 141 286 528 minecraft:crying_obsidian
fill 141 286 543 141 307 543 minecraft:obsidian
fill 162 286 552 162 307 552 minecraft:obsidian
fill 172 286 542 173 291 542 minecraft:obsidian
fill 173 286 543 173 291 543 minecraft:obsidian
setblock 174 286 552 minecraft:crying_obsidian
setblock 176 286 552 minecraft:amethyst_block
fill 177 286 525 182 288 525 minecraft:amethyst_block
fill 180 286 524 181 288 524 minecraft:amethyst_block
fill 180 286 526 181 288 526 minecraft:amethyst_block
setblock 183 286 533 minecraft:crying_obsidian
fill 141 287 517 141 307 517 minecraft:obsidian
fill 141 287 528 141 307 528 minecraft:obsidian
setblock 141 287 541 minecraft:crying_obsidian
setblock 150 287 552 minecraft:amethyst_block
fill 171 287 542 171 291 543 minecraft:obsidian
fill 172 287 544 172 291 544 minecraft:obsidian
fill 174 287 552 174 291 552 minecraft:obsidian
fill 175 287 525 176 287 525 minecraft:amethyst_block
fill 176 287 552 176 307 552 minecraft:obsidian
fill 177 287 524 179 287 524 minecraft:amethyst_block
fill 177 287 526 179 287 526 minecraft:amethyst_block
fill 182 287 524 182 288 524 minecraft:amethyst_block
fill 182 287 526 182 288 526 minecraft:amethyst_block
setblock 183 287 516 minecraft:white_concrete
fill 183 287 533 183 307 533 minecraft:obsidian
fill 141 288 518 141 290 518 minecraft:purple_stained_glass
fill 141 288 534 141 290 534 minecraft:purple_stained_glass
fill 141 288 541 141 307 541 minecraft:obsidian
setblock 141 288 549 minecraft:amethyst_block
fill 141 288 550 141 290 550 minecraft:purple_stained_glass
fill 145 288 510 145 290 510 minecraft:purple_stained_glass
fill 150 288 552 150 307 552 minecraft:obsidian
setblock 154 288 510 minecraft:amethyst_block
fill 155 288 552 155 290 552 minecraft:purple_stained_glass
fill 161 288 510 161 290 510 minecraft:purple_stained_glass
fill 171 288 544 171 291 544 minecraft:obsidian
fill 171 288 552 171 290 552 minecraft:purple_stained_glass
fill 172 288 541 173 291 541 minecraft:obsidian
fill 173 288 544 173 291 544 minecraft:obsidian
fill 174 288 542 174 291 543 minecraft:obsidian
fill 177 288 510 177 290 510 minecraft:purple_stained_glass
setblock 178 288 510 minecraft:amethyst_block
fill 178 288 524 179 288 524 minecraft:amethyst_block
fill 178 288 526 179 288 526 minecraft:amethyst_block
fill 183 288 516 183 295 516 minecraft:obsidian
fill 183 288 520 183 290 520 minecraft:purple_stained_glass
fill 183 288 536 183 290 536 minecraft:purple_stained_glass
setblock 183 288 544 minecraft:white_concrete
fill 141 289 549 141 307 549 minecraft:obsidian
setblock 148 289 552 minecraft:amethyst_block
fill 154 289 510 154 307 510 minecraft:obsidian
fill 170 289 542 170 291 543 minecraft:obsidian
fill 171 289 541 171 291 541 minecraft:obsidian
fill 172 289 545 172 291 545 minecraft:obsidian
fill 174 289 541 174 291 541 minecraft:obsidian
fill 174 289 544 174 291 544 minecraft:obsidian
fill 178 289 510 178 307 510 minecraft:obsidian
fill 180 289 525 182 289 525 minecraft:amethyst_block
setblock 181 289 524 minecraft:amethyst_block
setblock 181 289 526 minecraft:amethyst_block
setblock 183 289 544 minecraft:crying_obsidian
setblock 143 290 510 minecraft:amethyst_block
setblock 144 290 513 minecraft:light[level=12]
setblock 144 290 521 minecraft:light[level=12]
setblock 144 290 529 minecraft:light[level=12]
setblock 144 290 537 minecraft:light[level=12]
setblock 144 290 545 minecraft:light[level=12]
fill 148 290 552 148 293 552 minecraft:obsidian
setblock 152 290 513 minecraft:light[level=12]
setblock 152 290 521 minecraft:light[level=12]
setblock 152 290 529 minecraft:light[level=12]
setblock 152 290 537 minecraft:light[level=12]
setblock 152 290 545 minecraft:light[level=12]
setblock 160 290 513 minecraft:light[level=12]
setblock 160 290 521 minecraft:light[level=12]
setblock 160 290 529 minecraft:light[level=12]
setblock 160 290 537 minecraft:light[level=12]
setblock 160 290 545 minecraft:light[level=12]
setblock 168 290 513 minecraft:light[level=12]
setblock 168 290 521 minecraft:light[level=12]
setblock 168 290 529 minecraft:light[level=12]
setblock 168 290 537 minecraft:light[level=12]
setblock 168 290 545 minecraft:light[level=12]
fill 170 290 541 170 291 541 minecraft:obsidian
fill 170 290 544 170 291 544 minecraft:obsidian
fill 171 290 545 171 291 545 minecraft:obsidian
fill 172 290 540 173 291 540 minecraft:obsidian
fill 173 290 545 173 291 545 minecraft:obsidian
fill 175 290 542 175 291 543 minecraft:obsidian
setblock 176 290 513 minecraft:light[level=12]
setblock 176 290 521 minecraft:light[level=12]
setblock 176 290 529 minecraft:light[level=12]
setblock 176 290 537 minecraft:light[level=12]
setblock 176 290 545 minecraft:light[level=12]
fill 183 290 544 183 296 544 minecraft:obsidian
fill 141 291 518 141 296 518 minecraft:obsidian
fill 141 291 534 141 296 534 minecraft:obsidian
setblock 141 291 544 minecraft:white_concrete
fill 141 291 550 141 296 550 minecraft:obsidian
fill 143 291 510 143 307 510 minecraft:obsidian
fill 145 291 510 145 296 510 minecraft:obsidian
fill 155 291 552 155 296 552 minecraft:obsidian
setblock 159 291 552 minecraft:amethyst_block
fill 161 291 510 161 296 510 minecraft:obsidian
fill 169 291 542 169 291 543 minecraft:obsidian
setblock 170 291 545 minecraft:obsidian
setblock 171 291 540 minecraft:obsidian
fill 171 291 552 171 296 552 minecraft:obsidian
setblock 174 291 540 minecraft:obsidian
setblock 174 291 545 minecraft:obsidian
setblock 175 291 541 minecraft:obsidian
setblock 175 291 544 minecraft:obsidian
fill 177 291 510 177 296 510 minecraft:obsidian
fill 183 291 520 183 294 520 minecraft:obsidian
setblock 183 291 521 minecraft:amethyst_block
fill 183 291 536 183 296 536 minecraft:obsidian
fill 141 292 544 141 307 544 minecraft:obsidian
setblock 154 292 552 minecraft:white_concrete
fill 155 292 519 156 293 519 minecraft:crying_obsidian
setblock 158 292 510 minecraft:amethyst_block
fill 159 292 552 159 307 552 minecraft:obsidian
setblock 164 292 552 minecraft:amethyst_block
setblock 165 292 510 minecraft:crying_obsidian
fill 171 292 543 173 292 543 minecraft:amethyst_block
fill 172 292 542 173 293 542 minecraft:amethyst_block
setblock 174 292 552 minecraft:crying_obsidian
setblock 183 292 521 minecraft:obsidian
setblock 183 292 527 minecraft:crying_obsidian
setblock 150 293 510 minecraft:amethyst_block
fill 154 293 552 154 305 552 minecraft:obsidian
fill 158 293 510 158 307 510 minecraft:obsidian
fill 162 293 510 162 300 510 minecraft:obsidian
setblock 163 293 510 minecraft:amethyst_block
fill 164 293 552 164 307 552 minecraft:obsidian
fill 165 293 510 165 307 510 minecraft:obsidian
setblock 167 293 552 minecraft:amethyst_block
fill 172 293 543 173 293 543 minecraft:amethyst_block
fill 174 293 552 174 307 552 minecraft:obsidian
setblock 183 293 521 minecraft:white_concrete
fill 183 293 527 183 295 527 minecraft:obsidian
setblock 148 294 552 minecraft:white_concrete
fill 150 294 510 150 307 510 minecraft:obsidian
fill 154 294 529 154 295 529 minecraft:obsidian
fill 163 294 510 163 307 510 minecraft:obsidian
setblock 165 294 552 minecraft:crying_obsidian
fill 167 294 552 167 307 552 minecraft:obsidian
fill 172 294 542 172 294 543 minecraft:amethyst_block
fill 183 294 521 183 307 521 minecraft:obsidian
fill 148 295 552 148 307 552 minecraft:obsidian
fill 165 295 552 165 301 552 minecraft:obsidian
fill 170 295 532 170 296 533 minecraft:obsidian
setblock 172 295 543 minecraft:amethyst_block
setblock 183 295 520 minecraft:white_concrete
setblock 142 296 552 minecraft:crying_obsidian
setblock 183 296 516 minecraft:crying_obsidian
setblock 183 296 520 minecraft:obsidian
setblock 183 296 527 minecraft:crying_obsidian
fill 141 297 518 141 299 518 minecraft:purple_stained_glass
fill 141 297 534 141 299 534 minecraft:purple_stained_glass
fill 141 297 550 141 299 550 minecraft:purple_stained_glass
fill 142 297 552 142 307 552 minecraft:obsidian
fill 145 297 510 145 299 510 minecraft:purple_stained_glass
fill 155 297 552 155 299 552 minecraft:purple_stained_glass
fill 161 297 510 161 299 510 minecraft:purple_stained_glass
fill 171 297 552 171 299 552 minecraft:purple_stained_glass
fill 177 297 510 177 299 510 minecraft:purple_stained_glass
setblock 183 297 511 minecraft:amethyst_block
fill 183 297 516 183 307 516 minecraft:obsidian
fill 183 297 520 183 299 520 minecraft:purple_stained_glass
setblock 183 297 524 minecraft:white_concrete
fill 183 297 527 183 307 527 minecraft:obsidian
setblock 183 297 531 minecraft:amethyst_block
fill 183 297 536 183 299 536 minecraft:purple_stained_glass
setblock 183 297 544 minecraft:white_concrete
setblock 141 298 515 minecraft:white_concrete
setblock 144 298 513 minecraft:light[level=12]
setblock 144 298 521 minecraft:light[level=12]
fill 144 298 527 145 299 535 minecraft:obsidian
setblock 144 298 537 minecraft:light[level=12]
setblock 144 298 545 minecraft:light[level=12]
fill 145 298 524 146 299 526 minecraft:obsidian
fill 145 298 536 146 299 538 minecraft:obsidian
fill 146 298 522 147 299 523 minecraft:obsidian
fill 146 298 539 147 299 540 minecraft:obsidian
fill 147 298 521 148 299 521 minecraft:obsidian
fill 147 298 524 147 299 524 minecraft:obsidian
fill 147 298 538 147 299 538 minecraft:obsidian
fill 147 298 541 148 299 541 minecraft:obsidian
fill 148 298 519 149 299 520 minecraft:obsidian
fill 148 298 522 148 299 522 minecraft:obsidian
fill 148 298 540 148 299 540 minecraft:obsidian
fill 148 298 542 149 299 543 minecraft:obsidian
fill 149 298 518 151 299 518 minecraft:obsidian
fill 149 298 544 151 299 544 minecraft:obsidian
fill 150 298 517 153 299 517 minecraft:obsidian
fill 150 298 519 150 299 519 minecraft:obsidian
fill 150 298 543 150 299 543 minecraft:obsidian
fill 150 298 545 153 299 545 minecraft:obsidian
setblock 152 298 513 minecraft:light[level=12]
fill 152 298 516 155 299 516 minecraft:obsidian
setblock 152 298 521 minecraft:light[level=12]
setblock 152 298 529 minecraft:light[level=12]
setblock 152 298 537 minecraft:light[level=12]
fill 152 298 546 155 299 546 minecraft:obsidian
fill 153 298 515 157 299 515 minecraft:obsidian
fill 153 298 547 157 299 547 minecraft:obsidian
fill 155 298 514 169 299 514 minecraft:obsidian
fill 155 298 548 169 299 548 minecraft:obsidian
fill 158 298 513 166 299 513 minecraft:obsidian
fill 158 298 549 166 299 549 minecraft:obsidian
setblock 160 298 521 minecraft:light[level=12]
setblock 160 298 529 minecraft:light[level=12]
setblock 160 298 537 minecraft:light[level=12]
setblock 160 298 545 minecraft:light[level=12]
fill 167 298 515 171 299 515 minecraft:obsidian
fill 167 298 547 171 299 547 minecraft:obsidian
setblock 168 298 513 minecraft:light[level=12]
setblock 168 298 521 minecraft:light[level=12]
setblock 168 298 529 minecraft:light[level=12]
setblock 168 298 537 minecraft:light[level=12]
setblock 168 298 545 minecraft:light[level=12]
fill 169 298 516 172 299 516 minecraft:obsidian
fill 169 298 546 172 299 546 minecraft:obsidian
fill 171 298 517 174 299 517 minecraft:obsidian
fill 171 298 545 174 299 545 minecraft:obsidian
fill 172 298 510 172 307 510 minecraft:obsidian
setblock 173 298 510 minecraft:crying_obsidian
fill 173 298 518 175 299 518 minecraft:obsidian
fill 173 298 544 175 299 544 minecraft:obsidian
fill 174 298 519 176 299 519 minecraft:obsidian
fill 174 298 543 176 299 543 minecraft:obsidian
fill 175 298 520 176 299 520 minecraft:obsidian
fill 175 298 542 176 299 542 minecraft:obsidian
setblock 176 298 513 minecraft:light[level=12]
fill 176 298 521 177 299 522 minecraft:obsidian
setblock 176 298 529 minecraft:light[level=12]
setblock 176 298 537 minecraft:light[level=12]
fill 176 298 540 177 299 541 minecraft:obsidian
setblock 176 298 545 minecraft:light[level=12]
fill 177 298 523 178 299 524 minecraft:obsidian
fill 177 298 538 178 299 539 minecraft:obsidian
fill 178 298 522 178 299 522 minecraft:obsidian
fill 178 298 525 179 299 526 minecraft:obsidian
fill 178 298 536 179 299 537 minecraft:obsidian
fill 178 298 540 178 299 540 minecraft:obsidian
fill 179 298 524 179 299 524 minecraft:obsidian
fill 179 298 527 180 299 535 minecraft:obsidian
fill 179 298 538 179 299 538 minecraft:obsidian
fill 180 298 520 182 300 520 minecraft:amethyst_block
fill 181 298 519 181 300 519 minecraft:amethyst_block
fill 181 298 521 181 300 521 minecraft:amethyst_block
fill 183 298 511 183 307 511 minecraft:obsidian
fill 183 298 524 183 307 524 minecraft:obsidian
fill 183 298 531 183 307 531 minecraft:obsidian
fill 183 298 544 183 301 544 minecraft:obsidian
fill 141 299 515 141 302 515 minecraft:obsidian
fill 173 299 510 173 307 510 minecraft:obsidian
fill 178 299 520 179 300 520 minecraft:amethyst_block
fill 179 299 519 180 300 519 minecraft:amethyst_block
fill 179 299 521 180 300 521 minecraft:amethyst_block
setblock 180 299 510 minecraft:white_concrete
fill 182 299 519 182 300 519 minecraft:amethyst_block
fill 182 299 521 182 300 521 minecraft:amethyst_block
fill 141 300 518 141 307 518 minecraft:obsidian
setblock 141 300 521 minecraft:white_concrete
fill 141 300 534 141 307 534 minecraft:obsidian
fill 141 300 550 141 307 550 minecraft:obsidian
fill 144 300 527 144 300 535 minecraft:crying_obsidian
fill 145 300 510 145 307 510 minecraft:obsidian
fill 145 300 524 145 300 526 minecraft:crying_obsidian
fill 145 300 536 145 300 538 minecraft:crying_obsidian
fill 146 300 522 146 300 523 minecraft:crying_obsidian
fill 146 300 539 146 300 540 minecraft:crying_obsidian
setblock 147 300 521 minecraft:crying_obsidian
setblock 147 300 541 minecraft:crying_obsidian
fill 148 300 519 148 300 520 minecraft:crying_obsidian
fill 148 300 542 148 300 543 minecraft:crying_obsidian
fill 149 300 518 149 300 519 minecraft:crying_obsidian
fill 149 300 543 149 300 544 minecraft:crying_obsidian
fill 150 300 517 150 300 518 minecraft:crying_obsidian
fill 150 300 544 150 300 545 minecraft:crying_obsidian
setblock 151 300 517 minecraft:crying_obsidian
setblock 151 300 545 minecraft:crying_obsidian
setblock 152 300 516 minecraft:crying_obsidian
setblock 152 300 546 minecraft:crying_obsidian
fill 153 300 515 154 300 515 minecraft:crying_obsidian
fill 153 300 547 154 300 547 minecraft:crying_obsidian
fill 155 300 514 157 300 514 minecraft:crying_obsidian
fill 155 300 548 157 300 548 minecraft:crying_obsidian
fill 155 300 552 155 307 552 minecraft:obsidian
fill 158 300 513 166 300 513 minecraft:crying_obsidian
fill 158 300 549 166 300 549 minecraft:crying_obsidian
fill 161 300 510 161 307 510 minecraft:obsidian
fill 167 300 514 169 300 514 minecraft:crying_obsidian
setblock 167 300 548 minecraft:crying_obsidian
fill 170 300 515 171 300 515 minecraft:crying_obsidian
fill 171 300 552 171 307 552 minecraft:obsidian
setblock 172 300 516 minecraft:crying_obsidian
fill 173 300 517 174 300 517 minecraft:crying_obsidian
fill 174 300 518 175 300 518 minecraft:crying_obsidian
fill 175 300 519 176 300 519 minecraft:crying_obsidian
setblock 176 300 520 minecraft:crying_obsidian
fill 177 300 510 177 305 510 minecraft:obsidian
setblock 177 300 520 minecraft:amethyst_block
setblock 177 300 521 minecraft:crying_obsidian
setblock 178 300 519 minecraft:amethyst_block
setblock 178 300 521 minecraft:amethyst_block
fill 178 300 522 178 300 523 minecraft:crying_obsidian
setblock 178 300 539 minecraft:crying_obsidian
fill 179 300 524 179 300 526 minecraft:crying_obsidian
fill 179 300 536 179 300 538 minecraft:crying_obsidian
fill 180 300 510 180 307 510 minecraft:obsidian
fill 180 300 527 180 300 535 minecraft:crying_obsidian
fill 183 300 520 183 307 520 minecraft:obsidian
setblock 183 300 534 minecraft:crying_obsidian
fill 183 300 535 183 307 536 minecraft:obsidian
fill 141 301 521 141 307 521 minecraft:obsidian
setblock 141 301 522 minecraft:amethyst_block
setblock 162 301 510 minecraft:white_concrete
setblock 183 301 517 minecraft:crying_obsidian
setblock 183 301 529 minecraft:amethyst_block
fill 183 301 534 183 307 534 minecraft:obsidian
setblock 183 301 545 minecraft:amethyst_block
setblock 183 301 547 minecraft:amethyst_block
fill 141 302 522 141 307 522 minecraft:obsidian
setblock 141 302 542 minecraft:amethyst_block
setblock 146 302 510 minecraft:amethyst_block
setblock 161 302 552 minecraft:white_concrete
fill 162 302 510 162 307 510 minecraft:obsidian
setblock 165 302 552 minecraft:amethyst_block
fill 183 302 517 183 304 517 minecraft:obsidian
fill 183 302 529 183 307 529 minecraft:obsidian
setblock 183 302 544 minecraft:amethyst_block
fill 183 302 545 183 307 545 minecraft:obsidian
fill 183 302 547 183 307 547 minecraft:obsidian
setblock 141 303 515 minecraft:crying_obsidian
setblock 141 303 529 minecraft:white_concrete
fill 141 303 542 141 307 542 minecraft:obsidian
fill 146 303 510 146 307 510 minecraft:obsidian
fill 161 303 552 161 307 552 minecraft:obsidian
fill 165 303 552 165 307 552 minecraft:obsidian
fill 183 303 544 183 307 544 minecraft:obsidian
fill 141 304 515 141 306 515 minecraft:obsidian
fill 141 304 529 141 307 529 minecraft:obsidian
setblock 148 304 510 minecraft:amethyst_block
fill 149 304 510 149 307 510 minecraft:obsidian
setblock 169 304 552 minecraft:amethyst_block
setblock 177 304 552 minecraft:white_concrete
setblock 183 304 539 minecraft:crying_obsidian
setblock 141 305 527 minecraft:amethyst_block
fill 148 305 510 148 307 510 minecraft:obsidian
setblock 151 305 552 minecraft:crying_obsidian
fill 169 305 552 169 307 552 minecraft:obsidian
fill 177 305 552 177 307 552 minecraft:obsidian
setblock 183 305 517 minecraft:crying_obsidian
fill 183 305 539 183 307 539 minecraft:obsidian
fill 141 306 527 141 307 527 minecraft:obsidian
setblock 141 306 546 minecraft:crying_obsidian
fill 151 306 552 151 307 552 minecraft:obsidian
setblock 154 306 552 minecraft:white_concrete
setblock 177 306 510 minecraft:amethyst_block
fill 183 306 517 183 307 517 minecraft:obsidian
setblock 141 307 515 minecraft:amethyst_block
setblock 141 307 546 minecraft:obsidian
setblock 154 307 552 minecraft:obsidian
setblock 177 307 510 minecraft:obsidian
setblock 183 307 518 minecraft:amethyst_block
