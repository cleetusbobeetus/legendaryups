fill 423 98 229 423 127 229 minecraft:black_concrete
setblock 423 98 230 minecraft:white_concrete
fill 423 98 247 423 196 247 minecraft:black_concrete
fill 423 98 265 423 119 265 minecraft:black_concrete
fill 426 98 270 426 112 270 minecraft:black_concrete
setblock 440 98 228 minecraft:pearlescent_froglight
setblock 445 98 270 minecraft:purple_concrete
fill 462 98 270 463 112 270 minecraft:black_concrete
fill 465 98 232 465 101 232 minecraft:black_concrete
fill 423 99 230 423 123 230 minecraft:black_concrete
setblock 423 99 235 minecraft:magenta_terracotta
setblock 439 99 228 minecraft:pearlescent_froglight
fill 440 99 228 440 123 228 minecraft:black_concrete
fill 445 99 270 445 165 270 minecraft:black_concrete
setblock 455 99 270 minecraft:white_concrete
setblock 465 99 239 minecraft:purple_concrete
setblock 465 99 263 minecraft:purple_terracotta
fill 423 100 235 423 111 235 minecraft:black_concrete
setblock 426 100 231 minecraft:light[level=15]
setblock 426 100 239 minecraft:light[level=15]
setblock 426 100 247 minecraft:light[level=15]
setblock 426 100 255 minecraft:light[level=15]
setblock 426 100 263 minecraft:light[level=15]
setblock 432 100 270 minecraft:sea_lantern
setblock 434 100 231 minecraft:light[level=15]
setblock 434 100 239 minecraft:light[level=15]
setblock 434 100 247 minecraft:light[level=15]
setblock 434 100 255 minecraft:light[level=15]
setblock 434 100 263 minecraft:light[level=15]
fill 439 100 228 439 107 228 minecraft:black_concrete
setblock 442 100 231 minecraft:light[level=15]
setblock 442 100 239 minecraft:light[level=15]
setblock 442 100 255 minecraft:light[level=15]
setblock 442 100 263 minecraft:light[level=15]
fill 446 100 238 446 120 238 minecraft:gray_concrete
setblock 450 100 231 minecraft:light[level=15]
setblock 450 100 239 minecraft:light[level=15]
setblock 450 100 247 minecraft:light[level=15]
setblock 450 100 255 minecraft:light[level=15]
setblock 450 100 263 minecraft:light[level=15]
setblock 451 100 228 minecraft:ochre_froglight
fill 455 100 270 455 123 270 minecraft:black_concrete
setblock 458 100 231 minecraft:light[level=15]
setblock 458 100 239 minecraft:light[level=15]
setblock 458 100 247 minecraft:light[level=15]
setblock 458 100 255 minecraft:light[level=15]
setblock 458 100 263 minecraft:light[level=15]
setblock 459 100 270 minecraft:ochre_froglight
setblock 460 100 270 minecraft:sea_lantern
fill 465 100 239 465 166 239 minecraft:black_concrete
setblock 465 100 253 minecraft:ochre_froglight
fill 465 100 263 465 126 263 minecraft:black_concrete
fill 432 101 270 432 206 270 minecraft:black_concrete
setblock 448 101 228 minecraft:pearlescent_froglight
fill 448 101 255 448 120 255 minecraft:gray_concrete
fill 451 101 228 451 165 228 minecraft:black_concrete
fill 459 101 270 460 128 270 minecraft:black_concrete
setblock 465 101 240 minecraft:purple_concrete
fill 465 101 253 465 116 253 minecraft:black_concrete
setblock 423 102 238 minecraft:pearlescent_froglight
setblock 426 102 231 minecraft:light[level=12]
setblock 426 102 238 minecraft:light[level=12]
setblock 426 102 245 minecraft:light[level=12]
setblock 426 102 252 minecraft:light[level=12]
setblock 426 102 259 minecraft:light[level=12]
setblock 426 102 266 minecraft:light[level=12]
setblock 433 102 231 minecraft:light[level=12]
setblock 433 102 238 minecraft:light[level=12]
setblock 433 102 245 minecraft:light[level=12]
setblock 433 102 252 minecraft:light[level=12]
setblock 433 102 259 minecraft:light[level=12]
setblock 433 102 266 minecraft:light[level=12]
setblock 434 102 228 minecraft:sea_lantern
setblock 440 102 231 minecraft:light[level=12]
setblock 440 102 238 minecraft:light[level=12]
setblock 440 102 245 minecraft:light[level=12]
setblock 440 102 252 minecraft:light[level=12]
setblock 440 102 259 minecraft:light[level=12]
setblock 440 102 266 minecraft:light[level=12]
setblock 447 102 231 minecraft:light[level=12]
setblock 447 102 245 minecraft:light[level=12]
setblock 447 102 252 minecraft:light[level=12]
setblock 447 102 259 minecraft:light[level=12]
setblock 447 102 266 minecraft:light[level=12]
fill 448 102 228 448 115 228 minecraft:black_concrete
setblock 454 102 231 minecraft:light[level=12]
setblock 454 102 238 minecraft:light[level=12]
setblock 454 102 245 minecraft:light[level=12]
setblock 454 102 252 minecraft:light[level=12]
setblock 454 102 259 minecraft:light[level=12]
setblock 454 102 266 minecraft:light[level=12]
setblock 461 102 231 minecraft:light[level=12]
setblock 461 102 238 minecraft:light[level=12]
setblock 461 102 245 minecraft:light[level=12]
setblock 461 102 252 minecraft:light[level=12]
setblock 461 102 259 minecraft:light[level=12]
setblock 461 102 266 minecraft:light[level=12]
setblock 465 102 232 minecraft:white_concrete
fill 465 102 240 465 148 240 minecraft:black_concrete
setblock 423 103 238 minecraft:black_concrete
setblock 423 103 256 minecraft:pearlescent_froglight
setblock 423 103 262 minecraft:pearlescent_froglight
fill 434 103 228 434 106 228 minecraft:black_concrete
setblock 446 103 228 minecraft:sea_lantern
fill 465 103 232 465 121 232 minecraft:black_concrete
setblock 465 103 247 minecraft:magenta_terracotta
setblock 465 103 248 minecraft:sea_lantern
setblock 465 103 254 minecraft:purple_concrete
setblock 423 104 238 minecraft:magenta_terracotta
fill 423 104 256 423 124 256 minecraft:black_concrete
fill 423 104 262 423 115 262 minecraft:black_concrete
setblock 423 104 266 minecraft:pearlescent_froglight
setblock 425 104 228 minecraft:pearlescent_froglight
setblock 433 104 270 minecraft:white_concrete
fill 434 104 270 434 166 270 minecraft:black_concrete
fill 443 104 231 447 105 235 minecraft:gray_concrete
fill 445 104 229 445 104 230 minecraft:gray_concrete
fill 446 104 228 446 144 228 minecraft:black_concrete
fill 447 104 255 447 120 255 minecraft:gray_concrete
fill 452 104 258 454 105 258 minecraft:end_stone
setblock 453 104 228 minecraft:sea_lantern
fill 453 104 257 453 105 257 minecraft:end_stone
fill 453 104 259 453 105 259 minecraft:end_stone
setblock 465 104 235 minecraft:white_concrete
fill 465 104 247 465 124 248 minecraft:black_concrete
setblock 465 104 250 minecraft:ochre_froglight
fill 465 104 254 465 120 254 minecraft:black_concrete
setblock 465 104 256 minecraft:pearlescent_froglight
setblock 465 104 258 minecraft:sea_lantern
setblock 423 105 234 minecraft:sea_lantern
fill 423 105 238 423 123 238 minecraft:black_concrete
setblock 423 105 250 minecraft:pearlescent_froglight
setblock 423 105 252 minecraft:blue_concrete
fill 423 105 266 423 265 266 minecraft:black_concrete
fill 425 105 228 425 179 228 minecraft:black_concrete
setblock 427 105 270 minecraft:pearlescent_froglight
fill 433 105 270 433 185 270 minecraft:black_concrete
fill 435 105 228 435 106 228 minecraft:ochre_froglight
setblock 436 105 228 minecraft:pearlescent_froglight
fill 442 105 233 442 106 233 minecraft:orange_concrete
fill 445 105 230 445 106 230 minecraft:orange_concrete
fill 445 105 236 445 106 236 minecraft:orange_concrete
fill 448 105 233 448 106 233 minecraft:orange_concrete
fill 453 105 228 453 182 228 minecraft:black_concrete
fill 456 105 228 456 144 228 minecraft:black_concrete
setblock 457 105 228 minecraft:white_concrete
fill 465 105 235 465 111 235 minecraft:black_concrete
fill 465 105 250 465 133 250 minecraft:black_concrete
fill 465 105 256 465 116 256 minecraft:black_concrete
fill 465 105 258 465 148 258 minecraft:black_concrete
fill 423 106 234 423 116 234 minecraft:black_concrete
setblock 423 106 250 minecraft:blue_concrete
fill 423 106 252 423 156 252 minecraft:black_concrete
fill 427 106 270 427 120 270 minecraft:black_concrete
setblock 429 106 228 minecraft:pearlescent_froglight
fill 432 106 232 434 106 234 minecraft:orange_concrete
fill 436 106 228 436 188 228 minecraft:black_concrete
fill 444 106 232 446 109 234 minecraft:light_gray_concrete
setblock 452 106 228 minecraft:ochre_froglight
fill 457 106 228 457 137 228 minecraft:black_concrete
setblock 465 106 261 minecraft:sea_lantern
setblock 423 107 236 minecraft:magenta_terracotta
fill 423 107 250 423 125 250 minecraft:black_concrete
setblock 426 107 228 minecraft:white_concrete
setblock 426 107 231 minecraft:light[level=15]
setblock 426 107 239 minecraft:light[level=15]
setblock 426 107 247 minecraft:light[level=15]
setblock 426 107 255 minecraft:light[level=15]
setblock 426 107 263 minecraft:light[level=15]
fill 429 107 228 429 127 228 minecraft:black_concrete
fill 429 107 262 433 108 266 minecraft:gray_concrete
fill 431 107 267 431 107 268 minecraft:gray_concrete
fill 432 107 233 434 107 233 minecraft:orange_concrete
setblock 433 107 232 minecraft:orange_concrete
setblock 433 107 234 minecraft:orange_concrete
setblock 434 107 228 minecraft:magenta_terracotta
setblock 434 107 231 minecraft:light[level=15]
setblock 434 107 239 minecraft:light[level=15]
setblock 434 107 247 minecraft:light[level=15]
setblock 434 107 255 minecraft:light[level=15]
setblock 434 107 263 minecraft:light[level=15]
fill 435 107 228 435 152 228 minecraft:black_concrete
setblock 442 107 231 minecraft:light[level=15]
setblock 442 107 239 minecraft:light[level=15]
setblock 442 107 255 minecraft:light[level=15]
setblock 442 107 263 minecraft:light[level=15]
fill 443 107 233 443 108 233 minecraft:orange_concrete
setblock 444 107 228 minecraft:magenta_terracotta
fill 445 107 231 445 108 231 minecraft:orange_concrete
fill 445 107 235 445 108 235 minecraft:orange_concrete
fill 445 107 265 447 109 267 minecraft:gold_block
fill 447 107 233 447 108 233 minecraft:orange_concrete
setblock 450 107 231 minecraft:light[level=15]
setblock 450 107 239 minecraft:light[level=15]
setblock 450 107 247 minecraft:light[level=15]
setblock 450 107 255 minecraft:light[level=15]
setblock 450 107 263 minecraft:light[level=15]
fill 452 107 228 452 174 228 minecraft:black_concrete
setblock 455 107 228 minecraft:sea_lantern
setblock 458 107 231 minecraft:light[level=15]
setblock 458 107 239 minecraft:light[level=15]
setblock 458 107 247 minecraft:light[level=15]
setblock 458 107 255 minecraft:light[level=15]
setblock 458 107 263 minecraft:light[level=15]
fill 465 107 261 465 162 261 minecraft:black_concrete
setblock 423 108 232 minecraft:ochre_froglight
fill 423 108 236 423 145 236 minecraft:black_concrete
setblock 423 108 257 minecraft:ochre_froglight
fill 426 108 228 426 260 228 minecraft:black_concrete
setblock 426 108 231 minecraft:light[level=12]
setblock 426 108 238 minecraft:light[level=12]
setblock 426 108 245 minecraft:light[level=12]
setblock 426 108 252 minecraft:light[level=12]
setblock 426 108 259 minecraft:light[level=12]
setblock 426 108 266 minecraft:light[level=12]
setblock 433 108 231 minecraft:light[level=12]
fill 433 108 233 433 109 233 minecraft:orange_concrete
setblock 433 108 238 minecraft:light[level=12]
setblock 433 108 245 minecraft:light[level=12]
setblock 433 108 252 minecraft:light[level=12]
setblock 433 108 259 minecraft:light[level=12]
fill 434 108 228 434 137 228 minecraft:black_concrete
setblock 438 108 270 minecraft:white_concrete
setblock 439 108 228 minecraft:ochre_froglight
setblock 440 108 231 minecraft:light[level=12]
setblock 440 108 238 minecraft:light[level=12]
setblock 440 108 245 minecraft:light[level=12]
setblock 440 108 252 minecraft:light[level=12]
setblock 440 108 259 minecraft:light[level=12]
fill 440 108 265 444 108 267 minecraft:blue_stained_glass
fill 444 108 228 444 164 228 minecraft:black_concrete
setblock 444 108 270 minecraft:pearlescent_froglight
setblock 447 108 231 minecraft:light[level=12]
setblock 447 108 245 minecraft:light[level=12]
setblock 447 108 252 minecraft:light[level=12]
setblock 447 108 259 minecraft:light[level=12]
fill 448 108 265 452 108 267 minecraft:blue_stained_glass
setblock 454 108 231 minecraft:light[level=12]
setblock 454 108 238 minecraft:light[level=12]
setblock 454 108 245 minecraft:light[level=12]
setblock 454 108 252 minecraft:light[level=12]
setblock 454 108 259 minecraft:light[level=12]
setblock 454 108 266 minecraft:light[level=12]
fill 455 108 228 455 130 228 minecraft:black_concrete
setblock 459 108 228 minecraft:ochre_froglight
setblock 461 108 231 minecraft:light[level=12]
setblock 461 108 238 minecraft:light[level=12]
setblock 461 108 245 minecraft:light[level=12]
setblock 461 108 252 minecraft:light[level=12]
setblock 461 108 259 minecraft:light[level=12]
setblock 461 108 266 minecraft:light[level=12]
fill 423 109 232 423 147 232 minecraft:black_concrete
fill 423 109 257 423 118 257 minecraft:black_concrete
setblock 423 109 264 minecraft:blue_concrete
setblock 438 109 228 minecraft:white_concrete
setblock 438 109 270 minecraft:black_concrete
fill 439 109 228 439 117 228 minecraft:black_concrete
fill 444 109 270 444 119 270 minecraft:black_concrete
setblock 458 109 228 minecraft:white_concrete
fill 459 109 228 459 167 228 minecraft:black_concrete
setblock 460 109 228 minecraft:pearlescent_froglight
setblock 465 109 245 minecraft:pearlescent_froglight
fill 423 110 264 423 142 264 minecraft:black_concrete
fill 438 110 228 438 117 228 minecraft:black_concrete
setblock 438 110 270 minecraft:ochre_froglight
setblock 439 110 270 minecraft:pearlescent_froglight
fill 446 110 266 446 111 266 minecraft:iron_bars
setblock 454 110 228 minecraft:sea_lantern
fill 458 110 228 458 129 228 minecraft:black_concrete
fill 460 110 228 460 122 228 minecraft:black_concrete
fill 465 110 245 465 179 245 minecraft:black_concrete
setblock 423 111 258 minecraft:ochre_froglight
setblock 429 111 270 minecraft:white_concrete
fill 438 111 270 439 135 270 minecraft:black_concrete
fill 454 111 228 454 133 228 minecraft:black_concrete
setblock 423 112 235 minecraft:sea_lantern
setblock 423 112 249 minecraft:ochre_froglight
fill 423 112 258 423 148 258 minecraft:black_concrete
fill 429 112 270 429 122 270 minecraft:black_concrete
setblock 465 112 235 minecraft:blue_concrete
fill 423 113 235 423 132 235 minecraft:black_concrete
fill 423 113 249 423 126 249 minecraft:black_concrete
setblock 423 113 259 minecraft:pearlescent_froglight
setblock 426 113 270 minecraft:ochre_froglight
setblock 431 113 270 minecraft:pearlescent_froglight
setblock 447 113 228 minecraft:purple_terracotta
fill 447 113 239 447 120 239 minecraft:gray_concrete
fill 462 113 270 462 181 270 minecraft:black_concrete
setblock 463 113 270 minecraft:pearlescent_froglight
fill 465 113 235 465 163 235 minecraft:black_concrete
setblock 465 113 255 minecraft:pearlescent_froglight
setblock 465 113 267 minecraft:white_concrete
fill 423 114 259 423 116 259 minecraft:black_concrete
setblock 426 114 231 minecraft:light[level=15]
setblock 426 114 238 minecraft:light[level=12]
setblock 426 114 239 minecraft:light[level=15]
setblock 426 114 245 minecraft:light[level=12]
setblock 426 114 247 minecraft:light[level=15]
setblock 426 114 252 minecraft:light[level=12]
setblock 426 114 255 minecraft:light[level=15]
setblock 426 114 259 minecraft:light[level=12]
setblock 426 114 263 minecraft:light[level=15]
setblock 426 114 266 minecraft:light[level=12]
fill 426 114 270 426 115 270 minecraft:black_concrete
fill 431 114 270 431 126 270 minecraft:black_concrete
setblock 433 114 231 minecraft:light[level=12]
setblock 433 114 238 minecraft:light[level=12]
setblock 433 114 245 minecraft:light[level=12]
setblock 433 114 252 minecraft:light[level=12]
setblock 433 114 259 minecraft:light[level=12]
setblock 433 114 266 minecraft:light[level=12]
setblock 434 114 231 minecraft:light[level=15]
setblock 434 114 239 minecraft:light[level=15]
setblock 434 114 247 minecraft:light[level=15]
setblock 434 114 255 minecraft:light[level=15]
setblock 434 114 263 minecraft:light[level=15]
setblock 440 114 231 minecraft:light[level=12]
setblock 440 114 238 minecraft:light[level=12]
setblock 440 114 252 minecraft:light[level=12]
setblock 440 114 259 minecraft:light[level=12]
setblock 440 114 266 minecraft:light[level=12]
setblock 442 114 231 minecraft:light[level=15]
setblock 442 114 239 minecraft:light[level=15]
setblock 442 114 255 minecraft:light[level=15]
setblock 442 114 263 minecraft:light[level=15]
fill 446 114 239 446 120 239 minecraft:gray_concrete
fill 447 114 228 447 116 228 minecraft:black_concrete
setblock 447 114 231 minecraft:light[level=12]
setblock 447 114 245 minecraft:light[level=12]
setblock 447 114 252 minecraft:light[level=12]
setblock 447 114 259 minecraft:light[level=12]
setblock 447 114 266 minecraft:light[level=12]
setblock 450 114 228 minecraft:ochre_froglight
setblock 450 114 231 minecraft:light[level=15]
setblock 450 114 239 minecraft:light[level=15]
setblock 450 114 247 minecraft:light[level=15]
setblock 450 114 255 minecraft:light[level=15]
setblock 450 114 263 minecraft:light[level=15]
setblock 454 114 231 minecraft:light[level=12]
setblock 454 114 238 minecraft:light[level=12]
setblock 454 114 245 minecraft:light[level=12]
setblock 454 114 252 minecraft:light[level=12]
setblock 454 114 259 minecraft:light[level=12]
setblock 454 114 266 minecraft:light[level=12]
setblock 458 114 231 minecraft:light[level=15]
setblock 458 114 239 minecraft:light[level=15]
setblock 458 114 247 minecraft:light[level=15]
setblock 458 114 255 minecraft:light[level=15]
setblock 458 114 263 minecraft:light[level=15]
setblock 461 114 228 minecraft:ochre_froglight
setblock 461 114 231 minecraft:light[level=12]
setblock 461 114 238 minecraft:light[level=12]
setblock 461 114 245 minecraft:light[level=12]
setblock 461 114 252 minecraft:light[level=12]
setblock 461 114 259 minecraft:light[level=12]
setblock 461 114 266 minecraft:light[level=12]
fill 463 114 270 463 211 270 minecraft:black_concrete
fill 465 114 255 465 115 255 minecraft:black_concrete
fill 465 114 267 465 127 267 minecraft:black_concrete
fill 433 115 247 433 120 247 minecraft:gray_concrete
fill 439 115 246 439 116 246 minecraft:light_gray_concrete
fill 439 115 248 439 116 248 minecraft:light_gray_concrete
fill 441 115 244 441 116 244 minecraft:light_gray_concrete
fill 441 115 250 441 116 250 minecraft:light_gray_concrete
setblock 442 115 228 minecraft:ochre_froglight
fill 443 115 244 443 116 244 minecraft:light_gray_concrete
fill 443 115 250 443 116 250 minecraft:light_gray_concrete
fill 445 115 246 445 116 246 minecraft:light_gray_concrete
fill 445 115 248 445 116 248 minecraft:light_gray_concrete
fill 450 115 228 450 136 228 minecraft:black_concrete
setblock 453 115 270 minecraft:pearlescent_froglight
fill 461 115 228 461 207 228 minecraft:black_concrete
setblock 464 115 228 minecraft:ochre_froglight
setblock 465 115 236 minecraft:white_concrete
setblock 465 115 269 minecraft:sea_lantern
fill 465 115 270 465 308 270 minecraft:black_concrete
setblock 423 116 262 minecraft:pearlescent_froglight
setblock 426 116 270 minecraft:pearlescent_froglight
fill 433 116 248 433 120 248 minecraft:gray_concrete
setblock 438 116 247 minecraft:white_concrete
setblock 439 116 245 minecraft:light_gray_concrete
setblock 439 116 249 minecraft:light_gray_concrete
setblock 440 116 244 minecraft:light_gray_concrete
setblock 440 116 250 minecraft:light_gray_concrete
fill 442 116 228 442 244 228 minecraft:black_concrete
setblock 442 116 243 minecraft:white_concrete
setblock 442 116 251 minecraft:white_concrete
setblock 444 116 244 minecraft:light_gray_concrete
setblock 444 116 250 minecraft:light_gray_concrete
setblock 445 116 245 minecraft:light_gray_concrete
setblock 445 116 249 minecraft:light_gray_concrete
setblock 446 116 247 minecraft:white_concrete
setblock 448 116 228 minecraft:pearlescent_froglight
fill 453 116 270 453 184 270 minecraft:black_concrete
setblock 454 116 270 minecraft:purple_terracotta
fill 464 116 228 464 130 228 minecraft:black_concrete
fill 465 116 236 465 202 236 minecraft:black_concrete
setblock 465 116 255 minecraft:white_concrete
fill 465 116 269 465 120 269 minecraft:black_concrete
setblock 423 117 234 minecraft:sea_lantern
setblock 423 117 259 minecraft:pearlescent_froglight
fill 423 117 262 423 190 262 minecraft:black_concrete
fill 424 117 229 424 117 234 minecraft:light_gray_stained_glass
setblock 424 117 235 minecraft:sea_lantern
fill 424 117 236 424 117 247 minecraft:light_gray_stained_glass
setblock 424 117 248 minecraft:sea_lantern
fill 424 117 249 424 117 260 minecraft:light_gray_stained_glass
setblock 424 117 261 minecraft:sea_lantern
fill 424 117 262 424 117 269 minecraft:light_gray_stained_glass
setblock 425 117 229 minecraft:sea_lantern
fill 425 117 230 425 117 241 minecraft:light_gray_stained_glass
setblock 425 117 242 minecraft:sea_lantern
fill 425 117 243 425 117 254 minecraft:light_gray_stained_glass
setblock 425 117 255 minecraft:sea_lantern
fill 425 117 256 425 117 267 minecraft:light_gray_stained_glass
setblock 425 117 268 minecraft:sea_lantern
fill 425 117 269 426 117 269 minecraft:light_gray_stained_glass
fill 426 117 229 426 117 235 minecraft:light_gray_stained_glass
setblock 426 117 236 minecraft:sea_lantern
fill 426 117 237 426 117 248 minecraft:light_gray_stained_glass
setblock 426 117 249 minecraft:sea_lantern
fill 426 117 250 426 117 261 minecraft:light_gray_stained_glass
setblock 426 117 262 minecraft:sea_lantern
fill 426 117 263 427 117 268 minecraft:light_gray_stained_glass
fill 426 117 270 426 165 270 minecraft:black_concrete
fill 427 117 229 437 117 229 minecraft:light_gray_stained_glass
setblock 427 117 230 minecraft:sea_lantern
fill 427 117 231 427 117 242 minecraft:light_gray_stained_glass
setblock 427 117 243 minecraft:sea_lantern
fill 427 117 244 427 117 255 minecraft:light_gray_stained_glass
setblock 427 117 256 minecraft:sea_lantern
fill 427 117 257 428 117 262 minecraft:light_gray_stained_glass
setblock 427 117 269 minecraft:sea_lantern
fill 428 117 230 428 117 236 minecraft:light_gray_stained_glass
setblock 428 117 237 minecraft:sea_lantern
fill 428 117 238 428 117 249 minecraft:light_gray_stained_glass
setblock 428 117 250 minecraft:sea_lantern
fill 428 117 251 429 117 256 minecraft:light_gray_stained_glass
setblock 428 117 263 minecraft:sea_lantern
fill 428 117 264 429 117 269 minecraft:light_gray_stained_glass
fill 429 117 230 439 117 230 minecraft:light_gray_stained_glass
setblock 429 117 231 minecraft:sea_lantern
fill 429 117 232 429 117 243 minecraft:light_gray_stained_glass
setblock 429 117 244 minecraft:sea_lantern
fill 429 117 245 430 117 250 minecraft:light_gray_stained_glass
setblock 429 117 257 minecraft:sea_lantern
fill 429 117 258 430 117 263 minecraft:light_gray_stained_glass
fill 430 117 231 430 117 237 minecraft:light_gray_stained_glass
setblock 430 117 238 minecraft:sea_lantern
fill 430 117 239 431 117 244 minecraft:light_gray_stained_glass
setblock 430 117 251 minecraft:sea_lantern
fill 430 117 252 431 117 257 minecraft:light_gray_stained_glass
setblock 430 117 264 minecraft:sea_lantern
fill 430 117 265 431 117 269 minecraft:light_gray_stained_glass
fill 431 117 231 441 117 231 minecraft:light_gray_stained_glass
setblock 431 117 232 minecraft:sea_lantern
fill 431 117 233 432 117 238 minecraft:light_gray_stained_glass
setblock 431 117 245 minecraft:sea_lantern
fill 431 117 246 431 117 251 minecraft:light_gray_stained_glass
setblock 431 117 258 minecraft:sea_lantern
fill 431 117 259 432 117 264 minecraft:light_gray_stained_glass
fill 432 117 232 443 117 232 minecraft:light_gray_stained_glass
setblock 432 117 239 minecraft:sea_lantern
fill 432 117 240 432 117 246 minecraft:light_gray_stained_glass
fill 432 117 249 436 117 251 minecraft:light_gray_stained_glass
setblock 432 117 252 minecraft:sea_lantern
fill 432 117 253 433 117 258 minecraft:light_gray_stained_glass
setblock 432 117 265 minecraft:sea_lantern
fill 432 117 266 433 117 269 minecraft:light_gray_stained_glass
setblock 433 117 233 minecraft:sea_lantern
fill 433 117 234 433 117 245 minecraft:light_gray_stained_glass
setblock 433 117 246 minecraft:sea_lantern
fill 433 117 252 438 117 252 minecraft:light_gray_stained_glass
setblock 433 117 259 minecraft:sea_lantern
fill 433 117 260 434 117 265 minecraft:light_gray_stained_glass
fill 434 117 233 434 117 239 minecraft:light_gray_stained_glass
setblock 434 117 240 minecraft:sea_lantern
fill 434 117 241 434 117 248 minecraft:light_gray_stained_glass
setblock 434 117 253 minecraft:sea_lantern
fill 434 117 254 435 117 259 minecraft:light_gray_stained_glass
setblock 434 117 266 minecraft:sea_lantern
fill 434 117 267 435 117 269 minecraft:light_gray_stained_glass
fill 435 117 233 445 117 233 minecraft:light_gray_stained_glass
setblock 435 117 234 minecraft:sea_lantern
fill 435 117 235 435 117 246 minecraft:light_gray_stained_glass
setblock 435 117 247 minecraft:sea_lantern
setblock 435 117 248 minecraft:light_gray_stained_glass
fill 435 117 253 440 117 253 minecraft:light_gray_stained_glass
setblock 435 117 260 minecraft:sea_lantern
fill 435 117 261 436 117 266 minecraft:light_gray_stained_glass
fill 436 117 234 436 117 240 minecraft:light_gray_stained_glass
setblock 436 117 241 minecraft:sea_lantern
fill 436 117 242 436 117 245 minecraft:light_gray_stained_glass
fill 436 117 246 436 118 248 minecraft:light_gray_concrete
setblock 436 117 254 minecraft:sea_lantern
fill 436 117 255 437 117 260 minecraft:light_gray_stained_glass
setblock 436 117 267 minecraft:sea_lantern
fill 436 117 268 437 117 269 minecraft:light_gray_stained_glass
fill 437 117 234 447 117 234 minecraft:light_gray_stained_glass
setblock 437 117 235 minecraft:sea_lantern
fill 437 117 236 437 117 243 minecraft:light_gray_stained_glass
fill 437 117 244 437 118 244 minecraft:white_concrete
fill 437 117 245 437 117 249 minecraft:sea_lantern
fill 437 117 250 437 118 250 minecraft:white_concrete
setblock 437 117 251 minecraft:light_gray_stained_glass
fill 437 117 254 448 117 254 minecraft:light_gray_stained_glass
setblock 437 117 261 minecraft:sea_lantern
fill 437 117 262 438 117 267 minecraft:light_gray_stained_glass
setblock 438 117 229 minecraft:sea_lantern
fill 438 117 235 438 117 241 minecraft:light_gray_stained_glass
fill 438 117 242 438 117 245 minecraft:sea_lantern
fill 438 117 246 438 117 248 minecraft:redstone_block
fill 438 117 249 438 117 251 minecraft:sea_lantern
setblock 438 117 255 minecraft:sea_lantern
fill 438 117 256 439 117 261 minecraft:light_gray_stained_glass
setblock 438 117 268 minecraft:sea_lantern
fill 438 117 269 439 117 269 minecraft:light_gray_stained_glass
fill 439 117 229 450 117 229 minecraft:light_gray_stained_glass
fill 439 117 235 449 117 235 minecraft:light_gray_stained_glass
setblock 439 117 236 minecraft:sea_lantern
fill 439 117 237 440 117 241 minecraft:light_gray_stained_glass
fill 439 117 242 439 118 242 minecraft:white_concrete
fill 439 117 243 440 117 243 minecraft:sea_lantern
fill 439 117 244 439 117 246 minecraft:redstone_block
fill 439 117 248 439 117 250 minecraft:redstone_block
fill 439 117 251 440 117 251 minecraft:sea_lantern
fill 439 117 252 439 118 252 minecraft:white_concrete
fill 439 117 255 446 117 255 minecraft:light_gray_stained_glass
setblock 439 117 262 minecraft:sea_lantern
fill 439 117 263 440 117 268 minecraft:light_gray_stained_glass
setblock 440 117 230 minecraft:sea_lantern
fill 440 117 236 451 117 236 minecraft:light_gray_stained_glass
fill 440 117 242 444 117 242 minecraft:sea_lantern
fill 440 117 244 441 117 244 minecraft:redstone_block
fill 440 117 250 441 117 250 minecraft:redstone_block
fill 440 117 252 444 117 252 minecraft:sea_lantern
setblock 440 117 256 minecraft:sea_lantern
fill 440 117 257 441 117 262 minecraft:light_gray_stained_glass
setblock 440 117 269 minecraft:sea_lantern
setblock 441 117 228 minecraft:purple_terracotta
fill 441 117 230 452 117 230 minecraft:light_gray_stained_glass
setblock 441 117 237 minecraft:sea_lantern
fill 441 117 238 442 117 240 minecraft:light_gray_stained_glass
fill 441 117 241 443 118 241 minecraft:light_gray_concrete
fill 441 117 243 443 117 243 minecraft:redstone_block
fill 441 117 251 443 117 251 minecraft:redstone_block
fill 441 117 253 443 118 253 minecraft:light_gray_concrete
fill 441 117 256 452 117 256 minecraft:light_gray_stained_glass
setblock 441 117 263 minecraft:sea_lantern
fill 441 117 264 442 117 269 minecraft:light_gray_stained_glass
setblock 442 117 231 minecraft:sea_lantern
fill 442 117 237 453 117 237 minecraft:light_gray_stained_glass
setblock 442 117 257 minecraft:sea_lantern
fill 442 117 258 443 117 263 minecraft:light_gray_stained_glass
fill 443 117 231 454 117 231 minecraft:light_gray_stained_glass
setblock 443 117 238 minecraft:sea_lantern
fill 443 117 239 444 117 240 minecraft:light_gray_stained_glass
fill 443 117 244 445 117 244 minecraft:redstone_block
fill 443 117 250 445 117 250 minecraft:redstone_block
fill 443 117 257 454 117 257 minecraft:light_gray_stained_glass
setblock 443 117 264 minecraft:sea_lantern
fill 443 117 265 444 117 269 minecraft:light_gray_stained_glass
setblock 444 117 232 minecraft:sea_lantern
fill 444 117 238 445 117 238 minecraft:light_gray_stained_glass
fill 444 117 241 448 117 241 minecraft:light_gray_stained_glass
fill 444 117 243 446 117 243 minecraft:sea_lantern
fill 444 117 251 446 117 251 minecraft:sea_lantern
fill 444 117 253 446 117 253 minecraft:light_gray_stained_glass
setblock 444 117 258 minecraft:sea_lantern
fill 444 117 259 445 117 264 minecraft:light_gray_stained_glass
fill 445 117 232 456 117 232 minecraft:light_gray_stained_glass
setblock 445 117 239 minecraft:sea_lantern
fill 445 117 240 446 117 240 minecraft:light_gray_stained_glass
fill 445 117 242 445 118 242 minecraft:white_concrete
fill 445 117 245 445 117 246 minecraft:redstone_block
fill 445 117 248 445 117 249 minecraft:redstone_block
fill 445 117 252 445 118 252 minecraft:white_concrete
fill 445 117 258 456 117 258 minecraft:light_gray_stained_glass
setblock 445 117 265 minecraft:sea_lantern
fill 445 117 266 446 117 269 minecraft:light_gray_stained_glass
setblock 446 117 233 minecraft:sea_lantern
fill 446 117 242 450 117 242 minecraft:light_gray_stained_glass
fill 446 117 244 446 117 245 minecraft:sea_lantern
fill 446 117 246 446 117 248 minecraft:redstone_block
fill 446 117 249 446 117 250 minecraft:sea_lantern
fill 446 117 252 457 117 252 minecraft:light_gray_stained_glass
setblock 446 117 259 minecraft:sea_lantern
fill 446 117 260 447 117 265 minecraft:light_gray_stained_glass
setblock 447 117 228 minecraft:sea_lantern
fill 447 117 233 458 117 233 minecraft:light_gray_stained_glass
setblock 447 117 240 minecraft:sea_lantern
fill 447 117 243 452 117 243 minecraft:light_gray_stained_glass
fill 447 117 244 447 118 244 minecraft:white_concrete
fill 447 117 245 447 117 249 minecraft:sea_lantern
fill 447 117 250 447 118 250 minecraft:white_concrete
fill 447 117 251 455 117 251 minecraft:light_gray_stained_glass
setblock 447 117 253 minecraft:sea_lantern
fill 447 117 259 458 117 259 minecraft:light_gray_stained_glass
setblock 447 117 266 minecraft:sea_lantern
fill 447 117 267 448 117 269 minecraft:light_gray_stained_glass
fill 448 117 228 448 145 228 minecraft:black_concrete
setblock 448 117 234 minecraft:sea_lantern
fill 448 117 238 455 117 240 minecraft:light_gray_stained_glass
fill 448 117 244 454 117 245 minecraft:light_gray_stained_glass
fill 448 117 246 448 118 248 minecraft:light_gray_concrete
fill 448 117 249 451 117 250 minecraft:light_gray_stained_glass
fill 448 117 253 459 117 253 minecraft:light_gray_stained_glass
setblock 448 117 260 minecraft:sea_lantern
fill 448 117 261 449 117 266 minecraft:light_gray_stained_glass
fill 449 117 234 460 117 234 minecraft:light_gray_stained_glass
setblock 449 117 241 minecraft:sea_lantern
fill 449 117 246 449 117 248 minecraft:light_gray_stained_glass
setblock 449 117 254 minecraft:sea_lantern
fill 449 117 255 450 117 255 minecraft:light_gray_stained_glass
fill 449 117 260 460 117 260 minecraft:light_gray_stained_glass
setblock 449 117 267 minecraft:sea_lantern
fill 449 117 268 450 117 269 minecraft:light_gray_stained_glass
setblock 450 117 235 minecraft:sea_lantern
fill 450 117 241 461 117 241 minecraft:light_gray_stained_glass
fill 450 117 246 458 117 247 minecraft:light_gray_stained_glass
setblock 450 117 248 minecraft:sea_lantern
fill 450 117 254 461 117 254 minecraft:light_gray_stained_glass
setblock 450 117 261 minecraft:sea_lantern
fill 450 117 262 451 117 267 minecraft:light_gray_stained_glass
setblock 451 117 229 minecraft:sea_lantern
fill 451 117 235 462 117 235 minecraft:light_gray_stained_glass
setblock 451 117 242 minecraft:sea_lantern
fill 451 117 248 462 117 248 minecraft:light_gray_stained_glass
setblock 451 117 255 minecraft:sea_lantern
fill 451 117 261 462 117 261 minecraft:light_gray_stained_glass
setblock 451 117 268 minecraft:sea_lantern
fill 451 117 269 452 117 269 minecraft:light_gray_stained_glass
fill 452 117 229 463 117 229 minecraft:light_gray_stained_glass
setblock 452 117 236 minecraft:sea_lantern
fill 452 117 242 463 117 242 minecraft:light_gray_stained_glass
setblock 452 117 249 minecraft:sea_lantern
fill 452 117 250 453 117 250 minecraft:light_gray_stained_glass
fill 452 117 255 463 117 255 minecraft:light_gray_stained_glass
setblock 452 117 262 minecraft:sea_lantern
fill 452 117 263 453 117 268 minecraft:light_gray_stained_glass
setblock 453 117 230 minecraft:sea_lantern
fill 453 117 236 464 117 236 minecraft:light_gray_stained_glass
setblock 453 117 243 minecraft:sea_lantern
fill 453 117 249 464 117 249 minecraft:light_gray_stained_glass
setblock 453 117 256 minecraft:sea_lantern
fill 453 117 262 464 117 262 minecraft:light_gray_stained_glass
setblock 453 117 269 minecraft:sea_lantern
fill 454 117 230 464 117 230 minecraft:light_gray_stained_glass
setblock 454 117 237 minecraft:sea_lantern
fill 454 117 243 464 117 243 minecraft:light_gray_stained_glass
setblock 454 117 250 minecraft:sea_lantern
fill 454 117 256 464 117 256 minecraft:light_gray_stained_glass
setblock 454 117 263 minecraft:sea_lantern
fill 454 117 264 455 117 269 minecraft:light_gray_stained_glass
fill 454 117 270 454 124 270 minecraft:black_concrete
setblock 455 117 231 minecraft:sea_lantern
fill 455 117 237 464 117 237 minecraft:light_gray_stained_glass
setblock 455 117 244 minecraft:sea_lantern
fill 455 117 245 456 117 245 minecraft:light_gray_stained_glass
fill 455 117 250 464 117 250 minecraft:light_gray_stained_glass
setblock 455 117 257 minecraft:sea_lantern
fill 455 117 263 464 117 263 minecraft:light_gray_stained_glass
fill 456 117 231 464 117 231 minecraft:light_gray_stained_glass
setblock 456 117 238 minecraft:sea_lantern
fill 456 117 239 457 117 240 minecraft:light_gray_stained_glass
fill 456 117 244 464 117 244 minecraft:light_gray_stained_glass
setblock 456 117 251 minecraft:sea_lantern
fill 456 117 257 464 117 257 minecraft:light_gray_stained_glass
setblock 456 117 264 minecraft:sea_lantern
fill 456 117 265 457 117 269 minecraft:light_gray_stained_glass
setblock 457 117 232 minecraft:sea_lantern
fill 457 117 238 464 117 238 minecraft:light_gray_stained_glass
setblock 457 117 245 minecraft:sea_lantern
fill 457 117 251 464 117 251 minecraft:light_gray_stained_glass
setblock 457 117 258 minecraft:sea_lantern
fill 457 117 264 464 117 264 minecraft:light_gray_stained_glass
fill 458 117 232 464 117 232 minecraft:light_gray_stained_glass
setblock 458 117 239 minecraft:sea_lantern
fill 458 117 240 459 117 240 minecraft:light_gray_stained_glass
fill 458 117 245 464 117 245 minecraft:light_gray_stained_glass
setblock 458 117 252 minecraft:sea_lantern
fill 458 117 258 464 117 258 minecraft:light_gray_stained_glass
setblock 458 117 265 minecraft:sea_lantern
fill 458 117 266 459 117 269 minecraft:light_gray_stained_glass
setblock 459 117 233 minecraft:sea_lantern
fill 459 117 239 464 117 239 minecraft:light_gray_stained_glass
setblock 459 117 246 minecraft:sea_lantern
fill 459 117 247 460 117 247 minecraft:light_gray_stained_glass
fill 459 117 252 464 117 252 minecraft:light_gray_stained_glass
setblock 459 117 259 minecraft:sea_lantern
fill 459 117 265 464 117 265 minecraft:light_gray_stained_glass
fill 460 117 233 464 117 233 minecraft:light_gray_stained_glass
setblock 460 117 240 minecraft:sea_lantern
fill 460 117 246 464 117 246 minecraft:light_gray_stained_glass
setblock 460 117 253 minecraft:sea_lantern
fill 460 117 259 464 117 259 minecraft:light_gray_stained_glass
setblock 460 117 266 minecraft:sea_lantern
fill 460 117 267 461 117 269 minecraft:light_gray_stained_glass
setblock 461 117 234 minecraft:sea_lantern
fill 461 117 240 464 117 240 minecraft:light_gray_stained_glass
setblock 461 117 247 minecraft:sea_lantern
fill 461 117 253 464 117 253 minecraft:light_gray_stained_glass
setblock 461 117 260 minecraft:sea_lantern
fill 461 117 266 464 117 266 minecraft:light_gray_stained_glass
fill 462 117 234 464 117 234 minecraft:light_gray_stained_glass
setblock 462 117 241 minecraft:sea_lantern
fill 462 117 247 464 117 247 minecraft:light_gray_stained_glass
setblock 462 117 254 minecraft:sea_lantern
fill 462 117 260 464 117 260 minecraft:light_gray_stained_glass
setblock 462 117 267 minecraft:sea_lantern
fill 462 117 268 463 117 269 minecraft:light_gray_stained_glass
setblock 463 117 235 minecraft:sea_lantern
fill 463 117 241 464 117 241 minecraft:light_gray_stained_glass
setblock 463 117 248 minecraft:sea_lantern
fill 463 117 254 464 117 254 minecraft:light_gray_stained_glass
setblock 463 117 261 minecraft:sea_lantern
fill 463 117 267 464 117 267 minecraft:light_gray_stained_glass
setblock 464 117 229 minecraft:sea_lantern
setblock 464 117 235 minecraft:light_gray_stained_glass
setblock 464 117 242 minecraft:sea_lantern
setblock 464 117 248 minecraft:light_gray_stained_glass
setblock 464 117 255 minecraft:sea_lantern
setblock 464 117 261 minecraft:light_gray_stained_glass
setblock 464 117 268 minecraft:sea_lantern
setblock 464 117 269 minecraft:light_gray_stained_glass
setblock 465 117 253 minecraft:white_concrete
fill 465 117 255 465 170 255 minecraft:black_concrete
setblock 465 117 256 minecraft:pearlescent_froglight
setblock 465 117 268 minecraft:white_concrete
setblock 423 118 231 minecraft:magenta_terracotta
fill 423 118 234 423 155 234 minecraft:black_concrete
fill 423 118 259 423 132 259 minecraft:black_concrete
fill 435 118 245 435 119 249 minecraft:white_concrete
fill 436 118 243 436 119 243 minecraft:white_concrete
fill 436 118 244 436 118 245 minecraft:light_gray_concrete
fill 436 118 249 436 118 250 minecraft:light_gray_concrete
fill 436 118 251 436 119 251 minecraft:white_concrete
fill 437 118 242 437 119 242 minecraft:white_concrete
setblock 437 118 243 minecraft:light_gray_concrete
setblock 437 118 245 minecraft:white_concrete
setblock 437 118 249 minecraft:white_concrete
setblock 437 118 251 minecraft:light_gray_concrete
fill 437 118 252 437 119 252 minecraft:white_concrete
setblock 438 118 228 minecraft:purple_terracotta
fill 438 118 241 438 119 241 minecraft:white_concrete
setblock 438 118 242 minecraft:light_gray_concrete
setblock 438 118 243 minecraft:white_concrete
setblock 438 118 251 minecraft:white_concrete
setblock 438 118 252 minecraft:light_gray_concrete
fill 438 118 253 438 119 253 minecraft:white_concrete
setblock 439 118 228 minecraft:blue_concrete
fill 439 118 241 440 118 241 minecraft:light_gray_concrete
fill 439 118 253 440 118 253 minecraft:light_gray_concrete
fill 440 118 240 444 119 240 minecraft:white_concrete
setblock 440 118 242 minecraft:white_concrete
setblock 440 118 252 minecraft:white_concrete
fill 440 118 254 444 119 254 minecraft:white_concrete
fill 441 118 228 441 134 228 minecraft:black_concrete
fill 444 118 241 445 118 241 minecraft:light_gray_concrete
setblock 444 118 242 minecraft:white_concrete
setblock 444 118 252 minecraft:white_concrete
fill 444 118 253 445 118 253 minecraft:light_gray_concrete
fill 446 118 241 446 119 241 minecraft:white_concrete
setblock 446 118 242 minecraft:light_gray_concrete
setblock 446 118 243 minecraft:white_concrete
setblock 446 118 251 minecraft:white_concrete
setblock 446 118 252 minecraft:light_gray_concrete
fill 446 118 253 446 119 253 minecraft:white_concrete
fill 447 118 228 447 169 228 minecraft:black_concrete
fill 447 118 242 447 119 242 minecraft:white_concrete
setblock 447 118 243 minecraft:light_gray_concrete
setblock 447 118 245 minecraft:white_concrete
setblock 447 118 249 minecraft:white_concrete
setblock 447 118 251 minecraft:light_gray_concrete
fill 447 118 252 447 119 252 minecraft:white_concrete
fill 448 118 243 448 119 243 minecraft:white_concrete
fill 448 118 244 448 118 245 minecraft:light_gray_concrete
fill 448 118 249 448 118 250 minecraft:light_gray_concrete
fill 448 118 251 448 119 251 minecraft:white_concrete
fill 449 118 245 449 119 249 minecraft:white_concrete
setblock 465 118 231 minecraft:magenta_terracotta
setblock 465 118 251 minecraft:white_concrete
fill 465 118 253 465 129 253 minecraft:black_concrete
fill 465 118 256 465 126 256 minecraft:black_concrete
setblock 465 118 268 minecraft:purple_concrete
fill 423 119 231 423 128 231 minecraft:black_concrete
setblock 423 119 257 minecraft:ochre_froglight
fill 434 119 244 434 119 250 minecraft:white_concrete
fill 435 119 242 435 119 244 minecraft:white_concrete
fill 435 119 250 435 119 252 minecraft:white_concrete
fill 436 119 241 436 119 242 minecraft:white_concrete
fill 436 119 252 436 119 253 minecraft:white_concrete
fill 437 119 240 437 119 241 minecraft:white_concrete
fill 437 119 253 437 119 254 minecraft:white_concrete
fill 438 119 228 439 127 228 minecraft:black_concrete
fill 438 119 240 439 119 240 minecraft:white_concrete
fill 438 119 254 439 119 254 minecraft:white_concrete
fill 439 119 239 445 119 239 minecraft:white_concrete
fill 439 119 255 445 119 255 minecraft:white_concrete
setblock 441 119 270 minecraft:purple_concrete
fill 445 119 240 447 119 240 minecraft:white_concrete
fill 445 119 254 447 119 254 minecraft:white_concrete
fill 447 119 241 448 119 241 minecraft:white_concrete
fill 447 119 253 448 119 253 minecraft:white_concrete
fill 448 119 242 449 119 242 minecraft:white_concrete
fill 448 119 252 449 119 252 minecraft:white_concrete
fill 449 119 243 449 119 244 minecraft:white_concrete
fill 449 119 250 449 119 251 minecraft:white_concrete
fill 450 119 244 450 119 250 minecraft:white_concrete
fill 465 119 231 465 143 231 minecraft:black_concrete
fill 465 119 251 465 194 251 minecraft:black_concrete
fill 465 119 268 465 149 268 minecraft:black_concrete
fill 423 120 257 423 195 257 minecraft:black_concrete
setblock 423 120 265 minecraft:blue_concrete
setblock 426 120 231 minecraft:light[level=12]
setblock 426 120 238 minecraft:light[level=12]
setblock 426 120 245 minecraft:light[level=12]
setblock 426 120 252 minecraft:light[level=12]
setblock 426 120 259 minecraft:light[level=12]
setblock 426 120 266 minecraft:light[level=12]
setblock 433 120 231 minecraft:light[level=12]
setblock 433 120 238 minecraft:light[level=12]
fill 433 120 243 433 120 246 minecraft:light_gray_concrete
fill 433 120 249 433 120 251 minecraft:light_gray_concrete
setblock 433 120 252 minecraft:light[level=12]
setblock 433 120 259 minecraft:light[level=12]
setblock 433 120 266 minecraft:light[level=12]
fill 434 120 242 434 121 242 minecraft:light_gray_concrete
fill 434 120 243 434 120 245 minecraft:white_concrete
fill 434 120 249 434 120 251 minecraft:white_concrete
fill 434 120 252 434 121 252 minecraft:light_gray_concrete
fill 435 120 240 435 120 241 minecraft:light_gray_concrete
setblock 435 120 242 minecraft:white_concrete
setblock 435 120 252 minecraft:white_concrete
fill 435 120 253 435 120 254 minecraft:light_gray_concrete
setblock 436 120 240 minecraft:light_gray_concrete
setblock 436 120 241 minecraft:white_concrete
setblock 436 120 253 minecraft:white_concrete
setblock 436 120 254 minecraft:light_gray_concrete
fill 437 120 239 437 121 239 minecraft:light_gray_concrete
setblock 437 120 240 minecraft:white_concrete
setblock 437 120 254 minecraft:white_concrete
fill 437 120 255 437 121 255 minecraft:light_gray_concrete
fill 438 120 238 445 120 238 minecraft:light_gray_concrete
fill 438 120 239 440 120 239 minecraft:white_concrete
fill 438 120 255 440 120 255 minecraft:white_concrete
fill 438 120 256 446 120 256 minecraft:light_gray_concrete
setblock 440 120 231 minecraft:light[level=12]
setblock 440 120 245 minecraft:light[level=12]
setblock 440 120 252 minecraft:light[level=12]
setblock 440 120 259 minecraft:light[level=12]
setblock 440 120 266 minecraft:light[level=12]
fill 441 120 270 441 245 270 minecraft:black_concrete
fill 444 120 239 445 120 239 minecraft:white_concrete
fill 444 120 255 446 120 255 minecraft:white_concrete
setblock 444 120 270 minecraft:ochre_froglight
setblock 447 120 231 minecraft:light[level=12]
setblock 447 120 240 minecraft:white_concrete
setblock 447 120 245 minecraft:light[level=12]
setblock 447 120 252 minecraft:light[level=12]
setblock 447 120 254 minecraft:white_concrete
setblock 447 120 259 minecraft:light[level=12]
setblock 447 120 266 minecraft:light[level=12]
fill 448 120 240 449 120 240 minecraft:light_gray_concrete
setblock 448 120 241 minecraft:white_concrete
setblock 448 120 253 minecraft:white_concrete
fill 448 120 254 449 120 254 minecraft:light_gray_concrete
setblock 449 120 241 minecraft:light_gray_concrete
setblock 449 120 242 minecraft:white_concrete
setblock 449 120 252 minecraft:white_concrete
setblock 449 120 253 minecraft:light_gray_concrete
fill 450 120 242 450 121 242 minecraft:light_gray_concrete
fill 450 120 243 450 120 245 minecraft:white_concrete
fill 450 120 249 450 120 251 minecraft:white_concrete
fill 450 120 252 450 121 252 minecraft:light_gray_concrete
fill 451 120 243 451 120 251 minecraft:light_gray_concrete
setblock 454 120 231 minecraft:light[level=12]
setblock 454 120 238 minecraft:light[level=12]
setblock 454 120 245 minecraft:light[level=12]
setblock 454 120 252 minecraft:light[level=12]
setblock 454 120 259 minecraft:light[level=12]
setblock 454 120 266 minecraft:light[level=12]
setblock 461 120 231 minecraft:light[level=12]
setblock 461 120 238 minecraft:light[level=12]
setblock 461 120 245 minecraft:light[level=12]
setblock 461 120 252 minecraft:light[level=12]
setblock 461 120 259 minecraft:light[level=12]
setblock 461 120 266 minecraft:light[level=12]
setblock 465 120 243 minecraft:white_concrete
fill 423 121 265 423 150 265 minecraft:black_concrete
setblock 426 121 231 minecraft:light[level=15]
setblock 426 121 239 minecraft:light[level=15]
setblock 426 121 247 minecraft:light[level=15]
setblock 426 121 255 minecraft:light[level=15]
setblock 426 121 263 minecraft:light[level=15]
setblock 427 121 270 minecraft:sea_lantern
fill 432 121 243 432 121 251 minecraft:white_concrete
fill 433 121 241 433 121 242 minecraft:white_concrete
fill 433 121 243 433 121 244 minecraft:light_gray_concrete
fill 433 121 250 433 121 251 minecraft:light_gray_concrete
fill 433 121 252 433 121 253 minecraft:white_concrete
setblock 434 121 231 minecraft:light[level=15]
setblock 434 121 239 minecraft:light[level=15]
fill 434 121 240 434 121 241 minecraft:white_concrete
setblock 434 121 247 minecraft:light[level=15]
fill 434 121 253 434 121 254 minecraft:white_concrete
setblock 434 121 255 minecraft:light[level=15]
setblock 434 121 263 minecraft:light[level=15]
fill 435 121 239 436 121 239 minecraft:white_concrete
setblock 435 121 240 minecraft:light_gray_concrete
setblock 435 121 254 minecraft:light_gray_concrete
fill 435 121 255 436 121 255 minecraft:white_concrete
fill 436 121 238 437 121 238 minecraft:white_concrete
fill 436 121 256 437 121 256 minecraft:white_concrete
fill 438 121 237 446 121 237 minecraft:white_concrete
fill 438 121 238 439 121 238 minecraft:light_gray_concrete
fill 438 121 256 439 121 256 minecraft:light_gray_concrete
fill 438 121 257 446 121 257 minecraft:white_concrete
setblock 442 121 231 minecraft:light[level=15]
setblock 442 121 239 minecraft:light[level=15]
setblock 442 121 247 minecraft:light[level=15]
setblock 442 121 255 minecraft:light[level=15]
setblock 442 121 263 minecraft:light[level=15]
fill 444 121 270 444 134 270 minecraft:black_concrete
setblock 445 121 228 minecraft:ochre_froglight
fill 445 121 238 446 121 238 minecraft:light_gray_concrete
fill 445 121 256 446 121 256 minecraft:light_gray_concrete
fill 447 121 238 448 121 238 minecraft:white_concrete
setblock 447 121 239 minecraft:light_gray_concrete
setblock 447 121 255 minecraft:light_gray_concrete
fill 447 121 256 448 121 256 minecraft:white_concrete
fill 448 121 239 449 121 239 minecraft:white_concrete
fill 448 121 255 449 121 255 minecraft:white_concrete
setblock 449 121 240 minecraft:light_gray_concrete
setblock 449 121 254 minecraft:light_gray_concrete
setblock 450 121 231 minecraft:light[level=15]
setblock 450 121 239 minecraft:light[level=15]
fill 450 121 240 450 121 241 minecraft:white_concrete
setblock 450 121 247 minecraft:light[level=15]
fill 450 121 253 450 121 254 minecraft:white_concrete
setblock 450 121 255 minecraft:light[level=15]
setblock 450 121 263 minecraft:light[level=15]
fill 451 121 241 451 121 242 minecraft:white_concrete
fill 451 121 243 451 121 244 minecraft:light_gray_concrete
fill 451 121 250 451 121 251 minecraft:light_gray_concrete
fill 451 121 252 451 121 253 minecraft:white_concrete
fill 452 121 243 452 121 251 minecraft:white_concrete
fill 455 121 245 457 122 245 minecraft:end_stone
fill 456 121 244 457 122 244 minecraft:end_stone
setblock 456 121 270 minecraft:white_concrete
setblock 458 121 231 minecraft:light[level=15]
setblock 458 121 239 minecraft:light[level=15]
setblock 458 121 247 minecraft:light[level=15]
setblock 458 121 255 minecraft:light[level=15]
setblock 458 121 263 minecraft:light[level=15]
setblock 464 121 270 minecraft:pearlescent_froglight
setblock 465 121 241 minecraft:pearlescent_froglight
fill 465 121 243 465 137 243 minecraft:black_concrete
setblock 465 121 254 minecraft:sea_lantern
setblock 465 121 259 minecraft:sea_lantern
setblock 465 121 266 minecraft:ochre_froglight
setblock 465 121 269 minecraft:pearlescent_froglight
setblock 423 122 243 minecraft:sea_lantern
fill 427 122 270 427 139 270 minecraft:black_concrete
setblock 428 122 228 minecraft:sea_lantern
setblock 431 122 228 minecraft:sea_lantern
fill 431 122 243 431 122 251 minecraft:white_concrete
fill 432 122 241 432 122 243 minecraft:white_concrete
fill 432 122 251 432 122 253 minecraft:white_concrete
fill 433 122 240 433 122 241 minecraft:white_concrete
fill 433 122 253 433 122 254 minecraft:white_concrete
fill 434 122 239 434 122 240 minecraft:white_concrete
fill 434 122 254 434 122 255 minecraft:white_concrete
fill 435 122 238 435 122 239 minecraft:white_concrete
fill 435 122 255 435 122 256 minecraft:white_concrete
fill 436 122 237 436 122 238 minecraft:white_concrete
fill 436 122 256 436 122 257 minecraft:white_concrete
fill 437 122 237 438 122 237 minecraft:white_concrete
fill 437 122 257 438 122 257 minecraft:white_concrete
fill 438 122 236 446 122 236 minecraft:white_concrete
fill 438 122 258 446 122 258 minecraft:white_concrete
fill 445 122 228 445 223 228 minecraft:black_concrete
fill 446 122 237 448 122 237 minecraft:white_concrete
fill 446 122 257 448 122 257 minecraft:white_concrete
fill 448 122 238 449 122 238 minecraft:white_concrete
fill 448 122 256 449 122 256 minecraft:white_concrete
fill 449 122 239 450 122 239 minecraft:white_concrete
fill 449 122 255 450 122 255 minecraft:white_concrete
fill 450 122 240 451 122 240 minecraft:white_concrete
fill 450 122 254 451 122 254 minecraft:white_concrete
fill 451 122 241 452 122 241 minecraft:white_concrete
fill 451 122 253 452 122 253 minecraft:white_concrete
fill 452 122 242 452 122 243 minecraft:white_concrete
fill 452 122 251 452 122 252 minecraft:white_concrete
fill 453 122 243 453 122 251 minecraft:white_concrete
fill 456 122 270 456 128 270 minecraft:black_concrete
fill 464 122 270 464 201 270 minecraft:black_concrete
setblock 465 122 232 minecraft:ochre_froglight
fill 465 122 241 465 148 241 minecraft:black_concrete
fill 465 122 254 465 176 254 minecraft:black_concrete
fill 465 122 259 465 134 259 minecraft:black_concrete
fill 465 122 266 465 127 266 minecraft:black_concrete
fill 465 122 269 465 129 269 minecraft:black_concrete
fill 423 123 243 423 154 243 minecraft:black_concrete
fill 428 123 228 428 190 228 minecraft:black_concrete
setblock 429 123 270 minecraft:blue_concrete
fill 430 123 244 430 123 250 minecraft:light_gray_concrete
fill 431 123 228 431 142 228 minecraft:black_concrete
setblock 431 123 242 minecraft:light_gray_concrete
fill 431 123 243 431 123 244 minecraft:white_concrete
fill 431 123 250 431 123 251 minecraft:white_concrete
setblock 431 123 252 minecraft:light_gray_concrete
setblock 432 123 240 minecraft:light_gray_concrete
setblock 432 123 241 minecraft:white_concrete
setblock 432 123 253 minecraft:iron_block
setblock 432 123 254 minecraft:light_gray_concrete
setblock 433 123 239 minecraft:light_gray_concrete
setblock 433 123 240 minecraft:white_concrete
setblock 433 123 254 minecraft:white_concrete
setblock 433 123 255 minecraft:light_gray_concrete
setblock 434 123 238 minecraft:light_gray_concrete
setblock 434 123 256 minecraft:light_gray_concrete
setblock 435 123 237 minecraft:light_gray_concrete
setblock 435 123 238 minecraft:white_concrete
setblock 435 123 256 minecraft:white_concrete
setblock 435 123 257 minecraft:light_gray_concrete
setblock 436 123 237 minecraft:white_concrete
setblock 436 123 257 minecraft:white_concrete
setblock 437 123 236 minecraft:light_gray_concrete
setblock 437 123 258 minecraft:light_gray_concrete
fill 438 123 236 439 123 236 minecraft:white_concrete
fill 438 123 258 439 123 258 minecraft:white_concrete
fill 439 123 235 445 123 235 minecraft:light_gray_concrete
fill 439 123 259 445 123 259 minecraft:light_gray_concrete
fill 442 123 236 442 124 236 minecraft:iron_block
fill 445 123 236 446 123 236 minecraft:white_concrete
fill 445 123 258 446 123 258 minecraft:white_concrete
setblock 447 123 236 minecraft:light_gray_concrete
setblock 447 123 258 minecraft:light_gray_concrete
setblock 448 123 237 minecraft:white_concrete
setblock 448 123 257 minecraft:white_concrete
setblock 448 123 270 minecraft:ochre_froglight
setblock 449 123 237 minecraft:light_gray_concrete
setblock 449 123 238 minecraft:white_concrete
setblock 449 123 256 minecraft:white_concrete
setblock 449 123 257 minecraft:light_gray_concrete
setblock 450 123 238 minecraft:light_gray_concrete
setblock 450 123 256 minecraft:light_gray_concrete
setblock 451 123 239 minecraft:light_gray_concrete
setblock 451 123 240 minecraft:white_concrete
setblock 451 123 254 minecraft:white_concrete
setblock 451 123 255 minecraft:light_gray_concrete
setblock 452 123 240 minecraft:light_gray_concrete
setblock 452 123 241 minecraft:white_concrete
fill 452 123 252 452 123 253 minecraft:iron_block
setblock 452 123 254 minecraft:light_gray_concrete
setblock 453 123 242 minecraft:light_gray_concrete
fill 453 123 243 453 123 244 minecraft:white_concrete
fill 453 123 250 453 123 251 minecraft:white_concrete
setblock 453 123 252 minecraft:light_gray_concrete
fill 454 123 244 454 123 250 minecraft:light_gray_concrete
setblock 460 123 228 minecraft:sea_lantern
fill 465 123 232 465 133 232 minecraft:black_concrete
setblock 423 124 230 minecraft:purple_terracotta
setblock 423 124 238 minecraft:sea_lantern
setblock 423 124 261 minecraft:blue_concrete
fill 429 124 270 429 199 270 minecraft:black_concrete
setblock 430 124 244 minecraft:light_gray_concrete
setblock 430 124 250 minecraft:light_gray_concrete
fill 433 124 252 433 124 253 minecraft:iron_block
setblock 439 124 235 minecraft:light_gray_concrete
setblock 439 124 259 minecraft:light_gray_concrete
setblock 440 124 228 minecraft:sea_lantern
fill 442 124 237 442 125 237 minecraft:iron_block
setblock 445 124 235 minecraft:light_gray_concrete
setblock 445 124 259 minecraft:light_gray_concrete
setblock 448 124 270 minecraft:white_concrete
setblock 451 124 252 minecraft:iron_block
setblock 454 124 244 minecraft:light_gray_concrete
setblock 454 124 250 minecraft:light_gray_concrete
setblock 455 124 270 minecraft:pearlescent_froglight
fill 460 124 228 460 128 228 minecraft:black_concrete
setblock 465 124 246 minecraft:sea_lantern
setblock 465 124 249 minecraft:blue_concrete
fill 423 125 230 423 161 230 minecraft:black_concrete
fill 423 125 238 423 165 238 minecraft:black_concrete
setblock 423 125 256 minecraft:sea_lantern
fill 423 125 261 423 197 261 minecraft:black_concrete
setblock 423 125 268 minecraft:sea_lantern
setblock 425 125 270 minecraft:pearlescent_froglight
setblock 434 125 252 minecraft:iron_block
setblock 437 125 270 minecraft:purple_terracotta
fill 440 125 228 440 169 228 minecraft:black_concrete
setblock 442 125 238 minecraft:iron_block
fill 448 125 270 448 126 270 minecraft:black_concrete
setblock 450 125 251 minecraft:iron_block
setblock 454 125 270 minecraft:white_concrete
fill 455 125 270 455 134 270 minecraft:black_concrete
setblock 465 125 230 minecraft:ochre_froglight
fill 465 125 246 465 151 247 minecraft:black_concrete
setblock 465 125 248 minecraft:sea_lantern
fill 465 125 249 465 152 249 minecraft:black_concrete
setblock 423 126 242 minecraft:sea_lantern
setblock 423 126 250 minecraft:white_concrete
fill 423 126 256 423 127 256 minecraft:black_concrete
fill 423 126 268 423 171 268 minecraft:black_concrete
fill 425 126 270 425 183 270 minecraft:black_concrete
setblock 426 126 231 minecraft:light[level=12]
setblock 426 126 238 minecraft:light[level=12]
setblock 426 126 245 minecraft:light[level=12]
setblock 426 126 252 minecraft:light[level=12]
setblock 426 126 259 minecraft:light[level=12]
setblock 426 126 266 minecraft:light[level=12]
setblock 433 126 231 minecraft:light[level=12]
setblock 433 126 238 minecraft:light[level=12]
setblock 433 126 245 minecraft:light[level=12]
setblock 433 126 252 minecraft:light[level=12]
setblock 433 126 259 minecraft:light[level=12]
setblock 433 126 266 minecraft:light[level=12]
fill 434 126 243 435 129 243 minecraft:andesite
fill 435 126 244 435 130 245 minecraft:andesite
setblock 435 126 251 minecraft:iron_block
fill 437 126 270 437 128 270 minecraft:black_concrete
setblock 440 126 231 minecraft:light[level=12]
setblock 440 126 238 minecraft:light[level=12]
setblock 440 126 245 minecraft:light[level=12]
setblock 440 126 252 minecraft:light[level=12]
setblock 440 126 259 minecraft:light[level=12]
setblock 440 126 266 minecraft:light[level=12]
setblock 442 126 239 minecraft:iron_block
setblock 447 126 231 minecraft:light[level=12]
setblock 447 126 238 minecraft:light[level=12]
setblock 447 126 245 minecraft:light[level=12]
setblock 447 126 252 minecraft:light[level=12]
setblock 447 126 259 minecraft:light[level=12]
setblock 447 126 266 minecraft:light[level=12]
setblock 449 126 251 minecraft:iron_block
setblock 454 126 231 minecraft:light[level=12]
setblock 454 126 238 minecraft:light[level=12]
setblock 454 126 245 minecraft:light[level=12]
setblock 454 126 252 minecraft:light[level=12]
setblock 454 126 259 minecraft:light[level=12]
setblock 454 126 266 minecraft:light[level=12]
fill 454 126 270 454 130 270 minecraft:black_concrete
setblock 461 126 231 minecraft:light[level=12]
setblock 461 126 238 minecraft:light[level=12]
setblock 461 126 245 minecraft:light[level=12]
setblock 461 126 252 minecraft:light[level=12]
setblock 461 126 259 minecraft:light[level=12]
setblock 461 126 266 minecraft:light[level=12]
fill 465 126 230 465 134 230 minecraft:black_concrete
setblock 465 126 238 minecraft:sea_lantern
fill 465 126 248 465 131 248 minecraft:black_concrete
fill 423 127 242 423 207 242 minecraft:black_concrete
setblock 423 127 249 minecraft:pearlescent_froglight
fill 423 127 250 423 157 250 minecraft:black_concrete
setblock 423 127 251 minecraft:sea_lantern
setblock 431 127 270 minecraft:ochre_froglight
fill 434 127 242 435 128 242 minecraft:andesite
fill 434 127 244 434 128 246 minecraft:andesite
fill 435 127 246 435 128 246 minecraft:andesite
fill 436 127 244 437 129 245 minecraft:andesite
setblock 436 127 251 minecraft:iron_block
setblock 442 127 240 minecraft:iron_block
setblock 446 127 270 minecraft:sea_lantern
setblock 448 127 250 minecraft:iron_block
setblock 448 127 270 minecraft:sea_lantern
fill 465 127 238 465 144 238 minecraft:black_concrete
setblock 465 127 256 minecraft:sea_lantern
setblock 465 127 260 minecraft:white_concrete
setblock 465 127 263 minecraft:ochre_froglight
setblock 423 128 229 minecraft:sea_lantern
setblock 423 128 245 minecraft:ochre_froglight
setblock 423 128 249 minecraft:magenta_terracotta
fill 423 128 251 423 168 251 minecraft:black_concrete
setblock 423 128 253 minecraft:pearlescent_froglight
setblock 423 128 256 minecraft:white_concrete
setblock 426 128 231 minecraft:light[level=15]
setblock 426 128 239 minecraft:light[level=15]
setblock 426 128 247 minecraft:light[level=15]
setblock 426 128 255 minecraft:light[level=15]
setblock 426 128 263 minecraft:light[level=15]
setblock 429 128 228 minecraft:ochre_froglight
fill 431 128 270 431 134 270 minecraft:black_concrete
setblock 434 128 231 minecraft:light[level=15]
setblock 434 128 239 minecraft:light[level=15]
setblock 434 128 247 minecraft:light[level=15]
setblock 434 128 255 minecraft:light[level=15]
setblock 434 128 263 minecraft:light[level=15]
fill 436 128 242 436 130 243 minecraft:andesite
fill 436 128 246 436 130 246 minecraft:andesite
fill 437 128 243 437 130 243 minecraft:andesite
setblock 438 128 228 minecraft:sea_lantern
setblock 438 128 244 minecraft:andesite
fill 439 128 228 439 171 228 minecraft:black_concrete
setblock 442 128 231 minecraft:light[level=15]
setblock 442 128 239 minecraft:light[level=15]
setblock 442 128 247 minecraft:light[level=15]
setblock 442 128 255 minecraft:light[level=15]
setblock 442 128 263 minecraft:light[level=15]
fill 446 128 270 446 146 270 minecraft:black_concrete
fill 448 128 270 448 155 270 minecraft:black_concrete
setblock 450 128 231 minecraft:light[level=15]
setblock 450 128 239 minecraft:light[level=15]
setblock 450 128 247 minecraft:light[level=15]
setblock 450 128 255 minecraft:light[level=15]
setblock 450 128 263 minecraft:light[level=15]
setblock 458 128 231 minecraft:light[level=15]
setblock 458 128 239 minecraft:light[level=15]
setblock 458 128 247 minecraft:light[level=15]
setblock 458 128 255 minecraft:light[level=15]
setblock 458 128 263 minecraft:light[level=15]
fill 465 128 256 465 138 256 minecraft:black_concrete
fill 465 128 260 465 132 260 minecraft:black_concrete
fill 465 128 263 465 149 263 minecraft:black_concrete
setblock 465 128 266 minecraft:white_concrete
setblock 465 128 267 minecraft:pearlescent_froglight
fill 423 129 229 423 132 229 minecraft:black_concrete
setblock 423 129 231 minecraft:white_concrete
setblock 423 129 239 minecraft:ochre_froglight
fill 423 129 245 423 139 245 minecraft:black_concrete
fill 423 129 249 423 142 249 minecraft:black_concrete
fill 423 129 253 423 175 253 minecraft:black_concrete
fill 423 129 256 423 137 256 minecraft:black_concrete
fill 429 129 228 429 159 228 minecraft:black_concrete
fill 434 129 244 434 129 245 minecraft:andesite
setblock 435 129 242 minecraft:andesite
fill 437 129 242 437 130 242 minecraft:andesite
setblock 437 129 270 minecraft:ochre_froglight
fill 438 129 228 438 144 228 minecraft:black_concrete
fill 448 129 256 449 130 256 minecraft:gray_concrete
setblock 449 129 270 minecraft:white_concrete
setblock 456 129 270 minecraft:ochre_froglight
fill 459 129 270 459 159 270 minecraft:black_concrete
setblock 460 129 228 minecraft:white_concrete
setblock 460 129 270 minecraft:white_concrete
setblock 465 129 229 minecraft:sea_lantern
setblock 465 129 257 minecraft:purple_concrete
fill 465 129 266 465 151 267 minecraft:black_concrete
fill 423 130 231 423 144 231 minecraft:black_concrete
fill 423 130 239 423 202 239 minecraft:black_concrete
fill 434 130 244 434 131 244 minecraft:andesite
setblock 435 130 243 minecraft:andesite
fill 436 130 244 436 130 245 minecraft:andesite
setblock 437 130 245 minecraft:andesite
fill 437 130 270 437 180 270 minecraft:black_concrete
fill 449 130 270 449 159 270 minecraft:black_concrete
fill 456 130 270 456 137 270 minecraft:black_concrete
setblock 458 130 228 minecraft:pearlescent_froglight
fill 460 130 228 460 209 228 minecraft:black_concrete
fill 460 130 270 460 141 270 minecraft:black_concrete
setblock 461 130 270 minecraft:sea_lantern
fill 465 130 229 465 141 229 minecraft:black_concrete
setblock 465 130 253 minecraft:sea_lantern
fill 465 130 257 465 176 257 minecraft:black_concrete
setblock 465 130 269 minecraft:ochre_froglight
setblock 427 131 228 minecraft:white_concrete
setblock 430 131 270 minecraft:white_concrete
setblock 435 131 244 minecraft:andesite
setblock 436 131 245 minecraft:andesite
setblock 454 131 270 minecraft:sea_lantern
setblock 455 131 228 minecraft:white_concrete
fill 458 131 228 458 198 228 minecraft:black_concrete
fill 461 131 270 461 167 270 minecraft:black_concrete
setblock 464 131 228 minecraft:purple_concrete
fill 465 131 253 465 183 253 minecraft:black_concrete
fill 465 131 269 465 172 269 minecraft:black_concrete
setblock 423 132 260 minecraft:sea_lantern
setblock 426 132 231 minecraft:light[level=12]
setblock 426 132 238 minecraft:light[level=12]
setblock 426 132 245 minecraft:light[level=12]
setblock 426 132 252 minecraft:light[level=12]
setblock 426 132 259 minecraft:light[level=12]
setblock 426 132 266 minecraft:light[level=12]
fill 427 132 228 427 177 228 minecraft:black_concrete
fill 430 132 270 430 179 270 minecraft:black_concrete
setblock 433 132 231 minecraft:light[level=12]
setblock 433 132 238 minecraft:light[level=12]
setblock 433 132 245 minecraft:light[level=12]
setblock 433 132 252 minecraft:light[level=12]
setblock 433 132 259 minecraft:light[level=12]
setblock 433 132 266 minecraft:light[level=12]
setblock 440 132 231 minecraft:light[level=12]
setblock 440 132 238 minecraft:light[level=12]
setblock 440 132 245 minecraft:light[level=12]
setblock 440 132 252 minecraft:light[level=12]
setblock 440 132 259 minecraft:light[level=12]
setblock 440 132 266 minecraft:light[level=12]
setblock 447 132 231 minecraft:light[level=12]
setblock 447 132 238 minecraft:light[level=12]
setblock 447 132 245 minecraft:light[level=12]
setblock 447 132 252 minecraft:light[level=12]
setblock 447 132 259 minecraft:light[level=12]
setblock 447 132 266 minecraft:light[level=12]
fill 453 132 243 453 135 244 minecraft:tuff
setblock 454 132 231 minecraft:light[level=12]
setblock 454 132 238 minecraft:light[level=12]
fill 454 132 244 454 135 244 minecraft:tuff
setblock 454 132 245 minecraft:light[level=12]
setblock 454 132 252 minecraft:light[level=12]
setblock 454 132 259 minecraft:light[level=12]
setblock 454 132 266 minecraft:light[level=12]
fill 454 132 270 454 179 270 minecraft:black_concrete
fill 455 132 228 455 143 228 minecraft:black_concrete
setblock 457 132 270 minecraft:sea_lantern
setblock 461 132 231 minecraft:light[level=12]
setblock 461 132 238 minecraft:light[level=12]
setblock 461 132 245 minecraft:light[level=12]
setblock 461 132 252 minecraft:light[level=12]
setblock 461 132 259 minecraft:light[level=12]
setblock 461 132 266 minecraft:light[level=12]
fill 464 132 228 464 159 228 minecraft:black_concrete
setblock 465 132 242 minecraft:purple_concrete
setblock 465 132 248 minecraft:blue_concrete
setblock 423 133 229 minecraft:blue_concrete
setblock 423 133 235 minecraft:pearlescent_froglight
setblock 423 133 259 minecraft:blue_concrete
fill 423 133 260 423 179 260 minecraft:black_concrete
fill 452 133 243 452 134 245 minecraft:tuff
fill 453 133 245 454 134 245 minecraft:tuff
fill 454 133 243 454 134 243 minecraft:tuff
fill 457 133 270 457 150 270 minecraft:black_concrete
fill 465 133 242 465 135 242 minecraft:black_concrete
setblock 465 133 248 minecraft:magenta_terracotta
setblock 465 133 260 minecraft:purple_concrete
fill 423 134 229 423 143 229 minecraft:black_concrete
fill 423 134 235 423 147 235 minecraft:black_concrete
fill 423 134 259 423 136 259 minecraft:black_concrete
setblock 443 134 270 minecraft:ochre_froglight
setblock 454 134 228 minecraft:ochre_froglight
setblock 465 134 232 minecraft:ochre_froglight
fill 465 134 248 465 149 248 minecraft:black_concrete
setblock 465 134 250 minecraft:pearlescent_froglight
fill 465 134 260 465 204 260 minecraft:black_concrete
setblock 426 135 231 minecraft:light[level=15]
setblock 426 135 239 minecraft:light[level=15]
setblock 426 135 247 minecraft:light[level=15]
setblock 426 135 255 minecraft:light[level=15]
setblock 426 135 263 minecraft:light[level=15]
setblock 431 135 270 minecraft:ochre_froglight
setblock 434 135 231 minecraft:light[level=15]
setblock 434 135 239 minecraft:light[level=15]
setblock 434 135 247 minecraft:light[level=15]
setblock 434 135 255 minecraft:light[level=15]
setblock 434 135 263 minecraft:light[level=15]
setblock 441 135 228 minecraft:purple_concrete
setblock 442 135 231 minecraft:light[level=15]
setblock 442 135 239 minecraft:light[level=15]
setblock 442 135 247 minecraft:light[level=15]
setblock 442 135 255 minecraft:light[level=15]
setblock 442 135 263 minecraft:light[level=15]
fill 443 135 270 443 140 270 minecraft:black_concrete
fill 444 135 260 446 137 261 minecraft:cobbled_deepslate
setblock 444 135 270 minecraft:ochre_froglight
fill 445 135 259 446 138 259 minecraft:cobbled_deepslate
setblock 447 135 270 minecraft:ochre_froglight
setblock 449 135 228 minecraft:white_concrete
setblock 450 135 231 minecraft:light[level=15]
setblock 450 135 239 minecraft:light[level=15]
setblock 450 135 247 minecraft:light[level=15]
setblock 450 135 255 minecraft:light[level=15]
setblock 450 135 263 minecraft:light[level=15]
setblock 452 135 244 minecraft:tuff
fill 454 135 228 454 197 228 minecraft:black_concrete
setblock 455 135 270 minecraft:pearlescent_froglight
setblock 458 135 231 minecraft:light[level=15]
setblock 458 135 239 minecraft:light[level=15]
setblock 458 135 247 minecraft:light[level=15]
setblock 458 135 255 minecraft:light[level=15]
setblock 458 135 263 minecraft:light[level=15]
setblock 465 135 230 minecraft:purple_concrete
fill 465 135 232 465 156 232 minecraft:black_concrete
fill 465 135 250 465 147 250 minecraft:black_concrete
setblock 465 135 259 minecraft:ochre_froglight
setblock 423 136 233 minecraft:purple_terracotta
setblock 423 136 237 minecraft:ochre_froglight
setblock 423 136 248 minecraft:sea_lantern
setblock 430 136 228 minecraft:ochre_froglight
fill 431 136 270 431 222 270 minecraft:black_concrete
setblock 435 136 270 minecraft:ochre_froglight
fill 438 136 270 438 140 270 minecraft:black_concrete
setblock 439 136 270 minecraft:ochre_froglight
fill 441 136 228 441 169 228 minecraft:black_concrete
fill 444 136 259 444 137 259 minecraft:cobbled_deepslate
fill 444 136 270 444 154 270 minecraft:black_concrete
fill 445 136 262 445 137 262 minecraft:cobbled_deepslate
fill 447 136 259 447 137 260 minecraft:cobbled_deepslate
fill 447 136 270 447 161 270 minecraft:black_concrete
fill 449 136 228 449 308 228 minecraft:black_concrete
fill 455 136 270 455 138 270 minecraft:black_concrete
fill 465 136 230 465 170 230 minecraft:black_concrete
setblock 465 136 242 minecraft:sea_lantern
fill 465 136 259 465 203 259 minecraft:black_concrete
fill 423 137 233 423 152 233 minecraft:black_concrete
fill 423 137 237 423 225 237 minecraft:black_concrete
setblock 423 137 246 minecraft:magenta_terracotta
setblock 423 137 248 minecraft:pearlescent_froglight
setblock 423 137 259 minecraft:white_concrete
setblock 430 137 228 minecraft:black_concrete
fill 435 137 270 435 160 270 minecraft:black_concrete
fill 439 137 270 439 145 270 minecraft:black_concrete
setblock 446 137 262 minecraft:cobbled_deepslate
setblock 450 137 228 minecraft:white_concrete
fill 462 137 228 462 223 228 minecraft:black_concrete
setblock 463 137 228 minecraft:ochre_froglight
fill 465 137 242 465 165 242 minecraft:black_concrete
fill 423 138 246 423 158 246 minecraft:black_concrete
fill 423 138 248 423 200 248 minecraft:black_concrete
setblock 423 138 256 minecraft:white_concrete
fill 423 138 259 423 234 259 minecraft:black_concrete
setblock 426 138 231 minecraft:light[level=12]
setblock 426 138 238 minecraft:light[level=12]
setblock 426 138 245 minecraft:light[level=12]
setblock 426 138 252 minecraft:light[level=12]
setblock 426 138 259 minecraft:light[level=12]
setblock 426 138 266 minecraft:light[level=12]
setblock 430 138 228 minecraft:blue_concrete
setblock 433 138 231 minecraft:light[level=12]
setblock 433 138 238 minecraft:light[level=12]
setblock 433 138 245 minecraft:light[level=12]
setblock 433 138 252 minecraft:light[level=12]
setblock 433 138 259 minecraft:light[level=12]
setblock 433 138 266 minecraft:light[level=12]
setblock 434 138 228 minecraft:pearlescent_froglight
setblock 440 138 231 minecraft:light[level=12]
setblock 440 138 238 minecraft:light[level=12]
setblock 440 138 245 minecraft:light[level=12]
setblock 440 138 252 minecraft:light[level=12]
setblock 440 138 259 minecraft:light[level=12]
setblock 440 138 266 minecraft:light[level=12]
fill 445 138 260 446 138 261 minecraft:cobbled_deepslate
setblock 447 138 231 minecraft:light[level=12]
setblock 447 138 238 minecraft:light[level=12]
setblock 447 138 245 minecraft:light[level=12]
setblock 447 138 252 minecraft:light[level=12]
setblock 447 138 259 minecraft:light[level=12]
setblock 447 138 266 minecraft:light[level=12]
fill 450 138 228 450 203 228 minecraft:black_concrete
setblock 454 138 231 minecraft:light[level=12]
setblock 454 138 238 minecraft:light[level=12]
setblock 454 138 245 minecraft:light[level=12]
setblock 454 138 252 minecraft:light[level=12]
setblock 454 138 259 minecraft:light[level=12]
setblock 454 138 266 minecraft:light[level=12]
setblock 456 138 270 minecraft:white_concrete
setblock 457 138 228 minecraft:pearlescent_froglight
setblock 461 138 231 minecraft:light[level=12]
setblock 461 138 238 minecraft:light[level=12]
setblock 461 138 245 minecraft:light[level=12]
setblock 461 138 252 minecraft:light[level=12]
setblock 461 138 259 minecraft:light[level=12]
setblock 461 138 266 minecraft:light[level=12]
fill 463 138 228 463 150 228 minecraft:black_concrete
setblock 465 138 243 minecraft:magenta_terracotta
fill 423 139 256 423 153 256 minecraft:black_concrete
fill 430 139 228 430 164 228 minecraft:black_concrete
fill 434 139 228 434 199 228 minecraft:black_concrete
setblock 451 139 270 minecraft:purple_concrete
setblock 455 139 270 minecraft:sea_lantern
fill 456 139 270 456 152 270 minecraft:black_concrete
fill 457 139 228 457 170 228 minecraft:black_concrete
fill 465 139 243 465 166 243 minecraft:black_concrete
setblock 465 139 256 minecraft:blue_concrete
setblock 423 140 240 minecraft:white_concrete
setblock 423 140 245 minecraft:pearlescent_froglight
setblock 427 140 270 minecraft:pearlescent_froglight
fill 451 140 270 451 178 270 minecraft:black_concrete
fill 455 140 270 455 168 270 minecraft:black_concrete
fill 465 140 256 465 179 256 minecraft:black_concrete
fill 423 141 240 423 267 240 minecraft:black_concrete
fill 423 141 245 423 194 245 minecraft:black_concrete
fill 427 141 270 427 193 270 minecraft:black_concrete
setblock 438 141 270 minecraft:magenta_terracotta
setblock 443 141 270 minecraft:ochre_froglight
setblock 458 141 270 minecraft:pearlescent_froglight
setblock 423 142 255 minecraft:pearlescent_froglight
setblock 426 142 231 minecraft:light[level=15]
setblock 426 142 239 minecraft:light[level=15]
setblock 426 142 247 minecraft:light[level=15]
setblock 426 142 255 minecraft:light[level=15]
setblock 426 142 263 minecraft:light[level=15]
setblock 434 142 231 minecraft:light[level=15]
setblock 434 142 239 minecraft:light[level=15]
setblock 434 142 247 minecraft:light[level=15]
setblock 434 142 255 minecraft:light[level=15]
setblock 434 142 263 minecraft:light[level=15]
fill 438 142 270 438 150 270 minecraft:black_concrete
setblock 442 142 231 minecraft:light[level=15]
setblock 442 142 239 minecraft:light[level=15]
setblock 442 142 247 minecraft:light[level=15]
setblock 442 142 255 minecraft:light[level=15]
setblock 442 142 263 minecraft:light[level=15]
fill 443 142 270 443 146 270 minecraft:black_concrete
setblock 450 142 231 minecraft:light[level=15]
setblock 450 142 239 minecraft:light[level=15]
setblock 450 142 247 minecraft:light[level=15]
setblock 450 142 255 minecraft:light[level=15]
setblock 450 142 263 minecraft:light[level=15]
setblock 458 142 231 minecraft:light[level=15]
setblock 458 142 239 minecraft:light[level=15]
setblock 458 142 247 minecraft:light[level=15]
setblock 458 142 255 minecraft:light[level=15]
setblock 458 142 263 minecraft:light[level=15]
fill 458 142 270 458 155 270 minecraft:black_concrete
setblock 460 142 270 minecraft:ochre_froglight
setblock 465 142 229 minecraft:pearlescent_froglight
setblock 423 143 249 minecraft:white_concrete
fill 423 143 255 423 207 255 minecraft:black_concrete
setblock 423 143 264 minecraft:sea_lantern
setblock 431 143 228 minecraft:sea_lantern
fill 460 143 270 460 146 270 minecraft:black_concrete
fill 465 143 229 465 193 229 minecraft:black_concrete
setblock 423 144 229 minecraft:sea_lantern
fill 423 144 249 423 200 249 minecraft:black_concrete
fill 423 144 264 423 156 264 minecraft:black_concrete
setblock 426 144 231 minecraft:light[level=12]
setblock 426 144 238 minecraft:light[level=12]
setblock 426 144 245 minecraft:light[level=12]
setblock 426 144 252 minecraft:light[level=12]
setblock 426 144 259 minecraft:light[level=12]
setblock 426 144 266 minecraft:light[level=12]
fill 431 144 228 431 162 228 minecraft:black_concrete
setblock 433 144 231 minecraft:light[level=12]
setblock 433 144 238 minecraft:light[level=12]
setblock 433 144 245 minecraft:light[level=12]
setblock 433 144 252 minecraft:light[level=12]
setblock 433 144 259 minecraft:light[level=12]
setblock 433 144 266 minecraft:light[level=12]
setblock 440 144 231 minecraft:light[level=12]
setblock 440 144 238 minecraft:light[level=12]
setblock 440 144 245 minecraft:light[level=12]
setblock 440 144 252 minecraft:light[level=12]
setblock 440 144 259 minecraft:light[level=12]
setblock 440 144 266 minecraft:light[level=12]
setblock 447 144 231 minecraft:light[level=12]
setblock 447 144 238 minecraft:light[level=12]
setblock 447 144 245 minecraft:light[level=12]
setblock 447 144 252 minecraft:light[level=12]
setblock 447 144 259 minecraft:light[level=12]
setblock 447 144 266 minecraft:light[level=12]
fill 450 144 242 452 145 242 minecraft:gray_concrete
fill 451 144 241 452 145 241 minecraft:gray_concrete
setblock 452 144 270 minecraft:white_concrete
setblock 454 144 231 minecraft:light[level=12]
setblock 454 144 238 minecraft:light[level=12]
setblock 454 144 245 minecraft:light[level=12]
setblock 454 144 252 minecraft:light[level=12]
setblock 454 144 259 minecraft:light[level=12]
setblock 454 144 266 minecraft:light[level=12]
setblock 455 144 228 minecraft:sea_lantern
fill 458 144 257 459 145 258 minecraft:end_stone
setblock 461 144 231 minecraft:light[level=12]
setblock 461 144 238 minecraft:light[level=12]
setblock 461 144 245 minecraft:light[level=12]
setblock 461 144 252 minecraft:light[level=12]
setblock 461 144 259 minecraft:light[level=12]
setblock 461 144 266 minecraft:light[level=12]
setblock 465 144 231 minecraft:ochre_froglight
fill 423 145 229 423 154 229 minecraft:black_concrete
setblock 423 145 231 minecraft:pearlescent_froglight
fill 432 145 254 433 146 255 minecraft:end_stone
setblock 438 145 228 minecraft:ochre_froglight
setblock 446 145 228 minecraft:pearlescent_froglight
fill 452 145 270 452 196 270 minecraft:black_concrete
fill 455 145 228 455 152 228 minecraft:black_concrete
setblock 456 145 228 minecraft:magenta_terracotta
fill 465 145 231 465 150 231 minecraft:black_concrete
setblock 465 145 238 minecraft:purple_concrete
fill 423 146 231 423 173 231 minecraft:black_concrete
setblock 423 146 236 minecraft:white_concrete
fill 438 146 228 438 184 228 minecraft:black_concrete
setblock 439 146 270 minecraft:sea_lantern
fill 446 146 228 446 166 228 minecraft:black_concrete
setblock 448 146 228 minecraft:magenta_terracotta
fill 456 146 228 456 166 228 minecraft:black_concrete
fill 465 146 238 465 153 238 minecraft:black_concrete
fill 423 147 236 423 174 236 minecraft:black_concrete
fill 439 147 270 439 163 270 minecraft:black_concrete
setblock 443 147 270 minecraft:purple_terracotta
setblock 446 147 270 minecraft:white_concrete
fill 448 147 228 448 162 228 minecraft:black_concrete
setblock 460 147 270 minecraft:ochre_froglight
setblock 465 147 233 minecraft:ochre_froglight
setblock 423 148 232 minecraft:pearlescent_froglight
setblock 423 148 235 minecraft:pearlescent_froglight
fill 443 148 270 443 164 270 minecraft:black_concrete
setblock 446 148 270 minecraft:magenta_terracotta
fill 453 148 265 454 149 265 minecraft:end_stone
fill 455 148 256 455 149 256 minecraft:pearlescent_froglight
fill 460 148 270 460 273 270 minecraft:black_concrete
fill 465 148 233 465 157 233 minecraft:black_concrete
setblock 465 148 250 minecraft:blue_concrete
fill 423 149 232 423 168 232 minecraft:black_concrete
fill 423 149 235 423 184 235 minecraft:black_concrete
setblock 423 149 258 minecraft:sea_lantern
setblock 426 149 231 minecraft:light[level=15]
setblock 426 149 239 minecraft:light[level=15]
setblock 426 149 247 minecraft:light[level=15]
setblock 426 149 255 minecraft:light[level=15]
setblock 426 149 263 minecraft:light[level=15]
setblock 434 149 231 minecraft:light[level=15]
setblock 434 149 239 minecraft:light[level=15]
setblock 434 149 247 minecraft:light[level=15]
setblock 434 149 255 minecraft:light[level=15]
setblock 434 149 263 minecraft:light[level=15]
setblock 442 149 231 minecraft:light[level=15]
setblock 442 149 239 minecraft:light[level=15]
setblock 442 149 247 minecraft:light[level=15]
setblock 442 149 255 minecraft:light[level=15]
setblock 442 149 263 minecraft:light[level=15]
fill 446 149 270 446 169 270 minecraft:black_concrete
setblock 450 149 231 minecraft:light[level=15]
setblock 450 149 239 minecraft:light[level=15]
setblock 450 149 247 minecraft:light[level=15]
setblock 450 149 255 minecraft:light[level=15]
setblock 450 149 263 minecraft:light[level=15]
setblock 458 149 231 minecraft:light[level=15]
setblock 458 149 239 minecraft:light[level=15]
setblock 458 149 247 minecraft:light[level=15]
setblock 458 149 255 minecraft:light[level=15]
setblock 458 149 263 minecraft:light[level=15]
fill 465 149 240 465 149 241 minecraft:ochre_froglight
fill 465 149 250 465 178 250 minecraft:black_concrete
setblock 465 149 258 minecraft:sea_lantern
fill 423 150 258 423 156 258 minecraft:black_concrete
setblock 426 150 231 minecraft:light[level=12]
setblock 426 150 238 minecraft:light[level=12]
setblock 426 150 245 minecraft:light[level=12]
setblock 426 150 252 minecraft:light[level=12]
setblock 426 150 259 minecraft:light[level=12]
setblock 426 150 266 minecraft:light[level=12]
setblock 433 150 231 minecraft:light[level=12]
setblock 433 150 238 minecraft:light[level=12]
setblock 433 150 245 minecraft:light[level=12]
setblock 433 150 252 minecraft:light[level=12]
setblock 433 150 259 minecraft:light[level=12]
setblock 433 150 266 minecraft:light[level=12]
setblock 440 150 231 minecraft:light[level=12]
setblock 440 150 238 minecraft:light[level=12]
setblock 440 150 245 minecraft:light[level=12]
setblock 440 150 252 minecraft:light[level=12]
setblock 440 150 259 minecraft:light[level=12]
setblock 440 150 266 minecraft:light[level=12]
setblock 443 150 228 minecraft:ochre_froglight
setblock 447 150 231 minecraft:light[level=12]
setblock 447 150 238 minecraft:light[level=12]
setblock 447 150 245 minecraft:light[level=12]
setblock 447 150 252 minecraft:light[level=12]
setblock 447 150 259 minecraft:light[level=12]
setblock 447 150 266 minecraft:light[level=12]
setblock 454 150 231 minecraft:light[level=12]
setblock 454 150 238 minecraft:light[level=12]
setblock 454 150 245 minecraft:light[level=12]
setblock 454 150 252 minecraft:light[level=12]
setblock 454 150 259 minecraft:light[level=12]
setblock 454 150 266 minecraft:light[level=12]
fill 455 150 256 455 157 256 minecraft:gray_concrete
setblock 461 150 231 minecraft:light[level=12]
setblock 461 150 238 minecraft:light[level=12]
setblock 461 150 245 minecraft:light[level=12]
setblock 461 150 252 minecraft:light[level=12]
setblock 461 150 259 minecraft:light[level=12]
setblock 461 150 266 minecraft:light[level=12]
fill 465 150 240 465 159 241 minecraft:black_concrete
setblock 465 150 248 minecraft:ochre_froglight
setblock 465 150 252 minecraft:sea_lantern
fill 465 150 258 465 151 258 minecraft:black_concrete
setblock 465 150 263 minecraft:sea_lantern
setblock 465 150 268 minecraft:ochre_froglight
setblock 423 151 265 minecraft:white_concrete
setblock 438 151 270 minecraft:sea_lantern
fill 443 151 228 443 188 228 minecraft:black_concrete
fill 454 151 256 454 157 257 minecraft:gray_concrete
fill 455 151 257 455 157 257 minecraft:gray_concrete
setblock 457 151 270 minecraft:purple_concrete
fill 460 151 267 464 152 267 minecraft:light_blue_concrete
setblock 460 151 268 minecraft:white_concrete
fill 461 151 266 464 151 266 minecraft:light_blue_concrete
fill 461 151 268 461 153 269 minecraft:light_blue_concrete
fill 462 151 265 462 153 265 minecraft:light_blue_concrete
setblock 462 151 268 minecraft:white_concrete
fill 462 151 269 464 151 269 minecraft:light_blue_concrete
setblock 463 151 228 minecraft:white_concrete
setblock 463 151 265 minecraft:white_concrete
fill 463 151 268 463 153 268 minecraft:light_blue_concrete
setblock 464 151 268 minecraft:white_concrete
fill 465 151 231 465 152 231 minecraft:sea_lantern
fill 465 151 248 465 156 248 minecraft:black_concrete
fill 465 151 252 465 208 252 minecraft:black_concrete
fill 465 151 263 465 186 263 minecraft:black_concrete
fill 465 151 268 465 208 268 minecraft:black_concrete
setblock 423 152 265 minecraft:black_concrete
fill 438 152 270 438 214 270 minecraft:black_concrete
fill 447 152 265 449 154 267 minecraft:gold_block
fill 457 152 270 457 213 270 minecraft:black_concrete
fill 459 152 265 461 153 265 minecraft:light_blue_concrete
setblock 459 152 266 minecraft:white_concrete
fill 459 152 267 459 152 269 minecraft:light_blue_concrete
fill 460 152 264 464 152 264 minecraft:light_blue_concrete
fill 460 152 266 460 154 266 minecraft:light_blue_concrete
fill 460 152 268 460 156 268 minecraft:light_blue_concrete
setblock 460 152 269 minecraft:white_concrete
setblock 461 152 266 minecraft:white_concrete
fill 462 152 266 462 154 266 minecraft:light_blue_concrete
fill 462 152 268 462 156 268 minecraft:light_blue_concrete
setblock 462 152 269 minecraft:white_concrete
fill 463 152 228 463 155 228 minecraft:black_concrete
fill 463 152 265 464 153 265 minecraft:light_blue_concrete
setblock 463 152 266 minecraft:white_concrete
fill 463 152 269 463 154 269 minecraft:light_blue_concrete
fill 464 152 266 464 154 266 minecraft:light_blue_concrete
fill 464 152 268 464 156 268 minecraft:light_blue_concrete
setblock 464 152 269 minecraft:white_concrete
setblock 465 152 246 minecraft:sea_lantern
fill 465 152 247 465 161 247 minecraft:black_concrete
setblock 465 152 258 minecraft:purple_concrete
setblock 465 152 266 minecraft:white_concrete
fill 465 152 267 465 168 267 minecraft:black_concrete
setblock 423 153 233 minecraft:pearlescent_froglight
setblock 423 153 265 minecraft:white_concrete
setblock 435 153 228 minecraft:purple_concrete
fill 442 153 265 446 153 267 minecraft:blue_stained_glass
fill 450 153 265 454 153 267 minecraft:blue_stained_glass
fill 453 153 256 453 157 257 minecraft:gray_concrete
fill 454 153 255 455 157 255 minecraft:gray_concrete
fill 454 153 258 455 157 258 minecraft:gray_concrete
setblock 455 153 228 minecraft:sea_lantern
fill 456 153 256 456 157 257 minecraft:gray_concrete
setblock 456 153 270 minecraft:sea_lantern
fill 458 153 265 458 153 269 minecraft:light_blue_concrete
fill 459 153 264 459 155 264 minecraft:light_blue_concrete
fill 459 153 266 459 157 266 minecraft:light_blue_concrete
setblock 459 153 267 minecraft:white_concrete
fill 459 153 268 459 153 269 minecraft:light_blue_concrete
fill 460 153 263 464 154 263 minecraft:light_blue_concrete
setblock 460 153 264 minecraft:white_concrete
fill 460 153 267 460 155 267 minecraft:light_blue_concrete
fill 460 153 269 460 157 269 minecraft:light_blue_concrete
fill 461 153 264 461 155 264 minecraft:light_blue_concrete
fill 461 153 266 461 157 266 minecraft:light_blue_concrete
setblock 461 153 267 minecraft:white_concrete
setblock 462 153 264 minecraft:white_concrete
fill 462 153 267 462 155 267 minecraft:light_blue_concrete
fill 462 153 269 462 157 269 minecraft:light_blue_concrete
fill 463 153 264 463 155 264 minecraft:light_blue_concrete
fill 463 153 266 463 157 266 minecraft:light_blue_concrete
setblock 463 153 267 minecraft:white_concrete
setblock 464 153 264 minecraft:white_concrete
fill 464 153 267 464 155 267 minecraft:light_blue_concrete
fill 464 153 269 464 157 269 minecraft:light_blue_concrete
fill 465 153 231 465 163 231 minecraft:black_concrete
fill 465 153 246 465 185 246 minecraft:black_concrete
setblock 465 153 249 minecraft:white_concrete
fill 465 153 258 465 225 258 minecraft:black_concrete
fill 465 153 266 465 165 266 minecraft:black_concrete
fill 423 154 233 423 271 233 minecraft:black_concrete
setblock 423 154 254 minecraft:magenta_terracotta
setblock 423 154 256 minecraft:magenta_terracotta
fill 423 154 265 423 162 265 minecraft:black_concrete
fill 435 154 228 435 199 228 minecraft:black_concrete
fill 453 154 255 453 157 255 minecraft:gray_concrete
fill 455 154 228 455 159 228 minecraft:black_concrete
fill 456 154 255 456 157 255 minecraft:gray_concrete
fill 456 154 258 456 157 258 minecraft:gray_concrete
fill 456 154 270 456 187 270 minecraft:black_concrete
fill 457 154 265 457 156 267 minecraft:light_blue_concrete
setblock 457 154 268 minecraft:white_concrete
fill 457 154 269 459 154 269 minecraft:light_blue_concrete
fill 458 154 264 458 158 264 minecraft:light_blue_concrete
setblock 458 154 265 minecraft:white_concrete
fill 458 154 266 458 154 268 minecraft:light_blue_concrete
setblock 459 154 263 minecraft:light_blue_concrete
fill 459 154 265 459 156 265 minecraft:light_blue_concrete
fill 459 154 267 459 158 267 minecraft:light_blue_concrete
setblock 459 154 268 minecraft:white_concrete
fill 460 154 258 461 155 258 minecraft:end_stone
fill 460 154 262 460 156 262 minecraft:light_blue_concrete
fill 460 154 264 460 158 264 minecraft:light_blue_concrete
setblock 460 154 265 minecraft:white_concrete
setblock 461 154 262 minecraft:white_concrete
fill 461 154 265 461 156 265 minecraft:light_blue_concrete
fill 461 154 267 461 158 267 minecraft:light_blue_concrete
setblock 461 154 268 minecraft:white_concrete
setblock 461 154 269 minecraft:light_blue_concrete
fill 462 154 262 462 156 262 minecraft:light_blue_concrete
fill 462 154 264 462 158 264 minecraft:light_blue_concrete
setblock 462 154 265 minecraft:white_concrete
setblock 463 154 262 minecraft:white_concrete
fill 463 154 265 463 156 265 minecraft:light_blue_concrete
fill 463 154 267 463 158 267 minecraft:light_blue_concrete
setblock 463 154 268 minecraft:white_concrete
fill 464 154 262 464 156 262 minecraft:light_blue_concrete
fill 464 154 264 464 158 264 minecraft:light_blue_concrete
setblock 464 154 265 minecraft:white_concrete
setblock 465 154 238 minecraft:white_concrete
fill 465 154 249 465 155 249 minecraft:black_concrete
setblock 423 155 229 minecraft:pearlescent_froglight
setblock 423 155 243 minecraft:white_concrete
fill 423 155 254 423 179 254 minecraft:black_concrete
fill 423 155 256 423 159 256 minecraft:black_concrete
setblock 444 155 270 minecraft:ochre_froglight
fill 448 155 266 448 156 266 minecraft:iron_bars
fill 452 155 256 452 157 257 minecraft:gray_concrete
fill 453 155 258 453 157 258 minecraft:gray_concrete
fill 454 155 254 456 157 254 minecraft:gray_concrete
fill 454 155 259 455 157 259 minecraft:gray_concrete
fill 456 155 267 456 155 268 minecraft:light_blue_concrete
fill 457 155 256 457 157 257 minecraft:gray_concrete
setblock 457 155 264 minecraft:light_blue_concrete
fill 457 155 268 459 156 268 minecraft:light_blue_concrete
setblock 457 155 269 minecraft:white_concrete
fill 458 155 263 458 157 263 minecraft:light_blue_concrete
fill 458 155 265 458 159 265 minecraft:light_blue_concrete
setblock 458 155 266 minecraft:white_concrete
setblock 458 155 267 minecraft:light_blue_concrete
fill 458 155 269 458 157 269 minecraft:light_blue_concrete
fill 459 155 262 459 159 262 minecraft:light_blue_concrete
setblock 459 155 263 minecraft:white_concrete
setblock 459 155 269 minecraft:white_concrete
fill 460 155 263 460 157 263 minecraft:light_blue_concrete
fill 460 155 265 460 159 265 minecraft:light_blue_concrete
setblock 460 155 266 minecraft:white_concrete
fill 461 155 262 461 159 262 minecraft:light_blue_concrete
setblock 461 155 263 minecraft:white_concrete
fill 461 155 268 461 159 268 minecraft:light_blue_concrete
setblock 461 155 269 minecraft:white_concrete
fill 462 155 261 463 155 261 minecraft:light_blue_concrete
fill 462 155 263 462 157 263 minecraft:light_blue_concrete
fill 462 155 265 462 159 265 minecraft:light_blue_concrete
setblock 462 155 266 minecraft:white_concrete
fill 463 155 262 463 159 262 minecraft:light_blue_concrete
setblock 463 155 263 minecraft:white_concrete
fill 463 155 268 463 159 268 minecraft:light_blue_concrete
setblock 463 155 269 minecraft:white_concrete
fill 464 155 263 464 157 263 minecraft:light_blue_concrete
fill 464 155 265 464 159 265 minecraft:light_blue_concrete
setblock 464 155 266 minecraft:white_concrete
fill 465 155 238 465 182 238 minecraft:black_concrete
fill 423 156 229 423 229 229 minecraft:black_concrete
setblock 423 156 234 minecraft:pearlescent_froglight
fill 423 156 243 423 252 243 minecraft:black_concrete
setblock 426 156 231 minecraft:light[level=15]
setblock 426 156 238 minecraft:light[level=12]
setblock 426 156 239 minecraft:light[level=15]
setblock 426 156 245 minecraft:light[level=12]
setblock 426 156 247 minecraft:light[level=15]
setblock 426 156 252 minecraft:light[level=12]
setblock 426 156 255 minecraft:light[level=15]
setblock 426 156 259 minecraft:light[level=12]
setblock 426 156 263 minecraft:light[level=15]
setblock 426 156 266 minecraft:light[level=12]
setblock 433 156 231 minecraft:light[level=12]
setblock 433 156 238 minecraft:light[level=12]
setblock 433 156 245 minecraft:light[level=12]
setblock 433 156 252 minecraft:light[level=12]
setblock 433 156 259 minecraft:light[level=12]
setblock 433 156 266 minecraft:light[level=12]
setblock 434 156 231 minecraft:light[level=15]
setblock 434 156 239 minecraft:light[level=15]
setblock 434 156 247 minecraft:light[level=15]
setblock 434 156 255 minecraft:light[level=15]
setblock 434 156 263 minecraft:light[level=15]
setblock 440 156 231 minecraft:light[level=12]
setblock 440 156 238 minecraft:light[level=12]
setblock 440 156 245 minecraft:light[level=12]
setblock 440 156 252 minecraft:light[level=12]
setblock 440 156 259 minecraft:light[level=12]
setblock 440 156 266 minecraft:light[level=12]
setblock 442 156 231 minecraft:light[level=15]
setblock 442 156 239 minecraft:light[level=15]
setblock 442 156 247 minecraft:light[level=15]
setblock 442 156 255 minecraft:light[level=15]
setblock 442 156 263 minecraft:light[level=15]
fill 444 156 270 444 165 270 minecraft:black_concrete
setblock 447 156 231 minecraft:light[level=12]
setblock 447 156 238 minecraft:light[level=12]
setblock 447 156 245 minecraft:light[level=12]
setblock 447 156 252 minecraft:light[level=12]
setblock 447 156 259 minecraft:light[level=12]
setblock 447 156 266 minecraft:light[level=12]
setblock 448 156 270 minecraft:white_concrete
setblock 450 156 231 minecraft:light[level=15]
setblock 450 156 239 minecraft:light[level=15]
setblock 450 156 247 minecraft:light[level=15]
setblock 450 156 255 minecraft:light[level=15]
setblock 450 156 263 minecraft:light[level=15]
fill 452 156 255 452 157 255 minecraft:gray_concrete
fill 452 156 258 452 157 258 minecraft:gray_concrete
fill 453 156 254 453 157 254 minecraft:gray_concrete
fill 453 156 259 453 157 259 minecraft:gray_concrete
setblock 454 156 231 minecraft:light[level=12]
setblock 454 156 238 minecraft:light[level=12]
setblock 454 156 245 minecraft:light[level=12]
setblock 454 156 252 minecraft:light[level=12]
setblock 454 156 266 minecraft:light[level=12]
fill 456 156 259 456 157 259 minecraft:gray_concrete
fill 456 156 266 456 159 266 minecraft:light_blue_concrete
setblock 456 156 267 minecraft:white_concrete
fill 456 156 268 456 156 269 minecraft:light_blue_concrete
fill 457 156 255 457 157 255 minecraft:gray_concrete
fill 457 156 258 457 157 258 minecraft:gray_concrete
setblock 457 156 264 minecraft:white_concrete
fill 457 156 269 457 160 269 minecraft:light_blue_concrete
setblock 458 156 231 minecraft:light[level=15]
setblock 458 156 239 minecraft:light[level=15]
setblock 458 156 247 minecraft:light[level=15]
setblock 458 156 255 minecraft:light[level=15]
fill 458 156 266 458 160 266 minecraft:light_blue_concrete
setblock 458 156 267 minecraft:white_concrete
setblock 458 156 270 minecraft:ochre_froglight
fill 459 156 263 459 160 263 minecraft:light_blue_concrete
setblock 459 156 264 minecraft:white_concrete
fill 459 156 269 459 160 269 minecraft:light_blue_concrete
fill 460 156 266 460 160 266 minecraft:light_blue_concrete
setblock 460 156 267 minecraft:white_concrete
setblock 461 156 231 minecraft:light[level=12]
setblock 461 156 238 minecraft:light[level=12]
setblock 461 156 245 minecraft:light[level=12]
setblock 461 156 252 minecraft:light[level=12]
setblock 461 156 259 minecraft:light[level=12]
fill 461 156 261 461 158 261 minecraft:light_blue_concrete
fill 461 156 263 461 160 263 minecraft:light_blue_concrete
setblock 461 156 264 minecraft:white_concrete
fill 461 156 269 461 160 269 minecraft:light_blue_concrete
setblock 462 156 261 minecraft:white_concrete
fill 462 156 266 462 160 266 minecraft:light_blue_concrete
setblock 462 156 267 minecraft:white_concrete
setblock 463 156 228 minecraft:white_concrete
fill 463 156 261 463 158 261 minecraft:light_blue_concrete
fill 463 156 263 463 160 263 minecraft:light_blue_concrete
setblock 463 156 264 minecraft:white_concrete
fill 463 156 269 463 160 269 minecraft:light_blue_concrete
setblock 464 156 261 minecraft:white_concrete
fill 464 156 266 464 160 266 minecraft:light_blue_concrete
setblock 464 156 267 minecraft:white_concrete
setblock 465 156 249 minecraft:white_concrete
fill 423 157 234 423 215 234 minecraft:black_concrete
setblock 423 157 252 minecraft:blue_concrete
setblock 423 157 258 minecraft:white_concrete
setblock 423 157 264 minecraft:ochre_froglight
fill 448 157 270 448 213 270 minecraft:black_concrete
fill 451 157 256 451 157 257 minecraft:gray_concrete
setblock 452 157 254 minecraft:gray_concrete
fill 454 157 253 456 157 253 minecraft:gray_concrete
setblock 455 157 260 minecraft:gray_concrete
fill 456 157 265 456 158 265 minecraft:light_blue_concrete
fill 456 157 267 458 158 267 minecraft:light_blue_concrete
setblock 456 157 268 minecraft:white_concrete
setblock 456 157 269 minecraft:light_blue_concrete
setblock 457 157 254 minecraft:gray_concrete
setblock 457 157 259 minecraft:gray_concrete
fill 457 157 264 457 160 264 minecraft:light_blue_concrete
setblock 457 157 265 minecraft:white_concrete
setblock 457 157 266 minecraft:light_blue_concrete
fill 457 157 268 457 159 268 minecraft:light_blue_concrete
fill 458 157 255 458 157 257 minecraft:gray_concrete
setblock 458 157 268 minecraft:white_concrete
fill 458 157 270 458 189 270 minecraft:black_concrete
fill 459 157 264 459 161 264 minecraft:light_blue_concrete
setblock 459 157 265 minecraft:white_concrete
fill 459 157 268 459 159 268 minecraft:light_blue_concrete
fill 460 157 261 460 158 261 minecraft:light_blue_concrete
setblock 460 157 262 minecraft:white_concrete
fill 460 157 267 460 161 267 minecraft:light_blue_concrete
setblock 460 157 268 minecraft:white_concrete
fill 461 157 264 461 161 264 minecraft:light_blue_concrete
setblock 461 157 265 minecraft:white_concrete
fill 462 157 261 462 160 261 minecraft:light_blue_concrete
setblock 462 157 262 minecraft:white_concrete
fill 462 157 267 462 161 267 minecraft:light_blue_concrete
setblock 462 157 268 minecraft:white_concrete
fill 463 157 228 463 164 228 minecraft:black_concrete
fill 463 157 264 463 161 264 minecraft:light_blue_concrete
setblock 463 157 265 minecraft:white_concrete
fill 464 157 261 464 159 261 minecraft:light_blue_concrete
setblock 464 157 262 minecraft:white_concrete
fill 464 157 267 464 161 267 minecraft:light_blue_concrete
setblock 464 157 268 minecraft:white_concrete
setblock 465 157 232 minecraft:sea_lantern
setblock 465 157 248 minecraft:ochre_froglight
fill 465 157 249 465 216 249 minecraft:black_concrete
setblock 423 158 250 minecraft:white_concrete
fill 423 158 252 423 184 252 minecraft:black_concrete
fill 423 158 258 423 171 258 minecraft:black_concrete
fill 423 158 264 423 238 264 minecraft:black_concrete
fill 452 158 252 452 161 252 minecraft:tuff
fill 454 158 256 455 159 257 minecraft:pearlescent_froglight
fill 456 158 268 456 160 268 minecraft:light_blue_concrete
setblock 456 158 269 minecraft:white_concrete
fill 457 158 265 457 161 265 minecraft:light_blue_concrete
setblock 457 158 266 minecraft:white_concrete
setblock 458 158 263 minecraft:white_concrete
fill 458 158 268 458 162 268 minecraft:light_blue_concrete
setblock 458 158 269 minecraft:white_concrete
fill 459 158 265 459 162 265 minecraft:light_blue_concrete
setblock 459 158 266 minecraft:white_concrete
fill 460 158 262 460 161 262 minecraft:light_blue_concrete
setblock 460 158 263 minecraft:white_concrete
fill 460 158 268 460 162 268 minecraft:light_blue_concrete
setblock 460 158 269 minecraft:white_concrete
fill 461 158 265 461 162 265 minecraft:light_blue_concrete
setblock 461 158 266 minecraft:white_concrete
fill 462 158 262 462 161 262 minecraft:light_blue_concrete
setblock 462 158 263 minecraft:white_concrete
fill 462 158 268 462 162 268 minecraft:light_blue_concrete
setblock 462 158 269 minecraft:white_concrete
fill 463 158 265 463 162 265 minecraft:light_blue_concrete
setblock 463 158 266 minecraft:white_concrete
fill 464 158 262 464 161 262 minecraft:light_blue_concrete
setblock 464 158 263 minecraft:white_concrete
fill 464 158 268 464 162 268 minecraft:light_blue_concrete
setblock 464 158 269 minecraft:white_concrete
fill 465 158 232 465 164 232 minecraft:black_concrete
setblock 465 158 233 minecraft:sea_lantern
fill 465 158 248 465 184 248 minecraft:black_concrete
setblock 423 159 246 minecraft:sea_lantern
fill 423 159 250 423 191 250 minecraft:black_concrete
fill 440 159 262 440 160 262 minecraft:pearlescent_froglight
fill 451 159 252 451 161 252 minecraft:tuff
fill 452 159 251 452 160 251 minecraft:tuff
fill 452 159 253 453 161 255 minecraft:tuff
fill 453 159 252 453 162 252 minecraft:tuff
fill 454 159 253 454 162 254 minecraft:tuff
fill 456 159 267 456 160 267 minecraft:light_blue_concrete
setblock 456 159 269 minecraft:light_blue_concrete
fill 457 159 266 457 161 266 minecraft:light_blue_concrete
setblock 457 159 267 minecraft:white_concrete
fill 458 159 263 458 160 263 minecraft:light_blue_concrete
setblock 458 159 264 minecraft:white_concrete
fill 458 159 267 458 161 267 minecraft:light_blue_concrete
fill 458 159 269 458 162 269 minecraft:light_blue_concrete
fill 459 159 266 459 163 266 minecraft:light_blue_concrete
setblock 459 159 267 minecraft:white_concrete
fill 460 159 263 460 162 263 minecraft:light_blue_concrete
setblock 460 159 264 minecraft:white_concrete
fill 460 159 269 460 163 269 minecraft:light_blue_concrete
setblock 461 159 261 minecraft:white_concrete
fill 461 159 266 461 163 266 minecraft:light_blue_concrete
setblock 461 159 267 minecraft:white_concrete
fill 462 159 263 462 162 263 minecraft:light_blue_concrete
setblock 462 159 264 minecraft:white_concrete
fill 462 159 269 462 163 269 minecraft:light_blue_concrete
setblock 463 159 261 minecraft:white_concrete
fill 463 159 266 463 163 266 minecraft:light_blue_concrete
setblock 463 159 267 minecraft:white_concrete
fill 464 159 263 464 162 263 minecraft:light_blue_concrete
setblock 464 159 264 minecraft:white_concrete
fill 464 159 269 464 163 269 minecraft:light_blue_concrete
fill 465 159 233 465 164 233 minecraft:black_concrete
fill 423 160 246 423 233 246 minecraft:black_concrete
setblock 423 160 256 minecraft:magenta_terracotta
setblock 429 160 228 minecraft:ochre_froglight
setblock 449 160 270 minecraft:white_concrete
fill 451 160 253 451 160 255 minecraft:tuff
fill 453 160 251 453 161 251 minecraft:tuff
fill 454 160 252 455 161 252 minecraft:tuff
fill 454 160 256 455 160 256 minecraft:pearlescent_froglight
setblock 455 160 228 minecraft:pearlescent_froglight
fill 455 160 253 455 161 253 minecraft:tuff
setblock 455 160 257 minecraft:pearlescent_froglight
fill 457 160 267 457 161 267 minecraft:light_blue_concrete
setblock 457 160 268 minecraft:white_concrete
fill 458 160 264 458 161 264 minecraft:light_blue_concrete
setblock 458 160 265 minecraft:white_concrete
setblock 459 160 262 minecraft:white_concrete
fill 459 160 267 459 163 267 minecraft:light_blue_concrete
setblock 459 160 268 minecraft:white_concrete
setblock 459 160 270 minecraft:magenta_terracotta
fill 460 160 264 460 163 264 minecraft:light_blue_concrete
setblock 460 160 265 minecraft:white_concrete
setblock 461 160 262 minecraft:white_concrete
fill 461 160 267 461 164 267 minecraft:light_blue_concrete
setblock 461 160 268 minecraft:white_concrete
fill 462 160 264 462 163 264 minecraft:light_blue_concrete
setblock 462 160 265 minecraft:white_concrete
setblock 463 160 261 minecraft:light_blue_concrete
setblock 463 160 262 minecraft:white_concrete
fill 463 160 267 463 164 267 minecraft:light_blue_concrete
setblock 463 160 268 minecraft:white_concrete
setblock 464 160 228 minecraft:ochre_froglight
fill 464 160 264 464 163 264 minecraft:light_blue_concrete
setblock 464 160 265 minecraft:white_concrete
setblock 465 160 240 minecraft:ochre_froglight
fill 465 160 241 465 242 241 minecraft:black_concrete
fill 423 161 256 423 215 256 minecraft:black_concrete
fill 429 161 228 429 191 228 minecraft:black_concrete
setblock 435 161 270 minecraft:magenta_terracotta
fill 440 161 262 440 168 262 minecraft:gray_concrete
fill 449 161 270 449 165 270 minecraft:black_concrete
fill 450 161 253 451 161 253 minecraft:tuff
fill 451 161 254 451 162 254 minecraft:tuff
setblock 454 161 251 minecraft:tuff
fill 455 161 228 455 190 228 minecraft:black_concrete
setblock 455 161 256 minecraft:pearlescent_froglight
setblock 457 161 268 minecraft:light_blue_concrete
setblock 457 161 269 minecraft:white_concrete
fill 458 161 265 458 162 265 minecraft:light_blue_concrete
setblock 458 161 266 minecraft:white_concrete
setblock 459 161 263 minecraft:white_concrete
fill 459 161 268 459 163 268 minecraft:light_blue_concrete
setblock 459 161 269 minecraft:white_concrete
fill 459 161 270 459 193 270 minecraft:black_concrete
fill 460 161 265 460 163 265 minecraft:light_blue_concrete
setblock 460 161 266 minecraft:white_concrete
setblock 461 161 262 minecraft:light_blue_concrete
setblock 461 161 263 minecraft:white_concrete
fill 461 161 268 461 164 268 minecraft:light_blue_concrete
setblock 461 161 269 minecraft:white_concrete
fill 462 161 265 462 164 265 minecraft:light_blue_concrete
setblock 462 161 266 minecraft:white_concrete
setblock 463 161 262 minecraft:light_blue_concrete
setblock 463 161 263 minecraft:white_concrete
fill 463 161 268 463 164 268 minecraft:light_blue_concrete
setblock 463 161 269 minecraft:white_concrete
fill 464 161 228 464 173 228 minecraft:black_concrete
fill 464 161 265 464 163 265 minecraft:light_blue_concrete
setblock 464 161 266 minecraft:white_concrete
setblock 465 161 234 minecraft:pearlescent_froglight
fill 465 161 240 465 163 240 minecraft:black_concrete
setblock 423 162 230 minecraft:purple_terracotta
setblock 426 162 231 minecraft:light[level=12]
setblock 426 162 238 minecraft:light[level=12]
setblock 426 162 245 minecraft:light[level=12]
setblock 426 162 252 minecraft:light[level=12]
setblock 426 162 259 minecraft:light[level=12]
setblock 426 162 266 minecraft:light[level=12]
setblock 428 162 270 minecraft:ochre_froglight
setblock 433 162 231 minecraft:light[level=12]
setblock 433 162 238 minecraft:light[level=12]
setblock 433 162 245 minecraft:light[level=12]
setblock 433 162 252 minecraft:light[level=12]
setblock 433 162 259 minecraft:light[level=12]
setblock 433 162 266 minecraft:light[level=12]
fill 435 162 270 435 221 270 minecraft:black_concrete
setblock 440 162 231 minecraft:light[level=12]
setblock 440 162 238 minecraft:light[level=12]
setblock 440 162 245 minecraft:light[level=12]
setblock 440 162 252 minecraft:light[level=12]
setblock 440 162 259 minecraft:light[level=12]
fill 440 162 261 440 168 261 minecraft:gray_concrete
fill 440 162 263 440 168 263 minecraft:gray_concrete
setblock 440 162 266 minecraft:light[level=12]
fill 441 162 262 441 168 262 minecraft:gray_concrete
setblock 447 162 231 minecraft:light[level=12]
setblock 447 162 238 minecraft:light[level=12]
setblock 447 162 245 minecraft:light[level=12]
setblock 447 162 252 minecraft:light[level=12]
setblock 447 162 259 minecraft:light[level=12]
setblock 447 162 266 minecraft:light[level=12]
setblock 447 162 270 minecraft:sea_lantern
fill 451 162 253 453 162 253 minecraft:tuff
fill 452 162 254 453 162 254 minecraft:tuff
setblock 454 162 231 minecraft:light[level=12]
setblock 454 162 238 minecraft:light[level=12]
setblock 454 162 245 minecraft:light[level=12]
setblock 454 162 252 minecraft:tuff
setblock 454 162 259 minecraft:light[level=12]
setblock 454 162 266 minecraft:light[level=12]
setblock 458 162 266 minecraft:light_blue_concrete
setblock 458 162 267 minecraft:white_concrete
setblock 459 162 264 minecraft:white_concrete
fill 459 162 269 459 163 269 minecraft:light_blue_concrete
fill 460 162 266 460 163 266 minecraft:light_blue_concrete
setblock 460 162 267 minecraft:white_concrete
setblock 461 162 231 minecraft:light[level=12]
setblock 461 162 238 minecraft:light[level=12]
setblock 461 162 245 minecraft:light[level=12]
setblock 461 162 252 minecraft:light[level=12]
setblock 461 162 259 minecraft:light[level=12]
setblock 461 162 263 minecraft:light_blue_concrete
setblock 461 162 264 minecraft:white_concrete
fill 461 162 269 461 164 269 minecraft:light_blue_concrete
fill 462 162 266 462 164 266 minecraft:light_blue_concrete
setblock 462 162 267 minecraft:white_concrete
setblock 463 162 263 minecraft:light_blue_concrete
setblock 463 162 264 minecraft:white_concrete
fill 463 162 269 463 164 269 minecraft:light_blue_concrete
fill 464 162 266 464 164 266 minecraft:light_blue_concrete
setblock 464 162 267 minecraft:white_concrete
fill 465 162 234 465 177 234 minecraft:black_concrete
setblock 465 162 247 minecraft:white_concrete
fill 423 163 230 423 228 230 minecraft:black_concrete
setblock 423 163 265 minecraft:pearlescent_froglight
setblock 426 163 231 minecraft:light[level=15]
setblock 426 163 239 minecraft:light[level=15]
setblock 426 163 247 minecraft:light[level=15]
setblock 426 163 255 minecraft:light[level=15]
setblock 426 163 263 minecraft:light[level=15]
fill 428 163 270 428 178 270 minecraft:black_concrete
setblock 431 163 228 minecraft:white_concrete
setblock 434 163 231 minecraft:light[level=15]
setblock 434 163 239 minecraft:light[level=15]
setblock 434 163 247 minecraft:light[level=15]
setblock 434 163 255 minecraft:light[level=15]
setblock 434 163 263 minecraft:light[level=15]
fill 439 163 262 439 168 262 minecraft:gray_concrete
fill 441 163 261 441 168 261 minecraft:gray_concrete
fill 441 163 263 441 168 263 minecraft:gray_concrete
setblock 442 163 231 minecraft:light[level=15]
setblock 442 163 239 minecraft:light[level=15]
setblock 442 163 247 minecraft:light[level=15]
setblock 442 163 255 minecraft:light[level=15]
setblock 442 163 263 minecraft:light[level=15]
fill 447 163 270 447 180 270 minecraft:black_concrete
setblock 448 163 228 minecraft:ochre_froglight
setblock 450 163 231 minecraft:light[level=15]
setblock 450 163 239 minecraft:light[level=15]
setblock 450 163 247 minecraft:light[level=15]
setblock 450 163 255 minecraft:light[level=15]
setblock 450 163 263 minecraft:light[level=15]
setblock 453 163 254 minecraft:tuff
setblock 458 163 231 minecraft:light[level=15]
setblock 458 163 239 minecraft:light[level=15]
setblock 458 163 247 minecraft:light[level=15]
setblock 458 163 255 minecraft:light[level=15]
setblock 458 163 263 minecraft:light[level=15]
setblock 459 163 265 minecraft:white_concrete
fill 460 163 250 460 164 250 minecraft:pearlescent_froglight
fill 460 163 267 460 164 267 minecraft:light_blue_concrete
setblock 460 163 268 minecraft:white_concrete
setblock 461 163 264 minecraft:light_blue_concrete
setblock 461 163 265 minecraft:white_concrete
fill 462 163 267 462 164 267 minecraft:light_blue_concrete
setblock 462 163 268 minecraft:white_concrete
setblock 463 163 264 minecraft:light_blue_concrete
setblock 463 163 265 minecraft:white_concrete
fill 464 163 267 464 164 267 minecraft:light_blue_concrete
setblock 464 163 268 minecraft:white_concrete
fill 465 163 247 465 182 247 minecraft:black_concrete
setblock 465 163 261 minecraft:magenta_terracotta
setblock 465 163 262 minecraft:pearlescent_froglight
fill 423 164 265 423 179 265 minecraft:black_concrete
fill 431 164 228 431 308 228 minecraft:black_concrete
fill 439 164 261 439 168 261 minecraft:gray_concrete
fill 439 164 263 439 168 263 minecraft:gray_concrete
setblock 439 164 270 minecraft:ochre_froglight
fill 442 164 261 442 168 263 minecraft:gray_concrete
fill 448 164 228 448 172 228 minecraft:black_concrete
setblock 460 164 268 minecraft:light_blue_concrete
setblock 461 164 266 minecraft:white_concrete
setblock 462 164 268 minecraft:light_blue_concrete
setblock 462 164 269 minecraft:white_concrete
setblock 463 164 265 minecraft:light_blue_concrete
setblock 463 164 266 minecraft:white_concrete
setblock 464 164 268 minecraft:light_blue_concrete
setblock 464 164 269 minecraft:white_concrete
setblock 465 164 231 minecraft:sea_lantern
setblock 465 164 235 minecraft:sea_lantern
setblock 465 164 240 minecraft:white_concrete
fill 465 164 261 465 185 262 minecraft:black_concrete
setblock 430 165 228 minecraft:sea_lantern
fill 438 165 262 438 168 262 minecraft:gray_concrete
fill 439 165 260 441 168 260 minecraft:gray_concrete
fill 439 165 264 441 168 264 minecraft:gray_concrete
fill 439 165 270 439 175 270 minecraft:black_concrete
setblock 443 165 270 minecraft:pearlescent_froglight
setblock 444 165 228 minecraft:pearlescent_froglight
fill 460 165 250 460 175 250 minecraft:gray_concrete
setblock 463 165 228 minecraft:purple_terracotta
fill 465 165 231 465 256 231 minecraft:black_concrete
setblock 465 165 232 minecraft:ochre_froglight
setblock 465 165 233 minecraft:white_concrete
fill 465 165 235 465 193 235 minecraft:black_concrete
fill 465 165 240 465 238 240 minecraft:black_concrete
setblock 423 166 238 minecraft:sea_lantern
setblock 426 166 270 minecraft:white_concrete
fill 430 166 228 430 192 228 minecraft:black_concrete
fill 438 166 261 438 168 261 minecraft:gray_concrete
fill 438 166 263 438 168 263 minecraft:gray_concrete
fill 442 166 260 442 168 260 minecraft:gray_concrete
fill 442 166 264 442 168 264 minecraft:gray_concrete
fill 443 166 261 443 168 263 minecraft:gray_concrete
fill 443 166 270 443 185 270 minecraft:black_concrete
fill 444 166 228 444 167 228 minecraft:black_concrete
setblock 444 166 270 minecraft:sea_lantern
setblock 445 166 270 minecraft:purple_concrete
setblock 449 166 270 minecraft:white_concrete
fill 450 166 243 452 167 243 minecraft:gray_concrete
setblock 451 166 228 minecraft:pearlescent_froglight
fill 451 166 242 451 167 242 minecraft:gray_concrete
fill 451 166 244 451 167 244 minecraft:gray_concrete
fill 451 166 257 451 170 257 minecraft:cobbled_deepslate
fill 463 166 228 463 192 228 minecraft:black_concrete
fill 465 166 232 465 167 233 minecraft:black_concrete
setblock 465 166 242 minecraft:pearlescent_froglight
setblock 465 166 266 minecraft:white_concrete
fill 423 167 238 423 169 238 minecraft:black_concrete
fill 426 167 270 426 194 270 minecraft:black_concrete
setblock 434 167 270 minecraft:purple_terracotta
fill 437 167 262 437 168 262 minecraft:gray_concrete
fill 438 167 260 438 168 260 minecraft:gray_concrete
fill 438 167 264 438 168 264 minecraft:gray_concrete
fill 439 167 259 441 168 259 minecraft:gray_concrete
fill 439 167 265 441 168 265 minecraft:gray_concrete
setblock 442 167 270 minecraft:ochre_froglight
fill 443 167 260 443 168 260 minecraft:gray_concrete
fill 443 167 264 443 168 264 minecraft:gray_concrete
fill 444 167 270 445 189 270 minecraft:black_concrete
setblock 446 167 228 minecraft:blue_concrete
fill 449 167 270 449 180 270 minecraft:black_concrete
fill 450 167 256 450 169 258 minecraft:cobbled_deepslate
fill 451 167 228 451 308 228 minecraft:black_concrete
fill 451 167 256 452 170 256 minecraft:cobbled_deepslate
fill 451 167 258 452 170 258 minecraft:cobbled_deepslate
fill 452 167 257 453 168 257 minecraft:cobbled_deepslate
setblock 456 167 228 minecraft:ochre_froglight
fill 459 167 250 459 175 250 minecraft:gray_concrete
fill 460 167 249 460 175 249 minecraft:gray_concrete
fill 460 167 251 461 175 251 minecraft:gray_concrete
fill 461 167 250 461 175 250 minecraft:gray_concrete
setblock 465 167 239 minecraft:pearlescent_froglight
fill 465 167 242 465 209 242 minecraft:black_concrete
setblock 465 167 243 minecraft:purple_concrete
fill 465 167 266 465 197 266 minecraft:black_concrete
setblock 424 168 228 minecraft:white_concrete
setblock 426 168 231 minecraft:light[level=12]
setblock 426 168 238 minecraft:light[level=12]
setblock 426 168 245 minecraft:light[level=12]
setblock 426 168 252 minecraft:light[level=12]
setblock 426 168 259 minecraft:light[level=12]
setblock 426 168 266 minecraft:light[level=12]
setblock 433 168 231 minecraft:light[level=12]
setblock 433 168 238 minecraft:light[level=12]
setblock 433 168 245 minecraft:light[level=12]
setblock 433 168 252 minecraft:light[level=12]
setblock 433 168 259 minecraft:light[level=12]
setblock 433 168 266 minecraft:light[level=12]
fill 434 168 270 434 186 270 minecraft:black_concrete
fill 435 168 242 435 169 242 minecraft:end_stone
fill 437 168 260 437 168 261 minecraft:gray_concrete
fill 437 168 263 437 168 264 minecraft:gray_concrete
setblock 438 168 259 minecraft:gray_concrete
setblock 438 168 265 minecraft:gray_concrete
setblock 440 168 231 minecraft:light[level=12]
setblock 440 168 238 minecraft:light[level=12]
setblock 440 168 245 minecraft:light[level=12]
setblock 440 168 252 minecraft:light[level=12]
setblock 440 168 266 minecraft:light[level=12]
setblock 442 168 259 minecraft:gray_concrete
setblock 442 168 265 minecraft:gray_concrete
fill 442 168 270 442 172 270 minecraft:black_concrete
setblock 444 168 228 minecraft:magenta_terracotta
fill 444 168 261 444 168 263 minecraft:gray_concrete
setblock 446 168 228 minecraft:black_concrete
setblock 447 168 231 minecraft:light[level=12]
setblock 447 168 238 minecraft:light[level=12]
setblock 447 168 245 minecraft:light[level=12]
setblock 447 168 252 minecraft:light[level=12]
setblock 447 168 259 minecraft:light[level=12]
setblock 447 168 266 minecraft:light[level=12]
fill 449 168 256 449 168 258 minecraft:cobbled_deepslate
fill 450 168 259 451 169 259 minecraft:cobbled_deepslate
setblock 453 168 258 minecraft:cobbled_deepslate
setblock 454 168 231 minecraft:light[level=12]
setblock 454 168 238 minecraft:light[level=12]
setblock 454 168 245 minecraft:light[level=12]
setblock 454 168 252 minecraft:light[level=12]
setblock 454 168 259 minecraft:light[level=12]
setblock 454 168 266 minecraft:light[level=12]
fill 456 168 228 456 171 228 minecraft:black_concrete
setblock 459 168 228 minecraft:ochre_froglight
fill 459 168 249 459 175 249 minecraft:gray_concrete
fill 459 168 251 459 175 251 minecraft:gray_concrete
setblock 461 168 231 minecraft:light[level=12]
setblock 461 168 238 minecraft:light[level=12]
setblock 461 168 245 minecraft:light[level=12]
fill 461 168 249 461 175 249 minecraft:gray_concrete
setblock 461 168 252 minecraft:light[level=12]
setblock 461 168 259 minecraft:light[level=12]
setblock 461 168 266 minecraft:light[level=12]
fill 461 168 270 461 169 270 minecraft:white_concrete
fill 465 168 232 465 201 232 minecraft:black_concrete
setblock 465 168 233 minecraft:purple_terracotta
fill 465 168 239 465 263 239 minecraft:black_concrete
fill 465 168 243 465 196 243 minecraft:black_concrete
setblock 423 169 232 minecraft:pearlescent_froglight
setblock 423 169 251 minecraft:magenta_terracotta
fill 424 169 228 424 178 228 minecraft:black_concrete
fill 440 169 261 441 169 263 minecraft:pearlescent_froglight
fill 444 169 228 444 178 228 minecraft:black_concrete
setblock 446 169 228 minecraft:white_concrete
setblock 449 169 257 minecraft:cobbled_deepslate
fill 452 169 257 452 170 257 minecraft:cobbled_deepslate
setblock 452 169 259 minecraft:cobbled_deepslate
setblock 455 169 270 minecraft:pearlescent_froglight
fill 458 169 250 458 175 250 minecraft:gray_concrete
fill 459 169 228 459 182 228 minecraft:black_concrete
fill 459 169 252 461 175 252 minecraft:gray_concrete
fill 460 169 248 460 175 248 minecraft:gray_concrete
fill 462 169 249 462 175 251 minecraft:gray_concrete
setblock 465 169 233 minecraft:sea_lantern
setblock 465 169 267 minecraft:pearlescent_froglight
fill 423 170 232 423 192 232 minecraft:black_concrete
setblock 423 170 238 minecraft:ochre_froglight
fill 423 170 251 423 172 251 minecraft:black_concrete
setblock 426 170 231 minecraft:light[level=15]
setblock 426 170 239 minecraft:light[level=15]
setblock 426 170 247 minecraft:light[level=15]
setblock 426 170 255 minecraft:light[level=15]
setblock 426 170 263 minecraft:light[level=15]
setblock 434 170 231 minecraft:light[level=15]
setblock 434 170 239 minecraft:light[level=15]
setblock 434 170 247 minecraft:light[level=15]
setblock 434 170 255 minecraft:light[level=15]
setblock 434 170 263 minecraft:light[level=15]
setblock 440 170 228 minecraft:purple_concrete
fill 440 170 261 440 170 263 minecraft:pearlescent_froglight
setblock 441 170 228 minecraft:ochre_froglight
fill 441 170 262 441 171 262 minecraft:pearlescent_froglight
setblock 442 170 231 minecraft:light[level=15]
setblock 442 170 239 minecraft:light[level=15]
setblock 442 170 247 minecraft:light[level=15]
setblock 442 170 255 minecraft:light[level=15]
setblock 442 170 263 minecraft:light[level=15]
fill 446 170 228 446 191 228 minecraft:black_concrete
fill 446 170 270 446 171 270 minecraft:pearlescent_froglight
setblock 447 170 228 minecraft:white_concrete
setblock 450 170 231 minecraft:light[level=15]
setblock 450 170 239 minecraft:light[level=15]
setblock 450 170 247 minecraft:light[level=15]
setblock 450 170 255 minecraft:light[level=15]
fill 450 170 257 450 170 258 minecraft:cobbled_deepslate
setblock 450 170 263 minecraft:light[level=15]
setblock 451 170 259 minecraft:cobbled_deepslate
fill 455 170 270 455 184 270 minecraft:black_concrete
setblock 458 170 231 minecraft:light[level=15]
setblock 458 170 239 minecraft:light[level=15]
setblock 458 170 247 minecraft:light[level=15]
fill 458 170 249 458 175 249 minecraft:gray_concrete
fill 458 170 251 458 175 251 minecraft:gray_concrete
setblock 458 170 255 minecraft:light[level=15]
setblock 458 170 263 minecraft:light[level=15]
fill 459 170 248 459 175 248 minecraft:gray_concrete
fill 461 170 248 461 175 248 minecraft:gray_concrete
fill 461 170 270 461 173 270 minecraft:black_concrete
fill 462 170 252 462 175 252 minecraft:gray_concrete
fill 465 170 233 465 216 233 minecraft:black_concrete
fill 465 170 267 465 208 267 minecraft:black_concrete
fill 423 171 238 423 206 238 minecraft:black_concrete
fill 440 171 228 441 198 228 minecraft:black_concrete
fill 440 171 262 440 172 262 minecraft:pearlescent_froglight
fill 447 171 228 447 196 228 minecraft:black_concrete
setblock 457 171 228 minecraft:blue_concrete
fill 457 171 250 457 175 250 minecraft:gray_concrete
fill 458 171 248 458 175 248 minecraft:gray_concrete
fill 458 171 252 458 175 252 minecraft:gray_concrete
fill 459 171 253 461 175 253 minecraft:gray_concrete
fill 460 171 247 461 175 247 minecraft:gray_concrete
fill 462 171 248 462 175 248 minecraft:gray_concrete
fill 463 171 249 463 175 251 minecraft:gray_concrete
setblock 465 171 230 minecraft:white_concrete
setblock 465 171 255 minecraft:magenta_terracotta
setblock 423 172 258 minecraft:magenta_terracotta
setblock 423 172 268 minecraft:ochre_froglight
setblock 437 172 228 minecraft:sea_lantern
setblock 439 172 228 minecraft:white_concrete
fill 446 172 270 446 215 270 minecraft:black_concrete
setblock 456 172 228 minecraft:sea_lantern
setblock 457 172 228 minecraft:pearlescent_froglight
fill 457 172 249 457 175 249 minecraft:gray_concrete
fill 457 172 251 457 175 252 minecraft:gray_concrete
fill 458 172 253 458 175 253 minecraft:gray_concrete
fill 459 172 247 459 175 247 minecraft:gray_concrete
fill 462 172 247 462 175 247 minecraft:gray_concrete
fill 462 172 253 462 175 253 minecraft:gray_concrete
fill 463 172 248 463 175 248 minecraft:gray_concrete
fill 463 172 252 463 175 252 minecraft:gray_concrete
fill 465 172 230 465 174 230 minecraft:black_concrete
fill 465 172 255 465 192 255 minecraft:black_concrete
setblock 423 173 251 minecraft:white_concrete
fill 423 173 258 423 256 258 minecraft:black_concrete
setblock 423 173 267 minecraft:pearlescent_froglight
fill 423 173 268 423 186 268 minecraft:black_concrete
fill 437 173 228 437 174 228 minecraft:black_concrete
fill 439 173 228 439 180 228 minecraft:black_concrete
setblock 442 173 270 minecraft:sea_lantern
setblock 448 173 228 minecraft:pearlescent_froglight
fill 456 173 228 457 186 228 minecraft:black_concrete
fill 456 173 250 456 175 251 minecraft:gray_concrete
fill 457 173 248 457 175 248 minecraft:gray_concrete
fill 458 173 247 458 175 247 minecraft:gray_concrete
fill 459 173 254 461 175 254 minecraft:gray_concrete
fill 460 173 246 461 175 246 minecraft:gray_concrete
fill 463 173 247 463 175 247 minecraft:gray_concrete
fill 463 173 253 463 175 253 minecraft:gray_concrete
fill 464 173 249 464 175 251 minecraft:gray_concrete
setblock 465 173 269 minecraft:white_concrete
setblock 423 174 231 minecraft:sea_lantern
fill 423 174 251 423 201 251 minecraft:black_concrete
fill 423 174 267 423 188 267 minecraft:black_concrete
setblock 426 174 231 minecraft:light[level=12]
setblock 426 174 238 minecraft:light[level=12]
setblock 426 174 245 minecraft:light[level=12]
setblock 426 174 252 minecraft:light[level=12]
setblock 426 174 259 minecraft:light[level=12]
setblock 426 174 266 minecraft:light[level=12]
setblock 433 174 231 minecraft:light[level=12]
setblock 433 174 238 minecraft:light[level=12]
setblock 433 174 245 minecraft:light[level=12]
setblock 433 174 252 minecraft:light[level=12]
schedule function dropper:buildpart/57_2 1t
