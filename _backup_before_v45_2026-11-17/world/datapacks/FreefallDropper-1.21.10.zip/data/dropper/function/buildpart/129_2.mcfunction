setblock 428 248 510 minecraft:light_blue_stained_glass
fill 431 248 510 431 254 510 minecraft:black_concrete
fill 433 248 510 433 268 510 minecraft:black_concrete
fill 439 248 552 439 307 552 minecraft:black_concrete
fill 460 248 552 460 307 552 minecraft:black_concrete
setblock 423 249 532 minecraft:white_concrete
fill 423 249 533 423 307 533 minecraft:black_concrete
fill 423 249 539 423 307 539 minecraft:black_concrete
fill 428 249 510 428 283 510 minecraft:black_concrete
setblock 460 249 510 minecraft:light_blue_stained_glass
setblock 423 250 525 minecraft:sea_lantern
fill 423 250 532 423 251 532 minecraft:black_concrete
fill 460 250 510 460 305 510 minecraft:black_concrete
setblock 465 250 511 minecraft:light_blue_stained_glass
fill 465 250 512 465 285 512 minecraft:black_concrete
fill 423 251 519 423 271 520 minecraft:black_concrete
setblock 423 251 521 minecraft:light_blue_stained_glass
fill 423 251 522 423 295 523 minecraft:black_concrete
fill 423 251 525 423 275 525 minecraft:black_concrete
fill 458 251 552 458 300 552 minecraft:black_concrete
setblock 459 251 552 minecraft:white_concrete
fill 465 251 511 465 269 511 minecraft:black_concrete
setblock 465 251 521 minecraft:light_blue_stained_glass
fill 465 251 542 465 284 542 minecraft:black_concrete
setblock 465 251 543 minecraft:sea_lantern
fill 423 252 518 423 254 518 minecraft:gold_block
fill 423 252 521 423 284 521 minecraft:black_concrete
fill 423 252 527 423 252 530 minecraft:black_concrete
fill 423 252 531 423 252 532 minecraft:white_concrete
fill 423 252 534 423 254 534 minecraft:gold_block
setblock 423 252 542 minecraft:sea_lantern
setblock 423 252 544 minecraft:white_concrete
fill 423 252 550 423 254 550 minecraft:gold_block
fill 427 252 510 427 254 510 minecraft:gold_block
fill 437 252 552 437 254 552 minecraft:gold_block
fill 443 252 510 443 254 510 minecraft:gold_block
fill 453 252 552 453 254 552 minecraft:gold_block
fill 459 252 510 459 254 510 minecraft:gold_block
fill 459 252 552 459 307 552 minecraft:black_concrete
fill 465 252 520 465 254 520 minecraft:gold_block
fill 465 252 521 465 288 521 minecraft:black_concrete
fill 465 252 536 465 254 536 minecraft:gold_block
fill 465 252 543 465 307 543 minecraft:black_concrete
fill 423 253 527 423 269 527 minecraft:black_concrete
setblock 423 253 528 minecraft:light_blue_stained_glass
fill 423 253 529 423 257 532 minecraft:black_concrete
fill 423 253 542 423 303 542 minecraft:black_concrete
fill 423 253 544 423 284 544 minecraft:black_concrete
setblock 426 253 513 minecraft:light[level=14]
setblock 426 253 521 minecraft:light[level=14]
setblock 426 253 529 minecraft:light[level=14]
setblock 426 253 537 minecraft:light[level=14]
setblock 426 253 545 minecraft:light[level=14]
setblock 434 253 513 minecraft:light[level=14]
setblock 434 253 521 minecraft:light[level=14]
setblock 434 253 529 minecraft:light[level=14]
setblock 434 253 537 minecraft:light[level=14]
setblock 434 253 545 minecraft:light[level=14]
setblock 440 253 510 minecraft:white_concrete
setblock 442 253 513 minecraft:light[level=14]
setblock 442 253 521 minecraft:light[level=14]
setblock 442 253 529 minecraft:light[level=14]
setblock 442 253 537 minecraft:light[level=14]
setblock 442 253 545 minecraft:light[level=14]
setblock 450 253 513 minecraft:light[level=14]
setblock 450 253 521 minecraft:light[level=14]
setblock 450 253 529 minecraft:light[level=14]
setblock 450 253 537 minecraft:light[level=14]
setblock 450 253 545 minecraft:light[level=14]
setblock 458 253 513 minecraft:light[level=14]
setblock 458 253 521 minecraft:light[level=14]
setblock 458 253 529 minecraft:light[level=14]
setblock 458 253 537 minecraft:light[level=14]
setblock 458 253 545 minecraft:light[level=14]
fill 459 253 545 459 253 547 minecraft:waxed_cut_copper
fill 460 253 544 462 253 544 minecraft:waxed_cut_copper
fill 460 253 548 462 253 548 minecraft:waxed_cut_copper
fill 463 253 545 463 253 547 minecraft:waxed_cut_copper
fill 423 254 528 423 284 528 minecraft:black_concrete
setblock 423 254 541 minecraft:white_concrete
setblock 424 254 552 minecraft:sea_lantern
fill 440 254 510 440 283 510 minecraft:black_concrete
fill 442 254 552 446 266 552 minecraft:black_concrete
setblock 446 254 510 minecraft:light_blue_stained_glass
setblock 447 254 552 minecraft:sea_lantern
fill 448 254 552 449 256 552 minecraft:black_concrete
fill 463 254 545 464 255 547 minecraft:waxed_copper_block
fill 465 254 515 465 292 517 minecraft:black_concrete
setblock 465 254 518 minecraft:light_blue_stained_glass
fill 465 254 519 465 307 519 minecraft:black_concrete
fill 423 255 518 423 260 518 minecraft:black_concrete
fill 423 255 534 423 260 534 minecraft:black_concrete
fill 423 255 541 423 307 541 minecraft:black_concrete
fill 423 255 550 423 257 550 minecraft:black_concrete
setblock 424 255 510 minecraft:light_blue_stained_glass
setblock 424 255 552 minecraft:black_concrete
fill 425 255 510 427 260 510 minecraft:black_concrete
setblock 431 255 510 minecraft:white_concrete
fill 437 255 552 437 260 552 minecraft:black_concrete
fill 443 255 510 443 259 510 minecraft:black_concrete
setblock 446 255 510 minecraft:sea_lantern
fill 447 255 552 447 268 552 minecraft:black_concrete
fill 453 255 552 453 260 552 minecraft:black_concrete
fill 459 255 510 459 260 510 minecraft:black_concrete
setblock 459 255 546 minecraft:sea_lantern
fill 463 255 510 463 305 510 minecraft:black_concrete
setblock 463 255 552 minecraft:white_concrete
setblock 464 255 510 minecraft:light_blue_stained_glass
fill 465 255 518 465 257 518 minecraft:black_concrete
fill 465 255 520 465 260 520 minecraft:black_concrete
fill 465 255 536 465 260 536 minecraft:black_concrete
fill 424 256 510 424 265 510 minecraft:black_concrete
setblock 424 256 552 minecraft:light_blue_stained_glass
setblock 430 256 552 minecraft:sea_lantern
fill 431 256 510 431 307 510 minecraft:black_concrete
fill 431 256 552 431 277 552 minecraft:black_concrete
setblock 432 256 510 minecraft:light_blue_stained_glass
fill 446 256 510 446 261 510 minecraft:black_concrete
fill 451 256 552 451 272 552 minecraft:black_concrete
setblock 452 256 552 minecraft:light_blue_stained_glass
setblock 454 256 510 minecraft:white_concrete
fill 463 256 552 463 293 552 minecraft:black_concrete
fill 464 256 510 464 307 510 minecraft:black_concrete
setblock 465 256 547 minecraft:sea_lantern
fill 465 256 548 465 307 548 minecraft:black_concrete
fill 424 257 552 424 261 552 minecraft:black_concrete
fill 430 257 552 430 302 552 minecraft:black_concrete
fill 432 257 510 432 273 510 minecraft:black_concrete
setblock 442 257 510 minecraft:white_concrete
fill 448 257 552 448 307 552 minecraft:black_concrete
setblock 449 257 552 minecraft:light_blue_stained_glass
fill 452 257 552 452 288 552 minecraft:black_concrete
fill 454 257 510 454 267 510 minecraft:black_concrete
fill 454 257 539 458 264 539 minecraft:red_terracotta
fill 455 257 538 457 264 538 minecraft:red_terracotta
fill 455 257 540 457 264 540 minecraft:red_terracotta
fill 456 257 537 456 264 537 minecraft:red_terracotta
fill 456 257 541 456 264 541 minecraft:red_terracotta
fill 465 257 538 465 277 538 minecraft:black_concrete
setblock 465 257 539 minecraft:white_concrete
fill 465 257 540 465 276 541 minecraft:black_concrete
fill 465 257 547 465 307 547 minecraft:black_concrete
fill 423 258 529 423 263 530 minecraft:black_concrete
setblock 423 258 531 minecraft:sea_lantern
fill 423 258 532 423 263 532 minecraft:black_concrete
setblock 423 258 550 minecraft:white_concrete
setblock 428 258 552 minecraft:white_concrete
fill 442 258 510 442 297 510 minecraft:black_concrete
fill 449 258 552 449 307 552 minecraft:black_concrete
fill 453 258 538 453 263 540 minecraft:red_terracotta
fill 454 258 537 454 263 538 minecraft:red_terracotta
fill 454 258 540 454 263 541 minecraft:red_terracotta
fill 455 258 536 455 263 537 minecraft:red_terracotta
fill 455 258 541 455 263 541 minecraft:red_terracotta
fill 456 258 536 457 263 536 minecraft:red_terracotta
fill 456 258 542 456 263 542 minecraft:red_terracotta
fill 457 258 537 458 263 537 minecraft:red_terracotta
fill 457 258 541 458 263 541 minecraft:red_terracotta
fill 458 258 538 459 263 538 minecraft:red_terracotta
fill 458 258 540 459 263 540 minecraft:red_terracotta
fill 459 258 539 459 263 539 minecraft:red_terracotta
setblock 465 258 518 minecraft:white_concrete
fill 465 258 539 465 269 539 minecraft:black_concrete
setblock 465 258 545 minecraft:white_concrete
setblock 423 259 511 minecraft:light_blue_stained_glass
fill 423 259 531 423 294 531 minecraft:black_concrete
fill 423 259 550 423 260 550 minecraft:black_concrete
fill 428 259 552 428 307 552 minecraft:black_concrete
fill 453 259 537 453 262 537 minecraft:red_terracotta
fill 453 259 541 453 262 541 minecraft:red_terracotta
fill 454 259 536 454 262 536 minecraft:red_terracotta
fill 454 259 542 455 262 542 minecraft:red_terracotta
fill 457 259 542 458 262 542 minecraft:red_terracotta
fill 458 259 536 458 262 536 minecraft:red_terracotta
fill 459 259 537 459 262 537 minecraft:red_terracotta
fill 459 259 541 459 262 541 minecraft:red_terracotta
fill 465 259 518 465 284 518 minecraft:black_concrete
setblock 465 259 534 minecraft:light_blue_stained_glass
fill 465 259 535 465 279 535 minecraft:black_concrete
fill 465 259 545 465 266 545 minecraft:black_concrete
fill 423 260 511 423 267 511 minecraft:black_concrete
setblock 443 260 510 minecraft:white_concrete
setblock 447 260 510 minecraft:white_concrete
fill 448 260 510 448 307 510 minecraft:black_concrete
fill 452 260 539 452 261 539 minecraft:red_terracotta
fill 455 260 535 457 261 535 minecraft:red_terracotta
fill 457 260 543 461 261 543 minecraft:polished_blackstone
fill 459 260 542 461 261 542 minecraft:polished_blackstone
fill 459 260 545 459 260 547 minecraft:waxed_cut_copper
fill 460 260 539 460 261 539 minecraft:red_terracotta
fill 460 260 540 461 261 541 minecraft:polished_blackstone
fill 460 260 544 462 260 544 minecraft:waxed_cut_copper
fill 460 260 548 462 260 548 minecraft:waxed_cut_copper
fill 461 260 539 461 261 539 minecraft:polished_blackstone
fill 462 260 541 463 260 541 minecraft:polished_blackstone
fill 463 260 545 463 260 547 minecraft:waxed_cut_copper
fill 465 260 534 465 307 534 minecraft:black_concrete
fill 423 261 518 423 263 518 minecraft:gold_block
fill 423 261 534 423 263 534 minecraft:gold_block
fill 423 261 550 423 263 550 minecraft:gold_block
fill 425 261 510 426 270 510 minecraft:black_concrete
setblock 426 261 513 minecraft:light[level=14]
setblock 426 261 521 minecraft:light[level=14]
setblock 426 261 529 minecraft:light[level=14]
setblock 426 261 537 minecraft:light[level=14]
setblock 426 261 545 minecraft:light[level=14]
fill 427 261 510 427 263 510 minecraft:gold_block
setblock 434 261 513 minecraft:light[level=14]
setblock 434 261 521 minecraft:light[level=14]
setblock 434 261 529 minecraft:light[level=14]
setblock 434 261 537 minecraft:light[level=14]
setblock 434 261 545 minecraft:light[level=14]
fill 437 261 552 437 263 552 minecraft:gold_block
setblock 442 261 513 minecraft:light[level=14]
setblock 442 261 521 minecraft:light[level=14]
setblock 442 261 529 minecraft:light[level=14]
setblock 442 261 537 minecraft:light[level=14]
setblock 442 261 545 minecraft:light[level=14]
fill 443 261 510 443 263 510 minecraft:gold_block
fill 447 261 510 447 307 510 minecraft:black_concrete
setblock 450 261 513 minecraft:light[level=14]
setblock 450 261 521 minecraft:light[level=14]
setblock 450 261 529 minecraft:light[level=14]
setblock 450 261 537 minecraft:light[level=14]
setblock 450 261 545 minecraft:light[level=14]
fill 453 261 552 453 263 552 minecraft:gold_block
setblock 458 261 513 minecraft:light[level=14]
setblock 458 261 521 minecraft:light[level=14]
setblock 458 261 529 minecraft:light[level=14]
setblock 458 261 545 minecraft:light[level=14]
fill 459 261 510 459 263 510 minecraft:gold_block
fill 465 261 520 465 263 520 minecraft:gold_block
fill 465 261 536 465 263 536 minecraft:gold_block
setblock 424 262 552 minecraft:sea_lantern
fill 436 262 510 436 307 510 minecraft:black_concrete
setblock 437 262 510 minecraft:sea_lantern
setblock 446 262 510 minecraft:sea_lantern
fill 424 263 552 424 304 552 minecraft:black_concrete
setblock 429 263 510 minecraft:light_blue_stained_glass
fill 430 263 510 430 277 510 minecraft:black_concrete
fill 437 263 510 437 307 510 minecraft:black_concrete
fill 446 263 510 446 307 510 minecraft:black_concrete
fill 452 263 510 452 307 510 minecraft:black_concrete
setblock 453 263 510 minecraft:white_concrete
fill 459 263 541 459 270 541 minecraft:gold_block
setblock 423 264 518 minecraft:black_concrete
fill 423 264 529 423 291 529 minecraft:black_concrete
setblock 423 264 530 minecraft:white_concrete
setblock 423 264 532 minecraft:white_concrete
fill 423 264 534 423 269 534 minecraft:black_concrete
fill 423 264 550 423 269 550 minecraft:black_concrete
fill 427 264 510 427 269 510 minecraft:black_concrete
fill 429 264 510 429 307 510 minecraft:black_concrete
fill 437 264 552 437 269 552 minecraft:black_concrete
fill 438 264 510 439 264 510 minecraft:light_blue_stained_glass
fill 443 264 510 443 269 510 minecraft:black_concrete
fill 453 264 510 453 266 510 minecraft:black_concrete
fill 453 264 552 453 269 552 minecraft:black_concrete
fill 457 264 541 458 269 542 minecraft:gold_block
fill 458 264 540 461 269 540 minecraft:gold_block
fill 458 264 543 460 269 543 minecraft:gold_block
fill 459 264 510 459 269 510 minecraft:black_concrete
fill 459 264 539 460 269 539 minecraft:gold_block
fill 459 264 542 461 269 542 minecraft:gold_block
fill 460 264 541 461 269 541 minecraft:gold_block
setblock 462 264 510 minecraft:white_concrete
fill 465 264 520 465 269 520 minecraft:black_concrete
fill 465 264 536 465 269 536 minecraft:black_concrete
setblock 423 265 518 minecraft:white_concrete
fill 423 265 530 423 298 530 minecraft:black_concrete
fill 423 265 532 423 307 532 minecraft:black_concrete
setblock 423 265 548 minecraft:light_blue_stained_glass
fill 423 265 549 423 307 549 minecraft:black_concrete
fill 433 265 552 435 307 552 minecraft:black_concrete
setblock 436 265 552 minecraft:light_blue_stained_glass
fill 438 265 510 439 267 510 minecraft:black_concrete
fill 456 265 540 456 268 542 minecraft:gold_block
fill 457 265 539 457 268 540 minecraft:gold_block
fill 457 265 543 457 268 543 minecraft:gold_block
fill 458 265 538 458 268 539 minecraft:gold_block
fill 458 265 544 460 268 544 minecraft:gold_block
fill 459 265 538 460 268 538 minecraft:gold_block
fill 461 265 539 461 268 539 minecraft:gold_block
fill 461 265 543 461 268 543 minecraft:gold_block
fill 462 265 510 462 269 510 minecraft:black_concrete
fill 462 265 540 462 268 542 minecraft:gold_block
fill 423 266 518 423 268 518 minecraft:black_concrete
fill 423 266 548 423 307 548 minecraft:black_concrete
setblock 424 266 510 minecraft:white_concrete
fill 425 266 552 425 307 552 minecraft:black_concrete
setblock 426 266 552 minecraft:light_blue_stained_glass
fill 427 266 552 427 307 552 minecraft:black_concrete
fill 436 266 552 436 268 552 minecraft:black_concrete
setblock 441 266 510 minecraft:white_concrete
setblock 451 266 510 minecraft:light_blue_stained_glass
setblock 465 266 524 minecraft:white_concrete
setblock 465 266 546 minecraft:white_concrete
fill 424 267 510 424 299 510 minecraft:black_concrete
fill 426 267 552 426 307 552 minecraft:black_concrete
fill 441 267 510 441 307 510 minecraft:black_concrete
fill 442 267 552 444 299 552 minecraft:black_concrete
setblock 445 267 552 minecraft:white_concrete
fill 446 267 552 446 307 552 minecraft:black_concrete
fill 451 267 510 451 286 510 minecraft:black_concrete
setblock 453 267 510 minecraft:light_blue_stained_glass
fill 459 267 545 459 267 547 minecraft:waxed_cut_copper
fill 460 267 548 462 267 548 minecraft:waxed_cut_copper
fill 461 267 544 462 267 544 minecraft:waxed_cut_copper
fill 463 267 545 463 267 547 minecraft:waxed_cut_copper
fill 465 267 524 465 307 524 minecraft:black_concrete
setblock 465 267 545 minecraft:sea_lantern
fill 465 267 546 465 307 546 minecraft:black_concrete
setblock 423 268 511 minecraft:light_blue_stained_glass
fill 438 268 510 438 307 510 minecraft:black_concrete
setblock 439 268 510 minecraft:sea_lantern
fill 445 268 552 445 283 552 minecraft:black_concrete
fill 453 268 510 453 307 510 minecraft:black_concrete
setblock 454 268 510 minecraft:light_blue_stained_glass
fill 465 268 545 465 276 545 minecraft:black_concrete
fill 423 269 511 423 307 511 minecraft:black_concrete
setblock 423 269 518 minecraft:sea_lantern
setblock 426 269 513 minecraft:light[level=14]
setblock 426 269 521 minecraft:light[level=14]
setblock 426 269 529 minecraft:light[level=14]
setblock 426 269 537 minecraft:light[level=14]
setblock 426 269 545 minecraft:light[level=14]
setblock 433 269 510 minecraft:sea_lantern
setblock 434 269 513 minecraft:light[level=14]
setblock 434 269 521 minecraft:light[level=14]
setblock 434 269 529 minecraft:light[level=14]
setblock 434 269 537 minecraft:light[level=14]
setblock 434 269 545 minecraft:light[level=14]
setblock 436 269 552 minecraft:white_concrete
fill 439 269 510 439 307 510 minecraft:black_concrete
setblock 442 269 513 minecraft:light[level=14]
setblock 442 269 521 minecraft:light[level=14]
setblock 442 269 529 minecraft:light[level=14]
setblock 442 269 537 minecraft:light[level=14]
setblock 442 269 545 minecraft:light[level=14]
setblock 447 269 552 minecraft:light_blue_stained_glass
setblock 450 269 513 minecraft:light[level=14]
setblock 450 269 521 minecraft:light[level=14]
setblock 450 269 529 minecraft:light[level=14]
setblock 450 269 537 minecraft:light[level=14]
setblock 450 269 545 minecraft:light[level=14]
setblock 454 269 510 minecraft:black_concrete
setblock 457 269 540 minecraft:gold_block
setblock 458 269 513 minecraft:light[level=14]
setblock 458 269 521 minecraft:light[level=14]
setblock 458 269 529 minecraft:light[level=14]
setblock 458 269 537 minecraft:light[level=14]
setblock 458 269 539 minecraft:gold_block
setblock 458 269 545 minecraft:light[level=14]
setblock 465 269 537 minecraft:light_blue_stained_glass
fill 423 270 518 423 272 518 minecraft:gold_block
setblock 423 270 527 minecraft:white_concrete
fill 423 270 534 423 272 534 minecraft:gold_block
fill 423 270 550 423 272 550 minecraft:gold_block
fill 427 270 510 427 272 510 minecraft:gold_block
fill 433 270 510 433 307 510 minecraft:black_concrete
fill 436 270 528 436 272 528 minecraft:blue_stained_glass
fill 436 270 529 436 273 529 minecraft:waxed_cut_copper
fill 436 270 530 436 273 534 minecraft:blue_stained_glass
fill 436 270 535 436 273 535 minecraft:waxed_cut_copper
fill 436 270 536 436 272 536 minecraft:blue_stained_glass
fill 436 270 552 436 285 552 minecraft:black_concrete
fill 437 270 526 437 272 527 minecraft:blue_stained_glass
fill 437 270 537 437 272 538 minecraft:blue_stained_glass
fill 437 270 552 437 272 552 minecraft:gold_block
fill 438 270 525 438 273 525 minecraft:blue_stained_glass
fill 438 270 539 438 273 539 minecraft:blue_stained_glass
fill 439 270 524 439 273 524 minecraft:waxed_cut_copper
fill 439 270 540 439 273 540 minecraft:waxed_cut_copper
fill 440 270 523 440 273 523 minecraft:blue_stained_glass
fill 440 270 541 440 273 541 minecraft:blue_stained_glass
fill 441 270 522 442 272 522 minecraft:blue_stained_glass
fill 441 270 542 442 272 542 minecraft:blue_stained_glass
fill 443 270 510 443 272 510 minecraft:gold_block
fill 443 270 521 443 272 521 minecraft:blue_stained_glass
fill 443 270 543 443 272 543 minecraft:blue_stained_glass
fill 444 270 521 444 273 521 minecraft:waxed_cut_copper
fill 444 270 543 444 273 543 minecraft:waxed_cut_copper
fill 445 270 521 449 273 521 minecraft:blue_stained_glass
fill 445 270 543 449 273 543 minecraft:blue_stained_glass
fill 447 270 552 447 293 552 minecraft:black_concrete
fill 450 270 521 450 273 521 minecraft:waxed_cut_copper
fill 450 270 543 450 273 543 minecraft:waxed_cut_copper
fill 451 270 521 451 272 521 minecraft:blue_stained_glass
fill 451 270 543 451 272 543 minecraft:blue_stained_glass
fill 452 270 522 453 272 522 minecraft:blue_stained_glass
fill 452 270 542 453 272 542 minecraft:blue_stained_glass
fill 453 270 552 453 272 552 minecraft:gold_block
setblock 454 270 510 minecraft:white_concrete
fill 454 270 523 454 273 523 minecraft:blue_stained_glass
fill 454 270 541 454 273 541 minecraft:blue_stained_glass
fill 455 270 524 455 273 524 minecraft:waxed_cut_copper
fill 455 270 540 455 273 540 minecraft:waxed_cut_copper
fill 456 270 525 456 273 525 minecraft:blue_stained_glass
fill 456 270 539 456 273 539 minecraft:blue_stained_glass
fill 457 270 526 457 272 527 minecraft:blue_stained_glass
fill 457 270 537 457 272 538 minecraft:blue_stained_glass
fill 458 270 528 458 272 528 minecraft:blue_stained_glass
fill 458 270 529 458 273 529 minecraft:waxed_cut_copper
fill 458 270 530 458 273 534 minecraft:blue_stained_glass
fill 458 270 535 458 273 535 minecraft:waxed_cut_copper
fill 458 270 536 458 272 536 minecraft:blue_stained_glass
fill 459 270 510 459 272 510 minecraft:gold_block
setblock 462 270 510 minecraft:sea_lantern
setblock 465 270 511 minecraft:sea_lantern
fill 465 270 520 465 272 520 minecraft:gold_block
fill 465 270 536 465 272 536 minecraft:gold_block
setblock 465 270 537 minecraft:black_concrete
setblock 465 270 539 minecraft:light_blue_stained_glass
setblock 423 271 513 minecraft:white_concrete
fill 423 271 527 423 283 527 minecraft:black_concrete
setblock 425 271 510 minecraft:white_concrete
fill 426 271 510 426 282 510 minecraft:black_concrete
fill 438 271 526 438 274 526 minecraft:blue_stained_glass
fill 438 271 538 438 274 538 minecraft:blue_stained_glass
fill 441 271 523 441 274 523 minecraft:blue_stained_glass
fill 441 271 541 441 274 541 minecraft:blue_stained_glass
fill 453 271 523 453 274 523 minecraft:blue_stained_glass
fill 453 271 541 453 274 541 minecraft:blue_stained_glass
fill 454 271 510 454 272 510 minecraft:black_concrete
fill 456 271 526 456 274 526 minecraft:blue_stained_glass
fill 456 271 538 456 274 538 minecraft:blue_stained_glass
fill 462 271 510 462 307 510 minecraft:black_concrete
fill 465 271 511 465 307 511 minecraft:black_concrete
setblock 465 271 537 minecraft:white_concrete
fill 465 271 539 465 307 539 minecraft:black_concrete
setblock 465 271 551 minecraft:white_concrete
fill 423 272 513 423 307 513 minecraft:black_concrete
fill 423 272 519 423 307 519 minecraft:black_concrete
setblock 423 272 520 minecraft:white_concrete
fill 425 272 510 425 281 510 minecraft:black_concrete
fill 437 272 528 437 274 528 minecraft:blue_stained_glass
fill 437 272 536 437 274 536 minecraft:blue_stained_glass
fill 439 272 525 439 275 525 minecraft:blue_stained_glass
fill 439 272 539 439 275 539 minecraft:blue_stained_glass
fill 440 272 524 440 275 524 minecraft:blue_stained_glass
fill 440 272 540 440 275 540 minecraft:blue_stained_glass
fill 443 272 522 443 274 522 minecraft:blue_stained_glass
fill 443 272 542 443 274 542 minecraft:blue_stained_glass
fill 451 272 522 451 274 522 minecraft:blue_stained_glass
fill 451 272 542 451 274 542 minecraft:blue_stained_glass
fill 454 272 524 454 275 524 minecraft:blue_stained_glass
fill 454 272 540 454 275 540 minecraft:blue_stained_glass
fill 455 272 525 455 275 525 minecraft:blue_stained_glass
fill 455 272 539 455 275 539 minecraft:blue_stained_glass
fill 457 272 528 457 274 528 minecraft:blue_stained_glass
fill 457 272 536 457 274 536 minecraft:blue_stained_glass
fill 465 272 537 465 307 537 minecraft:black_concrete
fill 465 272 551 465 307 551 minecraft:black_concrete
fill 423 273 518 423 287 518 minecraft:black_concrete
fill 423 273 520 423 307 520 minecraft:black_concrete
fill 423 273 534 423 287 534 minecraft:black_concrete
setblock 423 273 547 minecraft:white_concrete
fill 423 273 550 423 287 550 minecraft:black_concrete
fill 427 273 510 427 282 510 minecraft:black_concrete
setblock 437 273 527 minecraft:blue_stained_glass
fill 437 273 529 437 275 529 minecraft:waxed_cut_copper
fill 437 273 535 437 275 535 minecraft:waxed_cut_copper
setblock 437 273 537 minecraft:blue_stained_glass
fill 437 273 552 437 287 552 minecraft:black_concrete
setblock 442 273 522 minecraft:blue_stained_glass
setblock 442 273 542 minecraft:blue_stained_glass
fill 443 273 510 443 287 510 minecraft:black_concrete
fill 444 273 522 444 275 522 minecraft:waxed_cut_copper
fill 444 273 542 444 275 542 minecraft:waxed_cut_copper
fill 450 273 522 450 275 522 minecraft:waxed_cut_copper
fill 450 273 542 450 275 542 minecraft:waxed_cut_copper
setblock 451 273 552 minecraft:sea_lantern
setblock 452 273 522 minecraft:blue_stained_glass
setblock 452 273 542 minecraft:blue_stained_glass
fill 453 273 552 453 287 552 minecraft:black_concrete
setblock 454 273 510 minecraft:sea_lantern
setblock 457 273 527 minecraft:blue_stained_glass
fill 457 273 529 457 275 529 minecraft:waxed_cut_copper
fill 457 273 535 457 275 535 minecraft:waxed_cut_copper
setblock 457 273 537 minecraft:blue_stained_glass
fill 459 273 510 459 287 510 minecraft:black_concrete
setblock 465 273 513 minecraft:light_blue_stained_glass
fill 465 273 520 465 287 520 minecraft:black_concrete
fill 465 273 536 465 287 536 minecraft:black_concrete
setblock 423 274 514 minecraft:white_concrete
fill 423 274 515 423 281 517 minecraft:black_concrete
fill 423 274 547 423 307 547 minecraft:black_concrete
setblock 432 274 510 minecraft:sea_lantern
fill 436 274 531 437 274 533 minecraft:blue_stained_glass
fill 437 274 530 437 275 530 minecraft:blue_stained_glass
fill 437 274 534 437 275 534 minecraft:blue_stained_glass
fill 438 274 527 438 275 527 minecraft:blue_stained_glass
fill 438 274 537 438 275 537 minecraft:blue_stained_glass
fill 439 274 526 439 276 526 minecraft:blue_stained_glass
fill 439 274 538 439 276 538 minecraft:blue_stained_glass
fill 441 274 524 441 276 524 minecraft:blue_stained_glass
fill 441 274 540 441 276 540 minecraft:blue_stained_glass
fill 442 274 523 442 275 523 minecraft:blue_stained_glass
fill 442 274 541 442 275 541 minecraft:blue_stained_glass
fill 445 274 522 449 275 522 minecraft:blue_stained_glass
fill 445 274 542 449 275 542 minecraft:blue_stained_glass
fill 446 274 521 448 274 521 minecraft:blue_stained_glass
fill 446 274 543 448 274 543 minecraft:blue_stained_glass
fill 451 274 552 451 281 552 minecraft:black_concrete
fill 452 274 523 452 275 523 minecraft:blue_stained_glass
fill 452 274 541 452 275 541 minecraft:blue_stained_glass
fill 453 274 524 453 276 524 minecraft:blue_stained_glass
fill 453 274 540 453 276 540 minecraft:blue_stained_glass
fill 454 274 510 454 307 510 minecraft:black_concrete
fill 455 274 526 455 276 526 minecraft:blue_stained_glass
fill 455 274 538 455 276 538 minecraft:blue_stained_glass
fill 456 274 527 456 275 527 minecraft:blue_stained_glass
fill 456 274 537 456 275 537 minecraft:blue_stained_glass
fill 457 274 530 457 275 534 minecraft:blue_stained_glass
fill 458 274 531 458 274 533 minecraft:blue_stained_glass
setblock 465 274 513 minecraft:white_concrete
setblock 465 274 528 minecraft:light_blue_stained_glass
fill 465 274 529 465 297 531 minecraft:black_concrete
fill 423 275 514 423 299 514 minecraft:black_concrete
fill 432 275 510 432 307 510 minecraft:black_concrete
fill 437 275 531 437 276 533 minecraft:blue_stained_glass
fill 438 275 528 438 276 529 minecraft:blue_stained_glass
fill 438 275 535 438 276 536 minecraft:blue_stained_glass
fill 439 275 527 439 276 527 minecraft:blue_stained_glass
fill 439 275 537 439 276 537 minecraft:blue_stained_glass
fill 440 275 525 440 276 525 minecraft:waxed_cut_copper
fill 440 275 539 440 276 539 minecraft:waxed_cut_copper
fill 442 275 524 442 276 524 minecraft:blue_stained_glass
fill 442 275 540 442 276 540 minecraft:blue_stained_glass
fill 443 275 523 444 276 523 minecraft:blue_stained_glass
fill 443 275 541 444 276 541 minecraft:blue_stained_glass
fill 450 275 523 451 276 523 minecraft:blue_stained_glass
fill 450 275 541 451 276 541 minecraft:blue_stained_glass
fill 452 275 524 452 276 524 minecraft:blue_stained_glass
fill 452 275 540 452 276 540 minecraft:blue_stained_glass
fill 454 275 525 454 276 525 minecraft:waxed_cut_copper
fill 454 275 539 454 276 539 minecraft:waxed_cut_copper
fill 455 275 527 455 276 527 minecraft:blue_stained_glass
fill 455 275 537 455 276 537 minecraft:blue_stained_glass
fill 456 275 528 456 276 529 minecraft:blue_stained_glass
fill 456 275 535 456 276 536 minecraft:blue_stained_glass
setblock 457 275 552 minecraft:sea_lantern
fill 465 275 513 465 278 513 minecraft:black_concrete
fill 465 275 528 465 307 528 minecraft:black_concrete
setblock 423 276 512 minecraft:sea_lantern
setblock 423 276 525 minecraft:light_blue_stained_glass
fill 438 276 530 438 277 534 minecraft:blue_stained_glass
fill 439 276 528 439 277 528 minecraft:blue_stained_glass
fill 439 276 536 439 277 536 minecraft:blue_stained_glass
fill 440 276 526 440 277 526 minecraft:blue_stained_glass
fill 440 276 538 440 277 538 minecraft:blue_stained_glass
fill 441 276 525 441 277 525 minecraft:blue_stained_glass
fill 441 276 539 441 277 539 minecraft:blue_stained_glass
fill 443 276 524 443 277 524 minecraft:blue_stained_glass
fill 443 276 540 443 277 540 minecraft:blue_stained_glass
fill 445 276 523 449 277 523 minecraft:blue_stained_glass
fill 445 276 541 449 277 541 minecraft:blue_stained_glass
fill 446 276 522 448 276 522 minecraft:blue_stained_glass
fill 446 276 542 448 276 542 minecraft:blue_stained_glass
fill 451 276 524 451 277 524 minecraft:blue_stained_glass
fill 451 276 540 451 277 540 minecraft:blue_stained_glass
fill 453 276 525 453 277 525 minecraft:blue_stained_glass
fill 453 276 539 453 277 539 minecraft:blue_stained_glass
fill 454 276 526 454 277 526 minecraft:blue_stained_glass
fill 454 276 538 454 277 538 minecraft:blue_stained_glass
setblock 454 276 552 minecraft:light_blue_stained_glass
fill 455 276 528 455 277 528 minecraft:blue_stained_glass
fill 455 276 536 455 277 536 minecraft:blue_stained_glass
fill 455 276 552 457 284 552 minecraft:black_concrete
fill 456 276 530 456 277 534 minecraft:blue_stained_glass
fill 457 276 531 457 276 533 minecraft:blue_stained_glass
fill 423 277 512 423 307 512 minecraft:black_concrete
fill 423 277 525 423 307 525 minecraft:black_concrete
setblock 426 277 513 minecraft:light[level=14]
setblock 426 277 521 minecraft:light[level=14]
setblock 426 277 529 minecraft:light[level=14]
setblock 426 277 537 minecraft:light[level=14]
setblock 426 277 545 minecraft:light[level=14]
setblock 434 277 513 minecraft:light[level=14]
setblock 434 277 521 minecraft:light[level=14]
setblock 434 277 529 minecraft:light[level=14]
setblock 434 277 537 minecraft:light[level=14]
setblock 434 277 545 minecraft:light[level=14]
setblock 439 277 529 minecraft:blue_stained_glass
fill 439 277 530 439 278 530 minecraft:waxed_cut_copper
fill 439 277 531 439 278 533 minecraft:blue_stained_glass
fill 439 277 534 439 278 534 minecraft:waxed_cut_copper
setblock 439 277 535 minecraft:blue_stained_glass
fill 440 277 527 440 277 528 minecraft:blue_stained_glass
fill 440 277 536 440 277 537 minecraft:blue_stained_glass
setblock 441 277 526 minecraft:waxed_cut_copper
setblock 441 277 538 minecraft:waxed_cut_copper
setblock 442 277 513 minecraft:light[level=14]
setblock 442 277 521 minecraft:light[level=14]
fill 442 277 525 443 277 525 minecraft:blue_stained_glass
setblock 442 277 529 minecraft:light[level=14]
setblock 442 277 537 minecraft:light[level=14]
fill 442 277 539 443 277 539 minecraft:blue_stained_glass
setblock 442 277 545 minecraft:light[level=14]
setblock 444 277 524 minecraft:blue_stained_glass
setblock 444 277 540 minecraft:blue_stained_glass
fill 445 277 524 445 278 524 minecraft:waxed_cut_copper
fill 445 277 540 445 278 540 minecraft:waxed_cut_copper
fill 446 277 524 448 278 524 minecraft:blue_stained_glass
fill 446 277 540 448 278 540 minecraft:blue_stained_glass
fill 449 277 524 449 278 524 minecraft:waxed_cut_copper
fill 449 277 540 449 278 540 minecraft:waxed_cut_copper
setblock 450 277 513 minecraft:light[level=14]
setblock 450 277 521 minecraft:light[level=14]
setblock 450 277 524 minecraft:blue_stained_glass
setblock 450 277 529 minecraft:light[level=14]
setblock 450 277 537 minecraft:light[level=14]
setblock 450 277 540 minecraft:blue_stained_glass
setblock 450 277 545 minecraft:light[level=14]
fill 451 277 525 452 277 525 minecraft:blue_stained_glass
fill 451 277 539 452 277 539 minecraft:blue_stained_glass
setblock 453 277 526 minecraft:waxed_cut_copper
setblock 453 277 538 minecraft:waxed_cut_copper
fill 454 277 527 454 277 528 minecraft:blue_stained_glass
fill 454 277 536 454 277 537 minecraft:blue_stained_glass
fill 454 277 552 454 287 552 minecraft:black_concrete
setblock 455 277 529 minecraft:blue_stained_glass
fill 455 277 530 455 278 530 minecraft:waxed_cut_copper
fill 455 277 531 455 278 533 minecraft:blue_stained_glass
fill 455 277 534 455 278 534 minecraft:waxed_cut_copper
setblock 455 277 535 minecraft:blue_stained_glass
setblock 458 277 513 minecraft:light[level=14]
setblock 458 277 521 minecraft:light[level=14]
setblock 458 277 529 minecraft:light[level=14]
setblock 458 277 537 minecraft:light[level=14]
setblock 458 277 545 minecraft:light[level=14]
fill 465 277 540 465 289 540 minecraft:black_concrete
setblock 465 277 541 minecraft:sea_lantern
setblock 465 277 545 minecraft:sea_lantern
setblock 430 278 510 minecraft:sea_lantern
setblock 431 278 552 minecraft:white_concrete
fill 440 278 528 440 278 529 minecraft:blue_stained_glass
fill 440 278 530 440 279 530 minecraft:waxed_cut_copper
fill 440 278 531 440 280 533 minecraft:blue_stained_glass
fill 440 278 534 440 279 534 minecraft:waxed_cut_copper
fill 440 278 535 440 278 536 minecraft:blue_stained_glass
fill 441 278 527 441 278 528 minecraft:blue_stained_glass
fill 441 278 536 441 278 537 minecraft:blue_stained_glass
fill 442 278 526 443 278 526 minecraft:blue_stained_glass
fill 442 278 527 442 279 527 minecraft:waxed_cut_copper
fill 442 278 537 442 279 537 minecraft:waxed_cut_copper
fill 442 278 538 443 278 538 minecraft:blue_stained_glass
fill 443 278 525 444 278 525 minecraft:blue_stained_glass
fill 443 278 539 444 278 539 minecraft:blue_stained_glass
fill 445 278 525 445 279 525 minecraft:waxed_cut_copper
fill 445 278 539 445 279 539 minecraft:waxed_cut_copper
fill 446 278 525 448 280 525 minecraft:blue_stained_glass
fill 446 278 539 448 280 539 minecraft:blue_stained_glass
fill 449 278 525 449 279 525 minecraft:waxed_cut_copper
fill 449 278 539 449 279 539 minecraft:waxed_cut_copper
fill 450 278 525 451 278 525 minecraft:blue_stained_glass
fill 450 278 539 451 278 539 minecraft:blue_stained_glass
fill 451 278 526 452 278 526 minecraft:blue_stained_glass
fill 451 278 538 452 278 538 minecraft:blue_stained_glass
fill 452 278 527 452 279 527 minecraft:waxed_cut_copper
fill 452 278 537 452 279 537 minecraft:waxed_cut_copper
fill 453 278 527 453 278 528 minecraft:blue_stained_glass
fill 453 278 536 453 278 537 minecraft:blue_stained_glass
fill 454 278 528 454 278 529 minecraft:blue_stained_glass
fill 454 278 530 454 279 530 minecraft:waxed_cut_copper
fill 454 278 531 454 280 533 minecraft:blue_stained_glass
fill 454 278 534 454 279 534 minecraft:waxed_cut_copper
fill 454 278 535 454 278 536 minecraft:blue_stained_glass
setblock 465 278 538 minecraft:light_blue_stained_glass
fill 465 278 541 465 298 541 minecraft:black_concrete
fill 465 278 545 465 307 545 minecraft:black_concrete
fill 430 279 510 430 307 510 minecraft:black_concrete
fill 431 279 552 431 293 552 minecraft:black_concrete
fill 441 279 528 441 280 536 minecraft:blue_stained_glass
fill 442 279 528 442 280 530 minecraft:blue_stained_glass
fill 442 279 534 442 280 536 minecraft:blue_stained_glass
fill 443 279 526 445 280 527 minecraft:blue_stained_glass
setblock 443 279 528 minecraft:waxed_cut_copper
setblock 443 279 536 minecraft:waxed_cut_copper
fill 443 279 537 445 280 538 minecraft:blue_stained_glass
fill 446 279 526 451 280 526 minecraft:blue_stained_glass
fill 446 279 538 451 280 538 minecraft:blue_stained_glass
fill 449 279 527 451 280 527 minecraft:blue_stained_glass
fill 449 279 537 451 280 537 minecraft:blue_stained_glass
setblock 451 279 528 minecraft:waxed_cut_copper
setblock 451 279 536 minecraft:waxed_cut_copper
fill 452 279 528 453 280 530 minecraft:blue_stained_glass
fill 452 279 534 453 280 536 minecraft:blue_stained_glass
fill 453 279 531 453 280 533 minecraft:blue_stained_glass
setblock 465 279 513 minecraft:light_blue_stained_glass
fill 465 279 538 465 307 538 minecraft:black_concrete
setblock 423 280 543 minecraft:sea_lantern
fill 424 280 511 437 280 551 minecraft:polished_blackstone
fill 438 280 511 438 280 528 minecraft:polished_blackstone
fill 438 280 529 439 280 535 minecraft:blue_stained_glass
fill 438 280 536 438 280 551 minecraft:polished_blackstone
fill 439 280 511 439 280 526 minecraft:polished_blackstone
fill 439 280 527 440 280 528 minecraft:blue_stained_glass
fill 439 280 536 440 280 537 minecraft:blue_stained_glass
fill 439 280 538 439 280 551 minecraft:polished_blackstone
fill 440 280 511 440 280 525 minecraft:polished_blackstone
fill 440 280 526 442 280 526 minecraft:blue_stained_glass
fill 440 280 529 440 280 530 minecraft:blue_stained_glass
fill 440 280 534 440 280 535 minecraft:blue_stained_glass
fill 440 280 538 442 280 538 minecraft:blue_stained_glass
fill 440 280 539 440 280 551 minecraft:polished_blackstone
fill 441 280 511 441 280 524 minecraft:polished_blackstone
fill 441 280 525 445 280 525 minecraft:blue_stained_glass
fill 441 280 527 442 280 527 minecraft:blue_stained_glass
fill 441 280 537 442 280 537 minecraft:blue_stained_glass
fill 441 280 539 445 280 539 minecraft:blue_stained_glass
fill 441 280 540 441 280 551 minecraft:polished_blackstone
fill 442 280 511 443 280 523 minecraft:polished_blackstone
fill 442 280 524 452 280 524 minecraft:blue_stained_glass
fill 442 280 531 443 280 533 minecraft:blue_stained_glass
fill 442 280 540 452 280 540 minecraft:blue_stained_glass
fill 442 280 541 443 280 551 minecraft:polished_blackstone
fill 443 280 528 444 280 530 minecraft:blue_stained_glass
fill 443 280 534 444 280 536 minecraft:blue_stained_glass
fill 444 280 511 464 280 522 minecraft:polished_blackstone
fill 444 280 523 450 280 523 minecraft:blue_stained_glass
fill 444 280 531 444 280 533 minecraft:sea_lantern
fill 444 280 541 450 280 541 minecraft:blue_stained_glass
fill 444 280 542 464 280 551 minecraft:polished_blackstone
fill 445 280 528 445 280 529 minecraft:blue_stained_glass
fill 445 280 530 445 280 531 minecraft:sea_lantern
fill 445 280 533 445 280 534 minecraft:sea_lantern
fill 445 280 535 445 280 536 minecraft:blue_stained_glass
fill 446 280 527 448 280 528 minecraft:blue_stained_glass
fill 446 280 529 446 280 530 minecraft:sea_lantern
fill 446 280 534 446 280 535 minecraft:sea_lantern
fill 446 280 536 448 280 537 minecraft:blue_stained_glass
fill 447 280 529 448 280 529 minecraft:sea_lantern
fill 447 280 535 448 280 535 minecraft:sea_lantern
fill 448 280 530 449 280 530 minecraft:sea_lantern
fill 448 280 534 449 280 534 minecraft:sea_lantern
fill 449 280 525 453 280 525 minecraft:blue_stained_glass
fill 449 280 528 451 280 529 minecraft:blue_stained_glass
fill 449 280 531 450 280 531 minecraft:sea_lantern
fill 449 280 533 450 280 533 minecraft:sea_lantern
fill 449 280 535 451 280 536 minecraft:blue_stained_glass
fill 449 280 539 453 280 539 minecraft:blue_stained_glass
fill 450 280 530 451 280 530 minecraft:blue_stained_glass
setblock 450 280 532 minecraft:sea_lantern
fill 450 280 534 451 280 534 minecraft:blue_stained_glass
fill 451 280 523 464 280 523 minecraft:polished_blackstone
fill 451 280 531 452 280 533 minecraft:blue_stained_glass
fill 451 280 541 464 280 541 minecraft:polished_blackstone
fill 452 280 526 454 280 527 minecraft:blue_stained_glass
fill 452 280 537 454 280 538 minecraft:blue_stained_glass
fill 453 280 524 464 280 524 minecraft:polished_blackstone
fill 453 280 540 464 280 540 minecraft:polished_blackstone
fill 454 280 525 464 280 525 minecraft:polished_blackstone
fill 454 280 528 455 280 530 minecraft:blue_stained_glass
fill 454 280 534 455 280 536 minecraft:blue_stained_glass
fill 454 280 539 464 280 539 minecraft:polished_blackstone
fill 455 280 526 464 280 526 minecraft:polished_blackstone
setblock 455 280 527 minecraft:blue_stained_glass
fill 455 280 531 456 280 533 minecraft:blue_stained_glass
setblock 455 280 537 minecraft:blue_stained_glass
fill 455 280 538 464 280 538 minecraft:polished_blackstone
fill 456 280 527 464 280 528 minecraft:polished_blackstone
fill 456 280 529 456 280 530 minecraft:blue_stained_glass
fill 456 280 534 456 280 535 minecraft:blue_stained_glass
fill 456 280 536 464 280 537 minecraft:polished_blackstone
fill 457 280 529 464 280 535 minecraft:polished_blackstone
fill 465 280 513 465 295 513 minecraft:black_concrete
setblock 465 280 535 minecraft:light_blue_stained_glass
fill 423 281 543 423 285 543 minecraft:black_concrete
fill 444 281 510 444 303 510 minecraft:black_concrete
fill 444 281 531 444 281 533 minecraft:blue_stained_glass
setblock 445 281 510 minecraft:sea_lantern
setblock 445 281 530 minecraft:waxed_cut_copper
setblock 445 281 531 minecraft:blue_stained_glass
setblock 445 281 533 minecraft:blue_stained_glass
setblock 445 281 534 minecraft:waxed_cut_copper
fill 446 281 529 446 281 530 minecraft:blue_stained_glass
fill 446 281 534 446 281 535 minecraft:blue_stained_glass
fill 447 281 529 448 281 529 minecraft:blue_stained_glass
fill 447 281 535 448 281 535 minecraft:blue_stained_glass
setblock 448 281 530 minecraft:blue_stained_glass
setblock 448 281 534 minecraft:blue_stained_glass
setblock 449 281 530 minecraft:waxed_cut_copper
fill 449 281 531 450 281 531 minecraft:blue_stained_glass
fill 449 281 533 450 281 533 minecraft:blue_stained_glass
setblock 449 281 534 minecraft:waxed_cut_copper
setblock 450 281 532 minecraft:blue_stained_glass
setblock 465 281 526 minecraft:white_concrete
fill 465 281 535 465 307 535 minecraft:black_concrete
fill 423 282 515 423 305 516 minecraft:black_concrete
setblock 423 282 517 minecraft:sea_lantern
setblock 425 282 510 minecraft:sea_lantern
setblock 429 282 552 minecraft:light_blue_stained_glass
fill 445 282 510 445 303 510 minecraft:black_concrete
setblock 451 282 552 minecraft:sea_lantern
fill 465 282 526 465 307 526 minecraft:black_concrete
fill 423 283 517 423 307 517 minecraft:black_concrete
fill 425 283 510 425 307 510 minecraft:black_concrete
setblock 426 283 510 minecraft:light_blue_stained_glass
setblock 427 283 510 minecraft:sea_lantern
fill 429 283 552 429 307 552 minecraft:black_concrete
setblock 450 283 510 minecraft:white_concrete
fill 451 283 552 451 307 552 minecraft:black_concrete
setblock 465 283 549 minecraft:white_concrete
setblock 423 284 527 minecraft:white_concrete
fill 426 284 510 427 287 510 minecraft:black_concrete
setblock 428 284 510 minecraft:sea_lantern
setblock 440 284 510 minecraft:white_concrete
setblock 445 284 552 minecraft:white_concrete
fill 450 284 510 450 288 510 minecraft:black_concrete
fill 456 284 510 457 307 510 minecraft:black_concrete
setblock 458 284 510 minecraft:sea_lantern
fill 465 284 549 465 285 549 minecraft:black_concrete
setblock 423 285 521 minecraft:light_blue_stained_glass
fill 423 285 527 423 287 527 minecraft:black_concrete
setblock 423 285 528 minecraft:light_blue_stained_glass
setblock 423 285 544 minecraft:light_blue_stained_glass
fill 424 285 520 426 286 520 minecraft:waxed_copper_block
setblock 426 285 513 minecraft:light[level=14]
setblock 426 285 521 minecraft:light[level=14]
setblock 426 285 529 minecraft:light[level=14]
setblock 426 285 537 minecraft:light[level=14]
setblock 426 285 545 minecraft:light[level=14]
fill 428 285 510 428 287 510 minecraft:black_concrete
setblock 434 285 513 minecraft:light[level=14]
setblock 434 285 521 minecraft:light[level=14]
setblock 434 285 529 minecraft:light[level=14]
setblock 434 285 537 minecraft:light[level=14]
setblock 434 285 545 minecraft:light[level=14]
fill 440 285 510 440 292 510 minecraft:black_concrete
setblock 442 285 513 minecraft:light[level=14]
setblock 442 285 521 minecraft:light[level=14]
setblock 442 285 529 minecraft:light[level=14]
setblock 442 285 537 minecraft:light[level=14]
setblock 442 285 545 minecraft:light[level=14]
fill 445 285 552 445 307 552 minecraft:black_concrete
setblock 450 285 513 minecraft:light[level=14]
setblock 450 285 521 minecraft:light[level=14]
setblock 450 285 529 minecraft:light[level=14]
setblock 450 285 537 minecraft:light[level=14]
setblock 450 285 545 minecraft:light[level=14]
setblock 455 285 552 minecraft:white_concrete
fill 456 285 552 457 289 552 minecraft:black_concrete
fill 458 285 510 458 307 510 minecraft:black_concrete
setblock 458 285 513 minecraft:light[level=14]
setblock 458 285 521 minecraft:light[level=14]
setblock 458 285 529 minecraft:light[level=14]
setblock 458 285 537 minecraft:light[level=14]
setblock 458 285 545 minecraft:light[level=14]
setblock 465 285 518 minecraft:sea_lantern
setblock 465 285 542 minecraft:sea_lantern
fill 423 286 521 423 307 521 minecraft:black_concrete
fill 423 286 528 423 302 528 minecraft:black_concrete
setblock 423 286 543 minecraft:white_concrete
fill 423 286 544 423 307 544 minecraft:black_concrete
fill 430 286 536 434 293 537 minecraft:red_terracotta
fill 431 286 535 433 293 535 minecraft:red_terracotta
fill 431 286 538 433 293 538 minecraft:red_terracotta
setblock 436 286 552 minecraft:sea_lantern
fill 455 286 552 455 307 552 minecraft:black_concrete
setblock 461 286 552 minecraft:light_blue_stained_glass
fill 462 286 552 462 307 552 minecraft:black_concrete
setblock 465 286 512 minecraft:white_concrete
fill 465 286 518 465 307 518 minecraft:black_concrete
fill 465 286 542 465 307 542 minecraft:black_concrete
setblock 465 286 549 minecraft:sea_lantern
fill 423 287 543 423 307 543 minecraft:black_concrete
fill 429 287 535 429 292 538 minecraft:red_terracotta
fill 430 287 534 430 292 535 minecraft:red_terracotta
fill 430 287 538 430 292 539 minecraft:red_terracotta
fill 431 287 534 434 292 534 minecraft:red_terracotta
fill 431 287 539 434 292 539 minecraft:red_terracotta
fill 434 287 535 435 292 535 minecraft:red_terracotta
fill 434 287 538 434 292 538 minecraft:red_terracotta
fill 435 287 536 435 292 537 minecraft:red_terracotta
fill 436 287 552 436 299 552 minecraft:black_concrete
setblock 451 287 510 minecraft:light_blue_stained_glass
fill 461 287 552 461 307 552 minecraft:black_concrete
fill 465 287 512 465 304 512 minecraft:black_concrete
fill 465 287 549 465 296 549 minecraft:black_concrete
fill 423 288 518 423 290 518 minecraft:gold_block
setblock 423 288 527 minecraft:white_concrete
fill 423 288 534 423 290 534 minecraft:gold_block
fill 423 288 550 423 290 550 minecraft:gold_block
fill 426 288 510 426 307 510 minecraft:black_concrete
fill 427 288 510 427 290 510 minecraft:gold_block
setblock 428 288 510 minecraft:white_concrete
fill 428 288 536 428 291 537 minecraft:red_terracotta
fill 429 288 534 429 291 534 minecraft:red_terracotta
fill 429 288 539 429 291 539 minecraft:red_terracotta
fill 430 288 533 433 291 533 minecraft:red_terracotta
fill 431 288 540 433 291 540 minecraft:red_terracotta
setblock 432 288 552 minecraft:sea_lantern
fill 435 288 534 435 291 534 minecraft:red_terracotta
fill 435 288 538 435 291 538 minecraft:red_terracotta
fill 437 288 515 440 295 518 minecraft:yellow_concrete
fill 437 288 552 437 290 552 minecraft:gold_block
fill 438 288 514 440 295 514 minecraft:yellow_concrete
fill 441 288 515 441 295 517 minecraft:yellow_concrete
fill 443 288 510 443 290 510 minecraft:gold_block
fill 451 288 510 451 307 510 minecraft:black_concrete
fill 453 288 552 453 290 552 minecraft:gold_block
setblock 454 288 552 minecraft:white_concrete
fill 459 288 510 459 290 510 minecraft:gold_block
fill 465 288 520 465 290 520 minecraft:gold_block
fill 465 288 536 465 290 536 minecraft:gold_block
fill 423 289 527 423 307 527 minecraft:black_concrete
fill 428 289 510 428 307 510 minecraft:black_concrete
fill 428 289 535 428 290 535 minecraft:red_terracotta
fill 428 289 538 428 290 538 minecraft:red_terracotta
fill 430 289 540 430 290 540 minecraft:red_terracotta
fill 432 289 552 432 291 552 minecraft:black_concrete
fill 434 289 533 434 290 533 minecraft:red_terracotta
fill 434 289 540 434 290 540 minecraft:red_terracotta
fill 435 289 539 435 290 539 minecraft:red_terracotta
fill 436 289 514 436 294 518 minecraft:yellow_concrete
fill 436 289 536 436 290 537 minecraft:red_terracotta
fill 437 289 514 437 294 514 minecraft:yellow_concrete
fill 437 289 519 441 294 519 minecraft:yellow_concrete
fill 438 289 513 440 294 513 minecraft:yellow_concrete
fill 441 289 514 441 294 514 minecraft:yellow_concrete
fill 441 289 518 441 294 518 minecraft:yellow_concrete
fill 442 289 515 442 294 517 minecraft:yellow_concrete
setblock 450 289 510 minecraft:light_blue_stained_glass
setblock 452 289 552 minecraft:light_blue_stained_glass
fill 454 289 552 454 307 552 minecraft:black_concrete
setblock 465 289 521 minecraft:sea_lantern
setblock 423 290 538 minecraft:white_concrete
fill 435 290 515 435 293 518 minecraft:yellow_concrete
fill 436 290 519 436 293 519 minecraft:yellow_concrete
fill 437 290 513 437 293 513 minecraft:yellow_concrete
fill 437 290 520 440 293 520 minecraft:yellow_concrete
fill 441 290 513 441 293 513 minecraft:yellow_concrete
fill 442 290 514 442 293 514 minecraft:yellow_concrete
fill 442 290 518 442 293 518 minecraft:yellow_concrete
fill 450 290 510 450 300 510 minecraft:black_concrete
fill 452 290 552 452 295 552 minecraft:black_concrete
setblock 456 290 552 minecraft:white_concrete
setblock 457 290 552 minecraft:sea_lantern
setblock 461 290 510 minecraft:light_blue_stained_glass
fill 465 290 521 465 307 521 minecraft:black_concrete
setblock 465 290 540 minecraft:sea_lantern
fill 423 291 518 423 296 518 minecraft:black_concrete
fill 423 291 534 423 296 534 minecraft:black_concrete
fill 423 291 538 423 307 538 minecraft:black_concrete
fill 423 291 550 423 296 550 minecraft:black_concrete
fill 427 291 510 427 296 510 minecraft:black_concrete
fill 435 291 514 435 292 514 minecraft:yellow_concrete
fill 436 291 513 436 292 513 minecraft:yellow_concrete
fill 437 291 552 437 296 552 minecraft:black_concrete
fill 438 291 512 439 292 512 minecraft:yellow_concrete
fill 441 291 520 441 292 520 minecraft:yellow_concrete
fill 442 291 519 442 292 519 minecraft:yellow_concrete
fill 443 291 510 443 296 510 minecraft:black_concrete
fill 443 291 516 443 292 517 minecraft:yellow_concrete
fill 453 291 552 453 296 552 minecraft:black_concrete
fill 456 291 552 457 300 552 minecraft:black_concrete
fill 459 291 510 459 296 510 minecraft:black_concrete
fill 461 291 510 461 307 510 minecraft:black_concrete
fill 465 291 520 465 294 520 minecraft:black_concrete
fill 465 291 536 465 296 536 minecraft:black_concrete
fill 465 291 540 465 303 540 minecraft:black_concrete
setblock 423 292 529 minecraft:light_blue_stained_glass
setblock 432 292 552 minecraft:white_concrete
fill 455 292 510 455 293 510 minecraft:white_concrete
fill 423 293 529 423 307 529 minecraft:black_concrete
setblock 426 293 513 minecraft:light[level=14]
setblock 426 293 521 minecraft:light[level=14]
setblock 426 293 529 minecraft:light[level=14]
setblock 426 293 537 minecraft:light[level=14]
setblock 426 293 545 minecraft:light[level=14]
fill 432 293 552 432 307 552 minecraft:black_concrete
setblock 434 293 513 minecraft:light[level=14]
setblock 434 293 521 minecraft:light[level=14]
setblock 434 293 529 minecraft:light[level=14]
setblock 434 293 545 minecraft:light[level=14]
setblock 440 293 510 minecraft:white_concrete
setblock 442 293 513 minecraft:light[level=14]
setblock 442 293 521 minecraft:light[level=14]
setblock 442 293 529 minecraft:light[level=14]
setblock 442 293 537 minecraft:light[level=14]
setblock 442 293 545 minecraft:light[level=14]
setblock 450 293 513 minecraft:light[level=14]
setblock 450 293 521 minecraft:light[level=14]
setblock 450 293 529 minecraft:light[level=14]
setblock 450 293 537 minecraft:light[level=14]
setblock 450 293 545 minecraft:light[level=14]
setblock 458 293 513 minecraft:light[level=14]
setblock 458 293 521 minecraft:light[level=14]
setblock 458 293 529 minecraft:light[level=14]
setblock 458 293 537 minecraft:light[level=14]
setblock 458 293 545 minecraft:light[level=14]
fill 465 293 515 465 307 515 minecraft:black_concrete
setblock 465 293 516 minecraft:light_blue_stained_glass
fill 465 293 517 465 307 517 minecraft:black_concrete
setblock 431 294 552 minecraft:light_blue_stained_glass
fill 440 294 510 440 307 510 minecraft:black_concrete
setblock 447 294 552 minecraft:sea_lantern
fill 455 294 510 455 307 510 minecraft:black_concrete
setblock 463 294 552 minecraft:white_concrete
fill 465 294 516 465 307 516 minecraft:black_concrete
setblock 423 295 531 minecraft:sea_lantern
fill 431 295 552 431 307 552 minecraft:black_concrete
fill 447 295 552 447 307 552 minecraft:black_concrete
fill 463 295 552 463 307 552 minecraft:black_concrete
setblock 465 295 520 minecraft:white_concrete
fill 423 296 522 423 307 522 minecraft:black_concrete
setblock 423 296 523 minecraft:white_concrete
fill 423 296 531 423 307 531 minecraft:black_concrete
setblock 435 296 510 minecraft:white_concrete
setblock 452 296 552 minecraft:sea_lantern
setblock 465 296 513 minecraft:sea_lantern
setblock 465 296 520 minecraft:black_concrete
fill 423 297 518 423 299 518 minecraft:gold_block
fill 423 297 523 423 307 523 minecraft:black_concrete
fill 423 297 534 423 299 534 minecraft:gold_block
fill 423 297 550 423 299 550 minecraft:gold_block
fill 427 297 510 427 299 510 minecraft:gold_block
fill 435 297 510 435 298 510 minecraft:black_concrete
fill 437 297 552 437 299 552 minecraft:gold_block
fill 443 297 510 443 299 510 minecraft:gold_block
fill 452 297 552 452 307 552 minecraft:black_concrete
fill 453 297 552 453 299 552 minecraft:gold_block
fill 459 297 510 459 299 510 minecraft:gold_block
fill 465 297 513 465 299 513 minecraft:black_concrete
fill 465 297 520 465 299 520 minecraft:gold_block
fill 465 297 536 465 299 536 minecraft:gold_block
setblock 465 297 549 minecraft:sea_lantern
setblock 442 298 510 minecraft:sea_lantern
fill 465 298 529 465 307 529 minecraft:black_concrete
setblock 465 298 530 minecraft:sea_lantern
fill 465 298 531 465 307 531 minecraft:black_concrete
fill 465 298 549 465 299 549 minecraft:black_concrete
setblock 423 299 530 minecraft:sea_lantern
setblock 435 299 510 minecraft:sea_lantern
fill 442 299 510 442 307 510 minecraft:black_concrete
fill 465 299 530 465 307 530 minecraft:black_concrete
setblock 465 299 541 minecraft:white_concrete
setblock 423 300 514 minecraft:sea_lantern
fill 423 300 518 423 307 518 minecraft:black_concrete
fill 423 300 530 423 307 530 minecraft:black_concrete
fill 423 300 534 423 304 534 minecraft:black_concrete
fill 423 300 550 423 307 550 minecraft:black_concrete
setblock 424 300 510 minecraft:white_concrete
setblock 427 300 510 minecraft:sea_lantern
fill 435 300 510 435 307 510 minecraft:black_concrete
setblock 436 300 552 minecraft:light_blue_stained_glass
fill 437 300 552 437 307 552 minecraft:black_concrete
fill 442 300 552 442 307 552 minecraft:black_concrete
fill 443 300 510 443 307 510 minecraft:black_concrete
setblock 443 300 552 minecraft:white_concrete
fill 444 300 552 444 307 552 minecraft:black_concrete
fill 453 300 552 453 307 552 minecraft:black_concrete
fill 459 300 510 459 307 510 minecraft:black_concrete
setblock 465 300 513 minecraft:light_blue_stained_glass
fill 465 300 520 465 305 520 minecraft:black_concrete
fill 465 300 536 465 307 536 minecraft:black_concrete
fill 465 300 541 465 307 541 minecraft:black_concrete
setblock 465 300 549 minecraft:light_blue_stained_glass
fill 423 301 514 423 307 514 minecraft:black_concrete
fill 424 301 510 424 307 510 minecraft:black_concrete
setblock 426 301 513 minecraft:light[level=14]
setblock 426 301 521 minecraft:light[level=14]
setblock 426 301 529 minecraft:light[level=14]
setblock 426 301 537 minecraft:light[level=14]
setblock 426 301 545 minecraft:light[level=14]
fill 427 301 510 427 307 510 minecraft:black_concrete
setblock 434 301 513 minecraft:light[level=14]
setblock 434 301 521 minecraft:light[level=14]
setblock 434 301 529 minecraft:light[level=14]
setblock 434 301 537 minecraft:light[level=14]
setblock 434 301 545 minecraft:light[level=14]
fill 436 301 552 436 307 552 minecraft:black_concrete
fill 440 301 552 440 307 552 minecraft:black_concrete
setblock 441 301 552 minecraft:light_blue_stained_glass
setblock 442 301 513 minecraft:light[level=14]
setblock 442 301 521 minecraft:light[level=14]
setblock 442 301 529 minecraft:light[level=14]
setblock 442 301 537 minecraft:light[level=14]
setblock 442 301 545 minecraft:light[level=14]
fill 443 301 552 443 307 552 minecraft:black_concrete
setblock 450 301 510 minecraft:sea_lantern
setblock 450 301 513 minecraft:light[level=14]
setblock 450 301 521 minecraft:light[level=14]
setblock 450 301 529 minecraft:light[level=14]
setblock 450 301 537 minecraft:light[level=14]
setblock 450 301 545 minecraft:light[level=14]
fill 456 301 552 456 307 552 minecraft:black_concrete
fill 457 301 552 458 301 552 minecraft:white_concrete
setblock 458 301 513 minecraft:light[level=14]
setblock 458 301 521 minecraft:light[level=14]
setblock 458 301 529 minecraft:light[level=14]
setblock 458 301 537 minecraft:light[level=14]
setblock 458 301 545 minecraft:light[level=14]
fill 465 301 513 465 307 513 minecraft:black_concrete
fill 465 301 549 465 307 549 minecraft:black_concrete
fill 441 302 552 441 307 552 minecraft:black_concrete
fill 450 302 510 450 307 510 minecraft:black_concrete
fill 457 302 552 458 307 552 minecraft:black_concrete
setblock 423 303 528 minecraft:white_concrete
setblock 430 303 552 minecraft:white_concrete
fill 423 304 528 423 307 528 minecraft:black_concrete
setblock 423 304 542 minecraft:light_blue_stained_glass
fill 430 304 552 430 307 552 minecraft:black_concrete
setblock 444 304 510 minecraft:white_concrete
setblock 445 304 510 minecraft:light_blue_stained_glass
setblock 465 304 540 minecraft:light_blue_stained_glass
setblock 423 305 534 minecraft:sea_lantern
fill 423 305 542 423 307 542 minecraft:black_concrete
setblock 424 305 552 minecraft:white_concrete
fill 444 305 510 445 307 510 minecraft:black_concrete
setblock 465 305 512 minecraft:light_blue_stained_glass
setblock 465 305 523 minecraft:white_concrete
fill 465 305 540 465 307 540 minecraft:black_concrete
fill 423 306 515 423 307 515 minecraft:black_concrete
setblock 423 306 516 minecraft:white_concrete
fill 423 306 534 423 307 534 minecraft:black_concrete
fill 424 306 552 424 307 552 minecraft:black_concrete
setblock 460 306 510 minecraft:light_blue_stained_glass
setblock 463 306 510 minecraft:light_blue_stained_glass
fill 465 306 512 465 307 512 minecraft:black_concrete
setblock 465 306 520 minecraft:white_concrete
fill 465 306 523 465 307 523 minecraft:black_concrete
setblock 423 307 516 minecraft:black_concrete
setblock 460 307 510 minecraft:black_concrete
setblock 463 307 510 minecraft:black_concrete
setblock 465 307 520 minecraft:black_concrete
