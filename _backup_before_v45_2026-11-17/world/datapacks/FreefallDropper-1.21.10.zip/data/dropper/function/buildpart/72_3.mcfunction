setblock 2 97 357 minecraft:yellow_terracotta
fill 2 97 358 2 100 358 minecraft:honeycomb_block
fill 2 97 363 2 100 363 minecraft:honeycomb_block
setblock 3 97 331 minecraft:yellow_terracotta
fill 3 97 332 3 100 332 minecraft:honeycomb_block
setblock 3 97 335 minecraft:honeycomb_block
setblock 3 97 336 minecraft:yellow_terracotta
fill 3 97 337 3 100 337 minecraft:honeycomb_block
setblock 3 97 341 minecraft:yellow_terracotta
fill 3 97 342 3 100 342 minecraft:honeycomb_block
setblock 3 97 347 minecraft:honeycomb_block
setblock 3 97 351 minecraft:yellow_terracotta
fill 3 97 352 3 98 352 minecraft:honeycomb_block
setblock 3 97 356 minecraft:yellow_terracotta
fill 3 97 357 3 99 357 minecraft:honeycomb_block
setblock 4 97 335 minecraft:yellow_terracotta
fill 4 97 336 4 100 336 minecraft:honeycomb_block
setblock 4 97 340 minecraft:yellow_terracotta
setblock 4 97 355 minecraft:yellow_terracotta
setblock 6 97 323 minecraft:yellow_terracotta
setblock 6 97 363 minecraft:yellow_terracotta
setblock 7 97 323 minecraft:honeycomb_block
setblock 7 97 363 minecraft:honeycomb_block
fill 19 97 363 19 98 363 minecraft:honeycomb_block
setblock 20 97 324 minecraft:yellow_terracotta
setblock 21 97 323 minecraft:yellow_terracotta
fill 21 97 324 21 100 324 minecraft:honeycomb_block
setblock 21 97 362 minecraft:honeycomb_block
setblock 21 97 363 minecraft:yellow_terracotta
fill 22 97 323 22 100 323 minecraft:honeycomb_block
setblock 22 97 362 minecraft:yellow_terracotta
fill 22 97 363 22 100 363 minecraft:honeycomb_block
setblock 23 97 361 minecraft:yellow_terracotta
fill 23 97 362 23 100 362 minecraft:honeycomb_block
setblock 24 97 325 minecraft:yellow_terracotta
fill 24 97 361 24 100 361 minecraft:honeycomb_block
setblock 25 97 324 minecraft:yellow_terracotta
setblock 25 97 325 minecraft:honeycomb_block
setblock 26 97 323 minecraft:yellow_terracotta
fill 26 97 324 26 99 324 minecraft:honeycomb_block
setblock 26 97 363 minecraft:yellow_terracotta
setblock 27 97 322 minecraft:yellow_terracotta
fill 27 97 323 27 100 323 minecraft:honeycomb_block
setblock 27 97 361 minecraft:honeycomb_block
setblock 27 97 362 minecraft:yellow_terracotta
fill 27 97 363 27 100 363 minecraft:honeycomb_block
fill 28 97 322 28 132 322 minecraft:honeycomb_block
setblock 28 97 361 minecraft:yellow_terracotta
fill 28 97 362 28 100 362 minecraft:honeycomb_block
fill 29 97 361 29 98 361 minecraft:honeycomb_block
setblock 31 97 323 minecraft:yellow_terracotta
setblock 31 97 362 minecraft:honeycomb_block
setblock 31 97 363 minecraft:yellow_terracotta
setblock 32 97 362 minecraft:yellow_terracotta
fill 32 97 363 35 97 363 minecraft:honeycomb_block
setblock 36 97 363 minecraft:yellow_terracotta
setblock 37 97 323 minecraft:honey_block
fill 37 97 325 37 98 325 minecraft:yellow_terracotta
fill 37 97 363 37 100 363 minecraft:honeycomb_block
fill 38 97 362 38 100 362 minecraft:honeycomb_block
fill 39 97 323 39 98 323 minecraft:yellow_terracotta
fill 39 97 352 39 97 354 minecraft:honeycomb_block
setblock 39 97 355 minecraft:yellow_terracotta
fill 39 97 356 39 100 356 minecraft:honeycomb_block
setblock 39 97 360 minecraft:yellow_terracotta
setblock 40 97 334 minecraft:yellow_terracotta
fill 40 97 335 40 98 337 minecraft:honeycomb_block
setblock 40 97 349 minecraft:yellow_terracotta
fill 40 97 350 40 100 350 minecraft:honeycomb_block
setblock 40 97 354 minecraft:yellow_terracotta
fill 40 97 355 40 100 355 minecraft:honeycomb_block
setblock 40 97 359 minecraft:yellow_terracotta
fill 40 97 360 40 100 360 minecraft:honeycomb_block
fill 41 97 329 41 98 329 minecraft:honeycomb_block
setblock 41 97 333 minecraft:yellow_terracotta
fill 41 97 334 41 100 334 minecraft:honeycomb_block
setblock 41 97 337 minecraft:honeycomb_block
setblock 41 97 338 minecraft:yellow_terracotta
fill 41 97 339 41 97 342 minecraft:honeycomb_block
setblock 41 97 343 minecraft:yellow_terracotta
fill 41 97 344 41 100 344 minecraft:honeycomb_block
setblock 41 97 348 minecraft:yellow_terracotta
fill 41 97 349 41 100 349 minecraft:honeycomb_block
setblock 41 97 353 minecraft:yellow_terracotta
fill 41 97 354 41 100 354 minecraft:honeycomb_block
setblock 41 97 358 minecraft:yellow_terracotta
fill 41 97 359 41 100 359 minecraft:honeycomb_block
setblock 41 97 363 minecraft:yellow_terracotta
setblock 1 98 323 minecraft:honey_block
fill 1 98 328 1 98 331 minecraft:honeycomb_block
setblock 1 98 332 minecraft:yellow_terracotta
fill 1 98 333 1 98 336 minecraft:honeycomb_block
setblock 1 98 337 minecraft:yellow_terracotta
fill 1 98 338 1 101 338 minecraft:honeycomb_block
setblock 1 98 342 minecraft:yellow_terracotta
fill 1 98 343 1 101 343 minecraft:honeycomb_block
setblock 1 98 347 minecraft:yellow_terracotta
fill 1 98 348 1 101 348 minecraft:honeycomb_block
setblock 1 98 352 minecraft:yellow_terracotta
fill 1 98 353 1 101 353 minecraft:honeycomb_block
setblock 1 98 357 minecraft:yellow_terracotta
fill 1 98 358 1 101 358 minecraft:honeycomb_block
setblock 1 98 361 minecraft:honeycomb_block
setblock 1 98 362 minecraft:yellow_terracotta
fill 1 98 363 1 101 363 minecraft:honeycomb_block
setblock 2 98 331 minecraft:yellow_terracotta
fill 2 98 332 2 101 332 minecraft:honeycomb_block
setblock 2 98 336 minecraft:yellow_terracotta
fill 2 98 337 2 101 337 minecraft:honeycomb_block
setblock 2 98 340 minecraft:honeycomb_block
setblock 2 98 341 minecraft:yellow_terracotta
fill 2 98 342 2 101 342 minecraft:honeycomb_block
fill 2 98 344 2 99 344 minecraft:honeycomb_block
setblock 2 98 346 minecraft:yellow_terracotta
fill 2 98 347 2 101 347 minecraft:honeycomb_block
setblock 2 98 351 minecraft:yellow_terracotta
fill 2 98 352 2 101 352 minecraft:honeycomb_block
setblock 2 98 356 minecraft:yellow_terracotta
fill 2 98 357 2 101 357 minecraft:honeycomb_block
setblock 2 98 361 minecraft:yellow_terracotta
setblock 3 98 325 minecraft:light[level=12]
setblock 3 98 331 minecraft:honeycomb_block
setblock 3 98 335 minecraft:yellow_terracotta
fill 3 98 336 3 101 336 minecraft:honeycomb_block
setblock 3 98 340 minecraft:yellow_terracotta
fill 3 98 341 3 101 341 minecraft:honeycomb_block
setblock 3 98 346 minecraft:light[level=12]
setblock 3 98 350 minecraft:yellow_terracotta
setblock 3 98 351 minecraft:honeycomb_block
setblock 3 98 355 minecraft:yellow_terracotta
fill 3 98 356 3 99 356 minecraft:honeycomb_block
setblock 3 98 360 minecraft:light[level=12]
setblock 4 98 334 minecraft:yellow_terracotta
fill 4 98 335 4 100 335 minecraft:honeycomb_block
setblock 4 98 339 minecraft:yellow_terracotta
fill 4 98 340 4 99 340 minecraft:honeycomb_block
setblock 5 98 363 minecraft:yellow_terracotta
fill 6 98 363 6 99 363 minecraft:honeycomb_block
setblock 9 98 322 minecraft:orange_terracotta
setblock 10 98 325 minecraft:light[level=12]
setblock 10 98 332 minecraft:light[level=12]
setblock 10 98 339 minecraft:light[level=12]
setblock 10 98 346 minecraft:light[level=12]
setblock 10 98 353 minecraft:light[level=12]
setblock 10 98 360 minecraft:light[level=12]
setblock 11 98 363 minecraft:honey_block
setblock 12 98 323 minecraft:honey_block
setblock 17 98 325 minecraft:light[level=12]
setblock 17 98 332 minecraft:light[level=12]
setblock 17 98 339 minecraft:light[level=12]
setblock 17 98 346 minecraft:light[level=12]
setblock 17 98 353 minecraft:light[level=12]
setblock 17 98 360 minecraft:light[level=12]
setblock 20 98 323 minecraft:yellow_terracotta
fill 20 98 324 20 101 324 minecraft:honeycomb_block
setblock 20 98 362 minecraft:honeycomb_block
setblock 20 98 363 minecraft:yellow_terracotta
fill 21 98 323 21 101 323 minecraft:honeycomb_block
setblock 21 98 362 minecraft:yellow_terracotta
fill 21 98 363 21 101 363 minecraft:honeycomb_block
setblock 22 98 361 minecraft:yellow_terracotta
fill 22 98 362 22 101 362 minecraft:honeycomb_block
fill 23 98 361 23 101 361 minecraft:honeycomb_block
setblock 24 98 324 minecraft:yellow_terracotta
setblock 24 98 325 minecraft:light[level=12]
setblock 24 98 332 minecraft:light[level=12]
setblock 24 98 339 minecraft:light[level=12]
setblock 24 98 346 minecraft:light[level=12]
setblock 24 98 353 minecraft:light[level=12]
setblock 24 98 360 minecraft:light[level=12]
setblock 25 98 323 minecraft:yellow_terracotta
fill 25 98 324 25 100 324 minecraft:honeycomb_block
setblock 25 98 363 minecraft:yellow_terracotta
fill 26 98 323 26 101 323 minecraft:honeycomb_block
setblock 26 98 362 minecraft:yellow_terracotta
fill 26 98 363 26 101 363 minecraft:honeycomb_block
fill 27 98 322 27 124 322 minecraft:honeycomb_block
setblock 27 98 361 minecraft:yellow_terracotta
fill 27 98 362 27 101 362 minecraft:honeycomb_block
fill 28 98 361 28 100 361 minecraft:honeycomb_block
setblock 30 98 323 minecraft:yellow_terracotta
setblock 30 98 363 minecraft:yellow_terracotta
setblock 31 98 323 minecraft:honey_block
setblock 31 98 325 minecraft:light[level=12]
setblock 31 98 332 minecraft:light[level=12]
setblock 31 98 339 minecraft:light[level=12]
setblock 31 98 346 minecraft:light[level=12]
setblock 31 98 353 minecraft:light[level=12]
setblock 31 98 360 minecraft:light[level=12]
setblock 31 98 362 minecraft:yellow_terracotta
fill 31 98 363 34 98 363 minecraft:honeycomb_block
setblock 32 98 362 minecraft:honeycomb_block
setblock 35 98 363 minecraft:yellow_terracotta
fill 36 98 363 36 101 363 minecraft:honeycomb_block
setblock 37 98 323 minecraft:yellow_terracotta
setblock 38 98 332 minecraft:light[level=12]
setblock 38 98 339 minecraft:light[level=12]
setblock 38 98 346 minecraft:light[level=12]
fill 38 98 348 38 100 348 minecraft:brown_terracotta
setblock 38 98 353 minecraft:light[level=12]
setblock 38 98 360 minecraft:light[level=12]
fill 39 98 347 39 100 347 minecraft:brown_terracotta
fill 39 98 349 39 100 349 minecraft:brown_terracotta
setblock 39 98 353 minecraft:honeycomb_block
setblock 39 98 354 minecraft:yellow_terracotta
fill 39 98 355 39 101 355 minecraft:honeycomb_block
setblock 39 98 359 minecraft:yellow_terracotta
fill 39 98 360 39 101 360 minecraft:honeycomb_block
setblock 40 98 334 minecraft:honeycomb_block
setblock 40 98 338 minecraft:yellow_terracotta
fill 40 98 339 41 100 339 minecraft:honeycomb_block
fill 40 98 348 40 100 348 minecraft:brown_terracotta
fill 40 98 349 40 99 349 minecraft:honeycomb_block
setblock 40 98 353 minecraft:yellow_terracotta
fill 40 98 354 40 101 354 minecraft:honeycomb_block
setblock 40 98 358 minecraft:yellow_terracotta
fill 40 98 359 40 101 359 minecraft:honeycomb_block
setblock 40 98 363 minecraft:yellow_terracotta
setblock 41 98 332 minecraft:yellow_terracotta
fill 41 98 333 41 101 333 minecraft:honeycomb_block
setblock 41 98 337 minecraft:yellow_terracotta
fill 41 98 338 41 101 338 minecraft:honeycomb_block
fill 41 98 340 41 98 341 minecraft:honeycomb_block
setblock 41 98 342 minecraft:yellow_terracotta
fill 41 98 343 41 101 343 minecraft:honeycomb_block
setblock 41 98 347 minecraft:yellow_terracotta
fill 41 98 348 41 101 348 minecraft:honeycomb_block
setblock 41 98 352 minecraft:yellow_terracotta
fill 41 98 353 41 101 353 minecraft:honeycomb_block
setblock 41 98 357 minecraft:yellow_terracotta
fill 41 98 358 41 101 358 minecraft:honeycomb_block
setblock 41 98 362 minecraft:yellow_terracotta
fill 41 98 363 41 101 363 minecraft:honeycomb_block
fill 42 98 352 42 135 352 minecraft:honeycomb_block
setblock 42 98 363 minecraft:orange_terracotta
fill 1 99 328 1 99 330 minecraft:honeycomb_block
setblock 1 99 331 minecraft:yellow_terracotta
fill 1 99 332 1 99 335 minecraft:honeycomb_block
setblock 1 99 336 minecraft:yellow_terracotta
fill 1 99 337 1 102 337 minecraft:honeycomb_block
setblock 1 99 341 minecraft:yellow_terracotta
fill 1 99 342 1 102 342 minecraft:honeycomb_block
setblock 1 99 346 minecraft:yellow_terracotta
fill 1 99 347 1 102 347 minecraft:honeycomb_block
setblock 1 99 351 minecraft:yellow_terracotta
fill 1 99 352 1 102 352 minecraft:honeycomb_block
setblock 1 99 356 minecraft:yellow_terracotta
fill 1 99 357 1 102 357 minecraft:honeycomb_block
setblock 1 99 361 minecraft:yellow_terracotta
fill 1 99 362 1 102 362 minecraft:honeycomb_block
setblock 2 99 330 minecraft:yellow_terracotta
fill 2 99 331 2 101 331 minecraft:honeycomb_block
setblock 2 99 335 minecraft:yellow_terracotta
fill 2 99 336 2 102 336 minecraft:honeycomb_block
setblock 2 99 340 minecraft:yellow_terracotta
fill 2 99 341 2 102 341 minecraft:honeycomb_block
setblock 2 99 345 minecraft:yellow_terracotta
fill 2 99 346 2 102 346 minecraft:honeycomb_block
setblock 2 99 350 minecraft:yellow_terracotta
fill 2 99 351 2 100 351 minecraft:honeycomb_block
setblock 2 99 355 minecraft:yellow_terracotta
fill 2 99 356 2 102 356 minecraft:honeycomb_block
setblock 2 99 359 minecraft:honeycomb_block
setblock 2 99 360 minecraft:yellow_terracotta
fill 2 99 361 2 102 361 minecraft:honeycomb_block
setblock 3 99 334 minecraft:yellow_terracotta
fill 3 99 335 3 102 335 minecraft:honeycomb_block
setblock 3 99 339 minecraft:yellow_terracotta
fill 3 99 340 3 102 340 minecraft:honeycomb_block
setblock 3 99 354 minecraft:yellow_terracotta
setblock 3 99 355 minecraft:honeycomb_block
setblock 4 99 334 minecraft:honeycomb_block
setblock 4 99 338 minecraft:yellow_terracotta
fill 4 99 339 4 102 339 minecraft:honeycomb_block
setblock 4 99 363 minecraft:yellow_terracotta
fill 5 99 363 5 102 363 minecraft:honeycomb_block
setblock 6 99 323 minecraft:honey_block
fill 9 99 322 9 166 322 minecraft:honeycomb_block
setblock 11 99 322 minecraft:yellow_concrete
fill 11 99 364 11 308 364 minecraft:honeycomb_block
setblock 12 99 364 minecraft:yellow_concrete
fill 13 99 364 13 178 364 minecraft:honeycomb_block
setblock 17 99 363 minecraft:honey_block
setblock 18 99 363 minecraft:honeycomb_block
setblock 19 99 323 minecraft:yellow_terracotta
setblock 19 99 363 minecraft:yellow_terracotta
fill 20 99 323 20 102 323 minecraft:honeycomb_block
setblock 20 99 362 minecraft:yellow_terracotta
fill 20 99 363 20 102 363 minecraft:honeycomb_block
fill 21 99 362 21 102 362 minecraft:honeycomb_block
fill 22 99 361 22 102 361 minecraft:honeycomb_block
setblock 23 99 324 minecraft:yellow_terracotta
setblock 24 99 323 minecraft:yellow_terracotta
fill 24 99 324 24 102 324 minecraft:honeycomb_block
setblock 24 99 363 minecraft:yellow_terracotta
fill 25 99 323 25 102 323 minecraft:honeycomb_block
setblock 25 99 362 minecraft:yellow_terracotta
fill 25 99 363 25 102 363 minecraft:honeycomb_block
setblock 26 99 361 minecraft:yellow_terracotta
fill 26 99 362 26 102 362 minecraft:honeycomb_block
fill 27 99 361 27 102 361 minecraft:honeycomb_block
setblock 27 99 364 minecraft:yellow_concrete
setblock 29 99 323 minecraft:yellow_terracotta
setblock 29 99 363 minecraft:yellow_terracotta
setblock 30 99 362 minecraft:yellow_terracotta
fill 30 99 363 33 99 363 minecraft:honeycomb_block
fill 31 99 362 31 100 362 minecraft:honeycomb_block
setblock 34 99 363 minecraft:yellow_terracotta
fill 35 99 363 35 102 363 minecraft:honeycomb_block
fill 37 99 362 37 101 362 minecraft:honeycomb_block
fill 39 99 354 39 100 354 minecraft:honeycomb_block
setblock 39 99 358 minecraft:yellow_terracotta
fill 39 99 359 39 102 359 minecraft:honeycomb_block
setblock 39 99 363 minecraft:yellow_terracotta
fill 40 99 335 40 99 336 minecraft:honeycomb_block
setblock 40 99 337 minecraft:yellow_terracotta
fill 40 99 338 40 102 338 minecraft:honeycomb_block
fill 40 99 340 41 99 340 minecraft:honeycomb_block
setblock 40 99 352 minecraft:yellow_terracotta
fill 40 99 353 40 102 353 minecraft:honeycomb_block
setblock 40 99 357 minecraft:yellow_terracotta
fill 40 99 358 40 102 358 minecraft:honeycomb_block
setblock 40 99 362 minecraft:yellow_terracotta
fill 40 99 363 40 102 363 minecraft:honeycomb_block
setblock 41 99 331 minecraft:yellow_terracotta
fill 41 99 332 41 102 332 minecraft:honeycomb_block
setblock 41 99 336 minecraft:yellow_terracotta
fill 41 99 337 41 102 337 minecraft:honeycomb_block
setblock 41 99 341 minecraft:yellow_terracotta
fill 41 99 342 41 102 342 minecraft:honeycomb_block
setblock 41 99 346 minecraft:yellow_terracotta
fill 41 99 347 41 102 347 minecraft:honeycomb_block
setblock 41 99 351 minecraft:yellow_terracotta
fill 41 99 352 41 102 352 minecraft:honeycomb_block
setblock 41 99 356 minecraft:yellow_terracotta
fill 41 99 357 41 102 357 minecraft:honeycomb_block
setblock 41 99 361 minecraft:yellow_terracotta
fill 41 99 362 41 102 362 minecraft:honeycomb_block
fill 42 99 363 42 196 363 minecraft:honeycomb_block
setblock 1 100 329 minecraft:honeycomb_block
setblock 1 100 330 minecraft:yellow_terracotta
fill 1 100 331 1 100 334 minecraft:honeycomb_block
setblock 1 100 335 minecraft:yellow_terracotta
fill 1 100 336 1 103 336 minecraft:honeycomb_block
setblock 1 100 340 minecraft:yellow_terracotta
fill 1 100 341 1 103 341 minecraft:honeycomb_block
setblock 1 100 345 minecraft:yellow_terracotta
fill 1 100 346 1 103 346 minecraft:honeycomb_block
setblock 1 100 350 minecraft:yellow_terracotta
fill 1 100 351 1 103 351 minecraft:honeycomb_block
setblock 1 100 355 minecraft:yellow_terracotta
fill 1 100 356 1 103 356 minecraft:honeycomb_block
setblock 1 100 360 minecraft:yellow_terracotta
fill 1 100 361 1 103 361 minecraft:honeycomb_block
setblock 2 100 334 minecraft:yellow_terracotta
fill 2 100 335 2 103 335 minecraft:honeycomb_block
setblock 2 100 339 minecraft:yellow_terracotta
fill 2 100 340 2 103 340 minecraft:honeycomb_block
setblock 2 100 344 minecraft:yellow_terracotta
fill 2 100 345 2 103 345 minecraft:honeycomb_block
setblock 2 100 349 minecraft:yellow_terracotta
setblock 2 100 350 minecraft:honeycomb_block
setblock 2 100 354 minecraft:yellow_terracotta
fill 2 100 355 2 102 355 minecraft:honeycomb_block
setblock 2 100 359 minecraft:yellow_terracotta
fill 2 100 360 2 103 360 minecraft:honeycomb_block
setblock 3 100 333 minecraft:yellow_terracotta
fill 3 100 334 3 103 334 minecraft:honeycomb_block
setblock 3 100 338 minecraft:yellow_terracotta
fill 3 100 339 3 103 339 minecraft:honeycomb_block
setblock 3 100 343 minecraft:yellow_terracotta
setblock 3 100 363 minecraft:yellow_terracotta
setblock 4 100 337 minecraft:yellow_terracotta
fill 4 100 338 4 102 338 minecraft:honeycomb_block
fill 4 100 363 4 103 363 minecraft:honeycomb_block
fill 11 100 322 11 184 322 minecraft:honeycomb_block
fill 12 100 364 12 145 364 minecraft:honeycomb_block
setblock 17 100 323 minecraft:honeycomb_block
setblock 17 100 363 minecraft:honeycomb_block
setblock 18 100 323 minecraft:yellow_terracotta
setblock 18 100 363 minecraft:yellow_terracotta
fill 19 100 323 19 103 323 minecraft:honeycomb_block
setblock 19 100 362 minecraft:yellow_terracotta
fill 19 100 363 19 103 363 minecraft:honeycomb_block
fill 20 100 362 20 103 362 minecraft:honeycomb_block
fill 21 100 361 21 103 361 minecraft:honeycomb_block
setblock 22 100 324 minecraft:yellow_terracotta
setblock 23 100 323 minecraft:yellow_terracotta
fill 23 100 324 23 103 324 minecraft:honeycomb_block
setblock 23 100 363 minecraft:yellow_terracotta
fill 24 100 323 24 103 323 minecraft:honeycomb_block
setblock 24 100 362 minecraft:yellow_terracotta
fill 24 100 363 24 103 363 minecraft:honeycomb_block
setblock 25 100 361 minecraft:yellow_terracotta
fill 25 100 362 25 103 362 minecraft:honeycomb_block
fill 26 100 361 26 103 361 minecraft:honeycomb_block
fill 27 100 364 27 101 364 minecraft:honeycomb_block
setblock 28 100 323 minecraft:yellow_terracotta
setblock 28 100 363 minecraft:yellow_terracotta
setblock 29 100 362 minecraft:yellow_terracotta
fill 29 100 363 32 100 363 minecraft:honeycomb_block
fill 30 100 362 30 103 362 minecraft:honeycomb_block
setblock 33 100 363 minecraft:yellow_terracotta
fill 34 100 363 34 103 363 minecraft:honeycomb_block
setblock 38 100 347 minecraft:brown_terracotta
setblock 38 100 349 minecraft:brown_terracotta
setblock 38 100 363 minecraft:yellow_terracotta
setblock 39 100 357 minecraft:yellow_terracotta
fill 39 100 358 39 103 358 minecraft:honeycomb_block
setblock 39 100 362 minecraft:yellow_terracotta
fill 39 100 363 39 103 363 minecraft:honeycomb_block
setblock 40 100 335 minecraft:honeycomb_block
setblock 40 100 336 minecraft:yellow_terracotta
fill 40 100 337 40 103 337 minecraft:honeycomb_block
setblock 40 100 340 minecraft:honeycomb_block
setblock 40 100 341 minecraft:yellow_terracotta
fill 40 100 342 40 103 342 minecraft:honeycomb_block
setblock 40 100 347 minecraft:brown_terracotta
setblock 40 100 349 minecraft:brown_terracotta
setblock 40 100 351 minecraft:yellow_terracotta
fill 40 100 352 40 103 352 minecraft:honeycomb_block
setblock 40 100 356 minecraft:yellow_terracotta
fill 40 100 357 40 103 357 minecraft:honeycomb_block
setblock 40 100 361 minecraft:yellow_terracotta
fill 40 100 362 40 103 362 minecraft:honeycomb_block
setblock 41 100 326 minecraft:honey_block
setblock 41 100 331 minecraft:honeycomb_block
setblock 41 100 335 minecraft:yellow_terracotta
fill 41 100 336 41 103 336 minecraft:honeycomb_block
setblock 41 100 340 minecraft:yellow_terracotta
fill 41 100 341 41 103 341 minecraft:honeycomb_block
setblock 41 100 345 minecraft:yellow_terracotta
fill 41 100 346 41 103 346 minecraft:honeycomb_block
setblock 41 100 350 minecraft:yellow_terracotta
fill 41 100 351 41 103 351 minecraft:honeycomb_block
setblock 41 100 355 minecraft:yellow_terracotta
fill 41 100 356 41 103 356 minecraft:honeycomb_block
setblock 41 100 360 minecraft:yellow_terracotta
fill 41 100 361 41 103 361 minecraft:honeycomb_block
setblock 0 101 330 minecraft:yellow_terracotta
setblock 1 101 329 minecraft:yellow_terracotta
fill 1 101 330 1 101 333 minecraft:honeycomb_block
setblock 1 101 334 minecraft:yellow_terracotta
fill 1 101 335 1 104 335 minecraft:honeycomb_block
setblock 1 101 339 minecraft:yellow_terracotta
fill 1 101 340 1 104 340 minecraft:honeycomb_block
setblock 1 101 344 minecraft:yellow_terracotta
fill 1 101 345 1 104 345 minecraft:honeycomb_block
setblock 1 101 349 minecraft:yellow_terracotta
fill 1 101 350 1 104 350 minecraft:honeycomb_block
setblock 1 101 354 minecraft:yellow_terracotta
fill 1 101 355 1 104 355 minecraft:honeycomb_block
setblock 1 101 359 minecraft:yellow_terracotta
fill 1 101 360 1 104 360 minecraft:honeycomb_block
setblock 2 101 333 minecraft:yellow_terracotta
fill 2 101 334 2 104 334 minecraft:honeycomb_block
setblock 2 101 338 minecraft:yellow_terracotta
fill 2 101 339 2 104 339 minecraft:honeycomb_block
setblock 2 101 343 minecraft:yellow_terracotta
fill 2 101 344 2 104 344 minecraft:honeycomb_block
setblock 2 101 353 minecraft:yellow_terracotta
setblock 2 101 354 minecraft:honeycomb_block
setblock 2 101 358 minecraft:yellow_terracotta
fill 2 101 359 2 104 359 minecraft:honeycomb_block
setblock 2 101 363 minecraft:yellow_terracotta
setblock 3 101 333 minecraft:honeycomb_block
setblock 3 101 337 minecraft:yellow_terracotta
fill 3 101 338 3 104 338 minecraft:honeycomb_block
setblock 3 101 342 minecraft:yellow_terracotta
fill 3 101 343 3 104 343 minecraft:honeycomb_block
fill 3 101 363 3 104 363 minecraft:honeycomb_block
setblock 4 101 336 minecraft:yellow_terracotta
setblock 4 101 337 minecraft:honeycomb_block
setblock 13 101 323 minecraft:honey_block
setblock 17 101 323 minecraft:yellow_terracotta
setblock 17 101 363 minecraft:yellow_terracotta
fill 18 101 323 18 104 323 minecraft:honeycomb_block
setblock 18 101 362 minecraft:yellow_terracotta
fill 18 101 363 18 104 363 minecraft:honeycomb_block
fill 19 101 362 19 104 362 minecraft:honeycomb_block
setblock 21 101 324 minecraft:yellow_terracotta
setblock 22 101 323 minecraft:yellow_terracotta
fill 22 101 324 22 104 324 minecraft:honeycomb_block
setblock 22 101 363 minecraft:yellow_terracotta
fill 23 101 323 23 104 323 minecraft:honeycomb_block
fill 23 101 327 23 104 327 minecraft:brown_terracotta
setblock 23 101 362 minecraft:yellow_terracotta
fill 23 101 363 23 104 363 minecraft:honeycomb_block
fill 24 101 326 24 104 326 minecraft:brown_terracotta
fill 24 101 328 24 104 328 minecraft:brown_terracotta
setblock 24 101 361 minecraft:yellow_terracotta
fill 24 101 362 24 104 362 minecraft:honeycomb_block
fill 25 101 327 25 104 327 minecraft:brown_terracotta
fill 25 101 361 25 104 361 minecraft:honeycomb_block
setblock 27 101 323 minecraft:yellow_terracotta
setblock 27 101 363 minecraft:yellow_terracotta
setblock 28 101 362 minecraft:yellow_terracotta
fill 28 101 363 31 101 363 minecraft:honeycomb_block
fill 29 101 362 29 104 362 minecraft:honeycomb_block
setblock 30 101 364 minecraft:yellow_concrete
setblock 32 101 363 minecraft:yellow_terracotta
fill 33 101 363 33 104 363 minecraft:honeycomb_block
fill 36 101 341 36 102 341 minecraft:ochre_froglight
fill 36 101 362 36 102 362 minecraft:honeycomb_block
setblock 37 101 363 minecraft:yellow_terracotta
setblock 38 101 323 minecraft:honey_block
setblock 38 101 362 minecraft:yellow_terracotta
fill 38 101 363 38 104 363 minecraft:honeycomb_block
setblock 39 101 356 minecraft:yellow_terracotta
fill 39 101 357 39 104 357 minecraft:honeycomb_block
setblock 39 101 361 minecraft:yellow_terracotta
fill 39 101 362 39 104 362 minecraft:honeycomb_block
setblock 40 101 335 minecraft:yellow_terracotta
fill 40 101 336 40 104 336 minecraft:honeycomb_block
setblock 40 101 339 minecraft:honeycomb_block
setblock 40 101 340 minecraft:yellow_terracotta
fill 40 101 341 40 104 341 minecraft:honeycomb_block
fill 40 101 343 40 102 343 minecraft:honeycomb_block
setblock 40 101 350 minecraft:yellow_terracotta
fill 40 101 351 40 104 351 minecraft:honeycomb_block
setblock 40 101 355 minecraft:yellow_terracotta
fill 40 101 356 40 104 356 minecraft:honeycomb_block
setblock 40 101 360 minecraft:yellow_terracotta
fill 40 101 361 40 104 361 minecraft:honeycomb_block
setblock 41 101 334 minecraft:yellow_terracotta
fill 41 101 335 41 104 335 minecraft:honeycomb_block
setblock 41 101 339 minecraft:yellow_terracotta
fill 41 101 340 41 104 340 minecraft:honeycomb_block
setblock 41 101 344 minecraft:yellow_terracotta
fill 41 101 345 41 104 345 minecraft:honeycomb_block
setblock 41 101 349 minecraft:yellow_terracotta
fill 41 101 350 41 104 350 minecraft:honeycomb_block
setblock 41 101 354 minecraft:yellow_terracotta
fill 41 101 355 41 104 355 minecraft:honeycomb_block
setblock 41 101 359 minecraft:yellow_terracotta
fill 41 101 360 41 104 360 minecraft:honeycomb_block
setblock 42 101 330 minecraft:yellow_concrete
fill 0 102 330 1 104 330 minecraft:honeycomb_block
setblock 1 102 328 minecraft:honey_block
fill 1 102 329 1 105 329 minecraft:honeycomb_block
fill 1 102 331 1 102 332 minecraft:honeycomb_block
setblock 1 102 333 minecraft:yellow_terracotta
fill 1 102 334 1 105 334 minecraft:honeycomb_block
setblock 1 102 338 minecraft:yellow_terracotta
fill 1 102 339 1 105 339 minecraft:honeycomb_block
setblock 1 102 343 minecraft:yellow_terracotta
fill 1 102 344 1 105 344 minecraft:honeycomb_block
setblock 1 102 348 minecraft:yellow_terracotta
fill 1 102 349 1 105 349 minecraft:honeycomb_block
setblock 1 102 353 minecraft:yellow_terracotta
fill 1 102 354 1 105 354 minecraft:honeycomb_block
setblock 1 102 358 minecraft:yellow_terracotta
fill 1 102 359 1 105 359 minecraft:honeycomb_block
setblock 1 102 363 minecraft:yellow_terracotta
setblock 2 102 332 minecraft:yellow_terracotta
fill 2 102 333 2 105 333 minecraft:honeycomb_block
setblock 2 102 337 minecraft:yellow_terracotta
fill 2 102 338 2 105 338 minecraft:honeycomb_block
setblock 2 102 342 minecraft:yellow_terracotta
fill 2 102 343 2 105 343 minecraft:honeycomb_block
setblock 2 102 357 minecraft:yellow_terracotta
fill 2 102 358 2 104 358 minecraft:honeycomb_block
fill 2 102 363 2 105 363 minecraft:honeycomb_block
setblock 3 102 336 minecraft:yellow_terracotta
fill 3 102 337 3 105 337 minecraft:honeycomb_block
setblock 3 102 341 minecraft:yellow_terracotta
fill 3 102 342 3 105 342 minecraft:honeycomb_block
setblock 7 102 323 minecraft:honey_block
setblock 10 102 363 minecraft:honey_block
setblock 16 102 323 minecraft:yellow_terracotta
setblock 16 102 363 minecraft:yellow_terracotta
fill 17 102 323 17 105 323 minecraft:honeycomb_block
fill 17 102 363 17 105 363 minecraft:honeycomb_block
fill 18 102 362 18 105 362 minecraft:honeycomb_block
setblock 19 102 324 minecraft:honeycomb_block
setblock 20 102 324 minecraft:yellow_terracotta
fill 20 102 361 20 104 361 minecraft:honeycomb_block
setblock 21 102 323 minecraft:yellow_terracotta
fill 21 102 324 21 105 324 minecraft:honeycomb_block
setblock 21 102 363 minecraft:yellow_terracotta
fill 22 102 323 22 105 323 minecraft:honeycomb_block
setblock 22 102 362 minecraft:yellow_terracotta
fill 22 102 363 22 105 363 minecraft:honeycomb_block
setblock 23 102 361 minecraft:yellow_terracotta
fill 23 102 362 23 105 362 minecraft:honeycomb_block
fill 24 102 361 24 105 361 minecraft:honeycomb_block
setblock 26 102 323 minecraft:yellow_terracotta
setblock 26 102 363 minecraft:yellow_terracotta
fill 27 102 323 27 105 323 minecraft:honeycomb_block
setblock 27 102 362 minecraft:yellow_terracotta
fill 27 102 363 30 102 363 minecraft:honeycomb_block
setblock 27 102 364 minecraft:orange_terracotta
fill 28 102 362 28 105 362 minecraft:honeycomb_block
fill 30 102 364 30 140 364 minecraft:honeycomb_block
setblock 31 102 363 minecraft:yellow_terracotta
setblock 32 102 323 minecraft:honey_block
fill 32 102 363 32 105 363 minecraft:honeycomb_block
setblock 34 102 364 minecraft:yellow_concrete
fill 35 102 362 35 103 362 minecraft:honeycomb_block
setblock 36 102 363 minecraft:yellow_terracotta
setblock 37 102 362 minecraft:yellow_terracotta
fill 37 102 363 37 105 363 minecraft:honeycomb_block
fill 38 102 362 38 105 362 minecraft:honeycomb_block
fill 39 102 356 39 105 356 minecraft:honeycomb_block
setblock 39 102 360 minecraft:yellow_terracotta
fill 39 102 361 39 105 361 minecraft:honeycomb_block
fill 40 102 335 40 105 335 minecraft:honeycomb_block
setblock 40 102 339 minecraft:yellow_terracotta
fill 40 102 340 40 105 340 minecraft:honeycomb_block
setblock 40 102 344 minecraft:yellow_terracotta
fill 40 102 345 40 105 345 minecraft:honeycomb_block
setblock 40 102 354 minecraft:yellow_terracotta
fill 40 102 355 40 105 355 minecraft:honeycomb_block
setblock 40 102 359 minecraft:yellow_terracotta
fill 40 102 360 40 105 360 minecraft:honeycomb_block
setblock 41 102 333 minecraft:yellow_terracotta
fill 41 102 334 41 105 334 minecraft:honeycomb_block
setblock 41 102 338 minecraft:yellow_terracotta
fill 41 102 339 41 105 339 minecraft:honeycomb_block
setblock 41 102 343 minecraft:yellow_terracotta
fill 41 102 344 41 105 344 minecraft:honeycomb_block
setblock 41 102 348 minecraft:yellow_terracotta
fill 41 102 349 41 105 349 minecraft:honeycomb_block
setblock 41 102 353 minecraft:yellow_terracotta
fill 41 102 354 41 105 354 minecraft:honeycomb_block
setblock 41 102 358 minecraft:yellow_terracotta
fill 41 102 359 41 105 359 minecraft:honeycomb_block
setblock 41 102 363 minecraft:yellow_terracotta
fill 42 102 330 42 155 330 minecraft:honeycomb_block
setblock 42 102 337 minecraft:yellow_concrete
setblock 0 103 339 minecraft:yellow_terracotta
fill 1 103 323 4 103 323 minecraft:honeycomb_block
setblock 1 103 331 minecraft:honeycomb_block
setblock 1 103 332 minecraft:yellow_terracotta
fill 1 103 333 1 106 333 minecraft:honeycomb_block
setblock 1 103 337 minecraft:yellow_terracotta
fill 1 103 338 1 106 338 minecraft:honeycomb_block
setblock 1 103 342 minecraft:yellow_terracotta
fill 1 103 343 1 106 343 minecraft:honeycomb_block
setblock 1 103 347 minecraft:yellow_terracotta
fill 1 103 348 1 106 348 minecraft:honeycomb_block
setblock 1 103 352 minecraft:yellow_terracotta
fill 1 103 353 1 106 353 minecraft:honeycomb_block
setblock 1 103 357 minecraft:yellow_terracotta
fill 1 103 358 1 106 358 minecraft:honeycomb_block
setblock 1 103 362 minecraft:yellow_terracotta
fill 1 103 363 1 106 363 minecraft:honeycomb_block
fill 2 103 332 2 106 332 minecraft:honeycomb_block
setblock 2 103 336 minecraft:yellow_terracotta
fill 2 103 337 2 106 337 minecraft:honeycomb_block
setblock 2 103 341 minecraft:yellow_terracotta
fill 2 103 342 2 106 342 minecraft:honeycomb_block
setblock 2 103 346 minecraft:yellow_terracotta
fill 2 103 347 2 106 347 minecraft:honeycomb_block
setblock 2 103 357 minecraft:honeycomb_block
setblock 2 103 361 minecraft:yellow_terracotta
fill 2 103 362 2 106 362 minecraft:honeycomb_block
setblock 3 103 335 minecraft:yellow_terracotta
fill 3 103 336 3 106 336 minecraft:honeycomb_block
setblock 3 103 340 minecraft:yellow_terracotta
fill 3 103 341 3 106 341 minecraft:honeycomb_block
setblock 5 103 363 minecraft:yellow_terracotta
setblock 14 103 323 minecraft:honeycomb_block
setblock 15 103 323 minecraft:yellow_terracotta
setblock 15 103 363 minecraft:yellow_terracotta
fill 16 103 323 16 106 323 minecraft:honeycomb_block
fill 16 103 363 16 106 363 minecraft:honeycomb_block
fill 17 103 362 17 106 362 minecraft:honeycomb_block
setblock 18 103 324 minecraft:honeycomb_block
setblock 19 103 324 minecraft:yellow_terracotta
fill 19 103 361 19 105 361 minecraft:honeycomb_block
setblock 20 103 323 minecraft:yellow_terracotta
fill 20 103 324 20 106 324 minecraft:honeycomb_block
setblock 20 103 363 minecraft:yellow_terracotta
fill 21 103 323 21 106 323 minecraft:honeycomb_block
setblock 21 103 362 minecraft:yellow_terracotta
fill 21 103 363 21 106 363 minecraft:honeycomb_block
setblock 22 103 361 minecraft:yellow_terracotta
fill 22 103 362 22 106 362 minecraft:honeycomb_block
fill 23 103 361 23 106 361 minecraft:honeycomb_block
setblock 24 103 324 minecraft:yellow_terracotta
setblock 25 103 323 minecraft:yellow_terracotta
setblock 25 103 363 minecraft:yellow_terracotta
fill 26 103 323 26 106 323 minecraft:honeycomb_block
setblock 26 103 362 minecraft:yellow_terracotta
fill 26 103 363 29 103 363 minecraft:honeycomb_block
fill 27 103 362 27 106 362 minecraft:honeycomb_block
fill 27 103 364 27 123 364 minecraft:honeycomb_block
setblock 30 103 363 minecraft:yellow_terracotta
setblock 31 103 362 minecraft:yellow_terracotta
fill 31 103 363 31 106 363 minecraft:honeycomb_block
fill 34 103 362 34 104 362 minecraft:honeycomb_block
setblock 34 103 364 minecraft:honeycomb_block
setblock 35 103 363 minecraft:yellow_terracotta
fill 36 103 341 36 112 341 minecraft:brown_terracotta
setblock 36 103 362 minecraft:yellow_terracotta
fill 36 103 363 36 106 363 minecraft:honeycomb_block
fill 37 103 362 37 106 362 minecraft:honeycomb_block
fill 38 103 361 38 106 361 minecraft:honeycomb_block
setblock 39 103 359 minecraft:yellow_terracotta
fill 39 103 360 39 106 360 minecraft:honeycomb_block
setblock 40 103 338 minecraft:yellow_terracotta
fill 40 103 339 40 106 339 minecraft:honeycomb_block
setblock 40 103 343 minecraft:yellow_terracotta
fill 40 103 344 40 106 344 minecraft:honeycomb_block
fill 40 103 346 40 103 347 minecraft:honeycomb_block
setblock 40 103 348 minecraft:yellow_terracotta
fill 40 103 349 40 105 350 minecraft:honeycomb_block
setblock 40 103 353 minecraft:yellow_terracotta
fill 40 103 354 40 106 354 minecraft:honeycomb_block
setblock 40 103 358 minecraft:yellow_terracotta
fill 40 103 359 40 106 359 minecraft:honeycomb_block
setblock 40 103 363 minecraft:yellow_terracotta
setblock 41 103 327 minecraft:honey_block
setblock 41 103 332 minecraft:yellow_terracotta
fill 41 103 333 41 106 333 minecraft:honeycomb_block
setblock 41 103 337 minecraft:yellow_terracotta
fill 41 103 338 41 106 338 minecraft:honeycomb_block
setblock 41 103 342 minecraft:yellow_terracotta
fill 41 103 343 41 106 343 minecraft:honeycomb_block
setblock 41 103 347 minecraft:yellow_terracotta
fill 41 103 348 41 106 348 minecraft:honeycomb_block
setblock 41 103 352 minecraft:yellow_terracotta
fill 41 103 353 41 106 353 minecraft:honeycomb_block
setblock 41 103 357 minecraft:yellow_terracotta
fill 41 103 358 41 106 358 minecraft:honeycomb_block
setblock 41 103 362 minecraft:yellow_terracotta
fill 41 103 363 41 106 363 minecraft:honeycomb_block
fill 42 103 337 42 175 337 minecraft:honeycomb_block
fill 0 104 339 0 113 339 minecraft:honeycomb_block
fill 1 104 323 1 104 325 minecraft:honeycomb_block
setblock 1 104 326 minecraft:yellow_terracotta
fill 1 104 327 1 106 328 minecraft:honeycomb_block
setblock 1 104 331 minecraft:yellow_terracotta
fill 1 104 332 1 107 332 minecraft:honeycomb_block
setblock 1 104 336 minecraft:yellow_terracotta
fill 1 104 337 1 107 337 minecraft:honeycomb_block
setblock 1 104 341 minecraft:yellow_terracotta
fill 1 104 342 1 107 342 minecraft:honeycomb_block
setblock 1 104 346 minecraft:yellow_terracotta
fill 1 104 347 1 107 347 minecraft:honeycomb_block
setblock 1 104 351 minecraft:yellow_terracotta
fill 1 104 352 1 107 352 minecraft:honeycomb_block
setblock 1 104 356 minecraft:yellow_terracotta
fill 1 104 357 1 107 357 minecraft:honeycomb_block
setblock 1 104 361 minecraft:yellow_terracotta
fill 1 104 362 1 107 362 minecraft:honeycomb_block
fill 2 104 323 3 104 323 minecraft:honeycomb_block
setblock 2 104 335 minecraft:yellow_terracotta
fill 2 104 336 2 107 336 minecraft:honeycomb_block
setblock 2 104 340 minecraft:yellow_terracotta
fill 2 104 341 2 107 341 minecraft:honeycomb_block
setblock 2 104 345 minecraft:yellow_terracotta
fill 2 104 346 2 107 346 minecraft:honeycomb_block
setblock 2 104 360 minecraft:yellow_terracotta
fill 2 104 361 2 107 361 minecraft:honeycomb_block
setblock 3 104 325 minecraft:light[level=15]
setblock 3 104 332 minecraft:light[level=12]
setblock 3 104 333 minecraft:light[level=15]
fill 3 104 335 3 106 335 minecraft:honeycomb_block
setblock 3 104 339 minecraft:yellow_terracotta
fill 3 104 340 3 107 340 minecraft:honeycomb_block
setblock 3 104 344 minecraft:yellow_terracotta
setblock 3 104 346 minecraft:light[level=12]
setblock 3 104 349 minecraft:light[level=15]
setblock 3 104 353 minecraft:light[level=12]
setblock 3 104 357 minecraft:light[level=15]
setblock 3 104 360 minecraft:light[level=12]
setblock 4 104 323 minecraft:yellow_terracotta
setblock 4 104 363 minecraft:yellow_terracotta
fill 5 104 323 6 106 323 minecraft:honeycomb_block
fill 5 104 363 5 107 363 minecraft:honeycomb_block
setblock 10 104 325 minecraft:light[level=12]
setblock 10 104 332 minecraft:light[level=12]
setblock 10 104 339 minecraft:light[level=12]
setblock 10 104 346 minecraft:light[level=12]
setblock 10 104 353 minecraft:light[level=12]
setblock 10 104 360 minecraft:light[level=12]
setblock 11 104 325 minecraft:light[level=15]
setblock 11 104 333 minecraft:light[level=15]
setblock 11 104 341 minecraft:light[level=15]
setblock 11 104 349 minecraft:light[level=15]
setblock 11 104 357 minecraft:light[level=15]
setblock 13 104 323 minecraft:honeycomb_block
setblock 13 104 363 minecraft:honeycomb_block
setblock 14 104 323 minecraft:yellow_terracotta
setblock 14 104 363 minecraft:yellow_terracotta
fill 15 104 323 15 107 323 minecraft:honeycomb_block
fill 15 104 363 15 107 363 minecraft:honeycomb_block
fill 16 104 324 17 104 324 minecraft:honeycomb_block
fill 16 104 362 16 107 362 minecraft:honeycomb_block
setblock 17 104 325 minecraft:light[level=12]
setblock 17 104 332 minecraft:light[level=12]
setblock 17 104 339 minecraft:light[level=12]
setblock 17 104 346 minecraft:light[level=12]
setblock 17 104 353 minecraft:light[level=12]
setblock 17 104 360 minecraft:light[level=12]
setblock 18 104 324 minecraft:yellow_terracotta
fill 18 104 361 18 106 361 minecraft:honeycomb_block
setblock 19 104 323 minecraft:yellow_terracotta
fill 19 104 324 19 107 324 minecraft:honeycomb_block
setblock 19 104 325 minecraft:light[level=15]
setblock 19 104 333 minecraft:light[level=15]
setblock 19 104 341 minecraft:light[level=15]
setblock 19 104 349 minecraft:light[level=15]
setblock 19 104 357 minecraft:light[level=15]
setblock 19 104 363 minecraft:yellow_terracotta
fill 20 104 323 20 107 323 minecraft:honeycomb_block
setblock 20 104 362 minecraft:yellow_terracotta
fill 20 104 363 20 107 363 minecraft:honeycomb_block
setblock 21 104 361 minecraft:yellow_terracotta
fill 21 104 362 21 107 362 minecraft:honeycomb_block
fill 22 104 361 22 107 361 minecraft:honeycomb_block
setblock 23 104 324 minecraft:yellow_terracotta
setblock 23 104 326 minecraft:brown_terracotta
setblock 23 104 328 minecraft:brown_terracotta
setblock 24 104 323 minecraft:yellow_terracotta
fill 24 104 324 24 107 324 minecraft:honeycomb_block
setblock 24 104 325 minecraft:light[level=12]
setblock 24 104 332 minecraft:light[level=12]
setblock 24 104 339 minecraft:light[level=12]
setblock 24 104 346 minecraft:light[level=12]
setblock 24 104 353 minecraft:light[level=12]
setblock 24 104 360 minecraft:light[level=12]
setblock 24 104 363 minecraft:yellow_terracotta
fill 25 104 323 25 107 323 minecraft:honeycomb_block
setblock 25 104 326 minecraft:brown_terracotta
setblock 25 104 328 minecraft:brown_terracotta
setblock 25 104 362 minecraft:yellow_terracotta
fill 25 104 363 28 104 363 minecraft:honeycomb_block
setblock 26 104 361 minecraft:yellow_terracotta
fill 26 104 362 26 107 362 minecraft:honeycomb_block
setblock 27 104 325 minecraft:light[level=15]
setblock 27 104 333 minecraft:light[level=15]
setblock 27 104 341 minecraft:light[level=15]
setblock 27 104 349 minecraft:light[level=15]
setblock 27 104 357 minecraft:light[level=15]
setblock 29 104 363 minecraft:yellow_terracotta
setblock 30 104 362 minecraft:yellow_terracotta
fill 30 104 363 30 107 363 minecraft:honeycomb_block
setblock 31 104 325 minecraft:light[level=12]
setblock 31 104 332 minecraft:light[level=12]
setblock 31 104 339 minecraft:light[level=12]
setblock 31 104 346 minecraft:light[level=12]
setblock 31 104 353 minecraft:light[level=12]
setblock 31 104 360 minecraft:light[level=12]
fill 31 104 362 33 105 362 minecraft:honeycomb_block
setblock 34 104 363 minecraft:yellow_terracotta
setblock 34 104 364 minecraft:yellow_concrete
setblock 35 104 325 minecraft:light[level=15]
setblock 35 104 333 minecraft:light[level=15]
fill 35 104 341 35 112 341 minecraft:brown_terracotta
setblock 35 104 349 minecraft:light[level=15]
setblock 35 104 357 minecraft:light[level=15]
setblock 35 104 362 minecraft:yellow_terracotta
fill 35 104 363 35 107 363 minecraft:honeycomb_block
fill 36 104 340 36 112 340 minecraft:brown_terracotta
fill 36 104 362 36 107 362 minecraft:honeycomb_block
fill 37 104 361 37 107 361 minecraft:honeycomb_block
setblock 38 104 325 minecraft:light[level=12]
setblock 38 104 332 minecraft:light[level=12]
setblock 38 104 339 minecraft:light[level=12]
setblock 38 104 346 minecraft:light[level=12]
setblock 38 104 353 minecraft:light[level=12]
setblock 38 104 360 minecraft:light[level=12]
setblock 39 104 323 minecraft:yellow_terracotta
fill 39 104 339 39 104 342 minecraft:honeycomb_block
setblock 39 104 343 minecraft:yellow_terracotta
fill 39 104 344 39 107 344 minecraft:honeycomb_block
setblock 39 104 358 minecraft:yellow_terracotta
fill 39 104 359 39 107 359 minecraft:honeycomb_block
setblock 39 104 363 minecraft:yellow_terracotta
fill 40 104 323 41 106 323 minecraft:honeycomb_block
setblock 40 104 337 minecraft:yellow_terracotta
fill 40 104 338 40 107 338 minecraft:honeycomb_block
setblock 40 104 342 minecraft:yellow_terracotta
fill 40 104 343 40 107 343 minecraft:honeycomb_block
setblock 40 104 346 minecraft:honeycomb_block
setblock 40 104 347 minecraft:yellow_terracotta
fill 40 104 348 40 107 348 minecraft:honeycomb_block
setblock 40 104 352 minecraft:yellow_terracotta
fill 40 104 353 40 107 353 minecraft:honeycomb_block
setblock 40 104 357 minecraft:yellow_terracotta
fill 40 104 358 40 107 358 minecraft:honeycomb_block
setblock 40 104 362 minecraft:yellow_terracotta
fill 40 104 363 40 107 363 minecraft:honeycomb_block
fill 41 104 332 41 107 332 minecraft:honeycomb_block
setblock 41 104 336 minecraft:yellow_terracotta
fill 41 104 337 41 107 337 minecraft:honeycomb_block
setblock 41 104 341 minecraft:yellow_terracotta
fill 41 104 342 41 107 342 minecraft:honeycomb_block
setblock 41 104 346 minecraft:yellow_terracotta
fill 41 104 347 41 107 347 minecraft:honeycomb_block
setblock 41 104 351 minecraft:yellow_terracotta
fill 41 104 352 41 107 352 minecraft:honeycomb_block
setblock 41 104 356 minecraft:yellow_terracotta
fill 41 104 357 41 107 357 minecraft:honeycomb_block
setblock 41 104 361 minecraft:yellow_terracotta
fill 41 104 362 41 107 362 minecraft:honeycomb_block
setblock 0 105 328 minecraft:orange_terracotta
fill 0 105 330 0 136 330 minecraft:honeycomb_block
fill 1 105 323 1 105 324 minecraft:honeycomb_block
setblock 1 105 325 minecraft:yellow_terracotta
fill 1 105 326 1 108 326 minecraft:honeycomb_block
setblock 1 105 330 minecraft:yellow_terracotta
fill 1 105 331 1 108 331 minecraft:honeycomb_block
setblock 1 105 335 minecraft:yellow_terracotta
fill 1 105 336 1 108 336 minecraft:honeycomb_block
setblock 1 105 340 minecraft:yellow_terracotta
fill 1 105 341 1 108 341 minecraft:honeycomb_block
setblock 1 105 345 minecraft:yellow_terracotta
fill 1 105 346 1 108 346 minecraft:honeycomb_block
setblock 1 105 350 minecraft:yellow_terracotta
fill 1 105 351 1 108 351 minecraft:honeycomb_block
setblock 1 105 355 minecraft:yellow_terracotta
fill 1 105 356 1 108 356 minecraft:honeycomb_block
setblock 1 105 360 minecraft:yellow_terracotta
fill 1 105 361 1 108 361 minecraft:honeycomb_block
fill 2 105 322 2 105 323 minecraft:honeycomb_block
setblock 2 105 334 minecraft:yellow_terracotta
fill 2 105 335 2 108 335 minecraft:honeycomb_block
setblock 2 105 339 minecraft:yellow_terracotta
fill 2 105 340 2 108 340 minecraft:honeycomb_block
setblock 2 105 344 minecraft:yellow_terracotta
fill 2 105 345 2 108 345 minecraft:honeycomb_block
setblock 2 105 359 minecraft:yellow_terracotta
fill 2 105 360 2 107 360 minecraft:honeycomb_block
fill 3 105 322 3 144 322 minecraft:honeycomb_block
setblock 3 105 323 minecraft:yellow_terracotta
setblock 3 105 338 minecraft:yellow_terracotta
fill 3 105 339 3 108 339 minecraft:honeycomb_block
setblock 3 105 343 minecraft:yellow_terracotta
fill 3 105 344 3 108 344 minecraft:honeycomb_block
setblock 3 105 362 minecraft:honeycomb_block
setblock 3 105 363 minecraft:yellow_terracotta
setblock 4 105 322 minecraft:yellow_concrete
fill 4 105 323 4 108 323 minecraft:honeycomb_block
fill 4 105 363 4 108 363 minecraft:honeycomb_block
fill 6 105 363 6 106 363 minecraft:honeycomb_block
setblock 7 105 323 minecraft:honeycomb_block
setblock 8 105 323 minecraft:yellow_terracotta
fill 9 105 323 12 105 323 minecraft:honeycomb_block
setblock 9 105 363 minecraft:honey_block
setblock 12 105 363 minecraft:honeycomb_block
setblock 13 105 323 minecraft:yellow_terracotta
setblock 13 105 363 minecraft:yellow_terracotta
fill 14 105 323 14 108 323 minecraft:honeycomb_block
fill 14 105 363 14 108 363 minecraft:honeycomb_block
fill 15 105 324 16 105 324 minecraft:honeycomb_block
fill 15 105 362 15 108 362 minecraft:honeycomb_block
setblock 17 105 324 minecraft:yellow_terracotta
fill 17 105 361 17 107 361 minecraft:honeycomb_block
setblock 18 105 323 minecraft:yellow_terracotta
fill 18 105 324 18 108 324 minecraft:honeycomb_block
setblock 18 105 363 minecraft:yellow_terracotta
fill 19 105 323 19 108 323 minecraft:honeycomb_block
fill 19 105 325 20 105 325 minecraft:honeycomb_block
setblock 19 105 362 minecraft:yellow_terracotta
fill 19 105 363 19 108 363 minecraft:honeycomb_block
setblock 20 105 361 minecraft:yellow_terracotta
fill 20 105 362 20 108 362 minecraft:honeycomb_block
fill 21 105 361 21 108 361 minecraft:honeycomb_block
setblock 22 105 324 minecraft:yellow_terracotta
setblock 23 105 323 minecraft:yellow_terracotta
fill 23 105 324 23 108 324 minecraft:honeycomb_block
setblock 23 105 363 minecraft:yellow_terracotta
fill 24 105 323 24 108 323 minecraft:honeycomb_block
setblock 24 105 362 minecraft:yellow_terracotta
fill 24 105 363 27 105 363 minecraft:honeycomb_block
setblock 25 105 361 minecraft:yellow_terracotta
fill 25 105 362 25 108 362 minecraft:honeycomb_block
fill 26 105 361 26 108 361 minecraft:honeycomb_block
setblock 28 105 323 minecraft:yellow_terracotta
setblock 28 105 363 minecraft:yellow_terracotta
setblock 29 105 362 minecraft:yellow_terracotta
fill 29 105 363 29 108 363 minecraft:honeycomb_block
fill 30 105 362 30 108 362 minecraft:honeycomb_block
setblock 33 105 323 minecraft:honey_block
setblock 33 105 363 minecraft:yellow_terracotta
setblock 34 105 362 minecraft:yellow_terracotta
fill 34 105 363 34 108 364 minecraft:honeycomb_block
fill 35 105 340 35 112 340 minecraft:brown_terracotta
fill 35 105 342 36 112 342 minecraft:brown_terracotta
setblock 35 105 361 minecraft:yellow_terracotta
fill 35 105 362 35 108 362 minecraft:honeycomb_block
fill 36 105 323 37 105 323 minecraft:honeycomb_block
fill 36 105 361 36 108 361 minecraft:honeycomb_block
fill 37 105 340 37 112 341 minecraft:brown_terracotta
setblock 38 105 323 minecraft:yellow_terracotta
setblock 38 105 363 minecraft:yellow_terracotta
fill 39 105 323 39 108 323 minecraft:honeycomb_block
fill 39 105 338 39 105 341 minecraft:honeycomb_block
setblock 39 105 342 minecraft:yellow_terracotta
fill 39 105 343 39 108 343 minecraft:honeycomb_block
fill 39 105 345 39 105 346 minecraft:honeycomb_block
setblock 39 105 357 minecraft:yellow_terracotta
fill 39 105 358 39 108 358 minecraft:honeycomb_block
setblock 39 105 362 minecraft:yellow_terracotta
fill 39 105 363 39 108 363 minecraft:honeycomb_block
setblock 40 105 336 minecraft:yellow_terracotta
fill 40 105 337 40 108 337 minecraft:honeycomb_block
setblock 40 105 341 minecraft:yellow_terracotta
fill 40 105 342 40 108 342 minecraft:honeycomb_block
setblock 40 105 346 minecraft:yellow_terracotta
fill 40 105 347 40 108 347 minecraft:honeycomb_block
setblock 40 105 351 minecraft:yellow_terracotta
fill 40 105 352 40 108 352 minecraft:honeycomb_block
setblock 40 105 356 minecraft:yellow_terracotta
fill 40 105 357 40 108 357 minecraft:honeycomb_block
setblock 40 105 361 minecraft:yellow_terracotta
fill 40 105 362 40 108 362 minecraft:honeycomb_block
setblock 41 105 324 minecraft:honeycomb_block
setblock 41 105 325 minecraft:yellow_terracotta
setblock 41 105 335 minecraft:yellow_terracotta
fill 41 105 336 41 108 336 minecraft:honeycomb_block
setblock 41 105 340 minecraft:yellow_terracotta
fill 41 105 341 41 108 341 minecraft:honeycomb_block
setblock 41 105 345 minecraft:yellow_terracotta
fill 41 105 346 41 108 346 minecraft:honeycomb_block
setblock 41 105 350 minecraft:yellow_terracotta
fill 41 105 351 41 108 351 minecraft:honeycomb_block
setblock 41 105 355 minecraft:yellow_terracotta
fill 41 105 356 41 108 356 minecraft:honeycomb_block
setblock 41 105 360 minecraft:yellow_terracotta
fill 41 105 361 41 108 361 minecraft:honeycomb_block
fill 0 106 328 0 215 328 minecraft:honeycomb_block
setblock 0 106 349 minecraft:orange_terracotta
setblock 1 106 323 minecraft:honeycomb_block
setblock 1 106 324 minecraft:yellow_terracotta
fill 1 106 325 2 108 325 minecraft:honeycomb_block
setblock 1 106 329 minecraft:yellow_terracotta
fill 1 106 330 1 109 330 minecraft:honeycomb_block
setblock 1 106 334 minecraft:yellow_terracotta
fill 1 106 335 1 109 335 minecraft:honeycomb_block
setblock 1 106 339 minecraft:yellow_terracotta
fill 1 106 340 1 109 340 minecraft:honeycomb_block
setblock 1 106 344 minecraft:yellow_terracotta
fill 1 106 345 1 109 345 minecraft:honeycomb_block
setblock 1 106 349 minecraft:yellow_terracotta
fill 1 106 350 1 109 350 minecraft:honeycomb_block
setblock 1 106 354 minecraft:yellow_terracotta
fill 1 106 355 1 108 355 minecraft:honeycomb_block
setblock 1 106 359 minecraft:yellow_terracotta
fill 1 106 360 1 109 360 minecraft:honeycomb_block
fill 2 106 322 2 120 322 minecraft:honeycomb_block
setblock 2 106 323 minecraft:yellow_terracotta
fill 2 106 324 3 108 324 minecraft:honeycomb_block
setblock 2 106 333 minecraft:yellow_terracotta
fill 2 106 334 2 109 334 minecraft:honeycomb_block
setblock 2 106 338 minecraft:yellow_terracotta
fill 2 106 339 2 109 339 minecraft:honeycomb_block
setblock 2 106 343 minecraft:yellow_terracotta
fill 2 106 344 2 109 344 minecraft:honeycomb_block
setblock 2 106 348 minecraft:yellow_terracotta
setblock 2 106 363 minecraft:yellow_terracotta
fill 3 106 323 3 109 323 minecraft:honeycomb_block
setblock 3 106 337 minecraft:yellow_terracotta
fill 3 106 338 3 109 338 minecraft:honeycomb_block
setblock 3 106 342 minecraft:yellow_terracotta
fill 3 106 343 3 109 343 minecraft:honeycomb_block
fill 3 106 345 3 107 345 minecraft:honeycomb_block
setblock 3 106 362 minecraft:yellow_terracotta
fill 3 106 363 3 109 363 minecraft:honeycomb_block
fill 4 106 322 4 224 322 minecraft:honeycomb_block
setblock 7 106 323 minecraft:yellow_terracotta
setblock 7 106 363 minecraft:yellow_terracotta
fill 8 106 323 11 106 323 minecraft:honeycomb_block
fill 8 106 363 11 106 363 minecraft:honeycomb_block
setblock 12 106 323 minecraft:yellow_terracotta
setblock 12 106 363 minecraft:yellow_terracotta
fill 13 106 323 13 108 324 minecraft:honeycomb_block
fill 13 106 363 13 109 363 minecraft:honeycomb_block
fill 14 106 324 15 106 324 minecraft:honeycomb_block
fill 14 106 362 14 109 362 minecraft:honeycomb_block
setblock 16 106 324 minecraft:yellow_terracotta
fill 16 106 325 19 106 325 minecraft:honeycomb_block
fill 16 106 361 16 108 361 minecraft:honeycomb_block
setblock 17 106 323 minecraft:yellow_terracotta
fill 17 106 324 17 109 324 minecraft:honeycomb_block
setblock 17 106 363 minecraft:yellow_terracotta
fill 18 106 323 18 109 323 minecraft:honeycomb_block
setblock 18 106 362 minecraft:yellow_terracotta
fill 18 106 363 18 109 363 minecraft:honeycomb_block
setblock 19 106 361 minecraft:yellow_terracotta
fill 19 106 362 19 109 362 minecraft:honeycomb_block
setblock 20 106 325 minecraft:yellow_terracotta
setblock 20 106 360 minecraft:yellow_terracotta
fill 20 106 361 20 109 361 minecraft:honeycomb_block
setblock 21 106 324 minecraft:yellow_terracotta
fill 21 106 325 22 108 325 minecraft:honeycomb_block
fill 21 106 360 21 108 360 minecraft:honeycomb_block
setblock 22 106 323 minecraft:yellow_terracotta
fill 22 106 324 22 109 324 minecraft:honeycomb_block
setblock 22 106 363 minecraft:yellow_terracotta
fill 23 106 323 23 109 323 minecraft:honeycomb_block
setblock 23 106 362 minecraft:yellow_terracotta
fill 23 106 363 26 106 363 minecraft:honeycomb_block
setblock 24 106 361 minecraft:yellow_terracotta
fill 24 106 362 24 109 362 minecraft:honeycomb_block
setblock 25 106 324 minecraft:honeycomb_block
fill 25 106 361 25 109 361 minecraft:honeycomb_block
setblock 27 106 323 minecraft:yellow_terracotta
setblock 27 106 361 minecraft:honeycomb_block
setblock 27 106 363 minecraft:yellow_terracotta
fill 28 106 323 29 108 323 minecraft:honeycomb_block
setblock 28 106 362 minecraft:yellow_terracotta
fill 28 106 363 28 109 363 minecraft:honeycomb_block
fill 29 106 362 29 109 362 minecraft:honeycomb_block
fill 31 106 345 31 107 346 minecraft:yellow_concrete
fill 31 106 362 32 106 362 minecraft:honeycomb_block
setblock 32 106 363 minecraft:yellow_terracotta
setblock 33 106 362 minecraft:yellow_terracotta
fill 33 106 363 33 109 363 minecraft:honeycomb_block
fill 34 106 323 36 106 323 minecraft:honeycomb_block
fill 34 106 340 34 112 341 minecraft:brown_terracotta
setblock 34 106 361 minecraft:yellow_terracotta
fill 34 106 362 34 109 362 minecraft:honeycomb_block
fill 35 106 339 37 112 339 minecraft:brown_terracotta
fill 35 106 361 35 109 361 minecraft:honeycomb_block
setblock 36 106 364 minecraft:orange_terracotta
setblock 37 106 323 minecraft:yellow_terracotta
fill 37 106 342 37 112 342 minecraft:brown_terracotta
setblock 37 106 363 minecraft:yellow_terracotta
fill 37 106 364 39 129 364 minecraft:honeycomb_block
fill 38 106 323 38 109 323 minecraft:honeycomb_block
setblock 38 106 342 minecraft:yellow_terracotta
fill 38 106 343 38 109 343 minecraft:honeycomb_block
setblock 38 106 362 minecraft:yellow_terracotta
fill 38 106 363 38 109 363 minecraft:honeycomb_block
fill 39 106 337 39 106 340 minecraft:honeycomb_block
setblock 39 106 341 minecraft:yellow_terracotta
fill 39 106 342 39 109 342 minecraft:honeycomb_block
setblock 39 106 345 minecraft:honeycomb_block
setblock 39 106 346 minecraft:yellow_terracotta
fill 39 106 347 39 108 348 minecraft:honeycomb_block
setblock 39 106 356 minecraft:yellow_terracotta
fill 39 106 357 39 108 357 minecraft:honeycomb_block
setblock 39 106 361 minecraft:yellow_terracotta
fill 39 106 362 39 109 362 minecraft:honeycomb_block
setblock 40 106 335 minecraft:yellow_terracotta
fill 40 106 336 40 109 336 minecraft:honeycomb_block
setblock 40 106 340 minecraft:yellow_terracotta
fill 40 106 341 40 109 341 minecraft:honeycomb_block
setblock 40 106 345 minecraft:yellow_terracotta
fill 40 106 346 40 109 346 minecraft:honeycomb_block
setblock 40 106 349 minecraft:honeycomb_block
setblock 40 106 350 minecraft:yellow_terracotta
fill 40 106 351 40 109 351 minecraft:honeycomb_block
setblock 40 106 355 minecraft:yellow_terracotta
fill 40 106 356 40 109 356 minecraft:honeycomb_block
setblock 40 106 360 minecraft:yellow_terracotta
fill 40 106 361 40 109 361 minecraft:honeycomb_block
setblock 41 106 324 minecraft:yellow_terracotta
fill 41 106 325 41 108 326 minecraft:honeycomb_block
setblock 41 106 328 minecraft:honey_block
setblock 41 106 334 minecraft:yellow_terracotta
fill 41 106 335 41 109 335 minecraft:honeycomb_block
setblock 41 106 339 minecraft:yellow_terracotta
fill 41 106 340 41 109 340 minecraft:honeycomb_block
setblock 41 106 344 minecraft:yellow_terracotta
fill 41 106 345 41 109 345 minecraft:honeycomb_block
setblock 41 106 349 minecraft:yellow_terracotta
fill 41 106 350 41 109 350 minecraft:honeycomb_block
setblock 41 106 354 minecraft:yellow_terracotta
fill 41 106 355 41 109 355 minecraft:honeycomb_block
setblock 41 106 359 minecraft:yellow_terracotta
fill 41 106 360 41 109 360 minecraft:honeycomb_block
fill 0 107 349 1 110 349 minecraft:honeycomb_block
setblock 0 107 358 minecraft:yellow_concrete
setblock 1 107 323 minecraft:yellow_terracotta
fill 1 107 324 1 110 324 minecraft:honeycomb_block
setblock 1 107 327 minecraft:honeycomb_block
setblock 1 107 328 minecraft:yellow_terracotta
fill 1 107 329 1 110 329 minecraft:honeycomb_block
setblock 1 107 333 minecraft:yellow_terracotta
fill 1 107 334 1 110 334 minecraft:honeycomb_block
setblock 1 107 338 minecraft:yellow_terracotta
fill 1 107 339 1 110 339 minecraft:honeycomb_block
setblock 1 107 343 minecraft:yellow_terracotta
fill 1 107 344 1 110 344 minecraft:honeycomb_block
setblock 1 107 348 minecraft:yellow_terracotta
setblock 1 107 353 minecraft:yellow_terracotta
fill 1 107 354 1 108 354 minecraft:honeycomb_block
setblock 1 107 358 minecraft:yellow_terracotta
fill 1 107 359 1 110 359 minecraft:honeycomb_block
setblock 1 107 363 minecraft:yellow_terracotta
fill 2 107 323 2 110 323 minecraft:honeycomb_block
setblock 2 107 326 minecraft:honeycomb_block
setblock 2 107 327 minecraft:yellow_terracotta
fill 2 107 328 2 110 328 minecraft:honeycomb_block
setblock 2 107 331 minecraft:honeycomb_block
setblock 2 107 332 minecraft:yellow_terracotta
fill 2 107 333 2 110 333 minecraft:honeycomb_block
setblock 2 107 337 minecraft:yellow_terracotta
fill 2 107 338 2 110 338 minecraft:honeycomb_block
setblock 2 107 342 minecraft:yellow_terracotta
fill 2 107 343 2 110 343 minecraft:honeycomb_block
setblock 2 107 347 minecraft:yellow_terracotta
fill 2 107 348 2 110 348 minecraft:honeycomb_block
setblock 2 107 362 minecraft:yellow_terracotta
fill 2 107 363 2 110 363 minecraft:honeycomb_block
setblock 3 107 336 minecraft:yellow_terracotta
fill 3 107 337 3 108 337 minecraft:honeycomb_block
setblock 3 107 341 minecraft:yellow_terracotta
fill 3 107 342 3 110 342 minecraft:honeycomb_block
fill 3 107 362 3 108 362 minecraft:honeycomb_block
setblock 4 107 324 minecraft:honeycomb_block
setblock 5 107 323 minecraft:honeycomb_block
setblock 5 107 324 minecraft:yellow_terracotta
setblock 6 107 323 minecraft:yellow_terracotta
setblock 6 107 363 minecraft:yellow_terracotta
fill 7 107 323 10 107 323 minecraft:honeycomb_block
fill 7 107 363 10 107 363 minecraft:honeycomb_block
setblock 10 107 324 minecraft:yellow_terracotta
setblock 11 107 323 minecraft:yellow_terracotta
fill 11 107 324 12 109 324 minecraft:honeycomb_block
setblock 11 107 363 minecraft:yellow_terracotta
fill 12 107 323 12 110 323 minecraft:honeycomb_block
fill 12 107 363 12 110 363 minecraft:honeycomb_block
fill 13 107 362 13 110 362 minecraft:honeycomb_block
setblock 14 107 324 minecraft:honeycomb_block
setblock 14 107 325 minecraft:yellow_terracotta
setblock 15 107 324 minecraft:yellow_terracotta
fill 15 107 325 18 107 325 minecraft:honeycomb_block
fill 15 107 361 15 109 361 minecraft:honeycomb_block
setblock 16 107 323 minecraft:yellow_terracotta
fill 16 107 324 16 110 324 minecraft:honeycomb_block
setblock 16 107 363 minecraft:yellow_terracotta
fill 17 107 323 17 110 323 minecraft:honeycomb_block
setblock 17 107 362 minecraft:yellow_terracotta
fill 17 107 363 17 110 363 minecraft:honeycomb_block
setblock 18 107 361 minecraft:yellow_terracotta
fill 18 107 362 18 110 362 minecraft:honeycomb_block
setblock 19 107 325 minecraft:yellow_terracotta
setblock 19 107 360 minecraft:yellow_terracotta
fill 19 107 361 19 110 361 minecraft:honeycomb_block
setblock 20 107 324 minecraft:yellow_terracotta
fill 20 107 325 20 110 325 minecraft:honeycomb_block
fill 20 107 360 20 109 360 minecraft:honeycomb_block
setblock 21 107 323 minecraft:yellow_terracotta
fill 21 107 324 21 110 324 minecraft:honeycomb_block
setblock 21 107 363 minecraft:yellow_terracotta
fill 22 107 323 22 110 323 minecraft:honeycomb_block
setblock 22 107 362 minecraft:yellow_terracotta
fill 22 107 363 25 107 363 minecraft:honeycomb_block
setblock 23 107 361 minecraft:yellow_terracotta
fill 23 107 362 23 110 362 minecraft:honeycomb_block
fill 24 107 361 24 110 361 minecraft:honeycomb_block
setblock 25 107 324 minecraft:yellow_terracotta
setblock 26 107 323 minecraft:yellow_terracotta
setblock 26 107 363 minecraft:yellow_terracotta
fill 27 107 323 27 110 323 minecraft:honeycomb_block
setblock 27 107 362 minecraft:yellow_terracotta
fill 27 107 363 27 110 363 minecraft:honeycomb_block
fill 28 107 362 28 110 362 minecraft:honeycomb_block
setblock 30 107 323 minecraft:honeycomb_block
setblock 31 107 323 minecraft:yellow_terracotta
setblock 31 107 362 minecraft:honeycomb_block
setblock 31 107 363 minecraft:yellow_terracotta
fill 32 107 323 35 107 323 minecraft:honeycomb_block
setblock 32 107 362 minecraft:yellow_terracotta
fill 32 107 363 32 110 363 minecraft:honeycomb_block
setblock 33 107 361 minecraft:yellow_terracotta
fill 33 107 362 33 110 362 minecraft:honeycomb_block
fill 34 107 339 34 112 339 minecraft:brown_terracotta
fill 34 107 342 34 112 342 minecraft:brown_terracotta
fill 34 107 361 34 110 361 minecraft:honeycomb_block
fill 35 107 343 36 112 343 minecraft:brown_terracotta
setblock 36 107 323 minecraft:yellow_terracotta
setblock 36 107 363 minecraft:yellow_terracotta
fill 36 107 364 36 155 364 minecraft:honeycomb_block
fill 37 107 323 37 109 324 minecraft:honeycomb_block
setblock 37 107 362 minecraft:yellow_terracotta
fill 37 107 363 37 110 363 minecraft:honeycomb_block
fill 38 107 324 39 107 324 minecraft:honeycomb_block
setblock 38 107 340 minecraft:honeycomb_block
setblock 38 107 341 minecraft:yellow_terracotta
fill 38 107 342 38 110 342 minecraft:honeycomb_block
fill 38 107 344 38 107 345 minecraft:honeycomb_block
setblock 38 107 346 minecraft:yellow_terracotta
setblock 38 107 361 minecraft:yellow_terracotta
fill 38 107 362 38 110 362 minecraft:honeycomb_block
fill 39 107 337 39 107 339 minecraft:honeycomb_block
setblock 39 107 340 minecraft:yellow_terracotta
fill 39 107 341 39 110 341 minecraft:honeycomb_block
setblock 39 107 345 minecraft:yellow_terracotta
fill 39 107 346 39 110 346 minecraft:honeycomb_block
setblock 39 107 349 minecraft:honeycomb_block
setblock 39 107 350 minecraft:yellow_terracotta
setblock 39 107 356 minecraft:honeycomb_block
setblock 39 107 360 minecraft:yellow_terracotta
fill 39 107 361 39 110 361 minecraft:honeycomb_block
setblock 40 107 323 minecraft:honeycomb_block
setblock 40 107 324 minecraft:yellow_terracotta
setblock 40 107 334 minecraft:yellow_terracotta
fill 40 107 335 40 110 335 minecraft:honeycomb_block
setblock 40 107 339 minecraft:yellow_terracotta
fill 40 107 340 40 110 340 minecraft:honeycomb_block
setblock 40 107 344 minecraft:yellow_terracotta
fill 40 107 345 40 110 345 minecraft:honeycomb_block
setblock 40 107 349 minecraft:yellow_terracotta
fill 40 107 350 40 110 350 minecraft:honeycomb_block
setblock 40 107 354 minecraft:yellow_terracotta
fill 40 107 355 40 110 355 minecraft:honeycomb_block
setblock 40 107 359 minecraft:yellow_terracotta
fill 40 107 360 40 110 360 minecraft:honeycomb_block
fill 41 107 322 41 107 323 minecraft:yellow_terracotta
fill 41 107 324 41 110 324 minecraft:honeycomb_block
setblock 41 107 327 minecraft:honeycomb_block
setblock 41 107 328 minecraft:yellow_terracotta
fill 41 107 329 41 108 331 minecraft:honeycomb_block
setblock 41 107 333 minecraft:yellow_terracotta
fill 41 107 334 41 110 334 minecraft:honeycomb_block
setblock 41 107 338 minecraft:yellow_terracotta
fill 41 107 339 41 110 339 minecraft:honeycomb_block
setblock 41 107 343 minecraft:yellow_terracotta
fill 41 107 344 41 110 344 minecraft:honeycomb_block
setblock 41 107 348 minecraft:yellow_terracotta
fill 41 107 349 41 110 349 minecraft:honeycomb_block
setblock 41 107 353 minecraft:yellow_terracotta
fill 41 107 354 41 110 354 minecraft:honeycomb_block
setblock 41 107 358 minecraft:yellow_terracotta
fill 41 107 359 41 110 359 minecraft:honeycomb_block
setblock 41 107 363 minecraft:yellow_terracotta
setblock 42 107 360 minecraft:yellow_concrete
setblock 0 108 351 minecraft:yellow_concrete
fill 0 108 352 0 113 352 minecraft:honeycomb_block
fill 0 108 358 1 109 358 minecraft:honeycomb_block
fill 1 108 323 1 111 323 minecraft:honeycomb_block
setblock 1 108 327 minecraft:yellow_terracotta
fill 1 108 328 1 111 328 minecraft:honeycomb_block
setblock 1 108 332 minecraft:yellow_terracotta
fill 1 108 333 1 111 333 minecraft:honeycomb_block
setblock 1 108 337 minecraft:yellow_terracotta
fill 1 108 338 1 111 338 minecraft:honeycomb_block
setblock 1 108 342 minecraft:yellow_terracotta
fill 1 108 343 1 111 343 minecraft:honeycomb_block
setblock 1 108 347 minecraft:yellow_terracotta
fill 1 108 348 1 111 348 minecraft:honeycomb_block
setblock 1 108 352 minecraft:yellow_terracotta
fill 1 108 353 1 109 353 minecraft:honeycomb_block
setblock 1 108 357 minecraft:yellow_terracotta
setblock 1 108 362 minecraft:yellow_terracotta
fill 1 108 363 1 111 363 minecraft:honeycomb_block
setblock 2 108 326 minecraft:yellow_terracotta
fill 2 108 327 2 111 327 minecraft:honeycomb_block
fill 2 108 329 2 108 330 minecraft:honeycomb_block
setblock 2 108 331 minecraft:yellow_terracotta
fill 2 108 332 2 111 332 minecraft:honeycomb_block
setblock 2 108 336 minecraft:yellow_terracotta
fill 2 108 337 2 111 337 minecraft:honeycomb_block
setblock 2 108 341 minecraft:yellow_terracotta
fill 2 108 342 2 111 342 minecraft:honeycomb_block
setblock 2 108 346 minecraft:yellow_terracotta
fill 2 108 347 2 111 347 minecraft:honeycomb_block
fill 2 108 349 2 109 349 minecraft:honeycomb_block
setblock 2 108 361 minecraft:yellow_terracotta
fill 2 108 362 2 109 362 minecraft:honeycomb_block
setblock 3 108 340 minecraft:yellow_terracotta
fill 3 108 341 3 110 341 minecraft:honeycomb_block
setblock 3 108 345 minecraft:yellow_terracotta
setblock 4 108 324 minecraft:yellow_terracotta
setblock 5 108 323 minecraft:yellow_terracotta
fill 5 108 324 8 108 324 minecraft:honeycomb_block
setblock 5 108 363 minecraft:yellow_terracotta
fill 6 108 323 9 108 323 minecraft:honeycomb_block
fill 6 108 363 9 108 363 minecraft:honeycomb_block
setblock 9 108 324 minecraft:yellow_terracotta
setblock 10 108 323 minecraft:yellow_terracotta
fill 10 108 324 10 111 324 minecraft:honeycomb_block
setblock 10 108 363 minecraft:yellow_terracotta
fill 11 108 323 11 111 323 minecraft:honeycomb_block
fill 11 108 363 11 111 363 minecraft:honeycomb_block
fill 12 108 362 12 111 362 minecraft:honeycomb_block
setblock 13 108 325 minecraft:yellow_terracotta
setblock 14 108 324 minecraft:yellow_terracotta
fill 14 108 325 17 108 325 minecraft:honeycomb_block
setblock 15 108 323 minecraft:yellow_terracotta
fill 15 108 324 15 111 324 minecraft:honeycomb_block
setblock 15 108 363 minecraft:yellow_terracotta
fill 16 108 323 16 111 323 minecraft:honeycomb_block
setblock 16 108 362 minecraft:yellow_terracotta
fill 16 108 363 16 111 363 minecraft:honeycomb_block
setblock 17 108 361 minecraft:yellow_terracotta
fill 17 108 362 17 111 362 minecraft:honeycomb_block
setblock 18 108 325 minecraft:yellow_terracotta
fill 18 108 361 18 111 361 minecraft:honeycomb_block
setblock 19 108 324 minecraft:yellow_terracotta
fill 19 108 325 19 111 325 minecraft:honeycomb_block
fill 19 108 360 19 109 360 minecraft:honeycomb_block
setblock 20 108 323 minecraft:yellow_terracotta
fill 20 108 324 20 111 324 minecraft:honeycomb_block
setblock 20 108 363 minecraft:yellow_terracotta
fill 21 108 323 21 111 323 minecraft:honeycomb_block
setblock 21 108 362 minecraft:yellow_terracotta
fill 21 108 363 24 108 363 minecraft:honeycomb_block
setblock 22 108 361 minecraft:yellow_terracotta
fill 22 108 362 22 111 362 minecraft:honeycomb_block
fill 23 108 361 23 110 361 minecraft:honeycomb_block
setblock 24 108 324 minecraft:yellow_terracotta
setblock 25 108 323 minecraft:yellow_terracotta
fill 25 108 324 26 110 324 minecraft:honeycomb_block
setblock 25 108 363 minecraft:yellow_terracotta
fill 26 108 323 26 111 323 minecraft:honeycomb_block
setblock 26 108 362 minecraft:yellow_terracotta
fill 26 108 363 26 111 363 minecraft:honeycomb_block
fill 27 108 362 27 111 362 minecraft:honeycomb_block
setblock 30 108 323 minecraft:yellow_terracotta
setblock 30 108 363 minecraft:yellow_terracotta
fill 31 108 323 34 108 323 minecraft:honeycomb_block
setblock 31 108 362 minecraft:yellow_terracotta
fill 31 108 363 31 111 363 minecraft:honeycomb_block
fill 32 108 362 32 111 362 minecraft:honeycomb_block
fill 33 108 340 33 110 341 minecraft:brown_terracotta
fill 33 108 361 33 110 361 minecraft:honeycomb_block
fill 34 108 343 34 112 343 minecraft:brown_terracotta
fill 35 108 322 36 155 322 minecraft:honeycomb_block
setblock 35 108 323 minecraft:yellow_terracotta
fill 35 108 324 36 110 324 minecraft:honeycomb_block
fill 35 108 338 37 112 338 minecraft:brown_terracotta
setblock 35 108 363 minecraft:yellow_terracotta
fill 36 108 323 36 111 323 minecraft:honeycomb_block
setblock 36 108 362 minecraft:yellow_terracotta
fill 36 108 363 36 111 363 minecraft:honeycomb_block
setblock 37 108 322 minecraft:yellow_concrete
fill 37 108 343 37 109 343 minecraft:brown_terracotta
setblock 37 108 361 minecraft:yellow_terracotta
fill 37 108 362 37 111 362 minecraft:honeycomb_block
fill 38 108 322 38 308 322 minecraft:honeycomb_block
setblock 38 108 324 minecraft:honeycomb_block
setblock 38 108 339 minecraft:brown_terracotta
setblock 38 108 340 minecraft:yellow_terracotta
fill 38 108 341 38 111 341 minecraft:honeycomb_block
setblock 38 108 344 minecraft:honeycomb_block
setblock 38 108 345 minecraft:yellow_terracotta
fill 38 108 346 38 109 348 minecraft:honeycomb_block
fill 38 108 361 38 110 361 minecraft:honeycomb_block
setblock 39 108 324 minecraft:yellow_terracotta
fill 39 108 337 39 108 338 minecraft:honeycomb_block
setblock 39 108 339 minecraft:yellow_terracotta
fill 39 108 340 39 111 340 minecraft:honeycomb_block
setblock 39 108 344 minecraft:yellow_terracotta
fill 39 108 345 39 111 345 minecraft:honeycomb_block
setblock 39 108 349 minecraft:yellow_terracotta
fill 39 108 350 39 109 352 minecraft:honeycomb_block
setblock 39 108 359 minecraft:yellow_terracotta
fill 39 108 360 39 110 360 minecraft:honeycomb_block
setblock 40 108 323 minecraft:yellow_terracotta
fill 40 108 324 40 109 326 minecraft:honeycomb_block
fill 40 108 334 40 109 334 minecraft:honeycomb_block
setblock 40 108 338 minecraft:yellow_terracotta
fill 40 108 339 40 111 339 minecraft:honeycomb_block
setblock 40 108 343 minecraft:yellow_terracotta
fill 40 108 344 40 111 344 minecraft:honeycomb_block
setblock 40 108 348 minecraft:yellow_terracotta
fill 40 108 349 40 111 349 minecraft:honeycomb_block
setblock 40 108 353 minecraft:yellow_terracotta
fill 40 108 354 40 111 354 minecraft:honeycomb_block
setblock 40 108 358 minecraft:yellow_terracotta
fill 40 108 359 40 110 359 minecraft:honeycomb_block
setblock 40 108 363 minecraft:yellow_terracotta
fill 41 108 322 41 111 323 minecraft:honeycomb_block
setblock 41 108 327 minecraft:yellow_terracotta
fill 41 108 328 41 111 328 minecraft:honeycomb_block
setblock 41 108 332 minecraft:yellow_terracotta
fill 41 108 333 41 111 333 minecraft:honeycomb_block
setblock 41 108 337 minecraft:yellow_terracotta
fill 41 108 338 41 111 338 minecraft:honeycomb_block
setblock 41 108 342 minecraft:yellow_terracotta
fill 41 108 343 41 111 343 minecraft:honeycomb_block
setblock 41 108 347 minecraft:yellow_terracotta
fill 41 108 348 41 111 348 minecraft:honeycomb_block
setblock 41 108 352 minecraft:yellow_terracotta
fill 41 108 353 41 111 353 minecraft:honeycomb_block
setblock 41 108 357 minecraft:yellow_terracotta
fill 41 108 358 41 111 358 minecraft:honeycomb_block
setblock 41 108 362 minecraft:yellow_terracotta
fill 41 108 363 41 111 363 minecraft:honeycomb_block
fill 42 108 360 42 185 360 minecraft:honeycomb_block
fill 0 109 351 0 198 351 minecraft:honeycomb_block
setblock 1 109 325 minecraft:honeycomb_block
setblock 1 109 326 minecraft:yellow_terracotta
fill 1 109 327 1 112 327 minecraft:honeycomb_block
setblock 1 109 331 minecraft:yellow_terracotta
fill 1 109 332 1 112 332 minecraft:honeycomb_block
setblock 1 109 336 minecraft:yellow_terracotta
fill 1 109 337 1 112 337 minecraft:honeycomb_block
setblock 1 109 341 minecraft:yellow_terracotta
fill 1 109 342 1 112 342 minecraft:honeycomb_block
setblock 1 109 346 minecraft:yellow_terracotta
fill 1 109 347 1 112 347 minecraft:honeycomb_block
setblock 1 109 351 minecraft:yellow_terracotta
fill 1 109 352 1 111 352 minecraft:honeycomb_block
setblock 1 109 357 minecraft:honeycomb_block
setblock 1 109 361 minecraft:yellow_terracotta
fill 1 109 362 1 112 362 minecraft:honeycomb_block
setblock 2 109 324 minecraft:honeycomb_block
setblock 2 109 325 minecraft:yellow_terracotta
fill 2 109 326 2 112 326 minecraft:honeycomb_block
setblock 2 109 329 minecraft:honeycomb_block
setblock 2 109 330 minecraft:yellow_terracotta
fill 2 109 331 2 111 331 minecraft:honeycomb_block
setblock 2 109 335 minecraft:yellow_terracotta
fill 2 109 336 2 111 336 minecraft:honeycomb_block
setblock 2 109 340 minecraft:yellow_terracotta
fill 2 109 341 2 112 341 minecraft:honeycomb_block
setblock 2 109 345 minecraft:yellow_terracotta
fill 2 109 346 2 112 346 minecraft:honeycomb_block
setblock 3 109 324 minecraft:yellow_terracotta
setblock 3 109 339 minecraft:yellow_terracotta
fill 3 109 340 3 110 340 minecraft:honeycomb_block
setblock 3 109 344 minecraft:yellow_terracotta
fill 3 109 345 3 110 345 minecraft:honeycomb_block
setblock 4 109 323 minecraft:yellow_terracotta
fill 4 109 324 7 109 324 minecraft:honeycomb_block
setblock 4 109 363 minecraft:yellow_terracotta
fill 5 109 323 8 109 323 minecraft:honeycomb_block
fill 5 109 363 8 109 363 minecraft:honeycomb_block
setblock 8 109 324 minecraft:yellow_terracotta
setblock 9 109 323 minecraft:yellow_terracotta
fill 9 109 324 9 112 324 minecraft:honeycomb_block
setblock 9 109 363 minecraft:yellow_terracotta
fill 10 109 323 10 112 323 minecraft:honeycomb_block
fill 10 109 363 10 112 363 minecraft:honeycomb_block
setblock 11 109 325 minecraft:honeycomb_block
fill 11 109 362 11 112 362 minecraft:honeycomb_block
setblock 12 109 325 minecraft:yellow_terracotta
setblock 13 109 323 minecraft:honeycomb_block
setblock 13 109 324 minecraft:yellow_terracotta
fill 13 109 325 16 109 325 minecraft:honeycomb_block
setblock 14 109 323 minecraft:yellow_terracotta
fill 14 109 324 14 112 324 minecraft:honeycomb_block
fill 14 109 361 14 110 361 minecraft:honeycomb_block
setblock 14 109 363 minecraft:yellow_terracotta
fill 15 109 323 15 112 323 minecraft:honeycomb_block
setblock 15 109 326 minecraft:honeycomb_block
setblock 15 109 362 minecraft:yellow_terracotta
fill 15 109 363 15 112 363 minecraft:honeycomb_block
setblock 16 109 326 minecraft:yellow_terracotta
setblock 16 109 361 minecraft:yellow_terracotta
fill 16 109 362 16 112 362 minecraft:honeycomb_block
setblock 17 109 325 minecraft:yellow_terracotta
fill 17 109 326 19 110 326 minecraft:honeycomb_block
fill 17 109 361 17 112 361 minecraft:honeycomb_block
setblock 18 109 324 minecraft:yellow_terracotta
fill 18 109 325 18 112 325 minecraft:honeycomb_block
setblock 19 109 323 minecraft:yellow_terracotta
fill 19 109 324 19 112 324 minecraft:honeycomb_block
setblock 19 109 363 minecraft:yellow_terracotta
fill 20 109 323 20 112 323 minecraft:honeycomb_block
setblock 20 109 362 minecraft:yellow_terracotta
fill 20 109 363 23 109 363 minecraft:honeycomb_block
setblock 21 109 325 minecraft:honeycomb_block
setblock 21 109 361 minecraft:yellow_terracotta
fill 21 109 362 21 112 362 minecraft:honeycomb_block
setblock 22 109 325 minecraft:yellow_terracotta
fill 22 109 361 22 111 361 minecraft:honeycomb_block
setblock 23 109 324 minecraft:yellow_terracotta
setblock 23 109 325 minecraft:honeycomb_block
setblock 24 109 323 minecraft:yellow_terracotta
fill 24 109 324 24 112 324 minecraft:honeycomb_block
setblock 24 109 363 minecraft:yellow_terracotta
fill 25 109 323 25 112 323 minecraft:honeycomb_block
setblock 25 109 362 minecraft:yellow_terracotta
fill 25 109 363 25 112 363 minecraft:honeycomb_block
fill 26 109 362 26 111 362 minecraft:honeycomb_block
setblock 28 109 323 minecraft:honeycomb_block
setblock 29 109 323 minecraft:yellow_terracotta
setblock 29 109 363 minecraft:yellow_terracotta
fill 30 109 323 33 109 323 minecraft:honeycomb_block
setblock 30 109 362 minecraft:yellow_terracotta
fill 30 109 363 30 112 363 minecraft:honeycomb_block
fill 31 109 362 31 112 362 minecraft:honeycomb_block
fill 33 109 339 33 110 339 minecraft:brown_terracotta
fill 33 109 342 33 110 342 minecraft:brown_terracotta
fill 33 109 359 33 113 359 minecraft:yellow_terracotta
setblock 34 109 323 minecraft:yellow_terracotta
fill 34 109 324 34 112 324 minecraft:honeycomb_block
fill 34 109 338 34 112 338 minecraft:brown_terracotta
setblock 34 109 363 minecraft:yellow_terracotta
fill 34 109 364 34 194 364 minecraft:honeycomb_block
fill 35 109 323 35 112 323 minecraft:honeycomb_block
fill 35 109 344 36 112 344 minecraft:brown_terracotta
setblock 35 109 362 minecraft:yellow_terracotta
fill 35 109 363 35 112 363 minecraft:honeycomb_block
setblock 36 109 361 minecraft:yellow_terracotta
fill 36 109 362 36 112 362 minecraft:honeycomb_block
fill 37 109 322 37 151 322 minecraft:honeycomb_block
setblock 37 109 344 minecraft:honeycomb_block
fill 37 109 361 37 111 361 minecraft:honeycomb_block
setblock 38 109 324 minecraft:yellow_terracotta
fill 38 109 338 38 112 338 minecraft:brown_terracotta
setblock 38 109 339 minecraft:yellow_terracotta
fill 38 109 340 38 111 340 minecraft:honeycomb_block
setblock 38 109 344 minecraft:yellow_terracotta
fill 38 109 345 38 112 345 minecraft:honeycomb_block
setblock 38 109 349 minecraft:yellow_terracotta
setblock 39 109 323 minecraft:yellow_terracotta
fill 39 109 324 39 112 324 minecraft:honeycomb_block
setblock 39 109 337 minecraft:honeycomb_block
setblock 39 109 338 minecraft:yellow_terracotta
fill 39 109 339 39 112 339 minecraft:honeycomb_block
setblock 39 109 343 minecraft:yellow_terracotta
fill 39 109 344 39 112 344 minecraft:honeycomb_block
setblock 39 109 347 minecraft:honeycomb_block
setblock 39 109 348 minecraft:yellow_terracotta
fill 39 109 349 39 112 349 minecraft:honeycomb_block
setblock 39 109 358 minecraft:yellow_terracotta
setblock 39 109 359 minecraft:honeycomb_block
setblock 39 109 363 minecraft:yellow_terracotta
fill 40 109 323 40 112 323 minecraft:honeycomb_block
setblock 40 109 327 minecraft:yellow_terracotta
setblock 40 109 337 minecraft:yellow_terracotta
fill 40 109 338 40 112 338 minecraft:honeycomb_block
setblock 40 109 342 minecraft:yellow_terracotta
fill 40 109 343 40 112 343 minecraft:honeycomb_block
setblock 40 109 347 minecraft:yellow_terracotta
fill 40 109 348 40 112 348 minecraft:honeycomb_block
setblock 40 109 352 minecraft:yellow_terracotta
fill 40 109 353 40 112 353 minecraft:honeycomb_block
setblock 40 109 357 minecraft:yellow_terracotta
fill 40 109 358 40 110 358 minecraft:honeycomb_block
setblock 40 109 362 minecraft:yellow_terracotta
fill 40 109 363 40 112 363 minecraft:honeycomb_block
setblock 41 109 325 minecraft:honeycomb_block
setblock 41 109 326 minecraft:yellow_terracotta
fill 41 109 327 41 112 327 minecraft:honeycomb_block
fill 41 109 329 41 109 330 minecraft:honeycomb_block
setblock 41 109 331 minecraft:yellow_terracotta
fill 41 109 332 41 112 332 minecraft:honeycomb_block
setblock 41 109 336 minecraft:yellow_terracotta
fill 41 109 337 41 112 337 minecraft:honeycomb_block
setblock 41 109 341 minecraft:yellow_terracotta
fill 41 109 342 41 112 342 minecraft:honeycomb_block
setblock 41 109 346 minecraft:yellow_terracotta
fill 41 109 347 41 112 347 minecraft:honeycomb_block
setblock 41 109 351 minecraft:yellow_terracotta
fill 41 109 352 41 112 352 minecraft:honeycomb_block
setblock 41 109 356 minecraft:yellow_terracotta
fill 41 109 357 41 111 357 minecraft:honeycomb_block
setblock 41 109 361 minecraft:yellow_terracotta
fill 41 109 362 41 112 362 minecraft:honeycomb_block
setblock 42 109 340 minecraft:yellow_terracotta
fill 0 110 358 0 205 358 minecraft:honeycomb_block
setblock 1 110 325 minecraft:yellow_terracotta
fill 1 110 326 1 113 326 minecraft:honeycomb_block
setblock 1 110 330 minecraft:yellow_terracotta
fill 1 110 331 1 113 331 minecraft:honeycomb_block
setblock 1 110 335 minecraft:yellow_terracotta
fill 1 110 336 1 113 336 minecraft:honeycomb_block
setblock 1 110 340 minecraft:yellow_terracotta
fill 1 110 341 1 113 341 minecraft:honeycomb_block
setblock 1 110 345 minecraft:yellow_terracotta
fill 1 110 346 1 113 346 minecraft:honeycomb_block
setblock 1 110 350 minecraft:yellow_terracotta
fill 1 110 351 1 113 351 minecraft:honeycomb_block
setblock 1 110 357 minecraft:honey_block
setblock 1 110 360 minecraft:yellow_terracotta
fill 1 110 361 1 111 361 minecraft:honeycomb_block
setblock 2 110 324 minecraft:yellow_terracotta
fill 2 110 325 2 113 325 minecraft:honeycomb_block
setblock 2 110 329 minecraft:yellow_terracotta
fill 2 110 330 2 113 330 minecraft:honeycomb_block
setblock 2 110 334 minecraft:yellow_terracotta
fill 2 110 335 2 111 335 minecraft:honeycomb_block
setblock 2 110 339 minecraft:yellow_terracotta
fill 2 110 340 2 112 340 minecraft:honeycomb_block
setblock 2 110 344 minecraft:yellow_terracotta
fill 2 110 345 2 113 345 minecraft:honeycomb_block
setblock 2 110 349 minecraft:yellow_terracotta
setblock 3 110 323 minecraft:yellow_terracotta
fill 3 110 324 6 110 324 minecraft:honeycomb_block
setblock 3 110 325 minecraft:light[level=12]
setblock 3 110 332 minecraft:light[level=12]
setblock 3 110 339 minecraft:honeycomb_block
setblock 3 110 343 minecraft:yellow_terracotta
setblock 3 110 344 minecraft:honeycomb_block
setblock 3 110 346 minecraft:light[level=12]
setblock 3 110 353 minecraft:light[level=12]
setblock 3 110 360 minecraft:light[level=12]
setblock 3 110 363 minecraft:yellow_terracotta
fill 4 110 323 7 110 323 minecraft:honeycomb_block
fill 4 110 363 7 110 363 minecraft:honeycomb_block
fill 5 110 343 5 111 343 minecraft:black_concrete
setblock 7 110 324 minecraft:yellow_terracotta
setblock 8 110 323 minecraft:yellow_terracotta
fill 8 110 324 8 113 324 minecraft:honeycomb_block
setblock 8 110 363 minecraft:yellow_terracotta
fill 9 110 323 9 113 323 minecraft:honeycomb_block
fill 9 110 363 9 113 363 minecraft:honeycomb_block
setblock 10 110 325 minecraft:honeycomb_block
setblock 10 110 332 minecraft:light[level=12]
setblock 10 110 339 minecraft:light[level=12]
setblock 10 110 346 minecraft:light[level=12]
setblock 10 110 353 minecraft:light[level=12]
setblock 10 110 360 minecraft:light[level=12]
setblock 11 110 324 minecraft:honeycomb_block
setblock 11 110 325 minecraft:yellow_terracotta
setblock 12 110 324 minecraft:yellow_terracotta
fill 12 110 325 15 110 325 minecraft:honeycomb_block
setblock 13 110 323 minecraft:yellow_terracotta
fill 13 110 324 13 113 324 minecraft:honeycomb_block
setblock 13 110 363 minecraft:yellow_terracotta
fill 14 110 323 14 113 323 minecraft:honeycomb_block
setblock 14 110 326 minecraft:honeycomb_block
setblock 14 110 362 minecraft:yellow_terracotta
fill 14 110 363 14 113 363 minecraft:honeycomb_block
setblock 15 110 326 minecraft:yellow_terracotta
setblock 15 110 361 minecraft:yellow_terracotta
fill 15 110 362 15 113 362 minecraft:honeycomb_block
setblock 16 110 325 minecraft:yellow_terracotta
fill 16 110 326 16 113 326 minecraft:honeycomb_block
fill 16 110 361 16 113 361 minecraft:honeycomb_block
setblock 17 110 324 minecraft:yellow_terracotta
fill 17 110 325 17 113 325 minecraft:honeycomb_block
setblock 17 110 332 minecraft:light[level=12]
setblock 17 110 339 minecraft:light[level=12]
setblock 17 110 346 minecraft:light[level=12]
setblock 17 110 353 minecraft:light[level=12]
setblock 17 110 360 minecraft:light[level=12]
setblock 18 110 323 minecraft:yellow_terracotta
fill 18 110 324 18 113 324 minecraft:honeycomb_block
setblock 18 110 363 minecraft:yellow_terracotta
fill 19 110 323 19 113 323 minecraft:honeycomb_block
setblock 19 110 362 minecraft:yellow_terracotta
fill 19 110 363 20 112 364 minecraft:honeycomb_block
setblock 20 110 361 minecraft:yellow_terracotta
fill 20 110 362 20 113 362 minecraft:honeycomb_block
setblock 21 110 325 minecraft:yellow_terracotta
fill 21 110 361 21 111 361 minecraft:honeycomb_block
fill 21 110 363 22 110 363 minecraft:honeycomb_block
setblock 21 110 364 minecraft:orange_terracotta
setblock 22 110 324 minecraft:yellow_terracotta
fill 22 110 325 22 111 325 minecraft:honeycomb_block
setblock 23 110 323 minecraft:yellow_terracotta
fill 23 110 324 23 113 324 minecraft:honeycomb_block
setblock 23 110 363 minecraft:yellow_terracotta
fill 24 110 323 24 113 323 minecraft:honeycomb_block
setblock 24 110 325 minecraft:light[level=12]
setblock 24 110 332 minecraft:light[level=12]
setblock 24 110 339 minecraft:light[level=12]
setblock 24 110 346 minecraft:light[level=12]
setblock 24 110 353 minecraft:light[level=12]
setblock 24 110 360 minecraft:light[level=12]
setblock 24 110 362 minecraft:yellow_terracotta
fill 24 110 363 24 113 363 minecraft:honeycomb_block
fill 25 110 362 25 112 362 minecraft:honeycomb_block
setblock 28 110 323 minecraft:yellow_terracotta
setblock 28 110 363 minecraft:yellow_terracotta
fill 29 110 323 32 110 323 minecraft:honeycomb_block
setblock 29 110 362 minecraft:yellow_terracotta
fill 29 110 363 29 113 363 minecraft:honeycomb_block
fill 30 110 362 30 112 362 minecraft:honeycomb_block
setblock 31 110 325 minecraft:light[level=12]
setblock 31 110 332 minecraft:light[level=12]
setblock 31 110 339 minecraft:light[level=12]
setblock 31 110 346 minecraft:light[level=12]
setblock 31 110 353 minecraft:light[level=12]
setblock 31 110 360 minecraft:light[level=12]
setblock 32 110 324 minecraft:yellow_terracotta
fill 32 110 340 32 112 341 minecraft:brown_terracotta
setblock 33 110 323 minecraft:yellow_terracotta
fill 33 110 324 33 113 324 minecraft:honeycomb_block
setblock 33 110 338 minecraft:brown_terracotta
setblock 33 110 343 minecraft:brown_terracotta
setblock 33 110 363 minecraft:yellow_terracotta
fill 34 110 323 34 113 323 minecraft:honeycomb_block
fill 34 110 344 34 112 344 minecraft:brown_terracotta
setblock 34 110 362 minecraft:yellow_terracotta
fill 34 110 363 34 113 363 minecraft:honeycomb_block
fill 35 110 337 37 112 337 minecraft:brown_terracotta
setblock 35 110 361 minecraft:yellow_terracotta
fill 35 110 362 35 113 362 minecraft:honeycomb_block
fill 36 110 361 36 111 361 minecraft:honeycomb_block
setblock 37 110 323 minecraft:honeycomb_block
fill 37 110 324 37 110 325 minecraft:yellow_terracotta
setblock 37 110 343 minecraft:honeycomb_block
setblock 37 110 344 minecraft:yellow_terracotta
fill 37 110 345 37 112 346 minecraft:honeycomb_block
fill 37 110 360 37 112 360 minecraft:yellow_terracotta
setblock 38 110 323 minecraft:yellow_terracotta
fill 38 110 324 38 113 324 minecraft:honeycomb_block
setblock 38 110 325 minecraft:light[level=12]
setblock 38 110 332 minecraft:light[level=12]
fill 38 110 339 38 112 339 minecraft:brown_terracotta
setblock 38 110 343 minecraft:yellow_terracotta
fill 38 110 344 38 113 344 minecraft:honeycomb_block
fill 38 110 346 38 110 347 minecraft:honeycomb_block
setblock 38 110 348 minecraft:yellow_terracotta
fill 38 110 349 38 112 350 minecraft:honeycomb_block
setblock 38 110 353 minecraft:light[level=12]
setblock 38 110 360 minecraft:light[level=12]
setblock 38 110 363 minecraft:yellow_terracotta
fill 39 110 323 39 113 323 minecraft:honeycomb_block
setblock 39 110 337 minecraft:yellow_terracotta
fill 39 110 338 39 111 338 minecraft:honeycomb_block
setblock 39 110 342 minecraft:yellow_terracotta
fill 39 110 343 39 113 343 minecraft:honeycomb_block
setblock 39 110 347 minecraft:yellow_terracotta
fill 39 110 348 39 113 348 minecraft:honeycomb_block
fill 39 110 350 39 110 351 minecraft:honeycomb_block
setblock 39 110 352 minecraft:yellow_terracotta
setblock 39 110 362 minecraft:yellow_terracotta
fill 39 110 363 39 113 363 minecraft:honeycomb_block
fill 40 110 324 40 110 325 minecraft:honeycomb_block
setblock 40 110 326 minecraft:yellow_terracotta
fill 40 110 327 40 112 328 minecraft:honeycomb_block
setblock 40 110 336 minecraft:yellow_terracotta
fill 40 110 337 40 112 337 minecraft:honeycomb_block
setblock 40 110 341 minecraft:yellow_terracotta
fill 40 110 342 40 113 342 minecraft:honeycomb_block
setblock 40 110 346 minecraft:yellow_terracotta
fill 40 110 347 40 113 347 minecraft:honeycomb_block
setblock 40 110 351 minecraft:yellow_terracotta
fill 40 110 352 40 113 352 minecraft:honeycomb_block
setblock 40 110 356 minecraft:yellow_terracotta
setblock 40 110 357 minecraft:honeycomb_block
setblock 40 110 361 minecraft:yellow_terracotta
fill 40 110 362 40 111 362 minecraft:honeycomb_block
setblock 41 110 325 minecraft:yellow_terracotta
fill 41 110 326 42 113 326 minecraft:honeycomb_block
setblock 41 110 329 minecraft:honeycomb_block
setblock 41 110 330 minecraft:yellow_terracotta
fill 41 110 331 41 113 331 minecraft:honeycomb_block
setblock 41 110 335 minecraft:yellow_terracotta
fill 41 110 336 41 113 336 minecraft:honeycomb_block
setblock 41 110 340 minecraft:yellow_terracotta
fill 41 110 341 41 113 341 minecraft:honeycomb_block
setblock 41 110 345 minecraft:yellow_terracotta
fill 41 110 346 41 113 346 minecraft:honeycomb_block
setblock 41 110 350 minecraft:yellow_terracotta
fill 41 110 351 41 113 351 minecraft:honeycomb_block
setblock 41 110 355 minecraft:yellow_terracotta
fill 41 110 356 41 111 356 minecraft:honeycomb_block
setblock 41 110 360 minecraft:yellow_terracotta
fill 41 110 361 41 112 361 minecraft:honeycomb_block
fill 42 110 323 42 132 324 minecraft:honeycomb_block
setblock 42 110 325 minecraft:yellow_concrete
fill 42 110 340 42 221 340 minecraft:honeycomb_block
fill 0 111 349 0 135 349 minecraft:honeycomb_block
setblock 1 111 324 minecraft:yellow_terracotta
fill 1 111 325 1 113 325 minecraft:honeycomb_block
setblock 1 111 329 minecraft:yellow_terracotta
fill 1 111 330 1 113 330 minecraft:honeycomb_block
setblock 1 111 334 minecraft:yellow_terracotta
fill 1 111 335 1 113 335 minecraft:honeycomb_block
setblock 1 111 339 minecraft:yellow_terracotta
fill 1 111 340 1 113 340 minecraft:honeycomb_block
setblock 1 111 344 minecraft:yellow_terracotta
fill 1 111 345 1 113 345 minecraft:honeycomb_block
setblock 1 111 349 minecraft:yellow_terracotta
fill 1 111 350 1 113 350 minecraft:honeycomb_block
setblock 2 111 323 minecraft:yellow_terracotta
fill 2 111 324 5 111 324 minecraft:honeycomb_block
setblock 2 111 328 minecraft:yellow_terracotta
fill 2 111 329 2 113 329 minecraft:honeycomb_block
setblock 2 111 338 minecraft:yellow_terracotta
fill 2 111 339 2 112 339 minecraft:honeycomb_block
setblock 2 111 343 minecraft:yellow_terracotta
fill 2 111 344 2 113 344 minecraft:honeycomb_block
setblock 2 111 348 minecraft:yellow_terracotta
setblock 2 111 363 minecraft:yellow_terracotta
fill 3 111 323 6 111 323 minecraft:honeycomb_block
setblock 3 111 342 minecraft:yellow_terracotta
setblock 3 111 343 minecraft:honeycomb_block
fill 3 111 363 6 111 363 minecraft:honeycomb_block
setblock 5 111 322 minecraft:orange_terracotta
setblock 6 111 324 minecraft:yellow_terracotta
setblock 7 111 323 minecraft:yellow_terracotta
fill 7 111 324 7 113 324 minecraft:honeycomb_block
setblock 7 111 363 minecraft:yellow_terracotta
fill 8 111 323 8 113 323 minecraft:honeycomb_block
fill 8 111 363 8 112 363 minecraft:honeycomb_block
setblock 9 111 325 minecraft:honeycomb_block
setblock 9 111 364 minecraft:orange_terracotta
setblock 10 111 325 minecraft:yellow_terracotta
setblock 11 111 324 minecraft:yellow_terracotta
fill 11 111 325 14 111 325 minecraft:honeycomb_block
setblock 12 111 323 minecraft:yellow_terracotta
fill 12 111 324 12 113 324 minecraft:honeycomb_block
setblock 12 111 363 minecraft:yellow_terracotta
fill 13 111 323 13 113 323 minecraft:honeycomb_block
setblock 13 111 326 minecraft:honeycomb_block
fill 13 111 337 13 112 337 minecraft:orange_stained_glass
fill 13 111 338 13 113 338 minecraft:honeycomb_block
fill 13 111 339 13 114 343 minecraft:orange_stained_glass
fill 13 111 344 13 113 344 minecraft:honeycomb_block
fill 13 111 345 13 112 345 minecraft:orange_stained_glass
setblock 13 111 362 minecraft:yellow_terracotta
fill 13 111 363 13 113 363 minecraft:honeycomb_block
setblock 14 111 326 minecraft:yellow_terracotta
fill 14 111 335 14 112 336 minecraft:orange_stained_glass
fill 14 111 346 14 112 347 minecraft:orange_stained_glass
setblock 14 111 361 minecraft:yellow_terracotta
fill 14 111 362 14 113 362 minecraft:honeycomb_block
setblock 15 111 325 minecraft:yellow_terracotta
fill 15 111 326 15 113 326 minecraft:honeycomb_block
fill 15 111 334 15 113 335 minecraft:orange_stained_glass
fill 15 111 347 15 113 348 minecraft:orange_stained_glass
fill 15 111 361 15 112 361 minecraft:honeycomb_block
setblock 16 111 324 minecraft:yellow_terracotta
fill 16 111 325 16 113 325 minecraft:honeycomb_block
fill 16 111 333 17 113 333 minecraft:orange_stained_glass
fill 16 111 334 16 115 334 minecraft:honeycomb_block
fill 16 111 348 16 115 348 minecraft:honeycomb_block
fill 16 111 349 17 113 349 minecraft:orange_stained_glass
setblock 17 111 323 minecraft:yellow_terracotta
fill 17 111 324 17 113 324 minecraft:honeycomb_block
fill 17 111 326 18 111 326 minecraft:honeycomb_block
fill 17 111 332 18 112 332 minecraft:orange_stained_glass
fill 17 111 350 18 112 350 minecraft:orange_stained_glass
setblock 17 111 363 minecraft:yellow_terracotta
fill 18 111 323 18 113 323 minecraft:honeycomb_block
setblock 18 111 362 minecraft:yellow_terracotta
fill 18 111 363 18 113 363 minecraft:honeycomb_block
setblock 19 111 326 minecraft:yellow_terracotta
fill 19 111 331 19 112 331 minecraft:orange_stained_glass
fill 19 111 351 19 112 351 minecraft:orange_stained_glass
setblock 19 111 361 minecraft:yellow_terracotta
fill 19 111 362 19 113 362 minecraft:honeycomb_block
setblock 20 111 325 minecraft:yellow_terracotta
fill 20 111 331 20 113 331 minecraft:honeycomb_block
fill 20 111 351 20 113 351 minecraft:honeycomb_block
fill 20 111 361 20 112 361 minecraft:honeycomb_block
setblock 21 111 324 minecraft:yellow_terracotta
fill 21 111 325 21 112 325 minecraft:honeycomb_block
fill 21 111 331 25 114 331 minecraft:orange_stained_glass
fill 21 111 351 25 114 351 minecraft:orange_stained_glass
fill 21 111 363 21 111 364 minecraft:honeycomb_block
setblock 22 111 323 minecraft:yellow_terracotta
fill 22 111 324 22 113 324 minecraft:honeycomb_block
setblock 22 111 363 minecraft:yellow_terracotta
fill 23 111 323 23 113 323 minecraft:honeycomb_block
setblock 23 111 362 minecraft:yellow_terracotta
fill 23 111 363 23 113 363 minecraft:honeycomb_block
fill 24 111 362 24 112 362 minecraft:honeycomb_block
setblock 25 111 324 minecraft:honeycomb_block
fill 26 111 331 26 113 331 minecraft:honeycomb_block
fill 26 111 351 26 113 351 minecraft:honeycomb_block
setblock 27 111 323 minecraft:yellow_terracotta
fill 27 111 331 27 112 331 minecraft:orange_stained_glass
fill 27 111 351 27 112 351 minecraft:orange_stained_glass
setblock 27 111 363 minecraft:yellow_terracotta
fill 28 111 323 31 111 323 minecraft:honeycomb_block
fill 28 111 332 29 112 332 minecraft:orange_stained_glass
fill 28 111 350 29 112 350 minecraft:orange_stained_glass
setblock 28 111 362 minecraft:yellow_terracotta
fill 28 111 363 28 113 363 minecraft:honeycomb_block
fill 29 111 333 30 113 333 minecraft:orange_stained_glass
fill 29 111 349 30 113 349 minecraft:orange_stained_glass
setblock 29 111 362 minecraft:honeycomb_block
fill 30 111 334 30 115 334 minecraft:honeycomb_block
fill 30 111 348 30 115 348 minecraft:honeycomb_block
fill 31 111 334 31 113 335 minecraft:orange_stained_glass
fill 31 111 347 31 113 348 minecraft:orange_stained_glass
setblock 32 111 323 minecraft:yellow_terracotta
fill 32 111 324 32 113 324 minecraft:honeycomb_block
fill 32 111 335 32 112 336 minecraft:orange_stained_glass
fill 32 111 339 32 112 339 minecraft:brown_terracotta
fill 32 111 342 32 112 342 minecraft:brown_terracotta
fill 32 111 346 32 112 347 minecraft:orange_stained_glass
setblock 32 111 363 minecraft:yellow_terracotta
fill 33 111 323 33 113 323 minecraft:honeycomb_block
fill 33 111 337 33 112 337 minecraft:orange_stained_glass
fill 33 111 338 33 113 338 minecraft:honeycomb_block
fill 33 111 339 33 114 343 minecraft:orange_stained_glass
fill 33 111 344 33 113 344 minecraft:honeycomb_block
fill 33 111 345 33 112 345 minecraft:orange_stained_glass
setblock 33 111 362 minecraft:yellow_terracotta
fill 33 111 363 33 113 363 minecraft:honeycomb_block
fill 34 111 337 34 112 337 minecraft:brown_terracotta
setblock 34 111 361 minecraft:yellow_terracotta
fill 34 111 362 34 113 362 minecraft:honeycomb_block
setblock 35 111 324 minecraft:honeycomb_block
fill 35 111 345 36 112 345 minecraft:brown_terracotta
setblock 35 111 361 minecraft:honeycomb_block
fill 36 111 324 36 111 325 minecraft:yellow_terracotta
fill 36 111 360 36 112 360 minecraft:yellow_terracotta
setblock 37 111 323 minecraft:yellow_terracotta
fill 37 111 324 37 113 324 minecraft:honeycomb_block
fill 37 111 325 37 112 326 minecraft:yellow_terracotta
setblock 37 111 343 minecraft:yellow_terracotta
fill 37 111 344 37 112 344 minecraft:honeycomb_block
setblock 37 111 347 minecraft:honeycomb_block
fill 37 111 359 37 113 359 minecraft:yellow_terracotta
setblock 37 111 363 minecraft:yellow_terracotta
fill 38 111 323 38 113 323 minecraft:honeycomb_block
fill 38 111 325 38 112 325 minecraft:yellow_terracotta
fill 38 111 337 38 112 337 minecraft:brown_terracotta
setblock 38 111 342 minecraft:yellow_terracotta
fill 38 111 343 38 113 343 minecraft:honeycomb_block
setblock 38 111 346 minecraft:honeycomb_block
setblock 38 111 347 minecraft:yellow_terracotta
fill 38 111 348 38 113 348 minecraft:honeycomb_block
fill 38 111 360 38 111 362 minecraft:yellow_terracotta
fill 38 111 363 38 113 363 minecraft:honeycomb_block
setblock 39 111 341 minecraft:yellow_terracotta
fill 39 111 342 39 113 342 minecraft:honeycomb_block
setblock 39 111 346 minecraft:yellow_terracotta
fill 39 111 347 39 113 347 minecraft:honeycomb_block
setblock 39 111 350 minecraft:honeycomb_block
setblock 39 111 351 minecraft:yellow_terracotta
setblock 39 111 352 minecraft:honeycomb_block
fill 39 111 362 39 112 362 minecraft:honeycomb_block
setblock 40 111 324 minecraft:honeycomb_block
setblock 40 111 325 minecraft:yellow_terracotta
fill 40 111 326 40 113 326 minecraft:honeycomb_block
setblock 40 111 335 minecraft:yellow_terracotta
setblock 40 111 336 minecraft:honeycomb_block
setblock 40 111 340 minecraft:yellow_terracotta
fill 40 111 341 40 113 341 minecraft:honeycomb_block
setblock 40 111 345 minecraft:yellow_terracotta
fill 40 111 346 40 113 346 minecraft:honeycomb_block
setblock 40 111 350 minecraft:yellow_terracotta
fill 40 111 351 40 113 351 minecraft:honeycomb_block
setblock 40 111 360 minecraft:yellow_terracotta
setblock 40 111 361 minecraft:honeycomb_block
setblock 41 111 324 minecraft:yellow_terracotta
fill 41 111 325 42 113 325 minecraft:honeycomb_block
setblock 41 111 329 minecraft:yellow_terracotta
fill 41 111 330 41 113 330 minecraft:honeycomb_block
setblock 41 111 334 minecraft:yellow_terracotta
fill 41 111 335 41 113 335 minecraft:honeycomb_block
setblock 41 111 339 minecraft:yellow_terracotta
fill 41 111 340 41 113 340 minecraft:honeycomb_block
fill 41 111 344 42 111 344 minecraft:yellow_terracotta
fill 41 111 345 41 113 345 minecraft:honeycomb_block
setblock 41 111 349 minecraft:yellow_terracotta
fill 41 111 350 41 113 350 minecraft:honeycomb_block
setblock 41 111 354 minecraft:yellow_terracotta
fill 41 111 355 41 112 355 minecraft:honeycomb_block
setblock 41 111 359 minecraft:yellow_terracotta
fill 41 111 360 41 112 360 minecraft:honeycomb_block
setblock 41 111 364 minecraft:yellow_concrete
setblock 42 111 350 minecraft:yellow_concrete
fill 42 111 364 42 308 364 minecraft:honeycomb_block
setblock 0 112 344 minecraft:yellow_terracotta
setblock 1 112 323 minecraft:yellow_terracotta
fill 1 112 324 4 112 324 minecraft:honeycomb_block
setblock 1 112 328 minecraft:yellow_terracotta
fill 1 112 329 1 113 329 minecraft:honeycomb_block
setblock 1 112 333 minecraft:yellow_terracotta
fill 1 112 334 1 113 334 minecraft:honeycomb_block
setblock 1 112 338 minecraft:yellow_terracotta
fill 1 112 339 1 113 339 minecraft:honeycomb_block
setblock 1 112 343 minecraft:yellow_terracotta
fill 1 112 344 1 113 344 minecraft:honeycomb_block
setblock 1 112 348 minecraft:yellow_terracotta
fill 1 112 349 1 113 349 minecraft:honeycomb_block
setblock 1 112 363 minecraft:yellow_terracotta
fill 2 112 323 5 112 323 minecraft:honeycomb_block
setblock 2 112 327 minecraft:yellow_terracotta
fill 2 112 328 2 113 328 minecraft:honeycomb_block
setblock 2 112 338 minecraft:honeycomb_block
setblock 2 112 342 minecraft:yellow_terracotta
fill 2 112 343 2 113 343 minecraft:honeycomb_block
setblock 2 112 347 minecraft:yellow_terracotta
setblock 2 112 348 minecraft:honeycomb_block
setblock 2 112 363 minecraft:honeycomb_block
setblock 3 112 325 minecraft:light[level=15]
setblock 3 112 333 minecraft:light[level=15]
setblock 3 112 341 minecraft:light[level=15]
setblock 3 112 349 minecraft:light[level=15]
setblock 3 112 357 minecraft:light[level=15]
fill 5 112 322 5 149 322 minecraft:honeycomb_block
setblock 5 112 324 minecraft:yellow_terracotta
setblock 6 112 323 minecraft:yellow_terracotta
fill 6 112 324 6 113 324 minecraft:honeycomb_block
fill 7 112 323 7 113 323 minecraft:honeycomb_block
setblock 7 112 363 minecraft:honey_block
setblock 9 112 325 minecraft:yellow_terracotta
fill 9 112 364 9 118 364 minecraft:honeycomb_block
setblock 10 112 324 minecraft:yellow_terracotta
fill 10 112 325 13 112 325 minecraft:honeycomb_block
setblock 11 112 323 minecraft:yellow_terracotta
fill 11 112 324 11 113 324 minecraft:honeycomb_block
setblock 11 112 333 minecraft:light[level=15]
setblock 11 112 341 minecraft:light[level=15]
setblock 11 112 349 minecraft:light[level=15]
setblock 11 112 357 minecraft:light[level=15]
setblock 11 112 363 minecraft:yellow_terracotta
fill 12 112 323 12 113 323 minecraft:honeycomb_block
setblock 12 112 362 minecraft:yellow_terracotta
fill 12 112 363 12 113 363 minecraft:honeycomb_block
setblock 13 112 326 minecraft:yellow_terracotta
fill 13 112 362 13 113 362 minecraft:honeycomb_block
setblock 14 112 325 minecraft:yellow_terracotta
fill 14 112 326 14 113 326 minecraft:honeycomb_block
fill 14 112 337 14 115 337 minecraft:orange_stained_glass
fill 14 112 345 14 115 345 minecraft:orange_stained_glass
setblock 15 112 324 minecraft:yellow_terracotta
fill 15 112 325 15 113 325 minecraft:honeycomb_block
setblock 16 112 323 minecraft:yellow_terracotta
fill 16 112 324 16 113 324 minecraft:honeycomb_block
setblock 16 112 363 minecraft:yellow_terracotta
fill 17 112 323 17 113 323 minecraft:honeycomb_block
setblock 17 112 326 minecraft:honeycomb_block
setblock 17 112 362 minecraft:yellow_terracotta
fill 17 112 363 17 113 363 minecraft:honeycomb_block
setblock 18 112 326 minecraft:yellow_terracotta
setblock 18 112 361 minecraft:yellow_terracotta
fill 18 112 362 18 113 362 minecraft:honeycomb_block
setblock 19 112 325 minecraft:yellow_terracotta
fill 19 112 332 19 115 332 minecraft:orange_stained_glass
setblock 19 112 333 minecraft:light[level=15]
setblock 19 112 341 minecraft:light[level=15]
setblock 19 112 349 minecraft:light[level=15]
fill 19 112 350 19 115 350 minecraft:orange_stained_glass
setblock 19 112 357 minecraft:light[level=15]
setblock 19 112 361 minecraft:honeycomb_block
setblock 20 112 324 minecraft:yellow_terracotta
fill 20 112 325 20 113 325 minecraft:honeycomb_block
setblock 21 112 323 minecraft:yellow_terracotta
fill 21 112 324 21 113 324 minecraft:honeycomb_block
setblock 21 112 363 minecraft:yellow_terracotta
fill 21 112 364 21 142 364 minecraft:honeycomb_block
fill 22 112 323 22 113 323 minecraft:honeycomb_block
setblock 22 112 362 minecraft:yellow_terracotta
fill 22 112 363 22 113 363 minecraft:honeycomb_block
fill 23 112 362 23 113 362 minecraft:honeycomb_block
setblock 26 112 323 minecraft:yellow_terracotta
setblock 26 112 363 minecraft:yellow_terracotta
fill 27 112 323 30 112 323 minecraft:honeycomb_block
setblock 27 112 325 minecraft:light[level=15]
fill 27 112 332 27 115 332 minecraft:orange_stained_glass
setblock 27 112 333 minecraft:light[level=15]
setblock 27 112 341 minecraft:light[level=15]
setblock 27 112 349 minecraft:light[level=15]
fill 27 112 350 27 115 350 minecraft:orange_stained_glass
setblock 27 112 357 minecraft:light[level=15]
fill 27 112 363 27 113 363 minecraft:honeycomb_block
setblock 31 112 323 minecraft:yellow_terracotta
fill 31 112 340 31 112 341 minecraft:brown_terracotta
setblock 31 112 363 minecraft:yellow_terracotta
fill 32 112 323 32 113 323 minecraft:honeycomb_block
fill 32 112 337 32 115 337 minecraft:orange_stained_glass
setblock 32 112 338 minecraft:brown_terracotta
setblock 32 112 343 minecraft:brown_terracotta
fill 32 112 345 32 115 345 minecraft:orange_stained_glass
fill 32 112 359 32 113 359 minecraft:yellow_terracotta
setblock 32 112 362 minecraft:yellow_terracotta
fill 32 112 363 32 113 363 minecraft:honeycomb_block
fill 33 112 358 33 113 358 minecraft:yellow_terracotta
fill 33 112 360 33 113 360 minecraft:yellow_terracotta
fill 33 112 362 33 113 362 minecraft:honeycomb_block
setblock 34 112 345 minecraft:brown_terracotta
fill 34 112 359 34 113 359 minecraft:yellow_terracotta
setblock 35 112 324 minecraft:yellow_terracotta
setblock 35 112 325 minecraft:light[level=15]
setblock 35 112 333 minecraft:light[level=15]
fill 35 112 336 37 112 336 minecraft:brown_terracotta
setblock 35 112 349 minecraft:light[level=15]
setblock 35 112 357 minecraft:light[level=15]
setblock 36 112 323 minecraft:yellow_terracotta
fill 36 112 324 36 113 324 minecraft:honeycomb_block
fill 36 112 325 36 112 327 minecraft:yellow_terracotta
fill 36 112 358 36 113 359 minecraft:yellow_terracotta
setblock 36 112 363 minecraft:yellow_terracotta
fill 37 112 323 37 113 323 minecraft:honeycomb_block
fill 37 112 327 38 113 327 minecraft:yellow_terracotta
setblock 37 112 343 minecraft:brown_terracotta
setblock 37 112 347 minecraft:yellow_terracotta
fill 37 112 358 38 113 358 minecraft:yellow_terracotta
fill 37 112 361 37 112 362 minecraft:yellow_terracotta
fill 37 112 363 37 113 363 minecraft:honeycomb_block
fill 38 112 326 38 113 326 minecraft:yellow_terracotta
setblock 38 112 340 minecraft:brown_terracotta
setblock 38 112 341 minecraft:yellow_terracotta
fill 38 112 342 38 113 342 minecraft:honeycomb_block
setblock 38 112 346 minecraft:yellow_terracotta
fill 38 112 347 38 113 347 minecraft:honeycomb_block
fill 38 112 359 38 112 360 minecraft:yellow_terracotta
setblock 38 112 362 minecraft:honeycomb_block
fill 39 112 337 39 112 338 minecraft:brown_terracotta
setblock 39 112 340 minecraft:yellow_terracotta
fill 39 112 341 39 113 341 minecraft:honeycomb_block
setblock 39 112 345 minecraft:yellow_terracotta
fill 39 112 346 39 113 346 minecraft:honeycomb_block
setblock 39 112 350 minecraft:yellow_terracotta
fill 39 112 351 39 113 351 minecraft:honeycomb_block
setblock 40 112 324 minecraft:yellow_terracotta
fill 40 112 325 40 113 325 minecraft:honeycomb_block
setblock 40 112 339 minecraft:yellow_terracotta
fill 40 112 340 40 113 340 minecraft:honeycomb_block
setblock 40 112 344 minecraft:yellow_terracotta
fill 40 112 345 40 113 345 minecraft:honeycomb_block
setblock 40 112 349 minecraft:yellow_terracotta
fill 40 112 350 40 113 350 minecraft:honeycomb_block
fill 41 112 322 41 308 322 minecraft:honeycomb_block
setblock 41 112 323 minecraft:yellow_terracotta
fill 41 112 324 41 113 324 minecraft:honeycomb_block
setblock 41 112 328 minecraft:yellow_terracotta
fill 41 112 329 41 113 329 minecraft:honeycomb_block
setblock 41 112 333 minecraft:yellow_terracotta
fill 41 112 334 41 113 334 minecraft:honeycomb_block
setblock 41 112 338 minecraft:yellow_terracotta
fill 41 112 339 41 113 339 minecraft:honeycomb_block
setblock 41 112 343 minecraft:yellow_terracotta
fill 41 112 344 42 113 344 minecraft:honeycomb_block
setblock 41 112 348 minecraft:yellow_terracotta
fill 41 112 349 41 113 349 minecraft:honeycomb_block
setblock 41 112 353 minecraft:yellow_terracotta
fill 41 112 354 41 113 354 minecraft:honeycomb_block
setblock 41 112 363 minecraft:yellow_terracotta
fill 41 112 364 41 130 364 minecraft:honeycomb_block
fill 42 112 350 42 142 350 minecraft:honeycomb_block
fill 0 113 344 0 146 344 minecraft:honeycomb_block
fill 1 113 323 3 113 324 minecraft:honeycomb_block
setblock 1 113 327 minecraft:yellow_terracotta
setblock 1 113 328 minecraft:honeycomb_block
setblock 1 113 332 minecraft:yellow_terracotta
setblock 1 113 333 minecraft:honeycomb_block
setblock 1 113 337 minecraft:yellow_terracotta
setblock 1 113 338 minecraft:honeycomb_block
setblock 1 113 342 minecraft:yellow_terracotta
setblock 1 113 343 minecraft:honeycomb_block
setblock 1 113 347 minecraft:yellow_terracotta
setblock 1 113 348 minecraft:honeycomb_block
setblock 1 113 356 minecraft:honey_block
setblock 2 113 326 minecraft:yellow_terracotta
setblock 2 113 327 minecraft:honeycomb_block
setblock 2 113 342 minecraft:honeycomb_block
setblock 2 113 346 minecraft:yellow_terracotta
setblock 2 113 347 minecraft:honeycomb_block
setblock 4 113 323 minecraft:honeycomb_block
setblock 4 113 324 minecraft:yellow_terracotta
setblock 5 113 323 minecraft:yellow_terracotta
setblock 5 113 324 minecraft:honeycomb_block
setblock 6 113 323 minecraft:honeycomb_block
setblock 9 113 324 minecraft:yellow_terracotta
fill 9 113 325 12 113 325 minecraft:honeycomb_block
setblock 10 113 323 minecraft:yellow_terracotta
setblock 10 113 324 minecraft:honeycomb_block
setblock 10 113 363 minecraft:yellow_terracotta
setblock 11 113 323 minecraft:honeycomb_block
setblock 11 113 363 minecraft:honeycomb_block
setblock 12 113 326 minecraft:yellow_terracotta
setblock 12 113 362 minecraft:honeycomb_block
setblock 13 113 325 minecraft:yellow_terracotta
setblock 13 113 326 minecraft:honeycomb_block
setblock 14 113 324 minecraft:yellow_terracotta
setblock 14 113 325 minecraft:honeycomb_block
fill 14 113 336 14 114 336 minecraft:orange_stained_glass
fill 14 113 346 14 114 346 minecraft:orange_stained_glass
setblock 15 113 323 minecraft:yellow_terracotta
setblock 15 113 324 minecraft:honeycomb_block
setblock 15 113 363 minecraft:yellow_terracotta
setblock 16 113 323 minecraft:honeycomb_block
setblock 16 113 362 minecraft:yellow_terracotta
setblock 16 113 363 minecraft:honeycomb_block
setblock 17 113 326 minecraft:yellow_terracotta
setblock 17 113 361 minecraft:yellow_terracotta
setblock 17 113 362 minecraft:honeycomb_block
setblock 18 113 325 minecraft:yellow_terracotta
fill 18 113 332 18 114 332 minecraft:orange_stained_glass
fill 18 113 350 18 114 350 minecraft:orange_stained_glass
setblock 18 113 361 minecraft:honeycomb_block
setblock 19 113 324 minecraft:yellow_terracotta
setblock 19 113 325 minecraft:honeycomb_block
fill 19 113 363 19 113 364 minecraft:honeycomb_block
setblock 20 113 323 minecraft:yellow_terracotta
setblock 20 113 324 minecraft:honeycomb_block
setblock 20 113 363 minecraft:yellow_terracotta
fill 20 113 364 20 149 364 minecraft:honeycomb_block
setblock 21 113 323 minecraft:honeycomb_block
setblock 21 113 362 minecraft:yellow_terracotta
setblock 21 113 363 minecraft:honeycomb_block
setblock 22 113 362 minecraft:honeycomb_block
setblock 25 113 323 minecraft:yellow_terracotta
setblock 25 113 363 minecraft:yellow_terracotta
fill 26 113 323 29 113 323 minecraft:honeycomb_block
setblock 26 113 363 minecraft:honeycomb_block
fill 28 113 332 28 114 332 minecraft:orange_stained_glass
fill 28 113 350 28 114 350 minecraft:orange_stained_glass
setblock 30 113 323 minecraft:yellow_terracotta
setblock 30 113 363 minecraft:yellow_terracotta
setblock 31 113 323 minecraft:honeycomb_block
setblock 31 113 363 minecraft:honeycomb_block
fill 32 113 336 32 114 336 minecraft:orange_stained_glass
fill 32 113 346 32 114 346 minecraft:orange_stained_glass
setblock 32 113 358 minecraft:yellow_terracotta
setblock 32 113 360 minecraft:yellow_terracotta
setblock 32 113 362 minecraft:honeycomb_block
setblock 34 113 324 minecraft:yellow_terracotta
setblock 34 113 358 minecraft:yellow_terracotta
setblock 34 113 360 minecraft:yellow_terracotta
setblock 35 113 323 minecraft:yellow_terracotta
setblock 35 113 324 minecraft:honeycomb_block
setblock 35 113 363 minecraft:yellow_terracotta
setblock 36 113 323 minecraft:honeycomb_block
fill 36 113 326 36 113 328 minecraft:yellow_terracotta
setblock 36 113 341 minecraft:yellow_terracotta
fill 36 113 357 38 113 357 minecraft:yellow_terracotta
setblock 36 113 362 minecraft:yellow_terracotta
setblock 36 113 363 minecraft:honeycomb_block
setblock 37 113 325 minecraft:honey_block
setblock 37 113 326 minecraft:yellow_terracotta
fill 37 113 328 37 113 329 minecraft:yellow_terracotta
setblock 37 113 356 minecraft:yellow_terracotta
setblock 37 113 360 minecraft:honey_block
setblock 37 113 362 minecraft:honeycomb_block
setblock 38 113 328 minecraft:yellow_terracotta
setblock 38 113 345 minecraft:yellow_terracotta
setblock 38 113 346 minecraft:honeycomb_block
setblock 38 113 349 minecraft:honeycomb_block
setblock 38 113 359 minecraft:yellow_terracotta
setblock 39 113 324 minecraft:yellow_terracotta
setblock 39 113 340 minecraft:honeycomb_block
setblock 39 113 344 minecraft:yellow_terracotta
setblock 39 113 345 minecraft:honeycomb_block
setblock 39 113 349 minecraft:yellow_terracotta
setblock 39 113 350 minecraft:honeycomb_block
setblock 40 113 323 minecraft:yellow_terracotta
setblock 40 113 324 minecraft:honeycomb_block
setblock 40 113 327 minecraft:honeycomb_block
setblock 40 113 328 minecraft:yellow_terracotta
setblock 40 113 338 minecraft:yellow_terracotta
setblock 40 113 339 minecraft:honeycomb_block
setblock 40 113 343 minecraft:yellow_terracotta
setblock 40 113 344 minecraft:honeycomb_block
setblock 40 113 348 minecraft:yellow_terracotta
setblock 40 113 349 minecraft:honeycomb_block
setblock 40 113 363 minecraft:yellow_terracotta
setblock 41 113 323 minecraft:honeycomb_block
setblock 41 113 327 minecraft:yellow_terracotta
setblock 41 113 328 minecraft:honeycomb_block
setblock 41 113 332 minecraft:yellow_terracotta
setblock 41 113 333 minecraft:honeycomb_block
setblock 41 113 337 minecraft:yellow_terracotta
setblock 41 113 338 minecraft:honeycomb_block
setblock 41 113 342 minecraft:yellow_terracotta
setblock 41 113 343 minecraft:honeycomb_block
setblock 41 113 347 minecraft:yellow_terracotta
setblock 41 113 348 minecraft:honeycomb_block
setblock 41 113 352 minecraft:yellow_terracotta
setblock 41 113 353 minecraft:honeycomb_block
setblock 41 113 355 minecraft:honey_block
setblock 41 113 363 minecraft:honeycomb_block
setblock 0 114 339 minecraft:orange_terracotta
setblock 0 114 352 minecraft:yellow_concrete
fill 14 114 338 14 116 338 minecraft:orange_stained_glass
fill 14 114 344 14 116 344 minecraft:orange_stained_glass
fill 15 114 335 15 115 336 minecraft:orange_stained_glass
fill 15 114 346 15 115 347 minecraft:orange_stained_glass
fill 17 114 333 18 115 333 minecraft:orange_stained_glass
fill 17 114 349 18 115 349 minecraft:orange_stained_glass
fill 19 114 364 19 308 364 minecraft:honeycomb_block
fill 20 114 332 20 116 332 minecraft:orange_stained_glass
fill 20 114 350 20 116 350 minecraft:orange_stained_glass
fill 26 114 332 26 116 332 minecraft:orange_stained_glass
fill 26 114 350 26 116 350 minecraft:orange_stained_glass
fill 28 114 333 29 115 333 minecraft:orange_stained_glass
fill 28 114 349 29 115 349 minecraft:orange_stained_glass
fill 31 114 335 31 115 336 minecraft:orange_stained_glass
fill 31 114 346 31 115 347 minecraft:orange_stained_glass
fill 32 114 338 32 116 338 minecraft:orange_stained_glass
fill 32 114 344 32 116 344 minecraft:orange_stained_glass
fill 42 114 325 42 165 326 minecraft:honeycomb_block
fill 42 114 344 42 123 344 minecraft:honeycomb_block
fill 0 115 339 0 169 339 minecraft:honeycomb_block
fill 0 115 352 0 294 352 minecraft:honeycomb_block
fill 13 115 341 14 115 341 minecraft:orange_stained_glass
fill 14 115 339 14 116 340 minecraft:orange_stained_glass
fill 14 115 342 14 116 343 minecraft:orange_stained_glass
fill 15 115 337 15 116 337 minecraft:orange_stained_glass
fill 15 115 345 15 116 345 minecraft:orange_stained_glass
fill 16 115 335 16 116 335 minecraft:orange_stained_glass
fill 16 115 347 16 116 347 minecraft:orange_stained_glass
fill 17 115 334 17 116 334 minecraft:orange_stained_glass
fill 17 115 348 17 116 348 minecraft:orange_stained_glass
fill 19 115 333 19 116 333 minecraft:orange_stained_glass
fill 19 115 349 19 116 349 minecraft:orange_stained_glass
fill 21 115 332 25 116 332 minecraft:orange_stained_glass
fill 21 115 350 25 116 350 minecraft:orange_stained_glass
setblock 23 115 331 minecraft:orange_stained_glass
setblock 23 115 351 minecraft:orange_stained_glass
fill 27 115 333 27 116 333 minecraft:orange_stained_glass
fill 27 115 349 27 116 349 minecraft:orange_stained_glass
fill 29 115 334 29 116 334 minecraft:orange_stained_glass
fill 29 115 348 29 116 348 minecraft:orange_stained_glass
fill 30 115 335 30 116 335 minecraft:orange_stained_glass
fill 30 115 347 30 116 347 minecraft:orange_stained_glass
fill 31 115 337 31 116 337 minecraft:orange_stained_glass
fill 31 115 345 31 116 345 minecraft:orange_stained_glass
fill 32 115 339 32 116 343 minecraft:orange_stained_glass
setblock 33 115 341 minecraft:orange_stained_glass
setblock 40 115 364 minecraft:yellow_terracotta
setblock 3 116 325 minecraft:light[level=12]
setblock 3 116 332 minecraft:light[level=12]
setblock 3 116 339 minecraft:light[level=12]
setblock 3 116 346 minecraft:light[level=12]
setblock 3 116 353 minecraft:light[level=12]
setblock 3 116 360 minecraft:light[level=12]
setblock 10 116 325 minecraft:light[level=12]
setblock 10 116 332 minecraft:light[level=12]
setblock 10 116 339 minecraft:light[level=12]
setblock 10 116 346 minecraft:light[level=12]
setblock 10 116 353 minecraft:light[level=12]
setblock 10 116 360 minecraft:light[level=12]
setblock 14 116 341 minecraft:orange_stained_glass
fill 15 116 336 16 116 336 minecraft:orange_stained_glass
fill 15 116 338 15 117 338 minecraft:orange_stained_glass
fill 15 116 339 15 117 339 minecraft:honeycomb_block
fill 15 116 343 15 117 343 minecraft:honeycomb_block
fill 15 116 344 15 117 344 minecraft:orange_stained_glass
fill 15 116 346 16 116 346 minecraft:orange_stained_glass
setblock 17 116 325 minecraft:light[level=12]
setblock 17 116 332 minecraft:light[level=12]
fill 17 116 335 17 117 335 minecraft:honeycomb_block
setblock 17 116 339 minecraft:light[level=12]
setblock 17 116 346 minecraft:light[level=12]
fill 17 116 347 17 117 347 minecraft:honeycomb_block
setblock 17 116 353 minecraft:light[level=12]
setblock 17 116 360 minecraft:light[level=12]
fill 18 116 333 18 116 334 minecraft:orange_stained_glass
fill 18 116 348 18 116 349 minecraft:orange_stained_glass
fill 20 116 333 20 117 333 minecraft:orange_stained_glass
fill 20 116 349 20 117 349 minecraft:orange_stained_glass
fill 21 116 333 21 117 333 minecraft:honeycomb_block
fill 21 116 349 21 117 349 minecraft:honeycomb_block
setblock 24 116 325 minecraft:light[level=12]
setblock 24 116 339 minecraft:light[level=12]
setblock 24 116 346 minecraft:light[level=12]
setblock 24 116 353 minecraft:light[level=12]
setblock 24 116 360 minecraft:light[level=12]
fill 25 116 333 25 117 333 minecraft:honeycomb_block
fill 25 116 349 25 117 349 minecraft:honeycomb_block
fill 26 116 333 26 117 333 minecraft:orange_stained_glass
fill 26 116 349 26 117 349 minecraft:orange_stained_glass
fill 28 116 333 28 116 334 minecraft:orange_stained_glass
fill 28 116 348 28 116 349 minecraft:orange_stained_glass
fill 29 116 335 29 117 335 minecraft:honeycomb_block
fill 29 116 347 29 117 347 minecraft:honeycomb_block
fill 30 116 336 31 116 336 minecraft:orange_stained_glass
fill 30 116 346 31 116 346 minecraft:orange_stained_glass
setblock 31 116 325 minecraft:light[level=12]
setblock 31 116 332 minecraft:light[level=12]
fill 31 116 338 31 117 338 minecraft:orange_stained_glass
fill 31 116 339 31 117 339 minecraft:honeycomb_block
fill 31 116 343 31 117 343 minecraft:honeycomb_block
fill 31 116 344 31 117 344 minecraft:orange_stained_glass
setblock 31 116 353 minecraft:light[level=12]
setblock 31 116 360 minecraft:light[level=12]
setblock 38 116 325 minecraft:light[level=12]
setblock 38 116 332 minecraft:light[level=12]
setblock 38 116 339 minecraft:light[level=12]
setblock 38 116 346 minecraft:light[level=12]
setblock 38 116 353 minecraft:light[level=12]
setblock 38 116 360 minecraft:light[level=12]
fill 40 116 364 40 183 364 minecraft:honeycomb_block
setblock 0 117 343 minecraft:yellow_terracotta
fill 15 117 340 15 117 342 minecraft:orange_stained_glass
fill 16 117 336 16 117 338 minecraft:orange_stained_glass
fill 16 117 344 16 117 346 minecraft:orange_stained_glass
fill 17 117 336 17 118 336 minecraft:orange_stained_glass
fill 17 117 346 17 118 346 minecraft:orange_stained_glass
fill 18 117 334 18 117 335 minecraft:orange_stained_glass
fill 18 117 347 18 117 348 minecraft:orange_stained_glass
fill 19 117 334 20 117 334 minecraft:orange_stained_glass
fill 19 117 348 20 117 348 minecraft:orange_stained_glass
fill 22 117 333 24 117 333 minecraft:orange_stained_glass
fill 22 117 349 24 117 349 minecraft:orange_stained_glass
fill 26 117 334 28 117 334 minecraft:orange_stained_glass
fill 26 117 348 28 117 348 minecraft:orange_stained_glass
fill 28 117 335 28 118 335 minecraft:orange_stained_glass
fill 28 117 347 28 118 347 minecraft:orange_stained_glass
fill 29 117 336 30 117 336 minecraft:orange_stained_glass
fill 29 117 346 30 117 346 minecraft:orange_stained_glass
fill 30 117 337 30 117 338 minecraft:orange_stained_glass
fill 30 117 344 30 117 345 minecraft:orange_stained_glass
fill 31 117 340 31 117 342 minecraft:orange_stained_glass
fill 0 118 343 0 144 343 minecraft:honeycomb_block
fill 15 118 341 16 118 341 minecraft:orange_stained_glass
fill 16 118 338 17 118 338 minecraft:orange_stained_glass
setblock 16 118 339 minecraft:honeycomb_block
setblock 16 118 340 minecraft:orange_stained_glass
setblock 16 118 342 minecraft:orange_stained_glass
setblock 16 118 343 minecraft:honeycomb_block
fill 16 118 344 17 118 344 minecraft:orange_stained_glass
setblock 17 118 337 minecraft:orange_stained_glass
setblock 17 118 345 minecraft:orange_stained_glass
fill 18 118 335 20 118 335 minecraft:orange_stained_glass
setblock 18 118 336 minecraft:honeycomb_block
setblock 18 118 346 minecraft:honeycomb_block
fill 18 118 347 20 118 347 minecraft:orange_stained_glass
setblock 20 118 334 minecraft:orange_stained_glass
setblock 20 118 348 minecraft:orange_stained_glass
setblock 21 118 334 minecraft:honeycomb_block
setblock 21 118 348 minecraft:honeycomb_block
fill 22 118 334 24 118 334 minecraft:orange_stained_glass
fill 22 118 348 24 118 348 minecraft:orange_stained_glass
setblock 23 118 333 minecraft:orange_stained_glass
setblock 23 118 349 minecraft:orange_stained_glass
setblock 25 118 334 minecraft:honeycomb_block
setblock 25 118 348 minecraft:honeycomb_block
fill 26 118 334 26 118 335 minecraft:orange_stained_glass
fill 26 118 347 26 118 348 minecraft:orange_stained_glass
setblock 27 118 335 minecraft:orange_stained_glass
setblock 27 118 347 minecraft:orange_stained_glass
setblock 28 118 336 minecraft:honeycomb_block
schedule function dropper:buildpart/72_4 1t
