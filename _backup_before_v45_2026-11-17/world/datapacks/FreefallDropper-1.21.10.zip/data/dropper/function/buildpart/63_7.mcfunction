setblock 144 214 292 minecraft:light[level=12]
setblock 144 214 299 minecraft:light[level=12]
setblock 144 214 306 minecraft:light[level=12]
setblock 144 214 313 minecraft:light[level=12]
setblock 151 214 278 minecraft:light[level=12]
setblock 151 214 285 minecraft:light[level=12]
setblock 151 214 292 minecraft:light[level=12]
setblock 151 214 299 minecraft:light[level=12]
setblock 151 214 306 minecraft:light[level=12]
setblock 151 214 313 minecraft:light[level=12]
setblock 157 214 317 minecraft:white_concrete
setblock 158 214 278 minecraft:light[level=12]
setblock 158 214 285 minecraft:light[level=12]
setblock 158 214 292 minecraft:light[level=12]
setblock 158 214 299 minecraft:light[level=12]
setblock 158 214 306 minecraft:light[level=12]
setblock 158 214 313 minecraft:light[level=12]
fill 158 214 317 158 244 317 minecraft:packed_ice
setblock 159 214 317 minecraft:light_blue_concrete
fill 160 214 317 162 241 317 minecraft:packed_ice
setblock 165 214 278 minecraft:light[level=12]
setblock 165 214 285 minecraft:light[level=12]
setblock 165 214 292 minecraft:light[level=12]
setblock 165 214 299 minecraft:light[level=12]
setblock 165 214 306 minecraft:light[level=12]
setblock 165 214 313 minecraft:light[level=12]
setblock 172 214 278 minecraft:light[level=12]
setblock 172 214 285 minecraft:light[level=12]
setblock 172 214 292 minecraft:light[level=12]
setblock 172 214 299 minecraft:light[level=12]
setblock 172 214 306 minecraft:light[level=12]
setblock 172 214 313 minecraft:light[level=12]
setblock 176 214 275 minecraft:light_blue_concrete
setblock 179 214 278 minecraft:light[level=12]
setblock 179 214 285 minecraft:light[level=12]
fill 179 214 291 179 215 291 minecraft:packed_ice
setblock 179 214 292 minecraft:light[level=12]
setblock 179 214 299 minecraft:light[level=12]
setblock 179 214 306 minecraft:light[level=12]
setblock 179 214 313 minecraft:light[level=12]
fill 180 214 290 180 215 290 minecraft:packed_ice
fill 180 214 292 180 215 292 minecraft:packed_ice
fill 181 214 291 181 215 291 minecraft:packed_ice
setblock 183 214 298 minecraft:white_concrete
fill 141 215 310 141 244 310 minecraft:packed_ice
fill 141 215 312 141 240 312 minecraft:packed_ice
fill 152 215 317 155 237 317 minecraft:packed_ice
setblock 156 215 317 minecraft:white_concrete
fill 157 215 317 157 241 317 minecraft:packed_ice
fill 159 215 317 159 231 317 minecraft:packed_ice
fill 176 215 275 176 244 275 minecraft:packed_ice
fill 183 215 298 183 244 298 minecraft:packed_ice
fill 156 216 317 156 244 317 minecraft:packed_ice
fill 178 216 275 178 244 275 minecraft:packed_ice
setblock 179 216 275 minecraft:white_concrete
fill 180 216 275 182 244 275 minecraft:packed_ice
fill 183 216 280 183 232 281 minecraft:packed_ice
setblock 183 216 282 minecraft:light_blue_concrete
fill 183 216 283 183 240 283 minecraft:packed_ice
fill 141 217 302 141 241 302 minecraft:packed_ice
setblock 141 217 303 minecraft:light_blue_concrete
fill 154 217 290 154 219 294 minecraft:blue_ice
fill 155 217 288 155 219 291 minecraft:blue_ice
fill 155 217 292 160 217 292 minecraft:packed_ice
fill 155 217 293 155 219 296 minecraft:blue_ice
fill 156 217 286 156 219 287 minecraft:blue_ice
fill 156 217 288 161 217 291 minecraft:packed_ice
fill 156 217 293 161 217 296 minecraft:packed_ice
fill 156 217 297 156 219 298 minecraft:blue_ice
fill 157 217 285 157 218 286 minecraft:blue_ice
fill 157 217 287 171 218 287 minecraft:packed_ice
fill 157 217 297 171 218 297 minecraft:packed_ice
fill 157 217 298 157 218 299 minecraft:blue_ice
setblock 158 217 275 minecraft:packed_ice
fill 158 217 284 158 218 285 minecraft:blue_ice
fill 158 217 286 170 218 286 minecraft:packed_ice
fill 158 217 298 170 218 298 minecraft:packed_ice
fill 158 217 299 158 218 300 minecraft:blue_ice
setblock 159 217 275 minecraft:light_blue_concrete
fill 159 217 284 159 219 284 minecraft:blue_ice
fill 159 217 285 169 218 285 minecraft:packed_ice
fill 159 217 299 169 218 299 minecraft:packed_ice
fill 159 217 300 159 218 300 minecraft:blue_ice
fill 160 217 275 160 244 275 minecraft:packed_ice
fill 160 217 283 163 219 283 minecraft:blue_ice
fill 160 217 284 168 218 284 minecraft:packed_ice
fill 160 217 300 168 218 300 minecraft:packed_ice
fill 160 217 301 163 219 301 minecraft:blue_ice
fill 162 217 282 166 219 282 minecraft:blue_ice
fill 162 217 288 163 217 289 minecraft:packed_ice
fill 162 217 295 163 217 296 minecraft:packed_ice
fill 162 217 302 166 219 302 minecraft:blue_ice
fill 164 217 283 164 218 283 minecraft:packed_ice
fill 164 217 288 172 217 288 minecraft:packed_ice
fill 164 217 296 172 217 296 minecraft:packed_ice
fill 164 217 301 164 218 301 minecraft:packed_ice
fill 165 217 275 166 225 275 minecraft:packed_ice
fill 165 217 283 168 219 283 minecraft:blue_ice
fill 165 217 289 172 217 289 minecraft:packed_ice
fill 165 217 295 172 217 295 minecraft:packed_ice
fill 165 217 301 168 219 301 minecraft:blue_ice
setblock 167 217 275 minecraft:white_concrete
fill 167 217 290 172 217 291 minecraft:packed_ice
fill 167 217 293 172 217 294 minecraft:packed_ice
fill 168 217 292 173 217 292 minecraft:packed_ice
fill 169 217 284 170 219 284 minecraft:blue_ice
fill 169 217 300 170 218 300 minecraft:blue_ice
fill 170 217 285 171 218 285 minecraft:blue_ice
fill 170 217 299 171 218 299 minecraft:blue_ice
fill 171 217 286 172 218 286 minecraft:blue_ice
fill 171 217 298 172 218 298 minecraft:blue_ice
fill 172 217 287 172 218 287 minecraft:blue_ice
fill 172 217 297 172 218 297 minecraft:blue_ice
fill 173 217 288 173 219 291 minecraft:blue_ice
fill 173 217 293 173 219 296 minecraft:blue_ice
fill 174 217 290 174 219 294 minecraft:blue_ice
fill 177 217 317 178 244 317 minecraft:packed_ice
fill 179 217 275 179 244 275 minecraft:packed_ice
setblock 179 217 317 minecraft:white_concrete
fill 180 217 317 181 244 317 minecraft:packed_ice
setblock 183 217 278 minecraft:light_blue_concrete
fill 183 217 282 183 242 282 minecraft:packed_ice
fill 183 217 300 183 230 305 minecraft:packed_ice
setblock 183 217 306 minecraft:white_concrete
fill 183 217 307 183 244 307 minecraft:packed_ice
fill 141 218 303 141 244 303 minecraft:packed_ice
fill 142 218 276 142 218 277 minecraft:snow_block
setblock 142 218 278 minecraft:packed_ice
fill 142 218 279 142 218 281 minecraft:snow_block
setblock 142 218 282 minecraft:packed_ice
fill 142 218 283 142 218 285 minecraft:snow_block
setblock 142 218 286 minecraft:packed_ice
fill 142 218 287 142 218 289 minecraft:snow_block
setblock 142 218 290 minecraft:packed_ice
fill 142 218 291 142 218 293 minecraft:snow_block
setblock 142 218 294 minecraft:packed_ice
fill 142 218 295 142 218 297 minecraft:snow_block
setblock 142 218 298 minecraft:packed_ice
fill 142 218 299 142 218 301 minecraft:snow_block
setblock 142 218 302 minecraft:packed_ice
fill 142 218 303 142 218 305 minecraft:snow_block
setblock 142 218 306 minecraft:packed_ice
fill 142 218 307 142 218 309 minecraft:snow_block
setblock 142 218 310 minecraft:packed_ice
fill 142 218 311 142 218 313 minecraft:snow_block
setblock 142 218 314 minecraft:packed_ice
fill 142 218 315 143 218 316 minecraft:snow_block
setblock 143 218 276 minecraft:snow_block
setblock 143 218 277 minecraft:packed_ice
fill 143 218 278 143 218 280 minecraft:snow_block
setblock 143 218 281 minecraft:packed_ice
fill 143 218 282 143 218 284 minecraft:snow_block
setblock 143 218 285 minecraft:packed_ice
fill 143 218 286 143 218 288 minecraft:snow_block
setblock 143 218 289 minecraft:packed_ice
fill 143 218 290 143 218 292 minecraft:snow_block
setblock 143 218 293 minecraft:packed_ice
fill 143 218 294 143 218 296 minecraft:snow_block
setblock 143 218 297 minecraft:packed_ice
fill 143 218 298 143 218 300 minecraft:snow_block
setblock 143 218 301 minecraft:packed_ice
fill 143 218 302 143 218 304 minecraft:snow_block
setblock 143 218 305 minecraft:packed_ice
fill 143 218 306 143 218 308 minecraft:snow_block
setblock 143 218 309 minecraft:packed_ice
fill 143 218 310 143 218 312 minecraft:snow_block
setblock 143 218 313 minecraft:packed_ice
fill 143 218 314 145 218 314 minecraft:snow_block
setblock 144 218 276 minecraft:packed_ice
fill 144 218 277 144 218 279 minecraft:snow_block
setblock 144 218 280 minecraft:packed_ice
fill 144 218 281 144 218 283 minecraft:snow_block
setblock 144 218 284 minecraft:packed_ice
fill 144 218 285 144 218 287 minecraft:snow_block
setblock 144 218 288 minecraft:packed_ice
fill 144 218 289 144 218 291 minecraft:snow_block
setblock 144 218 292 minecraft:packed_ice
fill 144 218 293 144 218 295 minecraft:snow_block
setblock 144 218 296 minecraft:packed_ice
fill 144 218 297 144 218 299 minecraft:snow_block
setblock 144 218 300 minecraft:packed_ice
fill 144 218 301 144 218 303 minecraft:snow_block
setblock 144 218 304 minecraft:packed_ice
fill 144 218 305 144 218 307 minecraft:snow_block
setblock 144 218 308 minecraft:packed_ice
fill 144 218 309 144 218 311 minecraft:snow_block
setblock 144 218 312 minecraft:packed_ice
fill 144 218 313 146 218 313 minecraft:snow_block
setblock 144 218 315 minecraft:snow_block
setblock 144 218 316 minecraft:packed_ice
fill 145 218 276 145 218 278 minecraft:snow_block
setblock 145 218 279 minecraft:packed_ice
fill 145 218 280 145 218 282 minecraft:snow_block
setblock 145 218 283 minecraft:packed_ice
fill 145 218 284 145 218 286 minecraft:snow_block
setblock 145 218 287 minecraft:packed_ice
fill 145 218 288 145 218 290 minecraft:snow_block
setblock 145 218 291 minecraft:packed_ice
fill 145 218 292 145 218 294 minecraft:snow_block
setblock 145 218 295 minecraft:packed_ice
fill 145 218 296 145 218 298 minecraft:snow_block
setblock 145 218 299 minecraft:packed_ice
fill 145 218 300 145 218 302 minecraft:snow_block
setblock 145 218 303 minecraft:packed_ice
fill 145 218 304 145 218 306 minecraft:snow_block
setblock 145 218 307 minecraft:packed_ice
fill 145 218 308 145 218 310 minecraft:snow_block
setblock 145 218 311 minecraft:packed_ice
fill 145 218 312 147 218 312 minecraft:snow_block
setblock 145 218 315 minecraft:packed_ice
fill 145 218 316 147 218 316 minecraft:snow_block
fill 146 218 276 146 218 277 minecraft:snow_block
setblock 146 218 278 minecraft:packed_ice
fill 146 218 279 146 218 281 minecraft:snow_block
setblock 146 218 282 minecraft:packed_ice
fill 146 218 283 146 218 285 minecraft:snow_block
setblock 146 218 286 minecraft:packed_ice
fill 146 218 287 146 218 289 minecraft:snow_block
setblock 146 218 290 minecraft:packed_ice
fill 146 218 291 146 218 293 minecraft:snow_block
setblock 146 218 294 minecraft:packed_ice
fill 146 218 295 146 218 297 minecraft:snow_block
setblock 146 218 298 minecraft:packed_ice
fill 146 218 299 146 218 301 minecraft:snow_block
setblock 146 218 302 minecraft:packed_ice
fill 146 218 303 146 218 305 minecraft:snow_block
setblock 146 218 306 minecraft:packed_ice
fill 146 218 307 146 218 309 minecraft:snow_block
setblock 146 218 310 minecraft:packed_ice
fill 146 218 311 148 218 311 minecraft:snow_block
setblock 146 218 314 minecraft:packed_ice
fill 146 218 315 148 218 315 minecraft:snow_block
setblock 147 218 276 minecraft:snow_block
setblock 147 218 277 minecraft:packed_ice
fill 147 218 278 147 218 280 minecraft:snow_block
setblock 147 218 281 minecraft:packed_ice
fill 147 218 282 147 218 284 minecraft:snow_block
setblock 147 218 285 minecraft:packed_ice
fill 147 218 286 147 218 288 minecraft:snow_block
setblock 147 218 289 minecraft:packed_ice
fill 147 218 290 147 218 292 minecraft:snow_block
setblock 147 218 293 minecraft:packed_ice
fill 147 218 294 147 218 296 minecraft:snow_block
setblock 147 218 297 minecraft:packed_ice
fill 147 218 298 147 218 300 minecraft:snow_block
setblock 147 218 301 minecraft:packed_ice
fill 147 218 302 147 218 304 minecraft:snow_block
setblock 147 218 305 minecraft:packed_ice
fill 147 218 306 147 218 308 minecraft:snow_block
setblock 147 218 309 minecraft:packed_ice
fill 147 218 310 149 218 310 minecraft:snow_block
setblock 147 218 313 minecraft:packed_ice
fill 147 218 314 149 218 314 minecraft:snow_block
setblock 148 218 276 minecraft:packed_ice
fill 148 218 277 148 218 279 minecraft:snow_block
setblock 148 218 280 minecraft:packed_ice
fill 148 218 281 148 218 283 minecraft:snow_block
setblock 148 218 284 minecraft:packed_ice
fill 148 218 285 148 218 287 minecraft:snow_block
setblock 148 218 288 minecraft:packed_ice
fill 148 218 289 148 218 291 minecraft:snow_block
setblock 148 218 292 minecraft:packed_ice
fill 148 218 293 148 218 295 minecraft:snow_block
setblock 148 218 296 minecraft:packed_ice
fill 148 218 297 148 218 299 minecraft:snow_block
setblock 148 218 300 minecraft:packed_ice
fill 148 218 301 148 218 303 minecraft:snow_block
setblock 148 218 304 minecraft:packed_ice
fill 148 218 305 148 218 307 minecraft:snow_block
setblock 148 218 308 minecraft:packed_ice
fill 148 218 309 150 218 309 minecraft:snow_block
setblock 148 218 312 minecraft:packed_ice
fill 148 218 313 150 218 313 minecraft:snow_block
setblock 148 218 316 minecraft:packed_ice
fill 149 218 276 149 218 278 minecraft:snow_block
setblock 149 218 279 minecraft:packed_ice
fill 149 218 280 149 218 282 minecraft:snow_block
setblock 149 218 283 minecraft:packed_ice
fill 149 218 284 149 218 286 minecraft:snow_block
setblock 149 218 287 minecraft:packed_ice
fill 149 218 288 149 218 290 minecraft:snow_block
setblock 149 218 291 minecraft:packed_ice
fill 149 218 292 149 218 294 minecraft:snow_block
setblock 149 218 295 minecraft:packed_ice
fill 149 218 296 149 218 298 minecraft:snow_block
setblock 149 218 299 minecraft:packed_ice
fill 149 218 300 149 218 302 minecraft:snow_block
setblock 149 218 303 minecraft:packed_ice
fill 149 218 304 149 218 306 minecraft:snow_block
setblock 149 218 307 minecraft:packed_ice
fill 149 218 308 151 218 308 minecraft:snow_block
setblock 149 218 311 minecraft:packed_ice
fill 149 218 312 151 218 312 minecraft:snow_block
setblock 149 218 315 minecraft:packed_ice
fill 149 218 316 151 218 316 minecraft:snow_block
fill 150 218 276 150 218 277 minecraft:snow_block
setblock 150 218 278 minecraft:packed_ice
fill 150 218 279 150 218 281 minecraft:snow_block
setblock 150 218 282 minecraft:packed_ice
fill 150 218 283 150 218 285 minecraft:snow_block
setblock 150 218 286 minecraft:packed_ice
fill 150 218 287 150 218 289 minecraft:snow_block
setblock 150 218 290 minecraft:packed_ice
fill 150 218 291 150 218 293 minecraft:snow_block
setblock 150 218 294 minecraft:packed_ice
fill 150 218 295 150 218 297 minecraft:snow_block
setblock 150 218 298 minecraft:packed_ice
fill 150 218 299 150 218 301 minecraft:snow_block
setblock 150 218 302 minecraft:packed_ice
fill 150 218 303 150 218 305 minecraft:snow_block
setblock 150 218 306 minecraft:packed_ice
fill 150 218 307 152 218 307 minecraft:snow_block
setblock 150 218 310 minecraft:packed_ice
fill 150 218 311 152 218 311 minecraft:snow_block
setblock 150 218 314 minecraft:packed_ice
fill 150 218 315 152 218 315 minecraft:snow_block
setblock 151 218 276 minecraft:snow_block
setblock 151 218 277 minecraft:packed_ice
fill 151 218 278 151 218 280 minecraft:snow_block
setblock 151 218 281 minecraft:packed_ice
fill 151 218 282 151 218 284 minecraft:snow_block
setblock 151 218 285 minecraft:packed_ice
fill 151 218 286 151 218 288 minecraft:snow_block
setblock 151 218 289 minecraft:packed_ice
fill 151 218 290 151 218 292 minecraft:snow_block
setblock 151 218 293 minecraft:packed_ice
fill 151 218 294 151 218 296 minecraft:snow_block
setblock 151 218 297 minecraft:packed_ice
fill 151 218 298 151 218 300 minecraft:snow_block
setblock 151 218 301 minecraft:packed_ice
fill 151 218 302 151 218 304 minecraft:snow_block
setblock 151 218 305 minecraft:packed_ice
fill 151 218 306 153 218 306 minecraft:snow_block
setblock 151 218 309 minecraft:packed_ice
fill 151 218 310 153 218 310 minecraft:snow_block
setblock 151 218 313 minecraft:packed_ice
fill 151 218 314 153 218 314 minecraft:snow_block
setblock 152 218 276 minecraft:packed_ice
fill 152 218 277 152 218 279 minecraft:snow_block
setblock 152 218 280 minecraft:packed_ice
fill 152 218 281 152 218 283 minecraft:snow_block
setblock 152 218 284 minecraft:packed_ice
fill 152 218 285 152 218 287 minecraft:snow_block
setblock 152 218 288 minecraft:packed_ice
fill 152 218 289 152 218 291 minecraft:snow_block
setblock 152 218 292 minecraft:packed_ice
fill 152 218 293 152 218 295 minecraft:snow_block
setblock 152 218 296 minecraft:packed_ice
fill 152 218 297 152 218 299 minecraft:snow_block
setblock 152 218 300 minecraft:packed_ice
fill 152 218 301 152 218 303 minecraft:snow_block
setblock 152 218 304 minecraft:packed_ice
fill 152 218 305 154 218 305 minecraft:snow_block
setblock 152 218 308 minecraft:packed_ice
fill 152 218 309 154 218 309 minecraft:snow_block
setblock 152 218 312 minecraft:packed_ice
fill 152 218 313 154 218 313 minecraft:snow_block
setblock 152 218 316 minecraft:packed_ice
fill 153 218 276 153 218 278 minecraft:snow_block
setblock 153 218 279 minecraft:packed_ice
fill 153 218 280 153 218 282 minecraft:snow_block
setblock 153 218 283 minecraft:packed_ice
fill 153 218 284 153 218 286 minecraft:snow_block
setblock 153 218 287 minecraft:packed_ice
fill 153 218 288 153 218 290 minecraft:snow_block
setblock 153 218 291 minecraft:packed_ice
fill 153 218 292 153 218 294 minecraft:snow_block
setblock 153 218 295 minecraft:packed_ice
fill 153 218 296 153 218 298 minecraft:snow_block
setblock 153 218 299 minecraft:packed_ice
fill 153 218 300 153 218 302 minecraft:snow_block
setblock 153 218 303 minecraft:packed_ice
fill 153 218 304 155 218 304 minecraft:snow_block
setblock 153 218 307 minecraft:packed_ice
fill 153 218 308 155 218 308 minecraft:snow_block
setblock 153 218 311 minecraft:packed_ice
fill 153 218 312 155 218 312 minecraft:snow_block
setblock 153 218 315 minecraft:packed_ice
fill 153 218 316 155 218 316 minecraft:snow_block
fill 154 218 276 154 218 277 minecraft:snow_block
setblock 154 218 278 minecraft:packed_ice
fill 154 218 279 154 218 281 minecraft:snow_block
setblock 154 218 282 minecraft:packed_ice
fill 154 218 283 154 218 285 minecraft:snow_block
setblock 154 218 286 minecraft:packed_ice
fill 154 218 287 154 218 288 minecraft:snow_block
setblock 154 218 289 minecraft:blue_ice
setblock 154 218 295 minecraft:blue_ice
fill 154 218 296 154 218 297 minecraft:snow_block
setblock 154 218 298 minecraft:packed_ice
fill 154 218 299 154 218 301 minecraft:snow_block
setblock 154 218 302 minecraft:packed_ice
fill 154 218 303 156 218 303 minecraft:snow_block
setblock 154 218 306 minecraft:packed_ice
fill 154 218 307 156 218 307 minecraft:snow_block
setblock 154 218 310 minecraft:packed_ice
fill 154 218 311 156 218 311 minecraft:snow_block
setblock 154 218 314 minecraft:packed_ice
fill 154 218 315 156 218 315 minecraft:snow_block
setblock 155 218 276 minecraft:snow_block
setblock 155 218 277 minecraft:packed_ice
fill 155 218 278 155 218 280 minecraft:snow_block
setblock 155 218 281 minecraft:packed_ice
fill 155 218 282 155 218 284 minecraft:snow_block
setblock 155 218 285 minecraft:packed_ice
setblock 155 218 286 minecraft:snow_block
setblock 155 218 287 minecraft:blue_ice
fill 155 218 292 159 218 292 minecraft:packed_ice
setblock 155 218 297 minecraft:blue_ice
fill 155 218 298 155 218 300 minecraft:snow_block
setblock 155 218 301 minecraft:packed_ice
fill 155 218 302 157 218 302 minecraft:snow_block
setblock 155 218 305 minecraft:packed_ice
fill 155 218 306 157 218 306 minecraft:snow_block
setblock 155 218 309 minecraft:packed_ice
fill 155 218 310 157 218 310 minecraft:snow_block
setblock 155 218 313 minecraft:packed_ice
fill 155 218 314 157 218 314 minecraft:snow_block
setblock 156 218 276 minecraft:packed_ice
fill 156 218 277 156 218 279 minecraft:snow_block
setblock 156 218 280 minecraft:packed_ice
fill 156 218 281 156 218 283 minecraft:snow_block
setblock 156 218 284 minecraft:packed_ice
setblock 156 218 285 minecraft:snow_block
fill 156 218 288 159 218 291 minecraft:packed_ice
fill 156 218 293 159 218 296 minecraft:packed_ice
setblock 156 218 299 minecraft:snow_block
setblock 156 218 300 minecraft:packed_ice
fill 156 218 301 158 218 301 minecraft:snow_block
setblock 156 218 304 minecraft:packed_ice
fill 156 218 305 158 218 305 minecraft:snow_block
setblock 156 218 308 minecraft:packed_ice
fill 156 218 309 158 218 309 minecraft:snow_block
setblock 156 218 312 minecraft:packed_ice
fill 156 218 313 158 218 313 minecraft:snow_block
setblock 156 218 316 minecraft:packed_ice
fill 157 218 276 157 218 278 minecraft:snow_block
setblock 157 218 279 minecraft:packed_ice
fill 157 218 280 157 218 282 minecraft:snow_block
setblock 157 218 283 minecraft:packed_ice
setblock 157 218 284 minecraft:snow_block
setblock 157 218 300 minecraft:snow_block
setblock 157 218 303 minecraft:packed_ice
fill 157 218 304 159 218 304 minecraft:snow_block
setblock 157 218 307 minecraft:packed_ice
fill 157 218 308 159 218 308 minecraft:snow_block
setblock 157 218 311 minecraft:packed_ice
fill 157 218 312 159 218 312 minecraft:snow_block
setblock 157 218 315 minecraft:packed_ice
fill 157 218 316 159 218 316 minecraft:snow_block
setblock 158 218 275 minecraft:light_blue_concrete
fill 158 218 276 158 218 277 minecraft:snow_block
setblock 158 218 278 minecraft:packed_ice
fill 158 218 279 158 218 281 minecraft:snow_block
setblock 158 218 282 minecraft:packed_ice
setblock 158 218 283 minecraft:snow_block
setblock 158 218 302 minecraft:packed_ice
fill 158 218 303 160 218 303 minecraft:snow_block
setblock 158 218 306 minecraft:packed_ice
fill 158 218 307 160 218 307 minecraft:snow_block
setblock 158 218 310 minecraft:packed_ice
fill 158 218 311 160 218 311 minecraft:snow_block
setblock 158 218 314 minecraft:packed_ice
fill 158 218 315 160 218 315 minecraft:snow_block
fill 159 218 275 159 244 275 minecraft:packed_ice
setblock 159 218 276 minecraft:snow_block
setblock 159 218 277 minecraft:packed_ice
fill 159 218 278 159 218 280 minecraft:snow_block
setblock 159 218 281 minecraft:packed_ice
fill 159 218 282 160 218 282 minecraft:snow_block
setblock 159 218 283 minecraft:blue_ice
setblock 159 218 301 minecraft:blue_ice
fill 159 218 302 160 218 302 minecraft:snow_block
setblock 159 218 305 minecraft:packed_ice
fill 159 218 306 161 218 306 minecraft:snow_block
setblock 159 218 309 minecraft:packed_ice
fill 159 218 310 161 218 310 minecraft:snow_block
setblock 159 218 313 minecraft:packed_ice
fill 159 218 314 161 218 314 minecraft:snow_block
setblock 160 218 276 minecraft:packed_ice
fill 160 218 277 160 218 279 minecraft:snow_block
setblock 160 218 280 minecraft:packed_ice
fill 160 218 281 162 218 281 minecraft:snow_block
fill 160 218 288 160 218 290 minecraft:packed_ice
fill 160 218 291 160 218 293 minecraft:sea_lantern
fill 160 218 294 160 218 296 minecraft:packed_ice
setblock 160 218 304 minecraft:packed_ice
fill 160 218 305 162 218 305 minecraft:snow_block
setblock 160 218 308 minecraft:packed_ice
fill 160 218 309 162 218 309 minecraft:snow_block
setblock 160 218 312 minecraft:packed_ice
fill 160 218 313 162 218 313 minecraft:snow_block
setblock 160 218 316 minecraft:packed_ice
fill 161 218 276 161 218 278 minecraft:snow_block
setblock 161 218 279 minecraft:packed_ice
fill 161 218 280 163 218 280 minecraft:snow_block
setblock 161 218 282 minecraft:blue_ice
fill 161 218 288 162 218 288 minecraft:packed_ice
fill 161 218 289 161 218 291 minecraft:sea_lantern
fill 161 218 293 161 218 295 minecraft:sea_lantern
fill 161 218 296 162 218 296 minecraft:packed_ice
setblock 161 218 302 minecraft:blue_ice
setblock 161 218 303 minecraft:packed_ice
fill 161 218 304 163 218 304 minecraft:snow_block
setblock 161 218 307 minecraft:packed_ice
fill 161 218 308 163 218 308 minecraft:snow_block
setblock 161 218 311 minecraft:packed_ice
fill 161 218 312 163 218 312 minecraft:snow_block
setblock 161 218 315 minecraft:packed_ice
fill 161 218 316 163 218 316 minecraft:snow_block
fill 162 218 276 162 218 277 minecraft:snow_block
setblock 162 218 278 minecraft:packed_ice
fill 162 218 279 164 218 279 minecraft:snow_block
fill 162 218 289 163 218 289 minecraft:sea_lantern
fill 162 218 295 163 218 295 minecraft:sea_lantern
fill 162 218 303 164 218 303 minecraft:snow_block
setblock 162 218 306 minecraft:packed_ice
fill 162 218 307 164 218 307 minecraft:snow_block
setblock 162 218 310 minecraft:packed_ice
fill 162 218 311 164 218 311 minecraft:snow_block
setblock 162 218 314 minecraft:packed_ice
fill 162 218 315 164 218 315 minecraft:snow_block
setblock 163 218 276 minecraft:snow_block
setblock 163 218 277 minecraft:packed_ice
fill 163 218 278 165 218 278 minecraft:snow_block
setblock 163 218 281 minecraft:packed_ice
fill 163 218 288 165 218 288 minecraft:sea_lantern
fill 163 218 296 165 218 296 minecraft:sea_lantern
setblock 163 218 305 minecraft:packed_ice
fill 163 218 306 165 218 306 minecraft:snow_block
setblock 163 218 309 minecraft:packed_ice
fill 163 218 310 165 218 310 minecraft:snow_block
setblock 163 218 313 minecraft:packed_ice
fill 163 218 314 165 218 314 minecraft:snow_block
setblock 164 218 276 minecraft:packed_ice
fill 164 218 277 166 218 277 minecraft:snow_block
setblock 164 218 280 minecraft:packed_ice
fill 164 218 281 166 218 281 minecraft:snow_block
setblock 164 218 304 minecraft:packed_ice
fill 164 218 305 166 218 305 minecraft:snow_block
setblock 164 218 308 minecraft:packed_ice
fill 164 218 309 166 218 309 minecraft:snow_block
setblock 164 218 312 minecraft:packed_ice
fill 164 218 313 166 218 313 minecraft:snow_block
setblock 164 218 316 minecraft:packed_ice
fill 165 218 276 167 218 276 minecraft:snow_block
setblock 165 218 279 minecraft:packed_ice
fill 165 218 280 167 218 280 minecraft:snow_block
fill 165 218 289 167 218 289 minecraft:sea_lantern
fill 165 218 295 167 218 295 minecraft:sea_lantern
setblock 165 218 303 minecraft:packed_ice
fill 165 218 304 167 218 304 minecraft:snow_block
setblock 165 218 307 minecraft:packed_ice
fill 165 218 308 167 218 308 minecraft:snow_block
setblock 165 218 311 minecraft:packed_ice
fill 165 218 312 167 218 312 minecraft:snow_block
setblock 165 218 315 minecraft:packed_ice
fill 165 218 316 167 218 316 minecraft:snow_block
setblock 166 218 278 minecraft:packed_ice
fill 166 218 279 168 218 279 minecraft:snow_block
fill 166 218 288 172 218 288 minecraft:packed_ice
fill 166 218 296 172 218 296 minecraft:packed_ice
fill 166 218 303 168 218 303 minecraft:snow_block
setblock 166 218 306 minecraft:packed_ice
fill 166 218 307 168 218 307 minecraft:snow_block
setblock 166 218 310 minecraft:packed_ice
fill 166 218 311 168 218 311 minecraft:snow_block
setblock 166 218 314 minecraft:packed_ice
fill 166 218 315 168 218 315 minecraft:snow_block
fill 167 218 275 167 241 275 minecraft:packed_ice
setblock 167 218 277 minecraft:packed_ice
fill 167 218 278 169 218 278 minecraft:snow_block
setblock 167 218 281 minecraft:packed_ice
setblock 167 218 282 minecraft:blue_ice
fill 167 218 290 167 218 291 minecraft:sea_lantern
fill 167 218 293 167 218 294 minecraft:sea_lantern
setblock 167 218 302 minecraft:blue_ice
setblock 167 218 305 minecraft:packed_ice
fill 167 218 306 169 218 306 minecraft:snow_block
setblock 167 218 309 minecraft:packed_ice
fill 167 218 310 169 218 310 minecraft:snow_block
setblock 167 218 313 minecraft:packed_ice
fill 167 218 314 169 218 314 minecraft:snow_block
setblock 168 218 276 minecraft:packed_ice
fill 168 218 277 170 218 277 minecraft:snow_block
setblock 168 218 280 minecraft:packed_ice
fill 168 218 281 169 218 282 minecraft:snow_block
fill 168 218 289 172 218 290 minecraft:packed_ice
fill 168 218 291 168 218 293 minecraft:sea_lantern
fill 168 218 294 172 218 295 minecraft:packed_ice
fill 168 218 302 169 218 302 minecraft:snow_block
setblock 168 218 304 minecraft:packed_ice
fill 168 218 305 170 218 305 minecraft:snow_block
setblock 168 218 308 minecraft:packed_ice
fill 168 218 309 170 218 309 minecraft:snow_block
setblock 168 218 312 minecraft:packed_ice
fill 168 218 313 170 218 313 minecraft:snow_block
setblock 168 218 316 minecraft:packed_ice
fill 169 218 276 171 218 276 minecraft:snow_block
setblock 169 218 279 minecraft:packed_ice
fill 169 218 280 171 218 280 minecraft:snow_block
setblock 169 218 283 minecraft:blue_ice
fill 169 218 291 172 218 293 minecraft:packed_ice
setblock 169 218 301 minecraft:blue_ice
setblock 169 218 303 minecraft:packed_ice
fill 169 218 304 171 218 304 minecraft:snow_block
setblock 169 218 307 minecraft:packed_ice
fill 169 218 308 171 218 308 minecraft:snow_block
setblock 169 218 311 minecraft:packed_ice
fill 169 218 312 171 218 312 minecraft:snow_block
setblock 169 218 315 minecraft:packed_ice
fill 169 218 316 171 218 316 minecraft:snow_block
setblock 170 218 278 minecraft:packed_ice
fill 170 218 279 172 218 279 minecraft:snow_block
setblock 170 218 281 minecraft:snow_block
setblock 170 218 282 minecraft:packed_ice
fill 170 218 283 172 218 283 minecraft:snow_block
setblock 170 218 301 minecraft:snow_block
setblock 170 218 302 minecraft:packed_ice
fill 170 218 303 172 218 303 minecraft:snow_block
setblock 170 218 306 minecraft:packed_ice
fill 170 218 307 172 218 307 minecraft:snow_block
setblock 170 218 310 minecraft:packed_ice
fill 170 218 311 172 218 311 minecraft:snow_block
setblock 170 218 314 minecraft:packed_ice
fill 170 218 315 172 218 315 minecraft:snow_block
setblock 171 218 277 minecraft:packed_ice
fill 171 218 278 173 218 278 minecraft:snow_block
setblock 171 218 281 minecraft:packed_ice
fill 171 218 282 173 218 282 minecraft:snow_block
setblock 171 218 284 minecraft:snow_block
setblock 171 218 300 minecraft:snow_block
setblock 171 218 301 minecraft:packed_ice
fill 171 218 302 173 218 302 minecraft:snow_block
setblock 171 218 305 minecraft:packed_ice
fill 171 218 306 173 218 306 minecraft:snow_block
setblock 171 218 309 minecraft:packed_ice
fill 171 218 310 173 218 310 minecraft:snow_block
setblock 171 218 313 minecraft:packed_ice
fill 171 218 314 173 218 314 minecraft:snow_block
setblock 172 218 276 minecraft:packed_ice
fill 172 218 277 174 218 277 minecraft:snow_block
setblock 172 218 280 minecraft:packed_ice
fill 172 218 281 174 218 281 minecraft:snow_block
setblock 172 218 284 minecraft:packed_ice
fill 172 218 285 174 218 285 minecraft:snow_block
setblock 172 218 299 minecraft:snow_block
setblock 172 218 300 minecraft:packed_ice
fill 172 218 301 174 218 301 minecraft:snow_block
setblock 172 218 304 minecraft:packed_ice
fill 172 218 305 174 218 305 minecraft:snow_block
setblock 172 218 308 minecraft:packed_ice
fill 172 218 309 174 218 309 minecraft:snow_block
setblock 172 218 312 minecraft:packed_ice
fill 172 218 313 174 218 313 minecraft:snow_block
setblock 172 218 316 minecraft:packed_ice
fill 173 218 276 175 218 276 minecraft:snow_block
setblock 173 218 279 minecraft:packed_ice
fill 173 218 280 175 218 280 minecraft:snow_block
setblock 173 218 283 minecraft:packed_ice
fill 173 218 284 175 218 284 minecraft:snow_block
setblock 173 218 286 minecraft:snow_block
setblock 173 218 287 minecraft:blue_ice
setblock 173 218 292 minecraft:packed_ice
setblock 173 218 297 minecraft:blue_ice
setblock 173 218 298 minecraft:snow_block
setblock 173 218 299 minecraft:packed_ice
fill 173 218 300 175 218 300 minecraft:snow_block
setblock 173 218 303 minecraft:packed_ice
fill 173 218 304 175 218 304 minecraft:snow_block
setblock 173 218 307 minecraft:packed_ice
fill 173 218 308 175 218 308 minecraft:snow_block
setblock 173 218 311 minecraft:packed_ice
fill 173 218 312 175 218 312 minecraft:snow_block
setblock 173 218 315 minecraft:packed_ice
fill 173 218 316 175 218 316 minecraft:snow_block
setblock 174 218 275 minecraft:white_concrete
setblock 174 218 278 minecraft:packed_ice
fill 174 218 279 176 218 279 minecraft:snow_block
setblock 174 218 282 minecraft:packed_ice
fill 174 218 283 176 218 283 minecraft:snow_block
setblock 174 218 286 minecraft:packed_ice
fill 174 218 287 175 218 288 minecraft:snow_block
setblock 174 218 289 minecraft:blue_ice
setblock 174 218 295 minecraft:blue_ice
fill 174 218 296 174 218 297 minecraft:snow_block
setblock 174 218 298 minecraft:packed_ice
fill 174 218 299 176 218 299 minecraft:snow_block
setblock 174 218 302 minecraft:packed_ice
fill 174 218 303 176 218 303 minecraft:snow_block
setblock 174 218 306 minecraft:packed_ice
fill 174 218 307 176 218 307 minecraft:snow_block
setblock 174 218 310 minecraft:packed_ice
fill 174 218 311 176 218 311 minecraft:snow_block
setblock 174 218 314 minecraft:packed_ice
fill 174 218 315 176 218 315 minecraft:snow_block
setblock 175 218 277 minecraft:packed_ice
fill 175 218 278 177 218 278 minecraft:snow_block
setblock 175 218 281 minecraft:packed_ice
fill 175 218 282 177 218 282 minecraft:snow_block
setblock 175 218 285 minecraft:packed_ice
fill 175 218 286 177 218 286 minecraft:snow_block
setblock 175 218 289 minecraft:packed_ice
fill 175 218 290 175 218 292 minecraft:snow_block
setblock 175 218 293 minecraft:packed_ice
fill 175 218 294 175 218 296 minecraft:snow_block
setblock 175 218 297 minecraft:packed_ice
fill 175 218 298 177 218 298 minecraft:snow_block
setblock 175 218 301 minecraft:packed_ice
fill 175 218 302 177 218 302 minecraft:snow_block
setblock 175 218 305 minecraft:packed_ice
fill 175 218 306 177 218 306 minecraft:snow_block
setblock 175 218 309 minecraft:packed_ice
fill 175 218 310 177 218 310 minecraft:snow_block
setblock 175 218 313 minecraft:packed_ice
fill 175 218 314 177 218 314 minecraft:snow_block
setblock 176 218 276 minecraft:packed_ice
fill 176 218 277 178 218 277 minecraft:snow_block
setblock 176 218 280 minecraft:packed_ice
fill 176 218 281 178 218 281 minecraft:snow_block
setblock 176 218 284 minecraft:packed_ice
fill 176 218 285 178 218 285 minecraft:snow_block
setblock 176 218 287 minecraft:snow_block
setblock 176 218 288 minecraft:packed_ice
fill 176 218 289 176 218 291 minecraft:snow_block
setblock 176 218 292 minecraft:packed_ice
fill 176 218 293 176 218 295 minecraft:snow_block
setblock 176 218 296 minecraft:packed_ice
fill 176 218 297 178 218 297 minecraft:snow_block
setblock 176 218 300 minecraft:packed_ice
fill 176 218 301 178 218 301 minecraft:snow_block
setblock 176 218 304 minecraft:packed_ice
fill 176 218 305 178 218 305 minecraft:snow_block
setblock 176 218 308 minecraft:packed_ice
fill 176 218 309 178 218 309 minecraft:snow_block
setblock 176 218 312 minecraft:packed_ice
fill 176 218 313 178 218 313 minecraft:snow_block
setblock 176 218 316 minecraft:packed_ice
fill 177 218 276 179 218 276 minecraft:snow_block
setblock 177 218 279 minecraft:packed_ice
fill 177 218 280 179 218 280 minecraft:snow_block
setblock 177 218 283 minecraft:packed_ice
fill 177 218 284 179 218 284 minecraft:snow_block
setblock 177 218 287 minecraft:packed_ice
fill 177 218 288 177 218 290 minecraft:snow_block
setblock 177 218 291 minecraft:packed_ice
fill 177 218 292 177 218 294 minecraft:snow_block
setblock 177 218 295 minecraft:packed_ice
setblock 177 218 296 minecraft:snow_block
setblock 177 218 299 minecraft:packed_ice
fill 177 218 300 179 218 300 minecraft:snow_block
setblock 177 218 303 minecraft:packed_ice
fill 177 218 304 179 218 304 minecraft:snow_block
setblock 177 218 307 minecraft:packed_ice
fill 177 218 308 179 218 308 minecraft:snow_block
setblock 177 218 311 minecraft:packed_ice
fill 177 218 312 179 218 312 minecraft:snow_block
setblock 177 218 315 minecraft:packed_ice
fill 177 218 316 179 218 316 minecraft:snow_block
setblock 178 218 278 minecraft:packed_ice
fill 178 218 279 180 218 279 minecraft:snow_block
setblock 178 218 282 minecraft:packed_ice
fill 178 218 283 180 218 283 minecraft:snow_block
setblock 178 218 286 minecraft:packed_ice
fill 178 218 287 178 218 289 minecraft:snow_block
setblock 178 218 290 minecraft:packed_ice
fill 178 218 291 178 218 293 minecraft:snow_block
setblock 178 218 294 minecraft:packed_ice
setblock 178 218 295 minecraft:snow_block
fill 178 218 296 178 219 296 minecraft:packed_ice
setblock 178 218 298 minecraft:packed_ice
fill 178 218 299 180 218 299 minecraft:snow_block
setblock 178 218 302 minecraft:packed_ice
fill 178 218 303 180 218 303 minecraft:snow_block
setblock 178 218 306 minecraft:packed_ice
fill 178 218 307 180 218 307 minecraft:snow_block
setblock 178 218 310 minecraft:packed_ice
fill 178 218 311 180 218 311 minecraft:snow_block
setblock 178 218 314 minecraft:packed_ice
fill 178 218 315 180 218 315 minecraft:snow_block
setblock 179 218 277 minecraft:packed_ice
fill 179 218 278 181 218 278 minecraft:snow_block
setblock 179 218 281 minecraft:packed_ice
fill 179 218 282 181 218 282 minecraft:snow_block
setblock 179 218 285 minecraft:packed_ice
fill 179 218 286 179 218 288 minecraft:snow_block
setblock 179 218 289 minecraft:packed_ice
fill 179 218 290 179 218 292 minecraft:snow_block
setblock 179 218 293 minecraft:packed_ice
fill 179 218 294 181 218 294 minecraft:snow_block
fill 179 218 295 179 219 295 minecraft:packed_ice
fill 179 218 297 179 219 297 minecraft:packed_ice
fill 179 218 298 181 218 298 minecraft:snow_block
setblock 179 218 301 minecraft:packed_ice
fill 179 218 302 181 218 302 minecraft:snow_block
setblock 179 218 305 minecraft:packed_ice
fill 179 218 306 181 218 306 minecraft:snow_block
setblock 179 218 309 minecraft:packed_ice
fill 179 218 310 181 218 310 minecraft:snow_block
setblock 179 218 313 minecraft:packed_ice
fill 179 218 314 181 218 314 minecraft:snow_block
fill 179 218 317 179 226 317 minecraft:packed_ice
setblock 180 218 276 minecraft:packed_ice
fill 180 218 277 182 218 277 minecraft:snow_block
setblock 180 218 280 minecraft:packed_ice
fill 180 218 281 182 218 281 minecraft:snow_block
setblock 180 218 284 minecraft:packed_ice
fill 180 218 285 180 218 287 minecraft:snow_block
setblock 180 218 288 minecraft:packed_ice
fill 180 218 289 180 218 291 minecraft:snow_block
setblock 180 218 292 minecraft:packed_ice
fill 180 218 293 182 218 293 minecraft:snow_block
setblock 180 218 295 minecraft:snow_block
fill 180 218 296 180 219 296 minecraft:packed_ice
fill 180 218 297 182 218 297 minecraft:snow_block
setblock 180 218 300 minecraft:packed_ice
fill 180 218 301 182 218 301 minecraft:snow_block
setblock 180 218 304 minecraft:packed_ice
fill 180 218 305 182 218 305 minecraft:snow_block
setblock 180 218 308 minecraft:packed_ice
fill 180 218 309 182 218 309 minecraft:snow_block
setblock 180 218 312 minecraft:packed_ice
fill 180 218 313 182 218 313 minecraft:snow_block
setblock 180 218 316 minecraft:packed_ice
fill 181 218 276 182 218 276 minecraft:snow_block
setblock 181 218 279 minecraft:packed_ice
fill 181 218 280 182 218 280 minecraft:snow_block
setblock 181 218 283 minecraft:packed_ice
fill 181 218 284 181 218 286 minecraft:snow_block
setblock 181 218 287 minecraft:packed_ice
fill 181 218 288 181 218 290 minecraft:snow_block
setblock 181 218 291 minecraft:packed_ice
fill 181 218 292 182 218 292 minecraft:snow_block
setblock 181 218 295 minecraft:packed_ice
fill 181 218 296 182 218 296 minecraft:snow_block
setblock 181 218 299 minecraft:packed_ice
fill 181 218 300 182 218 300 minecraft:snow_block
setblock 181 218 303 minecraft:packed_ice
fill 181 218 304 182 218 304 minecraft:snow_block
setblock 181 218 307 minecraft:packed_ice
fill 181 218 308 182 218 308 minecraft:snow_block
setblock 181 218 311 minecraft:packed_ice
fill 181 218 312 182 218 312 minecraft:snow_block
setblock 181 218 315 minecraft:packed_ice
fill 181 218 316 182 218 316 minecraft:snow_block
fill 182 218 278 183 218 278 minecraft:packed_ice
setblock 182 218 279 minecraft:snow_block
setblock 182 218 282 minecraft:packed_ice
fill 182 218 283 182 218 285 minecraft:snow_block
setblock 182 218 286 minecraft:packed_ice
fill 182 218 287 182 218 289 minecraft:snow_block
setblock 182 218 290 minecraft:packed_ice
setblock 182 218 291 minecraft:snow_block
setblock 182 218 294 minecraft:packed_ice
setblock 182 218 295 minecraft:snow_block
setblock 182 218 298 minecraft:packed_ice
setblock 182 218 299 minecraft:snow_block
setblock 182 218 302 minecraft:packed_ice
setblock 182 218 303 minecraft:snow_block
fill 182 218 306 183 218 306 minecraft:packed_ice
setblock 182 218 307 minecraft:snow_block
setblock 182 218 310 minecraft:packed_ice
setblock 182 218 311 minecraft:snow_block
setblock 182 218 314 minecraft:packed_ice
setblock 182 218 315 minecraft:snow_block
setblock 141 219 300 minecraft:light_blue_concrete
fill 141 219 301 141 229 301 minecraft:packed_ice
fill 155 219 292 156 219 292 minecraft:blue_ice
fill 156 219 288 156 219 291 minecraft:blue_ice
fill 156 219 293 156 219 296 minecraft:blue_ice
fill 157 219 285 159 220 300 minecraft:gray_concrete
fill 158 219 275 158 224 275 minecraft:packed_ice
setblock 158 219 284 minecraft:blue_ice
fill 160 219 284 168 219 284 minecraft:blue_ice
fill 160 219 285 172 220 287 minecraft:gray_concrete
fill 160 219 298 172 220 300 minecraft:gray_concrete
fill 164 219 283 164 225 283 minecraft:blue_ice
fill 164 219 301 164 225 301 minecraft:blue_ice
fill 170 219 288 172 220 297 minecraft:gray_concrete
fill 173 219 292 173 225 292 minecraft:blue_ice
fill 174 219 275 174 243 275 minecraft:packed_ice
fill 183 219 278 183 244 278 minecraft:packed_ice
fill 183 219 306 183 244 306 minecraft:packed_ice
fill 141 220 300 141 244 300 minecraft:packed_ice
setblock 144 220 278 minecraft:light[level=15]
setblock 144 220 285 minecraft:light[level=12]
setblock 144 220 286 minecraft:light[level=15]
setblock 144 220 292 minecraft:light[level=12]
setblock 144 220 294 minecraft:light[level=15]
setblock 144 220 299 minecraft:light[level=12]
setblock 144 220 302 minecraft:light[level=15]
setblock 144 220 306 minecraft:light[level=12]
setblock 144 220 310 minecraft:light[level=15]
setblock 144 220 313 minecraft:light[level=12]
setblock 151 220 278 minecraft:light[level=12]
setblock 151 220 285 minecraft:light[level=12]
setblock 151 220 292 minecraft:light[level=12]
setblock 151 220 299 minecraft:light[level=12]
setblock 151 220 306 minecraft:light[level=12]
setblock 151 220 313 minecraft:light[level=12]
setblock 152 220 278 minecraft:light[level=15]
setblock 152 220 286 minecraft:light[level=15]
setblock 152 220 294 minecraft:light[level=15]
setblock 152 220 302 minecraft:light[level=15]
setblock 152 220 310 minecraft:light[level=15]
fill 155 220 292 155 225 292 minecraft:blue_ice
setblock 158 220 278 minecraft:light[level=12]
setblock 158 220 306 minecraft:light[level=12]
setblock 158 220 313 minecraft:light[level=12]
setblock 160 220 278 minecraft:light[level=15]
setblock 160 220 302 minecraft:light[level=15]
setblock 160 220 310 minecraft:light[level=15]
setblock 165 220 278 minecraft:light[level=12]
setblock 165 220 306 minecraft:light[level=12]
setblock 165 220 313 minecraft:light[level=12]
setblock 168 220 278 minecraft:light[level=15]
setblock 168 220 302 minecraft:light[level=15]
setblock 168 220 310 minecraft:light[level=15]
setblock 172 220 278 minecraft:light[level=12]
setblock 172 220 306 minecraft:light[level=12]
setblock 172 220 313 minecraft:light[level=12]
setblock 176 220 278 minecraft:light[level=15]
setblock 176 220 286 minecraft:light[level=15]
setblock 176 220 294 minecraft:light[level=15]
setblock 176 220 302 minecraft:light[level=15]
setblock 176 220 310 minecraft:light[level=15]
setblock 179 220 278 minecraft:light[level=12]
setblock 179 220 285 minecraft:light[level=12]
setblock 179 220 292 minecraft:light[level=12]
setblock 179 220 299 minecraft:light[level=12]
setblock 179 220 306 minecraft:light[level=12]
setblock 179 220 313 minecraft:light[level=12]
fill 157 221 285 157 233 285 minecraft:gray_concrete
setblock 157 221 286 minecraft:light_blue_stained_glass
fill 157 221 287 172 234 287 minecraft:gray_concrete
setblock 157 221 288 minecraft:sea_lantern
fill 157 221 289 159 234 289 minecraft:gray_concrete
setblock 157 221 290 minecraft:black_stained_glass
fill 157 221 291 159 234 291 minecraft:gray_concrete
setblock 157 221 292 minecraft:light_blue_stained_glass
fill 157 221 293 159 234 293 minecraft:gray_concrete
setblock 157 221 294 minecraft:black_stained_glass
fill 157 221 295 159 234 295 minecraft:gray_concrete
setblock 157 221 296 minecraft:black_stained_glass
fill 157 221 297 159 234 297 minecraft:gray_concrete
setblock 157 221 298 minecraft:black_stained_glass
fill 157 221 299 157 234 300 minecraft:gray_concrete
setblock 158 221 285 minecraft:black_stained_glass
fill 158 221 286 171 234 286 minecraft:gray_concrete
fill 158 221 288 159 234 288 minecraft:gray_concrete
fill 158 221 290 159 234 290 minecraft:gray_concrete
fill 158 221 292 159 234 292 minecraft:gray_concrete
fill 158 221 294 159 234 294 minecraft:gray_concrete
fill 158 221 296 159 234 296 minecraft:gray_concrete
fill 158 221 298 171 234 299 minecraft:gray_concrete
setblock 158 221 300 minecraft:sea_lantern
fill 159 221 285 159 233 285 minecraft:gray_concrete
fill 159 221 300 159 234 300 minecraft:gray_concrete
setblock 160 221 285 minecraft:black_stained_glass
setblock 160 221 300 minecraft:black_stained_glass
fill 161 221 285 161 233 285 minecraft:gray_concrete
fill 161 221 300 161 234 300 minecraft:gray_concrete
setblock 162 221 285 minecraft:light_blue_stained_glass
setblock 162 221 300 minecraft:light_blue_stained_glass
fill 163 221 285 163 233 285 minecraft:gray_concrete
fill 163 221 300 163 234 300 minecraft:gray_concrete
setblock 164 221 285 minecraft:black_stained_glass
setblock 164 221 300 minecraft:sea_lantern
fill 165 221 285 165 233 285 minecraft:gray_concrete
fill 165 221 300 165 234 300 minecraft:gray_concrete
setblock 166 221 285 minecraft:sea_lantern
setblock 166 221 300 minecraft:light_blue_stained_glass
fill 167 221 285 167 233 285 minecraft:gray_concrete
fill 167 221 300 167 234 300 minecraft:gray_concrete
setblock 168 221 285 minecraft:black_stained_glass
setblock 168 221 300 minecraft:sea_lantern
fill 169 221 285 169 233 285 minecraft:gray_concrete
fill 169 221 300 169 234 300 minecraft:gray_concrete
setblock 170 221 285 minecraft:black_stained_glass
fill 170 221 288 171 234 297 minecraft:gray_concrete
setblock 170 221 300 minecraft:black_stained_glass
fill 171 221 285 172 233 285 minecraft:gray_concrete
fill 171 221 300 172 234 300 minecraft:gray_concrete
setblock 172 221 286 minecraft:light_blue_stained_glass
setblock 172 221 288 minecraft:sea_lantern
fill 172 221 289 172 234 289 minecraft:gray_concrete
setblock 172 221 290 minecraft:black_stained_glass
fill 172 221 291 172 234 291 minecraft:gray_concrete
setblock 172 221 292 minecraft:black_stained_glass
fill 172 221 293 172 234 293 minecraft:gray_concrete
setblock 172 221 294 minecraft:black_stained_glass
fill 172 221 295 172 234 295 minecraft:gray_concrete
setblock 172 221 296 minecraft:black_stained_glass
fill 172 221 297 172 234 297 minecraft:gray_concrete
setblock 172 221 298 minecraft:light_blue_stained_glass
fill 172 221 299 172 234 299 minecraft:gray_concrete
setblock 142 222 285 minecraft:packed_ice
setblock 142 222 286 minecraft:snow_block
fill 142 222 287 142 222 290 minecraft:packed_ice
setblock 142 222 291 minecraft:snow_block
fill 142 222 292 142 222 295 minecraft:packed_ice
setblock 142 222 296 minecraft:snow_block
fill 142 222 297 142 222 300 minecraft:packed_ice
setblock 142 222 301 minecraft:snow_block
fill 142 222 302 142 222 303 minecraft:packed_ice
setblock 142 222 306 minecraft:snow_block
fill 142 222 307 142 222 310 minecraft:packed_ice
setblock 142 222 311 minecraft:snow_block
fill 142 222 312 142 222 315 minecraft:packed_ice
setblock 142 222 316 minecraft:snow_block
fill 143 222 276 146 222 276 minecraft:packed_ice
fill 143 222 286 143 222 289 minecraft:packed_ice
setblock 143 222 290 minecraft:snow_block
fill 143 222 291 143 222 294 minecraft:packed_ice
setblock 143 222 295 minecraft:snow_block
fill 143 222 296 143 222 299 minecraft:packed_ice
setblock 143 222 300 minecraft:snow_block
fill 143 222 312 143 222 314 minecraft:packed_ice
fill 143 222 316 146 222 316 minecraft:packed_ice
setblock 144 222 288 minecraft:packed_ice
setblock 144 222 289 minecraft:snow_block
fill 144 222 290 144 222 293 minecraft:packed_ice
setblock 144 222 294 minecraft:snow_block
fill 144 222 295 144 223 297 minecraft:packed_ice
fill 144 222 315 147 222 315 minecraft:packed_ice
fill 145 222 290 145 222 292 minecraft:packed_ice
setblock 145 222 293 minecraft:snow_block
fill 145 222 294 145 224 295 minecraft:packed_ice
setblock 147 222 276 minecraft:snow_block
setblock 147 222 316 minecraft:snow_block
fill 148 222 276 151 222 276 minecraft:packed_ice
setblock 148 222 315 minecraft:snow_block
fill 148 222 316 151 222 316 minecraft:packed_ice
setblock 149 222 315 minecraft:packed_ice
setblock 152 222 276 minecraft:snow_block
setblock 152 222 316 minecraft:snow_block
fill 153 222 276 156 222 276 minecraft:packed_ice
fill 153 222 316 154 222 316 minecraft:packed_ice
setblock 157 222 276 minecraft:snow_block
fill 157 222 286 157 223 286 minecraft:gray_concrete
fill 157 222 288 157 223 288 minecraft:gray_concrete
fill 157 222 290 157 223 290 minecraft:gray_concrete
fill 157 222 292 157 223 292 minecraft:gray_concrete
fill 157 222 294 157 223 294 minecraft:gray_concrete
fill 157 222 296 157 223 296 minecraft:gray_concrete
fill 157 222 298 157 223 298 minecraft:gray_concrete
setblock 157 222 316 minecraft:snow_block
fill 158 222 276 161 222 276 minecraft:packed_ice
fill 158 222 285 158 223 285 minecraft:gray_concrete
fill 158 222 300 158 223 300 minecraft:gray_concrete
fill 158 222 316 161 222 316 minecraft:packed_ice
fill 160 222 285 160 223 285 minecraft:gray_concrete
fill 160 222 300 160 223 300 minecraft:gray_concrete
fill 161 222 315 162 222 315 minecraft:packed_ice
setblock 162 222 276 minecraft:snow_block
fill 162 222 277 165 222 277 minecraft:packed_ice
fill 162 222 285 162 223 285 minecraft:gray_concrete
fill 162 222 300 162 223 300 minecraft:gray_concrete
setblock 162 222 316 minecraft:snow_block
fill 163 222 276 166 222 276 minecraft:packed_ice
setblock 163 222 314 minecraft:packed_ice
setblock 163 222 315 minecraft:snow_block
fill 163 222 316 166 222 316 minecraft:packed_ice
fill 164 222 285 164 223 285 minecraft:gray_concrete
fill 164 222 300 164 223 300 minecraft:gray_concrete
setblock 164 222 314 minecraft:snow_block
fill 164 222 315 167 222 315 minecraft:packed_ice
fill 165 222 314 168 222 314 minecraft:packed_ice
setblock 166 222 277 minecraft:snow_block
fill 166 222 285 166 223 285 minecraft:gray_concrete
fill 166 222 300 166 223 300 minecraft:gray_concrete
fill 166 222 313 169 222 313 minecraft:packed_ice
setblock 167 222 276 minecraft:snow_block
fill 167 222 277 170 222 277 minecraft:packed_ice
setblock 167 222 316 minecraft:snow_block
fill 168 222 276 171 222 276 minecraft:packed_ice
fill 168 222 285 168 223 285 minecraft:gray_concrete
fill 168 222 300 168 223 300 minecraft:gray_concrete
setblock 168 222 315 minecraft:snow_block
fill 168 222 316 171 222 316 minecraft:packed_ice
setblock 169 222 314 minecraft:snow_block
fill 169 222 315 172 222 315 minecraft:packed_ice
fill 170 222 285 170 223 285 minecraft:gray_concrete
fill 170 222 300 170 223 300 minecraft:gray_concrete
setblock 170 222 313 minecraft:snow_block
fill 170 222 314 173 222 314 minecraft:packed_ice
setblock 172 222 276 minecraft:snow_block
fill 172 222 286 172 223 286 minecraft:gray_concrete
fill 172 222 288 172 223 288 minecraft:gray_concrete
fill 172 222 290 172 223 290 minecraft:gray_concrete
fill 172 222 292 172 223 292 minecraft:gray_concrete
fill 172 222 294 172 223 294 minecraft:gray_concrete
fill 172 222 296 172 223 296 minecraft:gray_concrete
fill 172 222 298 172 223 298 minecraft:gray_concrete
setblock 172 222 316 minecraft:snow_block
setblock 173 222 276 minecraft:packed_ice
setblock 173 222 315 minecraft:snow_block
fill 173 222 316 176 222 316 minecraft:packed_ice
fill 174 222 315 177 222 315 minecraft:packed_ice
setblock 177 222 316 minecraft:snow_block
fill 178 222 289 178 232 289 minecraft:packed_ice
setblock 178 222 315 minecraft:snow_block
fill 178 222 316 181 222 316 minecraft:packed_ice
fill 179 222 315 182 222 315 minecraft:packed_ice
fill 180 222 292 181 222 292 minecraft:blue_ice
fill 181 222 291 181 225 291 minecraft:blue_ice
fill 181 222 293 182 222 295 minecraft:packed_ice
fill 181 222 309 181 222 311 minecraft:packed_ice
setblock 181 222 312 minecraft:snow_block
fill 181 222 313 182 223 314 minecraft:packed_ice
fill 182 222 288 182 222 290 minecraft:packed_ice
setblock 182 222 291 minecraft:snow_block
fill 182 222 292 182 225 292 minecraft:packed_ice
setblock 182 222 296 minecraft:snow_block
fill 182 222 297 182 222 300 minecraft:packed_ice
setblock 182 222 301 minecraft:snow_block
fill 182 222 302 182 222 305 minecraft:packed_ice
setblock 182 222 306 minecraft:snow_block
fill 182 222 307 182 222 310 minecraft:packed_ice
setblock 182 222 311 minecraft:snow_block
fill 182 222 312 182 225 312 minecraft:packed_ice
setblock 182 222 316 minecraft:snow_block
setblock 142 223 285 minecraft:snow_block
fill 142 223 286 142 223 289 minecraft:packed_ice
setblock 142 223 290 minecraft:snow_block
fill 142 223 291 142 223 294 minecraft:packed_ice
setblock 142 223 295 minecraft:snow_block
fill 142 223 296 142 223 299 minecraft:packed_ice
setblock 142 223 300 minecraft:snow_block
fill 142 223 301 142 225 302 minecraft:packed_ice
setblock 142 223 309 minecraft:packed_ice
setblock 142 223 310 minecraft:snow_block
fill 142 223 311 142 223 314 minecraft:packed_ice
setblock 142 223 315 minecraft:snow_block
fill 142 223 316 145 223 316 minecraft:packed_ice
fill 143 223 276 145 223 276 minecraft:packed_ice
fill 143 223 287 143 223 288 minecraft:packed_ice
setblock 143 223 289 minecraft:snow_block
fill 143 223 290 143 223 293 minecraft:packed_ice
setblock 143 223 294 minecraft:snow_block
fill 143 223 295 143 223 298 minecraft:packed_ice
setblock 143 223 299 minecraft:snow_block
fill 143 223 300 143 226 300 minecraft:packed_ice
setblock 144 223 288 minecraft:snow_block
fill 144 223 289 144 223 292 minecraft:packed_ice
setblock 144 223 293 minecraft:snow_block
fill 144 223 294 144 226 294 minecraft:packed_ice
setblock 144 223 298 minecraft:snow_block
fill 144 223 315 146 223 315 minecraft:packed_ice
setblock 145 223 291 minecraft:packed_ice
setblock 145 223 292 minecraft:snow_block
fill 145 223 293 145 226 293 minecraft:packed_ice
setblock 146 223 276 minecraft:snow_block
setblock 146 223 316 minecraft:snow_block
fill 147 223 276 148 224 277 minecraft:packed_ice
setblock 147 223 315 minecraft:snow_block
fill 147 223 316 150 223 316 minecraft:packed_ice
setblock 148 223 315 minecraft:packed_ice
fill 149 223 276 150 223 276 minecraft:packed_ice
setblock 151 223 276 minecraft:snow_block
setblock 151 223 316 minecraft:snow_block
fill 152 223 276 155 223 276 minecraft:packed_ice
fill 152 223 316 153 223 316 minecraft:packed_ice
fill 154 223 292 154 225 292 minecraft:blue_ice
fill 155 223 291 155 225 291 minecraft:blue_ice
fill 155 223 293 155 225 293 minecraft:blue_ice
setblock 156 223 276 minecraft:snow_block
fill 156 223 292 156 225 292 minecraft:blue_ice
fill 157 223 276 160 223 276 minecraft:packed_ice
fill 157 223 316 160 223 316 minecraft:packed_ice
fill 160 223 315 161 223 315 minecraft:packed_ice
setblock 161 223 276 minecraft:snow_block
fill 161 223 277 164 223 277 minecraft:packed_ice
setblock 161 223 316 minecraft:snow_block
fill 162 223 276 165 223 276 minecraft:packed_ice
setblock 162 223 315 minecraft:snow_block
fill 162 223 316 165 223 316 minecraft:packed_ice
fill 163 223 283 163 225 283 minecraft:blue_ice
fill 163 223 301 163 225 301 minecraft:blue_ice
setblock 163 223 314 minecraft:snow_block
fill 163 223 315 166 223 315 minecraft:packed_ice
fill 164 223 282 164 225 282 minecraft:blue_ice
fill 164 223 284 164 225 284 minecraft:blue_ice
fill 164 223 302 164 225 302 minecraft:blue_ice
fill 164 223 314 167 223 314 minecraft:packed_ice
setblock 165 223 277 minecraft:snow_block
fill 165 223 283 165 225 283 minecraft:blue_ice
fill 165 223 301 165 225 301 minecraft:blue_ice
setblock 166 223 276 minecraft:snow_block
fill 166 223 277 169 223 277 minecraft:packed_ice
setblock 166 223 316 minecraft:snow_block
fill 167 223 276 170 223 276 minecraft:packed_ice
fill 167 223 313 168 223 313 minecraft:packed_ice
setblock 167 223 315 minecraft:snow_block
fill 167 223 316 170 223 316 minecraft:packed_ice
setblock 168 223 314 minecraft:snow_block
fill 168 223 315 171 223 315 minecraft:packed_ice
fill 169 223 314 172 223 314 minecraft:packed_ice
setblock 171 223 276 minecraft:snow_block
setblock 171 223 316 minecraft:snow_block
fill 172 223 276 172 226 276 minecraft:packed_ice
setblock 172 223 315 minecraft:snow_block
fill 172 223 316 175 223 316 minecraft:packed_ice
fill 173 223 291 173 225 291 minecraft:blue_ice
fill 173 223 293 173 225 293 minecraft:blue_ice
fill 173 223 315 175 223 315 minecraft:packed_ice
fill 174 223 292 174 225 292 minecraft:blue_ice
setblock 176 223 316 minecraft:snow_block
setblock 176 223 317 minecraft:white_concrete
fill 177 223 316 180 223 316 minecraft:packed_ice
fill 179 223 292 180 225 292 minecraft:blue_ice
fill 180 223 291 180 225 291 minecraft:blue_ice
fill 180 223 293 180 225 293 minecraft:blue_ice
fill 180 223 315 181 223 315 minecraft:packed_ice
fill 181 223 292 181 223 295 minecraft:packed_ice
setblock 181 223 296 minecraft:snow_block
fill 181 223 297 182 225 297 minecraft:packed_ice
setblock 181 223 310 minecraft:packed_ice
setblock 181 223 311 minecraft:snow_block
fill 181 223 312 181 226 312 minecraft:packed_ice
setblock 181 223 316 minecraft:snow_block
fill 182 223 288 182 223 289 minecraft:packed_ice
setblock 182 223 290 minecraft:snow_block
fill 182 223 291 182 226 291 minecraft:packed_ice
fill 182 223 293 182 223 294 minecraft:packed_ice
setblock 182 223 295 minecraft:snow_block
fill 182 223 296 182 226 296 minecraft:packed_ice
fill 182 223 298 182 223 299 minecraft:packed_ice
setblock 182 223 300 minecraft:snow_block
fill 182 223 301 182 223 304 minecraft:packed_ice
setblock 182 223 305 minecraft:snow_block
fill 182 223 306 182 223 309 minecraft:packed_ice
setblock 182 223 310 minecraft:snow_block
fill 182 223 311 182 226 311 minecraft:packed_ice
setblock 182 223 315 minecraft:snow_block
fill 182 223 316 182 226 316 minecraft:packed_ice
fill 142 224 276 142 225 277 minecraft:packed_ice
fill 142 224 285 142 224 288 minecraft:packed_ice
setblock 142 224 289 minecraft:snow_block
fill 142 224 290 142 224 293 minecraft:packed_ice
setblock 142 224 294 minecraft:snow_block
fill 142 224 295 142 224 298 minecraft:packed_ice
setblock 142 224 299 minecraft:snow_block
fill 142 224 300 142 227 300 minecraft:packed_ice
setblock 142 224 303 minecraft:packed_ice
fill 142 224 310 142 224 313 minecraft:packed_ice
setblock 142 224 314 minecraft:snow_block
fill 142 224 315 142 226 316 minecraft:packed_ice
fill 143 224 276 144 224 276 minecraft:packed_ice
setblock 143 224 287 minecraft:packed_ice
setblock 143 224 288 minecraft:snow_block
fill 143 224 289 143 224 292 minecraft:packed_ice
setblock 143 224 293 minecraft:snow_block
fill 143 224 294 143 224 297 minecraft:packed_ice
setblock 143 224 298 minecraft:snow_block
fill 143 224 299 143 227 299 minecraft:packed_ice
fill 143 224 316 144 224 316 minecraft:packed_ice
fill 144 224 289 144 224 291 minecraft:packed_ice
setblock 144 224 292 minecraft:snow_block
fill 144 224 293 144 227 293 minecraft:packed_ice
fill 144 224 295 144 224 296 minecraft:packed_ice
setblock 144 224 297 minecraft:snow_block
fill 144 224 298 144 227 298 minecraft:packed_ice
fill 144 224 315 145 224 315 minecraft:packed_ice
setblock 145 224 276 minecraft:snow_block
setblock 145 224 291 minecraft:snow_block
fill 145 224 292 145 225 292 minecraft:packed_ice
setblock 145 224 316 minecraft:snow_block
fill 146 224 276 146 226 277 minecraft:packed_ice
setblock 146 224 315 minecraft:snow_block
fill 146 224 316 149 224 316 minecraft:packed_ice
setblock 147 224 315 minecraft:packed_ice
setblock 149 224 275 minecraft:light_blue_concrete
setblock 149 224 276 minecraft:packed_ice
setblock 150 224 276 minecraft:snow_block
setblock 150 224 316 minecraft:snow_block
fill 151 224 276 154 224 276 minecraft:packed_ice
fill 151 224 316 152 226 316 minecraft:packed_ice
setblock 155 224 276 minecraft:snow_block
fill 156 224 276 159 224 276 minecraft:packed_ice
setblock 157 224 286 minecraft:black_stained_glass
setblock 157 224 288 minecraft:black_stained_glass
setblock 157 224 290 minecraft:black_stained_glass
setblock 157 224 292 minecraft:black_stained_glass
setblock 157 224 294 minecraft:black_stained_glass
setblock 157 224 296 minecraft:black_stained_glass
setblock 157 224 298 minecraft:sea_lantern
fill 157 224 316 159 224 316 minecraft:packed_ice
setblock 158 224 285 minecraft:black_stained_glass
setblock 158 224 300 minecraft:black_stained_glass
setblock 160 224 276 minecraft:snow_block
fill 160 224 277 163 224 277 minecraft:packed_ice
setblock 160 224 285 minecraft:black_stained_glass
setblock 160 224 300 minecraft:black_stained_glass
setblock 160 224 315 minecraft:packed_ice
setblock 160 224 316 minecraft:snow_block
fill 161 224 276 164 224 276 minecraft:packed_ice
setblock 161 224 315 minecraft:snow_block
fill 161 224 316 164 224 316 minecraft:packed_ice
setblock 162 224 285 minecraft:black_stained_glass
setblock 162 224 300 minecraft:black_stained_glass
fill 162 224 315 165 224 315 minecraft:packed_ice
fill 163 224 314 166 224 314 minecraft:packed_ice
setblock 164 224 277 minecraft:snow_block
setblock 164 224 285 minecraft:black_stained_glass
setblock 164 224 300 minecraft:sea_lantern
setblock 165 224 276 minecraft:snow_block
fill 165 224 277 168 224 277 minecraft:packed_ice
setblock 165 224 316 minecraft:snow_block
fill 166 224 276 169 224 276 minecraft:packed_ice
setblock 166 224 285 minecraft:black_stained_glass
setblock 166 224 300 minecraft:black_stained_glass
setblock 166 224 315 minecraft:snow_block
fill 166 224 316 169 224 316 minecraft:packed_ice
setblock 167 224 314 minecraft:snow_block
fill 167 224 315 170 224 315 minecraft:packed_ice
setblock 168 224 285 minecraft:black_stained_glass
setblock 168 224 300 minecraft:light_blue_stained_glass
fill 168 224 314 171 224 314 minecraft:packed_ice
setblock 169 224 277 minecraft:snow_block
setblock 170 224 276 minecraft:snow_block
setblock 170 224 285 minecraft:sea_lantern
setblock 170 224 300 minecraft:black_stained_glass
setblock 170 224 316 minecraft:snow_block
fill 171 224 276 171 227 276 minecraft:packed_ice
setblock 171 224 315 minecraft:snow_block
fill 171 224 316 174 224 316 minecraft:packed_ice
setblock 172 224 286 minecraft:light_blue_stained_glass
setblock 172 224 288 minecraft:sea_lantern
setblock 172 224 290 minecraft:sea_lantern
setblock 172 224 292 minecraft:sea_lantern
setblock 172 224 294 minecraft:light_blue_stained_glass
setblock 172 224 296 minecraft:black_stained_glass
setblock 172 224 298 minecraft:black_stained_glass
fill 172 224 315 174 224 315 minecraft:packed_ice
setblock 175 224 316 minecraft:snow_block
fill 176 224 316 176 227 317 minecraft:packed_ice
fill 177 224 316 179 224 316 minecraft:packed_ice
fill 178 224 292 178 226 292 minecraft:blue_ice
fill 179 224 291 179 225 291 minecraft:blue_ice
fill 179 224 293 179 225 293 minecraft:blue_ice
setblock 180 224 315 minecraft:packed_ice
setblock 180 224 316 minecraft:snow_block
fill 181 224 292 181 224 294 minecraft:packed_ice
setblock 181 224 295 minecraft:snow_block
fill 181 224 296 181 227 296 minecraft:packed_ice
fill 181 224 298 181 224 299 minecraft:packed_ice
setblock 181 224 311 minecraft:packed_ice
fill 181 224 313 181 224 314 minecraft:packed_ice
setblock 181 224 315 minecraft:snow_block
fill 181 224 316 181 227 316 minecraft:packed_ice
setblock 182 224 289 minecraft:snow_block
fill 182 224 290 182 227 290 minecraft:packed_ice
setblock 182 224 293 minecraft:packed_ice
setblock 182 224 294 minecraft:snow_block
fill 182 224 295 182 227 295 minecraft:packed_ice
setblock 182 224 298 minecraft:packed_ice
setblock 182 224 299 minecraft:snow_block
fill 182 224 300 182 224 303 minecraft:packed_ice
setblock 182 224 304 minecraft:snow_block
fill 182 224 305 182 224 308 minecraft:packed_ice
setblock 182 224 309 minecraft:snow_block
fill 182 224 310 182 227 310 minecraft:packed_ice
setblock 182 224 313 minecraft:packed_ice
setblock 182 224 314 minecraft:snow_block
fill 182 224 315 182 227 315 minecraft:packed_ice
fill 183 224 296 183 244 296 minecraft:packed_ice
setblock 183 224 297 minecraft:white_concrete
setblock 142 225 278 minecraft:snow_block
fill 142 225 279 142 228 279 minecraft:packed_ice
fill 142 225 285 142 225 287 minecraft:packed_ice
setblock 142 225 288 minecraft:snow_block
fill 142 225 289 142 225 292 minecraft:packed_ice
setblock 142 225 293 minecraft:snow_block
fill 142 225 294 142 225 297 minecraft:packed_ice
setblock 142 225 298 minecraft:snow_block
fill 142 225 299 142 228 299 minecraft:packed_ice
setblock 142 225 303 minecraft:snow_block
fill 142 225 311 142 225 312 minecraft:packed_ice
setblock 142 225 313 minecraft:snow_block
fill 142 225 314 142 228 314 minecraft:packed_ice
setblock 143 225 276 minecraft:packed_ice
setblock 143 225 287 minecraft:snow_block
fill 143 225 288 143 225 291 minecraft:packed_ice
setblock 143 225 292 minecraft:snow_block
fill 143 225 293 143 225 296 minecraft:packed_ice
setblock 143 225 297 minecraft:snow_block
fill 143 225 298 143 228 298 minecraft:packed_ice
setblock 143 225 301 minecraft:packed_ice
setblock 143 225 316 minecraft:packed_ice
setblock 144 225 276 minecraft:snow_block
fill 144 225 277 145 227 277 minecraft:packed_ice
fill 144 225 289 144 225 290 minecraft:packed_ice
setblock 144 225 291 minecraft:snow_block
fill 144 225 292 144 228 292 minecraft:packed_ice
setblock 144 225 295 minecraft:packed_ice
setblock 144 225 296 minecraft:snow_block
fill 144 225 297 144 228 297 minecraft:packed_ice
fill 144 225 299 144 226 299 minecraft:packed_ice
setblock 144 225 315 minecraft:packed_ice
setblock 144 225 316 minecraft:snow_block
fill 145 225 276 145 228 276 minecraft:packed_ice
setblock 145 225 294 minecraft:packed_ice
setblock 145 225 295 minecraft:snow_block
setblock 145 225 315 minecraft:snow_block
fill 145 225 316 148 225 316 minecraft:packed_ice
setblock 146 225 315 minecraft:packed_ice
fill 147 225 276 147 225 277 minecraft:packed_ice
setblock 148 225 276 minecraft:packed_ice
setblock 148 225 277 minecraft:snow_block
fill 149 225 275 149 244 275 minecraft:packed_ice
setblock 149 225 276 minecraft:snow_block
fill 149 225 277 149 228 277 minecraft:packed_ice
setblock 149 225 316 minecraft:snow_block
fill 150 225 276 153 225 276 minecraft:packed_ice
fill 150 225 316 150 228 316 minecraft:packed_ice
setblock 154 225 276 minecraft:snow_block
setblock 154 225 291 minecraft:blue_ice
setblock 154 225 293 minecraft:blue_ice
fill 155 225 276 158 225 276 minecraft:packed_ice
setblock 156 225 275 minecraft:white_concrete
setblock 156 225 291 minecraft:blue_ice
setblock 156 225 293 minecraft:blue_ice
fill 156 225 316 158 225 316 minecraft:packed_ice
fill 157 225 286 157 226 286 minecraft:gray_concrete
fill 157 225 288 157 226 288 minecraft:gray_concrete
fill 157 225 290 157 226 290 minecraft:gray_concrete
fill 157 225 292 157 226 292 minecraft:gray_concrete
fill 157 225 294 157 226 294 minecraft:gray_concrete
fill 157 225 296 157 226 296 minecraft:gray_concrete
fill 157 225 298 157 226 298 minecraft:gray_concrete
setblock 158 225 275 minecraft:white_concrete
fill 158 225 285 158 226 285 minecraft:gray_concrete
fill 158 225 300 158 226 300 minecraft:gray_concrete
setblock 159 225 276 minecraft:snow_block
fill 159 225 277 162 225 277 minecraft:packed_ice
setblock 159 225 315 minecraft:packed_ice
setblock 159 225 316 minecraft:snow_block
fill 160 225 276 163 225 276 minecraft:packed_ice
fill 160 225 285 160 226 285 minecraft:gray_concrete
fill 160 225 300 160 226 300 minecraft:gray_concrete
setblock 160 225 315 minecraft:snow_block
fill 160 225 316 163 225 316 minecraft:packed_ice
fill 161 225 315 164 225 315 minecraft:packed_ice
fill 162 225 285 162 226 285 minecraft:gray_concrete
fill 162 225 300 162 226 300 minecraft:gray_concrete
fill 162 225 314 165 225 314 minecraft:packed_ice
setblock 163 225 277 minecraft:snow_block
setblock 163 225 282 minecraft:blue_ice
setblock 163 225 284 minecraft:blue_ice
setblock 163 225 302 minecraft:blue_ice
setblock 164 225 276 minecraft:snow_block
fill 164 225 277 167 225 277 minecraft:packed_ice
fill 164 225 285 164 226 285 minecraft:gray_concrete
fill 164 225 300 164 226 300 minecraft:gray_concrete
setblock 164 225 316 minecraft:snow_block
fill 165 225 276 168 225 276 minecraft:packed_ice
setblock 165 225 282 minecraft:blue_ice
setblock 165 225 284 minecraft:blue_ice
setblock 165 225 302 minecraft:blue_ice
setblock 165 225 315 minecraft:snow_block
fill 165 225 316 168 225 316 minecraft:packed_ice
fill 166 225 285 166 226 285 minecraft:gray_concrete
fill 166 225 300 166 226 300 minecraft:gray_concrete
setblock 166 225 314 minecraft:snow_block
fill 166 225 315 169 225 315 minecraft:packed_ice
fill 167 225 314 170 225 314 minecraft:packed_ice
setblock 168 225 277 minecraft:snow_block
fill 168 225 285 168 226 285 minecraft:gray_concrete
fill 168 225 300 168 226 300 minecraft:gray_concrete
setblock 169 225 276 minecraft:snow_block
fill 169 225 277 169 228 277 minecraft:packed_ice
setblock 169 225 316 minecraft:snow_block
fill 170 225 276 170 228 276 minecraft:packed_ice
fill 170 225 285 170 226 285 minecraft:gray_concrete
fill 170 225 300 170 226 300 minecraft:gray_concrete
setblock 170 225 315 minecraft:snow_block
fill 170 225 316 173 225 316 minecraft:packed_ice
fill 171 225 315 173 226 315 minecraft:packed_ice
fill 172 225 286 172 226 286 minecraft:gray_concrete
fill 172 225 288 172 226 288 minecraft:gray_concrete
fill 172 225 290 172 226 290 minecraft:gray_concrete
fill 172 225 292 172 226 292 minecraft:gray_concrete
fill 172 225 294 172 226 294 minecraft:gray_concrete
fill 172 225 296 172 226 296 minecraft:gray_concrete
fill 172 225 298 172 226 298 minecraft:gray_concrete
setblock 174 225 291 minecraft:blue_ice
setblock 174 225 293 minecraft:blue_ice
setblock 174 225 316 minecraft:snow_block
fill 175 225 316 175 228 316 minecraft:packed_ice
fill 177 225 292 177 226 292 minecraft:blue_ice
fill 177 225 316 178 225 316 minecraft:packed_ice
setblock 178 225 291 minecraft:blue_ice
setblock 178 225 293 minecraft:blue_ice
setblock 179 225 316 minecraft:snow_block
setblock 180 225 315 minecraft:snow_block
fill 180 225 316 180 228 316 minecraft:packed_ice
fill 181 225 292 181 225 293 minecraft:packed_ice
setblock 181 225 294 minecraft:snow_block
fill 181 225 295 181 228 295 minecraft:packed_ice
setblock 181 225 298 minecraft:packed_ice
setblock 181 225 299 minecraft:snow_block
fill 181 225 300 182 227 300 minecraft:packed_ice
setblock 181 225 313 minecraft:packed_ice
setblock 181 225 314 minecraft:snow_block
fill 181 225 315 181 228 315 minecraft:packed_ice
fill 182 225 276 182 226 276 minecraft:packed_ice
fill 182 225 289 182 228 289 minecraft:packed_ice
setblock 182 225 293 minecraft:snow_block
fill 182 225 294 182 228 294 minecraft:packed_ice
setblock 182 225 298 minecraft:snow_block
fill 182 225 299 182 228 299 minecraft:packed_ice
fill 182 225 301 182 225 302 minecraft:packed_ice
setblock 182 225 303 minecraft:snow_block
fill 182 225 304 182 225 307 minecraft:packed_ice
setblock 182 225 308 minecraft:snow_block
fill 182 225 309 182 228 309 minecraft:packed_ice
setblock 182 225 313 minecraft:snow_block
fill 182 225 314 182 228 314 minecraft:packed_ice
fill 183 225 297 183 244 297 minecraft:packed_ice
setblock 183 225 316 minecraft:white_concrete
fill 183 225 317 183 244 317 minecraft:packed_ice
fill 141 226 317 141 246 317 minecraft:packed_ice
setblock 142 226 276 minecraft:packed_ice
setblock 142 226 277 minecraft:snow_block
fill 142 226 278 143 228 278 minecraft:packed_ice
fill 142 226 280 142 226 281 minecraft:packed_ice
setblock 142 226 282 minecraft:snow_block
fill 142 226 283 142 226 286 minecraft:packed_ice
setblock 142 226 287 minecraft:snow_block
fill 142 226 288 142 226 291 minecraft:packed_ice
setblock 142 226 292 minecraft:snow_block
fill 142 226 293 142 226 296 minecraft:packed_ice
setblock 142 226 297 minecraft:snow_block
fill 142 226 298 142 229 298 minecraft:packed_ice
setblock 142 226 301 minecraft:packed_ice
setblock 142 226 302 minecraft:snow_block
fill 142 226 303 142 228 304 minecraft:packed_ice
setblock 142 226 311 minecraft:packed_ice
setblock 142 226 312 minecraft:snow_block
fill 142 226 313 142 229 313 minecraft:packed_ice
setblock 142 226 317 minecraft:light_blue_concrete
setblock 143 226 276 minecraft:snow_block
fill 143 226 277 143 229 277 minecraft:packed_ice
fill 143 226 279 143 227 279 minecraft:packed_ice
fill 143 226 287 143 226 290 minecraft:packed_ice
setblock 143 226 291 minecraft:snow_block
fill 143 226 292 143 226 295 minecraft:packed_ice
setblock 143 226 296 minecraft:snow_block
fill 143 226 297 143 229 297 minecraft:packed_ice
setblock 143 226 301 minecraft:snow_block
setblock 143 226 316 minecraft:snow_block
fill 143 226 317 143 242 317 minecraft:packed_ice
fill 144 226 276 144 229 276 minecraft:packed_ice
setblock 144 226 278 minecraft:light[level=12]
setblock 144 226 285 minecraft:light[level=12]
setblock 144 226 289 minecraft:packed_ice
setblock 144 226 290 minecraft:snow_block
fill 144 226 291 144 229 291 minecraft:packed_ice
setblock 144 226 295 minecraft:snow_block
fill 144 226 296 145 228 296 minecraft:packed_ice
setblock 144 226 306 minecraft:light[level=12]
setblock 144 226 313 minecraft:light[level=12]
setblock 144 226 315 minecraft:snow_block
fill 144 226 316 147 226 316 minecraft:packed_ice
setblock 145 226 294 minecraft:snow_block
fill 145 226 295 145 229 295 minecraft:packed_ice
fill 145 226 315 145 229 315 minecraft:packed_ice
setblock 147 226 276 minecraft:packed_ice
setblock 147 226 277 minecraft:snow_block
setblock 148 226 276 minecraft:snow_block
fill 148 226 277 148 229 277 minecraft:packed_ice
setblock 148 226 316 minecraft:snow_block
fill 149 226 276 152 226 276 minecraft:packed_ice
fill 149 226 316 149 229 316 minecraft:packed_ice
fill 150 226 277 150 227 277 minecraft:packed_ice
setblock 151 226 278 minecraft:light[level=12]
setblock 151 226 285 minecraft:light[level=12]
setblock 151 226 292 minecraft:light[level=12]
setblock 151 226 299 minecraft:light[level=12]
setblock 151 226 306 minecraft:light[level=12]
setblock 151 226 313 minecraft:light[level=12]
setblock 153 226 276 minecraft:snow_block
fill 154 226 276 157 226 276 minecraft:packed_ice
fill 155 226 316 157 226 316 minecraft:packed_ice
fill 156 226 275 156 244 275 minecraft:packed_ice
setblock 157 226 277 minecraft:snow_block
fill 158 226 275 158 245 275 minecraft:packed_ice
setblock 158 226 276 minecraft:snow_block
fill 158 226 277 161 226 277 minecraft:packed_ice
setblock 158 226 278 minecraft:light[level=12]
setblock 158 226 306 minecraft:light[level=12]
setblock 158 226 313 minecraft:light[level=12]
setblock 158 226 316 minecraft:snow_block
fill 159 226 276 162 226 276 minecraft:packed_ice
setblock 159 226 315 minecraft:snow_block
fill 159 226 316 162 226 316 minecraft:packed_ice
fill 160 226 315 163 226 315 minecraft:packed_ice
setblock 162 226 277 minecraft:snow_block
fill 162 226 278 165 226 278 minecraft:packed_ice
fill 162 226 314 164 226 314 minecraft:packed_ice
setblock 163 226 276 minecraft:snow_block
fill 163 226 277 166 226 277 minecraft:packed_ice
setblock 163 226 316 minecraft:snow_block
fill 164 226 276 167 226 276 minecraft:packed_ice
setblock 164 226 315 minecraft:snow_block
fill 164 226 316 167 226 316 minecraft:packed_ice
setblock 165 226 275 minecraft:light_blue_concrete
setblock 165 226 306 minecraft:light[level=12]
setblock 165 226 313 minecraft:light[level=12]
setblock 165 226 314 minecraft:snow_block
fill 165 226 315 168 226 315 minecraft:packed_ice
fill 166 226 275 166 244 275 minecraft:packed_ice
fill 166 226 314 169 226 314 minecraft:packed_ice
setblock 167 226 277 minecraft:snow_block
setblock 168 226 276 minecraft:snow_block
fill 168 226 277 168 229 277 minecraft:packed_ice
setblock 168 226 316 minecraft:snow_block
fill 169 226 276 169 229 276 minecraft:packed_ice
setblock 169 226 315 minecraft:snow_block
fill 169 226 316 172 226 316 minecraft:packed_ice
fill 170 226 315 170 229 315 minecraft:packed_ice
setblock 172 226 278 minecraft:light[level=12]
setblock 172 226 306 minecraft:light[level=12]
setblock 172 226 313 minecraft:light[level=12]
setblock 173 226 316 minecraft:snow_block
fill 174 226 316 174 229 316 minecraft:packed_ice
setblock 176 226 292 minecraft:blue_ice
setblock 177 226 316 minecraft:packed_ice
setblock 178 226 316 minecraft:snow_block
setblock 179 226 278 minecraft:light[level=12]
setblock 179 226 285 minecraft:light[level=12]
setblock 179 226 292 minecraft:blue_ice
setblock 179 226 299 minecraft:light[level=12]
setblock 179 226 306 minecraft:light[level=12]
setblock 179 226 313 minecraft:light[level=12]
fill 179 226 316 179 229 316 minecraft:packed_ice
fill 180 226 315 180 229 315 minecraft:packed_ice
fill 181 226 276 181 227 276 minecraft:packed_ice
fill 181 226 291 181 226 292 minecraft:packed_ice
setblock 181 226 293 minecraft:snow_block
fill 181 226 294 181 229 294 minecraft:packed_ice
setblock 181 226 297 minecraft:packed_ice
setblock 181 226 298 minecraft:snow_block
fill 181 226 299 181 229 299 minecraft:packed_ice
fill 181 226 301 181 226 302 minecraft:packed_ice
setblock 181 226 313 minecraft:snow_block
fill 181 226 314 181 229 314 minecraft:packed_ice
setblock 182 226 277 minecraft:snow_block
fill 182 226 278 182 229 278 minecraft:packed_ice
fill 182 226 288 182 229 288 minecraft:packed_ice
setblock 182 226 292 minecraft:snow_block
fill 182 226 293 182 229 293 minecraft:packed_ice
setblock 182 226 297 minecraft:snow_block
fill 182 226 298 182 229 298 minecraft:packed_ice
setblock 182 226 301 minecraft:packed_ice
setblock 182 226 302 minecraft:snow_block
fill 182 226 303 182 226 306 minecraft:packed_ice
setblock 182 226 307 minecraft:snow_block
fill 182 226 308 182 229 308 minecraft:packed_ice
setblock 182 226 312 minecraft:snow_block
fill 182 226 313 182 229 313 minecraft:packed_ice
setblock 183 226 310 minecraft:light_blue_concrete
fill 183 226 316 183 244 316 minecraft:packed_ice
setblock 141 227 286 minecraft:light_blue_concrete
setblock 142 227 276 minecraft:snow_block
fill 142 227 277 142 230 277 minecraft:packed_ice
setblock 142 227 280 minecraft:packed_ice
setblock 142 227 281 minecraft:snow_block
fill 142 227 282 142 227 285 minecraft:packed_ice
setblock 142 227 286 minecraft:snow_block
fill 142 227 287 142 227 290 minecraft:packed_ice
setblock 142 227 291 minecraft:snow_block
fill 142 227 292 142 227 295 minecraft:packed_ice
setblock 142 227 296 minecraft:snow_block
fill 142 227 297 142 230 297 minecraft:packed_ice
setblock 142 227 301 minecraft:snow_block
fill 142 227 302 143 229 302 minecraft:packed_ice
setblock 142 227 305 minecraft:packed_ice
setblock 142 227 311 minecraft:snow_block
fill 142 227 312 142 230 312 minecraft:packed_ice
setblock 142 227 315 minecraft:packed_ice
setblock 142 227 316 minecraft:snow_block
fill 142 227 317 142 244 317 minecraft:packed_ice
fill 143 227 276 143 230 276 minecraft:packed_ice
setblock 143 227 280 minecraft:snow_block
fill 143 227 281 143 228 283 minecraft:packed_ice
setblock 143 227 285 minecraft:snow_block
fill 143 227 286 143 227 289 minecraft:packed_ice
setblock 143 227 290 minecraft:snow_block
fill 143 227 291 143 227 294 minecraft:packed_ice
setblock 143 227 295 minecraft:snow_block
fill 143 227 296 143 230 296 minecraft:packed_ice
setblock 143 227 300 minecraft:snow_block
fill 143 227 301 143 230 301 minecraft:packed_ice
setblock 143 227 315 minecraft:snow_block
fill 143 227 316 146 227 316 minecraft:packed_ice
setblock 144 227 289 minecraft:snow_block
fill 144 227 290 144 230 290 minecraft:packed_ice
setblock 144 227 294 minecraft:snow_block
fill 144 227 295 144 230 295 minecraft:packed_ice
setblock 144 227 299 minecraft:snow_block
fill 144 227 300 144 230 300 minecraft:packed_ice
fill 144 227 315 144 230 315 minecraft:packed_ice
setblock 145 227 293 minecraft:snow_block
fill 145 227 294 145 229 294 minecraft:packed_ice
setblock 146 227 276 minecraft:packed_ice
setblock 146 227 277 minecraft:snow_block
setblock 147 227 276 minecraft:snow_block
fill 147 227 277 147 230 277 minecraft:packed_ice
setblock 147 227 316 minecraft:snow_block
fill 148 227 276 151 227 276 minecraft:packed_ice
fill 148 227 316 148 230 316 minecraft:packed_ice
setblock 151 227 277 minecraft:snow_block
setblock 151 227 316 minecraft:packed_ice
setblock 152 227 276 minecraft:snow_block
fill 152 227 277 152 230 277 minecraft:packed_ice
setblock 152 227 316 minecraft:snow_block
fill 153 227 276 156 227 276 minecraft:packed_ice
fill 153 227 316 156 227 316 minecraft:packed_ice
setblock 155 227 277 minecraft:packed_ice
setblock 156 227 277 minecraft:snow_block
setblock 157 227 276 minecraft:snow_block
fill 157 227 277 160 227 277 minecraft:packed_ice
setblock 157 227 286 minecraft:black_stained_glass
setblock 157 227 288 minecraft:light_blue_stained_glass
setblock 157 227 290 minecraft:sea_lantern
setblock 157 227 292 minecraft:light_blue_stained_glass
setblock 157 227 294 minecraft:light_blue_stained_glass
setblock 157 227 296 minecraft:light_blue_stained_glass
setblock 157 227 298 minecraft:sea_lantern
setblock 157 227 316 minecraft:snow_block
fill 158 227 276 161 227 276 minecraft:packed_ice
setblock 158 227 285 minecraft:light_blue_stained_glass
setblock 158 227 300 minecraft:sea_lantern
setblock 158 227 315 minecraft:snow_block
fill 158 227 316 161 227 316 minecraft:packed_ice
fill 159 227 315 162 227 315 minecraft:packed_ice
setblock 160 227 278 minecraft:snow_block
setblock 160 227 285 minecraft:sea_lantern
setblock 160 227 300 minecraft:black_stained_glass
setblock 161 227 277 minecraft:snow_block
fill 161 227 278 164 227 278 minecraft:packed_ice
fill 161 227 314 163 227 314 minecraft:packed_ice
setblock 162 227 276 minecraft:snow_block
fill 162 227 277 165 227 277 minecraft:packed_ice
setblock 162 227 285 minecraft:light_blue_stained_glass
setblock 162 227 300 minecraft:black_stained_glass
setblock 162 227 316 minecraft:snow_block
fill 163 227 276 166 227 276 minecraft:packed_ice
setblock 163 227 315 minecraft:snow_block
fill 163 227 316 166 227 316 minecraft:packed_ice
setblock 164 227 285 minecraft:sea_lantern
setblock 164 227 300 minecraft:black_stained_glass
setblock 164 227 314 minecraft:snow_block
fill 164 227 315 167 227 315 minecraft:packed_ice
fill 165 227 275 165 244 275 minecraft:packed_ice
setblock 165 227 278 minecraft:snow_block
fill 165 227 314 168 227 314 minecraft:packed_ice
setblock 166 227 277 minecraft:snow_block
fill 166 227 278 166 230 278 minecraft:packed_ice
setblock 166 227 285 minecraft:black_stained_glass
setblock 166 227 300 minecraft:sea_lantern
setblock 167 227 276 minecraft:snow_block
fill 167 227 277 167 230 277 minecraft:packed_ice
setblock 167 227 316 minecraft:snow_block
fill 168 227 276 168 230 276 minecraft:packed_ice
setblock 168 227 285 minecraft:black_stained_glass
setblock 168 227 300 minecraft:light_blue_stained_glass
setblock 168 227 315 minecraft:snow_block
fill 168 227 316 171 227 316 minecraft:packed_ice
setblock 169 227 314 minecraft:snow_block
fill 169 227 315 169 230 315 minecraft:packed_ice
setblock 170 227 285 minecraft:light_blue_stained_glass
setblock 170 227 300 minecraft:sea_lantern
fill 171 227 315 172 227 315 minecraft:packed_ice
setblock 172 227 276 minecraft:snow_block
setblock 172 227 286 minecraft:light_blue_stained_glass
setblock 172 227 288 minecraft:black_stained_glass
setblock 172 227 290 minecraft:black_stained_glass
setblock 172 227 292 minecraft:black_stained_glass
setblock 172 227 294 minecraft:sea_lantern
setblock 172 227 296 minecraft:light_blue_stained_glass
setblock 172 227 298 minecraft:light_blue_stained_glass
setblock 172 227 316 minecraft:snow_block
fill 173 227 316 173 230 316 minecraft:packed_ice
setblock 177 227 316 minecraft:snow_block
fill 178 227 316 178 230 316 minecraft:packed_ice
fill 179 227 276 180 228 276 minecraft:packed_ice
fill 179 227 315 179 230 315 minecraft:packed_ice
setblock 179 227 317 minecraft:light_blue_concrete
fill 180 227 295 180 227 297 minecraft:packed_ice
setblock 180 227 298 minecraft:snow_block
fill 180 227 299 180 230 299 minecraft:packed_ice
setblock 181 227 291 minecraft:packed_ice
setblock 181 227 292 minecraft:snow_block
fill 181 227 293 181 230 293 minecraft:packed_ice
setblock 181 227 297 minecraft:snow_block
fill 181 227 298 181 230 298 minecraft:packed_ice
setblock 181 227 301 minecraft:packed_ice
setblock 181 227 302 minecraft:snow_block
fill 181 227 303 182 228 304 minecraft:packed_ice
setblock 181 227 312 minecraft:snow_block
fill 181 227 313 181 230 313 minecraft:packed_ice
setblock 182 227 276 minecraft:snow_block
fill 182 227 277 182 230 277 minecraft:packed_ice
fill 182 227 279 182 227 280 minecraft:packed_ice
setblock 182 227 291 minecraft:snow_block
fill 182 227 292 182 230 292 minecraft:packed_ice
setblock 182 227 296 minecraft:snow_block
fill 182 227 297 182 230 297 minecraft:packed_ice
setblock 182 227 301 minecraft:snow_block
fill 182 227 302 182 230 302 minecraft:packed_ice
setblock 182 227 305 minecraft:packed_ice
setblock 182 227 306 minecraft:snow_block
fill 182 227 307 182 230 307 minecraft:packed_ice
setblock 182 227 311 minecraft:snow_block
fill 182 227 312 182 230 312 minecraft:packed_ice
setblock 182 227 316 minecraft:snow_block
fill 183 227 310 183 240 310 minecraft:packed_ice
fill 141 228 286 143 230 286 minecraft:packed_ice
fill 141 228 307 141 241 308 minecraft:packed_ice
setblock 141 228 309 minecraft:light_blue_concrete
fill 142 228 276 142 231 276 minecraft:packed_ice
setblock 142 228 280 minecraft:snow_block
fill 142 228 281 142 228 284 minecraft:packed_ice
setblock 142 228 285 minecraft:snow_block
fill 142 228 287 142 228 289 minecraft:packed_ice
setblock 142 228 290 minecraft:snow_block
fill 142 228 291 142 228 294 minecraft:packed_ice
setblock 142 228 295 minecraft:snow_block
fill 142 228 296 142 231 296 minecraft:packed_ice
setblock 142 228 300 minecraft:snow_block
fill 142 228 301 142 231 301 minecraft:packed_ice
setblock 142 228 305 minecraft:snow_block
fill 142 228 306 142 231 306 minecraft:packed_ice
fill 142 228 311 142 231 311 minecraft:packed_ice
setblock 142 228 315 minecraft:snow_block
fill 142 228 316 145 228 316 minecraft:packed_ice
setblock 143 228 279 minecraft:snow_block
fill 143 228 280 144 230 280 minecraft:packed_ice
setblock 143 228 284 minecraft:snow_block
fill 143 228 285 143 231 285 minecraft:packed_ice
fill 143 228 287 143 228 288 minecraft:packed_ice
setblock 143 228 289 minecraft:snow_block
fill 143 228 290 143 228 293 minecraft:packed_ice
setblock 143 228 294 minecraft:snow_block
fill 143 228 295 143 231 295 minecraft:packed_ice
setblock 143 228 299 minecraft:snow_block
fill 143 228 300 143 231 300 minecraft:packed_ice
setblock 143 228 303 minecraft:packed_ice
fill 143 228 315 143 231 315 minecraft:packed_ice
setblock 144 228 277 minecraft:packed_ice
setblock 144 228 278 minecraft:snow_block
fill 144 228 279 144 231 279 minecraft:packed_ice
setblock 144 228 286 minecraft:light[level=15]
fill 144 228 289 144 230 289 minecraft:packed_ice
setblock 144 228 293 minecraft:snow_block
fill 144 228 294 144 231 294 minecraft:packed_ice
setblock 144 228 298 minecraft:snow_block
fill 144 228 299 144 231 299 minecraft:packed_ice
fill 144 228 301 144 229 301 minecraft:packed_ice
setblock 144 228 302 minecraft:light[level=15]
setblock 144 228 310 minecraft:light[level=15]
setblock 145 228 277 minecraft:snow_block
fill 145 228 278 147 229 278 minecraft:packed_ice
setblock 145 228 297 minecraft:snow_block
setblock 146 228 276 minecraft:snow_block
fill 146 228 277 146 231 277 minecraft:packed_ice
setblock 146 228 316 minecraft:snow_block
fill 147 228 276 150 228 276 minecraft:packed_ice
fill 147 228 316 147 231 316 minecraft:packed_ice
setblock 150 228 277 minecraft:snow_block
setblock 151 228 276 minecraft:snow_block
fill 151 228 277 151 231 277 minecraft:packed_ice
setblock 151 228 316 minecraft:snow_block
fill 152 228 276 155 228 276 minecraft:packed_ice
setblock 152 228 278 minecraft:light[level=15]
setblock 152 228 286 minecraft:light[level=15]
setblock 152 228 294 minecraft:light[level=15]
setblock 152 228 302 minecraft:light[level=15]
setblock 152 228 310 minecraft:light[level=15]
fill 152 228 316 155 228 316 minecraft:packed_ice
fill 153 228 277 154 228 277 minecraft:packed_ice
setblock 155 228 277 minecraft:snow_block
setblock 156 228 276 minecraft:snow_block
fill 156 228 277 159 228 277 minecraft:packed_ice
setblock 156 228 316 minecraft:snow_block
fill 157 228 276 160 228 276 minecraft:packed_ice
fill 157 228 286 157 229 286 minecraft:gray_concrete
fill 157 228 288 157 229 288 minecraft:gray_concrete
fill 157 228 290 157 229 290 minecraft:gray_concrete
fill 157 228 292 157 229 292 minecraft:gray_concrete
fill 157 228 294 157 229 294 minecraft:gray_concrete
fill 157 228 296 157 229 296 minecraft:gray_concrete
fill 157 228 298 157 229 298 minecraft:gray_concrete
fill 157 228 316 160 228 316 minecraft:packed_ice
setblock 158 228 278 minecraft:packed_ice
fill 158 228 285 158 229 285 minecraft:gray_concrete
fill 158 228 300 158 229 300 minecraft:gray_concrete
fill 158 228 315 161 228 315 minecraft:packed_ice
setblock 159 228 278 minecraft:snow_block
setblock 160 228 277 minecraft:snow_block
fill 160 228 278 163 228 278 minecraft:packed_ice
fill 160 228 285 160 229 285 minecraft:gray_concrete
fill 160 228 300 160 229 300 minecraft:gray_concrete
setblock 160 228 302 minecraft:light[level=15]
setblock 160 228 310 minecraft:light[level=15]
setblock 161 228 276 minecraft:snow_block
fill 161 228 277 164 228 277 minecraft:packed_ice
fill 161 228 314 162 228 314 minecraft:packed_ice
setblock 161 228 316 minecraft:snow_block
fill 162 228 276 165 228 276 minecraft:packed_ice
fill 162 228 285 162 229 285 minecraft:gray_concrete
fill 162 228 300 162 229 300 minecraft:gray_concrete
setblock 162 228 315 minecraft:snow_block
fill 162 228 316 165 228 316 minecraft:packed_ice
setblock 163 228 314 minecraft:snow_block
fill 163 228 315 166 228 315 minecraft:packed_ice
setblock 164 228 278 minecraft:snow_block
fill 164 228 285 164 229 285 minecraft:gray_concrete
fill 164 228 300 164 229 300 minecraft:gray_concrete
fill 164 228 314 167 228 314 minecraft:packed_ice
setblock 165 228 277 minecraft:snow_block
fill 165 228 278 165 231 278 minecraft:packed_ice
setblock 166 228 276 minecraft:snow_block
fill 166 228 277 166 231 277 minecraft:packed_ice
fill 166 228 285 166 229 285 minecraft:gray_concrete
fill 166 228 300 166 229 300 minecraft:gray_concrete
setblock 166 228 316 minecraft:snow_block
fill 167 228 276 167 231 276 minecraft:packed_ice
setblock 167 228 315 minecraft:snow_block
fill 167 228 316 170 228 316 minecraft:packed_ice
setblock 168 228 278 minecraft:light[level=15]
fill 168 228 285 168 229 285 minecraft:gray_concrete
fill 168 228 300 168 229 300 minecraft:gray_concrete
setblock 168 228 302 minecraft:light[level=15]
setblock 168 228 310 minecraft:light[level=15]
setblock 168 228 314 minecraft:snow_block
fill 168 228 315 168 231 315 minecraft:packed_ice
fill 170 228 285 170 229 285 minecraft:gray_concrete
fill 170 228 300 170 229 300 minecraft:gray_concrete
setblock 171 228 276 minecraft:snow_block
setblock 171 228 315 minecraft:packed_ice
setblock 171 228 316 minecraft:snow_block
fill 172 228 276 173 230 276 minecraft:packed_ice
fill 172 228 286 172 229 286 minecraft:gray_concrete
fill 172 228 288 172 229 288 minecraft:gray_concrete
fill 172 228 290 172 229 290 minecraft:gray_concrete
fill 172 228 292 172 229 292 minecraft:gray_concrete
fill 172 228 294 172 229 294 minecraft:gray_concrete
fill 172 228 296 172 229 296 minecraft:gray_concrete
fill 172 228 298 172 229 298 minecraft:gray_concrete
setblock 172 228 315 minecraft:snow_block
fill 172 228 316 172 231 316 minecraft:packed_ice
setblock 176 228 278 minecraft:light[level=15]
setblock 176 228 286 minecraft:light[level=15]
setblock 176 228 294 minecraft:light[level=15]
setblock 176 228 302 minecraft:light[level=15]
setblock 176 228 310 minecraft:light[level=15]
setblock 176 228 316 minecraft:snow_block
setblock 176 228 317 minecraft:white_concrete
fill 177 228 276 178 230 276 minecraft:packed_ice
fill 177 228 289 177 232 289 minecraft:packed_ice
fill 177 228 316 177 231 316 minecraft:packed_ice
fill 178 228 288 178 232 288 minecraft:packed_ice
fill 178 228 290 178 232 290 minecraft:packed_ice
fill 178 228 311 178 235 311 minecraft:snow_block
fill 178 228 315 178 231 315 minecraft:packed_ice
fill 179 228 289 179 232 289 minecraft:packed_ice
fill 179 228 317 179 245 317 minecraft:packed_ice
fill 180 228 294 180 228 296 minecraft:packed_ice
setblock 180 228 297 minecraft:snow_block
fill 180 228 298 180 231 298 minecraft:packed_ice
fill 180 228 300 180 228 301 minecraft:packed_ice
setblock 180 228 302 minecraft:snow_block
setblock 181 228 276 minecraft:snow_block
fill 181 228 277 181 231 277 minecraft:packed_ice
setblock 181 228 290 minecraft:packed_ice
setblock 181 228 291 minecraft:snow_block
fill 181 228 292 181 231 292 minecraft:packed_ice
setblock 181 228 296 minecraft:snow_block
fill 181 228 297 181 231 297 minecraft:packed_ice
setblock 181 228 300 minecraft:packed_ice
setblock 181 228 301 minecraft:snow_block
fill 181 228 302 181 231 302 minecraft:packed_ice
setblock 181 228 305 minecraft:packed_ice
setblock 181 228 306 minecraft:snow_block
fill 181 228 312 181 231 312 minecraft:packed_ice
setblock 181 228 316 minecraft:snow_block
fill 182 228 276 182 231 276 minecraft:packed_ice
setblock 182 228 279 minecraft:packed_ice
setblock 182 228 280 minecraft:snow_block
fill 182 228 281 182 229 283 minecraft:packed_ice
setblock 182 228 285 minecraft:snow_block
fill 182 228 286 182 230 287 minecraft:packed_ice
setblock 182 228 290 minecraft:snow_block
fill 182 228 291 182 231 291 minecraft:packed_ice
setblock 182 228 295 minecraft:snow_block
fill 182 228 296 182 231 296 minecraft:packed_ice
setblock 182 228 300 minecraft:snow_block
fill 182 228 301 182 231 301 minecraft:packed_ice
setblock 182 228 305 minecraft:snow_block
fill 182 228 306 182 231 306 minecraft:packed_ice
setblock 182 228 310 minecraft:snow_block
fill 182 228 311 182 231 311 minecraft:packed_ice
setblock 182 228 315 minecraft:snow_block
fill 182 228 316 182 231 316 minecraft:packed_ice
fill 141 229 282 142 229 283 minecraft:packed_ice
setblock 141 229 284 minecraft:light_blue_concrete
fill 141 229 309 141 244 309 minecraft:packed_ice
setblock 141 229 313 minecraft:light_blue_concrete
fill 142 229 275 142 240 275 minecraft:packed_ice
setblock 142 229 278 minecraft:packed_ice
setblock 142 229 279 minecraft:snow_block
fill 142 229 280 142 231 281 minecraft:packed_ice
setblock 142 229 284 minecraft:snow_block
fill 142 229 285 142 232 285 minecraft:packed_ice
fill 142 229 287 142 229 288 minecraft:packed_ice
setblock 142 229 289 minecraft:snow_block
fill 142 229 290 142 229 293 minecraft:packed_ice
setblock 142 229 294 minecraft:snow_block
fill 142 229 295 142 232 295 minecraft:packed_ice
setblock 142 229 299 minecraft:snow_block
fill 142 229 300 142 232 300 minecraft:packed_ice
setblock 142 229 303 minecraft:packed_ice
setblock 142 229 304 minecraft:snow_block
fill 142 229 305 142 232 305 minecraft:packed_ice
fill 142 229 307 142 229 308 minecraft:packed_ice
fill 142 229 310 142 232 310 minecraft:packed_ice
setblock 142 229 314 minecraft:snow_block
fill 142 229 315 142 231 316 minecraft:packed_ice
setblock 143 229 275 minecraft:light_blue_concrete
setblock 143 229 278 minecraft:snow_block
fill 143 229 279 143 232 279 minecraft:packed_ice
fill 143 229 281 143 229 282 minecraft:packed_ice
setblock 143 229 283 minecraft:snow_block
fill 143 229 284 143 232 284 minecraft:packed_ice
setblock 143 229 287 minecraft:packed_ice
setblock 143 229 288 minecraft:snow_block
fill 143 229 289 143 229 292 minecraft:packed_ice
setblock 143 229 293 minecraft:snow_block
fill 143 229 294 143 232 294 minecraft:packed_ice
setblock 143 229 298 minecraft:snow_block
fill 143 229 299 143 232 299 minecraft:packed_ice
setblock 143 229 303 minecraft:snow_block
fill 143 229 304 143 232 304 minecraft:packed_ice
fill 143 229 316 144 229 316 minecraft:packed_ice
fill 144 229 275 146 240 275 minecraft:packed_ice
setblock 144 229 277 minecraft:snow_block
fill 144 229 278 144 232 278 minecraft:packed_ice
setblock 144 229 281 minecraft:packed_ice
setblock 144 229 282 minecraft:snow_block
fill 144 229 283 144 232 283 minecraft:packed_ice
setblock 144 229 292 minecraft:snow_block
fill 144 229 293 144 232 293 minecraft:packed_ice
setblock 144 229 296 minecraft:packed_ice
setblock 144 229 297 minecraft:snow_block
fill 144 229 298 144 232 298 minecraft:packed_ice
setblock 145 229 276 minecraft:snow_block
fill 145 229 277 145 232 277 minecraft:packed_ice
setblock 145 229 296 minecraft:snow_block
fill 145 229 297 145 230 297 minecraft:packed_ice
setblock 145 229 316 minecraft:snow_block
fill 146 229 276 149 229 276 minecraft:packed_ice
fill 146 229 316 146 232 316 minecraft:packed_ice
setblock 148 229 278 minecraft:snow_block
setblock 149 229 277 minecraft:snow_block
fill 149 229 278 149 232 278 minecraft:packed_ice
setblock 150 229 276 minecraft:snow_block
fill 150 229 277 150 232 277 minecraft:packed_ice
setblock 150 229 316 minecraft:snow_block
fill 151 229 276 154 229 276 minecraft:packed_ice
fill 151 229 316 154 229 316 minecraft:packed_ice
setblock 153 229 277 minecraft:packed_ice
setblock 154 229 277 minecraft:snow_block
setblock 155 229 276 minecraft:snow_block
fill 155 229 277 158 229 277 minecraft:packed_ice
setblock 155 229 316 minecraft:snow_block
fill 156 229 276 159 229 276 minecraft:packed_ice
fill 156 229 278 157 229 278 minecraft:packed_ice
fill 156 229 316 159 229 316 minecraft:packed_ice
fill 157 229 315 160 229 315 minecraft:packed_ice
setblock 158 229 278 minecraft:snow_block
setblock 159 229 277 minecraft:snow_block
fill 159 229 278 162 229 278 minecraft:packed_ice
setblock 160 229 276 minecraft:snow_block
fill 160 229 277 163 229 277 minecraft:packed_ice
fill 160 229 314 161 229 314 minecraft:packed_ice
setblock 160 229 316 minecraft:snow_block
fill 161 229 276 164 229 276 minecraft:packed_ice
setblock 161 229 315 minecraft:snow_block
fill 161 229 316 164 229 316 minecraft:packed_ice
setblock 162 229 314 minecraft:snow_block
fill 162 229 315 165 229 315 minecraft:packed_ice
setblock 163 229 278 minecraft:snow_block
fill 163 229 314 166 229 314 minecraft:packed_ice
setblock 164 229 277 minecraft:snow_block
fill 164 229 278 164 232 278 minecraft:packed_ice
setblock 165 229 276 minecraft:snow_block
fill 165 229 277 165 232 277 minecraft:packed_ice
setblock 165 229 316 minecraft:snow_block
fill 166 229 276 166 232 276 minecraft:packed_ice
setblock 166 229 315 minecraft:snow_block
fill 166 229 316 169 229 316 minecraft:packed_ice
setblock 167 229 314 minecraft:snow_block
fill 167 229 315 167 232 315 minecraft:packed_ice
setblock 168 229 314 minecraft:packed_ice
setblock 169 229 277 minecraft:snow_block
setblock 170 229 276 minecraft:snow_block
setblock 170 229 316 minecraft:snow_block
fill 171 229 276 171 232 276 minecraft:packed_ice
setblock 171 229 315 minecraft:snow_block
fill 171 229 316 171 232 316 minecraft:packed_ice
setblock 174 229 276 minecraft:packed_ice
setblock 175 229 276 minecraft:snow_block
setblock 175 229 316 minecraft:snow_block
fill 176 229 276 176 232 276 minecraft:packed_ice
fill 176 229 316 176 232 317 minecraft:packed_ice
setblock 179 229 276 minecraft:packed_ice
fill 179 229 298 179 231 299 minecraft:packed_ice
setblock 180 229 276 minecraft:snow_block
fill 180 229 277 180 232 277 minecraft:packed_ice
fill 180 229 293 180 229 295 minecraft:packed_ice
setblock 180 229 296 minecraft:snow_block
fill 180 229 297 180 232 297 minecraft:packed_ice
setblock 180 229 300 minecraft:packed_ice
setblock 180 229 301 minecraft:snow_block
fill 180 229 302 180 231 303 minecraft:packed_ice
setblock 180 229 316 minecraft:snow_block
fill 181 229 276 181 232 276 minecraft:packed_ice
fill 181 229 278 181 229 279 minecraft:packed_ice
setblock 181 229 290 minecraft:snow_block
fill 181 229 291 181 232 291 minecraft:packed_ice
setblock 181 229 295 minecraft:snow_block
fill 181 229 296 181 232 296 minecraft:packed_ice
setblock 181 229 300 minecraft:snow_block
fill 181 229 301 181 232 301 minecraft:packed_ice
fill 181 229 303 181 229 304 minecraft:packed_ice
setblock 181 229 305 minecraft:snow_block
fill 181 229 306 181 230 308 minecraft:packed_ice
fill 181 229 311 181 232 311 minecraft:packed_ice
setblock 181 229 315 minecraft:snow_block
fill 181 229 316 181 232 316 minecraft:packed_ice
setblock 182 229 279 minecraft:snow_block
fill 182 229 280 182 232 280 minecraft:packed_ice
setblock 182 229 284 minecraft:snow_block
fill 182 229 285 182 232 285 minecraft:packed_ice
setblock 182 229 289 minecraft:snow_block
fill 182 229 290 182 232 290 minecraft:packed_ice
setblock 182 229 294 minecraft:snow_block
fill 182 229 295 182 232 295 minecraft:packed_ice
setblock 182 229 299 minecraft:snow_block
fill 182 229 300 182 232 300 minecraft:packed_ice
setblock 182 229 303 minecraft:packed_ice
setblock 182 229 304 minecraft:snow_block
fill 182 229 305 182 232 305 minecraft:packed_ice
setblock 182 229 309 minecraft:snow_block
fill 182 229 310 182 232 310 minecraft:packed_ice
setblock 182 229 314 minecraft:snow_block
fill 182 229 315 182 232 315 minecraft:packed_ice
fill 141 230 282 141 240 284 minecraft:packed_ice
setblock 141 230 301 minecraft:light_blue_concrete
fill 141 230 313 141 242 313 minecraft:packed_ice
setblock 142 230 278 minecraft:snow_block
fill 142 230 279 142 233 279 minecraft:packed_ice
setblock 142 230 282 minecraft:packed_ice
setblock 142 230 283 minecraft:snow_block
fill 142 230 284 142 233 284 minecraft:packed_ice
setblock 142 230 287 minecraft:packed_ice
setblock 142 230 288 minecraft:snow_block
fill 142 230 289 142 230 292 minecraft:packed_ice
setblock 142 230 293 minecraft:snow_block
fill 142 230 294 142 233 294 minecraft:packed_ice
setblock 142 230 298 minecraft:snow_block
fill 142 230 299 142 233 299 minecraft:packed_ice
setblock 142 230 302 minecraft:packed_ice
setblock 142 230 303 minecraft:snow_block
fill 142 230 304 142 233 304 minecraft:packed_ice
setblock 142 230 307 minecraft:packed_ice
setblock 142 230 308 minecraft:snow_block
fill 142 230 309 142 233 309 minecraft:packed_ice
setblock 142 230 313 minecraft:snow_block
fill 142 230 314 142 233 314 minecraft:packed_ice
fill 143 230 275 143 245 275 minecraft:packed_ice
setblock 143 230 277 minecraft:snow_block
fill 143 230 278 143 233 278 minecraft:packed_ice
setblock 143 230 281 minecraft:packed_ice
setblock 143 230 282 minecraft:snow_block
fill 143 230 283 143 233 283 minecraft:packed_ice
setblock 143 230 287 minecraft:snow_block
fill 143 230 288 143 230 291 minecraft:packed_ice
setblock 143 230 292 minecraft:snow_block
fill 143 230 293 143 233 293 minecraft:packed_ice
setblock 143 230 297 minecraft:snow_block
fill 143 230 298 143 233 298 minecraft:packed_ice
setblock 143 230 302 minecraft:snow_block
fill 143 230 303 143 233 303 minecraft:packed_ice
fill 143 230 305 143 231 305 minecraft:packed_ice
fill 143 230 308 143 233 310 minecraft:blue_ice
setblock 143 230 316 minecraft:packed_ice
setblock 144 230 276 minecraft:snow_block
fill 144 230 277 144 233 277 minecraft:packed_ice
setblock 144 230 281 minecraft:snow_block
fill 144 230 282 144 233 282 minecraft:packed_ice
fill 144 230 284 144 230 285 minecraft:packed_ice
setblock 144 230 291 minecraft:snow_block
fill 144 230 292 144 232 292 minecraft:packed_ice
setblock 144 230 296 minecraft:snow_block
fill 144 230 297 144 233 297 minecraft:packed_ice
setblock 144 230 301 minecraft:snow_block
fill 144 230 302 144 233 302 minecraft:packed_ice
setblock 144 230 316 minecraft:snow_block
fill 145 230 276 148 230 276 minecraft:packed_ice
fill 145 230 278 145 230 279 minecraft:packed_ice
setblock 145 230 296 minecraft:packed_ice
fill 145 230 316 145 233 316 minecraft:packed_ice
setblock 146 230 278 minecraft:packed_ice
setblock 147 230 278 minecraft:snow_block
setblock 148 230 277 minecraft:snow_block
fill 148 230 278 148 233 278 minecraft:packed_ice
setblock 149 230 276 minecraft:snow_block
fill 149 230 277 149 233 277 minecraft:packed_ice
setblock 149 230 316 minecraft:snow_block
fill 150 230 276 153 230 276 minecraft:packed_ice
fill 150 230 278 150 231 278 minecraft:packed_ice
fill 150 230 316 153 230 316 minecraft:packed_ice
setblock 153 230 277 minecraft:snow_block
setblock 154 230 276 minecraft:snow_block
fill 154 230 277 156 230 278 minecraft:packed_ice
setblock 154 230 316 minecraft:snow_block
fill 155 230 276 158 230 276 minecraft:packed_ice
fill 155 230 316 158 230 316 minecraft:packed_ice
fill 156 230 315 159 230 315 minecraft:packed_ice
setblock 157 230 277 minecraft:packed_ice
setblock 157 230 278 minecraft:snow_block
setblock 157 230 286 minecraft:sea_lantern
setblock 157 230 288 minecraft:black_stained_glass
setblock 157 230 290 minecraft:light_blue_stained_glass
setblock 157 230 292 minecraft:black_stained_glass
setblock 157 230 294 minecraft:black_stained_glass
setblock 157 230 296 minecraft:light_blue_stained_glass
setblock 157 230 298 minecraft:black_stained_glass
setblock 158 230 277 minecraft:snow_block
fill 158 230 278 161 230 278 minecraft:packed_ice
setblock 158 230 285 minecraft:black_stained_glass
setblock 158 230 300 minecraft:sea_lantern
setblock 159 230 276 minecraft:snow_block
fill 159 230 277 162 230 277 minecraft:packed_ice
fill 159 230 279 160 230 279 minecraft:packed_ice
fill 159 230 314 160 230 314 minecraft:packed_ice
setblock 159 230 316 minecraft:snow_block
fill 160 230 276 163 230 276 minecraft:packed_ice
setblock 160 230 285 minecraft:light_blue_stained_glass
setblock 160 230 300 minecraft:light_blue_stained_glass
setblock 160 230 315 minecraft:snow_block
fill 160 230 316 163 230 316 minecraft:packed_ice
setblock 161 230 279 minecraft:snow_block
setblock 161 230 314 minecraft:snow_block
fill 161 230 315 164 230 315 minecraft:packed_ice
setblock 162 230 278 minecraft:snow_block
fill 162 230 279 163 232 279 minecraft:packed_ice
setblock 162 230 285 minecraft:black_stained_glass
setblock 162 230 300 minecraft:black_stained_glass
fill 162 230 314 165 230 314 minecraft:packed_ice
setblock 163 230 277 minecraft:snow_block
fill 163 230 278 163 233 278 minecraft:packed_ice
setblock 164 230 276 minecraft:snow_block
fill 164 230 277 164 233 277 minecraft:packed_ice
setblock 164 230 285 minecraft:sea_lantern
setblock 164 230 300 minecraft:sea_lantern
setblock 164 230 316 minecraft:snow_block
fill 165 230 276 165 233 276 minecraft:packed_ice
setblock 165 230 315 minecraft:snow_block
fill 165 230 316 168 230 316 minecraft:packed_ice
setblock 166 230 285 minecraft:light_blue_stained_glass
setblock 166 230 300 minecraft:light_blue_stained_glass
setblock 166 230 314 minecraft:snow_block
fill 166 230 315 166 233 315 minecraft:packed_ice
setblock 167 230 278 minecraft:snow_block
setblock 167 230 314 minecraft:packed_ice
setblock 168 230 277 minecraft:snow_block
setblock 168 230 285 minecraft:sea_lantern
setblock 168 230 300 minecraft:black_stained_glass
setblock 169 230 276 minecraft:snow_block
fill 169 230 277 169 231 277 minecraft:packed_ice
setblock 169 230 316 minecraft:snow_block
fill 170 230 276 170 233 276 minecraft:packed_ice
setblock 170 230 285 minecraft:black_stained_glass
setblock 170 230 300 minecraft:sea_lantern
setblock 170 230 315 minecraft:snow_block
fill 170 230 316 170 233 316 minecraft:packed_ice
setblock 171 230 315 minecraft:packed_ice
setblock 172 230 286 minecraft:black_stained_glass
setblock 172 230 288 minecraft:black_stained_glass
setblock 172 230 290 minecraft:light_blue_stained_glass
setblock 172 230 292 minecraft:black_stained_glass
setblock 172 230 294 minecraft:black_stained_glass
setblock 172 230 296 minecraft:black_stained_glass
setblock 172 230 298 minecraft:light_blue_stained_glass
setblock 174 230 276 minecraft:snow_block
setblock 174 230 316 minecraft:snow_block
fill 175 230 276 175 233 276 minecraft:packed_ice
fill 175 230 316 175 233 316 minecraft:packed_ice
fill 177 230 315 177 231 315 minecraft:packed_ice
setblock 178 230 277 minecraft:snow_block
setblock 179 230 276 minecraft:snow_block
fill 179 230 277 179 233 277 minecraft:packed_ice
setblock 179 230 296 minecraft:snow_block
fill 179 230 297 179 233 297 minecraft:packed_ice
setblock 179 230 300 minecraft:packed_ice
setblock 179 230 301 minecraft:snow_block
setblock 179 230 316 minecraft:snow_block
fill 180 230 276 180 233 276 minecraft:packed_ice
fill 180 230 293 180 230 294 minecraft:packed_ice
setblock 180 230 295 minecraft:snow_block
fill 180 230 296 180 233 296 minecraft:packed_ice
setblock 180 230 300 minecraft:snow_block
fill 180 230 301 180 233 301 minecraft:packed_ice
setblock 180 230 304 minecraft:packed_ice
setblock 180 230 305 minecraft:snow_block
setblock 180 230 315 minecraft:snow_block
fill 180 230 316 180 233 316 minecraft:packed_ice
setblock 181 230 278 minecraft:packed_ice
setblock 181 230 279 minecraft:snow_block
fill 181 230 280 181 231 282 minecraft:packed_ice
setblock 181 230 289 minecraft:snow_block
fill 181 230 290 181 233 290 minecraft:packed_ice
setblock 181 230 294 minecraft:snow_block
fill 181 230 295 181 233 295 minecraft:packed_ice
setblock 181 230 299 minecraft:snow_block
fill 181 230 300 181 233 300 minecraft:packed_ice
setblock 181 230 303 minecraft:packed_ice
setblock 181 230 304 minecraft:snow_block
fill 181 230 305 181 233 305 minecraft:packed_ice
setblock 181 230 309 minecraft:snow_block
fill 181 230 310 181 233 310 minecraft:packed_ice
setblock 181 230 314 minecraft:snow_block
fill 181 230 315 181 233 315 minecraft:packed_ice
setblock 182 230 278 minecraft:snow_block
fill 182 230 279 182 233 279 minecraft:packed_ice
fill 182 230 281 182 230 282 minecraft:packed_ice
setblock 182 230 283 minecraft:snow_block
fill 182 230 284 182 233 284 minecraft:packed_ice
setblock 182 230 288 minecraft:snow_block
fill 182 230 289 182 233 289 minecraft:packed_ice
setblock 182 230 293 minecraft:snow_block
fill 182 230 294 182 233 294 minecraft:packed_ice
setblock 182 230 298 minecraft:snow_block
fill 182 230 299 182 233 299 minecraft:packed_ice
setblock 182 230 303 minecraft:snow_block
fill 182 230 304 182 233 304 minecraft:packed_ice
setblock 182 230 308 minecraft:snow_block
fill 182 230 309 182 233 309 minecraft:packed_ice
setblock 182 230 313 minecraft:snow_block
fill 182 230 314 182 233 314 minecraft:packed_ice
fill 141 231 286 142 231 286 minecraft:packed_ice
fill 141 231 301 141 232 301 minecraft:packed_ice
setblock 142 231 277 minecraft:snow_block
fill 142 231 278 142 234 278 minecraft:packed_ice
setblock 142 231 282 minecraft:snow_block
fill 142 231 283 142 234 283 minecraft:packed_ice
setblock 142 231 287 minecraft:snow_block
fill 142 231 288 142 231 291 minecraft:packed_ice
setblock 142 231 292 minecraft:snow_block
fill 142 231 293 142 234 293 minecraft:packed_ice
setblock 142 231 297 minecraft:snow_block
fill 142 231 298 142 234 298 minecraft:packed_ice
setblock 142 231 302 minecraft:snow_block
fill 142 231 303 142 234 303 minecraft:packed_ice
setblock 142 231 307 minecraft:snow_block
fill 142 231 308 142 234 308 minecraft:packed_ice
setblock 142 231 312 minecraft:snow_block
fill 142 231 313 142 233 313 minecraft:packed_ice
setblock 143 231 276 minecraft:snow_block
fill 143 231 277 143 234 277 minecraft:packed_ice
setblock 143 231 280 minecraft:packed_ice
setblock 143 231 281 minecraft:snow_block
fill 143 231 282 143 234 282 minecraft:packed_ice
setblock 143 231 286 minecraft:snow_block
fill 143 231 287 143 231 290 minecraft:packed_ice
setblock 143 231 291 minecraft:snow_block
fill 143 231 292 143 234 292 minecraft:packed_ice
setblock 143 231 296 minecraft:snow_block
fill 143 231 297 143 234 297 minecraft:packed_ice
setblock 143 231 301 minecraft:snow_block
fill 143 231 302 143 234 302 minecraft:packed_ice
setblock 143 231 316 minecraft:snow_block
fill 144 231 276 147 231 276 minecraft:packed_ice
setblock 144 231 280 minecraft:snow_block
fill 144 231 281 144 234 281 minecraft:packed_ice
setblock 144 231 284 minecraft:packed_ice
setblock 144 231 285 minecraft:snow_block
fill 144 231 286 144 234 286 minecraft:packed_ice
setblock 144 231 290 minecraft:snow_block
setblock 144 231 291 minecraft:packed_ice
setblock 144 231 295 minecraft:snow_block
fill 144 231 296 144 233 296 minecraft:packed_ice
setblock 144 231 300 minecraft:snow_block
fill 144 231 301 144 233 301 minecraft:packed_ice
fill 144 231 308 144 233 310 minecraft:blue_ice
fill 144 231 316 144 234 316 minecraft:packed_ice
setblock 145 231 278 minecraft:packed_ice
setblock 145 231 279 minecraft:snow_block
fill 145 231 280 145 233 280 minecraft:packed_ice
setblock 146 231 278 minecraft:snow_block
fill 146 231 279 146 232 279 minecraft:packed_ice
setblock 147 231 277 minecraft:snow_block
fill 147 231 278 147 237 278 minecraft:packed_ice
setblock 148 231 276 minecraft:snow_block
fill 148 231 277 148 234 277 minecraft:packed_ice
setblock 148 231 316 minecraft:snow_block
fill 149 231 276 152 231 276 minecraft:packed_ice
fill 149 231 316 152 231 316 minecraft:packed_ice
setblock 151 231 278 minecraft:snow_block
setblock 152 231 277 minecraft:snow_block
fill 152 231 278 155 231 278 minecraft:packed_ice
setblock 153 231 276 minecraft:snow_block
fill 153 231 277 156 231 277 minecraft:packed_ice
setblock 153 231 316 minecraft:snow_block
fill 154 231 276 157 231 276 minecraft:packed_ice
fill 154 231 316 157 231 316 minecraft:packed_ice
setblock 156 231 278 minecraft:snow_block
fill 156 231 315 158 231 315 minecraft:packed_ice
setblock 157 231 277 minecraft:snow_block
fill 157 231 278 159 231 279 minecraft:packed_ice
fill 157 231 286 157 234 286 minecraft:gray_concrete
fill 157 231 288 157 234 288 minecraft:gray_concrete
fill 157 231 290 157 234 290 minecraft:gray_concrete
fill 157 231 292 157 234 292 minecraft:gray_concrete
fill 157 231 294 157 234 294 minecraft:gray_concrete
fill 157 231 296 157 234 296 minecraft:gray_concrete
fill 157 231 298 157 234 298 minecraft:gray_concrete
setblock 158 231 276 minecraft:snow_block
fill 158 231 277 161 231 277 minecraft:packed_ice
fill 158 231 285 158 233 285 minecraft:gray_concrete
fill 158 231 300 158 234 300 minecraft:gray_concrete
setblock 158 231 316 minecraft:snow_block
fill 159 231 276 162 231 276 minecraft:packed_ice
setblock 159 231 314 minecraft:packed_ice
setblock 159 231 315 minecraft:snow_block
fill 159 231 316 162 231 316 minecraft:packed_ice
setblock 160 231 278 minecraft:packed_ice
setblock 160 231 279 minecraft:snow_block
fill 160 231 285 160 233 285 minecraft:gray_concrete
fill 160 231 300 160 234 300 minecraft:gray_concrete
setblock 160 231 314 minecraft:snow_block
fill 160 231 315 163 231 315 minecraft:packed_ice
setblock 161 231 278 minecraft:snow_block
fill 161 231 279 161 234 279 minecraft:packed_ice
fill 161 231 314 164 231 314 minecraft:packed_ice
setblock 162 231 277 minecraft:snow_block
fill 162 231 278 162 234 278 minecraft:packed_ice
fill 162 231 285 162 233 285 minecraft:gray_concrete
fill 162 231 300 162 234 300 minecraft:gray_concrete
setblock 163 231 276 minecraft:snow_block
fill 163 231 277 163 234 277 minecraft:packed_ice
setblock 163 231 316 minecraft:snow_block
fill 163 231 317 163 242 317 minecraft:packed_ice
fill 164 231 276 164 234 276 minecraft:packed_ice
setblock 164 231 279 minecraft:packed_ice
fill 164 231 285 164 233 285 minecraft:gray_concrete
fill 164 231 300 164 234 300 minecraft:gray_concrete
setblock 164 231 315 minecraft:snow_block
fill 164 231 316 167 231 316 minecraft:packed_ice
setblock 164 231 317 minecraft:white_concrete
setblock 165 231 314 minecraft:snow_block
fill 165 231 315 165 234 315 minecraft:packed_ice
fill 165 231 317 167 232 317 minecraft:packed_ice
setblock 166 231 278 minecraft:snow_block
fill 166 231 285 166 233 285 minecraft:gray_concrete
fill 166 231 300 166 234 300 minecraft:gray_concrete
setblock 166 231 314 minecraft:packed_ice
setblock 167 231 277 minecraft:snow_block
setblock 168 231 276 minecraft:snow_block
fill 168 231 277 168 233 277 minecraft:packed_ice
fill 168 231 285 168 233 285 minecraft:gray_concrete
fill 168 231 300 168 234 300 minecraft:gray_concrete
setblock 168 231 316 minecraft:snow_block
fill 169 231 276 169 234 276 minecraft:packed_ice
setblock 169 231 315 minecraft:snow_block
fill 169 231 316 169 234 316 minecraft:packed_ice
fill 170 231 285 170 233 285 minecraft:gray_concrete
fill 170 231 300 170 234 300 minecraft:gray_concrete
setblock 170 231 315 minecraft:packed_ice
setblock 172 231 276 minecraft:packed_ice
fill 172 231 286 172 234 286 minecraft:gray_concrete
fill 172 231 288 172 234 288 minecraft:gray_concrete
fill 172 231 290 172 234 290 minecraft:gray_concrete
fill 172 231 292 172 234 292 minecraft:gray_concrete
fill 172 231 294 172 234 294 minecraft:gray_concrete
fill 172 231 296 172 234 296 minecraft:gray_concrete
fill 172 231 298 172 234 298 minecraft:gray_concrete
setblock 173 231 276 minecraft:snow_block
setblock 173 231 316 minecraft:snow_block
fill 174 231 276 174 234 276 minecraft:packed_ice
fill 174 231 316 174 234 316 minecraft:packed_ice
setblock 177 231 276 minecraft:packed_ice
setblock 177 231 277 minecraft:snow_block
fill 177 231 288 177 232 288 minecraft:packed_ice
schedule function dropper:buildpart/63_8 1t
