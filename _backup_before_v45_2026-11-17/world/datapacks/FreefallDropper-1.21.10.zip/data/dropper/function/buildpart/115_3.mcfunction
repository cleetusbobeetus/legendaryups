setblock 346 81 504 minecraft:red_nether_bricks
setblock 347 81 504 minecraft:pink_terracotta
setblock 350 81 464 minecraft:pink_terracotta
setblock 351 81 464 minecraft:red_nether_bricks
setblock 351 81 504 minecraft:red_nether_bricks
fill 352 81 464 355 81 464 minecraft:pink_terracotta
fill 352 81 504 352 82 504 minecraft:pink_terracotta
fill 353 81 465 354 81 465 minecraft:pink_terracotta
setblock 353 81 503 minecraft:pink_terracotta
setblock 355 81 465 minecraft:red_nether_bricks
setblock 356 81 464 minecraft:red_nether_bricks
fill 356 81 465 356 82 465 minecraft:pink_terracotta
setblock 356 81 504 minecraft:red_nether_bricks
fill 357 81 464 357 82 464 minecraft:pink_terracotta
setblock 357 81 503 minecraft:red_nether_bricks
fill 357 81 504 357 82 504 minecraft:pink_terracotta
setblock 358 81 480 minecraft:white_concrete
setblock 358 81 503 minecraft:pink_terracotta
setblock 360 81 465 minecraft:red_nether_bricks
setblock 361 81 464 minecraft:red_nether_bricks
fill 361 81 465 361 82 465 minecraft:pink_terracotta
setblock 361 81 504 minecraft:red_nether_bricks
fill 362 81 464 362 82 464 minecraft:pink_terracotta
setblock 362 81 504 minecraft:pink_terracotta
setblock 364 81 465 minecraft:pink_terracotta
setblock 364 81 504 minecraft:white_concrete
setblock 366 81 464 minecraft:red_nether_bricks
fill 367 81 464 367 82 464 minecraft:pink_terracotta
setblock 369 81 465 minecraft:pink_terracotta
setblock 369 81 466 minecraft:red_nether_bricks
fill 369 81 467 369 82 467 minecraft:pink_terracotta
setblock 370 81 465 minecraft:red_nether_bricks
fill 370 81 466 370 82 466 minecraft:pink_terracotta
setblock 370 81 470 minecraft:red_nether_bricks
fill 370 81 471 370 82 471 minecraft:pink_terracotta
setblock 370 81 474 minecraft:white_concrete
setblock 370 81 480 minecraft:red_nether_bricks
fill 370 81 481 370 82 481 minecraft:pink_terracotta
setblock 370 81 485 minecraft:red_nether_bricks
fill 370 81 486 370 82 486 minecraft:pink_terracotta
setblock 370 81 499 minecraft:white_concrete
setblock 330 82 464 minecraft:red_nether_bricks
setblock 330 82 465 minecraft:pink_terracotta
setblock 330 82 469 minecraft:red_nether_bricks
setblock 330 82 470 minecraft:pink_terracotta
setblock 330 82 475 minecraft:white_concrete
setblock 330 82 484 minecraft:red_nether_bricks
setblock 330 82 485 minecraft:pink_terracotta
setblock 330 82 500 minecraft:white_concrete
setblock 330 82 504 minecraft:red_nether_bricks
setblock 331 82 464 minecraft:pink_terracotta
setblock 331 82 468 minecraft:red_nether_bricks
setblock 331 82 469 minecraft:pink_terracotta
setblock 331 82 503 minecraft:red_nether_bricks
setblock 331 82 504 minecraft:pink_terracotta
setblock 332 82 467 minecraft:red_nether_bricks
setblock 332 82 503 minecraft:pink_terracotta
setblock 333 82 466 minecraft:red_nether_bricks
setblock 334 82 465 minecraft:red_nether_bricks
setblock 334 82 466 minecraft:pink_terracotta
setblock 335 82 464 minecraft:red_nether_bricks
setblock 335 82 465 minecraft:pink_terracotta
setblock 335 82 504 minecraft:red_nether_bricks
setblock 336 82 464 minecraft:pink_terracotta
setblock 336 82 503 minecraft:red_nether_bricks
setblock 336 82 504 minecraft:pink_terracotta
setblock 337 82 502 minecraft:red_nether_bricks
setblock 337 82 503 minecraft:pink_terracotta
setblock 338 82 466 minecraft:red_nether_bricks
setblock 338 82 502 minecraft:pink_terracotta
setblock 339 82 465 minecraft:red_nether_bricks
setblock 340 82 464 minecraft:red_nether_bricks
setblock 340 82 465 minecraft:pink_terracotta
setblock 340 82 504 minecraft:red_nether_bricks
setblock 341 82 464 minecraft:pink_terracotta
setblock 341 82 503 minecraft:red_nether_bricks
fill 341 82 504 344 82 504 minecraft:pink_terracotta
setblock 345 82 504 minecraft:red_nether_bricks
setblock 350 82 464 minecraft:red_nether_bricks
setblock 350 82 504 minecraft:red_nether_bricks
fill 351 82 464 354 82 464 minecraft:pink_terracotta
setblock 351 82 504 minecraft:pink_terracotta
setblock 353 82 465 minecraft:pink_terracotta
setblock 354 82 465 minecraft:red_nether_bricks
setblock 355 82 464 minecraft:red_nether_bricks
setblock 355 82 465 minecraft:pink_terracotta
setblock 355 82 504 minecraft:red_nether_bricks
setblock 356 82 464 minecraft:pink_terracotta
setblock 356 82 504 minecraft:pink_terracotta
setblock 359 82 465 minecraft:red_nether_bricks
setblock 360 82 464 minecraft:red_nether_bricks
setblock 360 82 465 minecraft:pink_terracotta
setblock 360 82 504 minecraft:red_nether_bricks
setblock 361 82 464 minecraft:pink_terracotta
setblock 365 82 464 minecraft:red_nether_bricks
setblock 366 82 464 minecraft:pink_terracotta
setblock 369 82 465 minecraft:red_nether_bricks
setblock 369 82 466 minecraft:pink_terracotta
setblock 369 82 469 minecraft:pink_terracotta
setblock 370 82 464 minecraft:red_nether_bricks
setblock 370 82 465 minecraft:pink_terracotta
setblock 370 82 469 minecraft:red_nether_bricks
setblock 370 82 470 minecraft:pink_terracotta
setblock 370 82 480 minecraft:pink_terracotta
setblock 370 82 484 minecraft:red_nether_bricks
setblock 370 82 485 minecraft:pink_terracotta
setblock 370 82 493 minecraft:white_concrete
setblock 370 82 504 minecraft:red_nether_bricks
setblock 332 87 466 minecraft:light[level=12]
setblock 332 87 474 minecraft:light[level=12]
setblock 332 87 482 minecraft:light[level=12]
setblock 332 87 490 minecraft:light[level=12]
setblock 332 87 498 minecraft:light[level=12]
setblock 340 87 466 minecraft:light[level=12]
setblock 340 87 474 minecraft:light[level=12]
setblock 340 87 482 minecraft:light[level=12]
setblock 340 87 490 minecraft:light[level=12]
setblock 340 87 498 minecraft:light[level=12]
setblock 348 87 466 minecraft:light[level=12]
setblock 348 87 474 minecraft:light[level=12]
setblock 348 87 482 minecraft:light[level=12]
setblock 348 87 490 minecraft:light[level=12]
setblock 348 87 498 minecraft:light[level=12]
fill 349 87 481 351 87 483 minecraft:redstone_block
fill 353 87 489 355 87 491 minecraft:redstone_block
setblock 356 87 466 minecraft:light[level=12]
setblock 356 87 474 minecraft:light[level=12]
fill 356 87 480 358 87 482 minecraft:redstone_block
setblock 356 87 490 minecraft:light[level=12]
setblock 356 87 498 minecraft:light[level=12]
setblock 364 87 466 minecraft:light[level=12]
setblock 364 87 474 minecraft:light[level=12]
setblock 364 87 482 minecraft:light[level=12]
setblock 364 87 490 minecraft:light[level=12]
setblock 364 87 498 minecraft:light[level=12]
fill 341 88 485 342 89 485 minecraft:red_nether_bricks
fill 342 88 482 343 89 484 minecraft:red_nether_bricks
fill 342 88 486 343 89 488 minecraft:red_nether_bricks
fill 343 88 481 345 89 481 minecraft:red_nether_bricks
fill 343 88 485 349 89 485 minecraft:white_concrete
fill 343 88 489 345 89 489 minecraft:red_nether_bricks
fill 344 88 480 346 89 480 minecraft:red_nether_bricks
fill 344 88 482 344 89 482 minecraft:red_nether_bricks
fill 344 88 483 348 88 484 minecraft:white_concrete
fill 344 88 486 349 89 487 minecraft:white_concrete
fill 344 88 488 344 89 488 minecraft:red_nether_bricks
fill 344 88 490 346 89 490 minecraft:red_nether_bricks
fill 345 88 479 348 89 479 minecraft:red_nether_bricks
fill 345 88 482 348 88 482 minecraft:white_concrete
fill 345 88 488 350 89 488 minecraft:white_concrete
fill 345 88 491 348 89 491 minecraft:red_nether_bricks
fill 346 88 481 348 88 481 minecraft:white_concrete
fill 346 88 489 351 89 489 minecraft:white_concrete
fill 347 88 478 361 89 478 minecraft:red_nether_bricks
fill 347 88 480 355 88 480 minecraft:white_concrete
fill 347 88 490 352 88 490 minecraft:white_concrete
fill 347 88 492 361 88 492 minecraft:red_nether_bricks
fill 349 88 477 359 89 477 minecraft:red_nether_bricks
fill 349 88 479 359 88 479 minecraft:white_concrete
setblock 349 88 484 minecraft:white_concrete
fill 349 88 491 352 88 491 minecraft:white_concrete
fill 349 88 493 359 89 493 minecraft:red_nether_bricks
fill 350 88 484 351 88 486 minecraft:black_concrete
fill 350 88 487 350 89 487 minecraft:gray_concrete
fill 351 88 487 352 88 488 minecraft:black_concrete
fill 352 88 481 352 88 483 minecraft:black_concrete
setblock 352 88 484 minecraft:gray_concrete
setblock 352 88 485 minecraft:black_concrete
setblock 352 88 486 minecraft:gray_concrete
setblock 352 88 489 minecraft:black_concrete
fill 353 88 481 353 89 481 minecraft:black_concrete
fill 353 88 482 355 88 482 minecraft:gray_concrete
fill 353 88 483 357 88 483 minecraft:black_concrete
fill 353 88 487 357 88 487 minecraft:black_concrete
fill 353 88 488 355 88 488 minecraft:gray_concrete
fill 354 88 481 354 89 481 minecraft:gray_concrete
setblock 355 88 481 minecraft:black_concrete
setblock 356 88 484 minecraft:gray_concrete
fill 356 88 485 358 88 485 minecraft:black_concrete
setblock 356 88 486 minecraft:gray_concrete
fill 356 88 488 356 88 489 minecraft:black_concrete
fill 356 88 490 359 88 491 minecraft:white_concrete
fill 357 88 484 358 89 484 minecraft:black_concrete
fill 357 88 486 358 89 486 minecraft:black_concrete
fill 357 88 488 357 89 488 minecraft:black_concrete
fill 357 88 489 362 89 489 minecraft:white_concrete
setblock 358 88 483 minecraft:gray_concrete
fill 358 88 487 358 89 487 minecraft:gray_concrete
fill 358 88 488 363 89 488 minecraft:white_concrete
fill 359 88 480 361 88 487 minecraft:white_concrete
fill 360 88 479 363 89 479 minecraft:red_nether_bricks
fill 360 88 490 361 89 490 minecraft:white_concrete
fill 360 88 491 363 89 491 minecraft:red_nether_bricks
fill 362 88 480 364 89 480 minecraft:red_nether_bricks
fill 362 88 481 362 89 487 minecraft:white_concrete
fill 362 88 490 364 89 490 minecraft:red_nether_bricks
fill 363 88 481 365 89 481 minecraft:red_nether_bricks
fill 363 88 482 363 89 487 minecraft:white_concrete
fill 363 88 489 365 89 489 minecraft:red_nether_bricks
fill 364 88 482 366 89 482 minecraft:red_nether_bricks
fill 364 88 483 364 89 487 minecraft:white_concrete
fill 364 88 488 366 89 488 minecraft:red_nether_bricks
fill 365 88 483 366 89 484 minecraft:red_nether_bricks
fill 365 88 485 365 89 485 minecraft:white_concrete
fill 365 88 486 366 89 487 minecraft:red_nether_bricks
fill 366 88 485 367 89 485 minecraft:red_nether_bricks
fill 330 89 464 340 89 504 minecraft:red_nether_bricks
fill 341 89 464 341 89 484 minecraft:red_nether_bricks
fill 341 89 486 341 89 504 minecraft:red_nether_bricks
fill 342 89 464 342 89 481 minecraft:red_nether_bricks
fill 342 89 489 342 89 504 minecraft:red_nether_bricks
fill 343 89 464 343 89 480 minecraft:red_nether_bricks
fill 343 89 490 343 89 504 minecraft:red_nether_bricks
fill 344 89 464 344 89 479 minecraft:red_nether_bricks
fill 344 89 483 347 89 484 minecraft:white_concrete
fill 344 89 491 344 89 504 minecraft:red_nether_bricks
fill 345 89 464 346 89 478 minecraft:red_nether_bricks
fill 345 89 482 347 89 482 minecraft:white_concrete
fill 345 89 492 348 89 504 minecraft:red_nether_bricks
fill 346 89 481 347 89 481 minecraft:white_concrete
fill 347 89 464 348 89 477 minecraft:red_nether_bricks
setblock 347 89 480 minecraft:white_concrete
fill 347 89 490 351 89 490 minecraft:white_concrete
fill 348 89 480 348 89 484 minecraft:shroomlight
fill 349 89 464 370 89 476 minecraft:red_nether_bricks
fill 349 89 479 354 89 479 minecraft:white_concrete
fill 349 89 480 352 89 480 minecraft:shroomlight
fill 349 89 481 351 89 483 minecraft:red_nether_bricks
fill 349 89 484 352 89 484 minecraft:shroomlight
fill 349 89 491 351 89 491 minecraft:white_concrete
fill 349 89 492 351 89 492 minecraft:red_nether_bricks
fill 349 89 494 370 89 504 minecraft:red_nether_bricks
fill 350 89 485 351 89 486 minecraft:black_concrete
fill 351 89 487 351 89 488 minecraft:black_concrete
fill 352 89 481 352 89 483 minecraft:shroomlight
fill 352 89 485 352 89 492 minecraft:shroomlight
fill 353 89 480 354 89 480 minecraft:white_concrete
fill 353 89 482 354 89 482 minecraft:gray_concrete
fill 353 89 483 359 89 483 minecraft:shroomlight
fill 353 89 487 356 89 488 minecraft:shroomlight
fill 353 89 489 355 89 491 minecraft:red_nether_bricks
fill 353 89 492 356 89 492 minecraft:shroomlight
fill 355 89 479 355 89 482 minecraft:shroomlight
fill 356 89 479 359 89 479 minecraft:shroomlight
fill 356 89 480 358 89 482 minecraft:red_nether_bricks
fill 356 89 484 356 89 486 minecraft:shroomlight
fill 356 89 489 356 89 491 minecraft:shroomlight
fill 357 89 485 358 89 485 minecraft:black_concrete
setblock 357 89 487 minecraft:black_concrete
fill 357 89 490 359 89 491 minecraft:white_concrete
fill 357 89 492 370 89 492 minecraft:red_nether_bricks
fill 359 89 480 359 89 482 minecraft:shroomlight
fill 359 89 484 361 89 487 minecraft:white_concrete
fill 360 89 477 370 89 477 minecraft:red_nether_bricks
fill 360 89 480 361 89 483 minecraft:white_concrete
fill 360 89 493 370 89 493 minecraft:red_nether_bricks
fill 362 89 478 370 89 478 minecraft:red_nether_bricks
fill 364 89 479 370 89 479 minecraft:red_nether_bricks
fill 364 89 491 370 89 491 minecraft:red_nether_bricks
fill 365 89 480 370 89 480 minecraft:red_nether_bricks
fill 365 89 490 370 89 490 minecraft:red_nether_bricks
fill 366 89 481 370 89 481 minecraft:red_nether_bricks
fill 366 89 489 370 89 489 minecraft:red_nether_bricks
fill 367 89 482 370 89 484 minecraft:red_nether_bricks
fill 367 89 486 370 89 488 minecraft:red_nether_bricks
fill 368 89 485 370 89 485 minecraft:red_nether_bricks
fill 330 93 464 330 93 467 minecraft:pink_terracotta
setblock 330 93 468 minecraft:red_nether_bricks
fill 330 93 469 330 93 472 minecraft:pink_terracotta
setblock 330 93 473 minecraft:red_nether_bricks
fill 330 93 474 330 93 477 minecraft:pink_terracotta
setblock 330 93 478 minecraft:red_nether_bricks
fill 330 93 479 330 93 482 minecraft:pink_terracotta
setblock 330 93 483 minecraft:red_nether_bricks
fill 330 93 484 330 93 487 minecraft:pink_terracotta
setblock 330 93 488 minecraft:red_nether_bricks
fill 330 93 489 330 93 492 minecraft:pink_terracotta
setblock 330 93 493 minecraft:red_nether_bricks
fill 330 93 494 330 93 497 minecraft:pink_terracotta
setblock 330 93 498 minecraft:red_nether_bricks
fill 330 93 499 330 93 502 minecraft:pink_terracotta
setblock 330 93 503 minecraft:red_nether_bricks
fill 330 93 504 333 93 504 minecraft:pink_terracotta
fill 331 93 464 331 93 466 minecraft:pink_terracotta
setblock 331 93 467 minecraft:red_nether_bricks
fill 331 93 468 331 93 471 minecraft:pink_terracotta
setblock 331 93 472 minecraft:red_nether_bricks
fill 331 93 473 331 93 476 minecraft:pink_terracotta
setblock 331 93 477 minecraft:red_nether_bricks
setblock 331 93 487 minecraft:red_nether_bricks
fill 331 93 488 331 93 491 minecraft:pink_terracotta
setblock 331 93 492 minecraft:red_nether_bricks
fill 331 93 493 331 93 496 minecraft:pink_terracotta
setblock 331 93 497 minecraft:red_nether_bricks
fill 331 93 498 331 93 501 minecraft:pink_terracotta
setblock 331 93 502 minecraft:red_nether_bricks
fill 331 93 503 334 93 503 minecraft:pink_terracotta
fill 332 93 464 332 93 465 minecraft:pink_terracotta
setblock 332 93 472 minecraft:pink_terracotta
fill 332 93 489 332 93 490 minecraft:pink_terracotta
setblock 332 93 491 minecraft:red_nether_bricks
fill 332 93 492 332 93 495 minecraft:pink_terracotta
setblock 332 93 496 minecraft:red_nether_bricks
fill 332 93 497 332 93 500 minecraft:pink_terracotta
setblock 332 93 501 minecraft:red_nether_bricks
fill 332 93 502 332 94 502 minecraft:pink_terracotta
setblock 333 93 464 minecraft:pink_terracotta
fill 333 93 492 333 93 494 minecraft:pink_terracotta
setblock 333 93 495 minecraft:red_nether_bricks
fill 333 93 496 333 94 498 minecraft:pink_terracotta
setblock 334 93 464 minecraft:red_nether_bricks
setblock 334 93 504 minecraft:red_nether_bricks
fill 335 93 504 336 93 504 minecraft:pink_terracotta
setblock 348 93 464 minecraft:pink_terracotta
setblock 348 93 504 minecraft:pink_terracotta
setblock 349 93 464 minecraft:red_nether_bricks
setblock 349 93 504 minecraft:red_nether_bricks
fill 350 93 464 353 93 464 minecraft:pink_terracotta
setblock 350 93 504 minecraft:pink_terracotta
setblock 351 93 465 minecraft:pink_terracotta
setblock 354 93 464 minecraft:red_nether_bricks
setblock 355 93 464 minecraft:pink_terracotta
fill 362 93 464 363 93 464 minecraft:pink_terracotta
setblock 364 93 464 minecraft:red_nether_bricks
fill 364 93 465 367 93 465 minecraft:pink_terracotta
fill 365 93 464 368 93 464 minecraft:pink_terracotta
fill 365 93 504 368 93 504 minecraft:pink_terracotta
setblock 366 93 466 minecraft:pink_terracotta
setblock 367 93 466 minecraft:red_nether_bricks
fill 367 93 468 367 93 470 minecraft:pink_terracotta
setblock 367 93 471 minecraft:red_nether_bricks
fill 367 93 472 368 93 474 minecraft:pink_terracotta
fill 367 93 503 369 93 503 minecraft:pink_terracotta
setblock 368 93 465 minecraft:red_nether_bricks
fill 368 93 466 368 93 469 minecraft:pink_terracotta
setblock 368 93 470 minecraft:red_nether_bricks
fill 368 93 471 370 94 471 minecraft:pink_terracotta
setblock 368 93 475 minecraft:red_nether_bricks
fill 368 93 476 370 93 477 minecraft:pink_terracotta
fill 368 93 493 368 93 494 minecraft:pink_terracotta
setblock 368 93 495 minecraft:red_nether_bricks
fill 368 93 496 368 93 499 minecraft:pink_terracotta
setblock 369 93 464 minecraft:red_nether_bricks
fill 369 93 465 369 93 468 minecraft:pink_terracotta
setblock 369 93 469 minecraft:red_nether_bricks
fill 369 93 470 370 95 470 minecraft:pink_terracotta
fill 369 93 472 369 93 473 minecraft:pink_terracotta
setblock 369 93 474 minecraft:red_nether_bricks
fill 369 93 475 370 95 475 minecraft:pink_terracotta
setblock 369 93 478 minecraft:pink_terracotta
setblock 369 93 479 minecraft:red_nether_bricks
setblock 369 93 489 minecraft:red_nether_bricks
fill 369 93 490 369 93 493 minecraft:pink_terracotta
setblock 369 93 494 minecraft:red_nether_bricks
fill 369 93 495 369 93 498 minecraft:pink_terracotta
setblock 369 93 499 minecraft:red_nether_bricks
fill 369 93 500 370 93 502 minecraft:pink_terracotta
setblock 369 93 504 minecraft:red_nether_bricks
fill 370 93 464 370 93 467 minecraft:pink_terracotta
setblock 370 93 468 minecraft:red_nether_bricks
fill 370 93 469 370 96 469 minecraft:pink_terracotta
setblock 370 93 472 minecraft:pink_terracotta
setblock 370 93 473 minecraft:red_nether_bricks
fill 370 93 474 370 96 474 minecraft:pink_terracotta
setblock 370 93 478 minecraft:red_nether_bricks
fill 370 93 479 370 93 482 minecraft:pink_terracotta
setblock 370 93 483 minecraft:red_nether_bricks
fill 370 93 484 370 93 487 minecraft:pink_terracotta
setblock 370 93 488 minecraft:red_nether_bricks
fill 370 93 489 370 93 492 minecraft:pink_terracotta
setblock 370 93 493 minecraft:red_nether_bricks
fill 370 93 494 370 93 497 minecraft:pink_terracotta
setblock 370 93 498 minecraft:red_nether_bricks
fill 370 93 499 370 96 499 minecraft:pink_terracotta
setblock 370 93 503 minecraft:red_nether_bricks
fill 370 93 504 370 96 504 minecraft:pink_terracotta
fill 330 94 464 330 94 466 minecraft:pink_terracotta
setblock 330 94 467 minecraft:red_nether_bricks
fill 330 94 468 330 94 471 minecraft:pink_terracotta
setblock 330 94 472 minecraft:red_nether_bricks
fill 330 94 473 330 94 476 minecraft:pink_terracotta
setblock 330 94 477 minecraft:red_nether_bricks
fill 330 94 478 330 94 481 minecraft:pink_terracotta
setblock 330 94 482 minecraft:red_nether_bricks
fill 330 94 483 330 94 486 minecraft:pink_terracotta
setblock 330 94 487 minecraft:red_nether_bricks
fill 330 94 488 330 94 491 minecraft:pink_terracotta
setblock 330 94 492 minecraft:red_nether_bricks
fill 330 94 493 330 94 496 minecraft:pink_terracotta
setblock 330 94 497 minecraft:red_nether_bricks
fill 330 94 498 330 94 501 minecraft:pink_terracotta
setblock 330 94 502 minecraft:red_nether_bricks
fill 330 94 503 332 94 504 minecraft:pink_terracotta
fill 331 94 464 332 94 464 minecraft:pink_terracotta
setblock 331 94 466 minecraft:red_nether_bricks
fill 331 94 467 331 94 470 minecraft:pink_terracotta
setblock 331 94 471 minecraft:red_nether_bricks
fill 331 94 472 331 94 475 minecraft:pink_terracotta
setblock 331 94 476 minecraft:red_nether_bricks
fill 331 94 477 331 95 477 minecraft:pink_terracotta
fill 331 94 487 331 94 490 minecraft:pink_terracotta
setblock 331 94 491 minecraft:red_nether_bricks
fill 331 94 492 331 94 495 minecraft:pink_terracotta
setblock 331 94 496 minecraft:red_nether_bricks
fill 331 94 497 331 94 500 minecraft:pink_terracotta
setblock 331 94 501 minecraft:red_nether_bricks
fill 331 94 502 331 97 502 minecraft:pink_terracotta
setblock 332 94 490 minecraft:red_nether_bricks
fill 332 94 491 332 94 494 minecraft:pink_terracotta
setblock 332 94 495 minecraft:red_nether_bricks
fill 332 94 496 332 94 499 minecraft:pink_terracotta
setblock 332 94 500 minecraft:red_nether_bricks
fill 332 94 501 332 96 501 minecraft:pink_terracotta
setblock 333 94 464 minecraft:red_nether_bricks
setblock 333 94 493 minecraft:pink_terracotta
setblock 333 94 494 minecraft:red_nether_bricks
fill 333 94 495 333 95 495 minecraft:pink_terracotta
setblock 333 94 503 minecraft:pink_terracotta
setblock 333 94 504 minecraft:red_nether_bricks
fill 334 94 504 335 94 504 minecraft:pink_terracotta
fill 340 94 464 340 95 464 minecraft:white_concrete
setblock 346 94 464 minecraft:white_concrete
setblock 348 94 464 minecraft:red_nether_bricks
fill 349 94 464 352 94 464 minecraft:pink_terracotta
setblock 349 94 504 minecraft:pink_terracotta
setblock 353 94 464 minecraft:red_nether_bricks
setblock 354 94 504 minecraft:white_concrete
setblock 362 94 464 minecraft:pink_terracotta
setblock 363 94 464 minecraft:red_nether_bricks
fill 364 94 464 366 94 465 minecraft:pink_terracotta
fill 365 94 504 367 94 504 minecraft:pink_terracotta
setblock 366 94 466 minecraft:red_nether_bricks
setblock 367 94 464 minecraft:pink_terracotta
setblock 367 94 465 minecraft:red_nether_bricks
fill 367 94 466 370 94 466 minecraft:pink_terracotta
setblock 367 94 469 minecraft:pink_terracotta
setblock 367 94 470 minecraft:red_nether_bricks
fill 367 94 471 367 94 474 minecraft:pink_terracotta
fill 367 94 503 368 94 503 minecraft:pink_terracotta
setblock 368 94 464 minecraft:red_nether_bricks
fill 368 94 465 370 95 465 minecraft:pink_terracotta
fill 368 94 467 368 94 468 minecraft:pink_terracotta
setblock 368 94 469 minecraft:red_nether_bricks
fill 368 94 470 368 96 470 minecraft:pink_terracotta
fill 368 94 472 368 94 473 minecraft:pink_terracotta
setblock 368 94 474 minecraft:red_nether_bricks
fill 368 94 475 368 95 477 minecraft:pink_terracotta
setblock 368 94 493 minecraft:pink_terracotta
setblock 368 94 494 minecraft:red_nether_bricks
fill 368 94 495 368 94 498 minecraft:pink_terracotta
setblock 368 94 499 minecraft:red_nether_bricks
fill 368 94 500 370 95 500 minecraft:pink_terracotta
setblock 368 94 504 minecraft:red_nether_bricks
fill 369 94 464 370 96 464 minecraft:pink_terracotta
setblock 369 94 467 minecraft:pink_terracotta
setblock 369 94 468 minecraft:red_nether_bricks
fill 369 94 469 369 97 469 minecraft:pink_terracotta
setblock 369 94 472 minecraft:pink_terracotta
setblock 369 94 473 minecraft:red_nether_bricks
fill 369 94 474 369 97 474 minecraft:pink_terracotta
fill 369 94 476 369 94 477 minecraft:pink_terracotta
setblock 369 94 478 minecraft:red_nether_bricks
fill 369 94 479 370 96 479 minecraft:pink_terracotta
fill 369 94 490 369 94 492 minecraft:pink_terracotta
setblock 369 94 493 minecraft:red_nether_bricks
fill 369 94 494 369 94 497 minecraft:pink_terracotta
setblock 369 94 498 minecraft:red_nether_bricks
fill 369 94 499 369 97 499 minecraft:pink_terracotta
fill 369 94 501 369 94 502 minecraft:pink_terracotta
setblock 369 94 503 minecraft:red_nether_bricks
fill 369 94 504 369 97 504 minecraft:pink_terracotta
setblock 370 94 467 minecraft:red_nether_bricks
fill 370 94 468 370 97 468 minecraft:pink_terracotta
setblock 370 94 472 minecraft:red_nether_bricks
fill 370 94 473 370 97 473 minecraft:pink_terracotta
setblock 370 94 476 minecraft:pink_terracotta
setblock 370 94 477 minecraft:red_nether_bricks
fill 370 94 478 370 97 478 minecraft:pink_terracotta
fill 370 94 480 370 94 481 minecraft:pink_terracotta
setblock 370 94 482 minecraft:red_nether_bricks
setblock 370 94 484 minecraft:white_concrete
setblock 370 94 486 minecraft:pink_terracotta
setblock 370 94 487 minecraft:red_nether_bricks
fill 370 94 488 370 94 491 minecraft:pink_terracotta
setblock 370 94 492 minecraft:red_nether_bricks
fill 370 94 493 370 94 496 minecraft:pink_terracotta
setblock 370 94 497 minecraft:red_nether_bricks
fill 370 94 498 370 97 498 minecraft:pink_terracotta
setblock 370 94 501 minecraft:pink_terracotta
setblock 370 94 502 minecraft:red_nether_bricks
fill 370 94 503 370 97 503 minecraft:pink_terracotta
fill 330 95 464 330 95 465 minecraft:pink_terracotta
setblock 330 95 466 minecraft:red_nether_bricks
fill 330 95 467 330 95 470 minecraft:pink_terracotta
setblock 330 95 471 minecraft:red_nether_bricks
fill 330 95 472 330 95 475 minecraft:pink_terracotta
setblock 330 95 476 minecraft:red_nether_bricks
fill 330 95 477 330 95 480 minecraft:pink_terracotta
setblock 330 95 481 minecraft:red_nether_bricks
fill 330 95 482 330 95 485 minecraft:pink_terracotta
setblock 330 95 486 minecraft:red_nether_bricks
fill 330 95 487 330 95 490 minecraft:pink_terracotta
setblock 330 95 491 minecraft:red_nether_bricks
fill 330 95 492 330 95 495 minecraft:pink_terracotta
setblock 330 95 496 minecraft:red_nether_bricks
fill 330 95 497 330 95 500 minecraft:pink_terracotta
setblock 330 95 501 minecraft:red_nether_bricks
fill 330 95 502 330 96 504 minecraft:pink_terracotta
setblock 331 95 464 minecraft:pink_terracotta
setblock 331 95 470 minecraft:red_nether_bricks
fill 331 95 471 331 95 474 minecraft:pink_terracotta
setblock 331 95 475 minecraft:red_nether_bricks
fill 331 95 476 331 96 476 minecraft:pink_terracotta
fill 331 95 488 331 95 489 minecraft:pink_terracotta
setblock 331 95 490 minecraft:red_nether_bricks
fill 331 95 491 331 95 494 minecraft:pink_terracotta
setblock 331 95 495 minecraft:red_nether_bricks
fill 331 95 496 331 95 499 minecraft:pink_terracotta
setblock 331 95 500 minecraft:red_nether_bricks
fill 331 95 501 331 98 501 minecraft:pink_terracotta
fill 331 95 503 331 95 504 minecraft:pink_terracotta
setblock 332 95 466 minecraft:light[level=12]
setblock 332 95 474 minecraft:light[level=12]
setblock 332 95 482 minecraft:light[level=12]
setblock 332 95 490 minecraft:light[level=12]
fill 332 95 491 332 95 493 minecraft:pink_terracotta
setblock 332 95 494 minecraft:red_nether_bricks
fill 332 95 495 332 95 498 minecraft:pink_terracotta
setblock 332 95 499 minecraft:red_nether_bricks
fill 332 95 500 332 97 500 minecraft:pink_terracotta
setblock 332 95 503 minecraft:pink_terracotta
setblock 332 95 504 minecraft:red_nether_bricks
fill 333 95 496 333 95 497 minecraft:pink_terracotta
setblock 333 95 503 minecraft:red_nether_bricks
fill 333 95 504 334 95 504 minecraft:pink_terracotta
setblock 334 95 464 minecraft:white_concrete
setblock 340 95 466 minecraft:light[level=12]
setblock 340 95 474 minecraft:light[level=12]
setblock 340 95 482 minecraft:light[level=12]
setblock 340 95 490 minecraft:light[level=12]
setblock 340 95 498 minecraft:light[level=12]
setblock 341 95 504 minecraft:white_concrete
setblock 348 95 466 minecraft:light[level=12]
setblock 348 95 474 minecraft:light[level=12]
setblock 348 95 482 minecraft:light[level=12]
setblock 348 95 490 minecraft:light[level=12]
setblock 348 95 498 minecraft:light[level=12]
fill 349 95 464 351 95 464 minecraft:pink_terracotta
setblock 356 95 466 minecraft:light[level=12]
setblock 356 95 474 minecraft:light[level=12]
setblock 356 95 482 minecraft:light[level=12]
setblock 356 95 490 minecraft:light[level=12]
setblock 356 95 498 minecraft:light[level=12]
setblock 359 95 464 minecraft:white_concrete
setblock 360 95 504 minecraft:white_concrete
setblock 362 95 464 minecraft:red_nether_bricks
fill 363 95 464 366 95 464 minecraft:pink_terracotta
setblock 364 95 466 minecraft:light[level=12]
setblock 364 95 474 minecraft:light[level=12]
setblock 364 95 482 minecraft:light[level=12]
setblock 364 95 490 minecraft:light[level=12]
setblock 364 95 498 minecraft:light[level=12]
fill 364 95 504 366 95 504 minecraft:pink_terracotta
setblock 365 95 465 minecraft:pink_terracotta
setblock 366 95 465 minecraft:red_nether_bricks
fill 366 95 503 367 95 503 minecraft:pink_terracotta
setblock 367 95 464 minecraft:red_nether_bricks
fill 367 95 465 367 98 465 minecraft:pink_terracotta
fill 367 95 472 367 95 473 minecraft:pink_terracotta
setblock 367 95 504 minecraft:red_nether_bricks
fill 368 95 464 368 98 464 minecraft:pink_terracotta
fill 368 95 466 368 95 467 minecraft:pink_terracotta
setblock 368 95 468 minecraft:red_nether_bricks
fill 368 95 469 368 96 469 minecraft:pink_terracotta
fill 368 95 471 368 95 472 minecraft:pink_terracotta
setblock 368 95 473 minecraft:red_nether_bricks
fill 368 95 474 368 97 474 minecraft:pink_terracotta
fill 368 95 494 368 95 497 minecraft:pink_terracotta
setblock 368 95 498 minecraft:red_nether_bricks
fill 368 95 499 368 98 499 minecraft:pink_terracotta
fill 368 95 501 369 95 501 minecraft:pink_terracotta
setblock 368 95 503 minecraft:red_nether_bricks
fill 368 95 504 368 98 504 minecraft:pink_terracotta
setblock 369 95 466 minecraft:pink_terracotta
setblock 369 95 467 minecraft:red_nether_bricks
fill 369 95 468 369 97 468 minecraft:pink_terracotta
setblock 369 95 471 minecraft:pink_terracotta
setblock 369 95 472 minecraft:red_nether_bricks
fill 369 95 473 369 98 473 minecraft:pink_terracotta
setblock 369 95 476 minecraft:pink_terracotta
setblock 369 95 477 minecraft:red_nether_bricks
fill 369 95 478 369 98 478 minecraft:pink_terracotta
setblock 369 95 491 minecraft:pink_terracotta
setblock 369 95 492 minecraft:red_nether_bricks
fill 369 95 493 369 95 496 minecraft:pink_terracotta
setblock 369 95 497 minecraft:red_nether_bricks
fill 369 95 498 369 98 498 minecraft:pink_terracotta
setblock 369 95 502 minecraft:red_nether_bricks
fill 369 95 503 369 98 503 minecraft:pink_terracotta
setblock 370 95 466 minecraft:red_nether_bricks
fill 370 95 467 370 98 467 minecraft:pink_terracotta
setblock 370 95 471 minecraft:red_nether_bricks
fill 370 95 472 370 98 472 minecraft:pink_terracotta
setblock 370 95 476 minecraft:red_nether_bricks
fill 370 95 477 370 98 477 minecraft:pink_terracotta
setblock 370 95 480 minecraft:pink_terracotta
setblock 370 95 481 minecraft:red_nether_bricks
fill 370 95 488 370 95 490 minecraft:pink_terracotta
setblock 370 95 491 minecraft:red_nether_bricks
fill 370 95 492 370 95 495 minecraft:pink_terracotta
setblock 370 95 496 minecraft:red_nether_bricks
fill 370 95 497 370 98 497 minecraft:pink_terracotta
setblock 370 95 501 minecraft:red_nether_bricks
fill 370 95 502 370 98 502 minecraft:pink_terracotta
setblock 330 96 464 minecraft:pink_terracotta
setblock 330 96 465 minecraft:red_nether_bricks
fill 330 96 466 330 96 469 minecraft:pink_terracotta
setblock 330 96 470 minecraft:red_nether_bricks
fill 330 96 471 330 96 474 minecraft:pink_terracotta
setblock 330 96 475 minecraft:red_nether_bricks
fill 330 96 476 330 96 479 minecraft:pink_terracotta
setblock 330 96 480 minecraft:red_nether_bricks
fill 330 96 481 330 96 482 minecraft:pink_terracotta
fill 330 96 486 330 96 489 minecraft:pink_terracotta
setblock 330 96 490 minecraft:red_nether_bricks
fill 330 96 491 330 96 494 minecraft:pink_terracotta
setblock 330 96 495 minecraft:red_nether_bricks
fill 330 96 496 330 96 499 minecraft:pink_terracotta
setblock 330 96 500 minecraft:red_nether_bricks
fill 330 96 501 330 99 501 minecraft:pink_terracotta
setblock 331 96 473 minecraft:pink_terracotta
setblock 331 96 474 minecraft:red_nether_bricks
setblock 331 96 475 minecraft:pink_terracotta
fill 331 96 490 331 96 493 minecraft:pink_terracotta
setblock 331 96 494 minecraft:red_nether_bricks
fill 331 96 495 331 96 498 minecraft:pink_terracotta
setblock 331 96 499 minecraft:red_nether_bricks
fill 331 96 500 331 99 500 minecraft:pink_terracotta
setblock 331 96 503 minecraft:pink_terracotta
setblock 331 96 504 minecraft:red_nether_bricks
setblock 332 96 492 minecraft:pink_terracotta
setblock 332 96 493 minecraft:red_nether_bricks
fill 332 96 494 332 96 497 minecraft:pink_terracotta
setblock 332 96 498 minecraft:red_nether_bricks
fill 332 96 499 332 98 499 minecraft:pink_terracotta
setblock 332 96 503 minecraft:red_nether_bricks
fill 332 96 504 333 97 504 minecraft:pink_terracotta
fill 345 96 493 346 97 493 minecraft:red_concrete
setblock 347 96 504 minecraft:white_concrete
setblock 353 96 464 minecraft:white_concrete
fill 363 96 464 365 96 464 minecraft:pink_terracotta
fill 364 96 504 365 96 504 minecraft:pink_terracotta
setblock 365 96 465 minecraft:red_nether_bricks
setblock 366 96 464 minecraft:red_nether_bricks
fill 366 96 465 366 99 465 minecraft:pink_terracotta
setblock 366 96 503 minecraft:pink_terracotta
setblock 366 96 504 minecraft:red_nether_bricks
fill 367 96 464 367 99 464 minecraft:pink_terracotta
setblock 367 96 503 minecraft:red_nether_bricks
fill 367 96 504 367 99 504 minecraft:pink_terracotta
fill 368 96 465 369 96 465 minecraft:pink_terracotta
setblock 368 96 471 minecraft:pink_terracotta
setblock 368 96 472 minecraft:red_nether_bricks
fill 368 96 473 368 97 473 minecraft:pink_terracotta
fill 368 96 475 368 96 476 minecraft:pink_terracotta
fill 368 96 495 368 96 496 minecraft:pink_terracotta
setblock 368 96 497 minecraft:red_nether_bricks
fill 368 96 498 368 99 498 minecraft:pink_terracotta
fill 368 96 500 368 96 501 minecraft:pink_terracotta
setblock 368 96 502 minecraft:red_nether_bricks
fill 368 96 503 368 99 503 minecraft:pink_terracotta
setblock 369 96 466 minecraft:red_nether_bricks
fill 369 96 467 369 97 467 minecraft:pink_terracotta
setblock 369 96 470 minecraft:pink_terracotta
setblock 369 96 471 minecraft:red_nether_bricks
fill 369 96 472 369 98 472 minecraft:pink_terracotta
setblock 369 96 475 minecraft:pink_terracotta
setblock 369 96 476 minecraft:red_nether_bricks
fill 369 96 477 369 99 477 minecraft:pink_terracotta
fill 369 96 492 369 96 495 minecraft:pink_terracotta
setblock 369 96 496 minecraft:red_nether_bricks
fill 369 96 497 369 99 497 minecraft:pink_terracotta
setblock 369 96 500 minecraft:pink_terracotta
setblock 369 96 501 minecraft:red_nether_bricks
fill 369 96 502 369 99 502 minecraft:pink_terracotta
setblock 370 96 465 minecraft:red_nether_bricks
fill 370 96 466 370 99 466 minecraft:pink_terracotta
setblock 370 96 470 minecraft:red_nether_bricks
fill 370 96 471 370 99 471 minecraft:pink_terracotta
setblock 370 96 475 minecraft:red_nether_bricks
fill 370 96 476 370 99 476 minecraft:pink_terracotta
setblock 370 96 480 minecraft:red_nether_bricks
fill 370 96 481 370 97 481 minecraft:pink_terracotta
setblock 370 96 489 minecraft:pink_terracotta
setblock 370 96 490 minecraft:red_nether_bricks
fill 370 96 491 370 96 494 minecraft:pink_terracotta
setblock 370 96 495 minecraft:red_nether_bricks
fill 370 96 496 370 99 496 minecraft:pink_terracotta
setblock 370 96 500 minecraft:red_nether_bricks
fill 370 96 501 370 99 501 minecraft:pink_terracotta
fill 329 97 463 329 98 469 minecraft:red_concrete
fill 329 97 470 330 97 470 minecraft:pink_terracotta
fill 329 97 471 329 100 475 minecraft:red_concrete
fill 329 97 476 330 97 476 minecraft:pink_terracotta
fill 329 97 477 329 98 482 minecraft:red_concrete
setblock 329 97 483 minecraft:pink_terracotta
setblock 329 97 484 minecraft:red_concrete
setblock 329 97 485 minecraft:pink_terracotta
fill 329 97 486 329 98 494 minecraft:red_concrete
fill 329 97 495 331 97 497 minecraft:pink_terracotta
fill 329 97 498 329 98 505 minecraft:red_concrete
fill 330 97 463 337 100 463 minecraft:red_concrete
fill 330 97 471 330 97 473 minecraft:pink_terracotta
setblock 330 97 474 minecraft:red_nether_bricks
fill 330 97 475 330 100 475 minecraft:pink_terracotta
fill 330 97 477 330 97 478 minecraft:pink_terracotta
setblock 330 97 479 minecraft:red_nether_bricks
fill 330 97 480 330 99 481 minecraft:pink_terracotta
setblock 330 97 483 minecraft:white_concrete
fill 330 97 487 330 97 488 minecraft:pink_terracotta
setblock 330 97 489 minecraft:red_nether_bricks
fill 330 97 490 330 97 493 minecraft:pink_terracotta
setblock 330 97 494 minecraft:red_nether_bricks
setblock 330 97 498 minecraft:pink_terracotta
setblock 330 97 499 minecraft:red_nether_bricks
fill 330 97 500 330 100 500 minecraft:pink_terracotta
fill 330 97 502 330 97 503 minecraft:pink_terracotta
setblock 330 97 504 minecraft:red_nether_bricks
fill 330 97 505 330 98 505 minecraft:red_concrete
fill 331 97 491 331 97 492 minecraft:pink_terracotta
setblock 331 97 493 minecraft:red_nether_bricks
fill 331 97 494 332 97 494 minecraft:pink_terracotta
setblock 331 97 498 minecraft:red_nether_bricks
fill 331 97 499 331 100 499 minecraft:pink_terracotta
setblock 331 97 503 minecraft:red_nether_bricks
fill 331 97 504 331 97 505 minecraft:pink_terracotta
fill 332 97 495 332 97 496 minecraft:pink_terracotta
setblock 332 97 497 minecraft:red_nether_bricks
fill 332 97 498 332 98 498 minecraft:pink_terracotta
setblock 332 97 503 minecraft:pink_terracotta
fill 332 97 505 349 98 505 minecraft:red_concrete
fill 334 97 504 334 98 504 minecraft:white_concrete
setblock 338 97 463 minecraft:pink_terracotta
fill 339 97 463 352 97 463 minecraft:red_concrete
setblock 347 97 464 minecraft:white_concrete
setblock 350 97 505 minecraft:pink_terracotta
fill 351 97 505 352 97 505 minecraft:red_concrete
setblock 353 97 463 minecraft:pink_terracotta
setblock 353 97 504 minecraft:white_concrete
setblock 353 97 505 minecraft:pink_terracotta
fill 354 97 463 371 97 463 minecraft:red_concrete
fill 354 97 505 369 97 505 minecraft:red_concrete
fill 363 97 464 364 97 464 minecraft:pink_terracotta
fill 363 97 504 364 97 504 minecraft:pink_terracotta
setblock 365 97 464 minecraft:red_nether_bricks
setblock 365 97 503 minecraft:pink_terracotta
setblock 365 97 504 minecraft:red_nether_bricks
fill 366 97 464 366 100 464 minecraft:pink_terracotta
setblock 366 97 503 minecraft:red_nether_bricks
fill 366 97 504 366 100 504 minecraft:pink_terracotta
setblock 367 97 502 minecraft:red_nether_bricks
fill 367 97 503 367 100 503 minecraft:pink_terracotta
setblock 368 97 465 minecraft:pink_terracotta
setblock 368 97 471 minecraft:red_nether_bricks
setblock 368 97 472 minecraft:pink_terracotta
setblock 368 97 475 minecraft:pink_terracotta
setblock 368 97 476 minecraft:red_nether_bricks
setblock 368 97 495 minecraft:pink_terracotta
setblock 368 97 496 minecraft:red_nether_bricks
fill 368 97 497 368 100 497 minecraft:pink_terracotta
setblock 368 97 500 minecraft:pink_terracotta
setblock 368 97 501 minecraft:red_nether_bricks
fill 368 97 502 368 100 502 minecraft:pink_terracotta
setblock 369 97 464 minecraft:pink_terracotta
setblock 369 97 465 minecraft:red_nether_bricks
setblock 369 97 466 minecraft:pink_terracotta
setblock 369 97 470 minecraft:red_nether_bricks
fill 369 97 471 369 98 471 minecraft:pink_terracotta
setblock 369 97 475 minecraft:red_nether_bricks
fill 369 97 476 369 100 476 minecraft:pink_terracotta
fill 369 97 493 369 97 494 minecraft:pink_terracotta
setblock 369 97 495 minecraft:red_nether_bricks
fill 369 97 496 369 100 496 minecraft:pink_terracotta
setblock 369 97 500 minecraft:red_nether_bricks
fill 369 97 501 369 100 501 minecraft:pink_terracotta
setblock 370 97 464 minecraft:red_nether_bricks
fill 370 97 465 370 100 465 minecraft:pink_terracotta
setblock 370 97 469 minecraft:red_nether_bricks
fill 370 97 470 370 99 470 minecraft:pink_terracotta
setblock 370 97 474 minecraft:red_nether_bricks
fill 370 97 475 370 100 475 minecraft:pink_terracotta
setblock 370 97 479 minecraft:red_nether_bricks
fill 370 97 480 370 100 480 minecraft:pink_terracotta
setblock 370 97 485 minecraft:white_concrete
fill 370 97 490 370 97 493 minecraft:pink_terracotta
setblock 370 97 494 minecraft:red_nether_bricks
fill 370 97 495 371 97 495 minecraft:pink_terracotta
setblock 370 97 499 minecraft:red_nether_bricks
fill 370 97 500 370 100 500 minecraft:pink_terracotta
setblock 370 97 504 minecraft:red_nether_bricks
setblock 370 97 505 minecraft:pink_terracotta
fill 371 97 464 371 97 487 minecraft:red_concrete
setblock 371 97 488 minecraft:pink_terracotta
fill 371 97 489 371 100 491 minecraft:red_concrete
fill 371 97 492 371 98 492 minecraft:pink_terracotta
fill 371 97 493 371 98 494 minecraft:red_concrete
fill 371 97 496 371 98 501 minecraft:red_concrete
fill 371 97 502 371 97 503 minecraft:pink_terracotta
fill 371 97 504 371 100 505 minecraft:red_concrete
setblock 329 98 470 minecraft:pink_terracotta
fill 329 98 476 329 100 476 minecraft:red_concrete
fill 329 98 483 329 100 483 minecraft:red_concrete
fill 329 98 484 329 99 484 minecraft:pink_terracotta
fill 329 98 485 329 100 485 minecraft:red_concrete
fill 329 98 495 329 100 495 minecraft:red_concrete
fill 329 98 496 331 98 496 minecraft:pink_terracotta
fill 329 98 497 329 100 497 minecraft:red_concrete
setblock 330 98 464 minecraft:white_concrete
fill 330 98 470 330 99 470 minecraft:white_concrete
setblock 330 98 472 minecraft:pink_terracotta
setblock 330 98 473 minecraft:red_nether_bricks
fill 330 98 474 330 99 474 minecraft:pink_terracotta
fill 330 98 476 330 98 477 minecraft:pink_terracotta
setblock 330 98 478 minecraft:red_nether_bricks
fill 330 98 479 330 101 479 minecraft:pink_terracotta
fill 330 98 489 330 98 492 minecraft:pink_terracotta
setblock 330 98 493 minecraft:red_nether_bricks
fill 330 98 494 331 99 495 minecraft:pink_terracotta
setblock 330 98 497 minecraft:pink_terracotta
setblock 330 98 498 minecraft:red_nether_bricks
fill 330 98 499 330 101 499 minecraft:pink_terracotta
setblock 330 98 502 minecraft:pink_terracotta
setblock 330 98 503 minecraft:red_nether_bricks
fill 330 98 504 332 99 504 minecraft:pink_terracotta
setblock 331 98 492 minecraft:red_nether_bricks
fill 331 98 493 331 99 493 minecraft:pink_terracotta
setblock 331 98 497 minecraft:red_nether_bricks
fill 331 98 498 331 101 498 minecraft:pink_terracotta
setblock 331 98 502 minecraft:red_nether_bricks
fill 331 98 503 331 101 503 minecraft:pink_terracotta
fill 331 98 505 331 100 505 minecraft:red_concrete
setblock 332 98 496 minecraft:red_nether_bricks
setblock 332 98 497 minecraft:pink_terracotta
fill 338 98 463 339 98 463 minecraft:red_concrete
setblock 340 98 463 minecraft:pink_terracotta
setblock 340 98 504 minecraft:white_concrete
fill 341 98 463 356 98 463 minecraft:red_concrete
setblock 341 98 464 minecraft:white_concrete
setblock 350 98 505 minecraft:red_concrete
fill 351 98 505 352 98 505 minecraft:pink_terracotta
fill 353 98 505 359 100 505 minecraft:red_concrete
setblock 357 98 463 minecraft:pink_terracotta
fill 358 98 463 365 100 463 minecraft:red_concrete
setblock 359 98 504 minecraft:white_concrete
setblock 360 98 464 minecraft:white_concrete
fill 360 98 477 361 99 478 minecraft:pink_concrete
setblock 360 98 505 minecraft:pink_terracotta
fill 361 98 505 366 98 505 minecraft:red_concrete
fill 362 98 464 363 98 464 minecraft:pink_terracotta
fill 362 98 478 362 99 478 minecraft:pink_concrete
setblock 363 98 504 minecraft:pink_terracotta
setblock 364 98 464 minecraft:red_nether_bricks
setblock 364 98 503 minecraft:pink_terracotta
setblock 364 98 504 minecraft:red_nether_bricks
fill 365 98 464 365 101 464 minecraft:pink_terracotta
setblock 365 98 503 minecraft:red_nether_bricks
fill 365 98 504 365 101 504 minecraft:pink_terracotta
setblock 366 98 463 minecraft:pink_terracotta
fill 366 98 503 366 101 503 minecraft:pink_terracotta
fill 367 98 463 371 98 463 minecraft:red_concrete
fill 367 98 502 367 101 502 minecraft:pink_terracotta
setblock 367 98 505 minecraft:pink_terracotta
setblock 368 98 465 minecraft:red_nether_bricks
setblock 368 98 496 minecraft:pink_terracotta
setblock 368 98 500 minecraft:red_nether_bricks
fill 368 98 501 368 101 501 minecraft:pink_terracotta
fill 368 98 505 370 100 505 minecraft:red_concrete
setblock 369 98 464 minecraft:red_nether_bricks
setblock 369 98 470 minecraft:pink_terracotta
setblock 369 98 474 minecraft:red_nether_bricks
fill 369 98 475 369 99 475 minecraft:pink_terracotta
setblock 369 98 494 minecraft:red_nether_bricks
fill 369 98 495 370 100 495 minecraft:pink_terracotta
setblock 369 98 499 minecraft:red_nether_bricks
fill 369 98 500 369 101 500 minecraft:pink_terracotta
setblock 369 98 504 minecraft:red_nether_bricks
fill 370 98 464 370 101 464 minecraft:pink_terracotta
setblock 370 98 468 minecraft:red_nether_bricks
fill 370 98 469 370 99 469 minecraft:pink_terracotta
setblock 370 98 473 minecraft:red_nether_bricks
fill 370 98 474 370 101 474 minecraft:pink_terracotta
setblock 370 98 478 minecraft:red_nether_bricks
fill 370 98 479 370 101 479 minecraft:pink_terracotta
fill 370 98 491 370 98 492 minecraft:pink_terracotta
setblock 370 98 493 minecraft:red_nether_bricks
fill 370 98 494 370 101 494 minecraft:pink_terracotta
setblock 370 98 498 minecraft:red_nether_bricks
fill 370 98 499 370 101 499 minecraft:pink_terracotta
setblock 370 98 503 minecraft:red_nether_bricks
fill 370 98 504 370 101 504 minecraft:pink_terracotta
fill 371 98 464 371 98 483 minecraft:red_concrete
fill 371 98 484 371 98 485 minecraft:pink_terracotta
fill 371 98 486 371 98 488 minecraft:red_concrete
fill 371 98 495 371 100 495 minecraft:red_concrete
fill 371 98 502 371 98 503 minecraft:red_concrete
fill 329 99 463 329 100 468 minecraft:red_concrete
setblock 329 99 469 minecraft:pink_terracotta
fill 329 99 470 329 100 470 minecraft:red_concrete
fill 329 99 477 329 100 478 minecraft:red_concrete
setblock 329 99 479 minecraft:pink_terracotta
fill 329 99 480 329 100 482 minecraft:red_concrete
fill 329 99 486 329 100 490 minecraft:red_concrete
fill 329 99 491 330 99 491 minecraft:pink_terracotta
fill 329 99 492 329 100 494 minecraft:red_concrete
fill 329 99 496 329 100 496 minecraft:red_concrete
fill 329 99 498 329 100 498 minecraft:red_concrete
setblock 329 99 499 minecraft:pink_terracotta
fill 329 99 500 329 100 505 minecraft:red_concrete
setblock 330 99 476 minecraft:pink_terracotta
setblock 330 99 477 minecraft:red_nether_bricks
fill 330 99 478 330 102 478 minecraft:pink_terracotta
setblock 330 99 482 minecraft:red_nether_bricks
fill 330 99 490 330 100 490 minecraft:pink_terracotta
setblock 330 99 492 minecraft:red_nether_bricks
fill 330 99 493 330 102 493 minecraft:pink_terracotta
setblock 330 99 496 minecraft:pink_terracotta
setblock 330 99 497 minecraft:red_nether_bricks
fill 330 99 498 330 102 498 minecraft:pink_terracotta
setblock 330 99 502 minecraft:red_nether_bricks
fill 330 99 503 330 102 503 minecraft:pink_terracotta
setblock 330 99 505 minecraft:pink_terracotta
setblock 331 99 496 minecraft:red_nether_bricks
fill 331 99 497 331 102 497 minecraft:pink_terracotta
setblock 331 99 501 minecraft:red_nether_bricks
fill 331 99 502 331 102 502 minecraft:pink_terracotta
fill 332 99 505 334 100 505 minecraft:red_concrete
setblock 335 99 464 minecraft:white_concrete
fill 335 99 479 335 100 481 minecraft:pink_concrete
setblock 335 99 505 minecraft:pink_terracotta
fill 336 99 480 336 100 481 minecraft:pink_concrete
fill 336 99 505 338 100 505 minecraft:red_concrete
setblock 338 99 463 minecraft:pink_terracotta
fill 339 99 463 340 100 463 minecraft:red_concrete
setblock 339 99 505 minecraft:pink_terracotta
fill 340 99 505 349 100 505 minecraft:red_concrete
setblock 341 99 463 minecraft:pink_terracotta
fill 342 99 463 342 100 463 minecraft:red_concrete
setblock 343 99 463 minecraft:pink_terracotta
fill 344 99 463 357 100 463 minecraft:red_concrete
fill 346 99 504 346 100 504 minecraft:pink_terracotta
setblock 350 99 505 minecraft:pink_terracotta
fill 351 99 505 352 100 505 minecraft:red_concrete
setblock 354 99 464 minecraft:white_concrete
fill 360 99 505 365 100 505 minecraft:red_concrete
setblock 362 99 464 minecraft:pink_terracotta
setblock 362 99 504 minecraft:pink_terracotta
setblock 363 99 464 minecraft:red_nether_bricks
setblock 363 99 503 minecraft:pink_terracotta
setblock 363 99 504 minecraft:red_nether_bricks
fill 364 99 464 364 102 464 minecraft:pink_terracotta
setblock 364 99 503 minecraft:red_nether_bricks
fill 364 99 504 364 102 504 minecraft:pink_terracotta
fill 365 99 503 365 102 503 minecraft:pink_terracotta
fill 366 99 463 366 100 463 minecraft:red_concrete
fill 366 99 502 366 102 502 minecraft:pink_terracotta
setblock 366 99 505 minecraft:pink_terracotta
setblock 367 99 463 minecraft:pink_terracotta
setblock 367 99 465 minecraft:red_nether_bricks
fill 367 99 505 367 100 505 minecraft:red_concrete
fill 368 99 463 371 100 463 minecraft:red_concrete
setblock 368 99 464 minecraft:red_nether_bricks
setblock 368 99 499 minecraft:red_nether_bricks
fill 368 99 500 368 102 500 minecraft:pink_terracotta
setblock 368 99 504 minecraft:red_nether_bricks
fill 369 99 464 369 102 464 minecraft:pink_terracotta
setblock 369 99 473 minecraft:red_nether_bricks
setblock 369 99 474 minecraft:pink_terracotta
setblock 369 99 478 minecraft:red_nether_bricks
setblock 369 99 494 minecraft:pink_terracotta
setblock 369 99 498 minecraft:red_nether_bricks
fill 369 99 499 369 102 499 minecraft:pink_terracotta
setblock 369 99 503 minecraft:red_nether_bricks
fill 369 99 504 369 102 504 minecraft:pink_terracotta
setblock 370 99 472 minecraft:red_nether_bricks
fill 370 99 473 370 100 473 minecraft:pink_terracotta
setblock 370 99 477 minecraft:red_nether_bricks
fill 370 99 478 370 102 478 minecraft:pink_terracotta
setblock 370 99 492 minecraft:red_nether_bricks
fill 370 99 493 371 99 493 minecraft:pink_terracotta
setblock 370 99 497 minecraft:red_nether_bricks
fill 370 99 498 370 102 498 minecraft:pink_terracotta
setblock 370 99 502 minecraft:red_nether_bricks
fill 370 99 503 370 102 503 minecraft:pink_terracotta
fill 371 99 464 371 100 473 minecraft:red_concrete
setblock 371 99 474 minecraft:pink_terracotta
fill 371 99 475 371 100 480 minecraft:red_concrete
setblock 371 99 481 minecraft:pink_terracotta
fill 371 99 482 371 101 482 minecraft:red_concrete
setblock 371 99 483 minecraft:pink_terracotta
fill 371 99 484 371 100 485 minecraft:red_concrete
setblock 371 99 486 minecraft:pink_terracotta
fill 371 99 487 371 100 488 minecraft:red_concrete
fill 371 99 492 371 100 492 minecraft:red_concrete
fill 371 99 494 371 100 494 minecraft:red_concrete
setblock 371 99 496 minecraft:pink_terracotta
fill 371 99 497 371 100 500 minecraft:red_concrete
fill 371 99 501 371 99 502 minecraft:pink_terracotta
fill 371 99 503 371 100 503 minecraft:red_concrete
setblock 329 100 469 minecraft:red_concrete
setblock 329 100 479 minecraft:red_concrete
setblock 329 100 484 minecraft:red_concrete
fill 329 100 491 329 101 491 minecraft:red_concrete
setblock 329 100 499 minecraft:red_concrete
setblock 330 100 476 minecraft:red_nether_bricks
fill 330 100 477 330 103 477 minecraft:pink_terracotta
setblock 330 100 480 minecraft:pink_terracotta
setblock 330 100 481 minecraft:red_nether_bricks
fill 330 100 482 330 102 483 minecraft:pink_terracotta
setblock 330 100 491 minecraft:red_nether_bricks
fill 330 100 492 330 103 492 minecraft:pink_terracotta
fill 330 100 494 330 100 495 minecraft:pink_terracotta
setblock 330 100 496 minecraft:red_nether_bricks
fill 330 100 497 330 103 497 minecraft:pink_terracotta
setblock 330 100 501 minecraft:red_nether_bricks
fill 330 100 502 330 103 502 minecraft:pink_terracotta
fill 330 100 504 331 100 504 minecraft:pink_terracotta
setblock 330 100 505 minecraft:red_concrete
setblock 331 100 494 minecraft:pink_terracotta
setblock 331 100 495 minecraft:red_nether_bricks
fill 331 100 496 331 103 496 minecraft:pink_terracotta
setblock 331 100 500 minecraft:red_nether_bricks
fill 331 100 501 331 103 501 minecraft:pink_terracotta
setblock 332 100 504 minecraft:red_nether_bricks
setblock 335 100 505 minecraft:red_concrete
setblock 338 100 463 minecraft:red_concrete
setblock 339 100 505 minecraft:red_concrete
setblock 341 100 463 minecraft:red_concrete
setblock 343 100 463 minecraft:red_concrete
fill 344 100 504 345 101 504 minecraft:pink_terracotta
setblock 347 100 504 minecraft:red_nether_bricks
setblock 348 100 464 minecraft:white_concrete
fill 348 100 504 348 103 504 minecraft:pink_terracotta
setblock 350 100 505 minecraft:red_concrete
setblock 352 100 504 minecraft:white_concrete
setblock 361 100 464 minecraft:pink_terracotta
setblock 361 100 504 minecraft:pink_terracotta
setblock 362 100 464 minecraft:red_nether_bricks
setblock 362 100 503 minecraft:pink_terracotta
setblock 362 100 504 minecraft:red_nether_bricks
fill 363 100 464 363 103 464 minecraft:pink_terracotta
setblock 363 100 503 minecraft:red_nether_bricks
fill 363 100 504 363 103 504 minecraft:pink_terracotta
setblock 364 100 502 minecraft:red_nether_bricks
fill 364 100 503 364 103 503 minecraft:pink_terracotta
setblock 365 100 465 minecraft:pink_terracotta
fill 365 100 502 365 103 502 minecraft:pink_terracotta
setblock 366 100 465 minecraft:red_nether_bricks
setblock 366 100 505 minecraft:red_concrete
setblock 367 100 463 minecraft:red_concrete
setblock 367 100 464 minecraft:red_nether_bricks
fill 367 100 465 367 103 465 minecraft:pink_terracotta
setblock 367 100 504 minecraft:red_nether_bricks
fill 368 100 464 368 103 464 minecraft:pink_terracotta
setblock 368 100 498 minecraft:red_nether_bricks
fill 368 100 499 368 103 499 minecraft:pink_terracotta
setblock 368 100 503 minecraft:red_nether_bricks
fill 368 100 504 368 103 504 minecraft:pink_terracotta
setblock 369 100 477 minecraft:red_nether_bricks
setblock 369 100 497 minecraft:red_nether_bricks
fill 369 100 498 369 103 498 minecraft:pink_terracotta
setblock 369 100 502 minecraft:red_nether_bricks
fill 369 100 503 369 103 503 minecraft:pink_terracotta
setblock 370 100 467 minecraft:white_concrete
setblock 370 100 472 minecraft:pink_terracotta
setblock 370 100 476 minecraft:red_nether_bricks
fill 370 100 477 370 103 477 minecraft:pink_terracotta
setblock 370 100 486 minecraft:white_concrete
fill 370 100 493 370 101 493 minecraft:pink_terracotta
setblock 370 100 496 minecraft:red_nether_bricks
fill 370 100 497 370 103 497 minecraft:pink_terracotta
setblock 370 100 501 minecraft:red_nether_bricks
fill 370 100 502 370 103 502 minecraft:pink_terracotta
setblock 371 100 474 minecraft:red_concrete
setblock 371 100 481 minecraft:red_concrete
fill 371 100 483 371 102 483 minecraft:red_concrete
setblock 371 100 486 minecraft:red_concrete
setblock 371 100 493 minecraft:red_concrete
setblock 371 100 496 minecraft:red_concrete
fill 371 100 501 371 100 502 minecraft:red_concrete
fill 329 101 463 329 101 467 minecraft:pink_terracotta
setblock 329 101 468 minecraft:red_concrete
fill 329 101 469 329 202 473 minecraft:pink_terracotta
fill 329 101 474 329 101 475 minecraft:red_concrete
fill 329 101 476 329 102 490 minecraft:pink_terracotta
fill 329 101 492 329 101 505 minecraft:pink_terracotta
fill 330 101 463 333 101 463 minecraft:pink_terracotta
fill 330 101 476 330 103 476 minecraft:pink_terracotta
setblock 330 101 480 minecraft:red_nether_bricks
fill 330 101 481 330 104 481 minecraft:pink_terracotta
setblock 330 101 484 minecraft:pink_terracotta
setblock 330 101 488 minecraft:white_concrete
fill 330 101 491 330 104 491 minecraft:pink_terracotta
setblock 330 101 494 minecraft:pink_terracotta
setblock 330 101 495 minecraft:red_nether_bricks
fill 330 101 496 330 104 496 minecraft:pink_terracotta
setblock 330 101 500 minecraft:red_nether_bricks
fill 330 101 501 330 104 501 minecraft:pink_terracotta
fill 330 101 504 330 101 505 minecraft:pink_terracotta
setblock 331 101 495 minecraft:pink_terracotta
setblock 331 101 499 minecraft:red_nether_bricks
fill 331 101 500 331 104 500 minecraft:pink_terracotta
setblock 331 101 504 minecraft:red_nether_bricks
fill 331 101 505 354 101 505 minecraft:pink_terracotta
fill 332 101 504 332 104 504 minecraft:pink_terracotta
setblock 333 101 504 minecraft:white_concrete
setblock 334 101 463 minecraft:red_concrete
fill 335 101 463 339 102 463 minecraft:pink_terracotta
fill 340 101 463 340 102 463 minecraft:red_concrete
fill 341 101 463 353 101 463 minecraft:pink_terracotta
setblock 342 101 464 minecraft:white_concrete
fill 342 101 504 343 103 504 minecraft:pink_terracotta
setblock 346 101 464 minecraft:red_nether_bricks
setblock 346 101 504 minecraft:red_nether_bricks
fill 347 101 464 348 103 464 minecraft:pink_terracotta
fill 347 101 504 347 104 504 minecraft:pink_terracotta
fill 349 101 504 349 102 504 minecraft:pink_terracotta
setblock 354 101 463 minecraft:red_concrete
fill 355 101 463 356 101 463 minecraft:pink_terracotta
setblock 355 101 505 minecraft:red_concrete
fill 356 101 505 369 101 505 minecraft:pink_terracotta
setblock 357 101 463 minecraft:red_concrete
fill 358 101 463 358 204 463 minecraft:pink_terracotta
setblock 358 101 504 minecraft:white_concrete
setblock 359 101 463 minecraft:red_concrete
fill 359 101 464 360 101 464 minecraft:pink_terracotta
fill 359 101 504 360 101 504 minecraft:pink_terracotta
fill 360 101 463 371 101 463 minecraft:pink_terracotta
setblock 361 101 464 minecraft:red_nether_bricks
fill 361 101 473 362 102 474 minecraft:red_concrete
setblock 361 101 503 minecraft:pink_terracotta
setblock 361 101 504 minecraft:red_nether_bricks
fill 362 101 464 362 104 464 minecraft:pink_terracotta
fill 362 101 475 362 102 475 minecraft:red_concrete
setblock 362 101 503 minecraft:red_nether_bricks
fill 362 101 504 362 104 504 minecraft:pink_terracotta
fill 363 101 465 364 101 465 minecraft:pink_terracotta
fill 363 101 501 363 102 501 minecraft:iron_block
setblock 363 101 502 minecraft:red_nether_bricks
fill 363 101 503 363 104 503 minecraft:pink_terracotta
fill 364 101 502 364 104 502 minecraft:pink_terracotta
setblock 365 101 465 minecraft:red_nether_bricks
setblock 366 101 464 minecraft:red_nether_bricks
fill 366 101 465 366 104 465 minecraft:pink_terracotta
setblock 366 101 504 minecraft:red_nether_bricks
fill 367 101 464 367 104 464 minecraft:pink_terracotta
setblock 367 101 503 minecraft:red_nether_bricks
fill 367 101 504 367 104 504 minecraft:pink_terracotta
setblock 368 101 497 minecraft:red_nether_bricks
fill 368 101 498 368 104 498 minecraft:pink_terracotta
setblock 368 101 502 minecraft:red_nether_bricks
fill 368 101 503 368 104 503 minecraft:pink_terracotta
setblock 369 101 495 minecraft:pink_terracotta
setblock 369 101 496 minecraft:red_nether_bricks
fill 369 101 497 369 104 497 minecraft:pink_terracotta
setblock 369 101 501 minecraft:red_nether_bricks
fill 369 101 502 369 104 502 minecraft:pink_terracotta
setblock 370 101 465 minecraft:red_nether_bricks
setblock 370 101 475 minecraft:red_nether_bricks
fill 370 101 476 370 103 476 minecraft:pink_terracotta
setblock 370 101 480 minecraft:red_nether_bricks
fill 370 101 481 371 104 481 minecraft:pink_terracotta
setblock 370 101 495 minecraft:red_nether_bricks
fill 370 101 496 371 102 496 minecraft:pink_terracotta
setblock 370 101 500 minecraft:red_nether_bricks
fill 370 101 501 371 104 501 minecraft:pink_terracotta
setblock 370 101 505 minecraft:red_concrete
fill 371 101 464 371 102 464 minecraft:pink_terracotta
setblock 371 101 465 minecraft:red_concrete
fill 371 101 466 371 101 475 minecraft:pink_terracotta
setblock 371 101 476 minecraft:red_concrete
fill 371 101 477 371 204 480 minecraft:pink_terracotta
fill 371 101 484 371 101 487 minecraft:pink_terracotta
setblock 371 101 488 minecraft:red_concrete
fill 371 101 489 371 101 495 minecraft:pink_terracotta
fill 371 101 497 371 200 500 minecraft:pink_terracotta
fill 371 101 502 371 101 505 minecraft:pink_terracotta
fill 329 102 463 329 202 464 minecraft:pink_terracotta
setblock 329 102 465 minecraft:red_concrete
fill 329 102 466 329 102 468 minecraft:pink_terracotta
fill 329 102 474 329 204 475 minecraft:pink_terracotta
fill 329 102 491 329 201 493 minecraft:pink_terracotta
setblock 329 102 494 minecraft:red_concrete
fill 329 102 495 330 105 495 minecraft:pink_terracotta
setblock 329 102 496 minecraft:red_concrete
fill 329 102 497 329 102 501 minecraft:pink_terracotta
setblock 329 102 502 minecraft:red_concrete
fill 329 102 503 329 102 505 minecraft:pink_terracotta
setblock 330 102 463 minecraft:red_concrete
setblock 330 102 469 minecraft:white_concrete
setblock 330 102 479 minecraft:red_nether_bricks
fill 330 102 480 330 105 480 minecraft:pink_terracotta
setblock 330 102 484 minecraft:red_nether_bricks
fill 330 102 485 330 104 486 minecraft:pink_terracotta
fill 330 102 490 330 105 490 minecraft:pink_terracotta
setblock 330 102 494 minecraft:red_nether_bricks
setblock 330 102 499 minecraft:red_nether_bricks
fill 330 102 500 330 105 500 minecraft:pink_terracotta
setblock 330 102 504 minecraft:red_nether_bricks
fill 330 102 505 336 102 505 minecraft:pink_terracotta
fill 331 102 463 334 102 463 minecraft:pink_terracotta
setblock 331 102 498 minecraft:red_nether_bricks
fill 331 102 499 331 105 499 minecraft:pink_terracotta
setblock 331 102 503 minecraft:red_nether_bricks
fill 331 102 504 331 105 504 minecraft:pink_terracotta
fill 333 102 504 333 103 504 minecraft:pink_terracotta
setblock 336 102 464 minecraft:white_concrete
setblock 337 102 505 minecraft:red_concrete
fill 338 102 505 344 200 505 minecraft:pink_terracotta
setblock 339 102 504 minecraft:white_concrete
setblock 340 102 504 minecraft:red_nether_bricks
fill 341 102 463 343 102 463 minecraft:pink_terracotta
fill 341 102 504 341 105 504 minecraft:pink_terracotta
fill 343 102 464 344 102 464 minecraft:pink_terracotta
fill 343 102 503 345 102 503 minecraft:pink_terracotta
setblock 344 102 463 minecraft:red_concrete
setblock 344 102 504 minecraft:pink_terracotta
fill 345 102 463 355 200 463 minecraft:pink_terracotta
setblock 345 102 464 minecraft:red_nether_bricks
setblock 345 102 504 minecraft:red_nether_bricks
setblock 345 102 505 minecraft:red_concrete
fill 346 102 464 346 105 464 minecraft:pink_terracotta
setblock 346 102 503 minecraft:red_nether_bricks
fill 346 102 504 346 105 505 minecraft:pink_terracotta
fill 347 102 505 351 102 505 minecraft:pink_terracotta
setblock 349 102 464 minecraft:pink_terracotta
setblock 350 102 464 minecraft:red_nether_bricks
setblock 350 102 504 minecraft:red_nether_bricks
setblock 352 102 505 minecraft:red_concrete
fill 353 102 505 358 102 505 minecraft:pink_terracotta
setblock 356 102 463 minecraft:red_concrete
fill 357 102 463 357 204 463 minecraft:pink_terracotta
fill 358 102 464 359 102 464 minecraft:pink_terracotta
fill 358 102 504 359 102 504 minecraft:pink_terracotta
fill 359 102 463 362 102 463 minecraft:pink_terracotta
setblock 359 102 505 minecraft:red_concrete
setblock 360 102 464 minecraft:red_nether_bricks
setblock 360 102 503 minecraft:pink_terracotta
setblock 360 102 504 minecraft:red_nether_bricks
fill 360 102 505 368 102 505 minecraft:pink_terracotta
fill 361 102 464 361 104 465 minecraft:pink_terracotta
setblock 361 102 503 minecraft:red_nether_bricks
fill 361 102 504 361 105 504 minecraft:pink_terracotta
fill 362 102 465 363 102 465 minecraft:pink_terracotta
setblock 362 102 502 minecraft:red_nether_bricks
fill 362 102 503 362 105 503 minecraft:pink_terracotta
fill 363 102 463 363 103 463 minecraft:red_concrete
fill 363 102 502 363 105 502 minecraft:pink_terracotta
fill 364 102 463 370 102 463 minecraft:pink_terracotta
setblock 364 102 465 minecraft:red_nether_bricks
setblock 365 102 464 minecraft:red_nether_bricks
fill 365 102 465 365 105 465 minecraft:pink_terracotta
fill 365 102 501 367 102 501 minecraft:pink_terracotta
setblock 365 102 504 minecraft:red_nether_bricks
fill 366 102 464 366 105 464 minecraft:pink_terracotta
setblock 366 102 503 minecraft:red_nether_bricks
fill 366 102 504 366 105 504 minecraft:pink_terracotta
fill 367 102 500 367 103 500 minecraft:pink_terracotta
setblock 367 102 502 minecraft:red_nether_bricks
fill 367 102 503 367 105 503 minecraft:pink_terracotta
fill 368 102 497 368 103 497 minecraft:pink_terracotta
setblock 368 102 501 minecraft:red_nether_bricks
fill 368 102 502 368 105 502 minecraft:pink_terracotta
setblock 369 102 495 minecraft:red_nether_bricks
fill 369 102 496 369 105 496 minecraft:pink_terracotta
setblock 369 102 500 minecraft:red_nether_bricks
fill 369 102 501 369 105 501 minecraft:pink_terracotta
setblock 369 102 505 minecraft:red_concrete
setblock 370 102 464 minecraft:red_nether_bricks
fill 370 102 465 371 105 465 minecraft:pink_terracotta
setblock 370 102 474 minecraft:white_concrete
fill 370 102 475 371 102 475 minecraft:pink_terracotta
setblock 370 102 479 minecraft:red_nether_bricks
fill 370 102 480 370 105 480 minecraft:pink_terracotta
fill 370 102 482 371 103 482 minecraft:pink_terracotta
setblock 370 102 494 minecraft:red_nether_bricks
fill 370 102 495 371 105 495 minecraft:pink_terracotta
setblock 370 102 499 minecraft:red_nether_bricks
fill 370 102 500 370 105 500 minecraft:pink_terracotta
setblock 370 102 504 minecraft:red_nether_bricks
fill 370 102 505 371 202 505 minecraft:pink_terracotta
setblock 371 102 463 minecraft:red_concrete
fill 371 102 466 371 102 470 minecraft:pink_terracotta
setblock 371 102 471 minecraft:red_concrete
fill 371 102 472 371 201 474 minecraft:pink_terracotta
fill 371 102 476 371 204 476 minecraft:pink_terracotta
fill 371 102 484 371 204 485 minecraft:pink_terracotta
setblock 371 102 486 minecraft:red_concrete
fill 371 102 487 371 102 490 minecraft:pink_terracotta
setblock 371 102 491 minecraft:red_concrete
fill 371 102 492 371 102 494 minecraft:pink_terracotta
fill 371 102 502 371 202 502 minecraft:pink_terracotta
setblock 371 102 503 minecraft:red_concrete
fill 371 102 504 371 201 504 minecraft:pink_terracotta
fill 329 103 465 329 202 467 minecraft:pink_terracotta
setblock 329 103 468 minecraft:red_concrete
fill 329 103 476 329 103 477 minecraft:red_concrete
fill 329 103 478 329 201 490 minecraft:pink_terracotta
fill 329 103 494 330 106 494 minecraft:pink_terracotta
fill 329 103 496 329 204 496 minecraft:pink_terracotta
setblock 329 103 497 minecraft:red_concrete
fill 329 103 498 329 200 503 minecraft:pink_terracotta
fill 329 103 504 329 103 505 minecraft:red_concrete
fill 330 103 463 332 201 463 minecraft:pink_terracotta
setblock 330 103 475 minecraft:white_concrete
setblock 330 103 478 minecraft:red_nether_bricks
fill 330 103 479 330 106 479 minecraft:pink_terracotta
setblock 330 103 482 minecraft:pink_terracotta
setblock 330 103 483 minecraft:red_nether_bricks
fill 330 103 484 330 106 484 minecraft:pink_terracotta
setblock 330 103 487 minecraft:pink_terracotta
setblock 330 103 488 minecraft:red_nether_bricks
fill 330 103 489 330 106 489 minecraft:pink_terracotta
setblock 330 103 493 minecraft:red_nether_bricks
setblock 330 103 498 minecraft:red_nether_bricks
fill 330 103 499 330 106 499 minecraft:pink_terracotta
setblock 330 103 503 minecraft:red_nether_bricks
fill 330 103 504 330 106 505 minecraft:pink_terracotta
setblock 331 103 497 minecraft:red_nether_bricks
fill 331 103 498 331 105 498 minecraft:pink_terracotta
setblock 331 103 502 minecraft:red_nether_bricks
fill 331 103 503 331 106 503 minecraft:pink_terracotta
fill 331 103 505 333 204 505 minecraft:pink_terracotta
setblock 332 103 466 minecraft:light[level=12]
setblock 332 103 474 minecraft:light[level=12]
setblock 332 103 482 minecraft:light[level=12]
setblock 332 103 490 minecraft:light[level=12]
setblock 332 103 498 minecraft:light[level=12]
setblock 333 103 463 minecraft:red_concrete
fill 334 103 463 337 201 463 minecraft:pink_terracotta
setblock 334 103 504 minecraft:red_nether_bricks
setblock 334 103 505 minecraft:red_concrete
fill 335 103 504 337 104 505 minecraft:pink_terracotta
setblock 338 103 463 minecraft:red_concrete
setblock 338 103 504 minecraft:pink_terracotta
fill 339 103 463 341 200 463 minecraft:pink_terracotta
setblock 339 103 504 minecraft:red_nether_bricks
setblock 340 103 466 minecraft:light[level=12]
fill 340 103 471 341 104 472 minecraft:red_concrete
setblock 340 103 474 minecraft:light[level=12]
setblock 340 103 482 minecraft:light[level=12]
setblock 340 103 490 minecraft:light[level=12]
setblock 340 103 498 minecraft:light[level=12]
setblock 340 103 503 minecraft:red_nether_bricks
fill 340 103 504 340 106 504 minecraft:pink_terracotta
fill 341 103 464 343 103 464 minecraft:pink_terracotta
fill 341 103 503 344 103 503 minecraft:pink_terracotta
fill 342 103 463 343 103 463 minecraft:red_concrete
fill 344 103 463 344 200 463 minecraft:pink_terracotta
setblock 344 103 464 minecraft:red_nether_bricks
setblock 344 103 504 minecraft:red_nether_bricks
fill 345 103 464 345 106 464 minecraft:pink_terracotta
setblock 345 103 503 minecraft:red_nether_bricks
fill 345 103 504 345 106 505 minecraft:pink_terracotta
fill 346 103 503 347 105 503 minecraft:pink_terracotta
fill 347 103 505 349 202 505 minecraft:pink_terracotta
setblock 348 103 466 minecraft:light[level=12]
setblock 348 103 474 minecraft:light[level=12]
setblock 348 103 482 minecraft:light[level=12]
setblock 348 103 490 minecraft:light[level=12]
setblock 348 103 498 minecraft:light[level=12]
setblock 349 103 464 minecraft:red_nether_bricks
setblock 349 103 504 minecraft:red_nether_bricks
fill 350 103 464 353 103 464 minecraft:pink_terracotta
fill 350 103 504 351 105 504 minecraft:pink_terracotta
setblock 350 103 505 minecraft:red_concrete
fill 351 103 492 351 104 492 minecraft:pink_concrete
fill 351 103 505 357 200 505 minecraft:pink_terracotta
setblock 354 103 464 minecraft:red_nether_bricks
fill 355 103 464 358 103 464 minecraft:pink_terracotta
fill 355 103 504 358 103 504 minecraft:pink_terracotta
fill 356 103 463 356 204 463 minecraft:pink_terracotta
setblock 356 103 466 minecraft:light[level=12]
setblock 356 103 474 minecraft:light[level=12]
setblock 356 103 482 minecraft:light[level=12]
setblock 356 103 490 minecraft:light[level=12]
setblock 356 103 498 minecraft:light[level=12]
fill 358 103 503 359 103 503 minecraft:pink_terracotta
setblock 358 103 505 minecraft:red_concrete
fill 359 103 463 359 201 463 minecraft:pink_terracotta
setblock 359 103 464 minecraft:red_nether_bricks
fill 359 103 465 360 105 465 minecraft:pink_terracotta
setblock 359 103 504 minecraft:red_nether_bricks
fill 359 103 505 366 200 505 minecraft:pink_terracotta
setblock 360 103 463 minecraft:red_concrete
fill 360 103 464 360 106 464 minecraft:pink_terracotta
setblock 360 103 503 minecraft:red_nether_bricks
fill 360 103 504 360 106 504 minecraft:pink_terracotta
fill 361 103 463 362 200 463 minecraft:pink_terracotta
setblock 361 103 502 minecraft:red_nether_bricks
fill 361 103 503 361 106 503 minecraft:pink_terracotta
setblock 362 103 465 minecraft:pink_terracotta
fill 362 103 502 362 106 502 minecraft:pink_terracotta
setblock 363 103 465 minecraft:red_nether_bricks
fill 363 103 501 366 103 501 minecraft:pink_terracotta
fill 364 103 463 364 204 463 minecraft:pink_terracotta
setblock 364 103 464 minecraft:red_nether_bricks
fill 364 103 465 364 106 465 minecraft:pink_terracotta
setblock 364 103 466 minecraft:light[level=12]
setblock 364 103 474 minecraft:light[level=12]
setblock 364 103 482 minecraft:light[level=12]
setblock 364 103 490 minecraft:light[level=12]
setblock 364 103 498 minecraft:light[level=12]
setblock 364 103 504 minecraft:red_nether_bricks
setblock 365 103 463 minecraft:red_concrete
fill 365 103 464 365 106 464 minecraft:pink_terracotta
setblock 365 103 503 minecraft:red_nether_bricks
fill 365 103 504 365 106 504 minecraft:pink_terracotta
fill 366 103 463 371 202 463 minecraft:pink_terracotta
setblock 366 103 502 minecraft:red_nether_bricks
fill 366 103 503 366 106 503 minecraft:pink_terracotta
setblock 367 103 501 minecraft:red_nether_bricks
fill 367 103 502 367 106 502 minecraft:pink_terracotta
setblock 367 103 505 minecraft:red_concrete
setblock 368 103 465 minecraft:red_nether_bricks
setblock 368 103 500 minecraft:red_nether_bricks
fill 368 103 501 368 106 501 minecraft:pink_terracotta
fill 368 103 505 369 204 505 minecraft:pink_terracotta
setblock 369 103 464 minecraft:red_nether_bricks
setblock 369 103 499 minecraft:red_nether_bricks
fill 369 103 500 369 106 500 minecraft:pink_terracotta
setblock 369 103 504 minecraft:red_nether_bricks
fill 370 103 464 370 106 464 minecraft:pink_terracotta
setblock 370 103 468 minecraft:white_concrete
setblock 370 103 478 minecraft:red_nether_bricks
fill 370 103 479 370 106 479 minecraft:pink_terracotta
setblock 370 103 483 minecraft:red_nether_bricks
setblock 370 103 493 minecraft:white_concrete
fill 370 103 494 371 106 494 minecraft:pink_terracotta
fill 370 103 496 370 104 496 minecraft:pink_terracotta
setblock 370 103 498 minecraft:red_nether_bricks
fill 370 103 499 370 106 499 minecraft:pink_terracotta
setblock 370 103 503 minecraft:red_nether_bricks
fill 370 103 504 370 106 504 minecraft:pink_terracotta
setblock 371 103 464 minecraft:red_concrete
fill 371 103 466 371 200 468 minecraft:pink_terracotta
setblock 371 103 469 minecraft:red_concrete
fill 371 103 470 371 200 471 minecraft:pink_terracotta
fill 371 103 475 371 204 475 minecraft:pink_terracotta
fill 371 103 483 371 204 483 minecraft:pink_terracotta
fill 371 103 486 371 200 489 minecraft:pink_terracotta
setblock 371 103 490 minecraft:red_concrete
fill 371 103 491 371 204 492 minecraft:pink_terracotta
setblock 371 103 493 minecraft:red_concrete
setblock 371 103 496 minecraft:red_concrete
fill 371 103 503 371 204 503 minecraft:pink_terracotta
fill 329 104 468 329 204 468 minecraft:pink_terracotta
fill 329 104 476 329 202 477 minecraft:pink_terracotta
fill 329 104 497 329 204 497 minecraft:pink_terracotta
fill 329 104 504 329 204 505 minecraft:pink_terracotta
setblock 330 104 477 minecraft:red_nether_bricks
fill 330 104 478 330 107 478 minecraft:pink_terracotta
setblock 330 104 482 minecraft:red_nether_bricks
fill 330 104 483 331 106 483 minecraft:pink_terracotta
setblock 330 104 487 minecraft:red_nether_bricks
fill 330 104 488 330 107 488 minecraft:pink_terracotta
setblock 330 104 492 minecraft:red_nether_bricks
fill 330 104 493 330 107 493 minecraft:pink_terracotta
setblock 330 104 497 minecraft:red_nether_bricks
fill 330 104 498 330 107 498 minecraft:pink_terracotta
setblock 330 104 502 minecraft:red_nether_bricks
fill 330 104 503 330 107 503 minecraft:pink_terracotta
setblock 331 104 480 minecraft:pink_terracotta
setblock 331 104 481 minecraft:red_nether_bricks
fill 331 104 482 331 107 482 minecraft:pink_terracotta
fill 331 104 484 331 105 484 minecraft:pink_terracotta
setblock 331 104 497 minecraft:pink_terracotta
setblock 331 104 501 minecraft:red_nether_bricks
fill 331 104 502 331 107 502 minecraft:pink_terracotta
fill 332 104 503 332 105 503 minecraft:pink_terracotta
fill 333 104 463 333 204 463 minecraft:pink_terracotta
setblock 333 104 504 minecraft:red_nether_bricks
fill 334 104 504 334 107 505 minecraft:pink_terracotta
fill 338 104 463 338 204 463 minecraft:pink_terracotta
setblock 338 104 503 minecraft:pink_terracotta
setblock 338 104 504 minecraft:red_nether_bricks
setblock 339 104 503 minecraft:red_nether_bricks
fill 339 104 504 339 107 504 minecraft:pink_terracotta
fill 340 104 464 342 104 464 minecraft:pink_terracotta
fill 340 104 503 343 104 503 minecraft:pink_terracotta
fill 342 104 463 343 204 463 minecraft:pink_terracotta
setblock 342 104 504 minecraft:pink_terracotta
setblock 343 104 464 minecraft:red_nether_bricks
fill 343 104 465 346 104 465 minecraft:pink_terracotta
setblock 343 104 504 minecraft:red_nether_bricks
fill 344 104 464 344 107 464 minecraft:pink_terracotta
setblock 344 104 503 minecraft:red_nether_bricks
fill 344 104 504 344 107 504 minecraft:pink_terracotta
fill 345 104 503 345 107 503 minecraft:pink_terracotta
setblock 347 104 464 minecraft:pink_terracotta
setblock 347 104 465 minecraft:red_nether_bricks
setblock 348 104 464 minecraft:red_nether_bricks
setblock 348 104 503 minecraft:pink_terracotta
setblock 348 104 504 minecraft:red_nether_bricks
fill 349 104 464 352 104 464 minecraft:pink_terracotta
fill 349 104 504 349 107 504 minecraft:pink_terracotta
fill 350 104 505 350 202 505 minecraft:pink_terracotta
setblock 352 104 504 minecraft:pink_terracotta
setblock 353 104 464 minecraft:red_nether_bricks
setblock 353 104 504 minecraft:red_nether_bricks
fill 354 104 464 357 104 464 minecraft:pink_terracotta
fill 354 104 504 357 104 504 minecraft:pink_terracotta
fill 357 104 503 358 104 503 minecraft:pink_terracotta
setblock 358 104 464 minecraft:red_nether_bricks
fill 358 104 465 358 107 465 minecraft:pink_terracotta
setblock 358 104 504 minecraft:red_nether_bricks
fill 358 104 505 358 202 505 minecraft:pink_terracotta
fill 359 104 464 359 107 464 minecraft:pink_terracotta
setblock 359 104 502 minecraft:pink_terracotta
setblock 359 104 503 minecraft:red_nether_bricks
fill 359 104 504 359 107 504 minecraft:pink_terracotta
fill 360 104 463 360 202 463 minecraft:pink_terracotta
setblock 360 104 502 minecraft:red_nether_bricks
fill 360 104 503 360 107 503 minecraft:pink_terracotta
fill 361 104 502 361 107 502 minecraft:pink_terracotta
setblock 362 104 465 minecraft:red_nether_bricks
fill 362 104 466 364 105 466 minecraft:pink_terracotta
fill 362 104 501 365 104 501 minecraft:pink_terracotta
fill 363 104 463 363 205 463 minecraft:pink_terracotta
setblock 363 104 464 minecraft:red_nether_bricks
fill 363 104 465 363 107 465 minecraft:pink_terracotta
setblock 363 104 504 minecraft:red_nether_bricks
fill 364 104 464 364 107 464 minecraft:pink_terracotta
setblock 364 104 503 minecraft:red_nether_bricks
fill 364 104 504 364 107 504 minecraft:pink_terracotta
fill 365 104 463 365 204 463 minecraft:pink_terracotta
fill 365 104 467 365 113 467 minecraft:iron_block
setblock 365 104 502 minecraft:red_nether_bricks
fill 365 104 503 365 107 503 minecraft:pink_terracotta
setblock 366 104 501 minecraft:red_nether_bricks
fill 366 104 502 366 107 502 minecraft:pink_terracotta
setblock 367 104 465 minecraft:red_nether_bricks
setblock 367 104 500 minecraft:red_nether_bricks
fill 367 104 501 367 107 501 minecraft:pink_terracotta
fill 367 104 505 367 204 505 minecraft:pink_terracotta
setblock 368 104 464 minecraft:red_nether_bricks
fill 368 104 465 368 107 465 minecraft:pink_terracotta
setblock 368 104 499 minecraft:red_nether_bricks
fill 368 104 500 368 107 500 minecraft:pink_terracotta
setblock 368 104 504 minecraft:red_nether_bricks
fill 369 104 464 369 107 464 minecraft:pink_terracotta
setblock 369 104 498 minecraft:red_nether_bricks
fill 369 104 499 369 107 499 minecraft:pink_terracotta
setblock 369 104 503 minecraft:red_nether_bricks
fill 369 104 504 369 107 504 minecraft:pink_terracotta
setblock 370 104 477 minecraft:red_nether_bricks
fill 370 104 478 370 105 478 minecraft:pink_terracotta
setblock 370 104 482 minecraft:red_nether_bricks
fill 370 104 483 370 105 485 minecraft:pink_terracotta
setblock 370 104 487 minecraft:white_concrete
setblock 370 104 497 minecraft:red_nether_bricks
fill 370 104 498 370 107 498 minecraft:pink_terracotta
setblock 370 104 502 minecraft:red_nether_bricks
fill 370 104 503 370 107 503 minecraft:pink_terracotta
fill 371 104 464 371 204 464 minecraft:pink_terracotta
fill 371 104 469 371 204 469 minecraft:pink_terracotta
fill 371 104 482 371 205 482 minecraft:pink_terracotta
fill 371 104 490 371 202 490 minecraft:pink_terracotta
fill 371 104 493 371 204 493 minecraft:pink_terracotta
fill 371 104 496 371 204 496 minecraft:pink_terracotta
setblock 330 105 468 minecraft:white_concrete
fill 330 105 477 330 106 477 minecraft:pink_terracotta
setblock 330 105 481 minecraft:red_nether_bricks
fill 330 105 482 330 108 482 minecraft:pink_terracotta
setblock 330 105 485 minecraft:pink_terracotta
setblock 330 105 486 minecraft:red_nether_bricks
fill 330 105 487 330 108 487 minecraft:pink_terracotta
setblock 330 105 491 minecraft:red_nether_bricks
fill 330 105 492 330 108 492 minecraft:pink_terracotta
setblock 330 105 496 minecraft:red_nether_bricks
fill 330 105 497 330 108 497 minecraft:pink_terracotta
setblock 330 105 501 minecraft:red_nether_bricks
fill 330 105 502 330 108 502 minecraft:pink_terracotta
setblock 331 105 480 minecraft:red_nether_bricks
fill 331 105 481 331 108 481 minecraft:pink_terracotta
setblock 331 105 485 minecraft:red_nether_bricks
fill 331 105 486 331 108 486 minecraft:pink_terracotta
setblock 331 105 500 minecraft:red_nether_bricks
fill 331 105 501 331 107 501 minecraft:pink_terracotta
setblock 332 105 504 minecraft:red_nether_bricks
fill 333 105 504 333 108 504 minecraft:pink_terracotta
fill 335 105 504 336 105 505 minecraft:pink_terracotta
setblock 337 105 464 minecraft:white_concrete
setblock 337 105 503 minecraft:pink_terracotta
setblock 337 105 504 minecraft:red_nether_bricks
fill 337 105 505 337 201 505 minecraft:pink_terracotta
fill 338 105 464 341 105 464 minecraft:pink_terracotta
setblock 338 105 503 minecraft:red_nether_bricks
fill 338 105 504 338 108 504 minecraft:pink_terracotta
fill 339 105 503 342 105 503 minecraft:pink_terracotta
setblock 341 105 465 minecraft:red_nether_bricks
fill 341 105 502 343 105 502 minecraft:pink_terracotta
setblock 342 105 464 minecraft:red_nether_bricks
fill 342 105 465 345 105 465 minecraft:pink_terracotta
setblock 342 105 504 minecraft:red_nether_bricks
fill 343 105 464 343 108 464 minecraft:pink_terracotta
setblock 343 105 503 minecraft:red_nether_bricks
fill 343 105 504 343 108 504 minecraft:pink_terracotta
setblock 344 105 502 minecraft:red_nether_bricks
fill 344 105 503 344 108 503 minecraft:pink_terracotta
setblock 346 105 465 minecraft:red_nether_bricks
setblock 347 105 464 minecraft:red_nether_bricks
fill 347 105 465 349 106 465 minecraft:pink_terracotta
setblock 347 105 504 minecraft:red_nether_bricks
fill 348 105 464 351 105 464 minecraft:pink_terracotta
setblock 348 105 503 minecraft:red_nether_bricks
fill 348 105 504 348 108 504 minecraft:pink_terracotta
setblock 352 105 464 minecraft:red_nether_bricks
setblock 352 105 504 minecraft:red_nether_bricks
fill 353 105 464 356 105 464 minecraft:pink_terracotta
fill 353 105 504 356 105 504 minecraft:pink_terracotta
setblock 355 105 465 minecraft:pink_terracotta
setblock 356 105 465 minecraft:red_nether_bricks
fill 356 105 503 357 105 503 minecraft:pink_terracotta
setblock 357 105 464 minecraft:red_nether_bricks
fill 357 105 465 357 108 465 minecraft:pink_terracotta
setblock 357 105 504 minecraft:red_nether_bricks
fill 358 105 464 358 108 464 minecraft:pink_terracotta
setblock 358 105 502 minecraft:pink_terracotta
setblock 358 105 503 minecraft:red_nether_bricks
fill 358 105 504 358 108 504 minecraft:pink_terracotta
setblock 359 105 502 minecraft:red_nether_bricks
fill 359 105 503 359 108 503 minecraft:pink_terracotta
setblock 360 105 466 minecraft:red_nether_bricks
fill 360 105 502 360 108 502 minecraft:pink_terracotta
setblock 361 105 464 minecraft:pink_terracotta
setblock 361 105 465 minecraft:red_nether_bricks
fill 361 105 466 361 108 466 minecraft:pink_terracotta
fill 361 105 501 364 105 501 minecraft:pink_terracotta
setblock 362 105 464 minecraft:red_nether_bricks
fill 362 105 465 362 108 465 minecraft:pink_terracotta
setblock 362 105 504 minecraft:red_nether_bricks
fill 363 105 464 363 108 464 minecraft:pink_terracotta
setblock 363 105 503 minecraft:red_nether_bricks
fill 363 105 504 363 108 504 minecraft:pink_terracotta
setblock 364 105 502 minecraft:red_nether_bricks
fill 364 105 503 364 108 503 minecraft:pink_terracotta
setblock 365 105 466 minecraft:red_nether_bricks
setblock 365 105 501 minecraft:red_nether_bricks
fill 365 105 502 365 108 502 minecraft:pink_terracotta
setblock 366 105 465 minecraft:red_nether_bricks
fill 366 105 501 366 107 501 minecraft:pink_terracotta
setblock 367 105 464 minecraft:red_nether_bricks
fill 367 105 465 367 108 465 minecraft:pink_terracotta
fill 367 105 500 367 106 500 minecraft:pink_terracotta
setblock 367 105 504 minecraft:red_nether_bricks
fill 368 105 464 368 108 464 minecraft:pink_terracotta
setblock 368 105 498 minecraft:red_nether_bricks
fill 368 105 499 368 107 499 minecraft:pink_terracotta
setblock 368 105 503 minecraft:red_nether_bricks
fill 368 105 504 368 108 504 minecraft:pink_terracotta
fill 369 105 465 369 106 465 minecraft:pink_terracotta
setblock 369 105 497 minecraft:red_nether_bricks
fill 369 105 498 369 107 498 minecraft:pink_terracotta
setblock 369 105 502 minecraft:red_nether_bricks
fill 369 105 503 369 108 503 minecraft:pink_terracotta
setblock 370 105 466 minecraft:red_nether_bricks
fill 370 105 475 370 106 475 minecraft:white_concrete
setblock 370 105 481 minecraft:red_nether_bricks
fill 370 105 482 370 108 482 minecraft:pink_terracotta
setblock 370 105 486 minecraft:red_nether_bricks
fill 370 105 487 370 108 487 minecraft:pink_terracotta
setblock 370 105 496 minecraft:red_nether_bricks
fill 370 105 497 370 108 497 minecraft:pink_terracotta
setblock 370 105 501 minecraft:red_nether_bricks
fill 370 105 502 370 108 502 minecraft:pink_terracotta
fill 371 105 481 371 204 481 minecraft:pink_terracotta
fill 371 105 501 371 204 501 minecraft:pink_terracotta
fill 329 106 495 329 205 495 minecraft:pink_terracotta
setblock 330 106 474 minecraft:white_concrete
setblock 330 106 480 minecraft:red_nether_bricks
fill 330 106 481 330 109 481 minecraft:pink_terracotta
setblock 330 106 485 minecraft:red_nether_bricks
fill 330 106 486 330 109 486 minecraft:pink_terracotta
setblock 330 106 490 minecraft:red_nether_bricks
fill 330 106 491 330 109 491 minecraft:pink_terracotta
setblock 330 106 495 minecraft:red_nether_bricks
fill 330 106 496 330 108 496 minecraft:pink_terracotta
setblock 330 106 500 minecraft:red_nether_bricks
fill 330 106 501 330 109 501 minecraft:pink_terracotta
setblock 331 106 464 minecraft:white_concrete
fill 331 106 480 331 107 480 minecraft:pink_terracotta
setblock 331 106 484 minecraft:red_nether_bricks
fill 331 106 485 331 109 485 minecraft:pink_terracotta
fill 331 106 487 331 107 487 minecraft:pink_terracotta
setblock 331 106 499 minecraft:red_nether_bricks
setblock 331 106 500 minecraft:pink_terracotta
setblock 331 106 504 minecraft:red_nether_bricks
setblock 332 106 503 minecraft:red_nether_bricks
fill 332 106 504 332 109 504 minecraft:pink_terracotta
fill 335 106 504 335 106 505 minecraft:pink_terracotta
setblock 336 106 464 minecraft:red_nether_bricks
setblock 336 106 503 minecraft:pink_terracotta
setblock 336 106 504 minecraft:red_nether_bricks
fill 336 106 505 336 204 505 minecraft:pink_terracotta
fill 337 106 464 340 106 464 minecraft:pink_terracotta
setblock 337 106 503 minecraft:red_nether_bricks
fill 337 106 504 337 109 504 minecraft:pink_terracotta
fill 338 106 503 341 106 503 minecraft:pink_terracotta
setblock 340 106 465 minecraft:red_nether_bricks
setblock 341 106 464 minecraft:red_nether_bricks
fill 341 106 465 344 106 465 minecraft:pink_terracotta
fill 341 106 502 342 106 502 minecraft:pink_terracotta
setblock 341 106 504 minecraft:red_nether_bricks
fill 342 106 464 342 109 464 minecraft:pink_terracotta
setblock 342 106 503 minecraft:red_nether_bricks
fill 342 106 504 342 109 504 minecraft:pink_terracotta
setblock 343 106 502 minecraft:red_nether_bricks
fill 343 106 503 343 109 503 minecraft:pink_terracotta
setblock 344 106 502 minecraft:pink_terracotta
setblock 345 106 465 minecraft:red_nether_bricks
setblock 346 106 464 minecraft:red_nether_bricks
fill 346 106 465 346 109 465 minecraft:pink_terracotta
setblock 346 106 503 minecraft:pink_terracotta
setblock 346 106 504 minecraft:red_nether_bricks
fill 346 106 505 346 202 505 minecraft:pink_terracotta
fill 347 106 464 350 106 464 minecraft:pink_terracotta
setblock 347 106 503 minecraft:red_nether_bricks
fill 347 106 504 347 109 504 minecraft:pink_terracotta
fill 348 106 503 348 107 503 minecraft:pink_terracotta
setblock 350 106 465 minecraft:red_nether_bricks
setblock 350 106 504 minecraft:pink_terracotta
setblock 351 106 464 minecraft:red_nether_bricks
fill 351 106 465 354 106 465 minecraft:pink_terracotta
setblock 351 106 504 minecraft:red_nether_bricks
fill 352 106 464 355 106 464 minecraft:pink_terracotta
fill 352 106 504 355 106 504 minecraft:pink_terracotta
setblock 355 106 465 minecraft:red_nether_bricks
fill 355 106 503 356 106 503 minecraft:pink_terracotta
setblock 356 106 464 minecraft:red_nether_bricks
fill 356 106 465 356 109 465 minecraft:pink_terracotta
setblock 356 106 504 minecraft:red_nether_bricks
fill 357 106 464 357 109 464 minecraft:pink_terracotta
setblock 357 106 503 minecraft:red_nether_bricks
fill 357 106 504 357 109 504 minecraft:pink_terracotta
setblock 358 106 466 minecraft:pink_terracotta
setblock 358 106 502 minecraft:red_nether_bricks
fill 358 106 503 358 109 503 minecraft:pink_terracotta
setblock 359 106 465 minecraft:pink_terracotta
setblock 359 106 466 minecraft:red_nether_bricks
fill 359 106 502 359 109 502 minecraft:pink_terracotta
setblock 360 106 465 minecraft:red_nether_bricks
fill 360 106 466 360 109 466 minecraft:pink_terracotta
setblock 361 106 464 minecraft:red_nether_bricks
fill 361 106 465 361 109 465 minecraft:pink_terracotta
fill 361 106 501 363 106 501 minecraft:pink_terracotta
setblock 361 106 504 minecraft:red_nether_bricks
fill 362 106 464 362 109 464 minecraft:pink_terracotta
fill 362 106 466 363 106 466 minecraft:pink_terracotta
setblock 362 106 503 minecraft:red_nether_bricks
fill 362 106 504 362 109 504 minecraft:pink_terracotta
setblock 363 106 502 minecraft:red_nether_bricks
fill 363 106 503 363 109 503 minecraft:pink_terracotta
setblock 364 106 466 minecraft:red_nether_bricks
setblock 364 106 501 minecraft:red_nether_bricks
fill 364 106 502 364 109 502 minecraft:pink_terracotta
setblock 365 106 465 minecraft:red_nether_bricks
fill 365 106 466 366 107 466 minecraft:pink_terracotta
fill 365 106 501 365 108 501 minecraft:pink_terracotta
setblock 366 106 464 minecraft:red_nether_bricks
fill 366 106 465 366 109 465 minecraft:pink_terracotta
setblock 366 106 504 minecraft:red_nether_bricks
fill 367 106 464 367 109 464 minecraft:pink_terracotta
setblock 367 106 503 minecraft:red_nether_bricks
fill 367 106 504 367 109 504 minecraft:pink_terracotta
setblock 368 106 502 minecraft:red_nether_bricks
fill 368 106 503 368 109 503 minecraft:pink_terracotta
fill 369 106 497 369 107 497 minecraft:pink_terracotta
setblock 369 106 501 minecraft:red_nether_bricks
fill 369 106 502 369 109 502 minecraft:pink_terracotta
setblock 370 106 465 minecraft:red_nether_bricks
fill 370 106 466 370 108 466 minecraft:pink_terracotta
setblock 370 106 469 minecraft:white_concrete
setblock 370 106 480 minecraft:red_nether_bricks
fill 370 106 481 370 108 481 minecraft:pink_terracotta
fill 370 106 483 370 106 484 minecraft:pink_terracotta
setblock 370 106 485 minecraft:red_nether_bricks
fill 370 106 486 370 109 486 minecraft:pink_terracotta
fill 370 106 488 370 107 488 minecraft:pink_terracotta
setblock 370 106 495 minecraft:red_nether_bricks
fill 370 106 496 370 108 496 minecraft:pink_terracotta
setblock 370 106 500 minecraft:red_nether_bricks
fill 370 106 501 370 109 501 minecraft:pink_terracotta
fill 371 106 465 371 204 465 minecraft:pink_terracotta
fill 371 106 495 371 202 495 minecraft:pink_terracotta
fill 329 107 494 329 201 494 minecraft:pink_terracotta
setblock 330 107 479 minecraft:red_nether_bricks
fill 330 107 480 330 110 480 minecraft:pink_terracotta
setblock 330 107 483 minecraft:pink_terracotta
setblock 330 107 484 minecraft:red_nether_bricks
fill 330 107 485 330 110 485 minecraft:pink_terracotta
setblock 330 107 489 minecraft:red_nether_bricks
fill 330 107 490 330 110 490 minecraft:pink_terracotta
setblock 330 107 494 minecraft:red_nether_bricks
setblock 330 107 495 minecraft:pink_terracotta
setblock 330 107 499 minecraft:red_nether_bricks
fill 330 107 500 330 109 500 minecraft:pink_terracotta
setblock 330 107 504 minecraft:red_nether_bricks
fill 330 107 505 330 201 505 minecraft:pink_terracotta
setblock 331 107 483 minecraft:red_nether_bricks
fill 331 107 484 331 110 484 minecraft:pink_terracotta
setblock 331 107 488 minecraft:red_nether_bricks
setblock 331 107 503 minecraft:red_nether_bricks
fill 331 107 504 331 110 504 minecraft:pink_terracotta
setblock 335 107 464 minecraft:red_nether_bricks
fill 335 107 493 335 125 493 minecraft:iron_block
setblock 335 107 504 minecraft:red_nether_bricks
fill 335 107 505 335 204 505 minecraft:pink_terracotta
fill 336 107 464 339 107 464 minecraft:pink_terracotta
setblock 336 107 503 minecraft:red_nether_bricks
fill 336 107 504 336 110 504 minecraft:pink_terracotta
fill 337 107 503 340 107 503 minecraft:pink_terracotta
setblock 339 107 465 minecraft:red_nether_bricks
setblock 340 107 464 minecraft:red_nether_bricks
fill 340 107 465 343 107 465 minecraft:pink_terracotta
setblock 340 107 504 minecraft:red_nether_bricks
fill 341 107 464 341 110 464 minecraft:pink_terracotta
setblock 341 107 502 minecraft:pink_terracotta
setblock 341 107 503 minecraft:red_nether_bricks
fill 341 107 504 341 110 504 minecraft:pink_terracotta
setblock 342 107 466 minecraft:pink_terracotta
setblock 342 107 502 minecraft:red_nether_bricks
fill 342 107 503 342 110 503 minecraft:pink_terracotta
setblock 343 107 466 minecraft:red_nether_bricks
setblock 343 107 502 minecraft:pink_terracotta
setblock 344 107 465 minecraft:red_nether_bricks
fill 344 107 466 345 109 466 minecraft:pink_terracotta
setblock 345 107 464 minecraft:red_nether_bricks
fill 345 107 465 345 110 465 minecraft:pink_terracotta
setblock 345 107 504 minecraft:red_nether_bricks
fill 345 107 505 345 205 505 minecraft:pink_terracotta
fill 346 107 464 349 107 464 minecraft:pink_terracotta
setblock 346 107 503 minecraft:red_nether_bricks
fill 346 107 504 346 110 504 minecraft:pink_terracotta
fill 347 107 465 348 107 465 minecraft:pink_terracotta
setblock 347 107 503 minecraft:pink_terracotta
setblock 349 107 465 minecraft:red_nether_bricks
setblock 350 107 464 minecraft:red_nether_bricks
fill 350 107 465 353 107 465 minecraft:pink_terracotta
setblock 350 107 504 minecraft:red_nether_bricks
fill 351 107 464 354 107 464 minecraft:pink_terracotta
fill 351 107 504 354 107 504 minecraft:pink_terracotta
setblock 354 107 465 minecraft:red_nether_bricks
fill 354 107 503 355 107 503 minecraft:pink_terracotta
setblock 355 107 464 minecraft:red_nether_bricks
fill 355 107 465 355 110 465 minecraft:pink_terracotta
setblock 355 107 504 minecraft:red_nether_bricks
fill 356 107 464 356 110 464 minecraft:pink_terracotta
setblock 356 107 503 minecraft:red_nether_bricks
fill 356 107 504 356 110 504 minecraft:pink_terracotta
setblock 357 107 466 minecraft:pink_terracotta
setblock 357 107 502 minecraft:red_nether_bricks
fill 357 107 503 357 110 503 minecraft:pink_terracotta
setblock 358 107 466 minecraft:red_nether_bricks
fill 358 107 502 358 110 502 minecraft:pink_terracotta
setblock 359 107 465 minecraft:red_nether_bricks
fill 359 107 466 359 110 466 minecraft:pink_terracotta
setblock 360 107 464 minecraft:red_nether_bricks
fill 360 107 465 360 110 465 minecraft:pink_terracotta
fill 360 107 501 362 107 501 minecraft:pink_terracotta
setblock 360 107 504 minecraft:red_nether_bricks
fill 361 107 464 361 110 464 minecraft:pink_terracotta
setblock 361 107 503 minecraft:red_nether_bricks
fill 361 107 504 361 110 504 minecraft:pink_terracotta
setblock 362 107 466 minecraft:pink_terracotta
setblock 362 107 502 minecraft:red_nether_bricks
fill 362 107 503 362 110 503 minecraft:pink_terracotta
setblock 363 107 466 minecraft:red_nether_bricks
setblock 363 107 501 minecraft:red_nether_bricks
fill 363 107 502 363 110 502 minecraft:pink_terracotta
setblock 364 107 465 minecraft:red_nether_bricks
fill 364 107 466 364 110 466 minecraft:pink_terracotta
fill 364 107 501 364 108 501 minecraft:pink_terracotta
setblock 365 107 464 minecraft:red_nether_bricks
fill 365 107 465 365 110 465 minecraft:pink_terracotta
setblock 365 107 504 minecraft:red_nether_bricks
fill 366 107 464 366 110 464 minecraft:pink_terracotta
setblock 366 107 503 minecraft:red_nether_bricks
fill 366 107 504 366 110 504 minecraft:pink_terracotta
setblock 367 107 502 minecraft:red_nether_bricks
fill 367 107 503 367 110 503 minecraft:pink_terracotta
setblock 368 107 501 minecraft:red_nether_bricks
fill 368 107 502 368 108 502 minecraft:pink_terracotta
setblock 369 107 465 minecraft:red_nether_bricks
setblock 369 107 500 minecraft:red_nether_bricks
fill 369 107 501 369 109 501 minecraft:pink_terracotta
setblock 370 107 464 minecraft:red_nether_bricks
fill 370 107 465 370 110 465 minecraft:pink_terracotta
setblock 370 107 480 minecraft:pink_terracotta
setblock 370 107 483 minecraft:pink_terracotta
setblock 370 107 484 minecraft:red_nether_bricks
fill 370 107 485 370 110 485 minecraft:pink_terracotta
setblock 370 107 489 minecraft:red_nether_bricks
setblock 370 107 494 minecraft:red_nether_bricks
fill 370 107 495 370 108 495 minecraft:pink_terracotta
setblock 370 107 499 minecraft:red_nether_bricks
fill 370 107 500 370 110 500 minecraft:pink_terracotta
setblock 370 107 504 minecraft:red_nether_bricks
fill 371 107 494 371 204 494 minecraft:pink_terracotta
fill 330 108 467 330 109 467 minecraft:white_concrete
fill 330 108 479 330 109 479 minecraft:pink_terracotta
setblock 330 108 483 minecraft:red_nether_bricks
fill 330 108 484 330 111 484 minecraft:pink_terracotta
setblock 330 108 488 minecraft:red_nether_bricks
fill 330 108 489 330 111 489 minecraft:pink_terracotta
setblock 330 108 493 minecraft:red_nether_bricks
setblock 330 108 498 minecraft:red_nether_bricks
setblock 330 108 499 minecraft:pink_terracotta
setblock 330 108 503 minecraft:red_nether_bricks
fill 330 108 504 330 110 504 minecraft:pink_terracotta
setblock 331 108 482 minecraft:red_nether_bricks
fill 331 108 483 331 111 483 minecraft:pink_terracotta
setblock 331 108 487 minecraft:red_nether_bricks
fill 331 108 488 331 111 488 minecraft:pink_terracotta
setblock 334 108 464 minecraft:red_nether_bricks
setblock 334 108 504 minecraft:red_nether_bricks
fill 334 108 505 334 201 505 minecraft:pink_terracotta
fill 335 108 464 338 108 464 minecraft:pink_terracotta
fill 335 108 504 335 111 504 minecraft:pink_terracotta
fill 336 108 503 339 108 503 minecraft:pink_terracotta
setblock 338 108 465 minecraft:red_nether_bricks
setblock 339 108 464 minecraft:red_nether_bricks
fill 339 108 465 342 108 465 minecraft:pink_terracotta
setblock 339 108 504 minecraft:red_nether_bricks
fill 340 108 464 340 111 464 minecraft:pink_terracotta
setblock 340 108 503 minecraft:red_nether_bricks
fill 340 108 504 340 111 504 minecraft:pink_terracotta
setblock 341 108 466 minecraft:pink_terracotta
fill 341 108 503 341 110 503 minecraft:pink_terracotta
setblock 342 108 466 minecraft:red_nether_bricks
setblock 343 108 465 minecraft:red_nether_bricks
fill 343 108 466 343 111 466 minecraft:pink_terracotta
setblock 344 108 464 minecraft:red_nether_bricks
fill 344 108 465 344 111 465 minecraft:pink_terracotta
setblock 344 108 504 minecraft:red_nether_bricks
fill 345 108 464 348 108 464 minecraft:pink_terracotta
setblock 345 108 503 minecraft:red_nether_bricks
fill 345 108 504 345 111 504 minecraft:pink_terracotta
setblock 346 108 503 minecraft:pink_terracotta
setblock 347 108 465 minecraft:pink_terracotta
setblock 348 108 465 minecraft:red_nether_bricks
setblock 349 108 464 minecraft:red_nether_bricks
fill 349 108 465 352 108 465 minecraft:pink_terracotta
setblock 349 108 504 minecraft:red_nether_bricks
fill 350 108 464 353 108 464 minecraft:pink_terracotta
fill 350 108 504 353 108 504 minecraft:pink_terracotta
setblock 353 108 465 minecraft:red_nether_bricks
setblock 354 108 464 minecraft:red_nether_bricks
fill 354 108 465 354 111 465 minecraft:pink_terracotta
setblock 354 108 503 minecraft:pink_terracotta
setblock 354 108 504 minecraft:red_nether_bricks
fill 355 108 464 355 111 464 minecraft:pink_terracotta
setblock 355 108 503 minecraft:red_nether_bricks
fill 355 108 504 355 111 504 minecraft:pink_terracotta
setblock 356 108 466 minecraft:pink_terracotta
fill 356 108 503 356 111 503 minecraft:pink_terracotta
setblock 357 108 466 minecraft:red_nether_bricks
setblock 357 108 502 minecraft:pink_terracotta
setblock 358 108 465 minecraft:red_nether_bricks
fill 358 108 466 358 111 466 minecraft:pink_terracotta
setblock 359 108 464 minecraft:red_nether_bricks
fill 359 108 465 359 111 465 minecraft:pink_terracotta
setblock 359 108 504 minecraft:red_nether_bricks
fill 360 108 464 360 111 464 minecraft:pink_terracotta
setblock 360 108 503 minecraft:red_nether_bricks
fill 360 108 504 360 111 504 minecraft:pink_terracotta
setblock 361 108 501 minecraft:pink_terracotta
setblock 361 108 502 minecraft:red_nether_bricks
fill 361 108 503 361 111 503 minecraft:pink_terracotta
setblock 362 108 466 minecraft:red_nether_bricks
setblock 362 108 501 minecraft:red_nether_bricks
fill 362 108 502 362 111 502 minecraft:pink_terracotta
setblock 363 108 465 minecraft:red_nether_bricks
fill 363 108 466 363 111 466 minecraft:pink_terracotta
setblock 363 108 501 minecraft:pink_terracotta
setblock 364 108 464 minecraft:red_nether_bricks
fill 364 108 465 364 111 465 minecraft:pink_terracotta
setblock 364 108 504 minecraft:red_nether_bricks
fill 365 108 464 365 111 464 minecraft:pink_terracotta
fill 365 108 466 365 109 466 minecraft:pink_terracotta
setblock 365 108 503 minecraft:red_nether_bricks
fill 365 108 504 365 111 504 minecraft:pink_terracotta
setblock 366 108 502 minecraft:red_nether_bricks
fill 366 108 503 366 111 503 minecraft:pink_terracotta
fill 367 108 502 367 109 502 minecraft:pink_terracotta
setblock 368 108 465 minecraft:red_nether_bricks
setblock 368 108 501 minecraft:pink_terracotta
setblock 369 108 464 minecraft:red_nether_bricks
setblock 369 108 499 minecraft:red_nether_bricks
fill 369 108 500 369 109 500 minecraft:pink_terracotta
setblock 369 108 504 minecraft:red_nether_bricks
fill 370 108 464 370 111 464 minecraft:pink_terracotta
setblock 370 108 483 minecraft:red_nether_bricks
fill 370 108 484 370 111 484 minecraft:pink_terracotta
setblock 370 108 488 minecraft:red_nether_bricks
fill 370 108 489 370 110 490 minecraft:pink_terracotta
setblock 370 108 498 minecraft:red_nether_bricks
fill 370 108 499 370 110 499 minecraft:pink_terracotta
setblock 370 108 503 minecraft:red_nether_bricks
fill 370 108 504 370 111 504 minecraft:pink_terracotta
setblock 330 109 473 minecraft:white_concrete
setblock 330 109 482 minecraft:red_nether_bricks
fill 330 109 483 330 112 483 minecraft:pink_terracotta
setblock 330 109 487 minecraft:red_nether_bricks
fill 330 109 488 330 112 488 minecraft:pink_terracotta
setblock 330 109 492 minecraft:red_nether_bricks
setblock 330 109 502 minecraft:red_nether_bricks
fill 330 109 503 330 110 503 minecraft:pink_terracotta
fill 331 109 482 331 110 482 minecraft:pink_terracotta
setblock 331 109 486 minecraft:red_nether_bricks
fill 331 109 487 331 112 487 minecraft:pink_terracotta
fill 331 109 489 331 110 489 minecraft:pink_terracotta
setblock 333 109 504 minecraft:red_nether_bricks
fill 334 109 464 337 109 464 minecraft:pink_terracotta
fill 334 109 504 334 110 504 minecraft:pink_terracotta
setblock 337 109 465 minecraft:red_nether_bricks
fill 337 109 503 338 109 503 minecraft:pink_terracotta
setblock 338 109 464 minecraft:red_nether_bricks
fill 338 109 465 341 109 465 minecraft:pink_terracotta
setblock 338 109 504 minecraft:red_nether_bricks
fill 339 109 464 339 112 464 minecraft:pink_terracotta
setblock 339 109 503 minecraft:red_nether_bricks
fill 339 109 504 339 112 504 minecraft:pink_terracotta
setblock 340 109 466 minecraft:pink_terracotta
fill 340 109 503 340 110 503 minecraft:pink_terracotta
setblock 341 109 466 minecraft:red_nether_bricks
setblock 342 109 465 minecraft:red_nether_bricks
fill 342 109 466 342 112 466 minecraft:pink_terracotta
setblock 343 109 464 minecraft:red_nether_bricks
fill 343 109 465 343 112 465 minecraft:pink_terracotta
setblock 343 109 504 minecraft:red_nether_bricks
fill 344 109 464 347 109 464 minecraft:pink_terracotta
setblock 344 109 503 minecraft:red_nether_bricks
fill 344 109 504 344 112 504 minecraft:pink_terracotta
setblock 345 109 503 minecraft:pink_terracotta
setblock 347 109 465 minecraft:red_nether_bricks
setblock 348 109 464 minecraft:red_nether_bricks
fill 348 109 465 351 109 465 minecraft:pink_terracotta
setblock 348 109 504 minecraft:red_nether_bricks
fill 349 109 464 352 109 464 minecraft:pink_terracotta
fill 349 109 504 352 109 504 minecraft:pink_terracotta
setblock 352 109 465 minecraft:red_nether_bricks
setblock 353 109 464 minecraft:red_nether_bricks
fill 353 109 465 353 112 465 minecraft:pink_terracotta
setblock 353 109 504 minecraft:red_nether_bricks
fill 354 109 464 354 112 464 minecraft:pink_terracotta
fill 354 109 495 354 110 495 minecraft:pink_concrete
setblock 354 109 503 minecraft:red_nether_bricks
fill 354 109 504 354 112 504 minecraft:pink_terracotta
setblock 355 109 466 minecraft:pink_terracotta
fill 355 109 503 355 112 503 minecraft:pink_terracotta
setblock 356 109 466 minecraft:red_nether_bricks
setblock 357 109 465 minecraft:red_nether_bricks
fill 357 109 466 357 112 466 minecraft:pink_terracotta
setblock 358 109 464 minecraft:red_nether_bricks
fill 358 109 465 358 112 465 minecraft:pink_terracotta
setblock 358 109 504 minecraft:red_nether_bricks
fill 359 109 464 359 112 464 minecraft:pink_terracotta
setblock 359 109 503 minecraft:red_nether_bricks
fill 359 109 504 359 112 504 minecraft:pink_terracotta
setblock 360 109 502 minecraft:red_nether_bricks
fill 360 109 503 360 112 503 minecraft:pink_terracotta
setblock 361 109 466 minecraft:red_nether_bricks
fill 361 109 502 361 112 502 minecraft:pink_terracotta
setblock 362 109 465 minecraft:red_nether_bricks
fill 362 109 466 362 112 466 minecraft:pink_terracotta
setblock 363 109 464 minecraft:red_nether_bricks
fill 363 109 465 363 112 465 minecraft:pink_terracotta
fill 363 109 501 363 112 501 minecraft:iron_block
setblock 363 109 504 minecraft:red_nether_bricks
fill 364 109 464 364 112 464 minecraft:pink_terracotta
setblock 364 109 503 minecraft:red_nether_bricks
fill 364 109 504 364 112 504 minecraft:pink_terracotta
setblock 365 109 502 minecraft:red_nether_bricks
fill 365 109 503 365 112 503 minecraft:pink_terracotta
fill 366 109 502 366 110 502 minecraft:pink_terracotta
setblock 367 109 465 minecraft:red_nether_bricks
setblock 368 109 464 minecraft:red_nether_bricks
setblock 368 109 465 minecraft:pink_terracotta
setblock 368 109 504 minecraft:red_nether_bricks
fill 369 109 464 369 111 464 minecraft:pink_terracotta
setblock 369 109 503 minecraft:red_nether_bricks
fill 369 109 504 369 112 504 minecraft:pink_terracotta
setblock 370 109 476 minecraft:white_concrete
setblock 370 109 482 minecraft:red_nether_bricks
fill 370 109 483 370 110 483 minecraft:pink_terracotta
setblock 370 109 487 minecraft:red_nether_bricks
fill 370 109 488 370 112 488 minecraft:pink_terracotta
setblock 370 109 495 minecraft:white_concrete
setblock 370 109 497 minecraft:red_nether_bricks
setblock 370 109 498 minecraft:pink_terracotta
setblock 370 109 502 minecraft:red_nether_bricks
fill 370 109 503 370 112 503 minecraft:pink_terracotta
setblock 330 110 479 minecraft:white_concrete
setblock 330 110 481 minecraft:red_nether_bricks
fill 330 110 482 330 113 482 minecraft:pink_terracotta
setblock 330 110 486 minecraft:red_nether_bricks
fill 330 110 487 330 113 487 minecraft:pink_terracotta
setblock 330 110 491 minecraft:red_nether_bricks
setblock 330 110 492 minecraft:pink_terracotta
setblock 330 110 498 minecraft:white_concrete
setblock 331 110 485 minecraft:red_nether_bricks
fill 331 110 486 331 113 486 minecraft:pink_terracotta
setblock 332 110 464 minecraft:white_concrete
setblock 332 110 504 minecraft:red_nether_bricks
setblock 333 110 504 minecraft:pink_terracotta
fill 334 110 464 336 110 464 minecraft:pink_terracotta
setblock 337 110 464 minecraft:red_nether_bricks
fill 337 110 465 340 110 465 minecraft:pink_terracotta
setblock 337 110 504 minecraft:red_nether_bricks
fill 338 110 464 338 113 464 minecraft:pink_terracotta
setblock 338 110 503 minecraft:red_nether_bricks
fill 338 110 504 338 113 504 minecraft:pink_terracotta
setblock 339 110 503 minecraft:pink_terracotta
setblock 340 110 466 minecraft:red_nether_bricks
setblock 341 110 465 minecraft:red_nether_bricks
fill 341 110 466 341 113 466 minecraft:pink_terracotta
setblock 342 110 464 minecraft:red_nether_bricks
fill 342 110 465 342 113 465 minecraft:pink_terracotta
setblock 342 110 504 minecraft:red_nether_bricks
fill 343 110 464 346 110 464 minecraft:pink_terracotta
fill 343 110 487 344 157 489 minecraft:red_nether_bricks
fill 343 110 504 343 112 504 minecraft:pink_terracotta
setblock 344 110 466 minecraft:pink_terracotta
setblock 345 110 466 minecraft:red_nether_bricks
fill 345 110 488 345 157 488 minecraft:red_nether_bricks
setblock 346 110 465 minecraft:red_nether_bricks
setblock 347 110 464 minecraft:red_nether_bricks
fill 347 110 465 350 110 465 minecraft:pink_terracotta
setblock 347 110 504 minecraft:red_nether_bricks
fill 348 110 464 351 110 464 minecraft:pink_terracotta
fill 348 110 504 351 110 504 minecraft:pink_terracotta
setblock 351 110 465 minecraft:red_nether_bricks
setblock 352 110 464 minecraft:red_nether_bricks
fill 352 110 465 352 113 465 minecraft:pink_terracotta
setblock 352 110 504 minecraft:red_nether_bricks
fill 353 110 464 353 113 464 minecraft:pink_terracotta
fill 353 110 504 353 113 504 minecraft:pink_terracotta
setblock 355 110 466 minecraft:red_nether_bricks
setblock 356 110 465 minecraft:red_nether_bricks
fill 356 110 466 356 113 466 minecraft:pink_terracotta
setblock 357 110 464 minecraft:red_nether_bricks
fill 357 110 465 357 113 465 minecraft:pink_terracotta
setblock 357 110 504 minecraft:red_nether_bricks
fill 358 110 464 358 113 464 minecraft:pink_terracotta
setblock 358 110 503 minecraft:red_nether_bricks
fill 358 110 504 358 113 504 minecraft:pink_terracotta
setblock 359 110 502 minecraft:red_nether_bricks
fill 359 110 503 359 113 503 minecraft:pink_terracotta
setblock 360 110 466 minecraft:red_nether_bricks
fill 360 110 502 360 112 502 minecraft:pink_terracotta
setblock 361 110 465 minecraft:red_nether_bricks
fill 361 110 466 361 113 466 minecraft:pink_terracotta
setblock 362 110 464 minecraft:red_nether_bricks
fill 362 110 465 362 113 465 minecraft:pink_terracotta
setblock 362 110 504 minecraft:red_nether_bricks
fill 363 110 464 363 113 464 minecraft:pink_terracotta
setblock 363 110 503 minecraft:red_nether_bricks
fill 363 110 504 363 113 504 minecraft:pink_terracotta
setblock 364 110 502 minecraft:red_nether_bricks
fill 364 110 503 364 113 503 minecraft:pink_terracotta
setblock 365 110 502 minecraft:pink_terracotta
setblock 366 110 465 minecraft:red_nether_bricks
setblock 367 110 464 minecraft:red_nether_bricks
setblock 367 110 465 minecraft:pink_terracotta
setblock 367 110 504 minecraft:red_nether_bricks
fill 368 110 464 368 112 464 minecraft:pink_terracotta
setblock 368 110 503 minecraft:red_nether_bricks
fill 368 110 504 368 113 504 minecraft:pink_terracotta
setblock 369 110 502 minecraft:red_nether_bricks
setblock 369 110 503 minecraft:pink_terracotta
setblock 370 110 470 minecraft:white_concrete
setblock 370 110 486 minecraft:red_nether_bricks
fill 370 110 487 370 113 487 minecraft:pink_terracotta
setblock 370 110 501 minecraft:red_nether_bricks
fill 370 110 502 370 111 502 minecraft:pink_terracotta
setblock 330 111 481 minecraft:pink_terracotta
setblock 330 111 485 minecraft:red_nether_bricks
fill 330 111 486 330 114 486 minecraft:pink_terracotta
setblock 330 111 490 minecraft:red_nether_bricks
fill 330 111 491 330 114 491 minecraft:pink_terracotta
setblock 330 111 504 minecraft:white_concrete
setblock 331 111 484 minecraft:red_nether_bricks
fill 331 111 485 331 114 485 minecraft:pink_terracotta
setblock 331 111 489 minecraft:red_nether_bricks
setblock 332 111 466 minecraft:light[level=12]
setblock 332 111 474 minecraft:light[level=12]
setblock 332 111 482 minecraft:light[level=12]
setblock 332 111 490 minecraft:light[level=12]
setblock 332 111 498 minecraft:light[level=12]
fill 334 111 464 335 111 464 minecraft:pink_terracotta
setblock 336 111 464 minecraft:red_nether_bricks
fill 336 111 465 339 111 465 minecraft:pink_terracotta
setblock 336 111 504 minecraft:red_nether_bricks
fill 337 111 464 337 114 464 minecraft:pink_terracotta
fill 337 111 504 337 114 504 minecraft:pink_terracotta
setblock 339 111 466 minecraft:red_nether_bricks
setblock 340 111 465 minecraft:red_nether_bricks
fill 340 111 466 340 114 466 minecraft:pink_terracotta
setblock 340 111 474 minecraft:light[level=12]
setblock 340 111 482 minecraft:light[level=12]
setblock 340 111 490 minecraft:light[level=12]
setblock 340 111 498 minecraft:light[level=12]
setblock 341 111 464 minecraft:red_nether_bricks
fill 341 111 465 341 114 465 minecraft:pink_terracotta
setblock 341 111 504 minecraft:red_nether_bricks
fill 342 111 464 345 111 464 minecraft:pink_terracotta
fill 342 111 488 342 112 488 minecraft:red_terracotta
fill 342 111 504 342 113 504 minecraft:pink_terracotta
setblock 344 111 466 minecraft:red_nether_bricks
setblock 345 111 465 minecraft:red_nether_bricks
fill 345 111 487 345 112 487 minecraft:red_terracotta
fill 345 111 489 345 112 489 minecraft:red_terracotta
setblock 346 111 464 minecraft:red_nether_bricks
fill 346 111 465 349 111 465 minecraft:pink_terracotta
setblock 346 111 504 minecraft:red_nether_bricks
fill 347 111 464 350 111 464 minecraft:pink_terracotta
setblock 348 111 466 minecraft:light[level=12]
setblock 348 111 474 minecraft:light[level=12]
setblock 348 111 482 minecraft:light[level=12]
setblock 348 111 490 minecraft:light[level=12]
setblock 348 111 498 minecraft:light[level=12]
setblock 350 111 465 minecraft:red_nether_bricks
setblock 351 111 464 minecraft:red_nether_bricks
fill 351 111 465 351 114 465 minecraft:pink_terracotta
setblock 351 111 504 minecraft:red_nether_bricks
fill 352 111 464 352 114 464 minecraft:pink_terracotta
fill 352 111 504 352 112 504 minecraft:pink_terracotta
setblock 354 111 466 minecraft:red_nether_bricks
setblock 355 111 465 minecraft:red_nether_bricks
fill 355 111 466 355 114 466 minecraft:pink_terracotta
setblock 356 111 464 minecraft:red_nether_bricks
fill 356 111 465 356 114 465 minecraft:pink_terracotta
setblock 356 111 474 minecraft:light[level=12]
setblock 356 111 482 minecraft:light[level=12]
setblock 356 111 490 minecraft:light[level=12]
setblock 356 111 498 minecraft:light[level=12]
setblock 356 111 504 minecraft:red_nether_bricks
fill 357 111 464 357 114 464 minecraft:pink_terracotta
setblock 357 111 503 minecraft:red_nether_bricks
fill 357 111 504 357 114 504 minecraft:pink_terracotta
setblock 358 111 502 minecraft:red_nether_bricks
fill 358 111 503 358 114 503 minecraft:pink_terracotta
setblock 359 111 466 minecraft:red_nether_bricks
setblock 359 111 502 minecraft:pink_terracotta
setblock 360 111 465 minecraft:red_nether_bricks
fill 360 111 466 360 114 466 minecraft:pink_terracotta
setblock 361 111 464 minecraft:red_nether_bricks
fill 361 111 465 361 114 465 minecraft:pink_terracotta
setblock 361 111 504 minecraft:red_nether_bricks
fill 362 111 464 362 114 464 minecraft:pink_terracotta
setblock 362 111 503 minecraft:red_nether_bricks
fill 362 111 504 362 114 504 minecraft:pink_terracotta
setblock 363 111 502 minecraft:red_nether_bricks
fill 363 111 503 363 114 503 minecraft:pink_terracotta
setblock 364 111 466 minecraft:light[level=12]
setblock 364 111 474 minecraft:light[level=12]
setblock 364 111 482 minecraft:light[level=12]
setblock 364 111 490 minecraft:light[level=12]
setblock 364 111 498 minecraft:light[level=12]
setblock 364 111 502 minecraft:pink_terracotta
setblock 365 111 465 minecraft:red_nether_bricks
setblock 366 111 464 minecraft:red_nether_bricks
setblock 366 111 465 minecraft:pink_terracotta
setblock 366 111 504 minecraft:red_nether_bricks
fill 367 111 464 367 113 464 minecraft:pink_terracotta
setblock 367 111 503 minecraft:red_nether_bricks
fill 367 111 504 367 113 504 minecraft:pink_terracotta
setblock 368 111 503 minecraft:pink_terracotta
setblock 370 111 483 minecraft:white_concrete
setblock 370 111 485 minecraft:red_nether_bricks
fill 370 111 486 370 114 486 minecraft:pink_terracotta
setblock 370 111 489 minecraft:pink_terracotta
setblock 370 111 490 minecraft:red_nether_bricks
fill 370 111 491 370 114 491 minecraft:pink_terracotta
setblock 370 111 501 minecraft:pink_terracotta
setblock 330 112 466 minecraft:white_concrete
setblock 330 112 484 minecraft:red_nether_bricks
fill 330 112 485 330 115 485 minecraft:pink_terracotta
setblock 330 112 489 minecraft:red_nether_bricks
fill 330 112 490 330 115 490 minecraft:pink_terracotta
fill 330 112 492 330 113 492 minecraft:pink_terracotta
fill 331 112 484 331 113 484 minecraft:pink_terracotta
setblock 331 112 488 minecraft:red_nether_bricks
fill 331 112 489 331 115 489 minecraft:pink_terracotta
setblock 334 112 464 minecraft:pink_terracotta
setblock 335 112 464 minecraft:red_nether_bricks
fill 336 112 464 336 114 465 minecraft:pink_terracotta
fill 336 112 504 336 113 504 minecraft:pink_terracotta
fill 337 112 465 338 112 465 minecraft:pink_terracotta
setblock 339 112 465 minecraft:red_nether_bricks
fill 339 112 466 339 115 466 minecraft:pink_terracotta
setblock 340 112 464 minecraft:red_nether_bricks
fill 340 112 465 340 115 465 minecraft:pink_terracotta
setblock 340 112 504 minecraft:red_nether_bricks
fill 341 112 464 344 112 464 minecraft:pink_terracotta
fill 341 112 504 341 113 504 minecraft:pink_terracotta
setblock 342 112 487 minecraft:red_terracotta
setblock 342 112 489 minecraft:red_terracotta
setblock 343 112 466 minecraft:red_nether_bricks
fill 343 112 486 345 112 486 minecraft:red_terracotta
fill 343 112 490 345 112 490 minecraft:red_terracotta
setblock 344 112 465 minecraft:red_nether_bricks
setblock 345 112 464 minecraft:red_nether_bricks
fill 345 112 465 348 112 465 minecraft:pink_terracotta
fill 346 112 464 349 112 464 minecraft:pink_terracotta
setblock 346 112 488 minecraft:red_terracotta
setblock 349 112 465 minecraft:red_nether_bricks
setblock 350 112 464 minecraft:red_nether_bricks
fill 350 112 465 350 115 465 minecraft:pink_terracotta
fill 351 112 464 351 115 464 minecraft:pink_terracotta
setblock 354 112 465 minecraft:red_nether_bricks
fill 354 112 466 354 115 466 minecraft:pink_terracotta
setblock 355 112 464 minecraft:red_nether_bricks
fill 355 112 465 355 115 465 minecraft:pink_terracotta
setblock 355 112 504 minecraft:red_nether_bricks
fill 356 112 464 356 115 464 minecraft:pink_terracotta
setblock 356 112 503 minecraft:red_nether_bricks
fill 356 112 504 356 115 504 minecraft:pink_terracotta
fill 357 112 503 357 115 503 minecraft:pink_terracotta
setblock 358 112 466 minecraft:red_nether_bricks
setblock 359 112 465 minecraft:red_nether_bricks
fill 359 112 466 359 115 466 minecraft:pink_terracotta
setblock 360 112 464 minecraft:red_nether_bricks
fill 360 112 465 360 115 465 minecraft:pink_terracotta
setblock 360 112 504 minecraft:red_nether_bricks
fill 361 112 464 361 115 464 minecraft:pink_terracotta
setblock 361 112 503 minecraft:red_nether_bricks
fill 361 112 504 361 115 504 minecraft:pink_terracotta
fill 362 112 503 362 115 503 minecraft:pink_terracotta
setblock 363 112 466 minecraft:red_nether_bricks
setblock 364 112 465 minecraft:red_nether_bricks
setblock 365 112 464 minecraft:red_nether_bricks
setblock 365 112 465 minecraft:pink_terracotta
setblock 365 112 504 minecraft:red_nether_bricks
fill 366 112 464 366 114 464 minecraft:pink_terracotta
setblock 366 112 503 minecraft:red_nether_bricks
fill 366 112 504 366 114 504 minecraft:pink_terracotta
setblock 370 112 477 minecraft:white_concrete
fill 370 112 485 370 115 485 minecraft:pink_terracotta
setblock 370 112 489 minecraft:red_nether_bricks
fill 370 112 490 370 115 490 minecraft:pink_terracotta
setblock 370 112 502 minecraft:white_concrete
setblock 370 112 504 minecraft:red_nether_bricks
setblock 330 113 472 minecraft:white_concrete
setblock 330 113 483 minecraft:red_nether_bricks
fill 330 113 484 330 116 484 minecraft:pink_terracotta
setblock 330 113 488 minecraft:red_nether_bricks
fill 330 113 489 330 116 489 minecraft:pink_terracotta
setblock 330 113 497 minecraft:white_concrete
setblock 331 113 487 minecraft:red_nether_bricks
fill 331 113 488 331 116 488 minecraft:pink_terracotta
setblock 333 113 464 minecraft:white_concrete
setblock 334 113 464 minecraft:red_nether_bricks
fill 335 113 464 335 116 464 minecraft:pink_terracotta
setblock 337 113 465 minecraft:pink_terracotta
setblock 338 113 465 minecraft:red_nether_bricks
setblock 339 113 464 minecraft:red_nether_bricks
fill 339 113 465 339 116 465 minecraft:pink_terracotta
setblock 339 113 504 minecraft:red_nether_bricks
fill 340 113 464 343 113 464 minecraft:pink_terracotta
fill 340 113 504 340 114 504 minecraft:pink_terracotta
setblock 342 113 466 minecraft:red_nether_bricks
setblock 343 113 465 minecraft:red_nether_bricks
setblock 344 113 464 minecraft:red_nether_bricks
fill 344 113 465 347 113 465 minecraft:pink_terracotta
fill 345 113 464 348 113 464 minecraft:pink_terracotta
setblock 348 113 465 minecraft:red_nether_bricks
setblock 349 113 464 minecraft:red_nether_bricks
fill 349 113 465 349 116 465 minecraft:pink_terracotta
fill 349 113 473 350 114 474 minecraft:pink_concrete
fill 350 113 464 350 116 464 minecraft:pink_terracotta
setblock 353 113 465 minecraft:red_nether_bricks
setblock 354 113 464 minecraft:red_nether_bricks
fill 354 113 465 354 116 465 minecraft:pink_terracotta
setblock 354 113 504 minecraft:red_nether_bricks
fill 355 113 464 355 116 464 minecraft:pink_terracotta
fill 355 113 504 355 116 504 minecraft:pink_terracotta
fill 356 113 503 356 116 503 minecraft:pink_terracotta
setblock 357 113 466 minecraft:red_nether_bricks
setblock 358 113 465 minecraft:red_nether_bricks
fill 358 113 466 358 116 466 minecraft:pink_terracotta
setblock 359 113 464 minecraft:red_nether_bricks
fill 359 113 465 359 116 465 minecraft:pink_terracotta
setblock 359 113 504 minecraft:red_nether_bricks
fill 360 113 464 360 116 464 minecraft:pink_terracotta
setblock 360 113 503 minecraft:red_nether_bricks
fill 360 113 504 360 116 504 minecraft:pink_terracotta
fill 361 113 503 361 116 503 minecraft:pink_terracotta
setblock 362 113 466 minecraft:red_nether_bricks
setblock 363 113 465 minecraft:red_nether_bricks
setblock 364 113 464 minecraft:red_nether_bricks
fill 364 113 465 364 114 465 minecraft:pink_terracotta
setblock 364 113 504 minecraft:red_nether_bricks
fill 365 113 464 365 115 464 minecraft:pink_terracotta
fill 365 113 504 365 115 504 minecraft:pink_terracotta
setblock 370 113 471 minecraft:white_concrete
setblock 370 113 488 minecraft:red_nether_bricks
fill 370 113 489 370 116 489 minecraft:pink_terracotta
setblock 370 113 492 minecraft:pink_terracotta
setblock 370 113 496 minecraft:white_concrete
setblock 330 114 478 minecraft:white_concrete
fill 330 114 483 330 117 483 minecraft:pink_terracotta
setblock 330 114 487 minecraft:red_nether_bricks
fill 330 114 488 330 117 488 minecraft:pink_terracotta
setblock 330 114 492 minecraft:red_nether_bricks
setblock 330 114 503 minecraft:white_concrete
setblock 331 114 486 minecraft:red_nether_bricks
fill 331 114 487 331 117 487 minecraft:pink_terracotta
setblock 331 114 490 minecraft:pink_terracotta
fill 334 114 464 334 117 464 minecraft:pink_terracotta
fill 335 114 465 335 115 465 minecraft:pink_terracotta
setblock 337 114 465 minecraft:red_nether_bricks
setblock 338 114 464 minecraft:red_nether_bricks
fill 338 114 465 338 116 466 minecraft:pink_terracotta
setblock 338 114 504 minecraft:red_nether_bricks
fill 339 114 464 342 114 464 minecraft:pink_terracotta
setblock 339 114 504 minecraft:pink_terracotta
setblock 341 114 466 minecraft:red_nether_bricks
setblock 342 114 465 minecraft:red_nether_bricks
setblock 342 114 466 minecraft:pink_terracotta
setblock 343 114 464 minecraft:red_nether_bricks
fill 343 114 465 346 114 465 minecraft:pink_terracotta
fill 344 114 464 347 114 464 minecraft:pink_terracotta
setblock 348 114 464 minecraft:red_nether_bricks
setblock 348 114 504 minecraft:white_concrete
fill 349 114 464 349 117 464 minecraft:pink_terracotta
setblock 352 114 465 minecraft:red_nether_bricks
setblock 353 114 464 minecraft:red_nether_bricks
fill 353 114 465 353 116 466 minecraft:pink_terracotta
setblock 353 114 504 minecraft:red_nether_bricks
fill 354 114 464 354 117 464 minecraft:pink_terracotta
fill 354 114 504 354 117 504 minecraft:pink_terracotta
setblock 356 114 466 minecraft:red_nether_bricks
setblock 357 114 465 minecraft:red_nether_bricks
fill 357 114 466 357 117 466 minecraft:pink_terracotta
setblock 358 114 464 minecraft:red_nether_bricks
fill 358 114 465 358 117 465 minecraft:pink_terracotta
setblock 358 114 504 minecraft:red_nether_bricks
fill 359 114 464 359 117 464 minecraft:pink_terracotta
setblock 359 114 503 minecraft:red_nether_bricks
fill 359 114 504 359 117 504 minecraft:pink_terracotta
fill 360 114 503 360 117 503 minecraft:pink_terracotta
setblock 361 114 466 minecraft:red_nether_bricks
setblock 362 114 465 minecraft:red_nether_bricks
setblock 363 114 464 minecraft:red_nether_bricks
fill 363 114 465 363 115 465 minecraft:pink_terracotta
setblock 363 114 504 minecraft:red_nether_bricks
fill 364 114 464 364 117 464 minecraft:pink_terracotta
fill 364 114 504 364 117 504 minecraft:pink_terracotta
setblock 370 114 465 minecraft:white_concrete
setblock 370 114 487 minecraft:red_nether_bricks
fill 370 114 488 370 117 488 minecraft:pink_terracotta
setblock 370 114 492 minecraft:red_nether_bricks
fill 370 114 493 370 117 493 minecraft:pink_terracotta
setblock 330 115 465 minecraft:white_concrete
setblock 330 115 486 minecraft:red_nether_bricks
fill 330 115 487 330 118 487 minecraft:pink_terracotta
setblock 330 115 491 minecraft:red_nether_bricks
fill 330 115 492 330 117 493 minecraft:pink_terracotta
setblock 331 115 485 minecraft:red_nether_bricks
fill 331 115 486 331 118 486 minecraft:pink_terracotta
setblock 331 115 490 minecraft:red_nether_bricks
fill 331 115 491 331 118 491 minecraft:pink_terracotta
fill 333 115 464 333 118 464 minecraft:pink_terracotta
setblock 335 115 504 minecraft:white_concrete
setblock 336 115 464 minecraft:pink_terracotta
setblock 336 115 465 minecraft:red_nether_bricks
setblock 337 115 464 minecraft:red_nether_bricks
fill 337 115 465 337 117 466 minecraft:pink_terracotta
fill 338 115 464 341 115 464 minecraft:pink_terracotta
setblock 340 115 466 minecraft:red_nether_bricks
setblock 341 115 465 minecraft:red_nether_bricks
fill 341 115 466 341 118 466 minecraft:pink_terracotta
setblock 342 115 464 minecraft:red_nether_bricks
fill 342 115 465 345 115 465 minecraft:pink_terracotta
fill 343 115 464 346 115 464 minecraft:pink_terracotta
setblock 347 115 464 minecraft:red_nether_bricks
fill 348 115 464 348 118 464 minecraft:pink_terracotta
setblock 351 115 465 minecraft:red_nether_bricks
setblock 352 115 464 minecraft:red_nether_bricks
fill 352 115 465 352 118 465 minecraft:pink_terracotta
setblock 352 115 504 minecraft:red_nether_bricks
fill 353 115 464 353 118 464 minecraft:pink_terracotta
fill 353 115 504 353 118 504 minecraft:pink_terracotta
setblock 355 115 466 minecraft:red_nether_bricks
setblock 356 115 465 minecraft:red_nether_bricks
fill 356 115 466 356 118 466 minecraft:pink_terracotta
setblock 357 115 464 minecraft:red_nether_bricks
fill 357 115 465 357 118 465 minecraft:pink_terracotta
setblock 357 115 504 minecraft:red_nether_bricks
schedule function dropper:buildpart/115_4 1t
