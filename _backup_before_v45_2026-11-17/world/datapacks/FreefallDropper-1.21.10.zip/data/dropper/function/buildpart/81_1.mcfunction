setblock 465 87 325 minecraft:gray_concrete
fill 465 87 326 465 87 329 minecraft:light_gray_concrete
setblock 465 87 330 minecraft:gray_concrete
fill 465 87 331 465 192 331 minecraft:light_gray_concrete
setblock 465 87 332 minecraft:gray_concrete
fill 465 87 333 465 93 334 minecraft:light_gray_concrete
setblock 465 87 335 minecraft:gray_concrete
fill 465 87 336 465 93 341 minecraft:light_gray_concrete
setblock 465 87 342 minecraft:gray_concrete
fill 465 87 343 465 93 346 minecraft:light_gray_concrete
setblock 465 87 347 minecraft:gray_concrete
fill 465 87 349 465 192 351 minecraft:light_gray_concrete
fill 465 87 352 465 88 352 minecraft:gray_concrete
fill 465 87 353 465 93 363 minecraft:light_gray_concrete
fill 423 88 322 423 93 328 minecraft:light_gray_concrete
setblock 423 88 329 minecraft:gray_concrete
fill 423 88 330 423 93 332 minecraft:light_gray_concrete
fill 423 88 335 423 192 336 minecraft:light_gray_concrete
setblock 423 88 337 minecraft:gray_concrete
fill 423 88 338 423 93 345 minecraft:light_gray_concrete
fill 423 88 346 423 88 347 minecraft:gray_concrete
fill 423 88 348 423 93 357 minecraft:light_gray_concrete
fill 423 88 358 423 88 359 minecraft:gray_concrete
fill 423 88 360 423 93 364 minecraft:light_gray_concrete
fill 424 88 322 427 93 322 minecraft:light_gray_concrete
fill 427 88 364 437 93 364 minecraft:light_gray_concrete
setblock 428 88 322 minecraft:gray_concrete
fill 429 88 322 434 93 322 minecraft:light_gray_concrete
setblock 435 88 322 minecraft:gray_concrete
fill 435 88 360 435 89 362 minecraft:iron_block
fill 436 88 322 436 93 322 minecraft:light_gray_concrete
fill 438 88 322 439 93 322 minecraft:light_gray_concrete
setblock 438 88 364 minecraft:gray_concrete
fill 439 88 364 439 93 364 minecraft:light_gray_concrete
fill 441 88 322 441 196 322 minecraft:light_gray_concrete
fill 441 88 364 441 196 364 minecraft:light_gray_concrete
setblock 446 88 322 minecraft:gray_concrete
fill 447 88 322 447 93 322 minecraft:light_gray_concrete
fill 448 88 322 449 88 322 minecraft:gray_concrete
fill 450 88 322 452 196 322 minecraft:light_gray_concrete
fill 454 88 364 454 196 364 minecraft:light_gray_concrete
fill 460 88 322 460 196 322 minecraft:light_gray_concrete
fill 461 88 322 462 88 322 minecraft:gray_concrete
fill 463 88 322 465 192 322 minecraft:light_gray_concrete
fill 465 88 325 465 93 328 minecraft:light_gray_concrete
setblock 465 88 329 minecraft:gray_concrete
fill 465 88 330 465 192 330 minecraft:light_gray_concrete
fill 465 88 332 465 196 332 minecraft:light_gray_concrete
fill 465 88 335 465 93 335 minecraft:light_gray_concrete
fill 465 88 342 465 194 342 minecraft:light_gray_concrete
fill 465 88 347 465 196 348 minecraft:light_gray_concrete
fill 423 89 329 423 93 329 minecraft:light_gray_concrete
fill 423 89 337 423 197 337 minecraft:light_gray_concrete
fill 423 89 346 423 193 347 minecraft:light_gray_concrete
fill 423 89 358 423 93 359 minecraft:light_gray_concrete
setblock 426 89 325 minecraft:light[level=14]
setblock 426 89 333 minecraft:light[level=14]
setblock 426 89 341 minecraft:light[level=14]
setblock 426 89 349 minecraft:light[level=14]
setblock 426 89 357 minecraft:light[level=14]
fill 428 89 322 428 93 322 minecraft:light_gray_concrete
setblock 434 89 325 minecraft:light[level=14]
setblock 434 89 333 minecraft:light[level=14]
setblock 434 89 341 minecraft:light[level=14]
setblock 434 89 349 minecraft:light[level=14]
setblock 434 89 357 minecraft:light[level=14]
fill 435 89 322 435 197 322 minecraft:light_gray_concrete
setblock 435 89 358 minecraft:verdant_froglight
fill 438 89 364 438 93 364 minecraft:light_gray_concrete
setblock 442 89 325 minecraft:light[level=14]
setblock 442 89 333 minecraft:light[level=14]
setblock 442 89 341 minecraft:light[level=14]
setblock 442 89 349 minecraft:light[level=14]
setblock 442 89 357 minecraft:light[level=14]
fill 446 89 322 446 93 322 minecraft:light_gray_concrete
fill 448 89 322 449 93 322 minecraft:light_gray_concrete
setblock 450 89 325 minecraft:light[level=14]
setblock 450 89 333 minecraft:light[level=14]
setblock 450 89 341 minecraft:light[level=14]
setblock 450 89 349 minecraft:light[level=14]
setblock 450 89 357 minecraft:light[level=14]
fill 453 89 343 453 90 344 minecraft:lime_stained_glass
fill 454 89 322 454 196 322 minecraft:light_gray_concrete
setblock 458 89 325 minecraft:light[level=14]
setblock 458 89 333 minecraft:light[level=14]
setblock 458 89 341 minecraft:light[level=14]
setblock 458 89 349 minecraft:light[level=14]
setblock 458 89 357 minecraft:light[level=14]
fill 460 89 328 460 89 330 minecraft:light_gray_concrete
fill 461 89 322 462 193 322 minecraft:light_gray_concrete
fill 461 89 328 462 89 328 minecraft:light_gray_concrete
fill 461 89 330 462 89 330 minecraft:light_gray_concrete
setblock 462 89 329 minecraft:light_gray_concrete
fill 465 89 329 465 196 329 minecraft:light_gray_concrete
fill 465 89 352 465 197 352 minecraft:light_gray_concrete
setblock 424 90 325 minecraft:light_gray_concrete
fill 424 90 327 424 90 330 minecraft:light_gray_concrete
setblock 424 90 335 minecraft:light_gray_concrete
fill 424 90 337 424 90 340 minecraft:light_gray_concrete
setblock 424 90 345 minecraft:light_gray_concrete
fill 424 90 347 424 90 350 minecraft:light_gray_concrete
setblock 424 90 355 minecraft:light_gray_concrete
fill 424 90 357 424 90 360 minecraft:light_gray_concrete
fill 425 90 323 428 90 323 minecraft:light_gray_concrete
fill 425 90 329 429 90 331 minecraft:iron_block
fill 426 90 328 428 90 328 minecraft:iron_block
fill 426 90 332 428 90 332 minecraft:iron_block
setblock 426 90 363 minecraft:light_gray_concrete
fill 428 90 363 431 90 363 minecraft:light_gray_concrete
fill 429 90 325 433 90 327 minecraft:iron_block
setblock 430 90 323 minecraft:light_gray_concrete
fill 430 90 324 432 90 324 minecraft:iron_block
fill 430 90 328 432 90 328 minecraft:iron_block
fill 435 90 323 438 90 323 minecraft:light_gray_concrete
setblock 436 90 363 minecraft:light_gray_concrete
fill 438 90 363 441 90 363 minecraft:light_gray_concrete
setblock 440 90 323 minecraft:light_gray_concrete
fill 445 90 323 448 90 323 minecraft:light_gray_concrete
setblock 446 90 363 minecraft:light_gray_concrete
fill 448 90 363 451 90 363 minecraft:light_gray_concrete
setblock 450 90 323 minecraft:light_gray_concrete
fill 455 90 323 458 90 323 minecraft:light_gray_concrete
setblock 456 90 363 minecraft:light_gray_concrete
fill 458 90 363 461 90 363 minecraft:light_gray_concrete
setblock 460 90 323 minecraft:light_gray_concrete
fill 464 90 324 464 90 327 minecraft:light_gray_concrete
setblock 464 90 329 minecraft:light_gray_concrete
fill 464 90 334 464 90 337 minecraft:light_gray_concrete
setblock 464 90 339 minecraft:light_gray_concrete
fill 464 90 344 464 90 347 minecraft:light_gray_concrete
setblock 464 90 349 minecraft:light_gray_concrete
fill 464 90 354 464 90 357 minecraft:light_gray_concrete
setblock 464 90 359 minecraft:light_gray_concrete
fill 425 91 329 429 98 331 minecraft:glass
fill 426 91 328 428 98 328 minecraft:glass
fill 426 91 332 428 98 332 minecraft:glass
fill 429 91 325 433 98 327 minecraft:glass
fill 430 91 324 432 98 324 minecraft:glass
fill 430 91 328 432 98 328 minecraft:glass
fill 430 93 349 431 94 349 minecraft:lime_concrete
fill 434 93 358 434 93 360 minecraft:light_gray_concrete
fill 435 93 358 436 93 358 minecraft:light_gray_concrete
fill 435 93 360 436 93 360 minecraft:light_gray_concrete
setblock 436 93 359 minecraft:light_gray_concrete
fill 423 94 322 423 196 327 minecraft:light_gray_concrete
fill 423 94 328 423 94 331 minecraft:verdant_froglight
fill 423 94 332 423 196 332 minecraft:light_gray_concrete
fill 423 94 338 423 94 341 minecraft:verdant_froglight
fill 423 94 342 423 194 345 minecraft:light_gray_concrete
fill 423 94 348 423 94 351 minecraft:verdant_froglight
fill 423 94 352 423 193 357 minecraft:light_gray_concrete
fill 423 94 358 423 94 361 minecraft:verdant_froglight
fill 423 94 362 423 193 364 minecraft:light_gray_concrete
fill 424 94 322 425 193 322 minecraft:light_gray_concrete
fill 426 94 322 429 94 322 minecraft:verdant_froglight
fill 427 94 364 430 94 364 minecraft:verdant_froglight
fill 430 94 322 434 192 322 minecraft:light_gray_concrete
fill 431 94 364 436 192 364 minecraft:light_gray_concrete
fill 436 94 322 439 94 322 minecraft:verdant_froglight
fill 437 94 364 440 94 364 minecraft:verdant_froglight
fill 442 94 364 446 193 364 minecraft:light_gray_concrete
fill 446 94 322 449 94 322 minecraft:verdant_froglight
fill 447 94 364 450 94 364 minecraft:verdant_froglight
fill 451 94 364 453 194 364 minecraft:light_gray_concrete
fill 455 94 322 455 197 322 minecraft:light_gray_concrete
fill 455 94 364 456 193 364 minecraft:light_gray_concrete
fill 456 94 322 459 94 322 minecraft:verdant_froglight
fill 457 94 364 460 94 364 minecraft:verdant_froglight
fill 461 94 364 462 196 364 minecraft:light_gray_concrete
fill 465 94 323 465 94 326 minecraft:verdant_froglight
fill 465 94 327 465 193 328 minecraft:light_gray_concrete
fill 465 94 333 465 94 336 minecraft:verdant_froglight
fill 465 94 337 465 192 341 minecraft:light_gray_concrete
fill 465 94 343 465 94 346 minecraft:verdant_froglight
fill 465 94 353 465 94 356 minecraft:verdant_froglight
fill 465 94 357 465 192 362 minecraft:light_gray_concrete
setblock 465 94 363 minecraft:verdant_froglight
fill 423 95 328 423 102 331 minecraft:light_gray_concrete
fill 423 95 338 423 102 341 minecraft:light_gray_concrete
fill 423 95 348 423 102 351 minecraft:light_gray_concrete
fill 423 95 358 423 102 361 minecraft:light_gray_concrete
fill 426 95 322 429 102 322 minecraft:light_gray_concrete
fill 427 95 364 430 102 364 minecraft:light_gray_concrete
fill 436 95 322 439 102 322 minecraft:light_gray_concrete
fill 437 95 364 440 102 364 minecraft:light_gray_concrete
fill 446 95 322 449 102 322 minecraft:light_gray_concrete
fill 447 95 364 450 102 364 minecraft:light_gray_concrete
fill 456 95 322 459 102 322 minecraft:light_gray_concrete
fill 457 95 364 460 102 364 minecraft:light_gray_concrete
fill 465 95 323 465 102 326 minecraft:light_gray_concrete
fill 465 95 333 465 102 336 minecraft:light_gray_concrete
fill 465 95 343 465 102 346 minecraft:light_gray_concrete
fill 465 95 353 465 102 356 minecraft:light_gray_concrete
fill 465 95 363 465 102 363 minecraft:light_gray_concrete
setblock 424 96 325 minecraft:light_gray_concrete
setblock 424 96 335 minecraft:light_gray_concrete
setblock 424 96 345 minecraft:light_gray_concrete
setblock 424 96 355 minecraft:light_gray_concrete
setblock 426 96 363 minecraft:light_gray_concrete
setblock 430 96 323 minecraft:light_gray_concrete
setblock 436 96 363 minecraft:light_gray_concrete
setblock 440 96 323 minecraft:light_gray_concrete
setblock 446 96 363 minecraft:light_gray_concrete
setblock 450 96 323 minecraft:light_gray_concrete
setblock 456 96 363 minecraft:light_gray_concrete
setblock 460 96 323 minecraft:light_gray_concrete
fill 460 96 328 460 96 330 minecraft:light_gray_concrete
fill 461 96 328 462 96 328 minecraft:light_gray_concrete
fill 461 96 330 462 96 330 minecraft:light_gray_concrete
setblock 462 96 329 minecraft:light_gray_concrete
setblock 464 96 329 minecraft:light_gray_concrete
setblock 464 96 339 minecraft:light_gray_concrete
setblock 464 96 349 minecraft:light_gray_concrete
setblock 464 96 359 minecraft:light_gray_concrete
setblock 426 97 325 minecraft:light[level=14]
setblock 426 97 333 minecraft:light[level=14]
setblock 426 97 341 minecraft:light[level=14]
setblock 426 97 349 minecraft:light[level=14]
setblock 426 97 357 minecraft:light[level=14]
setblock 434 97 325 minecraft:light[level=14]
setblock 434 97 333 minecraft:light[level=14]
setblock 434 97 341 minecraft:light[level=14]
setblock 434 97 349 minecraft:light[level=14]
setblock 434 97 357 minecraft:light[level=14]
setblock 442 97 325 minecraft:light[level=14]
setblock 442 97 333 minecraft:light[level=14]
setblock 442 97 341 minecraft:light[level=14]
setblock 442 97 349 minecraft:light[level=14]
setblock 442 97 357 minecraft:light[level=14]
setblock 450 97 325 minecraft:light[level=14]
setblock 450 97 333 minecraft:light[level=14]
setblock 450 97 341 minecraft:light[level=14]
setblock 450 97 349 minecraft:light[level=14]
setblock 450 97 357 minecraft:light[level=14]
setblock 458 97 325 minecraft:light[level=14]
setblock 458 97 333 minecraft:light[level=14]
setblock 458 97 341 minecraft:light[level=14]
setblock 458 97 349 minecraft:light[level=14]
setblock 458 97 357 minecraft:light[level=14]
fill 424 99 327 424 99 330 minecraft:light_gray_concrete
fill 424 99 337 424 99 340 minecraft:light_gray_concrete
fill 424 99 347 424 99 350 minecraft:light_gray_concrete
fill 424 99 357 424 99 360 minecraft:light_gray_concrete
fill 425 99 323 428 99 323 minecraft:light_gray_concrete
fill 425 99 329 429 99 331 minecraft:iron_block
fill 426 99 328 428 99 328 minecraft:iron_block
fill 426 99 332 428 99 332 minecraft:iron_block
fill 428 99 363 431 99 363 minecraft:light_gray_concrete
fill 429 99 325 433 99 327 minecraft:iron_block
fill 430 99 324 432 99 324 minecraft:iron_block
fill 430 99 328 432 99 328 minecraft:iron_block
fill 434 99 358 434 99 360 minecraft:light_gray_concrete
fill 435 99 323 438 99 323 minecraft:light_gray_concrete
fill 435 99 358 436 99 358 minecraft:light_gray_concrete
fill 435 99 360 436 99 360 minecraft:light_gray_concrete
setblock 436 99 359 minecraft:light_gray_concrete
fill 438 99 363 441 99 363 minecraft:light_gray_concrete
fill 445 99 323 448 99 323 minecraft:light_gray_concrete
fill 448 99 363 451 99 363 minecraft:light_gray_concrete
fill 455 99 323 458 99 323 minecraft:light_gray_concrete
fill 458 99 363 461 99 363 minecraft:light_gray_concrete
fill 464 99 324 464 99 327 minecraft:light_gray_concrete
fill 464 99 334 464 99 337 minecraft:light_gray_concrete
fill 464 99 344 464 99 347 minecraft:light_gray_concrete
fill 464 99 354 464 99 357 minecraft:light_gray_concrete
setblock 424 102 325 minecraft:light_gray_concrete
setblock 424 102 335 minecraft:light_gray_concrete
setblock 424 102 345 minecraft:light_gray_concrete
setblock 424 102 355 minecraft:light_gray_concrete
setblock 426 102 363 minecraft:light_gray_concrete
setblock 430 102 323 minecraft:light_gray_concrete
setblock 436 102 363 minecraft:light_gray_concrete
fill 439 102 359 441 103 359 minecraft:lime_concrete
setblock 440 102 323 minecraft:light_gray_concrete
fill 440 102 358 440 103 358 minecraft:lime_concrete
fill 440 102 360 440 103 360 minecraft:lime_concrete
setblock 446 102 363 minecraft:light_gray_concrete
setblock 450 102 323 minecraft:light_gray_concrete
setblock 456 102 363 minecraft:light_gray_concrete
setblock 460 102 323 minecraft:light_gray_concrete
setblock 464 102 329 minecraft:light_gray_concrete
setblock 464 102 339 minecraft:light_gray_concrete
setblock 464 102 349 minecraft:light_gray_concrete
setblock 464 102 359 minecraft:light_gray_concrete
fill 423 103 328 423 103 331 minecraft:verdant_froglight
fill 423 103 338 423 103 341 minecraft:verdant_froglight
fill 423 103 348 423 103 351 minecraft:verdant_froglight
fill 423 103 358 423 103 361 minecraft:verdant_froglight
fill 426 103 322 429 103 322 minecraft:verdant_froglight
fill 427 103 364 430 103 364 minecraft:verdant_froglight
fill 436 103 322 439 103 322 minecraft:verdant_froglight
fill 437 103 364 440 103 364 minecraft:verdant_froglight
fill 446 103 322 449 103 322 minecraft:verdant_froglight
fill 447 103 364 450 103 364 minecraft:verdant_froglight
fill 456 103 322 459 103 322 minecraft:verdant_froglight
fill 457 103 364 460 103 364 minecraft:verdant_froglight
fill 460 103 328 460 103 330 minecraft:light_gray_concrete
fill 461 103 328 462 103 328 minecraft:light_gray_concrete
fill 461 103 330 462 103 330 minecraft:light_gray_concrete
setblock 462 103 329 minecraft:light_gray_concrete
fill 465 103 323 465 103 326 minecraft:verdant_froglight
fill 465 103 333 465 103 336 minecraft:verdant_froglight
fill 465 103 343 465 103 346 minecraft:verdant_froglight
fill 465 103 353 465 103 356 minecraft:verdant_froglight
setblock 465 103 363 minecraft:verdant_froglight
fill 423 104 328 423 111 331 minecraft:light_gray_concrete
fill 423 104 338 423 111 341 minecraft:light_gray_concrete
fill 423 104 348 423 111 351 minecraft:light_gray_concrete
fill 423 104 358 423 111 361 minecraft:light_gray_concrete
fill 424 104 345 426 105 345 minecraft:iron_block
fill 426 104 322 429 111 322 minecraft:light_gray_concrete
fill 427 104 364 430 111 364 minecraft:light_gray_concrete
fill 436 104 322 439 111 322 minecraft:light_gray_concrete
fill 437 104 364 440 111 364 minecraft:light_gray_concrete
fill 446 104 322 449 111 322 minecraft:light_gray_concrete
fill 447 104 364 450 111 364 minecraft:light_gray_concrete
fill 456 104 322 459 111 322 minecraft:light_gray_concrete
fill 457 104 364 460 111 364 minecraft:light_gray_concrete
fill 465 104 323 465 111 326 minecraft:light_gray_concrete
fill 465 104 333 465 111 336 minecraft:light_gray_concrete
fill 465 104 343 465 111 346 minecraft:light_gray_concrete
fill 465 104 353 465 111 356 minecraft:light_gray_concrete
fill 465 104 363 465 111 363 minecraft:light_gray_concrete
setblock 426 105 325 minecraft:light[level=14]
setblock 426 105 333 minecraft:light[level=14]
setblock 426 105 341 minecraft:light[level=14]
setblock 426 105 349 minecraft:light[level=14]
setblock 426 105 357 minecraft:light[level=14]
setblock 434 105 325 minecraft:light[level=14]
setblock 434 105 333 minecraft:light[level=14]
setblock 434 105 341 minecraft:light[level=14]
setblock 434 105 349 minecraft:light[level=14]
setblock 434 105 357 minecraft:light[level=14]
fill 434 105 358 434 105 360 minecraft:light_gray_concrete
fill 435 105 358 436 105 358 minecraft:light_gray_concrete
fill 435 105 360 436 105 360 minecraft:light_gray_concrete
setblock 436 105 359 minecraft:light_gray_concrete
setblock 442 105 325 minecraft:light[level=14]
setblock 442 105 333 minecraft:light[level=14]
setblock 442 105 341 minecraft:light[level=14]
setblock 442 105 349 minecraft:light[level=14]
setblock 442 105 357 minecraft:light[level=14]
setblock 450 105 325 minecraft:light[level=14]
setblock 450 105 333 minecraft:light[level=14]
setblock 450 105 341 minecraft:light[level=14]
setblock 450 105 349 minecraft:light[level=14]
setblock 450 105 357 minecraft:light[level=14]
setblock 458 105 325 minecraft:light[level=14]
setblock 458 105 333 minecraft:light[level=14]
setblock 458 105 341 minecraft:light[level=14]
setblock 458 105 349 minecraft:light[level=14]
setblock 458 105 357 minecraft:light[level=14]
setblock 424 108 325 minecraft:light_gray_concrete
fill 424 108 327 424 108 330 minecraft:light_gray_concrete
setblock 424 108 335 minecraft:light_gray_concrete
fill 424 108 337 424 108 340 minecraft:light_gray_concrete
setblock 424 108 345 minecraft:light_gray_concrete
fill 424 108 347 424 108 350 minecraft:light_gray_concrete
setblock 424 108 355 minecraft:light_gray_concrete
fill 424 108 357 424 108 360 minecraft:light_gray_concrete
fill 425 108 323 428 108 323 minecraft:light_gray_concrete
setblock 426 108 363 minecraft:light_gray_concrete
fill 428 108 363 431 108 363 minecraft:light_gray_concrete
setblock 430 108 323 minecraft:light_gray_concrete
fill 435 108 323 438 108 323 minecraft:light_gray_concrete
setblock 436 108 363 minecraft:light_gray_concrete
fill 437 108 333 437 109 334 minecraft:lime_stained_glass
fill 438 108 363 441 108 363 minecraft:light_gray_concrete
setblock 440 108 323 minecraft:light_gray_concrete
fill 445 108 323 448 108 323 minecraft:light_gray_concrete
setblock 446 108 363 minecraft:light_gray_concrete
fill 448 108 363 451 108 363 minecraft:light_gray_concrete
setblock 450 108 323 minecraft:light_gray_concrete
fill 455 108 323 458 108 323 minecraft:light_gray_concrete
setblock 456 108 363 minecraft:light_gray_concrete
fill 458 108 363 461 108 363 minecraft:light_gray_concrete
setblock 460 108 323 minecraft:light_gray_concrete
fill 464 108 324 464 108 327 minecraft:light_gray_concrete
setblock 464 108 329 minecraft:light_gray_concrete
fill 464 108 334 464 108 337 minecraft:light_gray_concrete
setblock 464 108 339 minecraft:light_gray_concrete
fill 464 108 344 464 108 347 minecraft:light_gray_concrete
setblock 464 108 349 minecraft:light_gray_concrete
fill 464 108 354 464 108 357 minecraft:light_gray_concrete
setblock 464 108 359 minecraft:light_gray_concrete
fill 449 109 323 449 110 325 minecraft:iron_block
fill 460 110 328 460 110 330 minecraft:light_gray_concrete
fill 461 110 328 462 110 328 minecraft:light_gray_concrete
fill 461 110 330 462 110 330 minecraft:light_gray_concrete
setblock 462 110 329 minecraft:light_gray_concrete
fill 434 111 358 434 111 360 minecraft:light_gray_concrete
fill 435 111 358 436 111 358 minecraft:light_gray_concrete
fill 435 111 360 436 111 360 minecraft:light_gray_concrete
setblock 436 111 359 minecraft:light_gray_concrete
fill 423 112 328 423 112 331 minecraft:verdant_froglight
fill 423 112 338 423 112 341 minecraft:verdant_froglight
fill 423 112 348 423 112 351 minecraft:verdant_froglight
fill 423 112 358 423 112 361 minecraft:verdant_froglight
fill 426 112 322 429 112 322 minecraft:verdant_froglight
fill 427 112 364 430 112 364 minecraft:verdant_froglight
fill 436 112 322 439 112 322 minecraft:verdant_froglight
fill 437 112 364 440 112 364 minecraft:verdant_froglight
fill 446 112 322 449 112 322 minecraft:verdant_froglight
fill 447 112 364 450 112 364 minecraft:verdant_froglight
fill 456 112 322 459 112 322 minecraft:verdant_froglight
fill 457 112 364 460 112 364 minecraft:verdant_froglight
fill 465 112 323 465 112 326 minecraft:verdant_froglight
fill 465 112 333 465 112 336 minecraft:verdant_froglight
fill 465 112 343 465 112 346 minecraft:verdant_froglight
fill 465 112 353 465 112 356 minecraft:verdant_froglight
setblock 465 112 363 minecraft:verdant_froglight
fill 423 113 328 423 120 331 minecraft:light_gray_concrete
fill 423 113 338 423 120 341 minecraft:light_gray_concrete
fill 423 113 348 423 120 351 minecraft:light_gray_concrete
fill 423 113 358 423 120 361 minecraft:light_gray_concrete
fill 426 113 322 429 120 322 minecraft:light_gray_concrete
setblock 426 113 325 minecraft:light[level=14]
setblock 426 113 333 minecraft:light[level=14]
setblock 426 113 341 minecraft:light[level=14]
setblock 426 113 349 minecraft:light[level=14]
setblock 426 113 357 minecraft:light[level=14]
fill 427 113 364 430 120 364 minecraft:light_gray_concrete
setblock 434 113 325 minecraft:light[level=14]
setblock 434 113 333 minecraft:light[level=14]
setblock 434 113 341 minecraft:light[level=14]
setblock 434 113 349 minecraft:light[level=14]
setblock 434 113 357 minecraft:light[level=14]
fill 436 113 322 439 120 322 minecraft:light_gray_concrete
fill 437 113 364 440 120 364 minecraft:light_gray_concrete
setblock 442 113 325 minecraft:light[level=14]
setblock 442 113 333 minecraft:light[level=14]
setblock 442 113 341 minecraft:light[level=14]
setblock 442 113 349 minecraft:light[level=14]
setblock 442 113 357 minecraft:light[level=14]
fill 444 113 358 448 113 360 minecraft:iron_block
fill 445 113 357 447 113 357 minecraft:iron_block
fill 445 113 361 447 113 361 minecraft:iron_block
fill 446 113 322 449 120 322 minecraft:light_gray_concrete
fill 447 113 364 450 120 364 minecraft:light_gray_concrete
setblock 450 113 325 minecraft:light[level=14]
setblock 450 113 333 minecraft:light[level=14]
setblock 450 113 341 minecraft:light[level=14]
setblock 450 113 349 minecraft:light[level=14]
setblock 450 113 357 minecraft:light[level=14]
fill 456 113 322 459 120 322 minecraft:light_gray_concrete
fill 457 113 364 460 120 364 minecraft:light_gray_concrete
setblock 458 113 325 minecraft:light[level=14]
setblock 458 113 333 minecraft:light[level=14]
setblock 458 113 341 minecraft:light[level=14]
setblock 458 113 349 minecraft:light[level=14]
setblock 458 113 357 minecraft:light[level=14]
fill 465 113 323 465 120 326 minecraft:light_gray_concrete
fill 465 113 333 465 120 336 minecraft:light_gray_concrete
fill 465 113 343 465 120 346 minecraft:light_gray_concrete
fill 465 113 353 465 120 356 minecraft:light_gray_concrete
fill 465 113 363 465 120 363 minecraft:light_gray_concrete
setblock 424 114 325 minecraft:light_gray_concrete
setblock 424 114 335 minecraft:light_gray_concrete
setblock 424 114 345 minecraft:light_gray_concrete
setblock 424 114 355 minecraft:light_gray_concrete
setblock 426 114 363 minecraft:light_gray_concrete
setblock 430 114 323 minecraft:light_gray_concrete
setblock 436 114 363 minecraft:light_gray_concrete
setblock 440 114 323 minecraft:light_gray_concrete
fill 444 114 358 448 121 360 minecraft:glass
fill 445 114 357 447 121 357 minecraft:glass
fill 445 114 361 447 121 361 minecraft:glass
setblock 446 114 363 minecraft:light_gray_concrete
setblock 450 114 323 minecraft:light_gray_concrete
setblock 456 114 363 minecraft:light_gray_concrete
setblock 460 114 323 minecraft:light_gray_concrete
fill 461 114 339 463 115 339 minecraft:iron_block
setblock 464 114 329 minecraft:light_gray_concrete
setblock 464 114 339 minecraft:light_gray_concrete
setblock 464 114 349 minecraft:light_gray_concrete
setblock 464 114 359 minecraft:light_gray_concrete
fill 424 117 327 424 117 330 minecraft:light_gray_concrete
fill 424 117 337 424 117 340 minecraft:light_gray_concrete
fill 424 117 347 424 117 350 minecraft:light_gray_concrete
fill 424 117 357 424 117 360 minecraft:light_gray_concrete
fill 425 117 323 428 117 323 minecraft:light_gray_concrete
fill 428 117 363 431 117 363 minecraft:light_gray_concrete
fill 434 117 358 434 117 360 minecraft:light_gray_concrete
fill 435 117 323 438 117 323 minecraft:light_gray_concrete
fill 435 117 358 436 117 358 minecraft:light_gray_concrete
fill 435 117 360 436 117 360 minecraft:light_gray_concrete
setblock 436 117 359 minecraft:light_gray_concrete
fill 438 117 363 441 117 363 minecraft:light_gray_concrete
fill 445 117 323 448 117 323 minecraft:light_gray_concrete
fill 448 117 363 451 117 363 minecraft:light_gray_concrete
fill 455 117 323 458 117 323 minecraft:light_gray_concrete
fill 458 117 363 461 117 363 minecraft:light_gray_concrete
fill 460 117 328 460 117 330 minecraft:light_gray_concrete
fill 461 117 328 462 117 328 minecraft:light_gray_concrete
fill 461 117 330 462 117 330 minecraft:light_gray_concrete
setblock 462 117 329 minecraft:light_gray_concrete
fill 464 117 324 464 117 327 minecraft:light_gray_concrete
fill 464 117 334 464 117 337 minecraft:light_gray_concrete
fill 464 117 344 464 117 347 minecraft:light_gray_concrete
fill 464 117 354 464 117 357 minecraft:light_gray_concrete
setblock 424 120 325 minecraft:light_gray_concrete
setblock 424 120 335 minecraft:light_gray_concrete
setblock 424 120 345 minecraft:light_gray_concrete
setblock 424 120 355 minecraft:light_gray_concrete
setblock 426 120 363 minecraft:light_gray_concrete
setblock 430 120 323 minecraft:light_gray_concrete
setblock 436 120 363 minecraft:light_gray_concrete
setblock 440 120 323 minecraft:light_gray_concrete
setblock 446 120 363 minecraft:light_gray_concrete
setblock 450 120 323 minecraft:light_gray_concrete
setblock 456 120 363 minecraft:light_gray_concrete
setblock 460 120 323 minecraft:light_gray_concrete
setblock 464 120 329 minecraft:light_gray_concrete
setblock 464 120 339 minecraft:light_gray_concrete
setblock 464 120 349 minecraft:light_gray_concrete
setblock 464 120 359 minecraft:light_gray_concrete
fill 423 121 328 423 121 331 minecraft:verdant_froglight
fill 423 121 338 423 121 341 minecraft:verdant_froglight
fill 423 121 348 423 121 351 minecraft:verdant_froglight
fill 423 121 358 423 121 361 minecraft:verdant_froglight
fill 426 121 322 429 121 322 minecraft:verdant_froglight
setblock 426 121 325 minecraft:light[level=14]
setblock 426 121 333 minecraft:light[level=14]
setblock 426 121 341 minecraft:light[level=14]
setblock 426 121 349 minecraft:light[level=14]
setblock 426 121 357 minecraft:light[level=14]
fill 427 121 364 430 121 364 minecraft:verdant_froglight
setblock 434 121 325 minecraft:light[level=14]
setblock 434 121 333 minecraft:light[level=14]
setblock 434 121 341 minecraft:light[level=14]
setblock 434 121 349 minecraft:light[level=14]
setblock 434 121 357 minecraft:light[level=14]
fill 436 121 322 439 121 322 minecraft:verdant_froglight
fill 437 121 364 440 121 364 minecraft:verdant_froglight
setblock 442 121 325 minecraft:light[level=14]
setblock 442 121 333 minecraft:light[level=14]
setblock 442 121 341 minecraft:light[level=14]
setblock 442 121 349 minecraft:light[level=14]
setblock 442 121 357 minecraft:light[level=14]
fill 446 121 322 449 121 322 minecraft:verdant_froglight
fill 447 121 364 450 121 364 minecraft:verdant_froglight
setblock 450 121 325 minecraft:light[level=14]
setblock 450 121 333 minecraft:light[level=14]
setblock 450 121 341 minecraft:light[level=14]
setblock 450 121 349 minecraft:light[level=14]
setblock 450 121 357 minecraft:light[level=14]
fill 456 121 322 459 121 322 minecraft:verdant_froglight
fill 457 121 364 460 121 364 minecraft:verdant_froglight
setblock 458 121 325 minecraft:light[level=14]
setblock 458 121 333 minecraft:light[level=14]
setblock 458 121 341 minecraft:light[level=14]
setblock 458 121 349 minecraft:light[level=14]
setblock 458 121 357 minecraft:light[level=14]
fill 465 121 323 465 121 326 minecraft:verdant_froglight
fill 465 121 333 465 121 336 minecraft:verdant_froglight
fill 465 121 343 465 121 346 minecraft:verdant_froglight
fill 465 121 353 465 121 356 minecraft:verdant_froglight
setblock 465 121 363 minecraft:verdant_froglight
fill 423 122 328 423 129 331 minecraft:light_gray_concrete
fill 423 122 338 423 129 341 minecraft:light_gray_concrete
fill 423 122 348 423 129 351 minecraft:light_gray_concrete
fill 423 122 358 423 129 361 minecraft:light_gray_concrete
fill 426 122 322 429 129 322 minecraft:light_gray_concrete
fill 427 122 364 430 129 364 minecraft:light_gray_concrete
fill 436 122 322 439 129 322 minecraft:light_gray_concrete
fill 437 122 364 440 129 364 minecraft:light_gray_concrete
fill 444 122 358 448 122 360 minecraft:iron_block
fill 445 122 357 447 122 357 minecraft:iron_block
fill 445 122 361 447 122 361 minecraft:iron_block
fill 446 122 322 449 129 322 minecraft:light_gray_concrete
fill 447 122 364 450 129 364 minecraft:light_gray_concrete
fill 456 122 322 459 129 322 minecraft:light_gray_concrete
fill 457 122 364 460 129 364 minecraft:light_gray_concrete
fill 465 122 323 465 129 326 minecraft:light_gray_concrete
fill 465 122 333 465 129 336 minecraft:light_gray_concrete
fill 465 122 343 465 129 346 minecraft:light_gray_concrete
fill 465 122 353 465 129 356 minecraft:light_gray_concrete
fill 465 122 363 465 129 363 minecraft:light_gray_concrete
fill 434 123 358 434 123 360 minecraft:light_gray_concrete
fill 435 123 358 436 123 358 minecraft:light_gray_concrete
fill 435 123 360 436 123 360 minecraft:light_gray_concrete
setblock 436 123 359 minecraft:light_gray_concrete
fill 460 124 328 460 124 330 minecraft:light_gray_concrete
fill 461 124 328 462 124 328 minecraft:light_gray_concrete
fill 461 124 330 462 124 330 minecraft:light_gray_concrete
setblock 462 124 329 minecraft:light_gray_concrete
setblock 424 126 325 minecraft:light_gray_concrete
fill 424 126 327 424 126 330 minecraft:light_gray_concrete
setblock 424 126 335 minecraft:light_gray_concrete
fill 424 126 337 424 126 340 minecraft:light_gray_concrete
setblock 424 126 345 minecraft:light_gray_concrete
fill 424 126 347 424 126 350 minecraft:light_gray_concrete
setblock 424 126 355 minecraft:light_gray_concrete
fill 424 126 357 424 126 360 minecraft:light_gray_concrete
fill 425 126 323 428 126 323 minecraft:light_gray_concrete
setblock 426 126 363 minecraft:light_gray_concrete
fill 428 126 363 431 126 363 minecraft:light_gray_concrete
setblock 430 126 323 minecraft:light_gray_concrete
fill 435 126 323 438 126 323 minecraft:light_gray_concrete
setblock 436 126 363 minecraft:light_gray_concrete
fill 438 126 363 441 126 363 minecraft:light_gray_concrete
setblock 440 126 323 minecraft:light_gray_concrete
fill 445 126 323 448 126 323 minecraft:light_gray_concrete
setblock 446 126 363 minecraft:light_gray_concrete
fill 448 126 363 451 126 363 minecraft:light_gray_concrete
setblock 450 126 323 minecraft:light_gray_concrete
fill 455 126 323 458 126 323 minecraft:light_gray_concrete
setblock 456 126 363 minecraft:light_gray_concrete
fill 458 126 363 461 126 363 minecraft:light_gray_concrete
setblock 460 126 323 minecraft:light_gray_concrete
fill 464 126 324 464 126 327 minecraft:light_gray_concrete
setblock 464 126 329 minecraft:light_gray_concrete
fill 464 126 334 464 126 337 minecraft:light_gray_concrete
setblock 464 126 339 minecraft:light_gray_concrete
fill 464 126 344 464 126 347 minecraft:light_gray_concrete
setblock 464 126 349 minecraft:light_gray_concrete
fill 464 126 354 464 126 357 minecraft:light_gray_concrete
setblock 464 126 359 minecraft:light_gray_concrete
setblock 426 129 325 minecraft:light[level=14]
setblock 426 129 333 minecraft:light[level=14]
setblock 426 129 341 minecraft:light[level=14]
setblock 426 129 349 minecraft:light[level=14]
setblock 426 129 357 minecraft:light[level=14]
setblock 434 129 325 minecraft:light[level=14]
setblock 434 129 333 minecraft:light[level=14]
setblock 434 129 341 minecraft:light[level=14]
setblock 434 129 349 minecraft:light[level=14]
setblock 434 129 357 minecraft:light[level=14]
fill 434 129 358 434 129 360 minecraft:light_gray_concrete
fill 435 129 358 436 129 358 minecraft:light_gray_concrete
fill 435 129 360 436 129 360 minecraft:light_gray_concrete
setblock 436 129 359 minecraft:light_gray_concrete
setblock 442 129 325 minecraft:light[level=14]
setblock 442 129 333 minecraft:light[level=14]
setblock 442 129 341 minecraft:light[level=14]
setblock 442 129 349 minecraft:light[level=14]
setblock 442 129 357 minecraft:light[level=14]
setblock 450 129 325 minecraft:light[level=14]
setblock 450 129 333 minecraft:light[level=14]
setblock 450 129 341 minecraft:light[level=14]
setblock 450 129 349 minecraft:light[level=14]
setblock 450 129 357 minecraft:light[level=14]
setblock 458 129 325 minecraft:light[level=14]
setblock 458 129 333 minecraft:light[level=14]
setblock 458 129 341 minecraft:light[level=14]
setblock 458 129 349 minecraft:light[level=14]
setblock 458 129 357 minecraft:light[level=14]
fill 423 130 328 423 130 331 minecraft:verdant_froglight
fill 423 130 338 423 130 341 minecraft:verdant_froglight
fill 423 130 348 423 130 351 minecraft:verdant_froglight
fill 423 130 358 423 130 361 minecraft:verdant_froglight
fill 426 130 322 429 130 322 minecraft:verdant_froglight
fill 427 130 364 430 130 364 minecraft:verdant_froglight
fill 436 130 322 439 130 322 minecraft:verdant_froglight
fill 437 130 364 440 130 364 minecraft:verdant_froglight
fill 446 130 322 449 130 322 minecraft:verdant_froglight
fill 447 130 364 450 130 364 minecraft:verdant_froglight
fill 456 130 322 459 130 322 minecraft:verdant_froglight
fill 457 130 364 460 130 364 minecraft:verdant_froglight
fill 465 130 323 465 130 326 minecraft:verdant_froglight
fill 465 130 333 465 130 336 minecraft:verdant_froglight
fill 465 130 343 465 130 346 minecraft:verdant_froglight
fill 465 130 353 465 130 356 minecraft:verdant_froglight
setblock 465 130 363 minecraft:verdant_froglight
fill 423 131 328 423 138 331 minecraft:light_gray_concrete
fill 423 131 338 423 138 341 minecraft:light_gray_concrete
fill 423 131 348 423 138 351 minecraft:light_gray_concrete
fill 423 131 358 423 138 361 minecraft:light_gray_concrete
fill 426 131 322 429 138 322 minecraft:light_gray_concrete
fill 427 131 364 430 138 364 minecraft:light_gray_concrete
fill 436 131 322 439 138 322 minecraft:light_gray_concrete
fill 437 131 364 440 138 364 minecraft:light_gray_concrete
fill 446 131 322 449 138 322 minecraft:light_gray_concrete
fill 447 131 364 450 138 364 minecraft:light_gray_concrete
fill 456 131 322 459 138 322 minecraft:light_gray_concrete
fill 457 131 364 460 138 364 minecraft:light_gray_concrete
fill 460 131 328 460 131 330 minecraft:light_gray_concrete
fill 461 131 328 462 131 328 minecraft:light_gray_concrete
fill 461 131 330 462 131 330 minecraft:light_gray_concrete
setblock 462 131 329 minecraft:light_gray_concrete
fill 465 131 323 465 138 326 minecraft:light_gray_concrete
fill 465 131 333 465 138 336 minecraft:light_gray_concrete
fill 465 131 343 465 138 346 minecraft:light_gray_concrete
fill 465 131 353 465 138 356 minecraft:light_gray_concrete
fill 465 131 363 465 138 363 minecraft:light_gray_concrete
setblock 424 132 325 minecraft:light_gray_concrete
setblock 424 132 335 minecraft:light_gray_concrete
setblock 424 132 345 minecraft:light_gray_concrete
setblock 424 132 355 minecraft:light_gray_concrete
setblock 426 132 363 minecraft:light_gray_concrete
setblock 430 132 323 minecraft:light_gray_concrete
setblock 436 132 363 minecraft:light_gray_concrete
setblock 440 132 323 minecraft:light_gray_concrete
setblock 446 132 363 minecraft:light_gray_concrete
setblock 450 132 323 minecraft:light_gray_concrete
setblock 456 132 363 minecraft:light_gray_concrete
setblock 460 132 323 minecraft:light_gray_concrete
setblock 464 132 329 minecraft:light_gray_concrete
setblock 464 132 339 minecraft:light_gray_concrete
setblock 464 132 349 minecraft:light_gray_concrete
setblock 464 132 359 minecraft:light_gray_concrete
fill 424 135 327 424 135 330 minecraft:light_gray_concrete
fill 424 135 337 424 135 340 minecraft:light_gray_concrete
fill 424 135 347 424 135 350 minecraft:light_gray_concrete
fill 424 135 357 424 135 360 minecraft:light_gray_concrete
fill 425 135 323 428 135 323 minecraft:light_gray_concrete
fill 428 135 363 431 135 363 minecraft:light_gray_concrete
fill 434 135 358 434 135 360 minecraft:light_gray_concrete
fill 435 135 323 438 135 323 minecraft:light_gray_concrete
fill 435 135 358 436 135 358 minecraft:light_gray_concrete
fill 435 135 360 436 135 360 minecraft:light_gray_concrete
setblock 436 135 359 minecraft:light_gray_concrete
fill 438 135 363 441 135 363 minecraft:light_gray_concrete
fill 445 135 323 448 135 323 minecraft:light_gray_concrete
fill 448 135 363 451 135 363 minecraft:light_gray_concrete
fill 455 135 323 458 135 323 minecraft:light_gray_concrete
fill 458 135 363 461 135 363 minecraft:light_gray_concrete
fill 464 135 324 464 135 327 minecraft:light_gray_concrete
fill 464 135 334 464 135 337 minecraft:light_gray_concrete
fill 464 135 344 464 135 347 minecraft:light_gray_concrete
fill 464 135 354 464 135 357 minecraft:light_gray_concrete
fill 424 136 347 426 137 347 minecraft:iron_block
setblock 426 137 325 minecraft:light[level=14]
setblock 426 137 333 minecraft:light[level=14]
setblock 426 137 341 minecraft:light[level=14]
setblock 426 137 349 minecraft:light[level=14]
setblock 426 137 357 minecraft:light[level=14]
setblock 434 137 325 minecraft:light[level=14]
setblock 434 137 333 minecraft:light[level=14]
setblock 434 137 341 minecraft:light[level=14]
setblock 434 137 349 minecraft:light[level=14]
setblock 434 137 357 minecraft:light[level=14]
setblock 442 137 325 minecraft:light[level=14]
setblock 442 137 333 minecraft:light[level=14]
setblock 442 137 341 minecraft:light[level=14]
setblock 442 137 349 minecraft:light[level=14]
setblock 442 137 357 minecraft:light[level=14]
setblock 450 137 325 minecraft:light[level=14]
setblock 450 137 333 minecraft:light[level=14]
setblock 450 137 341 minecraft:light[level=14]
setblock 450 137 349 minecraft:light[level=14]
setblock 450 137 357 minecraft:light[level=14]
setblock 458 137 325 minecraft:light[level=14]
setblock 458 137 333 minecraft:light[level=14]
setblock 458 137 341 minecraft:light[level=14]
setblock 458 137 349 minecraft:light[level=14]
setblock 458 137 357 minecraft:light[level=14]
setblock 424 138 325 minecraft:light_gray_concrete
setblock 424 138 335 minecraft:light_gray_concrete
setblock 424 138 345 minecraft:light_gray_concrete
setblock 424 138 355 minecraft:light_gray_concrete
setblock 426 138 363 minecraft:light_gray_concrete
setblock 430 138 323 minecraft:light_gray_concrete
setblock 436 138 363 minecraft:light_gray_concrete
setblock 440 138 323 minecraft:light_gray_concrete
setblock 446 138 363 minecraft:light_gray_concrete
setblock 450 138 323 minecraft:light_gray_concrete
setblock 456 138 363 minecraft:light_gray_concrete
setblock 460 138 323 minecraft:light_gray_concrete
fill 460 138 328 460 138 330 minecraft:light_gray_concrete
fill 461 138 328 462 138 328 minecraft:light_gray_concrete
fill 461 138 330 462 138 330 minecraft:light_gray_concrete
setblock 462 138 329 minecraft:light_gray_concrete
setblock 464 138 329 minecraft:light_gray_concrete
setblock 464 138 339 minecraft:light_gray_concrete
setblock 464 138 349 minecraft:light_gray_concrete
setblock 464 138 359 minecraft:light_gray_concrete
fill 423 139 328 423 139 331 minecraft:verdant_froglight
fill 423 139 338 423 139 341 minecraft:verdant_froglight
fill 423 139 348 423 139 351 minecraft:verdant_froglight
fill 423 139 358 423 139 361 minecraft:verdant_froglight
fill 426 139 322 429 139 322 minecraft:verdant_froglight
fill 427 139 364 430 139 364 minecraft:verdant_froglight
fill 436 139 322 439 139 322 minecraft:verdant_froglight
fill 437 139 364 440 139 364 minecraft:verdant_froglight
fill 446 139 322 449 139 322 minecraft:verdant_froglight
fill 447 139 364 450 139 364 minecraft:verdant_froglight
fill 456 139 322 459 139 322 minecraft:verdant_froglight
fill 457 139 364 460 139 364 minecraft:verdant_froglight
fill 465 139 323 465 139 326 minecraft:verdant_froglight
fill 465 139 333 465 139 336 minecraft:verdant_froglight
fill 465 139 343 465 139 346 minecraft:verdant_froglight
fill 465 139 353 465 139 356 minecraft:verdant_froglight
setblock 465 139 363 minecraft:verdant_froglight
fill 423 140 328 423 156 331 minecraft:light_gray_concrete
fill 423 140 338 423 156 341 minecraft:light_gray_concrete
fill 423 140 348 423 156 351 minecraft:light_gray_concrete
fill 423 140 358 423 156 361 minecraft:light_gray_concrete
fill 426 140 322 429 156 322 minecraft:light_gray_concrete
fill 427 140 364 430 156 364 minecraft:light_gray_concrete
fill 436 140 322 439 156 322 minecraft:light_gray_concrete
fill 437 140 364 440 156 364 minecraft:light_gray_concrete
fill 446 140 322 449 156 322 minecraft:light_gray_concrete
fill 447 140 364 450 156 364 minecraft:light_gray_concrete
fill 456 140 322 459 156 322 minecraft:light_gray_concrete
fill 457 140 364 460 156 364 minecraft:light_gray_concrete
fill 465 140 323 465 156 326 minecraft:light_gray_concrete
fill 465 140 333 465 156 336 minecraft:light_gray_concrete
fill 465 140 343 465 156 346 minecraft:light_gray_concrete
fill 465 140 353 465 156 356 minecraft:light_gray_concrete
fill 465 140 363 465 156 363 minecraft:light_gray_concrete
fill 434 141 358 434 141 360 minecraft:light_gray_concrete
fill 435 141 358 436 141 358 minecraft:light_gray_concrete
fill 435 141 360 436 141 360 minecraft:light_gray_concrete
setblock 436 141 359 minecraft:light_gray_concrete
setblock 424 144 325 minecraft:light_gray_concrete
fill 424 144 327 424 144 330 minecraft:light_gray_concrete
setblock 424 144 335 minecraft:light_gray_concrete
fill 424 144 337 424 144 340 minecraft:light_gray_concrete
setblock 424 144 345 minecraft:light_gray_concrete
fill 424 144 347 424 144 350 minecraft:light_gray_concrete
setblock 424 144 355 minecraft:light_gray_concrete
fill 424 144 357 424 144 360 minecraft:light_gray_concrete
fill 425 144 323 428 144 323 minecraft:light_gray_concrete
setblock 426 144 363 minecraft:light_gray_concrete
fill 428 144 363 431 144 363 minecraft:light_gray_concrete
setblock 430 144 323 minecraft:light_gray_concrete
fill 435 144 323 438 144 323 minecraft:light_gray_concrete
setblock 436 144 363 minecraft:light_gray_concrete
fill 438 144 363 441 144 363 minecraft:light_gray_concrete
setblock 440 144 323 minecraft:light_gray_concrete
fill 445 144 323 448 144 323 minecraft:light_gray_concrete
setblock 446 144 363 minecraft:light_gray_concrete
fill 448 144 363 451 144 363 minecraft:light_gray_concrete
setblock 450 144 323 minecraft:light_gray_concrete
fill 455 144 323 458 144 323 minecraft:light_gray_concrete
setblock 456 144 363 minecraft:light_gray_concrete
fill 458 144 363 461 144 363 minecraft:light_gray_concrete
setblock 460 144 323 minecraft:light_gray_concrete
fill 464 144 324 464 144 327 minecraft:light_gray_concrete
setblock 464 144 329 minecraft:light_gray_concrete
fill 464 144 334 464 144 337 minecraft:light_gray_concrete
setblock 464 144 339 minecraft:light_gray_concrete
fill 464 144 344 464 144 347 minecraft:light_gray_concrete
setblock 464 144 349 minecraft:light_gray_concrete
fill 464 144 354 464 144 357 minecraft:light_gray_concrete
setblock 464 144 359 minecraft:light_gray_concrete
setblock 426 145 325 minecraft:light[level=14]
setblock 426 145 333 minecraft:light[level=14]
setblock 426 145 341 minecraft:light[level=14]
setblock 426 145 349 minecraft:light[level=14]
setblock 426 145 357 minecraft:light[level=14]
setblock 434 145 325 minecraft:light[level=14]
setblock 434 145 333 minecraft:light[level=14]
setblock 434 145 341 minecraft:light[level=14]
setblock 434 145 349 minecraft:light[level=14]
setblock 434 145 357 minecraft:light[level=14]
setblock 442 145 325 minecraft:light[level=14]
setblock 442 145 333 minecraft:light[level=14]
setblock 442 145 341 minecraft:light[level=14]
setblock 442 145 349 minecraft:light[level=14]
setblock 442 145 357 minecraft:light[level=14]
setblock 450 145 325 minecraft:light[level=14]
setblock 450 145 333 minecraft:light[level=14]
setblock 450 145 341 minecraft:light[level=14]
setblock 450 145 349 minecraft:light[level=14]
setblock 450 145 357 minecraft:light[level=14]
setblock 458 145 325 minecraft:light[level=14]
setblock 458 145 333 minecraft:light[level=14]
setblock 458 145 341 minecraft:light[level=14]
setblock 458 145 349 minecraft:light[level=14]
setblock 458 145 357 minecraft:light[level=14]
fill 424 150 323 425 151 363 minecraft:lime_concrete
fill 426 150 323 426 151 363 minecraft:iron_block
fill 427 150 323 428 151 363 minecraft:lime_concrete
fill 429 150 323 429 151 363 minecraft:iron_block
fill 430 150 323 431 151 363 minecraft:lime_concrete
fill 432 150 323 432 151 363 minecraft:iron_block
fill 433 150 323 434 151 363 minecraft:lime_concrete
fill 435 150 323 435 151 363 minecraft:iron_block
fill 436 150 323 437 151 363 minecraft:lime_concrete
fill 438 150 323 438 151 363 minecraft:iron_block
fill 439 150 323 440 151 363 minecraft:lime_concrete
fill 441 150 323 441 151 363 minecraft:iron_block
fill 442 150 323 443 150 363 minecraft:lime_concrete
fill 444 150 323 444 150 341 minecraft:iron_block
fill 444 150 345 444 150 363 minecraft:iron_block
fill 445 150 323 446 150 340 minecraft:lime_concrete
fill 445 150 346 446 150 363 minecraft:lime_concrete
fill 447 150 323 447 150 340 minecraft:iron_block
fill 447 150 346 447 150 363 minecraft:iron_block
fill 448 150 323 449 150 341 minecraft:lime_concrete
fill 448 150 345 449 150 363 minecraft:lime_concrete
fill 449 150 342 449 150 344 minecraft:lime_concrete
fill 450 150 323 450 151 363 minecraft:iron_block
fill 451 150 323 452 151 363 minecraft:lime_concrete
fill 453 150 323 453 151 363 minecraft:iron_block
fill 454 150 323 455 151 363 minecraft:lime_concrete
fill 456 150 323 456 151 363 minecraft:iron_block
fill 457 150 323 458 151 363 minecraft:lime_concrete
fill 459 150 323 459 151 363 minecraft:iron_block
fill 460 150 323 461 151 363 minecraft:lime_concrete
fill 462 150 323 462 151 363 minecraft:iron_block
fill 463 150 323 464 151 363 minecraft:lime_concrete
fill 442 151 323 442 151 363 minecraft:lime_concrete
fill 443 151 323 443 151 340 minecraft:lime_concrete
fill 443 151 341 443 151 345 minecraft:verdant_froglight
fill 443 151 346 443 151 363 minecraft:lime_concrete
fill 444 151 323 444 151 339 minecraft:iron_block
fill 444 151 340 444 151 341 minecraft:verdant_froglight
fill 444 151 345 444 151 346 minecraft:verdant_froglight
fill 444 151 347 444 151 363 minecraft:iron_block
fill 445 151 323 446 151 339 minecraft:lime_concrete
fill 445 151 340 448 151 340 minecraft:verdant_froglight
fill 445 151 346 448 151 346 minecraft:verdant_froglight
fill 445 151 347 446 151 363 minecraft:lime_concrete
fill 447 151 323 447 151 339 minecraft:iron_block
fill 447 151 347 447 151 363 minecraft:iron_block
fill 448 151 323 449 151 339 minecraft:lime_concrete
fill 448 151 341 449 151 341 minecraft:verdant_froglight
fill 448 151 345 449 151 345 minecraft:verdant_froglight
fill 448 151 347 449 151 363 minecraft:lime_concrete
setblock 449 151 340 minecraft:lime_concrete
fill 449 151 342 449 151 344 minecraft:verdant_froglight
setblock 449 151 346 minecraft:lime_concrete
fill 443 152 341 443 152 345 minecraft:lime_stained_glass
fill 444 152 340 448 152 340 minecraft:lime_stained_glass
fill 444 152 346 448 152 346 minecraft:lime_stained_glass
fill 449 152 341 449 152 345 minecraft:lime_stained_glass
setblock 426 153 325 minecraft:light[level=14]
setblock 426 153 333 minecraft:light[level=14]
setblock 426 153 341 minecraft:light[level=14]
setblock 426 153 349 minecraft:light[level=14]
setblock 426 153 357 minecraft:light[level=14]
setblock 434 153 325 minecraft:light[level=14]
setblock 434 153 333 minecraft:light[level=14]
setblock 434 153 341 minecraft:light[level=14]
setblock 434 153 349 minecraft:light[level=14]
setblock 434 153 357 minecraft:light[level=14]
fill 435 153 341 442 154 345 minecraft:light_gray_concrete
fill 436 153 338 444 154 340 minecraft:light_gray_concrete
fill 436 153 346 444 154 348 minecraft:light_gray_concrete
fill 437 153 337 455 156 337 minecraft:light_gray_concrete
fill 437 153 349 455 156 349 minecraft:light_gray_concrete
fill 438 153 336 454 156 336 minecraft:light_gray_concrete
fill 438 153 350 454 156 350 minecraft:light_gray_concrete
fill 439 153 335 453 156 335 minecraft:light_gray_concrete
fill 439 153 351 453 156 351 minecraft:light_gray_concrete
fill 440 153 334 452 156 334 minecraft:light_gray_concrete
fill 440 153 352 452 156 352 minecraft:light_gray_concrete
fill 441 153 333 451 156 333 minecraft:light_gray_concrete
fill 441 153 353 451 156 353 minecraft:light_gray_concrete
setblock 442 153 325 minecraft:light[level=14]
setblock 442 153 357 minecraft:light[level=14]
fill 443 153 341 443 154 341 minecraft:light_gray_concrete
fill 443 153 345 443 154 345 minecraft:light_gray_concrete
fill 444 153 332 448 156 332 minecraft:light_gray_concrete
fill 444 153 354 448 156 354 minecraft:light_gray_concrete
fill 445 153 338 456 154 339 minecraft:light_gray_concrete
fill 445 153 347 456 154 348 minecraft:light_gray_concrete
fill 448 153 340 456 154 340 minecraft:light_gray_concrete
fill 448 153 346 456 154 346 minecraft:light_gray_concrete
fill 449 153 341 457 154 341 minecraft:light_gray_concrete
fill 449 153 345 457 154 345 minecraft:light_gray_concrete
setblock 450 153 325 minecraft:light[level=14]
fill 450 153 342 457 154 344 minecraft:light_gray_concrete
setblock 450 153 357 minecraft:light[level=14]
setblock 458 153 325 minecraft:light[level=14]
setblock 458 153 333 minecraft:light[level=14]
setblock 458 153 341 minecraft:light[level=14]
setblock 458 153 349 minecraft:light[level=14]
setblock 458 153 357 minecraft:light[level=14]
fill 433 154 339 433 155 347 minecraft:sea_lantern
fill 434 154 337 434 155 340 minecraft:sea_lantern
fill 434 154 341 434 155 345 minecraft:light_gray_concrete
fill 434 154 346 434 155 349 minecraft:sea_lantern
fill 435 154 335 435 155 337 minecraft:sea_lantern
fill 435 154 338 435 155 340 minecraft:light_gray_concrete
fill 435 154 346 435 155 348 minecraft:light_gray_concrete
fill 435 154 349 435 155 351 minecraft:sea_lantern
fill 436 154 334 436 155 335 minecraft:sea_lantern
fill 436 154 336 436 155 337 minecraft:light_gray_concrete
fill 436 154 349 436 155 350 minecraft:light_gray_concrete
fill 436 154 351 436 155 352 minecraft:sea_lantern
fill 437 154 333 437 155 334 minecraft:sea_lantern
fill 437 154 335 437 155 336 minecraft:light_gray_concrete
fill 437 154 350 437 155 351 minecraft:light_gray_concrete
fill 437 154 352 437 155 353 minecraft:sea_lantern
fill 438 154 332 438 155 333 minecraft:sea_lantern
fill 438 154 334 438 155 335 minecraft:light_gray_concrete
fill 438 154 351 438 155 352 minecraft:light_gray_concrete
fill 438 154 353 438 155 354 minecraft:sea_lantern
fill 439 154 332 440 155 332 minecraft:sea_lantern
fill 439 154 333 439 155 334 minecraft:light_gray_concrete
fill 439 154 352 439 155 353 minecraft:light_gray_concrete
fill 439 154 354 440 155 354 minecraft:sea_lantern
fill 440 154 331 443 155 331 minecraft:sea_lantern
fill 440 154 333 440 155 333 minecraft:light_gray_concrete
fill 440 154 353 440 155 353 minecraft:light_gray_concrete
fill 440 154 355 443 155 355 minecraft:sea_lantern
fill 441 154 332 443 155 332 minecraft:light_gray_concrete
fill 441 154 354 443 155 354 minecraft:light_gray_concrete
fill 442 154 330 450 155 330 minecraft:sea_lantern
fill 442 154 356 450 155 356 minecraft:sea_lantern
fill 444 154 331 448 155 331 minecraft:light_gray_concrete
fill 444 154 355 448 155 355 minecraft:light_gray_concrete
fill 449 154 331 452 155 331 minecraft:sea_lantern
fill 449 154 332 451 155 332 minecraft:light_gray_concrete
fill 449 154 354 451 155 354 minecraft:light_gray_concrete
fill 449 154 355 452 155 355 minecraft:sea_lantern
fill 452 154 332 454 155 332 minecraft:sea_lantern
fill 452 154 333 453 155 333 minecraft:light_gray_concrete
fill 452 154 353 453 155 353 minecraft:light_gray_concrete
fill 452 154 354 454 155 354 minecraft:sea_lantern
fill 453 154 334 454 155 334 minecraft:light_gray_concrete
fill 453 154 352 454 155 352 minecraft:light_gray_concrete
fill 454 154 333 455 155 333 minecraft:sea_lantern
fill 454 154 335 455 155 335 minecraft:light_gray_concrete
fill 454 154 351 455 155 351 minecraft:light_gray_concrete
fill 454 154 353 455 155 353 minecraft:sea_lantern
fill 455 154 334 456 155 334 minecraft:sea_lantern
fill 455 154 336 456 155 336 minecraft:light_gray_concrete
fill 455 154 350 456 155 350 minecraft:light_gray_concrete
fill 455 154 352 456 155 352 minecraft:sea_lantern
fill 456 154 335 457 155 335 minecraft:sea_lantern
fill 456 154 337 456 155 337 minecraft:light_gray_concrete
fill 456 154 349 456 155 349 minecraft:light_gray_concrete
fill 456 154 351 457 155 351 minecraft:sea_lantern
fill 457 154 336 457 155 337 minecraft:sea_lantern
fill 457 154 338 457 155 340 minecraft:light_gray_concrete
fill 457 154 346 457 155 348 minecraft:light_gray_concrete
fill 457 154 349 457 155 350 minecraft:sea_lantern
fill 458 154 337 458 155 340 minecraft:sea_lantern
fill 458 154 341 458 155 345 minecraft:light_gray_concrete
fill 458 154 346 458 155 349 minecraft:sea_lantern
fill 459 154 339 459 155 347 minecraft:sea_lantern
fill 424 155 324 424 217 324 minecraft:iron_block
fill 424 155 334 424 217 334 minecraft:iron_block
fill 424 155 344 424 217 344 minecraft:iron_block
fill 424 155 354 427 217 354 minecraft:iron_block
fill 425 155 352 427 217 353 minecraft:iron_block
fill 425 155 363 425 217 363 minecraft:iron_block
fill 431 155 323 431 217 323 minecraft:iron_block
fill 435 155 341 441 155 345 minecraft:light_gray_concrete
fill 435 155 363 435 217 363 minecraft:iron_block
fill 436 155 338 442 155 340 minecraft:light_gray_concrete
fill 436 155 346 442 155 348 minecraft:light_gray_concrete
fill 439 155 358 441 217 360 minecraft:iron_block
fill 441 155 323 441 217 323 minecraft:iron_block
fill 442 155 341 442 157 345 minecraft:light_blue_stained_glass
fill 443 155 338 443 155 339 minecraft:light_gray_concrete
fill 443 155 340 443 155 341 minecraft:light_blue_stained_glass
fill 443 155 345 443 155 346 minecraft:light_blue_stained_glass
fill 443 155 347 443 155 348 minecraft:light_gray_concrete
fill 444 155 338 456 155 338 minecraft:light_gray_concrete
fill 444 155 339 444 155 340 minecraft:light_blue_stained_glass
fill 444 155 346 444 155 347 minecraft:light_blue_stained_glass
fill 444 155 348 456 155 348 minecraft:light_gray_concrete
fill 445 155 325 447 217 327 minecraft:iron_block
fill 445 155 339 448 157 339 minecraft:light_blue_stained_glass
fill 445 155 347 448 157 347 minecraft:light_blue_stained_glass
fill 445 155 363 445 217 363 minecraft:iron_block
fill 447 155 359 449 217 361 minecraft:iron_block
fill 448 155 340 449 155 340 minecraft:light_blue_stained_glass
fill 448 155 346 449 155 346 minecraft:light_blue_stained_glass
fill 449 155 339 456 155 339 minecraft:light_gray_concrete
fill 449 155 341 450 155 341 minecraft:light_blue_stained_glass
fill 449 155 345 450 155 345 minecraft:light_blue_stained_glass
fill 449 155 347 456 155 347 minecraft:light_gray_concrete
fill 450 155 340 456 155 340 minecraft:light_gray_concrete
fill 450 155 342 450 157 344 minecraft:light_blue_stained_glass
fill 450 155 346 456 155 346 minecraft:light_gray_concrete
fill 451 155 323 451 217 323 minecraft:iron_block
fill 451 155 341 457 155 345 minecraft:light_gray_concrete
fill 455 155 363 455 217 363 minecraft:iron_block
fill 461 155 323 461 217 323 minecraft:iron_block
fill 464 155 330 464 217 330 minecraft:iron_block
fill 464 155 340 464 217 340 minecraft:iron_block
fill 464 155 350 464 217 350 minecraft:iron_block
fill 464 155 360 464 217 360 minecraft:iron_block
setblock 424 156 325 minecraft:light_gray_concrete
setblock 424 156 335 minecraft:light_gray_concrete
setblock 424 156 345 minecraft:light_gray_concrete
setblock 424 156 355 minecraft:light_gray_concrete
setblock 426 156 363 minecraft:light_gray_concrete
setblock 430 156 323 minecraft:light_gray_concrete
fill 435 156 341 440 156 345 minecraft:light_gray_concrete
fill 436 156 338 441 156 340 minecraft:light_gray_concrete
fill 436 156 346 441 156 348 minecraft:light_gray_concrete
setblock 436 156 363 minecraft:light_gray_concrete
setblock 440 156 323 minecraft:light_gray_concrete
fill 441 156 341 441 158 345 minecraft:light_blue_stained_glass
fill 442 156 338 443 156 338 minecraft:light_gray_concrete
fill 442 156 339 443 158 340 minecraft:light_blue_stained_glass
fill 442 156 346 443 158 347 minecraft:light_blue_stained_glass
fill 442 156 348 443 156 348 minecraft:light_gray_concrete
fill 444 156 338 444 158 339 minecraft:light_blue_stained_glass
fill 444 156 347 444 158 348 minecraft:light_blue_stained_glass
fill 445 156 338 448 158 338 minecraft:light_blue_stained_glass
fill 445 156 348 448 158 348 minecraft:light_blue_stained_glass
setblock 446 156 363 minecraft:light_gray_concrete
fill 449 156 338 456 156 338 minecraft:light_gray_concrete
fill 449 156 339 450 158 340 minecraft:light_blue_stained_glass
fill 449 156 346 450 158 347 minecraft:light_blue_stained_glass
fill 449 156 348 456 156 348 minecraft:light_gray_concrete
setblock 450 156 323 minecraft:light_gray_concrete
fill 450 156 341 451 158 341 minecraft:light_blue_stained_glass
fill 450 156 345 451 158 345 minecraft:light_blue_stained_glass
fill 451 156 339 456 156 340 minecraft:light_gray_concrete
fill 451 156 342 451 158 344 minecraft:light_blue_stained_glass
fill 451 156 346 456 156 347 minecraft:light_gray_concrete
fill 452 156 341 457 156 345 minecraft:light_gray_concrete
setblock 456 156 363 minecraft:light_gray_concrete
setblock 460 156 323 minecraft:light_gray_concrete
setblock 464 156 329 minecraft:light_gray_concrete
setblock 464 156 339 minecraft:light_gray_concrete
setblock 464 156 349 minecraft:light_gray_concrete
setblock 464 156 359 minecraft:light_gray_concrete
fill 423 157 328 423 157 331 minecraft:verdant_froglight
fill 423 157 338 423 157 341 minecraft:verdant_froglight
fill 423 157 348 423 157 351 minecraft:verdant_froglight
fill 423 157 358 423 157 361 minecraft:verdant_froglight
fill 424 157 352 424 157 353 minecraft:light_gray_concrete
fill 425 157 351 427 157 351 minecraft:light_gray_concrete
fill 425 157 355 427 157 355 minecraft:light_gray_concrete
fill 426 157 322 429 157 322 minecraft:verdant_froglight
fill 427 157 364 430 157 364 minecraft:verdant_froglight
fill 428 157 352 428 157 354 minecraft:light_gray_concrete
fill 436 157 322 439 157 322 minecraft:verdant_froglight
fill 437 157 364 440 157 364 minecraft:verdant_froglight
fill 438 157 358 438 157 360 minecraft:light_gray_concrete
fill 439 157 357 441 157 357 minecraft:light_gray_concrete
fill 439 157 361 441 157 361 minecraft:light_gray_concrete
setblock 440 157 343 minecraft:light_blue_stained_glass
setblock 441 157 340 minecraft:light_blue_stained_glass
setblock 441 157 346 minecraft:light_blue_stained_glass
fill 442 157 358 442 157 360 minecraft:light_gray_concrete
setblock 443 157 338 minecraft:light_blue_stained_glass
setblock 443 157 348 minecraft:light_blue_stained_glass
fill 444 157 325 444 157 327 minecraft:light_gray_concrete
fill 445 157 324 447 157 324 minecraft:light_gray_concrete
fill 445 157 328 447 157 328 minecraft:light_gray_concrete
fill 446 157 322 449 157 322 minecraft:verdant_froglight
setblock 446 157 337 minecraft:light_blue_stained_glass
setblock 446 157 349 minecraft:light_blue_stained_glass
fill 446 157 359 446 157 361 minecraft:light_gray_concrete
fill 447 157 358 449 157 358 minecraft:light_gray_concrete
fill 447 157 362 449 157 362 minecraft:light_gray_concrete
fill 447 157 364 450 157 364 minecraft:verdant_froglight
fill 448 157 325 448 157 327 minecraft:light_gray_concrete
setblock 449 157 338 minecraft:light_blue_stained_glass
setblock 449 157 348 minecraft:light_blue_stained_glass
fill 450 157 359 450 157 361 minecraft:light_gray_concrete
setblock 451 157 340 minecraft:light_blue_stained_glass
setblock 451 157 346 minecraft:light_blue_stained_glass
setblock 452 157 343 minecraft:light_blue_stained_glass
fill 456 157 322 459 157 322 minecraft:verdant_froglight
fill 457 157 364 460 157 364 minecraft:verdant_froglight
fill 465 157 323 465 157 326 minecraft:verdant_froglight
fill 465 157 333 465 157 336 minecraft:verdant_froglight
fill 465 157 343 465 157 346 minecraft:verdant_froglight
fill 465 157 353 465 157 356 minecraft:verdant_froglight
setblock 465 157 363 minecraft:verdant_froglight
fill 423 158 328 423 165 331 minecraft:light_gray_concrete
fill 423 158 338 423 165 341 minecraft:light_gray_concrete
fill 423 158 348 423 165 351 minecraft:light_gray_concrete
fill 423 158 358 423 165 361 minecraft:light_gray_concrete
fill 426 158 322 429 165 322 minecraft:light_gray_concrete
fill 427 158 364 430 165 364 minecraft:light_gray_concrete
fill 436 158 322 439 165 322 minecraft:light_gray_concrete
fill 437 158 364 440 165 364 minecraft:light_gray_concrete
fill 442 158 341 442 159 341 minecraft:light_blue_stained_glass
fill 442 158 345 442 159 345 minecraft:light_blue_stained_glass
fill 446 158 322 449 165 322 minecraft:light_gray_concrete
fill 447 158 364 450 165 364 minecraft:light_gray_concrete
fill 448 158 339 448 159 339 minecraft:light_blue_stained_glass
fill 448 158 347 448 159 347 minecraft:light_blue_stained_glass
fill 456 158 322 459 165 322 minecraft:light_gray_concrete
fill 457 158 364 460 165 364 minecraft:light_gray_concrete
fill 465 158 323 465 165 326 minecraft:light_gray_concrete
fill 465 158 333 465 165 336 minecraft:light_gray_concrete
fill 465 158 343 465 165 346 minecraft:light_gray_concrete
fill 465 158 353 465 165 356 minecraft:light_gray_concrete
fill 465 158 363 465 165 363 minecraft:light_gray_concrete
setblock 444 159 339 minecraft:light_blue_stained_glass
setblock 444 159 347 minecraft:light_blue_stained_glass
setblock 450 159 341 minecraft:light_blue_stained_glass
setblock 450 159 345 minecraft:light_blue_stained_glass
setblock 426 161 325 minecraft:light[level=14]
setblock 426 161 333 minecraft:light[level=14]
setblock 426 161 341 minecraft:light[level=14]
setblock 426 161 349 minecraft:light[level=14]
setblock 426 161 357 minecraft:light[level=14]
setblock 434 161 325 minecraft:light[level=14]
setblock 434 161 333 minecraft:light[level=14]
setblock 434 161 341 minecraft:light[level=14]
setblock 434 161 349 minecraft:light[level=14]
setblock 434 161 357 minecraft:light[level=14]
setblock 442 161 325 minecraft:light[level=14]
setblock 442 161 333 minecraft:light[level=14]
setblock 442 161 349 minecraft:light[level=14]
setblock 442 161 357 minecraft:light[level=14]
setblock 450 161 325 minecraft:light[level=14]
setblock 450 161 333 minecraft:light[level=14]
setblock 450 161 349 minecraft:light[level=14]
setblock 450 161 357 minecraft:light[level=14]
setblock 458 161 325 minecraft:light[level=14]
setblock 458 161 333 minecraft:light[level=14]
setblock 458 161 341 minecraft:light[level=14]
setblock 458 161 349 minecraft:light[level=14]
setblock 458 161 357 minecraft:light[level=14]
setblock 424 162 325 minecraft:light_gray_concrete
fill 424 162 327 424 162 330 minecraft:light_gray_concrete
fill 424 162 335 427 163 335 minecraft:light_gray_concrete
fill 424 162 337 424 162 341 minecraft:light_gray_concrete
setblock 424 162 345 minecraft:light_gray_concrete
fill 424 162 347 424 162 350 minecraft:light_gray_concrete
fill 424 162 353 424 164 353 minecraft:light_gray_concrete
setblock 424 162 355 minecraft:light_gray_concrete
fill 424 162 357 424 162 360 minecraft:light_gray_concrete
fill 425 162 323 428 162 323 minecraft:light_gray_concrete
fill 425 162 329 426 163 329 minecraft:light_gray_concrete
fill 425 162 341 441 163 341 minecraft:light_gray_concrete
fill 425 162 347 426 163 347 minecraft:light_gray_concrete
fill 425 162 359 428 163 359 minecraft:light_gray_concrete
setblock 426 162 363 minecraft:light_gray_concrete
fill 428 162 363 431 162 363 minecraft:light_gray_concrete
setblock 430 162 323 minecraft:light_gray_concrete
fill 435 162 323 438 162 323 minecraft:light_gray_concrete
setblock 436 162 363 minecraft:light_gray_concrete
fill 438 162 363 441 162 363 minecraft:light_gray_concrete
setblock 440 162 323 minecraft:light_gray_concrete
fill 444 162 325 444 162 327 minecraft:light_gray_concrete
fill 445 162 323 447 162 324 minecraft:light_gray_concrete
fill 445 162 328 447 162 328 minecraft:light_gray_concrete
setblock 446 162 363 minecraft:light_gray_concrete
setblock 448 162 323 minecraft:light_gray_concrete
fill 448 162 325 448 162 327 minecraft:light_gray_concrete
fill 448 162 363 451 162 363 minecraft:light_gray_concrete
setblock 450 162 323 minecraft:light_gray_concrete
fill 451 162 341 463 162 341 minecraft:light_gray_concrete
fill 455 162 323 458 162 323 minecraft:light_gray_concrete
setblock 456 162 363 minecraft:light_gray_concrete
fill 458 162 363 461 162 363 minecraft:light_gray_concrete
setblock 460 162 323 minecraft:light_gray_concrete
fill 464 162 324 464 162 327 minecraft:light_gray_concrete
setblock 464 162 329 minecraft:light_gray_concrete
fill 464 162 334 464 162 337 minecraft:light_gray_concrete
setblock 464 162 339 minecraft:light_gray_concrete
fill 464 162 344 464 162 347 minecraft:light_gray_concrete
setblock 464 162 349 minecraft:light_gray_concrete
fill 464 162 354 464 162 357 minecraft:light_gray_concrete
fill 464 162 359 464 163 359 minecraft:light_gray_concrete
setblock 424 163 329 minecraft:light_gray_concrete
setblock 424 163 341 minecraft:light_gray_concrete
setblock 424 163 347 minecraft:light_gray_concrete
setblock 424 163 359 minecraft:light_gray_concrete
fill 427 163 329 458 163 329 minecraft:light_gray_concrete
fill 427 163 347 442 163 347 minecraft:light_gray_concrete
fill 428 163 335 463 163 335 minecraft:light_gray_concrete
fill 428 163 353 435 163 353 minecraft:light_gray_concrete
fill 429 163 359 435 163 359 minecraft:light_gray_concrete
fill 436 163 350 436 163 363 minecraft:iron_block
fill 437 163 353 457 163 353 minecraft:light_gray_concrete
fill 437 163 359 438 163 359 minecraft:light_gray_concrete
fill 442 163 341 458 163 341 minecraft:light_gray_concrete
fill 442 163 359 446 163 359 minecraft:light_gray_concrete
fill 448 163 347 455 163 347 minecraft:light_gray_concrete
fill 450 163 359 463 163 359 minecraft:light_gray_concrete
setblock 424 164 352 minecraft:light_gray_concrete
fill 425 164 351 427 164 351 minecraft:light_gray_concrete
fill 425 164 355 427 164 355 minecraft:light_gray_concrete
fill 428 164 352 428 164 354 minecraft:light_gray_concrete
fill 430 164 323 430 165 329 minecraft:iron_block
fill 436 164 323 436 164 355 minecraft:iron_block
fill 438 164 358 438 164 360 minecraft:light_gray_concrete
fill 439 164 357 441 164 357 minecraft:light_gray_concrete
fill 439 164 361 441 164 361 minecraft:light_gray_concrete
fill 442 164 323 442 165 329 minecraft:iron_block
fill 442 164 358 442 164 360 minecraft:light_gray_concrete
fill 448 164 323 448 164 343 minecraft:iron_block
fill 448 164 347 448 164 358 minecraft:iron_block
fill 448 164 362 448 164 363 minecraft:iron_block
fill 450 164 347 464 164 347 minecraft:light_gray_concrete
fill 452 164 353 453 164 353 minecraft:light_gray_concrete
fill 453 164 329 464 164 329 minecraft:light_gray_concrete
fill 454 164 323 454 165 328 minecraft:iron_block
fill 454 164 330 454 165 346 minecraft:iron_block
fill 454 164 348 454 165 362 minecraft:iron_block
fill 455 164 353 464 164 353 minecraft:light_gray_concrete
fill 456 164 335 463 164 335 minecraft:light_gray_concrete
fill 460 164 323 460 165 325 minecraft:iron_block
fill 424 165 352 424 166 353 minecraft:iron_block
fill 430 165 330 430 165 363 minecraft:iron_block
fill 436 165 323 436 165 325 minecraft:iron_block
fill 442 165 330 442 165 343 minecraft:iron_block
fill 442 165 346 442 165 363 minecraft:iron_block
fill 446 165 331 447 166 332 minecraft:lime_concrete
fill 446 165 359 446 165 361 minecraft:light_gray_concrete
fill 447 165 358 449 165 358 minecraft:light_gray_concrete
fill 447 165 362 449 165 362 minecraft:light_gray_concrete
fill 448 165 323 448 165 341 minecraft:iron_block
fill 450 165 359 450 165 361 minecraft:light_gray_concrete
setblock 454 165 329 minecraft:iron_block
setblock 454 165 347 minecraft:iron_block
fill 460 165 326 460 165 353 minecraft:iron_block
fill 423 166 328 423 166 331 minecraft:verdant_froglight
fill 423 166 338 423 166 341 minecraft:verdant_froglight
fill 423 166 348 423 166 351 minecraft:verdant_froglight
fill 423 166 358 423 166 361 minecraft:verdant_froglight
fill 426 166 322 429 166 322 minecraft:verdant_froglight
fill 427 166 364 430 166 364 minecraft:verdant_froglight
setblock 428 166 353 minecraft:verdant_froglight
fill 436 166 322 439 166 322 minecraft:verdant_froglight
fill 437 166 364 440 166 364 minecraft:verdant_froglight
fill 446 166 322 449 166 322 minecraft:verdant_froglight
fill 447 166 364 450 166 364 minecraft:verdant_froglight
fill 456 166 322 459 166 322 minecraft:verdant_froglight
fill 457 166 364 460 166 364 minecraft:verdant_froglight
fill 460 166 348 460 166 363 minecraft:iron_block
fill 465 166 323 465 166 326 minecraft:verdant_froglight
fill 465 166 333 465 166 336 minecraft:verdant_froglight
fill 465 166 343 465 166 346 minecraft:verdant_froglight
fill 465 166 353 465 166 356 minecraft:verdant_froglight
setblock 465 166 363 minecraft:verdant_froglight
fill 423 167 328 423 174 331 minecraft:light_gray_concrete
fill 423 167 338 423 174 341 minecraft:light_gray_concrete
fill 423 167 348 423 174 351 minecraft:light_gray_concrete
fill 423 167 358 423 174 361 minecraft:light_gray_concrete
fill 426 167 322 429 174 322 minecraft:light_gray_concrete
fill 427 167 364 430 174 364 minecraft:light_gray_concrete
fill 436 167 322 439 174 322 minecraft:light_gray_concrete
fill 437 167 364 440 174 364 minecraft:light_gray_concrete
fill 444 167 325 444 167 327 minecraft:light_gray_concrete
fill 445 167 324 447 167 324 minecraft:light_gray_concrete
fill 445 167 328 447 167 328 minecraft:light_gray_concrete
fill 446 167 322 449 174 322 minecraft:light_gray_concrete
fill 447 167 364 450 174 364 minecraft:light_gray_concrete
fill 448 167 325 448 167 327 minecraft:light_gray_concrete
fill 456 167 322 459 174 322 minecraft:light_gray_concrete
fill 457 167 364 460 174 364 minecraft:light_gray_concrete
fill 465 167 323 465 174 326 minecraft:light_gray_concrete
fill 465 167 333 465 174 336 minecraft:light_gray_concrete
fill 465 167 343 465 174 346 minecraft:light_gray_concrete
fill 465 167 353 465 174 356 minecraft:light_gray_concrete
fill 465 167 363 465 174 363 minecraft:light_gray_concrete
setblock 424 168 325 minecraft:light_gray_concrete
setblock 424 168 335 minecraft:light_gray_concrete
setblock 424 168 345 minecraft:light_gray_concrete
setblock 424 168 355 minecraft:light_gray_concrete
setblock 426 168 363 minecraft:light_gray_concrete
setblock 430 168 323 minecraft:light_gray_concrete
setblock 436 168 363 minecraft:light_gray_concrete
setblock 440 168 323 minecraft:light_gray_concrete
setblock 446 168 363 minecraft:light_gray_concrete
setblock 450 168 323 minecraft:light_gray_concrete
setblock 456 168 363 minecraft:light_gray_concrete
setblock 460 168 323 minecraft:light_gray_concrete
setblock 464 168 329 minecraft:light_gray_concrete
setblock 464 168 339 minecraft:light_gray_concrete
setblock 464 168 349 minecraft:light_gray_concrete
setblock 464 168 359 minecraft:light_gray_concrete
setblock 426 169 325 minecraft:light[level=14]
setblock 426 169 333 minecraft:light[level=14]
setblock 426 169 341 minecraft:light[level=14]
setblock 426 169 349 minecraft:light[level=14]
setblock 426 169 357 minecraft:light[level=14]
setblock 434 169 325 minecraft:light[level=14]
setblock 434 169 333 minecraft:light[level=14]
setblock 434 169 341 minecraft:light[level=14]
setblock 434 169 349 minecraft:light[level=14]
setblock 434 169 357 minecraft:light[level=14]
setblock 442 169 325 minecraft:light[level=14]
setblock 442 169 333 minecraft:light[level=14]
setblock 442 169 341 minecraft:light[level=14]
setblock 442 169 349 minecraft:light[level=14]
setblock 442 169 357 minecraft:light[level=14]
fill 447 169 362 449 170 363 minecraft:iron_block
setblock 450 169 325 minecraft:light[level=14]
setblock 450 169 333 minecraft:light[level=14]
setblock 450 169 341 minecraft:light[level=14]
setblock 450 169 349 minecraft:light[level=14]
setblock 450 169 357 minecraft:light[level=14]
setblock 458 169 325 minecraft:light[level=14]
setblock 458 169 333 minecraft:light[level=14]
setblock 458 169 341 minecraft:light[level=14]
setblock 458 169 349 minecraft:light[level=14]
setblock 458 169 357 minecraft:light[level=14]
fill 441 170 351 442 171 351 minecraft:lime_concrete
setblock 448 170 358 minecraft:verdant_froglight
fill 424 171 327 424 171 330 minecraft:light_gray_concrete
fill 424 171 337 424 171 340 minecraft:light_gray_concrete
fill 424 171 347 424 171 350 minecraft:light_gray_concrete
fill 424 171 352 424 171 353 minecraft:light_gray_concrete
fill 424 171 357 424 171 360 minecraft:light_gray_concrete
fill 425 171 323 428 171 323 minecraft:light_gray_concrete
fill 425 171 351 427 171 351 minecraft:light_gray_concrete
fill 425 171 355 427 171 355 minecraft:light_gray_concrete
fill 428 171 352 428 171 354 minecraft:light_gray_concrete
fill 428 171 363 431 171 363 minecraft:light_gray_concrete
fill 435 171 323 438 171 323 minecraft:light_gray_concrete
fill 438 171 358 438 171 360 minecraft:light_gray_concrete
fill 438 171 363 441 171 363 minecraft:light_gray_concrete
fill 439 171 357 441 171 357 minecraft:light_gray_concrete
fill 439 171 361 441 171 361 minecraft:light_gray_concrete
fill 442 171 358 442 171 360 minecraft:light_gray_concrete
fill 445 171 323 448 171 323 minecraft:light_gray_concrete
fill 448 171 363 451 171 363 minecraft:light_gray_concrete
fill 455 171 323 458 171 323 minecraft:light_gray_concrete
fill 458 171 363 461 171 363 minecraft:light_gray_concrete
fill 464 171 324 464 171 327 minecraft:light_gray_concrete
fill 464 171 334 464 171 337 minecraft:light_gray_concrete
fill 464 171 344 464 171 347 minecraft:light_gray_concrete
fill 464 171 354 464 171 357 minecraft:light_gray_concrete
fill 444 172 325 444 172 327 minecraft:light_gray_concrete
fill 445 172 324 447 172 324 minecraft:light_gray_concrete
fill 445 172 328 447 172 328 minecraft:light_gray_concrete
fill 448 172 325 448 172 327 minecraft:light_gray_concrete
fill 446 173 359 446 173 361 minecraft:light_gray_concrete
fill 447 173 358 449 173 358 minecraft:light_gray_concrete
fill 447 173 362 449 173 362 minecraft:light_gray_concrete
fill 450 173 359 450 173 361 minecraft:light_gray_concrete
setblock 424 174 325 minecraft:light_gray_concrete
setblock 424 174 335 minecraft:light_gray_concrete
setblock 424 174 345 minecraft:light_gray_concrete
setblock 424 174 355 minecraft:light_gray_concrete
setblock 426 174 363 minecraft:light_gray_concrete
setblock 430 174 323 minecraft:light_gray_concrete
setblock 436 174 363 minecraft:light_gray_concrete
setblock 440 174 323 minecraft:light_gray_concrete
setblock 446 174 363 minecraft:light_gray_concrete
setblock 450 174 323 minecraft:light_gray_concrete
setblock 456 174 363 minecraft:light_gray_concrete
setblock 460 174 323 minecraft:light_gray_concrete
setblock 464 174 329 minecraft:light_gray_concrete
setblock 464 174 339 minecraft:light_gray_concrete
setblock 464 174 349 minecraft:light_gray_concrete
setblock 464 174 359 minecraft:light_gray_concrete
fill 423 175 328 423 175 331 minecraft:verdant_froglight
fill 423 175 338 423 175 341 minecraft:verdant_froglight
fill 423 175 348 423 175 351 minecraft:verdant_froglight
fill 423 175 358 423 175 361 minecraft:verdant_froglight
fill 426 175 322 429 175 322 minecraft:verdant_froglight
fill 427 175 364 430 175 364 minecraft:verdant_froglight
fill 436 175 322 439 175 322 minecraft:verdant_froglight
fill 437 175 364 440 175 364 minecraft:verdant_froglight
fill 446 175 322 449 175 322 minecraft:verdant_froglight
fill 447 175 364 450 175 364 minecraft:verdant_froglight
fill 456 175 322 459 175 322 minecraft:verdant_froglight
fill 457 175 364 460 175 364 minecraft:verdant_froglight
fill 465 175 323 465 175 326 minecraft:verdant_froglight
fill 465 175 333 465 175 336 minecraft:verdant_froglight
fill 465 175 343 465 175 346 minecraft:verdant_froglight
fill 465 175 353 465 175 356 minecraft:verdant_froglight
setblock 465 175 363 minecraft:verdant_froglight
fill 423 176 328 423 183 331 minecraft:light_gray_concrete
fill 423 176 338 423 183 341 minecraft:light_gray_concrete
fill 423 176 348 423 183 351 minecraft:light_gray_concrete
fill 423 176 358 423 183 361 minecraft:light_gray_concrete
fill 426 176 322 429 183 322 minecraft:light_gray_concrete
fill 427 176 364 430 183 364 minecraft:light_gray_concrete
fill 436 176 322 439 183 322 minecraft:light_gray_concrete
fill 437 176 364 440 183 364 minecraft:light_gray_concrete
fill 446 176 322 449 183 322 minecraft:light_gray_concrete
fill 447 176 364 450 183 364 minecraft:light_gray_concrete
fill 456 176 322 459 183 322 minecraft:light_gray_concrete
fill 457 176 364 460 183 364 minecraft:light_gray_concrete
fill 465 176 323 465 183 326 minecraft:light_gray_concrete
fill 465 176 333 465 183 336 minecraft:light_gray_concrete
fill 465 176 343 465 183 346 minecraft:light_gray_concrete
fill 465 176 353 465 183 356 minecraft:light_gray_concrete
fill 465 176 363 465 183 363 minecraft:light_gray_concrete
setblock 426 177 325 minecraft:light[level=14]
setblock 426 177 333 minecraft:light[level=14]
setblock 426 177 341 minecraft:light[level=14]
setblock 426 177 349 minecraft:light[level=14]
setblock 426 177 357 minecraft:light[level=14]
setblock 434 177 325 minecraft:light[level=14]
setblock 434 177 333 minecraft:light[level=14]
setblock 434 177 341 minecraft:light[level=14]
setblock 434 177 349 minecraft:light[level=14]
setblock 434 177 357 minecraft:light[level=14]
setblock 442 177 325 minecraft:light[level=14]
setblock 442 177 333 minecraft:light[level=14]
setblock 442 177 341 minecraft:light[level=14]
setblock 442 177 349 minecraft:light[level=14]
setblock 442 177 357 minecraft:light[level=14]
fill 444 177 325 444 177 327 minecraft:light_gray_concrete
fill 445 177 324 447 177 324 minecraft:light_gray_concrete
fill 445 177 328 447 177 328 minecraft:light_gray_concrete
fill 448 177 325 448 177 327 minecraft:light_gray_concrete
setblock 450 177 325 minecraft:light[level=14]
setblock 450 177 333 minecraft:light[level=14]
setblock 450 177 341 minecraft:light[level=14]
setblock 450 177 349 minecraft:light[level=14]
setblock 450 177 357 minecraft:light[level=14]
setblock 458 177 325 minecraft:light[level=14]
setblock 458 177 333 minecraft:light[level=14]
setblock 458 177 341 minecraft:light[level=14]
setblock 458 177 349 minecraft:light[level=14]
setblock 458 177 357 minecraft:light[level=14]
fill 424 178 352 424 178 353 minecraft:light_gray_concrete
fill 425 178 351 427 178 351 minecraft:light_gray_concrete
fill 425 178 355 427 178 355 minecraft:light_gray_concrete
fill 428 178 352 428 178 354 minecraft:light_gray_concrete
fill 438 178 358 438 178 360 minecraft:light_gray_concrete
fill 439 178 357 441 178 357 minecraft:light_gray_concrete
fill 439 178 361 441 178 361 minecraft:light_gray_concrete
fill 442 178 358 442 178 360 minecraft:light_gray_concrete
setblock 424 180 325 minecraft:light_gray_concrete
fill 424 180 327 424 180 330 minecraft:light_gray_concrete
setblock 424 180 335 minecraft:light_gray_concrete
fill 424 180 337 424 180 340 minecraft:light_gray_concrete
setblock 424 180 345 minecraft:light_gray_concrete
fill 424 180 347 424 180 350 minecraft:light_gray_concrete
setblock 424 180 355 minecraft:light_gray_concrete
fill 424 180 357 424 180 360 minecraft:light_gray_concrete
fill 425 180 323 428 180 323 minecraft:light_gray_concrete
setblock 426 180 363 minecraft:light_gray_concrete
fill 428 180 363 431 180 363 minecraft:light_gray_concrete
setblock 430 180 323 minecraft:light_gray_concrete
fill 435 180 323 438 180 323 minecraft:light_gray_concrete
setblock 436 180 363 minecraft:light_gray_concrete
fill 438 180 363 441 180 363 minecraft:light_gray_concrete
setblock 440 180 323 minecraft:light_gray_concrete
fill 445 180 323 448 180 323 minecraft:light_gray_concrete
setblock 446 180 363 minecraft:light_gray_concrete
fill 448 180 363 451 180 363 minecraft:light_gray_concrete
setblock 450 180 323 minecraft:light_gray_concrete
fill 455 180 323 458 180 323 minecraft:light_gray_concrete
setblock 456 180 363 minecraft:light_gray_concrete
fill 458 180 363 461 180 363 minecraft:light_gray_concrete
setblock 460 180 323 minecraft:light_gray_concrete
fill 464 180 324 464 180 327 minecraft:light_gray_concrete
setblock 464 180 329 minecraft:light_gray_concrete
fill 464 180 334 464 180 337 minecraft:light_gray_concrete
setblock 464 180 339 minecraft:light_gray_concrete
fill 464 180 344 464 180 347 minecraft:light_gray_concrete
setblock 464 180 349 minecraft:light_gray_concrete
fill 464 180 354 464 180 357 minecraft:light_gray_concrete
setblock 464 180 359 minecraft:light_gray_concrete
fill 443 181 328 443 182 329 minecraft:lime_stained_glass
fill 444 181 329 444 182 329 minecraft:lime_stained_glass
fill 445 181 323 447 181 324 minecraft:iron_block
fill 446 181 359 446 181 361 minecraft:light_gray_concrete
fill 447 181 358 449 181 358 minecraft:light_gray_concrete
fill 447 181 362 449 181 362 minecraft:light_gray_concrete
fill 450 181 359 450 181 361 minecraft:light_gray_concrete
fill 458 181 347 462 181 349 minecraft:iron_block
fill 459 181 346 461 181 346 minecraft:iron_block
fill 459 181 350 461 181 350 minecraft:iron_block
fill 444 182 325 444 182 327 minecraft:light_gray_concrete
fill 445 182 323 447 182 323 minecraft:iron_block
fill 445 182 324 447 182 324 minecraft:light_gray_concrete
fill 445 182 328 447 182 328 minecraft:light_gray_concrete
fill 448 182 325 448 182 327 minecraft:light_gray_concrete
fill 458 182 347 462 189 349 minecraft:glass
fill 459 182 346 461 189 346 minecraft:glass
fill 459 182 350 461 189 350 minecraft:glass
fill 423 184 328 423 184 331 minecraft:verdant_froglight
fill 423 184 338 423 184 341 minecraft:verdant_froglight
fill 423 184 348 423 184 351 minecraft:verdant_froglight
fill 423 184 358 423 184 361 minecraft:verdant_froglight
fill 426 184 322 429 184 322 minecraft:verdant_froglight
fill 427 184 364 430 184 364 minecraft:verdant_froglight
fill 436 184 322 439 184 322 minecraft:verdant_froglight
fill 437 184 364 440 184 364 minecraft:verdant_froglight
fill 446 184 322 449 184 322 minecraft:verdant_froglight
fill 447 184 364 450 184 364 minecraft:verdant_froglight
fill 456 184 322 459 184 322 minecraft:verdant_froglight
fill 457 184 364 460 184 364 minecraft:verdant_froglight
fill 465 184 323 465 184 326 minecraft:verdant_froglight
fill 465 184 333 465 184 336 minecraft:verdant_froglight
fill 465 184 343 465 184 346 minecraft:verdant_froglight
fill 465 184 353 465 184 356 minecraft:verdant_froglight
setblock 465 184 363 minecraft:verdant_froglight
fill 423 185 328 423 192 331 minecraft:light_gray_concrete
fill 423 185 338 423 192 341 minecraft:light_gray_concrete
fill 423 185 348 423 192 351 minecraft:light_gray_concrete
fill 423 185 358 423 192 361 minecraft:light_gray_concrete
fill 424 185 352 424 185 353 minecraft:light_gray_concrete
fill 425 185 351 427 185 351 minecraft:light_gray_concrete
fill 425 185 355 427 185 355 minecraft:light_gray_concrete
fill 426 185 322 429 192 322 minecraft:light_gray_concrete
setblock 426 185 325 minecraft:light[level=14]
setblock 426 185 333 minecraft:light[level=14]
setblock 426 185 341 minecraft:light[level=14]
setblock 426 185 349 minecraft:light[level=14]
setblock 426 185 357 minecraft:light[level=14]
fill 427 185 364 430 192 364 minecraft:light_gray_concrete
fill 428 185 352 428 185 354 minecraft:light_gray_concrete
setblock 434 185 325 minecraft:light[level=14]
setblock 434 185 333 minecraft:light[level=14]
setblock 434 185 341 minecraft:light[level=14]
setblock 434 185 349 minecraft:light[level=14]
setblock 434 185 357 minecraft:light[level=14]
fill 436 185 322 439 192 322 minecraft:light_gray_concrete
fill 437 185 364 440 192 364 minecraft:light_gray_concrete
fill 438 185 358 438 185 360 minecraft:light_gray_concrete
fill 439 185 357 441 185 357 minecraft:light_gray_concrete
fill 439 185 361 441 185 361 minecraft:light_gray_concrete
setblock 442 185 325 minecraft:light[level=14]
setblock 442 185 333 minecraft:light[level=14]
setblock 442 185 341 minecraft:light[level=14]
setblock 442 185 349 minecraft:light[level=14]
setblock 442 185 357 minecraft:light[level=14]
fill 442 185 358 442 185 360 minecraft:light_gray_concrete
fill 446 185 322 449 192 322 minecraft:light_gray_concrete
fill 447 185 364 450 192 364 minecraft:light_gray_concrete
setblock 450 185 325 minecraft:light[level=14]
setblock 450 185 333 minecraft:light[level=14]
setblock 450 185 341 minecraft:light[level=14]
setblock 450 185 349 minecraft:light[level=14]
setblock 450 185 357 minecraft:light[level=14]
fill 453 185 348 454 186 348 minecraft:lime_concrete
fill 456 185 322 459 192 322 minecraft:light_gray_concrete
fill 457 185 364 460 192 364 minecraft:light_gray_concrete
setblock 458 185 325 minecraft:light[level=14]
setblock 458 185 333 minecraft:light[level=14]
setblock 458 185 341 minecraft:light[level=14]
setblock 458 185 357 minecraft:light[level=14]
fill 465 185 323 465 192 326 minecraft:light_gray_concrete
fill 465 185 333 465 192 336 minecraft:light_gray_concrete
fill 465 185 343 465 192 346 minecraft:light_gray_concrete
fill 465 185 353 465 192 356 minecraft:light_gray_concrete
fill 465 185 363 465 192 363 minecraft:light_gray_concrete
setblock 424 186 325 minecraft:light_gray_concrete
setblock 424 186 335 minecraft:light_gray_concrete
setblock 424 186 345 minecraft:light_gray_concrete
setblock 424 186 355 minecraft:light_gray_concrete
setblock 426 186 363 minecraft:light_gray_concrete
setblock 430 186 323 minecraft:light_gray_concrete
setblock 436 186 363 minecraft:light_gray_concrete
setblock 440 186 323 minecraft:light_gray_concrete
setblock 446 186 363 minecraft:light_gray_concrete
setblock 450 186 323 minecraft:light_gray_concrete
setblock 456 186 363 minecraft:light_gray_concrete
setblock 460 186 323 minecraft:light_gray_concrete
setblock 464 186 329 minecraft:light_gray_concrete
setblock 464 186 339 minecraft:light_gray_concrete
setblock 464 186 349 minecraft:light_gray_concrete
setblock 464 186 359 minecraft:light_gray_concrete
fill 444 187 325 444 187 327 minecraft:light_gray_concrete
fill 445 187 324 447 187 324 minecraft:light_gray_concrete
fill 445 187 328 447 187 328 minecraft:light_gray_concrete
fill 448 187 325 448 187 327 minecraft:light_gray_concrete
fill 424 189 327 424 189 330 minecraft:light_gray_concrete
fill 424 189 337 424 189 340 minecraft:light_gray_concrete
fill 424 189 347 424 189 350 minecraft:light_gray_concrete
fill 424 189 357 424 189 360 minecraft:light_gray_concrete
fill 425 189 323 428 189 323 minecraft:light_gray_concrete
fill 428 189 363 431 189 363 minecraft:light_gray_concrete
fill 435 189 323 438 189 323 minecraft:light_gray_concrete
fill 438 189 363 441 189 363 minecraft:light_gray_concrete
fill 445 189 323 448 189 323 minecraft:light_gray_concrete
fill 446 189 359 446 189 361 minecraft:light_gray_concrete
fill 447 189 358 449 189 358 minecraft:light_gray_concrete
fill 447 189 362 449 189 362 minecraft:light_gray_concrete
fill 448 189 363 451 189 363 minecraft:light_gray_concrete
fill 450 189 359 450 189 361 minecraft:light_gray_concrete
fill 455 189 323 458 189 323 minecraft:light_gray_concrete
fill 458 189 363 461 189 363 minecraft:light_gray_concrete
fill 464 189 324 464 189 327 minecraft:light_gray_concrete
fill 464 189 334 464 189 337 minecraft:light_gray_concrete
fill 464 189 344 464 189 347 minecraft:light_gray_concrete
fill 464 189 354 464 189 357 minecraft:light_gray_concrete
fill 458 190 347 462 190 349 minecraft:iron_block
fill 459 190 346 461 190 346 minecraft:iron_block
fill 459 190 350 461 190 350 minecraft:iron_block
setblock 424 192 325 minecraft:light_gray_concrete
setblock 424 192 335 minecraft:light_gray_concrete
setblock 424 192 345 minecraft:light_gray_concrete
fill 424 192 352 424 192 353 minecraft:light_gray_concrete
fill 424 192 355 427 192 355 minecraft:light_gray_concrete
fill 425 192 351 427 192 351 minecraft:light_gray_concrete
setblock 426 192 363 minecraft:light_gray_concrete
fill 428 192 352 428 192 354 minecraft:light_gray_concrete
setblock 430 192 323 minecraft:light_gray_concrete
setblock 436 192 363 minecraft:light_gray_concrete
fill 438 192 358 438 192 360 minecraft:light_gray_concrete
fill 439 192 357 441 192 357 minecraft:light_gray_concrete
fill 439 192 361 441 192 361 minecraft:light_gray_concrete
setblock 440 192 323 minecraft:light_gray_concrete
fill 442 192 358 442 192 360 minecraft:light_gray_concrete
fill 444 192 325 444 192 327 minecraft:light_gray_concrete
fill 445 192 324 447 192 324 minecraft:light_gray_concrete
fill 445 192 328 447 192 328 minecraft:light_gray_concrete
setblock 446 192 363 minecraft:light_gray_concrete
fill 448 192 325 448 192 327 minecraft:light_gray_concrete
setblock 450 192 323 minecraft:light_gray_concrete
setblock 456 192 363 minecraft:light_gray_concrete
setblock 460 192 323 minecraft:light_gray_concrete
setblock 464 192 329 minecraft:light_gray_concrete
setblock 464 192 339 minecraft:light_gray_concrete
setblock 464 192 349 minecraft:light_gray_concrete
setblock 464 192 359 minecraft:light_gray_concrete
fill 423 193 328 423 193 331 minecraft:verdant_froglight
fill 423 193 335 423 196 335 minecraft:light_gray_concrete
fill 423 193 336 423 194 336 minecraft:white_concrete
fill 423 193 338 423 193 341 minecraft:verdant_froglight
fill 423 193 348 423 193 351 minecraft:verdant_froglight
fill 423 193 358 423 193 361 minecraft:verdant_froglight
fill 426 193 322 429 193 322 minecraft:verdant_froglight
setblock 426 193 325 minecraft:light[level=14]
setblock 426 193 333 minecraft:light[level=14]
setblock 426 193 341 minecraft:light[level=14]
setblock 426 193 349 minecraft:light[level=14]
setblock 426 193 357 minecraft:light[level=14]
fill 427 193 364 430 193 364 minecraft:verdant_froglight
setblock 430 193 322 minecraft:white_concrete
fill 431 193 322 434 193 322 minecraft:light_gray_concrete
fill 431 193 364 434 196 364 minecraft:light_gray_concrete
setblock 434 193 325 minecraft:light[level=14]
setblock 434 193 333 minecraft:light[level=14]
setblock 434 193 341 minecraft:light[level=14]
setblock 434 193 349 minecraft:light[level=14]
setblock 434 193 357 minecraft:light[level=14]
setblock 435 193 364 minecraft:white_concrete
fill 436 193 322 439 193 322 minecraft:verdant_froglight
fill 436 193 364 436 196 364 minecraft:light_gray_concrete
fill 437 193 364 440 193 364 minecraft:verdant_froglight
setblock 442 193 325 minecraft:light[level=14]
setblock 442 193 333 minecraft:light[level=14]
setblock 442 193 341 minecraft:light[level=14]
setblock 442 193 349 minecraft:light[level=14]
setblock 442 193 357 minecraft:light[level=14]
fill 446 193 322 449 193 322 minecraft:verdant_froglight
fill 447 193 364 450 193 364 minecraft:verdant_froglight
setblock 450 193 325 minecraft:light[level=14]
setblock 450 193 333 minecraft:light[level=14]
setblock 450 193 341 minecraft:light[level=14]
setblock 450 193 349 minecraft:light[level=14]
setblock 450 193 357 minecraft:light[level=14]
fill 456 193 322 459 193 322 minecraft:verdant_froglight
fill 457 193 364 460 193 364 minecraft:verdant_froglight
setblock 458 193 325 minecraft:light[level=14]
setblock 458 193 333 minecraft:light[level=14]
setblock 458 193 341 minecraft:light[level=14]
setblock 458 193 349 minecraft:light[level=14]
setblock 458 193 357 minecraft:light[level=14]
setblock 463 193 322 minecraft:white_concrete
fill 464 193 322 465 196 322 minecraft:light_gray_concrete
fill 465 193 323 465 193 326 minecraft:verdant_froglight
fill 465 193 330 465 193 331 minecraft:white_concrete
fill 465 193 333 465 193 336 minecraft:verdant_froglight
setblock 465 193 337 minecraft:white_concrete
fill 465 193 338 465 196 341 minecraft:light_gray_concrete
fill 465 193 343 465 193 346 minecraft:verdant_froglight
fill 465 193 349 465 196 350 minecraft:light_gray_concrete
setblock 465 193 351 minecraft:white_concrete
fill 465 193 353 465 193 356 minecraft:verdant_froglight
fill 465 193 357 465 193 359 minecraft:light_gray_concrete
setblock 465 193 360 minecraft:white_concrete
fill 465 193 361 465 193 362 minecraft:light_gray_concrete
setblock 465 193 363 minecraft:verdant_froglight
fill 423 194 328 423 196 331 minecraft:light_gray_concrete
fill 423 194 338 423 196 341 minecraft:light_gray_concrete
setblock 423 194 346 minecraft:white_concrete
fill 423 194 347 423 194 353 minecraft:light_gray_concrete
setblock 423 194 354 minecraft:white_concrete
fill 423 194 355 423 194 363 minecraft:light_gray_concrete
setblock 423 194 364 minecraft:white_concrete
fill 424 194 322 424 196 322 minecraft:light_gray_concrete
setblock 425 194 322 minecraft:white_concrete
fill 426 194 322 430 194 322 minecraft:light_gray_concrete
fill 427 194 364 430 194 364 minecraft:light_gray_concrete
setblock 431 194 322 minecraft:white_concrete
fill 432 194 322 433 194 322 minecraft:light_gray_concrete
setblock 434 194 322 minecraft:white_concrete
fill 435 194 364 435 196 364 minecraft:light_gray_concrete
fill 436 194 322 439 194 322 minecraft:light_gray_concrete
setblock 437 194 364 minecraft:white_concrete
fill 438 194 364 440 194 364 minecraft:light_gray_concrete
setblock 442 194 322 minecraft:white_concrete
fill 442 194 364 444 196 364 minecraft:light_gray_concrete
fill 443 194 322 445 196 322 minecraft:light_gray_concrete
setblock 445 194 364 minecraft:white_concrete
fill 446 194 322 446 195 322 minecraft:white_concrete
fill 446 194 364 450 196 364 minecraft:light_gray_concrete
fill 447 194 322 447 196 322 minecraft:light_gray_concrete
setblock 448 194 322 minecraft:white_concrete
fill 449 194 322 449 196 322 minecraft:light_gray_concrete
fill 455 194 364 455 196 364 minecraft:light_gray_concrete
fill 456 194 322 459 194 322 minecraft:light_gray_concrete
setblock 456 194 364 minecraft:white_concrete
fill 457 194 364 457 196 364 minecraft:light_gray_concrete
setblock 458 194 364 minecraft:white_concrete
fill 459 194 364 460 194 364 minecraft:light_gray_concrete
setblock 461 194 322 minecraft:white_concrete
fill 462 194 322 463 196 322 minecraft:light_gray_concrete
fill 465 194 323 465 196 327 minecraft:light_gray_concrete
setblock 465 194 328 minecraft:white_concrete
fill 465 194 330 465 196 331 minecraft:light_gray_concrete
fill 465 194 333 465 196 337 minecraft:light_gray_concrete
fill 465 194 343 465 196 346 minecraft:light_gray_concrete
fill 465 194 351 465 196 351 minecraft:light_gray_concrete
fill 465 194 353 465 194 356 minecraft:light_gray_concrete
setblock 465 194 357 minecraft:white_concrete
fill 465 194 358 465 196 360 minecraft:light_gray_concrete
setblock 465 194 361 minecraft:white_concrete
fill 465 194 362 465 196 363 minecraft:light_gray_concrete
fill 423 195 336 423 196 336 minecraft:light_gray_concrete
fill 423 195 342 423 196 344 minecraft:light_gray_concrete
setblock 423 195 345 minecraft:white_concrete
fill 423 195 346 423 196 351 minecraft:light_gray_concrete
setblock 423 195 352 minecraft:white_concrete
fill 423 195 353 423 196 354 minecraft:light_gray_concrete
setblock 423 195 355 minecraft:white_concrete
fill 423 195 356 423 196 364 minecraft:light_gray_concrete
fill 425 195 322 425 196 322 minecraft:light_gray_concrete
setblock 426 195 322 minecraft:white_concrete
fill 427 195 322 431 196 322 minecraft:light_gray_concrete
fill 427 195 364 428 196 364 minecraft:light_gray_concrete
fill 429 195 364 430 195 364 minecraft:white_concrete
fill 432 195 322 433 195 322 minecraft:white_concrete
fill 434 195 322 434 196 322 minecraft:light_gray_concrete
fill 436 195 322 437 196 322 minecraft:light_gray_concrete
fill 437 195 364 438 196 364 minecraft:light_gray_concrete
setblock 438 195 322 minecraft:white_concrete
fill 439 195 322 439 196 322 minecraft:light_gray_concrete
setblock 439 195 364 minecraft:white_concrete
fill 440 195 364 440 196 364 minecraft:light_gray_concrete
fill 442 195 322 442 197 322 minecraft:light_gray_concrete
fill 445 195 364 445 196 364 minecraft:light_gray_concrete
fill 448 195 322 448 196 322 minecraft:light_gray_concrete
setblock 451 195 364 minecraft:white_concrete
fill 452 195 364 453 196 364 minecraft:light_gray_concrete
setblock 453 195 322 minecraft:white_concrete
fill 456 195 322 457 196 322 minecraft:light_gray_concrete
fill 456 195 364 456 197 364 minecraft:light_gray_concrete
setblock 458 195 322 minecraft:white_concrete
fill 458 195 364 458 196 364 minecraft:light_gray_concrete
fill 459 195 322 459 196 322 minecraft:light_gray_concrete
setblock 459 195 364 minecraft:white_concrete
fill 460 195 364 460 196 364 minecraft:light_gray_concrete
fill 461 195 322 461 196 322 minecraft:light_gray_concrete
fill 465 195 328 465 196 328 minecraft:light_gray_concrete
setblock 465 195 342 minecraft:white_concrete
fill 465 195 353 465 196 353 minecraft:light_gray_concrete
setblock 465 195 354 minecraft:white_concrete
fill 465 195 355 465 196 357 minecraft:light_gray_concrete
fill 465 195 361 465 196 361 minecraft:light_gray_concrete
setblock 423 196 345 minecraft:light_gray_concrete
setblock 423 196 352 minecraft:light_gray_concrete
setblock 423 196 355 minecraft:light_gray_concrete
setblock 426 196 322 minecraft:light_gray_concrete
fill 429 196 364 430 196 364 minecraft:light_gray_concrete
fill 432 196 322 433 196 322 minecraft:light_gray_concrete
setblock 438 196 322 minecraft:light_gray_concrete
setblock 439 196 364 minecraft:light_gray_concrete
setblock 446 196 322 minecraft:light_gray_concrete
setblock 451 196 364 minecraft:light_gray_concrete
setblock 453 196 322 minecraft:light_gray_concrete
setblock 458 196 322 minecraft:light_gray_concrete
setblock 459 196 364 minecraft:light_gray_concrete
fill 465 196 342 465 197 342 minecraft:light_gray_concrete
setblock 465 196 354 minecraft:light_gray_concrete
setblock 423 197 322 minecraft:light_gray_concrete
fill 423 197 323 423 197 325 minecraft:white_concrete
setblock 423 197 326 minecraft:light_gray_concrete
fill 423 197 327 423 307 327 minecraft:white_concrete
fill 423 197 328 423 197 329 minecraft:light_gray_concrete
fill 423 197 330 423 198 333 minecraft:white_concrete
setblock 423 197 334 minecraft:light_gray_concrete
fill 423 197 335 423 197 336 minecraft:white_concrete
fill 423 197 338 423 197 342 minecraft:white_concrete
fill 423 197 343 423 197 344 minecraft:light_gray_concrete
fill 423 197 345 423 307 347 minecraft:white_concrete
setblock 423 197 348 minecraft:light_gray_concrete
fill 423 197 349 423 198 349 minecraft:white_concrete
fill 423 197 350 423 198 350 minecraft:light_gray_concrete
fill 423 197 351 423 198 353 minecraft:white_concrete
setblock 423 197 354 minecraft:light_gray_concrete
fill 423 197 355 423 198 363 minecraft:white_concrete
setblock 423 197 364 minecraft:light_gray_concrete
fill 424 197 322 434 197 322 minecraft:white_concrete
fill 424 197 364 449 197 364 minecraft:white_concrete
fill 436 197 322 441 197 322 minecraft:white_concrete
fill 443 197 322 454 198 322 minecraft:white_concrete
fill 444 197 325 444 197 327 minecraft:light_gray_concrete
fill 445 197 324 447 197 324 minecraft:light_gray_concrete
fill 445 197 328 447 197 328 minecraft:light_gray_concrete
fill 446 197 359 446 197 361 minecraft:light_gray_concrete
fill 447 197 358 449 197 358 minecraft:light_gray_concrete
fill 447 197 362 449 197 362 minecraft:light_gray_concrete
fill 448 197 325 448 197 327 minecraft:light_gray_concrete
fill 450 197 359 450 197 361 minecraft:light_gray_concrete
setblock 450 197 364 minecraft:light_gray_concrete
fill 451 197 364 455 307 364 minecraft:white_concrete
fill 456 197 322 465 197 322 minecraft:white_concrete
fill 457 197 364 464 197 364 minecraft:white_concrete
fill 465 197 323 465 198 326 minecraft:white_concrete
setblock 465 197 327 minecraft:light_gray_concrete
fill 465 197 328 465 307 329 minecraft:white_concrete
setblock 465 197 330 minecraft:light_gray_concrete
fill 465 197 331 465 307 332 minecraft:white_concrete
setblock 465 197 333 minecraft:light_gray_concrete
fill 465 197 334 465 201 334 minecraft:white_concrete
setblock 465 197 335 minecraft:light_gray_concrete
fill 465 197 336 465 197 341 minecraft:white_concrete
fill 465 197 343 465 198 343 minecraft:light_gray_concrete
fill 465 197 344 465 197 351 minecraft:white_concrete
fill 465 197 353 465 197 362 minecraft:white_concrete
fill 465 197 363 465 197 364 minecraft:light_gray_concrete
fill 423 198 322 423 307 322 minecraft:white_concrete
setblock 423 198 323 minecraft:light_gray_concrete
fill 423 198 324 423 307 326 minecraft:white_concrete
fill 423 198 328 423 201 329 minecraft:white_concrete
fill 423 198 334 423 307 335 minecraft:white_concrete
fill 423 198 336 423 199 336 minecraft:light_gray_concrete
fill 423 198 337 423 198 339 minecraft:white_concrete
fill 423 198 340 424 198 340 minecraft:light_gray_concrete
fill 423 198 341 423 201 341 minecraft:white_concrete
setblock 423 198 342 minecraft:light_gray_concrete
fill 423 198 343 423 307 343 minecraft:white_concrete
fill 423 198 344 423 199 344 minecraft:light_gray_concrete
fill 423 198 348 423 201 348 minecraft:white_concrete
fill 423 198 354 423 307 354 minecraft:white_concrete
fill 423 198 364 425 307 364 minecraft:white_concrete
setblock 424 198 322 minecraft:light_gray_concrete
setblock 424 198 325 minecraft:light_gray_concrete
fill 424 198 327 424 198 330 minecraft:light_gray_concrete
setblock 424 198 335 minecraft:light_gray_concrete
fill 424 198 337 424 198 339 minecraft:light_gray_concrete
setblock 424 198 345 minecraft:light_gray_concrete
fill 424 198 347 424 198 350 minecraft:light_gray_concrete
setblock 424 198 355 minecraft:light_gray_concrete
fill 424 198 357 424 198 360 minecraft:light_gray_concrete
fill 425 198 322 430 198 322 minecraft:white_concrete
fill 425 198 323 428 198 323 minecraft:light_gray_concrete
fill 425 198 329 426 199 329 minecraft:iron_block
fill 426 198 363 426 198 364 minecraft:light_gray_concrete
fill 427 198 364 450 198 364 minecraft:white_concrete
fill 428 198 363 431 198 363 minecraft:light_gray_concrete
setblock 430 198 323 minecraft:light_gray_concrete
fill 431 198 322 431 199 322 minecraft:light_gray_concrete
fill 432 198 322 432 307 322 minecraft:white_concrete
setblock 433 198 322 minecraft:light_gray_concrete
fill 434 198 322 435 307 322 minecraft:white_concrete
fill 435 198 323 438 198 323 minecraft:light_gray_concrete
setblock 436 198 322 minecraft:light_gray_concrete
setblock 436 198 363 minecraft:light_gray_concrete
fill 437 198 322 440 198 322 minecraft:white_concrete
fill 438 198 363 441 198 363 minecraft:light_gray_concrete
setblock 440 198 323 minecraft:light_gray_concrete
setblock 441 198 322 minecraft:light_gray_concrete
fill 442 198 322 442 307 322 minecraft:white_concrete
fill 445 198 323 448 198 323 minecraft:light_gray_concrete
setblock 446 198 363 minecraft:light_gray_concrete
fill 448 198 363 451 198 363 minecraft:light_gray_concrete
setblock 450 198 323 minecraft:light_gray_concrete
fill 453 198 348 453 199 348 minecraft:lime_stained_glass
fill 455 198 322 464 198 322 minecraft:white_concrete
fill 455 198 323 458 198 323 minecraft:light_gray_concrete
setblock 456 198 363 minecraft:light_gray_concrete
fill 456 198 364 457 201 364 minecraft:white_concrete
fill 458 198 363 459 198 364 minecraft:light_gray_concrete
setblock 460 198 323 minecraft:light_gray_concrete
fill 460 198 363 461 198 363 minecraft:light_gray_concrete
fill 460 198 364 463 198 364 minecraft:white_concrete
fill 464 198 324 464 198 327 minecraft:light_gray_concrete
setblock 464 198 329 minecraft:light_gray_concrete
fill 464 198 334 464 198 337 minecraft:light_gray_concrete
setblock 464 198 339 minecraft:light_gray_concrete
fill 464 198 344 464 198 347 minecraft:light_gray_concrete
setblock 464 198 349 minecraft:light_gray_concrete
fill 464 198 354 464 198 357 minecraft:light_gray_concrete
setblock 464 198 359 minecraft:light_gray_concrete
fill 464 198 364 464 199 364 minecraft:light_gray_concrete
fill 465 198 322 465 199 322 minecraft:light_gray_concrete
fill 465 198 327 465 307 327 minecraft:white_concrete
fill 465 198 330 465 307 330 minecraft:white_concrete
fill 465 198 333 465 201 333 minecraft:white_concrete
fill 465 198 335 465 201 336 minecraft:white_concrete
setblock 465 198 337 minecraft:light_gray_concrete
fill 465 198 338 465 307 342 minecraft:white_concrete
setblock 465 198 344 minecraft:light_gray_concrete
fill 465 198 345 465 201 355 minecraft:white_concrete
setblock 465 198 356 minecraft:light_gray_concrete
fill 465 198 357 465 198 364 minecraft:white_concrete
fill 423 199 323 423 307 323 minecraft:white_concrete
fill 423 199 330 423 201 332 minecraft:white_concrete
setblock 423 199 333 minecraft:light_gray_concrete
fill 423 199 337 423 307 337 minecraft:white_concrete
setblock 423 199 338 minecraft:light_gray_concrete
fill 423 199 339 423 201 340 minecraft:white_concrete
fill 423 199 342 423 307 342 minecraft:white_concrete
setblock 423 199 349 minecraft:light_gray_concrete
fill 423 199 350 423 201 352 minecraft:white_concrete
fill 423 199 353 424 199 353 minecraft:light_gray_concrete
fill 423 199 355 423 201 358 minecraft:white_concrete
setblock 423 199 359 minecraft:light_gray_concrete
fill 423 199 360 423 201 363 minecraft:white_concrete
fill 424 199 322 426 201 322 minecraft:white_concrete
setblock 424 199 329 minecraft:iron_block
setblock 424 199 352 minecraft:light_gray_concrete
fill 425 199 351 427 199 351 minecraft:light_gray_concrete
fill 425 199 355 427 199 355 minecraft:light_gray_concrete
fill 426 199 364 439 201 364 minecraft:white_concrete
setblock 427 199 322 minecraft:light_gray_concrete
fill 428 199 322 430 201 322 minecraft:white_concrete
fill 428 199 352 428 199 354 minecraft:light_gray_concrete
fill 433 199 322 433 307 322 minecraft:white_concrete
fill 436 199 322 436 201 322 minecraft:white_concrete
setblock 437 199 322 minecraft:light_gray_concrete
fill 438 199 322 441 201 322 minecraft:white_concrete
fill 438 199 358 438 199 360 minecraft:light_gray_concrete
fill 439 199 357 441 199 357 minecraft:light_gray_concrete
fill 439 199 361 441 199 361 minecraft:light_gray_concrete
setblock 440 199 364 minecraft:light_gray_concrete
fill 441 199 364 450 201 364 minecraft:white_concrete
fill 442 199 358 442 199 360 minecraft:light_gray_concrete
fill 443 199 322 447 201 322 minecraft:white_concrete
setblock 448 199 322 minecraft:light_gray_concrete
fill 449 199 322 453 201 322 minecraft:white_concrete
setblock 454 199 322 minecraft:light_gray_concrete
fill 455 199 322 458 201 322 minecraft:white_concrete
fill 458 199 364 460 201 364 minecraft:white_concrete
setblock 459 199 322 minecraft:light_gray_concrete
fill 460 199 322 464 307 322 minecraft:white_concrete
setblock 461 199 364 minecraft:light_gray_concrete
fill 462 199 364 463 307 364 minecraft:white_concrete
setblock 465 199 323 minecraft:light_gray_concrete
fill 465 199 324 465 201 326 minecraft:white_concrete
fill 465 199 337 465 307 337 minecraft:white_concrete
fill 465 199 343 465 201 344 minecraft:white_concrete
fill 465 199 356 465 201 360 minecraft:white_concrete
setblock 465 199 361 minecraft:light_gray_concrete
fill 465 199 362 465 201 363 minecraft:white_concrete
setblock 465 199 364 minecraft:light_gray_concrete
fill 423 200 333 423 307 333 minecraft:white_concrete
fill 423 200 336 423 307 336 minecraft:white_concrete
fill 423 200 338 423 201 338 minecraft:white_concrete
fill 423 200 344 423 307 344 minecraft:white_concrete
fill 423 200 349 423 201 349 minecraft:white_concrete
fill 423 200 353 423 307 353 minecraft:white_concrete
fill 423 200 359 423 201 359 minecraft:white_concrete
fill 427 200 322 427 201 322 minecraft:white_concrete
fill 431 200 322 431 307 322 minecraft:white_concrete
fill 437 200 322 437 201 322 minecraft:white_concrete
fill 440 200 364 440 201 364 minecraft:white_concrete
fill 448 200 322 448 201 322 minecraft:white_concrete
fill 454 200 322 454 307 322 minecraft:white_concrete
fill 459 200 322 459 201 322 minecraft:white_concrete
fill 461 200 364 461 307 364 minecraft:white_concrete
fill 464 200 364 465 307 364 minecraft:white_concrete
fill 465 200 322 465 201 323 minecraft:white_concrete
fill 465 200 361 465 307 361 minecraft:white_concrete
setblock 426 201 325 minecraft:light[level=14]
setblock 426 201 333 minecraft:light[level=14]
setblock 426 201 341 minecraft:light[level=14]
setblock 426 201 349 minecraft:light[level=14]
setblock 426 201 357 minecraft:light[level=14]
setblock 434 201 325 minecraft:light[level=14]
setblock 434 201 333 minecraft:light[level=14]
setblock 434 201 341 minecraft:light[level=14]
setblock 434 201 349 minecraft:light[level=14]
setblock 434 201 357 minecraft:light[level=14]
fill 439 201 361 441 202 362 minecraft:iron_block
fill 440 201 363 440 202 363 minecraft:iron_block
setblock 442 201 325 minecraft:light[level=14]
setblock 442 201 333 minecraft:light[level=14]
setblock 442 201 341 minecraft:light[level=14]
setblock 442 201 349 minecraft:light[level=14]
setblock 442 201 357 minecraft:light[level=14]
setblock 450 201 325 minecraft:light[level=14]
setblock 450 201 333 minecraft:light[level=14]
setblock 450 201 341 minecraft:light[level=14]
setblock 450 201 349 minecraft:light[level=14]
setblock 450 201 357 minecraft:light[level=14]
setblock 458 201 325 minecraft:light[level=14]
setblock 458 201 333 minecraft:light[level=14]
setblock 458 201 341 minecraft:light[level=14]
setblock 458 201 349 minecraft:light[level=14]
setblock 458 201 357 minecraft:light[level=14]
fill 423 202 328 423 202 331 minecraft:verdant_froglight
fill 423 202 332 423 307 332 minecraft:white_concrete
fill 423 202 338 423 202 341 minecraft:verdant_froglight
fill 423 202 348 423 202 351 minecraft:verdant_froglight
fill 423 202 352 423 307 352 minecraft:white_concrete
fill 423 202 355 423 307 357 minecraft:white_concrete
fill 423 202 358 423 202 361 minecraft:verdant_froglight
fill 423 202 362 423 307 363 minecraft:white_concrete
fill 424 202 322 425 307 322 minecraft:white_concrete
fill 426 202 322 429 202 322 minecraft:verdant_froglight
fill 426 202 364 426 307 364 minecraft:white_concrete
fill 427 202 364 430 202 364 minecraft:verdant_froglight
fill 430 202 322 430 307 322 minecraft:white_concrete
fill 431 202 364 436 307 364 minecraft:white_concrete
fill 436 202 322 439 202 322 minecraft:verdant_froglight
fill 437 202 364 440 202 364 minecraft:verdant_froglight
fill 440 202 322 441 307 322 minecraft:white_concrete
setblock 440 202 357 minecraft:verdant_froglight
fill 441 202 364 446 307 364 minecraft:white_concrete
fill 443 202 322 445 307 322 minecraft:white_concrete
fill 444 202 325 444 202 327 minecraft:light_gray_concrete
fill 445 202 324 447 202 324 minecraft:light_gray_concrete
fill 445 202 328 447 202 328 minecraft:light_gray_concrete
fill 446 202 322 449 202 322 minecraft:verdant_froglight
fill 447 202 364 450 202 364 minecraft:verdant_froglight
fill 448 202 325 448 202 327 minecraft:light_gray_concrete
fill 450 202 322 453 307 322 minecraft:white_concrete
fill 455 202 322 455 307 322 minecraft:white_concrete
fill 456 202 322 459 202 322 minecraft:verdant_froglight
fill 456 202 364 456 307 364 minecraft:white_concrete
fill 457 202 364 460 202 364 minecraft:verdant_froglight
fill 465 202 322 465 307 322 minecraft:white_concrete
fill 465 202 323 465 202 326 minecraft:verdant_froglight
fill 465 202 333 465 202 336 minecraft:verdant_froglight
fill 465 202 343 465 202 346 minecraft:verdant_froglight
fill 465 202 347 465 307 352 minecraft:white_concrete
fill 465 202 353 465 202 356 minecraft:verdant_froglight
fill 465 202 357 465 307 360 minecraft:white_concrete
fill 465 202 362 465 307 362 minecraft:white_concrete
setblock 465 202 363 minecraft:verdant_froglight
fill 423 203 328 423 210 331 minecraft:white_concrete
fill 423 203 338 423 210 341 minecraft:white_concrete
fill 423 203 348 423 210 351 minecraft:white_concrete
fill 423 203 358 423 210 361 minecraft:white_concrete
fill 426 203 322 429 210 322 minecraft:white_concrete
fill 427 203 364 430 210 364 minecraft:white_concrete
fill 430 203 340 432 204 340 minecraft:lime_concrete
fill 431 203 339 431 204 339 minecraft:lime_concrete
fill 431 203 341 431 204 341 minecraft:lime_concrete
fill 436 203 322 439 210 322 minecraft:white_concrete
fill 437 203 364 440 210 364 minecraft:white_concrete
fill 446 203 322 449 210 322 minecraft:white_concrete
fill 447 203 364 450 210 364 minecraft:white_concrete
fill 456 203 322 459 210 322 minecraft:white_concrete
fill 457 203 364 460 210 364 minecraft:white_concrete
fill 465 203 323 465 210 326 minecraft:white_concrete
fill 465 203 333 465 210 336 minecraft:white_concrete
fill 465 203 343 465 210 346 minecraft:white_concrete
fill 465 203 353 465 210 356 minecraft:white_concrete
fill 465 203 363 465 210 363 minecraft:white_concrete
setblock 424 204 325 minecraft:light_gray_concrete
setblock 424 204 335 minecraft:light_gray_concrete
setblock 424 204 345 minecraft:light_gray_concrete
setblock 424 204 355 minecraft:light_gray_concrete
setblock 426 204 363 minecraft:light_gray_concrete
setblock 430 204 323 minecraft:light_gray_concrete
setblock 436 204 363 minecraft:light_gray_concrete
setblock 440 204 323 minecraft:light_gray_concrete
setblock 446 204 363 minecraft:light_gray_concrete
setblock 450 204 323 minecraft:light_gray_concrete
setblock 456 204 363 minecraft:light_gray_concrete
setblock 460 204 323 minecraft:light_gray_concrete
setblock 464 204 329 minecraft:light_gray_concrete
setblock 464 204 339 minecraft:light_gray_concrete
setblock 464 204 349 minecraft:light_gray_concrete
setblock 464 204 359 minecraft:light_gray_concrete
fill 446 205 359 446 205 361 minecraft:light_gray_concrete
fill 447 205 358 449 205 358 minecraft:light_gray_concrete
fill 447 205 362 449 205 362 minecraft:light_gray_concrete
fill 450 205 359 450 205 361 minecraft:light_gray_concrete
fill 424 206 352 424 206 353 minecraft:light_gray_concrete
fill 425 206 351 427 206 351 minecraft:light_gray_concrete
fill 425 206 355 427 206 355 minecraft:light_gray_concrete
fill 428 206 352 428 206 354 minecraft:light_gray_concrete
fill 438 206 358 438 206 360 minecraft:light_gray_concrete
fill 439 206 357 441 206 357 minecraft:light_gray_concrete
fill 439 206 361 441 206 361 minecraft:light_gray_concrete
fill 442 206 358 442 206 360 minecraft:light_gray_concrete
fill 424 207 327 424 207 330 minecraft:light_gray_concrete
fill 424 207 337 424 207 340 minecraft:light_gray_concrete
fill 424 207 347 424 207 350 minecraft:light_gray_concrete
fill 424 207 357 424 207 360 minecraft:light_gray_concrete
fill 425 207 323 428 207 323 minecraft:light_gray_concrete
fill 428 207 363 431 207 363 minecraft:light_gray_concrete
fill 435 207 323 438 207 323 minecraft:light_gray_concrete
fill 438 207 363 441 207 363 minecraft:light_gray_concrete
fill 444 207 325 444 207 327 minecraft:light_gray_concrete
fill 445 207 323 447 207 324 minecraft:light_gray_concrete
fill 445 207 328 447 207 328 minecraft:light_gray_concrete
setblock 448 207 323 minecraft:light_gray_concrete
fill 448 207 325 448 207 327 minecraft:light_gray_concrete
fill 448 207 363 451 207 363 minecraft:light_gray_concrete
fill 455 207 323 458 207 323 minecraft:light_gray_concrete
fill 458 207 363 461 207 363 minecraft:light_gray_concrete
fill 464 207 324 464 207 327 minecraft:light_gray_concrete
fill 464 207 334 464 207 337 minecraft:light_gray_concrete
fill 464 207 344 464 207 347 minecraft:light_gray_concrete
fill 464 207 354 464 207 357 minecraft:light_gray_concrete
setblock 426 209 325 minecraft:light[level=14]
setblock 426 209 333 minecraft:light[level=14]
setblock 426 209 341 minecraft:light[level=14]
setblock 426 209 349 minecraft:light[level=14]
setblock 426 209 357 minecraft:light[level=14]
setblock 434 209 325 minecraft:light[level=14]
setblock 434 209 333 minecraft:light[level=14]
setblock 434 209 341 minecraft:light[level=14]
setblock 434 209 349 minecraft:light[level=14]
setblock 434 209 357 minecraft:light[level=14]
setblock 442 209 325 minecraft:light[level=14]
setblock 442 209 333 minecraft:light[level=14]
setblock 442 209 341 minecraft:light[level=14]
setblock 442 209 349 minecraft:light[level=14]
setblock 442 209 357 minecraft:light[level=14]
setblock 450 209 325 minecraft:light[level=14]
setblock 450 209 333 minecraft:light[level=14]
setblock 450 209 341 minecraft:light[level=14]
setblock 450 209 349 minecraft:light[level=14]
setblock 450 209 357 minecraft:light[level=14]
setblock 458 209 325 minecraft:light[level=14]
setblock 458 209 333 minecraft:light[level=14]
setblock 458 209 341 minecraft:light[level=14]
setblock 458 209 349 minecraft:light[level=14]
setblock 458 209 357 minecraft:light[level=14]
setblock 424 210 325 minecraft:light_gray_concrete
setblock 424 210 335 minecraft:light_gray_concrete
setblock 424 210 345 minecraft:light_gray_concrete
setblock 424 210 355 minecraft:light_gray_concrete
setblock 426 210 363 minecraft:light_gray_concrete
setblock 430 210 323 minecraft:light_gray_concrete
setblock 436 210 363 minecraft:light_gray_concrete
setblock 440 210 323 minecraft:light_gray_concrete
setblock 446 210 363 minecraft:light_gray_concrete
setblock 450 210 323 minecraft:light_gray_concrete
setblock 456 210 363 minecraft:light_gray_concrete
setblock 460 210 323 minecraft:light_gray_concrete
setblock 464 210 329 minecraft:light_gray_concrete
setblock 464 210 339 minecraft:light_gray_concrete
setblock 464 210 349 minecraft:light_gray_concrete
setblock 464 210 359 minecraft:light_gray_concrete
fill 423 211 328 423 211 331 minecraft:verdant_froglight
fill 423 211 338 423 211 341 minecraft:verdant_froglight
fill 423 211 348 423 211 351 minecraft:verdant_froglight
fill 423 211 358 423 211 361 minecraft:verdant_froglight
fill 426 211 322 429 211 322 minecraft:verdant_froglight
fill 427 211 364 430 211 364 minecraft:verdant_froglight
fill 436 211 322 439 211 322 minecraft:verdant_froglight
fill 437 211 364 440 211 364 minecraft:verdant_froglight
fill 446 211 322 449 211 322 minecraft:verdant_froglight
fill 447 211 364 450 211 364 minecraft:verdant_froglight
fill 456 211 322 459 211 322 minecraft:verdant_froglight
fill 457 211 364 460 211 364 minecraft:verdant_froglight
fill 465 211 323 465 211 326 minecraft:verdant_froglight
fill 465 211 333 465 211 336 minecraft:verdant_froglight
fill 465 211 343 465 211 346 minecraft:verdant_froglight
fill 465 211 353 465 211 356 minecraft:verdant_froglight
setblock 465 211 363 minecraft:verdant_froglight
fill 423 212 328 423 228 331 minecraft:white_concrete
fill 423 212 338 423 228 341 minecraft:white_concrete
fill 423 212 348 423 228 351 minecraft:white_concrete
fill 423 212 358 423 228 361 minecraft:white_concrete
fill 426 212 322 429 228 322 minecraft:white_concrete
fill 427 212 364 430 228 364 minecraft:white_concrete
fill 436 212 322 439 228 322 minecraft:white_concrete
fill 437 212 364 440 228 364 minecraft:white_concrete
fill 444 212 325 444 212 327 minecraft:light_gray_concrete
fill 445 212 324 447 212 324 minecraft:light_gray_concrete
fill 445 212 328 447 212 328 minecraft:light_gray_concrete
fill 446 212 322 449 228 322 minecraft:white_concrete
fill 447 212 364 450 228 364 minecraft:white_concrete
fill 448 212 325 448 212 327 minecraft:light_gray_concrete
fill 456 212 322 459 228 322 minecraft:white_concrete
fill 457 212 364 460 228 364 minecraft:white_concrete
fill 465 212 323 465 228 326 minecraft:white_concrete
fill 465 212 333 465 228 336 minecraft:white_concrete
fill 465 212 343 465 228 346 minecraft:white_concrete
fill 465 212 353 465 228 356 minecraft:white_concrete
fill 465 212 363 465 228 363 minecraft:white_concrete
fill 424 213 352 424 213 353 minecraft:light_gray_concrete
fill 425 213 351 427 213 351 minecraft:light_gray_concrete
fill 425 213 355 427 213 355 minecraft:light_gray_concrete
fill 428 213 352 428 213 354 minecraft:light_gray_concrete
fill 438 213 358 438 213 360 minecraft:light_gray_concrete
fill 439 213 357 441 213 357 minecraft:light_gray_concrete
fill 439 213 361 441 213 361 minecraft:light_gray_concrete
fill 442 213 358 442 213 360 minecraft:light_gray_concrete
fill 446 213 359 446 213 361 minecraft:light_gray_concrete
fill 447 213 358 449 213 358 minecraft:light_gray_concrete
fill 447 213 362 449 213 362 minecraft:light_gray_concrete
fill 450 213 359 450 213 361 minecraft:light_gray_concrete
setblock 424 216 325 minecraft:light_gray_concrete
fill 424 216 327 424 216 330 minecraft:light_gray_concrete
setblock 424 216 335 minecraft:light_gray_concrete
fill 424 216 337 424 216 340 minecraft:light_gray_concrete
setblock 424 216 345 minecraft:light_gray_concrete
fill 424 216 347 424 216 350 minecraft:light_gray_concrete
setblock 424 216 355 minecraft:light_gray_concrete
fill 424 216 357 424 216 360 minecraft:light_gray_concrete
fill 425 216 323 428 216 323 minecraft:light_gray_concrete
setblock 426 216 363 minecraft:light_gray_concrete
fill 428 216 363 431 216 363 minecraft:light_gray_concrete
setblock 430 216 323 minecraft:light_gray_concrete
fill 435 216 323 438 216 323 minecraft:light_gray_concrete
setblock 436 216 363 minecraft:light_gray_concrete
fill 438 216 363 441 216 363 minecraft:light_gray_concrete
setblock 440 216 323 minecraft:light_gray_concrete
fill 445 216 323 448 216 323 minecraft:light_gray_concrete
setblock 446 216 363 minecraft:light_gray_concrete
fill 448 216 363 451 216 363 minecraft:light_gray_concrete
setblock 450 216 323 minecraft:light_gray_concrete
fill 455 216 323 458 216 323 minecraft:light_gray_concrete
setblock 456 216 363 minecraft:light_gray_concrete
fill 458 216 363 461 216 363 minecraft:light_gray_concrete
setblock 460 216 323 minecraft:light_gray_concrete
fill 464 216 324 464 216 327 minecraft:light_gray_concrete
setblock 464 216 329 minecraft:light_gray_concrete
fill 464 216 334 464 216 337 minecraft:light_gray_concrete
setblock 464 216 339 minecraft:light_gray_concrete
fill 464 216 344 464 216 347 minecraft:light_gray_concrete
setblock 464 216 349 minecraft:light_gray_concrete
fill 464 216 354 464 216 357 minecraft:light_gray_concrete
setblock 464 216 359 minecraft:light_gray_concrete
setblock 426 217 325 minecraft:light[level=14]
setblock 426 217 333 minecraft:light[level=14]
setblock 426 217 341 minecraft:light[level=14]
setblock 426 217 349 minecraft:light[level=14]
setblock 426 217 357 minecraft:light[level=14]
setblock 434 217 325 minecraft:light[level=14]
setblock 434 217 333 minecraft:light[level=14]
setblock 434 217 341 minecraft:light[level=14]
setblock 434 217 349 minecraft:light[level=14]
setblock 434 217 357 minecraft:light[level=14]
setblock 442 217 325 minecraft:light[level=14]
setblock 442 217 333 minecraft:light[level=14]
setblock 442 217 341 minecraft:light[level=14]
setblock 442 217 349 minecraft:light[level=14]
setblock 442 217 357 minecraft:light[level=14]
setblock 450 217 325 minecraft:light[level=14]
setblock 450 217 333 minecraft:light[level=14]
setblock 450 217 341 minecraft:light[level=14]
setblock 450 217 349 minecraft:light[level=14]
setblock 450 217 357 minecraft:light[level=14]
setblock 458 217 325 minecraft:light[level=14]
setblock 458 217 333 minecraft:light[level=14]
setblock 458 217 341 minecraft:light[level=14]
setblock 458 217 349 minecraft:light[level=14]
setblock 458 217 357 minecraft:light[level=14]
fill 433 223 346 441 223 346 minecraft:iron_block
fill 434 223 342 434 224 343 minecraft:iron_block
fill 434 223 345 441 223 345 minecraft:iron_block
fill 434 223 348 442 223 348 minecraft:iron_block
fill 435 223 340 436 224 340 minecraft:iron_block
fill 435 223 343 452 223 343 minecraft:iron_block
fill 435 223 350 435 224 351 minecraft:iron_block
fill 436 223 341 451 223 342 minecraft:iron_block
fill 436 223 344 442 223 344 minecraft:iron_block
fill 436 223 347 441 223 347 minecraft:iron_block
fill 436 223 349 452 223 350 minecraft:iron_block
fill 436 223 353 437 224 353 minecraft:iron_block
fill 437 223 338 437 224 339 minecraft:iron_block
fill 437 223 351 450 223 352 minecraft:iron_block
fill 438 223 339 449 223 340 minecraft:iron_block
fill 438 223 354 438 224 355 minecraft:iron_block
fill 439 223 337 440 224 337 minecraft:iron_block
fill 439 223 353 448 224 354 minecraft:iron_block
fill 440 223 338 450 224 338 minecraft:iron_block
fill 440 223 356 441 224 356 minecraft:iron_block
fill 441 223 355 441 224 355 minecraft:iron_block
fill 442 223 336 442 224 337 minecraft:iron_block
fill 443 223 355 444 224 356 minecraft:iron_block
fill 444 223 335 444 224 337 minecraft:iron_block
fill 444 223 357 444 224 357 minecraft:iron_block
fill 445 223 336 445 224 337 minecraft:iron_block
fill 446 223 344 454 223 344 minecraft:iron_block
fill 446 223 348 452 223 348 minecraft:iron_block
fill 446 223 355 446 224 356 minecraft:iron_block
fill 447 223 336 447 224 337 minecraft:iron_block
fill 447 223 345 452 223 347 minecraft:iron_block
fill 448 223 336 448 224 336 minecraft:iron_block
fill 448 223 355 449 224 355 minecraft:iron_block
fill 449 223 353 451 224 353 minecraft:iron_block
fill 450 223 337 450 224 337 minecraft:iron_block
fill 450 223 340 451 224 340 minecraft:iron_block
fill 451 223 339 452 224 339 minecraft:iron_block
fill 451 223 351 452 224 351 minecraft:iron_block
fill 451 223 354 451 224 354 minecraft:iron_block
fill 452 223 342 453 224 342 minecraft:iron_block
fill 452 223 352 453 224 352 minecraft:iron_block
fill 453 223 341 453 224 341 minecraft:iron_block
fill 453 223 346 454 224 347 minecraft:iron_block
fill 453 223 349 454 224 349 minecraft:iron_block
fill 454 223 350 454 224 350 minecraft:iron_block
fill 455 223 346 455 224 346 minecraft:iron_block
fill 424 224 323 424 224 324 minecraft:lime_stained_glass
setblock 424 224 325 minecraft:green_stained_glass
fill 424 224 326 424 224 328 minecraft:lime_stained_glass
setblock 424 224 329 minecraft:green_stained_glass
fill 424 224 330 424 224 332 minecraft:lime_stained_glass
setblock 424 224 333 minecraft:green_stained_glass
fill 424 224 334 424 224 336 minecraft:lime_stained_glass
setblock 424 224 337 minecraft:green_stained_glass
fill 424 224 338 424 224 340 minecraft:lime_stained_glass
setblock 424 224 341 minecraft:green_stained_glass
fill 424 224 342 424 224 344 minecraft:lime_stained_glass
setblock 424 224 345 minecraft:green_stained_glass
fill 424 224 346 424 224 348 minecraft:lime_stained_glass
setblock 424 224 349 minecraft:green_stained_glass
fill 424 224 350 424 224 352 minecraft:lime_stained_glass
setblock 424 224 353 minecraft:green_stained_glass
fill 424 224 354 424 224 356 minecraft:lime_stained_glass
setblock 424 224 357 minecraft:green_stained_glass
fill 424 224 358 424 224 360 minecraft:lime_stained_glass
setblock 424 224 361 minecraft:green_stained_glass
fill 424 224 362 425 224 363 minecraft:lime_stained_glass
setblock 425 224 323 minecraft:lime_stained_glass
setblock 425 224 324 minecraft:green_stained_glass
fill 425 224 325 425 224 327 minecraft:lime_stained_glass
setblock 425 224 328 minecraft:green_stained_glass
fill 425 224 329 425 224 331 minecraft:lime_stained_glass
setblock 425 224 332 minecraft:green_stained_glass
fill 425 224 333 425 224 335 minecraft:lime_stained_glass
setblock 425 224 336 minecraft:green_stained_glass
fill 425 224 337 425 224 339 minecraft:lime_stained_glass
setblock 425 224 340 minecraft:green_stained_glass
fill 425 224 341 425 224 343 minecraft:lime_stained_glass
setblock 425 224 344 minecraft:green_stained_glass
fill 425 224 345 425 224 347 minecraft:lime_stained_glass
setblock 425 224 348 minecraft:green_stained_glass
fill 425 224 349 425 224 351 minecraft:lime_stained_glass
setblock 425 224 352 minecraft:green_stained_glass
fill 425 224 353 425 224 355 minecraft:lime_stained_glass
setblock 425 224 356 minecraft:green_stained_glass
fill 425 224 357 425 224 359 minecraft:lime_stained_glass
setblock 425 224 360 minecraft:green_stained_glass
fill 425 224 361 427 224 361 minecraft:lime_stained_glass
setblock 426 224 323 minecraft:green_stained_glass
fill 426 224 324 426 224 326 minecraft:lime_stained_glass
setblock 426 224 327 minecraft:green_stained_glass
fill 426 224 328 426 224 330 minecraft:lime_stained_glass
setblock 426 224 331 minecraft:green_stained_glass
fill 426 224 332 426 224 334 minecraft:lime_stained_glass
setblock 426 224 335 minecraft:green_stained_glass
fill 426 224 336 426 224 338 minecraft:lime_stained_glass
setblock 426 224 339 minecraft:green_stained_glass
fill 426 224 340 426 224 342 minecraft:lime_stained_glass
setblock 426 224 343 minecraft:green_stained_glass
fill 426 224 344 426 224 346 minecraft:lime_stained_glass
setblock 426 224 347 minecraft:green_stained_glass
fill 426 224 348 426 224 350 minecraft:lime_stained_glass
setblock 426 224 351 minecraft:green_stained_glass
fill 426 224 352 426 224 354 minecraft:lime_stained_glass
setblock 426 224 355 minecraft:green_stained_glass
fill 426 224 356 426 224 358 minecraft:lime_stained_glass
setblock 426 224 359 minecraft:green_stained_glass
fill 426 224 360 428 224 360 minecraft:lime_stained_glass
setblock 426 224 362 minecraft:lime_stained_glass
setblock 426 224 363 minecraft:green_stained_glass
fill 427 224 323 427 224 325 minecraft:lime_stained_glass
setblock 427 224 326 minecraft:green_stained_glass
fill 427 224 327 427 224 329 minecraft:lime_stained_glass
setblock 427 224 330 minecraft:green_stained_glass
fill 427 224 331 427 224 333 minecraft:lime_stained_glass
setblock 427 224 334 minecraft:green_stained_glass
fill 427 224 335 427 224 337 minecraft:lime_stained_glass
setblock 427 224 338 minecraft:green_stained_glass
fill 427 224 339 427 224 341 minecraft:lime_stained_glass
setblock 427 224 342 minecraft:green_stained_glass
fill 427 224 343 427 224 345 minecraft:lime_stained_glass
setblock 427 224 346 minecraft:green_stained_glass
fill 427 224 347 427 224 349 minecraft:lime_stained_glass
setblock 427 224 350 minecraft:green_stained_glass
fill 427 224 351 427 224 353 minecraft:lime_stained_glass
setblock 427 224 354 minecraft:green_stained_glass
fill 427 224 355 427 224 357 minecraft:lime_stained_glass
setblock 427 224 358 minecraft:green_stained_glass
fill 427 224 359 429 224 359 minecraft:lime_stained_glass
setblock 427 224 362 minecraft:green_stained_glass
fill 427 224 363 429 224 363 minecraft:lime_stained_glass
fill 428 224 323 428 224 324 minecraft:lime_stained_glass
setblock 428 224 325 minecraft:green_stained_glass
fill 428 224 326 428 224 328 minecraft:lime_stained_glass
setblock 428 224 329 minecraft:green_stained_glass
fill 428 224 330 428 224 332 minecraft:lime_stained_glass
setblock 428 224 333 minecraft:green_stained_glass
fill 428 224 334 428 224 336 minecraft:lime_stained_glass
setblock 428 224 337 minecraft:green_stained_glass
fill 428 224 338 428 224 340 minecraft:lime_stained_glass
setblock 428 224 341 minecraft:green_stained_glass
fill 428 224 342 428 224 344 minecraft:lime_stained_glass
setblock 428 224 345 minecraft:green_stained_glass
fill 428 224 346 428 224 348 minecraft:lime_stained_glass
setblock 428 224 349 minecraft:green_stained_glass
fill 428 224 350 428 224 352 minecraft:lime_stained_glass
setblock 428 224 353 minecraft:green_stained_glass
fill 428 224 354 428 224 356 minecraft:lime_stained_glass
setblock 428 224 357 minecraft:green_stained_glass
fill 428 224 358 430 224 358 minecraft:lime_stained_glass
setblock 428 224 361 minecraft:green_stained_glass
fill 428 224 362 430 224 362 minecraft:lime_stained_glass
setblock 429 224 323 minecraft:lime_stained_glass
setblock 429 224 324 minecraft:green_stained_glass
fill 429 224 325 429 224 327 minecraft:lime_stained_glass
setblock 429 224 328 minecraft:green_stained_glass
fill 429 224 329 429 224 331 minecraft:lime_stained_glass
setblock 429 224 332 minecraft:green_stained_glass
fill 429 224 333 429 224 335 minecraft:lime_stained_glass
setblock 429 224 336 minecraft:green_stained_glass
fill 429 224 337 429 224 339 minecraft:lime_stained_glass
setblock 429 224 340 minecraft:green_stained_glass
fill 429 224 341 429 224 343 minecraft:lime_stained_glass
setblock 429 224 344 minecraft:green_stained_glass
fill 429 224 345 429 224 347 minecraft:lime_stained_glass
setblock 429 224 348 minecraft:green_stained_glass
fill 429 224 349 429 224 351 minecraft:lime_stained_glass
setblock 429 224 352 minecraft:green_stained_glass
fill 429 224 353 429 224 355 minecraft:lime_stained_glass
setblock 429 224 356 minecraft:green_stained_glass
fill 429 224 357 431 224 357 minecraft:lime_stained_glass
setblock 429 224 360 minecraft:green_stained_glass
fill 429 224 361 431 224 361 minecraft:lime_stained_glass
setblock 430 224 323 minecraft:green_stained_glass
fill 430 224 324 430 224 326 minecraft:lime_stained_glass
setblock 430 224 327 minecraft:green_stained_glass
fill 430 224 328 430 224 330 minecraft:lime_stained_glass
setblock 430 224 331 minecraft:green_stained_glass
fill 430 224 332 430 224 334 minecraft:lime_stained_glass
schedule function dropper:buildpart/81_2 1t
