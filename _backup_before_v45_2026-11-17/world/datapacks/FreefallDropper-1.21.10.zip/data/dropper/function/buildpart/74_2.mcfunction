setblock 95 114 351 minecraft:stripped_spruce_log
fill 95 114 352 95 117 352 minecraft:stone
setblock 95 114 356 minecraft:stripped_spruce_log
fill 96 114 323 96 114 324 minecraft:stone
setblock 96 114 325 minecraft:stripped_spruce_log
fill 96 114 326 96 117 326 minecraft:stone
setblock 96 114 330 minecraft:stripped_spruce_log
fill 96 114 331 96 117 331 minecraft:stone
setblock 96 114 334 minecraft:stone
setblock 96 114 335 minecraft:stripped_spruce_log
fill 96 114 336 96 114 339 minecraft:stone
setblock 96 114 340 minecraft:stripped_spruce_log
fill 96 114 341 96 117 341 minecraft:stone
setblock 96 114 345 minecraft:stripped_spruce_log
fill 96 114 346 96 117 346 minecraft:stone
setblock 96 114 349 minecraft:stone
setblock 96 114 350 minecraft:stripped_spruce_log
fill 96 114 351 96 117 351 minecraft:stone
setblock 96 114 354 minecraft:stone
setblock 96 114 355 minecraft:stripped_spruce_log
setblock 96 114 359 minecraft:raw_gold_block
setblock 97 114 323 minecraft:stone
setblock 97 114 324 minecraft:stripped_spruce_log
fill 97 114 325 97 117 325 minecraft:stone
setblock 97 114 329 minecraft:stripped_spruce_log
fill 97 114 330 97 117 330 minecraft:stone
setblock 97 114 333 minecraft:stone
setblock 97 114 334 minecraft:stripped_spruce_log
fill 97 114 335 97 116 336 minecraft:stone
setblock 97 114 343 minecraft:stone
setblock 97 114 344 minecraft:stripped_spruce_log
fill 97 114 345 97 116 345 minecraft:stone
setblock 97 114 349 minecraft:stripped_spruce_log
fill 97 114 350 97 117 350 minecraft:stone
fill 97 114 352 97 115 352 minecraft:stone
setblock 98 114 323 minecraft:stripped_spruce_log
fill 98 114 324 101 114 324 minecraft:stone
setblock 98 114 327 minecraft:stone
setblock 98 114 328 minecraft:stripped_spruce_log
fill 98 114 329 98 117 329 minecraft:stone
fill 98 114 331 98 114 332 minecraft:stone
setblock 98 114 333 minecraft:stripped_spruce_log
fill 99 114 323 102 114 323 minecraft:stone
setblock 99 114 326 minecraft:stone
fill 99 114 363 101 115 363 minecraft:stone
setblock 100 114 326 minecraft:stripped_spruce_log
setblock 101 114 325 minecraft:stripped_spruce_log
fill 101 114 326 101 116 326 minecraft:stone
setblock 102 114 324 minecraft:stripped_spruce_log
fill 102 114 325 102 117 325 minecraft:stone
setblock 103 114 323 minecraft:stripped_spruce_log
fill 103 114 324 106 114 324 minecraft:stone
fill 104 114 323 107 114 323 minecraft:stone
setblock 107 114 324 minecraft:stripped_spruce_log
setblock 108 114 323 minecraft:stripped_spruce_log
fill 108 114 324 111 114 324 minecraft:stone
fill 109 114 323 112 114 323 minecraft:stone
setblock 111 114 322 minecraft:diamond_block
setblock 112 114 324 minecraft:stripped_spruce_log
setblock 113 114 323 minecraft:stripped_spruce_log
fill 113 114 324 113 117 324 minecraft:stone
setblock 113 114 363 minecraft:stripped_spruce_log
fill 114 114 323 117 114 323 minecraft:stone
fill 114 114 363 117 114 363 minecraft:stone
fill 115 114 360 115 114 362 minecraft:iron_bars
fill 115 114 364 116 124 364 minecraft:cobbled_deepslate
setblock 116 114 324 minecraft:stone
setblock 116 114 325 minecraft:stripped_spruce_log
fill 116 114 362 118 114 362 minecraft:stone
setblock 117 114 324 minecraft:stripped_spruce_log
fill 117 114 325 117 117 325 minecraft:stone
setblock 117 114 364 minecraft:diamond_block
setblock 118 114 323 minecraft:stripped_spruce_log
fill 118 114 324 121 114 324 minecraft:stone
fill 118 114 326 119 114 326 minecraft:stone
setblock 118 114 363 minecraft:stripped_spruce_log
fill 118 114 364 118 125 364 minecraft:cobbled_deepslate
fill 119 114 323 122 114 323 minecraft:stone
setblock 119 114 362 minecraft:stripped_spruce_log
fill 119 114 363 122 114 363 minecraft:stone
fill 120 114 362 120 117 362 minecraft:stone
setblock 121 114 325 minecraft:stripped_spruce_log
setblock 122 114 324 minecraft:stripped_spruce_log
setblock 122 114 325 minecraft:stone
setblock 123 114 323 minecraft:stripped_spruce_log
fill 123 114 324 123 115 324 minecraft:stone
setblock 123 114 363 minecraft:stripped_spruce_log
fill 124 114 323 124 116 323 minecraft:stone
setblock 124 114 362 minecraft:stripped_spruce_log
fill 124 114 363 124 117 363 minecraft:stone
fill 128 114 364 128 125 364 minecraft:cobbled_deepslate
setblock 133 114 348 minecraft:stripped_spruce_log
fill 133 114 349 133 117 349 minecraft:stone
setblock 133 114 352 minecraft:stone
setblock 133 114 353 minecraft:stripped_spruce_log
setblock 134 114 347 minecraft:stripped_spruce_log
fill 134 114 348 134 117 348 minecraft:stone
setblock 134 114 352 minecraft:stripped_spruce_log
fill 134 114 353 134 117 353 minecraft:stone
fill 134 114 355 134 114 356 minecraft:stone
setblock 135 114 322 minecraft:raw_gold_block
fill 135 114 324 135 114 325 minecraft:stone
setblock 135 114 326 minecraft:stripped_spruce_log
fill 135 114 327 135 117 327 minecraft:stone
setblock 135 114 330 minecraft:stone
setblock 135 114 331 minecraft:stripped_spruce_log
fill 135 114 332 135 117 332 minecraft:stone
fill 135 114 334 135 114 335 minecraft:stone
setblock 135 114 336 minecraft:stripped_spruce_log
fill 135 114 337 135 114 340 minecraft:stone
setblock 135 114 341 minecraft:stripped_spruce_log
fill 135 114 342 135 117 342 minecraft:stone
setblock 135 114 346 minecraft:stripped_spruce_log
fill 135 114 347 135 117 347 minecraft:stone
setblock 135 114 351 minecraft:stripped_spruce_log
fill 135 114 352 135 117 352 minecraft:stone
setblock 135 114 356 minecraft:stripped_spruce_log
fill 135 114 357 135 117 357 minecraft:stone
fill 135 114 359 135 115 359 minecraft:stone
fill 136 114 335 136 125 335 minecraft:cobbled_deepslate
setblock 136 114 342 minecraft:gold_block
fill 94 115 323 94 121 323 minecraft:cobbled_deepslate
fill 95 115 323 95 115 324 minecraft:stone
setblock 95 115 325 minecraft:stripped_spruce_log
fill 95 115 326 95 118 326 minecraft:stone
setblock 95 115 330 minecraft:stripped_spruce_log
fill 95 115 331 95 115 334 minecraft:stone
setblock 95 115 335 minecraft:stripped_spruce_log
fill 95 115 336 95 115 339 minecraft:stone
setblock 95 115 340 minecraft:stripped_spruce_log
fill 95 115 341 95 118 341 minecraft:stone
setblock 95 115 345 minecraft:stripped_spruce_log
fill 95 115 346 95 118 346 minecraft:stone
setblock 95 115 350 minecraft:stripped_spruce_log
fill 95 115 351 95 118 351 minecraft:stone
setblock 95 115 355 minecraft:stripped_spruce_log
fill 95 115 356 95 116 358 minecraft:stone
setblock 96 115 323 minecraft:stone
setblock 96 115 324 minecraft:stripped_spruce_log
fill 96 115 325 96 118 325 minecraft:stone
setblock 96 115 328 minecraft:stone
setblock 96 115 329 minecraft:stripped_spruce_log
fill 96 115 330 96 118 330 minecraft:stone
setblock 96 115 334 minecraft:stripped_spruce_log
fill 96 115 335 96 115 338 minecraft:stone
setblock 96 115 339 minecraft:stripped_spruce_log
fill 96 115 340 96 118 340 minecraft:stone
setblock 96 115 344 minecraft:stripped_spruce_log
fill 96 115 345 96 118 345 minecraft:stone
setblock 96 115 349 minecraft:stripped_spruce_log
fill 96 115 350 96 118 350 minecraft:stone
setblock 96 115 354 minecraft:stripped_spruce_log
fill 96 115 355 96 117 356 minecraft:stone
setblock 97 115 323 minecraft:stripped_spruce_log
fill 97 115 324 100 115 324 minecraft:stone
setblock 97 115 328 minecraft:stripped_spruce_log
fill 97 115 329 97 118 329 minecraft:stone
setblock 97 115 333 minecraft:stripped_spruce_log
fill 97 115 334 98 117 334 minecraft:stone
setblock 97 115 337 minecraft:stone
setblock 97 115 338 minecraft:stripped_spruce_log
setblock 97 115 339 minecraft:light[level=12]
setblock 97 115 341 minecraft:light[level=15]
setblock 97 115 343 minecraft:stripped_spruce_log
fill 97 115 344 97 116 344 minecraft:stone
setblock 97 115 348 minecraft:stripped_spruce_log
fill 97 115 349 97 118 349 minecraft:stone
setblock 97 115 353 minecraft:stripped_spruce_log
setblock 97 115 357 minecraft:light[level=15]
setblock 97 115 360 minecraft:light[level=12]
fill 98 115 323 101 115 323 minecraft:stone
setblock 98 115 326 minecraft:stone
setblock 98 115 327 minecraft:stripped_spruce_log
fill 98 115 328 98 118 328 minecraft:stone
setblock 98 115 331 minecraft:stone
setblock 98 115 332 minecraft:stripped_spruce_log
fill 98 115 333 98 118 333 minecraft:stone
fill 98 115 335 98 116 335 minecraft:stone
fill 98 115 363 98 118 363 minecraft:stone
setblock 99 115 326 minecraft:stripped_spruce_log
fill 99 115 329 99 115 330 minecraft:stone
setblock 99 115 331 minecraft:stripped_spruce_log
fill 99 115 358 99 119 358 minecraft:cobbled_deepslate
fill 99 115 364 102 121 364 minecraft:cobbled_deepslate
setblock 100 115 325 minecraft:stripped_spruce_log
fill 100 115 326 100 116 326 minecraft:stone
setblock 101 115 324 minecraft:stripped_spruce_log
fill 101 115 325 101 117 325 minecraft:stone
setblock 102 115 323 minecraft:stripped_spruce_log
fill 102 115 324 105 115 324 minecraft:stone
fill 103 115 323 106 115 323 minecraft:stone
setblock 103 115 364 minecraft:diamond_block
setblock 104 115 332 minecraft:light[level=12]
setblock 104 115 339 minecraft:light[level=12]
setblock 104 115 346 minecraft:light[level=12]
setblock 104 115 353 minecraft:light[level=12]
setblock 104 115 360 minecraft:light[level=12]
fill 104 115 364 105 121 364 minecraft:cobbled_deepslate
setblock 105 115 325 minecraft:light[level=15]
setblock 105 115 333 minecraft:light[level=15]
setblock 105 115 341 minecraft:light[level=15]
setblock 105 115 349 minecraft:light[level=15]
setblock 105 115 357 minecraft:light[level=15]
setblock 106 115 324 minecraft:stripped_spruce_log
setblock 107 115 323 minecraft:stripped_spruce_log
fill 107 115 324 110 115 324 minecraft:stone
fill 108 115 323 111 115 323 minecraft:stone
setblock 111 115 322 minecraft:cobbled_deepslate
setblock 111 115 324 minecraft:stripped_spruce_log
setblock 111 115 325 minecraft:light[level=12]
setblock 111 115 332 minecraft:light[level=12]
setblock 111 115 339 minecraft:light[level=12]
setblock 111 115 346 minecraft:light[level=12]
setblock 111 115 353 minecraft:light[level=12]
setblock 111 115 360 minecraft:light[level=12]
setblock 112 115 323 minecraft:stripped_spruce_log
fill 112 115 324 112 118 324 minecraft:stone
setblock 112 115 363 minecraft:stripped_spruce_log
fill 113 115 323 116 115 323 minecraft:stone
fill 113 115 325 113 116 325 minecraft:stone
setblock 113 115 333 minecraft:light[level=15]
setblock 113 115 341 minecraft:light[level=15]
setblock 113 115 349 minecraft:light[level=15]
setblock 113 115 357 minecraft:light[level=15]
fill 113 115 363 116 115 363 minecraft:stone
setblock 115 115 324 minecraft:stone
setblock 115 115 325 minecraft:stripped_spruce_log
fill 115 115 360 115 115 361 minecraft:iron_bars
fill 115 115 362 117 115 362 minecraft:stone
setblock 116 115 324 minecraft:stripped_spruce_log
fill 116 115 325 116 118 325 minecraft:stone
setblock 117 115 323 minecraft:stripped_spruce_log
fill 117 115 324 120 115 324 minecraft:stone
fill 117 115 326 118 115 326 minecraft:stone
setblock 117 115 363 minecraft:stripped_spruce_log
fill 117 115 364 117 122 364 minecraft:cobbled_deepslate
fill 118 115 323 121 115 323 minecraft:stone
setblock 118 115 332 minecraft:light[level=12]
setblock 118 115 346 minecraft:light[level=12]
setblock 118 115 353 minecraft:light[level=12]
setblock 118 115 360 minecraft:light[level=12]
setblock 118 115 361 minecraft:stone
setblock 118 115 362 minecraft:stripped_spruce_log
fill 118 115 363 121 115 363 minecraft:stone
setblock 119 115 361 minecraft:stripped_spruce_log
fill 119 115 362 119 118 362 minecraft:stone
setblock 120 115 325 minecraft:stripped_spruce_log
fill 120 115 361 120 118 361 minecraft:stone
setblock 121 115 324 minecraft:stripped_spruce_log
setblock 121 115 325 minecraft:stone
setblock 121 115 333 minecraft:light[level=15]
setblock 121 115 341 minecraft:light[level=15]
setblock 121 115 349 minecraft:light[level=15]
setblock 121 115 357 minecraft:light[level=15]
setblock 122 115 323 minecraft:stripped_spruce_log
fill 122 115 324 122 116 324 minecraft:stone
setblock 122 115 363 minecraft:stripped_spruce_log
fill 123 115 323 123 117 323 minecraft:stone
setblock 123 115 362 minecraft:stripped_spruce_log
fill 123 115 363 123 118 363 minecraft:stone
setblock 125 115 325 minecraft:light[level=12]
setblock 125 115 332 minecraft:light[level=12]
setblock 125 115 339 minecraft:light[level=12]
setblock 125 115 346 minecraft:light[level=12]
setblock 125 115 353 minecraft:light[level=12]
setblock 125 115 360 minecraft:light[level=12]
setblock 129 115 325 minecraft:light[level=15]
setblock 129 115 341 minecraft:light[level=15]
setblock 129 115 349 minecraft:light[level=15]
setblock 129 115 357 minecraft:light[level=15]
setblock 132 115 325 minecraft:light[level=12]
setblock 132 115 332 minecraft:light[level=12]
setblock 132 115 339 minecraft:light[level=12]
setblock 132 115 346 minecraft:light[level=12]
setblock 132 115 353 minecraft:light[level=12]
setblock 132 115 360 minecraft:light[level=12]
setblock 133 115 347 minecraft:stripped_spruce_log
fill 133 115 348 133 118 348 minecraft:stone
setblock 133 115 352 minecraft:stripped_spruce_log
fill 133 115 353 133 117 354 minecraft:stone
fill 134 115 328 134 115 330 minecraft:stone
setblock 134 115 331 minecraft:stripped_spruce_log
fill 134 115 332 134 117 333 minecraft:stone
setblock 134 115 343 minecraft:stone
setblock 134 115 346 minecraft:stripped_spruce_log
fill 134 115 347 134 118 347 minecraft:stone
setblock 134 115 351 minecraft:stripped_spruce_log
fill 134 115 352 134 118 352 minecraft:stone
setblock 134 115 355 minecraft:stone
setblock 134 115 356 minecraft:stripped_spruce_log
fill 134 115 357 134 118 357 minecraft:stone
fill 135 115 322 135 125 322 minecraft:cobbled_deepslate
setblock 135 115 324 minecraft:stone
setblock 135 115 325 minecraft:stripped_spruce_log
fill 135 115 326 135 118 326 minecraft:stone
setblock 135 115 330 minecraft:stripped_spruce_log
fill 135 115 331 135 118 331 minecraft:stone
setblock 135 115 334 minecraft:stone
setblock 135 115 335 minecraft:stripped_spruce_log
fill 135 115 336 135 115 339 minecraft:stone
setblock 135 115 340 minecraft:stripped_spruce_log
fill 135 115 341 135 118 341 minecraft:stone
setblock 135 115 345 minecraft:stripped_spruce_log
fill 135 115 346 135 118 346 minecraft:stone
setblock 135 115 350 minecraft:stripped_spruce_log
fill 135 115 351 135 118 351 minecraft:stone
setblock 135 115 355 minecraft:stripped_spruce_log
fill 135 115 356 135 118 356 minecraft:stone
setblock 135 115 360 minecraft:stripped_spruce_log
fill 136 115 342 136 125 342 minecraft:cobbled_deepslate
setblock 95 116 323 minecraft:stone
setblock 95 116 324 minecraft:stripped_spruce_log
fill 95 116 325 95 119 325 minecraft:stone
setblock 95 116 329 minecraft:stripped_spruce_log
fill 95 116 330 95 116 333 minecraft:stone
setblock 95 116 334 minecraft:stripped_spruce_log
fill 95 116 335 95 116 338 minecraft:stone
setblock 95 116 339 minecraft:stripped_spruce_log
fill 95 116 340 95 119 340 minecraft:stone
setblock 95 116 344 minecraft:stripped_spruce_log
fill 95 116 345 95 119 345 minecraft:stone
setblock 95 116 349 minecraft:stripped_spruce_log
fill 95 116 350 95 119 350 minecraft:stone
setblock 95 116 353 minecraft:stone
setblock 95 116 354 minecraft:stripped_spruce_log
fill 95 116 355 95 119 355 minecraft:stone
setblock 95 116 359 minecraft:stripped_spruce_log
setblock 96 116 323 minecraft:stripped_spruce_log
fill 96 116 324 96 119 324 minecraft:spruce_log
setblock 96 116 328 minecraft:stripped_spruce_log
fill 96 116 329 96 119 329 minecraft:stone
setblock 96 116 332 minecraft:stone
setblock 96 116 333 minecraft:stripped_spruce_log
fill 96 116 334 96 116 337 minecraft:stone
setblock 96 116 338 minecraft:stripped_spruce_log
fill 96 116 339 97 118 339 minecraft:stone
fill 96 116 343 96 119 343 minecraft:spruce_log
fill 96 116 344 96 119 344 minecraft:stone
setblock 96 116 348 minecraft:stripped_spruce_log
fill 96 116 349 96 119 349 minecraft:stone
setblock 96 116 353 minecraft:stripped_spruce_log
fill 96 116 354 97 118 354 minecraft:stone
setblock 96 116 357 minecraft:stone
fill 96 116 362 96 119 362 minecraft:spruce_log
fill 97 116 323 99 116 324 minecraft:stone
setblock 97 116 327 minecraft:stripped_spruce_log
fill 97 116 328 97 119 328 minecraft:stone
setblock 97 116 332 minecraft:stripped_spruce_log
fill 97 116 333 97 119 333 minecraft:stone
setblock 97 116 337 minecraft:stripped_spruce_log
fill 97 116 338 97 119 338 minecraft:stone
fill 97 116 340 97 117 340 minecraft:stone
setblock 97 116 347 minecraft:stripped_spruce_log
fill 97 116 348 97 118 348 minecraft:stone
setblock 97 116 352 minecraft:stripped_spruce_log
fill 97 116 353 97 119 353 minecraft:stone
fill 97 116 363 97 119 363 minecraft:stone
setblock 98 116 326 minecraft:stripped_spruce_log
fill 98 116 327 98 118 327 minecraft:stone
setblock 98 116 331 minecraft:stripped_spruce_log
fill 98 116 332 99 118 332 minecraft:stone
setblock 98 116 336 minecraft:stripped_spruce_log
setblock 99 116 325 minecraft:stripped_spruce_log
setblock 99 116 326 minecraft:stone
setblock 99 116 329 minecraft:stone
setblock 99 116 330 minecraft:stripped_spruce_log
fill 99 116 331 99 118 331 minecraft:stone
fill 99 116 363 100 116 363 minecraft:stone
setblock 100 116 323 minecraft:stone
setblock 100 116 324 minecraft:stripped_spruce_log
fill 100 116 325 100 118 325 minecraft:stone
setblock 101 116 323 minecraft:stripped_spruce_log
fill 101 116 324 104 116 324 minecraft:stone
setblock 101 116 363 minecraft:stripped_spruce_log
fill 102 116 323 105 116 323 minecraft:stone
fill 103 116 364 103 125 364 minecraft:cobbled_deepslate
setblock 105 116 324 minecraft:stripped_spruce_log
setblock 106 116 323 minecraft:stripped_spruce_log
fill 106 116 324 107 116 324 minecraft:stone
fill 107 116 323 110 116 323 minecraft:stone
setblock 110 116 324 minecraft:stripped_spruce_log
setblock 111 116 322 minecraft:diamond_block
setblock 111 116 323 minecraft:stripped_spruce_log
fill 111 116 324 111 118 324 minecraft:stone
fill 112 116 323 115 116 323 minecraft:stone
fill 112 116 363 115 116 363 minecraft:stone
setblock 114 116 324 minecraft:stone
setblock 114 116 325 minecraft:stripped_spruce_log
fill 114 116 362 114 118 362 minecraft:stone
fill 115 116 324 115 119 324 minecraft:spruce_log
fill 115 116 325 115 118 325 minecraft:stone
fill 115 116 362 115 119 362 minecraft:spruce_log
setblock 116 116 323 minecraft:stripped_spruce_log
fill 116 116 324 119 116 324 minecraft:stone
setblock 116 116 362 minecraft:stone
setblock 116 116 363 minecraft:stripped_spruce_log
fill 117 116 323 120 116 323 minecraft:stone
setblock 117 116 361 minecraft:stone
setblock 117 116 362 minecraft:stripped_spruce_log
fill 117 116 363 120 116 363 minecraft:stone
setblock 118 116 361 minecraft:stripped_spruce_log
fill 118 116 362 118 119 362 minecraft:stone
setblock 119 116 325 minecraft:stripped_spruce_log
fill 119 116 361 119 119 361 minecraft:stone
setblock 120 116 324 minecraft:stripped_spruce_log
setblock 120 116 325 minecraft:stone
setblock 121 116 323 minecraft:stripped_spruce_log
fill 121 116 324 121 117 324 minecraft:stone
setblock 121 116 361 minecraft:stone
setblock 121 116 363 minecraft:stripped_spruce_log
fill 122 116 323 122 118 323 minecraft:stone
setblock 122 116 362 minecraft:stripped_spruce_log
fill 122 116 363 122 119 363 minecraft:stone
fill 123 116 362 123 117 362 minecraft:stone
fill 133 116 347 133 118 347 minecraft:stone
setblock 133 116 350 minecraft:stone
setblock 133 116 351 minecraft:stripped_spruce_log
fill 133 116 352 133 119 352 minecraft:stone
setblock 133 116 355 minecraft:stone
fill 134 116 324 134 119 324 minecraft:spruce_log
fill 134 116 328 134 116 329 minecraft:stone
setblock 134 116 330 minecraft:stripped_spruce_log
fill 134 116 331 134 119 331 minecraft:stone
setblock 134 116 334 minecraft:stone
setblock 134 116 335 minecraft:stripped_spruce_log
fill 134 116 336 135 118 336 minecraft:stone
fill 134 116 342 134 118 342 minecraft:stone
fill 134 116 343 134 119 343 minecraft:spruce_log
setblock 134 116 345 minecraft:stripped_spruce_log
fill 134 116 346 134 119 346 minecraft:stone
setblock 134 116 350 minecraft:stripped_spruce_log
fill 134 116 351 134 119 351 minecraft:stone
setblock 134 116 355 minecraft:stripped_spruce_log
fill 134 116 356 134 119 356 minecraft:stone
fill 134 116 358 134 117 358 minecraft:stone
fill 134 116 362 134 119 362 minecraft:spruce_log
setblock 135 116 323 minecraft:stone
setblock 135 116 324 minecraft:stripped_spruce_log
fill 135 116 325 135 119 325 minecraft:stone
setblock 135 116 329 minecraft:stripped_spruce_log
fill 135 116 330 135 119 330 minecraft:stone
setblock 135 116 334 minecraft:stripped_spruce_log
fill 135 116 335 135 119 335 minecraft:stone
fill 135 116 337 135 116 338 minecraft:stone
setblock 135 116 339 minecraft:stripped_spruce_log
fill 135 116 340 135 119 340 minecraft:stone
setblock 135 116 344 minecraft:stripped_spruce_log
fill 135 116 345 135 119 345 minecraft:stone
setblock 135 116 349 minecraft:stripped_spruce_log
fill 135 116 350 135 119 350 minecraft:stone
setblock 135 116 354 minecraft:stripped_spruce_log
fill 135 116 355 135 119 355 minecraft:stone
setblock 135 116 359 minecraft:stripped_spruce_log
fill 135 116 360 135 117 362 minecraft:stone
setblock 95 117 323 minecraft:stripped_spruce_log
fill 95 117 324 95 120 324 minecraft:stone
setblock 95 117 328 minecraft:stripped_spruce_log
fill 95 117 329 95 117 332 minecraft:stone
setblock 95 117 333 minecraft:stripped_spruce_log
fill 95 117 334 95 117 337 minecraft:stone
setblock 95 117 338 minecraft:stripped_spruce_log
fill 95 117 339 95 120 339 minecraft:stone
setblock 95 117 343 minecraft:stripped_spruce_log
fill 95 117 344 95 120 344 minecraft:stone
setblock 95 117 348 minecraft:stripped_spruce_log
fill 95 117 349 95 120 349 minecraft:stone
setblock 95 117 353 minecraft:stripped_spruce_log
fill 95 117 354 95 120 354 minecraft:stone
fill 95 117 356 95 117 357 minecraft:stone
setblock 95 117 358 minecraft:stripped_spruce_log
fill 95 117 359 95 119 360 minecraft:stone
fill 96 117 323 99 117 323 minecraft:stone
setblock 96 117 327 minecraft:stripped_spruce_log
fill 96 117 328 96 120 328 minecraft:stone
setblock 96 117 332 minecraft:stripped_spruce_log
fill 96 117 333 96 117 336 minecraft:stone
setblock 96 117 337 minecraft:stripped_spruce_log
fill 96 117 338 96 120 338 minecraft:stone
setblock 96 117 342 minecraft:stripped_spruce_log
setblock 96 117 347 minecraft:stripped_spruce_log
fill 96 117 348 96 120 348 minecraft:stone
setblock 96 117 352 minecraft:stripped_spruce_log
fill 96 117 353 96 120 353 minecraft:stone
setblock 96 117 357 minecraft:stripped_spruce_log
fill 97 117 324 98 117 324 minecraft:stone
setblock 97 117 326 minecraft:stripped_spruce_log
fill 97 117 327 97 120 327 minecraft:stone
setblock 97 117 331 minecraft:stripped_spruce_log
fill 97 117 332 97 120 332 minecraft:stone
setblock 97 117 335 minecraft:stone
setblock 97 117 336 minecraft:stripped_spruce_log
fill 97 117 337 97 120 337 minecraft:stone
setblock 97 117 346 minecraft:stripped_spruce_log
setblock 97 117 347 minecraft:stone
setblock 97 117 351 minecraft:stripped_spruce_log
fill 97 117 352 97 119 352 minecraft:stone
setblock 97 117 355 minecraft:stone
setblock 98 117 325 minecraft:stripped_spruce_log
setblock 98 117 330 minecraft:stripped_spruce_log
fill 98 117 331 98 120 331 minecraft:stone
setblock 98 117 335 minecraft:stripped_spruce_log
fill 98 117 336 98 120 336 minecraft:stone
fill 98 117 358 98 119 358 minecraft:cobbled_deepslate
setblock 99 117 324 minecraft:stripped_spruce_log
fill 99 117 325 99 118 325 minecraft:stone
setblock 99 117 329 minecraft:stripped_spruce_log
setblock 99 117 330 minecraft:stone
setblock 99 117 333 minecraft:stone
fill 99 117 357 99 119 357 minecraft:cobbled_deepslate
fill 99 117 359 99 119 359 minecraft:cobbled_deepslate
setblock 99 117 363 minecraft:stone
setblock 100 117 323 minecraft:stripped_spruce_log
fill 100 117 324 103 117 324 minecraft:stone
fill 100 117 358 100 119 358 minecraft:cobbled_deepslate
setblock 100 117 363 minecraft:stripped_spruce_log
fill 101 117 323 104 117 323 minecraft:stone
setblock 104 117 324 minecraft:stripped_spruce_log
setblock 105 117 323 minecraft:stripped_spruce_log
setblock 105 117 324 minecraft:stone
fill 106 117 323 109 117 323 minecraft:stone
setblock 110 117 323 minecraft:stripped_spruce_log
fill 111 117 322 111 122 322 minecraft:cobbled_deepslate
fill 111 117 323 114 117 323 minecraft:stone
fill 111 117 363 114 117 363 minecraft:stone
setblock 114 117 324 minecraft:stripped_spruce_log
setblock 114 117 325 minecraft:stone
setblock 115 117 323 minecraft:stripped_spruce_log
setblock 115 117 363 minecraft:stripped_spruce_log
fill 116 117 323 118 117 324 minecraft:stone
setblock 116 117 361 minecraft:stone
setblock 116 117 362 minecraft:stripped_spruce_log
fill 116 117 363 119 117 363 minecraft:stone
fill 117 117 326 119 118 328 minecraft:iron_block
setblock 117 117 361 minecraft:stripped_spruce_log
fill 117 117 362 117 120 362 minecraft:stone
setblock 118 117 325 minecraft:stripped_spruce_log
fill 118 117 361 118 120 361 minecraft:stone
setblock 119 117 323 minecraft:stone
setblock 119 117 324 minecraft:stripped_spruce_log
setblock 119 117 325 minecraft:stone
setblock 120 117 323 minecraft:stripped_spruce_log
fill 120 117 324 120 118 324 minecraft:stone
setblock 120 117 363 minecraft:stripped_spruce_log
fill 121 117 323 121 119 323 minecraft:stone
setblock 121 117 362 minecraft:stripped_spruce_log
fill 121 117 363 121 120 363 minecraft:stone
fill 122 117 362 122 118 362 minecraft:stone
setblock 125 117 363 minecraft:stripped_spruce_log
setblock 133 117 350 minecraft:stripped_spruce_log
fill 133 117 351 133 120 351 minecraft:stone
setblock 133 117 355 minecraft:stripped_spruce_log
fill 133 117 356 133 120 356 minecraft:stone
fill 134 117 327 134 117 328 minecraft:stone
setblock 134 117 329 minecraft:stripped_spruce_log
fill 134 117 330 134 120 330 minecraft:stone
setblock 134 117 334 minecraft:stripped_spruce_log
fill 134 117 335 134 120 335 minecraft:stone
fill 134 117 337 134 117 338 minecraft:stone
setblock 134 117 339 minecraft:stripped_spruce_log
fill 134 117 340 134 119 341 minecraft:stone
setblock 134 117 344 minecraft:stripped_spruce_log
fill 134 117 345 134 120 345 minecraft:stone
setblock 134 117 349 minecraft:stripped_spruce_log
fill 134 117 350 134 120 350 minecraft:stone
setblock 134 117 354 minecraft:stripped_spruce_log
fill 134 117 355 134 120 355 minecraft:stone
setblock 134 117 359 minecraft:stripped_spruce_log
fill 135 117 324 135 118 324 minecraft:stone
setblock 135 117 328 minecraft:stripped_spruce_log
fill 135 117 329 135 120 329 minecraft:stone
setblock 135 117 333 minecraft:stripped_spruce_log
fill 135 117 334 135 120 334 minecraft:stone
setblock 135 117 337 minecraft:stone
setblock 135 117 338 minecraft:stripped_spruce_log
fill 135 117 339 135 120 339 minecraft:stone
setblock 135 117 343 minecraft:stripped_spruce_log
fill 135 117 344 135 120 344 minecraft:stone
setblock 135 117 348 minecraft:stripped_spruce_log
fill 135 117 349 135 120 349 minecraft:stone
setblock 135 117 353 minecraft:stripped_spruce_log
fill 135 117 354 135 120 354 minecraft:stone
setblock 135 117 358 minecraft:stripped_spruce_log
fill 135 117 359 135 120 359 minecraft:stone
fill 94 118 326 94 125 328 minecraft:cobbled_deepslate
setblock 94 118 329 minecraft:diamond_block
fill 94 118 330 94 125 330 minecraft:cobbled_deepslate
fill 95 118 323 98 118 323 minecraft:stone
setblock 95 118 327 minecraft:stripped_spruce_log
fill 95 118 328 95 118 331 minecraft:stone
setblock 95 118 332 minecraft:stripped_spruce_log
fill 95 118 333 95 118 336 minecraft:stone
setblock 95 118 337 minecraft:stripped_spruce_log
fill 95 118 338 95 121 338 minecraft:stone
setblock 95 118 342 minecraft:stripped_spruce_log
fill 95 118 343 95 121 343 minecraft:stone
setblock 95 118 347 minecraft:stripped_spruce_log
fill 95 118 348 95 121 348 minecraft:stone
setblock 95 118 352 minecraft:stripped_spruce_log
fill 95 118 353 95 121 353 minecraft:stone
setblock 95 118 356 minecraft:stone
setblock 95 118 357 minecraft:stripped_spruce_log
fill 95 118 358 96 120 358 minecraft:stone
setblock 95 118 361 minecraft:stone
setblock 96 118 322 minecraft:gold_block
setblock 96 118 326 minecraft:stripped_spruce_log
fill 96 118 327 96 121 327 minecraft:stone
setblock 96 118 331 minecraft:stripped_spruce_log
fill 96 118 332 96 118 335 minecraft:stone
setblock 96 118 336 minecraft:stripped_spruce_log
fill 96 118 337 96 121 337 minecraft:stone
setblock 96 118 341 minecraft:stripped_spruce_log
fill 96 118 342 96 121 342 minecraft:stone
setblock 96 118 346 minecraft:stripped_spruce_log
fill 96 118 347 96 120 347 minecraft:stone
setblock 96 118 351 minecraft:stripped_spruce_log
fill 96 118 352 96 121 352 minecraft:stone
setblock 96 118 355 minecraft:stone
setblock 96 118 356 minecraft:stripped_spruce_log
fill 96 118 357 96 121 357 minecraft:stone
setblock 97 118 324 minecraft:stone
setblock 97 118 325 minecraft:stripped_spruce_log
fill 97 118 326 97 119 326 minecraft:stone
setblock 97 118 330 minecraft:stripped_spruce_log
fill 97 118 331 97 121 331 minecraft:stone
setblock 97 118 334 minecraft:stone
setblock 97 118 335 minecraft:stripped_spruce_log
fill 97 118 336 97 121 336 minecraft:stone
setblock 97 118 340 minecraft:stripped_spruce_log
setblock 97 118 350 minecraft:stripped_spruce_log
fill 97 118 351 97 119 351 minecraft:stone
setblock 97 118 355 minecraft:stripped_spruce_log
setblock 98 118 324 minecraft:stripped_spruce_log
setblock 98 118 325 minecraft:stone
setblock 98 118 329 minecraft:stripped_spruce_log
fill 98 118 330 98 120 330 minecraft:stone
setblock 98 118 334 minecraft:stripped_spruce_log
fill 98 118 335 98 121 335 minecraft:stone
setblock 98 118 337 minecraft:stone
fill 98 118 357 98 119 357 minecraft:cobbled_deepslate
fill 98 118 359 98 119 359 minecraft:cobbled_deepslate
setblock 99 118 323 minecraft:stripped_spruce_log
fill 99 118 324 102 118 324 minecraft:stone
setblock 99 118 333 minecraft:stripped_spruce_log
setblock 99 118 363 minecraft:stripped_spruce_log
fill 100 118 323 103 118 323 minecraft:stone
fill 100 118 357 100 119 357 minecraft:cobbled_deepslate
fill 100 118 359 100 119 359 minecraft:cobbled_deepslate
setblock 103 118 324 minecraft:stripped_spruce_log
setblock 104 118 323 minecraft:stripped_spruce_log
fill 105 118 323 108 118 323 minecraft:stone
setblock 109 118 323 minecraft:stripped_spruce_log
fill 110 118 323 113 118 323 minecraft:stone
fill 111 118 363 113 118 363 minecraft:stone
setblock 113 118 324 minecraft:stripped_spruce_log
fill 113 118 362 113 119 362 minecraft:stone
setblock 114 118 323 minecraft:stripped_spruce_log
fill 114 118 324 114 120 324 minecraft:stone
setblock 114 118 363 minecraft:stripped_spruce_log
fill 115 118 323 118 118 323 minecraft:stone
setblock 115 118 361 minecraft:stone
fill 115 118 363 118 118 363 minecraft:stone
fill 116 118 324 117 118 324 minecraft:stone
setblock 116 118 361 minecraft:stripped_spruce_log
fill 116 118 362 116 121 362 minecraft:stone
setblock 117 118 325 minecraft:stripped_spruce_log
fill 117 118 361 117 121 361 minecraft:stone
setblock 118 118 324 minecraft:stripped_spruce_log
setblock 119 118 323 minecraft:stripped_spruce_log
setblock 119 118 324 minecraft:stone
setblock 119 118 363 minecraft:stripped_spruce_log
fill 120 118 323 120 119 323 minecraft:stone
setblock 120 118 362 minecraft:stripped_spruce_log
fill 120 118 363 120 121 363 minecraft:stone
fill 121 118 362 121 120 362 minecraft:stone
setblock 124 118 363 minecraft:stripped_spruce_log
setblock 133 118 349 minecraft:stripped_spruce_log
fill 133 118 350 133 120 350 minecraft:stone
setblock 133 118 353 minecraft:stone
setblock 133 118 354 minecraft:stripped_spruce_log
fill 133 118 355 133 121 355 minecraft:stone
setblock 134 118 328 minecraft:stripped_spruce_log
fill 134 118 329 134 121 329 minecraft:stone
setblock 134 118 332 minecraft:stone
setblock 134 118 333 minecraft:stripped_spruce_log
fill 134 118 334 134 121 334 minecraft:stone
setblock 134 118 337 minecraft:stone
setblock 134 118 338 minecraft:stripped_spruce_log
fill 134 118 339 134 121 339 minecraft:stone
fill 134 118 344 134 121 344 minecraft:stone
setblock 134 118 348 minecraft:stripped_spruce_log
fill 134 118 349 134 121 349 minecraft:stone
setblock 134 118 353 minecraft:stripped_spruce_log
fill 134 118 354 134 121 354 minecraft:stone
setblock 134 118 358 minecraft:stripped_spruce_log
fill 134 118 359 134 121 359 minecraft:stone
setblock 135 118 327 minecraft:stripped_spruce_log
fill 135 118 328 135 121 328 minecraft:stone
setblock 135 118 332 minecraft:stripped_spruce_log
fill 135 118 333 135 121 333 minecraft:stone
setblock 135 118 337 minecraft:stripped_spruce_log
fill 135 118 338 135 121 338 minecraft:stone
setblock 135 118 342 minecraft:stripped_spruce_log
fill 135 118 343 135 121 343 minecraft:stone
setblock 135 118 347 minecraft:stripped_spruce_log
fill 135 118 348 135 121 348 minecraft:stone
setblock 135 118 352 minecraft:stripped_spruce_log
fill 135 118 353 135 121 353 minecraft:stone
setblock 135 118 357 minecraft:stripped_spruce_log
fill 135 118 358 135 121 358 minecraft:stone
fill 135 118 360 135 118 361 minecraft:stone
setblock 135 118 362 minecraft:stripped_spruce_log
setblock 136 118 336 minecraft:raw_iron_block
fill 94 119 329 94 125 329 minecraft:cobbled_deepslate
fill 95 119 323 97 119 323 minecraft:stone
setblock 95 119 326 minecraft:stripped_spruce_log
fill 95 119 327 95 119 330 minecraft:stone
setblock 95 119 331 minecraft:stripped_spruce_log
fill 95 119 332 95 119 335 minecraft:stone
setblock 95 119 336 minecraft:stripped_spruce_log
fill 95 119 337 95 121 337 minecraft:stone
setblock 95 119 341 minecraft:stripped_spruce_log
fill 95 119 342 95 121 342 minecraft:stone
setblock 95 119 346 minecraft:stripped_spruce_log
fill 95 119 347 95 121 347 minecraft:stone
setblock 95 119 351 minecraft:stripped_spruce_log
fill 95 119 352 95 121 352 minecraft:stone
setblock 95 119 356 minecraft:stripped_spruce_log
fill 95 119 357 95 121 357 minecraft:stone
setblock 95 119 361 minecraft:stripped_spruce_log
fill 96 119 322 96 123 322 minecraft:cobbled_deepslate
setblock 96 119 325 minecraft:stripped_spruce_log
fill 96 119 326 96 121 326 minecraft:stone
setblock 96 119 330 minecraft:stripped_spruce_log
fill 96 119 331 96 119 334 minecraft:stone
setblock 96 119 335 minecraft:stripped_spruce_log
fill 96 119 336 96 121 336 minecraft:stone
setblock 96 119 339 minecraft:stone
setblock 96 119 340 minecraft:stripped_spruce_log
fill 96 119 341 96 121 341 minecraft:stone
setblock 96 119 345 minecraft:stripped_spruce_log
setblock 96 119 346 minecraft:stone
setblock 96 119 350 minecraft:stripped_spruce_log
fill 96 119 351 96 121 351 minecraft:stone
setblock 96 119 354 minecraft:stone
setblock 96 119 355 minecraft:stripped_spruce_log
fill 96 119 356 96 121 356 minecraft:stone
setblock 97 119 324 minecraft:stripped_spruce_log
setblock 97 119 329 minecraft:stripped_spruce_log
fill 97 119 330 97 122 330 minecraft:stone
setblock 97 119 334 minecraft:stripped_spruce_log
fill 97 119 335 97 122 335 minecraft:stone
setblock 97 119 339 minecraft:stripped_spruce_log
setblock 97 119 340 minecraft:stone
setblock 97 119 354 minecraft:stripped_spruce_log
setblock 97 119 358 minecraft:cobbled_deepslate
setblock 98 119 323 minecraft:stripped_spruce_log
fill 98 119 324 101 119 324 minecraft:stone
setblock 98 119 328 minecraft:stripped_spruce_log
fill 98 119 329 98 120 329 minecraft:stone
setblock 98 119 332 minecraft:stone
setblock 98 119 333 minecraft:stripped_spruce_log
fill 98 119 334 98 121 334 minecraft:stone
setblock 98 119 363 minecraft:stripped_spruce_log
fill 99 119 323 102 119 323 minecraft:stone
setblock 99 119 356 minecraft:cobbled_deepslate
setblock 99 119 360 minecraft:cobbled_deepslate
setblock 101 119 358 minecraft:cobbled_deepslate
setblock 103 119 323 minecraft:stripped_spruce_log
setblock 104 119 323 minecraft:stone
setblock 108 119 322 minecraft:gold_block
fill 109 119 323 112 119 323 minecraft:stone
fill 110 119 363 112 119 363 minecraft:stone
setblock 112 119 324 minecraft:stripped_spruce_log
setblock 113 119 323 minecraft:stripped_spruce_log
fill 113 119 324 113 120 324 minecraft:stone
setblock 113 119 363 minecraft:stripped_spruce_log
fill 114 119 323 117 119 323 minecraft:stone
setblock 114 119 362 minecraft:stripped_spruce_log
fill 114 119 363 117 119 363 minecraft:stone
setblock 115 119 361 minecraft:stripped_spruce_log
setblock 116 119 324 minecraft:stone
fill 116 119 361 116 122 361 minecraft:stone
setblock 117 119 324 minecraft:stripped_spruce_log
fill 117 119 326 119 119 328 minecraft:raw_gold_block
setblock 118 119 323 minecraft:stripped_spruce_log
setblock 118 119 324 minecraft:stone
setblock 118 119 363 minecraft:stripped_spruce_log
fill 119 119 323 119 120 323 minecraft:stone
setblock 119 119 362 minecraft:stripped_spruce_log
fill 119 119 363 119 121 363 minecraft:stone
fill 120 119 362 120 121 362 minecraft:stone
setblock 123 119 363 minecraft:stripped_spruce_log
fill 132 119 353 132 120 353 minecraft:iron_bars
setblock 133 119 333 minecraft:stripped_spruce_log
fill 133 119 334 133 121 335 minecraft:stone
setblock 133 119 348 minecraft:stripped_spruce_log
fill 133 119 349 133 120 349 minecraft:stone
setblock 133 119 353 minecraft:stripped_spruce_log
fill 133 119 354 133 122 354 minecraft:stone
setblock 133 119 357 minecraft:stone
setblock 134 119 328 minecraft:stone
setblock 134 119 332 minecraft:stripped_spruce_log
fill 134 119 333 134 121 333 minecraft:stone
setblock 134 119 336 minecraft:stone
setblock 134 119 337 minecraft:stripped_spruce_log
fill 134 119 338 134 121 338 minecraft:stone
setblock 134 119 342 minecraft:stripped_spruce_log
setblock 134 119 347 minecraft:stripped_spruce_log
fill 134 119 348 134 121 348 minecraft:stone
setblock 134 119 352 minecraft:stripped_spruce_log
fill 134 119 353 134 121 353 minecraft:stone
setblock 134 119 357 minecraft:stripped_spruce_log
fill 134 119 358 134 121 358 minecraft:stone
setblock 135 119 326 minecraft:stripped_spruce_log
fill 135 119 327 135 121 327 minecraft:stone
setblock 135 119 331 minecraft:stripped_spruce_log
fill 135 119 332 135 121 332 minecraft:stone
setblock 135 119 336 minecraft:stripped_spruce_log
fill 135 119 337 135 121 337 minecraft:stone
setblock 135 119 341 minecraft:stripped_spruce_log
fill 135 119 342 135 121 342 minecraft:stone
setblock 135 119 346 minecraft:stripped_spruce_log
fill 135 119 347 135 121 347 minecraft:stone
setblock 135 119 351 minecraft:stripped_spruce_log
fill 135 119 352 135 121 352 minecraft:stone
setblock 135 119 356 minecraft:stripped_spruce_log
fill 135 119 357 135 121 357 minecraft:stone
setblock 135 119 360 minecraft:stone
setblock 135 119 361 minecraft:stripped_spruce_log
fill 135 119 362 135 121 362 minecraft:stone
fill 136 119 336 136 122 336 minecraft:cobbled_deepslate
setblock 136 119 355 minecraft:raw_gold_block
fill 95 120 323 96 120 323 minecraft:stone
setblock 95 120 325 minecraft:stripped_spruce_log
fill 95 120 326 95 120 329 minecraft:stone
setblock 95 120 330 minecraft:stripped_spruce_log
fill 95 120 331 95 120 334 minecraft:stone
setblock 95 120 335 minecraft:stripped_spruce_log
fill 95 120 336 95 121 336 minecraft:stone
setblock 95 120 340 minecraft:stripped_spruce_log
fill 95 120 341 95 121 341 minecraft:stone
setblock 95 120 345 minecraft:stripped_spruce_log
fill 95 120 346 95 121 346 minecraft:stone
setblock 95 120 350 minecraft:stripped_spruce_log
fill 95 120 351 95 121 351 minecraft:stone
setblock 95 120 355 minecraft:stripped_spruce_log
fill 95 120 356 95 121 356 minecraft:stone
setblock 95 120 359 minecraft:stone
setblock 95 120 360 minecraft:stripped_spruce_log
fill 95 120 361 95 121 362 minecraft:stone
setblock 96 120 324 minecraft:glowstone
fill 96 120 325 96 121 325 minecraft:stone
setblock 96 120 329 minecraft:stripped_spruce_log
fill 96 120 330 96 120 333 minecraft:stone
setblock 96 120 334 minecraft:stripped_spruce_log
fill 96 120 335 96 121 335 minecraft:stone
setblock 96 120 339 minecraft:stripped_spruce_log
fill 96 120 340 96 121 340 minecraft:stone
setblock 96 120 343 minecraft:glowstone
setblock 96 120 349 minecraft:stripped_spruce_log
setblock 96 120 350 minecraft:stone
setblock 96 120 354 minecraft:stripped_spruce_log
fill 96 120 355 96 121 355 minecraft:stone
setblock 96 120 362 minecraft:glowstone
setblock 97 120 323 minecraft:stripped_spruce_log
fill 97 120 324 98 120 324 minecraft:stone
setblock 97 120 328 minecraft:stripped_spruce_log
fill 97 120 329 97 122 329 minecraft:stone
setblock 97 120 333 minecraft:stripped_spruce_log
fill 97 120 334 97 123 334 minecraft:stone
setblock 97 120 338 minecraft:stripped_spruce_log
fill 97 120 339 97 121 339 minecraft:stone
fill 98 120 323 101 120 323 minecraft:stone
setblock 98 120 332 minecraft:stripped_spruce_log
fill 98 120 333 98 121 333 minecraft:stone
setblock 102 120 323 minecraft:stripped_spruce_log
fill 108 120 322 108 125 322 minecraft:cobbled_deepslate
fill 110 120 323 111 120 323 minecraft:stone
fill 110 120 363 111 120 363 minecraft:stone
setblock 112 120 323 minecraft:stripped_spruce_log
setblock 112 120 362 minecraft:stone
setblock 112 120 363 minecraft:stripped_spruce_log
fill 113 120 323 116 120 323 minecraft:stone
setblock 113 120 362 minecraft:stripped_spruce_log
fill 113 120 363 116 120 363 minecraft:stone
setblock 114 120 361 minecraft:stripped_spruce_log
fill 114 120 362 114 121 362 minecraft:stone
setblock 115 120 324 minecraft:glowstone
fill 115 120 361 115 123 361 minecraft:stone
setblock 115 120 362 minecraft:glowstone
setblock 116 120 324 minecraft:stripped_spruce_log
setblock 117 120 323 minecraft:stripped_spruce_log
setblock 117 120 363 minecraft:stripped_spruce_log
fill 118 120 323 118 121 323 minecraft:stone
setblock 118 120 362 minecraft:stripped_spruce_log
fill 118 120 363 118 121 363 minecraft:stone
setblock 119 120 361 minecraft:stripped_spruce_log
fill 119 120 362 119 121 362 minecraft:stone
setblock 122 120 363 minecraft:stripped_spruce_log
fill 133 120 333 133 123 333 minecraft:stone
setblock 133 120 336 minecraft:stone
setblock 133 120 352 minecraft:stripped_spruce_log
fill 133 120 353 133 122 353 minecraft:stone
setblock 133 120 357 minecraft:stripped_spruce_log
setblock 134 120 324 minecraft:glowstone
setblock 134 120 331 minecraft:stripped_spruce_log
fill 134 120 332 134 121 332 minecraft:stone
setblock 134 120 336 minecraft:stripped_spruce_log
fill 134 120 337 134 121 337 minecraft:stone
setblock 134 120 340 minecraft:stone
setblock 134 120 341 minecraft:stripped_spruce_log
fill 134 120 342 134 121 342 minecraft:stone
setblock 134 120 343 minecraft:glowstone
setblock 134 120 346 minecraft:stripped_spruce_log
fill 134 120 347 134 121 347 minecraft:stone
setblock 134 120 351 minecraft:stripped_spruce_log
fill 134 120 352 134 121 352 minecraft:stone
setblock 134 120 356 minecraft:stripped_spruce_log
fill 134 120 357 134 121 357 minecraft:stone
setblock 134 120 362 minecraft:glowstone
setblock 135 120 325 minecraft:stripped_spruce_log
fill 135 120 326 135 121 326 minecraft:stone
setblock 135 120 330 minecraft:stripped_spruce_log
fill 135 120 331 135 121 331 minecraft:stone
setblock 135 120 335 minecraft:stripped_spruce_log
fill 135 120 336 135 121 336 minecraft:stone
setblock 135 120 340 minecraft:stripped_spruce_log
fill 135 120 341 135 121 341 minecraft:stone
setblock 135 120 345 minecraft:stripped_spruce_log
fill 135 120 346 135 121 346 minecraft:stone
setblock 135 120 350 minecraft:stripped_spruce_log
fill 135 120 351 135 121 351 minecraft:stone
setblock 135 120 355 minecraft:stripped_spruce_log
fill 135 120 356 135 121 356 minecraft:stone
setblock 135 120 360 minecraft:stripped_spruce_log
fill 135 120 361 135 121 361 minecraft:stone
fill 136 120 355 136 122 355 minecraft:cobbled_deepslate
setblock 94 121 325 minecraft:raw_iron_block
setblock 95 121 323 minecraft:stone
setblock 95 121 324 minecraft:stripped_spruce_log
fill 95 121 325 95 121 328 minecraft:stone
setblock 95 121 329 minecraft:stripped_spruce_log
fill 95 121 330 95 121 333 minecraft:stone
setblock 95 121 334 minecraft:stripped_spruce_log
setblock 95 121 335 minecraft:stone
setblock 95 121 339 minecraft:stripped_spruce_log
setblock 95 121 340 minecraft:stone
setblock 95 121 344 minecraft:stripped_spruce_log
setblock 95 121 345 minecraft:stone
setblock 95 121 349 minecraft:stripped_spruce_log
setblock 95 121 350 minecraft:stone
setblock 95 121 354 minecraft:stripped_spruce_log
setblock 95 121 355 minecraft:stone
setblock 95 121 358 minecraft:stone
setblock 95 121 359 minecraft:stripped_spruce_log
setblock 95 121 360 minecraft:stone
setblock 96 121 323 minecraft:stripped_spruce_log
fill 96 121 324 96 122 324 minecraft:spruce_log
setblock 96 121 328 minecraft:stripped_spruce_log
fill 96 121 329 96 121 332 minecraft:stone
setblock 96 121 333 minecraft:stripped_spruce_log
setblock 96 121 334 minecraft:stone
setblock 96 121 338 minecraft:stripped_spruce_log
setblock 96 121 339 minecraft:stone
fill 96 121 343 96 122 343 minecraft:spruce_log
setblock 96 121 353 minecraft:stripped_spruce_log
setblock 96 121 354 minecraft:stone
setblock 96 121 358 minecraft:stripped_spruce_log
fill 96 121 362 96 122 362 minecraft:spruce_log
fill 97 121 323 100 121 323 minecraft:stone
setblock 97 121 325 minecraft:light[level=12]
setblock 97 121 328 minecraft:stone
setblock 97 121 332 minecraft:stripped_spruce_log
fill 97 121 333 97 124 333 minecraft:stone
setblock 97 121 337 minecraft:stripped_spruce_log
fill 97 121 338 97 124 338 minecraft:stone
setblock 97 121 346 minecraft:light[level=12]
setblock 97 121 353 minecraft:light[level=12]
setblock 97 121 360 minecraft:light[level=12]
fill 98 121 329 98 131 329 minecraft:iron_bars
setblock 98 121 331 minecraft:stripped_spruce_log
setblock 98 121 332 minecraft:stone
setblock 104 121 325 minecraft:light[level=12]
setblock 104 121 332 minecraft:light[level=12]
setblock 104 121 339 minecraft:light[level=12]
setblock 104 121 346 minecraft:light[level=12]
setblock 104 121 353 minecraft:light[level=12]
setblock 104 121 360 minecraft:light[level=12]
setblock 110 121 323 minecraft:stone
setblock 110 121 363 minecraft:stone
setblock 111 121 323 minecraft:stripped_spruce_log
setblock 111 121 325 minecraft:light[level=12]
setblock 111 121 332 minecraft:light[level=12]
setblock 111 121 339 minecraft:light[level=12]
setblock 111 121 346 minecraft:light[level=12]
setblock 111 121 353 minecraft:light[level=12]
setblock 111 121 360 minecraft:light[level=12]
setblock 111 121 363 minecraft:stripped_spruce_log
fill 112 121 323 115 121 323 minecraft:stone
setblock 112 121 362 minecraft:stripped_spruce_log
fill 112 121 363 115 121 363 minecraft:stone
setblock 113 121 362 minecraft:stone
fill 114 121 361 114 124 361 minecraft:stone
fill 115 121 324 115 122 324 minecraft:spruce_log
fill 115 121 362 115 122 362 minecraft:spruce_log
setblock 116 121 323 minecraft:stripped_spruce_log
setblock 116 121 363 minecraft:stripped_spruce_log
setblock 117 121 323 minecraft:stone
setblock 117 121 362 minecraft:stripped_spruce_log
setblock 117 121 363 minecraft:stone
setblock 118 121 325 minecraft:light[level=12]
setblock 118 121 332 minecraft:light[level=12]
setblock 118 121 346 minecraft:light[level=12]
setblock 118 121 353 minecraft:light[level=12]
setblock 118 121 360 minecraft:light[level=12]
setblock 118 121 361 minecraft:stripped_spruce_log
setblock 118 121 362 minecraft:stone
setblock 121 121 363 minecraft:stripped_spruce_log
setblock 125 121 325 minecraft:light[level=12]
setblock 125 121 332 minecraft:light[level=12]
setblock 125 121 339 minecraft:light[level=12]
setblock 125 121 346 minecraft:light[level=12]
setblock 125 121 353 minecraft:light[level=12]
setblock 125 121 360 minecraft:light[level=12]
setblock 132 121 325 minecraft:light[level=12]
setblock 132 121 332 minecraft:light[level=12]
setblock 132 121 339 minecraft:light[level=12]
setblock 132 121 346 minecraft:light[level=12]
setblock 132 121 353 minecraft:light[level=12]
setblock 132 121 360 minecraft:light[level=12]
setblock 133 121 336 minecraft:stripped_spruce_log
fill 133 121 337 133 123 338 minecraft:stone
setblock 133 121 351 minecraft:stripped_spruce_log
fill 133 121 352 133 122 352 minecraft:stone
setblock 133 121 356 minecraft:stripped_spruce_log
setblock 133 121 357 minecraft:stone
fill 134 121 324 134 122 324 minecraft:spruce_log
setblock 134 121 330 minecraft:stripped_spruce_log
setblock 134 121 331 minecraft:stone
setblock 134 121 335 minecraft:stripped_spruce_log
setblock 134 121 336 minecraft:stone
setblock 134 121 340 minecraft:stripped_spruce_log
setblock 134 121 341 minecraft:stone
fill 134 121 343 134 122 343 minecraft:spruce_log
setblock 134 121 345 minecraft:stripped_spruce_log
setblock 134 121 346 minecraft:stone
setblock 134 121 350 minecraft:stripped_spruce_log
setblock 134 121 351 minecraft:stone
setblock 134 121 355 minecraft:stripped_spruce_log
setblock 134 121 356 minecraft:stone
fill 134 121 362 134 122 362 minecraft:spruce_log
setblock 135 121 329 minecraft:stripped_spruce_log
setblock 135 121 330 minecraft:stone
setblock 135 121 334 minecraft:stripped_spruce_log
setblock 135 121 335 minecraft:stone
setblock 135 121 339 minecraft:stripped_spruce_log
setblock 135 121 340 minecraft:stone
setblock 135 121 344 minecraft:stripped_spruce_log
setblock 135 121 345 minecraft:stone
setblock 135 121 349 minecraft:stripped_spruce_log
setblock 135 121 350 minecraft:stone
setblock 135 121 354 minecraft:stripped_spruce_log
setblock 135 121 355 minecraft:stone
setblock 135 121 359 minecraft:stripped_spruce_log
setblock 135 121 360 minecraft:stone
setblock 94 122 323 minecraft:deepslate
fill 94 122 325 94 125 325 minecraft:cobbled_deepslate
setblock 94 122 335 minecraft:deepslate
setblock 94 122 342 minecraft:deepslate
setblock 94 122 345 minecraft:raw_iron_block
setblock 94 122 354 minecraft:deepslate
fill 95 122 323 95 122 363 minecraft:spruce_planks
fill 96 122 323 135 122 323 minecraft:spruce_planks
fill 96 122 325 96 122 342 minecraft:spruce_planks
fill 96 122 344 96 122 361 minecraft:spruce_planks
fill 96 122 363 135 122 363 minecraft:spruce_planks
fill 97 122 324 114 122 324 minecraft:spruce_planks
setblock 97 122 331 minecraft:stripped_spruce_log
fill 97 122 332 97 124 332 minecraft:stone
setblock 97 122 336 minecraft:stripped_spruce_log
fill 97 122 337 97 125 337 minecraft:stone
fill 97 122 362 114 122 362 minecraft:spruce_planks
fill 99 122 364 100 125 364 minecraft:cobbled_deepslate
setblock 101 122 364 minecraft:deepslate
fill 102 122 364 102 125 364 minecraft:cobbled_deepslate
setblock 104 122 364 minecraft:deepslate
fill 105 122 364 105 125 364 minecraft:cobbled_deepslate
setblock 112 122 322 minecraft:deepslate
fill 113 122 361 113 125 361 minecraft:stone
setblock 113 122 364 minecraft:deepslate
fill 116 122 324 133 122 324 minecraft:spruce_planks
fill 116 122 362 133 122 362 minecraft:spruce_planks
setblock 117 122 361 minecraft:stripped_spruce_log
fill 118 122 350 125 123 350 minecraft:stripped_spruce_log
fill 118 122 361 118 125 361 minecraft:stone
fill 123 122 349 133 123 349 minecraft:stripped_spruce_log
fill 126 122 322 127 122 322 minecraft:deepslate
fill 129 122 348 133 123 348 minecraft:stripped_spruce_log
setblock 132 122 322 minecraft:gold_block
setblock 133 122 334 minecraft:stone
setblock 133 122 335 minecraft:stripped_spruce_log
fill 133 122 336 133 125 336 minecraft:stone
setblock 133 122 339 minecraft:stone
setblock 133 122 355 minecraft:stripped_spruce_log
fill 133 122 356 133 123 356 minecraft:stone
fill 134 122 325 135 122 342 minecraft:spruce_planks
fill 134 122 344 135 122 361 minecraft:spruce_planks
fill 134 122 364 134 125 364 minecraft:cobbled_deepslate
setblock 135 122 324 minecraft:spruce_planks
setblock 135 122 343 minecraft:spruce_planks
setblock 135 122 362 minecraft:spruce_planks
setblock 135 122 364 minecraft:deepslate
setblock 136 122 325 minecraft:deepslate
fill 136 122 332 136 122 333 minecraft:deepslate
fill 136 122 338 136 125 339 minecraft:cobbled_deepslate
setblock 136 122 340 minecraft:deepslate
setblock 136 122 343 minecraft:deepslate
setblock 136 122 346 minecraft:deepslate
setblock 136 122 348 minecraft:deepslate
setblock 136 122 354 minecraft:gold_block
setblock 136 122 357 minecraft:deepslate
setblock 136 122 364 minecraft:cobbled_deepslate
setblock 94 123 323 minecraft:cobbled_deepslate
setblock 94 123 324 minecraft:raw_iron_block
fill 94 123 335 94 126 335 minecraft:cobbled_deepslate
setblock 94 123 337 minecraft:deepslate
fill 94 123 340 94 123 341 minecraft:deepslate
fill 94 123 342 94 125 342 minecraft:cobbled_deepslate
fill 94 123 345 94 125 345 minecraft:cobbled_deepslate
fill 94 123 354 94 125 354 minecraft:cobbled_deepslate
setblock 94 123 356 minecraft:deepslate
fill 95 123 323 95 123 326 minecraft:stone
setblock 95 123 327 minecraft:stripped_spruce_log
fill 95 123 328 95 123 331 minecraft:stone
setblock 95 123 332 minecraft:stripped_spruce_log
fill 95 123 333 95 123 336 minecraft:stone
setblock 95 123 337 minecraft:stripped_spruce_log
fill 95 123 338 95 123 341 minecraft:stone
setblock 95 123 342 minecraft:stripped_spruce_log
fill 95 123 343 95 124 345 minecraft:stone
fill 95 123 349 95 123 351 minecraft:stone
setblock 95 123 352 minecraft:stripped_spruce_log
fill 95 123 353 95 123 356 minecraft:stone
setblock 95 123 357 minecraft:stripped_spruce_log
fill 95 123 358 95 123 361 minecraft:stone
setblock 95 123 362 minecraft:stripped_spruce_log
fill 95 123 363 96 125 363 minecraft:stone
fill 96 123 323 98 123 323 minecraft:stone
fill 96 123 327 96 123 330 minecraft:stone
setblock 96 123 331 minecraft:stripped_spruce_log
fill 96 123 332 96 123 335 minecraft:stone
setblock 96 123 336 minecraft:stripped_spruce_log
fill 96 123 337 96 123 340 minecraft:stone
setblock 96 123 341 minecraft:stripped_spruce_log
fill 96 123 353 99 123 354 minecraft:stripped_spruce_log
setblock 96 123 356 minecraft:stripped_spruce_log
setblock 96 123 357 minecraft:stone
setblock 97 123 325 minecraft:light[level=15]
fill 97 123 328 97 123 329 minecraft:cobbled_deepslate
setblock 97 123 330 minecraft:stripped_spruce_log
setblock 97 123 331 minecraft:stone
setblock 97 123 335 minecraft:stripped_spruce_log
fill 97 123 336 97 126 336 minecraft:stone
setblock 97 123 341 minecraft:light[level=15]
setblock 97 123 349 minecraft:light[level=15]
setblock 97 123 357 minecraft:light[level=15]
fill 100 123 352 106 123 353 minecraft:stripped_spruce_log
fill 101 123 364 101 125 364 minecraft:cobbled_deepslate
setblock 103 123 322 minecraft:deepslate
setblock 104 123 364 minecraft:cobbled_deepslate
setblock 105 123 325 minecraft:light[level=15]
setblock 105 123 333 minecraft:light[level=15]
setblock 105 123 341 minecraft:light[level=15]
setblock 105 123 349 minecraft:light[level=15]
setblock 105 123 357 minecraft:light[level=15]
fill 107 123 351 113 123 352 minecraft:stripped_spruce_log
setblock 108 123 363 minecraft:stone
setblock 109 123 363 minecraft:stripped_spruce_log
fill 110 123 323 113 123 323 minecraft:stone
setblock 110 123 362 minecraft:stripped_spruce_log
fill 110 123 363 113 123 363 minecraft:stone
setblock 111 123 322 minecraft:deepslate
fill 111 123 362 114 123 362 minecraft:stone
fill 112 123 322 112 125 322 minecraft:cobbled_deepslate
fill 112 123 361 112 126 361 minecraft:stone
setblock 113 123 325 minecraft:light[level=15]
setblock 113 123 333 minecraft:light[level=15]
setblock 113 123 341 minecraft:light[level=15]
setblock 113 123 349 minecraft:light[level=15]
setblock 113 123 357 minecraft:light[level=15]
fill 113 123 364 113 125 364 minecraft:cobbled_deepslate
setblock 114 123 323 minecraft:stripped_spruce_log
fill 114 123 350 117 123 351 minecraft:stripped_spruce_log
setblock 114 123 363 minecraft:stripped_spruce_log
fill 115 123 323 116 125 323 minecraft:stone
setblock 115 123 362 minecraft:stripped_spruce_log
fill 115 123 363 118 123 363 minecraft:stone
setblock 116 123 361 minecraft:stripped_spruce_log
fill 116 123 362 119 123 362 minecraft:stone
fill 117 123 361 117 126 361 minecraft:stone
fill 117 123 364 117 124 364 minecraft:deepslate
fill 118 123 351 120 123 351 minecraft:stripped_spruce_log
setblock 119 123 363 minecraft:stripped_spruce_log
fill 120 123 363 121 123 363 minecraft:stone
setblock 121 123 325 minecraft:light[level=15]
setblock 121 123 333 minecraft:light[level=15]
setblock 121 123 341 minecraft:light[level=15]
fill 121 123 349 122 123 349 minecraft:stripped_spruce_log
setblock 121 123 357 minecraft:light[level=15]
setblock 121 123 364 minecraft:deepslate
fill 123 123 322 124 123 322 minecraft:deepslate
setblock 123 123 364 minecraft:deepslate
fill 126 123 322 127 125 322 minecraft:cobbled_deepslate
fill 126 123 350 127 123 350 minecraft:stripped_spruce_log
setblock 128 123 348 minecraft:stripped_spruce_log
setblock 129 123 325 minecraft:light[level=15]
setblock 129 123 341 minecraft:light[level=15]
setblock 129 123 357 minecraft:light[level=15]
fill 129 123 364 130 123 364 minecraft:raw_gold_block
fill 132 123 322 132 125 322 minecraft:cobbled_deepslate
setblock 133 123 334 minecraft:stripped_spruce_log
fill 133 123 335 135 124 335 minecraft:stone
setblock 133 123 339 minecraft:stripped_spruce_log
fill 133 123 340 135 124 340 minecraft:stone
setblock 133 123 354 minecraft:stripped_spruce_log
fill 133 123 355 135 123 355 minecraft:stone
fill 134 123 330 134 123 332 minecraft:stone
setblock 134 123 333 minecraft:stripped_spruce_log
fill 134 123 334 135 125 334 minecraft:stone
fill 134 123 336 134 123 337 minecraft:stone
setblock 134 123 338 minecraft:stripped_spruce_log
fill 134 123 339 135 125 339 minecraft:stone
fill 134 123 341 134 123 342 minecraft:stone
setblock 134 123 343 minecraft:stripped_spruce_log
fill 134 123 344 134 123 347 minecraft:stone
setblock 134 123 348 minecraft:stripped_spruce_log
fill 134 123 349 134 123 352 minecraft:stone
setblock 134 123 353 minecraft:stripped_spruce_log
fill 134 123 354 135 125 354 minecraft:stone
fill 134 123 356 134 123 357 minecraft:stone
setblock 134 123 358 minecraft:stripped_spruce_log
fill 134 123 359 135 124 360 minecraft:stone
setblock 135 123 327 minecraft:stripped_spruce_log
fill 135 123 328 135 123 331 minecraft:stone
setblock 135 123 332 minecraft:stripped_spruce_log
fill 135 123 333 135 126 333 minecraft:stone
setblock 135 123 336 minecraft:stone
setblock 135 123 337 minecraft:stripped_spruce_log
fill 135 123 338 135 126 338 minecraft:stone
setblock 135 123 341 minecraft:stone
setblock 135 123 342 minecraft:stripped_spruce_log
fill 135 123 343 135 123 346 minecraft:stone
setblock 135 123 347 minecraft:stripped_spruce_log
fill 135 123 348 135 123 351 minecraft:stone
setblock 135 123 352 minecraft:stripped_spruce_log
fill 135 123 353 135 126 353 minecraft:stone
setblock 135 123 356 minecraft:stone
setblock 135 123 357 minecraft:stripped_spruce_log
fill 135 123 358 135 126 358 minecraft:stone
setblock 135 123 361 minecraft:stone
setblock 135 123 362 minecraft:stripped_spruce_log
fill 135 123 364 135 126 364 minecraft:cobbled_deepslate
setblock 136 123 324 minecraft:deepslate
fill 136 123 325 136 123 327 minecraft:cobbled_deepslate
setblock 136 123 328 minecraft:deepslate
fill 136 123 332 136 123 333 minecraft:cobbled_deepslate
setblock 136 123 336 minecraft:diamond_block
fill 136 123 340 136 125 340 minecraft:cobbled_deepslate
fill 136 123 343 136 125 343 minecraft:cobbled_deepslate
fill 136 123 346 136 125 346 minecraft:cobbled_deepslate
fill 136 123 348 136 125 348 minecraft:cobbled_deepslate
setblock 136 123 349 minecraft:deepslate
setblock 136 123 350 minecraft:raw_iron_block
setblock 136 123 352 minecraft:deepslate
fill 136 123 354 136 125 354 minecraft:cobbled_deepslate
fill 136 123 355 136 124 355 minecraft:deepslate
setblock 136 123 357 minecraft:cobbled_deepslate
setblock 136 123 359 minecraft:deepslate
setblock 136 123 364 minecraft:deepslate
setblock 94 124 323 minecraft:deepslate
fill 94 124 324 94 125 324 minecraft:cobbled_deepslate
fill 94 124 337 94 125 337 minecraft:cobbled_deepslate
fill 94 124 340 94 125 341 minecraft:cobbled_deepslate
fill 94 124 356 94 125 356 minecraft:cobbled_deepslate
fill 94 124 362 94 125 363 minecraft:cobbled_deepslate
setblock 94 124 364 minecraft:deepslate
fill 95 124 322 96 124 322 minecraft:deepslate
fill 95 124 323 95 124 325 minecraft:stone
setblock 95 124 326 minecraft:stripped_spruce_log
fill 95 124 327 95 124 330 minecraft:stone
setblock 95 124 331 minecraft:stripped_spruce_log
fill 95 124 332 95 124 335 minecraft:stone
setblock 95 124 336 minecraft:stripped_spruce_log
fill 95 124 337 95 124 340 minecraft:stone
setblock 95 124 341 minecraft:stripped_spruce_log
fill 95 124 342 95 127 342 minecraft:stone
fill 95 124 352 95 124 355 minecraft:stone
setblock 95 124 356 minecraft:stripped_spruce_log
fill 95 124 357 95 124 360 minecraft:stone
setblock 95 124 361 minecraft:stripped_spruce_log
fill 95 124 362 95 127 362 minecraft:stone
fill 96 124 323 97 124 323 minecraft:stone
fill 96 124 328 96 124 329 minecraft:stone
setblock 96 124 330 minecraft:stripped_spruce_log
fill 96 124 331 96 124 334 minecraft:stone
setblock 96 124 335 minecraft:stripped_spruce_log
fill 96 124 336 96 124 339 minecraft:stone
setblock 96 124 340 minecraft:stripped_spruce_log
fill 96 124 341 96 127 341 minecraft:stone
fill 96 124 353 98 124 354 minecraft:stripped_spruce_log
setblock 97 124 334 minecraft:stripped_spruce_log
fill 97 124 335 97 127 335 minecraft:stone
setblock 97 124 363 minecraft:stone
setblock 98 124 323 minecraft:stripped_spruce_log
setblock 98 124 364 minecraft:deepslate
fill 99 124 353 104 124 353 minecraft:stripped_spruce_log
setblock 101 124 322 minecraft:deepslate
fill 102 124 352 109 124 352 minecraft:stripped_spruce_log
fill 103 124 322 103 125 322 minecraft:cobbled_deepslate
fill 103 124 334 105 125 336 minecraft:iron_block
setblock 104 124 364 minecraft:deepslate
setblock 107 124 363 minecraft:stone
fill 107 124 364 107 125 364 minecraft:cobbled_deepslate
setblock 108 124 363 minecraft:stripped_spruce_log
setblock 108 124 364 minecraft:deepslate
setblock 109 124 322 minecraft:deepslate
fill 109 124 323 112 124 323 minecraft:stone
setblock 109 124 362 minecraft:stripped_spruce_log
fill 109 124 363 112 124 363 minecraft:stone
fill 109 124 364 109 125 364 minecraft:cobbled_deepslate
fill 110 124 362 113 124 362 minecraft:stone
setblock 110 124 364 minecraft:deepslate
fill 111 124 322 111 125 322 minecraft:cobbled_deepslate
fill 111 124 351 114 124 351 minecraft:stripped_spruce_log
fill 111 124 361 111 127 361 minecraft:stone
setblock 113 124 323 minecraft:stripped_spruce_log
setblock 113 124 363 minecraft:stripped_spruce_log
fill 114 124 323 114 127 323 minecraft:stone
fill 114 124 360 115 124 360 minecraft:stone
setblock 114 124 362 minecraft:stripped_spruce_log
fill 114 124 363 117 124 363 minecraft:stone
fill 115 124 351 116 124 351 minecraft:stripped_dark_oak_log
setblock 115 124 361 minecraft:stripped_spruce_log
fill 115 124 362 118 124 362 minecraft:stone
fill 116 124 361 116 127 361 minecraft:stone
fill 118 124 350 124 124 350 minecraft:stripped_dark_oak_log
setblock 118 124 363 minecraft:stripped_spruce_log
setblock 119 124 362 minecraft:stripped_spruce_log
fill 119 124 363 120 126 363 minecraft:stone
setblock 121 124 322 minecraft:deepslate
fill 121 124 364 121 126 364 minecraft:cobbled_deepslate
fill 123 124 322 123 125 322 minecraft:cobbled_deepslate
fill 123 124 364 123 125 364 minecraft:cobbled_deepslate
setblock 124 124 322 minecraft:deepslate
fill 124 124 349 131 124 349 minecraft:stripped_dark_oak_log
setblock 128 124 322 minecraft:deepslate
fill 129 124 364 130 125 364 minecraft:cobbled_deepslate
setblock 130 124 322 minecraft:deepslate
fill 131 124 348 134 124 348 minecraft:stripped_dark_oak_log
setblock 133 124 322 minecraft:deepslate
setblock 133 124 333 minecraft:stripped_spruce_log
fill 133 124 334 133 127 334 minecraft:stone
setblock 133 124 337 minecraft:stone
setblock 133 124 338 minecraft:stripped_spruce_log
fill 133 124 339 133 127 339 minecraft:stone
fill 133 124 341 134 124 341 minecraft:stone
setblock 133 124 363 minecraft:stripped_spruce_log
fill 134 124 330 134 124 331 minecraft:stone
setblock 134 124 332 minecraft:stripped_spruce_log
fill 134 124 333 134 127 333 minecraft:stone
setblock 134 124 336 minecraft:stone
setblock 134 124 337 minecraft:stripped_spruce_log
fill 134 124 338 134 127 338 minecraft:stone
setblock 134 124 342 minecraft:stripped_spruce_log
fill 134 124 343 134 124 346 minecraft:stone
fill 134 124 350 134 124 351 minecraft:stone
setblock 134 124 352 minecraft:stripped_spruce_log
fill 134 124 353 134 127 353 minecraft:stone
fill 134 124 355 134 124 356 minecraft:stone
setblock 134 124 357 minecraft:stripped_spruce_log
fill 134 124 358 134 127 358 minecraft:stone
fill 134 124 363 135 126 363 minecraft:stone
fill 135 124 328 135 124 330 minecraft:stone
setblock 135 124 331 minecraft:stripped_spruce_log
fill 135 124 332 135 127 332 minecraft:stone
setblock 135 124 336 minecraft:stripped_spruce_log
fill 135 124 337 135 127 337 minecraft:stone
setblock 135 124 341 minecraft:stripped_spruce_log
fill 135 124 342 135 124 345 minecraft:stone
setblock 135 124 346 minecraft:stripped_spruce_log
fill 135 124 347 135 124 350 minecraft:stone
setblock 135 124 351 minecraft:stripped_spruce_log
fill 135 124 352 135 127 352 minecraft:stone
setblock 135 124 355 minecraft:stone
setblock 135 124 356 minecraft:stripped_spruce_log
fill 135 124 357 135 127 357 minecraft:stone
setblock 135 124 361 minecraft:stripped_spruce_log
fill 135 124 362 135 127 362 minecraft:stone
fill 136 124 324 136 125 325 minecraft:cobbled_deepslate
setblock 136 124 326 minecraft:deepslate
fill 136 124 327 136 125 328 minecraft:cobbled_deepslate
setblock 136 124 332 minecraft:deepslate
fill 136 124 333 136 125 333 minecraft:cobbled_deepslate
fill 136 124 336 136 125 336 minecraft:cobbled_deepslate
setblock 136 124 341 minecraft:raw_gold_block
setblock 136 124 344 minecraft:deepslate
fill 136 124 345 136 127 345 minecraft:cobbled_deepslate
fill 136 124 349 136 125 350 minecraft:cobbled_deepslate
fill 136 124 352 136 125 352 minecraft:cobbled_deepslate
setblock 136 124 357 minecraft:deepslate
fill 136 124 359 136 125 359 minecraft:cobbled_deepslate
fill 136 124 364 136 125 364 minecraft:cobbled_deepslate
setblock 94 125 323 minecraft:cobbled_deepslate
setblock 94 125 332 minecraft:raw_iron_block
fill 94 125 364 94 126 364 minecraft:cobbled_deepslate
setblock 95 125 322 minecraft:gold_block
fill 95 125 323 95 125 324 minecraft:stone
setblock 95 125 325 minecraft:stripped_spruce_log
fill 95 125 326 95 125 329 minecraft:stone
setblock 95 125 330 minecraft:stripped_spruce_log
fill 95 125 331 95 125 334 minecraft:stone
setblock 95 125 335 minecraft:stripped_spruce_log
fill 95 125 336 95 125 339 minecraft:stone
setblock 95 125 340 minecraft:stripped_spruce_log
fill 95 125 341 95 128 341 minecraft:stone
fill 95 125 343 95 125 344 minecraft:stone
setblock 95 125 345 minecraft:stripped_spruce_log
fill 95 125 353 95 125 354 minecraft:stone
setblock 95 125 355 minecraft:stripped_spruce_log
fill 95 125 356 95 125 359 minecraft:stone
setblock 95 125 360 minecraft:stripped_spruce_log
fill 95 125 361 95 128 361 minecraft:stone
setblock 96 125 322 minecraft:cobbled_deepslate
setblock 96 125 323 minecraft:stone
setblock 96 125 328 minecraft:stone
setblock 96 125 329 minecraft:stripped_spruce_log
fill 96 125 330 96 125 333 minecraft:stone
setblock 96 125 334 minecraft:stripped_spruce_log
fill 96 125 335 96 125 338 minecraft:stone
setblock 96 125 339 minecraft:stripped_spruce_log
fill 96 125 340 96 128 340 minecraft:stone
fill 96 125 353 96 125 354 minecraft:stripped_dark_oak_log
setblock 97 125 323 minecraft:stripped_spruce_log
setblock 97 125 333 minecraft:stripped_spruce_log
fill 97 125 334 97 126 334 minecraft:stone
setblock 97 125 338 minecraft:stripped_spruce_log
fill 97 125 353 102 125 353 minecraft:stripped_dark_oak_log
setblock 97 125 363 minecraft:stripped_spruce_log
fill 98 125 323 98 128 323 minecraft:stone
fill 98 125 363 98 128 363 minecraft:stone
setblock 98 125 364 minecraft:cobbled_deepslate
fill 101 125 322 101 126 322 minecraft:cobbled_deepslate
fill 104 125 352 108 125 352 minecraft:stripped_dark_oak_log
setblock 104 125 364 minecraft:cobbled_deepslate
setblock 106 125 363 minecraft:stone
setblock 107 125 363 minecraft:stripped_spruce_log
fill 108 125 323 111 125 323 minecraft:stone
setblock 108 125 362 minecraft:stripped_spruce_log
fill 108 125 363 111 125 363 minecraft:stone
setblock 108 125 364 minecraft:cobbled_deepslate
setblock 109 125 322 minecraft:cobbled_deepslate
fill 109 125 362 112 125 362 minecraft:stone
fill 110 125 361 110 128 361 minecraft:stone
fill 110 125 364 110 126 364 minecraft:cobbled_deepslate
setblock 112 125 323 minecraft:stripped_spruce_log
fill 112 125 360 114 125 360 minecraft:stone
setblock 112 125 363 minecraft:stripped_spruce_log
fill 113 125 323 113 128 323 minecraft:stone
setblock 113 125 362 minecraft:stripped_spruce_log
fill 113 125 363 116 125 363 minecraft:stone
setblock 114 125 361 minecraft:stripped_spruce_log
fill 114 125 362 117 125 362 minecraft:stone
setblock 115 125 360 minecraft:stripped_spruce_log
fill 115 125 361 115 128 361 minecraft:stone
setblock 115 125 364 minecraft:cobbled_deepslate
setblock 116 125 364 minecraft:raw_gold_block
fill 117 125 327 117 141 327 minecraft:iron_bars
setblock 117 125 363 minecraft:stripped_spruce_log
setblock 117 125 364 minecraft:cobbled_deepslate
setblock 118 125 362 minecraft:stripped_spruce_log
fill 118 125 363 118 128 363 minecraft:stone
fill 119 125 362 119 128 362 minecraft:stone
setblock 121 125 322 minecraft:cobbled_deepslate
setblock 121 125 363 minecraft:stone
setblock 124 125 322 minecraft:cobbled_deepslate
setblock 128 125 322 minecraft:cobbled_deepslate
setblock 130 125 322 minecraft:cobbled_deepslate
setblock 131 125 363 minecraft:stone
setblock 132 125 363 minecraft:stripped_spruce_log
setblock 133 125 322 minecraft:cobbled_deepslate
fill 133 125 333 133 128 333 minecraft:stone
fill 133 125 335 134 125 335 minecraft:stone
setblock 133 125 337 minecraft:stripped_spruce_log
fill 133 125 338 133 128 338 minecraft:stone
fill 133 125 340 133 125 341 minecraft:stone
setblock 133 125 342 minecraft:stripped_spruce_log
fill 133 125 363 133 128 363 minecraft:stone
setblock 134 125 330 minecraft:stone
setblock 134 125 331 minecraft:stripped_spruce_log
fill 134 125 332 134 128 332 minecraft:stone
setblock 134 125 336 minecraft:stripped_spruce_log
fill 134 125 337 134 128 337 minecraft:stone
setblock 134 125 340 minecraft:stone
setblock 134 125 341 minecraft:stripped_spruce_log
fill 134 125 342 134 125 345 minecraft:stone
setblock 134 125 346 minecraft:stripped_spruce_log
setblock 134 125 351 minecraft:stripped_spruce_log
fill 134 125 352 134 126 352 minecraft:stone
setblock 134 125 355 minecraft:stone
setblock 134 125 356 minecraft:stripped_spruce_log
fill 134 125 357 134 128 357 minecraft:stone
fill 134 125 359 134 125 360 minecraft:stone
setblock 134 125 361 minecraft:stripped_spruce_log
fill 135 125 328 135 125 329 minecraft:stone
setblock 135 125 330 minecraft:stripped_spruce_log
fill 135 125 331 135 128 331 minecraft:stone
setblock 135 125 335 minecraft:stripped_spruce_log
fill 135 125 336 135 128 336 minecraft:stone
setblock 135 125 340 minecraft:stripped_spruce_log
fill 135 125 341 135 125 344 minecraft:stone
setblock 135 125 345 minecraft:stripped_spruce_log
fill 135 125 346 135 125 349 minecraft:stone
setblock 135 125 350 minecraft:stripped_spruce_log
fill 135 125 351 135 128 351 minecraft:stone
setblock 135 125 355 minecraft:stripped_spruce_log
fill 135 125 356 135 128 356 minecraft:stone
setblock 135 125 359 minecraft:stone
setblock 135 125 360 minecraft:stripped_spruce_log
fill 135 125 361 135 128 361 minecraft:stone
setblock 136 125 323 minecraft:diamond_block
setblock 136 125 326 minecraft:cobbled_deepslate
setblock 136 125 332 minecraft:cobbled_deepslate
fill 136 125 341 136 126 341 minecraft:cobbled_deepslate
setblock 136 125 344 minecraft:cobbled_deepslate
setblock 136 125 355 minecraft:cobbled_deepslate
setblock 136 125 357 minecraft:cobbled_deepslate
fill 94 126 322 94 126 334 minecraft:deepslate
fill 94 126 336 94 186 337 minecraft:deepslate
fill 94 126 339 94 126 346 minecraft:deepslate
setblock 94 126 347 minecraft:raw_iron_block
fill 94 126 348 94 126 357 minecraft:deepslate
setblock 94 126 358 minecraft:raw_iron_block
fill 94 126 359 94 126 363 minecraft:deepslate
fill 95 126 322 100 134 322 minecraft:deepslate
setblock 95 126 323 minecraft:stone
setblock 95 126 324 minecraft:stripped_spruce_log
fill 95 126 325 95 126 328 minecraft:stone
setblock 95 126 329 minecraft:stripped_spruce_log
fill 95 126 330 95 126 333 minecraft:stone
setblock 95 126 334 minecraft:stripped_spruce_log
fill 95 126 335 95 126 338 minecraft:stone
setblock 95 126 339 minecraft:stripped_spruce_log
fill 95 126 340 95 129 340 minecraft:stone
setblock 95 126 343 minecraft:stone
setblock 95 126 344 minecraft:stripped_spruce_log
fill 95 126 345 95 129 345 minecraft:stone
setblock 95 126 354 minecraft:stripped_spruce_log
fill 95 126 355 95 126 358 minecraft:stone
setblock 95 126 359 minecraft:stripped_spruce_log
fill 95 126 360 96 128 360 minecraft:stone
setblock 95 126 363 minecraft:stone
fill 95 126 364 98 126 364 minecraft:deepslate
setblock 96 126 323 minecraft:stripped_spruce_log
fill 96 126 329 96 126 332 minecraft:stone
setblock 96 126 333 minecraft:stripped_spruce_log
fill 96 126 334 96 126 337 minecraft:stone
setblock 96 126 338 minecraft:stripped_spruce_log
fill 96 126 339 96 129 339 minecraft:stone
setblock 96 126 342 minecraft:stone
fill 96 126 359 96 129 359 minecraft:stone
fill 96 126 361 96 127 361 minecraft:stone
setblock 96 126 363 minecraft:stripped_spruce_log
fill 97 126 323 97 129 323 minecraft:stone
setblock 97 126 337 minecraft:stripped_spruce_log
fill 97 126 338 97 127 338 minecraft:stone
fill 97 126 363 97 129 363 minecraft:stone
fill 99 126 323 99 127 323 minecraft:stone
fill 99 126 363 100 126 363 minecraft:stone
setblock 99 126 364 minecraft:cobbled_deepslate
fill 100 126 364 109 131 364 minecraft:deepslate
fill 102 126 322 112 126 322 minecraft:deepslate
fill 103 126 334 105 126 336 minecraft:raw_gold_block
fill 103 126 363 105 126 363 minecraft:stone
setblock 106 126 323 minecraft:stripped_spruce_log
setblock 106 126 362 minecraft:stone
setblock 106 126 363 minecraft:stripped_spruce_log
fill 107 126 323 110 126 323 minecraft:stone
setblock 107 126 362 minecraft:stripped_spruce_log
fill 107 126 363 110 126 363 minecraft:stone
setblock 108 126 361 minecraft:stripped_spruce_log
fill 108 126 362 111 126 362 minecraft:stone
fill 109 126 324 109 126 328 minecraft:raw_gold_block
fill 109 126 361 109 129 361 minecraft:stone
setblock 111 126 323 minecraft:stripped_spruce_log
fill 111 126 360 113 126 360 minecraft:stone
setblock 111 126 363 minecraft:stripped_spruce_log
fill 111 126 364 120 126 364 minecraft:deepslate
fill 112 126 323 112 129 323 minecraft:stone
setblock 112 126 362 minecraft:stripped_spruce_log
fill 112 126 363 115 126 363 minecraft:stone
setblock 113 126 361 minecraft:stripped_spruce_log
fill 113 126 362 116 126 362 minecraft:stone
fill 114 126 322 114 183 322 minecraft:deepslate
setblock 114 126 360 minecraft:stripped_spruce_log
fill 114 126 361 114 129 361 minecraft:stone
setblock 115 126 323 minecraft:stone
fill 115 126 360 116 128 360 minecraft:stone
fill 116 126 322 118 140 322 minecraft:deepslate
setblock 116 126 323 minecraft:stripped_spruce_log
setblock 116 126 363 minecraft:stripped_spruce_log
setblock 117 126 362 minecraft:stripped_spruce_log
fill 117 126 363 117 129 363 minecraft:stone
setblock 118 126 361 minecraft:stripped_spruce_log
fill 118 126 362 118 129 362 minecraft:stone
fill 120 126 322 121 186 322 minecraft:deepslate
setblock 121 126 363 minecraft:stripped_spruce_log
setblock 122 126 322 minecraft:diamond_block
fill 123 126 322 136 127 322 minecraft:deepslate
fill 123 126 364 125 137 364 minecraft:deepslate
setblock 126 126 364 minecraft:cobbled_deepslate
fill 127 126 364 130 134 364 minecraft:deepslate
fill 128 126 363 130 126 363 minecraft:stone
setblock 131 126 363 minecraft:stripped_spruce_log
setblock 132 126 336 minecraft:stone
setblock 132 126 337 minecraft:stripped_spruce_log
fill 132 126 338 132 127 340 minecraft:stone
setblock 132 126 362 minecraft:stripped_spruce_log
fill 132 126 363 132 129 363 minecraft:stone
fill 132 126 364 134 126 364 minecraft:deepslate
setblock 133 126 335 minecraft:stone
setblock 133 126 336 minecraft:stripped_spruce_log
fill 133 126 337 133 129 337 minecraft:stone
setblock 133 126 340 minecraft:stone
setblock 133 126 341 minecraft:stripped_spruce_log
fill 133 126 342 135 126 343 minecraft:stone
fill 133 126 362 133 129 362 minecraft:stone
fill 134 126 323 134 127 323 minecraft:stone
setblock 134 126 330 minecraft:stripped_spruce_log
fill 134 126 331 134 129 331 minecraft:stone
setblock 134 126 334 minecraft:stone
setblock 134 126 335 minecraft:stripped_spruce_log
fill 134 126 336 134 129 336 minecraft:stone
setblock 134 126 339 minecraft:stone
setblock 134 126 340 minecraft:stripped_spruce_log
fill 134 126 341 135 128 341 minecraft:stone
setblock 134 126 344 minecraft:stone
setblock 134 126 345 minecraft:stripped_spruce_log
fill 134 126 346 135 127 347 minecraft:stone
setblock 134 126 354 minecraft:stone
setblock 134 126 355 minecraft:stripped_spruce_log
fill 134 126 356 134 129 356 minecraft:stone
setblock 134 126 359 minecraft:stone
setblock 134 126 360 minecraft:stripped_spruce_log
fill 134 126 361 134 129 361 minecraft:stone
fill 135 126 327 135 126 328 minecraft:stone
setblock 135 126 329 minecraft:stripped_spruce_log
fill 135 126 330 135 129 330 minecraft:stone
setblock 135 126 334 minecraft:stripped_spruce_log
fill 135 126 335 135 129 335 minecraft:stone
setblock 135 126 339 minecraft:stripped_spruce_log
fill 135 126 340 135 129 340 minecraft:stone
setblock 135 126 344 minecraft:stripped_spruce_log
fill 135 126 345 135 129 345 minecraft:stone
setblock 135 126 348 minecraft:stone
setblock 135 126 349 minecraft:stripped_spruce_log
fill 135 126 350 135 129 350 minecraft:stone
setblock 135 126 354 minecraft:stripped_spruce_log
fill 135 126 355 135 129 355 minecraft:stone
setblock 135 126 359 minecraft:stripped_spruce_log
fill 135 126 360 135 129 360 minecraft:stone
fill 136 126 323 136 126 340 minecraft:deepslate
fill 136 126 342 136 126 344 minecraft:deepslate
fill 136 126 346 136 186 346 minecraft:deepslate
setblock 136 126 347 minecraft:diamond_block
fill 136 126 348 136 126 357 minecraft:deepslate
fill 136 126 359 136 126 364 minecraft:deepslate
fill 94 127 322 94 182 323 minecraft:deepslate
fill 94 127 324 94 128 324 minecraft:cobbled_deepslate
fill 94 127 325 94 127 335 minecraft:deepslate
fill 94 127 338 94 130 341 minecraft:deepslate
fill 94 127 342 94 127 343 minecraft:cobbled_deepslate
fill 94 127 344 94 127 351 minecraft:deepslate
setblock 94 127 352 minecraft:cobbled_deepslate
fill 94 127 353 94 140 360 minecraft:deepslate
fill 94 127 361 94 128 361 minecraft:cobbled_deepslate
fill 94 127 362 94 172 364 minecraft:deepslate
setblock 95 127 323 minecraft:stripped_spruce_log
fill 95 127 324 95 127 327 minecraft:stone
setblock 95 127 328 minecraft:stripped_spruce_log
fill 95 127 329 95 127 332 minecraft:stone
setblock 95 127 333 minecraft:stripped_spruce_log
fill 95 127 334 95 127 337 minecraft:stone
setblock 95 127 338 minecraft:stripped_spruce_log
fill 95 127 339 95 130 339 minecraft:stone
setblock 95 127 343 minecraft:stripped_spruce_log
fill 95 127 344 95 130 344 minecraft:stone
fill 95 127 354 95 127 357 minecraft:stone
setblock 95 127 358 minecraft:stripped_spruce_log
fill 95 127 359 95 130 359 minecraft:stone
setblock 95 127 363 minecraft:stripped_spruce_log
setblock 95 127 364 minecraft:cobbled_deepslate
fill 96 127 323 96 129 324 minecraft:stone
fill 96 127 329 96 127 331 minecraft:stone
setblock 96 127 332 minecraft:stripped_spruce_log
fill 96 127 333 96 127 336 minecraft:stone
setblock 96 127 337 minecraft:stripped_spruce_log
fill 96 127 338 96 130 338 minecraft:stone
setblock 96 127 342 minecraft:stripped_spruce_log
setblock 96 127 362 minecraft:stripped_spruce_log
fill 96 127 363 96 130 363 minecraft:stone
fill 96 127 364 99 127 364 minecraft:deepslate
setblock 97 127 325 minecraft:light[level=12]
setblock 97 127 332 minecraft:light[level=12]
setblock 97 127 336 minecraft:stripped_spruce_log
fill 97 127 337 97 128 337 minecraft:stone
setblock 97 127 339 minecraft:light[level=12]
setblock 97 127 346 minecraft:light[level=12]
setblock 97 127 353 minecraft:light[level=12]
setblock 97 127 360 minecraft:light[level=12]
fill 97 127 362 97 130 362 minecraft:stone
setblock 99 127 363 minecraft:stone
setblock 100 127 323 minecraft:stripped_spruce_log
setblock 100 127 363 minecraft:stripped_spruce_log
fill 101 127 322 104 127 322 minecraft:deepslate
fill 101 127 323 104 127 323 minecraft:stone
fill 101 127 363 104 127 363 minecraft:stone
fill 102 127 355 102 128 355 minecraft:raw_gold_block
fill 102 127 358 102 128 359 minecraft:raw_gold_block
fill 102 127 361 102 127 362 minecraft:raw_gold_block
setblock 104 127 325 minecraft:light[level=12]
setblock 104 127 332 minecraft:light[level=12]
setblock 104 127 339 minecraft:light[level=12]
setblock 104 127 346 minecraft:light[level=12]
setblock 104 127 353 minecraft:light[level=12]
setblock 104 127 360 minecraft:light[level=12]
setblock 105 127 322 minecraft:cobbled_deepslate
setblock 105 127 323 minecraft:stripped_spruce_log
setblock 105 127 362 minecraft:stone
setblock 105 127 363 minecraft:stripped_spruce_log
fill 106 127 322 110 130 322 minecraft:deepslate
fill 106 127 323 109 127 323 minecraft:stone
setblock 106 127 362 minecraft:stripped_spruce_log
fill 106 127 363 109 127 363 minecraft:stone
setblock 107 127 361 minecraft:stripped_spruce_log
fill 107 127 362 110 127 362 minecraft:stone
fill 108 127 324 109 127 326 minecraft:raw_gold_block
fill 108 127 361 108 130 361 minecraft:stone
setblock 109 127 327 minecraft:raw_gold_block
fill 109 127 360 112 127 360 minecraft:stone
setblock 110 127 323 minecraft:stripped_spruce_log
fill 110 127 324 112 128 324 minecraft:stone
fill 110 127 325 110 127 326 minecraft:raw_gold_block
setblock 110 127 363 minecraft:stripped_spruce_log
fill 110 127 364 116 130 364 minecraft:deepslate
setblock 111 127 322 minecraft:cobbled_deepslate
fill 111 127 323 111 130 323 minecraft:stone
setblock 111 127 325 minecraft:light[level=12]
setblock 111 127 332 minecraft:light[level=12]
setblock 111 127 339 minecraft:light[level=12]
setblock 111 127 346 minecraft:light[level=12]
setblock 111 127 353 minecraft:light[level=12]
setblock 111 127 362 minecraft:stripped_spruce_log
fill 111 127 363 114 127 363 minecraft:stone
fill 112 127 322 113 138 322 minecraft:deepslate
setblock 112 127 361 minecraft:stripped_spruce_log
fill 112 127 362 115 127 362 minecraft:stone
setblock 113 127 360 minecraft:stripped_spruce_log
fill 113 127 361 113 130 361 minecraft:stone
fill 114 127 360 114 130 360 minecraft:stone
fill 115 127 322 115 166 322 minecraft:deepslate
setblock 115 127 323 minecraft:stripped_spruce_log
setblock 115 127 363 minecraft:stripped_spruce_log
fill 116 127 323 116 130 323 minecraft:stone
setblock 116 127 362 minecraft:stripped_spruce_log
fill 116 127 363 116 130 363 minecraft:stone
setblock 117 127 361 minecraft:stripped_spruce_log
fill 117 127 362 117 130 362 minecraft:stone
setblock 117 127 364 minecraft:cobbled_deepslate
setblock 118 127 325 minecraft:light[level=12]
setblock 118 127 332 minecraft:light[level=12]
setblock 118 127 346 minecraft:light[level=12]
setblock 118 127 353 minecraft:light[level=12]
setblock 118 127 360 minecraft:light[level=12]
fill 118 127 361 118 130 361 minecraft:stone
fill 118 127 364 122 129 364 minecraft:deepslate
fill 119 127 322 119 181 322 minecraft:deepslate
setblock 119 127 363 minecraft:stone
setblock 120 127 362 minecraft:stone
setblock 120 127 363 minecraft:stripped_spruce_log
fill 121 127 363 123 128 363 minecraft:stone
setblock 122 127 322 minecraft:deepslate
setblock 125 127 325 minecraft:light[level=12]
setblock 125 127 332 minecraft:light[level=12]
setblock 125 127 339 minecraft:light[level=12]
setblock 125 127 346 minecraft:light[level=12]
setblock 125 127 353 minecraft:light[level=12]
setblock 125 127 360 minecraft:light[level=12]
setblock 125 127 363 minecraft:stripped_spruce_log
fill 126 127 363 129 127 363 minecraft:stone
fill 126 127 364 126 185 364 minecraft:deepslate
fill 129 127 362 130 127 362 minecraft:stone
setblock 130 127 363 minecraft:stripped_spruce_log
fill 131 127 323 133 128 323 minecraft:stone
setblock 131 127 362 minecraft:stripped_spruce_log
fill 131 127 363 131 130 363 minecraft:stone
fill 131 127 364 131 129 364 minecraft:deepslate
setblock 132 127 325 minecraft:light[level=12]
setblock 132 127 332 minecraft:light[level=12]
setblock 132 127 336 minecraft:stripped_spruce_log
fill 132 127 337 132 130 337 minecraft:stone
setblock 132 127 341 minecraft:stripped_spruce_log
fill 132 127 342 135 127 342 minecraft:stone
setblock 132 127 346 minecraft:light[level=12]
setblock 132 127 353 minecraft:light[level=12]
setblock 132 127 360 minecraft:light[level=12]
fill 132 127 362 132 130 362 minecraft:stone
setblock 132 127 364 minecraft:cobbled_deepslate
setblock 133 127 335 minecraft:stripped_spruce_log
fill 133 127 336 133 130 336 minecraft:stone
setblock 133 127 340 minecraft:stripped_spruce_log
fill 133 127 341 133 130 341 minecraft:stone
fill 133 127 343 133 127 344 minecraft:stone
setblock 133 127 345 minecraft:stripped_spruce_log
fill 133 127 364 135 162 364 minecraft:deepslate
fill 134 127 330 134 130 330 minecraft:stone
setblock 134 127 334 minecraft:stripped_spruce_log
fill 134 127 335 134 130 335 minecraft:stone
setblock 134 127 339 minecraft:stripped_spruce_log
fill 134 127 340 134 130 340 minecraft:stone
setblock 134 127 343 minecraft:stone
setblock 134 127 344 minecraft:stripped_spruce_log
fill 134 127 345 134 130 345 minecraft:stone
setblock 134 127 354 minecraft:stripped_spruce_log
fill 134 127 355 134 128 355 minecraft:stone
setblock 134 127 359 minecraft:stripped_spruce_log
fill 134 127 360 134 130 360 minecraft:stone
fill 134 127 362 134 127 363 minecraft:stone
setblock 135 127 323 minecraft:stripped_spruce_log
fill 135 127 324 135 127 327 minecraft:stone
setblock 135 127 328 minecraft:stripped_spruce_log
fill 135 127 329 135 130 329 minecraft:stone
setblock 135 127 333 minecraft:stripped_spruce_log
fill 135 127 334 135 130 334 minecraft:stone
setblock 135 127 338 minecraft:stripped_spruce_log
fill 135 127 339 135 130 339 minecraft:stone
setblock 135 127 343 minecraft:stripped_spruce_log
fill 135 127 344 135 130 344 minecraft:stone
setblock 135 127 348 minecraft:stripped_spruce_log
fill 135 127 349 135 130 349 minecraft:stone
setblock 135 127 353 minecraft:stripped_spruce_log
fill 135 127 354 135 130 354 minecraft:stone
setblock 135 127 358 minecraft:stripped_spruce_log
fill 135 127 359 135 130 359 minecraft:stone
setblock 135 127 363 minecraft:stripped_spruce_log
fill 136 127 323 136 127 330 minecraft:deepslate
fill 136 127 331 136 128 331 minecraft:cobbled_deepslate
fill 136 127 332 136 127 341 minecraft:deepslate
fill 136 127 342 136 128 342 minecraft:cobbled_deepslate
fill 136 127 343 136 154 344 minecraft:deepslate
fill 136 127 347 136 188 347 minecraft:deepslate
setblock 136 127 348 minecraft:cobbled_deepslate
fill 136 127 349 136 129 349 minecraft:deepslate
setblock 136 127 350 minecraft:cobbled_deepslate
fill 136 127 351 136 127 353 minecraft:deepslate
setblock 136 127 354 minecraft:cobbled_deepslate
fill 136 127 355 136 141 357 minecraft:deepslate
fill 136 127 359 136 127 363 minecraft:deepslate
fill 136 127 364 136 128 364 minecraft:cobbled_deepslate
fill 94 128 325 94 131 331 minecraft:deepslate
setblock 94 128 332 minecraft:cobbled_deepslate
fill 94 128 333 94 172 334 minecraft:deepslate
setblock 94 128 335 minecraft:cobbled_deepslate
fill 94 128 342 94 186 342 minecraft:deepslate
setblock 94 128 343 minecraft:cobbled_deepslate
fill 94 128 344 94 137 344 minecraft:deepslate
setblock 94 128 345 minecraft:diamond_block
fill 94 128 346 94 140 352 minecraft:deepslate
fill 95 128 323 95 128 326 minecraft:stone
setblock 95 128 327 minecraft:stripped_spruce_log
fill 95 128 328 95 128 331 minecraft:stone
setblock 95 128 332 minecraft:stripped_spruce_log
fill 95 128 333 95 128 336 minecraft:stone
setblock 95 128 337 minecraft:stripped_spruce_log
fill 95 128 338 95 131 338 minecraft:stone
setblock 95 128 342 minecraft:stripped_spruce_log
fill 95 128 343 96 130 343 minecraft:stone
setblock 95 128 346 minecraft:stone
fill 95 128 355 95 128 356 minecraft:stone
setblock 95 128 357 minecraft:stripped_spruce_log
fill 95 128 358 95 131 358 minecraft:stone
setblock 95 128 362 minecraft:stripped_spruce_log
fill 95 128 363 95 131 363 minecraft:stone
fill 95 128 364 97 151 364 minecraft:deepslate
setblock 96 128 325 minecraft:stone
setblock 96 128 326 minecraft:stripped_spruce_log
fill 96 128 329 96 128 330 minecraft:stone
setblock 96 128 331 minecraft:stripped_spruce_log
fill 96 128 332 96 128 335 minecraft:stone
setblock 96 128 336 minecraft:stripped_spruce_log
fill 96 128 337 96 131 337 minecraft:stone
setblock 96 128 341 minecraft:stripped_spruce_log
fill 96 128 342 96 131 342 minecraft:stone
setblock 96 128 361 minecraft:stripped_spruce_log
fill 96 128 362 96 131 362 minecraft:stone
setblock 97 128 324 minecraft:stone
fill 98 128 362 98 129 362 minecraft:stone
setblock 98 128 364 minecraft:cobbled_deepslate
setblock 99 128 323 minecraft:stripped_spruce_log
setblock 99 128 363 minecraft:stripped_spruce_log
fill 99 128 364 99 180 364 minecraft:deepslate
fill 100 128 323 103 128 323 minecraft:stone
fill 100 128 363 103 128 363 minecraft:stone
fill 101 128 322 101 182 322 minecraft:deepslate
fill 101 128 359 101 128 362 minecraft:raw_gold_block
setblock 102 128 322 minecraft:cobbled_deepslate
fill 102 128 356 102 128 357 minecraft:raw_gold_block
fill 102 128 360 103 129 361 minecraft:raw_gold_block
fill 102 128 362 104 128 362 minecraft:stone
fill 103 128 322 105 134 322 minecraft:deepslate
setblock 103 128 359 minecraft:raw_gold_block
setblock 104 128 323 minecraft:stripped_spruce_log
setblock 104 128 363 minecraft:stripped_spruce_log
fill 105 128 323 108 128 323 minecraft:stone
setblock 105 128 362 minecraft:stripped_spruce_log
fill 105 128 363 108 128 363 minecraft:stone
setblock 106 128 361 minecraft:stripped_spruce_log
fill 106 128 362 109 128 362 minecraft:stone
setblock 107 128 324 minecraft:stone
fill 107 128 361 107 131 361 minecraft:stone
setblock 108 128 324 minecraft:stripped_spruce_log
fill 108 128 360 111 128 360 minecraft:stone
setblock 109 128 323 minecraft:stripped_spruce_log
fill 109 128 324 109 131 324 minecraft:stone
setblock 109 128 325 minecraft:raw_gold_block
setblock 109 128 363 minecraft:stripped_spruce_log
fill 110 128 323 110 131 323 minecraft:stone
setblock 110 128 362 minecraft:stripped_spruce_log
fill 110 128 363 113 128 363 minecraft:stone
fill 111 128 322 111 174 322 minecraft:deepslate
setblock 111 128 361 minecraft:stripped_spruce_log
fill 111 128 362 114 128 362 minecraft:stone
setblock 112 128 360 minecraft:stripped_spruce_log
fill 112 128 361 112 131 361 minecraft:stone
setblock 113 128 324 minecraft:stripped_spruce_log
fill 113 128 360 113 131 360 minecraft:stone
setblock 114 128 323 minecraft:stripped_spruce_log
setblock 114 128 363 minecraft:stripped_spruce_log
fill 115 128 323 115 131 323 minecraft:stone
setblock 115 128 362 minecraft:stripped_spruce_log
fill 115 128 363 115 131 363 minecraft:stone
setblock 116 128 361 minecraft:stripped_spruce_log
fill 116 128 362 116 131 362 minecraft:stone
fill 117 128 323 117 129 323 minecraft:stone
fill 117 128 361 117 131 361 minecraft:stone
fill 117 128 364 117 139 364 minecraft:deepslate
setblock 119 128 363 minecraft:stripped_spruce_log
setblock 120 128 362 minecraft:stripped_spruce_log
fill 120 128 363 120 131 363 minecraft:stone
setblock 122 128 322 minecraft:gold_block
fill 123 128 322 125 144 322 minecraft:deepslate
setblock 124 128 363 minecraft:stripped_spruce_log
fill 125 128 363 128 128 363 minecraft:stone
setblock 126 128 322 minecraft:gold_block
fill 127 128 322 129 156 322 minecraft:deepslate
fill 127 128 362 129 128 362 minecraft:stone
setblock 129 128 323 minecraft:stripped_spruce_log
setblock 129 128 363 minecraft:stripped_spruce_log
setblock 130 128 322 minecraft:raw_gold_block
fill 130 128 323 130 131 323 minecraft:stone
setblock 130 128 362 minecraft:stripped_spruce_log
fill 130 128 363 130 131 363 minecraft:stone
fill 131 128 322 131 165 322 minecraft:deepslate
setblock 131 128 361 minecraft:stripped_spruce_log
fill 131 128 362 131 131 362 minecraft:stone
fill 132 128 322 133 128 322 minecraft:cobbled_deepslate
setblock 132 128 335 minecraft:stripped_spruce_log
fill 132 128 336 132 131 336 minecraft:stone
fill 132 128 338 132 128 339 minecraft:stone
setblock 132 128 340 minecraft:stripped_spruce_log
fill 132 128 341 132 129 343 minecraft:stone
fill 132 128 364 132 136 364 minecraft:deepslate
setblock 133 128 334 minecraft:stripped_spruce_log
fill 133 128 335 133 131 335 minecraft:stone
setblock 133 128 339 minecraft:stripped_spruce_log
fill 133 128 340 133 131 340 minecraft:stone
fill 133 128 342 133 128 343 minecraft:stone
setblock 133 128 344 minecraft:stripped_spruce_log
fill 133 128 345 133 130 346 minecraft:stone
fill 134 128 322 136 150 322 minecraft:deepslate
setblock 134 128 323 minecraft:stripped_spruce_log
setblock 134 128 333 minecraft:stripped_spruce_log
fill 134 128 334 134 131 334 minecraft:stone
setblock 134 128 338 minecraft:stripped_spruce_log
fill 134 128 339 134 131 339 minecraft:stone
setblock 134 128 342 minecraft:stone
setblock 134 128 343 minecraft:stripped_spruce_log
fill 134 128 344 134 131 344 minecraft:stone
fill 134 128 346 134 128 347 minecraft:stone
setblock 134 128 348 minecraft:stripped_spruce_log
setblock 134 128 354 minecraft:stone
setblock 134 128 358 minecraft:stripped_spruce_log
fill 134 128 359 134 131 359 minecraft:stone
setblock 134 128 362 minecraft:stone
setblock 134 128 363 minecraft:stripped_spruce_log
fill 135 128 323 135 128 326 minecraft:stone
setblock 135 128 327 minecraft:stripped_spruce_log
fill 135 128 328 135 131 328 minecraft:stone
setblock 135 128 332 minecraft:stripped_spruce_log
fill 135 128 333 135 131 333 minecraft:stone
setblock 135 128 337 minecraft:stripped_spruce_log
fill 135 128 338 135 131 338 minecraft:stone
setblock 135 128 342 minecraft:stripped_spruce_log
fill 135 128 343 135 131 343 minecraft:stone
setblock 135 128 346 minecraft:stone
setblock 135 128 347 minecraft:stripped_spruce_log
fill 135 128 348 135 131 348 minecraft:stone
setblock 135 128 352 minecraft:stripped_spruce_log
fill 135 128 353 135 130 353 minecraft:stone
setblock 135 128 357 minecraft:stripped_spruce_log
fill 135 128 358 135 131 358 minecraft:stone
setblock 135 128 362 minecraft:stripped_spruce_log
fill 135 128 363 135 131 363 minecraft:stone
fill 136 128 323 136 153 323 minecraft:deepslate
setblock 136 128 324 minecraft:cobbled_deepslate
fill 136 128 325 136 160 325 minecraft:deepslate
setblock 136 128 326 minecraft:diamond_block
fill 136 128 327 136 137 330 minecraft:deepslate
fill 136 128 332 136 129 335 minecraft:deepslate
setblock 136 128 336 minecraft:cobbled_deepslate
fill 136 128 337 136 171 340 minecraft:deepslate
setblock 136 128 341 minecraft:cobbled_deepslate
fill 136 128 345 136 129 345 minecraft:deepslate
fill 136 128 348 136 187 348 minecraft:deepslate
setblock 136 128 350 minecraft:deepslate
setblock 136 128 351 minecraft:cobbled_deepslate
fill 136 128 352 136 130 354 minecraft:deepslate
fill 136 128 358 136 146 360 minecraft:deepslate
setblock 136 128 361 minecraft:cobbled_deepslate
fill 136 128 362 136 137 363 minecraft:deepslate
fill 94 129 324 94 184 324 minecraft:deepslate
fill 94 129 332 94 153 332 minecraft:deepslate
fill 94 129 335 94 143 335 minecraft:deepslate
fill 94 129 343 94 139 343 minecraft:deepslate
fill 94 129 345 94 149 345 minecraft:deepslate
fill 94 129 361 94 186 361 minecraft:deepslate
fill 95 129 323 95 129 325 minecraft:stone
setblock 95 129 326 minecraft:stripped_spruce_log
fill 95 129 327 95 129 330 minecraft:stone
setblock 95 129 331 minecraft:stripped_spruce_log
fill 95 129 332 95 129 335 minecraft:stone
setblock 95 129 336 minecraft:stripped_spruce_log
fill 95 129 337 95 132 337 minecraft:stone
setblock 95 129 341 minecraft:stripped_spruce_log
fill 95 129 342 95 132 342 minecraft:stone
setblock 95 129 346 minecraft:stripped_spruce_log
setblock 95 129 355 minecraft:stone
setblock 95 129 356 minecraft:stripped_spruce_log
fill 95 129 357 95 131 357 minecraft:stone
setblock 95 129 360 minecraft:stone
setblock 95 129 361 minecraft:stripped_spruce_log
fill 95 129 362 95 132 362 minecraft:stone
setblock 96 129 325 minecraft:stripped_spruce_log
fill 96 129 326 96 129 329 minecraft:stone
setblock 96 129 330 minecraft:stripped_spruce_log
fill 96 129 331 96 129 334 minecraft:stone
setblock 96 129 335 minecraft:stripped_spruce_log
fill 96 129 336 96 131 336 minecraft:stone
setblock 96 129 340 minecraft:stripped_spruce_log
fill 96 129 341 96 132 341 minecraft:stone
setblock 96 129 360 minecraft:stripped_spruce_log
fill 96 129 361 96 132 361 minecraft:stone
setblock 97 129 324 minecraft:stripped_spruce_log
setblock 98 129 323 minecraft:stripped_spruce_log
fill 98 129 324 98 132 324 minecraft:stone
setblock 98 129 363 minecraft:stripped_spruce_log
fill 98 129 364 98 186 364 minecraft:deepslate
fill 99 129 323 102 129 323 minecraft:stone
setblock 99 129 362 minecraft:stripped_spruce_log
fill 99 129 363 102 129 363 minecraft:stone
fill 100 129 362 103 129 362 minecraft:stone
fill 101 129 360 101 129 361 minecraft:raw_gold_block
fill 102 129 322 102 147 322 minecraft:deepslate
setblock 102 129 359 minecraft:raw_gold_block
setblock 103 129 323 minecraft:stripped_spruce_log
setblock 103 129 363 minecraft:stripped_spruce_log
fill 104 129 323 107 129 323 minecraft:stone
setblock 104 129 362 minecraft:stripped_spruce_log
fill 104 129 363 107 129 363 minecraft:stone
fill 105 129 324 106 129 324 minecraft:stone
setblock 105 129 361 minecraft:stripped_spruce_log
fill 105 129 362 108 129 362 minecraft:stone
fill 106 129 361 106 132 361 minecraft:stone
setblock 107 129 324 minecraft:stripped_spruce_log
fill 107 129 360 110 129 360 minecraft:stone
setblock 108 129 323 minecraft:stripped_spruce_log
fill 108 129 324 108 132 324 minecraft:stone
setblock 108 129 363 minecraft:stripped_spruce_log
fill 109 129 323 109 132 323 minecraft:stone
setblock 109 129 362 minecraft:stripped_spruce_log
fill 109 129 363 112 129 363 minecraft:stone
fill 110 129 324 111 129 324 minecraft:stone
setblock 110 129 361 minecraft:stripped_spruce_log
fill 110 129 362 113 129 362 minecraft:stone
setblock 111 129 360 minecraft:stripped_spruce_log
fill 111 129 361 111 132 361 minecraft:stone
setblock 112 129 324 minecraft:stripped_spruce_log
setblock 112 129 359 minecraft:stripped_spruce_log
fill 112 129 360 112 132 360 minecraft:stone
setblock 113 129 323 minecraft:stripped_spruce_log
fill 113 129 324 114 131 324 minecraft:stone
setblock 113 129 363 minecraft:stripped_spruce_log
fill 114 129 323 114 132 323 minecraft:stone
setblock 114 129 362 minecraft:stripped_spruce_log
fill 114 129 363 114 132 363 minecraft:stone
setblock 115 129 360 minecraft:stone
setblock 115 129 361 minecraft:stripped_spruce_log
fill 115 129 362 115 131 362 minecraft:stone
setblock 116 129 360 minecraft:stripped_spruce_log
fill 116 129 361 116 132 361 minecraft:stone
setblock 118 129 363 minecraft:stripped_spruce_log
setblock 119 129 362 minecraft:stripped_spruce_log
fill 119 129 363 119 132 363 minecraft:stone
fill 120 129 362 122 130 362 minecraft:stone
fill 121 129 363 122 129 363 minecraft:stone
fill 122 129 322 122 140 322 minecraft:deepslate
setblock 123 129 363 minecraft:stripped_spruce_log
setblock 124 129 362 minecraft:stripped_spruce_log
fill 124 129 363 127 129 363 minecraft:stone
fill 125 129 362 128 129 362 minecraft:stone
fill 126 129 322 126 131 322 minecraft:deepslate
setblock 127 129 323 minecraft:stone
setblock 128 129 323 minecraft:stripped_spruce_log
setblock 128 129 363 minecraft:stripped_spruce_log
fill 129 129 323 129 132 323 minecraft:stone
setblock 129 129 361 minecraft:stone
setblock 129 129 362 minecraft:stripped_spruce_log
fill 129 129 363 129 132 363 minecraft:stone
fill 130 129 322 130 141 322 minecraft:deepslate
setblock 130 129 361 minecraft:stripped_spruce_log
fill 130 129 362 130 132 362 minecraft:stone
fill 131 129 323 131 129 324 minecraft:stone
fill 131 129 338 131 129 339 minecraft:stone
setblock 131 129 340 minecraft:stripped_spruce_log
fill 131 129 341 131 132 341 minecraft:stone
fill 131 129 361 133 130 361 minecraft:stone
fill 132 129 322 133 173 322 minecraft:deepslate
setblock 132 129 323 minecraft:stone
setblock 132 129 324 minecraft:stripped_spruce_log
fill 132 129 335 132 130 335 minecraft:stone
setblock 132 129 338 minecraft:stone
setblock 132 129 339 minecraft:stripped_spruce_log
fill 132 129 340 132 132 340 minecraft:stone
setblock 132 129 344 minecraft:stripped_spruce_log
setblock 133 129 323 minecraft:stripped_spruce_log
fill 133 129 324 135 130 324 minecraft:stone
setblock 133 129 333 minecraft:stripped_spruce_log
fill 133 129 334 133 132 334 minecraft:stone
setblock 133 129 338 minecraft:stripped_spruce_log
fill 133 129 339 133 132 339 minecraft:stone
setblock 133 129 342 minecraft:stone
setblock 133 129 343 minecraft:stripped_spruce_log
fill 133 129 344 133 132 344 minecraft:stone
setblock 133 129 360 minecraft:stone
setblock 133 129 363 minecraft:stripped_spruce_log
fill 134 129 323 135 131 323 minecraft:stone
fill 134 129 329 134 131 329 minecraft:stone
setblock 134 129 332 minecraft:stripped_spruce_log
fill 134 129 333 134 132 333 minecraft:stone
setblock 134 129 337 minecraft:stripped_spruce_log
fill 134 129 338 134 132 338 minecraft:stone
setblock 134 129 341 minecraft:stone
setblock 134 129 342 minecraft:stripped_spruce_log
fill 134 129 343 134 131 343 minecraft:stone
setblock 134 129 346 minecraft:stone
setblock 134 129 347 minecraft:stripped_spruce_log
fill 134 129 348 134 132 348 minecraft:stone
setblock 134 129 357 minecraft:stripped_spruce_log
fill 134 129 358 134 130 358 minecraft:stone
setblock 134 129 362 minecraft:stripped_spruce_log
fill 134 129 363 134 132 363 minecraft:stone
setblock 135 129 325 minecraft:stone
setblock 135 129 326 minecraft:stripped_spruce_log
fill 135 129 327 135 132 327 minecraft:stone
setblock 135 129 331 minecraft:stripped_spruce_log
fill 135 129 332 135 132 332 minecraft:stone
setblock 135 129 336 minecraft:stripped_spruce_log
fill 135 129 337 135 132 337 minecraft:stone
setblock 135 129 341 minecraft:stripped_spruce_log
fill 135 129 342 135 132 342 minecraft:stone
setblock 135 129 346 minecraft:stripped_spruce_log
fill 135 129 347 135 132 347 minecraft:stone
setblock 135 129 351 minecraft:stripped_spruce_log
fill 135 129 352 135 130 352 minecraft:stone
setblock 135 129 356 minecraft:stripped_spruce_log
fill 135 129 357 135 131 357 minecraft:stone
setblock 135 129 361 minecraft:stripped_spruce_log
fill 135 129 362 135 132 362 minecraft:stone
fill 136 129 324 136 186 324 minecraft:deepslate
fill 136 129 326 136 153 326 minecraft:deepslate
fill 136 129 331 136 180 331 minecraft:deepslate
fill 136 129 336 136 133 336 minecraft:deepslate
fill 136 129 341 136 172 342 minecraft:deepslate
setblock 136 129 350 minecraft:raw_gold_block
fill 136 129 351 136 138 351 minecraft:deepslate
fill 136 129 361 136 185 361 minecraft:deepslate
fill 136 129 364 136 186 364 minecraft:deepslate
fill 95 130 323 95 130 324 minecraft:stone
setblock 95 130 325 minecraft:stripped_spruce_log
fill 95 130 326 95 130 329 minecraft:stone
setblock 95 130 330 minecraft:stripped_spruce_log
fill 95 130 331 95 130 334 minecraft:stone
setblock 95 130 335 minecraft:stripped_spruce_log
fill 95 130 336 95 133 336 minecraft:stone
setblock 95 130 340 minecraft:stripped_spruce_log
fill 95 130 341 95 133 341 minecraft:stone
setblock 95 130 345 minecraft:stripped_spruce_log
fill 95 130 346 95 131 347 minecraft:stone
setblock 95 130 356 minecraft:stone
setblock 95 130 360 minecraft:stripped_spruce_log
fill 95 130 361 95 133 361 minecraft:stone
setblock 96 130 323 minecraft:stone
setblock 96 130 324 minecraft:stripped_spruce_log
fill 96 130 325 96 130 328 minecraft:stone
fill 96 130 332 96 130 333 minecraft:stone
setblock 96 130 334 minecraft:stripped_spruce_log
fill 96 130 335 96 131 335 minecraft:stone
setblock 96 130 339 minecraft:stripped_spruce_log
fill 96 130 340 96 132 340 minecraft:stone
fill 96 130 357 97 131 358 minecraft:raw_gold_block
setblock 96 130 359 minecraft:stripped_spruce_log
fill 96 130 360 96 131 360 minecraft:stone
setblock 97 130 323 minecraft:stripped_spruce_log
fill 97 130 324 97 133 324 minecraft:stone
fill 97 130 359 97 131 359 minecraft:raw_gold_block
setblock 97 130 363 minecraft:stripped_spruce_log
fill 98 130 323 101 130 323 minecraft:stone
fill 98 130 358 98 131 358 minecraft:raw_gold_block
setblock 98 130 362 minecraft:stripped_spruce_log
fill 98 130 363 101 130 363 minecraft:stone
fill 99 130 324 100 130 324 minecraft:stone
fill 99 130 362 102 130 362 minecraft:stone
setblock 101 130 324 minecraft:stripped_spruce_log
setblock 102 130 323 minecraft:stripped_spruce_log
fill 102 130 324 105 130 324 minecraft:stone
setblock 102 130 363 minecraft:stripped_spruce_log
fill 103 130 323 106 130 323 minecraft:stone
setblock 103 130 362 minecraft:stripped_spruce_log
fill 103 130 363 106 130 363 minecraft:stone
setblock 104 130 361 minecraft:stripped_spruce_log
fill 104 130 362 107 130 362 minecraft:stone
fill 105 130 361 105 133 361 minecraft:stone
setblock 106 130 324 minecraft:stripped_spruce_log
setblock 107 130 323 minecraft:stripped_spruce_log
fill 107 130 324 107 133 324 minecraft:stone
fill 107 130 360 109 130 360 minecraft:stone
setblock 107 130 363 minecraft:stripped_spruce_log
fill 108 130 323 108 133 323 minecraft:stone
setblock 108 130 362 minecraft:stripped_spruce_log
fill 108 130 363 111 130 363 minecraft:stone
setblock 109 130 361 minecraft:stripped_spruce_log
fill 109 130 362 112 130 362 minecraft:stone
setblock 110 130 324 minecraft:stone
setblock 110 130 360 minecraft:stripped_spruce_log
fill 110 130 361 110 133 361 minecraft:stone
setblock 111 130 324 minecraft:stripped_spruce_log
setblock 111 130 359 minecraft:stripped_spruce_log
fill 111 130 360 111 133 360 minecraft:stone
setblock 112 130 323 minecraft:stripped_spruce_log
fill 112 130 324 112 133 324 minecraft:stone
setblock 112 130 363 minecraft:stripped_spruce_log
fill 113 130 323 113 133 323 minecraft:stone
setblock 113 130 362 minecraft:stripped_spruce_log
fill 113 130 363 113 133 363 minecraft:stone
setblock 114 130 361 minecraft:stripped_spruce_log
fill 114 130 362 114 133 362 minecraft:stone
setblock 115 130 360 minecraft:stripped_spruce_log
fill 115 130 361 115 133 361 minecraft:stone
setblock 117 130 323 minecraft:stripped_spruce_log
setblock 117 130 363 minecraft:stripped_spruce_log
setblock 118 130 362 minecraft:stripped_spruce_log
fill 118 130 363 118 133 363 minecraft:stone
fill 118 130 364 121 164 364 minecraft:deepslate
fill 119 130 362 119 132 362 minecraft:stone
setblock 121 130 363 minecraft:stone
setblock 122 130 363 minecraft:stripped_spruce_log
setblock 122 130 364 minecraft:raw_gold_block
setblock 123 130 362 minecraft:stripped_spruce_log
fill 123 130 363 126 130 363 minecraft:stone
fill 124 130 362 127 130 362 minecraft:stone
setblock 126 130 323 minecraft:stone
setblock 127 130 323 minecraft:stripped_spruce_log
setblock 127 130 363 minecraft:stripped_spruce_log
fill 128 130 323 128 133 323 minecraft:stone
setblock 128 130 361 minecraft:stone
setblock 128 130 362 minecraft:stripped_spruce_log
fill 128 130 363 128 133 363 minecraft:stone
fill 129 130 324 130 130 324 minecraft:stone
fill 129 130 342 130 145 343 minecraft:stripped_spruce_log
setblock 129 130 361 minecraft:stripped_spruce_log
fill 129 130 362 129 133 362 minecraft:stone
fill 130 130 361 130 132 361 minecraft:stone
setblock 131 130 323 minecraft:stone
setblock 131 130 324 minecraft:stripped_spruce_log
setblock 131 130 338 minecraft:stone
setblock 131 130 339 minecraft:stripped_spruce_log
fill 131 130 340 131 132 340 minecraft:stone
fill 131 130 342 132 130 342 minecraft:stone
fill 131 130 343 132 130 343 minecraft:stripped_spruce_log
setblock 131 130 364 minecraft:diamond_block
setblock 132 130 323 minecraft:stripped_spruce_log
fill 132 130 324 132 133 324 minecraft:stone
setblock 132 130 338 minecraft:stripped_spruce_log
fill 132 130 339 132 133 339 minecraft:stone
fill 132 130 341 132 131 341 minecraft:stone
fill 132 130 344 132 132 345 minecraft:stone
setblock 132 130 363 minecraft:stripped_spruce_log
fill 133 130 323 133 133 323 minecraft:stone
fill 133 130 333 133 131 333 minecraft:stone
setblock 133 130 337 minecraft:stripped_spruce_log
fill 133 130 338 133 133 338 minecraft:stone
setblock 133 130 342 minecraft:stripped_spruce_log
fill 133 130 343 133 133 343 minecraft:stone
setblock 133 130 347 minecraft:stripped_spruce_log
setblock 133 130 362 minecraft:stripped_spruce_log
fill 133 130 363 133 133 363 minecraft:stone
setblock 134 130 325 minecraft:stone
setblock 134 130 326 minecraft:stripped_spruce_log
fill 134 130 327 134 132 328 minecraft:stone
setblock 134 130 331 minecraft:stripped_spruce_log
fill 134 130 332 134 133 332 minecraft:stone
setblock 134 130 336 minecraft:stripped_spruce_log
fill 134 130 337 134 133 337 minecraft:stone
setblock 134 130 341 minecraft:stripped_spruce_log
fill 134 130 342 134 133 342 minecraft:stone
setblock 134 130 346 minecraft:stripped_spruce_log
fill 134 130 347 134 133 347 minecraft:stone
setblock 134 130 357 minecraft:stone
setblock 134 130 361 minecraft:stripped_spruce_log
fill 134 130 362 134 131 362 minecraft:stone
setblock 135 130 325 minecraft:stripped_spruce_log
fill 135 130 326 135 133 326 minecraft:stone
setblock 135 130 330 minecraft:stripped_spruce_log
fill 135 130 331 135 133 331 minecraft:stone
setblock 135 130 335 minecraft:stripped_spruce_log
fill 135 130 336 135 133 336 minecraft:stone
setblock 135 130 340 minecraft:stripped_spruce_log
fill 135 130 341 135 133 341 minecraft:stone
setblock 135 130 345 minecraft:stripped_spruce_log
fill 135 130 346 135 133 346 minecraft:stone
setblock 135 130 350 minecraft:stripped_spruce_log
setblock 135 130 351 minecraft:stone
setblock 135 130 355 minecraft:stripped_spruce_log
fill 135 130 356 135 131 356 minecraft:stone
setblock 135 130 360 minecraft:stripped_spruce_log
fill 135 130 361 135 133 361 minecraft:stone
fill 136 130 332 136 139 332 minecraft:deepslate
setblock 136 130 333 minecraft:raw_gold_block
fill 136 130 334 136 150 335 minecraft:deepslate
setblock 136 130 345 minecraft:gold_block
setblock 136 130 349 minecraft:raw_gold_block
fill 136 130 350 136 153 350 minecraft:deepslate
fill 94 131 338 94 186 338 minecraft:deepslate
setblock 94 131 339 minecraft:diamond_block
fill 94 131 340 94 170 341 minecraft:deepslate
setblock 95 131 323 minecraft:stone
setblock 95 131 324 minecraft:stripped_spruce_log
fill 95 131 325 95 131 328 minecraft:stone
setblock 95 131 329 minecraft:stripped_spruce_log
fill 95 131 330 95 131 333 minecraft:stone
setblock 95 131 334 minecraft:stripped_spruce_log
fill 95 131 335 95 133 335 minecraft:stone
setblock 95 131 339 minecraft:stripped_spruce_log
fill 95 131 340 95 134 340 minecraft:stone
setblock 95 131 343 minecraft:stone
setblock 95 131 344 minecraft:stripped_spruce_log
fill 95 131 345 95 134 345 minecraft:stone
setblock 95 131 359 minecraft:stripped_spruce_log
fill 95 131 360 95 134 360 minecraft:stone
setblock 96 131 323 minecraft:stripped_spruce_log
fill 96 131 324 96 131 327 minecraft:stone
setblock 96 131 334 minecraft:stone
setblock 96 131 338 minecraft:stripped_spruce_log
fill 96 131 339 96 132 339 minecraft:stone
setblock 96 131 343 minecraft:stripped_spruce_log
fill 96 131 359 96 132 359 minecraft:raw_gold_block
setblock 96 131 363 minecraft:stripped_spruce_log
fill 97 131 323 100 131 323 minecraft:stone
setblock 97 131 325 minecraft:light[level=15]
setblock 97 131 333 minecraft:light[level=15]
setblock 97 131 341 minecraft:light[level=15]
setblock 97 131 349 minecraft:light[level=15]
setblock 97 131 362 minecraft:stripped_spruce_log
fill 97 131 363 100 131 363 minecraft:stone
fill 98 131 362 101 131 362 minecraft:stone
setblock 99 131 324 minecraft:stone
setblock 100 131 324 minecraft:stripped_spruce_log
setblock 101 131 323 minecraft:stripped_spruce_log
fill 101 131 324 104 131 324 minecraft:stone
setblock 101 131 363 minecraft:stripped_spruce_log
fill 102 131 323 105 131 323 minecraft:stone
setblock 102 131 362 minecraft:stripped_spruce_log
fill 102 131 363 105 131 363 minecraft:stone
setblock 103 131 361 minecraft:stripped_spruce_log
fill 103 131 362 106 131 362 minecraft:stone
fill 104 131 361 104 134 361 minecraft:stone
setblock 105 131 324 minecraft:stripped_spruce_log
setblock 105 131 325 minecraft:light[level=15]
setblock 105 131 333 minecraft:light[level=15]
setblock 105 131 341 minecraft:light[level=15]
setblock 105 131 349 minecraft:light[level=15]
setblock 105 131 357 minecraft:light[level=15]
setblock 106 131 322 minecraft:raw_iron_block
setblock 106 131 323 minecraft:stripped_spruce_log
fill 106 131 324 106 134 324 minecraft:stone
fill 106 131 360 108 131 360 minecraft:stone
setblock 106 131 363 minecraft:stripped_spruce_log
fill 107 131 322 110 148 322 minecraft:deepslate
fill 107 131 323 107 134 323 minecraft:stone
fill 107 131 325 108 131 325 minecraft:stone
setblock 107 131 362 minecraft:stripped_spruce_log
fill 107 131 363 110 131 363 minecraft:stone
setblock 108 131 361 minecraft:stripped_spruce_log
fill 108 131 362 111 131 362 minecraft:stone
setblock 109 131 325 minecraft:stripped_spruce_log
setblock 109 131 360 minecraft:stripped_spruce_log
fill 109 131 361 109 134 361 minecraft:stone
setblock 110 131 324 minecraft:stripped_spruce_log
fill 110 131 325 110 133 325 minecraft:stone
fill 110 131 360 110 134 360 minecraft:stone
fill 110 131 364 112 152 364 minecraft:deepslate
setblock 111 131 323 minecraft:stripped_spruce_log
fill 111 131 324 111 134 324 minecraft:stone
setblock 111 131 363 minecraft:stripped_spruce_log
fill 112 131 323 112 134 323 minecraft:stone
setblock 112 131 362 minecraft:stripped_spruce_log
fill 112 131 363 112 134 363 minecraft:stone
setblock 113 131 325 minecraft:light[level=15]
setblock 113 131 333 minecraft:light[level=15]
setblock 113 131 341 minecraft:light[level=15]
setblock 113 131 349 minecraft:light[level=15]
setblock 113 131 357 minecraft:light[level=15]
setblock 113 131 361 minecraft:stripped_spruce_log
fill 113 131 362 113 134 362 minecraft:stone
setblock 113 131 364 minecraft:diamond_block
setblock 114 131 360 minecraft:stripped_spruce_log
fill 114 131 361 114 133 361 minecraft:stone
fill 114 131 364 116 156 364 minecraft:deepslate
setblock 115 131 360 minecraft:stone
setblock 116 131 323 minecraft:stripped_spruce_log
setblock 116 131 363 minecraft:stripped_spruce_log
fill 117 131 323 118 132 323 minecraft:stone
setblock 117 131 362 minecraft:stripped_spruce_log
fill 117 131 363 117 134 363 minecraft:stone
fill 118 131 362 118 133 362 minecraft:stone
fill 120 131 362 121 131 362 minecraft:stone
setblock 121 131 325 minecraft:light[level=15]
setblock 121 131 333 minecraft:light[level=15]
setblock 121 131 341 minecraft:light[level=15]
setblock 121 131 349 minecraft:light[level=15]
setblock 121 131 357 minecraft:light[level=15]
setblock 121 131 363 minecraft:stripped_spruce_log
setblock 122 131 362 minecraft:stripped_spruce_log
fill 122 131 363 125 131 363 minecraft:stone
fill 122 131 364 122 132 364 minecraft:deepslate
fill 123 131 362 126 131 362 minecraft:stone
fill 124 131 323 125 131 323 minecraft:stone
setblock 126 131 323 minecraft:stripped_spruce_log
setblock 126 131 363 minecraft:stripped_spruce_log
fill 127 131 323 127 134 323 minecraft:stone
setblock 127 131 361 minecraft:stone
setblock 127 131 362 minecraft:stripped_spruce_log
fill 127 131 363 127 134 363 minecraft:stone
fill 128 131 324 129 131 324 minecraft:stone
setblock 128 131 361 minecraft:stripped_spruce_log
fill 128 131 362 128 134 362 minecraft:stone
setblock 129 131 325 minecraft:light[level=15]
setblock 129 131 341 minecraft:light[level=15]
setblock 129 131 349 minecraft:light[level=15]
setblock 129 131 357 minecraft:light[level=15]
fill 129 131 361 129 132 361 minecraft:stone
setblock 130 131 324 minecraft:stripped_spruce_log
setblock 131 131 323 minecraft:stripped_spruce_log
fill 131 131 324 131 134 324 minecraft:stone
setblock 131 131 338 minecraft:stripped_spruce_log
fill 131 131 339 131 132 339 minecraft:stone
setblock 131 131 342 minecraft:stone
setblock 131 131 343 minecraft:stripped_spruce_log
fill 131 131 361 132 131 361 minecraft:stone
setblock 131 131 363 minecraft:stripped_spruce_log
fill 131 131 364 131 178 364 minecraft:deepslate
fill 132 131 323 132 134 323 minecraft:stone
setblock 132 131 337 minecraft:stripped_spruce_log
fill 132 131 338 132 133 338 minecraft:stone
setblock 132 131 342 minecraft:stripped_spruce_log
fill 132 131 343 132 134 343 minecraft:stone
setblock 132 131 362 minecraft:stripped_spruce_log
fill 132 131 363 132 134 363 minecraft:stone
fill 133 131 324 134 131 324 minecraft:stone
setblock 133 131 336 minecraft:stripped_spruce_log
fill 133 131 337 133 134 337 minecraft:stone
schedule function dropper:buildpart/74_3 1t
