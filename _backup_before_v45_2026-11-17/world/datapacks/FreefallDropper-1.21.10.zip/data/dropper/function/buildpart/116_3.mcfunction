setblock 391 295 504 minecraft:sea_lantern
setblock 392 295 499 minecraft:sea_lantern
setblock 392 295 501 minecraft:sea_lantern
setblock 392 295 503 minecraft:sea_lantern
setblock 393 295 498 minecraft:sea_lantern
setblock 393 295 500 minecraft:sea_lantern
setblock 393 295 502 minecraft:sea_lantern
setblock 393 295 504 minecraft:sea_lantern
setblock 394 295 499 minecraft:sea_lantern
setblock 394 295 501 minecraft:sea_lantern
setblock 394 295 503 minecraft:sea_lantern
setblock 395 295 498 minecraft:sea_lantern
setblock 395 295 500 minecraft:sea_lantern
setblock 395 295 502 minecraft:sea_lantern
setblock 395 295 504 minecraft:sea_lantern
setblock 396 295 499 minecraft:sea_lantern
setblock 396 295 501 minecraft:sea_lantern
setblock 396 295 503 minecraft:sea_lantern
setblock 397 295 498 minecraft:sea_lantern
setblock 397 295 500 minecraft:sea_lantern
setblock 397 295 502 minecraft:sea_lantern
setblock 397 295 504 minecraft:sea_lantern
setblock 398 295 499 minecraft:sea_lantern
setblock 398 295 501 minecraft:sea_lantern
setblock 398 295 503 minecraft:sea_lantern
setblock 399 295 498 minecraft:sea_lantern
setblock 399 295 500 minecraft:sea_lantern
setblock 399 295 502 minecraft:sea_lantern
setblock 399 295 504 minecraft:sea_lantern
setblock 417 295 503 minecraft:black_concrete
fill 377 296 470 377 297 470 minecraft:black_concrete
fill 377 296 472 377 297 472 minecraft:black_concrete
fill 377 296 474 377 297 474 minecraft:black_concrete
fill 377 296 476 377 297 476 minecraft:black_concrete
fill 378 296 471 378 297 471 minecraft:black_concrete
fill 378 296 473 378 297 473 minecraft:black_concrete
fill 378 296 475 378 297 475 minecraft:black_concrete
fill 379 296 470 379 297 470 minecraft:black_concrete
fill 379 296 472 379 297 472 minecraft:black_concrete
fill 379 296 474 379 297 474 minecraft:black_concrete
fill 379 296 476 379 297 476 minecraft:black_concrete
fill 380 296 471 380 297 471 minecraft:black_concrete
fill 380 296 473 380 297 473 minecraft:black_concrete
fill 380 296 475 380 297 475 minecraft:black_concrete
fill 381 296 470 381 297 470 minecraft:black_concrete
fill 381 296 472 381 297 472 minecraft:black_concrete
fill 381 296 474 381 297 474 minecraft:black_concrete
fill 381 296 476 381 297 476 minecraft:black_concrete
fill 382 296 471 382 297 471 minecraft:black_concrete
fill 382 296 473 382 297 473 minecraft:black_concrete
fill 382 296 475 382 297 475 minecraft:black_concrete
fill 383 296 470 383 297 470 minecraft:black_concrete
fill 383 296 472 383 297 472 minecraft:black_concrete
fill 383 296 474 383 297 474 minecraft:black_concrete
fill 383 296 476 383 297 476 minecraft:black_concrete
fill 384 296 471 384 297 471 minecraft:black_concrete
fill 384 296 473 384 297 473 minecraft:black_concrete
fill 384 296 475 384 297 475 minecraft:black_concrete
fill 385 296 470 385 297 470 minecraft:black_concrete
fill 385 296 472 385 297 472 minecraft:black_concrete
fill 385 296 474 385 297 474 minecraft:black_concrete
fill 385 296 476 385 297 476 minecraft:black_concrete
fill 391 296 498 391 297 498 minecraft:black_concrete
fill 391 296 500 391 297 500 minecraft:black_concrete
fill 391 296 502 391 297 502 minecraft:black_concrete
fill 391 296 504 391 297 504 minecraft:black_concrete
fill 392 296 499 392 297 499 minecraft:black_concrete
fill 392 296 501 392 297 501 minecraft:black_concrete
fill 392 296 503 392 297 503 minecraft:black_concrete
fill 393 296 498 393 297 498 minecraft:black_concrete
fill 393 296 500 393 297 500 minecraft:black_concrete
fill 393 296 502 393 297 502 minecraft:black_concrete
fill 393 296 504 393 297 504 minecraft:black_concrete
fill 394 296 499 394 297 499 minecraft:black_concrete
fill 394 296 501 394 297 501 minecraft:black_concrete
fill 394 296 503 394 297 503 minecraft:black_concrete
fill 395 296 498 395 297 498 minecraft:black_concrete
fill 395 296 500 395 297 500 minecraft:black_concrete
fill 395 296 502 395 297 502 minecraft:black_concrete
fill 395 296 504 395 297 504 minecraft:black_concrete
fill 396 296 499 396 297 499 minecraft:black_concrete
fill 396 296 501 396 297 501 minecraft:black_concrete
fill 396 296 503 396 297 503 minecraft:black_concrete
fill 397 296 498 397 297 498 minecraft:black_concrete
fill 397 296 500 397 297 500 minecraft:black_concrete
fill 397 296 502 397 297 502 minecraft:black_concrete
fill 397 296 504 397 297 504 minecraft:black_concrete
fill 398 296 499 398 297 499 minecraft:black_concrete
fill 398 296 501 398 297 501 minecraft:black_concrete
fill 398 296 503 398 297 503 minecraft:black_concrete
fill 399 296 498 399 297 498 minecraft:black_concrete
fill 399 296 500 399 297 500 minecraft:black_concrete
fill 399 296 502 399 297 502 minecraft:black_concrete
fill 399 296 504 399 297 504 minecraft:black_concrete
fill 376 298 468 376 300 468 minecraft:sea_lantern
fill 376 298 476 377 298 476 minecraft:sea_lantern
fill 376 298 484 376 300 484 minecraft:sea_lantern
fill 376 298 492 376 300 492 minecraft:sea_lantern
fill 376 298 500 376 300 500 minecraft:sea_lantern
setblock 377 298 470 minecraft:sea_lantern
setblock 377 298 472 minecraft:sea_lantern
setblock 377 298 474 minecraft:sea_lantern
setblock 378 298 471 minecraft:sea_lantern
setblock 378 298 473 minecraft:sea_lantern
setblock 378 298 475 minecraft:sea_lantern
setblock 379 298 466 minecraft:light[level=14]
setblock 379 298 470 minecraft:sea_lantern
setblock 379 298 472 minecraft:sea_lantern
setblock 379 298 474 minecraft:sea_lantern
setblock 379 298 476 minecraft:sea_lantern
setblock 379 298 482 minecraft:light[level=14]
setblock 379 298 490 minecraft:light[level=14]
setblock 379 298 498 minecraft:light[level=14]
fill 379 298 505 379 300 505 minecraft:sea_lantern
setblock 380 298 471 minecraft:sea_lantern
setblock 380 298 473 minecraft:sea_lantern
setblock 380 298 475 minecraft:sea_lantern
setblock 381 298 470 minecraft:sea_lantern
setblock 381 298 472 minecraft:sea_lantern
setblock 381 298 474 minecraft:sea_lantern
setblock 381 298 476 minecraft:sea_lantern
setblock 382 298 471 minecraft:sea_lantern
setblock 382 298 473 minecraft:sea_lantern
setblock 382 298 475 minecraft:sea_lantern
fill 383 298 463 383 300 463 minecraft:sea_lantern
setblock 383 298 470 minecraft:sea_lantern
setblock 383 298 472 minecraft:sea_lantern
setblock 383 298 474 minecraft:sea_lantern
setblock 383 298 476 minecraft:sea_lantern
setblock 384 298 471 minecraft:sea_lantern
setblock 384 298 473 minecraft:sea_lantern
setblock 384 298 475 minecraft:sea_lantern
setblock 385 298 470 minecraft:sea_lantern
setblock 385 298 472 minecraft:sea_lantern
setblock 385 298 474 minecraft:sea_lantern
setblock 385 298 476 minecraft:sea_lantern
setblock 387 298 466 minecraft:light[level=14]
setblock 387 298 474 minecraft:light[level=14]
setblock 387 298 482 minecraft:light[level=14]
setblock 387 298 490 minecraft:light[level=14]
setblock 387 298 498 minecraft:light[level=14]
fill 387 298 505 387 300 505 minecraft:sea_lantern
fill 391 298 463 391 300 463 minecraft:sea_lantern
setblock 391 298 498 minecraft:sea_lantern
setblock 391 298 500 minecraft:sea_lantern
setblock 391 298 502 minecraft:sea_lantern
setblock 391 298 504 minecraft:sea_lantern
setblock 392 298 499 minecraft:sea_lantern
setblock 392 298 501 minecraft:sea_lantern
setblock 392 298 503 minecraft:sea_lantern
setblock 393 298 498 minecraft:sea_lantern
setblock 393 298 500 minecraft:sea_lantern
setblock 393 298 502 minecraft:sea_lantern
setblock 393 298 504 minecraft:sea_lantern
setblock 394 298 499 minecraft:sea_lantern
setblock 394 298 501 minecraft:sea_lantern
setblock 394 298 503 minecraft:sea_lantern
setblock 395 298 466 minecraft:light[level=14]
setblock 395 298 474 minecraft:light[level=14]
setblock 395 298 482 minecraft:light[level=14]
setblock 395 298 490 minecraft:light[level=14]
setblock 395 298 498 minecraft:sea_lantern
setblock 395 298 500 minecraft:sea_lantern
setblock 395 298 502 minecraft:sea_lantern
fill 395 298 504 395 298 505 minecraft:sea_lantern
setblock 396 298 499 minecraft:sea_lantern
setblock 396 298 501 minecraft:sea_lantern
setblock 396 298 503 minecraft:sea_lantern
setblock 397 298 498 minecraft:sea_lantern
setblock 397 298 500 minecraft:sea_lantern
setblock 397 298 502 minecraft:sea_lantern
setblock 397 298 504 minecraft:sea_lantern
setblock 398 298 499 minecraft:sea_lantern
setblock 398 298 501 minecraft:sea_lantern
setblock 398 298 503 minecraft:sea_lantern
fill 399 298 463 399 300 463 minecraft:sea_lantern
setblock 399 298 498 minecraft:sea_lantern
setblock 399 298 500 minecraft:sea_lantern
setblock 399 298 502 minecraft:sea_lantern
setblock 399 298 504 minecraft:sea_lantern
setblock 403 298 466 minecraft:light[level=14]
setblock 403 298 474 minecraft:light[level=14]
setblock 403 298 482 minecraft:light[level=14]
setblock 403 298 490 minecraft:light[level=14]
setblock 403 298 498 minecraft:light[level=14]
fill 403 298 505 403 300 505 minecraft:sea_lantern
fill 407 298 463 407 300 463 minecraft:sea_lantern
setblock 411 298 466 minecraft:light[level=14]
setblock 411 298 474 minecraft:light[level=14]
setblock 411 298 482 minecraft:light[level=14]
setblock 411 298 490 minecraft:light[level=14]
setblock 411 298 498 minecraft:light[level=14]
fill 411 298 505 411 300 505 minecraft:sea_lantern
fill 415 298 463 415 300 463 minecraft:sea_lantern
fill 418 298 468 418 300 468 minecraft:sea_lantern
fill 418 298 476 418 300 476 minecraft:sea_lantern
fill 418 298 484 418 300 484 minecraft:sea_lantern
fill 418 298 492 418 300 492 minecraft:sea_lantern
fill 418 298 500 418 300 500 minecraft:sea_lantern
fill 376 299 476 376 300 476 minecraft:sea_lantern
fill 377 299 470 377 300 470 minecraft:black_concrete
fill 377 299 472 377 300 472 minecraft:black_concrete
fill 377 299 474 377 300 474 minecraft:black_concrete
fill 377 299 476 377 300 476 minecraft:black_concrete
fill 378 299 471 378 300 471 minecraft:black_concrete
fill 378 299 473 378 300 473 minecraft:black_concrete
fill 378 299 475 378 300 475 minecraft:black_concrete
fill 379 299 470 379 300 470 minecraft:black_concrete
fill 379 299 472 379 300 472 minecraft:black_concrete
fill 379 299 474 379 300 474 minecraft:black_concrete
fill 379 299 476 379 300 476 minecraft:black_concrete
fill 380 299 471 380 300 471 minecraft:black_concrete
fill 380 299 473 380 300 473 minecraft:black_concrete
fill 380 299 475 380 300 475 minecraft:black_concrete
fill 381 299 470 381 300 470 minecraft:black_concrete
fill 381 299 472 381 300 472 minecraft:black_concrete
fill 381 299 474 381 300 474 minecraft:black_concrete
fill 381 299 476 381 300 476 minecraft:black_concrete
fill 382 299 471 382 300 471 minecraft:black_concrete
fill 382 299 473 382 300 473 minecraft:black_concrete
fill 382 299 475 382 300 475 minecraft:black_concrete
fill 383 299 470 383 300 470 minecraft:black_concrete
fill 383 299 472 383 300 472 minecraft:black_concrete
fill 383 299 474 383 300 474 minecraft:black_concrete
fill 383 299 476 383 300 476 minecraft:black_concrete
fill 384 299 471 384 300 471 minecraft:black_concrete
fill 384 299 473 384 300 473 minecraft:black_concrete
fill 384 299 475 384 300 475 minecraft:black_concrete
fill 385 299 470 385 300 470 minecraft:black_concrete
fill 385 299 472 385 300 472 minecraft:black_concrete
fill 385 299 474 385 300 474 minecraft:black_concrete
fill 385 299 476 385 300 476 minecraft:black_concrete
fill 391 299 498 391 300 498 minecraft:black_concrete
fill 391 299 500 391 300 500 minecraft:black_concrete
fill 391 299 502 391 300 502 minecraft:black_concrete
fill 391 299 504 391 300 504 minecraft:black_concrete
fill 392 299 499 392 300 499 minecraft:black_concrete
fill 392 299 501 392 300 501 minecraft:black_concrete
fill 392 299 503 392 300 503 minecraft:black_concrete
fill 393 299 498 393 300 498 minecraft:black_concrete
fill 393 299 500 393 300 500 minecraft:black_concrete
fill 393 299 502 393 300 502 minecraft:black_concrete
fill 393 299 504 393 300 504 minecraft:black_concrete
fill 394 299 499 394 300 499 minecraft:black_concrete
fill 394 299 501 394 300 501 minecraft:black_concrete
fill 394 299 503 394 300 503 minecraft:black_concrete
fill 395 299 498 395 300 498 minecraft:black_concrete
fill 395 299 500 395 300 500 minecraft:black_concrete
fill 395 299 502 395 300 502 minecraft:black_concrete
fill 395 299 504 395 300 504 minecraft:black_concrete
fill 395 299 505 395 300 505 minecraft:sea_lantern
fill 396 299 499 396 300 499 minecraft:black_concrete
fill 396 299 501 396 300 501 minecraft:black_concrete
fill 396 299 503 396 300 503 minecraft:black_concrete
fill 397 299 498 397 300 498 minecraft:black_concrete
fill 397 299 500 397 300 500 minecraft:black_concrete
fill 397 299 502 397 300 502 minecraft:black_concrete
fill 397 299 504 397 300 504 minecraft:black_concrete
fill 398 299 499 398 300 499 minecraft:black_concrete
fill 398 299 501 398 300 501 minecraft:black_concrete
fill 398 299 503 398 300 503 minecraft:black_concrete
fill 399 299 498 399 300 498 minecraft:black_concrete
fill 399 299 500 399 300 500 minecraft:black_concrete
fill 399 299 502 399 300 502 minecraft:black_concrete
fill 399 299 504 399 300 504 minecraft:black_concrete
fill 376 301 468 376 307 468 minecraft:magenta_concrete
fill 376 301 476 376 307 476 minecraft:magenta_concrete
fill 376 301 484 376 307 484 minecraft:magenta_concrete
fill 376 301 492 376 307 492 minecraft:magenta_concrete
fill 376 301 500 376 307 500 minecraft:magenta_concrete
fill 379 301 505 379 307 505 minecraft:magenta_concrete
fill 383 301 463 383 307 463 minecraft:magenta_concrete
fill 387 301 505 387 307 505 minecraft:magenta_concrete
fill 391 301 463 391 307 463 minecraft:magenta_concrete
fill 395 301 505 395 307 505 minecraft:magenta_concrete
fill 399 301 463 399 307 463 minecraft:magenta_concrete
fill 403 301 505 403 307 505 minecraft:magenta_concrete
fill 407 301 463 407 307 463 minecraft:magenta_concrete
fill 411 301 505 411 307 505 minecraft:magenta_concrete
fill 415 301 463 415 307 463 minecraft:magenta_concrete
fill 418 301 468 418 307 468 minecraft:magenta_concrete
fill 418 301 476 418 307 476 minecraft:magenta_concrete
fill 418 301 484 418 307 484 minecraft:magenta_concrete
fill 418 301 492 418 307 492 minecraft:magenta_concrete
fill 418 301 500 418 307 500 minecraft:magenta_concrete
