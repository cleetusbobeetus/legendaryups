fill 41 213 323 41 213 326 minecraft:honeycomb_block
setblock 41 213 327 minecraft:yellow_terracotta
fill 41 213 328 41 216 328 minecraft:honeycomb_block
setblock 41 213 331 minecraft:honeycomb_block
setblock 41 213 332 minecraft:yellow_terracotta
fill 41 213 333 41 216 333 minecraft:honeycomb_block
setblock 41 213 337 minecraft:yellow_terracotta
fill 41 213 338 41 213 341 minecraft:honeycomb_block
setblock 41 213 342 minecraft:yellow_terracotta
fill 41 213 343 41 213 346 minecraft:honeycomb_block
setblock 41 213 347 minecraft:yellow_terracotta
fill 41 213 348 41 213 351 minecraft:honeycomb_block
setblock 41 213 352 minecraft:yellow_terracotta
fill 41 213 353 41 216 353 minecraft:honeycomb_block
setblock 41 213 356 minecraft:honeycomb_block
setblock 41 213 357 minecraft:yellow_terracotta
fill 41 213 358 41 216 358 minecraft:honeycomb_block
setblock 41 213 362 minecraft:yellow_terracotta
fill 41 213 363 41 216 363 minecraft:honeycomb_block
fill 0 214 332 2 216 332 minecraft:honeycomb_block
fill 0 214 336 0 230 336 minecraft:honeycomb_block
fill 1 214 323 1 214 325 minecraft:honeycomb_block
setblock 1 214 326 minecraft:yellow_terracotta
fill 1 214 327 1 214 330 minecraft:honeycomb_block
setblock 1 214 331 minecraft:yellow_terracotta
fill 1 214 333 1 214 335 minecraft:honeycomb_block
setblock 1 214 336 minecraft:yellow_terracotta
fill 1 214 337 1 214 340 minecraft:honeycomb_block
setblock 1 214 341 minecraft:yellow_terracotta
fill 1 214 342 1 214 345 minecraft:honeycomb_block
setblock 1 214 346 minecraft:yellow_terracotta
fill 1 214 347 1 214 350 minecraft:honeycomb_block
setblock 1 214 351 minecraft:yellow_terracotta
fill 1 214 352 1 214 355 minecraft:honeycomb_block
setblock 1 214 356 minecraft:yellow_terracotta
fill 1 214 357 1 214 360 minecraft:honeycomb_block
setblock 1 214 361 minecraft:yellow_terracotta
fill 1 214 362 3 214 363 minecraft:honeycomb_block
fill 2 214 323 2 214 324 minecraft:honeycomb_block
setblock 2 214 325 minecraft:yellow_terracotta
fill 2 214 326 2 214 329 minecraft:honeycomb_block
setblock 2 214 330 minecraft:yellow_terracotta
fill 2 214 331 2 216 331 minecraft:honeycomb_block
fill 2 214 333 2 214 334 minecraft:honeycomb_block
setblock 2 214 335 minecraft:yellow_terracotta
fill 2 214 336 2 216 336 minecraft:honeycomb_block
fill 2 214 347 2 214 349 minecraft:honeycomb_block
setblock 2 214 350 minecraft:yellow_terracotta
fill 2 214 351 2 214 354 minecraft:honeycomb_block
setblock 2 214 355 minecraft:yellow_terracotta
fill 2 214 356 2 214 359 minecraft:honeycomb_block
setblock 2 214 360 minecraft:yellow_terracotta
fill 2 214 361 2 217 361 minecraft:honeycomb_block
setblock 2 214 364 minecraft:yellow_terracotta
setblock 3 214 323 minecraft:honeycomb_block
setblock 3 214 349 minecraft:yellow_terracotta
fill 3 214 350 3 214 353 minecraft:honeycomb_block
setblock 3 214 354 minecraft:yellow_terracotta
fill 3 214 355 3 214 358 minecraft:honeycomb_block
setblock 3 214 359 minecraft:yellow_terracotta
fill 3 214 360 3 217 360 minecraft:honeycomb_block
setblock 4 214 323 minecraft:yellow_terracotta
setblock 4 214 352 minecraft:honeycomb_block
setblock 4 214 353 minecraft:yellow_terracotta
fill 4 214 354 4 214 357 minecraft:honeycomb_block
setblock 4 214 358 minecraft:yellow_terracotta
setblock 4 214 362 minecraft:honeycomb_block
setblock 4 214 363 minecraft:yellow_terracotta
setblock 5 214 362 minecraft:yellow_terracotta
fill 5 214 363 7 214 363 minecraft:honeycomb_block
setblock 6 214 362 minecraft:honeycomb_block
setblock 14 214 363 minecraft:honey_block
fill 20 214 323 23 214 323 minecraft:honeycomb_block
fill 20 214 363 21 214 363 minecraft:honeycomb_block
setblock 24 214 323 minecraft:yellow_terracotta
setblock 25 214 323 minecraft:honeycomb_block
fill 28 214 322 28 232 322 minecraft:honeycomb_block
setblock 28 214 323 minecraft:honey_block
fill 28 214 330 28 217 330 minecraft:brown_terracotta
fill 28 214 334 28 217 334 minecraft:brown_terracotta
fill 29 214 329 29 217 329 minecraft:brown_terracotta
fill 30 214 336 32 217 336 minecraft:brown_terracotta
fill 33 214 329 33 217 329 minecraft:brown_terracotta
setblock 33 214 363 minecraft:honey_block
setblock 34 214 323 minecraft:yellow_terracotta
fill 34 214 330 34 217 330 minecraft:brown_terracotta
fill 35 214 323 38 214 323 minecraft:honeycomb_block
fill 35 214 332 35 217 333 minecraft:brown_terracotta
setblock 37 214 324 minecraft:honeycomb_block
fill 37 214 344 38 221 344 minecraft:brown_terracotta
fill 37 214 346 38 221 346 minecraft:brown_terracotta
fill 37 214 363 38 214 363 minecraft:honeycomb_block
setblock 38 214 324 minecraft:yellow_terracotta
fill 38 214 330 38 214 332 minecraft:honeycomb_block
setblock 39 214 323 minecraft:yellow_terracotta
fill 39 214 324 39 214 327 minecraft:honeycomb_block
setblock 39 214 328 minecraft:yellow_terracotta
fill 39 214 329 39 216 329 minecraft:honeycomb_block
fill 39 214 331 39 214 332 minecraft:honeycomb_block
setblock 39 214 333 minecraft:yellow_terracotta
fill 39 214 334 39 215 336 minecraft:honeycomb_block
fill 39 214 354 39 215 354 minecraft:honeycomb_block
fill 39 214 356 39 214 357 minecraft:honeycomb_block
setblock 39 214 362 minecraft:honeycomb_block
setblock 39 214 363 minecraft:yellow_terracotta
setblock 40 214 322 minecraft:yellow_terracotta
fill 40 214 323 40 214 326 minecraft:honeycomb_block
setblock 40 214 327 minecraft:yellow_terracotta
fill 40 214 328 40 217 328 minecraft:honeycomb_block
setblock 40 214 331 minecraft:honeycomb_block
setblock 40 214 332 minecraft:yellow_terracotta
fill 40 214 333 40 217 333 minecraft:honeycomb_block
fill 40 214 335 40 214 336 minecraft:honeycomb_block
setblock 40 214 337 minecraft:yellow_terracotta
fill 40 214 338 41 216 338 minecraft:honeycomb_block
fill 40 214 350 40 214 351 minecraft:honeycomb_block
setblock 40 214 352 minecraft:yellow_terracotta
fill 40 214 353 40 217 353 minecraft:honeycomb_block
setblock 40 214 356 minecraft:honeycomb_block
setblock 40 214 357 minecraft:yellow_terracotta
fill 40 214 358 40 214 361 minecraft:honeycomb_block
setblock 40 214 362 minecraft:yellow_terracotta
fill 40 214 363 40 217 363 minecraft:honeycomb_block
fill 41 214 323 41 214 325 minecraft:honeycomb_block
setblock 41 214 326 minecraft:yellow_terracotta
fill 41 214 327 41 217 327 minecraft:honeycomb_block
setblock 41 214 331 minecraft:yellow_terracotta
fill 41 214 332 41 217 332 minecraft:honeycomb_block
setblock 41 214 335 minecraft:honeycomb_block
setblock 41 214 336 minecraft:yellow_terracotta
fill 41 214 337 41 217 337 minecraft:honeycomb_block
fill 41 214 339 41 214 340 minecraft:honeycomb_block
setblock 41 214 341 minecraft:yellow_terracotta
setblock 41 214 346 minecraft:yellow_terracotta
fill 41 214 347 41 214 350 minecraft:honeycomb_block
setblock 41 214 351 minecraft:yellow_terracotta
fill 41 214 352 41 217 352 minecraft:honeycomb_block
setblock 41 214 356 minecraft:yellow_terracotta
fill 41 214 357 41 217 357 minecraft:honeycomb_block
fill 41 214 359 41 214 360 minecraft:honeycomb_block
setblock 41 214 361 minecraft:yellow_terracotta
fill 41 214 362 41 217 362 minecraft:honeycomb_block
setblock 42 214 332 minecraft:orange_terracotta
fill 1 215 323 1 215 324 minecraft:honeycomb_block
setblock 1 215 325 minecraft:yellow_terracotta
fill 1 215 326 1 215 329 minecraft:honeycomb_block
setblock 1 215 330 minecraft:yellow_terracotta
fill 1 215 331 1 218 331 minecraft:honeycomb_block
fill 1 215 333 1 215 334 minecraft:honeycomb_block
setblock 1 215 335 minecraft:yellow_terracotta
fill 1 215 336 1 215 339 minecraft:honeycomb_block
setblock 1 215 340 minecraft:yellow_terracotta
fill 1 215 341 1 215 344 minecraft:honeycomb_block
setblock 1 215 345 minecraft:yellow_terracotta
fill 1 215 346 1 215 349 minecraft:honeycomb_block
setblock 1 215 350 minecraft:yellow_terracotta
fill 1 215 351 1 215 354 minecraft:honeycomb_block
setblock 1 215 355 minecraft:yellow_terracotta
fill 1 215 356 1 215 359 minecraft:honeycomb_block
setblock 1 215 360 minecraft:yellow_terracotta
fill 1 215 361 1 216 363 minecraft:honeycomb_block
setblock 2 215 323 minecraft:honeycomb_block
setblock 2 215 328 minecraft:honeycomb_block
setblock 2 215 329 minecraft:yellow_terracotta
setblock 2 215 330 minecraft:honeycomb_block
setblock 2 215 333 minecraft:honeycomb_block
setblock 2 215 334 minecraft:yellow_terracotta
fill 2 215 335 2 217 335 minecraft:honeycomb_block
setblock 2 215 348 minecraft:honeycomb_block
setblock 2 215 349 minecraft:yellow_terracotta
fill 2 215 350 2 215 353 minecraft:honeycomb_block
setblock 2 215 354 minecraft:yellow_terracotta
fill 2 215 355 2 215 358 minecraft:honeycomb_block
setblock 2 215 359 minecraft:yellow_terracotta
fill 2 215 360 2 218 360 minecraft:honeycomb_block
fill 2 215 362 2 215 364 minecraft:honeycomb_block
setblock 3 215 323 minecraft:yellow_terracotta
fill 3 215 350 3 215 352 minecraft:honeycomb_block
setblock 3 215 353 minecraft:yellow_terracotta
fill 3 215 354 3 215 357 minecraft:honeycomb_block
setblock 3 215 358 minecraft:yellow_terracotta
fill 3 215 359 3 218 359 minecraft:honeycomb_block
fill 3 215 361 3 215 362 minecraft:honeycomb_block
setblock 3 215 363 minecraft:yellow_terracotta
fill 4 215 353 4 215 356 minecraft:honeycomb_block
setblock 4 215 357 minecraft:yellow_terracotta
setblock 4 215 362 minecraft:yellow_terracotta
fill 4 215 363 6 216 363 minecraft:honeycomb_block
setblock 5 215 362 minecraft:honeycomb_block
setblock 20 215 363 minecraft:honey_block
fill 21 215 323 22 215 323 minecraft:honeycomb_block
setblock 23 215 323 minecraft:yellow_terracotta
fill 23 215 357 24 216 357 minecraft:yellow_concrete
fill 24 215 341 24 216 345 minecraft:white_concrete
fill 27 215 331 27 217 333 minecraft:brown_terracotta
fill 28 215 335 28 217 335 minecraft:brown_terracotta
fill 29 215 336 29 217 336 minecraft:brown_terracotta
fill 30 215 328 32 217 328 minecraft:brown_terracotta
fill 33 215 336 33 217 336 minecraft:brown_terracotta
fill 34 215 329 34 217 329 minecraft:brown_terracotta
fill 34 215 335 34 217 335 minecraft:brown_terracotta
fill 35 215 323 37 215 323 minecraft:honeycomb_block
fill 35 215 331 35 217 331 minecraft:brown_terracotta
fill 35 215 334 35 217 334 minecraft:brown_terracotta
fill 36 215 345 36 221 345 minecraft:brown_terracotta
fill 36 215 363 37 215 363 minecraft:honeycomb_block
setblock 37 215 324 minecraft:yellow_terracotta
setblock 38 215 323 minecraft:yellow_terracotta
fill 38 215 324 41 215 324 minecraft:honeycomb_block
setblock 38 215 362 minecraft:honeycomb_block
setblock 38 215 363 minecraft:yellow_terracotta
fill 39 215 323 41 216 323 minecraft:honeycomb_block
setblock 39 215 326 minecraft:honeycomb_block
setblock 39 215 327 minecraft:yellow_terracotta
fill 39 215 328 39 216 328 minecraft:honeycomb_block
fill 39 215 330 39 215 331 minecraft:honeycomb_block
setblock 39 215 332 minecraft:yellow_terracotta
fill 39 215 333 39 218 333 minecraft:honeycomb_block
fill 39 215 345 39 221 345 minecraft:brown_terracotta
fill 39 215 355 39 215 356 minecraft:honeycomb_block
setblock 39 215 357 minecraft:yellow_terracotta
fill 39 215 358 40 216 359 minecraft:honeycomb_block
setblock 39 215 362 minecraft:yellow_terracotta
fill 39 215 363 39 218 363 minecraft:honeycomb_block
fill 40 215 322 40 270 322 minecraft:honeycomb_block
setblock 40 215 325 minecraft:honeycomb_block
setblock 40 215 326 minecraft:yellow_terracotta
fill 40 215 327 40 217 327 minecraft:honeycomb_block
setblock 40 215 330 minecraft:honeycomb_block
setblock 40 215 331 minecraft:yellow_terracotta
fill 40 215 332 40 218 332 minecraft:honeycomb_block
setblock 40 215 335 minecraft:honeycomb_block
setblock 40 215 336 minecraft:yellow_terracotta
fill 40 215 337 40 218 337 minecraft:honeycomb_block
setblock 40 215 350 minecraft:honeycomb_block
setblock 40 215 351 minecraft:yellow_terracotta
fill 40 215 352 40 217 352 minecraft:honeycomb_block
setblock 40 215 355 minecraft:honeycomb_block
setblock 40 215 356 minecraft:yellow_terracotta
fill 40 215 357 40 218 357 minecraft:honeycomb_block
setblock 40 215 360 minecraft:honeycomb_block
setblock 40 215 361 minecraft:yellow_terracotta
fill 40 215 362 40 218 362 minecraft:honeycomb_block
setblock 41 215 325 minecraft:yellow_terracotta
fill 41 215 326 41 218 326 minecraft:honeycomb_block
setblock 41 215 330 minecraft:yellow_terracotta
fill 41 215 331 41 218 331 minecraft:honeycomb_block
setblock 41 215 335 minecraft:yellow_terracotta
fill 41 215 336 41 218 336 minecraft:honeycomb_block
setblock 41 215 339 minecraft:honeycomb_block
setblock 41 215 340 minecraft:yellow_terracotta
fill 41 215 341 41 216 341 minecraft:honeycomb_block
fill 41 215 347 41 215 349 minecraft:honeycomb_block
setblock 41 215 350 minecraft:yellow_terracotta
fill 41 215 351 41 218 351 minecraft:honeycomb_block
setblock 41 215 355 minecraft:yellow_terracotta
fill 41 215 356 41 218 356 minecraft:honeycomb_block
setblock 41 215 359 minecraft:honeycomb_block
setblock 41 215 360 minecraft:yellow_terracotta
fill 41 215 361 41 218 361 minecraft:honeycomb_block
fill 42 215 332 42 278 332 minecraft:honeycomb_block
setblock 42 215 352 minecraft:yellow_concrete
setblock 0 216 328 minecraft:orange_terracotta
setblock 1 216 323 minecraft:honeycomb_block
setblock 1 216 324 minecraft:yellow_terracotta
fill 1 216 325 1 216 328 minecraft:honeycomb_block
setblock 1 216 329 minecraft:yellow_terracotta
fill 1 216 330 1 218 330 minecraft:honeycomb_block
setblock 1 216 333 minecraft:honeycomb_block
setblock 1 216 334 minecraft:yellow_terracotta
fill 1 216 335 1 216 338 minecraft:honeycomb_block
setblock 1 216 339 minecraft:yellow_terracotta
fill 1 216 340 1 218 341 minecraft:honeycomb_block
setblock 1 216 344 minecraft:honey_block
fill 1 216 345 1 216 348 minecraft:honeycomb_block
setblock 1 216 349 minecraft:yellow_terracotta
fill 1 216 350 1 216 353 minecraft:honeycomb_block
setblock 1 216 354 minecraft:yellow_terracotta
fill 1 216 355 1 216 358 minecraft:honeycomb_block
setblock 1 216 359 minecraft:yellow_terracotta
fill 1 216 360 1 219 360 minecraft:honeycomb_block
setblock 2 216 323 minecraft:yellow_terracotta
setblock 2 216 333 minecraft:yellow_terracotta
fill 2 216 334 2 217 334 minecraft:honeycomb_block
fill 2 216 349 2 216 352 minecraft:honeycomb_block
setblock 2 216 353 minecraft:yellow_terracotta
fill 2 216 354 2 216 357 minecraft:honeycomb_block
setblock 2 216 358 minecraft:yellow_terracotta
fill 2 216 359 2 219 359 minecraft:honeycomb_block
setblock 2 216 362 minecraft:honeycomb_block
setblock 2 216 363 minecraft:yellow_terracotta
fill 2 216 364 2 262 364 minecraft:honeycomb_block
setblock 3 216 325 minecraft:light[level=15]
setblock 3 216 333 minecraft:light[level=15]
setblock 3 216 341 minecraft:light[level=15]
setblock 3 216 349 minecraft:light[level=15]
setblock 3 216 351 minecraft:honeycomb_block
setblock 3 216 352 minecraft:yellow_terracotta
fill 3 216 353 3 216 356 minecraft:honeycomb_block
setblock 3 216 357 minecraft:yellow_terracotta
fill 3 216 358 3 219 358 minecraft:honeycomb_block
setblock 3 216 361 minecraft:honeycomb_block
setblock 3 216 362 minecraft:yellow_terracotta
fill 3 216 363 3 219 363 minecraft:honeycomb_block
fill 4 216 362 4 217 362 minecraft:honeycomb_block
fill 7 216 363 7 217 363 minecraft:honey_block
fill 10 216 339 10 217 339 minecraft:honey_block
setblock 11 216 325 minecraft:light[level=15]
setblock 11 216 333 minecraft:light[level=15]
setblock 11 216 341 minecraft:light[level=15]
setblock 11 216 349 minecraft:light[level=15]
setblock 11 216 357 minecraft:light[level=15]
fill 13 216 336 17 224 337 minecraft:yellow_terracotta
fill 14 216 335 16 271 335 minecraft:yellow_terracotta
fill 14 216 338 16 267 338 minecraft:yellow_terracotta
setblock 16 216 323 minecraft:honey_block
setblock 19 216 325 minecraft:light[level=15]
setblock 19 216 333 minecraft:light[level=15]
setblock 19 216 341 minecraft:light[level=15]
setblock 19 216 349 minecraft:light[level=15]
setblock 19 216 357 minecraft:light[level=15]
setblock 26 216 363 minecraft:honey_block
setblock 27 216 325 minecraft:light[level=15]
fill 27 216 330 27 217 330 minecraft:brown_terracotta
fill 27 216 334 27 217 335 minecraft:brown_terracotta
setblock 27 216 341 minecraft:light[level=15]
setblock 27 216 349 minecraft:light[level=15]
setblock 27 216 357 minecraft:light[level=15]
fill 28 216 329 28 217 329 minecraft:brown_terracotta
fill 28 216 336 28 217 336 minecraft:brown_terracotta
fill 29 216 328 29 217 328 minecraft:brown_terracotta
fill 30 216 337 32 217 337 minecraft:brown_terracotta
fill 33 216 328 33 217 328 minecraft:brown_terracotta
fill 34 216 336 34 217 336 minecraft:brown_terracotta
fill 35 216 323 36 216 323 minecraft:honeycomb_block
setblock 35 216 325 minecraft:light[level=15]
fill 35 216 330 35 217 330 minecraft:brown_terracotta
fill 35 216 335 35 217 335 minecraft:brown_terracotta
setblock 35 216 341 minecraft:light[level=15]
setblock 35 216 349 minecraft:light[level=15]
setblock 35 216 357 minecraft:light[level=15]
fill 36 216 332 36 217 333 minecraft:brown_terracotta
fill 36 216 344 36 221 344 minecraft:brown_terracotta
fill 36 216 346 36 221 346 minecraft:brown_terracotta
setblock 36 216 363 minecraft:honeycomb_block
setblock 37 216 323 minecraft:yellow_terracotta
fill 37 216 324 40 216 324 minecraft:honeycomb_block
fill 37 216 343 38 221 343 minecraft:brown_terracotta
fill 37 216 347 38 221 347 minecraft:brown_terracotta
setblock 37 216 363 minecraft:yellow_terracotta
fill 38 216 323 38 219 323 minecraft:honeycomb_block
setblock 38 216 362 minecraft:yellow_terracotta
fill 38 216 363 38 219 363 minecraft:honeycomb_block
setblock 39 216 330 minecraft:honeycomb_block
setblock 39 216 331 minecraft:yellow_terracotta
fill 39 216 332 39 217 332 minecraft:honeycomb_block
fill 39 216 334 39 216 335 minecraft:honeycomb_block
setblock 39 216 336 minecraft:yellow_terracotta
fill 39 216 344 39 221 344 minecraft:brown_terracotta
fill 39 216 346 39 221 346 minecraft:brown_terracotta
setblock 39 216 355 minecraft:honeycomb_block
setblock 39 216 356 minecraft:yellow_terracotta
fill 39 216 357 39 219 357 minecraft:honeycomb_block
setblock 39 216 360 minecraft:honeycomb_block
fill 39 216 362 39 219 362 minecraft:honeycomb_block
setblock 40 216 325 minecraft:yellow_terracotta
fill 40 216 326 40 217 326 minecraft:honeycomb_block
setblock 40 216 329 minecraft:honeycomb_block
setblock 40 216 330 minecraft:yellow_terracotta
fill 40 216 331 40 219 331 minecraft:honeycomb_block
setblock 40 216 334 minecraft:honeycomb_block
setblock 40 216 335 minecraft:yellow_terracotta
fill 40 216 336 40 219 336 minecraft:honeycomb_block
setblock 40 216 351 minecraft:honeycomb_block
setblock 40 216 354 minecraft:honeycomb_block
setblock 40 216 355 minecraft:yellow_terracotta
fill 40 216 356 40 219 356 minecraft:honeycomb_block
setblock 40 216 360 minecraft:yellow_terracotta
fill 40 216 361 40 219 361 minecraft:honeycomb_block
setblock 41 216 324 minecraft:yellow_terracotta
fill 41 216 325 41 219 325 minecraft:honeycomb_block
setblock 41 216 329 minecraft:yellow_terracotta
fill 41 216 330 41 219 330 minecraft:honeycomb_block
setblock 41 216 334 minecraft:yellow_terracotta
fill 41 216 335 41 219 335 minecraft:honeycomb_block
setblock 41 216 339 minecraft:yellow_terracotta
fill 41 216 340 41 219 340 minecraft:honeycomb_block
setblock 41 216 342 minecraft:honey_block
setblock 41 216 348 minecraft:honeycomb_block
setblock 41 216 349 minecraft:yellow_terracotta
fill 41 216 350 41 217 350 minecraft:honeycomb_block
setblock 41 216 354 minecraft:yellow_terracotta
fill 41 216 355 41 219 355 minecraft:honeycomb_block
setblock 41 216 359 minecraft:yellow_terracotta
fill 41 216 360 41 219 360 minecraft:honeycomb_block
fill 42 216 352 42 233 352 minecraft:honeycomb_block
fill 0 217 323 1 217 323 minecraft:yellow_terracotta
fill 0 217 328 0 308 328 minecraft:honeycomb_block
fill 0 217 332 1 217 332 minecraft:honeycomb_block
setblock 0 217 359 minecraft:yellow_concrete
setblock 1 217 325 minecraft:honey_block
setblock 1 217 327 minecraft:honeycomb_block
setblock 1 217 328 minecraft:yellow_terracotta
setblock 1 217 329 minecraft:honeycomb_block
setblock 1 217 333 minecraft:yellow_terracotta
fill 1 217 334 1 217 337 minecraft:honeycomb_block
setblock 1 217 338 minecraft:yellow_terracotta
fill 1 217 339 1 220 339 minecraft:honeycomb_block
fill 1 217 346 1 217 347 minecraft:honeycomb_block
setblock 1 217 348 minecraft:yellow_terracotta
fill 1 217 349 1 217 352 minecraft:honeycomb_block
setblock 1 217 353 minecraft:yellow_terracotta
fill 1 217 354 1 217 357 minecraft:honeycomb_block
setblock 1 217 358 minecraft:yellow_terracotta
fill 1 217 359 1 220 359 minecraft:honeycomb_block
fill 1 217 361 1 217 362 minecraft:honeycomb_block
setblock 1 217 363 minecraft:yellow_terracotta
fill 2 217 350 2 217 351 minecraft:honeycomb_block
setblock 2 217 352 minecraft:yellow_terracotta
fill 2 217 353 2 217 356 minecraft:honeycomb_block
setblock 2 217 357 minecraft:yellow_terracotta
fill 2 217 358 2 220 358 minecraft:honeycomb_block
setblock 2 217 362 minecraft:yellow_terracotta
fill 2 217 363 2 220 363 minecraft:honeycomb_block
fill 3 217 353 3 217 355 minecraft:honeycomb_block
setblock 3 217 356 minecraft:yellow_terracotta
fill 3 217 357 3 220 357 minecraft:honeycomb_block
fill 3 217 362 3 220 362 minecraft:honeycomb_block
fill 4 217 363 5 217 363 minecraft:honeycomb_block
setblock 10 217 323 minecraft:honey_block
fill 12 217 337 12 218 337 minecraft:brown_terracotta
fill 13 217 335 13 218 335 minecraft:brown_terracotta
fill 13 217 338 13 218 338 minecraft:brown_terracotta
setblock 13 217 363 minecraft:honey_block
fill 14 217 334 16 218 334 minecraft:brown_terracotta
fill 14 217 339 16 218 339 minecraft:brown_terracotta
fill 17 217 335 17 218 335 minecraft:brown_terracotta
fill 17 217 338 17 218 338 minecraft:brown_terracotta
setblock 21 217 364 minecraft:yellow_concrete
fill 26 217 331 26 217 334 minecraft:brown_terracotta
setblock 27 217 329 minecraft:brown_terracotta
setblock 28 217 328 minecraft:brown_terracotta
setblock 29 217 323 minecraft:honey_block
setblock 29 217 337 minecraft:brown_terracotta
fill 30 217 327 32 217 327 minecraft:brown_terracotta
setblock 32 217 363 minecraft:honey_block
setblock 33 217 337 minecraft:brown_terracotta
setblock 33 217 364 minecraft:yellow_concrete
setblock 34 217 328 minecraft:brown_terracotta
setblock 35 217 323 minecraft:honeycomb_block
setblock 35 217 329 minecraft:brown_terracotta
setblock 35 217 336 minecraft:brown_terracotta
fill 35 217 345 35 221 345 minecraft:brown_terracotta
setblock 35 217 363 minecraft:honeycomb_block
setblock 36 217 323 minecraft:yellow_terracotta
fill 36 217 330 36 217 331 minecraft:brown_terracotta
setblock 36 217 334 minecraft:brown_terracotta
fill 36 217 343 36 221 343 minecraft:brown_terracotta
fill 36 217 347 36 221 347 minecraft:brown_terracotta
setblock 36 217 363 minecraft:yellow_terracotta
fill 37 217 323 37 220 323 minecraft:honeycomb_block
setblock 37 217 362 minecraft:yellow_terracotta
fill 37 217 363 37 220 363 minecraft:honeycomb_block
fill 38 217 324 39 217 324 minecraft:honeycomb_block
fill 38 217 362 38 220 362 minecraft:honeycomb_block
fill 39 217 323 40 217 323 minecraft:honeycomb_block
setblock 39 217 330 minecraft:yellow_terracotta
setblock 39 217 331 minecraft:honeycomb_block
setblock 39 217 334 minecraft:honeycomb_block
setblock 39 217 335 minecraft:yellow_terracotta
fill 39 217 343 39 221 343 minecraft:brown_terracotta
fill 39 217 347 39 221 347 minecraft:brown_terracotta
setblock 39 217 355 minecraft:yellow_terracotta
fill 39 217 356 39 220 356 minecraft:honeycomb_block
fill 39 217 358 39 217 359 minecraft:honeycomb_block
setblock 39 217 360 minecraft:yellow_terracotta
fill 39 217 361 39 220 361 minecraft:honeycomb_block
setblock 40 217 324 minecraft:yellow_terracotta
setblock 40 217 325 minecraft:honeycomb_block
setblock 40 217 329 minecraft:yellow_terracotta
fill 40 217 330 40 219 330 minecraft:honeycomb_block
setblock 40 217 334 minecraft:yellow_terracotta
fill 40 217 335 40 220 335 minecraft:honeycomb_block
setblock 40 217 338 minecraft:honeycomb_block
fill 40 217 344 40 221 346 minecraft:brown_terracotta
setblock 40 217 354 minecraft:yellow_terracotta
fill 40 217 355 40 220 355 minecraft:honeycomb_block
setblock 40 217 358 minecraft:honeycomb_block
setblock 40 217 359 minecraft:yellow_terracotta
fill 40 217 360 40 220 360 minecraft:honeycomb_block
setblock 41 217 323 minecraft:yellow_terracotta
fill 41 217 324 41 220 324 minecraft:honeycomb_block
setblock 41 217 328 minecraft:yellow_terracotta
fill 41 217 329 41 220 329 minecraft:honeycomb_block
setblock 41 217 333 minecraft:yellow_terracotta
fill 41 217 334 41 220 334 minecraft:honeycomb_block
setblock 41 217 338 minecraft:yellow_terracotta
fill 41 217 339 41 220 339 minecraft:honeycomb_block
setblock 41 217 353 minecraft:yellow_terracotta
fill 41 217 354 41 220 354 minecraft:honeycomb_block
setblock 41 217 358 minecraft:yellow_terracotta
fill 41 217 359 41 220 359 minecraft:honeycomb_block
setblock 41 217 363 minecraft:yellow_terracotta
setblock 42 217 325 minecraft:yellow_terracotta
setblock 42 217 338 minecraft:orange_terracotta
fill 0 218 323 0 308 323 minecraft:honeycomb_block
setblock 0 218 332 minecraft:yellow_concrete
fill 0 218 359 0 308 359 minecraft:honeycomb_block
setblock 1 218 332 minecraft:yellow_terracotta
fill 1 218 333 1 218 336 minecraft:honeycomb_block
setblock 1 218 337 minecraft:yellow_terracotta
fill 1 218 338 1 221 338 minecraft:honeycomb_block
setblock 1 218 347 minecraft:yellow_terracotta
fill 1 218 348 1 218 351 minecraft:honeycomb_block
setblock 1 218 352 minecraft:yellow_terracotta
fill 1 218 353 1 218 356 minecraft:honeycomb_block
setblock 1 218 357 minecraft:yellow_terracotta
fill 1 218 358 1 221 358 minecraft:honeycomb_block
setblock 1 218 361 minecraft:honeycomb_block
setblock 1 218 362 minecraft:yellow_terracotta
fill 1 218 363 1 221 363 minecraft:honeycomb_block
setblock 2 218 351 minecraft:yellow_terracotta
fill 2 218 352 2 218 355 minecraft:honeycomb_block
setblock 2 218 356 minecraft:yellow_terracotta
fill 2 218 357 2 221 357 minecraft:honeycomb_block
setblock 2 218 361 minecraft:yellow_terracotta
fill 2 218 362 2 221 362 minecraft:honeycomb_block
setblock 3 218 325 minecraft:light[level=12]
setblock 3 218 332 minecraft:light[level=12]
setblock 3 218 339 minecraft:light[level=12]
setblock 3 218 346 minecraft:light[level=12]
setblock 3 218 353 minecraft:light[level=12]
setblock 3 218 354 minecraft:honeycomb_block
setblock 3 218 355 minecraft:yellow_terracotta
fill 3 218 356 3 219 356 minecraft:honeycomb_block
setblock 3 218 360 minecraft:yellow_terracotta
setblock 4 218 323 minecraft:honey_block
setblock 4 218 363 minecraft:honeycomb_block
fill 5 218 355 5 227 355 minecraft:yellow_terracotta
setblock 5 218 363 minecraft:yellow_terracotta
setblock 10 218 325 minecraft:light[level=12]
setblock 10 218 332 minecraft:light[level=12]
setblock 10 218 339 minecraft:light[level=12]
setblock 10 218 346 minecraft:light[level=12]
setblock 10 218 353 minecraft:light[level=12]
setblock 10 218 360 minecraft:light[level=12]
fill 12 218 335 12 218 336 minecraft:brown_terracotta
fill 12 218 338 12 218 339 minecraft:brown_terracotta
setblock 13 218 334 minecraft:brown_terracotta
setblock 13 218 339 minecraft:brown_terracotta
setblock 14 218 322 minecraft:yellow_terracotta
fill 14 218 333 16 218 333 minecraft:brown_terracotta
fill 14 218 340 16 218 340 minecraft:brown_terracotta
setblock 17 218 325 minecraft:light[level=12]
setblock 17 218 332 minecraft:light[level=12]
setblock 17 218 334 minecraft:brown_terracotta
fill 17 218 339 18 218 339 minecraft:brown_terracotta
setblock 17 218 346 minecraft:light[level=12]
setblock 17 218 353 minecraft:light[level=12]
setblock 17 218 360 minecraft:light[level=12]
fill 18 218 335 18 218 338 minecraft:brown_terracotta
setblock 19 218 363 minecraft:honey_block
fill 21 218 364 21 308 364 minecraft:honeycomb_block
setblock 23 218 323 minecraft:honey_block
setblock 24 218 325 minecraft:light[level=12]
setblock 24 218 332 minecraft:light[level=12]
setblock 24 218 339 minecraft:light[level=12]
setblock 24 218 346 minecraft:light[level=12]
setblock 24 218 353 minecraft:light[level=12]
setblock 24 218 360 minecraft:light[level=12]
setblock 31 218 325 minecraft:light[level=12]
fill 31 218 332 31 221 332 minecraft:yellow_terracotta
setblock 31 218 339 minecraft:light[level=12]
setblock 31 218 346 minecraft:light[level=12]
setblock 31 218 353 minecraft:light[level=12]
setblock 31 218 360 minecraft:light[level=12]
fill 33 218 364 33 308 364 minecraft:honeycomb_block
setblock 34 218 323 minecraft:honeycomb_block
setblock 34 218 363 minecraft:honeycomb_block
setblock 35 218 323 minecraft:yellow_terracotta
fill 35 218 344 35 221 344 minecraft:brown_terracotta
fill 35 218 346 35 221 346 minecraft:brown_terracotta
setblock 35 218 363 minecraft:yellow_terracotta
fill 36 218 323 36 221 323 minecraft:honeycomb_block
setblock 36 218 362 minecraft:yellow_terracotta
fill 36 218 363 36 221 363 minecraft:honeycomb_block
fill 37 218 342 38 221 342 minecraft:brown_terracotta
fill 37 218 348 38 221 348 minecraft:brown_terracotta
fill 37 218 362 37 221 362 minecraft:honeycomb_block
setblock 38 218 324 minecraft:honeycomb_block
setblock 38 218 325 minecraft:light[level=12]
setblock 38 218 332 minecraft:light[level=12]
setblock 38 218 339 minecraft:light[level=12]
setblock 38 218 353 minecraft:light[level=12]
setblock 38 218 360 minecraft:light[level=12]
fill 38 218 361 38 221 361 minecraft:honeycomb_block
setblock 39 218 323 minecraft:honeycomb_block
setblock 39 218 324 minecraft:yellow_terracotta
setblock 39 218 334 minecraft:yellow_terracotta
setblock 39 218 358 minecraft:honeycomb_block
setblock 39 218 359 minecraft:yellow_terracotta
fill 39 218 360 39 221 360 minecraft:honeycomb_block
setblock 40 218 323 minecraft:yellow_terracotta
setblock 40 218 324 minecraft:honeycomb_block
setblock 40 218 328 minecraft:yellow_terracotta
setblock 40 218 329 minecraft:honeycomb_block
setblock 40 218 333 minecraft:yellow_terracotta
fill 40 218 334 40 221 334 minecraft:honeycomb_block
setblock 40 218 338 minecraft:yellow_terracotta
fill 40 218 343 40 221 343 minecraft:brown_terracotta
fill 40 218 347 40 221 347 minecraft:brown_terracotta
setblock 40 218 353 minecraft:yellow_terracotta
fill 40 218 354 40 221 354 minecraft:honeycomb_block
setblock 40 218 358 minecraft:yellow_terracotta
fill 40 218 359 40 221 359 minecraft:honeycomb_block
setblock 40 218 363 minecraft:yellow_terracotta
fill 41 218 323 41 221 323 minecraft:honeycomb_block
setblock 41 218 327 minecraft:yellow_terracotta
fill 41 218 328 41 220 328 minecraft:honeycomb_block
setblock 41 218 332 minecraft:yellow_terracotta
fill 41 218 333 41 221 333 minecraft:honeycomb_block
setblock 41 218 337 minecraft:yellow_terracotta
fill 41 218 338 42 221 338 minecraft:honeycomb_block
setblock 41 218 349 minecraft:honey_block
setblock 41 218 352 minecraft:yellow_terracotta
fill 41 218 353 41 221 353 minecraft:honeycomb_block
setblock 41 218 357 minecraft:yellow_terracotta
fill 41 218 358 41 221 358 minecraft:honeycomb_block
setblock 41 218 362 minecraft:yellow_terracotta
fill 41 218 363 41 221 363 minecraft:honeycomb_block
fill 42 218 325 42 308 325 minecraft:honeycomb_block
fill 0 219 332 1 219 332 minecraft:honeycomb_block
setblock 0 219 340 minecraft:yellow_concrete
fill 1 219 333 1 219 335 minecraft:honeycomb_block
setblock 1 219 336 minecraft:yellow_terracotta
fill 1 219 337 1 222 337 minecraft:honeycomb_block
setblock 1 219 340 minecraft:honeycomb_block
setblock 1 219 341 minecraft:yellow_terracotta
fill 1 219 342 1 222 342 minecraft:honeycomb_block
setblock 1 219 343 minecraft:honey_block
fill 1 219 348 1 219 350 minecraft:honeycomb_block
setblock 1 219 351 minecraft:yellow_terracotta
fill 1 219 352 1 219 355 minecraft:honeycomb_block
setblock 1 219 356 minecraft:yellow_terracotta
fill 1 219 357 1 222 357 minecraft:honeycomb_block
setblock 1 219 361 minecraft:yellow_terracotta
fill 1 219 362 1 222 362 minecraft:honeycomb_block
fill 2 219 352 2 219 354 minecraft:honeycomb_block
setblock 2 219 355 minecraft:yellow_terracotta
fill 2 219 356 2 222 356 minecraft:honeycomb_block
setblock 2 219 360 minecraft:yellow_terracotta
fill 2 219 361 2 222 361 minecraft:honeycomb_block
setblock 3 219 355 minecraft:honeycomb_block
setblock 3 219 359 minecraft:yellow_terracotta
setblock 4 219 363 minecraft:yellow_terracotta
fill 14 219 322 14 289 322 minecraft:honeycomb_block
setblock 17 219 323 minecraft:honey_block
fill 17 219 363 18 219 363 minecraft:honeycomb_block
setblock 19 219 363 minecraft:yellow_terracotta
setblock 25 219 363 minecraft:honey_block
setblock 27 219 322 minecraft:yellow_terracotta
setblock 34 219 323 minecraft:yellow_terracotta
fill 34 219 344 34 221 345 minecraft:brown_terracotta
setblock 34 219 363 minecraft:yellow_terracotta
fill 35 219 323 35 222 323 minecraft:honeycomb_block
fill 35 219 343 35 221 343 minecraft:brown_terracotta
fill 35 219 347 35 221 347 minecraft:brown_terracotta
setblock 35 219 362 minecraft:yellow_terracotta
fill 35 219 363 35 222 363 minecraft:honeycomb_block
fill 36 219 342 36 221 342 minecraft:brown_terracotta
fill 36 219 348 36 221 348 minecraft:brown_terracotta
fill 36 219 362 36 222 362 minecraft:honeycomb_block
fill 37 219 361 37 222 361 minecraft:honeycomb_block
setblock 38 219 324 minecraft:yellow_terracotta
setblock 39 219 323 minecraft:yellow_terracotta
fill 39 219 324 39 222 324 minecraft:honeycomb_block
fill 39 219 342 39 221 342 minecraft:brown_terracotta
fill 39 219 348 39 221 348 minecraft:brown_terracotta
setblock 39 219 358 minecraft:yellow_terracotta
fill 39 219 359 39 222 359 minecraft:honeycomb_block
setblock 39 219 363 minecraft:yellow_terracotta
fill 40 219 323 40 222 323 minecraft:honeycomb_block
setblock 40 219 332 minecraft:yellow_terracotta
fill 40 219 333 40 220 333 minecraft:honeycomb_block
setblock 40 219 337 minecraft:yellow_terracotta
fill 40 219 338 40 222 338 minecraft:honeycomb_block
setblock 40 219 353 minecraft:honeycomb_block
setblock 40 219 357 minecraft:yellow_terracotta
fill 40 219 358 40 222 358 minecraft:honeycomb_block
setblock 40 219 362 minecraft:yellow_terracotta
fill 40 219 363 40 222 363 minecraft:honeycomb_block
setblock 41 219 326 minecraft:yellow_terracotta
fill 41 219 327 41 220 327 minecraft:honeycomb_block
setblock 41 219 331 minecraft:yellow_terracotta
fill 41 219 332 41 221 332 minecraft:honeycomb_block
setblock 41 219 336 minecraft:yellow_terracotta
fill 41 219 337 41 222 337 minecraft:honeycomb_block
setblock 41 219 343 minecraft:honey_block
fill 41 219 344 41 221 346 minecraft:brown_terracotta
setblock 41 219 351 minecraft:yellow_terracotta
fill 41 219 352 41 222 352 minecraft:honeycomb_block
setblock 41 219 356 minecraft:yellow_terracotta
fill 41 219 357 41 222 357 minecraft:honeycomb_block
setblock 41 219 361 minecraft:yellow_terracotta
fill 41 219 362 41 222 362 minecraft:honeycomb_block
setblock 42 219 330 minecraft:yellow_terracotta
setblock 42 219 350 minecraft:yellow_concrete
setblock 42 219 362 minecraft:orange_terracotta
fill 0 220 332 0 308 332 minecraft:honeycomb_block
fill 0 220 340 0 290 340 minecraft:honeycomb_block
setblock 1 220 324 minecraft:honey_block
fill 1 220 333 1 220 334 minecraft:honeycomb_block
setblock 1 220 335 minecraft:yellow_terracotta
fill 1 220 336 1 223 336 minecraft:honeycomb_block
setblock 1 220 340 minecraft:yellow_terracotta
fill 1 220 341 1 223 341 minecraft:honeycomb_block
fill 1 220 343 1 221 343 minecraft:honeycomb_block
setblock 1 220 349 minecraft:honeycomb_block
setblock 1 220 350 minecraft:yellow_terracotta
fill 1 220 351 1 220 354 minecraft:honeycomb_block
setblock 1 220 355 minecraft:yellow_terracotta
fill 1 220 356 1 223 356 minecraft:honeycomb_block
setblock 1 220 360 minecraft:yellow_terracotta
fill 1 220 361 1 223 361 minecraft:honeycomb_block
setblock 2 220 353 minecraft:honeycomb_block
setblock 2 220 354 minecraft:yellow_terracotta
fill 2 220 355 2 223 355 minecraft:honeycomb_block
setblock 2 220 359 minecraft:yellow_terracotta
fill 2 220 360 2 223 360 minecraft:honeycomb_block
setblock 3 220 358 minecraft:yellow_terracotta
setblock 3 220 359 minecraft:honeycomb_block
setblock 3 220 363 minecraft:yellow_terracotta
fill 4 220 363 4 223 363 minecraft:honeycomb_block
setblock 6 220 363 minecraft:honey_block
setblock 11 220 323 minecraft:honey_block
setblock 14 220 364 minecraft:yellow_terracotta
fill 15 220 363 17 220 363 minecraft:honeycomb_block
setblock 18 220 363 minecraft:yellow_terracotta
fill 19 220 363 20 222 363 minecraft:honeycomb_block
fill 27 220 322 27 308 322 minecraft:honeycomb_block
setblock 31 220 363 minecraft:honey_block
setblock 32 220 363 minecraft:honeycomb_block
setblock 33 220 323 minecraft:yellow_terracotta
setblock 33 220 363 minecraft:yellow_terracotta
fill 34 220 323 34 223 323 minecraft:honeycomb_block
fill 34 220 343 34 221 343 minecraft:brown_terracotta
fill 34 220 346 34 221 347 minecraft:brown_terracotta
setblock 34 220 362 minecraft:yellow_terracotta
fill 34 220 363 34 223 363 minecraft:honeycomb_block
fill 35 220 342 35 221 342 minecraft:brown_terracotta
fill 35 220 348 35 221 348 minecraft:brown_terracotta
fill 35 220 362 35 223 362 minecraft:honeycomb_block
setblock 36 220 324 minecraft:honeycomb_block
fill 36 220 361 36 223 361 minecraft:honeycomb_block
setblock 37 220 324 minecraft:yellow_terracotta
fill 37 220 341 38 221 341 minecraft:brown_terracotta
fill 37 220 349 38 221 349 minecraft:brown_terracotta
setblock 38 220 323 minecraft:yellow_terracotta
fill 38 220 324 38 223 324 minecraft:honeycomb_block
setblock 38 220 363 minecraft:yellow_terracotta
fill 39 220 323 39 223 323 minecraft:honeycomb_block
setblock 39 220 357 minecraft:yellow_terracotta
fill 39 220 358 39 223 358 minecraft:honeycomb_block
setblock 39 220 362 minecraft:yellow_terracotta
fill 39 220 363 39 223 363 minecraft:honeycomb_block
setblock 40 220 336 minecraft:yellow_terracotta
fill 40 220 337 40 223 337 minecraft:honeycomb_block
fill 40 220 342 40 221 342 minecraft:brown_terracotta
fill 40 220 348 40 221 348 minecraft:brown_terracotta
setblock 40 220 356 minecraft:yellow_terracotta
fill 40 220 357 40 223 357 minecraft:honeycomb_block
setblock 40 220 361 minecraft:yellow_terracotta
fill 40 220 362 40 223 362 minecraft:honeycomb_block
setblock 41 220 325 minecraft:yellow_terracotta
fill 41 220 326 41 223 326 minecraft:honeycomb_block
setblock 41 220 330 minecraft:yellow_terracotta
fill 41 220 331 41 221 331 minecraft:honeycomb_block
setblock 41 220 335 minecraft:yellow_terracotta
fill 41 220 336 41 223 336 minecraft:honeycomb_block
setblock 41 220 340 minecraft:yellow_terracotta
fill 41 220 341 41 223 341 minecraft:honeycomb_block
fill 41 220 343 41 221 343 minecraft:brown_terracotta
fill 41 220 347 41 221 347 minecraft:brown_terracotta
setblock 41 220 355 minecraft:yellow_terracotta
fill 41 220 356 41 223 356 minecraft:honeycomb_block
setblock 41 220 360 minecraft:yellow_terracotta
fill 41 220 361 41 223 361 minecraft:honeycomb_block
fill 42 220 330 42 225 330 minecraft:honeycomb_block
fill 42 220 350 42 266 350 minecraft:honeycomb_block
setblock 42 220 360 minecraft:orange_terracotta
fill 42 220 362 42 308 362 minecraft:honeycomb_block
setblock 0 221 335 minecraft:yellow_concrete
setblock 1 221 330 minecraft:honey_block
setblock 1 221 334 minecraft:yellow_terracotta
fill 1 221 335 1 224 335 minecraft:honeycomb_block
setblock 1 221 339 minecraft:yellow_terracotta
fill 1 221 340 1 224 340 minecraft:honeycomb_block
setblock 1 221 344 minecraft:yellow_terracotta
fill 1 221 345 1 223 346 minecraft:honeycomb_block
setblock 1 221 348 minecraft:honeycomb_block
setblock 1 221 349 minecraft:yellow_terracotta
fill 1 221 350 1 221 353 minecraft:honeycomb_block
setblock 1 221 354 minecraft:yellow_terracotta
fill 1 221 355 1 224 355 minecraft:honeycomb_block
setblock 1 221 359 minecraft:yellow_terracotta
fill 1 221 360 1 224 360 minecraft:honeycomb_block
setblock 2 221 353 minecraft:yellow_terracotta
fill 2 221 354 2 223 354 minecraft:honeycomb_block
setblock 2 221 358 minecraft:yellow_terracotta
fill 2 221 359 2 224 359 minecraft:honeycomb_block
setblock 2 221 363 minecraft:yellow_terracotta
setblock 3 221 362 minecraft:yellow_terracotta
fill 3 221 363 3 224 363 minecraft:honeycomb_block
setblock 5 221 323 minecraft:honey_block
fill 5 221 363 5 222 363 minecraft:honeycomb_block
fill 6 221 348 7 222 348 minecraft:yellow_concrete
fill 7 221 347 7 222 347 minecraft:yellow_concrete
setblock 12 221 363 minecraft:honey_block
fill 13 221 363 16 221 363 minecraft:honeycomb_block
fill 14 221 364 14 308 364 minecraft:honeycomb_block
setblock 17 221 323 minecraft:yellow_terracotta
setblock 17 221 363 minecraft:yellow_terracotta
fill 18 221 323 20 222 323 minecraft:honeycomb_block
fill 18 221 363 18 224 363 minecraft:honeycomb_block
setblock 21 221 363 minecraft:honeycomb_block
setblock 30 221 323 minecraft:honey_block
fill 30 221 331 30 223 333 minecraft:flowering_azalea_leaves[persistent=true]
setblock 31 221 323 minecraft:honeycomb_block
fill 31 221 331 32 223 331 minecraft:flowering_azalea_leaves[persistent=true]
fill 31 221 333 32 223 334 minecraft:flowering_azalea_leaves[persistent=true]
setblock 31 221 363 minecraft:honeycomb_block
setblock 32 221 323 minecraft:yellow_terracotta
fill 32 221 332 33 223 332 minecraft:flowering_azalea_leaves[persistent=true]
setblock 32 221 363 minecraft:yellow_terracotta
fill 33 221 323 33 224 323 minecraft:honeycomb_block
setblock 33 221 345 minecraft:brown_terracotta
setblock 33 221 362 minecraft:yellow_terracotta
fill 33 221 363 33 224 363 minecraft:honeycomb_block
setblock 34 221 342 minecraft:brown_terracotta
fill 34 221 362 34 224 362 minecraft:honeycomb_block
setblock 35 221 324 minecraft:honeycomb_block
fill 35 221 361 35 224 361 minecraft:honeycomb_block
setblock 36 221 324 minecraft:yellow_terracotta
setblock 36 221 341 minecraft:brown_terracotta
setblock 36 221 349 minecraft:brown_terracotta
setblock 37 221 323 minecraft:yellow_terracotta
fill 37 221 324 37 224 324 minecraft:honeycomb_block
setblock 37 221 363 minecraft:yellow_terracotta
fill 38 221 323 38 224 323 minecraft:honeycomb_block
setblock 38 221 362 minecraft:yellow_terracotta
fill 38 221 363 38 224 363 minecraft:honeycomb_block
setblock 39 221 341 minecraft:brown_terracotta
setblock 39 221 349 minecraft:brown_terracotta
setblock 39 221 356 minecraft:yellow_terracotta
fill 39 221 357 39 224 357 minecraft:honeycomb_block
setblock 39 221 361 minecraft:yellow_terracotta
fill 39 221 362 39 224 362 minecraft:honeycomb_block
setblock 40 221 335 minecraft:yellow_terracotta
fill 40 221 336 40 222 336 minecraft:honeycomb_block
setblock 40 221 355 minecraft:yellow_terracotta
fill 40 221 356 40 224 356 minecraft:honeycomb_block
setblock 40 221 360 minecraft:yellow_terracotta
fill 40 221 361 40 224 361 minecraft:honeycomb_block
setblock 41 221 324 minecraft:yellow_terracotta
fill 41 221 325 41 224 325 minecraft:honeycomb_block
setblock 41 221 334 minecraft:yellow_terracotta
fill 41 221 335 41 224 335 minecraft:honeycomb_block
setblock 41 221 339 minecraft:yellow_terracotta
fill 41 221 340 41 224 340 minecraft:honeycomb_block
setblock 41 221 342 minecraft:brown_terracotta
setblock 41 221 348 minecraft:brown_terracotta
setblock 41 221 354 minecraft:yellow_terracotta
fill 41 221 355 41 224 355 minecraft:honeycomb_block
setblock 41 221 359 minecraft:yellow_terracotta
fill 41 221 360 42 224 360 minecraft:honeycomb_block
fill 0 222 335 0 308 335 minecraft:honeycomb_block
setblock 1 222 338 minecraft:yellow_terracotta
fill 1 222 339 1 225 339 minecraft:honeycomb_block
setblock 1 222 343 minecraft:yellow_terracotta
fill 1 222 344 1 225 344 minecraft:honeycomb_block
setblock 1 222 347 minecraft:honeycomb_block
setblock 1 222 348 minecraft:yellow_terracotta
fill 1 222 349 1 222 352 minecraft:honeycomb_block
setblock 1 222 353 minecraft:yellow_terracotta
fill 1 222 354 1 225 354 minecraft:honeycomb_block
setblock 1 222 358 minecraft:yellow_terracotta
fill 1 222 359 1 225 359 minecraft:honeycomb_block
setblock 1 222 363 minecraft:yellow_terracotta
setblock 2 222 357 minecraft:yellow_terracotta
fill 2 222 358 2 225 358 minecraft:honeycomb_block
setblock 2 222 362 minecraft:yellow_terracotta
fill 2 222 363 2 225 363 minecraft:honeycomb_block
fill 3 222 362 3 225 362 minecraft:honeycomb_block
setblock 11 222 363 minecraft:yellow_terracotta
fill 12 222 363 15 222 363 minecraft:honeycomb_block
setblock 12 222 364 minecraft:yellow_terracotta
fill 14 222 362 16 222 362 minecraft:honeycomb_block
setblock 15 222 323 minecraft:honeycomb_block
setblock 16 222 323 minecraft:yellow_terracotta
setblock 16 222 363 minecraft:yellow_terracotta
fill 17 222 323 17 225 323 minecraft:honeycomb_block
setblock 17 222 362 minecraft:yellow_terracotta
fill 17 222 363 17 225 363 minecraft:honeycomb_block
fill 18 222 362 19 224 362 minecraft:honeycomb_block
setblock 21 222 323 minecraft:yellow_terracotta
setblock 21 222 363 minecraft:yellow_terracotta
fill 22 222 323 22 225 323 minecraft:honeycomb_block
fill 22 222 363 22 225 363 minecraft:honeycomb_block
setblock 24 222 323 minecraft:honey_block
fill 29 222 323 30 222 323 minecraft:honeycomb_block
fill 29 222 332 29 222 333 minecraft:flowering_azalea_leaves[persistent=true]
fill 29 222 363 30 222 363 minecraft:honeycomb_block
setblock 30 222 334 minecraft:flowering_azalea_leaves[persistent=true]
setblock 31 222 323 minecraft:yellow_terracotta
setblock 31 222 330 minecraft:flowering_azalea_leaves[persistent=true]
fill 31 222 332 31 223 332 minecraft:flowering_azalea_leaves[persistent=true]
setblock 31 222 363 minecraft:yellow_terracotta
fill 32 222 323 32 225 323 minecraft:honeycomb_block
setblock 32 222 362 minecraft:yellow_terracotta
fill 32 222 363 32 225 363 minecraft:honeycomb_block
fill 33 222 324 34 222 324 minecraft:honeycomb_block
setblock 33 222 331 minecraft:flowering_azalea_leaves[persistent=true]
setblock 33 222 333 minecraft:flowering_azalea_leaves[persistent=true]
fill 33 222 362 33 225 362 minecraft:honeycomb_block
fill 34 222 361 34 225 361 minecraft:honeycomb_block
setblock 35 222 324 minecraft:yellow_terracotta
setblock 36 222 323 minecraft:yellow_terracotta
fill 36 222 324 36 225 324 minecraft:honeycomb_block
setblock 36 222 363 minecraft:yellow_terracotta
fill 37 222 323 37 225 323 minecraft:honeycomb_block
fill 37 222 345 38 224 345 minecraft:yellow_terracotta
fill 37 222 360 38 222 360 minecraft:honeycomb_block
setblock 37 222 362 minecraft:yellow_terracotta
fill 37 222 363 37 225 363 minecraft:honeycomb_block
fill 38 222 359 38 223 359 minecraft:honeycomb_block
setblock 38 222 361 minecraft:yellow_terracotta
fill 38 222 362 38 225 362 minecraft:honeycomb_block
fill 39 222 356 39 224 356 minecraft:honeycomb_block
setblock 39 222 360 minecraft:yellow_terracotta
fill 39 222 361 39 225 361 minecraft:honeycomb_block
setblock 40 222 324 minecraft:yellow_terracotta
setblock 40 222 339 minecraft:yellow_terracotta
setblock 40 222 354 minecraft:yellow_terracotta
fill 40 222 355 40 225 355 minecraft:honeycomb_block
setblock 40 222 359 minecraft:yellow_terracotta
fill 40 222 360 40 225 360 minecraft:honeycomb_block
setblock 41 222 323 minecraft:yellow_terracotta
fill 41 222 324 41 225 324 minecraft:honeycomb_block
setblock 41 222 333 minecraft:yellow_terracotta
fill 41 222 334 41 223 334 minecraft:honeycomb_block
setblock 41 222 338 minecraft:yellow_terracotta
fill 41 222 339 41 225 339 minecraft:honeycomb_block
setblock 41 222 342 minecraft:honeycomb_block
setblock 41 222 350 minecraft:honey_block
setblock 41 222 353 minecraft:yellow_terracotta
fill 41 222 354 41 225 354 minecraft:honeycomb_block
setblock 41 222 358 minecraft:yellow_terracotta
fill 41 222 359 41 225 359 minecraft:honeycomb_block
setblock 41 222 363 minecraft:yellow_terracotta
fill 42 222 338 42 226 338 minecraft:honeycomb_block
setblock 42 222 340 minecraft:orange_terracotta
setblock 42 222 356 minecraft:orange_terracotta
setblock 1 223 323 minecraft:honey_block
setblock 1 223 337 minecraft:yellow_terracotta
fill 1 223 338 1 226 338 minecraft:honeycomb_block
setblock 1 223 342 minecraft:yellow_terracotta
fill 1 223 343 1 226 343 minecraft:honeycomb_block
setblock 1 223 347 minecraft:yellow_terracotta
fill 1 223 348 1 223 351 minecraft:honeycomb_block
setblock 1 223 352 minecraft:yellow_terracotta
fill 1 223 353 1 226 353 minecraft:honeycomb_block
setblock 1 223 357 minecraft:yellow_terracotta
fill 1 223 358 1 226 358 minecraft:honeycomb_block
setblock 1 223 362 minecraft:yellow_terracotta
fill 1 223 363 1 226 363 minecraft:honeycomb_block
fill 2 223 339 2 223 340 minecraft:honeycomb_block
setblock 2 223 341 minecraft:yellow_terracotta
fill 2 223 342 2 226 342 minecraft:honeycomb_block
setblock 2 223 356 minecraft:yellow_terracotta
fill 2 223 357 2 226 357 minecraft:honeycomb_block
setblock 2 223 361 minecraft:yellow_terracotta
fill 2 223 362 2 226 362 minecraft:honeycomb_block
fill 4 223 359 4 227 359 minecraft:brown_terracotta
fill 4 223 362 4 224 362 minecraft:honeycomb_block
setblock 5 223 363 minecraft:yellow_terracotta
fill 6 223 363 9 223 363 minecraft:honeycomb_block
fill 8 223 336 11 271 339 minecraft:yellow_terracotta
setblock 10 223 363 minecraft:yellow_terracotta
fill 11 223 363 14 223 363 minecraft:honeycomb_block
setblock 12 223 323 minecraft:honey_block
fill 12 223 362 15 223 362 minecraft:honeycomb_block
fill 12 223 364 12 233 364 minecraft:honeycomb_block
fill 13 223 323 14 223 323 minecraft:honeycomb_block
setblock 15 223 323 minecraft:yellow_terracotta
setblock 15 223 363 minecraft:yellow_terracotta
fill 16 223 323 16 226 323 minecraft:honeycomb_block
setblock 16 223 362 minecraft:yellow_terracotta
fill 16 223 363 16 226 363 minecraft:honeycomb_block
fill 17 223 362 17 226 362 minecraft:honeycomb_block
fill 18 223 323 19 223 323 minecraft:honeycomb_block
setblock 19 223 363 minecraft:honeycomb_block
fill 20 223 322 20 223 323 minecraft:yellow_terracotta
setblock 20 223 362 minecraft:honeycomb_block
setblock 20 223 363 minecraft:yellow_terracotta
fill 21 223 323 21 226 323 minecraft:honeycomb_block
fill 21 223 363 21 226 363 minecraft:honeycomb_block
fill 23 223 323 24 223 323 minecraft:honeycomb_block
fill 23 223 363 23 224 363 minecraft:honeycomb_block
setblock 24 223 363 minecraft:honey_block
setblock 25 223 322 minecraft:yellow_concrete
setblock 25 223 323 minecraft:yellow_terracotta
fill 26 223 323 29 223 323 minecraft:honeycomb_block
fill 27 223 363 29 223 363 minecraft:honeycomb_block
setblock 30 223 323 minecraft:yellow_terracotta
setblock 30 223 362 minecraft:honeycomb_block
setblock 30 223 363 minecraft:yellow_terracotta
fill 31 223 323 31 225 324 minecraft:honeycomb_block
setblock 31 223 362 minecraft:yellow_terracotta
fill 31 223 363 31 226 363 minecraft:honeycomb_block
fill 32 223 324 33 223 324 minecraft:honeycomb_block
setblock 32 223 361 minecraft:yellow_terracotta
fill 32 223 362 32 226 362 minecraft:honeycomb_block
fill 33 223 361 33 226 361 minecraft:honeycomb_block
setblock 34 223 324 minecraft:yellow_terracotta
setblock 35 223 323 minecraft:yellow_terracotta
fill 35 223 324 35 226 324 minecraft:honeycomb_block
fill 35 223 360 37 223 360 minecraft:honeycomb_block
setblock 35 223 363 minecraft:yellow_terracotta
fill 36 223 323 36 226 323 minecraft:honeycomb_block
setblock 36 223 362 minecraft:yellow_terracotta
fill 36 223 363 36 226 363 minecraft:honeycomb_block
setblock 37 223 361 minecraft:yellow_terracotta
fill 37 223 362 37 226 362 minecraft:honeycomb_block
setblock 38 223 360 minecraft:yellow_terracotta
fill 38 223 361 38 226 361 minecraft:honeycomb_block
setblock 39 223 324 minecraft:yellow_terracotta
setblock 39 223 359 minecraft:yellow_terracotta
fill 39 223 360 39 226 360 minecraft:honeycomb_block
setblock 40 223 323 minecraft:yellow_terracotta
fill 40 223 324 40 226 324 minecraft:honeycomb_block
setblock 40 223 338 minecraft:yellow_terracotta
fill 40 223 339 40 225 340 minecraft:honeycomb_block
fill 40 223 354 40 224 354 minecraft:honeycomb_block
setblock 40 223 358 minecraft:yellow_terracotta
fill 40 223 359 40 226 359 minecraft:honeycomb_block
setblock 40 223 363 minecraft:yellow_terracotta
fill 41 223 323 41 226 323 minecraft:honeycomb_block
setblock 41 223 337 minecraft:yellow_terracotta
fill 41 223 338 41 226 338 minecraft:honeycomb_block
setblock 41 223 342 minecraft:yellow_terracotta
fill 41 223 343 41 225 344 minecraft:honeycomb_block
setblock 41 223 352 minecraft:yellow_terracotta
fill 41 223 353 41 226 353 minecraft:honeycomb_block
setblock 41 223 357 minecraft:yellow_terracotta
fill 41 223 358 41 226 358 minecraft:honeycomb_block
setblock 41 223 362 minecraft:yellow_terracotta
fill 41 223 363 41 226 363 minecraft:honeycomb_block
setblock 42 223 340 minecraft:yellow_concrete
fill 42 223 356 42 251 356 minecraft:honeycomb_block
setblock 0 224 348 minecraft:yellow_concrete
setblock 0 224 349 minecraft:yellow_terracotta
fill 1 224 323 1 226 323 minecraft:honeycomb_block
setblock 1 224 329 minecraft:honey_block
setblock 1 224 336 minecraft:yellow_terracotta
fill 1 224 337 1 227 337 minecraft:honeycomb_block
setblock 1 224 341 minecraft:yellow_terracotta
fill 1 224 342 1 227 342 minecraft:honeycomb_block
setblock 1 224 345 minecraft:honeycomb_block
setblock 1 224 346 minecraft:yellow_terracotta
fill 1 224 347 1 224 350 minecraft:honeycomb_block
setblock 1 224 351 minecraft:yellow_terracotta
fill 1 224 352 1 227 352 minecraft:honeycomb_block
setblock 1 224 356 minecraft:yellow_terracotta
fill 1 224 357 1 227 357 minecraft:honeycomb_block
setblock 1 224 361 minecraft:yellow_terracotta
fill 1 224 362 1 227 362 minecraft:honeycomb_block
setblock 2 224 339 minecraft:honeycomb_block
setblock 2 224 340 minecraft:yellow_terracotta
fill 2 224 341 2 227 341 minecraft:honeycomb_block
fill 2 224 343 2 224 344 minecraft:honeycomb_block
setblock 2 224 355 minecraft:yellow_terracotta
fill 2 224 356 2 225 356 minecraft:honeycomb_block
setblock 2 224 360 minecraft:yellow_terracotta
fill 2 224 361 2 227 361 minecraft:honeycomb_block
setblock 3 224 325 minecraft:light[level=15]
setblock 3 224 332 minecraft:light[level=12]
setblock 3 224 333 minecraft:light[level=15]
setblock 3 224 339 minecraft:light[level=12]
setblock 3 224 341 minecraft:light[level=15]
setblock 3 224 346 minecraft:light[level=12]
setblock 3 224 349 minecraft:light[level=15]
setblock 3 224 353 minecraft:light[level=12]
setblock 3 224 357 minecraft:light[level=15]
setblock 3 224 360 minecraft:light[level=12]
fill 4 224 355 4 227 355 minecraft:yellow_terracotta
setblock 4 224 363 minecraft:yellow_terracotta
fill 5 224 354 5 227 354 minecraft:yellow_terracotta
fill 5 224 356 5 227 356 minecraft:yellow_terracotta
fill 5 224 363 8 224 363 minecraft:honeycomb_block
setblock 6 224 323 minecraft:honey_block
fill 6 224 355 6 227 355 minecraft:yellow_terracotta
fill 7 224 336 7 225 339 minecraft:brown_terracotta
fill 8 224 335 11 225 335 minecraft:brown_terracotta
fill 8 224 340 11 225 340 minecraft:brown_terracotta
setblock 9 224 363 minecraft:yellow_terracotta
setblock 10 224 325 minecraft:light[level=12]
setblock 10 224 332 minecraft:light[level=12]
setblock 10 224 346 minecraft:light[level=12]
setblock 10 224 353 minecraft:light[level=12]
setblock 10 224 360 minecraft:light[level=12]
setblock 10 224 362 minecraft:yellow_terracotta
fill 10 224 363 13 224 363 minecraft:honeycomb_block
fill 11 224 323 13 224 323 minecraft:honeycomb_block
setblock 11 224 325 minecraft:light[level=15]
setblock 11 224 333 minecraft:light[level=15]
setblock 11 224 341 minecraft:light[level=15]
setblock 11 224 349 minecraft:light[level=15]
setblock 11 224 357 minecraft:light[level=15]
fill 11 224 362 14 224 362 minecraft:honeycomb_block
fill 12 224 336 12 225 339 minecraft:brown_terracotta
setblock 14 224 323 minecraft:yellow_terracotta
setblock 14 224 363 minecraft:yellow_terracotta
fill 15 224 323 15 226 324 minecraft:honeycomb_block
setblock 15 224 361 minecraft:honeycomb_block
setblock 15 224 362 minecraft:yellow_terracotta
fill 15 224 363 15 227 363 minecraft:honeycomb_block
fill 16 224 324 17 224 324 minecraft:honeycomb_block
setblock 16 224 361 minecraft:yellow_terracotta
fill 16 224 362 16 227 362 minecraft:honeycomb_block
setblock 17 224 325 minecraft:light[level=12]
setblock 17 224 332 minecraft:light[level=12]
setblock 17 224 339 minecraft:light[level=12]
setblock 17 224 346 minecraft:light[level=12]
setblock 17 224 353 minecraft:light[level=12]
setblock 17 224 360 minecraft:light[level=12]
setblock 18 224 323 minecraft:honeycomb_block
setblock 18 224 324 minecraft:yellow_terracotta
setblock 19 224 323 minecraft:yellow_terracotta
fill 19 224 324 20 226 324 minecraft:honeycomb_block
setblock 19 224 325 minecraft:light[level=15]
setblock 19 224 333 minecraft:light[level=15]
setblock 19 224 341 minecraft:light[level=15]
setblock 19 224 349 minecraft:light[level=15]
setblock 19 224 357 minecraft:light[level=15]
setblock 19 224 363 minecraft:yellow_terracotta
fill 20 224 322 20 227 323 minecraft:honeycomb_block
setblock 20 224 362 minecraft:yellow_terracotta
fill 20 224 363 20 227 363 minecraft:honeycomb_block
setblock 23 224 323 minecraft:honeycomb_block
setblock 24 224 323 minecraft:yellow_terracotta
setblock 24 224 325 minecraft:light[level=12]
setblock 24 224 332 minecraft:light[level=12]
setblock 24 224 339 minecraft:light[level=12]
setblock 24 224 346 minecraft:light[level=12]
setblock 24 224 353 minecraft:light[level=12]
setblock 24 224 360 minecraft:light[level=12]
setblock 24 224 363 minecraft:yellow_terracotta
fill 25 224 322 25 227 323 minecraft:honeycomb_block
fill 25 224 363 28 224 363 minecraft:honeycomb_block
fill 26 224 323 28 224 323 minecraft:honeycomb_block
setblock 27 224 325 minecraft:light[level=15]
setblock 27 224 333 minecraft:light[level=15]
setblock 27 224 341 minecraft:light[level=15]
setblock 27 224 349 minecraft:light[level=15]
setblock 27 224 357 minecraft:light[level=15]
setblock 29 224 323 minecraft:yellow_terracotta
fill 29 224 324 30 226 324 minecraft:honeycomb_block
setblock 29 224 362 minecraft:honeycomb_block
setblock 29 224 363 minecraft:yellow_terracotta
fill 30 224 323 30 227 323 minecraft:honeycomb_block
setblock 30 224 362 minecraft:yellow_terracotta
fill 30 224 363 30 227 363 minecraft:honeycomb_block
setblock 31 224 325 minecraft:light[level=12]
setblock 31 224 332 minecraft:light[level=12]
setblock 31 224 339 minecraft:light[level=12]
setblock 31 224 346 minecraft:light[level=12]
setblock 31 224 353 minecraft:light[level=12]
setblock 31 224 360 minecraft:light[level=12]
setblock 31 224 361 minecraft:yellow_terracotta
fill 31 224 362 31 227 362 minecraft:honeycomb_block
setblock 32 224 324 minecraft:honeycomb_block
fill 32 224 361 32 227 361 minecraft:honeycomb_block
setblock 33 224 324 minecraft:yellow_terracotta
fill 33 224 325 36 224 325 minecraft:honeycomb_block
setblock 34 224 323 minecraft:yellow_terracotta
fill 34 224 324 34 227 324 minecraft:honeycomb_block
fill 34 224 360 36 224 360 minecraft:honeycomb_block
setblock 34 224 363 minecraft:yellow_terracotta
fill 35 224 323 35 227 323 minecraft:honeycomb_block
setblock 35 224 333 minecraft:light[level=15]
setblock 35 224 341 minecraft:light[level=15]
setblock 35 224 349 minecraft:light[level=15]
setblock 35 224 357 minecraft:light[level=15]
setblock 35 224 362 minecraft:yellow_terracotta
fill 35 224 363 35 227 363 minecraft:honeycomb_block
setblock 36 224 361 minecraft:yellow_terracotta
fill 36 224 362 36 227 362 minecraft:honeycomb_block
setblock 37 224 325 minecraft:yellow_terracotta
setblock 37 224 360 minecraft:yellow_terracotta
fill 37 224 361 37 227 361 minecraft:honeycomb_block
setblock 38 224 324 minecraft:yellow_terracotta
setblock 38 224 325 minecraft:light[level=12]
setblock 38 224 332 minecraft:light[level=12]
setblock 38 224 339 minecraft:light[level=12]
setblock 38 224 346 minecraft:light[level=12]
setblock 38 224 353 minecraft:light[level=12]
setblock 38 224 358 minecraft:honeycomb_block
setblock 38 224 359 minecraft:yellow_terracotta
fill 38 224 360 38 227 360 minecraft:honeycomb_block
setblock 39 224 323 minecraft:yellow_terracotta
fill 39 224 324 39 227 324 minecraft:honeycomb_block
setblock 39 224 358 minecraft:yellow_terracotta
fill 39 224 359 39 227 359 minecraft:honeycomb_block
setblock 39 224 363 minecraft:yellow_terracotta
fill 40 224 323 40 227 323 minecraft:honeycomb_block
fill 40 224 325 40 225 325 minecraft:honeycomb_block
setblock 40 224 338 minecraft:honeycomb_block
setblock 40 224 341 minecraft:honeycomb_block
setblock 40 224 342 minecraft:yellow_terracotta
setblock 40 224 357 minecraft:yellow_terracotta
fill 40 224 358 40 227 358 minecraft:honeycomb_block
setblock 40 224 362 minecraft:yellow_terracotta
fill 40 224 363 40 227 363 minecraft:honeycomb_block
setblock 41 224 326 minecraft:yellow_terracotta
fill 41 224 332 41 225 332 minecraft:honey_block
setblock 41 224 336 minecraft:yellow_terracotta
fill 41 224 337 41 226 337 minecraft:honeycomb_block
setblock 41 224 341 minecraft:yellow_terracotta
fill 41 224 342 41 227 342 minecraft:honeycomb_block
setblock 41 224 345 minecraft:honeycomb_block
fill 41 224 352 41 227 352 minecraft:honeycomb_block
setblock 41 224 356 minecraft:yellow_terracotta
fill 41 224 357 41 227 357 minecraft:honeycomb_block
setblock 41 224 361 minecraft:yellow_terracotta
fill 41 224 362 41 227 362 minecraft:honeycomb_block
setblock 42 224 340 minecraft:orange_terracotta
setblock 0 225 327 minecraft:orange_terracotta
fill 0 225 348 1 225 349 minecraft:honeycomb_block
setblock 0 225 358 minecraft:yellow_concrete
setblock 1 225 335 minecraft:honey_block
fill 1 225 336 1 226 336 minecraft:honeycomb_block
setblock 1 225 340 minecraft:yellow_terracotta
fill 1 225 341 1 228 341 minecraft:honeycomb_block
setblock 1 225 345 minecraft:yellow_terracotta
fill 1 225 346 1 227 347 minecraft:honeycomb_block
setblock 1 225 350 minecraft:yellow_terracotta
fill 1 225 351 1 228 351 minecraft:honeycomb_block
setblock 1 225 355 minecraft:yellow_terracotta
fill 1 225 356 1 228 356 minecraft:honeycomb_block
setblock 1 225 360 minecraft:yellow_terracotta
fill 1 225 361 1 228 361 minecraft:honeycomb_block
setblock 2 225 339 minecraft:yellow_terracotta
fill 2 225 340 2 228 340 minecraft:honeycomb_block
setblock 2 225 343 minecraft:honeycomb_block
setblock 2 225 344 minecraft:yellow_terracotta
fill 2 225 345 2 227 346 minecraft:honeycomb_block
setblock 2 225 359 minecraft:yellow_terracotta
fill 2 225 360 2 227 360 minecraft:honeycomb_block
setblock 3 225 363 minecraft:yellow_terracotta
setblock 4 225 322 minecraft:yellow_terracotta
setblock 4 225 362 minecraft:yellow_terracotta
fill 4 225 363 7 225 363 minecraft:honeycomb_block
fill 6 225 336 6 225 339 minecraft:brown_terracotta
setblock 7 225 335 minecraft:brown_terracotta
setblock 7 225 340 minecraft:brown_terracotta
fill 8 225 334 11 225 334 minecraft:brown_terracotta
fill 8 225 341 12 225 341 minecraft:brown_terracotta
setblock 8 225 363 minecraft:yellow_terracotta
setblock 9 225 362 minecraft:yellow_terracotta
fill 9 225 363 12 225 363 minecraft:honeycomb_block
fill 10 225 323 12 225 323 minecraft:honeycomb_block
fill 10 225 362 13 225 362 minecraft:honeycomb_block
setblock 12 225 335 minecraft:brown_terracotta
fill 12 225 340 13 225 340 minecraft:brown_terracotta
setblock 13 225 323 minecraft:yellow_terracotta
fill 13 225 324 14 227 324 minecraft:honeycomb_block
fill 13 225 336 13 225 339 minecraft:brown_terracotta
fill 13 225 361 14 225 361 minecraft:honeycomb_block
setblock 13 225 363 minecraft:yellow_terracotta
fill 14 225 323 14 228 323 minecraft:honeycomb_block
fill 14 225 336 17 267 337 minecraft:yellow_terracotta
setblock 14 225 362 minecraft:yellow_terracotta
fill 14 225 363 14 228 363 minecraft:honeycomb_block
setblock 15 225 361 minecraft:yellow_terracotta
fill 15 225 362 15 228 362 minecraft:honeycomb_block
setblock 16 225 322 minecraft:orange_terracotta
setblock 16 225 324 minecraft:honeycomb_block
fill 16 225 361 16 226 361 minecraft:honeycomb_block
setblock 17 225 324 minecraft:yellow_terracotta
setblock 18 225 323 minecraft:yellow_terracotta
fill 18 225 324 18 228 324 minecraft:honeycomb_block
setblock 18 225 362 minecraft:honeycomb_block
setblock 18 225 363 minecraft:yellow_terracotta
fill 19 225 323 19 228 323 minecraft:honeycomb_block
setblock 19 225 362 minecraft:yellow_terracotta
fill 19 225 363 19 228 363 minecraft:honeycomb_block
fill 20 225 362 20 226 362 minecraft:honeycomb_block
setblock 21 225 324 minecraft:honeycomb_block
setblock 22 225 324 minecraft:yellow_terracotta
setblock 23 225 323 minecraft:yellow_terracotta
setblock 23 225 363 minecraft:yellow_terracotta
fill 24 225 323 24 228 323 minecraft:honeycomb_block
fill 24 225 363 27 225 363 minecraft:honeycomb_block
setblock 24 225 364 minecraft:yellow_concrete
fill 26 225 323 27 225 323 minecraft:honeycomb_block
setblock 27 225 324 minecraft:yellow_terracotta
setblock 28 225 323 minecraft:yellow_terracotta
fill 28 225 324 28 228 324 minecraft:honeycomb_block
setblock 28 225 362 minecraft:honeycomb_block
setblock 28 225 363 minecraft:yellow_terracotta
fill 29 225 323 29 228 323 minecraft:honeycomb_block
setblock 29 225 362 minecraft:yellow_terracotta
fill 29 225 363 29 228 363 minecraft:honeycomb_block
fill 30 225 362 30 228 362 minecraft:honeycomb_block
setblock 31 225 325 minecraft:yellow_terracotta
fill 31 225 361 31 228 361 minecraft:honeycomb_block
setblock 32 225 324 minecraft:yellow_terracotta
fill 32 225 325 35 225 325 minecraft:honeycomb_block
setblock 33 225 323 minecraft:yellow_terracotta
fill 33 225 324 33 228 324 minecraft:honeycomb_block
fill 33 225 360 35 225 360 minecraft:honeycomb_block
setblock 33 225 363 minecraft:yellow_terracotta
fill 34 225 323 34 228 323 minecraft:honeycomb_block
setblock 34 225 362 minecraft:yellow_terracotta
fill 34 225 363 34 228 363 minecraft:honeycomb_block
setblock 35 225 361 minecraft:yellow_terracotta
fill 35 225 362 35 228 362 minecraft:honeycomb_block
setblock 36 225 325 minecraft:yellow_terracotta
fill 36 225 344 39 227 346 minecraft:flowering_azalea_leaves[persistent=true]
setblock 36 225 360 minecraft:yellow_terracotta
fill 36 225 361 36 228 361 minecraft:honeycomb_block
setblock 37 225 324 minecraft:yellow_terracotta
fill 37 225 325 38 227 325 minecraft:honeycomb_block
fill 37 225 360 37 228 360 minecraft:honeycomb_block
setblock 38 225 323 minecraft:yellow_terracotta
fill 38 225 324 38 228 324 minecraft:honeycomb_block
fill 38 225 359 38 226 359 minecraft:honeycomb_block
setblock 38 225 363 minecraft:yellow_terracotta
fill 39 225 323 39 228 323 minecraft:honeycomb_block
setblock 39 225 357 minecraft:yellow_terracotta
fill 39 225 358 39 227 358 minecraft:honeycomb_block
setblock 39 225 362 minecraft:yellow_terracotta
fill 39 225 363 39 228 363 minecraft:honeycomb_block
setblock 40 225 341 minecraft:yellow_terracotta
fill 40 225 342 40 227 343 minecraft:honeycomb_block
setblock 40 225 356 minecraft:yellow_terracotta
fill 40 225 357 40 228 357 minecraft:honeycomb_block
setblock 40 225 361 minecraft:yellow_terracotta
fill 40 225 362 40 228 362 minecraft:honeycomb_block
setblock 41 225 325 minecraft:yellow_terracotta
fill 41 225 326 41 228 326 minecraft:honeycomb_block
setblock 41 225 336 minecraft:honeycomb_block
setblock 41 225 340 minecraft:yellow_terracotta
fill 41 225 341 41 228 341 minecraft:honeycomb_block
setblock 41 225 345 minecraft:yellow_terracotta
fill 41 225 346 41 227 347 minecraft:honeycomb_block
setblock 41 225 351 minecraft:honey_block
setblock 41 225 355 minecraft:yellow_terracotta
fill 41 225 356 41 228 356 minecraft:honeycomb_block
setblock 41 225 360 minecraft:yellow_terracotta
fill 41 225 361 41 228 361 minecraft:honeycomb_block
fill 42 225 340 42 308 340 minecraft:honeycomb_block
fill 42 225 360 42 299 360 minecraft:honeycomb_block
setblock 0 226 327 minecraft:yellow_terracotta
fill 0 226 348 0 265 349 minecraft:honeycomb_block
fill 0 226 358 0 308 358 minecraft:honeycomb_block
setblock 1 226 339 minecraft:yellow_terracotta
fill 1 226 340 1 229 340 minecraft:honeycomb_block
setblock 1 226 344 minecraft:yellow_terracotta
fill 1 226 345 1 229 345 minecraft:honeycomb_block
setblock 1 226 348 minecraft:honeycomb_block
setblock 1 226 349 minecraft:yellow_terracotta
fill 1 226 350 1 229 350 minecraft:honeycomb_block
setblock 1 226 354 minecraft:yellow_terracotta
fill 1 226 355 1 228 355 minecraft:honeycomb_block
setblock 1 226 359 minecraft:yellow_terracotta
fill 1 226 360 1 229 360 minecraft:honeycomb_block
setblock 2 226 323 minecraft:yellow_terracotta
setblock 2 226 339 minecraft:honeycomb_block
setblock 2 226 343 minecraft:yellow_terracotta
fill 2 226 344 2 229 344 minecraft:honeycomb_block
setblock 2 226 347 minecraft:honeycomb_block
setblock 2 226 358 minecraft:yellow_terracotta
fill 2 226 359 2 227 359 minecraft:honeycomb_block
setblock 2 226 363 minecraft:yellow_terracotta
fill 3 226 359 3 227 359 minecraft:brown_terracotta
setblock 3 226 362 minecraft:yellow_terracotta
fill 3 226 363 6 226 363 minecraft:honeycomb_block
fill 4 226 322 4 295 322 minecraft:honeycomb_block
fill 4 226 354 4 227 354 minecraft:yellow_terracotta
fill 4 226 356 4 227 356 minecraft:yellow_terracotta
fill 4 226 358 4 227 358 minecraft:brown_terracotta
fill 4 226 360 4 227 360 minecraft:brown_terracotta
setblock 4 226 362 minecraft:honeycomb_block
fill 5 226 359 5 227 359 minecraft:brown_terracotta
fill 6 226 354 6 227 354 minecraft:yellow_terracotta
fill 6 226 356 6 227 356 minecraft:yellow_terracotta
setblock 7 226 363 minecraft:yellow_terracotta
fill 8 226 323 11 226 323 minecraft:honeycomb_block
setblock 8 226 362 minecraft:yellow_terracotta
fill 8 226 363 11 226 363 minecraft:honeycomb_block
fill 9 226 362 12 226 362 minecraft:honeycomb_block
setblock 11 226 324 minecraft:yellow_terracotta
setblock 12 226 323 minecraft:yellow_terracotta
fill 12 226 324 12 229 324 minecraft:honeycomb_block
setblock 12 226 363 minecraft:yellow_terracotta
fill 13 226 323 13 229 323 minecraft:honeycomb_block
fill 13 226 336 13 267 337 minecraft:yellow_terracotta
setblock 13 226 361 minecraft:honeycomb_block
setblock 13 226 362 minecraft:yellow_terracotta
fill 13 226 363 13 229 363 minecraft:honeycomb_block
setblock 14 226 361 minecraft:yellow_terracotta
fill 14 226 362 14 229 362 minecraft:honeycomb_block
setblock 15 226 361 minecraft:honeycomb_block
fill 16 226 322 16 246 322 minecraft:honeycomb_block
setblock 16 226 324 minecraft:yellow_terracotta
setblock 17 226 323 minecraft:yellow_terracotta
fill 17 226 324 17 229 324 minecraft:honeycomb_block
setblock 17 226 363 minecraft:yellow_terracotta
fill 18 226 323 18 229 323 minecraft:honeycomb_block
setblock 18 226 362 minecraft:yellow_terracotta
fill 18 226 363 18 229 363 minecraft:honeycomb_block
fill 19 226 362 19 227 362 minecraft:honeycomb_block
setblock 21 226 324 minecraft:yellow_terracotta
setblock 22 226 323 minecraft:yellow_terracotta
fill 22 226 324 25 226 324 minecraft:honeycomb_block
setblock 22 226 363 minecraft:yellow_terracotta
fill 23 226 323 23 229 323 minecraft:honeycomb_block
fill 23 226 363 26 226 363 minecraft:honeycomb_block
setblock 24 226 322 minecraft:yellow_terracotta
fill 24 226 364 24 228 364 minecraft:honeycomb_block
setblock 26 226 323 minecraft:honeycomb_block
setblock 26 226 324 minecraft:yellow_terracotta
setblock 27 226 323 minecraft:yellow_terracotta
fill 27 226 324 27 229 324 minecraft:honeycomb_block
setblock 27 226 362 minecraft:honeycomb_block
setblock 27 226 363 minecraft:yellow_terracotta
fill 28 226 323 28 229 323 minecraft:honeycomb_block
setblock 28 226 362 minecraft:yellow_terracotta
fill 28 226 363 28 229 363 minecraft:honeycomb_block
fill 29 226 362 29 229 362 minecraft:honeycomb_block
setblock 30 226 325 minecraft:yellow_terracotta
fill 30 226 361 30 229 361 minecraft:honeycomb_block
setblock 31 226 323 minecraft:honeycomb_block
setblock 31 226 324 minecraft:yellow_terracotta
fill 31 226 325 34 226 325 minecraft:honeycomb_block
setblock 32 226 323 minecraft:yellow_terracotta
fill 32 226 324 32 229 324 minecraft:honeycomb_block
setblock 32 226 363 minecraft:yellow_terracotta
fill 33 226 323 33 229 323 minecraft:honeycomb_block
fill 33 226 360 34 226 360 minecraft:honeycomb_block
setblock 33 226 362 minecraft:yellow_terracotta
fill 33 226 363 33 229 363 minecraft:honeycomb_block
setblock 34 226 361 minecraft:yellow_terracotta
fill 34 226 362 34 229 362 minecraft:honeycomb_block
setblock 35 226 325 minecraft:yellow_terracotta
setblock 35 226 360 minecraft:yellow_terracotta
fill 35 226 361 35 229 361 minecraft:honeycomb_block
setblock 36 226 324 minecraft:yellow_terracotta
fill 36 226 325 36 229 325 minecraft:honeycomb_block
fill 36 226 360 36 228 360 minecraft:honeycomb_block
setblock 37 226 323 minecraft:yellow_terracotta
fill 37 226 324 37 229 324 minecraft:honeycomb_block
fill 37 226 343 38 226 343 minecraft:flowering_azalea_leaves[persistent=true]
fill 37 226 347 38 226 347 minecraft:flowering_azalea_leaves[persistent=true]
setblock 37 226 363 minecraft:yellow_terracotta
fill 38 226 323 38 229 323 minecraft:honeycomb_block
setblock 38 226 362 minecraft:yellow_terracotta
fill 38 226 363 38 229 363 minecraft:honeycomb_block
setblock 39 226 357 minecraft:honeycomb_block
setblock 39 226 361 minecraft:yellow_terracotta
fill 39 226 362 39 229 362 minecraft:honeycomb_block
setblock 40 226 325 minecraft:yellow_terracotta
setblock 40 226 340 minecraft:yellow_terracotta
fill 40 226 341 40 227 341 minecraft:honeycomb_block
setblock 40 226 344 minecraft:honeycomb_block
setblock 40 226 355 minecraft:yellow_terracotta
fill 40 226 356 40 227 356 minecraft:honeycomb_block
setblock 40 226 360 minecraft:yellow_terracotta
fill 40 226 361 40 229 361 minecraft:honeycomb_block
setblock 41 226 324 minecraft:yellow_terracotta
fill 41 226 325 41 229 325 minecraft:honeycomb_block
setblock 41 226 339 minecraft:yellow_terracotta
fill 41 226 340 41 228 340 minecraft:honeycomb_block
setblock 41 226 343 minecraft:honeycomb_block
setblock 41 226 344 minecraft:yellow_terracotta
fill 41 226 345 41 229 345 minecraft:honeycomb_block
setblock 41 226 348 minecraft:honeycomb_block
setblock 41 226 349 minecraft:yellow_terracotta
fill 41 226 350 41 227 351 minecraft:honeycomb_block
setblock 41 226 354 minecraft:yellow_terracotta
fill 41 226 355 41 228 355 minecraft:honeycomb_block
setblock 41 226 359 minecraft:yellow_terracotta
fill 41 226 360 41 229 360 minecraft:honeycomb_block
setblock 42 226 330 minecraft:yellow_concrete
setblock 42 226 347 minecraft:yellow_concrete
fill 0 227 327 0 239 327 minecraft:honeycomb_block
fill 0 227 343 1 227 343 minecraft:yellow_terracotta
setblock 1 227 323 minecraft:yellow_terracotta
fill 1 227 328 1 228 328 minecraft:honey_block
setblock 1 227 338 minecraft:yellow_terracotta
fill 1 227 339 1 229 339 minecraft:honeycomb_block
fill 1 227 344 1 230 344 minecraft:honeycomb_block
setblock 1 227 348 minecraft:yellow_terracotta
fill 1 227 349 1 230 349 minecraft:honeycomb_block
setblock 1 227 353 minecraft:yellow_terracotta
fill 1 227 354 1 228 354 minecraft:honeycomb_block
setblock 1 227 358 minecraft:yellow_terracotta
fill 1 227 359 1 229 359 minecraft:honeycomb_block
setblock 1 227 363 minecraft:yellow_terracotta
setblock 2 227 323 minecraft:honeycomb_block
setblock 2 227 342 minecraft:yellow_terracotta
fill 2 227 343 2 230 343 minecraft:honeycomb_block
setblock 2 227 347 minecraft:yellow_terracotta
setblock 2 227 362 minecraft:yellow_terracotta
fill 2 227 363 5 227 363 minecraft:honeycomb_block
setblock 3 227 358 minecraft:brown_terracotta
setblock 3 227 360 minecraft:brown_terracotta
setblock 3 227 362 minecraft:honeycomb_block
setblock 5 227 358 minecraft:brown_terracotta
setblock 5 227 360 minecraft:brown_terracotta
setblock 6 227 363 minecraft:yellow_terracotta
fill 7 227 323 10 227 323 minecraft:honeycomb_block
fill 7 227 363 10 227 363 minecraft:honeycomb_block
fill 8 227 362 11 227 362 minecraft:honeycomb_block
setblock 10 227 324 minecraft:yellow_terracotta
setblock 11 227 323 minecraft:yellow_terracotta
fill 11 227 324 11 230 324 minecraft:honeycomb_block
setblock 11 227 363 minecraft:yellow_terracotta
fill 12 227 323 12 230 323 minecraft:honeycomb_block
setblock 12 227 362 minecraft:yellow_terracotta
fill 12 227 363 12 230 363 minecraft:honeycomb_block
setblock 13 227 361 minecraft:yellow_terracotta
fill 13 227 362 13 230 362 minecraft:honeycomb_block
setblock 14 227 325 minecraft:yellow_terracotta
setblock 14 227 361 minecraft:honeycomb_block
setblock 15 227 323 minecraft:honeycomb_block
setblock 15 227 324 minecraft:yellow_terracotta
fill 15 227 325 17 228 325 minecraft:honeycomb_block
setblock 16 227 323 minecraft:yellow_terracotta
fill 16 227 324 16 230 324 minecraft:honeycomb_block
setblock 16 227 363 minecraft:yellow_terracotta
fill 17 227 323 17 230 323 minecraft:honeycomb_block
setblock 17 227 362 minecraft:yellow_terracotta
fill 17 227 363 17 230 363 minecraft:honeycomb_block
fill 18 227 362 18 228 362 minecraft:honeycomb_block
setblock 19 227 324 minecraft:honeycomb_block
setblock 20 227 324 minecraft:yellow_terracotta
setblock 21 227 323 minecraft:yellow_terracotta
fill 21 227 324 24 227 324 minecraft:honeycomb_block
setblock 21 227 363 minecraft:yellow_terracotta
fill 22 227 323 22 230 323 minecraft:honeycomb_block
fill 22 227 363 25 227 363 minecraft:honeycomb_block
fill 24 227 322 24 295 322 minecraft:honeycomb_block
setblock 25 227 324 minecraft:yellow_terracotta
setblock 26 227 323 minecraft:yellow_terracotta
fill 26 227 324 26 230 324 minecraft:honeycomb_block
setblock 26 227 363 minecraft:yellow_terracotta
fill 27 227 323 27 230 323 minecraft:honeycomb_block
setblock 27 227 362 minecraft:yellow_terracotta
fill 27 227 363 27 230 363 minecraft:honeycomb_block
fill 28 227 362 28 230 362 minecraft:honeycomb_block
setblock 29 227 324 minecraft:honeycomb_block
setblock 29 227 325 minecraft:yellow_terracotta
setblock 30 227 324 minecraft:yellow_terracotta
fill 30 227 325 33 227 325 minecraft:honeycomb_block
setblock 31 227 323 minecraft:yellow_terracotta
fill 31 227 324 31 230 324 minecraft:honeycomb_block
setblock 31 227 363 minecraft:yellow_terracotta
fill 32 227 323 32 230 323 minecraft:honeycomb_block
setblock 32 227 362 minecraft:yellow_terracotta
fill 32 227 363 32 230 363 minecraft:honeycomb_block
setblock 33 227 360 minecraft:honeycomb_block
setblock 33 227 361 minecraft:yellow_terracotta
fill 33 227 362 33 230 362 minecraft:honeycomb_block
setblock 34 227 325 minecraft:yellow_terracotta
setblock 34 227 360 minecraft:yellow_terracotta
fill 34 227 361 34 230 361 minecraft:honeycomb_block
setblock 35 227 324 minecraft:yellow_terracotta
fill 35 227 325 35 230 325 minecraft:honeycomb_block
fill 35 227 360 35 228 360 minecraft:honeycomb_block
setblock 36 227 323 minecraft:yellow_terracotta
fill 36 227 324 36 230 324 minecraft:honeycomb_block
setblock 36 227 363 minecraft:yellow_terracotta
fill 37 227 323 37 230 323 minecraft:honeycomb_block
setblock 37 227 362 minecraft:yellow_terracotta
fill 37 227 363 37 230 363 minecraft:honeycomb_block
setblock 38 227 361 minecraft:yellow_terracotta
fill 38 227 362 38 230 362 minecraft:honeycomb_block
setblock 39 227 360 minecraft:yellow_terracotta
fill 39 227 361 39 229 361 minecraft:honeycomb_block
setblock 40 227 324 minecraft:yellow_terracotta
fill 40 227 325 40 228 325 minecraft:honeycomb_block
setblock 40 227 344 minecraft:yellow_terracotta
setblock 40 227 345 minecraft:honeycomb_block
setblock 40 227 359 minecraft:yellow_terracotta
fill 40 227 360 40 229 360 minecraft:honeycomb_block
setblock 41 227 323 minecraft:yellow_terracotta
fill 41 227 324 41 230 324 minecraft:honeycomb_block
setblock 41 227 338 minecraft:yellow_terracotta
setblock 41 227 339 minecraft:honeycomb_block
setblock 41 227 343 minecraft:yellow_terracotta
fill 41 227 344 41 230 344 minecraft:honeycomb_block
setblock 41 227 348 minecraft:yellow_terracotta
fill 41 227 349 41 230 349 minecraft:honeycomb_block
setblock 41 227 353 minecraft:yellow_terracotta
fill 41 227 354 41 228 354 minecraft:honeycomb_block
setblock 41 227 358 minecraft:yellow_terracotta
fill 41 227 359 41 230 359 minecraft:honeycomb_block
setblock 41 227 363 minecraft:yellow_terracotta
fill 42 227 330 42 244 330 minecraft:honeycomb_block
setblock 42 227 338 minecraft:yellow_concrete
fill 42 227 347 42 268 347 minecraft:honeycomb_block
fill 0 228 343 1 231 343 minecraft:honeycomb_block
setblock 1 228 323 minecraft:honeycomb_block
setblock 1 228 334 minecraft:honey_block
setblock 1 228 338 minecraft:honeycomb_block
setblock 1 228 342 minecraft:yellow_terracotta
setblock 1 228 346 minecraft:honeycomb_block
setblock 1 228 347 minecraft:yellow_terracotta
fill 1 228 348 2 230 348 minecraft:honeycomb_block
setblock 1 228 352 minecraft:yellow_terracotta
setblock 1 228 353 minecraft:honeycomb_block
setblock 1 228 357 minecraft:yellow_terracotta
fill 1 228 358 1 229 358 minecraft:honeycomb_block
setblock 1 228 362 minecraft:yellow_terracotta
fill 1 228 363 4 228 363 minecraft:honeycomb_block
setblock 2 228 341 minecraft:yellow_terracotta
fill 2 228 342 2 230 342 minecraft:honeycomb_block
setblock 2 228 345 minecraft:honeycomb_block
setblock 2 228 346 minecraft:yellow_terracotta
fill 2 228 347 2 231 347 minecraft:honeycomb_block
setblock 2 228 362 minecraft:honeycomb_block
setblock 5 228 363 minecraft:yellow_terracotta
fill 6 228 323 9 228 323 minecraft:honeycomb_block
fill 6 228 363 9 228 363 minecraft:honeycomb_block
fill 8 228 362 10 228 362 minecraft:honeycomb_block
setblock 10 228 323 minecraft:yellow_terracotta
fill 10 228 324 10 231 324 minecraft:honeycomb_block
setblock 10 228 363 minecraft:yellow_terracotta
fill 11 228 323 11 231 323 minecraft:honeycomb_block
setblock 11 228 362 minecraft:yellow_terracotta
fill 11 228 363 11 231 363 minecraft:honeycomb_block
fill 12 228 362 12 230 362 minecraft:honeycomb_block
setblock 13 228 324 minecraft:honeycomb_block
setblock 13 228 325 minecraft:yellow_terracotta
setblock 14 228 324 minecraft:yellow_terracotta
fill 14 228 325 14 231 325 minecraft:honeycomb_block
setblock 15 228 323 minecraft:yellow_terracotta
fill 15 228 324 15 231 324 minecraft:honeycomb_block
setblock 15 228 363 minecraft:yellow_terracotta
fill 16 228 323 16 231 323 minecraft:honeycomb_block
setblock 16 228 362 minecraft:yellow_terracotta
fill 16 228 363 16 231 363 minecraft:honeycomb_block
setblock 16 228 364 minecraft:yellow_terracotta
setblock 17 228 362 minecraft:honeycomb_block
setblock 18 228 325 minecraft:yellow_terracotta
setblock 19 228 324 minecraft:yellow_terracotta
fill 20 228 322 20 308 322 minecraft:honeycomb_block
setblock 20 228 323 minecraft:yellow_terracotta
fill 20 228 324 23 228 324 minecraft:honeycomb_block
setblock 20 228 363 minecraft:yellow_terracotta
fill 21 228 323 21 231 323 minecraft:honeycomb_block
fill 21 228 363 24 228 363 minecraft:honeycomb_block
setblock 24 228 324 minecraft:yellow_terracotta
fill 25 228 322 25 264 322 minecraft:honeycomb_block
setblock 25 228 323 minecraft:yellow_terracotta
fill 25 228 324 25 231 324 minecraft:honeycomb_block
setblock 25 228 363 minecraft:yellow_terracotta
fill 26 228 323 26 231 323 minecraft:honeycomb_block
fill 26 228 363 26 231 363 minecraft:honeycomb_block
fill 27 228 362 27 231 362 minecraft:honeycomb_block
setblock 28 228 325 minecraft:yellow_terracotta
setblock 29 228 324 minecraft:yellow_terracotta
fill 29 228 325 32 228 325 minecraft:honeycomb_block
setblock 30 228 323 minecraft:yellow_terracotta
fill 30 228 324 30 231 324 minecraft:honeycomb_block
setblock 30 228 363 minecraft:yellow_terracotta
fill 31 228 323 31 231 323 minecraft:honeycomb_block
setblock 31 228 362 minecraft:yellow_terracotta
fill 31 228 363 31 231 363 minecraft:honeycomb_block
setblock 32 228 361 minecraft:yellow_terracotta
fill 32 228 362 32 231 362 minecraft:honeycomb_block
setblock 33 228 325 minecraft:yellow_terracotta
setblock 33 228 360 minecraft:yellow_terracotta
fill 33 228 361 33 231 361 minecraft:honeycomb_block
setblock 34 228 324 minecraft:yellow_terracotta
fill 34 228 325 34 231 325 minecraft:honeycomb_block
setblock 34 228 360 minecraft:honeycomb_block
setblock 35 228 323 minecraft:yellow_terracotta
fill 35 228 324 35 231 324 minecraft:honeycomb_block
setblock 35 228 363 minecraft:yellow_terracotta
fill 36 228 323 36 231 323 minecraft:honeycomb_block
setblock 36 228 362 minecraft:yellow_terracotta
fill 36 228 363 36 231 363 minecraft:honeycomb_block
setblock 37 228 325 minecraft:honeycomb_block
setblock 37 228 361 minecraft:yellow_terracotta
fill 37 228 362 37 231 362 minecraft:honeycomb_block
fill 38 228 361 38 229 361 minecraft:honeycomb_block
setblock 39 228 324 minecraft:yellow_terracotta
setblock 39 228 359 minecraft:yellow_terracotta
setblock 39 228 360 minecraft:honeycomb_block
setblock 40 228 323 minecraft:yellow_terracotta
fill 40 228 324 40 229 324 minecraft:honeycomb_block
setblock 40 228 343 minecraft:yellow_terracotta
setblock 40 228 344 minecraft:honeycomb_block
setblock 40 228 358 minecraft:yellow_terracotta
fill 40 228 359 40 229 359 minecraft:honeycomb_block
setblock 40 228 363 minecraft:yellow_terracotta
setblock 40 228 364 minecraft:yellow_concrete
fill 41 228 323 41 231 323 minecraft:honeycomb_block
setblock 41 228 333 minecraft:honey_block
setblock 41 228 342 minecraft:yellow_terracotta
fill 41 228 343 41 230 343 minecraft:honeycomb_block
setblock 41 228 346 minecraft:honeycomb_block
setblock 41 228 347 minecraft:yellow_terracotta
fill 41 228 348 41 231 348 minecraft:honeycomb_block
fill 41 228 350 41 229 350 minecraft:honeycomb_block
setblock 41 228 352 minecraft:honey_block
setblock 41 228 357 minecraft:yellow_terracotta
fill 41 228 358 41 230 358 minecraft:honeycomb_block
setblock 41 228 362 minecraft:yellow_terracotta
fill 41 228 363 41 231 363 minecraft:honeycomb_block
setblock 42 228 338 minecraft:honeycomb_block
setblock 1 229 341 minecraft:yellow_terracotta
fill 1 229 342 1 232 342 minecraft:honeycomb_block
setblock 1 229 346 minecraft:yellow_terracotta
fill 1 229 347 1 232 347 minecraft:honeycomb_block
setblock 1 229 351 minecraft:yellow_terracotta
setblock 1 229 352 minecraft:honeycomb_block
setblock 1 229 361 minecraft:yellow_terracotta
fill 1 229 362 1 230 363 minecraft:honeycomb_block
setblock 2 229 341 minecraft:honeycomb_block
setblock 2 229 345 minecraft:yellow_terracotta
fill 2 229 346 2 232 346 minecraft:honeycomb_block
fill 2 229 363 3 229 363 minecraft:honeycomb_block
setblock 4 229 363 minecraft:yellow_terracotta
fill 5 229 363 8 229 363 minecraft:honeycomb_block
fill 6 229 323 8 229 323 minecraft:honeycomb_block
setblock 9 229 323 minecraft:yellow_terracotta
fill 9 229 324 9 232 324 minecraft:honeycomb_block
setblock 9 229 362 minecraft:honeycomb_block
setblock 9 229 363 minecraft:yellow_terracotta
fill 10 229 323 10 232 323 minecraft:honeycomb_block
setblock 10 229 362 minecraft:yellow_terracotta
fill 10 229 363 10 232 363 minecraft:honeycomb_block
fill 11 229 362 11 230 362 minecraft:honeycomb_block
setblock 12 229 325 minecraft:yellow_terracotta
setblock 13 229 324 minecraft:yellow_terracotta
fill 13 229 325 13 232 325 minecraft:honeycomb_block
setblock 14 229 323 minecraft:yellow_terracotta
fill 14 229 324 14 232 324 minecraft:honeycomb_block
setblock 14 229 363 minecraft:yellow_terracotta
fill 15 229 323 15 232 323 minecraft:honeycomb_block
fill 15 229 325 16 229 325 minecraft:honeycomb_block
setblock 15 229 362 minecraft:yellow_terracotta
fill 15 229 363 15 232 363 minecraft:honeycomb_block
setblock 16 229 362 minecraft:honeycomb_block
fill 16 229 364 16 278 364 minecraft:honeycomb_block
setblock 17 229 325 minecraft:yellow_terracotta
setblock 18 229 324 minecraft:yellow_terracotta
setblock 19 229 323 minecraft:yellow_terracotta
fill 19 229 324 22 229 324 minecraft:honeycomb_block
setblock 19 229 363 minecraft:yellow_terracotta
fill 20 229 323 20 232 323 minecraft:honeycomb_block
fill 20 229 363 23 229 363 minecraft:honeycomb_block
setblock 23 229 324 minecraft:yellow_terracotta
setblock 24 229 323 minecraft:yellow_terracotta
fill 24 229 324 24 232 324 minecraft:honeycomb_block
setblock 24 229 363 minecraft:yellow_terracotta
setblock 24 229 364 minecraft:orange_terracotta
fill 25 229 323 25 232 323 minecraft:honeycomb_block
fill 25 229 363 25 232 363 minecraft:honeycomb_block
setblock 27 229 325 minecraft:yellow_terracotta
setblock 28 229 324 minecraft:yellow_terracotta
fill 28 229 325 31 229 325 minecraft:honeycomb_block
setblock 29 229 323 minecraft:yellow_terracotta
fill 29 229 324 29 232 324 minecraft:honeycomb_block
setblock 29 229 363 minecraft:yellow_terracotta
fill 30 229 323 30 232 323 minecraft:honeycomb_block
setblock 30 229 362 minecraft:yellow_terracotta
fill 30 229 363 30 232 363 minecraft:honeycomb_block
setblock 31 229 361 minecraft:yellow_terracotta
fill 31 229 362 31 232 362 minecraft:honeycomb_block
setblock 32 229 325 minecraft:yellow_terracotta
fill 32 229 361 32 231 361 minecraft:honeycomb_block
setblock 33 229 324 minecraft:yellow_terracotta
fill 33 229 325 33 232 325 minecraft:honeycomb_block
setblock 34 229 322 minecraft:orange_terracotta
setblock 34 229 323 minecraft:yellow_terracotta
fill 34 229 324 34 232 324 minecraft:honeycomb_block
setblock 34 229 363 minecraft:yellow_terracotta
fill 35 229 323 35 232 323 minecraft:honeycomb_block
setblock 35 229 362 minecraft:yellow_terracotta
fill 35 229 363 35 232 363 minecraft:honeycomb_block
setblock 36 229 361 minecraft:yellow_terracotta
fill 36 229 362 36 232 362 minecraft:honeycomb_block
setblock 37 229 325 minecraft:yellow_terracotta
fill 37 229 361 37 230 361 minecraft:honeycomb_block
setblock 38 229 324 minecraft:yellow_terracotta
setblock 39 229 323 minecraft:yellow_terracotta
fill 39 229 324 39 230 324 minecraft:honeycomb_block
setblock 39 229 363 minecraft:yellow_terracotta
fill 40 229 323 40 232 323 minecraft:honeycomb_block
setblock 40 229 362 minecraft:yellow_terracotta
fill 40 229 363 40 232 364 minecraft:honeycomb_block
setblock 41 229 327 minecraft:honey_block
setblock 41 229 341 minecraft:yellow_terracotta
fill 41 229 342 41 230 342 minecraft:honeycomb_block
setblock 41 229 346 minecraft:yellow_terracotta
fill 41 229 347 41 232 347 minecraft:honeycomb_block
setblock 41 229 356 minecraft:yellow_terracotta
setblock 41 229 357 minecraft:honeycomb_block
setblock 41 229 361 minecraft:yellow_terracotta
fill 41 229 362 41 232 362 minecraft:honeycomb_block
setblock 42 229 338 minecraft:orange_terracotta
setblock 1 230 340 minecraft:yellow_terracotta
fill 1 230 341 1 232 341 minecraft:honeycomb_block
setblock 1 230 345 minecraft:yellow_terracotta
fill 1 230 346 1 233 346 minecraft:honeycomb_block
setblock 1 230 350 minecraft:yellow_terracotta
fill 1 230 351 1 233 351 minecraft:honeycomb_block
setblock 1 230 361 minecraft:honeycomb_block
setblock 2 230 344 minecraft:yellow_terracotta
fill 2 230 345 2 233 345 minecraft:honeycomb_block
setblock 2 230 363 minecraft:honeycomb_block
setblock 3 230 325 minecraft:light[level=12]
setblock 3 230 332 minecraft:light[level=12]
setblock 3 230 339 minecraft:light[level=12]
setblock 3 230 346 minecraft:light[level=12]
setblock 3 230 353 minecraft:light[level=12]
setblock 3 230 360 minecraft:light[level=12]
setblock 3 230 363 minecraft:honey_block
fill 5 230 359 5 234 359 minecraft:brown_terracotta
fill 5 230 363 7 230 363 minecraft:honeycomb_block
setblock 6 230 322 minecraft:orange_terracotta
fill 6 230 323 7 230 323 minecraft:honeycomb_block
setblock 8 230 323 minecraft:yellow_terracotta
setblock 8 230 363 minecraft:yellow_terracotta
fill 9 230 323 9 233 323 minecraft:honeycomb_block
fill 9 230 363 9 233 363 minecraft:honeycomb_block
setblock 10 230 325 minecraft:light[level=12]
setblock 10 230 332 minecraft:light[level=12]
setblock 10 230 346 minecraft:light[level=12]
setblock 10 230 353 minecraft:light[level=12]
setblock 10 230 360 minecraft:light[level=12]
setblock 12 230 324 minecraft:yellow_terracotta
fill 12 230 325 12 233 325 minecraft:honeycomb_block
setblock 13 230 323 minecraft:yellow_terracotta
fill 13 230 324 13 233 324 minecraft:honeycomb_block
setblock 13 230 363 minecraft:yellow_terracotta
fill 14 230 323 14 233 323 minecraft:honeycomb_block
setblock 14 230 362 minecraft:yellow_terracotta
fill 14 230 363 14 232 363 minecraft:honeycomb_block
setblock 15 230 325 minecraft:honeycomb_block
setblock 16 230 325 minecraft:yellow_terracotta
setblock 17 230 324 minecraft:yellow_terracotta
setblock 17 230 325 minecraft:honeycomb_block
setblock 17 230 332 minecraft:light[level=12]
setblock 17 230 339 minecraft:light[level=12]
setblock 17 230 346 minecraft:light[level=12]
setblock 17 230 353 minecraft:light[level=12]
setblock 17 230 360 minecraft:light[level=12]
setblock 18 230 323 minecraft:yellow_terracotta
fill 18 230 324 21 230 324 minecraft:honeycomb_block
setblock 18 230 363 minecraft:yellow_terracotta
fill 19 230 323 19 233 323 minecraft:honeycomb_block
fill 19 230 363 22 230 363 minecraft:honeycomb_block
setblock 22 230 324 minecraft:yellow_terracotta
setblock 23 230 323 minecraft:yellow_terracotta
fill 23 230 324 23 233 324 minecraft:honeycomb_block
setblock 23 230 363 minecraft:yellow_terracotta
fill 24 230 323 24 233 323 minecraft:honeycomb_block
setblock 24 230 325 minecraft:light[level=12]
setblock 24 230 332 minecraft:light[level=12]
setblock 24 230 339 minecraft:light[level=12]
setblock 24 230 346 minecraft:light[level=12]
setblock 24 230 353 minecraft:light[level=12]
setblock 24 230 360 minecraft:light[level=12]
fill 24 230 363 24 231 364 minecraft:honeycomb_block
setblock 27 230 324 minecraft:yellow_terracotta
fill 27 230 325 30 230 325 minecraft:honeycomb_block
setblock 28 230 323 minecraft:yellow_terracotta
fill 28 230 324 28 233 324 minecraft:honeycomb_block
setblock 28 230 363 minecraft:yellow_terracotta
fill 29 230 323 29 233 323 minecraft:honeycomb_block
setblock 29 230 362 minecraft:yellow_terracotta
fill 29 230 363 29 233 363 minecraft:honeycomb_block
setblock 30 230 361 minecraft:yellow_terracotta
fill 30 230 362 30 233 362 minecraft:honeycomb_block
setblock 31 230 325 minecraft:yellow_terracotta
setblock 31 230 332 minecraft:light[level=12]
setblock 31 230 339 minecraft:light[level=12]
setblock 31 230 346 minecraft:light[level=12]
setblock 31 230 353 minecraft:light[level=12]
setblock 31 230 360 minecraft:light[level=12]
fill 31 230 361 31 231 361 minecraft:honeycomb_block
setblock 32 230 324 minecraft:yellow_terracotta
fill 32 230 325 32 233 325 minecraft:honeycomb_block
setblock 33 230 323 minecraft:yellow_terracotta
fill 33 230 324 33 233 324 minecraft:honeycomb_block
setblock 33 230 363 minecraft:yellow_terracotta
fill 34 230 322 34 233 323 minecraft:honeycomb_block
setblock 34 230 362 minecraft:yellow_terracotta
fill 34 230 363 34 233 363 minecraft:honeycomb_block
setblock 35 230 361 minecraft:yellow_terracotta
fill 35 230 362 35 233 362 minecraft:honeycomb_block
setblock 36 230 325 minecraft:yellow_terracotta
setblock 36 230 361 minecraft:honeycomb_block
setblock 37 230 324 minecraft:yellow_terracotta
setblock 38 230 323 minecraft:yellow_terracotta
fill 38 230 324 38 231 324 minecraft:honeycomb_block
setblock 38 230 325 minecraft:light[level=12]
setblock 38 230 332 minecraft:light[level=12]
setblock 38 230 339 minecraft:light[level=12]
setblock 38 230 346 minecraft:light[level=12]
setblock 38 230 353 minecraft:light[level=12]
setblock 38 230 360 minecraft:light[level=12]
setblock 38 230 363 minecraft:yellow_terracotta
fill 39 230 323 39 233 323 minecraft:honeycomb_block
setblock 39 230 362 minecraft:yellow_terracotta
fill 39 230 363 39 233 363 minecraft:honeycomb_block
setblock 40 230 361 minecraft:yellow_terracotta
setblock 40 230 362 minecraft:honeycomb_block
setblock 41 230 325 minecraft:yellow_terracotta
setblock 41 230 340 minecraft:honey_block
setblock 41 230 345 minecraft:yellow_terracotta
fill 41 230 346 41 233 346 minecraft:honeycomb_block
setblock 41 230 350 minecraft:yellow_terracotta
setblock 41 230 360 minecraft:yellow_terracotta
fill 41 230 361 41 231 361 minecraft:honeycomb_block
fill 42 230 338 42 308 338 minecraft:honeycomb_block
setblock 42 230 342 minecraft:orange_terracotta
setblock 42 230 346 minecraft:orange_terracotta
setblock 42 230 363 minecraft:yellow_terracotta
setblock 0 231 336 minecraft:yellow_terracotta
setblock 0 231 337 minecraft:yellow_concrete
setblock 1 231 327 minecraft:honey_block
setblock 1 231 344 minecraft:yellow_terracotta
fill 1 231 345 1 234 345 minecraft:honeycomb_block
setblock 1 231 348 minecraft:honeycomb_block
setblock 1 231 349 minecraft:yellow_terracotta
fill 1 231 350 1 234 350 minecraft:honeycomb_block
setblock 1 231 352 minecraft:honey_block
setblock 2 231 343 minecraft:yellow_terracotta
fill 2 231 344 2 232 344 minecraft:honeycomb_block
setblock 2 231 348 minecraft:yellow_terracotta
fill 6 231 322 6 231 323 minecraft:honeycomb_block
setblock 7 231 323 minecraft:yellow_terracotta
setblock 7 231 363 minecraft:yellow_terracotta
fill 8 231 323 8 233 324 minecraft:honeycomb_block
fill 8 231 363 8 232 363 minecraft:honeycomb_block
setblock 11 231 324 minecraft:yellow_terracotta
fill 11 231 325 11 234 325 minecraft:honeycomb_block
setblock 12 231 323 minecraft:yellow_terracotta
fill 12 231 324 12 234 324 minecraft:honeycomb_block
setblock 12 231 363 minecraft:yellow_terracotta
fill 13 231 323 13 234 323 minecraft:honeycomb_block
fill 13 231 363 13 233 363 minecraft:honeycomb_block
setblock 15 231 325 minecraft:yellow_terracotta
setblock 16 231 324 minecraft:yellow_terracotta
setblock 16 231 325 minecraft:honeycomb_block
setblock 17 231 323 minecraft:yellow_terracotta
fill 17 231 324 20 231 324 minecraft:honeycomb_block
setblock 17 231 363 minecraft:yellow_terracotta
fill 18 231 323 18 234 323 minecraft:honeycomb_block
setblock 21 231 324 minecraft:yellow_terracotta
setblock 22 231 323 minecraft:yellow_terracotta
fill 22 231 324 22 234 324 minecraft:honeycomb_block
fill 23 231 323 23 234 323 minecraft:honeycomb_block
setblock 26 231 324 minecraft:yellow_terracotta
fill 26 231 325 29 231 325 minecraft:honeycomb_block
fill 26 231 340 28 261 343 minecraft:yellow_terracotta
setblock 27 231 323 minecraft:yellow_terracotta
fill 27 231 324 27 234 324 minecraft:honeycomb_block
setblock 27 231 363 minecraft:yellow_terracotta
fill 28 231 323 28 234 323 minecraft:honeycomb_block
setblock 28 231 362 minecraft:yellow_terracotta
fill 28 231 363 28 234 363 minecraft:honeycomb_block
fill 29 231 362 29 234 362 minecraft:honeycomb_block
setblock 30 231 325 minecraft:yellow_terracotta
setblock 31 231 324 minecraft:yellow_terracotta
fill 31 231 325 31 234 325 minecraft:honeycomb_block
setblock 32 231 323 minecraft:yellow_terracotta
fill 32 231 324 32 234 324 minecraft:honeycomb_block
setblock 32 231 363 minecraft:yellow_terracotta
fill 33 231 323 33 234 323 minecraft:honeycomb_block
setblock 33 231 362 minecraft:yellow_terracotta
fill 33 231 363 33 234 363 minecraft:honeycomb_block
setblock 34 231 361 minecraft:yellow_terracotta
fill 34 231 362 34 234 362 minecraft:honeycomb_block
setblock 35 231 325 minecraft:yellow_terracotta
setblock 35 231 361 minecraft:honeycomb_block
setblock 36 231 324 minecraft:yellow_terracotta
setblock 37 231 323 minecraft:yellow_terracotta
fill 37 231 324 37 232 324 minecraft:honeycomb_block
setblock 37 231 363 minecraft:yellow_terracotta
fill 38 231 323 38 234 323 minecraft:honeycomb_block
setblock 38 231 362 minecraft:yellow_terracotta
fill 38 231 363 38 234 363 minecraft:honeycomb_block
setblock 39 231 362 minecraft:honeycomb_block
setblock 41 231 324 minecraft:yellow_terracotta
setblock 41 231 334 minecraft:honey_block
setblock 41 231 344 minecraft:yellow_terracotta
fill 41 231 345 41 234 345 minecraft:honeycomb_block
setblock 41 231 349 minecraft:yellow_terracotta
fill 41 231 350 41 234 350 minecraft:honeycomb_block
setblock 41 231 359 minecraft:honey_block
setblock 41 231 360 minecraft:honeycomb_block
fill 42 231 342 42 264 342 minecraft:honeycomb_block
fill 42 231 346 42 308 346 minecraft:honeycomb_block
fill 42 231 363 42 308 363 minecraft:honeycomb_block
fill 0 232 336 0 268 337 minecraft:honeycomb_block
fill 0 232 343 0 240 343 minecraft:honeycomb_block
setblock 1 232 333 minecraft:honey_block
setblock 1 232 343 minecraft:yellow_terracotta
fill 1 232 344 1 235 344 minecraft:honeycomb_block
setblock 1 232 348 minecraft:yellow_terracotta
fill 1 232 349 1 235 349 minecraft:honeycomb_block
setblock 1 232 358 minecraft:honey_block
setblock 2 232 323 minecraft:honey_block
setblock 2 232 347 minecraft:yellow_terracotta
fill 2 232 348 2 235 348 minecraft:honeycomb_block
setblock 3 232 325 minecraft:light[level=15]
setblock 3 232 333 minecraft:light[level=15]
setblock 3 232 341 minecraft:light[level=15]
setblock 3 232 349 minecraft:light[level=15]
setblock 3 232 357 minecraft:light[level=15]
fill 6 232 322 6 308 322 minecraft:honeycomb_block
setblock 6 232 323 minecraft:yellow_terracotta
fill 7 232 323 7 235 323 minecraft:honeycomb_block
setblock 10 232 322 minecraft:orange_terracotta
setblock 10 232 324 minecraft:yellow_terracotta
setblock 11 232 323 minecraft:yellow_terracotta
fill 11 232 324 11 235 324 minecraft:honeycomb_block
setblock 11 232 333 minecraft:light[level=15]
setblock 11 232 341 minecraft:light[level=15]
setblock 11 232 349 minecraft:light[level=15]
setblock 11 232 357 minecraft:light[level=15]
setblock 11 232 363 minecraft:yellow_terracotta
fill 12 232 323 12 235 323 minecraft:honeycomb_block
fill 12 232 363 12 233 363 minecraft:honeycomb_block
setblock 14 232 325 minecraft:yellow_terracotta
setblock 15 232 324 minecraft:yellow_terracotta
setblock 15 232 325 minecraft:honeycomb_block
setblock 16 232 323 minecraft:yellow_terracotta
fill 16 232 324 19 232 324 minecraft:honeycomb_block
fill 17 232 323 17 235 323 minecraft:honeycomb_block
setblock 19 232 325 minecraft:light[level=15]
setblock 19 232 333 minecraft:light[level=15]
setblock 19 232 341 minecraft:light[level=15]
setblock 19 232 349 minecraft:light[level=15]
setblock 19 232 357 minecraft:light[level=15]
setblock 20 232 324 minecraft:yellow_terracotta
fill 21 232 322 21 232 323 minecraft:yellow_terracotta
fill 21 232 324 21 235 324 minecraft:honeycomb_block
setblock 22 232 322 minecraft:yellow_concrete
fill 22 232 323 22 235 323 minecraft:honeycomb_block
setblock 23 232 364 minecraft:yellow_terracotta
fill 24 232 364 24 256 364 minecraft:honeycomb_block
setblock 25 232 324 minecraft:yellow_terracotta
fill 25 232 340 25 233 343 minecraft:brown_terracotta
setblock 26 232 323 minecraft:yellow_terracotta
fill 26 232 324 26 234 325 minecraft:honeycomb_block
fill 26 232 339 27 233 339 minecraft:brown_terracotta
setblock 26 232 363 minecraft:yellow_terracotta
fill 27 232 323 27 235 323 minecraft:honeycomb_block
fill 27 232 325 28 232 325 minecraft:honeycomb_block
setblock 27 232 333 minecraft:light[level=15]
fill 27 232 344 27 233 344 minecraft:brown_terracotta
setblock 27 232 349 minecraft:light[level=15]
setblock 27 232 357 minecraft:light[level=15]
fill 27 232 363 27 235 363 minecraft:honeycomb_block
fill 28 232 362 28 235 362 minecraft:honeycomb_block
setblock 29 232 325 minecraft:yellow_terracotta
fill 29 232 340 29 233 343 minecraft:brown_terracotta
setblock 30 232 324 minecraft:yellow_terracotta
fill 30 232 325 30 235 325 minecraft:honeycomb_block
setblock 31 232 323 minecraft:yellow_terracotta
fill 31 232 324 31 235 324 minecraft:honeycomb_block
setblock 31 232 363 minecraft:yellow_terracotta
fill 32 232 323 32 235 323 minecraft:honeycomb_block
setblock 32 232 362 minecraft:yellow_terracotta
fill 32 232 363 32 235 363 minecraft:honeycomb_block
fill 33 232 362 33 235 362 minecraft:honeycomb_block
setblock 34 232 325 minecraft:yellow_terracotta
setblock 35 232 324 minecraft:yellow_terracotta
setblock 35 232 325 minecraft:honeycomb_block
setblock 35 232 333 minecraft:light[level=15]
setblock 35 232 341 minecraft:light[level=15]
setblock 35 232 349 minecraft:light[level=15]
setblock 35 232 357 minecraft:light[level=15]
setblock 36 232 323 minecraft:yellow_terracotta
fill 36 232 324 36 234 324 minecraft:honeycomb_block
setblock 36 232 363 minecraft:yellow_terracotta
fill 37 232 323 37 235 323 minecraft:honeycomb_block
setblock 37 232 362 minecraft:yellow_terracotta
fill 37 232 363 37 235 363 minecraft:honeycomb_block
setblock 41 232 328 minecraft:honey_block
setblock 41 232 344 minecraft:honeycomb_block
setblock 41 232 348 minecraft:yellow_terracotta
fill 41 232 349 41 235 349 minecraft:honeycomb_block
setblock 41 232 353 minecraft:honey_block
setblock 41 232 363 minecraft:yellow_terracotta
setblock 1 233 339 minecraft:honey_block
setblock 1 233 342 minecraft:yellow_terracotta
fill 1 233 343 1 236 343 minecraft:honeycomb_block
setblock 1 233 347 minecraft:yellow_terracotta
fill 1 233 348 1 236 348 minecraft:honeycomb_block
setblock 2 233 346 minecraft:yellow_terracotta
fill 2 233 347 2 236 347 minecraft:honeycomb_block
setblock 2 233 363 minecraft:honey_block
fill 4 233 359 4 234 359 minecraft:brown_terracotta
fill 5 233 358 5 234 358 minecraft:brown_terracotta
fill 5 233 360 5 234 360 minecraft:brown_terracotta
fill 6 233 323 6 236 323 minecraft:honeycomb_block
fill 6 233 359 6 234 359 minecraft:brown_terracotta
setblock 9 233 324 minecraft:yellow_terracotta
fill 10 233 322 10 266 322 minecraft:honeycomb_block
setblock 10 233 323 minecraft:yellow_terracotta
fill 10 233 324 10 236 324 minecraft:honeycomb_block
setblock 10 233 363 minecraft:yellow_terracotta
fill 11 233 323 11 236 323 minecraft:honeycomb_block
fill 11 233 363 11 234 363 minecraft:honeycomb_block
setblock 13 233 325 minecraft:yellow_terracotta
setblock 14 233 324 minecraft:yellow_terracotta
setblock 14 233 325 minecraft:honeycomb_block
setblock 15 233 323 minecraft:yellow_terracotta
fill 15 233 324 18 233 324 minecraft:honeycomb_block
fill 16 233 323 16 236 323 minecraft:honeycomb_block
setblock 19 233 324 minecraft:yellow_terracotta
setblock 20 233 323 minecraft:yellow_terracotta
fill 21 233 322 21 236 323 minecraft:honeycomb_block
setblock 21 233 363 minecraft:honey_block
fill 22 233 322 22 283 322 minecraft:honeycomb_block
fill 23 233 364 23 285 364 minecraft:honeycomb_block
setblock 24 233 324 minecraft:yellow_terracotta
fill 24 233 340 24 233 341 minecraft:brown_terracotta
setblock 25 233 323 minecraft:yellow_terracotta
fill 25 233 324 25 236 324 minecraft:honeycomb_block
setblock 25 233 339 minecraft:brown_terracotta
fill 25 233 344 26 233 344 minecraft:brown_terracotta
setblock 25 233 363 minecraft:yellow_terracotta
fill 26 233 323 26 236 323 minecraft:honeycomb_block
fill 26 233 363 26 236 363 minecraft:honeycomb_block
setblock 27 233 325 minecraft:honeycomb_block
setblock 28 233 322 minecraft:yellow_terracotta
setblock 28 233 325 minecraft:yellow_terracotta
fill 28 233 339 29 233 339 minecraft:brown_terracotta
fill 28 233 344 29 233 344 minecraft:brown_terracotta
setblock 29 233 324 minecraft:yellow_terracotta
fill 29 233 325 29 236 325 minecraft:honeycomb_block
setblock 30 233 323 minecraft:yellow_terracotta
fill 30 233 324 30 236 324 minecraft:honeycomb_block
fill 30 233 340 30 233 342 minecraft:brown_terracotta
setblock 30 233 363 minecraft:yellow_terracotta
fill 31 233 323 31 236 323 minecraft:honeycomb_block
setblock 31 233 362 minecraft:yellow_terracotta
fill 31 233 363 31 236 363 minecraft:honeycomb_block
fill 32 233 362 32 236 362 minecraft:honeycomb_block
setblock 33 233 325 minecraft:yellow_terracotta
setblock 34 233 324 minecraft:yellow_terracotta
setblock 34 233 325 minecraft:honeycomb_block
setblock 35 233 323 minecraft:yellow_terracotta
fill 35 233 324 35 235 324 minecraft:honeycomb_block
setblock 35 233 363 minecraft:yellow_terracotta
fill 36 233 323 36 236 323 minecraft:honeycomb_block
setblock 36 233 362 minecraft:yellow_terracotta
fill 36 233 363 36 236 363 minecraft:honeycomb_block
setblock 40 233 323 minecraft:honey_block
setblock 40 233 363 minecraft:yellow_terracotta
fill 40 233 364 40 252 364 minecraft:honeycomb_block
setblock 41 233 347 minecraft:yellow_terracotta
fill 41 233 348 41 236 348 minecraft:honeycomb_block
setblock 41 233 351 minecraft:honeycomb_block
setblock 42 233 348 minecraft:yellow_concrete
fill 42 233 349 42 294 349 minecraft:honeycomb_block
setblock 1 234 326 minecraft:honey_block
setblock 1 234 342 minecraft:honeycomb_block
setblock 1 234 346 minecraft:yellow_terracotta
fill 1 234 347 1 237 347 minecraft:honeycomb_block
setblock 1 234 351 minecraft:yellow_terracotta
setblock 2 234 345 minecraft:yellow_terracotta
fill 2 234 346 2 237 346 minecraft:honeycomb_block
setblock 2 234 349 minecraft:honeycomb_block
setblock 8 234 323 minecraft:honeycomb_block
setblock 8 234 324 minecraft:yellow_terracotta
setblock 8 234 363 minecraft:honey_block
setblock 9 234 323 minecraft:yellow_terracotta
fill 9 234 324 9 237 324 minecraft:honeycomb_block
fill 10 234 323 10 237 323 minecraft:honeycomb_block
fill 10 234 325 10 235 325 minecraft:honeycomb_block
setblock 10 234 363 minecraft:honeycomb_block
setblock 12 234 325 minecraft:yellow_terracotta
setblock 12 234 364 minecraft:yellow_concrete
setblock 13 234 324 minecraft:yellow_terracotta
fill 13 234 325 13 237 325 minecraft:honeycomb_block
setblock 14 234 323 minecraft:yellow_terracotta
fill 14 234 324 17 234 324 minecraft:honeycomb_block
fill 15 234 323 15 237 323 minecraft:honeycomb_block
setblock 18 234 324 minecraft:yellow_terracotta
setblock 19 234 323 minecraft:yellow_terracotta
fill 20 234 323 20 237 323 minecraft:honeycomb_block
setblock 23 234 324 minecraft:yellow_terracotta
setblock 24 234 323 minecraft:yellow_terracotta
fill 24 234 324 24 237 324 minecraft:honeycomb_block
fill 25 234 323 25 237 323 minecraft:honeycomb_block
fill 25 234 325 25 235 325 minecraft:honeycomb_block
fill 25 234 363 25 237 363 minecraft:honeycomb_block
setblock 27 234 325 minecraft:yellow_terracotta
fill 28 234 322 28 262 322 minecraft:honeycomb_block
setblock 28 234 324 minecraft:yellow_terracotta
fill 28 234 325 28 237 325 minecraft:honeycomb_block
setblock 29 234 323 minecraft:yellow_terracotta
fill 29 234 324 29 237 324 minecraft:honeycomb_block
setblock 29 234 363 minecraft:yellow_terracotta
fill 30 234 323 30 237 323 minecraft:honeycomb_block
setblock 30 234 362 minecraft:yellow_terracotta
fill 30 234 363 30 237 363 minecraft:honeycomb_block
fill 31 234 362 31 237 362 minecraft:honeycomb_block
setblock 32 234 325 minecraft:yellow_terracotta
setblock 33 234 324 minecraft:yellow_terracotta
fill 33 234 325 33 235 325 minecraft:honeycomb_block
fill 34 234 322 34 263 322 minecraft:honeycomb_block
setblock 34 234 323 minecraft:yellow_terracotta
fill 34 234 324 34 237 324 minecraft:honeycomb_block
setblock 34 234 363 minecraft:yellow_terracotta
fill 35 234 323 35 237 323 minecraft:honeycomb_block
setblock 35 234 362 minecraft:yellow_terracotta
fill 35 234 363 35 237 363 minecraft:honeycomb_block
setblock 36 234 322 minecraft:orange_terracotta
fill 41 234 335 41 235 335 minecraft:honey_block
setblock 41 234 341 minecraft:honey_block
setblock 41 234 346 minecraft:yellow_terracotta
fill 41 234 347 41 237 347 minecraft:honeycomb_block
setblock 41 234 351 minecraft:yellow_terracotta
fill 41 234 352 41 237 352 minecraft:honeycomb_block
setblock 41 234 360 minecraft:honey_block
fill 42 234 348 42 308 348 minecraft:honeycomb_block
setblock 42 234 352 minecraft:yellow_terracotta
setblock 1 235 332 minecraft:honey_block
setblock 1 235 345 minecraft:yellow_terracotta
fill 1 235 346 1 238 346 minecraft:honeycomb_block
setblock 1 235 350 minecraft:yellow_terracotta
fill 1 235 351 1 237 352 minecraft:honeycomb_block
fill 2 235 345 2 238 345 minecraft:honeycomb_block
setblock 2 235 349 minecraft:yellow_terracotta
fill 2 235 350 2 238 350 minecraft:honeycomb_block
setblock 3 235 323 minecraft:honey_block
fill 5 235 323 5 237 323 minecraft:honeycomb_block
setblock 7 235 324 minecraft:yellow_terracotta
setblock 8 235 323 minecraft:yellow_terracotta
fill 8 235 324 8 238 324 minecraft:honeycomb_block
fill 9 235 323 9 238 323 minecraft:honeycomb_block
fill 9 235 325 9 236 325 minecraft:honeycomb_block
setblock 11 235 325 minecraft:yellow_terracotta
setblock 12 235 324 minecraft:yellow_terracotta
fill 12 235 325 12 238 325 minecraft:honeycomb_block
fill 12 235 364 12 275 364 minecraft:honeycomb_block
setblock 13 235 323 minecraft:yellow_terracotta
fill 13 235 324 16 235 324 minecraft:honeycomb_block
fill 14 235 323 14 238 323 minecraft:honeycomb_block
setblock 14 235 363 minecraft:honey_block
setblock 17 235 324 minecraft:yellow_terracotta
setblock 18 235 323 minecraft:yellow_terracotta
fill 19 235 323 19 238 323 minecraft:honeycomb_block
setblock 22 235 324 minecraft:yellow_terracotta
setblock 23 235 323 minecraft:yellow_terracotta
fill 23 235 324 23 238 324 minecraft:honeycomb_block
fill 24 235 323 24 238 323 minecraft:honeycomb_block
setblock 26 235 324 minecraft:honeycomb_block
setblock 26 235 325 minecraft:yellow_terracotta
setblock 27 235 324 minecraft:yellow_terracotta
fill 27 235 325 27 238 325 minecraft:honeycomb_block
setblock 28 235 323 minecraft:yellow_terracotta
fill 28 235 324 28 238 324 minecraft:honeycomb_block
setblock 28 235 363 minecraft:yellow_terracotta
fill 29 235 323 29 238 323 minecraft:honeycomb_block
setblock 29 235 362 minecraft:yellow_terracotta
fill 29 235 363 29 238 363 minecraft:honeycomb_block
fill 30 235 362 30 238 362 minecraft:honeycomb_block
setblock 31 235 325 minecraft:yellow_terracotta
setblock 32 235 324 minecraft:yellow_terracotta
fill 32 235 325 32 237 325 minecraft:honeycomb_block
setblock 33 235 323 minecraft:yellow_terracotta
fill 33 235 324 33 238 324 minecraft:honeycomb_block
setblock 33 235 363 minecraft:yellow_terracotta
fill 34 235 323 34 238 323 minecraft:honeycomb_block
setblock 34 235 362 minecraft:yellow_terracotta
fill 34 235 363 34 238 363 minecraft:honeycomb_block
fill 36 235 322 36 270 322 minecraft:honeycomb_block
fill 39 235 363 39 236 363 minecraft:honey_block
setblock 41 235 329 minecraft:honey_block
setblock 41 235 345 minecraft:yellow_terracotta
fill 41 235 346 41 238 346 minecraft:honeycomb_block
setblock 41 235 350 minecraft:yellow_terracotta
fill 41 235 351 41 238 351 minecraft:honeycomb_block
fill 41 235 353 41 236 353 minecraft:honeycomb_block
setblock 41 235 354 minecraft:honey_block
fill 42 235 352 42 252 352 minecraft:honeycomb_block
setblock 1 236 338 minecraft:honey_block
fill 1 236 342 1 237 342 minecraft:honeycomb_block
setblock 1 236 344 minecraft:yellow_terracotta
fill 1 236 345 1 239 345 minecraft:honeycomb_block
setblock 1 236 349 minecraft:yellow_terracotta
fill 1 236 350 1 239 350 minecraft:honeycomb_block
setblock 1 236 353 minecraft:honeycomb_block
setblock 1 236 357 minecraft:honey_block
fill 1 236 363 1 237 363 minecraft:honey_block
fill 2 236 344 2 239 344 minecraft:honeycomb_block
setblock 2 236 348 minecraft:yellow_terracotta
fill 2 236 349 2 239 349 minecraft:honeycomb_block
fill 2 236 351 2 237 351 minecraft:honeycomb_block
setblock 3 236 325 minecraft:light[level=12]
setblock 3 236 332 minecraft:light[level=12]
setblock 3 236 339 minecraft:light[level=12]
setblock 3 236 346 minecraft:light[level=12]
setblock 3 236 353 minecraft:light[level=12]
setblock 3 236 360 minecraft:light[level=12]
setblock 6 236 324 minecraft:yellow_terracotta
setblock 7 236 323 minecraft:yellow_terracotta
fill 7 236 324 7 239 324 minecraft:honeycomb_block
fill 8 236 323 8 239 323 minecraft:honeycomb_block
fill 8 236 325 8 237 325 minecraft:honeycomb_block
setblock 10 236 325 minecraft:yellow_terracotta
setblock 10 236 332 minecraft:light[level=12]
setblock 10 236 346 minecraft:light[level=12]
setblock 10 236 353 minecraft:light[level=12]
setblock 10 236 360 minecraft:light[level=12]
setblock 11 236 324 minecraft:yellow_terracotta
fill 11 236 325 11 239 325 minecraft:honeycomb_block
setblock 12 236 323 minecraft:yellow_terracotta
fill 12 236 324 15 236 324 minecraft:honeycomb_block
fill 13 236 323 13 239 323 minecraft:honeycomb_block
setblock 16 236 324 minecraft:yellow_terracotta
setblock 17 236 323 minecraft:yellow_terracotta
fill 17 236 324 17 239 324 minecraft:honeycomb_block
setblock 17 236 325 minecraft:light[level=12]
setblock 17 236 332 minecraft:light[level=12]
setblock 17 236 339 minecraft:light[level=12]
setblock 17 236 346 minecraft:light[level=12]
setblock 17 236 353 minecraft:light[level=12]
setblock 17 236 360 minecraft:light[level=12]
fill 18 236 323 18 239 323 minecraft:honeycomb_block
setblock 20 236 324 minecraft:honeycomb_block
setblock 20 236 363 minecraft:honey_block
setblock 21 236 324 minecraft:yellow_terracotta
setblock 22 236 323 minecraft:yellow_terracotta
fill 22 236 324 22 239 324 minecraft:honeycomb_block
fill 23 236 323 23 239 323 minecraft:honeycomb_block
setblock 24 236 325 minecraft:honeycomb_block
setblock 24 236 332 minecraft:light[level=12]
setblock 24 236 339 minecraft:light[level=12]
setblock 24 236 346 minecraft:light[level=12]
setblock 24 236 353 minecraft:light[level=12]
setblock 24 236 360 minecraft:light[level=12]
fill 24 236 363 24 238 363 minecraft:honeycomb_block
setblock 25 236 325 minecraft:yellow_terracotta
setblock 26 236 324 minecraft:yellow_terracotta
fill 26 236 325 26 239 325 minecraft:honeycomb_block
setblock 27 236 323 minecraft:yellow_terracotta
fill 27 236 324 27 239 324 minecraft:honeycomb_block
setblock 27 236 362 minecraft:honeycomb_block
setblock 27 236 363 minecraft:yellow_terracotta
fill 28 236 323 28 239 323 minecraft:honeycomb_block
setblock 28 236 326 minecraft:honeycomb_block
setblock 28 236 362 minecraft:yellow_terracotta
fill 28 236 363 28 239 363 minecraft:honeycomb_block
fill 29 236 362 29 239 362 minecraft:honeycomb_block
setblock 30 236 325 minecraft:yellow_terracotta
setblock 31 236 324 minecraft:yellow_terracotta
fill 31 236 325 31 239 325 minecraft:honeycomb_block
setblock 31 236 332 minecraft:light[level=12]
setblock 31 236 339 minecraft:light[level=12]
setblock 31 236 346 minecraft:light[level=12]
setblock 31 236 353 minecraft:light[level=12]
setblock 31 236 360 minecraft:light[level=12]
setblock 32 236 323 minecraft:yellow_terracotta
fill 32 236 324 32 239 324 minecraft:honeycomb_block
setblock 32 236 363 minecraft:yellow_terracotta
fill 33 236 323 33 239 323 minecraft:honeycomb_block
setblock 33 236 362 minecraft:yellow_terracotta
fill 33 236 363 33 239 363 minecraft:honeycomb_block
setblock 38 236 325 minecraft:light[level=12]
setblock 38 236 332 minecraft:light[level=12]
setblock 38 236 339 minecraft:light[level=12]
setblock 38 236 346 minecraft:light[level=12]
setblock 38 236 353 minecraft:light[level=12]
setblock 38 236 360 minecraft:light[level=12]
setblock 40 236 349 minecraft:honeycomb_block
setblock 40 236 350 minecraft:yellow_terracotta
setblock 41 236 323 minecraft:honey_block
fill 41 236 345 41 239 345 minecraft:honeycomb_block
setblock 41 236 349 minecraft:yellow_terracotta
fill 41 236 350 41 239 350 minecraft:honeycomb_block
setblock 41 236 354 minecraft:yellow_terracotta
fill 1 237 325 1 238 325 minecraft:honey_block
setblock 1 237 327 minecraft:honeycomb_block
setblock 1 237 328 minecraft:yellow_terracotta
fill 1 237 329 1 239 330 minecraft:honeycomb_block
setblock 1 237 343 minecraft:yellow_terracotta
fill 1 237 344 1 240 344 minecraft:honeycomb_block
setblock 1 237 348 minecraft:yellow_terracotta
fill 1 237 349 1 240 349 minecraft:honeycomb_block
setblock 1 237 353 minecraft:yellow_terracotta
fill 1 237 354 1 240 354 minecraft:honeycomb_block
setblock 2 237 347 minecraft:yellow_terracotta
fill 2 237 348 3 239 348 minecraft:honeycomb_block
setblock 2 237 352 minecraft:yellow_terracotta
setblock 3 237 346 minecraft:yellow_terracotta
fill 3 237 347 3 240 347 minecraft:honeycomb_block
fill 3 237 349 3 237 350 minecraft:honeycomb_block
fill 4 237 323 4 238 323 minecraft:honeycomb_block
setblock 6 237 323 minecraft:yellow_terracotta
fill 6 237 324 6 240 324 minecraft:honeycomb_block
fill 7 237 323 7 240 323 minecraft:honeycomb_block
fill 7 237 325 7 238 325 minecraft:honeycomb_block
setblock 7 237 363 minecraft:honey_block
setblock 9 237 325 minecraft:yellow_terracotta
setblock 10 237 324 minecraft:yellow_terracotta
fill 10 237 325 10 240 325 minecraft:honeycomb_block
setblock 11 237 323 minecraft:yellow_terracotta
fill 11 237 324 14 237 324 minecraft:honeycomb_block
fill 12 237 323 12 240 323 minecraft:honeycomb_block
setblock 15 237 324 minecraft:yellow_terracotta
setblock 16 237 323 minecraft:yellow_terracotta
fill 16 237 324 16 239 324 minecraft:honeycomb_block
fill 17 237 323 17 240 323 minecraft:honeycomb_block
setblock 19 237 324 minecraft:honeycomb_block
setblock 20 237 324 minecraft:yellow_terracotta
fill 21 237 322 21 257 322 minecraft:honeycomb_block
setblock 21 237 323 minecraft:yellow_terracotta
fill 21 237 324 21 240 324 minecraft:honeycomb_block
fill 22 237 323 22 240 323 minecraft:honeycomb_block
setblock 23 237 325 minecraft:honeycomb_block
fill 23 237 363 23 239 363 minecraft:honeycomb_block
setblock 24 237 325 minecraft:yellow_terracotta
setblock 25 237 324 minecraft:yellow_terracotta
fill 25 237 325 25 240 325 minecraft:honeycomb_block
setblock 26 237 323 minecraft:yellow_terracotta
fill 26 237 324 26 240 324 minecraft:honeycomb_block
setblock 26 237 362 minecraft:honeycomb_block
setblock 26 237 363 minecraft:yellow_terracotta
fill 27 237 323 27 240 323 minecraft:honeycomb_block
setblock 27 237 326 minecraft:honeycomb_block
setblock 27 237 362 minecraft:yellow_terracotta
fill 27 237 363 27 240 363 minecraft:honeycomb_block
setblock 28 237 326 minecraft:yellow_terracotta
fill 28 237 336 30 238 336 minecraft:honey_block
fill 28 237 362 28 240 362 minecraft:honeycomb_block
setblock 29 237 325 minecraft:yellow_terracotta
fill 29 237 326 29 238 326 minecraft:honeycomb_block
fill 29 237 335 29 238 335 minecraft:honey_block
fill 29 237 337 29 238 337 minecraft:honey_block
setblock 30 237 324 minecraft:yellow_terracotta
fill 30 237 325 30 240 325 minecraft:honeycomb_block
setblock 30 237 364 minecraft:yellow_concrete
setblock 31 237 323 minecraft:yellow_terracotta
fill 31 237 324 31 240 324 minecraft:honeycomb_block
setblock 31 237 363 minecraft:yellow_terracotta
fill 32 237 323 32 240 323 minecraft:honeycomb_block
setblock 32 237 362 minecraft:yellow_terracotta
fill 32 237 363 32 240 363 minecraft:honeycomb_block
setblock 33 237 362 minecraft:honeycomb_block
setblock 36 237 323 minecraft:yellow_terracotta
setblock 36 237 363 minecraft:yellow_terracotta
setblock 40 237 348 minecraft:honeycomb_block
setblock 40 237 349 minecraft:yellow_terracotta
fill 40 237 350 40 238 352 minecraft:honeycomb_block
setblock 41 237 342 minecraft:honey_block
fill 41 237 344 41 240 344 minecraft:honeycomb_block
setblock 41 237 348 minecraft:yellow_terracotta
fill 41 237 349 41 240 349 minecraft:honeycomb_block
setblock 41 237 353 minecraft:yellow_terracotta
fill 41 237 354 41 238 356 minecraft:honeycomb_block
setblock 41 237 361 minecraft:honey_block
setblock 1 238 326 minecraft:honeycomb_block
setblock 1 238 327 minecraft:yellow_terracotta
fill 1 238 328 2 240 328 minecraft:honeycomb_block
setblock 1 238 331 minecraft:honeycomb_block
setblock 1 238 332 minecraft:yellow_terracotta
fill 1 238 333 1 240 334 minecraft:honeycomb_block
setblock 1 238 341 minecraft:honeycomb_block
setblock 1 238 342 minecraft:yellow_terracotta
fill 1 238 343 2 240 343 minecraft:honeycomb_block
setblock 1 238 347 minecraft:yellow_terracotta
fill 1 238 348 1 241 348 minecraft:honeycomb_block
setblock 1 238 351 minecraft:honeycomb_block
setblock 1 238 352 minecraft:yellow_terracotta
fill 1 238 353 2 240 353 minecraft:honeycomb_block
fill 1 238 355 1 239 355 minecraft:honeycomb_block
fill 2 238 329 2 238 330 minecraft:honeycomb_block
setblock 2 238 331 minecraft:yellow_terracotta
setblock 2 238 346 minecraft:yellow_terracotta
fill 2 238 347 2 241 347 minecraft:honeycomb_block
setblock 2 238 351 minecraft:yellow_terracotta
fill 2 238 352 2 241 352 minecraft:honeycomb_block
fill 3 238 346 3 241 346 minecraft:honeycomb_block
setblock 3 238 349 minecraft:honeycomb_block
setblock 3 238 350 minecraft:yellow_terracotta
schedule function dropper:buildpart/72_9 1t
