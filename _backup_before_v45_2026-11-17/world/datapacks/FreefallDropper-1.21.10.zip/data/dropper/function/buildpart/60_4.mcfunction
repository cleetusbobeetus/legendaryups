setblock 38 204 292 minecraft:light[level=12]
setblock 38 204 299 minecraft:light[level=12]
setblock 38 204 306 minecraft:light[level=12]
setblock 38 204 313 minecraft:light[level=12]
setblock 0 205 280 minecraft:purple_concrete
setblock 0 205 292 minecraft:amethyst_block
fill 0 205 293 0 210 293 minecraft:blackstone
fill 0 205 300 0 219 300 minecraft:blackstone
setblock 0 205 312 minecraft:purple_concrete
fill 0 205 313 0 215 314 minecraft:blackstone
setblock 2 205 285 minecraft:amethyst_block
setblock 2 205 293 minecraft:amethyst_block
setblock 4 205 294 minecraft:nether_wart_block
fill 4 205 295 4 205 297 minecraft:red_nether_bricks
setblock 4 205 298 minecraft:nether_wart_block
fill 4 205 299 4 207 299 minecraft:red_nether_bricks
setblock 5 205 275 minecraft:magma_block
fill 5 205 292 5 205 294 minecraft:red_nether_bricks
setblock 5 205 295 minecraft:nether_wart_block
fill 5 205 296 5 206 297 minecraft:red_nether_bricks
setblock 5 205 298 minecraft:orange_terracotta
setblock 5 205 299 minecraft:nether_wart_block
fill 5 205 300 5 206 301 minecraft:red_nether_bricks
fill 6 205 275 7 216 275 minecraft:blackstone
setblock 6 205 292 minecraft:nether_wart_block
fill 6 205 293 6 206 293 minecraft:red_nether_bricks
setblock 6 205 296 minecraft:nether_wart_block
setblock 6 205 297 minecraft:orange_terracotta
fill 6 205 299 6 205 301 minecraft:orange_terracotta
setblock 7 205 292 minecraft:red_nether_bricks
setblock 7 205 293 minecraft:nether_wart_block
fill 7 205 294 7 206 294 minecraft:red_nether_bricks
setblock 7 205 297 minecraft:nether_wart_block
fill 7 205 299 8 206 299 minecraft:red_nether_bricks
fill 7 205 300 7 206 302 minecraft:orange_terracotta
setblock 8 205 294 minecraft:nether_wart_block
setblock 8 205 295 minecraft:red_nether_bricks
setblock 8 205 298 minecraft:nether_wart_block
fill 8 205 300 8 206 300 minecraft:red_nether_bricks
setblock 11 205 275 minecraft:crying_obsidian
fill 15 205 307 15 206 307 minecraft:amethyst_block
fill 22 205 317 22 220 317 minecraft:blackstone
fill 33 205 317 33 219 317 minecraft:blackstone
setblock 40 205 308 minecraft:amethyst_block
setblock 42 205 283 minecraft:crying_obsidian
fill 42 205 308 42 216 308 minecraft:blackstone
fill 42 205 310 42 219 310 minecraft:blackstone
fill 0 206 280 0 219 280 minecraft:blackstone
fill 0 206 286 0 219 286 minecraft:blackstone
fill 0 206 287 2 206 287 minecraft:amethyst_block
fill 0 206 292 0 219 292 minecraft:blackstone
fill 0 206 312 0 216 312 minecraft:blackstone
setblock 1 206 286 minecraft:amethyst_block
setblock 1 206 288 minecraft:amethyst_block
fill 4 206 295 4 206 296 minecraft:red_nether_bricks
setblock 4 206 297 minecraft:nether_wart_block
fill 4 206 298 4 207 298 minecraft:red_nether_bricks
setblock 4 206 300 minecraft:red_nether_bricks
fill 5 206 275 5 219 275 minecraft:blackstone
setblock 5 206 293 minecraft:red_nether_bricks
setblock 5 206 294 minecraft:nether_wart_block
fill 5 206 295 5 207 295 minecraft:red_nether_bricks
setblock 5 206 298 minecraft:nether_wart_block
fill 5 206 299 5 208 299 minecraft:red_nether_bricks
setblock 5 206 302 minecraft:nether_wart_block
setblock 6 206 294 minecraft:red_nether_bricks
setblock 6 206 295 minecraft:nether_wart_block
fill 6 206 296 6 207 297 minecraft:red_nether_bricks
fill 6 206 298 6 209 298 minecraft:bone_block
setblock 6 206 299 minecraft:nether_wart_block
fill 6 206 300 6 206 302 minecraft:orange_terracotta
setblock 6 206 303 minecraft:nether_wart_block
setblock 7 206 291 minecraft:bone_block
setblock 7 206 296 minecraft:nether_wart_block
fill 7 206 297 7 207 298 minecraft:red_nether_bricks
fill 7 206 303 8 206 303 minecraft:red_nether_bricks
setblock 8 206 296 minecraft:red_nether_bricks
setblock 8 206 297 minecraft:nether_wart_block
fill 8 206 298 8 207 298 minecraft:red_nether_bricks
fill 8 206 301 8 206 302 minecraft:orange_terracotta
fill 8 206 304 8 209 304 minecraft:orange_terracotta
fill 11 206 275 11 216 275 minecraft:blackstone
fill 42 206 283 42 216 283 minecraft:blackstone
fill 42 206 297 42 215 298 minecraft:blackstone
setblock 42 206 299 minecraft:crying_obsidian
fill 42 206 309 42 219 309 minecraft:blackstone
fill 0 207 287 0 215 289 minecraft:blackstone
setblock 0 207 290 minecraft:magma_block
setblock 4 207 297 minecraft:red_nether_bricks
setblock 4 207 300 minecraft:nether_wart_block
setblock 4 207 301 minecraft:red_nether_bricks
setblock 5 207 296 minecraft:red_nether_bricks
setblock 5 207 297 minecraft:nether_wart_block
fill 5 207 298 5 208 298 minecraft:red_nether_bricks
fill 5 207 300 7 207 300 minecraft:red_nether_bricks
setblock 5 207 301 minecraft:nether_wart_block
fill 5 207 302 5 208 303 minecraft:red_nether_bricks
setblock 6 207 295 minecraft:red_nether_bricks
fill 6 207 299 6 209 299 minecraft:red_nether_bricks
fill 6 207 301 7 207 302 minecraft:orange_terracotta
fill 6 207 303 6 208 304 minecraft:red_nether_bricks
setblock 7 207 296 minecraft:red_nether_bricks
setblock 7 207 299 minecraft:nether_wart_block
fill 7 207 303 7 208 304 minecraft:orange_terracotta
fill 7 207 305 7 208 305 minecraft:red_nether_bricks
setblock 8 207 297 minecraft:red_nether_bricks
setblock 8 207 299 minecraft:red_nether_bricks
setblock 8 207 300 minecraft:nether_wart_block
fill 8 207 301 8 208 302 minecraft:red_nether_bricks
fill 8 207 303 9 207 303 minecraft:orange_terracotta
fill 8 207 305 9 209 305 minecraft:orange_terracotta
setblock 9 207 300 minecraft:red_nether_bricks
setblock 9 207 301 minecraft:nether_wart_block
fill 9 207 302 9 209 302 minecraft:red_nether_bricks
fill 9 207 304 9 209 304 minecraft:orange_terracotta
fill 15 207 307 15 217 307 minecraft:blackstone
setblock 36 207 317 minecraft:crying_obsidian
fill 38 207 307 38 211 307 minecraft:blackstone
fill 39 207 306 39 211 306 minecraft:blackstone
fill 39 207 308 39 211 308 minecraft:blackstone
fill 40 207 307 40 211 307 minecraft:blackstone
fill 42 207 299 42 209 299 minecraft:blackstone
fill 0 208 290 0 212 290 minecraft:blackstone
setblock 4 208 300 minecraft:red_nether_bricks
setblock 5 208 297 minecraft:red_nether_bricks
setblock 5 208 300 minecraft:nether_wart_block
fill 5 208 301 5 209 301 minecraft:red_nether_bricks
setblock 6 208 297 minecraft:nether_wart_block
fill 6 208 300 8 208 300 minecraft:red_nether_bricks
setblock 6 208 301 minecraft:nether_wart_block
fill 6 208 302 6 210 302 minecraft:red_nether_bricks
setblock 6 208 305 minecraft:nether_wart_block
setblock 7 208 297 minecraft:red_nether_bricks
setblock 7 208 298 minecraft:nether_wart_block
fill 7 208 299 7 209 299 minecraft:red_nether_bricks
setblock 7 208 301 minecraft:red_nether_bricks
setblock 7 208 302 minecraft:nether_wart_block
setblock 7 208 306 minecraft:nether_wart_block
setblock 8 208 299 minecraft:nether_wart_block
setblock 8 208 303 minecraft:orange_terracotta
setblock 8 208 306 minecraft:red_nether_bricks
fill 9 208 301 9 209 301 minecraft:red_nether_bricks
fill 9 208 303 10 208 303 minecraft:red_nether_bricks
fill 9 208 306 10 209 306 minecraft:orange_terracotta
setblock 9 208 307 minecraft:red_nether_bricks
setblock 10 208 304 minecraft:red_nether_bricks
setblock 10 208 305 minecraft:nether_wart_block
fill 10 208 307 10 210 307 minecraft:orange_terracotta
fill 14 208 307 14 210 307 minecraft:blackstone
fill 15 208 306 15 217 306 minecraft:blackstone
fill 36 208 317 36 217 317 minecraft:blackstone
fill 42 208 287 42 212 287 minecraft:blackstone
setblock 42 208 288 minecraft:amethyst_block
fill 42 208 289 42 219 289 minecraft:blackstone
setblock 5 209 300 minecraft:red_nether_bricks
setblock 5 209 302 minecraft:red_nether_bricks
setblock 5 209 303 minecraft:nether_wart_block
setblock 6 209 300 minecraft:nether_wart_block
fill 6 209 301 6 210 301 minecraft:red_nether_bricks
fill 6 209 303 8 209 303 minecraft:red_nether_bricks
setblock 6 209 304 minecraft:nether_wart_block
fill 6 209 305 6 210 305 minecraft:red_nether_bricks
fill 7 209 300 8 209 300 minecraft:red_nether_bricks
setblock 7 209 301 minecraft:nether_wart_block
fill 7 209 302 7 210 302 minecraft:red_nether_bricks
setblock 7 209 304 minecraft:red_nether_bricks
setblock 7 209 305 minecraft:nether_wart_block
fill 7 209 306 7 211 306 minecraft:red_nether_bricks
setblock 8 209 301 minecraft:red_nether_bricks
setblock 8 209 302 minecraft:nether_wart_block
setblock 8 209 306 minecraft:nether_wart_block
fill 8 209 307 8 211 307 minecraft:red_nether_bricks
setblock 9 209 303 minecraft:nether_wart_block
setblock 9 209 307 minecraft:orange_terracotta
fill 9 209 308 9 211 308 minecraft:red_nether_bricks
setblock 10 209 303 minecraft:red_nether_bricks
setblock 10 209 304 minecraft:nether_wart_block
fill 10 209 305 10 211 305 minecraft:red_nether_bricks
fill 10 209 308 11 210 308 minecraft:orange_terracotta
setblock 11 209 304 minecraft:red_nether_bricks
setblock 11 209 305 minecraft:nether_wart_block
fill 11 209 306 11 210 307 minecraft:orange_terracotta
fill 12 209 307 12 210 307 minecraft:orange_terracotta
fill 14 209 306 14 217 306 minecraft:blackstone
fill 14 209 308 15 210 308 minecraft:blackstone
fill 16 209 306 16 217 307 minecraft:blackstone
fill 38 209 306 38 211 306 minecraft:blackstone
fill 38 209 308 38 211 308 minecraft:blackstone
fill 40 209 306 40 211 306 minecraft:blackstone
fill 40 209 308 40 211 308 minecraft:blackstone
setblock 42 209 281 minecraft:magma_block
fill 42 209 288 42 219 288 minecraft:blackstone
fill 3 210 278 3 211 278 minecraft:light[level=12]
setblock 3 210 285 minecraft:light[level=12]
setblock 3 210 292 minecraft:light[level=12]
setblock 3 210 299 minecraft:light[level=12]
setblock 3 210 306 minecraft:light[level=12]
setblock 3 210 313 minecraft:light[level=12]
setblock 6 210 303 minecraft:nether_wart_block
setblock 6 210 304 minecraft:red_nether_bricks
setblock 7 210 301 minecraft:red_nether_bricks
fill 7 210 303 9 210 303 minecraft:red_nether_bricks
setblock 7 210 304 minecraft:nether_wart_block
fill 7 210 305 7 211 305 minecraft:red_nether_bricks
setblock 8 210 301 minecraft:nether_wart_block
setblock 8 210 302 minecraft:red_nether_bricks
fill 8 210 304 10 210 304 minecraft:red_nether_bricks
fill 8 210 305 9 213 305 minecraft:bone_block
fill 8 210 306 8 212 306 minecraft:red_nether_bricks
setblock 8 210 308 minecraft:red_nether_bricks
setblock 9 210 302 minecraft:nether_wart_block
setblock 9 210 306 minecraft:nether_wart_block
fill 9 210 307 9 212 307 minecraft:red_nether_bricks
setblock 10 210 278 minecraft:light[level=12]
setblock 10 210 285 minecraft:light[level=12]
setblock 10 210 292 minecraft:light[level=12]
setblock 10 210 299 minecraft:light[level=12]
setblock 10 210 303 minecraft:nether_wart_block
setblock 10 210 306 minecraft:orange_terracotta
fill 10 210 309 11 211 309 minecraft:red_nether_bricks
setblock 10 210 313 minecraft:light[level=12]
setblock 11 210 304 minecraft:nether_wart_block
fill 11 210 305 11 212 305 minecraft:red_nether_bricks
setblock 12 210 305 minecraft:nether_wart_block
fill 12 210 306 12 212 306 minecraft:red_nether_bricks
fill 12 210 308 13 211 309 minecraft:orange_terracotta
fill 13 210 307 13 212 307 minecraft:red_nether_bricks
fill 15 210 305 15 217 305 minecraft:blackstone
fill 16 210 308 16 212 308 minecraft:blackstone
setblock 17 210 278 minecraft:light[level=12]
setblock 17 210 285 minecraft:light[level=12]
setblock 17 210 292 minecraft:light[level=12]
setblock 17 210 299 minecraft:light[level=12]
setblock 17 210 306 minecraft:light[level=12]
setblock 17 210 313 minecraft:light[level=12]
setblock 24 210 278 minecraft:light[level=12]
setblock 24 210 285 minecraft:light[level=12]
setblock 24 210 292 minecraft:light[level=12]
setblock 24 210 299 minecraft:light[level=12]
setblock 24 210 306 minecraft:light[level=12]
setblock 24 210 313 minecraft:light[level=12]
setblock 31 210 278 minecraft:light[level=12]
setblock 31 210 285 minecraft:light[level=12]
setblock 31 210 292 minecraft:light[level=12]
setblock 31 210 299 minecraft:light[level=12]
setblock 31 210 306 minecraft:light[level=12]
setblock 31 210 313 minecraft:light[level=12]
setblock 38 210 278 minecraft:light[level=12]
setblock 38 210 285 minecraft:light[level=12]
setblock 38 210 292 minecraft:light[level=12]
setblock 38 210 299 minecraft:light[level=12]
setblock 38 210 313 minecraft:light[level=12]
fill 42 210 281 42 220 281 minecraft:blackstone
setblock 42 210 299 minecraft:crying_obsidian
setblock 0 211 293 minecraft:crying_obsidian
setblock 3 211 286 minecraft:light[level=12]
setblock 3 211 294 minecraft:light[level=12]
setblock 3 211 302 minecraft:light[level=12]
setblock 3 211 310 minecraft:light[level=12]
setblock 7 211 303 minecraft:nether_wart_block
setblock 7 211 304 minecraft:red_nether_bricks
fill 8 211 303 9 211 303 minecraft:red_nether_bricks
setblock 8 211 304 minecraft:nether_wart_block
setblock 8 211 308 minecraft:nether_wart_block
fill 9 211 304 11 211 304 minecraft:red_nether_bricks
fill 9 211 306 9 213 306 minecraft:red_nether_bricks
setblock 9 211 309 minecraft:nether_wart_block
setblock 10 211 306 minecraft:nether_wart_block
fill 10 211 307 10 212 308 minecraft:red_nether_bricks
setblock 11 211 278 minecraft:light[level=12]
setblock 11 211 286 minecraft:light[level=12]
setblock 11 211 294 minecraft:light[level=12]
setblock 11 211 302 minecraft:light[level=12]
setblock 11 211 306 minecraft:red_nether_bricks
setblock 11 211 307 minecraft:orange_terracotta
fill 11 211 308 11 213 308 minecraft:red_nether_bricks
fill 11 211 310 12 211 310 minecraft:red_nether_bricks
setblock 12 211 305 minecraft:red_nether_bricks
setblock 12 211 307 minecraft:red_nether_bricks
fill 13 211 306 13 212 306 minecraft:red_nether_bricks
fill 13 211 310 14 212 310 minecraft:orange_terracotta
fill 14 211 305 14 217 305 minecraft:blackstone
fill 14 211 307 14 213 307 minecraft:red_nether_bricks
fill 14 211 308 14 211 309 minecraft:orange_terracotta
setblock 15 211 308 minecraft:blackstone
fill 15 211 309 15 211 310 minecraft:red_nether_bricks
fill 16 211 305 16 217 305 minecraft:blackstone
setblock 16 211 309 minecraft:blackstone
fill 17 211 306 17 213 308 minecraft:blackstone
setblock 19 211 278 minecraft:light[level=12]
setblock 19 211 286 minecraft:light[level=12]
setblock 19 211 294 minecraft:light[level=12]
setblock 19 211 302 minecraft:light[level=12]
setblock 19 211 310 minecraft:light[level=12]
setblock 27 211 278 minecraft:light[level=12]
setblock 27 211 286 minecraft:light[level=12]
setblock 27 211 294 minecraft:light[level=12]
setblock 27 211 302 minecraft:light[level=12]
setblock 27 211 310 minecraft:light[level=12]
setblock 35 211 278 minecraft:light[level=12]
setblock 35 211 286 minecraft:light[level=12]
setblock 35 211 294 minecraft:light[level=12]
setblock 35 211 302 minecraft:light[level=12]
setblock 35 211 310 minecraft:light[level=12]
fill 42 211 299 42 215 299 minecraft:blackstone
fill 0 212 293 0 217 293 minecraft:blackstone
setblock 8 212 304 minecraft:red_nether_bricks
setblock 8 212 307 minecraft:nether_wart_block
setblock 9 212 304 minecraft:nether_wart_block
setblock 9 212 308 minecraft:nether_wart_block
setblock 9 212 309 minecraft:red_nether_bricks
setblock 10 212 304 minecraft:red_nether_bricks
setblock 10 212 305 minecraft:nether_wart_block
fill 10 212 306 10 213 306 minecraft:red_nether_bricks
setblock 10 212 309 minecraft:nether_wart_block
setblock 11 212 306 minecraft:nether_wart_block
fill 11 212 307 11 214 307 minecraft:red_nether_bricks
setblock 11 212 309 minecraft:red_nether_bricks
setblock 11 212 310 minecraft:nether_wart_block
setblock 12 212 275 minecraft:purple_concrete
setblock 12 212 307 minecraft:nether_wart_block
fill 12 212 308 12 214 308 minecraft:red_nether_bricks
fill 12 212 309 15 212 309 minecraft:orange_terracotta
setblock 12 212 310 minecraft:red_nether_bricks
setblock 12 212 311 minecraft:nether_wart_block
fill 13 212 305 13 217 305 minecraft:blackstone
setblock 13 212 308 minecraft:orange_terracotta
fill 13 212 311 14 212 311 minecraft:red_nether_bricks
fill 14 212 308 15 212 308 minecraft:red_nether_bricks
fill 15 212 304 15 217 304 minecraft:blackstone
fill 15 212 310 17 213 311 minecraft:orange_terracotta
setblock 16 212 309 minecraft:red_nether_bricks
fill 17 212 305 17 217 305 minecraft:blackstone
setblock 0 213 290 minecraft:amethyst_block
setblock 9 213 307 minecraft:nether_wart_block
setblock 9 213 308 minecraft:red_nether_bricks
setblock 10 213 307 minecraft:red_nether_bricks
setblock 10 213 308 minecraft:nether_wart_block
setblock 10 213 309 minecraft:red_nether_bricks
setblock 11 213 306 minecraft:red_nether_bricks
setblock 11 213 309 minecraft:nether_wart_block
fill 11 213 310 11 214 310 minecraft:red_nether_bricks
fill 12 213 275 12 219 275 minecraft:blackstone
setblock 12 213 306 minecraft:nether_wart_block
fill 12 213 307 12 214 307 minecraft:red_nether_bricks
fill 12 213 309 13 213 309 minecraft:red_nether_bricks
setblock 12 213 310 minecraft:nether_wart_block
fill 12 213 311 12 214 311 minecraft:red_nether_bricks
fill 13 213 306 13 217 306 minecraft:blackstone
setblock 13 213 307 minecraft:nether_wart_block
fill 13 213 308 13 215 308 minecraft:red_nether_bricks
fill 13 213 310 14 213 310 minecraft:red_nether_bricks
setblock 13 213 311 minecraft:nether_wart_block
fill 14 213 304 14 217 304 minecraft:blackstone
setblock 14 213 308 minecraft:nether_wart_block
fill 14 213 309 14 216 309 minecraft:bone_block
setblock 14 213 311 minecraft:red_nether_bricks
setblock 14 213 312 minecraft:nether_wart_block
fill 15 213 308 16 213 308 minecraft:red_nether_bricks
setblock 15 213 309 minecraft:nether_wart_block
fill 15 213 312 16 213 312 minecraft:red_nether_bricks
fill 15 213 317 15 219 317 minecraft:blackstone
fill 16 213 304 16 217 304 minecraft:blackstone
setblock 16 213 309 minecraft:orange_terracotta
setblock 16 213 317 minecraft:crying_obsidian
fill 17 213 309 17 214 309 minecraft:red_nether_bricks
setblock 17 213 312 minecraft:orange_terracotta
fill 17 213 317 17 219 317 minecraft:blackstone
fill 18 213 306 18 217 308 minecraft:blackstone
fill 18 213 310 18 214 311 minecraft:orange_terracotta
setblock 18 213 312 minecraft:nether_wart_block
setblock 39 213 275 minecraft:magma_block
setblock 42 213 287 minecraft:magma_block
fill 0 214 290 0 216 290 minecraft:blackstone
setblock 11 214 308 minecraft:nether_wart_block
setblock 11 214 309 minecraft:red_nether_bricks
fill 12 214 305 12 217 306 minecraft:blackstone
setblock 12 214 309 minecraft:nether_wart_block
setblock 12 214 310 minecraft:red_nether_bricks
fill 13 214 304 13 217 304 minecraft:blackstone
setblock 13 214 307 minecraft:red_nether_bricks
setblock 13 214 309 minecraft:red_nether_bricks
setblock 13 214 310 minecraft:nether_wart_block
fill 13 214 311 13 215 311 minecraft:red_nether_bricks
setblock 14 214 307 minecraft:nether_wart_block
fill 14 214 308 14 215 308 minecraft:red_nether_bricks
fill 14 214 310 14 216 310 minecraft:bone_block
setblock 14 214 311 minecraft:nether_wart_block
fill 14 214 312 14 215 312 minecraft:red_nether_bricks
setblock 15 214 308 minecraft:nether_wart_block
fill 15 214 309 15 214 311 minecraft:red_nether_bricks
setblock 15 214 312 minecraft:nether_wart_block
fill 16 214 308 17 214 308 minecraft:red_nether_bricks
setblock 16 214 309 minecraft:nether_wart_block
fill 16 214 310 17 214 311 minecraft:orange_terracotta
fill 16 214 312 18 214 312 minecraft:red_nether_bricks
fill 16 214 317 16 219 317 minecraft:blackstone
fill 17 214 304 17 217 304 minecraft:blackstone
fill 17 214 306 17 217 307 minecraft:blackstone
fill 17 214 313 18 214 313 minecraft:red_nether_bricks
fill 18 214 305 18 217 305 minecraft:blackstone
fill 18 214 309 19 215 309 minecraft:red_nether_bricks
fill 19 214 310 20 215 312 minecraft:orange_terracotta
fill 21 214 311 21 216 311 minecraft:orange_terracotta
fill 39 214 275 39 217 275 minecraft:blackstone
fill 42 214 287 42 216 287 minecraft:blackstone
fill 11 215 305 11 217 308 minecraft:blackstone
fill 12 215 304 12 217 304 minecraft:blackstone
fill 12 215 307 12 217 308 minecraft:blackstone
setblock 12 215 309 minecraft:red_nether_bricks
fill 12 215 310 12 217 310 minecraft:blackstone
fill 13 215 303 16 217 303 minecraft:blackstone
fill 13 215 307 14 217 307 minecraft:blackstone
setblock 13 215 309 minecraft:nether_wart_block
setblock 13 215 310 minecraft:red_nether_bricks
fill 14 215 311 14 216 311 minecraft:red_nether_bricks
fill 15 215 308 15 215 310 minecraft:red_nether_bricks
setblock 15 215 311 minecraft:nether_wart_block
fill 15 215 312 15 216 312 minecraft:red_nether_bricks
setblock 16 215 308 minecraft:nether_wart_block
fill 16 215 309 16 215 311 minecraft:red_nether_bricks
setblock 16 215 312 minecraft:nether_wart_block
setblock 16 215 313 minecraft:red_nether_bricks
setblock 17 215 308 minecraft:red_nether_bricks
setblock 17 215 309 minecraft:nether_wart_block
fill 17 215 310 17 215 312 minecraft:red_nether_bricks
setblock 17 215 313 minecraft:nether_wart_block
fill 18 215 304 18 217 304 minecraft:blackstone
setblock 18 215 310 minecraft:nether_wart_block
fill 18 215 311 18 215 313 minecraft:red_nether_bricks
fill 19 215 306 19 217 308 minecraft:blackstone
fill 19 215 313 20 216 313 minecraft:red_nether_bricks
fill 20 215 309 20 217 309 minecraft:red_nether_bricks
setblock 21 215 310 minecraft:orange_terracotta
fill 21 215 312 21 216 312 minecraft:orange_terracotta
setblock 21 215 313 minecraft:nether_wart_block
setblock 22 215 310 minecraft:nether_wart_block
fill 22 215 311 22 215 312 minecraft:red_nether_bricks
fill 23 215 311 23 217 311 minecraft:orange_terracotta
setblock 31 215 275 minecraft:amethyst_block
setblock 0 216 275 minecraft:blackstone
setblock 0 216 276 minecraft:deepslate_tiles
setblock 0 216 287 minecraft:deepslate_tiles
fill 0 216 288 0 219 288 minecraft:blackstone
fill 0 216 289 0 217 289 minecraft:deepslate_tiles
setblock 0 216 305 minecraft:amethyst_block
fill 0 216 313 0 219 313 minecraft:blackstone
setblock 0 216 314 minecraft:deepslate_tiles
setblock 0 216 316 minecraft:purple_concrete
fill 0 216 317 0 219 317 minecraft:blackstone
setblock 3 216 275 minecraft:deepslate_tiles
setblock 3 216 278 minecraft:light[level=12]
setblock 3 216 285 minecraft:light[level=12]
setblock 3 216 292 minecraft:light[level=12]
setblock 3 216 299 minecraft:light[level=12]
setblock 3 216 306 minecraft:light[level=12]
setblock 3 216 313 minecraft:light[level=12]
setblock 4 216 317 minecraft:crying_obsidian
setblock 10 216 278 minecraft:light[level=12]
setblock 10 216 285 minecraft:light[level=12]
setblock 10 216 292 minecraft:light[level=12]
setblock 10 216 299 minecraft:light[level=12]
setblock 10 216 306 minecraft:light[level=12]
setblock 10 216 313 minecraft:light[level=12]
fill 11 216 304 11 217 304 minecraft:blackstone
fill 11 216 309 13 217 309 minecraft:blackstone
fill 12 216 303 12 217 303 minecraft:blackstone
fill 13 216 308 17 217 308 minecraft:blackstone
fill 13 216 310 13 217 311 minecraft:blackstone
fill 15 216 309 17 216 309 minecraft:red_nether_bricks
setblock 15 216 310 minecraft:nether_wart_block
setblock 15 216 311 minecraft:red_nether_bricks
setblock 16 216 275 minecraft:deepslate_tiles
fill 16 216 310 18 216 310 minecraft:red_nether_bricks
setblock 16 216 311 minecraft:nether_wart_block
setblock 16 216 312 minecraft:red_nether_bricks
setblock 17 216 278 minecraft:light[level=12]
setblock 17 216 285 minecraft:light[level=12]
setblock 17 216 292 minecraft:light[level=12]
setblock 17 216 299 minecraft:light[level=12]
fill 17 216 303 17 217 303 minecraft:blackstone
fill 17 216 311 19 216 311 minecraft:red_nether_bricks
setblock 17 216 312 minecraft:nether_wart_block
setblock 17 216 313 minecraft:red_nether_bricks
setblock 18 216 309 minecraft:nether_wart_block
fill 18 216 312 19 216 312 minecraft:red_nether_bricks
setblock 18 216 313 minecraft:nether_wart_block
fill 19 216 305 19 217 305 minecraft:blackstone
setblock 19 216 309 minecraft:red_nether_bricks
setblock 19 216 310 minecraft:nether_wart_block
fill 20 216 310 21 216 310 minecraft:red_nether_bricks
fill 20 216 311 20 216 312 minecraft:orange_terracotta
fill 21 216 309 21 218 309 minecraft:red_nether_bricks
fill 21 216 313 21 218 313 minecraft:red_nether_bricks
setblock 21 216 317 minecraft:deepslate_tiles
setblock 22 216 275 minecraft:deepslate_tiles
setblock 22 216 309 minecraft:nether_wart_block
fill 22 216 310 22 216 312 minecraft:orange_terracotta
setblock 22 216 313 minecraft:nether_wart_block
fill 23 216 310 24 217 310 minecraft:orange_terracotta
fill 23 216 312 24 217 312 minecraft:orange_terracotta
setblock 23 216 313 minecraft:red_nether_bricks
setblock 24 216 278 minecraft:light[level=12]
setblock 24 216 285 minecraft:light[level=12]
setblock 24 216 292 minecraft:light[level=12]
setblock 24 216 299 minecraft:light[level=12]
setblock 24 216 306 minecraft:light[level=12]
fill 24 216 311 25 217 311 minecraft:orange_terracotta
setblock 24 216 313 minecraft:light[level=12]
setblock 25 216 317 minecraft:deepslate_tiles
fill 26 216 317 28 219 317 minecraft:blackstone
fill 31 216 275 31 219 275 minecraft:blackstone
setblock 31 216 278 minecraft:light[level=12]
setblock 31 216 285 minecraft:light[level=12]
setblock 31 216 292 minecraft:light[level=12]
setblock 31 216 299 minecraft:light[level=12]
setblock 31 216 306 minecraft:light[level=12]
setblock 31 216 313 minecraft:light[level=12]
setblock 38 216 278 minecraft:light[level=12]
setblock 38 216 285 minecraft:light[level=12]
setblock 38 216 292 minecraft:light[level=12]
setblock 38 216 299 minecraft:light[level=12]
setblock 38 216 306 minecraft:light[level=12]
setblock 38 216 313 minecraft:light[level=12]
fill 40 216 317 40 217 317 minecraft:deepslate_tiles
fill 41 216 317 42 217 317 minecraft:blackstone
setblock 42 216 278 minecraft:deepslate_tiles
setblock 42 216 297 minecraft:deepslate_tiles
setblock 42 216 298 minecraft:blackstone
setblock 42 216 299 minecraft:deepslate_tiles
setblock 42 216 312 minecraft:deepslate_tiles
setblock 42 216 316 minecraft:deepslate_tiles
fill 0 217 275 1 217 275 minecraft:deepslate_tiles
fill 0 217 276 0 219 276 minecraft:blackstone
setblock 0 217 284 minecraft:deepslate_tiles
fill 0 217 287 0 219 287 minecraft:blackstone
setblock 0 217 290 minecraft:deepslate_tiles
setblock 0 217 302 minecraft:deepslate_tiles
fill 0 217 303 0 219 303 minecraft:blackstone
setblock 0 217 305 minecraft:blackstone
setblock 0 217 309 minecraft:deepslate_tiles
fill 0 217 310 0 219 310 minecraft:blackstone
fill 0 217 312 0 218 312 minecraft:deepslate_tiles
fill 0 217 314 0 219 314 minecraft:blackstone
fill 0 217 316 0 219 316 minecraft:blackstone
fill 3 217 275 3 219 275 minecraft:blackstone
setblock 3 217 317 minecraft:deepslate_tiles
fill 4 217 317 4 219 317 minecraft:blackstone
setblock 6 217 275 minecraft:deepslate_tiles
fill 6 217 317 6 218 317 minecraft:deepslate_tiles
fill 7 217 275 7 219 275 minecraft:blackstone
setblock 9 217 275 minecraft:deepslate_tiles
fill 10 217 305 10 217 309 minecraft:blackstone
fill 10 217 317 10 219 317 minecraft:blackstone
setblock 11 217 275 minecraft:deepslate_tiles
setblock 11 217 310 minecraft:blackstone
fill 11 217 317 13 217 317 minecraft:deepslate_tiles
setblock 12 217 311 minecraft:blackstone
fill 13 217 302 17 217 302 minecraft:blackstone
setblock 14 217 275 minecraft:deepslate_tiles
fill 14 217 309 15 217 312 minecraft:blackstone
fill 16 217 275 16 219 275 minecraft:blackstone
fill 16 217 309 17 217 309 minecraft:blackstone
setblock 16 217 310 minecraft:nether_wart_block
setblock 16 217 311 minecraft:red_nether_bricks
setblock 16 217 312 minecraft:blackstone
fill 17 217 310 19 217 310 minecraft:red_nether_bricks
setblock 17 217 311 minecraft:nether_wart_block
setblock 17 217 312 minecraft:red_nether_bricks
setblock 18 217 303 minecraft:blackstone
setblock 18 217 309 minecraft:red_nether_bricks
fill 18 217 311 19 217 311 minecraft:red_nether_bricks
setblock 18 217 312 minecraft:nether_wart_block
setblock 18 217 313 minecraft:red_nether_bricks
setblock 19 217 304 minecraft:blackstone
setblock 19 217 309 minecraft:nether_wart_block
fill 19 217 312 21 217 312 minecraft:red_nether_bricks
setblock 19 217 313 minecraft:nether_wart_block
fill 20 217 306 20 217 308 minecraft:blackstone
setblock 20 217 310 minecraft:nether_wart_block
fill 20 217 311 21 220 311 minecraft:bone_block
setblock 20 217 313 minecraft:red_nether_bricks
fill 21 217 310 22 217 310 minecraft:red_nether_bricks
fill 21 217 317 21 219 317 minecraft:blackstone
fill 22 217 275 22 219 275 minecraft:blackstone
fill 22 217 309 22 219 309 minecraft:red_nether_bricks
setblock 22 217 311 minecraft:orange_terracotta
setblock 22 217 312 minecraft:nether_wart_block
fill 22 217 313 22 219 313 minecraft:red_nether_bricks
setblock 23 217 309 minecraft:nether_wart_block
setblock 23 217 313 minecraft:nether_wart_block
fill 24 217 309 25 217 309 minecraft:red_nether_bricks
setblock 24 217 313 minecraft:red_nether_bricks
fill 25 217 310 27 218 310 minecraft:orange_terracotta
fill 25 217 312 25 219 312 minecraft:red_nether_bricks
fill 25 217 317 25 219 317 minecraft:blackstone
fill 26 217 311 26 219 311 minecraft:orange_terracotta
setblock 26 217 312 minecraft:nether_wart_block
setblock 36 217 275 minecraft:deepslate_tiles
fill 37 217 275 37 219 275 minecraft:blackstone
setblock 38 217 317 minecraft:deepslate_tiles
fill 39 217 317 39 219 317 minecraft:blackstone
fill 42 217 278 42 219 278 minecraft:blackstone
setblock 42 217 283 minecraft:crying_obsidian
setblock 42 217 285 minecraft:deepslate_tiles
setblock 42 217 287 minecraft:deepslate_tiles
fill 42 217 291 42 217 292 minecraft:deepslate_tiles
fill 42 217 293 42 219 293 minecraft:blackstone
setblock 42 217 294 minecraft:deepslate_tiles
fill 42 217 297 42 219 297 minecraft:blackstone
fill 42 217 298 42 218 298 minecraft:deepslate_tiles
setblock 42 217 299 minecraft:blackstone
fill 42 217 306 42 217 308 minecraft:deepslate_tiles
fill 42 217 312 42 219 312 minecraft:blackstone
setblock 42 217 316 minecraft:blackstone
fill 0 218 275 1 219 275 minecraft:blackstone
fill 0 218 284 0 219 284 minecraft:blackstone
fill 0 218 289 0 219 290 minecraft:blackstone
setblock 0 218 293 minecraft:deepslate_tiles
fill 0 218 302 0 219 302 minecraft:blackstone
setblock 0 218 305 minecraft:deepslate_tiles
setblock 0 218 307 minecraft:deepslate_tiles
setblock 0 218 309 minecraft:crying_obsidian
setblock 0 218 311 minecraft:deepslate_tiles
setblock 3 218 278 minecraft:light[level=12]
setblock 3 218 286 minecraft:light[level=12]
setblock 3 218 294 minecraft:light[level=12]
setblock 3 218 302 minecraft:light[level=12]
setblock 3 218 310 minecraft:light[level=12]
fill 3 218 317 3 219 317 minecraft:blackstone
fill 6 218 275 6 219 275 minecraft:blackstone
fill 9 218 275 9 219 275 minecraft:blackstone
fill 11 218 275 11 219 275 minecraft:blackstone
setblock 11 218 278 minecraft:light[level=12]
setblock 11 218 286 minecraft:light[level=12]
setblock 11 218 294 minecraft:light[level=12]
setblock 11 218 302 minecraft:light[level=12]
setblock 11 218 310 minecraft:light[level=12]
fill 11 218 317 13 219 317 minecraft:blackstone
fill 14 218 275 14 219 275 minecraft:blackstone
fill 14 218 306 15 218 307 minecraft:amethyst_block
setblock 15 218 308 minecraft:amethyst_block
setblock 16 218 307 minecraft:amethyst_block
setblock 18 218 275 minecraft:deepslate_tiles
fill 18 218 310 20 218 310 minecraft:red_nether_bricks
setblock 18 218 311 minecraft:nether_wart_block
setblock 18 218 312 minecraft:red_nether_bricks
setblock 19 218 278 minecraft:light[level=12]
setblock 19 218 286 minecraft:light[level=12]
setblock 19 218 294 minecraft:light[level=12]
setblock 19 218 302 minecraft:light[level=12]
setblock 19 218 311 minecraft:red_nether_bricks
setblock 19 218 312 minecraft:nether_wart_block
setblock 19 218 317 minecraft:deepslate_tiles
setblock 20 218 309 minecraft:nether_wart_block
fill 20 218 312 22 218 312 minecraft:red_nether_bricks
setblock 20 218 313 minecraft:nether_wart_block
setblock 21 218 310 minecraft:nether_wart_block
fill 22 218 310 24 218 310 minecraft:red_nether_bricks
setblock 22 218 311 minecraft:nether_wart_block
fill 23 218 309 23 219 309 minecraft:red_nether_bricks
setblock 23 218 311 minecraft:red_nether_bricks
setblock 23 218 312 minecraft:nether_wart_block
fill 23 218 313 23 219 313 minecraft:red_nether_bricks
setblock 24 218 309 minecraft:nether_wart_block
setblock 24 218 311 minecraft:orange_terracotta
setblock 24 218 312 minecraft:red_nether_bricks
setblock 24 218 313 minecraft:nether_wart_block
setblock 25 218 309 minecraft:red_nether_bricks
fill 25 218 311 25 220 311 minecraft:red_nether_bricks
setblock 25 218 313 minecraft:red_nether_bricks
fill 26 218 309 28 218 309 minecraft:orange_terracotta
fill 26 218 312 26 220 312 minecraft:red_nether_bricks
setblock 27 218 278 minecraft:light[level=12]
setblock 27 218 286 minecraft:light[level=12]
setblock 27 218 294 minecraft:light[level=12]
setblock 27 218 302 minecraft:light[level=12]
fill 27 218 311 27 219 311 minecraft:orange_terracotta
setblock 27 218 312 minecraft:nether_wart_block
fill 28 218 310 28 219 310 minecraft:orange_terracotta
setblock 28 218 311 minecraft:red_nether_bricks
setblock 29 218 275 minecraft:deepslate_tiles
setblock 34 218 317 minecraft:magma_block
setblock 35 218 278 minecraft:light[level=12]
setblock 35 218 286 minecraft:light[level=12]
setblock 35 218 294 minecraft:light[level=12]
setblock 35 218 302 minecraft:light[level=12]
setblock 35 218 310 minecraft:light[level=12]
fill 36 218 275 36 219 275 minecraft:blackstone
setblock 36 218 317 minecraft:deepslate_tiles
fill 38 218 275 39 218 275 minecraft:deepslate_tiles
fill 38 218 317 38 219 317 minecraft:blackstone
fill 40 218 317 40 219 317 minecraft:blackstone
setblock 41 218 317 minecraft:deepslate_tiles
fill 42 218 282 42 218 283 minecraft:deepslate_tiles
fill 42 218 285 42 219 285 minecraft:blackstone
setblock 42 218 286 minecraft:deepslate_tiles
fill 42 218 287 42 219 287 minecraft:blackstone
fill 42 218 291 42 219 292 minecraft:blackstone
fill 42 218 294 42 219 294 minecraft:blackstone
setblock 42 218 295 minecraft:deepslate_tiles
setblock 42 218 299 minecraft:deepslate_tiles
setblock 42 218 304 minecraft:deepslate_tiles
fill 42 218 306 42 219 308 minecraft:blackstone
setblock 42 218 316 minecraft:deepslate_tiles
fill 42 218 317 42 219 317 minecraft:blackstone
setblock 0 219 293 minecraft:blackstone
setblock 0 219 305 minecraft:blackstone
setblock 0 219 307 minecraft:blackstone
fill 0 219 309 0 220 309 minecraft:blackstone
fill 0 219 311 0 219 312 minecraft:blackstone
setblock 6 219 317 minecraft:blackstone
fill 14 219 307 15 219 307 minecraft:amethyst_block
setblock 15 219 306 minecraft:amethyst_block
setblock 18 219 275 minecraft:blackstone
setblock 19 219 317 minecraft:blackstone
fill 20 219 310 21 219 310 minecraft:red_nether_bricks
setblock 20 219 312 minecraft:nether_wart_block
fill 21 219 312 23 219 312 minecraft:red_nether_bricks
setblock 21 219 313 minecraft:nether_wart_block
setblock 22 219 310 minecraft:nether_wart_block
fill 22 219 311 22 220 311 minecraft:red_nether_bricks
fill 23 219 310 25 219 310 minecraft:red_nether_bricks
setblock 23 219 311 minecraft:nether_wart_block
fill 24 219 309 24 220 309 minecraft:red_nether_bricks
setblock 24 219 311 minecraft:red_nether_bricks
setblock 24 219 312 minecraft:nether_wart_block
fill 24 219 313 24 220 313 minecraft:red_nether_bricks
fill 25 219 308 27 219 308 minecraft:red_nether_bricks
setblock 25 219 309 minecraft:nether_wart_block
setblock 25 219 313 minecraft:nether_wart_block
setblock 26 219 309 minecraft:red_nether_bricks
fill 26 219 310 27 219 310 minecraft:orange_terracotta
setblock 26 219 313 minecraft:red_nether_bricks
fill 27 219 309 30 219 309 minecraft:orange_terracotta
fill 27 219 312 27 221 312 minecraft:red_nether_bricks
setblock 28 219 308 minecraft:nether_wart_block
setblock 28 219 311 minecraft:orange_terracotta
setblock 28 219 312 minecraft:nether_wart_block
fill 29 219 275 29 220 275 minecraft:blackstone
fill 29 219 308 30 221 308 minecraft:orange_terracotta
fill 29 219 310 29 219 311 minecraft:red_nether_bricks
setblock 30 219 310 minecraft:nether_wart_block
setblock 34 219 317 minecraft:blackstone
setblock 36 219 317 minecraft:blackstone
fill 38 219 275 39 219 275 minecraft:blackstone
setblock 41 219 317 minecraft:blackstone
setblock 42 219 277 minecraft:purple_concrete
fill 42 219 282 42 219 283 minecraft:blackstone
setblock 42 219 286 minecraft:blackstone
setblock 42 219 295 minecraft:blackstone
fill 42 219 298 42 219 299 minecraft:blackstone
fill 42 219 304 42 220 304 minecraft:blackstone
setblock 42 219 316 minecraft:blackstone
fill 0 220 275 0 222 275 minecraft:blackstone
fill 0 220 276 0 220 297 minecraft:deepslate_tiles
setblock 0 220 298 minecraft:blackstone
fill 0 220 299 0 220 308 minecraft:deepslate_tiles
fill 0 220 310 0 240 317 minecraft:deepslate_tiles
fill 1 220 275 28 220 275 minecraft:deepslate_tiles
fill 1 220 317 21 220 317 minecraft:deepslate_tiles
fill 15 220 307 15 222 307 minecraft:amethyst_block
setblock 22 220 310 minecraft:red_nether_bricks
fill 22 220 312 24 220 312 minecraft:red_nether_bricks
setblock 23 220 310 minecraft:nether_wart_block
setblock 23 220 311 minecraft:red_nether_bricks
fill 23 220 317 42 220 317 minecraft:deepslate_tiles
fill 24 220 310 26 220 310 minecraft:red_nether_bricks
setblock 24 220 311 minecraft:nether_wart_block
setblock 25 220 308 minecraft:nether_wart_block
fill 25 220 309 25 221 309 minecraft:red_nether_bricks
setblock 25 220 312 minecraft:nether_wart_block
setblock 25 220 313 minecraft:red_nether_bricks
fill 26 220 308 28 220 308 minecraft:red_nether_bricks
setblock 26 220 309 minecraft:nether_wart_block
fill 26 220 311 27 221 311 minecraft:red_nether_bricks
fill 27 220 309 28 220 309 minecraft:red_nether_bricks
setblock 27 220 310 minecraft:orange_terracotta
setblock 28 220 307 minecraft:nether_wart_block
setblock 28 220 310 minecraft:red_nether_bricks
setblock 28 220 311 minecraft:nether_wart_block
fill 28 220 312 28 221 312 minecraft:red_nether_bricks
setblock 29 220 307 minecraft:red_nether_bricks
fill 29 220 309 29 220 310 minecraft:orange_terracotta
fill 29 220 311 30 220 311 minecraft:red_nether_bricks
fill 30 220 275 34 223 275 minecraft:deepslate_tiles
fill 30 220 307 31 221 307 minecraft:orange_terracotta
fill 30 220 309 31 221 309 minecraft:orange_terracotta
fill 30 220 310 30 222 310 minecraft:red_nether_bricks
fill 31 220 308 31 221 308 minecraft:orange_terracotta
setblock 31 220 310 minecraft:nether_wart_block
fill 36 220 275 41 308 275 minecraft:deepslate_tiles
fill 42 220 276 42 221 276 minecraft:deepslate_tiles
setblock 42 220 277 minecraft:magma_block
fill 42 220 278 42 308 280 minecraft:deepslate_tiles
fill 42 220 282 42 294 283 minecraft:deepslate_tiles
setblock 42 220 284 minecraft:purple_concrete
fill 42 220 285 42 235 289 minecraft:deepslate_tiles
fill 42 220 291 42 220 303 minecraft:deepslate_tiles
fill 42 220 305 42 220 316 minecraft:deepslate_tiles
fill 0 221 276 0 221 285 minecraft:deepslate_tiles
setblock 0 221 286 minecraft:blackstone
fill 0 221 287 0 221 293 minecraft:deepslate_tiles
setblock 0 221 294 minecraft:blackstone
fill 0 221 295 0 221 302 minecraft:deepslate_tiles
setblock 0 221 303 minecraft:blackstone
fill 0 221 304 0 286 309 minecraft:deepslate_tiles
fill 1 221 275 14 221 275 minecraft:deepslate_tiles
fill 1 221 317 20 221 317 minecraft:deepslate_tiles
setblock 15 221 275 minecraft:blackstone
fill 16 221 275 29 224 275 minecraft:deepslate_tiles
setblock 21 221 317 minecraft:magma_block
fill 22 221 317 29 221 317 minecraft:deepslate_tiles
setblock 24 221 310 minecraft:nether_wart_block
fill 24 221 311 24 221 312 minecraft:red_nether_bricks
fill 25 221 310 26 221 310 minecraft:red_nether_bricks
setblock 25 221 311 minecraft:nether_wart_block
setblock 25 221 312 minecraft:red_nether_bricks
setblock 26 221 308 minecraft:nether_wart_block
fill 26 221 309 26 222 309 minecraft:red_nether_bricks
setblock 26 221 312 minecraft:nether_wart_block
fill 27 221 308 28 221 308 minecraft:red_nether_bricks
setblock 27 221 309 minecraft:nether_wart_block
fill 27 221 310 28 223 310 minecraft:bone_block
fill 28 221 307 28 222 307 minecraft:red_nether_bricks
setblock 28 221 309 minecraft:red_nether_bricks
fill 28 221 311 28 222 311 minecraft:red_nether_bricks
fill 29 221 306 30 221 306 minecraft:red_nether_bricks
setblock 29 221 307 minecraft:nether_wart_block
setblock 29 221 309 minecraft:orange_terracotta
setblock 29 221 310 minecraft:red_nether_bricks
setblock 29 221 311 minecraft:nether_wart_block
setblock 30 221 311 minecraft:red_nether_bricks
setblock 30 221 317 minecraft:blackstone
fill 31 221 306 33 222 306 minecraft:orange_terracotta
fill 31 221 310 31 223 310 minecraft:red_nether_bricks
fill 31 221 317 34 283 317 minecraft:deepslate_tiles
fill 32 221 307 33 222 307 minecraft:orange_terracotta
fill 32 221 308 32 221 309 minecraft:red_nether_bricks
fill 33 221 305 33 223 305 minecraft:orange_terracotta
fill 33 221 308 33 223 308 minecraft:red_nether_bricks
fill 35 221 275 35 224 275 minecraft:deepslate_tiles
setblock 35 221 317 minecraft:blackstone
fill 36 221 317 42 221 317 minecraft:deepslate_tiles
setblock 42 221 277 minecraft:deepslate_tiles
fill 42 221 281 42 308 281 minecraft:deepslate_tiles
setblock 42 221 284 minecraft:deepslate_tiles
fill 42 221 291 42 240 298 minecraft:deepslate_tiles
setblock 42 221 299 minecraft:blackstone
fill 42 221 300 42 221 306 minecraft:deepslate_tiles
setblock 42 221 307 minecraft:blackstone
fill 42 221 308 42 221 311 minecraft:deepslate_tiles
setblock 42 221 312 minecraft:blackstone
fill 42 221 313 42 221 316 minecraft:deepslate_tiles
fill 0 222 276 0 308 276 minecraft:deepslate_tiles
setblock 0 222 277 minecraft:blackstone
fill 0 222 278 0 223 291 minecraft:deepslate_tiles
setblock 0 222 292 minecraft:blackstone
fill 0 222 293 0 248 294 minecraft:deepslate_tiles
fill 0 222 295 0 222 296 minecraft:blackstone
fill 0 222 297 0 254 298 minecraft:deepslate_tiles
setblock 0 222 299 minecraft:blackstone
fill 0 222 300 0 247 300 minecraft:deepslate_tiles
fill 0 222 301 0 222 302 minecraft:blackstone
fill 0 222 303 0 235 303 minecraft:deepslate_tiles
fill 1 222 275 7 229 275 minecraft:deepslate_tiles
fill 1 222 317 10 285 317 minecraft:deepslate_tiles
setblock 3 222 278 minecraft:light[level=12]
setblock 3 222 285 minecraft:light[level=12]
setblock 3 222 292 minecraft:light[level=12]
setblock 3 222 299 minecraft:light[level=12]
setblock 3 222 306 minecraft:light[level=12]
setblock 3 222 313 minecraft:light[level=12]
setblock 8 222 275 minecraft:blackstone
fill 9 222 275 15 228 275 minecraft:deepslate_tiles
setblock 10 222 278 minecraft:light[level=12]
setblock 10 222 285 minecraft:light[level=12]
setblock 10 222 292 minecraft:light[level=12]
setblock 10 222 299 minecraft:light[level=12]
setblock 10 222 306 minecraft:light[level=12]
setblock 10 222 313 minecraft:light[level=12]
setblock 11 222 317 minecraft:blackstone
fill 12 222 317 14 281 317 minecraft:deepslate_tiles
fill 15 222 317 16 222 317 minecraft:blackstone
setblock 17 222 278 minecraft:light[level=12]
setblock 17 222 285 minecraft:light[level=12]
setblock 17 222 292 minecraft:light[level=12]
setblock 17 222 299 minecraft:light[level=12]
setblock 17 222 306 minecraft:light[level=12]
setblock 17 222 313 minecraft:light[level=12]
fill 17 222 317 21 235 317 minecraft:deepslate_tiles
setblock 22 222 317 minecraft:blackstone
fill 23 222 317 30 258 317 minecraft:deepslate_tiles
setblock 24 222 278 minecraft:light[level=12]
setblock 24 222 285 minecraft:light[level=12]
setblock 24 222 292 minecraft:light[level=12]
setblock 24 222 299 minecraft:light[level=12]
setblock 24 222 306 minecraft:light[level=12]
setblock 24 222 313 minecraft:light[level=12]
setblock 26 222 310 minecraft:red_nether_bricks
setblock 26 222 311 minecraft:nether_wart_block
setblock 27 222 308 minecraft:nether_wart_block
fill 27 222 309 27 223 309 minecraft:red_nether_bricks
setblock 27 222 311 minecraft:red_nether_bricks
fill 28 222 308 30 222 308 minecraft:red_nether_bricks
setblock 28 222 309 minecraft:nether_wart_block
setblock 29 222 306 minecraft:nether_wart_block
fill 29 222 307 29 224 307 minecraft:red_nether_bricks
fill 29 222 309 31 222 309 minecraft:red_nether_bricks
setblock 29 222 310 minecraft:nether_wart_block
setblock 29 222 311 minecraft:red_nether_bricks
setblock 30 222 306 minecraft:red_nether_bricks
setblock 30 222 307 minecraft:nether_wart_block
setblock 30 222 311 minecraft:nether_wart_block
setblock 31 222 278 minecraft:light[level=12]
setblock 31 222 285 minecraft:light[level=12]
setblock 31 222 292 minecraft:light[level=12]
setblock 31 222 299 minecraft:light[level=12]
fill 31 222 305 31 224 305 minecraft:red_nether_bricks
setblock 31 222 307 minecraft:orange_terracotta
setblock 31 222 308 minecraft:nether_wart_block
setblock 31 222 313 minecraft:light[level=12]
fill 32 222 304 34 222 304 minecraft:red_nether_bricks
fill 32 222 305 32 223 305 minecraft:orange_terracotta
setblock 32 222 308 minecraft:red_nether_bricks
setblock 32 222 309 minecraft:nether_wart_block
setblock 33 222 309 minecraft:red_nether_bricks
fill 34 222 305 34 222 306 minecraft:orange_terracotta
setblock 34 222 307 minecraft:nether_wart_block
fill 35 222 317 40 226 317 minecraft:deepslate_tiles
setblock 38 222 278 minecraft:light[level=12]
setblock 38 222 285 minecraft:light[level=12]
setblock 38 222 292 minecraft:light[level=12]
setblock 38 222 299 minecraft:light[level=12]
setblock 38 222 306 minecraft:light[level=12]
setblock 38 222 313 minecraft:light[level=12]
setblock 41 222 317 minecraft:blackstone
fill 42 222 275 42 308 275 minecraft:deepslate_tiles
fill 42 222 276 42 222 277 minecraft:blackstone
setblock 42 222 284 minecraft:blackstone
fill 42 222 290 42 276 290 minecraft:deepslate_tiles
fill 42 222 299 42 242 301 minecraft:deepslate_tiles
setblock 42 222 302 minecraft:blackstone
fill 42 222 303 42 235 309 minecraft:deepslate_tiles
setblock 42 222 310 minecraft:blackstone
fill 42 222 311 42 233 313 minecraft:deepslate_tiles
setblock 42 222 314 minecraft:blackstone
fill 42 222 315 42 223 317 minecraft:deepslate_tiles
fill 0 223 275 0 308 275 minecraft:deepslate_tiles
fill 0 223 277 0 227 277 minecraft:deepslate_tiles
fill 0 223 292 0 308 292 minecraft:deepslate_tiles
fill 0 223 295 0 271 296 minecraft:deepslate_tiles
fill 0 223 299 0 308 299 minecraft:deepslate_tiles
fill 0 223 301 0 258 302 minecraft:deepslate_tiles
fill 8 223 275 8 308 275 minecraft:deepslate_tiles
fill 11 223 317 11 291 317 minecraft:deepslate_tiles
fill 15 223 317 16 225 317 minecraft:deepslate_tiles
fill 22 223 317 22 308 317 minecraft:deepslate_tiles
setblock 28 223 308 minecraft:nether_wart_block
setblock 28 223 309 minecraft:red_nether_bricks
setblock 29 223 306 minecraft:red_nether_bricks
fill 29 223 308 31 223 308 minecraft:red_nether_bricks
setblock 29 223 309 minecraft:nether_wart_block
setblock 29 223 310 minecraft:red_nether_bricks
setblock 30 223 305 minecraft:red_nether_bricks
setblock 30 223 306 minecraft:nether_wart_block
fill 30 223 307 30 224 307 minecraft:red_nether_bricks
fill 30 223 309 32 223 309 minecraft:red_nether_bricks
setblock 30 223 310 minecraft:nether_wart_block
fill 31 223 304 31 225 304 minecraft:red_nether_bricks
setblock 31 223 306 minecraft:red_nether_bricks
setblock 31 223 307 minecraft:nether_wart_block
setblock 32 223 304 minecraft:nether_wart_block
fill 32 223 306 33 223 306 minecraft:orange_terracotta
fill 32 223 307 34 223 307 minecraft:red_nether_bricks
setblock 32 223 308 minecraft:nether_wart_block
fill 33 223 303 35 223 304 minecraft:orange_terracotta
setblock 33 223 309 minecraft:nether_wart_block
fill 34 223 302 35 225 302 minecraft:orange_terracotta
fill 34 223 305 35 223 305 minecraft:red_nether_bricks
setblock 34 223 306 minecraft:nether_wart_block
fill 34 223 308 34 224 308 minecraft:red_nether_bricks
setblock 35 223 306 minecraft:red_nether_bricks
fill 41 223 317 41 308 317 minecraft:deepslate_tiles
fill 42 223 276 42 308 277 minecraft:deepslate_tiles
fill 42 223 284 42 308 284 minecraft:deepslate_tiles
fill 42 223 302 42 267 302 minecraft:deepslate_tiles
fill 42 223 310 42 308 310 minecraft:deepslate_tiles
fill 42 223 314 42 308 314 minecraft:deepslate_tiles
fill 0 224 278 0 291 287 minecraft:deepslate_tiles
setblock 0 224 288 minecraft:magma_block
fill 0 224 289 0 235 291 minecraft:deepslate_tiles
setblock 27 224 310 minecraft:bone_block
fill 27 224 315 27 227 315 minecraft:amethyst_block
setblock 29 224 308 minecraft:nether_wart_block
setblock 29 224 309 minecraft:red_nether_bricks
fill 30 224 275 33 224 275 minecraft:deepslate_tiles
setblock 30 224 306 minecraft:red_nether_bricks
fill 30 224 308 32 224 308 minecraft:red_nether_bricks
setblock 30 224 309 minecraft:nether_wart_block
setblock 31 224 306 minecraft:nether_wart_block
fill 31 224 307 31 225 307 minecraft:red_nether_bricks
fill 31 224 309 32 224 309 minecraft:red_nether_bricks
setblock 32 224 303 minecraft:nether_wart_block
fill 32 224 304 32 224 306 minecraft:red_nether_bricks
setblock 32 224 307 minecraft:nether_wart_block
fill 33 224 276 34 226 276 minecraft:amethyst_block
fill 33 224 302 33 224 303 minecraft:red_nether_bricks
fill 33 224 304 35 224 304 minecraft:orange_terracotta
fill 33 224 305 33 227 306 minecraft:bone_block
fill 33 224 307 34 224 307 minecraft:red_nether_bricks
setblock 33 224 308 minecraft:nether_wart_block
fill 34 224 275 34 225 275 minecraft:amethyst_block
setblock 34 224 301 minecraft:nether_wart_block
fill 34 224 303 36 224 303 minecraft:orange_terracotta
setblock 34 224 305 minecraft:nether_wart_block
fill 34 224 306 34 226 306 minecraft:red_nether_bricks
fill 35 224 300 36 226 300 minecraft:orange_terracotta
fill 35 224 301 36 224 301 minecraft:red_nether_bricks
fill 35 224 305 36 224 305 minecraft:red_nether_bricks
setblock 35 224 306 minecraft:nether_wart_block
setblock 36 224 302 minecraft:orange_terracotta
fill 36 224 304 36 226 304 minecraft:red_nether_bricks
setblock 42 224 315 minecraft:magma_block
fill 42 224 316 42 268 317 minecraft:deepslate_tiles
fill 0 225 288 0 285 288 minecraft:deepslate_tiles
setblock 3 225 278 minecraft:light[level=12]
setblock 3 225 286 minecraft:light[level=12]
setblock 3 225 294 minecraft:light[level=12]
setblock 3 225 302 minecraft:light[level=12]
setblock 3 225 310 minecraft:light[level=12]
setblock 11 225 278 minecraft:light[level=12]
setblock 11 225 286 minecraft:light[level=12]
setblock 11 225 294 minecraft:light[level=12]
setblock 11 225 302 minecraft:light[level=12]
setblock 11 225 310 minecraft:light[level=12]
fill 16 225 275 25 235 275 minecraft:deepslate_tiles
setblock 19 225 278 minecraft:light[level=12]
setblock 19 225 286 minecraft:light[level=12]
setblock 19 225 294 minecraft:light[level=12]
setblock 19 225 302 minecraft:light[level=12]
setblock 19 225 310 minecraft:light[level=12]
setblock 26 225 275 minecraft:crying_obsidian
fill 26 225 314 26 226 316 minecraft:amethyst_block
fill 27 225 275 32 227 275 minecraft:deepslate_tiles
setblock 27 225 278 minecraft:light[level=12]
setblock 27 225 286 minecraft:light[level=12]
setblock 27 225 294 minecraft:light[level=12]
setblock 27 225 302 minecraft:light[level=12]
setblock 27 225 310 minecraft:light[level=12]
fill 27 225 313 27 227 314 minecraft:amethyst_block
fill 27 225 316 28 226 316 minecraft:amethyst_block
fill 28 225 314 28 226 315 minecraft:amethyst_block
setblock 31 225 305 minecraft:nether_wart_block
setblock 31 225 306 minecraft:red_nether_bricks
fill 31 225 308 33 225 308 minecraft:red_nether_bricks
fill 32 225 303 32 225 305 minecraft:red_nether_bricks
setblock 32 225 306 minecraft:nether_wart_block
setblock 32 225 307 minecraft:red_nether_bricks
setblock 33 225 275 minecraft:amethyst_block
fill 33 225 277 34 226 277 minecraft:amethyst_block
fill 33 225 301 33 225 302 minecraft:red_nether_bricks
setblock 33 225 303 minecraft:nether_wart_block
fill 33 225 304 33 227 304 minecraft:red_nether_bricks
setblock 33 225 307 minecraft:nether_wart_block
setblock 34 225 300 minecraft:nether_wart_block
fill 34 225 301 34 227 301 minecraft:red_nether_bricks
fill 34 225 303 35 225 303 minecraft:orange_terracotta
setblock 34 225 304 minecraft:nether_wart_block
fill 34 225 305 34 227 305 minecraft:red_nether_bricks
setblock 34 225 307 minecraft:red_nether_bricks
fill 35 225 275 35 226 276 minecraft:amethyst_block
setblock 35 225 278 minecraft:light[level=12]
setblock 35 225 286 minecraft:light[level=12]
setblock 35 225 294 minecraft:light[level=12]
fill 35 225 299 36 226 299 minecraft:orange_terracotta
fill 35 225 301 36 226 301 minecraft:orange_terracotta
setblock 35 225 304 minecraft:red_nether_bricks
setblock 35 225 305 minecraft:nether_wart_block
fill 35 225 306 35 226 306 minecraft:red_nether_bricks
setblock 35 225 310 minecraft:light[level=12]
setblock 36 225 302 minecraft:nether_wart_block
fill 36 225 303 36 227 303 minecraft:red_nether_bricks
setblock 36 225 305 minecraft:red_nether_bricks
fill 37 225 300 37 225 302 minecraft:red_nether_bricks
setblock 37 225 303 minecraft:nether_wart_block
fill 42 225 315 42 232 315 minecraft:deepslate_tiles
fill 15 226 317 15 308 317 minecraft:deepslate_tiles
setblock 16 226 317 minecraft:magma_block
fill 26 226 275 26 308 275 minecraft:deepslate_tiles
fill 26 226 313 26 227 313 minecraft:amethyst_block
fill 27 226 312 27 227 312 minecraft:amethyst_block
fill 28 226 313 28 227 313 minecraft:amethyst_block
fill 32 226 303 32 226 304 minecraft:red_nether_bricks
setblock 32 226 305 minecraft:nether_wart_block
setblock 32 226 306 minecraft:red_nether_bricks
fill 33 226 275 34 226 275 minecraft:deepslate_tiles
fill 33 226 300 33 226 301 minecraft:red_nether_bricks
setblock 33 226 302 minecraft:nether_wart_block
fill 33 226 303 33 227 303 minecraft:red_nether_bricks
setblock 34 226 299 minecraft:nether_wart_block
fill 34 226 300 34 228 300 minecraft:red_nether_bricks
fill 34 226 302 36 226 302 minecraft:red_nether_bricks
setblock 34 226 303 minecraft:nether_wart_block
fill 34 226 304 34 227 304 minecraft:red_nether_bricks
fill 35 226 297 35 226 298 minecraft:red_nether_bricks
setblock 35 226 303 minecraft:red_nether_bricks
setblock 35 226 304 minecraft:nether_wart_block
fill 35 226 305 35 227 305 minecraft:red_nether_bricks
fill 36 226 296 36 227 298 minecraft:orange_terracotta
setblock 36 226 305 minecraft:nether_wart_block
fill 37 226 297 37 228 297 minecraft:orange_terracotta
setblock 37 226 298 minecraft:nether_wart_block
fill 37 226 299 37 226 300 minecraft:orange_terracotta
setblock 37 226 301 minecraft:red_nether_bricks
setblock 37 226 302 minecraft:nether_wart_block
fill 37 226 303 37 227 303 minecraft:red_nether_bricks
setblock 38 226 299 minecraft:nether_wart_block
fill 38 226 300 38 228 300 minecraft:red_nether_bricks
fill 16 227 317 16 242 317 minecraft:deepslate_tiles
setblock 26 227 312 minecraft:amethyst_block
setblock 26 227 314 minecraft:amethyst_block
fill 27 227 311 27 228 311 minecraft:amethyst_block
setblock 28 227 312 minecraft:amethyst_block
setblock 28 227 314 minecraft:amethyst_block
fill 33 227 275 33 308 275 minecraft:deepslate_tiles
setblock 33 227 276 minecraft:amethyst_block
setblock 33 227 300 minecraft:red_nether_bricks
setblock 33 227 301 minecraft:nether_wart_block
setblock 33 227 302 minecraft:red_nether_bricks
setblock 34 227 275 minecraft:amethyst_block
setblock 34 227 297 minecraft:red_nether_bricks
setblock 34 227 298 minecraft:nether_wart_block
fill 34 227 299 34 229 299 minecraft:red_nether_bricks
setblock 34 227 302 minecraft:nether_wart_block
fill 34 227 303 34 228 303 minecraft:red_nether_bricks
fill 35 227 275 35 278 275 minecraft:deepslate_tiles
setblock 35 227 295 minecraft:nether_wart_block
fill 35 227 296 35 227 297 minecraft:orange_terracotta
setblock 35 227 298 minecraft:red_nether_bricks
setblock 35 227 299 minecraft:nether_wart_block
fill 35 227 300 35 227 302 minecraft:red_nether_bricks
setblock 35 227 303 minecraft:nether_wart_block
setblock 35 227 304 minecraft:red_nether_bricks
fill 35 227 317 35 260 317 minecraft:deepslate_tiles
fill 36 227 295 37 228 295 minecraft:orange_terracotta
setblock 36 227 299 minecraft:orange_terracotta
setblock 36 227 300 minecraft:nether_wart_block
fill 36 227 301 36 228 302 minecraft:red_nether_bricks
setblock 36 227 304 minecraft:nether_wart_block
setblock 36 227 317 minecraft:amethyst_block
fill 37 227 296 37 228 296 minecraft:orange_terracotta
setblock 37 227 298 minecraft:orange_terracotta
fill 37 227 299 37 227 300 minecraft:red_nether_bricks
setblock 37 227 301 minecraft:nether_wart_block
fill 37 227 302 37 228 302 minecraft:red_nether_bricks
fill 37 227 317 40 239 317 minecraft:deepslate_tiles
fill 38 227 296 38 227 297 minecraft:red_nether_bricks
setblock 38 227 298 minecraft:nether_wart_block
fill 38 227 299 38 229 299 minecraft:red_nether_bricks
setblock 38 227 301 minecraft:red_nether_bricks
fill 40 227 300 40 229 300 minecraft:amethyst_block
setblock 0 228 277 minecraft:crying_obsidian
setblock 3 228 278 minecraft:light[level=12]
setblock 3 228 285 minecraft:light[level=12]
setblock 3 228 292 minecraft:light[level=12]
setblock 3 228 299 minecraft:light[level=12]
setblock 3 228 306 minecraft:light[level=12]
setblock 3 228 313 minecraft:light[level=12]
setblock 10 228 278 minecraft:light[level=12]
setblock 10 228 285 minecraft:light[level=12]
setblock 10 228 292 minecraft:light[level=12]
setblock 10 228 299 minecraft:light[level=12]
setblock 10 228 306 minecraft:light[level=12]
setblock 10 228 313 minecraft:light[level=12]
setblock 17 228 278 minecraft:light[level=12]
setblock 17 228 285 minecraft:light[level=12]
setblock 17 228 292 minecraft:light[level=12]
setblock 17 228 299 minecraft:light[level=12]
setblock 17 228 306 minecraft:light[level=12]
setblock 17 228 313 minecraft:light[level=12]
fill 20 228 312 21 229 312 minecraft:gold_block
setblock 24 228 278 minecraft:light[level=12]
setblock 24 228 285 minecraft:light[level=12]
setblock 24 228 292 minecraft:light[level=12]
setblock 24 228 299 minecraft:light[level=12]
setblock 24 228 306 minecraft:light[level=12]
setblock 24 228 313 minecraft:light[level=12]
fill 27 228 275 29 251 275 minecraft:deepslate_tiles
setblock 27 228 310 minecraft:amethyst_block
setblock 30 228 275 minecraft:purple_concrete
fill 31 228 275 32 308 275 minecraft:deepslate_tiles
setblock 31 228 278 minecraft:light[level=12]
setblock 31 228 285 minecraft:light[level=12]
setblock 31 228 292 minecraft:light[level=12]
setblock 31 228 299 minecraft:light[level=12]
setblock 31 228 306 minecraft:light[level=12]
setblock 31 228 313 minecraft:light[level=12]
fill 34 228 275 34 286 275 minecraft:deepslate_tiles
fill 34 228 295 34 228 296 minecraft:red_nether_bricks
setblock 34 228 297 minecraft:nether_wart_block
fill 34 228 298 34 229 298 minecraft:red_nether_bricks
setblock 34 228 301 minecraft:nether_wart_block
setblock 34 228 302 minecraft:red_nether_bricks
fill 35 228 293 37 229 293 minecraft:orange_terracotta
setblock 35 228 294 minecraft:nether_wart_block
fill 35 228 295 35 230 295 minecraft:red_nether_bricks
fill 35 228 296 36 228 296 minecraft:orange_terracotta
setblock 35 228 297 minecraft:red_nether_bricks
setblock 35 228 298 minecraft:nether_wart_block
fill 35 228 299 35 228 301 minecraft:red_nether_bricks
setblock 35 228 302 minecraft:nether_wart_block
setblock 35 228 303 minecraft:red_nether_bricks
fill 36 228 292 36 230 292 minecraft:orange_terracotta
fill 36 228 294 36 230 294 minecraft:orange_terracotta
setblock 36 228 297 minecraft:orange_terracotta
fill 36 228 298 38 228 298 minecraft:red_nether_bricks
fill 36 228 299 36 231 299 minecraft:bone_block
fill 36 228 300 36 229 300 minecraft:red_nether_bricks
setblock 36 228 303 minecraft:nether_wart_block
fill 36 228 317 36 308 317 minecraft:deepslate_tiles
setblock 37 228 294 minecraft:red_nether_bricks
setblock 37 228 299 minecraft:red_nether_bricks
setblock 37 228 300 minecraft:nether_wart_block
fill 37 228 301 37 229 301 minecraft:red_nether_bricks
setblock 38 228 278 minecraft:light[level=12]
setblock 38 228 285 minecraft:light[level=12]
setblock 38 228 292 minecraft:light[level=12]
fill 38 228 295 38 228 296 minecraft:red_nether_bricks
setblock 38 228 297 minecraft:nether_wart_block
setblock 38 228 306 minecraft:light[level=12]
setblock 38 228 313 minecraft:light[level=12]
fill 39 228 299 39 229 301 minecraft:amethyst_block
fill 40 228 299 41 229 299 minecraft:amethyst_block
fill 40 228 301 41 229 301 minecraft:amethyst_block
fill 41 228 300 41 229 300 minecraft:amethyst_block
fill 0 229 277 0 275 277 minecraft:deepslate_tiles
fill 9 229 275 10 308 275 minecraft:deepslate_tiles
setblock 11 229 275 minecraft:magma_block
fill 12 229 275 15 235 275 minecraft:deepslate_tiles
fill 30 229 275 30 272 275 minecraft:deepslate_tiles
fill 34 229 293 34 229 295 minecraft:red_nether_bricks
setblock 34 229 296 minecraft:nether_wart_block
fill 34 229 297 34 230 297 minecraft:red_nether_bricks
setblock 34 229 300 minecraft:nether_wart_block
setblock 35 229 291 minecraft:red_nether_bricks
fill 35 229 292 35 230 292 minecraft:orange_terracotta
setblock 35 229 294 minecraft:orange_terracotta
fill 35 229 296 37 229 296 minecraft:red_nether_bricks
setblock 35 229 297 minecraft:nether_wart_block
fill 35 229 298 35 229 300 minecraft:red_nether_bricks
setblock 35 229 301 minecraft:nether_wart_block
fill 36 229 291 36 230 291 minecraft:orange_terracotta
fill 36 229 295 36 231 295 minecraft:red_nether_bricks
fill 36 229 297 38 229 297 minecraft:red_nether_bricks
setblock 36 229 298 minecraft:nether_wart_block
setblock 36 229 301 minecraft:red_nether_bricks
setblock 37 229 292 minecraft:orange_terracotta
setblock 37 229 294 minecraft:orange_terracotta
setblock 37 229 295 minecraft:nether_wart_block
fill 37 229 298 38 229 298 minecraft:red_nether_bricks
setblock 37 229 299 minecraft:nether_wart_block
setblock 37 229 300 minecraft:red_nether_bricks
fill 38 229 293 38 229 295 minecraft:red_nether_bricks
setblock 38 229 296 minecraft:nether_wart_block
fill 38 229 300 38 229 301 minecraft:amethyst_block
fill 1 230 275 6 231 275 minecraft:deepslate_tiles
setblock 7 230 275 minecraft:magma_block
fill 11 230 275 11 308 275 minecraft:deepslate_tiles
fill 34 230 289 35 232 290 minecraft:orange_terracotta
setblock 34 230 291 minecraft:nether_wart_block
fill 34 230 292 34 230 294 minecraft:red_nether_bricks
setblock 34 230 295 minecraft:nether_wart_block
setblock 34 230 296 minecraft:red_nether_bricks
fill 35 230 291 35 231 291 minecraft:orange_terracotta
fill 35 230 293 36 230 293 minecraft:orange_terracotta
fill 35 230 294 35 231 294 minecraft:red_nether_bricks
setblock 35 230 296 minecraft:nether_wart_block
fill 35 230 297 35 230 299 minecraft:red_nether_bricks
setblock 36 230 289 minecraft:nether_wart_block
fill 36 230 290 36 231 290 minecraft:orange_terracotta
fill 36 230 296 38 230 296 minecraft:red_nether_bricks
setblock 36 230 297 minecraft:nether_wart_block
setblock 36 230 298 minecraft:red_nether_bricks
setblock 37 230 290 minecraft:nether_wart_block
fill 37 230 291 37 230 293 minecraft:red_nether_bricks
setblock 37 230 294 minecraft:nether_wart_block
fill 37 230 295 37 232 295 minecraft:red_nether_bricks
fill 37 230 297 38 230 297 minecraft:red_nether_bricks
setblock 37 230 298 minecraft:nether_wart_block
setblock 37 230 299 minecraft:red_nether_bricks
fill 38 230 292 38 230 294 minecraft:red_nether_bricks
setblock 38 230 295 minecraft:nether_wart_block
setblock 38 230 298 minecraft:red_nether_bricks
fill 7 231 275 7 295 275 minecraft:deepslate_tiles
fill 33 231 287 33 233 287 minecraft:orange_terracotta
setblock 33 231 288 minecraft:red_nether_bricks
setblock 33 231 289 minecraft:nether_wart_block
fill 33 231 290 33 231 292 minecraft:red_nether_bricks
setblock 34 231 287 minecraft:red_nether_bricks
fill 34 231 288 35 232 288 minecraft:orange_terracotta
fill 34 231 291 34 231 293 minecraft:red_nether_bricks
setblock 34 231 294 minecraft:nether_wart_block
setblock 34 231 295 minecraft:red_nether_bricks
fill 35 231 292 35 232 293 minecraft:red_nether_bricks
setblock 35 231 295 minecraft:nether_wart_block
fill 35 231 296 35 231 297 minecraft:red_nether_bricks
setblock 36 231 288 minecraft:nether_wart_block
setblock 36 231 289 minecraft:orange_terracotta
fill 36 231 291 38 231 291 minecraft:red_nether_bricks
fill 36 231 292 36 234 292 minecraft:bone_block
fill 36 231 293 36 232 294 minecraft:red_nether_bricks
setblock 36 231 296 minecraft:nether_wart_block
setblock 36 231 297 minecraft:red_nether_bricks
setblock 37 231 289 minecraft:nether_wart_block
fill 37 231 290 37 233 290 minecraft:red_nether_bricks
fill 37 231 292 38 231 292 minecraft:red_nether_bricks
setblock 37 231 293 minecraft:nether_wart_block
fill 37 231 294 37 232 294 minecraft:red_nether_bricks
fill 37 231 296 38 231 296 minecraft:red_nether_bricks
setblock 37 231 297 minecraft:nether_wart_block
setblock 38 231 293 minecraft:red_nether_bricks
setblock 38 231 294 minecraft:nether_wart_block
setblock 38 231 295 minecraft:red_nether_bricks
fill 1 232 275 1 292 275 minecraft:deepslate_tiles
setblock 2 232 275 minecraft:amethyst_block
fill 3 232 275 6 308 275 minecraft:deepslate_tiles
setblock 3 232 278 minecraft:light[level=12]
setblock 3 232 286 minecraft:light[level=12]
setblock 3 232 294 minecraft:light[level=12]
setblock 3 232 302 minecraft:light[level=12]
setblock 3 232 310 minecraft:light[level=12]
setblock 11 232 278 minecraft:light[level=12]
setblock 11 232 286 minecraft:light[level=12]
setblock 11 232 294 minecraft:light[level=12]
setblock 11 232 302 minecraft:light[level=12]
setblock 11 232 310 minecraft:light[level=12]
setblock 19 232 278 minecraft:light[level=12]
setblock 19 232 286 minecraft:light[level=12]
setblock 19 232 294 minecraft:light[level=12]
setblock 19 232 302 minecraft:light[level=12]
setblock 19 232 310 minecraft:light[level=12]
setblock 27 232 278 minecraft:light[level=12]
setblock 27 232 286 minecraft:light[level=12]
setblock 27 232 294 minecraft:light[level=12]
setblock 27 232 302 minecraft:light[level=12]
setblock 27 232 310 minecraft:light[level=12]
fill 32 232 286 32 233 287 minecraft:orange_terracotta
fill 32 232 288 32 233 289 minecraft:red_nether_bricks
fill 33 232 286 34 233 286 minecraft:orange_terracotta
fill 33 232 288 33 233 288 minecraft:orange_terracotta
fill 33 232 289 33 232 291 minecraft:red_nether_bricks
setblock 33 232 292 minecraft:nether_wart_block
fill 34 232 287 34 233 287 minecraft:orange_terracotta
fill 34 232 291 34 232 292 minecraft:red_nether_bricks
setblock 34 232 293 minecraft:nether_wart_block
setblock 34 232 294 minecraft:red_nether_bricks
setblock 35 232 278 minecraft:light[level=12]
setblock 35 232 286 minecraft:light[level=12]
fill 35 232 287 35 234 287 minecraft:red_nether_bricks
fill 35 232 291 35 234 291 minecraft:red_nether_bricks
setblock 35 232 294 minecraft:nether_wart_block
setblock 35 232 295 minecraft:red_nether_bricks
setblock 35 232 302 minecraft:light[level=12]
setblock 35 232 310 minecraft:light[level=12]
setblock 36 232 287 minecraft:nether_wart_block
fill 36 232 288 36 232 290 minecraft:red_nether_bricks
setblock 36 232 291 minecraft:nether_wart_block
setblock 36 232 295 minecraft:nether_wart_block
fill 37 232 289 37 233 289 minecraft:red_nether_bricks
setblock 37 232 291 minecraft:red_nether_bricks
setblock 37 232 292 minecraft:nether_wart_block
fill 37 232 293 37 233 293 minecraft:red_nether_bricks
setblock 38 232 292 minecraft:red_nether_bricks
setblock 38 232 293 minecraft:nether_wart_block
fill 2 233 275 2 308 275 minecraft:deepslate_tiles
fill 31 233 284 31 234 285 minecraft:orange_terracotta
fill 31 233 286 31 234 287 minecraft:red_nether_bricks
setblock 32 233 284 minecraft:red_nether_bricks
fill 32 233 285 33 233 285 minecraft:orange_terracotta
fill 33 233 289 34 233 290 minecraft:red_nether_bricks
setblock 33 233 291 minecraft:nether_wart_block
fill 34 233 285 34 234 285 minecraft:red_nether_bricks
setblock 34 233 288 minecraft:nether_wart_block
setblock 34 233 291 minecraft:red_nether_bricks
setblock 34 233 292 minecraft:nether_wart_block
fill 35 233 286 35 234 286 minecraft:red_nether_bricks
fill 35 233 288 36 233 288 minecraft:red_nether_bricks
setblock 35 233 289 minecraft:nether_wart_block
fill 35 233 290 35 234 290 minecraft:red_nether_bricks
setblock 35 233 292 minecraft:red_nether_bricks
setblock 35 233 293 minecraft:nether_wart_block
fill 36 233 287 36 234 287 minecraft:red_nether_bricks
setblock 36 233 289 minecraft:red_nether_bricks
setblock 36 233 290 minecraft:nether_wart_block
fill 36 233 291 36 234 291 minecraft:red_nether_bricks
setblock 36 233 293 minecraft:red_nether_bricks
setblock 36 233 294 minecraft:nether_wart_block
setblock 37 233 291 minecraft:nether_wart_block
setblock 37 233 292 minecraft:red_nether_bricks
setblock 42 233 315 minecraft:magma_block
setblock 3 234 278 minecraft:light[level=12]
setblock 3 234 285 minecraft:light[level=12]
setblock 3 234 292 minecraft:light[level=12]
setblock 3 234 299 minecraft:light[level=12]
setblock 3 234 306 minecraft:light[level=12]
setblock 3 234 313 minecraft:light[level=12]
setblock 10 234 278 minecraft:light[level=12]
setblock 10 234 285 minecraft:light[level=12]
setblock 10 234 292 minecraft:light[level=12]
setblock 10 234 299 minecraft:light[level=12]
setblock 10 234 306 minecraft:light[level=12]
setblock 10 234 313 minecraft:light[level=12]
setblock 17 234 278 minecraft:light[level=12]
setblock 17 234 285 minecraft:light[level=12]
setblock 17 234 292 minecraft:light[level=12]
setblock 17 234 299 minecraft:light[level=12]
setblock 17 234 306 minecraft:light[level=12]
setblock 17 234 313 minecraft:light[level=12]
setblock 24 234 278 minecraft:light[level=12]
setblock 24 234 285 minecraft:light[level=12]
setblock 24 234 292 minecraft:light[level=12]
setblock 24 234 299 minecraft:light[level=12]
setblock 24 234 306 minecraft:light[level=12]
setblock 24 234 313 minecraft:light[level=12]
fill 29 234 283 30 234 284 minecraft:orange_terracotta
setblock 29 234 285 minecraft:red_nether_bricks
setblock 30 234 285 minecraft:orange_terracotta
setblock 30 234 286 minecraft:red_nether_bricks
setblock 31 234 278 minecraft:light[level=12]
setblock 31 234 283 minecraft:orange_terracotta
setblock 31 234 288 minecraft:nether_wart_block
setblock 31 234 292 minecraft:light[level=12]
setblock 31 234 299 minecraft:light[level=12]
setblock 31 234 306 minecraft:light[level=12]
setblock 31 234 313 minecraft:light[level=12]
setblock 32 234 283 minecraft:red_nether_bricks
fill 32 234 284 32 234 286 minecraft:orange_terracotta
fill 32 234 287 33 234 288 minecraft:red_nether_bricks
setblock 32 234 289 minecraft:nether_wart_block
fill 33 234 284 33 234 285 minecraft:red_nether_bricks
setblock 33 234 286 minecraft:orange_terracotta
fill 33 234 289 35 234 289 minecraft:red_nether_bricks
setblock 33 234 290 minecraft:nether_wart_block
setblock 34 234 286 minecraft:red_nether_bricks
setblock 34 234 287 minecraft:nether_wart_block
setblock 34 234 288 minecraft:red_nether_bricks
setblock 34 234 290 minecraft:red_nether_bricks
setblock 34 234 291 minecraft:nether_wart_block
setblock 35 234 288 minecraft:nether_wart_block
setblock 35 234 292 minecraft:nether_wart_block
setblock 36 234 288 minecraft:red_nether_bricks
setblock 36 234 289 minecraft:nether_wart_block
setblock 36 234 290 minecraft:red_nether_bricks
setblock 38 234 278 minecraft:light[level=12]
setblock 38 234 285 minecraft:light[level=12]
setblock 38 234 292 minecraft:light[level=12]
setblock 38 234 299 minecraft:light[level=12]
setblock 38 234 306 minecraft:light[level=12]
setblock 38 234 313 minecraft:light[level=12]
fill 42 234 311 42 308 311 minecraft:deepslate_tiles
setblock 42 234 312 minecraft:magma_block
fill 42 234 313 42 303 313 minecraft:deepslate_tiles
fill 42 234 315 42 308 315 minecraft:deepslate_tiles
fill 1 235 276 16 235 316 minecraft:red_terracotta
fill 17 235 276 17 235 290 minecraft:red_terracotta
fill 17 235 292 17 235 316 minecraft:red_terracotta
fill 18 235 276 19 235 288 minecraft:red_terracotta
fill 18 235 294 19 235 316 minecraft:red_terracotta
fill 20 235 276 41 235 287 minecraft:red_terracotta
fill 20 235 295 20 235 316 minecraft:red_terracotta
fill 21 235 288 41 235 288 minecraft:red_terracotta
fill 21 235 294 41 235 295 minecraft:red_terracotta
fill 21 235 296 21 242 296 minecraft:red_nether_bricks
fill 21 235 297 41 235 316 minecraft:red_terracotta
fill 22 235 296 41 235 296 minecraft:red_terracotta
fill 23 235 289 41 235 290 minecraft:red_terracotta
fill 23 235 292 41 235 293 minecraft:red_terracotta
fill 24 235 291 41 235 291 minecraft:red_terracotta
fill 42 235 312 42 308 312 minecraft:deepslate_tiles
fill 0 236 289 0 237 289 minecraft:bone_block
fill 0 236 290 0 246 291 minecraft:deepslate_tiles
fill 0 236 303 0 237 303 minecraft:bone_block
fill 1 236 276 2 236 286 minecraft:red_terracotta
fill 1 236 287 1 236 291 minecraft:red_concrete
fill 1 236 292 1 236 300 minecraft:red_terracotta
fill 1 236 301 1 236 305 minecraft:red_concrete
fill 1 236 306 2 236 316 minecraft:red_terracotta
fill 2 236 287 12 236 287 minecraft:red_terracotta
fill 2 236 288 3 236 292 minecraft:red_concrete
fill 2 236 293 6 236 299 minecraft:red_terracotta
fill 2 236 300 3 236 304 minecraft:red_concrete
fill 2 236 305 12 236 305 minecraft:red_terracotta
fill 3 236 276 9 236 276 minecraft:red_concrete
fill 3 236 277 3 236 286 minecraft:red_terracotta
fill 3 236 306 3 236 315 minecraft:red_terracotta
fill 3 236 316 9 236 316 minecraft:red_concrete
fill 4 236 277 10 236 277 minecraft:red_concrete
fill 4 236 278 4 236 286 minecraft:red_terracotta
fill 4 236 288 13 236 288 minecraft:red_terracotta
fill 4 236 289 5 236 292 minecraft:red_concrete
fill 4 236 300 5 236 303 minecraft:red_concrete
fill 4 236 304 13 236 304 minecraft:red_terracotta
fill 4 236 306 4 236 314 minecraft:red_terracotta
fill 4 236 315 10 236 315 minecraft:red_concrete
fill 5 236 278 10 236 278 minecraft:red_concrete
fill 5 236 279 5 236 286 minecraft:red_terracotta
fill 5 236 306 5 236 313 minecraft:red_terracotta
fill 5 236 314 10 236 314 minecraft:red_concrete
fill 6 236 279 11 236 279 minecraft:red_concrete
fill 6 236 280 6 236 286 minecraft:red_terracotta
fill 6 236 289 14 236 289 minecraft:red_terracotta
fill 6 236 290 7 236 292 minecraft:red_concrete
fill 6 236 300 7 236 302 minecraft:red_concrete
fill 6 236 303 14 236 303 minecraft:red_terracotta
fill 6 236 306 6 236 312 minecraft:red_terracotta
fill 6 236 313 11 236 313 minecraft:red_concrete
fill 7 236 280 11 236 280 minecraft:red_concrete
fill 7 236 281 7 236 286 minecraft:red_terracotta
fill 7 236 293 14 236 293 minecraft:red_concrete
fill 7 236 294 11 236 298 minecraft:red_terracotta
fill 7 236 299 14 236 299 minecraft:red_concrete
fill 7 236 306 7 236 311 minecraft:red_terracotta
fill 7 236 312 11 236 312 minecraft:red_concrete
fill 8 236 281 12 236 281 minecraft:red_concrete
fill 8 236 282 8 236 286 minecraft:red_terracotta
fill 8 236 290 15 236 290 minecraft:red_terracotta
fill 8 236 291 10 236 292 minecraft:red_concrete
fill 8 236 300 10 236 301 minecraft:red_concrete
fill 8 236 302 15 236 302 minecraft:red_terracotta
fill 8 236 306 8 236 310 minecraft:red_terracotta
fill 8 236 311 12 236 311 minecraft:red_concrete
fill 9 236 282 13 236 282 minecraft:red_concrete
fill 9 236 283 9 236 286 minecraft:red_terracotta
fill 9 236 306 9 236 309 minecraft:red_terracotta
fill 9 236 310 13 236 310 minecraft:red_concrete
fill 10 236 276 18 236 276 minecraft:red_terracotta
fill 10 236 283 13 236 283 minecraft:red_concrete
fill 10 236 284 10 236 286 minecraft:red_terracotta
fill 10 236 306 10 236 308 minecraft:red_terracotta
fill 10 236 309 13 236 309 minecraft:red_concrete
fill 10 236 316 18 236 316 minecraft:red_terracotta
fill 11 236 277 18 236 278 minecraft:red_terracotta
fill 11 236 284 14 236 285 minecraft:red_concrete
setblock 11 236 286 minecraft:red_terracotta
fill 11 236 291 15 236 291 minecraft:red_terracotta
fill 11 236 292 12 236 292 minecraft:red_concrete
fill 11 236 300 12 236 300 minecraft:red_concrete
fill 11 236 301 16 236 301 minecraft:red_terracotta
setblock 11 236 306 minecraft:red_terracotta
fill 11 236 307 14 236 308 minecraft:red_concrete
fill 11 236 314 18 236 315 minecraft:red_terracotta
fill 12 236 275 14 290 275 minecraft:deepslate_tiles
fill 12 236 279 19 236 280 minecraft:red_terracotta
fill 12 236 286 15 236 286 minecraft:red_concrete
fill 12 236 294 16 236 294 minecraft:red_concrete
fill 12 236 295 16 236 297 minecraft:red_terracotta
fill 12 236 298 16 236 298 minecraft:red_concrete
fill 12 236 306 15 236 306 minecraft:red_concrete
fill 12 236 312 19 236 313 minecraft:red_terracotta
fill 13 236 281 19 236 281 minecraft:red_terracotta
fill 13 236 287 15 236 287 minecraft:red_concrete
fill 13 236 292 15 236 292 minecraft:red_terracotta
fill 13 236 300 17 236 300 minecraft:red_terracotta
fill 13 236 305 15 236 305 minecraft:red_concrete
fill 13 236 311 19 236 311 minecraft:red_terracotta
fill 14 236 282 19 236 283 minecraft:red_terracotta
fill 14 236 288 16 236 288 minecraft:red_concrete
fill 14 236 304 16 236 304 minecraft:red_concrete
fill 14 236 309 19 236 310 minecraft:red_terracotta
setblock 15 236 275 minecraft:crying_obsidian
fill 15 236 284 19 236 285 minecraft:red_terracotta
fill 15 236 289 16 236 289 minecraft:red_concrete
fill 15 236 293 16 236 293 minecraft:red_terracotta
fill 15 236 299 18 236 299 minecraft:red_terracotta
fill 15 236 303 17 236 303 minecraft:red_concrete
fill 15 236 307 19 236 308 minecraft:red_terracotta
fill 16 236 275 20 239 275 minecraft:deepslate_tiles
fill 16 236 286 18 236 287 minecraft:red_terracotta
fill 16 236 290 17 236 290 minecraft:shroomlight
fill 16 236 291 16 238 291 minecraft:quartz_block
fill 16 236 292 17 236 292 minecraft:shroomlight
fill 16 236 302 17 236 302 minecraft:red_concrete
fill 16 236 305 19 236 306 minecraft:red_terracotta
fill 17 236 288 17 236 289 minecraft:shroomlight
fill 17 236 293 17 236 294 minecraft:shroomlight
fill 17 236 295 18 236 295 minecraft:red_concrete
fill 17 236 296 18 236 296 minecraft:red_terracotta
fill 17 236 297 18 236 297 minecraft:red_concrete
fill 17 236 298 18 236 298 minecraft:red_terracotta
fill 17 236 301 18 236 301 minecraft:red_concrete
fill 17 236 304 19 236 304 minecraft:red_terracotta
fill 17 236 317 20 243 317 minecraft:deepslate_tiles
fill 18 236 288 19 236 288 minecraft:shroomlight
fill 18 236 294 19 236 294 minecraft:shroomlight
setblock 18 236 300 minecraft:red_concrete
fill 18 236 302 19 236 303 minecraft:red_terracotta
fill 19 236 276 23 236 278 minecraft:red_concrete
setblock 19 236 286 minecraft:red_terracotta
setblock 19 236 287 minecraft:shroomlight
setblock 19 236 295 minecraft:shroomlight
fill 19 236 296 20 237 301 minecraft:red_nether_bricks
fill 19 236 314 23 236 316 minecraft:red_concrete
fill 20 236 279 20 236 285 minecraft:red_concrete
fill 20 236 286 22 237 286 minecraft:red_nether_bricks
fill 20 236 287 20 238 287 minecraft:quartz_block
fill 20 236 295 20 238 295 minecraft:quartz_block
fill 20 236 302 22 236 306 minecraft:red_nether_bricks
fill 20 236 307 20 236 313 minecraft:red_concrete
fill 21 236 275 21 237 275 minecraft:bone_block
fill 21 236 279 22 236 283 minecraft:red_concrete
fill 21 236 284 21 238 285 minecraft:red_nether_bricks
fill 21 236 287 21 236 288 minecraft:shroomlight
fill 21 236 294 21 236 295 minecraft:shroomlight
fill 21 236 297 23 236 301 minecraft:red_nether_bricks
fill 21 236 307 21 237 308 minecraft:red_nether_bricks
fill 21 236 309 22 236 313 minecraft:red_concrete
fill 21 236 317 21 237 317 minecraft:bone_block
fill 22 236 275 25 308 275 minecraft:deepslate_tiles
fill 22 236 284 22 236 285 minecraft:red_concrete
setblock 22 236 287 minecraft:red_nether_bricks
fill 22 236 288 23 236 288 minecraft:shroomlight
fill 22 236 294 23 236 294 minecraft:shroomlight
fill 22 236 295 23 236 296 minecraft:red_nether_bricks
fill 22 236 307 22 236 308 minecraft:red_concrete
fill 23 236 279 26 236 287 minecraft:red_terracotta
fill 23 236 289 23 236 290 minecraft:shroomlight
fill 23 236 292 23 236 293 minecraft:shroomlight
fill 23 236 302 24 236 313 minecraft:red_terracotta
fill 24 236 276 31 236 278 minecraft:red_terracotta
fill 24 236 288 24 236 289 minecraft:red_terracotta
setblock 24 236 290 minecraft:shroomlight
fill 24 236 291 24 238 291 minecraft:quartz_block
setblock 24 236 292 minecraft:shroomlight
fill 24 236 293 25 236 294 minecraft:red_terracotta
fill 24 236 295 25 236 295 minecraft:red_concrete
fill 24 236 296 41 236 296 minecraft:red_terracotta
fill 24 236 297 25 236 297 minecraft:red_concrete
fill 24 236 298 25 236 299 minecraft:red_terracotta
fill 24 236 300 24 236 301 minecraft:red_concrete
fill 24 236 314 31 236 316 minecraft:red_terracotta
setblock 25 236 288 minecraft:red_terracotta
fill 25 236 289 25 236 291 minecraft:red_concrete
fill 25 236 292 29 236 292 minecraft:red_terracotta
fill 25 236 300 29 236 300 minecraft:red_terracotta
fill 25 236 301 25 236 303 minecraft:red_concrete
fill 25 236 304 25 236 313 minecraft:red_terracotta
fill 26 236 288 26 236 290 minecraft:red_concrete
fill 26 236 291 31 236 291 minecraft:red_terracotta
fill 26 236 293 27 236 293 minecraft:red_terracotta
fill 26 236 294 30 236 294 minecraft:red_concrete
fill 26 236 295 41 236 295 minecraft:red_terracotta
fill 26 236 297 41 236 297 minecraft:red_terracotta
fill 26 236 298 30 236 298 minecraft:red_concrete
fill 26 236 299 27 236 299 minecraft:red_terracotta
fill 26 236 301 31 236 301 minecraft:red_terracotta
fill 26 236 302 26 236 304 minecraft:red_concrete
fill 26 236 305 26 236 313 minecraft:red_terracotta
fill 27 236 279 27 236 285 minecraft:red_terracotta
fill 27 236 286 27 236 289 minecraft:red_concrete
fill 27 236 290 34 236 290 minecraft:red_terracotta
fill 27 236 302 34 236 302 minecraft:red_terracotta
fill 27 236 303 27 236 306 minecraft:red_concrete
fill 27 236 307 27 236 313 minecraft:red_terracotta
fill 28 236 279 28 236 283 minecraft:red_terracotta
fill 28 236 284 28 236 288 minecraft:red_concrete
fill 28 236 289 36 236 289 minecraft:red_terracotta
fill 28 236 293 35 236 293 minecraft:red_concrete
fill 28 236 299 35 236 299 minecraft:red_concrete
fill 28 236 303 36 236 303 minecraft:red_terracotta
fill 28 236 304 28 236 308 minecraft:red_concrete
fill 28 236 309 28 236 313 minecraft:red_terracotta
fill 29 236 279 29 236 281 minecraft:red_terracotta
fill 29 236 282 29 236 287 minecraft:red_concrete
fill 29 236 288 38 236 288 minecraft:red_terracotta
fill 29 236 304 38 236 304 minecraft:red_terracotta
fill 29 236 305 29 236 310 minecraft:red_concrete
fill 29 236 311 29 236 313 minecraft:red_terracotta
fill 30 236 279 30 236 280 minecraft:red_terracotta
fill 30 236 281 30 236 286 minecraft:red_concrete
fill 30 236 287 40 236 287 minecraft:red_terracotta
fill 30 236 292 40 236 292 minecraft:red_concrete
fill 30 236 300 40 236 300 minecraft:red_concrete
fill 30 236 305 40 236 305 minecraft:red_terracotta
fill 30 236 306 30 236 311 minecraft:red_concrete
fill 30 236 312 30 236 313 minecraft:red_terracotta
fill 31 236 279 31 236 285 minecraft:red_concrete
fill 31 236 286 41 236 286 minecraft:red_terracotta
fill 31 236 294 41 236 294 minecraft:red_terracotta
fill 31 236 298 41 236 298 minecraft:red_terracotta
fill 31 236 306 41 236 306 minecraft:red_terracotta
fill 31 236 307 31 236 313 minecraft:red_concrete
setblock 32 236 276 minecraft:red_terracotta
fill 32 236 277 32 236 283 minecraft:red_concrete
fill 32 236 284 41 236 285 minecraft:red_terracotta
fill 32 236 291 41 236 291 minecraft:red_concrete
fill 32 236 301 41 236 301 minecraft:red_concrete
fill 32 236 307 41 236 308 minecraft:red_terracotta
fill 32 236 309 32 236 315 minecraft:red_concrete
setblock 32 236 316 minecraft:red_terracotta
fill 33 236 276 33 236 282 minecraft:red_concrete
fill 33 236 283 41 236 283 minecraft:red_terracotta
fill 33 236 309 41 236 309 minecraft:red_terracotta
fill 33 236 310 33 236 316 minecraft:red_concrete
fill 34 236 276 34 236 281 minecraft:red_concrete
fill 34 236 282 41 236 282 minecraft:red_terracotta
fill 34 236 310 41 236 310 minecraft:red_terracotta
fill 34 236 311 34 236 316 minecraft:red_concrete
fill 35 236 276 35 236 280 minecraft:red_concrete
fill 35 236 281 41 236 281 minecraft:red_terracotta
fill 35 236 290 41 236 290 minecraft:red_concrete
fill 35 236 302 41 236 302 minecraft:red_concrete
fill 35 236 311 41 236 311 minecraft:red_terracotta
fill 35 236 312 35 236 316 minecraft:red_concrete
fill 36 236 276 36 236 279 minecraft:red_concrete
fill 36 236 280 41 236 280 minecraft:red_terracotta
fill 36 236 293 41 236 293 minecraft:red_terracotta
fill 36 236 299 41 236 299 minecraft:red_terracotta
fill 36 236 312 41 236 312 minecraft:red_terracotta
fill 36 236 313 36 236 316 minecraft:red_concrete
fill 37 236 276 37 236 278 minecraft:red_concrete
fill 37 236 279 41 236 279 minecraft:red_terracotta
fill 37 236 289 41 236 289 minecraft:red_concrete
fill 37 236 303 41 236 303 minecraft:red_concrete
fill 37 236 313 41 236 313 minecraft:red_terracotta
fill 37 236 314 37 236 316 minecraft:red_concrete
fill 38 236 276 38 236 277 minecraft:red_concrete
fill 38 236 278 41 236 278 minecraft:red_terracotta
fill 38 236 314 41 236 314 minecraft:red_terracotta
fill 38 236 315 38 236 316 minecraft:red_concrete
setblock 39 236 276 minecraft:red_concrete
fill 39 236 277 41 236 277 minecraft:red_terracotta
fill 39 236 288 41 236 288 minecraft:red_concrete
fill 39 236 304 41 236 304 minecraft:red_concrete
fill 39 236 315 41 236 315 minecraft:red_terracotta
setblock 39 236 316 minecraft:red_concrete
fill 40 236 276 41 236 276 minecraft:red_terracotta
fill 40 236 316 41 236 316 minecraft:red_terracotta
setblock 41 236 287 minecraft:red_concrete
setblock 41 236 292 minecraft:red_terracotta
setblock 41 236 300 minecraft:red_terracotta
setblock 41 236 305 minecraft:red_concrete
fill 42 236 285 42 269 288 minecraft:deepslate_tiles
fill 42 236 289 42 237 289 minecraft:bone_block
fill 42 236 303 42 237 303 minecraft:bone_block
fill 42 236 304 42 267 309 minecraft:deepslate_tiles
fill 1 237 289 1 237 290 minecraft:bone_block
fill 1 237 302 1 237 303 minecraft:bone_block
fill 2 237 290 4 237 290 minecraft:bone_block
fill 2 237 302 4 237 302 minecraft:bone_block
fill 4 237 291 7 237 291 minecraft:bone_block
fill 4 237 301 7 237 301 minecraft:bone_block
fill 7 237 292 10 237 292 minecraft:bone_block
fill 7 237 300 10 237 300 minecraft:bone_block
fill 8 237 278 8 237 279 minecraft:bone_block
fill 8 237 313 8 237 314 minecraft:bone_block
fill 9 237 279 9 237 280 minecraft:bone_block
fill 9 237 312 9 237 313 minecraft:bone_block
fill 10 237 280 10 237 281 minecraft:bone_block
fill 10 237 293 13 237 293 minecraft:bone_block
fill 10 237 299 13 237 299 minecraft:bone_block
fill 10 237 311 10 237 312 minecraft:bone_block
fill 11 237 282 11 237 283 minecraft:bone_block
fill 11 237 309 11 237 310 minecraft:bone_block
fill 12 237 283 12 237 284 minecraft:bone_block
fill 12 237 308 12 237 309 minecraft:bone_block
setblock 13 237 285 minecraft:bone_block
setblock 13 237 307 minecraft:bone_block
fill 14 237 286 14 237 287 minecraft:bone_block
fill 14 237 291 15 237 291 minecraft:red_nether_bricks
fill 14 237 294 15 237 294 minecraft:bone_block
fill 14 237 298 16 237 298 minecraft:bone_block
fill 14 237 305 14 237 306 minecraft:bone_block
fill 15 237 275 15 308 275 minecraft:deepslate_tiles
fill 15 237 287 15 237 288 minecraft:bone_block
fill 15 237 289 15 242 290 minecraft:red_nether_bricks
fill 15 237 292 15 242 293 minecraft:red_nether_bricks
fill 15 237 304 15 237 305 minecraft:bone_block
fill 16 237 288 17 237 288 minecraft:red_nether_bricks
fill 16 237 289 17 237 289 minecraft:quartz_block
fill 16 237 290 16 238 290 minecraft:red_nether_bricks
fill 16 237 292 16 238 292 minecraft:red_nether_bricks
fill 16 237 293 17 237 293 minecraft:quartz_block
fill 16 237 294 17 237 294 minecraft:red_nether_bricks
fill 16 237 302 16 237 303 minecraft:bone_block
setblock 17 237 287 minecraft:red_nether_bricks
setblock 17 237 295 minecraft:red_nether_bricks
fill 17 237 297 18 237 297 minecraft:bone_block
fill 17 237 301 17 237 302 minecraft:bone_block
fill 18 237 287 18 237 288 minecraft:quartz_block
fill 18 237 294 18 237 295 minecraft:quartz_block
fill 18 237 300 18 237 301 minecraft:bone_block
fill 19 237 287 19 238 287 minecraft:red_nether_bricks
fill 19 237 295 19 238 295 minecraft:red_nether_bricks
fill 19 237 302 20 237 304 minecraft:red_nether_bricks
fill 20 237 284 20 237 285 minecraft:red_nether_bricks
fill 20 237 305 20 237 308 minecraft:red_nether_bricks
fill 21 237 276 21 237 281 minecraft:bone_block
fill 21 237 282 21 237 283 minecraft:red_nether_bricks
fill 21 237 287 21 238 287 minecraft:red_nether_bricks
fill 21 237 295 21 238 295 minecraft:red_nether_bricks
setblock 21 237 297 minecraft:bone_block
fill 21 237 298 23 238 298 minecraft:red_nether_bricks
fill 21 237 299 21 239 299 minecraft:bone_block
fill 21 237 300 23 238 300 minecraft:red_nether_bricks
fill 21 237 301 21 239 301 minecraft:bone_block
fill 21 237 302 23 237 302 minecraft:red_nether_bricks
fill 21 237 303 21 239 303 minecraft:bone_block
fill 21 237 304 23 237 304 minecraft:red_nether_bricks
fill 21 237 305 21 239 305 minecraft:bone_block
fill 21 237 306 22 238 306 minecraft:red_nether_bricks
fill 21 237 309 21 237 310 minecraft:red_nether_bricks
fill 21 237 311 21 237 316 minecraft:bone_block
fill 22 237 284 22 237 285 minecraft:red_nether_bricks
fill 22 237 287 22 237 288 minecraft:quartz_block
fill 22 237 294 22 237 295 minecraft:quartz_block
fill 22 237 296 23 243 297 minecraft:red_nether_bricks
fill 22 237 299 23 238 299 minecraft:red_nether_bricks
fill 22 237 301 23 238 301 minecraft:red_nether_bricks
fill 22 237 303 23 237 303 minecraft:red_nether_bricks
fill 22 237 305 22 238 305 minecraft:red_nether_bricks
fill 22 237 307 22 237 308 minecraft:red_nether_bricks
fill 23 237 281 27 237 281 minecraft:orange_terracotta
fill 23 237 287 23 237 288 minecraft:red_nether_bricks
fill 23 237 289 24 237 289 minecraft:quartz_block
fill 23 237 293 24 237 293 minecraft:quartz_block
fill 23 237 294 23 237 295 minecraft:red_nether_bricks
fill 24 237 282 28 237 282 minecraft:orange_terracotta
setblock 24 237 288 minecraft:red_nether_bricks
fill 24 237 290 25 237 290 minecraft:red_nether_bricks
fill 24 237 292 25 237 292 minecraft:red_nether_bricks
setblock 24 237 294 minecraft:red_nether_bricks
fill 24 237 295 25 237 295 minecraft:bone_block
fill 24 237 297 25 237 297 minecraft:bone_block
fill 24 237 300 24 237 301 minecraft:bone_block
setblock 25 237 280 minecraft:red_nether_bricks
setblock 25 237 283 minecraft:nether_wart_block
fill 25 237 289 25 238 289 minecraft:red_nether_bricks
fill 25 237 291 26 237 291 minecraft:red_nether_bricks
fill 25 237 293 25 238 293 minecraft:red_nether_bricks
fill 25 237 301 25 237 302 minecraft:bone_block
setblock 26 237 280 minecraft:nether_wart_block
fill 26 237 283 28 237 283 minecraft:orange_terracotta
setblock 26 237 284 minecraft:nether_wart_block
fill 26 237 289 26 237 290 minecraft:bone_block
fill 26 237 294 28 237 294 minecraft:bone_block
fill 26 237 298 28 237 298 minecraft:bone_block
fill 26 237 302 26 237 303 minecraft:bone_block
fill 27 237 280 28 237 280 minecraft:red_nether_bricks
fill 27 237 284 29 237 284 minecraft:red_nether_bricks
fill 27 237 287 27 237 288 minecraft:bone_block
fill 27 237 304 27 237 305 minecraft:bone_block
fill 28 237 281 30 237 281 minecraft:red_nether_bricks
setblock 28 237 285 minecraft:red_nether_bricks
fill 28 237 286 28 237 287 minecraft:bone_block
fill 28 237 305 28 237 306 minecraft:bone_block
fill 29 237 282 30 237 282 minecraft:red_nether_bricks
setblock 29 237 283 minecraft:nether_wart_block
setblock 29 237 285 minecraft:bone_block
fill 29 237 286 31 237 286 minecraft:red_nether_bricks
fill 29 237 293 32 237 293 minecraft:bone_block
fill 29 237 299 32 237 299 minecraft:bone_block
setblock 29 237 307 minecraft:bone_block
fill 30 237 283 30 237 284 minecraft:bone_block
fill 30 237 285 30 238 285 minecraft:red_nether_bricks
fill 30 237 308 30 237 309 minecraft:bone_block
fill 31 237 282 31 237 283 minecraft:bone_block
fill 31 237 284 33 237 284 minecraft:red_nether_bricks
setblock 31 237 285 minecraft:nether_wart_block
fill 31 237 309 31 237 310 minecraft:bone_block
fill 32 237 280 32 237 281 minecraft:bone_block
setblock 32 237 283 minecraft:red_nether_bricks
fill 32 237 285 33 237 285 minecraft:red_nether_bricks
fill 32 237 286 33 238 286 minecraft:bone_block
setblock 32 237 287 minecraft:red_nether_bricks
fill 32 237 292 35 237 292 minecraft:bone_block
fill 32 237 300 35 237 300 minecraft:bone_block
fill 32 237 311 32 237 312 minecraft:bone_block
fill 33 237 279 33 237 280 minecraft:bone_block
fill 33 237 312 33 237 313 minecraft:bone_block
fill 34 237 278 34 237 279 minecraft:bone_block
fill 34 237 313 34 237 314 minecraft:bone_block
fill 35 237 291 38 237 291 minecraft:bone_block
fill 35 237 301 38 237 301 minecraft:bone_block
fill 38 237 290 41 237 290 minecraft:bone_block
fill 38 237 302 41 237 302 minecraft:bone_block
setblock 41 237 289 minecraft:bone_block
setblock 41 237 303 minecraft:bone_block
fill 0 238 289 0 276 289 minecraft:deepslate_tiles
fill 0 238 303 0 308 303 minecraft:deepslate_tiles
fill 13 238 289 14 245 293 minecraft:red_nether_bricks
fill 14 238 288 15 244 288 minecraft:red_nether_bricks
fill 14 238 294 15 244 294 minecraft:red_nether_bricks
fill 15 238 287 16 244 287 minecraft:red_nether_bricks
setblock 15 238 291 minecraft:quartz_block
fill 15 238 295 16 244 295 minecraft:red_nether_bricks
fill 16 238 286 19 242 286 minecraft:red_nether_bricks
fill 16 238 288 16 238 289 minecraft:quartz_block
fill 16 238 293 16 238 294 minecraft:quartz_block
fill 16 238 296 19 242 296 minecraft:red_nether_bricks
fill 17 238 287 18 238 287 minecraft:quartz_block
fill 17 238 288 17 239 288 minecraft:red_nether_bricks
fill 17 238 294 17 239 294 minecraft:red_nether_bricks
fill 17 238 295 18 238 295 minecraft:quartz_block
fill 19 238 285 20 245 285 minecraft:red_nether_bricks
fill 19 238 297 20 238 301 minecraft:red_nether_bricks
setblock 20 238 286 minecraft:quartz_block
setblock 20 238 296 minecraft:quartz_block
fill 20 238 302 20 238 306 minecraft:red_nether_bricks
fill 21 238 275 21 308 275 minecraft:deepslate_tiles
setblock 21 238 283 minecraft:bone_block
fill 21 238 286 24 242 286 minecraft:red_nether_bricks
fill 21 238 297 21 245 297 minecraft:red_nether_bricks
fill 21 238 302 22 238 302 minecraft:red_nether_bricks
fill 21 238 304 22 238 304 minecraft:red_nether_bricks
setblock 21 238 307 minecraft:bone_block
setblock 21 238 308 minecraft:red_nether_bricks
setblock 21 238 309 minecraft:bone_block
fill 21 238 317 21 290 317 minecraft:deepslate_tiles
fill 22 238 280 22 238 282 minecraft:red_nether_bricks
fill 22 238 287 23 238 287 minecraft:quartz_block
fill 22 238 295 23 238 295 minecraft:quartz_block
setblock 22 238 303 minecraft:red_nether_bricks
fill 23 238 280 25 238 282 minecraft:orange_terracotta
fill 23 238 288 23 239 288 minecraft:red_nether_bricks
fill 23 238 294 23 239 294 minecraft:red_nether_bricks
fill 24 238 283 25 239 283 minecraft:red_nether_bricks
fill 24 238 287 25 244 287 minecraft:red_nether_bricks
fill 24 238 288 24 238 289 minecraft:quartz_block
setblock 24 238 290 minecraft:red_nether_bricks
setblock 24 238 292 minecraft:red_nether_bricks
fill 24 238 293 24 238 294 minecraft:quartz_block
fill 24 238 295 24 244 296 minecraft:red_nether_bricks
fill 25 238 279 25 240 279 minecraft:red_nether_bricks
fill 25 238 288 26 238 288 minecraft:red_nether_bricks
fill 25 238 290 31 242 290 minecraft:nether_bricks
setblock 25 238 291 minecraft:quartz_block
fill 25 238 292 31 242 292 minecraft:nether_bricks
fill 25 238 294 25 238 295 minecraft:red_nether_bricks
fill 26 238 280 26 238 282 minecraft:red_nether_bricks
setblock 26 238 283 minecraft:nether_wart_block
fill 26 238 284 26 239 284 minecraft:red_nether_bricks
fill 26 238 289 30 244 289 minecraft:nether_bricks
fill 26 238 291 31 244 291 minecraft:nether_bricks
fill 26 238 293 30 244 293 minecraft:nether_bricks
setblock 26 238 294 minecraft:red_nether_bricks
setblock 27 238 280 minecraft:nether_wart_block
fill 27 238 281 27 240 281 minecraft:red_nether_bricks
fill 27 238 282 27 242 282 minecraft:bone_block
fill 27 238 283 29 238 283 minecraft:red_nether_bricks
setblock 27 238 284 minecraft:nether_wart_block
setblock 28 238 280 minecraft:red_nether_bricks
setblock 28 238 281 minecraft:nether_wart_block
fill 28 238 282 28 240 282 minecraft:red_nether_bricks
fill 28 238 284 30 238 284 minecraft:red_nether_bricks
setblock 28 238 285 minecraft:nether_wart_block
fill 29 238 281 30 238 281 minecraft:red_nether_bricks
setblock 29 238 282 minecraft:nether_wart_block
setblock 29 238 285 minecraft:red_nether_bricks
fill 30 238 282 31 238 282 minecraft:red_nether_bricks
setblock 30 238 283 minecraft:nether_wart_block
setblock 31 238 283 minecraft:red_nether_bricks
setblock 31 238 284 minecraft:nether_wart_block
setblock 31 238 285 minecraft:red_nether_bricks
setblock 32 238 284 minecraft:red_nether_bricks
fill 42 238 289 42 308 289 minecraft:deepslate_tiles
fill 42 238 303 42 308 303 minecraft:deepslate_tiles
fill 3 239 278 3 240 278 minecraft:light[level=12]
setblock 3 239 286 minecraft:light[level=12]
setblock 3 239 294 minecraft:light[level=12]
setblock 3 239 302 minecraft:light[level=12]
setblock 3 239 310 minecraft:light[level=12]
setblock 11 239 278 minecraft:light[level=12]
setblock 11 239 286 minecraft:light[level=12]
setblock 11 239 294 minecraft:light[level=12]
setblock 11 239 302 minecraft:light[level=12]
setblock 11 239 310 minecraft:light[level=12]
fill 12 239 289 12 246 293 minecraft:red_nether_bricks
fill 13 239 288 13 247 288 minecraft:red_nether_bricks
fill 13 239 294 13 247 294 minecraft:red_nether_bricks
fill 14 239 287 14 247 287 minecraft:red_nether_bricks
fill 14 239 295 14 247 295 minecraft:red_nether_bricks
fill 15 239 286 15 247 286 minecraft:red_nether_bricks
fill 15 239 291 15 241 291 minecraft:red_nether_bricks
fill 15 239 296 15 247 296 minecraft:red_nether_bricks
fill 16 239 285 18 246 285 minecraft:red_nether_bricks
fill 16 239 288 16 240 289 minecraft:red_nether_bricks
fill 16 239 293 16 240 294 minecraft:red_nether_bricks
fill 16 239 297 20 245 297 minecraft:red_nether_bricks
fill 17 239 287 18 240 287 minecraft:red_nether_bricks
fill 17 239 295 18 240 295 minecraft:red_nether_bricks
setblock 19 239 278 minecraft:light[level=12]
setblock 19 239 302 minecraft:light[level=12]
setblock 19 239 310 minecraft:light[level=12]
fill 20 239 280 24 239 281 minecraft:orange_terracotta
fill 20 239 286 20 241 286 minecraft:red_nether_bricks
fill 20 239 296 20 241 296 minecraft:red_nether_bricks
fill 21 239 282 21 240 282 minecraft:orange_terracotta
fill 21 239 285 24 245 285 minecraft:red_nether_bricks
fill 22 239 279 22 241 279 minecraft:red_nether_bricks
setblock 22 239 282 minecraft:nether_wart_block
fill 22 239 283 22 241 283 minecraft:red_nether_bricks
fill 22 239 287 23 240 287 minecraft:red_nether_bricks
fill 22 239 295 23 240 295 minecraft:red_nether_bricks
setblock 23 239 279 minecraft:nether_wart_block
fill 23 239 282 24 239 282 minecraft:orange_terracotta
setblock 23 239 283 minecraft:nether_wart_block
setblock 24 239 279 minecraft:red_nether_bricks
setblock 24 239 288 minecraft:red_nether_bricks
fill 24 239 289 25 240 289 minecraft:nether_bricks
fill 24 239 293 25 240 293 minecraft:nether_bricks
setblock 24 239 294 minecraft:red_nether_bricks
fill 24 239 297 24 246 297 minecraft:red_nether_bricks
fill 25 239 280 27 239 280 minecraft:red_nether_bricks
setblock 25 239 281 minecraft:orange_terracotta
fill 25 239 282 25 241 282 minecraft:red_nether_bricks
setblock 25 239 284 minecraft:red_nether_bricks
fill 25 239 286 25 247 286 minecraft:red_nether_bricks
fill 25 239 288 31 243 288 minecraft:nether_bricks
fill 25 239 291 25 241 291 minecraft:nether_bricks
fill 25 239 294 31 243 294 minecraft:nether_bricks
fill 25 239 295 25 246 296 minecraft:red_nether_bricks
setblock 26 239 279 minecraft:red_nether_bricks
setblock 26 239 281 minecraft:red_nether_bricks
setblock 26 239 282 minecraft:nether_wart_block
fill 26 239 283 26 240 283 minecraft:red_nether_bricks
setblock 26 239 287 minecraft:red_nether_bricks
setblock 26 239 295 minecraft:red_nether_bricks
setblock 27 239 278 minecraft:light[level=12]
setblock 27 239 283 minecraft:nether_wart_block
setblock 27 239 284 minecraft:red_nether_bricks
setblock 27 239 286 minecraft:light[level=12]
setblock 27 239 302 minecraft:light[level=12]
setblock 27 239 310 minecraft:light[level=12]
setblock 28 239 280 minecraft:nether_wart_block
fill 28 239 281 28 240 281 minecraft:red_nether_bricks
fill 28 239 283 30 239 283 minecraft:red_nether_bricks
setblock 28 239 284 minecraft:nether_wart_block
setblock 29 239 281 minecraft:nether_wart_block
setblock 29 239 282 minecraft:red_nether_bricks
fill 29 239 284 30 239 284 minecraft:red_nether_bricks
setblock 30 239 282 minecraft:nether_wart_block
fill 31 239 289 32 241 289 minecraft:nether_bricks
fill 31 239 293 32 241 293 minecraft:nether_bricks
fill 32 239 290 32 243 292 minecraft:nether_bricks
fill 33 239 291 33 243 291 minecraft:nether_bricks
setblock 35 239 278 minecraft:light[level=12]
setblock 35 239 286 minecraft:light[level=12]
setblock 35 239 294 minecraft:light[level=12]
setblock 35 239 302 minecraft:light[level=12]
setblock 35 239 310 minecraft:light[level=12]
setblock 3 240 285 minecraft:light[level=12]
setblock 3 240 292 minecraft:light[level=12]
setblock 3 240 299 minecraft:light[level=12]
setblock 3 240 306 minecraft:light[level=12]
setblock 3 240 313 minecraft:light[level=12]
fill 5 240 280 7 243 280 minecraft:blackstone
fill 6 240 279 6 243 279 minecraft:blackstone
fill 6 240 281 6 243 281 minecraft:blackstone
setblock 10 240 278 minecraft:light[level=12]
setblock 10 240 285 minecraft:light[level=12]
setblock 10 240 292 minecraft:light[level=12]
setblock 10 240 299 minecraft:light[level=12]
setblock 10 240 306 minecraft:light[level=12]
setblock 10 240 313 minecraft:light[level=12]
fill 11 240 290 11 245 292 minecraft:red_nether_bricks
fill 12 240 288 12 246 288 minecraft:red_nether_bricks
fill 12 240 294 12 246 294 minecraft:red_nether_bricks
fill 13 240 287 13 246 287 minecraft:red_nether_bricks
fill 13 240 295 13 246 295 minecraft:red_nether_bricks
fill 14 240 286 14 246 286 minecraft:red_nether_bricks
fill 14 240 296 14 246 296 minecraft:red_nether_bricks
fill 15 240 285 15 245 285 minecraft:red_nether_bricks
fill 15 240 297 15 245 297 minecraft:red_nether_bricks
fill 16 240 275 17 308 275 minecraft:deepslate_tiles
setblock 17 240 278 minecraft:light[level=12]
fill 17 240 284 23 244 284 minecraft:red_nether_bricks
fill 17 240 298 23 244 298 minecraft:red_nether_bricks
setblock 17 240 299 minecraft:light[level=12]
setblock 17 240 306 minecraft:light[level=12]
setblock 17 240 313 minecraft:light[level=12]
setblock 18 240 275 minecraft:amethyst_block
setblock 18 240 280 minecraft:red_nether_bricks
setblock 18 240 281 minecraft:nether_wart_block
fill 19 240 275 20 308 275 minecraft:deepslate_tiles
fill 19 240 280 22 240 281 minecraft:orange_terracotta
setblock 19 240 282 minecraft:nether_wart_block
setblock 20 240 279 minecraft:nether_wart_block
setblock 20 240 282 minecraft:orange_terracotta
setblock 21 240 279 minecraft:red_nether_bricks
setblock 21 240 283 minecraft:red_nether_bricks
fill 22 240 282 22 242 282 minecraft:red_nether_bricks
fill 23 240 279 23 240 281 minecraft:red_nether_bricks
setblock 23 240 282 minecraft:nether_wart_block
fill 23 240 283 23 241 283 minecraft:red_nether_bricks
setblock 24 240 278 minecraft:light[level=12]
setblock 24 240 279 minecraft:nether_wart_block
fill 24 240 280 24 240 282 minecraft:red_nether_bricks
setblock 24 240 283 minecraft:nether_wart_block
fill 24 240 288 24 241 288 minecraft:nether_bricks
fill 24 240 294 24 241 294 minecraft:nether_bricks
setblock 24 240 299 minecraft:light[level=12]
setblock 24 240 306 minecraft:light[level=12]
setblock 24 240 313 minecraft:light[level=12]
setblock 25 240 280 minecraft:nether_wart_block
fill 25 240 281 25 242 281 minecraft:red_nether_bricks
setblock 25 240 283 minecraft:red_nether_bricks
fill 25 240 285 25 245 285 minecraft:red_nether_bricks
fill 25 240 297 25 245 297 minecraft:red_nether_bricks
fill 26 240 280 27 240 280 minecraft:red_nether_bricks
setblock 26 240 281 minecraft:nether_wart_block
fill 26 240 282 26 241 282 minecraft:red_nether_bricks
fill 26 240 286 26 246 286 minecraft:red_nether_bricks
fill 26 240 287 30 242 287 minecraft:nether_bricks
fill 26 240 295 30 242 295 minecraft:nether_bricks
fill 26 240 296 26 246 296 minecraft:red_nether_bricks
setblock 27 240 283 minecraft:red_nether_bricks
setblock 28 240 283 minecraft:nether_wart_block
setblock 31 240 278 minecraft:light[level=12]
setblock 31 240 285 minecraft:light[level=12]
setblock 31 240 299 minecraft:light[level=12]
setblock 31 240 306 minecraft:light[level=12]
setblock 31 240 313 minecraft:light[level=12]
fill 32 240 288 32 242 288 minecraft:nether_bricks
fill 32 240 294 32 242 294 minecraft:nether_bricks
fill 33 240 289 33 242 290 minecraft:nether_bricks
fill 33 240 292 33 242 293 minecraft:nether_bricks
fill 37 240 317 38 299 317 minecraft:deepslate_tiles
setblock 38 240 278 minecraft:light[level=12]
setblock 38 240 285 minecraft:light[level=12]
setblock 38 240 292 minecraft:light[level=12]
setblock 38 240 299 minecraft:light[level=12]
setblock 38 240 306 minecraft:light[level=12]
setblock 38 240 313 minecraft:light[level=12]
setblock 39 240 317 minecraft:crying_obsidian
fill 40 240 317 40 308 317 minecraft:deepslate_tiles
fill 0 241 310 0 308 312 minecraft:deepslate_tiles
setblock 0 241 313 minecraft:crying_obsidian
fill 0 241 314 0 279 317 minecraft:deepslate_tiles
fill 11 241 289 11 245 289 minecraft:red_nether_bricks
fill 11 241 293 11 245 293 minecraft:red_nether_bricks
fill 12 241 287 12 245 287 minecraft:red_nether_bricks
fill 12 241 295 12 245 295 minecraft:red_nether_bricks
fill 13 241 286 13 245 286 minecraft:red_nether_bricks
fill 13 241 296 13 245 296 minecraft:red_nether_bricks
fill 14 241 285 14 247 285 minecraft:red_nether_bricks
fill 14 241 297 14 244 297 minecraft:red_nether_bricks
fill 16 241 281 18 242 282 minecraft:orange_terracotta
fill 16 241 284 16 245 284 minecraft:red_nether_bricks
setblock 16 241 288 minecraft:red_nether_bricks
setblock 16 241 294 minecraft:red_nether_bricks
fill 16 241 298 16 244 298 minecraft:red_nether_bricks
fill 17 241 280 18 241 280 minecraft:orange_terracotta
setblock 17 241 287 minecraft:red_nether_bricks
setblock 17 241 295 minecraft:red_nether_bricks
fill 18 241 275 18 308 275 minecraft:deepslate_tiles
fill 18 241 279 20 241 279 minecraft:red_nether_bricks
fill 18 241 283 20 241 283 minecraft:red_nether_bricks
setblock 19 241 280 minecraft:red_nether_bricks
fill 19 241 281 21 241 281 minecraft:orange_terracotta
fill 19 241 282 19 243 282 minecraft:red_nether_bricks
setblock 20 241 280 minecraft:orange_terracotta
setblock 20 241 282 minecraft:nether_wart_block
setblock 21 241 279 minecraft:nether_wart_block
fill 21 241 280 21 243 280 minecraft:red_nether_bricks
setblock 21 241 282 minecraft:red_nether_bricks
setblock 21 241 283 minecraft:nether_wart_block
setblock 22 241 280 minecraft:nether_wart_block
fill 22 241 281 22 243 281 minecraft:red_nether_bricks
fill 23 241 279 24 241 280 minecraft:red_nether_bricks
setblock 23 241 281 minecraft:nether_wart_block
fill 23 241 282 23 242 282 minecraft:red_nether_bricks
setblock 23 241 287 minecraft:red_nether_bricks
setblock 23 241 295 minecraft:red_nether_bricks
setblock 24 241 281 minecraft:red_nether_bricks
setblock 24 241 282 minecraft:nether_wart_block
fill 24 241 283 24 241 284 minecraft:red_nether_bricks
fill 24 241 298 24 244 298 minecraft:red_nether_bricks
setblock 25 241 280 minecraft:red_nether_bricks
setblock 25 241 283 minecraft:nether_wart_block
fill 25 241 289 25 243 289 minecraft:nether_bricks
fill 25 241 293 25 243 293 minecraft:nether_bricks
setblock 26 241 280 minecraft:nether_wart_block
setblock 26 241 281 minecraft:red_nether_bricks
fill 26 241 285 26 244 285 minecraft:red_nether_bricks
fill 26 241 297 26 244 297 minecraft:red_nether_bricks
fill 27 241 286 27 245 286 minecraft:red_nether_bricks
fill 27 241 296 27 245 296 minecraft:red_nether_bricks
fill 39 241 317 39 308 317 minecraft:deepslate_tiles
fill 42 241 291 42 252 295 minecraft:deepslate_tiles
setblock 42 241 296 minecraft:crying_obsidian
fill 42 241 297 42 251 298 minecraft:deepslate_tiles
fill 0 242 313 0 308 313 minecraft:deepslate_tiles
fill 5 242 279 5 243 279 minecraft:blackstone
fill 5 242 281 5 243 281 minecraft:blackstone
fill 7 242 279 7 243 279 minecraft:blackstone
fill 7 242 281 7 243 281 minecraft:blackstone
fill 11 242 288 11 244 288 minecraft:red_nether_bricks
fill 11 242 294 11 244 294 minecraft:red_nether_bricks
fill 14 242 282 14 244 283 minecraft:orange_terracotta
setblock 15 242 280 minecraft:nether_wart_block
fill 15 242 281 15 244 281 minecraft:red_nether_bricks
fill 15 242 282 15 244 282 minecraft:orange_terracotta
fill 15 242 283 17 242 283 minecraft:red_nether_bricks
setblock 16 242 280 minecraft:red_nether_bricks
fill 17 242 279 17 244 279 minecraft:red_nether_bricks
setblock 17 242 280 minecraft:orange_terracotta
setblock 18 242 279 minecraft:nether_wart_block
fill 18 242 280 18 244 280 minecraft:red_nether_bricks
setblock 18 242 283 minecraft:nether_wart_block
fill 19 242 279 21 242 279 minecraft:red_nether_bricks
setblock 19 242 280 minecraft:nether_wart_block
fill 19 242 281 19 244 281 minecraft:red_nether_bricks
fill 19 242 283 21 242 283 minecraft:red_nether_bricks
setblock 20 242 280 minecraft:red_nether_bricks
fill 20 242 281 20 245 281 minecraft:bone_block
fill 20 242 282 20 244 282 minecraft:red_nether_bricks
setblock 21 242 281 minecraft:red_nether_bricks
setblock 21 242 282 minecraft:nether_wart_block
setblock 22 242 279 minecraft:nether_wart_block
fill 22 242 280 22 243 280 minecraft:red_nether_bricks
setblock 22 242 283 minecraft:nether_wart_block
setblock 23 242 279 minecraft:red_nether_bricks
setblock 23 242 280 minecraft:nether_wart_block
fill 23 242 281 23 243 281 minecraft:red_nether_bricks
setblock 24 242 280 minecraft:red_nether_bricks
setblock 24 242 281 minecraft:nether_wart_block
setblock 24 242 282 minecraft:red_nether_bricks
fill 24 242 284 24 244 284 minecraft:red_nether_bricks
fill 31 242 289 31 244 289 minecraft:nether_bricks
fill 31 242 293 31 244 293 minecraft:nether_bricks
fill 32 242 289 32 243 289 minecraft:black_concrete
fill 32 242 293 32 243 293 minecraft:black_concrete
fill 42 242 296 42 308 296 minecraft:deepslate_tiles
setblock 13 243 281 minecraft:nether_wart_block
fill 13 243 282 13 244 284 minecraft:orange_terracotta
fill 14 243 280 14 243 281 minecraft:red_nether_bricks
fill 14 243 284 15 243 284 minecraft:red_nether_bricks
fill 15 243 280 15 245 280 minecraft:red_nether_bricks
fill 15 243 283 15 244 283 minecraft:orange_terracotta
setblock 15 243 289 minecraft:red_nether_bricks
setblock 15 243 293 minecraft:red_nether_bricks
setblock 16 243 279 minecraft:red_nether_bricks
setblock 16 243 280 minecraft:nether_wart_block
fill 16 243 281 17 243 282 minecraft:orange_terracotta
fill 16 243 283 18 243 283 minecraft:red_nether_bricks
fill 16 243 286 18 243 286 minecraft:red_nether_bricks
fill 16 243 296 18 243 296 minecraft:red_nether_bricks
setblock 16 243 317 minecraft:crying_obsidian
setblock 17 243 280 minecraft:red_nether_bricks
fill 18 243 279 18 244 279 minecraft:red_nether_bricks
setblock 18 243 281 minecraft:red_nether_bricks
setblock 18 243 282 minecraft:nether_wart_block
setblock 19 243 279 minecraft:nether_wart_block
fill 19 243 280 19 244 280 minecraft:red_nether_bricks
setblock 19 243 283 minecraft:nether_wart_block
fill 20 243 279 21 243 279 minecraft:red_nether_bricks
setblock 20 243 280 minecraft:nether_wart_block
setblock 20 243 283 minecraft:red_nether_bricks
setblock 21 243 281 minecraft:nether_wart_block
setblock 21 243 282 minecraft:red_nether_bricks
setblock 22 243 282 minecraft:nether_wart_block
fill 22 243 286 24 243 286 minecraft:red_nether_bricks
fill 26 243 287 28 245 287 minecraft:red_nether_bricks
fill 26 243 290 31 244 290 minecraft:nether_bricks
fill 26 243 292 31 244 292 minecraft:nether_bricks
fill 26 243 295 28 245 295 minecraft:red_nether_bricks
setblock 33 243 290 minecraft:nether_bricks
setblock 33 243 292 minecraft:nether_bricks
setblock 42 243 299 minecraft:crying_obsidian
fill 42 243 300 42 278 301 minecraft:deepslate_tiles
setblock 11 244 283 minecraft:red_nether_bricks
fill 11 244 284 12 245 285 minecraft:orange_terracotta
setblock 12 244 282 minecraft:red_nether_bricks
setblock 12 244 283 minecraft:orange_terracotta
fill 13 244 281 13 246 281 minecraft:red_nether_bricks
fill 13 244 285 13 246 285 minecraft:red_nether_bricks
setblock 14 244 280 minecraft:red_nether_bricks
setblock 14 244 281 minecraft:nether_wart_block
setblock 14 244 284 minecraft:orange_terracotta
fill 14 244 307 14 245 307 minecraft:gold_block
fill 15 244 284 15 245 284 minecraft:red_nether_bricks
setblock 16 244 279 minecraft:nether_wart_block
fill 16 244 280 16 244 282 minecraft:red_nether_bricks
setblock 16 244 283 minecraft:nether_wart_block
fill 16 244 286 17 244 286 minecraft:red_nether_bricks
fill 16 244 296 17 244 296 minecraft:red_nether_bricks
fill 16 244 317 19 305 317 minecraft:deepslate_tiles
setblock 17 244 280 minecraft:nether_wart_block
fill 17 244 281 17 244 283 minecraft:red_nether_bricks
setblock 18 244 281 minecraft:nether_wart_block
fill 18 244 282 18 244 283 minecraft:red_nether_bricks
setblock 19 244 279 minecraft:red_nether_bricks
setblock 19 244 282 minecraft:nether_wart_block
setblock 19 244 283 minecraft:red_nether_bricks
setblock 20 244 280 minecraft:red_nether_bricks
setblock 20 244 317 minecraft:magma_block
setblock 21 244 281 minecraft:red_nether_bricks
fill 22 244 297 23 246 297 minecraft:red_nether_bricks
fill 23 244 286 24 244 286 minecraft:red_nether_bricks
setblock 23 244 296 minecraft:red_nether_bricks
fill 25 244 288 26 244 288 minecraft:red_nether_bricks
fill 25 244 294 26 244 294 minecraft:red_nether_bricks
fill 27 244 288 29 244 288 minecraft:nether_bricks
fill 27 244 294 29 244 294 minecraft:nether_bricks
setblock 32 244 291 minecraft:nether_bricks
fill 42 244 299 42 308 299 minecraft:deepslate_tiles
fill 9 245 285 9 246 285 minecraft:red_nether_bricks
setblock 10 245 283 minecraft:red_nether_bricks
fill 10 245 284 10 246 286 minecraft:orange_terracotta
fill 11 245 282 11 247 282 minecraft:red_nether_bricks
setblock 11 245 283 minecraft:orange_terracotta
fill 11 245 286 11 246 286 minecraft:orange_terracotta
setblock 12 245 281 minecraft:red_nether_bricks
setblock 12 245 282 minecraft:nether_wart_block
fill 12 245 283 12 247 283 minecraft:red_nether_bricks
setblock 12 245 286 minecraft:nether_wart_block
fill 13 245 282 15 245 282 minecraft:red_nether_bricks
setblock 13 245 283 minecraft:orange_terracotta
fill 13 245 284 13 247 284 minecraft:red_nether_bricks
setblock 14 245 280 minecraft:nether_wart_block
fill 14 245 281 14 246 281 minecraft:red_nether_bricks
fill 14 245 283 16 245 283 minecraft:red_nether_bricks
setblock 14 245 284 minecraft:nether_wart_block
fill 14 245 288 14 247 288 minecraft:red_nether_bricks
fill 14 245 294 14 247 294 minecraft:red_nether_bricks
setblock 15 245 281 minecraft:nether_wart_block
fill 15 245 287 15 246 287 minecraft:red_nether_bricks
fill 15 245 295 15 246 295 minecraft:red_nether_bricks
fill 16 245 280 17 245 281 minecraft:red_nether_bricks
setblock 16 245 282 minecraft:nether_wart_block
fill 16 245 286 16 246 286 minecraft:red_nether_bricks
fill 16 245 296 16 246 296 minecraft:red_nether_bricks
fill 17 245 282 18 245 282 minecraft:red_nether_bricks
setblock 17 245 283 minecraft:nether_wart_block
setblock 17 245 284 minecraft:red_nether_bricks
setblock 17 245 298 minecraft:red_nether_bricks
setblock 18 245 280 minecraft:nether_wart_block
setblock 18 245 281 minecraft:red_nether_bricks
setblock 18 245 284 minecraft:black_concrete
setblock 18 245 298 minecraft:black_concrete
setblock 19 245 281 minecraft:nether_wart_block
fill 19 245 284 23 245 284 minecraft:red_nether_bricks
fill 19 245 298 23 245 298 minecraft:red_nether_bricks
fill 20 245 317 20 308 317 minecraft:deepslate_tiles
fill 24 245 286 24 246 286 minecraft:red_nether_bricks
fill 24 245 296 24 246 296 minecraft:red_nether_bricks
fill 25 245 287 25 246 287 minecraft:red_nether_bricks
fill 26 245 288 26 245 294 minecraft:red_nether_bricks
fill 27 245 288 28 246 290 minecraft:red_nether_bricks
fill 27 245 291 29 245 291 minecraft:nether_bricks
fill 27 245 292 28 246 294 minecraft:red_nether_bricks
fill 29 245 289 29 245 290 minecraft:red_nether_bricks
fill 29 245 292 29 245 293 minecraft:red_nether_bricks
setblock 3 246 278 minecraft:light[level=12]
fill 3 246 285 3 246 286 minecraft:light[level=12]
setblock 3 246 292 minecraft:light[level=12]
setblock 3 246 294 minecraft:light[level=12]
setblock 3 246 299 minecraft:light[level=12]
setblock 3 246 302 minecraft:light[level=12]
setblock 3 246 306 minecraft:light[level=12]
setblock 3 246 310 minecraft:light[level=12]
setblock 3 246 313 minecraft:light[level=12]
setblock 8 246 285 minecraft:nether_wart_block
fill 8 246 286 9 247 288 minecraft:orange_terracotta
fill 9 246 284 9 247 284 minecraft:red_nether_bricks
fill 10 246 278 11 246 278 minecraft:light[level=12]
setblock 10 246 283 minecraft:nether_wart_block
fill 10 246 287 10 247 287 minecraft:orange_terracotta
setblock 10 246 292 minecraft:light[level=12]
setblock 10 246 299 minecraft:light[level=12]
setblock 10 246 306 minecraft:light[level=12]
setblock 10 246 313 minecraft:light[level=12]
setblock 11 246 283 minecraft:red_nether_bricks
fill 11 246 284 11 246 285 minecraft:orange_terracotta
setblock 11 246 287 minecraft:red_nether_bricks
setblock 11 246 294 minecraft:light[level=12]
setblock 11 246 302 minecraft:light[level=12]
setblock 11 246 310 minecraft:light[level=12]
setblock 12 246 281 minecraft:nether_wart_block
fill 12 246 282 12 247 282 minecraft:red_nether_bricks
setblock 12 246 284 minecraft:orange_terracotta
setblock 12 246 285 minecraft:nether_wart_block
fill 12 246 286 12 248 286 minecraft:red_nether_bricks
setblock 13 246 282 minecraft:nether_wart_block
fill 13 246 283 13 249 283 minecraft:bone_block
setblock 13 246 286 minecraft:nether_wart_block
fill 13 246 289 13 247 293 minecraft:red_nether_bricks
fill 14 246 282 16 246 282 minecraft:red_nether_bricks
setblock 14 246 283 minecraft:nether_wart_block
fill 14 246 284 14 247 284 minecraft:red_nether_bricks
setblock 14 246 289 minecraft:red_nether_bricks
setblock 14 246 293 minecraft:red_nether_bricks
setblock 15 246 281 minecraft:red_nether_bricks
fill 15 246 283 18 246 283 minecraft:black_concrete
setblock 15 246 284 minecraft:nether_wart_block
fill 15 246 299 18 246 299 minecraft:black_concrete
setblock 16 246 281 minecraft:nether_wart_block
fill 16 246 297 18 246 297 minecraft:red_nether_bricks
setblock 17 246 278 minecraft:light[level=12]
setblock 17 246 281 minecraft:red_nether_bricks
setblock 17 246 282 minecraft:nether_wart_block
setblock 17 246 306 minecraft:light[level=12]
setblock 17 246 313 minecraft:light[level=12]
setblock 19 246 278 minecraft:light[level=12]
fill 19 246 284 21 246 284 minecraft:red_nether_bricks
fill 19 246 298 21 246 298 minecraft:red_nether_bricks
setblock 19 246 302 minecraft:light[level=12]
setblock 19 246 310 minecraft:light[level=12]
fill 22 246 285 24 246 285 minecraft:red_nether_bricks
setblock 24 246 278 minecraft:light[level=12]
setblock 24 246 299 minecraft:light[level=12]
setblock 24 246 306 minecraft:light[level=12]
setblock 24 246 313 minecraft:light[level=12]
fill 26 246 287 26 246 289 minecraft:red_nether_bricks
fill 26 246 293 26 246 295 minecraft:red_nether_bricks
setblock 27 246 278 minecraft:light[level=12]
setblock 27 246 286 minecraft:light[level=12]
setblock 27 246 287 minecraft:red_nether_bricks
fill 27 246 291 28 247 291 minecraft:red_nether_bricks
setblock 27 246 295 minecraft:red_nether_bricks
setblock 27 246 302 minecraft:light[level=12]
setblock 27 246 310 minecraft:light[level=12]
setblock 31 246 278 minecraft:light[level=12]
setblock 31 246 285 minecraft:light[level=12]
setblock 31 246 292 minecraft:light[level=12]
setblock 31 246 299 minecraft:light[level=12]
setblock 31 246 306 minecraft:light[level=12]
setblock 31 246 313 minecraft:light[level=12]
setblock 35 246 278 minecraft:light[level=12]
setblock 35 246 286 minecraft:light[level=12]
setblock 35 246 294 minecraft:light[level=12]
setblock 35 246 302 minecraft:light[level=12]
setblock 35 246 310 minecraft:light[level=12]
setblock 38 246 278 minecraft:light[level=12]
setblock 38 246 285 minecraft:light[level=12]
setblock 38 246 292 minecraft:light[level=12]
setblock 38 246 299 minecraft:light[level=12]
setblock 38 246 306 minecraft:light[level=12]
setblock 38 246 313 minecraft:light[level=12]
fill 0 247 290 0 308 290 minecraft:deepslate_tiles
setblock 0 247 291 minecraft:crying_obsidian
setblock 7 247 286 minecraft:red_nether_bricks
setblock 7 247 287 minecraft:nether_wart_block
setblock 7 247 288 minecraft:orange_terracotta
setblock 7 247 289 minecraft:red_nether_bricks
setblock 8 247 284 minecraft:nether_wart_block
fill 8 247 285 8 249 285 minecraft:red_nether_bricks
fill 8 247 289 8 249 289 minecraft:orange_terracotta
fill 9 247 283 10 247 283 minecraft:red_nether_bricks
setblock 9 247 285 minecraft:nether_wart_block
setblock 9 247 289 minecraft:nether_wart_block
fill 10 247 284 11 247 285 minecraft:red_nether_bricks
setblock 10 247 286 minecraft:nether_wart_block
fill 10 247 288 11 248 288 minecraft:red_nether_bricks
setblock 11 247 283 minecraft:nether_wart_block
setblock 11 247 286 minecraft:red_nether_bricks
setblock 11 247 287 minecraft:nether_wart_block
fill 12 247 281 14 247 281 minecraft:black_concrete
setblock 12 247 284 minecraft:nether_wart_block
fill 12 247 285 12 249 285 minecraft:red_nether_bricks
setblock 12 247 287 minecraft:red_nether_bricks
setblock 12 247 291 minecraft:red_nether_bricks
fill 12 247 301 14 247 301 minecraft:black_concrete
fill 13 247 282 17 247 282 minecraft:black_concrete
setblock 13 247 285 minecraft:nether_wart_block
setblock 13 247 286 minecraft:red_nether_bricks
fill 13 247 300 17 247 300 minecraft:black_concrete
setblock 14 247 283 minecraft:red_nether_bricks
setblock 15 247 283 minecraft:nether_wart_block
setblock 18 247 283 minecraft:black_concrete
setblock 18 247 299 minecraft:black_concrete
setblock 25 247 296 minecraft:red_nether_bricks
fill 26 247 287 26 247 288 minecraft:red_nether_bricks
fill 26 247 294 26 247 295 minecraft:red_nether_bricks
fill 27 247 288 27 247 290 minecraft:red_nether_bricks
fill 27 247 292 27 247 294 minecraft:red_nether_bricks
fill 34 247 291 35 248 293 minecraft:raw_gold_block
fill 0 248 291 0 308 291 minecraft:deepslate_tiles
setblock 0 248 300 minecraft:purple_concrete
fill 6 248 287 7 248 288 minecraft:red_nether_bricks
setblock 6 248 289 minecraft:nether_wart_block
fill 6 248 290 7 249 291 minecraft:orange_terracotta
setblock 7 248 286 minecraft:nether_wart_block
fill 7 248 289 7 249 289 minecraft:orange_terracotta
setblock 8 248 284 minecraft:red_nether_bricks
fill 8 248 286 10 248 286 minecraft:red_nether_bricks
fill 8 248 287 9 248 288 minecraft:orange_terracotta
fill 8 248 290 8 249 290 minecraft:orange_terracotta
setblock 8 248 291 minecraft:nether_wart_block
setblock 9 248 284 minecraft:nether_wart_block
fill 9 248 285 9 250 285 minecraft:red_nether_bricks
fill 9 248 289 9 249 290 minecraft:red_nether_bricks
setblock 10 248 280 minecraft:black_concrete
fill 10 248 283 11 248 284 minecraft:red_nether_bricks
setblock 10 248 285 minecraft:nether_wart_block
fill 10 248 287 11 249 287 minecraft:red_nether_bricks
setblock 10 248 289 minecraft:nether_wart_block
setblock 10 248 302 minecraft:black_concrete
setblock 11 248 285 minecraft:red_nether_bricks
schedule function dropper:buildpart/60_5 1t
