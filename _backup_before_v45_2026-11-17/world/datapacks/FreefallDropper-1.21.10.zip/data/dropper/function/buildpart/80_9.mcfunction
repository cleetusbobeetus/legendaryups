setblock 417 286 359 minecraft:polished_deepslate
fill 417 286 360 417 289 360 minecraft:gray_concrete
fill 418 286 334 418 308 334 minecraft:gray_concrete
fill 376 287 335 376 287 339 minecraft:gray_concrete
fill 376 287 346 376 297 346 minecraft:gray_concrete
fill 377 287 334 377 287 337 minecraft:gray_concrete
setblock 377 287 338 minecraft:polished_deepslate
fill 377 287 339 377 290 339 minecraft:gray_concrete
fill 377 287 341 377 287 342 minecraft:gray_concrete
setblock 377 287 343 minecraft:polished_deepslate
setblock 377 287 344 minecraft:gray_concrete
setblock 377 287 349 minecraft:gray_concrete
setblock 377 287 352 minecraft:gray_concrete
setblock 377 287 353 minecraft:yellow_concrete
fill 377 287 354 377 287 357 minecraft:gray_concrete
setblock 377 287 358 minecraft:polished_deepslate
fill 377 287 359 377 290 359 minecraft:gray_concrete
fill 377 287 361 377 287 362 minecraft:gray_concrete
setblock 377 287 363 minecraft:polished_deepslate
fill 378 287 353 378 287 356 minecraft:gray_concrete
setblock 378 287 357 minecraft:polished_deepslate
fill 378 287 358 378 289 358 minecraft:gray_concrete
setblock 378 287 362 minecraft:polished_deepslate
fill 378 287 363 378 290 363 minecraft:gray_concrete
setblock 379 287 357 minecraft:gray_concrete
fill 379 287 362 379 288 362 minecraft:gray_concrete
fill 380 287 355 382 300 356 minecraft:polished_deepslate
fill 381 287 348 382 288 349 minecraft:light_gray_wool
setblock 382 287 363 minecraft:polished_deepslate
fill 383 287 363 386 287 363 minecraft:gray_concrete
setblock 387 287 363 minecraft:polished_deepslate
setblock 388 287 362 minecraft:polished_deepslate
fill 388 287 363 391 287 363 minecraft:gray_concrete
fill 389 287 362 392 287 362 minecraft:gray_concrete
setblock 391 287 323 minecraft:gray_concrete
setblock 392 287 323 minecraft:polished_deepslate
setblock 392 287 363 minecraft:polished_deepslate
fill 393 287 323 393 290 323 minecraft:gray_concrete
setblock 393 287 362 minecraft:polished_deepslate
fill 393 287 363 393 290 363 minecraft:gray_concrete
fill 394 287 362 394 288 362 minecraft:gray_concrete
setblock 396 287 364 minecraft:light_blue_stained_glass
setblock 397 287 363 minecraft:polished_deepslate
setblock 406 287 323 minecraft:gray_concrete
setblock 406 287 363 minecraft:gray_concrete
setblock 407 287 323 minecraft:polished_deepslate
setblock 407 287 363 minecraft:polished_deepslate
fill 408 287 323 411 287 323 minecraft:gray_concrete
setblock 408 287 362 minecraft:polished_deepslate
fill 408 287 363 411 287 363 minecraft:gray_concrete
fill 409 287 324 410 287 324 minecraft:gray_concrete
fill 409 287 362 412 287 362 minecraft:gray_concrete
fill 410 287 361 413 287 361 minecraft:gray_concrete
setblock 411 287 324 minecraft:polished_deepslate
fill 411 287 339 411 288 341 minecraft:black_concrete
setblock 412 287 323 minecraft:polished_deepslate
fill 412 287 324 412 290 324 minecraft:gray_concrete
fill 412 287 338 414 288 338 minecraft:black_concrete
fill 412 287 342 412 288 342 minecraft:black_concrete
setblock 412 287 363 minecraft:polished_deepslate
fill 413 287 323 413 290 323 minecraft:gray_concrete
setblock 413 287 362 minecraft:polished_deepslate
fill 413 287 363 413 290 363 minecraft:gray_concrete
fill 414 287 342 415 288 342 minecraft:black_concrete
setblock 414 287 361 minecraft:polished_deepslate
fill 414 287 362 414 290 362 minecraft:gray_concrete
fill 414 287 364 414 292 364 minecraft:gray_concrete
setblock 415 287 324 minecraft:gray_concrete
fill 415 287 339 415 288 339 minecraft:black_concrete
fill 415 287 340 415 300 340 minecraft:polished_deepslate
fill 415 287 341 415 288 341 minecraft:black_concrete
setblock 415 287 356 minecraft:gray_concrete
setblock 415 287 360 minecraft:polished_deepslate
fill 415 287 361 415 290 361 minecraft:gray_concrete
setblock 416 287 322 minecraft:light_blue_stained_glass
setblock 416 287 323 minecraft:gray_concrete
setblock 416 287 324 minecraft:polished_deepslate
setblock 416 287 334 minecraft:polished_deepslate
setblock 416 287 335 minecraft:gray_concrete
setblock 416 287 339 minecraft:polished_deepslate
setblock 416 287 354 minecraft:polished_deepslate
fill 416 287 355 416 288 355 minecraft:gray_concrete
setblock 416 287 359 minecraft:polished_deepslate
fill 416 287 360 416 290 360 minecraft:gray_concrete
fill 417 287 322 417 308 322 minecraft:gray_concrete
setblock 417 287 323 minecraft:polished_deepslate
fill 417 287 324 417 287 327 minecraft:gray_concrete
setblock 417 287 328 minecraft:polished_deepslate
setblock 417 287 329 minecraft:gray_concrete
setblock 417 287 333 minecraft:polished_deepslate
fill 417 287 334 417 288 334 minecraft:gray_concrete
setblock 417 287 338 minecraft:polished_deepslate
fill 417 287 339 417 289 339 minecraft:gray_concrete
setblock 417 287 352 minecraft:gray_concrete
setblock 417 287 353 minecraft:polished_deepslate
fill 417 287 354 417 288 354 minecraft:gray_concrete
setblock 417 287 358 minecraft:polished_deepslate
fill 417 287 359 417 290 359 minecraft:gray_concrete
setblock 417 287 363 minecraft:polished_deepslate
fill 376 288 335 376 288 338 minecraft:gray_concrete
setblock 376 288 339 minecraft:light_blue_stained_glass
setblock 377 288 336 minecraft:gray_concrete
setblock 377 288 337 minecraft:polished_deepslate
fill 377 288 338 377 289 338 minecraft:gray_concrete
setblock 377 288 341 minecraft:gray_concrete
setblock 377 288 342 minecraft:polished_deepslate
fill 377 288 343 377 291 343 minecraft:gray_concrete
fill 377 288 349 377 291 350 minecraft:light_blue_stained_glass
setblock 377 288 352 minecraft:polished_deepslate
fill 377 288 353 377 289 353 minecraft:gray_concrete
setblock 377 288 354 minecraft:ochre_froglight
fill 377 288 355 377 288 356 minecraft:gray_concrete
setblock 377 288 357 minecraft:polished_deepslate
fill 377 288 358 377 291 358 minecraft:gray_concrete
setblock 377 288 361 minecraft:gray_concrete
setblock 377 288 362 minecraft:polished_deepslate
fill 377 288 363 377 291 363 minecraft:gray_concrete
fill 378 288 350 378 291 352 minecraft:light_blue_stained_glass
setblock 378 288 355 minecraft:gray_concrete
setblock 378 288 356 minecraft:polished_deepslate
fill 378 288 357 378 289 357 minecraft:gray_concrete
setblock 378 288 361 minecraft:polished_deepslate
fill 378 288 362 378 290 362 minecraft:gray_concrete
fill 379 288 351 379 292 351 minecraft:light_blue_stained_glass
fill 381 288 354 381 289 354 minecraft:black_concrete
fill 381 288 357 381 289 357 minecraft:black_concrete
setblock 381 288 363 minecraft:polished_deepslate
fill 382 288 363 385 288 363 minecraft:gray_concrete
setblock 386 288 363 minecraft:polished_deepslate
fill 387 288 363 390 288 363 minecraft:gray_concrete
fill 388 288 362 391 288 362 minecraft:gray_concrete
setblock 391 288 323 minecraft:polished_deepslate
setblock 391 288 363 minecraft:polished_deepslate
fill 392 288 323 392 291 323 minecraft:gray_concrete
setblock 392 288 362 minecraft:polished_deepslate
fill 392 288 363 392 291 363 minecraft:gray_concrete
fill 393 288 362 393 289 362 minecraft:gray_concrete
setblock 396 288 363 minecraft:polished_deepslate
fill 396 288 364 396 308 364 minecraft:gray_concrete
setblock 405 288 323 minecraft:gray_concrete
setblock 405 288 363 minecraft:gray_concrete
setblock 406 288 323 minecraft:polished_deepslate
setblock 406 288 363 minecraft:polished_deepslate
fill 407 288 323 410 288 323 minecraft:gray_concrete
setblock 407 288 362 minecraft:polished_deepslate
fill 407 288 363 410 288 363 minecraft:gray_concrete
fill 408 288 324 409 288 324 minecraft:gray_concrete
fill 408 288 362 411 288 362 minecraft:gray_concrete
setblock 410 288 324 minecraft:polished_deepslate
fill 410 288 339 410 288 341 minecraft:black_concrete
fill 410 288 361 412 288 361 minecraft:gray_concrete
setblock 411 288 323 minecraft:polished_deepslate
fill 411 288 324 411 291 324 minecraft:gray_concrete
setblock 411 288 338 minecraft:black_concrete
setblock 411 288 342 minecraft:black_concrete
setblock 411 288 363 minecraft:polished_deepslate
fill 412 288 323 412 291 323 minecraft:gray_concrete
fill 412 288 337 414 288 337 minecraft:black_concrete
fill 412 288 343 415 288 343 minecraft:black_concrete
setblock 412 288 362 minecraft:polished_deepslate
fill 412 288 363 412 291 363 minecraft:gray_concrete
setblock 413 288 361 minecraft:polished_deepslate
fill 413 288 362 413 291 362 minecraft:gray_concrete
fill 414 288 361 414 291 361 minecraft:gray_concrete
setblock 415 288 324 minecraft:polished_deepslate
setblock 415 288 338 minecraft:black_concrete
setblock 415 288 359 minecraft:polished_deepslate
fill 415 288 360 415 290 360 minecraft:gray_concrete
fill 416 288 322 416 308 322 minecraft:gray_concrete
setblock 416 288 323 minecraft:polished_deepslate
fill 416 288 339 416 288 342 minecraft:black_concrete
setblock 416 288 358 minecraft:polished_deepslate
fill 416 288 359 416 291 359 minecraft:gray_concrete
setblock 416 288 363 minecraft:polished_deepslate
fill 417 288 323 417 288 325 minecraft:gray_concrete
setblock 417 288 333 minecraft:gray_concrete
setblock 417 288 337 minecraft:polished_deepslate
fill 417 288 338 417 289 338 minecraft:gray_concrete
setblock 417 288 357 minecraft:polished_deepslate
fill 417 288 358 417 291 358 minecraft:gray_concrete
setblock 417 288 362 minecraft:polished_deepslate
fill 417 288 363 417 291 363 minecraft:gray_concrete
fill 376 289 335 376 308 336 minecraft:gray_concrete
setblock 376 289 337 minecraft:light_blue_stained_glass
fill 376 289 338 376 292 339 minecraft:gray_concrete
fill 376 289 351 376 308 351 minecraft:gray_concrete
setblock 377 289 341 minecraft:polished_deepslate
fill 377 289 342 377 292 342 minecraft:gray_concrete
fill 377 289 351 377 291 352 minecraft:light_blue_stained_glass
fill 377 289 354 377 290 354 minecraft:gray_concrete
setblock 377 289 355 minecraft:yellow_concrete
setblock 377 289 356 minecraft:polished_deepslate
fill 377 289 357 377 292 357 minecraft:gray_concrete
setblock 377 289 361 minecraft:polished_deepslate
fill 377 289 362 377 292 362 minecraft:gray_concrete
fill 378 289 349 378 290 349 minecraft:light_blue_stained_glass
fill 378 289 353 378 290 353 minecraft:light_blue_stained_glass
setblock 378 289 360 minecraft:polished_deepslate
fill 378 289 361 378 290 361 minecraft:gray_concrete
fill 379 289 350 380 291 350 minecraft:light_blue_stained_glass
fill 379 289 352 380 291 352 minecraft:light_blue_stained_glass
fill 379 289 355 379 289 356 minecraft:black_concrete
fill 380 289 330 380 290 330 minecraft:black_concrete
fill 380 289 338 380 290 338 minecraft:black_concrete
fill 380 289 351 380 292 351 minecraft:light_blue_stained_glass
setblock 380 289 354 minecraft:black_concrete
setblock 380 289 357 minecraft:black_concrete
setblock 380 289 363 minecraft:polished_deepslate
fill 381 289 363 384 289 363 minecraft:gray_concrete
setblock 382 289 354 minecraft:black_concrete
setblock 382 289 357 minecraft:black_concrete
fill 383 289 355 383 289 356 minecraft:black_concrete
fill 383 289 359 383 290 359 minecraft:black_concrete
setblock 385 289 363 minecraft:polished_deepslate
setblock 386 289 322 minecraft:light_blue_stained_glass
fill 386 289 363 389 289 363 minecraft:gray_concrete
fill 387 289 362 390 289 362 minecraft:gray_concrete
setblock 390 289 323 minecraft:polished_deepslate
setblock 390 289 363 minecraft:polished_deepslate
fill 391 289 323 391 292 323 minecraft:gray_concrete
setblock 391 289 362 minecraft:polished_deepslate
fill 391 289 363 391 292 363 minecraft:gray_concrete
fill 392 289 362 392 291 362 minecraft:gray_concrete
setblock 395 289 323 minecraft:polished_deepslate
setblock 395 289 363 minecraft:polished_deepslate
setblock 396 289 363 minecraft:gray_concrete
fill 400 289 326 400 290 326 minecraft:black_concrete
setblock 404 289 323 minecraft:gray_concrete
setblock 405 289 323 minecraft:polished_deepslate
setblock 405 289 363 minecraft:polished_deepslate
fill 406 289 323 409 289 323 minecraft:gray_concrete
fill 406 289 363 409 289 363 minecraft:gray_concrete
fill 407 289 362 410 289 362 minecraft:gray_concrete
setblock 408 289 324 minecraft:gray_concrete
setblock 409 289 324 minecraft:polished_deepslate
fill 409 289 361 411 289 361 minecraft:gray_concrete
setblock 410 289 323 minecraft:polished_deepslate
fill 410 289 324 410 292 324 minecraft:gray_concrete
setblock 410 289 363 minecraft:polished_deepslate
fill 411 289 323 411 292 323 minecraft:gray_concrete
setblock 411 289 362 minecraft:polished_deepslate
fill 411 289 363 411 292 363 minecraft:gray_concrete
setblock 412 289 361 minecraft:polished_deepslate
fill 412 289 362 412 292 362 minecraft:gray_concrete
fill 413 289 355 413 290 355 minecraft:black_concrete
fill 413 289 361 413 292 361 minecraft:gray_concrete
setblock 414 289 324 minecraft:polished_deepslate
setblock 415 289 323 minecraft:polished_deepslate
setblock 415 289 324 minecraft:gray_concrete
setblock 415 289 358 minecraft:polished_deepslate
setblock 415 289 359 minecraft:gray_concrete
setblock 415 289 363 minecraft:polished_deepslate
setblock 415 289 364 minecraft:light_blue_stained_glass
fill 416 289 323 418 291 323 minecraft:gray_concrete
setblock 416 289 357 minecraft:polished_deepslate
fill 416 289 358 416 291 358 minecraft:gray_concrete
setblock 416 289 362 minecraft:polished_deepslate
fill 416 289 363 416 292 363 minecraft:gray_concrete
fill 417 289 324 417 290 324 minecraft:gray_concrete
setblock 417 289 337 minecraft:gray_concrete
setblock 417 289 356 minecraft:polished_deepslate
fill 417 289 357 417 292 357 minecraft:gray_concrete
setblock 417 289 361 minecraft:polished_deepslate
fill 417 289 362 417 292 362 minecraft:gray_concrete
setblock 418 289 324 minecraft:light_blue_stained_glass
fill 376 290 337 376 308 337 minecraft:gray_concrete
fill 376 290 340 376 308 340 minecraft:gray_concrete
setblock 377 290 340 minecraft:polished_deepslate
fill 377 290 341 377 293 341 minecraft:gray_concrete
fill 377 290 353 377 291 353 minecraft:light_blue_stained_glass
setblock 377 290 355 minecraft:polished_deepslate
setblock 377 290 356 minecraft:yellow_concrete
setblock 377 290 360 minecraft:polished_deepslate
fill 377 290 361 377 293 361 minecraft:gray_concrete
setblock 378 290 359 minecraft:polished_deepslate
setblock 378 290 360 minecraft:gray_concrete
setblock 379 290 325 minecraft:light[level=12]
fill 379 290 330 379 291 330 minecraft:black_concrete
setblock 379 290 332 minecraft:light[level=12]
fill 379 290 338 379 291 338 minecraft:black_concrete
setblock 379 290 339 minecraft:light[level=12]
setblock 379 290 346 minecraft:light[level=12]
setblock 379 290 349 minecraft:light_blue_stained_glass
setblock 379 290 353 minecraft:light_blue_stained_glass
setblock 379 290 360 minecraft:light[level=12]
setblock 379 290 363 minecraft:polished_deepslate
fill 380 290 363 383 290 363 minecraft:gray_concrete
fill 381 290 350 381 291 352 minecraft:light_blue_stained_glass
fill 382 290 351 382 292 351 minecraft:light_blue_stained_glass
fill 383 290 360 383 291 360 minecraft:black_concrete
setblock 384 290 363 minecraft:polished_deepslate
fill 385 290 363 388 290 363 minecraft:gray_concrete
fill 386 290 322 386 308 322 minecraft:gray_concrete
setblock 386 290 325 minecraft:light[level=12]
setblock 386 290 332 minecraft:light[level=12]
setblock 386 290 339 minecraft:light[level=12]
setblock 386 290 346 minecraft:light[level=12]
setblock 386 290 353 minecraft:light[level=12]
setblock 386 290 360 minecraft:light[level=12]
fill 387 290 362 389 290 362 minecraft:gray_concrete
setblock 389 290 323 minecraft:polished_deepslate
setblock 389 290 363 minecraft:polished_deepslate
fill 390 290 323 390 293 323 minecraft:gray_concrete
setblock 390 290 362 minecraft:polished_deepslate
fill 390 290 363 390 293 363 minecraft:gray_concrete
fill 391 290 362 391 293 362 minecraft:gray_concrete
setblock 393 290 325 minecraft:light[level=12]
setblock 393 290 332 minecraft:light[level=12]
setblock 393 290 339 minecraft:light[level=12]
setblock 393 290 346 minecraft:light[level=12]
setblock 393 290 353 minecraft:light[level=12]
setblock 393 290 360 minecraft:light[level=12]
setblock 394 290 323 minecraft:polished_deepslate
setblock 394 290 363 minecraft:polished_deepslate
fill 395 290 323 395 293 323 minecraft:gray_concrete
fill 395 290 363 395 293 363 minecraft:gray_concrete
fill 400 290 325 400 291 325 minecraft:black_concrete
setblock 400 290 332 minecraft:light[level=12]
setblock 400 290 339 minecraft:light[level=12]
setblock 400 290 346 minecraft:light[level=12]
setblock 400 290 353 minecraft:light[level=12]
setblock 400 290 360 minecraft:light[level=12]
setblock 404 290 323 minecraft:polished_deepslate
setblock 404 290 363 minecraft:polished_deepslate
fill 405 290 323 408 290 323 minecraft:gray_concrete
fill 405 290 363 408 290 363 minecraft:gray_concrete
fill 406 290 362 409 290 362 minecraft:gray_concrete
setblock 407 290 324 minecraft:gray_concrete
setblock 407 290 325 minecraft:light[level=12]
setblock 407 290 332 minecraft:light[level=12]
setblock 407 290 339 minecraft:light[level=12]
setblock 407 290 346 minecraft:light[level=12]
setblock 407 290 353 minecraft:light[level=12]
setblock 407 290 360 minecraft:light[level=12]
setblock 408 290 324 minecraft:polished_deepslate
setblock 409 290 323 minecraft:polished_deepslate
fill 409 290 324 409 293 324 minecraft:gray_concrete
fill 409 290 361 410 290 361 minecraft:gray_concrete
setblock 409 290 363 minecraft:polished_deepslate
fill 410 290 323 410 293 323 minecraft:gray_concrete
setblock 410 290 362 minecraft:polished_deepslate
fill 410 290 363 410 293 363 minecraft:gray_concrete
setblock 411 290 361 minecraft:polished_deepslate
fill 411 290 362 411 293 362 minecraft:gray_concrete
fill 412 290 322 412 308 322 minecraft:gray_concrete
fill 412 290 361 412 293 361 minecraft:gray_concrete
setblock 413 290 322 minecraft:light_blue_stained_glass
setblock 413 290 324 minecraft:polished_deepslate
fill 414 290 322 415 299 322 minecraft:gray_concrete
setblock 414 290 323 minecraft:polished_deepslate
fill 414 290 324 414 293 324 minecraft:gray_concrete
setblock 414 290 325 minecraft:light[level=12]
setblock 414 290 332 minecraft:light[level=12]
setblock 414 290 346 minecraft:light[level=12]
setblock 414 290 353 minecraft:light[level=12]
fill 414 290 355 414 291 355 minecraft:black_concrete
setblock 414 290 360 minecraft:light[level=12]
setblock 414 290 363 minecraft:polished_deepslate
fill 415 290 323 415 293 323 minecraft:gray_concrete
setblock 415 290 362 minecraft:polished_deepslate
fill 415 290 363 415 293 364 minecraft:gray_concrete
setblock 416 290 357 minecraft:gray_concrete
setblock 416 290 361 minecraft:polished_deepslate
fill 416 290 362 416 293 362 minecraft:gray_concrete
fill 417 290 356 417 291 356 minecraft:gray_concrete
setblock 417 290 360 minecraft:polished_deepslate
fill 417 290 361 417 293 361 minecraft:gray_concrete
fill 418 290 324 418 308 324 minecraft:gray_concrete
fill 377 291 340 377 294 340 minecraft:gray_concrete
setblock 377 291 344 minecraft:polished_deepslate
setblock 377 291 355 minecraft:yellow_concrete
fill 377 291 356 377 292 356 minecraft:gray_concrete
setblock 377 291 359 minecraft:polished_deepslate
fill 377 291 360 377 294 360 minecraft:gray_concrete
fill 378 291 330 378 292 330 minecraft:black_concrete
fill 378 291 338 378 292 338 minecraft:black_concrete
setblock 378 291 363 minecraft:polished_deepslate
fill 379 291 363 382 291 363 minecraft:gray_concrete
setblock 382 291 350 minecraft:light_blue_stained_glass
setblock 382 291 352 minecraft:light_blue_stained_glass
fill 383 291 351 383 292 351 minecraft:light_blue_stained_glass
fill 383 291 361 383 292 361 minecraft:black_concrete
setblock 383 291 363 minecraft:polished_deepslate
fill 384 291 363 387 291 363 minecraft:gray_concrete
fill 387 291 362 388 291 362 minecraft:gray_concrete
setblock 388 291 323 minecraft:polished_deepslate
setblock 388 291 363 minecraft:polished_deepslate
fill 389 291 323 389 294 323 minecraft:gray_concrete
setblock 389 291 362 minecraft:polished_deepslate
fill 389 291 363 389 294 363 minecraft:gray_concrete
fill 390 291 362 390 294 362 minecraft:gray_concrete
setblock 393 291 323 minecraft:polished_deepslate
setblock 393 291 363 minecraft:polished_deepslate
fill 394 291 323 394 294 323 minecraft:gray_concrete
fill 394 291 363 394 294 363 minecraft:gray_concrete
setblock 398 291 364 minecraft:light_blue_stained_glass
fill 400 291 324 400 292 324 minecraft:black_concrete
setblock 402 291 323 minecraft:gray_concrete
setblock 403 291 323 minecraft:polished_deepslate
setblock 403 291 363 minecraft:polished_deepslate
fill 404 291 323 407 291 323 minecraft:gray_concrete
fill 404 291 363 407 291 363 minecraft:gray_concrete
setblock 406 291 324 minecraft:gray_concrete
fill 406 291 362 408 291 362 minecraft:gray_concrete
setblock 407 291 324 minecraft:polished_deepslate
setblock 408 291 323 minecraft:polished_deepslate
fill 408 291 324 408 294 324 minecraft:gray_concrete
setblock 408 291 363 minecraft:polished_deepslate
fill 409 291 323 409 294 323 minecraft:gray_concrete
setblock 409 291 361 minecraft:gray_concrete
setblock 409 291 362 minecraft:polished_deepslate
fill 409 291 363 409 294 363 minecraft:gray_concrete
setblock 410 291 361 minecraft:polished_deepslate
fill 410 291 362 410 294 362 minecraft:gray_concrete
fill 411 291 361 411 294 361 minecraft:gray_concrete
setblock 412 291 324 minecraft:polished_deepslate
fill 413 291 322 413 308 322 minecraft:gray_concrete
setblock 413 291 323 minecraft:polished_deepslate
fill 413 291 324 413 294 324 minecraft:gray_concrete
setblock 413 291 363 minecraft:polished_deepslate
fill 414 291 323 414 294 323 minecraft:gray_concrete
setblock 414 291 362 minecraft:polished_deepslate
fill 414 291 363 414 294 363 minecraft:gray_concrete
fill 415 291 355 415 292 355 minecraft:black_concrete
setblock 415 291 361 minecraft:polished_deepslate
fill 415 291 362 415 294 362 minecraft:gray_concrete
setblock 416 291 360 minecraft:polished_deepslate
fill 416 291 361 416 294 361 minecraft:gray_concrete
setblock 417 291 324 minecraft:polished_deepslate
setblock 417 291 359 minecraft:polished_deepslate
fill 417 291 360 417 294 360 minecraft:gray_concrete
setblock 418 291 363 minecraft:light_blue_stained_glass
fill 418 291 364 418 308 364 minecraft:gray_concrete
fill 377 292 330 377 293 330 minecraft:black_concrete
fill 377 292 338 377 293 338 minecraft:black_concrete
setblock 377 292 343 minecraft:polished_deepslate
fill 377 292 344 377 294 345 minecraft:gray_concrete
fill 377 292 351 378 292 351 minecraft:light_blue_stained_glass
setblock 377 292 354 minecraft:yellow_concrete
setblock 377 292 358 minecraft:polished_deepslate
fill 377 292 359 377 295 359 minecraft:gray_concrete
setblock 377 292 363 minecraft:polished_deepslate
fill 378 292 363 381 292 363 minecraft:gray_concrete
setblock 381 292 351 minecraft:light_blue_stained_glass
setblock 382 292 363 minecraft:polished_deepslate
fill 383 292 362 383 293 362 minecraft:black_concrete
fill 383 292 363 386 292 363 minecraft:gray_concrete
setblock 384 292 351 minecraft:light_blue_stained_glass
setblock 386 292 323 minecraft:gray_concrete
fill 386 292 362 387 292 362 minecraft:gray_concrete
setblock 387 292 323 minecraft:polished_deepslate
setblock 387 292 363 minecraft:polished_deepslate
fill 388 292 323 388 295 323 minecraft:gray_concrete
setblock 388 292 362 minecraft:polished_deepslate
fill 388 292 363 388 295 363 minecraft:gray_concrete
fill 389 292 362 389 295 362 minecraft:gray_concrete
setblock 390 292 364 minecraft:light_blue_stained_glass
fill 391 292 334 391 293 334 minecraft:white_wool
setblock 392 292 323 minecraft:polished_deepslate
setblock 392 292 363 minecraft:polished_deepslate
fill 393 292 323 393 295 323 minecraft:gray_concrete
fill 393 292 363 393 295 363 minecraft:gray_concrete
setblock 396 292 323 minecraft:gray_concrete
setblock 397 292 323 minecraft:polished_deepslate
fill 398 292 364 398 308 364 minecraft:gray_concrete
fill 400 292 323 401 292 323 minecraft:gray_concrete
setblock 402 292 323 minecraft:polished_deepslate
setblock 403 292 322 minecraft:light_blue_stained_glass
fill 403 292 323 406 292 323 minecraft:gray_concrete
fill 403 292 363 406 292 363 minecraft:gray_concrete
fill 404 292 324 405 292 324 minecraft:gray_concrete
fill 405 292 362 407 292 362 minecraft:gray_concrete
setblock 406 292 324 minecraft:polished_deepslate
setblock 407 292 323 minecraft:polished_deepslate
fill 407 292 324 407 295 324 minecraft:gray_concrete
setblock 407 292 363 minecraft:polished_deepslate
fill 408 292 323 408 295 323 minecraft:gray_concrete
fill 408 292 325 409 292 325 minecraft:gray_concrete
setblock 408 292 361 minecraft:gray_concrete
setblock 408 292 362 minecraft:polished_deepslate
fill 408 292 363 408 295 363 minecraft:gray_concrete
setblock 409 292 361 minecraft:polished_deepslate
fill 409 292 362 409 295 362 minecraft:gray_concrete
setblock 410 292 325 minecraft:polished_deepslate
fill 410 292 361 410 295 361 minecraft:gray_concrete
setblock 411 292 324 minecraft:polished_deepslate
setblock 412 292 323 minecraft:polished_deepslate
fill 412 292 324 412 295 324 minecraft:gray_concrete
setblock 412 292 363 minecraft:polished_deepslate
fill 413 292 323 413 295 323 minecraft:gray_concrete
setblock 413 292 362 minecraft:polished_deepslate
fill 413 292 363 413 295 363 minecraft:gray_concrete
setblock 414 292 361 minecraft:polished_deepslate
fill 414 292 362 414 295 362 minecraft:gray_concrete
setblock 415 292 361 minecraft:gray_concrete
setblock 416 292 323 minecraft:gray_concrete
fill 416 292 355 416 293 355 minecraft:black_concrete
setblock 416 292 359 minecraft:polished_deepslate
fill 416 292 360 416 295 360 minecraft:gray_concrete
setblock 417 292 323 minecraft:polished_deepslate
fill 417 292 324 417 295 324 minecraft:gray_concrete
setblock 417 292 358 minecraft:polished_deepslate
fill 417 292 359 417 295 359 minecraft:gray_concrete
setblock 417 292 363 minecraft:polished_deepslate
fill 418 292 323 418 308 323 minecraft:gray_concrete
fill 418 292 363 418 308 363 minecraft:gray_concrete
setblock 376 293 338 minecraft:light_blue_stained_glass
fill 376 293 339 376 308 339 minecraft:gray_concrete
setblock 376 293 350 minecraft:light_blue_stained_glass
setblock 377 293 342 minecraft:polished_deepslate
fill 377 293 343 377 296 343 minecraft:gray_concrete
setblock 377 293 346 minecraft:gray_concrete
setblock 377 293 347 minecraft:polished_deepslate
setblock 377 293 353 minecraft:ochre_froglight
fill 377 293 357 377 294 357 minecraft:polished_deepslate
fill 377 293 358 377 295 358 minecraft:gray_concrete
setblock 377 293 362 minecraft:polished_deepslate
fill 377 293 363 380 293 363 minecraft:gray_concrete
setblock 380 293 330 minecraft:sea_lantern
setblock 380 293 336 minecraft:sea_lantern
setblock 380 293 342 minecraft:sea_lantern
setblock 380 293 348 minecraft:sea_lantern
setblock 380 293 354 minecraft:sea_lantern
setblock 380 293 360 minecraft:sea_lantern
setblock 381 293 363 minecraft:polished_deepslate
fill 382 293 363 385 293 363 minecraft:gray_concrete
setblock 384 293 326 minecraft:sea_lantern
setblock 385 293 323 minecraft:gray_concrete
fill 385 293 362 386 293 362 minecraft:gray_concrete
setblock 386 293 323 minecraft:polished_deepslate
setblock 386 293 360 minecraft:sea_lantern
setblock 386 293 363 minecraft:polished_deepslate
fill 387 293 323 387 296 323 minecraft:gray_concrete
setblock 387 293 362 minecraft:polished_deepslate
fill 387 293 363 387 296 363 minecraft:gray_concrete
fill 388 293 362 388 296 362 minecraft:gray_concrete
setblock 389 293 324 minecraft:gray_concrete
setblock 390 293 324 minecraft:polished_deepslate
setblock 390 293 326 minecraft:sea_lantern
fill 390 293 364 390 308 364 minecraft:gray_concrete
setblock 391 293 323 minecraft:polished_deepslate
fill 391 293 324 392 295 324 minecraft:gray_concrete
setblock 391 293 363 minecraft:polished_deepslate
fill 392 293 323 392 296 323 minecraft:gray_concrete
setblock 392 293 360 minecraft:sea_lantern
fill 392 293 363 392 296 363 minecraft:gray_concrete
setblock 396 293 323 minecraft:polished_deepslate
setblock 396 293 326 minecraft:sea_lantern
fill 397 293 323 400 293 323 minecraft:gray_concrete
setblock 398 293 360 minecraft:sea_lantern
setblock 401 293 323 minecraft:polished_deepslate
setblock 401 293 363 minecraft:polished_deepslate
fill 402 293 323 405 293 323 minecraft:gray_concrete
setblock 402 293 326 minecraft:sea_lantern
fill 402 293 363 405 293 363 minecraft:gray_concrete
fill 403 293 322 403 308 322 minecraft:gray_concrete
fill 403 293 324 404 293 324 minecraft:gray_concrete
setblock 404 293 360 minecraft:sea_lantern
fill 404 293 362 406 293 362 minecraft:gray_concrete
fill 405 293 322 406 305 322 minecraft:gray_concrete
setblock 405 293 324 minecraft:polished_deepslate
setblock 406 293 323 minecraft:polished_deepslate
fill 406 293 324 406 295 325 minecraft:gray_concrete
setblock 406 293 363 minecraft:polished_deepslate
setblock 407 293 322 minecraft:light_blue_stained_glass
fill 407 293 323 407 296 323 minecraft:gray_concrete
fill 407 293 325 408 293 325 minecraft:gray_concrete
setblock 407 293 361 minecraft:gray_concrete
setblock 407 293 362 minecraft:polished_deepslate
fill 407 293 363 407 296 363 minecraft:gray_concrete
fill 408 293 322 408 308 322 minecraft:gray_concrete
setblock 408 293 326 minecraft:sea_lantern
setblock 408 293 361 minecraft:polished_deepslate
fill 408 293 362 408 296 362 minecraft:gray_concrete
setblock 409 293 325 minecraft:polished_deepslate
fill 409 293 361 409 296 361 minecraft:gray_concrete
setblock 410 293 324 minecraft:polished_deepslate
fill 410 293 325 411 295 325 minecraft:gray_concrete
setblock 410 293 360 minecraft:sea_lantern
setblock 411 293 323 minecraft:polished_deepslate
fill 411 293 324 411 296 324 minecraft:gray_concrete
setblock 411 293 363 minecraft:polished_deepslate
fill 412 293 323 412 296 323 minecraft:gray_concrete
setblock 412 293 362 minecraft:polished_deepslate
fill 412 293 363 412 296 363 minecraft:gray_concrete
setblock 413 293 361 minecraft:polished_deepslate
fill 413 293 362 413 296 362 minecraft:gray_concrete
setblock 414 293 326 minecraft:sea_lantern
setblock 414 293 332 minecraft:sea_lantern
setblock 414 293 338 minecraft:sea_lantern
setblock 414 293 344 minecraft:sea_lantern
setblock 414 293 350 minecraft:sea_lantern
setblock 414 293 356 minecraft:sea_lantern
fill 414 293 361 414 295 361 minecraft:gray_concrete
setblock 414 293 364 minecraft:light_blue_stained_glass
setblock 415 293 324 minecraft:polished_deepslate
setblock 416 293 323 minecraft:polished_deepslate
setblock 416 293 359 minecraft:gray_concrete
setblock 416 293 363 minecraft:polished_deepslate
fill 417 293 323 417 296 323 minecraft:gray_concrete
fill 417 293 357 417 294 357 minecraft:polished_deepslate
fill 417 293 358 417 296 358 minecraft:gray_concrete
setblock 417 293 362 minecraft:polished_deepslate
fill 417 293 363 417 296 363 minecraft:gray_concrete
fill 376 294 338 376 308 338 minecraft:gray_concrete
fill 376 294 350 376 308 350 minecraft:gray_concrete
fill 377 294 323 380 294 339 minecraft:polished_deepslate
fill 377 294 341 380 294 341 minecraft:polished_deepslate
fill 377 294 342 377 297 342 minecraft:gray_concrete
fill 377 294 346 380 294 346 minecraft:polished_deepslate
fill 377 294 347 377 295 349 minecraft:gray_concrete
fill 377 294 350 379 294 356 minecraft:polished_deepslate
fill 377 294 361 407 294 361 minecraft:polished_deepslate
fill 377 294 362 377 296 363 minecraft:gray_concrete
fill 378 294 340 380 294 340 minecraft:polished_deepslate
fill 378 294 342 380 294 345 minecraft:polished_deepslate
fill 378 294 347 380 294 349 minecraft:polished_deepslate
fill 378 294 357 380 294 360 minecraft:polished_deepslate
fill 378 294 362 383 294 362 minecraft:polished_deepslate
fill 378 294 363 379 294 363 minecraft:gray_concrete
fill 380 294 350 380 294 354 minecraft:polished_deepslate
setblock 380 294 363 minecraft:polished_deepslate
fill 381 294 323 382 294 326 minecraft:polished_deepslate
fill 381 294 360 415 294 360 minecraft:polished_deepslate
fill 381 294 363 384 294 363 minecraft:gray_concrete
fill 383 294 323 384 294 323 minecraft:gray_concrete
fill 383 294 324 386 294 326 minecraft:polished_deepslate
fill 384 294 362 385 294 362 minecraft:gray_concrete
setblock 385 294 323 minecraft:polished_deepslate
setblock 385 294 363 minecraft:polished_deepslate
fill 385 294 364 385 308 364 minecraft:gray_concrete
fill 386 294 323 386 297 323 minecraft:gray_concrete
setblock 386 294 362 minecraft:polished_deepslate
fill 386 294 363 386 297 363 minecraft:gray_concrete
setblock 386 294 364 minecraft:light_blue_stained_glass
fill 387 294 324 388 294 324 minecraft:gray_concrete
fill 387 294 325 403 294 326 minecraft:polished_deepslate
setblock 387 294 333 minecraft:light[level=13]
setblock 387 294 341 minecraft:light[level=13]
setblock 387 294 349 minecraft:light[level=13]
setblock 387 294 357 minecraft:light[level=13]
fill 387 294 362 387 297 362 minecraft:gray_concrete
setblock 389 294 324 minecraft:polished_deepslate
setblock 390 294 323 minecraft:polished_deepslate
fill 390 294 324 390 297 324 minecraft:gray_concrete
setblock 390 294 363 minecraft:polished_deepslate
fill 391 294 323 391 297 323 minecraft:gray_concrete
fill 391 294 362 403 294 362 minecraft:polished_deepslate
fill 391 294 363 391 297 363 minecraft:gray_concrete
setblock 393 294 324 minecraft:gray_concrete
fill 394 294 324 400 294 324 minecraft:polished_deepslate
setblock 395 294 323 minecraft:polished_deepslate
setblock 395 294 333 minecraft:light[level=13]
setblock 395 294 341 minecraft:light[level=13]
setblock 395 294 349 minecraft:light[level=13]
setblock 395 294 357 minecraft:light[level=13]
fill 395 294 363 400 294 363 minecraft:polished_deepslate
fill 396 294 323 399 294 323 minecraft:gray_concrete
setblock 400 294 323 minecraft:polished_deepslate
fill 401 294 323 403 294 324 minecraft:gray_concrete
fill 401 294 363 404 294 363 minecraft:gray_concrete
setblock 403 294 333 minecraft:light[level=13]
setblock 403 294 341 minecraft:light[level=13]
setblock 403 294 349 minecraft:light[level=13]
setblock 403 294 357 minecraft:light[level=13]
setblock 404 294 323 minecraft:gray_concrete
setblock 404 294 324 minecraft:polished_deepslate
fill 404 294 325 405 296 325 minecraft:gray_concrete
fill 404 294 326 417 294 326 minecraft:polished_deepslate
fill 404 294 362 405 294 362 minecraft:gray_concrete
setblock 405 294 323 minecraft:polished_deepslate
fill 405 294 324 405 297 324 minecraft:gray_concrete
setblock 405 294 363 minecraft:polished_deepslate
fill 406 294 323 406 297 323 minecraft:gray_concrete
setblock 406 294 362 minecraft:polished_deepslate
fill 406 294 363 406 297 363 minecraft:gray_concrete
fill 407 294 322 407 308 322 minecraft:gray_concrete
setblock 407 294 325 minecraft:gray_concrete
fill 407 294 362 407 297 362 minecraft:gray_concrete
setblock 408 294 325 minecraft:polished_deepslate
fill 408 294 361 408 297 361 minecraft:gray_concrete
setblock 409 294 324 minecraft:polished_deepslate
fill 409 294 325 409 297 325 minecraft:gray_concrete
setblock 410 294 323 minecraft:polished_deepslate
fill 410 294 324 410 297 324 minecraft:gray_concrete
setblock 410 294 363 minecraft:polished_deepslate
fill 411 294 323 411 297 323 minecraft:gray_concrete
setblock 411 294 333 minecraft:light[level=13]
setblock 411 294 341 minecraft:light[level=13]
setblock 411 294 349 minecraft:light[level=13]
setblock 411 294 357 minecraft:light[level=13]
setblock 411 294 362 minecraft:polished_deepslate
fill 411 294 363 411 297 363 minecraft:gray_concrete
setblock 412 294 325 minecraft:gray_concrete
setblock 412 294 361 minecraft:polished_deepslate
fill 412 294 362 412 297 362 minecraft:gray_concrete
fill 413 294 325 417 294 325 minecraft:polished_deepslate
fill 413 294 361 413 296 361 minecraft:gray_concrete
setblock 414 294 324 minecraft:polished_deepslate
fill 414 294 327 417 294 338 minecraft:polished_deepslate
fill 414 294 342 416 294 359 minecraft:polished_deepslate
fill 414 294 364 415 308 364 minecraft:gray_concrete
setblock 415 294 323 minecraft:polished_deepslate
fill 415 294 324 415 297 324 minecraft:gray_concrete
fill 415 294 339 417 294 339 minecraft:polished_deepslate
fill 415 294 341 417 294 341 minecraft:polished_deepslate
setblock 415 294 361 minecraft:polished_deepslate
setblock 415 294 363 minecraft:polished_deepslate
fill 416 294 323 416 297 323 minecraft:gray_concrete
setblock 416 294 324 minecraft:polished_deepslate
fill 416 294 340 417 294 340 minecraft:polished_deepslate
setblock 416 294 362 minecraft:polished_deepslate
fill 416 294 363 416 297 363 minecraft:gray_concrete
fill 417 294 342 417 294 356 minecraft:polished_deepslate
setblock 417 294 361 minecraft:polished_deepslate
fill 417 294 362 417 297 362 minecraft:gray_concrete
fill 377 295 322 377 308 322 minecraft:gray_concrete
setblock 377 295 340 minecraft:polished_deepslate
fill 377 295 341 377 298 341 minecraft:gray_concrete
setblock 377 295 344 minecraft:gray_concrete
setblock 377 295 345 minecraft:polished_deepslate
fill 377 295 346 378 297 346 minecraft:gray_concrete
setblock 377 295 350 minecraft:polished_deepslate
fill 377 295 351 377 298 351 minecraft:gray_concrete
setblock 377 295 360 minecraft:polished_deepslate
fill 377 295 361 377 298 361 minecraft:gray_concrete
fill 378 295 322 378 296 322 minecraft:light_blue_stained_glass
fill 378 295 342 378 295 343 minecraft:gray_concrete
setblock 378 295 344 minecraft:polished_deepslate
fill 378 295 345 378 298 345 minecraft:gray_concrete
fill 378 295 347 378 296 347 minecraft:gray_concrete
setblock 378 295 363 minecraft:gray_concrete
setblock 379 295 363 minecraft:polished_deepslate
fill 380 295 326 380 295 354 minecraft:light_blue_concrete
fill 380 295 357 380 295 360 minecraft:light_blue_concrete
fill 380 295 363 383 295 363 minecraft:gray_concrete
fill 381 295 323 383 295 323 minecraft:gray_concrete
fill 381 295 326 406 295 326 minecraft:light_blue_concrete
fill 381 295 360 414 295 360 minecraft:light_blue_concrete
fill 383 295 362 384 295 362 minecraft:gray_concrete
setblock 384 295 323 minecraft:polished_deepslate
setblock 384 295 363 minecraft:polished_deepslate
fill 385 295 323 385 297 324 minecraft:gray_concrete
setblock 385 295 362 minecraft:polished_deepslate
fill 385 295 363 385 298 363 minecraft:gray_concrete
fill 386 295 324 387 295 324 minecraft:gray_concrete
fill 386 295 362 386 298 362 minecraft:gray_concrete
fill 386 295 364 386 308 364 minecraft:gray_concrete
setblock 388 295 324 minecraft:polished_deepslate
setblock 389 295 323 minecraft:polished_deepslate
fill 389 295 324 389 298 324 minecraft:gray_concrete
setblock 389 295 363 minecraft:polished_deepslate
fill 390 295 323 390 298 323 minecraft:gray_concrete
setblock 390 295 362 minecraft:polished_deepslate
fill 390 295 363 390 298 363 minecraft:gray_concrete
setblock 391 295 362 minecraft:gray_concrete
setblock 393 295 324 minecraft:polished_deepslate
setblock 394 295 323 minecraft:polished_deepslate
fill 394 295 324 397 295 324 minecraft:gray_concrete
setblock 394 295 363 minecraft:polished_deepslate
fill 395 295 323 398 295 323 minecraft:gray_concrete
fill 395 295 363 395 297 363 minecraft:gray_concrete
setblock 398 295 324 minecraft:polished_deepslate
setblock 399 295 323 minecraft:polished_deepslate
fill 399 295 324 402 295 324 minecraft:gray_concrete
setblock 399 295 363 minecraft:polished_deepslate
fill 400 295 323 403 295 323 minecraft:gray_concrete
fill 400 295 363 403 295 363 minecraft:gray_concrete
setblock 403 295 324 minecraft:polished_deepslate
fill 403 295 325 403 298 325 minecraft:gray_concrete
fill 403 295 362 404 295 362 minecraft:gray_concrete
setblock 404 295 323 minecraft:polished_deepslate
fill 404 295 324 404 298 324 minecraft:gray_concrete
setblock 404 295 363 minecraft:polished_deepslate
fill 405 295 323 405 298 323 minecraft:gray_concrete
setblock 405 295 362 minecraft:polished_deepslate
fill 405 295 363 405 298 363 minecraft:gray_concrete
setblock 406 295 361 minecraft:polished_deepslate
fill 406 295 362 406 298 362 minecraft:gray_concrete
setblock 407 295 325 minecraft:polished_deepslate
fill 407 295 326 408 297 326 minecraft:gray_concrete
fill 407 295 361 407 298 361 minecraft:gray_concrete
setblock 408 295 324 minecraft:polished_deepslate
fill 408 295 325 408 298 325 minecraft:gray_concrete
setblock 409 295 323 minecraft:polished_deepslate
fill 409 295 324 409 298 324 minecraft:gray_concrete
fill 409 295 326 414 295 326 minecraft:light_blue_concrete
setblock 409 295 363 minecraft:polished_deepslate
fill 410 295 323 410 298 323 minecraft:gray_concrete
setblock 410 295 362 minecraft:polished_deepslate
fill 410 295 363 410 298 363 minecraft:gray_concrete
setblock 411 295 361 minecraft:polished_deepslate
fill 411 295 362 411 298 362 minecraft:gray_concrete
setblock 412 295 325 minecraft:polished_deepslate
fill 412 295 361 412 297 361 minecraft:gray_concrete
setblock 413 295 324 minecraft:polished_deepslate
setblock 414 295 323 minecraft:polished_deepslate
fill 414 295 324 414 298 324 minecraft:gray_concrete
fill 414 295 327 414 295 338 minecraft:light_blue_concrete
fill 414 295 342 414 295 359 minecraft:light_blue_concrete
setblock 414 295 363 minecraft:polished_deepslate
fill 415 295 323 415 298 323 minecraft:gray_concrete
setblock 415 295 362 minecraft:polished_deepslate
fill 415 295 363 415 298 363 minecraft:gray_concrete
setblock 416 295 361 minecraft:polished_deepslate
fill 416 295 362 416 298 362 minecraft:gray_concrete
setblock 417 295 325 minecraft:polished_deepslate
fill 417 295 343 417 295 344 minecraft:gray_concrete
setblock 417 295 345 minecraft:polished_deepslate
fill 417 295 346 417 298 346 minecraft:gray_concrete
setblock 417 295 360 minecraft:polished_deepslate
fill 417 295 361 417 298 361 minecraft:gray_concrete
setblock 376 296 344 minecraft:light_blue_stained_glass
fill 377 296 340 377 299 340 minecraft:gray_concrete
setblock 377 296 344 minecraft:polished_deepslate
fill 377 296 345 377 299 345 minecraft:gray_concrete
fill 377 296 347 377 296 348 minecraft:gray_concrete
setblock 377 296 349 minecraft:polished_deepslate
fill 377 296 350 377 299 350 minecraft:gray_concrete
fill 377 296 352 377 297 352 minecraft:gray_concrete
setblock 377 296 359 minecraft:polished_deepslate
fill 377 296 360 377 297 360 minecraft:gray_concrete
setblock 378 296 342 minecraft:gray_concrete
setblock 378 296 343 minecraft:polished_deepslate
fill 378 296 344 378 299 344 minecraft:gray_concrete
setblock 378 296 348 minecraft:polished_deepslate
fill 378 296 349 378 299 349 minecraft:gray_concrete
setblock 378 296 363 minecraft:polished_deepslate
fill 379 296 323 382 296 323 minecraft:gray_concrete
setblock 379 296 325 minecraft:light[level=12]
setblock 379 296 332 minecraft:light[level=12]
setblock 379 296 339 minecraft:light[level=12]
setblock 379 296 346 minecraft:light[level=12]
setblock 379 296 353 minecraft:light[level=12]
setblock 379 296 360 minecraft:light[level=12]
fill 379 296 363 382 296 363 minecraft:gray_concrete
setblock 383 296 323 minecraft:polished_deepslate
fill 383 296 324 384 298 324 minecraft:gray_concrete
setblock 383 296 362 minecraft:gray_concrete
setblock 383 296 363 minecraft:polished_deepslate
fill 384 296 323 384 299 323 minecraft:gray_concrete
setblock 384 296 362 minecraft:polished_deepslate
fill 384 296 363 384 299 363 minecraft:gray_concrete
fill 385 296 362 385 299 362 minecraft:gray_concrete
setblock 386 296 324 minecraft:gray_concrete
setblock 386 296 325 minecraft:light[level=12]
setblock 386 296 332 minecraft:light[level=12]
setblock 386 296 339 minecraft:light[level=12]
setblock 386 296 346 minecraft:light[level=12]
setblock 386 296 353 minecraft:light[level=12]
setblock 386 296 360 minecraft:light[level=12]
setblock 387 296 324 minecraft:polished_deepslate
fill 387 296 325 390 296 325 minecraft:gray_concrete
setblock 388 296 323 minecraft:polished_deepslate
fill 388 296 324 388 299 324 minecraft:gray_concrete
setblock 388 296 363 minecraft:polished_deepslate
fill 389 296 323 389 299 323 minecraft:gray_concrete
setblock 389 296 362 minecraft:polished_deepslate
fill 389 296 363 389 299 363 minecraft:gray_concrete
setblock 390 296 362 minecraft:gray_concrete
setblock 391 296 324 minecraft:gray_concrete
setblock 391 296 325 minecraft:polished_deepslate
setblock 392 296 324 minecraft:polished_deepslate
setblock 393 296 323 minecraft:polished_deepslate
fill 393 296 324 396 296 324 minecraft:gray_concrete
setblock 393 296 325 minecraft:light[level=12]
setblock 393 296 332 minecraft:light[level=12]
setblock 393 296 339 minecraft:light[level=12]
setblock 393 296 346 minecraft:light[level=12]
setblock 393 296 353 minecraft:light[level=12]
setblock 393 296 360 minecraft:light[level=12]
setblock 393 296 363 minecraft:polished_deepslate
fill 394 296 323 397 296 323 minecraft:gray_concrete
fill 394 296 363 394 297 363 minecraft:gray_concrete
fill 396 296 363 397 296 363 minecraft:gray_concrete
setblock 397 296 324 minecraft:polished_deepslate
setblock 398 296 323 minecraft:polished_deepslate
fill 398 296 324 401 296 324 minecraft:gray_concrete
setblock 398 296 363 minecraft:polished_deepslate
fill 399 296 323 402 296 323 minecraft:gray_concrete
fill 399 296 363 402 296 363 minecraft:gray_concrete
setblock 400 296 325 minecraft:light[level=12]
setblock 400 296 332 minecraft:light[level=12]
setblock 400 296 339 minecraft:light[level=12]
setblock 400 296 346 minecraft:light[level=12]
setblock 400 296 353 minecraft:light[level=12]
setblock 400 296 360 minecraft:light[level=12]
setblock 401 296 325 minecraft:polished_deepslate
setblock 402 296 324 minecraft:polished_deepslate
fill 402 296 325 402 299 325 minecraft:gray_concrete
fill 402 296 362 403 296 362 minecraft:gray_concrete
setblock 403 296 323 minecraft:polished_deepslate
fill 403 296 324 403 299 324 minecraft:gray_concrete
setblock 403 296 363 minecraft:polished_deepslate
fill 404 296 323 404 299 323 minecraft:gray_concrete
setblock 404 296 362 minecraft:polished_deepslate
fill 404 296 363 404 299 363 minecraft:gray_concrete
setblock 405 296 326 minecraft:polished_deepslate
setblock 405 296 361 minecraft:polished_deepslate
fill 405 296 362 405 299 362 minecraft:gray_concrete
setblock 406 296 324 minecraft:gray_concrete
setblock 406 296 325 minecraft:polished_deepslate
fill 406 296 326 406 299 326 minecraft:gray_concrete
fill 406 296 361 406 299 361 minecraft:gray_concrete
setblock 406 296 364 minecraft:light_blue_stained_glass
setblock 407 296 324 minecraft:polished_deepslate
fill 407 296 325 407 299 325 minecraft:gray_concrete
setblock 407 296 332 minecraft:light[level=12]
setblock 407 296 339 minecraft:light[level=12]
setblock 407 296 346 minecraft:light[level=12]
setblock 407 296 353 minecraft:light[level=12]
setblock 407 296 360 minecraft:light[level=12]
setblock 408 296 323 minecraft:polished_deepslate
fill 408 296 324 408 299 324 minecraft:gray_concrete
setblock 408 296 363 minecraft:polished_deepslate
fill 409 296 323 409 299 323 minecraft:gray_concrete
setblock 409 296 326 minecraft:gray_concrete
setblock 409 296 362 minecraft:polished_deepslate
fill 409 296 363 409 299 363 minecraft:gray_concrete
setblock 410 296 325 minecraft:gray_concrete
setblock 410 296 361 minecraft:polished_deepslate
fill 410 296 362 410 299 362 minecraft:gray_concrete
setblock 411 296 325 minecraft:polished_deepslate
fill 411 296 361 411 298 361 minecraft:gray_concrete
setblock 412 296 324 minecraft:polished_deepslate
fill 412 296 325 413 297 325 minecraft:gray_concrete
setblock 413 296 323 minecraft:polished_deepslate
fill 413 296 324 413 299 324 minecraft:gray_concrete
setblock 413 296 363 minecraft:polished_deepslate
fill 414 296 323 414 299 323 minecraft:gray_concrete
setblock 414 296 325 minecraft:light[level=12]
setblock 414 296 332 minecraft:light[level=12]
setblock 414 296 346 minecraft:light[level=12]
setblock 414 296 353 minecraft:light[level=12]
setblock 414 296 360 minecraft:light[level=12]
setblock 414 296 362 minecraft:polished_deepslate
fill 414 296 363 414 299 363 minecraft:gray_concrete
fill 415 296 362 415 299 362 minecraft:gray_concrete
setblock 416 296 324 minecraft:gray_concrete
setblock 416 296 360 minecraft:polished_deepslate
fill 416 296 361 416 297 361 minecraft:gray_concrete
setblock 417 296 324 minecraft:polished_deepslate
fill 417 296 325 417 298 326 minecraft:gray_concrete
fill 417 296 342 417 296 343 minecraft:gray_concrete
setblock 417 296 344 minecraft:polished_deepslate
fill 417 296 345 417 299 345 minecraft:gray_concrete
fill 417 296 347 417 296 348 minecraft:gray_concrete
setblock 417 296 349 minecraft:polished_deepslate
fill 417 296 357 417 297 357 minecraft:gray_concrete
setblock 417 296 359 minecraft:polished_deepslate
fill 417 296 360 417 299 360 minecraft:gray_concrete
fill 376 297 344 377 300 344 minecraft:gray_concrete
setblock 377 297 323 minecraft:polished_deepslate
fill 377 297 324 377 300 324 minecraft:gray_concrete
setblock 377 297 343 minecraft:polished_deepslate
setblock 377 297 347 minecraft:gray_concrete
setblock 377 297 348 minecraft:polished_deepslate
fill 377 297 349 377 300 349 minecraft:gray_concrete
setblock 377 297 353 minecraft:polished_deepslate
fill 377 297 354 377 300 354 minecraft:gray_concrete
setblock 377 297 362 minecraft:gray_concrete
setblock 377 297 363 minecraft:polished_deepslate
fill 378 297 322 378 300 323 minecraft:gray_concrete
setblock 378 297 341 minecraft:gray_concrete
setblock 378 297 342 minecraft:polished_deepslate
fill 378 297 343 379 299 343 minecraft:gray_concrete
setblock 378 297 347 minecraft:polished_deepslate
fill 378 297 348 378 300 348 minecraft:gray_concrete
fill 378 297 350 378 298 350 minecraft:gray_concrete
fill 378 297 363 381 297 363 minecraft:gray_concrete
fill 379 297 323 381 297 323 minecraft:gray_concrete
fill 379 297 344 379 297 345 minecraft:gray_concrete
setblock 379 297 346 minecraft:polished_deepslate
fill 379 297 347 379 300 347 minecraft:gray_concrete
fill 379 297 355 379 297 356 minecraft:light_blue_concrete
fill 380 297 354 382 298 354 minecraft:light_blue_concrete
fill 380 297 357 382 298 357 minecraft:light_blue_concrete
setblock 382 297 323 minecraft:polished_deepslate
fill 382 297 324 382 300 324 minecraft:gray_concrete
setblock 382 297 363 minecraft:polished_deepslate
fill 383 297 323 383 300 323 minecraft:gray_concrete
fill 383 297 355 383 297 356 minecraft:light_blue_concrete
setblock 383 297 362 minecraft:polished_deepslate
fill 383 297 363 383 300 363 minecraft:gray_concrete
fill 384 297 362 384 299 362 minecraft:gray_concrete
setblock 385 297 325 minecraft:polished_deepslate
fill 385 297 343 387 298 343 minecraft:white_wool
setblock 386 297 324 minecraft:polished_deepslate
fill 386 297 325 389 297 325 minecraft:gray_concrete
fill 386 297 342 386 298 342 minecraft:white_wool
fill 386 297 344 386 298 344 minecraft:white_wool
setblock 387 297 323 minecraft:polished_deepslate
fill 387 297 324 387 300 324 minecraft:gray_concrete
setblock 387 297 363 minecraft:polished_deepslate
fill 388 297 323 388 300 323 minecraft:gray_concrete
setblock 388 297 362 minecraft:polished_deepslate
fill 388 297 363 388 300 363 minecraft:gray_concrete
setblock 389 297 362 minecraft:gray_concrete
setblock 390 297 325 minecraft:polished_deepslate
setblock 391 297 324 minecraft:polished_deepslate
fill 391 297 325 392 299 325 minecraft:gray_concrete
setblock 392 297 323 minecraft:polished_deepslate
fill 392 297 324 395 297 324 minecraft:gray_concrete
setblock 392 297 363 minecraft:polished_deepslate
fill 393 297 323 396 297 323 minecraft:gray_concrete
fill 393 297 363 393 298 363 minecraft:gray_concrete
setblock 396 297 324 minecraft:polished_deepslate
setblock 397 297 323 minecraft:polished_deepslate
fill 397 297 324 400 297 324 minecraft:gray_concrete
setblock 397 297 363 minecraft:polished_deepslate
fill 398 297 323 401 297 323 minecraft:gray_concrete
fill 398 297 363 401 297 363 minecraft:gray_concrete
setblock 399 297 322 minecraft:light_blue_stained_glass
setblock 399 297 325 minecraft:gray_concrete
setblock 400 297 325 minecraft:polished_deepslate
setblock 401 297 324 minecraft:polished_deepslate
fill 401 297 325 401 300 325 minecraft:gray_concrete
setblock 402 297 323 minecraft:polished_deepslate
fill 402 297 324 402 300 324 minecraft:gray_concrete
setblock 402 297 362 minecraft:gray_concrete
setblock 402 297 363 minecraft:polished_deepslate
fill 403 297 323 403 300 323 minecraft:gray_concrete
setblock 403 297 326 minecraft:gray_concrete
setblock 403 297 362 minecraft:polished_deepslate
fill 403 297 363 403 300 363 minecraft:gray_concrete
setblock 404 297 325 minecraft:gray_concrete
setblock 404 297 326 minecraft:polished_deepslate
fill 404 297 362 404 300 362 minecraft:gray_concrete
setblock 405 297 325 minecraft:polished_deepslate
fill 405 297 326 405 300 326 minecraft:gray_concrete
fill 405 297 361 405 299 361 minecraft:gray_concrete
setblock 406 297 324 minecraft:polished_deepslate
fill 406 297 325 406 300 325 minecraft:gray_concrete
fill 406 297 364 406 308 364 minecraft:gray_concrete
setblock 407 297 323 minecraft:polished_deepslate
fill 407 297 324 407 300 324 minecraft:gray_concrete
setblock 407 297 363 minecraft:polished_deepslate
fill 408 297 323 408 300 323 minecraft:gray_concrete
setblock 408 297 362 minecraft:polished_deepslate
fill 408 297 363 408 300 363 minecraft:gray_concrete
setblock 409 297 326 minecraft:polished_deepslate
setblock 409 297 361 minecraft:polished_deepslate
fill 409 297 362 409 300 362 minecraft:gray_concrete
setblock 410 297 325 minecraft:polished_deepslate
fill 410 297 326 410 298 326 minecraft:gray_concrete
fill 410 297 339 411 297 342 minecraft:light_blue_concrete
fill 410 297 361 410 299 361 minecraft:gray_concrete
setblock 411 297 324 minecraft:polished_deepslate
fill 411 297 325 411 300 325 minecraft:gray_concrete
fill 411 297 338 416 297 338 minecraft:light_blue_concrete
fill 411 297 343 415 297 343 minecraft:light_blue_concrete
setblock 412 297 323 minecraft:polished_deepslate
fill 412 297 324 412 300 324 minecraft:gray_concrete
fill 412 297 337 414 297 337 minecraft:light_blue_concrete
fill 412 297 342 412 299 342 minecraft:light_blue_concrete
setblock 412 297 363 minecraft:polished_deepslate
fill 413 297 323 413 300 323 minecraft:gray_concrete
setblock 413 297 362 minecraft:polished_deepslate
fill 413 297 363 413 300 363 minecraft:gray_concrete
fill 414 297 342 416 297 342 minecraft:light_blue_concrete
fill 414 297 362 414 299 362 minecraft:gray_concrete
fill 415 297 339 416 297 339 minecraft:light_blue_concrete
fill 415 297 341 416 298 341 minecraft:light_blue_concrete
setblock 416 297 324 minecraft:polished_deepslate
fill 416 297 340 416 298 340 minecraft:light_blue_concrete
setblock 417 297 323 minecraft:polished_deepslate
fill 417 297 324 417 300 324 minecraft:gray_concrete
setblock 417 297 342 minecraft:gray_concrete
setblock 417 297 343 minecraft:polished_deepslate
fill 417 297 344 417 300 344 minecraft:gray_concrete
setblock 417 297 347 minecraft:gray_concrete
setblock 417 297 348 minecraft:polished_deepslate
fill 417 297 349 417 297 352 minecraft:gray_concrete
setblock 417 297 358 minecraft:polished_deepslate
fill 417 297 359 417 300 359 minecraft:gray_concrete
setblock 417 297 363 minecraft:polished_deepslate
setblock 417 297 364 minecraft:light_blue_stained_glass
setblock 418 297 342 minecraft:light_blue_stained_glass
setblock 376 298 346 minecraft:light_blue_stained_glass
fill 377 298 323 377 299 323 minecraft:gray_concrete
fill 377 298 325 377 299 325 minecraft:gray_concrete
setblock 377 298 342 minecraft:polished_deepslate
fill 377 298 343 377 300 343 minecraft:gray_concrete
setblock 377 298 346 minecraft:gray_concrete
setblock 377 298 347 minecraft:polished_deepslate
fill 377 298 348 377 300 348 minecraft:gray_concrete
setblock 377 298 352 minecraft:polished_deepslate
fill 377 298 353 377 300 353 minecraft:gray_concrete
setblock 377 298 362 minecraft:polished_deepslate
fill 377 298 363 380 298 363 minecraft:gray_concrete
setblock 378 298 341 minecraft:polished_deepslate
fill 378 298 342 378 300 342 minecraft:gray_concrete
setblock 378 298 346 minecraft:polished_deepslate
fill 378 298 347 378 300 347 minecraft:gray_concrete
setblock 378 298 351 minecraft:polished_deepslate
fill 379 298 323 380 298 323 minecraft:gray_concrete
setblock 379 298 344 minecraft:gray_concrete
setblock 379 298 345 minecraft:polished_deepslate
fill 379 298 346 379 300 346 minecraft:gray_concrete
fill 379 298 348 379 298 349 minecraft:gray_concrete
setblock 381 298 323 minecraft:polished_deepslate
fill 381 298 324 381 300 324 minecraft:gray_concrete
setblock 381 298 363 minecraft:polished_deepslate
fill 382 298 323 382 300 323 minecraft:gray_concrete
fill 382 298 363 382 300 363 minecraft:gray_concrete
setblock 383 298 362 minecraft:gray_concrete
setblock 384 298 325 minecraft:polished_deepslate
setblock 385 298 323 minecraft:gray_concrete
setblock 385 298 324 minecraft:polished_deepslate
fill 385 298 325 388 298 325 minecraft:gray_concrete
setblock 386 298 323 minecraft:polished_deepslate
fill 386 298 324 386 300 324 minecraft:gray_concrete
setblock 386 298 363 minecraft:polished_deepslate
fill 387 298 323 387 300 323 minecraft:gray_concrete
setblock 387 298 362 minecraft:polished_deepslate
fill 387 298 363 387 300 363 minecraft:gray_concrete
setblock 388 298 362 minecraft:gray_concrete
setblock 389 298 325 minecraft:polished_deepslate
setblock 390 298 324 minecraft:polished_deepslate
fill 390 298 325 390 300 325 minecraft:gray_concrete
setblock 391 298 323 minecraft:polished_deepslate
fill 391 298 324 394 298 324 minecraft:gray_concrete
setblock 391 298 363 minecraft:polished_deepslate
fill 392 298 323 395 298 323 minecraft:gray_concrete
fill 392 298 363 392 299 363 minecraft:gray_concrete
setblock 393 298 325 minecraft:gray_concrete
setblock 393 298 364 minecraft:light_blue_stained_glass
setblock 395 298 324 minecraft:polished_deepslate
setblock 396 298 323 minecraft:polished_deepslate
fill 396 298 324 399 298 324 minecraft:gray_concrete
fill 397 298 323 400 298 323 minecraft:gray_concrete
fill 397 298 363 400 298 363 minecraft:gray_concrete
setblock 398 298 325 minecraft:gray_concrete
fill 399 298 322 399 308 322 minecraft:gray_concrete
setblock 399 298 325 minecraft:polished_deepslate
setblock 400 298 324 minecraft:polished_deepslate
fill 400 298 325 400 300 325 minecraft:gray_concrete
setblock 401 298 323 minecraft:polished_deepslate
fill 401 298 324 401 300 324 minecraft:gray_concrete
setblock 401 298 362 minecraft:gray_concrete
setblock 401 298 363 minecraft:polished_deepslate
fill 402 298 323 402 300 323 minecraft:gray_concrete
setblock 402 298 326 minecraft:gray_concrete
setblock 402 298 362 minecraft:polished_deepslate
fill 402 298 363 402 300 363 minecraft:gray_concrete
setblock 403 298 326 minecraft:polished_deepslate
fill 403 298 362 403 300 362 minecraft:gray_concrete
setblock 404 298 325 minecraft:polished_deepslate
fill 404 298 326 404 300 326 minecraft:gray_concrete
setblock 405 298 324 minecraft:polished_deepslate
fill 405 298 325 405 300 325 minecraft:gray_concrete
setblock 406 298 323 minecraft:polished_deepslate
fill 406 298 324 406 300 324 minecraft:gray_concrete
setblock 406 298 363 minecraft:polished_deepslate
fill 407 298 323 407 300 323 minecraft:gray_concrete
setblock 407 298 326 minecraft:gray_concrete
setblock 407 298 362 minecraft:polished_deepslate
fill 407 298 363 407 300 363 minecraft:gray_concrete
setblock 408 298 326 minecraft:polished_deepslate
setblock 408 298 361 minecraft:polished_deepslate
fill 408 298 362 408 300 362 minecraft:gray_concrete
setblock 409 298 325 minecraft:polished_deepslate
fill 409 298 326 409 299 326 minecraft:gray_concrete
fill 409 298 361 409 299 361 minecraft:gray_concrete
setblock 410 298 324 minecraft:polished_deepslate
fill 410 298 325 410 300 325 minecraft:gray_concrete
fill 410 298 340 411 298 340 minecraft:light_blue_concrete
setblock 411 298 323 minecraft:polished_deepslate
fill 411 298 324 411 300 324 minecraft:gray_concrete
fill 411 298 338 411 298 339 minecraft:light_blue_concrete
fill 411 298 341 411 298 342 minecraft:light_blue_concrete
setblock 411 298 363 minecraft:polished_deepslate
fill 412 298 323 412 300 323 minecraft:gray_concrete
fill 412 298 325 412 299 325 minecraft:gray_concrete
fill 412 298 338 415 298 338 minecraft:light_blue_concrete
fill 412 298 343 414 298 343 minecraft:light_blue_concrete
setblock 412 298 362 minecraft:polished_deepslate
fill 412 298 363 412 300 363 minecraft:gray_concrete
fill 413 298 362 413 300 362 minecraft:gray_concrete
fill 414 298 342 415 298 342 minecraft:light_blue_concrete
setblock 415 298 324 minecraft:polished_deepslate
fill 415 298 339 415 299 339 minecraft:light_blue_concrete
setblock 416 298 323 minecraft:polished_deepslate
setblock 416 298 324 minecraft:gray_concrete
setblock 416 298 363 minecraft:polished_deepslate
fill 417 298 323 417 300 323 minecraft:gray_concrete
setblock 417 298 327 minecraft:polished_deepslate
setblock 417 298 342 minecraft:polished_deepslate
fill 417 298 343 417 300 343 minecraft:gray_concrete
setblock 417 298 347 minecraft:polished_deepslate
fill 417 298 348 417 298 351 minecraft:gray_concrete
setblock 417 298 352 minecraft:polished_deepslate
fill 417 298 353 417 300 354 minecraft:gray_concrete
setblock 417 298 357 minecraft:polished_deepslate
fill 417 298 358 417 299 358 minecraft:gray_concrete
setblock 417 298 362 minecraft:polished_deepslate
fill 417 298 363 417 300 364 minecraft:gray_concrete
fill 418 298 342 418 308 342 minecraft:gray_concrete
fill 376 299 346 376 308 346 minecraft:gray_concrete
setblock 377 299 341 minecraft:polished_deepslate
fill 377 299 342 377 300 342 minecraft:gray_concrete
setblock 377 299 346 minecraft:polished_deepslate
fill 377 299 347 377 300 347 minecraft:gray_concrete
setblock 377 299 351 minecraft:polished_deepslate
fill 377 299 352 378 300 352 minecraft:gray_concrete
setblock 377 299 355 minecraft:gray_concrete
fill 377 299 363 379 299 363 minecraft:gray_concrete
setblock 378 299 341 minecraft:gray_concrete
setblock 378 299 345 minecraft:polished_deepslate
fill 378 299 346 378 300 346 minecraft:gray_concrete
setblock 378 299 350 minecraft:polished_deepslate
fill 378 299 351 378 300 351 minecraft:gray_concrete
setblock 379 299 323 minecraft:gray_concrete
setblock 379 299 344 minecraft:polished_deepslate
fill 379 299 345 379 300 345 minecraft:gray_concrete
setblock 379 299 348 minecraft:gray_concrete
setblock 379 299 349 minecraft:polished_deepslate
fill 379 299 350 379 300 350 minecraft:gray_concrete
setblock 380 299 323 minecraft:polished_deepslate
fill 380 299 346 380 299 347 minecraft:gray_concrete
setblock 380 299 363 minecraft:polished_deepslate
fill 381 299 323 381 300 323 minecraft:gray_concrete
setblock 381 299 354 minecraft:light_blue_concrete
setblock 381 299 357 minecraft:light_blue_concrete
fill 381 299 363 381 300 363 minecraft:gray_concrete
setblock 383 299 324 minecraft:gray_concrete
setblock 383 299 325 minecraft:polished_deepslate
setblock 384 299 324 minecraft:polished_deepslate
fill 384 299 325 387 299 325 minecraft:gray_concrete
setblock 385 299 323 minecraft:polished_deepslate
fill 385 299 324 385 300 324 minecraft:gray_concrete
setblock 385 299 363 minecraft:polished_deepslate
fill 386 299 323 386 300 323 minecraft:gray_concrete
setblock 386 299 362 minecraft:polished_deepslate
fill 386 299 363 386 300 363 minecraft:gray_concrete
setblock 388 299 325 minecraft:polished_deepslate
setblock 389 299 324 minecraft:polished_deepslate
fill 389 299 325 389 300 325 minecraft:gray_concrete
setblock 390 299 323 minecraft:polished_deepslate
fill 390 299 324 393 299 324 minecraft:gray_concrete
setblock 390 299 363 minecraft:polished_deepslate
fill 391 299 323 394 299 323 minecraft:gray_concrete
setblock 391 299 363 minecraft:gray_concrete
fill 393 299 364 393 308 364 minecraft:gray_concrete
setblock 394 299 324 minecraft:polished_deepslate
setblock 395 299 323 minecraft:polished_deepslate
fill 395 299 324 398 299 324 minecraft:gray_concrete
fill 396 299 323 399 299 323 minecraft:gray_concrete
setblock 397 299 325 minecraft:gray_concrete
setblock 398 299 325 minecraft:polished_deepslate
fill 398 299 363 399 299 363 minecraft:gray_concrete
setblock 399 299 324 minecraft:polished_deepslate
fill 399 299 325 399 300 325 minecraft:gray_concrete
setblock 400 299 323 minecraft:polished_deepslate
fill 400 299 324 400 300 324 minecraft:gray_concrete
setblock 400 299 363 minecraft:polished_deepslate
fill 401 299 323 401 300 323 minecraft:gray_concrete
setblock 401 299 326 minecraft:gray_concrete
setblock 401 299 362 minecraft:polished_deepslate
fill 401 299 363 401 300 363 minecraft:gray_concrete
setblock 402 299 326 minecraft:polished_deepslate
fill 402 299 362 402 300 362 minecraft:gray_concrete
setblock 403 299 325 minecraft:polished_deepslate
fill 403 299 326 403 300 326 minecraft:gray_concrete
setblock 404 299 324 minecraft:polished_deepslate
fill 404 299 325 404 300 325 minecraft:gray_concrete
setblock 405 299 323 minecraft:polished_deepslate
fill 405 299 324 405 300 324 minecraft:gray_concrete
setblock 405 299 363 minecraft:polished_deepslate
fill 406 299 323 406 300 323 minecraft:gray_concrete
setblock 406 299 362 minecraft:polished_deepslate
fill 406 299 363 406 300 363 minecraft:gray_concrete
setblock 407 299 326 minecraft:polished_deepslate
setblock 407 299 361 minecraft:polished_deepslate
fill 407 299 362 407 300 362 minecraft:gray_concrete
setblock 408 299 325 minecraft:polished_deepslate
fill 408 299 326 408 300 326 minecraft:gray_concrete
fill 408 299 361 408 300 361 minecraft:gray_concrete
setblock 409 299 324 minecraft:polished_deepslate
fill 409 299 325 409 300 325 minecraft:gray_concrete
setblock 410 299 323 minecraft:polished_deepslate
fill 410 299 324 410 300 324 minecraft:gray_concrete
setblock 410 299 363 minecraft:polished_deepslate
fill 411 299 323 411 300 323 minecraft:gray_concrete
fill 411 299 339 411 299 341 minecraft:light_blue_concrete
setblock 411 299 362 minecraft:polished_deepslate
fill 411 299 363 411 300 363 minecraft:gray_concrete
fill 412 299 338 414 299 338 minecraft:light_blue_concrete
fill 412 299 362 412 300 362 minecraft:gray_concrete
setblock 414 299 324 minecraft:polished_deepslate
setblock 414 299 342 minecraft:light_blue_concrete
setblock 415 299 323 minecraft:polished_deepslate
setblock 415 299 324 minecraft:gray_concrete
setblock 415 299 341 minecraft:light_blue_concrete
setblock 415 299 363 minecraft:polished_deepslate
fill 416 299 323 416 300 323 minecraft:gray_concrete
setblock 416 299 347 minecraft:polished_deepslate
fill 416 299 348 417 300 349 minecraft:gray_concrete
fill 416 299 363 416 300 363 minecraft:gray_concrete
setblock 417 299 325 minecraft:gray_concrete
setblock 417 299 326 minecraft:polished_deepslate
fill 417 299 327 417 300 327 minecraft:gray_concrete
setblock 417 299 346 minecraft:polished_deepslate
fill 417 299 347 417 300 347 minecraft:gray_concrete
setblock 417 299 350 minecraft:gray_concrete
setblock 417 299 351 minecraft:polished_deepslate
fill 417 299 352 417 300 352 minecraft:gray_concrete
setblock 417 299 355 minecraft:gray_concrete
setblock 417 299 356 minecraft:polished_deepslate
setblock 417 299 357 minecraft:gray_concrete
setblock 417 299 361 minecraft:polished_deepslate
fill 417 299 362 417 300 362 minecraft:gray_concrete
setblock 377 300 325 minecraft:polished_deepslate
setblock 377 300 326 minecraft:gray_concrete
setblock 377 300 340 minecraft:polished_deepslate
setblock 377 300 341 minecraft:gray_concrete
setblock 377 300 345 minecraft:polished_deepslate
setblock 377 300 346 minecraft:gray_concrete
setblock 377 300 350 minecraft:polished_deepslate
setblock 377 300 351 minecraft:gray_concrete
setblock 377 300 355 minecraft:polished_deepslate
setblock 378 300 343 minecraft:gray_concrete
setblock 378 300 344 minecraft:polished_deepslate
setblock 378 300 345 minecraft:gray_concrete
setblock 378 300 349 minecraft:polished_deepslate
setblock 378 300 350 minecraft:gray_concrete
setblock 379 300 323 minecraft:polished_deepslate
setblock 379 300 343 minecraft:polished_deepslate
setblock 379 300 344 minecraft:gray_concrete
setblock 379 300 348 minecraft:polished_deepslate
setblock 379 300 349 minecraft:gray_concrete
setblock 379 300 363 minecraft:polished_deepslate
setblock 380 300 323 minecraft:gray_concrete
setblock 380 300 346 minecraft:gray_concrete
setblock 380 300 347 minecraft:polished_deepslate
setblock 380 300 348 minecraft:gray_concrete
setblock 380 300 363 minecraft:gray_concrete
setblock 383 300 324 minecraft:polished_deepslate
fill 383 300 325 386 300 325 minecraft:gray_concrete
setblock 384 300 323 minecraft:polished_deepslate
setblock 384 300 324 minecraft:gray_concrete
setblock 384 300 363 minecraft:polished_deepslate
setblock 385 300 323 minecraft:gray_concrete
setblock 385 300 363 minecraft:gray_concrete
setblock 387 300 325 minecraft:polished_deepslate
setblock 388 300 324 minecraft:polished_deepslate
setblock 388 300 325 minecraft:gray_concrete
setblock 389 300 323 minecraft:polished_deepslate
fill 389 300 324 392 300 324 minecraft:gray_concrete
setblock 389 300 363 minecraft:polished_deepslate
fill 390 300 323 393 300 323 minecraft:gray_concrete
setblock 390 300 363 minecraft:gray_concrete
setblock 391 300 325 minecraft:gray_concrete
setblock 393 300 324 minecraft:polished_deepslate
setblock 394 300 323 minecraft:polished_deepslate
fill 394 300 324 397 300 324 minecraft:gray_concrete
fill 395 300 323 398 300 323 minecraft:gray_concrete
setblock 397 300 325 minecraft:polished_deepslate
setblock 398 300 324 minecraft:polished_deepslate
setblock 398 300 325 minecraft:gray_concrete
setblock 398 300 363 minecraft:gray_concrete
setblock 399 300 323 minecraft:polished_deepslate
setblock 399 300 324 minecraft:gray_concrete
setblock 399 300 363 minecraft:polished_deepslate
setblock 400 300 323 minecraft:gray_concrete
setblock 400 300 363 minecraft:gray_concrete
setblock 401 300 326 minecraft:polished_deepslate
setblock 402 300 325 minecraft:polished_deepslate
setblock 402 300 326 minecraft:gray_concrete
setblock 403 300 324 minecraft:polished_deepslate
setblock 403 300 325 minecraft:gray_concrete
setblock 404 300 323 minecraft:polished_deepslate
setblock 404 300 324 minecraft:gray_concrete
setblock 404 300 363 minecraft:polished_deepslate
setblock 405 300 323 minecraft:gray_concrete
setblock 405 300 362 minecraft:polished_deepslate
setblock 405 300 363 minecraft:gray_concrete
setblock 406 300 326 minecraft:polished_deepslate
setblock 406 300 361 minecraft:polished_deepslate
setblock 406 300 362 minecraft:gray_concrete
setblock 407 300 325 minecraft:polished_deepslate
setblock 407 300 326 minecraft:gray_concrete
setblock 407 300 361 minecraft:gray_concrete
setblock 408 300 324 minecraft:polished_deepslate
setblock 408 300 325 minecraft:gray_concrete
setblock 409 300 323 minecraft:polished_deepslate
setblock 409 300 324 minecraft:gray_concrete
setblock 409 300 363 minecraft:polished_deepslate
setblock 410 300 323 minecraft:gray_concrete
setblock 410 300 362 minecraft:polished_deepslate
setblock 410 300 363 minecraft:gray_concrete
setblock 411 300 362 minecraft:gray_concrete
setblock 413 300 324 minecraft:polished_deepslate
setblock 414 300 322 minecraft:light_blue_stained_glass
setblock 414 300 323 minecraft:polished_deepslate
setblock 414 300 324 minecraft:gray_concrete
setblock 414 300 363 minecraft:polished_deepslate
fill 415 300 322 415 300 323 minecraft:gray_concrete
setblock 415 300 363 minecraft:gray_concrete
setblock 416 300 347 minecraft:gray_concrete
setblock 416 300 350 minecraft:gray_concrete
setblock 417 300 325 minecraft:polished_deepslate
setblock 417 300 326 minecraft:gray_concrete
setblock 417 300 345 minecraft:polished_deepslate
setblock 417 300 346 minecraft:gray_concrete
setblock 417 300 350 minecraft:polished_deepslate
setblock 417 300 351 minecraft:gray_concrete
setblock 417 300 355 minecraft:polished_deepslate
setblock 417 300 356 minecraft:gray_concrete
setblock 417 300 360 minecraft:polished_deepslate
setblock 417 300 361 minecraft:gray_concrete
setblock 418 300 329 minecraft:light_blue_stained_glass
fill 376 301 344 376 308 344 minecraft:gray_concrete
setblock 376 301 360 minecraft:light_blue_stained_glass
fill 378 301 322 378 308 322 minecraft:gray_concrete
fill 414 301 322 415 308 322 minecraft:gray_concrete
fill 417 301 364 417 303 364 minecraft:gray_concrete
fill 418 301 329 418 308 329 minecraft:gray_concrete
setblock 418 301 349 minecraft:light_blue_stained_glass
setblock 376 302 345 minecraft:light_blue_stained_glass
fill 376 302 360 376 308 360 minecraft:gray_concrete
setblock 379 302 325 minecraft:light[level=13]
setblock 379 302 332 minecraft:light[level=12]
setblock 379 302 333 minecraft:light[level=13]
setblock 379 302 339 minecraft:light[level=12]
setblock 379 302 341 minecraft:light[level=13]
setblock 379 302 346 minecraft:light[level=12]
setblock 379 302 349 minecraft:light[level=13]
setblock 379 302 353 minecraft:light[level=12]
setblock 379 302 357 minecraft:light[level=13]
setblock 379 302 360 minecraft:light[level=12]
setblock 386 302 325 minecraft:light[level=12]
setblock 386 302 332 minecraft:light[level=12]
setblock 386 302 339 minecraft:light[level=12]
setblock 386 302 346 minecraft:light[level=12]
setblock 386 302 353 minecraft:light[level=12]
setblock 386 302 360 minecraft:light[level=12]
setblock 387 302 325 minecraft:light[level=13]
setblock 387 302 333 minecraft:light[level=13]
setblock 387 302 341 minecraft:light[level=13]
setblock 387 302 349 minecraft:light[level=13]
setblock 387 302 357 minecraft:light[level=13]
setblock 393 302 325 minecraft:light[level=12]
setblock 393 302 332 minecraft:light[level=12]
setblock 393 302 339 minecraft:light[level=12]
setblock 393 302 346 minecraft:light[level=12]
setblock 393 302 353 minecraft:light[level=12]
setblock 393 302 360 minecraft:light[level=12]
setblock 395 302 325 minecraft:light[level=13]
setblock 395 302 333 minecraft:light[level=13]
setblock 395 302 341 minecraft:light[level=13]
setblock 395 302 349 minecraft:light[level=13]
setblock 395 302 357 minecraft:light[level=13]
setblock 400 302 325 minecraft:light[level=12]
setblock 400 302 332 minecraft:light[level=12]
setblock 400 302 339 minecraft:light[level=12]
setblock 400 302 346 minecraft:light[level=12]
setblock 400 302 353 minecraft:light[level=12]
setblock 400 302 360 minecraft:light[level=12]
setblock 403 302 325 minecraft:light[level=13]
setblock 403 302 333 minecraft:light[level=13]
setblock 403 302 341 minecraft:light[level=13]
setblock 403 302 349 minecraft:light[level=13]
setblock 403 302 357 minecraft:light[level=13]
setblock 407 302 325 minecraft:light[level=12]
setblock 407 302 332 minecraft:light[level=12]
setblock 407 302 339 minecraft:light[level=12]
setblock 407 302 346 minecraft:light[level=12]
setblock 407 302 353 minecraft:light[level=12]
setblock 407 302 360 minecraft:light[level=12]
setblock 411 302 325 minecraft:light[level=13]
setblock 411 302 333 minecraft:light[level=13]
setblock 411 302 341 minecraft:light[level=13]
setblock 411 302 349 minecraft:light[level=13]
setblock 411 302 357 minecraft:light[level=13]
setblock 414 302 325 minecraft:light[level=12]
setblock 414 302 332 minecraft:light[level=12]
setblock 414 302 339 minecraft:light[level=12]
setblock 414 302 346 minecraft:light[level=12]
setblock 414 302 353 minecraft:light[level=12]
setblock 414 302 360 minecraft:light[level=12]
setblock 418 302 341 minecraft:light_blue_stained_glass
fill 418 302 349 418 308 349 minecraft:gray_concrete
fill 376 303 345 376 308 345 minecraft:gray_concrete
fill 418 303 341 418 308 341 minecraft:gray_concrete
setblock 382 304 364 minecraft:light_blue_stained_glass
fill 383 304 322 384 308 322 minecraft:gray_concrete
setblock 385 304 322 minecraft:light_blue_stained_glass
setblock 417 304 364 minecraft:light_blue_stained_glass
setblock 379 305 364 minecraft:light_blue_stained_glass
fill 382 305 364 382 308 364 minecraft:gray_concrete
fill 385 305 322 385 308 322 minecraft:gray_concrete
fill 417 305 364 417 308 364 minecraft:gray_concrete
fill 379 306 364 379 308 364 minecraft:gray_concrete
setblock 387 306 322 minecraft:light_blue_stained_glass
setblock 405 306 322 minecraft:light_blue_stained_glass
fill 406 306 322 406 308 322 minecraft:gray_concrete
fill 387 307 322 387 308 322 minecraft:gray_concrete
fill 401 307 322 401 308 322 minecraft:gray_concrete
setblock 402 307 322 minecraft:light_blue_stained_glass
fill 405 307 322 405 308 322 minecraft:gray_concrete
setblock 402 308 322 minecraft:gray_concrete
setblock 418 308 346 minecraft:light_blue_stained_glass
