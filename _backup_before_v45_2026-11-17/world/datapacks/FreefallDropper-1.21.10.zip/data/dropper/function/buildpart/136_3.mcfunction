fill 207 260 596 207 262 596 minecraft:quartz_block
fill 207 260 598 207 273 598 minecraft:quartz_block
fill 208 260 591 208 262 591 minecraft:quartz_block
fill 208 260 593 208 262 593 minecraft:quartz_block
fill 208 260 595 208 262 595 minecraft:quartz_block
fill 208 260 597 208 265 597 minecraft:quartz_block
fill 209 260 590 209 262 590 minecraft:quartz_block
fill 209 260 592 209 262 592 minecraft:quartz_block
fill 209 260 594 209 262 594 minecraft:quartz_block
fill 209 260 596 209 262 596 minecraft:quartz_block
fill 209 260 598 209 273 598 minecraft:quartz_block
fill 210 260 591 210 262 591 minecraft:quartz_block
fill 210 260 593 210 262 593 minecraft:quartz_block
fill 210 260 595 210 262 595 minecraft:quartz_block
fill 210 260 597 210 265 597 minecraft:quartz_block
fill 211 260 558 212 261 558 minecraft:quartz_block
fill 211 260 590 211 262 590 minecraft:quartz_block
fill 211 260 592 211 262 592 minecraft:quartz_block
fill 211 260 594 211 262 594 minecraft:quartz_block
fill 211 260 596 211 262 596 minecraft:quartz_block
fill 211 260 598 211 262 598 minecraft:quartz_block
fill 212 260 559 214 265 559 minecraft:quartz_block
fill 212 260 591 212 262 591 minecraft:quartz_block
fill 212 260 593 212 262 593 minecraft:quartz_block
fill 212 260 595 212 262 595 minecraft:quartz_block
fill 212 260 597 212 262 597 minecraft:quartz_block
fill 213 260 590 213 262 590 minecraft:quartz_block
fill 213 260 592 213 262 592 minecraft:quartz_block
fill 213 260 594 213 262 594 minecraft:quartz_block
fill 213 260 596 213 262 596 minecraft:quartz_block
fill 213 260 598 213 262 598 minecraft:quartz_block
fill 214 260 591 214 262 591 minecraft:quartz_block
fill 214 260 593 214 262 593 minecraft:quartz_block
fill 214 260 595 214 262 595 minecraft:quartz_block
fill 214 260 597 214 262 597 minecraft:quartz_block
fill 215 260 590 215 262 590 minecraft:quartz_block
fill 215 260 592 215 262 592 minecraft:quartz_block
fill 215 260 594 215 262 594 minecraft:quartz_block
fill 215 260 596 215 262 596 minecraft:quartz_block
fill 215 260 598 215 262 598 minecraft:quartz_block
fill 220 260 597 222 265 597 minecraft:quartz_block
fill 224 260 559 226 265 559 minecraft:quartz_block
fill 228 260 567 228 265 569 minecraft:quartz_block
fill 228 260 579 228 265 581 minecraft:quartz_block
fill 228 260 591 228 265 593 minecraft:quartz_block
fill 203 261 559 203 261 562 minecraft:gold_block
fill 211 261 559 211 262 559 minecraft:quartz_block
fill 212 261 560 212 264 560 minecraft:quartz_block
fill 211 262 560 211 263 560 minecraft:quartz_block
setblock 212 262 558 minecraft:quartz_block
fill 212 262 561 212 264 561 minecraft:quartz_block
fill 213 262 560 213 263 560 minecraft:quartz_block
fill 204 263 591 207 263 597 minecraft:gold_block
fill 208 263 591 214 263 596 minecraft:gold_block
fill 211 263 561 211 264 561 minecraft:quartz_block
fill 211 263 597 214 263 597 minecraft:gold_block
setblock 212 263 558 minecraft:gold_block
fill 212 263 562 212 264 562 minecraft:quartz_block
fill 213 263 561 213 264 561 minecraft:quartz_block
fill 205 264 592 213 264 596 minecraft:gold_block
fill 211 264 562 211 264 563 minecraft:quartz_block
fill 212 264 563 212 266 564 minecraft:quartz_block
fill 212 264 591 212 266 591 minecraft:quartz_block
fill 213 264 562 213 264 563 minecraft:quartz_block
fill 189 265 561 189 265 566 minecraft:yellow_terracotta
fill 189 265 573 189 265 578 minecraft:yellow_terracotta
fill 189 265 585 189 265 590 minecraft:yellow_terracotta
fill 189 265 597 189 265 598 minecraft:yellow_terracotta
fill 190 265 598 193 265 598 minecraft:yellow_terracotta
fill 193 265 558 198 265 558 minecraft:yellow_terracotta
fill 200 265 598 205 265 598 minecraft:yellow_terracotta
fill 205 265 558 210 265 558 minecraft:yellow_terracotta
fill 206 265 593 212 265 595 minecraft:gold_block
fill 211 265 563 211 265 564 minecraft:quartz_block
fill 211 265 591 211 265 592 minecraft:quartz_block
fill 212 265 561 212 265 562 minecraft:gold_block
fill 212 265 565 212 267 565 minecraft:quartz_block
fill 212 265 590 212 267 590 minecraft:quartz_block
fill 212 265 592 213 265 592 minecraft:quartz_block
fill 212 265 598 217 265 598 minecraft:yellow_terracotta
fill 213 265 563 213 265 564 minecraft:quartz_block
fill 213 265 591 213 266 591 minecraft:quartz_block
fill 217 265 558 222 265 558 minecraft:yellow_terracotta
fill 224 265 598 229 265 598 minecraft:yellow_terracotta
fill 229 265 558 229 265 563 minecraft:yellow_terracotta
fill 229 265 570 229 265 575 minecraft:yellow_terracotta
fill 229 265 582 229 265 587 minecraft:yellow_terracotta
fill 229 265 594 229 265 597 minecraft:yellow_terracotta
fill 188 266 563 188 271 566 minecraft:ochre_froglight
fill 188 266 575 188 271 578 minecraft:ochre_froglight
fill 188 266 587 188 271 590 minecraft:ochre_froglight
fill 188 266 599 191 271 599 minecraft:ochre_froglight
setblock 191 266 560 minecraft:light[level=14]
setblock 191 266 568 minecraft:light[level=14]
setblock 191 266 576 minecraft:light[level=14]
setblock 191 266 584 minecraft:light[level=14]
setblock 191 266 592 minecraft:light[level=14]
fill 195 266 557 198 271 557 minecraft:ochre_froglight
setblock 199 266 560 minecraft:light[level=14]
setblock 199 266 568 minecraft:light[level=14]
setblock 199 266 576 minecraft:light[level=14]
setblock 199 266 584 minecraft:light[level=14]
setblock 199 266 592 minecraft:light[level=14]
fill 200 266 599 203 271 599 minecraft:ochre_froglight
fill 207 266 557 210 271 557 minecraft:ochre_froglight
setblock 207 266 560 minecraft:light[level=14]
setblock 207 266 568 minecraft:light[level=14]
setblock 207 266 584 minecraft:light[level=14]
setblock 207 266 592 minecraft:light[level=14]
fill 207 266 594 211 266 594 minecraft:gold_block
fill 211 266 564 211 266 566 minecraft:quartz_block
fill 211 266 589 211 266 591 minecraft:quartz_block
setblock 212 266 562 minecraft:gold_block
fill 212 266 566 212 267 567 minecraft:quartz_block
fill 212 266 588 212 268 589 minecraft:quartz_block
setblock 212 266 592 minecraft:quartz_block
setblock 212 266 593 minecraft:gold_block
fill 212 266 599 215 271 599 minecraft:ochre_froglight
fill 213 266 564 213 266 566 minecraft:quartz_block
fill 213 266 589 213 266 590 minecraft:quartz_block
setblock 215 266 560 minecraft:light[level=14]
setblock 215 266 568 minecraft:light[level=14]
setblock 215 266 576 minecraft:light[level=14]
setblock 215 266 584 minecraft:light[level=14]
setblock 215 266 592 minecraft:light[level=14]
fill 219 266 557 222 271 557 minecraft:ochre_froglight
setblock 223 266 560 minecraft:light[level=14]
setblock 223 266 568 minecraft:light[level=14]
setblock 223 266 576 minecraft:light[level=14]
setblock 223 266 584 minecraft:light[level=14]
setblock 223 266 592 minecraft:light[level=14]
fill 224 266 599 227 271 599 minecraft:ochre_froglight
fill 230 266 558 230 271 561 minecraft:ochre_froglight
fill 230 266 570 230 271 573 minecraft:ochre_froglight
fill 230 266 582 230 271 585 minecraft:ochre_froglight
fill 230 266 594 230 271 597 minecraft:ochre_froglight
fill 211 267 566 211 267 568 minecraft:quartz_block
fill 211 267 587 211 267 589 minecraft:quartz_block
setblock 212 267 564 minecraft:gold_block
fill 212 267 568 212 269 569 minecraft:quartz_block
fill 212 267 586 212 268 587 minecraft:quartz_block
setblock 212 267 591 minecraft:gold_block
fill 213 267 566 213 267 568 minecraft:quartz_block
fill 213 267 587 213 267 589 minecraft:quartz_block
fill 196 268 568 197 268 569 minecraft:gold_block
fill 211 268 567 211 268 570 minecraft:quartz_block
fill 211 268 585 211 268 588 minecraft:quartz_block
fill 212 268 565 212 268 566 minecraft:gold_block
fill 212 268 567 213 268 567 minecraft:quartz_block
fill 212 268 570 212 269 571 minecraft:quartz_block
fill 212 268 584 212 270 585 minecraft:quartz_block
setblock 212 268 590 minecraft:gold_block
fill 213 268 568 213 268 570 minecraft:quartz_block
fill 213 268 585 213 268 588 minecraft:quartz_block
fill 195 269 572 195 271 572 minecraft:yellow_stained_glass
fill 195 269 573 195 272 573 minecraft:gold_block
fill 195 269 574 195 273 578 minecraft:yellow_stained_glass
fill 195 269 579 195 272 579 minecraft:gold_block
fill 195 269 580 195 271 580 minecraft:yellow_stained_glass
fill 196 269 568 196 269 569 minecraft:gold_block
fill 196 269 570 196 271 571 minecraft:yellow_stained_glass
fill 196 269 581 196 271 582 minecraft:yellow_stained_glass
fill 197 269 568 197 270 569 minecraft:yellow_stained_glass
fill 197 269 583 197 270 584 minecraft:yellow_stained_glass
fill 198 269 567 198 271 567 minecraft:gold_block
fill 198 269 568 198 273 568 minecraft:yellow_stained_glass
fill 198 269 584 198 273 584 minecraft:yellow_stained_glass
fill 198 269 585 198 271 585 minecraft:gold_block
fill 199 269 566 199 270 567 minecraft:yellow_stained_glass
fill 199 269 585 199 270 586 minecraft:yellow_stained_glass
fill 200 269 566 200 272 566 minecraft:yellow_stained_glass
fill 200 269 586 200 272 586 minecraft:yellow_stained_glass
fill 201 269 565 202 271 565 minecraft:yellow_stained_glass
fill 201 269 587 202 271 587 minecraft:yellow_stained_glass
fill 203 269 564 203 271 564 minecraft:yellow_stained_glass
fill 203 269 588 203 271 588 minecraft:yellow_stained_glass
fill 204 269 564 204 272 564 minecraft:gold_block
fill 204 269 588 204 272 588 minecraft:gold_block
fill 205 269 564 209 273 564 minecraft:yellow_stained_glass
fill 205 269 588 209 273 588 minecraft:yellow_stained_glass
fill 210 269 564 210 272 564 minecraft:gold_block
fill 210 269 588 210 272 588 minecraft:gold_block
fill 211 269 564 211 271 564 minecraft:yellow_stained_glass
fill 211 269 569 211 269 572 minecraft:quartz_block
fill 211 269 583 211 269 586 minecraft:quartz_block
fill 211 269 588 211 271 588 minecraft:yellow_stained_glass
fill 212 269 565 213 271 565 minecraft:yellow_stained_glass
setblock 212 269 567 minecraft:gold_block
fill 212 269 572 212 270 575 minecraft:quartz_block
fill 212 269 580 212 270 583 minecraft:quartz_block
fill 212 269 586 213 269 586 minecraft:quartz_block
fill 212 269 587 213 271 587 minecraft:yellow_stained_glass
setblock 212 269 588 minecraft:gold_block
fill 213 269 569 213 269 572 minecraft:quartz_block
fill 213 269 583 213 269 585 minecraft:quartz_block
fill 214 269 566 215 270 566 minecraft:yellow_stained_glass
fill 214 269 586 215 270 586 minecraft:yellow_stained_glass
fill 215 269 567 215 273 567 minecraft:yellow_stained_glass
fill 215 269 585 215 273 585 minecraft:yellow_stained_glass
fill 216 269 567 216 271 567 minecraft:gold_block
fill 216 269 568 217 270 568 minecraft:yellow_stained_glass
fill 216 269 584 217 270 584 minecraft:yellow_stained_glass
fill 216 269 585 216 271 585 minecraft:gold_block
fill 217 269 569 217 272 569 minecraft:yellow_stained_glass
fill 217 269 583 217 272 583 minecraft:yellow_stained_glass
fill 218 269 570 218 271 571 minecraft:yellow_stained_glass
fill 218 269 581 218 271 582 minecraft:yellow_stained_glass
fill 219 269 572 219 271 572 minecraft:yellow_stained_glass
fill 219 269 573 219 272 573 minecraft:gold_block
fill 219 269 574 219 273 578 minecraft:yellow_stained_glass
fill 219 269 579 219 272 579 minecraft:gold_block
fill 219 269 580 219 271 580 minecraft:yellow_stained_glass
fill 211 270 572 211 270 583 minecraft:quartz_block
fill 212 270 568 212 270 570 minecraft:gold_block
setblock 212 270 571 minecraft:quartz_block
fill 212 270 576 213 271 579 minecraft:quartz_block
setblock 212 270 586 minecraft:gold_block
fill 213 270 572 213 270 575 minecraft:quartz_block
fill 213 270 580 213 270 583 minecraft:quartz_block
fill 196 271 572 196 274 572 minecraft:yellow_stained_glass
fill 196 271 580 196 274 580 minecraft:yellow_stained_glass
fill 197 271 569 197 272 570 minecraft:yellow_stained_glass
fill 197 271 582 197 272 583 minecraft:yellow_stained_glass
fill 199 271 567 199 273 567 minecraft:yellow_stained_glass
fill 199 271 585 199 273 585 minecraft:yellow_stained_glass
fill 201 271 566 201 274 566 minecraft:yellow_stained_glass
fill 201 271 586 201 274 586 minecraft:yellow_stained_glass
fill 203 271 565 203 274 565 minecraft:yellow_stained_glass
fill 203 271 587 203 274 587 minecraft:yellow_stained_glass
fill 211 271 565 211 274 565 minecraft:yellow_stained_glass
fill 211 271 576 211 271 579 minecraft:quartz_block
fill 211 271 587 211 274 587 minecraft:yellow_stained_glass
fill 212 271 570 212 271 572 minecraft:gold_block
fill 212 271 573 212 271 575 minecraft:quartz_block
fill 212 271 580 212 271 582 minecraft:quartz_block
fill 212 271 583 212 271 585 minecraft:gold_block
fill 213 271 566 214 272 566 minecraft:yellow_stained_glass
fill 213 271 586 214 272 586 minecraft:yellow_stained_glass
fill 216 271 568 216 273 568 minecraft:yellow_stained_glass
fill 216 271 584 216 273 584 minecraft:yellow_stained_glass
fill 217 271 570 217 274 570 minecraft:yellow_stained_glass
fill 217 271 582 217 274 582 minecraft:yellow_stained_glass
fill 218 271 572 218 274 572 minecraft:yellow_stained_glass
fill 218 271 580 218 274 580 minecraft:yellow_stained_glass
fill 188 272 563 188 285 563 minecraft:gold_block
fill 188 272 564 188 272 565 minecraft:ochre_froglight
fill 188 272 566 188 285 566 minecraft:gold_block
fill 188 272 575 188 285 575 minecraft:gold_block
fill 188 272 576 188 272 577 minecraft:ochre_froglight
fill 188 272 578 188 285 578 minecraft:gold_block
fill 188 272 587 188 285 587 minecraft:gold_block
fill 188 272 588 188 272 589 minecraft:ochre_froglight
fill 188 272 590 188 285 590 minecraft:gold_block
fill 188 272 599 188 285 599 minecraft:gold_block
fill 189 272 599 190 272 599 minecraft:ochre_froglight
fill 191 272 599 191 285 599 minecraft:gold_block
fill 195 272 557 195 285 557 minecraft:gold_block
fill 196 272 557 197 272 557 minecraft:ochre_froglight
fill 196 272 571 196 273 571 minecraft:yellow_stained_glass
fill 196 272 573 196 274 573 minecraft:gold_block
fill 196 272 579 196 274 579 minecraft:gold_block
fill 196 272 581 196 273 581 minecraft:yellow_stained_glass
fill 198 272 557 198 285 557 minecraft:gold_block
fill 198 272 569 198 274 569 minecraft:yellow_stained_glass
fill 198 272 583 198 274 583 minecraft:yellow_stained_glass
fill 200 272 567 200 274 567 minecraft:yellow_stained_glass
fill 200 272 585 200 274 585 minecraft:yellow_stained_glass
fill 200 272 599 200 285 599 minecraft:gold_block
fill 201 272 599 202 272 599 minecraft:ochre_froglight
fill 202 272 565 202 273 565 minecraft:yellow_stained_glass
fill 202 272 587 202 273 587 minecraft:yellow_stained_glass
fill 203 272 599 203 285 599 minecraft:gold_block
fill 204 272 565 204 274 565 minecraft:gold_block
fill 204 272 587 204 274 587 minecraft:gold_block
fill 207 272 557 207 285 557 minecraft:gold_block
fill 208 272 557 209 272 557 minecraft:ochre_froglight
fill 210 272 557 210 285 557 minecraft:gold_block
fill 210 272 565 210 274 565 minecraft:gold_block
fill 210 272 587 210 274 587 minecraft:gold_block
fill 212 272 565 212 273 565 minecraft:yellow_stained_glass
fill 212 272 573 212 272 582 minecraft:gold_block
fill 212 272 587 212 273 587 minecraft:yellow_stained_glass
fill 212 272 599 212 285 599 minecraft:gold_block
fill 213 272 599 214 272 599 minecraft:ochre_froglight
fill 214 272 567 214 274 567 minecraft:yellow_stained_glass
fill 214 272 585 214 274 585 minecraft:yellow_stained_glass
fill 215 272 599 215 285 599 minecraft:gold_block
fill 216 272 569 216 274 569 minecraft:yellow_stained_glass
fill 216 272 583 216 274 583 minecraft:yellow_stained_glass
fill 218 272 571 218 273 571 minecraft:yellow_stained_glass
fill 218 272 573 218 274 573 minecraft:gold_block
fill 218 272 579 218 274 579 minecraft:gold_block
fill 218 272 581 218 273 581 minecraft:yellow_stained_glass
fill 219 272 557 219 285 557 minecraft:gold_block
fill 220 272 557 221 272 557 minecraft:ochre_froglight
fill 222 272 557 222 285 557 minecraft:gold_block
fill 224 272 599 224 285 599 minecraft:gold_block
fill 225 272 599 226 272 599 minecraft:ochre_froglight
fill 227 272 599 227 285 599 minecraft:gold_block
fill 230 272 558 230 285 558 minecraft:gold_block
fill 230 272 559 230 272 560 minecraft:ochre_froglight
fill 230 272 561 230 285 561 minecraft:gold_block
fill 230 272 570 230 285 570 minecraft:gold_block
fill 230 272 571 230 272 572 minecraft:ochre_froglight
fill 230 272 573 230 285 573 minecraft:gold_block
fill 230 272 582 230 285 582 minecraft:gold_block
fill 230 272 583 230 272 584 minecraft:ochre_froglight
fill 230 272 585 230 285 585 minecraft:gold_block
fill 230 272 594 230 285 594 minecraft:gold_block
fill 230 272 595 230 272 596 minecraft:ochre_froglight
fill 230 272 597 230 285 597 minecraft:gold_block
fill 188 273 564 188 285 565 minecraft:gold_block
fill 188 273 576 188 285 577 minecraft:gold_block
fill 188 273 588 188 285 589 minecraft:gold_block
fill 189 273 599 190 285 599 minecraft:gold_block
fill 196 273 557 197 285 557 minecraft:gold_block
fill 196 273 574 196 275 575 minecraft:yellow_stained_glass
fill 196 273 577 196 275 578 minecraft:yellow_stained_glass
fill 197 273 570 197 274 571 minecraft:yellow_stained_glass
fill 197 273 581 197 274 582 minecraft:yellow_stained_glass
fill 199 273 568 199 274 568 minecraft:gold_block
fill 199 273 584 199 274 584 minecraft:gold_block
fill 201 273 599 202 285 599 minecraft:gold_block
fill 202 273 566 202 275 566 minecraft:yellow_stained_glass
fill 202 273 586 202 275 586 minecraft:yellow_stained_glass
fill 205 273 565 206 275 565 minecraft:yellow_stained_glass
fill 205 273 587 206 275 587 minecraft:yellow_stained_glass
fill 208 273 557 209 285 557 minecraft:gold_block
fill 208 273 565 209 275 565 minecraft:yellow_stained_glass
fill 208 273 587 209 275 587 minecraft:yellow_stained_glass
fill 212 273 566 213 274 566 minecraft:yellow_stained_glass
fill 212 273 586 213 274 586 minecraft:yellow_stained_glass
fill 213 273 599 214 285 599 minecraft:gold_block
fill 215 273 568 215 274 568 minecraft:gold_block
fill 215 273 584 215 274 584 minecraft:gold_block
fill 217 273 571 217 275 571 minecraft:yellow_stained_glass
fill 217 273 581 217 275 581 minecraft:yellow_stained_glass
fill 218 273 574 218 275 575 minecraft:yellow_stained_glass
fill 218 273 577 218 275 578 minecraft:yellow_stained_glass
fill 220 273 557 221 285 557 minecraft:gold_block
fill 225 273 599 226 285 599 minecraft:gold_block
fill 230 273 559 230 285 560 minecraft:gold_block
fill 230 273 571 230 285 572 minecraft:gold_block
fill 230 273 583 230 285 584 minecraft:gold_block
fill 230 273 595 230 285 596 minecraft:gold_block
setblock 191 274 560 minecraft:light[level=14]
setblock 191 274 568 minecraft:light[level=14]
setblock 191 274 576 minecraft:light[level=14]
setblock 191 274 584 minecraft:light[level=14]
setblock 191 274 592 minecraft:light[level=14]
fill 196 274 576 196 275 576 minecraft:yellow_stained_glass
fill 197 274 572 197 275 572 minecraft:yellow_stained_glass
fill 197 274 580 197 275 580 minecraft:yellow_stained_glass
fill 198 274 570 198 275 570 minecraft:yellow_stained_glass
fill 198 274 582 198 275 582 minecraft:yellow_stained_glass
setblock 199 274 560 minecraft:light[level=14]
fill 199 274 569 199 275 569 minecraft:yellow_stained_glass
setblock 199 274 576 minecraft:light[level=14]
fill 199 274 583 199 275 583 minecraft:yellow_stained_glass
setblock 199 274 592 minecraft:light[level=14]
fill 200 274 568 200 275 568 minecraft:yellow_stained_glass
fill 200 274 584 200 275 584 minecraft:yellow_stained_glass
fill 201 274 567 201 275 567 minecraft:yellow_stained_glass
fill 201 274 585 201 275 585 minecraft:yellow_stained_glass
fill 203 274 566 203 275 566 minecraft:yellow_stained_glass
fill 203 274 586 203 275 586 minecraft:yellow_stained_glass
setblock 207 274 560 minecraft:light[level=14]
fill 207 274 565 207 275 565 minecraft:yellow_stained_glass
setblock 207 274 568 minecraft:light[level=14]
setblock 207 274 584 minecraft:light[level=14]
fill 207 274 587 207 275 587 minecraft:yellow_stained_glass
setblock 207 274 592 minecraft:light[level=14]
fill 211 274 566 211 275 566 minecraft:yellow_stained_glass
fill 211 274 586 211 275 586 minecraft:yellow_stained_glass
fill 213 274 567 213 275 567 minecraft:yellow_stained_glass
fill 213 274 585 213 275 585 minecraft:yellow_stained_glass
fill 214 274 568 214 275 568 minecraft:yellow_stained_glass
fill 214 274 584 214 275 584 minecraft:yellow_stained_glass
setblock 215 274 560 minecraft:light[level=14]
fill 215 274 569 215 275 569 minecraft:yellow_stained_glass
setblock 215 274 576 minecraft:light[level=14]
fill 215 274 583 215 275 583 minecraft:yellow_stained_glass
setblock 215 274 592 minecraft:light[level=14]
fill 216 274 570 216 275 570 minecraft:yellow_stained_glass
fill 216 274 582 216 275 582 minecraft:yellow_stained_glass
fill 217 274 572 217 275 572 minecraft:yellow_stained_glass
fill 217 274 580 217 275 580 minecraft:yellow_stained_glass
fill 218 274 576 218 275 576 minecraft:yellow_stained_glass
setblock 223 274 560 minecraft:light[level=14]
setblock 223 274 568 minecraft:light[level=14]
setblock 223 274 576 minecraft:light[level=14]
setblock 223 274 584 minecraft:light[level=14]
setblock 223 274 592 minecraft:light[level=14]
fill 197 275 571 198 275 571 minecraft:yellow_stained_glass
fill 197 275 573 197 276 573 minecraft:gold_block
fill 197 275 574 197 276 578 minecraft:yellow_stained_glass
fill 197 275 579 197 276 579 minecraft:gold_block
fill 197 275 581 198 275 581 minecraft:yellow_stained_glass
fill 199 275 570 199 276 570 minecraft:yellow_stained_glass
fill 199 275 582 199 276 582 minecraft:yellow_stained_glass
fill 201 275 568 201 276 568 minecraft:yellow_stained_glass
fill 201 275 584 201 276 584 minecraft:yellow_stained_glass
fill 202 275 567 202 276 567 minecraft:yellow_stained_glass
fill 202 275 585 202 276 585 minecraft:yellow_stained_glass
fill 204 275 566 204 276 566 minecraft:gold_block
fill 204 275 586 204 276 586 minecraft:gold_block
fill 205 275 566 209 276 566 minecraft:yellow_stained_glass
fill 205 275 586 209 276 586 minecraft:yellow_stained_glass
fill 210 275 566 210 276 566 minecraft:gold_block
fill 210 275 586 210 276 586 minecraft:gold_block
fill 212 275 566 212 275 567 minecraft:yellow_stained_glass
fill 212 275 585 212 275 586 minecraft:yellow_stained_glass
fill 213 275 568 213 276 568 minecraft:yellow_stained_glass
fill 213 275 584 213 276 584 minecraft:yellow_stained_glass
fill 215 275 570 215 276 570 minecraft:yellow_stained_glass
fill 215 275 582 215 276 582 minecraft:yellow_stained_glass
fill 216 275 571 216 276 571 minecraft:yellow_stained_glass
fill 216 275 581 216 276 581 minecraft:yellow_stained_glass
fill 217 275 573 217 276 573 minecraft:gold_block
fill 217 275 574 217 276 578 minecraft:yellow_stained_glass
fill 217 275 579 217 276 579 minecraft:gold_block
fill 198 276 571 198 276 573 minecraft:yellow_stained_glass
fill 198 276 579 198 276 581 minecraft:yellow_stained_glass
fill 199 276 571 199 277 571 minecraft:yellow_stained_glass
fill 199 276 581 199 277 581 minecraft:yellow_stained_glass
setblock 200 276 569 minecraft:gold_block
setblock 200 276 583 minecraft:gold_block
fill 202 276 568 202 277 568 minecraft:yellow_stained_glass
fill 202 276 584 202 277 584 minecraft:yellow_stained_glass
fill 203 276 567 204 276 567 minecraft:yellow_stained_glass
fill 203 276 585 204 276 585 minecraft:yellow_stained_glass
fill 210 276 567 212 276 567 minecraft:yellow_stained_glass
fill 210 276 585 212 276 585 minecraft:yellow_stained_glass
fill 212 276 568 212 277 568 minecraft:yellow_stained_glass
fill 212 276 584 212 277 584 minecraft:yellow_stained_glass
setblock 214 276 569 minecraft:gold_block
setblock 214 276 583 minecraft:gold_block
fill 215 276 571 215 277 571 minecraft:yellow_stained_glass
fill 215 276 581 215 277 581 minecraft:yellow_stained_glass
fill 216 276 572 216 276 573 minecraft:yellow_stained_glass
fill 216 276 579 216 276 580 minecraft:yellow_stained_glass
fill 198 277 573 198 277 579 minecraft:yellow_stained_glass
fill 199 277 572 199 277 573 minecraft:yellow_stained_glass
fill 199 277 579 199 277 580 minecraft:yellow_stained_glass
fill 200 277 570 200 277 571 minecraft:yellow_stained_glass
fill 200 277 581 200 277 582 minecraft:yellow_stained_glass
fill 201 277 569 202 277 569 minecraft:yellow_stained_glass
fill 201 277 570 201 278 570 minecraft:gold_block
fill 201 277 582 201 278 582 minecraft:gold_block
fill 201 277 583 202 277 583 minecraft:yellow_stained_glass
fill 203 277 568 204 277 568 minecraft:yellow_stained_glass
fill 203 277 584 204 277 584 minecraft:yellow_stained_glass
fill 204 277 567 210 277 567 minecraft:yellow_stained_glass
fill 204 277 585 210 277 585 minecraft:yellow_stained_glass
fill 210 277 568 211 277 568 minecraft:yellow_stained_glass
fill 210 277 584 211 277 584 minecraft:yellow_stained_glass
fill 212 277 569 213 277 569 minecraft:yellow_stained_glass
fill 212 277 583 213 277 583 minecraft:yellow_stained_glass
fill 213 277 570 213 278 570 minecraft:gold_block
fill 213 277 582 213 278 582 minecraft:gold_block
fill 214 277 570 214 277 571 minecraft:yellow_stained_glass
fill 214 277 581 214 277 582 minecraft:yellow_stained_glass
fill 215 277 572 215 277 573 minecraft:yellow_stained_glass
fill 215 277 579 215 277 580 minecraft:yellow_stained_glass
fill 216 277 573 216 277 579 minecraft:yellow_stained_glass
fill 199 278 573 200 278 573 minecraft:yellow_stained_glass
fill 199 278 574 200 278 574 minecraft:gold_block
fill 199 278 575 199 278 577 minecraft:yellow_stained_glass
fill 199 278 578 200 278 578 minecraft:gold_block
fill 199 278 579 200 278 579 minecraft:yellow_stained_glass
fill 200 278 571 201 278 572 minecraft:yellow_stained_glass
fill 200 278 580 201 278 581 minecraft:yellow_stained_glass
fill 202 278 569 203 278 570 minecraft:yellow_stained_glass
fill 202 278 582 203 278 583 minecraft:yellow_stained_glass
fill 204 278 568 204 278 569 minecraft:yellow_stained_glass
fill 204 278 583 204 278 584 minecraft:yellow_stained_glass
fill 205 278 568 205 278 569 minecraft:gold_block
fill 205 278 583 205 278 584 minecraft:gold_block
fill 206 278 568 208 278 568 minecraft:yellow_stained_glass
fill 206 278 584 208 278 584 minecraft:yellow_stained_glass
fill 209 278 568 209 278 569 minecraft:gold_block
fill 209 278 583 209 278 584 minecraft:gold_block
fill 210 278 568 210 278 569 minecraft:yellow_stained_glass
fill 210 278 583 210 278 584 minecraft:yellow_stained_glass
fill 211 278 569 212 278 570 minecraft:yellow_stained_glass
fill 211 278 582 212 278 583 minecraft:yellow_stained_glass
fill 213 278 571 214 278 572 minecraft:yellow_stained_glass
fill 213 278 580 214 278 581 minecraft:yellow_stained_glass
fill 214 278 573 215 278 573 minecraft:yellow_stained_glass
fill 214 278 574 215 278 574 minecraft:gold_block
fill 214 278 578 215 278 578 minecraft:gold_block
fill 214 278 579 215 278 579 minecraft:yellow_stained_glass
fill 215 278 575 215 278 577 minecraft:yellow_stained_glass
fill 200 279 573 202 280 573 minecraft:yellow_stained_glass
setblock 200 279 574 minecraft:gold_block
fill 200 279 575 201 280 577 minecraft:yellow_stained_glass
setblock 200 279 578 minecraft:gold_block
fill 200 279 579 202 280 579 minecraft:yellow_stained_glass
fill 201 279 572 202 280 572 minecraft:yellow_stained_glass
fill 201 279 574 201 280 574 minecraft:yellow_stained_glass
fill 201 279 578 201 280 578 minecraft:yellow_stained_glass
fill 201 279 580 202 280 580 minecraft:yellow_stained_glass
setblock 202 279 571 minecraft:gold_block
setblock 202 279 581 minecraft:gold_block
fill 203 279 570 204 280 571 minecraft:yellow_stained_glass
setblock 203 279 572 minecraft:gold_block
setblock 203 279 580 minecraft:gold_block
fill 203 279 581 204 280 582 minecraft:yellow_stained_glass
fill 204 279 569 204 280 569 minecraft:yellow_stained_glass
fill 204 279 583 204 280 583 minecraft:yellow_stained_glass
setblock 205 279 569 minecraft:gold_block
fill 205 279 570 211 280 570 minecraft:yellow_stained_glass
fill 205 279 582 211 280 582 minecraft:yellow_stained_glass
setblock 205 279 583 minecraft:gold_block
fill 206 279 569 208 280 569 minecraft:yellow_stained_glass
fill 206 279 583 208 280 583 minecraft:yellow_stained_glass
setblock 209 279 569 minecraft:gold_block
setblock 209 279 583 minecraft:gold_block
fill 210 279 569 210 280 569 minecraft:yellow_stained_glass
fill 210 279 571 211 280 571 minecraft:yellow_stained_glass
fill 210 279 581 211 280 581 minecraft:yellow_stained_glass
fill 210 279 583 210 280 583 minecraft:yellow_stained_glass
setblock 211 279 572 minecraft:gold_block
setblock 211 279 580 minecraft:gold_block
setblock 212 279 571 minecraft:gold_block
fill 212 279 572 213 280 573 minecraft:yellow_stained_glass
fill 212 279 579 213 280 580 minecraft:yellow_stained_glass
setblock 212 279 581 minecraft:gold_block
fill 213 279 574 213 280 578 minecraft:yellow_stained_glass
fill 214 279 573 214 280 573 minecraft:yellow_stained_glass
setblock 214 279 574 minecraft:gold_block
fill 214 279 575 214 280 577 minecraft:yellow_stained_glass
setblock 214 279 578 minecraft:gold_block
fill 214 279 579 214 280 579 minecraft:yellow_stained_glass
fill 189 280 558 196 280 598 minecraft:quartz_block
fill 197 280 558 197 280 571 minecraft:quartz_block
fill 197 280 572 199 280 580 minecraft:yellow_stained_glass
fill 197 280 581 197 280 598 minecraft:quartz_block
fill 198 280 558 198 280 570 minecraft:quartz_block
fill 198 280 571 202 280 571 minecraft:yellow_stained_glass
fill 198 280 581 202 280 581 minecraft:yellow_stained_glass
fill 198 280 582 198 280 598 minecraft:quartz_block
fill 199 280 558 199 280 568 minecraft:quartz_block
fill 199 280 569 202 280 570 minecraft:yellow_stained_glass
fill 199 280 582 202 280 583 minecraft:yellow_stained_glass
fill 199 280 584 199 280 598 minecraft:quartz_block
fill 200 280 558 201 280 567 minecraft:quartz_block
fill 200 280 568 214 280 568 minecraft:yellow_stained_glass
setblock 200 280 572 minecraft:yellow_stained_glass
setblock 200 280 574 minecraft:yellow_stained_glass
setblock 200 280 578 minecraft:yellow_stained_glass
setblock 200 280 580 minecraft:yellow_stained_glass
fill 200 280 584 214 280 584 minecraft:yellow_stained_glass
fill 200 280 585 201 280 598 minecraft:quartz_block
fill 202 280 558 202 280 566 minecraft:quartz_block
fill 202 280 567 212 280 567 minecraft:yellow_stained_glass
fill 202 280 574 203 280 578 minecraft:yellow_stained_glass
fill 202 280 585 212 280 585 minecraft:yellow_stained_glass
fill 202 280 586 202 280 598 minecraft:quartz_block
fill 203 280 558 229 280 565 minecraft:quartz_block
fill 203 280 566 211 280 566 minecraft:yellow_stained_glass
setblock 203 280 569 minecraft:yellow_stained_glass
fill 203 280 572 205 280 573 minecraft:yellow_stained_glass
fill 203 280 579 205 280 580 minecraft:yellow_stained_glass
setblock 203 280 583 minecraft:yellow_stained_glass
fill 203 280 586 211 280 586 minecraft:yellow_stained_glass
fill 203 280 587 229 280 598 minecraft:quartz_block
setblock 204 280 574 minecraft:yellow_stained_glass
fill 204 280 575 204 280 577 minecraft:ochre_froglight
setblock 204 280 578 minecraft:yellow_stained_glass
setblock 205 280 569 minecraft:yellow_stained_glass
fill 205 280 571 209 280 571 minecraft:yellow_stained_glass
fill 205 280 574 205 280 575 minecraft:ochre_froglight
fill 205 280 577 205 280 578 minecraft:ochre_froglight
fill 205 280 581 209 280 581 minecraft:yellow_stained_glass
setblock 205 280 583 minecraft:yellow_stained_glass
fill 206 280 572 211 280 572 minecraft:yellow_stained_glass
fill 206 280 573 206 280 574 minecraft:ochre_froglight
fill 206 280 578 206 280 579 minecraft:ochre_froglight
fill 206 280 580 211 280 580 minecraft:yellow_stained_glass
fill 207 280 573 208 280 573 minecraft:ochre_froglight
fill 207 280 579 208 280 579 minecraft:ochre_froglight
fill 208 280 574 209 280 574 minecraft:ochre_froglight
fill 208 280 578 209 280 578 minecraft:ochre_froglight
setblock 209 280 569 minecraft:yellow_stained_glass
fill 209 280 573 211 280 573 minecraft:yellow_stained_glass
fill 209 280 575 210 280 575 minecraft:ochre_froglight
fill 209 280 577 210 280 577 minecraft:ochre_froglight
fill 209 280 579 211 280 579 minecraft:yellow_stained_glass
setblock 209 280 583 minecraft:yellow_stained_glass
fill 210 280 574 212 280 574 minecraft:yellow_stained_glass
setblock 210 280 576 minecraft:ochre_froglight
fill 210 280 578 212 280 578 minecraft:yellow_stained_glass
fill 211 280 569 215 280 569 minecraft:yellow_stained_glass
fill 211 280 575 212 280 577 minecraft:yellow_stained_glass
fill 211 280 583 215 280 583 minecraft:yellow_stained_glass
fill 212 280 566 229 280 566 minecraft:quartz_block
fill 212 280 570 215 280 571 minecraft:yellow_stained_glass
fill 212 280 581 215 280 582 minecraft:yellow_stained_glass
fill 212 280 586 229 280 586 minecraft:quartz_block
fill 213 280 567 229 280 567 minecraft:quartz_block
fill 213 280 585 229 280 585 minecraft:quartz_block
fill 214 280 572 217 280 572 minecraft:yellow_stained_glass
fill 214 280 574 217 280 574 minecraft:yellow_stained_glass
fill 214 280 578 217 280 578 minecraft:yellow_stained_glass
fill 214 280 580 217 280 580 minecraft:yellow_stained_glass
fill 215 280 568 229 280 568 minecraft:quartz_block
fill 215 280 573 217 280 573 minecraft:yellow_stained_glass
fill 215 280 575 217 280 577 minecraft:yellow_stained_glass
fill 215 280 579 217 280 579 minecraft:yellow_stained_glass
fill 215 280 584 229 280 584 minecraft:quartz_block
fill 216 280 569 229 280 570 minecraft:quartz_block
setblock 216 280 571 minecraft:yellow_stained_glass
setblock 216 280 581 minecraft:yellow_stained_glass
fill 216 280 582 229 280 583 minecraft:quartz_block
fill 217 280 571 229 280 571 minecraft:quartz_block
fill 217 280 581 229 280 581 minecraft:quartz_block
fill 218 280 572 229 280 580 minecraft:quartz_block
fill 204 281 575 204 281 577 minecraft:yellow_stained_glass
setblock 205 281 574 minecraft:gold_block
setblock 205 281 575 minecraft:yellow_stained_glass
setblock 205 281 577 minecraft:yellow_stained_glass
setblock 205 281 578 minecraft:gold_block
fill 206 281 573 206 281 574 minecraft:yellow_stained_glass
fill 206 281 578 206 281 579 minecraft:yellow_stained_glass
fill 207 281 573 208 281 573 minecraft:yellow_stained_glass
fill 207 281 579 208 281 579 minecraft:yellow_stained_glass
setblock 208 281 574 minecraft:yellow_stained_glass
setblock 208 281 578 minecraft:yellow_stained_glass
setblock 209 281 574 minecraft:gold_block
fill 209 281 575 210 281 575 minecraft:yellow_stained_glass
fill 209 281 577 210 281 577 minecraft:yellow_stained_glass
setblock 209 281 578 minecraft:gold_block
setblock 210 281 576 minecraft:yellow_stained_glass
setblock 191 282 560 minecraft:light[level=14]
setblock 191 282 568 minecraft:light[level=14]
setblock 191 282 576 minecraft:light[level=14]
setblock 191 282 584 minecraft:light[level=14]
setblock 191 282 592 minecraft:light[level=14]
setblock 199 282 560 minecraft:light[level=14]
setblock 199 282 568 minecraft:light[level=14]
setblock 199 282 576 minecraft:light[level=14]
setblock 199 282 584 minecraft:light[level=14]
setblock 199 282 592 minecraft:light[level=14]
setblock 207 282 560 minecraft:light[level=14]
setblock 207 282 568 minecraft:light[level=14]
setblock 207 282 584 minecraft:light[level=14]
setblock 207 282 592 minecraft:light[level=14]
setblock 215 282 560 minecraft:light[level=14]
setblock 215 282 568 minecraft:light[level=14]
setblock 215 282 576 minecraft:light[level=14]
setblock 215 282 584 minecraft:light[level=14]
setblock 215 282 592 minecraft:light[level=14]
setblock 223 282 560 minecraft:light[level=14]
setblock 223 282 568 minecraft:light[level=14]
setblock 223 282 576 minecraft:light[level=14]
setblock 223 282 584 minecraft:light[level=14]
setblock 223 282 592 minecraft:light[level=14]
fill 189 284 558 191 300 558 minecraft:quartz_block
fill 189 284 568 189 300 570 minecraft:quartz_block
fill 189 284 580 189 300 582 minecraft:quartz_block
fill 189 284 592 189 300 594 minecraft:quartz_block
fill 190 284 567 190 285 569 minecraft:quartz_block
fill 190 284 579 190 285 581 minecraft:quartz_block
fill 190 284 591 190 285 593 minecraft:quartz_block
fill 195 284 598 197 300 598 minecraft:quartz_block
fill 196 284 597 198 285 597 minecraft:quartz_block
fill 200 284 559 202 285 559 minecraft:quartz_block
fill 201 284 558 203 300 558 minecraft:quartz_block
fill 204 284 596 208 288 596 minecraft:red_wool
fill 207 284 598 229 284 598 minecraft:quartz_block
fill 208 284 597 229 284 597 minecraft:quartz_block
fill 209 284 592 229 284 596 minecraft:quartz_block
fill 212 284 559 214 285 559 minecraft:quartz_block
fill 213 284 558 215 300 558 minecraft:quartz_block
fill 222 284 588 229 285 591 minecraft:quartz_block
fill 224 284 559 226 285 559 minecraft:quartz_block
fill 225 284 558 227 300 558 minecraft:quartz_block
fill 228 284 567 228 285 569 minecraft:quartz_block
fill 228 284 579 228 285 581 minecraft:quartz_block
fill 229 284 566 229 300 568 minecraft:quartz_block
fill 229 284 578 229 300 580 minecraft:quartz_block
fill 189 285 561 189 285 566 minecraft:yellow_terracotta
fill 189 285 573 189 285 578 minecraft:yellow_terracotta
fill 189 285 585 189 285 590 minecraft:yellow_terracotta
fill 189 285 597 189 285 598 minecraft:yellow_terracotta
fill 190 285 598 193 285 598 minecraft:yellow_terracotta
fill 193 285 558 198 285 558 minecraft:yellow_terracotta
fill 200 285 598 205 285 598 minecraft:yellow_terracotta
fill 205 285 558 210 285 558 minecraft:yellow_terracotta
fill 207 285 598 211 285 598 minecraft:quartz_block
fill 208 285 597 228 285 597 minecraft:quartz_block
fill 209 285 592 228 285 596 minecraft:quartz_block
fill 212 285 598 217 285 598 minecraft:yellow_terracotta
fill 217 285 558 222 285 558 minecraft:yellow_terracotta
fill 218 285 598 223 285 598 minecraft:quartz_block
fill 224 285 598 229 285 598 minecraft:yellow_terracotta
fill 229 285 558 229 285 563 minecraft:yellow_terracotta
fill 229 285 570 229 285 575 minecraft:yellow_terracotta
fill 229 285 582 229 285 587 minecraft:yellow_terracotta
fill 229 285 592 229 285 593 minecraft:quartz_block
fill 229 285 594 229 285 597 minecraft:yellow_terracotta
fill 188 286 563 188 291 566 minecraft:ochre_froglight
fill 188 286 575 188 291 578 minecraft:ochre_froglight
fill 188 286 587 188 291 590 minecraft:ochre_froglight
fill 188 286 599 191 291 599 minecraft:ochre_froglight
fill 195 286 557 198 291 557 minecraft:ochre_froglight
fill 200 286 599 203 291 599 minecraft:ochre_froglight
fill 207 286 557 210 291 557 minecraft:ochre_froglight
fill 207 286 598 208 300 598 minecraft:quartz_block
setblock 209 286 592 minecraft:ochre_froglight
fill 209 286 593 209 300 593 minecraft:quartz_block
setblock 209 286 594 minecraft:ochre_froglight
fill 209 286 595 209 300 595 minecraft:quartz_block
setblock 209 286 596 minecraft:ochre_froglight
fill 209 286 597 209 300 597 minecraft:quartz_block
setblock 209 286 598 minecraft:ochre_froglight
fill 210 286 592 210 300 592 minecraft:quartz_block
setblock 210 286 593 minecraft:ochre_froglight
fill 210 286 594 210 300 594 minecraft:quartz_block
setblock 210 286 595 minecraft:ochre_froglight
fill 210 286 596 210 300 596 minecraft:quartz_block
setblock 210 286 597 minecraft:ochre_froglight
fill 210 286 598 210 300 598 minecraft:quartz_block
setblock 211 286 592 minecraft:ochre_froglight
fill 211 286 593 211 300 593 minecraft:quartz_block
setblock 211 286 594 minecraft:ochre_froglight
fill 211 286 595 211 300 595 minecraft:quartz_block
setblock 211 286 596 minecraft:ochre_froglight
fill 211 286 597 211 300 597 minecraft:quartz_block
setblock 211 286 598 minecraft:ochre_froglight
fill 212 286 592 212 300 592 minecraft:quartz_block
setblock 212 286 593 minecraft:ochre_froglight
fill 212 286 594 212 300 594 minecraft:quartz_block
setblock 212 286 595 minecraft:ochre_froglight
fill 212 286 596 212 300 596 minecraft:quartz_block
setblock 212 286 597 minecraft:ochre_froglight
fill 212 286 598 212 300 598 minecraft:quartz_block
fill 212 286 599 215 291 599 minecraft:ochre_froglight
setblock 213 286 592 minecraft:ochre_froglight
fill 213 286 593 213 300 593 minecraft:quartz_block
setblock 213 286 594 minecraft:ochre_froglight
fill 213 286 595 213 300 595 minecraft:quartz_block
setblock 213 286 596 minecraft:ochre_froglight
fill 213 286 597 213 300 597 minecraft:quartz_block
setblock 213 286 598 minecraft:ochre_froglight
fill 214 286 592 214 300 592 minecraft:quartz_block
setblock 214 286 593 minecraft:ochre_froglight
fill 214 286 594 214 300 594 minecraft:quartz_block
setblock 214 286 595 minecraft:ochre_froglight
fill 214 286 596 214 300 596 minecraft:quartz_block
setblock 214 286 597 minecraft:ochre_froglight
fill 214 286 598 214 300 598 minecraft:quartz_block
setblock 215 286 592 minecraft:ochre_froglight
fill 215 286 593 215 300 593 minecraft:quartz_block
setblock 215 286 594 minecraft:ochre_froglight
fill 215 286 595 215 300 595 minecraft:quartz_block
setblock 215 286 596 minecraft:ochre_froglight
fill 215 286 597 215 300 597 minecraft:quartz_block
setblock 215 286 598 minecraft:ochre_froglight
fill 216 286 592 216 300 592 minecraft:quartz_block
setblock 216 286 593 minecraft:ochre_froglight
fill 216 286 594 216 300 594 minecraft:quartz_block
setblock 216 286 595 minecraft:ochre_froglight
fill 216 286 596 216 300 596 minecraft:quartz_block
setblock 216 286 597 minecraft:ochre_froglight
fill 216 286 598 216 300 598 minecraft:quartz_block
setblock 217 286 592 minecraft:ochre_froglight
fill 217 286 593 217 300 593 minecraft:quartz_block
setblock 217 286 594 minecraft:ochre_froglight
fill 217 286 595 217 300 595 minecraft:quartz_block
setblock 217 286 596 minecraft:ochre_froglight
fill 217 286 597 217 300 597 minecraft:quartz_block
setblock 217 286 598 minecraft:ochre_froglight
fill 218 286 592 218 300 592 minecraft:quartz_block
setblock 218 286 593 minecraft:ochre_froglight
fill 218 286 594 218 300 594 minecraft:quartz_block
setblock 218 286 595 minecraft:ochre_froglight
fill 218 286 596 218 300 596 minecraft:quartz_block
setblock 218 286 597 minecraft:ochre_froglight
fill 218 286 598 218 300 598 minecraft:quartz_block
fill 219 286 557 222 291 557 minecraft:ochre_froglight
setblock 219 286 592 minecraft:ochre_froglight
fill 219 286 593 219 300 593 minecraft:quartz_block
setblock 219 286 594 minecraft:ochre_froglight
fill 219 286 595 219 300 595 minecraft:quartz_block
setblock 219 286 596 minecraft:ochre_froglight
fill 219 286 597 219 300 597 minecraft:quartz_block
setblock 219 286 598 minecraft:ochre_froglight
fill 220 286 592 220 300 592 minecraft:quartz_block
setblock 220 286 593 minecraft:ochre_froglight
fill 220 286 594 220 300 594 minecraft:quartz_block
setblock 220 286 595 minecraft:ochre_froglight
fill 220 286 596 220 300 596 minecraft:quartz_block
setblock 220 286 597 minecraft:ochre_froglight
fill 220 286 598 220 300 598 minecraft:quartz_block
setblock 221 286 592 minecraft:ochre_froglight
fill 221 286 593 221 300 593 minecraft:quartz_block
setblock 221 286 594 minecraft:ochre_froglight
fill 221 286 595 221 300 595 minecraft:quartz_block
setblock 221 286 596 minecraft:ochre_froglight
fill 221 286 597 221 300 597 minecraft:quartz_block
setblock 221 286 598 minecraft:ochre_froglight
fill 222 286 588 222 299 588 minecraft:quartz_block
setblock 222 286 589 minecraft:ochre_froglight
fill 222 286 590 222 299 590 minecraft:quartz_block
setblock 222 286 591 minecraft:ochre_froglight
fill 222 286 592 222 299 592 minecraft:quartz_block
setblock 222 286 593 minecraft:ochre_froglight
fill 222 286 594 222 299 594 minecraft:quartz_block
setblock 222 286 595 minecraft:ochre_froglight
fill 222 286 596 222 299 596 minecraft:quartz_block
setblock 222 286 597 minecraft:ochre_froglight
fill 222 286 598 222 299 598 minecraft:quartz_block
setblock 223 286 588 minecraft:ochre_froglight
fill 223 286 589 223 299 589 minecraft:quartz_block
setblock 223 286 590 minecraft:ochre_froglight
fill 223 286 591 223 299 591 minecraft:quartz_block
setblock 223 286 592 minecraft:ochre_froglight
fill 223 286 593 223 299 593 minecraft:quartz_block
setblock 223 286 594 minecraft:ochre_froglight
fill 223 286 595 223 299 595 minecraft:quartz_block
setblock 223 286 596 minecraft:ochre_froglight
fill 223 286 597 223 299 597 minecraft:quartz_block
setblock 223 286 598 minecraft:ochre_froglight
fill 224 286 588 224 299 588 minecraft:quartz_block
setblock 224 286 589 minecraft:ochre_froglight
fill 224 286 590 224 299 590 minecraft:quartz_block
setblock 224 286 591 minecraft:ochre_froglight
fill 224 286 592 224 299 592 minecraft:quartz_block
setblock 224 286 593 minecraft:ochre_froglight
fill 224 286 594 224 299 594 minecraft:quartz_block
setblock 224 286 595 minecraft:ochre_froglight
fill 224 286 596 224 299 596 minecraft:quartz_block
setblock 224 286 597 minecraft:ochre_froglight
fill 224 286 598 224 299 598 minecraft:quartz_block
fill 224 286 599 227 291 599 minecraft:ochre_froglight
setblock 225 286 588 minecraft:ochre_froglight
fill 225 286 589 225 299 589 minecraft:quartz_block
setblock 225 286 590 minecraft:ochre_froglight
fill 225 286 591 225 299 591 minecraft:quartz_block
setblock 225 286 592 minecraft:ochre_froglight
fill 225 286 593 225 299 593 minecraft:quartz_block
setblock 225 286 594 minecraft:ochre_froglight
fill 225 286 595 225 299 595 minecraft:quartz_block
setblock 225 286 596 minecraft:ochre_froglight
fill 225 286 597 225 299 597 minecraft:quartz_block
setblock 225 286 598 minecraft:ochre_froglight
fill 226 286 588 226 299 588 minecraft:quartz_block
setblock 226 286 589 minecraft:ochre_froglight
fill 226 286 590 226 299 590 minecraft:quartz_block
setblock 226 286 591 minecraft:ochre_froglight
fill 226 286 592 226 299 592 minecraft:quartz_block
setblock 226 286 593 minecraft:ochre_froglight
fill 226 286 594 226 299 594 minecraft:quartz_block
setblock 226 286 595 minecraft:ochre_froglight
fill 226 286 596 226 299 596 minecraft:quartz_block
setblock 226 286 597 minecraft:ochre_froglight
fill 226 286 598 226 299 598 minecraft:quartz_block
setblock 227 286 588 minecraft:ochre_froglight
fill 227 286 589 227 299 589 minecraft:quartz_block
setblock 227 286 590 minecraft:ochre_froglight
fill 227 286 591 227 299 591 minecraft:quartz_block
setblock 227 286 592 minecraft:ochre_froglight
fill 227 286 593 227 299 593 minecraft:quartz_block
setblock 227 286 594 minecraft:ochre_froglight
fill 227 286 595 227 299 595 minecraft:quartz_block
setblock 227 286 596 minecraft:ochre_froglight
fill 227 286 597 227 299 597 minecraft:quartz_block
setblock 227 286 598 minecraft:ochre_froglight
fill 228 286 588 228 299 588 minecraft:quartz_block
setblock 228 286 589 minecraft:ochre_froglight
fill 228 286 590 228 299 590 minecraft:quartz_block
setblock 228 286 591 minecraft:ochre_froglight
fill 228 286 592 228 300 592 minecraft:quartz_block
setblock 228 286 593 minecraft:ochre_froglight
fill 228 286 594 228 299 594 minecraft:quartz_block
setblock 228 286 595 minecraft:ochre_froglight
fill 228 286 596 228 299 596 minecraft:quartz_block
setblock 228 286 597 minecraft:ochre_froglight
fill 228 286 598 228 299 598 minecraft:quartz_block
setblock 229 286 588 minecraft:ochre_froglight
fill 229 286 589 229 299 589 minecraft:quartz_block
setblock 229 286 590 minecraft:ochre_froglight
fill 229 286 591 229 300 591 minecraft:quartz_block
setblock 229 286 592 minecraft:ochre_froglight
fill 229 286 593 229 299 593 minecraft:quartz_block
fill 229 286 594 230 286 594 minecraft:ochre_froglight
fill 229 286 595 229 299 595 minecraft:quartz_block
fill 229 286 596 230 286 596 minecraft:ochre_froglight
fill 229 286 597 229 299 597 minecraft:quartz_block
setblock 229 286 598 minecraft:ochre_froglight
fill 230 286 558 230 291 561 minecraft:ochre_froglight
fill 230 286 570 230 291 573 minecraft:ochre_froglight
fill 230 286 582 230 291 585 minecraft:ochre_froglight
setblock 230 286 589 minecraft:ochre_froglight
fill 230 286 590 230 307 590 minecraft:gold_block
setblock 230 286 591 minecraft:ochre_froglight
setblock 230 286 593 minecraft:ochre_froglight
fill 230 286 595 230 292 595 minecraft:ochre_froglight
fill 230 286 597 230 292 597 minecraft:ochre_froglight
fill 209 287 592 209 288 592 minecraft:quartz_block
fill 209 287 594 209 288 594 minecraft:quartz_block
fill 209 287 596 209 288 596 minecraft:quartz_block
fill 209 287 598 209 288 598 minecraft:quartz_block
fill 210 287 593 210 288 593 minecraft:quartz_block
fill 210 287 595 210 288 595 minecraft:quartz_block
fill 210 287 597 210 288 597 minecraft:quartz_block
fill 211 287 592 211 288 592 minecraft:quartz_block
fill 211 287 594 211 288 594 minecraft:quartz_block
fill 211 287 596 211 288 596 minecraft:quartz_block
fill 211 287 598 211 288 598 minecraft:quartz_block
fill 212 287 593 212 288 593 minecraft:quartz_block
fill 212 287 595 212 288 595 minecraft:quartz_block
fill 212 287 597 212 288 597 minecraft:quartz_block
fill 213 287 592 213 288 592 minecraft:quartz_block
fill 213 287 594 213 288 594 minecraft:quartz_block
fill 213 287 596 213 288 596 minecraft:quartz_block
fill 213 287 598 213 288 598 minecraft:quartz_block
fill 214 287 593 214 288 593 minecraft:quartz_block
fill 214 287 595 214 288 595 minecraft:quartz_block
fill 214 287 597 214 288 597 minecraft:quartz_block
fill 215 287 592 215 288 592 minecraft:quartz_block
fill 215 287 594 215 288 594 minecraft:quartz_block
fill 215 287 596 215 288 596 minecraft:quartz_block
fill 215 287 598 215 288 598 minecraft:quartz_block
fill 216 287 593 216 288 593 minecraft:quartz_block
fill 216 287 595 216 288 595 minecraft:quartz_block
fill 216 287 597 216 288 597 minecraft:quartz_block
fill 217 287 592 217 288 592 minecraft:quartz_block
fill 217 287 594 217 288 594 minecraft:quartz_block
fill 217 287 596 217 288 596 minecraft:quartz_block
fill 217 287 598 217 288 598 minecraft:quartz_block
fill 218 287 593 218 288 593 minecraft:quartz_block
fill 218 287 595 218 288 595 minecraft:quartz_block
fill 218 287 597 218 288 597 minecraft:quartz_block
fill 219 287 592 219 288 592 minecraft:quartz_block
fill 219 287 594 219 288 594 minecraft:quartz_block
fill 219 287 596 219 288 596 minecraft:quartz_block
fill 219 287 598 219 288 598 minecraft:quartz_block
fill 220 287 593 220 288 593 minecraft:quartz_block
fill 220 287 595 220 288 595 minecraft:quartz_block
fill 220 287 597 220 288 597 minecraft:quartz_block
fill 221 287 592 221 288 592 minecraft:quartz_block
fill 221 287 594 221 288 594 minecraft:quartz_block
fill 221 287 596 221 288 596 minecraft:quartz_block
fill 221 287 598 221 288 598 minecraft:quartz_block
fill 222 287 589 222 288 589 minecraft:quartz_block
fill 222 287 591 222 288 591 minecraft:quartz_block
fill 222 287 593 222 288 593 minecraft:quartz_block
fill 222 287 595 222 288 595 minecraft:quartz_block
fill 222 287 597 222 288 597 minecraft:quartz_block
fill 223 287 588 223 288 588 minecraft:quartz_block
fill 223 287 590 223 288 590 minecraft:quartz_block
fill 223 287 592 223 288 592 minecraft:quartz_block
fill 223 287 594 223 288 594 minecraft:quartz_block
fill 223 287 596 223 288 596 minecraft:quartz_block
fill 223 287 598 223 288 598 minecraft:quartz_block
fill 224 287 589 224 288 589 minecraft:quartz_block
fill 224 287 591 224 288 591 minecraft:quartz_block
fill 224 287 593 224 288 593 minecraft:quartz_block
fill 224 287 595 224 288 595 minecraft:quartz_block
fill 224 287 597 224 288 597 minecraft:quartz_block
fill 225 287 588 225 288 588 minecraft:quartz_block
fill 225 287 590 225 288 590 minecraft:quartz_block
fill 225 287 592 225 288 592 minecraft:quartz_block
fill 225 287 594 225 288 594 minecraft:quartz_block
fill 225 287 596 225 288 596 minecraft:quartz_block
fill 225 287 598 225 288 598 minecraft:quartz_block
fill 226 287 589 226 288 589 minecraft:quartz_block
fill 226 287 591 226 288 591 minecraft:quartz_block
fill 226 287 593 226 288 593 minecraft:quartz_block
fill 226 287 595 226 288 595 minecraft:quartz_block
fill 226 287 597 226 288 597 minecraft:quartz_block
fill 227 287 588 227 288 588 minecraft:quartz_block
fill 227 287 590 227 288 590 minecraft:quartz_block
fill 227 287 592 227 288 592 minecraft:quartz_block
fill 227 287 594 227 288 594 minecraft:quartz_block
fill 227 287 596 227 288 596 minecraft:quartz_block
fill 227 287 598 227 288 598 minecraft:quartz_block
fill 228 287 589 228 288 589 minecraft:quartz_block
fill 228 287 591 228 288 591 minecraft:quartz_block
fill 228 287 593 228 288 593 minecraft:quartz_block
fill 228 287 595 228 288 595 minecraft:quartz_block
fill 228 287 597 228 288 597 minecraft:quartz_block
fill 229 287 588 229 288 588 minecraft:quartz_block
fill 229 287 590 229 288 590 minecraft:quartz_block
fill 229 287 592 229 288 592 minecraft:quartz_block
fill 229 287 594 229 288 594 minecraft:quartz_block
fill 229 287 596 229 288 596 minecraft:quartz_block
fill 229 287 598 229 288 598 minecraft:quartz_block
fill 230 287 589 230 288 589 minecraft:gold_block
fill 230 287 591 230 288 591 minecraft:gold_block
fill 230 287 593 230 288 593 minecraft:gold_block
fill 230 287 594 230 291 594 minecraft:ochre_froglight
fill 230 287 596 230 292 596 minecraft:ochre_froglight
fill 196 289 578 198 290 578 minecraft:raw_gold_block
fill 197 289 577 197 290 577 minecraft:raw_gold_block
fill 197 289 579 197 290 579 minecraft:raw_gold_block
fill 203 289 596 208 290 596 minecraft:gold_block
setblock 209 289 592 minecraft:ochre_froglight
setblock 209 289 594 minecraft:ochre_froglight
setblock 209 289 596 minecraft:ochre_froglight
setblock 209 289 598 minecraft:ochre_froglight
setblock 210 289 593 minecraft:ochre_froglight
setblock 210 289 595 minecraft:ochre_froglight
setblock 210 289 597 minecraft:ochre_froglight
setblock 211 289 592 minecraft:ochre_froglight
setblock 211 289 594 minecraft:ochre_froglight
setblock 211 289 596 minecraft:ochre_froglight
setblock 211 289 598 minecraft:ochre_froglight
setblock 212 289 593 minecraft:ochre_froglight
setblock 212 289 595 minecraft:ochre_froglight
setblock 212 289 597 minecraft:ochre_froglight
setblock 213 289 592 minecraft:ochre_froglight
setblock 213 289 594 minecraft:ochre_froglight
setblock 213 289 596 minecraft:ochre_froglight
setblock 213 289 598 minecraft:ochre_froglight
setblock 214 289 593 minecraft:ochre_froglight
setblock 214 289 595 minecraft:ochre_froglight
setblock 214 289 597 minecraft:ochre_froglight
setblock 215 289 592 minecraft:ochre_froglight
setblock 215 289 594 minecraft:ochre_froglight
setblock 215 289 596 minecraft:ochre_froglight
setblock 215 289 598 minecraft:ochre_froglight
setblock 216 289 593 minecraft:ochre_froglight
setblock 216 289 595 minecraft:ochre_froglight
setblock 216 289 597 minecraft:ochre_froglight
setblock 217 289 592 minecraft:ochre_froglight
setblock 217 289 594 minecraft:ochre_froglight
setblock 217 289 596 minecraft:ochre_froglight
setblock 217 289 598 minecraft:ochre_froglight
setblock 218 289 593 minecraft:ochre_froglight
setblock 218 289 595 minecraft:ochre_froglight
setblock 218 289 597 minecraft:ochre_froglight
setblock 219 289 592 minecraft:ochre_froglight
setblock 219 289 594 minecraft:ochre_froglight
setblock 219 289 596 minecraft:ochre_froglight
setblock 219 289 598 minecraft:ochre_froglight
setblock 220 289 593 minecraft:ochre_froglight
setblock 220 289 595 minecraft:ochre_froglight
setblock 220 289 597 minecraft:ochre_froglight
setblock 221 289 592 minecraft:ochre_froglight
setblock 221 289 594 minecraft:ochre_froglight
setblock 221 289 596 minecraft:ochre_froglight
setblock 221 289 598 minecraft:ochre_froglight
setblock 222 289 589 minecraft:ochre_froglight
setblock 222 289 591 minecraft:ochre_froglight
setblock 222 289 593 minecraft:ochre_froglight
setblock 222 289 595 minecraft:ochre_froglight
setblock 222 289 597 minecraft:ochre_froglight
setblock 223 289 588 minecraft:ochre_froglight
setblock 223 289 590 minecraft:ochre_froglight
setblock 223 289 592 minecraft:ochre_froglight
setblock 223 289 594 minecraft:ochre_froglight
setblock 223 289 596 minecraft:ochre_froglight
setblock 223 289 598 minecraft:ochre_froglight
setblock 224 289 589 minecraft:ochre_froglight
setblock 224 289 591 minecraft:ochre_froglight
setblock 224 289 593 minecraft:ochre_froglight
setblock 224 289 595 minecraft:ochre_froglight
setblock 224 289 597 minecraft:ochre_froglight
setblock 225 289 588 minecraft:ochre_froglight
setblock 225 289 590 minecraft:ochre_froglight
setblock 225 289 592 minecraft:ochre_froglight
setblock 225 289 594 minecraft:ochre_froglight
setblock 225 289 596 minecraft:ochre_froglight
setblock 225 289 598 minecraft:ochre_froglight
setblock 226 289 589 minecraft:ochre_froglight
setblock 226 289 591 minecraft:ochre_froglight
setblock 226 289 593 minecraft:ochre_froglight
setblock 226 289 595 minecraft:ochre_froglight
setblock 226 289 597 minecraft:ochre_froglight
setblock 227 289 588 minecraft:ochre_froglight
setblock 227 289 590 minecraft:ochre_froglight
setblock 227 289 592 minecraft:ochre_froglight
setblock 227 289 594 minecraft:ochre_froglight
setblock 227 289 596 minecraft:ochre_froglight
setblock 227 289 598 minecraft:ochre_froglight
setblock 228 289 589 minecraft:ochre_froglight
setblock 228 289 591 minecraft:ochre_froglight
setblock 228 289 593 minecraft:ochre_froglight
setblock 228 289 595 minecraft:ochre_froglight
setblock 228 289 597 minecraft:ochre_froglight
setblock 229 289 588 minecraft:ochre_froglight
setblock 229 289 590 minecraft:ochre_froglight
setblock 229 289 592 minecraft:ochre_froglight
setblock 229 289 594 minecraft:ochre_froglight
setblock 229 289 596 minecraft:ochre_froglight
setblock 229 289 598 minecraft:ochre_froglight
setblock 230 289 589 minecraft:ochre_froglight
setblock 230 289 591 minecraft:ochre_froglight
setblock 230 289 593 minecraft:ochre_froglight
setblock 191 290 560 minecraft:light[level=14]
setblock 191 290 568 minecraft:light[level=14]
setblock 191 290 576 minecraft:light[level=14]
setblock 191 290 584 minecraft:light[level=14]
setblock 191 290 592 minecraft:light[level=14]
setblock 199 290 560 minecraft:light[level=14]
setblock 199 290 568 minecraft:light[level=14]
setblock 199 290 576 minecraft:light[level=14]
setblock 199 290 584 minecraft:light[level=14]
setblock 199 290 592 minecraft:light[level=14]
setblock 207 290 560 minecraft:light[level=14]
setblock 207 290 568 minecraft:light[level=14]
setblock 207 290 584 minecraft:light[level=14]
setblock 207 290 592 minecraft:light[level=14]
fill 209 290 592 209 291 592 minecraft:quartz_block
fill 209 290 594 209 291 594 minecraft:quartz_block
fill 209 290 596 209 291 596 minecraft:quartz_block
fill 209 290 598 209 291 598 minecraft:quartz_block
fill 210 290 593 210 291 593 minecraft:quartz_block
fill 210 290 595 210 291 595 minecraft:quartz_block
fill 210 290 597 210 291 597 minecraft:quartz_block
fill 211 290 592 211 291 592 minecraft:quartz_block
fill 211 290 594 211 291 594 minecraft:quartz_block
fill 211 290 596 211 291 596 minecraft:quartz_block
fill 211 290 598 211 291 598 minecraft:quartz_block
fill 212 290 593 212 291 593 minecraft:quartz_block
fill 212 290 595 212 291 595 minecraft:quartz_block
fill 212 290 597 212 291 597 minecraft:quartz_block
fill 213 290 592 213 291 592 minecraft:quartz_block
fill 213 290 594 213 291 594 minecraft:quartz_block
fill 213 290 596 213 291 596 minecraft:quartz_block
fill 213 290 598 213 291 598 minecraft:quartz_block
fill 214 290 593 214 291 593 minecraft:quartz_block
fill 214 290 595 214 291 595 minecraft:quartz_block
fill 214 290 597 214 291 597 minecraft:quartz_block
setblock 215 290 560 minecraft:light[level=14]
setblock 215 290 568 minecraft:light[level=14]
setblock 215 290 576 minecraft:light[level=14]
setblock 215 290 584 minecraft:light[level=14]
fill 215 290 592 215 291 592 minecraft:quartz_block
fill 215 290 594 215 291 594 minecraft:quartz_block
fill 215 290 596 215 291 596 minecraft:quartz_block
fill 215 290 598 215 291 598 minecraft:quartz_block
fill 216 290 593 216 291 593 minecraft:quartz_block
fill 216 290 595 216 291 595 minecraft:quartz_block
fill 216 290 597 216 291 597 minecraft:quartz_block
fill 217 290 592 217 291 592 minecraft:quartz_block
fill 217 290 594 217 291 594 minecraft:quartz_block
fill 217 290 596 217 291 596 minecraft:quartz_block
fill 217 290 598 217 291 598 minecraft:quartz_block
fill 218 290 593 218 291 593 minecraft:quartz_block
fill 218 290 595 218 291 595 minecraft:quartz_block
fill 218 290 597 218 291 597 minecraft:quartz_block
fill 219 290 592 219 291 592 minecraft:quartz_block
fill 219 290 594 219 291 594 minecraft:quartz_block
fill 219 290 596 219 291 596 minecraft:quartz_block
fill 219 290 598 219 291 598 minecraft:quartz_block
fill 220 290 593 220 291 593 minecraft:quartz_block
fill 220 290 595 220 291 595 minecraft:quartz_block
fill 220 290 597 220 291 597 minecraft:quartz_block
fill 221 290 592 221 291 592 minecraft:quartz_block
fill 221 290 594 221 291 594 minecraft:quartz_block
fill 221 290 596 221 291 596 minecraft:quartz_block
fill 221 290 598 221 291 598 minecraft:quartz_block
fill 222 290 589 222 291 589 minecraft:quartz_block
fill 222 290 591 222 291 591 minecraft:quartz_block
fill 222 290 593 222 291 593 minecraft:quartz_block
fill 222 290 595 222 291 595 minecraft:quartz_block
fill 222 290 597 222 291 597 minecraft:quartz_block
setblock 223 290 560 minecraft:light[level=14]
setblock 223 290 568 minecraft:light[level=14]
setblock 223 290 576 minecraft:light[level=14]
setblock 223 290 584 minecraft:light[level=14]
fill 223 290 588 223 291 588 minecraft:quartz_block
fill 223 290 590 223 291 590 minecraft:quartz_block
fill 223 290 592 223 291 592 minecraft:quartz_block
fill 223 290 594 223 291 594 minecraft:quartz_block
fill 223 290 596 223 291 596 minecraft:quartz_block
fill 223 290 598 223 291 598 minecraft:quartz_block
fill 224 290 589 224 291 589 minecraft:quartz_block
fill 224 290 591 224 291 591 minecraft:quartz_block
fill 224 290 593 224 291 593 minecraft:quartz_block
fill 224 290 595 224 291 595 minecraft:quartz_block
fill 224 290 597 224 291 597 minecraft:quartz_block
fill 225 290 588 225 291 588 minecraft:quartz_block
fill 225 290 590 225 291 590 minecraft:quartz_block
fill 225 290 592 225 291 592 minecraft:quartz_block
fill 225 290 594 225 291 594 minecraft:quartz_block
fill 225 290 596 225 291 596 minecraft:quartz_block
fill 225 290 598 225 291 598 minecraft:quartz_block
fill 226 290 589 226 291 589 minecraft:quartz_block
fill 226 290 591 226 291 591 minecraft:quartz_block
fill 226 290 593 226 291 593 minecraft:quartz_block
fill 226 290 595 226 291 595 minecraft:quartz_block
fill 226 290 597 226 291 597 minecraft:quartz_block
fill 227 290 588 227 291 588 minecraft:quartz_block
fill 227 290 590 227 291 590 minecraft:quartz_block
fill 227 290 592 227 291 592 minecraft:quartz_block
fill 227 290 594 227 291 594 minecraft:quartz_block
fill 227 290 596 227 291 596 minecraft:quartz_block
fill 227 290 598 227 291 598 minecraft:quartz_block
fill 228 290 589 228 291 589 minecraft:quartz_block
fill 228 290 591 228 291 591 minecraft:quartz_block
fill 228 290 593 228 291 593 minecraft:quartz_block
fill 228 290 595 228 291 595 minecraft:quartz_block
fill 228 290 597 228 291 597 minecraft:quartz_block
fill 229 290 588 229 291 588 minecraft:quartz_block
fill 229 290 590 229 291 590 minecraft:quartz_block
fill 229 290 592 229 291 592 minecraft:quartz_block
fill 229 290 594 229 291 594 minecraft:quartz_block
fill 229 290 596 229 291 596 minecraft:quartz_block
fill 229 290 598 229 291 598 minecraft:quartz_block
fill 230 290 589 230 291 589 minecraft:gold_block
fill 230 290 591 230 291 591 minecraft:gold_block
fill 230 290 593 230 291 593 minecraft:gold_block
fill 188 292 563 188 307 563 minecraft:gold_block
fill 188 292 564 188 292 565 minecraft:ochre_froglight
fill 188 292 566 188 307 566 minecraft:gold_block
fill 188 292 575 188 307 575 minecraft:gold_block
fill 188 292 576 188 292 577 minecraft:ochre_froglight
fill 188 292 578 188 307 578 minecraft:gold_block
fill 188 292 587 188 307 587 minecraft:gold_block
fill 188 292 588 188 292 589 minecraft:ochre_froglight
fill 188 292 590 188 307 590 minecraft:gold_block
fill 188 292 599 188 307 599 minecraft:gold_block
fill 189 292 599 190 292 599 minecraft:ochre_froglight
fill 191 292 599 191 307 599 minecraft:gold_block
fill 195 292 557 195 307 557 minecraft:gold_block
fill 196 292 557 197 292 557 minecraft:ochre_froglight
fill 198 292 557 198 307 557 minecraft:gold_block
fill 200 292 599 200 307 599 minecraft:gold_block
fill 201 292 599 202 292 599 minecraft:ochre_froglight
fill 203 292 599 203 307 599 minecraft:gold_block
fill 207 292 557 207 307 557 minecraft:gold_block
fill 208 292 557 209 292 557 minecraft:ochre_froglight
setblock 209 292 592 minecraft:ochre_froglight
setblock 209 292 594 minecraft:ochre_froglight
setblock 209 292 596 minecraft:ochre_froglight
setblock 209 292 598 minecraft:ochre_froglight
fill 210 292 557 210 307 557 minecraft:gold_block
setblock 210 292 593 minecraft:ochre_froglight
setblock 210 292 595 minecraft:ochre_froglight
setblock 210 292 597 minecraft:ochre_froglight
setblock 211 292 592 minecraft:ochre_froglight
setblock 211 292 594 minecraft:ochre_froglight
setblock 211 292 596 minecraft:ochre_froglight
setblock 211 292 598 minecraft:ochre_froglight
setblock 212 292 593 minecraft:ochre_froglight
setblock 212 292 595 minecraft:ochre_froglight
setblock 212 292 597 minecraft:ochre_froglight
fill 212 292 599 212 307 599 minecraft:gold_block
setblock 213 292 592 minecraft:ochre_froglight
setblock 213 292 594 minecraft:ochre_froglight
setblock 213 292 596 minecraft:ochre_froglight
fill 213 292 598 213 292 599 minecraft:ochre_froglight
setblock 214 292 593 minecraft:ochre_froglight
setblock 214 292 595 minecraft:ochre_froglight
setblock 214 292 597 minecraft:ochre_froglight
setblock 214 292 599 minecraft:ochre_froglight
setblock 215 292 592 minecraft:ochre_froglight
setblock 215 292 594 minecraft:ochre_froglight
setblock 215 292 596 minecraft:ochre_froglight
setblock 215 292 598 minecraft:ochre_froglight
fill 215 292 599 215 307 599 minecraft:gold_block
setblock 216 292 593 minecraft:ochre_froglight
setblock 216 292 595 minecraft:ochre_froglight
setblock 216 292 597 minecraft:ochre_froglight
setblock 217 292 592 minecraft:ochre_froglight
setblock 217 292 594 minecraft:ochre_froglight
setblock 217 292 596 minecraft:ochre_froglight
setblock 217 292 598 minecraft:ochre_froglight
setblock 218 292 593 minecraft:ochre_froglight
setblock 218 292 595 minecraft:ochre_froglight
setblock 218 292 597 minecraft:ochre_froglight
fill 219 292 557 219 307 557 minecraft:gold_block
setblock 219 292 592 minecraft:ochre_froglight
setblock 219 292 594 minecraft:ochre_froglight
setblock 219 292 596 minecraft:ochre_froglight
setblock 219 292 598 minecraft:ochre_froglight
fill 220 292 557 221 292 557 minecraft:ochre_froglight
setblock 220 292 593 minecraft:ochre_froglight
setblock 220 292 595 minecraft:ochre_froglight
setblock 220 292 597 minecraft:ochre_froglight
setblock 221 292 592 minecraft:ochre_froglight
setblock 221 292 594 minecraft:ochre_froglight
setblock 221 292 596 minecraft:ochre_froglight
setblock 221 292 598 minecraft:ochre_froglight
fill 222 292 557 222 307 557 minecraft:gold_block
setblock 222 292 589 minecraft:ochre_froglight
setblock 222 292 591 minecraft:ochre_froglight
setblock 222 292 593 minecraft:ochre_froglight
setblock 222 292 595 minecraft:ochre_froglight
setblock 222 292 597 minecraft:ochre_froglight
setblock 223 292 588 minecraft:ochre_froglight
setblock 223 292 590 minecraft:ochre_froglight
setblock 223 292 592 minecraft:ochre_froglight
setblock 223 292 594 minecraft:ochre_froglight
setblock 223 292 596 minecraft:ochre_froglight
setblock 223 292 598 minecraft:ochre_froglight
setblock 224 292 589 minecraft:ochre_froglight
setblock 224 292 591 minecraft:ochre_froglight
setblock 224 292 593 minecraft:ochre_froglight
setblock 224 292 595 minecraft:ochre_froglight
setblock 224 292 597 minecraft:ochre_froglight
fill 224 292 599 224 307 599 minecraft:gold_block
setblock 225 292 588 minecraft:ochre_froglight
setblock 225 292 590 minecraft:ochre_froglight
setblock 225 292 592 minecraft:ochre_froglight
setblock 225 292 594 minecraft:ochre_froglight
setblock 225 292 596 minecraft:ochre_froglight
fill 225 292 598 225 292 599 minecraft:ochre_froglight
setblock 226 292 589 minecraft:ochre_froglight
setblock 226 292 591 minecraft:ochre_froglight
setblock 226 292 593 minecraft:ochre_froglight
setblock 226 292 595 minecraft:ochre_froglight
setblock 226 292 597 minecraft:ochre_froglight
setblock 226 292 599 minecraft:ochre_froglight
setblock 227 292 588 minecraft:ochre_froglight
setblock 227 292 590 minecraft:ochre_froglight
setblock 227 292 592 minecraft:ochre_froglight
setblock 227 292 594 minecraft:ochre_froglight
setblock 227 292 596 minecraft:ochre_froglight
setblock 227 292 598 minecraft:ochre_froglight
fill 227 292 599 227 307 599 minecraft:gold_block
setblock 228 292 589 minecraft:ochre_froglight
setblock 228 292 591 minecraft:ochre_froglight
setblock 228 292 593 minecraft:ochre_froglight
setblock 228 292 595 minecraft:ochre_froglight
setblock 228 292 597 minecraft:ochre_froglight
setblock 229 292 588 minecraft:ochre_froglight
setblock 229 292 590 minecraft:ochre_froglight
setblock 229 292 592 minecraft:ochre_froglight
setblock 229 292 594 minecraft:ochre_froglight
setblock 229 292 596 minecraft:ochre_froglight
setblock 229 292 598 minecraft:ochre_froglight
fill 230 292 558 230 307 558 minecraft:gold_block
fill 230 292 559 230 292 560 minecraft:ochre_froglight
fill 230 292 561 230 307 561 minecraft:gold_block
fill 230 292 570 230 307 570 minecraft:gold_block
fill 230 292 571 230 292 572 minecraft:ochre_froglight
fill 230 292 573 230 307 573 minecraft:gold_block
fill 230 292 582 230 307 582 minecraft:gold_block
fill 230 292 583 230 292 584 minecraft:ochre_froglight
fill 230 292 585 230 307 585 minecraft:gold_block
setblock 230 292 589 minecraft:ochre_froglight
setblock 230 292 591 minecraft:ochre_froglight
setblock 230 292 593 minecraft:ochre_froglight
fill 230 292 594 230 307 594 minecraft:gold_block
fill 188 293 564 188 307 565 minecraft:gold_block
fill 188 293 576 188 307 577 minecraft:gold_block
fill 188 293 588 188 307 589 minecraft:gold_block
fill 189 293 599 190 307 599 minecraft:gold_block
fill 196 293 557 197 307 557 minecraft:gold_block
fill 201 293 599 202 307 599 minecraft:gold_block
fill 208 293 557 209 307 557 minecraft:gold_block
fill 209 293 592 209 294 592 minecraft:quartz_block
fill 209 293 594 209 294 594 minecraft:quartz_block
fill 209 293 596 209 294 596 minecraft:quartz_block
fill 209 293 598 209 294 598 minecraft:quartz_block
fill 210 293 593 210 294 593 minecraft:quartz_block
fill 210 293 595 210 294 595 minecraft:quartz_block
fill 210 293 597 210 294 597 minecraft:quartz_block
fill 211 293 592 211 294 592 minecraft:quartz_block
fill 211 293 594 211 294 594 minecraft:quartz_block
fill 211 293 596 211 294 596 minecraft:quartz_block
fill 211 293 598 211 294 598 minecraft:quartz_block
fill 212 293 593 212 294 593 minecraft:quartz_block
fill 212 293 595 212 294 595 minecraft:quartz_block
fill 212 293 597 212 294 597 minecraft:quartz_block
fill 213 293 592 213 294 592 minecraft:quartz_block
fill 213 293 594 213 294 594 minecraft:quartz_block
fill 213 293 596 213 294 596 minecraft:quartz_block
fill 213 293 598 213 294 598 minecraft:quartz_block
fill 213 293 599 214 307 599 minecraft:gold_block
fill 214 293 593 214 294 593 minecraft:quartz_block
fill 214 293 595 214 294 595 minecraft:quartz_block
fill 214 293 597 214 294 597 minecraft:quartz_block
fill 215 293 592 215 294 592 minecraft:quartz_block
fill 215 293 594 215 294 594 minecraft:quartz_block
fill 215 293 596 215 294 596 minecraft:quartz_block
fill 215 293 598 215 294 598 minecraft:quartz_block
fill 216 293 593 216 294 593 minecraft:quartz_block
fill 216 293 595 216 294 595 minecraft:quartz_block
fill 216 293 597 216 294 597 minecraft:quartz_block
fill 217 293 592 217 294 592 minecraft:quartz_block
fill 217 293 594 217 294 594 minecraft:quartz_block
fill 217 293 596 217 294 596 minecraft:quartz_block
fill 217 293 598 217 294 598 minecraft:quartz_block
fill 218 293 593 218 294 593 minecraft:quartz_block
fill 218 293 595 218 294 595 minecraft:quartz_block
fill 218 293 597 218 294 597 minecraft:quartz_block
fill 219 293 592 219 294 592 minecraft:quartz_block
fill 219 293 594 219 294 594 minecraft:quartz_block
fill 219 293 596 219 294 596 minecraft:quartz_block
fill 219 293 598 219 294 598 minecraft:quartz_block
fill 220 293 557 221 307 557 minecraft:gold_block
fill 220 293 593 220 294 593 minecraft:quartz_block
fill 220 293 595 220 294 595 minecraft:quartz_block
fill 220 293 597 220 294 597 minecraft:quartz_block
fill 221 293 592 221 294 592 minecraft:quartz_block
fill 221 293 594 221 294 594 minecraft:quartz_block
fill 221 293 596 221 294 596 minecraft:quartz_block
fill 221 293 598 221 294 598 minecraft:quartz_block
fill 222 293 589 222 294 589 minecraft:quartz_block
fill 222 293 591 222 294 591 minecraft:quartz_block
fill 222 293 593 222 294 593 minecraft:quartz_block
fill 222 293 595 222 294 595 minecraft:quartz_block
fill 222 293 597 222 294 597 minecraft:quartz_block
fill 223 293 588 223 294 588 minecraft:quartz_block
fill 223 293 590 223 294 590 minecraft:quartz_block
fill 223 293 592 223 294 592 minecraft:quartz_block
fill 223 293 594 223 294 594 minecraft:quartz_block
fill 223 293 596 223 294 596 minecraft:quartz_block
fill 223 293 598 223 294 598 minecraft:quartz_block
fill 224 293 589 224 294 589 minecraft:quartz_block
fill 224 293 591 224 294 591 minecraft:quartz_block
fill 224 293 593 224 294 593 minecraft:quartz_block
fill 224 293 595 224 294 595 minecraft:quartz_block
fill 224 293 597 224 294 597 minecraft:quartz_block
fill 225 293 588 225 294 588 minecraft:quartz_block
fill 225 293 590 225 294 590 minecraft:quartz_block
fill 225 293 592 225 294 592 minecraft:quartz_block
fill 225 293 594 225 294 594 minecraft:quartz_block
fill 225 293 596 225 294 596 minecraft:quartz_block
fill 225 293 598 225 294 598 minecraft:quartz_block
fill 225 293 599 226 307 599 minecraft:gold_block
fill 226 293 589 226 294 589 minecraft:quartz_block
fill 226 293 591 226 294 591 minecraft:quartz_block
fill 226 293 593 226 294 593 minecraft:quartz_block
fill 226 293 595 226 294 595 minecraft:quartz_block
fill 226 293 597 226 294 597 minecraft:quartz_block
fill 227 293 588 227 294 588 minecraft:quartz_block
fill 227 293 590 227 294 590 minecraft:quartz_block
fill 227 293 592 227 294 592 minecraft:quartz_block
fill 227 293 594 227 294 594 minecraft:quartz_block
fill 227 293 596 227 294 596 minecraft:quartz_block
fill 227 293 598 227 294 598 minecraft:quartz_block
fill 228 293 589 228 294 589 minecraft:quartz_block
fill 228 293 591 228 294 591 minecraft:quartz_block
fill 228 293 593 228 294 593 minecraft:quartz_block
fill 228 293 595 228 294 595 minecraft:quartz_block
fill 228 293 597 228 294 597 minecraft:quartz_block
fill 229 293 588 229 294 588 minecraft:quartz_block
fill 229 293 590 229 294 590 minecraft:quartz_block
fill 229 293 592 229 294 592 minecraft:quartz_block
fill 229 293 594 229 294 594 minecraft:quartz_block
fill 229 293 596 229 294 596 minecraft:quartz_block
fill 229 293 598 229 294 598 minecraft:quartz_block
fill 230 293 559 230 307 560 minecraft:gold_block
fill 230 293 571 230 307 572 minecraft:gold_block
fill 230 293 583 230 307 584 minecraft:gold_block
fill 230 293 589 230 294 589 minecraft:gold_block
fill 230 293 591 230 294 591 minecraft:gold_block
fill 230 293 593 230 294 593 minecraft:gold_block
fill 230 293 595 230 294 597 minecraft:gold_block
setblock 209 295 592 minecraft:ochre_froglight
setblock 209 295 594 minecraft:ochre_froglight
setblock 209 295 596 minecraft:ochre_froglight
setblock 209 295 598 minecraft:ochre_froglight
setblock 210 295 593 minecraft:ochre_froglight
setblock 210 295 595 minecraft:ochre_froglight
setblock 210 295 597 minecraft:ochre_froglight
setblock 211 295 592 minecraft:ochre_froglight
setblock 211 295 594 minecraft:ochre_froglight
setblock 211 295 596 minecraft:ochre_froglight
setblock 211 295 598 minecraft:ochre_froglight
setblock 212 295 593 minecraft:ochre_froglight
setblock 212 295 595 minecraft:ochre_froglight
setblock 212 295 597 minecraft:ochre_froglight
setblock 213 295 592 minecraft:ochre_froglight
setblock 213 295 594 minecraft:ochre_froglight
setblock 213 295 596 minecraft:ochre_froglight
setblock 213 295 598 minecraft:ochre_froglight
setblock 214 295 593 minecraft:ochre_froglight
setblock 214 295 595 minecraft:ochre_froglight
setblock 214 295 597 minecraft:ochre_froglight
setblock 215 295 592 minecraft:ochre_froglight
setblock 215 295 594 minecraft:ochre_froglight
setblock 215 295 596 minecraft:ochre_froglight
setblock 215 295 598 minecraft:ochre_froglight
setblock 216 295 593 minecraft:ochre_froglight
setblock 216 295 595 minecraft:ochre_froglight
setblock 216 295 597 minecraft:ochre_froglight
setblock 217 295 592 minecraft:ochre_froglight
setblock 217 295 594 minecraft:ochre_froglight
setblock 217 295 596 minecraft:ochre_froglight
setblock 217 295 598 minecraft:ochre_froglight
setblock 218 295 593 minecraft:ochre_froglight
setblock 218 295 595 minecraft:ochre_froglight
setblock 218 295 597 minecraft:ochre_froglight
setblock 219 295 592 minecraft:ochre_froglight
setblock 219 295 594 minecraft:ochre_froglight
setblock 219 295 596 minecraft:ochre_froglight
setblock 219 295 598 minecraft:ochre_froglight
setblock 220 295 593 minecraft:ochre_froglight
setblock 220 295 595 minecraft:ochre_froglight
setblock 220 295 597 minecraft:ochre_froglight
setblock 221 295 592 minecraft:ochre_froglight
setblock 221 295 594 minecraft:ochre_froglight
setblock 221 295 596 minecraft:ochre_froglight
setblock 221 295 598 minecraft:ochre_froglight
setblock 222 295 589 minecraft:ochre_froglight
setblock 222 295 591 minecraft:ochre_froglight
setblock 222 295 593 minecraft:ochre_froglight
setblock 222 295 595 minecraft:ochre_froglight
setblock 222 295 597 minecraft:ochre_froglight
setblock 223 295 588 minecraft:ochre_froglight
setblock 223 295 590 minecraft:ochre_froglight
setblock 223 295 592 minecraft:ochre_froglight
setblock 223 295 594 minecraft:ochre_froglight
setblock 223 295 596 minecraft:ochre_froglight
setblock 223 295 598 minecraft:ochre_froglight
setblock 224 295 589 minecraft:ochre_froglight
setblock 224 295 591 minecraft:ochre_froglight
setblock 224 295 593 minecraft:ochre_froglight
setblock 224 295 595 minecraft:ochre_froglight
setblock 224 295 597 minecraft:ochre_froglight
setblock 225 295 588 minecraft:ochre_froglight
setblock 225 295 590 minecraft:ochre_froglight
setblock 225 295 592 minecraft:ochre_froglight
setblock 225 295 594 minecraft:ochre_froglight
setblock 225 295 596 minecraft:ochre_froglight
setblock 225 295 598 minecraft:ochre_froglight
setblock 226 295 589 minecraft:ochre_froglight
setblock 226 295 591 minecraft:ochre_froglight
setblock 226 295 593 minecraft:ochre_froglight
setblock 226 295 595 minecraft:ochre_froglight
setblock 226 295 597 minecraft:ochre_froglight
setblock 227 295 588 minecraft:ochre_froglight
setblock 227 295 590 minecraft:ochre_froglight
setblock 227 295 592 minecraft:ochre_froglight
setblock 227 295 594 minecraft:ochre_froglight
setblock 227 295 596 minecraft:ochre_froglight
setblock 227 295 598 minecraft:ochre_froglight
setblock 228 295 589 minecraft:ochre_froglight
setblock 228 295 591 minecraft:ochre_froglight
setblock 228 295 593 minecraft:ochre_froglight
setblock 228 295 595 minecraft:ochre_froglight
setblock 228 295 597 minecraft:ochre_froglight
setblock 229 295 588 minecraft:ochre_froglight
setblock 229 295 590 minecraft:ochre_froglight
setblock 229 295 592 minecraft:ochre_froglight
setblock 229 295 594 minecraft:ochre_froglight
setblock 229 295 596 minecraft:ochre_froglight
setblock 229 295 598 minecraft:ochre_froglight
setblock 230 295 589 minecraft:ochre_froglight
setblock 230 295 591 minecraft:ochre_froglight
setblock 230 295 593 minecraft:ochre_froglight
setblock 230 295 595 minecraft:ochre_froglight
fill 230 295 596 230 307 596 minecraft:gold_block
setblock 230 295 597 minecraft:ochre_froglight
fill 209 296 592 209 297 592 minecraft:quartz_block
fill 209 296 594 209 297 594 minecraft:quartz_block
fill 209 296 596 209 297 596 minecraft:quartz_block
fill 209 296 598 209 297 598 minecraft:quartz_block
fill 210 296 593 210 297 593 minecraft:quartz_block
fill 210 296 595 210 297 595 minecraft:quartz_block
fill 210 296 597 210 297 597 minecraft:quartz_block
fill 211 296 592 211 297 592 minecraft:quartz_block
fill 211 296 594 211 297 594 minecraft:quartz_block
fill 211 296 596 211 297 596 minecraft:quartz_block
fill 211 296 598 211 297 598 minecraft:quartz_block
fill 212 296 593 212 297 593 minecraft:quartz_block
fill 212 296 595 212 297 595 minecraft:quartz_block
fill 212 296 597 212 297 597 minecraft:quartz_block
fill 213 296 592 213 297 592 minecraft:quartz_block
fill 213 296 594 213 297 594 minecraft:quartz_block
fill 213 296 596 213 297 596 minecraft:quartz_block
fill 213 296 598 213 297 598 minecraft:quartz_block
fill 214 296 593 214 297 593 minecraft:quartz_block
fill 214 296 595 214 297 595 minecraft:quartz_block
fill 214 296 597 214 297 597 minecraft:quartz_block
fill 215 296 592 215 297 592 minecraft:quartz_block
fill 215 296 594 215 297 594 minecraft:quartz_block
fill 215 296 596 215 297 596 minecraft:quartz_block
fill 215 296 598 215 297 598 minecraft:quartz_block
fill 216 296 593 216 297 593 minecraft:quartz_block
fill 216 296 595 216 297 595 minecraft:quartz_block
fill 216 296 597 216 297 597 minecraft:quartz_block
fill 217 296 592 217 297 592 minecraft:quartz_block
fill 217 296 594 217 297 594 minecraft:quartz_block
fill 217 296 596 217 297 596 minecraft:quartz_block
fill 217 296 598 217 297 598 minecraft:quartz_block
fill 218 296 593 218 297 593 minecraft:quartz_block
fill 218 296 595 218 297 595 minecraft:quartz_block
fill 218 296 597 218 297 597 minecraft:quartz_block
fill 219 296 592 219 297 592 minecraft:quartz_block
fill 219 296 594 219 297 594 minecraft:quartz_block
fill 219 296 596 219 297 596 minecraft:quartz_block
fill 219 296 598 219 297 598 minecraft:quartz_block
fill 220 296 593 220 297 593 minecraft:quartz_block
fill 220 296 595 220 297 595 minecraft:quartz_block
fill 220 296 597 220 297 597 minecraft:quartz_block
fill 221 296 592 221 297 592 minecraft:quartz_block
fill 221 296 594 221 297 594 minecraft:quartz_block
fill 221 296 596 221 297 596 minecraft:quartz_block
fill 221 296 598 221 297 598 minecraft:quartz_block
fill 222 296 589 222 297 589 minecraft:quartz_block
fill 222 296 591 222 297 591 minecraft:quartz_block
fill 222 296 593 222 297 593 minecraft:quartz_block
fill 222 296 595 222 297 595 minecraft:quartz_block
fill 222 296 597 222 297 597 minecraft:quartz_block
fill 223 296 588 223 297 588 minecraft:quartz_block
fill 223 296 590 223 297 590 minecraft:quartz_block
fill 223 296 592 223 297 592 minecraft:quartz_block
fill 223 296 594 223 297 594 minecraft:quartz_block
fill 223 296 596 223 297 596 minecraft:quartz_block
fill 223 296 598 223 297 598 minecraft:quartz_block
fill 224 296 589 224 297 589 minecraft:quartz_block
fill 224 296 591 224 297 591 minecraft:quartz_block
fill 224 296 593 224 297 593 minecraft:quartz_block
fill 224 296 595 224 297 595 minecraft:quartz_block
fill 224 296 597 224 297 597 minecraft:quartz_block
fill 225 296 588 225 297 588 minecraft:quartz_block
fill 225 296 590 225 297 590 minecraft:quartz_block
fill 225 296 592 225 297 592 minecraft:quartz_block
fill 225 296 594 225 297 594 minecraft:quartz_block
fill 225 296 596 225 297 596 minecraft:quartz_block
fill 225 296 598 225 297 598 minecraft:quartz_block
fill 226 296 589 226 297 589 minecraft:quartz_block
fill 226 296 591 226 297 591 minecraft:quartz_block
fill 226 296 593 226 297 593 minecraft:quartz_block
fill 226 296 595 226 297 595 minecraft:quartz_block
fill 226 296 597 226 297 597 minecraft:quartz_block
fill 227 296 588 227 297 588 minecraft:quartz_block
fill 227 296 590 227 297 590 minecraft:quartz_block
fill 227 296 592 227 297 592 minecraft:quartz_block
fill 227 296 594 227 297 594 minecraft:quartz_block
fill 227 296 596 227 297 596 minecraft:quartz_block
fill 227 296 598 227 297 598 minecraft:quartz_block
fill 228 296 589 228 297 589 minecraft:quartz_block
fill 228 296 591 228 297 591 minecraft:quartz_block
fill 228 296 593 228 297 593 minecraft:quartz_block
fill 228 296 595 228 297 595 minecraft:quartz_block
fill 228 296 597 228 297 597 minecraft:quartz_block
fill 229 296 588 229 297 588 minecraft:quartz_block
fill 229 296 590 229 297 590 minecraft:quartz_block
fill 229 296 592 229 297 592 minecraft:quartz_block
fill 229 296 594 229 297 594 minecraft:quartz_block
fill 229 296 596 229 297 596 minecraft:quartz_block
fill 229 296 598 229 297 598 minecraft:quartz_block
fill 230 296 589 230 297 589 minecraft:gold_block
fill 230 296 591 230 297 591 minecraft:gold_block
fill 230 296 593 230 297 593 minecraft:gold_block
fill 230 296 595 230 297 595 minecraft:gold_block
fill 230 296 597 230 297 597 minecraft:gold_block
setblock 191 298 560 minecraft:light[level=14]
setblock 191 298 568 minecraft:light[level=14]
setblock 191 298 576 minecraft:light[level=14]
setblock 191 298 584 minecraft:light[level=14]
setblock 191 298 592 minecraft:light[level=14]
setblock 199 298 560 minecraft:light[level=14]
setblock 199 298 568 minecraft:light[level=14]
setblock 199 298 576 minecraft:light[level=14]
setblock 199 298 584 minecraft:light[level=14]
setblock 199 298 592 minecraft:light[level=14]
setblock 207 298 560 minecraft:light[level=14]
setblock 207 298 568 minecraft:light[level=14]
setblock 207 298 584 minecraft:light[level=14]
setblock 207 298 592 minecraft:light[level=14]
setblock 209 298 592 minecraft:ochre_froglight
setblock 209 298 594 minecraft:ochre_froglight
setblock 209 298 596 minecraft:ochre_froglight
setblock 209 298 598 minecraft:ochre_froglight
setblock 210 298 593 minecraft:ochre_froglight
setblock 210 298 595 minecraft:ochre_froglight
setblock 210 298 597 minecraft:ochre_froglight
setblock 211 298 592 minecraft:ochre_froglight
setblock 211 298 594 minecraft:ochre_froglight
setblock 211 298 596 minecraft:ochre_froglight
setblock 211 298 598 minecraft:ochre_froglight
setblock 212 298 593 minecraft:ochre_froglight
setblock 212 298 595 minecraft:ochre_froglight
setblock 212 298 597 minecraft:ochre_froglight
setblock 213 298 592 minecraft:ochre_froglight
setblock 213 298 594 minecraft:ochre_froglight
setblock 213 298 596 minecraft:ochre_froglight
setblock 213 298 598 minecraft:ochre_froglight
setblock 214 298 593 minecraft:ochre_froglight
setblock 214 298 595 minecraft:ochre_froglight
setblock 214 298 597 minecraft:ochre_froglight
setblock 215 298 560 minecraft:light[level=14]
setblock 215 298 568 minecraft:light[level=14]
setblock 215 298 576 minecraft:light[level=14]
setblock 215 298 584 minecraft:light[level=14]
setblock 215 298 592 minecraft:ochre_froglight
setblock 215 298 594 minecraft:ochre_froglight
setblock 215 298 596 minecraft:ochre_froglight
setblock 215 298 598 minecraft:ochre_froglight
setblock 216 298 593 minecraft:ochre_froglight
setblock 216 298 595 minecraft:ochre_froglight
setblock 216 298 597 minecraft:ochre_froglight
setblock 217 298 592 minecraft:ochre_froglight
setblock 217 298 594 minecraft:ochre_froglight
setblock 217 298 596 minecraft:ochre_froglight
setblock 217 298 598 minecraft:ochre_froglight
setblock 218 298 593 minecraft:ochre_froglight
setblock 218 298 595 minecraft:ochre_froglight
setblock 218 298 597 minecraft:ochre_froglight
setblock 219 298 592 minecraft:ochre_froglight
setblock 219 298 594 minecraft:ochre_froglight
setblock 219 298 596 minecraft:ochre_froglight
setblock 219 298 598 minecraft:ochre_froglight
setblock 220 298 593 minecraft:ochre_froglight
setblock 220 298 595 minecraft:ochre_froglight
setblock 220 298 597 minecraft:ochre_froglight
setblock 221 298 592 minecraft:ochre_froglight
setblock 221 298 594 minecraft:ochre_froglight
setblock 221 298 596 minecraft:ochre_froglight
setblock 221 298 598 minecraft:ochre_froglight
setblock 222 298 589 minecraft:ochre_froglight
setblock 222 298 591 minecraft:ochre_froglight
setblock 222 298 593 minecraft:ochre_froglight
setblock 222 298 595 minecraft:ochre_froglight
setblock 222 298 597 minecraft:ochre_froglight
setblock 223 298 560 minecraft:light[level=14]
setblock 223 298 568 minecraft:light[level=14]
setblock 223 298 576 minecraft:light[level=14]
setblock 223 298 584 minecraft:light[level=14]
setblock 223 298 588 minecraft:ochre_froglight
setblock 223 298 590 minecraft:ochre_froglight
setblock 223 298 592 minecraft:ochre_froglight
setblock 223 298 594 minecraft:ochre_froglight
setblock 223 298 596 minecraft:ochre_froglight
setblock 223 298 598 minecraft:ochre_froglight
setblock 224 298 589 minecraft:ochre_froglight
setblock 224 298 591 minecraft:ochre_froglight
setblock 224 298 593 minecraft:ochre_froglight
setblock 224 298 595 minecraft:ochre_froglight
setblock 224 298 597 minecraft:ochre_froglight
setblock 225 298 588 minecraft:ochre_froglight
setblock 225 298 590 minecraft:ochre_froglight
setblock 225 298 592 minecraft:ochre_froglight
setblock 225 298 594 minecraft:ochre_froglight
setblock 225 298 596 minecraft:ochre_froglight
setblock 225 298 598 minecraft:ochre_froglight
setblock 226 298 589 minecraft:ochre_froglight
setblock 226 298 591 minecraft:ochre_froglight
setblock 226 298 593 minecraft:ochre_froglight
setblock 226 298 595 minecraft:ochre_froglight
setblock 226 298 597 minecraft:ochre_froglight
setblock 227 298 588 minecraft:ochre_froglight
setblock 227 298 590 minecraft:ochre_froglight
setblock 227 298 592 minecraft:ochre_froglight
setblock 227 298 594 minecraft:ochre_froglight
setblock 227 298 596 minecraft:ochre_froglight
setblock 227 298 598 minecraft:ochre_froglight
setblock 228 298 589 minecraft:ochre_froglight
setblock 228 298 591 minecraft:ochre_froglight
setblock 228 298 593 minecraft:ochre_froglight
setblock 228 298 595 minecraft:ochre_froglight
setblock 228 298 597 minecraft:ochre_froglight
setblock 229 298 588 minecraft:ochre_froglight
setblock 229 298 590 minecraft:ochre_froglight
setblock 229 298 592 minecraft:ochre_froglight
setblock 229 298 594 minecraft:ochre_froglight
setblock 229 298 596 minecraft:ochre_froglight
setblock 229 298 598 minecraft:ochre_froglight
setblock 230 298 589 minecraft:ochre_froglight
setblock 230 298 591 minecraft:ochre_froglight
setblock 230 298 593 minecraft:ochre_froglight
setblock 230 298 595 minecraft:ochre_froglight
setblock 230 298 597 minecraft:ochre_froglight
fill 209 299 592 209 300 592 minecraft:quartz_block
fill 209 299 594 209 300 594 minecraft:quartz_block
fill 209 299 596 209 300 596 minecraft:quartz_block
fill 209 299 598 209 300 598 minecraft:quartz_block
fill 210 299 593 210 300 593 minecraft:quartz_block
fill 210 299 595 210 300 595 minecraft:quartz_block
fill 210 299 597 210 300 597 minecraft:quartz_block
fill 211 299 592 211 300 592 minecraft:quartz_block
fill 211 299 594 211 300 594 minecraft:quartz_block
fill 211 299 596 211 300 596 minecraft:quartz_block
fill 211 299 598 211 300 598 minecraft:quartz_block
fill 212 299 593 212 300 593 minecraft:quartz_block
fill 212 299 595 212 300 595 minecraft:quartz_block
fill 212 299 597 212 300 597 minecraft:quartz_block
fill 213 299 592 213 300 592 minecraft:quartz_block
fill 213 299 594 213 300 594 minecraft:quartz_block
fill 213 299 596 213 300 596 minecraft:quartz_block
fill 213 299 598 213 300 598 minecraft:quartz_block
fill 214 299 593 214 300 593 minecraft:quartz_block
fill 214 299 595 214 300 595 minecraft:quartz_block
fill 214 299 597 214 300 597 minecraft:quartz_block
fill 215 299 592 215 300 592 minecraft:quartz_block
fill 215 299 594 215 300 594 minecraft:quartz_block
fill 215 299 596 215 300 596 minecraft:quartz_block
fill 215 299 598 215 300 598 minecraft:quartz_block
fill 216 299 593 216 300 593 minecraft:quartz_block
fill 216 299 595 216 300 595 minecraft:quartz_block
fill 216 299 597 216 300 597 minecraft:quartz_block
fill 217 299 592 217 300 592 minecraft:quartz_block
fill 217 299 594 217 300 594 minecraft:quartz_block
fill 217 299 596 217 300 596 minecraft:quartz_block
fill 217 299 598 217 300 598 minecraft:quartz_block
fill 218 299 593 218 300 593 minecraft:quartz_block
fill 218 299 595 218 300 595 minecraft:quartz_block
fill 218 299 597 218 300 597 minecraft:quartz_block
fill 219 299 592 219 300 592 minecraft:quartz_block
fill 219 299 594 219 300 594 minecraft:quartz_block
fill 219 299 596 219 300 596 minecraft:quartz_block
fill 219 299 598 219 300 598 minecraft:quartz_block
fill 220 299 593 220 300 593 minecraft:quartz_block
fill 220 299 595 220 300 595 minecraft:quartz_block
fill 220 299 597 220 300 597 minecraft:quartz_block
fill 221 299 592 221 300 592 minecraft:quartz_block
fill 221 299 594 221 300 594 minecraft:quartz_block
fill 221 299 596 221 300 596 minecraft:quartz_block
fill 221 299 598 221 300 598 minecraft:quartz_block
setblock 222 299 589 minecraft:quartz_block
setblock 222 299 591 minecraft:quartz_block
setblock 222 299 593 minecraft:quartz_block
setblock 222 299 595 minecraft:quartz_block
fill 222 299 597 222 300 597 minecraft:quartz_block
setblock 223 299 588 minecraft:quartz_block
setblock 223 299 590 minecraft:quartz_block
setblock 223 299 592 minecraft:quartz_block
setblock 223 299 594 minecraft:quartz_block
setblock 223 299 596 minecraft:quartz_block
setblock 223 299 598 minecraft:quartz_block
setblock 224 299 589 minecraft:quartz_block
setblock 224 299 591 minecraft:quartz_block
setblock 224 299 593 minecraft:quartz_block
setblock 224 299 595 minecraft:quartz_block
setblock 224 299 597 minecraft:quartz_block
setblock 225 299 588 minecraft:quartz_block
setblock 225 299 590 minecraft:quartz_block
setblock 225 299 592 minecraft:quartz_block
setblock 225 299 594 minecraft:quartz_block
setblock 225 299 596 minecraft:quartz_block
setblock 225 299 598 minecraft:quartz_block
setblock 226 299 589 minecraft:quartz_block
setblock 226 299 591 minecraft:quartz_block
setblock 226 299 593 minecraft:quartz_block
setblock 226 299 595 minecraft:quartz_block
setblock 226 299 597 minecraft:quartz_block
setblock 227 299 588 minecraft:quartz_block
setblock 227 299 590 minecraft:quartz_block
setblock 227 299 592 minecraft:quartz_block
setblock 227 299 594 minecraft:quartz_block
setblock 227 299 596 minecraft:quartz_block
setblock 227 299 598 minecraft:quartz_block
setblock 228 299 589 minecraft:quartz_block
fill 228 299 591 228 300 591 minecraft:quartz_block
fill 228 299 593 228 300 593 minecraft:quartz_block
setblock 228 299 595 minecraft:quartz_block
setblock 228 299 597 minecraft:quartz_block
setblock 229 299 588 minecraft:quartz_block
fill 229 299 590 229 300 590 minecraft:quartz_block
fill 229 299 592 229 300 592 minecraft:quartz_block
setblock 229 299 594 minecraft:quartz_block
setblock 229 299 596 minecraft:quartz_block
setblock 229 299 598 minecraft:quartz_block
fill 230 299 589 230 307 589 minecraft:gold_block
fill 230 299 591 230 307 591 minecraft:gold_block
fill 230 299 593 230 307 593 minecraft:gold_block
fill 230 299 595 230 307 595 minecraft:gold_block
fill 230 299 597 230 307 597 minecraft:gold_block
fill 190 300 567 190 300 569 minecraft:quartz_block
fill 190 300 579 190 300 581 minecraft:quartz_block
fill 190 300 591 190 300 593 minecraft:quartz_block
fill 196 300 597 198 300 597 minecraft:quartz_block
fill 200 300 559 202 300 559 minecraft:quartz_block
setblock 208 300 597 minecraft:quartz_block
fill 212 300 559 214 300 559 minecraft:quartz_block
fill 223 300 589 227 300 597 minecraft:gold_block
fill 224 300 559 226 300 559 minecraft:quartz_block
fill 228 300 567 228 300 569 minecraft:quartz_block
fill 228 300 579 228 300 581 minecraft:quartz_block
fill 228 300 589 228 300 590 minecraft:gold_block
fill 228 300 594 229 300 597 minecraft:gold_block
setblock 229 300 589 minecraft:gold_block
setblock 229 300 593 minecraft:gold_block
