fill 489 248 364 489 255 364 minecraft:blue_concrete
fill 493 248 322 493 255 322 minecraft:blue_concrete
fill 497 248 364 497 255 364 minecraft:blue_concrete
fill 501 248 322 501 255 322 minecraft:blue_concrete
fill 505 248 364 505 255 364 minecraft:blue_concrete
fill 509 248 322 509 255 322 minecraft:blue_concrete
fill 512 248 327 512 255 327 minecraft:blue_concrete
fill 512 248 335 512 255 335 minecraft:blue_concrete
fill 512 248 343 512 255 343 minecraft:blue_concrete
fill 512 248 351 512 255 351 minecraft:blue_concrete
fill 512 248 359 512 255 359 minecraft:blue_concrete
fill 471 252 323 471 253 328 minecraft:black_concrete
fill 471 252 331 472 252 336 minecraft:black_concrete
fill 471 252 339 472 252 344 minecraft:black_concrete
fill 471 252 347 472 252 352 minecraft:black_concrete
fill 471 252 355 472 252 360 minecraft:black_concrete
fill 471 252 363 476 253 363 minecraft:black_concrete
fill 472 252 324 472 252 330 minecraft:black_concrete
fill 472 252 337 472 252 338 minecraft:black_concrete
fill 472 252 345 472 252 346 minecraft:black_concrete
fill 472 252 353 472 252 354 minecraft:black_concrete
fill 472 252 361 472 252 362 minecraft:black_concrete
fill 473 252 324 510 252 324 minecraft:black_concrete
setblock 473 252 325 minecraft:light[level=14]
setblock 473 252 333 minecraft:light[level=14]
setblock 473 252 341 minecraft:light[level=14]
setblock 473 252 349 minecraft:light[level=14]
setblock 473 252 357 minecraft:light[level=14]
fill 473 252 362 511 252 362 minecraft:black_concrete
fill 474 252 323 479 253 323 minecraft:black_concrete
fill 479 252 363 484 253 363 minecraft:black_concrete
setblock 481 252 325 minecraft:light[level=14]
setblock 481 252 333 minecraft:light[level=14]
setblock 481 252 341 minecraft:light[level=14]
setblock 481 252 349 minecraft:light[level=14]
setblock 481 252 357 minecraft:light[level=14]
fill 482 252 323 487 253 323 minecraft:black_concrete
fill 487 252 363 492 253 363 minecraft:black_concrete
setblock 489 252 325 minecraft:light[level=14]
setblock 489 252 333 minecraft:light[level=14]
setblock 489 252 341 minecraft:light[level=14]
setblock 489 252 349 minecraft:light[level=14]
setblock 489 252 357 minecraft:light[level=14]
fill 490 252 323 495 253 323 minecraft:black_concrete
fill 495 252 363 500 253 363 minecraft:black_concrete
setblock 497 252 325 minecraft:light[level=14]
setblock 497 252 333 minecraft:light[level=14]
setblock 497 252 341 minecraft:light[level=14]
setblock 497 252 349 minecraft:light[level=14]
setblock 497 252 357 minecraft:light[level=14]
fill 498 252 323 503 253 323 minecraft:black_concrete
fill 503 252 363 508 253 363 minecraft:black_concrete
setblock 505 252 325 minecraft:light[level=14]
setblock 505 252 333 minecraft:light[level=14]
setblock 505 252 341 minecraft:light[level=14]
setblock 505 252 349 minecraft:light[level=14]
setblock 505 252 357 minecraft:light[level=14]
fill 506 252 323 511 253 323 minecraft:black_concrete
fill 510 252 325 510 252 361 minecraft:black_concrete
fill 511 252 326 511 253 331 minecraft:black_concrete
fill 511 252 334 511 253 339 minecraft:black_concrete
fill 511 252 342 511 253 347 minecraft:black_concrete
fill 511 252 350 511 253 355 minecraft:black_concrete
fill 511 252 358 511 253 361 minecraft:black_concrete
fill 511 252 363 511 253 363 minecraft:black_concrete
fill 471 253 331 471 253 336 minecraft:black_concrete
fill 471 253 339 471 253 344 minecraft:black_concrete
fill 471 253 347 471 253 352 minecraft:black_concrete
fill 471 253 355 471 253 360 minecraft:black_concrete
setblock 511 253 362 minecraft:black_concrete
fill 503 255 360 503 256 362 minecraft:iron_block
fill 470 256 327 470 261 327 minecraft:sea_lantern
fill 470 256 335 470 261 335 minecraft:sea_lantern
fill 470 256 343 470 261 343 minecraft:sea_lantern
fill 470 256 351 470 261 351 minecraft:sea_lantern
fill 470 256 359 470 261 359 minecraft:sea_lantern
fill 473 256 364 473 261 364 minecraft:sea_lantern
fill 477 256 322 477 261 322 minecraft:sea_lantern
fill 481 256 364 481 261 364 minecraft:sea_lantern
fill 485 256 322 485 261 322 minecraft:sea_lantern
fill 489 256 364 489 261 364 minecraft:sea_lantern
fill 493 256 322 493 261 322 minecraft:sea_lantern
fill 497 256 364 497 261 364 minecraft:sea_lantern
fill 501 256 322 501 261 322 minecraft:sea_lantern
fill 505 256 364 505 261 364 minecraft:sea_lantern
fill 509 256 322 509 261 322 minecraft:sea_lantern
fill 512 256 327 512 261 327 minecraft:sea_lantern
fill 512 256 335 512 261 335 minecraft:sea_lantern
fill 512 256 343 512 261 343 minecraft:sea_lantern
fill 512 256 351 512 261 351 minecraft:sea_lantern
fill 512 256 359 512 261 359 minecraft:sea_lantern
fill 501 258 357 505 260 359 minecraft:blue_concrete
fill 502 258 356 504 260 356 minecraft:blue_concrete
fill 502 258 360 504 260 360 minecraft:blue_concrete
setblock 473 260 325 minecraft:light[level=14]
setblock 473 260 333 minecraft:light[level=14]
setblock 473 260 341 minecraft:light[level=14]
setblock 473 260 349 minecraft:light[level=14]
setblock 473 260 357 minecraft:light[level=14]
setblock 481 260 325 minecraft:light[level=14]
setblock 481 260 333 minecraft:light[level=14]
setblock 481 260 341 minecraft:light[level=14]
setblock 481 260 349 minecraft:light[level=14]
setblock 481 260 357 minecraft:light[level=14]
setblock 489 260 325 minecraft:light[level=14]
setblock 489 260 333 minecraft:light[level=14]
setblock 489 260 341 minecraft:light[level=14]
setblock 489 260 349 minecraft:light[level=14]
setblock 489 260 357 minecraft:light[level=14]
setblock 497 260 325 minecraft:light[level=14]
setblock 497 260 333 minecraft:light[level=14]
setblock 497 260 341 minecraft:light[level=14]
setblock 497 260 349 minecraft:light[level=14]
setblock 497 260 357 minecraft:light[level=14]
setblock 505 260 325 minecraft:light[level=14]
setblock 505 260 333 minecraft:light[level=14]
setblock 505 260 341 minecraft:light[level=14]
setblock 505 260 349 minecraft:light[level=14]
fill 500 261 357 506 261 359 minecraft:sea_lantern
fill 501 261 356 505 261 356 minecraft:sea_lantern
fill 501 261 360 505 261 360 minecraft:sea_lantern
fill 502 261 355 504 261 355 minecraft:sea_lantern
fill 502 261 361 504 261 361 minecraft:sea_lantern
fill 470 262 327 470 269 327 minecraft:blue_concrete
fill 470 262 335 470 269 335 minecraft:blue_concrete
fill 470 262 343 470 269 343 minecraft:blue_concrete
fill 470 262 351 470 269 351 minecraft:blue_concrete
fill 470 262 359 470 269 359 minecraft:blue_concrete
fill 473 262 364 473 269 364 minecraft:blue_concrete
fill 474 262 339 474 263 347 minecraft:black_concrete
fill 475 262 336 475 263 339 minecraft:black_concrete
fill 475 262 347 475 263 350 minecraft:black_concrete
fill 476 262 334 476 263 336 minecraft:black_concrete
fill 476 262 350 476 263 352 minecraft:black_concrete
fill 477 262 322 477 269 322 minecraft:blue_concrete
fill 477 262 333 477 263 334 minecraft:black_concrete
fill 477 262 352 477 263 353 minecraft:black_concrete
fill 478 262 332 478 263 333 minecraft:black_concrete
fill 478 262 353 478 263 354 minecraft:black_concrete
fill 479 262 331 479 263 331 minecraft:black_concrete
fill 479 262 355 479 263 355 minecraft:black_concrete
fill 480 262 330 481 263 330 minecraft:black_concrete
fill 480 262 356 481 263 356 minecraft:black_concrete
fill 481 262 329 482 263 329 minecraft:black_concrete
fill 481 262 357 482 263 357 minecraft:black_concrete
fill 481 262 364 481 269 364 minecraft:blue_concrete
fill 482 262 328 484 263 328 minecraft:black_concrete
fill 482 262 358 484 263 358 minecraft:black_concrete
fill 484 262 327 487 263 327 minecraft:black_concrete
fill 484 262 359 487 263 359 minecraft:black_concrete
fill 485 262 322 485 269 322 minecraft:blue_concrete
fill 487 262 326 495 263 326 minecraft:black_concrete
fill 487 262 360 495 263 360 minecraft:black_concrete
fill 489 262 364 489 269 364 minecraft:blue_concrete
fill 493 262 322 493 269 322 minecraft:blue_concrete
fill 495 262 327 498 263 327 minecraft:black_concrete
fill 495 262 359 498 263 359 minecraft:black_concrete
fill 497 262 364 497 269 364 minecraft:blue_concrete
fill 498 262 328 500 263 328 minecraft:black_concrete
fill 498 262 358 500 263 358 minecraft:black_concrete
fill 500 262 329 501 263 329 minecraft:black_concrete
fill 500 262 357 501 263 357 minecraft:black_concrete
fill 501 262 322 501 269 322 minecraft:blue_concrete
fill 501 262 330 502 263 330 minecraft:black_concrete
fill 501 262 356 502 263 356 minecraft:black_concrete
fill 503 262 331 503 263 331 minecraft:black_concrete
fill 503 262 355 503 263 355 minecraft:black_concrete
fill 504 262 332 504 263 333 minecraft:black_concrete
fill 504 262 353 504 263 354 minecraft:black_concrete
fill 505 262 333 505 263 334 minecraft:black_concrete
fill 505 262 352 505 263 353 minecraft:black_concrete
fill 505 262 364 505 269 364 minecraft:blue_concrete
fill 506 262 334 506 263 336 minecraft:black_concrete
fill 506 262 350 506 263 352 minecraft:black_concrete
fill 507 262 336 507 263 339 minecraft:black_concrete
fill 507 262 347 507 263 350 minecraft:black_concrete
fill 508 262 339 508 263 347 minecraft:black_concrete
fill 509 262 322 509 269 322 minecraft:blue_concrete
fill 512 262 327 512 269 327 minecraft:blue_concrete
fill 512 262 335 512 269 335 minecraft:blue_concrete
fill 512 262 343 512 269 343 minecraft:blue_concrete
fill 512 262 351 512 269 351 minecraft:blue_concrete
fill 512 262 359 512 269 359 minecraft:blue_concrete
fill 473 264 342 473 264 344 minecraft:sea_lantern
fill 474 264 337 474 264 341 minecraft:sea_lantern
fill 474 264 345 474 264 349 minecraft:sea_lantern
fill 475 264 335 475 264 336 minecraft:sea_lantern
fill 475 264 350 475 264 351 minecraft:sea_lantern
fill 476 264 333 476 264 334 minecraft:sea_lantern
fill 476 264 352 476 264 353 minecraft:sea_lantern
fill 477 264 332 477 264 333 minecraft:sea_lantern
fill 477 264 353 477 264 354 minecraft:sea_lantern
setblock 478 264 331 minecraft:sea_lantern
setblock 478 264 355 minecraft:sea_lantern
setblock 479 264 330 minecraft:sea_lantern
setblock 479 264 356 minecraft:sea_lantern
fill 480 264 329 481 264 329 minecraft:sea_lantern
fill 480 264 357 481 264 357 minecraft:sea_lantern
fill 481 264 328 482 264 328 minecraft:sea_lantern
fill 481 264 358 482 264 358 minecraft:sea_lantern
fill 483 264 327 484 264 327 minecraft:sea_lantern
fill 483 264 359 484 264 359 minecraft:sea_lantern
fill 485 264 326 489 264 326 minecraft:sea_lantern
fill 485 264 360 489 264 360 minecraft:sea_lantern
fill 490 264 325 492 264 325 minecraft:sea_lantern
fill 490 264 361 492 264 361 minecraft:sea_lantern
fill 493 264 326 497 264 326 minecraft:sea_lantern
fill 493 264 360 497 264 360 minecraft:sea_lantern
fill 498 264 327 499 264 327 minecraft:sea_lantern
fill 498 264 359 499 264 359 minecraft:sea_lantern
setblock 500 264 328 minecraft:sea_lantern
fill 500 264 358 501 264 358 minecraft:sea_lantern
fill 501 264 357 502 264 357 minecraft:sea_lantern
setblock 503 264 356 minecraft:sea_lantern
setblock 504 264 355 minecraft:sea_lantern
setblock 505 264 354 minecraft:sea_lantern
fill 503 265 351 504 270 351 minecraft:iron_block
fill 471 266 323 471 267 328 minecraft:black_concrete
fill 471 266 331 472 266 336 minecraft:black_concrete
fill 471 266 339 472 266 344 minecraft:black_concrete
fill 471 266 347 472 266 352 minecraft:black_concrete
fill 471 266 355 472 266 360 minecraft:black_concrete
fill 471 266 363 476 267 363 minecraft:black_concrete
fill 472 266 324 472 266 330 minecraft:black_concrete
fill 472 266 337 472 266 338 minecraft:black_concrete
fill 472 266 345 472 266 346 minecraft:black_concrete
fill 472 266 353 472 266 354 minecraft:black_concrete
fill 472 266 361 472 266 362 minecraft:black_concrete
fill 473 266 324 510 266 324 minecraft:black_concrete
fill 473 266 362 511 266 362 minecraft:black_concrete
fill 474 266 323 479 267 323 minecraft:black_concrete
fill 479 266 363 484 267 363 minecraft:black_concrete
fill 482 266 323 487 267 323 minecraft:black_concrete
fill 487 266 363 492 267 363 minecraft:black_concrete
fill 490 266 323 495 267 323 minecraft:black_concrete
fill 495 266 363 500 267 363 minecraft:black_concrete
fill 498 266 323 503 267 323 minecraft:black_concrete
fill 502 266 350 502 269 352 minecraft:iron_block
fill 503 266 350 505 269 350 minecraft:iron_block
fill 503 266 352 504 269 353 minecraft:iron_block
fill 503 266 363 508 267 363 minecraft:black_concrete
fill 505 266 351 505 269 352 minecraft:iron_block
fill 506 266 323 511 267 323 minecraft:black_concrete
fill 510 266 325 510 266 361 minecraft:black_concrete
fill 511 266 326 511 267 331 minecraft:black_concrete
fill 511 266 334 511 267 339 minecraft:black_concrete
fill 511 266 342 511 267 347 minecraft:black_concrete
fill 511 266 350 511 267 355 minecraft:black_concrete
fill 511 266 358 511 267 361 minecraft:black_concrete
fill 511 266 363 511 267 363 minecraft:black_concrete
fill 471 267 331 471 267 336 minecraft:black_concrete
fill 471 267 339 471 267 344 minecraft:black_concrete
fill 471 267 347 471 267 352 minecraft:black_concrete
fill 471 267 355 471 267 360 minecraft:black_concrete
fill 502 267 353 502 268 353 minecraft:iron_block
fill 503 267 349 504 268 349 minecraft:iron_block
fill 505 267 353 505 268 353 minecraft:iron_block
fill 506 267 351 506 268 351 minecraft:iron_block
setblock 511 267 362 minecraft:black_concrete
setblock 473 268 325 minecraft:light[level=14]
setblock 473 268 333 minecraft:light[level=14]
setblock 473 268 341 minecraft:light[level=14]
setblock 473 268 349 minecraft:light[level=14]
setblock 473 268 357 minecraft:light[level=14]
setblock 481 268 325 minecraft:light[level=14]
setblock 481 268 333 minecraft:light[level=14]
setblock 481 268 341 minecraft:light[level=14]
setblock 481 268 349 minecraft:light[level=14]
fill 481 268 356 485 269 360 minecraft:black_concrete
fill 483 268 361 483 268 362 minecraft:black_concrete
setblock 489 268 325 minecraft:light[level=14]
setblock 489 268 333 minecraft:light[level=14]
setblock 489 268 341 minecraft:light[level=14]
setblock 489 268 349 minecraft:light[level=14]
setblock 489 268 357 minecraft:light[level=14]
setblock 497 268 325 minecraft:light[level=14]
setblock 497 268 333 minecraft:light[level=14]
setblock 497 268 341 minecraft:light[level=14]
setblock 497 268 349 minecraft:light[level=14]
setblock 497 268 357 minecraft:light[level=14]
setblock 505 268 325 minecraft:light[level=14]
setblock 505 268 333 minecraft:light[level=14]
setblock 505 268 341 minecraft:light[level=14]
setblock 505 268 349 minecraft:light[level=14]
setblock 505 268 357 minecraft:light[level=14]
fill 470 270 327 470 272 327 minecraft:sea_lantern
fill 470 270 335 470 272 335 minecraft:sea_lantern
fill 470 270 343 470 272 343 minecraft:sea_lantern
fill 470 270 351 470 272 351 minecraft:sea_lantern
fill 470 270 359 470 272 359 minecraft:sea_lantern
fill 473 270 364 473 272 364 minecraft:sea_lantern
fill 477 270 322 477 272 322 minecraft:sea_lantern
fill 481 270 364 481 272 364 minecraft:sea_lantern
fill 483 270 358 483 272 358 minecraft:black_concrete
fill 485 270 322 485 272 322 minecraft:sea_lantern
fill 489 270 364 489 272 364 minecraft:sea_lantern
fill 493 270 322 493 272 322 minecraft:sea_lantern
fill 497 270 364 497 272 364 minecraft:sea_lantern
fill 501 270 322 501 272 322 minecraft:sea_lantern
fill 504 270 329 508 272 331 minecraft:blue_concrete
fill 505 270 328 507 272 328 minecraft:blue_concrete
fill 505 270 332 507 272 332 minecraft:blue_concrete
fill 505 270 364 505 272 364 minecraft:sea_lantern
fill 509 270 322 509 272 322 minecraft:sea_lantern
fill 512 270 327 512 272 327 minecraft:sea_lantern
fill 512 270 335 512 272 335 minecraft:sea_lantern
fill 512 270 343 512 272 343 minecraft:sea_lantern
fill 512 270 351 512 272 351 minecraft:sea_lantern
fill 512 270 359 512 272 359 minecraft:sea_lantern
fill 470 273 327 470 283 327 minecraft:blue_concrete
fill 470 273 335 470 283 335 minecraft:blue_concrete
fill 470 273 343 470 283 343 minecraft:blue_concrete
fill 470 273 351 470 283 351 minecraft:blue_concrete
fill 470 273 359 470 283 359 minecraft:blue_concrete
fill 473 273 364 473 283 364 minecraft:blue_concrete
fill 477 273 322 477 283 322 minecraft:blue_concrete
fill 481 273 364 481 283 364 minecraft:blue_concrete
fill 485 273 322 485 283 322 minecraft:blue_concrete
fill 489 273 364 489 283 364 minecraft:blue_concrete
fill 493 273 322 493 283 322 minecraft:blue_concrete
fill 497 273 364 497 283 364 minecraft:blue_concrete
fill 501 273 322 501 283 322 minecraft:blue_concrete
fill 505 273 364 505 283 364 minecraft:blue_concrete
fill 509 273 322 509 283 322 minecraft:blue_concrete
fill 512 273 327 512 283 327 minecraft:blue_concrete
fill 512 273 335 512 283 335 minecraft:blue_concrete
fill 512 273 343 512 283 343 minecraft:blue_concrete
fill 512 273 351 512 283 351 minecraft:blue_concrete
fill 512 273 359 512 283 359 minecraft:blue_concrete
setblock 473 276 325 minecraft:light[level=14]
setblock 473 276 333 minecraft:light[level=14]
setblock 473 276 341 minecraft:light[level=14]
setblock 473 276 349 minecraft:light[level=14]
setblock 473 276 357 minecraft:light[level=14]
setblock 481 276 325 minecraft:light[level=14]
setblock 481 276 333 minecraft:light[level=14]
setblock 481 276 341 minecraft:light[level=14]
setblock 481 276 349 minecraft:light[level=14]
setblock 481 276 357 minecraft:light[level=14]
setblock 489 276 325 minecraft:light[level=14]
setblock 489 276 333 minecraft:light[level=14]
setblock 489 276 341 minecraft:light[level=14]
setblock 489 276 349 minecraft:light[level=14]
setblock 489 276 357 minecraft:light[level=14]
setblock 497 276 325 minecraft:light[level=14]
setblock 497 276 333 minecraft:light[level=14]
setblock 497 276 341 minecraft:light[level=14]
setblock 497 276 349 minecraft:light[level=14]
setblock 497 276 357 minecraft:light[level=14]
setblock 505 276 325 minecraft:light[level=14]
setblock 505 276 333 minecraft:light[level=14]
setblock 505 276 341 minecraft:light[level=14]
setblock 505 276 349 minecraft:light[level=14]
setblock 505 276 357 minecraft:light[level=14]
fill 471 278 323 472 279 326 minecraft:blue_concrete
fill 471 278 327 472 278 331 minecraft:light_blue_concrete
fill 471 278 332 472 278 336 minecraft:blue_concrete
fill 471 278 337 472 278 341 minecraft:light_blue_concrete
fill 471 278 342 472 278 346 minecraft:blue_concrete
fill 471 278 347 472 278 351 minecraft:light_blue_concrete
fill 471 278 352 472 278 356 minecraft:blue_concrete
fill 471 278 357 472 278 361 minecraft:light_blue_concrete
fill 471 278 362 472 278 363 minecraft:blue_concrete
fill 473 278 323 477 278 326 minecraft:light_blue_concrete
fill 473 278 327 477 278 331 minecraft:blue_concrete
fill 473 278 332 477 278 336 minecraft:light_blue_concrete
fill 473 278 337 477 278 341 minecraft:blue_concrete
fill 473 278 342 477 278 346 minecraft:light_blue_concrete
fill 473 278 347 477 278 351 minecraft:blue_concrete
fill 473 278 352 477 278 356 minecraft:light_blue_concrete
fill 473 278 357 477 278 361 minecraft:blue_concrete
fill 473 278 362 477 278 363 minecraft:light_blue_concrete
fill 478 278 323 482 278 326 minecraft:blue_concrete
fill 478 278 327 482 278 331 minecraft:light_blue_concrete
fill 478 278 332 482 278 336 minecraft:blue_concrete
fill 478 278 337 482 278 341 minecraft:light_blue_concrete
fill 478 278 342 482 278 346 minecraft:blue_concrete
fill 478 278 347 482 278 351 minecraft:light_blue_concrete
fill 478 278 352 482 278 356 minecraft:blue_concrete
fill 478 278 357 482 278 361 minecraft:light_blue_concrete
fill 478 278 362 482 278 363 minecraft:blue_concrete
fill 483 278 323 487 278 326 minecraft:light_blue_concrete
fill 483 278 327 487 278 331 minecraft:blue_concrete
fill 483 278 332 487 278 336 minecraft:light_blue_concrete
fill 483 278 337 487 278 341 minecraft:blue_concrete
fill 483 278 342 487 278 346 minecraft:light_blue_concrete
fill 483 278 347 487 278 351 minecraft:blue_concrete
fill 483 278 352 487 278 356 minecraft:light_blue_concrete
fill 483 278 357 487 278 361 minecraft:blue_concrete
fill 483 278 362 487 278 363 minecraft:light_blue_concrete
fill 488 278 323 492 278 326 minecraft:blue_concrete
fill 488 278 327 492 278 331 minecraft:light_blue_concrete
fill 488 278 332 492 278 336 minecraft:blue_concrete
fill 488 278 337 490 278 341 minecraft:light_blue_concrete
fill 488 278 342 489 278 346 minecraft:blue_concrete
fill 488 278 347 492 278 351 minecraft:light_blue_concrete
fill 488 278 352 492 278 356 minecraft:blue_concrete
fill 488 278 357 492 278 361 minecraft:light_blue_concrete
fill 488 278 362 492 278 363 minecraft:blue_concrete
fill 490 278 343 490 278 346 minecraft:blue_concrete
fill 491 278 337 492 278 339 minecraft:light_blue_concrete
fill 491 278 345 492 278 346 minecraft:blue_concrete
fill 493 278 323 497 278 326 minecraft:light_blue_concrete
fill 493 278 327 497 278 331 minecraft:blue_concrete
fill 493 278 332 497 278 336 minecraft:light_blue_concrete
fill 493 278 337 497 278 338 minecraft:blue_concrete
fill 493 278 346 497 278 346 minecraft:light_blue_concrete
fill 493 278 347 497 278 351 minecraft:blue_concrete
fill 493 278 352 497 278 356 minecraft:light_blue_concrete
fill 493 278 357 497 278 361 minecraft:blue_concrete
fill 493 278 362 497 278 363 minecraft:light_blue_concrete
fill 494 278 339 497 278 339 minecraft:blue_concrete
fill 494 278 345 497 278 345 minecraft:light_blue_concrete
fill 496 278 340 497 278 341 minecraft:blue_concrete
fill 496 278 343 497 278 344 minecraft:light_blue_concrete
setblock 497 278 342 minecraft:light_blue_concrete
fill 498 278 323 502 278 326 minecraft:blue_concrete
fill 498 278 327 502 278 331 minecraft:light_blue_concrete
fill 498 278 332 502 278 336 minecraft:blue_concrete
fill 498 278 337 502 278 341 minecraft:light_blue_concrete
fill 498 278 342 502 278 346 minecraft:blue_concrete
fill 498 278 347 502 278 351 minecraft:light_blue_concrete
fill 498 278 352 502 278 356 minecraft:blue_concrete
fill 498 278 357 502 278 361 minecraft:light_blue_concrete
fill 498 278 362 502 278 363 minecraft:blue_concrete
fill 503 278 323 507 278 326 minecraft:light_blue_concrete
fill 503 278 327 507 278 331 minecraft:blue_concrete
fill 503 278 332 507 278 336 minecraft:light_blue_concrete
fill 503 278 337 507 278 341 minecraft:blue_concrete
fill 503 278 342 507 278 346 minecraft:light_blue_concrete
fill 503 278 347 507 278 351 minecraft:blue_concrete
fill 503 278 352 507 278 356 minecraft:light_blue_concrete
fill 503 278 357 507 278 361 minecraft:blue_concrete
fill 503 278 362 507 278 363 minecraft:light_blue_concrete
fill 508 278 323 511 278 326 minecraft:blue_concrete
fill 508 278 327 511 278 331 minecraft:light_blue_concrete
fill 508 278 332 511 278 336 minecraft:blue_concrete
fill 508 278 337 511 278 341 minecraft:light_blue_concrete
fill 508 278 342 511 278 346 minecraft:blue_concrete
fill 508 278 347 511 278 351 minecraft:light_blue_concrete
fill 508 278 352 511 278 356 minecraft:blue_concrete
fill 508 278 357 511 278 361 minecraft:light_blue_concrete
fill 508 278 362 511 278 363 minecraft:blue_concrete
fill 471 279 327 511 279 327 minecraft:yellow_concrete
fill 471 279 328 472 279 331 minecraft:light_blue_concrete
fill 471 279 332 511 279 332 minecraft:yellow_concrete
fill 471 279 333 472 279 336 minecraft:blue_concrete
fill 471 279 337 511 279 337 minecraft:yellow_concrete
fill 471 279 338 472 279 341 minecraft:light_blue_concrete
fill 471 279 342 488 279 342 minecraft:yellow_concrete
fill 471 279 343 472 279 346 minecraft:blue_concrete
fill 471 279 347 511 279 347 minecraft:yellow_concrete
fill 471 279 348 472 279 351 minecraft:light_blue_concrete
fill 471 279 352 511 279 352 minecraft:yellow_concrete
fill 471 279 353 472 279 356 minecraft:blue_concrete
fill 471 279 357 511 279 357 minecraft:yellow_concrete
fill 471 279 358 472 279 361 minecraft:light_blue_concrete
fill 471 279 362 511 279 362 minecraft:yellow_concrete
fill 471 279 363 472 279 363 minecraft:blue_concrete
fill 473 279 323 473 279 326 minecraft:yellow_concrete
fill 473 279 328 473 279 331 minecraft:yellow_concrete
fill 473 279 333 473 279 336 minecraft:yellow_concrete
fill 473 279 338 473 279 341 minecraft:yellow_concrete
fill 473 279 343 473 279 346 minecraft:yellow_concrete
fill 473 279 348 473 279 351 minecraft:yellow_concrete
fill 473 279 353 473 279 356 minecraft:yellow_concrete
fill 473 279 358 473 279 361 minecraft:yellow_concrete
setblock 473 279 363 minecraft:yellow_concrete
fill 474 279 323 477 279 326 minecraft:light_blue_concrete
fill 474 279 328 477 279 331 minecraft:blue_concrete
fill 474 279 333 477 279 336 minecraft:light_blue_concrete
fill 474 279 338 477 279 341 minecraft:blue_concrete
fill 474 279 343 477 279 346 minecraft:light_blue_concrete
fill 474 279 348 477 279 351 minecraft:blue_concrete
fill 474 279 353 477 279 356 minecraft:light_blue_concrete
fill 474 279 358 477 279 361 minecraft:blue_concrete
fill 474 279 363 477 279 363 minecraft:light_blue_concrete
fill 478 279 323 478 279 326 minecraft:yellow_concrete
fill 478 279 328 478 279 331 minecraft:yellow_concrete
fill 478 279 333 478 279 336 minecraft:yellow_concrete
fill 478 279 338 478 279 341 minecraft:yellow_concrete
fill 478 279 343 478 279 346 minecraft:yellow_concrete
fill 478 279 348 478 279 351 minecraft:yellow_concrete
fill 478 279 353 478 279 356 minecraft:yellow_concrete
fill 478 279 358 478 279 361 minecraft:yellow_concrete
setblock 478 279 363 minecraft:yellow_concrete
fill 479 279 323 482 279 326 minecraft:blue_concrete
fill 479 279 328 482 279 331 minecraft:light_blue_concrete
fill 479 279 333 482 279 336 minecraft:blue_concrete
fill 479 279 338 482 279 341 minecraft:light_blue_concrete
fill 479 279 343 482 279 346 minecraft:blue_concrete
fill 479 279 348 482 279 351 minecraft:light_blue_concrete
fill 479 279 353 482 279 356 minecraft:blue_concrete
fill 479 279 358 482 279 361 minecraft:light_blue_concrete
fill 479 279 363 482 279 363 minecraft:blue_concrete
fill 483 279 323 483 279 326 minecraft:yellow_concrete
fill 483 279 328 483 279 331 minecraft:yellow_concrete
fill 483 279 333 483 279 336 minecraft:yellow_concrete
fill 483 279 338 483 279 341 minecraft:yellow_concrete
fill 483 279 343 483 279 346 minecraft:yellow_concrete
fill 483 279 348 483 279 351 minecraft:yellow_concrete
fill 483 279 353 483 279 356 minecraft:yellow_concrete
fill 483 279 358 483 279 361 minecraft:yellow_concrete
setblock 483 279 363 minecraft:yellow_concrete
fill 484 279 323 487 279 326 minecraft:light_blue_concrete
fill 484 279 328 487 279 331 minecraft:blue_concrete
fill 484 279 333 487 279 336 minecraft:light_blue_concrete
fill 484 279 338 487 279 341 minecraft:blue_concrete
fill 484 279 343 487 279 346 minecraft:light_blue_concrete
fill 484 279 348 487 279 351 minecraft:blue_concrete
fill 484 279 353 487 279 356 minecraft:light_blue_concrete
fill 484 279 358 487 279 361 minecraft:blue_concrete
fill 484 279 363 487 279 363 minecraft:light_blue_concrete
fill 488 279 323 488 279 326 minecraft:yellow_concrete
fill 488 279 328 488 279 331 minecraft:yellow_concrete
fill 488 279 333 488 279 336 minecraft:yellow_concrete
fill 488 279 338 488 279 341 minecraft:yellow_concrete
fill 488 279 343 488 279 346 minecraft:yellow_concrete
fill 488 279 348 488 279 351 minecraft:yellow_concrete
fill 488 279 353 488 279 356 minecraft:yellow_concrete
fill 488 279 358 488 279 361 minecraft:yellow_concrete
setblock 488 279 363 minecraft:yellow_concrete
fill 489 279 323 492 279 326 minecraft:blue_concrete
fill 489 279 328 492 279 331 minecraft:light_blue_concrete
fill 489 279 333 492 279 336 minecraft:blue_concrete
fill 489 279 338 489 279 340 minecraft:light_blue_concrete
fill 489 279 341 489 279 343 minecraft:sea_lantern
fill 489 279 344 489 279 346 minecraft:blue_concrete
fill 489 279 348 492 279 351 minecraft:light_blue_concrete
fill 489 279 353 492 279 356 minecraft:blue_concrete
fill 489 279 358 492 279 361 minecraft:light_blue_concrete
fill 489 279 363 492 279 363 minecraft:blue_concrete
fill 490 279 338 491 279 338 minecraft:light_blue_concrete
fill 490 279 339 490 279 341 minecraft:sea_lantern
fill 490 279 343 490 279 345 minecraft:sea_lantern
fill 490 279 346 491 279 346 minecraft:blue_concrete
fill 491 279 339 492 279 339 minecraft:sea_lantern
fill 491 279 345 492 279 345 minecraft:sea_lantern
fill 492 279 338 494 279 338 minecraft:sea_lantern
fill 492 279 346 494 279 346 minecraft:sea_lantern
fill 493 279 323 493 279 326 minecraft:yellow_concrete
fill 493 279 328 493 279 331 minecraft:yellow_concrete
fill 493 279 333 493 279 336 minecraft:yellow_concrete
fill 493 279 348 493 279 351 minecraft:yellow_concrete
fill 493 279 353 493 279 356 minecraft:yellow_concrete
fill 493 279 358 493 279 361 minecraft:yellow_concrete
setblock 493 279 363 minecraft:yellow_concrete
fill 494 279 323 497 279 326 minecraft:light_blue_concrete
fill 494 279 328 497 279 331 minecraft:blue_concrete
fill 494 279 333 497 279 336 minecraft:light_blue_concrete
fill 494 279 339 496 279 339 minecraft:sea_lantern
fill 494 279 345 496 279 345 minecraft:sea_lantern
fill 494 279 348 497 279 351 minecraft:blue_concrete
fill 494 279 353 497 279 356 minecraft:light_blue_concrete
fill 494 279 358 497 279 361 minecraft:blue_concrete
fill 494 279 363 497 279 363 minecraft:light_blue_concrete
fill 495 279 338 497 279 338 minecraft:blue_concrete
fill 495 279 346 497 279 346 minecraft:light_blue_concrete
fill 496 279 340 496 279 341 minecraft:sea_lantern
fill 496 279 343 496 279 344 minecraft:sea_lantern
fill 497 279 339 497 279 340 minecraft:blue_concrete
fill 497 279 341 497 279 343 minecraft:sea_lantern
fill 497 279 344 497 279 345 minecraft:light_blue_concrete
fill 498 279 323 498 279 326 minecraft:yellow_concrete
fill 498 279 328 498 279 331 minecraft:yellow_concrete
fill 498 279 333 498 279 336 minecraft:yellow_concrete
fill 498 279 338 498 279 346 minecraft:yellow_concrete
fill 498 279 348 498 279 351 minecraft:yellow_concrete
fill 498 279 353 498 279 356 minecraft:yellow_concrete
fill 498 279 358 498 279 361 minecraft:yellow_concrete
setblock 498 279 363 minecraft:yellow_concrete
fill 499 279 323 502 279 326 minecraft:blue_concrete
fill 499 279 328 502 279 331 minecraft:light_blue_concrete
fill 499 279 333 502 279 336 minecraft:blue_concrete
fill 499 279 338 502 279 341 minecraft:light_blue_concrete
fill 499 279 342 511 279 342 minecraft:yellow_concrete
fill 499 279 343 502 279 346 minecraft:blue_concrete
fill 499 279 348 502 279 351 minecraft:light_blue_concrete
fill 499 279 353 502 279 356 minecraft:blue_concrete
fill 499 279 358 502 279 361 minecraft:light_blue_concrete
fill 499 279 363 502 279 363 minecraft:blue_concrete
fill 503 279 323 503 279 326 minecraft:yellow_concrete
fill 503 279 328 503 279 331 minecraft:yellow_concrete
fill 503 279 333 503 279 336 minecraft:yellow_concrete
fill 503 279 338 503 279 341 minecraft:yellow_concrete
fill 503 279 343 503 279 346 minecraft:yellow_concrete
fill 503 279 348 503 279 351 minecraft:yellow_concrete
fill 503 279 353 503 279 356 minecraft:yellow_concrete
fill 503 279 358 503 279 361 minecraft:yellow_concrete
setblock 503 279 363 minecraft:yellow_concrete
fill 504 279 323 507 279 326 minecraft:light_blue_concrete
fill 504 279 328 507 279 331 minecraft:blue_concrete
fill 504 279 333 507 279 336 minecraft:light_blue_concrete
fill 504 279 338 507 279 341 minecraft:blue_concrete
fill 504 279 343 507 279 346 minecraft:light_blue_concrete
fill 504 279 348 507 279 351 minecraft:blue_concrete
fill 504 279 353 507 279 356 minecraft:light_blue_concrete
fill 504 279 358 507 279 361 minecraft:blue_concrete
fill 504 279 363 507 279 363 minecraft:light_blue_concrete
fill 508 279 323 508 279 326 minecraft:yellow_concrete
fill 508 279 328 508 279 331 minecraft:yellow_concrete
fill 508 279 333 508 279 336 minecraft:yellow_concrete
fill 508 279 338 508 279 341 minecraft:yellow_concrete
fill 508 279 343 508 279 346 minecraft:yellow_concrete
fill 508 279 348 508 279 351 minecraft:yellow_concrete
fill 508 279 353 508 279 356 minecraft:yellow_concrete
fill 508 279 358 508 279 361 minecraft:yellow_concrete
setblock 508 279 363 minecraft:yellow_concrete
fill 509 279 323 511 279 326 minecraft:blue_concrete
fill 509 279 328 511 279 331 minecraft:light_blue_concrete
fill 509 279 333 511 279 336 minecraft:blue_concrete
fill 509 279 338 511 279 341 minecraft:light_blue_concrete
fill 509 279 343 511 279 346 minecraft:blue_concrete
fill 509 279 348 511 279 351 minecraft:light_blue_concrete
fill 509 279 353 511 279 356 minecraft:blue_concrete
fill 509 279 358 511 279 361 minecraft:light_blue_concrete
fill 509 279 363 511 279 363 minecraft:blue_concrete
fill 471 283 329 471 300 330 minecraft:black_concrete
fill 471 283 337 471 300 338 minecraft:black_concrete
fill 471 283 345 471 300 346 minecraft:black_concrete
fill 471 283 353 471 300 354 minecraft:black_concrete
fill 471 283 361 471 300 362 minecraft:black_concrete
fill 472 283 323 473 300 323 minecraft:black_concrete
fill 477 283 363 478 300 363 minecraft:black_concrete
fill 480 283 323 481 300 323 minecraft:black_concrete
fill 485 283 363 486 300 363 minecraft:black_concrete
fill 488 283 323 489 300 323 minecraft:black_concrete
fill 493 283 363 494 300 363 minecraft:black_concrete
fill 496 283 323 497 300 323 minecraft:black_concrete
fill 501 283 363 502 300 363 minecraft:black_concrete
fill 504 283 323 505 300 323 minecraft:black_concrete
fill 509 283 363 510 300 363 minecraft:black_concrete
fill 511 283 324 511 300 325 minecraft:black_concrete
fill 511 283 332 511 300 333 minecraft:black_concrete
fill 511 283 340 511 300 341 minecraft:black_concrete
fill 511 283 348 511 300 349 minecraft:black_concrete
fill 511 283 356 511 300 357 minecraft:black_concrete
fill 470 284 327 470 289 327 minecraft:sea_lantern
fill 470 284 335 470 289 335 minecraft:sea_lantern
fill 470 284 343 470 289 343 minecraft:sea_lantern
fill 470 284 351 470 289 351 minecraft:sea_lantern
fill 470 284 359 470 289 359 minecraft:sea_lantern
setblock 473 284 325 minecraft:light[level=14]
setblock 473 284 333 minecraft:light[level=14]
setblock 473 284 341 minecraft:light[level=14]
setblock 473 284 349 minecraft:light[level=14]
setblock 473 284 357 minecraft:light[level=14]
fill 473 284 364 473 289 364 minecraft:sea_lantern
fill 477 284 322 477 289 322 minecraft:sea_lantern
setblock 481 284 325 minecraft:light[level=14]
setblock 481 284 333 minecraft:light[level=14]
setblock 481 284 341 minecraft:light[level=14]
setblock 481 284 349 minecraft:light[level=14]
setblock 481 284 357 minecraft:light[level=14]
fill 481 284 364 481 289 364 minecraft:sea_lantern
fill 485 284 322 485 289 322 minecraft:sea_lantern
setblock 489 284 325 minecraft:light[level=14]
setblock 489 284 333 minecraft:light[level=14]
setblock 489 284 341 minecraft:light[level=14]
setblock 489 284 349 minecraft:light[level=14]
setblock 489 284 357 minecraft:light[level=14]
fill 489 284 364 489 289 364 minecraft:sea_lantern
fill 493 284 322 493 289 322 minecraft:sea_lantern
setblock 497 284 325 minecraft:light[level=14]
setblock 497 284 333 minecraft:light[level=14]
setblock 497 284 341 minecraft:light[level=14]
setblock 497 284 349 minecraft:light[level=14]
setblock 497 284 357 minecraft:light[level=14]
fill 497 284 364 497 289 364 minecraft:sea_lantern
fill 501 284 322 501 289 322 minecraft:sea_lantern
setblock 505 284 325 minecraft:light[level=14]
setblock 505 284 333 minecraft:light[level=14]
setblock 505 284 341 minecraft:light[level=14]
setblock 505 284 349 minecraft:light[level=14]
setblock 505 284 357 minecraft:light[level=14]
fill 505 284 364 505 289 364 minecraft:sea_lantern
fill 509 284 322 509 289 322 minecraft:sea_lantern
fill 512 284 327 512 289 327 minecraft:sea_lantern
fill 512 284 335 512 289 335 minecraft:sea_lantern
fill 512 284 343 512 289 343 minecraft:sea_lantern
fill 512 284 351 512 289 351 minecraft:sea_lantern
fill 512 284 359 512 289 359 minecraft:sea_lantern
fill 470 290 327 470 297 327 minecraft:blue_concrete
fill 470 290 335 470 297 335 minecraft:blue_concrete
fill 470 290 343 470 297 343 minecraft:blue_concrete
fill 470 290 351 470 297 351 minecraft:blue_concrete
fill 470 290 359 470 297 359 minecraft:blue_concrete
fill 473 290 364 473 297 364 minecraft:blue_concrete
fill 477 290 322 477 297 322 minecraft:blue_concrete
fill 481 290 364 481 297 364 minecraft:blue_concrete
fill 485 290 322 485 297 322 minecraft:blue_concrete
fill 489 290 364 489 297 364 minecraft:blue_concrete
fill 493 290 322 493 297 322 minecraft:blue_concrete
fill 497 290 364 497 297 364 minecraft:blue_concrete
fill 501 290 322 501 297 322 minecraft:blue_concrete
fill 505 290 364 505 297 364 minecraft:blue_concrete
fill 509 290 322 509 297 322 minecraft:blue_concrete
fill 512 290 327 512 297 327 minecraft:blue_concrete
fill 512 290 335 512 297 335 minecraft:blue_concrete
fill 512 290 343 512 297 343 minecraft:blue_concrete
fill 512 290 351 512 297 351 minecraft:blue_concrete
fill 512 290 359 512 297 359 minecraft:blue_concrete
setblock 473 292 325 minecraft:light[level=14]
setblock 473 292 333 minecraft:light[level=14]
setblock 473 292 341 minecraft:light[level=14]
setblock 473 292 349 minecraft:light[level=14]
setblock 473 292 357 minecraft:light[level=14]
setblock 481 292 325 minecraft:light[level=14]
setblock 481 292 333 minecraft:light[level=14]
setblock 481 292 341 minecraft:light[level=14]
setblock 481 292 349 minecraft:light[level=14]
setblock 481 292 357 minecraft:light[level=14]
setblock 489 292 325 minecraft:light[level=14]
setblock 489 292 333 minecraft:light[level=14]
setblock 489 292 341 minecraft:light[level=14]
setblock 489 292 349 minecraft:light[level=14]
setblock 489 292 357 minecraft:light[level=14]
fill 490 292 360 490 293 362 minecraft:iron_block
setblock 497 292 325 minecraft:light[level=14]
setblock 497 292 333 minecraft:light[level=14]
setblock 497 292 341 minecraft:light[level=14]
setblock 497 292 349 minecraft:light[level=14]
setblock 497 292 357 minecraft:light[level=14]
setblock 505 292 325 minecraft:light[level=14]
setblock 505 292 333 minecraft:light[level=14]
setblock 505 292 341 minecraft:light[level=14]
setblock 505 292 349 minecraft:light[level=14]
setblock 505 292 357 minecraft:light[level=14]
fill 473 293 324 473 293 325 minecraft:iron_block
fill 471 294 323 471 295 328 minecraft:black_concrete
fill 471 294 331 472 294 336 minecraft:black_concrete
fill 471 294 339 472 294 344 minecraft:black_concrete
fill 471 294 347 472 294 352 minecraft:black_concrete
fill 471 294 355 472 294 360 minecraft:black_concrete
fill 471 294 363 476 295 363 minecraft:black_concrete
fill 472 294 324 472 294 330 minecraft:black_concrete
fill 472 294 337 472 294 338 minecraft:black_concrete
fill 472 294 345 472 294 346 minecraft:black_concrete
fill 472 294 353 472 294 354 minecraft:black_concrete
fill 472 294 361 472 294 362 minecraft:black_concrete
fill 473 294 324 510 294 324 minecraft:black_concrete
setblock 473 294 325 minecraft:iron_block
fill 473 294 362 511 294 362 minecraft:black_concrete
fill 474 294 323 479 295 323 minecraft:black_concrete
fill 479 294 363 484 295 363 minecraft:black_concrete
fill 482 294 323 487 295 323 minecraft:black_concrete
fill 487 294 363 492 295 363 minecraft:black_concrete
fill 490 294 323 495 295 323 minecraft:black_concrete
fill 495 294 363 500 295 363 minecraft:black_concrete
fill 498 294 323 503 295 323 minecraft:black_concrete
fill 503 294 363 508 295 363 minecraft:black_concrete
fill 506 294 323 511 295 323 minecraft:black_concrete
fill 510 294 325 510 294 361 minecraft:black_concrete
fill 511 294 326 511 295 331 minecraft:black_concrete
fill 511 294 334 511 295 339 minecraft:black_concrete
fill 511 294 342 511 295 347 minecraft:black_concrete
fill 511 294 350 511 295 355 minecraft:black_concrete
fill 511 294 358 511 295 361 minecraft:black_concrete
fill 511 294 363 511 295 363 minecraft:black_concrete
fill 471 295 331 471 295 336 minecraft:black_concrete
fill 471 295 339 471 295 344 minecraft:black_concrete
fill 471 295 347 471 295 352 minecraft:black_concrete
fill 471 295 355 471 295 360 minecraft:black_concrete
setblock 511 295 362 minecraft:black_concrete
fill 470 298 327 470 300 327 minecraft:sea_lantern
fill 470 298 335 470 300 335 minecraft:sea_lantern
fill 470 298 343 470 300 343 minecraft:sea_lantern
fill 470 298 351 470 300 351 minecraft:sea_lantern
fill 470 298 359 470 300 359 minecraft:sea_lantern
fill 473 298 364 473 300 364 minecraft:sea_lantern
fill 477 298 322 477 300 322 minecraft:sea_lantern
fill 481 298 364 481 300 364 minecraft:sea_lantern
fill 485 298 322 485 300 322 minecraft:sea_lantern
fill 489 298 364 489 300 364 minecraft:sea_lantern
fill 493 298 322 493 300 322 minecraft:sea_lantern
fill 497 298 364 497 300 364 minecraft:sea_lantern
fill 501 298 322 501 300 322 minecraft:sea_lantern
fill 505 298 364 505 300 364 minecraft:sea_lantern
fill 509 298 322 509 300 322 minecraft:sea_lantern
fill 512 298 327 512 300 327 minecraft:sea_lantern
fill 512 298 335 512 300 335 minecraft:sea_lantern
fill 512 298 343 512 300 343 minecraft:sea_lantern
fill 512 298 351 512 300 351 minecraft:sea_lantern
fill 512 298 359 512 300 359 minecraft:sea_lantern
setblock 473 300 325 minecraft:light[level=14]
setblock 473 300 333 minecraft:light[level=14]
setblock 473 300 341 minecraft:light[level=14]
setblock 473 300 349 minecraft:light[level=14]
setblock 473 300 357 minecraft:light[level=14]
setblock 481 300 325 minecraft:light[level=14]
setblock 481 300 333 minecraft:light[level=14]
setblock 481 300 341 minecraft:light[level=14]
setblock 481 300 349 minecraft:light[level=14]
setblock 481 300 357 minecraft:light[level=14]
setblock 489 300 325 minecraft:light[level=14]
setblock 489 300 333 minecraft:light[level=14]
setblock 489 300 341 minecraft:light[level=14]
setblock 489 300 349 minecraft:light[level=14]
setblock 489 300 357 minecraft:light[level=14]
setblock 497 300 325 minecraft:light[level=14]
setblock 497 300 333 minecraft:light[level=14]
setblock 497 300 341 minecraft:light[level=14]
setblock 497 300 349 minecraft:light[level=14]
setblock 497 300 357 minecraft:light[level=14]
setblock 505 300 325 minecraft:light[level=14]
setblock 505 300 333 minecraft:light[level=14]
setblock 505 300 341 minecraft:light[level=14]
setblock 505 300 349 minecraft:light[level=14]
setblock 505 300 357 minecraft:light[level=14]
fill 470 301 327 470 307 327 minecraft:blue_concrete
fill 470 301 335 470 307 335 minecraft:blue_concrete
fill 470 301 343 470 307 343 minecraft:blue_concrete
fill 470 301 351 470 307 351 minecraft:blue_concrete
fill 470 301 359 470 307 359 minecraft:blue_concrete
fill 473 301 364 473 307 364 minecraft:blue_concrete
fill 477 301 322 477 307 322 minecraft:blue_concrete
fill 481 301 364 481 307 364 minecraft:blue_concrete
fill 485 301 322 485 307 322 minecraft:blue_concrete
fill 489 301 364 489 307 364 minecraft:blue_concrete
fill 493 301 322 493 307 322 minecraft:blue_concrete
fill 497 301 364 497 307 364 minecraft:blue_concrete
fill 501 301 322 501 307 322 minecraft:blue_concrete
fill 505 301 364 505 307 364 minecraft:blue_concrete
fill 509 301 322 509 307 322 minecraft:blue_concrete
fill 512 301 327 512 307 327 minecraft:blue_concrete
fill 512 301 335 512 307 335 minecraft:blue_concrete
fill 512 301 343 512 307 343 minecraft:blue_concrete
fill 512 301 351 512 307 351 minecraft:blue_concrete
fill 512 301 359 512 307 359 minecraft:blue_concrete
