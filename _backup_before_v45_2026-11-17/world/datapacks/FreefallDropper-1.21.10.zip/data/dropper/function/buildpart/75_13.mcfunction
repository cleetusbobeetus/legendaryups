setblock 173 269 323 minecraft:purple_concrete
fill 173 269 334 174 269 334 minecraft:purple_concrete
fill 174 269 335 179 269 335 minecraft:purple_concrete
fill 175 269 336 178 269 336 minecraft:purple_concrete
setblock 176 269 325 minecraft:light[level=13]
setblock 176 269 341 minecraft:light[level=13]
setblock 176 269 349 minecraft:light[level=13]
setblock 176 269 357 minecraft:light[level=13]
fill 178 269 334 179 270 334 minecraft:purple_concrete
setblock 179 269 325 minecraft:light[level=12]
setblock 179 269 339 minecraft:light[level=12]
setblock 179 269 346 minecraft:light[level=12]
setblock 179 269 353 minecraft:light[level=12]
setblock 179 269 360 minecraft:light[level=12]
setblock 180 269 323 minecraft:dark_prismarine
fill 180 269 324 180 272 324 minecraft:blue_terracotta
setblock 180 269 343 minecraft:dark_prismarine
setblock 180 269 344 minecraft:blue_terracotta
setblock 180 269 363 minecraft:dark_prismarine
fill 181 269 323 181 272 323 minecraft:blue_terracotta
fill 181 269 325 181 269 326 minecraft:blue_terracotta
setblock 181 269 327 minecraft:dark_prismarine
fill 181 269 328 181 271 329 minecraft:blue_terracotta
setblock 181 269 337 minecraft:dark_prismarine
fill 181 269 338 181 271 338 minecraft:blue_terracotta
setblock 181 269 342 minecraft:dark_prismarine
fill 181 269 343 181 272 343 minecraft:blue_terracotta
setblock 181 269 347 minecraft:dark_prismarine
fill 181 269 363 181 272 363 minecraft:blue_terracotta
setblock 182 269 325 minecraft:blue_terracotta
setblock 182 269 326 minecraft:dark_prismarine
fill 182 269 327 182 272 327 minecraft:blue_terracotta
setblock 182 269 331 minecraft:dark_prismarine
fill 182 269 332 182 272 332 minecraft:blue_terracotta
setblock 182 269 336 minecraft:dark_prismarine
fill 182 269 337 182 272 337 minecraft:blue_terracotta
setblock 182 269 341 minecraft:dark_prismarine
fill 182 269 342 182 272 342 minecraft:blue_terracotta
setblock 182 269 346 minecraft:dark_prismarine
fill 182 269 347 182 272 347 minecraft:blue_terracotta
setblock 182 269 358 minecraft:purple_concrete
setblock 182 269 361 minecraft:dark_prismarine
fill 182 269 362 182 272 362 minecraft:blue_terracotta
fill 183 269 347 183 275 348 minecraft:blue_concrete
setblock 183 269 349 minecraft:cyan_concrete
fill 142 270 323 143 270 323 minecraft:blue_terracotta
setblock 142 270 325 minecraft:dark_prismarine
fill 142 270 326 142 272 326 minecraft:blue_terracotta
setblock 142 270 330 minecraft:dark_prismarine
fill 142 270 331 142 272 331 minecraft:blue_terracotta
setblock 142 270 335 minecraft:dark_prismarine
fill 142 270 336 142 271 336 minecraft:blue_terracotta
setblock 142 270 340 minecraft:dark_prismarine
setblock 142 270 341 minecraft:blue_terracotta
setblock 142 270 345 minecraft:dark_prismarine
fill 142 270 346 142 272 346 minecraft:blue_terracotta
setblock 142 270 353 minecraft:purple_concrete
setblock 142 270 360 minecraft:dark_prismarine
fill 142 270 361 142 272 361 minecraft:blue_terracotta
setblock 143 270 324 minecraft:dark_prismarine
fill 143 270 325 143 272 325 minecraft:blue_terracotta
setblock 143 270 329 minecraft:dark_prismarine
fill 143 270 330 143 272 330 minecraft:blue_terracotta
fill 143 270 336 143 270 339 minecraft:dark_prismarine
setblock 143 270 340 minecraft:blue_terracotta
setblock 143 270 344 minecraft:dark_prismarine
fill 143 270 345 143 272 345 minecraft:blue_terracotta
fill 143 270 347 143 271 347 minecraft:blue_terracotta
fill 143 270 360 143 271 360 minecraft:blue_terracotta
setblock 144 270 323 minecraft:dark_prismarine
fill 144 270 324 144 272 324 minecraft:blue_terracotta
setblock 144 270 328 minecraft:dark_prismarine
setblock 144 270 345 minecraft:dark_prismarine
setblock 144 270 363 minecraft:dark_prismarine
fill 145 270 323 145 272 323 minecraft:blue_terracotta
setblock 145 270 362 minecraft:dark_prismarine
fill 145 270 363 145 272 363 minecraft:blue_terracotta
setblock 146 270 361 minecraft:dark_prismarine
fill 146 270 362 146 272 362 minecraft:blue_terracotta
setblock 147 270 325 minecraft:dark_prismarine
setblock 147 270 361 minecraft:blue_terracotta
setblock 148 270 324 minecraft:dark_prismarine
fill 148 270 325 148 271 325 minecraft:blue_terracotta
setblock 149 270 323 minecraft:dark_prismarine
fill 149 270 324 149 272 324 minecraft:blue_terracotta
setblock 149 270 363 minecraft:dark_prismarine
fill 150 270 323 150 272 323 minecraft:blue_terracotta
setblock 150 270 362 minecraft:dark_prismarine
fill 150 270 363 153 270 363 minecraft:blue_terracotta
fill 151 270 362 152 270 362 minecraft:blue_terracotta
setblock 154 270 323 minecraft:dark_prismarine
setblock 154 270 363 minecraft:dark_prismarine
fill 155 270 323 158 270 323 minecraft:blue_terracotta
fill 155 270 363 155 272 363 minecraft:blue_terracotta
setblock 159 270 323 minecraft:dark_prismarine
setblock 159 270 363 minecraft:dark_prismarine
fill 160 270 323 160 272 323 minecraft:blue_terracotta
setblock 160 270 362 minecraft:dark_prismarine
fill 160 270 363 160 272 363 minecraft:blue_terracotta
fill 161 270 362 161 272 362 minecraft:blue_terracotta
setblock 163 270 324 minecraft:dark_prismarine
setblock 164 270 323 minecraft:dark_prismarine
fill 164 270 324 164 272 324 minecraft:blue_terracotta
setblock 164 270 363 minecraft:dark_prismarine
fill 165 270 323 165 272 323 minecraft:blue_terracotta
setblock 165 270 362 minecraft:dark_prismarine
fill 165 270 363 165 272 363 minecraft:blue_terracotta
fill 166 270 362 166 271 362 minecraft:blue_terracotta
setblock 169 270 323 minecraft:dark_prismarine
fill 169 270 359 169 277 359 minecraft:magenta_terracotta
setblock 169 270 363 minecraft:dark_prismarine
setblock 170 270 323 minecraft:blue_terracotta
setblock 170 270 363 minecraft:blue_terracotta
setblock 174 270 334 minecraft:purple_concrete
fill 175 270 335 178 270 335 minecraft:purple_concrete
fill 176 270 336 177 270 336 minecraft:purple_concrete
setblock 176 270 363 minecraft:purple_concrete
setblock 179 270 323 minecraft:dark_prismarine
fill 179 270 324 179 272 324 minecraft:blue_terracotta
fill 180 270 323 180 272 323 minecraft:blue_terracotta
setblock 180 270 342 minecraft:dark_prismarine
setblock 180 270 343 minecraft:blue_terracotta
fill 180 270 363 180 272 363 minecraft:blue_terracotta
setblock 181 270 325 minecraft:blue_terracotta
setblock 181 270 326 minecraft:dark_prismarine
fill 181 270 327 181 272 327 minecraft:blue_terracotta
setblock 181 270 330 minecraft:blue_terracotta
setblock 181 270 331 minecraft:dark_prismarine
setblock 181 270 336 minecraft:dark_prismarine
fill 181 270 337 181 271 337 minecraft:blue_terracotta
setblock 181 270 341 minecraft:dark_prismarine
fill 181 270 342 181 272 342 minecraft:blue_terracotta
setblock 181 270 346 minecraft:dark_prismarine
fill 181 270 347 181 272 347 minecraft:blue_terracotta
setblock 182 270 325 minecraft:dark_prismarine
fill 182 270 326 182 272 326 minecraft:blue_terracotta
setblock 182 270 330 minecraft:dark_prismarine
fill 182 270 331 182 272 331 minecraft:blue_terracotta
setblock 182 270 335 minecraft:dark_prismarine
fill 182 270 336 182 272 336 minecraft:blue_terracotta
setblock 182 270 340 minecraft:dark_prismarine
fill 182 270 341 182 272 341 minecraft:blue_terracotta
setblock 182 270 345 minecraft:dark_prismarine
fill 182 270 346 182 272 346 minecraft:blue_terracotta
setblock 182 270 349 minecraft:blue_terracotta
setblock 182 270 350 minecraft:dark_prismarine
setblock 182 270 352 minecraft:purple_concrete
fill 182 270 361 182 271 361 minecraft:blue_terracotta
fill 183 270 349 183 308 349 minecraft:blue_concrete
fill 141 271 333 141 308 333 minecraft:blue_concrete
setblock 141 271 334 minecraft:cyan_concrete
fill 141 271 335 141 298 335 minecraft:blue_concrete
setblock 142 271 323 minecraft:blue_terracotta
setblock 142 271 324 minecraft:dark_prismarine
fill 142 271 325 142 272 325 minecraft:blue_terracotta
setblock 142 271 329 minecraft:dark_prismarine
fill 142 271 330 142 272 330 minecraft:blue_terracotta
setblock 142 271 334 minecraft:dark_prismarine
setblock 142 271 335 minecraft:sea_lantern
setblock 142 271 337 minecraft:sea_lantern
setblock 142 271 339 minecraft:sea_lantern
fill 142 271 340 142 272 340 minecraft:blue_terracotta
setblock 142 271 341 minecraft:sea_lantern
fill 142 271 342 142 272 342 minecraft:blue_terracotta
setblock 142 271 343 minecraft:sea_lantern
setblock 142 271 344 minecraft:dark_prismarine
setblock 142 271 345 minecraft:sea_lantern
setblock 142 271 349 minecraft:dark_prismarine
fill 142 271 350 142 272 350 minecraft:blue_terracotta
setblock 142 271 359 minecraft:dark_prismarine
fill 142 271 360 142 272 360 minecraft:blue_terracotta
setblock 143 271 323 minecraft:dark_prismarine
fill 143 271 324 143 272 324 minecraft:blue_terracotta
setblock 143 271 328 minecraft:dark_prismarine
fill 143 271 329 143 272 329 minecraft:blue_terracotta
fill 143 271 335 143 272 335 minecraft:dark_prismarine
setblock 143 271 336 minecraft:sea_lantern
fill 143 271 337 143 272 337 minecraft:dark_prismarine
setblock 143 271 338 minecraft:sea_lantern
fill 143 271 339 143 272 339 minecraft:dark_prismarine
setblock 143 271 340 minecraft:sea_lantern
fill 143 271 341 143 272 341 minecraft:dark_prismarine
setblock 143 271 342 minecraft:sea_lantern
fill 143 271 343 143 272 343 minecraft:dark_prismarine
setblock 143 271 344 minecraft:sea_lantern
setblock 143 271 363 minecraft:dark_prismarine
fill 144 271 323 144 272 323 minecraft:blue_terracotta
setblock 144 271 327 minecraft:dark_prismarine
fill 144 271 328 144 272 328 minecraft:blue_terracotta
setblock 144 271 335 minecraft:sea_lantern
setblock 144 271 337 minecraft:sea_lantern
setblock 144 271 339 minecraft:sea_lantern
setblock 144 271 341 minecraft:sea_lantern
fill 144 271 342 144 272 342 minecraft:dark_prismarine
setblock 144 271 343 minecraft:sea_lantern
setblock 144 271 345 minecraft:sea_lantern
setblock 144 271 362 minecraft:dark_prismarine
fill 144 271 363 144 272 363 minecraft:blue_terracotta
setblock 145 271 336 minecraft:sea_lantern
setblock 145 271 338 minecraft:sea_lantern
setblock 145 271 340 minecraft:sea_lantern
setblock 145 271 342 minecraft:sea_lantern
setblock 145 271 344 minecraft:sea_lantern
fill 145 271 362 145 272 362 minecraft:blue_terracotta
setblock 146 271 325 minecraft:dark_prismarine
setblock 146 271 335 minecraft:sea_lantern
setblock 146 271 337 minecraft:sea_lantern
setblock 146 271 339 minecraft:sea_lantern
setblock 146 271 341 minecraft:sea_lantern
setblock 146 271 343 minecraft:sea_lantern
setblock 146 271 345 minecraft:sea_lantern
setblock 147 271 324 minecraft:dark_prismarine
fill 147 271 325 147 272 325 minecraft:blue_terracotta
setblock 147 271 336 minecraft:sea_lantern
setblock 147 271 338 minecraft:sea_lantern
setblock 147 271 340 minecraft:sea_lantern
setblock 147 271 342 minecraft:sea_lantern
setblock 147 271 344 minecraft:sea_lantern
setblock 148 271 323 minecraft:dark_prismarine
fill 148 271 324 148 272 324 minecraft:blue_terracotta
setblock 148 271 335 minecraft:sea_lantern
setblock 148 271 337 minecraft:sea_lantern
setblock 148 271 339 minecraft:sea_lantern
setblock 148 271 341 minecraft:sea_lantern
setblock 148 271 343 minecraft:sea_lantern
setblock 148 271 345 minecraft:sea_lantern
setblock 148 271 363 minecraft:dark_prismarine
fill 149 271 323 149 272 323 minecraft:blue_terracotta
setblock 149 271 336 minecraft:sea_lantern
setblock 149 271 338 minecraft:sea_lantern
setblock 149 271 340 minecraft:sea_lantern
setblock 149 271 342 minecraft:sea_lantern
setblock 149 271 344 minecraft:sea_lantern
setblock 149 271 362 minecraft:dark_prismarine
fill 149 271 363 152 271 363 minecraft:blue_terracotta
setblock 150 271 362 minecraft:blue_terracotta
setblock 153 271 323 minecraft:dark_prismarine
setblock 153 271 363 minecraft:dark_prismarine
fill 154 271 323 157 271 323 minecraft:blue_terracotta
fill 154 271 363 154 272 363 minecraft:blue_terracotta
setblock 158 271 323 minecraft:dark_prismarine
setblock 158 271 363 minecraft:dark_prismarine
fill 159 271 323 159 272 323 minecraft:blue_terracotta
setblock 159 271 362 minecraft:dark_prismarine
fill 159 271 363 159 272 363 minecraft:blue_terracotta
fill 160 271 362 160 272 362 minecraft:blue_terracotta
setblock 162 271 324 minecraft:dark_prismarine
setblock 163 271 323 minecraft:dark_prismarine
fill 163 271 324 163 272 324 minecraft:blue_terracotta
setblock 163 271 363 minecraft:dark_prismarine
fill 164 271 323 164 272 323 minecraft:blue_terracotta
setblock 164 271 362 minecraft:dark_prismarine
fill 164 271 363 164 272 363 minecraft:blue_terracotta
setblock 165 271 362 minecraft:blue_terracotta
setblock 168 271 323 minecraft:dark_prismarine
setblock 168 271 363 minecraft:dark_prismarine
setblock 169 271 323 minecraft:blue_terracotta
setblock 169 271 363 minecraft:blue_terracotta
fill 175 271 335 177 271 335 minecraft:purple_concrete
setblock 178 271 323 minecraft:dark_prismarine
setblock 178 271 334 minecraft:purple_concrete
fill 179 271 323 179 272 323 minecraft:blue_terracotta
setblock 181 271 325 minecraft:dark_prismarine
fill 181 271 326 181 272 326 minecraft:blue_terracotta
setblock 181 271 330 minecraft:dark_prismarine
fill 181 271 331 181 272 331 minecraft:blue_terracotta
setblock 181 271 340 minecraft:dark_prismarine
fill 181 271 341 181 272 341 minecraft:blue_terracotta
setblock 181 271 345 minecraft:dark_prismarine
fill 181 271 346 181 272 346 minecraft:blue_terracotta
fill 181 271 348 181 272 348 minecraft:blue_terracotta
setblock 182 271 324 minecraft:dark_prismarine
fill 182 271 325 182 272 325 minecraft:blue_terracotta
setblock 182 271 329 minecraft:dark_prismarine
fill 182 271 330 182 272 330 minecraft:blue_terracotta
setblock 182 271 334 minecraft:dark_prismarine
fill 182 271 335 182 272 335 minecraft:blue_terracotta
setblock 182 271 339 minecraft:dark_prismarine
fill 182 271 340 182 272 340 minecraft:blue_terracotta
setblock 182 271 344 minecraft:dark_prismarine
fill 182 271 345 182 272 345 minecraft:blue_terracotta
setblock 182 271 349 minecraft:dark_prismarine
fill 182 271 350 182 272 350 minecraft:blue_terracotta
fill 141 272 334 141 308 334 minecraft:blue_concrete
setblock 142 272 323 minecraft:dark_prismarine
setblock 142 272 324 minecraft:blue_terracotta
setblock 142 272 328 minecraft:dark_prismarine
setblock 142 272 329 minecraft:blue_terracotta
setblock 142 272 333 minecraft:dark_prismarine
fill 142 272 334 142 272 335 minecraft:blue_terracotta
fill 142 272 336 142 272 338 minecraft:dark_prismarine
setblock 142 272 339 minecraft:blue_terracotta
setblock 142 272 341 minecraft:blue_terracotta
setblock 142 272 343 minecraft:dark_prismarine
fill 142 272 344 142 272 345 minecraft:blue_terracotta
setblock 142 272 348 minecraft:dark_prismarine
setblock 142 272 349 minecraft:blue_terracotta
setblock 142 272 351 minecraft:blue_terracotta
setblock 142 272 359 minecraft:blue_terracotta
setblock 142 272 363 minecraft:dark_prismarine
setblock 143 272 323 minecraft:blue_terracotta
setblock 143 272 327 minecraft:dark_prismarine
setblock 143 272 328 minecraft:blue_terracotta
setblock 143 272 336 minecraft:dark_prismarine
setblock 143 272 338 minecraft:dark_prismarine
setblock 143 272 340 minecraft:dark_prismarine
setblock 143 272 342 minecraft:dark_prismarine
setblock 143 272 344 minecraft:blue_terracotta
setblock 143 272 347 minecraft:dark_prismarine
setblock 143 272 362 minecraft:dark_prismarine
setblock 143 272 363 minecraft:blue_terracotta
setblock 144 272 326 minecraft:dark_prismarine
setblock 144 272 327 minecraft:blue_terracotta
setblock 144 272 335 minecraft:dark_prismarine
setblock 144 272 337 minecraft:dark_prismarine
setblock 144 272 339 minecraft:dark_prismarine
setblock 144 272 341 minecraft:dark_prismarine
setblock 144 272 343 minecraft:dark_prismarine
setblock 144 272 345 minecraft:dark_prismarine
setblock 144 272 362 minecraft:blue_terracotta
setblock 145 272 325 minecraft:dark_prismarine
setblock 145 272 336 minecraft:dark_prismarine
setblock 145 272 338 minecraft:dark_prismarine
setblock 145 272 340 minecraft:dark_prismarine
setblock 145 272 342 minecraft:dark_prismarine
setblock 145 272 344 minecraft:dark_prismarine
setblock 146 272 324 minecraft:dark_prismarine
setblock 146 272 325 minecraft:blue_terracotta
setblock 146 272 335 minecraft:dark_prismarine
setblock 146 272 337 minecraft:dark_prismarine
setblock 146 272 339 minecraft:dark_prismarine
setblock 146 272 341 minecraft:dark_prismarine
setblock 146 272 343 minecraft:dark_prismarine
setblock 146 272 345 minecraft:dark_prismarine
setblock 147 272 323 minecraft:dark_prismarine
setblock 147 272 324 minecraft:blue_terracotta
setblock 147 272 336 minecraft:dark_prismarine
setblock 147 272 338 minecraft:dark_prismarine
setblock 147 272 340 minecraft:dark_prismarine
setblock 147 272 342 minecraft:dark_prismarine
setblock 147 272 344 minecraft:dark_prismarine
setblock 147 272 363 minecraft:dark_prismarine
setblock 148 272 323 minecraft:blue_terracotta
setblock 148 272 335 minecraft:dark_prismarine
setblock 148 272 337 minecraft:dark_prismarine
setblock 148 272 339 minecraft:dark_prismarine
setblock 148 272 341 minecraft:dark_prismarine
fill 148 272 343 148 277 343 minecraft:magenta_terracotta
setblock 148 272 345 minecraft:dark_prismarine
setblock 148 272 362 minecraft:dark_prismarine
fill 148 272 363 151 272 363 minecraft:blue_terracotta
setblock 149 272 336 minecraft:dark_prismarine
setblock 149 272 338 minecraft:dark_prismarine
setblock 149 272 340 minecraft:dark_prismarine
setblock 149 272 342 minecraft:dark_prismarine
setblock 149 272 344 minecraft:dark_prismarine
setblock 152 272 323 minecraft:dark_prismarine
setblock 152 272 363 minecraft:dark_prismarine
fill 153 272 323 156 272 323 minecraft:blue_terracotta
setblock 153 272 363 minecraft:blue_terracotta
setblock 157 272 323 minecraft:dark_prismarine
setblock 157 272 363 minecraft:dark_prismarine
setblock 158 272 323 minecraft:blue_terracotta
setblock 158 272 363 minecraft:blue_terracotta
setblock 161 272 323 minecraft:blue_terracotta
setblock 161 272 324 minecraft:dark_prismarine
setblock 162 272 323 minecraft:dark_prismarine
setblock 162 272 324 minecraft:blue_terracotta
setblock 162 272 363 minecraft:dark_prismarine
setblock 163 272 323 minecraft:blue_terracotta
setblock 163 272 362 minecraft:dark_prismarine
setblock 163 272 363 minecraft:blue_terracotta
setblock 164 272 362 minecraft:blue_terracotta
setblock 167 272 323 minecraft:dark_prismarine
setblock 167 272 363 minecraft:dark_prismarine
setblock 168 272 323 minecraft:blue_terracotta
setblock 169 272 363 minecraft:purple_concrete
setblock 177 272 323 minecraft:dark_prismarine
setblock 178 272 323 minecraft:blue_terracotta
setblock 180 272 325 minecraft:dark_prismarine
setblock 181 272 324 minecraft:dark_prismarine
setblock 181 272 325 minecraft:blue_terracotta
setblock 181 272 328 minecraft:blue_terracotta
setblock 181 272 329 minecraft:dark_prismarine
setblock 181 272 330 minecraft:blue_terracotta
setblock 181 272 332 minecraft:blue_terracotta
setblock 181 272 339 minecraft:dark_prismarine
setblock 181 272 340 minecraft:blue_terracotta
setblock 181 272 344 minecraft:dark_prismarine
setblock 181 272 345 minecraft:blue_terracotta
setblock 182 272 323 minecraft:dark_prismarine
setblock 182 272 324 minecraft:blue_terracotta
setblock 182 272 328 minecraft:dark_prismarine
setblock 182 272 329 minecraft:blue_terracotta
setblock 182 272 333 minecraft:dark_prismarine
setblock 182 272 334 minecraft:blue_terracotta
setblock 182 272 338 minecraft:dark_prismarine
setblock 182 272 339 minecraft:blue_terracotta
setblock 182 272 343 minecraft:dark_prismarine
setblock 182 272 344 minecraft:blue_terracotta
setblock 182 272 348 minecraft:dark_prismarine
setblock 182 272 349 minecraft:blue_terracotta
setblock 182 272 351 minecraft:blue_terracotta
setblock 182 272 363 minecraft:dark_prismarine
setblock 183 272 352 minecraft:light_blue_wool
setblock 141 273 349 minecraft:light_blue_wool
fill 141 273 350 141 287 354 minecraft:blue_concrete
setblock 153 273 322 minecraft:cyan_concrete
fill 154 273 322 154 295 322 minecraft:blue_concrete
fill 183 273 352 183 308 352 minecraft:blue_concrete
fill 141 274 349 141 308 349 minecraft:blue_concrete
fill 153 274 322 153 300 322 minecraft:blue_concrete
fill 155 274 327 155 277 327 minecraft:magenta_terracotta
setblock 141 275 356 minecraft:cyan_concrete
setblock 144 275 325 minecraft:light[level=12]
setblock 144 275 332 minecraft:light[level=12]
setblock 144 275 339 minecraft:light[level=12]
setblock 144 275 346 minecraft:light[level=12]
setblock 144 275 353 minecraft:light[level=12]
setblock 144 275 360 minecraft:light[level=12]
setblock 151 275 325 minecraft:light[level=12]
setblock 151 275 332 minecraft:light[level=12]
setblock 151 275 339 minecraft:light[level=12]
setblock 151 275 346 minecraft:light[level=12]
setblock 151 275 353 minecraft:light[level=12]
setblock 151 275 360 minecraft:light[level=12]
setblock 158 275 325 minecraft:light[level=12]
setblock 158 275 332 minecraft:light[level=12]
setblock 158 275 339 minecraft:light[level=12]
setblock 158 275 346 minecraft:light[level=12]
setblock 158 275 353 minecraft:light[level=12]
setblock 158 275 360 minecraft:light[level=12]
setblock 165 275 325 minecraft:light[level=12]
setblock 165 275 332 minecraft:light[level=12]
setblock 165 275 339 minecraft:light[level=12]
setblock 165 275 346 minecraft:light[level=12]
setblock 165 275 353 minecraft:light[level=12]
setblock 165 275 360 minecraft:light[level=12]
setblock 172 275 325 minecraft:light[level=12]
setblock 172 275 332 minecraft:light[level=12]
setblock 172 275 339 minecraft:light[level=12]
setblock 172 275 346 minecraft:light[level=12]
setblock 172 275 353 minecraft:light[level=12]
setblock 172 275 360 minecraft:light[level=12]
setblock 179 275 325 minecraft:light[level=12]
setblock 179 275 332 minecraft:light[level=12]
setblock 179 275 339 minecraft:light[level=12]
setblock 179 275 346 minecraft:light[level=12]
setblock 179 275 353 minecraft:light[level=12]
setblock 179 275 360 minecraft:light[level=12]
fill 141 276 356 141 308 356 minecraft:blue_concrete
fill 148 276 342 148 277 342 minecraft:magenta_terracotta
setblock 183 276 325 minecraft:cyan_concrete
setblock 183 276 347 minecraft:cyan_concrete
fill 183 276 348 183 308 348 minecraft:blue_concrete
setblock 144 277 325 minecraft:light[level=13]
setblock 144 277 333 minecraft:light[level=13]
setblock 144 277 341 minecraft:light[level=13]
setblock 144 277 349 minecraft:light[level=13]
setblock 144 277 357 minecraft:light[level=13]
setblock 152 277 325 minecraft:light[level=13]
setblock 152 277 333 minecraft:light[level=13]
setblock 152 277 341 minecraft:light[level=13]
setblock 152 277 349 minecraft:light[level=13]
setblock 152 277 357 minecraft:light[level=13]
setblock 160 277 325 minecraft:light[level=13]
setblock 160 277 333 minecraft:light[level=13]
setblock 160 277 349 minecraft:light[level=13]
setblock 160 277 357 minecraft:light[level=13]
setblock 168 277 325 minecraft:light[level=13]
setblock 168 277 333 minecraft:light[level=13]
setblock 168 277 341 minecraft:light[level=13]
setblock 168 277 349 minecraft:light[level=13]
setblock 168 277 357 minecraft:light[level=13]
setblock 176 277 325 minecraft:light[level=13]
setblock 176 277 333 minecraft:light[level=13]
setblock 176 277 341 minecraft:light[level=13]
setblock 176 277 349 minecraft:light[level=13]
setblock 176 277 357 minecraft:light[level=13]
fill 183 277 325 183 308 325 minecraft:blue_concrete
fill 183 277 347 183 308 347 minecraft:blue_concrete
fill 142 278 323 144 279 363 minecraft:spruce_planks
fill 145 278 323 145 279 363 minecraft:dark_oak_planks
fill 146 278 323 148 279 363 minecraft:spruce_planks
fill 149 278 323 149 279 363 minecraft:dark_oak_planks
fill 150 278 323 152 278 363 minecraft:spruce_planks
fill 153 278 323 153 278 363 minecraft:dark_oak_planks
fill 154 278 323 156 278 363 minecraft:spruce_planks
fill 157 278 323 157 278 343 minecraft:dark_oak_planks
fill 157 278 345 157 278 363 minecraft:dark_oak_planks
fill 158 278 323 159 278 341 minecraft:spruce_planks
fill 158 278 347 159 278 363 minecraft:spruce_planks
fill 160 278 323 160 278 340 minecraft:spruce_planks
fill 160 278 348 160 278 363 minecraft:spruce_planks
fill 161 278 323 161 278 341 minecraft:dark_oak_planks
fill 161 278 347 161 278 363 minecraft:dark_oak_planks
fill 162 278 323 164 278 341 minecraft:spruce_planks
fill 162 278 347 164 278 363 minecraft:spruce_planks
fill 163 278 342 164 278 343 minecraft:spruce_planks
fill 163 278 345 164 278 346 minecraft:spruce_planks
setblock 164 278 344 minecraft:spruce_planks
fill 165 278 323 165 279 363 minecraft:dark_oak_planks
fill 166 278 323 168 279 363 minecraft:spruce_planks
fill 169 278 323 169 278 363 minecraft:dark_oak_planks
fill 170 278 323 172 278 363 minecraft:spruce_planks
fill 173 278 323 173 278 363 minecraft:dark_oak_planks
fill 174 278 323 176 278 363 minecraft:spruce_planks
fill 177 278 323 177 278 363 minecraft:dark_oak_planks
fill 178 278 323 180 278 363 minecraft:spruce_planks
fill 181 278 323 181 278 363 minecraft:dark_oak_planks
fill 182 278 323 182 279 363 minecraft:spruce_planks
fill 150 279 323 151 279 363 minecraft:spruce_planks
fill 152 279 323 152 279 356 minecraft:spruce_planks
fill 152 279 357 153 281 359 minecraft:magenta_terracotta
fill 152 279 360 152 279 363 minecraft:spruce_planks
fill 153 279 323 153 279 326 minecraft:dark_oak_planks
fill 153 279 327 154 281 328 minecraft:magenta_terracotta
fill 153 279 329 153 279 348 minecraft:dark_oak_planks
fill 153 279 349 154 281 356 minecraft:magenta_terracotta
fill 153 279 360 153 279 363 minecraft:dark_oak_planks
fill 154 279 323 156 279 326 minecraft:spruce_planks
fill 154 279 329 157 281 329 minecraft:magenta_terracotta
fill 154 279 330 154 279 346 minecraft:spruce_planks
fill 154 279 347 155 281 348 minecraft:magenta_terracotta
fill 154 279 357 154 281 358 minecraft:magenta_terracotta
fill 154 279 359 156 279 363 minecraft:spruce_planks
fill 155 279 327 156 279 327 minecraft:spruce_planks
fill 155 279 328 155 291 328 minecraft:magenta_terracotta
fill 155 279 330 158 281 330 minecraft:magenta_terracotta
fill 155 279 331 155 279 346 minecraft:spruce_planks
fill 155 279 349 155 281 350 minecraft:magenta_terracotta
fill 155 279 351 156 279 358 minecraft:spruce_planks
setblock 156 279 328 minecraft:spruce_planks
fill 156 279 331 156 279 342 minecraft:spruce_planks
fill 156 279 343 156 279 345 minecraft:ochre_froglight
fill 156 279 346 156 279 350 minecraft:spruce_planks
fill 157 279 323 157 279 328 minecraft:dark_oak_planks
fill 157 279 331 159 281 331 minecraft:magenta_terracotta
fill 157 279 332 157 279 340 minecraft:dark_oak_planks
fill 157 279 341 157 279 343 minecraft:ochre_froglight
fill 157 279 345 157 279 347 minecraft:ochre_froglight
fill 157 279 348 157 279 363 minecraft:dark_oak_planks
fill 158 279 323 160 279 329 minecraft:spruce_planks
fill 158 279 332 161 281 332 minecraft:magenta_terracotta
fill 158 279 333 158 279 340 minecraft:spruce_planks
fill 158 279 341 159 279 341 minecraft:ochre_froglight
fill 158 279 347 159 279 347 minecraft:ochre_froglight
fill 158 279 348 158 279 363 minecraft:spruce_planks
fill 158 279 364 160 306 364 minecraft:blue_concrete
fill 159 279 330 160 279 330 minecraft:spruce_planks
fill 159 279 333 162 281 333 minecraft:magenta_terracotta
fill 159 279 334 160 279 339 minecraft:spruce_planks
fill 159 279 340 161 279 340 minecraft:ochre_froglight
fill 159 279 348 161 279 348 minecraft:ochre_froglight
fill 159 279 349 160 279 363 minecraft:spruce_planks
setblock 160 279 331 minecraft:spruce_planks
fill 161 279 323 161 279 331 minecraft:dark_oak_planks
fill 161 279 334 163 281 334 minecraft:magenta_terracotta
fill 161 279 335 161 279 339 minecraft:dark_oak_planks
fill 161 279 341 163 279 341 minecraft:ochre_froglight
fill 161 279 347 163 279 347 minecraft:ochre_froglight
fill 161 279 349 161 279 363 minecraft:dark_oak_planks
setblock 161 279 364 minecraft:light_blue_wool
fill 162 279 323 164 279 332 minecraft:spruce_planks
fill 162 279 335 162 281 335 minecraft:magenta_terracotta
fill 162 279 336 164 279 340 minecraft:spruce_planks
fill 162 279 348 164 279 363 minecraft:spruce_planks
fill 162 279 364 162 308 364 minecraft:blue_concrete
fill 163 279 333 164 279 333 minecraft:spruce_planks
fill 163 279 335 164 279 335 minecraft:spruce_planks
fill 163 279 342 163 279 343 minecraft:ochre_froglight
fill 163 279 345 163 279 346 minecraft:ochre_froglight
setblock 164 279 334 minecraft:spruce_planks
fill 164 279 341 164 279 342 minecraft:spruce_planks
fill 164 279 343 164 279 345 minecraft:ochre_froglight
fill 164 279 346 164 279 347 minecraft:spruce_planks
fill 169 279 323 169 279 346 minecraft:dark_oak_planks
fill 169 279 347 173 281 347 minecraft:magenta_terracotta
fill 169 279 348 169 279 363 minecraft:dark_oak_planks
fill 170 279 323 170 279 346 minecraft:spruce_planks
fill 170 279 348 171 281 348 minecraft:magenta_terracotta
fill 170 279 349 172 279 363 minecraft:spruce_planks
fill 171 279 323 172 279 345 minecraft:spruce_planks
fill 171 279 346 175 281 346 minecraft:magenta_terracotta
setblock 172 279 348 minecraft:spruce_planks
fill 173 279 323 173 279 344 minecraft:dark_oak_planks
fill 173 279 345 178 281 345 minecraft:magenta_terracotta
fill 173 279 348 173 279 363 minecraft:dark_oak_planks
fill 174 279 323 174 279 344 minecraft:spruce_planks
fill 174 279 347 176 279 363 minecraft:spruce_planks
fill 175 279 323 176 279 343 minecraft:spruce_planks
fill 175 279 344 180 281 344 minecraft:magenta_terracotta
setblock 176 279 346 minecraft:spruce_planks
fill 177 279 323 177 279 343 minecraft:dark_oak_planks
fill 177 279 346 177 279 363 minecraft:dark_oak_planks
fill 178 279 323 179 279 342 minecraft:spruce_planks
fill 178 279 343 181 281 343 minecraft:magenta_terracotta
fill 178 279 346 180 279 363 minecraft:spruce_planks
fill 179 279 345 180 279 345 minecraft:spruce_planks
fill 180 279 323 180 279 341 minecraft:spruce_planks
fill 180 279 342 180 281 342 minecraft:magenta_terracotta
fill 181 279 323 181 279 342 minecraft:dark_oak_planks
fill 181 279 344 181 279 363 minecraft:dark_oak_planks
setblock 143 280 364 minecraft:light_blue_wool
fill 148 280 342 148 286 343 minecraft:magenta_terracotta
fill 152 280 327 152 280 328 minecraft:magenta_terracotta
fill 152 280 354 152 280 356 minecraft:magenta_terracotta
setblock 153 280 326 minecraft:magenta_terracotta
setblock 153 280 329 minecraft:magenta_terracotta
fill 153 280 347 153 280 348 minecraft:magenta_terracotta
setblock 153 280 360 minecraft:magenta_terracotta
setblock 154 280 359 minecraft:magenta_terracotta
fill 155 280 327 155 298 327 minecraft:magenta_terracotta
fill 155 280 351 155 280 353 minecraft:magenta_terracotta
fill 155 280 358 155 298 358 minecraft:magenta_terracotta
setblock 156 280 328 minecraft:magenta_terracotta
setblock 156 280 331 minecraft:magenta_terracotta
setblock 157 280 332 minecraft:magenta_terracotta
setblock 159 280 330 minecraft:magenta_terracotta
setblock 160 280 331 minecraft:magenta_terracotta
setblock 160 280 334 minecraft:magenta_terracotta
setblock 161 280 335 minecraft:magenta_terracotta
fill 161 280 364 161 308 364 minecraft:blue_concrete
setblock 163 280 333 minecraft:magenta_terracotta
setblock 163 280 335 minecraft:magenta_terracotta
fill 169 280 327 169 280 328 minecraft:magenta_terracotta
setblock 169 280 348 minecraft:magenta_terracotta
fill 169 280 358 169 289 359 minecraft:magenta_terracotta
fill 170 280 328 170 297 328 minecraft:magenta_terracotta
setblock 170 280 346 minecraft:magenta_terracotta
setblock 172 280 345 minecraft:magenta_terracotta
setblock 172 280 348 minecraft:magenta_terracotta
setblock 174 280 344 minecraft:magenta_terracotta
setblock 174 280 347 minecraft:magenta_terracotta
fill 176 280 343 177 280 343 minecraft:magenta_terracotta
setblock 176 280 346 minecraft:magenta_terracotta
setblock 179 280 342 minecraft:magenta_terracotta
setblock 179 280 345 minecraft:magenta_terracotta
setblock 181 280 342 minecraft:magenta_terracotta
setblock 181 280 344 minecraft:magenta_terracotta
fill 143 281 364 143 308 364 minecraft:blue_concrete
setblock 144 281 325 minecraft:light[level=12]
setblock 144 281 332 minecraft:light[level=12]
setblock 144 281 339 minecraft:light[level=12]
setblock 144 281 346 minecraft:light[level=12]
setblock 144 281 353 minecraft:light[level=12]
setblock 144 281 360 minecraft:light[level=12]
setblock 151 281 325 minecraft:light[level=12]
setblock 151 281 332 minecraft:light[level=12]
setblock 151 281 339 minecraft:light[level=12]
setblock 151 281 346 minecraft:light[level=12]
setblock 151 281 353 minecraft:light[level=12]
setblock 151 281 360 minecraft:light[level=12]
setblock 158 281 325 minecraft:light[level=12]
setblock 158 281 339 minecraft:light[level=12]
setblock 158 281 353 minecraft:light[level=12]
setblock 158 281 360 minecraft:light[level=12]
setblock 165 281 325 minecraft:light[level=12]
setblock 165 281 332 minecraft:light[level=12]
setblock 165 281 339 minecraft:light[level=12]
setblock 165 281 346 minecraft:light[level=12]
setblock 165 281 353 minecraft:light[level=12]
setblock 165 281 360 minecraft:light[level=12]
fill 169 281 328 169 298 328 minecraft:magenta_terracotta
setblock 172 281 325 minecraft:light[level=12]
setblock 172 281 332 minecraft:light[level=12]
setblock 172 281 339 minecraft:light[level=12]
setblock 172 281 353 minecraft:light[level=12]
setblock 172 281 360 minecraft:light[level=12]
fill 176 281 343 176 289 343 minecraft:magenta_terracotta
setblock 179 281 325 minecraft:light[level=12]
setblock 179 281 332 minecraft:light[level=12]
setblock 179 281 339 minecraft:light[level=12]
setblock 179 281 346 minecraft:light[level=12]
setblock 179 281 353 minecraft:light[level=12]
setblock 179 281 360 minecraft:light[level=12]
fill 176 282 344 176 298 344 minecraft:magenta_terracotta
fill 142 283 323 142 283 326 minecraft:blue_terracotta
setblock 142 283 327 minecraft:dark_prismarine
fill 142 283 328 142 283 331 minecraft:blue_terracotta
setblock 142 283 332 minecraft:dark_prismarine
fill 142 283 333 142 283 336 minecraft:blue_terracotta
fill 142 283 348 142 283 351 minecraft:blue_terracotta
setblock 142 283 352 minecraft:dark_prismarine
fill 142 283 353 142 283 356 minecraft:blue_terracotta
setblock 142 283 357 minecraft:dark_prismarine
fill 142 283 358 142 283 361 minecraft:blue_terracotta
setblock 142 283 362 minecraft:dark_prismarine
fill 142 283 363 144 283 363 minecraft:blue_terracotta
setblock 143 283 323 minecraft:blue_terracotta
setblock 143 283 330 minecraft:blue_terracotta
setblock 143 283 331 minecraft:dark_prismarine
fill 143 283 332 145 284 334 minecraft:purple_concrete
setblock 143 283 351 minecraft:dark_prismarine
fill 143 283 352 143 283 355 minecraft:blue_terracotta
setblock 143 283 356 minecraft:dark_prismarine
fill 143 283 357 143 283 360 minecraft:blue_terracotta
fill 146 283 333 146 284 333 minecraft:purple_concrete
setblock 147 283 363 minecraft:purple_concrete
setblock 152 283 323 minecraft:purple_concrete
fill 152 283 363 155 283 363 minecraft:blue_terracotta
fill 155 283 357 155 298 357 minecraft:magenta_terracotta
setblock 156 283 363 minecraft:dark_prismarine
fill 157 283 363 159 283 363 minecraft:blue_terracotta
fill 171 283 323 171 284 323 minecraft:purple_concrete
setblock 172 283 363 minecraft:purple_concrete
fill 173 283 323 175 283 323 minecraft:blue_terracotta
setblock 174 283 324 minecraft:blue_terracotta
setblock 175 283 324 minecraft:dark_prismarine
setblock 176 283 323 minecraft:dark_prismarine
fill 176 283 324 178 283 325 minecraft:blue_terracotta
fill 176 283 334 176 287 334 minecraft:green_terracotta
setblock 176 283 363 minecraft:dark_prismarine
fill 177 283 323 180 283 323 minecraft:blue_terracotta
fill 177 283 363 180 283 363 minecraft:blue_terracotta
setblock 179 283 324 minecraft:blue_terracotta
setblock 179 283 325 minecraft:dark_prismarine
fill 179 283 327 179 283 329 minecraft:blue_terracotta
setblock 179 283 330 minecraft:dark_prismarine
fill 179 283 331 179 283 334 minecraft:blue_terracotta
setblock 179 283 335 minecraft:dark_prismarine
setblock 180 283 324 minecraft:dark_prismarine
fill 180 283 325 180 283 328 minecraft:blue_terracotta
setblock 180 283 329 minecraft:dark_prismarine
fill 180 283 330 180 283 333 minecraft:blue_terracotta
setblock 180 283 334 minecraft:dark_prismarine
fill 180 283 335 182 283 336 minecraft:blue_terracotta
setblock 181 283 323 minecraft:dark_prismarine
fill 181 283 324 181 283 327 minecraft:blue_terracotta
setblock 181 283 328 minecraft:dark_prismarine
fill 181 283 329 181 283 332 minecraft:blue_terracotta
setblock 181 283 333 minecraft:dark_prismarine
fill 181 283 334 182 285 334 minecraft:blue_terracotta
setblock 181 283 337 minecraft:blue_terracotta
fill 181 283 351 181 283 352 minecraft:blue_terracotta
setblock 181 283 353 minecraft:dark_prismarine
fill 181 283 354 181 283 357 minecraft:blue_terracotta
setblock 181 283 358 minecraft:dark_prismarine
fill 181 283 359 182 283 359 minecraft:blue_terracotta
setblock 181 283 363 minecraft:dark_prismarine
fill 182 283 323 182 283 326 minecraft:blue_terracotta
setblock 182 283 327 minecraft:dark_prismarine
fill 182 283 328 182 283 331 minecraft:blue_terracotta
setblock 182 283 332 minecraft:dark_prismarine
fill 182 283 333 182 286 333 minecraft:blue_terracotta
setblock 182 283 337 minecraft:dark_prismarine
fill 182 283 338 182 283 339 minecraft:blue_terracotta
fill 182 283 349 182 283 351 minecraft:blue_terracotta
setblock 182 283 352 minecraft:dark_prismarine
fill 182 283 353 182 283 356 minecraft:blue_terracotta
setblock 182 283 357 minecraft:dark_prismarine
fill 182 283 358 182 286 358 minecraft:blue_terracotta
fill 182 283 360 182 283 361 minecraft:blue_terracotta
setblock 182 283 362 minecraft:dark_prismarine
fill 182 283 363 182 285 363 minecraft:blue_terracotta
setblock 142 284 325 minecraft:blue_terracotta
setblock 142 284 326 minecraft:dark_prismarine
fill 142 284 327 142 284 330 minecraft:blue_terracotta
setblock 142 284 331 minecraft:dark_prismarine
fill 142 284 332 142 284 335 minecraft:blue_terracotta
setblock 142 284 336 minecraft:dark_prismarine
fill 142 284 349 142 284 350 minecraft:blue_terracotta
setblock 142 284 351 minecraft:dark_prismarine
fill 142 284 352 142 284 355 minecraft:blue_terracotta
setblock 142 284 356 minecraft:dark_prismarine
fill 142 284 357 142 284 360 minecraft:blue_terracotta
setblock 142 284 361 minecraft:dark_prismarine
fill 142 284 362 142 286 363 minecraft:blue_terracotta
fill 143 284 352 143 284 354 minecraft:blue_terracotta
setblock 143 284 355 minecraft:dark_prismarine
fill 143 284 356 143 284 359 minecraft:blue_terracotta
setblock 143 284 360 minecraft:dark_prismarine
fill 143 284 363 143 285 363 minecraft:blue_terracotta
fill 144 284 331 145 284 331 minecraft:purple_concrete
fill 144 284 335 145 284 335 minecraft:purple_concrete
setblock 146 284 323 minecraft:purple_concrete
setblock 146 284 332 minecraft:purple_concrete
setblock 146 284 334 minecraft:purple_concrete
fill 153 284 363 154 284 363 minecraft:blue_terracotta
setblock 155 284 363 minecraft:dark_prismarine
fill 156 284 363 158 284 363 minecraft:blue_terracotta
setblock 165 284 323 minecraft:purple_concrete
fill 173 284 323 174 284 323 minecraft:blue_terracotta
setblock 175 284 323 minecraft:dark_prismarine
fill 175 284 324 178 284 324 minecraft:blue_terracotta
fill 176 284 323 179 284 323 minecraft:blue_terracotta
fill 176 284 363 179 284 363 minecraft:blue_terracotta
setblock 179 284 324 minecraft:dark_prismarine
setblock 179 284 329 minecraft:dark_prismarine
fill 179 284 330 179 284 333 minecraft:blue_terracotta
setblock 179 284 334 minecraft:dark_prismarine
setblock 180 284 323 minecraft:dark_prismarine
fill 180 284 324 182 284 324 minecraft:blue_terracotta
setblock 180 284 327 minecraft:blue_terracotta
setblock 180 284 328 minecraft:dark_prismarine
fill 180 284 329 180 284 332 minecraft:blue_terracotta
setblock 180 284 333 minecraft:dark_prismarine
fill 180 284 334 180 284 336 minecraft:blue_terracotta
setblock 180 284 363 minecraft:dark_prismarine
fill 181 284 323 182 285 323 minecraft:blue_terracotta
fill 181 284 325 181 284 326 minecraft:blue_terracotta
setblock 181 284 327 minecraft:dark_prismarine
fill 181 284 328 181 284 331 minecraft:blue_terracotta
setblock 181 284 332 minecraft:dark_prismarine
fill 181 284 333 181 287 333 minecraft:blue_terracotta
fill 181 284 335 181 284 336 minecraft:blue_terracotta
setblock 181 284 337 minecraft:dark_prismarine
fill 181 284 353 181 284 356 minecraft:blue_terracotta
setblock 181 284 357 minecraft:dark_prismarine
setblock 181 284 358 minecraft:blue_terracotta
fill 181 284 363 181 287 363 minecraft:blue_terracotta
setblock 182 284 325 minecraft:blue_terracotta
setblock 182 284 326 minecraft:dark_prismarine
fill 182 284 327 182 284 330 minecraft:blue_terracotta
setblock 182 284 331 minecraft:dark_prismarine
fill 182 284 332 182 287 332 minecraft:blue_terracotta
setblock 182 284 335 minecraft:blue_terracotta
setblock 182 284 336 minecraft:dark_prismarine
fill 182 284 337 182 284 338 minecraft:blue_terracotta
fill 182 284 350 182 285 350 minecraft:purple_concrete
setblock 182 284 351 minecraft:dark_prismarine
fill 182 284 352 182 284 355 minecraft:blue_terracotta
setblock 182 284 356 minecraft:dark_prismarine
fill 182 284 357 182 287 357 minecraft:blue_terracotta
fill 182 284 359 182 284 360 minecraft:blue_terracotta
setblock 182 284 361 minecraft:dark_prismarine
fill 182 284 362 182 287 362 minecraft:blue_terracotta
setblock 183 284 357 minecraft:light_blue_wool
fill 142 285 327 147 285 328 minecraft:dark_prismarine
setblock 142 285 329 minecraft:blue_terracotta
fill 142 285 330 147 285 330 minecraft:dark_prismarine
fill 142 285 331 142 285 334 minecraft:blue_terracotta
fill 142 285 335 147 285 335 minecraft:dark_prismarine
setblock 142 285 336 minecraft:purple_concrete
fill 142 285 337 147 285 339 minecraft:dark_prismarine
setblock 142 285 350 minecraft:dark_prismarine
fill 142 285 351 142 285 354 minecraft:blue_terracotta
setblock 142 285 355 minecraft:dark_prismarine
fill 142 285 356 142 285 359 minecraft:blue_terracotta
setblock 142 285 360 minecraft:dark_prismarine
fill 142 285 361 142 288 361 minecraft:blue_terracotta
fill 143 285 329 147 285 329 minecraft:dark_prismarine
fill 143 285 331 147 285 334 minecraft:dark_prismarine
fill 143 285 336 147 285 336 minecraft:dark_prismarine
setblock 143 285 353 minecraft:blue_terracotta
setblock 143 285 354 minecraft:dark_prismarine
fill 143 285 355 143 285 358 minecraft:blue_terracotta
setblock 143 285 359 minecraft:dark_prismarine
setblock 144 285 325 minecraft:light[level=13]
setblock 144 285 341 minecraft:light[level=13]
setblock 144 285 349 minecraft:light[level=13]
setblock 144 285 357 minecraft:light[level=13]
setblock 152 285 325 minecraft:light[level=13]
setblock 152 285 333 minecraft:light[level=13]
setblock 152 285 341 minecraft:light[level=13]
setblock 152 285 349 minecraft:light[level=13]
setblock 152 285 357 minecraft:light[level=13]
setblock 153 285 363 minecraft:blue_terracotta
setblock 154 285 363 minecraft:dark_prismarine
fill 155 285 363 157 286 363 minecraft:blue_terracotta
setblock 159 285 323 minecraft:purple_concrete
setblock 159 285 363 minecraft:purple_concrete
setblock 160 285 325 minecraft:light[level=13]
setblock 160 285 333 minecraft:light[level=13]
setblock 160 285 341 minecraft:light[level=13]
setblock 160 285 349 minecraft:light[level=13]
setblock 160 285 357 minecraft:light[level=13]
fill 165 285 363 165 286 363 minecraft:purple_concrete
setblock 168 285 325 minecraft:light[level=13]
setblock 168 285 333 minecraft:light[level=13]
setblock 168 285 341 minecraft:light[level=13]
setblock 168 285 349 minecraft:light[level=13]
setblock 168 285 357 minecraft:light[level=13]
setblock 173 285 323 minecraft:blue_terracotta
setblock 174 285 323 minecraft:dark_prismarine
fill 175 285 323 177 285 324 minecraft:blue_terracotta
fill 175 285 363 178 285 363 minecraft:blue_terracotta
setblock 176 285 325 minecraft:light[level=13]
setblock 176 285 333 minecraft:light[level=13]
setblock 176 285 341 minecraft:light[level=13]
setblock 176 285 349 minecraft:light[level=13]
setblock 176 285 357 minecraft:light[level=13]
setblock 178 285 323 minecraft:blue_terracotta
setblock 178 285 324 minecraft:dark_prismarine
setblock 179 285 323 minecraft:dark_prismarine
setblock 179 285 324 minecraft:blue_terracotta
setblock 179 285 363 minecraft:dark_prismarine
fill 180 285 323 180 288 323 minecraft:blue_terracotta
fill 180 285 329 180 285 331 minecraft:blue_terracotta
setblock 180 285 332 minecraft:dark_prismarine
fill 180 285 333 180 285 335 minecraft:blue_terracotta
fill 180 285 363 180 288 363 minecraft:blue_terracotta
setblock 181 285 326 minecraft:dark_prismarine
fill 181 285 327 181 285 330 minecraft:blue_terracotta
setblock 181 285 331 minecraft:dark_prismarine
fill 181 285 332 181 287 332 minecraft:blue_terracotta
setblock 181 285 335 minecraft:blue_terracotta
setblock 181 285 336 minecraft:dark_prismarine
setblock 181 285 355 minecraft:blue_terracotta
setblock 181 285 356 minecraft:dark_prismarine
setblock 181 285 357 minecraft:blue_terracotta
setblock 182 285 324 minecraft:blue_terracotta
setblock 182 285 325 minecraft:dark_prismarine
fill 182 285 326 182 285 329 minecraft:blue_terracotta
setblock 182 285 330 minecraft:dark_prismarine
fill 182 285 331 182 287 331 minecraft:blue_terracotta
setblock 182 285 335 minecraft:dark_prismarine
fill 182 285 336 182 286 337 minecraft:blue_terracotta
setblock 182 285 344 minecraft:purple_concrete
fill 182 285 352 182 285 354 minecraft:blue_terracotta
setblock 182 285 355 minecraft:dark_prismarine
fill 182 285 356 182 288 356 minecraft:blue_terracotta
setblock 182 285 359 minecraft:blue_terracotta
setblock 182 285 360 minecraft:dark_prismarine
fill 182 285 361 182 288 361 minecraft:blue_terracotta
fill 183 285 357 183 308 357 minecraft:blue_concrete
setblock 142 286 323 minecraft:purple_concrete
setblock 142 286 327 minecraft:sea_lantern
fill 142 286 328 142 289 328 minecraft:dark_prismarine
setblock 142 286 329 minecraft:sea_lantern
fill 142 286 330 142 300 330 minecraft:dark_prismarine
setblock 142 286 331 minecraft:sea_lantern
fill 142 286 332 142 297 332 minecraft:dark_prismarine
setblock 142 286 333 minecraft:sea_lantern
fill 142 286 334 142 290 334 minecraft:dark_prismarine
setblock 142 286 335 minecraft:sea_lantern
fill 142 286 336 142 300 336 minecraft:dark_prismarine
setblock 142 286 337 minecraft:sea_lantern
fill 142 286 338 142 292 338 minecraft:dark_prismarine
setblock 142 286 339 minecraft:sea_lantern
setblock 142 286 342 minecraft:purple_concrete
fill 142 286 348 142 287 348 minecraft:purple_concrete
fill 142 286 351 142 286 353 minecraft:blue_terracotta
setblock 142 286 354 minecraft:dark_prismarine
fill 142 286 355 142 286 358 minecraft:blue_terracotta
setblock 142 286 359 minecraft:dark_prismarine
fill 142 286 360 142 289 360 minecraft:blue_terracotta
fill 143 286 327 143 300 327 minecraft:dark_prismarine
setblock 143 286 328 minecraft:sea_lantern
fill 143 286 329 143 300 329 minecraft:dark_prismarine
setblock 143 286 330 minecraft:sea_lantern
fill 143 286 331 143 300 331 minecraft:dark_prismarine
setblock 143 286 332 minecraft:sea_lantern
fill 143 286 333 143 300 333 minecraft:dark_prismarine
setblock 143 286 334 minecraft:sea_lantern
fill 143 286 335 143 300 335 minecraft:dark_prismarine
setblock 143 286 336 minecraft:sea_lantern
fill 143 286 337 143 300 337 minecraft:dark_prismarine
setblock 143 286 338 minecraft:sea_lantern
fill 143 286 339 143 300 339 minecraft:dark_prismarine
fill 143 286 354 143 286 357 minecraft:blue_terracotta
setblock 143 286 358 minecraft:dark_prismarine
fill 143 286 359 143 289 359 minecraft:blue_terracotta
setblock 144 286 327 minecraft:sea_lantern
fill 144 286 328 144 300 328 minecraft:dark_prismarine
setblock 144 286 329 minecraft:sea_lantern
fill 144 286 330 144 300 330 minecraft:dark_prismarine
setblock 144 286 331 minecraft:sea_lantern
fill 144 286 332 144 300 332 minecraft:dark_prismarine
setblock 144 286 333 minecraft:sea_lantern
fill 144 286 334 144 300 334 minecraft:dark_prismarine
setblock 144 286 335 minecraft:sea_lantern
fill 144 286 336 144 300 336 minecraft:dark_prismarine
setblock 144 286 337 minecraft:sea_lantern
fill 144 286 338 144 300 338 minecraft:dark_prismarine
setblock 144 286 339 minecraft:sea_lantern
fill 145 286 327 145 300 327 minecraft:dark_prismarine
setblock 145 286 328 minecraft:sea_lantern
fill 145 286 329 145 300 329 minecraft:dark_prismarine
setblock 145 286 330 minecraft:sea_lantern
fill 145 286 331 145 300 331 minecraft:dark_prismarine
setblock 145 286 332 minecraft:sea_lantern
fill 145 286 333 145 300 333 minecraft:dark_prismarine
setblock 145 286 334 minecraft:sea_lantern
fill 145 286 335 145 300 335 minecraft:dark_prismarine
setblock 145 286 336 minecraft:sea_lantern
fill 145 286 337 145 300 337 minecraft:dark_prismarine
setblock 145 286 338 minecraft:sea_lantern
fill 145 286 339 145 300 339 minecraft:dark_prismarine
setblock 146 286 327 minecraft:sea_lantern
fill 146 286 328 146 300 328 minecraft:dark_prismarine
setblock 146 286 329 minecraft:sea_lantern
fill 146 286 330 146 300 330 minecraft:dark_prismarine
setblock 146 286 331 minecraft:sea_lantern
fill 146 286 332 146 300 332 minecraft:dark_prismarine
setblock 146 286 333 minecraft:sea_lantern
fill 146 286 334 146 300 334 minecraft:dark_prismarine
setblock 146 286 335 minecraft:sea_lantern
fill 146 286 336 146 300 336 minecraft:dark_prismarine
setblock 146 286 337 minecraft:sea_lantern
fill 146 286 338 146 300 338 minecraft:dark_prismarine
setblock 146 286 339 minecraft:sea_lantern
setblock 146 286 363 minecraft:purple_concrete
fill 147 286 327 147 300 327 minecraft:dark_prismarine
setblock 147 286 328 minecraft:sea_lantern
fill 147 286 329 147 300 329 minecraft:dark_prismarine
setblock 147 286 330 minecraft:sea_lantern
fill 147 286 331 147 300 331 minecraft:dark_prismarine
setblock 147 286 332 minecraft:sea_lantern
fill 147 286 333 147 300 333 minecraft:dark_prismarine
setblock 147 286 334 minecraft:sea_lantern
fill 147 286 335 147 300 335 minecraft:dark_prismarine
setblock 147 286 336 minecraft:sea_lantern
fill 147 286 337 147 300 337 minecraft:dark_prismarine
setblock 147 286 338 minecraft:sea_lantern
fill 147 286 339 147 300 339 minecraft:dark_prismarine
setblock 152 286 363 minecraft:blue_terracotta
setblock 153 286 323 minecraft:purple_concrete
setblock 153 286 363 minecraft:dark_prismarine
fill 154 286 363 154 289 363 minecraft:blue_terracotta
fill 157 286 330 157 300 332 minecraft:dark_prismarine
fill 158 286 330 158 300 331 minecraft:dark_prismarine
fill 170 286 359 170 297 359 minecraft:magenta_terracotta
setblock 171 286 363 minecraft:purple_concrete
setblock 173 286 323 minecraft:dark_prismarine
fill 174 286 323 177 286 323 minecraft:blue_terracotta
fill 175 286 353 175 287 353 minecraft:sea_lantern
fill 175 286 363 177 286 363 minecraft:blue_terracotta
setblock 176 286 324 minecraft:blue_terracotta
setblock 177 286 324 minecraft:dark_prismarine
setblock 178 286 323 minecraft:dark_prismarine
setblock 178 286 324 minecraft:blue_terracotta
setblock 178 286 363 minecraft:dark_prismarine
fill 179 286 323 179 289 323 minecraft:blue_terracotta
fill 179 286 363 179 289 363 minecraft:blue_terracotta
setblock 180 286 333 minecraft:blue_terracotta
setblock 181 286 323 minecraft:blue_terracotta
setblock 181 286 329 minecraft:blue_terracotta
setblock 181 286 330 minecraft:dark_prismarine
setblock 181 286 331 minecraft:blue_terracotta
setblock 181 286 334 minecraft:blue_terracotta
setblock 181 286 335 minecraft:dark_prismarine
fill 182 286 326 182 286 328 minecraft:blue_terracotta
setblock 182 286 329 minecraft:dark_prismarine
fill 182 286 330 182 287 330 minecraft:blue_terracotta
setblock 182 286 334 minecraft:dark_prismarine
fill 182 286 335 182 289 335 minecraft:blue_terracotta
setblock 182 286 338 minecraft:purple_concrete
setblock 182 286 354 minecraft:dark_prismarine
fill 182 286 355 182 289 355 minecraft:blue_terracotta
setblock 182 286 359 minecraft:dark_prismarine
fill 182 286 360 182 289 360 minecraft:blue_terracotta
setblock 183 286 328 minecraft:cyan_concrete
fill 142 287 327 142 288 327 minecraft:dark_prismarine
setblock 142 287 329 minecraft:purple_concrete
fill 142 287 331 142 288 331 minecraft:dark_prismarine
fill 142 287 333 142 288 333 minecraft:dark_prismarine
setblock 142 287 335 minecraft:dark_prismarine
fill 142 287 337 142 288 337 minecraft:dark_prismarine
fill 142 287 339 142 288 339 minecraft:dark_prismarine
setblock 142 287 352 minecraft:blue_terracotta
setblock 142 287 353 minecraft:dark_prismarine
fill 142 287 354 142 287 357 minecraft:blue_terracotta
setblock 142 287 358 minecraft:dark_prismarine
fill 142 287 359 142 290 359 minecraft:blue_terracotta
setblock 142 287 362 minecraft:blue_terracotta
setblock 142 287 363 minecraft:dark_prismarine
fill 143 287 328 143 288 328 minecraft:dark_prismarine
fill 143 287 330 143 288 330 minecraft:dark_prismarine
fill 143 287 332 143 288 332 minecraft:dark_prismarine
fill 143 287 334 143 288 334 minecraft:dark_prismarine
fill 143 287 336 143 288 336 minecraft:dark_prismarine
fill 143 287 338 143 288 338 minecraft:dark_prismarine
fill 143 287 355 143 287 356 minecraft:blue_terracotta
setblock 143 287 357 minecraft:dark_prismarine
fill 143 287 358 143 290 358 minecraft:blue_terracotta
setblock 144 287 325 minecraft:light[level=12]
fill 144 287 327 144 288 327 minecraft:dark_prismarine
fill 144 287 329 144 288 329 minecraft:dark_prismarine
fill 144 287 331 144 288 331 minecraft:dark_prismarine
fill 144 287 333 144 288 333 minecraft:dark_prismarine
fill 144 287 335 144 288 335 minecraft:dark_prismarine
fill 144 287 337 144 288 337 minecraft:dark_prismarine
fill 144 287 339 144 288 339 minecraft:dark_prismarine
setblock 144 287 346 minecraft:light[level=12]
setblock 144 287 353 minecraft:light[level=12]
setblock 144 287 360 minecraft:light[level=12]
fill 145 287 328 145 288 328 minecraft:dark_prismarine
fill 145 287 330 145 288 330 minecraft:dark_prismarine
fill 145 287 332 145 288 332 minecraft:dark_prismarine
fill 145 287 334 145 288 334 minecraft:dark_prismarine
fill 145 287 336 145 288 336 minecraft:dark_prismarine
fill 145 287 338 145 288 338 minecraft:dark_prismarine
fill 146 287 327 146 288 327 minecraft:dark_prismarine
fill 146 287 329 146 288 329 minecraft:dark_prismarine
fill 146 287 331 146 288 331 minecraft:dark_prismarine
fill 146 287 333 146 288 333 minecraft:dark_prismarine
fill 146 287 335 146 288 335 minecraft:dark_prismarine
fill 146 287 337 146 288 337 minecraft:dark_prismarine
fill 146 287 339 146 288 339 minecraft:dark_prismarine
setblock 147 287 323 minecraft:purple_concrete
fill 147 287 328 147 288 328 minecraft:dark_prismarine
fill 147 287 330 147 288 330 minecraft:dark_prismarine
fill 147 287 332 147 288 332 minecraft:dark_prismarine
fill 147 287 334 147 288 334 minecraft:dark_prismarine
fill 147 287 336 147 288 336 minecraft:dark_prismarine
fill 147 287 338 147 288 338 minecraft:dark_prismarine
fill 148 287 342 148 297 342 minecraft:magenta_terracotta
setblock 151 287 325 minecraft:light[level=12]
setblock 151 287 332 minecraft:light[level=12]
setblock 151 287 339 minecraft:light[level=12]
setblock 151 287 346 minecraft:light[level=12]
setblock 151 287 353 minecraft:light[level=12]
setblock 151 287 360 minecraft:light[level=12]
setblock 151 287 363 minecraft:blue_terracotta
setblock 152 287 363 minecraft:dark_prismarine
fill 153 287 363 153 290 363 minecraft:blue_terracotta
fill 155 287 363 156 287 363 minecraft:blue_terracotta
fill 156 287 330 156 288 332 minecraft:black_concrete
fill 157 287 329 157 288 329 minecraft:black_concrete
setblock 157 287 363 minecraft:dark_prismarine
setblock 158 287 325 minecraft:light[level=12]
fill 158 287 332 158 288 332 minecraft:black_concrete
setblock 158 287 339 minecraft:light[level=12]
setblock 158 287 346 minecraft:light[level=12]
setblock 158 287 353 minecraft:light[level=12]
setblock 158 287 360 minecraft:light[level=12]
fill 159 287 331 159 288 331 minecraft:black_concrete
setblock 165 287 325 minecraft:light[level=12]
setblock 165 287 332 minecraft:light[level=12]
setblock 165 287 339 minecraft:light[level=12]
setblock 165 287 346 minecraft:light[level=12]
setblock 165 287 353 minecraft:light[level=12]
setblock 165 287 360 minecraft:light[level=12]
setblock 172 287 323 minecraft:dark_prismarine
setblock 172 287 325 minecraft:light[level=12]
setblock 172 287 332 minecraft:light[level=12]
setblock 172 287 339 minecraft:light[level=12]
setblock 172 287 346 minecraft:light[level=12]
setblock 172 287 353 minecraft:light[level=12]
setblock 172 287 360 minecraft:light[level=12]
fill 173 287 323 176 287 323 minecraft:blue_terracotta
fill 174 287 363 176 287 363 minecraft:blue_terracotta
setblock 176 287 324 minecraft:dark_prismarine
setblock 177 287 323 minecraft:dark_prismarine
setblock 177 287 324 minecraft:blue_terracotta
setblock 177 287 363 minecraft:dark_prismarine
fill 178 287 323 178 290 323 minecraft:blue_terracotta
fill 178 287 363 178 290 363 minecraft:blue_terracotta
setblock 179 287 325 minecraft:light[level=12]
setblock 179 287 332 minecraft:light[level=12]
setblock 179 287 339 minecraft:light[level=12]
setblock 179 287 346 minecraft:light[level=12]
setblock 179 287 353 minecraft:light[level=12]
setblock 179 287 360 minecraft:light[level=12]
setblock 181 287 334 minecraft:dark_prismarine
setblock 182 287 329 minecraft:blue_terracotta
setblock 182 287 333 minecraft:dark_prismarine
fill 182 287 334 182 289 334 minecraft:blue_terracotta
fill 182 287 336 182 288 336 minecraft:blue_terracotta
setblock 182 287 358 minecraft:dark_prismarine
fill 182 287 359 182 290 359 minecraft:blue_terracotta
fill 183 287 328 183 308 328 minecraft:blue_concrete
setblock 183 287 331 minecraft:light_blue_wool
fill 141 288 350 141 308 353 minecraft:blue_concrete
setblock 141 288 354 minecraft:light_blue_wool
setblock 142 288 329 minecraft:dark_prismarine
setblock 142 288 335 minecraft:purple_concrete
fill 142 288 353 142 288 356 minecraft:blue_terracotta
setblock 142 288 357 minecraft:dark_prismarine
fill 142 288 358 142 291 358 minecraft:blue_terracotta
setblock 142 288 362 minecraft:dark_prismarine
fill 142 288 363 142 291 363 minecraft:blue_terracotta
setblock 143 288 356 minecraft:dark_prismarine
fill 143 288 357 143 291 357 minecraft:blue_terracotta
fill 147 288 342 147 295 342 minecraft:magenta_terracotta
fill 149 288 363 150 288 363 minecraft:blue_terracotta
setblock 151 288 363 minecraft:dark_prismarine
setblock 152 288 362 minecraft:dark_prismarine
fill 152 288 363 152 291 363 minecraft:blue_terracotta
fill 153 288 362 155 289 362 minecraft:blue_terracotta
setblock 155 288 331 minecraft:black_concrete
fill 155 288 347 155 300 348 minecraft:dark_prismarine
setblock 155 288 363 minecraft:blue_terracotta
setblock 156 288 329 minecraft:black_concrete
fill 156 288 347 156 300 347 minecraft:dark_prismarine
setblock 156 288 363 minecraft:dark_prismarine
setblock 157 288 333 minecraft:black_concrete
fill 157 288 363 157 291 363 minecraft:blue_terracotta
setblock 158 288 329 minecraft:black_concrete
setblock 158 288 363 minecraft:purple_concrete
setblock 159 288 330 minecraft:black_concrete
setblock 159 288 332 minecraft:black_concrete
setblock 166 288 323 minecraft:purple_concrete
fill 172 288 323 175 288 323 minecraft:blue_terracotta
fill 172 288 363 175 288 363 minecraft:blue_terracotta
setblock 175 288 324 minecraft:dark_prismarine
fill 175 288 353 175 298 353 minecraft:black_concrete
fill 175 288 362 176 288 362 minecraft:blue_terracotta
setblock 176 288 323 minecraft:dark_prismarine
fill 176 288 324 176 291 324 minecraft:blue_terracotta
setblock 176 288 363 minecraft:dark_prismarine
fill 177 288 323 177 291 323 minecraft:blue_terracotta
setblock 177 288 362 minecraft:dark_prismarine
fill 177 288 363 177 291 363 minecraft:blue_terracotta
fill 178 288 362 178 291 362 minecraft:blue_terracotta
setblock 181 288 363 minecraft:dark_prismarine
setblock 182 288 326 minecraft:purple_concrete
setblock 182 288 332 minecraft:dark_prismarine
setblock 182 288 333 minecraft:blue_terracotta
setblock 182 288 351 minecraft:purple_concrete
setblock 182 288 357 minecraft:dark_prismarine
fill 182 288 358 182 291 358 minecraft:blue_terracotta
setblock 182 288 362 minecraft:dark_prismarine
fill 182 288 363 182 291 363 minecraft:blue_terracotta
fill 183 288 331 183 308 331 minecraft:blue_concrete
fill 141 289 354 141 308 354 minecraft:blue_concrete
setblock 142 289 327 minecraft:sea_lantern
setblock 142 289 329 minecraft:sea_lantern
setblock 142 289 331 minecraft:sea_lantern
setblock 142 289 333 minecraft:sea_lantern
setblock 142 289 335 minecraft:sea_lantern
setblock 142 289 337 minecraft:sea_lantern
setblock 142 289 339 minecraft:sea_lantern
setblock 142 289 341 minecraft:purple_concrete
fill 142 289 353 142 289 355 minecraft:blue_terracotta
setblock 142 289 356 minecraft:dark_prismarine
fill 142 289 357 142 292 357 minecraft:blue_terracotta
setblock 142 289 361 minecraft:dark_prismarine
fill 142 289 362 142 292 362 minecraft:blue_terracotta
setblock 143 289 328 minecraft:sea_lantern
setblock 143 289 330 minecraft:sea_lantern
setblock 143 289 332 minecraft:sea_lantern
setblock 143 289 334 minecraft:sea_lantern
setblock 143 289 336 minecraft:sea_lantern
setblock 143 289 338 minecraft:sea_lantern
fill 143 289 356 143 292 356 minecraft:blue_terracotta
setblock 143 289 360 minecraft:dark_prismarine
fill 143 289 363 144 289 363 minecraft:blue_terracotta
setblock 144 289 327 minecraft:sea_lantern
setblock 144 289 329 minecraft:sea_lantern
setblock 144 289 331 minecraft:sea_lantern
setblock 144 289 333 minecraft:sea_lantern
setblock 144 289 335 minecraft:sea_lantern
setblock 144 289 337 minecraft:sea_lantern
setblock 144 289 339 minecraft:sea_lantern
setblock 145 289 328 minecraft:sea_lantern
setblock 145 289 330 minecraft:sea_lantern
setblock 145 289 332 minecraft:sea_lantern
setblock 145 289 334 minecraft:sea_lantern
setblock 145 289 336 minecraft:sea_lantern
setblock 145 289 338 minecraft:sea_lantern
setblock 145 289 363 minecraft:purple_concrete
setblock 146 289 327 minecraft:sea_lantern
setblock 146 289 329 minecraft:sea_lantern
setblock 146 289 331 minecraft:sea_lantern
setblock 146 289 333 minecraft:sea_lantern
setblock 146 289 335 minecraft:sea_lantern
setblock 146 289 337 minecraft:sea_lantern
setblock 146 289 339 minecraft:sea_lantern
fill 146 289 363 149 289 363 minecraft:blue_terracotta
setblock 147 289 328 minecraft:sea_lantern
setblock 147 289 330 minecraft:sea_lantern
setblock 147 289 332 minecraft:sea_lantern
setblock 147 289 334 minecraft:sea_lantern
setblock 147 289 336 minecraft:sea_lantern
setblock 147 289 338 minecraft:sea_lantern
setblock 150 289 362 minecraft:blue_terracotta
setblock 150 289 363 minecraft:dark_prismarine
setblock 151 289 362 minecraft:dark_prismarine
fill 151 289 363 151 292 363 minecraft:blue_terracotta
fill 152 289 362 152 292 362 minecraft:blue_terracotta
fill 154 289 347 154 290 348 minecraft:black_concrete
fill 155 289 346 155 290 346 minecraft:black_concrete
setblock 155 289 363 minecraft:dark_prismarine
fill 156 289 348 156 290 348 minecraft:black_concrete
fill 156 289 363 156 292 363 minecraft:blue_terracotta
setblock 160 289 323 minecraft:purple_concrete
setblock 164 289 363 minecraft:purple_concrete
fill 171 289 323 174 289 323 minecraft:blue_terracotta
fill 171 289 363 174 289 363 minecraft:blue_terracotta
setblock 173 289 324 minecraft:blue_terracotta
fill 173 289 362 175 289 362 minecraft:blue_terracotta
setblock 174 289 324 minecraft:dark_prismarine
fill 174 289 353 174 298 353 minecraft:black_concrete
setblock 175 289 323 minecraft:dark_prismarine
fill 175 289 324 175 292 324 minecraft:blue_terracotta
fill 175 289 352 175 298 352 minecraft:black_concrete
setblock 175 289 363 minecraft:dark_prismarine
fill 176 289 323 176 292 323 minecraft:blue_terracotta
setblock 176 289 362 minecraft:dark_prismarine
fill 176 289 363 176 292 363 minecraft:blue_terracotta
fill 177 289 324 177 290 324 minecraft:blue_terracotta
fill 177 289 362 177 292 362 minecraft:blue_terracotta
fill 179 289 362 179 290 362 minecraft:blue_terracotta
setblock 180 289 323 minecraft:dark_prismarine
setblock 180 289 363 minecraft:dark_prismarine
fill 181 289 359 181 290 360 minecraft:blue_terracotta
fill 181 289 363 181 292 363 minecraft:blue_terracotta
setblock 182 289 345 minecraft:purple_concrete
setblock 182 289 356 minecraft:dark_prismarine
fill 182 289 357 182 292 357 minecraft:blue_terracotta
setblock 182 289 361 minecraft:dark_prismarine
fill 182 289 362 182 292 362 minecraft:blue_terracotta
setblock 183 289 329 minecraft:cyan_concrete
fill 183 289 330 183 308 330 minecraft:blue_concrete
setblock 183 289 336 minecraft:cyan_concrete
fill 142 290 327 142 291 327 minecraft:dark_prismarine
setblock 142 290 328 minecraft:purple_concrete
fill 142 290 329 142 291 329 minecraft:dark_prismarine
fill 142 290 331 142 291 331 minecraft:dark_prismarine
fill 142 290 333 142 291 333 minecraft:dark_prismarine
fill 142 290 335 142 291 335 minecraft:dark_prismarine
fill 142 290 337 142 291 337 minecraft:dark_prismarine
fill 142 290 339 142 291 339 minecraft:dark_prismarine
setblock 142 290 347 minecraft:purple_concrete
fill 142 290 353 142 290 354 minecraft:blue_terracotta
setblock 142 290 355 minecraft:dark_prismarine
fill 142 290 356 142 293 356 minecraft:blue_terracotta
setblock 142 290 360 minecraft:dark_prismarine
fill 142 290 361 143 292 361 minecraft:blue_terracotta
fill 143 290 328 143 291 328 minecraft:dark_prismarine
fill 143 290 330 143 291 330 minecraft:dark_prismarine
fill 143 290 332 143 291 332 minecraft:dark_prismarine
fill 143 290 334 143 291 334 minecraft:dark_prismarine
fill 143 290 336 143 291 336 minecraft:dark_prismarine
fill 143 290 338 143 291 338 minecraft:dark_prismarine
setblock 143 290 359 minecraft:dark_prismarine
fill 143 290 360 143 293 360 minecraft:blue_terracotta
setblock 143 290 363 minecraft:blue_terracotta
fill 144 290 327 144 291 327 minecraft:dark_prismarine
fill 144 290 329 144 291 329 minecraft:dark_prismarine
fill 144 290 331 144 291 331 minecraft:dark_prismarine
fill 144 290 333 144 291 333 minecraft:dark_prismarine
fill 144 290 335 144 291 335 minecraft:dark_prismarine
fill 144 290 337 144 291 337 minecraft:dark_prismarine
fill 144 290 339 144 291 339 minecraft:dark_prismarine
setblock 144 290 363 minecraft:dark_prismarine
fill 145 290 328 145 291 328 minecraft:dark_prismarine
fill 145 290 330 145 291 330 minecraft:dark_prismarine
fill 145 290 332 145 291 332 minecraft:dark_prismarine
fill 145 290 334 145 291 334 minecraft:dark_prismarine
fill 145 290 336 145 291 336 minecraft:dark_prismarine
fill 145 290 338 145 291 338 minecraft:dark_prismarine
fill 145 290 363 148 290 363 minecraft:blue_terracotta
fill 146 290 327 146 291 327 minecraft:dark_prismarine
fill 146 290 329 146 291 329 minecraft:dark_prismarine
fill 146 290 331 146 291 331 minecraft:dark_prismarine
fill 146 290 333 146 291 333 minecraft:dark_prismarine
fill 146 290 335 146 291 335 minecraft:dark_prismarine
fill 146 290 337 146 291 337 minecraft:dark_prismarine
fill 146 290 339 146 291 339 minecraft:dark_prismarine
fill 147 290 328 147 291 328 minecraft:dark_prismarine
fill 147 290 330 147 291 330 minecraft:dark_prismarine
fill 147 290 332 147 291 332 minecraft:dark_prismarine
fill 147 290 334 147 291 334 minecraft:dark_prismarine
fill 147 290 336 147 291 336 minecraft:dark_prismarine
fill 147 290 338 147 291 338 minecraft:dark_prismarine
fill 147 290 362 149 290 362 minecraft:blue_terracotta
setblock 149 290 363 minecraft:dark_prismarine
setblock 150 290 362 minecraft:dark_prismarine
fill 150 290 363 150 293 363 minecraft:blue_terracotta
setblock 151 290 361 minecraft:dark_prismarine
fill 151 290 362 151 293 362 minecraft:blue_terracotta
fill 152 290 361 154 291 361 minecraft:blue_terracotta
fill 153 290 362 154 290 362 minecraft:blue_terracotta
setblock 154 290 323 minecraft:purple_concrete
setblock 154 290 346 minecraft:black_concrete
setblock 154 290 363 minecraft:dark_prismarine
setblock 155 290 349 minecraft:black_concrete
setblock 155 290 362 minecraft:dark_prismarine
fill 155 290 363 155 293 363 minecraft:blue_terracotta
setblock 156 290 346 minecraft:black_concrete
fill 156 290 362 156 293 362 minecraft:blue_terracotta
setblock 158 290 363 minecraft:blue_terracotta
setblock 169 290 323 minecraft:dark_prismarine
fill 169 290 359 169 298 359 minecraft:magenta_terracotta
setblock 169 290 363 minecraft:dark_prismarine
fill 170 290 323 173 290 323 minecraft:blue_terracotta
fill 170 290 363 173 290 363 minecraft:blue_terracotta
fill 171 290 362 174 290 362 minecraft:blue_terracotta
setblock 172 290 324 minecraft:blue_terracotta
setblock 173 290 324 minecraft:dark_prismarine
setblock 174 290 323 minecraft:dark_prismarine
fill 174 290 324 174 293 324 minecraft:blue_terracotta
fill 174 290 352 174 298 352 minecraft:black_concrete
setblock 174 290 363 minecraft:dark_prismarine
fill 175 290 323 175 293 323 minecraft:blue_terracotta
fill 175 290 354 175 298 354 minecraft:black_concrete
setblock 175 290 361 minecraft:blue_terracotta
setblock 175 290 362 minecraft:dark_prismarine
fill 175 290 363 175 293 363 minecraft:blue_terracotta
fill 176 290 352 176 298 353 minecraft:black_concrete
setblock 176 290 361 minecraft:dark_prismarine
fill 176 290 362 176 293 362 minecraft:blue_terracotta
setblock 179 290 323 minecraft:dark_prismarine
setblock 179 290 363 minecraft:dark_prismarine
fill 180 290 323 181 292 323 minecraft:blue_terracotta
setblock 180 290 362 minecraft:dark_prismarine
fill 180 290 363 180 293 363 minecraft:blue_terracotta
fill 181 290 358 181 292 358 minecraft:blue_terracotta
setblock 181 290 361 minecraft:dark_prismarine
fill 181 290 362 181 293 362 minecraft:blue_terracotta
setblock 182 290 339 minecraft:purple_concrete
setblock 182 290 355 minecraft:dark_prismarine
fill 182 290 356 182 293 356 minecraft:blue_terracotta
setblock 182 290 360 minecraft:dark_prismarine
fill 182 290 361 182 293 361 minecraft:blue_terracotta
fill 183 290 329 183 308 329 minecraft:blue_concrete
fill 183 290 336 183 308 336 minecraft:blue_concrete
fill 142 291 328 142 300 328 minecraft:dark_prismarine
setblock 142 291 334 minecraft:purple_concrete
setblock 142 291 353 minecraft:blue_terracotta
setblock 142 291 354 minecraft:dark_prismarine
fill 142 291 355 142 294 355 minecraft:blue_terracotta
setblock 142 291 359 minecraft:dark_prismarine
fill 142 291 360 142 294 360 minecraft:blue_terracotta
setblock 143 291 358 minecraft:dark_prismarine
fill 143 291 359 143 294 359 minecraft:blue_terracotta
setblock 143 291 362 minecraft:blue_terracotta
setblock 143 291 363 minecraft:dark_prismarine
setblock 144 291 362 minecraft:dark_prismarine
fill 144 291 363 147 291 363 minecraft:blue_terracotta
fill 145 291 362 148 291 362 minecraft:blue_terracotta
setblock 148 291 323 minecraft:purple_concrete
fill 148 291 361 149 291 361 minecraft:blue_terracotta
setblock 148 291 363 minecraft:dark_prismarine
setblock 149 291 362 minecraft:dark_prismarine
fill 149 291 363 149 294 363 minecraft:blue_terracotta
setblock 150 291 361 minecraft:dark_prismarine
fill 150 291 362 150 294 362 minecraft:blue_terracotta
fill 151 291 361 151 294 361 minecraft:blue_terracotta
setblock 152 291 323 minecraft:blue_terracotta
setblock 153 291 323 minecraft:dark_prismarine
setblock 153 291 362 minecraft:blue_terracotta
setblock 153 291 363 minecraft:dark_prismarine
fill 154 291 323 154 294 323 minecraft:blue_terracotta
setblock 154 291 362 minecraft:dark_prismarine
fill 154 291 363 154 294 363 minecraft:blue_terracotta
setblock 155 291 361 minecraft:dark_prismarine
fill 155 291 362 155 294 362 minecraft:blue_terracotta
setblock 158 291 363 minecraft:dark_prismarine
setblock 167 291 323 minecraft:purple_concrete
setblock 168 291 323 minecraft:dark_prismarine
setblock 168 291 363 minecraft:dark_prismarine
fill 169 291 323 172 291 323 minecraft:blue_terracotta
fill 169 291 329 169 297 329 minecraft:magenta_terracotta
fill 169 291 363 172 291 363 minecraft:blue_terracotta
fill 170 291 324 171 291 324 minecraft:blue_terracotta
fill 170 291 362 173 291 362 minecraft:blue_terracotta
setblock 172 291 324 minecraft:dark_prismarine
fill 172 291 361 174 291 361 minecraft:blue_terracotta
setblock 173 291 323 minecraft:dark_prismarine
fill 173 291 324 173 294 324 minecraft:blue_terracotta
fill 173 291 353 173 298 353 minecraft:black_concrete
setblock 173 291 363 minecraft:dark_prismarine
fill 174 291 323 174 294 323 minecraft:blue_terracotta
fill 174 291 354 174 298 354 minecraft:black_concrete
setblock 174 291 362 minecraft:dark_prismarine
fill 174 291 363 174 294 363 minecraft:blue_terracotta
fill 175 291 351 175 298 351 minecraft:black_concrete
setblock 175 291 361 minecraft:dark_prismarine
fill 175 291 362 175 294 362 minecraft:blue_terracotta
fill 176 291 354 176 298 354 minecraft:black_concrete
fill 176 291 361 178 292 361 minecraft:blue_terracotta
setblock 177 291 324 minecraft:dark_prismarine
setblock 178 291 323 minecraft:dark_prismarine
fill 178 291 324 178 294 324 minecraft:blue_terracotta
setblock 178 291 363 minecraft:dark_prismarine
fill 179 291 323 179 294 323 minecraft:blue_terracotta
setblock 179 291 362 minecraft:dark_prismarine
fill 179 291 363 179 294 363 minecraft:blue_terracotta
fill 180 291 362 180 294 362 minecraft:blue_terracotta
setblock 181 291 359 minecraft:blue_terracotta
setblock 181 291 360 minecraft:dark_prismarine
fill 181 291 361 181 294 361 minecraft:blue_terracotta
setblock 182 291 323 minecraft:blue_terracotta
setblock 182 291 333 minecraft:purple_concrete
setblock 182 291 352 minecraft:purple_concrete
fill 182 291 355 182 294 355 minecraft:blue_terracotta
setblock 182 291 359 minecraft:dark_prismarine
fill 182 291 360 182 294 360 minecraft:blue_terracotta
fill 141 292 339 141 308 340 minecraft:blue_concrete
setblock 141 292 341 minecraft:light_blue_wool
fill 141 292 342 141 308 342 minecraft:blue_concrete
setblock 142 292 327 minecraft:sea_lantern
setblock 142 292 329 minecraft:sea_lantern
setblock 142 292 331 minecraft:sea_lantern
setblock 142 292 333 minecraft:sea_lantern
fill 142 292 334 142 300 334 minecraft:dark_prismarine
setblock 142 292 335 minecraft:sea_lantern
setblock 142 292 337 minecraft:sea_lantern
setblock 142 292 339 minecraft:sea_lantern
setblock 142 292 340 minecraft:purple_concrete
setblock 142 292 353 minecraft:dark_prismarine
fill 142 292 354 142 295 354 minecraft:blue_terracotta
setblock 142 292 358 minecraft:dark_prismarine
fill 142 292 359 142 295 359 minecraft:blue_terracotta
setblock 142 292 363 minecraft:dark_prismarine
setblock 143 292 328 minecraft:sea_lantern
setblock 143 292 330 minecraft:sea_lantern
setblock 143 292 332 minecraft:sea_lantern
setblock 143 292 334 minecraft:sea_lantern
setblock 143 292 336 minecraft:sea_lantern
setblock 143 292 338 minecraft:sea_lantern
setblock 143 292 357 minecraft:dark_prismarine
fill 143 292 358 143 295 358 minecraft:blue_terracotta
setblock 143 292 362 minecraft:dark_prismarine
fill 143 292 363 146 292 363 minecraft:blue_terracotta
setblock 144 292 327 minecraft:sea_lantern
setblock 144 292 329 minecraft:sea_lantern
setblock 144 292 331 minecraft:sea_lantern
setblock 144 292 333 minecraft:sea_lantern
setblock 144 292 335 minecraft:sea_lantern
setblock 144 292 337 minecraft:sea_lantern
setblock 144 292 339 minecraft:sea_lantern
fill 144 292 362 147 292 362 minecraft:blue_terracotta
fill 144 292 364 144 308 364 minecraft:blue_concrete
setblock 145 292 328 minecraft:sea_lantern
setblock 145 292 330 minecraft:sea_lantern
setblock 145 292 332 minecraft:sea_lantern
setblock 145 292 334 minecraft:sea_lantern
setblock 145 292 336 minecraft:sea_lantern
setblock 145 292 338 minecraft:sea_lantern
setblock 145 292 364 minecraft:cyan_concrete
fill 146 292 322 146 308 322 minecraft:blue_concrete
setblock 146 292 327 minecraft:sea_lantern
setblock 146 292 329 minecraft:sea_lantern
setblock 146 292 331 minecraft:sea_lantern
setblock 146 292 333 minecraft:sea_lantern
setblock 146 292 335 minecraft:sea_lantern
setblock 146 292 337 minecraft:sea_lantern
setblock 146 292 339 minecraft:sea_lantern
fill 146 292 361 148 292 361 minecraft:blue_terracotta
fill 146 292 364 146 308 364 minecraft:blue_concrete
setblock 147 292 322 minecraft:cyan_concrete
setblock 147 292 328 minecraft:sea_lantern
setblock 147 292 330 minecraft:sea_lantern
setblock 147 292 332 minecraft:sea_lantern
setblock 147 292 334 minecraft:sea_lantern
setblock 147 292 336 minecraft:sea_lantern
setblock 147 292 338 minecraft:sea_lantern
setblock 147 292 363 minecraft:dark_prismarine
fill 148 292 322 149 308 322 minecraft:blue_concrete
fill 148 292 341 148 298 341 minecraft:magenta_terracotta
setblock 148 292 362 minecraft:dark_prismarine
fill 148 292 363 148 295 363 minecraft:blue_terracotta
fill 149 292 323 151 292 323 minecraft:blue_terracotta
setblock 149 292 361 minecraft:dark_prismarine
fill 149 292 362 149 295 362 minecraft:blue_terracotta
fill 150 292 361 150 295 361 minecraft:blue_terracotta
fill 151 292 360 152 293 360 minecraft:blue_terracotta
setblock 152 292 323 minecraft:dark_prismarine
fill 152 292 361 153 292 361 minecraft:blue_terracotta
setblock 152 292 363 minecraft:dark_prismarine
fill 153 292 323 153 295 323 minecraft:blue_terracotta
setblock 153 292 362 minecraft:dark_prismarine
fill 153 292 363 153 295 363 minecraft:blue_terracotta
setblock 154 292 361 minecraft:dark_prismarine
fill 154 292 362 154 295 362 minecraft:blue_terracotta
fill 155 292 323 156 292 323 minecraft:blue_terracotta
fill 155 292 361 155 294 361 minecraft:blue_terracotta
setblock 157 292 362 minecraft:blue_terracotta
setblock 157 292 363 minecraft:dark_prismarine
fill 158 292 357 158 293 357 minecraft:spruce_planks
fill 158 292 363 159 294 363 minecraft:blue_terracotta
setblock 161 292 323 minecraft:purple_concrete
setblock 163 292 363 minecraft:purple_concrete
setblock 166 292 323 minecraft:blue_terracotta
setblock 166 292 363 minecraft:blue_terracotta
setblock 167 292 323 minecraft:dark_prismarine
setblock 167 292 363 minecraft:dark_prismarine
fill 168 292 323 171 292 323 minecraft:blue_terracotta
setblock 168 292 362 minecraft:dark_prismarine
fill 168 292 363 171 292 363 minecraft:blue_terracotta
fill 169 292 324 170 292 324 minecraft:blue_terracotta
fill 169 292 362 172 292 362 minecraft:blue_terracotta
setblock 171 292 324 minecraft:dark_prismarine
fill 171 292 361 173 292 361 minecraft:blue_terracotta
setblock 172 292 323 minecraft:dark_prismarine
fill 172 292 324 172 294 325 minecraft:blue_terracotta
setblock 172 292 363 minecraft:dark_prismarine
fill 173 292 323 173 295 323 minecraft:blue_terracotta
fill 173 292 325 174 292 325 minecraft:blue_terracotta
fill 173 292 352 173 298 352 minecraft:black_concrete
fill 173 292 354 173 298 354 minecraft:black_concrete
setblock 173 292 362 minecraft:dark_prismarine
fill 173 292 363 173 295 363 minecraft:blue_terracotta
fill 174 292 351 174 298 351 minecraft:black_concrete
fill 174 292 355 175 298 355 minecraft:black_concrete
setblock 174 292 361 minecraft:dark_prismarine
fill 174 292 362 174 295 362 minecraft:blue_terracotta
fill 175 292 361 175 295 361 minecraft:blue_terracotta
setblock 176 292 324 minecraft:dark_prismarine
fill 176 292 351 176 298 351 minecraft:black_concrete
setblock 177 292 323 minecraft:dark_prismarine
fill 177 292 324 177 295 324 minecraft:blue_terracotta
fill 177 292 352 177 298 353 minecraft:black_concrete
setblock 177 292 363 minecraft:dark_prismarine
fill 178 292 323 178 295 323 minecraft:blue_terracotta
setblock 178 292 362 minecraft:dark_prismarine
fill 178 292 363 178 295 363 minecraft:blue_terracotta
setblock 179 292 361 minecraft:dark_prismarine
fill 179 292 362 179 295 362 minecraft:blue_terracotta
setblock 181 292 359 minecraft:dark_prismarine
fill 181 292 360 181 295 360 minecraft:blue_terracotta
setblock 182 292 323 minecraft:dark_prismarine
setblock 182 292 327 minecraft:purple_concrete
setblock 182 292 346 minecraft:purple_concrete
setblock 182 292 358 minecraft:dark_prismarine
fill 182 292 359 182 295 359 minecraft:blue_terracotta
setblock 182 292 363 minecraft:dark_prismarine
setblock 183 292 327 minecraft:light_blue_wool
fill 141 293 341 141 308 341 minecraft:blue_concrete
setblock 142 293 327 minecraft:dark_prismarine
fill 142 293 329 142 294 329 minecraft:dark_prismarine
fill 142 293 331 142 294 331 minecraft:dark_prismarine
fill 142 293 333 142 294 333 minecraft:dark_prismarine
fill 142 293 335 142 294 335 minecraft:dark_prismarine
fill 142 293 337 142 294 337 minecraft:dark_prismarine
fill 142 293 338 142 293 341 minecraft:blue_terracotta
setblock 142 293 342 minecraft:dark_prismarine
fill 142 293 343 142 296 343 minecraft:blue_terracotta
setblock 142 293 346 minecraft:purple_concrete
fill 142 293 353 142 296 353 minecraft:blue_terracotta
setblock 142 293 357 minecraft:dark_prismarine
fill 142 293 358 142 296 358 minecraft:blue_terracotta
setblock 142 293 361 minecraft:blue_terracotta
setblock 142 293 362 minecraft:dark_prismarine
fill 142 293 363 145 293 363 minecraft:blue_terracotta
fill 143 293 328 143 294 328 minecraft:dark_prismarine
fill 143 293 330 143 294 330 minecraft:dark_prismarine
fill 143 293 332 143 294 332 minecraft:dark_prismarine
fill 143 293 334 143 294 334 minecraft:dark_prismarine
fill 143 293 336 143 294 336 minecraft:dark_prismarine
fill 143 293 338 143 294 338 minecraft:dark_prismarine
setblock 143 293 356 minecraft:dark_prismarine
fill 143 293 357 143 296 357 minecraft:blue_terracotta
setblock 143 293 361 minecraft:dark_prismarine
fill 143 293 362 146 293 362 minecraft:blue_terracotta
setblock 144 293 325 minecraft:light[level=13]
fill 144 293 327 144 294 327 minecraft:dark_prismarine
fill 144 293 329 144 294 329 minecraft:dark_prismarine
fill 144 293 331 144 294 331 minecraft:dark_prismarine
fill 144 293 333 144 294 333 minecraft:dark_prismarine
fill 144 293 335 144 294 335 minecraft:dark_prismarine
fill 144 293 337 144 294 337 minecraft:dark_prismarine
fill 144 293 339 144 294 339 minecraft:dark_prismarine
setblock 144 293 341 minecraft:light[level=13]
setblock 144 293 346 minecraft:light[level=12]
setblock 144 293 349 minecraft:light[level=13]
setblock 144 293 353 minecraft:light[level=12]
setblock 144 293 357 minecraft:light[level=13]
setblock 144 293 359 minecraft:blue_terracotta
setblock 144 293 360 minecraft:dark_prismarine
fill 144 293 361 147 293 361 minecraft:blue_terracotta
fill 145 293 328 145 294 328 minecraft:dark_prismarine
fill 145 293 330 145 294 330 minecraft:dark_prismarine
fill 145 293 332 145 294 332 minecraft:dark_prismarine
fill 145 293 334 145 294 334 minecraft:dark_prismarine
fill 145 293 336 145 294 336 minecraft:dark_prismarine
fill 145 293 338 145 294 338 minecraft:dark_prismarine
fill 145 293 364 145 308 364 minecraft:blue_concrete
fill 146 293 327 146 294 327 minecraft:dark_prismarine
fill 146 293 329 146 294 329 minecraft:dark_prismarine
fill 146 293 331 146 294 331 minecraft:dark_prismarine
fill 146 293 333 146 294 333 minecraft:dark_prismarine
fill 146 293 335 146 294 335 minecraft:dark_prismarine
fill 146 293 337 146 294 337 minecraft:dark_prismarine
fill 146 293 339 146 294 339 minecraft:dark_prismarine
setblock 146 293 363 minecraft:dark_prismarine
fill 147 293 322 147 308 322 minecraft:blue_concrete
fill 147 293 323 150 293 323 minecraft:blue_terracotta
fill 147 293 328 147 294 328 minecraft:dark_prismarine
fill 147 293 330 147 294 330 minecraft:dark_prismarine
fill 147 293 332 147 294 332 minecraft:dark_prismarine
fill 147 293 334 147 294 334 minecraft:dark_prismarine
fill 147 293 336 147 294 336 minecraft:dark_prismarine
fill 147 293 338 147 294 338 minecraft:dark_prismarine
setblock 147 293 362 minecraft:dark_prismarine
fill 147 293 363 147 296 363 minecraft:blue_terracotta
setblock 148 293 361 minecraft:dark_prismarine
fill 148 293 362 148 296 362 minecraft:blue_terracotta
setblock 149 293 360 minecraft:dark_prismarine
fill 149 293 361 149 296 361 minecraft:blue_terracotta
fill 150 293 360 150 295 360 minecraft:blue_terracotta
setblock 151 293 323 minecraft:dark_prismarine
setblock 151 293 325 minecraft:light[level=12]
setblock 151 293 332 minecraft:light[level=12]
setblock 151 293 339 minecraft:light[level=12]
setblock 151 293 346 minecraft:light[level=12]
setblock 151 293 353 minecraft:light[level=12]
setblock 151 293 363 minecraft:dark_prismarine
fill 152 293 323 152 296 323 minecraft:blue_terracotta
setblock 152 293 325 minecraft:light[level=13]
setblock 152 293 333 minecraft:light[level=13]
setblock 152 293 341 minecraft:light[level=13]
setblock 152 293 349 minecraft:light[level=13]
setblock 152 293 357 minecraft:light[level=13]
setblock 152 293 361 minecraft:blue_terracotta
setblock 152 293 362 minecraft:dark_prismarine
fill 152 293 363 152 296 363 minecraft:blue_terracotta
setblock 153 293 361 minecraft:dark_prismarine
fill 153 293 362 153 296 362 minecraft:blue_terracotta
fill 154 293 361 154 295 361 minecraft:blue_terracotta
setblock 155 293 323 minecraft:blue_terracotta
setblock 156 293 323 minecraft:dark_prismarine
setblock 156 293 363 minecraft:dark_prismarine
fill 157 293 323 157 296 323 minecraft:blue_terracotta
setblock 157 293 362 minecraft:dark_prismarine
fill 157 293 363 157 296 363 minecraft:blue_terracotta
setblock 158 293 325 minecraft:light[level=12]
setblock 158 293 332 minecraft:light[level=12]
setblock 158 293 339 minecraft:light[level=12]
setblock 158 293 346 minecraft:light[level=12]
setblock 158 293 353 minecraft:light[level=12]
setblock 158 293 360 minecraft:light[level=12]
setblock 160 293 325 minecraft:light[level=13]
setblock 160 293 333 minecraft:light[level=13]
setblock 160 293 341 minecraft:light[level=13]
setblock 160 293 349 minecraft:light[level=13]
setblock 160 293 357 minecraft:light[level=13]
fill 164 293 323 165 293 323 minecraft:blue_terracotta
fill 164 293 363 165 293 363 minecraft:blue_terracotta
setblock 165 293 325 minecraft:light[level=12]
setblock 165 293 332 minecraft:light[level=12]
setblock 165 293 339 minecraft:light[level=12]
setblock 165 293 346 minecraft:light[level=12]
setblock 165 293 353 minecraft:light[level=12]
setblock 165 293 360 minecraft:light[level=12]
setblock 166 293 323 minecraft:dark_prismarine
setblock 166 293 363 minecraft:dark_prismarine
fill 167 293 323 169 293 324 minecraft:blue_terracotta
setblock 167 293 362 minecraft:dark_prismarine
fill 167 293 363 170 293 363 minecraft:blue_terracotta
setblock 168 293 325 minecraft:light[level=13]
setblock 168 293 333 minecraft:light[level=13]
setblock 168 293 341 minecraft:light[level=13]
setblock 168 293 349 minecraft:light[level=13]
setblock 168 293 357 minecraft:light[level=13]
fill 168 293 362 171 293 362 minecraft:blue_terracotta
setblock 170 293 323 minecraft:blue_terracotta
setblock 170 293 324 minecraft:dark_prismarine
fill 170 293 325 171 295 325 minecraft:blue_terracotta
fill 170 293 361 172 293 361 minecraft:blue_terracotta
setblock 171 293 323 minecraft:dark_prismarine
fill 171 293 324 171 296 324 minecraft:blue_terracotta
setblock 171 293 363 minecraft:dark_prismarine
fill 172 293 323 172 296 323 minecraft:blue_terracotta
setblock 172 293 332 minecraft:light[level=12]
setblock 172 293 339 minecraft:light[level=12]
setblock 172 293 346 minecraft:light[level=12]
fill 172 293 353 172 298 353 minecraft:black_concrete
setblock 172 293 360 minecraft:light[level=12]
setblock 172 293 362 minecraft:dark_prismarine
fill 172 293 363 172 296 363 minecraft:blue_terracotta
setblock 173 293 325 minecraft:blue_terracotta
fill 173 293 351 173 298 351 minecraft:black_concrete
fill 173 293 355 173 298 355 minecraft:black_concrete
setblock 173 293 361 minecraft:dark_prismarine
fill 173 293 362 173 296 362 minecraft:blue_terracotta
setblock 174 293 325 minecraft:dark_prismarine
fill 174 293 361 174 296 361 minecraft:blue_terracotta
setblock 175 293 324 minecraft:dark_prismarine
fill 175 293 325 175 296 325 minecraft:blue_terracotta
fill 175 293 350 175 298 350 minecraft:black_concrete
setblock 176 293 323 minecraft:dark_prismarine
fill 176 293 324 176 296 324 minecraft:blue_terracotta
setblock 176 293 325 minecraft:light[level=13]
setblock 176 293 333 minecraft:light[level=13]
setblock 176 293 341 minecraft:light[level=13]
setblock 176 293 349 minecraft:light[level=13]
fill 176 293 355 176 298 355 minecraft:black_concrete
setblock 176 293 357 minecraft:light[level=13]
fill 176 293 361 177 293 361 minecraft:blue_terracotta
setblock 176 293 363 minecraft:dark_prismarine
fill 177 293 323 177 296 323 minecraft:blue_terracotta
fill 177 293 344 177 297 344 minecraft:magenta_terracotta
fill 177 293 351 177 298 351 minecraft:black_concrete
fill 177 293 354 177 298 354 minecraft:black_concrete
setblock 177 293 362 minecraft:dark_prismarine
fill 177 293 363 177 296 363 minecraft:blue_terracotta
setblock 178 293 361 minecraft:dark_prismarine
fill 178 293 362 178 296 362 minecraft:blue_terracotta
setblock 178 293 364 minecraft:light_blue_wool
setblock 179 293 324 minecraft:blue_terracotta
setblock 179 293 325 minecraft:light[level=12]
setblock 179 293 332 minecraft:light[level=12]
setblock 179 293 339 minecraft:light[level=12]
setblock 179 293 346 minecraft:light[level=12]
setblock 179 293 353 minecraft:light[level=12]
setblock 179 293 360 minecraft:light[level=12]
fill 179 293 361 180 295 361 minecraft:blue_terracotta
setblock 180 293 323 minecraft:blue_terracotta
setblock 181 293 323 minecraft:dark_prismarine
setblock 181 293 358 minecraft:dark_prismarine
fill 181 293 359 181 296 359 minecraft:blue_terracotta
setblock 181 293 363 minecraft:dark_prismarine
fill 182 293 323 182 295 324 minecraft:blue_terracotta
setblock 182 293 340 minecraft:purple_concrete
setblock 182 293 357 minecraft:dark_prismarine
fill 182 293 358 182 296 358 minecraft:blue_terracotta
setblock 182 293 362 minecraft:dark_prismarine
fill 182 293 363 182 296 363 minecraft:blue_terracotta
fill 183 293 327 183 308 327 minecraft:blue_concrete
setblock 142 294 327 minecraft:purple_concrete
fill 142 294 338 142 294 340 minecraft:blue_terracotta
setblock 142 294 341 minecraft:dark_prismarine
fill 142 294 342 142 297 342 minecraft:blue_terracotta
fill 142 294 344 142 294 345 minecraft:blue_terracotta
setblock 142 294 346 minecraft:dark_prismarine
setblock 142 294 352 minecraft:purple_concrete
setblock 142 294 356 minecraft:dark_prismarine
fill 142 294 357 142 297 357 minecraft:blue_terracotta
setblock 142 294 361 minecraft:dark_prismarine
fill 142 294 362 144 294 363 minecraft:blue_terracotta
fill 143 294 356 143 295 356 minecraft:blue_terracotta
setblock 143 294 360 minecraft:dark_prismarine
fill 143 294 361 146 294 361 minecraft:blue_terracotta
setblock 144 294 359 minecraft:dark_prismarine
fill 144 294 360 144 296 360 minecraft:blue_terracotta
setblock 145 294 323 minecraft:dark_prismarine
setblock 145 294 362 minecraft:blue_terracotta
setblock 145 294 363 minecraft:dark_prismarine
fill 146 294 323 149 294 323 minecraft:blue_terracotta
setblock 146 294 362 minecraft:dark_prismarine
fill 146 294 363 146 297 363 minecraft:blue_terracotta
setblock 147 294 361 minecraft:dark_prismarine
fill 147 294 362 147 297 362 minecraft:blue_terracotta
fill 148 294 361 148 297 361 minecraft:blue_terracotta
fill 149 294 360 149 295 360 minecraft:blue_terracotta
setblock 150 294 323 minecraft:dark_prismarine
setblock 150 294 363 minecraft:dark_prismarine
fill 151 294 323 151 297 323 minecraft:blue_terracotta
setblock 151 294 360 minecraft:blue_terracotta
setblock 151 294 362 minecraft:dark_prismarine
fill 151 294 363 151 297 363 minecraft:blue_terracotta
fill 152 294 324 152 295 324 minecraft:blue_terracotta
setblock 152 294 361 minecraft:dark_prismarine
fill 152 294 362 152 297 362 minecraft:blue_terracotta
fill 153 294 361 153 296 361 minecraft:blue_terracotta
setblock 155 294 323 minecraft:dark_prismarine
setblock 155 294 363 minecraft:dark_prismarine
fill 156 294 323 156 297 323 minecraft:blue_terracotta
setblock 156 294 362 minecraft:dark_prismarine
fill 156 294 363 156 297 363 minecraft:blue_terracotta
setblock 157 294 362 minecraft:blue_terracotta
fill 158 294 323 158 295 323 minecraft:blue_terracotta
setblock 160 294 363 minecraft:dark_prismarine
fill 162 294 323 164 294 323 minecraft:blue_terracotta
fill 163 294 363 164 294 363 minecraft:blue_terracotta
setblock 165 294 323 minecraft:dark_prismarine
setblock 165 294 363 minecraft:dark_prismarine
fill 166 294 323 168 294 324 minecraft:blue_terracotta
setblock 166 294 362 minecraft:dark_prismarine
fill 166 294 363 169 294 363 minecraft:blue_terracotta
fill 167 294 362 170 294 362 minecraft:blue_terracotta
setblock 169 294 323 minecraft:blue_terracotta
setblock 169 294 324 minecraft:dark_prismarine
fill 169 294 325 169 297 325 minecraft:blue_terracotta
fill 169 294 361 171 294 361 minecraft:blue_terracotta
setblock 170 294 323 minecraft:dark_prismarine
fill 170 294 324 170 297 324 minecraft:blue_terracotta
setblock 170 294 363 minecraft:dark_prismarine
fill 171 294 323 171 297 323 minecraft:blue_terracotta
setblock 171 294 362 minecraft:dark_prismarine
fill 171 294 363 171 297 363 minecraft:blue_terracotta
fill 172 294 348 182 295 348 minecraft:dark_prismarine
fill 172 294 351 172 298 352 minecraft:black_concrete
fill 172 294 354 172 298 354 minecraft:black_concrete
setblock 172 294 361 minecraft:dark_prismarine
fill 172 294 362 172 297 362 minecraft:blue_terracotta
setblock 173 294 325 minecraft:dark_prismarine
fill 173 294 350 174 298 350 minecraft:black_concrete
fill 173 294 361 173 297 361 minecraft:blue_terracotta
setblock 174 294 324 minecraft:dark_prismarine
fill 174 294 325 174 297 325 minecraft:blue_terracotta
fill 174 294 356 175 298 356 minecraft:black_concrete
setblock 175 294 322 minecraft:light_blue_wool
setblock 175 294 323 minecraft:dark_prismarine
fill 175 294 324 175 297 324 minecraft:blue_terracotta
setblock 175 294 363 minecraft:dark_prismarine
fill 176 294 323 176 297 323 minecraft:blue_terracotta
fill 176 294 325 176 295 325 minecraft:blue_terracotta
fill 176 294 350 176 298 350 minecraft:black_concrete
setblock 176 294 361 minecraft:blue_terracotta
setblock 176 294 362 minecraft:dark_prismarine
fill 176 294 363 176 297 363 minecraft:blue_terracotta
fill 177 294 355 177 298 355 minecraft:black_concrete
setblock 177 294 361 minecraft:dark_prismarine
fill 177 294 362 177 297 362 minecraft:blue_terracotta
fill 178 294 349 182 295 349 minecraft:dark_prismarine
fill 178 294 352 178 298 354 minecraft:black_concrete
fill 178 294 361 178 296 361 minecraft:blue_terracotta
fill 178 294 364 178 308 364 minecraft:blue_concrete
setblock 179 294 324 minecraft:dark_prismarine
setblock 180 294 323 minecraft:dark_prismarine
setblock 180 294 363 minecraft:dark_prismarine
fill 181 294 323 181 297 323 minecraft:blue_terracotta
fill 181 294 358 181 295 358 minecraft:blue_terracotta
setblock 181 294 362 minecraft:dark_prismarine
fill 181 294 363 181 297 363 minecraft:blue_terracotta
setblock 182 294 325 minecraft:blue_terracotta
setblock 182 294 334 minecraft:purple_concrete
fill 182 294 339 182 294 340 minecraft:blue_terracotta
fill 182 294 353 182 295 353 minecraft:purple_concrete
setblock 182 294 356 minecraft:dark_prismarine
fill 182 294 357 182 297 357 minecraft:blue_terracotta
setblock 182 294 361 minecraft:dark_prismarine
fill 182 294 362 182 297 362 minecraft:blue_terracotta
fill 142 295 323 143 295 323 minecraft:blue_terracotta
setblock 142 295 327 minecraft:sea_lantern
setblock 142 295 329 minecraft:sea_lantern
setblock 142 295 331 minecraft:sea_lantern
setblock 142 295 333 minecraft:sea_lantern
setblock 142 295 335 minecraft:sea_lantern
setblock 142 295 337 minecraft:sea_lantern
fill 142 295 338 142 296 338 minecraft:blue_terracotta
setblock 142 295 339 minecraft:sea_lantern
setblock 142 295 340 minecraft:dark_prismarine
fill 142 295 341 143 297 341 minecraft:blue_terracotta
setblock 142 295 344 minecraft:blue_terracotta
setblock 142 295 345 minecraft:dark_prismarine
fill 142 295 346 142 296 348 minecraft:blue_terracotta
fill 142 295 352 142 297 352 minecraft:blue_terracotta
setblock 142 295 355 minecraft:dark_prismarine
fill 142 295 356 142 298 356 minecraft:blue_terracotta
setblock 142 295 360 minecraft:dark_prismarine
fill 142 295 361 143 295 363 minecraft:blue_terracotta
setblock 143 295 328 minecraft:sea_lantern
setblock 143 295 330 minecraft:sea_lantern
setblock 143 295 332 minecraft:sea_lantern
setblock 143 295 334 minecraft:sea_lantern
setblock 143 295 336 minecraft:sea_lantern
setblock 143 295 338 minecraft:sea_lantern
fill 143 295 340 143 297 340 minecraft:blue_terracotta
fill 143 295 342 143 295 343 minecraft:blue_terracotta
setblock 143 295 344 minecraft:dark_prismarine
setblock 143 295 359 minecraft:dark_prismarine
fill 143 295 360 143 298 360 minecraft:blue_terracotta
setblock 144 295 323 minecraft:dark_prismarine
setblock 144 295 327 minecraft:sea_lantern
setblock 144 295 329 minecraft:sea_lantern
setblock 144 295 331 minecraft:sea_lantern
setblock 144 295 333 minecraft:sea_lantern
setblock 144 295 335 minecraft:sea_lantern
setblock 144 295 337 minecraft:sea_lantern
setblock 144 295 339 minecraft:sea_lantern
setblock 144 295 359 minecraft:blue_terracotta
fill 144 295 361 144 295 362 minecraft:blue_terracotta
setblock 144 295 363 minecraft:dark_prismarine
fill 145 295 323 148 295 323 minecraft:blue_terracotta
setblock 145 295 328 minecraft:sea_lantern
setblock 145 295 330 minecraft:sea_lantern
setblock 145 295 332 minecraft:sea_lantern
setblock 145 295 334 minecraft:sea_lantern
setblock 145 295 336 minecraft:sea_lantern
setblock 145 295 338 minecraft:sea_lantern
setblock 145 295 361 minecraft:blue_terracotta
setblock 145 295 362 minecraft:dark_prismarine
fill 145 295 363 145 298 363 minecraft:blue_terracotta
setblock 146 295 327 minecraft:sea_lantern
setblock 146 295 329 minecraft:sea_lantern
setblock 146 295 331 minecraft:sea_lantern
setblock 146 295 333 minecraft:sea_lantern
setblock 146 295 335 minecraft:sea_lantern
setblock 146 295 337 minecraft:sea_lantern
setblock 146 295 339 minecraft:sea_lantern
setblock 146 295 361 minecraft:dark_prismarine
fill 146 295 362 146 298 362 minecraft:blue_terracotta
setblock 147 295 328 minecraft:sea_lantern
setblock 147 295 330 minecraft:sea_lantern
setblock 147 295 332 minecraft:sea_lantern
setblock 147 295 334 minecraft:sea_lantern
setblock 147 295 336 minecraft:sea_lantern
setblock 147 295 338 minecraft:sea_lantern
fill 147 295 361 147 298 361 minecraft:blue_terracotta
setblock 149 295 323 minecraft:dark_prismarine
fill 149 295 324 151 296 324 minecraft:blue_terracotta
setblock 149 295 363 minecraft:dark_prismarine
fill 150 295 323 150 298 323 minecraft:blue_terracotta
setblock 150 295 362 minecraft:dark_prismarine
fill 150 295 363 150 298 363 minecraft:blue_terracotta
setblock 151 295 361 minecraft:dark_prismarine
fill 151 295 362 151 298 362 minecraft:blue_terracotta
fill 152 295 361 152 296 361 minecraft:blue_terracotta
setblock 153 295 324 minecraft:dark_prismarine
setblock 154 295 323 minecraft:dark_prismarine
setblock 154 295 363 minecraft:dark_prismarine
fill 155 295 323 155 298 323 minecraft:blue_terracotta
setblock 155 295 362 minecraft:dark_prismarine
fill 155 295 363 155 298 363 minecraft:blue_terracotta
setblock 156 295 362 minecraft:blue_terracotta
fill 157 295 347 159 296 347 minecraft:dark_prismarine
setblock 158 295 363 minecraft:blue_terracotta
setblock 159 295 323 minecraft:dark_prismarine
setblock 159 295 363 minecraft:dark_prismarine
fill 160 295 323 163 295 323 minecraft:blue_terracotta
fill 160 295 363 163 295 363 minecraft:blue_terracotta
fill 162 295 348 171 295 348 minecraft:dark_prismarine
fill 163 295 347 173 295 347 minecraft:dark_prismarine
setblock 164 295 323 minecraft:dark_prismarine
setblock 164 295 363 minecraft:dark_prismarine
fill 165 295 323 167 295 324 minecraft:blue_terracotta
fill 165 295 363 168 295 363 minecraft:blue_terracotta
fill 166 295 362 169 295 362 minecraft:blue_terracotta
setblock 167 295 325 minecraft:dark_prismarine
setblock 168 295 323 minecraft:blue_terracotta
setblock 168 295 324 minecraft:dark_prismarine
fill 168 295 325 168 298 325 minecraft:blue_terracotta
fill 168 295 361 170 295 361 minecraft:blue_terracotta
setblock 169 295 323 minecraft:dark_prismarine
fill 169 295 324 169 298 324 minecraft:blue_terracotta
setblock 169 295 363 minecraft:dark_prismarine
fill 170 295 323 170 298 323 minecraft:blue_terracotta
setblock 170 295 362 minecraft:dark_prismarine
fill 170 295 363 170 298 363 minecraft:blue_terracotta
fill 171 295 353 171 298 353 minecraft:black_concrete
setblock 171 295 361 minecraft:dark_prismarine
fill 171 295 362 171 298 362 minecraft:blue_terracotta
setblock 172 295 324 minecraft:blue_terracotta
setblock 172 295 325 minecraft:dark_prismarine
fill 172 295 355 172 298 355 minecraft:black_concrete
fill 172 295 361 172 298 361 minecraft:blue_terracotta
setblock 173 295 324 minecraft:dark_prismarine
fill 173 295 325 173 298 325 minecraft:blue_terracotta
fill 173 295 356 173 298 356 minecraft:black_concrete
setblock 174 295 323 minecraft:dark_prismarine
fill 174 295 324 174 298 324 minecraft:blue_terracotta
setblock 174 295 349 minecraft:dark_prismarine
setblock 174 295 363 minecraft:dark_prismarine
fill 175 295 322 175 308 322 minecraft:blue_concrete
fill 175 295 323 175 298 323 minecraft:blue_terracotta
fill 175 295 349 175 298 349 minecraft:black_concrete
setblock 175 295 362 minecraft:dark_prismarine
fill 175 295 363 175 298 363 minecraft:blue_terracotta
fill 176 295 345 176 297 345 minecraft:magenta_terracotta
fill 176 295 349 177 295 349 minecraft:dark_prismarine
fill 176 295 356 177 298 356 minecraft:black_concrete
setblock 176 295 361 minecraft:dark_prismarine
fill 176 295 362 176 298 362 minecraft:blue_terracotta
fill 177 295 350 177 298 350 minecraft:black_concrete
fill 177 295 361 177 296 361 minecraft:blue_terracotta
setblock 178 295 324 minecraft:dark_prismarine
fill 178 295 351 178 298 351 minecraft:black_concrete
fill 178 295 355 178 298 355 minecraft:black_concrete
setblock 179 295 323 minecraft:dark_prismarine
fill 179 295 324 179 297 324 minecraft:blue_terracotta
setblock 179 295 363 minecraft:dark_prismarine
fill 180 295 323 180 298 323 minecraft:blue_terracotta
setblock 180 295 362 minecraft:dark_prismarine
fill 180 295 363 180 298 363 minecraft:blue_terracotta
setblock 181 295 361 minecraft:dark_prismarine
fill 181 295 362 181 298 362 minecraft:blue_terracotta
setblock 182 295 325 minecraft:dark_prismarine
setblock 182 295 328 minecraft:purple_concrete
setblock 182 295 340 minecraft:dark_prismarine
fill 182 295 341 182 296 342 minecraft:blue_terracotta
setblock 182 295 347 minecraft:purple_concrete
fill 182 295 356 182 296 356 minecraft:blue_terracotta
setblock 182 295 360 minecraft:dark_prismarine
fill 182 295 361 182 298 361 minecraft:blue_terracotta
setblock 142 296 323 minecraft:blue_terracotta
fill 142 296 327 142 297 327 minecraft:dark_prismarine
fill 142 296 329 142 297 329 minecraft:dark_prismarine
fill 142 296 331 142 297 331 minecraft:dark_prismarine
fill 142 296 333 142 297 333 minecraft:dark_prismarine
fill 142 296 335 142 297 335 minecraft:dark_prismarine
fill 142 296 337 142 297 337 minecraft:dark_prismarine
setblock 142 296 339 minecraft:dark_prismarine
fill 142 296 340 142 299 340 minecraft:blue_terracotta
setblock 142 296 344 minecraft:dark_prismarine
fill 142 296 345 143 298 345 minecraft:blue_terracotta
setblock 142 296 349 minecraft:dark_prismarine
fill 142 296 350 142 298 351 minecraft:blue_terracotta
setblock 142 296 354 minecraft:dark_prismarine
fill 142 296 355 142 298 355 minecraft:blue_terracotta
setblock 142 296 359 minecraft:dark_prismarine
fill 142 296 360 142 296 363 minecraft:blue_terracotta
setblock 143 296 323 minecraft:dark_prismarine
fill 143 296 328 143 297 328 minecraft:dark_prismarine
fill 143 296 330 143 297 330 minecraft:dark_prismarine
fill 143 296 332 143 297 332 minecraft:dark_prismarine
fill 143 296 334 143 297 334 minecraft:dark_prismarine
fill 143 296 336 143 297 336 minecraft:dark_prismarine
fill 143 296 338 143 297 338 minecraft:dark_prismarine
setblock 143 296 342 minecraft:blue_terracotta
setblock 143 296 343 minecraft:dark_prismarine
fill 143 296 344 143 299 344 minecraft:blue_terracotta
fill 143 296 346 143 297 346 minecraft:blue_terracotta
setblock 143 296 358 minecraft:dark_prismarine
fill 143 296 359 143 298 359 minecraft:blue_terracotta
fill 143 296 361 143 296 362 minecraft:blue_terracotta
setblock 143 296 363 minecraft:dark_prismarine
fill 144 296 323 147 296 323 minecraft:blue_terracotta
fill 144 296 327 144 297 327 minecraft:dark_prismarine
fill 144 296 329 144 297 329 minecraft:dark_prismarine
fill 144 296 331 144 297 331 minecraft:dark_prismarine
fill 144 296 333 144 297 333 minecraft:dark_prismarine
fill 144 296 335 144 297 335 minecraft:dark_prismarine
fill 144 296 337 144 297 337 minecraft:dark_prismarine
fill 144 296 339 144 297 339 minecraft:dark_prismarine
fill 144 296 345 147 296 346 minecraft:dark_prismarine
setblock 144 296 361 minecraft:blue_terracotta
setblock 144 296 362 minecraft:dark_prismarine
fill 144 296 363 144 299 363 minecraft:blue_terracotta
fill 145 296 328 145 297 328 minecraft:dark_prismarine
fill 145 296 330 145 297 330 minecraft:dark_prismarine
fill 145 296 332 145 297 332 minecraft:dark_prismarine
fill 145 296 334 145 297 334 minecraft:dark_prismarine
fill 145 296 336 145 297 336 minecraft:dark_prismarine
fill 145 296 338 145 297 338 minecraft:dark_prismarine
setblock 145 296 361 minecraft:dark_prismarine
fill 145 296 362 145 299 362 minecraft:blue_terracotta
fill 146 296 327 146 297 327 minecraft:dark_prismarine
fill 146 296 329 146 297 329 minecraft:dark_prismarine
fill 146 296 331 146 297 331 minecraft:dark_prismarine
fill 146 296 333 146 297 333 minecraft:dark_prismarine
fill 146 296 335 146 297 335 minecraft:dark_prismarine
fill 146 296 337 146 297 337 minecraft:dark_prismarine
fill 146 296 339 146 297 339 minecraft:dark_prismarine
fill 146 296 361 146 297 361 minecraft:blue_terracotta
fill 147 296 328 147 297 328 minecraft:dark_prismarine
fill 147 296 330 147 297 330 minecraft:dark_prismarine
fill 147 296 332 147 297 332 minecraft:dark_prismarine
fill 147 296 334 147 297 334 minecraft:dark_prismarine
fill 147 296 336 147 297 336 minecraft:dark_prismarine
fill 147 296 338 147 297 338 minecraft:dark_prismarine
setblock 148 296 323 minecraft:dark_prismarine
fill 148 296 324 148 299 324 minecraft:blue_terracotta
fill 148 296 346 154 296 347 minecraft:dark_prismarine
setblock 148 296 363 minecraft:dark_prismarine
fill 149 296 323 149 299 323 minecraft:blue_terracotta
setblock 149 296 362 minecraft:dark_prismarine
fill 149 296 363 149 299 363 minecraft:blue_terracotta
setblock 150 296 361 minecraft:dark_prismarine
fill 150 296 362 150 299 362 minecraft:blue_terracotta
fill 151 296 361 151 297 361 minecraft:blue_terracotta
setblock 152 296 324 minecraft:dark_prismarine
setblock 153 296 323 minecraft:dark_prismarine
fill 153 296 324 153 298 324 minecraft:blue_terracotta
setblock 153 296 363 minecraft:dark_prismarine
setblock 154 296 322 minecraft:cyan_concrete
fill 154 296 323 154 299 323 minecraft:blue_terracotta
setblock 154 296 362 minecraft:dark_prismarine
fill 154 296 363 154 299 363 minecraft:blue_terracotta
fill 155 296 346 157 296 346 minecraft:dark_prismarine
setblock 155 296 362 minecraft:blue_terracotta
setblock 158 296 323 minecraft:dark_prismarine
setblock 158 296 363 minecraft:dark_prismarine
fill 159 296 323 162 296 323 minecraft:blue_terracotta
setblock 159 296 363 minecraft:blue_terracotta
fill 161 296 363 162 296 363 minecraft:blue_terracotta
setblock 163 296 323 minecraft:dark_prismarine
fill 163 296 347 167 296 348 minecraft:dark_prismarine
setblock 163 296 363 minecraft:dark_prismarine
setblock 163 296 364 minecraft:light_blue_wool
fill 164 296 323 166 296 324 minecraft:blue_terracotta
fill 164 296 363 167 296 363 minecraft:blue_terracotta
fill 165 296 362 168 296 362 minecraft:blue_terracotta
setblock 167 296 323 minecraft:blue_terracotta
setblock 167 296 324 minecraft:dark_prismarine
fill 167 296 325 167 299 325 minecraft:blue_terracotta
setblock 168 296 323 minecraft:dark_prismarine
fill 168 296 324 168 299 324 minecraft:blue_terracotta
fill 168 296 348 171 296 348 minecraft:dark_prismarine
fill 168 296 361 169 296 361 minecraft:blue_terracotta
setblock 168 296 363 minecraft:dark_prismarine
fill 169 296 323 169 299 323 minecraft:blue_terracotta
setblock 169 296 362 minecraft:dark_prismarine
fill 169 296 363 169 299 363 minecraft:blue_terracotta
setblock 170 296 325 minecraft:blue_terracotta
setblock 170 296 361 minecraft:dark_prismarine
fill 170 296 362 170 299 362 minecraft:blue_terracotta
setblock 171 296 325 minecraft:dark_prismarine
fill 171 296 351 171 298 352 minecraft:black_concrete
fill 171 296 354 171 298 354 minecraft:black_concrete
fill 171 296 361 171 298 361 minecraft:blue_terracotta
setblock 172 296 324 minecraft:dark_prismarine
fill 172 296 325 172 299 325 minecraft:blue_terracotta
fill 172 296 348 180 296 348 minecraft:purple_concrete
fill 172 296 350 172 298 350 minecraft:black_concrete
fill 172 296 356 172 298 356 minecraft:black_concrete
setblock 173 296 322 minecraft:cyan_concrete
setblock 173 296 323 minecraft:dark_prismarine
fill 173 296 324 173 299 324 minecraft:blue_terracotta
fill 173 296 349 174 298 349 minecraft:black_concrete
setblock 173 296 363 minecraft:dark_prismarine
fill 174 296 323 174 299 323 minecraft:blue_terracotta
fill 174 296 357 176 298 357 minecraft:black_concrete
setblock 174 296 362 minecraft:dark_prismarine
fill 174 296 363 174 299 363 minecraft:blue_terracotta
setblock 175 296 361 minecraft:dark_prismarine
fill 175 296 362 175 299 362 minecraft:blue_terracotta
fill 176 296 349 177 298 349 minecraft:black_concrete
setblock 176 296 361 minecraft:blue_terracotta
setblock 177 296 324 minecraft:dark_prismarine
setblock 178 296 323 minecraft:dark_prismarine
fill 178 296 324 178 298 324 minecraft:blue_terracotta
fill 178 296 350 178 298 350 minecraft:black_concrete
setblock 178 296 363 minecraft:dark_prismarine
fill 179 296 323 179 299 323 minecraft:blue_terracotta
fill 179 296 349 181 296 349 minecraft:purple_concrete
fill 179 296 352 179 298 354 minecraft:black_concrete
setblock 179 296 362 minecraft:dark_prismarine
fill 179 296 363 179 299 363 minecraft:blue_terracotta
fill 180 296 362 180 299 362 minecraft:blue_terracotta
setblock 181 296 360 minecraft:dark_prismarine
fill 181 296 361 181 298 361 minecraft:blue_terracotta
setblock 182 296 323 minecraft:blue_terracotta
setblock 182 296 324 minecraft:dark_prismarine
fill 182 296 325 182 299 325 minecraft:blue_terracotta
setblock 182 296 343 minecraft:blue_terracotta
setblock 182 296 359 minecraft:dark_prismarine
fill 182 296 360 182 299 360 minecraft:blue_terracotta
setblock 142 297 323 minecraft:dark_prismarine
setblock 142 297 326 minecraft:purple_concrete
fill 142 297 338 142 298 338 minecraft:dark_prismarine
setblock 142 297 339 minecraft:blue_terracotta
setblock 142 297 343 minecraft:dark_prismarine
fill 142 297 344 142 300 344 minecraft:blue_terracotta
fill 142 297 346 142 297 347 minecraft:blue_terracotta
setblock 142 297 348 minecraft:dark_prismarine
fill 142 297 349 142 300 349 minecraft:blue_terracotta
setblock 142 297 353 minecraft:dark_prismarine
setblock 142 297 354 minecraft:blue_terracotta
setblock 142 297 358 minecraft:dark_prismarine
fill 142 297 359 142 297 362 minecraft:blue_terracotta
setblock 142 297 363 minecraft:dark_prismarine
fill 143 297 323 146 297 323 minecraft:blue_terracotta
setblock 143 297 342 minecraft:dark_prismarine
fill 143 297 343 144 299 343 minecraft:blue_terracotta
setblock 143 297 347 minecraft:dark_prismarine
setblock 143 297 358 minecraft:blue_terracotta
setblock 143 297 361 minecraft:blue_terracotta
setblock 143 297 362 minecraft:dark_prismarine
fill 143 297 363 143 300 363 minecraft:blue_terracotta
fill 144 297 344 144 298 344 minecraft:blue_terracotta
fill 144 297 345 144 297 346 minecraft:dark_prismarine
fill 144 297 362 144 300 362 minecraft:blue_terracotta
fill 145 297 346 150 297 346 minecraft:dark_prismarine
setblock 145 297 361 minecraft:blue_terracotta
setblock 147 297 323 minecraft:dark_prismarine
fill 147 297 324 147 300 324 minecraft:blue_terracotta
setblock 147 297 341 minecraft:magenta_terracotta
setblock 147 297 363 minecraft:dark_prismarine
fill 148 297 323 148 300 323 minecraft:blue_terracotta
setblock 148 297 362 minecraft:dark_prismarine
fill 148 297 363 148 300 363 minecraft:blue_terracotta
fill 149 297 324 150 297 324 minecraft:blue_terracotta
setblock 149 297 361 minecraft:dark_prismarine
fill 149 297 362 149 300 362 minecraft:blue_terracotta
setblock 150 297 361 minecraft:blue_terracotta
setblock 151 297 324 minecraft:dark_prismarine
fill 151 297 346 156 297 346 minecraft:purple_concrete
setblock 152 297 323 minecraft:dark_prismarine
fill 152 297 324 152 299 324 minecraft:blue_terracotta
setblock 152 297 363 minecraft:dark_prismarine
fill 153 297 323 153 300 323 minecraft:blue_terracotta
setblock 153 297 362 minecraft:dark_prismarine
fill 153 297 363 153 300 363 minecraft:blue_terracotta
fill 154 297 322 154 308 322 minecraft:blue_concrete
fill 154 297 347 154 299 348 minecraft:purple_concrete
setblock 154 297 362 minecraft:blue_terracotta
fill 155 297 330 156 297 331 minecraft:purple_concrete
fill 155 297 349 156 297 349 minecraft:purple_concrete
fill 156 297 329 159 297 329 minecraft:purple_concrete
fill 156 297 332 156 298 332 minecraft:purple_concrete
fill 156 297 348 156 299 348 minecraft:purple_concrete
setblock 157 297 323 minecraft:dark_prismarine
fill 157 297 333 158 297 333 minecraft:purple_concrete
fill 157 297 347 159 297 347 minecraft:purple_concrete
setblock 157 297 363 minecraft:dark_prismarine
fill 158 297 323 161 297 323 minecraft:blue_terracotta
fill 158 297 332 159 297 332 minecraft:purple_concrete
fill 159 297 330 159 298 331 minecraft:purple_concrete
setblock 162 297 323 minecraft:dark_prismarine
setblock 162 297 363 minecraft:dark_prismarine
fill 163 297 323 165 297 324 minecraft:blue_terracotta
fill 163 297 347 166 297 347 minecraft:purple_concrete
fill 163 297 363 166 297 363 minecraft:blue_terracotta
fill 163 297 364 163 308 364 minecraft:blue_concrete
fill 165 297 362 167 297 362 minecraft:blue_terracotta
setblock 166 297 323 minecraft:blue_terracotta
setblock 166 297 324 minecraft:dark_prismarine
fill 166 297 325 166 300 325 minecraft:blue_terracotta
setblock 167 297 323 minecraft:dark_prismarine
fill 167 297 324 167 300 324 minecraft:blue_terracotta
setblock 167 297 363 minecraft:dark_prismarine
fill 168 297 323 168 300 323 minecraft:blue_terracotta
setblock 168 297 361 minecraft:blue_terracotta
setblock 168 297 362 minecraft:dark_prismarine
fill 168 297 363 168 300 363 minecraft:blue_terracotta
setblock 169 297 361 minecraft:dark_prismarine
fill 169 297 362 169 300 362 minecraft:blue_terracotta
setblock 170 297 325 minecraft:dark_prismarine
fill 170 297 353 170 298 353 minecraft:black_concrete
fill 170 297 361 170 298 361 minecraft:blue_terracotta
setblock 171 297 324 minecraft:dark_prismarine
fill 171 297 325 171 300 325 minecraft:blue_terracotta
fill 171 297 350 171 298 350 minecraft:black_concrete
fill 171 297 355 171 298 355 minecraft:black_concrete
setblock 172 297 323 minecraft:dark_prismarine
fill 172 297 324 172 300 324 minecraft:blue_terracotta
fill 172 297 349 172 298 349 minecraft:black_concrete
setblock 172 297 363 minecraft:dark_prismarine
fill 173 297 322 173 308 322 minecraft:blue_concrete
fill 173 297 323 173 300 323 minecraft:blue_terracotta
fill 173 297 357 173 298 357 minecraft:black_concrete
setblock 173 297 362 minecraft:dark_prismarine
fill 173 297 363 173 300 363 minecraft:blue_terracotta
setblock 174 297 361 minecraft:dark_prismarine
fill 174 297 362 174 300 362 minecraft:blue_terracotta
setblock 175 297 325 minecraft:dark_prismarine
fill 175 297 348 175 298 348 minecraft:black_concrete
setblock 175 297 361 minecraft:blue_terracotta
setblock 176 297 324 minecraft:dark_prismarine
setblock 177 297 323 minecraft:dark_prismarine
fill 177 297 324 177 299 324 minecraft:blue_terracotta
fill 177 297 357 177 298 357 minecraft:black_concrete
setblock 177 297 363 minecraft:dark_prismarine
fill 178 297 323 178 300 323 minecraft:blue_terracotta
fill 178 297 356 178 298 356 minecraft:black_concrete
setblock 178 297 362 minecraft:dark_prismarine
fill 178 297 363 178 300 363 minecraft:blue_terracotta
fill 179 297 351 179 298 351 minecraft:black_concrete
fill 179 297 355 179 298 355 minecraft:black_concrete
fill 179 297 362 179 299 362 minecraft:blue_terracotta
setblock 181 297 360 minecraft:blue_terracotta
setblock 182 297 323 minecraft:dark_prismarine
fill 182 297 324 182 300 324 minecraft:blue_terracotta
setblock 182 297 335 minecraft:purple_concrete
setblock 182 297 342 minecraft:blue_terracotta
setblock 182 297 343 minecraft:dark_prismarine
fill 182 297 344 182 300 344 minecraft:blue_terracotta
setblock 182 297 358 minecraft:dark_prismarine
fill 182 297 359 182 300 359 minecraft:blue_terracotta
setblock 182 297 363 minecraft:dark_prismarine
fill 142 298 323 145 298 323 minecraft:blue_terracotta
setblock 142 298 327 minecraft:sea_lantern
setblock 142 298 329 minecraft:sea_lantern
setblock 142 298 331 minecraft:sea_lantern
setblock 142 298 332 minecraft:purple_concrete
setblock 142 298 333 minecraft:sea_lantern
setblock 142 298 335 minecraft:sea_lantern
setblock 142 298 337 minecraft:sea_lantern
setblock 142 298 339 minecraft:sea_lantern
setblock 142 298 341 minecraft:blue_terracotta
setblock 142 298 342 minecraft:dark_prismarine
fill 142 298 343 142 300 343 minecraft:blue_terracotta
setblock 142 298 346 minecraft:blue_terracotta
setblock 142 298 347 minecraft:dark_prismarine
fill 142 298 348 143 300 348 minecraft:blue_terracotta
setblock 142 298 352 minecraft:dark_prismarine
setblock 142 298 357 minecraft:dark_prismarine
fill 142 298 358 142 298 361 minecraft:blue_terracotta
setblock 142 298 362 minecraft:dark_prismarine
fill 142 298 363 142 300 363 minecraft:blue_terracotta
setblock 143 298 328 minecraft:sea_lantern
setblock 143 298 330 minecraft:sea_lantern
setblock 143 298 332 minecraft:sea_lantern
setblock 143 298 334 minecraft:sea_lantern
setblock 143 298 336 minecraft:sea_lantern
setblock 143 298 338 minecraft:sea_lantern
setblock 143 298 341 minecraft:dark_prismarine
fill 143 298 342 144 298 342 minecraft:blue_terracotta
setblock 143 298 346 minecraft:dark_prismarine
fill 143 298 347 143 300 347 minecraft:blue_terracotta
setblock 143 298 361 minecraft:dark_prismarine
fill 143 298 362 143 299 362 minecraft:blue_terracotta
setblock 144 298 327 minecraft:sea_lantern
setblock 144 298 329 minecraft:sea_lantern
setblock 144 298 331 minecraft:sea_lantern
setblock 144 298 333 minecraft:sea_lantern
setblock 144 298 335 minecraft:sea_lantern
setblock 144 298 337 minecraft:sea_lantern
setblock 144 298 339 minecraft:sea_lantern
setblock 144 298 345 minecraft:dark_prismarine
fill 144 298 346 144 300 346 minecraft:blue_terracotta
setblock 145 298 328 minecraft:sea_lantern
setblock 145 298 330 minecraft:sea_lantern
setblock 145 298 332 minecraft:sea_lantern
setblock 145 298 334 minecraft:sea_lantern
setblock 145 298 336 minecraft:sea_lantern
setblock 145 298 338 minecraft:sea_lantern
fill 145 298 346 149 298 346 minecraft:purple_concrete
setblock 146 298 323 minecraft:dark_prismarine
setblock 146 298 327 minecraft:sea_lantern
setblock 146 298 329 minecraft:sea_lantern
setblock 146 298 331 minecraft:sea_lantern
setblock 146 298 333 minecraft:sea_lantern
setblock 146 298 335 minecraft:sea_lantern
setblock 146 298 337 minecraft:sea_lantern
setblock 146 298 339 minecraft:sea_lantern
setblock 146 298 363 minecraft:dark_prismarine
fill 147 298 323 147 300 323 minecraft:blue_terracotta
setblock 147 298 328 minecraft:sea_lantern
setblock 147 298 330 minecraft:sea_lantern
setblock 147 298 332 minecraft:sea_lantern
setblock 147 298 334 minecraft:sea_lantern
setblock 147 298 336 minecraft:sea_lantern
setblock 147 298 338 minecraft:sea_lantern
setblock 147 298 362 minecraft:dark_prismarine
fill 147 298 363 147 300 363 minecraft:blue_terracotta
setblock 148 298 361 minecraft:dark_prismarine
fill 148 298 362 148 300 362 minecraft:blue_terracotta
setblock 149 298 324 minecraft:blue_terracotta
setblock 149 298 361 minecraft:blue_terracotta
setblock 150 298 324 minecraft:dark_prismarine
setblock 151 298 323 minecraft:dark_prismarine
fill 151 298 324 151 300 324 minecraft:blue_terracotta
setblock 151 298 363 minecraft:dark_prismarine
fill 152 298 323 152 300 323 minecraft:blue_terracotta
setblock 152 298 362 minecraft:dark_prismarine
fill 152 298 363 152 300 363 minecraft:blue_terracotta
setblock 153 298 362 minecraft:blue_terracotta
fill 154 298 346 156 298 346 minecraft:purple_concrete
setblock 156 298 323 minecraft:dark_prismarine
fill 156 298 330 156 299 331 minecraft:purple_concrete
setblock 156 298 363 minecraft:dark_prismarine
fill 157 298 323 160 298 323 minecraft:blue_terracotta
fill 157 298 329 158 298 329 minecraft:purple_concrete
fill 158 298 332 158 299 332 minecraft:purple_concrete
setblock 161 298 323 minecraft:dark_prismarine
fill 162 298 323 165 298 323 minecraft:blue_terracotta
fill 162 298 363 165 298 363 minecraft:blue_terracotta
fill 163 298 324 164 298 324 minecraft:blue_terracotta
setblock 165 298 324 minecraft:dark_prismarine
fill 165 298 325 165 300 325 minecraft:blue_terracotta
fill 165 298 362 166 298 362 minecraft:blue_terracotta
setblock 166 298 323 minecraft:dark_prismarine
fill 166 298 324 166 300 324 minecraft:blue_terracotta
setblock 166 298 363 minecraft:dark_prismarine
fill 167 298 323 167 300 323 minecraft:blue_terracotta
setblock 167 298 362 minecraft:dark_prismarine
fill 167 298 363 167 300 363 minecraft:blue_terracotta
fill 168 298 362 168 300 362 minecraft:blue_terracotta
setblock 169 298 325 minecraft:dark_prismarine
setblock 169 298 361 minecraft:blue_terracotta
setblock 170 298 324 minecraft:dark_prismarine
fill 170 298 325 170 300 325 minecraft:blue_terracotta
fill 170 298 351 170 298 352 minecraft:black_concrete
fill 170 298 354 170 298 355 minecraft:black_concrete
setblock 171 298 323 minecraft:dark_prismarine
fill 171 298 324 171 300 324 minecraft:blue_terracotta
setblock 171 298 356 minecraft:black_concrete
setblock 171 298 363 minecraft:dark_prismarine
fill 172 298 323 172 300 323 minecraft:blue_terracotta
setblock 172 298 357 minecraft:black_concrete
setblock 172 298 362 minecraft:dark_prismarine
fill 172 298 363 172 300 363 minecraft:blue_terracotta
fill 173 298 348 174 298 348 minecraft:black_concrete
setblock 173 298 361 minecraft:dark_prismarine
fill 173 298 362 173 300 362 minecraft:blue_terracotta
setblock 174 298 325 minecraft:dark_prismarine
fill 174 298 358 176 298 358 minecraft:black_concrete
setblock 175 298 324 minecraft:dark_prismarine
setblock 176 298 323 minecraft:dark_prismarine
fill 176 298 324 176 300 324 minecraft:blue_terracotta
fill 176 298 348 177 298 348 minecraft:black_concrete
setblock 176 298 363 minecraft:dark_prismarine
fill 177 298 323 177 300 323 minecraft:blue_terracotta
setblock 177 298 362 minecraft:dark_prismarine
fill 177 298 363 177 300 363 minecraft:blue_terracotta
setblock 178 298 349 minecraft:black_concrete
setblock 178 298 357 minecraft:black_concrete
fill 178 298 362 178 299 362 minecraft:blue_terracotta
setblock 179 298 350 minecraft:black_concrete
setblock 179 298 356 minecraft:black_concrete
fill 180 298 352 180 298 354 minecraft:black_concrete
setblock 181 298 323 minecraft:dark_prismarine
setblock 181 298 363 minecraft:dark_prismarine
fill 182 298 323 182 300 323 minecraft:blue_terracotta
setblock 182 298 329 minecraft:purple_concrete
fill 182 298 343 182 299 343 minecraft:blue_terracotta
fill 182 298 345 182 299 345 minecraft:blue_terracotta
setblock 182 298 354 minecraft:purple_concrete
setblock 182 298 357 minecraft:dark_prismarine
fill 182 298 358 182 300 358 minecraft:blue_terracotta
setblock 182 298 362 minecraft:dark_prismarine
fill 182 298 363 182 300 363 minecraft:blue_terracotta
setblock 141 299 335 minecraft:light_blue_wool
setblock 142 299 322 minecraft:cyan_concrete
fill 142 299 323 144 299 323 minecraft:blue_terracotta
fill 142 299 327 142 300 327 minecraft:dark_prismarine
fill 142 299 329 142 300 329 minecraft:dark_prismarine
fill 142 299 331 142 300 333 minecraft:dark_prismarine
fill 142 299 335 142 300 335 minecraft:dark_prismarine
fill 142 299 337 142 300 337 minecraft:dark_prismarine
setblock 142 299 338 minecraft:purple_concrete
fill 142 299 339 142 300 339 minecraft:dark_prismarine
setblock 142 299 341 minecraft:dark_prismarine
fill 142 299 342 143 300 342 minecraft:blue_terracotta
setblock 142 299 345 minecraft:blue_terracotta
setblock 142 299 346 minecraft:dark_prismarine
fill 142 299 347 142 300 347 minecraft:blue_terracotta
setblock 142 299 350 minecraft:blue_terracotta
setblock 142 299 351 minecraft:dark_prismarine
fill 142 299 352 142 300 352 minecraft:blue_terracotta
fill 142 299 357 142 299 360 minecraft:blue_terracotta
setblock 142 299 361 minecraft:dark_prismarine
fill 142 299 362 142 300 362 minecraft:blue_terracotta
fill 143 299 322 144 308 322 minecraft:blue_concrete
fill 143 299 328 143 300 328 minecraft:dark_prismarine
fill 143 299 330 143 300 330 minecraft:dark_prismarine
fill 143 299 332 143 300 332 minecraft:dark_prismarine
fill 143 299 334 143 300 334 minecraft:dark_prismarine
fill 143 299 336 143 300 336 minecraft:dark_prismarine
fill 143 299 338 143 300 338 minecraft:dark_prismarine
fill 143 299 341 143 300 341 minecraft:blue_terracotta
schedule function dropper:buildpart/75_14 1t
