setblock 148 74 297 minecraft:packed_ice
setblock 148 74 314 minecraft:packed_ice
fill 149 74 288 150 75 288 minecraft:packed_ice
fill 149 74 292 149 75 292 minecraft:packed_ice
setblock 150 74 276 minecraft:snow_block
fill 150 74 293 150 75 293 minecraft:packed_ice
setblock 150 74 296 minecraft:packed_ice
setblock 150 74 316 minecraft:snow_block
fill 151 74 276 151 77 276 minecraft:packed_ice
setblock 151 74 315 minecraft:snow_block
fill 151 74 316 151 76 316 minecraft:packed_ice
fill 152 74 288 152 75 288 minecraft:packed_ice
fill 152 74 292 152 75 292 minecraft:packed_ice
fill 153 74 289 153 75 291 minecraft:packed_ice
fill 154 74 278 154 75 278 minecraft:snow_block
setblock 155 74 276 minecraft:snow_block
fill 156 74 276 159 74 276 minecraft:packed_ice
fill 156 74 277 156 75 278 minecraft:snow_block
fill 158 74 316 159 74 316 minecraft:packed_ice
setblock 160 74 276 minecraft:snow_block
setblock 160 74 316 minecraft:snow_block
fill 161 74 276 163 74 277 minecraft:packed_ice
setblock 161 74 315 minecraft:snow_block
fill 161 74 316 164 74 316 minecraft:packed_ice
fill 162 74 315 165 74 315 minecraft:packed_ice
setblock 164 74 276 minecraft:packed_ice
setblock 164 74 277 minecraft:snow_block
fill 164 74 278 164 77 278 minecraft:packed_ice
fill 164 74 314 166 74 314 minecraft:packed_ice
setblock 165 74 276 minecraft:snow_block
fill 165 74 277 165 77 277 minecraft:packed_ice
setblock 165 74 316 minecraft:snow_block
fill 166 74 276 166 77 276 minecraft:packed_ice
setblock 166 74 315 minecraft:snow_block
fill 166 74 316 166 77 316 minecraft:packed_ice
setblock 167 74 314 minecraft:snow_block
fill 167 74 315 167 77 315 minecraft:packed_ice
setblock 168 74 278 minecraft:snow_block
fill 168 74 314 168 77 314 minecraft:packed_ice
setblock 169 74 277 minecraft:snow_block
fill 169 74 278 169 76 278 minecraft:packed_ice
fill 170 74 275 170 114 275 minecraft:packed_ice
setblock 170 74 276 minecraft:snow_block
fill 170 74 277 170 77 277 minecraft:packed_ice
setblock 170 74 316 minecraft:snow_block
fill 171 74 276 171 77 276 minecraft:packed_ice
setblock 171 74 315 minecraft:snow_block
fill 171 74 316 171 77 316 minecraft:packed_ice
setblock 172 74 314 minecraft:snow_block
fill 172 74 315 175 74 315 minecraft:packed_ice
fill 173 74 314 174 74 314 minecraft:packed_ice
fill 174 74 317 174 115 317 minecraft:packed_ice
setblock 175 74 275 minecraft:white_concrete
setblock 175 74 276 minecraft:snow_block
setblock 175 74 316 minecraft:snow_block
fill 176 74 276 179 74 276 minecraft:packed_ice
setblock 176 74 315 minecraft:snow_block
fill 176 74 316 176 77 316 minecraft:packed_ice
fill 177 74 315 177 77 315 minecraft:packed_ice
setblock 180 74 276 minecraft:snow_block
setblock 180 74 316 minecraft:snow_block
fill 181 74 276 181 77 276 minecraft:packed_ice
setblock 181 74 310 minecraft:snow_block
fill 181 74 311 181 77 311 minecraft:packed_ice
setblock 181 74 315 minecraft:snow_block
fill 181 74 316 181 77 316 minecraft:packed_ice
setblock 182 74 289 minecraft:snow_block
fill 182 74 290 182 76 290 minecraft:packed_ice
setblock 182 74 294 minecraft:snow_block
fill 182 74 295 182 74 298 minecraft:packed_ice
setblock 182 74 299 minecraft:snow_block
fill 182 74 300 182 77 300 minecraft:packed_ice
setblock 182 74 304 minecraft:snow_block
fill 182 74 305 182 77 305 minecraft:packed_ice
setblock 182 74 309 minecraft:snow_block
fill 182 74 310 182 77 310 minecraft:packed_ice
setblock 182 74 314 minecraft:snow_block
fill 182 74 315 182 77 315 minecraft:packed_ice
fill 183 74 279 183 111 279 minecraft:packed_ice
fill 141 75 307 141 114 307 minecraft:packed_ice
fill 142 75 276 142 75 277 minecraft:packed_ice
setblock 142 75 287 minecraft:packed_ice
setblock 142 75 288 minecraft:snow_block
fill 142 75 289 142 78 289 minecraft:packed_ice
setblock 142 75 293 minecraft:snow_block
fill 142 75 294 142 75 297 minecraft:packed_ice
setblock 142 75 298 minecraft:snow_block
fill 142 75 299 142 78 299 minecraft:packed_ice
setblock 142 75 303 minecraft:snow_block
fill 142 75 304 142 78 304 minecraft:packed_ice
setblock 142 75 308 minecraft:snow_block
fill 142 75 309 142 78 309 minecraft:packed_ice
setblock 142 75 313 minecraft:snow_block
fill 142 75 314 142 78 314 minecraft:packed_ice
setblock 143 75 276 minecraft:packed_ice
setblock 143 75 292 minecraft:snow_block
fill 143 75 293 143 78 293 minecraft:packed_ice
setblock 143 75 297 minecraft:snow_block
fill 143 75 298 143 78 298 minecraft:packed_ice
setblock 143 75 302 minecraft:snow_block
fill 143 75 303 143 78 303 minecraft:packed_ice
setblock 143 75 312 minecraft:snow_block
fill 143 75 313 143 77 313 minecraft:packed_ice
setblock 143 75 316 minecraft:packed_ice
setblock 144 75 276 minecraft:snow_block
setblock 144 75 291 minecraft:snow_block
fill 144 75 292 144 78 292 minecraft:packed_ice
setblock 144 75 296 minecraft:snow_block
fill 144 75 297 144 78 297 minecraft:packed_ice
setblock 144 75 301 minecraft:snow_block
setblock 144 75 316 minecraft:snow_block
fill 145 75 276 145 78 276 minecraft:packed_ice
setblock 145 75 295 minecraft:snow_block
fill 145 75 296 145 78 296 minecraft:packed_ice
setblock 145 75 315 minecraft:snow_block
fill 145 75 316 145 78 316 minecraft:packed_ice
fill 146 75 277 146 76 277 minecraft:packed_ice
fill 146 75 315 146 77 315 minecraft:packed_ice
setblock 148 75 277 minecraft:snow_block
setblock 148 75 289 minecraft:packed_ice
setblock 149 75 276 minecraft:snow_block
setblock 149 75 316 minecraft:snow_block
fill 150 75 276 150 78 276 minecraft:packed_ice
fill 150 75 316 150 77 316 minecraft:packed_ice
fill 151 75 293 152 75 293 minecraft:packed_ice
setblock 153 75 292 minecraft:packed_ice
setblock 154 75 276 minecraft:snow_block
fill 155 75 276 158 75 276 minecraft:packed_ice
setblock 158 75 316 minecraft:packed_ice
setblock 159 75 276 minecraft:snow_block
setblock 159 75 316 minecraft:snow_block
fill 160 75 276 162 75 277 minecraft:packed_ice
fill 160 75 316 163 75 316 minecraft:packed_ice
fill 161 75 315 164 75 315 minecraft:packed_ice
setblock 163 75 276 minecraft:packed_ice
setblock 163 75 277 minecraft:snow_block
fill 163 75 278 163 78 278 minecraft:packed_ice
setblock 164 75 276 minecraft:snow_block
fill 164 75 277 164 78 277 minecraft:packed_ice
fill 164 75 314 165 75 314 minecraft:packed_ice
setblock 164 75 316 minecraft:snow_block
fill 165 75 276 165 78 276 minecraft:packed_ice
setblock 165 75 315 minecraft:snow_block
fill 165 75 316 165 78 316 minecraft:packed_ice
setblock 166 75 314 minecraft:snow_block
fill 166 75 315 166 78 315 minecraft:packed_ice
setblock 167 75 278 minecraft:snow_block
fill 167 75 314 167 77 314 minecraft:packed_ice
setblock 168 75 277 minecraft:snow_block
fill 168 75 278 168 78 278 minecraft:packed_ice
setblock 169 75 276 minecraft:snow_block
fill 169 75 277 169 78 277 minecraft:packed_ice
setblock 169 75 316 minecraft:snow_block
fill 170 75 276 170 78 276 minecraft:packed_ice
setblock 170 75 315 minecraft:snow_block
fill 170 75 316 170 78 316 minecraft:packed_ice
setblock 171 75 314 minecraft:snow_block
fill 171 75 315 174 75 315 minecraft:packed_ice
setblock 172 75 314 minecraft:packed_ice
setblock 173 75 277 minecraft:snow_block
setblock 174 75 276 minecraft:snow_block
setblock 174 75 316 minecraft:snow_block
fill 175 75 275 175 78 276 minecraft:packed_ice
setblock 175 75 315 minecraft:snow_block
fill 175 75 316 175 78 316 minecraft:packed_ice
fill 176 75 276 178 75 276 minecraft:packed_ice
fill 176 75 315 176 77 315 minecraft:packed_ice
fill 178 75 292 178 77 292 minecraft:packed_ice
fill 178 75 294 178 77 294 minecraft:packed_ice
setblock 179 75 276 minecraft:snow_block
setblock 179 75 316 minecraft:snow_block
fill 180 75 276 180 78 276 minecraft:packed_ice
fill 180 75 292 180 77 292 minecraft:packed_ice
fill 180 75 294 180 77 294 minecraft:packed_ice
setblock 180 75 315 minecraft:snow_block
fill 180 75 316 180 78 316 minecraft:packed_ice
fill 181 75 296 182 76 296 minecraft:packed_ice
fill 181 75 310 181 76 310 minecraft:packed_ice
setblock 181 75 314 minecraft:snow_block
fill 181 75 315 181 78 315 minecraft:packed_ice
setblock 182 75 293 minecraft:snow_block
fill 182 75 294 182 77 295 minecraft:packed_ice
setblock 182 75 297 minecraft:packed_ice
setblock 182 75 298 minecraft:snow_block
fill 182 75 299 182 78 299 minecraft:packed_ice
setblock 182 75 302 minecraft:packed_ice
setblock 182 75 303 minecraft:snow_block
fill 182 75 304 182 78 304 minecraft:packed_ice
setblock 182 75 308 minecraft:snow_block
fill 182 75 309 182 78 309 minecraft:packed_ice
setblock 182 75 313 minecraft:snow_block
fill 182 75 314 182 78 314 minecraft:packed_ice
setblock 142 76 276 minecraft:packed_ice
setblock 142 76 277 minecraft:snow_block
fill 142 76 288 142 79 288 minecraft:packed_ice
setblock 142 76 292 minecraft:snow_block
fill 142 76 293 142 76 296 minecraft:packed_ice
setblock 142 76 297 minecraft:snow_block
fill 142 76 298 142 79 298 minecraft:packed_ice
setblock 142 76 302 minecraft:snow_block
fill 142 76 303 142 79 303 minecraft:packed_ice
setblock 142 76 307 minecraft:snow_block
fill 142 76 308 142 79 308 minecraft:packed_ice
setblock 142 76 312 minecraft:snow_block
fill 142 76 313 142 79 313 minecraft:packed_ice
setblock 143 76 276 minecraft:snow_block
setblock 143 76 291 minecraft:snow_block
fill 143 76 292 143 79 292 minecraft:packed_ice
setblock 143 76 296 minecraft:snow_block
fill 143 76 297 143 79 297 minecraft:packed_ice
setblock 143 76 300 minecraft:packed_ice
setblock 143 76 301 minecraft:snow_block
fill 143 76 302 143 79 302 minecraft:packed_ice
fill 143 76 304 143 77 304 minecraft:packed_ice
setblock 143 76 311 minecraft:snow_block
setblock 143 76 312 minecraft:packed_ice
setblock 143 76 316 minecraft:snow_block
fill 144 76 276 144 79 276 minecraft:packed_ice
setblock 144 76 278 minecraft:light[level=15]
setblock 144 76 285 minecraft:light[level=12]
setblock 144 76 286 minecraft:light[level=15]
setblock 144 76 290 minecraft:snow_block
fill 144 76 291 144 77 291 minecraft:packed_ice
setblock 144 76 295 minecraft:snow_block
fill 144 76 296 144 79 296 minecraft:packed_ice
setblock 144 76 300 minecraft:snow_block
fill 144 76 301 144 79 301 minecraft:packed_ice
setblock 144 76 302 minecraft:light[level=15]
setblock 144 76 306 minecraft:light[level=12]
setblock 144 76 310 minecraft:light[level=15]
setblock 144 76 313 minecraft:light[level=12]
setblock 144 76 315 minecraft:snow_block
fill 144 76 316 144 79 316 minecraft:packed_ice
setblock 145 76 294 minecraft:snow_block
fill 145 76 295 145 79 295 minecraft:packed_ice
fill 145 76 315 145 77 315 minecraft:packed_ice
setblock 147 76 277 minecraft:snow_block
setblock 148 76 276 minecraft:snow_block
setblock 148 76 316 minecraft:snow_block
fill 149 76 276 149 79 276 minecraft:packed_ice
fill 149 76 316 149 78 316 minecraft:packed_ice
fill 150 76 290 151 77 291 minecraft:blue_ice
setblock 151 76 278 minecraft:light[level=12]
setblock 151 76 285 minecraft:light[level=12]
setblock 151 76 289 minecraft:blue_ice
setblock 151 76 292 minecraft:light[level=12]
setblock 151 76 299 minecraft:light[level=12]
setblock 151 76 306 minecraft:light[level=12]
setblock 151 76 313 minecraft:light[level=12]
setblock 152 76 278 minecraft:light[level=15]
setblock 152 76 286 minecraft:light[level=15]
setblock 152 76 294 minecraft:light[level=15]
setblock 152 76 302 minecraft:light[level=15]
setblock 152 76 310 minecraft:light[level=15]
setblock 153 76 276 minecraft:snow_block
fill 154 76 276 157 76 276 minecraft:packed_ice
setblock 158 76 276 minecraft:snow_block
setblock 158 76 278 minecraft:light[level=12]
setblock 158 76 285 minecraft:light[level=12]
setblock 158 76 292 minecraft:light[level=12]
setblock 158 76 299 minecraft:light[level=12]
setblock 158 76 306 minecraft:light[level=12]
setblock 158 76 313 minecraft:light[level=12]
fill 159 76 276 161 76 277 minecraft:packed_ice
fill 159 76 316 162 76 316 minecraft:packed_ice
setblock 160 76 278 minecraft:light[level=15]
setblock 160 76 286 minecraft:light[level=15]
setblock 160 76 294 minecraft:light[level=15]
setblock 160 76 302 minecraft:light[level=15]
setblock 160 76 310 minecraft:light[level=15]
fill 161 76 315 163 76 315 minecraft:packed_ice
setblock 162 76 276 minecraft:packed_ice
setblock 162 76 277 minecraft:snow_block
setblock 163 76 276 minecraft:snow_block
fill 163 76 277 163 79 277 minecraft:packed_ice
setblock 163 76 316 minecraft:snow_block
fill 164 76 276 164 79 276 minecraft:packed_ice
setblock 164 76 314 minecraft:packed_ice
setblock 164 76 315 minecraft:snow_block
fill 164 76 316 164 79 316 minecraft:packed_ice
setblock 165 76 285 minecraft:light[level=12]
setblock 165 76 292 minecraft:light[level=12]
setblock 165 76 299 minecraft:light[level=12]
setblock 165 76 306 minecraft:light[level=12]
setblock 165 76 313 minecraft:light[level=12]
setblock 165 76 314 minecraft:snow_block
fill 165 76 315 165 79 315 minecraft:packed_ice
setblock 166 76 278 minecraft:snow_block
fill 166 76 314 166 77 314 minecraft:packed_ice
setblock 167 76 277 minecraft:snow_block
fill 167 76 278 167 79 278 minecraft:packed_ice
setblock 168 76 276 minecraft:snow_block
fill 168 76 277 168 79 277 minecraft:packed_ice
setblock 168 76 286 minecraft:light[level=15]
setblock 168 76 294 minecraft:light[level=15]
setblock 168 76 302 minecraft:light[level=15]
setblock 168 76 310 minecraft:light[level=15]
setblock 168 76 316 minecraft:snow_block
fill 169 76 276 169 79 276 minecraft:packed_ice
setblock 169 76 315 minecraft:snow_block
fill 169 76 316 169 79 316 minecraft:packed_ice
setblock 170 76 314 minecraft:snow_block
fill 170 76 315 173 76 315 minecraft:packed_ice
setblock 172 76 277 minecraft:snow_block
setblock 172 76 278 minecraft:light[level=12]
setblock 172 76 285 minecraft:light[level=12]
setblock 172 76 292 minecraft:light[level=12]
setblock 172 76 299 minecraft:light[level=12]
setblock 172 76 306 minecraft:light[level=12]
setblock 172 76 313 minecraft:light[level=12]
setblock 173 76 276 minecraft:snow_block
setblock 173 76 316 minecraft:snow_block
fill 174 76 276 174 79 276 minecraft:packed_ice
setblock 174 76 315 minecraft:snow_block
fill 174 76 316 174 79 316 minecraft:packed_ice
fill 175 76 315 175 77 315 minecraft:packed_ice
fill 176 76 276 177 76 276 minecraft:packed_ice
setblock 176 76 278 minecraft:light[level=15]
setblock 176 76 286 minecraft:light[level=15]
setblock 176 76 294 minecraft:light[level=15]
setblock 176 76 302 minecraft:light[level=15]
setblock 176 76 310 minecraft:light[level=15]
setblock 178 76 276 minecraft:snow_block
setblock 178 76 316 minecraft:snow_block
fill 179 76 276 179 79 276 minecraft:packed_ice
setblock 179 76 278 minecraft:light[level=12]
setblock 179 76 285 minecraft:light[level=12]
setblock 179 76 299 minecraft:light[level=12]
setblock 179 76 306 minecraft:light[level=12]
setblock 179 76 313 minecraft:light[level=12]
setblock 179 76 315 minecraft:snow_block
fill 179 76 316 179 79 316 minecraft:packed_ice
fill 180 76 315 180 79 315 minecraft:packed_ice
fill 181 76 295 181 78 295 minecraft:packed_ice
setblock 181 76 297 minecraft:packed_ice
setblock 181 76 298 minecraft:snow_block
setblock 181 76 313 minecraft:snow_block
fill 181 76 314 181 79 314 minecraft:packed_ice
setblock 182 76 277 minecraft:snow_block
fill 182 76 278 182 79 278 minecraft:packed_ice
setblock 182 76 292 minecraft:snow_block
fill 182 76 293 182 79 293 minecraft:packed_ice
setblock 182 76 297 minecraft:snow_block
fill 182 76 298 182 79 298 minecraft:packed_ice
setblock 182 76 302 minecraft:snow_block
fill 182 76 303 182 79 303 minecraft:packed_ice
setblock 182 76 307 minecraft:snow_block
fill 182 76 308 182 79 308 minecraft:packed_ice
setblock 182 76 312 minecraft:snow_block
fill 182 76 313 182 79 313 minecraft:packed_ice
setblock 142 77 276 minecraft:snow_block
fill 142 77 277 142 79 278 minecraft:packed_ice
setblock 142 77 291 minecraft:snow_block
fill 142 77 292 142 77 295 minecraft:packed_ice
setblock 142 77 296 minecraft:snow_block
fill 142 77 297 142 80 297 minecraft:packed_ice
setblock 142 77 301 minecraft:snow_block
fill 142 77 302 142 80 302 minecraft:packed_ice
setblock 142 77 306 minecraft:snow_block
fill 142 77 307 142 80 307 minecraft:packed_ice
setblock 142 77 311 minecraft:snow_block
fill 142 77 312 142 80 312 minecraft:packed_ice
setblock 142 77 315 minecraft:packed_ice
setblock 142 77 316 minecraft:snow_block
fill 143 77 276 143 80 276 minecraft:packed_ice
setblock 143 77 290 minecraft:snow_block
fill 143 77 291 143 80 291 minecraft:packed_ice
setblock 143 77 295 minecraft:snow_block
fill 143 77 296 143 80 296 minecraft:packed_ice
setblock 143 77 300 minecraft:snow_block
fill 143 77 301 143 80 301 minecraft:packed_ice
setblock 143 77 315 minecraft:snow_block
fill 143 77 316 143 80 316 minecraft:packed_ice
setblock 144 77 294 minecraft:snow_block
fill 144 77 295 144 80 295 minecraft:packed_ice
setblock 144 77 298 minecraft:packed_ice
setblock 144 77 299 minecraft:snow_block
fill 144 77 300 144 80 300 minecraft:packed_ice
fill 144 77 315 144 78 315 minecraft:packed_ice
setblock 145 77 277 minecraft:packed_ice
setblock 145 77 293 minecraft:snow_block
fill 145 77 294 145 78 294 minecraft:packed_ice
setblock 145 77 298 minecraft:snow_block
setblock 146 77 277 minecraft:snow_block
setblock 147 77 276 minecraft:snow_block
fill 147 77 277 147 80 277 minecraft:packed_ice
setblock 147 77 316 minecraft:snow_block
fill 148 77 276 148 80 276 minecraft:packed_ice
fill 148 77 316 148 79 316 minecraft:packed_ice
setblock 152 77 276 minecraft:snow_block
fill 153 77 276 156 77 276 minecraft:packed_ice
fill 154 77 287 156 131 288 minecraft:snow_block
fill 155 77 286 155 131 286 minecraft:snow_block
fill 155 77 289 156 131 289 minecraft:snow_block
setblock 157 77 276 minecraft:snow_block
fill 157 77 288 157 131 288 minecraft:snow_block
fill 157 77 317 158 114 317 minecraft:packed_ice
fill 158 77 276 161 77 276 minecraft:packed_ice
fill 159 77 277 160 77 277 minecraft:packed_ice
fill 159 77 316 161 77 316 minecraft:packed_ice
setblock 159 77 317 minecraft:white_concrete
fill 160 77 317 165 78 317 minecraft:packed_ice
setblock 161 77 277 minecraft:snow_block
fill 161 77 315 162 77 315 minecraft:packed_ice
setblock 162 77 276 minecraft:snow_block
fill 162 77 277 162 79 278 minecraft:packed_ice
setblock 162 77 316 minecraft:snow_block
fill 163 77 276 163 80 276 minecraft:packed_ice
setblock 163 77 315 minecraft:snow_block
fill 163 77 316 163 80 316 minecraft:packed_ice
fill 164 77 315 164 80 315 minecraft:packed_ice
setblock 165 77 278 minecraft:snow_block
setblock 165 77 314 minecraft:packed_ice
setblock 166 77 277 minecraft:snow_block
fill 166 77 278 166 80 278 minecraft:packed_ice
setblock 167 77 276 minecraft:snow_block
fill 167 77 277 167 80 277 minecraft:packed_ice
setblock 167 77 316 minecraft:snow_block
fill 168 77 276 168 80 276 minecraft:packed_ice
setblock 168 77 315 minecraft:snow_block
fill 168 77 316 168 80 316 minecraft:packed_ice
fill 169 77 315 172 77 315 minecraft:packed_ice
setblock 171 77 277 minecraft:snow_block
setblock 172 77 276 minecraft:snow_block
setblock 172 77 316 minecraft:snow_block
fill 173 77 276 173 80 276 minecraft:packed_ice
setblock 173 77 315 minecraft:snow_block
fill 173 77 316 173 80 316 minecraft:packed_ice
setblock 174 77 315 minecraft:packed_ice
setblock 176 77 276 minecraft:packed_ice
setblock 177 77 276 minecraft:snow_block
fill 177 77 304 181 77 304 minecraft:blue_ice
setblock 177 77 316 minecraft:snow_block
fill 178 77 276 178 80 276 minecraft:packed_ice
setblock 178 77 315 minecraft:snow_block
fill 178 77 316 178 80 316 minecraft:packed_ice
fill 179 77 315 179 80 315 minecraft:packed_ice
setblock 181 77 296 minecraft:packed_ice
setblock 181 77 297 minecraft:snow_block
fill 181 77 298 181 78 300 minecraft:packed_ice
setblock 181 77 312 minecraft:snow_block
fill 181 77 313 181 80 313 minecraft:packed_ice
setblock 182 77 276 minecraft:snow_block
fill 182 77 277 182 80 277 minecraft:packed_ice
setblock 182 77 291 minecraft:snow_block
fill 182 77 292 182 80 292 minecraft:packed_ice
setblock 182 77 296 minecraft:snow_block
fill 182 77 297 182 80 297 minecraft:packed_ice
setblock 182 77 301 minecraft:snow_block
fill 182 77 302 182 80 302 minecraft:packed_ice
setblock 182 77 306 minecraft:snow_block
fill 182 77 307 182 80 307 minecraft:packed_ice
setblock 182 77 311 minecraft:snow_block
fill 182 77 312 182 80 312 minecraft:packed_ice
setblock 182 77 316 minecraft:snow_block
fill 141 78 279 141 81 280 minecraft:packed_ice
setblock 141 78 281 minecraft:white_concrete
fill 141 78 282 141 110 282 minecraft:packed_ice
fill 142 78 276 142 81 276 minecraft:packed_ice
setblock 142 78 279 minecraft:packed_ice
setblock 142 78 280 minecraft:snow_block
setblock 142 78 290 minecraft:snow_block
fill 142 78 291 142 78 294 minecraft:packed_ice
setblock 142 78 295 minecraft:snow_block
fill 142 78 296 142 81 296 minecraft:packed_ice
setblock 142 78 300 minecraft:snow_block
fill 142 78 301 142 81 301 minecraft:packed_ice
setblock 142 78 305 minecraft:snow_block
fill 142 78 306 142 81 306 minecraft:packed_ice
setblock 142 78 310 minecraft:snow_block
fill 142 78 311 142 81 311 minecraft:packed_ice
setblock 142 78 315 minecraft:snow_block
fill 142 78 316 142 81 316 minecraft:packed_ice
fill 143 78 290 143 81 290 minecraft:packed_ice
setblock 143 78 294 minecraft:snow_block
fill 143 78 295 143 81 295 minecraft:packed_ice
setblock 143 78 299 minecraft:snow_block
fill 143 78 300 143 81 300 minecraft:packed_ice
setblock 143 78 304 minecraft:snow_block
setblock 143 78 315 minecraft:packed_ice
setblock 144 78 277 minecraft:packed_ice
setblock 144 78 293 minecraft:snow_block
fill 144 78 294 144 81 294 minecraft:packed_ice
setblock 144 78 298 minecraft:snow_block
fill 144 78 299 144 81 299 minecraft:packed_ice
fill 145 78 277 145 78 278 minecraft:snow_block
setblock 145 78 297 minecraft:snow_block
fill 145 78 298 145 81 298 minecraft:packed_ice
setblock 146 78 276 minecraft:snow_block
fill 146 78 277 146 81 277 minecraft:packed_ice
setblock 146 78 316 minecraft:snow_block
fill 147 78 276 147 81 276 minecraft:packed_ice
fill 147 78 316 147 80 316 minecraft:packed_ice
fill 150 78 290 151 78 290 minecraft:blue_ice
setblock 151 78 276 minecraft:snow_block
fill 152 78 276 155 78 276 minecraft:packed_ice
fill 154 78 286 154 79 286 minecraft:packed_ice
fill 154 78 289 154 79 289 minecraft:packed_ice
setblock 156 78 276 minecraft:snow_block
fill 156 78 286 157 79 286 minecraft:packed_ice
fill 157 78 276 160 78 276 minecraft:packed_ice
fill 157 78 287 157 79 287 minecraft:packed_ice
fill 157 78 289 157 79 289 minecraft:packed_ice
fill 158 78 277 159 78 277 minecraft:packed_ice
fill 158 78 316 160 78 316 minecraft:packed_ice
fill 159 78 317 159 111 317 minecraft:packed_ice
setblock 160 78 277 minecraft:snow_block
fill 160 78 303 162 131 304 minecraft:snow_block
setblock 161 78 276 minecraft:snow_block
fill 161 78 277 161 80 278 minecraft:packed_ice
fill 161 78 302 161 131 302 minecraft:snow_block
fill 161 78 305 161 131 305 minecraft:snow_block
setblock 161 78 315 minecraft:packed_ice
setblock 161 78 316 minecraft:snow_block
fill 162 78 276 162 81 276 minecraft:packed_ice
setblock 162 78 315 minecraft:snow_block
fill 162 78 316 162 81 316 minecraft:packed_ice
fill 163 78 315 163 81 315 minecraft:packed_ice
setblock 164 78 278 minecraft:snow_block
setblock 165 78 277 minecraft:snow_block
fill 165 78 278 165 81 278 minecraft:packed_ice
setblock 166 78 276 minecraft:snow_block
fill 166 78 277 166 81 277 minecraft:packed_ice
setblock 166 78 316 minecraft:snow_block
fill 167 78 276 167 81 276 minecraft:packed_ice
setblock 167 78 315 minecraft:snow_block
fill 167 78 316 167 81 316 minecraft:packed_ice
fill 168 78 315 171 78 315 minecraft:packed_ice
setblock 170 78 277 minecraft:snow_block
setblock 171 78 276 minecraft:snow_block
fill 171 78 277 171 79 277 minecraft:packed_ice
setblock 171 78 316 minecraft:snow_block
fill 172 78 276 172 81 276 minecraft:packed_ice
setblock 172 78 315 minecraft:snow_block
fill 172 78 316 172 81 316 minecraft:packed_ice
fill 175 78 317 178 110 317 minecraft:packed_ice
setblock 176 78 276 minecraft:snow_block
setblock 176 78 316 minecraft:snow_block
fill 177 78 276 177 81 276 minecraft:packed_ice
fill 177 78 303 180 80 305 minecraft:snow_block
fill 177 78 316 177 81 316 minecraft:packed_ice
fill 178 78 306 179 85 306 minecraft:snow_block
fill 178 78 315 178 81 315 minecraft:packed_ice
fill 179 78 314 179 82 314 minecraft:packed_ice
setblock 179 78 317 minecraft:white_concrete
fill 180 78 317 183 107 317 minecraft:packed_ice
setblock 181 78 276 minecraft:snow_block
setblock 181 78 296 minecraft:snow_block
fill 181 78 297 181 81 297 minecraft:packed_ice
setblock 181 78 301 minecraft:snow_block
fill 181 78 302 181 81 302 minecraft:packed_ice
fill 181 78 303 181 78 305 minecraft:blue_ice
fill 181 78 312 181 81 312 minecraft:packed_ice
setblock 181 78 316 minecraft:snow_block
fill 182 78 276 182 81 276 minecraft:packed_ice
setblock 182 78 279 minecraft:packed_ice
fill 182 78 291 182 81 291 minecraft:packed_ice
setblock 182 78 294 minecraft:packed_ice
setblock 182 78 295 minecraft:snow_block
fill 182 78 296 182 81 296 minecraft:packed_ice
setblock 182 78 300 minecraft:snow_block
fill 182 78 301 182 81 301 minecraft:packed_ice
setblock 182 78 305 minecraft:snow_block
fill 182 78 306 182 81 306 minecraft:packed_ice
setblock 182 78 310 minecraft:snow_block
fill 182 78 311 182 81 311 minecraft:packed_ice
setblock 182 78 315 minecraft:snow_block
fill 182 78 316 182 81 316 minecraft:packed_ice
fill 141 79 281 142 81 281 minecraft:packed_ice
setblock 141 79 292 minecraft:white_concrete
setblock 141 79 314 minecraft:light_blue_concrete
setblock 142 79 279 minecraft:snow_block
fill 142 79 280 142 82 280 minecraft:packed_ice
fill 142 79 282 142 80 282 minecraft:packed_ice
fill 142 79 287 142 80 287 minecraft:packed_ice
setblock 142 79 289 minecraft:snow_block
fill 142 79 290 142 79 293 minecraft:packed_ice
setblock 142 79 294 minecraft:snow_block
fill 142 79 295 142 82 295 minecraft:packed_ice
setblock 142 79 299 minecraft:snow_block
fill 142 79 300 142 82 300 minecraft:packed_ice
setblock 142 79 304 minecraft:snow_block
fill 142 79 305 142 82 305 minecraft:packed_ice
setblock 142 79 309 minecraft:snow_block
fill 142 79 310 142 82 310 minecraft:packed_ice
setblock 142 79 314 minecraft:snow_block
fill 142 79 315 142 82 315 minecraft:packed_ice
setblock 143 79 277 minecraft:packed_ice
setblock 143 79 278 minecraft:snow_block
setblock 143 79 293 minecraft:snow_block
fill 143 79 294 143 82 294 minecraft:packed_ice
setblock 143 79 298 minecraft:snow_block
fill 143 79 299 143 82 299 minecraft:packed_ice
setblock 143 79 303 minecraft:snow_block
fill 143 79 304 143 82 304 minecraft:packed_ice
setblock 144 79 277 minecraft:snow_block
setblock 144 79 292 minecraft:snow_block
fill 144 79 293 144 82 293 minecraft:packed_ice
setblock 144 79 297 minecraft:snow_block
fill 144 79 298 144 82 298 minecraft:packed_ice
setblock 144 79 302 minecraft:snow_block
setblock 145 79 276 minecraft:snow_block
fill 145 79 277 145 82 277 minecraft:packed_ice
fill 145 79 278 145 82 278 minecraft:snow_block
setblock 145 79 296 minecraft:snow_block
fill 145 79 297 145 82 297 minecraft:packed_ice
setblock 145 79 316 minecraft:snow_block
fill 146 79 276 146 82 276 minecraft:packed_ice
fill 146 79 316 146 82 316 minecraft:packed_ice
fill 147 79 279 147 80 279 minecraft:packed_ice
fill 148 79 278 148 80 278 minecraft:packed_ice
fill 148 79 280 148 80 280 minecraft:packed_ice
fill 149 79 279 149 80 279 minecraft:packed_ice
setblock 150 79 276 minecraft:snow_block
fill 151 79 276 154 79 276 minecraft:packed_ice
setblock 151 79 290 minecraft:blue_ice
fill 153 79 286 153 79 289 minecraft:packed_ice
fill 154 79 285 156 79 285 minecraft:packed_ice
fill 154 79 290 157 79 290 minecraft:packed_ice
setblock 155 79 275 minecraft:light_blue_concrete
setblock 155 79 276 minecraft:snow_block
fill 156 79 275 159 79 276 minecraft:packed_ice
fill 156 79 307 157 131 308 minecraft:snow_block
fill 157 79 277 158 79 277 minecraft:packed_ice
fill 158 79 287 158 79 289 minecraft:packed_ice
fill 158 79 316 159 79 316 minecraft:packed_ice
setblock 159 79 277 minecraft:snow_block
fill 159 79 303 159 80 304 minecraft:packed_ice
setblock 160 79 276 minecraft:snow_block
fill 160 79 277 160 81 278 minecraft:packed_ice
fill 160 79 302 160 80 302 minecraft:packed_ice
fill 160 79 305 160 80 305 minecraft:packed_ice
setblock 160 79 316 minecraft:snow_block
setblock 160 79 317 minecraft:light_blue_concrete
fill 161 79 276 161 82 276 minecraft:packed_ice
setblock 161 79 315 minecraft:snow_block
fill 161 79 316 161 82 317 minecraft:packed_ice
fill 162 79 302 162 80 302 minecraft:packed_ice
fill 162 79 305 162 80 305 minecraft:packed_ice
fill 162 79 315 162 82 315 minecraft:packed_ice
fill 162 79 317 165 84 317 minecraft:packed_ice
setblock 163 79 278 minecraft:snow_block
setblock 164 79 277 minecraft:snow_block
fill 164 79 278 164 82 278 minecraft:packed_ice
setblock 165 79 276 minecraft:snow_block
fill 165 79 277 165 82 277 minecraft:packed_ice
setblock 165 79 316 minecraft:snow_block
fill 166 79 276 166 82 276 minecraft:packed_ice
setblock 166 79 315 minecraft:snow_block
fill 166 79 316 166 82 316 minecraft:packed_ice
fill 167 79 315 170 79 315 minecraft:packed_ice
setblock 168 79 278 minecraft:snow_block
setblock 169 79 277 minecraft:snow_block
setblock 170 79 276 minecraft:snow_block
fill 170 79 277 170 82 277 minecraft:packed_ice
setblock 170 79 316 minecraft:snow_block
fill 171 79 276 171 82 276 minecraft:packed_ice
setblock 171 79 315 minecraft:snow_block
fill 171 79 316 171 82 316 minecraft:packed_ice
fill 175 79 275 179 91 275 minecraft:packed_ice
setblock 175 79 276 minecraft:snow_block
setblock 175 79 316 minecraft:snow_block
fill 176 79 276 176 82 276 minecraft:packed_ice
fill 176 79 303 176 80 306 minecraft:packed_ice
fill 176 79 316 176 82 316 minecraft:packed_ice
fill 177 79 302 180 80 302 minecraft:packed_ice
fill 177 79 306 177 80 306 minecraft:packed_ice
fill 178 79 307 179 80 307 minecraft:packed_ice
fill 179 79 317 179 111 317 minecraft:packed_ice
setblock 180 79 275 minecraft:white_concrete
setblock 180 79 276 minecraft:snow_block
fill 180 79 306 180 80 306 minecraft:packed_ice
setblock 180 79 316 minecraft:snow_block
fill 181 79 275 181 82 276 minecraft:packed_ice
setblock 181 79 294 minecraft:packed_ice
setblock 181 79 295 minecraft:snow_block
fill 181 79 296 181 82 296 minecraft:packed_ice
fill 181 79 298 181 79 299 minecraft:packed_ice
setblock 181 79 300 minecraft:snow_block
fill 181 79 301 181 82 301 minecraft:packed_ice
fill 181 79 303 181 79 305 minecraft:packed_ice
setblock 181 79 315 minecraft:snow_block
fill 181 79 316 181 82 316 minecraft:packed_ice
fill 182 79 275 183 110 275 minecraft:packed_ice
setblock 182 79 279 minecraft:snow_block
fill 182 79 280 182 82 280 minecraft:packed_ice
setblock 182 79 294 minecraft:snow_block
fill 182 79 295 182 82 295 minecraft:packed_ice
setblock 182 79 299 minecraft:snow_block
fill 182 79 300 182 82 300 minecraft:packed_ice
setblock 182 79 304 minecraft:snow_block
fill 182 79 305 182 82 305 minecraft:packed_ice
setblock 182 79 309 minecraft:snow_block
fill 182 79 310 182 82 310 minecraft:packed_ice
setblock 182 79 314 minecraft:snow_block
fill 182 79 315 182 82 315 minecraft:packed_ice
fill 141 80 292 142 80 292 minecraft:packed_ice
fill 141 80 295 141 84 300 minecraft:packed_ice
setblock 141 80 301 minecraft:light_blue_concrete
fill 141 80 302 141 90 306 minecraft:packed_ice
fill 141 80 314 142 83 314 minecraft:packed_ice
setblock 142 80 275 minecraft:light_blue_concrete
setblock 142 80 277 minecraft:packed_ice
setblock 142 80 278 minecraft:snow_block
fill 142 80 279 143 82 279 minecraft:packed_ice
setblock 142 80 283 minecraft:snow_block
fill 142 80 284 142 81 286 minecraft:packed_ice
setblock 142 80 288 minecraft:snow_block
fill 142 80 289 142 81 291 minecraft:packed_ice
setblock 142 80 293 minecraft:snow_block
fill 142 80 294 142 83 294 minecraft:packed_ice
setblock 142 80 298 minecraft:snow_block
fill 142 80 299 142 83 299 minecraft:packed_ice
setblock 142 80 303 minecraft:snow_block
fill 142 80 304 142 83 304 minecraft:packed_ice
setblock 142 80 308 minecraft:snow_block
fill 142 80 309 142 83 309 minecraft:packed_ice
setblock 142 80 313 minecraft:snow_block
fill 143 80 275 145 110 275 minecraft:packed_ice
setblock 143 80 277 minecraft:snow_block
fill 143 80 278 143 83 278 minecraft:packed_ice
fill 143 80 280 143 81 280 minecraft:packed_ice
setblock 143 80 292 minecraft:snow_block
fill 143 80 293 143 83 293 minecraft:packed_ice
setblock 143 80 297 minecraft:snow_block
fill 143 80 298 143 83 298 minecraft:packed_ice
setblock 143 80 302 minecraft:snow_block
fill 143 80 303 143 83 303 minecraft:packed_ice
fill 143 80 305 143 81 305 minecraft:packed_ice
setblock 144 80 276 minecraft:snow_block
fill 144 80 277 144 83 277 minecraft:packed_ice
fill 144 80 292 144 82 292 minecraft:packed_ice
setblock 144 80 296 minecraft:snow_block
fill 144 80 297 144 83 297 minecraft:packed_ice
setblock 144 80 301 minecraft:snow_block
fill 144 80 302 144 83 302 minecraft:packed_ice
setblock 144 80 316 minecraft:snow_block
fill 145 80 276 145 83 276 minecraft:packed_ice
fill 145 80 296 145 81 296 minecraft:packed_ice
setblock 145 80 299 minecraft:packed_ice
fill 145 80 316 145 83 316 minecraft:packed_ice
setblock 148 80 277 minecraft:snow_block
setblock 149 80 276 minecraft:snow_block
fill 150 80 276 153 80 276 minecraft:packed_ice
setblock 154 80 276 minecraft:snow_block
fill 155 80 275 158 80 276 minecraft:packed_ice
fill 156 80 277 157 80 277 minecraft:packed_ice
setblock 158 80 277 minecraft:snow_block
fill 158 80 303 158 80 304 minecraft:packed_ice
setblock 158 80 316 minecraft:packed_ice
fill 159 80 275 159 110 275 minecraft:packed_ice
setblock 159 80 276 minecraft:snow_block
fill 159 80 277 159 82 278 minecraft:packed_ice
setblock 159 80 302 minecraft:packed_ice
setblock 159 80 305 minecraft:packed_ice
setblock 159 80 316 minecraft:snow_block
fill 160 80 276 160 83 276 minecraft:packed_ice
fill 160 80 301 162 80 301 minecraft:packed_ice
fill 160 80 306 162 80 306 minecraft:packed_ice
fill 160 80 316 160 83 317 minecraft:packed_ice
fill 161 80 315 161 83 315 minecraft:packed_ice
setblock 162 80 277 minecraft:packed_ice
setblock 162 80 278 minecraft:snow_block
setblock 163 80 277 minecraft:snow_block
fill 163 80 278 163 82 279 minecraft:packed_ice
fill 163 80 302 163 80 305 minecraft:packed_ice
setblock 164 80 276 minecraft:snow_block
fill 164 80 277 164 83 277 minecraft:packed_ice
setblock 164 80 316 minecraft:snow_block
fill 165 80 276 165 83 276 minecraft:packed_ice
setblock 165 80 315 minecraft:snow_block
fill 165 80 316 165 83 316 minecraft:packed_ice
fill 166 80 315 169 80 315 minecraft:packed_ice
setblock 167 80 278 minecraft:snow_block
fill 167 80 297 170 131 299 minecraft:snow_block
setblock 168 80 277 minecraft:snow_block
fill 168 80 278 168 83 278 minecraft:packed_ice
fill 168 80 296 170 131 296 minecraft:snow_block
setblock 169 80 276 minecraft:snow_block
fill 169 80 277 169 83 277 minecraft:packed_ice
setblock 169 80 316 minecraft:snow_block
fill 170 80 276 170 83 276 minecraft:packed_ice
setblock 170 80 315 minecraft:snow_block
fill 170 80 316 170 83 316 minecraft:packed_ice
setblock 174 80 276 minecraft:snow_block
setblock 174 80 316 minecraft:snow_block
fill 175 80 276 175 83 276 minecraft:packed_ice
fill 175 80 303 175 80 306 minecraft:packed_ice
fill 175 80 316 175 83 316 minecraft:packed_ice
setblock 176 80 302 minecraft:packed_ice
fill 176 80 307 177 80 307 minecraft:packed_ice
fill 177 80 301 180 80 301 minecraft:packed_ice
fill 178 80 308 179 80 308 minecraft:packed_ice
setblock 179 80 276 minecraft:snow_block
setblock 179 80 316 minecraft:snow_block
fill 180 80 275 180 83 276 minecraft:packed_ice
setblock 180 80 299 minecraft:packed_ice
setblock 180 80 300 minecraft:snow_block
fill 180 80 307 181 80 307 minecraft:packed_ice
setblock 180 80 315 minecraft:snow_block
fill 180 80 316 180 83 316 minecraft:packed_ice
fill 181 80 277 181 81 277 minecraft:packed_ice
setblock 181 80 294 minecraft:snow_block
fill 181 80 295 181 83 295 minecraft:packed_ice
setblock 181 80 298 minecraft:packed_ice
setblock 181 80 299 minecraft:snow_block
fill 181 80 300 181 83 300 minecraft:packed_ice
setblock 181 80 303 minecraft:packed_ice
setblock 181 80 304 minecraft:snow_block
fill 181 80 305 181 82 306 minecraft:packed_ice
setblock 181 80 314 minecraft:snow_block
fill 181 80 315 181 83 315 minecraft:packed_ice
setblock 182 80 278 minecraft:snow_block
fill 182 80 279 182 83 279 minecraft:packed_ice
fill 182 80 281 182 81 281 minecraft:packed_ice
setblock 182 80 293 minecraft:snow_block
fill 182 80 294 182 83 294 minecraft:packed_ice
setblock 182 80 298 minecraft:snow_block
fill 182 80 299 182 83 299 minecraft:packed_ice
setblock 182 80 303 minecraft:snow_block
fill 182 80 304 182 83 304 minecraft:packed_ice
setblock 182 80 308 minecraft:snow_block
fill 182 80 309 182 83 309 minecraft:packed_ice
setblock 182 80 313 minecraft:snow_block
fill 182 80 314 182 83 314 minecraft:packed_ice
setblock 183 80 307 minecraft:white_concrete
fill 141 81 292 141 111 292 minecraft:packed_ice
fill 141 81 301 141 88 301 minecraft:packed_ice
fill 142 81 275 142 114 275 minecraft:packed_ice
setblock 142 81 277 minecraft:snow_block
fill 142 81 278 142 84 278 minecraft:packed_ice
setblock 142 81 282 minecraft:snow_block
fill 142 81 283 143 83 283 minecraft:packed_ice
setblock 142 81 287 minecraft:snow_block
fill 142 81 288 142 84 288 minecraft:packed_ice
setblock 142 81 292 minecraft:snow_block
fill 142 81 293 142 84 293 minecraft:packed_ice
setblock 142 81 297 minecraft:snow_block
fill 142 81 298 142 84 298 minecraft:packed_ice
setblock 142 81 302 minecraft:snow_block
fill 142 81 303 142 84 303 minecraft:packed_ice
setblock 142 81 307 minecraft:snow_block
fill 142 81 308 142 84 308 minecraft:packed_ice
setblock 142 81 312 minecraft:snow_block
fill 142 81 313 142 84 313 minecraft:packed_ice
setblock 143 81 276 minecraft:snow_block
fill 143 81 277 143 84 277 minecraft:packed_ice
setblock 143 81 281 minecraft:snow_block
fill 143 81 282 143 84 282 minecraft:packed_ice
fill 143 81 289 143 82 289 minecraft:packed_ice
setblock 143 81 291 minecraft:snow_block
fill 143 81 292 143 84 292 minecraft:packed_ice
setblock 143 81 296 minecraft:snow_block
fill 143 81 297 143 84 297 minecraft:packed_ice
setblock 143 81 301 minecraft:snow_block
fill 143 81 302 143 84 302 minecraft:packed_ice
setblock 143 81 306 minecraft:snow_block
setblock 143 81 316 minecraft:snow_block
fill 144 81 276 144 84 276 minecraft:packed_ice
setblock 144 81 295 minecraft:snow_block
fill 144 81 296 144 84 296 minecraft:packed_ice
setblock 144 81 300 minecraft:snow_block
fill 144 81 301 144 84 301 minecraft:packed_ice
fill 144 81 303 144 82 303 minecraft:packed_ice
fill 144 81 316 144 84 316 minecraft:packed_ice
setblock 145 81 299 minecraft:snow_block
setblock 147 81 277 minecraft:snow_block
setblock 148 81 276 minecraft:snow_block
fill 148 81 277 149 83 277 minecraft:packed_ice
fill 149 81 276 152 81 276 minecraft:packed_ice
setblock 153 81 276 minecraft:snow_block
fill 154 81 276 157 81 276 minecraft:packed_ice
fill 155 81 275 158 105 275 minecraft:packed_ice
fill 155 81 277 156 81 277 minecraft:packed_ice
fill 155 81 307 155 81 308 minecraft:packed_ice
fill 156 81 306 157 81 306 minecraft:packed_ice
fill 156 81 309 157 81 309 minecraft:packed_ice
setblock 157 81 277 minecraft:snow_block
fill 157 81 278 158 83 278 minecraft:packed_ice
setblock 157 81 316 minecraft:packed_ice
setblock 158 81 276 minecraft:snow_block
fill 158 81 277 158 84 277 minecraft:packed_ice
fill 158 81 307 158 81 308 minecraft:packed_ice
setblock 158 81 316 minecraft:snow_block
fill 159 81 276 159 84 276 minecraft:packed_ice
fill 159 81 316 159 84 316 minecraft:packed_ice
fill 160 81 315 160 84 315 minecraft:packed_ice
setblock 161 81 277 minecraft:packed_ice
setblock 161 81 278 minecraft:snow_block
fill 161 81 279 162 83 279 minecraft:packed_ice
fill 161 81 313 163 82 314 minecraft:blue_ice
setblock 162 81 277 minecraft:snow_block
fill 162 81 278 162 84 278 minecraft:packed_ice
fill 162 81 312 162 83 312 minecraft:blue_ice
setblock 163 81 276 minecraft:snow_block
fill 163 81 277 163 84 277 minecraft:packed_ice
setblock 163 81 316 minecraft:snow_block
fill 164 81 276 164 84 276 minecraft:packed_ice
setblock 164 81 279 minecraft:packed_ice
setblock 164 81 315 minecraft:snow_block
fill 164 81 316 164 84 316 minecraft:packed_ice
setblock 165 81 279 minecraft:snow_block
fill 165 81 315 168 81 315 minecraft:packed_ice
setblock 166 81 278 minecraft:snow_block
fill 166 81 297 166 82 299 minecraft:packed_ice
setblock 167 81 277 minecraft:snow_block
fill 167 81 278 167 84 278 minecraft:packed_ice
fill 167 81 296 167 82 296 minecraft:packed_ice
fill 167 81 300 170 82 300 minecraft:packed_ice
setblock 167 81 317 minecraft:white_concrete
setblock 168 81 276 minecraft:snow_block
fill 168 81 277 168 84 277 minecraft:packed_ice
fill 168 81 295 170 82 295 minecraft:packed_ice
setblock 168 81 316 minecraft:snow_block
fill 168 81 317 171 111 317 minecraft:packed_ice
fill 169 81 276 169 84 276 minecraft:packed_ice
setblock 169 81 315 minecraft:snow_block
fill 169 81 316 169 84 316 minecraft:packed_ice
fill 171 81 296 171 82 299 minecraft:packed_ice
setblock 173 81 276 minecraft:snow_block
setblock 173 81 316 minecraft:snow_block
fill 174 81 276 174 84 276 minecraft:packed_ice
fill 174 81 316 174 84 316 minecraft:packed_ice
fill 177 81 303 179 83 305 minecraft:snow_block
setblock 178 81 276 minecraft:snow_block
fill 178 81 314 178 82 314 minecraft:packed_ice
setblock 178 81 316 minecraft:snow_block
fill 179 81 276 179 84 276 minecraft:packed_ice
fill 179 81 313 179 82 313 minecraft:packed_ice
setblock 179 81 315 minecraft:snow_block
fill 179 81 316 179 84 316 minecraft:packed_ice
fill 180 81 277 180 82 277 minecraft:packed_ice
fill 180 81 297 180 81 298 minecraft:packed_ice
setblock 180 81 299 minecraft:snow_block
fill 180 81 300 180 81 303 minecraft:packed_ice
fill 180 81 304 180 81 305 minecraft:snow_block
fill 180 81 314 180 82 315 minecraft:packed_ice
setblock 181 81 278 minecraft:snow_block
fill 181 81 279 181 84 279 minecraft:packed_ice
fill 181 81 294 181 84 294 minecraft:packed_ice
setblock 181 81 298 minecraft:snow_block
fill 181 81 299 181 84 299 minecraft:packed_ice
setblock 181 81 303 minecraft:snow_block
fill 181 81 304 181 84 304 minecraft:packed_ice
setblock 181 81 307 minecraft:packed_ice
setblock 181 81 308 minecraft:snow_block
fill 181 81 309 181 82 311 minecraft:packed_ice
setblock 181 81 313 minecraft:snow_block
fill 181 81 314 181 84 314 minecraft:packed_ice
setblock 182 81 277 minecraft:snow_block
fill 182 81 278 182 84 278 minecraft:packed_ice
setblock 182 81 282 minecraft:snow_block
fill 182 81 283 182 84 283 minecraft:packed_ice
fill 182 81 290 182 82 290 minecraft:packed_ice
setblock 182 81 292 minecraft:snow_block
fill 182 81 293 182 84 293 minecraft:packed_ice
setblock 182 81 297 minecraft:snow_block
fill 182 81 298 182 84 298 minecraft:packed_ice
setblock 182 81 302 minecraft:snow_block
fill 182 81 303 182 84 303 minecraft:packed_ice
setblock 182 81 307 minecraft:snow_block
fill 182 81 308 182 84 308 minecraft:packed_ice
setblock 182 81 312 minecraft:snow_block
fill 182 81 313 182 84 313 minecraft:packed_ice
setblock 183 81 280 minecraft:light_blue_concrete
fill 183 81 307 183 114 307 minecraft:packed_ice
fill 141 82 279 141 111 279 minecraft:packed_ice
setblock 141 82 280 minecraft:light_blue_concrete
fill 141 82 281 141 83 281 minecraft:packed_ice
setblock 142 82 276 minecraft:snow_block
fill 142 82 277 142 85 277 minecraft:packed_ice
setblock 142 82 281 minecraft:snow_block
fill 142 82 282 142 85 282 minecraft:packed_ice
fill 142 82 284 142 82 285 minecraft:packed_ice
setblock 142 82 286 minecraft:snow_block
fill 142 82 287 143 84 287 minecraft:packed_ice
fill 142 82 289 142 82 290 minecraft:packed_ice
setblock 142 82 291 minecraft:snow_block
fill 142 82 292 142 85 292 minecraft:packed_ice
setblock 142 82 296 minecraft:snow_block
fill 142 82 297 142 85 297 minecraft:packed_ice
setblock 142 82 301 minecraft:snow_block
fill 142 82 302 142 85 302 minecraft:packed_ice
setblock 142 82 306 minecraft:snow_block
fill 142 82 307 142 85 307 minecraft:packed_ice
setblock 142 82 311 minecraft:snow_block
fill 142 82 312 142 85 312 minecraft:packed_ice
setblock 142 82 316 minecraft:snow_block
fill 143 82 276 143 85 276 minecraft:packed_ice
setblock 143 82 280 minecraft:snow_block
fill 143 82 281 144 84 281 minecraft:packed_ice
setblock 143 82 284 minecraft:packed_ice
setblock 143 82 285 minecraft:snow_block
fill 143 82 286 143 85 286 minecraft:packed_ice
fill 143 82 288 143 83 288 minecraft:packed_ice
setblock 143 82 290 minecraft:snow_block
fill 143 82 291 143 85 291 minecraft:packed_ice
setblock 143 82 295 minecraft:snow_block
fill 143 82 296 143 85 296 minecraft:packed_ice
setblock 143 82 300 minecraft:snow_block
fill 143 82 301 143 85 301 minecraft:packed_ice
setblock 143 82 305 minecraft:snow_block
fill 143 82 306 143 85 306 minecraft:packed_ice
fill 143 82 316 143 85 316 minecraft:packed_ice
setblock 144 82 278 minecraft:packed_ice
fill 144 82 279 145 82 279 minecraft:snow_block
fill 144 82 280 144 85 280 minecraft:packed_ice
setblock 144 82 285 minecraft:light[level=12]
setblock 144 82 294 minecraft:snow_block
fill 144 82 295 144 85 295 minecraft:packed_ice
setblock 144 82 299 minecraft:snow_block
fill 144 82 300 145 84 300 minecraft:packed_ice
setblock 144 82 304 minecraft:snow_block
setblock 144 82 306 minecraft:light[level=12]
setblock 144 82 313 minecraft:light[level=12]
setblock 145 82 298 minecraft:snow_block
fill 145 82 299 145 84 299 minecraft:packed_ice
fill 146 82 277 146 82 278 minecraft:snow_block
setblock 147 82 276 minecraft:snow_block
fill 147 82 277 147 85 277 minecraft:packed_ice
fill 148 82 276 151 82 276 minecraft:packed_ice
setblock 150 82 277 minecraft:packed_ice
setblock 151 82 278 minecraft:light[level=12]
setblock 151 82 285 minecraft:light[level=12]
setblock 151 82 292 minecraft:light[level=12]
setblock 151 82 299 minecraft:light[level=12]
setblock 151 82 306 minecraft:light[level=12]
setblock 151 82 313 minecraft:light[level=12]
setblock 152 82 276 minecraft:snow_block
fill 152 82 277 155 82 277 minecraft:packed_ice
fill 153 82 276 156 82 276 minecraft:packed_ice
setblock 156 82 277 minecraft:snow_block
fill 156 82 278 156 85 278 minecraft:packed_ice
setblock 157 82 276 minecraft:snow_block
fill 157 82 277 157 85 277 minecraft:packed_ice
setblock 157 82 316 minecraft:snow_block
fill 158 82 276 158 85 276 minecraft:packed_ice
setblock 158 82 285 minecraft:light[level=12]
setblock 158 82 292 minecraft:light[level=12]
setblock 158 82 299 minecraft:light[level=12]
setblock 158 82 306 minecraft:light[level=12]
setblock 158 82 313 minecraft:light[level=12]
fill 158 82 316 158 85 316 minecraft:packed_ice
setblock 159 82 279 minecraft:snow_block
setblock 160 82 277 minecraft:packed_ice
setblock 160 82 278 minecraft:snow_block
fill 160 82 279 160 85 279 minecraft:packed_ice
setblock 161 82 277 minecraft:snow_block
fill 161 82 278 161 85 278 minecraft:packed_ice
setblock 161 82 312 minecraft:blue_ice
setblock 162 82 276 minecraft:snow_block
fill 162 82 277 162 85 277 minecraft:packed_ice
fill 162 82 309 162 83 311 minecraft:blue_ice
setblock 162 82 316 minecraft:snow_block
fill 163 82 276 163 85 276 minecraft:packed_ice
setblock 163 82 312 minecraft:blue_ice
setblock 163 82 315 minecraft:snow_block
fill 163 82 316 163 85 316 minecraft:packed_ice
setblock 164 82 279 minecraft:snow_block
fill 164 82 315 167 82 315 minecraft:packed_ice
setblock 165 82 278 minecraft:snow_block
fill 165 82 279 165 85 279 minecraft:packed_ice
setblock 165 82 285 minecraft:light[level=12]
setblock 165 82 292 minecraft:light[level=12]
fill 165 82 297 165 82 299 minecraft:packed_ice
setblock 165 82 306 minecraft:light[level=12]
setblock 165 82 313 minecraft:light[level=12]
setblock 166 82 277 minecraft:snow_block
fill 166 82 278 166 85 278 minecraft:packed_ice
fill 166 82 295 166 82 296 minecraft:packed_ice
setblock 166 82 300 minecraft:packed_ice
setblock 167 82 276 minecraft:snow_block
fill 167 82 277 167 85 277 minecraft:packed_ice
setblock 167 82 295 minecraft:packed_ice
fill 167 82 301 170 82 301 minecraft:packed_ice
setblock 167 82 316 minecraft:snow_block
fill 167 82 317 167 114 317 minecraft:packed_ice
fill 168 82 276 168 85 276 minecraft:packed_ice
fill 168 82 294 169 82 294 minecraft:packed_ice
setblock 168 82 315 minecraft:snow_block
fill 168 82 316 168 85 316 minecraft:packed_ice
setblock 169 82 315 minecraft:packed_ice
setblock 171 82 295 minecraft:packed_ice
setblock 171 82 300 minecraft:packed_ice
setblock 172 82 276 minecraft:snow_block
setblock 172 82 278 minecraft:light[level=12]
setblock 172 82 285 minecraft:light[level=12]
setblock 172 82 292 minecraft:light[level=12]
fill 172 82 296 172 82 299 minecraft:packed_ice
setblock 172 82 306 minecraft:light[level=12]
setblock 172 82 313 minecraft:light[level=12]
setblock 172 82 316 minecraft:snow_block
fill 173 82 276 173 85 276 minecraft:packed_ice
fill 173 82 316 173 85 316 minecraft:packed_ice
setblock 177 82 276 minecraft:snow_block
setblock 177 82 316 minecraft:snow_block
fill 178 82 276 178 84 277 minecraft:packed_ice
setblock 178 82 315 minecraft:snow_block
fill 178 82 316 178 85 316 minecraft:packed_ice
fill 179 82 277 179 83 277 minecraft:packed_ice
setblock 179 82 278 minecraft:light[level=12]
setblock 179 82 285 minecraft:light[level=12]
setblock 179 82 292 minecraft:light[level=12]
setblock 179 82 299 minecraft:light[level=12]
fill 179 82 315 179 85 315 minecraft:packed_ice
fill 180 82 296 180 82 297 minecraft:packed_ice
setblock 180 82 298 minecraft:snow_block
fill 180 82 299 180 82 302 minecraft:packed_ice
setblock 180 82 303 minecraft:snow_block
fill 180 82 304 180 84 305 minecraft:packed_ice
setblock 181 82 277 minecraft:snow_block
fill 181 82 278 181 85 278 minecraft:packed_ice
fill 181 82 280 181 83 280 minecraft:packed_ice
fill 181 82 293 181 85 293 minecraft:packed_ice
setblock 181 82 297 minecraft:snow_block
fill 181 82 298 181 85 298 minecraft:packed_ice
setblock 181 82 302 minecraft:snow_block
fill 181 82 303 181 85 303 minecraft:packed_ice
setblock 181 82 307 minecraft:snow_block
fill 181 82 308 181 85 308 minecraft:packed_ice
setblock 181 82 312 minecraft:snow_block
fill 181 82 313 181 85 313 minecraft:packed_ice
setblock 182 82 276 minecraft:snow_block
fill 182 82 277 182 85 277 minecraft:packed_ice
setblock 182 82 281 minecraft:snow_block
fill 182 82 282 182 85 282 minecraft:packed_ice
fill 182 82 284 182 82 285 minecraft:packed_ice
fill 182 82 289 182 83 289 minecraft:packed_ice
setblock 182 82 291 minecraft:snow_block
fill 182 82 292 182 85 292 minecraft:packed_ice
setblock 182 82 296 minecraft:snow_block
fill 182 82 297 182 85 297 minecraft:packed_ice
setblock 182 82 301 minecraft:snow_block
fill 182 82 302 182 85 302 minecraft:packed_ice
setblock 182 82 306 minecraft:snow_block
fill 182 82 307 182 85 307 minecraft:packed_ice
setblock 182 82 311 minecraft:snow_block
fill 182 82 312 182 85 312 minecraft:packed_ice
setblock 182 82 316 minecraft:snow_block
fill 183 82 280 183 114 280 minecraft:packed_ice
setblock 183 82 290 minecraft:light_blue_concrete
fill 183 82 291 183 110 291 minecraft:packed_ice
fill 141 83 280 141 114 280 minecraft:packed_ice
fill 142 83 276 142 86 276 minecraft:packed_ice
setblock 142 83 279 minecraft:packed_ice
setblock 142 83 280 minecraft:snow_block
fill 142 83 281 142 86 281 minecraft:packed_ice
setblock 142 83 284 minecraft:packed_ice
setblock 142 83 285 minecraft:snow_block
fill 142 83 286 142 86 286 minecraft:packed_ice
setblock 142 83 289 minecraft:packed_ice
setblock 142 83 290 minecraft:snow_block
fill 142 83 291 142 86 291 minecraft:packed_ice
setblock 142 83 295 minecraft:snow_block
fill 142 83 296 142 86 296 minecraft:packed_ice
setblock 142 83 300 minecraft:snow_block
fill 142 83 301 142 86 301 minecraft:packed_ice
setblock 142 83 305 minecraft:snow_block
fill 142 83 306 142 86 306 minecraft:packed_ice
setblock 142 83 310 minecraft:snow_block
fill 142 83 311 142 86 311 minecraft:packed_ice
setblock 142 83 315 minecraft:snow_block
fill 142 83 316 142 86 316 minecraft:packed_ice
setblock 143 83 279 minecraft:snow_block
fill 143 83 280 143 86 280 minecraft:packed_ice
setblock 143 83 284 minecraft:snow_block
fill 143 83 285 143 86 285 minecraft:packed_ice
setblock 143 83 289 minecraft:snow_block
fill 143 83 290 143 86 290 minecraft:packed_ice
setblock 143 83 294 minecraft:snow_block
fill 143 83 295 143 86 295 minecraft:packed_ice
setblock 143 83 299 minecraft:snow_block
fill 143 83 300 143 86 300 minecraft:packed_ice
setblock 143 83 304 minecraft:snow_block
fill 143 83 305 143 86 305 minecraft:packed_ice
fill 143 83 307 143 84 307 minecraft:packed_ice
setblock 144 83 278 minecraft:snow_block
fill 144 83 279 144 86 279 minecraft:packed_ice
setblock 144 83 282 minecraft:packed_ice
setblock 144 83 283 minecraft:snow_block
setblock 144 83 293 minecraft:snow_block
fill 144 83 294 144 85 294 minecraft:packed_ice
setblock 144 83 298 minecraft:snow_block
fill 144 83 299 144 86 299 minecraft:packed_ice
setblock 144 83 303 minecraft:snow_block
fill 144 83 304 144 86 304 minecraft:packed_ice
setblock 145 83 277 minecraft:snow_block
fill 145 83 278 146 85 278 minecraft:packed_ice
setblock 145 83 297 minecraft:snow_block
setblock 145 83 298 minecraft:packed_ice
setblock 146 83 276 minecraft:snow_block
fill 146 83 277 146 86 277 minecraft:packed_ice
setblock 147 83 275 minecraft:light_blue_concrete
fill 147 83 276 150 83 276 minecraft:packed_ice
fill 148 83 275 150 110 275 minecraft:packed_ice
setblock 150 83 277 minecraft:snow_block
setblock 151 83 276 minecraft:snow_block
fill 151 83 277 154 83 277 minecraft:packed_ice
fill 152 83 276 155 83 276 minecraft:packed_ice
setblock 155 83 277 minecraft:snow_block
fill 155 83 278 155 86 278 minecraft:packed_ice
setblock 156 83 276 minecraft:snow_block
fill 156 83 277 156 86 277 minecraft:packed_ice
setblock 156 83 316 minecraft:snow_block
fill 157 83 276 157 86 276 minecraft:packed_ice
fill 157 83 316 157 86 316 minecraft:packed_ice
setblock 158 83 279 minecraft:snow_block
setblock 159 83 277 minecraft:packed_ice
setblock 159 83 278 minecraft:snow_block
fill 159 83 279 159 86 279 minecraft:packed_ice
fill 159 83 315 159 85 315 minecraft:packed_ice
setblock 160 83 277 minecraft:snow_block
fill 160 83 278 160 86 278 minecraft:packed_ice
setblock 161 83 276 minecraft:snow_block
fill 161 83 277 161 86 277 minecraft:packed_ice
setblock 161 83 316 minecraft:snow_block
fill 161 83 317 161 114 317 minecraft:packed_ice
fill 162 83 276 162 86 276 minecraft:packed_ice
setblock 162 83 308 minecraft:blue_ice
fill 162 83 313 162 83 314 minecraft:blue_ice
setblock 162 83 315 minecraft:snow_block
fill 162 83 316 162 86 316 minecraft:packed_ice
setblock 163 83 278 minecraft:packed_ice
setblock 163 83 279 minecraft:snow_block
fill 163 83 315 166 83 315 minecraft:packed_ice
setblock 164 83 278 minecraft:snow_block
fill 164 83 279 164 86 279 minecraft:packed_ice
setblock 165 83 277 minecraft:snow_block
fill 165 83 278 165 86 278 minecraft:packed_ice
setblock 166 83 276 minecraft:snow_block
fill 166 83 277 166 86 277 minecraft:packed_ice
setblock 166 83 316 minecraft:snow_block
fill 167 83 276 167 86 276 minecraft:packed_ice
setblock 167 83 315 minecraft:snow_block
fill 167 83 316 167 86 316 minecraft:packed_ice
fill 168 83 315 168 84 315 minecraft:packed_ice
setblock 170 83 277 minecraft:snow_block
setblock 171 83 276 minecraft:snow_block
setblock 171 83 316 minecraft:snow_block
fill 172 83 276 172 86 276 minecraft:packed_ice
fill 172 83 316 172 86 316 minecraft:packed_ice
setblock 176 83 276 minecraft:snow_block
setblock 176 83 316 minecraft:snow_block
fill 177 83 276 177 85 277 minecraft:packed_ice
setblock 177 83 315 minecraft:snow_block
fill 177 83 316 177 86 316 minecraft:packed_ice
fill 178 83 315 178 86 315 minecraft:packed_ice
fill 179 83 299 179 83 302 minecraft:packed_ice
setblock 180 83 277 minecraft:snow_block
setblock 180 83 296 minecraft:packed_ice
setblock 180 83 297 minecraft:snow_block
fill 180 83 298 180 83 301 minecraft:packed_ice
setblock 180 83 302 minecraft:snow_block
fill 180 83 303 180 86 303 minecraft:packed_ice
setblock 180 83 306 minecraft:packed_ice
setblock 180 83 307 minecraft:snow_block
fill 180 83 315 180 84 315 minecraft:packed_ice
fill 181 83 275 181 114 275 minecraft:packed_ice
setblock 181 83 276 minecraft:snow_block
fill 181 83 277 181 86 277 minecraft:packed_ice
setblock 181 83 281 minecraft:snow_block
fill 181 83 282 181 85 283 minecraft:packed_ice
fill 181 83 292 181 86 292 minecraft:packed_ice
setblock 181 83 296 minecraft:snow_block
fill 181 83 297 181 86 297 minecraft:packed_ice
setblock 181 83 301 minecraft:snow_block
fill 181 83 302 181 86 302 minecraft:packed_ice
setblock 181 83 305 minecraft:packed_ice
setblock 181 83 306 minecraft:snow_block
fill 181 83 307 181 86 307 minecraft:packed_ice
fill 181 83 309 181 83 310 minecraft:packed_ice
setblock 181 83 311 minecraft:snow_block
fill 181 83 312 181 86 312 minecraft:packed_ice
setblock 181 83 316 minecraft:snow_block
fill 182 83 276 182 86 276 minecraft:packed_ice
setblock 182 83 280 minecraft:snow_block
fill 182 83 281 182 86 281 minecraft:packed_ice
setblock 182 83 284 minecraft:packed_ice
setblock 182 83 285 minecraft:snow_block
fill 182 83 286 182 84 288 minecraft:packed_ice
setblock 182 83 290 minecraft:snow_block
fill 182 83 291 182 86 291 minecraft:packed_ice
setblock 182 83 295 minecraft:snow_block
fill 182 83 296 182 86 296 minecraft:packed_ice
setblock 182 83 300 minecraft:snow_block
fill 182 83 301 182 86 301 minecraft:packed_ice
setblock 182 83 305 minecraft:snow_block
fill 182 83 306 182 86 306 minecraft:packed_ice
setblock 182 83 310 minecraft:snow_block
fill 182 83 311 182 86 311 minecraft:packed_ice
setblock 182 83 315 minecraft:snow_block
fill 182 83 316 182 86 316 minecraft:packed_ice
fill 183 83 290 183 99 290 minecraft:packed_ice
setblock 141 84 281 minecraft:white_concrete
fill 141 84 314 141 114 314 minecraft:packed_ice
setblock 142 84 279 minecraft:snow_block
fill 142 84 280 142 87 280 minecraft:packed_ice
setblock 142 84 283 minecraft:packed_ice
setblock 142 84 284 minecraft:snow_block
fill 142 84 285 142 87 285 minecraft:packed_ice
setblock 142 84 289 minecraft:snow_block
fill 142 84 290 142 87 290 minecraft:packed_ice
setblock 142 84 294 minecraft:snow_block
fill 142 84 295 142 87 295 minecraft:packed_ice
setblock 142 84 299 minecraft:snow_block
fill 142 84 300 142 87 300 minecraft:packed_ice
setblock 142 84 304 minecraft:snow_block
fill 142 84 305 142 87 305 minecraft:packed_ice
setblock 142 84 309 minecraft:snow_block
fill 142 84 310 142 87 310 minecraft:packed_ice
setblock 142 84 314 minecraft:snow_block
fill 142 84 315 142 86 315 minecraft:packed_ice
setblock 143 84 278 minecraft:snow_block
fill 143 84 279 143 87 279 minecraft:packed_ice
setblock 143 84 283 minecraft:snow_block
fill 143 84 284 144 86 284 minecraft:packed_ice
setblock 143 84 288 minecraft:snow_block
fill 143 84 289 143 87 289 minecraft:packed_ice
setblock 143 84 293 minecraft:snow_block
fill 143 84 294 143 87 294 minecraft:packed_ice
setblock 143 84 298 minecraft:snow_block
fill 143 84 299 143 87 299 minecraft:packed_ice
setblock 143 84 303 minecraft:snow_block
fill 143 84 304 143 87 304 minecraft:packed_ice
setblock 143 84 308 minecraft:snow_block
setblock 144 84 277 minecraft:snow_block
fill 144 84 278 144 86 278 minecraft:packed_ice
setblock 144 84 282 minecraft:snow_block
fill 144 84 283 144 87 283 minecraft:packed_ice
fill 144 84 285 144 85 285 minecraft:packed_ice
setblock 144 84 286 minecraft:light[level=15]
setblock 144 84 293 minecraft:packed_ice
setblock 144 84 297 minecraft:snow_block
fill 144 84 298 144 87 298 minecraft:packed_ice
setblock 144 84 302 minecraft:snow_block
fill 144 84 303 144 87 303 minecraft:packed_ice
fill 144 84 305 144 85 305 minecraft:packed_ice
setblock 144 84 310 minecraft:light[level=15]
setblock 145 84 276 minecraft:snow_block
fill 145 84 277 145 87 277 minecraft:packed_ice
setblock 145 84 316 minecraft:snow_block
fill 146 84 276 149 84 276 minecraft:packed_ice
fill 147 84 275 147 114 275 minecraft:packed_ice
setblock 148 84 277 minecraft:packed_ice
setblock 149 84 277 minecraft:snow_block
setblock 150 84 276 minecraft:snow_block
fill 150 84 277 153 84 277 minecraft:packed_ice
fill 151 84 276 154 84 276 minecraft:packed_ice
setblock 152 84 278 minecraft:light[level=15]
setblock 152 84 286 minecraft:light[level=15]
setblock 152 84 294 minecraft:light[level=15]
setblock 152 84 302 minecraft:light[level=15]
setblock 152 84 310 minecraft:light[level=15]
setblock 154 84 277 minecraft:snow_block
fill 154 84 278 154 87 278 minecraft:packed_ice
setblock 155 84 276 minecraft:snow_block
fill 155 84 277 155 87 277 minecraft:packed_ice
fill 156 84 276 156 87 276 minecraft:packed_ice
setblock 156 84 279 minecraft:packed_ice
fill 156 84 316 156 87 316 minecraft:packed_ice
setblock 157 84 278 minecraft:packed_ice
setblock 157 84 279 minecraft:snow_block
setblock 158 84 278 minecraft:snow_block
fill 158 84 279 158 87 279 minecraft:packed_ice
setblock 159 84 277 minecraft:snow_block
fill 159 84 278 159 87 278 minecraft:packed_ice
setblock 160 84 276 minecraft:snow_block
fill 160 84 277 160 87 277 minecraft:packed_ice
setblock 160 84 280 minecraft:packed_ice
setblock 160 84 286 minecraft:light[level=15]
setblock 160 84 294 minecraft:light[level=15]
setblock 160 84 302 minecraft:light[level=15]
setblock 160 84 310 minecraft:light[level=15]
setblock 160 84 316 minecraft:snow_block
fill 160 84 317 160 92 317 minecraft:packed_ice
fill 161 84 276 161 87 276 minecraft:packed_ice
setblock 161 84 279 minecraft:packed_ice
setblock 161 84 280 minecraft:snow_block
setblock 161 84 315 minecraft:snow_block
fill 161 84 316 161 87 316 minecraft:packed_ice
setblock 162 84 279 minecraft:snow_block
fill 162 84 315 165 84 315 minecraft:packed_ice
setblock 163 84 278 minecraft:snow_block
fill 163 84 279 163 87 279 minecraft:packed_ice
setblock 164 84 277 minecraft:snow_block
fill 164 84 278 164 87 278 minecraft:packed_ice
setblock 165 84 276 minecraft:snow_block
fill 165 84 277 165 87 277 minecraft:packed_ice
setblock 165 84 316 minecraft:snow_block
fill 166 84 276 166 87 276 minecraft:packed_ice
setblock 166 84 315 minecraft:snow_block
fill 166 84 316 166 87 316 minecraft:packed_ice
fill 167 84 315 167 85 315 minecraft:packed_ice
setblock 168 84 278 minecraft:light[level=15]
setblock 168 84 286 minecraft:light[level=15]
setblock 168 84 294 minecraft:light[level=15]
setblock 168 84 302 minecraft:light[level=15]
setblock 168 84 310 minecraft:light[level=15]
setblock 169 84 277 minecraft:snow_block
setblock 170 84 276 minecraft:snow_block
setblock 170 84 277 minecraft:packed_ice
setblock 170 84 316 minecraft:snow_block
fill 171 84 276 171 87 276 minecraft:packed_ice
fill 171 84 316 171 87 316 minecraft:packed_ice
fill 173 84 293 179 102 297 minecraft:snow_block
fill 174 84 292 178 102 292 minecraft:snow_block
fill 174 84 298 178 102 298 minecraft:snow_block
setblock 175 84 276 minecraft:snow_block
setblock 175 84 316 minecraft:snow_block
fill 176 84 276 176 86 277 minecraft:packed_ice
setblock 176 84 278 minecraft:light[level=15]
setblock 176 84 286 minecraft:light[level=15]
setblock 176 84 302 minecraft:light[level=15]
setblock 176 84 310 minecraft:light[level=15]
fill 176 84 316 176 87 316 minecraft:packed_ice
fill 177 84 303 178 85 305 minecraft:snow_block
fill 177 84 315 177 87 315 minecraft:packed_ice
setblock 179 84 277 minecraft:snow_block
fill 179 84 288 179 85 288 minecraft:snow_block
fill 179 84 298 179 84 301 minecraft:packed_ice
setblock 179 84 302 minecraft:snow_block
fill 179 84 303 179 85 305 minecraft:packed_ice
fill 180 84 275 180 110 275 minecraft:packed_ice
setblock 180 84 276 minecraft:snow_block
fill 180 84 277 180 87 277 minecraft:packed_ice
setblock 180 84 295 minecraft:packed_ice
setblock 180 84 296 minecraft:snow_block
fill 180 84 297 180 84 300 minecraft:packed_ice
setblock 180 84 301 minecraft:snow_block
fill 180 84 302 180 87 302 minecraft:packed_ice
setblock 180 84 306 minecraft:snow_block
fill 180 84 307 180 85 309 minecraft:packed_ice
setblock 180 84 316 minecraft:snow_block
fill 181 84 276 181 87 276 minecraft:packed_ice
setblock 181 84 280 minecraft:snow_block
fill 181 84 281 181 87 281 minecraft:packed_ice
setblock 181 84 284 minecraft:packed_ice
setblock 181 84 285 minecraft:snow_block
setblock 181 84 295 minecraft:snow_block
fill 181 84 296 181 87 296 minecraft:packed_ice
setblock 181 84 300 minecraft:snow_block
fill 181 84 301 181 87 301 minecraft:packed_ice
setblock 181 84 305 minecraft:snow_block
fill 181 84 306 181 87 306 minecraft:packed_ice
setblock 181 84 309 minecraft:packed_ice
setblock 181 84 310 minecraft:snow_block
fill 181 84 311 181 87 311 minecraft:packed_ice
setblock 181 84 315 minecraft:snow_block
fill 181 84 316 181 87 316 minecraft:packed_ice
setblock 182 84 279 minecraft:snow_block
fill 182 84 280 182 87 280 minecraft:packed_ice
setblock 182 84 284 minecraft:snow_block
fill 182 84 285 182 87 285 minecraft:packed_ice
setblock 182 84 289 minecraft:snow_block
fill 182 84 290 182 87 290 minecraft:packed_ice
setblock 182 84 294 minecraft:snow_block
fill 182 84 295 182 87 295 minecraft:packed_ice
setblock 182 84 299 minecraft:snow_block
fill 182 84 300 182 87 300 minecraft:packed_ice
setblock 182 84 304 minecraft:snow_block
fill 182 84 305 182 87 305 minecraft:packed_ice
setblock 182 84 309 minecraft:snow_block
fill 182 84 310 182 87 310 minecraft:packed_ice
setblock 182 84 314 minecraft:snow_block
fill 182 84 315 182 87 315 minecraft:packed_ice
fill 183 84 297 183 111 298 minecraft:packed_ice
setblock 183 84 299 minecraft:light_blue_concrete
fill 141 85 281 141 92 281 minecraft:packed_ice
fill 141 85 295 141 91 297 minecraft:packed_ice
setblock 141 85 298 minecraft:light_blue_concrete
fill 141 85 299 141 102 300 minecraft:packed_ice
setblock 142 85 278 minecraft:snow_block
fill 142 85 279 142 88 279 minecraft:packed_ice
setblock 142 85 283 minecraft:snow_block
fill 142 85 284 142 88 284 minecraft:packed_ice
setblock 142 85 287 minecraft:packed_ice
setblock 142 85 288 minecraft:snow_block
fill 142 85 289 142 88 289 minecraft:packed_ice
setblock 142 85 293 minecraft:snow_block
fill 142 85 294 142 88 294 minecraft:packed_ice
setblock 142 85 298 minecraft:snow_block
fill 142 85 299 142 88 299 minecraft:packed_ice
setblock 142 85 303 minecraft:snow_block
fill 142 85 304 142 88 304 minecraft:packed_ice
setblock 142 85 308 minecraft:snow_block
fill 142 85 309 142 88 309 minecraft:packed_ice
setblock 142 85 313 minecraft:snow_block
fill 142 85 314 142 86 314 minecraft:packed_ice
setblock 143 85 277 minecraft:snow_block
fill 143 85 278 143 88 278 minecraft:packed_ice
setblock 143 85 281 minecraft:packed_ice
setblock 143 85 282 minecraft:snow_block
fill 143 85 283 143 88 283 minecraft:packed_ice
setblock 143 85 287 minecraft:snow_block
fill 143 85 288 143 88 288 minecraft:packed_ice
setblock 143 85 292 minecraft:snow_block
fill 143 85 293 143 88 293 minecraft:packed_ice
setblock 143 85 297 minecraft:snow_block
fill 143 85 298 143 88 298 minecraft:packed_ice
setblock 143 85 302 minecraft:snow_block
fill 143 85 303 143 88 303 minecraft:packed_ice
setblock 143 85 307 minecraft:snow_block
fill 143 85 308 143 87 308 minecraft:packed_ice
setblock 144 85 276 minecraft:snow_block
fill 144 85 277 144 88 277 minecraft:packed_ice
setblock 144 85 281 minecraft:snow_block
fill 144 85 282 144 88 282 minecraft:packed_ice
setblock 144 85 286 minecraft:snow_block
fill 144 85 287 144 88 287 minecraft:packed_ice
setblock 144 85 296 minecraft:snow_block
fill 144 85 297 144 86 297 minecraft:packed_ice
setblock 144 85 300 minecraft:packed_ice
setblock 144 85 301 minecraft:snow_block
fill 144 85 302 144 87 302 minecraft:packed_ice
setblock 144 85 316 minecraft:snow_block
fill 145 85 276 148 85 276 minecraft:packed_ice
setblock 148 85 277 minecraft:snow_block
setblock 149 85 276 minecraft:snow_block
fill 149 85 277 152 85 277 minecraft:packed_ice
fill 150 85 276 153 85 276 minecraft:packed_ice
setblock 153 85 277 minecraft:snow_block
fill 153 85 278 153 88 278 minecraft:packed_ice
setblock 154 85 276 minecraft:snow_block
fill 154 85 277 154 88 277 minecraft:packed_ice
fill 155 85 276 155 88 276 minecraft:packed_ice
fill 155 85 316 155 88 316 minecraft:packed_ice
setblock 156 85 279 minecraft:snow_block
setblock 157 85 278 minecraft:snow_block
fill 157 85 279 157 88 279 minecraft:packed_ice
setblock 158 85 277 minecraft:snow_block
fill 158 85 278 158 88 278 minecraft:packed_ice
fill 158 85 315 158 86 315 minecraft:packed_ice
setblock 159 85 276 minecraft:snow_block
fill 159 85 277 159 88 277 minecraft:packed_ice
setblock 159 85 280 minecraft:packed_ice
setblock 159 85 316 minecraft:snow_block
fill 160 85 276 160 88 276 minecraft:packed_ice
setblock 160 85 280 minecraft:snow_block
setblock 160 85 315 minecraft:snow_block
fill 160 85 316 160 88 316 minecraft:packed_ice
setblock 161 85 279 minecraft:snow_block
fill 161 85 280 162 85 280 minecraft:packed_ice
fill 161 85 315 164 85 315 minecraft:packed_ice
setblock 162 85 278 minecraft:snow_block
fill 162 85 279 162 88 279 minecraft:packed_ice
setblock 162 85 317 minecraft:white_concrete
setblock 163 85 277 minecraft:snow_block
fill 163 85 278 163 88 278 minecraft:packed_ice
fill 163 85 317 165 114 317 minecraft:packed_ice
setblock 164 85 276 minecraft:snow_block
fill 164 85 277 164 88 277 minecraft:packed_ice
setblock 164 85 316 minecraft:snow_block
fill 165 85 276 165 88 276 minecraft:packed_ice
setblock 165 85 315 minecraft:snow_block
fill 165 85 316 165 88 316 minecraft:packed_ice
fill 166 85 308 167 86 309 minecraft:white_concrete
fill 166 85 315 166 86 315 minecraft:packed_ice
setblock 167 85 278 minecraft:snow_block
setblock 168 85 277 minecraft:snow_block
setblock 169 85 276 minecraft:snow_block
setblock 169 85 277 minecraft:packed_ice
setblock 169 85 316 minecraft:snow_block
fill 170 85 276 170 87 276 minecraft:packed_ice
fill 170 85 316 170 87 316 minecraft:packed_ice
fill 171 85 294 172 101 296 minecraft:snow_block
fill 172 85 292 172 101 293 minecraft:snow_block
fill 172 85 297 172 101 298 minecraft:snow_block
fill 173 85 291 173 101 292 minecraft:snow_block
fill 173 85 298 173 101 299 minecraft:snow_block
setblock 174 85 276 minecraft:snow_block
fill 174 85 291 179 101 291 minecraft:snow_block
fill 174 85 299 178 101 299 minecraft:snow_block
setblock 174 85 316 minecraft:snow_block
fill 175 85 276 175 88 276 minecraft:packed_ice
fill 175 85 290 177 101 290 minecraft:snow_block
fill 175 85 300 177 101 300 minecraft:snow_block
fill 175 85 316 175 88 316 minecraft:packed_ice
setblock 176 85 315 minecraft:packed_ice
setblock 178 85 276 minecraft:packed_ice
setblock 178 85 277 minecraft:snow_block
setblock 179 85 276 minecraft:snow_block
fill 179 85 277 179 88 277 minecraft:packed_ice
fill 179 85 292 180 96 292 minecraft:snow_block
fill 179 85 298 179 85 300 minecraft:packed_ice
setblock 179 85 301 minecraft:snow_block
fill 179 85 302 179 88 302 minecraft:packed_ice
setblock 179 85 316 minecraft:snow_block
fill 180 85 276 180 88 276 minecraft:packed_ice
fill 180 85 278 180 85 279 minecraft:packed_ice
setblock 180 85 280 minecraft:snow_block
fill 180 85 281 180 88 281 minecraft:packed_ice
fill 180 85 293 180 85 295 minecraft:snow_block
fill 180 85 296 180 85 299 minecraft:packed_ice
setblock 180 85 300 minecraft:snow_block
fill 180 85 301 180 88 301 minecraft:packed_ice
setblock 180 85 304 minecraft:packed_ice
setblock 180 85 305 minecraft:snow_block
fill 180 85 306 180 88 306 minecraft:packed_ice
setblock 180 85 310 minecraft:snow_block
setblock 180 85 315 minecraft:snow_block
fill 180 85 316 180 88 316 minecraft:packed_ice
setblock 181 85 279 minecraft:snow_block
fill 181 85 280 181 88 280 minecraft:packed_ice
setblock 181 85 284 minecraft:snow_block
fill 181 85 285 181 86 287 minecraft:packed_ice
fill 181 85 291 181 87 291 minecraft:packed_ice
setblock 181 85 294 minecraft:snow_block
fill 181 85 295 181 88 295 minecraft:packed_ice
setblock 181 85 299 minecraft:snow_block
fill 181 85 300 181 88 300 minecraft:packed_ice
setblock 181 85 304 minecraft:snow_block
fill 181 85 305 181 88 305 minecraft:packed_ice
setblock 181 85 309 minecraft:snow_block
fill 181 85 310 181 88 310 minecraft:packed_ice
setblock 181 85 314 minecraft:snow_block
fill 181 85 315 181 86 315 minecraft:packed_ice
setblock 182 85 278 minecraft:snow_block
fill 182 85 279 182 88 279 minecraft:packed_ice
setblock 182 85 283 minecraft:snow_block
fill 182 85 284 182 88 284 minecraft:packed_ice
fill 182 85 286 182 85 287 minecraft:packed_ice
setblock 182 85 288 minecraft:snow_block
fill 182 85 289 182 88 289 minecraft:packed_ice
setblock 182 85 293 minecraft:snow_block
fill 182 85 294 182 88 294 minecraft:packed_ice
setblock 182 85 298 minecraft:snow_block
fill 182 85 299 183 88 299 minecraft:packed_ice
setblock 182 85 303 minecraft:snow_block
fill 182 85 304 182 88 304 minecraft:packed_ice
setblock 182 85 308 minecraft:snow_block
fill 182 85 309 182 88 309 minecraft:packed_ice
setblock 182 85 313 minecraft:snow_block
fill 182 85 314 182 88 314 minecraft:packed_ice
setblock 183 85 286 minecraft:white_concrete
fill 141 86 298 142 89 298 minecraft:packed_ice
fill 141 86 308 141 111 309 minecraft:packed_ice
setblock 141 86 310 minecraft:light_blue_concrete
fill 141 86 311 141 94 312 minecraft:packed_ice
setblock 142 86 277 minecraft:snow_block
fill 142 86 278 142 89 278 minecraft:packed_ice
setblock 142 86 282 minecraft:snow_block
fill 142 86 283 142 89 283 minecraft:packed_ice
setblock 142 86 287 minecraft:snow_block
fill 142 86 288 142 89 288 minecraft:packed_ice
setblock 142 86 292 minecraft:snow_block
fill 142 86 293 142 89 293 minecraft:packed_ice
setblock 142 86 297 minecraft:snow_block
setblock 142 86 302 minecraft:snow_block
fill 142 86 303 142 89 303 minecraft:packed_ice
setblock 142 86 307 minecraft:snow_block
fill 142 86 308 142 89 308 minecraft:packed_ice
setblock 142 86 312 minecraft:snow_block
setblock 142 86 313 minecraft:packed_ice
setblock 143 86 276 minecraft:snow_block
fill 143 86 277 143 88 277 minecraft:packed_ice
setblock 143 86 281 minecraft:snow_block
fill 143 86 282 143 89 282 minecraft:packed_ice
setblock 143 86 286 minecraft:snow_block
fill 143 86 287 143 89 287 minecraft:packed_ice
setblock 143 86 291 minecraft:snow_block
fill 143 86 292 143 88 292 minecraft:packed_ice
setblock 143 86 296 minecraft:snow_block
fill 143 86 297 143 88 297 minecraft:packed_ice
setblock 143 86 301 minecraft:snow_block
fill 143 86 302 143 89 302 minecraft:packed_ice
setblock 143 86 306 minecraft:snow_block
fill 143 86 307 143 89 307 minecraft:packed_ice
setblock 143 86 316 minecraft:snow_block
fill 144 86 276 147 86 276 minecraft:packed_ice
setblock 144 86 280 minecraft:snow_block
fill 144 86 281 144 89 281 minecraft:packed_ice
setblock 144 86 285 minecraft:snow_block
fill 144 86 286 144 89 286 minecraft:packed_ice
setblock 144 86 296 minecraft:packed_ice
setblock 144 86 300 minecraft:snow_block
fill 144 86 301 144 87 301 minecraft:packed_ice
setblock 144 86 305 minecraft:snow_block
setblock 145 86 278 minecraft:packed_ice
setblock 147 86 277 minecraft:snow_block
setblock 148 86 276 minecraft:snow_block
fill 148 86 277 151 86 277 minecraft:packed_ice
fill 149 86 276 152 86 276 minecraft:packed_ice
setblock 152 86 277 minecraft:snow_block
setblock 153 86 276 minecraft:snow_block
fill 153 86 277 153 89 277 minecraft:packed_ice
fill 154 86 276 154 89 276 minecraft:packed_ice
setblock 155 86 279 minecraft:snow_block
setblock 156 86 278 minecraft:snow_block
fill 156 86 279 156 89 279 minecraft:packed_ice
setblock 157 86 277 minecraft:snow_block
fill 157 86 278 157 89 278 minecraft:packed_ice
setblock 158 86 276 minecraft:snow_block
fill 158 86 277 158 89 277 minecraft:packed_ice
setblock 158 86 280 minecraft:packed_ice
setblock 158 86 316 minecraft:snow_block
fill 159 86 276 159 89 276 minecraft:packed_ice
setblock 159 86 280 minecraft:snow_block
setblock 159 86 315 minecraft:snow_block
fill 159 86 316 159 89 316 minecraft:packed_ice
setblock 160 86 279 minecraft:snow_block
fill 160 86 280 161 86 280 minecraft:packed_ice
fill 160 86 315 163 86 315 minecraft:packed_ice
setblock 161 86 278 minecraft:snow_block
fill 161 86 279 161 88 279 minecraft:packed_ice
setblock 162 86 277 minecraft:snow_block
fill 162 86 278 162 89 278 minecraft:packed_ice
fill 162 86 317 162 114 317 minecraft:packed_ice
setblock 163 86 276 minecraft:snow_block
fill 163 86 277 163 89 277 minecraft:packed_ice
setblock 163 86 316 minecraft:snow_block
fill 164 86 276 164 89 276 minecraft:packed_ice
setblock 164 86 315 minecraft:snow_block
fill 164 86 316 164 89 316 minecraft:packed_ice
fill 165 86 315 165 87 315 minecraft:packed_ice
setblock 166 86 278 minecraft:snow_block
setblock 167 86 277 minecraft:snow_block
setblock 168 86 276 minecraft:snow_block
setblock 168 86 277 minecraft:packed_ice
setblock 168 86 316 minecraft:snow_block
fill 169 86 276 169 87 276 minecraft:packed_ice
fill 169 86 316 169 87 316 minecraft:packed_ice
fill 170 86 293 170 100 295 minecraft:snow_block
fill 171 86 292 171 100 293 minecraft:snow_block
fill 171 86 297 171 100 298 minecraft:snow_block
fill 172 86 291 172 100 291 minecraft:snow_block
fill 172 86 299 172 100 299 minecraft:snow_block
setblock 173 86 276 minecraft:snow_block
fill 173 86 290 174 100 290 minecraft:snow_block
fill 173 86 300 174 100 300 minecraft:snow_block
setblock 173 86 316 minecraft:snow_block
fill 174 86 276 174 88 276 minecraft:packed_ice
fill 174 86 289 178 100 289 minecraft:snow_block
fill 174 86 301 178 100 301 minecraft:snow_block
fill 174 86 316 174 89 316 minecraft:packed_ice
setblock 177 86 276 minecraft:packed_ice
setblock 177 86 277 minecraft:snow_block
fill 177 86 303 177 131 305 minecraft:snow_block
setblock 178 86 276 minecraft:snow_block
fill 178 86 277 178 88 277 minecraft:packed_ice
fill 178 86 290 179 100 290 minecraft:snow_block
fill 178 86 300 179 86 300 minecraft:snow_block
fill 178 86 303 179 87 303 minecraft:packed_ice
fill 178 86 304 178 86 306 minecraft:snow_block
setblock 178 86 316 minecraft:snow_block
fill 179 86 276 179 89 276 minecraft:packed_ice
fill 179 86 298 179 86 299 minecraft:packed_ice
fill 179 86 301 179 89 301 minecraft:packed_ice
setblock 179 86 304 minecraft:packed_ice
setblock 179 86 305 minecraft:snow_block
fill 179 86 306 179 88 307 minecraft:packed_ice
setblock 179 86 315 minecraft:snow_block
fill 179 86 316 179 89 316 minecraft:packed_ice
setblock 180 86 279 minecraft:snow_block
fill 180 86 280 180 87 280 minecraft:packed_ice
fill 180 86 282 180 86 283 minecraft:packed_ice
fill 180 86 291 180 96 291 minecraft:snow_block
fill 180 86 293 180 97 294 minecraft:snow_block
fill 180 86 295 180 86 298 minecraft:packed_ice
setblock 180 86 299 minecraft:snow_block
fill 180 86 300 180 89 300 minecraft:packed_ice
setblock 180 86 304 minecraft:snow_block
fill 180 86 305 180 89 305 minecraft:packed_ice
fill 180 86 307 180 86 308 minecraft:packed_ice
setblock 180 86 309 minecraft:snow_block
fill 180 86 310 180 89 310 minecraft:packed_ice
fill 180 86 315 180 87 315 minecraft:packed_ice
setblock 181 86 278 minecraft:snow_block
fill 181 86 279 181 89 279 minecraft:packed_ice
setblock 181 86 282 minecraft:packed_ice
setblock 181 86 283 minecraft:snow_block
fill 181 86 284 181 89 284 minecraft:packed_ice
setblock 181 86 288 minecraft:snow_block
fill 181 86 289 181 88 290 minecraft:packed_ice
setblock 181 86 293 minecraft:snow_block
fill 181 86 294 181 89 294 minecraft:packed_ice
setblock 181 86 298 minecraft:snow_block
fill 181 86 299 181 89 299 minecraft:packed_ice
setblock 181 86 303 minecraft:snow_block
fill 181 86 304 181 89 304 minecraft:packed_ice
setblock 181 86 308 minecraft:snow_block
fill 181 86 309 181 89 309 minecraft:packed_ice
setblock 181 86 313 minecraft:snow_block
fill 181 86 314 181 87 314 minecraft:packed_ice
setblock 182 86 277 minecraft:snow_block
fill 182 86 278 182 89 278 minecraft:packed_ice
setblock 182 86 282 minecraft:snow_block
fill 182 86 283 182 89 283 minecraft:packed_ice
fill 182 86 286 183 86 286 minecraft:packed_ice
setblock 182 86 287 minecraft:snow_block
fill 182 86 288 182 89 288 minecraft:packed_ice
setblock 182 86 292 minecraft:snow_block
fill 182 86 293 182 89 293 minecraft:packed_ice
setblock 182 86 297 minecraft:snow_block
fill 182 86 298 182 89 298 minecraft:packed_ice
setblock 182 86 302 minecraft:snow_block
fill 182 86 303 182 89 303 minecraft:packed_ice
setblock 182 86 307 minecraft:snow_block
fill 182 86 308 182 89 308 minecraft:packed_ice
setblock 182 86 312 minecraft:snow_block
fill 182 86 313 182 89 313 minecraft:packed_ice
fill 141 87 310 141 112 310 minecraft:packed_ice
setblock 142 87 276 minecraft:snow_block
fill 142 87 277 142 90 277 minecraft:packed_ice
setblock 142 87 281 minecraft:snow_block
fill 142 87 282 142 90 282 minecraft:packed_ice
setblock 142 87 286 minecraft:snow_block
fill 142 87 287 142 90 287 minecraft:packed_ice
setblock 142 87 291 minecraft:snow_block
fill 142 87 292 142 90 292 minecraft:packed_ice
setblock 142 87 296 minecraft:snow_block
fill 142 87 297 142 90 297 minecraft:packed_ice
setblock 142 87 301 minecraft:snow_block
fill 142 87 302 142 90 302 minecraft:packed_ice
setblock 142 87 306 minecraft:snow_block
fill 142 87 307 142 90 307 minecraft:packed_ice
setblock 142 87 311 minecraft:snow_block
setblock 142 87 312 minecraft:packed_ice
fill 143 87 276 146 87 276 minecraft:packed_ice
setblock 143 87 280 minecraft:snow_block
fill 143 87 281 143 90 281 minecraft:packed_ice
setblock 143 87 284 minecraft:packed_ice
setblock 143 87 285 minecraft:snow_block
fill 143 87 286 143 90 286 minecraft:packed_ice
setblock 143 87 290 minecraft:snow_block
fill 143 87 291 143 89 291 minecraft:packed_ice
setblock 143 87 295 minecraft:snow_block
fill 143 87 296 143 88 296 minecraft:packed_ice
setblock 143 87 300 minecraft:snow_block
fill 143 87 301 143 89 301 minecraft:packed_ice
setblock 143 87 305 minecraft:snow_block
fill 143 87 306 143 89 306 minecraft:packed_ice
setblock 144 87 279 minecraft:snow_block
fill 144 87 280 144 88 280 minecraft:packed_ice
setblock 144 87 284 minecraft:snow_block
fill 144 87 285 144 90 285 minecraft:packed_ice
setblock 144 87 299 minecraft:snow_block
setblock 144 87 300 minecraft:packed_ice
setblock 144 87 304 minecraft:snow_block
setblock 146 87 277 minecraft:snow_block
setblock 147 87 276 minecraft:snow_block
fill 148 87 276 151 87 276 minecraft:packed_ice
setblock 151 87 277 minecraft:snow_block
setblock 152 87 276 minecraft:snow_block
fill 152 87 277 152 89 277 minecraft:packed_ice
fill 153 87 276 153 90 276 minecraft:packed_ice
setblock 155 87 278 minecraft:snow_block
fill 155 87 279 155 88 279 minecraft:packed_ice
setblock 156 87 277 minecraft:snow_block
fill 156 87 278 156 90 278 minecraft:packed_ice
setblock 156 87 317 minecraft:white_concrete
setblock 157 87 276 minecraft:snow_block
fill 157 87 277 157 90 277 minecraft:packed_ice
setblock 157 87 316 minecraft:snow_block
fill 158 87 276 158 90 276 minecraft:packed_ice
setblock 158 87 280 minecraft:snow_block
setblock 158 87 315 minecraft:snow_block
fill 158 87 316 158 90 316 minecraft:packed_ice
setblock 159 87 279 minecraft:snow_block
fill 159 87 280 160 87 280 minecraft:packed_ice
fill 159 87 315 162 87 315 minecraft:packed_ice
setblock 160 87 278 minecraft:snow_block
fill 160 87 279 160 89 279 minecraft:packed_ice
setblock 161 87 277 minecraft:snow_block
fill 161 87 278 161 89 278 minecraft:packed_ice
setblock 162 87 276 minecraft:snow_block
fill 162 87 277 162 90 277 minecraft:packed_ice
setblock 162 87 316 minecraft:snow_block
fill 163 87 276 163 90 276 minecraft:packed_ice
setblock 163 87 315 minecraft:snow_block
fill 163 87 316 163 90 316 minecraft:packed_ice
setblock 164 87 315 minecraft:packed_ice
setblock 165 87 278 minecraft:snow_block
setblock 166 87 277 minecraft:snow_block
setblock 167 87 276 minecraft:snow_block
setblock 167 87 277 minecraft:packed_ice
setblock 167 87 316 minecraft:snow_block
fill 168 87 276 168 88 276 minecraft:packed_ice
fill 168 87 316 168 88 316 minecraft:packed_ice
fill 169 87 294 169 100 295 minecraft:snow_block
fill 170 87 292 170 99 292 minecraft:snow_block
fill 171 87 290 171 99 291 minecraft:snow_block
fill 171 87 299 171 99 300 minecraft:snow_block
setblock 172 87 276 minecraft:snow_block
fill 172 87 290 172 99 290 minecraft:snow_block
fill 172 87 300 172 99 300 minecraft:snow_block
setblock 172 87 316 minecraft:snow_block
setblock 173 87 276 minecraft:packed_ice
fill 173 87 289 173 99 289 minecraft:snow_block
fill 173 87 301 173 99 301 minecraft:snow_block
fill 173 87 316 173 88 316 minecraft:packed_ice
fill 175 87 288 177 99 288 minecraft:snow_block
fill 175 87 302 177 99 302 minecraft:snow_block
setblock 176 87 276 minecraft:packed_ice
setblock 177 87 276 minecraft:snow_block
setblock 177 87 277 minecraft:packed_ice
setblock 177 87 316 minecraft:snow_block
fill 178 87 276 178 89 276 minecraft:packed_ice
fill 178 87 300 178 100 300 minecraft:snow_block
setblock 178 87 302 minecraft:packed_ice
setblock 178 87 304 minecraft:packed_ice
fill 178 87 305 178 131 306 minecraft:snow_block
setblock 178 87 315 minecraft:snow_block
fill 178 87 316 178 90 316 minecraft:packed_ice
fill 179 87 289 179 99 289 minecraft:snow_block
setblock 179 87 298 minecraft:packed_ice
setblock 179 87 299 minecraft:snow_block
fill 179 87 300 179 89 300 minecraft:packed_ice
setblock 179 87 304 minecraft:snow_block
fill 179 87 305 179 90 305 minecraft:packed_ice
setblock 179 87 308 minecraft:packed_ice
setblock 179 87 315 minecraft:packed_ice
setblock 180 87 282 minecraft:packed_ice
setblock 180 87 283 minecraft:snow_block
fill 180 87 284 180 89 284 minecraft:packed_ice
fill 180 87 290 180 95 290 minecraft:snow_block
fill 180 87 295 180 87 297 minecraft:packed_ice
setblock 180 87 298 minecraft:snow_block
fill 180 87 299 180 90 299 minecraft:packed_ice
setblock 180 87 303 minecraft:snow_block
fill 180 87 304 180 90 304 minecraft:packed_ice
setblock 180 87 307 minecraft:packed_ice
setblock 180 87 308 minecraft:snow_block
fill 180 87 309 180 90 309 minecraft:packed_ice
setblock 181 87 277 minecraft:snow_block
fill 181 87 278 181 88 278 minecraft:packed_ice
setblock 181 87 282 minecraft:snow_block
fill 181 87 283 181 90 283 minecraft:packed_ice
fill 181 87 285 181 87 286 minecraft:packed_ice
setblock 181 87 287 minecraft:snow_block
fill 181 87 288 181 90 288 minecraft:packed_ice
setblock 181 87 292 minecraft:snow_block
fill 181 87 293 181 89 293 minecraft:packed_ice
setblock 181 87 297 minecraft:snow_block
fill 181 87 298 181 90 298 minecraft:packed_ice
setblock 181 87 302 minecraft:snow_block
fill 181 87 303 181 90 303 minecraft:packed_ice
setblock 181 87 307 minecraft:snow_block
fill 181 87 308 181 90 308 minecraft:packed_ice
setblock 181 87 312 minecraft:snow_block
setblock 181 87 313 minecraft:packed_ice
setblock 182 87 276 minecraft:snow_block
fill 182 87 277 182 89 277 minecraft:packed_ice
setblock 182 87 281 minecraft:snow_block
fill 182 87 282 182 90 282 minecraft:packed_ice
setblock 182 87 286 minecraft:snow_block
fill 182 87 287 182 90 287 minecraft:packed_ice
setblock 182 87 291 minecraft:snow_block
fill 182 87 292 182 90 292 minecraft:packed_ice
setblock 182 87 296 minecraft:snow_block
fill 182 87 297 182 90 297 minecraft:packed_ice
setblock 182 87 301 minecraft:snow_block
fill 182 87 302 182 90 302 minecraft:packed_ice
setblock 182 87 306 minecraft:snow_block
fill 182 87 307 182 90 307 minecraft:packed_ice
setblock 182 87 311 minecraft:snow_block
fill 182 87 312 182 90 312 minecraft:packed_ice
setblock 182 87 316 minecraft:snow_block
fill 183 87 286 183 91 286 minecraft:packed_ice
fill 142 88 276 145 88 276 minecraft:packed_ice
setblock 142 88 280 minecraft:snow_block
fill 142 88 281 142 91 281 minecraft:packed_ice
setblock 142 88 285 minecraft:snow_block
fill 142 88 286 142 91 286 minecraft:packed_ice
setblock 142 88 290 minecraft:snow_block
fill 142 88 291 142 91 291 minecraft:packed_ice
setblock 142 88 295 minecraft:snow_block
fill 142 88 296 142 91 296 minecraft:packed_ice
setblock 142 88 300 minecraft:snow_block
fill 142 88 301 142 91 301 minecraft:packed_ice
setblock 142 88 305 minecraft:snow_block
fill 142 88 306 142 91 306 minecraft:packed_ice
setblock 142 88 310 minecraft:snow_block
setblock 142 88 311 minecraft:packed_ice
setblock 143 88 279 minecraft:snow_block
fill 143 88 280 143 90 280 minecraft:packed_ice
setblock 143 88 284 minecraft:snow_block
fill 143 88 285 143 91 285 minecraft:packed_ice
setblock 143 88 289 minecraft:snow_block
fill 143 88 290 143 90 290 minecraft:packed_ice
setblock 143 88 294 minecraft:snow_block
setblock 143 88 295 minecraft:packed_ice
setblock 143 88 299 minecraft:snow_block
fill 143 88 300 143 89 300 minecraft:packed_ice
setblock 143 88 304 minecraft:snow_block
fill 143 88 305 143 90 305 minecraft:packed_ice
setblock 144 88 278 minecraft:light[level=12]
setblock 144 88 283 minecraft:snow_block
fill 144 88 284 144 90 284 minecraft:packed_ice
setblock 144 88 292 minecraft:light[level=12]
setblock 144 88 299 minecraft:light[level=12]
setblock 144 88 306 minecraft:light[level=12]
setblock 144 88 313 minecraft:light[level=12]
setblock 146 88 276 minecraft:snow_block
fill 147 88 276 150 88 276 minecraft:packed_ice
setblock 151 88 276 minecraft:snow_block
setblock 151 88 278 minecraft:light[level=12]
setblock 151 88 285 minecraft:light[level=12]
setblock 151 88 292 minecraft:light[level=12]
setblock 151 88 299 minecraft:light[level=12]
setblock 151 88 306 minecraft:light[level=12]
setblock 151 88 313 minecraft:light[level=12]
fill 152 88 276 152 91 276 minecraft:packed_ice
setblock 153 88 275 minecraft:white_concrete
setblock 154 88 278 minecraft:snow_block
setblock 155 88 277 minecraft:snow_block
fill 155 88 278 155 90 278 minecraft:packed_ice
setblock 156 88 276 minecraft:snow_block
fill 156 88 277 156 91 277 minecraft:packed_ice
setblock 156 88 316 minecraft:snow_block
fill 156 88 317 156 97 317 minecraft:packed_ice
fill 157 88 276 157 91 276 minecraft:packed_ice
fill 157 88 316 157 91 316 minecraft:packed_ice
setblock 158 88 279 minecraft:snow_block
setblock 158 88 285 minecraft:light[level=12]
setblock 158 88 292 minecraft:light[level=12]
setblock 158 88 299 minecraft:light[level=12]
setblock 158 88 306 minecraft:light[level=12]
setblock 158 88 313 minecraft:light[level=12]
fill 158 88 315 161 88 315 minecraft:packed_ice
setblock 159 88 278 minecraft:snow_block
fill 159 88 279 159 89 279 minecraft:packed_ice
setblock 160 88 277 minecraft:snow_block
fill 160 88 278 160 90 278 minecraft:packed_ice
setblock 161 88 276 minecraft:snow_block
fill 161 88 277 161 91 277 minecraft:packed_ice
setblock 161 88 316 minecraft:snow_block
fill 162 88 276 162 91 276 minecraft:packed_ice
setblock 162 88 315 minecraft:snow_block
fill 162 88 316 162 91 316 minecraft:packed_ice
setblock 163 88 315 minecraft:packed_ice
setblock 164 88 278 minecraft:snow_block
setblock 165 88 277 minecraft:snow_block
setblock 165 88 278 minecraft:light[level=12]
setblock 165 88 285 minecraft:light[level=12]
setblock 165 88 292 minecraft:light[level=12]
setblock 165 88 299 minecraft:light[level=12]
setblock 165 88 306 minecraft:light[level=12]
setblock 165 88 313 minecraft:light[level=12]
setblock 166 88 276 minecraft:snow_block
setblock 166 88 316 minecraft:snow_block
setblock 167 88 276 minecraft:packed_ice
setblock 167 88 316 minecraft:packed_ice
fill 169 88 292 169 100 293 minecraft:snow_block
fill 170 88 291 170 98 291 minecraft:snow_block
setblock 171 88 275 minecraft:white_concrete
fill 172 88 275 174 103 275 minecraft:packed_ice
setblock 172 88 278 minecraft:light[level=12]
setblock 172 88 285 minecraft:light[level=12]
fill 172 88 289 172 98 289 minecraft:snow_block
fill 172 88 301 172 98 301 minecraft:snow_block
setblock 172 88 306 minecraft:light[level=12]
setblock 172 88 313 minecraft:light[level=12]
fill 173 88 288 174 98 288 minecraft:snow_block
fill 173 88 302 174 98 302 minecraft:snow_block
setblock 176 88 276 minecraft:snow_block
setblock 176 88 316 minecraft:snow_block
fill 177 88 276 177 89 276 minecraft:packed_ice
fill 177 88 316 177 91 316 minecraft:packed_ice
fill 178 88 288 179 98 288 minecraft:snow_block
fill 178 88 302 178 98 302 minecraft:snow_block
setblock 178 88 303 minecraft:packed_ice
fill 178 88 304 178 131 304 minecraft:snow_block
setblock 179 88 278 minecraft:light[level=12]
setblock 179 88 285 minecraft:light[level=12]
fill 179 88 298 179 101 298 minecraft:snow_block
setblock 179 88 299 minecraft:packed_ice
setblock 179 88 303 minecraft:snow_block
fill 179 88 304 179 91 304 minecraft:packed_ice
setblock 179 88 308 minecraft:snow_block
setblock 179 88 313 minecraft:light[level=12]
setblock 180 88 277 minecraft:snow_block
setblock 180 88 282 minecraft:snow_block
fill 180 88 283 180 89 283 minecraft:packed_ice
fill 180 88 285 181 88 285 minecraft:packed_ice
fill 180 88 289 180 96 289 minecraft:snow_block
fill 180 88 295 180 101 295 minecraft:snow_block
setblock 180 88 296 minecraft:packed_ice
setblock 180 88 297 minecraft:snow_block
fill 180 88 298 180 89 298 minecraft:packed_ice
setblock 180 88 302 minecraft:snow_block
fill 180 88 303 180 91 303 minecraft:packed_ice
setblock 180 88 307 minecraft:snow_block
fill 180 88 308 180 91 308 minecraft:packed_ice
setblock 181 88 276 minecraft:snow_block
setblock 181 88 281 minecraft:snow_block
fill 181 88 282 181 91 282 minecraft:packed_ice
setblock 181 88 286 minecraft:snow_block
fill 181 88 287 181 91 287 minecraft:packed_ice
setblock 181 88 291 minecraft:snow_block
fill 181 88 292 181 89 292 minecraft:packed_ice
setblock 181 88 296 minecraft:snow_block
fill 181 88 297 181 91 297 minecraft:packed_ice
setblock 181 88 301 minecraft:snow_block
fill 181 88 302 181 91 302 minecraft:packed_ice
setblock 181 88 306 minecraft:snow_block
fill 181 88 307 181 91 307 minecraft:packed_ice
setblock 181 88 311 minecraft:snow_block
setblock 181 88 312 minecraft:packed_ice
setblock 181 88 316 minecraft:snow_block
setblock 182 88 276 minecraft:packed_ice
setblock 182 88 280 minecraft:snow_block
fill 182 88 281 182 91 281 minecraft:packed_ice
setblock 182 88 285 minecraft:snow_block
fill 182 88 286 182 91 286 minecraft:packed_ice
setblock 182 88 290 minecraft:snow_block
fill 182 88 291 182 91 291 minecraft:packed_ice
setblock 182 88 295 minecraft:snow_block
fill 182 88 296 182 91 296 minecraft:packed_ice
setblock 182 88 300 minecraft:snow_block
fill 182 88 301 182 91 301 minecraft:packed_ice
setblock 182 88 305 minecraft:snow_block
fill 182 88 306 182 91 306 minecraft:packed_ice
setblock 182 88 310 minecraft:snow_block
fill 182 88 311 182 91 311 minecraft:packed_ice
setblock 182 88 315 minecraft:snow_block
setblock 182 88 316 minecraft:packed_ice
setblock 141 89 301 minecraft:light_blue_concrete
fill 142 89 276 144 89 276 minecraft:packed_ice
setblock 142 89 279 minecraft:snow_block
fill 142 89 280 142 92 280 minecraft:packed_ice
setblock 142 89 284 minecraft:snow_block
fill 142 89 285 142 92 285 minecraft:packed_ice
setblock 142 89 289 minecraft:snow_block
fill 142 89 290 142 92 290 minecraft:packed_ice
setblock 142 89 294 minecraft:snow_block
fill 142 89 295 142 91 295 minecraft:packed_ice
setblock 142 89 299 minecraft:snow_block
fill 142 89 300 142 91 300 minecraft:packed_ice
setblock 142 89 304 minecraft:snow_block
fill 142 89 305 142 92 305 minecraft:packed_ice
setblock 142 89 309 minecraft:snow_block
fill 142 89 310 142 90 310 minecraft:packed_ice
setblock 143 89 278 minecraft:snow_block
fill 143 89 279 143 90 279 minecraft:packed_ice
setblock 143 89 283 minecraft:snow_block
fill 143 89 284 143 92 284 minecraft:packed_ice
setblock 143 89 288 minecraft:snow_block
fill 143 89 289 143 92 289 minecraft:packed_ice
setblock 143 89 298 minecraft:snow_block
setblock 143 89 299 minecraft:packed_ice
setblock 143 89 303 minecraft:snow_block
fill 143 89 304 143 90 304 minecraft:packed_ice
setblock 144 89 282 minecraft:snow_block
fill 144 89 283 144 90 283 minecraft:packed_ice
fill 146 89 280 146 95 280 minecraft:packed_ice
fill 151 89 276 151 90 276 minecraft:packed_ice
fill 153 89 275 153 114 275 minecraft:packed_ice
setblock 154 89 277 minecraft:snow_block
setblock 154 89 278 minecraft:packed_ice
setblock 155 89 276 minecraft:snow_block
fill 155 89 277 155 92 277 minecraft:packed_ice
fill 155 89 309 155 89 315 minecraft:blue_ice
setblock 155 89 316 minecraft:snow_block
fill 156 89 276 156 92 276 minecraft:packed_ice
fill 156 89 316 156 92 316 minecraft:packed_ice
setblock 157 89 279 minecraft:snow_block
setblock 158 89 278 minecraft:snow_block
setblock 158 89 279 minecraft:packed_ice
fill 158 89 315 160 89 315 minecraft:packed_ice
setblock 159 89 277 minecraft:snow_block
fill 159 89 278 159 90 278 minecraft:packed_ice
setblock 160 89 276 minecraft:snow_block
fill 160 89 277 160 91 277 minecraft:packed_ice
setblock 160 89 316 minecraft:snow_block
fill 161 89 276 161 92 276 minecraft:packed_ice
setblock 161 89 315 minecraft:snow_block
fill 161 89 316 161 92 316 minecraft:packed_ice
setblock 162 89 315 minecraft:packed_ice
setblock 164 89 277 minecraft:snow_block
setblock 165 89 276 minecraft:snow_block
setblock 165 89 316 minecraft:snow_block
setblock 166 89 276 minecraft:packed_ice
setblock 166 89 316 minecraft:packed_ice
fill 167 89 277 167 95 277 minecraft:packed_ice
fill 168 89 292 168 89 293 minecraft:packed_ice
fill 168 89 294 168 97 295 minecraft:snow_block
fill 169 89 291 169 97 291 minecraft:snow_block
fill 170 89 290 170 97 290 minecraft:snow_block
fill 170 89 300 170 97 300 minecraft:snow_block
fill 171 89 275 171 114 275 minecraft:packed_ice
fill 171 89 289 171 97 289 minecraft:snow_block
fill 171 89 301 171 97 301 minecraft:snow_block
fill 172 89 288 172 97 288 minecraft:snow_block
fill 172 89 302 172 97 302 minecraft:snow_block
fill 175 89 287 177 97 287 minecraft:snow_block
fill 175 89 303 176 97 303 minecraft:snow_block
setblock 175 89 316 minecraft:snow_block
setblock 176 89 276 minecraft:packed_ice
fill 176 89 316 176 92 316 minecraft:packed_ice
fill 178 89 303 178 131 303 minecraft:snow_block
fill 179 89 299 179 101 299 minecraft:snow_block
setblock 179 89 302 minecraft:snow_block
fill 179 89 303 179 91 303 minecraft:packed_ice
setblock 179 89 306 minecraft:packed_ice
setblock 179 89 307 minecraft:snow_block
fill 179 89 308 179 90 308 minecraft:packed_ice
setblock 180 89 276 minecraft:snow_block
setblock 180 89 285 minecraft:packed_ice
fill 180 89 288 180 95 288 minecraft:snow_block
fill 180 89 296 180 101 296 minecraft:snow_block
setblock 180 89 297 minecraft:packed_ice
setblock 180 89 301 minecraft:snow_block
fill 180 89 302 180 92 302 minecraft:packed_ice
setblock 180 89 306 minecraft:snow_block
fill 180 89 307 180 92 307 minecraft:packed_ice
setblock 180 89 316 minecraft:snow_block
setblock 181 89 276 minecraft:packed_ice
setblock 181 89 280 minecraft:snow_block
fill 181 89 281 181 90 281 minecraft:packed_ice
setblock 181 89 285 minecraft:snow_block
fill 181 89 286 181 92 286 minecraft:packed_ice
setblock 181 89 289 minecraft:packed_ice
setblock 181 89 290 minecraft:snow_block
fill 181 89 291 181 90 291 minecraft:packed_ice
setblock 181 89 295 minecraft:snow_block
fill 181 89 296 181 90 296 minecraft:packed_ice
setblock 181 89 300 minecraft:snow_block
fill 181 89 301 181 92 301 minecraft:packed_ice
setblock 181 89 305 minecraft:snow_block
fill 181 89 306 181 92 306 minecraft:packed_ice
setblock 181 89 310 minecraft:snow_block
fill 181 89 311 181 90 311 minecraft:packed_ice
setblock 181 89 316 minecraft:packed_ice
setblock 182 89 279 minecraft:snow_block
fill 182 89 280 182 91 280 minecraft:packed_ice
setblock 182 89 284 minecraft:snow_block
fill 182 89 285 182 92 285 minecraft:packed_ice
setblock 182 89 289 minecraft:snow_block
fill 182 89 290 182 92 290 minecraft:packed_ice
setblock 182 89 294 minecraft:snow_block
fill 182 89 295 182 92 295 minecraft:packed_ice
setblock 182 89 299 minecraft:snow_block
fill 182 89 300 182 92 300 minecraft:packed_ice
setblock 182 89 304 minecraft:snow_block
fill 182 89 305 182 92 305 minecraft:packed_ice
setblock 182 89 309 minecraft:snow_block
fill 182 89 310 182 92 310 minecraft:packed_ice
fill 183 89 299 183 114 299 minecraft:packed_ice
fill 141 90 298 141 99 298 minecraft:packed_ice
setblock 141 90 301 minecraft:packed_ice
setblock 142 90 278 minecraft:snow_block
fill 142 90 279 142 92 279 minecraft:packed_ice
setblock 142 90 283 minecraft:snow_block
fill 142 90 284 142 93 284 minecraft:packed_ice
setblock 142 90 288 minecraft:snow_block
fill 142 90 289 142 93 289 minecraft:packed_ice
setblock 142 90 293 minecraft:snow_block
fill 142 90 294 142 91 294 minecraft:packed_ice
setblock 142 90 298 minecraft:snow_block
fill 142 90 299 142 91 299 minecraft:packed_ice
setblock 142 90 303 minecraft:snow_block
fill 142 90 304 142 92 304 minecraft:packed_ice
setblock 142 90 308 minecraft:snow_block
fill 142 90 309 142 91 309 minecraft:packed_ice
setblock 143 90 282 minecraft:snow_block
fill 143 90 283 143 93 283 minecraft:packed_ice
setblock 143 90 287 minecraft:snow_block
fill 143 90 288 143 93 288 minecraft:packed_ice
setblock 143 90 302 minecraft:snow_block
setblock 143 90 303 minecraft:packed_ice
setblock 153 90 277 minecraft:snow_block
setblock 154 90 276 minecraft:snow_block
fill 154 90 277 154 93 277 minecraft:packed_ice
fill 154 90 313 154 90 316 minecraft:blue_ice
fill 155 90 276 155 93 276 minecraft:packed_ice
fill 155 90 311 155 90 315 minecraft:blue_ice
fill 155 90 316 155 93 316 minecraft:packed_ice
fill 156 90 313 156 90 315 minecraft:blue_ice
setblock 157 90 278 minecraft:snow_block
setblock 158 90 277 minecraft:snow_block
fill 158 90 278 158 91 278 minecraft:packed_ice
fill 158 90 315 159 90 315 minecraft:packed_ice
setblock 159 90 276 minecraft:snow_block
fill 159 90 277 159 92 277 minecraft:packed_ice
setblock 159 90 316 minecraft:snow_block
fill 160 90 276 160 93 276 minecraft:packed_ice
setblock 160 90 315 minecraft:snow_block
fill 160 90 316 160 93 316 minecraft:packed_ice
setblock 161 90 315 minecraft:packed_ice
setblock 164 90 276 minecraft:snow_block
setblock 164 90 316 minecraft:snow_block
fill 168 90 292 168 96 293 minecraft:snow_block
fill 170 90 289 170 96 289 minecraft:snow_block
fill 170 90 301 170 96 301 minecraft:snow_block
fill 173 90 287 174 96 287 minecraft:snow_block
fill 173 90 303 174 96 303 minecraft:snow_block
fill 175 90 316 175 91 316 minecraft:packed_ice
fill 178 90 287 179 98 287 minecraft:snow_block
fill 179 90 300 179 99 301 minecraft:snow_block
setblock 179 90 302 minecraft:packed_ice
setblock 179 90 306 minecraft:snow_block
fill 179 90 307 179 91 307 minecraft:packed_ice
setblock 179 90 316 minecraft:snow_block
fill 180 90 297 180 101 298 minecraft:snow_block
setblock 180 90 300 minecraft:snow_block
fill 180 90 301 180 91 301 minecraft:packed_ice
setblock 180 90 305 minecraft:snow_block
fill 180 90 306 180 93 306 minecraft:packed_ice
setblock 181 90 284 minecraft:snow_block
fill 181 90 285 181 93 285 minecraft:packed_ice
setblock 181 90 289 minecraft:snow_block
fill 181 90 290 181 93 290 minecraft:packed_ice
fill 181 90 292 181 94 294 minecraft:snow_block
setblock 181 90 295 minecraft:packed_ice
setblock 181 90 299 minecraft:snow_block
fill 181 90 300 181 92 300 minecraft:packed_ice
setblock 181 90 304 minecraft:snow_block
fill 181 90 305 181 93 305 minecraft:packed_ice
setblock 181 90 309 minecraft:snow_block
fill 181 90 310 181 93 310 minecraft:packed_ice
setblock 182 90 279 minecraft:packed_ice
setblock 182 90 283 minecraft:snow_block
fill 182 90 284 182 93 284 minecraft:packed_ice
setblock 182 90 288 minecraft:snow_block
fill 182 90 289 182 93 289 minecraft:packed_ice
setblock 182 90 293 minecraft:snow_block
fill 182 90 294 182 93 294 minecraft:packed_ice
setblock 182 90 298 minecraft:snow_block
fill 182 90 299 182 93 299 minecraft:packed_ice
setblock 182 90 303 minecraft:snow_block
fill 182 90 304 182 93 304 minecraft:packed_ice
setblock 182 90 308 minecraft:snow_block
fill 182 90 309 182 93 309 minecraft:packed_ice
setblock 141 91 301 minecraft:light_blue_concrete
setblock 141 91 302 minecraft:white_concrete
fill 141 91 303 141 110 306 minecraft:packed_ice
setblock 142 91 278 minecraft:packed_ice
setblock 142 91 282 minecraft:snow_block
fill 142 91 283 142 94 283 minecraft:packed_ice
setblock 142 91 287 minecraft:snow_block
fill 142 91 288 142 94 288 minecraft:packed_ice
setblock 142 91 292 minecraft:snow_block
fill 142 91 293 142 94 293 minecraft:packed_ice
setblock 142 91 297 minecraft:snow_block
setblock 142 91 298 minecraft:packed_ice
setblock 142 91 302 minecraft:snow_block
fill 142 91 303 142 92 303 minecraft:packed_ice
setblock 142 91 307 minecraft:snow_block
fill 142 91 308 142 92 308 minecraft:packed_ice
setblock 143 91 281 minecraft:snow_block
fill 143 91 282 143 92 282 minecraft:packed_ice
setblock 143 91 286 minecraft:snow_block
fill 143 91 287 143 94 287 minecraft:packed_ice
setblock 153 91 276 minecraft:snow_block
fill 154 91 276 154 94 276 minecraft:packed_ice
fill 154 91 314 154 91 316 minecraft:blue_ice
fill 155 91 313 155 91 315 minecraft:blue_ice
setblock 156 91 278 minecraft:snow_block
fill 156 91 314 156 91 315 minecraft:blue_ice
setblock 157 91 277 minecraft:snow_block
setblock 157 91 278 minecraft:packed_ice
setblock 158 91 276 minecraft:snow_block
fill 158 91 277 158 93 277 minecraft:packed_ice
setblock 158 91 315 minecraft:packed_ice
setblock 158 91 316 minecraft:snow_block
fill 159 91 276 159 94 276 minecraft:packed_ice
setblock 159 91 315 minecraft:snow_block
fill 159 91 316 159 94 316 minecraft:packed_ice
setblock 160 91 275 minecraft:light_blue_concrete
setblock 163 91 276 minecraft:snow_block
setblock 163 91 316 minecraft:snow_block
fill 169 91 290 169 95 290 minecraft:snow_block
fill 169 91 300 169 95 300 minecraft:snow_block
fill 171 91 288 171 95 288 minecraft:snow_block
fill 171 91 302 171 95 302 minecraft:snow_block
setblock 178 91 316 minecraft:snow_block
fill 179 91 302 179 98 302 minecraft:snow_block
fill 179 91 305 179 131 305 minecraft:snow_block
setblock 179 91 306 minecraft:packed_ice
fill 180 91 299 180 100 299 minecraft:snow_block
setblock 180 91 300 minecraft:packed_ice
setblock 180 91 304 minecraft:snow_block
fill 180 91 305 180 93 305 minecraft:packed_ice
setblock 180 91 309 minecraft:snow_block
setblock 181 91 283 minecraft:snow_block
fill 181 91 284 181 93 284 minecraft:packed_ice
setblock 181 91 288 minecraft:snow_block
fill 181 91 289 181 94 289 minecraft:packed_ice
fill 181 91 291 181 93 291 minecraft:snow_block
fill 181 91 295 181 97 296 minecraft:snow_block
fill 181 91 298 181 100 298 minecraft:snow_block
fill 181 91 299 181 92 299 minecraft:packed_ice
setblock 181 91 303 minecraft:snow_block
fill 181 91 304 181 94 304 minecraft:packed_ice
setblock 181 91 308 minecraft:snow_block
fill 181 91 309 181 94 309 minecraft:packed_ice
setblock 182 91 282 minecraft:snow_block
fill 182 91 283 182 94 283 minecraft:packed_ice
setblock 182 91 287 minecraft:snow_block
fill 182 91 288 182 94 288 minecraft:packed_ice
setblock 182 91 292 minecraft:snow_block
fill 182 91 293 182 94 293 minecraft:packed_ice
setblock 182 91 297 minecraft:snow_block
fill 182 91 298 182 93 298 minecraft:packed_ice
setblock 182 91 302 minecraft:snow_block
fill 182 91 303 182 94 303 minecraft:packed_ice
setblock 182 91 307 minecraft:snow_block
fill 182 91 308 182 94 308 minecraft:packed_ice
setblock 182 91 312 minecraft:snow_block
fill 141 92 295 141 114 295 minecraft:packed_ice
setblock 141 92 296 minecraft:white_concrete
fill 141 92 297 141 112 297 minecraft:packed_ice
fill 141 92 301 141 93 302 minecraft:packed_ice
setblock 142 92 281 minecraft:snow_block
fill 142 92 282 142 95 282 minecraft:packed_ice
setblock 142 92 286 minecraft:snow_block
fill 142 92 287 142 95 287 minecraft:packed_ice
setblock 142 92 291 minecraft:snow_block
fill 142 92 292 142 95 292 minecraft:packed_ice
setblock 142 92 301 minecraft:snow_block
setblock 142 92 302 minecraft:packed_ice
setblock 142 92 306 minecraft:snow_block
fill 142 92 307 142 93 307 minecraft:packed_ice
setblock 143 92 285 minecraft:snow_block
fill 143 92 286 143 95 286 minecraft:packed_ice
setblock 144 92 278 minecraft:light[level=15]
setblock 144 92 286 minecraft:light[level=15]
setblock 144 92 294 minecraft:light[level=15]
setblock 144 92 302 minecraft:light[level=15]
setblock 144 92 310 minecraft:light[level=15]
fill 145 92 280 145 95 280 minecraft:packed_ice
fill 146 92 279 146 95 279 minecraft:packed_ice
fill 146 92 281 146 95 281 minecraft:packed_ice
fill 147 92 280 147 95 280 minecraft:packed_ice
setblock 152 92 276 minecraft:snow_block
setblock 152 92 278 minecraft:light[level=15]
setblock 152 92 286 minecraft:light[level=15]
setblock 152 92 294 minecraft:light[level=15]
setblock 152 92 302 minecraft:light[level=15]
setblock 152 92 310 minecraft:light[level=15]
fill 153 92 276 153 95 276 minecraft:packed_ice
fill 154 92 316 154 94 316 minecraft:packed_ice
setblock 155 92 315 minecraft:blue_ice
setblock 156 92 277 minecraft:snow_block
setblock 157 92 276 minecraft:snow_block
fill 157 92 277 157 95 277 minecraft:packed_ice
setblock 157 92 316 minecraft:snow_block
fill 158 92 276 158 95 276 minecraft:packed_ice
setblock 158 92 315 minecraft:snow_block
fill 158 92 316 158 95 316 minecraft:packed_ice
fill 159 92 315 159 95 315 minecraft:packed_ice
fill 160 92 275 160 110 275 minecraft:packed_ice
setblock 160 92 278 minecraft:light[level=15]
setblock 160 92 286 minecraft:light[level=15]
setblock 160 92 294 minecraft:light[level=15]
setblock 160 92 302 minecraft:light[level=15]
setblock 160 92 310 minecraft:light[level=15]
setblock 162 92 316 minecraft:snow_block
fill 166 92 275 167 111 275 minecraft:packed_ice
setblock 168 92 275 minecraft:light_blue_concrete
setblock 168 92 278 minecraft:light[level=15]
setblock 168 92 286 minecraft:light[level=15]
fill 168 92 291 168 94 291 minecraft:snow_block
setblock 168 92 302 minecraft:light[level=15]
setblock 168 92 310 minecraft:light[level=15]
fill 172 92 287 172 94 287 minecraft:snow_block
fill 172 92 303 172 94 303 minecraft:snow_block
fill 175 92 275 177 111 275 minecraft:packed_ice
setblock 176 92 278 minecraft:light[level=15]
setblock 176 92 286 minecraft:light[level=15]
setblock 176 92 310 minecraft:light[level=15]
setblock 178 92 275 minecraft:light_blue_concrete
fill 179 92 275 179 115 275 minecraft:packed_ice
fill 179 92 303 179 131 304 minecraft:snow_block
fill 179 92 306 179 131 306 minecraft:snow_block
fill 180 92 287 181 92 287 minecraft:snow_block
fill 180 92 300 180 98 301 minecraft:snow_block
fill 180 92 303 180 131 303 minecraft:snow_block
fill 180 92 304 180 93 304 minecraft:packed_ice
setblock 180 92 308 minecraft:snow_block
setblock 180 92 309 minecraft:packed_ice
setblock 181 92 283 minecraft:packed_ice
fill 181 92 288 181 95 288 minecraft:packed_ice
fill 181 92 297 181 100 297 minecraft:snow_block
setblock 181 92 302 minecraft:snow_block
fill 181 92 303 181 94 303 minecraft:packed_ice
setblock 181 92 307 minecraft:snow_block
fill 181 92 308 181 95 308 minecraft:packed_ice
setblock 182 92 281 minecraft:snow_block
fill 182 92 282 182 93 282 minecraft:packed_ice
setblock 182 92 286 minecraft:snow_block
fill 182 92 287 182 95 287 minecraft:packed_ice
setblock 182 92 291 minecraft:snow_block
fill 182 92 292 182 95 292 minecraft:packed_ice
setblock 182 92 296 minecraft:snow_block
fill 182 92 297 182 93 297 minecraft:packed_ice
setblock 182 92 301 minecraft:snow_block
fill 182 92 302 182 95 302 minecraft:packed_ice
setblock 182 92 306 minecraft:snow_block
fill 182 92 307 182 95 307 minecraft:packed_ice
setblock 182 92 311 minecraft:snow_block
setblock 183 92 286 minecraft:white_concrete
setblock 141 93 281 minecraft:light_blue_concrete
fill 141 93 296 141 96 296 minecraft:packed_ice
setblock 142 93 280 minecraft:snow_block
fill 142 93 281 142 96 281 minecraft:packed_ice
setblock 142 93 285 minecraft:snow_block
fill 142 93 286 142 96 286 minecraft:packed_ice
setblock 142 93 290 minecraft:snow_block
fill 142 93 291 142 96 291 minecraft:packed_ice
schedule function dropper:buildpart/63_2 1t
