fill 176 164 316 176 167 316 minecraft:packed_ice
fill 177 164 306 177 170 306 minecraft:packed_ice
setblock 177 164 314 minecraft:snow_block
fill 177 164 315 177 167 315 minecraft:packed_ice
fill 178 164 296 179 164 296 minecraft:packed_ice
setblock 178 164 314 minecraft:packed_ice
setblock 179 164 292 minecraft:snow_block
fill 179 164 293 179 165 293 minecraft:packed_ice
setblock 179 164 297 minecraft:snow_block
setblock 180 164 276 minecraft:snow_block
setblock 180 164 291 minecraft:snow_block
fill 180 164 292 180 167 292 minecraft:packed_ice
setblock 180 164 296 minecraft:snow_block
fill 180 164 297 180 167 297 minecraft:packed_ice
setblock 180 164 316 minecraft:snow_block
fill 181 164 276 181 167 276 minecraft:packed_ice
setblock 181 164 290 minecraft:snow_block
fill 181 164 291 181 167 291 minecraft:packed_ice
setblock 181 164 295 minecraft:snow_block
fill 181 164 296 181 167 296 minecraft:packed_ice
setblock 181 164 300 minecraft:snow_block
fill 181 164 301 181 167 301 minecraft:packed_ice
setblock 181 164 311 minecraft:packed_ice
setblock 181 164 315 minecraft:snow_block
fill 181 164 316 181 167 316 minecraft:packed_ice
setblock 182 164 285 minecraft:packed_ice
setblock 182 164 289 minecraft:snow_block
fill 182 164 290 182 167 290 minecraft:packed_ice
setblock 182 164 294 minecraft:snow_block
fill 182 164 295 182 167 295 minecraft:packed_ice
setblock 182 164 299 minecraft:snow_block
fill 182 164 300 182 167 300 minecraft:packed_ice
setblock 182 164 304 minecraft:snow_block
setblock 182 164 305 minecraft:packed_ice
setblock 182 164 309 minecraft:snow_block
setblock 182 164 310 minecraft:packed_ice
setblock 182 164 314 minecraft:snow_block
fill 182 164 315 182 166 315 minecraft:packed_ice
fill 183 164 292 183 179 292 minecraft:blue_ice
fill 183 164 304 183 176 304 minecraft:blue_ice
fill 141 165 289 141 179 289 minecraft:blue_ice
setblock 141 165 290 minecraft:light_blue_concrete
setblock 141 165 308 minecraft:white_concrete
fill 142 165 276 142 165 277 minecraft:packed_ice
setblock 142 165 278 minecraft:snow_block
fill 142 165 279 142 165 282 minecraft:packed_ice
setblock 142 165 283 minecraft:snow_block
setblock 142 165 284 minecraft:packed_ice
setblock 142 165 288 minecraft:snow_block
fill 142 165 289 142 168 289 minecraft:packed_ice
setblock 142 165 293 minecraft:snow_block
fill 142 165 294 142 168 294 minecraft:packed_ice
setblock 142 165 298 minecraft:snow_block
fill 142 165 299 142 168 299 minecraft:packed_ice
setblock 142 165 314 minecraft:packed_ice
setblock 143 165 292 minecraft:snow_block
fill 143 165 293 143 166 293 minecraft:packed_ice
setblock 144 165 276 minecraft:snow_block
setblock 144 165 316 minecraft:snow_block
fill 145 165 276 148 165 276 minecraft:packed_ice
fill 147 165 287 147 166 287 minecraft:packed_ice
fill 147 165 289 147 166 289 minecraft:packed_ice
fill 148 165 290 149 166 290 minecraft:packed_ice
fill 148 165 315 148 166 315 minecraft:blue_ice
setblock 149 165 276 minecraft:snow_block
fill 149 165 312 149 166 313 minecraft:blue_ice
setblock 149 165 316 minecraft:snow_block
fill 150 165 276 153 165 276 minecraft:packed_ice
fill 150 165 287 150 166 289 minecraft:packed_ice
fill 150 165 311 150 167 312 minecraft:blue_ice
fill 150 165 316 153 165 316 minecraft:packed_ice
fill 151 165 277 152 165 277 minecraft:packed_ice
fill 151 165 295 152 211 296 minecraft:snow_block
fill 151 165 312 151 166 313 minecraft:blue_ice
fill 152 165 315 154 165 315 minecraft:packed_ice
setblock 153 165 277 minecraft:snow_block
setblock 154 165 276 minecraft:snow_block
fill 154 165 277 154 168 277 minecraft:packed_ice
setblock 154 165 316 minecraft:snow_block
fill 155 165 276 155 168 276 minecraft:packed_ice
setblock 155 165 315 minecraft:snow_block
fill 155 165 316 155 168 316 minecraft:packed_ice
setblock 156 165 275 minecraft:light_blue_concrete
setblock 156 165 314 minecraft:snow_block
fill 156 165 315 156 168 315 minecraft:packed_ice
fill 157 165 314 157 168 314 minecraft:packed_ice
fill 158 165 275 158 166 275 minecraft:blue_ice
setblock 158 165 277 minecraft:snow_block
setblock 159 165 276 minecraft:snow_block
fill 159 165 277 159 168 277 minecraft:packed_ice
setblock 159 165 316 minecraft:snow_block
fill 160 165 276 160 168 276 minecraft:packed_ice
setblock 160 165 315 minecraft:snow_block
fill 160 165 316 160 168 316 minecraft:packed_ice
setblock 161 165 314 minecraft:snow_block
fill 161 165 315 161 168 315 minecraft:packed_ice
setblock 162 165 314 minecraft:packed_ice
setblock 164 165 276 minecraft:snow_block
setblock 164 165 316 minecraft:snow_block
setblock 165 165 276 minecraft:packed_ice
setblock 165 165 315 minecraft:snow_block
fill 165 165 316 168 165 316 minecraft:packed_ice
setblock 166 165 315 minecraft:packed_ice
setblock 169 165 316 minecraft:snow_block
fill 170 165 316 170 168 316 minecraft:packed_ice
setblock 171 165 315 minecraft:packed_ice
setblock 174 165 276 minecraft:snow_block
setblock 174 165 316 minecraft:snow_block
fill 175 165 276 175 168 276 minecraft:packed_ice
setblock 175 165 315 minecraft:snow_block
fill 175 165 316 175 168 316 minecraft:packed_ice
fill 175 165 317 175 176 317 minecraft:blue_ice
fill 176 165 315 176 168 315 minecraft:packed_ice
fill 177 165 296 178 171 296 minecraft:packed_ice
setblock 179 165 276 minecraft:snow_block
setblock 179 165 296 minecraft:snow_block
fill 179 165 297 179 168 297 minecraft:packed_ice
setblock 179 165 316 minecraft:snow_block
fill 180 165 276 180 168 276 minecraft:packed_ice
fill 180 165 291 180 166 291 minecraft:packed_ice
setblock 180 165 295 minecraft:snow_block
fill 180 165 296 180 168 296 minecraft:packed_ice
setblock 180 165 315 minecraft:snow_block
fill 180 165 316 180 168 316 minecraft:packed_ice
setblock 181 165 289 minecraft:snow_block
fill 181 165 290 181 167 290 minecraft:packed_ice
setblock 181 165 294 minecraft:snow_block
fill 181 165 295 181 168 295 minecraft:packed_ice
setblock 181 165 299 minecraft:snow_block
fill 181 165 300 181 168 300 minecraft:packed_ice
setblock 182 165 288 minecraft:snow_block
fill 182 165 289 182 168 289 minecraft:packed_ice
setblock 182 165 293 minecraft:snow_block
fill 182 165 294 182 168 294 minecraft:packed_ice
setblock 182 165 298 minecraft:snow_block
fill 182 165 299 182 168 299 minecraft:packed_ice
setblock 182 165 303 minecraft:snow_block
setblock 182 165 313 minecraft:snow_block
fill 182 165 314 182 166 314 minecraft:packed_ice
fill 183 165 293 183 179 293 minecraft:blue_ice
setblock 183 165 294 minecraft:light_blue_concrete
fill 183 165 295 183 176 297 minecraft:blue_ice
fill 141 166 290 141 175 290 minecraft:blue_ice
fill 141 166 308 141 176 308 minecraft:blue_ice
setblock 142 166 276 minecraft:packed_ice
setblock 142 166 277 minecraft:snow_block
fill 142 166 278 142 166 281 minecraft:packed_ice
setblock 142 166 282 minecraft:snow_block
setblock 142 166 287 minecraft:snow_block
fill 142 166 288 142 167 288 minecraft:packed_ice
setblock 142 166 292 minecraft:snow_block
fill 142 166 293 142 169 293 minecraft:packed_ice
setblock 142 166 297 minecraft:snow_block
fill 142 166 298 142 169 298 minecraft:packed_ice
setblock 143 166 276 minecraft:snow_block
setblock 143 166 292 minecraft:packed_ice
setblock 143 166 316 minecraft:snow_block
fill 144 166 276 147 166 276 minecraft:packed_ice
setblock 144 166 278 minecraft:light[level=12]
setblock 144 166 285 minecraft:light[level=12]
setblock 144 166 292 minecraft:light[level=12]
setblock 144 166 299 minecraft:light[level=12]
setblock 144 166 306 minecraft:light[level=12]
setblock 144 166 313 minecraft:light[level=12]
fill 146 166 288 146 166 289 minecraft:packed_ice
setblock 147 166 290 minecraft:packed_ice
setblock 148 166 276 minecraft:snow_block
fill 148 166 286 149 166 286 minecraft:packed_ice
fill 148 166 291 149 166 291 minecraft:packed_ice
setblock 148 166 316 minecraft:snow_block
fill 149 166 276 152 166 276 minecraft:packed_ice
setblock 149 166 311 minecraft:blue_ice
fill 149 166 316 152 166 316 minecraft:packed_ice
fill 150 166 277 151 166 277 minecraft:packed_ice
setblock 150 166 290 minecraft:packed_ice
fill 150 166 309 150 167 310 minecraft:blue_ice
setblock 151 166 278 minecraft:light[level=12]
setblock 151 166 285 minecraft:light[level=12]
fill 151 166 288 151 166 289 minecraft:packed_ice
setblock 151 166 292 minecraft:light[level=12]
fill 151 166 297 152 167 297 minecraft:packed_ice
setblock 151 166 299 minecraft:light[level=12]
setblock 151 166 306 minecraft:light[level=12]
setblock 151 166 311 minecraft:blue_ice
setblock 152 166 277 minecraft:snow_block
fill 152 166 315 153 166 315 minecraft:packed_ice
setblock 153 166 276 minecraft:snow_block
fill 153 166 277 153 169 277 minecraft:packed_ice
fill 153 166 296 153 167 296 minecraft:packed_ice
setblock 153 166 316 minecraft:snow_block
fill 154 166 276 154 169 276 minecraft:packed_ice
setblock 154 166 315 minecraft:snow_block
fill 154 166 316 154 169 316 minecraft:packed_ice
setblock 155 166 278 minecraft:packed_ice
setblock 155 166 314 minecraft:snow_block
fill 155 166 315 155 169 315 minecraft:packed_ice
fill 156 166 275 156 179 275 minecraft:blue_ice
setblock 156 166 278 minecraft:snow_block
fill 156 166 314 156 169 314 minecraft:packed_ice
setblock 157 166 277 minecraft:snow_block
fill 157 166 278 157 169 278 minecraft:packed_ice
setblock 158 166 276 minecraft:snow_block
fill 158 166 277 158 169 277 minecraft:packed_ice
setblock 158 166 278 minecraft:light[level=12]
setblock 158 166 285 minecraft:light[level=12]
setblock 158 166 292 minecraft:light[level=12]
setblock 158 166 299 minecraft:light[level=12]
setblock 158 166 306 minecraft:light[level=12]
setblock 158 166 313 minecraft:light[level=12]
setblock 158 166 316 minecraft:snow_block
fill 159 166 276 159 169 276 minecraft:packed_ice
setblock 159 166 315 minecraft:snow_block
fill 159 166 316 159 169 316 minecraft:packed_ice
setblock 160 166 314 minecraft:snow_block
fill 160 166 315 160 169 315 minecraft:packed_ice
setblock 161 166 314 minecraft:packed_ice
setblock 163 166 276 minecraft:snow_block
setblock 163 166 316 minecraft:snow_block
fill 164 166 276 164 169 276 minecraft:packed_ice
setblock 164 166 315 minecraft:snow_block
fill 164 166 316 167 166 316 minecraft:packed_ice
setblock 165 166 278 minecraft:light[level=12]
setblock 165 166 285 minecraft:light[level=12]
setblock 165 166 292 minecraft:light[level=12]
setblock 165 166 299 minecraft:light[level=12]
setblock 165 166 306 minecraft:light[level=12]
setblock 165 166 313 minecraft:light[level=12]
setblock 165 166 315 minecraft:packed_ice
setblock 168 166 316 minecraft:snow_block
fill 169 166 316 169 169 316 minecraft:packed_ice
fill 171 166 314 171 172 314 minecraft:packed_ice
setblock 172 166 278 minecraft:light[level=12]
setblock 172 166 285 minecraft:light[level=12]
setblock 172 166 292 minecraft:light[level=12]
setblock 172 166 299 minecraft:light[level=12]
setblock 172 166 306 minecraft:light[level=12]
setblock 172 166 313 minecraft:light[level=12]
setblock 173 166 276 minecraft:snow_block
setblock 173 166 316 minecraft:snow_block
fill 174 166 276 174 169 276 minecraft:packed_ice
setblock 174 166 315 minecraft:snow_block
fill 174 166 316 174 169 316 minecraft:packed_ice
fill 175 166 315 175 169 315 minecraft:packed_ice
fill 177 166 295 178 171 295 minecraft:packed_ice
fill 177 166 297 178 171 297 minecraft:packed_ice
setblock 178 166 276 minecraft:snow_block
setblock 178 166 316 minecraft:snow_block
fill 179 166 276 179 169 276 minecraft:packed_ice
setblock 179 166 278 minecraft:light[level=12]
setblock 179 166 285 minecraft:light[level=12]
setblock 179 166 292 minecraft:light[level=12]
setblock 179 166 295 minecraft:snow_block
fill 179 166 296 179 169 296 minecraft:packed_ice
setblock 179 166 299 minecraft:light[level=12]
setblock 179 166 306 minecraft:light[level=12]
setblock 179 166 313 minecraft:light[level=12]
setblock 179 166 315 minecraft:snow_block
fill 179 166 316 179 169 316 minecraft:packed_ice
setblock 180 166 294 minecraft:snow_block
fill 180 166 295 180 169 295 minecraft:packed_ice
setblock 180 166 299 minecraft:snow_block
setblock 181 166 289 minecraft:packed_ice
setblock 181 166 293 minecraft:snow_block
fill 181 166 294 181 169 294 minecraft:packed_ice
setblock 181 166 298 minecraft:snow_block
fill 181 166 299 181 169 299 minecraft:packed_ice
setblock 182 166 277 minecraft:snow_block
setblock 182 166 287 minecraft:snow_block
fill 182 166 288 182 167 288 minecraft:packed_ice
setblock 182 166 292 minecraft:snow_block
fill 182 166 293 182 169 293 minecraft:packed_ice
setblock 182 166 297 minecraft:snow_block
fill 182 166 298 182 169 298 minecraft:packed_ice
setblock 182 166 302 minecraft:snow_block
fill 183 166 294 183 179 294 minecraft:blue_ice
setblock 142 167 276 minecraft:snow_block
fill 142 167 277 142 167 280 minecraft:packed_ice
setblock 142 167 281 minecraft:snow_block
fill 142 167 282 142 170 282 minecraft:packed_ice
setblock 142 167 287 minecraft:packed_ice
setblock 142 167 291 minecraft:snow_block
fill 142 167 292 142 170 292 minecraft:packed_ice
setblock 142 167 296 minecraft:snow_block
fill 142 167 297 142 170 297 minecraft:packed_ice
setblock 142 167 316 minecraft:snow_block
fill 143 167 276 146 167 276 minecraft:packed_ice
setblock 147 167 276 minecraft:snow_block
fill 148 167 276 151 167 276 minecraft:packed_ice
fill 148 167 316 151 167 316 minecraft:packed_ice
fill 149 167 277 150 167 277 minecraft:packed_ice
fill 149 167 313 149 167 315 minecraft:blue_ice
fill 150 167 295 150 167 297 minecraft:packed_ice
fill 150 167 314 150 167 315 minecraft:blue_ice
setblock 151 167 277 minecraft:snow_block
fill 151 167 294 152 167 294 minecraft:packed_ice
fill 151 167 313 151 167 314 minecraft:blue_ice
fill 151 167 315 152 167 315 minecraft:packed_ice
setblock 152 167 276 minecraft:snow_block
fill 152 167 277 152 170 277 minecraft:packed_ice
setblock 152 167 316 minecraft:snow_block
fill 153 167 276 153 170 276 minecraft:packed_ice
fill 153 167 278 154 167 278 minecraft:packed_ice
setblock 153 167 295 minecraft:packed_ice
setblock 153 167 297 minecraft:packed_ice
setblock 153 167 315 minecraft:snow_block
fill 153 167 316 153 170 316 minecraft:packed_ice
setblock 154 167 314 minecraft:snow_block
fill 154 167 315 154 170 315 minecraft:packed_ice
setblock 155 167 278 minecraft:snow_block
fill 155 167 314 155 170 314 minecraft:packed_ice
setblock 156 167 277 minecraft:snow_block
fill 156 167 278 156 170 278 minecraft:packed_ice
setblock 157 167 276 minecraft:snow_block
fill 157 167 277 157 170 277 minecraft:packed_ice
setblock 157 167 316 minecraft:snow_block
setblock 158 167 275 minecraft:light_blue_concrete
fill 158 167 276 158 170 276 minecraft:packed_ice
fill 158 167 278 158 173 278 minecraft:packed_ice
setblock 158 167 315 minecraft:snow_block
fill 158 167 316 158 170 316 minecraft:packed_ice
setblock 159 167 314 minecraft:snow_block
fill 159 167 315 159 170 315 minecraft:packed_ice
fill 160 167 314 160 168 314 minecraft:packed_ice
setblock 161 167 277 minecraft:snow_block
setblock 162 167 276 minecraft:snow_block
setblock 162 167 316 minecraft:snow_block
fill 163 167 276 163 170 276 minecraft:packed_ice
setblock 163 167 315 minecraft:snow_block
fill 163 167 316 166 167 316 minecraft:packed_ice
setblock 164 167 315 minecraft:packed_ice
setblock 167 167 316 minecraft:snow_block
fill 168 167 316 168 170 316 minecraft:packed_ice
setblock 172 167 276 minecraft:snow_block
setblock 172 167 316 minecraft:snow_block
fill 173 167 276 173 170 276 minecraft:packed_ice
setblock 173 167 315 minecraft:snow_block
fill 173 167 316 173 170 316 minecraft:packed_ice
fill 174 167 315 174 170 315 minecraft:packed_ice
fill 176 167 296 176 171 296 minecraft:packed_ice
setblock 177 167 276 minecraft:snow_block
setblock 177 167 316 minecraft:snow_block
fill 178 167 276 178 170 276 minecraft:packed_ice
setblock 178 167 315 minecraft:snow_block
fill 178 167 316 178 170 316 minecraft:packed_ice
fill 179 167 295 179 171 295 minecraft:packed_ice
setblock 180 167 293 minecraft:snow_block
fill 180 167 294 180 170 294 minecraft:packed_ice
setblock 180 167 298 minecraft:snow_block
fill 180 167 299 180 170 299 minecraft:packed_ice
setblock 181 167 292 minecraft:snow_block
fill 181 167 293 181 170 293 minecraft:packed_ice
setblock 181 167 297 minecraft:snow_block
fill 181 167 298 181 170 298 minecraft:packed_ice
setblock 182 167 276 minecraft:snow_block
fill 182 167 277 182 169 278 minecraft:packed_ice
setblock 182 167 291 minecraft:snow_block
fill 182 167 292 182 170 292 minecraft:packed_ice
setblock 182 167 296 minecraft:snow_block
fill 182 167 297 182 170 297 minecraft:packed_ice
setblock 182 167 301 minecraft:snow_block
fill 182 167 302 182 170 302 minecraft:packed_ice
setblock 183 167 310 minecraft:white_concrete
fill 183 167 311 183 175 313 minecraft:blue_ice
fill 142 168 276 142 168 279 minecraft:packed_ice
setblock 142 168 280 minecraft:snow_block
fill 142 168 281 142 171 281 minecraft:packed_ice
fill 142 168 283 142 169 283 minecraft:packed_ice
setblock 142 168 290 minecraft:snow_block
fill 142 168 291 142 170 291 minecraft:packed_ice
setblock 142 168 295 minecraft:snow_block
fill 142 168 296 142 171 296 minecraft:packed_ice
setblock 142 168 316 minecraft:packed_ice
fill 143 168 276 143 169 277 minecraft:packed_ice
fill 144 168 276 145 168 276 minecraft:packed_ice
setblock 145 168 275 minecraft:white_concrete
setblock 146 168 276 minecraft:snow_block
fill 147 168 276 149 168 277 minecraft:packed_ice
fill 147 168 316 150 168 316 minecraft:packed_ice
setblock 150 168 276 minecraft:packed_ice
setblock 150 168 277 minecraft:snow_block
setblock 151 168 276 minecraft:snow_block
fill 151 168 277 151 171 277 minecraft:packed_ice
fill 151 168 313 151 169 313 minecraft:snow_block
setblock 151 168 315 minecraft:packed_ice
setblock 151 168 316 minecraft:snow_block
fill 152 168 276 152 171 276 minecraft:packed_ice
fill 152 168 278 153 168 278 minecraft:packed_ice
fill 152 168 312 152 169 312 minecraft:snow_block
fill 152 168 314 152 168 315 minecraft:snow_block
fill 152 168 316 152 171 316 minecraft:packed_ice
fill 153 168 313 153 169 313 minecraft:snow_block
fill 153 168 315 153 171 315 minecraft:packed_ice
setblock 154 168 278 minecraft:snow_block
fill 154 168 314 154 171 314 minecraft:packed_ice
setblock 155 168 277 minecraft:snow_block
fill 155 168 278 155 171 278 minecraft:packed_ice
setblock 156 168 276 minecraft:snow_block
fill 156 168 277 156 171 277 minecraft:packed_ice
setblock 156 168 316 minecraft:snow_block
fill 157 168 276 157 171 276 minecraft:packed_ice
setblock 157 168 315 minecraft:snow_block
fill 157 168 316 157 171 316 minecraft:packed_ice
fill 158 168 275 158 170 275 minecraft:blue_ice
setblock 158 168 314 minecraft:snow_block
fill 158 168 315 158 171 315 minecraft:packed_ice
fill 159 168 314 159 169 314 minecraft:packed_ice
setblock 160 168 275 minecraft:white_concrete
setblock 160 168 277 minecraft:snow_block
setblock 161 168 276 minecraft:snow_block
fill 161 168 277 161 171 277 minecraft:packed_ice
setblock 161 168 316 minecraft:snow_block
fill 162 168 276 162 171 276 minecraft:packed_ice
setblock 162 168 315 minecraft:snow_block
fill 162 168 316 165 168 316 minecraft:packed_ice
fill 163 168 315 163 169 315 minecraft:packed_ice
setblock 166 168 316 minecraft:snow_block
fill 167 168 316 167 171 316 minecraft:packed_ice
setblock 171 168 276 minecraft:snow_block
setblock 171 168 316 minecraft:snow_block
setblock 172 168 275 minecraft:light_blue_concrete
fill 172 168 276 172 171 276 minecraft:packed_ice
setblock 172 168 315 minecraft:snow_block
fill 172 168 316 172 171 316 minecraft:packed_ice
fill 173 168 315 173 171 315 minecraft:packed_ice
setblock 175 168 277 minecraft:snow_block
setblock 176 168 276 minecraft:snow_block
fill 176 168 277 178 169 277 minecraft:packed_ice
fill 176 168 295 176 171 295 minecraft:packed_ice
fill 176 168 297 176 171 297 minecraft:packed_ice
setblock 176 168 316 minecraft:snow_block
fill 177 168 276 177 171 276 minecraft:packed_ice
fill 177 168 294 178 171 294 minecraft:packed_ice
fill 177 168 298 180 171 298 minecraft:packed_ice
setblock 177 168 315 minecraft:snow_block
fill 177 168 316 177 171 316 minecraft:packed_ice
setblock 178 168 315 minecraft:packed_ice
fill 180 168 293 180 169 293 minecraft:packed_ice
setblock 180 168 297 minecraft:snow_block
fill 180 168 300 180 169 300 minecraft:packed_ice
setblock 181 168 276 minecraft:snow_block
setblock 181 168 291 minecraft:snow_block
fill 181 168 292 181 171 292 minecraft:packed_ice
setblock 181 168 296 minecraft:snow_block
fill 181 168 297 181 171 297 minecraft:packed_ice
setblock 181 168 301 minecraft:snow_block
setblock 181 168 316 minecraft:snow_block
fill 182 168 276 182 171 276 minecraft:packed_ice
setblock 182 168 279 minecraft:packed_ice
setblock 182 168 290 minecraft:snow_block
fill 182 168 291 182 171 291 minecraft:packed_ice
setblock 182 168 295 minecraft:snow_block
fill 182 168 296 182 171 296 minecraft:packed_ice
setblock 182 168 300 minecraft:snow_block
fill 182 168 301 182 171 301 minecraft:packed_ice
setblock 183 168 286 minecraft:white_concrete
fill 183 168 287 183 175 287 minecraft:blue_ice
setblock 183 168 299 minecraft:light_blue_concrete
setblock 183 168 303 minecraft:light_blue_concrete
fill 183 168 310 183 174 310 minecraft:blue_ice
fill 142 169 276 142 169 278 minecraft:packed_ice
setblock 142 169 279 minecraft:snow_block
fill 142 169 280 142 172 280 minecraft:packed_ice
setblock 142 169 284 minecraft:snow_block
setblock 142 169 290 minecraft:packed_ice
setblock 142 169 294 minecraft:snow_block
fill 142 169 295 142 172 295 minecraft:packed_ice
setblock 142 169 299 minecraft:snow_block
fill 142 169 300 142 172 300 minecraft:packed_ice
setblock 143 169 278 minecraft:snow_block
fill 143 169 279 143 172 279 minecraft:packed_ice
setblock 144 169 276 minecraft:packed_ice
setblock 144 169 277 minecraft:snow_block
fill 144 169 299 144 171 299 minecraft:snow_block
fill 145 169 275 145 177 275 minecraft:blue_ice
setblock 145 169 276 minecraft:snow_block
fill 145 169 277 148 169 277 minecraft:packed_ice
fill 145 169 298 145 171 298 minecraft:snow_block
fill 145 169 300 145 171 300 minecraft:snow_block
fill 146 169 276 149 169 276 minecraft:packed_ice
fill 146 169 299 146 171 299 minecraft:snow_block
fill 146 169 316 149 169 316 minecraft:packed_ice
setblock 149 169 277 minecraft:snow_block
setblock 150 169 276 minecraft:snow_block
fill 150 169 277 150 171 278 minecraft:packed_ice
setblock 150 169 315 minecraft:packed_ice
setblock 150 169 316 minecraft:snow_block
fill 151 169 276 151 172 276 minecraft:packed_ice
fill 151 169 278 152 169 278 minecraft:packed_ice
setblock 151 169 312 minecraft:snow_block
fill 151 169 314 151 169 315 minecraft:snow_block
fill 151 169 316 151 172 316 minecraft:packed_ice
setblock 152 169 314 minecraft:snow_block
fill 152 169 315 152 172 315 minecraft:packed_ice
setblock 153 169 278 minecraft:snow_block
setblock 153 169 312 minecraft:snow_block
fill 153 169 314 153 172 314 minecraft:packed_ice
setblock 154 169 277 minecraft:snow_block
fill 154 169 278 154 172 278 minecraft:packed_ice
setblock 155 169 276 minecraft:snow_block
fill 155 169 277 155 172 277 minecraft:packed_ice
setblock 155 169 316 minecraft:snow_block
fill 156 169 276 156 172 276 minecraft:packed_ice
setblock 156 169 315 minecraft:snow_block
fill 156 169 316 156 172 316 minecraft:packed_ice
fill 157 169 279 157 170 279 minecraft:packed_ice
setblock 157 169 314 minecraft:snow_block
fill 157 169 315 157 172 315 minecraft:packed_ice
fill 158 169 280 158 170 280 minecraft:packed_ice
fill 158 169 314 158 171 314 minecraft:packed_ice
setblock 159 169 277 minecraft:snow_block
fill 159 169 279 159 170 279 minecraft:packed_ice
fill 160 169 275 160 179 275 minecraft:blue_ice
setblock 160 169 276 minecraft:snow_block
fill 160 169 277 160 172 277 minecraft:packed_ice
setblock 160 169 316 minecraft:snow_block
fill 161 169 276 161 172 276 minecraft:packed_ice
setblock 161 169 315 minecraft:snow_block
fill 161 169 316 164 169 316 minecraft:packed_ice
fill 162 169 315 162 171 315 minecraft:packed_ice
setblock 165 169 276 minecraft:snow_block
setblock 165 169 316 minecraft:snow_block
fill 166 169 316 166 172 316 minecraft:packed_ice
setblock 169 169 276 minecraft:packed_ice
setblock 170 169 276 minecraft:snow_block
fill 170 169 314 170 172 314 minecraft:packed_ice
setblock 170 169 316 minecraft:snow_block
fill 171 169 276 171 172 276 minecraft:packed_ice
fill 171 169 313 171 172 313 minecraft:packed_ice
setblock 171 169 315 minecraft:snow_block
fill 171 169 316 171 172 316 minecraft:packed_ice
fill 172 169 275 172 173 275 minecraft:blue_ice
fill 172 169 314 172 172 315 minecraft:packed_ice
setblock 173 169 277 minecraft:packed_ice
setblock 174 169 277 minecraft:snow_block
setblock 175 169 276 minecraft:snow_block
fill 175 169 277 175 172 277 minecraft:packed_ice
setblock 175 169 316 minecraft:snow_block
fill 176 169 276 176 172 276 minecraft:packed_ice
fill 176 169 298 176 171 298 minecraft:packed_ice
fill 176 169 306 176 170 306 minecraft:packed_ice
setblock 176 169 315 minecraft:snow_block
fill 176 169 316 176 172 316 minecraft:packed_ice
fill 177 169 305 177 170 305 minecraft:packed_ice
fill 177 169 307 177 170 307 minecraft:packed_ice
fill 177 169 315 177 170 315 minecraft:packed_ice
fill 178 169 306 178 170 306 minecraft:packed_ice
setblock 179 169 277 minecraft:snow_block
fill 179 169 294 179 171 294 minecraft:packed_ice
setblock 179 169 297 minecraft:snow_block
setblock 180 169 276 minecraft:snow_block
setblock 180 169 296 minecraft:snow_block
fill 180 169 297 180 172 297 minecraft:packed_ice
setblock 180 169 316 minecraft:snow_block
fill 181 169 276 181 172 276 minecraft:packed_ice
setblock 181 169 291 minecraft:packed_ice
setblock 181 169 295 minecraft:snow_block
fill 181 169 296 181 172 296 minecraft:packed_ice
setblock 181 169 300 minecraft:snow_block
fill 181 169 301 181 171 302 minecraft:packed_ice
setblock 182 169 279 minecraft:snow_block
fill 182 169 280 182 171 281 minecraft:packed_ice
setblock 182 169 289 minecraft:snow_block
fill 182 169 290 182 172 290 minecraft:packed_ice
setblock 182 169 294 minecraft:snow_block
fill 182 169 295 182 172 295 minecraft:packed_ice
setblock 182 169 299 minecraft:snow_block
fill 182 169 300 182 172 300 minecraft:packed_ice
setblock 182 169 303 minecraft:packed_ice
fill 183 169 286 183 179 286 minecraft:blue_ice
fill 183 169 299 183 177 299 minecraft:blue_ice
setblock 183 169 301 minecraft:white_concrete
fill 183 169 303 183 179 303 minecraft:blue_ice
setblock 141 170 302 minecraft:white_concrete
fill 141 170 303 141 177 304 minecraft:blue_ice
fill 142 170 276 142 170 277 minecraft:packed_ice
setblock 142 170 278 minecraft:snow_block
fill 142 170 279 142 173 279 minecraft:packed_ice
setblock 142 170 283 minecraft:snow_block
fill 142 170 284 142 172 285 minecraft:packed_ice
setblock 142 170 293 minecraft:snow_block
fill 142 170 294 142 172 294 minecraft:packed_ice
setblock 142 170 298 minecraft:snow_block
fill 142 170 299 142 173 299 minecraft:packed_ice
setblock 143 170 276 minecraft:packed_ice
setblock 143 170 277 minecraft:snow_block
fill 143 170 278 143 173 278 minecraft:packed_ice
fill 143 170 280 143 170 281 minecraft:packed_ice
setblock 144 170 276 minecraft:snow_block
fill 144 170 277 147 170 277 minecraft:packed_ice
fill 145 170 276 148 170 276 minecraft:packed_ice
fill 145 170 316 148 170 316 minecraft:packed_ice
setblock 148 170 277 minecraft:snow_block
fill 148 170 278 149 172 278 minecraft:packed_ice
setblock 149 170 276 minecraft:snow_block
fill 149 170 277 149 173 277 minecraft:packed_ice
setblock 149 170 316 minecraft:snow_block
fill 150 170 276 150 173 276 minecraft:packed_ice
setblock 150 170 315 minecraft:snow_block
fill 150 170 316 150 173 316 minecraft:packed_ice
setblock 151 170 278 minecraft:packed_ice
fill 151 170 315 151 173 315 minecraft:packed_ice
setblock 152 170 278 minecraft:snow_block
setblock 153 170 277 minecraft:snow_block
fill 153 170 278 153 172 279 minecraft:packed_ice
setblock 154 170 276 minecraft:snow_block
fill 154 170 277 154 173 277 minecraft:packed_ice
fill 154 170 279 155 170 279 minecraft:packed_ice
setblock 154 170 316 minecraft:snow_block
fill 155 170 276 155 173 276 minecraft:packed_ice
setblock 155 170 315 minecraft:snow_block
fill 155 170 316 155 173 316 minecraft:packed_ice
setblock 156 170 314 minecraft:snow_block
fill 156 170 315 156 173 315 minecraft:packed_ice
setblock 157 170 275 minecraft:white_concrete
setblock 157 170 278 minecraft:snow_block
fill 157 170 314 157 172 314 minecraft:packed_ice
setblock 158 170 277 minecraft:snow_block
setblock 159 170 276 minecraft:snow_block
fill 159 170 277 159 173 277 minecraft:packed_ice
setblock 159 170 316 minecraft:snow_block
fill 160 170 276 160 173 276 minecraft:packed_ice
setblock 160 170 315 minecraft:snow_block
fill 160 170 316 163 170 316 minecraft:packed_ice
fill 161 170 315 161 172 315 minecraft:packed_ice
setblock 164 170 276 minecraft:snow_block
setblock 164 170 316 minecraft:snow_block
fill 165 170 276 168 170 276 minecraft:packed_ice
fill 165 170 316 165 173 316 minecraft:packed_ice
setblock 169 170 276 minecraft:snow_block
setblock 169 170 316 minecraft:snow_block
fill 170 170 276 170 173 276 minecraft:packed_ice
fill 170 170 313 170 172 313 minecraft:packed_ice
fill 170 170 315 170 173 316 minecraft:packed_ice
fill 171 170 315 171 173 315 minecraft:packed_ice
setblock 172 170 277 minecraft:packed_ice
fill 172 170 313 172 172 313 minecraft:packed_ice
setblock 173 170 277 minecraft:snow_block
setblock 174 170 276 minecraft:snow_block
fill 174 170 277 174 173 277 minecraft:packed_ice
setblock 174 170 316 minecraft:snow_block
fill 175 170 276 175 173 276 minecraft:packed_ice
fill 175 170 295 175 171 297 minecraft:packed_ice
setblock 175 170 315 minecraft:snow_block
fill 175 170 316 175 173 316 minecraft:packed_ice
fill 176 170 277 177 170 277 minecraft:packed_ice
fill 176 170 294 176 171 294 minecraft:packed_ice
fill 176 170 315 176 171 315 minecraft:packed_ice
fill 177 170 293 178 171 293 minecraft:packed_ice
fill 177 170 299 179 171 299 minecraft:packed_ice
setblock 178 170 277 minecraft:snow_block
setblock 179 170 276 minecraft:snow_block
fill 179 170 277 180 172 277 minecraft:packed_ice
setblock 179 170 296 minecraft:snow_block
fill 179 170 297 179 171 297 minecraft:packed_ice
setblock 179 170 316 minecraft:snow_block
fill 180 170 276 180 173 276 minecraft:packed_ice
setblock 180 170 295 minecraft:snow_block
fill 180 170 296 180 172 296 minecraft:packed_ice
setblock 180 170 300 minecraft:snow_block
fill 180 170 301 180 173 301 minecraft:packed_ice
setblock 180 170 316 minecraft:packed_ice
setblock 181 170 294 minecraft:snow_block
fill 181 170 295 181 173 295 minecraft:packed_ice
setblock 181 170 299 minecraft:snow_block
fill 181 170 300 181 173 300 minecraft:packed_ice
setblock 182 170 277 minecraft:packed_ice
setblock 182 170 278 minecraft:snow_block
fill 182 170 279 182 173 279 minecraft:packed_ice
setblock 182 170 282 minecraft:packed_ice
setblock 182 170 283 minecraft:snow_block
fill 182 170 289 182 173 289 minecraft:packed_ice
setblock 182 170 293 minecraft:snow_block
fill 182 170 294 182 173 294 minecraft:packed_ice
setblock 182 170 298 minecraft:snow_block
fill 182 170 299 182 173 299 minecraft:packed_ice
setblock 182 170 303 minecraft:snow_block
setblock 183 170 277 minecraft:light_blue_concrete
fill 183 170 301 183 179 301 minecraft:blue_ice
fill 141 171 302 141 179 302 minecraft:blue_ice
setblock 142 171 276 minecraft:packed_ice
setblock 142 171 277 minecraft:snow_block
fill 142 171 278 142 174 278 minecraft:packed_ice
setblock 142 171 282 minecraft:snow_block
fill 142 171 283 142 174 283 minecraft:packed_ice
setblock 142 171 286 minecraft:packed_ice
setblock 142 171 293 minecraft:packed_ice
setblock 142 171 297 minecraft:snow_block
fill 142 171 298 142 174 298 minecraft:packed_ice
setblock 142 171 301 minecraft:packed_ice
setblock 143 171 276 minecraft:snow_block
fill 143 171 277 146 171 277 minecraft:packed_ice
setblock 143 171 280 minecraft:packed_ice
setblock 143 171 281 minecraft:snow_block
fill 143 171 282 143 174 282 minecraft:packed_ice
fill 144 171 276 147 171 276 minecraft:packed_ice
fill 145 171 316 147 171 316 minecraft:packed_ice
setblock 146 171 278 minecraft:snow_block
setblock 147 171 277 minecraft:snow_block
fill 147 171 278 147 174 278 minecraft:packed_ice
setblock 148 171 276 minecraft:snow_block
fill 148 171 277 148 174 277 minecraft:packed_ice
setblock 148 171 316 minecraft:snow_block
fill 149 171 276 149 174 276 minecraft:packed_ice
setblock 149 171 315 minecraft:snow_block
fill 149 171 316 149 174 316 minecraft:packed_ice
fill 150 171 315 150 174 315 minecraft:packed_ice
setblock 151 171 278 minecraft:snow_block
fill 151 171 279 152 173 279 minecraft:packed_ice
setblock 152 171 277 minecraft:snow_block
fill 152 171 278 152 174 278 minecraft:packed_ice
fill 152 171 314 152 173 314 minecraft:packed_ice
setblock 153 171 276 minecraft:snow_block
fill 153 171 277 153 174 277 minecraft:packed_ice
setblock 153 171 316 minecraft:snow_block
fill 154 171 276 154 174 276 minecraft:packed_ice
setblock 154 171 279 minecraft:packed_ice
setblock 154 171 315 minecraft:snow_block
fill 154 171 316 154 174 316 minecraft:packed_ice
setblock 155 171 279 minecraft:snow_block
setblock 155 171 314 minecraft:snow_block
fill 155 171 315 155 174 315 minecraft:packed_ice
setblock 156 171 278 minecraft:snow_block
fill 156 171 314 156 173 314 minecraft:packed_ice
fill 157 171 275 157 177 275 minecraft:blue_ice
setblock 157 171 277 minecraft:snow_block
fill 157 171 278 157 174 278 minecraft:packed_ice
setblock 158 171 275 minecraft:white_concrete
setblock 158 171 276 minecraft:snow_block
fill 158 171 277 158 174 277 minecraft:packed_ice
setblock 158 171 316 minecraft:snow_block
fill 159 171 276 159 174 276 minecraft:packed_ice
setblock 159 171 278 minecraft:packed_ice
setblock 159 171 315 minecraft:snow_block
fill 159 171 316 162 171 316 minecraft:packed_ice
fill 160 171 315 160 173 315 minecraft:packed_ice
setblock 163 171 276 minecraft:snow_block
setblock 163 171 316 minecraft:snow_block
fill 164 171 276 167 171 276 minecraft:packed_ice
fill 164 171 316 164 174 316 minecraft:packed_ice
setblock 168 171 276 minecraft:snow_block
setblock 168 171 316 minecraft:snow_block
fill 169 171 276 169 174 276 minecraft:packed_ice
fill 169 171 316 169 174 316 minecraft:packed_ice
fill 170 171 277 171 171 277 minecraft:packed_ice
setblock 172 171 277 minecraft:snow_block
setblock 173 171 276 minecraft:snow_block
fill 173 171 277 173 174 277 minecraft:packed_ice
setblock 173 171 316 minecraft:snow_block
fill 174 171 276 174 174 276 minecraft:packed_ice
fill 174 171 278 175 171 278 minecraft:packed_ice
setblock 174 171 315 minecraft:snow_block
fill 174 171 316 174 174 316 minecraft:packed_ice
setblock 175 171 294 minecraft:packed_ice
setblock 175 171 298 minecraft:packed_ice
fill 175 171 315 175 172 315 minecraft:packed_ice
setblock 176 171 277 minecraft:packed_ice
setblock 176 171 278 minecraft:snow_block
setblock 176 171 293 minecraft:packed_ice
setblock 176 171 299 minecraft:packed_ice
setblock 177 171 277 minecraft:snow_block
setblock 178 171 276 minecraft:snow_block
fill 178 171 277 178 174 277 minecraft:packed_ice
setblock 178 171 316 minecraft:snow_block
fill 179 171 276 179 174 276 minecraft:packed_ice
setblock 179 171 293 minecraft:packed_ice
setblock 179 171 296 minecraft:packed_ice
fill 179 171 316 179 172 316 minecraft:packed_ice
setblock 180 171 294 minecraft:snow_block
fill 180 171 295 180 172 295 minecraft:packed_ice
setblock 180 171 299 minecraft:snow_block
fill 180 171 300 180 173 300 minecraft:packed_ice
setblock 181 171 277 minecraft:packed_ice
setblock 181 171 278 minecraft:snow_block
fill 181 171 279 181 172 281 minecraft:packed_ice
setblock 181 171 293 minecraft:snow_block
fill 181 171 294 181 173 294 minecraft:packed_ice
setblock 181 171 298 minecraft:snow_block
fill 181 171 299 181 174 299 minecraft:packed_ice
setblock 182 171 277 minecraft:snow_block
fill 182 171 278 182 174 278 minecraft:packed_ice
setblock 182 171 282 minecraft:snow_block
fill 182 171 283 182 171 286 minecraft:packed_ice
setblock 182 171 287 minecraft:snow_block
fill 182 171 288 182 174 288 minecraft:packed_ice
setblock 182 171 292 minecraft:snow_block
fill 182 171 293 182 174 293 minecraft:packed_ice
setblock 182 171 297 minecraft:snow_block
fill 182 171 298 182 174 298 minecraft:packed_ice
setblock 182 171 302 minecraft:snow_block
fill 182 171 303 182 173 304 minecraft:packed_ice
fill 183 171 277 183 177 277 minecraft:blue_ice
setblock 142 172 276 minecraft:snow_block
fill 142 172 277 145 172 277 minecraft:packed_ice
setblock 142 172 281 minecraft:snow_block
fill 142 172 282 142 175 282 minecraft:packed_ice
setblock 142 172 286 minecraft:snow_block
setblock 142 172 296 minecraft:snow_block
fill 142 172 297 142 173 297 minecraft:packed_ice
setblock 142 172 301 minecraft:snow_block
fill 143 172 276 146 172 276 minecraft:packed_ice
setblock 143 172 280 minecraft:snow_block
fill 143 172 281 143 175 281 minecraft:packed_ice
fill 143 172 283 143 173 283 minecraft:packed_ice
setblock 144 172 278 minecraft:packed_ice
setblock 144 172 279 minecraft:snow_block
setblock 144 172 285 minecraft:light[level=12]
setblock 144 172 286 minecraft:light[level=15]
setblock 144 172 292 minecraft:light[level=12]
setblock 144 172 294 minecraft:light[level=15]
setblock 144 172 299 minecraft:light[level=12]
setblock 144 172 302 minecraft:light[level=15]
setblock 144 172 306 minecraft:light[level=12]
setblock 144 172 310 minecraft:light[level=15]
setblock 144 172 313 minecraft:light[level=12]
fill 144 172 316 146 172 316 minecraft:packed_ice
setblock 145 172 278 minecraft:snow_block
setblock 146 172 277 minecraft:snow_block
fill 146 172 278 146 175 278 minecraft:packed_ice
setblock 147 172 276 minecraft:snow_block
fill 147 172 277 147 175 277 minecraft:packed_ice
setblock 147 172 316 minecraft:snow_block
fill 148 172 276 148 175 276 minecraft:packed_ice
fill 148 172 316 148 175 316 minecraft:packed_ice
setblock 149 172 279 minecraft:snow_block
fill 149 172 315 149 175 315 minecraft:packed_ice
setblock 150 172 277 minecraft:packed_ice
setblock 150 172 278 minecraft:snow_block
fill 150 172 279 150 175 279 minecraft:packed_ice
setblock 151 172 277 minecraft:snow_block
fill 151 172 278 151 175 278 minecraft:packed_ice
setblock 151 172 285 minecraft:light[level=12]
setblock 151 172 292 minecraft:light[level=12]
setblock 151 172 299 minecraft:light[level=12]
setblock 151 172 306 minecraft:light[level=12]
setblock 151 172 313 minecraft:light[level=12]
setblock 152 172 276 minecraft:snow_block
fill 152 172 277 152 175 277 minecraft:packed_ice
setblock 152 172 286 minecraft:light[level=15]
setblock 152 172 294 minecraft:light[level=15]
setblock 152 172 302 minecraft:light[level=15]
setblock 152 172 310 minecraft:light[level=15]
setblock 152 172 316 minecraft:snow_block
fill 153 172 276 153 175 276 minecraft:packed_ice
setblock 153 172 315 minecraft:snow_block
fill 153 172 316 153 175 316 minecraft:packed_ice
setblock 154 172 279 minecraft:snow_block
setblock 154 172 314 minecraft:snow_block
fill 154 172 315 154 175 315 minecraft:packed_ice
setblock 155 172 278 minecraft:snow_block
fill 155 172 279 156 172 279 minecraft:packed_ice
fill 155 172 314 155 174 314 minecraft:packed_ice
setblock 156 172 277 minecraft:snow_block
fill 156 172 278 156 175 278 minecraft:packed_ice
setblock 157 172 276 minecraft:snow_block
fill 157 172 277 157 175 277 minecraft:packed_ice
setblock 157 172 316 minecraft:snow_block
fill 158 172 275 158 175 275 minecraft:blue_ice
fill 158 172 276 158 175 276 minecraft:packed_ice
setblock 158 172 285 minecraft:light[level=12]
setblock 158 172 292 minecraft:light[level=12]
setblock 158 172 299 minecraft:light[level=12]
setblock 158 172 306 minecraft:light[level=12]
setblock 158 172 313 minecraft:light[level=12]
setblock 158 172 315 minecraft:snow_block
fill 158 172 316 161 172 316 minecraft:packed_ice
fill 159 172 315 159 174 315 minecraft:packed_ice
setblock 160 172 278 minecraft:light[level=15]
setblock 160 172 286 minecraft:light[level=15]
setblock 160 172 294 minecraft:light[level=15]
setblock 160 172 302 minecraft:light[level=15]
setblock 160 172 310 minecraft:light[level=15]
setblock 161 172 277 minecraft:snow_block
setblock 162 172 276 minecraft:snow_block
setblock 162 172 316 minecraft:snow_block
fill 163 172 276 166 172 276 minecraft:packed_ice
fill 163 172 316 163 174 316 minecraft:packed_ice
setblock 165 172 278 minecraft:light[level=12]
setblock 165 172 285 minecraft:light[level=12]
setblock 165 172 292 minecraft:light[level=12]
setblock 165 172 299 minecraft:light[level=12]
setblock 165 172 306 minecraft:light[level=12]
setblock 165 172 313 minecraft:light[level=12]
setblock 167 172 276 minecraft:snow_block
setblock 167 172 316 minecraft:snow_block
fill 168 172 276 168 175 276 minecraft:packed_ice
setblock 168 172 278 minecraft:light[level=15]
setblock 168 172 286 minecraft:light[level=15]
setblock 168 172 294 minecraft:light[level=15]
setblock 168 172 302 minecraft:light[level=15]
setblock 168 172 310 minecraft:light[level=15]
fill 168 172 316 168 175 316 minecraft:packed_ice
fill 169 172 277 170 172 277 minecraft:packed_ice
setblock 169 172 314 minecraft:packed_ice
setblock 171 172 277 minecraft:snow_block
setblock 171 172 312 minecraft:packed_ice
setblock 172 172 276 minecraft:snow_block
fill 172 172 277 172 175 277 minecraft:packed_ice
setblock 172 172 278 minecraft:light[level=12]
setblock 172 172 285 minecraft:light[level=12]
setblock 172 172 292 minecraft:light[level=12]
setblock 172 172 299 minecraft:light[level=12]
setblock 172 172 306 minecraft:light[level=12]
setblock 172 172 316 minecraft:snow_block
fill 173 172 276 173 175 276 minecraft:packed_ice
fill 173 172 278 174 172 278 minecraft:packed_ice
setblock 173 172 314 minecraft:packed_ice
setblock 173 172 315 minecraft:snow_block
fill 173 172 316 173 175 316 minecraft:packed_ice
fill 174 172 315 174 173 315 minecraft:packed_ice
setblock 175 172 278 minecraft:snow_block
setblock 176 172 277 minecraft:snow_block
fill 176 172 278 177 173 278 minecraft:packed_ice
setblock 176 172 286 minecraft:light[level=15]
setblock 176 172 294 minecraft:light[level=15]
setblock 176 172 302 minecraft:light[level=15]
setblock 177 172 276 minecraft:snow_block
fill 177 172 277 177 175 277 minecraft:packed_ice
fill 177 172 296 178 172 297 minecraft:blue_ice
fill 177 172 307 177 180 307 minecraft:packed_ice
setblock 177 172 316 minecraft:snow_block
fill 178 172 276 178 175 276 minecraft:packed_ice
setblock 178 172 295 minecraft:blue_ice
fill 178 172 316 178 173 316 minecraft:packed_ice
setblock 179 172 278 minecraft:light[level=12]
setblock 179 172 285 minecraft:light[level=12]
setblock 179 172 292 minecraft:light[level=12]
setblock 179 172 296 minecraft:blue_ice
setblock 179 172 299 minecraft:light[level=12]
setblock 179 172 306 minecraft:light[level=12]
setblock 179 172 313 minecraft:light[level=12]
setblock 180 172 298 minecraft:snow_block
fill 180 172 299 180 173 299 minecraft:packed_ice
setblock 181 172 277 minecraft:snow_block
fill 181 172 278 181 175 278 minecraft:packed_ice
setblock 181 172 282 minecraft:snow_block
fill 181 172 283 182 174 283 minecraft:packed_ice
setblock 181 172 293 minecraft:packed_ice
setblock 181 172 297 minecraft:snow_block
fill 181 172 298 181 175 298 minecraft:packed_ice
setblock 181 172 301 minecraft:packed_ice
setblock 181 172 302 minecraft:snow_block
fill 181 172 303 181 174 303 minecraft:packed_ice
setblock 182 172 276 minecraft:snow_block
fill 182 172 277 182 175 277 minecraft:packed_ice
setblock 182 172 280 minecraft:packed_ice
setblock 182 172 281 minecraft:snow_block
fill 182 172 282 182 175 282 minecraft:packed_ice
fill 182 172 284 182 172 285 minecraft:packed_ice
setblock 182 172 286 minecraft:snow_block
fill 182 172 287 182 175 287 minecraft:packed_ice
setblock 182 172 291 minecraft:snow_block
fill 182 172 292 182 174 292 minecraft:packed_ice
setblock 182 172 296 minecraft:snow_block
fill 182 172 297 182 175 297 minecraft:packed_ice
setblock 182 172 301 minecraft:snow_block
fill 182 172 302 182 175 302 minecraft:packed_ice
setblock 183 172 285 minecraft:light_blue_concrete
fill 142 173 276 144 173 277 minecraft:packed_ice
setblock 142 173 280 minecraft:snow_block
fill 142 173 281 142 176 281 minecraft:packed_ice
setblock 142 173 284 minecraft:packed_ice
setblock 142 173 285 minecraft:snow_block
fill 142 173 286 142 175 287 minecraft:packed_ice
setblock 142 173 296 minecraft:packed_ice
setblock 142 173 300 minecraft:snow_block
fill 142 173 301 142 174 302 minecraft:packed_ice
setblock 143 173 279 minecraft:snow_block
fill 143 173 280 144 175 280 minecraft:packed_ice
setblock 144 173 278 minecraft:snow_block
fill 144 173 279 144 176 279 minecraft:packed_ice
fill 144 173 316 145 173 316 minecraft:packed_ice
setblock 145 173 276 minecraft:packed_ice
setblock 145 173 277 minecraft:snow_block
fill 145 173 278 145 176 278 minecraft:packed_ice
setblock 146 173 276 minecraft:snow_block
fill 146 173 277 146 176 277 minecraft:packed_ice
setblock 146 173 316 minecraft:snow_block
fill 147 173 276 147 176 276 minecraft:packed_ice
fill 147 173 316 147 176 316 minecraft:packed_ice
setblock 148 173 278 minecraft:packed_ice
setblock 148 173 279 minecraft:snow_block
fill 148 173 315 148 176 315 minecraft:packed_ice
setblock 149 173 278 minecraft:snow_block
fill 149 173 279 149 176 279 minecraft:packed_ice
setblock 150 173 277 minecraft:snow_block
fill 150 173 278 150 176 278 minecraft:packed_ice
setblock 151 173 276 minecraft:snow_block
fill 151 173 277 151 176 277 minecraft:packed_ice
fill 151 173 314 151 174 314 minecraft:packed_ice
setblock 151 173 316 minecraft:snow_block
fill 152 173 276 152 176 276 minecraft:packed_ice
setblock 152 173 315 minecraft:snow_block
fill 152 173 316 152 176 316 minecraft:packed_ice
setblock 153 173 278 minecraft:packed_ice
setblock 153 173 279 minecraft:snow_block
setblock 153 173 314 minecraft:snow_block
fill 153 173 315 153 176 315 minecraft:packed_ice
setblock 154 173 278 minecraft:snow_block
fill 154 173 279 155 174 279 minecraft:packed_ice
fill 154 173 314 154 175 314 minecraft:packed_ice
setblock 155 173 277 minecraft:snow_block
fill 155 173 278 155 176 278 minecraft:packed_ice
setblock 156 173 276 minecraft:snow_block
fill 156 173 277 156 176 277 minecraft:packed_ice
setblock 156 173 316 minecraft:snow_block
fill 157 173 276 157 176 276 minecraft:packed_ice
setblock 157 173 315 minecraft:snow_block
fill 157 173 316 160 173 316 minecraft:packed_ice
fill 158 173 315 158 174 315 minecraft:packed_ice
setblock 160 173 277 minecraft:snow_block
setblock 161 173 276 minecraft:snow_block
fill 161 173 315 163 176 315 minecraft:blue_ice
setblock 161 173 316 minecraft:snow_block
fill 162 173 276 165 173 276 minecraft:packed_ice
fill 162 173 314 162 176 314 minecraft:blue_ice
fill 162 173 316 162 174 316 minecraft:packed_ice
fill 164 173 285 166 174 285 minecraft:white_concrete
fill 165 173 284 165 174 284 minecraft:white_concrete
fill 165 173 286 165 174 286 minecraft:white_concrete
setblock 166 173 276 minecraft:snow_block
setblock 166 173 316 minecraft:snow_block
fill 167 173 276 167 176 276 minecraft:packed_ice
fill 167 173 316 167 175 316 minecraft:packed_ice
setblock 169 173 277 minecraft:packed_ice
setblock 170 173 277 minecraft:snow_block
setblock 171 173 276 minecraft:snow_block
fill 171 173 277 171 176 277 minecraft:packed_ice
setblock 171 173 316 minecraft:snow_block
fill 172 173 276 172 176 276 minecraft:packed_ice
fill 172 173 278 173 173 278 minecraft:packed_ice
setblock 172 173 315 minecraft:snow_block
fill 172 173 316 172 176 316 minecraft:packed_ice
setblock 173 173 275 minecraft:light_blue_concrete
setblock 173 173 315 minecraft:packed_ice
setblock 174 173 278 minecraft:snow_block
setblock 175 173 277 minecraft:snow_block
fill 175 173 278 175 175 278 minecraft:packed_ice
setblock 176 173 276 minecraft:snow_block
fill 176 173 277 176 176 277 minecraft:packed_ice
setblock 176 173 316 minecraft:snow_block
fill 177 173 276 177 176 276 minecraft:packed_ice
fill 177 173 296 178 173 296 minecraft:blue_ice
fill 177 173 316 177 174 316 minecraft:packed_ice
setblock 178 173 297 minecraft:blue_ice
setblock 179 173 277 minecraft:packed_ice
setblock 180 173 277 minecraft:snow_block
setblock 180 173 297 minecraft:snow_block
setblock 180 173 298 minecraft:packed_ice
setblock 181 173 276 minecraft:snow_block
fill 181 173 277 181 174 277 minecraft:packed_ice
fill 181 173 279 181 173 280 minecraft:packed_ice
setblock 181 173 281 minecraft:snow_block
fill 181 173 282 181 176 282 minecraft:packed_ice
fill 181 173 284 182 173 284 minecraft:packed_ice
setblock 181 173 296 minecraft:snow_block
fill 181 173 297 181 174 297 minecraft:packed_ice
setblock 181 173 301 minecraft:snow_block
fill 181 173 302 181 175 302 minecraft:packed_ice
fill 182 173 276 182 176 276 minecraft:packed_ice
setblock 182 173 280 minecraft:snow_block
fill 182 173 281 182 176 281 minecraft:packed_ice
setblock 182 173 285 minecraft:snow_block
fill 182 173 286 182 176 286 minecraft:packed_ice
setblock 182 173 290 minecraft:snow_block
fill 182 173 291 182 174 291 minecraft:packed_ice
setblock 182 173 295 minecraft:snow_block
fill 182 173 296 182 175 296 minecraft:packed_ice
setblock 182 173 300 minecraft:snow_block
fill 182 173 301 182 176 301 minecraft:packed_ice
fill 183 173 285 183 176 285 minecraft:blue_ice
fill 142 174 276 143 174 277 minecraft:packed_ice
setblock 142 174 279 minecraft:snow_block
fill 142 174 280 142 177 280 minecraft:packed_ice
setblock 142 174 284 minecraft:snow_block
fill 142 174 285 142 177 285 minecraft:packed_ice
setblock 142 174 299 minecraft:snow_block
setblock 142 174 300 minecraft:packed_ice
setblock 143 174 278 minecraft:snow_block
fill 143 174 279 143 177 279 minecraft:packed_ice
setblock 143 174 283 minecraft:snow_block
fill 143 174 284 143 177 284 minecraft:packed_ice
setblock 144 174 276 minecraft:packed_ice
setblock 144 174 277 minecraft:snow_block
fill 144 174 278 144 175 278 minecraft:packed_ice
setblock 144 174 281 minecraft:packed_ice
setblock 145 174 276 minecraft:snow_block
fill 145 174 277 145 177 277 minecraft:packed_ice
setblock 145 174 316 minecraft:snow_block
fill 146 174 276 146 177 276 minecraft:packed_ice
fill 146 174 316 146 177 316 minecraft:packed_ice
setblock 147 174 279 minecraft:snow_block
setblock 148 174 278 minecraft:snow_block
fill 148 174 279 148 180 279 minecraft:packed_ice
setblock 149 174 277 minecraft:snow_block
fill 149 174 278 149 177 278 minecraft:packed_ice
setblock 150 174 276 minecraft:snow_block
fill 150 174 277 150 177 277 minecraft:packed_ice
setblock 150 174 316 minecraft:snow_block
fill 151 174 276 151 177 276 minecraft:packed_ice
setblock 151 174 279 minecraft:packed_ice
fill 151 174 300 151 175 300 minecraft:blue_ice
setblock 151 174 315 minecraft:snow_block
fill 151 174 316 151 177 316 minecraft:packed_ice
setblock 152 174 279 minecraft:snow_block
setblock 152 174 314 minecraft:snow_block
fill 152 174 315 152 177 315 minecraft:packed_ice
setblock 153 174 278 minecraft:snow_block
fill 153 174 279 153 176 279 minecraft:packed_ice
fill 153 174 314 153 175 314 minecraft:packed_ice
setblock 154 174 277 minecraft:snow_block
fill 154 174 278 154 176 278 minecraft:packed_ice
setblock 155 174 276 minecraft:snow_block
fill 155 174 277 155 177 277 minecraft:packed_ice
setblock 155 174 316 minecraft:snow_block
fill 156 174 276 156 177 276 minecraft:packed_ice
setblock 156 174 315 minecraft:snow_block
fill 156 174 316 159 174 316 minecraft:packed_ice
fill 157 174 315 157 175 315 minecraft:packed_ice
setblock 159 174 277 minecraft:snow_block
setblock 160 174 276 minecraft:snow_block
setblock 160 174 316 minecraft:snow_block
fill 161 174 276 164 174 276 minecraft:packed_ice
fill 161 174 313 161 176 314 minecraft:blue_ice
fill 161 174 316 161 175 316 minecraft:packed_ice
fill 162 174 312 162 176 313 minecraft:blue_ice
fill 163 174 313 163 176 314 minecraft:blue_ice
setblock 165 174 276 minecraft:snow_block
setblock 165 174 316 minecraft:snow_block
fill 166 174 276 166 175 276 minecraft:packed_ice
fill 166 174 316 166 175 316 minecraft:packed_ice
setblock 169 174 277 minecraft:snow_block
setblock 170 174 276 minecraft:snow_block
fill 170 174 277 170 176 277 minecraft:packed_ice
setblock 170 174 316 minecraft:snow_block
fill 171 174 276 171 177 276 minecraft:packed_ice
fill 171 174 278 172 174 278 minecraft:packed_ice
fill 171 174 316 171 177 316 minecraft:packed_ice
setblock 172 174 275 minecraft:light_blue_concrete
setblock 172 174 315 minecraft:packed_ice
fill 173 174 275 173 179 275 minecraft:blue_ice
setblock 173 174 278 minecraft:snow_block
setblock 174 174 277 minecraft:snow_block
fill 174 174 278 174 175 278 minecraft:packed_ice
setblock 175 174 276 minecraft:snow_block
fill 175 174 277 175 176 277 minecraft:packed_ice
setblock 175 174 316 minecraft:snow_block
fill 176 174 276 176 177 276 minecraft:packed_ice
setblock 176 174 278 minecraft:packed_ice
setblock 176 174 316 minecraft:packed_ice
fill 178 174 296 178 176 296 minecraft:blue_ice
setblock 179 174 277 minecraft:snow_block
setblock 180 174 276 minecraft:snow_block
setblock 180 174 277 minecraft:packed_ice
fill 181 174 276 181 175 276 minecraft:packed_ice
setblock 181 174 279 minecraft:packed_ice
setblock 181 174 280 minecraft:snow_block
fill 181 174 281 181 177 281 minecraft:packed_ice
setblock 181 174 284 minecraft:packed_ice
setblock 181 174 285 minecraft:snow_block
setblock 181 174 296 minecraft:packed_ice
setblock 181 174 300 minecraft:snow_block
fill 181 174 301 181 175 301 minecraft:packed_ice
setblock 182 174 279 minecraft:snow_block
fill 182 174 280 182 177 280 minecraft:packed_ice
setblock 182 174 284 minecraft:snow_block
fill 182 174 285 182 177 285 minecraft:packed_ice
setblock 182 174 289 minecraft:snow_block
setblock 182 174 290 minecraft:packed_ice
setblock 182 174 294 minecraft:snow_block
fill 182 174 295 182 175 295 minecraft:packed_ice
setblock 182 174 299 minecraft:snow_block
fill 182 174 300 182 177 300 minecraft:packed_ice
setblock 182 174 303 minecraft:packed_ice
setblock 182 174 304 minecraft:snow_block
fill 142 175 276 142 175 277 minecraft:packed_ice
setblock 142 175 278 minecraft:snow_block
fill 142 175 279 142 178 279 minecraft:packed_ice
setblock 142 175 283 minecraft:snow_block
fill 142 175 284 142 178 284 minecraft:packed_ice
setblock 142 175 301 minecraft:packed_ice
setblock 143 175 276 minecraft:packed_ice
setblock 143 175 277 minecraft:snow_block
fill 143 175 278 143 178 278 minecraft:packed_ice
setblock 143 175 282 minecraft:snow_block
fill 143 175 283 143 178 283 minecraft:packed_ice
setblock 144 175 276 minecraft:snow_block
fill 144 175 277 144 178 277 minecraft:packed_ice
setblock 144 175 281 minecraft:snow_block
fill 144 175 282 144 182 282 minecraft:packed_ice
fill 145 175 276 145 178 276 minecraft:packed_ice
fill 145 175 316 145 176 316 minecraft:packed_ice
setblock 147 175 278 minecraft:snow_block
setblock 147 175 279 minecraft:packed_ice
setblock 148 175 277 minecraft:snow_block
fill 148 175 278 148 180 278 minecraft:packed_ice
setblock 149 175 276 minecraft:snow_block
fill 149 175 277 149 178 277 minecraft:packed_ice
setblock 149 175 316 minecraft:snow_block
fill 150 175 276 150 178 276 minecraft:packed_ice
setblock 150 175 315 minecraft:snow_block
fill 150 175 316 150 178 316 minecraft:packed_ice
fill 151 175 275 151 179 275 minecraft:blue_ice
setblock 151 175 279 minecraft:snow_block
fill 151 175 315 151 178 315 minecraft:packed_ice
setblock 152 175 275 minecraft:light_blue_concrete
setblock 152 175 278 minecraft:snow_block
fill 152 175 279 152 176 279 minecraft:packed_ice
setblock 152 175 314 minecraft:packed_ice
setblock 153 175 277 minecraft:snow_block
fill 153 175 278 153 177 278 minecraft:packed_ice
setblock 154 175 276 minecraft:snow_block
fill 154 175 277 154 178 277 minecraft:packed_ice
setblock 154 175 279 minecraft:packed_ice
setblock 154 175 316 minecraft:snow_block
fill 155 175 276 155 178 276 minecraft:packed_ice
setblock 155 175 315 minecraft:snow_block
fill 155 175 316 158 175 316 minecraft:packed_ice
fill 156 175 279 156 176 280 minecraft:blue_ice
fill 156 175 315 156 176 315 minecraft:packed_ice
setblock 157 175 278 minecraft:blue_ice
setblock 158 175 277 minecraft:snow_block
setblock 159 175 276 minecraft:snow_block
setblock 159 175 316 minecraft:snow_block
fill 160 175 276 161 175 276 minecraft:packed_ice
setblock 160 175 316 minecraft:packed_ice
setblock 160 175 317 minecraft:light_blue_concrete
fill 161 175 312 161 176 312 minecraft:blue_ice
fill 162 175 310 162 176 311 minecraft:blue_ice
fill 162 175 316 163 175 316 minecraft:blue_ice
fill 163 175 312 163 176 312 minecraft:blue_ice
setblock 169 175 276 minecraft:snow_block
setblock 169 175 277 minecraft:packed_ice
setblock 169 175 316 minecraft:snow_block
fill 170 175 276 170 178 276 minecraft:packed_ice
fill 170 175 316 170 177 316 minecraft:packed_ice
fill 172 175 275 172 179 275 minecraft:blue_ice
setblock 172 175 278 minecraft:snow_block
setblock 173 175 277 minecraft:snow_block
setblock 173 175 278 minecraft:packed_ice
setblock 174 175 276 minecraft:snow_block
fill 174 175 277 174 176 277 minecraft:packed_ice
setblock 174 175 316 minecraft:snow_block
fill 175 175 276 175 177 276 minecraft:packed_ice
setblock 175 175 316 minecraft:packed_ice
setblock 178 175 277 minecraft:snow_block
setblock 179 175 276 minecraft:snow_block
setblock 180 175 276 minecraft:packed_ice
setblock 181 175 279 minecraft:snow_block
fill 181 175 280 181 177 280 minecraft:packed_ice
setblock 181 175 283 minecraft:packed_ice
setblock 181 175 284 minecraft:snow_block
fill 181 175 285 181 178 285 minecraft:packed_ice
setblock 181 175 299 minecraft:snow_block
setblock 181 175 300 minecraft:packed_ice
setblock 182 175 278 minecraft:snow_block
fill 182 175 279 182 178 279 minecraft:packed_ice
setblock 182 175 283 minecraft:snow_block
fill 182 175 284 182 178 284 minecraft:packed_ice
setblock 182 175 288 minecraft:snow_block
fill 182 175 289 182 176 289 minecraft:packed_ice
setblock 182 175 294 minecraft:packed_ice
setblock 182 175 298 minecraft:snow_block
fill 182 175 299 182 176 299 minecraft:packed_ice
setblock 182 175 303 minecraft:snow_block
fill 182 175 304 182 176 304 minecraft:packed_ice
setblock 183 175 278 minecraft:white_concrete
setblock 183 175 279 minecraft:light_blue_concrete
setblock 183 175 310 minecraft:white_concrete
setblock 141 176 279 minecraft:packed_ice
fill 141 176 287 141 177 287 minecraft:packed_ice
setblock 141 176 290 minecraft:packed_ice
setblock 141 176 305 minecraft:packed_ice
fill 142 176 275 142 176 276 minecraft:packed_ice
setblock 142 176 277 minecraft:snow_block
fill 142 176 278 142 179 278 minecraft:packed_ice
setblock 142 176 282 minecraft:snow_block
fill 142 176 283 142 179 283 minecraft:packed_ice
setblock 142 176 286 minecraft:packed_ice
setblock 142 176 287 minecraft:snow_block
setblock 142 176 317 minecraft:packed_ice
setblock 143 176 276 minecraft:snow_block
fill 143 176 277 143 177 277 minecraft:packed_ice
setblock 143 176 280 minecraft:packed_ice
setblock 143 176 281 minecraft:snow_block
fill 143 176 282 143 179 282 minecraft:packed_ice
fill 143 176 317 145 177 317 minecraft:blue_ice
fill 144 176 276 144 179 276 minecraft:packed_ice
setblock 144 176 280 minecraft:snow_block
fill 144 176 281 144 177 281 minecraft:packed_ice
setblock 146 176 278 minecraft:snow_block
setblock 146 176 317 minecraft:packed_ice
setblock 147 176 277 minecraft:snow_block
fill 147 176 278 147 178 278 minecraft:packed_ice
setblock 148 176 276 minecraft:snow_block
fill 148 176 277 148 179 277 minecraft:packed_ice
setblock 148 176 316 minecraft:snow_block
fill 149 176 276 149 179 276 minecraft:packed_ice
setblock 149 176 315 minecraft:snow_block
fill 149 176 316 149 179 316 minecraft:packed_ice
setblock 150 176 279 minecraft:snow_block
fill 150 176 315 150 179 315 minecraft:packed_ice
setblock 151 176 278 minecraft:snow_block
setblock 151 176 279 minecraft:packed_ice
fill 151 176 300 151 185 300 minecraft:packed_ice
fill 152 176 275 152 179 275 minecraft:blue_ice
setblock 152 176 277 minecraft:snow_block
fill 152 176 278 152 178 278 minecraft:packed_ice
setblock 153 176 276 minecraft:snow_block
fill 153 176 277 153 178 277 minecraft:packed_ice
setblock 153 176 316 minecraft:snow_block
setblock 153 176 317 minecraft:packed_ice
fill 154 176 276 154 179 276 minecraft:packed_ice
setblock 154 176 315 minecraft:snow_block
fill 154 176 316 157 176 316 minecraft:packed_ice
fill 155 176 315 155 177 315 minecraft:packed_ice
setblock 156 176 278 minecraft:blue_ice
fill 156 176 281 156 177 281 minecraft:blue_ice
setblock 157 176 277 minecraft:snow_block
fill 158 176 275 159 176 275 minecraft:packed_ice
setblock 158 176 276 minecraft:snow_block
setblock 158 176 316 minecraft:snow_block
setblock 159 176 276 minecraft:packed_ice
setblock 159 176 316 minecraft:packed_ice
fill 160 176 317 160 179 317 minecraft:blue_ice
setblock 161 176 311 minecraft:blue_ice
setblock 162 176 309 minecraft:blue_ice
setblock 162 176 316 minecraft:blue_ice
setblock 162 176 317 minecraft:packed_ice
setblock 163 176 311 minecraft:blue_ice
fill 163 176 317 164 179 317 minecraft:blue_ice
setblock 164 176 275 minecraft:packed_ice
setblock 168 176 276 minecraft:snow_block
setblock 168 176 316 minecraft:snow_block
fill 169 176 275 169 179 275 minecraft:blue_ice
fill 169 176 276 169 178 276 minecraft:packed_ice
fill 169 176 316 169 177 316 minecraft:packed_ice
setblock 170 176 275 minecraft:packed_ice
setblock 172 176 277 minecraft:snow_block
setblock 173 176 276 minecraft:snow_block
fill 173 176 277 173 177 277 minecraft:packed_ice
setblock 173 176 316 minecraft:snow_block
fill 174 176 276 174 177 276 minecraft:packed_ice
fill 176 176 307 176 180 307 minecraft:packed_ice
fill 177 176 306 177 180 306 minecraft:packed_ice
fill 177 176 308 177 180 308 minecraft:packed_ice
setblock 178 176 276 minecraft:snow_block
fill 178 176 307 178 180 307 minecraft:packed_ice
fill 179 176 275 179 176 276 minecraft:packed_ice
setblock 181 176 279 minecraft:packed_ice
setblock 181 176 283 minecraft:snow_block
fill 181 176 284 181 179 284 minecraft:packed_ice
setblock 182 176 277 minecraft:snow_block
fill 182 176 278 182 179 278 minecraft:packed_ice
setblock 182 176 282 minecraft:snow_block
fill 182 176 283 182 179 283 minecraft:packed_ice
setblock 182 176 287 minecraft:snow_block
fill 182 176 288 182 179 288 minecraft:packed_ice
setblock 182 176 297 minecraft:snow_block
setblock 182 176 298 minecraft:packed_ice
setblock 182 176 302 minecraft:snow_block
fill 182 176 303 182 177 303 minecraft:packed_ice
fill 183 176 275 183 176 276 minecraft:packed_ice
fill 183 176 278 183 179 279 minecraft:blue_ice
setblock 183 176 287 minecraft:packed_ice
fill 183 176 310 183 179 311 minecraft:blue_ice
setblock 183 176 312 minecraft:packed_ice
fill 183 176 313 183 178 313 minecraft:blue_ice
setblock 183 176 316 minecraft:packed_ice
fill 183 176 317 183 177 317 minecraft:blue_ice
setblock 141 177 275 minecraft:packed_ice
fill 141 177 276 141 179 277 minecraft:blue_ice
fill 141 177 279 141 179 279 minecraft:blue_ice
setblock 141 177 280 minecraft:packed_ice
fill 141 177 290 141 179 290 minecraft:blue_ice
setblock 141 177 305 minecraft:blue_ice
setblock 141 177 308 minecraft:white_concrete
fill 142 177 275 142 179 275 minecraft:blue_ice
setblock 142 177 276 minecraft:snow_block
fill 142 177 277 142 180 277 minecraft:packed_ice
setblock 142 177 281 minecraft:snow_block
fill 142 177 282 142 180 282 minecraft:packed_ice
setblock 142 177 286 minecraft:snow_block
fill 142 177 287 142 180 287 minecraft:packed_ice
fill 142 177 317 142 179 317 minecraft:blue_ice
fill 143 177 276 143 180 276 minecraft:packed_ice
setblock 143 177 280 minecraft:snow_block
fill 143 177 281 143 180 281 minecraft:packed_ice
setblock 146 177 277 minecraft:snow_block
setblock 146 177 278 minecraft:packed_ice
fill 146 177 317 146 181 317 minecraft:blue_ice
setblock 147 177 276 minecraft:snow_block
fill 147 177 277 147 180 277 minecraft:packed_ice
setblock 147 177 316 minecraft:snow_block
setblock 147 177 317 minecraft:packed_ice
fill 148 177 276 148 180 276 minecraft:packed_ice
setblock 148 177 315 minecraft:snow_block
fill 148 177 316 148 180 316 minecraft:packed_ice
fill 149 177 315 149 180 315 minecraft:packed_ice
setblock 150 177 278 minecraft:snow_block
setblock 150 177 279 minecraft:packed_ice
fill 150 177 300 150 185 300 minecraft:packed_ice
setblock 151 177 277 minecraft:snow_block
fill 151 177 278 151 178 278 minecraft:packed_ice
setblock 152 177 276 minecraft:snow_block
fill 152 177 277 152 179 277 minecraft:packed_ice
setblock 152 177 316 minecraft:snow_block
fill 153 177 276 153 180 276 minecraft:packed_ice
setblock 153 177 315 minecraft:snow_block
fill 153 177 316 156 177 316 minecraft:packed_ice
fill 153 177 317 153 179 317 minecraft:blue_ice
setblock 154 177 315 minecraft:packed_ice
setblock 156 177 282 minecraft:blue_ice
setblock 157 177 276 minecraft:snow_block
setblock 157 177 316 minecraft:snow_block
fill 158 177 275 159 179 275 minecraft:blue_ice
fill 162 177 317 162 179 317 minecraft:blue_ice
setblock 163 177 275 minecraft:white_concrete
fill 164 177 275 164 180 275 minecraft:blue_ice
fill 164 177 303 165 178 304 minecraft:snow_block
setblock 166 177 317 minecraft:packed_ice
fill 167 177 317 168 179 317 minecraft:blue_ice
fill 168 177 275 168 177 276 minecraft:packed_ice
fill 170 177 275 170 179 275 minecraft:blue_ice
setblock 171 177 277 minecraft:snow_block
setblock 172 177 276 minecraft:snow_block
setblock 172 177 277 minecraft:packed_ice
fill 173 177 276 173 178 276 minecraft:packed_ice
setblock 174 177 275 minecraft:packed_ice
fill 174 177 317 175 177 317 minecraft:packed_ice
setblock 177 177 317 minecraft:white_concrete
setblock 179 177 275 minecraft:packed_ice
setblock 181 177 282 minecraft:snow_block
fill 181 177 283 181 180 283 minecraft:packed_ice
setblock 182 177 277 minecraft:packed_ice
setblock 182 177 281 minecraft:snow_block
fill 182 177 282 182 180 282 minecraft:packed_ice
setblock 182 177 286 minecraft:snow_block
fill 182 177 287 182 180 287 minecraft:packed_ice
setblock 182 177 301 minecraft:snow_block
setblock 182 177 302 minecraft:packed_ice
setblock 183 177 275 minecraft:packed_ice
fill 183 177 276 183 179 276 minecraft:blue_ice
setblock 183 177 285 minecraft:light_blue_concrete
fill 183 177 287 183 179 287 minecraft:blue_ice
setblock 183 177 289 minecraft:packed_ice
setblock 183 177 295 minecraft:packed_ice
fill 183 177 296 183 178 297 minecraft:blue_ice
fill 183 177 304 183 178 304 minecraft:packed_ice
setblock 183 177 306 minecraft:packed_ice
fill 183 177 312 183 179 312 minecraft:blue_ice
fill 183 177 316 183 178 316 minecraft:blue_ice
fill 141 178 275 141 179 275 minecraft:blue_ice
fill 141 178 280 141 179 280 minecraft:blue_ice
setblock 141 178 283 minecraft:packed_ice
fill 141 178 287 141 179 287 minecraft:blue_ice
setblock 141 178 301 minecraft:light_blue_concrete
fill 141 178 303 141 179 303 minecraft:blue_ice
fill 141 178 304 141 178 305 minecraft:packed_ice
fill 141 178 308 141 179 308 minecraft:blue_ice
setblock 141 178 310 minecraft:packed_ice
fill 142 178 276 142 179 276 minecraft:packed_ice
setblock 142 178 280 minecraft:snow_block
fill 142 178 281 142 181 281 minecraft:packed_ice
setblock 142 178 285 minecraft:snow_block
fill 142 178 286 142 181 286 minecraft:packed_ice
setblock 143 178 279 minecraft:snow_block
fill 143 178 280 143 181 280 minecraft:packed_ice
setblock 143 178 284 minecraft:snow_block
fill 143 178 317 144 179 317 minecraft:blue_ice
setblock 144 178 278 minecraft:light[level=12]
setblock 144 178 285 minecraft:light[level=12]
setblock 144 178 292 minecraft:light[level=12]
setblock 144 178 299 minecraft:light[level=12]
setblock 144 178 306 minecraft:light[level=12]
setblock 144 178 313 minecraft:light[level=12]
setblock 145 178 275 minecraft:white_concrete
setblock 145 178 277 minecraft:snow_block
setblock 145 178 317 minecraft:packed_ice
setblock 146 178 276 minecraft:snow_block
fill 146 178 277 146 181 277 minecraft:packed_ice
setblock 146 178 316 minecraft:snow_block
fill 147 178 276 147 181 276 minecraft:packed_ice
fill 147 178 316 147 181 316 minecraft:packed_ice
fill 147 178 317 147 179 317 minecraft:blue_ice
setblock 148 178 275 minecraft:light_blue_concrete
setblock 149 178 278 minecraft:snow_block
setblock 150 178 277 minecraft:snow_block
setblock 150 178 278 minecraft:packed_ice
fill 150 178 301 151 185 301 minecraft:packed_ice
setblock 151 178 276 minecraft:snow_block
fill 151 178 277 151 180 277 minecraft:packed_ice
setblock 151 178 285 minecraft:light[level=12]
setblock 151 178 292 minecraft:light[level=12]
setblock 151 178 299 minecraft:light[level=12]
setblock 151 178 306 minecraft:light[level=12]
setblock 151 178 313 minecraft:light[level=12]
setblock 151 178 316 minecraft:snow_block
fill 152 178 276 152 181 276 minecraft:packed_ice
setblock 152 178 315 minecraft:snow_block
fill 152 178 316 155 178 316 minecraft:packed_ice
setblock 153 178 315 minecraft:packed_ice
setblock 155 178 275 minecraft:packed_ice
setblock 156 178 276 minecraft:snow_block
setblock 156 178 316 minecraft:snow_block
setblock 157 178 275 minecraft:packed_ice
setblock 158 178 278 minecraft:light[level=12]
setblock 158 178 285 minecraft:light[level=12]
setblock 158 178 292 minecraft:light[level=12]
setblock 158 178 299 minecraft:light[level=12]
setblock 158 178 306 minecraft:light[level=12]
setblock 158 178 313 minecraft:light[level=12]
fill 163 178 275 163 179 275 minecraft:blue_ice
setblock 165 178 278 minecraft:light[level=12]
setblock 165 178 285 minecraft:light[level=12]
setblock 165 178 292 minecraft:light[level=12]
setblock 165 178 299 minecraft:light[level=12]
setblock 165 178 306 minecraft:light[level=12]
setblock 165 178 313 minecraft:light[level=12]
fill 166 178 317 166 179 317 minecraft:blue_ice
fill 168 178 275 168 179 275 minecraft:blue_ice
setblock 171 178 276 minecraft:snow_block
setblock 172 178 276 minecraft:packed_ice
setblock 172 178 278 minecraft:light[level=12]
setblock 172 178 285 minecraft:light[level=12]
setblock 172 178 292 minecraft:light[level=12]
setblock 172 178 299 minecraft:light[level=12]
setblock 172 178 306 minecraft:light[level=12]
setblock 172 178 313 minecraft:light[level=12]
fill 174 178 275 174 179 275 minecraft:blue_ice
fill 174 178 317 175 179 317 minecraft:blue_ice
fill 176 178 306 176 180 306 minecraft:packed_ice
fill 176 178 308 176 180 308 minecraft:packed_ice
fill 177 178 317 177 179 317 minecraft:blue_ice
fill 178 178 306 178 180 306 minecraft:packed_ice
fill 178 178 308 178 180 308 minecraft:packed_ice
setblock 179 178 275 minecraft:light_blue_concrete
setblock 179 178 278 minecraft:light[level=12]
setblock 179 178 285 minecraft:light[level=12]
setblock 179 178 292 minecraft:light[level=12]
setblock 179 178 299 minecraft:light[level=12]
setblock 179 178 306 minecraft:light[level=12]
setblock 179 178 313 minecraft:light[level=12]
fill 180 178 275 180 179 275 minecraft:blue_ice
setblock 181 178 275 minecraft:packed_ice
setblock 181 178 281 minecraft:snow_block
fill 181 178 282 181 180 282 minecraft:packed_ice
setblock 182 178 280 minecraft:snow_block
fill 182 178 281 182 181 281 minecraft:packed_ice
setblock 182 178 285 minecraft:snow_block
fill 182 178 286 182 181 286 minecraft:packed_ice
fill 183 178 275 183 180 275 minecraft:blue_ice
setblock 183 178 277 minecraft:packed_ice
fill 183 178 285 183 180 285 minecraft:blue_ice
fill 183 178 289 183 179 289 minecraft:blue_ice
fill 183 178 295 183 180 295 minecraft:blue_ice
fill 183 178 299 183 178 300 minecraft:packed_ice
fill 183 178 306 183 179 306 minecraft:blue_ice
setblock 183 178 307 minecraft:packed_ice
setblock 183 178 315 minecraft:packed_ice
setblock 183 178 317 minecraft:packed_ice
setblock 141 179 283 minecraft:blue_ice
setblock 141 179 301 minecraft:blue_ice
fill 141 179 304 141 179 305 minecraft:blue_ice
setblock 141 179 310 minecraft:blue_ice
setblock 142 179 279 minecraft:snow_block
fill 142 179 280 142 182 280 minecraft:packed_ice
setblock 142 179 284 minecraft:snow_block
fill 142 179 285 142 182 285 minecraft:packed_ice
setblock 143 179 279 minecraft:packed_ice
setblock 143 179 283 minecraft:snow_block
fill 143 179 284 143 182 284 minecraft:packed_ice
fill 144 179 281 144 182 281 minecraft:packed_ice
fill 144 179 283 144 182 283 minecraft:packed_ice
setblock 145 179 275 minecraft:blue_ice
setblock 145 179 276 minecraft:snow_block
setblock 145 179 277 minecraft:packed_ice
fill 145 179 282 145 182 282 minecraft:packed_ice
setblock 145 179 317 minecraft:blue_ice
fill 146 179 276 146 182 276 minecraft:packed_ice
fill 146 179 316 146 182 316 minecraft:packed_ice
fill 147 179 279 147 180 279 minecraft:packed_ice
setblock 148 179 275 minecraft:blue_ice
fill 148 179 280 148 180 280 minecraft:packed_ice
setblock 149 179 277 minecraft:snow_block
fill 149 179 278 149 179 279 minecraft:packed_ice
fill 149 179 300 149 185 300 minecraft:packed_ice
setblock 150 179 276 minecraft:snow_block
fill 150 179 277 150 180 277 minecraft:packed_ice
fill 150 179 299 151 185 299 minecraft:packed_ice
setblock 150 179 316 minecraft:snow_block
setblock 150 179 317 minecraft:light_blue_concrete
fill 151 179 276 151 182 276 minecraft:packed_ice
setblock 151 179 315 minecraft:snow_block
fill 151 179 316 154 179 316 minecraft:packed_ice
fill 152 179 300 152 185 301 minecraft:packed_ice
setblock 152 179 315 minecraft:packed_ice
setblock 155 179 275 minecraft:blue_ice
setblock 155 179 316 minecraft:snow_block
fill 157 179 275 157 181 275 minecraft:blue_ice
setblock 179 179 275 minecraft:blue_ice
setblock 181 179 275 minecraft:blue_ice
setblock 181 179 285 minecraft:snow_block
setblock 182 179 279 minecraft:snow_block
fill 182 179 280 182 182 280 minecraft:packed_ice
setblock 182 179 284 minecraft:snow_block
fill 182 179 285 182 182 285 minecraft:packed_ice
setblock 183 179 277 minecraft:blue_ice
setblock 183 179 281 minecraft:light_blue_concrete
fill 183 179 282 183 179 284 minecraft:blue_ice
setblock 183 179 296 minecraft:blue_ice
setblock 183 179 297 minecraft:white_concrete
fill 183 179 299 183 179 300 minecraft:blue_ice
setblock 183 179 304 minecraft:blue_ice
setblock 183 179 307 minecraft:blue_ice
setblock 183 179 313 minecraft:light_blue_concrete
setblock 183 179 315 minecraft:blue_ice
setblock 183 179 316 minecraft:white_concrete
fill 183 179 317 183 180 317 minecraft:blue_ice
fill 141 180 275 141 180 283 minecraft:packed_ice
setblock 141 180 284 minecraft:blue_ice
fill 141 180 285 141 194 285 minecraft:packed_ice
fill 141 180 287 141 180 292 minecraft:packed_ice
fill 141 180 294 141 180 311 minecraft:packed_ice
fill 141 180 313 141 180 316 minecraft:packed_ice
fill 142 180 275 156 180 275 minecraft:packed_ice
setblock 142 180 278 minecraft:snow_block
fill 142 180 279 142 183 279 minecraft:packed_ice
setblock 142 180 283 minecraft:snow_block
fill 142 180 284 142 183 284 minecraft:packed_ice
fill 142 180 317 145 180 317 minecraft:packed_ice
setblock 143 180 282 minecraft:snow_block
fill 143 180 283 143 183 283 minecraft:packed_ice
setblock 144 180 276 minecraft:snow_block
setblock 144 180 278 minecraft:light[level=15]
setblock 144 180 286 minecraft:light[level=15]
setblock 144 180 294 minecraft:light[level=15]
setblock 144 180 302 minecraft:light[level=15]
setblock 144 180 310 minecraft:light[level=15]
fill 145 180 276 145 183 276 minecraft:packed_ice
fill 145 180 281 145 182 281 minecraft:packed_ice
fill 145 180 283 145 182 283 minecraft:packed_ice
fill 145 180 316 145 183 316 minecraft:packed_ice
fill 147 180 317 147 244 317 minecraft:packed_ice
setblock 148 180 277 minecraft:snow_block
fill 148 180 315 148 181 315 minecraft:packed_ice
setblock 148 180 317 minecraft:white_concrete
setblock 149 180 276 minecraft:snow_block
fill 149 180 277 149 181 277 minecraft:packed_ice
setblock 149 180 279 minecraft:packed_ice
fill 149 180 299 149 185 299 minecraft:packed_ice
fill 149 180 301 149 185 301 minecraft:packed_ice
setblock 149 180 316 minecraft:snow_block
fill 149 180 317 150 181 317 minecraft:packed_ice
fill 150 180 276 150 183 276 minecraft:packed_ice
fill 150 180 302 151 185 302 minecraft:packed_ice
setblock 150 180 315 minecraft:snow_block
fill 150 180 316 153 180 316 minecraft:packed_ice
fill 151 180 315 151 183 315 minecraft:packed_ice
setblock 152 180 278 minecraft:light[level=15]
setblock 152 180 286 minecraft:light[level=15]
setblock 152 180 294 minecraft:light[level=15]
fill 152 180 299 152 185 299 minecraft:packed_ice
setblock 152 180 302 minecraft:light[level=15]
setblock 152 180 310 minecraft:light[level=15]
fill 153 180 317 181 180 317 minecraft:packed_ice
setblock 154 180 316 minecraft:snow_block
fill 158 180 275 163 180 275 minecraft:packed_ice
setblock 160 180 278 minecraft:light[level=15]
setblock 160 180 286 minecraft:light[level=15]
setblock 160 180 294 minecraft:light[level=15]
setblock 160 180 302 minecraft:light[level=15]
setblock 160 180 310 minecraft:light[level=15]
fill 165 180 275 182 180 275 minecraft:packed_ice
setblock 168 180 278 minecraft:light[level=15]
setblock 168 180 286 minecraft:light[level=15]
setblock 168 180 294 minecraft:light[level=15]
setblock 168 180 302 minecraft:light[level=15]
setblock 168 180 310 minecraft:light[level=15]
setblock 175 180 307 minecraft:packed_ice
setblock 176 180 278 minecraft:light[level=15]
setblock 176 180 286 minecraft:light[level=15]
setblock 176 180 294 minecraft:light[level=15]
setblock 176 180 302 minecraft:light[level=15]
setblock 177 180 305 minecraft:packed_ice
setblock 177 180 309 minecraft:packed_ice
setblock 179 180 307 minecraft:packed_ice
setblock 181 180 284 minecraft:snow_block
fill 181 180 285 181 183 285 minecraft:packed_ice
fill 182 180 279 183 183 279 minecraft:packed_ice
setblock 182 180 283 minecraft:snow_block
fill 182 180 284 183 180 284 minecraft:packed_ice
setblock 182 180 288 minecraft:snow_block
fill 182 180 289 183 183 289 minecraft:packed_ice
fill 183 180 276 183 194 278 minecraft:packed_ice
fill 183 180 280 183 215 283 minecraft:packed_ice
fill 183 180 286 183 242 288 minecraft:packed_ice
fill 183 180 290 183 181 294 minecraft:packed_ice
fill 183 180 296 183 180 298 minecraft:packed_ice
setblock 183 180 299 minecraft:blue_ice
fill 183 180 300 183 216 307 minecraft:packed_ice
fill 183 180 310 183 180 313 minecraft:packed_ice
fill 183 180 315 183 181 316 minecraft:packed_ice
fill 141 181 275 141 193 280 minecraft:packed_ice
fill 141 181 281 141 182 281 minecraft:blue_ice
fill 141 181 282 141 228 284 minecraft:packed_ice
fill 141 181 286 141 181 290 minecraft:packed_ice
setblock 141 181 291 minecraft:blue_ice
fill 141 181 292 141 181 300 minecraft:packed_ice
setblock 141 181 301 minecraft:blue_ice
fill 141 181 302 141 216 303 minecraft:packed_ice
setblock 141 181 304 minecraft:blue_ice
fill 141 181 305 141 187 315 minecraft:packed_ice
setblock 141 181 316 minecraft:blue_ice
fill 141 181 317 143 225 317 minecraft:packed_ice
fill 142 181 275 152 181 275 minecraft:packed_ice
setblock 142 181 277 minecraft:snow_block
fill 142 181 278 142 184 278 minecraft:packed_ice
setblock 142 181 282 minecraft:snow_block
fill 142 181 283 142 184 283 minecraft:packed_ice
setblock 142 181 287 minecraft:snow_block
setblock 143 181 276 minecraft:snow_block
setblock 143 181 281 minecraft:snow_block
fill 143 181 282 143 184 282 minecraft:packed_ice
setblock 143 181 285 minecraft:packed_ice
fill 144 181 276 144 184 276 minecraft:packed_ice
fill 144 181 317 145 181 317 minecraft:blue_ice
setblock 147 181 277 minecraft:snow_block
setblock 148 181 276 minecraft:snow_block
fill 148 181 277 148 182 277 minecraft:packed_ice
setblock 148 181 316 minecraft:snow_block
fill 148 181 317 148 194 317 minecraft:packed_ice
fill 149 181 276 149 184 276 minecraft:packed_ice
fill 149 181 302 149 185 302 minecraft:packed_ice
setblock 149 181 315 minecraft:snow_block
fill 149 181 316 152 181 316 minecraft:packed_ice
fill 150 181 298 151 185 298 minecraft:packed_ice
fill 150 181 315 150 184 315 minecraft:packed_ice
fill 151 181 317 155 181 317 minecraft:packed_ice
fill 152 181 302 152 185 302 minecraft:packed_ice
setblock 153 181 275 minecraft:blue_ice
fill 153 181 300 153 185 301 minecraft:packed_ice
setblock 153 181 316 minecraft:snow_block
fill 154 181 275 156 182 275 minecraft:packed_ice
setblock 156 181 317 minecraft:blue_ice
fill 157 181 317 170 181 317 minecraft:packed_ice
fill 158 181 275 160 216 275 minecraft:packed_ice
fill 161 181 275 161 182 275 minecraft:blue_ice
fill 162 181 275 164 232 275 minecraft:packed_ice
fill 165 181 275 166 181 275 minecraft:white_concrete
setblock 167 181 275 minecraft:blue_ice
fill 168 181 275 168 244 275 minecraft:packed_ice
setblock 169 181 275 minecraft:blue_ice
fill 170 181 275 173 190 275 minecraft:packed_ice
fill 171 181 317 171 182 317 minecraft:blue_ice
fill 172 181 317 172 182 317 minecraft:packed_ice
setblock 173 181 317 minecraft:blue_ice
setblock 174 181 275 minecraft:blue_ice
fill 174 181 317 180 181 317 minecraft:packed_ice
fill 175 181 275 183 181 275 minecraft:packed_ice
setblock 181 181 283 minecraft:snow_block
fill 181 181 284 182 183 284 minecraft:packed_ice
fill 181 181 286 181 182 286 minecraft:packed_ice
setblock 181 181 317 minecraft:blue_ice
setblock 182 181 282 minecraft:snow_block
fill 182 181 283 182 184 283 minecraft:packed_ice
setblock 182 181 287 minecraft:snow_block
fill 182 181 288 182 184 288 minecraft:packed_ice
fill 182 181 290 182 182 290 minecraft:packed_ice
fill 182 181 317 183 181 317 minecraft:packed_ice
setblock 183 181 284 minecraft:blue_ice
fill 183 181 285 183 244 285 minecraft:packed_ice
fill 183 181 295 183 246 295 minecraft:packed_ice
fill 183 181 296 183 181 297 minecraft:blue_ice
fill 183 181 298 183 182 299 minecraft:packed_ice
fill 183 181 308 183 197 308 minecraft:packed_ice
fill 183 181 310 183 181 311 minecraft:blue_ice
fill 183 181 312 183 240 314 minecraft:packed_ice
fill 141 182 286 141 182 287 minecraft:blue_ice
fill 141 182 288 142 184 288 minecraft:packed_ice
setblock 141 182 289 minecraft:blue_ice
fill 141 182 290 141 240 293 minecraft:packed_ice
setblock 141 182 294 minecraft:blue_ice
fill 141 182 295 141 193 301 minecraft:packed_ice
fill 141 182 304 141 194 304 minecraft:packed_ice
fill 141 182 316 141 199 316 minecraft:packed_ice
fill 142 182 275 147 183 275 minecraft:packed_ice
fill 142 182 277 142 185 277 minecraft:packed_ice
setblock 142 182 281 minecraft:snow_block
fill 142 182 282 142 185 282 minecraft:packed_ice
setblock 142 182 286 minecraft:snow_block
fill 142 182 287 142 185 287 minecraft:packed_ice
setblock 142 182 306 minecraft:snow_block
fill 142 182 307 142 182 310 minecraft:packed_ice
setblock 142 182 311 minecraft:snow_block
fill 143 182 276 143 185 276 minecraft:packed_ice
fill 143 182 281 143 185 281 minecraft:packed_ice
setblock 143 182 285 minecraft:snow_block
fill 143 182 286 143 185 286 minecraft:packed_ice
setblock 144 182 280 minecraft:packed_ice
setblock 144 182 284 minecraft:packed_ice
fill 144 182 316 144 184 317 minecraft:packed_ice
fill 145 182 317 146 236 317 minecraft:packed_ice
setblock 146 182 277 minecraft:snow_block
setblock 146 182 282 minecraft:packed_ice
fill 146 182 315 147 182 315 minecraft:packed_ice
setblock 147 182 276 minecraft:snow_block
fill 147 182 277 147 185 277 minecraft:packed_ice
setblock 147 182 316 minecraft:snow_block
setblock 148 182 275 minecraft:blue_ice
fill 148 182 276 148 185 276 minecraft:packed_ice
fill 148 182 299 148 185 301 minecraft:packed_ice
setblock 148 182 315 minecraft:snow_block
fill 148 182 316 151 182 316 minecraft:packed_ice
fill 149 182 275 151 183 275 minecraft:packed_ice
fill 149 182 298 149 185 298 minecraft:packed_ice
fill 149 182 315 149 185 315 minecraft:packed_ice
setblock 149 182 317 minecraft:blue_ice
fill 150 182 303 151 185 303 minecraft:packed_ice
fill 150 182 317 150 233 317 minecraft:packed_ice
setblock 151 182 317 minecraft:blue_ice
setblock 152 182 275 minecraft:blue_ice
fill 152 182 298 152 185 298 minecraft:packed_ice
setblock 152 182 316 minecraft:snow_block
fill 152 182 317 167 183 317 minecraft:packed_ice
fill 153 182 275 153 204 275 minecraft:packed_ice
fill 153 182 299 153 185 299 minecraft:packed_ice
fill 153 182 302 153 185 302 minecraft:packed_ice
fill 153 182 316 153 185 316 minecraft:packed_ice
fill 157 182 275 157 244 275 minecraft:packed_ice
fill 165 182 275 167 216 275 minecraft:packed_ice
setblock 168 182 317 minecraft:blue_ice
fill 169 182 275 169 197 275 minecraft:packed_ice
fill 169 182 317 170 190 317 minecraft:packed_ice
fill 173 182 317 175 239 317 minecraft:packed_ice
fill 174 182 275 174 217 275 minecraft:packed_ice
setblock 175 182 275 minecraft:blue_ice
fill 176 182 275 182 211 275 minecraft:packed_ice
setblock 176 182 317 minecraft:light_blue_concrete
fill 177 182 317 181 216 317 minecraft:packed_ice
setblock 181 182 282 minecraft:snow_block
fill 181 182 283 181 185 283 minecraft:packed_ice
setblock 181 182 287 minecraft:snow_block
setblock 182 182 281 minecraft:snow_block
fill 182 182 282 182 185 282 minecraft:packed_ice
setblock 182 182 286 minecraft:snow_block
fill 182 182 287 182 185 287 minecraft:packed_ice
setblock 182 182 317 minecraft:blue_ice
setblock 183 182 275 minecraft:blue_ice
fill 183 182 284 183 244 284 minecraft:packed_ice
fill 183 182 290 183 245 290 minecraft:packed_ice
fill 183 182 291 183 182 292 minecraft:blue_ice
fill 183 182 293 183 195 294 minecraft:packed_ice
fill 183 182 296 183 223 297 minecraft:packed_ice
fill 183 182 309 183 207 311 minecraft:packed_ice
setblock 183 182 315 minecraft:blue_ice
fill 183 182 316 183 224 317 minecraft:packed_ice
fill 141 183 281 142 186 281 minecraft:packed_ice
fill 141 183 286 141 195 287 minecraft:packed_ice
fill 141 183 289 142 183 289 minecraft:packed_ice
fill 141 183 294 141 241 294 minecraft:packed_ice
fill 142 183 276 142 186 276 minecraft:packed_ice
setblock 142 183 280 minecraft:snow_block
setblock 142 183 285 minecraft:snow_block
fill 142 183 286 142 186 286 minecraft:packed_ice
setblock 142 183 305 minecraft:snow_block
fill 142 183 306 142 183 309 minecraft:packed_ice
setblock 142 183 310 minecraft:snow_block
fill 142 183 311 142 183 314 minecraft:packed_ice
setblock 142 183 315 minecraft:snow_block
fill 143 183 280 143 186 280 minecraft:packed_ice
setblock 143 183 284 minecraft:snow_block
fill 143 183 285 143 186 285 minecraft:packed_ice
fill 143 183 287 143 184 287 minecraft:packed_ice
fill 143 183 307 143 183 308 minecraft:packed_ice
setblock 143 183 309 minecraft:snow_block
fill 143 183 310 143 185 311 minecraft:packed_ice
fill 143 183 316 143 185 316 minecraft:packed_ice
fill 145 183 315 146 183 315 minecraft:packed_ice
setblock 146 183 276 minecraft:snow_block
fill 146 183 277 146 186 277 minecraft:packed_ice
setblock 146 183 316 minecraft:snow_block
fill 147 183 276 147 186 276 minecraft:packed_ice
setblock 147 183 315 minecraft:snow_block
fill 147 183 316 150 183 316 minecraft:packed_ice
fill 148 183 275 148 194 275 minecraft:packed_ice
fill 148 183 298 148 185 298 minecraft:packed_ice
fill 148 183 302 148 185 302 minecraft:packed_ice
setblock 148 183 314 minecraft:snow_block
fill 148 183 315 148 186 315 minecraft:packed_ice
fill 149 183 303 149 185 303 minecraft:packed_ice
fill 149 183 314 149 186 314 minecraft:packed_ice
fill 149 183 317 149 244 317 minecraft:packed_ice
fill 150 183 297 152 185 297 minecraft:packed_ice
setblock 151 183 276 minecraft:snow_block
setblock 151 183 316 minecraft:snow_block
fill 151 183 317 151 240 317 minecraft:packed_ice
fill 152 183 275 152 245 275 minecraft:packed_ice
fill 152 183 303 152 185 303 minecraft:packed_ice
fill 152 183 316 152 186 316 minecraft:packed_ice
fill 153 183 298 153 185 298 minecraft:packed_ice
setblock 154 183 275 minecraft:light_blue_concrete
fill 154 183 300 154 185 301 minecraft:packed_ice
fill 155 183 275 156 194 275 minecraft:packed_ice
fill 155 183 313 156 184 314 minecraft:snow_block
fill 156 183 312 156 184 312 minecraft:snow_block
fill 161 183 275 161 241 275 minecraft:packed_ice
fill 168 183 317 168 244 317 minecraft:packed_ice
fill 171 183 317 171 193 317 minecraft:packed_ice
setblock 172 183 317 minecraft:light_blue_concrete
fill 175 183 275 175 209 275 minecraft:packed_ice
fill 176 183 317 176 222 317 minecraft:packed_ice
fill 181 183 282 181 186 282 minecraft:packed_ice
setblock 181 183 286 minecraft:snow_block
fill 181 183 287 181 184 289 minecraft:packed_ice
fill 182 183 278 182 184 278 minecraft:packed_ice
setblock 182 183 280 minecraft:snow_block
fill 182 183 281 182 186 281 minecraft:packed_ice
setblock 182 183 285 minecraft:snow_block
fill 182 183 286 182 186 286 minecraft:packed_ice
setblock 182 183 290 minecraft:snow_block
fill 182 183 291 183 186 291 minecraft:packed_ice
fill 182 183 317 182 244 317 minecraft:packed_ice
fill 183 183 275 183 242 275 minecraft:packed_ice
fill 183 183 292 183 191 292 minecraft:packed_ice
fill 183 183 298 183 213 298 minecraft:packed_ice
setblock 183 183 299 minecraft:white_concrete
fill 183 183 315 183 189 315 minecraft:packed_ice
fill 141 184 289 141 244 289 minecraft:packed_ice
fill 142 184 275 146 228 275 minecraft:packed_ice
setblock 142 184 279 minecraft:snow_block
fill 142 184 280 142 187 280 minecraft:packed_ice
setblock 142 184 284 minecraft:snow_block
fill 142 184 285 142 187 285 minecraft:packed_ice
setblock 142 184 289 minecraft:snow_block
fill 142 184 290 142 186 291 minecraft:packed_ice
setblock 142 184 304 minecraft:snow_block
fill 142 184 305 142 184 308 minecraft:packed_ice
setblock 142 184 309 minecraft:snow_block
fill 142 184 310 142 184 313 minecraft:packed_ice
setblock 142 184 314 minecraft:snow_block
fill 142 184 315 142 186 316 minecraft:packed_ice
setblock 143 184 283 minecraft:snow_block
fill 143 184 284 143 187 284 minecraft:packed_ice
setblock 143 184 288 minecraft:snow_block
fill 143 184 289 143 187 289 minecraft:packed_ice
fill 143 184 306 143 184 307 minecraft:packed_ice
setblock 143 184 308 minecraft:snow_block
fill 143 184 309 144 186 309 minecraft:packed_ice
setblock 143 184 312 minecraft:packed_ice
setblock 143 184 313 minecraft:snow_block
fill 143 184 314 143 186 315 minecraft:packed_ice
setblock 144 184 278 minecraft:light[level=12]
setblock 144 184 285 minecraft:light[level=12]
setblock 144 184 292 minecraft:light[level=12]
setblock 144 184 299 minecraft:light[level=12]
setblock 144 184 306 minecraft:light[level=12]
setblock 144 184 307 minecraft:snow_block
fill 144 184 308 144 187 308 minecraft:packed_ice
fill 144 184 310 144 184 311 minecraft:packed_ice
setblock 144 184 312 minecraft:snow_block
setblock 144 184 313 minecraft:light[level=12]
fill 144 184 315 145 184 315 minecraft:packed_ice
setblock 145 184 276 minecraft:snow_block
fill 145 184 277 145 187 277 minecraft:packed_ice
fill 145 184 314 146 184 314 minecraft:packed_ice
setblock 145 184 316 minecraft:snow_block
fill 146 184 276 146 187 276 minecraft:packed_ice
setblock 146 184 315 minecraft:snow_block
fill 146 184 316 149 184 316 minecraft:packed_ice
setblock 147 184 275 minecraft:light_blue_concrete
fill 147 184 299 147 185 302 minecraft:packed_ice
setblock 147 184 314 minecraft:snow_block
fill 147 184 315 147 187 315 minecraft:packed_ice
fill 148 184 303 148 185 303 minecraft:packed_ice
fill 148 184 314 148 187 314 minecraft:packed_ice
setblock 149 184 275 minecraft:white_concrete
fill 149 184 297 149 185 297 minecraft:packed_ice
fill 150 184 275 151 201 275 minecraft:packed_ice
setblock 150 184 276 minecraft:snow_block
fill 150 184 304 152 185 304 minecraft:packed_ice
fill 150 184 314 150 185 314 minecraft:packed_ice
setblock 150 184 316 minecraft:snow_block
setblock 151 184 278 minecraft:light[level=12]
setblock 151 184 285 minecraft:light[level=12]
setblock 151 184 292 minecraft:light[level=12]
setblock 151 184 306 minecraft:light[level=12]
setblock 151 184 313 minecraft:light[level=12]
setblock 151 184 315 minecraft:snow_block
fill 151 184 316 151 187 316 minecraft:packed_ice
fill 152 184 315 152 187 315 minecraft:packed_ice
fill 152 184 317 161 184 317 minecraft:packed_ice
fill 153 184 297 153 185 297 minecraft:packed_ice
fill 153 184 303 153 185 303 minecraft:packed_ice
fill 154 184 275 154 244 275 minecraft:packed_ice
fill 154 184 299 154 185 299 minecraft:packed_ice
fill 154 184 302 154 185 302 minecraft:packed_ice
setblock 158 184 278 minecraft:light[level=12]
setblock 158 184 285 minecraft:light[level=12]
setblock 158 184 292 minecraft:light[level=12]
setblock 158 184 299 minecraft:light[level=12]
setblock 158 184 306 minecraft:light[level=12]
setblock 158 184 313 minecraft:light[level=12]
setblock 162 184 317 minecraft:white_concrete
fill 163 184 317 167 230 317 minecraft:packed_ice
setblock 165 184 278 minecraft:light[level=12]
setblock 165 184 285 minecraft:light[level=12]
setblock 165 184 292 minecraft:light[level=12]
setblock 165 184 299 minecraft:light[level=12]
setblock 165 184 306 minecraft:light[level=12]
setblock 165 184 313 minecraft:light[level=12]
fill 166 184 316 167 186 316 minecraft:packed_ice
setblock 172 184 278 minecraft:light[level=12]
setblock 172 184 285 minecraft:light[level=12]
setblock 172 184 292 minecraft:light[level=12]
setblock 172 184 299 minecraft:light[level=12]
setblock 172 184 306 minecraft:light[level=12]
setblock 172 184 313 minecraft:light[level=12]
fill 172 184 317 172 244 317 minecraft:packed_ice
setblock 179 184 278 minecraft:light[level=12]
setblock 179 184 285 minecraft:light[level=12]
setblock 179 184 292 minecraft:light[level=12]
setblock 179 184 299 minecraft:light[level=12]
setblock 179 184 306 minecraft:light[level=12]
setblock 179 184 313 minecraft:light[level=12]
fill 181 184 281 181 187 281 minecraft:packed_ice
setblock 181 184 284 minecraft:packed_ice
setblock 181 184 285 minecraft:snow_block
fill 181 184 286 181 187 286 minecraft:packed_ice
setblock 181 184 290 minecraft:snow_block
fill 182 184 277 182 185 277 minecraft:packed_ice
setblock 182 184 279 minecraft:snow_block
fill 182 184 280 182 187 280 minecraft:packed_ice
setblock 182 184 284 minecraft:snow_block
fill 182 184 285 182 187 285 minecraft:packed_ice
setblock 182 184 289 minecraft:snow_block
fill 182 184 290 182 187 290 minecraft:packed_ice
fill 182 184 292 182 184 293 minecraft:packed_ice
fill 182 184 306 182 184 308 minecraft:packed_ice
setblock 182 184 309 minecraft:snow_block
fill 182 184 310 182 186 311 minecraft:packed_ice
fill 183 184 279 183 244 279 minecraft:packed_ice
fill 183 184 289 183 193 289 minecraft:packed_ice
fill 183 184 299 183 242 299 minecraft:packed_ice
fill 141 185 288 141 241 288 minecraft:packed_ice
setblock 142 185 278 minecraft:snow_block
fill 142 185 279 143 187 279 minecraft:packed_ice
setblock 142 185 283 minecraft:snow_block
fill 142 185 284 142 188 284 minecraft:packed_ice
setblock 142 185 288 minecraft:snow_block
fill 142 185 289 142 188 289 minecraft:packed_ice
setblock 142 185 292 minecraft:packed_ice
fill 142 185 304 142 185 307 minecraft:packed_ice
setblock 142 185 308 minecraft:snow_block
fill 142 185 309 142 185 312 minecraft:packed_ice
setblock 142 185 313 minecraft:snow_block
fill 142 185 314 142 188 314 minecraft:packed_ice
setblock 143 185 277 minecraft:snow_block
fill 143 185 278 143 188 278 minecraft:packed_ice
setblock 143 185 282 minecraft:snow_block
fill 143 185 283 143 188 283 minecraft:packed_ice
setblock 143 185 287 minecraft:snow_block
fill 143 185 288 143 188 288 minecraft:packed_ice
fill 143 185 290 143 186 290 minecraft:packed_ice
fill 143 185 305 143 185 306 minecraft:packed_ice
setblock 143 185 307 minecraft:snow_block
fill 143 185 308 143 188 308 minecraft:packed_ice
setblock 143 185 312 minecraft:snow_block
fill 143 185 313 144 187 313 minecraft:packed_ice
setblock 144 185 276 minecraft:snow_block
fill 144 185 277 144 188 277 minecraft:packed_ice
fill 144 185 284 144 185 285 minecraft:packed_ice
setblock 144 185 286 minecraft:snow_block
fill 144 185 287 144 188 287 minecraft:packed_ice
setblock 144 185 306 minecraft:snow_block
fill 144 185 307 144 188 307 minecraft:packed_ice
setblock 144 185 310 minecraft:packed_ice
setblock 144 185 311 minecraft:snow_block
fill 144 185 312 145 187 312 minecraft:packed_ice
fill 144 185 314 144 185 315 minecraft:packed_ice
setblock 144 185 316 minecraft:snow_block
fill 144 185 317 144 240 317 minecraft:packed_ice
fill 145 185 276 145 188 276 minecraft:packed_ice
fill 145 185 308 145 185 309 minecraft:packed_ice
setblock 145 185 310 minecraft:snow_block
fill 145 185 311 145 188 311 minecraft:packed_ice
setblock 145 185 314 minecraft:packed_ice
setblock 145 185 315 minecraft:snow_block
fill 145 185 316 148 185 316 minecraft:packed_ice
setblock 146 185 313 minecraft:packed_ice
setblock 146 185 314 minecraft:snow_block
fill 146 185 315 146 188 315 minecraft:packed_ice
fill 147 185 275 147 244 275 minecraft:packed_ice
setblock 147 185 298 minecraft:packed_ice
setblock 147 185 313 minecraft:snow_block
fill 147 185 314 147 188 314 minecraft:packed_ice
setblock 148 185 297 minecraft:packed_ice
fill 148 185 313 149 187 313 minecraft:packed_ice
fill 149 185 275 149 223 275 minecraft:packed_ice
setblock 149 185 276 minecraft:snow_block
fill 149 185 296 150 185 296 minecraft:packed_ice
setblock 149 185 304 minecraft:packed_ice
setblock 149 185 316 minecraft:snow_block
fill 150 185 276 150 188 276 minecraft:packed_ice
setblock 150 185 315 minecraft:snow_block
fill 150 185 316 150 188 316 minecraft:packed_ice
setblock 151 185 314 minecraft:snow_block
fill 151 185 315 151 188 315 minecraft:packed_ice
fill 152 185 317 156 214 317 minecraft:packed_ice
setblock 153 185 304 minecraft:packed_ice
setblock 154 185 298 minecraft:packed_ice
setblock 154 185 303 minecraft:packed_ice
setblock 154 185 316 minecraft:snow_block
fill 155 185 300 155 185 301 minecraft:packed_ice
setblock 157 185 317 minecraft:light_blue_concrete
fill 158 185 317 162 213 317 minecraft:packed_ice
setblock 163 185 316 minecraft:packed_ice
setblock 164 185 316 minecraft:snow_block
fill 165 185 316 165 188 316 minecraft:packed_ice
setblock 168 185 316 minecraft:packed_ice
setblock 169 185 316 minecraft:snow_block
setblock 180 185 285 minecraft:snow_block
fill 180 185 286 180 186 288 minecraft:packed_ice
fill 181 185 276 182 186 276 minecraft:packed_ice
setblock 181 185 284 minecraft:snow_block
fill 181 185 285 181 188 285 minecraft:packed_ice
fill 181 185 287 181 185 288 minecraft:packed_ice
setblock 181 185 289 minecraft:snow_block
fill 181 185 290 181 187 291 minecraft:packed_ice
setblock 182 185 278 minecraft:snow_block
fill 182 185 279 182 188 279 minecraft:packed_ice
setblock 182 185 283 minecraft:snow_block
fill 182 185 284 182 188 284 minecraft:packed_ice
setblock 182 185 288 minecraft:snow_block
fill 182 185 289 182 188 289 minecraft:packed_ice
setblock 182 185 292 minecraft:packed_ice
setblock 182 185 293 minecraft:snow_block
fill 182 185 294 182 188 294 minecraft:packed_ice
fill 182 185 305 182 185 307 minecraft:packed_ice
setblock 182 185 308 minecraft:snow_block
fill 182 185 309 182 188 309 minecraft:packed_ice
setblock 182 185 312 minecraft:packed_ice
setblock 182 185 313 minecraft:snow_block
fill 182 185 314 182 187 315 minecraft:packed_ice
setblock 142 186 277 minecraft:snow_block
fill 142 186 278 142 189 278 minecraft:packed_ice
setblock 142 186 282 minecraft:snow_block
fill 142 186 283 142 189 283 minecraft:packed_ice
setblock 142 186 287 minecraft:snow_block
fill 142 186 288 142 189 288 minecraft:packed_ice
setblock 142 186 292 minecraft:snow_block
fill 142 186 293 142 188 294 minecraft:packed_ice
fill 142 186 303 142 186 306 minecraft:packed_ice
setblock 142 186 307 minecraft:snow_block
fill 142 186 308 142 186 311 minecraft:packed_ice
setblock 142 186 312 minecraft:snow_block
fill 142 186 313 142 189 313 minecraft:packed_ice
setblock 143 186 276 minecraft:snow_block
fill 143 186 277 143 189 277 minecraft:packed_ice
setblock 143 186 281 minecraft:snow_block
fill 143 186 282 143 189 282 minecraft:packed_ice
setblock 143 186 286 minecraft:snow_block
fill 143 186 287 143 189 287 minecraft:packed_ice
setblock 143 186 291 minecraft:snow_block
fill 143 186 304 143 186 305 minecraft:packed_ice
setblock 143 186 306 minecraft:snow_block
fill 143 186 307 143 189 307 minecraft:packed_ice
setblock 143 186 310 minecraft:packed_ice
setblock 143 186 311 minecraft:snow_block
fill 143 186 312 143 189 312 minecraft:packed_ice
setblock 143 186 316 minecraft:snow_block
fill 144 186 276 144 189 276 minecraft:packed_ice
setblock 144 186 284 minecraft:packed_ice
setblock 144 186 285 minecraft:snow_block
fill 144 186 286 144 188 286 minecraft:packed_ice
fill 144 186 288 144 186 289 minecraft:packed_ice
fill 144 186 306 144 189 306 minecraft:packed_ice
setblock 144 186 310 minecraft:snow_block
fill 144 186 311 144 189 311 minecraft:packed_ice
setblock 144 186 314 minecraft:packed_ice
setblock 144 186 315 minecraft:snow_block
fill 144 186 316 147 186 316 minecraft:packed_ice
fill 145 186 307 145 186 308 minecraft:packed_ice
setblock 145 186 309 minecraft:snow_block
fill 145 186 310 145 189 310 minecraft:packed_ice
setblock 145 186 313 minecraft:packed_ice
setblock 145 186 314 minecraft:snow_block
fill 145 186 315 145 189 315 minecraft:packed_ice
setblock 146 186 313 minecraft:snow_block
fill 146 186 314 146 189 314 minecraft:packed_ice
setblock 147 186 277 minecraft:snow_block
fill 147 186 313 147 189 313 minecraft:packed_ice
setblock 148 186 276 minecraft:snow_block
setblock 148 186 316 minecraft:snow_block
fill 149 186 276 149 189 276 minecraft:packed_ice
setblock 149 186 315 minecraft:snow_block
fill 149 186 316 149 189 316 minecraft:packed_ice
fill 150 186 300 151 187 301 minecraft:blue_ice
setblock 150 186 313 minecraft:packed_ice
setblock 150 186 314 minecraft:snow_block
fill 150 186 315 150 189 315 minecraft:packed_ice
setblock 151 186 299 minecraft:blue_ice
fill 151 186 314 151 189 314 minecraft:packed_ice
setblock 153 186 315 minecraft:packed_ice
setblock 153 186 316 minecraft:snow_block
fill 154 186 316 155 188 316 minecraft:packed_ice
fill 157 186 317 157 213 317 minecraft:packed_ice
fill 160 186 316 162 186 316 minecraft:packed_ice
setblock 163 186 315 minecraft:packed_ice
setblock 163 186 316 minecraft:snow_block
setblock 164 186 315 minecraft:snow_block
fill 164 186 316 164 189 316 minecraft:packed_ice
fill 165 186 315 167 187 315 minecraft:packed_ice
fill 166 186 276 167 186 276 minecraft:packed_ice
setblock 168 186 276 minecraft:snow_block
setblock 168 186 316 minecraft:snow_block
fill 169 186 315 169 189 316 minecraft:packed_ice
fill 173 186 276 173 187 279 minecraft:snow_block
fill 174 186 277 174 187 284 minecraft:snow_block
fill 180 186 276 180 188 276 minecraft:packed_ice
fill 180 186 285 180 189 285 minecraft:packed_ice
setblock 180 186 289 minecraft:snow_block
fill 181 186 280 181 188 280 minecraft:packed_ice
setblock 181 186 283 minecraft:snow_block
fill 181 186 284 181 189 284 minecraft:packed_ice
setblock 181 186 287 minecraft:packed_ice
setblock 181 186 288 minecraft:snow_block
fill 181 186 289 181 189 289 minecraft:packed_ice
setblock 181 186 292 minecraft:packed_ice
fill 181 186 316 182 186 316 minecraft:packed_ice
setblock 182 186 277 minecraft:snow_block
fill 182 186 278 182 189 278 minecraft:packed_ice
setblock 182 186 282 minecraft:snow_block
fill 182 186 283 182 189 283 minecraft:packed_ice
setblock 182 186 287 minecraft:snow_block
fill 182 186 288 182 189 288 minecraft:packed_ice
setblock 182 186 292 minecraft:snow_block
fill 182 186 293 182 189 293 minecraft:packed_ice
fill 182 186 295 182 187 295 minecraft:packed_ice
fill 182 186 305 182 186 306 minecraft:packed_ice
setblock 182 186 307 minecraft:snow_block
fill 182 186 308 182 189 308 minecraft:packed_ice
setblock 182 186 312 minecraft:snow_block
fill 182 186 313 182 189 313 minecraft:packed_ice
fill 141 187 281 141 240 281 minecraft:packed_ice
setblock 142 187 276 minecraft:snow_block
fill 142 187 277 142 190 277 minecraft:packed_ice
setblock 142 187 281 minecraft:snow_block
fill 142 187 282 142 190 282 minecraft:packed_ice
setblock 142 187 286 minecraft:snow_block
fill 142 187 287 142 190 287 minecraft:packed_ice
setblock 142 187 290 minecraft:packed_ice
setblock 142 187 291 minecraft:snow_block
fill 142 187 292 143 189 292 minecraft:packed_ice
setblock 142 187 295 minecraft:packed_ice
fill 142 187 302 142 187 305 minecraft:packed_ice
setblock 142 187 306 minecraft:snow_block
fill 142 187 307 142 187 310 minecraft:packed_ice
setblock 142 187 311 minecraft:snow_block
fill 142 187 312 142 190 312 minecraft:packed_ice
setblock 142 187 315 minecraft:packed_ice
setblock 142 187 316 minecraft:snow_block
fill 143 187 276 143 190 276 minecraft:packed_ice
setblock 143 187 280 minecraft:snow_block
fill 143 187 281 143 189 281 minecraft:packed_ice
setblock 143 187 285 minecraft:snow_block
fill 143 187 286 143 190 286 minecraft:packed_ice
setblock 143 187 290 minecraft:snow_block
fill 143 187 291 143 190 291 minecraft:packed_ice
fill 143 187 293 143 188 293 minecraft:packed_ice
setblock 143 187 304 minecraft:packed_ice
setblock 143 187 305 minecraft:snow_block
fill 143 187 306 143 190 306 minecraft:packed_ice
setblock 143 187 309 minecraft:packed_ice
setblock 143 187 310 minecraft:snow_block
fill 143 187 311 143 190 311 minecraft:packed_ice
setblock 143 187 314 minecraft:packed_ice
setblock 143 187 315 minecraft:snow_block
fill 143 187 316 146 187 316 minecraft:packed_ice
setblock 144 187 285 minecraft:packed_ice
setblock 144 187 288 minecraft:packed_ice
setblock 144 187 289 minecraft:snow_block
fill 144 187 290 144 190 290 minecraft:packed_ice
setblock 144 187 309 minecraft:snow_block
fill 144 187 310 144 190 310 minecraft:packed_ice
setblock 144 187 314 minecraft:snow_block
fill 144 187 315 144 190 315 minecraft:packed_ice
setblock 145 187 307 minecraft:packed_ice
setblock 145 187 308 minecraft:snow_block
fill 145 187 309 145 190 309 minecraft:packed_ice
setblock 145 187 313 minecraft:snow_block
fill 145 187 314 145 190 314 minecraft:packed_ice
setblock 146 187 277 minecraft:snow_block
fill 146 187 310 146 187 311 minecraft:packed_ice
setblock 146 187 312 minecraft:snow_block
fill 146 187 313 146 190 313 minecraft:packed_ice
setblock 147 187 276 minecraft:snow_block
fill 147 187 277 147 189 277 minecraft:packed_ice
fill 147 187 312 147 189 312 minecraft:packed_ice
setblock 147 187 316 minecraft:snow_block
fill 148 187 276 148 190 276 minecraft:packed_ice
setblock 148 187 315 minecraft:snow_block
fill 148 187 316 148 190 316 minecraft:packed_ice
setblock 149 187 314 minecraft:snow_block
fill 149 187 315 149 190 315 minecraft:packed_ice
setblock 150 187 313 minecraft:snow_block
fill 150 187 314 150 190 314 minecraft:packed_ice
fill 152 187 314 152 188 314 minecraft:packed_ice
setblock 152 187 316 minecraft:snow_block
setblock 153 187 315 minecraft:snow_block
fill 153 187 316 153 190 316 minecraft:packed_ice
fill 154 187 315 154 190 315 minecraft:packed_ice
setblock 156 187 316 minecraft:packed_ice
setblock 157 187 316 minecraft:snow_block
fill 158 187 316 161 187 316 minecraft:packed_ice
fill 161 187 315 162 187 315 minecraft:packed_ice
setblock 162 187 316 minecraft:snow_block
setblock 163 187 315 minecraft:snow_block
fill 163 187 316 163 190 316 minecraft:packed_ice
fill 164 187 276 166 187 276 minecraft:packed_ice
fill 164 187 315 164 190 315 minecraft:packed_ice
fill 165 187 314 165 190 314 minecraft:packed_ice
setblock 166 187 316 minecraft:packed_ice
setblock 167 187 276 minecraft:snow_block
setblock 167 187 316 minecraft:snow_block
fill 168 187 276 169 189 276 minecraft:packed_ice
setblock 168 187 315 minecraft:snow_block
fill 168 187 316 168 190 316 minecraft:packed_ice
fill 170 187 316 170 188 316 minecraft:packed_ice
fill 173 187 280 173 187 281 minecraft:snow_block
setblock 174 187 276 minecraft:snow_block
fill 174 187 285 175 187 288 minecraft:snow_block
fill 175 187 282 175 187 284 minecraft:snow_block
fill 175 187 289 176 187 294 minecraft:snow_block
fill 176 187 295 176 187 299 minecraft:snow_block
fill 177 187 297 177 188 304 minecraft:snow_block
fill 179 187 276 179 189 276 minecraft:packed_ice
fill 180 187 284 180 188 284 minecraft:packed_ice
fill 180 187 286 180 187 287 minecraft:packed_ice
setblock 180 187 288 minecraft:snow_block
fill 180 187 289 180 188 291 minecraft:packed_ice
fill 180 187 316 181 187 316 minecraft:packed_ice
setblock 181 187 276 minecraft:packed_ice
fill 181 187 278 181 189 279 minecraft:packed_ice
setblock 181 187 282 minecraft:snow_block
fill 181 187 283 181 190 283 minecraft:packed_ice
setblock 181 187 287 minecraft:snow_block
fill 181 187 288 181 190 288 minecraft:packed_ice
setblock 181 187 292 minecraft:snow_block
fill 181 187 293 181 190 293 minecraft:packed_ice
fill 181 187 309 181 187 311 minecraft:packed_ice
setblock 181 187 312 minecraft:snow_block
fill 181 187 313 181 188 315 minecraft:packed_ice
setblock 182 187 276 minecraft:snow_block
fill 182 187 277 182 190 277 minecraft:packed_ice
setblock 182 187 281 minecraft:snow_block
fill 182 187 282 182 190 282 minecraft:packed_ice
setblock 182 187 286 minecraft:snow_block
fill 182 187 287 182 190 287 minecraft:packed_ice
setblock 182 187 291 minecraft:snow_block
fill 182 187 292 182 190 292 minecraft:packed_ice
setblock 182 187 296 minecraft:snow_block
fill 182 187 304 182 187 305 minecraft:packed_ice
setblock 182 187 306 minecraft:snow_block
fill 182 187 307 182 190 307 minecraft:packed_ice
setblock 182 187 310 minecraft:packed_ice
setblock 182 187 311 minecraft:snow_block
fill 182 187 312 182 190 312 minecraft:packed_ice
setblock 182 187 316 minecraft:snow_block
fill 183 187 291 183 240 291 minecraft:packed_ice
fill 141 188 305 141 197 312 minecraft:packed_ice
setblock 141 188 313 minecraft:light_blue_concrete
fill 141 188 314 141 203 315 minecraft:packed_ice
fill 142 188 276 142 191 276 minecraft:packed_ice
setblock 142 188 279 minecraft:packed_ice
setblock 142 188 280 minecraft:snow_block
fill 142 188 281 142 191 281 minecraft:packed_ice
setblock 142 188 285 minecraft:snow_block
fill 142 188 286 142 191 286 minecraft:packed_ice
setblock 142 188 290 minecraft:snow_block
fill 142 188 291 142 191 291 minecraft:packed_ice
setblock 142 188 295 minecraft:snow_block
fill 142 188 296 142 190 297 minecraft:packed_ice
fill 142 188 302 142 188 304 minecraft:packed_ice
setblock 142 188 305 minecraft:snow_block
fill 142 188 306 142 188 309 minecraft:packed_ice
setblock 142 188 310 minecraft:snow_block
fill 142 188 311 142 191 311 minecraft:packed_ice
setblock 142 188 315 minecraft:snow_block
fill 142 188 316 145 188 316 minecraft:packed_ice
setblock 143 188 279 minecraft:snow_block
fill 143 188 280 143 190 280 minecraft:packed_ice
setblock 143 188 284 minecraft:snow_block
fill 143 188 285 143 190 285 minecraft:packed_ice
setblock 143 188 289 minecraft:snow_block
fill 143 188 290 143 191 290 minecraft:packed_ice
setblock 143 188 294 minecraft:snow_block
setblock 143 188 304 minecraft:snow_block
fill 143 188 305 143 191 305 minecraft:packed_ice
setblock 143 188 309 minecraft:snow_block
fill 143 188 310 143 191 310 minecraft:packed_ice
setblock 143 188 313 minecraft:packed_ice
setblock 143 188 314 minecraft:snow_block
fill 143 188 315 143 191 315 minecraft:packed_ice
setblock 144 188 278 minecraft:light[level=15]
setblock 144 188 288 minecraft:snow_block
fill 144 188 289 144 189 289 minecraft:packed_ice
fill 144 188 291 144 189 291 minecraft:packed_ice
setblock 144 188 294 minecraft:light[level=15]
setblock 144 188 302 minecraft:light[level=15]
setblock 144 188 308 minecraft:snow_block
fill 144 188 309 144 191 309 minecraft:packed_ice
setblock 144 188 312 minecraft:packed_ice
setblock 144 188 313 minecraft:snow_block
fill 144 188 314 144 191 314 minecraft:packed_ice
setblock 145 188 277 minecraft:snow_block
setblock 145 188 307 minecraft:snow_block
fill 145 188 308 145 190 308 minecraft:packed_ice
setblock 145 188 312 minecraft:snow_block
fill 145 188 313 145 191 313 minecraft:packed_ice
setblock 146 188 276 minecraft:snow_block
fill 146 188 277 146 190 277 minecraft:packed_ice
setblock 146 188 310 minecraft:packed_ice
setblock 146 188 311 minecraft:snow_block
fill 146 188 312 146 190 312 minecraft:packed_ice
setblock 146 188 316 minecraft:snow_block
fill 147 188 276 147 191 276 minecraft:packed_ice
setblock 147 188 315 minecraft:snow_block
fill 147 188 316 147 191 316 minecraft:packed_ice
setblock 148 188 313 minecraft:packed_ice
setblock 148 188 314 minecraft:snow_block
fill 148 188 315 148 191 315 minecraft:packed_ice
setblock 149 188 313 minecraft:snow_block
fill 149 188 314 149 191 314 minecraft:packed_ice
fill 150 188 300 151 188 300 minecraft:blue_ice
fill 150 188 313 150 189 313 minecraft:packed_ice
setblock 151 188 316 minecraft:snow_block
setblock 152 188 278 minecraft:light[level=15]
setblock 152 188 286 minecraft:light[level=15]
setblock 152 188 294 minecraft:light[level=15]
setblock 152 188 302 minecraft:light[level=15]
setblock 152 188 310 minecraft:light[level=15]
setblock 152 188 315 minecraft:snow_block
fill 152 188 316 152 191 316 minecraft:packed_ice
fill 153 188 315 153 191 315 minecraft:packed_ice
setblock 156 188 316 minecraft:snow_block
fill 157 188 316 160 188 316 minecraft:packed_ice
fill 159 188 315 161 188 315 minecraft:packed_ice
setblock 160 188 278 minecraft:light[level=15]
setblock 160 188 286 minecraft:light[level=15]
setblock 160 188 294 minecraft:light[level=15]
setblock 160 188 302 minecraft:light[level=15]
setblock 160 188 310 minecraft:light[level=15]
setblock 161 188 316 minecraft:snow_block
fill 162 188 310 162 189 310 minecraft:packed_ice
setblock 162 188 314 minecraft:packed_ice
setblock 162 188 315 minecraft:snow_block
fill 162 188 316 162 191 316 minecraft:packed_ice
fill 163 188 276 165 188 276 minecraft:packed_ice
setblock 163 188 314 minecraft:snow_block
fill 163 188 315 163 191 315 minecraft:packed_ice
fill 164 188 314 164 191 314 minecraft:packed_ice
fill 165 188 315 166 188 315 minecraft:packed_ice
setblock 166 188 276 minecraft:snow_block
fill 166 188 314 166 189 314 minecraft:packed_ice
setblock 166 188 316 minecraft:snow_block
fill 167 188 276 167 191 276 minecraft:packed_ice
setblock 167 188 315 minecraft:snow_block
fill 167 188 316 167 191 316 minecraft:packed_ice
setblock 168 188 278 minecraft:light[level=15]
setblock 168 188 286 minecraft:light[level=15]
setblock 168 188 294 minecraft:light[level=15]
setblock 168 188 302 minecraft:light[level=15]
setblock 168 188 310 minecraft:light[level=15]
fill 168 188 315 168 192 315 minecraft:packed_ice
setblock 170 188 276 minecraft:packed_ice
fill 173 188 276 173 188 278 minecraft:blue_ice
fill 174 188 279 174 188 284 minecraft:blue_ice
fill 174 188 310 174 189 310 minecraft:packed_ice
fill 175 188 287 175 188 293 minecraft:snow_block
setblock 176 188 278 minecraft:light[level=15]
setblock 176 188 286 minecraft:light[level=15]
fill 176 188 291 176 188 294 minecraft:snow_block
fill 176 188 295 176 189 295 minecraft:packed_ice
fill 176 188 296 176 188 301 minecraft:snow_block
setblock 176 188 302 minecraft:light[level=15]
setblock 177 188 296 minecraft:snow_block
fill 177 188 305 178 188 308 minecraft:snow_block
fill 178 188 276 178 190 276 minecraft:packed_ice
fill 178 188 281 178 189 281 minecraft:packed_ice
fill 178 188 302 178 188 304 minecraft:snow_block
fill 178 188 309 179 188 310 minecraft:snow_block
fill 178 188 314 179 188 314 minecraft:snow_block
fill 178 188 316 180 188 316 minecraft:packed_ice
fill 179 188 311 179 189 313 minecraft:snow_block
setblock 179 188 315 minecraft:snow_block
setblock 180 188 286 minecraft:packed_ice
setblock 180 188 287 minecraft:snow_block
fill 180 188 288 180 191 288 minecraft:packed_ice
fill 180 188 315 180 189 315 minecraft:packed_ice
setblock 181 188 276 minecraft:snow_block
schedule function dropper:buildpart/63_6 1t
