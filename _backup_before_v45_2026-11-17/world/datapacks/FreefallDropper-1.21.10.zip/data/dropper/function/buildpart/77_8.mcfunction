fill 235 246 339 235 308 339 minecraft:moss_block
setblock 236 246 324 minecraft:mushroom_stem
fill 236 246 325 236 249 325 minecraft:moss_block
setblock 236 246 329 minecraft:mushroom_stem
fill 236 246 330 236 249 330 minecraft:moss_block
setblock 236 246 334 minecraft:mushroom_stem
fill 236 246 335 236 249 335 minecraft:moss_block
setblock 236 246 339 minecraft:mushroom_stem
fill 236 246 340 236 249 340 minecraft:moss_block
setblock 236 246 344 minecraft:mushroom_stem
fill 236 246 345 236 247 345 minecraft:moss_block
setblock 236 246 349 minecraft:mushroom_stem
fill 236 246 350 236 249 350 minecraft:moss_block
setblock 236 246 354 minecraft:mushroom_stem
fill 236 246 355 236 249 355 minecraft:moss_block
setblock 236 246 358 minecraft:moss_block
setblock 236 246 359 minecraft:mushroom_stem
fill 236 246 360 236 249 360 minecraft:moss_block
setblock 237 246 323 minecraft:mushroom_stem
fill 237 246 324 237 249 324 minecraft:moss_block
setblock 237 246 328 minecraft:mushroom_stem
fill 237 246 329 237 249 329 minecraft:moss_block
setblock 237 246 333 minecraft:mushroom_stem
fill 237 246 334 238 248 334 minecraft:moss_block
setblock 237 246 338 minecraft:mushroom_stem
fill 237 246 339 237 249 339 minecraft:moss_block
setblock 237 246 349 minecraft:moss_block
setblock 237 246 353 minecraft:mushroom_stem
fill 237 246 354 237 249 354 minecraft:moss_block
setblock 237 246 358 minecraft:mushroom_stem
fill 237 246 359 237 249 359 minecraft:moss_block
setblock 237 246 362 minecraft:moss_block
setblock 237 246 363 minecraft:mushroom_stem
fill 238 246 323 241 246 323 minecraft:moss_block
setblock 238 246 327 minecraft:mushroom_stem
fill 238 246 328 238 248 328 minecraft:moss_block
setblock 238 246 332 minecraft:mushroom_stem
fill 238 246 333 238 249 333 minecraft:moss_block
setblock 238 246 337 minecraft:mushroom_stem
setblock 238 246 353 minecraft:moss_block
setblock 238 246 356 minecraft:moss_block
setblock 238 246 357 minecraft:mushroom_stem
fill 238 246 358 238 248 358 minecraft:moss_block
setblock 238 246 362 minecraft:mushroom_stem
fill 238 246 363 238 249 363 minecraft:moss_block
setblock 238 246 364 minecraft:shroomlight
setblock 239 246 331 minecraft:mushroom_stem
setblock 239 246 332 minecraft:moss_block
setblock 239 246 334 minecraft:dirt
fill 239 246 362 239 249 362 minecraft:moss_block
setblock 241 246 324 minecraft:mushroom_stem
setblock 242 246 323 minecraft:mushroom_stem
setblock 242 246 363 minecraft:mushroom_stem
fill 242 246 364 242 308 364 minecraft:moss_block
fill 243 246 323 243 247 323 minecraft:moss_block
fill 243 246 363 246 246 363 minecraft:moss_block
setblock 247 246 363 minecraft:mushroom_stem
fill 248 246 363 251 246 363 minecraft:moss_block
fill 249 246 362 252 246 362 minecraft:moss_block
setblock 252 246 323 minecraft:mushroom_stem
fill 252 246 361 253 246 361 minecraft:moss_block
setblock 252 246 363 minecraft:mushroom_stem
fill 253 246 323 253 249 323 minecraft:moss_block
setblock 253 246 362 minecraft:mushroom_stem
fill 253 246 363 253 249 363 minecraft:moss_block
setblock 254 246 361 minecraft:mushroom_stem
fill 254 246 362 254 249 362 minecraft:moss_block
setblock 255 246 360 minecraft:mushroom_stem
fill 255 246 361 255 249 361 minecraft:moss_block
fill 256 246 360 256 248 360 minecraft:moss_block
setblock 257 246 323 minecraft:mushroom_stem
setblock 257 246 363 minecraft:mushroom_stem
setblock 258 246 323 minecraft:moss_block
setblock 258 246 362 minecraft:mushroom_stem
fill 258 246 363 258 249 363 minecraft:moss_block
fill 259 246 362 259 248 362 minecraft:moss_block
setblock 260 246 323 minecraft:red_mushroom_block
fill 269 246 345 269 252 347 minecraft:dirt
fill 270 246 344 270 252 344 minecraft:dirt
fill 270 246 348 272 252 348 minecraft:dirt
fill 272 246 344 272 252 344 minecraft:dirt
fill 273 246 323 273 249 323 minecraft:moss_block
fill 273 246 330 273 246 331 minecraft:moss_block
setblock 273 246 332 minecraft:mushroom_stem
fill 273 246 333 273 249 333 minecraft:moss_block
setblock 273 246 337 minecraft:mushroom_stem
fill 273 246 345 273 252 345 minecraft:dirt
fill 273 246 347 273 252 347 minecraft:dirt
fill 274 246 324 275 246 324 minecraft:moss_block
fill 274 246 327 274 246 330 minecraft:moss_block
setblock 274 246 331 minecraft:mushroom_stem
fill 274 246 332 274 249 332 minecraft:moss_block
setblock 274 246 335 minecraft:moss_block
setblock 274 246 336 minecraft:mushroom_stem
fill 274 246 337 274 249 337 minecraft:moss_block
setblock 274 246 341 minecraft:mushroom_stem
setblock 274 246 350 minecraft:moss_block
setblock 274 246 351 minecraft:mushroom_stem
fill 274 246 352 274 247 352 minecraft:moss_block
setblock 274 246 356 minecraft:mushroom_stem
fill 274 246 363 274 248 363 minecraft:moss_block
setblock 275 246 325 minecraft:mushroom_stem
fill 275 246 326 275 249 326 minecraft:moss_block
setblock 275 246 330 minecraft:mushroom_stem
fill 275 246 331 275 249 331 minecraft:moss_block
setblock 275 246 335 minecraft:mushroom_stem
fill 275 246 336 275 249 336 minecraft:moss_block
setblock 275 246 340 minecraft:mushroom_stem
fill 275 246 341 275 249 341 minecraft:moss_block
setblock 275 246 345 minecraft:mushroom_stem
fill 275 246 346 275 248 346 minecraft:moss_block
setblock 275 246 350 minecraft:mushroom_stem
fill 275 246 351 275 249 351 minecraft:moss_block
setblock 275 246 355 minecraft:mushroom_stem
fill 275 246 356 275 249 356 minecraft:moss_block
setblock 275 246 359 minecraft:moss_block
setblock 275 246 360 minecraft:mushroom_stem
setblock 276 246 324 minecraft:mushroom_stem
fill 276 246 325 276 249 325 minecraft:moss_block
setblock 276 246 329 minecraft:mushroom_stem
fill 276 246 330 276 249 330 minecraft:moss_block
setblock 276 246 334 minecraft:mushroom_stem
fill 276 246 335 276 249 335 minecraft:moss_block
setblock 276 246 339 minecraft:mushroom_stem
fill 276 246 340 276 249 340 minecraft:moss_block
setblock 276 246 344 minecraft:mushroom_stem
fill 276 246 345 276 249 345 minecraft:moss_block
setblock 276 246 349 minecraft:mushroom_stem
fill 276 246 350 276 249 350 minecraft:moss_block
setblock 276 246 354 minecraft:mushroom_stem
fill 276 246 355 276 249 355 minecraft:moss_block
setblock 276 246 358 minecraft:moss_block
setblock 276 246 359 minecraft:mushroom_stem
fill 276 246 360 276 249 360 minecraft:moss_block
setblock 236 247 323 minecraft:mushroom_stem
fill 236 247 324 236 250 324 minecraft:moss_block
setblock 236 247 328 minecraft:mushroom_stem
fill 236 247 329 236 250 329 minecraft:moss_block
setblock 236 247 333 minecraft:mushroom_stem
fill 236 247 334 236 250 334 minecraft:moss_block
setblock 236 247 338 minecraft:mushroom_stem
fill 236 247 339 236 250 339 minecraft:moss_block
setblock 236 247 343 minecraft:mushroom_stem
setblock 236 247 344 minecraft:moss_block
setblock 236 247 348 minecraft:mushroom_stem
fill 236 247 349 236 248 349 minecraft:moss_block
setblock 236 247 353 minecraft:mushroom_stem
fill 236 247 354 236 250 354 minecraft:moss_block
setblock 236 247 358 minecraft:mushroom_stem
fill 236 247 359 236 250 359 minecraft:moss_block
setblock 236 247 362 minecraft:moss_block
setblock 236 247 363 minecraft:mushroom_stem
fill 237 247 323 240 247 323 minecraft:moss_block
setblock 237 247 327 minecraft:mushroom_stem
fill 237 247 328 237 250 328 minecraft:moss_block
setblock 237 247 332 minecraft:mushroom_stem
fill 237 247 333 237 250 333 minecraft:moss_block
setblock 237 247 337 minecraft:mushroom_stem
fill 237 247 338 237 250 338 minecraft:moss_block
setblock 237 247 352 minecraft:mushroom_stem
fill 237 247 353 237 249 353 minecraft:moss_block
setblock 237 247 357 minecraft:mushroom_stem
fill 237 247 358 237 250 358 minecraft:moss_block
setblock 237 247 362 minecraft:mushroom_stem
fill 237 247 363 237 250 363 minecraft:moss_block
setblock 238 247 326 minecraft:mushroom_stem
setblock 238 247 327 minecraft:moss_block
setblock 238 247 331 minecraft:mushroom_stem
fill 238 247 332 238 249 332 minecraft:moss_block
setblock 238 247 336 minecraft:mushroom_stem
setblock 238 247 337 minecraft:moss_block
setblock 238 247 356 minecraft:mushroom_stem
fill 238 247 357 238 248 357 minecraft:moss_block
fill 238 247 359 238 248 359 minecraft:moss_block
fill 238 247 362 238 250 362 minecraft:moss_block
fill 238 247 364 238 293 364 minecraft:moss_block
fill 239 247 333 241 253 333 minecraft:mushroom_stem
setblock 240 247 324 minecraft:mushroom_stem
fill 240 247 332 240 253 332 minecraft:mushroom_stem
fill 240 247 334 240 253 334 minecraft:mushroom_stem
setblock 241 247 323 minecraft:mushroom_stem
setblock 241 247 363 minecraft:mushroom_stem
setblock 242 247 322 minecraft:shroomlight
fill 242 247 323 242 248 323 minecraft:moss_block
fill 242 247 363 245 247 363 minecraft:moss_block
setblock 246 247 363 minecraft:mushroom_stem
fill 247 247 363 250 247 363 minecraft:moss_block
fill 248 247 358 248 251 358 minecraft:dirt
fill 248 247 362 251 247 362 minecraft:moss_block
fill 249 247 357 249 251 357 minecraft:dirt
fill 249 247 359 249 251 359 minecraft:dirt
fill 250 247 358 250 251 358 minecraft:dirt
setblock 251 247 323 minecraft:mushroom_stem
fill 251 247 361 252 247 361 minecraft:moss_block
setblock 251 247 363 minecraft:mushroom_stem
fill 252 247 323 252 250 323 minecraft:moss_block
setblock 252 247 362 minecraft:mushroom_stem
fill 252 247 363 252 250 363 minecraft:moss_block
setblock 253 247 360 minecraft:moss_block
setblock 253 247 361 minecraft:mushroom_stem
fill 253 247 362 253 250 362 minecraft:moss_block
setblock 254 247 360 minecraft:mushroom_stem
fill 254 247 361 254 250 361 minecraft:moss_block
fill 255 247 360 255 249 360 minecraft:moss_block
setblock 256 247 323 minecraft:mushroom_stem
setblock 256 247 363 minecraft:mushroom_stem
setblock 257 247 323 minecraft:moss_block
setblock 257 247 362 minecraft:mushroom_stem
fill 257 247 363 257 250 363 minecraft:moss_block
setblock 258 247 361 minecraft:mushroom_stem
fill 258 247 362 258 249 362 minecraft:moss_block
fill 269 247 344 269 252 344 minecraft:dirt
fill 269 247 348 269 252 348 minecraft:dirt
fill 271 247 343 271 252 343 minecraft:dirt
fill 272 247 323 272 250 323 minecraft:moss_block
setblock 273 247 330 minecraft:moss_block
setblock 273 247 331 minecraft:mushroom_stem
fill 273 247 332 273 250 332 minecraft:moss_block
fill 273 247 334 273 247 335 minecraft:moss_block
setblock 273 247 336 minecraft:mushroom_stem
fill 273 247 337 273 249 338 minecraft:moss_block
fill 273 247 344 273 252 344 minecraft:dirt
fill 273 247 348 273 252 348 minecraft:dirt
fill 273 247 363 273 249 363 minecraft:moss_block
setblock 274 247 324 minecraft:moss_block
fill 274 247 327 274 247 329 minecraft:moss_block
setblock 274 247 330 minecraft:mushroom_stem
fill 274 247 331 274 250 331 minecraft:moss_block
setblock 274 247 335 minecraft:mushroom_stem
fill 274 247 336 274 250 336 minecraft:moss_block
fill 274 247 338 274 247 339 minecraft:moss_block
setblock 274 247 340 minecraft:mushroom_stem
fill 274 247 341 274 250 341 minecraft:moss_block
fill 274 247 346 274 252 346 minecraft:dirt
setblock 274 247 351 minecraft:moss_block
setblock 274 247 355 minecraft:mushroom_stem
fill 274 247 356 274 248 356 minecraft:moss_block
setblock 275 247 324 minecraft:mushroom_stem
fill 275 247 325 275 249 325 minecraft:moss_block
setblock 275 247 329 minecraft:mushroom_stem
fill 275 247 330 275 250 330 minecraft:moss_block
setblock 275 247 334 minecraft:mushroom_stem
fill 275 247 335 275 250 335 minecraft:moss_block
setblock 275 247 339 minecraft:mushroom_stem
fill 275 247 340 275 250 340 minecraft:moss_block
setblock 275 247 344 minecraft:mushroom_stem
fill 275 247 345 275 248 345 minecraft:moss_block
setblock 275 247 349 minecraft:mushroom_stem
fill 275 247 350 275 248 350 minecraft:moss_block
setblock 275 247 354 minecraft:mushroom_stem
fill 275 247 355 275 250 355 minecraft:moss_block
setblock 275 247 359 minecraft:mushroom_stem
fill 275 247 360 275 250 360 minecraft:moss_block
setblock 275 247 363 minecraft:moss_block
setblock 276 247 323 minecraft:mushroom_stem
fill 276 247 324 276 250 324 minecraft:moss_block
setblock 276 247 328 minecraft:mushroom_stem
fill 276 247 329 276 250 329 minecraft:moss_block
setblock 276 247 333 minecraft:mushroom_stem
fill 276 247 334 276 250 334 minecraft:moss_block
setblock 276 247 338 minecraft:mushroom_stem
fill 276 247 339 276 250 339 minecraft:moss_block
setblock 276 247 343 minecraft:mushroom_stem
fill 276 247 344 276 250 344 minecraft:moss_block
setblock 276 247 348 minecraft:mushroom_stem
fill 276 247 349 276 249 349 minecraft:moss_block
setblock 276 247 353 minecraft:mushroom_stem
fill 276 247 354 276 250 354 minecraft:moss_block
setblock 276 247 358 minecraft:mushroom_stem
fill 276 247 359 276 250 359 minecraft:moss_block
setblock 276 247 363 minecraft:mushroom_stem
setblock 277 247 363 minecraft:shroomlight
fill 236 248 323 239 248 323 minecraft:moss_block
setblock 236 248 327 minecraft:mushroom_stem
fill 236 248 328 236 251 328 minecraft:moss_block
setblock 236 248 332 minecraft:mushroom_stem
fill 236 248 333 236 251 333 minecraft:moss_block
setblock 236 248 337 minecraft:mushroom_stem
fill 236 248 338 236 251 338 minecraft:moss_block
setblock 236 248 342 minecraft:mushroom_stem
setblock 236 248 343 minecraft:moss_block
setblock 236 248 347 minecraft:red_mushroom_block
setblock 236 248 348 minecraft:moss_block
setblock 236 248 352 minecraft:mushroom_stem
fill 236 248 353 236 251 353 minecraft:moss_block
setblock 236 248 357 minecraft:mushroom_stem
fill 236 248 358 236 251 358 minecraft:moss_block
setblock 236 248 362 minecraft:mushroom_stem
fill 236 248 363 236 251 363 minecraft:moss_block
setblock 237 248 326 minecraft:mushroom_stem
fill 237 248 327 237 250 327 minecraft:moss_block
setblock 237 248 331 minecraft:mushroom_stem
fill 237 248 332 237 251 332 minecraft:moss_block
setblock 237 248 336 minecraft:mushroom_stem
fill 237 248 337 237 251 337 minecraft:moss_block
setblock 237 248 352 minecraft:moss_block
setblock 237 248 356 minecraft:mushroom_stem
fill 237 248 357 237 251 357 minecraft:moss_block
setblock 237 248 361 minecraft:mushroom_stem
fill 237 248 362 237 251 362 minecraft:moss_block
setblock 238 248 330 minecraft:mushroom_stem
fill 238 248 331 238 249 331 minecraft:moss_block
setblock 238 248 335 minecraft:mushroom_stem
setblock 238 248 336 minecraft:moss_block
setblock 238 248 356 minecraft:moss_block
setblock 239 248 324 minecraft:mushroom_stem
setblock 240 248 323 minecraft:mushroom_stem
setblock 240 248 363 minecraft:mushroom_stem
setblock 241 248 323 minecraft:moss_block
fill 241 248 363 244 248 363 minecraft:moss_block
fill 242 248 322 242 308 322 minecraft:moss_block
setblock 245 248 363 minecraft:mushroom_stem
fill 246 248 363 249 248 363 minecraft:moss_block
setblock 248 248 323 minecraft:red_mushroom_block
fill 248 248 362 250 248 362 minecraft:moss_block
fill 250 248 361 251 248 361 minecraft:moss_block
setblock 250 248 363 minecraft:mushroom_stem
fill 251 248 323 251 249 323 minecraft:moss_block
setblock 251 248 362 minecraft:mushroom_stem
fill 251 248 363 251 251 363 minecraft:moss_block
setblock 252 248 360 minecraft:moss_block
setblock 252 248 361 minecraft:mushroom_stem
fill 252 248 362 252 251 362 minecraft:moss_block
setblock 253 248 360 minecraft:mushroom_stem
fill 253 248 361 253 251 361 minecraft:moss_block
fill 254 248 360 254 250 360 minecraft:moss_block
setblock 255 248 323 minecraft:mushroom_stem
setblock 255 248 363 minecraft:mushroom_stem
setblock 256 248 323 minecraft:moss_block
setblock 256 248 362 minecraft:mushroom_stem
fill 256 248 363 256 251 363 minecraft:moss_block
setblock 257 248 361 minecraft:mushroom_stem
fill 257 248 362 257 251 362 minecraft:moss_block
setblock 260 248 363 minecraft:mushroom_stem
setblock 264 248 363 minecraft:red_mushroom_block
setblock 267 248 323 minecraft:red_mushroom_block
fill 268 248 345 268 252 347 minecraft:dirt
fill 269 248 349 273 249 352 minecraft:dirt
fill 270 248 343 270 252 343 minecraft:dirt
fill 272 248 343 273 252 343 minecraft:dirt
fill 273 248 331 273 249 331 minecraft:moss_block
setblock 273 248 334 minecraft:moss_block
setblock 273 248 335 minecraft:mushroom_stem
fill 273 248 336 273 251 336 minecraft:moss_block
setblock 273 248 339 minecraft:moss_block
setblock 274 248 323 minecraft:moss_block
setblock 274 248 324 minecraft:mushroom_stem
setblock 274 248 328 minecraft:moss_block
setblock 274 248 329 minecraft:mushroom_stem
fill 274 248 330 274 251 330 minecraft:moss_block
setblock 274 248 334 minecraft:mushroom_stem
fill 274 248 335 274 251 335 minecraft:moss_block
setblock 274 248 338 minecraft:moss_block
setblock 274 248 339 minecraft:mushroom_stem
fill 274 248 340 274 251 340 minecraft:moss_block
fill 274 248 345 274 252 345 minecraft:dirt
fill 274 248 347 274 252 347 minecraft:dirt
setblock 274 248 350 minecraft:dirt
setblock 274 248 354 minecraft:mushroom_stem
setblock 274 248 355 minecraft:moss_block
setblock 275 248 323 minecraft:mushroom_stem
fill 275 248 324 275 249 324 minecraft:moss_block
setblock 275 248 328 minecraft:mushroom_stem
fill 275 248 329 275 251 329 minecraft:moss_block
setblock 275 248 333 minecraft:mushroom_stem
fill 275 248 334 275 251 334 minecraft:moss_block
setblock 275 248 338 minecraft:mushroom_stem
fill 275 248 339 275 251 339 minecraft:moss_block
setblock 275 248 343 minecraft:mushroom_stem
fill 275 248 344 275 249 344 minecraft:moss_block
setblock 275 248 348 minecraft:mushroom_stem
setblock 275 248 349 minecraft:moss_block
setblock 275 248 353 minecraft:mushroom_stem
fill 275 248 354 275 250 354 minecraft:moss_block
setblock 275 248 357 minecraft:moss_block
setblock 275 248 358 minecraft:mushroom_stem
fill 275 248 359 275 251 359 minecraft:moss_block
fill 275 248 361 276 248 361 minecraft:moss_block
setblock 275 248 363 minecraft:mushroom_stem
fill 276 248 323 276 251 323 minecraft:moss_block
setblock 276 248 327 minecraft:mushroom_stem
fill 276 248 328 276 251 328 minecraft:moss_block
setblock 276 248 332 minecraft:mushroom_stem
fill 276 248 333 276 251 333 minecraft:moss_block
setblock 276 248 337 minecraft:mushroom_stem
fill 276 248 338 276 251 338 minecraft:moss_block
setblock 276 248 342 minecraft:mushroom_stem
fill 276 248 343 276 251 343 minecraft:moss_block
setblock 276 248 347 minecraft:mushroom_stem
fill 276 248 348 276 249 348 minecraft:moss_block
setblock 276 248 352 minecraft:mushroom_stem
fill 276 248 353 276 251 353 minecraft:moss_block
setblock 276 248 357 minecraft:mushroom_stem
fill 276 248 358 276 251 358 minecraft:moss_block
setblock 276 248 362 minecraft:mushroom_stem
fill 276 248 363 277 251 363 minecraft:moss_block
fill 235 249 361 235 308 361 minecraft:moss_block
fill 236 249 323 238 249 323 minecraft:moss_block
setblock 236 249 326 minecraft:mushroom_stem
fill 236 249 327 236 252 327 minecraft:moss_block
setblock 236 249 331 minecraft:mushroom_stem
fill 236 249 332 236 252 332 minecraft:moss_block
setblock 236 249 336 minecraft:mushroom_stem
fill 236 249 337 236 252 337 minecraft:moss_block
setblock 236 249 341 minecraft:mushroom_stem
fill 236 249 342 236 250 342 minecraft:moss_block
setblock 236 249 351 minecraft:mushroom_stem
fill 236 249 352 236 250 352 minecraft:moss_block
setblock 236 249 356 minecraft:mushroom_stem
fill 236 249 357 236 252 357 minecraft:moss_block
setblock 236 249 361 minecraft:mushroom_stem
fill 236 249 362 236 252 362 minecraft:moss_block
setblock 237 249 325 minecraft:mushroom_stem
setblock 237 249 326 minecraft:moss_block
setblock 237 249 330 minecraft:mushroom_stem
fill 237 249 331 237 251 331 minecraft:moss_block
setblock 237 249 334 minecraft:moss_block
setblock 237 249 335 minecraft:mushroom_stem
fill 237 249 336 237 251 336 minecraft:moss_block
setblock 237 249 355 minecraft:mushroom_stem
fill 237 249 356 237 251 356 minecraft:moss_block
setblock 237 249 360 minecraft:mushroom_stem
fill 237 249 361 237 252 361 minecraft:moss_block
setblock 238 249 324 minecraft:mushroom_stem
setblock 238 249 325 minecraft:light[level=12]
setblock 238 249 334 minecraft:mushroom_stem
setblock 238 249 335 minecraft:moss_block
setblock 238 249 339 minecraft:light[level=12]
setblock 238 249 346 minecraft:light[level=12]
setblock 238 249 353 minecraft:light[level=12]
setblock 238 249 360 minecraft:light[level=12]
setblock 239 249 323 minecraft:mushroom_stem
setblock 239 249 363 minecraft:mushroom_stem
setblock 240 249 323 minecraft:moss_block
setblock 240 249 362 minecraft:mushroom_stem
fill 240 249 363 243 249 363 minecraft:moss_block
setblock 242 249 323 minecraft:red_mushroom_block
setblock 244 249 363 minecraft:mushroom_stem
setblock 245 249 325 minecraft:light[level=12]
setblock 245 249 332 minecraft:light[level=12]
setblock 245 249 339 minecraft:light[level=12]
setblock 245 249 346 minecraft:light[level=12]
setblock 245 249 353 minecraft:light[level=12]
setblock 245 249 360 minecraft:light[level=12]
fill 245 249 363 248 249 363 minecraft:moss_block
fill 247 249 362 249 249 362 minecraft:moss_block
fill 249 249 361 250 249 361 minecraft:moss_block
setblock 249 249 363 minecraft:mushroom_stem
setblock 250 249 362 minecraft:mushroom_stem
fill 250 249 363 250 252 363 minecraft:moss_block
fill 251 249 356 251 265 356 minecraft:iron_block
setblock 251 249 361 minecraft:mushroom_stem
fill 251 249 362 251 252 362 minecraft:moss_block
setblock 252 249 325 minecraft:light[level=12]
setblock 252 249 332 minecraft:light[level=12]
setblock 252 249 339 minecraft:light[level=12]
setblock 252 249 353 minecraft:light[level=12]
setblock 252 249 360 minecraft:mushroom_stem
fill 252 249 361 252 252 361 minecraft:moss_block
fill 253 249 360 253 251 360 minecraft:moss_block
setblock 254 249 323 minecraft:mushroom_stem
setblock 254 249 363 minecraft:mushroom_stem
setblock 255 249 362 minecraft:mushroom_stem
fill 255 249 363 255 252 363 minecraft:moss_block
setblock 256 249 361 minecraft:mushroom_stem
fill 256 249 362 256 252 362 minecraft:moss_block
setblock 257 249 361 minecraft:moss_block
setblock 259 249 325 minecraft:light[level=12]
setblock 259 249 332 minecraft:light[level=12]
setblock 259 249 339 minecraft:light[level=12]
setblock 259 249 346 minecraft:light[level=12]
setblock 259 249 353 minecraft:light[level=12]
setblock 259 249 360 minecraft:light[level=12]
setblock 259 249 363 minecraft:mushroom_stem
setblock 261 249 323 minecraft:red_mushroom_block
setblock 266 249 325 minecraft:light[level=12]
setblock 266 249 332 minecraft:light[level=12]
setblock 266 249 339 minecraft:light[level=12]
setblock 266 249 346 minecraft:light[level=12]
setblock 266 249 353 minecraft:light[level=12]
setblock 266 249 360 minecraft:light[level=12]
fill 268 249 344 268 252 344 minecraft:dirt
fill 268 249 348 268 252 348 minecraft:dirt
fill 269 249 343 269 252 343 minecraft:dirt
setblock 270 249 363 minecraft:red_mushroom_block
fill 271 249 342 272 252 342 minecraft:dirt
fill 272 249 363 272 250 363 minecraft:moss_block
setblock 273 249 325 minecraft:light[level=12]
setblock 273 249 334 minecraft:mushroom_stem
fill 273 249 335 273 252 335 minecraft:moss_block
setblock 273 249 339 minecraft:mushroom_stem
setblock 273 249 353 minecraft:light[level=12]
setblock 273 249 360 minecraft:light[level=12]
setblock 274 249 323 minecraft:mushroom_stem
setblock 274 249 328 minecraft:mushroom_stem
fill 274 249 329 274 250 329 minecraft:moss_block
setblock 274 249 333 minecraft:mushroom_stem
fill 274 249 334 274 252 334 minecraft:moss_block
setblock 274 249 338 minecraft:mushroom_stem
fill 274 249 339 274 252 339 minecraft:moss_block
fill 274 249 344 274 252 344 minecraft:dirt
fill 274 249 348 274 252 348 minecraft:dirt
setblock 274 249 363 minecraft:mushroom_stem
fill 275 249 323 275 252 323 minecraft:moss_block
setblock 275 249 327 minecraft:mushroom_stem
fill 275 249 328 275 252 328 minecraft:moss_block
setblock 275 249 332 minecraft:mushroom_stem
fill 275 249 333 275 252 333 minecraft:moss_block
setblock 275 249 337 minecraft:mushroom_stem
fill 275 249 338 275 252 338 minecraft:moss_block
setblock 275 249 342 minecraft:mushroom_stem
fill 275 249 343 275 251 343 minecraft:moss_block
fill 275 249 346 275 252 346 minecraft:dirt
setblock 275 249 352 minecraft:mushroom_stem
setblock 275 249 353 minecraft:moss_block
setblock 275 249 357 minecraft:mushroom_stem
fill 275 249 358 275 251 358 minecraft:moss_block
setblock 275 249 361 minecraft:moss_block
fill 275 249 363 275 252 363 minecraft:moss_block
setblock 276 249 326 minecraft:mushroom_stem
fill 276 249 327 276 252 327 minecraft:moss_block
setblock 276 249 331 minecraft:mushroom_stem
fill 276 249 332 276 252 332 minecraft:moss_block
setblock 276 249 336 minecraft:mushroom_stem
fill 276 249 337 276 252 337 minecraft:moss_block
setblock 276 249 341 minecraft:mushroom_stem
fill 276 249 342 276 252 342 minecraft:moss_block
setblock 276 249 346 minecraft:mushroom_stem
setblock 276 249 347 minecraft:moss_block
setblock 276 249 351 minecraft:mushroom_stem
fill 276 249 352 276 250 352 minecraft:moss_block
setblock 276 249 356 minecraft:mushroom_stem
fill 276 249 357 276 252 357 minecraft:moss_block
setblock 276 249 361 minecraft:mushroom_stem
fill 276 249 362 276 252 362 minecraft:moss_block
fill 235 250 346 235 264 355 minecraft:moss_block
setblock 235 250 356 minecraft:shroomlight
fill 235 250 357 235 250 359 minecraft:moss_block
fill 236 250 323 237 250 323 minecraft:moss_block
setblock 236 250 325 minecraft:mushroom_stem
fill 236 250 326 236 253 326 minecraft:moss_block
setblock 236 250 330 minecraft:mushroom_stem
fill 236 250 331 236 253 331 minecraft:moss_block
setblock 236 250 335 minecraft:mushroom_stem
fill 236 250 336 236 253 336 minecraft:moss_block
setblock 236 250 340 minecraft:mushroom_stem
fill 236 250 341 236 253 341 minecraft:moss_block
setblock 236 250 355 minecraft:mushroom_stem
fill 236 250 356 236 253 356 minecraft:moss_block
setblock 236 250 360 minecraft:mushroom_stem
fill 236 250 361 236 253 361 minecraft:moss_block
setblock 237 250 329 minecraft:mushroom_stem
setblock 237 250 330 minecraft:moss_block
setblock 237 250 334 minecraft:mushroom_stem
fill 237 250 335 237 251 335 minecraft:moss_block
setblock 237 250 355 minecraft:moss_block
setblock 237 250 359 minecraft:mushroom_stem
fill 237 250 360 237 253 360 minecraft:moss_block
setblock 238 250 323 minecraft:mushroom_stem
setblock 238 250 363 minecraft:mushroom_stem
fill 239 250 323 239 251 323 minecraft:moss_block
setblock 239 250 362 minecraft:mushroom_stem
fill 239 250 363 242 250 363 minecraft:moss_block
setblock 243 250 363 minecraft:mushroom_stem
fill 244 250 363 247 250 363 minecraft:moss_block
fill 247 250 362 248 250 362 minecraft:moss_block
fill 248 250 357 248 251 357 minecraft:dirt
fill 248 250 359 248 251 359 minecraft:dirt
setblock 248 250 363 minecraft:mushroom_stem
setblock 249 250 361 minecraft:moss_block
setblock 249 250 362 minecraft:mushroom_stem
fill 249 250 363 249 253 363 minecraft:moss_block
fill 250 250 357 250 251 357 minecraft:dirt
fill 250 250 359 250 251 359 minecraft:dirt
setblock 250 250 361 minecraft:mushroom_stem
fill 250 250 362 250 253 362 minecraft:moss_block
setblock 251 250 360 minecraft:mushroom_stem
fill 251 250 361 251 253 361 minecraft:moss_block
fill 252 250 360 252 253 360 minecraft:moss_block
setblock 253 250 323 minecraft:mushroom_stem
setblock 253 250 363 minecraft:mushroom_stem
setblock 254 250 362 minecraft:mushroom_stem
fill 254 250 363 254 253 363 minecraft:moss_block
setblock 255 250 323 minecraft:red_mushroom_block
setblock 255 250 361 minecraft:mushroom_stem
fill 255 250 362 255 253 362 minecraft:moss_block
setblock 256 250 361 minecraft:moss_block
setblock 258 250 363 minecraft:mushroom_stem
setblock 264 250 322 minecraft:red_mushroom_block
fill 267 250 344 267 252 347 minecraft:dirt
fill 268 250 343 268 252 343 minecraft:dirt
fill 268 250 349 270 252 349 minecraft:dirt
fill 269 250 342 270 252 342 minecraft:dirt
fill 270 250 350 272 256 350 minecraft:mushroom_stem
fill 271 250 349 271 256 349 minecraft:mushroom_stem
fill 271 250 351 271 256 351 minecraft:mushroom_stem
fill 272 250 349 274 252 349 minecraft:dirt
setblock 273 250 323 minecraft:mushroom_stem
setblock 273 250 333 minecraft:mushroom_stem
fill 273 250 334 273 252 334 minecraft:moss_block
setblock 273 250 337 minecraft:moss_block
setblock 273 250 338 minecraft:mushroom_stem
fill 273 250 339 273 251 339 minecraft:moss_block
fill 273 250 342 273 252 342 minecraft:dirt
setblock 273 250 363 minecraft:mushroom_stem
fill 274 250 323 274 253 323 minecraft:moss_block
setblock 274 250 332 minecraft:mushroom_stem
fill 274 250 333 274 253 333 minecraft:moss_block
setblock 274 250 337 minecraft:mushroom_stem
fill 274 250 338 274 253 338 minecraft:moss_block
fill 274 250 343 274 252 343 minecraft:dirt
fill 274 250 363 274 253 363 minecraft:moss_block
setblock 275 250 326 minecraft:mushroom_stem
fill 275 250 327 275 251 327 minecraft:moss_block
setblock 275 250 331 minecraft:mushroom_stem
fill 275 250 332 275 253 332 minecraft:moss_block
setblock 275 250 336 minecraft:mushroom_stem
fill 275 250 337 275 253 337 minecraft:moss_block
setblock 275 250 341 minecraft:mushroom_stem
fill 275 250 342 275 253 342 minecraft:moss_block
fill 275 250 344 275 252 345 minecraft:dirt
fill 275 250 347 275 252 347 minecraft:dirt
setblock 275 250 356 minecraft:mushroom_stem
fill 275 250 357 275 251 357 minecraft:moss_block
setblock 275 250 361 minecraft:mushroom_stem
setblock 276 250 325 minecraft:mushroom_stem
fill 276 250 326 276 253 326 minecraft:moss_block
setblock 276 250 330 minecraft:mushroom_stem
fill 276 250 331 276 253 331 minecraft:moss_block
setblock 276 250 335 minecraft:mushroom_stem
fill 276 250 336 276 253 336 minecraft:moss_block
setblock 276 250 340 minecraft:mushroom_stem
fill 276 250 341 276 253 341 minecraft:moss_block
setblock 276 250 345 minecraft:mushroom_stem
setblock 276 250 346 minecraft:red_mushroom_block
setblock 276 250 350 minecraft:mushroom_stem
setblock 276 250 351 minecraft:moss_block
setblock 276 250 355 minecraft:mushroom_stem
fill 276 250 356 276 253 356 minecraft:moss_block
setblock 276 250 360 minecraft:mushroom_stem
fill 276 250 361 276 253 361 minecraft:moss_block
fill 235 251 356 235 308 357 minecraft:moss_block
setblock 235 251 358 minecraft:red_mushroom_block
fill 235 251 359 235 255 359 minecraft:moss_block
setblock 236 251 323 minecraft:moss_block
setblock 236 251 324 minecraft:mushroom_stem
fill 236 251 325 236 254 325 minecraft:moss_block
setblock 236 251 329 minecraft:mushroom_stem
fill 236 251 330 236 253 330 minecraft:moss_block
setblock 236 251 334 minecraft:mushroom_stem
fill 236 251 335 236 254 335 minecraft:moss_block
setblock 236 251 339 minecraft:mushroom_stem
fill 236 251 340 236 254 340 minecraft:moss_block
setblock 236 251 346 minecraft:red_mushroom_block
setblock 236 251 354 minecraft:mushroom_stem
fill 236 251 355 236 253 355 minecraft:moss_block
setblock 236 251 359 minecraft:mushroom_stem
fill 236 251 360 236 254 360 minecraft:moss_block
setblock 237 251 323 minecraft:mushroom_stem
setblock 237 251 333 minecraft:mushroom_stem
setblock 237 251 334 minecraft:moss_block
setblock 237 251 358 minecraft:mushroom_stem
fill 237 251 359 237 254 359 minecraft:moss_block
setblock 237 251 363 minecraft:mushroom_stem
fill 238 251 323 238 254 323 minecraft:moss_block
setblock 238 251 362 minecraft:mushroom_stem
fill 238 251 363 241 251 363 minecraft:moss_block
fill 239 251 362 239 254 362 minecraft:moss_block
setblock 242 251 363 minecraft:mushroom_stem
fill 243 251 363 246 251 363 minecraft:moss_block
fill 246 251 362 247 251 362 minecraft:moss_block
setblock 247 251 363 minecraft:mushroom_stem
setblock 248 251 361 minecraft:moss_block
setblock 248 251 362 minecraft:mushroom_stem
fill 248 251 363 248 254 363 minecraft:moss_block
setblock 249 251 323 minecraft:red_mushroom_block
setblock 249 251 361 minecraft:mushroom_stem
fill 249 251 362 249 254 362 minecraft:moss_block
fill 250 251 361 250 254 361 minecraft:moss_block
fill 251 251 360 251 254 360 minecraft:moss_block
setblock 252 251 363 minecraft:mushroom_stem
setblock 253 251 362 minecraft:mushroom_stem
fill 253 251 363 253 254 363 minecraft:moss_block
setblock 254 251 361 minecraft:mushroom_stem
fill 254 251 362 254 254 362 minecraft:moss_block
fill 255 251 361 255 252 361 minecraft:moss_block
setblock 257 251 363 minecraft:mushroom_stem
setblock 258 251 363 minecraft:moss_block
setblock 263 251 363 minecraft:red_mushroom_block
fill 264 251 322 264 308 322 minecraft:moss_block
fill 267 251 343 267 252 343 minecraft:dirt
fill 267 251 348 267 252 348 minecraft:dirt
fill 268 251 342 268 252 342 minecraft:dirt
fill 269 251 350 269 252 350 minecraft:dirt
fill 270 251 341 272 252 341 minecraft:dirt
setblock 271 251 323 minecraft:moss_block
setblock 271 251 363 minecraft:moss_block
setblock 272 251 323 minecraft:mushroom_stem
setblock 272 251 363 minecraft:mushroom_stem
fill 273 251 323 273 254 323 minecraft:moss_block
setblock 273 251 333 minecraft:moss_block
setblock 273 251 337 minecraft:mushroom_stem
fill 273 251 338 273 253 338 minecraft:moss_block
fill 273 251 350 273 252 350 minecraft:dirt
fill 273 251 363 273 254 363 minecraft:moss_block
setblock 274 251 331 minecraft:mushroom_stem
fill 274 251 332 274 252 332 minecraft:moss_block
setblock 274 251 336 minecraft:mushroom_stem
fill 274 251 337 274 254 337 minecraft:moss_block
setblock 274 251 341 minecraft:mushroom_stem
fill 274 251 342 274 252 342 minecraft:dirt
setblock 275 251 330 minecraft:mushroom_stem
fill 275 251 331 275 254 331 minecraft:moss_block
setblock 275 251 335 minecraft:mushroom_stem
fill 275 251 336 275 254 336 minecraft:moss_block
setblock 275 251 340 minecraft:mushroom_stem
fill 275 251 341 275 254 341 minecraft:moss_block
fill 275 251 348 275 252 348 minecraft:dirt
setblock 275 251 356 minecraft:moss_block
setblock 275 251 360 minecraft:mushroom_stem
setblock 275 251 361 minecraft:moss_block
setblock 276 251 324 minecraft:mushroom_stem
fill 276 251 325 276 254 325 minecraft:moss_block
setblock 276 251 329 minecraft:mushroom_stem
fill 276 251 330 276 254 330 minecraft:moss_block
setblock 276 251 334 minecraft:mushroom_stem
fill 276 251 335 276 254 335 minecraft:moss_block
setblock 276 251 339 minecraft:mushroom_stem
fill 276 251 340 276 254 340 minecraft:moss_block
setblock 276 251 344 minecraft:mushroom_stem
fill 276 251 346 276 252 346 minecraft:dirt
setblock 276 251 354 minecraft:mushroom_stem
fill 276 251 355 276 252 355 minecraft:moss_block
setblock 276 251 359 minecraft:mushroom_stem
fill 276 251 360 276 254 360 minecraft:moss_block
fill 235 252 358 235 304 358 minecraft:moss_block
setblock 236 252 323 minecraft:mushroom_stem
fill 236 252 324 236 255 324 minecraft:moss_block
setblock 236 252 328 minecraft:mushroom_stem
fill 236 252 329 236 253 329 minecraft:moss_block
setblock 236 252 333 minecraft:mushroom_stem
fill 236 252 334 236 254 334 minecraft:moss_block
setblock 236 252 338 minecraft:mushroom_stem
fill 236 252 339 236 255 339 minecraft:moss_block
setblock 236 252 352 minecraft:red_mushroom_block
setblock 236 252 354 minecraft:moss_block
setblock 236 252 358 minecraft:mushroom_stem
fill 236 252 359 236 255 359 minecraft:moss_block
setblock 236 252 363 minecraft:mushroom_stem
fill 237 252 323 237 255 323 minecraft:moss_block
setblock 237 252 357 minecraft:mushroom_stem
fill 237 252 358 237 254 358 minecraft:moss_block
setblock 237 252 362 minecraft:mushroom_stem
fill 237 252 363 240 252 363 minecraft:moss_block
fill 238 252 362 238 255 362 minecraft:moss_block
setblock 241 252 363 minecraft:mushroom_stem
fill 242 252 363 245 252 363 minecraft:moss_block
setblock 243 252 323 minecraft:red_mushroom_block
fill 245 252 348 245 253 348 minecraft:shroomlight
fill 245 252 362 246 252 362 minecraft:moss_block
setblock 246 252 363 minecraft:mushroom_stem
setblock 247 252 362 minecraft:mushroom_stem
fill 247 252 363 247 255 363 minecraft:moss_block
setblock 248 252 361 minecraft:mushroom_stem
fill 248 252 362 248 255 362 minecraft:moss_block
fill 249 252 361 249 255 361 minecraft:moss_block
setblock 251 252 363 minecraft:mushroom_stem
setblock 252 252 362 minecraft:mushroom_stem
fill 252 252 363 252 255 363 minecraft:moss_block
setblock 253 252 361 minecraft:mushroom_stem
fill 253 252 362 253 255 362 minecraft:moss_block
fill 254 252 361 254 255 361 minecraft:moss_block
setblock 256 252 363 minecraft:mushroom_stem
fill 257 252 363 257 255 363 minecraft:moss_block
fill 266 252 344 266 252 348 minecraft:dirt
setblock 267 252 349 minecraft:dirt
setblock 268 252 323 minecraft:red_mushroom_block
setblock 268 252 350 minecraft:dirt
setblock 269 252 341 minecraft:dirt
setblock 269 252 363 minecraft:red_mushroom_block
setblock 270 252 351 minecraft:dirt
setblock 270 252 363 minecraft:moss_block
setblock 271 252 323 minecraft:mushroom_stem
setblock 271 252 363 minecraft:mushroom_stem
fill 272 252 323 272 255 323 minecraft:moss_block
setblock 272 252 351 minecraft:dirt
fill 272 252 363 272 255 363 minecraft:moss_block
setblock 273 252 336 minecraft:mushroom_stem
fill 273 252 337 273 253 337 minecraft:moss_block
setblock 273 252 341 minecraft:dirt
setblock 274 252 331 minecraft:moss_block
setblock 274 252 335 minecraft:mushroom_stem
fill 274 252 336 274 255 336 minecraft:moss_block
setblock 274 252 340 minecraft:mushroom_stem
fill 274 252 341 274 255 341 minecraft:moss_block
setblock 274 252 350 minecraft:dirt
setblock 275 252 329 minecraft:mushroom_stem
fill 275 252 330 275 253 330 minecraft:moss_block
setblock 275 252 334 minecraft:mushroom_stem
fill 275 252 335 275 255 335 minecraft:moss_block
setblock 275 252 339 minecraft:mushroom_stem
fill 275 252 340 275 255 340 minecraft:moss_block
setblock 275 252 343 minecraft:dirt
setblock 275 252 349 minecraft:dirt
setblock 275 252 359 minecraft:mushroom_stem
setblock 275 252 360 minecraft:moss_block
setblock 276 252 323 minecraft:mushroom_stem
fill 276 252 324 276 255 324 minecraft:moss_block
setblock 276 252 328 minecraft:mushroom_stem
fill 276 252 329 276 255 329 minecraft:moss_block
setblock 276 252 333 minecraft:mushroom_stem
fill 276 252 334 276 255 334 minecraft:moss_block
setblock 276 252 338 minecraft:mushroom_stem
fill 276 252 339 276 255 339 minecraft:moss_block
setblock 276 252 343 minecraft:mushroom_stem
setblock 276 252 344 minecraft:moss_block
setblock 276 252 345 minecraft:dirt
fill 276 252 347 276 252 348 minecraft:dirt
setblock 276 252 358 minecraft:mushroom_stem
fill 276 252 359 276 255 359 minecraft:moss_block
setblock 276 252 363 minecraft:mushroom_stem
fill 277 252 363 277 308 363 minecraft:moss_block
fill 236 253 323 236 256 323 minecraft:moss_block
setblock 236 253 327 minecraft:mushroom_stem
setblock 236 253 328 minecraft:moss_block
setblock 236 253 332 minecraft:mushroom_stem
fill 236 253 333 236 254 333 minecraft:moss_block
setblock 236 253 337 minecraft:mushroom_stem
fill 236 253 338 236 256 338 minecraft:moss_block
setblock 236 253 357 minecraft:mushroom_stem
fill 236 253 358 236 256 358 minecraft:moss_block
setblock 236 253 362 minecraft:mushroom_stem
fill 236 253 363 239 253 363 minecraft:moss_block
setblock 237 253 361 minecraft:mushroom_stem
fill 237 253 362 237 256 362 minecraft:moss_block
setblock 238 253 325 minecraft:light[level=15]
setblock 238 253 333 minecraft:light[level=15]
setblock 238 253 341 minecraft:light[level=15]
setblock 238 253 349 minecraft:light[level=15]
setblock 238 253 357 minecraft:light[level=15]
setblock 240 253 363 minecraft:mushroom_stem
fill 241 253 363 244 253 363 minecraft:moss_block
setblock 243 253 322 minecraft:shroomlight
fill 244 253 322 245 308 322 minecraft:moss_block
fill 244 253 362 245 253 362 minecraft:moss_block
setblock 245 253 363 minecraft:mushroom_stem
setblock 246 253 325 minecraft:light[level=15]
setblock 246 253 333 minecraft:light[level=15]
setblock 246 253 341 minecraft:light[level=15]
setblock 246 253 349 minecraft:light[level=15]
setblock 246 253 357 minecraft:light[level=15]
setblock 246 253 362 minecraft:mushroom_stem
fill 246 253 363 246 256 363 minecraft:moss_block
setblock 247 253 361 minecraft:mushroom_stem
fill 247 253 362 247 256 362 minecraft:moss_block
fill 248 253 361 248 256 361 minecraft:moss_block
setblock 250 253 323 minecraft:mushroom_stem
setblock 250 253 363 minecraft:mushroom_stem
fill 251 253 323 251 256 323 minecraft:moss_block
setblock 251 253 362 minecraft:mushroom_stem
fill 251 253 363 251 256 363 minecraft:moss_block
setblock 252 253 361 minecraft:mushroom_stem
fill 252 253 362 252 256 362 minecraft:moss_block
fill 253 253 361 253 256 361 minecraft:moss_block
setblock 254 253 325 minecraft:light[level=15]
setblock 254 253 333 minecraft:light[level=15]
setblock 254 253 341 minecraft:light[level=15]
setblock 254 253 349 minecraft:light[level=15]
setblock 254 253 357 minecraft:light[level=15]
setblock 255 253 363 minecraft:mushroom_stem
fill 256 253 323 256 254 323 minecraft:red_mushroom_block
setblock 256 253 362 minecraft:mushroom_stem
fill 256 253 363 256 256 363 minecraft:moss_block
setblock 262 253 323 minecraft:red_mushroom_block
setblock 262 253 325 minecraft:light[level=15]
setblock 262 253 333 minecraft:light[level=15]
setblock 262 253 341 minecraft:light[level=15]
setblock 262 253 349 minecraft:light[level=15]
setblock 262 253 357 minecraft:light[level=15]
setblock 269 253 363 minecraft:moss_block
setblock 270 253 323 minecraft:mushroom_stem
setblock 270 253 325 minecraft:light[level=15]
setblock 270 253 333 minecraft:light[level=15]
setblock 270 253 341 minecraft:light[level=15]
setblock 270 253 349 minecraft:light[level=15]
setblock 270 253 357 minecraft:light[level=15]
setblock 270 253 363 minecraft:mushroom_stem
fill 271 253 323 271 256 323 minecraft:moss_block
fill 271 253 346 271 256 346 minecraft:mushroom_stem
fill 271 253 363 271 256 363 minecraft:moss_block
fill 273 253 322 275 303 322 minecraft:moss_block
setblock 273 253 336 minecraft:moss_block
fill 273 253 362 274 254 362 minecraft:moss_block
setblock 274 253 334 minecraft:mushroom_stem
fill 274 253 335 274 255 335 minecraft:moss_block
setblock 274 253 339 minecraft:mushroom_stem
fill 274 253 340 274 256 340 minecraft:moss_block
setblock 275 253 323 minecraft:mushroom_stem
setblock 275 253 333 minecraft:mushroom_stem
fill 275 253 334 275 256 334 minecraft:moss_block
setblock 275 253 338 minecraft:mushroom_stem
fill 275 253 339 275 256 339 minecraft:moss_block
setblock 275 253 363 minecraft:mushroom_stem
setblock 276 253 322 minecraft:shroomlight
fill 276 253 323 276 256 323 minecraft:moss_block
setblock 276 253 327 minecraft:mushroom_stem
fill 276 253 328 276 256 328 minecraft:moss_block
setblock 276 253 332 minecraft:mushroom_stem
fill 276 253 333 276 256 333 minecraft:moss_block
setblock 276 253 337 minecraft:mushroom_stem
fill 276 253 338 276 256 338 minecraft:moss_block
setblock 276 253 342 minecraft:mushroom_stem
fill 276 253 343 276 256 343 minecraft:moss_block
setblock 276 253 353 minecraft:red_mushroom_block
setblock 276 253 357 minecraft:mushroom_stem
fill 276 253 358 276 256 358 minecraft:moss_block
setblock 276 253 362 minecraft:mushroom_stem
fill 276 253 363 276 256 363 minecraft:moss_block
setblock 235 254 330 minecraft:shroomlight
fill 235 254 331 235 304 333 minecraft:moss_block
setblock 236 254 326 minecraft:mushroom_stem
setblock 236 254 336 minecraft:mushroom_stem
fill 236 254 337 236 256 337 minecraft:moss_block
setblock 236 254 341 minecraft:mushroom_stem
setblock 236 254 356 minecraft:mushroom_stem
fill 236 254 357 236 257 357 minecraft:moss_block
setblock 236 254 361 minecraft:mushroom_stem
fill 236 254 362 236 256 363 minecraft:moss_block
setblock 237 254 360 minecraft:mushroom_stem
fill 237 254 361 237 257 361 minecraft:moss_block
fill 237 254 363 238 254 363 minecraft:moss_block
fill 238 254 331 239 257 335 minecraft:red_mushroom_block
setblock 239 254 363 minecraft:mushroom_stem
fill 240 254 331 242 257 332 minecraft:red_mushroom_block
setblock 240 254 333 minecraft:mushroom_stem
fill 240 254 334 242 257 335 minecraft:red_mushroom_block
setblock 240 254 362 minecraft:mushroom_stem
fill 240 254 363 243 254 363 minecraft:moss_block
fill 241 254 333 242 257 333 minecraft:red_mushroom_block
fill 242 254 362 244 254 362 minecraft:moss_block
fill 243 254 322 243 308 322 minecraft:moss_block
setblock 244 254 363 minecraft:mushroom_stem
fill 245 254 348 245 262 348 minecraft:dirt
setblock 245 254 362 minecraft:mushroom_stem
fill 245 254 363 245 257 363 minecraft:moss_block
setblock 246 254 361 minecraft:mushroom_stem
fill 246 254 362 246 257 362 minecraft:moss_block
fill 247 254 361 247 257 361 minecraft:moss_block
setblock 248 254 323 minecraft:moss_block
setblock 249 254 323 minecraft:mushroom_stem
setblock 249 254 363 minecraft:mushroom_stem
fill 250 254 323 250 257 323 minecraft:moss_block
fill 250 254 360 250 255 360 minecraft:moss_block
setblock 250 254 362 minecraft:mushroom_stem
fill 250 254 363 250 257 363 minecraft:moss_block
setblock 251 254 361 minecraft:mushroom_stem
fill 251 254 362 251 257 362 minecraft:moss_block
fill 252 254 323 252 255 323 minecraft:moss_block
fill 252 254 361 252 257 361 minecraft:moss_block
setblock 254 254 363 minecraft:mushroom_stem
setblock 255 254 362 minecraft:mushroom_stem
fill 255 254 363 255 257 363 minecraft:moss_block
fill 256 254 362 256 256 362 minecraft:moss_block
fill 262 254 364 262 308 364 minecraft:moss_block
setblock 263 254 364 minecraft:shroomlight
fill 264 254 364 265 308 364 minecraft:moss_block
setblock 268 254 363 minecraft:moss_block
setblock 269 254 323 minecraft:mushroom_stem
setblock 269 254 363 minecraft:mushroom_stem
fill 270 254 323 270 257 323 minecraft:moss_block
fill 270 254 363 270 257 363 minecraft:moss_block
fill 271 254 362 272 256 362 minecraft:moss_block
setblock 272 254 324 minecraft:moss_block
setblock 273 254 324 minecraft:mushroom_stem
setblock 274 254 323 minecraft:mushroom_stem
fill 274 254 324 274 257 324 minecraft:moss_block
setblock 274 254 334 minecraft:moss_block
setblock 274 254 338 minecraft:mushroom_stem
fill 274 254 339 274 257 339 minecraft:moss_block
setblock 274 254 363 minecraft:mushroom_stem
fill 275 254 323 275 257 323 minecraft:moss_block
setblock 275 254 332 minecraft:mushroom_stem
fill 275 254 333 275 256 333 minecraft:moss_block
setblock 275 254 337 minecraft:mushroom_stem
fill 275 254 338 275 257 338 minecraft:moss_block
setblock 275 254 342 minecraft:mushroom_stem
setblock 275 254 361 minecraft:moss_block
setblock 275 254 362 minecraft:mushroom_stem
fill 275 254 363 275 257 363 minecraft:moss_block
fill 276 254 322 276 308 322 minecraft:moss_block
setblock 276 254 326 minecraft:mushroom_stem
fill 276 254 327 276 257 327 minecraft:moss_block
setblock 276 254 331 minecraft:mushroom_stem
fill 276 254 332 276 257 332 minecraft:moss_block
setblock 276 254 336 minecraft:mushroom_stem
fill 276 254 337 276 257 337 minecraft:moss_block
setblock 276 254 341 minecraft:mushroom_stem
fill 276 254 342 276 257 342 minecraft:moss_block
setblock 276 254 347 minecraft:red_mushroom_block
setblock 276 254 357 minecraft:moss_block
setblock 276 254 361 minecraft:mushroom_stem
fill 276 254 362 276 257 362 minecraft:moss_block
fill 235 255 330 235 299 330 minecraft:moss_block
setblock 236 255 325 minecraft:mushroom_stem
fill 236 255 326 236 258 326 minecraft:moss_block
setblock 236 255 335 minecraft:mushroom_stem
setblock 236 255 336 minecraft:moss_block
setblock 236 255 340 minecraft:mushroom_stem
fill 236 255 341 236 258 341 minecraft:moss_block
setblock 236 255 345 minecraft:red_mushroom_block
fill 236 255 356 236 257 356 minecraft:moss_block
setblock 236 255 360 minecraft:mushroom_stem
fill 236 255 361 236 258 361 minecraft:moss_block
fill 237 255 332 237 256 334 minecraft:red_mushroom_block
setblock 237 255 359 minecraft:mushroom_stem
fill 237 255 360 237 258 360 minecraft:moss_block
setblock 237 255 363 minecraft:moss_block
setblock 238 255 323 minecraft:mushroom_stem
setblock 238 255 325 minecraft:light[level=12]
setblock 238 255 339 minecraft:light[level=12]
setblock 238 255 346 minecraft:light[level=12]
setblock 238 255 353 minecraft:light[level=12]
setblock 238 255 360 minecraft:light[level=12]
setblock 238 255 363 minecraft:mushroom_stem
fill 239 255 323 239 258 323 minecraft:moss_block
fill 239 255 330 241 256 330 minecraft:red_mushroom_block
fill 239 255 336 241 256 336 minecraft:red_mushroom_block
setblock 239 255 362 minecraft:mushroom_stem
fill 239 255 363 242 255 363 minecraft:moss_block
fill 240 255 333 240 258 333 minecraft:red_mushroom_block
fill 240 255 362 243 255 362 minecraft:moss_block
fill 243 255 332 243 256 334 minecraft:red_mushroom_block
setblock 243 255 363 minecraft:mushroom_stem
setblock 244 255 323 minecraft:red_mushroom_block
setblock 244 255 362 minecraft:mushroom_stem
fill 244 255 363 244 258 363 minecraft:moss_block
setblock 245 255 325 minecraft:light[level=12]
setblock 245 255 332 minecraft:light[level=12]
setblock 245 255 339 minecraft:light[level=12]
setblock 245 255 346 minecraft:light[level=12]
setblock 245 255 353 minecraft:light[level=12]
setblock 245 255 360 minecraft:light[level=12]
setblock 245 255 361 minecraft:mushroom_stem
fill 245 255 362 245 258 362 minecraft:moss_block
fill 246 255 323 247 255 323 minecraft:moss_block
fill 246 255 361 246 258 361 minecraft:moss_block
setblock 248 255 323 minecraft:mushroom_stem
setblock 248 255 363 minecraft:mushroom_stem
fill 249 255 323 249 258 323 minecraft:moss_block
fill 249 255 360 249 256 360 minecraft:moss_block
setblock 249 255 362 minecraft:mushroom_stem
fill 249 255 363 249 258 363 minecraft:moss_block
setblock 250 255 361 minecraft:mushroom_stem
fill 250 255 362 250 258 362 minecraft:moss_block
setblock 251 255 360 minecraft:mushroom_stem
fill 251 255 361 251 258 361 minecraft:moss_block
setblock 252 255 325 minecraft:light[level=12]
setblock 252 255 332 minecraft:light[level=12]
setblock 252 255 339 minecraft:light[level=12]
setblock 252 255 353 minecraft:light[level=12]
setblock 252 255 360 minecraft:light[level=12]
setblock 253 255 323 minecraft:mushroom_stem
setblock 253 255 363 minecraft:mushroom_stem
setblock 254 255 362 minecraft:mushroom_stem
fill 254 255 363 254 258 363 minecraft:moss_block
fill 255 255 362 255 258 362 minecraft:moss_block
setblock 259 255 325 minecraft:light[level=12]
setblock 259 255 332 minecraft:light[level=12]
setblock 259 255 339 minecraft:light[level=12]
setblock 259 255 346 minecraft:light[level=12]
setblock 259 255 353 minecraft:light[level=12]
setblock 259 255 360 minecraft:light[level=12]
setblock 260 255 364 minecraft:red_mushroom_block
setblock 262 255 363 minecraft:red_mushroom_block
fill 263 255 364 263 288 364 minecraft:moss_block
setblock 266 255 325 minecraft:light[level=12]
setblock 266 255 332 minecraft:light[level=12]
setblock 266 255 339 minecraft:light[level=12]
setblock 266 255 346 minecraft:light[level=12]
setblock 266 255 353 minecraft:light[level=12]
setblock 266 255 360 minecraft:light[level=12]
setblock 267 255 323 minecraft:moss_block
setblock 267 255 363 minecraft:moss_block
setblock 268 255 323 minecraft:mushroom_stem
setblock 268 255 363 minecraft:mushroom_stem
fill 269 255 323 269 258 323 minecraft:moss_block
setblock 269 255 362 minecraft:mushroom_stem
fill 269 255 363 269 258 363 minecraft:moss_block
fill 270 255 324 271 255 324 minecraft:moss_block
fill 270 255 362 270 258 362 minecraft:moss_block
setblock 272 255 324 minecraft:mushroom_stem
setblock 273 255 323 minecraft:mushroom_stem
fill 273 255 324 273 258 324 minecraft:moss_block
setblock 273 255 325 minecraft:light[level=12]
setblock 273 255 332 minecraft:light[level=12]
setblock 273 255 339 minecraft:light[level=12]
setblock 273 255 346 minecraft:light[level=12]
setblock 273 255 353 minecraft:light[level=12]
setblock 273 255 360 minecraft:light[level=12]
setblock 273 255 362 minecraft:moss_block
setblock 273 255 363 minecraft:mushroom_stem
fill 274 255 323 274 258 323 minecraft:moss_block
setblock 274 255 337 minecraft:mushroom_stem
fill 274 255 338 274 258 338 minecraft:moss_block
setblock 274 255 362 minecraft:mushroom_stem
fill 274 255 363 274 258 363 minecraft:moss_block
fill 275 255 324 275 256 324 minecraft:moss_block
setblock 275 255 332 minecraft:moss_block
setblock 275 255 336 minecraft:mushroom_stem
fill 275 255 337 275 258 337 minecraft:moss_block
setblock 275 255 341 minecraft:mushroom_stem
fill 275 255 342 275 258 342 minecraft:moss_block
setblock 275 255 361 minecraft:mushroom_stem
fill 275 255 362 275 258 362 minecraft:moss_block
setblock 276 255 325 minecraft:mushroom_stem
fill 276 255 326 276 258 326 minecraft:moss_block
setblock 276 255 330 minecraft:mushroom_stem
fill 276 255 331 276 258 331 minecraft:moss_block
setblock 276 255 335 minecraft:mushroom_stem
fill 276 255 336 276 258 336 minecraft:moss_block
setblock 276 255 340 minecraft:mushroom_stem
fill 276 255 341 276 258 341 minecraft:moss_block
setblock 276 255 344 minecraft:moss_block
setblock 276 255 360 minecraft:mushroom_stem
fill 276 255 361 276 258 361 minecraft:moss_block
fill 235 256 334 235 286 335 minecraft:moss_block
setblock 235 256 336 minecraft:red_mushroom_block
fill 235 256 337 235 260 337 minecraft:moss_block
setblock 235 256 359 minecraft:shroomlight
setblock 236 256 324 minecraft:mushroom_stem
fill 236 256 325 236 259 325 minecraft:moss_block
setblock 236 256 332 minecraft:red_mushroom_block
setblock 236 256 339 minecraft:mushroom_stem
fill 236 256 340 236 259 340 minecraft:moss_block
setblock 236 256 351 minecraft:red_mushroom_block
setblock 236 256 359 minecraft:mushroom_stem
fill 236 256 360 236 259 360 minecraft:moss_block
setblock 237 256 323 minecraft:mushroom_stem
fill 237 256 359 237 259 359 minecraft:moss_block
setblock 237 256 363 minecraft:mushroom_stem
fill 238 256 323 238 259 323 minecraft:moss_block
setblock 238 256 362 minecraft:mushroom_stem
fill 238 256 363 241 256 363 minecraft:moss_block
fill 239 256 362 242 256 362 minecraft:moss_block
fill 240 256 323 241 256 323 minecraft:moss_block
setblock 242 256 323 minecraft:mushroom_stem
setblock 242 256 363 minecraft:mushroom_stem
fill 243 256 323 246 256 323 minecraft:moss_block
setblock 243 256 362 minecraft:mushroom_stem
fill 243 256 363 243 259 363 minecraft:moss_block
fill 244 256 348 244 262 349 minecraft:dirt
setblock 244 256 361 minecraft:mushroom_stem
fill 244 256 362 244 259 362 minecraft:moss_block
fill 245 256 347 245 262 347 minecraft:dirt
fill 245 256 349 245 262 349 minecraft:dirt
fill 245 256 361 245 259 361 minecraft:moss_block
fill 246 256 348 246 262 348 minecraft:dirt
setblock 247 256 323 minecraft:mushroom_stem
setblock 247 256 363 minecraft:mushroom_stem
fill 248 256 323 248 259 323 minecraft:moss_block
fill 248 256 360 248 257 360 minecraft:moss_block
setblock 248 256 362 minecraft:mushroom_stem
fill 248 256 363 248 259 363 minecraft:moss_block
setblock 249 256 361 minecraft:mushroom_stem
fill 249 256 362 249 259 362 minecraft:moss_block
setblock 250 256 360 minecraft:mushroom_stem
fill 250 256 361 250 259 361 minecraft:moss_block
fill 251 256 360 251 258 360 minecraft:moss_block
setblock 252 256 323 minecraft:mushroom_stem
setblock 252 256 363 minecraft:mushroom_stem
fill 253 256 323 254 258 323 minecraft:moss_block
setblock 253 256 362 minecraft:mushroom_stem
fill 253 256 363 253 259 363 minecraft:moss_block
setblock 254 256 361 minecraft:mushroom_stem
fill 254 256 362 254 259 362 minecraft:moss_block
setblock 257 256 363 minecraft:mushroom_stem
fill 260 256 364 260 308 364 minecraft:moss_block
setblock 263 256 323 minecraft:red_mushroom_block
fill 265 256 363 266 256 363 minecraft:moss_block
setblock 266 256 323 minecraft:moss_block
setblock 267 256 323 minecraft:mushroom_stem
setblock 267 256 363 minecraft:mushroom_stem
fill 268 256 323 268 258 324 minecraft:moss_block
setblock 268 256 362 minecraft:mushroom_stem
fill 268 256 363 268 259 363 minecraft:moss_block
fill 269 256 324 270 256 324 minecraft:moss_block
fill 269 256 362 269 259 362 minecraft:moss_block
fill 270 256 345 270 258 347 minecraft:red_mushroom_block
setblock 271 256 324 minecraft:mushroom_stem
fill 271 256 344 271 258 345 minecraft:red_mushroom_block
fill 271 256 347 272 259 347 minecraft:red_mushroom_block
setblock 272 256 323 minecraft:mushroom_stem
fill 272 256 324 272 259 324 minecraft:moss_block
fill 272 256 345 272 258 346 minecraft:red_mushroom_block
setblock 272 256 363 minecraft:mushroom_stem
fill 273 256 323 273 259 323 minecraft:moss_block
fill 273 256 346 273 258 346 minecraft:red_mushroom_block
setblock 273 256 362 minecraft:mushroom_stem
fill 273 256 363 273 259 363 minecraft:moss_block
setblock 274 256 336 minecraft:mushroom_stem
fill 274 256 337 274 257 337 minecraft:moss_block
setblock 274 256 341 minecraft:mushroom_stem
fill 274 256 362 274 259 362 minecraft:moss_block
setblock 275 256 325 minecraft:mushroom_stem
setblock 275 256 335 minecraft:mushroom_stem
fill 275 256 336 275 258 336 minecraft:moss_block
setblock 275 256 340 minecraft:mushroom_stem
fill 275 256 341 275 259 341 minecraft:moss_block
fill 275 256 343 275 257 343 minecraft:moss_block
fill 275 256 361 275 259 361 minecraft:moss_block
setblock 276 256 324 minecraft:mushroom_stem
fill 276 256 325 276 259 325 minecraft:moss_block
setblock 276 256 329 minecraft:mushroom_stem
fill 276 256 330 276 259 330 minecraft:moss_block
setblock 276 256 334 minecraft:mushroom_stem
fill 276 256 335 276 259 335 minecraft:moss_block
setblock 276 256 339 minecraft:mushroom_stem
fill 276 256 340 276 259 340 minecraft:moss_block
setblock 276 256 344 minecraft:mushroom_stem
setblock 276 256 354 minecraft:red_mushroom_block
setblock 276 256 359 minecraft:mushroom_stem
fill 276 256 360 276 259 360 minecraft:moss_block
fill 235 257 336 235 308 336 minecraft:moss_block
fill 235 257 359 236 260 359 minecraft:moss_block
setblock 236 257 323 minecraft:mushroom_stem
fill 236 257 324 236 260 324 minecraft:moss_block
setblock 236 257 338 minecraft:mushroom_stem
fill 236 257 339 236 258 339 minecraft:moss_block
setblock 236 257 342 minecraft:moss_block
setblock 236 257 358 minecraft:mushroom_stem
setblock 236 257 362 minecraft:moss_block
setblock 236 257 363 minecraft:mushroom_stem
fill 237 257 323 237 260 323 minecraft:moss_block
setblock 237 257 362 minecraft:mushroom_stem
fill 237 257 363 240 257 363 minecraft:moss_block
fill 238 257 362 241 257 362 minecraft:moss_block
setblock 240 257 323 minecraft:moss_block
setblock 241 257 323 minecraft:mushroom_stem
setblock 241 257 363 minecraft:mushroom_stem
fill 242 257 323 245 257 323 minecraft:moss_block
setblock 242 257 362 minecraft:mushroom_stem
fill 242 257 363 242 260 363 minecraft:moss_block
setblock 243 257 361 minecraft:mushroom_stem
fill 243 257 362 243 260 362 minecraft:moss_block
fill 244 257 347 244 262 347 minecraft:dirt
fill 244 257 361 244 260 361 minecraft:moss_block
setblock 246 257 323 minecraft:mushroom_stem
fill 246 257 347 246 262 347 minecraft:dirt
fill 246 257 349 246 262 349 minecraft:dirt
setblock 246 257 363 minecraft:mushroom_stem
fill 247 257 323 247 260 323 minecraft:moss_block
fill 247 257 360 247 258 360 minecraft:moss_block
setblock 247 257 362 minecraft:mushroom_stem
fill 247 257 363 247 260 363 minecraft:moss_block
fill 248 257 324 249 257 324 minecraft:moss_block
setblock 248 257 361 minecraft:mushroom_stem
fill 248 257 362 248 260 362 minecraft:moss_block
setblock 249 257 360 minecraft:mushroom_stem
fill 249 257 361 249 260 361 minecraft:moss_block
fill 250 257 360 250 259 360 minecraft:moss_block
setblock 251 257 323 minecraft:mushroom_stem
setblock 251 257 363 minecraft:mushroom_stem
fill 252 257 323 252 260 323 minecraft:moss_block
setblock 252 257 362 minecraft:mushroom_stem
fill 252 257 363 252 260 363 minecraft:moss_block
setblock 253 257 361 minecraft:mushroom_stem
fill 253 257 362 253 260 362 minecraft:moss_block
setblock 256 257 363 minecraft:mushroom_stem
setblock 257 257 323 minecraft:red_mushroom_block
fill 257 257 363 258 259 363 minecraft:moss_block
fill 264 257 323 265 257 323 minecraft:moss_block
fill 264 257 363 265 257 363 minecraft:moss_block
setblock 266 257 323 minecraft:mushroom_stem
setblock 266 257 363 minecraft:mushroom_stem
fill 267 257 323 267 259 324 minecraft:moss_block
setblock 267 257 362 minecraft:mushroom_stem
fill 267 257 363 267 260 363 minecraft:moss_block
fill 268 257 362 268 260 362 minecraft:moss_block
setblock 269 257 324 minecraft:moss_block
fill 269 257 345 269 257 352 minecraft:red_mushroom_block
setblock 270 257 324 minecraft:mushroom_stem
fill 270 257 325 272 258 325 minecraft:moss_block
setblock 270 257 344 minecraft:red_mushroom_block
fill 270 257 348 270 260 352 minecraft:red_mushroom_block
setblock 271 257 323 minecraft:mushroom_stem
fill 271 257 324 271 260 324 minecraft:moss_block
fill 271 257 346 271 258 346 minecraft:red_mushroom_block
fill 271 257 348 273 260 349 minecraft:red_mushroom_block
setblock 271 257 350 minecraft:mushroom_stem
fill 271 257 351 273 260 352 minecraft:red_mushroom_block
setblock 271 257 362 minecraft:moss_block
setblock 271 257 363 minecraft:mushroom_stem
fill 272 257 323 272 260 323 minecraft:moss_block
setblock 272 257 344 minecraft:red_mushroom_block
fill 272 257 350 273 260 350 minecraft:red_mushroom_block
setblock 272 257 362 minecraft:mushroom_stem
fill 272 257 363 272 260 363 minecraft:moss_block
setblock 273 257 345 minecraft:red_mushroom_block
setblock 273 257 347 minecraft:red_mushroom_block
fill 273 257 362 273 260 362 minecraft:moss_block
setblock 274 257 340 minecraft:mushroom_stem
fill 274 257 341 274 258 341 minecraft:moss_block
setblock 275 257 324 minecraft:mushroom_stem
fill 275 257 325 275 258 327 minecraft:moss_block
setblock 275 257 334 minecraft:mushroom_stem
fill 275 257 335 275 258 335 minecraft:moss_block
setblock 275 257 339 minecraft:mushroom_stem
fill 275 257 340 275 260 340 minecraft:moss_block
setblock 276 257 323 minecraft:mushroom_stem
fill 276 257 324 276 260 324 minecraft:moss_block
setblock 276 257 328 minecraft:mushroom_stem
fill 276 257 329 276 260 329 minecraft:moss_block
setblock 276 257 333 minecraft:mushroom_stem
fill 276 257 334 276 259 334 minecraft:moss_block
setblock 276 257 338 minecraft:mushroom_stem
fill 276 257 339 276 260 339 minecraft:moss_block
setblock 276 257 343 minecraft:mushroom_stem
fill 276 257 344 277 260 344 minecraft:moss_block
setblock 276 257 348 minecraft:red_mushroom_block
setblock 276 257 358 minecraft:mushroom_stem
fill 276 257 359 276 260 359 minecraft:moss_block
setblock 276 257 363 minecraft:mushroom_stem
setblock 277 257 343 minecraft:red_mushroom_block
fill 236 258 323 236 261 323 minecraft:moss_block
setblock 236 258 327 minecraft:mushroom_stem
setblock 236 258 342 minecraft:mushroom_stem
fill 236 258 343 236 261 343 minecraft:moss_block
setblock 236 258 344 minecraft:red_mushroom_block
setblock 236 258 357 minecraft:mushroom_stem
fill 236 258 358 236 261 358 minecraft:moss_block
setblock 236 258 362 minecraft:mushroom_stem
fill 236 258 363 239 258 363 minecraft:moss_block
fill 237 258 324 237 259 324 minecraft:moss_block
setblock 237 258 361 minecraft:mushroom_stem
fill 237 258 362 240 258 362 minecraft:moss_block
setblock 240 258 323 minecraft:mushroom_stem
setblock 240 258 363 minecraft:mushroom_stem
fill 241 258 323 244 258 323 minecraft:moss_block
setblock 241 258 362 minecraft:mushroom_stem
fill 241 258 363 241 261 363 minecraft:moss_block
setblock 242 258 361 minecraft:mushroom_stem
fill 242 258 362 242 261 362 minecraft:moss_block
fill 243 258 347 243 262 349 minecraft:dirt
fill 243 258 361 243 261 361 minecraft:moss_block
fill 244 258 350 246 262 350 minecraft:dirt
setblock 245 258 323 minecraft:mushroom_stem
fill 245 258 324 248 258 324 minecraft:moss_block
fill 245 258 346 245 262 346 minecraft:dirt
setblock 245 258 363 minecraft:mushroom_stem
fill 246 258 323 246 261 323 minecraft:moss_block
fill 246 258 360 246 259 360 minecraft:moss_block
setblock 246 258 362 minecraft:mushroom_stem
fill 246 258 363 246 261 363 minecraft:moss_block
fill 247 258 348 247 262 348 minecraft:dirt
setblock 247 258 361 minecraft:mushroom_stem
fill 247 258 362 247 261 362 minecraft:moss_block
setblock 248 258 360 minecraft:mushroom_stem
fill 248 258 361 248 261 361 minecraft:moss_block
setblock 249 258 324 minecraft:mushroom_stem
fill 249 258 360 249 260 360 minecraft:moss_block
setblock 250 258 323 minecraft:mushroom_stem
fill 250 258 324 251 260 324 minecraft:moss_block
setblock 250 258 363 minecraft:mushroom_stem
fill 251 258 323 251 261 323 minecraft:moss_block
setblock 251 258 362 minecraft:mushroom_stem
fill 251 258 363 251 261 363 minecraft:moss_block
setblock 252 258 361 minecraft:mushroom_stem
fill 252 258 362 252 261 362 minecraft:moss_block
fill 253 258 361 253 259 361 minecraft:moss_block
setblock 255 258 323 minecraft:mushroom_stem
setblock 255 258 363 minecraft:mushroom_stem
fill 256 258 363 256 261 363 minecraft:moss_block
setblock 261 258 363 minecraft:red_mushroom_block
fill 262 258 323 264 258 323 minecraft:moss_block
fill 262 258 363 264 258 363 minecraft:moss_block
setblock 265 258 323 minecraft:mushroom_stem
fill 265 258 324 266 260 324 minecraft:moss_block
setblock 265 258 362 minecraft:moss_block
setblock 265 258 363 minecraft:mushroom_stem
fill 266 258 323 266 261 323 minecraft:moss_block
setblock 266 258 362 minecraft:mushroom_stem
fill 266 258 363 266 261 363 minecraft:moss_block
fill 267 258 362 267 261 362 minecraft:moss_block
setblock 268 258 325 minecraft:mushroom_stem
fill 268 258 349 269 259 351 minecraft:red_mushroom_block
setblock 269 258 324 minecraft:mushroom_stem
fill 269 258 325 269 261 325 minecraft:moss_block
fill 269 258 348 269 260 348 minecraft:red_mushroom_block
fill 269 258 352 269 260 352 minecraft:red_mushroom_block
setblock 270 258 323 minecraft:mushroom_stem
fill 270 258 324 270 261 324 minecraft:moss_block
fill 270 258 353 272 259 353 minecraft:red_mushroom_block
setblock 270 258 363 minecraft:mushroom_stem
fill 271 258 323 271 261 323 minecraft:moss_block
fill 271 258 350 271 261 350 minecraft:red_mushroom_block
setblock 271 258 362 minecraft:mushroom_stem
fill 271 258 363 271 261 363 minecraft:moss_block
fill 272 258 362 272 261 362 minecraft:moss_block
setblock 273 258 325 minecraft:mushroom_stem
setblock 274 258 324 minecraft:mushroom_stem
fill 274 258 325 274 261 325 minecraft:moss_block
setblock 274 258 339 minecraft:mushroom_stem
setblock 274 258 340 minecraft:moss_block
fill 274 258 349 274 259 351 minecraft:red_mushroom_block
setblock 275 258 323 minecraft:mushroom_stem
fill 275 258 324 275 261 324 minecraft:moss_block
setblock 275 258 328 minecraft:mushroom_stem
setblock 275 258 338 minecraft:mushroom_stem
fill 275 258 339 275 260 339 minecraft:moss_block
setblock 275 258 343 minecraft:mushroom_stem
setblock 275 258 363 minecraft:mushroom_stem
fill 276 258 323 276 261 323 minecraft:moss_block
setblock 276 258 327 minecraft:mushroom_stem
fill 276 258 328 276 261 328 minecraft:moss_block
setblock 276 258 332 minecraft:mushroom_stem
fill 276 258 333 276 259 333 minecraft:moss_block
setblock 276 258 337 minecraft:mushroom_stem
fill 276 258 338 276 260 338 minecraft:moss_block
setblock 276 258 342 minecraft:mushroom_stem
fill 276 258 343 277 261 343 minecraft:moss_block
fill 276 258 345 276 259 345 minecraft:moss_block
setblock 276 258 362 minecraft:mushroom_stem
fill 276 258 363 276 261 363 minecraft:moss_block
setblock 277 258 335 minecraft:shroomlight
setblock 236 259 326 minecraft:mushroom_stem
fill 236 259 327 236 262 327 minecraft:moss_block
setblock 236 259 331 minecraft:red_mushroom_block
setblock 236 259 341 minecraft:mushroom_stem
fill 236 259 342 236 261 342 minecraft:moss_block
fill 236 259 344 236 259 345 minecraft:moss_block
setblock 236 259 350 minecraft:red_mushroom_block
fill 236 259 357 236 260 357 minecraft:moss_block
setblock 236 259 361 minecraft:mushroom_stem
fill 236 259 362 238 259 363 minecraft:moss_block
setblock 237 259 360 minecraft:mushroom_stem
fill 237 259 361 237 262 361 minecraft:moss_block
setblock 239 259 323 minecraft:mushroom_stem
setblock 239 259 362 minecraft:moss_block
setblock 239 259 363 minecraft:mushroom_stem
fill 240 259 323 243 259 323 minecraft:moss_block
setblock 240 259 362 minecraft:mushroom_stem
fill 240 259 363 240 262 363 minecraft:moss_block
setblock 241 259 361 minecraft:mushroom_stem
fill 241 259 362 241 262 362 minecraft:moss_block
fill 242 259 361 242 262 361 minecraft:moss_block
setblock 243 259 324 minecraft:mushroom_stem
fill 243 259 350 243 262 350 minecraft:dirt
setblock 244 259 323 minecraft:mushroom_stem
fill 244 259 324 247 259 324 minecraft:moss_block
fill 244 259 346 244 262 346 minecraft:dirt
setblock 244 259 363 minecraft:mushroom_stem
fill 245 259 323 245 262 323 minecraft:moss_block
fill 245 259 360 245 260 360 minecraft:moss_block
setblock 245 259 362 minecraft:mushroom_stem
fill 245 259 363 245 262 363 minecraft:moss_block
fill 246 259 346 246 262 346 minecraft:dirt
setblock 246 259 361 minecraft:mushroom_stem
fill 246 259 362 246 262 362 minecraft:moss_block
fill 247 259 347 247 262 347 minecraft:dirt
fill 247 259 349 247 262 349 minecraft:dirt
setblock 247 259 360 minecraft:mushroom_stem
fill 247 259 361 247 262 361 minecraft:moss_block
setblock 248 259 324 minecraft:mushroom_stem
fill 248 259 360 248 260 360 minecraft:moss_block
setblock 249 259 323 minecraft:mushroom_stem
fill 249 259 324 249 262 324 minecraft:moss_block
setblock 249 259 363 minecraft:mushroom_stem
fill 250 259 323 250 262 323 minecraft:moss_block
setblock 250 259 362 minecraft:mushroom_stem
fill 250 259 363 250 262 363 minecraft:moss_block
setblock 251 259 361 minecraft:mushroom_stem
fill 251 259 362 251 262 362 minecraft:moss_block
setblock 252 259 324 minecraft:moss_block
fill 252 259 361 252 260 361 minecraft:moss_block
setblock 253 259 323 minecraft:moss_block
setblock 254 259 323 minecraft:mushroom_stem
setblock 254 259 363 minecraft:mushroom_stem
fill 255 259 323 256 261 323 minecraft:moss_block
setblock 255 259 362 minecraft:mushroom_stem
fill 255 259 363 255 262 363 minecraft:moss_block
setblock 259 259 363 minecraft:mushroom_stem
fill 260 259 363 263 259 363 minecraft:moss_block
fill 261 259 323 263 259 323 minecraft:moss_block
setblock 261 259 364 minecraft:shroomlight
setblock 264 259 323 minecraft:mushroom_stem
fill 264 259 324 264 262 324 minecraft:moss_block
setblock 264 259 363 minecraft:mushroom_stem
fill 265 259 323 265 262 323 minecraft:moss_block
setblock 265 259 362 minecraft:mushroom_stem
fill 265 259 363 265 262 363 minecraft:moss_block
setblock 266 259 325 minecraft:moss_block
fill 266 259 362 266 262 362 minecraft:moss_block
setblock 267 259 325 minecraft:mushroom_stem
setblock 268 259 323 minecraft:moss_block
setblock 268 259 324 minecraft:mushroom_stem
fill 268 259 325 268 262 325 minecraft:moss_block
setblock 269 259 323 minecraft:mushroom_stem
fill 269 259 324 269 262 324 minecraft:moss_block
setblock 269 259 363 minecraft:mushroom_stem
fill 270 259 323 270 262 323 minecraft:moss_block
fill 270 259 325 271 259 325 minecraft:moss_block
setblock 270 259 347 minecraft:red_mushroom_block
setblock 270 259 362 minecraft:mushroom_stem
fill 270 259 363 270 262 363 minecraft:moss_block
fill 271 259 362 271 262 362 minecraft:moss_block
setblock 272 259 325 minecraft:mushroom_stem
setblock 273 259 324 minecraft:mushroom_stem
fill 273 259 325 273 262 325 minecraft:moss_block
setblock 274 259 323 minecraft:mushroom_stem
fill 274 259 324 274 262 324 minecraft:moss_block
fill 274 259 326 275 259 326 minecraft:moss_block
setblock 274 259 363 minecraft:mushroom_stem
fill 275 259 323 275 262 323 minecraft:moss_block
fill 275 259 325 275 260 325 minecraft:moss_block
setblock 275 259 327 minecraft:mushroom_stem
fill 275 259 328 275 262 328 minecraft:moss_block
setblock 275 259 337 minecraft:mushroom_stem
setblock 275 259 338 minecraft:moss_block
setblock 275 259 342 minecraft:mushroom_stem
fill 275 259 343 275 260 343 minecraft:moss_block
setblock 275 259 362 minecraft:mushroom_stem
fill 275 259 363 275 262 363 minecraft:moss_block
setblock 276 259 326 minecraft:mushroom_stem
fill 276 259 327 276 262 327 minecraft:moss_block
setblock 276 259 331 minecraft:mushroom_stem
setblock 276 259 332 minecraft:moss_block
setblock 276 259 336 minecraft:mushroom_stem
fill 276 259 337 276 260 337 minecraft:moss_block
setblock 276 259 341 minecraft:mushroom_stem
fill 276 259 342 276 262 342 minecraft:moss_block
setblock 276 259 355 minecraft:red_mushroom_block
setblock 276 259 361 minecraft:mushroom_stem
fill 276 259 362 276 262 362 minecraft:moss_block
fill 277 259 335 277 277 335 minecraft:moss_block
setblock 236 260 325 minecraft:mushroom_stem
fill 236 260 326 236 263 326 minecraft:moss_block
setblock 236 260 337 minecraft:red_mushroom_block
setblock 236 260 341 minecraft:moss_block
setblock 236 260 344 minecraft:moss_block
setblock 236 260 345 minecraft:mushroom_stem
fill 236 260 346 236 263 346 minecraft:moss_block
setblock 236 260 356 minecraft:red_mushroom_block
setblock 236 260 360 minecraft:mushroom_stem
fill 236 260 361 236 261 363 minecraft:moss_block
setblock 237 260 324 minecraft:mushroom_stem
fill 237 260 360 237 261 360 minecraft:moss_block
fill 237 260 362 237 260 363 minecraft:moss_block
setblock 238 260 323 minecraft:mushroom_stem
fill 238 260 324 241 260 324 minecraft:moss_block
setblock 238 260 362 minecraft:moss_block
setblock 238 260 363 minecraft:mushroom_stem
fill 239 260 323 242 260 323 minecraft:moss_block
setblock 239 260 362 minecraft:mushroom_stem
fill 239 260 363 239 263 363 minecraft:moss_block
fill 240 260 362 240 263 362 minecraft:moss_block
fill 241 260 361 241 261 361 minecraft:moss_block
setblock 242 260 324 minecraft:mushroom_stem
fill 242 260 347 242 262 349 minecraft:dirt
setblock 243 260 323 minecraft:mushroom_stem
fill 243 260 324 246 260 324 minecraft:moss_block
fill 243 260 346 243 262 346 minecraft:dirt
setblock 243 260 363 minecraft:mushroom_stem
fill 244 260 323 244 263 323 minecraft:moss_block
fill 244 260 351 246 262 351 minecraft:dirt
setblock 244 260 362 minecraft:mushroom_stem
fill 244 260 363 244 263 363 minecraft:moss_block
setblock 245 260 361 minecraft:mushroom_stem
fill 245 260 362 245 263 362 minecraft:moss_block
setblock 246 260 360 minecraft:mushroom_stem
fill 246 260 361 246 263 361 minecraft:moss_block
setblock 247 260 324 minecraft:mushroom_stem
fill 247 260 346 247 262 346 minecraft:dirt
fill 247 260 350 247 262 350 minecraft:dirt
fill 247 260 360 247 261 360 minecraft:moss_block
setblock 248 260 323 minecraft:mushroom_stem
fill 248 260 324 248 263 324 minecraft:moss_block
setblock 248 260 363 minecraft:mushroom_stem
fill 249 260 323 249 263 323 minecraft:moss_block
setblock 249 260 362 minecraft:mushroom_stem
fill 249 260 363 249 263 363 minecraft:moss_block
setblock 250 260 361 minecraft:mushroom_stem
fill 250 260 362 250 263 362 minecraft:moss_block
fill 251 260 361 251 261 361 minecraft:moss_block
setblock 252 260 324 minecraft:mushroom_stem
setblock 253 260 323 minecraft:mushroom_stem
setblock 253 260 363 minecraft:mushroom_stem
fill 254 260 323 254 263 323 minecraft:moss_block
setblock 254 260 362 minecraft:mushroom_stem
fill 254 260 363 254 262 363 minecraft:moss_block
setblock 257 260 323 minecraft:moss_block
setblock 257 260 363 minecraft:moss_block
setblock 258 260 323 minecraft:mushroom_stem
setblock 258 260 363 minecraft:mushroom_stem
fill 259 260 323 262 260 323 minecraft:moss_block
fill 259 260 363 262 260 363 minecraft:moss_block
fill 261 260 364 261 308 364 minecraft:moss_block
setblock 262 260 324 minecraft:mushroom_stem
setblock 263 260 323 minecraft:mushroom_stem
fill 263 260 324 263 263 324 minecraft:moss_block
setblock 263 260 363 minecraft:mushroom_stem
fill 264 260 323 264 263 323 minecraft:moss_block
setblock 264 260 362 minecraft:mushroom_stem
fill 264 260 363 264 263 363 minecraft:moss_block
setblock 265 260 325 minecraft:moss_block
fill 265 260 362 265 263 362 minecraft:moss_block
setblock 266 260 325 minecraft:mushroom_stem
setblock 267 260 323 minecraft:moss_block
setblock 267 260 324 minecraft:mushroom_stem
fill 267 260 325 267 263 325 minecraft:moss_block
setblock 268 260 323 minecraft:mushroom_stem
fill 268 260 324 268 263 324 minecraft:moss_block
fill 268 260 326 269 260 326 minecraft:moss_block
setblock 268 260 363 minecraft:mushroom_stem
fill 269 260 323 269 263 323 minecraft:moss_block
fill 269 260 349 269 260 351 minecraft:red_mushroom_block
setblock 269 260 362 minecraft:mushroom_stem
fill 269 260 363 269 263 363 minecraft:moss_block
setblock 270 260 325 minecraft:moss_block
setblock 270 260 326 minecraft:mushroom_stem
fill 270 260 362 270 263 362 minecraft:moss_block
setblock 271 260 325 minecraft:mushroom_stem
fill 271 260 326 271 262 326 minecraft:moss_block
setblock 272 260 324 minecraft:mushroom_stem
fill 272 260 325 272 263 325 minecraft:moss_block
setblock 273 260 323 minecraft:mushroom_stem
fill 273 260 324 273 263 324 minecraft:moss_block
setblock 273 260 363 minecraft:mushroom_stem
fill 274 260 323 274 263 323 minecraft:moss_block
setblock 274 260 326 minecraft:moss_block
setblock 274 260 362 minecraft:mushroom_stem
fill 274 260 363 274 263 363 minecraft:moss_block
setblock 275 260 326 minecraft:mushroom_stem
fill 275 260 327 275 263 327 minecraft:moss_block
setblock 275 260 341 minecraft:mushroom_stem
setblock 275 260 342 minecraft:moss_block
setblock 275 260 361 minecraft:mushroom_stem
fill 275 260 362 275 261 362 minecraft:moss_block
setblock 276 260 325 minecraft:mushroom_stem
fill 276 260 326 276 263 326 minecraft:moss_block
setblock 276 260 330 minecraft:mushroom_stem
setblock 276 260 331 minecraft:moss_block
setblock 276 260 336 minecraft:moss_block
setblock 276 260 340 minecraft:mushroom_stem
fill 276 260 341 276 261 341 minecraft:moss_block
setblock 276 260 345 minecraft:mushroom_stem
fill 276 260 346 276 261 346 minecraft:moss_block
setblock 276 260 349 minecraft:red_mushroom_block
setblock 276 260 360 minecraft:mushroom_stem
fill 276 260 361 276 262 361 minecraft:moss_block
setblock 277 260 332 minecraft:red_mushroom_block
setblock 235 261 337 minecraft:red_mushroom_block
fill 235 261 359 235 279 359 minecraft:moss_block
setblock 236 261 324 minecraft:mushroom_stem
fill 236 261 325 237 261 325 minecraft:moss_block
setblock 236 261 344 minecraft:mushroom_stem
fill 236 261 345 236 263 345 minecraft:moss_block
fill 236 261 347 236 262 347 minecraft:moss_block
setblock 236 261 359 minecraft:mushroom_stem
fill 236 261 360 236 263 360 minecraft:moss_block
setblock 237 261 323 minecraft:mushroom_stem
fill 237 261 324 240 261 324 minecraft:moss_block
setblock 237 261 362 minecraft:moss_block
setblock 237 261 363 minecraft:mushroom_stem
fill 238 261 323 241 261 323 minecraft:moss_block
setblock 238 261 325 minecraft:light[level=15]
setblock 238 261 332 minecraft:light[level=12]
setblock 238 261 333 minecraft:light[level=15]
setblock 238 261 339 minecraft:light[level=12]
setblock 238 261 341 minecraft:light[level=15]
setblock 238 261 346 minecraft:light[level=12]
setblock 238 261 349 minecraft:light[level=15]
setblock 238 261 353 minecraft:light[level=12]
setblock 238 261 357 minecraft:light[level=15]
setblock 238 261 360 minecraft:light[level=12]
setblock 238 261 362 minecraft:mushroom_stem
fill 238 261 363 238 264 363 minecraft:moss_block
fill 239 261 362 239 264 362 minecraft:moss_block
setblock 241 261 324 minecraft:mushroom_stem
setblock 242 261 323 minecraft:mushroom_stem
fill 242 261 324 245 261 324 minecraft:moss_block
fill 242 261 346 242 262 346 minecraft:dirt
fill 242 261 350 242 262 350 minecraft:dirt
setblock 242 261 363 minecraft:mushroom_stem
fill 243 261 323 243 264 323 minecraft:moss_block
fill 243 261 351 243 262 351 minecraft:dirt
setblock 243 261 362 minecraft:mushroom_stem
fill 243 261 363 243 264 363 minecraft:moss_block
fill 244 261 345 246 262 345 minecraft:dirt
setblock 244 261 361 minecraft:mushroom_stem
fill 244 261 362 244 264 362 minecraft:moss_block
setblock 245 261 325 minecraft:light[level=12]
setblock 245 261 332 minecraft:light[level=12]
setblock 245 261 339 minecraft:light[level=12]
setblock 245 261 353 minecraft:light[level=12]
setblock 245 261 360 minecraft:light[level=12]
fill 245 261 361 245 263 361 minecraft:moss_block
setblock 246 261 324 minecraft:mushroom_stem
setblock 246 261 325 minecraft:light[level=15]
setblock 246 261 333 minecraft:light[level=15]
setblock 246 261 341 minecraft:light[level=15]
setblock 246 261 357 minecraft:light[level=15]
setblock 247 261 323 minecraft:mushroom_stem
fill 247 261 324 247 264 324 minecraft:moss_block
fill 247 261 351 247 262 351 minecraft:dirt
setblock 247 261 363 minecraft:mushroom_stem
fill 248 261 323 248 264 323 minecraft:moss_block
fill 248 261 347 248 262 349 minecraft:dirt
setblock 248 261 362 minecraft:mushroom_stem
fill 248 261 363 248 264 363 minecraft:moss_block
setblock 249 261 361 minecraft:mushroom_stem
fill 249 261 362 249 264 362 minecraft:moss_block
setblock 250 261 324 minecraft:moss_block
setblock 250 261 361 minecraft:moss_block
setblock 251 261 324 minecraft:mushroom_stem
setblock 252 261 323 minecraft:mushroom_stem
setblock 252 261 324 minecraft:moss_block
setblock 252 261 325 minecraft:light[level=12]
setblock 252 261 332 minecraft:light[level=12]
setblock 252 261 339 minecraft:light[level=12]
setblock 252 261 353 minecraft:light[level=12]
setblock 252 261 360 minecraft:light[level=12]
setblock 252 261 363 minecraft:mushroom_stem
fill 253 261 323 253 263 323 minecraft:moss_block
setblock 253 261 362 minecraft:mushroom_stem
fill 253 261 363 253 263 363 minecraft:moss_block
setblock 254 261 325 minecraft:light[level=15]
setblock 254 261 333 minecraft:light[level=15]
setblock 254 261 341 minecraft:light[level=15]
setblock 254 261 349 minecraft:light[level=15]
setblock 254 261 357 minecraft:light[level=15]
setblock 257 261 323 minecraft:mushroom_stem
setblock 257 261 363 minecraft:mushroom_stem
fill 258 261 323 261 261 323 minecraft:moss_block
setblock 259 261 325 minecraft:light[level=12]
setblock 259 261 332 minecraft:light[level=12]
setblock 259 261 339 minecraft:light[level=12]
setblock 259 261 346 minecraft:light[level=12]
setblock 259 261 353 minecraft:light[level=12]
setblock 259 261 360 minecraft:light[level=12]
fill 260 261 363 261 261 363 minecraft:moss_block
setblock 262 261 323 minecraft:mushroom_stem
fill 262 261 324 262 264 324 minecraft:moss_block
setblock 262 261 325 minecraft:light[level=15]
setblock 262 261 333 minecraft:light[level=15]
setblock 262 261 341 minecraft:light[level=15]
setblock 262 261 349 minecraft:light[level=15]
setblock 262 261 357 minecraft:light[level=15]
setblock 262 261 363 minecraft:mushroom_stem
fill 263 261 323 263 264 323 minecraft:moss_block
fill 263 261 363 263 264 363 minecraft:moss_block
setblock 264 261 325 minecraft:moss_block
fill 264 261 362 264 262 362 minecraft:moss_block
setblock 265 261 324 minecraft:moss_block
setblock 265 261 325 minecraft:mushroom_stem
setblock 266 261 324 minecraft:mushroom_stem
fill 266 261 325 266 264 325 minecraft:moss_block
setblock 266 261 332 minecraft:light[level=12]
setblock 266 261 339 minecraft:light[level=12]
setblock 266 261 346 minecraft:light[level=12]
setblock 266 261 353 minecraft:light[level=12]
setblock 266 261 360 minecraft:light[level=12]
setblock 267 261 323 minecraft:mushroom_stem
fill 267 261 324 267 264 324 minecraft:moss_block
fill 267 261 326 268 261 326 minecraft:moss_block
setblock 267 261 363 minecraft:mushroom_stem
fill 268 261 323 268 264 323 minecraft:moss_block
setblock 268 261 362 minecraft:mushroom_stem
fill 268 261 363 268 264 363 minecraft:moss_block
setblock 269 261 326 minecraft:mushroom_stem
fill 269 261 362 269 263 362 minecraft:moss_block
setblock 270 261 325 minecraft:mushroom_stem
fill 270 261 326 270 264 326 minecraft:moss_block
setblock 270 261 333 minecraft:light[level=15]
setblock 270 261 341 minecraft:light[level=15]
setblock 270 261 349 minecraft:light[level=15]
setblock 270 261 357 minecraft:light[level=15]
setblock 271 261 324 minecraft:mushroom_stem
fill 271 261 325 271 264 325 minecraft:moss_block
setblock 272 261 323 minecraft:mushroom_stem
fill 272 261 324 272 264 324 minecraft:moss_block
setblock 272 261 363 minecraft:mushroom_stem
fill 273 261 323 273 264 323 minecraft:moss_block
setblock 273 261 332 minecraft:light[level=12]
setblock 273 261 339 minecraft:light[level=12]
setblock 273 261 346 minecraft:light[level=12]
setblock 273 261 353 minecraft:light[level=12]
setblock 273 261 360 minecraft:light[level=12]
setblock 273 261 362 minecraft:mushroom_stem
fill 273 261 363 273 264 363 minecraft:moss_block
setblock 274 261 326 minecraft:mushroom_stem
setblock 274 261 362 minecraft:moss_block
setblock 275 261 325 minecraft:mushroom_stem
fill 275 261 326 275 264 326 minecraft:moss_block
setblock 276 261 324 minecraft:mushroom_stem
fill 276 261 325 276 264 325 minecraft:moss_block
setblock 276 261 329 minecraft:mushroom_stem
fill 276 261 330 276 263 330 minecraft:moss_block
setblock 276 261 339 minecraft:mushroom_stem
setblock 276 261 340 minecraft:moss_block
setblock 276 261 344 minecraft:mushroom_stem
fill 276 261 345 276 262 345 minecraft:moss_block
setblock 276 261 360 minecraft:moss_block
fill 277 261 332 277 308 332 minecraft:moss_block
fill 277 261 344 277 308 344 minecraft:moss_block
fill 235 262 337 235 308 337 minecraft:moss_block
setblock 236 262 323 minecraft:mushroom_stem
fill 236 262 324 236 264 325 minecraft:moss_block
setblock 236 262 343 minecraft:mushroom_stem
setblock 236 262 344 minecraft:moss_block
setblock 236 262 349 minecraft:red_mushroom_block
setblock 236 262 358 minecraft:mushroom_stem
fill 236 262 359 236 263 359 minecraft:moss_block
fill 236 262 361 236 262 362 minecraft:moss_block
setblock 236 262 363 minecraft:mushroom_stem
fill 237 262 323 239 262 324 minecraft:moss_block
setblock 237 262 362 minecraft:mushroom_stem
fill 237 262 363 237 265 363 minecraft:moss_block
fill 238 262 362 238 263 362 minecraft:moss_block
setblock 240 262 323 minecraft:moss_block
setblock 240 262 324 minecraft:mushroom_stem
setblock 241 262 323 minecraft:mushroom_stem
fill 241 262 324 244 262 324 minecraft:moss_block
fill 241 262 347 241 262 349 minecraft:dirt
setblock 241 262 363 minecraft:mushroom_stem
fill 242 262 323 242 265 323 minecraft:moss_block
setblock 242 262 351 minecraft:dirt
setblock 242 262 362 minecraft:mushroom_stem
fill 242 262 363 242 265 363 minecraft:moss_block
setblock 243 262 345 minecraft:dirt
setblock 243 262 361 minecraft:mushroom_stem
fill 243 262 362 243 265 362 minecraft:moss_block
fill 244 262 352 246 262 352 minecraft:dirt
fill 244 262 361 244 263 361 minecraft:moss_block
setblock 245 262 324 minecraft:mushroom_stem
setblock 246 262 323 minecraft:mushroom_stem
fill 246 262 324 246 265 324 minecraft:moss_block
setblock 246 262 363 minecraft:mushroom_stem
fill 247 262 323 247 265 323 minecraft:moss_block
setblock 247 262 345 minecraft:dirt
setblock 247 262 362 minecraft:mushroom_stem
fill 247 262 363 247 265 363 minecraft:moss_block
setblock 248 262 346 minecraft:dirt
setblock 248 262 350 minecraft:dirt
setblock 248 262 361 minecraft:mushroom_stem
fill 248 262 362 248 264 362 minecraft:moss_block
setblock 249 262 361 minecraft:moss_block
setblock 250 262 324 minecraft:mushroom_stem
setblock 251 262 323 minecraft:mushroom_stem
fill 251 262 324 251 263 324 minecraft:moss_block
setblock 251 262 363 minecraft:mushroom_stem
fill 252 262 323 252 264 323 minecraft:moss_block
setblock 252 262 362 minecraft:mushroom_stem
fill 252 262 363 252 264 363 minecraft:moss_block
setblock 255 262 323 minecraft:moss_block
setblock 256 262 323 minecraft:mushroom_stem
fill 257 262 323 260 262 323 minecraft:moss_block
setblock 261 262 323 minecraft:mushroom_stem
fill 261 262 324 261 265 324 minecraft:moss_block
setblock 261 262 363 minecraft:mushroom_stem
fill 262 262 323 262 265 323 minecraft:moss_block
fill 262 262 363 262 264 363 minecraft:moss_block
setblock 263 262 325 minecraft:moss_block
setblock 264 262 325 minecraft:mushroom_stem
setblock 265 262 324 minecraft:mushroom_stem
fill 265 262 325 265 265 325 minecraft:moss_block
setblock 266 262 323 minecraft:mushroom_stem
fill 266 262 324 266 265 324 minecraft:moss_block
fill 266 262 326 267 262 326 minecraft:moss_block
setblock 266 262 363 minecraft:mushroom_stem
fill 267 262 323 267 265 323 minecraft:moss_block
setblock 267 262 362 minecraft:mushroom_stem
fill 267 262 363 267 265 363 minecraft:moss_block
setblock 268 262 326 minecraft:mushroom_stem
fill 268 262 362 268 263 362 minecraft:moss_block
setblock 269 262 325 minecraft:mushroom_stem
fill 269 262 326 269 265 326 minecraft:moss_block
setblock 270 262 324 minecraft:mushroom_stem
fill 270 262 325 270 265 325 minecraft:moss_block
setblock 271 262 323 minecraft:mushroom_stem
fill 271 262 324 271 265 324 minecraft:moss_block
setblock 271 262 363 minecraft:mushroom_stem
fill 272 262 323 272 265 323 minecraft:moss_block
setblock 272 262 362 minecraft:mushroom_stem
fill 272 262 363 272 265 363 minecraft:moss_block
setblock 273 262 362 minecraft:moss_block
setblock 274 262 325 minecraft:mushroom_stem
fill 274 262 326 274 263 326 minecraft:moss_block
setblock 275 262 324 minecraft:mushroom_stem
fill 275 262 325 275 265 325 minecraft:moss_block
setblock 276 262 323 minecraft:mushroom_stem
fill 276 262 324 276 265 324 minecraft:moss_block
setblock 276 262 328 minecraft:mushroom_stem
fill 276 262 329 276 265 329 minecraft:moss_block
setblock 276 262 337 minecraft:red_mushroom_block
setblock 276 262 343 minecraft:mushroom_stem
setblock 276 262 344 minecraft:moss_block
setblock 276 262 363 minecraft:mushroom_stem
fill 277 262 343 277 308 343 minecraft:moss_block
fill 236 263 323 239 263 323 minecraft:moss_block
setblock 236 263 327 minecraft:mushroom_stem
fill 236 263 329 236 264 329 minecraft:mushroom_stem
setblock 236 263 330 minecraft:red_mushroom_block
fill 236 263 331 236 264 331 minecraft:mushroom_stem
setblock 236 263 347 minecraft:mushroom_stem
fill 236 263 348 236 266 348 minecraft:moss_block
setblock 236 263 355 minecraft:red_mushroom_block
setblock 236 263 361 minecraft:moss_block
setblock 236 263 362 minecraft:mushroom_stem
fill 236 263 363 236 266 363 minecraft:moss_block
fill 237 263 324 238 263 324 minecraft:moss_block
setblock 237 263 362 minecraft:moss_block
setblock 239 263 324 minecraft:mushroom_stem
setblock 240 263 323 minecraft:mushroom_stem
fill 240 263 324 243 263 324 minecraft:moss_block
setblock 240 263 363 minecraft:mushroom_stem
fill 241 263 323 241 266 323 minecraft:moss_block
setblock 241 263 362 minecraft:mushroom_stem
fill 241 263 363 241 266 363 minecraft:moss_block
fill 242 263 362 242 266 362 minecraft:moss_block
setblock 243 263 361 minecraft:moss_block
setblock 244 263 324 minecraft:mushroom_stem
setblock 245 263 323 minecraft:mushroom_stem
fill 245 263 324 245 266 324 minecraft:moss_block
fill 245 263 348 245 266 348 minecraft:mushroom_stem
setblock 245 263 363 minecraft:mushroom_stem
fill 246 263 323 246 266 323 minecraft:moss_block
setblock 246 263 362 minecraft:mushroom_stem
fill 246 263 363 246 266 363 minecraft:moss_block
setblock 247 263 361 minecraft:mushroom_stem
fill 247 263 362 247 265 362 minecraft:moss_block
setblock 248 263 361 minecraft:moss_block
setblock 249 263 324 minecraft:mushroom_stem
setblock 250 263 323 minecraft:mushroom_stem
setblock 250 263 324 minecraft:moss_block
setblock 250 263 363 minecraft:mushroom_stem
fill 251 263 323 251 265 323 minecraft:moss_block
setblock 251 263 362 minecraft:mushroom_stem
fill 251 263 363 251 264 363 minecraft:moss_block
fill 258 263 323 259 263 323 minecraft:moss_block
setblock 260 263 323 minecraft:mushroom_stem
fill 261 263 323 261 266 323 minecraft:moss_block
setblock 261 263 363 minecraft:moss_block
setblock 263 263 325 minecraft:mushroom_stem
setblock 264 263 324 minecraft:mushroom_stem
fill 264 263 325 264 266 325 minecraft:moss_block
setblock 265 263 323 minecraft:mushroom_stem
fill 265 263 324 265 266 324 minecraft:moss_block
fill 265 263 326 266 263 326 minecraft:moss_block
setblock 265 263 363 minecraft:mushroom_stem
fill 266 263 323 266 266 323 minecraft:moss_block
setblock 266 263 362 minecraft:mushroom_stem
fill 266 263 363 266 266 363 minecraft:moss_block
setblock 267 263 326 minecraft:mushroom_stem
setblock 267 263 362 minecraft:moss_block
setblock 268 263 325 minecraft:mushroom_stem
fill 268 263 326 268 266 326 minecraft:moss_block
setblock 269 263 324 minecraft:mushroom_stem
fill 269 263 325 269 266 325 minecraft:moss_block
setblock 270 263 323 minecraft:mushroom_stem
fill 270 263 324 270 266 324 minecraft:moss_block
setblock 270 263 363 minecraft:mushroom_stem
fill 271 263 323 271 266 323 minecraft:moss_block
setblock 271 263 362 minecraft:mushroom_stem
fill 271 263 363 271 265 363 minecraft:moss_block
setblock 273 263 325 minecraft:mushroom_stem
setblock 274 263 324 minecraft:mushroom_stem
setblock 274 263 325 minecraft:moss_block
setblock 275 263 323 minecraft:mushroom_stem
fill 275 263 324 275 266 324 minecraft:moss_block
fill 275 263 328 275 263 331 minecraft:mushroom_stem
setblock 275 263 363 minecraft:mushroom_stem
fill 276 263 323 276 266 323 minecraft:moss_block
setblock 276 263 327 minecraft:mushroom_stem
fill 276 263 328 276 266 328 minecraft:moss_block
setblock 276 263 331 minecraft:red_mushroom_block
setblock 276 263 356 minecraft:red_mushroom_block
setblock 276 263 362 minecraft:mushroom_stem
fill 276 263 363 276 265 363 minecraft:moss_block
fill 236 264 323 238 264 323 minecraft:moss_block
setblock 236 264 326 minecraft:mushroom_stem
setblock 236 264 327 minecraft:moss_block
fill 236 264 330 238 265 330 minecraft:mushroom_stem
setblock 236 264 336 minecraft:red_mushroom_block
setblock 236 264 346 minecraft:mushroom_stem
fill 236 264 347 236 267 347 minecraft:moss_block
setblock 236 264 361 minecraft:mushroom_stem
fill 236 264 362 236 265 362 minecraft:moss_block
fill 237 264 329 237 265 329 minecraft:mushroom_stem
fill 237 264 331 237 265 331 minecraft:mushroom_stem
setblock 239 264 323 minecraft:mushroom_stem
setblock 239 264 363 minecraft:mushroom_stem
fill 240 264 323 240 264 324 minecraft:moss_block
setblock 240 264 350 minecraft:shroomlight
setblock 240 264 362 minecraft:mushroom_stem
fill 240 264 363 240 267 363 minecraft:moss_block
fill 241 264 324 242 264 324 minecraft:moss_block
fill 241 264 362 241 265 362 minecraft:moss_block
setblock 243 264 324 minecraft:mushroom_stem
setblock 244 264 323 minecraft:mushroom_stem
fill 244 264 324 244 267 324 minecraft:moss_block
setblock 244 264 363 minecraft:mushroom_stem
fill 245 264 323 245 267 323 minecraft:moss_block
setblock 245 264 362 minecraft:mushroom_stem
fill 245 264 363 245 267 363 minecraft:moss_block
fill 246 264 362 246 265 362 minecraft:moss_block
setblock 248 264 324 minecraft:mushroom_stem
setblock 249 264 323 minecraft:mushroom_stem
setblock 249 264 324 minecraft:moss_block
setblock 249 264 363 minecraft:mushroom_stem
fill 250 264 323 250 265 323 minecraft:moss_block
fill 250 264 363 250 265 363 minecraft:moss_block
setblock 253 264 323 minecraft:red_mushroom_block
setblock 253 264 363 minecraft:red_mushroom_block
setblock 256 264 322 minecraft:red_mushroom_block
setblock 257 264 364 minecraft:shroomlight
setblock 258 264 323 minecraft:moss_block
setblock 259 264 323 minecraft:mushroom_stem
fill 260 264 323 260 266 324 minecraft:moss_block
setblock 262 264 325 minecraft:mushroom_stem
setblock 263 264 324 minecraft:mushroom_stem
fill 263 264 325 263 267 325 minecraft:moss_block
setblock 264 264 323 minecraft:mushroom_stem
fill 264 264 324 264 267 324 minecraft:moss_block
setblock 264 264 363 minecraft:mushroom_stem
fill 265 264 323 265 267 323 minecraft:moss_block
setblock 265 264 326 minecraft:moss_block
fill 265 264 363 265 267 363 minecraft:moss_block
setblock 266 264 326 minecraft:mushroom_stem
setblock 267 264 325 minecraft:mushroom_stem
fill 267 264 326 267 266 326 minecraft:moss_block
setblock 268 264 324 minecraft:mushroom_stem
fill 268 264 325 268 267 325 minecraft:moss_block
setblock 268 264 364 minecraft:shroomlight
setblock 269 264 323 minecraft:mushroom_stem
fill 269 264 324 269 267 324 minecraft:moss_block
setblock 269 264 363 minecraft:mushroom_stem
fill 270 264 323 270 267 323 minecraft:moss_block
fill 270 264 363 270 266 363 minecraft:moss_block
setblock 272 264 325 minecraft:mushroom_stem
setblock 273 264 324 minecraft:mushroom_stem
setblock 273 264 325 minecraft:moss_block
fill 273 264 330 276 264 330 minecraft:mushroom_stem
setblock 274 264 323 minecraft:mushroom_stem
fill 274 264 324 274 266 324 minecraft:moss_block
fill 274 264 329 275 264 329 minecraft:mushroom_stem
fill 274 264 331 276 264 331 minecraft:mushroom_stem
setblock 274 264 363 minecraft:mushroom_stem
fill 275 264 323 275 267 323 minecraft:moss_block
setblock 275 264 327 minecraft:mushroom_stem
fill 275 264 363 275 265 363 minecraft:moss_block
setblock 276 264 326 minecraft:mushroom_stem
fill 276 264 327 276 267 327 minecraft:moss_block
fill 276 264 344 276 265 344 minecraft:red_mushroom_block
setblock 276 264 350 minecraft:red_mushroom_block
setblock 276 264 362 minecraft:moss_block
setblock 277 264 360 minecraft:shroomlight
fill 235 265 346 235 300 347 minecraft:moss_block
setblock 235 265 348 minecraft:shroomlight
fill 235 265 349 235 290 355 minecraft:moss_block
fill 236 265 323 236 265 324 minecraft:moss_block
setblock 236 265 325 minecraft:mushroom_stem
fill 236 265 326 236 266 326 minecraft:moss_block
setblock 236 265 342 minecraft:red_mushroom_block
setblock 236 265 349 minecraft:moss_block
setblock 237 265 323 minecraft:moss_block
setblock 238 265 323 minecraft:mushroom_stem
fill 238 265 329 238 266 329 minecraft:mushroom_stem
fill 238 265 331 238 266 331 minecraft:mushroom_stem
setblock 238 265 363 minecraft:mushroom_stem
fill 239 265 323 240 267 323 minecraft:moss_block
fill 239 265 330 239 267 330 minecraft:mushroom_stem
fill 239 265 363 239 268 363 minecraft:moss_block
fill 240 265 350 240 269 350 minecraft:mushroom_stem
setblock 241 265 324 minecraft:moss_block
setblock 242 265 324 minecraft:mushroom_stem
setblock 243 265 323 minecraft:mushroom_stem
fill 243 265 324 243 267 324 minecraft:moss_block
setblock 243 265 363 minecraft:mushroom_stem
fill 244 265 323 244 268 323 minecraft:moss_block
setblock 244 265 362 minecraft:mushroom_stem
fill 244 265 363 244 268 363 minecraft:moss_block
fill 245 265 362 245 266 362 minecraft:moss_block
setblock 247 265 324 minecraft:mushroom_stem
setblock 248 265 323 minecraft:mushroom_stem
setblock 248 265 324 minecraft:moss_block
setblock 248 265 363 minecraft:mushroom_stem
fill 249 265 323 249 266 323 minecraft:moss_block
setblock 249 265 363 minecraft:moss_block
fill 253 265 364 255 298 364 minecraft:moss_block
fill 256 265 322 256 292 322 minecraft:moss_block
setblock 256 265 364 minecraft:red_mushroom_block
fill 257 265 364 257 308 364 minecraft:moss_block
fill 259 265 323 259 268 323 minecraft:moss_block
setblock 259 265 363 minecraft:red_mushroom_block
setblock 262 265 324 minecraft:mushroom_stem
fill 262 265 325 262 268 325 minecraft:moss_block
setblock 263 265 323 minecraft:mushroom_stem
fill 263 265 324 263 268 324 minecraft:moss_block
setblock 263 265 363 minecraft:mushroom_stem
fill 264 265 323 264 268 323 minecraft:moss_block
fill 264 265 363 264 267 363 minecraft:moss_block
setblock 265 265 326 minecraft:mushroom_stem
setblock 266 265 325 minecraft:mushroom_stem
fill 266 265 326 266 268 326 minecraft:moss_block
setblock 267 265 324 minecraft:mushroom_stem
fill 267 265 325 267 268 325 minecraft:moss_block
setblock 268 265 323 minecraft:mushroom_stem
fill 268 265 324 268 268 324 minecraft:moss_block
setblock 268 265 363 minecraft:mushroom_stem
fill 268 265 364 268 308 364 minecraft:moss_block
fill 269 265 323 269 268 323 minecraft:moss_block
fill 269 265 363 269 266 363 minecraft:moss_block
setblock 271 265 325 minecraft:mushroom_stem
setblock 272 265 324 minecraft:mushroom_stem
setblock 272 265 325 minecraft:moss_block
fill 272 265 330 275 265 330 minecraft:mushroom_stem
setblock 273 265 323 minecraft:mushroom_stem
fill 273 265 324 273 267 324 minecraft:moss_block
fill 273 265 329 274 265 329 minecraft:mushroom_stem
fill 273 265 331 274 265 331 minecraft:mushroom_stem
setblock 273 265 363 minecraft:mushroom_stem
fill 274 265 323 274 268 323 minecraft:moss_block
setblock 274 265 363 minecraft:moss_block
setblock 275 265 326 minecraft:mushroom_stem
setblock 275 265 327 minecraft:moss_block
setblock 276 265 325 minecraft:mushroom_stem
fill 276 265 326 276 268 326 minecraft:moss_block
setblock 276 265 330 minecraft:red_mushroom_block
setblock 276 265 338 minecraft:red_mushroom_block
fill 277 265 360 277 308 360 minecraft:moss_block
fill 235 266 348 235 308 348 minecraft:moss_block
setblock 236 266 323 minecraft:moss_block
setblock 236 266 324 minecraft:mushroom_stem
fill 236 266 325 236 267 325 minecraft:moss_block
fill 236 266 329 236 266 330 minecraft:red_mushroom_block
setblock 236 266 349 minecraft:mushroom_stem
fill 236 266 350 236 269 350 minecraft:moss_block
fill 236 266 354 236 267 354 minecraft:red_mushroom_block
setblock 237 266 323 minecraft:mushroom_stem
fill 237 266 330 238 266 330 minecraft:mushroom_stem
setblock 237 266 363 minecraft:mushroom_stem
fill 238 266 323 238 268 323 minecraft:moss_block
fill 238 266 363 238 269 363 minecraft:moss_block
fill 239 266 329 240 267 329 minecraft:mushroom_stem
fill 239 266 331 240 267 331 minecraft:mushroom_stem
fill 240 266 330 240 268 330 minecraft:mushroom_stem
setblock 241 266 324 minecraft:mushroom_stem
setblock 242 266 323 minecraft:mushroom_stem
fill 242 266 324 242 267 324 minecraft:moss_block
setblock 242 266 363 minecraft:mushroom_stem
fill 243 266 323 243 269 323 minecraft:moss_block
fill 243 266 326 243 267 328 minecraft:red_mushroom_block
fill 243 266 348 244 268 348 minecraft:red_mushroom_block
setblock 243 266 362 minecraft:mushroom_stem
fill 243 266 363 243 269 363 minecraft:moss_block
fill 244 266 325 247 266 325 minecraft:red_mushroom_block
fill 244 266 329 247 266 329 minecraft:red_mushroom_block
fill 244 266 347 246 268 347 minecraft:red_mushroom_block
fill 244 266 349 246 268 349 minecraft:red_mushroom_block
setblock 244 266 362 minecraft:moss_block
fill 245 266 350 245 268 350 minecraft:red_mushroom_block
setblock 246 266 324 minecraft:mushroom_stem
fill 246 266 348 246 268 348 minecraft:red_mushroom_block
setblock 247 266 323 minecraft:mushroom_stem
fill 247 266 326 247 267 328 minecraft:red_mushroom_block
setblock 247 266 363 minecraft:mushroom_stem
fill 248 266 323 248 267 323 minecraft:moss_block
setblock 248 266 327 minecraft:red_mushroom_block
setblock 248 266 363 minecraft:moss_block
fill 256 266 364 256 308 364 minecraft:moss_block
setblock 261 266 324 minecraft:mushroom_stem
fill 261 266 338 261 266 341 minecraft:red_mushroom_block
setblock 262 266 323 minecraft:mushroom_stem
fill 262 266 324 262 269 324 minecraft:moss_block
fill 262 266 337 262 266 338 minecraft:red_mushroom_block
fill 262 266 341 262 266 342 minecraft:red_mushroom_block
fill 263 266 323 263 269 323 minecraft:moss_block
fill 263 266 337 265 266 337 minecraft:red_mushroom_block
fill 263 266 342 265 267 342 minecraft:red_mushroom_block
setblock 263 266 363 minecraft:moss_block
setblock 264 266 326 minecraft:mushroom_stem
setblock 265 266 325 minecraft:mushroom_stem
fill 265 266 326 265 269 326 minecraft:moss_block
fill 265 266 338 266 267 338 minecraft:red_mushroom_block
fill 265 266 341 266 267 341 minecraft:red_mushroom_block
setblock 266 266 324 minecraft:mushroom_stem
fill 266 266 325 266 269 325 minecraft:moss_block
fill 266 266 339 266 267 340 minecraft:red_mushroom_block
setblock 267 266 323 minecraft:mushroom_stem
fill 267 266 324 267 269 324 minecraft:moss_block
setblock 267 266 363 minecraft:mushroom_stem
fill 268 266 323 268 269 323 minecraft:moss_block
fill 268 266 363 268 267 363 minecraft:moss_block
setblock 270 266 325 minecraft:mushroom_stem
setblock 271 266 324 minecraft:mushroom_stem
setblock 271 266 325 minecraft:moss_block
fill 271 266 329 273 266 331 minecraft:mushroom_stem
setblock 271 266 363 minecraft:red_mushroom_block
setblock 272 266 323 minecraft:mushroom_stem
fill 272 266 324 272 268 324 minecraft:moss_block
fill 273 266 323 273 269 323 minecraft:moss_block
setblock 274 266 330 minecraft:mushroom_stem
setblock 275 266 325 minecraft:mushroom_stem
setblock 275 266 326 minecraft:moss_block
setblock 275 266 330 minecraft:red_mushroom_block
setblock 276 266 324 minecraft:mushroom_stem
fill 276 266 325 276 269 325 minecraft:moss_block
setblock 276 266 329 minecraft:mushroom_stem
setblock 276 266 332 minecraft:red_mushroom_block
setblock 276 266 357 minecraft:red_mushroom_block
setblock 236 267 324 minecraft:moss_block
setblock 236 267 335 minecraft:red_mushroom_block
setblock 236 267 348 minecraft:mushroom_stem
fill 236 267 349 236 269 349 minecraft:moss_block
fill 236 267 351 236 267 352 minecraft:moss_block
setblock 236 267 360 minecraft:red_mushroom_block
setblock 237 267 323 minecraft:moss_block
setblock 237 267 330 minecraft:red_mushroom_block
setblock 238 267 325 minecraft:light[level=12]
setblock 238 267 330 minecraft:mushroom_stem
setblock 238 267 332 minecraft:light[level=12]
setblock 238 267 339 minecraft:light[level=12]
setblock 238 267 346 minecraft:light[level=12]
setblock 238 267 353 minecraft:light[level=12]
setblock 238 267 360 minecraft:light[level=12]
setblock 241 267 323 minecraft:mushroom_stem
fill 241 267 329 241 268 331 minecraft:mushroom_stem
setblock 241 267 363 minecraft:mushroom_stem
fill 242 267 323 242 269 323 minecraft:moss_block
fill 242 267 330 242 269 330 minecraft:mushroom_stem
fill 242 267 363 242 269 363 minecraft:moss_block
setblock 243 267 347 minecraft:red_mushroom_block
setblock 243 267 349 minecraft:red_mushroom_block
fill 244 267 325 246 267 325 minecraft:red_mushroom_block
fill 244 267 329 246 267 329 minecraft:red_mushroom_block
fill 244 267 346 245 267 346 minecraft:red_mushroom_block
setblock 244 267 350 minecraft:red_mushroom_block
setblock 245 267 324 minecraft:mushroom_stem
setblock 245 267 332 minecraft:light[level=12]
setblock 245 267 339 minecraft:light[level=12]
fill 245 267 348 245 268 348 minecraft:red_mushroom_block
setblock 245 267 353 minecraft:light[level=12]
setblock 245 267 360 minecraft:light[level=12]
setblock 246 267 323 minecraft:mushroom_stem
setblock 246 267 350 minecraft:red_mushroom_block
setblock 246 267 363 minecraft:mushroom_stem
fill 247 267 323 247 268 323 minecraft:moss_block
fill 247 267 348 247 267 349 minecraft:red_mushroom_block
setblock 247 267 363 minecraft:moss_block
setblock 252 267 325 minecraft:light[level=12]
setblock 252 267 332 minecraft:light[level=12]
setblock 252 267 339 minecraft:light[level=12]
setblock 252 267 346 minecraft:light[level=12]
setblock 252 267 353 minecraft:light[level=12]
setblock 252 267 360 minecraft:light[level=12]
setblock 252 267 363 minecraft:red_mushroom_block
setblock 259 267 325 minecraft:light[level=12]
setblock 259 267 332 minecraft:light[level=12]
setblock 259 267 339 minecraft:light[level=12]
setblock 259 267 346 minecraft:light[level=12]
setblock 259 267 353 minecraft:light[level=12]
setblock 259 267 360 minecraft:light[level=12]
setblock 260 267 323 minecraft:moss_block
setblock 260 267 324 minecraft:mushroom_stem
setblock 261 267 323 minecraft:mushroom_stem
fill 261 267 324 261 269 324 minecraft:moss_block
fill 261 267 339 261 267 340 minecraft:red_mushroom_block
fill 262 267 323 262 269 323 minecraft:moss_block
fill 262 267 338 262 268 338 minecraft:red_mushroom_block
fill 262 267 341 262 268 341 minecraft:red_mushroom_block
fill 263 267 337 264 267 337 minecraft:red_mushroom_block
setblock 264 267 325 minecraft:mushroom_stem
fill 264 267 326 264 269 326 minecraft:moss_block
setblock 265 267 324 minecraft:mushroom_stem
fill 265 267 325 265 269 325 minecraft:moss_block
setblock 266 267 323 minecraft:mushroom_stem
fill 266 267 324 266 269 324 minecraft:moss_block
setblock 266 267 332 minecraft:light[level=12]
setblock 266 267 346 minecraft:light[level=12]
setblock 266 267 353 minecraft:light[level=12]
setblock 266 267 360 minecraft:light[level=12]
setblock 266 267 363 minecraft:mushroom_stem
fill 267 267 323 267 269 323 minecraft:moss_block
setblock 267 267 363 minecraft:moss_block
setblock 269 267 325 minecraft:mushroom_stem
fill 269 267 330 273 267 330 minecraft:mushroom_stem
setblock 270 267 324 minecraft:mushroom_stem
setblock 270 267 325 minecraft:moss_block
fill 270 267 329 272 267 329 minecraft:mushroom_stem
fill 270 267 331 272 267 331 minecraft:mushroom_stem
setblock 271 267 323 minecraft:mushroom_stem
fill 271 267 324 271 269 324 minecraft:moss_block
fill 272 267 323 272 269 323 minecraft:moss_block
setblock 273 267 325 minecraft:light[level=12]
setblock 273 267 332 minecraft:light[level=12]
setblock 273 267 339 minecraft:light[level=12]
setblock 273 267 346 minecraft:light[level=12]
setblock 273 267 353 minecraft:light[level=12]
setblock 273 267 360 minecraft:light[level=12]
setblock 274 267 330 minecraft:red_mushroom_block
setblock 276 267 323 minecraft:mushroom_stem
fill 276 267 324 277 269 324 minecraft:moss_block
setblock 276 267 328 minecraft:mushroom_stem
fill 276 267 329 276 269 329 minecraft:moss_block
setblock 276 267 351 minecraft:red_mushroom_block
fill 277 267 325 277 308 325 minecraft:moss_block
setblock 277 267 326 minecraft:shroomlight
fill 235 268 340 235 308 341 minecraft:moss_block
setblock 235 268 342 minecraft:red_mushroom_block
fill 235 268 343 235 308 343 minecraft:moss_block
setblock 236 268 341 minecraft:red_mushroom_block
setblock 236 268 347 minecraft:mushroom_stem
fill 236 268 348 236 269 348 minecraft:moss_block
setblock 236 268 351 minecraft:moss_block
setblock 236 268 352 minecraft:mushroom_stem
fill 236 268 353 236 269 354 minecraft:moss_block
setblock 237 268 350 minecraft:moss_block
setblock 239 268 323 minecraft:moss_block
setblock 239 268 330 minecraft:red_mushroom_block
setblock 240 268 323 minecraft:mushroom_stem
setblock 240 268 363 minecraft:mushroom_stem
fill 241 268 323 241 269 323 minecraft:moss_block
fill 241 268 363 241 269 363 minecraft:moss_block
fill 242 268 329 242 269 329 minecraft:mushroom_stem
fill 242 268 331 242 269 331 minecraft:mushroom_stem
fill 243 268 330 243 269 330 minecraft:mushroom_stem
setblock 245 268 323 minecraft:mushroom_stem
setblock 245 268 325 minecraft:red_mushroom_block
setblock 245 268 363 minecraft:mushroom_stem
fill 246 268 323 246 269 323 minecraft:moss_block
setblock 246 268 363 minecraft:moss_block
setblock 247 268 327 minecraft:red_mushroom_block
setblock 254 268 323 minecraft:red_mushroom_block
setblock 258 268 363 minecraft:red_mushroom_block
setblock 260 268 323 minecraft:mushroom_stem
fill 260 268 324 260 269 324 minecraft:moss_block
fill 261 268 323 261 269 323 minecraft:moss_block
setblock 263 268 325 minecraft:mushroom_stem
setblock 264 268 324 minecraft:mushroom_stem
fill 264 268 325 264 269 325 minecraft:moss_block
setblock 265 268 323 minecraft:mushroom_stem
fill 265 268 324 265 269 324 minecraft:moss_block
setblock 265 268 338 minecraft:red_mushroom_block
setblock 265 268 341 minecraft:red_mushroom_block
setblock 265 268 363 minecraft:mushroom_stem
fill 266 268 323 266 269 323 minecraft:moss_block
setblock 266 268 363 minecraft:moss_block
setblock 268 268 325 minecraft:mushroom_stem
fill 268 268 330 271 268 330 minecraft:mushroom_stem
setblock 269 268 324 minecraft:mushroom_stem
setblock 269 268 325 minecraft:moss_block
fill 269 268 329 270 268 329 minecraft:mushroom_stem
fill 269 268 331 270 268 331 minecraft:mushroom_stem
setblock 270 268 323 minecraft:mushroom_stem
fill 270 268 324 270 269 324 minecraft:moss_block
fill 271 268 323 271 269 323 minecraft:moss_block
setblock 272 268 330 minecraft:red_mushroom_block
setblock 275 268 323 minecraft:mushroom_stem
fill 276 268 323 276 269 323 minecraft:moss_block
setblock 276 268 327 minecraft:mushroom_stem
fill 276 268 328 276 269 328 minecraft:moss_block
fill 276 268 330 276 269 330 minecraft:moss_block
setblock 276 268 345 minecraft:red_mushroom_block
fill 277 268 326 277 292 326 minecraft:moss_block
fill 235 269 324 235 308 324 minecraft:moss_block
setblock 235 269 325 minecraft:shroomlight
fill 235 269 326 235 308 326 minecraft:moss_block
fill 235 269 342 235 308 342 minecraft:moss_block
setblock 236 269 328 minecraft:red_mushroom_block
setblock 236 269 347 minecraft:moss_block
setblock 236 269 351 minecraft:mushroom_stem
fill 236 269 352 237 269 352 minecraft:moss_block
setblock 236 269 355 minecraft:moss_block
setblock 236 269 356 minecraft:mushroom_stem
fill 237 269 348 237 269 349 minecraft:moss_block
setblock 237 269 350 minecraft:mushroom_stem
setblock 237 269 351 minecraft:moss_block
setblock 237 269 353 minecraft:moss_block
setblock 238 269 325 minecraft:light[level=15]
setblock 238 269 333 minecraft:light[level=15]
setblock 238 269 341 minecraft:light[level=15]
setblock 238 269 349 minecraft:light[level=15]
setblock 238 269 357 minecraft:light[level=15]
setblock 239 269 323 minecraft:mushroom_stem
setblock 239 269 363 minecraft:mushroom_stem
setblock 240 269 323 minecraft:moss_block
setblock 240 269 330 minecraft:red_mushroom_block
setblock 240 269 363 minecraft:moss_block
setblock 241 269 330 minecraft:mushroom_stem
fill 243 269 329 244 269 329 minecraft:mushroom_stem
fill 243 269 331 244 269 331 minecraft:mushroom_stem
setblock 244 269 323 minecraft:mushroom_stem
fill 244 269 330 245 269 330 minecraft:mushroom_stem
setblock 244 269 363 minecraft:mushroom_stem
setblock 245 269 323 minecraft:moss_block
setblock 245 269 363 minecraft:moss_block
setblock 246 269 325 minecraft:light[level=15]
setblock 246 269 333 minecraft:light[level=15]
setblock 246 269 341 minecraft:light[level=15]
setblock 246 269 349 minecraft:light[level=15]
setblock 246 269 357 minecraft:light[level=15]
setblock 248 269 323 minecraft:red_mushroom_block
setblock 254 269 325 minecraft:light[level=15]
setblock 254 269 333 minecraft:light[level=15]
setblock 254 269 341 minecraft:light[level=15]
setblock 254 269 349 minecraft:light[level=15]
setblock 254 269 357 minecraft:light[level=15]
setblock 259 269 323 minecraft:mushroom_stem
setblock 260 269 323 minecraft:moss_block
setblock 261 269 325 minecraft:moss_block
setblock 262 269 325 minecraft:mushroom_stem
setblock 262 269 333 minecraft:light[level=15]
setblock 262 269 341 minecraft:light[level=15]
setblock 262 269 349 minecraft:light[level=15]
setblock 262 269 357 minecraft:light[level=15]
setblock 263 269 324 minecraft:mushroom_stem
setblock 263 269 325 minecraft:moss_block
setblock 264 269 323 minecraft:mushroom_stem
setblock 264 269 324 minecraft:moss_block
setblock 264 269 363 minecraft:red_mushroom_block
setblock 265 269 323 minecraft:moss_block
fill 266 269 330 270 269 330 minecraft:mushroom_stem
setblock 267 269 325 minecraft:mushroom_stem
fill 267 269 329 269 269 329 minecraft:mushroom_stem
fill 267 269 331 269 269 331 minecraft:mushroom_stem
setblock 268 269 324 minecraft:mushroom_stem
setblock 268 269 325 minecraft:moss_block
setblock 269 269 323 minecraft:mushroom_stem
setblock 269 269 324 minecraft:moss_block
setblock 270 269 323 minecraft:moss_block
setblock 270 269 325 minecraft:light[level=15]
setblock 270 269 333 minecraft:light[level=15]
setblock 270 269 341 minecraft:light[level=15]
setblock 270 269 349 minecraft:light[level=15]
setblock 270 269 357 minecraft:light[level=15]
setblock 271 269 330 minecraft:red_mushroom_block
setblock 274 269 323 minecraft:mushroom_stem
setblock 275 269 323 minecraft:moss_block
setblock 276 269 326 minecraft:mushroom_stem
setblock 276 269 327 minecraft:moss_block
setblock 276 269 339 minecraft:red_mushroom_block
setblock 276 269 358 minecraft:red_mushroom_block
fill 277 269 338 277 275 340 minecraft:moss_block
setblock 277 269 341 minecraft:red_mushroom_block
fill 235 270 325 235 308 325 minecraft:moss_block
fill 238 270 349 242 270 351 minecraft:red_mushroom_block
fill 239 270 348 241 270 348 minecraft:red_mushroom_block
fill 239 270 352 241 270 352 minecraft:red_mushroom_block
fill 277 270 324 277 308 324 minecraft:moss_block
fill 277 270 341 277 308 341 minecraft:moss_block
fill 266 272 364 266 308 364 minecraft:moss_block
setblock 267 272 364 minecraft:shroomlight
fill 277 272 354 277 296 356 minecraft:moss_block
setblock 277 272 357 minecraft:red_mushroom_block
setblock 277 272 358 minecraft:moss_block
setblock 238 273 325 minecraft:light[level=12]
setblock 238 273 332 minecraft:light[level=12]
setblock 238 273 339 minecraft:light[level=12]
setblock 238 273 346 minecraft:light[level=12]
setblock 238 273 353 minecraft:light[level=12]
setblock 238 273 360 minecraft:light[level=12]
setblock 245 273 325 minecraft:light[level=12]
setblock 245 273 332 minecraft:light[level=12]
setblock 245 273 339 minecraft:light[level=12]
setblock 245 273 346 minecraft:light[level=12]
setblock 245 273 353 minecraft:light[level=12]
setblock 245 273 360 minecraft:light[level=12]
setblock 252 273 325 minecraft:light[level=12]
setblock 252 273 332 minecraft:light[level=12]
setblock 252 273 339 minecraft:light[level=12]
setblock 252 273 346 minecraft:light[level=12]
setblock 252 273 353 minecraft:light[level=12]
setblock 252 273 360 minecraft:light[level=12]
setblock 259 273 325 minecraft:light[level=12]
setblock 259 273 332 minecraft:light[level=12]
setblock 259 273 339 minecraft:light[level=12]
setblock 259 273 346 minecraft:light[level=12]
setblock 259 273 353 minecraft:light[level=12]
setblock 259 273 360 minecraft:light[level=12]
setblock 266 273 325 minecraft:light[level=12]
setblock 266 273 332 minecraft:light[level=12]
setblock 266 273 339 minecraft:light[level=12]
setblock 266 273 346 minecraft:light[level=12]
setblock 266 273 353 minecraft:light[level=12]
setblock 266 273 360 minecraft:light[level=12]
fill 267 273 364 267 308 364 minecraft:moss_block
setblock 273 273 325 minecraft:light[level=12]
setblock 273 273 332 minecraft:light[level=12]
setblock 273 273 339 minecraft:light[level=12]
setblock 273 273 346 minecraft:light[level=12]
setblock 273 273 353 minecraft:light[level=12]
setblock 273 273 360 minecraft:light[level=12]
fill 277 273 357 277 308 357 minecraft:moss_block
setblock 277 273 358 minecraft:shroomlight
setblock 277 274 328 minecraft:red_mushroom_block
fill 277 274 358 277 308 358 minecraft:moss_block
fill 241 275 339 242 275 349 minecraft:red_mushroom_block
fill 242 275 337 242 275 338 minecraft:red_mushroom_block
fill 242 275 350 242 275 351 minecraft:red_mushroom_block
fill 243 275 336 267 276 336 minecraft:red_mushroom_block
schedule function dropper:buildpart/77_9 1t
