fill 517 172 284 517 175 284 minecraft:brown_terracotta
fill 517 172 293 517 174 293 minecraft:brown_terracotta
fill 517 172 294 517 172 295 minecraft:shroomlight
fill 517 172 296 517 175 296 minecraft:brown_terracotta
fill 517 172 305 517 174 305 minecraft:brown_terracotta
fill 517 172 306 517 172 307 minecraft:shroomlight
fill 517 172 308 517 175 308 minecraft:brown_terracotta
fill 517 172 317 517 174 317 minecraft:brown_terracotta
fill 518 172 317 519 172 317 minecraft:shroomlight
fill 519 172 295 519 173 297 minecraft:white_concrete
fill 520 172 296 520 175 296 minecraft:white_concrete
fill 520 172 317 520 175 317 minecraft:brown_terracotta
fill 524 172 275 524 175 275 minecraft:brown_terracotta
fill 525 172 275 526 172 275 minecraft:shroomlight
fill 527 172 275 527 174 275 minecraft:brown_terracotta
fill 529 172 317 529 176 317 minecraft:brown_terracotta
fill 530 172 317 531 172 317 minecraft:shroomlight
fill 532 172 317 532 175 317 minecraft:brown_terracotta
fill 536 172 275 536 175 275 minecraft:brown_terracotta
fill 537 172 275 538 172 275 minecraft:shroomlight
fill 539 172 275 539 174 275 minecraft:brown_terracotta
fill 541 172 317 541 176 317 minecraft:brown_terracotta
fill 542 172 317 543 172 317 minecraft:shroomlight
fill 544 172 317 544 175 317 minecraft:brown_terracotta
fill 545 172 311 549 172 315 minecraft:white_concrete
fill 548 172 275 548 175 275 minecraft:brown_terracotta
setblock 548 172 284 minecraft:shroomlight
setblock 548 172 286 minecraft:shroomlight
setblock 548 172 288 minecraft:shroomlight
fill 549 172 275 550 172 275 minecraft:shroomlight
setblock 549 172 283 minecraft:shroomlight
setblock 549 172 285 minecraft:shroomlight
setblock 549 172 287 minecraft:shroomlight
setblock 549 172 289 minecraft:shroomlight
setblock 550 172 284 minecraft:shroomlight
setblock 550 172 286 minecraft:shroomlight
setblock 550 172 288 minecraft:shroomlight
fill 551 172 275 551 174 275 minecraft:brown_terracotta
setblock 551 172 283 minecraft:shroomlight
setblock 551 172 285 minecraft:shroomlight
setblock 551 172 287 minecraft:shroomlight
setblock 551 172 289 minecraft:shroomlight
setblock 552 172 284 minecraft:shroomlight
setblock 552 172 286 minecraft:shroomlight
setblock 552 172 288 minecraft:shroomlight
fill 553 172 276 553 172 280 minecraft:red_concrete
setblock 553 172 283 minecraft:shroomlight
setblock 553 172 285 minecraft:shroomlight
setblock 553 172 287 minecraft:shroomlight
setblock 553 172 289 minecraft:shroomlight
fill 553 172 317 553 176 317 minecraft:brown_terracotta
fill 554 172 277 555 172 280 minecraft:red_concrete
setblock 554 172 284 minecraft:shroomlight
setblock 554 172 286 minecraft:shroomlight
setblock 554 172 288 minecraft:shroomlight
fill 554 172 317 555 172 317 minecraft:shroomlight
setblock 555 172 283 minecraft:shroomlight
setblock 555 172 285 minecraft:shroomlight
setblock 555 172 287 minecraft:shroomlight
setblock 555 172 289 minecraft:shroomlight
setblock 556 172 284 minecraft:shroomlight
setblock 556 172 286 minecraft:shroomlight
setblock 556 172 288 minecraft:shroomlight
fill 556 172 317 556 175 317 minecraft:brown_terracotta
setblock 557 172 283 minecraft:shroomlight
setblock 557 172 285 minecraft:shroomlight
setblock 557 172 287 minecraft:shroomlight
setblock 557 172 289 minecraft:shroomlight
setblock 558 172 284 minecraft:shroomlight
setblock 558 172 286 minecraft:shroomlight
setblock 558 172 288 minecraft:shroomlight
fill 559 172 276 559 175 276 minecraft:brown_terracotta
fill 559 172 279 559 176 279 minecraft:brown_terracotta
fill 559 172 288 559 175 288 minecraft:brown_terracotta
fill 559 172 289 559 172 290 minecraft:shroomlight
fill 559 172 291 559 176 291 minecraft:brown_terracotta
fill 559 172 300 559 175 300 minecraft:brown_terracotta
fill 559 172 301 559 172 302 minecraft:shroomlight
fill 559 172 303 559 176 303 minecraft:brown_terracotta
fill 559 172 312 559 175 312 minecraft:brown_terracotta
fill 559 172 313 559 172 314 minecraft:shroomlight
fill 559 172 315 559 176 315 minecraft:brown_terracotta
fill 517 173 282 517 175 283 minecraft:brown_terracotta
fill 517 173 294 517 175 295 minecraft:brown_terracotta
fill 517 173 306 517 175 307 minecraft:brown_terracotta
setblock 518 173 296 minecraft:white_concrete
fill 518 173 317 519 174 317 minecraft:brown_terracotta
setblock 520 173 278 minecraft:light[level=15]
setblock 520 173 286 minecraft:light[level=15]
setblock 520 173 294 minecraft:light[level=15]
fill 520 173 295 520 174 295 minecraft:white_concrete
fill 520 173 297 520 174 297 minecraft:white_concrete
setblock 520 173 302 minecraft:light[level=15]
setblock 520 173 310 minecraft:light[level=15]
fill 521 173 296 521 175 296 minecraft:white_concrete
fill 525 173 275 526 175 275 minecraft:brown_terracotta
setblock 528 173 278 minecraft:light[level=15]
setblock 528 173 286 minecraft:light[level=15]
setblock 528 173 294 minecraft:light[level=15]
setblock 528 173 302 minecraft:light[level=15]
setblock 528 173 310 minecraft:light[level=15]
fill 530 173 317 531 174 317 minecraft:brown_terracotta
fill 533 173 308 534 174 309 minecraft:white_concrete
setblock 536 173 278 minecraft:light[level=15]
setblock 536 173 286 minecraft:light[level=15]
setblock 536 173 294 minecraft:light[level=15]
setblock 536 173 302 minecraft:light[level=15]
setblock 536 173 310 minecraft:light[level=15]
fill 537 173 275 538 175 275 minecraft:brown_terracotta
fill 542 173 317 543 174 317 minecraft:brown_terracotta
setblock 544 173 278 minecraft:light[level=15]
setblock 544 173 286 minecraft:light[level=15]
setblock 544 173 294 minecraft:light[level=15]
setblock 544 173 302 minecraft:light[level=15]
setblock 544 173 310 minecraft:light[level=15]
fill 546 173 311 548 173 315 minecraft:white_concrete
fill 548 173 284 548 174 284 minecraft:white_concrete
fill 548 173 286 548 174 286 minecraft:white_concrete
fill 548 173 288 548 174 288 minecraft:white_concrete
fill 549 173 275 550 175 275 minecraft:brown_terracotta
fill 549 173 283 549 174 283 minecraft:white_concrete
fill 549 173 285 549 174 285 minecraft:white_concrete
fill 549 173 287 549 174 287 minecraft:white_concrete
fill 549 173 289 549 174 289 minecraft:white_concrete
fill 550 173 284 550 174 284 minecraft:white_concrete
fill 550 173 286 550 174 286 minecraft:white_concrete
fill 550 173 288 550 174 288 minecraft:white_concrete
fill 551 173 283 551 174 283 minecraft:white_concrete
fill 551 173 285 551 174 285 minecraft:white_concrete
fill 551 173 287 551 174 287 minecraft:white_concrete
fill 551 173 289 551 174 289 minecraft:white_concrete
setblock 552 173 278 minecraft:light[level=15]
fill 552 173 284 552 174 284 minecraft:white_concrete
fill 552 173 286 552 174 286 minecraft:white_concrete
fill 552 173 288 552 174 288 minecraft:white_concrete
setblock 552 173 294 minecraft:light[level=15]
setblock 552 173 302 minecraft:light[level=15]
setblock 552 173 310 minecraft:light[level=15]
fill 553 173 283 553 174 283 minecraft:white_concrete
fill 553 173 285 553 174 285 minecraft:white_concrete
fill 553 173 287 553 174 287 minecraft:white_concrete
fill 553 173 289 553 174 289 minecraft:white_concrete
fill 554 173 277 554 173 279 minecraft:red_concrete
fill 554 173 284 554 174 284 minecraft:white_concrete
fill 554 173 286 554 174 286 minecraft:white_concrete
fill 554 173 288 554 174 288 minecraft:white_concrete
fill 554 173 317 555 174 317 minecraft:brown_terracotta
fill 555 173 283 555 174 283 minecraft:white_concrete
fill 555 173 285 555 174 285 minecraft:white_concrete
fill 555 173 287 555 174 287 minecraft:white_concrete
fill 555 173 289 555 174 289 minecraft:white_concrete
fill 556 173 284 556 174 284 minecraft:white_concrete
fill 556 173 286 556 174 286 minecraft:white_concrete
fill 556 173 288 556 174 288 minecraft:white_concrete
fill 556 173 295 556 174 295 minecraft:orange_terracotta
fill 557 173 283 557 174 283 minecraft:white_concrete
fill 557 173 285 557 174 285 minecraft:white_concrete
fill 557 173 287 557 174 287 minecraft:white_concrete
fill 557 173 289 557 174 289 minecraft:white_concrete
fill 558 173 284 558 213 284 minecraft:white_concrete
fill 558 173 286 558 213 286 minecraft:white_concrete
fill 558 173 288 558 174 288 minecraft:white_concrete
fill 559 173 277 559 174 278 minecraft:brown_terracotta
fill 559 173 289 559 174 290 minecraft:brown_terracotta
fill 559 173 301 559 174 302 minecraft:brown_terracotta
fill 559 173 313 559 174 314 minecraft:brown_terracotta
setblock 518 174 296 minecraft:red_concrete
fill 519 174 279 519 174 281 minecraft:brown_terracotta
setblock 519 174 296 minecraft:white_concrete
fill 520 174 278 522 174 278 minecraft:brown_terracotta
fill 520 174 282 522 174 282 minecraft:brown_terracotta
fill 521 174 295 521 175 295 minecraft:white_concrete
fill 521 174 297 521 175 297 minecraft:white_concrete
fill 522 174 296 522 175 296 minecraft:white_concrete
fill 523 174 279 523 174 281 minecraft:brown_terracotta
fill 547 174 311 547 174 315 minecraft:white_concrete
fill 553 174 296 553 176 296 minecraft:white_concrete
setblock 517 175 277 minecraft:white_concrete
setblock 517 175 281 minecraft:white_concrete
setblock 517 175 285 minecraft:white_concrete
setblock 517 175 289 minecraft:white_concrete
setblock 517 175 293 minecraft:white_concrete
setblock 517 175 297 minecraft:white_concrete
setblock 517 175 301 minecraft:white_concrete
setblock 517 175 305 minecraft:white_concrete
setblock 517 175 309 minecraft:white_concrete
setblock 517 175 313 minecraft:white_concrete
setblock 517 175 317 minecraft:white_concrete
setblock 518 175 317 minecraft:brown_terracotta
setblock 519 175 275 minecraft:white_concrete
setblock 519 175 296 minecraft:red_concrete
setblock 519 175 317 minecraft:white_concrete
setblock 520 175 278 minecraft:light[level=12]
setblock 520 175 285 minecraft:light[level=12]
setblock 520 175 292 minecraft:light[level=12]
setblock 520 175 299 minecraft:light[level=12]
setblock 520 175 306 minecraft:light[level=12]
setblock 520 175 313 minecraft:light[level=12]
fill 522 175 295 523 175 295 minecraft:white_concrete
fill 522 175 297 523 175 297 minecraft:white_concrete
setblock 523 175 275 minecraft:white_concrete
fill 523 175 296 524 177 296 minecraft:white_concrete
setblock 523 175 317 minecraft:white_concrete
setblock 527 175 275 minecraft:white_concrete
setblock 527 175 278 minecraft:light[level=12]
setblock 527 175 285 minecraft:light[level=12]
setblock 527 175 292 minecraft:light[level=12]
setblock 527 175 299 minecraft:light[level=12]
setblock 527 175 306 minecraft:light[level=12]
setblock 527 175 313 minecraft:light[level=12]
setblock 527 175 317 minecraft:white_concrete
setblock 530 175 317 minecraft:brown_terracotta
setblock 531 175 275 minecraft:white_concrete
setblock 531 175 317 minecraft:white_concrete
setblock 534 175 278 minecraft:light[level=12]
setblock 534 175 285 minecraft:light[level=12]
setblock 534 175 292 minecraft:light[level=12]
setblock 534 175 306 minecraft:light[level=12]
setblock 534 175 313 minecraft:light[level=12]
setblock 535 175 275 minecraft:white_concrete
setblock 535 175 317 minecraft:white_concrete
setblock 539 175 275 minecraft:white_concrete
setblock 539 175 317 minecraft:white_concrete
setblock 541 175 278 minecraft:light[level=12]
setblock 541 175 285 minecraft:light[level=12]
setblock 541 175 292 minecraft:light[level=12]
setblock 541 175 299 minecraft:light[level=12]
setblock 541 175 306 minecraft:light[level=12]
setblock 541 175 313 minecraft:light[level=12]
setblock 542 175 317 minecraft:brown_terracotta
setblock 543 175 275 minecraft:white_concrete
setblock 543 175 317 minecraft:white_concrete
setblock 547 175 275 minecraft:white_concrete
setblock 547 175 317 minecraft:white_concrete
setblock 548 175 278 minecraft:light[level=12]
setblock 548 175 285 minecraft:light[level=12]
setblock 548 175 292 minecraft:light[level=12]
setblock 548 175 299 minecraft:light[level=12]
setblock 548 175 306 minecraft:light[level=12]
setblock 548 175 313 minecraft:light[level=12]
fill 549 175 284 557 175 288 minecraft:red_concrete
setblock 551 175 275 minecraft:white_concrete
fill 551 175 296 552 177 296 minecraft:white_concrete
setblock 551 175 317 minecraft:white_concrete
fill 552 175 295 558 175 295 minecraft:white_concrete
fill 552 175 297 559 175 297 minecraft:white_concrete
fill 554 175 293 558 175 294 minecraft:white_concrete
fill 554 175 296 558 175 296 minecraft:white_concrete
setblock 554 175 317 minecraft:brown_terracotta
setblock 555 175 275 minecraft:white_concrete
setblock 555 175 278 minecraft:light[level=12]
setblock 555 175 292 minecraft:light[level=12]
setblock 555 175 299 minecraft:light[level=12]
setblock 555 175 306 minecraft:light[level=12]
setblock 555 175 313 minecraft:light[level=12]
setblock 555 175 317 minecraft:white_concrete
setblock 559 175 275 minecraft:white_concrete
setblock 559 175 277 minecraft:white_concrete
setblock 559 175 278 minecraft:brown_terracotta
setblock 559 175 281 minecraft:white_concrete
setblock 559 175 285 minecraft:white_concrete
setblock 559 175 289 minecraft:white_concrete
setblock 559 175 290 minecraft:brown_terracotta
setblock 559 175 293 minecraft:white_concrete
setblock 559 175 301 minecraft:white_concrete
setblock 559 175 302 minecraft:brown_terracotta
setblock 559 175 305 minecraft:white_concrete
setblock 559 175 309 minecraft:white_concrete
setblock 559 175 313 minecraft:white_concrete
setblock 559 175 314 minecraft:brown_terracotta
setblock 559 175 317 minecraft:white_concrete
setblock 517 176 276 minecraft:white_concrete
fill 517 176 277 517 183 277 minecraft:brown_terracotta
setblock 517 176 278 minecraft:white_concrete
setblock 517 176 280 minecraft:white_concrete
fill 517 176 281 517 183 281 minecraft:brown_terracotta
setblock 517 176 282 minecraft:white_concrete
setblock 517 176 283 minecraft:brown_terracotta
setblock 517 176 284 minecraft:white_concrete
fill 517 176 285 517 183 285 minecraft:brown_terracotta
setblock 517 176 286 minecraft:white_concrete
setblock 517 176 288 minecraft:white_concrete
fill 517 176 289 517 183 289 minecraft:brown_terracotta
setblock 517 176 290 minecraft:white_concrete
setblock 517 176 292 minecraft:white_concrete
fill 517 176 293 517 183 293 minecraft:brown_terracotta
setblock 517 176 294 minecraft:white_concrete
setblock 517 176 295 minecraft:brown_terracotta
setblock 517 176 296 minecraft:white_concrete
fill 517 176 297 517 183 297 minecraft:brown_terracotta
setblock 517 176 298 minecraft:white_concrete
setblock 517 176 300 minecraft:white_concrete
fill 517 176 301 517 183 301 minecraft:brown_terracotta
setblock 517 176 302 minecraft:white_concrete
setblock 517 176 304 minecraft:white_concrete
fill 517 176 305 517 183 305 minecraft:brown_terracotta
setblock 517 176 306 minecraft:white_concrete
setblock 517 176 307 minecraft:brown_terracotta
setblock 517 176 308 minecraft:white_concrete
fill 517 176 309 517 183 309 minecraft:brown_terracotta
setblock 517 176 310 minecraft:white_concrete
setblock 517 176 312 minecraft:white_concrete
fill 517 176 313 517 183 313 minecraft:brown_terracotta
setblock 517 176 314 minecraft:white_concrete
setblock 517 176 316 minecraft:white_concrete
setblock 517 176 317 minecraft:brown_terracotta
setblock 518 176 275 minecraft:white_concrete
setblock 518 176 317 minecraft:white_concrete
fill 519 176 275 519 183 275 minecraft:brown_terracotta
fill 519 176 317 519 183 317 minecraft:brown_terracotta
setblock 520 176 275 minecraft:white_concrete
setblock 520 176 317 minecraft:white_concrete
fill 521 176 296 522 176 296 minecraft:red_concrete
setblock 522 176 275 minecraft:white_concrete
setblock 522 176 317 minecraft:white_concrete
fill 523 176 275 523 183 275 minecraft:brown_terracotta
fill 523 176 295 524 176 295 minecraft:white_concrete
fill 523 176 297 524 176 297 minecraft:white_concrete
fill 523 176 317 523 183 317 minecraft:brown_terracotta
setblock 524 176 275 minecraft:white_concrete
setblock 524 176 317 minecraft:white_concrete
setblock 525 176 275 minecraft:brown_terracotta
fill 525 176 296 525 178 296 minecraft:white_concrete
setblock 526 176 275 minecraft:white_concrete
setblock 526 176 317 minecraft:white_concrete
fill 527 176 275 527 183 275 minecraft:brown_terracotta
fill 527 176 317 527 183 317 minecraft:brown_terracotta
setblock 528 176 275 minecraft:white_concrete
setblock 528 176 317 minecraft:white_concrete
setblock 530 176 275 minecraft:white_concrete
setblock 530 176 317 minecraft:white_concrete
fill 531 176 275 531 183 275 minecraft:brown_terracotta
fill 531 176 317 531 183 317 minecraft:brown_terracotta
setblock 532 176 275 minecraft:white_concrete
setblock 532 176 317 minecraft:white_concrete
setblock 534 176 275 minecraft:white_concrete
setblock 534 176 317 minecraft:white_concrete
fill 535 176 275 535 183 275 minecraft:brown_terracotta
fill 535 176 317 535 183 317 minecraft:brown_terracotta
setblock 536 176 275 minecraft:white_concrete
setblock 536 176 317 minecraft:white_concrete
setblock 537 176 275 minecraft:brown_terracotta
setblock 538 176 275 minecraft:white_concrete
setblock 538 176 317 minecraft:white_concrete
fill 539 176 275 539 183 275 minecraft:brown_terracotta
fill 539 176 317 539 183 317 minecraft:brown_terracotta
setblock 540 176 275 minecraft:white_concrete
setblock 540 176 317 minecraft:white_concrete
setblock 542 176 275 minecraft:white_concrete
setblock 542 176 317 minecraft:white_concrete
fill 543 176 275 543 183 275 minecraft:brown_terracotta
fill 543 176 317 543 183 317 minecraft:brown_terracotta
setblock 544 176 275 minecraft:white_concrete
setblock 544 176 317 minecraft:white_concrete
setblock 546 176 275 minecraft:white_concrete
setblock 546 176 317 minecraft:white_concrete
fill 547 176 275 547 183 275 minecraft:brown_terracotta
fill 547 176 317 547 183 317 minecraft:brown_terracotta
setblock 548 176 275 minecraft:white_concrete
setblock 548 176 317 minecraft:white_concrete
setblock 549 176 275 minecraft:brown_terracotta
setblock 550 176 275 minecraft:white_concrete
fill 550 176 285 556 176 287 minecraft:red_concrete
fill 550 176 296 550 178 296 minecraft:white_concrete
setblock 550 176 317 minecraft:white_concrete
fill 551 176 275 551 183 275 minecraft:brown_terracotta
fill 551 176 295 552 176 295 minecraft:white_concrete
fill 551 176 297 552 176 297 minecraft:white_concrete
fill 551 176 317 551 183 317 minecraft:brown_terracotta
setblock 552 176 275 minecraft:white_concrete
setblock 552 176 317 minecraft:white_concrete
setblock 554 176 275 minecraft:white_concrete
setblock 554 176 296 minecraft:red_concrete
setblock 554 176 317 minecraft:white_concrete
fill 555 176 275 555 183 275 minecraft:brown_terracotta
fill 555 176 293 557 176 297 minecraft:white_concrete
fill 555 176 317 555 183 317 minecraft:brown_terracotta
setblock 556 176 275 minecraft:white_concrete
setblock 556 176 317 minecraft:white_concrete
setblock 558 176 275 minecraft:white_concrete
fill 558 176 296 558 213 297 minecraft:white_concrete
setblock 558 176 317 minecraft:white_concrete
setblock 559 176 275 minecraft:brown_terracotta
setblock 559 176 276 minecraft:white_concrete
fill 559 176 277 559 183 277 minecraft:brown_terracotta
setblock 559 176 278 minecraft:white_concrete
setblock 559 176 280 minecraft:white_concrete
fill 559 176 281 559 183 281 minecraft:brown_terracotta
setblock 559 176 282 minecraft:white_concrete
setblock 559 176 284 minecraft:white_concrete
fill 559 176 285 559 183 285 minecraft:brown_terracotta
setblock 559 176 286 minecraft:white_concrete
setblock 559 176 288 minecraft:white_concrete
fill 559 176 289 559 183 289 minecraft:brown_terracotta
setblock 559 176 290 minecraft:white_concrete
setblock 559 176 292 minecraft:white_concrete
fill 559 176 293 559 183 293 minecraft:brown_terracotta
setblock 559 176 294 minecraft:white_concrete
setblock 559 176 296 minecraft:white_concrete
fill 559 176 297 559 183 297 minecraft:brown_terracotta
setblock 559 176 298 minecraft:white_concrete
setblock 559 176 300 minecraft:white_concrete
fill 559 176 301 559 183 301 minecraft:brown_terracotta
setblock 559 176 302 minecraft:white_concrete
setblock 559 176 304 minecraft:white_concrete
fill 559 176 305 559 183 305 minecraft:brown_terracotta
setblock 559 176 306 minecraft:white_concrete
setblock 559 176 308 minecraft:white_concrete
fill 559 176 309 559 183 309 minecraft:brown_terracotta
setblock 559 176 310 minecraft:white_concrete
setblock 559 176 312 minecraft:white_concrete
fill 559 176 313 559 183 313 minecraft:brown_terracotta
setblock 559 176 314 minecraft:white_concrete
setblock 559 176 316 minecraft:white_concrete
fill 559 176 317 559 183 317 minecraft:brown_terracotta
setblock 517 177 275 minecraft:white_concrete
fill 517 177 276 517 184 276 minecraft:brown_terracotta
fill 517 177 278 517 184 278 minecraft:brown_terracotta
setblock 517 177 279 minecraft:white_concrete
fill 517 177 280 517 184 280 minecraft:brown_terracotta
fill 517 177 282 517 184 282 minecraft:brown_terracotta
setblock 517 177 283 minecraft:white_concrete
fill 517 177 284 517 184 284 minecraft:brown_terracotta
fill 517 177 286 517 184 286 minecraft:brown_terracotta
setblock 517 177 287 minecraft:white_concrete
fill 517 177 288 517 184 288 minecraft:brown_terracotta
fill 517 177 290 517 184 290 minecraft:brown_terracotta
setblock 517 177 291 minecraft:white_concrete
fill 517 177 292 517 184 292 minecraft:brown_terracotta
fill 517 177 294 517 184 294 minecraft:brown_terracotta
setblock 517 177 295 minecraft:white_concrete
fill 517 177 296 517 184 296 minecraft:brown_terracotta
fill 517 177 298 517 184 298 minecraft:brown_terracotta
setblock 517 177 299 minecraft:white_concrete
fill 517 177 300 517 184 300 minecraft:brown_terracotta
fill 517 177 302 517 184 302 minecraft:brown_terracotta
setblock 517 177 303 minecraft:white_concrete
fill 517 177 304 517 184 304 minecraft:brown_terracotta
fill 517 177 306 517 184 306 minecraft:brown_terracotta
setblock 517 177 307 minecraft:white_concrete
fill 517 177 308 517 184 308 minecraft:brown_terracotta
fill 517 177 310 517 184 310 minecraft:brown_terracotta
setblock 517 177 311 minecraft:white_concrete
fill 517 177 312 517 184 312 minecraft:brown_terracotta
fill 517 177 314 517 184 314 minecraft:brown_terracotta
setblock 517 177 315 minecraft:white_concrete
fill 517 177 316 517 184 316 minecraft:brown_terracotta
setblock 517 177 317 minecraft:white_concrete
fill 518 177 275 518 184 275 minecraft:brown_terracotta
fill 518 177 317 518 184 317 minecraft:brown_terracotta
fill 520 177 275 520 184 275 minecraft:brown_terracotta
fill 520 177 317 520 184 317 minecraft:brown_terracotta
setblock 521 177 275 minecraft:white_concrete
setblock 521 177 317 minecraft:white_concrete
fill 522 177 275 522 184 275 minecraft:brown_terracotta
setblock 522 177 296 minecraft:red_concrete
fill 522 177 317 522 184 317 minecraft:brown_terracotta
fill 524 177 275 524 184 275 minecraft:brown_terracotta
fill 524 177 295 526 177 295 minecraft:white_concrete
fill 524 177 297 526 177 297 minecraft:white_concrete
fill 524 177 317 524 184 317 minecraft:brown_terracotta
setblock 525 177 275 minecraft:white_concrete
setblock 525 177 317 minecraft:white_concrete
fill 526 177 275 526 184 275 minecraft:brown_terracotta
fill 526 177 296 527 178 296 minecraft:white_concrete
fill 526 177 317 526 184 317 minecraft:brown_terracotta
fill 528 177 275 528 184 275 minecraft:brown_terracotta
fill 528 177 317 528 184 317 minecraft:brown_terracotta
setblock 529 177 275 minecraft:white_concrete
setblock 529 177 317 minecraft:white_concrete
fill 530 177 275 530 184 275 minecraft:brown_terracotta
fill 530 177 317 530 184 317 minecraft:brown_terracotta
fill 532 177 275 532 184 275 minecraft:brown_terracotta
fill 532 177 317 532 184 317 minecraft:brown_terracotta
setblock 533 177 275 minecraft:white_concrete
setblock 533 177 317 minecraft:white_concrete
fill 534 177 275 534 184 275 minecraft:brown_terracotta
fill 534 177 317 534 184 317 minecraft:brown_terracotta
fill 536 177 275 536 184 275 minecraft:brown_terracotta
fill 536 177 317 536 184 317 minecraft:brown_terracotta
setblock 537 177 275 minecraft:white_concrete
setblock 537 177 317 minecraft:white_concrete
fill 538 177 275 538 184 275 minecraft:brown_terracotta
fill 538 177 317 538 184 317 minecraft:brown_terracotta
fill 540 177 275 540 184 275 minecraft:brown_terracotta
fill 540 177 317 540 184 317 minecraft:brown_terracotta
setblock 541 177 275 minecraft:white_concrete
setblock 541 177 317 minecraft:white_concrete
fill 542 177 275 542 184 275 minecraft:brown_terracotta
fill 542 177 317 542 184 317 minecraft:brown_terracotta
fill 544 177 275 544 184 275 minecraft:brown_terracotta
fill 544 177 317 544 184 317 minecraft:brown_terracotta
setblock 545 177 275 minecraft:white_concrete
setblock 545 177 317 minecraft:white_concrete
fill 546 177 275 546 184 275 minecraft:brown_terracotta
fill 546 177 317 546 184 317 minecraft:brown_terracotta
fill 548 177 275 548 184 275 minecraft:brown_terracotta
fill 548 177 296 549 179 296 minecraft:white_concrete
fill 548 177 317 548 184 317 minecraft:brown_terracotta
setblock 549 177 275 minecraft:white_concrete
fill 549 177 295 551 177 295 minecraft:white_concrete
fill 549 177 297 551 177 297 minecraft:white_concrete
setblock 549 177 317 minecraft:white_concrete
fill 550 177 275 550 184 275 minecraft:brown_terracotta
fill 550 177 317 550 184 317 minecraft:brown_terracotta
fill 551 177 286 555 177 286 minecraft:red_concrete
fill 552 177 275 552 184 275 minecraft:brown_terracotta
fill 552 177 317 552 184 317 minecraft:brown_terracotta
setblock 553 177 275 minecraft:white_concrete
setblock 553 177 296 minecraft:red_concrete
setblock 553 177 317 minecraft:white_concrete
fill 554 177 275 554 184 275 minecraft:brown_terracotta
fill 554 177 317 554 184 317 minecraft:brown_terracotta
fill 556 177 275 556 184 275 minecraft:brown_terracotta
fill 556 177 293 556 177 297 minecraft:white_concrete
fill 556 177 317 556 184 317 minecraft:brown_terracotta
setblock 557 177 275 minecraft:white_concrete
setblock 557 177 317 minecraft:white_concrete
fill 558 177 275 558 184 275 minecraft:brown_terracotta
fill 558 177 317 558 184 317 minecraft:brown_terracotta
setblock 559 177 275 minecraft:white_concrete
fill 559 177 276 559 184 276 minecraft:brown_terracotta
fill 559 177 278 559 184 278 minecraft:brown_terracotta
setblock 559 177 279 minecraft:white_concrete
fill 559 177 280 559 184 280 minecraft:brown_terracotta
fill 559 177 282 559 184 282 minecraft:brown_terracotta
setblock 559 177 283 minecraft:white_concrete
fill 559 177 284 559 184 284 minecraft:brown_terracotta
fill 559 177 286 559 184 286 minecraft:brown_terracotta
setblock 559 177 287 minecraft:white_concrete
fill 559 177 288 559 184 288 minecraft:brown_terracotta
fill 559 177 290 559 184 290 minecraft:brown_terracotta
setblock 559 177 291 minecraft:white_concrete
fill 559 177 292 559 184 292 minecraft:brown_terracotta
fill 559 177 294 559 184 294 minecraft:brown_terracotta
setblock 559 177 295 minecraft:white_concrete
fill 559 177 296 559 184 296 minecraft:brown_terracotta
fill 559 177 298 559 184 298 minecraft:brown_terracotta
setblock 559 177 299 minecraft:white_concrete
fill 559 177 300 559 184 300 minecraft:brown_terracotta
fill 559 177 302 559 184 302 minecraft:brown_terracotta
setblock 559 177 303 minecraft:white_concrete
fill 559 177 304 559 184 304 minecraft:brown_terracotta
fill 559 177 306 559 184 306 minecraft:brown_terracotta
setblock 559 177 307 minecraft:white_concrete
fill 559 177 308 559 184 308 minecraft:brown_terracotta
fill 559 177 310 559 184 310 minecraft:brown_terracotta
setblock 559 177 311 minecraft:white_concrete
fill 559 177 312 559 184 312 minecraft:brown_terracotta
fill 559 177 314 559 184 314 minecraft:brown_terracotta
setblock 559 177 315 minecraft:white_concrete
fill 559 177 316 559 184 316 minecraft:brown_terracotta
fill 517 178 275 517 185 275 minecraft:brown_terracotta
fill 517 178 279 517 185 279 minecraft:brown_terracotta
fill 517 178 283 517 185 283 minecraft:brown_terracotta
fill 517 178 287 517 185 287 minecraft:brown_terracotta
fill 517 178 291 517 185 291 minecraft:brown_terracotta
fill 517 178 295 517 185 295 minecraft:brown_terracotta
fill 517 178 299 517 185 299 minecraft:brown_terracotta
fill 517 178 303 517 185 303 minecraft:brown_terracotta
fill 517 178 307 517 185 307 minecraft:brown_terracotta
fill 517 178 311 517 185 311 minecraft:brown_terracotta
fill 517 178 315 517 185 315 minecraft:brown_terracotta
fill 517 178 317 517 183 317 minecraft:brown_terracotta
fill 521 178 275 521 185 275 minecraft:brown_terracotta
fill 521 178 317 521 185 317 minecraft:brown_terracotta
setblock 524 178 296 minecraft:red_concrete
fill 525 178 275 525 185 275 minecraft:brown_terracotta
fill 525 178 317 525 185 317 minecraft:brown_terracotta
fill 526 178 295 528 178 295 minecraft:white_concrete
fill 526 178 297 528 178 297 minecraft:white_concrete
fill 528 178 296 529 180 296 minecraft:white_concrete
fill 529 178 275 529 185 275 minecraft:brown_terracotta
fill 529 178 317 529 185 317 minecraft:brown_terracotta
fill 530 178 308 530 179 308 minecraft:white_concrete
fill 533 178 275 533 185 275 minecraft:brown_terracotta
fill 533 178 317 533 185 317 minecraft:brown_terracotta
fill 537 178 275 537 185 275 minecraft:brown_terracotta
fill 537 178 317 537 185 317 minecraft:brown_terracotta
fill 541 178 275 541 185 275 minecraft:brown_terracotta
fill 541 178 317 541 185 317 minecraft:brown_terracotta
fill 545 178 275 545 185 275 minecraft:brown_terracotta
fill 545 178 317 545 185 317 minecraft:brown_terracotta
fill 546 178 296 547 180 296 minecraft:white_concrete
fill 547 178 295 549 178 295 minecraft:white_concrete
fill 547 178 297 549 178 297 minecraft:white_concrete
fill 549 178 275 549 185 275 minecraft:brown_terracotta
fill 549 178 317 549 185 317 minecraft:brown_terracotta
setblock 551 178 296 minecraft:red_concrete
fill 552 178 285 554 178 287 minecraft:red_concrete
fill 553 178 275 553 185 275 minecraft:brown_terracotta
fill 553 178 317 553 185 317 minecraft:brown_terracotta
fill 557 178 275 557 185 275 minecraft:brown_terracotta
fill 557 178 317 557 185 317 minecraft:brown_terracotta
fill 559 178 275 559 183 275 minecraft:brown_terracotta
fill 559 178 279 559 185 279 minecraft:brown_terracotta
fill 559 178 283 559 185 283 minecraft:brown_terracotta
fill 559 178 287 559 185 287 minecraft:brown_terracotta
fill 559 178 291 559 185 291 minecraft:brown_terracotta
fill 559 178 295 559 185 295 minecraft:brown_terracotta
fill 559 178 299 559 185 299 minecraft:brown_terracotta
fill 559 178 303 559 185 303 minecraft:brown_terracotta
fill 559 178 307 559 185 307 minecraft:brown_terracotta
fill 559 178 311 559 185 311 minecraft:brown_terracotta
fill 559 178 315 559 185 315 minecraft:brown_terracotta
fill 525 179 296 526 179 296 minecraft:red_concrete
fill 527 179 295 527 179 297 minecraft:white_concrete
fill 528 179 295 530 179 295 minecraft:white_concrete
fill 528 179 297 530 179 297 minecraft:white_concrete
fill 530 179 296 531 180 296 minecraft:white_concrete
fill 544 179 296 545 181 296 minecraft:white_concrete
fill 545 179 295 548 179 295 minecraft:white_concrete
fill 545 179 297 548 179 297 minecraft:white_concrete
setblock 550 179 296 minecraft:red_concrete
fill 519 180 285 519 185 287 minecraft:white_concrete
fill 519 180 297 519 185 299 minecraft:white_concrete
fill 519 180 309 519 185 311 minecraft:white_concrete
fill 520 180 293 520 181 294 minecraft:red_concrete
fill 525 180 315 527 185 315 minecraft:white_concrete
setblock 527 180 296 minecraft:red_concrete
fill 529 180 277 531 185 277 minecraft:white_concrete
fill 529 180 295 532 180 295 minecraft:white_concrete
fill 529 180 297 532 180 297 minecraft:white_concrete
fill 531 180 312 535 180 316 minecraft:orange_terracotta
fill 532 180 296 535 181 296 minecraft:white_concrete
fill 537 180 315 539 186 315 minecraft:white_concrete
fill 540 180 296 543 181 296 minecraft:white_concrete
fill 541 180 277 543 185 277 minecraft:white_concrete
fill 543 180 295 546 180 295 minecraft:white_concrete
fill 543 180 297 546 180 297 minecraft:white_concrete
setblock 548 180 296 minecraft:red_concrete
fill 549 180 315 551 185 315 minecraft:white_concrete
fill 553 180 277 555 185 277 minecraft:white_concrete
fill 557 180 285 557 185 287 minecraft:white_concrete
fill 557 180 297 557 185 299 minecraft:white_concrete
fill 557 180 309 557 185 311 minecraft:white_concrete
setblock 520 181 278 minecraft:light[level=15]
setblock 520 181 285 minecraft:light[level=12]
setblock 520 181 286 minecraft:light[level=15]
setblock 520 181 292 minecraft:light[level=12]
setblock 520 181 299 minecraft:light[level=12]
setblock 520 181 302 minecraft:light[level=15]
setblock 520 181 306 minecraft:light[level=12]
setblock 520 181 310 minecraft:light[level=15]
setblock 520 181 313 minecraft:light[level=12]
setblock 527 181 278 minecraft:light[level=12]
setblock 527 181 285 minecraft:light[level=12]
setblock 527 181 292 minecraft:light[level=12]
setblock 527 181 299 minecraft:light[level=12]
setblock 527 181 306 minecraft:light[level=12]
setblock 527 181 313 minecraft:light[level=12]
setblock 528 181 278 minecraft:light[level=15]
setblock 528 181 286 minecraft:light[level=15]
setblock 528 181 294 minecraft:light[level=15]
fill 528 181 296 530 181 296 minecraft:red_concrete
setblock 528 181 302 minecraft:light[level=15]
setblock 528 181 310 minecraft:light[level=15]
setblock 531 181 296 minecraft:white_concrete
fill 531 181 312 532 184 316 minecraft:orange_terracotta
fill 532 181 295 543 181 295 minecraft:white_concrete
fill 532 181 297 533 181 297 minecraft:white_concrete
fill 533 181 312 535 184 313 minecraft:orange_terracotta
fill 533 181 314 533 182 314 minecraft:ochre_froglight
fill 533 181 315 535 184 316 minecraft:orange_terracotta
setblock 534 181 278 minecraft:light[level=12]
setblock 534 181 285 minecraft:light[level=12]
setblock 534 181 292 minecraft:light[level=12]
setblock 534 181 299 minecraft:light[level=12]
setblock 534 181 306 minecraft:light[level=12]
fill 534 181 314 535 184 314 minecraft:orange_terracotta
setblock 536 181 278 minecraft:light[level=15]
setblock 536 181 286 minecraft:light[level=15]
setblock 536 181 294 minecraft:light[level=15]
fill 536 181 296 539 182 296 minecraft:white_concrete
setblock 536 181 302 minecraft:light[level=15]
setblock 536 181 310 minecraft:light[level=15]
fill 537 181 297 543 181 297 minecraft:white_concrete
fill 537 181 310 537 184 310 minecraft:iron_block
setblock 541 181 278 minecraft:light[level=12]
setblock 541 181 285 minecraft:light[level=12]
setblock 541 181 292 minecraft:light[level=12]
setblock 541 181 299 minecraft:light[level=12]
setblock 541 181 306 minecraft:light[level=12]
setblock 541 181 313 minecraft:light[level=12]
setblock 544 181 278 minecraft:light[level=15]
setblock 544 181 286 minecraft:light[level=15]
setblock 544 181 294 minecraft:light[level=15]
setblock 544 181 302 minecraft:light[level=15]
setblock 544 181 310 minecraft:light[level=15]
fill 546 181 296 547 181 296 minecraft:red_concrete
setblock 548 181 278 minecraft:light[level=12]
setblock 548 181 285 minecraft:light[level=12]
setblock 548 181 292 minecraft:light[level=12]
setblock 548 181 299 minecraft:light[level=12]
setblock 548 181 306 minecraft:light[level=12]
setblock 548 181 313 minecraft:light[level=12]
setblock 552 181 278 minecraft:light[level=15]
setblock 552 181 286 minecraft:light[level=15]
setblock 552 181 294 minecraft:light[level=15]
setblock 552 181 302 minecraft:light[level=15]
setblock 552 181 310 minecraft:light[level=15]
setblock 555 181 278 minecraft:light[level=12]
setblock 555 181 285 minecraft:light[level=12]
setblock 555 181 292 minecraft:light[level=12]
setblock 555 181 299 minecraft:light[level=12]
setblock 555 181 306 minecraft:light[level=12]
setblock 555 181 313 minecraft:light[level=12]
fill 519 182 279 519 182 281 minecraft:brown_terracotta
fill 520 182 278 522 182 278 minecraft:brown_terracotta
fill 520 182 282 522 182 282 minecraft:brown_terracotta
fill 523 182 279 523 182 281 minecraft:brown_terracotta
fill 530 182 296 532 182 296 minecraft:red_concrete
fill 533 182 296 535 182 296 minecraft:white_concrete
fill 536 182 295 539 182 295 minecraft:white_concrete
fill 537 182 297 539 182 297 minecraft:white_concrete
fill 540 182 296 542 182 296 minecraft:white_concrete
fill 543 182 296 545 182 296 minecraft:red_concrete
fill 533 183 296 542 183 296 minecraft:red_concrete
fill 533 183 314 533 184 314 minecraft:orange_terracotta
setblock 517 184 277 minecraft:white_concrete
setblock 517 184 281 minecraft:white_concrete
setblock 517 184 285 minecraft:white_concrete
setblock 517 184 289 minecraft:white_concrete
setblock 517 184 293 minecraft:white_concrete
setblock 517 184 297 minecraft:white_concrete
setblock 517 184 301 minecraft:white_concrete
setblock 517 184 305 minecraft:white_concrete
setblock 517 184 309 minecraft:white_concrete
setblock 517 184 313 minecraft:white_concrete
setblock 517 184 317 minecraft:white_concrete
setblock 519 184 275 minecraft:white_concrete
setblock 519 184 317 minecraft:white_concrete
setblock 523 184 275 minecraft:white_concrete
setblock 523 184 317 minecraft:white_concrete
setblock 527 184 275 minecraft:white_concrete
setblock 527 184 317 minecraft:white_concrete
setblock 531 184 275 minecraft:white_concrete
setblock 531 184 317 minecraft:white_concrete
setblock 535 184 275 minecraft:white_concrete
setblock 535 184 317 minecraft:white_concrete
setblock 539 184 275 minecraft:white_concrete
setblock 539 184 317 minecraft:white_concrete
setblock 543 184 275 minecraft:white_concrete
setblock 543 184 317 minecraft:white_concrete
setblock 547 184 275 minecraft:white_concrete
setblock 547 184 317 minecraft:white_concrete
setblock 551 184 275 minecraft:white_concrete
setblock 551 184 317 minecraft:white_concrete
setblock 555 184 275 minecraft:white_concrete
setblock 555 184 317 minecraft:white_concrete
setblock 559 184 275 minecraft:white_concrete
setblock 559 184 277 minecraft:white_concrete
setblock 559 184 281 minecraft:white_concrete
setblock 559 184 285 minecraft:white_concrete
setblock 559 184 289 minecraft:white_concrete
setblock 559 184 293 minecraft:white_concrete
setblock 559 184 297 minecraft:white_concrete
setblock 559 184 301 minecraft:white_concrete
setblock 559 184 305 minecraft:white_concrete
setblock 559 184 309 minecraft:white_concrete
setblock 559 184 313 minecraft:white_concrete
setblock 559 184 317 minecraft:white_concrete
setblock 517 185 276 minecraft:white_concrete
fill 517 185 277 517 192 277 minecraft:brown_terracotta
setblock 517 185 278 minecraft:white_concrete
setblock 517 185 280 minecraft:white_concrete
fill 517 185 281 518 185 281 minecraft:brown_terracotta
setblock 517 185 282 minecraft:white_concrete
setblock 517 185 284 minecraft:white_concrete
fill 517 185 285 517 192 285 minecraft:brown_terracotta
setblock 517 185 286 minecraft:white_concrete
setblock 517 185 288 minecraft:white_concrete
fill 517 185 289 517 192 289 minecraft:brown_terracotta
setblock 517 185 290 minecraft:white_concrete
setblock 517 185 292 minecraft:white_concrete
fill 517 185 293 518 185 293 minecraft:brown_terracotta
setblock 517 185 294 minecraft:white_concrete
setblock 517 185 296 minecraft:white_concrete
fill 517 185 297 517 192 297 minecraft:brown_terracotta
setblock 517 185 298 minecraft:white_concrete
setblock 517 185 300 minecraft:white_concrete
fill 517 185 301 517 192 301 minecraft:brown_terracotta
setblock 517 185 302 minecraft:white_concrete
setblock 517 185 304 minecraft:white_concrete
fill 517 185 305 518 185 305 minecraft:brown_terracotta
setblock 517 185 306 minecraft:white_concrete
setblock 517 185 308 minecraft:white_concrete
fill 517 185 309 517 192 309 minecraft:brown_terracotta
setblock 517 185 310 minecraft:white_concrete
setblock 517 185 312 minecraft:white_concrete
fill 517 185 313 517 192 313 minecraft:brown_terracotta
setblock 517 185 314 minecraft:white_concrete
setblock 517 185 316 minecraft:white_concrete
setblock 517 185 317 minecraft:brown_terracotta
setblock 518 185 275 minecraft:white_concrete
fill 518 185 279 518 185 280 minecraft:brown_terracotta
fill 518 185 282 518 185 284 minecraft:brown_terracotta
fill 518 185 291 518 185 292 minecraft:brown_terracotta
fill 518 185 294 518 185 296 minecraft:brown_terracotta
fill 518 185 303 518 185 304 minecraft:brown_terracotta
fill 518 185 306 518 185 308 minecraft:brown_terracotta
fill 518 185 315 518 185 316 minecraft:brown_terracotta
setblock 518 185 317 minecraft:white_concrete
fill 519 185 275 519 192 275 minecraft:brown_terracotta
fill 519 185 316 519 185 317 minecraft:brown_terracotta
setblock 520 185 275 minecraft:white_concrete
fill 520 185 316 522 185 316 minecraft:brown_terracotta
setblock 520 185 317 minecraft:white_concrete
setblock 522 185 275 minecraft:white_concrete
fill 522 185 276 527 185 276 minecraft:brown_terracotta
setblock 522 185 317 minecraft:white_concrete
fill 523 185 275 523 192 275 minecraft:brown_terracotta
fill 523 185 317 523 192 317 minecraft:brown_terracotta
setblock 524 185 275 minecraft:white_concrete
setblock 524 185 317 minecraft:white_concrete
setblock 526 185 275 minecraft:white_concrete
setblock 526 185 317 minecraft:white_concrete
setblock 527 185 275 minecraft:brown_terracotta
fill 527 185 317 527 192 317 minecraft:brown_terracotta
setblock 528 185 275 minecraft:white_concrete
setblock 528 185 317 minecraft:white_concrete
fill 529 185 316 530 185 316 minecraft:brown_terracotta
setblock 530 185 275 minecraft:white_concrete
setblock 530 185 317 minecraft:white_concrete
fill 531 185 275 531 192 275 minecraft:brown_terracotta
fill 531 185 312 535 185 316 minecraft:white_concrete
setblock 531 185 317 minecraft:brown_terracotta
setblock 532 185 275 minecraft:white_concrete
fill 532 185 310 542 185 311 minecraft:brown_terracotta
setblock 532 185 317 minecraft:white_concrete
setblock 534 185 275 minecraft:white_concrete
fill 534 185 276 539 185 276 minecraft:brown_terracotta
setblock 534 185 317 minecraft:white_concrete
fill 535 185 275 535 192 275 minecraft:brown_terracotta
fill 535 185 317 535 192 317 minecraft:brown_terracotta
setblock 536 185 275 minecraft:white_concrete
fill 536 185 312 536 185 315 minecraft:brown_terracotta
setblock 536 185 317 minecraft:white_concrete
fill 537 185 312 542 185 314 minecraft:brown_terracotta
setblock 538 185 275 minecraft:white_concrete
setblock 538 185 317 minecraft:white_concrete
setblock 539 185 275 minecraft:brown_terracotta
fill 539 185 317 539 192 317 minecraft:brown_terracotta
setblock 540 185 275 minecraft:white_concrete
fill 540 185 315 542 185 315 minecraft:brown_terracotta
setblock 540 185 317 minecraft:white_concrete
fill 541 185 316 546 185 316 minecraft:brown_terracotta
setblock 542 185 275 minecraft:white_concrete
setblock 542 185 317 minecraft:white_concrete
fill 543 185 275 543 192 275 minecraft:brown_terracotta
setblock 543 185 317 minecraft:brown_terracotta
setblock 544 185 275 minecraft:white_concrete
setblock 544 185 317 minecraft:white_concrete
setblock 546 185 275 minecraft:white_concrete
fill 546 185 276 551 185 276 minecraft:brown_terracotta
setblock 546 185 317 minecraft:white_concrete
fill 547 185 275 547 192 275 minecraft:brown_terracotta
fill 547 185 300 547 186 302 minecraft:white_concrete
fill 547 185 317 547 192 317 minecraft:brown_terracotta
setblock 548 185 275 minecraft:white_concrete
fill 548 185 301 548 186 301 minecraft:white_concrete
setblock 548 185 317 minecraft:white_concrete
setblock 550 185 275 minecraft:white_concrete
setblock 550 185 317 minecraft:white_concrete
setblock 551 185 275 minecraft:brown_terracotta
fill 551 185 317 551 192 317 minecraft:brown_terracotta
setblock 552 185 275 minecraft:white_concrete
setblock 552 185 317 minecraft:white_concrete
fill 553 185 316 558 185 316 minecraft:brown_terracotta
setblock 554 185 275 minecraft:white_concrete
setblock 554 185 317 minecraft:white_concrete
fill 555 185 275 555 192 275 minecraft:brown_terracotta
setblock 555 185 317 minecraft:brown_terracotta
setblock 556 185 275 minecraft:white_concrete
setblock 556 185 317 minecraft:white_concrete
setblock 558 185 275 minecraft:white_concrete
fill 558 185 276 558 185 281 minecraft:brown_terracotta
fill 558 185 288 558 185 293 minecraft:brown_terracotta
fill 558 185 300 558 185 305 minecraft:brown_terracotta
fill 558 185 312 558 185 315 minecraft:brown_terracotta
setblock 558 185 317 minecraft:white_concrete
setblock 559 185 275 minecraft:brown_terracotta
setblock 559 185 276 minecraft:white_concrete
setblock 559 185 277 minecraft:brown_terracotta
setblock 559 185 278 minecraft:white_concrete
setblock 559 185 280 minecraft:white_concrete
fill 559 185 281 559 192 281 minecraft:brown_terracotta
setblock 559 185 282 minecraft:white_concrete
setblock 559 185 284 minecraft:white_concrete
fill 559 185 285 559 192 285 minecraft:brown_terracotta
setblock 559 185 286 minecraft:white_concrete
setblock 559 185 288 minecraft:white_concrete
setblock 559 185 289 minecraft:brown_terracotta
setblock 559 185 290 minecraft:white_concrete
setblock 559 185 292 minecraft:white_concrete
fill 559 185 293 559 192 293 minecraft:brown_terracotta
setblock 559 185 294 minecraft:white_concrete
setblock 559 185 296 minecraft:white_concrete
fill 559 185 297 559 192 297 minecraft:brown_terracotta
setblock 559 185 298 minecraft:white_concrete
setblock 559 185 300 minecraft:white_concrete
setblock 559 185 301 minecraft:brown_terracotta
setblock 559 185 302 minecraft:white_concrete
setblock 559 185 304 minecraft:white_concrete
fill 559 185 305 559 192 305 minecraft:brown_terracotta
setblock 559 185 306 minecraft:white_concrete
setblock 559 185 308 minecraft:white_concrete
fill 559 185 309 559 192 309 minecraft:brown_terracotta
setblock 559 185 310 minecraft:white_concrete
setblock 559 185 312 minecraft:white_concrete
setblock 559 185 313 minecraft:brown_terracotta
setblock 559 185 314 minecraft:white_concrete
setblock 559 185 316 minecraft:white_concrete
fill 559 185 317 559 192 317 minecraft:brown_terracotta
setblock 517 186 275 minecraft:white_concrete
fill 517 186 276 517 193 276 minecraft:brown_terracotta
fill 517 186 278 517 193 278 minecraft:brown_terracotta
setblock 517 186 279 minecraft:white_concrete
fill 517 186 280 517 193 280 minecraft:brown_terracotta
fill 517 186 281 517 191 284 minecraft:shroomlight
fill 517 186 286 517 193 286 minecraft:brown_terracotta
setblock 517 186 287 minecraft:white_concrete
fill 517 186 288 517 193 288 minecraft:brown_terracotta
fill 517 186 290 517 193 290 minecraft:brown_terracotta
setblock 517 186 291 minecraft:white_concrete
fill 517 186 292 517 193 292 minecraft:brown_terracotta
fill 517 186 293 517 191 296 minecraft:shroomlight
fill 517 186 298 517 193 298 minecraft:brown_terracotta
setblock 517 186 299 minecraft:white_concrete
fill 517 186 300 517 193 300 minecraft:brown_terracotta
fill 517 186 302 517 193 302 minecraft:brown_terracotta
setblock 517 186 303 minecraft:white_concrete
fill 517 186 304 517 193 304 minecraft:brown_terracotta
fill 517 186 305 517 191 308 minecraft:shroomlight
fill 517 186 310 517 193 310 minecraft:brown_terracotta
setblock 517 186 311 minecraft:white_concrete
fill 517 186 312 517 193 312 minecraft:brown_terracotta
fill 517 186 314 517 193 314 minecraft:brown_terracotta
setblock 517 186 315 minecraft:white_concrete
fill 517 186 316 517 193 316 minecraft:brown_terracotta
fill 517 186 317 520 191 317 minecraft:shroomlight
fill 518 186 275 518 193 275 minecraft:brown_terracotta
fill 520 186 275 520 193 275 minecraft:brown_terracotta
setblock 521 186 275 minecraft:white_concrete
setblock 521 186 317 minecraft:white_concrete
fill 522 186 275 522 193 275 minecraft:brown_terracotta
fill 522 186 317 522 193 317 minecraft:brown_terracotta
fill 524 186 275 527 191 275 minecraft:shroomlight
fill 524 186 317 524 193 317 minecraft:brown_terracotta
setblock 525 186 317 minecraft:white_concrete
fill 526 186 317 526 193 317 minecraft:brown_terracotta
fill 528 186 275 528 193 275 minecraft:brown_terracotta
fill 528 186 317 528 193 317 minecraft:brown_terracotta
setblock 529 186 275 minecraft:white_concrete
fill 529 186 317 532 191 317 minecraft:shroomlight
fill 530 186 275 530 193 275 minecraft:brown_terracotta
fill 532 186 275 532 193 275 minecraft:brown_terracotta
fill 532 186 310 534 186 316 minecraft:white_concrete
setblock 533 186 275 minecraft:white_concrete
setblock 533 186 317 minecraft:white_concrete
fill 534 186 275 534 193 275 minecraft:brown_terracotta
fill 534 186 317 534 193 317 minecraft:brown_terracotta
fill 535 186 310 536 186 315 minecraft:white_concrete
fill 536 186 275 539 191 275 minecraft:shroomlight
fill 536 186 317 536 193 317 minecraft:brown_terracotta
fill 537 186 310 542 186 314 minecraft:white_concrete
setblock 537 186 317 minecraft:white_concrete
fill 538 186 317 538 193 317 minecraft:brown_terracotta
fill 540 186 275 540 193 275 minecraft:brown_terracotta
fill 540 186 315 542 186 315 minecraft:white_concrete
fill 540 186 317 540 193 317 minecraft:brown_terracotta
setblock 541 186 275 minecraft:white_concrete
fill 541 186 317 544 191 317 minecraft:shroomlight
fill 542 186 275 542 193 275 minecraft:brown_terracotta
fill 544 186 275 544 193 275 minecraft:brown_terracotta
setblock 545 186 275 minecraft:white_concrete
setblock 545 186 317 minecraft:white_concrete
fill 546 186 275 546 193 275 minecraft:brown_terracotta
fill 546 186 317 546 193 317 minecraft:brown_terracotta
fill 548 186 275 551 191 275 minecraft:shroomlight
fill 548 186 317 548 193 317 minecraft:brown_terracotta
setblock 549 186 317 minecraft:white_concrete
fill 550 186 317 550 193 317 minecraft:brown_terracotta
fill 552 186 275 552 193 275 minecraft:brown_terracotta
fill 552 186 317 552 193 317 minecraft:brown_terracotta
setblock 553 186 275 minecraft:white_concrete
fill 553 186 317 556 191 317 minecraft:shroomlight
fill 554 186 275 554 193 275 minecraft:brown_terracotta
fill 556 186 275 556 193 275 minecraft:brown_terracotta
setblock 557 186 275 minecraft:white_concrete
setblock 557 186 317 minecraft:white_concrete
fill 558 186 275 558 193 275 minecraft:brown_terracotta
fill 558 186 317 558 193 317 minecraft:brown_terracotta
setblock 559 186 275 minecraft:white_concrete
fill 559 186 276 559 191 279 minecraft:shroomlight
fill 559 186 280 559 193 280 minecraft:brown_terracotta
fill 559 186 282 559 193 282 minecraft:brown_terracotta
setblock 559 186 283 minecraft:white_concrete
fill 559 186 284 559 193 284 minecraft:brown_terracotta
fill 559 186 286 559 193 286 minecraft:brown_terracotta
setblock 559 186 287 minecraft:white_concrete
fill 559 186 288 559 191 291 minecraft:shroomlight
fill 559 186 292 559 193 292 minecraft:brown_terracotta
fill 559 186 294 559 193 294 minecraft:brown_terracotta
setblock 559 186 295 minecraft:white_concrete
fill 559 186 296 559 193 296 minecraft:brown_terracotta
fill 559 186 298 559 193 298 minecraft:brown_terracotta
setblock 559 186 299 minecraft:white_concrete
fill 559 186 300 559 191 303 minecraft:shroomlight
fill 559 186 304 559 193 304 minecraft:brown_terracotta
fill 559 186 306 559 193 306 minecraft:brown_terracotta
setblock 559 186 307 minecraft:white_concrete
fill 559 186 308 559 193 308 minecraft:brown_terracotta
fill 559 186 310 559 193 310 minecraft:brown_terracotta
setblock 559 186 311 minecraft:white_concrete
fill 559 186 312 559 191 315 minecraft:shroomlight
fill 559 186 316 559 193 316 minecraft:brown_terracotta
fill 517 187 275 517 194 275 minecraft:brown_terracotta
fill 517 187 279 517 194 279 minecraft:brown_terracotta
fill 517 187 287 517 194 287 minecraft:brown_terracotta
fill 517 187 291 517 194 291 minecraft:brown_terracotta
fill 517 187 299 517 194 299 minecraft:brown_terracotta
fill 517 187 303 517 194 303 minecraft:brown_terracotta
fill 517 187 311 517 194 311 minecraft:brown_terracotta
fill 517 187 315 517 194 315 minecraft:brown_terracotta
setblock 520 187 278 minecraft:light[level=12]
setblock 520 187 285 minecraft:light[level=12]
setblock 520 187 292 minecraft:light[level=12]
setblock 520 187 299 minecraft:light[level=12]
setblock 520 187 306 minecraft:light[level=12]
setblock 520 187 313 minecraft:light[level=12]
fill 521 187 275 521 194 275 minecraft:brown_terracotta
fill 521 187 317 521 194 317 minecraft:brown_terracotta
fill 525 187 317 525 194 317 minecraft:brown_terracotta
setblock 527 187 278 minecraft:light[level=12]
setblock 527 187 285 minecraft:light[level=12]
setblock 527 187 292 minecraft:light[level=12]
setblock 527 187 299 minecraft:light[level=12]
setblock 527 187 306 minecraft:light[level=12]
setblock 527 187 313 minecraft:light[level=12]
fill 529 187 275 529 194 275 minecraft:brown_terracotta
fill 532 187 310 542 187 310 minecraft:red_concrete
fill 533 187 275 533 194 275 minecraft:brown_terracotta
fill 533 187 312 533 187 316 minecraft:white_concrete
fill 533 187 317 533 194 317 minecraft:brown_terracotta
setblock 534 187 278 minecraft:light[level=12]
setblock 534 187 285 minecraft:light[level=12]
setblock 534 187 292 minecraft:light[level=12]
setblock 534 187 299 minecraft:light[level=12]
setblock 534 187 306 minecraft:light[level=12]
setblock 534 187 313 minecraft:light[level=12]
fill 536 187 316 538 190 316 minecraft:shroomlight
fill 537 187 317 537 194 317 minecraft:brown_terracotta
fill 541 187 275 541 194 275 minecraft:brown_terracotta
setblock 541 187 278 minecraft:light[level=12]
setblock 541 187 285 minecraft:light[level=12]
setblock 541 187 292 minecraft:light[level=12]
setblock 541 187 299 minecraft:light[level=12]
setblock 541 187 306 minecraft:light[level=12]
setblock 541 187 313 minecraft:light[level=12]
fill 545 187 275 545 194 275 minecraft:brown_terracotta
fill 545 187 317 545 194 317 minecraft:brown_terracotta
setblock 548 187 278 minecraft:light[level=12]
setblock 548 187 285 minecraft:light[level=12]
setblock 548 187 292 minecraft:light[level=12]
setblock 548 187 299 minecraft:light[level=12]
setblock 548 187 306 minecraft:light[level=12]
setblock 548 187 313 minecraft:light[level=12]
fill 549 187 317 549 194 317 minecraft:brown_terracotta
fill 553 187 275 553 194 275 minecraft:brown_terracotta
setblock 555 187 278 minecraft:light[level=12]
setblock 555 187 285 minecraft:light[level=12]
setblock 555 187 292 minecraft:light[level=12]
setblock 555 187 299 minecraft:light[level=12]
setblock 555 187 306 minecraft:light[level=12]
setblock 555 187 313 minecraft:light[level=12]
fill 557 187 275 557 194 275 minecraft:brown_terracotta
fill 557 187 317 557 194 317 minecraft:brown_terracotta
fill 559 187 275 559 192 275 minecraft:brown_terracotta
fill 559 187 283 559 194 283 minecraft:brown_terracotta
fill 559 187 287 559 194 287 minecraft:brown_terracotta
fill 559 187 295 559 194 295 minecraft:brown_terracotta
fill 559 187 299 559 194 299 minecraft:brown_terracotta
fill 559 187 307 559 194 307 minecraft:brown_terracotta
fill 559 187 311 559 194 311 minecraft:brown_terracotta
setblock 532 188 310 minecraft:white_concrete
setblock 537 188 310 minecraft:white_concrete
setblock 542 188 310 minecraft:white_concrete
setblock 520 189 278 minecraft:light[level=15]
setblock 520 189 286 minecraft:light[level=15]
setblock 520 189 294 minecraft:light[level=15]
setblock 520 189 302 minecraft:light[level=15]
setblock 520 189 310 minecraft:light[level=15]
setblock 528 189 278 minecraft:light[level=15]
setblock 528 189 286 minecraft:light[level=15]
setblock 528 189 294 minecraft:light[level=15]
setblock 528 189 302 minecraft:light[level=15]
setblock 528 189 310 minecraft:light[level=15]
setblock 536 189 278 minecraft:light[level=15]
setblock 536 189 286 minecraft:light[level=15]
setblock 536 189 294 minecraft:light[level=15]
setblock 536 189 302 minecraft:light[level=15]
setblock 536 189 310 minecraft:light[level=15]
setblock 544 189 278 minecraft:light[level=15]
setblock 544 189 286 minecraft:light[level=15]
setblock 544 189 294 minecraft:light[level=15]
setblock 544 189 302 minecraft:light[level=15]
setblock 544 189 310 minecraft:light[level=15]
setblock 552 189 278 minecraft:light[level=15]
setblock 552 189 286 minecraft:light[level=15]
setblock 552 189 294 minecraft:light[level=15]
setblock 552 189 302 minecraft:light[level=15]
setblock 552 189 310 minecraft:light[level=15]
fill 519 190 279 519 190 281 minecraft:brown_terracotta
fill 520 190 278 522 190 278 minecraft:brown_terracotta
fill 520 190 282 522 190 282 minecraft:brown_terracotta
fill 523 190 279 523 190 281 minecraft:brown_terracotta
fill 526 191 300 527 192 300 minecraft:red_concrete
fill 536 191 316 538 213 316 minecraft:white_concrete
setblock 517 192 281 minecraft:brown_terracotta
fill 517 192 282 517 192 283 minecraft:shroomlight
fill 517 192 284 517 193 284 minecraft:brown_terracotta
setblock 517 192 293 minecraft:brown_terracotta
fill 517 192 294 517 192 295 minecraft:shroomlight
fill 517 192 296 517 193 296 minecraft:brown_terracotta
setblock 517 192 305 minecraft:brown_terracotta
fill 517 192 306 517 192 307 minecraft:shroomlight
fill 517 192 308 517 193 308 minecraft:brown_terracotta
setblock 517 192 317 minecraft:brown_terracotta
fill 518 192 317 519 192 317 minecraft:shroomlight
fill 520 192 317 520 193 317 minecraft:brown_terracotta
fill 524 192 275 524 193 275 minecraft:brown_terracotta
fill 525 192 275 526 192 275 minecraft:shroomlight
setblock 527 192 275 minecraft:brown_terracotta
fill 529 192 317 529 194 317 minecraft:brown_terracotta
fill 530 192 317 531 192 317 minecraft:shroomlight
fill 532 192 317 532 193 317 minecraft:brown_terracotta
fill 536 192 275 536 193 275 minecraft:brown_terracotta
fill 537 192 275 538 192 275 minecraft:shroomlight
setblock 539 192 275 minecraft:brown_terracotta
fill 541 192 317 541 194 317 minecraft:brown_terracotta
fill 542 192 317 543 192 317 minecraft:shroomlight
fill 544 192 317 544 193 317 minecraft:brown_terracotta
fill 548 192 275 548 193 275 minecraft:brown_terracotta
fill 549 192 275 550 192 275 minecraft:shroomlight
setblock 551 192 275 minecraft:brown_terracotta
fill 553 192 317 553 194 317 minecraft:brown_terracotta
fill 554 192 317 555 192 317 minecraft:shroomlight
fill 556 192 317 556 193 317 minecraft:brown_terracotta
fill 559 192 276 559 193 276 minecraft:brown_terracotta
fill 559 192 277 559 192 278 minecraft:shroomlight
fill 559 192 279 559 194 279 minecraft:brown_terracotta
fill 559 192 288 559 193 288 minecraft:brown_terracotta
fill 559 192 289 559 192 290 minecraft:shroomlight
fill 559 192 291 559 194 291 minecraft:brown_terracotta
fill 559 192 300 559 193 300 minecraft:brown_terracotta
fill 559 192 301 559 192 302 minecraft:shroomlight
fill 559 192 303 559 194 303 minecraft:brown_terracotta
fill 559 192 312 559 193 312 minecraft:brown_terracotta
fill 559 192 313 559 192 314 minecraft:shroomlight
fill 559 192 315 559 194 315 minecraft:brown_terracotta
setblock 517 193 277 minecraft:white_concrete
setblock 517 193 281 minecraft:white_concrete
fill 517 193 282 517 193 283 minecraft:brown_terracotta
setblock 517 193 285 minecraft:white_concrete
setblock 517 193 289 minecraft:white_concrete
setblock 517 193 293 minecraft:white_concrete
fill 517 193 294 517 193 295 minecraft:brown_terracotta
setblock 517 193 297 minecraft:white_concrete
setblock 517 193 301 minecraft:white_concrete
setblock 517 193 305 minecraft:white_concrete
fill 517 193 306 517 193 307 minecraft:brown_terracotta
setblock 517 193 309 minecraft:white_concrete
setblock 517 193 313 minecraft:white_concrete
setblock 517 193 317 minecraft:white_concrete
setblock 518 193 317 minecraft:brown_terracotta
setblock 519 193 275 minecraft:white_concrete
setblock 519 193 317 minecraft:white_concrete
setblock 520 193 278 minecraft:light[level=12]
setblock 520 193 285 minecraft:light[level=12]
setblock 520 193 292 minecraft:light[level=12]
setblock 520 193 299 minecraft:light[level=12]
setblock 520 193 306 minecraft:light[level=12]
setblock 520 193 313 minecraft:light[level=12]
setblock 523 193 275 minecraft:white_concrete
setblock 523 193 317 minecraft:white_concrete
fill 525 193 275 526 193 275 minecraft:brown_terracotta
setblock 527 193 275 minecraft:white_concrete
setblock 527 193 278 minecraft:light[level=12]
setblock 527 193 285 minecraft:light[level=12]
setblock 527 193 292 minecraft:light[level=12]
setblock 527 193 299 minecraft:light[level=12]
setblock 527 193 306 minecraft:light[level=12]
setblock 527 193 313 minecraft:light[level=12]
setblock 527 193 317 minecraft:white_concrete
setblock 530 193 317 minecraft:brown_terracotta
setblock 531 193 275 minecraft:white_concrete
setblock 531 193 317 minecraft:white_concrete
setblock 534 193 278 minecraft:light[level=12]
setblock 534 193 285 minecraft:light[level=12]
setblock 534 193 292 minecraft:light[level=12]
setblock 534 193 299 minecraft:light[level=12]
setblock 534 193 306 minecraft:light[level=12]
setblock 534 193 313 minecraft:light[level=12]
setblock 535 193 275 minecraft:white_concrete
setblock 535 193 317 minecraft:white_concrete
fill 537 193 275 538 193 275 minecraft:brown_terracotta
setblock 539 193 275 minecraft:white_concrete
setblock 539 193 317 minecraft:white_concrete
setblock 541 193 278 minecraft:light[level=12]
setblock 541 193 285 minecraft:light[level=12]
setblock 541 193 292 minecraft:light[level=12]
setblock 541 193 299 minecraft:light[level=12]
setblock 541 193 306 minecraft:light[level=12]
setblock 541 193 313 minecraft:light[level=12]
setblock 542 193 317 minecraft:brown_terracotta
setblock 543 193 275 minecraft:white_concrete
setblock 543 193 317 minecraft:white_concrete
setblock 547 193 275 minecraft:white_concrete
setblock 547 193 317 minecraft:white_concrete
setblock 548 193 278 minecraft:light[level=12]
setblock 548 193 285 minecraft:light[level=12]
setblock 548 193 292 minecraft:light[level=12]
setblock 548 193 299 minecraft:light[level=12]
setblock 548 193 306 minecraft:light[level=12]
setblock 548 193 313 minecraft:light[level=12]
fill 549 193 275 550 193 275 minecraft:brown_terracotta
setblock 551 193 275 minecraft:white_concrete
setblock 551 193 317 minecraft:white_concrete
setblock 554 193 317 minecraft:brown_terracotta
setblock 555 193 275 minecraft:white_concrete
setblock 555 193 278 minecraft:light[level=12]
setblock 555 193 285 minecraft:light[level=12]
setblock 555 193 292 minecraft:light[level=12]
setblock 555 193 299 minecraft:light[level=12]
setblock 555 193 306 minecraft:light[level=12]
setblock 555 193 313 minecraft:light[level=12]
setblock 555 193 317 minecraft:white_concrete
setblock 559 193 275 minecraft:white_concrete
setblock 559 193 277 minecraft:white_concrete
setblock 559 193 278 minecraft:brown_terracotta
setblock 559 193 281 minecraft:white_concrete
setblock 559 193 285 minecraft:white_concrete
setblock 559 193 289 minecraft:white_concrete
setblock 559 193 290 minecraft:brown_terracotta
setblock 559 193 293 minecraft:white_concrete
setblock 559 193 297 minecraft:white_concrete
setblock 559 193 301 minecraft:white_concrete
setblock 559 193 302 minecraft:brown_terracotta
setblock 559 193 305 minecraft:white_concrete
setblock 559 193 309 minecraft:white_concrete
setblock 559 193 313 minecraft:white_concrete
setblock 559 193 314 minecraft:brown_terracotta
setblock 559 193 317 minecraft:white_concrete
setblock 517 194 276 minecraft:white_concrete
fill 517 194 277 517 201 277 minecraft:brown_terracotta
setblock 517 194 278 minecraft:white_concrete
setblock 517 194 280 minecraft:white_concrete
fill 517 194 281 517 201 281 minecraft:brown_terracotta
setblock 517 194 282 minecraft:white_concrete
setblock 517 194 283 minecraft:brown_terracotta
setblock 517 194 284 minecraft:white_concrete
fill 517 194 285 517 201 285 minecraft:brown_terracotta
setblock 517 194 286 minecraft:white_concrete
setblock 517 194 288 minecraft:white_concrete
fill 517 194 289 517 201 289 minecraft:brown_terracotta
setblock 517 194 290 minecraft:white_concrete
setblock 517 194 292 minecraft:white_concrete
fill 517 194 293 517 201 293 minecraft:brown_terracotta
setblock 517 194 294 minecraft:white_concrete
setblock 517 194 295 minecraft:brown_terracotta
setblock 517 194 296 minecraft:white_concrete
fill 517 194 297 517 201 297 minecraft:brown_terracotta
setblock 517 194 298 minecraft:white_concrete
setblock 517 194 300 minecraft:white_concrete
fill 517 194 301 517 201 301 minecraft:brown_terracotta
setblock 517 194 302 minecraft:white_concrete
setblock 517 194 304 minecraft:white_concrete
fill 517 194 305 517 201 305 minecraft:brown_terracotta
setblock 517 194 306 minecraft:white_concrete
setblock 517 194 307 minecraft:brown_terracotta
setblock 517 194 308 minecraft:white_concrete
fill 517 194 309 517 201 309 minecraft:brown_terracotta
setblock 517 194 310 minecraft:white_concrete
setblock 517 194 312 minecraft:white_concrete
fill 517 194 313 517 201 313 minecraft:brown_terracotta
setblock 517 194 314 minecraft:white_concrete
setblock 517 194 316 minecraft:white_concrete
setblock 517 194 317 minecraft:brown_terracotta
setblock 518 194 275 minecraft:white_concrete
setblock 518 194 317 minecraft:white_concrete
fill 519 194 275 519 201 275 minecraft:brown_terracotta
fill 519 194 317 519 201 317 minecraft:brown_terracotta
setblock 520 194 275 minecraft:white_concrete
setblock 520 194 317 minecraft:white_concrete
setblock 522 194 275 minecraft:white_concrete
setblock 522 194 317 minecraft:white_concrete
fill 523 194 275 523 201 275 minecraft:brown_terracotta
fill 523 194 317 523 201 317 minecraft:brown_terracotta
setblock 524 194 275 minecraft:white_concrete
setblock 524 194 317 minecraft:white_concrete
setblock 525 194 275 minecraft:brown_terracotta
setblock 526 194 275 minecraft:white_concrete
setblock 526 194 317 minecraft:white_concrete
fill 527 194 275 527 201 275 minecraft:brown_terracotta
fill 527 194 317 527 201 317 minecraft:brown_terracotta
setblock 528 194 275 minecraft:white_concrete
setblock 528 194 317 minecraft:white_concrete
setblock 530 194 275 minecraft:white_concrete
setblock 530 194 317 minecraft:white_concrete
fill 531 194 275 531 201 275 minecraft:brown_terracotta
fill 531 194 317 531 201 317 minecraft:brown_terracotta
setblock 532 194 275 minecraft:white_concrete
setblock 532 194 317 minecraft:white_concrete
setblock 534 194 275 minecraft:white_concrete
setblock 534 194 317 minecraft:white_concrete
fill 535 194 275 535 201 275 minecraft:brown_terracotta
fill 535 194 317 535 201 317 minecraft:brown_terracotta
setblock 536 194 275 minecraft:white_concrete
setblock 536 194 317 minecraft:white_concrete
setblock 537 194 275 minecraft:brown_terracotta
setblock 538 194 275 minecraft:white_concrete
setblock 538 194 317 minecraft:white_concrete
fill 539 194 275 539 201 275 minecraft:brown_terracotta
fill 539 194 317 539 201 317 minecraft:brown_terracotta
setblock 540 194 275 minecraft:white_concrete
setblock 540 194 317 minecraft:white_concrete
setblock 542 194 275 minecraft:white_concrete
setblock 542 194 317 minecraft:white_concrete
fill 543 194 275 543 201 275 minecraft:brown_terracotta
fill 543 194 317 543 201 317 minecraft:brown_terracotta
setblock 544 194 275 minecraft:white_concrete
setblock 544 194 317 minecraft:white_concrete
setblock 546 194 275 minecraft:white_concrete
setblock 546 194 317 minecraft:white_concrete
fill 547 194 275 547 201 275 minecraft:brown_terracotta
fill 547 194 317 547 201 317 minecraft:brown_terracotta
setblock 548 194 275 minecraft:white_concrete
setblock 548 194 317 minecraft:white_concrete
setblock 549 194 275 minecraft:brown_terracotta
setblock 550 194 275 minecraft:white_concrete
setblock 550 194 317 minecraft:white_concrete
fill 551 194 275 551 201 275 minecraft:brown_terracotta
fill 551 194 317 551 201 317 minecraft:brown_terracotta
setblock 552 194 275 minecraft:white_concrete
setblock 552 194 317 minecraft:white_concrete
setblock 554 194 275 minecraft:white_concrete
setblock 554 194 317 minecraft:white_concrete
fill 555 194 275 555 201 275 minecraft:brown_terracotta
fill 555 194 317 555 201 317 minecraft:brown_terracotta
setblock 556 194 275 minecraft:white_concrete
setblock 556 194 317 minecraft:white_concrete
setblock 558 194 275 minecraft:white_concrete
setblock 558 194 317 minecraft:white_concrete
setblock 559 194 275 minecraft:brown_terracotta
setblock 559 194 276 minecraft:white_concrete
fill 559 194 277 559 201 277 minecraft:brown_terracotta
setblock 559 194 278 minecraft:white_concrete
setblock 559 194 280 minecraft:white_concrete
fill 559 194 281 559 201 281 minecraft:brown_terracotta
setblock 559 194 282 minecraft:white_concrete
setblock 559 194 284 minecraft:white_concrete
fill 559 194 285 559 201 285 minecraft:brown_terracotta
setblock 559 194 286 minecraft:white_concrete
setblock 559 194 288 minecraft:white_concrete
fill 559 194 289 559 201 289 minecraft:brown_terracotta
setblock 559 194 290 minecraft:white_concrete
setblock 559 194 292 minecraft:white_concrete
fill 559 194 293 559 201 293 minecraft:brown_terracotta
setblock 559 194 294 minecraft:white_concrete
setblock 559 194 296 minecraft:white_concrete
fill 559 194 297 559 201 297 minecraft:brown_terracotta
setblock 559 194 298 minecraft:white_concrete
setblock 559 194 300 minecraft:white_concrete
fill 559 194 301 559 201 301 minecraft:brown_terracotta
setblock 559 194 302 minecraft:white_concrete
setblock 559 194 304 minecraft:white_concrete
fill 559 194 305 559 201 305 minecraft:brown_terracotta
setblock 559 194 306 minecraft:white_concrete
setblock 559 194 308 minecraft:white_concrete
fill 559 194 309 559 201 309 minecraft:brown_terracotta
setblock 559 194 310 minecraft:white_concrete
setblock 559 194 312 minecraft:white_concrete
fill 559 194 313 559 201 313 minecraft:brown_terracotta
setblock 559 194 314 minecraft:white_concrete
setblock 559 194 316 minecraft:white_concrete
fill 559 194 317 559 201 317 minecraft:brown_terracotta
setblock 517 195 275 minecraft:white_concrete
fill 517 195 276 517 202 276 minecraft:brown_terracotta
fill 517 195 278 517 202 278 minecraft:brown_terracotta
setblock 517 195 279 minecraft:white_concrete
fill 517 195 280 517 202 280 minecraft:brown_terracotta
fill 517 195 282 517 202 282 minecraft:brown_terracotta
setblock 517 195 283 minecraft:white_concrete
fill 517 195 284 517 202 284 minecraft:brown_terracotta
fill 517 195 286 517 202 286 minecraft:brown_terracotta
setblock 517 195 287 minecraft:white_concrete
fill 517 195 288 517 202 288 minecraft:brown_terracotta
fill 517 195 290 517 202 290 minecraft:brown_terracotta
setblock 517 195 291 minecraft:white_concrete
fill 517 195 292 517 202 292 minecraft:brown_terracotta
fill 517 195 294 517 202 294 minecraft:brown_terracotta
setblock 517 195 295 minecraft:white_concrete
fill 517 195 296 517 202 296 minecraft:brown_terracotta
fill 517 195 298 517 202 298 minecraft:brown_terracotta
setblock 517 195 299 minecraft:white_concrete
fill 517 195 300 517 202 300 minecraft:brown_terracotta
fill 517 195 302 517 202 302 minecraft:brown_terracotta
setblock 517 195 303 minecraft:white_concrete
fill 517 195 304 517 202 304 minecraft:brown_terracotta
fill 517 195 306 517 202 306 minecraft:brown_terracotta
setblock 517 195 307 minecraft:white_concrete
fill 517 195 308 517 202 308 minecraft:brown_terracotta
fill 517 195 310 517 202 310 minecraft:brown_terracotta
setblock 517 195 311 minecraft:white_concrete
fill 517 195 312 517 202 312 minecraft:brown_terracotta
fill 517 195 314 517 202 314 minecraft:brown_terracotta
setblock 517 195 315 minecraft:white_concrete
fill 517 195 316 517 202 316 minecraft:brown_terracotta
setblock 517 195 317 minecraft:white_concrete
fill 518 195 275 518 202 275 minecraft:brown_terracotta
fill 518 195 317 518 202 317 minecraft:brown_terracotta
fill 520 195 275 520 202 275 minecraft:brown_terracotta
fill 520 195 317 520 202 317 minecraft:brown_terracotta
setblock 521 195 275 minecraft:white_concrete
setblock 521 195 317 minecraft:white_concrete
fill 522 195 275 522 202 275 minecraft:brown_terracotta
fill 522 195 317 522 202 317 minecraft:brown_terracotta
fill 524 195 275 524 202 275 minecraft:brown_terracotta
fill 524 195 317 524 202 317 minecraft:brown_terracotta
setblock 525 195 275 minecraft:white_concrete
setblock 525 195 317 minecraft:white_concrete
fill 526 195 275 526 202 275 minecraft:brown_terracotta
fill 526 195 317 526 202 317 minecraft:brown_terracotta
fill 528 195 275 528 202 275 minecraft:brown_terracotta
fill 528 195 317 528 202 317 minecraft:brown_terracotta
setblock 529 195 275 minecraft:white_concrete
setblock 529 195 317 minecraft:white_concrete
fill 530 195 275 530 202 275 minecraft:brown_terracotta
fill 530 195 317 530 202 317 minecraft:brown_terracotta
fill 532 195 275 532 202 275 minecraft:brown_terracotta
fill 532 195 317 532 202 317 minecraft:brown_terracotta
setblock 533 195 275 minecraft:white_concrete
setblock 533 195 317 minecraft:white_concrete
fill 534 195 275 534 202 275 minecraft:brown_terracotta
fill 534 195 317 534 202 317 minecraft:brown_terracotta
fill 536 195 275 536 202 275 minecraft:brown_terracotta
fill 536 195 317 536 202 317 minecraft:brown_terracotta
setblock 537 195 275 minecraft:white_concrete
setblock 537 195 317 minecraft:white_concrete
fill 538 195 275 538 202 275 minecraft:brown_terracotta
fill 538 195 317 538 202 317 minecraft:brown_terracotta
fill 540 195 275 540 202 275 minecraft:brown_terracotta
fill 540 195 317 540 202 317 minecraft:brown_terracotta
setblock 541 195 275 minecraft:white_concrete
setblock 541 195 317 minecraft:white_concrete
fill 542 195 275 542 202 275 minecraft:brown_terracotta
fill 542 195 317 542 202 317 minecraft:brown_terracotta
fill 544 195 275 544 202 275 minecraft:brown_terracotta
fill 544 195 317 544 202 317 minecraft:brown_terracotta
setblock 545 195 275 minecraft:white_concrete
setblock 545 195 317 minecraft:white_concrete
fill 546 195 275 546 202 275 minecraft:brown_terracotta
fill 546 195 317 546 202 317 minecraft:brown_terracotta
fill 548 195 275 548 202 275 minecraft:brown_terracotta
fill 548 195 317 548 202 317 minecraft:brown_terracotta
setblock 549 195 275 minecraft:white_concrete
setblock 549 195 317 minecraft:white_concrete
fill 550 195 275 550 202 275 minecraft:brown_terracotta
fill 550 195 317 550 202 317 minecraft:brown_terracotta
fill 552 195 275 552 202 275 minecraft:brown_terracotta
fill 552 195 317 552 202 317 minecraft:brown_terracotta
setblock 553 195 275 minecraft:white_concrete
setblock 553 195 317 minecraft:white_concrete
fill 554 195 275 554 202 275 minecraft:brown_terracotta
fill 554 195 317 554 202 317 minecraft:brown_terracotta
fill 556 195 275 556 202 275 minecraft:brown_terracotta
fill 556 195 317 556 202 317 minecraft:brown_terracotta
setblock 557 195 275 minecraft:white_concrete
setblock 557 195 317 minecraft:white_concrete
fill 558 195 275 558 202 275 minecraft:brown_terracotta
fill 558 195 317 558 202 317 minecraft:brown_terracotta
setblock 559 195 275 minecraft:white_concrete
fill 559 195 276 559 202 276 minecraft:brown_terracotta
fill 559 195 278 559 202 278 minecraft:brown_terracotta
setblock 559 195 279 minecraft:white_concrete
fill 559 195 280 559 202 280 minecraft:brown_terracotta
fill 559 195 282 559 202 282 minecraft:brown_terracotta
setblock 559 195 283 minecraft:white_concrete
fill 559 195 284 559 202 284 minecraft:brown_terracotta
fill 559 195 286 559 202 286 minecraft:brown_terracotta
setblock 559 195 287 minecraft:white_concrete
fill 559 195 288 559 202 288 minecraft:brown_terracotta
fill 559 195 290 559 202 290 minecraft:brown_terracotta
setblock 559 195 291 minecraft:white_concrete
fill 559 195 292 559 202 292 minecraft:brown_terracotta
fill 559 195 294 559 202 294 minecraft:brown_terracotta
setblock 559 195 295 minecraft:white_concrete
fill 559 195 296 559 202 296 minecraft:brown_terracotta
fill 559 195 298 559 202 298 minecraft:brown_terracotta
setblock 559 195 299 minecraft:white_concrete
fill 559 195 300 559 202 300 minecraft:brown_terracotta
fill 559 195 302 559 202 302 minecraft:brown_terracotta
setblock 559 195 303 minecraft:white_concrete
fill 559 195 304 559 202 304 minecraft:brown_terracotta
fill 559 195 306 559 202 306 minecraft:brown_terracotta
setblock 559 195 307 minecraft:white_concrete
fill 559 195 308 559 202 308 minecraft:brown_terracotta
fill 559 195 310 559 202 310 minecraft:brown_terracotta
setblock 559 195 311 minecraft:white_concrete
fill 559 195 312 559 202 312 minecraft:brown_terracotta
fill 559 195 314 559 202 314 minecraft:brown_terracotta
setblock 559 195 315 minecraft:white_concrete
fill 559 195 316 559 202 316 minecraft:brown_terracotta
fill 517 196 275 517 203 275 minecraft:brown_terracotta
fill 517 196 279 517 203 279 minecraft:brown_terracotta
fill 517 196 283 517 203 283 minecraft:brown_terracotta
fill 517 196 287 517 203 287 minecraft:brown_terracotta
fill 517 196 291 517 203 291 minecraft:brown_terracotta
fill 517 196 295 517 203 295 minecraft:brown_terracotta
fill 517 196 299 517 203 299 minecraft:brown_terracotta
fill 517 196 303 517 203 303 minecraft:brown_terracotta
fill 517 196 307 517 203 307 minecraft:brown_terracotta
fill 517 196 311 517 203 311 minecraft:brown_terracotta
fill 517 196 315 517 203 315 minecraft:brown_terracotta
fill 517 196 317 517 201 317 minecraft:brown_terracotta
fill 521 196 275 521 203 275 minecraft:brown_terracotta
fill 521 196 317 521 203 317 minecraft:brown_terracotta
fill 525 196 275 525 203 275 minecraft:brown_terracotta
fill 525 196 317 525 203 317 minecraft:brown_terracotta
fill 529 196 275 529 203 275 minecraft:brown_terracotta
fill 529 196 317 529 203 317 minecraft:brown_terracotta
fill 533 196 275 533 203 275 minecraft:brown_terracotta
fill 533 196 317 533 203 317 minecraft:brown_terracotta
fill 537 196 275 537 203 275 minecraft:brown_terracotta
fill 537 196 317 537 203 317 minecraft:brown_terracotta
fill 541 196 275 541 203 275 minecraft:brown_terracotta
fill 541 196 317 541 203 317 minecraft:brown_terracotta
fill 545 196 275 545 203 275 minecraft:brown_terracotta
fill 545 196 317 545 203 317 minecraft:brown_terracotta
fill 549 196 275 549 203 275 minecraft:brown_terracotta
fill 549 196 317 549 203 317 minecraft:brown_terracotta
fill 553 196 275 553 203 275 minecraft:brown_terracotta
fill 553 196 317 553 203 317 minecraft:brown_terracotta
fill 557 196 275 557 203 275 minecraft:brown_terracotta
fill 557 196 317 557 203 317 minecraft:brown_terracotta
fill 559 196 275 559 201 275 minecraft:brown_terracotta
fill 559 196 279 559 203 279 minecraft:brown_terracotta
fill 559 196 283 559 203 283 minecraft:brown_terracotta
fill 559 196 287 559 203 287 minecraft:brown_terracotta
fill 559 196 291 559 203 291 minecraft:brown_terracotta
fill 559 196 295 559 203 295 minecraft:brown_terracotta
fill 559 196 299 559 203 299 minecraft:brown_terracotta
fill 559 196 303 559 203 303 minecraft:brown_terracotta
fill 559 196 307 559 203 307 minecraft:brown_terracotta
fill 559 196 311 559 203 311 minecraft:brown_terracotta
fill 559 196 315 559 203 315 minecraft:brown_terracotta
setblock 520 197 278 minecraft:light[level=15]
setblock 520 197 286 minecraft:light[level=15]
setblock 520 197 294 minecraft:light[level=15]
setblock 520 197 302 minecraft:light[level=15]
setblock 520 197 310 minecraft:light[level=15]
setblock 528 197 278 minecraft:light[level=15]
setblock 528 197 286 minecraft:light[level=15]
setblock 528 197 294 minecraft:light[level=15]
setblock 528 197 302 minecraft:light[level=15]
setblock 528 197 310 minecraft:light[level=15]
setblock 536 197 278 minecraft:light[level=15]
setblock 536 197 286 minecraft:light[level=15]
setblock 536 197 294 minecraft:light[level=15]
setblock 536 197 302 minecraft:light[level=15]
setblock 536 197 310 minecraft:light[level=15]
setblock 544 197 278 minecraft:light[level=15]
setblock 544 197 286 minecraft:light[level=15]
setblock 544 197 294 minecraft:light[level=15]
setblock 544 197 302 minecraft:light[level=15]
setblock 544 197 310 minecraft:light[level=15]
fill 550 197 297 550 198 297 minecraft:shroomlight
setblock 552 197 278 minecraft:light[level=15]
setblock 552 197 286 minecraft:light[level=15]
setblock 552 197 294 minecraft:light[level=15]
setblock 552 197 302 minecraft:light[level=15]
setblock 552 197 310 minecraft:light[level=15]
fill 519 198 279 519 198 281 minecraft:brown_terracotta
fill 520 198 278 522 198 278 minecraft:brown_terracotta
fill 520 198 282 522 198 282 minecraft:brown_terracotta
fill 523 198 279 523 198 281 minecraft:brown_terracotta
setblock 520 199 278 minecraft:light[level=12]
setblock 520 199 285 minecraft:light[level=12]
setblock 520 199 292 minecraft:light[level=12]
setblock 520 199 299 minecraft:light[level=12]
setblock 520 199 306 minecraft:light[level=12]
setblock 520 199 313 minecraft:light[level=12]
setblock 527 199 278 minecraft:light[level=12]
setblock 527 199 285 minecraft:light[level=12]
setblock 527 199 292 minecraft:light[level=12]
setblock 527 199 299 minecraft:light[level=12]
setblock 527 199 306 minecraft:light[level=12]
setblock 527 199 313 minecraft:light[level=12]
setblock 534 199 278 minecraft:light[level=12]
setblock 534 199 285 minecraft:light[level=12]
setblock 534 199 292 minecraft:light[level=12]
setblock 534 199 299 minecraft:light[level=12]
setblock 534 199 306 minecraft:light[level=12]
setblock 534 199 313 minecraft:light[level=12]
setblock 541 199 278 minecraft:light[level=12]
setblock 541 199 285 minecraft:light[level=12]
setblock 541 199 292 minecraft:light[level=12]
setblock 541 199 299 minecraft:light[level=12]
setblock 541 199 306 minecraft:light[level=12]
setblock 541 199 313 minecraft:light[level=12]
setblock 548 199 278 minecraft:light[level=12]
setblock 548 199 285 minecraft:light[level=12]
setblock 548 199 292 minecraft:light[level=12]
setblock 548 199 299 minecraft:light[level=12]
setblock 548 199 306 minecraft:light[level=12]
setblock 548 199 313 minecraft:light[level=12]
fill 550 199 297 550 205 298 minecraft:brown_terracotta
setblock 555 199 278 minecraft:light[level=12]
setblock 555 199 285 minecraft:light[level=12]
setblock 555 199 292 minecraft:light[level=12]
setblock 555 199 299 minecraft:light[level=12]
setblock 555 199 306 minecraft:light[level=12]
setblock 555 199 313 minecraft:light[level=12]
fill 519 200 285 519 205 287 minecraft:white_concrete
fill 519 200 297 519 205 299 minecraft:white_concrete
fill 519 200 309 519 205 311 minecraft:white_concrete
fill 525 200 315 527 205 315 minecraft:white_concrete
fill 529 200 277 531 205 277 minecraft:white_concrete
fill 537 200 315 539 205 315 minecraft:white_concrete
fill 541 200 277 543 205 277 minecraft:white_concrete
fill 549 200 315 551 205 315 minecraft:white_concrete
fill 551 200 297 551 205 298 minecraft:brown_terracotta
fill 553 200 277 555 205 277 minecraft:white_concrete
fill 557 200 285 557 205 287 minecraft:white_concrete
fill 557 200 297 557 205 299 minecraft:white_concrete
fill 557 200 309 557 205 311 minecraft:white_concrete
fill 549 201 297 549 205 298 minecraft:brown_terracotta
setblock 517 202 277 minecraft:white_concrete
setblock 517 202 281 minecraft:white_concrete
setblock 517 202 285 minecraft:white_concrete
setblock 517 202 289 minecraft:white_concrete
setblock 517 202 293 minecraft:white_concrete
setblock 517 202 297 minecraft:white_concrete
setblock 517 202 301 minecraft:white_concrete
setblock 517 202 305 minecraft:white_concrete
setblock 517 202 309 minecraft:white_concrete
setblock 517 202 313 minecraft:white_concrete
setblock 517 202 317 minecraft:white_concrete
setblock 519 202 275 minecraft:white_concrete
setblock 519 202 317 minecraft:white_concrete
setblock 523 202 275 minecraft:white_concrete
setblock 523 202 317 minecraft:white_concrete
setblock 527 202 275 minecraft:white_concrete
setblock 527 202 317 minecraft:white_concrete
setblock 531 202 275 minecraft:white_concrete
setblock 531 202 317 minecraft:white_concrete
setblock 535 202 275 minecraft:white_concrete
setblock 535 202 317 minecraft:white_concrete
setblock 539 202 275 minecraft:white_concrete
setblock 539 202 317 minecraft:white_concrete
setblock 543 202 275 minecraft:white_concrete
setblock 543 202 317 minecraft:white_concrete
setblock 547 202 275 minecraft:white_concrete
setblock 547 202 317 minecraft:white_concrete
fill 550 202 296 551 205 296 minecraft:brown_terracotta
fill 550 202 299 551 205 299 minecraft:brown_terracotta
setblock 551 202 275 minecraft:white_concrete
setblock 551 202 317 minecraft:white_concrete
fill 552 202 297 552 205 298 minecraft:brown_terracotta
setblock 555 202 275 minecraft:white_concrete
setblock 555 202 317 minecraft:white_concrete
setblock 559 202 275 minecraft:white_concrete
setblock 559 202 277 minecraft:white_concrete
setblock 559 202 281 minecraft:white_concrete
setblock 559 202 285 minecraft:white_concrete
setblock 559 202 289 minecraft:white_concrete
setblock 559 202 293 minecraft:white_concrete
setblock 559 202 297 minecraft:white_concrete
setblock 559 202 301 minecraft:white_concrete
setblock 559 202 305 minecraft:white_concrete
setblock 559 202 309 minecraft:white_concrete
setblock 559 202 313 minecraft:white_concrete
setblock 559 202 317 minecraft:white_concrete
setblock 517 203 276 minecraft:white_concrete
fill 517 203 277 517 210 277 minecraft:brown_terracotta
setblock 517 203 278 minecraft:white_concrete
setblock 517 203 280 minecraft:white_concrete
fill 517 203 281 517 205 281 minecraft:brown_terracotta
setblock 517 203 282 minecraft:white_concrete
setblock 517 203 284 minecraft:white_concrete
fill 517 203 285 517 210 285 minecraft:brown_terracotta
setblock 517 203 286 minecraft:white_concrete
setblock 517 203 288 minecraft:white_concrete
fill 517 203 289 517 210 289 minecraft:brown_terracotta
setblock 517 203 290 minecraft:white_concrete
setblock 517 203 292 minecraft:white_concrete
fill 517 203 293 517 205 293 minecraft:brown_terracotta
setblock 517 203 294 minecraft:white_concrete
setblock 517 203 296 minecraft:white_concrete
fill 517 203 297 517 210 297 minecraft:brown_terracotta
setblock 517 203 298 minecraft:white_concrete
setblock 517 203 300 minecraft:white_concrete
fill 517 203 301 517 210 301 minecraft:brown_terracotta
setblock 517 203 302 minecraft:white_concrete
setblock 517 203 304 minecraft:white_concrete
fill 517 203 305 517 205 305 minecraft:brown_terracotta
setblock 517 203 306 minecraft:white_concrete
setblock 517 203 308 minecraft:white_concrete
fill 517 203 309 517 210 309 minecraft:brown_terracotta
setblock 517 203 310 minecraft:white_concrete
setblock 517 203 312 minecraft:white_concrete
fill 517 203 313 517 210 313 minecraft:brown_terracotta
setblock 517 203 314 minecraft:white_concrete
setblock 517 203 316 minecraft:white_concrete
setblock 517 203 317 minecraft:brown_terracotta
setblock 518 203 275 minecraft:white_concrete
setblock 518 203 317 minecraft:white_concrete
fill 519 203 275 519 210 275 minecraft:brown_terracotta
fill 519 203 317 519 205 317 minecraft:brown_terracotta
setblock 520 203 275 minecraft:white_concrete
setblock 520 203 317 minecraft:white_concrete
setblock 522 203 275 minecraft:white_concrete
setblock 522 203 317 minecraft:white_concrete
fill 523 203 275 523 210 275 minecraft:brown_terracotta
fill 523 203 317 523 210 317 minecraft:brown_terracotta
setblock 524 203 275 minecraft:white_concrete
setblock 524 203 317 minecraft:white_concrete
setblock 526 203 275 minecraft:white_concrete
setblock 526 203 317 minecraft:white_concrete
fill 527 203 275 527 205 275 minecraft:brown_terracotta
fill 527 203 317 527 210 317 minecraft:brown_terracotta
setblock 528 203 275 minecraft:white_concrete
setblock 528 203 317 minecraft:white_concrete
setblock 530 203 275 minecraft:white_concrete
setblock 530 203 317 minecraft:white_concrete
fill 531 203 275 531 210 275 minecraft:brown_terracotta
fill 531 203 317 531 205 317 minecraft:brown_terracotta
setblock 532 203 275 minecraft:white_concrete
setblock 532 203 317 minecraft:white_concrete
setblock 534 203 275 minecraft:white_concrete
setblock 534 203 317 minecraft:white_concrete
fill 535 203 275 535 210 275 minecraft:brown_terracotta
fill 535 203 317 535 210 317 minecraft:brown_terracotta
setblock 536 203 275 minecraft:white_concrete
setblock 536 203 317 minecraft:white_concrete
setblock 538 203 275 minecraft:white_concrete
setblock 538 203 317 minecraft:white_concrete
fill 539 203 275 539 205 275 minecraft:brown_terracotta
fill 539 203 317 539 210 317 minecraft:brown_terracotta
setblock 540 203 275 minecraft:white_concrete
setblock 540 203 317 minecraft:white_concrete
setblock 542 203 275 minecraft:white_concrete
setblock 542 203 317 minecraft:white_concrete
fill 543 203 275 543 210 275 minecraft:brown_terracotta
fill 543 203 317 543 205 317 minecraft:brown_terracotta
setblock 544 203 275 minecraft:white_concrete
setblock 544 203 317 minecraft:white_concrete
setblock 546 203 275 minecraft:white_concrete
setblock 546 203 317 minecraft:white_concrete
fill 547 203 275 547 210 275 minecraft:brown_terracotta
fill 547 203 317 547 210 317 minecraft:brown_terracotta
setblock 548 203 275 minecraft:white_concrete
fill 548 203 297 548 205 298 minecraft:brown_terracotta
setblock 548 203 317 minecraft:white_concrete
fill 549 203 296 549 205 296 minecraft:brown_terracotta
fill 549 203 299 549 205 299 minecraft:brown_terracotta
setblock 550 203 275 minecraft:white_concrete
setblock 550 203 317 minecraft:white_concrete
fill 551 203 275 551 205 275 minecraft:brown_terracotta
fill 551 203 317 551 210 317 minecraft:brown_terracotta
setblock 552 203 275 minecraft:white_concrete
fill 552 203 296 552 205 296 minecraft:brown_terracotta
fill 552 203 299 552 205 299 minecraft:brown_terracotta
setblock 552 203 317 minecraft:white_concrete
setblock 554 203 275 minecraft:white_concrete
setblock 554 203 317 minecraft:white_concrete
fill 555 203 275 555 210 275 minecraft:brown_terracotta
fill 555 203 317 555 205 317 minecraft:brown_terracotta
setblock 556 203 275 minecraft:white_concrete
setblock 556 203 317 minecraft:white_concrete
setblock 558 203 275 minecraft:white_concrete
setblock 558 203 317 minecraft:white_concrete
setblock 559 203 275 minecraft:brown_terracotta
setblock 559 203 276 minecraft:white_concrete
fill 559 203 277 559 205 277 minecraft:brown_terracotta
setblock 559 203 278 minecraft:white_concrete
setblock 559 203 280 minecraft:white_concrete
fill 559 203 281 559 210 281 minecraft:brown_terracotta
setblock 559 203 282 minecraft:white_concrete
setblock 559 203 284 minecraft:white_concrete
fill 559 203 285 559 210 285 minecraft:brown_terracotta
setblock 559 203 286 minecraft:white_concrete
setblock 559 203 288 minecraft:white_concrete
fill 559 203 289 559 205 289 minecraft:brown_terracotta
setblock 559 203 290 minecraft:white_concrete
setblock 559 203 292 minecraft:white_concrete
fill 559 203 293 559 210 293 minecraft:brown_terracotta
setblock 559 203 294 minecraft:white_concrete
setblock 559 203 296 minecraft:white_concrete
fill 559 203 297 559 210 297 minecraft:brown_terracotta
setblock 559 203 298 minecraft:white_concrete
setblock 559 203 300 minecraft:white_concrete
fill 559 203 301 559 205 301 minecraft:brown_terracotta
setblock 559 203 302 minecraft:white_concrete
setblock 559 203 304 minecraft:white_concrete
fill 559 203 305 559 210 305 minecraft:brown_terracotta
setblock 559 203 306 minecraft:white_concrete
setblock 559 203 308 minecraft:white_concrete
fill 559 203 309 559 210 309 minecraft:brown_terracotta
setblock 559 203 310 minecraft:white_concrete
setblock 559 203 312 minecraft:white_concrete
fill 559 203 313 559 205 313 minecraft:brown_terracotta
setblock 559 203 314 minecraft:white_concrete
setblock 559 203 316 minecraft:white_concrete
fill 559 203 317 559 210 317 minecraft:brown_terracotta
setblock 517 204 275 minecraft:white_concrete
fill 517 204 276 517 211 276 minecraft:brown_terracotta
fill 517 204 278 517 211 278 minecraft:brown_terracotta
setblock 517 204 279 minecraft:white_concrete
fill 517 204 280 517 211 280 minecraft:brown_terracotta
fill 517 204 282 517 205 282 minecraft:brown_terracotta
setblock 517 204 283 minecraft:white_concrete
fill 517 204 284 517 205 284 minecraft:brown_terracotta
fill 517 204 286 517 211 286 minecraft:brown_terracotta
setblock 517 204 287 minecraft:white_concrete
fill 517 204 288 517 211 288 minecraft:brown_terracotta
fill 517 204 290 517 211 290 minecraft:brown_terracotta
setblock 517 204 291 minecraft:white_concrete
fill 517 204 292 517 211 292 minecraft:brown_terracotta
fill 517 204 294 517 205 294 minecraft:brown_terracotta
setblock 517 204 295 minecraft:white_concrete
fill 517 204 296 517 205 296 minecraft:brown_terracotta
fill 517 204 298 517 211 298 minecraft:brown_terracotta
setblock 517 204 299 minecraft:white_concrete
fill 517 204 300 517 211 300 minecraft:brown_terracotta
fill 517 204 302 517 211 302 minecraft:brown_terracotta
setblock 517 204 303 minecraft:white_concrete
fill 517 204 304 517 211 304 minecraft:brown_terracotta
fill 517 204 306 517 205 306 minecraft:brown_terracotta
setblock 517 204 307 minecraft:white_concrete
fill 517 204 308 517 205 308 minecraft:brown_terracotta
fill 517 204 310 517 211 310 minecraft:brown_terracotta
setblock 517 204 311 minecraft:white_concrete
fill 517 204 312 517 211 312 minecraft:brown_terracotta
fill 517 204 314 517 211 314 minecraft:brown_terracotta
setblock 517 204 315 minecraft:white_concrete
fill 517 204 316 517 211 316 minecraft:brown_terracotta
setblock 517 204 317 minecraft:white_concrete
fill 518 204 275 518 211 275 minecraft:brown_terracotta
fill 518 204 317 518 205 317 minecraft:brown_terracotta
fill 520 204 275 520 211 275 minecraft:brown_terracotta
fill 520 204 317 520 205 317 minecraft:brown_terracotta
setblock 521 204 275 minecraft:white_concrete
setblock 521 204 317 minecraft:white_concrete
fill 522 204 275 522 211 275 minecraft:brown_terracotta
fill 522 204 317 522 211 317 minecraft:brown_terracotta
fill 524 204 275 524 205 275 minecraft:brown_terracotta
fill 524 204 317 524 211 317 minecraft:brown_terracotta
setblock 525 204 275 minecraft:white_concrete
setblock 525 204 317 minecraft:white_concrete
fill 526 204 275 526 205 275 minecraft:brown_terracotta
fill 526 204 317 526 211 317 minecraft:brown_terracotta
fill 528 204 275 528 211 275 minecraft:brown_terracotta
fill 528 204 317 528 211 317 minecraft:brown_terracotta
setblock 529 204 275 minecraft:white_concrete
setblock 529 204 317 minecraft:white_concrete
fill 530 204 275 530 211 275 minecraft:brown_terracotta
fill 530 204 317 530 205 317 minecraft:brown_terracotta
fill 531 204 285 533 205 285 minecraft:white_concrete
fill 532 204 275 532 211 275 minecraft:brown_terracotta
fill 532 204 286 532 205 286 minecraft:white_concrete
fill 532 204 317 532 205 317 minecraft:brown_terracotta
setblock 533 204 275 minecraft:white_concrete
setblock 533 204 317 minecraft:white_concrete
fill 534 204 275 534 211 275 minecraft:brown_terracotta
fill 534 204 317 534 211 317 minecraft:brown_terracotta
fill 536 204 275 536 205 275 minecraft:brown_terracotta
fill 536 204 317 536 211 317 minecraft:brown_terracotta
setblock 537 204 275 minecraft:white_concrete
setblock 537 204 317 minecraft:white_concrete
fill 538 204 275 538 205 275 minecraft:brown_terracotta
fill 538 204 317 538 211 317 minecraft:brown_terracotta
fill 540 204 275 540 211 275 minecraft:brown_terracotta
fill 540 204 317 540 211 317 minecraft:brown_terracotta
setblock 541 204 275 minecraft:white_concrete
setblock 541 204 317 minecraft:white_concrete
fill 542 204 275 542 211 275 minecraft:brown_terracotta
fill 542 204 317 542 205 317 minecraft:brown_terracotta
fill 544 204 275 544 211 275 minecraft:brown_terracotta
fill 544 204 317 544 205 317 minecraft:brown_terracotta
setblock 545 204 275 minecraft:white_concrete
setblock 545 204 317 minecraft:white_concrete
fill 546 204 275 546 211 275 minecraft:brown_terracotta
fill 546 204 317 546 211 317 minecraft:brown_terracotta
fill 548 204 275 548 205 275 minecraft:brown_terracotta
fill 548 204 296 548 205 296 minecraft:brown_terracotta
fill 548 204 299 548 205 299 minecraft:brown_terracotta
fill 548 204 317 548 211 317 minecraft:brown_terracotta
setblock 549 204 275 minecraft:white_concrete
fill 549 204 295 551 205 295 minecraft:brown_terracotta
fill 549 204 300 551 205 300 minecraft:brown_terracotta
setblock 549 204 317 minecraft:white_concrete
fill 550 204 275 550 205 275 minecraft:brown_terracotta
fill 550 204 317 550 211 317 minecraft:brown_terracotta
fill 552 204 275 552 211 275 minecraft:brown_terracotta
fill 552 204 317 552 211 317 minecraft:brown_terracotta
setblock 553 204 275 minecraft:white_concrete
fill 553 204 297 553 205 298 minecraft:brown_terracotta
setblock 553 204 317 minecraft:white_concrete
fill 554 204 275 554 211 275 minecraft:brown_terracotta
fill 554 204 317 554 205 317 minecraft:brown_terracotta
fill 556 204 275 556 211 275 minecraft:brown_terracotta
fill 556 204 317 556 205 317 minecraft:brown_terracotta
setblock 557 204 275 minecraft:white_concrete
setblock 557 204 317 minecraft:white_concrete
fill 558 204 275 558 211 275 minecraft:brown_terracotta
fill 558 204 317 558 211 317 minecraft:brown_terracotta
setblock 559 204 275 minecraft:white_concrete
fill 559 204 276 559 205 276 minecraft:brown_terracotta
fill 559 204 278 559 205 278 minecraft:brown_terracotta
setblock 559 204 279 minecraft:white_concrete
fill 559 204 280 559 211 280 minecraft:brown_terracotta
fill 559 204 282 559 211 282 minecraft:brown_terracotta
setblock 559 204 283 minecraft:white_concrete
fill 559 204 284 559 211 284 minecraft:brown_terracotta
fill 559 204 286 559 211 286 minecraft:brown_terracotta
setblock 559 204 287 minecraft:white_concrete
fill 559 204 288 559 205 288 minecraft:brown_terracotta
fill 559 204 290 559 205 290 minecraft:brown_terracotta
setblock 559 204 291 minecraft:white_concrete
fill 559 204 292 559 211 292 minecraft:brown_terracotta
fill 559 204 294 559 211 294 minecraft:brown_terracotta
setblock 559 204 295 minecraft:white_concrete
fill 559 204 296 559 211 296 minecraft:brown_terracotta
fill 559 204 298 559 211 298 minecraft:brown_terracotta
setblock 559 204 299 minecraft:white_concrete
fill 559 204 300 559 205 300 minecraft:brown_terracotta
fill 559 204 302 559 205 302 minecraft:brown_terracotta
setblock 559 204 303 minecraft:white_concrete
fill 559 204 304 559 211 304 minecraft:brown_terracotta
fill 559 204 306 559 211 306 minecraft:brown_terracotta
setblock 559 204 307 minecraft:white_concrete
fill 559 204 308 559 211 308 minecraft:brown_terracotta
fill 559 204 310 559 211 310 minecraft:brown_terracotta
setblock 559 204 311 minecraft:white_concrete
fill 559 204 312 559 205 312 minecraft:brown_terracotta
fill 559 204 314 559 205 314 minecraft:brown_terracotta
setblock 559 204 315 minecraft:white_concrete
fill 559 204 316 559 211 316 minecraft:brown_terracotta
fill 517 205 275 517 212 275 minecraft:brown_terracotta
fill 517 205 279 518 205 279 minecraft:brown_terracotta
fill 517 205 283 518 205 283 minecraft:brown_terracotta
fill 517 205 287 517 212 287 minecraft:brown_terracotta
fill 517 205 291 518 205 291 minecraft:brown_terracotta
fill 517 205 295 518 205 295 minecraft:brown_terracotta
fill 517 205 299 517 212 299 minecraft:brown_terracotta
fill 517 205 303 518 205 303 minecraft:brown_terracotta
fill 517 205 307 518 205 307 minecraft:brown_terracotta
fill 517 205 311 517 212 311 minecraft:brown_terracotta
fill 517 205 315 518 205 315 minecraft:brown_terracotta
setblock 517 205 317 minecraft:brown_terracotta
fill 518 205 280 518 205 282 minecraft:brown_terracotta
setblock 518 205 284 minecraft:brown_terracotta
fill 518 205 292 518 205 294 minecraft:brown_terracotta
setblock 518 205 296 minecraft:brown_terracotta
fill 518 205 304 518 205 306 minecraft:brown_terracotta
setblock 518 205 308 minecraft:brown_terracotta
fill 518 205 316 522 205 316 minecraft:brown_terracotta
setblock 520 205 278 minecraft:light[level=15]
setblock 520 205 285 minecraft:light[level=12]
setblock 520 205 286 minecraft:light[level=15]
setblock 520 205 292 minecraft:light[level=12]
setblock 520 205 294 minecraft:light[level=15]
setblock 520 205 299 minecraft:light[level=12]
setblock 520 205 302 minecraft:light[level=15]
setblock 520 205 306 minecraft:light[level=12]
setblock 520 205 310 minecraft:light[level=15]
setblock 520 205 313 minecraft:light[level=12]
fill 521 205 275 521 212 275 minecraft:brown_terracotta
fill 521 205 317 521 212 317 minecraft:brown_terracotta
fill 522 205 276 527 205 276 minecraft:brown_terracotta
setblock 525 205 275 minecraft:brown_terracotta
fill 525 205 317 525 212 317 minecraft:brown_terracotta
setblock 527 205 278 minecraft:light[level=12]
setblock 527 205 285 minecraft:light[level=12]
setblock 527 205 292 minecraft:light[level=12]
setblock 527 205 299 minecraft:light[level=12]
setblock 527 205 306 minecraft:light[level=12]
setblock 527 205 313 minecraft:light[level=12]
setblock 528 205 278 minecraft:light[level=15]
setblock 528 205 286 minecraft:light[level=15]
setblock 528 205 294 minecraft:light[level=15]
setblock 528 205 302 minecraft:light[level=15]
setblock 528 205 310 minecraft:light[level=15]
fill 529 205 275 529 212 275 minecraft:brown_terracotta
fill 529 205 316 529 205 317 minecraft:brown_terracotta
fill 530 205 316 534 205 316 minecraft:brown_terracotta
fill 533 205 275 533 212 275 minecraft:brown_terracotta
fill 533 205 317 533 212 317 minecraft:brown_terracotta
fill 534 205 276 539 205 276 minecraft:brown_terracotta
setblock 534 205 278 minecraft:light[level=12]
setblock 534 205 285 minecraft:light[level=12]
setblock 534 205 292 minecraft:light[level=12]
setblock 534 205 299 minecraft:light[level=12]
setblock 534 205 306 minecraft:light[level=12]
setblock 534 205 313 minecraft:light[level=12]
setblock 536 205 278 minecraft:light[level=15]
setblock 536 205 286 minecraft:light[level=15]
setblock 536 205 294 minecraft:light[level=15]
setblock 536 205 310 minecraft:light[level=15]
setblock 537 205 275 minecraft:brown_terracotta
fill 537 205 317 537 212 317 minecraft:brown_terracotta
fill 541 205 275 541 212 275 minecraft:brown_terracotta
setblock 541 205 278 minecraft:light[level=12]
setblock 541 205 285 minecraft:light[level=12]
setblock 541 205 292 minecraft:light[level=12]
setblock 541 205 299 minecraft:light[level=12]
setblock 541 205 306 minecraft:light[level=12]
setblock 541 205 313 minecraft:light[level=12]
fill 541 205 316 541 205 317 minecraft:brown_terracotta
fill 542 205 316 546 205 316 minecraft:brown_terracotta
setblock 544 205 278 minecraft:light[level=15]
setblock 544 205 286 minecraft:light[level=15]
setblock 544 205 294 minecraft:light[level=15]
setblock 544 205 302 minecraft:light[level=15]
setblock 544 205 310 minecraft:light[level=15]
fill 545 205 275 545 212 275 minecraft:brown_terracotta
fill 545 205 317 545 212 317 minecraft:brown_terracotta
fill 546 205 276 551 205 276 minecraft:brown_terracotta
setblock 548 205 278 minecraft:light[level=12]
setblock 548 205 285 minecraft:light[level=12]
setblock 548 205 292 minecraft:light[level=12]
setblock 548 205 306 minecraft:light[level=12]
setblock 548 205 313 minecraft:light[level=12]
setblock 549 205 275 minecraft:brown_terracotta
fill 549 205 317 549 212 317 minecraft:brown_terracotta
setblock 552 205 278 minecraft:light[level=15]
setblock 552 205 286 minecraft:light[level=15]
setblock 552 205 294 minecraft:light[level=15]
setblock 552 205 295 minecraft:brown_terracotta
setblock 552 205 300 minecraft:brown_terracotta
setblock 552 205 302 minecraft:light[level=15]
setblock 552 205 310 minecraft:light[level=15]
fill 553 205 275 553 212 275 minecraft:brown_terracotta
setblock 553 205 296 minecraft:brown_terracotta
setblock 553 205 299 minecraft:brown_terracotta
fill 553 205 316 553 205 317 minecraft:brown_terracotta
fill 554 205 316 558 205 316 minecraft:brown_terracotta
setblock 555 205 278 minecraft:light[level=12]
setblock 555 205 285 minecraft:light[level=12]
setblock 555 205 292 minecraft:light[level=12]
setblock 555 205 299 minecraft:light[level=12]
setblock 555 205 306 minecraft:light[level=12]
setblock 555 205 313 minecraft:light[level=12]
fill 557 205 275 557 212 275 minecraft:brown_terracotta
fill 557 205 317 557 212 317 minecraft:brown_terracotta
fill 558 205 276 558 205 281 minecraft:brown_terracotta
fill 558 205 288 558 205 293 minecraft:brown_terracotta
fill 558 205 300 558 205 305 minecraft:brown_terracotta
fill 558 205 312 558 205 315 minecraft:brown_terracotta
fill 559 205 275 559 210 275 minecraft:brown_terracotta
setblock 559 205 279 minecraft:brown_terracotta
fill 559 205 283 559 212 283 minecraft:brown_terracotta
fill 559 205 287 559 212 287 minecraft:brown_terracotta
setblock 559 205 291 minecraft:brown_terracotta
fill 559 205 295 559 212 295 minecraft:brown_terracotta
fill 559 205 299 559 212 299 minecraft:brown_terracotta
setblock 559 205 303 minecraft:brown_terracotta
fill 559 205 307 559 212 307 minecraft:brown_terracotta
fill 559 205 311 559 212 311 minecraft:brown_terracotta
setblock 559 205 315 minecraft:brown_terracotta
fill 517 206 279 517 212 279 minecraft:brown_terracotta
fill 517 206 281 517 211 284 minecraft:shroomlight
fill 517 206 291 517 212 291 minecraft:brown_terracotta
fill 517 206 293 517 211 296 minecraft:shroomlight
fill 517 206 303 517 212 303 minecraft:brown_terracotta
fill 517 206 305 517 211 308 minecraft:shroomlight
fill 517 206 315 517 212 315 minecraft:brown_terracotta
fill 517 206 317 520 211 317 minecraft:shroomlight
fill 519 206 279 519 206 281 minecraft:brown_terracotta
fill 520 206 278 522 206 278 minecraft:brown_terracotta
fill 520 206 282 522 206 282 minecraft:brown_terracotta
fill 523 206 279 523 206 281 minecraft:brown_terracotta
fill 524 206 275 527 211 275 minecraft:shroomlight
fill 529 206 317 532 211 317 minecraft:shroomlight
fill 536 206 275 539 211 275 minecraft:shroomlight
fill 541 206 317 544 211 317 minecraft:shroomlight
fill 548 206 275 551 211 275 minecraft:shroomlight
fill 550 206 297 550 208 298 minecraft:white_concrete
fill 553 206 317 556 211 317 minecraft:shroomlight
fill 559 206 276 559 211 279 minecraft:shroomlight
fill 559 206 288 559 211 291 minecraft:shroomlight
fill 559 206 300 559 211 303 minecraft:shroomlight
fill 559 206 312 559 211 315 minecraft:shroomlight
fill 535 207 287 537 208 287 minecraft:lime_concrete
fill 536 207 288 537 208 288 minecraft:lime_concrete
fill 549 209 296 551 211 298 minecraft:spruce_leaves[persistent=true]
fill 550 209 299 551 211 299 minecraft:spruce_leaves[persistent=true]
fill 552 209 297 552 211 298 minecraft:spruce_leaves[persistent=true]
fill 548 210 297 548 210 298 minecraft:spruce_leaves[persistent=true]
setblock 549 210 299 minecraft:spruce_leaves[persistent=true]
setblock 552 210 296 minecraft:spruce_leaves[persistent=true]
setblock 552 210 299 minecraft:spruce_leaves[persistent=true]
setblock 517 211 277 minecraft:white_concrete
setblock 517 211 285 minecraft:white_concrete
setblock 517 211 289 minecraft:white_concrete
setblock 517 211 297 minecraft:white_concrete
setblock 517 211 301 minecraft:white_concrete
setblock 517 211 309 minecraft:white_concrete
setblock 517 211 313 minecraft:white_concrete
setblock 519 211 275 minecraft:white_concrete
setblock 520 211 278 minecraft:light[level=12]
setblock 520 211 285 minecraft:light[level=12]
setblock 520 211 292 minecraft:light[level=12]
setblock 520 211 299 minecraft:light[level=12]
setblock 520 211 306 minecraft:light[level=12]
setblock 520 211 313 minecraft:light[level=12]
setblock 523 211 275 minecraft:white_concrete
setblock 523 211 317 minecraft:white_concrete
setblock 527 211 278 minecraft:light[level=12]
setblock 527 211 285 minecraft:light[level=12]
setblock 527 211 292 minecraft:light[level=12]
setblock 527 211 299 minecraft:light[level=12]
setblock 527 211 306 minecraft:light[level=12]
setblock 527 211 313 minecraft:light[level=12]
setblock 527 211 317 minecraft:white_concrete
setblock 531 211 275 minecraft:white_concrete
setblock 534 211 278 minecraft:light[level=12]
setblock 534 211 285 minecraft:light[level=12]
setblock 534 211 292 minecraft:light[level=12]
setblock 534 211 299 minecraft:light[level=12]
setblock 534 211 306 minecraft:light[level=12]
setblock 534 211 313 minecraft:light[level=12]
setblock 535 211 275 minecraft:white_concrete
fill 535 211 281 535 212 281 minecraft:lime_concrete
setblock 535 211 317 minecraft:white_concrete
setblock 539 211 317 minecraft:white_concrete
setblock 541 211 278 minecraft:light[level=12]
setblock 541 211 285 minecraft:light[level=12]
setblock 541 211 292 minecraft:light[level=12]
setblock 541 211 299 minecraft:light[level=12]
setblock 541 211 306 minecraft:light[level=12]
setblock 541 211 313 minecraft:light[level=12]
setblock 543 211 275 minecraft:white_concrete
setblock 547 211 275 minecraft:white_concrete
setblock 547 211 317 minecraft:white_concrete
setblock 548 211 278 minecraft:light[level=12]
setblock 548 211 285 minecraft:light[level=12]
setblock 548 211 292 minecraft:light[level=12]
setblock 548 211 299 minecraft:light[level=12]
setblock 548 211 306 minecraft:light[level=12]
setblock 548 211 313 minecraft:light[level=12]
setblock 551 211 317 minecraft:white_concrete
setblock 555 211 275 minecraft:white_concrete
setblock 555 211 278 minecraft:light[level=12]
setblock 555 211 285 minecraft:light[level=12]
setblock 555 211 292 minecraft:light[level=12]
setblock 555 211 299 minecraft:light[level=12]
setblock 555 211 306 minecraft:light[level=12]
setblock 555 211 313 minecraft:light[level=12]
setblock 559 211 275 minecraft:white_concrete
setblock 559 211 281 minecraft:white_concrete
setblock 559 211 285 minecraft:white_concrete
setblock 559 211 293 minecraft:white_concrete
setblock 559 211 297 minecraft:white_concrete
setblock 559 211 305 minecraft:white_concrete
setblock 559 211 309 minecraft:white_concrete
setblock 559 211 317 minecraft:white_concrete
setblock 517 212 276 minecraft:white_concrete
fill 517 212 277 517 219 277 minecraft:brown_terracotta
setblock 517 212 278 minecraft:white_concrete
setblock 517 212 280 minecraft:white_concrete
fill 517 212 281 517 219 281 minecraft:brown_terracotta
fill 517 212 282 517 212 283 minecraft:shroomlight
setblock 517 212 284 minecraft:white_concrete
fill 517 212 285 517 219 285 minecraft:brown_terracotta
setblock 517 212 286 minecraft:white_concrete
setblock 517 212 288 minecraft:white_concrete
fill 517 212 289 517 219 289 minecraft:brown_terracotta
setblock 517 212 290 minecraft:white_concrete
setblock 517 212 292 minecraft:white_concrete
fill 517 212 293 517 219 293 minecraft:brown_terracotta
fill 517 212 294 517 212 295 minecraft:shroomlight
setblock 517 212 296 minecraft:white_concrete
fill 517 212 297 517 219 297 minecraft:brown_terracotta
setblock 517 212 298 minecraft:white_concrete
setblock 517 212 300 minecraft:white_concrete
fill 517 212 301 517 219 301 minecraft:brown_terracotta
setblock 517 212 302 minecraft:white_concrete
setblock 517 212 304 minecraft:white_concrete
fill 517 212 305 517 219 305 minecraft:brown_terracotta
fill 517 212 306 517 212 307 minecraft:shroomlight
setblock 517 212 308 minecraft:white_concrete
fill 517 212 309 517 219 309 minecraft:brown_terracotta
setblock 517 212 310 minecraft:white_concrete
setblock 517 212 312 minecraft:white_concrete
fill 517 212 313 517 219 313 minecraft:brown_terracotta
setblock 517 212 314 minecraft:white_concrete
setblock 517 212 316 minecraft:white_concrete
setblock 517 212 317 minecraft:brown_terracotta
setblock 518 212 275 minecraft:white_concrete
fill 518 212 317 519 212 317 minecraft:shroomlight
fill 519 212 275 519 219 275 minecraft:brown_terracotta
fill 519 212 279 519 213 281 minecraft:red_concrete
setblock 520 212 275 minecraft:white_concrete
fill 520 212 278 522 213 278 minecraft:red_concrete
fill 520 212 282 522 213 282 minecraft:red_concrete
setblock 520 212 317 minecraft:white_concrete
setblock 522 212 275 minecraft:white_concrete
setblock 522 212 317 minecraft:white_concrete
fill 523 212 275 523 219 275 minecraft:brown_terracotta
fill 523 212 279 523 213 281 minecraft:red_concrete
fill 523 212 317 523 219 317 minecraft:brown_terracotta
setblock 524 212 275 minecraft:white_concrete
setblock 524 212 317 minecraft:white_concrete
fill 525 212 275 526 212 275 minecraft:shroomlight
setblock 526 212 317 minecraft:white_concrete
fill 527 212 275 527 219 275 minecraft:brown_terracotta
fill 527 212 317 527 219 317 minecraft:brown_terracotta
setblock 528 212 275 minecraft:white_concrete
setblock 528 212 317 minecraft:white_concrete
setblock 529 212 317 minecraft:brown_terracotta
setblock 530 212 275 minecraft:white_concrete
fill 530 212 317 531 212 317 minecraft:shroomlight
fill 531 212 275 531 219 275 minecraft:brown_terracotta
setblock 532 212 275 minecraft:white_concrete
setblock 532 212 317 minecraft:white_concrete
setblock 534 212 275 minecraft:white_concrete
setblock 534 212 317 minecraft:white_concrete
fill 535 212 275 535 219 275 minecraft:brown_terracotta
fill 535 212 317 535 219 317 minecraft:brown_terracotta
setblock 536 212 275 minecraft:white_concrete
setblock 536 212 317 minecraft:white_concrete
fill 537 212 275 538 212 275 minecraft:shroomlight
setblock 538 212 317 minecraft:white_concrete
fill 539 212 275 539 219 275 minecraft:brown_terracotta
fill 539 212 317 539 219 317 minecraft:brown_terracotta
setblock 540 212 275 minecraft:white_concrete
setblock 540 212 317 minecraft:white_concrete
setblock 541 212 317 minecraft:brown_terracotta
setblock 542 212 275 minecraft:white_concrete
fill 542 212 317 543 212 317 minecraft:shroomlight
fill 543 212 275 543 219 275 minecraft:brown_terracotta
setblock 544 212 275 minecraft:white_concrete
setblock 544 212 317 minecraft:white_concrete
setblock 546 212 275 minecraft:white_concrete
setblock 546 212 317 minecraft:white_concrete
fill 547 212 275 547 219 275 minecraft:brown_terracotta
fill 547 212 317 547 219 317 minecraft:brown_terracotta
setblock 548 212 275 minecraft:white_concrete
setblock 548 212 317 minecraft:white_concrete
fill 549 212 275 550 212 275 minecraft:shroomlight
setblock 550 212 317 minecraft:white_concrete
fill 551 212 275 551 219 275 minecraft:brown_terracotta
fill 551 212 317 551 219 317 minecraft:brown_terracotta
setblock 552 212 275 minecraft:white_concrete
setblock 552 212 317 minecraft:white_concrete
setblock 553 212 317 minecraft:brown_terracotta
setblock 554 212 275 minecraft:white_concrete
fill 554 212 317 555 212 317 minecraft:shroomlight
fill 555 212 275 555 219 275 minecraft:brown_terracotta
setblock 556 212 275 minecraft:white_concrete
fill 556 212 287 556 213 287 minecraft:red_wool
setblock 556 212 317 minecraft:white_concrete
setblock 558 212 275 minecraft:white_concrete
setblock 558 212 317 minecraft:white_concrete
setblock 559 212 275 minecraft:brown_terracotta
setblock 559 212 276 minecraft:white_concrete
fill 559 212 277 559 212 278 minecraft:shroomlight
setblock 559 212 279 minecraft:brown_terracotta
setblock 559 212 280 minecraft:white_concrete
fill 559 212 281 559 219 281 minecraft:brown_terracotta
setblock 559 212 282 minecraft:white_concrete
setblock 559 212 284 minecraft:white_concrete
fill 559 212 285 559 219 285 minecraft:brown_terracotta
setblock 559 212 286 minecraft:white_concrete
setblock 559 212 288 minecraft:white_concrete
fill 559 212 289 559 212 290 minecraft:shroomlight
setblock 559 212 291 minecraft:brown_terracotta
setblock 559 212 292 minecraft:white_concrete
fill 559 212 293 559 219 293 minecraft:brown_terracotta
setblock 559 212 294 minecraft:white_concrete
setblock 559 212 296 minecraft:white_concrete
fill 559 212 297 559 219 297 minecraft:brown_terracotta
setblock 559 212 298 minecraft:white_concrete
setblock 559 212 300 minecraft:white_concrete
fill 559 212 301 559 212 302 minecraft:shroomlight
setblock 559 212 303 minecraft:brown_terracotta
setblock 559 212 304 minecraft:white_concrete
fill 559 212 305 559 219 305 minecraft:brown_terracotta
setblock 559 212 306 minecraft:white_concrete
setblock 559 212 308 minecraft:white_concrete
fill 559 212 309 559 219 309 minecraft:brown_terracotta
setblock 559 212 310 minecraft:white_concrete
setblock 559 212 312 minecraft:white_concrete
fill 559 212 313 559 212 314 minecraft:shroomlight
setblock 559 212 315 minecraft:brown_terracotta
setblock 559 212 316 minecraft:white_concrete
fill 559 212 317 559 219 317 minecraft:brown_terracotta
setblock 517 213 275 minecraft:white_concrete
fill 517 213 276 517 220 276 minecraft:brown_terracotta
fill 517 213 278 517 220 278 minecraft:brown_terracotta
setblock 517 213 279 minecraft:white_concrete
fill 517 213 280 517 220 280 minecraft:brown_terracotta
fill 517 213 282 517 220 282 minecraft:brown_terracotta
setblock 517 213 283 minecraft:white_concrete
fill 517 213 284 517 220 284 minecraft:brown_terracotta
fill 517 213 286 517 220 286 minecraft:brown_terracotta
setblock 517 213 287 minecraft:white_concrete
fill 517 213 288 517 220 288 minecraft:brown_terracotta
fill 517 213 290 517 220 290 minecraft:brown_terracotta
setblock 517 213 291 minecraft:white_concrete
fill 517 213 292 517 220 292 minecraft:brown_terracotta
fill 517 213 294 517 220 294 minecraft:brown_terracotta
setblock 517 213 295 minecraft:white_concrete
fill 517 213 296 517 220 296 minecraft:brown_terracotta
fill 517 213 298 517 220 298 minecraft:brown_terracotta
setblock 517 213 299 minecraft:white_concrete
fill 517 213 300 517 220 300 minecraft:brown_terracotta
fill 517 213 302 517 220 302 minecraft:brown_terracotta
setblock 517 213 303 minecraft:white_concrete
fill 517 213 304 517 220 304 minecraft:brown_terracotta
fill 517 213 306 517 220 306 minecraft:brown_terracotta
setblock 517 213 307 minecraft:white_concrete
fill 517 213 308 517 220 308 minecraft:brown_terracotta
fill 517 213 310 517 220 310 minecraft:brown_terracotta
setblock 517 213 311 minecraft:white_concrete
fill 517 213 312 517 220 312 minecraft:brown_terracotta
fill 517 213 314 517 220 314 minecraft:brown_terracotta
setblock 517 213 315 minecraft:white_concrete
fill 517 213 316 517 220 316 minecraft:brown_terracotta
setblock 517 213 317 minecraft:white_concrete
fill 518 213 275 518 220 275 minecraft:brown_terracotta
fill 518 213 317 520 219 317 minecraft:brown_terracotta
fill 520 213 275 520 220 275 minecraft:brown_terracotta
setblock 520 213 286 minecraft:light[level=15]
setblock 520 213 294 minecraft:light[level=15]
setblock 520 213 302 minecraft:light[level=15]
setblock 520 213 310 minecraft:light[level=15]
setblock 521 213 275 minecraft:white_concrete
setblock 521 213 317 minecraft:white_concrete
fill 522 213 275 522 220 275 minecraft:brown_terracotta
fill 522 213 317 522 220 317 minecraft:brown_terracotta
fill 524 213 275 524 220 275 minecraft:brown_terracotta
fill 524 213 317 524 220 317 minecraft:brown_terracotta
setblock 525 213 275 minecraft:white_concrete
setblock 525 213 317 minecraft:white_concrete
fill 526 213 275 526 220 275 minecraft:brown_terracotta
fill 526 213 317 526 220 317 minecraft:brown_terracotta
fill 528 213 275 528 220 275 minecraft:brown_terracotta
setblock 528 213 278 minecraft:light[level=15]
setblock 528 213 286 minecraft:light[level=15]
setblock 528 213 294 minecraft:light[level=15]
setblock 528 213 302 minecraft:light[level=15]
setblock 528 213 310 minecraft:light[level=15]
fill 528 213 317 528 220 317 minecraft:brown_terracotta
setblock 529 213 275 minecraft:white_concrete
setblock 529 213 317 minecraft:white_concrete
fill 530 213 275 530 220 275 minecraft:brown_terracotta
fill 530 213 317 532 219 317 minecraft:brown_terracotta
fill 532 213 275 532 220 275 minecraft:brown_terracotta
setblock 533 213 275 minecraft:white_concrete
setblock 533 213 317 minecraft:white_concrete
fill 534 213 275 534 220 275 minecraft:brown_terracotta
fill 534 213 317 534 220 317 minecraft:brown_terracotta
fill 536 213 275 536 220 275 minecraft:brown_terracotta
setblock 536 213 278 minecraft:light[level=15]
setblock 536 213 286 minecraft:light[level=15]
setblock 536 213 294 minecraft:light[level=15]
setblock 536 213 310 minecraft:light[level=15]
fill 536 213 317 536 220 317 minecraft:brown_terracotta
setblock 537 213 275 minecraft:white_concrete
setblock 537 213 317 minecraft:white_concrete
fill 538 213 275 538 220 275 minecraft:brown_terracotta
fill 538 213 317 538 220 317 minecraft:brown_terracotta
fill 540 213 275 540 220 275 minecraft:brown_terracotta
fill 540 213 317 540 220 317 minecraft:brown_terracotta
setblock 541 213 275 minecraft:white_concrete
setblock 541 213 317 minecraft:white_concrete
fill 542 213 275 542 220 275 minecraft:brown_terracotta
fill 542 213 317 544 219 317 minecraft:brown_terracotta
fill 544 213 275 544 220 275 minecraft:brown_terracotta
setblock 544 213 278 minecraft:light[level=15]
setblock 544 213 286 minecraft:light[level=15]
setblock 544 213 294 minecraft:light[level=15]
setblock 544 213 302 minecraft:light[level=15]
setblock 544 213 310 minecraft:light[level=15]
setblock 545 213 275 minecraft:white_concrete
setblock 545 213 317 minecraft:white_concrete
fill 546 213 275 546 220 275 minecraft:brown_terracotta
fill 546 213 317 546 220 317 minecraft:brown_terracotta
fill 548 213 275 548 220 275 minecraft:brown_terracotta
fill 548 213 317 548 220 317 minecraft:brown_terracotta
setblock 549 213 275 minecraft:white_concrete
setblock 549 213 317 minecraft:white_concrete
fill 550 213 275 550 220 275 minecraft:brown_terracotta
fill 550 213 317 550 220 317 minecraft:brown_terracotta
fill 552 213 275 552 220 275 minecraft:brown_terracotta
setblock 552 213 278 minecraft:light[level=15]
setblock 552 213 286 minecraft:light[level=15]
setblock 552 213 294 minecraft:light[level=15]
setblock 552 213 302 minecraft:light[level=15]
setblock 552 213 310 minecraft:light[level=15]
fill 552 213 317 552 220 317 minecraft:brown_terracotta
setblock 553 213 275 minecraft:white_concrete
setblock 553 213 317 minecraft:white_concrete
fill 554 213 275 554 220 275 minecraft:brown_terracotta
fill 554 213 317 556 219 317 minecraft:brown_terracotta
fill 556 213 275 556 220 275 minecraft:brown_terracotta
fill 556 213 285 556 213 286 minecraft:red_wool
fill 556 213 288 556 213 289 minecraft:red_wool
setblock 557 213 275 minecraft:white_concrete
setblock 557 213 317 minecraft:white_concrete
fill 558 213 275 558 220 275 minecraft:brown_terracotta
fill 558 213 317 558 220 317 minecraft:brown_terracotta
setblock 559 213 275 minecraft:white_concrete
fill 559 213 276 559 219 278 minecraft:brown_terracotta
setblock 559 213 279 minecraft:white_concrete
fill 559 213 280 559 220 280 minecraft:brown_terracotta
fill 559 213 282 559 220 282 minecraft:brown_terracotta
setblock 559 213 283 minecraft:white_concrete
fill 559 213 284 559 220 284 minecraft:brown_terracotta
fill 559 213 286 559 220 286 minecraft:brown_terracotta
setblock 559 213 287 minecraft:white_concrete
fill 559 213 288 559 219 290 minecraft:brown_terracotta
setblock 559 213 291 minecraft:white_concrete
fill 559 213 292 559 220 292 minecraft:brown_terracotta
fill 559 213 294 559 220 294 minecraft:brown_terracotta
setblock 559 213 295 minecraft:white_concrete
fill 559 213 296 559 220 296 minecraft:brown_terracotta
fill 559 213 298 559 220 298 minecraft:brown_terracotta
setblock 559 213 299 minecraft:white_concrete
fill 559 213 300 559 219 302 minecraft:brown_terracotta
setblock 559 213 303 minecraft:white_concrete
fill 559 213 304 559 220 304 minecraft:brown_terracotta
fill 559 213 306 559 220 306 minecraft:brown_terracotta
setblock 559 213 307 minecraft:white_concrete
fill 559 213 308 559 220 308 minecraft:brown_terracotta
fill 559 213 310 559 220 310 minecraft:brown_terracotta
setblock 559 213 311 minecraft:white_concrete
fill 559 213 312 559 219 314 minecraft:brown_terracotta
setblock 559 213 315 minecraft:white_concrete
fill 559 213 316 559 220 316 minecraft:brown_terracotta
fill 517 214 275 517 221 275 minecraft:brown_terracotta
fill 517 214 279 517 221 279 minecraft:brown_terracotta
fill 517 214 283 517 221 283 minecraft:brown_terracotta
fill 517 214 287 517 221 287 minecraft:brown_terracotta
fill 517 214 291 517 221 291 minecraft:brown_terracotta
fill 517 214 295 517 221 295 minecraft:brown_terracotta
fill 517 214 299 517 221 299 minecraft:brown_terracotta
fill 517 214 303 517 221 303 minecraft:brown_terracotta
fill 517 214 307 517 221 307 minecraft:brown_terracotta
fill 517 214 311 517 221 311 minecraft:brown_terracotta
fill 517 214 315 517 221 315 minecraft:brown_terracotta
fill 517 214 317 517 219 317 minecraft:brown_terracotta
fill 521 214 275 521 221 275 minecraft:brown_terracotta
fill 521 214 317 521 221 317 minecraft:brown_terracotta
fill 525 214 275 525 221 275 minecraft:brown_terracotta
fill 525 214 317 525 221 317 minecraft:brown_terracotta
fill 529 214 275 529 221 275 minecraft:brown_terracotta
fill 529 214 317 529 221 317 minecraft:brown_terracotta
fill 533 214 275 533 221 275 minecraft:brown_terracotta
fill 533 214 317 533 221 317 minecraft:brown_terracotta
fill 537 214 275 537 221 275 minecraft:brown_terracotta
fill 537 214 317 537 221 317 minecraft:brown_terracotta
fill 541 214 275 541 221 275 minecraft:brown_terracotta
fill 541 214 317 541 221 317 minecraft:brown_terracotta
fill 545 214 275 545 221 275 minecraft:brown_terracotta
fill 545 214 317 545 221 317 minecraft:brown_terracotta
fill 549 214 275 549 221 275 minecraft:brown_terracotta
fill 549 214 317 549 221 317 minecraft:brown_terracotta
fill 553 214 275 553 221 275 minecraft:brown_terracotta
fill 553 214 317 553 221 317 minecraft:brown_terracotta
fill 557 214 275 557 221 275 minecraft:brown_terracotta
fill 557 214 317 557 221 317 minecraft:brown_terracotta
fill 559 214 275 559 219 275 minecraft:brown_terracotta
fill 559 214 279 559 221 279 minecraft:brown_terracotta
fill 559 214 283 559 221 283 minecraft:brown_terracotta
fill 559 214 287 559 221 287 minecraft:brown_terracotta
fill 559 214 291 559 221 291 minecraft:brown_terracotta
fill 559 214 295 559 221 295 minecraft:brown_terracotta
fill 559 214 299 559 221 299 minecraft:brown_terracotta
fill 559 214 303 559 221 303 minecraft:brown_terracotta
fill 559 214 307 559 221 307 minecraft:brown_terracotta
fill 559 214 311 559 221 311 minecraft:brown_terracotta
fill 559 214 315 559 221 315 minecraft:brown_terracotta
setblock 520 217 278 minecraft:light[level=12]
setblock 520 217 285 minecraft:light[level=12]
setblock 520 217 292 minecraft:light[level=12]
setblock 520 217 299 minecraft:light[level=12]
setblock 520 217 306 minecraft:light[level=12]
setblock 520 217 313 minecraft:light[level=12]
setblock 527 217 278 minecraft:light[level=12]
setblock 527 217 285 minecraft:light[level=12]
setblock 527 217 292 minecraft:light[level=12]
setblock 527 217 299 minecraft:light[level=12]
setblock 527 217 306 minecraft:light[level=12]
setblock 527 217 313 minecraft:light[level=12]
setblock 534 217 278 minecraft:light[level=12]
schedule function dropper:buildpart/71_5 1t
