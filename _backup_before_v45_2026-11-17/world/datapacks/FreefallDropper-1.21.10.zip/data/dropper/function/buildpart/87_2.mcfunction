setblock 142 118 381 minecraft:white_concrete
setblock 142 118 388 minecraft:white_concrete
setblock 142 118 395 minecraft:white_concrete
setblock 142 118 402 minecraft:white_concrete
setblock 142 118 409 minecraft:white_concrete
setblock 145 118 370 minecraft:white_concrete
setblock 148 118 410 minecraft:white_concrete
setblock 152 118 370 minecraft:white_concrete
setblock 155 118 410 minecraft:white_concrete
setblock 159 118 370 minecraft:white_concrete
setblock 162 118 410 minecraft:white_concrete
setblock 166 118 370 minecraft:white_concrete
setblock 169 118 410 minecraft:white_concrete
setblock 173 118 370 minecraft:white_concrete
setblock 176 118 410 minecraft:white_concrete
setblock 180 118 370 minecraft:white_concrete
setblock 182 118 375 minecraft:white_concrete
setblock 182 118 382 minecraft:white_concrete
setblock 182 118 389 minecraft:white_concrete
setblock 182 118 396 minecraft:white_concrete
setblock 182 118 403 minecraft:white_concrete
fill 142 120 370 142 120 374 minecraft:white_concrete
fill 142 120 376 142 120 381 minecraft:white_concrete
fill 142 120 383 142 120 388 minecraft:white_concrete
fill 142 120 390 142 120 395 minecraft:white_concrete
fill 142 120 397 142 120 402 minecraft:white_concrete
fill 142 120 404 142 120 409 minecraft:white_concrete
setblock 143 120 370 minecraft:white_concrete
fill 143 120 410 148 120 410 minecraft:white_concrete
fill 145 120 370 150 120 370 minecraft:white_concrete
fill 150 120 410 155 120 410 minecraft:white_concrete
fill 152 120 370 157 120 370 minecraft:white_concrete
fill 157 120 410 162 120 410 minecraft:white_concrete
fill 159 120 370 164 120 370 minecraft:white_concrete
fill 164 120 410 169 120 410 minecraft:white_concrete
fill 166 120 370 171 120 370 minecraft:white_concrete
fill 171 120 410 176 120 410 minecraft:white_concrete
fill 173 120 370 178 120 370 minecraft:white_concrete
fill 178 120 410 182 120 410 minecraft:white_concrete
fill 180 120 370 182 120 370 minecraft:white_concrete
fill 182 120 371 182 120 373 minecraft:white_concrete
fill 182 120 375 182 120 380 minecraft:white_concrete
fill 182 120 382 182 120 387 minecraft:white_concrete
fill 182 120 389 182 120 394 minecraft:white_concrete
fill 182 120 396 182 120 401 minecraft:white_concrete
fill 182 120 403 182 120 408 minecraft:white_concrete
setblock 142 121 370 minecraft:white_concrete
setblock 142 121 377 minecraft:white_concrete
setblock 142 121 384 minecraft:white_concrete
setblock 142 121 391 minecraft:white_concrete
setblock 142 121 398 minecraft:white_concrete
setblock 142 121 405 minecraft:white_concrete
setblock 144 121 410 minecraft:white_concrete
setblock 149 121 370 minecraft:white_concrete
setblock 151 121 410 minecraft:white_concrete
setblock 156 121 370 minecraft:white_concrete
setblock 158 121 410 minecraft:white_concrete
setblock 163 121 370 minecraft:white_concrete
setblock 165 121 410 minecraft:white_concrete
setblock 170 121 370 minecraft:white_concrete
setblock 172 121 410 minecraft:white_concrete
setblock 177 121 370 minecraft:white_concrete
setblock 179 121 410 minecraft:white_concrete
setblock 182 121 372 minecraft:white_concrete
setblock 182 121 379 minecraft:white_concrete
setblock 182 121 386 minecraft:white_concrete
setblock 182 121 393 minecraft:white_concrete
setblock 182 121 400 minecraft:white_concrete
setblock 182 121 407 minecraft:white_concrete
setblock 142 122 371 minecraft:white_concrete
setblock 142 122 378 minecraft:white_concrete
setblock 142 122 385 minecraft:white_concrete
setblock 142 122 392 minecraft:white_concrete
fill 142 122 397 144 123 397 minecraft:gray_concrete
setblock 142 122 399 minecraft:white_concrete
setblock 142 122 406 minecraft:white_concrete
setblock 145 122 410 minecraft:white_concrete
setblock 148 122 370 minecraft:white_concrete
setblock 152 122 410 minecraft:white_concrete
setblock 155 122 370 minecraft:white_concrete
setblock 159 122 410 minecraft:white_concrete
setblock 162 122 370 minecraft:white_concrete
setblock 166 122 410 minecraft:white_concrete
setblock 169 122 370 minecraft:white_concrete
setblock 173 122 410 minecraft:white_concrete
setblock 176 122 370 minecraft:white_concrete
setblock 180 122 410 minecraft:white_concrete
setblock 182 122 371 minecraft:white_concrete
setblock 182 122 378 minecraft:white_concrete
setblock 182 122 385 minecraft:white_concrete
setblock 182 122 392 minecraft:white_concrete
setblock 182 122 399 minecraft:white_concrete
setblock 182 122 406 minecraft:white_concrete
setblock 142 123 372 minecraft:white_concrete
setblock 142 123 379 minecraft:white_concrete
setblock 142 123 386 minecraft:white_concrete
setblock 142 123 393 minecraft:white_concrete
setblock 142 123 400 minecraft:white_concrete
setblock 142 123 407 minecraft:white_concrete
setblock 144 123 372 minecraft:light[level=14]
setblock 144 123 380 minecraft:light[level=14]
setblock 144 123 388 minecraft:light[level=14]
setblock 144 123 396 minecraft:light[level=14]
setblock 144 123 404 minecraft:light[level=14]
fill 145 123 388 145 124 388 minecraft:white_wool
setblock 146 123 410 minecraft:white_concrete
setblock 147 123 370 minecraft:white_concrete
setblock 152 123 372 minecraft:light[level=14]
setblock 152 123 380 minecraft:light[level=14]
setblock 152 123 388 minecraft:light[level=14]
setblock 152 123 396 minecraft:light[level=14]
setblock 152 123 404 minecraft:light[level=14]
setblock 153 123 410 minecraft:white_concrete
setblock 154 123 370 minecraft:white_concrete
setblock 160 123 372 minecraft:light[level=14]
setblock 160 123 380 minecraft:light[level=14]
setblock 160 123 388 minecraft:light[level=14]
setblock 160 123 396 minecraft:light[level=14]
setblock 160 123 404 minecraft:light[level=14]
setblock 160 123 410 minecraft:white_concrete
setblock 161 123 370 minecraft:white_concrete
setblock 167 123 410 minecraft:white_concrete
setblock 168 123 370 minecraft:white_concrete
setblock 168 123 372 minecraft:light[level=14]
setblock 168 123 380 minecraft:light[level=14]
setblock 168 123 388 minecraft:light[level=14]
setblock 168 123 396 minecraft:light[level=14]
setblock 168 123 404 minecraft:light[level=14]
setblock 174 123 410 minecraft:white_concrete
setblock 175 123 370 minecraft:white_concrete
setblock 176 123 372 minecraft:light[level=14]
setblock 176 123 380 minecraft:light[level=14]
setblock 176 123 388 minecraft:light[level=14]
setblock 176 123 396 minecraft:light[level=14]
setblock 176 123 404 minecraft:light[level=14]
setblock 181 123 410 minecraft:white_concrete
setblock 182 123 370 minecraft:white_concrete
setblock 182 123 377 minecraft:white_concrete
setblock 182 123 384 minecraft:white_concrete
setblock 182 123 391 minecraft:white_concrete
setblock 182 123 398 minecraft:white_concrete
setblock 182 123 405 minecraft:white_concrete
setblock 142 124 373 minecraft:white_concrete
setblock 142 124 380 minecraft:white_concrete
setblock 142 124 387 minecraft:white_concrete
setblock 142 124 394 minecraft:white_concrete
setblock 142 124 401 minecraft:white_concrete
setblock 142 124 408 minecraft:white_concrete
setblock 146 124 370 minecraft:white_concrete
setblock 147 124 410 minecraft:white_concrete
setblock 153 124 370 minecraft:white_concrete
setblock 154 124 410 minecraft:white_concrete
setblock 160 124 370 minecraft:white_concrete
setblock 161 124 410 minecraft:white_concrete
setblock 167 124 370 minecraft:white_concrete
setblock 168 124 410 minecraft:white_concrete
setblock 174 124 370 minecraft:white_concrete
setblock 175 124 410 minecraft:white_concrete
setblock 181 124 370 minecraft:white_concrete
setblock 182 124 376 minecraft:white_concrete
setblock 182 124 383 minecraft:white_concrete
setblock 182 124 390 minecraft:white_concrete
setblock 182 124 397 minecraft:white_concrete
setblock 182 124 404 minecraft:white_concrete
setblock 182 124 410 minecraft:white_concrete
setblock 142 125 374 minecraft:white_concrete
setblock 142 125 381 minecraft:white_concrete
setblock 142 125 388 minecraft:white_concrete
setblock 142 125 395 minecraft:white_concrete
setblock 142 125 402 minecraft:white_concrete
setblock 142 125 409 minecraft:white_concrete
setblock 145 125 370 minecraft:white_concrete
setblock 148 125 410 minecraft:white_concrete
setblock 152 125 370 minecraft:white_concrete
setblock 155 125 410 minecraft:white_concrete
setblock 159 125 370 minecraft:white_concrete
setblock 162 125 410 minecraft:white_concrete
setblock 166 125 370 minecraft:white_concrete
setblock 169 125 410 minecraft:white_concrete
setblock 173 125 370 minecraft:white_concrete
setblock 176 125 410 minecraft:white_concrete
setblock 180 125 370 minecraft:white_concrete
setblock 182 125 375 minecraft:white_concrete
setblock 182 125 382 minecraft:white_concrete
setblock 182 125 389 minecraft:white_concrete
setblock 182 125 396 minecraft:white_concrete
setblock 182 125 403 minecraft:white_concrete
fill 179 126 407 179 127 409 minecraft:gray_concrete
setblock 142 127 376 minecraft:white_concrete
setblock 142 127 383 minecraft:white_concrete
setblock 142 127 390 minecraft:white_concrete
setblock 142 127 397 minecraft:white_concrete
setblock 142 127 404 minecraft:white_concrete
setblock 143 127 370 minecraft:white_concrete
setblock 143 127 410 minecraft:white_concrete
setblock 150 127 370 minecraft:white_concrete
setblock 150 127 410 minecraft:white_concrete
setblock 157 127 370 minecraft:white_concrete
setblock 157 127 410 minecraft:white_concrete
setblock 164 127 370 minecraft:white_concrete
setblock 164 127 410 minecraft:white_concrete
setblock 171 127 370 minecraft:white_concrete
setblock 171 127 410 minecraft:white_concrete
setblock 178 127 370 minecraft:white_concrete
setblock 178 127 410 minecraft:white_concrete
setblock 182 127 373 minecraft:white_concrete
setblock 182 127 380 minecraft:white_concrete
setblock 182 127 387 minecraft:white_concrete
setblock 182 127 394 minecraft:white_concrete
setblock 182 127 401 minecraft:white_concrete
setblock 182 127 408 minecraft:white_concrete
setblock 142 128 370 minecraft:white_concrete
setblock 142 128 377 minecraft:white_concrete
setblock 142 128 384 minecraft:white_concrete
setblock 142 128 391 minecraft:white_concrete
setblock 142 128 398 minecraft:white_concrete
setblock 142 128 405 minecraft:white_concrete
setblock 144 128 410 minecraft:white_concrete
setblock 149 128 370 minecraft:white_concrete
setblock 151 128 410 minecraft:white_concrete
setblock 156 128 370 minecraft:white_concrete
setblock 158 128 410 minecraft:white_concrete
setblock 163 128 370 minecraft:white_concrete
setblock 165 128 410 minecraft:white_concrete
setblock 170 128 370 minecraft:white_concrete
setblock 172 128 410 minecraft:white_concrete
setblock 177 128 370 minecraft:white_concrete
setblock 179 128 410 minecraft:white_concrete
setblock 182 128 372 minecraft:white_concrete
setblock 182 128 379 minecraft:white_concrete
setblock 182 128 386 minecraft:white_concrete
setblock 182 128 393 minecraft:white_concrete
setblock 182 128 400 minecraft:white_concrete
setblock 182 128 407 minecraft:white_concrete
fill 142 129 371 142 130 371 minecraft:white_concrete
fill 142 129 378 142 130 378 minecraft:white_concrete
fill 142 129 385 142 130 385 minecraft:white_concrete
fill 142 129 392 142 130 392 minecraft:white_concrete
fill 142 129 399 142 130 399 minecraft:white_concrete
fill 142 129 406 142 130 406 minecraft:white_concrete
fill 145 129 410 145 130 410 minecraft:white_concrete
fill 148 129 370 148 130 370 minecraft:white_concrete
fill 152 129 410 152 130 410 minecraft:white_concrete
fill 155 129 370 155 130 370 minecraft:white_concrete
fill 158 129 404 159 130 404 minecraft:purple_wool
fill 159 129 410 159 130 410 minecraft:white_concrete
fill 162 129 370 162 130 370 minecraft:white_concrete
fill 166 129 410 166 130 410 minecraft:white_concrete
fill 169 129 370 169 130 370 minecraft:white_concrete
fill 173 129 410 173 130 410 minecraft:white_concrete
fill 176 129 370 176 130 370 minecraft:white_concrete
fill 180 129 410 180 130 410 minecraft:white_concrete
fill 182 129 371 182 130 371 minecraft:white_concrete
fill 182 129 378 182 130 378 minecraft:white_concrete
fill 182 129 385 182 130 385 minecraft:white_concrete
fill 182 129 392 182 130 392 minecraft:white_concrete
fill 182 129 399 182 130 399 minecraft:white_concrete
fill 182 129 406 182 130 406 minecraft:white_concrete
fill 142 130 370 143 130 370 minecraft:white_concrete
fill 142 130 372 142 130 374 minecraft:white_concrete
fill 142 130 376 142 130 377 minecraft:white_concrete
fill 142 130 379 142 130 381 minecraft:white_concrete
fill 142 130 383 142 130 384 minecraft:white_concrete
fill 142 130 386 142 130 388 minecraft:white_concrete
fill 142 130 390 142 130 391 minecraft:white_concrete
fill 142 130 393 142 130 395 minecraft:white_concrete
fill 142 130 397 142 130 398 minecraft:white_concrete
fill 142 130 400 142 130 402 minecraft:white_concrete
fill 142 130 404 142 130 405 minecraft:white_concrete
fill 142 130 407 142 130 409 minecraft:white_concrete
fill 143 130 410 144 130 410 minecraft:white_concrete
fill 145 130 370 147 130 370 minecraft:white_concrete
fill 146 130 410 148 130 410 minecraft:white_concrete
fill 149 130 370 150 130 370 minecraft:white_concrete
fill 150 130 410 151 130 410 minecraft:white_concrete
fill 152 130 370 154 130 370 minecraft:white_concrete
fill 153 130 410 155 130 410 minecraft:white_concrete
fill 156 130 370 157 130 370 minecraft:white_concrete
fill 157 130 410 158 130 410 minecraft:white_concrete
fill 159 130 370 161 130 370 minecraft:white_concrete
fill 160 130 410 162 130 410 minecraft:white_concrete
fill 163 130 370 164 130 370 minecraft:white_concrete
fill 164 130 410 165 130 410 minecraft:white_concrete
fill 166 130 370 168 130 370 minecraft:white_concrete
fill 167 130 410 169 130 410 minecraft:white_concrete
fill 170 130 370 171 130 370 minecraft:white_concrete
fill 171 130 410 172 130 410 minecraft:white_concrete
fill 173 130 370 175 130 370 minecraft:white_concrete
fill 174 130 410 176 130 410 minecraft:white_concrete
fill 177 130 370 178 130 370 minecraft:white_concrete
fill 178 130 410 179 130 410 minecraft:white_concrete
fill 180 130 370 182 130 370 minecraft:white_concrete
fill 181 130 410 182 130 410 minecraft:white_concrete
fill 182 130 372 182 130 373 minecraft:white_concrete
fill 182 130 375 182 130 377 minecraft:white_concrete
fill 182 130 379 182 130 380 minecraft:white_concrete
fill 182 130 382 182 130 384 minecraft:white_concrete
fill 182 130 386 182 130 387 minecraft:white_concrete
fill 182 130 389 182 130 391 minecraft:white_concrete
fill 182 130 393 182 130 394 minecraft:white_concrete
fill 182 130 396 182 130 398 minecraft:white_concrete
fill 182 130 400 182 130 401 minecraft:white_concrete
fill 182 130 403 182 130 405 minecraft:white_concrete
fill 182 130 407 182 130 408 minecraft:white_concrete
setblock 142 131 373 minecraft:white_concrete
setblock 142 131 380 minecraft:white_concrete
setblock 142 131 387 minecraft:white_concrete
setblock 142 131 394 minecraft:white_concrete
setblock 142 131 401 minecraft:white_concrete
setblock 142 131 408 minecraft:white_concrete
setblock 144 131 372 minecraft:light[level=14]
setblock 144 131 380 minecraft:light[level=14]
setblock 144 131 388 minecraft:light[level=14]
setblock 144 131 396 minecraft:light[level=14]
setblock 144 131 404 minecraft:light[level=14]
setblock 146 131 370 minecraft:white_concrete
setblock 147 131 410 minecraft:white_concrete
setblock 152 131 372 minecraft:light[level=14]
setblock 152 131 380 minecraft:light[level=14]
setblock 152 131 388 minecraft:light[level=14]
setblock 152 131 396 minecraft:light[level=14]
setblock 152 131 404 minecraft:light[level=14]
setblock 153 131 370 minecraft:white_concrete
setblock 154 131 410 minecraft:white_concrete
setblock 160 131 370 minecraft:white_concrete
setblock 160 131 372 minecraft:light[level=14]
setblock 160 131 380 minecraft:light[level=14]
setblock 160 131 388 minecraft:light[level=14]
setblock 160 131 396 minecraft:light[level=14]
setblock 160 131 404 minecraft:light[level=14]
setblock 161 131 410 minecraft:white_concrete
setblock 167 131 370 minecraft:white_concrete
setblock 168 131 372 minecraft:light[level=14]
setblock 168 131 380 minecraft:light[level=14]
setblock 168 131 388 minecraft:light[level=14]
setblock 168 131 396 minecraft:light[level=14]
setblock 168 131 404 minecraft:light[level=14]
setblock 168 131 410 minecraft:white_concrete
setblock 174 131 370 minecraft:white_concrete
setblock 175 131 410 minecraft:white_concrete
setblock 176 131 372 minecraft:light[level=14]
setblock 176 131 380 minecraft:light[level=14]
setblock 176 131 388 minecraft:light[level=14]
setblock 176 131 396 minecraft:light[level=14]
setblock 176 131 404 minecraft:light[level=14]
setblock 181 131 370 minecraft:white_concrete
setblock 182 131 376 minecraft:white_concrete
setblock 182 131 383 minecraft:white_concrete
setblock 182 131 390 minecraft:white_concrete
setblock 182 131 397 minecraft:white_concrete
setblock 182 131 404 minecraft:white_concrete
setblock 182 131 410 minecraft:white_concrete
setblock 142 132 374 minecraft:white_concrete
setblock 142 132 381 minecraft:white_concrete
setblock 142 132 388 minecraft:white_concrete
setblock 142 132 395 minecraft:white_concrete
setblock 142 132 402 minecraft:white_concrete
setblock 142 132 409 minecraft:white_concrete
setblock 145 132 370 minecraft:white_concrete
setblock 148 132 410 minecraft:white_concrete
setblock 152 132 370 minecraft:white_concrete
setblock 155 132 410 minecraft:white_concrete
setblock 159 132 370 minecraft:white_concrete
setblock 162 132 410 minecraft:white_concrete
setblock 166 132 370 minecraft:white_concrete
setblock 169 132 410 minecraft:white_concrete
setblock 173 132 370 minecraft:white_concrete
setblock 176 132 410 minecraft:white_concrete
setblock 180 132 370 minecraft:white_concrete
setblock 182 132 375 minecraft:white_concrete
setblock 182 132 382 minecraft:white_concrete
setblock 182 132 389 minecraft:white_concrete
setblock 182 132 396 minecraft:white_concrete
setblock 182 132 403 minecraft:white_concrete
setblock 144 139 372 minecraft:light[level=14]
setblock 144 139 380 minecraft:light[level=14]
setblock 144 139 388 minecraft:light[level=14]
fill 144 139 393 147 139 393 minecraft:white_concrete
setblock 144 139 396 minecraft:light[level=14]
setblock 144 139 404 minecraft:light[level=14]
setblock 145 139 388 minecraft:black_concrete
fill 145 139 389 148 139 392 minecraft:white_concrete
fill 145 139 394 147 139 398 minecraft:white_concrete
fill 146 139 386 146 139 387 minecraft:black_concrete
fill 146 139 388 151 139 388 minecraft:white_concrete
fill 146 139 399 147 139 400 minecraft:white_concrete
fill 147 139 384 147 139 386 minecraft:black_concrete
fill 147 139 387 152 139 387 minecraft:white_concrete
fill 147 139 401 148 139 402 minecraft:white_concrete
fill 148 139 383 148 139 385 minecraft:black_concrete
fill 148 139 386 154 139 386 minecraft:white_concrete
fill 148 139 393 153 139 400 minecraft:black_concrete
fill 148 139 403 149 139 403 minecraft:white_concrete
fill 149 139 382 149 139 384 minecraft:black_concrete
fill 149 139 385 164 139 385 minecraft:white_concrete
fill 149 139 389 149 139 390 minecraft:white_concrete
fill 149 139 391 155 139 392 minecraft:black_concrete
fill 149 139 401 155 139 402 minecraft:black_concrete
setblock 149 139 404 minecraft:white_concrete
fill 150 139 381 151 139 383 minecraft:black_concrete
fill 150 139 384 163 139 384 minecraft:white_concrete
setblock 150 139 389 minecraft:white_concrete
fill 150 139 390 158 139 390 minecraft:black_concrete
fill 150 139 403 158 139 404 minecraft:black_concrete
setblock 150 139 405 minecraft:white_concrete
fill 151 139 380 168 139 380 minecraft:black_concrete
fill 151 139 389 162 139 389 minecraft:black_concrete
fill 151 139 405 170 139 405 minecraft:black_concrete
fill 151 139 406 151 140 406 minecraft:white_concrete
setblock 152 139 372 minecraft:light[level=14]
fill 152 139 381 153 139 382 minecraft:black_concrete
fill 152 139 383 161 139 383 minecraft:white_concrete
fill 152 139 388 161 139 388 minecraft:black_concrete
fill 152 139 406 169 139 406 minecraft:black_concrete
fill 153 139 379 167 139 379 minecraft:black_concrete
fill 153 139 387 160 139 387 minecraft:black_concrete
fill 153 139 407 167 139 407 minecraft:black_concrete
fill 154 139 381 169 139 381 minecraft:black_concrete
fill 154 139 382 159 139 382 minecraft:white_concrete
fill 154 139 393 154 139 395 minecraft:black_concrete
fill 154 139 396 157 139 396 minecraft:white_concrete
fill 154 139 397 154 139 400 minecraft:black_concrete
fill 155 139 378 165 139 378 minecraft:black_concrete
fill 155 139 386 158 139 386 minecraft:black_concrete
fill 155 139 393 156 139 395 minecraft:white_concrete
fill 155 139 397 157 139 399 minecraft:white_concrete
setblock 155 139 400 minecraft:black_concrete
fill 155 139 408 165 139 408 minecraft:black_concrete
fill 156 139 391 157 139 391 minecraft:black_concrete
setblock 156 139 392 minecraft:white_concrete
fill 156 139 400 161 139 401 minecraft:white_concrete
setblock 156 139 402 minecraft:black_concrete
fill 157 139 392 157 139 394 minecraft:purple_concrete
setblock 157 139 395 minecraft:white_concrete
fill 157 139 402 170 139 402 minecraft:white_concrete
setblock 158 139 391 minecraft:purple_concrete
setblock 158 139 395 minecraft:purple_concrete
fill 158 139 396 158 139 397 minecraft:black_concrete
fill 158 139 398 158 139 399 minecraft:white_concrete
fill 159 139 386 164 139 386 minecraft:white_concrete
fill 159 139 390 161 139 390 minecraft:purple_concrete
fill 159 139 396 161 139 396 minecraft:purple_concrete
fill 159 139 397 168 139 398 minecraft:black_concrete
setblock 159 139 399 minecraft:white_concrete
fill 159 139 403 168 139 403 minecraft:white_concrete
fill 159 139 404 160 139 404 minecraft:black_concrete
setblock 160 139 372 minecraft:light[level=14]
setblock 160 139 377 minecraft:black_concrete
fill 160 139 382 170 139 382 minecraft:black_concrete
fill 160 139 399 167 139 399 minecraft:black_concrete
setblock 160 139 409 minecraft:black_concrete
fill 161 139 387 165 139 387 minecraft:white_concrete
fill 161 139 404 166 139 404 minecraft:white_concrete
fill 162 139 383 170 139 383 minecraft:black_concrete
fill 162 139 388 165 139 388 minecraft:white_concrete
setblock 162 139 390 minecraft:black_concrete
setblock 162 139 391 minecraft:purple_concrete
setblock 162 139 395 minecraft:purple_concrete
fill 162 139 396 170 139 396 minecraft:black_concrete
fill 162 139 400 165 139 400 minecraft:black_concrete
fill 162 139 401 171 139 401 minecraft:white_concrete
fill 163 139 389 165 139 391 minecraft:white_concrete
fill 163 139 392 163 139 394 minecraft:purple_concrete
fill 163 139 395 171 139 395 minecraft:black_concrete
fill 164 139 384 171 139 384 minecraft:black_concrete
fill 164 139 392 164 139 394 minecraft:white_concrete
fill 165 139 385 171 139 386 minecraft:black_concrete
fill 165 139 392 165 139 393 minecraft:white_concrete
fill 165 139 394 171 139 394 minecraft:black_concrete
fill 166 139 387 172 139 389 minecraft:black_concrete
setblock 166 139 390 minecraft:white_concrete
fill 166 139 391 172 139 393 minecraft:black_concrete
fill 166 139 400 172 139 400 minecraft:white_concrete
fill 167 139 390 172 139 390 minecraft:black_concrete
fill 167 139 404 171 139 404 minecraft:black_concrete
setblock 168 139 372 minecraft:light[level=14]
fill 168 139 399 173 139 399 minecraft:white_concrete
fill 169 139 380 169 140 380 minecraft:white_concrete
setblock 169 139 397 minecraft:black_concrete
fill 169 139 398 174 139 398 minecraft:white_concrete
fill 169 139 403 172 139 403 minecraft:black_concrete
setblock 170 139 381 minecraft:white_concrete
fill 170 139 397 175 139 397 minecraft:white_concrete
fill 171 139 382 171 139 383 minecraft:white_concrete
fill 171 139 396 175 139 396 minecraft:white_concrete
fill 171 139 402 173 139 402 minecraft:black_concrete
fill 172 139 383 172 139 385 minecraft:white_concrete
setblock 172 139 386 minecraft:black_concrete
fill 172 139 394 175 139 395 minecraft:white_concrete
fill 172 139 401 173 139 401 minecraft:black_concrete
fill 173 139 384 173 139 393 minecraft:white_concrete
fill 173 139 400 174 139 400 minecraft:black_concrete
fill 174 139 386 174 139 393 minecraft:white_concrete
setblock 174 139 399 minecraft:black_concrete
fill 175 139 388 175 139 393 minecraft:white_concrete
setblock 175 139 398 minecraft:black_concrete
setblock 176 139 372 minecraft:light[level=14]
setblock 176 139 380 minecraft:light[level=14]
setblock 176 139 388 minecraft:light[level=14]
setblock 176 139 393 minecraft:white_concrete
setblock 176 139 396 minecraft:light[level=14]
setblock 176 139 404 minecraft:light[level=14]
fill 142 140 370 142 140 374 minecraft:orange_terracotta
setblock 142 140 375 minecraft:white_concrete
fill 142 140 376 142 140 382 minecraft:orange_terracotta
setblock 142 140 383 minecraft:white_concrete
fill 142 140 384 142 140 390 minecraft:orange_terracotta
setblock 142 140 391 minecraft:white_concrete
fill 142 140 392 142 140 398 minecraft:orange_terracotta
setblock 142 140 399 minecraft:white_concrete
fill 142 140 400 142 140 406 minecraft:orange_terracotta
setblock 142 140 407 minecraft:white_concrete
fill 142 140 408 146 140 410 minecraft:orange_terracotta
fill 143 140 370 143 140 373 minecraft:orange_terracotta
setblock 143 140 374 minecraft:white_concrete
fill 143 140 375 143 140 381 minecraft:orange_terracotta
setblock 143 140 382 minecraft:white_concrete
fill 143 140 383 143 140 389 minecraft:orange_terracotta
setblock 143 140 390 minecraft:white_concrete
fill 143 140 391 143 140 397 minecraft:orange_terracotta
setblock 143 140 398 minecraft:white_concrete
fill 143 140 399 143 140 405 minecraft:orange_terracotta
setblock 143 140 406 minecraft:white_concrete
fill 143 140 407 149 140 407 minecraft:orange_terracotta
fill 144 140 370 144 140 372 minecraft:orange_terracotta
setblock 144 140 373 minecraft:white_concrete
fill 144 140 374 144 140 380 minecraft:orange_terracotta
setblock 144 140 381 minecraft:white_concrete
fill 144 140 382 144 140 388 minecraft:orange_terracotta
setblock 144 140 389 minecraft:white_concrete
fill 144 140 390 144 140 396 minecraft:orange_terracotta
setblock 144 140 397 minecraft:white_concrete
fill 144 140 398 144 140 404 minecraft:orange_terracotta
setblock 144 140 405 minecraft:white_concrete
fill 144 140 406 150 140 406 minecraft:orange_terracotta
fill 145 140 370 145 140 371 minecraft:orange_terracotta
setblock 145 140 372 minecraft:white_concrete
fill 145 140 373 145 140 379 minecraft:orange_terracotta
setblock 145 140 380 minecraft:white_concrete
fill 145 140 381 145 140 387 minecraft:orange_terracotta
setblock 145 140 388 minecraft:white_concrete
fill 145 140 389 145 140 395 minecraft:orange_terracotta
setblock 145 140 396 minecraft:white_concrete
fill 145 140 397 145 140 403 minecraft:orange_terracotta
setblock 145 140 404 minecraft:white_concrete
fill 145 140 405 151 140 405 minecraft:orange_terracotta
setblock 146 140 370 minecraft:orange_terracotta
setblock 146 140 371 minecraft:white_concrete
fill 146 140 372 146 140 378 minecraft:orange_terracotta
setblock 146 140 379 minecraft:white_concrete
fill 146 140 380 146 140 386 minecraft:orange_terracotta
setblock 146 140 387 minecraft:white_concrete
fill 146 140 388 146 140 394 minecraft:orange_terracotta
setblock 146 140 395 minecraft:white_concrete
fill 146 140 396 146 140 402 minecraft:orange_terracotta
setblock 146 140 403 minecraft:white_concrete
fill 146 140 404 152 140 404 minecraft:orange_terracotta
setblock 147 140 370 minecraft:white_concrete
fill 147 140 371 147 140 377 minecraft:orange_terracotta
setblock 147 140 378 minecraft:white_concrete
fill 147 140 379 147 140 385 minecraft:orange_terracotta
setblock 147 140 386 minecraft:white_concrete
fill 147 140 387 147 140 393 minecraft:orange_terracotta
setblock 147 140 394 minecraft:white_concrete
fill 147 140 395 147 140 401 minecraft:orange_terracotta
setblock 147 140 402 minecraft:white_concrete
fill 147 140 403 153 140 403 minecraft:orange_terracotta
fill 147 140 408 147 140 409 minecraft:orange_terracotta
setblock 147 140 410 minecraft:white_concrete
fill 148 140 370 148 140 376 minecraft:orange_terracotta
setblock 148 140 377 minecraft:white_concrete
fill 148 140 378 148 140 384 minecraft:orange_terracotta
setblock 148 140 385 minecraft:white_concrete
fill 148 140 386 148 140 392 minecraft:orange_terracotta
setblock 148 140 393 minecraft:white_concrete
fill 148 140 394 148 140 400 minecraft:orange_terracotta
setblock 148 140 401 minecraft:white_concrete
fill 148 140 402 154 140 402 minecraft:orange_terracotta
setblock 148 140 408 minecraft:orange_terracotta
setblock 148 140 409 minecraft:white_concrete
fill 148 140 410 154 140 410 minecraft:orange_terracotta
fill 149 140 370 149 140 375 minecraft:orange_terracotta
setblock 149 140 376 minecraft:white_concrete
fill 149 140 377 149 140 383 minecraft:orange_terracotta
setblock 149 140 384 minecraft:white_concrete
fill 149 140 385 149 140 391 minecraft:orange_terracotta
setblock 149 140 392 minecraft:white_concrete
fill 149 140 393 149 140 399 minecraft:orange_terracotta
setblock 149 140 400 minecraft:white_concrete
fill 149 140 401 155 140 401 minecraft:orange_terracotta
setblock 149 140 408 minecraft:white_concrete
fill 149 140 409 155 140 409 minecraft:orange_terracotta
fill 150 140 370 150 140 374 minecraft:orange_terracotta
setblock 150 140 375 minecraft:white_concrete
fill 150 140 376 150 140 382 minecraft:orange_terracotta
setblock 150 140 383 minecraft:white_concrete
fill 150 140 384 150 140 390 minecraft:orange_terracotta
setblock 150 140 391 minecraft:white_concrete
fill 150 140 392 150 140 398 minecraft:orange_terracotta
setblock 150 140 399 minecraft:white_concrete
fill 150 140 400 156 140 400 minecraft:orange_terracotta
setblock 150 140 407 minecraft:white_concrete
fill 150 140 408 156 140 408 minecraft:orange_terracotta
fill 151 140 370 151 140 373 minecraft:orange_terracotta
setblock 151 140 374 minecraft:white_concrete
fill 151 140 375 151 140 381 minecraft:orange_terracotta
setblock 151 140 382 minecraft:white_concrete
fill 151 140 383 151 140 389 minecraft:orange_terracotta
setblock 151 140 390 minecraft:white_concrete
fill 151 140 391 151 140 397 minecraft:orange_terracotta
setblock 151 140 398 minecraft:white_concrete
fill 151 140 399 157 140 399 minecraft:orange_terracotta
fill 151 140 407 157 140 407 minecraft:orange_terracotta
fill 152 140 370 152 140 372 minecraft:orange_terracotta
setblock 152 140 373 minecraft:white_concrete
fill 152 140 374 152 140 380 minecraft:orange_terracotta
setblock 152 140 381 minecraft:white_concrete
fill 152 140 382 152 140 388 minecraft:orange_terracotta
setblock 152 140 389 minecraft:white_concrete
fill 152 140 390 152 140 396 minecraft:orange_terracotta
setblock 152 140 397 minecraft:white_concrete
fill 152 140 398 158 140 398 minecraft:orange_terracotta
setblock 152 140 405 minecraft:white_concrete
fill 152 140 406 158 140 406 minecraft:orange_terracotta
fill 153 140 370 153 140 371 minecraft:orange_terracotta
setblock 153 140 372 minecraft:white_concrete
fill 153 140 373 153 140 379 minecraft:orange_terracotta
setblock 153 140 380 minecraft:white_concrete
fill 153 140 381 153 140 387 minecraft:orange_terracotta
setblock 153 140 388 minecraft:white_concrete
fill 153 140 389 153 140 395 minecraft:orange_terracotta
setblock 153 140 396 minecraft:white_concrete
fill 153 140 397 159 140 397 minecraft:orange_terracotta
setblock 153 140 404 minecraft:white_concrete
fill 153 140 405 159 140 405 minecraft:orange_terracotta
setblock 154 140 370 minecraft:orange_terracotta
setblock 154 140 371 minecraft:white_concrete
fill 154 140 372 154 140 378 minecraft:orange_terracotta
setblock 154 140 379 minecraft:white_concrete
fill 154 140 380 154 140 386 minecraft:orange_terracotta
setblock 154 140 387 minecraft:white_concrete
fill 154 140 388 154 140 394 minecraft:orange_terracotta
setblock 154 140 395 minecraft:white_concrete
fill 154 140 396 158 140 396 minecraft:orange_terracotta
setblock 154 140 403 minecraft:white_concrete
fill 154 140 404 160 140 404 minecraft:orange_terracotta
setblock 155 140 370 minecraft:white_concrete
fill 155 140 371 155 140 377 minecraft:orange_terracotta
setblock 155 140 378 minecraft:white_concrete
fill 155 140 379 155 140 385 minecraft:orange_terracotta
setblock 155 140 386 minecraft:white_concrete
fill 155 140 387 155 140 393 minecraft:orange_terracotta
setblock 155 140 394 minecraft:white_concrete
fill 155 140 395 157 140 395 minecraft:orange_terracotta
setblock 155 140 402 minecraft:white_concrete
fill 155 140 403 161 140 403 minecraft:orange_terracotta
setblock 155 140 410 minecraft:white_concrete
fill 156 140 370 156 140 376 minecraft:orange_terracotta
setblock 156 140 377 minecraft:white_concrete
fill 156 140 378 156 140 384 minecraft:orange_terracotta
setblock 156 140 385 minecraft:white_concrete
fill 156 140 386 156 140 392 minecraft:orange_terracotta
setblock 156 140 393 minecraft:white_concrete
setblock 156 140 394 minecraft:orange_terracotta
setblock 156 140 401 minecraft:white_concrete
fill 156 140 402 162 140 402 minecraft:orange_terracotta
setblock 156 140 409 minecraft:white_concrete
fill 156 140 410 162 140 410 minecraft:orange_terracotta
fill 157 140 370 157 140 375 minecraft:orange_terracotta
setblock 157 140 376 minecraft:white_concrete
fill 157 140 377 157 140 383 minecraft:orange_terracotta
setblock 157 140 384 minecraft:white_concrete
fill 157 140 385 157 140 391 minecraft:orange_terracotta
fill 157 140 392 157 141 394 minecraft:orange_concrete
setblock 157 140 400 minecraft:white_concrete
fill 157 140 401 163 140 401 minecraft:orange_terracotta
setblock 157 140 408 minecraft:white_concrete
fill 157 140 409 163 140 409 minecraft:orange_terracotta
fill 158 140 370 158 140 374 minecraft:orange_terracotta
setblock 158 140 375 minecraft:white_concrete
fill 158 140 376 158 140 382 minecraft:orange_terracotta
setblock 158 140 383 minecraft:white_concrete
fill 158 140 384 158 140 390 minecraft:orange_terracotta
fill 158 140 391 158 141 391 minecraft:orange_concrete
fill 158 140 395 158 141 395 minecraft:orange_concrete
setblock 158 140 399 minecraft:white_concrete
fill 158 140 400 164 140 400 minecraft:orange_terracotta
setblock 158 140 407 minecraft:white_concrete
fill 158 140 408 164 140 408 minecraft:orange_terracotta
fill 159 140 370 159 140 373 minecraft:orange_terracotta
setblock 159 140 374 minecraft:white_concrete
fill 159 140 375 159 140 381 minecraft:orange_terracotta
setblock 159 140 382 minecraft:white_concrete
fill 159 140 383 159 140 389 minecraft:orange_terracotta
fill 159 140 390 161 141 390 minecraft:orange_concrete
fill 159 140 396 161 141 396 minecraft:orange_concrete
setblock 159 140 398 minecraft:white_concrete
fill 159 140 399 165 140 399 minecraft:orange_terracotta
setblock 159 140 406 minecraft:white_concrete
fill 159 140 407 165 140 407 minecraft:orange_terracotta
fill 160 140 370 160 140 372 minecraft:orange_terracotta
setblock 160 140 373 minecraft:white_concrete
fill 160 140 374 160 140 380 minecraft:orange_terracotta
setblock 160 140 381 minecraft:white_concrete
fill 160 140 382 160 140 388 minecraft:orange_terracotta
setblock 160 140 389 minecraft:white_concrete
setblock 160 140 397 minecraft:white_concrete
fill 160 140 398 166 140 398 minecraft:orange_terracotta
setblock 160 140 405 minecraft:white_concrete
fill 160 140 406 166 140 406 minecraft:orange_terracotta
fill 161 140 370 161 140 371 minecraft:orange_terracotta
setblock 161 140 372 minecraft:white_concrete
fill 161 140 373 161 140 379 minecraft:orange_terracotta
setblock 161 140 380 minecraft:white_concrete
fill 161 140 381 161 140 387 minecraft:orange_terracotta
setblock 161 140 388 minecraft:white_concrete
fill 161 140 389 167 140 389 minecraft:orange_terracotta
fill 161 140 397 167 140 397 minecraft:orange_terracotta
setblock 161 140 404 minecraft:white_concrete
fill 161 140 405 167 140 405 minecraft:orange_terracotta
setblock 162 140 370 minecraft:orange_terracotta
setblock 162 140 371 minecraft:white_concrete
fill 162 140 372 162 140 378 minecraft:orange_terracotta
setblock 162 140 379 minecraft:white_concrete
fill 162 140 380 162 140 386 minecraft:orange_terracotta
setblock 162 140 387 minecraft:white_concrete
fill 162 140 388 168 140 388 minecraft:orange_terracotta
fill 162 140 390 166 140 390 minecraft:orange_terracotta
fill 162 140 391 162 141 391 minecraft:orange_concrete
fill 162 140 395 162 141 395 minecraft:orange_concrete
fill 162 140 396 168 140 396 minecraft:orange_terracotta
setblock 162 140 403 minecraft:white_concrete
fill 162 140 404 168 140 404 minecraft:orange_terracotta
setblock 163 140 370 minecraft:white_concrete
fill 163 140 371 163 140 377 minecraft:orange_terracotta
setblock 163 140 378 minecraft:white_concrete
fill 163 140 379 163 140 385 minecraft:orange_terracotta
setblock 163 140 386 minecraft:white_concrete
fill 163 140 387 169 140 387 minecraft:orange_terracotta
fill 163 140 391 165 140 391 minecraft:orange_terracotta
fill 163 140 392 163 141 394 minecraft:orange_concrete
fill 163 140 395 169 140 395 minecraft:orange_terracotta
setblock 163 140 402 minecraft:white_concrete
fill 163 140 403 169 140 403 minecraft:orange_terracotta
setblock 163 140 410 minecraft:white_concrete
fill 164 140 370 164 140 376 minecraft:orange_terracotta
setblock 164 140 377 minecraft:white_concrete
fill 164 140 378 164 140 384 minecraft:orange_terracotta
setblock 164 140 385 minecraft:white_concrete
fill 164 140 386 170 140 386 minecraft:orange_terracotta
setblock 164 140 392 minecraft:orange_terracotta
setblock 164 140 393 minecraft:white_concrete
fill 164 140 394 170 140 394 minecraft:orange_terracotta
setblock 164 140 401 minecraft:white_concrete
fill 164 140 402 170 140 402 minecraft:orange_terracotta
setblock 164 140 409 minecraft:white_concrete
fill 164 140 410 170 140 410 minecraft:orange_terracotta
fill 165 140 370 165 140 375 minecraft:orange_terracotta
setblock 165 140 376 minecraft:white_concrete
fill 165 140 377 165 140 383 minecraft:orange_terracotta
setblock 165 140 384 minecraft:white_concrete
fill 165 140 385 171 140 385 minecraft:orange_terracotta
fill 165 140 392 165 141 392 minecraft:white_concrete
fill 165 140 393 171 140 393 minecraft:orange_terracotta
setblock 165 140 400 minecraft:white_concrete
fill 165 140 401 171 140 401 minecraft:orange_terracotta
setblock 165 140 408 minecraft:white_concrete
fill 165 140 409 171 140 409 minecraft:orange_terracotta
fill 166 140 370 166 140 374 minecraft:orange_terracotta
setblock 166 140 375 minecraft:white_concrete
fill 166 140 376 166 140 382 minecraft:orange_terracotta
setblock 166 140 383 minecraft:white_concrete
fill 166 140 384 172 140 384 minecraft:orange_terracotta
setblock 166 140 391 minecraft:white_concrete
fill 166 140 392 172 140 392 minecraft:orange_terracotta
setblock 166 140 399 minecraft:white_concrete
fill 166 140 400 172 140 400 minecraft:orange_terracotta
setblock 166 140 407 minecraft:white_concrete
fill 166 140 408 172 140 408 minecraft:orange_terracotta
fill 167 140 370 167 140 373 minecraft:orange_terracotta
setblock 167 140 374 minecraft:white_concrete
fill 167 140 375 167 140 381 minecraft:orange_terracotta
setblock 167 140 382 minecraft:white_concrete
fill 167 140 383 173 140 383 minecraft:orange_terracotta
setblock 167 140 390 minecraft:white_concrete
fill 167 140 391 173 140 391 minecraft:orange_terracotta
setblock 167 140 398 minecraft:white_concrete
fill 167 140 399 173 140 399 minecraft:orange_terracotta
setblock 167 140 406 minecraft:white_concrete
fill 167 140 407 173 140 407 minecraft:orange_terracotta
fill 168 140 370 168 140 372 minecraft:orange_terracotta
setblock 168 140 373 minecraft:white_concrete
fill 168 140 374 168 140 380 minecraft:orange_terracotta
setblock 168 140 381 minecraft:white_concrete
fill 168 140 382 174 140 382 minecraft:orange_terracotta
setblock 168 140 389 minecraft:white_concrete
fill 168 140 390 174 140 390 minecraft:orange_terracotta
setblock 168 140 397 minecraft:white_concrete
fill 168 140 398 174 140 398 minecraft:orange_terracotta
setblock 168 140 405 minecraft:white_concrete
fill 168 140 406 174 140 406 minecraft:orange_terracotta
fill 169 140 370 169 140 371 minecraft:orange_terracotta
setblock 169 140 372 minecraft:white_concrete
fill 169 140 373 169 140 379 minecraft:orange_terracotta
fill 169 140 381 175 140 381 minecraft:orange_terracotta
setblock 169 140 388 minecraft:white_concrete
fill 169 140 389 175 140 389 minecraft:orange_terracotta
setblock 169 140 396 minecraft:white_concrete
fill 169 140 397 175 140 397 minecraft:orange_terracotta
setblock 169 140 404 minecraft:white_concrete
fill 169 140 405 175 140 405 minecraft:orange_terracotta
setblock 170 140 370 minecraft:orange_terracotta
setblock 170 140 371 minecraft:white_concrete
fill 170 140 372 170 140 378 minecraft:orange_terracotta
setblock 170 140 379 minecraft:white_concrete
fill 170 140 380 176 140 380 minecraft:orange_terracotta
setblock 170 140 387 minecraft:white_concrete
fill 170 140 388 176 140 388 minecraft:orange_terracotta
setblock 170 140 395 minecraft:white_concrete
fill 170 140 396 176 140 396 minecraft:orange_terracotta
setblock 170 140 403 minecraft:white_concrete
fill 170 140 404 176 140 404 minecraft:orange_terracotta
setblock 171 140 370 minecraft:white_concrete
fill 171 140 371 171 140 377 minecraft:orange_terracotta
setblock 171 140 378 minecraft:white_concrete
fill 171 140 379 177 140 379 minecraft:orange_terracotta
setblock 171 140 386 minecraft:white_concrete
fill 171 140 387 177 140 387 minecraft:orange_terracotta
setblock 171 140 394 minecraft:white_concrete
fill 171 140 395 177 140 395 minecraft:orange_terracotta
setblock 171 140 402 minecraft:white_concrete
fill 171 140 403 177 140 403 minecraft:orange_terracotta
setblock 171 140 410 minecraft:white_concrete
fill 172 140 370 172 140 376 minecraft:orange_terracotta
setblock 172 140 377 minecraft:white_concrete
fill 172 140 378 178 140 378 minecraft:orange_terracotta
setblock 172 140 385 minecraft:white_concrete
fill 172 140 386 178 140 386 minecraft:orange_terracotta
setblock 172 140 393 minecraft:white_concrete
fill 172 140 394 178 140 394 minecraft:orange_terracotta
setblock 172 140 401 minecraft:white_concrete
fill 172 140 402 178 140 402 minecraft:orange_terracotta
setblock 172 140 409 minecraft:white_concrete
fill 172 140 410 178 140 410 minecraft:orange_terracotta
fill 173 140 370 173 140 375 minecraft:orange_terracotta
setblock 173 140 376 minecraft:white_concrete
fill 173 140 377 179 140 377 minecraft:orange_terracotta
setblock 173 140 384 minecraft:white_concrete
fill 173 140 385 179 140 385 minecraft:orange_terracotta
setblock 173 140 392 minecraft:white_concrete
fill 173 140 393 179 140 393 minecraft:orange_terracotta
setblock 173 140 400 minecraft:white_concrete
fill 173 140 401 179 140 401 minecraft:orange_terracotta
setblock 173 140 408 minecraft:white_concrete
fill 173 140 409 179 140 409 minecraft:orange_terracotta
fill 174 140 370 174 140 374 minecraft:orange_terracotta
setblock 174 140 375 minecraft:white_concrete
fill 174 140 376 180 140 376 minecraft:orange_terracotta
setblock 174 140 383 minecraft:white_concrete
fill 174 140 384 180 140 384 minecraft:orange_terracotta
setblock 174 140 391 minecraft:white_concrete
fill 174 140 392 180 140 392 minecraft:orange_terracotta
setblock 174 140 399 minecraft:white_concrete
fill 174 140 400 180 140 400 minecraft:orange_terracotta
setblock 174 140 407 minecraft:white_concrete
fill 174 140 408 180 140 408 minecraft:orange_terracotta
fill 175 140 370 175 140 373 minecraft:orange_terracotta
setblock 175 140 374 minecraft:white_concrete
fill 175 140 375 181 140 375 minecraft:orange_terracotta
setblock 175 140 382 minecraft:white_concrete
fill 175 140 383 181 140 383 minecraft:orange_terracotta
setblock 175 140 390 minecraft:white_concrete
fill 175 140 391 181 140 391 minecraft:orange_terracotta
setblock 175 140 398 minecraft:white_concrete
fill 175 140 399 181 140 399 minecraft:orange_terracotta
setblock 175 140 406 minecraft:white_concrete
fill 175 140 407 181 140 407 minecraft:orange_terracotta
fill 176 140 370 176 140 372 minecraft:orange_terracotta
setblock 176 140 373 minecraft:white_concrete
fill 176 140 374 182 140 374 minecraft:orange_terracotta
setblock 176 140 381 minecraft:white_concrete
fill 176 140 382 182 140 382 minecraft:orange_terracotta
setblock 176 140 389 minecraft:white_concrete
fill 176 140 390 182 140 390 minecraft:orange_terracotta
setblock 176 140 397 minecraft:white_concrete
fill 176 140 398 182 140 398 minecraft:orange_terracotta
setblock 176 140 405 minecraft:white_concrete
fill 176 140 406 182 140 406 minecraft:orange_terracotta
fill 177 140 370 177 140 371 minecraft:orange_terracotta
setblock 177 140 372 minecraft:white_concrete
fill 177 140 373 182 140 373 minecraft:orange_terracotta
setblock 177 140 380 minecraft:white_concrete
fill 177 140 381 182 140 381 minecraft:orange_terracotta
setblock 177 140 388 minecraft:white_concrete
fill 177 140 389 182 140 389 minecraft:orange_terracotta
setblock 177 140 396 minecraft:white_concrete
fill 177 140 397 182 140 397 minecraft:orange_terracotta
setblock 177 140 404 minecraft:white_concrete
fill 177 140 405 182 140 405 minecraft:orange_terracotta
setblock 178 140 370 minecraft:orange_terracotta
setblock 178 140 371 minecraft:white_concrete
fill 178 140 372 182 140 372 minecraft:orange_terracotta
setblock 178 140 379 minecraft:white_concrete
fill 178 140 380 182 140 380 minecraft:orange_terracotta
setblock 178 140 387 minecraft:white_concrete
fill 178 140 388 182 140 388 minecraft:orange_terracotta
setblock 178 140 395 minecraft:white_concrete
fill 178 140 396 182 140 396 minecraft:orange_terracotta
setblock 178 140 403 minecraft:white_concrete
fill 178 140 404 182 140 404 minecraft:orange_terracotta
setblock 179 140 370 minecraft:white_concrete
fill 179 140 371 182 140 371 minecraft:orange_terracotta
setblock 179 140 378 minecraft:white_concrete
fill 179 140 379 182 140 379 minecraft:orange_terracotta
setblock 179 140 386 minecraft:white_concrete
fill 179 140 387 182 140 387 minecraft:orange_terracotta
setblock 179 140 394 minecraft:white_concrete
fill 179 140 395 182 140 395 minecraft:orange_terracotta
setblock 179 140 402 minecraft:white_concrete
fill 179 140 403 182 140 403 minecraft:orange_terracotta
setblock 179 140 410 minecraft:white_concrete
fill 180 140 370 182 140 370 minecraft:orange_terracotta
setblock 180 140 377 minecraft:white_concrete
fill 180 140 378 182 140 378 minecraft:orange_terracotta
setblock 180 140 385 minecraft:white_concrete
fill 180 140 386 182 140 386 minecraft:orange_terracotta
setblock 180 140 393 minecraft:white_concrete
fill 180 140 394 182 140 394 minecraft:orange_terracotta
setblock 180 140 401 minecraft:white_concrete
fill 180 140 402 182 140 402 minecraft:orange_terracotta
setblock 180 140 409 minecraft:white_concrete
fill 180 140 410 182 140 410 minecraft:orange_terracotta
setblock 181 140 376 minecraft:white_concrete
fill 181 140 377 182 140 377 minecraft:orange_terracotta
setblock 181 140 384 minecraft:white_concrete
fill 181 140 385 182 140 385 minecraft:orange_terracotta
setblock 181 140 392 minecraft:white_concrete
fill 181 140 393 182 140 393 minecraft:orange_terracotta
setblock 181 140 400 minecraft:white_concrete
fill 181 140 401 182 140 401 minecraft:orange_terracotta
setblock 181 140 408 minecraft:white_concrete
fill 181 140 409 182 140 409 minecraft:orange_terracotta
setblock 182 140 375 minecraft:white_concrete
setblock 182 140 376 minecraft:orange_terracotta
setblock 182 140 383 minecraft:white_concrete
setblock 182 140 384 minecraft:orange_terracotta
setblock 182 140 391 minecraft:white_concrete
setblock 182 140 392 minecraft:orange_terracotta
setblock 182 140 399 minecraft:white_concrete
setblock 182 140 400 minecraft:orange_terracotta
setblock 182 140 407 minecraft:white_concrete
setblock 182 140 408 minecraft:orange_terracotta
fill 165 141 388 165 141 391 minecraft:white_concrete
fill 165 141 393 165 141 398 minecraft:white_concrete
fill 165 142 388 165 147 390 minecraft:white_concrete
fill 165 142 391 165 145 395 minecraft:red_concrete
fill 165 142 396 165 147 398 minecraft:white_concrete
setblock 142 144 372 minecraft:white_concrete
fill 142 144 375 142 208 375 minecraft:white_concrete
setblock 142 144 379 minecraft:white_concrete
fill 142 144 382 142 208 382 minecraft:white_concrete
setblock 142 144 386 minecraft:white_concrete
fill 142 144 389 142 208 389 minecraft:white_concrete
setblock 142 144 393 minecraft:white_concrete
fill 142 144 396 142 208 396 minecraft:white_concrete
setblock 142 144 400 minecraft:white_concrete
fill 142 144 403 142 208 403 minecraft:white_concrete
setblock 142 144 407 minecraft:white_concrete
fill 142 144 410 142 208 410 minecraft:white_concrete
fill 144 144 370 144 208 370 minecraft:white_concrete
setblock 146 144 410 minecraft:white_concrete
setblock 147 144 370 minecraft:white_concrete
fill 149 144 410 149 208 410 minecraft:white_concrete
fill 151 144 370 151 208 370 minecraft:white_concrete
setblock 153 144 410 minecraft:white_concrete
setblock 154 144 370 minecraft:white_concrete
fill 156 144 410 156 208 410 minecraft:white_concrete
fill 158 144 370 158 208 370 minecraft:white_concrete
setblock 160 144 410 minecraft:white_concrete
setblock 161 144 370 minecraft:white_concrete
fill 163 144 410 163 208 410 minecraft:white_concrete
fill 165 144 370 165 208 370 minecraft:white_concrete
fill 166 144 393 171 144 394 minecraft:gray_concrete
fill 167 144 370 173 157 375 minecraft:white_concrete
setblock 167 144 410 minecraft:white_concrete
fill 170 144 410 170 208 410 minecraft:white_concrete
setblock 174 144 410 minecraft:white_concrete
setblock 175 144 370 minecraft:white_concrete
fill 177 144 410 177 208 410 minecraft:white_concrete
fill 179 144 370 179 208 370 minecraft:white_concrete
setblock 181 144 410 minecraft:white_concrete
setblock 182 144 370 minecraft:white_concrete
fill 182 144 374 182 208 374 minecraft:white_concrete
setblock 182 144 377 minecraft:white_concrete
fill 182 144 381 182 208 381 minecraft:white_concrete
setblock 182 144 384 minecraft:white_concrete
fill 182 144 388 182 208 388 minecraft:white_concrete
setblock 182 144 391 minecraft:white_concrete
fill 182 144 395 182 208 395 minecraft:white_concrete
setblock 182 144 398 minecraft:white_concrete
fill 182 144 402 182 208 402 minecraft:white_concrete
setblock 182 144 405 minecraft:white_concrete
fill 182 144 409 182 208 409 minecraft:white_concrete
setblock 142 145 373 minecraft:white_concrete
setblock 142 145 380 minecraft:white_concrete
setblock 142 145 387 minecraft:white_concrete
setblock 142 145 394 minecraft:white_concrete
setblock 142 145 401 minecraft:white_concrete
setblock 142 145 408 minecraft:white_concrete
setblock 146 145 370 minecraft:white_concrete
setblock 147 145 410 minecraft:white_concrete
setblock 153 145 370 minecraft:white_concrete
setblock 154 145 410 minecraft:white_concrete
setblock 160 145 370 minecraft:white_concrete
setblock 161 145 410 minecraft:white_concrete
setblock 168 145 410 minecraft:white_concrete
setblock 174 145 370 minecraft:white_concrete
setblock 175 145 410 minecraft:white_concrete
setblock 181 145 370 minecraft:white_concrete
setblock 182 145 376 minecraft:white_concrete
setblock 182 145 383 minecraft:white_concrete
setblock 182 145 390 minecraft:white_concrete
setblock 182 145 397 minecraft:white_concrete
setblock 182 145 404 minecraft:white_concrete
setblock 182 145 410 minecraft:white_concrete
setblock 142 146 374 minecraft:white_concrete
setblock 142 146 381 minecraft:white_concrete
setblock 142 146 388 minecraft:white_concrete
setblock 142 146 395 minecraft:white_concrete
setblock 142 146 402 minecraft:white_concrete
setblock 142 146 409 minecraft:white_concrete
setblock 145 146 370 minecraft:white_concrete
setblock 148 146 410 minecraft:white_concrete
setblock 152 146 370 minecraft:white_concrete
setblock 155 146 410 minecraft:white_concrete
setblock 159 146 370 minecraft:white_concrete
setblock 162 146 410 minecraft:white_concrete
fill 165 146 391 165 147 395 minecraft:white_concrete
setblock 166 146 370 minecraft:white_concrete
setblock 169 146 410 minecraft:white_concrete
setblock 176 146 410 minecraft:white_concrete
setblock 180 146 370 minecraft:white_concrete
setblock 182 146 375 minecraft:white_concrete
setblock 182 146 382 minecraft:white_concrete
setblock 182 146 389 minecraft:white_concrete
setblock 182 146 396 minecraft:white_concrete
setblock 182 146 403 minecraft:white_concrete
setblock 144 147 372 minecraft:light[level=14]
setblock 144 147 380 minecraft:light[level=14]
setblock 144 147 388 minecraft:light[level=14]
setblock 144 147 396 minecraft:light[level=14]
setblock 144 147 404 minecraft:light[level=14]
setblock 152 147 372 minecraft:light[level=14]
setblock 152 147 380 minecraft:light[level=14]
setblock 152 147 388 minecraft:light[level=14]
setblock 152 147 396 minecraft:light[level=14]
setblock 152 147 404 minecraft:light[level=14]
setblock 160 147 372 minecraft:light[level=14]
setblock 160 147 380 minecraft:light[level=14]
setblock 160 147 388 minecraft:light[level=14]
setblock 160 147 396 minecraft:light[level=14]
setblock 160 147 404 minecraft:light[level=14]
setblock 168 147 380 minecraft:light[level=14]
setblock 168 147 388 minecraft:light[level=14]
setblock 168 147 396 minecraft:light[level=14]
setblock 168 147 404 minecraft:light[level=14]
setblock 176 147 372 minecraft:light[level=14]
setblock 176 147 380 minecraft:light[level=14]
setblock 176 147 388 minecraft:light[level=14]
setblock 176 147 396 minecraft:light[level=14]
setblock 176 147 404 minecraft:light[level=14]
setblock 142 148 376 minecraft:white_concrete
setblock 142 148 383 minecraft:white_concrete
setblock 142 148 390 minecraft:white_concrete
setblock 142 148 397 minecraft:white_concrete
setblock 142 148 404 minecraft:white_concrete
setblock 143 148 370 minecraft:white_concrete
setblock 143 148 410 minecraft:white_concrete
setblock 150 148 370 minecraft:white_concrete
setblock 150 148 410 minecraft:white_concrete
setblock 157 148 370 minecraft:white_concrete
setblock 157 148 410 minecraft:white_concrete
setblock 164 148 370 minecraft:white_concrete
setblock 164 148 410 minecraft:white_concrete
setblock 171 148 410 minecraft:white_concrete
setblock 178 148 370 minecraft:white_concrete
setblock 178 148 410 minecraft:white_concrete
setblock 182 148 373 minecraft:white_concrete
setblock 182 148 380 minecraft:white_concrete
setblock 182 148 387 minecraft:white_concrete
setblock 182 148 394 minecraft:white_concrete
setblock 182 148 401 minecraft:white_concrete
setblock 182 148 408 minecraft:white_concrete
fill 142 149 370 142 150 370 minecraft:white_concrete
fill 142 149 377 142 150 377 minecraft:white_concrete
fill 142 149 384 142 150 384 minecraft:white_concrete
fill 142 149 391 142 150 391 minecraft:white_concrete
fill 142 149 398 142 150 398 minecraft:white_concrete
fill 142 149 405 142 150 405 minecraft:white_concrete
fill 144 149 410 144 150 410 minecraft:white_concrete
fill 149 149 370 149 150 370 minecraft:white_concrete
fill 151 149 410 151 150 410 minecraft:white_concrete
fill 156 149 370 156 150 370 minecraft:white_concrete
fill 157 149 403 161 150 407 minecraft:black_concrete
fill 158 149 410 158 150 410 minecraft:white_concrete
fill 159 149 408 159 149 409 minecraft:black_concrete
fill 163 149 370 163 150 370 minecraft:white_concrete
fill 165 149 410 165 150 410 minecraft:white_concrete
fill 172 149 410 172 150 410 minecraft:white_concrete
fill 177 149 370 177 150 370 minecraft:white_concrete
fill 179 149 410 179 150 410 minecraft:white_concrete
fill 182 149 372 182 150 372 minecraft:white_concrete
fill 182 149 379 182 150 379 minecraft:white_concrete
fill 182 149 386 182 150 386 minecraft:white_concrete
fill 182 149 393 182 150 393 minecraft:white_concrete
fill 182 149 400 182 150 400 minecraft:white_concrete
fill 182 149 407 182 150 407 minecraft:white_concrete
fill 142 150 371 142 150 374 minecraft:white_concrete
setblock 142 150 376 minecraft:white_concrete
fill 142 150 378 142 150 381 minecraft:white_concrete
setblock 142 150 383 minecraft:white_concrete
fill 142 150 385 142 150 388 minecraft:white_concrete
setblock 142 150 390 minecraft:white_concrete
fill 142 150 392 142 150 395 minecraft:white_concrete
setblock 142 150 397 minecraft:white_concrete
fill 142 150 399 142 150 402 minecraft:white_concrete
setblock 142 150 404 minecraft:white_concrete
fill 142 150 406 142 150 409 minecraft:white_concrete
setblock 143 150 370 minecraft:white_concrete
setblock 143 150 410 minecraft:white_concrete
fill 145 150 370 148 150 370 minecraft:white_concrete
fill 145 150 410 148 150 410 minecraft:white_concrete
setblock 150 150 370 minecraft:white_concrete
setblock 150 150 410 minecraft:white_concrete
fill 152 150 370 155 150 370 minecraft:white_concrete
fill 152 150 410 155 150 410 minecraft:white_concrete
setblock 157 150 370 minecraft:white_concrete
setblock 157 150 410 minecraft:white_concrete
fill 159 150 370 162 150 370 minecraft:white_concrete
fill 159 150 410 162 150 410 minecraft:white_concrete
setblock 164 150 370 minecraft:white_concrete
setblock 164 150 410 minecraft:white_concrete
setblock 166 150 370 minecraft:white_concrete
fill 166 150 410 169 150 410 minecraft:white_concrete
setblock 171 150 410 minecraft:white_concrete
fill 173 150 410 176 150 410 minecraft:white_concrete
fill 174 150 370 176 150 370 minecraft:white_concrete
setblock 178 150 370 minecraft:white_concrete
setblock 178 150 410 minecraft:white_concrete
fill 180 150 370 182 150 370 minecraft:white_concrete
fill 180 150 410 182 150 410 minecraft:white_concrete
setblock 182 150 371 minecraft:white_concrete
setblock 182 150 373 minecraft:white_concrete
fill 182 150 375 182 150 378 minecraft:white_concrete
setblock 182 150 380 minecraft:white_concrete
fill 182 150 382 182 150 385 minecraft:white_concrete
setblock 182 150 387 minecraft:white_concrete
fill 182 150 389 182 150 392 minecraft:white_concrete
setblock 182 150 394 minecraft:white_concrete
fill 182 150 396 182 150 399 minecraft:white_concrete
setblock 182 150 401 minecraft:white_concrete
fill 182 150 403 182 150 406 minecraft:white_concrete
setblock 182 150 408 minecraft:white_concrete
setblock 142 151 372 minecraft:white_concrete
setblock 142 151 379 minecraft:white_concrete
setblock 142 151 386 minecraft:white_concrete
setblock 142 151 393 minecraft:white_concrete
setblock 142 151 400 minecraft:white_concrete
setblock 142 151 407 minecraft:white_concrete
setblock 146 151 410 minecraft:white_concrete
setblock 147 151 370 minecraft:white_concrete
setblock 153 151 410 minecraft:white_concrete
setblock 154 151 370 minecraft:white_concrete
fill 159 151 405 159 156 405 minecraft:bone_block
setblock 160 151 410 minecraft:white_concrete
setblock 161 151 370 minecraft:white_concrete
setblock 167 151 410 minecraft:white_concrete
setblock 174 151 410 minecraft:white_concrete
setblock 175 151 370 minecraft:white_concrete
setblock 181 151 410 minecraft:white_concrete
setblock 182 151 370 minecraft:white_concrete
setblock 182 151 377 minecraft:white_concrete
setblock 182 151 384 minecraft:white_concrete
setblock 182 151 391 minecraft:white_concrete
setblock 182 151 398 minecraft:white_concrete
setblock 182 151 405 minecraft:white_concrete
setblock 142 152 373 minecraft:white_concrete
setblock 142 152 380 minecraft:white_concrete
setblock 142 152 387 minecraft:white_concrete
setblock 142 152 394 minecraft:white_concrete
setblock 142 152 401 minecraft:white_concrete
setblock 142 152 408 minecraft:white_concrete
setblock 146 152 370 minecraft:white_concrete
setblock 147 152 410 minecraft:white_concrete
setblock 153 152 370 minecraft:white_concrete
setblock 154 152 410 minecraft:white_concrete
fill 157 152 404 158 155 406 minecraft:bone_block
fill 158 152 403 160 155 403 minecraft:bone_block
fill 158 152 407 160 155 407 minecraft:bone_block
fill 159 152 404 161 155 404 minecraft:bone_block
fill 159 152 406 161 155 406 minecraft:bone_block
setblock 160 152 370 minecraft:white_concrete
fill 160 152 405 161 155 405 minecraft:bone_block
setblock 161 152 410 minecraft:white_concrete
fill 163 152 402 163 153 402 minecraft:purple_wool
setblock 168 152 410 minecraft:white_concrete
setblock 174 152 370 minecraft:white_concrete
setblock 175 152 410 minecraft:white_concrete
setblock 181 152 370 minecraft:white_concrete
setblock 182 152 376 minecraft:white_concrete
setblock 182 152 383 minecraft:white_concrete
setblock 182 152 390 minecraft:white_concrete
setblock 182 152 397 minecraft:white_concrete
setblock 182 152 404 minecraft:white_concrete
setblock 182 152 410 minecraft:white_concrete
setblock 142 153 374 minecraft:white_concrete
setblock 142 153 381 minecraft:white_concrete
setblock 142 153 388 minecraft:white_concrete
setblock 142 153 395 minecraft:white_concrete
setblock 142 153 402 minecraft:white_concrete
setblock 142 153 409 minecraft:white_concrete
setblock 145 153 370 minecraft:white_concrete
setblock 148 153 410 minecraft:white_concrete
setblock 152 153 370 minecraft:white_concrete
setblock 155 153 410 minecraft:white_concrete
setblock 159 153 370 minecraft:white_concrete
setblock 162 153 410 minecraft:white_concrete
setblock 166 153 370 minecraft:white_concrete
setblock 169 153 410 minecraft:white_concrete
setblock 176 153 410 minecraft:white_concrete
setblock 180 153 370 minecraft:white_concrete
setblock 182 153 375 minecraft:white_concrete
setblock 182 153 382 minecraft:white_concrete
setblock 182 153 389 minecraft:white_concrete
setblock 182 153 396 minecraft:white_concrete
setblock 182 153 403 minecraft:white_concrete
setblock 142 155 376 minecraft:white_concrete
setblock 142 155 383 minecraft:white_concrete
setblock 142 155 390 minecraft:white_concrete
setblock 142 155 397 minecraft:white_concrete
setblock 142 155 404 minecraft:white_concrete
setblock 143 155 370 minecraft:white_concrete
setblock 143 155 410 minecraft:white_concrete
setblock 144 155 372 minecraft:light[level=14]
setblock 144 155 380 minecraft:light[level=14]
setblock 144 155 388 minecraft:light[level=14]
setblock 144 155 396 minecraft:light[level=14]
setblock 144 155 404 minecraft:light[level=14]
setblock 150 155 370 minecraft:white_concrete
setblock 150 155 410 minecraft:white_concrete
setblock 152 155 372 minecraft:light[level=14]
setblock 152 155 380 minecraft:light[level=14]
setblock 152 155 388 minecraft:light[level=14]
setblock 152 155 396 minecraft:light[level=14]
setblock 152 155 404 minecraft:light[level=14]
setblock 157 155 370 minecraft:white_concrete
setblock 157 155 410 minecraft:white_concrete
setblock 160 155 372 minecraft:light[level=14]
setblock 160 155 380 minecraft:light[level=14]
setblock 160 155 388 minecraft:light[level=14]
setblock 160 155 396 minecraft:light[level=14]
setblock 164 155 370 minecraft:white_concrete
setblock 164 155 410 minecraft:white_concrete
setblock 168 155 380 minecraft:light[level=14]
setblock 168 155 388 minecraft:light[level=14]
setblock 168 155 396 minecraft:light[level=14]
setblock 168 155 404 minecraft:light[level=14]
setblock 171 155 410 minecraft:white_concrete
setblock 176 155 372 minecraft:light[level=14]
setblock 176 155 380 minecraft:light[level=14]
setblock 176 155 388 minecraft:light[level=14]
setblock 176 155 396 minecraft:light[level=14]
setblock 176 155 404 minecraft:light[level=14]
setblock 178 155 370 minecraft:white_concrete
setblock 178 155 410 minecraft:white_concrete
setblock 182 155 373 minecraft:white_concrete
setblock 182 155 380 minecraft:white_concrete
setblock 182 155 387 minecraft:white_concrete
setblock 182 155 394 minecraft:white_concrete
setblock 182 155 401 minecraft:white_concrete
setblock 182 155 408 minecraft:white_concrete
setblock 142 156 370 minecraft:white_concrete
setblock 142 156 377 minecraft:white_concrete
setblock 142 156 384 minecraft:white_concrete
setblock 142 156 391 minecraft:white_concrete
setblock 142 156 398 minecraft:white_concrete
setblock 142 156 405 minecraft:white_concrete
setblock 144 156 410 minecraft:white_concrete
setblock 149 156 370 minecraft:white_concrete
setblock 151 156 410 minecraft:white_concrete
setblock 156 156 370 minecraft:white_concrete
setblock 158 156 410 minecraft:white_concrete
setblock 163 156 370 minecraft:white_concrete
setblock 165 156 410 minecraft:white_concrete
setblock 172 156 410 minecraft:white_concrete
setblock 177 156 370 minecraft:white_concrete
setblock 179 156 410 minecraft:white_concrete
setblock 182 156 372 minecraft:white_concrete
setblock 182 156 379 minecraft:white_concrete
setblock 182 156 386 minecraft:white_concrete
setblock 182 156 393 minecraft:white_concrete
setblock 182 156 400 minecraft:white_concrete
setblock 182 156 407 minecraft:white_concrete
setblock 142 157 371 minecraft:white_concrete
setblock 142 157 378 minecraft:white_concrete
setblock 142 157 385 minecraft:white_concrete
setblock 142 157 392 minecraft:white_concrete
setblock 142 157 399 minecraft:white_concrete
setblock 142 157 406 minecraft:white_concrete
setblock 145 157 410 minecraft:white_concrete
setblock 148 157 370 minecraft:white_concrete
setblock 152 157 410 minecraft:white_concrete
setblock 155 157 370 minecraft:white_concrete
setblock 159 157 410 minecraft:white_concrete
setblock 162 157 370 minecraft:white_concrete
setblock 166 157 410 minecraft:white_concrete
setblock 173 157 410 minecraft:white_concrete
setblock 176 157 370 minecraft:white_concrete
setblock 180 157 410 minecraft:white_concrete
setblock 182 157 371 minecraft:white_concrete
setblock 182 157 378 minecraft:white_concrete
setblock 182 157 385 minecraft:white_concrete
setblock 182 157 392 minecraft:white_concrete
setblock 182 157 399 minecraft:white_concrete
setblock 182 157 406 minecraft:white_concrete
setblock 142 158 372 minecraft:white_concrete
setblock 142 158 379 minecraft:white_concrete
setblock 142 158 386 minecraft:white_concrete
setblock 142 158 393 minecraft:white_concrete
setblock 142 158 400 minecraft:white_concrete
setblock 142 158 407 minecraft:white_concrete
setblock 146 158 410 minecraft:white_concrete
setblock 147 158 370 minecraft:white_concrete
setblock 153 158 410 minecraft:white_concrete
setblock 154 158 370 minecraft:white_concrete
setblock 160 158 410 minecraft:white_concrete
setblock 161 158 370 minecraft:white_concrete
setblock 167 158 410 minecraft:white_concrete
setblock 168 158 370 minecraft:white_concrete
fill 168 158 371 172 158 374 minecraft:red_concrete
fill 172 158 370 172 208 370 minecraft:white_concrete
setblock 174 158 410 minecraft:white_concrete
setblock 175 158 370 minecraft:white_concrete
setblock 181 158 410 minecraft:white_concrete
setblock 182 158 370 minecraft:white_concrete
setblock 182 158 377 minecraft:white_concrete
setblock 182 158 384 minecraft:white_concrete
setblock 182 158 391 minecraft:white_concrete
setblock 182 158 398 minecraft:white_concrete
setblock 182 158 405 minecraft:white_concrete
fill 142 159 373 142 160 373 minecraft:white_concrete
fill 142 159 380 142 160 380 minecraft:white_concrete
fill 142 159 387 142 160 387 minecraft:white_concrete
fill 142 159 394 142 160 394 minecraft:white_concrete
fill 142 159 401 142 160 401 minecraft:white_concrete
fill 142 159 408 142 160 408 minecraft:white_concrete
fill 146 159 370 146 160 370 minecraft:white_concrete
fill 147 159 410 147 160 410 minecraft:white_concrete
fill 153 159 370 153 160 370 minecraft:white_concrete
fill 154 159 410 154 160 410 minecraft:white_concrete
fill 160 159 370 160 160 370 minecraft:white_concrete
fill 161 159 410 161 160 410 minecraft:white_concrete
fill 167 159 370 167 160 370 minecraft:white_concrete
fill 168 159 410 168 160 410 minecraft:white_concrete
fill 169 159 372 171 159 373 minecraft:red_concrete
fill 174 159 370 174 160 370 minecraft:white_concrete
fill 175 159 410 175 160 410 minecraft:white_concrete
fill 181 159 370 181 160 370 minecraft:white_concrete
fill 182 159 376 182 160 376 minecraft:white_concrete
fill 182 159 383 182 160 383 minecraft:white_concrete
fill 182 159 390 182 160 390 minecraft:white_concrete
fill 182 159 397 182 160 397 minecraft:white_concrete
fill 182 159 404 182 160 404 minecraft:white_concrete
fill 182 159 410 182 160 410 minecraft:white_concrete
fill 142 160 370 142 160 372 minecraft:white_concrete
setblock 142 160 374 minecraft:white_concrete
fill 142 160 376 142 160 379 minecraft:white_concrete
setblock 142 160 381 minecraft:white_concrete
fill 142 160 383 142 160 386 minecraft:white_concrete
setblock 142 160 388 minecraft:white_concrete
fill 142 160 390 142 160 393 minecraft:white_concrete
setblock 142 160 395 minecraft:white_concrete
fill 142 160 397 142 160 400 minecraft:white_concrete
setblock 142 160 402 minecraft:white_concrete
fill 142 160 404 142 160 407 minecraft:white_concrete
setblock 142 160 409 minecraft:white_concrete
setblock 143 160 370 minecraft:white_concrete
fill 143 160 410 146 160 410 minecraft:white_concrete
setblock 145 160 370 minecraft:white_concrete
fill 147 160 370 150 160 370 minecraft:white_concrete
setblock 148 160 410 minecraft:white_concrete
fill 150 160 410 153 160 410 minecraft:white_concrete
setblock 152 160 370 minecraft:white_concrete
fill 154 160 370 157 160 370 minecraft:white_concrete
setblock 155 160 410 minecraft:white_concrete
fill 157 160 410 160 160 410 minecraft:white_concrete
setblock 159 160 370 minecraft:white_concrete
fill 161 160 370 164 160 370 minecraft:white_concrete
setblock 162 160 410 minecraft:white_concrete
fill 164 160 410 167 160 410 minecraft:white_concrete
setblock 166 160 370 minecraft:white_concrete
fill 168 160 370 171 160 370 minecraft:white_concrete
setblock 169 160 410 minecraft:white_concrete
fill 170 160 372 170 161 373 minecraft:red_concrete
fill 171 160 410 174 160 410 minecraft:white_concrete
setblock 173 160 370 minecraft:white_concrete
fill 175 160 370 178 160 370 minecraft:white_concrete
setblock 176 160 410 minecraft:white_concrete
fill 178 160 410 181 160 410 minecraft:white_concrete
setblock 180 160 370 minecraft:white_concrete
fill 182 160 370 182 160 373 minecraft:white_concrete
setblock 182 160 375 minecraft:white_concrete
fill 182 160 377 182 160 380 minecraft:white_concrete
setblock 182 160 382 minecraft:white_concrete
fill 182 160 384 182 160 387 minecraft:white_concrete
setblock 182 160 389 minecraft:white_concrete
fill 182 160 391 182 160 394 minecraft:white_concrete
setblock 182 160 396 minecraft:white_concrete
fill 182 160 398 182 160 401 minecraft:white_concrete
setblock 182 160 403 minecraft:white_concrete
fill 182 160 405 182 160 408 minecraft:white_concrete
fill 153 161 379 153 162 380 minecraft:white_wool
fill 169 161 371 169 161 374 minecraft:red_concrete
fill 170 161 371 171 161 371 minecraft:red_concrete
fill 170 161 374 171 161 374 minecraft:red_concrete
fill 171 161 372 171 161 373 minecraft:red_concrete
setblock 142 162 376 minecraft:white_concrete
setblock 142 162 383 minecraft:white_concrete
setblock 142 162 390 minecraft:white_concrete
setblock 142 162 397 minecraft:white_concrete
setblock 142 162 404 minecraft:white_concrete
setblock 143 162 370 minecraft:white_concrete
setblock 143 162 410 minecraft:white_concrete
setblock 150 162 370 minecraft:white_concrete
setblock 150 162 410 minecraft:white_concrete
setblock 157 162 370 minecraft:white_concrete
setblock 157 162 410 minecraft:white_concrete
fill 160 162 399 160 163 401 minecraft:white_wool
fill 161 162 399 161 163 400 minecraft:white_wool
setblock 164 162 370 minecraft:white_concrete
setblock 164 162 410 minecraft:white_concrete
setblock 171 162 370 minecraft:white_concrete
setblock 171 162 410 minecraft:white_concrete
setblock 178 162 370 minecraft:white_concrete
setblock 178 162 410 minecraft:white_concrete
setblock 182 162 373 minecraft:white_concrete
setblock 182 162 380 minecraft:white_concrete
setblock 182 162 387 minecraft:white_concrete
setblock 182 162 394 minecraft:white_concrete
setblock 182 162 401 minecraft:white_concrete
setblock 182 162 408 minecraft:white_concrete
setblock 142 163 370 minecraft:white_concrete
setblock 142 163 377 minecraft:white_concrete
setblock 142 163 384 minecraft:white_concrete
setblock 142 163 391 minecraft:white_concrete
setblock 142 163 398 minecraft:white_concrete
setblock 142 163 405 minecraft:white_concrete
setblock 144 163 372 minecraft:light[level=14]
setblock 144 163 380 minecraft:light[level=14]
setblock 144 163 388 minecraft:light[level=14]
setblock 144 163 396 minecraft:light[level=14]
setblock 144 163 404 minecraft:light[level=14]
setblock 144 163 410 minecraft:white_concrete
setblock 149 163 370 minecraft:white_concrete
setblock 151 163 410 minecraft:white_concrete
setblock 152 163 372 minecraft:light[level=14]
setblock 152 163 380 minecraft:light[level=14]
setblock 152 163 388 minecraft:light[level=14]
setblock 152 163 396 minecraft:light[level=14]
setblock 152 163 404 minecraft:light[level=14]
setblock 156 163 370 minecraft:white_concrete
setblock 158 163 410 minecraft:white_concrete
setblock 160 163 372 minecraft:light[level=14]
setblock 160 163 380 minecraft:light[level=14]
setblock 160 163 388 minecraft:light[level=14]
setblock 160 163 396 minecraft:light[level=14]
setblock 160 163 404 minecraft:light[level=14]
setblock 163 163 370 minecraft:white_concrete
setblock 165 163 410 minecraft:white_concrete
setblock 168 163 372 minecraft:light[level=14]
setblock 168 163 380 minecraft:light[level=14]
setblock 168 163 388 minecraft:light[level=14]
setblock 168 163 396 minecraft:light[level=14]
setblock 168 163 404 minecraft:light[level=14]
setblock 170 163 370 minecraft:white_concrete
setblock 172 163 410 minecraft:white_concrete
setblock 176 163 372 minecraft:light[level=14]
setblock 176 163 380 minecraft:light[level=14]
setblock 176 163 388 minecraft:light[level=14]
setblock 176 163 396 minecraft:light[level=14]
setblock 176 163 404 minecraft:light[level=14]
setblock 177 163 370 minecraft:white_concrete
setblock 179 163 410 minecraft:white_concrete
setblock 182 163 372 minecraft:white_concrete
setblock 182 163 379 minecraft:white_concrete
setblock 182 163 386 minecraft:white_concrete
setblock 182 163 393 minecraft:white_concrete
setblock 182 163 400 minecraft:white_concrete
setblock 182 163 407 minecraft:white_concrete
setblock 142 164 371 minecraft:white_concrete
setblock 142 164 378 minecraft:white_concrete
setblock 142 164 385 minecraft:white_concrete
setblock 142 164 392 minecraft:white_concrete
setblock 142 164 399 minecraft:white_concrete
setblock 142 164 406 minecraft:white_concrete
setblock 145 164 410 minecraft:white_concrete
setblock 148 164 370 minecraft:white_concrete
setblock 152 164 410 minecraft:white_concrete
setblock 155 164 370 minecraft:white_concrete
setblock 159 164 410 minecraft:white_concrete
setblock 162 164 370 minecraft:white_concrete
setblock 166 164 410 minecraft:white_concrete
setblock 169 164 370 minecraft:white_concrete
setblock 173 164 410 minecraft:white_concrete
setblock 176 164 370 minecraft:white_concrete
setblock 180 164 410 minecraft:white_concrete
setblock 182 164 371 minecraft:white_concrete
setblock 182 164 378 minecraft:white_concrete
setblock 182 164 385 minecraft:white_concrete
setblock 182 164 392 minecraft:white_concrete
setblock 182 164 399 minecraft:white_concrete
setblock 182 164 406 minecraft:white_concrete
setblock 142 165 372 minecraft:white_concrete
setblock 142 165 379 minecraft:white_concrete
setblock 142 165 386 minecraft:white_concrete
setblock 142 165 393 minecraft:white_concrete
setblock 142 165 400 minecraft:white_concrete
setblock 142 165 407 minecraft:white_concrete
setblock 146 165 410 minecraft:white_concrete
setblock 147 165 370 minecraft:white_concrete
setblock 153 165 410 minecraft:white_concrete
setblock 154 165 370 minecraft:white_concrete
setblock 160 165 410 minecraft:white_concrete
setblock 161 165 370 minecraft:white_concrete
setblock 167 165 410 minecraft:white_concrete
setblock 168 165 370 minecraft:white_concrete
setblock 174 165 410 minecraft:white_concrete
setblock 175 165 370 minecraft:white_concrete
setblock 181 165 410 minecraft:white_concrete
setblock 182 165 370 minecraft:white_concrete
setblock 182 165 377 minecraft:white_concrete
setblock 182 165 384 minecraft:white_concrete
setblock 182 165 391 minecraft:white_concrete
setblock 182 165 398 minecraft:white_concrete
setblock 182 165 405 minecraft:white_concrete
setblock 142 166 373 minecraft:white_concrete
setblock 142 166 380 minecraft:white_concrete
setblock 142 166 387 minecraft:white_concrete
setblock 142 166 394 minecraft:white_concrete
setblock 142 166 401 minecraft:white_concrete
setblock 142 166 408 minecraft:white_concrete
setblock 146 166 370 minecraft:white_concrete
setblock 147 166 410 minecraft:white_concrete
setblock 153 166 370 minecraft:white_concrete
setblock 154 166 410 minecraft:white_concrete
setblock 160 166 370 minecraft:white_concrete
setblock 161 166 410 minecraft:white_concrete
setblock 167 166 370 minecraft:white_concrete
setblock 168 166 410 minecraft:white_concrete
setblock 174 166 370 minecraft:white_concrete
setblock 175 166 410 minecraft:white_concrete
setblock 181 166 370 minecraft:white_concrete
setblock 182 166 376 minecraft:white_concrete
setblock 182 166 383 minecraft:white_concrete
setblock 182 166 390 minecraft:white_concrete
setblock 182 166 397 minecraft:white_concrete
setblock 182 166 404 minecraft:white_concrete
setblock 182 166 410 minecraft:white_concrete
setblock 142 167 374 minecraft:white_concrete
setblock 142 167 381 minecraft:white_concrete
setblock 142 167 388 minecraft:white_concrete
setblock 142 167 395 minecraft:white_concrete
setblock 142 167 402 minecraft:white_concrete
setblock 142 167 409 minecraft:white_concrete
setblock 145 167 370 minecraft:white_concrete
setblock 148 167 410 minecraft:white_concrete
setblock 152 167 370 minecraft:white_concrete
setblock 155 167 410 minecraft:white_concrete
setblock 159 167 370 minecraft:white_concrete
setblock 162 167 410 minecraft:white_concrete
setblock 166 167 370 minecraft:white_concrete
setblock 169 167 410 minecraft:white_concrete
setblock 173 167 370 minecraft:white_concrete
setblock 176 167 410 minecraft:white_concrete
setblock 180 167 370 minecraft:white_concrete
setblock 182 167 375 minecraft:white_concrete
setblock 182 167 382 minecraft:white_concrete
setblock 182 167 389 minecraft:white_concrete
setblock 182 167 396 minecraft:white_concrete
setblock 182 167 403 minecraft:white_concrete
fill 142 169 376 142 170 376 minecraft:white_concrete
fill 142 169 383 142 170 383 minecraft:white_concrete
fill 142 169 390 142 170 390 minecraft:white_concrete
fill 142 169 397 142 170 397 minecraft:white_concrete
fill 142 169 404 142 170 404 minecraft:white_concrete
fill 143 169 370 143 170 370 minecraft:white_concrete
fill 143 169 410 143 170 410 minecraft:white_concrete
fill 150 169 370 150 170 370 minecraft:white_concrete
fill 150 169 410 150 170 410 minecraft:white_concrete
fill 157 169 370 157 170 370 minecraft:white_concrete
fill 157 169 410 157 170 410 minecraft:white_concrete
fill 164 169 370 164 170 370 minecraft:white_concrete
fill 164 169 410 164 170 410 minecraft:white_concrete
fill 171 169 370 171 170 370 minecraft:white_concrete
fill 171 169 410 171 170 410 minecraft:white_concrete
fill 178 169 370 178 170 370 minecraft:white_concrete
fill 178 169 410 178 170 410 minecraft:white_concrete
fill 182 169 373 182 170 373 minecraft:white_concrete
fill 182 169 380 182 170 380 minecraft:white_concrete
fill 182 169 387 182 170 387 minecraft:white_concrete
fill 182 169 394 182 170 394 minecraft:white_concrete
fill 182 169 401 182 170 401 minecraft:white_concrete
fill 182 169 408 182 170 408 minecraft:white_concrete
fill 142 170 370 142 170 374 minecraft:white_concrete
fill 142 170 377 142 170 381 minecraft:white_concrete
fill 142 170 384 142 170 388 minecraft:white_concrete
fill 142 170 391 142 170 395 minecraft:white_concrete
fill 142 170 398 142 170 402 minecraft:white_concrete
fill 142 170 405 142 170 409 minecraft:white_concrete
fill 144 170 410 148 170 410 minecraft:white_concrete
fill 145 170 370 149 170 370 minecraft:white_concrete
fill 151 170 410 155 170 410 minecraft:white_concrete
fill 152 170 370 156 170 370 minecraft:white_concrete
fill 158 170 410 162 170 410 minecraft:white_concrete
fill 159 170 370 163 170 370 minecraft:white_concrete
fill 165 170 410 169 170 410 minecraft:white_concrete
fill 166 170 370 170 170 370 minecraft:white_concrete
fill 172 170 410 176 170 410 minecraft:white_concrete
fill 173 170 370 177 170 370 minecraft:white_concrete
fill 179 170 410 182 170 410 minecraft:white_concrete
fill 180 170 370 182 170 370 minecraft:white_concrete
fill 182 170 371 182 170 372 minecraft:white_concrete
fill 182 170 375 182 170 379 minecraft:white_concrete
fill 182 170 382 182 170 386 minecraft:white_concrete
fill 182 170 389 182 170 393 minecraft:white_concrete
fill 182 170 396 182 170 400 minecraft:white_concrete
fill 182 170 403 182 170 407 minecraft:white_concrete
setblock 142 171 371 minecraft:white_concrete
setblock 142 171 378 minecraft:white_concrete
setblock 142 171 385 minecraft:white_concrete
setblock 142 171 392 minecraft:white_concrete
setblock 142 171 399 minecraft:white_concrete
setblock 142 171 406 minecraft:white_concrete
setblock 144 171 372 minecraft:light[level=14]
setblock 144 171 380 minecraft:light[level=14]
setblock 144 171 388 minecraft:light[level=14]
setblock 144 171 396 minecraft:light[level=14]
setblock 144 171 404 minecraft:light[level=14]
setblock 145 171 410 minecraft:white_concrete
setblock 148 171 370 minecraft:white_concrete
setblock 152 171 372 minecraft:light[level=14]
setblock 152 171 380 minecraft:light[level=14]
setblock 152 171 388 minecraft:light[level=14]
setblock 152 171 396 minecraft:light[level=14]
setblock 152 171 404 minecraft:light[level=14]
setblock 152 171 410 minecraft:white_concrete
setblock 155 171 370 minecraft:white_concrete
setblock 159 171 410 minecraft:white_concrete
setblock 160 171 372 minecraft:light[level=14]
setblock 160 171 380 minecraft:light[level=14]
setblock 160 171 388 minecraft:light[level=14]
setblock 160 171 396 minecraft:light[level=14]
setblock 160 171 404 minecraft:light[level=14]
setblock 162 171 370 minecraft:white_concrete
setblock 166 171 410 minecraft:white_concrete
setblock 168 171 372 minecraft:light[level=14]
setblock 168 171 380 minecraft:light[level=14]
setblock 168 171 388 minecraft:light[level=14]
setblock 168 171 396 minecraft:light[level=14]
setblock 168 171 404 minecraft:light[level=14]
setblock 169 171 370 minecraft:white_concrete
setblock 173 171 410 minecraft:white_concrete
setblock 176 171 370 minecraft:white_concrete
setblock 176 171 372 minecraft:light[level=14]
setblock 176 171 380 minecraft:light[level=14]
setblock 176 171 388 minecraft:light[level=14]
setblock 176 171 396 minecraft:light[level=14]
setblock 176 171 404 minecraft:light[level=14]
setblock 180 171 410 minecraft:white_concrete
setblock 182 171 371 minecraft:white_concrete
setblock 182 171 378 minecraft:white_concrete
setblock 182 171 385 minecraft:white_concrete
setblock 182 171 392 minecraft:white_concrete
setblock 182 171 399 minecraft:white_concrete
setblock 182 171 406 minecraft:white_concrete
setblock 142 172 372 minecraft:white_concrete
setblock 142 172 379 minecraft:white_concrete
setblock 142 172 386 minecraft:white_concrete
setblock 142 172 393 minecraft:white_concrete
setblock 142 172 400 minecraft:white_concrete
setblock 142 172 407 minecraft:white_concrete
setblock 146 172 410 minecraft:white_concrete
setblock 147 172 370 minecraft:white_concrete
setblock 153 172 410 minecraft:white_concrete
setblock 154 172 370 minecraft:white_concrete
setblock 160 172 410 minecraft:white_concrete
setblock 161 172 370 minecraft:white_concrete
setblock 167 172 410 minecraft:white_concrete
setblock 168 172 370 minecraft:white_concrete
setblock 174 172 410 minecraft:white_concrete
setblock 175 172 370 minecraft:white_concrete
setblock 181 172 410 minecraft:white_concrete
setblock 182 172 370 minecraft:white_concrete
setblock 182 172 377 minecraft:white_concrete
setblock 182 172 384 minecraft:white_concrete
setblock 182 172 391 minecraft:white_concrete
setblock 182 172 398 minecraft:white_concrete
setblock 182 172 405 minecraft:white_concrete
setblock 142 173 373 minecraft:white_concrete
setblock 142 173 380 minecraft:white_concrete
setblock 142 173 387 minecraft:white_concrete
setblock 142 173 394 minecraft:white_concrete
setblock 142 173 401 minecraft:white_concrete
setblock 142 173 408 minecraft:white_concrete
setblock 146 173 370 minecraft:white_concrete
setblock 147 173 410 minecraft:white_concrete
setblock 153 173 370 minecraft:white_concrete
setblock 154 173 410 minecraft:white_concrete
setblock 160 173 370 minecraft:white_concrete
setblock 161 173 410 minecraft:white_concrete
setblock 167 173 370 minecraft:white_concrete
setblock 168 173 410 minecraft:white_concrete
setblock 174 173 370 minecraft:white_concrete
setblock 175 173 410 minecraft:white_concrete
setblock 181 173 370 minecraft:white_concrete
setblock 182 173 376 minecraft:white_concrete
setblock 182 173 383 minecraft:white_concrete
setblock 182 173 390 minecraft:white_concrete
setblock 182 173 397 minecraft:white_concrete
setblock 182 173 404 minecraft:white_concrete
setblock 182 173 410 minecraft:white_concrete
setblock 142 174 374 minecraft:white_concrete
setblock 142 174 381 minecraft:white_concrete
setblock 142 174 388 minecraft:white_concrete
setblock 142 174 395 minecraft:white_concrete
setblock 142 174 402 minecraft:white_concrete
setblock 142 174 409 minecraft:white_concrete
setblock 145 174 370 minecraft:white_concrete
setblock 148 174 410 minecraft:white_concrete
setblock 152 174 370 minecraft:white_concrete
setblock 155 174 410 minecraft:white_concrete
setblock 159 174 370 minecraft:white_concrete
setblock 162 174 410 minecraft:white_concrete
setblock 166 174 370 minecraft:white_concrete
setblock 169 174 410 minecraft:white_concrete
setblock 173 174 370 minecraft:white_concrete
setblock 176 174 410 minecraft:white_concrete
setblock 180 174 370 minecraft:white_concrete
setblock 182 174 375 minecraft:white_concrete
setblock 182 174 382 minecraft:white_concrete
setblock 182 174 389 minecraft:white_concrete
setblock 182 174 396 minecraft:white_concrete
setblock 182 174 403 minecraft:white_concrete
setblock 142 176 376 minecraft:white_concrete
setblock 142 176 383 minecraft:white_concrete
setblock 142 176 390 minecraft:white_concrete
setblock 142 176 397 minecraft:white_concrete
setblock 142 176 404 minecraft:white_concrete
setblock 143 176 370 minecraft:white_concrete
setblock 143 176 410 minecraft:white_concrete
setblock 150 176 370 minecraft:white_concrete
setblock 150 176 410 minecraft:white_concrete
setblock 157 176 370 minecraft:white_concrete
setblock 157 176 410 minecraft:white_concrete
setblock 164 176 370 minecraft:white_concrete
setblock 164 176 410 minecraft:white_concrete
setblock 171 176 370 minecraft:white_concrete
setblock 171 176 410 minecraft:white_concrete
setblock 178 176 370 minecraft:white_concrete
setblock 178 176 410 minecraft:white_concrete
setblock 182 176 373 minecraft:white_concrete
setblock 182 176 380 minecraft:white_concrete
setblock 182 176 387 minecraft:white_concrete
setblock 182 176 394 minecraft:white_concrete
setblock 182 176 401 minecraft:white_concrete
setblock 182 176 408 minecraft:white_concrete
setblock 142 177 370 minecraft:white_concrete
setblock 142 177 377 minecraft:white_concrete
setblock 142 177 384 minecraft:white_concrete
setblock 142 177 391 minecraft:white_concrete
setblock 142 177 398 minecraft:white_concrete
setblock 142 177 405 minecraft:white_concrete
setblock 144 177 410 minecraft:white_concrete
setblock 149 177 370 minecraft:white_concrete
setblock 151 177 410 minecraft:white_concrete
setblock 156 177 370 minecraft:white_concrete
setblock 158 177 410 minecraft:white_concrete
setblock 163 177 370 minecraft:white_concrete
setblock 165 177 410 minecraft:white_concrete
setblock 170 177 370 minecraft:white_concrete
setblock 172 177 410 minecraft:white_concrete
setblock 177 177 370 minecraft:white_concrete
setblock 179 177 410 minecraft:white_concrete
setblock 182 177 372 minecraft:white_concrete
setblock 182 177 379 minecraft:white_concrete
setblock 182 177 386 minecraft:white_concrete
setblock 182 177 393 minecraft:white_concrete
setblock 182 177 400 minecraft:white_concrete
setblock 182 177 407 minecraft:white_concrete
setblock 142 178 371 minecraft:white_concrete
setblock 142 178 378 minecraft:white_concrete
setblock 142 178 385 minecraft:white_concrete
setblock 142 178 392 minecraft:white_concrete
setblock 142 178 399 minecraft:white_concrete
setblock 142 178 406 minecraft:white_concrete
setblock 145 178 410 minecraft:white_concrete
setblock 148 178 370 minecraft:white_concrete
setblock 152 178 410 minecraft:white_concrete
setblock 155 178 370 minecraft:white_concrete
setblock 159 178 410 minecraft:white_concrete
setblock 162 178 370 minecraft:white_concrete
setblock 166 178 410 minecraft:white_concrete
setblock 169 178 370 minecraft:white_concrete
setblock 173 178 410 minecraft:white_concrete
setblock 176 178 370 minecraft:white_concrete
setblock 180 178 410 minecraft:white_concrete
setblock 182 178 371 minecraft:white_concrete
setblock 182 178 378 minecraft:white_concrete
setblock 182 178 385 minecraft:white_concrete
setblock 182 178 392 minecraft:white_concrete
setblock 182 178 399 minecraft:white_concrete
setblock 182 178 406 minecraft:white_concrete
fill 142 179 372 142 180 372 minecraft:white_concrete
fill 142 179 379 142 180 379 minecraft:white_concrete
fill 142 179 386 142 180 386 minecraft:white_concrete
fill 142 179 393 142 180 393 minecraft:white_concrete
fill 142 179 400 142 180 400 minecraft:white_concrete
fill 142 179 407 142 180 407 minecraft:white_concrete
setblock 144 179 372 minecraft:light[level=14]
setblock 144 179 380 minecraft:light[level=14]
setblock 144 179 388 minecraft:light[level=14]
setblock 144 179 396 minecraft:light[level=14]
setblock 144 179 404 minecraft:light[level=14]
fill 146 179 410 146 180 410 minecraft:white_concrete
fill 147 179 370 147 180 370 minecraft:white_concrete
setblock 152 179 372 minecraft:light[level=14]
setblock 152 179 380 minecraft:light[level=14]
setblock 152 179 388 minecraft:light[level=14]
setblock 152 179 396 minecraft:light[level=14]
setblock 152 179 404 minecraft:light[level=14]
fill 153 179 410 153 180 410 minecraft:white_concrete
fill 154 179 370 154 180 370 minecraft:white_concrete
setblock 160 179 372 minecraft:light[level=14]
setblock 160 179 380 minecraft:light[level=14]
setblock 160 179 388 minecraft:light[level=14]
setblock 160 179 396 minecraft:light[level=14]
setblock 160 179 404 minecraft:light[level=14]
fill 160 179 410 160 180 410 minecraft:white_concrete
fill 161 179 370 161 180 370 minecraft:white_concrete
fill 167 179 410 167 180 410 minecraft:white_concrete
fill 168 179 370 168 180 370 minecraft:white_concrete
setblock 168 179 372 minecraft:light[level=14]
setblock 168 179 380 minecraft:light[level=14]
setblock 168 179 388 minecraft:light[level=14]
setblock 168 179 396 minecraft:light[level=14]
setblock 168 179 404 minecraft:light[level=14]
fill 174 179 410 174 180 410 minecraft:white_concrete
fill 175 179 370 175 180 370 minecraft:white_concrete
setblock 176 179 372 minecraft:light[level=14]
setblock 176 179 380 minecraft:light[level=14]
setblock 176 179 388 minecraft:light[level=14]
setblock 176 179 396 minecraft:light[level=14]
setblock 176 179 404 minecraft:light[level=14]
fill 181 179 410 181 180 410 minecraft:white_concrete
fill 182 179 370 182 180 370 minecraft:white_concrete
fill 182 179 377 182 180 377 minecraft:white_concrete
fill 182 179 384 182 180 384 minecraft:white_concrete
fill 182 179 391 182 180 391 minecraft:white_concrete
fill 182 179 398 182 180 398 minecraft:white_concrete
fill 182 179 405 182 180 405 minecraft:white_concrete
fill 142 180 370 142 180 371 minecraft:white_concrete
fill 142 180 373 142 180 374 minecraft:white_concrete
fill 142 180 376 142 180 378 minecraft:white_concrete
fill 142 180 380 142 180 381 minecraft:white_concrete
fill 142 180 383 142 180 385 minecraft:white_concrete
fill 142 180 387 142 180 388 minecraft:white_concrete
fill 142 180 390 142 180 392 minecraft:white_concrete
fill 142 180 394 142 180 395 minecraft:white_concrete
fill 142 180 397 142 180 399 minecraft:white_concrete
fill 142 180 401 142 180 402 minecraft:white_concrete
fill 142 180 404 142 180 406 minecraft:white_concrete
fill 142 180 408 142 180 409 minecraft:white_concrete
setblock 143 180 370 minecraft:white_concrete
fill 143 180 410 145 180 410 minecraft:white_concrete
fill 145 180 370 146 180 370 minecraft:white_concrete
fill 147 180 410 148 180 410 minecraft:white_concrete
fill 148 180 370 150 180 370 minecraft:white_concrete
fill 150 180 410 152 180 410 minecraft:white_concrete
fill 152 180 370 153 180 370 minecraft:white_concrete
fill 154 180 410 155 180 410 minecraft:white_concrete
fill 155 180 370 157 180 370 minecraft:white_concrete
fill 157 180 410 159 180 410 minecraft:white_concrete
fill 159 180 370 160 180 370 minecraft:white_concrete
fill 161 180 410 162 180 410 minecraft:white_concrete
fill 162 180 370 164 180 370 minecraft:white_concrete
fill 164 180 410 166 180 410 minecraft:white_concrete
fill 166 180 370 167 180 370 minecraft:white_concrete
fill 168 180 379 169 181 380 minecraft:red_wool
fill 168 180 410 169 180 410 minecraft:white_concrete
fill 169 180 370 171 180 370 minecraft:white_concrete
fill 171 180 410 173 180 410 minecraft:white_concrete
fill 173 180 370 174 180 370 minecraft:white_concrete
fill 175 180 410 176 180 410 minecraft:white_concrete
fill 176 180 370 178 180 370 minecraft:white_concrete
fill 178 180 410 180 180 410 minecraft:white_concrete
fill 180 180 370 181 180 370 minecraft:white_concrete
fill 182 180 371 182 180 373 minecraft:white_concrete
fill 182 180 375 182 180 376 minecraft:white_concrete
fill 182 180 378 182 180 380 minecraft:white_concrete
fill 182 180 382 182 180 383 minecraft:white_concrete
fill 182 180 385 182 180 387 minecraft:white_concrete
fill 182 180 389 182 180 390 minecraft:white_concrete
fill 182 180 392 182 180 394 minecraft:white_concrete
fill 182 180 396 182 180 397 minecraft:white_concrete
fill 182 180 399 182 180 401 minecraft:white_concrete
fill 182 180 403 182 180 404 minecraft:white_concrete
fill 182 180 406 182 180 408 minecraft:white_concrete
setblock 182 180 410 minecraft:white_concrete
setblock 142 181 374 minecraft:white_concrete
setblock 142 181 381 minecraft:white_concrete
fill 142 181 385 144 182 385 minecraft:gray_concrete
setblock 142 181 388 minecraft:white_concrete
setblock 142 181 395 minecraft:white_concrete
setblock 142 181 402 minecraft:white_concrete
setblock 142 181 409 minecraft:white_concrete
setblock 145 181 370 minecraft:white_concrete
setblock 148 181 410 minecraft:white_concrete
setblock 152 181 370 minecraft:white_concrete
setblock 155 181 410 minecraft:white_concrete
setblock 159 181 370 minecraft:white_concrete
setblock 162 181 410 minecraft:white_concrete
setblock 166 181 370 minecraft:white_concrete
setblock 169 181 410 minecraft:white_concrete
setblock 173 181 370 minecraft:white_concrete
setblock 176 181 410 minecraft:white_concrete
setblock 180 181 370 minecraft:white_concrete
setblock 182 181 375 minecraft:white_concrete
setblock 182 181 382 minecraft:white_concrete
setblock 182 181 389 minecraft:white_concrete
setblock 182 181 396 minecraft:white_concrete
setblock 182 181 403 minecraft:white_concrete
fill 158 182 374 158 183 374 minecraft:red_wool
setblock 142 183 376 minecraft:white_concrete
setblock 142 183 383 minecraft:white_concrete
setblock 142 183 390 minecraft:white_concrete
setblock 142 183 397 minecraft:white_concrete
setblock 142 183 404 minecraft:white_concrete
setblock 143 183 370 minecraft:white_concrete
setblock 143 183 410 minecraft:white_concrete
setblock 150 183 370 minecraft:white_concrete
setblock 150 183 410 minecraft:white_concrete
setblock 157 183 370 minecraft:white_concrete
setblock 157 183 410 minecraft:white_concrete
setblock 164 183 370 minecraft:white_concrete
setblock 164 183 410 minecraft:white_concrete
setblock 171 183 370 minecraft:white_concrete
setblock 171 183 410 minecraft:white_concrete
setblock 178 183 370 minecraft:white_concrete
setblock 178 183 410 minecraft:white_concrete
setblock 182 183 373 minecraft:white_concrete
setblock 182 183 380 minecraft:white_concrete
setblock 182 183 387 minecraft:white_concrete
setblock 182 183 394 minecraft:white_concrete
setblock 182 183 401 minecraft:white_concrete
setblock 182 183 408 minecraft:white_concrete
setblock 142 184 370 minecraft:white_concrete
setblock 142 184 377 minecraft:white_concrete
setblock 142 184 384 minecraft:white_concrete
setblock 142 184 391 minecraft:white_concrete
setblock 142 184 398 minecraft:white_concrete
setblock 142 184 405 minecraft:white_concrete
setblock 144 184 410 minecraft:white_concrete
setblock 149 184 370 minecraft:white_concrete
setblock 151 184 410 minecraft:white_concrete
setblock 156 184 370 minecraft:white_concrete
setblock 158 184 410 minecraft:white_concrete
setblock 163 184 370 minecraft:white_concrete
setblock 165 184 410 minecraft:white_concrete
setblock 170 184 370 minecraft:white_concrete
setblock 172 184 410 minecraft:white_concrete
setblock 177 184 370 minecraft:white_concrete
setblock 179 184 410 minecraft:white_concrete
setblock 182 184 372 minecraft:white_concrete
setblock 182 184 379 minecraft:white_concrete
setblock 182 184 386 minecraft:white_concrete
setblock 182 184 393 minecraft:white_concrete
setblock 182 184 400 minecraft:white_concrete
setblock 182 184 407 minecraft:white_concrete
setblock 142 185 371 minecraft:white_concrete
setblock 142 185 378 minecraft:white_concrete
setblock 142 185 385 minecraft:white_concrete
setblock 142 185 392 minecraft:white_concrete
setblock 142 185 399 minecraft:white_concrete
setblock 142 185 406 minecraft:white_concrete
setblock 145 185 410 minecraft:white_concrete
setblock 148 185 370 minecraft:white_concrete
setblock 152 185 410 minecraft:white_concrete
setblock 155 185 370 minecraft:white_concrete
setblock 159 185 410 minecraft:white_concrete
setblock 162 185 370 minecraft:white_concrete
setblock 166 185 410 minecraft:white_concrete
setblock 169 185 370 minecraft:white_concrete
setblock 173 185 410 minecraft:white_concrete
setblock 176 185 370 minecraft:white_concrete
setblock 180 185 410 minecraft:white_concrete
setblock 182 185 371 minecraft:white_concrete
setblock 182 185 378 minecraft:white_concrete
setblock 182 185 385 minecraft:white_concrete
setblock 182 185 392 minecraft:white_concrete
setblock 182 185 399 minecraft:white_concrete
setblock 182 185 406 minecraft:white_concrete
setblock 142 186 372 minecraft:white_concrete
setblock 142 186 379 minecraft:white_concrete
setblock 142 186 386 minecraft:white_concrete
setblock 142 186 393 minecraft:white_concrete
setblock 142 186 400 minecraft:white_concrete
setblock 142 186 407 minecraft:white_concrete
setblock 146 186 410 minecraft:white_concrete
setblock 147 186 370 minecraft:white_concrete
setblock 153 186 410 minecraft:white_concrete
setblock 154 186 370 minecraft:white_concrete
setblock 160 186 410 minecraft:white_concrete
setblock 161 186 370 minecraft:white_concrete
setblock 167 186 410 minecraft:white_concrete
setblock 168 186 370 minecraft:white_concrete
setblock 174 186 410 minecraft:white_concrete
setblock 175 186 370 minecraft:white_concrete
setblock 181 186 410 minecraft:white_concrete
setblock 182 186 370 minecraft:white_concrete
setblock 182 186 377 minecraft:white_concrete
setblock 182 186 384 minecraft:white_concrete
setblock 182 186 391 minecraft:white_concrete
setblock 182 186 398 minecraft:white_concrete
setblock 182 186 405 minecraft:white_concrete
setblock 142 187 373 minecraft:white_concrete
setblock 142 187 380 minecraft:white_concrete
setblock 142 187 387 minecraft:white_concrete
setblock 142 187 394 minecraft:white_concrete
setblock 142 187 401 minecraft:white_concrete
setblock 142 187 408 minecraft:white_concrete
setblock 144 187 372 minecraft:light[level=14]
setblock 144 187 380 minecraft:light[level=14]
setblock 144 187 388 minecraft:light[level=14]
setblock 144 187 396 minecraft:light[level=14]
setblock 144 187 404 minecraft:light[level=14]
setblock 146 187 370 minecraft:white_concrete
setblock 147 187 410 minecraft:white_concrete
setblock 152 187 372 minecraft:light[level=14]
setblock 152 187 380 minecraft:light[level=14]
setblock 152 187 388 minecraft:light[level=14]
setblock 152 187 396 minecraft:light[level=14]
setblock 152 187 404 minecraft:light[level=14]
setblock 153 187 370 minecraft:white_concrete
setblock 154 187 410 minecraft:white_concrete
setblock 160 187 370 minecraft:white_concrete
setblock 160 187 372 minecraft:light[level=14]
setblock 160 187 380 minecraft:light[level=14]
setblock 160 187 388 minecraft:light[level=14]
setblock 160 187 396 minecraft:light[level=14]
setblock 160 187 404 minecraft:light[level=14]
setblock 161 187 410 minecraft:white_concrete
setblock 167 187 370 minecraft:white_concrete
setblock 168 187 372 minecraft:light[level=14]
setblock 168 187 380 minecraft:light[level=14]
setblock 168 187 388 minecraft:light[level=14]
setblock 168 187 396 minecraft:light[level=14]
setblock 168 187 404 minecraft:light[level=14]
setblock 168 187 410 minecraft:white_concrete
setblock 174 187 370 minecraft:white_concrete
setblock 175 187 410 minecraft:white_concrete
setblock 176 187 372 minecraft:light[level=14]
setblock 176 187 380 minecraft:light[level=14]
setblock 176 187 388 minecraft:light[level=14]
setblock 176 187 396 minecraft:light[level=14]
setblock 176 187 404 minecraft:light[level=14]
setblock 181 187 370 minecraft:white_concrete
setblock 182 187 376 minecraft:white_concrete
setblock 182 187 383 minecraft:white_concrete
setblock 182 187 390 minecraft:white_concrete
setblock 182 187 397 minecraft:white_concrete
setblock 182 187 404 minecraft:white_concrete
setblock 182 187 410 minecraft:white_concrete
setblock 142 188 374 minecraft:white_concrete
setblock 142 188 381 minecraft:white_concrete
setblock 142 188 388 minecraft:white_concrete
setblock 142 188 395 minecraft:white_concrete
setblock 142 188 402 minecraft:white_concrete
setblock 142 188 409 minecraft:white_concrete
setblock 145 188 370 minecraft:white_concrete
setblock 148 188 410 minecraft:white_concrete
setblock 152 188 370 minecraft:white_concrete
setblock 155 188 410 minecraft:white_concrete
setblock 159 188 370 minecraft:white_concrete
setblock 162 188 410 minecraft:white_concrete
setblock 166 188 370 minecraft:white_concrete
setblock 169 188 410 minecraft:white_concrete
setblock 173 188 370 minecraft:white_concrete
setblock 176 188 410 minecraft:white_concrete
setblock 180 188 370 minecraft:white_concrete
setblock 182 188 375 minecraft:white_concrete
setblock 182 188 382 minecraft:white_concrete
setblock 182 188 389 minecraft:white_concrete
setblock 182 188 396 minecraft:white_concrete
setblock 182 188 403 minecraft:white_concrete
setblock 141 189 370 minecraft:purple_terracotta
fill 141 189 371 141 190 374 minecraft:black_concrete
fill 141 189 375 141 189 376 minecraft:purple_terracotta
setblock 141 189 384 minecraft:purple_terracotta
fill 141 189 385 141 192 387 minecraft:black_concrete
fill 141 189 389 141 192 390 minecraft:black_concrete
fill 141 189 391 141 189 392 minecraft:purple_terracotta
fill 141 189 393 141 190 396 minecraft:black_concrete
fill 143 189 369 147 190 369 minecraft:black_concrete
setblock 148 189 369 minecraft:purple_terracotta
fill 149 189 369 152 190 369 minecraft:black_concrete
fill 155 189 369 155 192 369 minecraft:black_concrete
fill 156 189 369 157 189 369 minecraft:purple_terracotta
fill 158 189 369 158 192 369 minecraft:black_concrete
fill 160 189 369 161 192 369 minecraft:black_concrete
setblock 162 189 369 minecraft:purple_terracotta
fill 177 189 369 177 190 369 minecraft:purple_terracotta
fill 178 189 369 178 192 369 minecraft:black_concrete
fill 182 189 369 182 192 369 minecraft:black_concrete
setblock 183 189 369 minecraft:purple_terracotta
fill 183 189 371 183 190 371 minecraft:purple_terracotta
fill 183 189 372 183 190 376 minecraft:black_concrete
fill 183 189 377 183 189 378 minecraft:purple_terracotta
fill 183 189 379 183 189 381 minecraft:black_concrete
fill 183 189 394 183 190 394 minecraft:purple_terracotta
fill 183 189 395 183 192 395 minecraft:black_concrete
fill 183 189 397 183 189 398 minecraft:black_concrete
setblock 183 189 399 minecraft:purple_terracotta
fill 183 189 400 183 189 403 minecraft:black_concrete
fill 183 189 404 183 189 405 minecraft:purple_terracotta
fill 183 189 406 183 192 406 minecraft:black_concrete
fill 183 189 407 183 189 408 minecraft:purple_terracotta
fill 141 190 370 141 193 370 minecraft:black_concrete
fill 141 190 375 141 192 376 minecraft:black_concrete
fill 141 190 384 141 192 384 minecraft:black_concrete
fill 141 190 391 141 192 392 minecraft:black_concrete
fill 141 190 398 141 192 401 minecraft:black_concrete
setblock 141 190 402 minecraft:purple_terracotta
fill 141 190 403 141 192 403 minecraft:black_concrete
fill 142 190 370 142 190 374 minecraft:white_concrete
fill 142 190 376 142 190 381 minecraft:white_concrete
fill 142 190 383 142 190 388 minecraft:white_concrete
fill 142 190 390 142 190 395 minecraft:white_concrete
fill 142 190 397 142 190 402 minecraft:white_concrete
fill 142 190 404 142 190 409 minecraft:white_concrete
setblock 143 190 370 minecraft:white_concrete
fill 143 190 410 148 190 410 minecraft:white_concrete
fill 145 190 370 150 190 370 minecraft:white_concrete
setblock 145 190 411 minecraft:purple_terracotta
fill 148 190 369 148 192 369 minecraft:black_concrete
fill 150 190 410 155 190 410 minecraft:white_concrete
fill 152 190 370 157 190 370 minecraft:white_concrete
setblock 154 190 369 minecraft:purple_terracotta
fill 156 190 369 157 192 369 minecraft:black_concrete
fill 157 190 410 162 190 410 minecraft:white_concrete
fill 159 190 370 164 190 370 minecraft:white_concrete
fill 159 190 411 166 192 411 minecraft:black_concrete
fill 162 190 369 162 192 369 minecraft:black_concrete
fill 164 190 410 169 190 410 minecraft:white_concrete
fill 166 190 370 171 190 370 minecraft:white_concrete
fill 167 190 369 168 190 369 minecraft:purple_terracotta
setblock 167 190 411 minecraft:purple_terracotta
fill 168 190 411 173 192 411 minecraft:black_concrete
fill 171 190 410 176 190 410 minecraft:white_concrete
fill 173 190 370 178 190 370 minecraft:white_concrete
fill 174 190 411 175 190 411 minecraft:purple_terracotta
fill 178 190 410 182 190 410 minecraft:white_concrete
fill 180 190 370 182 190 370 minecraft:white_concrete
setblock 181 190 369 minecraft:purple_terracotta
fill 182 190 371 182 190 373 minecraft:white_concrete
fill 182 190 375 182 190 380 minecraft:white_concrete
fill 182 190 382 182 190 387 minecraft:white_concrete
fill 182 190 389 182 190 394 minecraft:white_concrete
fill 182 190 396 182 190 401 minecraft:white_concrete
fill 182 190 403 182 190 408 minecraft:white_concrete
setblock 183 190 369 minecraft:black_concrete
fill 183 190 377 183 192 378 minecraft:black_concrete
setblock 183 190 379 minecraft:purple_terracotta
fill 183 190 380 183 192 381 minecraft:black_concrete
setblock 183 190 391 minecraft:purple_terracotta
setblock 183 190 397 minecraft:black_concrete
fill 183 190 398 183 191 398 minecraft:purple_terracotta
fill 183 190 399 183 192 401 minecraft:black_concrete
setblock 183 190 402 minecraft:purple_terracotta
fill 183 190 403 183 192 405 minecraft:black_concrete
fill 183 190 407 183 190 408 minecraft:black_concrete
setblock 183 190 410 minecraft:purple_terracotta
setblock 183 190 411 minecraft:black_concrete
fill 141 191 371 141 192 372 minecraft:black_concrete
fill 141 191 373 141 191 374 minecraft:purple_terracotta
fill 141 191 378 141 192 380 minecraft:black_concrete
setblock 141 191 381 minecraft:purple_terracotta
setblock 141 191 393 minecraft:purple_terracotta
fill 141 191 394 141 192 396 minecraft:black_concrete
setblock 141 191 397 minecraft:purple_terracotta
fill 141 191 402 141 192 402 minecraft:black_concrete
setblock 141 191 408 minecraft:purple_terracotta
setblock 142 191 370 minecraft:white_concrete
setblock 142 191 377 minecraft:white_concrete
setblock 142 191 384 minecraft:white_concrete
setblock 142 191 391 minecraft:white_concrete
setblock 142 191 398 minecraft:white_concrete
setblock 142 191 405 minecraft:white_concrete
fill 143 191 369 145 192 369 minecraft:black_concrete
setblock 144 191 410 minecraft:white_concrete
fill 145 191 411 146 192 411 minecraft:black_concrete
setblock 146 191 369 minecraft:purple_terracotta
fill 147 191 369 147 192 369 minecraft:black_concrete
setblock 147 191 411 minecraft:purple_terracotta
fill 149 191 369 149 193 369 minecraft:black_concrete
setblock 149 191 370 minecraft:white_concrete
setblock 150 191 369 minecraft:purple_terracotta
fill 151 191 369 152 192 369 minecraft:black_concrete
setblock 151 191 410 minecraft:white_concrete
fill 154 191 369 154 192 369 minecraft:black_concrete
setblock 156 191 370 minecraft:white_concrete
setblock 158 191 410 minecraft:white_concrete
setblock 159 191 369 minecraft:purple_terracotta
setblock 163 191 370 minecraft:white_concrete
setblock 164 191 369 minecraft:purple_terracotta
fill 165 191 369 168 192 369 minecraft:black_concrete
setblock 165 191 410 minecraft:white_concrete
fill 167 191 411 167 192 411 minecraft:black_concrete
setblock 170 191 370 minecraft:white_concrete
fill 171 191 369 173 192 369 minecraft:black_concrete
setblock 172 191 410 minecraft:white_concrete
setblock 174 191 369 minecraft:purple_terracotta
fill 174 191 411 175 192 411 minecraft:black_concrete
fill 175 191 369 177 192 369 minecraft:black_concrete
setblock 177 191 370 minecraft:white_concrete
setblock 179 191 410 minecraft:white_concrete
fill 181 191 369 181 193 369 minecraft:black_concrete
setblock 182 191 372 minecraft:white_concrete
setblock 182 191 379 minecraft:white_concrete
setblock 182 191 386 minecraft:white_concrete
setblock 182 191 393 minecraft:white_concrete
setblock 182 191 400 minecraft:white_concrete
setblock 182 191 407 minecraft:white_concrete
setblock 183 191 369 minecraft:purple_terracotta
fill 183 191 371 183 192 372 minecraft:black_concrete
setblock 183 191 373 minecraft:purple_terracotta
fill 183 191 374 183 192 374 minecraft:black_concrete
setblock 183 191 375 minecraft:purple_terracotta
fill 183 191 376 183 192 376 minecraft:black_concrete
fill 183 191 379 183 192 379 minecraft:black_concrete
setblock 183 191 382 minecraft:purple_terracotta
fill 183 191 391 183 192 391 minecraft:black_concrete
setblock 183 191 392 minecraft:purple_terracotta
fill 183 191 393 183 192 394 minecraft:black_concrete
setblock 183 191 397 minecraft:purple_terracotta
fill 183 191 402 183 192 402 minecraft:black_concrete
setblock 183 191 407 minecraft:purple_terracotta
fill 183 191 408 183 192 408 minecraft:black_concrete
fill 183 191 410 183 192 410 minecraft:black_concrete
setblock 183 191 411 minecraft:purple_terracotta
fill 141 192 373 141 192 374 minecraft:black_concrete
setblock 141 192 381 minecraft:black_concrete
setblock 141 192 393 minecraft:black_concrete
setblock 141 192 397 minecraft:black_concrete
setblock 141 192 408 minecraft:black_concrete
setblock 142 192 371 minecraft:white_concrete
setblock 142 192 378 minecraft:white_concrete
setblock 142 192 385 minecraft:white_concrete
setblock 142 192 392 minecraft:white_concrete
setblock 142 192 399 minecraft:white_concrete
setblock 142 192 406 minecraft:white_concrete
setblock 145 192 410 minecraft:white_concrete
fill 146 192 369 146 193 369 minecraft:black_concrete
setblock 147 192 411 minecraft:black_concrete
setblock 148 192 370 minecraft:white_concrete
setblock 150 192 369 minecraft:black_concrete
setblock 152 192 410 minecraft:white_concrete
setblock 155 192 370 minecraft:white_concrete
fill 157 192 408 157 204 408 minecraft:purple_wool
setblock 159 192 369 minecraft:black_concrete
setblock 159 192 410 minecraft:white_concrete
setblock 162 192 370 minecraft:white_concrete
fill 164 192 369 164 193 369 minecraft:black_concrete
setblock 166 192 410 minecraft:white_concrete
setblock 169 192 370 minecraft:white_concrete
setblock 173 192 410 minecraft:white_concrete
setblock 174 192 369 minecraft:black_concrete
setblock 176 192 370 minecraft:white_concrete
setblock 180 192 410 minecraft:white_concrete
setblock 182 192 371 minecraft:white_concrete
setblock 182 192 378 minecraft:white_concrete
setblock 182 192 385 minecraft:white_concrete
setblock 182 192 392 minecraft:white_concrete
setblock 182 192 399 minecraft:white_concrete
setblock 182 192 406 minecraft:white_concrete
setblock 183 192 369 minecraft:black_concrete
setblock 183 192 373 minecraft:black_concrete
setblock 183 192 375 minecraft:black_concrete
fill 183 192 382 183 193 382 minecraft:black_concrete
setblock 183 192 392 minecraft:black_concrete
fill 183 192 397 183 192 398 minecraft:black_concrete
setblock 183 192 407 minecraft:black_concrete
setblock 183 192 411 minecraft:black_concrete
fill 141 193 369 145 193 369 minecraft:purple_terracotta
fill 141 193 371 141 194 376 minecraft:purple_terracotta
fill 141 193 378 141 193 410 minecraft:purple_terracotta
setblock 142 193 372 minecraft:white_concrete
setblock 142 193 379 minecraft:white_concrete
setblock 142 193 386 minecraft:white_concrete
setblock 142 193 393 minecraft:white_concrete
setblock 142 193 400 minecraft:white_concrete
setblock 142 193 407 minecraft:white_concrete
fill 142 193 411 142 307 411 minecraft:purple_terracotta
setblock 143 193 411 minecraft:black_concrete
fill 144 193 411 151 193 411 minecraft:purple_terracotta
setblock 146 193 410 minecraft:white_concrete
fill 147 193 369 148 194 369 minecraft:purple_terracotta
setblock 147 193 370 minecraft:white_concrete
fill 150 193 369 163 307 369 minecraft:purple_terracotta
setblock 152 193 411 minecraft:black_concrete
setblock 153 193 410 minecraft:white_concrete
fill 153 193 411 154 194 411 minecraft:purple_terracotta
setblock 154 193 370 minecraft:white_concrete
fill 155 193 408 156 204 408 minecraft:purple_wool
setblock 155 193 411 minecraft:black_concrete
fill 156 193 411 160 307 411 minecraft:purple_terracotta
fill 158 193 408 159 204 408 minecraft:purple_wool
setblock 160 193 410 minecraft:white_concrete
setblock 161 193 370 minecraft:white_concrete
setblock 161 193 411 minecraft:black_concrete
fill 162 193 411 167 193 411 minecraft:purple_terracotta
fill 165 193 369 170 194 369 minecraft:purple_terracotta
setblock 167 193 410 minecraft:white_concrete
setblock 168 193 370 minecraft:white_concrete
fill 168 193 411 169 193 411 minecraft:black_concrete
fill 170 193 411 174 193 411 minecraft:purple_terracotta
setblock 171 193 369 minecraft:black_concrete
fill 172 193 369 180 193 369 minecraft:purple_terracotta
setblock 174 193 410 minecraft:white_concrete
setblock 175 193 370 minecraft:white_concrete
fill 175 193 411 176 193 411 minecraft:black_concrete
fill 177 193 411 178 307 411 minecraft:purple_terracotta
setblock 180 193 411 minecraft:black_concrete
setblock 181 193 410 minecraft:white_concrete
fill 181 193 411 183 307 411 minecraft:purple_terracotta
fill 182 193 369 183 193 369 minecraft:purple_terracotta
setblock 182 193 370 minecraft:white_concrete
setblock 182 193 377 minecraft:white_concrete
setblock 182 193 384 minecraft:white_concrete
setblock 182 193 391 minecraft:white_concrete
setblock 182 193 398 minecraft:white_concrete
setblock 182 193 405 minecraft:white_concrete
fill 183 193 370 183 193 381 minecraft:purple_terracotta
fill 183 193 383 183 193 397 minecraft:purple_terracotta
fill 183 193 398 183 193 399 minecraft:black_concrete
fill 183 193 400 183 193 403 minecraft:purple_terracotta
setblock 183 193 404 minecraft:black_concrete
fill 183 193 405 183 194 410 minecraft:purple_terracotta
fill 141 194 369 141 194 370 minecraft:purple_terracotta
fill 141 194 377 141 307 382 minecraft:purple_terracotta
setblock 141 194 383 minecraft:black_concrete
fill 141 194 384 141 194 390 minecraft:purple_terracotta
setblock 141 194 391 minecraft:black_concrete
fill 141 194 392 141 194 394 minecraft:purple_terracotta
setblock 141 194 395 minecraft:black_concrete
setblock 141 194 396 minecraft:purple_terracotta
setblock 141 194 397 minecraft:black_concrete
fill 141 194 398 141 194 401 minecraft:purple_terracotta
setblock 141 194 402 minecraft:black_concrete
fill 141 194 403 141 307 403 minecraft:purple_terracotta
setblock 141 194 404 minecraft:black_concrete
fill 141 194 405 141 307 411 minecraft:purple_terracotta
fill 142 194 369 144 194 369 minecraft:purple_terracotta
setblock 142 194 373 minecraft:white_concrete
fill 142 194 377 144 195 377 minecraft:gray_concrete
setblock 142 194 380 minecraft:white_concrete
setblock 142 194 387 minecraft:white_concrete
setblock 142 194 394 minecraft:white_concrete
setblock 142 194 401 minecraft:white_concrete
setblock 142 194 408 minecraft:white_concrete
fill 143 194 411 148 285 411 minecraft:purple_terracotta
setblock 145 194 369 minecraft:black_concrete
fill 146 194 369 146 307 369 minecraft:purple_terracotta
setblock 146 194 370 minecraft:white_concrete
setblock 147 194 410 minecraft:white_concrete
fill 149 194 369 149 219 369 minecraft:purple_terracotta
setblock 149 194 411 minecraft:black_concrete
fill 150 194 411 152 194 411 minecraft:purple_terracotta
setblock 153 194 370 minecraft:white_concrete
setblock 154 194 410 minecraft:white_concrete
fill 155 194 411 155 307 411 minecraft:purple_terracotta
setblock 160 194 370 minecraft:white_concrete
setblock 161 194 410 minecraft:white_concrete
fill 161 194 411 161 307 411 minecraft:purple_terracotta
setblock 162 194 411 minecraft:black_concrete
fill 163 194 411 163 307 411 minecraft:purple_terracotta
fill 164 194 369 164 307 369 minecraft:purple_terracotta
setblock 164 194 411 minecraft:black_concrete
fill 165 194 411 172 194 411 minecraft:purple_terracotta
setblock 167 194 370 minecraft:white_concrete
setblock 168 194 410 minecraft:white_concrete
fill 171 194 369 173 307 369 minecraft:purple_terracotta
setblock 173 194 411 minecraft:black_concrete
setblock 174 194 369 minecraft:black_concrete
setblock 174 194 370 minecraft:white_concrete
fill 174 194 411 176 307 411 minecraft:purple_terracotta
fill 175 194 369 181 194 369 minecraft:purple_terracotta
setblock 175 194 410 minecraft:white_concrete
fill 179 194 411 180 307 411 minecraft:purple_terracotta
setblock 181 194 370 minecraft:white_concrete
setblock 182 194 369 minecraft:black_concrete
setblock 182 194 376 minecraft:white_concrete
setblock 182 194 383 minecraft:white_concrete
setblock 182 194 390 minecraft:white_concrete
setblock 182 194 397 minecraft:white_concrete
setblock 182 194 404 minecraft:white_concrete
setblock 182 194 410 minecraft:white_concrete
fill 183 194 369 183 307 370 minecraft:purple_terracotta
setblock 183 194 371 minecraft:black_concrete
fill 183 194 372 183 194 380 minecraft:purple_terracotta
fill 183 194 381 183 195 381 minecraft:black_concrete
fill 183 194 382 183 307 390 minecraft:purple_terracotta
fill 183 194 391 183 194 392 minecraft:black_concrete
fill 183 194 393 183 307 399 minecraft:purple_terracotta
setblock 183 194 400 minecraft:black_concrete
fill 183 194 401 183 307 402 minecraft:purple_terracotta
setblock 183 194 403 minecraft:black_concrete
setblock 183 194 404 minecraft:purple_terracotta
fill 141 195 369 142 195 369 minecraft:black_concrete
fill 141 195 370 141 307 372 minecraft:purple_terracotta
setblock 141 195 373 minecraft:black_concrete
fill 141 195 374 141 307 376 minecraft:purple_terracotta
fill 141 195 383 141 307 384 minecraft:purple_terracotta
fill 141 195 385 141 195 386 minecraft:black_concrete
fill 141 195 387 141 307 392 minecraft:purple_terracotta
setblock 141 195 393 minecraft:black_concrete
fill 141 195 394 141 307 395 minecraft:purple_terracotta
setblock 141 195 396 minecraft:black_concrete
fill 141 195 397 141 307 397 minecraft:purple_terracotta
setblock 141 195 398 minecraft:black_concrete
fill 141 195 399 141 307 402 minecraft:purple_terracotta
fill 141 195 404 141 307 404 minecraft:purple_terracotta
setblock 142 195 374 minecraft:white_concrete
setblock 142 195 381 minecraft:white_concrete
setblock 142 195 388 minecraft:white_concrete
setblock 142 195 395 minecraft:white_concrete
setblock 142 195 402 minecraft:white_concrete
setblock 142 195 409 minecraft:white_concrete
fill 143 195 369 145 219 369 minecraft:purple_terracotta
setblock 144 195 372 minecraft:light[level=14]
setblock 144 195 380 minecraft:light[level=14]
setblock 144 195 388 minecraft:light[level=14]
setblock 144 195 396 minecraft:light[level=14]
setblock 144 195 404 minecraft:light[level=14]
setblock 145 195 370 minecraft:white_concrete
setblock 147 195 369 minecraft:black_concrete
fill 148 195 369 148 307 369 minecraft:purple_terracotta
setblock 148 195 410 minecraft:white_concrete
fill 149 195 411 151 307 411 minecraft:purple_terracotta
setblock 152 195 370 minecraft:white_concrete
setblock 152 195 372 minecraft:light[level=14]
setblock 152 195 380 minecraft:light[level=14]
setblock 152 195 388 minecraft:light[level=14]
setblock 152 195 396 minecraft:light[level=14]
setblock 152 195 404 minecraft:light[level=14]
fill 152 195 411 153 195 411 minecraft:black_concrete
fill 154 195 411 154 307 411 minecraft:purple_terracotta
setblock 155 195 410 minecraft:white_concrete
setblock 159 195 370 minecraft:white_concrete
setblock 160 195 372 minecraft:light[level=14]
setblock 160 195 380 minecraft:light[level=14]
setblock 160 195 388 minecraft:light[level=14]
setblock 160 195 396 minecraft:light[level=14]
setblock 160 195 404 minecraft:light[level=14]
setblock 162 195 410 minecraft:white_concrete
fill 162 195 411 162 307 411 minecraft:purple_terracotta
fill 164 195 411 164 307 411 minecraft:purple_terracotta
setblock 165 195 369 minecraft:black_concrete
setblock 165 195 411 minecraft:black_concrete
fill 166 195 369 170 307 369 minecraft:purple_terracotta
setblock 166 195 370 minecraft:white_concrete
fill 166 195 411 173 307 411 minecraft:purple_terracotta
setblock 168 195 372 minecraft:light[level=14]
setblock 168 195 380 minecraft:light[level=14]
setblock 168 195 388 minecraft:light[level=14]
setblock 168 195 396 minecraft:light[level=14]
setblock 168 195 404 minecraft:light[level=14]
setblock 169 195 410 minecraft:white_concrete
setblock 173 195 370 minecraft:white_concrete
fill 174 195 369 180 307 369 minecraft:purple_terracotta
setblock 176 195 372 minecraft:light[level=14]
setblock 176 195 380 minecraft:light[level=14]
setblock 176 195 388 minecraft:light[level=14]
setblock 176 195 396 minecraft:light[level=14]
setblock 176 195 404 minecraft:light[level=14]
setblock 176 195 410 minecraft:white_concrete
setblock 180 195 370 minecraft:white_concrete
setblock 181 195 369 minecraft:black_concrete
fill 182 195 369 182 307 369 minecraft:purple_terracotta
setblock 182 195 375 minecraft:white_concrete
setblock 182 195 382 minecraft:white_concrete
schedule function dropper:buildpart/87_3 1t
