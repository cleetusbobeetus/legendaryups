setblock 293 250 502 minecraft:shroomlight
setblock 293 250 504 minecraft:shroomlight
setblock 294 250 495 minecraft:shroomlight
setblock 294 250 497 minecraft:shroomlight
setblock 294 250 499 minecraft:shroomlight
setblock 294 250 501 minecraft:shroomlight
setblock 294 250 503 minecraft:shroomlight
setblock 295 250 496 minecraft:shroomlight
setblock 295 250 498 minecraft:shroomlight
setblock 295 250 500 minecraft:shroomlight
setblock 295 250 502 minecraft:shroomlight
setblock 295 250 504 minecraft:shroomlight
setblock 296 250 495 minecraft:shroomlight
setblock 296 250 497 minecraft:shroomlight
setblock 296 250 499 minecraft:shroomlight
setblock 296 250 501 minecraft:shroomlight
setblock 296 250 503 minecraft:shroomlight
setblock 297 250 496 minecraft:shroomlight
setblock 297 250 498 minecraft:shroomlight
setblock 297 250 500 minecraft:shroomlight
setblock 297 250 502 minecraft:shroomlight
setblock 297 250 504 minecraft:shroomlight
setblock 298 250 495 minecraft:shroomlight
setblock 298 250 497 minecraft:shroomlight
setblock 298 250 499 minecraft:shroomlight
setblock 298 250 501 minecraft:shroomlight
setblock 298 250 503 minecraft:shroomlight
setblock 299 250 496 minecraft:shroomlight
setblock 299 250 498 minecraft:shroomlight
setblock 299 250 500 minecraft:shroomlight
setblock 299 250 502 minecraft:shroomlight
setblock 299 250 504 minecraft:shroomlight
setblock 300 250 495 minecraft:shroomlight
setblock 300 250 497 minecraft:shroomlight
setblock 300 250 499 minecraft:shroomlight
setblock 300 250 501 minecraft:shroomlight
setblock 300 250 503 minecraft:shroomlight
setblock 301 250 496 minecraft:shroomlight
setblock 301 250 498 minecraft:shroomlight
setblock 301 250 500 minecraft:shroomlight
setblock 301 250 502 minecraft:shroomlight
setblock 301 250 504 minecraft:shroomlight
setblock 302 250 499 minecraft:shroomlight
setblock 302 250 501 minecraft:shroomlight
setblock 302 250 503 minecraft:shroomlight
setblock 303 250 498 minecraft:shroomlight
setblock 303 250 500 minecraft:shroomlight
setblock 303 250 502 minecraft:shroomlight
setblock 303 250 504 minecraft:shroomlight
setblock 304 250 499 minecraft:shroomlight
setblock 304 250 501 minecraft:shroomlight
setblock 304 250 503 minecraft:shroomlight
setblock 305 250 498 minecraft:shroomlight
setblock 305 250 500 minecraft:shroomlight
setblock 305 250 502 minecraft:shroomlight
setblock 305 250 504 minecraft:shroomlight
setblock 306 250 499 minecraft:shroomlight
setblock 306 250 501 minecraft:shroomlight
setblock 306 250 503 minecraft:shroomlight
setblock 307 250 498 minecraft:shroomlight
setblock 307 250 500 minecraft:shroomlight
setblock 307 250 502 minecraft:shroomlight
setblock 307 250 504 minecraft:shroomlight
setblock 308 250 499 minecraft:shroomlight
setblock 308 250 501 minecraft:shroomlight
setblock 308 250 503 minecraft:shroomlight
setblock 309 250 498 minecraft:shroomlight
setblock 309 250 500 minecraft:shroomlight
setblock 309 250 502 minecraft:shroomlight
setblock 309 250 504 minecraft:shroomlight
setblock 310 250 499 minecraft:shroomlight
setblock 310 250 501 minecraft:shroomlight
setblock 310 250 503 minecraft:shroomlight
fill 287 251 494 288 251 498 minecraft:gold_block
fill 289 251 495 289 252 500 minecraft:polished_blackstone_bricks
fill 289 251 502 289 252 502 minecraft:polished_blackstone_bricks
fill 289 251 504 289 252 504 minecraft:polished_blackstone_bricks
fill 290 251 495 290 252 495 minecraft:polished_blackstone_bricks
fill 290 251 497 290 252 497 minecraft:polished_blackstone_bricks
fill 290 251 499 290 252 499 minecraft:polished_blackstone_bricks
fill 290 251 501 290 252 501 minecraft:polished_blackstone_bricks
fill 290 251 503 290 252 503 minecraft:polished_blackstone_bricks
fill 291 251 496 291 252 496 minecraft:polished_blackstone_bricks
fill 291 251 498 291 252 498 minecraft:polished_blackstone_bricks
fill 291 251 500 291 252 500 minecraft:polished_blackstone_bricks
fill 291 251 502 291 252 502 minecraft:polished_blackstone_bricks
fill 291 251 504 291 252 504 minecraft:polished_blackstone_bricks
fill 292 251 495 292 252 495 minecraft:polished_blackstone_bricks
fill 292 251 497 292 252 497 minecraft:polished_blackstone_bricks
fill 292 251 499 292 252 499 minecraft:polished_blackstone_bricks
fill 292 251 501 292 252 501 minecraft:polished_blackstone_bricks
fill 292 251 503 292 252 503 minecraft:polished_blackstone_bricks
fill 293 251 496 293 252 496 minecraft:polished_blackstone_bricks
fill 293 251 498 293 252 498 minecraft:polished_blackstone_bricks
fill 293 251 500 293 252 500 minecraft:polished_blackstone_bricks
fill 293 251 502 293 252 502 minecraft:polished_blackstone_bricks
fill 293 251 504 293 252 504 minecraft:polished_blackstone_bricks
fill 294 251 495 294 252 495 minecraft:polished_blackstone_bricks
fill 294 251 497 294 252 497 minecraft:polished_blackstone_bricks
fill 294 251 499 294 252 499 minecraft:polished_blackstone_bricks
fill 294 251 501 294 252 501 minecraft:polished_blackstone_bricks
fill 294 251 503 294 252 503 minecraft:polished_blackstone_bricks
fill 295 251 496 295 252 496 minecraft:polished_blackstone_bricks
fill 295 251 498 295 252 498 minecraft:polished_blackstone_bricks
fill 295 251 500 295 252 500 minecraft:polished_blackstone_bricks
fill 295 251 502 295 252 502 minecraft:polished_blackstone_bricks
fill 295 251 504 295 252 504 minecraft:polished_blackstone_bricks
fill 296 251 495 296 252 495 minecraft:polished_blackstone_bricks
fill 296 251 497 296 252 497 minecraft:polished_blackstone_bricks
fill 296 251 499 296 252 499 minecraft:polished_blackstone_bricks
fill 296 251 501 296 252 501 minecraft:polished_blackstone_bricks
fill 296 251 503 296 252 503 minecraft:polished_blackstone_bricks
fill 297 251 496 297 252 496 minecraft:polished_blackstone_bricks
fill 297 251 498 297 252 498 minecraft:polished_blackstone_bricks
fill 297 251 500 297 252 500 minecraft:polished_blackstone_bricks
fill 297 251 502 297 252 502 minecraft:polished_blackstone_bricks
fill 297 251 504 297 252 504 minecraft:polished_blackstone_bricks
fill 298 251 495 298 252 495 minecraft:polished_blackstone_bricks
fill 298 251 497 298 252 497 minecraft:polished_blackstone_bricks
fill 298 251 499 298 252 499 minecraft:polished_blackstone_bricks
fill 298 251 501 298 252 501 minecraft:polished_blackstone_bricks
fill 298 251 503 298 252 503 minecraft:polished_blackstone_bricks
fill 299 251 496 299 252 496 minecraft:polished_blackstone_bricks
fill 299 251 498 299 252 498 minecraft:polished_blackstone_bricks
fill 299 251 500 299 252 500 minecraft:polished_blackstone_bricks
fill 299 251 502 299 252 502 minecraft:polished_blackstone_bricks
fill 299 251 504 299 252 504 minecraft:polished_blackstone_bricks
fill 300 251 495 300 252 495 minecraft:polished_blackstone_bricks
fill 300 251 497 300 252 497 minecraft:polished_blackstone_bricks
fill 300 251 499 300 252 499 minecraft:polished_blackstone_bricks
fill 300 251 501 300 252 501 minecraft:polished_blackstone_bricks
fill 300 251 503 300 252 503 minecraft:polished_blackstone_bricks
fill 301 251 496 301 252 496 minecraft:polished_blackstone_bricks
fill 301 251 498 301 252 498 minecraft:polished_blackstone_bricks
fill 301 251 500 301 252 500 minecraft:polished_blackstone_bricks
fill 301 251 502 301 252 502 minecraft:polished_blackstone_bricks
fill 301 251 504 301 252 504 minecraft:polished_blackstone_bricks
fill 302 251 499 302 252 499 minecraft:polished_blackstone_bricks
fill 302 251 501 302 252 501 minecraft:polished_blackstone_bricks
fill 302 251 503 302 252 503 minecraft:polished_blackstone_bricks
fill 303 251 498 303 252 498 minecraft:polished_blackstone_bricks
fill 303 251 500 303 252 500 minecraft:polished_blackstone_bricks
fill 303 251 502 303 252 502 minecraft:polished_blackstone_bricks
fill 303 251 504 303 252 504 minecraft:polished_blackstone_bricks
fill 304 251 499 304 252 499 minecraft:polished_blackstone_bricks
fill 304 251 501 304 252 501 minecraft:polished_blackstone_bricks
fill 304 251 503 304 252 503 minecraft:polished_blackstone_bricks
fill 305 251 498 305 252 498 minecraft:polished_blackstone_bricks
fill 305 251 500 305 252 500 minecraft:polished_blackstone_bricks
fill 305 251 502 305 252 502 minecraft:polished_blackstone_bricks
fill 305 251 504 305 252 504 minecraft:polished_blackstone_bricks
fill 306 251 499 306 252 499 minecraft:polished_blackstone_bricks
fill 306 251 501 306 252 501 minecraft:polished_blackstone_bricks
fill 306 251 503 306 252 503 minecraft:polished_blackstone_bricks
fill 307 251 498 307 252 498 minecraft:polished_blackstone_bricks
fill 307 251 500 307 252 500 minecraft:polished_blackstone_bricks
fill 307 251 502 307 252 502 minecraft:polished_blackstone_bricks
fill 307 251 504 307 252 504 minecraft:polished_blackstone_bricks
fill 308 251 499 308 252 499 minecraft:polished_blackstone_bricks
fill 308 251 501 308 252 501 minecraft:polished_blackstone_bricks
fill 308 251 503 308 252 503 minecraft:polished_blackstone_bricks
fill 309 251 498 309 252 498 minecraft:polished_blackstone_bricks
fill 309 251 500 309 252 500 minecraft:polished_blackstone_bricks
fill 309 251 502 309 252 502 minecraft:polished_blackstone_bricks
fill 309 251 504 309 252 504 minecraft:polished_blackstone_bricks
fill 310 251 499 310 252 499 minecraft:polished_blackstone_bricks
fill 310 251 501 310 252 501 minecraft:polished_blackstone_bricks
fill 310 251 503 310 252 503 minecraft:polished_blackstone_bricks
fill 320 251 478 320 269 478 minecraft:gilded_blackstone
fill 282 252 469 282 265 469 minecraft:red_nether_bricks
fill 282 252 470 282 252 471 minecraft:shroomlight
fill 282 252 472 282 265 472 minecraft:red_nether_bricks
fill 282 252 481 282 265 481 minecraft:red_nether_bricks
fill 282 252 482 282 252 483 minecraft:shroomlight
fill 282 252 484 282 265 484 minecraft:red_nether_bricks
fill 282 252 493 282 265 493 minecraft:red_nether_bricks
fill 282 252 494 282 252 495 minecraft:shroomlight
fill 282 252 496 282 265 496 minecraft:red_nether_bricks
fill 282 252 505 282 265 505 minecraft:red_nether_bricks
fill 283 252 505 284 252 505 minecraft:shroomlight
fill 285 252 505 285 265 505 minecraft:red_nether_bricks
fill 289 252 463 289 265 463 minecraft:red_nether_bricks
fill 290 252 463 291 252 463 minecraft:shroomlight
fill 292 252 463 292 265 463 minecraft:red_nether_bricks
fill 294 252 505 294 265 505 minecraft:red_nether_bricks
fill 295 252 505 296 252 505 minecraft:shroomlight
fill 297 252 505 297 265 505 minecraft:red_nether_bricks
fill 301 252 463 301 265 463 minecraft:red_nether_bricks
fill 302 252 463 303 252 463 minecraft:shroomlight
fill 304 252 463 304 265 463 minecraft:red_nether_bricks
fill 306 252 505 306 265 505 minecraft:red_nether_bricks
fill 307 252 505 308 252 505 minecraft:shroomlight
fill 309 252 505 309 265 505 minecraft:red_nether_bricks
fill 313 252 463 313 265 463 minecraft:red_nether_bricks
fill 314 252 463 315 252 463 minecraft:shroomlight
fill 316 252 463 316 265 463 minecraft:red_nether_bricks
fill 318 252 505 318 265 505 minecraft:red_nether_bricks
fill 319 252 505 320 252 505 minecraft:shroomlight
fill 321 252 505 321 265 505 minecraft:red_nether_bricks
fill 324 252 464 324 265 464 minecraft:red_nether_bricks
fill 324 252 465 324 252 466 minecraft:shroomlight
fill 324 252 467 324 265 467 minecraft:red_nether_bricks
fill 324 252 476 324 265 476 minecraft:red_nether_bricks
fill 324 252 477 324 252 478 minecraft:shroomlight
fill 324 252 479 324 265 479 minecraft:red_nether_bricks
fill 324 252 488 324 265 488 minecraft:red_nether_bricks
fill 324 252 489 324 252 490 minecraft:shroomlight
fill 324 252 491 324 265 491 minecraft:red_nether_bricks
fill 324 252 500 324 265 500 minecraft:red_nether_bricks
fill 324 252 501 324 252 502 minecraft:shroomlight
fill 324 252 503 324 265 503 minecraft:red_nether_bricks
fill 282 253 470 282 265 471 minecraft:red_nether_bricks
fill 282 253 482 282 265 483 minecraft:red_nether_bricks
fill 282 253 494 282 265 495 minecraft:red_nether_bricks
fill 283 253 505 284 265 505 minecraft:red_nether_bricks
fill 289 253 495 289 254 495 minecraft:polished_blackstone_bricks
setblock 289 253 496 minecraft:shroomlight
fill 289 253 497 289 254 497 minecraft:polished_blackstone_bricks
setblock 289 253 498 minecraft:shroomlight
fill 289 253 499 289 254 499 minecraft:polished_blackstone_bricks
setblock 289 253 500 minecraft:shroomlight
setblock 289 253 502 minecraft:shroomlight
setblock 289 253 504 minecraft:shroomlight
fill 290 253 463 291 265 463 minecraft:red_nether_bricks
setblock 290 253 495 minecraft:shroomlight
setblock 290 253 497 minecraft:shroomlight
setblock 290 253 499 minecraft:shroomlight
setblock 290 253 501 minecraft:shroomlight
setblock 290 253 503 minecraft:shroomlight
setblock 291 253 496 minecraft:shroomlight
setblock 291 253 498 minecraft:shroomlight
setblock 291 253 500 minecraft:shroomlight
setblock 291 253 502 minecraft:shroomlight
setblock 291 253 504 minecraft:shroomlight
setblock 292 253 495 minecraft:shroomlight
setblock 292 253 497 minecraft:shroomlight
setblock 292 253 499 minecraft:shroomlight
setblock 292 253 501 minecraft:shroomlight
setblock 292 253 503 minecraft:shroomlight
setblock 293 253 496 minecraft:shroomlight
setblock 293 253 498 minecraft:shroomlight
setblock 293 253 500 minecraft:shroomlight
setblock 293 253 502 minecraft:shroomlight
setblock 293 253 504 minecraft:shroomlight
setblock 294 253 495 minecraft:shroomlight
setblock 294 253 497 minecraft:shroomlight
setblock 294 253 499 minecraft:shroomlight
setblock 294 253 501 minecraft:shroomlight
setblock 294 253 503 minecraft:shroomlight
setblock 295 253 496 minecraft:shroomlight
setblock 295 253 498 minecraft:shroomlight
setblock 295 253 500 minecraft:shroomlight
setblock 295 253 502 minecraft:shroomlight
setblock 295 253 504 minecraft:shroomlight
fill 295 253 505 296 265 505 minecraft:red_nether_bricks
setblock 296 253 495 minecraft:shroomlight
setblock 296 253 497 minecraft:shroomlight
setblock 296 253 499 minecraft:shroomlight
setblock 296 253 501 minecraft:shroomlight
setblock 296 253 503 minecraft:shroomlight
setblock 297 253 496 minecraft:shroomlight
setblock 297 253 498 minecraft:shroomlight
setblock 297 253 500 minecraft:shroomlight
setblock 297 253 502 minecraft:shroomlight
setblock 297 253 504 minecraft:shroomlight
setblock 298 253 495 minecraft:shroomlight
setblock 298 253 497 minecraft:shroomlight
setblock 298 253 499 minecraft:shroomlight
setblock 298 253 501 minecraft:shroomlight
setblock 298 253 503 minecraft:shroomlight
setblock 299 253 496 minecraft:shroomlight
setblock 299 253 498 minecraft:shroomlight
setblock 299 253 500 minecraft:shroomlight
setblock 299 253 502 minecraft:shroomlight
setblock 299 253 504 minecraft:shroomlight
setblock 300 253 495 minecraft:shroomlight
setblock 300 253 497 minecraft:shroomlight
setblock 300 253 499 minecraft:shroomlight
setblock 300 253 501 minecraft:shroomlight
setblock 300 253 503 minecraft:shroomlight
setblock 301 253 496 minecraft:shroomlight
setblock 301 253 498 minecraft:shroomlight
setblock 301 253 500 minecraft:shroomlight
setblock 301 253 502 minecraft:shroomlight
setblock 301 253 504 minecraft:shroomlight
fill 302 253 463 303 265 463 minecraft:red_nether_bricks
setblock 302 253 499 minecraft:shroomlight
setblock 302 253 501 minecraft:shroomlight
setblock 302 253 503 minecraft:shroomlight
setblock 303 253 498 minecraft:shroomlight
setblock 303 253 500 minecraft:shroomlight
setblock 303 253 502 minecraft:shroomlight
setblock 303 253 504 minecraft:shroomlight
setblock 304 253 499 minecraft:shroomlight
setblock 304 253 501 minecraft:shroomlight
setblock 304 253 503 minecraft:shroomlight
setblock 305 253 498 minecraft:shroomlight
setblock 305 253 500 minecraft:shroomlight
setblock 305 253 502 minecraft:shroomlight
setblock 305 253 504 minecraft:shroomlight
setblock 306 253 499 minecraft:shroomlight
setblock 306 253 501 minecraft:shroomlight
setblock 306 253 503 minecraft:shroomlight
setblock 307 253 498 minecraft:shroomlight
setblock 307 253 500 minecraft:shroomlight
setblock 307 253 502 minecraft:shroomlight
setblock 307 253 504 minecraft:shroomlight
fill 307 253 505 308 265 505 minecraft:red_nether_bricks
setblock 308 253 499 minecraft:shroomlight
setblock 308 253 501 minecraft:shroomlight
setblock 308 253 503 minecraft:shroomlight
setblock 309 253 498 minecraft:shroomlight
setblock 309 253 500 minecraft:shroomlight
setblock 309 253 502 minecraft:shroomlight
setblock 309 253 504 minecraft:shroomlight
setblock 310 253 499 minecraft:shroomlight
setblock 310 253 501 minecraft:shroomlight
setblock 310 253 503 minecraft:shroomlight
fill 314 253 463 315 265 463 minecraft:red_nether_bricks
fill 319 253 505 320 265 505 minecraft:red_nether_bricks
fill 324 253 465 324 265 466 minecraft:red_nether_bricks
fill 324 253 477 324 265 478 minecraft:red_nether_bricks
fill 324 253 489 324 265 490 minecraft:red_nether_bricks
fill 324 253 501 324 265 502 minecraft:red_nether_bricks
setblock 289 254 496 minecraft:polished_blackstone_bricks
setblock 289 254 498 minecraft:polished_blackstone_bricks
setblock 289 254 500 minecraft:polished_blackstone_bricks
setblock 289 254 502 minecraft:polished_blackstone_bricks
fill 289 254 504 289 273 504 minecraft:polished_blackstone_bricks
setblock 290 254 495 minecraft:polished_blackstone_bricks
setblock 290 254 497 minecraft:polished_blackstone_bricks
setblock 290 254 499 minecraft:polished_blackstone_bricks
setblock 290 254 501 minecraft:polished_blackstone_bricks
setblock 290 254 503 minecraft:polished_blackstone_bricks
setblock 291 254 496 minecraft:polished_blackstone_bricks
setblock 291 254 498 minecraft:polished_blackstone_bricks
setblock 291 254 500 minecraft:polished_blackstone_bricks
setblock 291 254 502 minecraft:polished_blackstone_bricks
fill 291 254 504 291 273 504 minecraft:polished_blackstone_bricks
setblock 292 254 495 minecraft:polished_blackstone_bricks
setblock 292 254 497 minecraft:polished_blackstone_bricks
setblock 292 254 499 minecraft:polished_blackstone_bricks
setblock 292 254 501 minecraft:polished_blackstone_bricks
setblock 292 254 503 minecraft:polished_blackstone_bricks
setblock 293 254 496 minecraft:polished_blackstone_bricks
setblock 293 254 498 minecraft:polished_blackstone_bricks
setblock 293 254 500 minecraft:polished_blackstone_bricks
setblock 293 254 502 minecraft:polished_blackstone_bricks
setblock 293 254 504 minecraft:polished_blackstone_bricks
setblock 294 254 495 minecraft:polished_blackstone_bricks
setblock 294 254 497 minecraft:polished_blackstone_bricks
setblock 294 254 499 minecraft:polished_blackstone_bricks
setblock 294 254 501 minecraft:polished_blackstone_bricks
setblock 294 254 503 minecraft:polished_blackstone_bricks
setblock 295 254 496 minecraft:polished_blackstone_bricks
setblock 295 254 498 minecraft:polished_blackstone_bricks
setblock 295 254 500 minecraft:polished_blackstone_bricks
setblock 295 254 502 minecraft:polished_blackstone_bricks
setblock 295 254 504 minecraft:polished_blackstone_bricks
setblock 296 254 495 minecraft:polished_blackstone_bricks
setblock 296 254 497 minecraft:polished_blackstone_bricks
setblock 296 254 499 minecraft:polished_blackstone_bricks
setblock 296 254 501 minecraft:polished_blackstone_bricks
setblock 296 254 503 minecraft:polished_blackstone_bricks
setblock 297 254 496 minecraft:polished_blackstone_bricks
setblock 297 254 498 minecraft:polished_blackstone_bricks
setblock 297 254 500 minecraft:polished_blackstone_bricks
setblock 297 254 502 minecraft:polished_blackstone_bricks
setblock 297 254 504 minecraft:polished_blackstone_bricks
setblock 298 254 495 minecraft:polished_blackstone_bricks
setblock 298 254 497 minecraft:polished_blackstone_bricks
setblock 298 254 499 minecraft:polished_blackstone_bricks
setblock 298 254 501 minecraft:polished_blackstone_bricks
setblock 298 254 503 minecraft:polished_blackstone_bricks
setblock 299 254 496 minecraft:polished_blackstone_bricks
setblock 299 254 498 minecraft:polished_blackstone_bricks
setblock 299 254 500 minecraft:polished_blackstone_bricks
setblock 299 254 502 minecraft:polished_blackstone_bricks
setblock 299 254 504 minecraft:polished_blackstone_bricks
setblock 300 254 495 minecraft:polished_blackstone_bricks
setblock 300 254 497 minecraft:polished_blackstone_bricks
setblock 300 254 499 minecraft:polished_blackstone_bricks
setblock 300 254 501 minecraft:polished_blackstone_bricks
setblock 300 254 503 minecraft:polished_blackstone_bricks
setblock 301 254 496 minecraft:polished_blackstone_bricks
setblock 301 254 498 minecraft:polished_blackstone_bricks
setblock 301 254 500 minecraft:polished_blackstone_bricks
setblock 301 254 502 minecraft:polished_blackstone_bricks
fill 301 254 504 301 273 504 minecraft:polished_blackstone_bricks
setblock 302 254 499 minecraft:polished_blackstone_bricks
setblock 302 254 501 minecraft:polished_blackstone_bricks
setblock 302 254 503 minecraft:polished_blackstone_bricks
setblock 303 254 498 minecraft:polished_blackstone_bricks
setblock 303 254 500 minecraft:polished_blackstone_bricks
setblock 303 254 502 minecraft:polished_blackstone_bricks
fill 303 254 504 303 273 504 minecraft:polished_blackstone_bricks
setblock 304 254 499 minecraft:polished_blackstone_bricks
setblock 304 254 501 minecraft:polished_blackstone_bricks
setblock 304 254 503 minecraft:polished_blackstone_bricks
setblock 305 254 498 minecraft:polished_blackstone_bricks
setblock 305 254 500 minecraft:polished_blackstone_bricks
setblock 305 254 502 minecraft:polished_blackstone_bricks
setblock 305 254 504 minecraft:polished_blackstone_bricks
setblock 306 254 499 minecraft:polished_blackstone_bricks
setblock 306 254 501 minecraft:polished_blackstone_bricks
setblock 306 254 503 minecraft:polished_blackstone_bricks
setblock 307 254 498 minecraft:polished_blackstone_bricks
setblock 307 254 500 minecraft:polished_blackstone_bricks
setblock 307 254 502 minecraft:polished_blackstone_bricks
setblock 307 254 504 minecraft:polished_blackstone_bricks
setblock 308 254 499 minecraft:polished_blackstone_bricks
setblock 308 254 501 minecraft:polished_blackstone_bricks
setblock 308 254 503 minecraft:polished_blackstone_bricks
setblock 309 254 498 minecraft:polished_blackstone_bricks
setblock 309 254 500 minecraft:polished_blackstone_bricks
setblock 309 254 502 minecraft:polished_blackstone_bricks
setblock 309 254 504 minecraft:polished_blackstone_bricks
setblock 310 254 499 minecraft:polished_blackstone_bricks
setblock 310 254 501 minecraft:polished_blackstone_bricks
setblock 310 254 503 minecraft:polished_blackstone_bricks
setblock 285 255 466 minecraft:light[level=14]
setblock 285 255 474 minecraft:light[level=14]
setblock 285 255 482 minecraft:light[level=14]
setblock 285 255 490 minecraft:light[level=14]
setblock 285 255 498 minecraft:light[level=14]
fill 290 255 496 300 255 503 minecraft:gold_block
setblock 293 255 466 minecraft:light[level=14]
setblock 293 255 474 minecraft:light[level=14]
setblock 293 255 482 minecraft:light[level=14]
setblock 293 255 490 minecraft:light[level=14]
setblock 301 255 466 minecraft:light[level=14]
setblock 301 255 474 minecraft:light[level=14]
setblock 301 255 482 minecraft:light[level=14]
setblock 301 255 490 minecraft:light[level=14]
setblock 301 255 498 minecraft:light[level=14]
fill 301 255 499 309 255 503 minecraft:gold_block
setblock 309 255 466 minecraft:light[level=14]
setblock 309 255 474 minecraft:light[level=14]
setblock 309 255 482 minecraft:light[level=14]
setblock 309 255 490 minecraft:light[level=14]
setblock 309 255 498 minecraft:light[level=14]
setblock 317 255 466 minecraft:light[level=14]
setblock 317 255 474 minecraft:light[level=14]
setblock 317 255 482 minecraft:light[level=14]
setblock 317 255 490 minecraft:light[level=14]
setblock 317 255 498 minecraft:light[level=14]
fill 291 256 497 299 256 502 minecraft:gold_block
fill 302 256 500 308 256 502 minecraft:gold_block
fill 321 256 474 321 265 474 minecraft:red_wool
fill 292 257 498 298 257 501 minecraft:gold_block
fill 303 257 501 307 257 501 minecraft:gold_block
fill 321 257 472 321 265 473 minecraft:red_wool
fill 321 257 475 321 265 476 minecraft:red_wool
fill 293 258 499 297 258 500 minecraft:gold_block
fill 304 258 500 306 258 502 minecraft:gold_block
fill 321 258 485 321 259 491 minecraft:gilded_blackstone
fill 284 260 473 284 265 475 minecraft:polished_blackstone_bricks
fill 284 260 485 284 265 487 minecraft:polished_blackstone_bricks
fill 284 260 497 284 265 499 minecraft:polished_blackstone_bricks
fill 290 260 503 292 265 503 minecraft:polished_blackstone_bricks
fill 294 260 465 296 265 465 minecraft:polished_blackstone_bricks
fill 302 260 503 304 265 503 minecraft:polished_blackstone_bricks
fill 306 260 465 308 265 465 minecraft:polished_blackstone_bricks
fill 314 260 503 316 265 503 minecraft:polished_blackstone_bricks
fill 318 260 465 320 265 465 minecraft:polished_blackstone_bricks
fill 322 260 473 322 265 475 minecraft:polished_blackstone_bricks
fill 322 260 485 322 265 487 minecraft:polished_blackstone_bricks
fill 322 260 497 322 265 499 minecraft:polished_blackstone_bricks
fill 301 261 499 301 272 499 minecraft:gilded_blackstone
setblock 285 263 466 minecraft:light[level=14]
setblock 285 263 474 minecraft:light[level=14]
setblock 285 263 482 minecraft:light[level=14]
setblock 285 263 490 minecraft:light[level=14]
setblock 285 263 498 minecraft:light[level=14]
setblock 293 263 466 minecraft:light[level=14]
setblock 293 263 474 minecraft:light[level=14]
setblock 293 263 482 minecraft:light[level=14]
setblock 293 263 490 minecraft:light[level=14]
setblock 293 263 498 minecraft:light[level=14]
setblock 301 263 466 minecraft:light[level=14]
setblock 301 263 474 minecraft:light[level=14]
setblock 301 263 482 minecraft:light[level=14]
setblock 301 263 490 minecraft:light[level=14]
setblock 301 263 498 minecraft:light[level=14]
setblock 309 263 466 minecraft:light[level=14]
setblock 309 263 474 minecraft:light[level=14]
setblock 309 263 482 minecraft:light[level=14]
setblock 309 263 490 minecraft:light[level=14]
setblock 309 263 498 minecraft:light[level=14]
setblock 317 263 466 minecraft:light[level=14]
setblock 317 263 474 minecraft:light[level=14]
setblock 317 263 482 minecraft:light[level=14]
setblock 317 263 490 minecraft:light[level=14]
setblock 317 263 498 minecraft:light[level=14]
fill 283 265 467 283 265 472 minecraft:nether_bricks
fill 283 265 479 283 265 484 minecraft:nether_bricks
fill 283 265 491 283 265 496 minecraft:nether_bricks
fill 283 265 503 283 265 504 minecraft:nether_bricks
fill 284 265 504 287 265 504 minecraft:nether_bricks
fill 287 265 464 292 265 464 minecraft:nether_bricks
fill 294 265 504 299 265 504 minecraft:nether_bricks
fill 299 265 464 304 265 464 minecraft:nether_bricks
fill 306 265 504 311 265 504 minecraft:nether_bricks
fill 311 265 464 316 265 464 minecraft:nether_bricks
fill 318 265 504 323 265 504 minecraft:nether_bricks
fill 323 265 464 323 265 469 minecraft:nether_bricks
fill 323 265 476 323 265 481 minecraft:nether_bricks
fill 323 265 488 323 265 493 minecraft:nether_bricks
fill 323 265 500 323 265 503 minecraft:nether_bricks
fill 282 266 469 282 271 472 minecraft:shroomlight
fill 282 266 481 282 271 484 minecraft:shroomlight
fill 282 266 493 282 271 496 minecraft:shroomlight
fill 282 266 505 285 271 505 minecraft:shroomlight
fill 289 266 463 292 271 463 minecraft:shroomlight
fill 294 266 505 297 271 505 minecraft:shroomlight
fill 301 266 463 304 271 463 minecraft:shroomlight
fill 306 266 505 309 271 505 minecraft:shroomlight
fill 313 266 463 316 271 463 minecraft:shroomlight
fill 318 266 505 321 271 505 minecraft:shroomlight
fill 321 266 471 321 267 477 minecraft:gilded_blackstone
fill 324 266 464 324 271 467 minecraft:shroomlight
fill 324 266 476 324 271 479 minecraft:shroomlight
fill 324 266 488 324 271 491 minecraft:shroomlight
fill 324 266 500 324 271 503 minecraft:shroomlight
setblock 285 271 466 minecraft:light[level=14]
setblock 285 271 474 minecraft:light[level=14]
setblock 285 271 482 minecraft:light[level=14]
setblock 285 271 490 minecraft:light[level=14]
setblock 285 271 498 minecraft:light[level=14]
setblock 293 271 466 minecraft:light[level=14]
setblock 293 271 474 minecraft:light[level=14]
setblock 293 271 482 minecraft:light[level=14]
setblock 293 271 490 minecraft:light[level=14]
setblock 293 271 498 minecraft:light[level=14]
setblock 301 271 466 minecraft:light[level=14]
setblock 301 271 474 minecraft:light[level=14]
setblock 301 271 482 minecraft:light[level=14]
setblock 301 271 490 minecraft:light[level=14]
setblock 301 271 498 minecraft:light[level=14]
setblock 309 271 466 minecraft:light[level=14]
setblock 309 271 474 minecraft:light[level=14]
setblock 309 271 482 minecraft:light[level=14]
setblock 309 271 490 minecraft:light[level=14]
setblock 309 271 498 minecraft:light[level=14]
setblock 317 271 466 minecraft:light[level=14]
setblock 317 271 474 minecraft:light[level=14]
setblock 317 271 482 minecraft:light[level=14]
setblock 317 271 490 minecraft:light[level=14]
setblock 317 271 498 minecraft:light[level=14]
fill 282 272 469 282 285 469 minecraft:red_nether_bricks
fill 282 272 470 282 272 471 minecraft:shroomlight
fill 282 272 472 282 285 472 minecraft:red_nether_bricks
fill 282 272 481 282 285 481 minecraft:red_nether_bricks
fill 282 272 482 282 272 483 minecraft:shroomlight
fill 282 272 484 282 285 484 minecraft:red_nether_bricks
fill 282 272 493 282 285 493 minecraft:red_nether_bricks
fill 282 272 494 282 272 495 minecraft:shroomlight
fill 282 272 496 282 285 496 minecraft:red_nether_bricks
fill 282 272 505 282 285 505 minecraft:red_nether_bricks
fill 283 272 505 284 272 505 minecraft:shroomlight
fill 285 272 505 285 285 505 minecraft:red_nether_bricks
fill 289 272 463 289 285 463 minecraft:red_nether_bricks
fill 290 272 463 291 272 463 minecraft:shroomlight
fill 292 272 463 292 285 463 minecraft:red_nether_bricks
fill 294 272 505 294 285 505 minecraft:red_nether_bricks
fill 295 272 505 296 272 505 minecraft:shroomlight
fill 297 272 505 297 285 505 minecraft:red_nether_bricks
fill 301 272 463 301 285 463 minecraft:red_nether_bricks
fill 302 272 463 303 272 463 minecraft:shroomlight
fill 304 272 463 304 285 463 minecraft:red_nether_bricks
fill 306 272 505 306 285 505 minecraft:red_nether_bricks
fill 307 272 505 308 272 505 minecraft:shroomlight
fill 309 272 505 309 285 505 minecraft:red_nether_bricks
fill 313 272 463 313 285 463 minecraft:red_nether_bricks
fill 314 272 463 315 272 463 minecraft:shroomlight
fill 316 272 463 316 285 463 minecraft:red_nether_bricks
fill 318 272 505 318 285 505 minecraft:red_nether_bricks
fill 319 272 505 320 272 505 minecraft:shroomlight
fill 321 272 505 321 285 505 minecraft:red_nether_bricks
fill 324 272 464 324 285 464 minecraft:red_nether_bricks
fill 324 272 465 324 272 466 minecraft:shroomlight
fill 324 272 467 324 285 467 minecraft:red_nether_bricks
fill 324 272 476 324 285 476 minecraft:red_nether_bricks
fill 324 272 477 324 272 478 minecraft:shroomlight
fill 324 272 479 324 285 479 minecraft:red_nether_bricks
fill 324 272 488 324 285 488 minecraft:red_nether_bricks
fill 324 272 489 324 272 490 minecraft:shroomlight
fill 324 272 491 324 285 491 minecraft:red_nether_bricks
fill 324 272 500 324 285 500 minecraft:red_nether_bricks
fill 324 272 501 324 272 502 minecraft:shroomlight
fill 324 272 503 324 285 503 minecraft:red_nether_bricks
fill 282 273 470 282 285 471 minecraft:red_nether_bricks
fill 282 273 482 282 285 483 minecraft:red_nether_bricks
fill 282 273 494 282 285 495 minecraft:red_nether_bricks
fill 283 273 505 284 285 505 minecraft:red_nether_bricks
fill 290 273 463 291 285 463 minecraft:red_nether_bricks
fill 295 273 505 296 285 505 minecraft:red_nether_bricks
fill 302 273 463 303 285 463 minecraft:red_nether_bricks
fill 307 273 505 308 285 505 minecraft:red_nether_bricks
fill 314 273 463 315 285 463 minecraft:red_nether_bricks
fill 319 273 505 320 285 505 minecraft:red_nether_bricks
fill 324 273 465 324 285 466 minecraft:red_nether_bricks
fill 324 273 477 324 285 478 minecraft:red_nether_bricks
fill 324 273 489 324 285 490 minecraft:red_nether_bricks
fill 324 273 501 324 285 502 minecraft:red_nether_bricks
fill 283 279 464 284 280 465 minecraft:nether_bricks
fill 283 279 466 284 279 469 minecraft:red_nether_bricks
fill 283 279 470 284 279 473 minecraft:nether_bricks
fill 283 279 474 284 279 477 minecraft:red_nether_bricks
fill 283 279 478 284 279 481 minecraft:nether_bricks
fill 283 279 482 284 279 485 minecraft:red_nether_bricks
fill 283 279 486 284 279 489 minecraft:nether_bricks
fill 283 279 490 284 279 493 minecraft:red_nether_bricks
fill 283 279 494 284 279 497 minecraft:nether_bricks
fill 283 279 498 284 279 501 minecraft:red_nether_bricks
fill 283 279 502 284 279 504 minecraft:nether_bricks
fill 285 279 464 288 279 465 minecraft:red_nether_bricks
fill 285 279 466 288 279 469 minecraft:nether_bricks
fill 285 279 470 288 279 473 minecraft:red_nether_bricks
fill 285 279 474 288 279 477 minecraft:nether_bricks
fill 285 279 478 288 279 481 minecraft:red_nether_bricks
fill 285 279 482 288 279 485 minecraft:nether_bricks
fill 285 279 486 288 279 489 minecraft:red_nether_bricks
fill 285 279 490 288 279 493 minecraft:nether_bricks
fill 285 279 494 288 279 497 minecraft:red_nether_bricks
fill 285 279 498 288 279 501 minecraft:nether_bricks
fill 285 279 502 288 279 504 minecraft:red_nether_bricks
fill 289 279 464 292 279 465 minecraft:nether_bricks
fill 289 279 466 292 279 469 minecraft:red_nether_bricks
fill 289 279 470 292 279 473 minecraft:nether_bricks
fill 289 279 474 292 279 477 minecraft:red_nether_bricks
fill 289 279 478 292 279 481 minecraft:nether_bricks
fill 289 279 482 292 279 485 minecraft:red_nether_bricks
fill 289 279 486 292 279 489 minecraft:nether_bricks
fill 289 279 490 292 279 493 minecraft:red_nether_bricks
fill 289 279 494 292 279 497 minecraft:nether_bricks
fill 289 279 498 292 279 501 minecraft:red_nether_bricks
fill 289 279 502 292 279 504 minecraft:nether_bricks
fill 293 279 464 296 279 465 minecraft:red_nether_bricks
fill 293 279 466 296 279 469 minecraft:nether_bricks
fill 293 279 470 296 279 473 minecraft:red_nether_bricks
fill 293 279 474 296 279 477 minecraft:nether_bricks
fill 293 279 478 296 279 481 minecraft:red_nether_bricks
fill 293 279 482 296 279 485 minecraft:nether_bricks
fill 293 279 486 296 279 489 minecraft:red_nether_bricks
fill 293 279 490 296 279 493 minecraft:nether_bricks
fill 293 279 494 296 279 497 minecraft:red_nether_bricks
fill 293 279 498 296 279 501 minecraft:nether_bricks
fill 293 279 502 296 279 504 minecraft:red_nether_bricks
fill 297 279 464 300 279 465 minecraft:nether_bricks
fill 297 279 466 300 279 469 minecraft:red_nether_bricks
fill 297 279 470 300 279 473 minecraft:nether_bricks
fill 297 279 474 300 279 477 minecraft:red_nether_bricks
fill 297 279 478 300 279 481 minecraft:nether_bricks
fill 297 279 482 300 279 485 minecraft:red_nether_bricks
fill 297 279 486 300 279 489 minecraft:nether_bricks
fill 297 279 490 300 279 493 minecraft:red_nether_bricks
fill 297 279 494 300 279 497 minecraft:nether_bricks
fill 297 279 498 300 279 501 minecraft:red_nether_bricks
fill 297 279 502 300 279 504 minecraft:nether_bricks
fill 301 279 464 304 279 465 minecraft:red_nether_bricks
fill 301 279 466 304 279 469 minecraft:nether_bricks
fill 301 279 470 304 279 473 minecraft:red_nether_bricks
fill 301 279 474 304 279 477 minecraft:nether_bricks
fill 301 279 478 303 279 481 minecraft:red_nether_bricks
fill 301 279 482 302 279 485 minecraft:nether_bricks
fill 301 279 486 304 279 489 minecraft:red_nether_bricks
fill 301 279 490 304 279 493 minecraft:nether_bricks
fill 301 279 494 304 279 497 minecraft:red_nether_bricks
fill 301 279 498 304 279 501 minecraft:nether_bricks
fill 301 279 502 304 279 504 minecraft:red_nether_bricks
fill 303 279 483 303 279 485 minecraft:nether_bricks
fill 304 279 478 304 279 480 minecraft:red_nether_bricks
fill 304 279 484 304 279 485 minecraft:nether_bricks
fill 305 279 464 308 279 465 minecraft:nether_bricks
fill 305 279 466 308 279 469 minecraft:red_nether_bricks
fill 305 279 470 308 279 473 minecraft:nether_bricks
fill 305 279 474 308 279 477 minecraft:red_nether_bricks
fill 305 279 478 308 279 479 minecraft:nether_bricks
fill 305 279 485 308 279 485 minecraft:red_nether_bricks
fill 305 279 486 308 279 489 minecraft:nether_bricks
fill 305 279 490 308 279 493 minecraft:red_nether_bricks
fill 305 279 494 308 279 497 minecraft:nether_bricks
fill 305 279 498 308 279 501 minecraft:red_nether_bricks
fill 305 279 502 308 279 504 minecraft:nether_bricks
fill 306 279 480 308 279 480 minecraft:nether_bricks
fill 306 279 484 308 279 484 minecraft:red_nether_bricks
fill 307 279 481 308 279 481 minecraft:nether_bricks
fill 307 279 483 308 279 483 minecraft:red_nether_bricks
setblock 308 279 482 minecraft:red_nether_bricks
fill 309 279 464 312 279 465 minecraft:red_nether_bricks
fill 309 279 466 312 279 469 minecraft:nether_bricks
fill 309 279 470 312 279 473 minecraft:red_nether_bricks
fill 309 279 474 312 279 477 minecraft:nether_bricks
fill 309 279 478 312 279 481 minecraft:red_nether_bricks
fill 309 279 482 312 279 485 minecraft:nether_bricks
fill 309 279 486 312 279 489 minecraft:red_nether_bricks
fill 309 279 490 312 279 493 minecraft:nether_bricks
fill 309 279 494 312 279 497 minecraft:red_nether_bricks
fill 309 279 498 312 279 501 minecraft:nether_bricks
fill 309 279 502 312 279 504 minecraft:red_nether_bricks
fill 313 279 464 316 279 465 minecraft:nether_bricks
fill 313 279 466 316 279 469 minecraft:red_nether_bricks
fill 313 279 470 316 279 473 minecraft:nether_bricks
fill 313 279 474 316 279 477 minecraft:red_nether_bricks
fill 313 279 478 316 279 481 minecraft:nether_bricks
fill 313 279 482 316 279 485 minecraft:red_nether_bricks
fill 313 279 486 316 279 489 minecraft:nether_bricks
fill 313 279 490 316 279 493 minecraft:red_nether_bricks
fill 313 279 494 316 279 497 minecraft:nether_bricks
fill 313 279 498 316 279 501 minecraft:red_nether_bricks
fill 313 279 502 316 279 504 minecraft:nether_bricks
fill 317 279 464 320 279 465 minecraft:red_nether_bricks
fill 317 279 466 320 279 469 minecraft:nether_bricks
fill 317 279 470 320 279 473 minecraft:red_nether_bricks
fill 317 279 474 320 279 477 minecraft:nether_bricks
fill 317 279 478 320 279 481 minecraft:red_nether_bricks
fill 317 279 482 320 279 485 minecraft:nether_bricks
fill 317 279 486 320 279 489 minecraft:red_nether_bricks
fill 317 279 490 320 279 493 minecraft:nether_bricks
fill 317 279 494 320 279 497 minecraft:red_nether_bricks
fill 317 279 498 320 279 501 minecraft:nether_bricks
fill 317 279 502 320 279 504 minecraft:red_nether_bricks
fill 321 279 464 323 279 465 minecraft:nether_bricks
fill 321 279 466 323 279 469 minecraft:red_nether_bricks
fill 321 279 470 323 279 473 minecraft:nether_bricks
fill 321 279 474 323 279 477 minecraft:red_nether_bricks
fill 321 279 478 323 279 481 minecraft:nether_bricks
fill 321 279 482 323 279 485 minecraft:red_nether_bricks
fill 321 279 486 323 279 489 minecraft:nether_bricks
fill 321 279 490 323 279 493 minecraft:red_nether_bricks
fill 321 279 494 323 279 497 minecraft:nether_bricks
fill 321 279 498 323 279 501 minecraft:red_nether_bricks
fill 321 279 502 323 279 504 minecraft:nether_bricks
fill 283 280 466 323 280 466 minecraft:polished_blackstone_bricks
fill 283 280 467 284 280 469 minecraft:red_nether_bricks
fill 283 280 470 323 280 470 minecraft:polished_blackstone_bricks
fill 283 280 471 284 280 473 minecraft:nether_bricks
fill 283 280 474 323 280 474 minecraft:polished_blackstone_bricks
fill 283 280 475 284 280 477 minecraft:red_nether_bricks
fill 283 280 478 323 280 478 minecraft:polished_blackstone_bricks
fill 283 280 479 284 280 481 minecraft:nether_bricks
fill 283 280 482 301 280 482 minecraft:polished_blackstone_bricks
fill 283 280 483 284 280 485 minecraft:red_nether_bricks
fill 283 280 486 323 280 486 minecraft:polished_blackstone_bricks
fill 283 280 487 284 280 489 minecraft:nether_bricks
fill 283 280 490 323 280 490 minecraft:polished_blackstone_bricks
fill 283 280 491 284 280 493 minecraft:red_nether_bricks
fill 283 280 494 323 280 494 minecraft:polished_blackstone_bricks
fill 283 280 495 284 280 497 minecraft:nether_bricks
fill 283 280 498 323 280 498 minecraft:polished_blackstone_bricks
fill 283 280 499 284 280 501 minecraft:red_nether_bricks
fill 283 280 502 323 280 502 minecraft:polished_blackstone_bricks
fill 283 280 503 284 280 504 minecraft:nether_bricks
fill 285 280 464 285 280 465 minecraft:polished_blackstone_bricks
fill 285 280 467 285 280 469 minecraft:polished_blackstone_bricks
fill 285 280 471 285 280 473 minecraft:polished_blackstone_bricks
fill 285 280 475 285 280 477 minecraft:polished_blackstone_bricks
fill 285 280 479 285 280 481 minecraft:polished_blackstone_bricks
fill 285 280 483 285 280 485 minecraft:polished_blackstone_bricks
fill 285 280 487 285 280 489 minecraft:polished_blackstone_bricks
fill 285 280 491 285 280 493 minecraft:polished_blackstone_bricks
fill 285 280 495 285 280 497 minecraft:polished_blackstone_bricks
fill 285 280 499 285 280 501 minecraft:polished_blackstone_bricks
fill 285 280 503 285 280 504 minecraft:polished_blackstone_bricks
fill 286 280 464 288 280 465 minecraft:red_nether_bricks
fill 286 280 467 288 280 469 minecraft:nether_bricks
fill 286 280 471 288 280 473 minecraft:red_nether_bricks
fill 286 280 475 288 280 477 minecraft:nether_bricks
fill 286 280 479 288 280 481 minecraft:red_nether_bricks
fill 286 280 483 288 280 485 minecraft:nether_bricks
fill 286 280 487 288 280 489 minecraft:red_nether_bricks
fill 286 280 491 288 280 493 minecraft:nether_bricks
fill 286 280 495 288 280 497 minecraft:red_nether_bricks
fill 286 280 499 288 280 501 minecraft:nether_bricks
fill 286 280 503 288 280 504 minecraft:red_nether_bricks
fill 289 280 464 289 280 465 minecraft:polished_blackstone_bricks
fill 289 280 467 289 280 469 minecraft:polished_blackstone_bricks
fill 289 280 471 289 280 473 minecraft:polished_blackstone_bricks
fill 289 280 475 289 280 477 minecraft:polished_blackstone_bricks
fill 289 280 479 289 280 481 minecraft:polished_blackstone_bricks
fill 289 280 483 289 280 485 minecraft:polished_blackstone_bricks
fill 289 280 487 289 280 489 minecraft:polished_blackstone_bricks
fill 289 280 491 289 280 493 minecraft:polished_blackstone_bricks
fill 289 280 495 289 280 497 minecraft:polished_blackstone_bricks
fill 289 280 499 289 280 501 minecraft:polished_blackstone_bricks
fill 289 280 503 289 280 504 minecraft:polished_blackstone_bricks
fill 290 280 464 292 280 465 minecraft:nether_bricks
fill 290 280 467 292 280 469 minecraft:red_nether_bricks
fill 290 280 471 292 280 473 minecraft:nether_bricks
fill 290 280 475 292 280 477 minecraft:red_nether_bricks
fill 290 280 479 292 280 481 minecraft:nether_bricks
fill 290 280 483 292 280 485 minecraft:red_nether_bricks
fill 290 280 487 292 280 489 minecraft:nether_bricks
fill 290 280 491 292 280 493 minecraft:red_nether_bricks
fill 290 280 495 292 280 497 minecraft:nether_bricks
fill 290 280 499 292 280 501 minecraft:red_nether_bricks
fill 290 280 503 292 280 504 minecraft:nether_bricks
fill 293 280 464 293 280 465 minecraft:polished_blackstone_bricks
fill 293 280 467 293 280 469 minecraft:polished_blackstone_bricks
fill 293 280 471 293 280 473 minecraft:polished_blackstone_bricks
fill 293 280 475 293 280 477 minecraft:polished_blackstone_bricks
fill 293 280 479 293 280 481 minecraft:polished_blackstone_bricks
fill 293 280 483 293 280 485 minecraft:polished_blackstone_bricks
fill 293 280 487 293 280 489 minecraft:polished_blackstone_bricks
fill 293 280 491 293 280 493 minecraft:polished_blackstone_bricks
fill 293 280 495 293 280 497 minecraft:polished_blackstone_bricks
fill 293 280 499 293 280 501 minecraft:polished_blackstone_bricks
fill 293 280 503 293 280 504 minecraft:polished_blackstone_bricks
fill 294 280 464 296 280 465 minecraft:red_nether_bricks
fill 294 280 467 296 280 469 minecraft:nether_bricks
fill 294 280 471 296 280 473 minecraft:red_nether_bricks
fill 294 280 475 296 280 477 minecraft:nether_bricks
fill 294 280 479 296 280 481 minecraft:red_nether_bricks
fill 294 280 483 296 280 485 minecraft:nether_bricks
fill 294 280 487 296 280 489 minecraft:red_nether_bricks
fill 294 280 491 296 280 493 minecraft:nether_bricks
fill 294 280 495 296 280 497 minecraft:red_nether_bricks
fill 294 280 499 296 280 501 minecraft:nether_bricks
fill 294 280 503 296 280 504 minecraft:red_nether_bricks
fill 297 280 464 297 280 465 minecraft:polished_blackstone_bricks
fill 297 280 467 297 280 469 minecraft:polished_blackstone_bricks
fill 297 280 471 297 280 473 minecraft:polished_blackstone_bricks
fill 297 280 475 297 280 477 minecraft:polished_blackstone_bricks
fill 297 280 479 297 280 481 minecraft:polished_blackstone_bricks
fill 297 280 483 297 280 485 minecraft:polished_blackstone_bricks
fill 297 280 487 297 280 489 minecraft:polished_blackstone_bricks
fill 297 280 491 297 280 493 minecraft:polished_blackstone_bricks
fill 297 280 495 297 280 497 minecraft:polished_blackstone_bricks
fill 297 280 499 297 280 501 minecraft:polished_blackstone_bricks
fill 297 280 503 297 280 504 minecraft:polished_blackstone_bricks
fill 298 280 464 300 280 465 minecraft:nether_bricks
fill 298 280 467 300 280 469 minecraft:red_nether_bricks
fill 298 280 471 300 280 473 minecraft:nether_bricks
fill 298 280 475 300 280 477 minecraft:red_nether_bricks
fill 298 280 479 300 280 481 minecraft:nether_bricks
fill 298 280 483 300 280 485 minecraft:red_nether_bricks
fill 298 280 487 300 280 489 minecraft:nether_bricks
fill 298 280 491 300 280 493 minecraft:red_nether_bricks
fill 298 280 495 300 280 497 minecraft:nether_bricks
fill 298 280 499 300 280 501 minecraft:red_nether_bricks
fill 298 280 503 300 280 504 minecraft:nether_bricks
fill 301 280 464 301 280 465 minecraft:polished_blackstone_bricks
fill 301 280 467 301 280 469 minecraft:polished_blackstone_bricks
fill 301 280 471 301 280 473 minecraft:polished_blackstone_bricks
fill 301 280 475 301 280 477 minecraft:polished_blackstone_bricks
fill 301 280 479 301 280 481 minecraft:polished_blackstone_bricks
fill 301 280 483 301 280 485 minecraft:polished_blackstone_bricks
fill 301 280 487 301 280 489 minecraft:polished_blackstone_bricks
fill 301 280 491 301 280 493 minecraft:polished_blackstone_bricks
fill 301 280 495 301 280 497 minecraft:polished_blackstone_bricks
fill 301 280 499 301 280 501 minecraft:polished_blackstone_bricks
fill 301 280 503 301 280 504 minecraft:polished_blackstone_bricks
fill 302 280 464 304 280 465 minecraft:red_nether_bricks
fill 302 280 467 304 280 469 minecraft:nether_bricks
fill 302 280 471 304 280 473 minecraft:red_nether_bricks
fill 302 280 475 304 280 477 minecraft:nether_bricks
fill 302 280 479 302 280 480 minecraft:red_nether_bricks
fill 302 280 481 302 280 483 minecraft:shroomlight
fill 302 280 484 302 280 485 minecraft:nether_bricks
fill 302 280 487 304 280 489 minecraft:red_nether_bricks
fill 302 280 491 304 280 493 minecraft:nether_bricks
fill 302 280 495 304 280 497 minecraft:red_nether_bricks
fill 302 280 499 304 280 501 minecraft:nether_bricks
fill 302 280 503 304 280 504 minecraft:red_nether_bricks
setblock 303 280 479 minecraft:red_nether_bricks
fill 303 280 480 303 280 481 minecraft:shroomlight
fill 303 280 483 303 280 484 minecraft:shroomlight
setblock 303 280 485 minecraft:nether_bricks
fill 304 280 479 304 280 480 minecraft:shroomlight
fill 304 280 484 304 280 485 minecraft:shroomlight
fill 305 280 464 305 280 465 minecraft:polished_blackstone_bricks
fill 305 280 467 305 280 469 minecraft:polished_blackstone_bricks
fill 305 280 471 305 280 473 minecraft:polished_blackstone_bricks
fill 305 280 475 305 280 477 minecraft:polished_blackstone_bricks
fill 305 280 479 306 280 479 minecraft:shroomlight
fill 305 280 485 306 280 485 minecraft:shroomlight
fill 305 280 487 305 280 489 minecraft:polished_blackstone_bricks
fill 305 280 491 305 280 493 minecraft:polished_blackstone_bricks
fill 305 280 495 305 280 497 minecraft:polished_blackstone_bricks
fill 305 280 499 305 280 501 minecraft:polished_blackstone_bricks
fill 305 280 503 305 280 504 minecraft:polished_blackstone_bricks
fill 306 280 464 308 280 465 minecraft:nether_bricks
fill 306 280 467 308 280 469 minecraft:red_nether_bricks
fill 306 280 471 308 280 473 minecraft:nether_bricks
fill 306 280 475 308 280 477 minecraft:red_nether_bricks
fill 306 280 480 307 280 480 minecraft:shroomlight
fill 306 280 484 307 280 484 minecraft:shroomlight
fill 306 280 487 308 280 489 minecraft:nether_bricks
fill 306 280 491 308 280 493 minecraft:red_nether_bricks
fill 306 280 495 308 280 497 minecraft:nether_bricks
fill 306 280 499 308 280 501 minecraft:red_nether_bricks
fill 306 280 503 308 280 504 minecraft:nether_bricks
fill 307 280 479 308 280 479 minecraft:nether_bricks
fill 307 280 481 308 280 481 minecraft:shroomlight
fill 307 280 483 308 280 483 minecraft:shroomlight
fill 307 280 485 308 280 485 minecraft:red_nether_bricks
setblock 308 280 480 minecraft:nether_bricks
setblock 308 280 482 minecraft:shroomlight
setblock 308 280 484 minecraft:red_nether_bricks
fill 309 280 464 309 280 465 minecraft:polished_blackstone_bricks
fill 309 280 467 309 280 469 minecraft:polished_blackstone_bricks
fill 309 280 471 309 280 473 minecraft:polished_blackstone_bricks
fill 309 280 475 309 280 477 minecraft:polished_blackstone_bricks
fill 309 280 479 309 280 485 minecraft:polished_blackstone_bricks
fill 309 280 487 309 280 489 minecraft:polished_blackstone_bricks
fill 309 280 491 309 280 493 minecraft:polished_blackstone_bricks
fill 309 280 495 309 280 497 minecraft:polished_blackstone_bricks
fill 309 280 499 309 280 501 minecraft:polished_blackstone_bricks
fill 309 280 503 309 280 504 minecraft:polished_blackstone_bricks
fill 310 280 464 312 280 465 minecraft:red_nether_bricks
fill 310 280 467 312 280 469 minecraft:nether_bricks
fill 310 280 471 312 280 473 minecraft:red_nether_bricks
fill 310 280 475 312 280 477 minecraft:nether_bricks
fill 310 280 479 312 280 481 minecraft:red_nether_bricks
fill 310 280 482 323 280 482 minecraft:polished_blackstone_bricks
fill 310 280 483 312 280 485 minecraft:nether_bricks
fill 310 280 487 312 280 489 minecraft:red_nether_bricks
fill 310 280 491 312 280 493 minecraft:nether_bricks
fill 310 280 495 312 280 497 minecraft:red_nether_bricks
fill 310 280 499 312 280 501 minecraft:nether_bricks
fill 310 280 503 312 280 504 minecraft:red_nether_bricks
fill 313 280 464 313 280 465 minecraft:polished_blackstone_bricks
fill 313 280 467 313 280 469 minecraft:polished_blackstone_bricks
fill 313 280 471 313 280 473 minecraft:polished_blackstone_bricks
fill 313 280 475 313 280 477 minecraft:polished_blackstone_bricks
fill 313 280 479 313 280 481 minecraft:polished_blackstone_bricks
fill 313 280 483 313 280 485 minecraft:polished_blackstone_bricks
fill 313 280 487 313 280 489 minecraft:polished_blackstone_bricks
fill 313 280 491 313 280 493 minecraft:polished_blackstone_bricks
fill 313 280 495 313 280 497 minecraft:polished_blackstone_bricks
fill 313 280 499 313 280 501 minecraft:polished_blackstone_bricks
fill 313 280 503 313 280 504 minecraft:polished_blackstone_bricks
fill 314 280 464 316 280 465 minecraft:nether_bricks
fill 314 280 467 316 280 469 minecraft:red_nether_bricks
fill 314 280 471 316 280 473 minecraft:nether_bricks
fill 314 280 475 316 280 477 minecraft:red_nether_bricks
fill 314 280 479 316 280 481 minecraft:nether_bricks
fill 314 280 483 316 280 485 minecraft:red_nether_bricks
fill 314 280 487 316 280 489 minecraft:nether_bricks
fill 314 280 491 316 280 493 minecraft:red_nether_bricks
fill 314 280 495 316 280 497 minecraft:nether_bricks
fill 314 280 499 316 280 501 minecraft:red_nether_bricks
fill 314 280 503 316 280 504 minecraft:nether_bricks
fill 317 280 464 317 280 465 minecraft:polished_blackstone_bricks
fill 317 280 467 317 280 469 minecraft:polished_blackstone_bricks
fill 317 280 471 317 280 473 minecraft:polished_blackstone_bricks
fill 317 280 475 317 280 477 minecraft:polished_blackstone_bricks
fill 317 280 479 317 280 481 minecraft:polished_blackstone_bricks
fill 317 280 483 317 280 485 minecraft:polished_blackstone_bricks
fill 317 280 487 317 280 489 minecraft:polished_blackstone_bricks
fill 317 280 491 317 280 493 minecraft:polished_blackstone_bricks
fill 317 280 495 317 280 497 minecraft:polished_blackstone_bricks
fill 317 280 499 317 280 501 minecraft:polished_blackstone_bricks
fill 317 280 503 317 280 504 minecraft:polished_blackstone_bricks
fill 318 280 464 320 280 465 minecraft:red_nether_bricks
fill 318 280 467 320 280 469 minecraft:nether_bricks
fill 318 280 471 320 280 473 minecraft:red_nether_bricks
fill 318 280 475 320 280 477 minecraft:nether_bricks
fill 318 280 479 320 280 481 minecraft:red_nether_bricks
fill 318 280 483 320 280 485 minecraft:nether_bricks
fill 318 280 487 320 280 489 minecraft:red_nether_bricks
fill 318 280 491 320 280 493 minecraft:nether_bricks
fill 318 280 495 320 280 497 minecraft:red_nether_bricks
fill 318 280 499 320 280 501 minecraft:nether_bricks
fill 318 280 503 320 280 504 minecraft:red_nether_bricks
fill 321 280 464 321 280 465 minecraft:polished_blackstone_bricks
fill 321 280 467 321 280 469 minecraft:polished_blackstone_bricks
fill 321 280 471 321 280 473 minecraft:polished_blackstone_bricks
fill 321 280 475 321 280 477 minecraft:polished_blackstone_bricks
fill 321 280 479 321 280 481 minecraft:polished_blackstone_bricks
fill 321 280 483 321 280 485 minecraft:polished_blackstone_bricks
fill 321 280 487 321 280 489 minecraft:polished_blackstone_bricks
fill 321 280 491 321 280 493 minecraft:polished_blackstone_bricks
fill 321 280 495 321 280 497 minecraft:polished_blackstone_bricks
fill 321 280 499 321 280 501 minecraft:polished_blackstone_bricks
fill 321 280 503 321 280 504 minecraft:polished_blackstone_bricks
fill 322 280 464 323 280 465 minecraft:nether_bricks
fill 322 280 467 323 280 469 minecraft:red_nether_bricks
fill 322 280 471 323 280 473 minecraft:nether_bricks
fill 322 280 475 323 280 477 minecraft:red_nether_bricks
fill 322 280 479 323 280 481 minecraft:nether_bricks
fill 322 280 483 323 280 485 minecraft:red_nether_bricks
fill 322 280 487 323 280 489 minecraft:nether_bricks
fill 322 280 491 323 280 493 minecraft:red_nether_bricks
fill 322 280 495 323 280 497 minecraft:nether_bricks
fill 322 280 499 323 280 501 minecraft:red_nether_bricks
fill 322 280 503 323 280 504 minecraft:nether_bricks
fill 283 284 464 285 300 464 minecraft:polished_blackstone_bricks
fill 283 284 474 283 300 476 minecraft:polished_blackstone_bricks
fill 283 284 486 283 300 488 minecraft:polished_blackstone_bricks
fill 283 284 498 283 300 500 minecraft:polished_blackstone_bricks
fill 284 284 473 284 285 475 minecraft:polished_blackstone_bricks
fill 284 284 485 284 285 487 minecraft:polished_blackstone_bricks
fill 284 284 497 284 285 499 minecraft:polished_blackstone_bricks
fill 289 284 504 291 300 504 minecraft:polished_blackstone_bricks
fill 290 284 503 292 285 503 minecraft:polished_blackstone_bricks
fill 294 284 465 296 285 465 minecraft:polished_blackstone_bricks
fill 295 284 464 309 284 464 minecraft:polished_blackstone_bricks
fill 298 284 465 308 285 471 minecraft:polished_blackstone_bricks
fill 301 284 504 303 300 504 minecraft:polished_blackstone_bricks
fill 302 284 503 304 285 503 minecraft:polished_blackstone_bricks
fill 313 284 504 315 300 504 minecraft:polished_blackstone_bricks
fill 314 284 503 316 285 503 minecraft:polished_blackstone_bricks
fill 318 284 465 320 285 465 minecraft:polished_blackstone_bricks
fill 318 284 488 323 284 496 minecraft:polished_blackstone_bricks
fill 319 284 464 321 300 464 minecraft:polished_blackstone_bricks
fill 320 284 468 320 297 468 minecraft:gilded_blackstone
fill 322 284 473 322 285 475 minecraft:polished_blackstone_bricks
fill 322 284 485 322 285 487 minecraft:polished_blackstone_bricks
fill 322 284 497 322 285 499 minecraft:polished_blackstone_bricks
fill 323 284 472 323 300 474 minecraft:polished_blackstone_bricks
fill 323 284 484 323 300 486 minecraft:polished_blackstone_bricks
fill 323 284 497 323 300 498 minecraft:polished_blackstone_bricks
fill 283 285 467 283 285 472 minecraft:nether_bricks
fill 283 285 479 283 285 484 minecraft:nether_bricks
fill 283 285 491 283 285 496 minecraft:nether_bricks
fill 283 285 503 283 285 504 minecraft:nether_bricks
fill 284 285 504 287 285 504 minecraft:nether_bricks
fill 287 285 464 292 285 464 minecraft:nether_bricks
fill 294 285 504 299 285 504 minecraft:nether_bricks
fill 295 285 464 298 300 464 minecraft:polished_blackstone_bricks
fill 299 285 464 304 285 464 minecraft:nether_bricks
fill 305 285 464 309 285 464 minecraft:polished_blackstone_bricks
fill 306 285 504 311 285 504 minecraft:nether_bricks
fill 311 285 464 316 285 464 minecraft:nether_bricks
fill 318 285 488 322 285 496 minecraft:polished_blackstone_bricks
fill 318 285 504 323 285 504 minecraft:nether_bricks
fill 323 285 464 323 285 469 minecraft:nether_bricks
fill 323 285 476 323 285 481 minecraft:nether_bricks
fill 323 285 488 323 285 493 minecraft:nether_bricks
fill 323 285 494 323 285 496 minecraft:polished_blackstone_bricks
fill 323 285 500 323 285 503 minecraft:nether_bricks
fill 282 286 469 282 291 472 minecraft:shroomlight
fill 282 286 481 282 291 484 minecraft:shroomlight
fill 282 286 493 282 291 496 minecraft:shroomlight
fill 282 286 505 285 291 505 minecraft:shroomlight
fill 289 286 463 292 291 463 minecraft:shroomlight
fill 294 286 505 297 291 505 minecraft:shroomlight
setblock 298 286 465 minecraft:shroomlight
fill 298 286 466 298 300 466 minecraft:polished_blackstone_bricks
setblock 298 286 467 minecraft:shroomlight
fill 298 286 468 298 300 468 minecraft:polished_blackstone_bricks
setblock 298 286 469 minecraft:shroomlight
fill 298 286 470 298 300 470 minecraft:polished_blackstone_bricks
setblock 298 286 471 minecraft:shroomlight
setblock 299 286 464 minecraft:shroomlight
fill 299 286 465 299 300 465 minecraft:polished_blackstone_bricks
setblock 299 286 466 minecraft:shroomlight
fill 299 286 467 299 300 467 minecraft:polished_blackstone_bricks
setblock 299 286 468 minecraft:shroomlight
fill 299 286 469 299 300 469 minecraft:polished_blackstone_bricks
setblock 299 286 470 minecraft:shroomlight
fill 299 286 471 299 300 471 minecraft:polished_blackstone_bricks
fill 300 286 464 300 300 464 minecraft:polished_blackstone_bricks
setblock 300 286 465 minecraft:shroomlight
fill 300 286 466 300 300 466 minecraft:polished_blackstone_bricks
setblock 300 286 467 minecraft:shroomlight
fill 300 286 468 300 300 468 minecraft:polished_blackstone_bricks
setblock 300 286 469 minecraft:shroomlight
fill 300 286 470 300 300 470 minecraft:polished_blackstone_bricks
setblock 300 286 471 minecraft:shroomlight
fill 301 286 463 301 286 464 minecraft:shroomlight
fill 301 286 465 301 300 465 minecraft:polished_blackstone_bricks
setblock 301 286 466 minecraft:shroomlight
fill 301 286 467 301 300 467 minecraft:polished_blackstone_bricks
setblock 301 286 468 minecraft:shroomlight
fill 301 286 469 301 300 469 minecraft:polished_blackstone_bricks
setblock 301 286 470 minecraft:shroomlight
fill 301 286 471 301 300 471 minecraft:polished_blackstone_bricks
fill 302 286 463 304 291 463 minecraft:shroomlight
fill 302 286 464 302 300 464 minecraft:polished_blackstone_bricks
setblock 302 286 465 minecraft:shroomlight
fill 302 286 466 302 300 466 minecraft:polished_blackstone_bricks
setblock 302 286 467 minecraft:shroomlight
fill 302 286 468 302 300 468 minecraft:polished_blackstone_bricks
setblock 302 286 469 minecraft:shroomlight
fill 302 286 470 302 300 470 minecraft:polished_blackstone_bricks
setblock 302 286 471 minecraft:shroomlight
setblock 303 286 464 minecraft:shroomlight
fill 303 286 465 303 300 465 minecraft:polished_blackstone_bricks
setblock 303 286 466 minecraft:shroomlight
fill 303 286 467 303 300 467 minecraft:polished_blackstone_bricks
setblock 303 286 468 minecraft:shroomlight
fill 303 286 469 303 300 469 minecraft:polished_blackstone_bricks
setblock 303 286 470 minecraft:shroomlight
fill 303 286 471 303 300 471 minecraft:polished_blackstone_bricks
fill 304 286 464 304 300 464 minecraft:polished_blackstone_bricks
setblock 304 286 465 minecraft:shroomlight
fill 304 286 466 304 300 466 minecraft:polished_blackstone_bricks
setblock 304 286 467 minecraft:shroomlight
fill 304 286 468 304 300 468 minecraft:polished_blackstone_bricks
setblock 304 286 469 minecraft:shroomlight
fill 304 286 470 304 300 470 minecraft:polished_blackstone_bricks
setblock 304 286 471 minecraft:shroomlight
setblock 305 286 464 minecraft:shroomlight
fill 305 286 465 305 300 465 minecraft:polished_blackstone_bricks
setblock 305 286 466 minecraft:shroomlight
fill 305 286 467 305 300 467 minecraft:polished_blackstone_bricks
setblock 305 286 468 minecraft:shroomlight
fill 305 286 469 305 300 469 minecraft:polished_blackstone_bricks
setblock 305 286 470 minecraft:shroomlight
fill 305 286 471 305 300 471 minecraft:polished_blackstone_bricks
fill 306 286 464 306 300 464 minecraft:polished_blackstone_bricks
setblock 306 286 465 minecraft:shroomlight
fill 306 286 466 306 300 466 minecraft:polished_blackstone_bricks
setblock 306 286 467 minecraft:shroomlight
fill 306 286 468 306 300 468 minecraft:polished_blackstone_bricks
setblock 306 286 469 minecraft:shroomlight
fill 306 286 470 306 300 470 minecraft:polished_blackstone_bricks
setblock 306 286 471 minecraft:shroomlight
fill 306 286 505 309 291 505 minecraft:shroomlight
setblock 307 286 464 minecraft:shroomlight
fill 307 286 465 307 300 465 minecraft:polished_blackstone_bricks
setblock 307 286 466 minecraft:shroomlight
fill 307 286 467 307 300 467 minecraft:polished_blackstone_bricks
setblock 307 286 468 minecraft:shroomlight
fill 307 286 469 307 300 469 minecraft:polished_blackstone_bricks
setblock 307 286 470 minecraft:shroomlight
fill 307 286 471 307 300 471 minecraft:polished_blackstone_bricks
fill 308 286 464 309 300 464 minecraft:polished_blackstone_bricks
setblock 308 286 465 minecraft:shroomlight
fill 308 286 466 308 300 466 minecraft:polished_blackstone_bricks
setblock 308 286 467 minecraft:shroomlight
fill 308 286 468 308 300 468 minecraft:polished_blackstone_bricks
setblock 308 286 469 minecraft:shroomlight
fill 308 286 470 308 300 470 minecraft:polished_blackstone_bricks
setblock 308 286 471 minecraft:shroomlight
fill 313 286 463 316 291 463 minecraft:shroomlight
fill 318 286 488 318 300 488 minecraft:polished_blackstone_bricks
setblock 318 286 489 minecraft:shroomlight
fill 318 286 490 318 300 490 minecraft:polished_blackstone_bricks
setblock 318 286 491 minecraft:shroomlight
fill 318 286 492 318 300 492 minecraft:polished_blackstone_bricks
setblock 318 286 493 minecraft:shroomlight
fill 318 286 494 318 300 494 minecraft:polished_blackstone_bricks
setblock 318 286 495 minecraft:shroomlight
fill 318 286 496 318 300 496 minecraft:polished_blackstone_bricks
fill 318 286 505 321 291 505 minecraft:shroomlight
setblock 319 286 488 minecraft:shroomlight
fill 319 286 489 319 300 489 minecraft:polished_blackstone_bricks
setblock 319 286 490 minecraft:shroomlight
fill 319 286 491 319 300 491 minecraft:polished_blackstone_bricks
setblock 319 286 492 minecraft:shroomlight
fill 319 286 493 319 300 493 minecraft:polished_blackstone_bricks
setblock 319 286 494 minecraft:shroomlight
fill 319 286 495 319 300 495 minecraft:polished_blackstone_bricks
setblock 319 286 496 minecraft:shroomlight
fill 320 286 488 320 300 488 minecraft:polished_blackstone_bricks
setblock 320 286 489 minecraft:shroomlight
fill 320 286 490 320 300 490 minecraft:polished_blackstone_bricks
setblock 320 286 491 minecraft:shroomlight
fill 320 286 492 320 300 492 minecraft:polished_blackstone_bricks
setblock 320 286 493 minecraft:shroomlight
fill 320 286 494 320 300 494 minecraft:polished_blackstone_bricks
setblock 320 286 495 minecraft:shroomlight
fill 320 286 496 320 300 496 minecraft:polished_blackstone_bricks
setblock 321 286 488 minecraft:shroomlight
fill 321 286 489 321 300 489 minecraft:polished_blackstone_bricks
setblock 321 286 490 minecraft:shroomlight
fill 321 286 491 321 300 491 minecraft:polished_blackstone_bricks
setblock 321 286 492 minecraft:shroomlight
fill 321 286 493 321 300 493 minecraft:polished_blackstone_bricks
setblock 321 286 494 minecraft:shroomlight
fill 321 286 495 321 300 495 minecraft:polished_blackstone_bricks
setblock 321 286 496 minecraft:shroomlight
fill 322 286 488 322 300 488 minecraft:polished_blackstone_bricks
setblock 322 286 489 minecraft:shroomlight
fill 322 286 490 322 300 490 minecraft:polished_blackstone_bricks
setblock 322 286 491 minecraft:shroomlight
fill 322 286 492 322 300 492 minecraft:polished_blackstone_bricks
setblock 322 286 493 minecraft:shroomlight
fill 322 286 494 322 300 494 minecraft:polished_blackstone_bricks
setblock 322 286 495 minecraft:shroomlight
fill 322 286 496 322 300 496 minecraft:polished_blackstone_bricks
fill 323 286 488 324 286 488 minecraft:shroomlight
fill 323 286 489 323 300 489 minecraft:polished_blackstone_bricks
fill 323 286 490 324 286 490 minecraft:shroomlight
fill 323 286 491 323 300 491 minecraft:polished_blackstone_bricks
setblock 323 286 492 minecraft:shroomlight
fill 323 286 493 323 300 493 minecraft:polished_blackstone_bricks
setblock 323 286 494 minecraft:shroomlight
fill 323 286 495 323 300 495 minecraft:polished_blackstone_bricks
setblock 323 286 496 minecraft:shroomlight
fill 324 286 464 324 291 467 minecraft:shroomlight
fill 324 286 476 324 291 479 minecraft:shroomlight
fill 324 286 489 324 292 489 minecraft:shroomlight
fill 324 286 491 324 291 491 minecraft:shroomlight
fill 324 286 500 324 291 503 minecraft:shroomlight
setblock 285 287 466 minecraft:light[level=14]
setblock 285 287 474 minecraft:light[level=14]
setblock 285 287 482 minecraft:light[level=14]
setblock 285 287 490 minecraft:light[level=14]
setblock 285 287 498 minecraft:light[level=14]
setblock 293 287 466 minecraft:light[level=14]
setblock 293 287 474 minecraft:light[level=14]
setblock 293 287 482 minecraft:light[level=14]
setblock 293 287 490 minecraft:light[level=14]
setblock 293 287 498 minecraft:light[level=14]
fill 298 287 465 298 288 465 minecraft:polished_blackstone_bricks
fill 298 287 467 298 288 467 minecraft:polished_blackstone_bricks
fill 298 287 469 298 288 469 minecraft:polished_blackstone_bricks
fill 298 287 471 298 288 471 minecraft:polished_blackstone_bricks
fill 299 287 464 299 288 464 minecraft:polished_blackstone_bricks
fill 299 287 466 299 288 466 minecraft:polished_blackstone_bricks
fill 299 287 468 299 288 468 minecraft:polished_blackstone_bricks
fill 299 287 470 299 288 470 minecraft:polished_blackstone_bricks
fill 300 287 465 300 288 465 minecraft:polished_blackstone_bricks
fill 300 287 467 300 288 467 minecraft:polished_blackstone_bricks
fill 300 287 469 300 288 469 minecraft:polished_blackstone_bricks
fill 300 287 471 300 288 471 minecraft:polished_blackstone_bricks
fill 301 287 463 301 291 463 minecraft:shroomlight
fill 301 287 464 301 288 464 minecraft:polished_blackstone_bricks
fill 301 287 466 301 288 466 minecraft:polished_blackstone_bricks
fill 301 287 468 301 288 468 minecraft:polished_blackstone_bricks
fill 301 287 470 301 288 470 minecraft:polished_blackstone_bricks
setblock 301 287 474 minecraft:light[level=14]
setblock 301 287 482 minecraft:light[level=14]
setblock 301 287 490 minecraft:light[level=14]
setblock 301 287 498 minecraft:light[level=14]
fill 302 287 465 302 288 465 minecraft:polished_blackstone_bricks
fill 302 287 467 302 288 467 minecraft:polished_blackstone_bricks
fill 302 287 469 302 288 469 minecraft:polished_blackstone_bricks
fill 302 287 471 302 288 471 minecraft:polished_blackstone_bricks
fill 303 287 464 303 288 464 minecraft:polished_blackstone_bricks
fill 303 287 466 303 288 466 minecraft:polished_blackstone_bricks
fill 303 287 468 303 288 468 minecraft:polished_blackstone_bricks
fill 303 287 470 303 288 470 minecraft:polished_blackstone_bricks
fill 304 287 465 304 288 465 minecraft:polished_blackstone_bricks
fill 304 287 467 304 288 467 minecraft:polished_blackstone_bricks
fill 304 287 469 304 288 469 minecraft:polished_blackstone_bricks
fill 304 287 471 304 288 471 minecraft:polished_blackstone_bricks
fill 305 287 464 305 288 464 minecraft:polished_blackstone_bricks
fill 305 287 466 305 288 466 minecraft:polished_blackstone_bricks
fill 305 287 468 305 288 468 minecraft:polished_blackstone_bricks
fill 305 287 470 305 288 470 minecraft:polished_blackstone_bricks
fill 306 287 465 306 288 465 minecraft:polished_blackstone_bricks
fill 306 287 467 306 288 467 minecraft:polished_blackstone_bricks
fill 306 287 469 306 288 469 minecraft:polished_blackstone_bricks
fill 306 287 471 306 288 471 minecraft:polished_blackstone_bricks
fill 307 287 464 307 288 464 minecraft:polished_blackstone_bricks
fill 307 287 466 307 288 466 minecraft:polished_blackstone_bricks
fill 307 287 468 307 288 468 minecraft:polished_blackstone_bricks
fill 307 287 470 307 288 470 minecraft:polished_blackstone_bricks
fill 308 287 465 308 288 465 minecraft:polished_blackstone_bricks
fill 308 287 467 308 288 467 minecraft:polished_blackstone_bricks
fill 308 287 469 308 288 469 minecraft:polished_blackstone_bricks
fill 308 287 471 308 288 471 minecraft:polished_blackstone_bricks
setblock 309 287 466 minecraft:light[level=14]
setblock 309 287 474 minecraft:light[level=14]
setblock 309 287 482 minecraft:light[level=14]
setblock 309 287 490 minecraft:light[level=14]
setblock 309 287 498 minecraft:light[level=14]
setblock 317 287 466 minecraft:light[level=14]
setblock 317 287 474 minecraft:light[level=14]
setblock 317 287 482 minecraft:light[level=14]
setblock 317 287 490 minecraft:light[level=14]
setblock 317 287 498 minecraft:light[level=14]
fill 318 287 489 318 288 489 minecraft:polished_blackstone_bricks
fill 318 287 491 318 288 491 minecraft:polished_blackstone_bricks
fill 318 287 493 318 288 493 minecraft:polished_blackstone_bricks
fill 318 287 495 318 288 495 minecraft:polished_blackstone_bricks
fill 319 287 488 319 288 488 minecraft:polished_blackstone_bricks
fill 319 287 490 319 288 490 minecraft:polished_blackstone_bricks
fill 319 287 492 319 288 492 minecraft:polished_blackstone_bricks
fill 319 287 494 319 288 494 minecraft:polished_blackstone_bricks
fill 319 287 496 319 288 496 minecraft:polished_blackstone_bricks
fill 320 287 489 320 288 489 minecraft:polished_blackstone_bricks
fill 320 287 491 320 288 491 minecraft:polished_blackstone_bricks
fill 320 287 493 320 288 493 minecraft:polished_blackstone_bricks
fill 320 287 495 320 288 495 minecraft:polished_blackstone_bricks
fill 321 287 488 321 288 488 minecraft:polished_blackstone_bricks
fill 321 287 490 321 288 490 minecraft:polished_blackstone_bricks
fill 321 287 492 321 288 492 minecraft:polished_blackstone_bricks
fill 321 287 494 321 288 494 minecraft:polished_blackstone_bricks
fill 321 287 496 321 288 496 minecraft:polished_blackstone_bricks
fill 322 287 489 322 288 489 minecraft:polished_blackstone_bricks
fill 322 287 491 322 288 491 minecraft:polished_blackstone_bricks
fill 322 287 493 322 288 493 minecraft:polished_blackstone_bricks
fill 322 287 495 322 288 495 minecraft:polished_blackstone_bricks
fill 323 287 488 323 288 488 minecraft:polished_blackstone_bricks
fill 323 287 490 323 288 490 minecraft:polished_blackstone_bricks
fill 323 287 492 323 288 492 minecraft:polished_blackstone_bricks
fill 323 287 494 323 288 494 minecraft:polished_blackstone_bricks
fill 323 287 496 323 288 496 minecraft:polished_blackstone_bricks
fill 324 287 488 324 291 488 minecraft:shroomlight
fill 324 287 490 324 292 490 minecraft:shroomlight
setblock 298 289 465 minecraft:shroomlight
setblock 298 289 467 minecraft:shroomlight
setblock 298 289 469 minecraft:shroomlight
setblock 298 289 471 minecraft:shroomlight
setblock 299 289 464 minecraft:shroomlight
setblock 299 289 466 minecraft:shroomlight
setblock 299 289 468 minecraft:shroomlight
setblock 299 289 470 minecraft:shroomlight
setblock 300 289 465 minecraft:shroomlight
setblock 300 289 467 minecraft:shroomlight
setblock 300 289 469 minecraft:shroomlight
setblock 300 289 471 minecraft:shroomlight
setblock 301 289 464 minecraft:shroomlight
setblock 301 289 466 minecraft:shroomlight
setblock 301 289 468 minecraft:shroomlight
setblock 301 289 470 minecraft:shroomlight
setblock 302 289 465 minecraft:shroomlight
setblock 302 289 467 minecraft:shroomlight
setblock 302 289 469 minecraft:shroomlight
setblock 302 289 471 minecraft:shroomlight
setblock 303 289 464 minecraft:shroomlight
setblock 303 289 466 minecraft:shroomlight
setblock 303 289 468 minecraft:shroomlight
setblock 303 289 470 minecraft:shroomlight
setblock 304 289 465 minecraft:shroomlight
setblock 304 289 467 minecraft:shroomlight
setblock 304 289 469 minecraft:shroomlight
setblock 304 289 471 minecraft:shroomlight
setblock 305 289 464 minecraft:shroomlight
setblock 305 289 466 minecraft:shroomlight
setblock 305 289 468 minecraft:shroomlight
setblock 305 289 470 minecraft:shroomlight
setblock 306 289 465 minecraft:shroomlight
setblock 306 289 467 minecraft:shroomlight
setblock 306 289 469 minecraft:shroomlight
setblock 306 289 471 minecraft:shroomlight
setblock 307 289 464 minecraft:shroomlight
setblock 307 289 466 minecraft:shroomlight
setblock 307 289 468 minecraft:shroomlight
setblock 307 289 470 minecraft:shroomlight
setblock 308 289 465 minecraft:shroomlight
setblock 308 289 467 minecraft:shroomlight
setblock 308 289 469 minecraft:shroomlight
setblock 308 289 471 minecraft:shroomlight
setblock 318 289 489 minecraft:shroomlight
setblock 318 289 491 minecraft:shroomlight
setblock 318 289 493 minecraft:shroomlight
setblock 318 289 495 minecraft:shroomlight
setblock 319 289 488 minecraft:shroomlight
setblock 319 289 490 minecraft:shroomlight
setblock 319 289 492 minecraft:shroomlight
setblock 319 289 494 minecraft:shroomlight
setblock 319 289 496 minecraft:shroomlight
setblock 320 289 489 minecraft:shroomlight
setblock 320 289 491 minecraft:shroomlight
setblock 320 289 493 minecraft:shroomlight
setblock 320 289 495 minecraft:shroomlight
setblock 321 289 488 minecraft:shroomlight
setblock 321 289 490 minecraft:shroomlight
setblock 321 289 492 minecraft:shroomlight
setblock 321 289 494 minecraft:shroomlight
setblock 321 289 496 minecraft:shroomlight
setblock 322 289 489 minecraft:shroomlight
setblock 322 289 491 minecraft:shroomlight
setblock 322 289 493 minecraft:shroomlight
setblock 322 289 495 minecraft:shroomlight
setblock 323 289 488 minecraft:shroomlight
setblock 323 289 490 minecraft:shroomlight
setblock 323 289 492 minecraft:shroomlight
setblock 323 289 494 minecraft:shroomlight
setblock 323 289 496 minecraft:shroomlight
fill 298 290 465 298 291 465 minecraft:polished_blackstone_bricks
fill 298 290 467 298 291 467 minecraft:polished_blackstone_bricks
fill 298 290 469 298 291 469 minecraft:polished_blackstone_bricks
fill 298 290 471 298 291 471 minecraft:polished_blackstone_bricks
fill 299 290 464 299 291 464 minecraft:polished_blackstone_bricks
fill 299 290 466 299 291 466 minecraft:polished_blackstone_bricks
fill 299 290 468 299 291 468 minecraft:polished_blackstone_bricks
fill 299 290 470 299 291 470 minecraft:polished_blackstone_bricks
fill 300 290 465 300 291 465 minecraft:polished_blackstone_bricks
fill 300 290 467 300 291 467 minecraft:polished_blackstone_bricks
fill 300 290 469 300 291 469 minecraft:polished_blackstone_bricks
fill 300 290 471 300 291 471 minecraft:polished_blackstone_bricks
fill 301 290 464 301 291 464 minecraft:polished_blackstone_bricks
fill 301 290 466 301 291 466 minecraft:polished_blackstone_bricks
fill 301 290 468 301 291 468 minecraft:polished_blackstone_bricks
fill 301 290 470 301 291 470 minecraft:polished_blackstone_bricks
fill 302 290 465 302 291 465 minecraft:polished_blackstone_bricks
fill 302 290 467 302 291 467 minecraft:polished_blackstone_bricks
fill 302 290 469 302 291 469 minecraft:polished_blackstone_bricks
fill 302 290 471 302 291 471 minecraft:polished_blackstone_bricks
fill 303 290 464 303 291 464 minecraft:polished_blackstone_bricks
fill 303 290 466 303 291 466 minecraft:polished_blackstone_bricks
fill 303 290 468 303 291 468 minecraft:polished_blackstone_bricks
fill 303 290 470 303 291 470 minecraft:polished_blackstone_bricks
fill 304 290 465 304 291 465 minecraft:polished_blackstone_bricks
fill 304 290 467 304 291 467 minecraft:polished_blackstone_bricks
fill 304 290 469 304 291 469 minecraft:polished_blackstone_bricks
fill 304 290 471 304 291 471 minecraft:polished_blackstone_bricks
fill 305 290 464 305 291 464 minecraft:polished_blackstone_bricks
fill 305 290 466 305 291 466 minecraft:polished_blackstone_bricks
fill 305 290 468 305 291 468 minecraft:polished_blackstone_bricks
fill 305 290 470 305 291 470 minecraft:polished_blackstone_bricks
fill 306 290 465 306 291 465 minecraft:polished_blackstone_bricks
fill 306 290 467 306 291 467 minecraft:polished_blackstone_bricks
fill 306 290 469 306 291 469 minecraft:polished_blackstone_bricks
fill 306 290 471 306 291 471 minecraft:polished_blackstone_bricks
fill 307 290 464 307 291 464 minecraft:polished_blackstone_bricks
fill 307 290 466 307 291 466 minecraft:polished_blackstone_bricks
fill 307 290 468 307 291 468 minecraft:polished_blackstone_bricks
fill 307 290 470 307 291 470 minecraft:polished_blackstone_bricks
fill 308 290 465 308 291 465 minecraft:polished_blackstone_bricks
fill 308 290 467 308 291 467 minecraft:polished_blackstone_bricks
fill 308 290 469 308 291 469 minecraft:polished_blackstone_bricks
fill 308 290 471 308 291 471 minecraft:polished_blackstone_bricks
fill 318 290 489 318 291 489 minecraft:polished_blackstone_bricks
fill 318 290 491 318 291 491 minecraft:polished_blackstone_bricks
fill 318 290 493 318 291 493 minecraft:polished_blackstone_bricks
fill 318 290 495 318 291 495 minecraft:polished_blackstone_bricks
fill 319 290 488 319 291 488 minecraft:polished_blackstone_bricks
fill 319 290 490 319 291 490 minecraft:polished_blackstone_bricks
fill 319 290 492 319 291 492 minecraft:polished_blackstone_bricks
fill 319 290 494 319 291 494 minecraft:polished_blackstone_bricks
fill 319 290 496 319 291 496 minecraft:polished_blackstone_bricks
fill 320 290 489 320 291 489 minecraft:polished_blackstone_bricks
fill 320 290 491 320 291 491 minecraft:polished_blackstone_bricks
fill 320 290 493 320 291 493 minecraft:polished_blackstone_bricks
fill 320 290 495 320 291 495 minecraft:polished_blackstone_bricks
fill 321 290 488 321 291 488 minecraft:polished_blackstone_bricks
fill 321 290 490 321 291 490 minecraft:polished_blackstone_bricks
fill 321 290 492 321 291 492 minecraft:polished_blackstone_bricks
fill 321 290 494 321 291 494 minecraft:polished_blackstone_bricks
fill 321 290 496 321 291 496 minecraft:polished_blackstone_bricks
fill 322 290 489 322 291 489 minecraft:polished_blackstone_bricks
fill 322 290 491 322 291 491 minecraft:polished_blackstone_bricks
fill 322 290 493 322 291 493 minecraft:polished_blackstone_bricks
fill 322 290 495 322 291 495 minecraft:polished_blackstone_bricks
fill 323 290 488 323 291 488 minecraft:polished_blackstone_bricks
fill 323 290 490 323 291 490 minecraft:polished_blackstone_bricks
fill 323 290 492 323 291 492 minecraft:polished_blackstone_bricks
fill 323 290 494 323 291 494 minecraft:polished_blackstone_bricks
fill 323 290 496 323 291 496 minecraft:polished_blackstone_bricks
fill 282 292 469 282 307 469 minecraft:red_nether_bricks
fill 282 292 470 282 292 471 minecraft:shroomlight
fill 282 292 472 282 307 472 minecraft:red_nether_bricks
fill 282 292 481 282 307 481 minecraft:red_nether_bricks
fill 282 292 482 282 292 483 minecraft:shroomlight
fill 282 292 484 282 307 484 minecraft:red_nether_bricks
fill 282 292 493 282 307 493 minecraft:red_nether_bricks
fill 282 292 494 282 292 495 minecraft:shroomlight
fill 282 292 496 282 307 496 minecraft:red_nether_bricks
fill 282 292 505 282 307 505 minecraft:red_nether_bricks
fill 283 292 505 284 292 505 minecraft:shroomlight
fill 285 292 505 285 307 505 minecraft:red_nether_bricks
fill 289 292 463 289 307 463 minecraft:red_nether_bricks
fill 290 292 463 291 292 463 minecraft:shroomlight
fill 292 292 463 292 307 463 minecraft:red_nether_bricks
fill 294 292 505 294 307 505 minecraft:red_nether_bricks
fill 295 292 505 296 292 505 minecraft:shroomlight
fill 297 292 505 297 307 505 minecraft:red_nether_bricks
setblock 298 292 465 minecraft:shroomlight
setblock 298 292 467 minecraft:shroomlight
setblock 298 292 469 minecraft:shroomlight
setblock 298 292 471 minecraft:shroomlight
setblock 299 292 464 minecraft:shroomlight
setblock 299 292 466 minecraft:shroomlight
setblock 299 292 468 minecraft:shroomlight
setblock 299 292 470 minecraft:shroomlight
setblock 300 292 465 minecraft:shroomlight
setblock 300 292 467 minecraft:shroomlight
setblock 300 292 469 minecraft:shroomlight
setblock 300 292 471 minecraft:shroomlight
fill 301 292 463 301 307 463 minecraft:red_nether_bricks
setblock 301 292 464 minecraft:shroomlight
setblock 301 292 466 minecraft:shroomlight
setblock 301 292 468 minecraft:shroomlight
setblock 301 292 470 minecraft:shroomlight
fill 302 292 463 303 292 463 minecraft:shroomlight
setblock 302 292 465 minecraft:shroomlight
setblock 302 292 467 minecraft:shroomlight
setblock 302 292 469 minecraft:shroomlight
setblock 302 292 471 minecraft:shroomlight
setblock 303 292 464 minecraft:shroomlight
setblock 303 292 466 minecraft:shroomlight
setblock 303 292 468 minecraft:shroomlight
setblock 303 292 470 minecraft:shroomlight
fill 304 292 463 304 307 463 minecraft:red_nether_bricks
setblock 304 292 465 minecraft:shroomlight
setblock 304 292 467 minecraft:shroomlight
setblock 304 292 469 minecraft:shroomlight
setblock 304 292 471 minecraft:shroomlight
setblock 305 292 464 minecraft:shroomlight
setblock 305 292 466 minecraft:shroomlight
setblock 305 292 468 minecraft:shroomlight
setblock 305 292 470 minecraft:shroomlight
setblock 306 292 465 minecraft:shroomlight
setblock 306 292 467 minecraft:shroomlight
setblock 306 292 469 minecraft:shroomlight
setblock 306 292 471 minecraft:shroomlight
fill 306 292 505 306 307 505 minecraft:red_nether_bricks
setblock 307 292 464 minecraft:shroomlight
setblock 307 292 466 minecraft:shroomlight
setblock 307 292 468 minecraft:shroomlight
setblock 307 292 470 minecraft:shroomlight
fill 307 292 505 308 292 505 minecraft:shroomlight
setblock 308 292 465 minecraft:shroomlight
setblock 308 292 467 minecraft:shroomlight
setblock 308 292 469 minecraft:shroomlight
setblock 308 292 471 minecraft:shroomlight
fill 309 292 505 309 307 505 minecraft:red_nether_bricks
fill 313 292 463 313 307 463 minecraft:red_nether_bricks
fill 314 292 463 315 292 463 minecraft:shroomlight
fill 316 292 463 316 307 463 minecraft:red_nether_bricks
setblock 318 292 489 minecraft:shroomlight
setblock 318 292 491 minecraft:shroomlight
setblock 318 292 493 minecraft:shroomlight
setblock 318 292 495 minecraft:shroomlight
fill 318 292 505 318 307 505 minecraft:red_nether_bricks
setblock 319 292 488 minecraft:shroomlight
setblock 319 292 490 minecraft:shroomlight
setblock 319 292 492 minecraft:shroomlight
setblock 319 292 494 minecraft:shroomlight
setblock 319 292 496 minecraft:shroomlight
fill 319 292 505 320 292 505 minecraft:shroomlight
setblock 320 292 489 minecraft:shroomlight
setblock 320 292 491 minecraft:shroomlight
setblock 320 292 493 minecraft:shroomlight
setblock 320 292 495 minecraft:shroomlight
setblock 321 292 488 minecraft:shroomlight
setblock 321 292 490 minecraft:shroomlight
setblock 321 292 492 minecraft:shroomlight
setblock 321 292 494 minecraft:shroomlight
setblock 321 292 496 minecraft:shroomlight
fill 321 292 505 321 307 505 minecraft:red_nether_bricks
setblock 322 292 489 minecraft:shroomlight
setblock 322 292 491 minecraft:shroomlight
setblock 322 292 493 minecraft:shroomlight
setblock 322 292 495 minecraft:shroomlight
setblock 323 292 488 minecraft:shroomlight
setblock 323 292 490 minecraft:shroomlight
setblock 323 292 492 minecraft:shroomlight
setblock 323 292 494 minecraft:shroomlight
setblock 323 292 496 minecraft:shroomlight
fill 324 292 464 324 307 464 minecraft:red_nether_bricks
fill 324 292 465 324 292 466 minecraft:shroomlight
fill 324 292 467 324 307 467 minecraft:red_nether_bricks
fill 324 292 476 324 307 476 minecraft:red_nether_bricks
fill 324 292 477 324 292 478 minecraft:shroomlight
fill 324 292 479 324 307 479 minecraft:red_nether_bricks
fill 324 292 488 324 307 488 minecraft:red_nether_bricks
fill 324 292 491 324 307 491 minecraft:red_nether_bricks
fill 324 292 500 324 307 500 minecraft:red_nether_bricks
fill 324 292 501 324 292 502 minecraft:shroomlight
fill 324 292 503 324 307 503 minecraft:red_nether_bricks
fill 282 293 470 282 307 471 minecraft:red_nether_bricks
fill 282 293 482 282 307 483 minecraft:red_nether_bricks
fill 282 293 494 282 307 495 minecraft:red_nether_bricks
fill 283 293 505 284 307 505 minecraft:red_nether_bricks
fill 290 293 463 291 307 463 minecraft:red_nether_bricks
fill 295 293 505 296 307 505 minecraft:red_nether_bricks
fill 298 293 465 298 294 465 minecraft:polished_blackstone_bricks
fill 298 293 467 298 294 467 minecraft:polished_blackstone_bricks
fill 298 293 469 298 294 469 minecraft:polished_blackstone_bricks
fill 298 293 471 298 294 471 minecraft:polished_blackstone_bricks
fill 299 293 464 299 294 464 minecraft:polished_blackstone_bricks
fill 299 293 466 299 294 466 minecraft:polished_blackstone_bricks
fill 299 293 468 299 294 468 minecraft:polished_blackstone_bricks
fill 299 293 470 299 294 470 minecraft:polished_blackstone_bricks
fill 300 293 465 300 294 465 minecraft:polished_blackstone_bricks
fill 300 293 467 300 294 467 minecraft:polished_blackstone_bricks
fill 300 293 469 300 294 469 minecraft:polished_blackstone_bricks
fill 300 293 471 300 294 471 minecraft:polished_blackstone_bricks
fill 301 293 464 301 294 464 minecraft:polished_blackstone_bricks
fill 301 293 466 301 294 466 minecraft:polished_blackstone_bricks
fill 301 293 468 301 294 468 minecraft:polished_blackstone_bricks
fill 301 293 470 301 294 470 minecraft:polished_blackstone_bricks
fill 302 293 463 303 307 463 minecraft:red_nether_bricks
fill 302 293 465 302 294 465 minecraft:polished_blackstone_bricks
fill 302 293 467 302 294 467 minecraft:polished_blackstone_bricks
fill 302 293 469 302 294 469 minecraft:polished_blackstone_bricks
fill 302 293 471 302 294 471 minecraft:polished_blackstone_bricks
fill 303 293 464 303 294 464 minecraft:polished_blackstone_bricks
fill 303 293 466 303 294 466 minecraft:polished_blackstone_bricks
fill 303 293 468 303 294 468 minecraft:polished_blackstone_bricks
fill 303 293 470 303 294 470 minecraft:polished_blackstone_bricks
fill 304 293 465 304 294 465 minecraft:polished_blackstone_bricks
fill 304 293 467 304 294 467 minecraft:polished_blackstone_bricks
fill 304 293 469 304 294 469 minecraft:polished_blackstone_bricks
fill 304 293 471 304 294 471 minecraft:polished_blackstone_bricks
fill 305 293 464 305 294 464 minecraft:polished_blackstone_bricks
fill 305 293 466 305 294 466 minecraft:polished_blackstone_bricks
fill 305 293 468 305 294 468 minecraft:polished_blackstone_bricks
fill 305 293 470 305 294 470 minecraft:polished_blackstone_bricks
fill 306 293 465 306 294 465 minecraft:polished_blackstone_bricks
fill 306 293 467 306 294 467 minecraft:polished_blackstone_bricks
fill 306 293 469 306 294 469 minecraft:polished_blackstone_bricks
fill 306 293 471 306 294 471 minecraft:polished_blackstone_bricks
fill 307 293 464 307 294 464 minecraft:polished_blackstone_bricks
fill 307 293 466 307 294 466 minecraft:polished_blackstone_bricks
fill 307 293 468 307 294 468 minecraft:polished_blackstone_bricks
fill 307 293 470 307 294 470 minecraft:polished_blackstone_bricks
fill 307 293 505 308 307 505 minecraft:red_nether_bricks
fill 308 293 465 308 294 465 minecraft:polished_blackstone_bricks
fill 308 293 467 308 294 467 minecraft:polished_blackstone_bricks
fill 308 293 469 308 294 469 minecraft:polished_blackstone_bricks
fill 308 293 471 308 294 471 minecraft:polished_blackstone_bricks
fill 314 293 463 315 307 463 minecraft:red_nether_bricks
fill 318 293 489 318 294 489 minecraft:polished_blackstone_bricks
fill 318 293 491 318 294 491 minecraft:polished_blackstone_bricks
fill 318 293 493 318 294 493 minecraft:polished_blackstone_bricks
fill 318 293 495 318 294 495 minecraft:polished_blackstone_bricks
fill 319 293 488 319 294 488 minecraft:polished_blackstone_bricks
fill 319 293 490 319 294 490 minecraft:polished_blackstone_bricks
fill 319 293 492 319 294 492 minecraft:polished_blackstone_bricks
fill 319 293 494 319 294 494 minecraft:polished_blackstone_bricks
fill 319 293 496 319 294 496 minecraft:polished_blackstone_bricks
fill 319 293 505 320 307 505 minecraft:red_nether_bricks
fill 320 293 489 320 294 489 minecraft:polished_blackstone_bricks
fill 320 293 491 320 294 491 minecraft:polished_blackstone_bricks
fill 320 293 493 320 294 493 minecraft:polished_blackstone_bricks
fill 320 293 495 320 294 495 minecraft:polished_blackstone_bricks
fill 321 293 488 321 294 488 minecraft:polished_blackstone_bricks
fill 321 293 490 321 294 490 minecraft:polished_blackstone_bricks
fill 321 293 492 321 294 492 minecraft:polished_blackstone_bricks
fill 321 293 494 321 294 494 minecraft:polished_blackstone_bricks
fill 321 293 496 321 294 496 minecraft:polished_blackstone_bricks
fill 322 293 489 322 294 489 minecraft:polished_blackstone_bricks
fill 322 293 491 322 294 491 minecraft:polished_blackstone_bricks
fill 322 293 493 322 294 493 minecraft:polished_blackstone_bricks
fill 322 293 495 322 294 495 minecraft:polished_blackstone_bricks
fill 323 293 488 323 294 488 minecraft:polished_blackstone_bricks
fill 323 293 490 323 294 490 minecraft:polished_blackstone_bricks
fill 323 293 492 323 294 492 minecraft:polished_blackstone_bricks
fill 323 293 494 323 294 494 minecraft:polished_blackstone_bricks
fill 323 293 496 323 294 496 minecraft:polished_blackstone_bricks
fill 324 293 465 324 307 466 minecraft:red_nether_bricks
fill 324 293 477 324 307 478 minecraft:red_nether_bricks
fill 324 293 489 324 307 490 minecraft:red_nether_bricks
fill 324 293 501 324 307 502 minecraft:red_nether_bricks
setblock 285 295 466 minecraft:light[level=14]
setblock 285 295 474 minecraft:light[level=14]
setblock 285 295 482 minecraft:light[level=14]
setblock 285 295 490 minecraft:light[level=14]
setblock 285 295 498 minecraft:light[level=14]
setblock 293 295 466 minecraft:light[level=14]
setblock 293 295 474 minecraft:light[level=14]
setblock 293 295 482 minecraft:light[level=14]
setblock 293 295 490 minecraft:light[level=14]
setblock 293 295 498 minecraft:light[level=14]
setblock 298 295 465 minecraft:shroomlight
setblock 298 295 467 minecraft:shroomlight
setblock 298 295 469 minecraft:shroomlight
setblock 298 295 471 minecraft:shroomlight
setblock 299 295 464 minecraft:shroomlight
setblock 299 295 466 minecraft:shroomlight
setblock 299 295 468 minecraft:shroomlight
setblock 299 295 470 minecraft:shroomlight
setblock 300 295 465 minecraft:shroomlight
setblock 300 295 467 minecraft:shroomlight
setblock 300 295 469 minecraft:shroomlight
setblock 300 295 471 minecraft:shroomlight
setblock 301 295 464 minecraft:shroomlight
setblock 301 295 466 minecraft:shroomlight
setblock 301 295 468 minecraft:shroomlight
setblock 301 295 470 minecraft:shroomlight
setblock 301 295 474 minecraft:light[level=14]
setblock 301 295 482 minecraft:light[level=14]
setblock 301 295 490 minecraft:light[level=14]
setblock 301 295 498 minecraft:light[level=14]
setblock 302 295 465 minecraft:shroomlight
setblock 302 295 467 minecraft:shroomlight
setblock 302 295 469 minecraft:shroomlight
setblock 302 295 471 minecraft:shroomlight
setblock 303 295 464 minecraft:shroomlight
setblock 303 295 466 minecraft:shroomlight
setblock 303 295 468 minecraft:shroomlight
setblock 303 295 470 minecraft:shroomlight
setblock 304 295 465 minecraft:shroomlight
setblock 304 295 467 minecraft:shroomlight
setblock 304 295 469 minecraft:shroomlight
setblock 304 295 471 minecraft:shroomlight
setblock 305 295 464 minecraft:shroomlight
setblock 305 295 466 minecraft:shroomlight
setblock 305 295 468 minecraft:shroomlight
setblock 305 295 470 minecraft:shroomlight
setblock 306 295 465 minecraft:shroomlight
setblock 306 295 467 minecraft:shroomlight
setblock 306 295 469 minecraft:shroomlight
setblock 306 295 471 minecraft:shroomlight
setblock 307 295 464 minecraft:shroomlight
setblock 307 295 466 minecraft:shroomlight
setblock 307 295 468 minecraft:shroomlight
setblock 307 295 470 minecraft:shroomlight
setblock 308 295 465 minecraft:shroomlight
setblock 308 295 467 minecraft:shroomlight
setblock 308 295 469 minecraft:shroomlight
setblock 308 295 471 minecraft:shroomlight
setblock 309 295 466 minecraft:light[level=14]
setblock 309 295 474 minecraft:light[level=14]
setblock 309 295 482 minecraft:light[level=14]
setblock 309 295 490 minecraft:light[level=14]
setblock 309 295 498 minecraft:light[level=14]
fill 316 295 490 317 296 494 minecraft:nether_bricks
setblock 317 295 466 minecraft:light[level=14]
setblock 317 295 474 minecraft:light[level=14]
setblock 317 295 482 minecraft:light[level=14]
setblock 317 295 498 minecraft:light[level=14]
setblock 318 295 489 minecraft:shroomlight
setblock 318 295 491 minecraft:shroomlight
setblock 318 295 493 minecraft:shroomlight
setblock 318 295 495 minecraft:shroomlight
setblock 319 295 488 minecraft:shroomlight
setblock 319 295 490 minecraft:shroomlight
setblock 319 295 492 minecraft:shroomlight
setblock 319 295 494 minecraft:shroomlight
setblock 319 295 496 minecraft:shroomlight
setblock 320 295 489 minecraft:shroomlight
setblock 320 295 491 minecraft:shroomlight
setblock 320 295 493 minecraft:shroomlight
setblock 320 295 495 minecraft:shroomlight
setblock 321 295 488 minecraft:shroomlight
setblock 321 295 490 minecraft:shroomlight
setblock 321 295 492 minecraft:shroomlight
setblock 321 295 494 minecraft:shroomlight
setblock 321 295 496 minecraft:shroomlight
setblock 322 295 489 minecraft:shroomlight
setblock 322 295 491 minecraft:shroomlight
setblock 322 295 493 minecraft:shroomlight
setblock 322 295 495 minecraft:shroomlight
setblock 323 295 488 minecraft:shroomlight
setblock 323 295 490 minecraft:shroomlight
setblock 323 295 492 minecraft:shroomlight
setblock 323 295 494 minecraft:shroomlight
setblock 323 295 496 minecraft:shroomlight
fill 298 296 465 298 297 465 minecraft:polished_blackstone_bricks
fill 298 296 467 298 297 467 minecraft:polished_blackstone_bricks
fill 298 296 469 298 297 469 minecraft:polished_blackstone_bricks
fill 298 296 471 298 297 471 minecraft:polished_blackstone_bricks
fill 299 296 464 299 297 464 minecraft:polished_blackstone_bricks
fill 299 296 466 299 297 466 minecraft:polished_blackstone_bricks
fill 299 296 468 299 297 468 minecraft:polished_blackstone_bricks
fill 299 296 470 299 297 470 minecraft:polished_blackstone_bricks
fill 300 296 465 300 297 465 minecraft:polished_blackstone_bricks
fill 300 296 467 300 297 467 minecraft:polished_blackstone_bricks
fill 300 296 469 300 297 469 minecraft:polished_blackstone_bricks
fill 300 296 471 300 297 471 minecraft:polished_blackstone_bricks
fill 301 296 464 301 297 464 minecraft:polished_blackstone_bricks
fill 301 296 466 301 297 466 minecraft:polished_blackstone_bricks
fill 301 296 468 301 297 468 minecraft:polished_blackstone_bricks
fill 301 296 470 301 297 470 minecraft:polished_blackstone_bricks
fill 302 296 465 302 297 465 minecraft:polished_blackstone_bricks
fill 302 296 467 302 297 467 minecraft:polished_blackstone_bricks
fill 302 296 469 302 297 469 minecraft:polished_blackstone_bricks
fill 302 296 471 302 297 471 minecraft:polished_blackstone_bricks
fill 303 296 464 303 297 464 minecraft:polished_blackstone_bricks
fill 303 296 466 303 297 466 minecraft:polished_blackstone_bricks
fill 303 296 468 303 297 468 minecraft:polished_blackstone_bricks
fill 303 296 470 303 297 470 minecraft:polished_blackstone_bricks
fill 304 296 465 304 297 465 minecraft:polished_blackstone_bricks
fill 304 296 467 304 297 467 minecraft:polished_blackstone_bricks
fill 304 296 469 304 297 469 minecraft:polished_blackstone_bricks
fill 304 296 471 304 297 471 minecraft:polished_blackstone_bricks
fill 305 296 464 305 297 464 minecraft:polished_blackstone_bricks
fill 305 296 466 305 297 466 minecraft:polished_blackstone_bricks
fill 305 296 468 305 297 468 minecraft:polished_blackstone_bricks
fill 305 296 470 305 297 470 minecraft:polished_blackstone_bricks
fill 306 296 465 306 297 465 minecraft:polished_blackstone_bricks
fill 306 296 467 306 297 467 minecraft:polished_blackstone_bricks
fill 306 296 469 306 297 469 minecraft:polished_blackstone_bricks
fill 306 296 471 306 297 471 minecraft:polished_blackstone_bricks
fill 307 296 464 307 297 464 minecraft:polished_blackstone_bricks
fill 307 296 466 307 297 466 minecraft:polished_blackstone_bricks
fill 307 296 468 307 297 468 minecraft:polished_blackstone_bricks
fill 307 296 470 307 297 470 minecraft:polished_blackstone_bricks
fill 308 296 465 308 297 465 minecraft:polished_blackstone_bricks
fill 308 296 467 308 297 467 minecraft:polished_blackstone_bricks
fill 308 296 469 308 297 469 minecraft:polished_blackstone_bricks
fill 308 296 471 308 297 471 minecraft:polished_blackstone_bricks
fill 318 296 489 318 297 489 minecraft:polished_blackstone_bricks
fill 318 296 491 318 297 491 minecraft:polished_blackstone_bricks
fill 318 296 493 318 297 493 minecraft:polished_blackstone_bricks
fill 318 296 495 318 297 495 minecraft:polished_blackstone_bricks
fill 319 296 488 319 297 488 minecraft:polished_blackstone_bricks
fill 319 296 490 319 297 490 minecraft:polished_blackstone_bricks
fill 319 296 492 319 297 492 minecraft:polished_blackstone_bricks
fill 319 296 494 319 297 494 minecraft:polished_blackstone_bricks
fill 319 296 496 319 297 496 minecraft:polished_blackstone_bricks
fill 320 296 489 320 297 489 minecraft:polished_blackstone_bricks
fill 320 296 491 320 297 491 minecraft:polished_blackstone_bricks
fill 320 296 493 320 297 493 minecraft:polished_blackstone_bricks
fill 320 296 495 320 297 495 minecraft:polished_blackstone_bricks
fill 321 296 488 321 297 488 minecraft:polished_blackstone_bricks
fill 321 296 490 321 297 490 minecraft:polished_blackstone_bricks
fill 321 296 492 321 297 492 minecraft:polished_blackstone_bricks
fill 321 296 494 321 297 494 minecraft:polished_blackstone_bricks
fill 321 296 496 321 297 496 minecraft:polished_blackstone_bricks
fill 322 296 489 322 297 489 minecraft:polished_blackstone_bricks
fill 322 296 491 322 297 491 minecraft:polished_blackstone_bricks
fill 322 296 493 322 297 493 minecraft:polished_blackstone_bricks
fill 322 296 495 322 297 495 minecraft:polished_blackstone_bricks
fill 323 296 488 323 297 488 minecraft:polished_blackstone_bricks
fill 323 296 490 323 297 490 minecraft:polished_blackstone_bricks
fill 323 296 492 323 297 492 minecraft:polished_blackstone_bricks
fill 323 296 494 323 297 494 minecraft:polished_blackstone_bricks
fill 323 296 496 323 297 496 minecraft:polished_blackstone_bricks
setblock 298 298 465 minecraft:shroomlight
setblock 298 298 467 minecraft:shroomlight
setblock 298 298 469 minecraft:shroomlight
setblock 298 298 471 minecraft:shroomlight
setblock 299 298 464 minecraft:shroomlight
setblock 299 298 466 minecraft:shroomlight
setblock 299 298 468 minecraft:shroomlight
setblock 299 298 470 minecraft:shroomlight
setblock 300 298 465 minecraft:shroomlight
setblock 300 298 467 minecraft:shroomlight
setblock 300 298 469 minecraft:shroomlight
setblock 300 298 471 minecraft:shroomlight
setblock 301 298 464 minecraft:shroomlight
setblock 301 298 466 minecraft:shroomlight
setblock 301 298 468 minecraft:shroomlight
setblock 301 298 470 minecraft:shroomlight
setblock 302 298 465 minecraft:shroomlight
setblock 302 298 467 minecraft:shroomlight
setblock 302 298 469 minecraft:shroomlight
setblock 302 298 471 minecraft:shroomlight
setblock 303 298 464 minecraft:shroomlight
setblock 303 298 466 minecraft:shroomlight
setblock 303 298 468 minecraft:shroomlight
setblock 303 298 470 minecraft:shroomlight
setblock 304 298 465 minecraft:shroomlight
setblock 304 298 467 minecraft:shroomlight
setblock 304 298 469 minecraft:shroomlight
setblock 304 298 471 minecraft:shroomlight
setblock 305 298 464 minecraft:shroomlight
setblock 305 298 466 minecraft:shroomlight
setblock 305 298 468 minecraft:shroomlight
setblock 305 298 470 minecraft:shroomlight
setblock 306 298 465 minecraft:shroomlight
setblock 306 298 467 minecraft:shroomlight
setblock 306 298 469 minecraft:shroomlight
setblock 306 298 471 minecraft:shroomlight
setblock 307 298 464 minecraft:shroomlight
setblock 307 298 466 minecraft:shroomlight
setblock 307 298 468 minecraft:shroomlight
setblock 307 298 470 minecraft:shroomlight
setblock 308 298 465 minecraft:shroomlight
setblock 308 298 467 minecraft:shroomlight
setblock 308 298 469 minecraft:shroomlight
setblock 308 298 471 minecraft:shroomlight
fill 316 298 491 317 300 493 minecraft:bone_block
fill 317 298 490 317 300 490 minecraft:bone_block
fill 317 298 494 317 300 494 minecraft:bone_block
setblock 318 298 489 minecraft:shroomlight
setblock 318 298 491 minecraft:shroomlight
setblock 318 298 493 minecraft:shroomlight
setblock 318 298 495 minecraft:shroomlight
setblock 319 298 488 minecraft:shroomlight
setblock 319 298 490 minecraft:shroomlight
setblock 319 298 492 minecraft:shroomlight
setblock 319 298 494 minecraft:shroomlight
setblock 319 298 496 minecraft:shroomlight
setblock 320 298 489 minecraft:shroomlight
setblock 320 298 491 minecraft:shroomlight
setblock 320 298 493 minecraft:shroomlight
setblock 320 298 495 minecraft:shroomlight
setblock 321 298 488 minecraft:shroomlight
setblock 321 298 490 minecraft:shroomlight
setblock 321 298 492 minecraft:shroomlight
setblock 321 298 494 minecraft:shroomlight
setblock 321 298 496 minecraft:shroomlight
setblock 322 298 489 minecraft:shroomlight
setblock 322 298 491 minecraft:shroomlight
setblock 322 298 493 minecraft:shroomlight
setblock 322 298 495 minecraft:shroomlight
setblock 323 298 488 minecraft:shroomlight
setblock 323 298 490 minecraft:shroomlight
setblock 323 298 492 minecraft:shroomlight
setblock 323 298 494 minecraft:shroomlight
setblock 323 298 496 minecraft:shroomlight
fill 298 299 465 298 300 465 minecraft:polished_blackstone_bricks
fill 298 299 467 298 300 467 minecraft:polished_blackstone_bricks
fill 298 299 469 298 300 469 minecraft:polished_blackstone_bricks
fill 298 299 471 298 300 471 minecraft:polished_blackstone_bricks
fill 299 299 464 299 300 464 minecraft:polished_blackstone_bricks
fill 299 299 466 299 300 466 minecraft:polished_blackstone_bricks
fill 299 299 468 299 300 468 minecraft:polished_blackstone_bricks
fill 299 299 470 299 300 470 minecraft:polished_blackstone_bricks
fill 300 299 465 300 300 465 minecraft:polished_blackstone_bricks
fill 300 299 467 300 300 467 minecraft:polished_blackstone_bricks
fill 300 299 469 300 300 469 minecraft:polished_blackstone_bricks
fill 300 299 471 300 300 471 minecraft:polished_blackstone_bricks
fill 301 299 464 301 300 464 minecraft:polished_blackstone_bricks
fill 301 299 466 301 300 466 minecraft:polished_blackstone_bricks
fill 301 299 468 301 300 468 minecraft:polished_blackstone_bricks
fill 301 299 470 301 300 470 minecraft:polished_blackstone_bricks
fill 302 299 465 302 300 465 minecraft:polished_blackstone_bricks
fill 302 299 467 302 300 467 minecraft:polished_blackstone_bricks
fill 302 299 469 302 300 469 minecraft:polished_blackstone_bricks
fill 302 299 471 302 300 471 minecraft:polished_blackstone_bricks
fill 303 299 464 303 300 464 minecraft:polished_blackstone_bricks
fill 303 299 466 303 300 466 minecraft:polished_blackstone_bricks
fill 303 299 468 303 300 468 minecraft:polished_blackstone_bricks
fill 303 299 470 303 300 470 minecraft:polished_blackstone_bricks
fill 304 299 465 304 300 465 minecraft:polished_blackstone_bricks
fill 304 299 467 304 300 467 minecraft:polished_blackstone_bricks
fill 304 299 469 304 300 469 minecraft:polished_blackstone_bricks
fill 304 299 471 304 300 471 minecraft:polished_blackstone_bricks
fill 305 299 464 305 300 464 minecraft:polished_blackstone_bricks
fill 305 299 466 305 300 466 minecraft:polished_blackstone_bricks
fill 305 299 468 305 300 468 minecraft:polished_blackstone_bricks
fill 305 299 470 305 300 470 minecraft:polished_blackstone_bricks
fill 306 299 465 306 300 465 minecraft:polished_blackstone_bricks
fill 306 299 467 306 300 467 minecraft:polished_blackstone_bricks
fill 306 299 469 306 300 469 minecraft:polished_blackstone_bricks
fill 306 299 471 306 300 471 minecraft:polished_blackstone_bricks
fill 307 299 464 307 300 464 minecraft:polished_blackstone_bricks
fill 307 299 466 307 300 466 minecraft:polished_blackstone_bricks
fill 307 299 468 307 300 468 minecraft:polished_blackstone_bricks
fill 307 299 470 307 300 470 minecraft:polished_blackstone_bricks
fill 308 299 465 308 300 465 minecraft:polished_blackstone_bricks
fill 308 299 467 308 300 467 minecraft:polished_blackstone_bricks
fill 308 299 469 308 300 469 minecraft:polished_blackstone_bricks
fill 308 299 471 308 300 471 minecraft:polished_blackstone_bricks
fill 318 299 489 318 300 489 minecraft:polished_blackstone_bricks
fill 318 299 491 318 300 491 minecraft:polished_blackstone_bricks
fill 318 299 493 318 300 493 minecraft:polished_blackstone_bricks
fill 318 299 495 318 300 495 minecraft:polished_blackstone_bricks
fill 319 299 488 319 300 488 minecraft:polished_blackstone_bricks
fill 319 299 490 319 300 490 minecraft:polished_blackstone_bricks
fill 319 299 492 319 300 492 minecraft:polished_blackstone_bricks
fill 319 299 494 319 300 494 minecraft:polished_blackstone_bricks
fill 319 299 496 319 300 496 minecraft:polished_blackstone_bricks
fill 320 299 489 320 300 489 minecraft:polished_blackstone_bricks
fill 320 299 491 320 300 491 minecraft:polished_blackstone_bricks
fill 320 299 493 320 300 493 minecraft:polished_blackstone_bricks
fill 320 299 495 320 300 495 minecraft:polished_blackstone_bricks
fill 321 299 488 321 300 488 minecraft:polished_blackstone_bricks
fill 321 299 490 321 300 490 minecraft:polished_blackstone_bricks
fill 321 299 492 321 300 492 minecraft:polished_blackstone_bricks
fill 321 299 494 321 300 494 minecraft:polished_blackstone_bricks
fill 321 299 496 321 300 496 minecraft:polished_blackstone_bricks
fill 322 299 489 322 300 489 minecraft:polished_blackstone_bricks
fill 322 299 491 322 300 491 minecraft:polished_blackstone_bricks
fill 322 299 493 322 300 493 minecraft:polished_blackstone_bricks
fill 322 299 495 322 300 495 minecraft:polished_blackstone_bricks
fill 323 299 488 323 300 488 minecraft:polished_blackstone_bricks
fill 323 299 490 323 300 490 minecraft:polished_blackstone_bricks
fill 323 299 492 323 300 492 minecraft:polished_blackstone_bricks
fill 323 299 494 323 300 494 minecraft:polished_blackstone_bricks
fill 323 299 496 323 300 496 minecraft:polished_blackstone_bricks
fill 284 300 473 284 300 475 minecraft:polished_blackstone_bricks
fill 284 300 485 284 300 487 minecraft:polished_blackstone_bricks
fill 284 300 497 284 300 499 minecraft:polished_blackstone_bricks
fill 290 300 503 292 300 503 minecraft:polished_blackstone_bricks
fill 294 300 465 296 300 465 minecraft:polished_blackstone_bricks
fill 302 300 503 304 300 503 minecraft:polished_blackstone_bricks
fill 314 300 503 316 300 503 minecraft:polished_blackstone_bricks
fill 318 300 465 320 300 465 minecraft:polished_blackstone_bricks
fill 322 300 473 322 300 475 minecraft:polished_blackstone_bricks
fill 322 300 485 322 300 487 minecraft:polished_blackstone_bricks
fill 322 300 497 322 300 499 minecraft:polished_blackstone_bricks
setblock 285 303 466 minecraft:light[level=14]
setblock 285 303 474 minecraft:light[level=14]
setblock 285 303 482 minecraft:light[level=14]
setblock 285 303 490 minecraft:light[level=14]
setblock 285 303 498 minecraft:light[level=14]
setblock 293 303 466 minecraft:light[level=14]
setblock 293 303 474 minecraft:light[level=14]
setblock 293 303 482 minecraft:light[level=14]
setblock 293 303 490 minecraft:light[level=14]
setblock 293 303 498 minecraft:light[level=14]
setblock 301 303 466 minecraft:light[level=14]
setblock 301 303 474 minecraft:light[level=14]
setblock 301 303 482 minecraft:light[level=14]
setblock 301 303 490 minecraft:light[level=14]
setblock 301 303 498 minecraft:light[level=14]
setblock 309 303 466 minecraft:light[level=14]
setblock 309 303 474 minecraft:light[level=14]
setblock 309 303 482 minecraft:light[level=14]
setblock 309 303 490 minecraft:light[level=14]
setblock 309 303 498 minecraft:light[level=14]
setblock 317 303 466 minecraft:light[level=14]
setblock 317 303 474 minecraft:light[level=14]
setblock 317 303 482 minecraft:light[level=14]
setblock 317 303 490 minecraft:light[level=14]
setblock 317 303 498 minecraft:light[level=14]
