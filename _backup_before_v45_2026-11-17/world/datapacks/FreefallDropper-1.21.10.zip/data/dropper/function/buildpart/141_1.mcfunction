fill 435 150 557 435 151 557 minecraft:light_blue_concrete
setblock 437 150 557 minecraft:lime_concrete
fill 438 150 557 438 151 557 minecraft:light_blue_concrete
fill 442 150 557 442 152 557 minecraft:light_blue_concrete
fill 442 150 599 442 151 599 minecraft:light_blue_concrete
setblock 443 150 557 minecraft:lime_concrete
fill 444 150 557 444 151 557 minecraft:light_blue_concrete
fill 446 150 557 446 151 557 minecraft:light_blue_concrete
setblock 447 150 557 minecraft:lime_concrete
fill 448 150 557 450 151 557 minecraft:light_blue_concrete
fill 450 150 599 450 151 599 minecraft:light_blue_concrete
setblock 451 150 557 minecraft:lime_concrete
fill 452 150 557 452 151 557 minecraft:light_blue_concrete
setblock 453 150 557 minecraft:lime_concrete
fill 454 150 557 454 151 557 minecraft:light_blue_concrete
fill 456 150 557 456 151 557 minecraft:light_blue_concrete
fill 458 150 599 458 151 599 minecraft:light_blue_concrete
fill 462 150 557 463 150 557 minecraft:lime_concrete
fill 462 150 573 462 151 573 minecraft:yellow_concrete
setblock 463 150 599 minecraft:lime_concrete
fill 464 150 557 464 151 557 minecraft:light_blue_concrete
setblock 465 150 557 minecraft:lime_concrete
fill 465 150 560 465 151 560 minecraft:light_blue_concrete
setblock 465 150 561 minecraft:lime_concrete
fill 465 150 562 465 151 562 minecraft:light_blue_concrete
fill 465 150 570 465 151 570 minecraft:light_blue_concrete
fill 465 150 578 465 151 578 minecraft:light_blue_concrete
setblock 465 150 586 minecraft:lime_concrete
fill 465 150 588 465 151 589 minecraft:light_blue_concrete
setblock 465 150 590 minecraft:lime_concrete
fill 465 150 594 465 151 594 minecraft:light_blue_concrete
fill 465 150 599 465 151 599 minecraft:light_blue_concrete
setblock 423 151 560 minecraft:light_blue_concrete
setblock 423 151 562 minecraft:light_blue_concrete
setblock 423 151 566 minecraft:light_blue_concrete
setblock 423 151 575 minecraft:light_blue_concrete
setblock 423 151 579 minecraft:light_blue_concrete
setblock 423 151 582 minecraft:light_blue_concrete
setblock 426 151 557 minecraft:light_blue_concrete
setblock 430 151 599 minecraft:light_blue_concrete
setblock 432 151 557 minecraft:light_blue_concrete
setblock 434 151 557 minecraft:light_blue_concrete
setblock 437 151 557 minecraft:light_blue_concrete
setblock 443 151 557 minecraft:light_blue_concrete
setblock 447 151 557 minecraft:light_blue_concrete
setblock 451 151 557 minecraft:light_blue_concrete
setblock 453 151 557 minecraft:light_blue_concrete
fill 462 151 557 463 151 557 minecraft:light_blue_concrete
setblock 463 151 599 minecraft:light_blue_concrete
setblock 465 151 557 minecraft:light_blue_concrete
fill 465 151 561 465 152 561 minecraft:light_blue_concrete
fill 465 151 574 465 152 574 minecraft:light_blue_concrete
setblock 465 151 586 minecraft:light_blue_concrete
setblock 465 151 590 minecraft:light_blue_concrete
fill 423 152 558 423 152 562 minecraft:lime_concrete
setblock 423 152 563 minecraft:light_blue_concrete
fill 423 152 564 423 152 571 minecraft:lime_concrete
setblock 423 152 572 minecraft:light_blue_concrete
fill 423 152 573 423 152 582 minecraft:lime_concrete
fill 423 152 586 423 152 599 minecraft:lime_concrete
fill 424 152 557 432 153 557 minecraft:lime_concrete
fill 424 152 599 436 152 599 minecraft:lime_concrete
fill 434 152 557 441 152 557 minecraft:lime_concrete
fill 437 152 599 437 153 599 minecraft:light_blue_concrete
fill 438 152 599 463 152 599 minecraft:lime_concrete
fill 443 152 557 465 152 557 minecraft:lime_concrete
fill 465 152 558 465 186 560 minecraft:lime_concrete
fill 465 152 562 465 153 573 minecraft:lime_concrete
fill 465 152 575 465 152 599 minecraft:lime_concrete
fill 423 153 557 423 190 560 minecraft:lime_concrete
setblock 423 153 561 minecraft:light_blue_concrete
fill 423 153 562 423 153 567 minecraft:lime_concrete
setblock 423 153 568 minecraft:light_blue_concrete
fill 423 153 569 423 157 570 minecraft:lime_concrete
setblock 423 153 571 minecraft:light_blue_concrete
fill 423 153 572 423 153 578 minecraft:lime_concrete
setblock 423 153 579 minecraft:light_blue_concrete
fill 423 153 580 423 157 587 minecraft:lime_concrete
fill 423 153 588 423 154 588 minecraft:light_blue_concrete
fill 423 153 589 423 153 597 minecraft:lime_concrete
setblock 423 153 598 minecraft:light_blue_concrete
fill 423 153 599 424 153 599 minecraft:lime_concrete
setblock 425 153 599 minecraft:light_blue_concrete
fill 426 153 599 436 153 599 minecraft:lime_concrete
fill 433 153 557 433 190 557 minecraft:lime_concrete
setblock 434 153 557 minecraft:light_blue_concrete
fill 435 153 557 438 157 557 minecraft:lime_concrete
fill 438 153 599 438 190 599 minecraft:lime_concrete
fill 439 153 557 440 153 557 minecraft:light_blue_concrete
fill 439 153 599 440 153 599 minecraft:light_blue_concrete
fill 441 153 557 450 153 557 minecraft:lime_concrete
fill 441 153 599 449 153 599 minecraft:lime_concrete
setblock 450 153 599 minecraft:light_blue_concrete
setblock 451 153 557 minecraft:light_blue_concrete
fill 451 153 599 465 153 599 minecraft:lime_concrete
fill 452 153 557 455 153 557 minecraft:lime_concrete
setblock 456 153 557 minecraft:light_blue_concrete
fill 457 153 557 459 186 557 minecraft:lime_concrete
fill 460 153 557 461 153 557 minecraft:light_blue_concrete
fill 462 153 557 465 153 557 minecraft:lime_concrete
fill 465 153 561 465 188 561 minecraft:lime_concrete
fill 465 153 574 465 157 584 minecraft:lime_concrete
setblock 465 153 585 minecraft:light_blue_concrete
fill 465 153 586 465 157 586 minecraft:lime_concrete
setblock 465 153 587 minecraft:light_blue_concrete
fill 465 153 588 465 188 593 minecraft:lime_concrete
setblock 465 153 594 minecraft:light_blue_concrete
fill 465 153 595 465 153 598 minecraft:lime_concrete
fill 423 154 561 423 190 561 minecraft:lime_concrete
setblock 423 154 562 minecraft:light_blue_concrete
fill 423 154 563 423 186 568 minecraft:lime_concrete
fill 423 154 571 423 186 576 minecraft:lime_concrete
setblock 423 154 577 minecraft:light_blue_concrete
fill 423 154 578 423 157 579 minecraft:lime_concrete
fill 423 154 589 423 188 592 minecraft:lime_concrete
setblock 423 154 593 minecraft:light_blue_concrete
fill 423 154 594 423 157 594 minecraft:lime_concrete
setblock 423 154 595 minecraft:light_blue_concrete
fill 423 154 596 423 186 598 minecraft:lime_concrete
fill 423 154 599 424 154 599 minecraft:light_blue_concrete
fill 424 154 557 426 188 557 minecraft:lime_concrete
fill 424 154 558 424 155 563 minecraft:white_concrete
fill 424 154 566 425 154 571 minecraft:white_concrete
fill 424 154 574 425 154 579 minecraft:white_concrete
fill 424 154 582 425 154 587 minecraft:white_concrete
fill 424 154 590 425 154 595 minecraft:white_concrete
fill 424 154 598 429 155 598 minecraft:white_concrete
fill 425 154 559 425 154 565 minecraft:white_concrete
fill 425 154 572 425 154 573 minecraft:white_concrete
fill 425 154 580 425 154 581 minecraft:white_concrete
fill 425 154 588 425 154 589 minecraft:white_concrete
fill 425 154 596 425 154 597 minecraft:white_concrete
fill 425 154 599 425 188 599 minecraft:lime_concrete
fill 426 154 559 463 154 559 minecraft:white_concrete
fill 426 154 597 464 154 597 minecraft:white_concrete
setblock 426 154 599 minecraft:light_blue_concrete
fill 427 154 557 428 154 557 minecraft:light_blue_concrete
fill 427 154 558 432 155 558 minecraft:white_concrete
fill 427 154 599 437 157 599 minecraft:lime_concrete
fill 429 154 557 432 157 557 minecraft:lime_concrete
fill 432 154 598 437 155 598 minecraft:white_concrete
fill 434 154 557 434 190 557 minecraft:lime_concrete
fill 435 154 558 440 155 558 minecraft:white_concrete
fill 439 154 557 439 190 557 minecraft:lime_concrete
fill 439 154 599 445 157 599 minecraft:lime_concrete
setblock 440 154 557 minecraft:light_blue_concrete
fill 440 154 598 445 155 598 minecraft:white_concrete
fill 441 154 557 442 190 557 minecraft:lime_concrete
setblock 443 154 557 minecraft:light_blue_concrete
fill 443 154 558 448 155 558 minecraft:white_concrete
fill 444 154 557 453 157 557 minecraft:lime_concrete
setblock 446 154 599 minecraft:light_blue_concrete
fill 447 154 599 453 157 599 minecraft:lime_concrete
fill 448 154 598 453 155 598 minecraft:white_concrete
fill 451 154 558 456 155 558 minecraft:white_concrete
setblock 454 154 557 minecraft:light_blue_concrete
setblock 454 154 599 minecraft:light_blue_concrete
fill 455 154 557 456 190 557 minecraft:lime_concrete
fill 455 154 599 455 187 599 minecraft:lime_concrete
fill 456 154 598 461 155 598 minecraft:white_concrete
setblock 456 154 599 minecraft:light_blue_concrete
fill 457 154 599 465 157 599 minecraft:lime_concrete
fill 459 154 558 464 155 558 minecraft:white_concrete
fill 460 154 557 462 157 557 minecraft:lime_concrete
setblock 463 154 557 minecraft:light_blue_concrete
fill 463 154 560 463 154 596 minecraft:white_concrete
fill 464 154 557 464 190 557 minecraft:lime_concrete
fill 464 154 561 464 155 566 minecraft:white_concrete
fill 464 154 569 464 155 574 minecraft:white_concrete
fill 464 154 577 464 155 582 minecraft:white_concrete
fill 464 154 585 464 155 590 minecraft:white_concrete
fill 464 154 593 464 155 596 minecraft:white_concrete
fill 464 154 598 464 155 598 minecraft:white_concrete
setblock 465 154 557 minecraft:light_blue_concrete
setblock 465 154 562 minecraft:light_blue_concrete
fill 465 154 563 465 186 567 minecraft:lime_concrete
setblock 465 154 568 minecraft:light_blue_concrete
fill 465 154 569 465 157 573 minecraft:lime_concrete
fill 465 154 585 465 190 585 minecraft:lime_concrete
fill 465 154 587 465 191 587 minecraft:lime_concrete
fill 465 154 594 465 157 594 minecraft:lime_concrete
setblock 465 154 595 minecraft:light_blue_concrete
fill 465 154 596 465 190 596 minecraft:lime_concrete
setblock 465 154 597 minecraft:light_blue_concrete
fill 465 154 598 465 188 598 minecraft:lime_concrete
fill 423 155 562 423 157 562 minecraft:lime_concrete
fill 423 155 577 423 190 577 minecraft:lime_concrete
fill 423 155 588 423 190 588 minecraft:lime_concrete
fill 423 155 593 423 186 593 minecraft:lime_concrete
fill 423 155 595 423 190 595 minecraft:lime_concrete
fill 423 155 599 424 190 599 minecraft:lime_concrete
fill 424 155 566 424 155 571 minecraft:white_concrete
fill 424 155 574 424 155 579 minecraft:white_concrete
fill 424 155 582 424 155 587 minecraft:white_concrete
fill 424 155 590 424 155 595 minecraft:white_concrete
fill 426 155 599 426 157 599 minecraft:lime_concrete
fill 427 155 557 428 190 557 minecraft:lime_concrete
fill 440 155 557 440 191 557 minecraft:lime_concrete
fill 443 155 557 443 190 557 minecraft:lime_concrete
fill 446 155 599 446 190 599 minecraft:lime_concrete
fill 454 155 557 454 157 557 minecraft:lime_concrete
fill 454 155 599 454 186 599 minecraft:lime_concrete
fill 456 155 599 456 186 599 minecraft:lime_concrete
fill 463 155 557 463 190 557 minecraft:lime_concrete
setblock 464 155 597 minecraft:white_concrete
fill 465 155 557 465 186 557 minecraft:lime_concrete
fill 465 155 562 465 157 562 minecraft:lime_concrete
fill 465 155 568 465 186 568 minecraft:lime_concrete
fill 465 155 595 465 186 595 minecraft:lime_concrete
fill 465 155 597 465 186 597 minecraft:lime_concrete
setblock 426 156 560 minecraft:light[level=14]
setblock 426 156 568 minecraft:light[level=14]
setblock 426 156 576 minecraft:light[level=14]
setblock 426 156 584 minecraft:light[level=14]
setblock 426 156 592 minecraft:light[level=14]
setblock 434 156 560 minecraft:light[level=14]
setblock 434 156 568 minecraft:light[level=14]
setblock 434 156 576 minecraft:light[level=14]
setblock 434 156 584 minecraft:light[level=14]
setblock 434 156 592 minecraft:light[level=14]
setblock 442 156 560 minecraft:light[level=14]
setblock 442 156 568 minecraft:light[level=14]
setblock 442 156 576 minecraft:light[level=14]
setblock 442 156 584 minecraft:light[level=14]
setblock 442 156 592 minecraft:light[level=14]
setblock 450 156 560 minecraft:light[level=14]
setblock 450 156 568 minecraft:light[level=14]
setblock 450 156 576 minecraft:light[level=14]
setblock 450 156 584 minecraft:light[level=14]
setblock 450 156 592 minecraft:light[level=14]
setblock 458 156 560 minecraft:light[level=14]
setblock 458 156 568 minecraft:light[level=14]
setblock 458 156 576 minecraft:light[level=14]
setblock 458 156 584 minecraft:light[level=14]
setblock 458 156 592 minecraft:light[level=14]
fill 423 158 562 423 163 562 minecraft:sea_lantern
fill 423 158 569 423 190 569 minecraft:lime_concrete
fill 423 158 570 423 163 570 minecraft:sea_lantern
fill 423 158 578 423 163 578 minecraft:sea_lantern
fill 423 158 579 423 186 585 minecraft:lime_concrete
fill 423 158 586 423 163 586 minecraft:sea_lantern
fill 423 158 587 423 191 587 minecraft:lime_concrete
fill 423 158 594 423 163 594 minecraft:sea_lantern
fill 426 158 599 426 163 599 minecraft:sea_lantern
fill 427 158 599 433 187 599 minecraft:lime_concrete
fill 429 158 557 429 190 557 minecraft:lime_concrete
fill 430 158 557 430 163 557 minecraft:sea_lantern
fill 431 158 557 432 186 557 minecraft:lime_concrete
fill 434 158 599 434 163 599 minecraft:sea_lantern
fill 435 158 557 437 186 557 minecraft:lime_concrete
fill 435 158 599 437 186 599 minecraft:lime_concrete
fill 438 158 557 438 163 557 minecraft:sea_lantern
fill 439 158 599 441 186 599 minecraft:lime_concrete
fill 442 158 599 442 163 599 minecraft:sea_lantern
fill 443 158 599 445 186 599 minecraft:lime_concrete
fill 444 158 557 445 190 557 minecraft:lime_concrete
fill 446 158 557 446 163 557 minecraft:sea_lantern
fill 447 158 557 453 188 557 minecraft:lime_concrete
fill 447 158 599 449 186 599 minecraft:lime_concrete
fill 450 158 599 450 163 599 minecraft:sea_lantern
fill 451 158 599 453 188 599 minecraft:lime_concrete
fill 454 158 557 454 163 557 minecraft:sea_lantern
fill 457 158 599 457 190 599 minecraft:lime_concrete
fill 458 158 599 458 163 599 minecraft:sea_lantern
fill 459 158 599 465 187 599 minecraft:lime_concrete
fill 460 158 557 461 190 557 minecraft:lime_concrete
fill 462 158 557 462 163 557 minecraft:sea_lantern
fill 465 158 562 465 163 562 minecraft:sea_lantern
fill 465 158 569 465 190 569 minecraft:lime_concrete
fill 465 158 570 465 163 570 minecraft:sea_lantern
fill 465 158 571 465 186 577 minecraft:lime_concrete
fill 465 158 578 465 163 578 minecraft:sea_lantern
fill 465 158 579 465 186 584 minecraft:lime_concrete
fill 465 158 586 465 163 586 minecraft:sea_lantern
fill 465 158 594 465 163 594 minecraft:sea_lantern
fill 452 159 564 453 160 565 minecraft:blue_concrete
fill 423 164 562 423 171 562 minecraft:lime_concrete
fill 423 164 570 423 171 570 minecraft:lime_concrete
fill 423 164 578 423 171 578 minecraft:lime_concrete
fill 423 164 586 423 171 586 minecraft:lime_concrete
fill 423 164 594 423 171 594 minecraft:lime_concrete
setblock 426 164 560 minecraft:light[level=14]
setblock 426 164 568 minecraft:light[level=14]
setblock 426 164 576 minecraft:light[level=14]
setblock 426 164 584 minecraft:light[level=14]
setblock 426 164 592 minecraft:light[level=14]
fill 426 164 599 426 171 599 minecraft:lime_concrete
fill 430 164 557 430 171 557 minecraft:lime_concrete
setblock 434 164 560 minecraft:light[level=14]
setblock 434 164 568 minecraft:light[level=14]
setblock 434 164 576 minecraft:light[level=14]
setblock 434 164 584 minecraft:light[level=14]
setblock 434 164 592 minecraft:light[level=14]
fill 434 164 599 434 171 599 minecraft:lime_concrete
fill 438 164 557 438 171 557 minecraft:lime_concrete
setblock 442 164 560 minecraft:light[level=14]
setblock 442 164 568 minecraft:light[level=14]
setblock 442 164 576 minecraft:light[level=14]
setblock 442 164 584 minecraft:light[level=14]
setblock 442 164 592 minecraft:light[level=14]
fill 442 164 599 442 171 599 minecraft:lime_concrete
fill 446 164 557 446 171 557 minecraft:lime_concrete
setblock 450 164 560 minecraft:light[level=14]
setblock 450 164 568 minecraft:light[level=14]
setblock 450 164 576 minecraft:light[level=14]
setblock 450 164 584 minecraft:light[level=14]
setblock 450 164 592 minecraft:light[level=14]
fill 450 164 599 450 171 599 minecraft:lime_concrete
fill 454 164 557 454 171 557 minecraft:lime_concrete
setblock 458 164 560 minecraft:light[level=14]
setblock 458 164 568 minecraft:light[level=14]
setblock 458 164 576 minecraft:light[level=14]
setblock 458 164 584 minecraft:light[level=14]
setblock 458 164 592 minecraft:light[level=14]
fill 458 164 599 458 171 599 minecraft:lime_concrete
fill 462 164 557 462 171 557 minecraft:lime_concrete
fill 465 164 562 465 171 562 minecraft:lime_concrete
fill 465 164 570 465 171 570 minecraft:lime_concrete
fill 465 164 578 465 171 578 minecraft:lime_concrete
fill 465 164 586 465 171 586 minecraft:lime_concrete
fill 465 164 594 465 171 594 minecraft:lime_concrete
fill 424 168 558 424 169 563 minecraft:white_concrete
fill 424 168 566 425 168 571 minecraft:white_concrete
fill 424 168 574 425 168 579 minecraft:white_concrete
fill 424 168 582 425 168 587 minecraft:white_concrete
fill 424 168 590 425 168 595 minecraft:white_concrete
fill 424 168 598 429 169 598 minecraft:white_concrete
fill 425 168 559 425 168 565 minecraft:white_concrete
fill 425 168 572 425 168 573 minecraft:white_concrete
fill 425 168 580 425 168 581 minecraft:white_concrete
fill 425 168 588 425 168 589 minecraft:white_concrete
fill 425 168 596 425 168 597 minecraft:white_concrete
fill 426 168 559 463 168 559 minecraft:white_concrete
fill 426 168 597 464 168 597 minecraft:white_concrete
fill 427 168 558 432 169 558 minecraft:white_concrete
fill 432 168 598 437 169 598 minecraft:white_concrete
fill 435 168 558 440 169 558 minecraft:white_concrete
fill 440 168 598 445 169 598 minecraft:white_concrete
fill 443 168 558 448 169 558 minecraft:white_concrete
fill 448 168 598 453 169 598 minecraft:white_concrete
fill 451 168 558 456 169 558 minecraft:white_concrete
fill 456 168 598 461 169 598 minecraft:white_concrete
fill 459 168 558 464 169 558 minecraft:white_concrete
fill 463 168 560 463 168 596 minecraft:white_concrete
fill 464 168 561 464 169 566 minecraft:white_concrete
fill 464 168 569 464 169 574 minecraft:white_concrete
fill 464 168 577 464 169 582 minecraft:white_concrete
fill 464 168 585 464 169 590 minecraft:white_concrete
fill 464 168 593 464 169 596 minecraft:white_concrete
fill 464 168 598 464 169 598 minecraft:white_concrete
fill 424 169 566 424 169 571 minecraft:white_concrete
fill 424 169 574 424 169 579 minecraft:white_concrete
fill 424 169 582 424 169 587 minecraft:white_concrete
fill 424 169 590 424 169 595 minecraft:white_concrete
fill 445 169 559 445 170 560 minecraft:iron_block
setblock 464 169 597 minecraft:white_concrete
fill 424 170 574 426 171 574 minecraft:iron_block
setblock 445 170 558 minecraft:iron_block
fill 423 172 562 423 177 562 minecraft:sea_lantern
fill 423 172 570 423 177 570 minecraft:sea_lantern
fill 423 172 578 423 177 578 minecraft:sea_lantern
fill 423 172 586 423 177 586 minecraft:sea_lantern
fill 423 172 594 423 177 594 minecraft:sea_lantern
setblock 426 172 560 minecraft:light[level=14]
setblock 426 172 568 minecraft:light[level=14]
setblock 426 172 576 minecraft:light[level=14]
setblock 426 172 584 minecraft:light[level=14]
setblock 426 172 592 minecraft:light[level=14]
fill 426 172 599 426 177 599 minecraft:sea_lantern
fill 430 172 557 430 177 557 minecraft:sea_lantern
setblock 434 172 560 minecraft:light[level=14]
setblock 434 172 568 minecraft:light[level=14]
setblock 434 172 576 minecraft:light[level=14]
setblock 434 172 584 minecraft:light[level=14]
setblock 434 172 592 minecraft:light[level=14]
fill 434 172 599 434 177 599 minecraft:sea_lantern
fill 438 172 557 438 177 557 minecraft:sea_lantern
setblock 442 172 560 minecraft:light[level=14]
setblock 442 172 568 minecraft:light[level=14]
setblock 442 172 576 minecraft:light[level=14]
setblock 442 172 584 minecraft:light[level=14]
setblock 442 172 592 minecraft:light[level=14]
fill 442 172 599 442 177 599 minecraft:sea_lantern
fill 446 172 557 446 177 557 minecraft:sea_lantern
setblock 450 172 560 minecraft:light[level=14]
setblock 450 172 568 minecraft:light[level=14]
setblock 450 172 576 minecraft:light[level=14]
setblock 450 172 584 minecraft:light[level=14]
setblock 450 172 592 minecraft:light[level=14]
fill 450 172 599 450 177 599 minecraft:sea_lantern
fill 454 172 557 454 177 557 minecraft:sea_lantern
setblock 458 172 560 minecraft:light[level=14]
setblock 458 172 568 minecraft:light[level=14]
setblock 458 172 576 minecraft:light[level=14]
setblock 458 172 584 minecraft:light[level=14]
setblock 458 172 592 minecraft:light[level=14]
fill 458 172 599 458 177 599 minecraft:sea_lantern
fill 462 172 557 462 177 557 minecraft:sea_lantern
fill 465 172 562 465 177 562 minecraft:sea_lantern
fill 465 172 570 465 177 570 minecraft:sea_lantern
fill 465 172 578 465 177 578 minecraft:sea_lantern
fill 465 172 586 465 177 586 minecraft:sea_lantern
fill 465 172 594 465 177 594 minecraft:sea_lantern
fill 423 178 562 423 190 562 minecraft:lime_concrete
fill 423 178 570 423 186 570 minecraft:lime_concrete
fill 423 178 578 423 190 578 minecraft:lime_concrete
fill 423 178 586 423 190 586 minecraft:lime_concrete
fill 423 178 594 423 187 594 minecraft:lime_concrete
fill 426 178 574 427 179 582 minecraft:white_concrete
fill 426 178 599 426 190 599 minecraft:lime_concrete
fill 427 178 571 428 179 573 minecraft:white_concrete
fill 427 178 583 428 179 585 minecraft:white_concrete
fill 428 178 569 429 179 570 minecraft:white_concrete
fill 428 178 586 429 179 587 minecraft:white_concrete
fill 429 178 568 430 179 568 minecraft:white_concrete
fill 429 178 571 429 179 571 minecraft:white_concrete
fill 429 178 585 429 179 585 minecraft:white_concrete
fill 429 178 588 430 179 588 minecraft:white_concrete
fill 430 178 557 430 192 557 minecraft:lime_concrete
fill 430 178 566 431 179 567 minecraft:white_concrete
fill 430 178 569 430 179 569 minecraft:white_concrete
fill 430 178 587 430 179 587 minecraft:white_concrete
fill 430 178 589 431 179 590 minecraft:white_concrete
fill 431 178 565 433 179 565 minecraft:white_concrete
fill 431 178 591 433 179 591 minecraft:white_concrete
fill 432 178 564 435 179 564 minecraft:white_concrete
fill 432 178 566 432 179 566 minecraft:white_concrete
fill 432 178 590 432 179 590 minecraft:white_concrete
fill 432 178 592 435 179 592 minecraft:white_concrete
fill 434 178 563 437 179 563 minecraft:white_concrete
fill 434 178 593 437 179 593 minecraft:white_concrete
fill 434 178 599 434 186 599 minecraft:lime_concrete
fill 435 178 562 439 179 562 minecraft:white_concrete
fill 435 178 594 439 179 594 minecraft:white_concrete
fill 437 178 561 451 179 561 minecraft:white_concrete
fill 437 178 595 451 179 595 minecraft:white_concrete
fill 438 178 557 438 190 557 minecraft:lime_concrete
fill 440 178 560 448 179 560 minecraft:white_concrete
fill 440 178 596 448 179 596 minecraft:white_concrete
fill 442 178 599 442 188 599 minecraft:lime_concrete
fill 446 178 557 446 191 557 minecraft:lime_concrete
fill 449 178 562 453 179 562 minecraft:white_concrete
fill 449 178 594 453 179 594 minecraft:white_concrete
fill 450 178 599 450 188 599 minecraft:lime_concrete
fill 451 178 563 454 179 563 minecraft:white_concrete
fill 451 178 593 454 179 593 minecraft:white_concrete
fill 453 178 564 456 179 564 minecraft:white_concrete
fill 453 178 592 456 179 592 minecraft:white_concrete
fill 454 178 557 454 190 557 minecraft:lime_concrete
fill 455 178 565 457 179 565 minecraft:white_concrete
fill 455 178 591 457 179 591 minecraft:white_concrete
fill 456 178 566 458 179 566 minecraft:white_concrete
fill 456 178 590 458 179 590 minecraft:white_concrete
fill 457 178 567 458 179 567 minecraft:white_concrete
fill 457 178 589 458 179 589 minecraft:white_concrete
fill 458 178 568 459 179 569 minecraft:white_concrete
fill 458 178 587 459 179 588 minecraft:white_concrete
fill 458 178 599 458 190 599 minecraft:lime_concrete
fill 459 178 570 460 179 571 minecraft:white_concrete
fill 459 178 585 460 179 586 minecraft:white_concrete
fill 460 178 569 460 179 569 minecraft:white_concrete
fill 460 178 572 461 179 573 minecraft:white_concrete
fill 460 178 583 461 179 584 minecraft:white_concrete
fill 460 178 587 460 179 587 minecraft:white_concrete
fill 461 178 571 461 179 571 minecraft:white_concrete
fill 461 178 574 462 179 582 minecraft:white_concrete
fill 461 178 585 461 179 585 minecraft:white_concrete
fill 461 178 593 463 179 593 minecraft:iron_block
fill 462 178 557 462 190 557 minecraft:lime_concrete
fill 465 178 562 465 190 562 minecraft:lime_concrete
fill 465 178 570 465 190 570 minecraft:lime_concrete
fill 465 178 578 465 190 578 minecraft:lime_concrete
fill 465 178 586 465 190 586 minecraft:lime_concrete
fill 465 178 594 465 190 594 minecraft:lime_concrete
setblock 426 180 560 minecraft:light[level=14]
setblock 426 180 568 minecraft:light[level=14]
setblock 426 180 576 minecraft:light[level=14]
setblock 426 180 584 minecraft:light[level=14]
setblock 426 180 592 minecraft:light[level=14]
setblock 434 180 560 minecraft:light[level=14]
setblock 434 180 568 minecraft:light[level=14]
setblock 434 180 576 minecraft:light[level=14]
setblock 434 180 584 minecraft:light[level=14]
setblock 434 180 592 minecraft:light[level=14]
setblock 442 180 560 minecraft:light[level=14]
setblock 442 180 568 minecraft:light[level=14]
setblock 442 180 576 minecraft:light[level=14]
setblock 442 180 584 minecraft:light[level=14]
setblock 442 180 592 minecraft:light[level=14]
fill 445 180 560 448 180 560 minecraft:sea_lantern
fill 449 180 561 451 180 561 minecraft:sea_lantern
setblock 450 180 560 minecraft:light[level=14]
setblock 450 180 568 minecraft:light[level=14]
setblock 450 180 576 minecraft:light[level=14]
setblock 450 180 584 minecraft:light[level=14]
setblock 450 180 592 minecraft:light[level=14]
fill 452 180 562 453 180 562 minecraft:sea_lantern
fill 452 180 594 453 180 594 minecraft:sea_lantern
setblock 454 180 563 minecraft:sea_lantern
setblock 454 180 593 minecraft:sea_lantern
fill 455 180 564 456 180 564 minecraft:sea_lantern
fill 455 180 592 456 180 592 minecraft:sea_lantern
fill 456 180 565 457 180 565 minecraft:sea_lantern
fill 456 180 591 457 180 591 minecraft:sea_lantern
fill 457 180 566 458 180 566 minecraft:sea_lantern
fill 457 180 590 458 180 590 minecraft:sea_lantern
setblock 458 180 560 minecraft:light[level=14]
setblock 458 180 567 minecraft:sea_lantern
setblock 458 180 568 minecraft:light[level=14]
setblock 458 180 576 minecraft:light[level=14]
setblock 458 180 584 minecraft:light[level=14]
setblock 458 180 589 minecraft:sea_lantern
setblock 458 180 592 minecraft:light[level=14]
setblock 459 180 568 minecraft:sea_lantern
setblock 459 180 588 minecraft:sea_lantern
fill 460 180 569 460 180 570 minecraft:sea_lantern
fill 460 180 586 460 180 587 minecraft:sea_lantern
fill 461 180 571 461 180 573 minecraft:sea_lantern
fill 461 180 583 461 180 585 minecraft:sea_lantern
fill 462 180 574 462 180 582 minecraft:sea_lantern
fill 424 182 558 424 182 563 minecraft:white_concrete
fill 424 182 566 425 182 571 minecraft:white_concrete
fill 424 182 574 425 182 579 minecraft:white_concrete
fill 424 182 582 425 182 587 minecraft:white_concrete
fill 424 182 590 425 182 595 minecraft:white_concrete
fill 424 182 598 429 182 598 minecraft:white_concrete
fill 425 182 559 425 182 565 minecraft:white_concrete
fill 425 182 572 425 182 573 minecraft:white_concrete
fill 425 182 580 425 182 581 minecraft:white_concrete
fill 425 182 588 425 182 589 minecraft:white_concrete
fill 425 182 596 425 182 597 minecraft:white_concrete
fill 426 182 559 463 182 559 minecraft:white_concrete
fill 426 182 597 464 182 597 minecraft:white_concrete
fill 427 182 558 432 182 558 minecraft:white_concrete
fill 432 182 598 437 182 598 minecraft:white_concrete
fill 435 182 558 440 182 558 minecraft:white_concrete
fill 440 182 598 445 182 598 minecraft:white_concrete
fill 443 182 558 448 182 558 minecraft:white_concrete
fill 448 182 598 453 182 598 minecraft:white_concrete
fill 451 182 558 456 182 558 minecraft:white_concrete
fill 456 182 598 461 182 598 minecraft:white_concrete
fill 459 182 558 464 182 558 minecraft:white_concrete
fill 463 182 560 463 182 596 minecraft:white_concrete
fill 464 182 561 464 182 566 minecraft:white_concrete
fill 464 182 569 464 182 574 minecraft:white_concrete
fill 464 182 577 464 182 582 minecraft:white_concrete
fill 464 182 585 464 182 590 minecraft:white_concrete
fill 464 182 593 464 182 596 minecraft:white_concrete
setblock 464 182 598 minecraft:white_concrete
fill 423 187 563 423 188 565 minecraft:lime_concrete
setblock 423 187 566 minecraft:yellow_concrete
fill 423 187 567 423 187 568 minecraft:lime_concrete
fill 423 187 570 423 187 571 minecraft:yellow_concrete
fill 423 187 572 423 187 576 minecraft:lime_concrete
fill 423 187 579 423 188 580 minecraft:lime_concrete
setblock 423 187 581 minecraft:yellow_concrete
fill 423 187 582 423 187 585 minecraft:lime_concrete
setblock 423 187 593 minecraft:yellow_concrete
setblock 423 187 596 minecraft:yellow_concrete
fill 423 187 597 423 190 598 minecraft:lime_concrete
fill 431 187 557 431 190 557 minecraft:lime_concrete
setblock 432 187 557 minecraft:yellow_concrete
fill 434 187 599 435 187 599 minecraft:yellow_concrete
fill 435 187 557 435 188 557 minecraft:lime_concrete
fill 435 187 575 437 187 577 minecraft:redstone_block
fill 435 187 581 437 187 583 minecraft:redstone_block
setblock 436 187 557 minecraft:yellow_concrete
fill 436 187 599 437 190 599 minecraft:lime_concrete
fill 437 187 557 437 190 557 minecraft:lime_concrete
setblock 439 187 599 minecraft:yellow_concrete
fill 440 187 583 442 187 585 minecraft:redstone_block
fill 440 187 599 441 190 599 minecraft:lime_concrete
fill 442 187 574 444 187 576 minecraft:redstone_block
setblock 443 187 599 minecraft:yellow_concrete
fill 444 187 599 445 190 599 minecraft:lime_concrete
fill 447 187 599 448 190 599 minecraft:lime_concrete
setblock 449 187 599 minecraft:yellow_concrete
setblock 454 187 599 minecraft:yellow_concrete
setblock 456 187 599 minecraft:yellow_concrete
fill 457 187 557 457 188 557 minecraft:lime_concrete
setblock 458 187 557 minecraft:yellow_concrete
setblock 459 187 557 minecraft:lime_concrete
setblock 465 187 557 minecraft:yellow_concrete
fill 465 187 558 465 190 558 minecraft:lime_concrete
setblock 465 187 559 minecraft:yellow_concrete
fill 465 187 560 465 191 560 minecraft:lime_concrete
setblock 465 187 563 minecraft:yellow_concrete
fill 465 187 564 465 191 564 minecraft:lime_concrete
setblock 465 187 565 minecraft:yellow_concrete
fill 465 187 566 465 188 567 minecraft:lime_concrete
setblock 465 187 568 minecraft:yellow_concrete
fill 465 187 571 465 188 571 minecraft:yellow_concrete
fill 465 187 572 465 190 577 minecraft:lime_concrete
fill 465 187 579 465 187 582 minecraft:lime_concrete
setblock 465 187 583 minecraft:yellow_concrete
fill 465 187 584 465 190 584 minecraft:lime_concrete
setblock 465 187 595 minecraft:yellow_concrete
setblock 465 187 597 minecraft:yellow_concrete
fill 423 188 566 423 190 566 minecraft:lime_concrete
setblock 423 188 567 minecraft:yellow_concrete
fill 423 188 568 423 190 568 minecraft:lime_concrete
fill 423 188 570 423 190 574 minecraft:lime_concrete
setblock 423 188 575 minecraft:yellow_concrete
fill 423 188 576 423 190 576 minecraft:lime_concrete
fill 423 188 581 423 188 582 minecraft:lime_concrete
fill 423 188 583 423 189 583 minecraft:yellow_concrete
fill 423 188 584 423 190 585 minecraft:lime_concrete
setblock 423 188 593 minecraft:lime_concrete
setblock 423 188 594 minecraft:yellow_concrete
fill 423 188 596 423 190 596 minecraft:lime_concrete
setblock 426 188 560 minecraft:light[level=14]
setblock 426 188 568 minecraft:light[level=14]
setblock 426 188 576 minecraft:light[level=14]
setblock 426 188 584 minecraft:light[level=14]
setblock 426 188 592 minecraft:light[level=14]
fill 427 188 573 434 189 573 minecraft:lime_concrete
fill 427 188 585 434 189 585 minecraft:lime_concrete
fill 427 188 599 427 190 599 minecraft:lime_concrete
fill 428 188 574 434 188 575 minecraft:lime_concrete
fill 428 188 583 434 188 584 minecraft:lime_concrete
setblock 428 188 599 minecraft:yellow_concrete
fill 429 188 576 434 188 576 minecraft:lime_concrete
fill 429 188 582 434 188 582 minecraft:lime_concrete
fill 429 188 599 429 190 599 minecraft:lime_concrete
fill 430 188 577 434 188 577 minecraft:lime_concrete
fill 430 188 581 434 188 581 minecraft:lime_concrete
setblock 430 188 599 minecraft:yellow_concrete
fill 431 188 599 435 188 599 minecraft:lime_concrete
fill 432 188 557 432 190 557 minecraft:lime_concrete
fill 432 188 578 438 188 578 minecraft:lime_concrete
fill 432 188 580 438 188 580 minecraft:lime_concrete
setblock 434 188 560 minecraft:light[level=14]
setblock 434 188 568 minecraft:light[level=14]
fill 434 188 579 438 188 579 minecraft:lime_concrete
setblock 434 188 592 minecraft:light[level=14]
fill 435 188 574 441 188 574 minecraft:lime_concrete
fill 435 188 584 439 188 584 minecraft:lime_concrete
setblock 436 188 557 minecraft:lime_concrete
fill 436 188 566 438 188 573 minecraft:lime_concrete
fill 436 188 585 438 188 592 minecraft:lime_concrete
fill 437 188 565 437 189 565 minecraft:lime_concrete
fill 437 188 593 437 189 593 minecraft:lime_concrete
fill 438 188 575 441 188 577 minecraft:lime_concrete
fill 438 188 581 439 188 583 minecraft:lime_concrete
fill 439 188 567 439 188 573 minecraft:lime_concrete
fill 439 188 585 439 188 591 minecraft:lime_concrete
fill 439 188 599 439 190 599 minecraft:lime_concrete
fill 440 188 569 440 188 573 minecraft:lime_concrete
fill 440 188 581 446 188 582 minecraft:lime_concrete
fill 440 188 586 440 188 589 minecraft:lime_concrete
fill 441 188 571 441 188 573 minecraft:lime_concrete
fill 441 188 586 441 188 587 minecraft:lime_concrete
setblock 442 188 560 minecraft:light[level=14]
setblock 442 188 568 minecraft:light[level=14]
fill 442 188 572 448 188 573 minecraft:lime_concrete
setblock 442 188 576 minecraft:light[level=14]
fill 442 188 577 451 188 580 minecraft:lime_concrete
setblock 442 188 584 minecraft:light[level=14]
fill 442 188 586 448 188 586 minecraft:lime_concrete
setblock 442 188 592 minecraft:light[level=14]
fill 443 188 571 448 188 571 minecraft:lime_concrete
fill 443 188 583 446 188 585 minecraft:lime_concrete
fill 443 188 587 448 188 587 minecraft:lime_concrete
fill 443 188 599 443 190 599 minecraft:lime_concrete
fill 444 188 570 449 189 570 minecraft:lime_concrete
fill 444 188 588 449 189 588 minecraft:lime_concrete
fill 445 188 574 446 188 576 minecraft:lime_concrete
fill 446 188 569 449 189 569 minecraft:lime_concrete
fill 446 188 589 449 189 589 minecraft:lime_concrete
fill 447 188 568 449 189 568 minecraft:lime_concrete
fill 447 188 574 447 189 574 minecraft:lime_concrete
fill 447 188 581 451 189 581 minecraft:lime_concrete
fill 447 188 584 447 189 585 minecraft:lime_concrete
fill 447 188 590 449 189 590 minecraft:lime_concrete
fill 448 188 585 448 189 585 minecraft:lime_concrete
fill 449 188 599 449 190 599 minecraft:lime_concrete
setblock 450 188 560 minecraft:light[level=14]
setblock 450 188 568 minecraft:light[level=14]
setblock 450 188 576 minecraft:light[level=14]
setblock 450 188 584 minecraft:light[level=14]
setblock 450 188 592 minecraft:light[level=14]
fill 452 188 578 453 189 580 minecraft:lime_concrete
fill 454 188 579 455 189 579 minecraft:lime_concrete
fill 454 188 599 454 191 599 minecraft:lime_concrete
setblock 455 188 599 minecraft:yellow_concrete
fill 456 188 599 456 190 599 minecraft:lime_concrete
fill 458 188 557 458 190 557 minecraft:lime_concrete
setblock 458 188 560 minecraft:light[level=14]
setblock 458 188 568 minecraft:light[level=14]
setblock 458 188 576 minecraft:light[level=14]
setblock 458 188 584 minecraft:light[level=14]
setblock 458 188 592 minecraft:light[level=14]
setblock 459 188 557 minecraft:yellow_concrete
fill 459 188 599 460 188 599 minecraft:lime_concrete
setblock 461 188 599 minecraft:yellow_concrete
fill 462 188 599 464 188 599 minecraft:lime_concrete
fill 465 188 557 465 190 557 minecraft:lime_concrete
fill 465 188 559 465 190 559 minecraft:lime_concrete
fill 465 188 563 465 190 563 minecraft:lime_concrete
fill 465 188 565 465 190 565 minecraft:lime_concrete
fill 465 188 568 465 190 568 minecraft:lime_concrete
fill 465 188 579 465 190 581 minecraft:lime_concrete
setblock 465 188 582 minecraft:yellow_concrete
fill 465 188 583 465 191 583 minecraft:lime_concrete
fill 465 188 595 465 190 595 minecraft:lime_concrete
fill 465 188 597 465 191 597 minecraft:lime_concrete
setblock 465 188 599 minecraft:yellow_concrete
fill 423 189 563 423 190 563 minecraft:lime_concrete
setblock 423 189 564 minecraft:yellow_concrete
fill 423 189 565 423 190 565 minecraft:lime_concrete
fill 423 189 567 423 190 567 minecraft:lime_concrete
fill 423 189 575 423 190 575 minecraft:lime_concrete
setblock 423 189 579 minecraft:yellow_concrete
fill 423 189 580 423 190 580 minecraft:lime_concrete
setblock 423 189 581 minecraft:yellow_concrete
fill 423 189 582 423 190 582 minecraft:lime_concrete
fill 423 189 589 423 190 590 minecraft:lime_concrete
setblock 423 189 591 minecraft:yellow_concrete
fill 423 189 592 423 190 592 minecraft:lime_concrete
setblock 423 189 593 minecraft:yellow_concrete
fill 423 189 594 423 190 594 minecraft:lime_concrete
fill 424 189 557 424 190 557 minecraft:lime_concrete
fill 424 189 558 426 189 598 minecraft:black_concrete
setblock 425 189 557 minecraft:yellow_concrete
setblock 425 189 599 minecraft:yellow_concrete
fill 426 189 557 426 190 557 minecraft:lime_concrete
fill 427 189 558 435 189 572 minecraft:black_concrete
fill 427 189 574 427 189 584 minecraft:black_concrete
fill 427 189 586 435 189 598 minecraft:black_concrete
fill 428 189 574 430 189 575 minecraft:lime_concrete
fill 428 189 576 428 189 582 minecraft:black_concrete
fill 428 189 583 430 189 584 minecraft:lime_concrete
fill 428 189 599 428 190 599 minecraft:lime_concrete
fill 429 189 576 431 189 576 minecraft:lime_concrete
fill 429 189 577 429 189 581 minecraft:black_concrete
fill 429 189 582 431 189 582 minecraft:lime_concrete
fill 430 189 577 432 189 577 minecraft:lime_concrete
fill 430 189 578 431 189 580 minecraft:black_concrete
fill 430 189 581 432 189 581 minecraft:lime_concrete
fill 430 189 599 431 190 599 minecraft:lime_concrete
fill 431 189 574 433 189 574 minecraft:lime_concrete
fill 431 189 575 433 189 575 minecraft:light_blue_concrete
fill 431 189 583 433 189 583 minecraft:light_blue_concrete
fill 431 189 584 433 189 584 minecraft:lime_concrete
fill 432 189 576 433 189 576 minecraft:light_blue_concrete
fill 432 189 578 433 189 578 minecraft:lime_concrete
fill 432 189 579 433 189 579 minecraft:black_concrete
fill 432 189 580 433 189 580 minecraft:lime_concrete
fill 432 189 582 433 189 582 minecraft:light_blue_concrete
setblock 432 189 599 minecraft:yellow_concrete
setblock 433 189 577 minecraft:light_blue_concrete
setblock 433 189 581 minecraft:light_blue_concrete
fill 433 189 599 435 190 599 minecraft:lime_concrete
fill 434 189 574 434 189 578 minecraft:sea_lantern
fill 434 189 579 435 189 579 minecraft:lime_concrete
fill 434 189 580 434 189 584 minecraft:sea_lantern
fill 435 189 557 436 189 557 minecraft:yellow_concrete
setblock 435 189 573 minecraft:black_concrete
fill 435 189 574 438 189 574 minecraft:sea_lantern
fill 435 189 575 437 189 577 minecraft:black_concrete
fill 435 189 578 437 189 578 minecraft:sea_lantern
fill 435 189 580 437 189 580 minecraft:sea_lantern
fill 435 189 581 437 189 583 minecraft:black_concrete
fill 435 189 584 439 189 584 minecraft:sea_lantern
setblock 435 189 585 minecraft:black_concrete
fill 436 189 558 436 189 565 minecraft:black_concrete
fill 436 189 566 436 189 573 minecraft:lime_concrete
fill 436 189 579 437 189 579 minecraft:magenta_concrete
fill 436 189 585 436 189 592 minecraft:lime_concrete
fill 436 189 593 436 189 598 minecraft:black_concrete
fill 437 189 558 464 189 564 minecraft:black_concrete
fill 437 189 566 437 189 570 minecraft:lime_concrete
fill 437 189 571 439 189 573 minecraft:light_blue_concrete
fill 437 189 585 438 189 587 minecraft:light_blue_concrete
fill 437 189 588 437 189 592 minecraft:lime_concrete
fill 437 189 594 464 189 598 minecraft:black_concrete
fill 438 189 565 464 189 565 minecraft:black_concrete
fill 438 189 566 438 189 569 minecraft:lime_concrete
setblock 438 189 570 minecraft:light_blue_concrete
fill 438 189 575 438 189 577 minecraft:sea_lantern
fill 438 189 578 438 189 580 minecraft:shroomlight
fill 438 189 581 438 189 583 minecraft:sea_lantern
setblock 438 189 588 minecraft:light_blue_concrete
fill 438 189 589 438 189 592 minecraft:lime_concrete
fill 438 189 593 464 189 593 minecraft:black_concrete
fill 439 189 566 464 189 566 minecraft:black_concrete
fill 439 189 567 439 189 570 minecraft:lime_concrete
fill 439 189 574 439 189 575 minecraft:light_blue_concrete
fill 439 189 576 440 189 576 minecraft:magenta_concrete
fill 439 189 577 441 189 577 minecraft:shroomlight
fill 439 189 581 441 189 581 minecraft:shroomlight
fill 439 189 582 439 189 583 minecraft:sea_lantern
fill 439 189 585 439 189 586 minecraft:sea_lantern
setblock 439 189 587 minecraft:light_blue_concrete
fill 439 189 588 439 189 591 minecraft:lime_concrete
fill 439 189 592 464 189 592 minecraft:black_concrete
fill 440 189 567 446 189 568 minecraft:black_concrete
fill 440 189 569 440 189 571 minecraft:lime_concrete
fill 440 189 572 440 189 574 minecraft:light_blue_concrete
setblock 440 189 575 minecraft:magenta_concrete
fill 440 189 582 443 189 582 minecraft:sea_lantern
fill 440 189 583 442 189 585 minecraft:black_concrete
fill 440 189 586 443 189 586 minecraft:sea_lantern
fill 440 189 587 440 189 589 minecraft:lime_concrete
fill 440 189 590 446 189 591 minecraft:black_concrete
fill 441 189 569 443 189 570 minecraft:black_concrete
fill 441 189 571 441 189 572 minecraft:lime_concrete
fill 441 189 573 441 189 576 minecraft:sea_lantern
setblock 441 189 587 minecraft:lime_concrete
fill 441 189 588 443 189 589 minecraft:black_concrete
setblock 442 189 571 minecraft:black_concrete
fill 442 189 572 443 189 572 minecraft:lime_concrete
fill 442 189 573 445 189 573 minecraft:sea_lantern
fill 442 189 574 444 189 576 minecraft:black_concrete
fill 442 189 577 445 189 577 minecraft:sea_lantern
fill 442 189 578 442 189 580 minecraft:shroomlight
setblock 442 189 581 minecraft:sea_lantern
setblock 442 189 587 minecraft:black_concrete
setblock 442 189 599 minecraft:yellow_concrete
fill 443 189 571 445 189 571 minecraft:lime_concrete
fill 443 189 578 443 189 581 minecraft:magenta_concrete
fill 443 189 583 443 189 585 minecraft:sea_lantern
fill 443 189 587 445 189 587 minecraft:lime_concrete
fill 444 189 569 445 189 569 minecraft:black_concrete
fill 444 189 572 446 189 572 minecraft:light_blue_concrete
fill 444 189 578 449 189 578 minecraft:light_blue_concrete
setblock 444 189 579 minecraft:magenta_concrete
fill 444 189 580 445 189 586 minecraft:light_blue_concrete
fill 444 189 589 445 189 589 minecraft:black_concrete
fill 445 189 574 445 189 576 minecraft:sea_lantern
fill 445 189 579 450 189 579 minecraft:light_blue_concrete
setblock 446 189 571 minecraft:light_blue_concrete
fill 446 189 573 446 189 574 minecraft:light_blue_concrete
fill 446 189 575 446 189 576 minecraft:lime_concrete
setblock 446 189 577 minecraft:light_blue_concrete
fill 446 189 580 446 189 581 minecraft:light_blue_concrete
fill 446 189 582 446 189 583 minecraft:lime_concrete
fill 446 189 584 446 189 587 minecraft:light_blue_concrete
fill 447 189 557 449 190 557 minecraft:lime_concrete
fill 447 189 567 464 189 567 minecraft:black_concrete
fill 447 189 571 448 189 573 minecraft:lime_concrete
fill 447 189 575 464 189 576 minecraft:black_concrete
fill 447 189 577 451 189 577 minecraft:lime_concrete
fill 447 189 580 449 189 580 minecraft:light_blue_concrete
fill 447 189 582 464 189 583 minecraft:black_concrete
fill 447 189 586 448 189 587 minecraft:lime_concrete
fill 447 189 591 464 189 591 minecraft:black_concrete
fill 448 189 574 464 189 574 minecraft:black_concrete
fill 448 189 584 464 189 584 minecraft:black_concrete
fill 449 189 571 464 189 573 minecraft:black_concrete
fill 449 189 585 464 189 587 minecraft:black_concrete
setblock 450 189 557 minecraft:yellow_concrete
fill 450 189 568 464 189 570 minecraft:black_concrete
fill 450 189 578 451 189 578 minecraft:lime_concrete
fill 450 189 580 451 189 580 minecraft:lime_concrete
fill 450 189 588 464 189 590 minecraft:black_concrete
fill 450 189 599 451 189 599 minecraft:yellow_concrete
fill 451 189 557 453 190 557 minecraft:lime_concrete
setblock 451 189 579 minecraft:lime_concrete
fill 452 189 577 464 189 577 minecraft:black_concrete
fill 452 189 581 464 189 581 minecraft:black_concrete
fill 452 189 599 453 190 599 minecraft:lime_concrete
fill 454 189 578 464 189 578 minecraft:black_concrete
fill 454 189 580 464 189 580 minecraft:black_concrete
fill 455 189 599 455 190 599 minecraft:lime_concrete
fill 456 189 579 464 189 579 minecraft:black_concrete
setblock 457 189 557 minecraft:yellow_concrete
fill 459 189 557 459 190 557 minecraft:lime_concrete
fill 459 189 599 459 190 599 minecraft:lime_concrete
setblock 460 189 599 minecraft:yellow_concrete
fill 461 189 599 461 191 599 minecraft:lime_concrete
setblock 462 189 599 minecraft:yellow_concrete
fill 463 189 599 465 190 599 minecraft:lime_concrete
setblock 465 189 561 minecraft:yellow_concrete
setblock 465 189 566 minecraft:yellow_concrete
fill 465 189 567 465 191 567 minecraft:lime_concrete
fill 465 189 571 465 190 571 minecraft:lime_concrete
fill 465 189 582 465 190 582 minecraft:lime_concrete
fill 465 189 588 465 190 592 minecraft:lime_concrete
setblock 465 189 593 minecraft:yellow_concrete
setblock 465 189 598 minecraft:yellow_concrete
setblock 423 190 564 minecraft:lime_concrete
setblock 423 190 579 minecraft:lime_concrete
setblock 423 190 581 minecraft:lime_concrete
setblock 423 190 583 minecraft:lime_concrete
setblock 423 190 591 minecraft:lime_concrete
setblock 423 190 593 minecraft:lime_concrete
fill 424 190 563 425 190 595 minecraft:basalt
fill 425 190 557 425 191 557 minecraft:lime_concrete
fill 425 190 562 428 190 562 minecraft:basalt
setblock 425 190 596 minecraft:basalt
setblock 425 190 599 minecraft:lime_concrete
fill 426 190 561 431 190 561 minecraft:basalt
setblock 426 190 563 minecraft:magma_block
fill 426 190 564 428 192 565 minecraft:basalt
setblock 426 190 566 minecraft:magma_block
fill 426 190 567 428 195 568 minecraft:basalt
setblock 426 190 569 minecraft:magma_block
fill 426 190 570 428 197 571 minecraft:basalt
setblock 426 190 572 minecraft:magma_block
fill 426 190 573 426 198 574 minecraft:basalt
setblock 426 190 575 minecraft:magma_block
fill 426 190 576 426 199 576 minecraft:basalt
fill 426 190 582 426 199 583 minecraft:basalt
setblock 426 190 584 minecraft:magma_block
fill 426 190 585 427 198 586 minecraft:basalt
setblock 426 190 587 minecraft:magma_block
fill 426 190 588 428 196 589 minecraft:basalt
setblock 426 190 590 minecraft:magma_block
fill 426 190 591 428 194 592 minecraft:basalt
setblock 426 190 593 minecraft:magma_block
fill 426 190 594 428 192 595 minecraft:basalt
setblock 426 190 596 minecraft:magma_block
fill 426 190 597 431 190 597 minecraft:basalt
fill 427 190 560 434 190 560 minecraft:basalt
fill 427 190 563 434 191 563 minecraft:basalt
fill 427 190 566 434 195 566 minecraft:basalt
fill 427 190 569 429 197 569 minecraft:basalt
fill 427 190 572 427 199 573 minecraft:basalt
fill 427 190 587 428 198 587 minecraft:basalt
fill 427 190 590 431 190 590 minecraft:basalt
fill 427 190 593 434 194 593 minecraft:basalt
fill 427 190 596 434 191 596 minecraft:basalt
fill 427 190 598 428 190 598 minecraft:basalt
setblock 429 190 559 minecraft:magma_block
setblock 429 190 562 minecraft:magma_block
fill 429 190 564 431 194 564 minecraft:basalt
setblock 429 190 565 minecraft:magma_block
fill 429 190 567 431 197 567 minecraft:basalt
setblock 429 190 568 minecraft:magma_block
fill 429 190 570 429 200 570 minecraft:basalt
fill 429 190 588 429 200 588 minecraft:basalt
setblock 429 190 589 minecraft:magma_block
fill 429 190 591 431 197 591 minecraft:basalt
setblock 429 190 592 minecraft:magma_block
fill 429 190 594 431 194 594 minecraft:basalt
setblock 429 190 595 minecraft:magma_block
setblock 429 190 598 minecraft:magma_block
fill 430 190 559 437 190 559 minecraft:basalt
fill 430 190 562 437 193 562 minecraft:basalt
fill 430 190 565 437 196 565 minecraft:basalt
fill 430 190 568 431 199 568 minecraft:basalt
fill 430 190 592 434 190 592 minecraft:basalt
fill 430 190 595 437 194 595 minecraft:basalt
fill 430 190 598 437 191 598 minecraft:basalt
setblock 431 190 558 minecraft:basalt
setblock 432 190 558 minecraft:magma_block
setblock 432 190 561 minecraft:magma_block
setblock 432 190 564 minecraft:magma_block
setblock 432 190 567 minecraft:magma_block
setblock 432 190 591 minecraft:magma_block
setblock 432 190 594 minecraft:magma_block
setblock 432 190 597 minecraft:magma_block
fill 432 190 599 432 192 599 minecraft:lime_concrete
fill 433 190 558 440 190 558 minecraft:basalt
fill 433 190 561 440 193 561 minecraft:basalt
fill 433 190 564 440 197 564 minecraft:basalt
fill 433 190 594 440 197 594 minecraft:basalt
fill 433 190 597 440 193 597 minecraft:basalt
fill 435 190 557 436 190 557 minecraft:lime_concrete
setblock 435 190 560 minecraft:magma_block
setblock 435 190 563 minecraft:magma_block
setblock 435 190 593 minecraft:magma_block
setblock 435 190 596 minecraft:magma_block
fill 436 190 560 443 193 560 minecraft:basalt
fill 436 190 563 443 196 563 minecraft:basalt
fill 436 190 593 437 199 593 minecraft:basalt
fill 436 190 596 443 195 596 minecraft:basalt
setblock 438 190 559 minecraft:magma_block
setblock 438 190 562 minecraft:magma_block
setblock 438 190 595 minecraft:magma_block
setblock 438 190 598 minecraft:magma_block
fill 439 190 559 446 192 559 minecraft:basalt
fill 439 190 562 446 195 562 minecraft:basalt
fill 439 190 595 446 196 595 minecraft:basalt
fill 439 190 598 446 193 598 minecraft:basalt
setblock 441 190 558 minecraft:magma_block
setblock 441 190 561 minecraft:magma_block
setblock 441 190 564 minecraft:magma_block
setblock 441 190 594 minecraft:magma_block
setblock 441 190 597 minecraft:magma_block
fill 442 190 558 449 190 558 minecraft:basalt
fill 442 190 561 449 193 561 minecraft:basalt
fill 442 190 564 449 196 564 minecraft:basalt
fill 442 190 594 449 196 594 minecraft:basalt
fill 442 190 597 449 193 597 minecraft:basalt
fill 442 190 599 442 191 599 minecraft:lime_concrete
fill 443 190 565 446 190 565 minecraft:basalt
fill 443 190 593 443 199 593 minecraft:basalt
setblock 444 190 560 minecraft:magma_block
setblock 444 190 563 minecraft:magma_block
setblock 444 190 593 minecraft:magma_block
setblock 444 190 596 minecraft:magma_block
fill 445 190 560 452 190 560 minecraft:basalt
fill 445 190 563 452 193 563 minecraft:basalt
fill 445 190 593 452 195 593 minecraft:basalt
fill 445 190 596 452 192 596 minecraft:basalt
fill 446 190 566 452 196 566 minecraft:basalt
fill 446 190 592 446 199 592 minecraft:basalt
setblock 447 190 559 minecraft:magma_block
setblock 447 190 562 minecraft:magma_block
setblock 447 190 565 minecraft:magma_block
setblock 447 190 592 minecraft:magma_block
setblock 447 190 595 minecraft:magma_block
setblock 447 190 598 minecraft:magma_block
fill 448 190 559 451 190 559 minecraft:basalt
fill 448 190 562 455 190 562 minecraft:basalt
fill 448 190 565 455 192 565 minecraft:basalt
fill 448 190 567 449 199 567 minecraft:basalt
fill 448 190 591 449 198 592 minecraft:basalt
fill 448 190 595 455 191 595 minecraft:basalt
fill 448 190 598 453 190 598 minecraft:basalt
fill 449 190 568 455 195 568 minecraft:basalt
fill 449 190 590 452 190 590 minecraft:basalt
setblock 450 190 557 minecraft:lime_concrete
setblock 450 190 561 minecraft:magma_block
setblock 450 190 564 minecraft:magma_block
setblock 450 190 567 minecraft:magma_block
setblock 450 190 591 minecraft:magma_block
fill 450 190 592 455 193 592 minecraft:basalt
setblock 450 190 594 minecraft:magma_block
setblock 450 190 597 minecraft:magma_block
fill 450 190 599 451 190 599 minecraft:lime_concrete
fill 451 190 561 454 190 561 minecraft:basalt
fill 451 190 564 457 190 564 minecraft:basalt
fill 451 190 567 458 191 567 minecraft:basalt
fill 451 190 569 452 198 570 minecraft:basalt
fill 451 190 588 455 195 589 minecraft:basalt
fill 451 190 591 458 191 591 minecraft:basalt
fill 451 190 594 457 190 594 minecraft:basalt
fill 451 190 597 454 190 597 minecraft:basalt
fill 452 190 571 455 196 571 minecraft:basalt
fill 452 190 587 452 199 587 minecraft:basalt
setblock 453 190 560 minecraft:magma_block
setblock 453 190 563 minecraft:magma_block
setblock 453 190 566 minecraft:magma_block
setblock 453 190 569 minecraft:magma_block
fill 453 190 570 458 193 570 minecraft:basalt
setblock 453 190 572 minecraft:magma_block
fill 453 190 573 458 194 573 minecraft:basalt
fill 453 190 585 455 196 586 minecraft:basalt
setblock 453 190 587 minecraft:magma_block
setblock 453 190 590 minecraft:magma_block
setblock 453 190 593 minecraft:magma_block
setblock 453 190 596 minecraft:magma_block
fill 454 190 563 456 190 563 minecraft:basalt
fill 454 190 566 459 190 566 minecraft:basalt
fill 454 190 569 460 190 569 minecraft:basalt
fill 454 190 572 461 191 572 minecraft:basalt
fill 454 190 574 455 198 576 minecraft:basalt
fill 454 190 582 455 198 584 minecraft:basalt
fill 454 190 587 461 190 587 minecraft:basalt
fill 454 190 590 460 190 590 minecraft:basalt
fill 454 190 593 458 190 593 minecraft:basalt
fill 454 190 596 455 190 596 minecraft:basalt
fill 455 190 577 455 199 581 minecraft:basalt
setblock 456 190 565 minecraft:magma_block
setblock 456 190 568 minecraft:magma_block
setblock 456 190 571 minecraft:magma_block
setblock 456 190 574 minecraft:magma_block
fill 456 190 575 458 195 576 minecraft:basalt
setblock 456 190 577 minecraft:magma_block
fill 456 190 578 458 195 579 minecraft:basalt
setblock 456 190 580 minecraft:magma_block
fill 456 190 581 458 195 582 minecraft:basalt
setblock 456 190 583 minecraft:magma_block
fill 456 190 584 458 194 585 minecraft:basalt
setblock 456 190 586 minecraft:magma_block
fill 456 190 588 458 193 588 minecraft:basalt
setblock 456 190 589 minecraft:magma_block
setblock 456 190 592 minecraft:magma_block
setblock 456 190 595 minecraft:magma_block
setblock 457 190 557 minecraft:lime_concrete
fill 457 190 565 458 190 565 minecraft:basalt
fill 457 190 568 460 190 568 minecraft:basalt
fill 457 190 571 461 190 571 minecraft:basalt
fill 457 190 574 462 190 574 minecraft:basalt
fill 457 190 577 462 191 577 minecraft:basalt
fill 457 190 580 463 190 580 minecraft:basalt
fill 457 190 583 462 190 583 minecraft:basalt
fill 457 190 586 461 190 586 minecraft:basalt
fill 457 190 589 460 190 589 minecraft:basalt
fill 457 190 592 459 190 592 minecraft:basalt
setblock 459 190 567 minecraft:magma_block
setblock 459 190 570 minecraft:magma_block
setblock 459 190 573 minecraft:magma_block
fill 459 190 575 461 191 575 minecraft:basalt
setblock 459 190 576 minecraft:magma_block
fill 459 190 578 461 192 578 minecraft:basalt
setblock 459 190 579 minecraft:magma_block
fill 459 190 581 461 192 581 minecraft:basalt
setblock 459 190 582 minecraft:magma_block
fill 459 190 584 461 191 584 minecraft:basalt
setblock 459 190 585 minecraft:magma_block
setblock 459 190 588 minecraft:magma_block
setblock 459 190 591 minecraft:magma_block
fill 460 190 570 461 190 570 minecraft:basalt
fill 460 190 573 462 190 573 minecraft:basalt
fill 460 190 576 462 190 576 minecraft:basalt
fill 460 190 579 463 190 579 minecraft:basalt
fill 460 190 582 462 190 582 minecraft:basalt
fill 460 190 585 462 190 585 minecraft:basalt
fill 460 190 588 461 190 588 minecraft:basalt
setblock 460 190 599 minecraft:lime_concrete
setblock 462 190 575 minecraft:magma_block
setblock 462 190 578 minecraft:magma_block
setblock 462 190 581 minecraft:magma_block
setblock 462 190 584 minecraft:magma_block
setblock 462 190 599 minecraft:lime_concrete
setblock 463 190 578 minecraft:basalt
setblock 465 190 561 minecraft:lime_concrete
setblock 465 190 566 minecraft:lime_concrete
setblock 465 190 593 minecraft:lime_concrete
setblock 465 190 598 minecraft:lime_concrete
fill 423 191 557 423 192 569 minecraft:yellow_concrete
setblock 423 191 570 minecraft:lime_concrete
fill 423 191 571 423 191 586 minecraft:yellow_concrete
fill 423 191 588 423 191 597 minecraft:yellow_concrete
setblock 423 191 598 minecraft:lime_concrete
fill 423 191 599 431 191 599 minecraft:yellow_concrete
fill 424 191 557 424 229 557 minecraft:yellow_concrete
fill 424 191 564 425 191 594 minecraft:basalt
fill 425 191 563 426 191 563 minecraft:basalt
setblock 425 191 595 minecraft:magma_block
fill 426 191 557 429 191 557 minecraft:yellow_concrete
fill 426 191 562 429 191 562 minecraft:basalt
fill 426 191 566 426 194 566 minecraft:basalt
fill 426 191 569 426 196 569 minecraft:basalt
fill 426 191 572 426 198 572 minecraft:basalt
fill 426 191 575 427 191 575 minecraft:basalt
fill 426 191 577 426 200 581 minecraft:basalt
fill 426 191 584 427 198 584 minecraft:basalt
fill 426 191 587 426 197 587 minecraft:basalt
fill 426 191 590 430 196 590 minecraft:basalt
fill 426 191 593 426 193 593 minecraft:basalt
setblock 426 191 596 minecraft:basalt
fill 427 191 574 427 200 574 minecraft:basalt
fill 427 191 583 427 200 583 minecraft:basalt
setblock 428 191 561 minecraft:magma_block
fill 428 191 572 428 200 572 minecraft:basalt
fill 428 191 586 428 200 586 minecraft:basalt
setblock 428 191 597 minecraft:magma_block
fill 429 191 560 432 191 561 minecraft:basalt
fill 429 191 565 429 196 565 minecraft:basalt
fill 429 191 568 429 198 568 minecraft:basalt
fill 429 191 571 429 200 571 minecraft:basalt
fill 429 191 587 429 200 587 minecraft:basalt
fill 429 191 589 430 198 589 minecraft:basalt
fill 429 191 592 433 196 592 minecraft:basalt
fill 429 191 595 429 194 595 minecraft:basalt
fill 429 191 597 429 191 598 minecraft:basalt
fill 430 191 569 430 200 569 minecraft:basalt
fill 430 191 597 432 192 597 minecraft:basalt
fill 431 191 557 439 192 557 minecraft:yellow_concrete
fill 431 191 559 438 191 559 minecraft:basalt
setblock 431 191 590 minecraft:magma_block
fill 432 191 564 432 196 564 minecraft:basalt
fill 432 191 567 432 198 568 minecraft:basalt
fill 432 191 590 432 198 591 minecraft:basalt
fill 432 191 594 432 196 594 minecraft:basalt
fill 433 191 558 436 191 558 minecraft:basalt
fill 433 191 560 435 193 560 minecraft:basalt
fill 433 191 567 433 200 567 minecraft:basalt
fill 433 191 591 433 200 591 minecraft:basalt
fill 433 191 599 440 192 599 minecraft:yellow_concrete
setblock 434 191 592 minecraft:magma_block
fill 435 191 563 435 197 563 minecraft:basalt
fill 435 191 566 436 191 566 minecraft:basalt
fill 435 191 592 435 198 593 minecraft:basalt
fill 435 191 596 435 196 596 minecraft:basalt
fill 436 191 592 436 200 592 minecraft:basalt
setblock 437 191 558 minecraft:magma_block
fill 438 191 558 445 191 558 minecraft:basalt
fill 438 191 562 438 196 562 minecraft:basalt
fill 438 191 565 442 200 565 minecraft:basalt
fill 438 191 593 439 200 593 minecraft:basalt
fill 438 191 595 438 197 595 minecraft:basalt
fill 438 191 598 438 194 598 minecraft:basalt
setblock 440 191 593 minecraft:magma_block
fill 441 191 557 445 229 557 minecraft:yellow_concrete
fill 441 191 561 441 195 561 minecraft:basalt
fill 441 191 564 441 198 564 minecraft:basalt
fill 441 191 593 441 198 594 minecraft:basalt
fill 441 191 597 441 195 597 minecraft:basalt
setblock 441 191 599 minecraft:lime_concrete
fill 442 191 593 442 200 593 minecraft:basalt
setblock 443 191 565 minecraft:magma_block
fill 443 191 599 449 227 599 minecraft:yellow_concrete
fill 444 191 560 451 191 560 minecraft:basalt
fill 444 191 563 444 197 563 minecraft:basalt
fill 444 191 565 445 199 566 minecraft:basalt
fill 444 191 592 444 198 593 minecraft:basalt
fill 444 191 596 444 196 596 minecraft:basalt
fill 445 191 592 445 200 592 minecraft:basalt
setblock 446 191 558 minecraft:magma_block
fill 446 191 565 447 198 565 minecraft:basalt
setblock 447 191 557 minecraft:lime_concrete
fill 447 191 558 447 191 559 minecraft:basalt
fill 447 191 562 454 191 562 minecraft:basalt
fill 447 191 567 447 200 567 minecraft:basalt
fill 447 191 591 447 198 592 minecraft:basalt
fill 447 191 595 447 196 595 minecraft:basalt
fill 447 191 598 451 191 598 minecraft:basalt
fill 448 191 557 459 192 557 minecraft:yellow_concrete
fill 448 191 559 449 191 559 minecraft:basalt
setblock 448 191 568 minecraft:basalt
fill 448 191 590 448 200 590 minecraft:basalt
setblock 449 191 590 minecraft:magma_block
fill 450 191 561 452 191 561 minecraft:basalt
fill 450 191 564 456 191 564 minecraft:basalt
fill 450 191 567 450 198 567 minecraft:basalt
fill 450 191 569 450 200 569 minecraft:basalt
fill 450 191 589 450 198 591 minecraft:basalt
fill 450 191 594 456 191 594 minecraft:basalt
fill 450 191 597 452 191 597 minecraft:basalt
setblock 450 191 599 minecraft:lime_concrete
fill 451 191 571 451 200 571 minecraft:basalt
fill 451 191 587 451 200 587 minecraft:basalt
fill 451 191 590 459 191 590 minecraft:basalt
fill 451 191 599 453 225 599 minecraft:yellow_concrete
fill 452 191 572 453 198 572 minecraft:basalt
setblock 452 191 586 minecraft:magma_block
fill 453 191 563 455 191 563 minecraft:basalt
fill 453 191 566 457 191 566 minecraft:basalt
fill 453 191 569 459 191 569 minecraft:basalt
fill 453 191 574 453 200 575 minecraft:basalt
fill 453 191 583 453 200 584 minecraft:basalt
fill 453 191 587 460 191 587 minecraft:basalt
fill 453 191 593 457 191 593 minecraft:basalt
fill 453 191 596 454 191 596 minecraft:basalt
fill 454 191 577 454 200 581 minecraft:basalt
fill 455 191 599 460 191 599 minecraft:yellow_concrete
fill 456 191 565 457 191 565 minecraft:basalt
fill 456 191 568 459 191 568 minecraft:basalt
fill 456 191 571 460 191 571 minecraft:basalt
fill 456 191 574 460 192 574 minecraft:basalt
fill 456 191 577 456 197 577 minecraft:basalt
fill 456 191 580 462 191 580 minecraft:basalt
fill 456 191 583 460 193 583 minecraft:basalt
fill 456 191 586 460 192 586 minecraft:basalt
fill 456 191 589 459 191 589 minecraft:basalt
fill 456 191 592 457 191 592 minecraft:basalt
fill 459 191 570 460 191 570 minecraft:basalt
fill 459 191 573 461 191 573 minecraft:basalt
fill 459 191 576 461 192 576 minecraft:basalt
fill 459 191 579 462 191 579 minecraft:basalt
fill 459 191 582 461 192 582 minecraft:basalt
fill 459 191 585 461 191 585 minecraft:basalt
fill 459 191 588 460 191 588 minecraft:basalt
setblock 460 191 557 minecraft:lime_concrete
fill 461 191 557 465 191 557 minecraft:yellow_concrete
setblock 461 191 574 minecraft:magma_block
setblock 461 191 583 minecraft:magma_block
setblock 461 191 586 minecraft:magma_block
setblock 462 191 578 minecraft:basalt
setblock 462 191 581 minecraft:basalt
fill 462 191 599 465 226 599 minecraft:yellow_concrete
fill 465 191 558 465 225 559 minecraft:yellow_concrete
fill 465 191 561 465 199 563 minecraft:yellow_concrete
fill 465 191 565 465 225 566 minecraft:yellow_concrete
fill 465 191 568 465 191 578 minecraft:yellow_concrete
setblock 465 191 579 minecraft:lime_concrete
fill 465 191 580 465 191 582 minecraft:yellow_concrete
fill 465 191 584 465 199 586 minecraft:yellow_concrete
fill 465 191 588 465 191 596 minecraft:yellow_concrete
fill 465 191 598 465 227 598 minecraft:yellow_concrete
fill 423 192 570 423 192 581 minecraft:yellow_concrete
setblock 423 192 582 minecraft:lime_concrete
fill 423 192 583 423 192 591 minecraft:yellow_concrete
setblock 423 192 592 minecraft:lime_concrete
fill 423 192 593 423 192 599 minecraft:yellow_concrete
fill 424 192 565 425 192 593 minecraft:basalt
fill 424 192 599 425 229 599 minecraft:yellow_concrete
fill 425 192 557 428 227 557 minecraft:yellow_concrete
setblock 425 192 564 minecraft:basalt
setblock 425 192 594 minecraft:basalt
setblock 426 192 563 minecraft:basalt
fill 426 192 575 426 198 575 minecraft:basalt
setblock 426 192 599 minecraft:lime_concrete
setblock 427 192 563 minecraft:magma_block
setblock 427 192 575 minecraft:magma_block
fill 427 192 576 427 201 577 minecraft:basalt
setblock 427 192 578 minecraft:magma_block
fill 427 192 579 427 201 580 minecraft:basalt
setblock 427 192 581 minecraft:magma_block
fill 427 192 582 427 201 582 minecraft:basalt
fill 427 192 599 431 192 599 minecraft:yellow_concrete
fill 428 192 562 429 192 563 minecraft:basalt
fill 428 192 573 428 199 574 minecraft:basalt
fill 428 192 584 428 199 585 minecraft:basalt
fill 428 192 596 434 192 596 minecraft:basalt
setblock 429 192 557 minecraft:lime_concrete
fill 429 192 561 432 192 561 minecraft:basalt
fill 429 192 572 429 201 572 minecraft:basalt
fill 429 192 586 429 201 586 minecraft:basalt
setblock 429 192 597 minecraft:basalt
fill 430 192 563 434 194 563 minecraft:basalt
fill 430 192 570 430 200 570 minecraft:basalt
fill 430 192 588 430 200 588 minecraft:basalt
fill 431 192 560 432 192 560 minecraft:basalt
fill 431 192 569 431 199 569 minecraft:basalt
fill 431 192 589 431 199 590 minecraft:basalt
fill 431 192 598 437 192 598 minecraft:basalt
fill 433 192 559 438 192 559 minecraft:basalt
fill 433 192 568 433 201 568 minecraft:basalt
fill 433 192 590 433 201 590 minecraft:basalt
fill 434 192 567 435 201 567 minecraft:basalt
fill 434 192 591 434 199 592 minecraft:basalt
fill 435 192 566 435 200 566 minecraft:basalt
fill 435 192 591 435 201 591 minecraft:basalt
setblock 436 192 566 minecraft:magma_block
fill 437 192 558 441 192 558 minecraft:basalt
fill 437 192 566 443 192 566 minecraft:basalt
fill 437 192 592 438 201 592 minecraft:basalt
setblock 439 192 592 minecraft:magma_block
fill 440 192 557 440 229 557 minecraft:yellow_concrete
fill 440 192 592 440 199 593 minecraft:basalt
fill 441 192 592 443 199 592 minecraft:basalt
fill 441 192 599 442 199 599 minecraft:yellow_concrete
setblock 442 192 558 minecraft:magma_block
setblock 443 192 558 minecraft:basalt
fill 443 192 565 443 199 565 minecraft:basalt
fill 444 192 560 449 192 560 minecraft:basalt
fill 445 192 567 446 199 567 minecraft:basalt
fill 445 192 591 446 199 591 minecraft:basalt
fill 446 192 557 447 199 557 minecraft:yellow_concrete
setblock 447 192 559 minecraft:basalt
fill 447 192 562 452 192 562 minecraft:basalt
fill 447 192 568 447 201 568 minecraft:basalt
fill 447 192 590 447 201 590 minecraft:basalt
fill 447 192 598 447 193 598 minecraft:basalt
setblock 448 192 568 minecraft:magma_block
fill 448 192 595 454 192 595 minecraft:basalt
setblock 448 192 598 minecraft:magma_block
fill 449 192 569 449 199 569 minecraft:basalt
fill 449 192 589 449 199 590 minecraft:basalt
setblock 449 192 598 minecraft:basalt
setblock 450 192 561 minecraft:basalt
fill 450 192 564 455 192 564 minecraft:basalt
fill 450 192 570 450 200 570 minecraft:basalt
fill 450 192 588 450 200 588 minecraft:basalt
fill 450 192 594 455 192 594 minecraft:basalt
setblock 450 192 597 minecraft:basalt
setblock 450 192 599 minecraft:yellow_concrete
setblock 451 192 561 minecraft:magma_block
fill 451 192 567 457 192 567 minecraft:basalt
fill 451 192 572 451 201 572 minecraft:basalt
fill 451 192 586 452 199 586 minecraft:basalt
fill 451 192 590 457 192 591 minecraft:basalt
setblock 451 192 597 minecraft:magma_block
fill 452 192 573 452 201 574 minecraft:basalt
fill 452 192 584 452 201 585 minecraft:basalt
setblock 453 192 563 minecraft:basalt
fill 453 192 566 456 192 566 minecraft:basalt
fill 453 192 569 458 192 569 minecraft:basalt
fill 453 192 576 453 192 582 minecraft:basalt
fill 453 192 587 459 192 587 minecraft:basalt
fill 453 192 593 456 192 593 minecraft:basalt
setblock 454 192 563 minecraft:magma_block
fill 454 192 572 460 192 572 minecraft:basalt
fill 454 192 599 459 199 599 minecraft:yellow_concrete
setblock 456 192 565 minecraft:basalt
fill 456 192 568 458 192 568 minecraft:basalt
fill 456 192 571 459 192 571 minecraft:basalt
fill 456 192 580 461 192 580 minecraft:basalt
fill 456 192 589 458 192 589 minecraft:basalt
setblock 456 192 592 minecraft:basalt
fill 457 192 577 461 192 577 minecraft:basalt
setblock 458 192 590 minecraft:basalt
setblock 459 192 570 minecraft:basalt
fill 459 192 573 459 193 573 minecraft:basalt
fill 459 192 575 460 193 575 minecraft:basalt
fill 459 192 579 461 192 579 minecraft:basalt
fill 459 192 584 459 192 585 minecraft:basalt
setblock 459 192 588 minecraft:basalt
fill 460 192 557 462 199 557 minecraft:yellow_concrete
setblock 460 192 573 minecraft:magma_block
setblock 460 192 584 minecraft:basalt
setblock 460 192 585 minecraft:magma_block
setblock 460 192 599 minecraft:lime_concrete
fill 461 192 599 461 229 599 minecraft:yellow_concrete
setblock 463 192 557 minecraft:lime_concrete
fill 464 192 557 465 229 557 minecraft:yellow_concrete
fill 465 192 560 465 229 560 minecraft:yellow_concrete
fill 465 192 564 465 225 564 minecraft:yellow_concrete
fill 465 192 567 465 199 572 minecraft:yellow_concrete
setblock 465 192 573 minecraft:lime_concrete
fill 465 192 574 465 199 580 minecraft:yellow_concrete
fill 465 192 581 465 192 582 minecraft:lime_concrete
fill 465 192 583 465 230 583 minecraft:yellow_concrete
fill 465 192 587 465 192 591 minecraft:yellow_concrete
setblock 465 192 592 minecraft:lime_concrete
fill 465 192 593 465 192 597 minecraft:yellow_concrete
setblock 423 193 557 minecraft:lime_concrete
fill 423 193 558 423 229 558 minecraft:yellow_concrete
setblock 423 193 559 minecraft:lime_concrete
fill 423 193 560 423 199 565 minecraft:yellow_concrete
setblock 423 193 566 minecraft:lime_concrete
fill 423 193 567 423 199 571 minecraft:yellow_concrete
fill 423 193 572 423 193 574 minecraft:lime_concrete
fill 423 193 575 423 199 588 minecraft:yellow_concrete
setblock 423 193 589 minecraft:lime_concrete
fill 423 193 590 423 229 590 minecraft:yellow_concrete
setblock 423 193 591 minecraft:lime_concrete
fill 423 193 592 423 199 596 minecraft:yellow_concrete
setblock 423 193 597 minecraft:lime_concrete
fill 423 193 598 423 229 599 minecraft:yellow_concrete
fill 424 193 564 424 233 565 minecraft:white_concrete
fill 424 193 567 425 193 591 minecraft:basalt
fill 424 193 596 424 233 597 minecraft:white_concrete
fill 425 193 558 426 233 558 minecraft:white_concrete
setblock 425 193 566 minecraft:basalt
setblock 425 193 592 minecraft:basalt
setblock 426 193 565 minecraft:magma_block
fill 426 193 599 429 199 599 minecraft:yellow_concrete
fill 427 193 564 428 193 565 minecraft:basalt
fill 427 193 575 428 200 575 minecraft:basalt
fill 427 193 578 427 200 578 minecraft:basalt
fill 427 193 581 427 200 581 minecraft:basalt
fill 427 193 594 428 193 594 minecraft:basalt
fill 428 193 563 429 193 563 minecraft:basalt
fill 428 193 576 428 202 576 minecraft:basalt
fill 428 193 582 428 201 583 minecraft:basalt
setblock 428 193 595 minecraft:basalt
fill 429 193 557 437 199 557 minecraft:yellow_concrete
setblock 429 193 562 minecraft:basalt
setblock 429 193 573 minecraft:magma_block
setblock 429 193 585 minecraft:magma_block
fill 429 193 596 434 193 596 minecraft:basalt
fill 430 193 571 430 200 571 minecraft:basalt
fill 430 193 587 430 201 587 minecraft:basalt
fill 430 193 598 431 233 598 minecraft:white_concrete
setblock 430 193 599 minecraft:lime_concrete
fill 431 193 561 432 193 561 minecraft:basalt
fill 431 193 570 431 201 570 minecraft:basalt
fill 431 193 588 431 201 588 minecraft:basalt
fill 431 193 597 432 193 597 minecraft:basalt
fill 431 193 599 432 227 599 minecraft:yellow_concrete
setblock 432 193 569 minecraft:magma_block
fill 432 193 589 432 201 589 minecraft:basalt
fill 433 193 558 434 233 558 minecraft:white_concrete
fill 433 193 598 434 193 598 minecraft:basalt
fill 433 193 599 434 193 599 minecraft:lime_concrete
fill 434 193 568 434 202 568 minecraft:basalt
fill 434 193 590 434 202 590 minecraft:basalt
setblock 435 193 598 minecraft:magma_block
fill 435 193 599 439 225 599 minecraft:yellow_concrete
fill 436 193 559 443 193 559 minecraft:basalt
fill 436 193 566 437 200 567 minecraft:basalt
fill 436 193 591 437 201 591 minecraft:basalt
fill 436 193 598 437 194 598 minecraft:basalt
setblock 438 193 557 minecraft:lime_concrete
fill 438 193 566 440 201 566 minecraft:basalt
fill 439 193 557 439 229 557 minecraft:yellow_concrete
fill 439 193 592 439 200 592 minecraft:basalt
setblock 440 193 599 minecraft:lime_concrete
fill 441 193 558 442 233 558 minecraft:white_concrete
setblock 441 193 566 minecraft:magma_block
fill 442 193 566 443 201 566 minecraft:basalt
fill 443 193 567 444 193 567 minecraft:basalt
fill 443 193 591 444 193 591 minecraft:basalt
setblock 444 193 559 minecraft:magma_block
fill 444 193 560 447 193 560 minecraft:basalt
fill 445 193 596 449 194 596 minecraft:basalt
fill 446 193 568 446 202 568 minecraft:basalt
setblock 446 193 590 minecraft:basalt
fill 447 193 562 451 193 562 minecraft:basalt
fill 448 193 557 452 225 557 minecraft:yellow_concrete
fill 448 193 565 454 193 565 minecraft:basalt
fill 448 193 568 448 200 569 minecraft:basalt
fill 448 193 589 448 200 589 minecraft:basalt
fill 448 193 595 452 193 595 minecraft:basalt
fill 449 193 558 450 233 558 minecraft:white_concrete
fill 449 193 570 449 201 570 minecraft:basalt
fill 449 193 588 449 201 588 minecraft:basalt
fill 450 193 564 453 193 564 minecraft:basalt
fill 450 193 571 450 201 571 minecraft:basalt
setblock 450 193 587 minecraft:magma_block
fill 450 193 594 453 193 594 minecraft:basalt
setblock 450 193 596 minecraft:magma_block
setblock 450 193 599 minecraft:lime_concrete
fill 451 193 567 455 194 567 minecraft:basalt
fill 451 193 573 451 202 573 minecraft:basalt
fill 451 193 585 451 202 585 minecraft:basalt
fill 451 193 590 455 194 591 minecraft:basalt
setblock 451 193 596 minecraft:basalt
fill 452 193 575 452 193 576 minecraft:basalt
fill 452 193 582 452 193 583 minecraft:basalt
setblock 453 193 557 minecraft:lime_concrete
fill 453 193 566 455 193 566 minecraft:basalt
fill 453 193 569 457 193 569 minecraft:basalt
fill 453 193 576 453 201 576 minecraft:basalt
setblock 453 193 577 minecraft:magma_block
fill 453 193 578 453 201 579 minecraft:basalt
setblock 453 193 580 minecraft:magma_block
fill 453 193 581 453 201 582 minecraft:basalt
fill 453 193 587 458 193 587 minecraft:basalt
fill 453 193 593 454 193 593 minecraft:basalt
fill 454 193 557 459 199 557 minecraft:yellow_concrete
fill 454 193 572 458 194 572 minecraft:basalt
fill 454 193 598 455 233 598 minecraft:white_concrete
setblock 456 193 567 minecraft:magma_block
fill 456 193 568 457 193 568 minecraft:basalt
fill 456 193 571 458 193 571 minecraft:basalt
fill 456 193 574 459 193 574 minecraft:basalt
fill 456 193 580 460 193 580 minecraft:basalt
fill 456 193 586 459 193 586 minecraft:basalt
fill 456 193 589 457 193 590 minecraft:basalt
setblock 456 193 591 minecraft:magma_block
fill 457 193 558 458 233 558 minecraft:white_concrete
fill 457 193 577 460 193 577 minecraft:basalt
setblock 459 193 572 minecraft:magma_block
fill 459 193 576 460 193 576 minecraft:basalt
fill 459 193 578 460 193 579 minecraft:basalt
fill 459 193 581 460 193 582 minecraft:basalt
setblock 459 193 584 minecraft:magma_block
setblock 459 193 585 minecraft:basalt
fill 460 193 599 460 229 599 minecraft:yellow_concrete
fill 462 193 598 463 233 598 minecraft:white_concrete
fill 463 193 557 463 226 557 minecraft:yellow_concrete
fill 464 193 559 464 233 560 minecraft:white_concrete
fill 464 193 567 464 233 568 minecraft:white_concrete
fill 464 193 575 464 233 576 minecraft:white_concrete
fill 464 193 583 464 233 584 minecraft:white_concrete
fill 464 193 591 464 233 592 minecraft:white_concrete
fill 465 193 573 465 229 573 minecraft:yellow_concrete
fill 465 193 581 465 229 582 minecraft:yellow_concrete
fill 465 193 587 465 225 588 minecraft:yellow_concrete
setblock 465 193 589 minecraft:lime_concrete
fill 465 193 590 465 227 592 minecraft:yellow_concrete
setblock 465 193 593 minecraft:lime_concrete
fill 465 193 594 465 199 595 minecraft:yellow_concrete
setblock 465 193 596 minecraft:lime_concrete
fill 465 193 597 465 229 597 minecraft:yellow_concrete
fill 423 194 557 423 229 557 minecraft:yellow_concrete
fill 423 194 559 423 229 559 minecraft:yellow_concrete
fill 423 194 566 423 227 566 minecraft:yellow_concrete
fill 423 194 572 423 225 574 minecraft:yellow_concrete
fill 423 194 589 423 227 589 minecraft:yellow_concrete
fill 423 194 591 423 230 591 minecraft:yellow_concrete
fill 423 194 597 423 229 597 minecraft:yellow_concrete
fill 424 194 568 425 194 590 minecraft:basalt
setblock 425 194 567 minecraft:magma_block
setblock 425 194 591 minecraft:magma_block
fill 427 194 565 428 194 565 minecraft:basalt
setblock 428 194 564 minecraft:basalt
fill 428 194 577 428 202 577 minecraft:basalt
setblock 428 194 578 minecraft:magma_block
fill 428 194 579 428 202 580 minecraft:basalt
setblock 428 194 581 minecraft:magma_block
setblock 428 194 594 minecraft:basalt
setblock 429 194 563 minecraft:basalt
fill 429 194 573 429 201 575 minecraft:basalt
fill 429 194 583 429 201 585 minecraft:basalt
fill 430 194 572 430 202 572 minecraft:basalt
fill 430 194 586 430 202 586 minecraft:basalt
fill 430 194 599 430 229 599 minecraft:yellow_concrete
setblock 431 194 562 minecraft:magma_block
setblock 431 194 571 minecraft:magma_block
fill 431 194 587 431 202 587 minecraft:basalt
fill 431 194 596 434 194 596 minecraft:basalt
fill 432 194 562 437 194 562 minecraft:basalt
fill 432 194 569 432 201 570 minecraft:basalt
fill 432 194 588 432 202 588 minecraft:basalt
setblock 433 194 561 minecraft:basalt
fill 433 194 569 433 202 569 minecraft:basalt
fill 433 194 589 433 202 589 minecraft:basalt
setblock 433 194 597 minecraft:basalt
fill 433 194 599 434 199 599 minecraft:yellow_concrete
setblock 434 194 561 minecraft:magma_block
setblock 434 194 597 minecraft:magma_block
fill 435 194 561 440 194 561 minecraft:basalt
fill 435 194 568 436 194 568 minecraft:basalt
fill 435 194 590 436 202 590 minecraft:basalt
fill 435 194 597 440 194 597 minecraft:basalt
setblock 436 194 560 minecraft:basalt
setblock 437 194 560 minecraft:magma_block
fill 438 194 557 438 199 557 minecraft:yellow_concrete
fill 438 194 560 444 194 560 minecraft:basalt
fill 438 194 567 442 194 567 minecraft:basalt
fill 438 194 591 442 194 591 minecraft:basalt
setblock 439 194 598 minecraft:basalt
setblock 440 194 598 minecraft:magma_block
fill 440 194 599 440 229 599 minecraft:yellow_concrete
fill 441 194 566 441 201 566 minecraft:basalt
fill 441 194 598 444 194 598 minecraft:basalt
fill 442 194 561 447 194 561 minecraft:basalt
fill 442 194 597 447 194 597 minecraft:basalt
setblock 443 194 567 minecraft:magma_block
setblock 443 194 591 minecraft:magma_block
fill 444 194 567 444 201 568 minecraft:basalt
fill 444 194 590 444 201 591 minecraft:basalt
fill 445 194 563 451 194 563 minecraft:basalt
fill 445 194 568 445 202 568 minecraft:basalt
fill 445 194 590 445 202 590 minecraft:basalt
setblock 446 194 590 minecraft:magma_block
fill 446 194 598 447 233 598 minecraft:white_concrete
fill 447 194 562 448 194 562 minecraft:basalt
fill 447 194 569 447 202 569 minecraft:basalt
fill 447 194 589 447 202 589 minecraft:basalt
fill 448 194 565 453 194 565 minecraft:basalt
fill 448 194 570 448 202 570 minecraft:basalt
fill 448 194 588 448 202 588 minecraft:basalt
fill 448 194 595 451 194 595 minecraft:basalt
setblock 449 194 562 minecraft:magma_block
setblock 449 194 571 minecraft:magma_block
fill 449 194 587 450 201 587 minecraft:basalt
fill 450 194 564 451 195 564 minecraft:basalt
fill 450 194 572 450 201 572 minecraft:basalt
fill 450 194 586 450 202 586 minecraft:basalt
fill 450 194 592 454 194 592 minecraft:basalt
fill 450 194 594 451 195 594 minecraft:basalt
fill 450 194 599 450 199 599 minecraft:yellow_concrete
fill 451 194 574 451 194 575 minecraft:basalt
fill 451 194 583 451 202 584 minecraft:basalt
setblock 452 194 564 minecraft:magma_block
fill 452 194 575 452 201 575 minecraft:basalt
setblock 452 194 576 minecraft:magma_block
fill 452 194 577 452 202 578 minecraft:basalt
setblock 452 194 579 minecraft:magma_block
fill 452 194 580 452 202 581 minecraft:basalt
setblock 452 194 582 minecraft:magma_block
fill 452 194 583 452 201 583 minecraft:basalt
setblock 452 194 594 minecraft:magma_block
fill 453 194 557 453 229 557 minecraft:yellow_concrete
fill 453 194 566 454 194 566 minecraft:basalt
fill 453 194 569 456 194 570 minecraft:basalt
fill 453 194 577 453 201 577 minecraft:basalt
fill 453 194 580 453 201 580 minecraft:basalt
fill 453 194 587 457 194 587 minecraft:basalt
setblock 453 194 593 minecraft:basalt
setblock 456 194 568 minecraft:basalt
fill 456 194 571 457 194 571 minecraft:basalt
fill 456 194 574 457 196 574 minecraft:basalt
fill 456 194 580 459 194 580 minecraft:basalt
fill 456 194 583 459 194 583 minecraft:basalt
fill 456 194 586 457 195 586 minecraft:basalt
fill 456 194 588 456 194 590 minecraft:basalt
setblock 457 194 570 minecraft:basalt
fill 457 194 577 459 194 577 minecraft:basalt
setblock 457 194 588 minecraft:basalt
setblock 458 194 574 minecraft:magma_block
setblock 458 194 586 minecraft:magma_block
fill 459 194 575 459 194 576 minecraft:basalt
fill 459 194 578 459 194 579 minecraft:basalt
fill 459 194 581 459 194 582 minecraft:basalt
fill 465 194 589 465 229 589 minecraft:yellow_concrete
fill 465 194 593 465 229 593 minecraft:yellow_concrete
fill 465 194 596 465 229 596 minecraft:yellow_concrete
fill 424 195 570 425 195 586 minecraft:basalt
setblock 424 195 587 minecraft:magma_block
fill 424 195 588 425 195 588 minecraft:basalt
fill 424 195 589 424 233 589 minecraft:white_concrete
fill 425 195 568 425 195 569 minecraft:basalt
fill 425 195 587 425 196 587 minecraft:basalt
fill 425 195 589 425 195 590 minecraft:basalt
fill 426 195 591 428 195 591 minecraft:basalt
setblock 427 195 592 minecraft:magma_block
setblock 428 195 565 minecraft:basalt
fill 428 195 578 428 202 578 minecraft:basalt
fill 428 195 581 429 195 581 minecraft:basalt
fill 428 195 592 428 195 593 minecraft:basalt
setblock 429 195 564 minecraft:basalt
fill 429 195 576 429 203 577 minecraft:basalt
fill 429 195 582 429 203 582 minecraft:basalt
fill 429 195 593 429 195 594 minecraft:basalt
setblock 430 195 564 minecraft:magma_block
setblock 430 195 573 minecraft:magma_block
fill 430 195 574 430 203 574 minecraft:basalt
fill 430 195 584 430 203 584 minecraft:basalt
setblock 430 195 585 minecraft:magma_block
fill 430 195 593 434 196 593 minecraft:basalt
setblock 430 195 594 minecraft:magma_block
fill 431 195 563 431 195 564 minecraft:basalt
fill 431 195 571 431 202 572 minecraft:basalt
fill 431 195 586 431 202 586 minecraft:basalt
fill 431 195 594 431 195 595 minecraft:basalt
fill 432 195 563 434 195 563 minecraft:basalt
fill 432 195 571 432 203 571 minecraft:basalt
fill 432 195 587 432 203 587 minecraft:basalt
fill 432 195 595 437 195 595 minecraft:basalt
fill 433 195 562 437 195 562 minecraft:basalt
fill 433 195 570 433 203 570 minecraft:basalt
fill 433 195 588 433 203 588 minecraft:basalt
setblock 433 195 596 minecraft:magma_block
fill 434 195 569 435 203 569 minecraft:basalt
fill 434 195 589 435 203 589 minecraft:basalt
setblock 434 195 596 minecraft:basalt
fill 435 195 561 438 195 561 minecraft:basalt
fill 435 195 568 435 201 568 minecraft:basalt
fill 435 195 597 438 195 597 minecraft:basalt
setblock 436 195 568 minecraft:magma_block
fill 437 195 568 438 203 568 minecraft:basalt
fill 437 195 590 438 195 590 minecraft:basalt
fill 438 195 567 438 201 567 minecraft:basalt
fill 438 195 591 438 201 591 minecraft:basalt
fill 438 195 598 439 233 598 minecraft:white_concrete
setblock 439 195 561 minecraft:magma_block
setblock 439 195 567 minecraft:magma_block
setblock 439 195 591 minecraft:magma_block
setblock 439 195 597 minecraft:magma_block
setblock 440 195 561 minecraft:basalt
fill 440 195 567 443 202 567 minecraft:basalt
fill 440 195 591 443 202 591 minecraft:basalt
setblock 440 195 597 minecraft:basalt
fill 442 195 561 445 195 561 minecraft:basalt
fill 442 195 568 443 203 568 minecraft:basalt
setblock 442 195 590 minecraft:magma_block
fill 442 195 597 445 195 597 minecraft:basalt
fill 443 195 590 443 203 590 minecraft:basalt
fill 445 195 563 449 195 563 minecraft:basalt
fill 445 195 569 446 202 569 minecraft:basalt
setblock 445 195 589 minecraft:magma_block
fill 445 195 596 447 195 596 minecraft:basalt
fill 446 195 589 446 202 590 minecraft:basalt
setblock 447 195 562 minecraft:basalt
fill 447 195 570 447 203 570 minecraft:basalt
fill 447 195 588 447 203 588 minecraft:basalt
fill 448 195 565 452 195 565 minecraft:basalt
fill 448 195 571 449 202 571 minecraft:basalt
fill 448 195 587 448 203 587 minecraft:basalt
fill 448 195 595 449 195 595 minecraft:basalt
fill 449 195 572 449 203 572 minecraft:basalt
fill 449 195 586 449 202 586 minecraft:basalt
fill 450 195 573 450 195 574 minecraft:basalt
fill 450 195 584 450 203 585 minecraft:basalt
fill 450 195 592 453 195 592 minecraft:basalt
fill 451 195 567 454 195 567 minecraft:basalt
fill 451 195 574 451 202 574 minecraft:basalt
setblock 451 195 575 minecraft:magma_block
fill 451 195 576 451 203 577 minecraft:basalt
setblock 451 195 581 minecraft:magma_block
fill 451 195 582 452 202 582 minecraft:basalt
fill 451 195 590 454 195 591 minecraft:basalt
fill 452 195 576 452 202 576 minecraft:basalt
fill 452 195 579 452 202 579 minecraft:basalt
setblock 453 195 566 minecraft:basalt
fill 453 195 569 455 195 570 minecraft:basalt
fill 453 195 573 456 196 573 minecraft:basalt
fill 453 195 587 456 195 587 minecraft:basalt
fill 454 195 572 457 195 572 minecraft:basalt
setblock 455 195 590 minecraft:basalt
fill 456 195 570 456 195 571 minecraft:basalt
fill 456 195 580 458 195 580 minecraft:basalt
fill 456 195 583 456 196 585 minecraft:basalt
setblock 456 195 588 minecraft:basalt
setblock 457 195 573 minecraft:magma_block
fill 457 195 577 458 195 577 minecraft:basalt
fill 457 195 583 458 195 584 minecraft:basalt
setblock 457 195 585 minecraft:magma_block
setblock 458 195 574 minecraft:basalt
fill 424 196 558 424 197 563 minecraft:white_concrete
fill 424 196 566 424 197 571 minecraft:white_concrete
fill 424 196 572 425 196 586 minecraft:basalt
fill 424 196 587 424 197 588 minecraft:white_concrete
fill 424 196 590 425 196 595 minecraft:white_concrete
fill 424 196 598 429 197 598 minecraft:white_concrete
fill 425 196 559 425 196 569 minecraft:white_concrete
fill 425 196 570 425 196 571 minecraft:basalt
setblock 425 196 588 minecraft:basalt
setblock 425 196 589 minecraft:white_concrete
fill 425 196 596 425 196 597 minecraft:white_concrete
fill 426 196 559 463 196 559 minecraft:white_concrete
setblock 426 196 560 minecraft:light[level=14]
fill 426 196 568 428 196 568 minecraft:basalt
setblock 426 196 592 minecraft:light[level=14]
fill 426 196 597 464 196 597 minecraft:white_concrete
fill 427 196 558 432 197 558 minecraft:white_concrete
fill 427 196 567 428 196 567 minecraft:basalt
fill 427 196 591 428 196 591 minecraft:basalt
setblock 428 196 566 minecraft:basalt
fill 428 196 581 428 202 581 minecraft:basalt
setblock 428 196 592 minecraft:basalt
setblock 429 196 566 minecraft:magma_block
setblock 429 196 578 minecraft:magma_block
fill 429 196 579 429 203 580 minecraft:basalt
setblock 429 196 581 minecraft:magma_block
setblock 429 196 593 minecraft:magma_block
fill 430 196 566 434 197 566 minecraft:basalt
fill 430 196 573 431 203 573 minecraft:basalt
fill 430 196 575 430 203 576 minecraft:basalt
fill 430 196 582 430 203 583 minecraft:basalt
fill 430 196 585 431 203 585 minecraft:basalt
setblock 431 196 564 minecraft:basalt
setblock 431 196 594 minecraft:basalt
fill 432 196 572 432 204 572 minecraft:basalt
setblock 432 196 586 minecraft:magma_block
fill 432 196 598 437 197 598 minecraft:white_concrete
fill 433 196 563 434 196 563 minecraft:basalt
fill 433 196 571 433 204 571 minecraft:basalt
fill 433 196 587 433 203 587 minecraft:basalt
fill 433 196 595 437 196 595 minecraft:basalt
setblock 434 196 560 minecraft:light[level=14]
fill 434 196 570 434 202 570 minecraft:basalt
setblock 434 196 576 minecraft:light[level=14]
setblock 434 196 584 minecraft:light[level=14]
fill 434 196 588 434 202 588 minecraft:basalt
fill 435 196 558 440 197 558 minecraft:white_concrete
fill 435 196 562 437 196 562 minecraft:basalt
fill 436 196 568 436 202 569 minecraft:basalt
fill 436 196 589 437 196 589 minecraft:basalt
fill 436 196 596 437 196 596 minecraft:basalt
fill 437 196 569 437 204 569 minecraft:basalt
fill 437 196 590 437 202 590 minecraft:basalt
setblock 438 196 590 minecraft:magma_block
setblock 438 196 596 minecraft:magma_block
fill 439 196 562 440 196 562 minecraft:basalt
fill 439 196 567 439 202 568 minecraft:basalt
fill 439 196 590 439 202 591 minecraft:basalt
fill 439 196 596 443 196 596 minecraft:basalt
fill 440 196 568 440 202 568 minecraft:basalt
fill 440 196 590 442 203 590 minecraft:basalt
fill 440 196 598 445 197 598 minecraft:white_concrete
setblock 441 196 562 minecraft:magma_block
setblock 441 196 568 minecraft:magma_block
setblock 442 196 560 minecraft:light[level=14]
fill 442 196 562 445 196 562 minecraft:basalt
setblock 442 196 576 minecraft:light[level=14]
setblock 442 196 584 minecraft:light[level=14]
fill 443 196 558 448 197 558 minecraft:white_concrete
fill 443 196 569 444 196 569 minecraft:basalt
fill 443 196 589 445 203 589 minecraft:basalt
fill 445 196 563 446 196 563 minecraft:basalt
fill 445 196 593 451 196 593 minecraft:basalt
setblock 445 196 596 minecraft:basalt
fill 446 196 570 446 203 570 minecraft:basalt
fill 446 196 588 446 203 588 minecraft:basalt
setblock 447 196 563 minecraft:magma_block
fill 447 196 571 447 204 571 minecraft:basalt
setblock 447 196 587 minecraft:magma_block
fill 448 196 565 449 197 565 minecraft:basalt
fill 448 196 572 448 204 572 minecraft:basalt
fill 448 196 586 448 204 586 minecraft:basalt
fill 448 196 598 453 197 598 minecraft:white_concrete
fill 449 196 568 454 196 568 minecraft:basalt
fill 449 196 573 450 203 573 minecraft:basalt
fill 449 196 585 449 203 585 minecraft:basalt
setblock 450 196 560 minecraft:light[level=14]
setblock 450 196 565 minecraft:magma_block
setblock 450 196 574 minecraft:magma_block
fill 450 196 575 450 204 576 minecraft:basalt
fill 450 196 582 450 204 582 minecraft:basalt
setblock 450 196 583 minecraft:magma_block
fill 450 196 592 452 196 592 minecraft:basalt
fill 451 196 558 456 197 558 minecraft:white_concrete
setblock 451 196 565 minecraft:basalt
fill 451 196 567 452 196 567 minecraft:basalt
fill 451 196 575 451 202 575 minecraft:basalt
fill 451 196 578 451 203 581 minecraft:basalt
fill 451 196 588 452 196 591 minecraft:basalt
setblock 453 196 567 minecraft:magma_block
fill 453 196 569 454 196 570 minecraft:basalt
fill 453 196 587 454 196 590 minecraft:basalt
setblock 453 196 591 minecraft:magma_block
fill 454 196 572 455 197 572 minecraft:basalt
setblock 455 196 570 minecraft:basalt
fill 455 196 587 455 196 588 minecraft:basalt
setblock 456 196 572 minecraft:magma_block
fill 456 196 575 457 196 576 minecraft:basalt
fill 456 196 578 457 196 582 minecraft:basalt
setblock 456 196 586 minecraft:basalt
fill 456 196 598 461 197 598 minecraft:white_concrete
setblock 457 196 577 minecraft:basalt
fill 457 196 583 457 196 584 minecraft:basalt
setblock 458 196 560 minecraft:light[level=14]
setblock 458 196 568 minecraft:light[level=14]
setblock 458 196 576 minecraft:light[level=14]
setblock 458 196 584 minecraft:light[level=14]
setblock 458 196 592 minecraft:light[level=14]
fill 459 196 558 464 197 558 minecraft:white_concrete
fill 463 196 560 463 196 596 minecraft:white_concrete
fill 464 196 561 464 197 566 minecraft:white_concrete
fill 464 196 569 464 197 574 minecraft:white_concrete
fill 464 196 577 464 197 582 minecraft:white_concrete
fill 464 196 585 464 197 590 minecraft:white_concrete
fill 464 196 593 464 197 596 minecraft:white_concrete
fill 464 196 598 464 197 598 minecraft:white_concrete
fill 424 197 572 424 233 573 minecraft:white_concrete
fill 424 197 574 425 197 584 minecraft:basalt
fill 424 197 585 424 197 586 minecraft:white_concrete
fill 424 197 590 424 197 595 minecraft:white_concrete
setblock 425 197 572 minecraft:magma_block
setblock 425 197 573 minecraft:basalt
fill 425 197 585 425 197 586 minecraft:basalt
fill 426 197 588 428 197 588 minecraft:basalt
fill 427 197 589 428 197 589 minecraft:basalt
setblock 428 197 568 minecraft:magma_block
fill 428 197 590 430 197 590 minecraft:basalt
fill 429 197 578 430 197 578 minecraft:basalt
fill 429 197 581 430 203 581 minecraft:basalt
fill 430 197 577 430 204 577 minecraft:basalt
fill 430 197 579 430 203 580 minecraft:basalt
fill 430 197 592 433 197 592 minecraft:basalt
fill 431 197 565 437 197 565 minecraft:basalt
fill 431 197 574 431 204 575 minecraft:basalt
fill 431 197 583 431 204 584 minecraft:basalt
fill 431 197 593 434 197 593 minecraft:basalt
fill 432 197 573 432 204 573 minecraft:basalt
fill 432 197 585 432 204 586 minecraft:basalt
fill 433 197 572 433 205 572 minecraft:basalt
fill 433 197 586 433 205 586 minecraft:basalt
fill 434 197 571 434 204 571 minecraft:basalt
setblock 434 197 587 minecraft:magma_block
fill 435 197 570 436 197 570 minecraft:basalt
fill 435 197 588 436 197 588 minecraft:basalt
fill 435 197 595 436 197 595 minecraft:basalt
fill 436 197 563 442 197 563 minecraft:basalt
fill 436 197 589 436 203 589 minecraft:basalt
setblock 437 197 589 minecraft:magma_block
setblock 437 197 595 minecraft:magma_block
fill 438 197 569 442 197 569 minecraft:basalt
fill 438 197 589 438 203 590 minecraft:basalt
fill 439 197 589 442 204 589 minecraft:basalt
fill 439 197 595 445 197 595 minecraft:basalt
fill 441 197 568 441 203 568 minecraft:basalt
fill 442 197 564 447 197 564 minecraft:basalt
fill 442 197 594 447 197 594 minecraft:basalt
setblock 443 197 563 minecraft:magma_block
setblock 443 197 569 minecraft:magma_block
fill 444 197 569 444 204 570 minecraft:basalt
fill 444 197 588 445 204 588 minecraft:basalt
setblock 445 197 563 minecraft:basalt
fill 445 197 570 445 204 570 minecraft:basalt
fill 445 197 593 449 197 593 minecraft:basalt
fill 445 197 597 446 198 597 minecraft:lime_concrete
fill 446 197 566 450 197 566 minecraft:basalt
setblock 446 197 571 minecraft:magma_block
fill 446 197 587 447 204 587 minecraft:basalt
fill 447 197 572 447 204 572 minecraft:basalt
fill 447 197 586 447 205 586 minecraft:basalt
fill 448 197 573 448 203 573 minecraft:basalt
fill 448 197 585 448 203 585 minecraft:basalt
fill 449 197 568 452 197 568 minecraft:basalt
fill 449 197 574 449 204 575 minecraft:basalt
fill 449 197 583 449 204 584 minecraft:basalt
fill 450 197 574 450 203 574 minecraft:basalt
fill 450 197 577 450 204 581 minecraft:basalt
fill 450 197 583 450 204 583 minecraft:basalt
setblock 450 197 592 minecraft:basalt
setblock 451 197 567 minecraft:basalt
fill 451 197 588 451 197 591 minecraft:basalt
fill 452 197 571 454 197 571 minecraft:basalt
fill 452 197 588 453 197 589 minecraft:basalt
setblock 452 197 590 minecraft:magma_block
fill 453 197 569 453 197 570 minecraft:basalt
fill 453 197 573 455 197 573 minecraft:basalt
fill 453 197 585 454 197 587 minecraft:basalt
setblock 454 197 570 minecraft:basalt
setblock 454 197 588 minecraft:basalt
setblock 455 197 585 minecraft:basalt
setblock 455 197 586 minecraft:magma_block
fill 456 197 574 456 197 576 minecraft:basalt
fill 456 197 578 456 197 584 minecraft:basalt
setblock 464 197 597 minecraft:white_concrete
fill 424 198 578 425 198 579 minecraft:basalt
setblock 424 198 580 minecraft:magma_block
fill 424 198 581 424 233 581 minecraft:white_concrete
fill 424 198 588 424 233 588 minecraft:white_concrete
fill 425 198 574 425 198 577 minecraft:basalt
fill 425 198 580 425 198 584 minecraft:basalt
setblock 427 198 570 minecraft:magma_block
fill 427 198 571 428 198 571 minecraft:basalt
setblock 427 198 588 minecraft:magma_block
fill 428 198 569 428 198 570 minecraft:basalt
fill 428 198 588 428 198 589 minecraft:basalt
fill 429 198 569 429 199 569 minecraft:basalt
fill 429 198 578 429 203 578 minecraft:basalt
fill 429 198 590 430 198 590 minecraft:basalt
fill 430 198 567 431 198 567 minecraft:basalt
setblock 430 198 578 minecraft:magma_block
fill 430 198 591 431 198 591 minecraft:basalt
fill 431 198 566 434 198 566 minecraft:basalt
fill 431 198 576 431 205 577 minecraft:basalt
fill 431 198 581 431 205 582 minecraft:basalt
fill 431 198 592 433 198 592 minecraft:basalt
fill 432 198 574 432 204 574 minecraft:basalt
fill 432 198 584 432 205 584 minecraft:basalt
setblock 433 198 565 minecraft:magma_block
fill 433 198 573 433 205 573 minecraft:basalt
fill 433 198 585 433 205 585 minecraft:basalt
fill 433 198 593 434 198 593 minecraft:basalt
fill 434 198 565 437 198 565 minecraft:basalt
fill 434 198 572 434 205 572 minecraft:basalt
fill 434 198 586 434 204 587 minecraft:basalt
setblock 435 198 564 minecraft:basalt
fill 435 198 570 435 204 571 minecraft:basalt
fill 435 198 587 435 204 588 minecraft:basalt
setblock 435 198 594 minecraft:basalt
setblock 436 198 564 minecraft:magma_block
setblock 436 198 570 minecraft:magma_block
setblock 436 198 588 minecraft:magma_block
setblock 436 198 594 minecraft:magma_block
fill 437 198 564 440 198 564 minecraft:basalt
fill 437 198 570 438 205 570 minecraft:basalt
fill 437 198 588 437 204 589 minecraft:basalt
fill 437 198 594 440 198 594 minecraft:basalt
fill 438 198 569 438 204 569 minecraft:basalt
fill 438 198 588 438 205 588 minecraft:basalt
setblock 439 198 563 minecraft:magma_block
setblock 439 198 569 minecraft:magma_block
fill 439 198 595 441 198 595 minecraft:basalt
fill 440 198 563 441 198 563 minecraft:basalt
fill 440 198 569 443 203 569 minecraft:basalt
fill 442 198 564 444 198 564 minecraft:basalt
fill 442 198 570 443 205 570 minecraft:basalt
fill 442 198 588 443 205 588 minecraft:basalt
fill 442 198 594 444 198 594 minecraft:basalt
setblock 445 198 564 minecraft:magma_block
fill 445 198 571 446 204 571 minecraft:basalt
fill 445 198 587 445 205 587 minecraft:basalt
fill 445 198 593 447 198 593 minecraft:basalt
setblock 445 198 594 minecraft:magma_block
fill 446 198 566 447 199 566 minecraft:basalt
fill 446 198 572 446 205 572 minecraft:basalt
fill 446 198 586 446 205 586 minecraft:basalt
fill 447 198 573 447 205 573 minecraft:basalt
fill 447 198 585 447 205 585 minecraft:basalt
setblock 448 198 566 minecraft:magma_block
fill 448 198 574 448 205 574 minecraft:basalt
setblock 448 198 584 minecraft:magma_block
setblock 449 198 566 minecraft:basalt
fill 449 198 568 450 199 568 minecraft:basalt
fill 449 198 576 449 205 577 minecraft:basalt
fill 449 198 581 449 205 582 minecraft:basalt
setblock 451 198 568 minecraft:magma_block
fill 451 198 588 451 198 590 minecraft:basalt
fill 452 198 571 453 198 571 minecraft:basalt
fill 452 198 588 452 198 589 minecraft:basalt
setblock 453 198 570 minecraft:basalt
fill 453 198 573 453 199 573 minecraft:basalt
fill 453 198 585 453 198 588 minecraft:basalt
setblock 454 198 572 minecraft:basalt
setblock 454 198 573 minecraft:magma_block
setblock 454 198 585 minecraft:magma_block
setblock 454 198 586 minecraft:basalt
fill 456 198 578 456 198 580 minecraft:basalt
fill 424 199 580 424 233 580 minecraft:white_concrete
fill 425 199 577 425 199 581 minecraft:basalt
setblock 426 199 574 minecraft:basalt
setblock 426 199 575 minecraft:magma_block
setblock 426 199 584 minecraft:magma_block
fill 427 199 584 427 199 586 minecraft:basalt
fill 428 199 570 428 199 571 minecraft:basalt
fill 428 199 587 428 199 588 minecraft:basalt
setblock 429 199 589 minecraft:magma_block
fill 430 199 578 431 204 578 minecraft:basalt
fill 430 199 589 430 199 590 minecraft:basalt
setblock 431 199 567 minecraft:basalt
fill 431 199 579 431 205 580 minecraft:basalt
setblock 431 199 591 minecraft:basalt
setblock 432 199 567 minecraft:magma_block
fill 432 199 568 432 200 568 minecraft:basalt
fill 432 199 575 432 205 575 minecraft:basalt
fill 432 199 580 433 199 581 minecraft:light_blue_concrete
fill 432 199 583 432 204 583 minecraft:basalt
fill 432 199 590 432 200 590 minecraft:basalt
setblock 432 199 591 minecraft:magma_block
fill 433 199 566 434 199 566 minecraft:basalt
fill 433 199 574 433 205 574 minecraft:basalt
fill 433 199 584 433 205 584 minecraft:basalt
setblock 433 199 592 minecraft:basalt
fill 435 199 565 437 199 565 minecraft:basalt
setblock 435 199 572 minecraft:magma_block
fill 435 199 586 435 205 586 minecraft:basalt
fill 435 199 592 435 200 592 minecraft:basalt
setblock 435 199 593 minecraft:magma_block
fill 436 199 570 436 205 571 minecraft:basalt
fill 436 199 587 436 205 588 minecraft:basalt
fill 438 199 564 440 199 564 minecraft:basalt
fill 438 199 594 440 199 594 minecraft:basalt
fill 439 199 569 439 204 570 minecraft:basalt
fill 439 199 588 440 205 588 minecraft:basalt
fill 440 199 570 440 205 570 minecraft:basalt
setblock 441 199 564 minecraft:magma_block
setblock 441 199 570 minecraft:magma_block
setblock 441 199 588 minecraft:magma_block
fill 441 199 593 441 200 593 minecraft:basalt
setblock 441 199 594 minecraft:magma_block
setblock 442 199 564 minecraft:basalt
setblock 442 199 594 minecraft:basalt
fill 444 199 571 444 205 571 minecraft:basalt
setblock 444 199 587 minecraft:magma_block
fill 444 199 592 444 200 592 minecraft:basalt
setblock 444 199 593 minecraft:magma_block
fill 445 199 572 445 205 572 minecraft:basalt
fill 445 199 586 445 205 586 minecraft:basalt
setblock 445 199 593 minecraft:basalt
setblock 447 199 574 minecraft:magma_block
fill 447 199 584 448 204 584 minecraft:basalt
fill 447 199 591 449 199 591 minecraft:basalt
setblock 447 199 592 minecraft:magma_block
fill 448 199 575 448 205 575 minecraft:basalt
fill 448 199 583 448 205 583 minecraft:basalt
fill 449 199 578 449 205 580 minecraft:basalt
fill 450 199 589 450 199 590 minecraft:basalt
fill 451 199 569 451 199 570 minecraft:basalt
fill 451 199 588 451 199 589 minecraft:basalt
fill 452 199 570 452 199 572 minecraft:basalt
setblock 452 199 588 minecraft:basalt
setblock 453 199 572 minecraft:magma_block
fill 453 199 585 453 199 586 minecraft:basalt
fill 454 199 574 454 199 576 minecraft:basalt
fill 454 199 582 454 199 584 minecraft:basalt
fill 423 200 560 423 229 561 minecraft:yellow_concrete
fill 423 200 562 423 205 562 minecraft:sea_lantern
fill 423 200 563 423 229 565 minecraft:yellow_concrete
fill 423 200 567 423 226 569 minecraft:yellow_concrete
fill 423 200 570 423 205 570 minecraft:sea_lantern
fill 423 200 571 423 227 571 minecraft:yellow_concrete
fill 423 200 575 423 226 577 minecraft:yellow_concrete
fill 423 200 578 423 205 578 minecraft:sea_lantern
fill 423 200 579 423 226 585 minecraft:yellow_concrete
fill 423 200 586 423 205 586 minecraft:sea_lantern
fill 423 200 587 423 229 588 minecraft:yellow_concrete
fill 423 200 592 423 225 593 minecraft:yellow_concrete
fill 423 200 594 423 205 594 minecraft:sea_lantern
fill 423 200 595 423 225 596 minecraft:yellow_concrete
fill 426 200 599 426 205 599 minecraft:sea_lantern
fill 427 200 584 428 200 584 minecraft:basalt
fill 427 200 599 429 226 599 minecraft:yellow_concrete
setblock 428 200 573 minecraft:magma_block
fill 428 200 574 428 201 574 minecraft:basalt
setblock 428 200 585 minecraft:magma_block
fill 429 200 557 429 227 557 minecraft:yellow_concrete
fill 430 200 557 430 205 557 minecraft:sea_lantern
fill 430 200 589 431 200 589 minecraft:basalt
fill 431 200 557 437 229 557 minecraft:yellow_concrete
setblock 431 200 568 minecraft:basalt
setblock 431 200 569 minecraft:magma_block
setblock 431 200 590 minecraft:magma_block
fill 432 200 576 432 204 582 minecraft:basalt
fill 433 200 575 433 205 575 minecraft:basalt
fill 433 200 580 433 200 581 minecraft:light_blue_concrete
fill 433 200 583 433 205 583 minecraft:basalt
fill 433 200 599 433 225 599 minecraft:yellow_concrete
fill 434 200 573 434 205 573 minecraft:basalt
fill 434 200 585 434 205 585 minecraft:basalt
fill 434 200 591 434 201 591 minecraft:basalt
fill 434 200 599 434 205 599 minecraft:sea_lantern
fill 435 200 572 436 200 572 minecraft:basalt
fill 436 200 586 436 205 586 minecraft:basalt
fill 437 200 571 442 200 571 minecraft:basalt
fill 437 200 587 439 204 587 minecraft:basalt
fill 438 200 557 438 205 557 minecraft:sea_lantern
setblock 440 200 587 minecraft:magma_block
fill 440 200 592 442 201 592 minecraft:basalt
setblock 440 200 593 minecraft:magma_block
fill 441 200 570 441 205 570 minecraft:basalt
fill 441 200 587 441 205 588 minecraft:basalt
fill 441 200 599 441 229 599 minecraft:yellow_concrete
fill 442 200 587 444 205 587 minecraft:basalt
fill 442 200 599 442 205 599 minecraft:sea_lantern
setblock 443 200 571 minecraft:magma_block
setblock 443 200 592 minecraft:magma_block
fill 444 200 566 445 200 566 minecraft:basalt
fill 444 200 572 444 205 572 minecraft:basalt
fill 444 200 586 444 205 586 minecraft:basalt
fill 445 200 567 445 201 567 minecraft:basalt
fill 445 200 591 445 201 591 minecraft:basalt
fill 446 200 557 446 205 557 minecraft:sea_lantern
setblock 446 200 567 minecraft:magma_block
setblock 446 200 573 minecraft:magma_block
setblock 446 200 585 minecraft:magma_block
setblock 446 200 591 minecraft:magma_block
fill 447 200 557 447 229 557 minecraft:yellow_concrete
fill 447 200 574 447 204 575 minecraft:basalt
fill 447 200 583 447 205 583 minecraft:basalt
setblock 447 200 591 minecraft:basalt
fill 447 200 596 447 201 596 minecraft:light_blue_concrete
fill 448 200 576 448 200 582 minecraft:basalt
setblock 449 200 568 minecraft:basalt
setblock 449 200 569 minecraft:magma_block
fill 449 200 589 450 200 589 minecraft:basalt
setblock 449 200 590 minecraft:magma_block
fill 450 200 599 450 205 599 minecraft:sea_lantern
setblock 451 200 570 minecraft:basalt
fill 451 200 586 451 201 586 minecraft:basalt
setblock 451 200 588 minecraft:basalt
setblock 452 200 572 minecraft:basalt
setblock 452 200 586 minecraft:magma_block
fill 454 200 557 454 205 557 minecraft:sea_lantern
fill 454 200 599 457 225 599 minecraft:yellow_concrete
fill 455 200 557 461 225 557 minecraft:yellow_concrete
fill 458 200 599 458 205 599 minecraft:sea_lantern
fill 459 200 599 459 226 599 minecraft:yellow_concrete
fill 462 200 557 462 205 557 minecraft:sea_lantern
fill 465 200 561 465 230 561 minecraft:yellow_concrete
fill 465 200 562 465 205 562 minecraft:sea_lantern
fill 465 200 563 465 225 563 minecraft:yellow_concrete
fill 465 200 567 465 229 569 minecraft:yellow_concrete
fill 465 200 570 465 205 570 minecraft:sea_lantern
fill 465 200 571 465 225 572 minecraft:yellow_concrete
fill 465 200 574 465 227 577 minecraft:yellow_concrete
fill 465 200 578 465 205 578 minecraft:sea_lantern
fill 465 200 579 465 227 580 minecraft:yellow_concrete
fill 465 200 584 465 229 585 minecraft:yellow_concrete
fill 465 200 586 465 205 586 minecraft:sea_lantern
fill 465 200 594 465 205 594 minecraft:sea_lantern
fill 465 200 595 465 227 595 minecraft:yellow_concrete
setblock 427 201 578 minecraft:magma_block
setblock 427 201 581 minecraft:magma_block
setblock 428 201 573 minecraft:basalt
setblock 428 201 575 minecraft:basalt
fill 428 201 584 428 201 585 minecraft:basalt
setblock 430 201 571 minecraft:magma_block
setblock 433 201 576 minecraft:magma_block
setblock 433 201 582 minecraft:magma_block
fill 434 201 574 434 205 574 minecraft:basalt
fill 434 201 584 434 205 584 minecraft:basalt
fill 435 201 572 435 204 573 minecraft:basalt
fill 435 201 585 435 204 585 minecraft:basalt
fill 436 201 567 437 201 567 minecraft:basalt
setblock 436 201 572 minecraft:magma_block
setblock 437 201 566 minecraft:basalt
fill 437 201 571 437 205 572 minecraft:basalt
fill 437 201 586 437 205 586 minecraft:basalt
fill 438 201 571 438 205 571 minecraft:basalt
setblock 439 201 571 minecraft:magma_block
setblock 439 201 592 minecraft:magma_block
fill 440 201 571 443 204 571 minecraft:basalt
fill 440 201 587 440 205 587 minecraft:basalt
fill 443 201 572 443 205 572 minecraft:basalt
fill 443 201 586 443 205 586 minecraft:basalt
setblock 443 201 592 minecraft:basalt
fill 445 201 573 446 205 573 minecraft:basalt
fill 445 201 585 446 205 585 minecraft:basalt
setblock 446 201 567 minecraft:basalt
fill 446 201 574 446 205 574 minecraft:basalt
fill 446 201 584 446 205 584 minecraft:basalt
setblock 446 201 591 minecraft:basalt
fill 447 201 576 448 205 576 minecraft:basalt
fill 447 201 582 448 205 582 minecraft:basalt
setblock 448 201 569 minecraft:basalt
setblock 448 201 577 minecraft:magma_block
fill 448 201 578 448 205 579 minecraft:basalt
setblock 448 201 580 minecraft:magma_block
fill 448 201 581 448 205 581 minecraft:basalt
setblock 448 201 589 minecraft:magma_block
setblock 428 202 582 minecraft:basalt
setblock 429 202 573 minecraft:magma_block
fill 429 202 574 429 202 575 minecraft:basalt
fill 429 202 583 429 202 584 minecraft:basalt
setblock 429 202 585 minecraft:magma_block
setblock 432 202 570 minecraft:basalt
fill 433 202 576 433 205 582 minecraft:basalt
fill 434 202 575 434 202 576 minecraft:basalt
fill 434 202 582 434 202 583 minecraft:basalt
setblock 435 202 568 minecraft:magma_block
setblock 435 202 574 minecraft:magma_block
fill 435 202 584 435 205 584 minecraft:basalt
fill 436 202 572 436 205 573 minecraft:basalt
fill 436 202 585 437 205 585 minecraft:basalt
setblock 437 202 567 minecraft:basalt
fill 437 202 573 437 205 573 minecraft:basalt
setblock 437 202 591 minecraft:basalt
setblock 438 202 567 minecraft:magma_block
fill 438 202 572 440 204 572 minecraft:basalt
fill 438 202 586 442 202 586 minecraft:basalt
setblock 438 202 591 minecraft:magma_block
fill 439 202 571 439 205 571 minecraft:basalt
setblock 441 202 572 minecraft:magma_block
fill 442 202 572 442 205 572 minecraft:basalt
fill 443 202 573 444 202 573 minecraft:basalt
fill 443 202 585 444 202 585 minecraft:basalt
setblock 444 202 568 minecraft:magma_block
setblock 444 202 590 minecraft:basalt
fill 445 202 574 445 205 574 minecraft:basalt
fill 445 202 584 445 205 584 minecraft:basalt
fill 446 202 575 446 205 576 minecraft:basalt
fill 446 202 582 446 205 583 minecraft:basalt
fill 447 202 577 447 204 578 minecraft:basalt
setblock 447 202 579 minecraft:magma_block
fill 447 202 580 447 204 581 minecraft:basalt
fill 448 202 577 448 205 577 minecraft:basalt
fill 448 202 580 448 205 580 minecraft:basalt
setblock 449 202 587 minecraft:basalt
setblock 450 202 572 minecraft:magma_block
fill 452 202 570 453 203 571 minecraft:blue_concrete
setblock 431 203 572 minecraft:basalt
setblock 431 203 586 minecraft:magma_block
setblock 434 203 570 minecraft:magma_block
fill 434 203 575 435 205 575 minecraft:basalt
setblock 434 203 576 minecraft:magma_block
fill 434 203 577 434 205 578 minecraft:basalt
fill 434 203 580 434 205 581 minecraft:basalt
setblock 434 203 582 minecraft:magma_block
fill 434 203 583 435 205 583 minecraft:basalt
setblock 434 203 588 minecraft:magma_block
fill 435 203 574 436 205 574 minecraft:basalt
fill 436 203 569 436 204 569 minecraft:basalt
fill 436 203 584 436 205 584 minecraft:basalt
setblock 437 203 590 minecraft:magma_block
fill 438 203 573 439 203 573 minecraft:basalt
fill 438 203 585 439 203 586 minecraft:basalt
setblock 439 203 568 minecraft:basalt
setblock 439 203 590 minecraft:basalt
setblock 440 203 568 minecraft:magma_block
setblock 440 203 586 minecraft:magma_block
fill 441 203 572 441 205 573 minecraft:basalt
fill 441 203 585 442 204 586 minecraft:basalt
fill 442 203 573 442 205 573 minecraft:basalt
setblock 443 203 573 minecraft:magma_block
setblock 443 203 585 minecraft:magma_block
fill 444 203 573 444 204 574 minecraft:basalt
fill 444 203 584 444 204 585 minecraft:basalt
setblock 445 203 569 minecraft:basalt
fill 445 203 575 445 205 575 minecraft:basalt
fill 445 203 583 445 205 583 minecraft:basalt
setblock 446 203 569 minecraft:magma_block
fill 446 203 577 446 205 577 minecraft:basalt
setblock 446 203 578 minecraft:magma_block
fill 446 203 580 446 205 580 minecraft:basalt
setblock 446 203 581 minecraft:magma_block
setblock 446 203 589 minecraft:basalt
fill 447 203 579 447 205 579 minecraft:basalt
setblock 448 203 571 minecraft:basalt
setblock 449 203 586 minecraft:magma_block
setblock 451 203 582 minecraft:basalt
setblock 426 204 560 minecraft:light[level=14]
setblock 426 204 568 minecraft:light[level=14]
setblock 426 204 576 minecraft:light[level=14]
setblock 426 204 584 minecraft:light[level=14]
setblock 426 204 592 minecraft:light[level=14]
setblock 430 204 575 minecraft:basalt
setblock 430 204 576 minecraft:magma_block
setblock 430 204 579 minecraft:magma_block
fill 430 204 580 430 204 581 minecraft:basalt
setblock 430 204 582 minecraft:magma_block
setblock 430 204 583 minecraft:basalt
setblock 430 204 584 minecraft:purple_concrete
setblock 433 204 587 minecraft:magma_block
setblock 434 204 560 minecraft:light[level=14]
setblock 434 204 568 minecraft:light[level=14]
fill 434 204 576 435 204 576 minecraft:basalt
fill 434 204 579 434 205 579 minecraft:basalt
fill 434 204 582 435 204 582 minecraft:basalt
setblock 434 204 592 minecraft:light[level=14]
setblock 436 204 575 minecraft:basalt
fill 436 204 583 436 205 583 minecraft:magma_block
setblock 436 204 589 minecraft:magma_block
fill 437 204 574 437 205 574 minecraft:basalt
fill 437 204 584 437 205 584 minecraft:basalt
fill 438 204 573 438 205 573 minecraft:basalt
fill 438 204 585 438 205 586 minecraft:basalt
setblock 438 204 589 minecraft:basalt
setblock 439 204 573 minecraft:magma_block
setblock 439 204 585 minecraft:magma_block
fill 439 204 586 440 205 586 minecraft:basalt
fill 440 204 569 441 204 569 minecraft:basalt
fill 440 204 573 440 205 573 minecraft:basalt
fill 440 204 585 440 205 585 minecraft:basalt
setblock 442 204 560 minecraft:light[level=14]
setblock 442 204 568 minecraft:light[level=14]
setblock 442 204 569 minecraft:magma_block
setblock 442 204 576 minecraft:light[level=14]
setblock 442 204 584 minecraft:light[level=14]
setblock 442 204 592 minecraft:light[level=14]
setblock 443 204 569 minecraft:basalt
fill 443 204 573 443 205 574 minecraft:basalt
fill 443 204 584 443 205 585 minecraft:basalt
fill 443 204 589 444 204 589 minecraft:basalt
setblock 444 204 575 minecraft:basalt
setblock 444 204 583 minecraft:basalt
fill 445 204 576 445 205 576 minecraft:basalt
fill 445 204 582 445 205 582 minecraft:basalt
fill 446 204 578 446 205 579 minecraft:basalt
fill 446 204 581 446 205 581 minecraft:basalt
setblock 448 204 573 minecraft:magma_block
setblock 448 204 585 minecraft:magma_block
setblock 450 204 560 minecraft:light[level=14]
setblock 450 204 568 minecraft:light[level=14]
setblock 450 204 584 minecraft:light[level=14]
setblock 450 204 592 minecraft:light[level=14]
setblock 458 204 560 minecraft:light[level=14]
setblock 458 204 568 minecraft:light[level=14]
setblock 458 204 576 minecraft:light[level=14]
setblock 458 204 584 minecraft:light[level=14]
setblock 458 204 592 minecraft:light[level=14]
setblock 431 205 575 minecraft:basalt
fill 431 205 578 432 205 578 minecraft:basalt
setblock 431 205 583 minecraft:basalt
setblock 432 205 574 minecraft:magma_block
setblock 432 205 576 minecraft:basalt
setblock 432 205 577 minecraft:magma_block
setblock 432 205 579 minecraft:basalt
setblock 432 205 580 minecraft:magma_block
fill 432 205 581 432 205 582 minecraft:basalt
setblock 432 205 583 minecraft:magma_block
setblock 434 205 576 minecraft:basalt
setblock 434 205 582 minecraft:basalt
setblock 434 205 586 minecraft:basalt
fill 435 205 571 435 205 572 minecraft:basalt
setblock 435 205 573 minecraft:magma_block
fill 435 205 576 435 205 582 minecraft:magma_block
setblock 435 205 585 minecraft:magma_block
setblock 435 205 587 minecraft:basalt
fill 436 205 575 436 205 576 minecraft:magma_block
setblock 436 205 582 minecraft:magma_block
setblock 437 205 575 minecraft:magma_block
setblock 437 205 583 minecraft:magma_block
fill 437 205 587 437 205 588 minecraft:basalt
setblock 438 205 572 minecraft:magma_block
fill 438 205 574 442 205 574 minecraft:magma_block
fill 438 205 584 442 205 584 minecraft:magma_block
setblock 438 205 587 minecraft:magma_block
setblock 439 205 570 minecraft:basalt
fill 439 205 572 439 205 573 minecraft:basalt
setblock 439 205 585 minecraft:basalt
setblock 439 205 587 minecraft:basalt
fill 440 205 571 440 205 572 minecraft:basalt
setblock 441 205 571 minecraft:magma_block
fill 441 205 585 442 205 585 minecraft:basalt
setblock 441 205 586 minecraft:magma_block
fill 442 205 571 443 205 571 minecraft:basalt
setblock 442 205 586 minecraft:basalt
fill 443 205 575 444 205 575 minecraft:magma_block
fill 443 205 583 444 205 583 minecraft:magma_block
setblock 444 205 570 minecraft:magma_block
setblock 444 205 573 minecraft:magma_block
setblock 444 205 574 minecraft:basalt
setblock 444 205 576 minecraft:magma_block
setblock 444 205 582 minecraft:magma_block
setblock 444 205 584 minecraft:basalt
setblock 444 205 585 minecraft:magma_block
setblock 444 205 588 minecraft:magma_block
setblock 445 205 571 minecraft:basalt
fill 445 205 577 445 205 581 minecraft:magma_block
setblock 447 205 572 minecraft:magma_block
setblock 447 205 574 minecraft:basalt
setblock 447 205 575 minecraft:magma_block
setblock 447 205 577 minecraft:basalt
setblock 447 205 578 minecraft:magma_block
setblock 447 205 580 minecraft:basalt
setblock 447 205 581 minecraft:magma_block
setblock 447 205 584 minecraft:magma_block
setblock 448 205 584 minecraft:basalt
setblock 449 205 575 minecraft:basalt
setblock 449 205 583 minecraft:basalt
fill 423 206 562 423 213 562 minecraft:yellow_concrete
fill 423 206 570 423 213 570 minecraft:yellow_concrete
fill 423 206 578 423 213 578 minecraft:yellow_concrete
fill 423 206 586 423 213 586 minecraft:yellow_concrete
fill 423 206 594 423 213 594 minecraft:yellow_concrete
fill 426 206 599 426 213 599 minecraft:yellow_concrete
fill 430 206 557 430 213 557 minecraft:yellow_concrete
fill 434 206 599 434 213 599 minecraft:yellow_concrete
fill 438 206 557 438 213 557 minecraft:yellow_concrete
fill 438 206 586 439 206 586 minecraft:purple_concrete
fill 442 206 599 442 213 599 minecraft:yellow_concrete
fill 446 206 557 446 213 557 minecraft:yellow_concrete
fill 450 206 599 450 213 599 minecraft:yellow_concrete
fill 454 206 557 454 213 557 minecraft:yellow_concrete
fill 458 206 599 458 213 599 minecraft:yellow_concrete
fill 462 206 557 462 213 557 minecraft:yellow_concrete
fill 465 206 562 465 213 562 minecraft:yellow_concrete
fill 465 206 570 465 213 570 minecraft:yellow_concrete
fill 465 206 578 465 213 578 minecraft:yellow_concrete
fill 465 206 586 465 213 586 minecraft:yellow_concrete
fill 465 206 594 465 213 594 minecraft:yellow_concrete
fill 450 207 566 450 208 566 minecraft:purple_concrete
fill 448 208 586 450 209 586 minecraft:blue_concrete
fill 449 208 585 449 209 585 minecraft:blue_concrete
fill 449 208 587 449 209 587 minecraft:blue_concrete
fill 424 210 558 424 211 563 minecraft:white_concrete
fill 424 210 566 425 210 571 minecraft:white_concrete
fill 424 210 574 425 210 579 minecraft:white_concrete
fill 424 210 582 425 210 587 minecraft:white_concrete
fill 424 210 590 425 210 595 minecraft:white_concrete
fill 424 210 598 429 211 598 minecraft:white_concrete
fill 425 210 559 425 210 565 minecraft:white_concrete
fill 425 210 572 425 210 573 minecraft:white_concrete
fill 425 210 580 425 210 581 minecraft:white_concrete
fill 425 210 588 425 210 589 minecraft:white_concrete
fill 425 210 596 425 210 597 minecraft:white_concrete
fill 426 210 559 463 210 559 minecraft:white_concrete
fill 426 210 576 427 211 580 minecraft:white_concrete
fill 426 210 597 464 210 597 minecraft:white_concrete
fill 427 210 558 432 211 558 minecraft:white_concrete
fill 427 210 572 427 211 575 minecraft:white_concrete
fill 427 210 581 427 211 584 minecraft:white_concrete
fill 428 210 570 428 211 572 minecraft:white_concrete
fill 428 210 584 428 211 586 minecraft:white_concrete
fill 429 210 568 429 211 570 minecraft:white_concrete
fill 429 210 586 429 211 588 minecraft:white_concrete
fill 430 210 567 430 211 568 minecraft:white_concrete
fill 430 210 588 430 211 589 minecraft:white_concrete
fill 431 210 566 431 211 567 minecraft:white_concrete
fill 431 210 589 431 211 590 minecraft:white_concrete
fill 432 210 565 432 211 566 minecraft:white_concrete
fill 432 210 580 434 211 580 minecraft:red_concrete
fill 432 210 590 432 211 591 minecraft:white_concrete
fill 432 210 598 437 211 598 minecraft:white_concrete
fill 433 210 564 433 211 565 minecraft:white_concrete
fill 433 210 579 433 211 579 minecraft:red_concrete
fill 433 210 591 433 211 592 minecraft:white_concrete
fill 434 210 563 434 211 564 minecraft:white_concrete
fill 434 210 592 434 211 593 minecraft:white_concrete
fill 435 210 558 440 211 558 minecraft:white_concrete
fill 435 210 563 436 211 563 minecraft:white_concrete
fill 435 210 593 436 211 593 minecraft:white_concrete
schedule function dropper:buildpart/141_2 1t
