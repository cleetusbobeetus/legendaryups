setblock 26 166 324 minecraft:yellow_terracotta
fill 26 166 325 26 169 325 minecraft:honeycomb_block
fill 26 166 360 26 169 360 minecraft:honeycomb_block
setblock 27 166 323 minecraft:yellow_terracotta
fill 27 166 324 27 169 324 minecraft:honeycomb_block
setblock 27 166 363 minecraft:yellow_terracotta
setblock 28 166 322 minecraft:yellow_terracotta
fill 28 166 323 28 169 323 minecraft:honeycomb_block
setblock 28 166 362 minecraft:yellow_terracotta
fill 28 166 363 28 169 363 minecraft:honeycomb_block
setblock 29 166 361 minecraft:yellow_terracotta
fill 29 166 362 29 169 362 minecraft:honeycomb_block
setblock 30 166 325 minecraft:yellow_terracotta
setblock 30 166 360 minecraft:yellow_terracotta
fill 30 166 361 30 169 361 minecraft:honeycomb_block
setblock 31 166 324 minecraft:yellow_terracotta
setblock 31 166 360 minecraft:honeycomb_block
setblock 32 166 323 minecraft:yellow_terracotta
fill 32 166 324 32 169 324 minecraft:honeycomb_block
setblock 32 166 363 minecraft:yellow_terracotta
fill 33 166 323 33 169 323 minecraft:honeycomb_block
setblock 33 166 362 minecraft:yellow_terracotta
fill 33 166 363 33 169 363 minecraft:honeycomb_block
setblock 34 166 361 minecraft:yellow_terracotta
fill 34 166 362 34 169 362 minecraft:honeycomb_block
fill 35 166 361 35 167 361 minecraft:honeycomb_block
setblock 37 166 323 minecraft:yellow_terracotta
setblock 37 166 363 minecraft:yellow_terracotta
fill 38 166 323 41 166 323 minecraft:honeycomb_block
setblock 38 166 362 minecraft:yellow_terracotta
fill 38 166 363 38 167 364 minecraft:honeycomb_block
fill 39 166 322 39 168 322 minecraft:honeycomb_block
fill 39 166 362 39 169 362 minecraft:honeycomb_block
fill 40 166 342 41 166 343 minecraft:honeycomb_block
setblock 40 166 360 minecraft:yellow_terracotta
fill 40 166 361 40 169 361 minecraft:honeycomb_block
setblock 41 166 327 minecraft:honey_block
fill 41 166 337 41 166 338 minecraft:honeycomb_block
setblock 41 166 339 minecraft:yellow_terracotta
fill 41 166 340 41 169 340 minecraft:honeycomb_block
setblock 41 166 344 minecraft:yellow_terracotta
fill 41 166 345 41 169 345 minecraft:honeycomb_block
setblock 41 166 349 minecraft:yellow_terracotta
fill 41 166 350 41 168 351 minecraft:honeycomb_block
setblock 41 166 354 minecraft:yellow_terracotta
fill 41 166 355 41 169 355 minecraft:honeycomb_block
setblock 41 166 359 minecraft:yellow_terracotta
fill 41 166 360 41 169 360 minecraft:honeycomb_block
setblock 42 166 325 minecraft:yellow_concrete
fill 42 166 326 42 308 326 minecraft:honeycomb_block
setblock 0 167 344 minecraft:orange_terracotta
setblock 1 167 323 minecraft:yellow_terracotta
fill 1 167 324 1 169 325 minecraft:honeycomb_block
setblock 1 167 333 minecraft:yellow_terracotta
fill 1 167 334 1 170 334 minecraft:honeycomb_block
setblock 1 167 337 minecraft:honeycomb_block
setblock 1 167 338 minecraft:yellow_terracotta
fill 1 167 339 1 170 339 minecraft:honeycomb_block
setblock 1 167 343 minecraft:yellow_terracotta
fill 1 167 344 1 170 344 minecraft:honeycomb_block
setblock 1 167 347 minecraft:honeycomb_block
setblock 1 167 348 minecraft:yellow_terracotta
fill 1 167 349 1 170 349 minecraft:honeycomb_block
fill 1 167 351 1 167 352 minecraft:honeycomb_block
setblock 1 167 353 minecraft:yellow_terracotta
fill 1 167 354 1 170 354 minecraft:honeycomb_block
setblock 1 167 358 minecraft:yellow_terracotta
fill 1 167 359 1 170 359 minecraft:honeycomb_block
setblock 1 167 362 minecraft:honeycomb_block
setblock 1 167 363 minecraft:yellow_terracotta
fill 2 167 323 5 167 323 minecraft:honeycomb_block
setblock 2 167 337 minecraft:yellow_terracotta
fill 2 167 338 2 170 338 minecraft:honeycomb_block
setblock 2 167 341 minecraft:honeycomb_block
setblock 2 167 342 minecraft:yellow_terracotta
fill 2 167 343 2 170 343 minecraft:honeycomb_block
setblock 2 167 347 minecraft:yellow_terracotta
fill 2 167 348 3 169 348 minecraft:honeycomb_block
fill 2 167 350 2 167 351 minecraft:honeycomb_block
fill 2 167 358 2 168 358 minecraft:honeycomb_block
setblock 2 167 362 minecraft:yellow_terracotta
fill 2 167 363 2 170 363 minecraft:honeycomb_block
fill 3 167 324 4 167 324 minecraft:honeycomb_block
setblock 3 167 336 minecraft:yellow_terracotta
fill 3 167 337 3 170 337 minecraft:honeycomb_block
setblock 3 167 341 minecraft:yellow_terracotta
fill 3 167 342 3 170 342 minecraft:honeycomb_block
setblock 3 167 346 minecraft:yellow_terracotta
fill 3 167 347 3 170 347 minecraft:honeycomb_block
fill 3 167 362 3 170 362 minecraft:honeycomb_block
setblock 4 167 340 minecraft:yellow_terracotta
fill 4 167 341 4 170 341 minecraft:honeycomb_block
setblock 4 167 344 minecraft:honeycomb_block
setblock 4 167 345 minecraft:yellow_terracotta
fill 4 167 346 4 170 346 minecraft:honeycomb_block
setblock 5 167 324 minecraft:yellow_terracotta
fill 5 167 340 5 168 340 minecraft:honeycomb_block
fill 5 167 342 5 167 343 minecraft:honeycomb_block
setblock 5 167 361 minecraft:honeycomb_block
setblock 6 167 323 minecraft:yellow_terracotta
fill 6 167 324 9 167 324 minecraft:honeycomb_block
setblock 6 167 363 minecraft:yellow_terracotta
fill 7 167 323 7 170 323 minecraft:honeycomb_block
setblock 7 167 362 minecraft:yellow_terracotta
fill 7 167 363 7 170 363 minecraft:honeycomb_block
setblock 8 167 325 minecraft:honeycomb_block
fill 8 167 362 8 170 362 minecraft:honeycomb_block
setblock 9 167 322 minecraft:yellow_terracotta
setblock 10 167 324 minecraft:yellow_terracotta
setblock 11 167 323 minecraft:yellow_terracotta
fill 11 167 324 11 170 324 minecraft:honeycomb_block
setblock 11 167 363 minecraft:yellow_terracotta
fill 12 167 323 15 167 323 minecraft:honeycomb_block
fill 12 167 363 12 170 363 minecraft:honeycomb_block
setblock 14 167 324 minecraft:honeycomb_block
fill 14 167 325 14 169 325 minecraft:honey_block
setblock 15 167 324 minecraft:yellow_terracotta
setblock 16 167 323 minecraft:yellow_terracotta
fill 16 167 324 19 167 324 minecraft:honeycomb_block
setblock 16 167 363 minecraft:yellow_terracotta
fill 17 167 323 17 170 323 minecraft:honeycomb_block
fill 17 167 363 17 170 363 minecraft:honeycomb_block
fill 19 167 362 19 169 362 minecraft:honeycomb_block
setblock 20 167 324 minecraft:yellow_terracotta
fill 20 167 361 21 180 361 minecraft:yellow_terracotta
setblock 21 167 323 minecraft:yellow_terracotta
fill 21 167 324 21 169 325 minecraft:honeycomb_block
setblock 21 167 363 minecraft:yellow_terracotta
fill 22 167 323 22 170 323 minecraft:honeycomb_block
fill 22 167 325 23 167 325 minecraft:honeycomb_block
fill 22 167 326 22 167 329 minecraft:honey_block
setblock 22 167 361 minecraft:honeycomb_block
setblock 22 167 362 minecraft:yellow_terracotta
fill 22 167 363 22 170 363 minecraft:honeycomb_block
setblock 23 167 361 minecraft:yellow_terracotta
fill 23 167 362 23 170 362 minecraft:honeycomb_block
setblock 24 167 325 minecraft:yellow_terracotta
fill 24 167 361 24 170 361 minecraft:honeycomb_block
setblock 25 167 324 minecraft:yellow_terracotta
fill 25 167 325 25 170 325 minecraft:honeycomb_block
setblock 26 167 323 minecraft:yellow_terracotta
fill 26 167 324 26 170 324 minecraft:honeycomb_block
setblock 26 167 363 minecraft:yellow_terracotta
fill 27 167 323 27 170 323 minecraft:honeycomb_block
fill 27 167 325 28 167 325 minecraft:honeycomb_block
setblock 27 167 362 minecraft:yellow_terracotta
fill 27 167 363 27 170 363 minecraft:honeycomb_block
fill 28 167 322 28 212 322 minecraft:honeycomb_block
setblock 28 167 360 minecraft:honeycomb_block
setblock 28 167 361 minecraft:yellow_terracotta
fill 28 167 362 28 170 362 minecraft:honeycomb_block
setblock 29 167 325 minecraft:yellow_terracotta
setblock 29 167 360 minecraft:yellow_terracotta
fill 29 167 361 29 170 361 minecraft:honeycomb_block
setblock 30 167 324 minecraft:yellow_terracotta
fill 30 167 325 30 169 325 minecraft:honeycomb_block
setblock 30 167 360 minecraft:honeycomb_block
setblock 31 167 323 minecraft:yellow_terracotta
fill 31 167 324 31 170 324 minecraft:honeycomb_block
setblock 31 167 363 minecraft:yellow_terracotta
fill 31 167 364 31 184 364 minecraft:honeycomb_block
fill 32 167 323 32 170 323 minecraft:honeycomb_block
setblock 32 167 362 minecraft:yellow_terracotta
fill 32 167 363 32 170 363 minecraft:honeycomb_block
setblock 33 167 361 minecraft:yellow_terracotta
fill 33 167 362 33 170 362 minecraft:honeycomb_block
fill 34 167 361 34 168 361 minecraft:honeycomb_block
setblock 35 167 323 minecraft:honeycomb_block
setblock 36 167 323 minecraft:yellow_terracotta
setblock 36 167 363 minecraft:yellow_terracotta
fill 37 167 323 40 167 323 minecraft:honeycomb_block
setblock 37 167 362 minecraft:yellow_terracotta
fill 37 167 363 37 170 363 minecraft:honeycomb_block
fill 38 167 362 38 170 362 minecraft:honeycomb_block
fill 40 167 340 40 167 343 minecraft:honeycomb_block
setblock 40 167 344 minecraft:yellow_terracotta
fill 40 167 345 40 168 347 minecraft:honeycomb_block
setblock 40 167 359 minecraft:yellow_terracotta
fill 40 167 360 40 170 360 minecraft:honeycomb_block
setblock 41 167 323 minecraft:yellow_terracotta
fill 41 167 324 41 170 324 minecraft:honeycomb_block
setblock 41 167 337 minecraft:honeycomb_block
setblock 41 167 338 minecraft:yellow_terracotta
fill 41 167 339 41 170 339 minecraft:honeycomb_block
setblock 41 167 342 minecraft:honeycomb_block
setblock 41 167 343 minecraft:yellow_terracotta
fill 41 167 344 41 170 344 minecraft:honeycomb_block
fill 41 167 346 41 167 347 minecraft:honeycomb_block
setblock 41 167 348 minecraft:yellow_terracotta
fill 41 167 349 41 170 349 minecraft:honeycomb_block
setblock 41 167 352 minecraft:honeycomb_block
setblock 41 167 353 minecraft:yellow_terracotta
fill 41 167 354 41 170 354 minecraft:honeycomb_block
setblock 41 167 358 minecraft:yellow_terracotta
fill 41 167 359 41 170 359 minecraft:honeycomb_block
setblock 41 167 363 minecraft:yellow_terracotta
fill 42 167 325 42 216 325 minecraft:honeycomb_block
fill 0 168 344 0 308 344 minecraft:honeycomb_block
fill 1 168 323 4 168 323 minecraft:honeycomb_block
setblock 1 168 326 minecraft:honeycomb_block
setblock 1 168 327 minecraft:yellow_terracotta
fill 1 168 328 1 171 328 minecraft:honeycomb_block
setblock 1 168 332 minecraft:yellow_terracotta
fill 1 168 333 1 171 333 minecraft:honeycomb_block
setblock 1 168 336 minecraft:honeycomb_block
setblock 1 168 337 minecraft:yellow_terracotta
fill 1 168 338 1 171 338 minecraft:honeycomb_block
setblock 1 168 342 minecraft:yellow_terracotta
fill 1 168 343 1 171 343 minecraft:honeycomb_block
setblock 1 168 346 minecraft:honeycomb_block
setblock 1 168 347 minecraft:yellow_terracotta
fill 1 168 348 1 171 348 minecraft:honeycomb_block
setblock 1 168 351 minecraft:honeycomb_block
setblock 1 168 352 minecraft:yellow_terracotta
fill 1 168 353 1 171 353 minecraft:honeycomb_block
setblock 1 168 357 minecraft:yellow_terracotta
fill 1 168 358 1 171 358 minecraft:honeycomb_block
setblock 1 168 361 minecraft:honeycomb_block
setblock 1 168 362 minecraft:yellow_terracotta
fill 1 168 363 1 171 363 minecraft:honeycomb_block
fill 2 168 324 2 168 325 minecraft:honeycomb_block
fill 2 168 334 2 169 334 minecraft:honeycomb_block
setblock 2 168 336 minecraft:yellow_terracotta
fill 2 168 337 2 171 337 minecraft:honeycomb_block
setblock 2 168 341 minecraft:yellow_terracotta
fill 2 168 342 2 171 342 minecraft:honeycomb_block
setblock 2 168 345 minecraft:honeycomb_block
setblock 2 168 346 minecraft:yellow_terracotta
fill 2 168 347 2 171 347 minecraft:honeycomb_block
setblock 2 168 350 minecraft:honeycomb_block
setblock 2 168 351 minecraft:yellow_terracotta
fill 2 168 352 2 171 352 minecraft:honeycomb_block
setblock 2 168 361 minecraft:yellow_terracotta
fill 2 168 362 2 170 362 minecraft:honeycomb_block
setblock 3 168 324 minecraft:honeycomb_block
setblock 3 168 325 minecraft:light[level=15]
setblock 3 168 333 minecraft:light[level=15]
fill 3 168 336 3 170 336 minecraft:honeycomb_block
setblock 3 168 339 minecraft:honeycomb_block
setblock 3 168 340 minecraft:yellow_terracotta
fill 3 168 341 3 171 341 minecraft:honeycomb_block
setblock 3 168 345 minecraft:yellow_terracotta
fill 3 168 346 3 171 346 minecraft:honeycomb_block
setblock 3 168 349 minecraft:honeycomb_block
setblock 3 168 357 minecraft:light[level=15]
setblock 4 168 324 minecraft:yellow_terracotta
setblock 4 168 339 minecraft:yellow_terracotta
fill 4 168 340 4 171 340 minecraft:honeycomb_block
setblock 4 168 344 minecraft:yellow_terracotta
fill 4 168 345 4 171 345 minecraft:honeycomb_block
fill 4 168 347 4 169 347 minecraft:honeycomb_block
setblock 5 168 323 minecraft:yellow_terracotta
fill 5 168 324 7 168 325 minecraft:honeycomb_block
setblock 5 168 342 minecraft:honeycomb_block
setblock 5 168 343 minecraft:yellow_terracotta
fill 5 168 344 5 170 344 minecraft:honeycomb_block
setblock 5 168 363 minecraft:yellow_terracotta
fill 6 168 323 6 171 323 minecraft:honeycomb_block
setblock 6 168 362 minecraft:yellow_terracotta
fill 6 168 363 6 171 363 minecraft:honeycomb_block
fill 7 168 362 7 170 362 minecraft:honeycomb_block
setblock 8 168 324 minecraft:honeycomb_block
setblock 8 168 325 minecraft:yellow_terracotta
fill 9 168 322 9 201 322 minecraft:honeycomb_block
setblock 9 168 324 minecraft:yellow_terracotta
fill 9 168 325 10 170 325 minecraft:honeycomb_block
setblock 10 168 323 minecraft:yellow_terracotta
fill 10 168 324 10 171 324 minecraft:honeycomb_block
setblock 10 168 363 minecraft:yellow_terracotta
fill 11 168 323 14 168 323 minecraft:honeycomb_block
setblock 11 168 325 minecraft:light[level=15]
setblock 11 168 333 minecraft:light[level=15]
setblock 11 168 341 minecraft:light[level=15]
setblock 11 168 349 minecraft:light[level=15]
setblock 11 168 357 minecraft:light[level=15]
setblock 11 168 362 minecraft:yellow_terracotta
fill 11 168 363 11 171 363 minecraft:honeycomb_block
setblock 12 168 327 minecraft:ochre_froglight
setblock 13 168 330 minecraft:ochre_froglight
setblock 14 168 324 minecraft:yellow_terracotta
setblock 14 168 331 minecraft:ochre_froglight
setblock 15 168 323 minecraft:yellow_terracotta
fill 15 168 324 18 168 324 minecraft:honeycomb_block
setblock 15 168 363 minecraft:yellow_terracotta
fill 16 168 323 16 171 323 minecraft:honeycomb_block
fill 16 168 363 16 171 363 minecraft:honeycomb_block
setblock 17 168 332 minecraft:ochre_froglight
setblock 19 168 324 minecraft:yellow_terracotta
setblock 19 168 333 minecraft:light[level=15]
setblock 19 168 341 minecraft:light[level=15]
setblock 19 168 349 minecraft:light[level=15]
setblock 19 168 357 minecraft:light[level=15]
setblock 20 168 323 minecraft:yellow_terracotta
fill 20 168 324 20 170 325 minecraft:honeycomb_block
setblock 20 168 331 minecraft:ochre_froglight
setblock 20 168 363 minecraft:yellow_terracotta
fill 21 168 323 21 171 323 minecraft:honeycomb_block
setblock 21 168 330 minecraft:ochre_froglight
setblock 21 168 362 minecraft:yellow_terracotta
fill 21 168 363 21 171 363 minecraft:honeycomb_block
setblock 22 168 325 minecraft:honeycomb_block
setblock 22 168 327 minecraft:ochre_froglight
setblock 22 168 361 minecraft:yellow_terracotta
fill 22 168 362 22 171 362 minecraft:honeycomb_block
setblock 23 168 325 minecraft:yellow_terracotta
fill 23 168 361 23 171 361 minecraft:honeycomb_block
setblock 24 168 324 minecraft:yellow_terracotta
fill 24 168 325 24 171 325 minecraft:honeycomb_block
setblock 25 168 323 minecraft:yellow_terracotta
fill 25 168 324 25 171 324 minecraft:honeycomb_block
fill 25 168 326 26 168 326 minecraft:honeycomb_block
setblock 25 168 360 minecraft:honeycomb_block
setblock 25 168 363 minecraft:yellow_terracotta
fill 26 168 323 26 171 323 minecraft:honeycomb_block
setblock 26 168 362 minecraft:yellow_terracotta
fill 26 168 363 26 171 363 minecraft:honeycomb_block
setblock 27 168 325 minecraft:honeycomb_block
setblock 27 168 333 minecraft:light[level=15]
setblock 27 168 341 minecraft:light[level=15]
setblock 27 168 349 minecraft:light[level=15]
setblock 27 168 357 minecraft:light[level=15]
setblock 27 168 361 minecraft:yellow_terracotta
fill 27 168 362 27 171 362 minecraft:honeycomb_block
setblock 28 168 325 minecraft:yellow_terracotta
setblock 28 168 360 minecraft:yellow_terracotta
fill 28 168 361 28 171 361 minecraft:honeycomb_block
setblock 29 168 324 minecraft:yellow_terracotta
fill 29 168 325 29 171 325 minecraft:honeycomb_block
setblock 29 168 360 minecraft:honeycomb_block
setblock 30 168 323 minecraft:yellow_terracotta
fill 30 168 324 30 171 324 minecraft:honeycomb_block
setblock 30 168 363 minecraft:yellow_terracotta
fill 31 168 323 31 171 323 minecraft:honeycomb_block
setblock 31 168 362 minecraft:yellow_terracotta
fill 31 168 363 31 171 363 minecraft:honeycomb_block
setblock 32 168 361 minecraft:yellow_terracotta
fill 32 168 362 32 171 362 minecraft:honeycomb_block
setblock 33 168 361 minecraft:honeycomb_block
setblock 35 168 323 minecraft:yellow_terracotta
setblock 35 168 325 minecraft:light[level=15]
setblock 35 168 333 minecraft:light[level=15]
setblock 35 168 341 minecraft:light[level=15]
setblock 35 168 349 minecraft:light[level=15]
setblock 35 168 357 minecraft:light[level=15]
setblock 35 168 363 minecraft:yellow_terracotta
fill 36 168 323 39 168 323 minecraft:honeycomb_block
setblock 36 168 362 minecraft:yellow_terracotta
fill 36 168 363 36 171 363 minecraft:honeycomb_block
fill 37 168 362 37 170 362 minecraft:honeycomb_block
fill 38 168 363 38 169 363 minecraft:honeycomb_block
setblock 38 168 364 minecraft:yellow_terracotta
setblock 40 168 323 minecraft:yellow_terracotta
fill 40 168 340 40 168 342 minecraft:honeycomb_block
setblock 40 168 343 minecraft:yellow_terracotta
fill 40 168 344 40 171 344 minecraft:honeycomb_block
setblock 40 168 348 minecraft:yellow_terracotta
fill 40 168 349 40 171 349 minecraft:honeycomb_block
setblock 40 168 358 minecraft:yellow_terracotta
fill 40 168 359 40 170 359 minecraft:honeycomb_block
setblock 40 168 363 minecraft:yellow_terracotta
fill 41 168 323 41 171 323 minecraft:honeycomb_block
fill 41 168 325 41 168 326 minecraft:honeycomb_block
setblock 41 168 334 minecraft:honey_block
setblock 41 168 336 minecraft:honeycomb_block
setblock 41 168 337 minecraft:yellow_terracotta
fill 41 168 338 41 171 338 minecraft:honeycomb_block
setblock 41 168 342 minecraft:yellow_terracotta
fill 41 168 343 41 171 343 minecraft:honeycomb_block
setblock 41 168 346 minecraft:honeycomb_block
setblock 41 168 347 minecraft:yellow_terracotta
fill 41 168 348 41 171 348 minecraft:honeycomb_block
setblock 41 168 352 minecraft:yellow_terracotta
fill 41 168 353 41 171 353 minecraft:honeycomb_block
fill 41 168 357 42 168 357 minecraft:yellow_terracotta
fill 41 168 358 41 171 358 minecraft:honeycomb_block
setblock 41 168 362 minecraft:yellow_terracotta
fill 41 168 363 41 171 363 minecraft:honeycomb_block
setblock 42 168 351 minecraft:yellow_terracotta
fill 1 169 323 3 169 323 minecraft:honeycomb_block
setblock 1 169 326 minecraft:yellow_terracotta
fill 1 169 327 2 171 327 minecraft:honeycomb_block
fill 1 169 329 1 169 330 minecraft:honeycomb_block
setblock 1 169 331 minecraft:yellow_terracotta
fill 1 169 332 1 172 332 minecraft:honeycomb_block
setblock 1 169 335 minecraft:honeycomb_block
setblock 1 169 336 minecraft:yellow_terracotta
fill 1 169 337 1 172 337 minecraft:honeycomb_block
setblock 1 169 341 minecraft:yellow_terracotta
fill 1 169 342 1 172 342 minecraft:honeycomb_block
setblock 1 169 346 minecraft:yellow_terracotta
fill 1 169 347 1 172 347 minecraft:honeycomb_block
setblock 1 169 351 minecraft:yellow_terracotta
fill 1 169 352 1 172 352 minecraft:honeycomb_block
setblock 1 169 356 minecraft:yellow_terracotta
fill 1 169 357 1 171 357 minecraft:honeycomb_block
setblock 1 169 361 minecraft:yellow_terracotta
fill 1 169 362 1 172 362 minecraft:honeycomb_block
setblock 2 169 324 minecraft:honeycomb_block
setblock 2 169 325 minecraft:yellow_terracotta
fill 2 169 326 2 172 326 minecraft:honeycomb_block
setblock 2 169 335 minecraft:yellow_terracotta
fill 2 169 336 2 172 336 minecraft:honeycomb_block
setblock 2 169 340 minecraft:yellow_terracotta
fill 2 169 341 2 172 341 minecraft:honeycomb_block
setblock 2 169 345 minecraft:yellow_terracotta
fill 2 169 346 2 172 346 minecraft:honeycomb_block
setblock 2 169 350 minecraft:yellow_terracotta
fill 2 169 351 2 172 351 minecraft:honeycomb_block
setblock 2 169 360 minecraft:yellow_terracotta
fill 2 169 361 2 170 361 minecraft:honeycomb_block
setblock 3 169 324 minecraft:yellow_terracotta
setblock 3 169 338 minecraft:honeycomb_block
setblock 3 169 339 minecraft:yellow_terracotta
fill 3 169 340 3 172 340 minecraft:honeycomb_block
setblock 3 169 344 minecraft:yellow_terracotta
fill 3 169 345 3 172 345 minecraft:honeycomb_block
setblock 3 169 349 minecraft:yellow_terracotta
fill 3 169 350 3 172 350 minecraft:honeycomb_block
setblock 4 169 323 minecraft:yellow_terracotta
fill 4 169 324 6 169 325 minecraft:honeycomb_block
setblock 4 169 338 minecraft:yellow_terracotta
fill 4 169 339 4 170 339 minecraft:honeycomb_block
setblock 4 169 343 minecraft:yellow_terracotta
fill 4 169 344 4 172 344 minecraft:honeycomb_block
setblock 4 169 363 minecraft:yellow_terracotta
fill 5 169 323 5 172 323 minecraft:honeycomb_block
setblock 5 169 342 minecraft:yellow_terracotta
fill 5 169 343 5 170 343 minecraft:honeycomb_block
setblock 5 169 345 minecraft:honeycomb_block
setblock 5 169 362 minecraft:yellow_terracotta
fill 5 169 363 5 172 363 minecraft:honeycomb_block
fill 6 169 362 6 170 362 minecraft:honeycomb_block
setblock 7 169 324 minecraft:honeycomb_block
setblock 7 169 325 minecraft:yellow_terracotta
setblock 8 169 324 minecraft:yellow_terracotta
fill 8 169 325 8 172 325 minecraft:honeycomb_block
setblock 9 169 323 minecraft:yellow_terracotta
fill 9 169 324 9 172 324 minecraft:honeycomb_block
setblock 9 169 363 minecraft:yellow_terracotta
fill 10 169 323 13 169 323 minecraft:honeycomb_block
setblock 10 169 362 minecraft:yellow_terracotta
fill 10 169 363 10 171 363 minecraft:honeycomb_block
setblock 12 169 324 minecraft:honeycomb_block
setblock 13 169 324 minecraft:yellow_terracotta
setblock 14 169 323 minecraft:yellow_terracotta
fill 14 169 324 17 169 324 minecraft:honeycomb_block
setblock 14 169 363 minecraft:yellow_terracotta
fill 15 169 323 15 172 323 minecraft:honeycomb_block
fill 15 169 325 18 169 325 minecraft:honey_block
fill 15 169 363 15 171 363 minecraft:honeycomb_block
setblock 18 169 324 minecraft:yellow_terracotta
setblock 19 169 323 minecraft:yellow_terracotta
fill 19 169 324 19 171 325 minecraft:honeycomb_block
setblock 19 169 363 minecraft:yellow_terracotta
fill 20 169 323 20 172 323 minecraft:honeycomb_block
setblock 20 169 362 minecraft:yellow_terracotta
fill 20 169 363 20 172 363 minecraft:honeycomb_block
fill 21 169 362 21 172 362 minecraft:honeycomb_block
setblock 22 169 325 minecraft:yellow_terracotta
fill 22 169 361 22 171 361 minecraft:honeycomb_block
setblock 23 169 324 minecraft:yellow_terracotta
fill 23 169 325 23 171 326 minecraft:honeycomb_block
setblock 24 169 323 minecraft:yellow_terracotta
fill 24 169 324 24 172 324 minecraft:honeycomb_block
fill 24 169 326 25 169 326 minecraft:honeycomb_block
setblock 24 169 363 minecraft:yellow_terracotta
fill 25 169 323 25 172 323 minecraft:honeycomb_block
setblock 25 169 362 minecraft:yellow_terracotta
fill 25 169 363 25 172 363 minecraft:honeycomb_block
setblock 26 169 326 minecraft:yellow_terracotta
setblock 26 169 361 minecraft:yellow_terracotta
fill 26 169 362 26 172 362 minecraft:honeycomb_block
setblock 27 169 325 minecraft:yellow_terracotta
setblock 27 169 360 minecraft:yellow_terracotta
fill 27 169 361 27 172 361 minecraft:honeycomb_block
setblock 28 169 324 minecraft:yellow_terracotta
fill 28 169 325 28 172 325 minecraft:honeycomb_block
setblock 29 169 323 minecraft:yellow_terracotta
fill 29 169 324 29 172 324 minecraft:honeycomb_block
setblock 29 169 363 minecraft:yellow_terracotta
fill 30 169 323 30 172 323 minecraft:honeycomb_block
setblock 30 169 362 minecraft:yellow_terracotta
fill 30 169 363 30 172 363 minecraft:honeycomb_block
setblock 31 169 361 minecraft:yellow_terracotta
fill 31 169 362 31 172 362 minecraft:honeycomb_block
setblock 32 169 361 minecraft:honeycomb_block
setblock 33 169 324 minecraft:yellow_terracotta
setblock 34 169 323 minecraft:yellow_terracotta
setblock 34 169 363 minecraft:yellow_terracotta
fill 35 169 323 38 169 323 minecraft:honeycomb_block
setblock 35 169 362 minecraft:yellow_terracotta
fill 35 169 363 35 172 363 minecraft:honeycomb_block
fill 36 169 362 36 170 362 minecraft:honeycomb_block
fill 38 169 364 38 189 364 minecraft:honeycomb_block
setblock 39 169 322 minecraft:orange_terracotta
setblock 39 169 323 minecraft:yellow_terracotta
setblock 39 169 363 minecraft:yellow_terracotta
fill 40 169 323 40 172 323 minecraft:honeycomb_block
fill 40 169 340 40 169 341 minecraft:honeycomb_block
setblock 40 169 342 minecraft:yellow_terracotta
fill 40 169 343 40 172 343 minecraft:honeycomb_block
fill 40 169 345 40 169 346 minecraft:honeycomb_block
setblock 40 169 347 minecraft:yellow_terracotta
fill 40 169 348 40 172 348 minecraft:honeycomb_block
fill 40 169 350 40 169 351 minecraft:honeycomb_block
setblock 40 169 357 minecraft:yellow_terracotta
fill 40 169 358 40 170 358 minecraft:honeycomb_block
setblock 40 169 362 minecraft:yellow_terracotta
fill 40 169 363 40 172 363 minecraft:honeycomb_block
setblock 41 169 325 minecraft:honeycomb_block
setblock 41 169 326 minecraft:yellow_terracotta
fill 41 169 327 41 172 327 minecraft:honeycomb_block
setblock 41 169 328 minecraft:honey_block
setblock 41 169 336 minecraft:yellow_terracotta
fill 41 169 337 41 172 337 minecraft:honeycomb_block
setblock 41 169 341 minecraft:yellow_terracotta
fill 41 169 342 41 172 342 minecraft:honeycomb_block
setblock 41 169 346 minecraft:yellow_terracotta
fill 41 169 347 41 172 347 minecraft:honeycomb_block
setblock 41 169 350 minecraft:honeycomb_block
setblock 41 169 351 minecraft:yellow_terracotta
fill 41 169 352 41 172 352 minecraft:honeycomb_block
setblock 41 169 356 minecraft:yellow_terracotta
fill 41 169 357 42 172 357 minecraft:honeycomb_block
setblock 41 169 361 minecraft:yellow_terracotta
fill 41 169 362 41 172 362 minecraft:honeycomb_block
fill 42 169 351 42 180 351 minecraft:honeycomb_block
setblock 0 170 335 minecraft:yellow_concrete
fill 0 170 336 0 173 337 minecraft:honeycomb_block
setblock 0 170 339 minecraft:yellow_terracotta
fill 1 170 323 1 170 324 minecraft:honeycomb_block
setblock 1 170 325 minecraft:yellow_terracotta
fill 1 170 326 1 173 326 minecraft:honeycomb_block
setblock 1 170 329 minecraft:honeycomb_block
setblock 1 170 330 minecraft:yellow_terracotta
fill 1 170 331 1 173 331 minecraft:honeycomb_block
setblock 1 170 335 minecraft:yellow_terracotta
fill 1 170 336 1 173 336 minecraft:honeycomb_block
setblock 1 170 340 minecraft:yellow_terracotta
fill 1 170 341 1 173 341 minecraft:honeycomb_block
setblock 1 170 345 minecraft:yellow_terracotta
fill 1 170 346 1 173 346 minecraft:honeycomb_block
setblock 1 170 350 minecraft:yellow_terracotta
fill 1 170 351 1 173 351 minecraft:honeycomb_block
setblock 1 170 355 minecraft:yellow_terracotta
fill 1 170 356 1 171 356 minecraft:honeycomb_block
setblock 1 170 360 minecraft:yellow_terracotta
fill 1 170 361 1 172 361 minecraft:honeycomb_block
setblock 2 170 323 minecraft:honeycomb_block
setblock 2 170 324 minecraft:yellow_terracotta
fill 2 170 325 5 170 325 minecraft:honeycomb_block
setblock 2 170 328 minecraft:honeycomb_block
setblock 2 170 329 minecraft:yellow_terracotta
setblock 2 170 334 minecraft:yellow_terracotta
fill 2 170 335 2 173 335 minecraft:honeycomb_block
setblock 2 170 339 minecraft:yellow_terracotta
fill 2 170 340 2 173 340 minecraft:honeycomb_block
setblock 2 170 344 minecraft:yellow_terracotta
fill 2 170 345 2 173 345 minecraft:honeycomb_block
setblock 2 170 348 minecraft:honeycomb_block
setblock 2 170 349 minecraft:yellow_terracotta
fill 2 170 350 2 173 350 minecraft:honeycomb_block
setblock 3 170 323 minecraft:yellow_terracotta
fill 3 170 324 6 170 324 minecraft:honeycomb_block
setblock 3 170 332 minecraft:light[level=12]
setblock 3 170 338 minecraft:yellow_terracotta
fill 3 170 339 3 173 339 minecraft:honeycomb_block
setblock 3 170 343 minecraft:yellow_terracotta
fill 3 170 344 3 173 344 minecraft:honeycomb_block
setblock 3 170 348 minecraft:yellow_terracotta
fill 3 170 349 3 173 349 minecraft:honeycomb_block
setblock 3 170 353 minecraft:light[level=12]
setblock 3 170 360 minecraft:light[level=12]
setblock 3 170 363 minecraft:yellow_terracotta
fill 4 170 323 4 173 323 minecraft:honeycomb_block
setblock 4 170 342 minecraft:yellow_terracotta
fill 4 170 343 4 172 343 minecraft:honeycomb_block
setblock 4 170 347 minecraft:yellow_terracotta
setblock 4 170 348 minecraft:honeycomb_block
setblock 4 170 362 minecraft:yellow_terracotta
fill 4 170 363 4 173 363 minecraft:honeycomb_block
setblock 5 170 342 minecraft:honeycomb_block
fill 5 170 362 5 171 362 minecraft:honeycomb_block
setblock 6 170 325 minecraft:yellow_terracotta
setblock 7 170 324 minecraft:yellow_terracotta
fill 7 170 325 7 173 325 minecraft:honeycomb_block
setblock 8 170 323 minecraft:yellow_terracotta
fill 8 170 324 8 173 324 minecraft:honeycomb_block
setblock 8 170 363 minecraft:yellow_terracotta
fill 9 170 323 12 170 323 minecraft:honeycomb_block
fill 9 170 363 9 172 363 minecraft:honeycomb_block
setblock 10 170 332 minecraft:light[level=12]
setblock 10 170 339 minecraft:light[level=12]
setblock 10 170 346 minecraft:light[level=12]
setblock 10 170 353 minecraft:light[level=12]
setblock 10 170 360 minecraft:light[level=12]
setblock 12 170 324 minecraft:yellow_terracotta
setblock 13 170 323 minecraft:yellow_terracotta
fill 13 170 324 16 170 324 minecraft:honeycomb_block
setblock 13 170 363 minecraft:yellow_terracotta
fill 14 170 323 14 173 323 minecraft:honeycomb_block
setblock 14 170 363 minecraft:honeycomb_block
fill 15 170 325 17 170 325 minecraft:honey_block
setblock 17 170 324 minecraft:yellow_terracotta
setblock 17 170 332 minecraft:light[level=12]
setblock 17 170 339 minecraft:light[level=12]
setblock 17 170 346 minecraft:light[level=12]
setblock 17 170 353 minecraft:light[level=12]
setblock 17 170 360 minecraft:light[level=12]
setblock 18 170 323 minecraft:yellow_terracotta
fill 18 170 324 18 172 325 minecraft:honeycomb_block
setblock 18 170 363 minecraft:yellow_terracotta
fill 19 170 323 19 173 323 minecraft:honeycomb_block
setblock 19 170 362 minecraft:yellow_terracotta
fill 19 170 363 19 173 363 minecraft:honeycomb_block
fill 20 170 362 20 173 362 minecraft:honeycomb_block
setblock 21 170 324 minecraft:honeycomb_block
setblock 21 170 325 minecraft:yellow_terracotta
setblock 22 170 324 minecraft:yellow_terracotta
fill 22 170 325 22 172 326 minecraft:honeycomb_block
setblock 23 170 323 minecraft:yellow_terracotta
fill 23 170 324 23 173 324 minecraft:honeycomb_block
setblock 23 170 363 minecraft:yellow_terracotta
fill 24 170 323 24 173 323 minecraft:honeycomb_block
setblock 24 170 326 minecraft:honeycomb_block
setblock 24 170 332 minecraft:light[level=12]
setblock 24 170 339 minecraft:light[level=12]
setblock 24 170 346 minecraft:light[level=12]
setblock 24 170 353 minecraft:light[level=12]
setblock 24 170 360 minecraft:light[level=12]
setblock 24 170 362 minecraft:yellow_terracotta
fill 24 170 363 24 173 363 minecraft:honeycomb_block
setblock 25 170 326 minecraft:yellow_terracotta
setblock 25 170 361 minecraft:yellow_terracotta
fill 25 170 362 25 173 362 minecraft:honeycomb_block
setblock 26 170 325 minecraft:yellow_terracotta
setblock 26 170 326 minecraft:honeycomb_block
fill 26 170 361 26 172 361 minecraft:honeycomb_block
setblock 27 170 324 minecraft:yellow_terracotta
fill 27 170 325 27 173 325 minecraft:honeycomb_block
setblock 28 170 323 minecraft:yellow_terracotta
fill 28 170 324 28 173 324 minecraft:honeycomb_block
setblock 28 170 363 minecraft:yellow_terracotta
fill 29 170 323 29 173 323 minecraft:honeycomb_block
setblock 29 170 362 minecraft:yellow_terracotta
fill 29 170 363 29 173 363 minecraft:honeycomb_block
setblock 30 170 361 minecraft:yellow_terracotta
fill 30 170 362 30 172 362 minecraft:honeycomb_block
setblock 31 170 325 minecraft:light[level=12]
setblock 31 170 332 minecraft:light[level=12]
setblock 31 170 339 minecraft:light[level=12]
setblock 31 170 346 minecraft:light[level=12]
setblock 31 170 353 minecraft:light[level=12]
setblock 31 170 360 minecraft:light[level=12]
setblock 31 170 361 minecraft:honeycomb_block
setblock 32 170 324 minecraft:yellow_terracotta
setblock 33 170 323 minecraft:yellow_terracotta
setblock 33 170 363 minecraft:yellow_terracotta
fill 34 170 323 37 170 323 minecraft:honeycomb_block
setblock 34 170 362 minecraft:yellow_terracotta
fill 34 170 363 34 173 363 minecraft:honeycomb_block
setblock 35 170 362 minecraft:honeycomb_block
setblock 38 170 323 minecraft:yellow_terracotta
setblock 38 170 325 minecraft:light[level=12]
setblock 38 170 332 minecraft:light[level=12]
setblock 38 170 339 minecraft:light[level=12]
setblock 38 170 346 minecraft:light[level=12]
setblock 38 170 353 minecraft:light[level=12]
setblock 38 170 360 minecraft:light[level=12]
setblock 38 170 363 minecraft:yellow_terracotta
fill 39 170 322 39 173 323 minecraft:honeycomb_block
fill 39 170 345 39 170 346 minecraft:honeycomb_block
setblock 39 170 362 minecraft:yellow_terracotta
fill 39 170 363 39 173 363 minecraft:honeycomb_block
setblock 40 170 340 minecraft:honeycomb_block
setblock 40 170 341 minecraft:yellow_terracotta
fill 40 170 342 40 173 342 minecraft:honeycomb_block
setblock 40 170 345 minecraft:honeycomb_block
setblock 40 170 346 minecraft:yellow_terracotta
fill 40 170 347 40 173 347 minecraft:honeycomb_block
setblock 40 170 350 minecraft:honeycomb_block
setblock 40 170 351 minecraft:yellow_terracotta
fill 40 170 352 40 173 352 minecraft:honeycomb_block
setblock 40 170 361 minecraft:yellow_terracotta
fill 40 170 362 40 172 362 minecraft:honeycomb_block
setblock 41 170 325 minecraft:yellow_terracotta
fill 41 170 326 41 173 326 minecraft:honeycomb_block
setblock 41 170 340 minecraft:yellow_terracotta
fill 41 170 341 41 173 341 minecraft:honeycomb_block
setblock 41 170 345 minecraft:yellow_terracotta
fill 41 170 346 41 173 346 minecraft:honeycomb_block
setblock 41 170 350 minecraft:yellow_terracotta
fill 41 170 351 41 173 351 minecraft:honeycomb_block
setblock 41 170 355 minecraft:yellow_terracotta
fill 41 170 356 41 173 356 minecraft:honeycomb_block
setblock 41 170 360 minecraft:yellow_terracotta
fill 41 170 361 41 173 361 minecraft:honeycomb_block
setblock 42 170 324 minecraft:yellow_concrete
fill 0 171 335 1 174 335 minecraft:honeycomb_block
fill 0 171 339 0 296 339 minecraft:honeycomb_block
setblock 1 171 323 minecraft:honeycomb_block
setblock 1 171 324 minecraft:yellow_terracotta
fill 1 171 325 4 171 325 minecraft:honeycomb_block
setblock 1 171 329 minecraft:yellow_terracotta
fill 1 171 330 2 173 330 minecraft:honeycomb_block
setblock 1 171 334 minecraft:yellow_terracotta
setblock 1 171 339 minecraft:yellow_terracotta
fill 1 171 340 1 174 340 minecraft:honeycomb_block
setblock 1 171 344 minecraft:yellow_terracotta
fill 1 171 345 1 174 345 minecraft:honeycomb_block
setblock 1 171 349 minecraft:yellow_terracotta
fill 1 171 350 1 174 350 minecraft:honeycomb_block
setblock 1 171 354 minecraft:yellow_terracotta
fill 1 171 355 1 172 355 minecraft:honeycomb_block
setblock 1 171 359 minecraft:yellow_terracotta
setblock 1 171 360 minecraft:honeycomb_block
setblock 2 171 323 minecraft:yellow_terracotta
fill 2 171 324 5 171 324 minecraft:honeycomb_block
setblock 2 171 328 minecraft:yellow_terracotta
fill 2 171 329 2 174 329 minecraft:honeycomb_block
fill 2 171 331 2 172 331 minecraft:honeycomb_block
fill 2 171 334 2 174 334 minecraft:honeycomb_block
setblock 2 171 338 minecraft:yellow_terracotta
fill 2 171 339 2 174 339 minecraft:honeycomb_block
setblock 2 171 343 minecraft:yellow_terracotta
fill 2 171 344 2 174 344 minecraft:honeycomb_block
setblock 2 171 348 minecraft:yellow_terracotta
fill 2 171 349 2 174 349 minecraft:honeycomb_block
setblock 2 171 363 minecraft:yellow_terracotta
fill 3 171 323 3 174 323 minecraft:honeycomb_block
setblock 3 171 326 minecraft:honeycomb_block
setblock 3 171 337 minecraft:yellow_terracotta
fill 3 171 338 3 172 338 minecraft:honeycomb_block
setblock 3 171 342 minecraft:yellow_terracotta
fill 3 171 343 3 174 343 minecraft:honeycomb_block
setblock 3 171 347 minecraft:yellow_terracotta
fill 3 171 348 3 174 348 minecraft:honeycomb_block
setblock 3 171 362 minecraft:yellow_terracotta
fill 3 171 363 3 174 363 minecraft:honeycomb_block
setblock 4 171 341 minecraft:yellow_terracotta
fill 4 171 342 4 172 342 minecraft:honeycomb_block
setblock 4 171 346 minecraft:yellow_terracotta
fill 4 171 347 4 172 347 minecraft:honeycomb_block
setblock 4 171 362 minecraft:honeycomb_block
setblock 5 171 325 minecraft:yellow_terracotta
setblock 6 171 324 minecraft:yellow_terracotta
fill 6 171 325 6 174 325 minecraft:honeycomb_block
setblock 7 171 323 minecraft:yellow_terracotta
fill 7 171 324 7 174 324 minecraft:honeycomb_block
setblock 7 171 363 minecraft:yellow_terracotta
fill 8 171 323 11 171 323 minecraft:honeycomb_block
fill 8 171 363 8 172 363 minecraft:honeycomb_block
setblock 9 171 325 minecraft:honeycomb_block
setblock 11 171 324 minecraft:yellow_terracotta
setblock 12 171 323 minecraft:yellow_terracotta
fill 12 171 324 15 171 324 minecraft:honeycomb_block
fill 13 171 323 13 174 323 minecraft:honeycomb_block
setblock 16 171 324 minecraft:yellow_terracotta
setblock 17 171 323 minecraft:yellow_terracotta
fill 17 171 324 17 174 324 minecraft:honeycomb_block
setblock 17 171 363 minecraft:yellow_terracotta
fill 18 171 323 18 174 323 minecraft:honeycomb_block
fill 18 171 363 18 174 363 minecraft:honeycomb_block
setblock 19 171 362 minecraft:honeycomb_block
setblock 20 171 324 minecraft:honeycomb_block
setblock 20 171 325 minecraft:yellow_terracotta
setblock 21 171 324 minecraft:yellow_terracotta
fill 21 171 325 21 174 325 minecraft:honeycomb_block
setblock 22 171 323 minecraft:yellow_terracotta
fill 22 171 324 22 174 324 minecraft:honeycomb_block
setblock 22 171 363 minecraft:yellow_terracotta
fill 23 171 323 23 174 323 minecraft:honeycomb_block
setblock 23 171 362 minecraft:yellow_terracotta
fill 23 171 363 23 174 363 minecraft:honeycomb_block
setblock 24 171 326 minecraft:yellow_terracotta
setblock 24 171 361 minecraft:yellow_terracotta
fill 24 171 362 24 174 362 minecraft:honeycomb_block
setblock 25 171 325 minecraft:yellow_terracotta
setblock 25 171 326 minecraft:honeycomb_block
fill 25 171 361 25 172 361 minecraft:honeycomb_block
setblock 26 171 324 minecraft:yellow_terracotta
fill 26 171 325 26 174 325 minecraft:honeycomb_block
setblock 27 171 323 minecraft:yellow_terracotta
fill 27 171 324 27 174 324 minecraft:honeycomb_block
setblock 27 171 363 minecraft:yellow_terracotta
fill 28 171 323 28 174 323 minecraft:honeycomb_block
setblock 28 171 362 minecraft:yellow_terracotta
fill 28 171 363 28 174 363 minecraft:honeycomb_block
setblock 29 171 361 minecraft:yellow_terracotta
fill 29 171 362 29 173 362 minecraft:honeycomb_block
setblock 31 171 324 minecraft:yellow_terracotta
setblock 32 171 323 minecraft:yellow_terracotta
setblock 32 171 324 minecraft:honeycomb_block
setblock 32 171 363 minecraft:yellow_terracotta
fill 33 171 323 36 171 323 minecraft:honeycomb_block
setblock 33 171 362 minecraft:yellow_terracotta
fill 33 171 363 33 173 363 minecraft:honeycomb_block
setblock 34 171 362 minecraft:honeycomb_block
setblock 37 171 323 minecraft:yellow_terracotta
setblock 37 171 363 minecraft:yellow_terracotta
fill 38 171 323 38 174 323 minecraft:honeycomb_block
setblock 38 171 362 minecraft:yellow_terracotta
fill 38 171 363 38 174 363 minecraft:honeycomb_block
fill 39 171 344 39 171 345 minecraft:honeycomb_block
setblock 39 171 346 minecraft:yellow_terracotta
fill 39 171 347 39 174 347 minecraft:honeycomb_block
setblock 39 171 362 minecraft:honeycomb_block
setblock 40 171 340 minecraft:yellow_terracotta
fill 40 171 341 40 174 341 minecraft:honeycomb_block
setblock 40 171 345 minecraft:yellow_terracotta
fill 40 171 346 40 174 346 minecraft:honeycomb_block
setblock 40 171 350 minecraft:yellow_terracotta
fill 40 171 351 40 174 351 minecraft:honeycomb_block
fill 40 171 353 40 172 353 minecraft:honeycomb_block
setblock 40 171 360 minecraft:yellow_terracotta
setblock 40 171 361 minecraft:honeycomb_block
setblock 41 171 324 minecraft:yellow_terracotta
fill 41 171 325 41 174 325 minecraft:honeycomb_block
setblock 41 171 328 minecraft:honeycomb_block
setblock 41 171 339 minecraft:yellow_terracotta
fill 41 171 340 41 174 340 minecraft:honeycomb_block
setblock 41 171 344 minecraft:yellow_terracotta
fill 41 171 345 41 174 345 minecraft:honeycomb_block
setblock 41 171 349 minecraft:yellow_terracotta
fill 41 171 350 41 174 350 minecraft:honeycomb_block
setblock 41 171 354 minecraft:yellow_terracotta
fill 41 171 355 41 174 355 minecraft:honeycomb_block
setblock 41 171 359 minecraft:yellow_terracotta
fill 41 171 360 41 174 360 minecraft:honeycomb_block
fill 42 171 324 42 172 324 minecraft:honeycomb_block
setblock 0 172 327 minecraft:yellow_terracotta
setblock 0 172 329 minecraft:yellow_concrete
setblock 1 172 323 minecraft:yellow_terracotta
fill 1 172 324 3 172 325 minecraft:honeycomb_block
setblock 1 172 327 minecraft:honeycomb_block
setblock 1 172 328 minecraft:yellow_terracotta
fill 1 172 329 1 175 329 minecraft:honeycomb_block
setblock 1 172 333 minecraft:yellow_terracotta
fill 1 172 334 1 175 334 minecraft:honeycomb_block
setblock 1 172 338 minecraft:yellow_terracotta
fill 1 172 339 1 175 339 minecraft:honeycomb_block
setblock 1 172 343 minecraft:yellow_terracotta
fill 1 172 344 1 175 344 minecraft:honeycomb_block
setblock 1 172 348 minecraft:yellow_terracotta
fill 1 172 349 1 175 349 minecraft:honeycomb_block
setblock 1 172 353 minecraft:yellow_terracotta
fill 1 172 354 1 175 354 minecraft:honeycomb_block
setblock 1 172 363 minecraft:yellow_terracotta
fill 2 172 323 2 175 323 minecraft:honeycomb_block
setblock 2 172 327 minecraft:yellow_terracotta
fill 2 172 328 2 175 328 minecraft:honeycomb_block
setblock 2 172 332 minecraft:yellow_terracotta
fill 2 172 333 2 175 333 minecraft:honeycomb_block
setblock 2 172 337 minecraft:yellow_terracotta
fill 2 172 338 2 175 338 minecraft:honeycomb_block
setblock 2 172 342 minecraft:yellow_terracotta
fill 2 172 343 2 175 343 minecraft:honeycomb_block
setblock 2 172 347 minecraft:yellow_terracotta
fill 2 172 348 2 175 348 minecraft:honeycomb_block
setblock 2 172 352 minecraft:yellow_terracotta
fill 2 172 363 2 174 363 minecraft:honeycomb_block
setblock 3 172 326 minecraft:yellow_terracotta
fill 3 172 327 3 175 327 minecraft:honeycomb_block
setblock 3 172 341 minecraft:yellow_terracotta
fill 3 172 342 3 175 342 minecraft:honeycomb_block
setblock 3 172 346 minecraft:yellow_terracotta
fill 3 172 347 3 175 347 minecraft:honeycomb_block
setblock 4 172 324 minecraft:honeycomb_block
setblock 4 172 325 minecraft:yellow_terracotta
setblock 4 172 341 minecraft:honeycomb_block
setblock 4 172 345 minecraft:yellow_terracotta
fill 4 172 346 4 173 346 minecraft:honeycomb_block
setblock 5 172 324 minecraft:yellow_terracotta
fill 5 172 325 5 174 325 minecraft:honeycomb_block
setblock 6 172 323 minecraft:yellow_terracotta
fill 6 172 324 6 175 324 minecraft:honeycomb_block
setblock 6 172 363 minecraft:yellow_terracotta
fill 7 172 323 10 172 323 minecraft:honeycomb_block
setblock 7 172 363 minecraft:honeycomb_block
setblock 10 172 324 minecraft:yellow_terracotta
setblock 10 172 364 minecraft:orange_terracotta
setblock 11 172 323 minecraft:yellow_terracotta
fill 11 172 324 14 172 324 minecraft:honeycomb_block
fill 12 172 323 12 175 323 minecraft:honeycomb_block
setblock 14 172 363 minecraft:honey_block
setblock 15 172 324 minecraft:yellow_terracotta
setblock 16 172 323 minecraft:yellow_terracotta
fill 16 172 324 16 175 324 minecraft:honeycomb_block
setblock 16 172 363 minecraft:yellow_terracotta
fill 17 172 323 17 175 323 minecraft:honeycomb_block
fill 17 172 325 17 173 325 minecraft:honeycomb_block
fill 17 172 363 17 175 363 minecraft:honeycomb_block
setblock 19 172 324 minecraft:honeycomb_block
setblock 19 172 325 minecraft:yellow_terracotta
setblock 20 172 324 minecraft:yellow_terracotta
fill 20 172 325 20 175 325 minecraft:honeycomb_block
setblock 21 172 323 minecraft:yellow_terracotta
fill 21 172 324 21 175 324 minecraft:honeycomb_block
setblock 21 172 363 minecraft:yellow_terracotta
fill 22 172 323 22 175 323 minecraft:honeycomb_block
fill 22 172 361 22 172 362 minecraft:yellow_terracotta
fill 22 172 363 22 175 363 minecraft:honeycomb_block
setblock 23 172 325 minecraft:honeycomb_block
setblock 23 172 326 minecraft:yellow_terracotta
setblock 23 172 361 minecraft:yellow_terracotta
fill 23 172 362 23 175 362 minecraft:honeycomb_block
setblock 24 172 325 minecraft:yellow_terracotta
setblock 24 172 326 minecraft:honeycomb_block
setblock 24 172 361 minecraft:honeycomb_block
setblock 25 172 324 minecraft:yellow_terracotta
fill 25 172 325 25 175 325 minecraft:honeycomb_block
setblock 26 172 323 minecraft:yellow_terracotta
fill 26 172 324 26 175 324 minecraft:honeycomb_block
setblock 26 172 363 minecraft:yellow_terracotta
fill 27 172 323 27 175 323 minecraft:honeycomb_block
setblock 27 172 362 minecraft:yellow_terracotta
fill 27 172 363 27 175 363 minecraft:honeycomb_block
fill 28 172 362 28 173 362 minecraft:honeycomb_block
setblock 30 172 324 minecraft:yellow_terracotta
setblock 31 172 323 minecraft:yellow_terracotta
setblock 31 172 324 minecraft:honeycomb_block
setblock 31 172 363 minecraft:yellow_terracotta
fill 32 172 323 35 172 323 minecraft:honeycomb_block
fill 32 172 363 32 173 363 minecraft:honeycomb_block
setblock 36 172 323 minecraft:yellow_terracotta
setblock 36 172 363 minecraft:yellow_terracotta
fill 37 172 323 37 173 323 minecraft:honeycomb_block
fill 37 172 363 37 174 363 minecraft:honeycomb_block
setblock 39 172 345 minecraft:yellow_terracotta
fill 39 172 346 39 175 346 minecraft:honeycomb_block
fill 39 172 348 39 173 348 minecraft:honeycomb_block
setblock 40 172 344 minecraft:yellow_terracotta
fill 40 172 345 40 175 345 minecraft:honeycomb_block
setblock 40 172 349 minecraft:yellow_terracotta
fill 40 172 350 40 175 350 minecraft:honeycomb_block
setblock 41 172 323 minecraft:yellow_terracotta
fill 41 172 324 41 175 324 minecraft:honeycomb_block
setblock 41 172 328 minecraft:yellow_terracotta
fill 41 172 329 41 175 329 minecraft:honeycomb_block
setblock 41 172 335 minecraft:honey_block
setblock 41 172 338 minecraft:yellow_terracotta
fill 41 172 339 41 175 339 minecraft:honeycomb_block
setblock 41 172 343 minecraft:yellow_terracotta
fill 41 172 344 41 175 344 minecraft:honeycomb_block
setblock 41 172 348 minecraft:yellow_terracotta
fill 41 172 349 41 175 349 minecraft:honeycomb_block
setblock 41 172 353 minecraft:yellow_terracotta
fill 41 172 354 41 175 354 minecraft:honeycomb_block
setblock 41 172 358 minecraft:yellow_terracotta
fill 41 172 359 41 175 359 minecraft:honeycomb_block
setblock 41 172 363 minecraft:yellow_terracotta
setblock 42 172 361 minecraft:yellow_concrete
fill 0 173 327 0 224 327 minecraft:honeycomb_block
fill 0 173 329 0 287 329 minecraft:honeycomb_block
setblock 0 173 342 minecraft:yellow_concrete
fill 1 173 323 1 174 325 minecraft:honeycomb_block
setblock 1 173 327 minecraft:yellow_terracotta
fill 1 173 328 1 176 328 minecraft:honeycomb_block
setblock 1 173 332 minecraft:yellow_terracotta
fill 1 173 333 1 176 333 minecraft:honeycomb_block
setblock 1 173 337 minecraft:yellow_terracotta
fill 1 173 338 1 176 338 minecraft:honeycomb_block
setblock 1 173 342 minecraft:yellow_terracotta
fill 1 173 343 1 176 343 minecraft:honeycomb_block
setblock 1 173 347 minecraft:yellow_terracotta
fill 1 173 348 1 176 348 minecraft:honeycomb_block
setblock 1 173 352 minecraft:yellow_terracotta
fill 1 173 353 1 176 353 minecraft:honeycomb_block
setblock 1 173 357 minecraft:honey_block
setblock 1 173 362 minecraft:yellow_terracotta
fill 1 173 363 1 174 363 minecraft:honeycomb_block
fill 2 173 324 2 173 325 minecraft:honeycomb_block
setblock 2 173 326 minecraft:yellow_terracotta
fill 2 173 327 2 176 327 minecraft:honeycomb_block
setblock 2 173 331 minecraft:yellow_terracotta
fill 2 173 332 2 176 332 minecraft:honeycomb_block
setblock 2 173 336 minecraft:yellow_terracotta
fill 2 173 337 2 176 337 minecraft:honeycomb_block
setblock 2 173 341 minecraft:yellow_terracotta
fill 2 173 342 2 176 342 minecraft:honeycomb_block
setblock 2 173 346 minecraft:yellow_terracotta
fill 2 173 347 2 176 347 minecraft:honeycomb_block
setblock 2 173 351 minecraft:yellow_terracotta
fill 2 173 352 2 176 352 minecraft:honeycomb_block
setblock 3 173 324 minecraft:honeycomb_block
setblock 3 173 325 minecraft:yellow_terracotta
fill 3 173 326 3 176 326 minecraft:honeycomb_block
fill 3 173 328 3 174 328 minecraft:honeycomb_block
setblock 3 173 340 minecraft:yellow_terracotta
fill 3 173 341 3 174 341 minecraft:honeycomb_block
setblock 3 173 345 minecraft:yellow_terracotta
fill 3 173 346 3 176 346 minecraft:honeycomb_block
setblock 3 173 350 minecraft:yellow_terracotta
setblock 4 173 324 minecraft:yellow_terracotta
fill 4 173 325 4 176 325 minecraft:honeycomb_block
fill 4 173 341 4 174 341 minecraft:flowering_azalea_leaves[persistent=true]
setblock 4 173 344 minecraft:yellow_terracotta
setblock 4 173 345 minecraft:honeycomb_block
setblock 5 173 323 minecraft:yellow_terracotta
fill 5 173 324 5 176 324 minecraft:honeycomb_block
setblock 5 173 363 minecraft:yellow_terracotta
fill 6 173 323 9 173 323 minecraft:honeycomb_block
setblock 6 173 363 minecraft:honeycomb_block
setblock 9 173 324 minecraft:yellow_terracotta
setblock 10 173 323 minecraft:yellow_terracotta
fill 10 173 324 13 173 324 minecraft:honeycomb_block
fill 10 173 364 10 308 364 minecraft:honeycomb_block
fill 11 173 323 11 176 323 minecraft:honeycomb_block
setblock 14 173 324 minecraft:yellow_terracotta
setblock 15 173 323 minecraft:yellow_terracotta
fill 15 173 324 15 176 324 minecraft:honeycomb_block
fill 16 173 323 16 176 323 minecraft:honeycomb_block
setblock 18 173 324 minecraft:honeycomb_block
setblock 18 173 325 minecraft:yellow_terracotta
setblock 19 173 324 minecraft:yellow_terracotta
fill 19 173 325 19 176 325 minecraft:honeycomb_block
setblock 20 173 323 minecraft:yellow_terracotta
fill 20 173 324 20 176 324 minecraft:honeycomb_block
setblock 20 173 363 minecraft:yellow_terracotta
fill 21 173 323 21 176 323 minecraft:honeycomb_block
setblock 21 173 362 minecraft:yellow_terracotta
fill 21 173 363 21 176 363 minecraft:honeycomb_block
setblock 22 173 325 minecraft:honeycomb_block
setblock 22 173 326 minecraft:yellow_terracotta
fill 22 173 361 22 202 361 minecraft:yellow_terracotta
fill 22 173 362 22 176 362 minecraft:honeycomb_block
setblock 23 173 325 minecraft:yellow_terracotta
setblock 23 173 326 minecraft:honeycomb_block
setblock 24 173 324 minecraft:yellow_terracotta
fill 24 173 325 24 176 325 minecraft:honeycomb_block
setblock 25 173 323 minecraft:yellow_terracotta
fill 25 173 324 25 176 324 minecraft:honeycomb_block
fill 25 173 363 25 173 364 minecraft:yellow_terracotta
fill 26 173 323 26 176 323 minecraft:honeycomb_block
setblock 26 173 362 minecraft:yellow_terracotta
fill 26 173 363 26 176 363 minecraft:honeycomb_block
fill 27 173 362 27 174 362 minecraft:honeycomb_block
setblock 29 173 324 minecraft:yellow_terracotta
setblock 30 173 322 minecraft:yellow_concrete
setblock 30 173 323 minecraft:yellow_terracotta
setblock 30 173 363 minecraft:yellow_terracotta
fill 31 173 323 33 173 323 minecraft:honeycomb_block
fill 31 173 363 31 174 363 minecraft:honeycomb_block
setblock 35 173 363 minecraft:yellow_terracotta
setblock 36 173 363 minecraft:honeycomb_block
fill 39 173 345 39 176 345 minecraft:honeycomb_block
setblock 39 173 349 minecraft:yellow_terracotta
setblock 40 173 323 minecraft:yellow_terracotta
setblock 40 173 343 minecraft:yellow_terracotta
fill 40 173 344 40 176 344 minecraft:honeycomb_block
setblock 40 173 348 minecraft:yellow_terracotta
fill 40 173 349 40 176 349 minecraft:honeycomb_block
setblock 40 173 353 minecraft:yellow_terracotta
setblock 40 173 363 minecraft:yellow_terracotta
fill 41 173 323 41 176 323 minecraft:honeycomb_block
setblock 41 173 327 minecraft:yellow_terracotta
fill 41 173 328 41 176 328 minecraft:honeycomb_block
fill 41 173 330 41 174 330 minecraft:honeycomb_block
setblock 41 173 337 minecraft:yellow_terracotta
fill 41 173 338 41 176 338 minecraft:honeycomb_block
setblock 41 173 342 minecraft:yellow_terracotta
fill 41 173 343 41 176 343 minecraft:honeycomb_block
setblock 41 173 347 minecraft:yellow_terracotta
fill 41 173 348 41 176 348 minecraft:honeycomb_block
setblock 41 173 352 minecraft:yellow_terracotta
fill 41 173 353 41 176 353 minecraft:honeycomb_block
setblock 41 173 357 minecraft:yellow_terracotta
fill 41 173 358 41 176 358 minecraft:honeycomb_block
setblock 41 173 362 minecraft:yellow_terracotta
fill 41 173 363 41 176 363 minecraft:honeycomb_block
setblock 42 173 324 minecraft:yellow_concrete
fill 42 173 357 42 308 357 minecraft:honeycomb_block
fill 42 173 361 42 192 361 minecraft:honeycomb_block
setblock 0 174 336 minecraft:orange_terracotta
fill 0 174 337 1 177 337 minecraft:honeycomb_block
fill 0 174 342 1 177 342 minecraft:honeycomb_block
setblock 1 174 326 minecraft:yellow_terracotta
fill 1 174 327 1 177 327 minecraft:honeycomb_block
setblock 1 174 330 minecraft:honeycomb_block
setblock 1 174 331 minecraft:yellow_terracotta
fill 1 174 332 1 177 332 minecraft:honeycomb_block
setblock 1 174 336 minecraft:yellow_terracotta
setblock 1 174 341 minecraft:yellow_terracotta
setblock 1 174 346 minecraft:yellow_terracotta
fill 1 174 347 1 177 347 minecraft:honeycomb_block
setblock 1 174 351 minecraft:yellow_terracotta
fill 1 174 352 1 177 352 minecraft:honeycomb_block
setblock 2 174 324 minecraft:honeycomb_block
setblock 2 174 325 minecraft:yellow_terracotta
fill 2 174 326 2 177 326 minecraft:honeycomb_block
setblock 2 174 330 minecraft:yellow_terracotta
fill 2 174 331 2 177 331 minecraft:honeycomb_block
setblock 2 174 335 minecraft:yellow_terracotta
fill 2 174 336 2 177 336 minecraft:honeycomb_block
setblock 2 174 340 minecraft:yellow_terracotta
fill 2 174 341 2 177 341 minecraft:honeycomb_block
setblock 2 174 345 minecraft:yellow_terracotta
fill 2 174 346 2 177 346 minecraft:honeycomb_block
setblock 2 174 350 minecraft:yellow_terracotta
fill 2 174 351 2 177 351 minecraft:honeycomb_block
setblock 3 174 324 minecraft:yellow_terracotta
fill 3 174 325 3 177 325 minecraft:honeycomb_block
setblock 3 174 329 minecraft:yellow_terracotta
setblock 3 174 344 minecraft:yellow_terracotta
fill 3 174 345 3 177 345 minecraft:honeycomb_block
setblock 3 174 349 minecraft:yellow_terracotta
setblock 4 174 323 minecraft:yellow_terracotta
fill 4 174 324 4 177 324 minecraft:honeycomb_block
setblock 4 174 363 minecraft:yellow_terracotta
fill 5 174 323 8 174 323 minecraft:honeycomb_block
setblock 8 174 324 minecraft:yellow_terracotta
setblock 9 174 323 minecraft:yellow_terracotta
fill 9 174 324 10 174 324 minecraft:honeycomb_block
fill 10 174 323 10 177 323 minecraft:honeycomb_block
setblock 13 174 324 minecraft:yellow_terracotta
setblock 14 174 323 minecraft:yellow_terracotta
fill 14 174 324 14 177 324 minecraft:honeycomb_block
fill 15 174 323 15 177 323 minecraft:honeycomb_block
setblock 17 174 325 minecraft:yellow_terracotta
setblock 18 174 324 minecraft:yellow_terracotta
fill 18 174 325 18 177 325 minecraft:honeycomb_block
setblock 19 174 323 minecraft:yellow_terracotta
fill 19 174 324 19 177 324 minecraft:honeycomb_block
setblock 19 174 363 minecraft:yellow_terracotta
fill 20 174 323 20 177 323 minecraft:honeycomb_block
setblock 20 174 362 minecraft:yellow_terracotta
fill 20 174 363 20 177 363 minecraft:honeycomb_block
fill 21 174 362 21 177 362 minecraft:honeycomb_block
setblock 22 174 325 minecraft:yellow_terracotta
setblock 23 174 324 minecraft:yellow_terracotta
fill 23 174 325 23 177 325 minecraft:honeycomb_block
setblock 24 174 323 minecraft:yellow_terracotta
fill 24 174 324 24 177 324 minecraft:honeycomb_block
setblock 24 174 363 minecraft:yellow_terracotta
fill 25 174 323 25 177 323 minecraft:honeycomb_block
setblock 25 174 362 minecraft:yellow_terracotta
fill 25 174 363 25 177 364 minecraft:honeycomb_block
fill 26 174 362 26 175 362 minecraft:honeycomb_block
setblock 28 174 324 minecraft:yellow_terracotta
setblock 29 174 323 minecraft:yellow_terracotta
setblock 29 174 363 minecraft:yellow_terracotta
fill 30 174 322 30 175 323 minecraft:honeycomb_block
fill 30 174 363 30 175 363 minecraft:honeycomb_block
setblock 31 174 323 minecraft:honeycomb_block
fill 35 174 323 35 175 323 minecraft:honey_block
fill 38 174 342 39 175 343 minecraft:honey_block
fill 39 174 322 39 178 322 minecraft:honeycomb_block
setblock 39 174 323 minecraft:yellow_terracotta
setblock 39 174 348 minecraft:yellow_terracotta
fill 39 174 349 39 176 350 minecraft:honeycomb_block
setblock 39 174 363 minecraft:yellow_terracotta
fill 40 174 323 40 177 323 minecraft:honeycomb_block
setblock 40 174 342 minecraft:yellow_terracotta
fill 40 174 343 40 177 343 minecraft:honeycomb_block
setblock 40 174 347 minecraft:yellow_terracotta
fill 40 174 348 40 177 348 minecraft:honeycomb_block
setblock 40 174 352 minecraft:yellow_terracotta
fill 40 174 353 40 176 354 minecraft:honeycomb_block
fill 40 174 363 40 177 363 minecraft:honeycomb_block
setblock 41 174 326 minecraft:yellow_terracotta
fill 41 174 327 41 177 327 minecraft:honeycomb_block
setblock 41 174 331 minecraft:yellow_terracotta
setblock 41 174 341 minecraft:yellow_terracotta
fill 41 174 342 41 177 342 minecraft:honeycomb_block
setblock 41 174 346 minecraft:yellow_terracotta
fill 41 174 347 41 177 347 minecraft:honeycomb_block
setblock 41 174 351 minecraft:yellow_terracotta
fill 41 174 352 41 177 352 minecraft:honeycomb_block
setblock 41 174 356 minecraft:yellow_terracotta
fill 41 174 357 41 177 357 minecraft:honeycomb_block
setblock 41 174 361 minecraft:yellow_terracotta
fill 41 174 362 41 176 362 minecraft:honeycomb_block
fill 42 174 324 42 308 324 minecraft:honeycomb_block
fill 0 175 335 0 204 336 minecraft:honeycomb_block
fill 0 175 355 1 175 355 minecraft:yellow_terracotta
fill 1 175 323 1 175 324 minecraft:honeycomb_block
setblock 1 175 325 minecraft:yellow_terracotta
fill 1 175 326 1 178 326 minecraft:honeycomb_block
setblock 1 175 330 minecraft:yellow_terracotta
fill 1 175 331 1 178 331 minecraft:honeycomb_block
setblock 1 175 335 minecraft:yellow_terracotta
fill 1 175 336 1 178 336 minecraft:honeycomb_block
setblock 1 175 340 minecraft:yellow_terracotta
fill 1 175 341 1 178 341 minecraft:honeycomb_block
setblock 1 175 345 minecraft:yellow_terracotta
fill 1 175 346 1 178 346 minecraft:honeycomb_block
setblock 1 175 350 minecraft:yellow_terracotta
fill 1 175 351 1 178 351 minecraft:honeycomb_block
setblock 2 175 324 minecraft:yellow_terracotta
fill 2 175 325 2 178 325 minecraft:honeycomb_block
setblock 2 175 329 minecraft:yellow_terracotta
fill 2 175 330 3 177 330 minecraft:honeycomb_block
setblock 2 175 334 minecraft:yellow_terracotta
fill 2 175 335 2 178 335 minecraft:honeycomb_block
setblock 2 175 339 minecraft:yellow_terracotta
fill 2 175 340 2 178 340 minecraft:honeycomb_block
setblock 2 175 344 minecraft:yellow_terracotta
fill 2 175 345 2 178 345 minecraft:honeycomb_block
setblock 2 175 349 minecraft:yellow_terracotta
fill 2 175 350 2 178 350 minecraft:honeycomb_block
setblock 3 175 323 minecraft:yellow_terracotta
fill 3 175 324 3 178 324 minecraft:honeycomb_block
setblock 3 175 328 minecraft:yellow_terracotta
fill 3 175 329 3 178 329 minecraft:honeycomb_block
setblock 3 175 343 minecraft:yellow_terracotta
fill 3 175 344 3 176 344 minecraft:honeycomb_block
setblock 3 175 348 minecraft:yellow_terracotta
fill 3 175 349 3 178 349 minecraft:honeycomb_block
fill 4 175 323 7 175 323 minecraft:honeycomb_block
setblock 7 175 324 minecraft:yellow_terracotta
setblock 7 175 363 minecraft:honey_block
setblock 8 175 323 minecraft:yellow_terracotta
fill 8 175 324 9 175 324 minecraft:honeycomb_block
fill 9 175 323 9 178 323 minecraft:honeycomb_block
setblock 13 175 323 minecraft:yellow_terracotta
fill 14 175 323 14 178 323 minecraft:honeycomb_block
setblock 17 175 324 minecraft:yellow_terracotta
fill 17 175 325 17 178 325 minecraft:honeycomb_block
setblock 18 175 323 minecraft:yellow_terracotta
fill 18 175 324 18 178 324 minecraft:honeycomb_block
setblock 18 175 363 minecraft:yellow_terracotta
fill 19 175 323 19 178 323 minecraft:honeycomb_block
fill 19 175 363 19 178 363 minecraft:honeycomb_block
fill 20 175 362 20 178 362 minecraft:honeycomb_block
setblock 21 175 325 minecraft:yellow_terracotta
setblock 22 175 324 minecraft:yellow_terracotta
fill 22 175 325 22 178 325 minecraft:honeycomb_block
setblock 23 175 323 minecraft:yellow_terracotta
fill 23 175 324 23 178 324 minecraft:honeycomb_block
setblock 23 175 363 minecraft:yellow_terracotta
fill 24 175 323 24 178 323 minecraft:honeycomb_block
setblock 24 175 362 minecraft:yellow_terracotta
fill 24 175 363 24 178 363 minecraft:honeycomb_block
fill 25 175 362 25 176 362 minecraft:honeycomb_block
setblock 27 175 324 minecraft:yellow_terracotta
setblock 28 175 323 minecraft:yellow_terracotta
setblock 28 175 363 minecraft:yellow_terracotta
fill 29 175 323 29 176 323 minecraft:honeycomb_block
setblock 29 175 363 minecraft:honeycomb_block
setblock 32 175 363 minecraft:honey_block
setblock 38 175 363 minecraft:yellow_terracotta
fill 39 175 323 39 178 323 minecraft:honeycomb_block
setblock 39 175 347 minecraft:yellow_terracotta
fill 39 175 348 39 178 348 minecraft:honeycomb_block
setblock 39 175 351 minecraft:honeycomb_block
fill 39 175 363 39 178 363 minecraft:honeycomb_block
setblock 40 175 341 minecraft:yellow_terracotta
fill 40 175 342 40 178 342 minecraft:honeycomb_block
setblock 40 175 346 minecraft:yellow_terracotta
fill 40 175 347 40 178 347 minecraft:honeycomb_block
setblock 40 175 351 minecraft:yellow_terracotta
fill 40 175 352 40 178 352 minecraft:honeycomb_block
setblock 41 175 325 minecraft:yellow_terracotta
fill 41 175 326 41 178 326 minecraft:honeycomb_block
setblock 41 175 330 minecraft:yellow_terracotta
fill 41 175 331 41 176 333 minecraft:honeycomb_block
setblock 41 175 336 minecraft:honey_block
fill 41 175 337 41 177 337 minecraft:honeycomb_block
setblock 41 175 340 minecraft:yellow_terracotta
fill 41 175 341 41 178 341 minecraft:honeycomb_block
setblock 41 175 345 minecraft:yellow_terracotta
fill 41 175 346 41 178 346 minecraft:honeycomb_block
setblock 41 175 350 minecraft:yellow_terracotta
fill 41 175 351 41 178 351 minecraft:honeycomb_block
setblock 41 175 355 minecraft:yellow_terracotta
fill 41 175 356 41 178 356 minecraft:honeycomb_block
setblock 41 175 360 minecraft:yellow_terracotta
setblock 41 175 361 minecraft:honeycomb_block
setblock 42 175 348 minecraft:yellow_concrete
fill 0 176 355 1 179 355 minecraft:honeycomb_block
setblock 0 176 363 minecraft:orange_terracotta
fill 0 176 364 0 308 364 minecraft:honeycomb_block
setblock 1 176 323 minecraft:honeycomb_block
setblock 1 176 324 minecraft:yellow_terracotta
fill 1 176 325 1 179 325 minecraft:honeycomb_block
setblock 1 176 329 minecraft:yellow_terracotta
fill 1 176 330 1 179 330 minecraft:honeycomb_block
setblock 1 176 334 minecraft:yellow_terracotta
fill 1 176 335 1 179 335 minecraft:honeycomb_block
setblock 1 176 339 minecraft:yellow_terracotta
fill 1 176 340 1 179 340 minecraft:honeycomb_block
setblock 1 176 344 minecraft:yellow_terracotta
fill 1 176 345 1 179 345 minecraft:honeycomb_block
setblock 1 176 349 minecraft:yellow_terracotta
fill 1 176 350 1 179 350 minecraft:honeycomb_block
setblock 1 176 354 minecraft:yellow_terracotta
setblock 1 176 356 minecraft:honey_block
setblock 2 176 323 minecraft:yellow_terracotta
fill 2 176 324 2 179 324 minecraft:honeycomb_block
setblock 2 176 328 minecraft:yellow_terracotta
fill 2 176 329 2 179 329 minecraft:honeycomb_block
setblock 2 176 333 minecraft:yellow_terracotta
fill 2 176 334 2 179 334 minecraft:honeycomb_block
setblock 2 176 338 minecraft:yellow_terracotta
fill 2 176 339 2 179 339 minecraft:honeycomb_block
setblock 2 176 343 minecraft:yellow_terracotta
fill 2 176 344 2 179 344 minecraft:honeycomb_block
setblock 2 176 348 minecraft:yellow_terracotta
fill 2 176 349 2 179 349 minecraft:honeycomb_block
fill 3 176 323 6 176 323 minecraft:honeycomb_block
setblock 3 176 327 minecraft:yellow_terracotta
fill 3 176 328 3 179 328 minecraft:honeycomb_block
setblock 3 176 331 minecraft:honeycomb_block
setblock 3 176 332 minecraft:light[level=12]
setblock 3 176 333 minecraft:light[level=15]
setblock 3 176 339 minecraft:light[level=12]
setblock 3 176 341 minecraft:light[level=15]
setblock 3 176 347 minecraft:yellow_terracotta
fill 3 176 348 3 178 348 minecraft:honeycomb_block
setblock 3 176 353 minecraft:light[level=12]
setblock 3 176 357 minecraft:light[level=15]
setblock 3 176 360 minecraft:light[level=12]
setblock 6 176 324 minecraft:yellow_terracotta
setblock 7 176 323 minecraft:yellow_terracotta
fill 7 176 324 7 177 324 minecraft:honeycomb_block
fill 8 176 323 8 179 323 minecraft:honeycomb_block
setblock 10 176 325 minecraft:light[level=12]
setblock 10 176 332 minecraft:light[level=12]
setblock 10 176 339 minecraft:light[level=12]
setblock 10 176 346 minecraft:light[level=12]
setblock 10 176 353 minecraft:light[level=12]
setblock 10 176 360 minecraft:light[level=12]
setblock 11 176 325 minecraft:light[level=15]
setblock 11 176 333 minecraft:light[level=15]
setblock 11 176 341 minecraft:light[level=15]
setblock 11 176 349 minecraft:light[level=15]
setblock 11 176 357 minecraft:light[level=15]
setblock 12 176 323 minecraft:yellow_terracotta
fill 13 176 323 13 179 323 minecraft:honeycomb_block
setblock 13 176 363 minecraft:honey_block
setblock 16 176 324 minecraft:yellow_terracotta
setblock 17 176 323 minecraft:yellow_terracotta
fill 17 176 324 17 179 324 minecraft:honeycomb_block
setblock 17 176 332 minecraft:light[level=12]
setblock 17 176 339 minecraft:light[level=12]
setblock 17 176 346 minecraft:light[level=12]
setblock 17 176 353 minecraft:light[level=12]
setblock 17 176 360 minecraft:light[level=12]
setblock 17 176 363 minecraft:yellow_terracotta
fill 18 176 323 18 179 323 minecraft:honeycomb_block
fill 18 176 363 18 179 363 minecraft:honeycomb_block
setblock 19 176 333 minecraft:light[level=15]
setblock 19 176 341 minecraft:light[level=15]
setblock 19 176 349 minecraft:light[level=15]
setblock 19 176 357 minecraft:light[level=15]
setblock 20 176 325 minecraft:yellow_terracotta
setblock 21 176 324 minecraft:yellow_terracotta
fill 21 176 325 21 179 325 minecraft:honeycomb_block
setblock 21 176 364 minecraft:yellow_concrete
setblock 22 176 323 minecraft:yellow_terracotta
fill 22 176 324 22 179 324 minecraft:honeycomb_block
setblock 22 176 363 minecraft:yellow_terracotta
fill 23 176 323 23 179 323 minecraft:honeycomb_block
setblock 23 176 362 minecraft:yellow_terracotta
fill 23 176 363 23 179 363 minecraft:honeycomb_block
setblock 24 176 332 minecraft:light[level=12]
setblock 24 176 339 minecraft:light[level=12]
setblock 24 176 346 minecraft:light[level=12]
setblock 24 176 353 minecraft:light[level=12]
setblock 24 176 360 minecraft:light[level=12]
fill 24 176 362 24 179 362 minecraft:honeycomb_block
setblock 26 176 324 minecraft:yellow_terracotta
setblock 27 176 323 minecraft:yellow_terracotta
setblock 27 176 324 minecraft:honeycomb_block
setblock 27 176 325 minecraft:light[level=15]
setblock 27 176 333 minecraft:light[level=15]
setblock 27 176 341 minecraft:light[level=15]
setblock 27 176 349 minecraft:light[level=15]
setblock 27 176 357 minecraft:light[level=15]
setblock 27 176 363 minecraft:yellow_terracotta
fill 28 176 323 28 177 323 minecraft:honeycomb_block
fill 28 176 363 28 177 363 minecraft:honeycomb_block
fill 30 176 322 30 237 322 minecraft:honeycomb_block
setblock 31 176 325 minecraft:light[level=12]
setblock 31 176 332 minecraft:light[level=12]
setblock 31 176 339 minecraft:light[level=12]
setblock 31 176 346 minecraft:light[level=12]
setblock 31 176 353 minecraft:light[level=12]
setblock 31 176 360 minecraft:light[level=12]
setblock 35 176 325 minecraft:light[level=15]
setblock 35 176 333 minecraft:light[level=15]
setblock 35 176 341 minecraft:light[level=15]
setblock 35 176 349 minecraft:light[level=15]
setblock 35 176 357 minecraft:light[level=15]
setblock 37 176 322 minecraft:yellow_terracotta
setblock 38 176 325 minecraft:light[level=12]
setblock 38 176 332 minecraft:light[level=12]
setblock 38 176 339 minecraft:light[level=12]
setblock 38 176 346 minecraft:light[level=12]
setblock 38 176 353 minecraft:light[level=12]
setblock 38 176 360 minecraft:light[level=12]
setblock 38 176 363 minecraft:honey_block
setblock 39 176 346 minecraft:yellow_terracotta
fill 39 176 347 39 179 347 minecraft:honeycomb_block
setblock 39 176 351 minecraft:yellow_terracotta
fill 39 176 352 39 179 352 minecraft:honeycomb_block
fill 40 176 327 40 178 327 minecraft:honeycomb_block
fill 40 176 341 40 179 341 minecraft:honeycomb_block
setblock 40 176 345 minecraft:yellow_terracotta
fill 40 176 346 40 179 346 minecraft:honeycomb_block
setblock 40 176 350 minecraft:yellow_terracotta
fill 40 176 351 40 179 351 minecraft:honeycomb_block
setblock 40 176 355 minecraft:yellow_terracotta
setblock 41 176 324 minecraft:yellow_terracotta
fill 41 176 325 41 179 325 minecraft:honeycomb_block
setblock 41 176 329 minecraft:yellow_terracotta
fill 41 176 330 41 179 330 minecraft:honeycomb_block
setblock 41 176 334 minecraft:yellow_terracotta
fill 41 176 335 41 178 336 minecraft:honeycomb_block
setblock 41 176 339 minecraft:yellow_terracotta
fill 41 176 340 41 179 340 minecraft:honeycomb_block
setblock 41 176 344 minecraft:yellow_terracotta
fill 41 176 345 41 179 345 minecraft:honeycomb_block
setblock 41 176 349 minecraft:yellow_terracotta
fill 41 176 350 41 179 350 minecraft:honeycomb_block
setblock 41 176 354 minecraft:yellow_terracotta
fill 41 176 355 41 179 355 minecraft:honeycomb_block
setblock 41 176 359 minecraft:yellow_terracotta
setblock 42 176 337 minecraft:orange_terracotta
fill 42 176 348 42 205 348 minecraft:honeycomb_block
fill 0 177 324 1 178 324 minecraft:honeycomb_block
setblock 0 177 325 minecraft:orange_terracotta
fill 0 177 353 1 177 353 minecraft:yellow_terracotta
setblock 0 177 356 minecraft:yellow_concrete
fill 0 177 363 0 308 363 minecraft:honeycomb_block
setblock 1 177 323 minecraft:yellow_terracotta
setblock 1 177 328 minecraft:yellow_terracotta
fill 1 177 329 1 180 329 minecraft:honeycomb_block
setblock 1 177 333 minecraft:yellow_terracotta
fill 1 177 334 1 180 334 minecraft:honeycomb_block
setblock 1 177 338 minecraft:yellow_terracotta
fill 1 177 339 1 180 339 minecraft:honeycomb_block
setblock 1 177 343 minecraft:yellow_terracotta
fill 1 177 344 1 180 344 minecraft:honeycomb_block
setblock 1 177 348 minecraft:yellow_terracotta
fill 1 177 349 1 180 349 minecraft:honeycomb_block
fill 1 177 354 1 180 354 minecraft:honeycomb_block
fill 1 177 356 1 178 356 minecraft:honeycomb_block
setblock 1 177 362 minecraft:honey_block
fill 2 177 323 5 177 323 minecraft:honeycomb_block
setblock 2 177 327 minecraft:yellow_terracotta
fill 2 177 328 2 180 328 minecraft:honeycomb_block
setblock 2 177 332 minecraft:yellow_terracotta
fill 2 177 333 2 180 333 minecraft:honeycomb_block
setblock 2 177 337 minecraft:yellow_terracotta
fill 2 177 338 2 180 338 minecraft:honeycomb_block
setblock 2 177 342 minecraft:yellow_terracotta
fill 2 177 343 2 180 343 minecraft:honeycomb_block
setblock 2 177 347 minecraft:yellow_terracotta
fill 2 177 348 2 180 348 minecraft:honeycomb_block
setblock 2 177 352 minecraft:yellow_terracotta
fill 2 177 353 2 180 353 minecraft:honeycomb_block
setblock 3 177 326 minecraft:yellow_terracotta
fill 3 177 327 3 180 327 minecraft:honeycomb_block
setblock 3 177 331 minecraft:yellow_terracotta
fill 3 177 332 3 180 332 minecraft:honeycomb_block
setblock 3 177 346 minecraft:yellow_terracotta
fill 3 177 347 3 178 347 minecraft:honeycomb_block
setblock 5 177 324 minecraft:yellow_terracotta
setblock 6 177 323 minecraft:yellow_terracotta
fill 6 177 324 6 179 324 minecraft:honeycomb_block
fill 7 177 323 7 180 323 minecraft:honeycomb_block
setblock 11 177 323 minecraft:yellow_terracotta
fill 12 177 323 12 180 323 minecraft:honeycomb_block
setblock 15 177 324 minecraft:yellow_terracotta
setblock 16 177 323 minecraft:yellow_terracotta
fill 16 177 324 16 179 325 minecraft:honeycomb_block
fill 17 177 323 17 180 323 minecraft:honeycomb_block
fill 17 177 363 17 180 363 minecraft:honeycomb_block
setblock 19 177 325 minecraft:yellow_terracotta
setblock 20 177 324 minecraft:yellow_terracotta
fill 20 177 325 20 180 325 minecraft:honeycomb_block
setblock 21 177 323 minecraft:yellow_terracotta
fill 21 177 324 21 180 324 minecraft:honeycomb_block
setblock 21 177 363 minecraft:yellow_terracotta
fill 21 177 364 21 216 364 minecraft:honeycomb_block
fill 22 177 323 22 180 323 minecraft:honeycomb_block
setblock 22 177 362 minecraft:yellow_terracotta
fill 22 177 363 22 180 363 minecraft:honeycomb_block
fill 23 177 362 23 180 362 minecraft:honeycomb_block
setblock 24 177 325 minecraft:yellow_terracotta
setblock 25 177 324 minecraft:yellow_terracotta
setblock 26 177 323 minecraft:yellow_terracotta
setblock 26 177 324 minecraft:honeycomb_block
setblock 26 177 363 minecraft:yellow_terracotta
fill 27 177 323 27 178 323 minecraft:honeycomb_block
fill 27 177 363 27 180 363 minecraft:honeycomb_block
fill 37 177 322 37 308 322 minecraft:honeycomb_block
fill 38 177 323 38 179 323 minecraft:honeycomb_block
setblock 39 177 344 minecraft:honeycomb_block
setblock 39 177 345 minecraft:yellow_terracotta
fill 39 177 346 39 180 346 minecraft:honeycomb_block
setblock 39 177 349 minecraft:honeycomb_block
setblock 39 177 350 minecraft:yellow_terracotta
fill 39 177 351 39 180 351 minecraft:honeycomb_block
fill 39 177 353 40 177 353 minecraft:honeycomb_block
fill 40 177 326 40 179 326 minecraft:honeycomb_block
setblock 40 177 328 minecraft:honeycomb_block
setblock 40 177 329 minecraft:yellow_terracotta
fill 40 177 330 40 179 331 minecraft:honeycomb_block
setblock 40 177 344 minecraft:yellow_terracotta
fill 40 177 345 40 180 345 minecraft:honeycomb_block
setblock 40 177 349 minecraft:yellow_terracotta
fill 40 177 350 40 180 350 minecraft:honeycomb_block
setblock 40 177 354 minecraft:yellow_terracotta
fill 40 177 355 40 179 356 minecraft:honeycomb_block
setblock 41 177 323 minecraft:yellow_terracotta
fill 41 177 324 41 180 324 minecraft:honeycomb_block
setblock 41 177 328 minecraft:yellow_terracotta
fill 41 177 329 41 180 329 minecraft:honeycomb_block
fill 41 177 331 41 177 332 minecraft:honeycomb_block
setblock 41 177 333 minecraft:yellow_terracotta
fill 41 177 334 41 180 334 minecraft:honeycomb_block
setblock 41 177 338 minecraft:yellow_terracotta
fill 41 177 339 41 180 339 minecraft:honeycomb_block
setblock 41 177 343 minecraft:yellow_terracotta
fill 41 177 344 41 180 344 minecraft:honeycomb_block
setblock 41 177 348 minecraft:yellow_terracotta
fill 41 177 349 41 180 349 minecraft:honeycomb_block
setblock 41 177 353 minecraft:yellow_terracotta
fill 41 177 354 41 180 354 minecraft:honeycomb_block
setblock 41 177 358 minecraft:yellow_terracotta
fill 41 177 359 41 179 360 minecraft:honeycomb_block
fill 41 177 363 41 177 364 minecraft:yellow_terracotta
setblock 42 177 335 minecraft:yellow_terracotta
fill 42 177 337 42 308 337 minecraft:honeycomb_block
setblock 42 177 347 minecraft:orange_terracotta
fill 0 178 325 0 182 325 minecraft:honeycomb_block
fill 0 178 337 0 230 337 minecraft:honeycomb_block
fill 0 178 342 0 294 342 minecraft:honeycomb_block
fill 0 178 353 1 181 353 minecraft:honeycomb_block
fill 0 178 356 0 208 356 minecraft:honeycomb_block
fill 1 178 323 4 178 323 minecraft:honeycomb_block
setblock 1 178 327 minecraft:yellow_terracotta
fill 1 178 328 1 181 328 minecraft:honeycomb_block
setblock 1 178 332 minecraft:yellow_terracotta
fill 1 178 333 1 181 333 minecraft:honeycomb_block
setblock 1 178 337 minecraft:yellow_terracotta
fill 1 178 338 1 181 338 minecraft:honeycomb_block
setblock 1 178 342 minecraft:yellow_terracotta
fill 1 178 343 1 181 343 minecraft:honeycomb_block
setblock 1 178 347 minecraft:yellow_terracotta
fill 1 178 348 1 181 348 minecraft:honeycomb_block
setblock 1 178 352 minecraft:yellow_terracotta
setblock 2 178 326 minecraft:yellow_terracotta
fill 2 178 327 2 181 327 minecraft:honeycomb_block
setblock 2 178 330 minecraft:honeycomb_block
setblock 2 178 331 minecraft:yellow_terracotta
fill 2 178 332 2 181 332 minecraft:honeycomb_block
setblock 2 178 336 minecraft:yellow_terracotta
fill 2 178 337 2 181 337 minecraft:honeycomb_block
setblock 2 178 341 minecraft:yellow_terracotta
fill 2 178 342 2 181 342 minecraft:honeycomb_block
setblock 2 178 346 minecraft:yellow_terracotta
fill 2 178 347 2 181 347 minecraft:honeycomb_block
setblock 2 178 351 minecraft:yellow_terracotta
fill 2 178 352 2 181 352 minecraft:honeycomb_block
setblock 3 178 325 minecraft:yellow_terracotta
fill 3 178 326 3 181 326 minecraft:honeycomb_block
setblock 3 178 330 minecraft:yellow_terracotta
fill 3 178 331 3 181 331 minecraft:honeycomb_block
fill 3 178 333 3 178 334 minecraft:honeycomb_block
setblock 4 178 324 minecraft:yellow_terracotta
setblock 5 178 323 minecraft:yellow_terracotta
fill 5 178 324 5 181 324 minecraft:honeycomb_block
fill 6 178 323 6 181 323 minecraft:honeycomb_block
setblock 6 178 363 minecraft:honey_block
setblock 10 178 323 minecraft:yellow_terracotta
fill 11 178 323 11 181 323 minecraft:honeycomb_block
setblock 13 178 324 minecraft:honeycomb_block
setblock 14 178 324 minecraft:yellow_terracotta
setblock 15 178 323 minecraft:yellow_terracotta
fill 15 178 324 15 181 324 minecraft:honeycomb_block
fill 16 178 323 16 181 323 minecraft:honeycomb_block
fill 16 178 363 16 181 363 minecraft:honeycomb_block
setblock 18 178 325 minecraft:yellow_terracotta
setblock 19 178 324 minecraft:yellow_terracotta
fill 19 178 325 19 181 325 minecraft:honeycomb_block
fill 19 178 362 19 179 362 minecraft:honeycomb_block
setblock 20 178 323 minecraft:yellow_terracotta
fill 20 178 324 20 181 324 minecraft:honeycomb_block
fill 20 178 326 20 179 326 minecraft:honeycomb_block
setblock 20 178 363 minecraft:yellow_terracotta
fill 21 178 323 21 181 323 minecraft:honeycomb_block
setblock 21 178 362 minecraft:yellow_terracotta
fill 21 178 363 21 181 363 minecraft:honeycomb_block
fill 22 178 362 22 181 362 minecraft:honeycomb_block
setblock 23 178 325 minecraft:yellow_terracotta
setblock 24 178 324 minecraft:yellow_terracotta
setblock 25 178 323 minecraft:yellow_terracotta
fill 25 178 324 25 179 324 minecraft:honeycomb_block
setblock 25 178 363 minecraft:yellow_terracotta
fill 25 178 364 25 308 364 minecraft:honeycomb_block
fill 26 178 323 26 180 323 minecraft:honeycomb_block
fill 26 178 363 26 181 363 minecraft:honeycomb_block
setblock 31 178 363 minecraft:honey_block
setblock 36 178 323 minecraft:honey_block
fill 38 178 348 38 178 349 minecraft:honeycomb_block
setblock 38 178 350 minecraft:yellow_terracotta
fill 38 178 351 38 181 351 minecraft:honeycomb_block
setblock 39 178 344 minecraft:yellow_terracotta
fill 39 178 345 39 181 345 minecraft:honeycomb_block
setblock 39 178 349 minecraft:yellow_terracotta
fill 39 178 350 39 181 350 minecraft:honeycomb_block
setblock 39 178 353 minecraft:honeycomb_block
setblock 39 178 354 minecraft:yellow_terracotta
setblock 40 178 323 minecraft:yellow_terracotta
fill 40 178 325 40 180 325 minecraft:honeycomb_block
setblock 40 178 328 minecraft:yellow_terracotta
fill 40 178 329 40 181 329 minecraft:honeycomb_block
setblock 40 178 332 minecraft:honeycomb_block
setblock 40 178 333 minecraft:yellow_terracotta
fill 40 178 334 40 181 334 minecraft:honeycomb_block
fill 40 178 340 40 180 340 minecraft:honeycomb_block
setblock 40 178 343 minecraft:yellow_terracotta
fill 40 178 344 40 181 344 minecraft:honeycomb_block
setblock 40 178 348 minecraft:yellow_terracotta
fill 40 178 349 40 181 349 minecraft:honeycomb_block
setblock 40 178 353 minecraft:yellow_terracotta
fill 40 178 354 40 181 354 minecraft:honeycomb_block
setblock 40 178 357 minecraft:honeycomb_block
setblock 40 178 363 minecraft:yellow_terracotta
fill 41 178 323 41 181 323 minecraft:honeycomb_block
setblock 41 178 327 minecraft:yellow_terracotta
fill 41 178 328 41 181 328 minecraft:honeycomb_block
setblock 41 178 331 minecraft:honeycomb_block
setblock 41 178 332 minecraft:yellow_terracotta
fill 41 178 333 41 181 333 minecraft:honeycomb_block
setblock 41 178 337 minecraft:yellow_terracotta
fill 41 178 338 41 181 338 minecraft:honeycomb_block
setblock 41 178 342 minecraft:yellow_terracotta
fill 41 178 343 41 181 343 minecraft:honeycomb_block
setblock 41 178 347 minecraft:yellow_terracotta
fill 41 178 348 41 181 348 minecraft:honeycomb_block
setblock 41 178 352 minecraft:yellow_terracotta
fill 41 178 353 41 181 353 minecraft:honeycomb_block
setblock 41 178 357 minecraft:yellow_terracotta
fill 41 178 358 41 181 358 minecraft:honeycomb_block
setblock 41 178 362 minecraft:honey_block
fill 41 178 363 41 181 364 minecraft:honeycomb_block
fill 42 178 335 42 293 335 minecraft:honeycomb_block
fill 42 178 347 42 179 347 minecraft:honeycomb_block
setblock 0 179 324 minecraft:yellow_terracotta
fill 1 179 323 1 180 324 minecraft:honeycomb_block
setblock 1 179 326 minecraft:yellow_terracotta
fill 1 179 327 1 182 327 minecraft:honeycomb_block
setblock 1 179 331 minecraft:yellow_terracotta
fill 1 179 332 1 182 332 minecraft:honeycomb_block
setblock 1 179 336 minecraft:yellow_terracotta
fill 1 179 337 1 182 337 minecraft:honeycomb_block
setblock 1 179 341 minecraft:yellow_terracotta
fill 1 179 342 1 182 342 minecraft:honeycomb_block
setblock 1 179 346 minecraft:yellow_terracotta
fill 1 179 347 1 182 347 minecraft:honeycomb_block
setblock 1 179 351 minecraft:yellow_terracotta
fill 1 179 352 1 182 352 minecraft:honeycomb_block
setblock 1 179 356 minecraft:yellow_terracotta
fill 1 179 357 1 182 357 minecraft:honeycomb_block
fill 2 179 323 3 179 323 minecraft:honeycomb_block
setblock 2 179 325 minecraft:yellow_terracotta
fill 2 179 326 2 182 326 minecraft:honeycomb_block
setblock 2 179 330 minecraft:yellow_terracotta
fill 2 179 331 2 182 331 minecraft:honeycomb_block
setblock 2 179 335 minecraft:yellow_terracotta
fill 2 179 336 2 182 336 minecraft:honeycomb_block
setblock 2 179 340 minecraft:yellow_terracotta
fill 2 179 341 2 182 341 minecraft:honeycomb_block
setblock 2 179 345 minecraft:yellow_terracotta
fill 2 179 346 2 182 346 minecraft:honeycomb_block
setblock 2 179 350 minecraft:yellow_terracotta
fill 2 179 351 2 182 351 minecraft:honeycomb_block
setblock 2 179 354 minecraft:honeycomb_block
setblock 3 179 324 minecraft:yellow_terracotta
fill 3 179 325 3 180 325 minecraft:honeycomb_block
setblock 3 179 329 minecraft:yellow_terracotta
fill 3 179 330 3 182 330 minecraft:honeycomb_block
setblock 3 179 333 minecraft:honeycomb_block
setblock 3 179 334 minecraft:yellow_terracotta
fill 3 179 335 3 182 335 minecraft:honeycomb_block
setblock 4 179 323 minecraft:yellow_terracotta
fill 4 179 324 4 182 324 minecraft:honeycomb_block
fill 5 179 323 5 182 323 minecraft:honeycomb_block
setblock 9 179 323 minecraft:yellow_terracotta
fill 10 179 323 10 182 323 minecraft:honeycomb_block
fill 12 179 339 13 180 340 minecraft:yellow_concrete
setblock 12 179 363 minecraft:honey_block
setblock 13 179 324 minecraft:yellow_terracotta
setblock 13 179 364 minecraft:yellow_concrete
setblock 14 179 323 minecraft:yellow_terracotta
fill 14 179 324 14 182 324 minecraft:honeycomb_block
fill 15 179 323 15 182 323 minecraft:honeycomb_block
fill 15 179 325 15 180 325 minecraft:honeycomb_block
fill 15 179 363 15 182 363 minecraft:honeycomb_block
setblock 17 179 325 minecraft:yellow_terracotta
setblock 18 179 324 minecraft:yellow_terracotta
fill 18 179 325 18 181 326 minecraft:honeycomb_block
fill 18 179 362 18 180 362 minecraft:honeycomb_block
setblock 18 179 364 minecraft:yellow_concrete
setblock 19 179 323 minecraft:yellow_terracotta
fill 19 179 324 19 182 324 minecraft:honeycomb_block
fill 19 179 326 19 180 326 minecraft:honeycomb_block
setblock 19 179 363 minecraft:yellow_terracotta
fill 20 179 323 20 182 323 minecraft:honeycomb_block
setblock 20 179 362 minecraft:yellow_terracotta
fill 20 179 363 20 182 363 minecraft:honeycomb_block
fill 21 179 362 21 182 362 minecraft:honeycomb_block
setblock 22 179 325 minecraft:yellow_terracotta
setblock 23 179 324 minecraft:yellow_terracotta
setblock 23 179 325 minecraft:honeycomb_block
setblock 24 179 323 minecraft:yellow_terracotta
fill 24 179 324 24 180 324 minecraft:honeycomb_block
setblock 24 179 363 minecraft:yellow_terracotta
fill 25 179 323 25 181 323 minecraft:honeycomb_block
fill 25 179 363 25 182 363 minecraft:honeycomb_block
fill 26 179 351 26 180 351 minecraft:yellow_concrete
setblock 30 179 323 minecraft:honey_block
setblock 31 179 322 minecraft:yellow_concrete
setblock 37 179 363 minecraft:honey_block
fill 38 179 347 38 179 348 minecraft:honeycomb_block
setblock 38 179 349 minecraft:yellow_terracotta
fill 38 179 350 38 182 350 minecraft:honeycomb_block
fill 38 179 352 38 179 353 minecraft:honeycomb_block
setblock 38 179 363 minecraft:honeycomb_block
setblock 39 179 322 minecraft:yellow_concrete
setblock 39 179 323 minecraft:yellow_terracotta
fill 39 179 344 39 182 344 minecraft:honeycomb_block
setblock 39 179 348 minecraft:yellow_terracotta
fill 39 179 349 39 182 349 minecraft:honeycomb_block
setblock 39 179 353 minecraft:yellow_terracotta
fill 39 179 354 39 181 355 minecraft:honeycomb_block
setblock 39 179 363 minecraft:yellow_terracotta
fill 40 179 323 40 182 323 minecraft:honeycomb_block
setblock 40 179 327 minecraft:yellow_terracotta
fill 40 179 328 40 182 328 minecraft:honeycomb_block
setblock 40 179 332 minecraft:yellow_terracotta
fill 40 179 333 40 182 333 minecraft:honeycomb_block
fill 40 179 335 40 179 336 minecraft:honeycomb_block
setblock 40 179 337 minecraft:yellow_terracotta
fill 40 179 338 40 181 339 minecraft:honeycomb_block
setblock 40 179 342 minecraft:yellow_terracotta
fill 40 179 343 40 182 343 minecraft:honeycomb_block
setblock 40 179 347 minecraft:yellow_terracotta
fill 40 179 348 40 182 348 minecraft:honeycomb_block
setblock 40 179 352 minecraft:yellow_terracotta
fill 40 179 353 40 182 353 minecraft:honeycomb_block
setblock 40 179 357 minecraft:yellow_terracotta
fill 40 179 358 40 182 358 minecraft:honeycomb_block
fill 40 179 363 40 182 363 minecraft:honeycomb_block
setblock 41 179 326 minecraft:yellow_terracotta
fill 41 179 327 41 182 327 minecraft:honeycomb_block
setblock 41 179 331 minecraft:yellow_terracotta
fill 41 179 332 41 182 332 minecraft:honeycomb_block
setblock 41 179 335 minecraft:honeycomb_block
setblock 41 179 336 minecraft:yellow_terracotta
fill 41 179 337 41 182 337 minecraft:honeycomb_block
setblock 41 179 341 minecraft:yellow_terracotta
fill 41 179 342 41 182 342 minecraft:honeycomb_block
setblock 41 179 346 minecraft:yellow_terracotta
fill 41 179 347 41 182 347 minecraft:honeycomb_block
setblock 41 179 351 minecraft:yellow_terracotta
fill 41 179 352 41 182 352 minecraft:honeycomb_block
setblock 41 179 356 minecraft:yellow_terracotta
fill 41 179 357 41 182 357 minecraft:honeycomb_block
setblock 41 179 361 minecraft:yellow_terracotta
fill 41 179 362 41 182 362 minecraft:honeycomb_block
fill 0 180 324 0 205 324 minecraft:honeycomb_block
fill 0 180 330 1 180 330 minecraft:yellow_terracotta
fill 0 180 355 0 193 355 minecraft:honeycomb_block
setblock 1 180 325 minecraft:yellow_terracotta
fill 1 180 326 1 183 326 minecraft:honeycomb_block
fill 1 180 331 1 183 331 minecraft:honeycomb_block
setblock 1 180 335 minecraft:yellow_terracotta
fill 1 180 336 1 183 336 minecraft:honeycomb_block
setblock 1 180 340 minecraft:yellow_terracotta
fill 1 180 341 1 183 341 minecraft:honeycomb_block
setblock 1 180 345 minecraft:yellow_terracotta
fill 1 180 346 1 183 346 minecraft:honeycomb_block
setblock 1 180 350 minecraft:yellow_terracotta
fill 1 180 351 1 183 351 minecraft:honeycomb_block
setblock 1 180 355 minecraft:yellow_terracotta
fill 1 180 356 1 183 356 minecraft:honeycomb_block
fill 1 180 358 1 181 358 minecraft:honeycomb_block
setblock 1 180 361 minecraft:honey_block
setblock 2 180 323 minecraft:honeycomb_block
setblock 2 180 324 minecraft:yellow_terracotta
fill 2 180 325 2 183 325 minecraft:honeycomb_block
setblock 2 180 329 minecraft:yellow_terracotta
fill 2 180 330 2 183 330 minecraft:honeycomb_block
setblock 2 180 334 minecraft:yellow_terracotta
fill 2 180 335 2 183 335 minecraft:honeycomb_block
setblock 2 180 339 minecraft:yellow_terracotta
fill 2 180 340 2 183 340 minecraft:honeycomb_block
setblock 2 180 344 minecraft:yellow_terracotta
fill 2 180 345 2 182 345 minecraft:honeycomb_block
setblock 2 180 349 minecraft:yellow_terracotta
fill 2 180 350 2 183 350 minecraft:honeycomb_block
setblock 2 180 354 minecraft:yellow_terracotta
fill 2 180 355 2 183 355 minecraft:honeycomb_block
setblock 3 180 323 minecraft:yellow_terracotta
fill 3 180 324 3 182 324 minecraft:honeycomb_block
setblock 3 180 328 minecraft:yellow_terracotta
fill 3 180 329 4 181 329 minecraft:honeycomb_block
setblock 3 180 333 minecraft:yellow_terracotta
fill 3 180 334 3 183 334 minecraft:honeycomb_block
fill 3 180 336 3 181 336 minecraft:honeycomb_block
fill 4 180 323 4 183 323 minecraft:honeycomb_block
fill 4 180 330 4 180 331 minecraft:honeycomb_block
setblock 8 180 323 minecraft:yellow_terracotta
fill 9 180 323 9 183 323 minecraft:honeycomb_block
setblock 12 180 324 minecraft:yellow_terracotta
setblock 13 180 323 minecraft:yellow_terracotta
fill 13 180 324 13 183 324 minecraft:honeycomb_block
fill 13 180 364 13 308 364 minecraft:honeycomb_block
fill 14 180 323 14 183 323 minecraft:honeycomb_block
fill 14 180 325 14 181 325 minecraft:honeycomb_block
fill 14 180 363 14 183 363 minecraft:honeycomb_block
setblock 16 180 324 minecraft:honeycomb_block
setblock 16 180 325 minecraft:yellow_terracotta
setblock 17 180 324 minecraft:yellow_terracotta
fill 17 180 325 17 181 326 minecraft:honeycomb_block
fill 17 180 362 17 181 362 minecraft:honeycomb_block
setblock 18 180 323 minecraft:yellow_terracotta
fill 18 180 324 18 183 324 minecraft:honeycomb_block
setblock 18 180 363 minecraft:yellow_terracotta
fill 18 180 364 18 181 364 minecraft:honeycomb_block
fill 19 180 323 19 183 323 minecraft:honeycomb_block
setblock 19 180 362 minecraft:yellow_terracotta
fill 19 180 363 19 183 363 minecraft:honeycomb_block
setblock 20 180 326 minecraft:yellow_terracotta
fill 20 180 362 20 183 362 minecraft:honeycomb_block
setblock 21 180 325 minecraft:yellow_terracotta
setblock 22 180 324 minecraft:yellow_terracotta
fill 22 180 325 22 181 325 minecraft:honeycomb_block
setblock 23 180 323 minecraft:yellow_terracotta
fill 23 180 324 23 182 324 minecraft:honeycomb_block
setblock 23 180 363 minecraft:yellow_terracotta
fill 24 180 323 24 183 323 minecraft:honeycomb_block
setblock 24 180 362 minecraft:yellow_terracotta
fill 24 180 363 24 183 363 minecraft:honeycomb_block
fill 31 180 322 31 308 322 minecraft:honeycomb_block
setblock 37 180 323 minecraft:honeycomb_block
setblock 37 180 363 minecraft:honeycomb_block
setblock 38 180 323 minecraft:yellow_terracotta
setblock 38 180 347 minecraft:honeycomb_block
setblock 38 180 348 minecraft:yellow_terracotta
fill 38 180 349 38 183 349 minecraft:honeycomb_block
setblock 38 180 352 minecraft:honeycomb_block
setblock 38 180 353 minecraft:yellow_terracotta
fill 38 180 354 38 183 354 minecraft:honeycomb_block
setblock 38 180 363 minecraft:yellow_terracotta
fill 39 180 322 39 183 323 minecraft:honeycomb_block
fill 39 180 328 39 180 331 minecraft:honeycomb_block
setblock 39 180 332 minecraft:yellow_terracotta
fill 39 180 333 39 182 334 minecraft:honeycomb_block
fill 39 180 343 39 183 343 minecraft:honeycomb_block
setblock 39 180 347 minecraft:yellow_terracotta
fill 39 180 348 39 183 348 minecraft:honeycomb_block
setblock 39 180 352 minecraft:yellow_terracotta
fill 39 180 353 39 183 353 minecraft:honeycomb_block
setblock 39 180 356 minecraft:honeycomb_block
fill 39 180 363 39 183 363 minecraft:honeycomb_block
setblock 40 180 326 minecraft:yellow_terracotta
fill 40 180 327 40 183 327 minecraft:honeycomb_block
setblock 40 180 330 minecraft:honeycomb_block
setblock 40 180 331 minecraft:yellow_terracotta
fill 40 180 332 40 183 332 minecraft:honeycomb_block
setblock 40 180 335 minecraft:honeycomb_block
setblock 40 180 336 minecraft:yellow_terracotta
fill 40 180 337 40 183 337 minecraft:honeycomb_block
setblock 40 180 341 minecraft:yellow_terracotta
fill 40 180 342 40 183 342 minecraft:honeycomb_block
setblock 40 180 346 minecraft:yellow_terracotta
fill 40 180 347 40 183 347 minecraft:honeycomb_block
setblock 40 180 351 minecraft:yellow_terracotta
fill 40 180 352 40 183 352 minecraft:honeycomb_block
setblock 40 180 355 minecraft:honeycomb_block
setblock 40 180 356 minecraft:yellow_terracotta
fill 40 180 357 40 183 357 minecraft:honeycomb_block
fill 40 180 359 41 180 359 minecraft:honeycomb_block
setblock 41 180 325 minecraft:yellow_terracotta
fill 41 180 326 41 183 326 minecraft:honeycomb_block
setblock 41 180 330 minecraft:yellow_terracotta
fill 41 180 331 41 183 331 minecraft:honeycomb_block
setblock 41 180 335 minecraft:yellow_terracotta
fill 41 180 336 41 183 336 minecraft:honeycomb_block
setblock 41 180 340 minecraft:yellow_terracotta
fill 41 180 341 41 183 341 minecraft:honeycomb_block
setblock 41 180 345 minecraft:yellow_terracotta
fill 41 180 346 41 183 346 minecraft:honeycomb_block
setblock 41 180 350 minecraft:yellow_terracotta
fill 41 180 351 41 183 351 minecraft:honeycomb_block
setblock 41 180 355 minecraft:yellow_terracotta
fill 41 180 356 41 183 356 minecraft:honeycomb_block
setblock 41 180 360 minecraft:yellow_terracotta
fill 41 180 361 41 183 361 minecraft:honeycomb_block
setblock 42 180 347 minecraft:orange_terracotta
fill 0 181 330 1 184 330 minecraft:honeycomb_block
setblock 1 181 323 minecraft:honeycomb_block
setblock 1 181 324 minecraft:yellow_terracotta
fill 1 181 325 1 184 325 minecraft:honeycomb_block
setblock 1 181 329 minecraft:yellow_terracotta
setblock 1 181 334 minecraft:yellow_terracotta
fill 1 181 335 1 184 335 minecraft:honeycomb_block
setblock 1 181 339 minecraft:yellow_terracotta
fill 1 181 340 1 184 340 minecraft:honeycomb_block
setblock 1 181 344 minecraft:yellow_terracotta
fill 1 181 345 1 184 345 minecraft:honeycomb_block
setblock 1 181 349 minecraft:yellow_terracotta
fill 1 181 350 1 184 350 minecraft:honeycomb_block
setblock 1 181 354 minecraft:yellow_terracotta
fill 1 181 355 1 184 355 minecraft:honeycomb_block
setblock 1 181 359 minecraft:yellow_terracotta
setblock 2 181 323 minecraft:yellow_terracotta
fill 2 181 324 2 183 324 minecraft:honeycomb_block
setblock 2 181 328 minecraft:yellow_terracotta
fill 2 181 329 2 184 329 minecraft:honeycomb_block
setblock 2 181 333 minecraft:yellow_terracotta
fill 2 181 334 2 184 334 minecraft:honeycomb_block
setblock 2 181 338 minecraft:yellow_terracotta
fill 2 181 339 2 184 339 minecraft:honeycomb_block
setblock 2 181 343 minecraft:yellow_terracotta
fill 2 181 344 2 182 344 minecraft:honeycomb_block
setblock 2 181 348 minecraft:yellow_terracotta
fill 2 181 349 2 183 349 minecraft:honeycomb_block
setblock 2 181 353 minecraft:yellow_terracotta
fill 2 181 354 2 184 354 minecraft:honeycomb_block
fill 3 181 323 3 184 323 minecraft:honeycomb_block
setblock 3 181 325 minecraft:yellow_terracotta
setblock 3 181 327 minecraft:yellow_terracotta
fill 3 181 328 3 184 328 minecraft:honeycomb_block
setblock 3 181 332 minecraft:yellow_terracotta
fill 3 181 333 3 184 333 minecraft:honeycomb_block
setblock 4 181 330 minecraft:honeycomb_block
setblock 4 181 331 minecraft:yellow_terracotta
fill 4 181 332 4 182 332 minecraft:honeycomb_block
setblock 5 181 363 minecraft:honey_block
setblock 7 181 323 minecraft:yellow_terracotta
fill 8 181 323 8 183 323 minecraft:honeycomb_block
setblock 12 181 323 minecraft:yellow_terracotta
fill 12 181 324 12 184 324 minecraft:honeycomb_block
fill 13 181 323 13 184 323 minecraft:honeycomb_block
fill 13 181 363 13 184 363 minecraft:honeycomb_block
setblock 15 181 325 minecraft:yellow_terracotta
setblock 16 181 324 minecraft:yellow_terracotta
fill 16 181 325 16 184 325 minecraft:honeycomb_block
fill 16 181 362 16 182 362 minecraft:honeycomb_block
setblock 17 181 323 minecraft:yellow_terracotta
fill 17 181 324 17 184 324 minecraft:honeycomb_block
setblock 17 181 363 minecraft:yellow_terracotta
fill 18 181 323 18 184 323 minecraft:honeycomb_block
setblock 18 181 362 minecraft:yellow_terracotta
fill 18 181 363 18 184 363 minecraft:honeycomb_block
setblock 19 181 326 minecraft:yellow_terracotta
setblock 19 181 361 minecraft:yellow_terracotta
fill 19 181 362 19 184 362 minecraft:honeycomb_block
setblock 20 181 325 minecraft:yellow_terracotta
fill 20 181 361 20 184 361 minecraft:honeycomb_block
setblock 21 181 324 minecraft:yellow_terracotta
fill 21 181 325 21 182 325 minecraft:honeycomb_block
setblock 21 181 361 minecraft:yellow_terracotta
setblock 22 181 323 minecraft:yellow_terracotta
fill 22 181 324 22 183 324 minecraft:honeycomb_block
setblock 22 181 363 minecraft:yellow_terracotta
fill 23 181 323 23 184 323 minecraft:honeycomb_block
setblock 23 181 362 minecraft:yellow_terracotta
fill 23 181 363 23 184 363 minecraft:honeycomb_block
fill 24 181 362 24 182 362 minecraft:honeycomb_block
setblock 30 181 364 minecraft:orange_terracotta
fill 35 181 363 36 181 363 minecraft:honeycomb_block
setblock 37 181 323 minecraft:yellow_terracotta
setblock 37 181 363 minecraft:yellow_terracotta
fill 38 181 323 38 184 323 minecraft:honeycomb_block
setblock 38 181 347 minecraft:yellow_terracotta
fill 38 181 348 38 183 348 minecraft:honeycomb_block
setblock 38 181 352 minecraft:yellow_terracotta
fill 38 181 353 38 184 353 minecraft:honeycomb_block
fill 38 181 355 38 182 355 minecraft:honeycomb_block
fill 38 181 363 38 184 363 minecraft:honeycomb_block
fill 39 181 328 39 181 330 minecraft:honeycomb_block
setblock 39 181 331 minecraft:yellow_terracotta
fill 39 181 332 39 184 332 minecraft:honeycomb_block
setblock 39 181 335 minecraft:honeycomb_block
setblock 39 181 336 minecraft:yellow_terracotta
fill 39 181 337 39 184 337 minecraft:honeycomb_block
fill 39 181 342 39 184 342 minecraft:honeycomb_block
setblock 39 181 346 minecraft:yellow_terracotta
fill 39 181 347 39 184 347 minecraft:honeycomb_block
setblock 39 181 351 minecraft:yellow_terracotta
fill 39 181 352 39 184 352 minecraft:honeycomb_block
setblock 39 181 356 minecraft:yellow_terracotta
fill 39 181 357 39 184 357 minecraft:honeycomb_block
setblock 40 181 325 minecraft:yellow_terracotta
fill 40 181 326 40 183 326 minecraft:honeycomb_block
setblock 40 181 330 minecraft:yellow_terracotta
fill 40 181 331 40 184 331 minecraft:honeycomb_block
setblock 40 181 335 minecraft:yellow_terracotta
fill 40 181 336 40 184 336 minecraft:honeycomb_block
setblock 40 181 340 minecraft:yellow_terracotta
fill 40 181 341 40 184 341 minecraft:honeycomb_block
setblock 40 181 345 minecraft:yellow_terracotta
fill 40 181 346 40 184 346 minecraft:honeycomb_block
setblock 40 181 350 minecraft:yellow_terracotta
fill 40 181 351 40 184 351 minecraft:honeycomb_block
setblock 40 181 355 minecraft:yellow_terracotta
fill 40 181 356 40 184 356 minecraft:honeycomb_block
setblock 40 181 359 minecraft:honeycomb_block
setblock 41 181 324 minecraft:yellow_terracotta
fill 41 181 325 41 184 325 minecraft:honeycomb_block
setblock 41 181 329 minecraft:yellow_terracotta
fill 41 181 330 41 184 330 minecraft:honeycomb_block
setblock 41 181 334 minecraft:yellow_terracotta
fill 41 181 335 41 184 335 minecraft:honeycomb_block
setblock 41 181 339 minecraft:yellow_terracotta
fill 41 181 340 41 184 340 minecraft:honeycomb_block
setblock 41 181 344 minecraft:yellow_terracotta
fill 41 181 345 41 184 345 minecraft:honeycomb_block
setblock 41 181 349 minecraft:yellow_terracotta
fill 41 181 350 41 184 350 minecraft:honeycomb_block
setblock 41 181 354 minecraft:yellow_terracotta
fill 41 181 355 41 184 355 minecraft:honeycomb_block
setblock 41 181 359 minecraft:yellow_terracotta
fill 41 181 360 41 184 360 minecraft:honeycomb_block
setblock 42 181 346 minecraft:yellow_concrete
fill 42 181 347 42 225 347 minecraft:honeycomb_block
setblock 42 181 351 minecraft:yellow_concrete
fill 0 182 353 0 308 353 minecraft:honeycomb_block
setblock 1 182 323 minecraft:yellow_terracotta
fill 1 182 324 1 185 324 minecraft:honeycomb_block
setblock 1 182 328 minecraft:yellow_terracotta
fill 1 182 329 1 185 329 minecraft:honeycomb_block
setblock 1 182 333 minecraft:yellow_terracotta
fill 1 182 334 1 185 334 minecraft:honeycomb_block
setblock 1 182 338 minecraft:yellow_terracotta
fill 1 182 339 1 185 339 minecraft:honeycomb_block
setblock 1 182 343 minecraft:yellow_terracotta
fill 1 182 344 1 185 344 minecraft:honeycomb_block
setblock 1 182 348 minecraft:yellow_terracotta
fill 1 182 349 1 185 349 minecraft:honeycomb_block
setblock 1 182 353 minecraft:yellow_terracotta
fill 1 182 354 1 185 354 minecraft:honeycomb_block
setblock 1 182 358 minecraft:yellow_terracotta
fill 1 182 359 1 184 360 minecraft:honeycomb_block
fill 2 182 323 2 185 323 minecraft:honeycomb_block
setblock 2 182 327 minecraft:yellow_terracotta
fill 2 182 328 2 185 328 minecraft:honeycomb_block
setblock 2 182 332 minecraft:yellow_terracotta
fill 2 182 333 2 185 333 minecraft:honeycomb_block
setblock 2 182 337 minecraft:yellow_terracotta
fill 2 182 338 2 185 338 minecraft:honeycomb_block
setblock 2 182 342 minecraft:yellow_terracotta
setblock 2 182 347 minecraft:yellow_terracotta
fill 2 182 348 2 183 348 minecraft:honeycomb_block
setblock 2 182 352 minecraft:yellow_terracotta
fill 2 182 353 2 184 353 minecraft:honeycomb_block
setblock 2 182 356 minecraft:honeycomb_block
setblock 3 182 325 minecraft:light[level=12]
setblock 3 182 326 minecraft:yellow_terracotta
fill 3 182 327 3 183 327 minecraft:honeycomb_block
fill 3 182 329 3 183 329 minecraft:honeycomb_block
setblock 3 182 331 minecraft:yellow_terracotta
fill 3 182 332 3 185 332 minecraft:honeycomb_block
setblock 3 182 336 minecraft:yellow_terracotta
setblock 3 182 339 minecraft:light[level=12]
setblock 3 182 346 minecraft:light[level=12]
setblock 3 182 353 minecraft:light[level=12]
setblock 3 182 360 minecraft:light[level=12]
setblock 4 182 330 minecraft:yellow_terracotta
setblock 4 182 331 minecraft:honeycomb_block
setblock 6 182 323 minecraft:yellow_terracotta
fill 7 182 323 7 183 323 minecraft:honeycomb_block
setblock 10 182 325 minecraft:light[level=12]
setblock 10 182 332 minecraft:light[level=12]
setblock 10 182 339 minecraft:light[level=12]
setblock 10 182 346 minecraft:light[level=12]
setblock 10 182 353 minecraft:light[level=12]
setblock 10 182 360 minecraft:light[level=12]
setblock 11 182 323 minecraft:yellow_terracotta
setblock 11 182 324 minecraft:honeycomb_block
setblock 11 182 363 minecraft:honey_block
fill 12 182 323 12 185 323 minecraft:honeycomb_block
setblock 14 182 325 minecraft:yellow_terracotta
setblock 15 182 324 minecraft:yellow_terracotta
fill 15 182 325 15 184 325 minecraft:honeycomb_block
fill 15 182 362 15 183 362 minecraft:honeycomb_block
setblock 16 182 323 minecraft:yellow_terracotta
fill 16 182 324 16 185 324 minecraft:honeycomb_block
setblock 16 182 363 minecraft:yellow_terracotta
fill 17 182 323 17 185 323 minecraft:honeycomb_block
fill 17 182 325 18 182 325 minecraft:honeycomb_block
setblock 17 182 332 minecraft:light[level=12]
setblock 17 182 339 minecraft:light[level=12]
setblock 17 182 346 minecraft:light[level=12]
setblock 17 182 353 minecraft:light[level=12]
setblock 17 182 360 minecraft:light[level=12]
setblock 17 182 361 minecraft:honeycomb_block
setblock 17 182 362 minecraft:yellow_terracotta
fill 17 182 363 17 185 363 minecraft:honeycomb_block
setblock 18 182 361 minecraft:yellow_terracotta
fill 18 182 362 18 185 362 minecraft:honeycomb_block
setblock 18 182 364 minecraft:yellow_concrete
setblock 19 182 325 minecraft:yellow_terracotta
fill 19 182 361 19 185 361 minecraft:honeycomb_block
setblock 20 182 324 minecraft:yellow_terracotta
fill 20 182 325 20 183 325 minecraft:honeycomb_block
setblock 21 182 323 minecraft:yellow_terracotta
fill 21 182 324 21 183 324 minecraft:honeycomb_block
fill 21 182 361 21 183 361 minecraft:honeycomb_block
setblock 21 182 363 minecraft:yellow_terracotta
fill 22 182 323 22 184 323 minecraft:honeycomb_block
setblock 22 182 362 minecraft:yellow_terracotta
fill 22 182 363 22 185 363 minecraft:honeycomb_block
fill 23 182 362 23 185 362 minecraft:honeycomb_block
setblock 24 182 325 minecraft:light[level=12]
setblock 24 182 332 minecraft:light[level=12]
setblock 24 182 339 minecraft:light[level=12]
setblock 24 182 346 minecraft:light[level=12]
setblock 24 182 353 minecraft:light[level=12]
setblock 24 182 360 minecraft:light[level=12]
setblock 26 182 363 minecraft:yellow_terracotta
setblock 30 182 363 minecraft:honey_block
fill 30 182 364 30 236 364 minecraft:honeycomb_block
setblock 31 182 323 minecraft:honey_block
setblock 31 182 325 minecraft:light[level=12]
setblock 31 182 332 minecraft:light[level=12]
setblock 31 182 339 minecraft:light[level=12]
setblock 31 182 346 minecraft:light[level=12]
setblock 31 182 353 minecraft:light[level=12]
setblock 31 182 360 minecraft:light[level=12]
fill 34 182 363 35 182 363 minecraft:honeycomb_block
setblock 36 182 323 minecraft:yellow_terracotta
setblock 36 182 363 minecraft:yellow_terracotta
fill 37 182 323 37 184 323 minecraft:honeycomb_block
setblock 37 182 351 minecraft:honeycomb_block
setblock 37 182 352 minecraft:yellow_terracotta
fill 37 182 363 37 185 363 minecraft:honeycomb_block
setblock 38 182 325 minecraft:light[level=12]
setblock 38 182 332 minecraft:light[level=12]
setblock 38 182 339 minecraft:light[level=12]
setblock 38 182 346 minecraft:light[level=12]
fill 38 182 347 38 183 347 minecraft:honeycomb_block
setblock 38 182 351 minecraft:yellow_terracotta
fill 38 182 352 38 185 352 minecraft:honeycomb_block
setblock 38 182 356 minecraft:yellow_terracotta
setblock 38 182 360 minecraft:light[level=12]
fill 39 182 328 39 182 329 minecraft:honeycomb_block
setblock 39 182 330 minecraft:yellow_terracotta
fill 39 182 331 39 185 331 minecraft:honeycomb_block
setblock 39 182 335 minecraft:yellow_terracotta
fill 39 182 336 39 185 336 minecraft:honeycomb_block
fill 39 182 338 39 182 339 minecraft:honeycomb_block
setblock 39 182 340 minecraft:yellow_terracotta
fill 39 182 341 39 185 341 minecraft:honeycomb_block
setblock 39 182 345 minecraft:yellow_terracotta
fill 39 182 346 39 184 346 minecraft:honeycomb_block
setblock 39 182 350 minecraft:yellow_terracotta
fill 39 182 351 39 185 351 minecraft:honeycomb_block
setblock 39 182 354 minecraft:honeycomb_block
setblock 39 182 355 minecraft:yellow_terracotta
fill 39 182 356 39 185 356 minecraft:honeycomb_block
fill 39 182 358 39 183 358 minecraft:honeycomb_block
setblock 40 182 325 minecraft:honeycomb_block
setblock 40 182 329 minecraft:yellow_terracotta
fill 40 182 330 40 185 330 minecraft:honeycomb_block
setblock 40 182 334 minecraft:yellow_terracotta
fill 40 182 335 40 185 335 minecraft:honeycomb_block
setblock 40 182 338 minecraft:honeycomb_block
setblock 40 182 339 minecraft:yellow_terracotta
fill 40 182 340 40 185 340 minecraft:honeycomb_block
setblock 40 182 344 minecraft:yellow_terracotta
fill 40 182 345 40 185 345 minecraft:honeycomb_block
setblock 40 182 349 minecraft:yellow_terracotta
fill 40 182 350 40 185 350 minecraft:honeycomb_block
setblock 40 182 354 minecraft:yellow_terracotta
fill 40 182 355 40 185 355 minecraft:honeycomb_block
setblock 40 182 359 minecraft:yellow_terracotta
fill 40 182 360 40 184 360 minecraft:honeycomb_block
setblock 41 182 323 minecraft:yellow_terracotta
fill 41 182 324 41 184 324 minecraft:honeycomb_block
setblock 41 182 328 minecraft:yellow_terracotta
fill 41 182 329 41 185 329 minecraft:honeycomb_block
setblock 41 182 333 minecraft:yellow_terracotta
fill 41 182 334 41 185 334 minecraft:honeycomb_block
setblock 41 182 338 minecraft:yellow_terracotta
fill 41 182 339 41 185 339 minecraft:honeycomb_block
setblock 41 182 343 minecraft:yellow_terracotta
fill 41 182 344 41 185 344 minecraft:honeycomb_block
setblock 41 182 348 minecraft:yellow_terracotta
fill 41 182 349 41 185 349 minecraft:honeycomb_block
setblock 41 182 353 minecraft:yellow_terracotta
fill 41 182 354 41 185 354 minecraft:honeycomb_block
setblock 41 182 358 minecraft:yellow_terracotta
fill 41 182 359 41 185 359 minecraft:honeycomb_block
fill 41 182 364 41 203 364 minecraft:honeycomb_block
fill 42 182 346 42 209 346 minecraft:honeycomb_block
fill 42 182 351 42 308 351 minecraft:honeycomb_block
setblock 0 183 325 minecraft:yellow_terracotta
fill 1 183 323 1 186 323 minecraft:honeycomb_block
setblock 1 183 327 minecraft:yellow_terracotta
fill 1 183 328 1 186 328 minecraft:honeycomb_block
setblock 1 183 332 minecraft:yellow_terracotta
fill 1 183 333 1 186 333 minecraft:honeycomb_block
setblock 1 183 337 minecraft:yellow_terracotta
fill 1 183 338 1 186 338 minecraft:honeycomb_block
setblock 1 183 342 minecraft:yellow_terracotta
fill 1 183 343 1 185 343 minecraft:honeycomb_block
setblock 1 183 347 minecraft:yellow_terracotta
fill 1 183 348 1 185 348 minecraft:honeycomb_block
setblock 1 183 352 minecraft:yellow_terracotta
fill 1 183 353 1 186 353 minecraft:honeycomb_block
setblock 1 183 357 minecraft:yellow_terracotta
fill 1 183 358 1 186 358 minecraft:honeycomb_block
setblock 2 183 326 minecraft:yellow_terracotta
fill 2 183 327 2 185 327 minecraft:honeycomb_block
setblock 2 183 331 minecraft:yellow_terracotta
fill 2 183 332 2 186 332 minecraft:honeycomb_block
setblock 2 183 336 minecraft:yellow_terracotta
fill 2 183 337 2 186 337 minecraft:honeycomb_block
setblock 2 183 351 minecraft:yellow_terracotta
fill 2 183 352 2 184 352 minecraft:honeycomb_block
setblock 2 183 356 minecraft:yellow_terracotta
setblock 3 183 330 minecraft:yellow_terracotta
fill 3 183 331 3 185 331 minecraft:honeycomb_block
setblock 3 183 335 minecraft:yellow_terracotta
fill 3 183 336 3 185 336 minecraft:honeycomb_block
setblock 5 183 323 minecraft:yellow_terracotta
setblock 6 183 323 minecraft:honeycomb_block
setblock 10 183 323 minecraft:yellow_terracotta
fill 11 183 323 11 186 323 minecraft:honeycomb_block
fill 12 183 363 12 185 363 minecraft:honeycomb_block
setblock 14 183 324 minecraft:yellow_terracotta
setblock 14 183 325 minecraft:honeycomb_block
fill 14 183 362 14 184 362 minecraft:honeycomb_block
setblock 15 183 323 minecraft:yellow_terracotta
fill 15 183 324 15 186 324 minecraft:honeycomb_block
setblock 15 183 363 minecraft:yellow_terracotta
fill 16 183 323 16 186 323 minecraft:honeycomb_block
setblock 16 183 361 minecraft:honeycomb_block
setblock 16 183 362 minecraft:yellow_terracotta
fill 16 183 363 16 186 363 minecraft:honeycomb_block
setblock 17 183 325 minecraft:honeycomb_block
setblock 17 183 361 minecraft:yellow_terracotta
fill 17 183 362 17 186 362 minecraft:honeycomb_block
setblock 18 183 325 minecraft:yellow_terracotta
fill 18 183 361 18 186 361 minecraft:honeycomb_block
fill 18 183 364 18 245 364 minecraft:honeycomb_block
setblock 19 183 324 minecraft:yellow_terracotta
setblock 19 183 325 minecraft:honeycomb_block
setblock 20 183 323 minecraft:yellow_terracotta
fill 20 183 324 20 184 324 minecraft:honeycomb_block
setblock 20 183 363 minecraft:yellow_terracotta
fill 21 183 323 21 185 323 minecraft:honeycomb_block
setblock 21 183 362 minecraft:yellow_terracotta
fill 21 183 363 21 186 363 minecraft:honeycomb_block
fill 22 183 362 22 186 362 minecraft:honeycomb_block
setblock 25 183 323 minecraft:honey_block
setblock 25 183 363 minecraft:yellow_terracotta
setblock 26 183 363 minecraft:honeycomb_block
setblock 34 183 363 minecraft:honeycomb_block
setblock 35 183 363 minecraft:yellow_terracotta
setblock 36 183 323 minecraft:honeycomb_block
fill 36 183 363 36 186 363 minecraft:honeycomb_block
setblock 37 183 352 minecraft:honeycomb_block
fill 38 183 332 38 183 334 minecraft:honeycomb_block
setblock 38 183 335 minecraft:yellow_terracotta
setblock 38 183 350 minecraft:yellow_terracotta
fill 38 183 351 38 185 351 minecraft:honeycomb_block
setblock 38 183 355 minecraft:yellow_terracotta
fill 38 183 356 38 185 356 minecraft:honeycomb_block
setblock 39 183 328 minecraft:honeycomb_block
setblock 39 183 329 minecraft:yellow_terracotta
fill 39 183 330 39 185 330 minecraft:honeycomb_block
setblock 39 183 333 minecraft:honeycomb_block
setblock 39 183 334 minecraft:yellow_terracotta
fill 39 183 335 39 186 335 minecraft:honeycomb_block
setblock 39 183 338 minecraft:honeycomb_block
setblock 39 183 339 minecraft:yellow_terracotta
fill 39 183 340 39 186 340 minecraft:honeycomb_block
setblock 39 183 344 minecraft:yellow_terracotta
fill 39 183 345 39 184 345 minecraft:honeycomb_block
setblock 39 183 349 minecraft:yellow_terracotta
fill 39 183 350 39 186 350 minecraft:honeycomb_block
setblock 39 183 354 minecraft:yellow_terracotta
fill 39 183 355 39 186 355 minecraft:honeycomb_block
setblock 40 183 323 minecraft:yellow_terracotta
setblock 40 183 328 minecraft:yellow_terracotta
fill 40 183 329 40 186 329 minecraft:honeycomb_block
setblock 40 183 333 minecraft:yellow_terracotta
fill 40 183 334 40 186 334 minecraft:honeycomb_block
setblock 40 183 338 minecraft:yellow_terracotta
fill 40 183 339 40 186 339 minecraft:honeycomb_block
setblock 40 183 343 minecraft:yellow_terracotta
fill 40 183 344 40 186 344 minecraft:honeycomb_block
setblock 40 183 348 minecraft:yellow_terracotta
fill 40 183 349 40 186 349 minecraft:honeycomb_block
setblock 40 183 353 minecraft:yellow_terracotta
fill 40 183 354 40 186 354 minecraft:honeycomb_block
setblock 40 183 358 minecraft:yellow_terracotta
fill 40 183 359 40 186 359 minecraft:honeycomb_block
setblock 40 183 363 minecraft:yellow_terracotta
setblock 41 183 323 minecraft:honeycomb_block
setblock 41 183 327 minecraft:yellow_terracotta
fill 41 183 328 41 186 328 minecraft:honeycomb_block
setblock 41 183 332 minecraft:yellow_terracotta
fill 41 183 333 41 186 333 minecraft:honeycomb_block
setblock 41 183 337 minecraft:yellow_terracotta
fill 41 183 338 41 186 338 minecraft:honeycomb_block
setblock 41 183 342 minecraft:yellow_terracotta
fill 41 183 343 41 186 343 minecraft:honeycomb_block
setblock 41 183 347 minecraft:yellow_terracotta
fill 41 183 348 41 186 348 minecraft:honeycomb_block
setblock 41 183 352 minecraft:yellow_terracotta
fill 41 183 353 41 186 353 minecraft:honeycomb_block
setblock 41 183 357 minecraft:yellow_terracotta
fill 41 183 358 41 186 358 minecraft:honeycomb_block
setblock 41 183 362 minecraft:yellow_terracotta
fill 0 184 325 0 238 325 minecraft:honeycomb_block
setblock 0 184 333 minecraft:yellow_concrete
setblock 1 184 326 minecraft:yellow_terracotta
fill 1 184 327 1 187 327 minecraft:honeycomb_block
setblock 1 184 331 minecraft:yellow_terracotta
fill 1 184 332 1 187 332 minecraft:honeycomb_block
setblock 1 184 336 minecraft:yellow_terracotta
fill 1 184 337 1 187 337 minecraft:honeycomb_block
setblock 1 184 341 minecraft:yellow_terracotta
fill 1 184 342 1 186 342 minecraft:honeycomb_block
setblock 1 184 346 minecraft:yellow_terracotta
fill 1 184 347 1 185 347 minecraft:honeycomb_block
setblock 1 184 351 minecraft:yellow_terracotta
fill 1 184 352 1 186 352 minecraft:honeycomb_block
setblock 1 184 356 minecraft:yellow_terracotta
fill 1 184 357 1 187 357 minecraft:honeycomb_block
setblock 2 184 325 minecraft:yellow_terracotta
fill 2 184 326 2 185 326 minecraft:honeycomb_block
setblock 2 184 330 minecraft:yellow_terracotta
fill 2 184 331 2 187 331 minecraft:honeycomb_block
setblock 2 184 335 minecraft:yellow_terracotta
fill 2 184 336 2 187 336 minecraft:honeycomb_block
setblock 2 184 340 minecraft:yellow_terracotta
setblock 2 184 351 minecraft:honeycomb_block
setblock 2 184 355 minecraft:yellow_terracotta
setblock 3 184 325 minecraft:light[level=15]
setblock 3 184 329 minecraft:yellow_terracotta
fill 3 184 330 3 185 330 minecraft:honeycomb_block
setblock 3 184 334 minecraft:yellow_terracotta
fill 3 184 335 3 185 335 minecraft:honeycomb_block
setblock 3 184 341 minecraft:light[level=15]
setblock 3 184 349 minecraft:light[level=15]
setblock 3 184 357 minecraft:light[level=15]
setblock 4 184 323 minecraft:yellow_terracotta
setblock 9 184 323 minecraft:yellow_terracotta
fill 10 184 323 10 187 323 minecraft:honeycomb_block
setblock 11 184 325 minecraft:light[level=15]
setblock 11 184 333 minecraft:light[level=15]
setblock 11 184 341 minecraft:light[level=15]
setblock 11 184 349 minecraft:light[level=15]
setblock 11 184 357 minecraft:light[level=15]
fill 11 184 363 11 186 363 minecraft:honeycomb_block
setblock 13 184 324 minecraft:yellow_terracotta
fill 13 184 362 13 185 362 minecraft:honeycomb_block
setblock 14 184 323 minecraft:yellow_terracotta
fill 14 184 324 14 187 324 minecraft:honeycomb_block
setblock 14 184 363 minecraft:yellow_terracotta
fill 15 184 323 15 187 323 minecraft:honeycomb_block
setblock 15 184 361 minecraft:honeycomb_block
setblock 15 184 362 minecraft:yellow_terracotta
fill 15 184 363 15 187 363 minecraft:honeycomb_block
setblock 16 184 361 minecraft:yellow_terracotta
fill 16 184 362 16 187 362 minecraft:honeycomb_block
setblock 17 184 325 minecraft:yellow_terracotta
fill 17 184 361 17 187 361 minecraft:honeycomb_block
setblock 18 184 324 minecraft:yellow_terracotta
setblock 18 184 325 minecraft:honeycomb_block
setblock 19 184 323 minecraft:yellow_terracotta
fill 19 184 324 19 185 324 minecraft:honeycomb_block
setblock 19 184 325 minecraft:light[level=15]
setblock 19 184 333 minecraft:light[level=15]
setblock 19 184 341 minecraft:light[level=15]
setblock 19 184 349 minecraft:light[level=15]
setblock 19 184 357 minecraft:light[level=15]
setblock 19 184 363 minecraft:yellow_terracotta
fill 20 184 323 20 186 323 minecraft:honeycomb_block
setblock 20 184 362 minecraft:yellow_terracotta
fill 20 184 363 20 187 363 minecraft:honeycomb_block
setblock 21 184 361 minecraft:yellow_terracotta
fill 21 184 362 21 187 362 minecraft:honeycomb_block
setblock 24 184 363 minecraft:yellow_terracotta
setblock 25 184 363 minecraft:honeycomb_block
setblock 27 184 325 minecraft:light[level=15]
setblock 27 184 333 minecraft:light[level=15]
setblock 27 184 341 minecraft:light[level=15]
setblock 27 184 349 minecraft:light[level=15]
setblock 27 184 357 minecraft:light[level=15]
setblock 33 184 363 minecraft:honeycomb_block
setblock 34 184 363 minecraft:yellow_terracotta
setblock 35 184 325 minecraft:light[level=15]
setblock 35 184 333 minecraft:light[level=15]
setblock 35 184 341 minecraft:light[level=15]
setblock 35 184 349 minecraft:light[level=15]
setblock 35 184 357 minecraft:light[level=15]
fill 35 184 363 35 187 363 minecraft:honeycomb_block
fill 38 184 332 38 184 333 minecraft:honeycomb_block
setblock 38 184 334 minecraft:yellow_terracotta
fill 38 184 335 38 186 336 minecraft:honeycomb_block
setblock 38 184 349 minecraft:yellow_terracotta
setblock 38 184 350 minecraft:honeycomb_block
setblock 38 184 354 minecraft:yellow_terracotta
fill 38 184 355 38 185 355 minecraft:honeycomb_block
fill 39 184 322 39 308 322 minecraft:honeycomb_block
setblock 39 184 323 minecraft:yellow_terracotta
setblock 39 184 329 minecraft:honeycomb_block
setblock 39 184 333 minecraft:yellow_terracotta
fill 39 184 334 39 187 334 minecraft:honeycomb_block
setblock 39 184 338 minecraft:yellow_terracotta
fill 39 184 339 39 187 339 minecraft:honeycomb_block
setblock 39 184 343 minecraft:yellow_terracotta
setblock 39 184 344 minecraft:honeycomb_block
setblock 39 184 348 minecraft:yellow_terracotta
fill 39 184 349 39 185 349 minecraft:honeycomb_block
setblock 39 184 353 minecraft:yellow_terracotta
fill 39 184 354 39 186 354 minecraft:honeycomb_block
setblock 39 184 358 minecraft:yellow_terracotta
setblock 39 184 363 minecraft:yellow_terracotta
setblock 40 184 327 minecraft:yellow_terracotta
fill 40 184 328 40 185 328 minecraft:honeycomb_block
setblock 40 184 332 minecraft:yellow_terracotta
fill 40 184 333 40 187 333 minecraft:honeycomb_block
setblock 40 184 337 minecraft:yellow_terracotta
fill 40 184 338 40 187 338 minecraft:honeycomb_block
setblock 40 184 342 minecraft:yellow_terracotta
fill 40 184 343 40 187 343 minecraft:honeycomb_block
setblock 40 184 347 minecraft:yellow_terracotta
fill 40 184 348 40 186 348 minecraft:honeycomb_block
setblock 40 184 352 minecraft:yellow_terracotta
fill 40 184 353 40 187 353 minecraft:honeycomb_block
setblock 40 184 357 minecraft:yellow_terracotta
fill 40 184 358 40 187 358 minecraft:honeycomb_block
setblock 40 184 364 minecraft:orange_terracotta
setblock 41 184 326 minecraft:yellow_terracotta
fill 41 184 327 41 186 327 minecraft:honeycomb_block
setblock 41 184 331 minecraft:yellow_terracotta
fill 41 184 332 41 187 332 minecraft:honeycomb_block
setblock 41 184 336 minecraft:yellow_terracotta
fill 41 184 337 41 187 337 minecraft:honeycomb_block
setblock 41 184 341 minecraft:yellow_terracotta
fill 41 184 342 41 187 342 minecraft:honeycomb_block
setblock 41 184 346 minecraft:yellow_terracotta
fill 41 184 347 41 187 347 minecraft:honeycomb_block
setblock 41 184 351 minecraft:yellow_terracotta
fill 41 184 352 41 187 352 minecraft:honeycomb_block
setblock 41 184 356 minecraft:yellow_terracotta
fill 41 184 357 41 187 357 minecraft:honeycomb_block
setblock 41 184 361 minecraft:yellow_terracotta
fill 0 185 330 0 203 330 minecraft:honeycomb_block
fill 0 185 333 0 242 333 minecraft:honeycomb_block
setblock 1 185 325 minecraft:yellow_terracotta
fill 1 185 326 1 187 326 minecraft:honeycomb_block
setblock 1 185 330 minecraft:yellow_terracotta
fill 1 185 331 1 188 331 minecraft:honeycomb_block
setblock 1 185 335 minecraft:yellow_terracotta
fill 1 185 336 1 188 336 minecraft:honeycomb_block
setblock 1 185 340 minecraft:yellow_terracotta
fill 1 185 341 1 188 341 minecraft:honeycomb_block
setblock 1 185 345 minecraft:yellow_terracotta
setblock 1 185 346 minecraft:honeycomb_block
setblock 1 185 350 minecraft:yellow_terracotta
fill 1 185 351 1 186 351 minecraft:honeycomb_block
setblock 1 185 355 minecraft:yellow_terracotta
fill 1 185 356 1 187 356 minecraft:honeycomb_block
setblock 1 185 359 minecraft:honeycomb_block
setblock 1 185 360 minecraft:yellow_terracotta
setblock 2 185 329 minecraft:yellow_terracotta
fill 2 185 330 2 187 330 minecraft:honeycomb_block
setblock 2 185 334 minecraft:yellow_terracotta
fill 2 185 335 2 188 335 minecraft:honeycomb_block
setblock 2 185 339 minecraft:yellow_terracotta
setblock 3 185 333 minecraft:yellow_terracotta
fill 3 185 334 3 186 334 minecraft:honeycomb_block
setblock 4 185 363 minecraft:honey_block
setblock 9 185 323 minecraft:honeycomb_block
setblock 11 185 322 minecraft:yellow_terracotta
setblock 12 185 324 minecraft:yellow_terracotta
setblock 13 185 323 minecraft:yellow_terracotta
fill 13 185 324 13 186 324 minecraft:honeycomb_block
setblock 13 185 363 minecraft:yellow_terracotta
fill 14 185 323 14 188 323 minecraft:honeycomb_block
setblock 14 185 362 minecraft:yellow_terracotta
fill 14 185 363 14 188 363 minecraft:honeycomb_block
setblock 15 185 361 minecraft:yellow_terracotta
fill 15 185 362 15 188 362 minecraft:honeycomb_block
fill 16 185 361 16 188 361 minecraft:honeycomb_block
setblock 17 185 324 minecraft:yellow_terracotta
setblock 18 185 323 minecraft:yellow_terracotta
fill 18 185 324 18 186 324 minecraft:honeycomb_block
setblock 18 185 363 minecraft:yellow_terracotta
fill 19 185 323 19 187 323 minecraft:honeycomb_block
setblock 19 185 362 minecraft:yellow_terracotta
fill 19 185 363 19 188 363 minecraft:honeycomb_block
setblock 20 185 361 minecraft:yellow_terracotta
fill 20 185 362 20 188 362 minecraft:honeycomb_block
setblock 21 185 361 minecraft:honeycomb_block
schedule function dropper:buildpart/72_7 1t
