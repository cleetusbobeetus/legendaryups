fill 507 165 266 508 167 267 minecraft:red_concrete
fill 507 165 268 508 165 268 minecraft:white_concrete
fill 509 165 229 510 165 230 minecraft:red_concrete
fill 509 165 231 511 169 231 minecraft:white_concrete
fill 509 165 266 510 165 266 minecraft:red_concrete
fill 509 165 267 511 169 267 minecraft:white_concrete
fill 511 165 230 511 170 230 minecraft:white_concrete
fill 511 165 266 511 170 266 minecraft:white_concrete
fill 470 166 263 470 308 263 minecraft:lime_terracotta
fill 470 166 265 470 308 265 minecraft:white_concrete
fill 471 166 232 472 169 232 minecraft:red_concrete
fill 471 166 268 472 169 268 minecraft:red_concrete
fill 472 166 265 473 166 265 minecraft:red_concrete
fill 473 166 229 473 166 230 minecraft:red_concrete
setblock 473 166 238 minecraft:light[level=12]
setblock 473 166 245 minecraft:light[level=12]
setblock 473 166 252 minecraft:light[level=12]
setblock 473 166 259 minecraft:light[level=12]
fill 474 166 229 474 170 230 minecraft:white_concrete
fill 474 166 265 474 170 266 minecraft:white_concrete
setblock 480 166 231 minecraft:light[level=12]
setblock 480 166 238 minecraft:light[level=12]
setblock 480 166 245 minecraft:light[level=12]
setblock 480 166 252 minecraft:light[level=12]
setblock 480 166 259 minecraft:light[level=12]
setblock 480 166 266 minecraft:light[level=12]
setblock 487 166 231 minecraft:light[level=12]
setblock 487 166 245 minecraft:light[level=12]
setblock 487 166 252 minecraft:light[level=12]
setblock 487 166 259 minecraft:light[level=12]
setblock 487 166 266 minecraft:light[level=12]
setblock 494 166 231 minecraft:light[level=12]
setblock 494 166 238 minecraft:light[level=12]
setblock 494 166 245 minecraft:light[level=12]
setblock 494 166 259 minecraft:light[level=12]
setblock 494 166 266 minecraft:light[level=12]
setblock 501 166 231 minecraft:light[level=12]
setblock 501 166 238 minecraft:light[level=12]
setblock 501 166 245 minecraft:light[level=12]
setblock 501 166 252 minecraft:light[level=12]
setblock 501 166 259 minecraft:light[level=12]
setblock 501 166 266 minecraft:light[level=12]
fill 506 166 249 507 167 250 minecraft:yellow_concrete
fill 507 166 232 508 169 232 minecraft:red_concrete
fill 507 166 268 508 169 268 minecraft:red_concrete
setblock 508 166 233 minecraft:white_concrete
setblock 508 166 238 minecraft:light[level=12]
setblock 508 166 245 minecraft:light[level=12]
setblock 508 166 252 minecraft:light[level=12]
setblock 508 166 259 minecraft:light[level=12]
fill 508 166 265 509 166 265 minecraft:red_concrete
fill 509 166 229 509 166 230 minecraft:red_concrete
setblock 509 166 266 minecraft:red_concrete
fill 510 166 229 510 170 230 minecraft:white_concrete
fill 510 166 265 510 170 266 minecraft:white_concrete
fill 512 166 264 512 308 264 minecraft:white_concrete
fill 470 167 264 470 308 264 minecraft:white_concrete
fill 471 167 266 472 167 266 minecraft:red_concrete
fill 472 167 233 473 170 233 minecraft:red_concrete
setblock 472 167 265 minecraft:red_concrete
fill 472 167 269 473 170 269 minecraft:red_concrete
fill 473 167 229 473 171 230 minecraft:white_concrete
fill 473 167 232 473 171 232 minecraft:red_concrete
fill 473 167 265 473 171 266 minecraft:white_concrete
fill 473 167 268 473 171 268 minecraft:red_concrete
fill 476 167 245 477 168 246 minecraft:pink_concrete
fill 508 167 233 509 170 233 minecraft:red_concrete
setblock 508 167 265 minecraft:red_concrete
fill 508 167 269 509 170 269 minecraft:red_concrete
fill 509 167 229 509 171 230 minecraft:white_concrete
fill 509 167 232 509 171 232 minecraft:red_concrete
fill 509 167 265 509 171 266 minecraft:white_concrete
fill 509 167 268 509 171 268 minecraft:red_concrete
setblock 471 168 230 minecraft:red_concrete
setblock 471 168 266 minecraft:red_concrete
fill 472 168 229 472 172 230 minecraft:white_concrete
fill 472 168 265 472 172 266 minecraft:white_concrete
setblock 474 168 232 minecraft:white_concrete
fill 474 168 233 474 172 233 minecraft:red_concrete
setblock 474 168 268 minecraft:white_concrete
fill 474 168 269 474 172 269 minecraft:red_concrete
setblock 507 168 230 minecraft:red_concrete
fill 507 168 266 507 168 267 minecraft:red_concrete
fill 508 168 229 508 172 230 minecraft:white_concrete
fill 508 168 265 508 172 266 minecraft:white_concrete
fill 508 168 267 508 169 267 minecraft:red_concrete
setblock 510 168 232 minecraft:white_concrete
fill 510 168 233 510 172 233 minecraft:red_concrete
setblock 510 168 268 minecraft:white_concrete
fill 510 168 269 510 172 269 minecraft:red_concrete
fill 471 169 230 471 173 230 minecraft:white_concrete
fill 471 169 266 471 173 266 minecraft:white_concrete
setblock 473 169 239 minecraft:light[level=15]
setblock 473 169 247 minecraft:light[level=15]
setblock 473 169 255 minecraft:light[level=15]
setblock 473 169 263 minecraft:light[level=15]
fill 474 169 232 475 172 232 minecraft:red_concrete
fill 474 169 268 475 172 268 minecraft:red_concrete
setblock 481 169 231 minecraft:light[level=15]
setblock 481 169 239 minecraft:light[level=15]
setblock 481 169 247 minecraft:light[level=15]
setblock 481 169 255 minecraft:light[level=15]
setblock 481 169 263 minecraft:light[level=15]
setblock 489 169 231 minecraft:light[level=15]
setblock 489 169 247 minecraft:light[level=15]
setblock 489 169 255 minecraft:light[level=15]
setblock 489 169 263 minecraft:light[level=15]
setblock 497 169 231 minecraft:light[level=15]
setblock 497 169 239 minecraft:light[level=15]
setblock 497 169 255 minecraft:light[level=15]
setblock 497 169 263 minecraft:light[level=15]
setblock 505 169 231 minecraft:light[level=15]
setblock 505 169 239 minecraft:light[level=15]
setblock 505 169 247 minecraft:light[level=15]
setblock 505 169 255 minecraft:light[level=15]
setblock 505 169 263 minecraft:light[level=15]
fill 507 169 230 507 173 230 minecraft:white_concrete
fill 507 169 266 507 173 266 minecraft:white_concrete
setblock 507 169 267 minecraft:red_concrete
fill 510 169 232 511 172 232 minecraft:red_concrete
fill 510 169 268 511 172 268 minecraft:red_concrete
fill 471 170 231 471 174 232 minecraft:white_concrete
fill 471 170 267 471 174 268 minecraft:white_concrete
fill 472 170 231 472 174 231 minecraft:white_concrete
setblock 472 170 232 minecraft:red_concrete
fill 472 170 267 472 174 267 minecraft:white_concrete
setblock 472 170 268 minecraft:red_concrete
fill 473 170 231 475 174 231 minecraft:red_concrete
fill 473 170 267 475 174 267 minecraft:red_concrete
fill 507 170 231 507 174 232 minecraft:white_concrete
fill 507 170 267 507 174 268 minecraft:white_concrete
fill 508 170 231 508 174 231 minecraft:white_concrete
setblock 508 170 232 minecraft:red_concrete
fill 508 170 267 508 174 267 minecraft:white_concrete
setblock 508 170 268 minecraft:red_concrete
fill 509 170 231 511 174 231 minecraft:red_concrete
fill 509 170 267 511 174 267 minecraft:red_concrete
fill 472 171 232 472 175 233 minecraft:white_concrete
fill 472 171 268 472 175 269 minecraft:white_concrete
setblock 473 171 233 minecraft:red_concrete
setblock 473 171 269 minecraft:red_concrete
setblock 474 171 229 minecraft:white_concrete
fill 474 171 230 475 174 230 minecraft:red_concrete
setblock 474 171 265 minecraft:white_concrete
fill 474 171 266 475 174 266 minecraft:red_concrete
fill 508 171 232 508 175 233 minecraft:white_concrete
fill 508 171 268 508 175 269 minecraft:white_concrete
setblock 509 171 233 minecraft:red_concrete
setblock 509 171 269 minecraft:red_concrete
setblock 510 171 229 minecraft:white_concrete
fill 510 171 230 511 174 230 minecraft:red_concrete
setblock 510 171 265 minecraft:white_concrete
fill 510 171 266 511 174 266 minecraft:red_concrete
fill 473 172 229 473 176 230 minecraft:red_concrete
fill 473 172 232 473 176 233 minecraft:white_concrete
setblock 473 172 238 minecraft:light[level=12]
setblock 473 172 245 minecraft:light[level=12]
setblock 473 172 252 minecraft:light[level=12]
setblock 473 172 259 minecraft:light[level=12]
fill 473 172 265 473 176 266 minecraft:red_concrete
fill 473 172 268 473 176 269 minecraft:white_concrete
setblock 474 172 229 minecraft:red_concrete
fill 474 172 265 474 175 265 minecraft:red_concrete
setblock 480 172 231 minecraft:light[level=12]
setblock 480 172 238 minecraft:light[level=12]
setblock 480 172 245 minecraft:light[level=12]
setblock 480 172 252 minecraft:light[level=12]
setblock 480 172 259 minecraft:light[level=12]
setblock 480 172 266 minecraft:light[level=12]
setblock 487 172 231 minecraft:light[level=12]
setblock 487 172 245 minecraft:light[level=12]
setblock 487 172 252 minecraft:light[level=12]
setblock 487 172 259 minecraft:light[level=12]
setblock 487 172 266 minecraft:light[level=12]
setblock 494 172 231 minecraft:light[level=12]
setblock 494 172 238 minecraft:light[level=12]
setblock 494 172 245 minecraft:light[level=12]
setblock 494 172 259 minecraft:light[level=12]
setblock 494 172 266 minecraft:light[level=12]
setblock 501 172 231 minecraft:light[level=12]
setblock 501 172 238 minecraft:light[level=12]
setblock 501 172 245 minecraft:light[level=12]
setblock 501 172 252 minecraft:light[level=12]
setblock 501 172 259 minecraft:light[level=12]
setblock 501 172 266 minecraft:light[level=12]
setblock 508 172 238 minecraft:light[level=12]
setblock 508 172 245 minecraft:light[level=12]
setblock 508 172 252 minecraft:light[level=12]
setblock 508 172 259 minecraft:light[level=12]
fill 509 172 229 509 176 230 minecraft:red_concrete
fill 509 172 232 509 176 233 minecraft:white_concrete
fill 509 172 265 509 176 266 minecraft:red_concrete
fill 509 172 268 509 176 269 minecraft:white_concrete
fill 510 172 229 510 175 229 minecraft:red_concrete
fill 510 172 265 510 175 265 minecraft:red_concrete
fill 472 173 229 472 177 229 minecraft:red_concrete
setblock 472 173 230 minecraft:white_concrete
fill 472 173 265 472 177 265 minecraft:red_concrete
setblock 472 173 266 minecraft:white_concrete
fill 474 173 229 474 184 229 minecraft:brown_concrete
fill 474 173 232 474 177 233 minecraft:white_concrete
fill 474 173 268 474 177 269 minecraft:white_concrete
setblock 475 173 232 minecraft:red_concrete
setblock 475 173 268 minecraft:red_concrete
fill 495 173 250 495 194 250 minecraft:white_concrete
fill 508 173 229 508 176 229 minecraft:red_concrete
setblock 508 173 230 minecraft:white_concrete
fill 508 173 265 508 177 265 minecraft:red_concrete
setblock 508 173 266 minecraft:white_concrete
fill 510 173 232 510 177 233 minecraft:white_concrete
fill 510 173 268 510 177 269 minecraft:white_concrete
setblock 511 173 232 minecraft:red_concrete
fill 511 173 249 511 182 249 minecraft:brown_concrete
setblock 511 173 268 minecraft:red_concrete
fill 471 174 230 472 177 230 minecraft:red_concrete
fill 471 174 266 472 177 266 minecraft:red_concrete
fill 475 174 232 475 178 232 minecraft:white_concrete
fill 475 174 268 475 178 268 minecraft:white_concrete
fill 507 174 230 508 177 230 minecraft:red_concrete
fill 507 174 266 508 177 266 minecraft:red_concrete
fill 511 174 232 511 178 232 minecraft:white_concrete
fill 511 174 268 511 178 268 minecraft:white_concrete
fill 471 175 231 472 179 231 minecraft:red_concrete
setblock 471 175 232 minecraft:white_concrete
fill 471 175 267 472 179 267 minecraft:red_concrete
setblock 471 175 268 minecraft:white_concrete
fill 473 175 231 475 179 231 minecraft:white_concrete
fill 473 175 267 475 179 267 minecraft:white_concrete
setblock 474 175 230 minecraft:red_concrete
setblock 474 175 266 minecraft:red_concrete
fill 475 175 230 475 180 230 minecraft:white_concrete
fill 475 175 266 475 180 266 minecraft:white_concrete
fill 507 175 231 508 179 231 minecraft:red_concrete
setblock 507 175 232 minecraft:white_concrete
fill 507 175 267 508 179 267 minecraft:red_concrete
setblock 507 175 268 minecraft:white_concrete
fill 509 175 231 511 179 231 minecraft:white_concrete
fill 509 175 267 511 179 267 minecraft:white_concrete
setblock 510 175 230 minecraft:red_concrete
setblock 510 175 266 minecraft:red_concrete
fill 511 175 230 511 180 230 minecraft:white_concrete
fill 511 175 266 511 180 266 minecraft:white_concrete
fill 471 176 232 472 179 232 minecraft:red_concrete
fill 471 176 268 472 179 268 minecraft:red_concrete
setblock 472 176 233 minecraft:white_concrete
setblock 472 176 269 minecraft:white_concrete
setblock 473 176 239 minecraft:light[level=15]
setblock 473 176 247 minecraft:light[level=15]
setblock 473 176 255 minecraft:light[level=15]
setblock 473 176 263 minecraft:light[level=15]
fill 474 176 230 474 180 230 minecraft:white_concrete
fill 474 176 265 474 180 266 minecraft:white_concrete
setblock 481 176 231 minecraft:light[level=15]
setblock 481 176 239 minecraft:light[level=15]
setblock 481 176 247 minecraft:light[level=15]
setblock 481 176 255 minecraft:light[level=15]
setblock 481 176 263 minecraft:light[level=15]
setblock 489 176 231 minecraft:light[level=15]
setblock 489 176 247 minecraft:light[level=15]
setblock 489 176 255 minecraft:light[level=15]
setblock 489 176 263 minecraft:light[level=15]
setblock 497 176 231 minecraft:light[level=15]
setblock 497 176 239 minecraft:light[level=15]
setblock 497 176 255 minecraft:light[level=15]
setblock 497 176 263 minecraft:light[level=15]
setblock 505 176 231 minecraft:light[level=15]
setblock 505 176 239 minecraft:light[level=15]
setblock 505 176 247 minecraft:light[level=15]
setblock 505 176 255 minecraft:light[level=15]
setblock 505 176 263 minecraft:light[level=15]
fill 507 176 232 508 179 232 minecraft:red_concrete
fill 507 176 268 508 179 268 minecraft:red_concrete
setblock 508 176 233 minecraft:white_concrete
setblock 508 176 269 minecraft:white_concrete
fill 510 176 229 510 180 230 minecraft:white_concrete
fill 510 176 265 510 180 266 minecraft:white_concrete
fill 472 177 233 473 180 233 minecraft:red_concrete
fill 472 177 269 473 180 269 minecraft:red_concrete
fill 473 177 229 473 180 230 minecraft:white_concrete
fill 473 177 232 473 180 232 minecraft:red_concrete
fill 473 177 265 473 180 266 minecraft:white_concrete
fill 473 177 268 473 180 268 minecraft:red_concrete
fill 508 177 229 508 185 229 minecraft:brown_terracotta
fill 508 177 233 509 180 233 minecraft:red_concrete
fill 508 177 269 509 180 269 minecraft:red_concrete
fill 509 177 229 509 180 230 minecraft:white_concrete
fill 509 177 232 509 180 232 minecraft:red_concrete
fill 509 177 265 509 180 266 minecraft:white_concrete
fill 509 177 268 509 180 268 minecraft:red_concrete
setblock 471 178 230 minecraft:red_concrete
setblock 471 178 266 minecraft:red_concrete
fill 472 178 229 472 180 230 minecraft:white_concrete
fill 472 178 265 472 180 266 minecraft:white_concrete
setblock 473 178 238 minecraft:light[level=12]
setblock 473 178 245 minecraft:light[level=12]
setblock 473 178 252 minecraft:light[level=12]
setblock 473 178 259 minecraft:light[level=12]
setblock 474 178 232 minecraft:white_concrete
fill 474 178 233 474 182 233 minecraft:red_concrete
setblock 474 178 268 minecraft:white_concrete
fill 474 178 269 474 180 269 minecraft:red_concrete
setblock 480 178 231 minecraft:light[level=12]
setblock 480 178 238 minecraft:light[level=12]
setblock 480 178 245 minecraft:light[level=12]
setblock 480 178 252 minecraft:light[level=12]
setblock 480 178 259 minecraft:light[level=12]
setblock 480 178 266 minecraft:light[level=12]
setblock 487 178 231 minecraft:light[level=12]
setblock 487 178 245 minecraft:light[level=12]
setblock 487 178 252 minecraft:light[level=12]
setblock 487 178 259 minecraft:light[level=12]
setblock 487 178 266 minecraft:light[level=12]
fill 489 178 265 491 179 265 minecraft:yellow_concrete
fill 490 178 264 490 179 264 minecraft:yellow_concrete
fill 490 178 266 490 179 266 minecraft:yellow_concrete
setblock 494 178 231 minecraft:light[level=12]
setblock 494 178 238 minecraft:light[level=12]
setblock 494 178 245 minecraft:light[level=12]
setblock 494 178 259 minecraft:light[level=12]
setblock 494 178 266 minecraft:light[level=12]
setblock 501 178 231 minecraft:light[level=12]
setblock 501 178 238 minecraft:light[level=12]
setblock 501 178 245 minecraft:light[level=12]
setblock 501 178 252 minecraft:light[level=12]
setblock 501 178 259 minecraft:light[level=12]
setblock 501 178 266 minecraft:light[level=12]
setblock 507 178 230 minecraft:red_concrete
setblock 507 178 266 minecraft:red_concrete
fill 508 178 230 508 180 230 minecraft:white_concrete
setblock 508 178 238 minecraft:light[level=12]
setblock 508 178 245 minecraft:light[level=12]
setblock 508 178 252 minecraft:light[level=12]
setblock 508 178 259 minecraft:light[level=12]
fill 508 178 265 508 182 266 minecraft:white_concrete
setblock 510 178 232 minecraft:white_concrete
fill 510 178 233 510 180 233 minecraft:red_concrete
setblock 510 178 268 minecraft:white_concrete
fill 510 178 269 510 180 269 minecraft:red_concrete
fill 471 179 230 471 180 230 minecraft:white_concrete
fill 471 179 266 471 180 266 minecraft:white_concrete
fill 474 179 232 475 182 232 minecraft:red_concrete
fill 474 179 268 475 180 268 minecraft:red_concrete
fill 497 179 250 497 194 250 minecraft:white_concrete
fill 507 179 230 507 180 230 minecraft:white_concrete
fill 507 179 266 507 183 266 minecraft:white_concrete
fill 510 179 232 511 180 232 minecraft:red_concrete
fill 510 179 268 511 180 268 minecraft:red_concrete
fill 471 180 231 471 180 232 minecraft:white_concrete
fill 471 180 267 471 180 268 minecraft:white_concrete
setblock 472 180 231 minecraft:white_concrete
setblock 472 180 232 minecraft:red_concrete
setblock 472 180 267 minecraft:white_concrete
setblock 472 180 268 minecraft:red_concrete
fill 473 180 231 475 180 231 minecraft:red_concrete
fill 473 180 267 475 180 267 minecraft:red_concrete
fill 507 180 231 507 180 232 minecraft:white_concrete
fill 507 180 267 507 180 268 minecraft:white_concrete
setblock 508 180 231 minecraft:white_concrete
setblock 508 180 232 minecraft:red_concrete
setblock 508 180 267 minecraft:white_concrete
setblock 508 180 268 minecraft:red_concrete
fill 509 180 231 511 180 231 minecraft:red_concrete
fill 509 180 267 511 180 267 minecraft:red_concrete
fill 471 181 229 473 181 269 minecraft:black_concrete
fill 474 181 230 511 181 231 minecraft:black_concrete
setblock 474 181 265 minecraft:white_concrete
fill 474 181 266 475 184 266 minecraft:red_concrete
fill 474 181 267 511 181 269 minecraft:black_concrete
fill 475 181 229 507 181 229 minecraft:black_concrete
fill 496 181 250 496 194 250 minecraft:white_concrete
fill 507 181 232 508 185 232 minecraft:white_concrete
fill 508 181 233 508 186 233 minecraft:white_concrete
fill 509 181 229 511 181 229 minecraft:black_concrete
fill 509 181 232 510 181 266 minecraft:black_concrete
fill 511 181 232 511 181 248 minecraft:black_concrete
fill 511 181 250 511 181 266 minecraft:black_concrete
fill 471 182 229 473 182 269 minecraft:gray_concrete
fill 474 182 230 511 182 231 minecraft:gray_concrete
fill 474 182 265 474 185 265 minecraft:red_concrete
fill 474 182 267 511 182 269 minecraft:gray_concrete
fill 475 182 229 490 182 229 minecraft:gray_concrete
fill 491 182 229 491 193 229 minecraft:brown_concrete
fill 492 182 229 507 182 229 minecraft:gray_concrete
fill 502 182 241 503 183 241 minecraft:light_blue_concrete
fill 509 182 229 511 182 229 minecraft:gray_concrete
fill 509 182 232 510 182 266 minecraft:gray_concrete
fill 511 182 232 511 182 248 minecraft:gray_concrete
fill 511 182 250 511 182 266 minecraft:gray_concrete
fill 471 183 230 472 183 232 minecraft:white_concrete
setblock 471 183 233 minecraft:magenta_concrete
setblock 471 183 248 minecraft:yellow_concrete
fill 471 183 266 472 183 268 minecraft:white_concrete
fill 472 183 229 473 186 229 minecraft:red_concrete
fill 472 183 233 474 186 233 minecraft:white_concrete
setblock 472 183 243 minecraft:red_concrete
fill 472 183 265 473 186 265 minecraft:red_concrete
fill 472 183 269 474 186 269 minecraft:white_concrete
fill 473 183 230 475 184 231 minecraft:red_concrete
fill 473 183 232 474 186 232 minecraft:white_concrete
setblock 473 183 239 minecraft:light[level=15]
setblock 473 183 247 minecraft:light[level=15]
setblock 473 183 255 minecraft:light[level=15]
setblock 473 183 263 minecraft:light[level=15]
fill 473 183 266 473 184 267 minecraft:red_concrete
fill 473 183 268 474 186 268 minecraft:white_concrete
fill 474 183 267 475 184 267 minecraft:red_concrete
setblock 475 183 232 minecraft:red_concrete
setblock 475 183 268 minecraft:red_concrete
setblock 477 183 229 minecraft:white_concrete
setblock 481 183 231 minecraft:light[level=15]
setblock 481 183 239 minecraft:light[level=15]
setblock 481 183 247 minecraft:light[level=15]
setblock 481 183 255 minecraft:light[level=15]
setblock 481 183 263 minecraft:light[level=15]
fill 483 183 230 483 184 230 minecraft:brown_concrete
setblock 483 183 268 minecraft:orange_concrete
fill 486 183 268 486 184 268 minecraft:brown_concrete
setblock 488 183 229 minecraft:light_blue_concrete
setblock 489 183 231 minecraft:light[level=15]
setblock 489 183 247 minecraft:light[level=15]
setblock 489 183 255 minecraft:light[level=15]
setblock 489 183 263 minecraft:light[level=15]
setblock 489 183 268 minecraft:red_concrete
setblock 493 183 231 minecraft:lime_concrete
setblock 497 183 231 minecraft:light[level=15]
setblock 497 183 239 minecraft:light[level=15]
setblock 497 183 255 minecraft:light[level=15]
setblock 497 183 263 minecraft:light[level=15]
setblock 503 183 269 minecraft:white_concrete
setblock 505 183 231 minecraft:light[level=15]
setblock 505 183 239 minecraft:light[level=15]
setblock 505 183 247 minecraft:light[level=15]
setblock 505 183 255 minecraft:light[level=15]
setblock 505 183 263 minecraft:light[level=15]
fill 507 183 230 508 183 231 minecraft:white_concrete
fill 507 183 267 508 184 268 minecraft:white_concrete
fill 508 183 265 510 185 265 minecraft:red_concrete
setblock 508 183 266 minecraft:white_concrete
fill 508 183 269 510 186 269 minecraft:white_concrete
fill 509 183 229 510 184 231 minecraft:red_concrete
fill 509 183 232 510 186 233 minecraft:white_concrete
setblock 509 183 257 minecraft:orange_concrete
fill 509 183 266 511 184 267 minecraft:red_concrete
fill 509 183 268 510 186 268 minecraft:white_concrete
setblock 510 183 243 minecraft:magenta_concrete
fill 510 183 244 510 184 244 minecraft:brown_concrete
fill 510 183 252 510 184 252 minecraft:brown_concrete
fill 511 183 230 511 183 232 minecraft:red_concrete
fill 511 183 247 511 184 247 minecraft:brown_concrete
setblock 511 183 268 minecraft:red_concrete
fill 471 184 230 472 187 230 minecraft:red_concrete
fill 471 184 231 472 184 232 minecraft:white_concrete
fill 471 184 266 472 187 266 minecraft:red_concrete
fill 471 184 267 472 184 268 minecraft:white_concrete
setblock 473 184 238 minecraft:light[level=12]
setblock 473 184 245 minecraft:light[level=12]
setblock 473 184 252 minecraft:light[level=12]
setblock 473 184 259 minecraft:light[level=12]
fill 475 184 232 475 188 232 minecraft:white_concrete
fill 475 184 268 475 188 268 minecraft:white_concrete
setblock 480 184 231 minecraft:light[level=12]
setblock 480 184 238 minecraft:light[level=12]
setblock 480 184 245 minecraft:light[level=12]
setblock 480 184 252 minecraft:light[level=12]
setblock 480 184 259 minecraft:light[level=12]
setblock 480 184 266 minecraft:light[level=12]
setblock 487 184 231 minecraft:light[level=12]
setblock 487 184 245 minecraft:light[level=12]
setblock 487 184 252 minecraft:light[level=12]
setblock 487 184 259 minecraft:light[level=12]
setblock 487 184 266 minecraft:light[level=12]
setblock 494 184 231 minecraft:light[level=12]
setblock 494 184 238 minecraft:light[level=12]
setblock 494 184 245 minecraft:light[level=12]
setblock 494 184 259 minecraft:light[level=12]
setblock 494 184 266 minecraft:light[level=12]
setblock 501 184 231 minecraft:light[level=12]
setblock 501 184 238 minecraft:light[level=12]
setblock 501 184 245 minecraft:light[level=12]
setblock 501 184 252 minecraft:light[level=12]
setblock 501 184 259 minecraft:light[level=12]
setblock 501 184 266 minecraft:light[level=12]
fill 502 184 229 502 192 229 minecraft:brown_concrete
fill 507 184 230 508 187 230 minecraft:red_concrete
fill 507 184 231 508 184 231 minecraft:white_concrete
fill 507 184 266 508 187 266 minecraft:red_concrete
setblock 508 184 238 minecraft:light[level=12]
setblock 508 184 245 minecraft:light[level=12]
setblock 508 184 252 minecraft:light[level=12]
setblock 508 184 259 minecraft:light[level=12]
fill 511 184 230 511 184 231 minecraft:red_concrete
fill 511 184 232 511 188 232 minecraft:white_concrete
fill 511 184 268 511 188 268 minecraft:white_concrete
fill 471 185 231 472 189 231 minecraft:red_concrete
fill 471 185 232 472 185 232 minecraft:white_concrete
fill 471 185 267 472 189 267 minecraft:red_concrete
fill 471 185 268 472 185 268 minecraft:white_concrete
fill 473 185 230 474 185 230 minecraft:red_concrete
fill 473 185 231 475 189 231 minecraft:white_concrete
fill 473 185 266 474 185 266 minecraft:red_concrete
fill 473 185 267 475 189 267 minecraft:white_concrete
setblock 474 185 229 minecraft:red_concrete
fill 475 185 230 475 190 230 minecraft:white_concrete
fill 475 185 266 475 190 266 minecraft:white_concrete
fill 507 185 231 508 189 231 minecraft:red_concrete
fill 507 185 267 508 189 267 minecraft:red_concrete
fill 507 185 268 508 185 268 minecraft:white_concrete
fill 509 185 229 510 185 230 minecraft:red_concrete
fill 509 185 231 511 189 231 minecraft:white_concrete
fill 509 185 266 510 185 266 minecraft:red_concrete
fill 509 185 267 511 189 267 minecraft:white_concrete
fill 511 185 230 511 190 230 minecraft:white_concrete
fill 511 185 266 511 190 266 minecraft:white_concrete
fill 471 186 232 472 189 232 minecraft:red_concrete
fill 471 186 268 472 189 268 minecraft:red_concrete
setblock 473 186 230 minecraft:red_concrete
setblock 473 186 266 minecraft:red_concrete
fill 474 186 229 474 190 230 minecraft:white_concrete
fill 474 186 265 474 190 266 minecraft:white_concrete
fill 507 186 232 508 189 232 minecraft:red_concrete
fill 507 186 268 508 189 268 minecraft:red_concrete
fill 508 186 229 509 186 229 minecraft:red_concrete
fill 508 186 265 509 186 265 minecraft:red_concrete
setblock 509 186 230 minecraft:red_concrete
setblock 509 186 266 minecraft:red_concrete
fill 510 186 229 510 190 230 minecraft:white_concrete
fill 510 186 265 510 190 266 minecraft:white_concrete
setblock 472 187 229 minecraft:red_concrete
fill 472 187 233 473 190 233 minecraft:red_concrete
setblock 472 187 265 minecraft:red_concrete
fill 472 187 269 473 190 269 minecraft:red_concrete
fill 473 187 229 473 191 230 minecraft:white_concrete
fill 473 187 232 473 191 232 minecraft:red_concrete
fill 473 187 265 473 191 266 minecraft:white_concrete
fill 473 187 268 473 191 268 minecraft:red_concrete
fill 474 187 232 474 187 233 minecraft:white_concrete
fill 474 187 268 474 187 269 minecraft:white_concrete
setblock 508 187 229 minecraft:red_concrete
fill 508 187 233 509 190 233 minecraft:red_concrete
setblock 508 187 265 minecraft:red_concrete
fill 508 187 269 509 190 269 minecraft:red_concrete
fill 509 187 229 509 191 230 minecraft:white_concrete
fill 509 187 232 509 191 232 minecraft:red_concrete
fill 509 187 265 509 191 266 minecraft:white_concrete
fill 509 187 268 509 191 268 minecraft:red_concrete
fill 510 187 232 510 187 233 minecraft:white_concrete
fill 510 187 268 510 187 269 minecraft:white_concrete
setblock 471 188 230 minecraft:red_concrete
setblock 471 188 266 minecraft:red_concrete
fill 472 188 229 472 192 230 minecraft:white_concrete
fill 472 188 265 472 192 266 minecraft:white_concrete
setblock 474 188 232 minecraft:white_concrete
fill 474 188 233 474 192 233 minecraft:red_concrete
setblock 474 188 268 minecraft:white_concrete
fill 474 188 269 474 192 269 minecraft:red_concrete
setblock 507 188 230 minecraft:red_concrete
setblock 507 188 266 minecraft:red_concrete
fill 508 188 229 508 192 230 minecraft:white_concrete
fill 508 188 265 508 192 266 minecraft:white_concrete
setblock 510 188 232 minecraft:white_concrete
fill 510 188 233 510 192 233 minecraft:red_concrete
setblock 510 188 268 minecraft:white_concrete
fill 510 188 269 510 192 269 minecraft:red_concrete
fill 471 189 230 471 193 230 minecraft:white_concrete
fill 471 189 266 471 193 266 minecraft:white_concrete
fill 474 189 232 475 192 232 minecraft:red_concrete
fill 474 189 268 475 192 268 minecraft:red_concrete
fill 500 189 242 500 190 244 minecraft:light_blue_concrete
fill 501 189 243 501 190 243 minecraft:light_blue_concrete
fill 507 189 230 507 193 230 minecraft:white_concrete
fill 507 189 266 507 193 266 minecraft:white_concrete
fill 510 189 232 511 192 232 minecraft:red_concrete
fill 510 189 268 511 192 268 minecraft:red_concrete
fill 471 190 231 471 194 232 minecraft:white_concrete
fill 471 190 267 471 194 268 minecraft:white_concrete
fill 472 190 231 472 194 231 minecraft:white_concrete
setblock 472 190 232 minecraft:red_concrete
fill 472 190 267 472 194 267 minecraft:white_concrete
setblock 472 190 268 minecraft:red_concrete
fill 473 190 231 475 194 231 minecraft:red_concrete
setblock 473 190 238 minecraft:light[level=12]
setblock 473 190 239 minecraft:light[level=15]
setblock 473 190 245 minecraft:light[level=12]
setblock 473 190 247 minecraft:light[level=15]
setblock 473 190 252 minecraft:light[level=12]
setblock 473 190 255 minecraft:light[level=15]
setblock 473 190 259 minecraft:light[level=12]
setblock 473 190 263 minecraft:light[level=15]
fill 473 190 267 475 194 267 minecraft:red_concrete
setblock 480 190 231 minecraft:light[level=12]
setblock 480 190 238 minecraft:light[level=12]
setblock 480 190 245 minecraft:light[level=12]
setblock 480 190 252 minecraft:light[level=12]
setblock 480 190 259 minecraft:light[level=12]
setblock 480 190 266 minecraft:light[level=12]
setblock 481 190 231 minecraft:light[level=15]
setblock 481 190 239 minecraft:light[level=15]
setblock 481 190 247 minecraft:light[level=15]
setblock 481 190 255 minecraft:light[level=15]
setblock 481 190 263 minecraft:light[level=15]
setblock 487 190 231 minecraft:light[level=12]
setblock 487 190 245 minecraft:light[level=12]
setblock 487 190 252 minecraft:light[level=12]
setblock 487 190 259 minecraft:light[level=12]
setblock 487 190 266 minecraft:light[level=12]
setblock 489 190 231 minecraft:light[level=15]
setblock 489 190 247 minecraft:light[level=15]
setblock 489 190 255 minecraft:light[level=15]
setblock 489 190 263 minecraft:light[level=15]
setblock 494 190 231 minecraft:light[level=12]
setblock 494 190 238 minecraft:light[level=12]
setblock 494 190 245 minecraft:light[level=12]
setblock 494 190 259 minecraft:light[level=12]
setblock 494 190 266 minecraft:light[level=12]
setblock 497 190 231 minecraft:light[level=15]
setblock 497 190 239 minecraft:light[level=15]
setblock 497 190 247 minecraft:light[level=15]
setblock 497 190 255 minecraft:light[level=15]
setblock 497 190 263 minecraft:light[level=15]
setblock 501 190 231 minecraft:light[level=12]
setblock 501 190 238 minecraft:light[level=12]
setblock 501 190 245 minecraft:light[level=12]
setblock 501 190 252 minecraft:light[level=12]
setblock 501 190 259 minecraft:light[level=12]
setblock 501 190 266 minecraft:light[level=12]
setblock 505 190 231 minecraft:light[level=15]
setblock 505 190 239 minecraft:light[level=15]
setblock 505 190 247 minecraft:light[level=15]
setblock 505 190 255 minecraft:light[level=15]
setblock 505 190 263 minecraft:light[level=15]
fill 507 190 231 507 194 232 minecraft:white_concrete
fill 507 190 267 507 194 268 minecraft:white_concrete
fill 508 190 231 508 194 231 minecraft:white_concrete
setblock 508 190 232 minecraft:red_concrete
setblock 508 190 238 minecraft:light[level=12]
setblock 508 190 245 minecraft:light[level=12]
setblock 508 190 252 minecraft:light[level=12]
setblock 508 190 259 minecraft:light[level=12]
fill 508 190 267 508 194 267 minecraft:white_concrete
setblock 508 190 268 minecraft:red_concrete
fill 509 190 231 511 194 231 minecraft:red_concrete
fill 509 190 267 511 194 267 minecraft:red_concrete
fill 472 191 232 472 195 233 minecraft:white_concrete
fill 472 191 268 472 195 269 minecraft:white_concrete
setblock 473 191 233 minecraft:red_concrete
setblock 473 191 269 minecraft:red_concrete
setblock 474 191 229 minecraft:white_concrete
fill 474 191 230 475 194 230 minecraft:red_concrete
setblock 474 191 265 minecraft:white_concrete
fill 474 191 266 475 194 266 minecraft:red_concrete
fill 478 191 269 478 196 269 minecraft:brown_concrete
fill 484 191 238 485 191 240 minecraft:magenta_concrete
fill 485 191 237 491 191 237 minecraft:magenta_concrete
fill 485 191 241 486 191 242 minecraft:magenta_concrete
fill 486 191 236 490 191 236 minecraft:magenta_concrete
fill 486 191 238 486 193 238 minecraft:magenta_concrete
fill 487 191 242 489 191 243 minecraft:magenta_concrete
fill 490 191 238 491 192 238 minecraft:magenta_concrete
fill 490 191 240 490 191 242 minecraft:magenta_concrete
fill 491 191 239 491 191 241 minecraft:magenta_concrete
fill 491 191 248 492 191 252 minecraft:magenta_concrete
setblock 492 191 239 minecraft:magenta_concrete
setblock 492 191 247 minecraft:magenta_concrete
fill 492 191 253 498 191 253 minecraft:magenta_concrete
fill 493 191 252 493 193 252 minecraft:magenta_concrete
fill 494 191 254 496 191 254 minecraft:magenta_concrete
fill 497 191 252 498 192 252 minecraft:magenta_concrete
fill 498 191 249 499 191 251 minecraft:magenta_concrete
setblock 499 191 248 minecraft:magenta_concrete
fill 508 191 232 508 195 233 minecraft:white_concrete
fill 508 191 268 508 195 269 minecraft:white_concrete
setblock 509 191 233 minecraft:red_concrete
setblock 509 191 269 minecraft:red_concrete
setblock 510 191 229 minecraft:white_concrete
fill 510 191 230 511 194 230 minecraft:red_concrete
setblock 510 191 265 minecraft:white_concrete
fill 510 191 266 511 194 266 minecraft:red_concrete
fill 473 192 229 473 196 230 minecraft:red_concrete
fill 473 192 232 473 196 233 minecraft:white_concrete
fill 473 192 265 473 196 266 minecraft:red_concrete
fill 473 192 268 473 196 269 minecraft:white_concrete
fill 474 192 229 474 195 229 minecraft:red_concrete
fill 474 192 265 474 195 265 minecraft:red_concrete
fill 485 192 238 485 192 241 minecraft:magenta_concrete
fill 486 192 237 490 192 237 minecraft:magenta_concrete
fill 486 192 241 486 192 242 minecraft:magenta_concrete
fill 487 192 236 489 192 236 minecraft:magenta_concrete
fill 487 192 242 489 192 242 minecraft:magenta_concrete
fill 490 192 240 490 193 241 minecraft:magenta_concrete
fill 491 192 239 491 192 240 minecraft:magenta_concrete
fill 492 192 248 492 192 252 minecraft:magenta_concrete
fill 493 192 253 497 192 253 minecraft:magenta_concrete
fill 498 192 249 498 192 251 minecraft:magenta_concrete
fill 509 192 229 509 196 230 minecraft:red_concrete
fill 509 192 232 509 196 233 minecraft:white_concrete
fill 509 192 265 509 196 266 minecraft:red_concrete
fill 509 192 268 509 196 269 minecraft:white_concrete
fill 510 192 229 510 195 229 minecraft:red_concrete
fill 510 192 265 510 195 265 minecraft:red_concrete
fill 472 193 229 472 197 229 minecraft:red_concrete
setblock 472 193 230 minecraft:white_concrete
fill 472 193 265 472 197 265 minecraft:red_concrete
setblock 472 193 266 minecraft:white_concrete
fill 474 193 232 474 197 233 minecraft:white_concrete
fill 474 193 268 474 197 269 minecraft:white_concrete
setblock 475 193 232 minecraft:red_concrete
setblock 475 193 268 minecraft:red_concrete
setblock 486 193 241 minecraft:magenta_concrete
fill 487 193 237 489 193 237 minecraft:magenta_concrete
setblock 488 193 242 minecraft:magenta_concrete
setblock 490 193 238 minecraft:magenta_concrete
fill 492 193 249 492 193 250 minecraft:magenta_concrete
setblock 497 193 252 minecraft:magenta_concrete
setblock 498 193 250 minecraft:magenta_concrete
fill 508 193 229 508 197 229 minecraft:red_concrete
setblock 508 193 230 minecraft:white_concrete
fill 508 193 265 508 197 265 minecraft:red_concrete
setblock 508 193 266 minecraft:white_concrete
fill 510 193 232 510 197 233 minecraft:white_concrete
fill 510 193 268 510 197 269 minecraft:white_concrete
setblock 511 193 232 minecraft:red_concrete
setblock 511 193 268 minecraft:red_concrete
fill 471 194 230 472 197 230 minecraft:red_concrete
fill 471 194 266 472 197 266 minecraft:red_concrete
fill 475 194 232 475 198 232 minecraft:white_concrete
fill 475 194 268 475 198 268 minecraft:white_concrete
fill 507 194 230 508 197 230 minecraft:red_concrete
fill 507 194 266 508 197 266 minecraft:red_concrete
fill 511 194 232 511 198 232 minecraft:white_concrete
fill 511 194 268 511 198 268 minecraft:white_concrete
fill 471 195 231 472 199 231 minecraft:red_concrete
setblock 471 195 232 minecraft:white_concrete
fill 471 195 267 472 199 267 minecraft:red_concrete
setblock 471 195 268 minecraft:white_concrete
fill 473 195 231 475 199 231 minecraft:white_concrete
fill 473 195 267 475 199 267 minecraft:white_concrete
setblock 474 195 230 minecraft:red_concrete
setblock 474 195 266 minecraft:red_concrete
fill 475 195 230 475 200 230 minecraft:white_concrete
fill 475 195 266 475 200 266 minecraft:white_concrete
fill 507 195 231 508 199 231 minecraft:red_concrete
setblock 507 195 232 minecraft:white_concrete
fill 507 195 267 508 199 267 minecraft:red_concrete
setblock 507 195 268 minecraft:white_concrete
fill 509 195 231 511 199 231 minecraft:white_concrete
fill 509 195 267 511 199 267 minecraft:white_concrete
setblock 510 195 230 minecraft:red_concrete
setblock 510 195 266 minecraft:red_concrete
fill 511 195 230 511 200 230 minecraft:white_concrete
fill 511 195 266 511 200 266 minecraft:white_concrete
fill 471 196 232 472 199 232 minecraft:red_concrete
fill 471 196 268 472 199 268 minecraft:red_concrete
setblock 472 196 233 minecraft:white_concrete
setblock 472 196 269 minecraft:white_concrete
setblock 473 196 238 minecraft:light[level=12]
setblock 473 196 245 minecraft:light[level=12]
setblock 473 196 252 minecraft:light[level=12]
setblock 473 196 259 minecraft:light[level=12]
fill 474 196 229 474 200 230 minecraft:white_concrete
fill 474 196 265 474 200 266 minecraft:white_concrete
setblock 480 196 231 minecraft:light[level=12]
setblock 480 196 238 minecraft:light[level=12]
setblock 480 196 245 minecraft:light[level=12]
setblock 480 196 252 minecraft:light[level=12]
setblock 480 196 259 minecraft:light[level=12]
setblock 480 196 266 minecraft:light[level=12]
setblock 487 196 231 minecraft:light[level=12]
setblock 487 196 238 minecraft:light[level=12]
setblock 487 196 245 minecraft:light[level=12]
setblock 487 196 252 minecraft:light[level=12]
setblock 487 196 259 minecraft:light[level=12]
setblock 487 196 266 minecraft:light[level=12]
setblock 494 196 231 minecraft:light[level=12]
setblock 494 196 238 minecraft:light[level=12]
setblock 494 196 245 minecraft:light[level=12]
setblock 494 196 252 minecraft:light[level=12]
setblock 494 196 259 minecraft:light[level=12]
setblock 494 196 266 minecraft:light[level=12]
setblock 501 196 231 minecraft:light[level=12]
setblock 501 196 238 minecraft:light[level=12]
setblock 501 196 245 minecraft:light[level=12]
setblock 501 196 252 minecraft:light[level=12]
setblock 501 196 259 minecraft:light[level=12]
setblock 501 196 266 minecraft:light[level=12]
fill 507 196 232 508 199 232 minecraft:red_concrete
fill 507 196 268 508 199 268 minecraft:red_concrete
setblock 508 196 233 minecraft:white_concrete
setblock 508 196 238 minecraft:light[level=12]
setblock 508 196 245 minecraft:light[level=12]
setblock 508 196 252 minecraft:light[level=12]
setblock 508 196 259 minecraft:light[level=12]
setblock 508 196 269 minecraft:white_concrete
fill 510 196 229 510 200 230 minecraft:white_concrete
fill 510 196 265 510 200 266 minecraft:white_concrete
fill 472 197 233 473 200 233 minecraft:red_concrete
fill 472 197 269 473 200 269 minecraft:red_concrete
fill 473 197 229 473 201 230 minecraft:white_concrete
fill 473 197 232 473 201 232 minecraft:red_concrete
setblock 473 197 239 minecraft:light[level=15]
setblock 473 197 247 minecraft:light[level=15]
setblock 473 197 255 minecraft:light[level=15]
setblock 473 197 263 minecraft:light[level=15]
fill 473 197 265 473 201 266 minecraft:white_concrete
fill 473 197 268 473 201 268 minecraft:red_concrete
setblock 481 197 231 minecraft:light[level=15]
setblock 481 197 239 minecraft:light[level=15]
setblock 481 197 247 minecraft:light[level=15]
setblock 481 197 255 minecraft:light[level=15]
setblock 481 197 263 minecraft:light[level=15]
setblock 489 197 231 minecraft:light[level=15]
setblock 489 197 239 minecraft:light[level=15]
setblock 489 197 247 minecraft:light[level=15]
setblock 489 197 255 minecraft:light[level=15]
setblock 489 197 263 minecraft:light[level=15]
setblock 497 197 231 minecraft:light[level=15]
setblock 497 197 239 minecraft:light[level=15]
setblock 497 197 247 minecraft:light[level=15]
setblock 497 197 255 minecraft:light[level=15]
setblock 497 197 263 minecraft:light[level=15]
setblock 505 197 231 minecraft:light[level=15]
setblock 505 197 239 minecraft:light[level=15]
setblock 505 197 247 minecraft:light[level=15]
setblock 505 197 255 minecraft:light[level=15]
setblock 505 197 263 minecraft:light[level=15]
fill 508 197 233 509 200 233 minecraft:red_concrete
fill 508 197 269 509 200 269 minecraft:red_concrete
fill 509 197 229 509 201 230 minecraft:white_concrete
fill 509 197 232 509 201 232 minecraft:red_concrete
fill 509 197 265 509 201 266 minecraft:white_concrete
fill 509 197 268 509 201 268 minecraft:red_concrete
setblock 471 198 230 minecraft:red_concrete
setblock 471 198 266 minecraft:red_concrete
fill 472 198 229 472 201 230 minecraft:white_concrete
fill 472 198 265 472 201 266 minecraft:white_concrete
setblock 474 198 232 minecraft:white_concrete
fill 474 198 233 474 202 233 minecraft:red_concrete
setblock 474 198 268 minecraft:white_concrete
fill 474 198 269 474 201 269 minecraft:red_concrete
setblock 507 198 230 minecraft:red_concrete
setblock 507 198 266 minecraft:red_concrete
fill 508 198 229 508 201 230 minecraft:white_concrete
fill 508 198 265 508 202 266 minecraft:white_concrete
setblock 510 198 232 minecraft:white_concrete
fill 510 198 233 510 201 233 minecraft:red_concrete
setblock 510 198 268 minecraft:white_concrete
fill 510 198 269 510 201 269 minecraft:red_concrete
fill 471 199 230 471 201 230 minecraft:white_concrete
fill 471 199 266 471 201 266 minecraft:white_concrete
fill 474 199 232 475 202 232 minecraft:red_concrete
fill 474 199 268 475 201 268 minecraft:red_concrete
fill 507 199 230 507 201 230 minecraft:white_concrete
fill 507 199 266 507 203 266 minecraft:white_concrete
fill 510 199 232 511 201 232 minecraft:red_concrete
fill 510 199 268 511 201 268 minecraft:red_concrete
fill 471 200 231 471 201 232 minecraft:white_concrete
fill 471 200 267 471 201 268 minecraft:white_concrete
fill 472 200 231 472 201 231 minecraft:white_concrete
setblock 472 200 232 minecraft:red_concrete
fill 472 200 267 472 201 267 minecraft:white_concrete
setblock 472 200 268 minecraft:red_concrete
fill 473 200 231 475 201 231 minecraft:red_concrete
fill 473 200 267 475 201 267 minecraft:red_concrete
fill 484 200 244 484 202 246 minecraft:brown_concrete
fill 484 200 249 495 201 249 minecraft:brown_concrete
fill 485 200 241 505 201 241 minecraft:brown_concrete
fill 485 200 245 492 202 246 minecraft:brown_concrete
fill 485 200 248 493 201 248 minecraft:brown_concrete
fill 485 200 250 485 202 250 minecraft:brown_concrete
fill 486 200 242 493 201 244 minecraft:brown_concrete
fill 486 200 247 493 201 247 minecraft:brown_concrete
fill 486 200 252 487 202 253 minecraft:brown_concrete
fill 487 200 238 502 202 238 minecraft:brown_concrete
fill 487 200 250 506 201 251 minecraft:brown_concrete
fill 488 200 237 488 202 237 minecraft:brown_concrete
fill 488 200 239 503 201 240 minecraft:brown_concrete
fill 488 200 252 504 201 252 minecraft:brown_concrete
fill 489 200 253 504 202 253 minecraft:brown_concrete
fill 489 200 255 490 202 256 minecraft:brown_concrete
fill 490 200 254 505 202 254 minecraft:brown_concrete
fill 491 200 235 491 202 237 minecraft:brown_concrete
fill 491 200 255 501 202 255 minecraft:brown_concrete
fill 492 200 236 499 202 237 minecraft:brown_concrete
fill 492 200 257 494 202 257 minecraft:brown_concrete
fill 493 200 245 493 201 245 minecraft:brown_concrete
fill 493 200 256 501 202 256 minecraft:brown_concrete
fill 493 200 258 493 202 258 minecraft:brown_concrete
fill 494 200 234 495 202 234 minecraft:brown_concrete
fill 494 200 242 495 201 243 minecraft:brown_concrete
fill 495 200 235 495 202 235 minecraft:brown_concrete
fill 496 200 242 505 201 242 minecraft:brown_concrete
fill 497 200 243 508 201 243 minecraft:brown_concrete
fill 497 200 249 506 201 249 minecraft:brown_concrete
fill 497 200 257 497 202 258 minecraft:brown_concrete
fill 498 200 235 500 202 235 minecraft:brown_concrete
fill 498 200 258 498 202 258 minecraft:brown_concrete
fill 499 200 234 499 202 234 minecraft:brown_concrete
fill 499 200 244 506 201 245 minecraft:brown_concrete
fill 499 200 247 506 201 248 minecraft:brown_concrete
fill 500 200 237 503 202 237 minecraft:brown_concrete
fill 500 200 246 508 201 246 minecraft:brown_concrete
fill 501 200 257 501 202 257 minecraft:brown_concrete
fill 502 200 236 503 202 236 minecraft:brown_concrete
fill 504 200 240 506 202 240 minecraft:brown_concrete
fill 504 200 255 504 202 255 minecraft:brown_concrete
fill 505 200 239 506 202 239 minecraft:brown_concrete
fill 507 200 231 507 201 232 minecraft:white_concrete
fill 507 200 242 507 202 242 minecraft:brown_concrete
fill 507 200 244 507 202 244 minecraft:brown_concrete
fill 507 200 247 508 202 247 minecraft:brown_concrete
fill 507 200 251 507 202 251 minecraft:brown_concrete
fill 507 200 267 507 201 268 minecraft:white_concrete
fill 508 200 231 508 201 231 minecraft:white_concrete
setblock 508 200 232 minecraft:red_concrete
fill 508 200 248 508 202 248 minecraft:brown_concrete
fill 508 200 267 508 201 267 minecraft:white_concrete
setblock 508 200 268 minecraft:red_concrete
fill 509 200 231 511 201 231 minecraft:red_concrete
fill 509 200 267 511 201 267 minecraft:red_concrete
fill 472 201 232 472 201 233 minecraft:white_concrete
fill 472 201 268 472 201 269 minecraft:white_concrete
setblock 473 201 233 minecraft:red_concrete
setblock 473 201 269 minecraft:red_concrete
setblock 474 201 229 minecraft:white_concrete
fill 474 201 230 475 201 230 minecraft:red_concrete
setblock 474 201 265 minecraft:white_concrete
fill 474 201 266 475 204 266 minecraft:red_concrete
fill 508 201 232 508 205 233 minecraft:white_concrete
fill 508 201 268 508 201 269 minecraft:white_concrete
setblock 509 201 233 minecraft:red_concrete
setblock 509 201 269 minecraft:red_concrete
setblock 510 201 229 minecraft:white_concrete
fill 510 201 230 511 201 230 minecraft:red_concrete
setblock 510 201 265 minecraft:white_concrete
fill 510 201 266 511 201 266 minecraft:red_concrete
fill 471 202 229 473 202 269 minecraft:black_concrete
fill 474 202 229 511 202 231 minecraft:black_concrete
fill 474 202 234 493 202 234 minecraft:brown_concrete
fill 474 202 235 490 202 236 minecraft:brown_terracotta
fill 474 202 237 487 202 237 minecraft:brown_concrete
fill 474 202 238 486 202 239 minecraft:brown_terracotta
fill 474 202 240 492 202 240 minecraft:brown_concrete
fill 474 202 241 484 202 242 minecraft:brown_terracotta
fill 474 202 243 493 202 243 minecraft:brown_concrete
fill 474 202 244 483 202 245 minecraft:brown_terracotta
fill 474 202 246 483 202 246 minecraft:brown_concrete
fill 474 202 247 484 202 248 minecraft:brown_terracotta
fill 474 202 249 488 202 249 minecraft:brown_concrete
fill 474 202 250 484 202 251 minecraft:brown_terracotta
fill 474 202 252 485 202 252 minecraft:brown_concrete
fill 474 202 253 485 202 254 minecraft:brown_terracotta
fill 474 202 255 488 202 255 minecraft:brown_concrete
fill 474 202 256 488 202 257 minecraft:brown_terracotta
fill 474 202 258 492 202 258 minecraft:brown_concrete
fill 474 202 259 508 202 260 minecraft:brown_terracotta
fill 474 202 261 508 202 261 minecraft:brown_concrete
fill 474 202 262 508 202 263 minecraft:brown_terracotta
fill 474 202 264 508 202 264 minecraft:brown_concrete
fill 474 202 265 474 205 265 minecraft:red_concrete
fill 474 202 267 511 202 269 minecraft:black_concrete
fill 475 202 233 507 202 233 minecraft:brown_terracotta
fill 475 202 265 507 202 265 minecraft:brown_terracotta
fill 476 202 232 506 202 232 minecraft:brown_terracotta
fill 476 202 266 506 202 266 minecraft:brown_terracotta
fill 485 202 241 493 202 241 minecraft:brown_concrete
setblock 485 202 242 minecraft:brown_terracotta
setblock 485 202 244 minecraft:brown_terracotta
setblock 485 202 247 minecraft:brown_terracotta
fill 485 202 248 488 202 248 minecraft:brown_concrete
fill 485 202 251 486 202 251 minecraft:brown_terracotta
fill 486 202 242 493 202 242 minecraft:brown_concrete
fill 486 202 244 492 202 244 minecraft:brown_concrete
fill 486 202 247 488 202 247 minecraft:brown_concrete
setblock 486 202 250 minecraft:brown_terracotta
fill 486 202 254 489 202 254 minecraft:brown_terracotta
setblock 487 202 239 minecraft:brown_terracotta
fill 487 202 250 489 202 251 minecraft:brown_concrete
fill 488 202 239 492 202 239 minecraft:brown_concrete
fill 488 202 252 490 202 252 minecraft:brown_concrete
setblock 488 202 253 minecraft:brown_terracotta
fill 489 202 237 490 202 237 minecraft:brown_concrete
fill 489 202 247 492 202 249 minecraft:brown_terracotta
fill 489 202 257 491 202 257 minecraft:brown_terracotta
fill 490 202 250 493 202 251 minecraft:brown_terracotta
fill 491 202 252 492 202 252 minecraft:brown_terracotta
fill 491 202 256 492 202 256 minecraft:brown_terracotta
fill 492 202 235 494 202 235 minecraft:brown_terracotta
fill 493 202 239 499 202 240 minecraft:brown_terracotta
fill 493 202 244 493 202 245 minecraft:gold_block
fill 493 202 247 493 202 248 minecraft:gold_block
setblock 493 202 249 minecraft:brown_terracotta
fill 493 202 252 499 202 252 minecraft:brown_concrete
fill 494 202 241 495 202 242 minecraft:brown_terracotta
fill 494 202 243 495 202 243 minecraft:gold_block
fill 494 202 249 495 202 249 minecraft:gold_block
fill 494 202 250 498 202 251 minecraft:brown_concrete
fill 494 202 258 496 202 258 minecraft:brown_concrete
fill 495 202 257 496 202 257 minecraft:brown_terracotta
fill 496 202 234 498 202 234 minecraft:brown_concrete
fill 496 202 235 497 202 235 minecraft:brown_terracotta
fill 496 202 241 498 202 241 minecraft:brown_terracotta
setblock 496 202 242 minecraft:brown_concrete
fill 497 202 242 498 202 242 minecraft:brown_terracotta
fill 497 202 243 498 202 243 minecraft:gold_block
fill 497 202 249 498 202 249 minecraft:gold_block
fill 498 202 257 500 202 257 minecraft:brown_terracotta
fill 499 202 241 505 202 243 minecraft:brown_concrete
fill 499 202 244 499 202 245 minecraft:gold_block
fill 499 202 247 499 202 248 minecraft:gold_block
fill 499 202 249 502 202 251 minecraft:brown_terracotta
fill 499 202 258 508 202 258 minecraft:brown_concrete
fill 500 202 234 508 202 234 minecraft:brown_concrete
fill 500 202 236 501 202 236 minecraft:brown_terracotta
fill 500 202 239 503 202 240 minecraft:brown_concrete
fill 500 202 244 500 202 246 minecraft:brown_concrete
fill 500 202 247 503 202 248 minecraft:brown_terracotta
fill 500 202 252 501 202 252 minecraft:brown_terracotta
fill 501 202 235 508 202 235 minecraft:brown_terracotta
fill 501 202 244 506 202 245 minecraft:brown_concrete
fill 501 202 246 503 202 246 minecraft:brown_terracotta
fill 502 202 252 508 202 252 minecraft:brown_concrete
fill 502 202 255 503 202 255 minecraft:brown_concrete
fill 502 202 256 508 202 257 minecraft:brown_terracotta
fill 503 202 238 508 202 238 minecraft:brown_terracotta
setblock 503 202 249 minecraft:brown_terracotta
fill 503 202 250 506 202 251 minecraft:brown_concrete
fill 504 202 236 508 202 236 minecraft:brown_terracotta
fill 504 202 237 508 202 237 minecraft:brown_concrete
setblock 504 202 239 minecraft:brown_terracotta
fill 504 202 246 506 202 249 minecraft:brown_concrete
fill 505 202 253 508 202 253 minecraft:brown_terracotta
fill 505 202 255 508 202 255 minecraft:brown_concrete
fill 506 202 241 506 202 242 minecraft:brown_terracotta
fill 506 202 243 508 202 243 minecraft:brown_concrete
fill 506 202 254 508 202 254 minecraft:brown_terracotta
fill 507 202 232 507 205 232 minecraft:white_concrete
fill 507 202 239 508 202 239 minecraft:brown_terracotta
fill 507 202 240 508 202 240 minecraft:brown_concrete
fill 507 202 241 508 202 241 minecraft:brown_terracotta
fill 507 202 245 508 202 245 minecraft:brown_terracotta
fill 507 202 246 508 202 246 minecraft:brown_concrete
setblock 507 202 248 minecraft:brown_terracotta
fill 507 202 249 508 202 249 minecraft:brown_concrete
fill 507 202 250 508 202 250 minecraft:brown_terracotta
setblock 508 202 242 minecraft:brown_terracotta
setblock 508 202 244 minecraft:brown_terracotta
setblock 508 202 251 minecraft:brown_terracotta
fill 509 202 232 511 202 266 minecraft:black_concrete
fill 471 203 229 473 203 269 minecraft:gray_concrete
fill 474 203 229 511 203 231 minecraft:gray_concrete
fill 474 203 232 474 207 233 minecraft:white_concrete
fill 474 203 267 511 203 269 minecraft:gray_concrete
setblock 475 203 232 minecraft:red_concrete
setblock 485 203 244 minecraft:white_terracotta
setblock 486 203 247 minecraft:white_terracotta
fill 486 203 250 487 203 250 minecraft:white_terracotta
setblock 487 203 241 minecraft:white_terracotta
setblock 488 203 249 minecraft:white_terracotta
setblock 488 203 253 minecraft:white_terracotta
setblock 490 203 241 minecraft:white_terracotta
fill 490 203 248 490 203 249 minecraft:white_terracotta
setblock 491 203 244 minecraft:white_terracotta
fill 491 203 253 491 203 254 minecraft:white_terracotta
setblock 492 203 241 minecraft:white_terracotta
fill 492 203 245 492 203 247 minecraft:ochre_froglight
setblock 492 203 252 minecraft:white_terracotta
setblock 492 203 254 minecraft:white_terracotta
fill 493 203 243 493 203 245 minecraft:ochre_froglight
fill 493 203 247 493 203 249 minecraft:ochre_froglight
fill 494 203 243 495 203 243 minecraft:ochre_froglight
fill 494 203 249 495 203 249 minecraft:ochre_froglight
setblock 494 203 251 minecraft:white_terracotta
fill 495 203 242 497 203 242 minecraft:ochre_froglight
fill 495 203 250 497 203 250 minecraft:ochre_froglight
setblock 496 203 237 minecraft:white_terracotta
setblock 497 203 236 minecraft:white_terracotta
setblock 497 203 238 minecraft:white_terracotta
fill 497 203 243 499 203 243 minecraft:ochre_froglight
fill 497 203 249 499 203 249 minecraft:ochre_froglight
setblock 498 203 251 minecraft:white_terracotta
setblock 499 203 235 minecraft:white_terracotta
fill 499 203 244 499 203 245 minecraft:ochre_froglight
fill 499 203 247 499 203 248 minecraft:ochre_froglight
fill 500 203 245 500 203 247 minecraft:ochre_froglight
setblock 500 203 250 minecraft:white_terracotta
setblock 500 203 255 minecraft:white_terracotta
setblock 501 203 246 minecraft:white_terracotta
setblock 501 203 252 minecraft:white_terracotta
fill 502 203 242 503 203 242 minecraft:white_terracotta
fill 502 203 247 503 203 247 minecraft:white_terracotta
setblock 503 203 249 minecraft:white_terracotta
setblock 503 203 252 minecraft:white_terracotta
setblock 503 203 254 minecraft:white_terracotta
setblock 506 203 243 minecraft:white_terracotta
setblock 506 203 249 minecraft:white_terracotta
setblock 507 203 248 minecraft:white_terracotta
fill 508 203 265 508 207 265 minecraft:red_concrete
setblock 508 203 266 minecraft:white_concrete
fill 509 203 232 511 203 266 minecraft:gray_concrete
fill 471 204 230 475 204 230 minecraft:red_concrete
fill 471 204 231 472 204 232 minecraft:white_concrete
fill 471 204 266 473 206 266 minecraft:red_concrete
fill 471 204 267 472 204 268 minecraft:white_concrete
fill 472 204 229 474 205 229 minecraft:red_concrete
fill 472 204 233 473 206 233 minecraft:white_concrete
fill 472 204 254 472 205 254 minecraft:brown_concrete
fill 472 204 265 473 206 265 minecraft:red_concrete
fill 472 204 269 474 206 269 minecraft:white_concrete
fill 473 204 231 475 204 231 minecraft:red_concrete
fill 473 204 232 473 206 232 minecraft:white_concrete
setblock 473 204 239 minecraft:light[level=15]
setblock 473 204 247 minecraft:light[level=15]
setblock 473 204 252 minecraft:orange_concrete
setblock 473 204 255 minecraft:light[level=15]
setblock 473 204 258 minecraft:magenta_concrete
setblock 473 204 263 minecraft:light[level=15]
fill 473 204 267 475 204 267 minecraft:red_concrete
fill 473 204 268 475 206 268 minecraft:white_concrete
fill 475 204 232 475 208 232 minecraft:white_concrete
setblock 477 204 229 minecraft:light_blue_concrete
fill 477 204 231 477 205 231 minecraft:brown_concrete
setblock 481 204 231 minecraft:light[level=15]
setblock 481 204 239 minecraft:light[level=15]
setblock 481 204 247 minecraft:light[level=15]
setblock 481 204 255 minecraft:light[level=15]
setblock 481 204 263 minecraft:light[level=15]
setblock 489 204 229 minecraft:red_concrete
setblock 489 204 231 minecraft:light[level=15]
setblock 489 204 239 minecraft:light[level=15]
setblock 489 204 247 minecraft:light[level=15]
setblock 489 204 255 minecraft:light[level=15]
setblock 489 204 263 minecraft:light[level=15]
setblock 497 204 231 minecraft:light[level=15]
setblock 497 204 239 minecraft:light[level=15]
setblock 497 204 255 minecraft:light[level=15]
setblock 497 204 263 minecraft:light[level=15]
setblock 499 204 229 minecraft:lime_concrete
setblock 499 204 267 minecraft:yellow_concrete
setblock 502 204 230 minecraft:yellow_concrete
setblock 505 204 231 minecraft:light[level=15]
setblock 505 204 239 minecraft:light[level=15]
setblock 505 204 247 minecraft:light[level=15]
setblock 505 204 255 minecraft:light[level=15]
setblock 505 204 263 minecraft:light[level=15]
setblock 506 204 230 minecraft:orange_concrete
fill 507 204 230 511 204 230 minecraft:red_concrete
fill 507 204 231 508 204 231 minecraft:white_concrete
fill 507 204 266 511 204 266 minecraft:red_concrete
fill 507 204 267 508 204 268 minecraft:white_concrete
fill 508 204 229 510 205 229 minecraft:red_concrete
fill 508 204 269 510 206 269 minecraft:white_concrete
fill 509 204 231 511 204 231 minecraft:red_concrete
fill 509 204 232 510 206 233 minecraft:white_concrete
setblock 509 204 238 minecraft:orange_concrete
fill 509 204 258 509 205 258 minecraft:brown_concrete
fill 509 204 265 510 205 265 minecraft:red_concrete
fill 509 204 267 511 204 267 minecraft:red_concrete
fill 509 204 268 511 206 268 minecraft:white_concrete
fill 510 204 241 510 205 241 minecraft:brown_concrete
fill 511 204 232 511 208 232 minecraft:white_concrete
fill 511 204 251 511 205 251 minecraft:brown_concrete
fill 511 204 255 511 205 255 minecraft:brown_concrete
setblock 511 204 257 minecraft:red_concrete
fill 471 205 230 472 207 231 minecraft:red_concrete
fill 471 205 232 472 205 232 minecraft:white_concrete
fill 471 205 267 472 209 267 minecraft:red_concrete
fill 471 205 268 472 205 268 minecraft:white_concrete
fill 473 205 230 474 205 230 minecraft:red_concrete
fill 473 205 231 475 209 231 minecraft:white_concrete
fill 473 205 267 475 209 267 minecraft:white_concrete
setblock 474 205 266 minecraft:red_concrete
fill 475 205 230 475 210 230 minecraft:white_concrete
fill 475 205 266 475 210 266 minecraft:white_concrete
fill 507 205 230 508 207 231 minecraft:red_concrete
fill 507 205 266 508 207 267 minecraft:red_concrete
fill 507 205 268 508 205 268 minecraft:white_concrete
fill 509 205 230 510 205 230 minecraft:red_concrete
fill 509 205 231 511 209 231 minecraft:white_concrete
fill 509 205 266 510 205 266 minecraft:red_concrete
fill 509 205 267 511 209 267 minecraft:white_concrete
fill 511 205 230 511 210 230 minecraft:white_concrete
fill 511 205 266 511 210 266 minecraft:white_concrete
fill 471 206 232 472 209 232 minecraft:red_concrete
fill 471 206 268 472 209 268 minecraft:red_concrete
fill 472 206 229 473 206 229 minecraft:red_concrete
setblock 473 206 230 minecraft:red_concrete
fill 474 206 229 474 210 230 minecraft:white_concrete
fill 474 206 265 474 210 266 minecraft:white_concrete
fill 485 206 243 485 209 249 minecraft:iron_block
fill 486 206 241 486 209 242 minecraft:iron_block
fill 486 206 250 486 209 251 minecraft:iron_block
fill 487 206 239 487 209 240 minecraft:iron_block
fill 487 206 252 487 209 253 minecraft:iron_block
fill 488 206 238 488 206 239 minecraft:iron_block
fill 488 206 253 488 206 254 minecraft:iron_block
fill 489 206 237 489 209 238 minecraft:iron_block
fill 489 206 254 489 209 255 minecraft:iron_block
fill 490 206 237 490 209 237 minecraft:iron_block
fill 490 206 255 490 209 255 minecraft:iron_block
fill 491 206 236 492 209 236 minecraft:iron_block
fill 491 206 256 492 209 256 minecraft:iron_block
fill 493 206 234 494 206 234 minecraft:lime_concrete
fill 493 206 235 499 209 235 minecraft:iron_block
fill 493 206 257 499 209 257 minecraft:iron_block
fill 500 206 236 501 209 236 minecraft:iron_block
fill 500 206 256 501 209 256 minecraft:iron_block
fill 502 206 237 503 209 237 minecraft:iron_block
fill 502 206 255 503 209 255 minecraft:iron_block
fill 503 206 238 504 206 238 minecraft:iron_block
fill 503 206 254 504 206 254 minecraft:iron_block
fill 504 206 239 505 209 239 minecraft:iron_block
fill 504 206 253 505 209 253 minecraft:iron_block
fill 505 206 240 505 209 240 minecraft:iron_block
fill 505 206 252 505 209 252 minecraft:iron_block
fill 506 206 241 506 209 242 minecraft:iron_block
fill 506 206 250 506 209 251 minecraft:iron_block
fill 507 206 232 508 209 232 minecraft:red_concrete
fill 507 206 243 507 209 249 minecraft:iron_block
fill 507 206 268 508 209 268 minecraft:red_concrete
fill 508 206 229 509 206 229 minecraft:red_concrete
setblock 508 206 233 minecraft:white_concrete
setblock 509 206 230 minecraft:red_concrete
fill 509 206 265 509 206 266 minecraft:red_concrete
fill 510 206 229 510 210 230 minecraft:white_concrete
fill 510 206 265 510 210 266 minecraft:white_concrete
fill 471 207 266 472 207 266 minecraft:red_concrete
setblock 472 207 229 minecraft:red_concrete
fill 472 207 233 473 210 233 minecraft:red_concrete
setblock 472 207 265 minecraft:red_concrete
fill 472 207 269 473 210 269 minecraft:red_concrete
fill 473 207 229 473 211 230 minecraft:white_concrete
fill 473 207 232 473 211 232 minecraft:red_concrete
fill 473 207 265 473 211 266 minecraft:white_concrete
fill 473 207 268 473 211 268 minecraft:red_concrete
fill 474 207 268 474 207 269 minecraft:white_concrete
fill 475 207 268 475 208 268 minecraft:white_concrete
fill 484 207 243 484 207 249 minecraft:iron_block
fill 485 207 241 485 208 242 minecraft:iron_block
fill 485 207 250 485 208 251 minecraft:iron_block
fill 486 207 239 486 208 240 minecraft:iron_block
fill 486 207 243 486 208 249 minecraft:iron_block
fill 486 207 252 486 208 253 minecraft:iron_block
fill 487 207 238 487 208 238 minecraft:iron_block
fill 487 207 241 487 208 243 minecraft:iron_block
fill 487 207 249 487 208 251 minecraft:iron_block
fill 487 207 254 487 208 254 minecraft:iron_block
fill 488 207 237 488 208 237 minecraft:iron_block
fill 488 207 238 488 208 238 minecraft:light_gray_concrete
fill 488 207 239 488 208 240 minecraft:iron_block
fill 488 207 252 488 208 253 minecraft:iron_block
fill 488 207 254 488 208 254 minecraft:light_gray_concrete
fill 488 207 255 488 208 255 minecraft:iron_block
fill 489 207 236 490 208 236 minecraft:iron_block
fill 489 207 239 489 208 239 minecraft:light_gray_concrete
fill 489 207 253 489 208 253 minecraft:light_gray_concrete
fill 489 207 256 490 208 256 minecraft:iron_block
fill 490 207 238 490 208 238 minecraft:iron_block
fill 490 207 240 490 208 240 minecraft:light_gray_concrete
fill 490 207 252 490 208 252 minecraft:light_gray_concrete
fill 490 207 254 490 208 254 minecraft:iron_block
fill 491 207 235 492 208 235 minecraft:iron_block
fill 491 207 237 493 208 237 minecraft:iron_block
fill 491 207 241 491 208 241 minecraft:light_gray_concrete
fill 491 207 244 491 208 248 minecraft:white_concrete
fill 491 207 251 491 208 251 minecraft:light_gray_concrete
fill 491 207 255 493 208 255 minecraft:iron_block
fill 491 207 257 492 208 257 minecraft:iron_block
fill 492 207 242 492 208 242 minecraft:light_gray_concrete
fill 492 207 243 492 208 244 minecraft:white_concrete
fill 492 207 248 492 208 249 minecraft:white_concrete
fill 492 207 250 492 208 250 minecraft:light_gray_concrete
fill 493 207 234 499 208 234 minecraft:iron_block
fill 493 207 236 499 208 236 minecraft:iron_block
fill 493 207 242 494 208 242 minecraft:white_concrete
fill 493 207 250 494 208 250 minecraft:white_concrete
fill 493 207 256 499 208 256 minecraft:iron_block
fill 493 207 258 499 208 258 minecraft:iron_block
fill 494 207 241 498 208 241 minecraft:white_concrete
fill 494 207 251 498 208 251 minecraft:white_concrete
fill 498 207 242 499 208 242 minecraft:white_concrete
fill 498 207 250 499 208 250 minecraft:white_concrete
fill 499 207 237 501 208 237 minecraft:iron_block
fill 499 207 255 501 208 255 minecraft:iron_block
fill 500 207 235 501 208 235 minecraft:iron_block
fill 500 207 242 500 208 242 minecraft:light_gray_concrete
fill 500 207 243 500 208 244 minecraft:white_concrete
fill 500 207 248 500 208 249 minecraft:white_concrete
fill 500 207 250 500 208 250 minecraft:light_gray_concrete
fill 500 207 257 501 208 257 minecraft:iron_block
fill 501 207 241 501 208 241 minecraft:light_gray_concrete
fill 501 207 244 501 208 248 minecraft:white_concrete
fill 501 207 251 501 208 251 minecraft:light_gray_concrete
fill 502 207 236 503 208 236 minecraft:iron_block
fill 502 207 238 503 208 238 minecraft:iron_block
fill 502 207 240 502 208 240 minecraft:light_gray_concrete
fill 502 207 252 502 208 252 minecraft:light_gray_concrete
fill 502 207 254 503 208 254 minecraft:iron_block
fill 502 207 256 503 208 256 minecraft:iron_block
fill 503 207 239 503 208 239 minecraft:light_gray_concrete
fill 503 207 253 503 208 253 minecraft:light_gray_concrete
fill 504 207 237 504 208 237 minecraft:iron_block
fill 504 207 238 504 208 238 minecraft:light_gray_concrete
fill 504 207 240 504 208 240 minecraft:iron_block
fill 504 207 252 504 208 252 minecraft:iron_block
fill 504 207 254 504 208 254 minecraft:light_gray_concrete
fill 504 207 255 504 208 255 minecraft:iron_block
fill 505 207 238 505 208 238 minecraft:iron_block
fill 505 207 241 505 208 243 minecraft:iron_block
fill 505 207 249 505 208 251 minecraft:iron_block
fill 505 207 254 505 208 254 minecraft:iron_block
fill 506 207 239 506 208 240 minecraft:iron_block
fill 506 207 243 506 208 249 minecraft:iron_block
fill 506 207 252 506 208 253 minecraft:iron_block
fill 507 207 241 507 208 242 minecraft:iron_block
fill 507 207 250 507 208 251 minecraft:iron_block
setblock 508 207 229 minecraft:red_concrete
fill 508 207 233 509 210 233 minecraft:red_concrete
fill 508 207 243 508 207 249 minecraft:iron_block
fill 508 207 269 509 210 269 minecraft:red_concrete
fill 509 207 229 509 211 230 minecraft:white_concrete
fill 509 207 232 509 211 232 minecraft:red_concrete
fill 509 207 265 509 211 266 minecraft:white_concrete
fill 509 207 268 509 211 268 minecraft:red_concrete
fill 510 207 232 510 207 233 minecraft:white_concrete
fill 510 207 268 510 207 269 minecraft:white_concrete
fill 511 207 268 511 208 268 minecraft:white_concrete
fill 471 208 230 471 208 231 minecraft:red_concrete
setblock 471 208 266 minecraft:red_concrete
fill 472 208 229 472 212 230 minecraft:white_concrete
fill 472 208 231 472 209 231 minecraft:red_concrete
fill 472 208 265 472 212 266 minecraft:white_concrete
setblock 473 208 238 minecraft:light[level=12]
setblock 473 208 245 minecraft:light[level=12]
setblock 473 208 252 minecraft:light[level=12]
setblock 473 208 259 minecraft:light[level=12]
setblock 474 208 232 minecraft:white_concrete
fill 474 208 233 474 212 233 minecraft:red_concrete
setblock 474 208 268 minecraft:white_concrete
fill 474 208 269 474 212 269 minecraft:red_concrete
setblock 480 208 231 minecraft:light[level=12]
setblock 480 208 238 minecraft:light[level=12]
fill 480 208 243 484 208 249 minecraft:blue_stained_glass
setblock 480 208 252 minecraft:light[level=12]
setblock 480 208 259 minecraft:light[level=12]
setblock 480 208 266 minecraft:light[level=12]
setblock 487 208 231 minecraft:light[level=12]
setblock 487 208 245 minecraft:light[level=12]
setblock 487 208 259 minecraft:light[level=12]
setblock 487 208 266 minecraft:light[level=12]
setblock 494 208 231 minecraft:light[level=12]
setblock 494 208 238 minecraft:light[level=12]
setblock 494 208 252 minecraft:light[level=12]
setblock 494 208 259 minecraft:light[level=12]
setblock 494 208 266 minecraft:light[level=12]
setblock 501 208 231 minecraft:light[level=12]
setblock 501 208 238 minecraft:light[level=12]
setblock 501 208 252 minecraft:light[level=12]
setblock 501 208 259 minecraft:light[level=12]
setblock 501 208 266 minecraft:light[level=12]
fill 507 208 230 507 208 231 minecraft:red_concrete
fill 507 208 266 507 208 267 minecraft:red_concrete
fill 508 208 229 508 212 230 minecraft:white_concrete
fill 508 208 231 508 209 231 minecraft:red_concrete
setblock 508 208 238 minecraft:light[level=12]
fill 508 208 243 511 208 249 minecraft:blue_stained_glass
setblock 508 208 252 minecraft:light[level=12]
setblock 508 208 259 minecraft:light[level=12]
fill 508 208 265 508 212 266 minecraft:white_concrete
fill 508 208 267 508 209 267 minecraft:red_concrete
setblock 510 208 232 minecraft:white_concrete
fill 510 208 233 510 212 233 minecraft:red_concrete
setblock 510 208 268 minecraft:white_concrete
fill 510 208 269 510 212 269 minecraft:red_concrete
fill 471 209 230 471 213 230 minecraft:white_concrete
setblock 471 209 231 minecraft:red_concrete
fill 471 209 266 471 213 266 minecraft:white_concrete
fill 474 209 232 475 212 232 minecraft:red_concrete
fill 474 209 268 475 212 268 minecraft:red_concrete
fill 486 209 257 488 264 259 minecraft:white_concrete
fill 487 209 260 487 264 260 minecraft:white_concrete
fill 488 209 238 488 209 239 minecraft:iron_block
fill 488 209 253 488 209 254 minecraft:iron_block
fill 489 209 258 489 264 258 minecraft:white_concrete
fill 503 209 238 504 209 238 minecraft:iron_block
fill 503 209 254 504 209 254 minecraft:iron_block
fill 507 209 230 507 213 230 minecraft:white_concrete
setblock 507 209 231 minecraft:red_concrete
fill 507 209 266 507 213 266 minecraft:white_concrete
setblock 507 209 267 minecraft:red_concrete
fill 510 209 232 511 212 232 minecraft:red_concrete
fill 510 209 268 511 212 268 minecraft:red_concrete
fill 471 210 231 471 214 232 minecraft:white_concrete
fill 471 210 267 471 214 268 minecraft:white_concrete
fill 472 210 231 472 214 231 minecraft:white_concrete
setblock 472 210 232 minecraft:red_concrete
fill 472 210 267 472 214 267 minecraft:white_concrete
setblock 472 210 268 minecraft:red_concrete
fill 473 210 231 475 214 231 minecraft:red_concrete
fill 473 210 267 475 214 267 minecraft:red_concrete
fill 485 210 257 485 211 259 minecraft:brown_terracotta
fill 486 210 256 488 211 256 minecraft:brown_terracotta
fill 486 210 260 486 211 260 minecraft:brown_terracotta
fill 488 210 260 489 211 260 minecraft:brown_terracotta
fill 489 210 257 489 211 257 minecraft:brown_terracotta
fill 489 210 259 489 211 259 minecraft:brown_terracotta
fill 507 210 231 507 214 232 minecraft:white_concrete
fill 507 210 267 507 214 268 minecraft:white_concrete
fill 508 210 231 508 214 231 minecraft:white_concrete
setblock 508 210 232 minecraft:red_concrete
fill 508 210 267 508 214 267 minecraft:white_concrete
setblock 508 210 268 minecraft:red_concrete
fill 509 210 231 511 214 231 minecraft:red_concrete
fill 509 210 267 511 214 267 minecraft:red_concrete
fill 472 211 232 472 215 233 minecraft:white_concrete
fill 472 211 268 472 215 269 minecraft:white_concrete
setblock 473 211 233 minecraft:red_concrete
setblock 473 211 239 minecraft:light[level=15]
setblock 473 211 247 minecraft:light[level=15]
setblock 473 211 255 minecraft:light[level=15]
setblock 473 211 263 minecraft:light[level=15]
setblock 473 211 269 minecraft:red_concrete
setblock 474 211 229 minecraft:white_concrete
fill 474 211 230 475 214 230 minecraft:red_concrete
setblock 474 211 265 minecraft:white_concrete
fill 474 211 266 475 214 266 minecraft:red_concrete
setblock 481 211 231 minecraft:light[level=15]
setblock 481 211 239 minecraft:light[level=15]
setblock 481 211 247 minecraft:light[level=15]
setblock 481 211 255 minecraft:light[level=15]
setblock 481 211 263 minecraft:light[level=15]
fill 484 211 258 484 211 259 minecraft:brown_terracotta
setblock 485 211 256 minecraft:brown_terracotta
setblock 485 211 260 minecraft:brown_terracotta
fill 486 211 261 489 211 261 minecraft:brown_terracotta
fill 487 211 255 488 211 255 minecraft:brown_terracotta
setblock 489 211 231 minecraft:light[level=15]
setblock 489 211 239 minecraft:light[level=15]
setblock 489 211 247 minecraft:light[level=15]
setblock 489 211 255 minecraft:light[level=15]
setblock 489 211 256 minecraft:brown_terracotta
setblock 489 211 263 minecraft:light[level=15]
fill 490 211 257 490 211 259 minecraft:brown_terracotta
setblock 497 211 231 minecraft:light[level=15]
setblock 497 211 239 minecraft:light[level=15]
setblock 497 211 247 minecraft:light[level=15]
setblock 497 211 255 minecraft:light[level=15]
setblock 497 211 263 minecraft:light[level=15]
setblock 505 211 231 minecraft:light[level=15]
setblock 505 211 239 minecraft:light[level=15]
setblock 505 211 247 minecraft:light[level=15]
setblock 505 211 255 minecraft:light[level=15]
setblock 505 211 263 minecraft:light[level=15]
fill 508 211 232 508 215 233 minecraft:white_concrete
fill 508 211 268 508 215 268 minecraft:white_concrete
fill 508 211 269 508 219 269 minecraft:brown_concrete
setblock 509 211 233 minecraft:red_concrete
setblock 509 211 269 minecraft:red_concrete
setblock 510 211 229 minecraft:white_concrete
fill 510 211 230 511 214 230 minecraft:red_concrete
setblock 510 211 265 minecraft:white_concrete
fill 510 211 266 511 214 266 minecraft:red_concrete
fill 473 212 229 473 216 230 minecraft:red_concrete
fill 473 212 232 473 216 233 minecraft:white_concrete
fill 473 212 265 473 216 266 minecraft:red_concrete
fill 473 212 268 473 216 269 minecraft:white_concrete
fill 474 212 229 474 215 229 minecraft:red_concrete
fill 474 212 265 474 215 265 minecraft:red_concrete
fill 482 212 240 484 264 240 minecraft:white_concrete
fill 483 212 239 483 264 239 minecraft:white_concrete
fill 483 212 241 483 264 241 minecraft:white_concrete
fill 495 212 266 496 213 267 minecraft:light_blue_concrete
fill 497 212 266 497 213 266 minecraft:light_blue_concrete
fill 509 212 229 509 216 230 minecraft:red_concrete
fill 509 212 232 509 216 233 minecraft:white_concrete
fill 509 212 265 509 216 266 minecraft:red_concrete
fill 509 212 268 509 216 269 minecraft:white_concrete
fill 510 212 229 510 215 229 minecraft:red_concrete
fill 510 212 265 510 215 265 minecraft:red_concrete
fill 472 213 229 472 217 229 minecraft:red_concrete
setblock 472 213 230 minecraft:white_concrete
fill 472 213 265 472 217 265 minecraft:red_concrete
setblock 472 213 266 minecraft:white_concrete
fill 474 213 232 474 217 233 minecraft:white_concrete
fill 474 213 268 474 217 269 minecraft:white_concrete
setblock 475 213 232 minecraft:red_concrete
setblock 475 213 268 minecraft:red_concrete
fill 482 213 239 482 214 239 minecraft:brown_terracotta
fill 482 213 241 482 214 241 minecraft:brown_terracotta
fill 484 213 239 484 214 239 minecraft:brown_terracotta
fill 484 213 241 484 214 241 minecraft:brown_terracotta
fill 508 213 229 508 217 229 minecraft:red_concrete
setblock 508 213 230 minecraft:white_concrete
fill 508 213 265 508 217 265 minecraft:red_concrete
setblock 508 213 266 minecraft:white_concrete
fill 510 213 232 510 217 233 minecraft:white_concrete
fill 510 213 268 510 217 269 minecraft:white_concrete
setblock 511 213 232 minecraft:red_concrete
setblock 511 213 268 minecraft:red_concrete
fill 471 214 230 472 217 230 minecraft:red_concrete
fill 471 214 266 472 217 266 minecraft:red_concrete
setblock 473 214 238 minecraft:light[level=12]
setblock 473 214 245 minecraft:light[level=12]
setblock 473 214 252 minecraft:light[level=12]
setblock 473 214 259 minecraft:light[level=12]
fill 475 214 232 475 218 232 minecraft:white_concrete
fill 475 214 268 475 218 268 minecraft:white_concrete
fill 479 214 231 483 215 235 minecraft:brown_terracotta
setblock 480 214 238 minecraft:light[level=12]
setblock 480 214 245 minecraft:light[level=12]
setblock 480 214 252 minecraft:light[level=12]
setblock 480 214 259 minecraft:light[level=12]
setblock 480 214 266 minecraft:light[level=12]
fill 481 214 229 481 214 230 minecraft:brown_terracotta
fill 481 214 239 481 214 241 minecraft:brown_terracotta
fill 482 214 238 483 214 238 minecraft:brown_terracotta
fill 482 214 242 483 214 242 minecraft:brown_terracotta
setblock 485 214 240 minecraft:brown_terracotta
setblock 487 214 231 minecraft:light[level=12]
setblock 487 214 238 minecraft:light[level=12]
setblock 487 214 245 minecraft:light[level=12]
setblock 487 214 252 minecraft:light[level=12]
setblock 487 214 266 minecraft:light[level=12]
setblock 494 214 231 minecraft:light[level=12]
setblock 494 214 238 minecraft:light[level=12]
setblock 494 214 252 minecraft:light[level=12]
setblock 494 214 259 minecraft:light[level=12]
setblock 494 214 266 minecraft:light[level=12]
setblock 501 214 231 minecraft:light[level=12]
setblock 501 214 238 minecraft:light[level=12]
setblock 501 214 245 minecraft:light[level=12]
setblock 501 214 252 minecraft:light[level=12]
setblock 501 214 259 minecraft:light[level=12]
setblock 501 214 266 minecraft:light[level=12]
fill 507 214 230 508 217 230 minecraft:red_concrete
fill 507 214 266 508 217 266 minecraft:red_concrete
setblock 508 214 238 minecraft:light[level=12]
setblock 508 214 245 minecraft:light[level=12]
setblock 508 214 252 minecraft:light[level=12]
setblock 508 214 259 minecraft:light[level=12]
fill 511 214 232 511 218 232 minecraft:white_concrete
fill 511 214 268 511 218 268 minecraft:white_concrete
fill 471 215 231 472 219 231 minecraft:red_concrete
setblock 471 215 232 minecraft:white_concrete
fill 471 215 267 472 219 267 minecraft:red_concrete
setblock 471 215 268 minecraft:white_concrete
fill 473 215 231 475 219 231 minecraft:white_concrete
fill 473 215 267 475 219 267 minecraft:white_concrete
setblock 474 215 230 minecraft:red_concrete
setblock 474 215 266 minecraft:red_concrete
fill 475 215 230 475 220 230 minecraft:white_concrete
fill 475 215 266 475 220 266 minecraft:white_concrete
fill 507 215 231 508 219 231 minecraft:red_concrete
setblock 507 215 232 minecraft:white_concrete
fill 507 215 267 508 219 267 minecraft:red_concrete
setblock 507 215 268 minecraft:white_concrete
fill 509 215 231 511 219 231 minecraft:white_concrete
fill 509 215 267 511 219 267 minecraft:white_concrete
setblock 510 215 230 minecraft:red_concrete
setblock 510 215 266 minecraft:red_concrete
fill 511 215 230 511 220 230 minecraft:white_concrete
fill 511 215 266 511 220 266 minecraft:white_concrete
fill 471 216 232 472 219 232 minecraft:red_concrete
fill 471 216 268 472 219 268 minecraft:red_concrete
setblock 472 216 233 minecraft:white_concrete
setblock 472 216 269 minecraft:white_concrete
fill 474 216 229 474 220 230 minecraft:white_concrete
fill 474 216 265 474 220 266 minecraft:white_concrete
fill 480 216 233 482 222 233 minecraft:white_concrete
fill 481 216 232 481 222 232 minecraft:white_concrete
fill 481 216 234 481 222 234 minecraft:white_concrete
fill 507 216 232 508 219 232 minecraft:red_concrete
fill 507 216 268 508 219 268 minecraft:red_concrete
setblock 508 216 233 minecraft:white_concrete
fill 510 216 229 510 220 230 minecraft:white_concrete
fill 510 216 265 510 220 266 minecraft:white_concrete
fill 472 217 233 473 220 233 minecraft:red_concrete
fill 472 217 269 473 220 269 minecraft:red_concrete
fill 473 217 229 473 221 230 minecraft:white_concrete
fill 473 217 232 473 221 232 minecraft:red_concrete
fill 473 217 265 473 221 266 minecraft:white_concrete
fill 473 217 268 473 221 268 minecraft:red_concrete
fill 508 217 233 509 220 233 minecraft:red_concrete
fill 509 217 229 509 221 230 minecraft:white_concrete
fill 509 217 232 509 221 232 minecraft:red_concrete
fill 509 217 265 509 221 266 minecraft:white_concrete
fill 509 217 268 509 221 269 minecraft:red_concrete
setblock 471 218 230 minecraft:red_concrete
setblock 471 218 266 minecraft:red_concrete
fill 472 218 229 472 222 230 minecraft:white_concrete
fill 472 218 265 472 222 266 minecraft:white_concrete
setblock 473 218 239 minecraft:light[level=15]
setblock 473 218 247 minecraft:light[level=15]
setblock 473 218 255 minecraft:light[level=15]
setblock 473 218 263 minecraft:light[level=15]
setblock 474 218 232 minecraft:white_concrete
fill 474 218 233 474 222 233 minecraft:red_concrete
setblock 474 218 268 minecraft:white_concrete
fill 474 218 269 474 222 269 minecraft:red_concrete
setblock 481 218 231 minecraft:light[level=15]
setblock 481 218 239 minecraft:light[level=15]
setblock 481 218 247 minecraft:light[level=15]
setblock 481 218 255 minecraft:light[level=15]
setblock 481 218 263 minecraft:light[level=15]
setblock 489 218 231 minecraft:light[level=15]
setblock 489 218 239 minecraft:light[level=15]
setblock 489 218 247 minecraft:light[level=15]
setblock 489 218 255 minecraft:light[level=15]
setblock 489 218 263 minecraft:light[level=15]
setblock 497 218 231 minecraft:light[level=15]
setblock 497 218 239 minecraft:light[level=15]
setblock 497 218 247 minecraft:light[level=15]
setblock 497 218 255 minecraft:light[level=15]
setblock 497 218 263 minecraft:light[level=15]
setblock 505 218 231 minecraft:light[level=15]
setblock 505 218 239 minecraft:light[level=15]
setblock 505 218 247 minecraft:light[level=15]
setblock 505 218 255 minecraft:light[level=15]
setblock 505 218 263 minecraft:light[level=15]
setblock 507 218 230 minecraft:red_concrete
setblock 507 218 266 minecraft:red_concrete
fill 508 218 229 508 222 230 minecraft:white_concrete
fill 508 218 265 508 222 266 minecraft:white_concrete
setblock 510 218 232 minecraft:white_concrete
fill 510 218 233 510 222 233 minecraft:red_concrete
setblock 510 218 268 minecraft:white_concrete
fill 510 218 269 510 222 269 minecraft:red_concrete
fill 471 219 230 471 222 230 minecraft:white_concrete
fill 471 219 266 471 222 266 minecraft:white_concrete
fill 474 219 232 475 222 232 minecraft:red_concrete
fill 474 219 268 475 222 268 minecraft:red_concrete
fill 507 219 230 507 222 230 minecraft:white_concrete
fill 507 219 266 507 223 266 minecraft:white_concrete
fill 510 219 232 511 222 232 minecraft:red_concrete
fill 510 219 268 511 222 268 minecraft:red_concrete
fill 471 220 231 471 222 232 minecraft:white_concrete
fill 471 220 267 471 222 268 minecraft:white_concrete
fill 472 220 231 472 222 231 minecraft:white_concrete
setblock 472 220 232 minecraft:red_concrete
fill 472 220 267 472 222 267 minecraft:white_concrete
setblock 472 220 268 minecraft:red_concrete
fill 473 220 231 475 222 231 minecraft:red_concrete
setblock 473 220 238 minecraft:light[level=12]
setblock 473 220 245 minecraft:light[level=12]
setblock 473 220 252 minecraft:light[level=12]
setblock 473 220 259 minecraft:light[level=12]
fill 473 220 267 475 222 267 minecraft:red_concrete
setblock 480 220 231 minecraft:light[level=12]
setblock 480 220 238 minecraft:light[level=12]
setblock 480 220 245 minecraft:light[level=12]
setblock 480 220 252 minecraft:light[level=12]
setblock 480 220 259 minecraft:light[level=12]
setblock 480 220 266 minecraft:light[level=12]
setblock 487 220 231 minecraft:light[level=12]
setblock 487 220 238 minecraft:light[level=12]
setblock 487 220 245 minecraft:light[level=12]
setblock 487 220 252 minecraft:light[level=12]
setblock 487 220 266 minecraft:light[level=12]
setblock 494 220 231 minecraft:light[level=12]
setblock 494 220 238 minecraft:light[level=12]
setblock 494 220 252 minecraft:light[level=12]
setblock 494 220 259 minecraft:light[level=12]
setblock 494 220 266 minecraft:light[level=12]
setblock 501 220 231 minecraft:light[level=12]
setblock 501 220 238 minecraft:light[level=12]
setblock 501 220 245 minecraft:light[level=12]
setblock 501 220 252 minecraft:light[level=12]
setblock 501 220 259 minecraft:light[level=12]
setblock 501 220 266 minecraft:light[level=12]
fill 507 220 231 507 222 232 minecraft:white_concrete
fill 507 220 267 507 222 268 minecraft:white_concrete
fill 508 220 231 508 222 231 minecraft:white_concrete
setblock 508 220 232 minecraft:red_concrete
setblock 508 220 238 minecraft:light[level=12]
setblock 508 220 245 minecraft:light[level=12]
setblock 508 220 252 minecraft:light[level=12]
setblock 508 220 259 minecraft:light[level=12]
fill 508 220 267 508 222 267 minecraft:white_concrete
fill 508 220 268 508 220 269 minecraft:red_concrete
fill 509 220 231 511 222 231 minecraft:red_concrete
fill 509 220 267 511 222 267 minecraft:red_concrete
fill 472 221 232 472 222 233 minecraft:white_concrete
fill 472 221 268 472 222 269 minecraft:white_concrete
setblock 473 221 233 minecraft:red_concrete
setblock 473 221 269 minecraft:red_concrete
setblock 474 221 229 minecraft:white_concrete
fill 474 221 230 475 222 230 minecraft:red_concrete
setblock 474 221 265 minecraft:white_concrete
fill 474 221 266 475 224 266 minecraft:red_concrete
fill 479 221 231 479 222 235 minecraft:magenta_concrete
fill 480 221 231 480 222 232 minecraft:magenta_concrete
fill 480 221 234 480 224 235 minecraft:magenta_concrete
fill 481 221 231 483 222 231 minecraft:magenta_concrete
fill 481 221 235 483 224 235 minecraft:magenta_concrete
fill 482 221 232 483 224 232 minecraft:magenta_concrete
fill 482 221 234 483 224 234 minecraft:magenta_concrete
fill 483 221 233 483 224 233 minecraft:magenta_concrete
fill 508 221 232 508 225 233 minecraft:white_concrete
fill 508 221 268 508 222 269 minecraft:white_concrete
setblock 509 221 233 minecraft:red_concrete
setblock 510 221 229 minecraft:white_concrete
fill 510 221 230 511 222 230 minecraft:red_concrete
setblock 510 221 265 minecraft:white_concrete
fill 510 221 266 511 222 266 minecraft:red_concrete
fill 473 222 229 473 222 230 minecraft:red_concrete
fill 473 222 232 473 222 233 minecraft:white_concrete
fill 473 222 265 473 222 266 minecraft:red_concrete
fill 473 222 268 473 222 269 minecraft:white_concrete
setblock 474 222 229 minecraft:red_concrete
fill 474 222 265 474 225 265 minecraft:red_concrete
fill 478 222 231 478 222 235 minecraft:magenta_concrete
fill 479 222 230 483 222 230 minecraft:magenta_concrete
fill 479 222 236 483 223 236 minecraft:magenta_concrete
fill 484 222 231 484 222 235 minecraft:magenta_concrete
fill 509 222 229 509 222 230 minecraft:red_concrete
fill 509 222 232 509 222 233 minecraft:white_concrete
fill 509 222 265 509 222 266 minecraft:red_concrete
fill 509 222 268 509 222 269 minecraft:white_concrete
setblock 510 222 229 minecraft:red_concrete
setblock 510 222 265 minecraft:red_concrete
fill 471 223 229 473 223 269 minecraft:black_concrete
fill 474 223 229 511 223 231 minecraft:black_concrete
fill 474 223 232 474 227 233 minecraft:white_concrete
fill 474 223 267 511 223 269 minecraft:black_concrete
setblock 475 223 232 minecraft:red_concrete
fill 478 223 232 479 223 235 minecraft:magenta_concrete
fill 480 223 232 481 224 233 minecraft:magenta_concrete
fill 481 223 234 481 224 234 minecraft:magenta_concrete
fill 482 223 233 482 224 233 minecraft:magenta_concrete
fill 484 223 232 484 223 235 minecraft:magenta_concrete
fill 507 223 232 507 225 232 minecraft:white_concrete
fill 508 223 265 508 227 265 minecraft:red_concrete
setblock 508 223 266 minecraft:white_concrete
fill 509 223 232 511 223 266 minecraft:black_concrete
fill 471 224 229 473 224 269 minecraft:gray_concrete
fill 474 224 229 511 224 231 minecraft:gray_concrete
fill 474 224 267 511 224 269 minecraft:gray_concrete
fill 475 224 232 475 228 232 minecraft:white_concrete
fill 479 224 232 479 224 235 minecraft:magenta_concrete
fill 507 224 266 508 227 266 minecraft:red_concrete
fill 509 224 232 511 224 266 minecraft:gray_concrete
fill 471 225 230 472 227 231 minecraft:red_concrete
fill 471 225 232 473 225 232 minecraft:white_concrete
setblock 471 225 237 minecraft:orange_concrete
fill 471 225 266 472 227 267 minecraft:red_concrete
fill 471 225 268 475 225 268 minecraft:white_concrete
fill 472 225 229 474 225 229 minecraft:red_concrete
fill 472 225 233 473 226 233 minecraft:white_concrete
setblock 472 225 252 minecraft:light_blue_concrete
fill 472 225 265 473 226 265 minecraft:red_concrete
fill 472 225 269 474 226 269 minecraft:white_concrete
fill 473 225 230 474 225 230 minecraft:red_concrete
fill 473 225 231 475 229 231 minecraft:white_concrete
fill 473 225 234 473 226 234 minecraft:brown_concrete
setblock 473 225 237 minecraft:light_blue_concrete
setblock 473 225 239 minecraft:light[level=15]
setblock 473 225 247 minecraft:light[level=15]
setblock 473 225 255 minecraft:light[level=15]
setblock 473 225 263 minecraft:light[level=15]
fill 473 225 266 474 225 266 minecraft:red_concrete
fill 473 225 267 475 229 267 minecraft:white_concrete
fill 475 225 230 475 230 230 minecraft:white_concrete
fill 475 225 266 475 230 266 minecraft:white_concrete
fill 478 225 230 478 226 230 minecraft:brown_concrete
setblock 481 225 231 minecraft:light[level=15]
setblock 481 225 239 minecraft:light[level=15]
setblock 481 225 247 minecraft:light[level=15]
setblock 481 225 255 minecraft:light[level=15]
setblock 481 225 263 minecraft:light[level=15]
setblock 489 225 231 minecraft:light[level=15]
setblock 489 225 239 minecraft:light[level=15]
setblock 489 225 247 minecraft:light[level=15]
setblock 489 225 255 minecraft:light[level=15]
setblock 489 225 263 minecraft:light[level=15]
fill 493 225 229 493 226 229 minecraft:brown_concrete
setblock 496 225 229 minecraft:orange_concrete
setblock 496 225 268 minecraft:yellow_concrete
setblock 497 225 231 minecraft:light[level=15]
setblock 497 225 239 minecraft:light[level=15]
setblock 497 225 247 minecraft:light[level=15]
setblock 497 225 255 minecraft:light[level=15]
setblock 497 225 263 minecraft:light[level=15]
fill 497 225 269 497 226 269 minecraft:brown_concrete
setblock 498 225 269 minecraft:orange_concrete
setblock 505 225 231 minecraft:light[level=15]
setblock 505 225 239 minecraft:light[level=15]
setblock 505 225 247 minecraft:light[level=15]
setblock 505 225 255 minecraft:light[level=15]
setblock 505 225 263 minecraft:light[level=15]
fill 507 225 230 508 227 231 minecraft:red_concrete
fill 507 225 267 508 229 267 minecraft:red_concrete
fill 507 225 268 511 225 268 minecraft:white_concrete
fill 508 225 229 510 225 229 minecraft:red_concrete
fill 508 225 269 510 226 269 minecraft:white_concrete
fill 509 225 230 510 225 230 minecraft:red_concrete
fill 509 225 231 510 226 233 minecraft:white_concrete
fill 509 225 265 510 225 266 minecraft:red_concrete
fill 509 225 267 511 229 267 minecraft:white_concrete
setblock 510 225 236 minecraft:magenta_concrete
setblock 510 225 238 minecraft:white_concrete
setblock 510 225 240 minecraft:white_concrete
fill 510 225 247 510 226 247 minecraft:brown_concrete
fill 511 225 230 511 228 232 minecraft:white_concrete
setblock 511 225 238 minecraft:lime_concrete
setblock 511 225 241 minecraft:magenta_concrete
fill 511 225 266 511 230 266 minecraft:white_concrete
fill 471 226 232 472 229 232 minecraft:red_concrete
fill 471 226 268 472 229 268 minecraft:red_concrete
fill 472 226 229 473 226 229 minecraft:red_concrete
setblock 473 226 230 minecraft:red_concrete
setblock 473 226 232 minecraft:white_concrete
setblock 473 226 238 minecraft:light[level=12]
setblock 473 226 245 minecraft:light[level=12]
setblock 473 226 252 minecraft:light[level=12]
setblock 473 226 259 minecraft:light[level=12]
setblock 473 226 266 minecraft:red_concrete
fill 473 226 268 475 226 268 minecraft:white_concrete
fill 474 226 229 474 230 230 minecraft:white_concrete
fill 474 226 265 474 230 266 minecraft:white_concrete
setblock 480 226 231 minecraft:light[level=12]
setblock 480 226 238 minecraft:light[level=12]
setblock 480 226 245 minecraft:light[level=12]
setblock 480 226 252 minecraft:light[level=12]
setblock 480 226 259 minecraft:light[level=12]
setblock 480 226 266 minecraft:light[level=12]
setblock 487 226 231 minecraft:light[level=12]
setblock 487 226 238 minecraft:light[level=12]
setblock 487 226 245 minecraft:light[level=12]
setblock 487 226 252 minecraft:light[level=12]
setblock 487 226 266 minecraft:light[level=12]
fill 493 226 235 494 227 236 minecraft:yellow_concrete
setblock 494 226 231 minecraft:light[level=12]
fill 494 226 234 495 227 234 minecraft:yellow_concrete
fill 494 226 237 494 227 238 minecraft:yellow_concrete
setblock 494 226 252 minecraft:light[level=12]
setblock 494 226 259 minecraft:light[level=12]
setblock 494 226 266 minecraft:light[level=12]
fill 495 226 233 497 227 233 minecraft:yellow_concrete
fill 495 226 238 497 227 238 minecraft:yellow_concrete
fill 497 226 234 498 227 234 minecraft:yellow_concrete
fill 497 226 237 498 227 237 minecraft:yellow_concrete
fill 498 226 235 498 227 236 minecraft:yellow_concrete
setblock 501 226 231 minecraft:light[level=12]
setblock 501 226 238 minecraft:light[level=12]
setblock 501 226 245 minecraft:light[level=12]
setblock 501 226 252 minecraft:light[level=12]
setblock 501 226 259 minecraft:light[level=12]
setblock 501 226 266 minecraft:light[level=12]
fill 507 226 232 508 229 232 minecraft:red_concrete
fill 507 226 268 508 229 268 minecraft:red_concrete
fill 508 226 229 509 226 229 minecraft:red_concrete
setblock 508 226 233 minecraft:white_concrete
setblock 508 226 238 minecraft:light[level=12]
setblock 508 226 245 minecraft:light[level=12]
setblock 508 226 252 minecraft:light[level=12]
setblock 508 226 259 minecraft:light[level=12]
setblock 509 226 230 minecraft:red_concrete
fill 509 226 265 509 226 266 minecraft:red_concrete
fill 509 226 268 511 226 268 minecraft:white_concrete
fill 510 226 229 510 230 230 minecraft:white_concrete
fill 510 226 265 510 230 266 minecraft:white_concrete
setblock 472 227 229 minecraft:red_concrete
fill 472 227 233 473 230 233 minecraft:red_concrete
setblock 472 227 265 minecraft:red_concrete
fill 472 227 269 473 230 269 minecraft:red_concrete
fill 473 227 229 473 231 230 minecraft:white_concrete
fill 473 227 232 473 231 232 minecraft:red_concrete
fill 473 227 265 473 231 266 minecraft:white_concrete
fill 473 227 268 473 231 268 minecraft:red_concrete
fill 474 227 268 474 227 269 minecraft:white_concrete
fill 475 227 268 475 228 268 minecraft:white_concrete
setblock 508 227 229 minecraft:red_concrete
fill 508 227 233 509 230 233 minecraft:red_concrete
fill 508 227 269 509 229 269 minecraft:red_concrete
fill 509 227 229 509 229 231 minecraft:white_concrete
fill 509 227 232 509 231 232 minecraft:red_concrete
fill 509 227 265 509 231 266 minecraft:white_concrete
fill 509 227 268 509 231 268 minecraft:red_concrete
fill 510 227 231 510 227 233 minecraft:white_concrete
fill 510 227 268 510 227 269 minecraft:white_concrete
fill 511 227 268 511 228 268 minecraft:white_concrete
fill 471 228 230 471 228 231 minecraft:red_concrete
fill 471 228 266 471 228 267 minecraft:red_concrete
fill 472 228 229 472 232 230 minecraft:white_concrete
fill 472 228 231 472 229 231 minecraft:red_concrete
fill 472 228 265 472 232 266 minecraft:white_concrete
fill 472 228 267 472 229 267 minecraft:red_concrete
setblock 474 228 232 minecraft:white_concrete
fill 474 228 233 474 232 233 minecraft:red_concrete
setblock 474 228 268 minecraft:white_concrete
fill 474 228 269 474 232 269 minecraft:red_concrete
fill 489 228 239 490 229 240 minecraft:yellow_concrete
fill 507 228 230 507 228 231 minecraft:red_concrete
setblock 507 228 266 minecraft:red_concrete
fill 508 228 229 508 232 230 minecraft:white_concrete
fill 508 228 231 508 229 231 minecraft:red_concrete
fill 508 228 265 508 232 266 minecraft:white_concrete
fill 510 228 231 510 228 232 minecraft:white_concrete
fill 510 228 233 510 232 233 minecraft:red_concrete
setblock 510 228 268 minecraft:white_concrete
fill 510 228 269 510 232 269 minecraft:red_concrete
fill 471 229 230 471 233 230 minecraft:white_concrete
setblock 471 229 231 minecraft:red_concrete
fill 471 229 266 471 233 266 minecraft:white_concrete
setblock 471 229 267 minecraft:red_concrete
fill 474 229 232 475 232 232 minecraft:red_concrete
fill 474 229 268 475 232 268 minecraft:red_concrete
fill 503 229 260 504 230 260 minecraft:light_blue_concrete
fill 507 229 230 507 233 230 minecraft:white_concrete
setblock 507 229 231 minecraft:red_concrete
fill 507 229 266 507 233 266 minecraft:white_concrete
fill 510 229 231 511 229 231 minecraft:white_concrete
fill 510 229 232 511 232 232 minecraft:red_concrete
fill 510 229 268 511 232 268 minecraft:red_concrete
fill 511 229 230 511 230 230 minecraft:white_concrete
fill 471 230 231 471 234 232 minecraft:white_concrete
fill 471 230 267 471 234 268 minecraft:white_concrete
fill 472 230 231 472 234 231 minecraft:white_concrete
setblock 472 230 232 minecraft:red_concrete
fill 472 230 267 472 234 267 minecraft:white_concrete
setblock 472 230 268 minecraft:red_concrete
fill 473 230 231 475 234 231 minecraft:red_concrete
fill 473 230 267 475 234 267 minecraft:red_concrete
fill 507 230 231 507 234 232 minecraft:white_concrete
fill 507 230 267 507 234 268 minecraft:white_concrete
fill 508 230 231 508 234 231 minecraft:white_concrete
setblock 508 230 232 minecraft:red_concrete
fill 508 230 267 508 234 267 minecraft:white_concrete
setblock 508 230 268 minecraft:red_concrete
fill 508 230 269 508 238 269 minecraft:brown_terracotta
fill 509 230 229 509 231 230 minecraft:white_concrete
fill 509 230 231 511 234 231 minecraft:red_concrete
fill 509 230 267 511 234 267 minecraft:red_concrete
fill 509 230 269 509 231 269 minecraft:red_concrete
fill 472 231 232 472 235 233 minecraft:white_concrete
fill 472 231 268 472 235 269 minecraft:white_concrete
setblock 473 231 233 minecraft:red_concrete
setblock 473 231 269 minecraft:red_concrete
setblock 474 231 229 minecraft:white_concrete
fill 474 231 230 475 234 230 minecraft:red_concrete
setblock 474 231 265 minecraft:white_concrete
fill 474 231 266 475 234 266 minecraft:red_concrete
fill 508 231 232 508 235 233 minecraft:white_concrete
fill 508 231 268 508 235 268 minecraft:white_concrete
setblock 509 231 233 minecraft:red_concrete
setblock 510 231 229 minecraft:white_concrete
fill 510 231 230 511 234 230 minecraft:red_concrete
setblock 510 231 265 minecraft:white_concrete
fill 510 231 266 511 234 266 minecraft:red_concrete
fill 473 232 229 473 236 230 minecraft:red_concrete
fill 473 232 232 473 236 233 minecraft:white_concrete
setblock 473 232 238 minecraft:light[level=12]
setblock 473 232 239 minecraft:light[level=15]
setblock 473 232 245 minecraft:light[level=12]
setblock 473 232 247 minecraft:light[level=15]
setblock 473 232 252 minecraft:light[level=12]
setblock 473 232 255 minecraft:light[level=15]
setblock 473 232 259 minecraft:light[level=12]
setblock 473 232 263 minecraft:light[level=15]
fill 473 232 265 473 236 266 minecraft:red_concrete
fill 473 232 268 473 236 269 minecraft:white_concrete
fill 474 232 229 474 235 229 minecraft:red_concrete
fill 474 232 265 474 235 265 minecraft:red_concrete
setblock 480 232 231 minecraft:light[level=12]
setblock 480 232 238 minecraft:light[level=12]
setblock 480 232 245 minecraft:light[level=12]
setblock 480 232 252 minecraft:light[level=12]
setblock 480 232 259 minecraft:light[level=12]
setblock 480 232 266 minecraft:light[level=12]
setblock 481 232 231 minecraft:light[level=15]
setblock 481 232 239 minecraft:light[level=15]
setblock 481 232 247 minecraft:light[level=15]
setblock 481 232 255 minecraft:light[level=15]
setblock 481 232 263 minecraft:light[level=15]
setblock 487 232 231 minecraft:light[level=12]
setblock 487 232 238 minecraft:light[level=12]
fill 487 232 240 488 233 240 minecraft:yellow_concrete
setblock 487 232 245 minecraft:light[level=12]
setblock 487 232 252 minecraft:light[level=12]
setblock 487 232 266 minecraft:light[level=12]
setblock 489 232 231 minecraft:light[level=15]
setblock 489 232 239 minecraft:light[level=15]
setblock 489 232 247 minecraft:light[level=15]
setblock 489 232 255 minecraft:light[level=15]
setblock 489 232 263 minecraft:light[level=15]
setblock 494 232 231 minecraft:light[level=12]
setblock 494 232 238 minecraft:light[level=12]
setblock 494 232 245 minecraft:light[level=12]
setblock 494 232 252 minecraft:light[level=12]
setblock 494 232 259 minecraft:light[level=12]
setblock 494 232 266 minecraft:light[level=12]
setblock 497 232 231 minecraft:light[level=15]
setblock 497 232 239 minecraft:light[level=15]
setblock 497 232 247 minecraft:light[level=15]
setblock 497 232 255 minecraft:light[level=15]
setblock 497 232 263 minecraft:light[level=15]
setblock 501 232 231 minecraft:light[level=12]
setblock 501 232 238 minecraft:light[level=12]
setblock 501 232 245 minecraft:light[level=12]
setblock 501 232 252 minecraft:light[level=12]
setblock 501 232 259 minecraft:light[level=12]
setblock 501 232 266 minecraft:light[level=12]
setblock 505 232 231 minecraft:light[level=15]
setblock 505 232 239 minecraft:light[level=15]
setblock 505 232 247 minecraft:light[level=15]
setblock 505 232 255 minecraft:light[level=15]
setblock 505 232 263 minecraft:light[level=15]
setblock 508 232 238 minecraft:light[level=12]
setblock 508 232 245 minecraft:light[level=12]
setblock 508 232 252 minecraft:light[level=12]
setblock 508 232 259 minecraft:light[level=12]
fill 509 232 229 509 236 230 minecraft:red_concrete
fill 509 232 232 509 236 233 minecraft:white_concrete
fill 509 232 265 509 236 266 minecraft:red_concrete
fill 509 232 268 509 236 269 minecraft:white_concrete
fill 510 232 229 510 235 229 minecraft:red_concrete
fill 510 232 265 510 235 265 minecraft:red_concrete
fill 472 233 229 472 237 229 minecraft:red_concrete
setblock 472 233 230 minecraft:white_concrete
fill 472 233 265 472 237 265 minecraft:red_concrete
setblock 472 233 266 minecraft:white_concrete
fill 474 233 232 474 237 233 minecraft:white_concrete
fill 474 233 268 474 237 269 minecraft:white_concrete
setblock 475 233 232 minecraft:red_concrete
setblock 475 233 268 minecraft:red_concrete
fill 508 233 229 508 237 229 minecraft:red_concrete
setblock 508 233 230 minecraft:white_concrete
fill 508 233 265 508 237 265 minecraft:red_concrete
setblock 508 233 266 minecraft:white_concrete
fill 510 233 232 510 237 233 minecraft:white_concrete
fill 510 233 268 510 237 269 minecraft:white_concrete
setblock 511 233 232 minecraft:red_concrete
setblock 511 233 268 minecraft:red_concrete
fill 471 234 230 472 237 230 minecraft:red_concrete
fill 471 234 266 472 237 266 minecraft:red_concrete
fill 475 234 232 475 238 232 minecraft:white_concrete
fill 475 234 268 475 238 268 minecraft:white_concrete
fill 507 234 230 508 237 230 minecraft:red_concrete
fill 507 234 266 508 237 266 minecraft:red_concrete
fill 511 234 232 511 238 232 minecraft:white_concrete
fill 511 234 268 511 238 268 minecraft:white_concrete
fill 471 235 231 472 239 231 minecraft:red_concrete
setblock 471 235 232 minecraft:white_concrete
fill 471 235 267 472 239 267 minecraft:red_concrete
setblock 471 235 268 minecraft:white_concrete
fill 473 235 231 475 239 231 minecraft:white_concrete
fill 473 235 267 475 239 267 minecraft:white_concrete
setblock 474 235 230 minecraft:red_concrete
setblock 474 235 266 minecraft:red_concrete
fill 475 235 230 475 240 230 minecraft:white_concrete
fill 475 235 266 475 240 266 minecraft:white_concrete
fill 507 235 231 508 239 231 minecraft:red_concrete
setblock 507 235 232 minecraft:white_concrete
fill 507 235 267 508 239 267 minecraft:red_concrete
setblock 507 235 268 minecraft:white_concrete
fill 509 235 231 511 239 231 minecraft:white_concrete
fill 509 235 267 511 239 267 minecraft:white_concrete
setblock 510 235 230 minecraft:red_concrete
setblock 510 235 266 minecraft:red_concrete
fill 511 235 230 511 240 230 minecraft:white_concrete
fill 511 235 266 511 240 266 minecraft:white_concrete
fill 471 236 232 472 239 232 minecraft:red_concrete
fill 471 236 268 472 239 268 minecraft:red_concrete
setblock 472 236 233 minecraft:white_concrete
setblock 472 236 269 minecraft:white_concrete
fill 474 236 229 474 240 230 minecraft:white_concrete
fill 474 236 265 474 240 266 minecraft:white_concrete
fill 507 236 232 508 239 232 minecraft:red_concrete
fill 507 236 268 508 239 268 minecraft:red_concrete
setblock 508 236 233 minecraft:white_concrete
fill 510 236 229 510 240 230 minecraft:white_concrete
fill 510 236 265 510 240 266 minecraft:white_concrete
fill 472 237 233 473 240 233 minecraft:red_concrete
fill 472 237 269 473 240 269 minecraft:red_concrete
fill 473 237 229 473 241 230 minecraft:white_concrete
fill 473 237 232 473 241 232 minecraft:red_concrete
fill 473 237 265 473 241 266 minecraft:white_concrete
fill 473 237 268 473 241 268 minecraft:red_concrete
fill 508 237 233 509 240 233 minecraft:red_concrete
fill 509 237 229 509 241 230 minecraft:white_concrete
fill 509 237 232 509 241 232 minecraft:red_concrete
fill 509 237 265 509 241 266 minecraft:white_concrete
fill 509 237 268 509 241 269 minecraft:red_concrete
setblock 471 238 230 minecraft:red_concrete
setblock 471 238 266 minecraft:red_concrete
fill 472 238 229 472 242 230 minecraft:white_concrete
fill 472 238 265 472 242 266 minecraft:white_concrete
setblock 473 238 238 minecraft:light[level=12]
setblock 473 238 245 minecraft:light[level=12]
setblock 473 238 252 minecraft:light[level=12]
setblock 473 238 259 minecraft:light[level=12]
setblock 474 238 232 minecraft:white_concrete
fill 474 238 233 474 242 233 minecraft:red_concrete
setblock 474 238 268 minecraft:white_concrete
fill 474 238 269 474 242 269 minecraft:red_concrete
setblock 480 238 231 minecraft:light[level=12]
setblock 480 238 238 minecraft:light[level=12]
setblock 480 238 245 minecraft:light[level=12]
setblock 480 238 252 minecraft:light[level=12]
setblock 480 238 259 minecraft:light[level=12]
setblock 480 238 266 minecraft:light[level=12]
setblock 487 238 231 minecraft:light[level=12]
setblock 487 238 238 minecraft:light[level=12]
setblock 487 238 245 minecraft:light[level=12]
setblock 487 238 252 minecraft:light[level=12]
setblock 487 238 266 minecraft:light[level=12]
setblock 494 238 231 minecraft:light[level=12]
setblock 494 238 238 minecraft:light[level=12]
setblock 494 238 245 minecraft:light[level=12]
setblock 494 238 252 minecraft:light[level=12]
setblock 494 238 259 minecraft:light[level=12]
setblock 494 238 266 minecraft:light[level=12]
setblock 501 238 231 minecraft:light[level=12]
setblock 501 238 238 minecraft:light[level=12]
setblock 501 238 245 minecraft:light[level=12]
setblock 501 238 252 minecraft:light[level=12]
setblock 501 238 259 minecraft:light[level=12]
setblock 501 238 266 minecraft:light[level=12]
setblock 507 238 230 minecraft:red_concrete
setblock 507 238 266 minecraft:red_concrete
fill 508 238 229 508 242 230 minecraft:white_concrete
setblock 508 238 238 minecraft:light[level=12]
setblock 508 238 245 minecraft:light[level=12]
setblock 508 238 252 minecraft:light[level=12]
setblock 508 238 259 minecraft:light[level=12]
fill 508 238 265 508 242 266 minecraft:white_concrete
setblock 510 238 232 minecraft:white_concrete
fill 510 238 233 510 242 233 minecraft:red_concrete
setblock 510 238 268 minecraft:white_concrete
fill 510 238 269 510 242 269 minecraft:red_concrete
fill 471 239 230 471 243 230 minecraft:white_concrete
fill 471 239 266 471 243 266 minecraft:white_concrete
setblock 473 239 239 minecraft:light[level=15]
setblock 473 239 247 minecraft:light[level=15]
setblock 473 239 255 minecraft:light[level=15]
setblock 473 239 263 minecraft:light[level=15]
fill 474 239 232 475 242 232 minecraft:red_concrete
fill 474 239 268 475 242 268 minecraft:red_concrete
setblock 481 239 231 minecraft:light[level=15]
setblock 481 239 239 minecraft:light[level=15]
setblock 481 239 247 minecraft:light[level=15]
setblock 481 239 255 minecraft:light[level=15]
setblock 481 239 263 minecraft:light[level=15]
setblock 489 239 231 minecraft:light[level=15]
setblock 489 239 239 minecraft:light[level=15]
setblock 489 239 247 minecraft:light[level=15]
setblock 489 239 255 minecraft:light[level=15]
setblock 489 239 263 minecraft:light[level=15]
setblock 497 239 231 minecraft:light[level=15]
setblock 497 239 239 minecraft:light[level=15]
setblock 497 239 247 minecraft:light[level=15]
setblock 497 239 255 minecraft:light[level=15]
setblock 497 239 263 minecraft:light[level=15]
setblock 505 239 231 minecraft:light[level=15]
setblock 505 239 239 minecraft:light[level=15]
setblock 505 239 247 minecraft:light[level=15]
setblock 505 239 255 minecraft:light[level=15]
setblock 505 239 263 minecraft:light[level=15]
fill 507 239 230 507 243 230 minecraft:white_concrete
fill 507 239 266 507 243 266 minecraft:white_concrete
fill 508 239 269 508 240 269 minecraft:red_concrete
fill 510 239 232 511 242 232 minecraft:red_concrete
fill 510 239 268 511 242 268 minecraft:red_concrete
fill 471 240 231 471 243 232 minecraft:white_concrete
fill 471 240 267 471 243 268 minecraft:white_concrete
fill 472 240 231 472 243 231 minecraft:white_concrete
setblock 472 240 232 minecraft:red_concrete
fill 472 240 267 472 243 267 minecraft:white_concrete
setblock 472 240 268 minecraft:red_concrete
fill 473 240 231 475 243 231 minecraft:red_concrete
fill 473 240 267 475 243 267 minecraft:red_concrete
fill 507 240 231 507 243 232 minecraft:white_concrete
fill 507 240 267 507 243 268 minecraft:white_concrete
fill 508 240 231 508 243 231 minecraft:white_concrete
setblock 508 240 232 minecraft:red_concrete
fill 508 240 267 508 243 267 minecraft:white_concrete
setblock 508 240 268 minecraft:red_concrete
fill 509 240 231 511 243 231 minecraft:red_concrete
fill 509 240 267 511 243 267 minecraft:red_concrete
fill 472 241 232 472 243 233 minecraft:white_concrete
fill 472 241 268 472 243 269 minecraft:white_concrete
setblock 473 241 233 minecraft:red_concrete
setblock 473 241 269 minecraft:red_concrete
setblock 474 241 229 minecraft:white_concrete
fill 474 241 230 475 243 230 minecraft:red_concrete
setblock 474 241 265 minecraft:white_concrete
fill 474 241 266 475 244 266 minecraft:red_concrete
fill 508 241 232 508 245 233 minecraft:white_concrete
fill 508 241 268 508 243 269 minecraft:white_concrete
setblock 509 241 233 minecraft:red_concrete
setblock 510 241 229 minecraft:white_concrete
fill 510 241 230 511 243 230 minecraft:red_concrete
setblock 510 241 265 minecraft:white_concrete
fill 510 241 266 511 243 266 minecraft:red_concrete
fill 473 242 229 473 243 230 minecraft:red_concrete
fill 473 242 232 473 243 233 minecraft:white_concrete
fill 473 242 265 473 243 266 minecraft:red_concrete
fill 473 242 268 473 243 269 minecraft:white_concrete
fill 474 242 229 474 243 229 minecraft:red_concrete
fill 474 242 265 474 245 265 minecraft:red_concrete
fill 487 242 229 487 250 229 minecraft:brown_concrete
fill 509 242 229 509 243 230 minecraft:red_concrete
fill 509 242 232 509 243 233 minecraft:white_concrete
fill 509 242 265 509 243 266 minecraft:red_concrete
fill 509 242 268 509 243 269 minecraft:white_concrete
fill 510 242 229 510 243 229 minecraft:red_concrete
fill 510 242 265 510 243 265 minecraft:red_concrete
setblock 472 243 229 minecraft:red_concrete
setblock 472 243 230 minecraft:white_concrete
setblock 472 243 265 minecraft:red_concrete
setblock 472 243 266 minecraft:white_concrete
fill 474 243 232 474 247 233 minecraft:white_concrete
fill 474 243 268 474 243 269 minecraft:white_concrete
setblock 475 243 232 minecraft:red_concrete
setblock 475 243 268 minecraft:red_concrete
fill 483 243 269 483 251 269 minecraft:brown_terracotta
setblock 508 243 229 minecraft:red_concrete
setblock 508 243 230 minecraft:white_concrete
fill 508 243 265 508 247 265 minecraft:red_concrete
setblock 508 243 266 minecraft:white_concrete
fill 510 243 232 510 243 233 minecraft:white_concrete
fill 510 243 268 510 243 269 minecraft:white_concrete
setblock 511 243 232 minecraft:red_concrete
setblock 511 243 268 minecraft:red_concrete
fill 470 244 235 511 247 235 minecraft:brown_terracotta
fill 471 244 229 473 244 234 minecraft:black_concrete
fill 471 244 236 473 244 269 minecraft:black_concrete
fill 474 244 229 486 244 231 minecraft:black_concrete
fill 474 244 267 482 244 269 minecraft:black_concrete
fill 475 244 232 475 248 232 minecraft:white_concrete
setblock 480 244 238 minecraft:light[level=12]
setblock 480 244 245 minecraft:light[level=12]
setblock 480 244 252 minecraft:light[level=12]
setblock 480 244 259 minecraft:light[level=12]
setblock 480 244 266 minecraft:light[level=12]
fill 483 244 267 511 244 268 minecraft:black_concrete
fill 484 244 269 511 244 269 minecraft:black_concrete
fill 487 244 230 511 244 231 minecraft:black_concrete
setblock 487 244 238 minecraft:light[level=12]
setblock 487 244 245 minecraft:light[level=12]
setblock 487 244 252 minecraft:light[level=12]
setblock 487 244 266 minecraft:light[level=12]
fill 488 244 229 511 244 229 minecraft:black_concrete
setblock 494 244 238 minecraft:light[level=12]
setblock 494 244 245 minecraft:light[level=12]
setblock 494 244 252 minecraft:light[level=12]
setblock 494 244 259 minecraft:light[level=12]
setblock 494 244 266 minecraft:light[level=12]
setblock 501 244 238 minecraft:light[level=12]
setblock 501 244 245 minecraft:light[level=12]
setblock 501 244 252 minecraft:light[level=12]
setblock 501 244 259 minecraft:light[level=12]
setblock 501 244 266 minecraft:light[level=12]
fill 507 244 232 507 245 232 minecraft:white_concrete
fill 507 244 266 508 247 266 minecraft:red_concrete
setblock 508 244 238 minecraft:light[level=12]
setblock 508 244 245 minecraft:light[level=12]
setblock 508 244 252 minecraft:light[level=12]
setblock 508 244 259 minecraft:light[level=12]
fill 509 244 232 511 244 234 minecraft:black_concrete
fill 509 244 236 511 244 266 minecraft:black_concrete
fill 470 245 234 511 246 234 minecraft:brown_terracotta
fill 470 245 236 511 246 236 minecraft:brown_terracotta
fill 471 245 229 473 245 233 minecraft:gray_concrete
fill 471 245 237 473 245 269 minecraft:gray_concrete
fill 474 245 229 486 245 231 minecraft:gray_concrete
setblock 474 245 266 minecraft:red_concrete
fill 474 245 267 482 245 269 minecraft:gray_concrete
fill 475 245 266 475 250 266 minecraft:white_concrete
fill 483 245 267 511 245 268 minecraft:gray_concrete
fill 484 245 269 511 245 269 minecraft:gray_concrete
fill 487 245 230 511 245 231 minecraft:gray_concrete
fill 488 245 229 511 245 229 minecraft:gray_concrete
fill 509 245 232 511 245 233 minecraft:gray_concrete
fill 509 245 237 511 245 266 minecraft:gray_concrete
fill 512 245 235 512 246 235 minecraft:brown_terracotta
fill 471 246 230 472 247 232 minecraft:red_concrete
setblock 471 246 256 minecraft:red_concrete
fill 471 246 266 472 247 268 minecraft:red_concrete
fill 472 246 229 473 246 229 minecraft:red_concrete
fill 472 246 233 473 246 233 minecraft:white_concrete
fill 472 246 265 473 246 265 minecraft:red_concrete
fill 472 246 269 474 246 269 minecraft:white_concrete
setblock 473 246 230 minecraft:red_concrete
fill 473 246 231 473 246 232 minecraft:white_concrete
setblock 473 246 239 minecraft:light[level=15]
setblock 473 246 247 minecraft:light[level=15]
setblock 473 246 255 minecraft:light[level=15]
setblock 473 246 263 minecraft:light[level=15]
setblock 473 246 266 minecraft:red_concrete
fill 473 246 267 475 246 268 minecraft:white_concrete
fill 474 246 229 474 249 231 minecraft:white_concrete
fill 474 246 265 474 250 266 minecraft:white_concrete
fill 475 246 230 475 249 231 minecraft:white_concrete
fill 479 246 267 479 247 267 minecraft:brown_concrete
setblock 481 246 231 minecraft:light[level=15]
setblock 481 246 239 minecraft:light[level=15]
setblock 481 246 247 minecraft:light[level=15]
setblock 481 246 255 minecraft:light[level=15]
setblock 481 246 263 minecraft:light[level=15]
setblock 482 246 229 minecraft:yellow_concrete
setblock 485 246 268 minecraft:lime_concrete
setblock 486 246 230 minecraft:magenta_concrete
setblock 486 246 267 minecraft:light_blue_concrete
setblock 489 246 231 minecraft:light[level=15]
setblock 489 246 239 minecraft:light[level=15]
setblock 489 246 247 minecraft:light[level=15]
setblock 489 246 255 minecraft:light[level=15]
setblock 489 246 263 minecraft:light[level=15]
fill 492 246 269 492 247 269 minecraft:brown_concrete
setblock 497 246 231 minecraft:light[level=15]
setblock 497 246 239 minecraft:light[level=15]
setblock 497 246 247 minecraft:light[level=15]
setblock 497 246 255 minecraft:light[level=15]
setblock 497 246 263 minecraft:light[level=15]
fill 502 246 268 502 247 268 minecraft:brown_concrete
fill 504 246 269 504 247 269 minecraft:brown_concrete
setblock 505 246 231 minecraft:light[level=15]
setblock 505 246 239 minecraft:light[level=15]
setblock 505 246 247 minecraft:light[level=15]
setblock 505 246 255 minecraft:light[level=15]
setblock 505 246 263 minecraft:light[level=15]
fill 507 246 230 508 247 232 minecraft:red_concrete
fill 507 246 267 508 249 268 minecraft:red_concrete
fill 508 246 229 509 246 229 minecraft:red_concrete
fill 508 246 233 510 246 233 minecraft:white_concrete
fill 508 246 269 510 246 269 minecraft:white_concrete
setblock 509 246 230 minecraft:red_concrete
fill 509 246 231 511 246 232 minecraft:white_concrete
fill 509 246 265 509 246 266 minecraft:red_concrete
fill 509 246 267 511 246 268 minecraft:white_concrete
fill 510 246 229 510 250 230 minecraft:white_concrete
setblock 510 246 249 minecraft:lime_concrete
setblock 510 246 261 minecraft:red_concrete
fill 510 246 265 510 250 266 minecraft:white_concrete
fill 511 246 230 511 250 230 minecraft:white_concrete
setblock 511 246 245 minecraft:light_blue_concrete
setblock 511 246 259 minecraft:red_concrete
setblock 511 246 262 minecraft:magenta_concrete
fill 511 246 266 511 250 266 minecraft:white_concrete
fill 470 247 234 470 308 234 minecraft:light_blue_concrete
fill 470 247 236 470 308 236 minecraft:light_blue_concrete
setblock 472 247 229 minecraft:red_concrete
fill 472 247 233 473 250 233 minecraft:red_concrete
setblock 472 247 265 minecraft:red_concrete
fill 472 247 269 473 250 269 minecraft:red_concrete
fill 473 247 229 473 249 231 minecraft:white_concrete
fill 473 247 232 473 251 232 minecraft:red_concrete
fill 473 247 265 473 249 267 minecraft:white_concrete
fill 473 247 268 473 251 268 minecraft:red_concrete
fill 474 247 267 474 247 269 minecraft:white_concrete
fill 475 247 267 475 248 268 minecraft:white_concrete
setblock 508 247 229 minecraft:red_concrete
fill 508 247 233 509 250 233 minecraft:red_concrete
fill 508 247 269 509 250 269 minecraft:red_concrete
fill 509 247 229 509 249 231 minecraft:white_concrete
fill 509 247 232 509 251 232 minecraft:red_concrete
fill 509 247 265 509 249 267 minecraft:white_concrete
fill 509 247 268 509 251 268 minecraft:red_concrete
fill 510 247 231 510 247 233 minecraft:white_concrete
fill 510 247 267 510 247 269 minecraft:white_concrete
fill 511 247 231 511 248 232 minecraft:white_concrete
fill 511 247 267 511 248 268 minecraft:white_concrete
fill 512 247 235 512 308 235 minecraft:light_blue_concrete
fill 470 248 235 470 308 235 minecraft:light_blue_concrete
fill 471 248 230 471 248 232 minecraft:red_concrete
fill 471 248 266 471 248 268 minecraft:red_concrete
fill 472 248 229 472 252 230 minecraft:white_concrete
fill 472 248 231 472 249 232 minecraft:red_concrete
fill 472 248 265 472 252 266 minecraft:white_concrete
fill 472 248 267 472 249 268 minecraft:red_concrete
setblock 474 248 232 minecraft:white_concrete
fill 474 248 233 474 252 233 minecraft:red_concrete
fill 474 248 267 474 248 268 minecraft:white_concrete
fill 474 248 269 474 252 269 minecraft:red_concrete
fill 479 248 240 480 249 241 minecraft:yellow_concrete
fill 481 248 235 482 248 235 minecraft:lime_concrete
fill 481 248 241 481 249 241 minecraft:yellow_concrete
fill 507 248 230 507 248 232 minecraft:red_concrete
setblock 507 248 266 minecraft:red_concrete
fill 508 248 229 508 252 230 minecraft:white_concrete
fill 508 248 231 508 249 232 minecraft:red_concrete
fill 508 248 265 508 252 266 minecraft:white_concrete
fill 510 248 231 510 248 232 minecraft:white_concrete
fill 510 248 233 510 252 233 minecraft:red_concrete
fill 510 248 267 510 248 268 minecraft:white_concrete
fill 510 248 269 510 252 269 minecraft:red_concrete
fill 471 249 230 471 253 230 minecraft:white_concrete
fill 471 249 231 471 249 232 minecraft:red_concrete
fill 471 249 266 471 253 266 minecraft:white_concrete
fill 471 249 267 471 249 268 minecraft:red_concrete
fill 474 249 232 475 252 232 minecraft:red_concrete
fill 474 249 267 475 249 267 minecraft:white_concrete
fill 474 249 268 475 252 268 minecraft:red_concrete
fill 507 249 230 507 253 230 minecraft:white_concrete
fill 507 249 231 507 249 232 minecraft:red_concrete
fill 507 249 266 507 253 266 minecraft:white_concrete
fill 510 249 231 511 249 231 minecraft:white_concrete
fill 510 249 232 511 252 232 minecraft:red_concrete
fill 510 249 267 511 249 267 minecraft:white_concrete
fill 510 249 268 511 252 268 minecraft:red_concrete
fill 471 250 231 471 254 232 minecraft:white_concrete
fill 471 250 267 471 254 268 minecraft:white_concrete
fill 472 250 231 472 254 231 minecraft:white_concrete
setblock 472 250 232 minecraft:red_concrete
fill 472 250 267 472 254 267 minecraft:white_concrete
setblock 472 250 268 minecraft:red_concrete
fill 473 250 229 474 250 230 minecraft:white_concrete
fill 473 250 231 475 254 231 minecraft:red_concrete
setblock 473 250 238 minecraft:light[level=12]
setblock 473 250 245 minecraft:light[level=12]
setblock 473 250 252 minecraft:light[level=12]
setblock 473 250 259 minecraft:light[level=12]
fill 473 250 265 473 251 266 minecraft:white_concrete
fill 473 250 267 475 254 267 minecraft:red_concrete
setblock 475 250 230 minecraft:white_concrete
setblock 480 250 231 minecraft:light[level=12]
setblock 480 250 238 minecraft:light[level=12]
setblock 480 250 245 minecraft:light[level=12]
setblock 480 250 252 minecraft:light[level=12]
setblock 480 250 259 minecraft:light[level=12]
setblock 480 250 266 minecraft:light[level=12]
setblock 487 250 231 minecraft:light[level=12]
setblock 487 250 238 minecraft:light[level=12]
setblock 487 250 245 minecraft:light[level=12]
setblock 487 250 252 minecraft:light[level=12]
setblock 487 250 266 minecraft:light[level=12]
setblock 494 250 231 minecraft:light[level=12]
setblock 494 250 238 minecraft:light[level=12]
setblock 494 250 245 minecraft:light[level=12]
setblock 494 250 252 minecraft:light[level=12]
setblock 494 250 259 minecraft:light[level=12]
setblock 494 250 266 minecraft:light[level=12]
setblock 501 250 231 minecraft:light[level=12]
setblock 501 250 238 minecraft:light[level=12]
setblock 501 250 245 minecraft:light[level=12]
setblock 501 250 252 minecraft:light[level=12]
setblock 501 250 259 minecraft:light[level=12]
setblock 501 250 266 minecraft:light[level=12]
fill 507 250 231 507 254 232 minecraft:white_concrete
fill 507 250 267 507 254 268 minecraft:white_concrete
fill 508 250 231 508 254 231 minecraft:white_concrete
setblock 508 250 232 minecraft:red_concrete
setblock 508 250 238 minecraft:light[level=12]
setblock 508 250 245 minecraft:light[level=12]
setblock 508 250 252 minecraft:light[level=12]
setblock 508 250 259 minecraft:light[level=12]
fill 508 250 267 508 254 267 minecraft:white_concrete
setblock 508 250 268 minecraft:red_concrete
fill 509 250 229 509 251 230 minecraft:white_concrete
fill 509 250 231 511 254 231 minecraft:red_concrete
fill 509 250 265 509 251 266 minecraft:white_concrete
fill 509 250 267 511 254 267 minecraft:red_concrete
fill 471 251 240 477 251 240 minecraft:brown_terracotta
fill 472 251 232 472 255 233 minecraft:white_concrete
fill 472 251 268 472 255 269 minecraft:white_concrete
fill 473 251 229 473 251 230 minecraft:white_concrete
setblock 473 251 233 minecraft:red_concrete
fill 473 251 238 477 252 239 minecraft:brown_terracotta
fill 473 251 241 477 252 242 minecraft:brown_terracotta
setblock 473 251 269 minecraft:red_concrete
setblock 474 251 229 minecraft:white_concrete
fill 474 251 230 475 254 230 minecraft:red_concrete
setblock 474 251 265 minecraft:white_concrete
fill 474 251 266 475 254 266 minecraft:red_concrete
fill 508 251 232 508 255 233 minecraft:white_concrete
fill 508 251 268 508 255 269 minecraft:white_concrete
setblock 509 251 233 minecraft:red_concrete
setblock 509 251 269 minecraft:red_concrete
setblock 510 251 229 minecraft:white_concrete
fill 510 251 230 511 254 230 minecraft:red_concrete
setblock 510 251 265 minecraft:white_concrete
fill 510 251 266 511 254 266 minecraft:red_concrete
fill 473 252 229 473 256 230 minecraft:red_concrete
fill 473 252 232 473 256 233 minecraft:white_concrete
fill 473 252 240 477 252 240 minecraft:brown_terracotta
fill 473 252 265 473 256 266 minecraft:red_concrete
fill 473 252 268 473 256 269 minecraft:white_concrete
fill 474 252 229 474 255 229 minecraft:red_concrete
fill 474 252 265 474 255 265 minecraft:red_concrete
fill 509 252 229 509 256 230 minecraft:red_concrete
fill 509 252 232 509 256 233 minecraft:white_concrete
fill 509 252 265 509 256 266 minecraft:red_concrete
fill 509 252 268 509 256 269 minecraft:white_concrete
fill 510 252 229 510 255 229 minecraft:red_concrete
fill 510 252 265 510 255 265 minecraft:red_concrete
fill 472 253 229 472 257 229 minecraft:red_concrete
setblock 472 253 230 minecraft:white_concrete
fill 472 253 265 472 257 265 minecraft:red_concrete
setblock 472 253 266 minecraft:white_concrete
setblock 473 253 239 minecraft:light[level=15]
setblock 473 253 247 minecraft:light[level=15]
setblock 473 253 255 minecraft:light[level=15]
setblock 473 253 263 minecraft:light[level=15]
fill 474 253 232 474 257 233 minecraft:white_concrete
fill 474 253 240 476 259 240 minecraft:white_concrete
fill 474 253 268 474 257 269 minecraft:white_concrete
setblock 475 253 232 minecraft:red_concrete
fill 475 253 239 475 259 239 minecraft:white_concrete
fill 475 253 241 475 259 241 minecraft:white_concrete
setblock 475 253 268 minecraft:red_concrete
setblock 481 253 231 minecraft:light[level=15]
schedule function dropper:buildpart/58_3 1t
