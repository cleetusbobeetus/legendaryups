setblock 276 183 478 minecraft:bone_block
fill 276 183 479 276 186 479 minecraft:brown_terracotta
setblock 276 183 483 minecraft:bone_block
fill 276 183 484 276 186 484 minecraft:brown_terracotta
setblock 276 183 488 minecraft:bone_block
fill 276 183 489 276 185 489 minecraft:brown_terracotta
setblock 276 183 493 minecraft:bone_block
fill 276 183 494 276 186 494 minecraft:brown_terracotta
setblock 276 183 498 minecraft:bone_block
fill 276 183 499 276 186 499 minecraft:brown_terracotta
fill 276 183 501 276 184 501 minecraft:brown_terracotta
fill 236 184 464 238 184 464 minecraft:brown_terracotta
setblock 236 184 466 minecraft:brown_terracotta
setblock 236 184 467 minecraft:bone_block
fill 236 184 468 236 187 468 minecraft:brown_terracotta
setblock 236 184 472 minecraft:bone_block
fill 236 184 473 236 187 473 minecraft:brown_terracotta
setblock 236 184 477 minecraft:bone_block
fill 236 184 478 236 187 478 minecraft:brown_terracotta
setblock 236 184 481 minecraft:brown_terracotta
setblock 236 184 482 minecraft:bone_block
fill 236 184 483 236 186 484 minecraft:brown_terracotta
setblock 236 184 492 minecraft:bone_block
fill 236 184 493 236 185 493 minecraft:brown_terracotta
setblock 236 184 497 minecraft:bone_block
fill 236 184 498 236 187 498 minecraft:brown_terracotta
setblock 236 184 502 minecraft:bone_block
fill 236 184 503 236 186 504 minecraft:brown_terracotta
setblock 237 184 465 minecraft:brown_terracotta
setblock 237 184 466 minecraft:bone_block
fill 237 184 467 237 187 467 minecraft:brown_terracotta
setblock 237 184 471 minecraft:bone_block
fill 237 184 472 237 187 472 minecraft:brown_terracotta
setblock 237 184 476 minecraft:bone_block
fill 237 184 477 237 187 477 minecraft:brown_terracotta
setblock 237 184 481 minecraft:bone_block
fill 237 184 482 237 187 482 minecraft:brown_terracotta
setblock 237 184 496 minecraft:bone_block
fill 237 184 497 237 187 497 minecraft:brown_terracotta
setblock 237 184 501 minecraft:bone_block
fill 237 184 502 237 187 502 minecraft:brown_terracotta
fill 237 184 504 238 184 504 minecraft:brown_terracotta
setblock 238 184 465 minecraft:bone_block
setblock 238 184 470 minecraft:bone_block
fill 238 184 471 238 186 471 minecraft:brown_terracotta
setblock 238 184 475 minecraft:bone_block
fill 238 184 476 238 187 476 minecraft:brown_terracotta
setblock 238 184 480 minecraft:bone_block
fill 238 184 503 239 184 503 minecraft:brown_terracotta
setblock 239 184 464 minecraft:bone_block
fill 239 184 465 242 184 465 minecraft:brown_terracotta
setblock 239 184 474 minecraft:bone_block
fill 239 184 475 239 185 475 minecraft:brown_terracotta
setblock 239 184 504 minecraft:bone_block
fill 240 184 464 243 184 464 minecraft:brown_terracotta
fill 240 184 466 241 184 466 minecraft:brown_terracotta
setblock 240 184 502 minecraft:brown_terracotta
setblock 240 184 503 minecraft:bone_block
fill 240 184 504 240 187 504 minecraft:brown_terracotta
setblock 241 184 502 minecraft:bone_block
fill 241 184 503 241 187 503 minecraft:brown_terracotta
setblock 242 184 466 minecraft:bone_block
fill 242 184 502 242 187 502 minecraft:brown_terracotta
setblock 243 184 465 minecraft:bone_block
setblock 244 184 464 minecraft:bone_block
fill 244 184 465 244 185 465 minecraft:brown_terracotta
setblock 244 184 504 minecraft:bone_block
fill 245 184 464 245 187 464 minecraft:brown_terracotta
setblock 245 184 502 minecraft:brown_terracotta
setblock 245 184 503 minecraft:bone_block
fill 245 184 504 245 187 504 minecraft:brown_terracotta
fill 246 184 503 246 187 503 minecraft:brown_terracotta
setblock 249 184 504 minecraft:bone_block
fill 250 184 504 253 184 504 minecraft:brown_terracotta
fill 253 184 503 254 184 503 minecraft:brown_terracotta
setblock 254 184 504 minecraft:bone_block
setblock 255 184 503 minecraft:bone_block
fill 255 184 504 258 184 504 minecraft:brown_terracotta
setblock 256 184 502 minecraft:bone_block
fill 256 184 503 256 187 503 minecraft:brown_terracotta
fill 257 184 502 260 184 502 minecraft:brown_terracotta
setblock 258 184 464 minecraft:brown_terracotta
fill 258 184 501 258 187 501 minecraft:brown_terracotta
setblock 259 184 464 minecraft:bone_block
setblock 259 184 504 minecraft:bone_block
fill 260 184 464 260 185 464 minecraft:brown_terracotta
setblock 260 184 503 minecraft:bone_block
fill 260 184 504 260 187 504 minecraft:brown_terracotta
setblock 261 184 501 minecraft:brown_terracotta
setblock 261 184 502 minecraft:bone_block
fill 261 184 503 261 187 503 minecraft:brown_terracotta
setblock 262 184 501 minecraft:bone_block
fill 262 184 502 262 187 502 minecraft:brown_terracotta
setblock 264 184 504 minecraft:bone_block
setblock 265 184 503 minecraft:bone_block
fill 265 184 504 265 186 504 minecraft:brown_terracotta
fill 267 184 484 267 185 486 minecraft:bone_block
fill 268 184 485 268 185 486 minecraft:bone_block
fill 274 184 475 274 185 475 minecraft:brown_terracotta
setblock 274 184 478 minecraft:brown_terracotta
fill 275 184 471 275 184 472 minecraft:brown_terracotta
setblock 275 184 473 minecraft:bone_block
fill 275 184 474 275 187 474 minecraft:brown_terracotta
setblock 275 184 477 minecraft:brown_terracotta
setblock 275 184 478 minecraft:bone_block
fill 275 184 479 275 187 479 minecraft:brown_terracotta
setblock 275 184 482 minecraft:brown_terracotta
fill 276 184 468 276 184 471 minecraft:brown_terracotta
setblock 276 184 472 minecraft:bone_block
fill 276 184 473 276 187 473 minecraft:brown_terracotta
setblock 276 184 477 minecraft:bone_block
fill 276 184 478 276 187 478 minecraft:brown_terracotta
setblock 276 184 482 minecraft:bone_block
fill 276 184 483 276 187 483 minecraft:brown_terracotta
setblock 276 184 487 minecraft:bone_block
fill 276 184 488 276 185 488 minecraft:brown_terracotta
setblock 276 184 492 minecraft:bone_block
fill 276 184 493 276 186 493 minecraft:brown_terracotta
setblock 276 184 497 minecraft:bone_block
fill 276 184 498 276 187 498 minecraft:brown_terracotta
fill 236 185 464 237 185 464 minecraft:brown_terracotta
setblock 236 185 466 minecraft:bone_block
fill 236 185 467 236 188 467 minecraft:brown_terracotta
setblock 236 185 471 minecraft:bone_block
fill 236 185 472 236 188 472 minecraft:brown_terracotta
setblock 236 185 476 minecraft:bone_block
fill 236 185 477 236 188 477 minecraft:brown_terracotta
setblock 236 185 481 minecraft:bone_block
fill 236 185 482 236 188 482 minecraft:brown_terracotta
setblock 236 185 495 minecraft:brown_terracotta
setblock 236 185 496 minecraft:bone_block
fill 236 185 497 236 188 497 minecraft:brown_terracotta
setblock 236 185 500 minecraft:brown_terracotta
setblock 236 185 501 minecraft:bone_block
fill 236 185 502 236 188 502 minecraft:brown_terracotta
setblock 237 185 465 minecraft:bone_block
fill 237 185 466 237 188 466 minecraft:brown_terracotta
setblock 237 185 469 minecraft:brown_terracotta
setblock 237 185 470 minecraft:bone_block
fill 237 185 471 237 188 471 minecraft:brown_terracotta
setblock 237 185 475 minecraft:bone_block
fill 237 185 476 237 188 476 minecraft:brown_terracotta
setblock 237 185 479 minecraft:brown_terracotta
setblock 237 185 480 minecraft:bone_block
fill 237 185 481 237 188 481 minecraft:brown_terracotta
fill 237 185 496 237 186 496 minecraft:brown_terracotta
setblock 237 185 500 minecraft:bone_block
fill 237 185 501 237 188 501 minecraft:brown_terracotta
fill 237 185 503 237 185 504 minecraft:brown_terracotta
setblock 238 185 464 minecraft:bone_block
fill 238 185 465 241 185 465 minecraft:brown_terracotta
setblock 238 185 469 minecraft:bone_block
setblock 238 185 470 minecraft:brown_terracotta
setblock 238 185 474 minecraft:bone_block
fill 238 185 475 238 188 475 minecraft:brown_terracotta
setblock 238 185 479 minecraft:bone_block
fill 238 185 480 238 187 480 minecraft:brown_terracotta
setblock 238 185 503 minecraft:brown_terracotta
setblock 238 185 504 minecraft:bone_block
fill 239 185 464 242 185 464 minecraft:brown_terracotta
setblock 239 185 473 minecraft:bone_block
setblock 239 185 474 minecraft:brown_terracotta
setblock 239 185 502 minecraft:brown_terracotta
setblock 239 185 503 minecraft:bone_block
fill 239 185 504 239 188 504 minecraft:brown_terracotta
setblock 240 185 502 minecraft:bone_block
fill 240 185 503 240 188 503 minecraft:brown_terracotta
fill 241 185 502 241 188 502 minecraft:brown_terracotta
setblock 242 185 465 minecraft:bone_block
setblock 243 185 464 minecraft:bone_block
fill 243 185 465 243 186 465 minecraft:brown_terracotta
setblock 243 185 504 minecraft:bone_block
fill 244 185 464 244 188 464 minecraft:brown_terracotta
setblock 244 185 503 minecraft:bone_block
fill 244 185 504 244 188 504 minecraft:brown_terracotta
fill 245 185 503 245 188 503 minecraft:brown_terracotta
setblock 248 185 504 minecraft:bone_block
fill 249 185 504 252 185 504 minecraft:brown_terracotta
setblock 253 185 503 minecraft:brown_terracotta
setblock 253 185 504 minecraft:bone_block
setblock 254 185 503 minecraft:bone_block
fill 254 185 504 257 185 504 minecraft:brown_terracotta
setblock 255 185 502 minecraft:bone_block
fill 255 185 503 255 188 503 minecraft:brown_terracotta
fill 256 185 502 259 185 502 minecraft:brown_terracotta
setblock 258 185 504 minecraft:bone_block
setblock 259 185 464 minecraft:brown_terracotta
setblock 259 185 503 minecraft:bone_block
fill 259 185 504 259 188 504 minecraft:brown_terracotta
setblock 260 185 502 minecraft:bone_block
fill 260 185 503 260 188 503 minecraft:brown_terracotta
setblock 261 185 501 minecraft:bone_block
fill 261 185 502 261 188 502 minecraft:brown_terracotta
setblock 263 185 504 minecraft:bone_block
setblock 264 185 503 minecraft:bone_block
fill 264 185 504 264 188 504 minecraft:brown_terracotta
setblock 274 185 478 minecraft:bone_block
fill 274 185 479 274 188 479 minecraft:brown_terracotta
setblock 275 185 471 minecraft:brown_terracotta
setblock 275 185 472 minecraft:bone_block
fill 275 185 473 275 188 473 minecraft:brown_terracotta
setblock 275 185 477 minecraft:bone_block
fill 275 185 478 275 188 478 minecraft:brown_terracotta
setblock 275 185 481 minecraft:brown_terracotta
setblock 275 185 482 minecraft:bone_block
fill 275 185 483 275 188 483 minecraft:brown_terracotta
fill 276 185 468 276 185 470 minecraft:brown_terracotta
setblock 276 185 471 minecraft:bone_block
fill 276 185 472 276 188 472 minecraft:brown_terracotta
setblock 276 185 476 minecraft:bone_block
fill 276 185 477 276 188 477 minecraft:brown_terracotta
setblock 276 185 481 minecraft:bone_block
fill 276 185 482 276 188 482 minecraft:brown_terracotta
setblock 276 185 486 minecraft:bone_block
fill 276 185 487 276 188 487 minecraft:brown_terracotta
setblock 276 185 491 minecraft:bone_block
fill 276 185 492 276 186 492 minecraft:brown_terracotta
setblock 276 185 496 minecraft:bone_block
fill 276 185 497 276 188 497 minecraft:brown_terracotta
setblock 276 185 501 minecraft:bone_block
fill 276 185 502 276 188 502 minecraft:brown_terracotta
setblock 236 186 464 minecraft:brown_terracotta
setblock 236 186 465 minecraft:bone_block
fill 236 186 466 236 189 466 minecraft:brown_terracotta
setblock 236 186 470 minecraft:bone_block
fill 236 186 471 236 189 471 minecraft:brown_terracotta
setblock 236 186 475 minecraft:bone_block
fill 236 186 476 236 189 476 minecraft:brown_terracotta
setblock 236 186 480 minecraft:bone_block
fill 236 186 481 236 189 481 minecraft:brown_terracotta
setblock 236 186 495 minecraft:bone_block
fill 236 186 496 236 189 496 minecraft:brown_terracotta
setblock 236 186 499 minecraft:brown_terracotta
setblock 236 186 500 minecraft:bone_block
fill 236 186 501 236 189 501 minecraft:brown_terracotta
setblock 237 186 464 minecraft:bone_block
fill 237 186 465 240 186 465 minecraft:brown_terracotta
setblock 237 186 469 minecraft:bone_block
fill 237 186 470 237 189 470 minecraft:brown_terracotta
setblock 237 186 474 minecraft:bone_block
fill 237 186 475 237 189 475 minecraft:brown_terracotta
setblock 237 186 479 minecraft:bone_block
fill 237 186 480 237 189 480 minecraft:brown_terracotta
setblock 237 186 499 minecraft:bone_block
fill 237 186 500 237 189 500 minecraft:brown_terracotta
setblock 237 186 503 minecraft:brown_terracotta
setblock 237 186 504 minecraft:bone_block
fill 238 186 464 241 186 464 minecraft:brown_terracotta
setblock 238 186 473 minecraft:bone_block
fill 238 186 474 238 188 474 minecraft:brown_terracotta
setblock 238 186 478 minecraft:bone_block
fill 238 186 479 238 189 479 minecraft:brown_terracotta
setblock 238 186 503 minecraft:bone_block
fill 238 186 504 238 189 504 minecraft:brown_terracotta
setblock 239 186 502 minecraft:bone_block
fill 239 186 503 239 189 503 minecraft:brown_terracotta
fill 240 186 502 240 189 502 minecraft:brown_terracotta
setblock 241 186 465 minecraft:bone_block
setblock 242 186 464 minecraft:bone_block
fill 242 186 465 242 187 465 minecraft:brown_terracotta
setblock 242 186 504 minecraft:bone_block
fill 243 186 464 243 189 464 minecraft:brown_terracotta
setblock 243 186 503 minecraft:bone_block
fill 243 186 504 243 189 504 minecraft:brown_terracotta
setblock 244 186 502 minecraft:bone_block
fill 244 186 503 244 189 503 minecraft:brown_terracotta
setblock 247 186 504 minecraft:bone_block
setblock 248 186 503 minecraft:bone_block
fill 248 186 504 251 186 504 minecraft:brown_terracotta
setblock 252 186 503 minecraft:brown_terracotta
setblock 252 186 504 minecraft:bone_block
setblock 253 186 503 minecraft:bone_block
fill 253 186 504 256 186 504 minecraft:brown_terracotta
fill 254 186 503 254 189 503 minecraft:brown_terracotta
fill 255 186 502 258 186 502 minecraft:brown_terracotta
setblock 257 186 504 minecraft:bone_block
setblock 258 186 503 minecraft:bone_block
fill 258 186 504 258 189 504 minecraft:brown_terracotta
setblock 259 186 501 minecraft:brown_terracotta
setblock 259 186 502 minecraft:bone_block
fill 259 186 503 259 189 503 minecraft:brown_terracotta
setblock 260 186 501 minecraft:bone_block
fill 260 186 502 260 189 502 minecraft:brown_terracotta
fill 261 186 465 261 188 465 minecraft:soul_soil
fill 262 186 464 262 188 464 minecraft:soul_soil
fill 262 186 466 262 188 466 minecraft:soul_soil
setblock 262 186 504 minecraft:bone_block
fill 263 186 465 263 188 465 minecraft:soul_soil
setblock 263 186 503 minecraft:bone_block
fill 263 186 504 263 189 504 minecraft:brown_terracotta
setblock 264 186 503 minecraft:brown_terracotta
setblock 274 186 476 minecraft:brown_terracotta
setblock 274 186 477 minecraft:bone_block
fill 274 186 478 274 189 478 minecraft:brown_terracotta
fill 275 186 472 275 187 472 minecraft:brown_terracotta
setblock 275 186 476 minecraft:bone_block
fill 275 186 477 275 189 477 minecraft:brown_terracotta
setblock 275 186 481 minecraft:bone_block
fill 275 186 482 275 189 482 minecraft:brown_terracotta
fill 276 186 468 276 186 469 minecraft:brown_terracotta
setblock 276 186 470 minecraft:bone_block
fill 276 186 471 276 189 471 minecraft:brown_terracotta
setblock 276 186 475 minecraft:bone_block
fill 276 186 476 276 189 476 minecraft:brown_terracotta
setblock 276 186 480 minecraft:bone_block
fill 276 186 481 276 189 481 minecraft:brown_terracotta
setblock 276 186 485 minecraft:bone_block
fill 276 186 486 276 189 486 minecraft:brown_terracotta
setblock 276 186 495 minecraft:bone_block
fill 276 186 496 276 188 496 minecraft:brown_terracotta
setblock 276 186 500 minecraft:bone_block
fill 276 186 501 276 189 501 minecraft:brown_terracotta
fill 276 186 503 276 187 503 minecraft:brown_terracotta
setblock 236 187 464 minecraft:bone_block
fill 236 187 465 239 187 465 minecraft:brown_terracotta
setblock 236 187 469 minecraft:bone_block
fill 236 187 470 236 190 470 minecraft:brown_terracotta
setblock 236 187 474 minecraft:bone_block
fill 236 187 475 236 190 475 minecraft:brown_terracotta
setblock 236 187 479 minecraft:bone_block
fill 236 187 480 236 190 480 minecraft:brown_terracotta
setblock 236 187 483 minecraft:brown_terracotta
setblock 236 187 484 minecraft:bone_block
setblock 236 187 495 minecraft:brown_terracotta
setblock 236 187 499 minecraft:bone_block
fill 236 187 500 236 190 500 minecraft:brown_terracotta
setblock 236 187 503 minecraft:brown_terracotta
setblock 236 187 504 minecraft:bone_block
fill 237 187 464 240 187 464 minecraft:brown_terracotta
setblock 237 187 468 minecraft:bone_block
fill 237 187 469 237 190 469 minecraft:brown_terracotta
setblock 237 187 473 minecraft:bone_block
fill 237 187 474 237 190 474 minecraft:brown_terracotta
setblock 237 187 478 minecraft:bone_block
fill 237 187 479 237 190 479 minecraft:brown_terracotta
setblock 237 187 498 minecraft:bone_block
fill 237 187 499 237 190 499 minecraft:brown_terracotta
setblock 237 187 503 minecraft:bone_block
fill 237 187 504 237 190 504 minecraft:brown_terracotta
setblock 238 187 466 minecraft:light[level=12]
setblock 238 187 472 minecraft:bone_block
setblock 238 187 473 minecraft:brown_terracotta
setblock 238 187 477 minecraft:bone_block
fill 238 187 478 238 189 478 minecraft:brown_terracotta
setblock 238 187 482 minecraft:light[level=12]
setblock 238 187 490 minecraft:light[level=12]
setblock 238 187 498 minecraft:light[level=12]
setblock 238 187 501 minecraft:brown_terracotta
fill 238 187 503 238 190 503 minecraft:brown_terracotta
fill 239 187 502 239 190 502 minecraft:brown_terracotta
setblock 240 187 465 minecraft:bone_block
setblock 241 187 464 minecraft:bone_block
fill 241 187 465 241 190 465 minecraft:brown_terracotta
setblock 241 187 504 minecraft:bone_block
fill 242 187 464 242 190 464 minecraft:brown_terracotta
setblock 242 187 503 minecraft:bone_block
fill 242 187 504 242 190 504 minecraft:brown_terracotta
setblock 243 187 502 minecraft:bone_block
fill 243 187 503 243 190 503 minecraft:brown_terracotta
setblock 246 187 466 minecraft:light[level=12]
setblock 246 187 474 minecraft:light[level=12]
setblock 246 187 482 minecraft:light[level=12]
setblock 246 187 490 minecraft:light[level=12]
setblock 246 187 498 minecraft:light[level=12]
setblock 246 187 504 minecraft:bone_block
setblock 247 187 503 minecraft:bone_block
fill 247 187 504 250 187 504 minecraft:brown_terracotta
setblock 251 187 504 minecraft:bone_block
setblock 252 187 503 minecraft:bone_block
fill 252 187 504 255 187 504 minecraft:brown_terracotta
fill 253 187 503 253 190 503 minecraft:brown_terracotta
setblock 254 187 466 minecraft:light[level=12]
setblock 254 187 474 minecraft:light[level=12]
setblock 254 187 482 minecraft:light[level=12]
setblock 254 187 490 minecraft:light[level=12]
setblock 254 187 498 minecraft:light[level=12]
fill 255 187 502 257 187 502 minecraft:brown_terracotta
setblock 256 187 504 minecraft:bone_block
setblock 257 187 503 minecraft:bone_block
fill 257 187 504 257 190 504 minecraft:brown_terracotta
setblock 258 187 502 minecraft:bone_block
fill 258 187 503 258 190 503 minecraft:brown_terracotta
setblock 259 187 501 minecraft:bone_block
fill 259 187 502 259 190 502 minecraft:brown_terracotta
setblock 261 187 504 minecraft:bone_block
setblock 262 187 474 minecraft:light[level=12]
setblock 262 187 482 minecraft:light[level=12]
setblock 262 187 490 minecraft:light[level=12]
setblock 262 187 498 minecraft:light[level=12]
setblock 262 187 503 minecraft:bone_block
fill 262 187 504 262 190 504 minecraft:brown_terracotta
fill 263 187 503 263 188 503 minecraft:brown_terracotta
setblock 270 187 466 minecraft:light[level=12]
setblock 270 187 474 minecraft:light[level=12]
setblock 270 187 482 minecraft:light[level=12]
setblock 270 187 490 minecraft:light[level=12]
setblock 270 187 498 minecraft:light[level=12]
setblock 274 187 476 minecraft:bone_block
fill 274 187 477 274 190 477 minecraft:brown_terracotta
setblock 274 187 480 minecraft:brown_terracotta
setblock 275 187 475 minecraft:bone_block
fill 275 187 476 275 190 476 minecraft:brown_terracotta
setblock 275 187 480 minecraft:bone_block
fill 275 187 481 275 190 481 minecraft:brown_terracotta
setblock 276 187 468 minecraft:brown_terracotta
setblock 276 187 469 minecraft:bone_block
fill 276 187 470 276 190 470 minecraft:brown_terracotta
setblock 276 187 474 minecraft:bone_block
fill 276 187 475 276 190 475 minecraft:brown_terracotta
setblock 276 187 479 minecraft:bone_block
fill 276 187 480 276 190 480 minecraft:brown_terracotta
setblock 276 187 484 minecraft:bone_block
fill 276 187 485 276 190 485 minecraft:brown_terracotta
setblock 276 187 494 minecraft:bone_block
setblock 276 187 495 minecraft:brown_terracotta
setblock 276 187 499 minecraft:bone_block
fill 276 187 500 276 190 500 minecraft:brown_terracotta
fill 236 188 464 238 188 465 minecraft:brown_terracotta
setblock 236 188 468 minecraft:bone_block
fill 236 188 469 236 191 469 minecraft:brown_terracotta
setblock 236 188 473 minecraft:bone_block
fill 236 188 474 236 191 474 minecraft:brown_terracotta
setblock 236 188 478 minecraft:bone_block
fill 236 188 479 236 191 479 minecraft:brown_terracotta
setblock 236 188 483 minecraft:bone_block
fill 236 188 484 236 191 484 minecraft:brown_terracotta
setblock 236 188 498 minecraft:bone_block
fill 236 188 499 236 191 499 minecraft:brown_terracotta
setblock 236 188 503 minecraft:bone_block
fill 236 188 504 236 191 504 minecraft:brown_terracotta
setblock 237 188 467 minecraft:bone_block
fill 237 188 468 237 191 468 minecraft:brown_terracotta
setblock 237 188 472 minecraft:bone_block
fill 237 188 473 237 191 473 minecraft:brown_terracotta
setblock 237 188 477 minecraft:bone_block
fill 237 188 478 237 191 478 minecraft:brown_terracotta
setblock 237 188 482 minecraft:bone_block
fill 237 188 498 237 191 498 minecraft:brown_terracotta
setblock 237 188 502 minecraft:bone_block
fill 237 188 503 237 191 503 minecraft:brown_terracotta
setblock 238 188 476 minecraft:bone_block
fill 238 188 477 238 189 477 minecraft:brown_terracotta
setblock 238 188 501 minecraft:bone_block
fill 238 188 502 238 191 502 minecraft:brown_terracotta
setblock 239 188 464 minecraft:brown_terracotta
setblock 239 188 465 minecraft:bone_block
setblock 240 188 464 minecraft:bone_block
fill 240 188 465 240 191 465 minecraft:brown_terracotta
setblock 240 188 504 minecraft:bone_block
fill 241 188 464 241 191 464 minecraft:brown_terracotta
setblock 241 188 503 minecraft:bone_block
fill 241 188 504 241 191 504 minecraft:brown_terracotta
setblock 242 188 502 minecraft:bone_block
fill 242 188 503 242 191 503 minecraft:brown_terracotta
setblock 245 188 464 minecraft:bone_block
setblock 245 188 504 minecraft:bone_block
setblock 246 188 503 minecraft:bone_block
fill 246 188 504 249 188 504 minecraft:brown_terracotta
fill 247 188 503 247 191 503 minecraft:brown_terracotta
setblock 250 188 504 minecraft:bone_block
setblock 251 188 503 minecraft:bone_block
fill 251 188 504 254 188 504 minecraft:brown_terracotta
fill 252 188 503 252 191 503 minecraft:brown_terracotta
fill 254 188 502 256 188 502 minecraft:brown_terracotta
setblock 255 188 504 minecraft:bone_block
setblock 256 188 503 minecraft:bone_block
fill 256 188 504 256 191 504 minecraft:brown_terracotta
setblock 257 188 502 minecraft:bone_block
fill 257 188 503 257 191 503 minecraft:brown_terracotta
fill 258 188 502 258 191 502 minecraft:brown_terracotta
setblock 260 188 504 minecraft:bone_block
setblock 261 188 503 minecraft:bone_block
fill 261 188 504 261 191 504 minecraft:brown_terracotta
fill 262 188 503 262 191 503 minecraft:brown_terracotta
setblock 274 188 480 minecraft:bone_block
setblock 275 188 474 minecraft:bone_block
fill 275 188 475 275 191 475 minecraft:brown_terracotta
setblock 275 188 479 minecraft:bone_block
fill 275 188 480 275 191 480 minecraft:brown_terracotta
setblock 275 188 484 minecraft:bone_block
fill 276 188 464 276 188 467 minecraft:brown_terracotta
setblock 276 188 468 minecraft:bone_block
fill 276 188 469 276 191 469 minecraft:brown_terracotta
setblock 276 188 473 minecraft:bone_block
fill 276 188 474 276 191 474 minecraft:brown_terracotta
setblock 276 188 478 minecraft:bone_block
fill 276 188 479 276 191 479 minecraft:brown_terracotta
setblock 276 188 483 minecraft:bone_block
fill 276 188 484 276 191 484 minecraft:brown_terracotta
setblock 276 188 498 minecraft:bone_block
fill 276 188 499 276 191 499 minecraft:brown_terracotta
setblock 276 188 503 minecraft:bone_block
fill 276 188 504 276 191 504 minecraft:brown_terracotta
fill 236 189 464 237 189 465 minecraft:brown_terracotta
setblock 236 189 467 minecraft:bone_block
fill 236 189 468 236 192 468 minecraft:brown_terracotta
setblock 236 189 472 minecraft:bone_block
fill 236 189 473 236 192 473 minecraft:brown_terracotta
setblock 236 189 477 minecraft:bone_block
fill 236 189 478 236 192 478 minecraft:brown_terracotta
setblock 236 189 482 minecraft:bone_block
fill 236 189 483 236 192 483 minecraft:brown_terracotta
fill 236 189 485 236 190 485 minecraft:brown_terracotta
setblock 236 189 497 minecraft:bone_block
fill 236 189 498 236 192 498 minecraft:brown_terracotta
setblock 236 189 502 minecraft:bone_block
fill 236 189 503 236 192 503 minecraft:brown_terracotta
setblock 237 189 466 minecraft:bone_block
fill 237 189 467 237 192 467 minecraft:brown_terracotta
setblock 237 189 471 minecraft:bone_block
fill 237 189 472 237 192 472 minecraft:brown_terracotta
setblock 237 189 476 minecraft:bone_block
fill 237 189 477 237 192 477 minecraft:brown_terracotta
setblock 237 189 481 minecraft:bone_block
fill 237 189 482 237 192 482 minecraft:brown_terracotta
setblock 237 189 501 minecraft:bone_block
fill 237 189 502 237 192 502 minecraft:brown_terracotta
setblock 238 189 464 minecraft:brown_terracotta
setblock 238 189 465 minecraft:bone_block
setblock 238 189 476 minecraft:brown_terracotta
setblock 238 189 500 minecraft:bone_block
fill 238 189 501 238 192 501 minecraft:brown_terracotta
setblock 239 189 464 minecraft:bone_block
fill 239 189 465 239 192 465 minecraft:brown_terracotta
setblock 239 189 504 minecraft:bone_block
fill 240 189 464 240 192 464 minecraft:brown_terracotta
setblock 240 189 503 minecraft:bone_block
fill 240 189 504 240 192 504 minecraft:brown_terracotta
setblock 241 189 502 minecraft:bone_block
fill 241 189 503 241 192 503 minecraft:brown_terracotta
fill 242 189 502 242 192 502 minecraft:brown_terracotta
setblock 244 189 464 minecraft:bone_block
setblock 244 189 504 minecraft:bone_block
setblock 245 189 503 minecraft:bone_block
fill 245 189 504 248 189 504 minecraft:brown_terracotta
fill 246 189 503 246 192 503 minecraft:brown_terracotta
setblock 249 189 504 minecraft:bone_block
setblock 250 189 503 minecraft:bone_block
fill 250 189 504 253 189 504 minecraft:brown_terracotta
fill 251 189 503 251 192 503 minecraft:brown_terracotta
fill 254 189 502 255 189 502 minecraft:brown_terracotta
setblock 254 189 504 minecraft:bone_block
setblock 255 189 503 minecraft:bone_block
fill 255 189 504 255 192 504 minecraft:brown_terracotta
setblock 256 189 502 minecraft:bone_block
fill 256 189 503 256 192 503 minecraft:brown_terracotta
fill 257 189 502 257 192 502 minecraft:brown_terracotta
setblock 259 189 504 minecraft:bone_block
setblock 260 189 503 minecraft:bone_block
fill 260 189 504 260 192 504 minecraft:brown_terracotta
fill 261 189 503 261 192 503 minecraft:brown_terracotta
setblock 274 189 479 minecraft:bone_block
fill 274 189 480 274 191 481 minecraft:brown_terracotta
fill 275 189 464 276 191 464 minecraft:brown_terracotta
setblock 275 189 473 minecraft:bone_block
fill 275 189 474 275 192 474 minecraft:brown_terracotta
setblock 275 189 478 minecraft:bone_block
fill 275 189 479 275 192 479 minecraft:brown_terracotta
setblock 275 189 483 minecraft:bone_block
fill 275 189 484 275 192 484 minecraft:brown_terracotta
fill 275 189 504 275 192 504 minecraft:brown_terracotta
fill 276 189 465 276 189 466 minecraft:brown_terracotta
setblock 276 189 467 minecraft:bone_block
fill 276 189 468 276 192 468 minecraft:brown_terracotta
setblock 276 189 472 minecraft:bone_block
fill 276 189 473 276 192 473 minecraft:brown_terracotta
setblock 276 189 477 minecraft:bone_block
fill 276 189 478 276 192 478 minecraft:brown_terracotta
setblock 276 189 482 minecraft:bone_block
fill 276 189 483 276 192 483 minecraft:brown_terracotta
setblock 276 189 487 minecraft:bone_block
setblock 276 189 497 minecraft:bone_block
fill 276 189 498 276 192 498 minecraft:brown_terracotta
setblock 276 189 502 minecraft:bone_block
fill 276 189 503 276 192 503 minecraft:brown_terracotta
fill 236 190 464 236 190 465 minecraft:brown_terracotta
setblock 236 190 466 minecraft:bone_block
fill 236 190 467 236 193 467 minecraft:brown_terracotta
setblock 236 190 471 minecraft:bone_block
fill 236 190 472 236 193 472 minecraft:brown_terracotta
setblock 236 190 476 minecraft:bone_block
fill 236 190 477 236 193 477 minecraft:brown_terracotta
setblock 236 190 481 minecraft:bone_block
fill 236 190 482 236 193 482 minecraft:brown_terracotta
setblock 236 190 496 minecraft:bone_block
fill 236 190 497 236 193 497 minecraft:brown_terracotta
setblock 236 190 501 minecraft:bone_block
fill 236 190 502 236 193 502 minecraft:brown_terracotta
setblock 237 190 464 minecraft:brown_terracotta
setblock 237 190 465 minecraft:bone_block
fill 237 190 466 237 193 466 minecraft:brown_terracotta
setblock 237 190 470 minecraft:bone_block
fill 237 190 471 237 193 471 minecraft:brown_terracotta
setblock 237 190 475 minecraft:bone_block
fill 237 190 476 237 193 476 minecraft:brown_terracotta
setblock 237 190 480 minecraft:bone_block
fill 237 190 481 237 193 481 minecraft:brown_terracotta
fill 237 190 483 237 191 483 minecraft:brown_terracotta
setblock 237 190 500 minecraft:bone_block
fill 237 190 501 237 193 501 minecraft:brown_terracotta
setblock 238 190 464 minecraft:bone_block
fill 238 190 465 238 193 465 minecraft:brown_terracotta
fill 238 190 500 238 193 500 minecraft:brown_terracotta
setblock 238 190 504 minecraft:bone_block
fill 239 190 464 239 193 464 minecraft:brown_terracotta
setblock 239 190 503 minecraft:bone_block
fill 239 190 504 239 193 504 minecraft:brown_terracotta
setblock 240 190 502 minecraft:bone_block
fill 240 190 503 240 193 503 minecraft:brown_terracotta
fill 241 190 502 241 193 502 minecraft:brown_terracotta
setblock 243 190 464 minecraft:bone_block
setblock 243 190 504 minecraft:bone_block
fill 244 190 464 244 193 464 minecraft:brown_terracotta
setblock 244 190 503 minecraft:bone_block
fill 244 190 504 247 190 504 minecraft:brown_terracotta
fill 245 190 503 245 193 503 minecraft:brown_terracotta
setblock 248 190 503 minecraft:brown_terracotta
setblock 248 190 504 minecraft:bone_block
setblock 249 190 503 minecraft:bone_block
fill 249 190 504 252 190 504 minecraft:brown_terracotta
fill 250 190 503 250 193 503 minecraft:brown_terracotta
fill 253 190 502 254 190 502 minecraft:brown_terracotta
setblock 253 190 504 minecraft:bone_block
setblock 254 190 503 minecraft:bone_block
fill 254 190 504 254 193 504 minecraft:brown_terracotta
fill 255 190 464 257 190 464 minecraft:brown_terracotta
setblock 255 190 502 minecraft:bone_block
fill 255 190 503 255 193 503 minecraft:brown_terracotta
fill 256 190 502 256 193 502 minecraft:brown_terracotta
setblock 258 190 464 minecraft:bone_block
setblock 258 190 504 minecraft:bone_block
fill 259 190 464 259 193 464 minecraft:brown_terracotta
setblock 259 190 503 minecraft:bone_block
fill 259 190 504 259 193 504 minecraft:brown_terracotta
setblock 260 190 502 minecraft:bone_block
fill 260 190 503 260 193 503 minecraft:brown_terracotta
setblock 263 190 504 minecraft:bone_block
fill 274 190 464 274 193 464 minecraft:brown_terracotta
setblock 274 190 478 minecraft:bone_block
fill 274 190 479 274 193 479 minecraft:brown_terracotta
setblock 274 190 482 minecraft:brown_terracotta
fill 274 190 504 274 193 504 minecraft:brown_terracotta
fill 275 190 473 275 193 473 minecraft:brown_terracotta
setblock 275 190 477 minecraft:bone_block
fill 275 190 478 275 193 478 minecraft:brown_terracotta
setblock 275 190 482 minecraft:bone_block
fill 275 190 483 275 193 483 minecraft:brown_terracotta
fill 275 190 485 275 191 485 minecraft:brown_terracotta
setblock 276 190 465 minecraft:brown_terracotta
setblock 276 190 466 minecraft:bone_block
fill 276 190 467 276 193 467 minecraft:brown_terracotta
setblock 276 190 471 minecraft:bone_block
fill 276 190 472 276 193 472 minecraft:brown_terracotta
setblock 276 190 476 minecraft:bone_block
fill 276 190 477 276 193 477 minecraft:brown_terracotta
setblock 276 190 481 minecraft:bone_block
fill 276 190 482 276 193 482 minecraft:brown_terracotta
setblock 276 190 486 minecraft:bone_block
fill 276 190 487 276 192 488 minecraft:brown_terracotta
fill 276 190 497 276 193 497 minecraft:brown_terracotta
setblock 276 190 501 minecraft:bone_block
fill 276 190 502 276 193 502 minecraft:brown_terracotta
setblock 236 191 464 minecraft:brown_terracotta
setblock 236 191 465 minecraft:bone_block
fill 236 191 466 236 194 466 minecraft:brown_terracotta
setblock 236 191 470 minecraft:bone_block
fill 236 191 471 236 194 471 minecraft:brown_terracotta
setblock 236 191 475 minecraft:bone_block
fill 236 191 476 236 194 476 minecraft:brown_terracotta
setblock 236 191 480 minecraft:bone_block
fill 236 191 481 236 194 481 minecraft:brown_terracotta
setblock 236 191 485 minecraft:bone_block
fill 236 191 486 236 194 486 minecraft:brown_terracotta
fill 236 191 496 236 194 496 minecraft:brown_terracotta
setblock 236 191 500 minecraft:bone_block
fill 236 191 501 236 194 501 minecraft:brown_terracotta
setblock 237 191 464 minecraft:bone_block
fill 237 191 465 237 194 465 minecraft:brown_terracotta
setblock 237 191 469 minecraft:bone_block
fill 237 191 470 237 194 470 minecraft:brown_terracotta
setblock 237 191 474 minecraft:bone_block
fill 237 191 475 237 194 475 minecraft:brown_terracotta
setblock 237 191 479 minecraft:bone_block
fill 237 191 480 237 194 480 minecraft:brown_terracotta
setblock 237 191 484 minecraft:bone_block
setblock 237 191 499 minecraft:bone_block
fill 237 191 500 237 194 500 minecraft:brown_terracotta
setblock 237 191 504 minecraft:bone_block
fill 238 191 464 238 194 464 minecraft:brown_terracotta
setblock 238 191 503 minecraft:bone_block
fill 238 191 504 238 194 504 minecraft:brown_terracotta
setblock 239 191 502 minecraft:bone_block
fill 239 191 503 239 194 503 minecraft:brown_terracotta
fill 240 191 502 240 194 502 minecraft:brown_terracotta
setblock 241 191 465 minecraft:bone_block
setblock 242 191 464 minecraft:bone_block
setblock 242 191 504 minecraft:bone_block
fill 243 191 464 243 194 464 minecraft:brown_terracotta
setblock 243 191 503 minecraft:bone_block
fill 243 191 504 246 191 504 minecraft:brown_terracotta
fill 244 191 503 244 194 503 minecraft:brown_terracotta
fill 245 191 464 245 192 464 minecraft:brown_terracotta
setblock 247 191 504 minecraft:bone_block
setblock 248 191 503 minecraft:bone_block
fill 248 191 504 251 191 504 minecraft:brown_terracotta
fill 249 191 503 249 194 503 minecraft:brown_terracotta
fill 252 191 502 253 191 502 minecraft:brown_terracotta
setblock 252 191 504 minecraft:bone_block
fill 253 191 464 256 191 464 minecraft:brown_terracotta
setblock 253 191 503 minecraft:bone_block
fill 253 191 504 253 194 504 minecraft:brown_terracotta
setblock 254 191 502 minecraft:bone_block
fill 254 191 503 254 194 503 minecraft:brown_terracotta
fill 255 191 502 255 194 502 minecraft:brown_terracotta
setblock 257 191 464 minecraft:bone_block
setblock 257 191 504 minecraft:bone_block
fill 258 191 464 258 194 464 minecraft:brown_terracotta
setblock 258 191 503 minecraft:bone_block
fill 258 191 504 258 194 504 minecraft:brown_terracotta
setblock 259 191 502 minecraft:bone_block
fill 259 191 503 259 194 503 minecraft:brown_terracotta
fill 260 191 464 260 192 464 minecraft:brown_terracotta
setblock 260 191 502 minecraft:brown_terracotta
setblock 262 191 504 minecraft:bone_block
fill 263 191 504 263 194 504 minecraft:brown_terracotta
fill 273 191 464 273 194 464 minecraft:brown_terracotta
fill 273 191 504 273 194 504 minecraft:brown_terracotta
setblock 274 191 476 minecraft:brown_terracotta
setblock 274 191 477 minecraft:bone_block
fill 274 191 478 274 194 478 minecraft:brown_terracotta
setblock 274 191 482 minecraft:bone_block
fill 274 191 483 274 194 483 minecraft:brown_terracotta
setblock 275 191 465 minecraft:brown_terracotta
fill 275 191 472 275 194 472 minecraft:brown_terracotta
setblock 275 191 476 minecraft:bone_block
fill 275 191 477 275 194 477 minecraft:brown_terracotta
setblock 275 191 481 minecraft:bone_block
fill 275 191 482 275 194 482 minecraft:brown_terracotta
setblock 275 191 486 minecraft:bone_block
fill 275 191 502 275 193 503 minecraft:brown_terracotta
setblock 276 191 465 minecraft:bone_block
fill 276 191 466 276 194 466 minecraft:brown_terracotta
setblock 276 191 470 minecraft:bone_block
fill 276 191 471 276 194 471 minecraft:brown_terracotta
setblock 276 191 475 minecraft:bone_block
fill 276 191 476 276 194 476 minecraft:brown_terracotta
setblock 276 191 480 minecraft:bone_block
fill 276 191 481 276 194 481 minecraft:brown_terracotta
setblock 276 191 485 minecraft:bone_block
fill 276 191 486 276 194 486 minecraft:brown_terracotta
setblock 276 191 500 minecraft:bone_block
fill 276 191 501 276 194 501 minecraft:brown_terracotta
setblock 236 192 464 minecraft:bone_block
fill 236 192 465 236 195 465 minecraft:brown_terracotta
setblock 236 192 469 minecraft:bone_block
fill 236 192 470 236 195 470 minecraft:brown_terracotta
setblock 236 192 474 minecraft:bone_block
fill 236 192 475 236 195 475 minecraft:brown_terracotta
setblock 236 192 479 minecraft:bone_block
fill 236 192 480 236 195 480 minecraft:brown_terracotta
setblock 236 192 484 minecraft:bone_block
fill 236 192 485 237 194 485 minecraft:brown_terracotta
fill 236 192 487 236 192 488 minecraft:brown_terracotta
setblock 236 192 499 minecraft:bone_block
fill 236 192 500 236 195 500 minecraft:brown_terracotta
setblock 236 192 504 minecraft:bone_block
fill 237 192 464 237 195 464 minecraft:brown_terracotta
setblock 237 192 468 minecraft:bone_block
fill 237 192 469 237 195 469 minecraft:brown_terracotta
setblock 237 192 473 minecraft:bone_block
fill 237 192 474 237 194 474 minecraft:brown_terracotta
setblock 237 192 478 minecraft:bone_block
fill 237 192 479 237 195 479 minecraft:brown_terracotta
setblock 237 192 483 minecraft:bone_block
fill 237 192 484 237 195 484 minecraft:brown_terracotta
setblock 237 192 498 minecraft:bone_block
fill 237 192 499 237 195 499 minecraft:brown_terracotta
setblock 237 192 503 minecraft:bone_block
fill 237 192 504 237 195 504 minecraft:brown_terracotta
setblock 238 192 466 minecraft:brown_terracotta
setblock 238 192 502 minecraft:bone_block
fill 238 192 503 238 195 503 minecraft:brown_terracotta
fill 239 192 502 239 195 502 minecraft:brown_terracotta
setblock 240 192 465 minecraft:bone_block
setblock 241 192 464 minecraft:bone_block
fill 241 192 465 242 194 465 minecraft:brown_terracotta
setblock 241 192 504 minecraft:bone_block
fill 242 192 464 242 195 464 minecraft:brown_terracotta
setblock 242 192 503 minecraft:bone_block
fill 242 192 504 245 192 504 minecraft:brown_terracotta
fill 243 192 503 243 195 503 minecraft:brown_terracotta
setblock 246 192 464 minecraft:bone_block
setblock 246 192 504 minecraft:bone_block
setblock 247 192 503 minecraft:bone_block
fill 247 192 504 250 192 504 minecraft:brown_terracotta
fill 248 192 503 248 195 503 minecraft:brown_terracotta
setblock 250 192 464 minecraft:brown_terracotta
setblock 251 192 464 minecraft:bone_block
fill 251 192 502 252 192 502 minecraft:brown_terracotta
setblock 251 192 504 minecraft:bone_block
fill 252 192 464 255 192 464 minecraft:brown_terracotta
setblock 252 192 503 minecraft:bone_block
fill 252 192 504 252 195 504 minecraft:brown_terracotta
setblock 253 192 502 minecraft:bone_block
fill 253 192 503 253 195 503 minecraft:brown_terracotta
fill 254 192 502 254 195 502 minecraft:brown_terracotta
setblock 256 192 464 minecraft:bone_block
setblock 256 192 504 minecraft:bone_block
fill 257 192 464 257 195 464 minecraft:brown_terracotta
setblock 257 192 503 minecraft:bone_block
fill 257 192 504 257 195 504 minecraft:brown_terracotta
setblock 258 192 502 minecraft:bone_block
fill 258 192 503 258 195 503 minecraft:brown_terracotta
fill 259 192 502 259 194 502 minecraft:brown_terracotta
setblock 261 192 504 minecraft:bone_block
fill 262 192 504 262 195 504 minecraft:brown_terracotta
setblock 271 192 464 minecraft:bone_block
setblock 271 192 504 minecraft:bone_block
fill 272 192 464 272 195 464 minecraft:brown_terracotta
fill 272 192 504 272 195 504 minecraft:brown_terracotta
setblock 274 192 465 minecraft:brown_terracotta
setblock 274 192 476 minecraft:bone_block
fill 274 192 477 274 195 477 minecraft:brown_terracotta
setblock 274 192 480 minecraft:brown_terracotta
setblock 274 192 481 minecraft:bone_block
fill 274 192 482 274 195 482 minecraft:brown_terracotta
fill 274 192 484 274 193 484 minecraft:brown_terracotta
fill 274 192 503 274 194 503 minecraft:brown_terracotta
setblock 275 192 464 minecraft:brown_terracotta
setblock 275 192 465 minecraft:bone_block
fill 275 192 466 275 192 469 minecraft:brown_terracotta
setblock 275 192 470 minecraft:bone_block
fill 275 192 471 275 195 471 minecraft:brown_terracotta
setblock 275 192 475 minecraft:bone_block
fill 275 192 476 275 195 476 minecraft:brown_terracotta
setblock 275 192 480 minecraft:bone_block
fill 275 192 481 275 195 481 minecraft:brown_terracotta
setblock 275 192 485 minecraft:bone_block
fill 275 192 486 275 194 487 minecraft:brown_terracotta
fill 275 192 501 275 195 501 minecraft:brown_terracotta
setblock 276 192 464 minecraft:bone_block
fill 276 192 465 276 195 465 minecraft:brown_terracotta
setblock 276 192 469 minecraft:bone_block
fill 276 192 470 276 195 470 minecraft:brown_terracotta
setblock 276 192 474 minecraft:bone_block
fill 276 192 475 276 195 475 minecraft:brown_terracotta
setblock 276 192 479 minecraft:bone_block
fill 276 192 480 276 195 480 minecraft:brown_terracotta
setblock 276 192 484 minecraft:bone_block
fill 276 192 485 276 195 485 minecraft:brown_terracotta
setblock 276 192 489 minecraft:bone_block
setblock 276 192 499 minecraft:bone_block
fill 276 192 500 276 195 500 minecraft:brown_terracotta
setblock 276 192 504 minecraft:bone_block
fill 236 193 464 236 196 464 minecraft:brown_terracotta
setblock 236 193 468 minecraft:bone_block
fill 236 193 469 236 196 469 minecraft:brown_terracotta
setblock 236 193 473 minecraft:bone_block
fill 236 193 474 236 196 474 minecraft:brown_terracotta
setblock 236 193 478 minecraft:bone_block
fill 236 193 479 236 196 479 minecraft:brown_terracotta
setblock 236 193 483 minecraft:bone_block
fill 236 193 484 236 196 484 minecraft:brown_terracotta
setblock 236 193 487 minecraft:brown_terracotta
setblock 236 193 488 minecraft:bone_block
fill 236 193 489 236 196 489 minecraft:brown_terracotta
fill 236 193 495 236 195 495 minecraft:brown_terracotta
setblock 236 193 498 minecraft:bone_block
fill 236 193 499 236 196 499 minecraft:brown_terracotta
setblock 236 193 503 minecraft:bone_block
fill 236 193 504 236 196 504 minecraft:brown_terracotta
setblock 237 193 467 minecraft:bone_block
fill 237 193 468 237 196 468 minecraft:brown_terracotta
setblock 237 193 472 minecraft:bone_block
fill 237 193 473 237 194 473 minecraft:brown_terracotta
setblock 237 193 477 minecraft:bone_block
fill 237 193 478 237 195 478 minecraft:brown_terracotta
setblock 237 193 482 minecraft:bone_block
fill 237 193 483 237 196 483 minecraft:brown_terracotta
setblock 237 193 486 minecraft:brown_terracotta
fill 237 193 498 237 196 498 minecraft:brown_terracotta
setblock 237 193 502 minecraft:bone_block
fill 237 193 503 237 196 503 minecraft:brown_terracotta
setblock 238 193 466 minecraft:bone_block
fill 238 193 467 238 196 467 minecraft:brown_terracotta
setblock 238 193 501 minecraft:bone_block
fill 238 193 502 238 196 502 minecraft:brown_terracotta
setblock 239 193 465 minecraft:bone_block
fill 239 193 466 239 196 466 minecraft:brown_terracotta
setblock 240 193 464 minecraft:bone_block
fill 240 193 465 240 196 465 minecraft:brown_terracotta
setblock 240 193 504 minecraft:bone_block
fill 241 193 464 241 196 464 minecraft:brown_terracotta
setblock 241 193 503 minecraft:bone_block
fill 241 193 504 244 193 504 minecraft:brown_terracotta
setblock 242 193 502 minecraft:bone_block
fill 242 193 503 242 196 503 minecraft:brown_terracotta
setblock 245 193 464 minecraft:bone_block
setblock 245 193 504 minecraft:bone_block
fill 246 193 464 249 193 464 minecraft:brown_terracotta
setblock 246 193 503 minecraft:bone_block
fill 246 193 504 249 193 504 minecraft:brown_terracotta
fill 247 193 503 247 196 503 minecraft:brown_terracotta
setblock 250 193 464 minecraft:bone_block
fill 250 193 502 251 193 502 minecraft:brown_terracotta
setblock 250 193 504 minecraft:bone_block
fill 251 193 464 254 193 464 minecraft:brown_terracotta
setblock 251 193 503 minecraft:bone_block
fill 251 193 504 251 196 504 minecraft:brown_terracotta
setblock 252 193 502 minecraft:bone_block
fill 252 193 503 252 196 503 minecraft:brown_terracotta
fill 253 193 502 253 196 502 minecraft:brown_terracotta
setblock 255 193 464 minecraft:bone_block
fill 255 193 501 256 193 501 minecraft:brown_terracotta
setblock 255 193 504 minecraft:bone_block
fill 256 193 464 256 196 464 minecraft:brown_terracotta
setblock 256 193 503 minecraft:bone_block
fill 256 193 504 256 196 504 minecraft:brown_terracotta
setblock 257 193 502 minecraft:bone_block
fill 257 193 503 257 196 503 minecraft:brown_terracotta
fill 258 193 502 258 195 502 minecraft:brown_terracotta
setblock 260 193 464 minecraft:bone_block
setblock 260 193 504 minecraft:bone_block
fill 261 193 464 261 196 464 minecraft:brown_terracotta
setblock 261 193 503 minecraft:bone_block
fill 261 193 504 261 196 504 minecraft:brown_terracotta
setblock 264 193 504 minecraft:brown_terracotta
setblock 270 193 464 minecraft:bone_block
setblock 270 193 504 minecraft:bone_block
fill 271 193 464 271 196 464 minecraft:brown_terracotta
fill 271 193 504 271 196 504 minecraft:brown_terracotta
fill 272 193 465 273 193 465 minecraft:brown_terracotta
setblock 273 193 481 minecraft:bone_block
fill 273 193 503 273 195 503 minecraft:brown_terracotta
setblock 274 193 465 minecraft:bone_block
fill 274 193 476 274 196 476 minecraft:brown_terracotta
setblock 274 193 480 minecraft:bone_block
fill 274 193 481 274 196 481 minecraft:brown_terracotta
setblock 274 193 485 minecraft:bone_block
setblock 275 193 464 minecraft:bone_block
fill 275 193 465 275 193 468 minecraft:brown_terracotta
setblock 275 193 469 minecraft:bone_block
fill 275 193 470 275 196 470 minecraft:brown_terracotta
setblock 275 193 474 minecraft:bone_block
fill 275 193 475 275 196 475 minecraft:brown_terracotta
setblock 275 193 479 minecraft:bone_block
fill 275 193 480 275 196 480 minecraft:brown_terracotta
setblock 275 193 484 minecraft:bone_block
fill 275 193 485 275 196 485 minecraft:brown_terracotta
setblock 275 193 488 minecraft:brown_terracotta
fill 275 193 500 275 196 500 minecraft:brown_terracotta
setblock 275 193 504 minecraft:bone_block
fill 276 193 464 276 196 464 minecraft:brown_terracotta
setblock 276 193 468 minecraft:bone_block
fill 276 193 469 276 196 469 minecraft:brown_terracotta
setblock 276 193 473 minecraft:bone_block
fill 276 193 474 276 196 474 minecraft:brown_terracotta
setblock 276 193 478 minecraft:bone_block
fill 276 193 479 276 196 479 minecraft:brown_terracotta
setblock 276 193 483 minecraft:bone_block
fill 276 193 484 276 196 484 minecraft:brown_terracotta
setblock 276 193 487 minecraft:brown_terracotta
setblock 276 193 488 minecraft:bone_block
fill 276 193 489 276 195 490 minecraft:brown_terracotta
setblock 276 193 498 minecraft:bone_block
fill 276 193 499 276 196 499 minecraft:brown_terracotta
setblock 276 193 503 minecraft:bone_block
fill 276 193 504 276 196 504 minecraft:brown_terracotta
setblock 236 194 467 minecraft:bone_block
fill 236 194 468 236 197 468 minecraft:brown_terracotta
setblock 236 194 472 minecraft:bone_block
fill 236 194 473 236 197 473 minecraft:brown_terracotta
setblock 236 194 477 minecraft:bone_block
fill 236 194 478 236 197 478 minecraft:brown_terracotta
setblock 236 194 482 minecraft:bone_block
fill 236 194 483 236 197 483 minecraft:brown_terracotta
setblock 236 194 487 minecraft:bone_block
fill 236 194 488 236 197 488 minecraft:brown_terracotta
fill 236 194 490 236 194 491 minecraft:brown_terracotta
fill 236 194 494 236 196 494 minecraft:brown_terracotta
setblock 236 194 497 minecraft:bone_block
fill 236 194 498 236 197 498 minecraft:brown_terracotta
setblock 236 194 502 minecraft:bone_block
fill 236 194 503 236 197 503 minecraft:brown_terracotta
setblock 237 194 466 minecraft:bone_block
fill 237 194 467 237 197 467 minecraft:brown_terracotta
setblock 237 194 471 minecraft:bone_block
fill 237 194 472 237 196 472 minecraft:brown_terracotta
setblock 237 194 476 minecraft:bone_block
fill 237 194 477 237 195 477 minecraft:brown_terracotta
setblock 237 194 481 minecraft:bone_block
fill 237 194 482 237 197 482 minecraft:brown_terracotta
setblock 237 194 486 minecraft:bone_block
fill 237 194 487 237 197 487 minecraft:brown_terracotta
setblock 237 194 501 minecraft:bone_block
fill 237 194 502 237 197 502 minecraft:brown_terracotta
setblock 238 194 465 minecraft:bone_block
fill 238 194 466 238 197 466 minecraft:brown_terracotta
setblock 238 194 500 minecraft:bone_block
fill 238 194 501 238 197 501 minecraft:brown_terracotta
setblock 239 194 464 minecraft:bone_block
fill 239 194 465 239 197 465 minecraft:brown_terracotta
setblock 239 194 504 minecraft:bone_block
fill 240 194 464 240 197 464 minecraft:brown_terracotta
setblock 240 194 503 minecraft:bone_block
fill 240 194 504 243 194 504 minecraft:brown_terracotta
setblock 241 194 502 minecraft:bone_block
fill 241 194 503 241 197 503 minecraft:brown_terracotta
fill 242 194 502 242 195 502 minecraft:brown_terracotta
setblock 243 194 465 minecraft:bone_block
fill 243 194 475 243 195 477 minecraft:bone_block
setblock 244 194 464 minecraft:bone_block
fill 244 194 475 244 195 476 minecraft:bone_block
setblock 244 194 504 minecraft:bone_block
fill 245 194 464 248 194 464 minecraft:brown_terracotta
setblock 245 194 503 minecraft:bone_block
fill 245 194 504 248 194 504 minecraft:brown_terracotta
fill 246 194 503 246 197 503 minecraft:brown_terracotta
setblock 249 194 464 minecraft:bone_block
fill 249 194 502 250 194 502 minecraft:brown_terracotta
setblock 249 194 504 minecraft:bone_block
fill 250 194 464 253 194 464 minecraft:brown_terracotta
setblock 250 194 503 minecraft:bone_block
fill 250 194 504 250 197 504 minecraft:brown_terracotta
setblock 251 194 502 minecraft:bone_block
fill 251 194 503 251 197 503 minecraft:brown_terracotta
setblock 252 194 465 minecraft:brown_terracotta
fill 252 194 502 252 197 502 minecraft:brown_terracotta
setblock 253 194 465 minecraft:bone_block
setblock 254 194 464 minecraft:bone_block
fill 254 194 465 257 194 465 minecraft:brown_terracotta
fill 254 194 501 255 194 501 minecraft:brown_terracotta
setblock 254 194 504 minecraft:bone_block
fill 255 194 464 255 197 464 minecraft:brown_terracotta
setblock 255 194 503 minecraft:bone_block
fill 255 194 504 255 197 504 minecraft:brown_terracotta
setblock 256 194 502 minecraft:bone_block
fill 256 194 503 256 197 503 minecraft:brown_terracotta
fill 257 194 502 257 196 502 minecraft:brown_terracotta
setblock 258 194 465 minecraft:bone_block
setblock 259 194 464 minecraft:bone_block
setblock 259 194 504 minecraft:bone_block
fill 260 194 464 260 197 464 minecraft:brown_terracotta
setblock 260 194 503 minecraft:bone_block
fill 260 194 504 260 197 504 minecraft:brown_terracotta
fill 261 194 503 261 195 503 minecraft:brown_terracotta
fill 262 194 464 262 195 464 minecraft:brown_terracotta
setblock 264 194 504 minecraft:bone_block
setblock 268 194 464 minecraft:brown_terracotta
setblock 269 194 464 minecraft:bone_block
setblock 269 194 504 minecraft:bone_block
fill 270 194 464 270 197 464 minecraft:brown_terracotta
fill 270 194 504 270 197 504 minecraft:brown_terracotta
fill 271 194 465 272 194 465 minecraft:brown_terracotta
fill 272 194 503 272 196 503 minecraft:brown_terracotta
setblock 273 194 465 minecraft:bone_block
fill 273 194 466 275 195 466 minecraft:brown_terracotta
setblock 273 194 480 minecraft:bone_block
fill 273 194 481 273 195 483 minecraft:brown_terracotta
setblock 274 194 464 minecraft:bone_block
fill 274 194 465 275 196 465 minecraft:brown_terracotta
fill 274 194 467 274 194 468 minecraft:brown_terracotta
fill 274 194 475 274 197 475 minecraft:brown_terracotta
setblock 274 194 479 minecraft:bone_block
fill 274 194 480 274 197 480 minecraft:brown_terracotta
setblock 274 194 484 minecraft:bone_block
fill 274 194 485 274 195 487 minecraft:brown_terracotta
setblock 274 194 504 minecraft:bone_block
fill 275 194 464 275 197 464 minecraft:brown_terracotta
setblock 275 194 467 minecraft:brown_terracotta
setblock 275 194 468 minecraft:bone_block
fill 275 194 469 275 197 469 minecraft:brown_terracotta
setblock 275 194 473 minecraft:bone_block
fill 275 194 474 275 197 474 minecraft:brown_terracotta
setblock 275 194 478 minecraft:bone_block
fill 275 194 479 275 197 479 minecraft:brown_terracotta
setblock 275 194 483 minecraft:bone_block
fill 275 194 484 275 197 484 minecraft:brown_terracotta
setblock 275 194 488 minecraft:bone_block
fill 275 194 489 275 197 489 minecraft:brown_terracotta
setblock 275 194 502 minecraft:brown_terracotta
setblock 275 194 503 minecraft:bone_block
fill 275 194 504 275 197 504 minecraft:brown_terracotta
setblock 276 194 467 minecraft:bone_block
fill 276 194 468 276 197 468 minecraft:brown_terracotta
setblock 276 194 472 minecraft:bone_block
fill 276 194 473 276 197 473 minecraft:brown_terracotta
setblock 276 194 477 minecraft:bone_block
fill 276 194 478 276 197 478 minecraft:brown_terracotta
setblock 276 194 482 minecraft:bone_block
fill 276 194 483 276 197 483 minecraft:brown_terracotta
setblock 276 194 487 minecraft:bone_block
fill 276 194 488 276 197 488 minecraft:brown_terracotta
setblock 276 194 491 minecraft:brown_terracotta
setblock 276 194 492 minecraft:bone_block
setblock 276 194 497 minecraft:bone_block
fill 276 194 498 276 197 498 minecraft:brown_terracotta
setblock 276 194 502 minecraft:bone_block
fill 276 194 503 276 197 503 minecraft:brown_terracotta
setblock 236 195 466 minecraft:bone_block
fill 236 195 467 236 198 467 minecraft:brown_terracotta
setblock 236 195 471 minecraft:bone_block
fill 236 195 472 236 198 472 minecraft:brown_terracotta
setblock 236 195 476 minecraft:bone_block
fill 236 195 477 236 198 477 minecraft:brown_terracotta
setblock 236 195 481 minecraft:bone_block
fill 236 195 482 236 198 482 minecraft:brown_terracotta
setblock 236 195 485 minecraft:brown_terracotta
setblock 236 195 486 minecraft:bone_block
fill 236 195 487 236 198 487 minecraft:brown_terracotta
setblock 236 195 490 minecraft:brown_terracotta
setblock 236 195 491 minecraft:bone_block
fill 236 195 492 236 197 493 minecraft:brown_terracotta
setblock 236 195 496 minecraft:bone_block
fill 236 195 497 236 198 497 minecraft:brown_terracotta
setblock 236 195 501 minecraft:bone_block
fill 236 195 502 236 198 502 minecraft:brown_terracotta
setblock 237 195 465 minecraft:bone_block
fill 237 195 466 237 198 466 minecraft:brown_terracotta
setblock 237 195 470 minecraft:bone_block
fill 237 195 471 237 198 471 minecraft:brown_terracotta
setblock 237 195 480 minecraft:bone_block
fill 237 195 481 237 197 481 minecraft:brown_terracotta
setblock 237 195 485 minecraft:bone_block
fill 237 195 486 237 198 486 minecraft:brown_terracotta
fill 237 195 488 237 196 488 minecraft:brown_terracotta
setblock 237 195 500 minecraft:bone_block
fill 237 195 501 237 198 501 minecraft:brown_terracotta
setblock 238 195 464 minecraft:bone_block
fill 238 195 465 238 198 465 minecraft:brown_terracotta
setblock 238 195 468 minecraft:brown_terracotta
setblock 238 195 474 minecraft:light[level=12]
setblock 238 195 482 minecraft:light[level=12]
setblock 238 195 490 minecraft:light[level=12]
setblock 238 195 498 minecraft:light[level=12]
setblock 238 195 500 minecraft:brown_terracotta
setblock 238 195 504 minecraft:bone_block
fill 239 195 464 239 198 464 minecraft:brown_terracotta
setblock 239 195 503 minecraft:bone_block
fill 239 195 504 242 195 504 minecraft:brown_terracotta
setblock 240 195 466 minecraft:brown_terracotta
setblock 240 195 502 minecraft:bone_block
fill 240 195 503 240 198 503 minecraft:brown_terracotta
setblock 241 195 465 minecraft:brown_terracotta
fill 241 195 502 241 196 502 minecraft:brown_terracotta
setblock 242 195 465 minecraft:bone_block
setblock 243 195 464 minecraft:bone_block
fill 243 195 465 243 198 465 minecraft:brown_terracotta
setblock 243 195 504 minecraft:bone_block
fill 244 195 464 247 195 464 minecraft:brown_terracotta
setblock 244 195 503 minecraft:bone_block
fill 244 195 504 247 195 504 minecraft:brown_terracotta
fill 245 195 503 245 198 503 minecraft:brown_terracotta
setblock 246 195 466 minecraft:light[level=12]
setblock 246 195 474 minecraft:light[level=12]
setblock 246 195 482 minecraft:light[level=12]
setblock 246 195 490 minecraft:light[level=12]
setblock 246 195 498 minecraft:light[level=12]
setblock 248 195 464 minecraft:bone_block
fill 248 195 502 249 195 502 minecraft:brown_terracotta
setblock 248 195 504 minecraft:bone_block
fill 249 195 464 252 195 464 minecraft:brown_terracotta
setblock 249 195 503 minecraft:bone_block
fill 249 195 504 249 198 504 minecraft:brown_terracotta
fill 250 195 465 251 195 465 minecraft:brown_terracotta
setblock 250 195 502 minecraft:bone_block
fill 250 195 503 250 198 503 minecraft:brown_terracotta
fill 251 195 502 251 198 502 minecraft:brown_terracotta
setblock 252 195 465 minecraft:bone_block
setblock 253 195 464 minecraft:bone_block
fill 253 195 465 256 195 465 minecraft:brown_terracotta
setblock 253 195 504 minecraft:bone_block
fill 254 195 464 254 198 464 minecraft:brown_terracotta
setblock 254 195 466 minecraft:light[level=12]
setblock 254 195 474 minecraft:light[level=12]
setblock 254 195 482 minecraft:light[level=12]
setblock 254 195 490 minecraft:light[level=12]
setblock 254 195 498 minecraft:light[level=12]
setblock 254 195 501 minecraft:brown_terracotta
setblock 254 195 503 minecraft:bone_block
fill 254 195 504 254 198 504 minecraft:brown_terracotta
setblock 255 195 502 minecraft:bone_block
fill 255 195 503 255 198 503 minecraft:brown_terracotta
fill 256 195 502 256 197 502 minecraft:brown_terracotta
setblock 257 195 465 minecraft:bone_block
setblock 258 195 464 minecraft:bone_block
fill 258 195 465 259 197 465 minecraft:brown_terracotta
setblock 258 195 504 minecraft:bone_block
fill 259 195 464 259 198 464 minecraft:brown_terracotta
setblock 259 195 503 minecraft:bone_block
fill 259 195 504 259 198 504 minecraft:brown_terracotta
fill 260 195 503 260 196 503 minecraft:brown_terracotta
setblock 262 195 466 minecraft:light[level=12]
setblock 262 195 474 minecraft:light[level=12]
setblock 262 195 482 minecraft:light[level=12]
setblock 262 195 490 minecraft:light[level=12]
setblock 262 195 498 minecraft:light[level=12]
setblock 263 195 464 minecraft:bone_block
setblock 263 195 504 minecraft:bone_block
fill 264 195 464 267 195 464 minecraft:brown_terracotta
setblock 264 195 504 minecraft:brown_terracotta
setblock 267 195 504 minecraft:brown_terracotta
setblock 268 195 464 minecraft:bone_block
setblock 268 195 504 minecraft:bone_block
fill 269 195 464 269 197 465 minecraft:brown_terracotta
fill 269 195 504 269 198 504 minecraft:brown_terracotta
fill 270 195 465 271 195 465 minecraft:brown_terracotta
setblock 270 195 466 minecraft:light[level=12]
setblock 270 195 474 minecraft:light[level=12]
setblock 270 195 482 minecraft:light[level=12]
setblock 270 195 490 minecraft:light[level=12]
setblock 270 195 498 minecraft:light[level=12]
fill 271 195 503 271 197 503 minecraft:brown_terracotta
setblock 272 195 465 minecraft:bone_block
fill 272 195 466 272 198 466 minecraft:brown_terracotta
setblock 273 195 464 minecraft:bone_block
fill 273 195 465 273 198 465 minecraft:brown_terracotta
setblock 273 195 479 minecraft:bone_block
fill 273 195 480 273 196 480 minecraft:brown_terracotta
setblock 273 195 484 minecraft:bone_block
fill 273 195 485 273 198 485 minecraft:brown_terracotta
setblock 273 195 504 minecraft:bone_block
fill 274 195 464 274 198 464 minecraft:brown_terracotta
setblock 274 195 467 minecraft:brown_terracotta
setblock 274 195 468 minecraft:bone_block
fill 274 195 469 274 195 472 minecraft:brown_terracotta
setblock 274 195 473 minecraft:bone_block
fill 274 195 474 274 198 474 minecraft:brown_terracotta
setblock 274 195 478 minecraft:bone_block
fill 274 195 479 274 198 479 minecraft:brown_terracotta
setblock 274 195 483 minecraft:bone_block
fill 274 195 484 274 198 484 minecraft:brown_terracotta
setblock 274 195 503 minecraft:bone_block
fill 274 195 504 274 198 504 minecraft:brown_terracotta
setblock 275 195 467 minecraft:bone_block
fill 275 195 468 275 198 468 minecraft:brown_terracotta
setblock 275 195 472 minecraft:bone_block
fill 275 195 473 275 198 473 minecraft:brown_terracotta
setblock 275 195 477 minecraft:bone_block
fill 275 195 478 275 198 478 minecraft:brown_terracotta
setblock 275 195 482 minecraft:bone_block
fill 275 195 483 275 198 483 minecraft:brown_terracotta
setblock 275 195 486 minecraft:brown_terracotta
setblock 275 195 487 minecraft:bone_block
fill 275 195 488 275 198 488 minecraft:brown_terracotta
fill 275 195 490 275 196 490 minecraft:brown_terracotta
setblock 275 195 502 minecraft:bone_block
fill 275 195 503 275 198 503 minecraft:brown_terracotta
setblock 276 195 466 minecraft:bone_block
fill 276 195 467 276 198 467 minecraft:brown_terracotta
setblock 276 195 471 minecraft:bone_block
fill 276 195 472 276 198 472 minecraft:brown_terracotta
setblock 276 195 476 minecraft:bone_block
fill 276 195 477 276 198 477 minecraft:brown_terracotta
setblock 276 195 481 minecraft:bone_block
fill 276 195 482 276 198 482 minecraft:brown_terracotta
setblock 276 195 486 minecraft:bone_block
fill 276 195 487 276 198 487 minecraft:brown_terracotta
setblock 276 195 491 minecraft:bone_block
fill 276 195 492 276 197 493 minecraft:brown_terracotta
setblock 276 195 496 minecraft:bone_block
fill 276 195 497 276 197 497 minecraft:brown_terracotta
setblock 276 195 501 minecraft:bone_block
fill 276 195 502 276 198 502 minecraft:brown_terracotta
setblock 236 196 465 minecraft:bone_block
fill 236 196 466 236 199 466 minecraft:brown_terracotta
setblock 236 196 470 minecraft:bone_block
fill 236 196 471 236 199 471 minecraft:brown_terracotta
setblock 236 196 475 minecraft:bone_block
fill 236 196 476 236 198 476 minecraft:brown_terracotta
setblock 236 196 480 minecraft:bone_block
fill 236 196 481 236 199 481 minecraft:brown_terracotta
setblock 236 196 485 minecraft:bone_block
fill 236 196 486 236 199 486 minecraft:brown_terracotta
setblock 236 196 490 minecraft:bone_block
fill 236 196 491 236 199 491 minecraft:brown_terracotta
setblock 236 196 495 minecraft:bone_block
fill 236 196 496 236 199 496 minecraft:brown_terracotta
setblock 236 196 500 minecraft:bone_block
fill 236 196 501 236 199 501 minecraft:brown_terracotta
setblock 237 196 464 minecraft:bone_block
fill 237 196 465 237 199 465 minecraft:brown_terracotta
setblock 237 196 469 minecraft:bone_block
fill 237 196 470 237 199 470 minecraft:brown_terracotta
setblock 237 196 479 minecraft:bone_block
setblock 237 196 480 minecraft:brown_terracotta
setblock 237 196 484 minecraft:bone_block
fill 237 196 485 237 199 485 minecraft:brown_terracotta
setblock 237 196 489 minecraft:bone_block
setblock 237 196 499 minecraft:bone_block
fill 237 196 500 237 198 500 minecraft:brown_terracotta
setblock 237 196 504 minecraft:bone_block
fill 238 196 464 238 199 464 minecraft:brown_terracotta
setblock 238 196 468 minecraft:bone_block
setblock 238 196 503 minecraft:bone_block
fill 238 196 504 241 196 504 minecraft:brown_terracotta
setblock 239 196 502 minecraft:bone_block
fill 239 196 503 239 199 503 minecraft:brown_terracotta
setblock 240 196 466 minecraft:bone_block
setblock 240 196 502 minecraft:brown_terracotta
setblock 241 196 465 minecraft:bone_block
setblock 242 196 464 minecraft:bone_block
fill 242 196 465 242 199 465 minecraft:brown_terracotta
setblock 242 196 504 minecraft:bone_block
fill 243 196 464 246 196 464 minecraft:brown_terracotta
setblock 243 196 503 minecraft:bone_block
fill 243 196 504 246 196 504 minecraft:brown_terracotta
fill 244 196 465 244 197 465 minecraft:brown_terracotta
fill 244 196 503 244 199 503 minecraft:brown_terracotta
setblock 247 196 464 minecraft:bone_block
setblock 247 196 504 minecraft:bone_block
fill 248 196 464 250 196 465 minecraft:brown_terracotta
setblock 248 196 502 minecraft:brown_terracotta
setblock 248 196 503 minecraft:bone_block
fill 248 196 504 248 199 504 minecraft:brown_terracotta
setblock 249 196 502 minecraft:bone_block
fill 249 196 503 249 199 503 minecraft:brown_terracotta
fill 250 196 502 250 198 502 minecraft:brown_terracotta
setblock 251 196 464 minecraft:brown_terracotta
setblock 251 196 465 minecraft:bone_block
setblock 252 196 464 minecraft:bone_block
fill 252 196 465 255 196 465 minecraft:brown_terracotta
setblock 252 196 504 minecraft:bone_block
fill 253 196 464 253 199 464 minecraft:brown_terracotta
setblock 253 196 503 minecraft:bone_block
fill 253 196 504 253 199 504 minecraft:brown_terracotta
setblock 254 196 502 minecraft:bone_block
fill 254 196 503 254 199 503 minecraft:brown_terracotta
fill 255 196 502 255 198 502 minecraft:brown_terracotta
setblock 256 196 465 minecraft:bone_block
setblock 257 196 464 minecraft:bone_block
fill 257 196 465 257 199 465 minecraft:brown_terracotta
setblock 257 196 504 minecraft:bone_block
fill 258 196 464 258 199 464 minecraft:brown_terracotta
setblock 258 196 503 minecraft:bone_block
fill 258 196 504 258 199 504 minecraft:brown_terracotta
fill 259 196 503 259 197 503 minecraft:brown_terracotta
setblock 262 196 464 minecraft:bone_block
setblock 262 196 504 minecraft:bone_block
fill 263 196 464 266 196 464 minecraft:brown_terracotta
setblock 263 196 504 minecraft:brown_terracotta
setblock 267 196 464 minecraft:bone_block
setblock 267 196 504 minecraft:bone_block
fill 268 196 464 268 198 465 minecraft:brown_terracotta
fill 268 196 504 268 199 504 minecraft:brown_terracotta
setblock 270 196 465 minecraft:brown_terracotta
setblock 270 196 466 minecraft:bone_block
setblock 271 196 465 minecraft:bone_block
fill 271 196 466 271 199 466 minecraft:brown_terracotta
setblock 272 196 464 minecraft:bone_block
fill 272 196 465 272 199 465 minecraft:brown_terracotta
setblock 272 196 504 minecraft:bone_block
fill 273 196 464 273 199 464 minecraft:brown_terracotta
fill 273 196 466 273 196 467 minecraft:brown_terracotta
fill 273 196 481 273 196 482 minecraft:brown_terracotta
setblock 273 196 483 minecraft:bone_block
fill 273 196 484 273 198 484 minecraft:brown_terracotta
setblock 273 196 503 minecraft:bone_block
fill 273 196 504 273 199 504 minecraft:brown_terracotta
setblock 274 196 466 minecraft:brown_terracotta
setblock 274 196 467 minecraft:bone_block
fill 274 196 468 274 196 471 minecraft:brown_terracotta
setblock 274 196 472 minecraft:bone_block
fill 274 196 473 274 199 473 minecraft:brown_terracotta
setblock 274 196 477 minecraft:bone_block
fill 274 196 478 274 198 478 minecraft:brown_terracotta
setblock 274 196 482 minecraft:bone_block
fill 274 196 483 274 199 483 minecraft:brown_terracotta
fill 274 196 485 274 196 486 minecraft:brown_terracotta
setblock 274 196 487 minecraft:bone_block
fill 274 196 488 274 199 488 minecraft:brown_terracotta
fill 274 196 503 274 199 503 minecraft:brown_terracotta
setblock 275 196 466 minecraft:bone_block
fill 275 196 467 275 199 467 minecraft:brown_terracotta
setblock 275 196 471 minecraft:bone_block
fill 275 196 472 275 199 472 minecraft:brown_terracotta
setblock 275 196 476 minecraft:bone_block
fill 275 196 477 275 199 477 minecraft:brown_terracotta
setblock 275 196 481 minecraft:bone_block
fill 275 196 482 275 199 482 minecraft:brown_terracotta
setblock 275 196 486 minecraft:bone_block
fill 275 196 487 275 199 487 minecraft:brown_terracotta
setblock 275 196 501 minecraft:bone_block
fill 275 196 502 275 199 502 minecraft:brown_terracotta
setblock 276 196 465 minecraft:bone_block
fill 276 196 466 276 199 466 minecraft:brown_terracotta
setblock 276 196 470 minecraft:bone_block
fill 276 196 471 276 199 471 minecraft:brown_terracotta
setblock 276 196 475 minecraft:bone_block
fill 276 196 476 276 199 476 minecraft:brown_terracotta
setblock 276 196 480 minecraft:bone_block
fill 276 196 481 276 199 481 minecraft:brown_terracotta
setblock 276 196 485 minecraft:bone_block
fill 276 196 486 276 199 486 minecraft:brown_terracotta
setblock 276 196 489 minecraft:brown_terracotta
setblock 276 196 490 minecraft:bone_block
fill 276 196 491 276 199 491 minecraft:brown_terracotta
setblock 276 196 494 minecraft:brown_terracotta
setblock 276 196 496 minecraft:brown_terracotta
setblock 276 196 500 minecraft:bone_block
fill 276 196 501 276 199 501 minecraft:brown_terracotta
setblock 236 197 464 minecraft:bone_block
fill 236 197 465 236 200 465 minecraft:brown_terracotta
setblock 236 197 469 minecraft:bone_block
fill 236 197 470 236 200 470 minecraft:brown_terracotta
setblock 236 197 474 minecraft:bone_block
fill 236 197 475 236 199 475 minecraft:brown_terracotta
setblock 236 197 479 minecraft:bone_block
fill 236 197 480 236 199 480 minecraft:brown_terracotta
setblock 236 197 484 minecraft:bone_block
fill 236 197 485 236 200 485 minecraft:brown_terracotta
setblock 236 197 489 minecraft:bone_block
fill 236 197 490 237 198 490 minecraft:brown_terracotta
setblock 236 197 494 minecraft:bone_block
fill 236 197 495 236 200 495 minecraft:brown_terracotta
setblock 236 197 499 minecraft:bone_block
fill 236 197 500 236 200 500 minecraft:brown_terracotta
setblock 236 197 504 minecraft:bone_block
fill 237 197 464 237 200 464 minecraft:brown_terracotta
setblock 237 197 468 minecraft:bone_block
fill 237 197 469 237 200 469 minecraft:brown_terracotta
setblock 237 197 483 minecraft:bone_block
fill 237 197 484 237 198 484 minecraft:brown_terracotta
setblock 237 197 488 minecraft:bone_block
fill 237 197 489 237 199 489 minecraft:brown_terracotta
fill 237 197 499 237 198 499 minecraft:brown_terracotta
setblock 237 197 503 minecraft:bone_block
fill 237 197 504 240 197 504 minecraft:brown_terracotta
setblock 238 197 467 minecraft:bone_block
fill 238 197 468 238 198 468 minecraft:brown_terracotta
setblock 238 197 502 minecraft:bone_block
fill 238 197 503 238 200 503 minecraft:brown_terracotta
setblock 239 197 466 minecraft:bone_block
setblock 239 197 502 minecraft:brown_terracotta
setblock 240 197 465 minecraft:bone_block
setblock 240 197 466 minecraft:brown_terracotta
setblock 241 197 464 minecraft:bone_block
fill 241 197 465 241 199 465 minecraft:brown_terracotta
setblock 241 197 504 minecraft:bone_block
fill 242 197 464 245 197 464 minecraft:brown_terracotta
setblock 242 197 503 minecraft:bone_block
fill 242 197 504 245 197 504 minecraft:brown_terracotta
fill 243 197 503 243 198 503 minecraft:brown_terracotta
setblock 245 197 465 minecraft:bone_block
setblock 246 197 464 minecraft:bone_block
fill 246 197 465 249 197 465 minecraft:brown_terracotta
setblock 246 197 504 minecraft:bone_block
fill 247 197 464 250 197 464 minecraft:brown_terracotta
setblock 247 197 503 minecraft:bone_block
fill 247 197 504 247 200 504 minecraft:brown_terracotta
setblock 248 197 502 minecraft:bone_block
fill 248 197 503 248 200 503 minecraft:brown_terracotta
fill 249 197 502 249 198 502 minecraft:brown_terracotta
setblock 250 197 465 minecraft:bone_block
setblock 251 197 464 minecraft:bone_block
fill 251 197 465 254 197 465 minecraft:brown_terracotta
setblock 251 197 504 minecraft:bone_block
fill 252 197 464 252 200 464 minecraft:brown_terracotta
setblock 252 197 503 minecraft:bone_block
fill 252 197 504 252 200 504 minecraft:brown_terracotta
setblock 253 197 502 minecraft:bone_block
fill 253 197 503 253 200 503 minecraft:brown_terracotta
fill 254 197 502 254 198 502 minecraft:brown_terracotta
setblock 255 197 465 minecraft:bone_block
setblock 256 197 464 minecraft:bone_block
fill 256 197 465 256 200 465 minecraft:brown_terracotta
setblock 256 197 504 minecraft:bone_block
fill 257 197 464 257 200 464 minecraft:brown_terracotta
setblock 257 197 503 minecraft:bone_block
fill 257 197 504 257 200 504 minecraft:brown_terracotta
fill 258 197 503 258 198 503 minecraft:brown_terracotta
setblock 261 197 464 minecraft:bone_block
setblock 261 197 504 minecraft:bone_block
fill 262 197 464 265 197 464 minecraft:brown_terracotta
setblock 262 197 504 minecraft:brown_terracotta
setblock 266 197 464 minecraft:bone_block
fill 267 197 464 267 199 465 minecraft:brown_terracotta
fill 267 197 504 267 198 504 minecraft:brown_terracotta
setblock 270 197 465 minecraft:bone_block
fill 270 197 466 270 200 466 minecraft:brown_terracotta
setblock 271 197 464 minecraft:bone_block
fill 271 197 465 271 200 465 minecraft:brown_terracotta
setblock 271 197 504 minecraft:bone_block
fill 272 197 464 272 200 464 minecraft:brown_terracotta
setblock 272 197 467 minecraft:brown_terracotta
setblock 272 197 503 minecraft:bone_block
fill 272 197 504 272 200 504 minecraft:brown_terracotta
setblock 273 197 466 minecraft:brown_terracotta
setblock 273 197 467 minecraft:bone_block
fill 273 197 468 274 198 469 minecraft:brown_terracotta
setblock 273 197 481 minecraft:brown_terracotta
setblock 273 197 482 minecraft:bone_block
fill 273 197 483 273 198 483 minecraft:brown_terracotta
setblock 273 197 486 minecraft:brown_terracotta
fill 273 197 503 273 200 503 minecraft:brown_terracotta
setblock 274 197 465 minecraft:brown_terracotta
setblock 274 197 466 minecraft:bone_block
fill 274 197 467 274 200 467 minecraft:brown_terracotta
setblock 274 197 470 minecraft:brown_terracotta
setblock 274 197 471 minecraft:bone_block
fill 274 197 472 274 200 472 minecraft:brown_terracotta
setblock 274 197 476 minecraft:bone_block
fill 274 197 477 274 198 477 minecraft:brown_terracotta
setblock 274 197 481 minecraft:bone_block
fill 274 197 482 274 199 482 minecraft:brown_terracotta
setblock 274 197 485 minecraft:brown_terracotta
setblock 274 197 486 minecraft:bone_block
fill 274 197 487 274 200 487 minecraft:brown_terracotta
fill 274 197 489 274 198 489 minecraft:brown_terracotta
setblock 275 197 465 minecraft:bone_block
fill 275 197 466 275 200 466 minecraft:brown_terracotta
setblock 275 197 470 minecraft:bone_block
fill 275 197 471 275 200 471 minecraft:brown_terracotta
setblock 275 197 475 minecraft:bone_block
fill 275 197 476 275 200 476 minecraft:brown_terracotta
setblock 275 197 480 minecraft:bone_block
fill 275 197 481 275 200 481 minecraft:brown_terracotta
setblock 275 197 485 minecraft:bone_block
fill 275 197 486 275 200 486 minecraft:brown_terracotta
setblock 275 197 490 minecraft:bone_block
fill 275 197 491 275 199 491 minecraft:brown_terracotta
fill 275 197 501 275 198 501 minecraft:brown_terracotta
setblock 276 197 464 minecraft:bone_block
fill 276 197 465 276 200 465 minecraft:brown_terracotta
setblock 276 197 469 minecraft:bone_block
fill 276 197 470 276 200 470 minecraft:brown_terracotta
setblock 276 197 474 minecraft:bone_block
fill 276 197 475 276 200 475 minecraft:brown_terracotta
setblock 276 197 479 minecraft:bone_block
fill 276 197 480 276 200 480 minecraft:brown_terracotta
setblock 276 197 484 minecraft:bone_block
fill 276 197 485 276 200 485 minecraft:brown_terracotta
setblock 276 197 489 minecraft:bone_block
fill 276 197 490 276 200 490 minecraft:brown_terracotta
setblock 276 197 494 minecraft:bone_block
setblock 276 197 499 minecraft:bone_block
fill 276 197 500 276 199 500 minecraft:brown_terracotta
setblock 276 197 504 minecraft:bone_block
fill 236 198 464 236 201 464 minecraft:brown_terracotta
setblock 236 198 468 minecraft:bone_block
fill 236 198 469 236 201 469 minecraft:brown_terracotta
setblock 236 198 473 minecraft:bone_block
fill 236 198 474 236 199 474 minecraft:brown_terracotta
setblock 236 198 478 minecraft:bone_block
fill 236 198 479 236 199 479 minecraft:brown_terracotta
setblock 236 198 483 minecraft:bone_block
fill 236 198 484 236 201 484 minecraft:brown_terracotta
setblock 236 198 488 minecraft:bone_block
fill 236 198 489 236 201 489 minecraft:brown_terracotta
setblock 236 198 492 minecraft:brown_terracotta
setblock 236 198 493 minecraft:bone_block
fill 236 198 494 236 201 494 minecraft:brown_terracotta
setblock 236 198 498 minecraft:bone_block
fill 236 198 499 236 201 499 minecraft:brown_terracotta
setblock 236 198 503 minecraft:bone_block
fill 236 198 504 239 198 504 minecraft:brown_terracotta
setblock 237 198 467 minecraft:bone_block
fill 237 198 468 237 201 468 minecraft:brown_terracotta
setblock 237 198 483 minecraft:brown_terracotta
setblock 237 198 487 minecraft:bone_block
fill 237 198 488 237 199 488 minecraft:brown_terracotta
setblock 237 198 502 minecraft:bone_block
fill 237 198 503 237 200 503 minecraft:brown_terracotta
setblock 238 198 466 minecraft:bone_block
fill 238 198 467 238 199 467 minecraft:brown_terracotta
setblock 238 198 502 minecraft:brown_terracotta
setblock 239 198 465 minecraft:bone_block
setblock 239 198 466 minecraft:brown_terracotta
setblock 240 198 464 minecraft:bone_block
fill 240 198 465 240 200 465 minecraft:brown_terracotta
setblock 240 198 504 minecraft:bone_block
fill 241 198 464 244 198 464 minecraft:brown_terracotta
setblock 241 198 503 minecraft:bone_block
fill 241 198 504 244 198 504 minecraft:brown_terracotta
fill 242 198 503 242 199 503 minecraft:brown_terracotta
setblock 244 198 465 minecraft:bone_block
setblock 245 198 464 minecraft:bone_block
fill 245 198 465 248 198 465 minecraft:brown_terracotta
setblock 245 198 504 minecraft:bone_block
fill 246 198 464 249 198 464 minecraft:brown_terracotta
setblock 246 198 503 minecraft:bone_block
fill 246 198 504 246 201 504 minecraft:brown_terracotta
fill 247 198 503 247 200 503 minecraft:brown_terracotta
setblock 249 198 465 minecraft:bone_block
setblock 250 198 464 minecraft:bone_block
fill 250 198 465 253 198 465 minecraft:brown_terracotta
setblock 250 198 504 minecraft:bone_block
fill 251 198 464 251 201 464 minecraft:brown_terracotta
setblock 251 198 503 minecraft:bone_block
fill 251 198 504 251 201 504 minecraft:brown_terracotta
setblock 252 198 502 minecraft:bone_block
fill 252 198 503 252 201 503 minecraft:brown_terracotta
setblock 253 198 466 minecraft:bone_block
fill 253 198 502 253 199 502 minecraft:brown_terracotta
setblock 254 198 465 minecraft:bone_block
setblock 255 198 464 minecraft:bone_block
fill 255 198 465 255 200 465 minecraft:brown_terracotta
setblock 255 198 504 minecraft:bone_block
fill 256 198 464 256 201 464 minecraft:brown_terracotta
setblock 256 198 503 minecraft:bone_block
fill 256 198 504 256 201 504 minecraft:brown_terracotta
setblock 257 198 503 minecraft:brown_terracotta
setblock 258 198 465 minecraft:brown_terracotta
setblock 260 198 464 minecraft:bone_block
setblock 260 198 504 minecraft:bone_block
fill 261 198 464 264 198 464 minecraft:brown_terracotta
setblock 265 198 464 minecraft:bone_block
fill 266 198 464 266 201 464 minecraft:brown_terracotta
setblock 269 198 464 minecraft:brown_terracotta
setblock 269 198 465 minecraft:bone_block
fill 269 198 466 269 201 466 minecraft:brown_terracotta
setblock 270 198 464 minecraft:bone_block
fill 270 198 465 270 201 465 minecraft:brown_terracotta
setblock 270 198 504 minecraft:bone_block
fill 271 198 464 271 201 464 minecraft:brown_terracotta
setblock 271 198 467 minecraft:brown_terracotta
setblock 271 198 503 minecraft:bone_block
fill 271 198 504 271 201 504 minecraft:brown_terracotta
setblock 272 198 467 minecraft:bone_block
fill 272 198 503 272 199 503 minecraft:brown_terracotta
setblock 273 198 466 minecraft:bone_block
fill 273 198 467 273 201 467 minecraft:brown_terracotta
setblock 273 198 470 minecraft:brown_terracotta
setblock 273 198 486 minecraft:bone_block
setblock 274 198 465 minecraft:bone_block
fill 274 198 466 274 201 466 minecraft:brown_terracotta
setblock 274 198 470 minecraft:bone_block
fill 274 198 471 274 201 471 minecraft:brown_terracotta
setblock 274 198 475 minecraft:bone_block
setblock 274 198 476 minecraft:brown_terracotta
setblock 274 198 480 minecraft:bone_block
fill 274 198 481 274 199 481 minecraft:brown_terracotta
setblock 274 198 485 minecraft:bone_block
fill 274 198 486 274 200 486 minecraft:brown_terracotta
setblock 275 198 464 minecraft:bone_block
fill 275 198 465 275 201 465 minecraft:brown_terracotta
setblock 275 198 469 minecraft:bone_block
fill 275 198 470 275 201 470 minecraft:brown_terracotta
setblock 275 198 474 minecraft:bone_block
fill 275 198 475 275 200 475 minecraft:brown_terracotta
setblock 275 198 479 minecraft:bone_block
fill 275 198 480 275 200 480 minecraft:brown_terracotta
setblock 275 198 484 minecraft:bone_block
fill 275 198 485 275 201 485 minecraft:brown_terracotta
setblock 275 198 489 minecraft:bone_block
fill 275 198 490 275 200 490 minecraft:brown_terracotta
setblock 275 198 504 minecraft:bone_block
fill 276 198 464 276 201 464 minecraft:brown_terracotta
setblock 276 198 468 minecraft:bone_block
fill 276 198 469 276 201 469 minecraft:brown_terracotta
setblock 276 198 473 minecraft:bone_block
fill 276 198 474 276 201 474 minecraft:brown_terracotta
setblock 276 198 478 minecraft:bone_block
fill 276 198 479 276 200 479 minecraft:brown_terracotta
setblock 276 198 483 minecraft:bone_block
fill 276 198 484 276 201 484 minecraft:brown_terracotta
setblock 276 198 488 minecraft:bone_block
fill 276 198 489 276 201 489 minecraft:brown_terracotta
setblock 276 198 492 minecraft:brown_terracotta
setblock 276 198 493 minecraft:bone_block
setblock 276 198 499 minecraft:brown_terracotta
setblock 276 198 503 minecraft:bone_block
fill 276 198 504 276 201 504 minecraft:brown_terracotta
setblock 236 199 467 minecraft:bone_block
fill 236 199 468 236 202 468 minecraft:brown_terracotta
setblock 236 199 472 minecraft:bone_block
fill 236 199 473 236 200 473 minecraft:brown_terracotta
setblock 236 199 482 minecraft:bone_block
fill 236 199 483 236 200 483 minecraft:brown_terracotta
setblock 236 199 487 minecraft:bone_block
fill 236 199 488 236 202 488 minecraft:brown_terracotta
fill 236 199 490 236 200 490 minecraft:brown_terracotta
setblock 236 199 492 minecraft:bone_block
fill 236 199 493 236 202 493 minecraft:brown_terracotta
setblock 236 199 497 minecraft:bone_block
fill 236 199 498 236 200 498 minecraft:brown_terracotta
setblock 236 199 502 minecraft:bone_block
fill 236 199 503 236 201 504 minecraft:brown_terracotta
setblock 237 199 466 minecraft:bone_block
fill 237 199 467 237 202 467 minecraft:brown_terracotta
setblock 237 199 486 minecraft:bone_block
setblock 237 199 487 minecraft:brown_terracotta
setblock 237 199 501 minecraft:bone_block
fill 237 199 502 237 200 502 minecraft:brown_terracotta
fill 237 199 504 238 199 504 minecraft:brown_terracotta
setblock 238 199 465 minecraft:bone_block
setblock 238 199 466 minecraft:brown_terracotta
setblock 239 199 464 minecraft:bone_block
fill 239 199 465 239 201 465 minecraft:brown_terracotta
setblock 239 199 504 minecraft:bone_block
fill 240 199 464 243 199 464 minecraft:brown_terracotta
setblock 240 199 503 minecraft:bone_block
fill 240 199 504 243 199 504 minecraft:brown_terracotta
setblock 241 199 503 minecraft:brown_terracotta
setblock 244 199 464 minecraft:bone_block
setblock 244 199 504 minecraft:bone_block
fill 245 199 464 248 199 464 minecraft:brown_terracotta
setblock 245 199 503 minecraft:bone_block
fill 245 199 504 245 202 504 minecraft:brown_terracotta
fill 246 199 465 247 199 465 minecraft:brown_terracotta
setblock 246 199 503 minecraft:brown_terracotta
setblock 248 199 465 minecraft:bone_block
setblock 249 199 464 minecraft:bone_block
fill 249 199 465 252 199 465 minecraft:brown_terracotta
setblock 249 199 504 minecraft:bone_block
fill 250 199 464 250 202 464 minecraft:brown_terracotta
setblock 250 199 503 minecraft:bone_block
fill 250 199 504 250 202 504 minecraft:brown_terracotta
setblock 251 199 502 minecraft:bone_block
fill 251 199 503 251 201 503 minecraft:brown_terracotta
setblock 252 199 502 minecraft:brown_terracotta
setblock 253 199 465 minecraft:bone_block
setblock 254 199 464 minecraft:bone_block
fill 254 199 465 254 201 465 minecraft:brown_terracotta
setblock 254 199 504 minecraft:bone_block
fill 255 199 464 255 202 464 minecraft:brown_terracotta
setblock 255 199 503 minecraft:bone_block
fill 255 199 504 255 201 504 minecraft:brown_terracotta
setblock 256 199 503 minecraft:brown_terracotta
setblock 259 199 464 minecraft:bone_block
setblock 259 199 504 minecraft:bone_block
fill 260 199 464 263 199 464 minecraft:brown_terracotta
fill 263 199 495 263 200 495 minecraft:soul_soil
setblock 264 199 464 minecraft:bone_block
fill 265 199 464 265 202 464 minecraft:brown_terracotta
fill 266 199 465 266 200 465 minecraft:brown_terracotta
setblock 268 199 464 minecraft:brown_terracotta
setblock 268 199 465 minecraft:bone_block
fill 268 199 466 268 202 466 minecraft:brown_terracotta
setblock 269 199 464 minecraft:bone_block
fill 269 199 465 269 202 465 minecraft:brown_terracotta
setblock 269 199 504 minecraft:bone_block
fill 270 199 464 270 202 464 minecraft:brown_terracotta
fill 270 199 504 270 202 504 minecraft:brown_terracotta
setblock 271 199 467 minecraft:bone_block
setblock 272 199 466 minecraft:bone_block
fill 272 199 467 272 202 467 minecraft:brown_terracotta
setblock 273 199 465 minecraft:bone_block
fill 273 199 466 273 202 466 minecraft:brown_terracotta
fill 273 199 468 273 199 469 minecraft:brown_terracotta
setblock 273 199 470 minecraft:bone_block
setblock 274 199 464 minecraft:bone_block
fill 274 199 465 274 202 465 minecraft:brown_terracotta
setblock 274 199 468 minecraft:brown_terracotta
setblock 274 199 469 minecraft:bone_block
fill 274 199 470 274 202 470 minecraft:brown_terracotta
setblock 274 199 480 minecraft:brown_terracotta
setblock 274 199 484 minecraft:bone_block
fill 274 199 485 274 200 485 minecraft:brown_terracotta
setblock 274 199 504 minecraft:bone_block
fill 275 199 464 275 202 464 minecraft:brown_terracotta
setblock 275 199 468 minecraft:bone_block
fill 275 199 469 275 202 469 minecraft:brown_terracotta
setblock 275 199 473 minecraft:bone_block
fill 275 199 474 275 202 474 minecraft:brown_terracotta
setblock 275 199 478 minecraft:bone_block
setblock 275 199 479 minecraft:brown_terracotta
setblock 275 199 483 minecraft:bone_block
fill 275 199 484 275 201 484 minecraft:brown_terracotta
setblock 275 199 488 minecraft:bone_block
fill 275 199 489 275 201 489 minecraft:brown_terracotta
setblock 275 199 503 minecraft:bone_block
fill 275 199 504 275 202 504 minecraft:brown_terracotta
setblock 276 199 467 minecraft:bone_block
fill 276 199 468 276 202 468 minecraft:brown_terracotta
setblock 276 199 472 minecraft:bone_block
fill 276 199 473 276 202 473 minecraft:brown_terracotta
setblock 276 199 477 minecraft:bone_block
fill 276 199 478 276 200 478 minecraft:brown_terracotta
setblock 276 199 482 minecraft:bone_block
fill 276 199 483 276 201 483 minecraft:brown_terracotta
setblock 276 199 487 minecraft:bone_block
fill 276 199 488 276 202 488 minecraft:brown_terracotta
setblock 276 199 492 minecraft:bone_block
fill 276 199 493 276 200 493 minecraft:brown_terracotta
setblock 276 199 502 minecraft:bone_block
fill 276 199 503 276 201 503 minecraft:brown_terracotta
setblock 236 200 466 minecraft:bone_block
fill 236 200 467 236 203 467 minecraft:brown_terracotta
setblock 236 200 471 minecraft:bone_block
fill 236 200 472 236 202 472 minecraft:brown_terracotta
setblock 236 200 482 minecraft:brown_terracotta
setblock 236 200 486 minecraft:bone_block
fill 236 200 487 236 202 487 minecraft:brown_terracotta
setblock 236 200 491 minecraft:bone_block
fill 236 200 492 236 203 492 minecraft:brown_terracotta
setblock 236 200 496 minecraft:bone_block
setblock 236 200 497 minecraft:brown_terracotta
setblock 236 200 501 minecraft:bone_block
fill 236 200 502 236 202 502 minecraft:brown_terracotta
setblock 237 200 465 minecraft:bone_block
fill 237 200 466 237 202 466 minecraft:brown_terracotta
setblock 237 200 470 minecraft:bone_block
setblock 237 200 504 minecraft:brown_terracotta
setblock 238 200 464 minecraft:bone_block
fill 238 200 465 238 202 465 minecraft:brown_terracotta
setblock 238 200 504 minecraft:bone_block
fill 239 200 464 242 200 464 minecraft:brown_terracotta
setblock 239 200 503 minecraft:bone_block
fill 239 200 504 242 200 504 minecraft:brown_terracotta
setblock 243 200 464 minecraft:bone_block
setblock 243 200 504 minecraft:bone_block
fill 244 200 464 247 200 464 minecraft:brown_terracotta
fill 244 200 504 244 202 504 minecraft:brown_terracotta
setblock 247 200 465 minecraft:bone_block
setblock 248 200 464 minecraft:bone_block
fill 248 200 465 251 200 465 minecraft:brown_terracotta
setblock 248 200 504 minecraft:bone_block
fill 249 200 464 249 203 464 minecraft:brown_terracotta
setblock 249 200 503 minecraft:bone_block
fill 249 200 504 249 203 504 minecraft:brown_terracotta
fill 250 200 503 250 201 503 minecraft:brown_terracotta
setblock 252 200 465 minecraft:bone_block
setblock 253 200 464 minecraft:bone_block
fill 253 200 465 253 202 465 minecraft:brown_terracotta
setblock 253 200 504 minecraft:bone_block
fill 254 200 464 254 203 464 minecraft:brown_terracotta
setblock 254 200 503 minecraft:bone_block
fill 254 200 504 254 202 504 minecraft:brown_terracotta
setblock 255 200 503 minecraft:brown_terracotta
setblock 258 200 464 minecraft:bone_block
setblock 259 200 464 minecraft:brown_terracotta
setblock 264 200 464 minecraft:brown_terracotta
setblock 267 200 464 minecraft:brown_terracotta
setblock 267 200 465 minecraft:bone_block
setblock 268 200 464 minecraft:bone_block
fill 268 200 465 268 203 465 minecraft:brown_terracotta
setblock 268 200 504 minecraft:bone_block
fill 269 200 464 269 203 464 minecraft:brown_terracotta
fill 269 200 504 269 201 504 minecraft:brown_terracotta
setblock 270 200 467 minecraft:bone_block
setblock 271 200 466 minecraft:bone_block
fill 271 200 467 271 203 467 minecraft:brown_terracotta
setblock 272 200 465 minecraft:bone_block
fill 272 200 466 272 203 466 minecraft:brown_terracotta
setblock 273 200 464 minecraft:bone_block
fill 273 200 465 273 203 465 minecraft:brown_terracotta
setblock 273 200 468 minecraft:brown_terracotta
setblock 273 200 469 minecraft:bone_block
fill 273 200 470 273 202 470 minecraft:brown_terracotta
setblock 273 200 504 minecraft:bone_block
fill 274 200 464 274 203 464 minecraft:brown_terracotta
setblock 274 200 468 minecraft:bone_block
fill 274 200 469 274 203 469 minecraft:brown_terracotta
setblock 274 200 473 minecraft:bone_block
setblock 274 200 484 minecraft:brown_terracotta
setblock 274 200 503 minecraft:bone_block
fill 274 200 504 274 203 504 minecraft:brown_terracotta
setblock 275 200 467 minecraft:bone_block
fill 275 200 468 275 203 468 minecraft:brown_terracotta
setblock 275 200 472 minecraft:bone_block
fill 275 200 473 275 203 473 minecraft:brown_terracotta
setblock 275 200 482 minecraft:bone_block
setblock 275 200 483 minecraft:brown_terracotta
setblock 275 200 487 minecraft:bone_block
fill 275 200 488 275 201 488 minecraft:brown_terracotta
setblock 275 200 503 minecraft:brown_terracotta
setblock 276 200 466 minecraft:bone_block
fill 276 200 467 276 203 467 minecraft:brown_terracotta
setblock 276 200 471 minecraft:bone_block
fill 276 200 472 276 203 472 minecraft:brown_terracotta
setblock 276 200 476 minecraft:bone_block
fill 276 200 477 276 201 477 minecraft:brown_terracotta
setblock 276 200 481 minecraft:bone_block
fill 276 200 482 276 201 482 minecraft:brown_terracotta
setblock 276 200 486 minecraft:bone_block
fill 276 200 487 276 202 487 minecraft:brown_terracotta
setblock 276 200 491 minecraft:bone_block
fill 276 200 492 276 201 492 minecraft:brown_terracotta
setblock 276 200 501 minecraft:bone_block
setblock 276 200 502 minecraft:brown_terracotta
setblock 236 201 465 minecraft:bone_block
fill 236 201 466 236 204 466 minecraft:brown_terracotta
setblock 236 201 470 minecraft:bone_block
fill 236 201 471 236 204 471 minecraft:brown_terracotta
setblock 236 201 485 minecraft:bone_block
fill 236 201 486 236 202 486 minecraft:brown_terracotta
setblock 236 201 490 minecraft:bone_block
fill 236 201 491 236 204 491 minecraft:brown_terracotta
setblock 236 201 495 minecraft:bone_block
setblock 236 201 500 minecraft:bone_block
fill 236 201 501 236 202 501 minecraft:brown_terracotta
setblock 237 201 464 minecraft:bone_block
fill 237 201 465 237 202 465 minecraft:brown_terracotta
setblock 237 201 469 minecraft:bone_block
setblock 237 201 504 minecraft:bone_block
fill 238 201 464 241 201 464 minecraft:brown_terracotta
fill 238 201 504 241 201 504 minecraft:brown_terracotta
setblock 242 201 464 minecraft:bone_block
setblock 242 201 504 minecraft:bone_block
fill 243 201 464 246 201 464 minecraft:brown_terracotta
setblock 243 201 504 minecraft:brown_terracotta
fill 244 201 497 248 202 501 minecraft:soul_soil
fill 246 201 502 246 201 503 minecraft:soul_soil
setblock 247 201 464 minecraft:bone_block
setblock 247 201 504 minecraft:bone_block
fill 248 201 464 248 201 465 minecraft:brown_terracotta
setblock 248 201 503 minecraft:bone_block
fill 248 201 504 248 204 504 minecraft:brown_terracotta
fill 249 201 465 250 201 465 minecraft:brown_terracotta
setblock 249 201 503 minecraft:brown_terracotta
setblock 251 201 465 minecraft:bone_block
setblock 252 201 464 minecraft:bone_block
fill 252 201 465 252 202 465 minecraft:brown_terracotta
setblock 252 201 504 minecraft:bone_block
fill 253 201 464 253 203 464 minecraft:brown_terracotta
setblock 253 201 503 minecraft:bone_block
fill 253 201 504 253 203 504 minecraft:brown_terracotta
setblock 257 201 464 minecraft:bone_block
setblock 266 201 465 minecraft:bone_block
setblock 267 201 464 minecraft:bone_block
fill 267 201 465 267 204 465 minecraft:brown_terracotta
fill 268 201 464 268 204 464 minecraft:brown_terracotta
setblock 270 201 466 minecraft:bone_block
fill 270 201 467 270 204 467 minecraft:brown_terracotta
setblock 271 201 465 minecraft:bone_block
fill 271 201 466 271 204 466 minecraft:brown_terracotta
setblock 272 201 464 minecraft:bone_block
fill 272 201 465 272 204 465 minecraft:brown_terracotta
setblock 272 201 504 minecraft:bone_block
fill 273 201 464 273 204 464 minecraft:brown_terracotta
setblock 273 201 468 minecraft:bone_block
fill 273 201 469 273 204 469 minecraft:brown_terracotta
fill 273 201 504 273 204 504 minecraft:brown_terracotta
setblock 274 201 467 minecraft:bone_block
fill 274 201 468 274 204 468 minecraft:brown_terracotta
setblock 274 201 472 minecraft:bone_block
setblock 275 201 466 minecraft:bone_block
fill 275 201 467 275 204 467 minecraft:brown_terracotta
setblock 275 201 471 minecraft:bone_block
fill 275 201 472 275 204 472 minecraft:brown_terracotta
setblock 275 201 486 minecraft:bone_block
setblock 275 201 487 minecraft:brown_terracotta
setblock 276 201 465 minecraft:bone_block
fill 276 201 466 276 204 466 minecraft:brown_terracotta
setblock 276 201 470 minecraft:bone_block
fill 276 201 471 276 204 471 minecraft:brown_terracotta
setblock 276 201 475 minecraft:bone_block
setblock 276 201 476 minecraft:brown_terracotta
setblock 276 201 480 minecraft:bone_block
setblock 276 201 481 minecraft:brown_terracotta
setblock 276 201 485 minecraft:bone_block
fill 276 201 486 276 202 486 minecraft:brown_terracotta
setblock 276 201 490 minecraft:bone_block
fill 276 201 491 276 203 491 minecraft:brown_terracotta
setblock 236 202 464 minecraft:bone_block
fill 236 202 465 236 205 465 minecraft:brown_terracotta
setblock 236 202 469 minecraft:bone_block
fill 236 202 470 236 205 470 minecraft:brown_terracotta
setblock 236 202 489 minecraft:bone_block
fill 236 202 490 236 205 490 minecraft:brown_terracotta
setblock 236 202 494 minecraft:bone_block
fill 236 202 495 236 205 495 minecraft:brown_terracotta
setblock 236 202 503 minecraft:brown_terracotta
setblock 236 202 504 minecraft:bone_block
fill 237 202 464 240 202 464 minecraft:brown_terracotta
setblock 237 202 468 minecraft:bone_block
fill 237 202 504 240 202 504 minecraft:brown_terracotta
setblock 241 202 464 minecraft:bone_block
fill 244 202 464 245 202 464 minecraft:brown_terracotta
setblock 246 202 464 minecraft:bone_block
setblock 246 202 504 minecraft:bone_block
fill 247 202 464 248 204 464 minecraft:brown_terracotta
fill 247 202 504 247 205 504 minecraft:brown_terracotta
setblock 249 202 465 minecraft:brown_terracotta
setblock 250 202 465 minecraft:bone_block
setblock 251 202 464 minecraft:bone_block
setblock 251 202 465 minecraft:brown_terracotta
setblock 251 202 504 minecraft:bone_block
fill 252 202 464 252 204 464 minecraft:brown_terracotta
fill 252 202 504 252 203 504 minecraft:brown_terracotta
setblock 266 202 464 minecraft:bone_block
fill 266 202 465 266 205 465 minecraft:brown_terracotta
fill 267 202 464 267 205 464 minecraft:brown_terracotta
setblock 269 202 466 minecraft:bone_block
setblock 270 202 465 minecraft:bone_block
fill 270 202 466 270 205 466 minecraft:brown_terracotta
setblock 271 202 464 minecraft:bone_block
fill 271 202 465 271 205 465 minecraft:brown_terracotta
setblock 271 202 504 minecraft:bone_block
fill 272 202 464 272 205 464 minecraft:brown_terracotta
fill 272 202 504 272 205 504 minecraft:brown_terracotta
setblock 273 202 467 minecraft:bone_block
fill 273 202 468 273 204 468 minecraft:brown_terracotta
setblock 274 202 466 minecraft:bone_block
fill 274 202 467 274 205 467 minecraft:brown_terracotta
setblock 274 202 471 minecraft:bone_block
fill 274 202 472 274 205 472 minecraft:brown_terracotta
setblock 275 202 465 minecraft:bone_block
fill 275 202 466 275 205 466 minecraft:brown_terracotta
setblock 275 202 470 minecraft:bone_block
fill 275 202 471 275 205 471 minecraft:brown_terracotta
setblock 276 202 464 minecraft:bone_block
fill 276 202 465 276 205 465 minecraft:brown_terracotta
setblock 276 202 469 minecraft:bone_block
fill 276 202 470 276 205 470 minecraft:brown_terracotta
setblock 276 202 474 minecraft:bone_block
setblock 276 202 475 minecraft:brown_terracotta
setblock 276 202 485 minecraft:brown_terracotta
setblock 276 202 489 minecraft:bone_block
fill 276 202 490 276 203 490 minecraft:brown_terracotta
setblock 276 202 504 minecraft:bone_block
fill 236 203 464 239 203 464 minecraft:brown_terracotta
setblock 236 203 468 minecraft:bone_block
fill 236 203 469 236 206 469 minecraft:brown_terracotta
setblock 236 203 488 minecraft:bone_block
fill 236 203 489 236 206 489 minecraft:brown_terracotta
setblock 236 203 493 minecraft:bone_block
fill 236 203 494 236 206 494 minecraft:brown_terracotta
setblock 236 203 503 minecraft:bone_block
fill 236 203 504 237 203 504 minecraft:brown_terracotta
setblock 238 203 466 minecraft:light[level=12]
setblock 238 203 474 minecraft:light[level=12]
setblock 238 203 482 minecraft:light[level=12]
setblock 238 203 490 minecraft:light[level=12]
setblock 238 203 498 minecraft:light[level=12]
fill 242 203 498 244 204 498 minecraft:bone_block
fill 242 203 500 244 204 500 minecraft:bone_block
fill 243 203 499 243 204 499 minecraft:bone_block
setblock 245 203 504 minecraft:bone_block
setblock 246 203 464 minecraft:brown_terracotta
setblock 246 203 466 minecraft:light[level=12]
setblock 246 203 474 minecraft:light[level=12]
setblock 246 203 482 minecraft:light[level=12]
setblock 246 203 490 minecraft:light[level=12]
setblock 246 203 498 minecraft:light[level=12]
fill 246 203 504 246 206 504 minecraft:brown_terracotta
setblock 250 203 464 minecraft:bone_block
setblock 250 203 504 minecraft:bone_block
fill 251 203 464 251 205 464 minecraft:brown_terracotta
fill 251 203 504 251 204 504 minecraft:brown_terracotta
setblock 254 203 466 minecraft:light[level=12]
setblock 254 203 474 minecraft:light[level=12]
setblock 254 203 482 minecraft:light[level=12]
setblock 254 203 490 minecraft:light[level=12]
setblock 254 203 498 minecraft:light[level=12]
setblock 262 203 466 minecraft:light[level=12]
setblock 262 203 474 minecraft:light[level=12]
setblock 262 203 482 minecraft:light[level=12]
setblock 262 203 490 minecraft:light[level=12]
setblock 262 203 498 minecraft:light[level=12]
setblock 265 203 464 minecraft:bone_block
fill 266 203 464 266 206 464 minecraft:brown_terracotta
setblock 268 203 466 minecraft:bone_block
setblock 269 203 465 minecraft:bone_block
fill 269 203 466 269 206 466 minecraft:brown_terracotta
setblock 270 203 464 minecraft:bone_block
fill 270 203 465 270 206 465 minecraft:brown_terracotta
setblock 270 203 474 minecraft:light[level=12]
setblock 270 203 482 minecraft:light[level=12]
setblock 270 203 490 minecraft:light[level=12]
setblock 270 203 498 minecraft:light[level=12]
setblock 270 203 504 minecraft:bone_block
fill 271 203 464 271 206 464 minecraft:brown_terracotta
fill 271 203 504 271 206 504 minecraft:brown_terracotta
setblock 272 203 467 minecraft:bone_block
setblock 273 203 466 minecraft:bone_block
setblock 273 203 467 minecraft:brown_terracotta
setblock 274 203 465 minecraft:bone_block
fill 274 203 466 274 205 466 minecraft:brown_terracotta
setblock 274 203 470 minecraft:bone_block
fill 274 203 471 274 206 471 minecraft:brown_terracotta
setblock 275 203 464 minecraft:bone_block
fill 275 203 465 275 206 465 minecraft:brown_terracotta
setblock 275 203 469 minecraft:bone_block
fill 275 203 470 275 206 470 minecraft:brown_terracotta
setblock 275 203 504 minecraft:bone_block
fill 276 203 464 276 206 464 minecraft:brown_terracotta
setblock 276 203 468 minecraft:bone_block
fill 276 203 469 276 206 469 minecraft:brown_terracotta
setblock 276 203 473 minecraft:bone_block
fill 276 203 474 276 206 474 minecraft:brown_terracotta
setblock 276 203 488 minecraft:bone_block
setblock 276 203 489 minecraft:brown_terracotta
fill 236 204 464 237 204 464 minecraft:brown_terracotta
setblock 236 204 467 minecraft:bone_block
fill 236 204 468 236 207 468 minecraft:brown_terracotta
setblock 236 204 492 minecraft:bone_block
fill 236 204 493 236 207 493 minecraft:brown_terracotta
setblock 236 204 504 minecraft:brown_terracotta
fill 244 204 499 245 205 499 minecraft:bone_block
setblock 249 204 464 minecraft:bone_block
setblock 249 204 504 minecraft:bone_block
fill 250 204 464 250 206 464 minecraft:brown_terracotta
fill 250 204 504 250 207 504 minecraft:brown_terracotta
fill 265 204 464 265 207 464 minecraft:brown_terracotta
setblock 268 204 465 minecraft:bone_block
fill 268 204 466 268 207 466 minecraft:brown_terracotta
setblock 269 204 464 minecraft:bone_block
fill 269 204 465 269 207 465 minecraft:brown_terracotta
fill 270 204 464 270 207 464 minecraft:brown_terracotta
setblock 271 204 467 minecraft:bone_block
setblock 272 204 466 minecraft:bone_block
setblock 272 204 467 minecraft:brown_terracotta
setblock 273 204 465 minecraft:bone_block
fill 273 204 466 273 207 466 minecraft:brown_terracotta
setblock 274 204 464 minecraft:bone_block
fill 274 204 465 274 207 465 minecraft:brown_terracotta
setblock 274 204 469 minecraft:bone_block
fill 274 204 470 274 207 470 minecraft:brown_terracotta
fill 275 204 464 275 207 464 minecraft:brown_terracotta
setblock 275 204 468 minecraft:bone_block
fill 275 204 469 275 207 469 minecraft:brown_terracotta
setblock 275 204 473 minecraft:bone_block
setblock 276 204 467 minecraft:bone_block
fill 276 204 468 276 207 468 minecraft:brown_terracotta
setblock 276 204 472 minecraft:bone_block
fill 276 204 473 276 207 473 minecraft:brown_terracotta
fill 235 205 463 239 206 463 minecraft:brown_terracotta
setblock 235 205 464 minecraft:soul_soil
fill 235 205 465 235 206 467 minecraft:brown_terracotta
setblock 235 205 468 minecraft:soul_soil
fill 235 205 469 235 208 469 minecraft:brown_terracotta
setblock 235 205 470 minecraft:soul_soil
fill 235 205 488 235 208 489 minecraft:brown_terracotta
setblock 235 205 490 minecraft:soul_soil
setblock 235 205 501 minecraft:soul_soil
fill 235 205 502 235 208 502 minecraft:brown_terracotta
setblock 236 205 464 minecraft:brown_terracotta
setblock 236 205 466 minecraft:bone_block
fill 236 205 467 236 208 467 minecraft:brown_terracotta
setblock 236 205 471 minecraft:bone_block
setblock 236 205 491 minecraft:bone_block
fill 236 205 492 236 208 492 minecraft:brown_terracotta
setblock 236 205 496 minecraft:bone_block
fill 237 205 505 237 208 505 minecraft:brown_terracotta
fill 238 205 505 238 206 505 minecraft:soul_soil
setblock 240 205 463 minecraft:soul_soil
fill 246 205 499 246 206 499 minecraft:bone_block
setblock 247 205 464 minecraft:brown_terracotta
fill 247 205 505 247 208 505 minecraft:brown_terracotta
setblock 248 205 464 minecraft:bone_block
setblock 248 205 504 minecraft:bone_block
setblock 248 205 505 minecraft:soul_soil
fill 249 205 464 249 208 464 minecraft:brown_terracotta
fill 249 205 504 249 205 505 minecraft:brown_terracotta
fill 250 205 505 253 208 505 minecraft:brown_terracotta
setblock 254 205 505 minecraft:soul_soil
fill 255 205 505 256 208 505 minecraft:brown_terracotta
fill 261 205 467 261 206 468 minecraft:bone_block
setblock 261 205 505 minecraft:soul_soil
fill 262 205 463 262 208 463 minecraft:brown_terracotta
fill 262 205 505 265 205 505 minecraft:brown_terracotta
fill 263 205 463 263 207 463 minecraft:soul_soil
setblock 266 205 505 minecraft:soul_soil
setblock 267 205 465 minecraft:bone_block
fill 267 205 466 267 208 466 minecraft:brown_terracotta
fill 267 205 505 268 206 505 minecraft:brown_terracotta
setblock 268 205 464 minecraft:bone_block
fill 268 205 465 268 208 465 minecraft:brown_terracotta
fill 269 205 464 269 208 464 minecraft:brown_terracotta
setblock 269 205 505 minecraft:soul_soil
setblock 270 205 467 minecraft:bone_block
fill 271 205 463 272 205 463 minecraft:soul_soil
setblock 271 205 466 minecraft:bone_block
fill 271 205 467 271 206 467 minecraft:brown_terracotta
setblock 272 205 465 minecraft:bone_block
fill 272 205 466 272 208 466 minecraft:brown_terracotta
fill 273 205 463 273 208 463 minecraft:brown_terracotta
setblock 273 205 464 minecraft:bone_block
fill 273 205 465 273 208 465 minecraft:brown_terracotta
fill 274 205 464 274 208 464 minecraft:brown_terracotta
setblock 274 205 468 minecraft:bone_block
fill 274 205 469 274 208 469 minecraft:brown_terracotta
setblock 275 205 467 minecraft:bone_block
fill 275 205 468 275 208 468 minecraft:brown_terracotta
setblock 275 205 472 minecraft:bone_block
fill 275 205 473 275 208 473 minecraft:brown_terracotta
setblock 276 205 466 minecraft:bone_block
fill 276 205 467 276 208 467 minecraft:brown_terracotta
setblock 276 205 471 minecraft:bone_block
fill 276 205 472 276 208 472 minecraft:brown_terracotta
fill 277 205 463 277 205 464 minecraft:soul_soil
setblock 277 205 470 minecraft:soul_soil
fill 277 205 473 277 208 474 minecraft:brown_terracotta
setblock 277 205 475 minecraft:soul_soil
fill 277 205 476 277 208 476 minecraft:brown_terracotta
fill 277 205 496 277 206 496 minecraft:soul_soil
fill 277 205 497 277 208 497 minecraft:brown_terracotta
setblock 277 205 498 minecraft:soul_soil
fill 277 205 499 277 208 500 minecraft:brown_terracotta
setblock 277 205 501 minecraft:soul_soil
fill 235 206 464 235 209 464 minecraft:brown_terracotta
setblock 235 206 468 minecraft:brown_terracotta
fill 235 206 470 235 208 470 minecraft:brown_terracotta
fill 235 206 477 235 208 478 minecraft:brown_terracotta
fill 235 206 479 235 207 479 minecraft:soul_soil
fill 235 206 480 235 208 480 minecraft:brown_terracotta
setblock 235 206 481 minecraft:soul_soil
fill 235 206 482 235 206 485 minecraft:brown_terracotta
fill 235 206 490 235 208 490 minecraft:brown_terracotta
fill 235 206 492 235 208 492 minecraft:brown_terracotta
setblock 235 206 493 minecraft:soul_soil
fill 235 206 494 235 206 497 minecraft:brown_terracotta
setblock 235 206 498 minecraft:soul_soil
fill 235 206 499 235 208 499 minecraft:brown_terracotta
fill 235 206 501 235 208 501 minecraft:brown_terracotta
fill 235 206 503 235 208 503 minecraft:brown_terracotta
setblock 235 206 504 minecraft:soul_soil
setblock 236 206 465 minecraft:bone_block
fill 236 206 466 236 207 466 minecraft:brown_terracotta
setblock 236 206 470 minecraft:bone_block
fill 236 206 471 236 209 471 minecraft:brown_terracotta
setblock 236 206 490 minecraft:bone_block
fill 236 206 491 236 209 491 minecraft:brown_terracotta
setblock 236 206 495 minecraft:bone_block
fill 236 206 496 236 207 498 minecraft:brown_terracotta
fill 239 206 505 240 208 505 minecraft:brown_terracotta
setblock 240 206 463 minecraft:brown_terracotta
setblock 241 206 505 minecraft:soul_soil
fill 242 206 505 242 208 505 minecraft:brown_terracotta
setblock 243 206 505 minecraft:soul_soil
fill 245 206 504 245 207 504 minecraft:brown_terracotta
setblock 246 206 463 minecraft:soul_soil
fill 247 206 463 250 206 463 minecraft:brown_terracotta
setblock 247 206 464 minecraft:bone_block
fill 247 206 499 248 207 499 minecraft:bone_block
setblock 247 206 504 minecraft:bone_block
fill 248 206 464 248 209 464 minecraft:brown_terracotta
fill 248 206 504 248 208 505 minecraft:brown_terracotta
fill 249 206 504 249 208 504 minecraft:brown_terracotta
setblock 249 206 505 minecraft:soul_soil
fill 254 206 505 254 208 505 minecraft:brown_terracotta
fill 257 206 505 258 206 505 minecraft:soul_soil
fill 261 206 505 261 208 505 minecraft:brown_terracotta
setblock 262 206 505 minecraft:soul_soil
fill 263 206 505 266 206 505 minecraft:brown_terracotta
fill 264 206 464 264 208 464 minecraft:brown_terracotta
setblock 266 206 465 minecraft:bone_block
setblock 267 206 464 minecraft:bone_block
fill 267 206 465 267 209 465 minecraft:brown_terracotta
fill 268 206 464 268 209 464 minecraft:brown_terracotta
setblock 269 206 467 minecraft:bone_block
fill 269 206 505 269 208 505 minecraft:brown_terracotta
setblock 270 206 466 minecraft:bone_block
fill 270 206 467 270 208 467 minecraft:brown_terracotta
fill 270 206 504 270 207 504 minecraft:brown_terracotta
setblock 271 206 463 minecraft:soul_soil
setblock 271 206 465 minecraft:bone_block
fill 271 206 466 271 209 466 minecraft:brown_terracotta
fill 272 206 463 272 208 463 minecraft:brown_terracotta
setblock 272 206 464 minecraft:bone_block
fill 272 206 465 272 209 465 minecraft:brown_terracotta
setblock 272 206 504 minecraft:bone_block
fill 273 206 464 273 209 464 minecraft:brown_terracotta
setblock 274 206 467 minecraft:bone_block
fill 274 206 468 274 208 468 minecraft:brown_terracotta
setblock 274 206 472 minecraft:bone_block
setblock 275 206 466 minecraft:bone_block
fill 275 206 467 275 209 467 minecraft:brown_terracotta
setblock 275 206 471 minecraft:bone_block
fill 275 206 472 275 209 472 minecraft:brown_terracotta
setblock 276 206 465 minecraft:bone_block
fill 276 206 466 276 209 466 minecraft:brown_terracotta
setblock 276 206 470 minecraft:bone_block
fill 276 206 471 276 209 471 minecraft:brown_terracotta
fill 277 206 463 277 208 464 minecraft:brown_terracotta
setblock 277 206 470 minecraft:brown_terracotta
setblock 277 206 471 minecraft:soul_soil
fill 277 206 472 277 208 472 minecraft:brown_terracotta
fill 277 206 475 277 209 475 minecraft:brown_terracotta
setblock 277 206 479 minecraft:soul_soil
fill 277 206 480 277 206 481 minecraft:brown_terracotta
setblock 277 206 484 minecraft:soul_soil
fill 277 206 485 277 208 485 minecraft:brown_terracotta
fill 277 206 498 277 208 498 minecraft:brown_terracotta
fill 277 206 501 277 208 501 minecraft:brown_terracotta
setblock 277 206 502 minecraft:soul_soil
setblock 235 207 463 minecraft:soul_soil
fill 235 207 465 235 208 465 minecraft:brown_terracotta
setblock 235 207 466 minecraft:soul_soil
fill 235 207 467 235 208 467 minecraft:brown_terracotta
setblock 235 207 468 minecraft:soul_soil
fill 235 207 471 235 208 472 minecraft:brown_terracotta
setblock 235 207 473 minecraft:soul_soil
fill 235 207 474 235 208 476 minecraft:brown_terracotta
fill 235 207 481 235 208 481 minecraft:brown_terracotta
fill 235 207 482 235 207 483 minecraft:soul_soil
fill 235 207 484 235 208 485 minecraft:brown_terracotta
fill 235 207 493 235 208 493 minecraft:brown_terracotta
setblock 235 207 494 minecraft:soul_soil
fill 235 207 495 235 208 496 minecraft:brown_terracotta
setblock 235 207 497 minecraft:soul_soil
fill 235 207 498 235 208 498 minecraft:brown_terracotta
fill 235 207 504 235 208 504 minecraft:brown_terracotta
fill 236 207 463 236 208 463 minecraft:brown_terracotta
setblock 236 207 469 minecraft:bone_block
fill 236 207 470 236 210 470 minecraft:brown_terracotta
setblock 236 207 489 minecraft:bone_block
fill 236 207 490 236 210 490 minecraft:brown_terracotta
setblock 236 207 494 minecraft:bone_block
fill 236 207 495 236 210 495 minecraft:brown_terracotta
setblock 236 207 499 minecraft:bone_block
setblock 237 207 463 minecraft:soul_soil
fill 238 207 463 239 208 463 minecraft:brown_terracotta
fill 238 207 505 238 208 505 minecraft:brown_terracotta
fill 240 207 463 241 207 463 minecraft:soul_soil
fill 241 207 505 241 208 505 minecraft:brown_terracotta
fill 243 207 505 243 208 505 minecraft:brown_terracotta
fill 244 207 504 244 208 504 minecraft:brown_terracotta
fill 246 207 463 246 208 463 minecraft:brown_terracotta
setblock 246 207 504 minecraft:bone_block
setblock 247 207 463 minecraft:soul_soil
fill 247 207 464 247 210 464 minecraft:brown_terracotta
fill 247 207 504 247 210 504 minecraft:brown_terracotta
fill 248 207 463 250 208 463 minecraft:brown_terracotta
fill 248 207 498 250 208 498 minecraft:bone_block
fill 248 207 500 250 208 500 minecraft:bone_block
fill 249 207 499 249 208 499 minecraft:bone_block
fill 249 207 505 249 208 505 minecraft:brown_terracotta
fill 252 207 463 252 208 463 minecraft:brown_terracotta
setblock 253 207 463 minecraft:soul_soil
fill 254 207 463 255 208 463 minecraft:brown_terracotta
setblock 256 207 463 minecraft:soul_soil
fill 257 207 463 261 208 463 minecraft:brown_terracotta
fill 257 207 505 258 208 505 minecraft:brown_terracotta
fill 262 207 505 264 208 505 minecraft:brown_terracotta
setblock 264 207 463 minecraft:soul_soil
setblock 265 207 465 minecraft:bone_block
fill 265 207 505 267 207 505 minecraft:soul_soil
setblock 266 207 464 minecraft:bone_block
fill 266 207 465 266 209 466 minecraft:brown_terracotta
fill 267 207 464 267 210 464 minecraft:brown_terracotta
setblock 268 207 467 minecraft:bone_block
fill 268 207 505 268 208 505 minecraft:brown_terracotta
setblock 269 207 463 minecraft:soul_soil
setblock 269 207 466 minecraft:bone_block
fill 269 207 467 269 209 467 minecraft:brown_terracotta
fill 269 207 504 269 208 504 minecraft:brown_terracotta
setblock 270 207 465 minecraft:bone_block
fill 270 207 466 270 210 466 minecraft:brown_terracotta
fill 270 207 505 272 208 505 minecraft:brown_terracotta
fill 271 207 463 271 208 463 minecraft:brown_terracotta
setblock 271 207 464 minecraft:bone_block
fill 271 207 465 271 210 465 minecraft:brown_terracotta
setblock 271 207 504 minecraft:bone_block
fill 272 207 464 272 210 464 minecraft:brown_terracotta
fill 272 207 504 272 210 504 minecraft:brown_terracotta
setblock 273 207 505 minecraft:soul_soil
setblock 274 207 467 minecraft:brown_terracotta
setblock 274 207 471 minecraft:bone_block
fill 274 207 472 274 210 472 minecraft:brown_terracotta
fill 274 207 505 275 208 505 minecraft:brown_terracotta
setblock 275 207 465 minecraft:bone_block
fill 275 207 466 275 209 466 minecraft:brown_terracotta
setblock 275 207 470 minecraft:bone_block
fill 275 207 471 275 210 471 minecraft:brown_terracotta
setblock 275 207 474 minecraft:brown_terracotta
setblock 276 207 464 minecraft:bone_block
fill 276 207 465 276 210 465 minecraft:brown_terracotta
setblock 276 207 469 minecraft:bone_block
fill 276 207 470 276 210 470 minecraft:brown_terracotta
setblock 276 207 474 minecraft:bone_block
fill 276 207 475 276 210 475 minecraft:brown_terracotta
setblock 276 207 493 minecraft:brown_terracotta
setblock 276 207 494 minecraft:bone_block
setblock 277 207 470 minecraft:soul_soil
fill 277 207 471 277 208 471 minecraft:brown_terracotta
fill 277 207 479 277 208 480 minecraft:brown_terracotta
setblock 277 207 481 minecraft:soul_soil
fill 277 207 484 277 208 484 minecraft:brown_terracotta
fill 277 207 486 277 207 487 minecraft:soul_soil
setblock 277 207 491 minecraft:soul_soil
fill 277 207 496 277 208 496 minecraft:brown_terracotta
fill 277 207 502 277 208 502 minecraft:brown_terracotta
setblock 235 208 463 minecraft:brown_terracotta
setblock 235 208 466 minecraft:brown_terracotta
setblock 235 208 468 minecraft:brown_terracotta
fill 235 208 473 235 209 473 minecraft:brown_terracotta
setblock 235 208 479 minecraft:brown_terracotta
fill 235 208 482 235 208 483 minecraft:brown_terracotta
fill 235 208 494 237 208 494 minecraft:brown_terracotta
fill 235 208 497 236 208 497 minecraft:brown_terracotta
setblock 236 208 468 minecraft:bone_block
fill 236 208 469 236 209 469 minecraft:brown_terracotta
setblock 236 208 472 minecraft:brown_terracotta
fill 236 208 489 236 210 489 minecraft:brown_terracotta
setblock 236 208 493 minecraft:bone_block
fill 236 208 496 237 208 496 minecraft:brown_terracotta
setblock 236 208 498 minecraft:bone_block
fill 236 208 499 236 209 501 minecraft:brown_terracotta
setblock 237 208 463 minecraft:brown_terracotta
setblock 237 208 492 minecraft:bone_block
fill 237 208 493 237 211 493 minecraft:brown_terracotta
fill 237 208 495 237 209 495 minecraft:brown_terracotta
fill 240 208 463 241 208 463 minecraft:brown_terracotta
fill 243 208 504 243 209 504 minecraft:brown_terracotta
setblock 245 208 504 minecraft:bone_block
fill 246 208 464 246 211 464 minecraft:brown_terracotta
fill 246 208 504 246 211 504 minecraft:brown_terracotta
setblock 247 208 463 minecraft:brown_terracotta
setblock 250 208 504 minecraft:bone_block
setblock 253 208 463 minecraft:brown_terracotta
setblock 256 208 463 minecraft:brown_terracotta
fill 263 208 463 263 208 464 minecraft:brown_terracotta
setblock 264 208 463 minecraft:brown_terracotta
setblock 264 208 465 minecraft:bone_block
setblock 265 208 464 minecraft:bone_block
fill 265 208 465 265 211 465 minecraft:brown_terracotta
fill 265 208 505 267 208 505 minecraft:brown_terracotta
fill 266 208 464 266 211 464 minecraft:brown_terracotta
fill 267 208 504 268 209 504 minecraft:brown_terracotta
setblock 268 208 466 minecraft:bone_block
fill 268 208 467 268 210 467 minecraft:brown_terracotta
setblock 269 208 463 minecraft:brown_terracotta
setblock 269 208 465 minecraft:bone_block
fill 269 208 466 269 211 466 minecraft:brown_terracotta
setblock 270 208 464 minecraft:bone_block
fill 270 208 465 270 211 465 minecraft:brown_terracotta
setblock 270 208 504 minecraft:bone_block
fill 271 208 464 271 211 464 minecraft:brown_terracotta
fill 271 208 504 271 211 504 minecraft:brown_terracotta
fill 273 208 504 273 208 505 minecraft:brown_terracotta
setblock 274 208 465 minecraft:bone_block
setblock 274 208 470 minecraft:bone_block
fill 274 208 471 274 210 471 minecraft:brown_terracotta
setblock 275 208 464 minecraft:bone_block
setblock 275 208 469 minecraft:bone_block
fill 275 208 470 275 211 470 minecraft:brown_terracotta
setblock 275 208 474 minecraft:bone_block
fill 276 208 464 276 211 464 minecraft:brown_terracotta
setblock 276 208 468 minecraft:bone_block
fill 276 208 469 276 211 469 minecraft:brown_terracotta
setblock 276 208 473 minecraft:bone_block
fill 276 208 474 276 211 474 minecraft:brown_terracotta
setblock 276 208 492 minecraft:brown_terracotta
setblock 276 208 493 minecraft:bone_block
fill 276 208 494 276 208 497 minecraft:brown_terracotta
fill 277 208 470 277 209 470 minecraft:brown_terracotta
fill 277 208 481 277 210 481 minecraft:brown_terracotta
fill 277 208 486 277 208 487 minecraft:brown_terracotta
setblock 277 208 491 minecraft:brown_terracotta
fill 235 209 463 243 307 463 minecraft:soul_soil
fill 235 209 465 235 307 470 minecraft:soul_soil
setblock 235 209 471 minecraft:brown_terracotta
fill 235 209 472 235 307 472 minecraft:soul_soil
fill 235 209 474 235 307 477 minecraft:soul_soil
setblock 235 209 478 minecraft:brown_terracotta
fill 235 209 479 235 209 482 minecraft:soul_soil
fill 235 209 483 235 209 484 minecraft:brown_terracotta
fill 235 209 485 235 307 488 minecraft:soul_soil
setblock 235 209 489 minecraft:brown_terracotta
fill 235 209 490 235 209 505 minecraft:soul_soil
setblock 236 209 472 minecraft:bone_block
fill 236 209 473 236 212 473 minecraft:brown_terracotta
setblock 236 209 492 minecraft:bone_block
fill 236 209 493 236 211 494 minecraft:brown_terracotta
setblock 236 209 496 minecraft:brown_terracotta
setblock 236 209 497 minecraft:bone_block
fill 236 209 498 237 211 498 minecraft:brown_terracotta
setblock 236 209 502 minecraft:bone_block
fill 236 209 505 245 209 505 minecraft:soul_soil
fill 237 209 492 237 212 492 minecraft:brown_terracotta
fill 237 209 494 237 210 494 minecraft:brown_terracotta
setblock 237 209 496 minecraft:bone_block
fill 237 209 497 237 212 497 minecraft:brown_terracotta
fill 241 209 504 242 210 504 minecraft:brown_terracotta
setblock 244 209 463 minecraft:brown_terracotta
setblock 244 209 504 minecraft:bone_block
fill 245 209 463 248 307 463 minecraft:soul_soil
fill 245 209 464 245 212 464 minecraft:brown_terracotta
fill 245 209 504 245 212 504 minecraft:brown_terracotta
fill 246 209 503 246 212 503 minecraft:brown_terracotta
fill 247 209 505 269 209 505 minecraft:soul_soil
setblock 248 209 504 minecraft:brown_terracotta
setblock 249 209 463 minecraft:brown_terracotta
setblock 249 209 464 minecraft:bone_block
setblock 249 209 504 minecraft:bone_block
fill 250 209 463 254 209 463 minecraft:soul_soil
fill 250 209 504 250 210 504 minecraft:brown_terracotta
setblock 255 209 463 minecraft:brown_terracotta
fill 256 209 463 267 210 463 minecraft:soul_soil
fill 259 209 475 259 210 475 minecraft:bone_block
setblock 263 209 464 minecraft:brown_terracotta
setblock 264 209 464 minecraft:bone_block
fill 264 209 465 264 212 465 minecraft:brown_terracotta
fill 265 209 464 265 212 464 minecraft:brown_terracotta
fill 265 209 466 265 210 466 minecraft:brown_terracotta
fill 266 209 504 266 211 504 minecraft:brown_terracotta
setblock 267 209 466 minecraft:bone_block
fill 267 209 467 267 210 467 minecraft:brown_terracotta
setblock 268 209 463 minecraft:brown_terracotta
setblock 268 209 465 minecraft:bone_block
fill 268 209 466 268 212 466 minecraft:brown_terracotta
fill 269 209 463 269 307 463 minecraft:soul_soil
setblock 269 209 464 minecraft:bone_block
fill 269 209 465 269 212 465 minecraft:brown_terracotta
setblock 269 209 504 minecraft:bone_block
fill 270 209 464 270 212 464 minecraft:brown_terracotta
fill 270 209 504 270 209 505 minecraft:brown_terracotta
fill 271 209 463 277 307 463 minecraft:soul_soil
fill 271 209 505 271 307 505 minecraft:soul_soil
setblock 272 209 466 minecraft:bone_block
setblock 272 209 505 minecraft:brown_terracotta
setblock 273 209 465 minecraft:bone_block
setblock 273 209 504 minecraft:brown_terracotta
fill 273 209 505 277 209 505 minecraft:soul_soil
setblock 274 209 464 minecraft:bone_block
setblock 274 209 465 minecraft:brown_terracotta
setblock 274 209 469 minecraft:bone_block
schedule function dropper:buildpart/113_7 1t
