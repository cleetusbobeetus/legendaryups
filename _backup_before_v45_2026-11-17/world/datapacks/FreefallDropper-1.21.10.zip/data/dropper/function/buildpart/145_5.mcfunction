fill 62 299 605 62 300 605 minecraft:light_gray_concrete
fill 62 299 607 62 300 607 minecraft:light_gray_concrete
fill 62 299 609 62 300 609 minecraft:light_gray_concrete
fill 62 299 637 62 300 637 minecraft:light_gray_concrete
fill 62 299 639 62 300 639 minecraft:light_gray_concrete
fill 62 299 641 62 300 641 minecraft:light_gray_concrete
fill 62 299 643 62 300 643 minecraft:light_gray_concrete
fill 62 299 645 62 300 645 minecraft:light_gray_concrete
fill 63 299 606 63 300 606 minecraft:light_gray_concrete
fill 63 299 608 63 300 608 minecraft:light_gray_concrete
fill 63 299 610 63 300 610 minecraft:light_gray_concrete
fill 63 299 638 63 300 638 minecraft:light_gray_concrete
fill 63 299 640 63 300 640 minecraft:light_gray_concrete
fill 63 299 642 63 300 642 minecraft:light_gray_concrete
fill 63 299 644 63 300 644 minecraft:light_gray_concrete
fill 64 299 605 64 300 605 minecraft:light_gray_concrete
fill 64 299 607 64 300 607 minecraft:light_gray_concrete
fill 64 299 609 64 300 609 minecraft:light_gray_concrete
fill 64 299 637 64 300 637 minecraft:light_gray_concrete
fill 64 299 639 64 300 639 minecraft:light_gray_concrete
fill 64 299 641 64 300 641 minecraft:light_gray_concrete
fill 64 299 643 64 300 643 minecraft:light_gray_concrete
fill 64 299 645 64 300 645 minecraft:light_gray_concrete
fill 65 299 606 65 300 606 minecraft:light_gray_concrete
fill 65 299 608 65 300 608 minecraft:light_gray_concrete
fill 65 299 610 65 300 610 minecraft:light_gray_concrete
fill 65 299 638 65 300 638 minecraft:light_gray_concrete
fill 65 299 640 65 300 640 minecraft:light_gray_concrete
fill 65 299 642 65 300 642 minecraft:light_gray_concrete
fill 65 299 644 65 300 644 minecraft:light_gray_concrete
fill 66 299 605 66 300 605 minecraft:light_gray_concrete
fill 66 299 607 66 300 607 minecraft:light_gray_concrete
fill 66 299 609 66 300 609 minecraft:light_gray_concrete
setblock 66 299 615 minecraft:light[level=14]
setblock 66 299 623 minecraft:light[level=14]
setblock 66 299 631 minecraft:light[level=14]
fill 66 299 637 66 300 637 minecraft:light_gray_concrete
fill 66 299 639 66 300 639 minecraft:light_gray_concrete
fill 66 299 641 66 300 641 minecraft:light_gray_concrete
fill 66 299 643 66 300 643 minecraft:light_gray_concrete
fill 66 299 645 66 300 645 minecraft:light_gray_concrete
fill 66 299 646 66 300 646 minecraft:sea_lantern
fill 67 299 638 67 300 638 minecraft:light_gray_concrete
fill 67 299 640 67 300 640 minecraft:light_gray_concrete
fill 67 299 642 67 300 642 minecraft:light_gray_concrete
fill 67 299 644 67 300 644 minecraft:light_gray_concrete
fill 68 299 637 68 300 637 minecraft:light_gray_concrete
fill 68 299 639 68 300 639 minecraft:light_gray_concrete
fill 68 299 641 68 300 641 minecraft:light_gray_concrete
fill 68 299 643 68 300 643 minecraft:light_gray_concrete
fill 68 299 645 68 300 645 minecraft:light_gray_concrete
setblock 74 299 607 minecraft:light[level=14]
setblock 74 299 615 minecraft:light[level=14]
setblock 74 299 623 minecraft:light[level=14]
setblock 74 299 631 minecraft:light[level=14]
setblock 74 299 639 minecraft:light[level=14]
fill 77 299 638 77 300 638 minecraft:light_gray_concrete
fill 77 299 640 77 300 640 minecraft:light_gray_concrete
fill 77 299 642 77 300 642 minecraft:light_gray_concrete
fill 77 299 644 77 300 644 minecraft:light_gray_concrete
fill 78 299 639 78 300 639 minecraft:light_gray_concrete
fill 78 299 641 78 300 641 minecraft:light_gray_concrete
fill 78 299 643 78 300 643 minecraft:light_gray_concrete
fill 78 299 645 78 300 645 minecraft:light_gray_concrete
fill 79 299 638 79 300 638 minecraft:light_gray_concrete
fill 79 299 640 79 300 640 minecraft:light_gray_concrete
fill 79 299 642 79 300 642 minecraft:light_gray_concrete
fill 79 299 644 79 300 644 minecraft:light_gray_concrete
fill 80 299 639 80 300 639 minecraft:light_gray_concrete
fill 80 299 641 80 300 641 minecraft:light_gray_concrete
fill 80 299 643 80 300 643 minecraft:light_gray_concrete
fill 80 299 645 80 300 645 minecraft:light_gray_concrete
fill 81 299 638 81 300 638 minecraft:light_gray_concrete
fill 81 299 640 81 300 640 minecraft:light_gray_concrete
fill 81 299 642 81 300 642 minecraft:light_gray_concrete
fill 81 299 644 81 300 644 minecraft:light_gray_concrete
setblock 82 299 607 minecraft:light[level=14]
setblock 82 299 615 minecraft:light[level=14]
setblock 82 299 623 minecraft:light[level=14]
setblock 82 299 631 minecraft:light[level=14]
fill 82 299 639 82 300 639 minecraft:light_gray_concrete
fill 82 299 641 82 300 641 minecraft:light_gray_concrete
fill 82 299 643 82 300 643 minecraft:light_gray_concrete
fill 82 299 645 82 300 645 minecraft:light_gray_concrete
fill 82 299 646 82 300 646 minecraft:sea_lantern
fill 83 299 638 83 300 638 minecraft:light_gray_concrete
fill 83 299 640 83 300 640 minecraft:light_gray_concrete
fill 83 299 642 83 300 642 minecraft:light_gray_concrete
fill 83 299 644 83 300 644 minecraft:light_gray_concrete
fill 84 299 639 84 300 639 minecraft:light_gray_concrete
fill 84 299 641 84 300 641 minecraft:light_gray_concrete
fill 84 299 643 84 300 643 minecraft:light_gray_concrete
fill 84 299 645 84 300 645 minecraft:light_gray_concrete
fill 85 299 638 85 300 638 minecraft:light_gray_concrete
fill 85 299 640 85 300 640 minecraft:light_gray_concrete
fill 85 299 642 85 300 642 minecraft:light_gray_concrete
fill 85 299 644 85 300 644 minecraft:light_gray_concrete
fill 47 301 609 47 307 609 minecraft:gray_concrete
fill 47 301 617 47 307 617 minecraft:gray_concrete
fill 47 301 625 47 307 625 minecraft:gray_concrete
fill 47 301 633 47 307 633 minecraft:gray_concrete
fill 47 301 641 47 307 641 minecraft:gray_concrete
fill 50 301 646 50 307 646 minecraft:gray_concrete
fill 54 301 604 54 307 604 minecraft:gray_concrete
fill 58 301 646 58 307 646 minecraft:gray_concrete
fill 62 301 604 62 307 604 minecraft:gray_concrete
fill 66 301 646 66 307 646 minecraft:gray_concrete
fill 70 301 604 70 307 604 minecraft:gray_concrete
fill 74 301 646 74 307 646 minecraft:gray_concrete
fill 78 301 604 78 307 604 minecraft:gray_concrete
fill 82 301 646 82 307 646 minecraft:gray_concrete
fill 86 301 604 86 307 604 minecraft:gray_concrete
fill 89 301 609 89 307 609 minecraft:gray_concrete
fill 89 301 617 89 307 617 minecraft:gray_concrete
fill 89 301 625 89 307 625 minecraft:gray_concrete
fill 89 301 633 89 307 633 minecraft:gray_concrete
fill 89 301 641 89 307 641 minecraft:gray_concrete
